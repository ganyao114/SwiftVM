00007ff1409ce69b  nop [rax+rax*1], eax
00007ff1409ce6a0  mov rax, [r15+0xF8]
00007ff1409ce6a7  lea r14, [rax-0x1E0]
00007ff1409ce6ae  mov [r15+0xF8], r14
00007ff1409ce6b5  lea rax, [r14+0x1D0]
00007ff1409ce6bc  mov r12, [r15+0xA0]
00007ff1409ce6c3  mov r11, [r15+0x98]
00007ff1409ce6ca  mov [r13+rax*1], r12
00007ff1409ce6cf  lea rax, [r14+0x1D8]
00007ff1409ce6d6  mov [r13+rax*1], r11
00007ff1409ce6db  mov eax, 0x420AA0
00007ff1409ce6e0  movups xmm1, [r13+rax*1]
00007ff1409ce6e6  mov eax, 0x420A30
00007ff1409ce6eb  movups xmm15, [r13+rax*1]
00007ff1409ce6f1  mov eax, 0x420AC0
00007ff1409ce6f6  movups xmm14, [r13+rax*1]
00007ff1409ce6fc  mov eax, 0x420A60
00007ff1409ce701  movups xmm13, [r13+rax*1]
00007ff1409ce707  mov qword ptr [r15+0x98], 0x430CD0
00007ff1409ce712  mov eax, 0x420AD0
00007ff1409ce717  movups xmm12, [r13+rax*1]
00007ff1409ce71d  mov eax, 0x430CD0
00007ff1409ce722  movups [r13+rax*1], xmm1
00007ff1409ce728  mov eax, 0x430CE0
00007ff1409ce72d  movups [r13+rax*1], xmm15
00007ff1409ce733  mov eax, 0x430CF0
00007ff1409ce738  movups [r13+rax*1], xmm14
00007ff1409ce73e  mov eax, 0x430D00
00007ff1409ce743  movups [r13+rax*1], xmm13
00007ff1409ce749  mov eax, 0x420A20
00007ff1409ce74e  movups xmm14, [r13+rax*1]
00007ff1409ce754  mov eax, 0x420A10
00007ff1409ce759  movups xmm13, [r13+rax*1]
00007ff1409ce75f  mov eax, 0x430DD0
00007ff1409ce764  movups [r13+rax*1], xmm1
00007ff1409ce76a  mov eax, 0x430DE0
00007ff1409ce76f  movups [r13+rax*1], xmm15
00007ff1409ce775  mov eax, 0x430D10
00007ff1409ce77a  movups [r13+rax*1], xmm12
00007ff1409ce780  mov eax, 0x430D20
00007ff1409ce785  movups [r13+rax*1], xmm14
00007ff1409ce78b  mov eax, 0x420A00
00007ff1409ce790  movups xmm1, [r13+rax*1]
00007ff1409ce796  mov eax, 0x420A70
00007ff1409ce79b  movups xmm15, [r13+rax*1]
00007ff1409ce7a1  mov eax, 0x430D30
00007ff1409ce7a6  movups [r13+rax*1], xmm13
00007ff1409ce7ac  mov eax, 0x430D40
00007ff1409ce7b1  movups [r13+rax*1], xmm1
00007ff1409ce7b7  mov eax, 0x420A80
00007ff1409ce7bc  movups xmm1, [r13+rax*1]
00007ff1409ce7c2  mov eax, 0x420A50
00007ff1409ce7c7  movups xmm14, [r13+rax*1]
00007ff1409ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007ff1409ce7d5  mov eax, 0x430D50
00007ff1409ce7da  movups [r13+rax*1], xmm15
00007ff1409ce7e0  mov eax, 0x430D60
00007ff1409ce7e5  movups [r13+rax*1], xmm1
00007ff1409ce7eb  mov eax, 0x420AF0
00007ff1409ce7f0  movups xmm1, [r13+rax*1]
00007ff1409ce7f6  mov eax, 0x420B00
00007ff1409ce7fb  movups xmm15, [r13+rax*1]
00007ff1409ce801  movaps [r15+0x150], xmm15
00007ff1409ce809  mov qword ptr [r15+0xA0], 0x3E8
00007ff1409ce814  mov eax, 0x430D70
00007ff1409ce819  movups [r13+rax*1], xmm14
00007ff1409ce81f  mov eax, 0x430D80
00007ff1409ce824  movups [r13+rax*1], xmm1
00007ff1409ce82a  mov eax, 0x420AE0
00007ff1409ce82f  movups xmm1, [r13+rax*1]
00007ff1409ce835  mov eax, 0x420A90
00007ff1409ce83a  movups xmm14, [r13+rax*1]
00007ff1409ce840  movaps [r15+0x140], xmm14
00007ff1409ce848  lea rax, [r14+0x180]
00007ff1409ce84f  movq xmm13, qword ptr [r15+0x200]
00007ff1409ce858  movq xmm12, qword ptr [r15+0x1F0]
00007ff1409ce861  movq r12, xmm13
00007ff1409ce866  movq r11, xmm12
00007ff1409ce86b  mov [r13+rax*1], r12
00007ff1409ce870  lea rax, [r14+0x188]
00007ff1409ce877  mov [r13+rax*1], r11
00007ff1409ce87c  mov eax, 0x430D90
00007ff1409ce881  movups [r13+rax*1], xmm15
00007ff1409ce887  mov eax, 0x430DA0
00007ff1409ce88c  movups [r13+rax*1], xmm1
00007ff1409ce892  mov eax, 0x420AB0
00007ff1409ce897  movups xmm1, [r13+rax*1]
00007ff1409ce89d  mov eax, 0x420B18
00007ff1409ce8a2  mov r12, [r13+rax*1]
00007ff1409ce8a7  movq xmm15, r12
00007ff1409ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007ff1409ce8b4  mov eax, 0x430DB0
00007ff1409ce8b9  movups [r13+rax*1], xmm14
00007ff1409ce8bf  mov eax, 0x430DC0
00007ff1409ce8c4  movups [r13+rax*1], xmm1
00007ff1409ce8ca  mov eax, 0x420B80
00007ff1409ce8cf  movups xmm1, [r13+rax*1]
00007ff1409ce8d5  movq rax, xmm15
00007ff1409ce8da  mov r12d, 0x430DF0
00007ff1409ce8e0  mov [r13+r12*1], rax
00007ff1409ce8e5  mov eax, 0x420B60
00007ff1409ce8ea  movups xmm15, [r13+rax*1]
00007ff1409ce8f0  mov eax, 0x420B70
00007ff1409ce8f5  movups xmm14, [r13+rax*1]
00007ff1409ce8fb  lea rax, [r14+0x160]
00007ff1409ce902  movups [r13+rax*1], xmm1
00007ff1409ce908  lea rax, [r14+0x190]
00007ff1409ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007ff1409ce918  movq xmm13, qword ptr [r15+0x1D0]
00007ff1409ce921  movq r12, xmm1
00007ff1409ce926  movq r11, xmm13
00007ff1409ce92b  mov [r13+rax*1], r12
00007ff1409ce930  lea rax, [r14+0x198]
00007ff1409ce937  mov [r13+rax*1], r11
00007ff1409ce93c  lea rax, [r14+0x140]
00007ff1409ce943  movups [r13+rax*1], xmm15
00007ff1409ce949  lea rax, [r14+0x150]
00007ff1409ce950  movups [r13+rax*1], xmm14
00007ff1409ce956  mov eax, 0x420B20
00007ff1409ce95b  movups xmm1, [r13+rax*1]
00007ff1409ce961  mov eax, 0x420B30
00007ff1409ce966  movups xmm15, [r13+rax*1]
00007ff1409ce96c  movaps [r15+0x120], xmm15
00007ff1409ce974  lea rax, [r14+0x1A0]
00007ff1409ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007ff1409ce984  movq xmm13, qword ptr [r15+0x1B0]
00007ff1409ce98d  movq r12, xmm14
00007ff1409ce992  movq r11, xmm13
00007ff1409ce997  mov [r13+rax*1], r12
00007ff1409ce99c  lea rax, [r14+0x1A8]
00007ff1409ce9a3  mov [r13+rax*1], r11
00007ff1409ce9a8  lea rax, [r14+0x1B0]
00007ff1409ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007ff1409ce9b8  movq xmm13, qword ptr [r15+0x190]
00007ff1409ce9c1  movq r12, xmm14
00007ff1409ce9c6  movq r11, xmm13
00007ff1409ce9cb  mov [r13+rax*1], r12
00007ff1409ce9d0  lea rax, [r14+0x1B8]
00007ff1409ce9d7  mov [r13+rax*1], r11
00007ff1409ce9dc  lea rax, [r14+0x100]
00007ff1409ce9e3  movups [r13+rax*1], xmm1
00007ff1409ce9e9  lea rax, [r14+0x110]
00007ff1409ce9f0  movups [r13+rax*1], xmm15
00007ff1409ce9f6  mov eax, 0x420B40
00007ff1409ce9fb  movups xmm1, [r13+rax*1]
00007ff1409cea01  mov eax, 0x420B50
00007ff1409cea06  movups xmm15, [r13+rax*1]
00007ff1409cea0c  movaps [r15+0x110], xmm1
00007ff1409cea14  movaps [r15+0x130], xmm15
00007ff1409cea1c  lea rax, [r14+0x1C0]
00007ff1409cea23  mov r12, [r15+0xE8]
00007ff1409cea2a  mov r11, [r15+0xF0]
00007ff1409cea31  mov [r13+rax*1], r12
00007ff1409cea36  lea rax, [r14+0x1C8]
00007ff1409cea3d  mov [r13+rax*1], r11
00007ff1409cea42  mov eax, 0x430DF8
00007ff1409cea47  mov r12d, 0x421DF8D3
00007ff1409cea4d  mov [r13+rax*1], r12d
00007ff1409cea52  lea rax, [r14+0x120]
00007ff1409cea59  movups [r13+rax*1], xmm1
00007ff1409cea5f  lea rax, [r14+0x130]
00007ff1409cea66  movups [r13+rax*1], xmm15
00007ff1409cea6c  lea rax, [r14+0x100]
00007ff1409cea73  mov [r15], rax
00007ff1409cea76  mov qword ptr [r15+0x08], 0x430CD0
00007ff1409cea7e  mov qword ptr [r15+0x10], 0x12C
00007ff1409cea86  mov qword ptr [r15+0xF0], 0x410284
00007ff1409cea91  mov r14d, [r15+0x320]
00007ff1409cea98  mov eax, 0x410284
00007ff1409cea9d  mov rcx, 0x7FF1409D07C0
00007ff1409ceaa7  mov [r15+r14*8+0x328], rax
00007ff1409ceaaf  mov [r15+r14*8+0x368], rcx
00007ff1409ceab7  add r14d, 0x01
00007ff1409ceabb  and r14d, 0x07
00007ff1409ceabf  mov [r15+0x320], r14d
00007ff1409ceac6  cmp dword ptr [r15+0x318], 0x00
00007ff1409ceace  jz 0x00007FF1409CED70
00007ff1409cead4  nop [rax+rax*1], ax
00007ff1409ceadd  nop [rax+rax*1], eax
00007ff1409ceae5  mov eax, 0x410728
00007ff1409ceaea  mov [r15+0x100], rax
00007ff1409ceaf1  jmp 0x00007FF1407FE110
00007ff1409ceaf6  int3
00007ff1409ceaf7  call 0x00007FF14080BC20
00007ff1409ceafc  jmp 0x00007FF1409CE6CF
00007ff1409ceb01  call 0x00007FF14080A9A0
00007ff1409ceb06  jmp 0x00007FF1409CE6DB
00007ff1409ceb0b  call 0x00007FF1407FF430
00007ff1409ceb10  jmp 0x00007FF1409CE6E6
00007ff1409ceb15  call 0x00007FF14080E760
00007ff1409ceb1a  jmp 0x00007FF1409CE6F1
00007ff1409ceb1f  call 0x00007FF14080D4E0
00007ff1409ceb24  jmp 0x00007FF1409CE6FC
00007ff1409ceb29  call 0x00007FF14080C260
00007ff1409ceb2e  jmp 0x00007FF1409CE707
00007ff1409ceb33  call 0x00007FF14080AFE0
00007ff1409ceb38  jmp 0x00007FF1409CE71D
00007ff1409ceb3d  call 0x00007FF1407FF540
00007ff1409ceb42  jmp 0x00007FF1409CE728
00007ff1409ceb47  call 0x00007FF14080E880
00007ff1409ceb4c  jmp 0x00007FF1409CE733
00007ff1409ceb51  call 0x00007FF14080D600
00007ff1409ceb56  jmp 0x00007FF1409CE73E
00007ff1409ceb5b  call 0x00007FF14080C380
00007ff1409ceb60  jmp 0x00007FF1409CE749
00007ff1409ceb65  call 0x00007FF14080D4E0
00007ff1409ceb6a  jmp 0x00007FF1409CE754
00007ff1409ceb6f  call 0x00007FF14080C260
00007ff1409ceb74  jmp 0x00007FF1409CE75F
00007ff1409ceb79  call 0x00007FF1407FF540
00007ff1409ceb7e  jmp 0x00007FF1409CE76A
00007ff1409ceb83  call 0x00007FF14080E880
00007ff1409ceb88  jmp 0x00007FF1409CE775
00007ff1409ceb8d  call 0x00007FF14080B100
00007ff1409ceb92  jmp 0x00007FF1409CE780
00007ff1409ceb97  call 0x00007FF14080D600
00007ff1409ceb9c  jmp 0x00007FF1409CE78B
00007ff1409ceba1  call 0x00007FF1407FF430
00007ff1409ceba6  jmp 0x00007FF1409CE796
00007ff1409cebab  call 0x00007FF14080E760
00007ff1409cebb0  jmp 0x00007FF1409CE7A1
00007ff1409cebb5  call 0x00007FF14080C380
00007ff1409cebba  jmp 0x00007FF1409CE7AC
00007ff1409cebbf  call 0x00007FF1407FF540
00007ff1409cebc4  jmp 0x00007FF1409CE7B7
00007ff1409cebc9  call 0x00007FF1407FF430
00007ff1409cebce  jmp 0x00007FF1409CE7C2
00007ff1409cebd3  call 0x00007FF14080D4E0
00007ff1409cebd8  jmp 0x00007FF1409CE7CD
00007ff1409cebdd  call 0x00007FF14080E880
00007ff1409cebe2  jmp 0x00007FF1409CE7E0
00007ff1409cebe7  call 0x00007FF1407FF540
00007ff1409cebec  jmp 0x00007FF1409CE7EB
00007ff1409cebf1  call 0x00007FF1407FF430
00007ff1409cebf6  jmp 0x00007FF1409CE7F6
00007ff1409cebfb  call 0x00007FF14080E760
00007ff1409cec00  jmp 0x00007FF1409CE801
00007ff1409cec05  call 0x00007FF14080D600
00007ff1409cec0a  jmp 0x00007FF1409CE81F
00007ff1409cec0f  call 0x00007FF1407FF540
00007ff1409cec14  jmp 0x00007FF1409CE82A
00007ff1409cec19  call 0x00007FF1407FF430
00007ff1409cec1e  jmp 0x00007FF1409CE835
00007ff1409cec23  call 0x00007FF14080D4E0
00007ff1409cec28  jmp 0x00007FF1409CE840
00007ff1409cec2d  call 0x00007FF14080BC20
00007ff1409cec32  jmp 0x00007FF1409CE870
00007ff1409cec37  call 0x00007FF14080A9A0
00007ff1409cec3c  jmp 0x00007FF1409CE87C
00007ff1409cec41  call 0x00007FF14080E880
00007ff1409cec46  jmp 0x00007FF1409CE887
00007ff1409cec4b  call 0x00007FF1407FF540
00007ff1409cec50  jmp 0x00007FF1409CE892
00007ff1409cec55  call 0x00007FF1407FF430
00007ff1409cec5a  jmp 0x00007FF1409CE89D
00007ff1409cec5f  call 0x00007FF14080B720
00007ff1409cec64  jmp 0x00007FF1409CE8A7
00007ff1409cec69  call 0x00007FF14080D600
00007ff1409cec6e  jmp 0x00007FF1409CE8BF
00007ff1409cec73  call 0x00007FF1407FF540
00007ff1409cec78  jmp 0x00007FF1409CE8CA
00007ff1409cec7d  call 0x00007FF1407FF430
00007ff1409cec82  jmp 0x00007FF1409CE8D5
00007ff1409cec87  call 0x00007FF1408B4CB0
00007ff1409cec8c  jmp 0x00007FF1409CE8E5
00007ff1409cec91  call 0x00007FF14080E760
00007ff1409cec96  jmp 0x00007FF1409CE8F0
00007ff1409cec9b  call 0x00007FF14080D4E0
00007ff1409ceca0  jmp 0x00007FF1409CE8FB
00007ff1409ceca5  call 0x00007FF1407FF540
00007ff1409cecaa  jmp 0x00007FF1409CE908
00007ff1409cecaf  call 0x00007FF14080BC20
00007ff1409cecb4  jmp 0x00007FF1409CE930
00007ff1409cecb9  call 0x00007FF14080A9A0
00007ff1409cecbe  jmp 0x00007FF1409CE93C
00007ff1409cecc3  call 0x00007FF14080E880
00007ff1409cecc8  jmp 0x00007FF1409CE949
00007ff1409ceccd  call 0x00007FF14080D600
00007ff1409cecd2  jmp 0x00007FF1409CE956
00007ff1409cecd7  call 0x00007FF1407FF430
00007ff1409cecdc  jmp 0x00007FF1409CE961
00007ff1409cece1  call 0x00007FF14080E760
00007ff1409cece6  jmp 0x00007FF1409CE96C
00007ff1409ceceb  call 0x00007FF14080BC20
00007ff1409cecf0  jmp 0x00007FF1409CE99C
00007ff1409cecf5  call 0x00007FF14080A9A0
00007ff1409cecfa  jmp 0x00007FF1409CE9A8
00007ff1409cecff  call 0x00007FF14080BC20
00007ff1409ced04  jmp 0x00007FF1409CE9D0
00007ff1409ced09  call 0x00007FF14080A9A0
00007ff1409ced0e  jmp 0x00007FF1409CE9DC
00007ff1409ced13  call 0x00007FF1407FF540
00007ff1409ced18  jmp 0x00007FF1409CE9E9
00007ff1409ced1d  call 0x00007FF14080E880
00007ff1409ced22  jmp 0x00007FF1409CE9F6
00007ff1409ced27  call 0x00007FF1407FF430
00007ff1409ced2c  jmp 0x00007FF1409CEA01
00007ff1409ced31  call 0x00007FF14080E760
00007ff1409ced36  jmp 0x00007FF1409CEA0C
00007ff1409ced3b  call 0x00007FF14080BC20
00007ff1409ced40  jmp 0x00007FF1409CEA36
00007ff1409ced45  call 0x00007FF14080A9A0
00007ff1409ced4a  jmp 0x00007FF1409CEA42
00007ff1409ced4f  call 0x00007FF14080BAE0
00007ff1409ced54  jmp 0x00007FF1409CEA52
00007ff1409ced59  call 0x00007FF1407FF540
00007ff1409ced5e  jmp 0x00007FF1409CEA5F
00007ff1409ced63  call 0x00007FF14080E880
00007ff1409ced68  jmp 0x00007FF1409CEA6C
00007ff1409ced6d  int3
00007ff1409ced6e  nop
00007ff1409ced70  mov rax, [r15]
00007ff1409ced73  lea r14, [rax+0x20]
00007ff1409ced77  mov r12, [r13+r14*1]
00007ff1409ced7c  mov r14, [r15+0x10]
00007ff1409ced80  lea r11, [r12+r14*1]
00007ff1409ced84  mov [r15+0x40], r11
00007ff1409ced88  lea r12, [rax+0x20]
00007ff1409ced8c  mov [r13+r12*1], r11
00007ff1409ced91  test r14, r14
00007ff1409ced94  setz r14b
00007ff1409ced98  movzx r14, r14b
00007ff1409ced9c  mov [rsp+0x414], r14b
00007ff1409ceda4  cmp byte ptr [rsp+0x414], 0x00
00007ff1409cedac  jz 0x00007FF1409CEDDE
00007ff1409cedae  cmp dword ptr [r15+0x318], 0x00
00007ff1409cedb6  mov eax, 0x4109A0
00007ff1409cedbb  mov [r15+0x100], rax
00007ff1409cedc2  jz 0x00007FF1407FE0A0
00007ff1409cedc8  nop [rax+rax*1], eax
00007ff1409cedcd  mov eax, 0x4109A0
00007ff1409cedd2  mov [r15+0x100], rax
00007ff1409cedd9  jmp 0x00007FF1407FE110
00007ff1409cedde  cmp dword ptr [r15+0x318], 0x00
00007ff1409cede6  jz 0x00007FF1409CEE30
00007ff1409cedec  nop [rax+rax*1], ax
00007ff1409cedf5  nop [rax+rax*1], eax
00007ff1409cedfd  mov eax, 0x410738
00007ff1409cee02  mov [r15+0x100], rax
00007ff1409cee09  jmp 0x00007FF1407FE110
00007ff1409cee0e  int3
00007ff1409cee0f  call 0x00007FF1408E27E0
00007ff1409cee14  jmp 0x00007FF1409CED7C
00007ff1409cee19  call 0x00007FF1408C0860
00007ff1409cee1e  jmp 0x00007FF1409CED91
00007ff1409cee23  int3
00007ff1409cee24  nop [rax+rax*1], ax
00007ff1409cee2d  nop [rax], eax
00007ff1409cee30  mov rax, [r15+0xF8]
00007ff1409cee37  lea r14, [rax-0x150]
00007ff1409cee3e  mov [r15+0xF8], r14
00007ff1409cee45  mov rax, [r15]
00007ff1409cee48  lea r12, [rax+0x68]
00007ff1409cee4c  mov r11, [r13+r12*1]
00007ff1409cee51  mov [r15+0x88], r11
00007ff1409cee58  lea r12, [rax+0x28]
00007ff1409cee5c  mov [r15+0x40], r12
00007ff1409cee60  mov [r15+0x48], r14
00007ff1409cee64  mov qword ptr [r15+0x50], 0x420B90
00007ff1409cee6c  lea rax, [r14+0x100]
00007ff1409cee73  mov r12, [r15+0xE8]
00007ff1409cee7a  mov r11, [r15+0xD8]
00007ff1409cee81  mov [r13+rax*1], r12
00007ff1409cee86  lea rax, [r14+0x108]
00007ff1409cee8d  mov [r13+rax*1], r11
00007ff1409cee92  lea rax, [r14+0x110]
00007ff1409cee99  mov r12, [r15+0xD0]
00007ff1409ceea0  mov r11, [r15+0xC8]
00007ff1409ceea7  mov [r13+rax*1], r12
00007ff1409ceeac  lea rax, [r14+0x118]
00007ff1409ceeb3  mov [r13+rax*1], r11
00007ff1409ceeb8  lea rax, [r14+0x120]
00007ff1409ceebf  mov r12, [r15+0xC0]
00007ff1409ceec6  mov r11, [r15+0xB8]
00007ff1409ceecd  mov [r13+rax*1], r12
00007ff1409ceed2  lea rax, [r14+0x128]
00007ff1409ceed9  mov [r13+rax*1], r11
00007ff1409ceede  lea rax, [r14+0x130]
00007ff1409ceee5  mov r12, [r15+0xB0]
00007ff1409ceeec  mov r11, [r15+0xA8]
00007ff1409ceef3  mov [r13+rax*1], r12
00007ff1409ceef8  lea rax, [r14+0x138]
00007ff1409ceeff  mov [r13+rax*1], r11
00007ff1409cef04  lea rax, [r14+0x140]
00007ff1409cef0b  mov r12, [r15+0xA0]
00007ff1409cef12  mov r11, [r15+0x98]
00007ff1409cef19  mov [r13+rax*1], r12
00007ff1409cef1e  lea rax, [r14+0x148]
00007ff1409cef25  mov [r13+rax*1], r11
00007ff1409cef2a  cmp dword ptr [r15+0x318], 0x00
00007ff1409cef32  jz 0x00007FF1409CEFD0
00007ff1409cef38  nop [rax+rax*1], ax
00007ff1409cef41  nop [rax+rax*1], eax
00007ff1409cef49  mov eax, 0x410770
00007ff1409cef4e  mov [r15+0x100], rax
00007ff1409cef55  jmp 0x00007FF1407FE110
00007ff1409cef5a  int3
00007ff1409cef5b  call 0x00007FF1408C0370
00007ff1409cef60  jmp 0x00007FF1409CEE51
00007ff1409cef65  call 0x00007FF14080BC20
00007ff1409cef6a  jmp 0x00007FF1409CEE86
00007ff1409cef6f  call 0x00007FF14080A9A0
00007ff1409cef74  jmp 0x00007FF1409CEE92
00007ff1409cef79  call 0x00007FF14080BC20
00007ff1409cef7e  jmp 0x00007FF1409CEEAC
00007ff1409cef83  call 0x00007FF14080A9A0
00007ff1409cef88  jmp 0x00007FF1409CEEB8
00007ff1409cef8d  call 0x00007FF14080BC20
00007ff1409cef92  jmp 0x00007FF1409CEED2
00007ff1409cef97  call 0x00007FF14080A9A0
00007ff1409cef9c  jmp 0x00007FF1409CEEDE
00007ff1409cefa1  call 0x00007FF14080BC20
00007ff1409cefa6  jmp 0x00007FF1409CEEF8
00007ff1409cefab  call 0x00007FF14080A9A0
00007ff1409cefb0  jmp 0x00007FF1409CEF04
00007ff1409cefb5  call 0x00007FF14080BC20
00007ff1409cefba  jmp 0x00007FF1409CEF1E
00007ff1409cefbf  call 0x00007FF14080A9A0
00007ff1409cefc4  jmp 0x00007FF1409CEF2A
00007ff1409cefc9  int3
00007ff1409cefca  nop [rax+rax*1], ax
00007ff1409cefd0  mov rax, [r15+0x08]
00007ff1409cefd4  movzx r14d, byte ptr [r13+rax*1]
00007ff1409cefda  movzx r14d, r14b
00007ff1409cefde  mov [rsp+0x10], r14d
00007ff1409cefe3  mov r14d, r14d
00007ff1409cefe6  mov [r15+0x58], r14
00007ff1409cefea  lea r14, [rax+0x01]
00007ff1409cefee  mov [r15+0x08], r14
00007ff1409ceff2  mov rax, [r15+0x88]
00007ff1409ceff9  lea r14, [rax+0x01]
00007ff1409ceffd  mov r12, [r15]
00007ff1409cf000  lea r11, [r12+0x68]
00007ff1409cf005  mov [r13+r11*1], r14
00007ff1409cf00a  lea r14, [r12+rax*1]
00007ff1409cf00e  mov [r15+0x60], r14
00007ff1409cf012  lea rax, [r14+0x28]
00007ff1409cf016  mov r11d, [rsp+0x10]
00007ff1409cf01b  movzx r14d, r11b
00007ff1409cf01f  mov [r13+rax*1], r14b
00007ff1409cf024  lea rax, [r12+0x68]
00007ff1409cf029  mov r14, [r13+rax*1]
00007ff1409cf02e  mov [r15+0x88], r14
00007ff1409cf035  xor eax, eax
00007ff1409cf037  mov r12d, 0x40
00007ff1409cf03d  cmp r14, r12
00007ff1409cf040  cmc
00007ff1409cf041  lahf
00007ff1409cf042  seto al
00007ff1409cf045  mov [r15+0x108], eax
00007ff1409cf04c  mov eax, [r15+0x108]
00007ff1409cf053  sahf
00007ff1409cf054  jnz 0x00007FF1409CF086
00007ff1409cf056  cmp dword ptr [r15+0x318], 0x00
00007ff1409cf05e  jz 0x00007FF1409CF170
00007ff1409cf064  nop [rax+rax*1], ax
00007ff1409cf06d  nop [rax+rax*1], eax
00007ff1409cf075  mov eax, 0x410790
00007ff1409cf07a  mov [r15+0x100], rax
00007ff1409cf081  jmp 0x00007FF1407FE110
00007ff1409cf086  cmp dword ptr [r15+0x318], 0x00
00007ff1409cf08e  jz 0x00007FF1409CF0E0
00007ff1409cf094  nop [rax+rax*1], ax
00007ff1409cf09d  nop [rax+rax*1], eax
00007ff1409cf0a5  mov eax, 0x410768
00007ff1409cf0aa  mov [r15+0x100], rax
00007ff1409cf0b1  jmp 0x00007FF1407FE110
00007ff1409cf0b6  int3
00007ff1409cf0b7  call 0x00007FF14080D860
00007ff1409cf0bc  jmp 0x00007FF1409CEFDA
00007ff1409cf0c1  call 0x00007FF1408B36E0
00007ff1409cf0c6  jmp 0x00007FF1409CF00A
00007ff1409cf0cb  call 0x00007FF14080DD60
00007ff1409cf0d0  jmp 0x00007FF1409CF024
00007ff1409cf0d5  call 0x00007FF14080DC20
00007ff1409cf0da  jmp 0x00007FF1409CF02E
00007ff1409cf0df  int3
00007ff1409cf0e0  mov rax, [r15+0x10]
00007ff1409cf0e4  lea r14, [rax-0x01]
00007ff1409cf0e8  mov [r15+0x10], r14
00007ff1409cf0ec  test r14, r14
00007ff1409cf0ef  setz r14b
00007ff1409cf0f3  movzx r14, r14b
00007ff1409cf0f7  mov [rsp+0x414], r14b
00007ff1409cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007ff1409cf107  jz 0x00007FF1409CF139
00007ff1409cf109  cmp dword ptr [r15+0x318], 0x00
00007ff1409cf111  jz 0x00007FF1409D0670
00007ff1409cf117  nop [rax+rax*1], ax
00007ff1409cf120  nop [rax+rax*1], eax
00007ff1409cf128  mov eax, 0x410988
00007ff1409cf12d  mov [r15+0x100], rax
00007ff1409cf134  jmp 0x00007FF1407FE110
00007ff1409cf139  cmp dword ptr [r15+0x318], 0x00
00007ff1409cf141  jz 0x00007FF1409CEFD0
00007ff1409cf147  nop [rax+rax*1], ax
00007ff1409cf150  nop [rax+rax*1], eax
00007ff1409cf158  mov eax, 0x410770
00007ff1409cf15d  mov [r15+0x100], rax
00007ff1409cf164  jmp 0x00007FF1407FE110
00007ff1409cf169  int3
00007ff1409cf16a  int3
00007ff1409cf16b  nop [rax+rax*1], eax
00007ff1409cf170  mov rax, [r15+0x40]
00007ff1409cf174  movzx r14d, byte ptr [r13+rax*1]
00007ff1409cf17a  movaps xmm1, [r15+0x110]
00007ff1409cf182  pinsrb xmm1, r14d, 0x00
00007ff1409cf189  lea r14, [rax+0x01]
00007ff1409cf18d  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf193  movaps xmm15, [r15+0x120]
00007ff1409cf19b  pinsrb xmm15, r12d, 0x00
00007ff1409cf1a2  lea r14, [rax+0x02]
00007ff1409cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf1ac  movaps xmm14, [r15+0x130]
00007ff1409cf1b4  pinsrb xmm14, r12d, 0x00
00007ff1409cf1bb  lea r14, [rax+0x03]
00007ff1409cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf1c5  movaps xmm13, [r15+0x140]
00007ff1409cf1cd  pinsrb xmm13, r12d, 0x00
00007ff1409cf1d4  lea r14, [rax+0x04]
00007ff1409cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf1de  pinsrb xmm1, r12d, 0x01
00007ff1409cf1e5  lea r14, [rax+0x05]
00007ff1409cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf1ef  pinsrb xmm15, r12d, 0x01
00007ff1409cf1f6  lea r14, [rax+0x06]
00007ff1409cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf200  pinsrb xmm14, r12d, 0x01
00007ff1409cf207  lea r14, [rax+0x07]
00007ff1409cf20b  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf211  pinsrb xmm13, r12d, 0x01
00007ff1409cf218  lea r14, [rax+0x08]
00007ff1409cf21c  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf222  pinsrb xmm1, r12d, 0x02
00007ff1409cf229  lea r14, [rax+0x09]
00007ff1409cf22d  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf233  pinsrb xmm15, r12d, 0x02
00007ff1409cf23a  lea r14, [rax+0x0A]
00007ff1409cf23e  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf244  pinsrb xmm14, r12d, 0x02
00007ff1409cf24b  lea r14, [rax+0x0B]
00007ff1409cf24f  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf255  pinsrb xmm13, r12d, 0x02
00007ff1409cf25c  lea r14, [rax+0x0C]
00007ff1409cf260  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf266  pinsrb xmm1, r12d, 0x03
00007ff1409cf26d  lea r14, [rax+0x0D]
00007ff1409cf271  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf277  pinsrb xmm15, r12d, 0x03
00007ff1409cf27e  lea r14, [rax+0x0E]
00007ff1409cf282  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf288  pinsrb xmm14, r12d, 0x03
00007ff1409cf28f  lea r14, [rax+0x0F]
00007ff1409cf293  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf299  pinsrb xmm13, r12d, 0x03
00007ff1409cf2a0  lea r14, [rax+0x10]
00007ff1409cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf2aa  pinsrb xmm1, r12d, 0x04
00007ff1409cf2b1  lea r14, [rax+0x11]
00007ff1409cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf2bb  pinsrb xmm15, r12d, 0x04
00007ff1409cf2c2  lea r14, [rax+0x12]
00007ff1409cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf2cc  pinsrb xmm14, r12d, 0x04
00007ff1409cf2d3  lea r14, [rax+0x13]
00007ff1409cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf2dd  pinsrb xmm13, r12d, 0x04
00007ff1409cf2e4  lea r14, [rax+0x14]
00007ff1409cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf2ee  pinsrb xmm1, r12d, 0x05
00007ff1409cf2f5  lea r14, [rax+0x15]
00007ff1409cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf2ff  pinsrb xmm15, r12d, 0x05
00007ff1409cf306  lea r14, [rax+0x16]
00007ff1409cf30a  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf310  pinsrb xmm14, r12d, 0x05
00007ff1409cf317  lea r14, [rax+0x17]
00007ff1409cf31b  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf321  pinsrb xmm13, r12d, 0x05
00007ff1409cf328  lea r14, [rax+0x18]
00007ff1409cf32c  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf332  pinsrb xmm1, r12d, 0x06
00007ff1409cf339  lea r14, [rax+0x19]
00007ff1409cf33d  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf343  pinsrb xmm15, r12d, 0x06
00007ff1409cf34a  lea r14, [rax+0x1A]
00007ff1409cf34e  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf354  pinsrb xmm14, r12d, 0x06
00007ff1409cf35b  lea r14, [rax+0x1B]
00007ff1409cf35f  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf365  pinsrb xmm13, r12d, 0x06
00007ff1409cf36c  lea r14, [rax+0x1C]
00007ff1409cf370  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf376  pinsrb xmm1, r12d, 0x07
00007ff1409cf37d  lea r14, [rax+0x1D]
00007ff1409cf381  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf387  pinsrb xmm15, r12d, 0x07
00007ff1409cf38e  lea r14, [rax+0x1E]
00007ff1409cf392  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf398  pinsrb xmm14, r12d, 0x07
00007ff1409cf39f  lea r14, [rax+0x1F]
00007ff1409cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf3a9  pinsrb xmm13, r12d, 0x07
00007ff1409cf3b0  lea r14, [rax+0x20]
00007ff1409cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf3ba  pinsrb xmm1, r12d, 0x08
00007ff1409cf3c1  lea r14, [rax+0x21]
00007ff1409cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf3cb  pinsrb xmm15, r12d, 0x08
00007ff1409cf3d2  lea r14, [rax+0x22]
00007ff1409cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf3dc  pinsrb xmm14, r12d, 0x08
00007ff1409cf3e3  lea r14, [rax+0x23]
00007ff1409cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf3ed  pinsrb xmm13, r12d, 0x08
00007ff1409cf3f4  lea r14, [rax+0x24]
00007ff1409cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf3fe  pinsrb xmm1, r12d, 0x09
00007ff1409cf405  lea r14, [rax+0x25]
00007ff1409cf409  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf40f  pinsrb xmm15, r12d, 0x09
00007ff1409cf416  lea r14, [rax+0x26]
00007ff1409cf41a  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf420  pinsrb xmm14, r12d, 0x09
00007ff1409cf427  lea r14, [rax+0x27]
00007ff1409cf42b  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf431  pinsrb xmm13, r12d, 0x09
00007ff1409cf438  lea r14, [rax+0x28]
00007ff1409cf43c  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf442  pinsrb xmm1, r12d, 0x0A
00007ff1409cf449  lea r14, [rax+0x29]
00007ff1409cf44d  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf453  pinsrb xmm15, r12d, 0x0A
00007ff1409cf45a  lea r14, [rax+0x2A]
00007ff1409cf45e  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf464  pinsrb xmm14, r12d, 0x0A
00007ff1409cf46b  lea r14, [rax+0x2B]
00007ff1409cf46f  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf475  pinsrb xmm13, r12d, 0x0A
00007ff1409cf47c  lea r14, [rax+0x2C]
00007ff1409cf480  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf486  pinsrb xmm1, r12d, 0x0B
00007ff1409cf48d  lea r14, [rax+0x2D]
00007ff1409cf491  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf497  pinsrb xmm15, r12d, 0x0B
00007ff1409cf49e  lea r14, [rax+0x2E]
00007ff1409cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf4a8  pinsrb xmm14, r12d, 0x0B
00007ff1409cf4af  lea r14, [rax+0x2F]
00007ff1409cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf4b9  pinsrb xmm13, r12d, 0x0B
00007ff1409cf4c0  lea r14, [rax+0x30]
00007ff1409cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf4ca  pinsrb xmm1, r12d, 0x0C
00007ff1409cf4d1  lea r14, [rax+0x31]
00007ff1409cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf4db  pinsrb xmm15, r12d, 0x0C
00007ff1409cf4e2  lea r14, [rax+0x32]
00007ff1409cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf4ec  pinsrb xmm14, r12d, 0x0C
00007ff1409cf4f3  lea r14, [rax+0x33]
00007ff1409cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf4fd  pinsrb xmm13, r12d, 0x0C
00007ff1409cf504  lea r14, [rax+0x34]
00007ff1409cf508  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf50e  pinsrb xmm1, r12d, 0x0D
00007ff1409cf515  lea r14, [rax+0x35]
00007ff1409cf519  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf51f  pinsrb xmm15, r12d, 0x0D
00007ff1409cf526  lea r14, [rax+0x36]
00007ff1409cf52a  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf530  pinsrb xmm14, r12d, 0x0D
00007ff1409cf537  lea r14, [rax+0x37]
00007ff1409cf53b  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf541  pinsrb xmm13, r12d, 0x0D
00007ff1409cf548  lea r14, [rax+0x38]
00007ff1409cf54c  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf552  pinsrb xmm1, r12d, 0x0E
00007ff1409cf559  lea r14, [rax+0x39]
00007ff1409cf55d  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf563  pinsrb xmm15, r12d, 0x0E
00007ff1409cf56a  lea r14, [rax+0x3A]
00007ff1409cf56e  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf574  pinsrb xmm14, r12d, 0x0E
00007ff1409cf57b  lea r14, [rax+0x3B]
00007ff1409cf57f  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf585  pinsrb xmm13, r12d, 0x0E
00007ff1409cf58c  lea r14, [rax+0x3C]
00007ff1409cf590  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf596  pinsrb xmm1, r12d, 0x0F
00007ff1409cf59d  movaps [r15+0x110], xmm1
00007ff1409cf5a5  lea r14, [rax+0x3D]
00007ff1409cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf5af  pinsrb xmm15, r12d, 0x0F
00007ff1409cf5b6  movaps [r15+0x120], xmm15
00007ff1409cf5be  lea r14, [rax+0x3E]
00007ff1409cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007ff1409cf5c8  pinsrb xmm14, r12d, 0x0F
00007ff1409cf5cf  movaps [r15+0x130], xmm14
00007ff1409cf5d7  lea r14, [rax+0x3F]
00007ff1409cf5db  movzx eax, byte ptr [r13+r14*1]
00007ff1409cf5e1  pinsrb xmm13, eax, 0x0F
00007ff1409cf5e8  movaps [r15+0x140], xmm13
00007ff1409cf5f0  movq xmm1, qword ptr [r15+0x120]
00007ff1409cf5f9  pmovzxbw xmm1, xmm1
00007ff1409cf5fe  psllw xmm1, 0x00
00007ff1409cf603  movaps [r15+0x150], xmm1
00007ff1409cf60b  movq xmm1, qword ptr [r15+0x130]
00007ff1409cf614  pmovzxbw xmm1, xmm1
00007ff1409cf619  psllw xmm1, 0x00
00007ff1409cf61e  movaps [r15+0x160], xmm1
00007ff1409cf626  movq xmm1, qword ptr [r15+0x110]
00007ff1409cf62f  pmovzxbw xmm1, xmm1
00007ff1409cf634  psllw xmm1, 0x00
00007ff1409cf639  movaps [r15+0x170], xmm1
00007ff1409cf641  movaps xmm15, [r15+0x110]
00007ff1409cf649  pextrq rax, xmm15, 0x01
00007ff1409cf650  movq xmm15, rax
00007ff1409cf655  pmovzxbw xmm15, xmm15
00007ff1409cf65b  psllw xmm15, 0x00
00007ff1409cf661  movaps [r15+0x180], xmm15
00007ff1409cf669  movaps xmm14, [r15+0x120]
00007ff1409cf671  pextrq rax, xmm14, 0x01
00007ff1409cf678  movq xmm14, rax
00007ff1409cf67d  pmovzxbw xmm14, xmm14
00007ff1409cf683  psllw xmm14, 0x00
00007ff1409cf689  movaps [r15+0x210], xmm14
00007ff1409cf691  movaps xmm13, [r15+0x130]
00007ff1409cf699  pextrq rax, xmm13, 0x01
00007ff1409cf6a0  movq xmm13, rax
00007ff1409cf6a5  pmovzxbw xmm13, xmm13
00007ff1409cf6ab  psllw xmm13, 0x00
00007ff1409cf6b1  movaps [r15+0x220], xmm13
00007ff1409cf6b9  movq xmm12, qword ptr [r15+0x140]
00007ff1409cf6c2  pmovzxbw xmm12, xmm12
00007ff1409cf6c8  psllw xmm12, 0x00
00007ff1409cf6ce  movaps [r15+0x250], xmm12
00007ff1409cf6d6  movaps xmm12, [r15+0x140]
00007ff1409cf6de  pextrq rax, xmm12, 0x01
00007ff1409cf6e5  movq xmm12, rax
00007ff1409cf6ea  pmovzxbw xmm12, xmm12
00007ff1409cf6f0  psllw xmm12, 0x00
00007ff1409cf6f6  movaps [r15+0x110], xmm12
00007ff1409cf6fe  movq xmm11, qword ptr [r15+0x150]
00007ff1409cf707  pmovzxwd xmm11, xmm11
00007ff1409cf70d  pslld xmm11, 0x10
00007ff1409cf713  movq xmm10, qword ptr [r15+0x160]
00007ff1409cf71c  pmovzxwd xmm10, xmm10
00007ff1409cf722  pslld xmm10, 0x08
00007ff1409cf728  pextrq rax, xmm1, 0x01
00007ff1409cf72f  movq xmm1, rax
00007ff1409cf734  pmovzxwd xmm1, xmm1
00007ff1409cf739  pslld xmm1, 0x00
00007ff1409cf73e  movaps [r15+0x260], xmm1
00007ff1409cf746  pextrq rax, xmm15, 0x01
00007ff1409cf74d  movq xmm15, rax
00007ff1409cf752  pmovzxwd xmm15, xmm15
00007ff1409cf758  pslld xmm15, 0x00
00007ff1409cf75e  movaps [r15+0x270], xmm15
00007ff1409cf766  movq xmm9, qword ptr [r15+0x170]
00007ff1409cf76f  pmovzxwd xmm9, xmm9
00007ff1409cf775  pslld xmm9, 0x00
00007ff1409cf77b  pextrq rax, xmm14, 0x01
00007ff1409cf782  movq xmm14, rax
00007ff1409cf787  pmovzxwd xmm14, xmm14
00007ff1409cf78d  pslld xmm14, 0x10
00007ff1409cf793  movaps [r15+0x280], xmm14
00007ff1409cf79b  movq xmm8, qword ptr [r15+0x180]
00007ff1409cf7a4  pmovzxwd xmm8, xmm8
00007ff1409cf7aa  pslld xmm8, 0x00
00007ff1409cf7b0  movq xmm7, qword ptr [r15+0x210]
00007ff1409cf7b9  pmovzxwd xmm7, xmm7
00007ff1409cf7be  pslld xmm7, 0x10
00007ff1409cf7c3  movaps xmm6, [r15+0x150]
00007ff1409cf7cb  pextrq rax, xmm6, 0x01
00007ff1409cf7d2  movq xmm6, rax
00007ff1409cf7d7  pmovzxwd xmm6, xmm6
00007ff1409cf7dc  pslld xmm6, 0x10
00007ff1409cf7e1  por xmm11, xmm10
00007ff1409cf7e6  movaps [r15+0x230], xmm11
00007ff1409cf7ee  pextrq rax, xmm13, 0x01
00007ff1409cf7f5  movq xmm13, rax
00007ff1409cf7fa  pmovzxwd xmm13, xmm13
00007ff1409cf800  pslld xmm13, 0x08
00007ff1409cf806  movaps [r15+0x240], xmm13
00007ff1409cf80e  movq xmm10, qword ptr [r15+0x220]
00007ff1409cf817  pmovzxwd xmm10, xmm10
00007ff1409cf81d  pslld xmm10, 0x08
00007ff1409cf823  movaps xmm5, [r15+0x160]
00007ff1409cf82b  pextrq rax, xmm5, 0x01
00007ff1409cf832  movq xmm5, rax
00007ff1409cf837  pmovzxwd xmm5, xmm5
00007ff1409cf83c  pslld xmm5, 0x08
00007ff1409cf841  pslld xmm9, 0x18
00007ff1409cf847  pslld xmm15, 0x18
00007ff1409cf84d  pslld xmm8, 0x18
00007ff1409cf853  movq xmm4, qword ptr [r15+0x250]
00007ff1409cf85c  pmovzxwd xmm4, xmm4
00007ff1409cf861  pslld xmm4, 0x00
00007ff1409cf866  por xmm14, xmm13
00007ff1409cf86b  por xmm7, xmm10
00007ff1409cf870  movaps [r15+0x210], xmm7
00007ff1409cf878  pslld xmm1, 0x18
00007ff1409cf87d  movaps [r15+0x220], xmm1
00007ff1409cf885  por xmm6, xmm5
00007ff1409cf889  por xmm11, xmm9
00007ff1409cf88e  movaps [r15+0x160], xmm11
00007ff1409cf896  pextrq rax, xmm12, 0x01
00007ff1409cf89d  movq xmm13, rax
00007ff1409cf8a2  pmovzxwd xmm13, xmm13
00007ff1409cf8a8  pslld xmm13, 0x00
00007ff1409cf8ae  movaps [r15+0x170], xmm13
00007ff1409cf8b6  movq xmm12, qword ptr [r15+0x110]
00007ff1409cf8bf  pmovzxwd xmm12, xmm12
00007ff1409cf8c5  pslld xmm12, 0x00
00007ff1409cf8cb  por xmm14, xmm15
00007ff1409cf8d0  por xmm7, xmm8
00007ff1409cf8d5  movaps xmm15, [r15+0x250]
00007ff1409cf8dd  pextrq rax, xmm15, 0x01
00007ff1409cf8e4  movq xmm15, rax
00007ff1409cf8e9  pmovzxwd xmm15, xmm15
00007ff1409cf8ef  pslld xmm15, 0x00
00007ff1409cf8f5  movaps [r15+0x180], xmm15
00007ff1409cf8fd  por xmm6, xmm1
00007ff1409cf901  movaps [r15+0x150], xmm6
00007ff1409cf909  por xmm11, xmm4
00007ff1409cf90e  movaps [r15+0x140], xmm11
00007ff1409cf916  por xmm7, xmm12
00007ff1409cf91b  movaps [r15+0x110], xmm7
00007ff1409cf923  por xmm14, xmm13
00007ff1409cf928  movaps [r15+0x120], xmm14
00007ff1409cf930  por xmm6, xmm15
00007ff1409cf935  movaps [r15+0x130], xmm6
00007ff1409cf93d  mov rax, [r15+0xF8]
00007ff1409cf944  lea r14, [rax+0x20]
00007ff1409cf948  movups [r13+r14*1], xmm7
00007ff1409cf94e  lea r14, [rax+0x30]
00007ff1409cf952  movups [r13+r14*1], xmm14
00007ff1409cf958  movups [r13+rax*1], xmm11
00007ff1409cf95e  lea r14, [rax+0x10]
00007ff1409cf962  movups [r13+r14*1], xmm6
00007ff1409cf968  mov r14d, [r13+rax*1]
00007ff1409cf96d  mov rax, [r15+0x48]
00007ff1409cf971  mov [r15+0x68], rax
00007ff1409cf975  mov qword ptr [r15+0x58], 0x04
00007ff1409cf97d  lea r12, [rax+0x04]
00007ff1409cf981  mov r11d, [r13+r12*1]
00007ff1409cf986  mov [rsp+0x10], r11d
00007ff1409cf98b  mov r11d, r11d
00007ff1409cf98e  mov [r15+0x70], r11
00007ff1409cf992  lea r12, [rax+0x38]
00007ff1409cf996  mov r11d, [r13+r12*1]
00007ff1409cf99b  lea r12, [rax+0x24]
00007ff1409cf99f  mov r10d, [r13+r12*1]
00007ff1409cf9a4  mov [rsp+0x20], r10d
00007ff1409cf9a9  mov r10d, r10d
00007ff1409cf9ac  mov [r15+0x90], r10
00007ff1409cf9b3  mov [rsp+0x30], rax
00007ff1409cf9b8  xor eax, eax
00007ff1409cf9ba  mov r12d, 0x04
00007ff1409cf9c0  mov r10d, 0xC0
00007ff1409cf9c6  cmp r12, r10
00007ff1409cf9c9  cmc
00007ff1409cf9ca  lahf
00007ff1409cf9cb  seto al
00007ff1409cf9ce  mov [r15+0x108], eax
00007ff1409cf9d5  mov eax, [rsp+0x10]
00007ff1409cf9d9  mov r12d, [rsp+0x10]
00007ff1409cf9de  shrd eax, r12d, 0x07
00007ff1409cf9e3  mov [rsp+0x10], r11d
00007ff1409cf9e8  mov r10d, [rsp+0x10]
00007ff1409cf9ed  shrd r11d, r10d, 0x11
00007ff1409cf9f2  mov r9d, [rsp+0x20]
00007ff1409cf9f7  lea r8d, [r9d+r14d*1]
00007ff1409cf9fc  rorx r14d, r12d, 0x12
00007ff1409cfa02  xor eax, r14d
00007ff1409cfa05  rorx r14d, r10d, 0x13
00007ff1409cfa0b  xor r11d, r14d
00007ff1409cfa0e  mov [rsp+0x10], r11d
00007ff1409cfa13  mov r11d, r11d
00007ff1409cfa16  mov [r15+0x88], r11
00007ff1409cfa1d  mov [rsp+0x20], r12d
00007ff1409cfa22  shr r12d, 0x03
00007ff1409cfa26  xor eax, r12d
00007ff1409cfa29  mov [rsp+0x40], eax
00007ff1409cfa2d  mov eax, eax
00007ff1409cfa2f  mov [r15+0x80], rax
00007ff1409cfa36  shr r10d, 0x0A
00007ff1409cfa3a  mov eax, [rsp+0x10]
00007ff1409cfa3e  xor eax, r10d
00007ff1409cfa41  mov [rsp+0x10], eax
00007ff1409cfa45  mov eax, eax
00007ff1409cfa47  mov [r15+0x78], rax
00007ff1409cfa4b  mov eax, [rsp+0x40]
00007ff1409cfa4f  lea r14d, [r8d+eax*1]
00007ff1409cfa54  mov eax, [rsp+0x10]
00007ff1409cfa58  lea r12d, [r14d+eax*1]
00007ff1409cfa5d  mov rax, [rsp+0x30]
00007ff1409cfa62  lea r14, [rax+0x40]
00007ff1409cfa66  mov [r13+r14*1], r12d
00007ff1409cfa6b  mov eax, [rsp+0x20]
00007ff1409cfa6f  mov eax, eax
00007ff1409cfa71  mov [r15+0x60], rax
00007ff1409cfa75  mov eax, [r15+0x108]
00007ff1409cfa7c  sahf
00007ff1409cfa7d  jnz 0x00007FF1409CFAAF
00007ff1409cfa7f  cmp dword ptr [r15+0x318], 0x00
00007ff1409cfa87  jz 0x00007FF1409CFF70
00007ff1409cfa8d  nop [rax+rax*1], ax
00007ff1409cfa96  nop [rax+rax*1], eax
00007ff1409cfa9e  mov eax, 0x41088C
00007ff1409cfaa3  mov [r15+0x100], rax
00007ff1409cfaaa  jmp 0x00007FF1407FE110
00007ff1409cfaaf  cmp dword ptr [r15+0x318], 0x00
00007ff1409cfab7  jz 0x00007FF1409CFDC0
00007ff1409cfabd  nop [rax+rax*1], ax
00007ff1409cfac6  nop [rax+rax*1], eax
00007ff1409cface  mov eax, 0x410844
00007ff1409cfad3  mov [r15+0x100], rax
00007ff1409cfada  jmp 0x00007FF1407FE110
00007ff1409cfadf  int3
00007ff1409cfae0  call 0x00007FF14080D860
00007ff1409cfae5  jmp 0x00007FF1409CF17A
00007ff1409cfaea  call 0x00007FF1408E2420
00007ff1409cfaef  jmp 0x00007FF1409CF193
00007ff1409cfaf4  call 0x00007FF1408E2420
00007ff1409cfaf9  jmp 0x00007FF1409CF1AC
00007ff1409cfafe  call 0x00007FF1408E2420
00007ff1409cfb03  jmp 0x00007FF1409CF1C5
00007ff1409cfb08  call 0x00007FF1408E2420
00007ff1409cfb0d  jmp 0x00007FF1409CF1DE
00007ff1409cfb12  call 0x00007FF1408E2420
00007ff1409cfb17  jmp 0x00007FF1409CF1EF
00007ff1409cfb1c  call 0x00007FF1408E2420
00007ff1409cfb21  jmp 0x00007FF1409CF200
00007ff1409cfb26  call 0x00007FF1408E2420
00007ff1409cfb2b  jmp 0x00007FF1409CF211
00007ff1409cfb30  call 0x00007FF1408E2420
00007ff1409cfb35  jmp 0x00007FF1409CF222
00007ff1409cfb3a  call 0x00007FF1408E2420
00007ff1409cfb3f  jmp 0x00007FF1409CF233
00007ff1409cfb44  call 0x00007FF1408E2420
00007ff1409cfb49  jmp 0x00007FF1409CF244
00007ff1409cfb4e  call 0x00007FF1408E2420
00007ff1409cfb53  jmp 0x00007FF1409CF255
00007ff1409cfb58  call 0x00007FF1408E2420
00007ff1409cfb5d  jmp 0x00007FF1409CF266
00007ff1409cfb62  call 0x00007FF1408E2420
00007ff1409cfb67  jmp 0x00007FF1409CF277
00007ff1409cfb6c  call 0x00007FF1408E2420
00007ff1409cfb71  jmp 0x00007FF1409CF288
00007ff1409cfb76  call 0x00007FF1408E2420
00007ff1409cfb7b  jmp 0x00007FF1409CF299
00007ff1409cfb80  call 0x00007FF1408E2420
00007ff1409cfb85  jmp 0x00007FF1409CF2AA
00007ff1409cfb8a  call 0x00007FF1408E2420
00007ff1409cfb8f  jmp 0x00007FF1409CF2BB
00007ff1409cfb94  call 0x00007FF1408E2420
00007ff1409cfb99  jmp 0x00007FF1409CF2CC
00007ff1409cfb9e  call 0x00007FF1408E2420
00007ff1409cfba3  jmp 0x00007FF1409CF2DD
00007ff1409cfba8  call 0x00007FF1408E2420
00007ff1409cfbad  jmp 0x00007FF1409CF2EE
00007ff1409cfbb2  call 0x00007FF1408E2420
00007ff1409cfbb7  jmp 0x00007FF1409CF2FF
00007ff1409cfbbc  call 0x00007FF1408E2420
00007ff1409cfbc1  jmp 0x00007FF1409CF310
00007ff1409cfbc6  call 0x00007FF1408E2420
00007ff1409cfbcb  jmp 0x00007FF1409CF321
00007ff1409cfbd0  call 0x00007FF1408E2420
00007ff1409cfbd5  jmp 0x00007FF1409CF332
00007ff1409cfbda  call 0x00007FF1408E2420
00007ff1409cfbdf  jmp 0x00007FF1409CF343
00007ff1409cfbe4  call 0x00007FF1408E2420
00007ff1409cfbe9  jmp 0x00007FF1409CF354
00007ff1409cfbee  call 0x00007FF1408E2420
00007ff1409cfbf3  jmp 0x00007FF1409CF365
00007ff1409cfbf8  call 0x00007FF1408E2420
00007ff1409cfbfd  jmp 0x00007FF1409CF376
00007ff1409cfc02  call 0x00007FF1408E2420
00007ff1409cfc07  jmp 0x00007FF1409CF387
00007ff1409cfc0c  call 0x00007FF1408E2420
00007ff1409cfc11  jmp 0x00007FF1409CF398
00007ff1409cfc16  call 0x00007FF1408E2420
00007ff1409cfc1b  jmp 0x00007FF1409CF3A9
00007ff1409cfc20  call 0x00007FF1408E2420
00007ff1409cfc25  jmp 0x00007FF1409CF3BA
00007ff1409cfc2a  call 0x00007FF1408E2420
00007ff1409cfc2f  jmp 0x00007FF1409CF3CB
00007ff1409cfc34  call 0x00007FF1408E2420
00007ff1409cfc39  jmp 0x00007FF1409CF3DC
00007ff1409cfc3e  call 0x00007FF1408E2420
00007ff1409cfc43  jmp 0x00007FF1409CF3ED
00007ff1409cfc48  call 0x00007FF1408E2420
00007ff1409cfc4d  jmp 0x00007FF1409CF3FE
00007ff1409cfc52  call 0x00007FF1408E2420
00007ff1409cfc57  jmp 0x00007FF1409CF40F
00007ff1409cfc5c  call 0x00007FF1408E2420
00007ff1409cfc61  jmp 0x00007FF1409CF420
00007ff1409cfc66  call 0x00007FF1408E2420
00007ff1409cfc6b  jmp 0x00007FF1409CF431
00007ff1409cfc70  call 0x00007FF1408E2420
00007ff1409cfc75  jmp 0x00007FF1409CF442
00007ff1409cfc7a  call 0x00007FF1408E2420
00007ff1409cfc7f  jmp 0x00007FF1409CF453
00007ff1409cfc84  call 0x00007FF1408E2420
00007ff1409cfc89  jmp 0x00007FF1409CF464
00007ff1409cfc8e  call 0x00007FF1408E2420
00007ff1409cfc93  jmp 0x00007FF1409CF475
00007ff1409cfc98  call 0x00007FF1408E2420
00007ff1409cfc9d  jmp 0x00007FF1409CF486
00007ff1409cfca2  call 0x00007FF1408E2420
00007ff1409cfca7  jmp 0x00007FF1409CF497
00007ff1409cfcac  call 0x00007FF1408E2420
00007ff1409cfcb1  jmp 0x00007FF1409CF4A8
00007ff1409cfcb6  call 0x00007FF1408E2420
00007ff1409cfcbb  jmp 0x00007FF1409CF4B9
00007ff1409cfcc0  call 0x00007FF1408E2420
00007ff1409cfcc5  jmp 0x00007FF1409CF4CA
00007ff1409cfcca  call 0x00007FF1408E2420
00007ff1409cfccf  jmp 0x00007FF1409CF4DB
00007ff1409cfcd4  call 0x00007FF1408E2420
00007ff1409cfcd9  jmp 0x00007FF1409CF4EC
00007ff1409cfcde  call 0x00007FF1408E2420
00007ff1409cfce3  jmp 0x00007FF1409CF4FD
00007ff1409cfce8  call 0x00007FF1408E2420
00007ff1409cfced  jmp 0x00007FF1409CF50E
00007ff1409cfcf2  call 0x00007FF1408E2420
00007ff1409cfcf7  jmp 0x00007FF1409CF51F
00007ff1409cfcfc  call 0x00007FF1408E2420
00007ff1409cfd01  jmp 0x00007FF1409CF530
00007ff1409cfd06  call 0x00007FF1408E2420
00007ff1409cfd0b  jmp 0x00007FF1409CF541
00007ff1409cfd10  call 0x00007FF1408E2420
00007ff1409cfd15  jmp 0x00007FF1409CF552
00007ff1409cfd1a  call 0x00007FF1408E2420
00007ff1409cfd1f  jmp 0x00007FF1409CF563
00007ff1409cfd24  call 0x00007FF1408E2420
00007ff1409cfd29  jmp 0x00007FF1409CF574
00007ff1409cfd2e  call 0x00007FF1408E2420
00007ff1409cfd33  jmp 0x00007FF1409CF585
00007ff1409cfd38  call 0x00007FF1408E2420
00007ff1409cfd3d  jmp 0x00007FF1409CF596
00007ff1409cfd42  call 0x00007FF1408E2420
00007ff1409cfd47  jmp 0x00007FF1409CF5AF
00007ff1409cfd4c  call 0x00007FF1408E2420
00007ff1409cfd51  jmp 0x00007FF1409CF5C8
00007ff1409cfd56  call 0x00007FF1408D5610
00007ff1409cfd5b  jmp 0x00007FF1409CF5E1
00007ff1409cfd60  call 0x00007FF1408DC580
00007ff1409cfd65  jmp 0x00007FF1409CF94E
00007ff1409cfd6a  call 0x00007FF1408E46C0
00007ff1409cfd6f  jmp 0x00007FF1409CF958
00007ff1409cfd74  call 0x00007FF140809E90
00007ff1409cfd79  jmp 0x00007FF1409CF95E
00007ff1409cfd7e  call 0x00007FF1408DB310
00007ff1409cfd83  jmp 0x00007FF1409CF968
00007ff1409cfd88  call 0x00007FF14080DAE0
00007ff1409cfd8d  jmp 0x00007FF1409CF96D
00007ff1409cfd92  call 0x00007FF1408C0230
00007ff1409cfd97  jmp 0x00007FF1409CF986
00007ff1409cfd9c  call 0x00007FF1408C0230
00007ff1409cfda1  jmp 0x00007FF1409CF99B
00007ff1409cfda6  call 0x00007FF1408BEFC0
00007ff1409cfdab  jmp 0x00007FF1409CF9A4
00007ff1409cfdb0  call 0x00007FF1408E2BA0
00007ff1409cfdb5  jmp 0x00007FF1409CFA6B
00007ff1409cfdba  int3
00007ff1409cfdbb  nop [rax+rax*1], eax
00007ff1409cfdc0  mov rax, [r15+0x48]
00007ff1409cfdc4  mov r14, [r15+0x58]
00007ff1409cfdc8  lea r12, [rax+r14*1]
00007ff1409cfdcc  mov [r15+0x68], r12
00007ff1409cfdd0  lea rax, [r14+0x04]
00007ff1409cfdd4  mov [r15+0x58], rax
00007ff1409cfdd8  lea r14, [r12+0x04]
00007ff1409cfddd  mov r11d, [r13+r14*1]
00007ff1409cfde2  mov [rsp+0x10], r11d
00007ff1409cfde7  mov r11d, r11d
00007ff1409cfdea  mov [r15+0x70], r11
00007ff1409cfdee  lea r14, [r12+0x38]
00007ff1409cfdf3  mov r11d, [r13+r14*1]
00007ff1409cfdf8  lea r14, [r12+0x24]
00007ff1409cfdfd  mov r10d, [r13+r14*1]
00007ff1409cfe02  mov [rsp+0x20], r10d
00007ff1409cfe07  mov r10d, r10d
00007ff1409cfe0a  mov [r15+0x90], r10
00007ff1409cfe11  mov [rsp+0x30], rax
00007ff1409cfe16  xor eax, eax
00007ff1409cfe18  mov r14, [rsp+0x30]
00007ff1409cfe1d  mov r10d, 0xC0
00007ff1409cfe23  cmp r14, r10
00007ff1409cfe26  cmc
00007ff1409cfe27  lahf
00007ff1409cfe28  seto al
00007ff1409cfe2b  mov [r15+0x108], eax
00007ff1409cfe32  mov eax, [rsp+0x10]
00007ff1409cfe36  mov r14d, [rsp+0x10]
00007ff1409cfe3b  shrd eax, r14d, 0x07
00007ff1409cfe40  mov [rsp+0x10], r11d
00007ff1409cfe45  mov r10d, [rsp+0x10]
00007ff1409cfe4a  shrd r11d, r10d, 0x11
00007ff1409cfe4f  mov r9d, [r15+0x60]
00007ff1409cfe53  mov r8d, [rsp+0x20]
00007ff1409cfe58  lea ebp, [r8d+r9d*1]
00007ff1409cfe5d  rorx r9d, r14d, 0x12
00007ff1409cfe63  xor eax, r9d
00007ff1409cfe66  rorx r9d, r10d, 0x13
00007ff1409cfe6c  xor r11d, r9d
00007ff1409cfe6f  mov [rsp+0x10], r11d
00007ff1409cfe74  mov r11d, r11d
00007ff1409cfe77  mov [r15+0x88], r11
00007ff1409cfe7e  mov [rsp+0x20], r14d
00007ff1409cfe83  shr r14d, 0x03
00007ff1409cfe87  xor eax, r14d
00007ff1409cfe8a  mov [rsp+0x30], eax
00007ff1409cfe8e  mov eax, eax
00007ff1409cfe90  mov [r15+0x80], rax
00007ff1409cfe97  shr r10d, 0x0A
00007ff1409cfe9b  mov eax, [rsp+0x10]
00007ff1409cfe9f  xor eax, r10d
00007ff1409cfea2  mov [rsp+0x10], eax
00007ff1409cfea6  mov eax, eax
00007ff1409cfea8  mov [r15+0x78], rax
00007ff1409cfeac  mov eax, [rsp+0x30]
00007ff1409cfeb0  lea r14d, [ebp+eax*1]
00007ff1409cfeb6  mov eax, [rsp+0x10]
00007ff1409cfeba  lea r11d, [r14d+eax*1]
00007ff1409cfebf  lea rax, [r12+0x40]
00007ff1409cfec4  mov [r13+rax*1], r11d
00007ff1409cfec9  mov eax, [rsp+0x20]
00007ff1409cfecd  mov eax, eax
00007ff1409cfecf  mov [r15+0x60], rax
00007ff1409cfed3  mov eax, [r15+0x108]
00007ff1409cfeda  sahf
00007ff1409cfedb  jnz 0x00007FF1409CFF0D
00007ff1409cfedd  cmp dword ptr [r15+0x318], 0x00
00007ff1409cfee5  jz 0x00007FF1409CFF70
00007ff1409cfeeb  nop [rax+rax*1], ax
00007ff1409cfef4  nop [rax+rax*1], eax
00007ff1409cfefc  mov eax, 0x41088C
00007ff1409cff01  mov [r15+0x100], rax
00007ff1409cff08  jmp 0x00007FF1407FE110
00007ff1409cff0d  cmp dword ptr [r15+0x318], 0x00
00007ff1409cff15  jz 0x00007FF1409CFDC0
00007ff1409cff1b  nop [rax+rax*1], ax
00007ff1409cff24  nop [rax+rax*1], eax
00007ff1409cff2c  mov eax, 0x410844
00007ff1409cff31  mov [r15+0x100], rax
00007ff1409cff38  jmp 0x00007FF1407FE110
00007ff1409cff3d  int3
00007ff1409cff3e  call 0x00007FF1408E1430
00007ff1409cff43  jmp 0x00007FF1409CFDE2
00007ff1409cff48  call 0x00007FF1408E1430
00007ff1409cff4d  jmp 0x00007FF1409CFDF8
00007ff1409cff52  call 0x00007FF1408E01C0
00007ff1409cff57  jmp 0x00007FF1409CFE02
00007ff1409cff5c  call 0x00007FF14080A860
00007ff1409cff61  jmp 0x00007FF1409CFEC9
00007ff1409cff66  int3
00007ff1409cff67  nop [rax+rax*1], ax
00007ff1409cff70  mov rax, [r15]
00007ff1409cff73  mov r14d, [r13+rax*1]
00007ff1409cff78  lea r12, [rax+0x04]
00007ff1409cff7c  mov r11d, [r13+r12*1]
00007ff1409cff81  mov [rsp+0x10], r14d
00007ff1409cff86  mov r14d, r14d
00007ff1409cff89  mov [r15+0x78], r14
00007ff1409cff8d  mov [rsp+0x20], r11d
00007ff1409cff92  mov r11d, r11d
00007ff1409cff95  mov [r15+0x80], r11
00007ff1409cff9c  lea r14, [rax+0x08]
00007ff1409cffa0  mov r12d, [r13+r14*1]
00007ff1409cffa5  lea r14, [rax+0x0C]
00007ff1409cffa9  mov r11d, [r13+r14*1]
00007ff1409cffae  mov [rsp+0x30], r12d
00007ff1409cffb3  mov r12d, r12d
00007ff1409cffb6  mov [r15+0x70], r12
00007ff1409cffba  mov [rsp+0x40], r11d
00007ff1409cffbf  mov r11d, r11d
00007ff1409cffc2  mov [r15+0x68], r11
00007ff1409cffc6  lea r14, [rax+0x18]
00007ff1409cffca  mov r12d, [r13+r14*1]
00007ff1409cffcf  lea r14, [rax+0x1C]
00007ff1409cffd3  mov r11d, [r13+r14*1]
00007ff1409cffd8  mov [rsp+0x50], r12d
00007ff1409cffdd  mov r12d, r12d
00007ff1409cffe0  mov [r15+0x58], r12
00007ff1409cffe4  mov [rsp+0x60], r11d
00007ff1409cffe9  mov r11d, r11d
00007ff1409cffec  mov [r15+0x60], r11
00007ff1409cfff0  lea r14, [rax+0x10]
00007ff1409cfff4  mov r12d, [r13+r14*1]
00007ff1409cfff9  lea r14, [rax+0x14]
00007ff1409cfffd  mov eax, [r13+r14*1]
00007ff1409d0002  mov [rsp+0x70], r12d
00007ff1409d0007  mov r12d, r12d
00007ff1409d000a  mov [r15+0x18], r12
00007ff1409d000e  mov [rsp+0x80], eax
00007ff1409d0015  mov eax, eax
00007ff1409d0017  mov [r15+0x90], rax
00007ff1409d001e  mov eax, [rsp+0x70]
00007ff1409d0022  mov eax, eax
00007ff1409d0024  mov [r15+0x30], rax
00007ff1409d0028  mov eax, [rsp+0x50]
00007ff1409d002c  mov eax, eax
00007ff1409d002e  mov [r15+0xA0], rax
00007ff1409d0035  mov eax, [rsp+0x30]
00007ff1409d0039  mov eax, eax
00007ff1409d003b  mov [r15+0x28], rax
00007ff1409d003f  mov eax, [rsp+0x20]
00007ff1409d0043  mov eax, eax
00007ff1409d0045  mov [r15+0x98], rax
00007ff1409d004c  mov eax, [rsp+0x10]
00007ff1409d0050  mov eax, eax
00007ff1409d0052  mov [r15+0x38], rax
00007ff1409d0056  mov eax, [rsp+0x70]
00007ff1409d005a  mov r14d, [rsp+0x70]
00007ff1409d005f  shrd eax, r14d, 0x06
00007ff1409d0064  mov [rsp+0x70], r14d
00007ff1409d0069  mov r12d, [rsp+0x80]
00007ff1409d0071  and r14d, r12d
00007ff1409d0074  mov r11d, [rsp+0x10]
00007ff1409d0079  mov r10d, [rsp+0x10]
00007ff1409d007e  shrd r11d, r10d, 0x02
00007ff1409d0083  mov [rsp+0x10], r12d
00007ff1409d0088  mov r12d, r12d
00007ff1409d008b  mov [r15+0x20], r12
00007ff1409d008f  mov r12, [r15+0x50]
00007ff1409d0093  mov r9d, [r13+r12*1]
00007ff1409d0098  mov r12d, [rsp+0x50]
00007ff1409d009d  mov r8d, [rsp+0x70]
00007ff1409d00a2  andn ebp, r8d, r12d
00007ff1409d00a7  mov edi, [rsp+0x60]
00007ff1409d00ab  lea esi, [r14d+edi*1]
00007ff1409d00b0  rorx r14d, r8d, 0x0B
00007ff1409d00b6  xor eax, r14d
00007ff1409d00b9  rorx r14d, r10d, 0x0D
00007ff1409d00bf  xor r11d, r14d
00007ff1409d00c2  lea edi, [esi+ebp*1]
00007ff1409d00c6  mov r14, [r15+0x48]
00007ff1409d00ca  mov ebp, [r13+r14*1]
00007ff1409d00cf  mov r14d, [rsp+0x30]
00007ff1409d00d4  mov esi, [rsp+0x20]
00007ff1409d00d8  and r14d, esi
00007ff1409d00db  mov [rsp+0x20], r14d
00007ff1409d00e0  mov r14d, r14d
00007ff1409d00e3  mov [r15+0xD8], r14
00007ff1409d00ea  lea r14d, [edi+r9d*1]
00007ff1409d00ef  mov r9d, [rsp+0x30]
00007ff1409d00f4  xor r9d, esi
00007ff1409d00f7  rorx edi, r8d, 0x19
00007ff1409d00fd  xor eax, edi
00007ff1409d00ff  and r9d, r10d
00007ff1409d0102  rorx edi, r10d, 0x16
00007ff1409d0108  xor r11d, edi
00007ff1409d010b  mov [rsp+0x30], r11d
00007ff1409d0110  mov r11d, r11d
00007ff1409d0113  mov [r15+0xD0], r11
00007ff1409d011a  lea r11d, [r14d+ebp*1]
00007ff1409d011f  mov r10d, [rsp+0x20]
00007ff1409d0124  xor r9d, r10d
00007ff1409d0127  lea r14d, [r11d+eax*1]
00007ff1409d012c  mov qword ptr [r15+0x88], 0x04
00007ff1409d0137  mov eax, [rsp+0x30]
00007ff1409d013b  lea r11d, [r9d+eax*1]
00007ff1409d0140  mov eax, [rsp+0x40]
00007ff1409d0144  lea r10d, [r14d+eax*1]
00007ff1409d0149  mov r10d, r10d
00007ff1409d014c  mov [r15+0xB8], r10
00007ff1409d0153  xor eax, eax
00007ff1409d0155  mov r10d, 0x04
00007ff1409d015b  mov r9d, 0x100
00007ff1409d0161  cmp r10, r9
00007ff1409d0164  cmc
00007ff1409d0165  lahf
00007ff1409d0166  seto al
00007ff1409d0169  mov [r15+0x108], eax
00007ff1409d0170  lea eax, [r11d+r14d*1]
00007ff1409d0175  mov eax, eax
00007ff1409d0177  mov [r15+0xA8], rax
00007ff1409d017e  mov r12d, r12d
00007ff1409d0181  mov [r15+0xB0], r12
00007ff1409d0188  mov eax, [rsp+0x10]
00007ff1409d018c  mov eax, eax
00007ff1409d018e  mov [r15+0xC0], rax
00007ff1409d0195  mov r8d, r8d
00007ff1409d0198  mov [r15+0xC8], r8
00007ff1409d019f  mov eax, [r15+0x108]
00007ff1409d01a6  sahf
00007ff1409d01a7  jnz 0x00007FF1409D01D9
00007ff1409d01a9  cmp dword ptr [r15+0x318], 0x00
00007ff1409d01b1  jz 0x00007FF1409D04A0
00007ff1409d01b7  nop [rax+rax*1], ax
00007ff1409d01c0  nop [rax+rax*1], eax
00007ff1409d01c8  mov eax, 0x41094C
00007ff1409d01cd  mov [r15+0x100], rax
00007ff1409d01d4  jmp 0x00007FF1407FE110
00007ff1409d01d9  cmp dword ptr [r15+0x318], 0x00
00007ff1409d01e1  jz 0x00007FF1409D0270
00007ff1409d01e7  nop [rax+rax*1], ax
00007ff1409d01f0  nop [rax+rax*1], eax
00007ff1409d01f8  mov eax, 0x4108C0
00007ff1409d01fd  mov [r15+0x100], rax
00007ff1409d0204  jmp 0x00007FF1407FE110
00007ff1409d0209  int3
00007ff1409d020a  call 0x00007FF14080DAE0
00007ff1409d020f  jmp 0x00007FF1409CFF78
00007ff1409d0214  call 0x00007FF1408C0230
00007ff1409d0219  jmp 0x00007FF1409CFF81
00007ff1409d021e  call 0x00007FF1408E26A0
00007ff1409d0223  jmp 0x00007FF1409CFFA5
00007ff1409d0228  call 0x00007FF1408E1430
00007ff1409d022d  jmp 0x00007FF1409CFFAE
00007ff1409d0232  call 0x00007FF1408E26A0
00007ff1409d0237  jmp 0x00007FF1409CFFCF
00007ff1409d023c  call 0x00007FF1408E1430
00007ff1409d0241  jmp 0x00007FF1409CFFD8
00007ff1409d0246  call 0x00007FF1408E26A0
00007ff1409d024b  jmp 0x00007FF1409CFFF9
00007ff1409d0250  call 0x00007FF1408D5890
00007ff1409d0255  jmp 0x00007FF1409D0002
00007ff1409d025a  call 0x00007FF1408BDD50
00007ff1409d025f  jmp 0x00007FF1409D0098
00007ff1409d0264  call 0x00007FF1408DA580
00007ff1409d0269  jmp 0x00007FF1409D00CF
00007ff1409d026e  int3
00007ff1409d026f  nop
00007ff1409d0270  mov eax, [r15+0xB8]
00007ff1409d0277  mov [rsp+0x10], eax
00007ff1409d027b  mov eax, eax
00007ff1409d027d  mov [r15+0x30], rax
00007ff1409d0281  mov eax, [r15+0xC0]
00007ff1409d0288  mov [rsp+0x20], eax
00007ff1409d028c  mov eax, eax
00007ff1409d028e  mov [r15+0xA0], rax
00007ff1409d0295  mov eax, [r15+0x28]
00007ff1409d0299  mov r14d, [r15+0x98]
00007ff1409d02a0  mov [rsp+0x30], r14d
00007ff1409d02a5  mov r14d, r14d
00007ff1409d02a8  mov [r15+0x28], r14
00007ff1409d02ac  mov r14d, [r15+0x38]
00007ff1409d02b0  mov [rsp+0x40], r14d
00007ff1409d02b5  mov r14d, r14d
00007ff1409d02b8  mov [r15+0x98], r14
00007ff1409d02bf  mov r14d, [r15+0xA8]
00007ff1409d02c6  mov [rsp+0x50], r14d
00007ff1409d02cb  mov r14d, r14d
00007ff1409d02ce  mov [r15+0x38], r14
00007ff1409d02d2  mov r14d, [rsp+0x10]
00007ff1409d02d7  mov r12d, [rsp+0x10]
00007ff1409d02dc  shrd r14d, r12d, 0x06
00007ff1409d02e1  mov r11d, [r15+0xC8]
00007ff1409d02e8  mov [rsp+0x10], r12d
00007ff1409d02ed  and r12d, r11d
00007ff1409d02f0  mov r10d, [rsp+0x50]
00007ff1409d02f5  mov r9d, [rsp+0x50]
00007ff1409d02fa  shrd r10d, r9d, 0x02
00007ff1409d02ff  mov [rsp+0x50], r11d
00007ff1409d0304  mov r11d, r11d
00007ff1409d0307  mov [r15+0x20], r11
00007ff1409d030b  mov r11, [r15+0x88]
00007ff1409d0312  mov r8, [r15+0x50]
00007ff1409d0316  lea rbp, [r8+r11*1]
00007ff1409d031a  mov r8d, [r13+rbp*1]
00007ff1409d031f  mov ebp, [rsp+0x20]
00007ff1409d0323  mov edi, [rsp+0x10]
00007ff1409d0327  andn esi, edi, ebp
00007ff1409d032c  mov edx, [r15+0xB0]
00007ff1409d0333  lea ecx, [r12d+edx*1]
00007ff1409d0338  rorx r12d, edi, 0x0B
00007ff1409d033e  xor r14d, r12d
00007ff1409d0341  rorx r12d, r9d, 0x0D
00007ff1409d0347  xor r10d, r12d
00007ff1409d034a  lea r12d, [ecx+esi*1]
00007ff1409d034f  mov rsi, [r15+0x48]
00007ff1409d0353  lea rdx, [rsi+r11*1]
00007ff1409d0357  mov esi, [r13+rdx*1]
00007ff1409d035c  mov edx, [rsp+0x30]
00007ff1409d0360  mov ecx, [rsp+0x40]
00007ff1409d0364  and edx, ecx
00007ff1409d0366  mov [rsp+0x10], edx
00007ff1409d036a  mov edx, edx
00007ff1409d036c  mov [r15+0xD8], rdx
00007ff1409d0373  lea edx, [r12d+r8d*1]
00007ff1409d0378  mov r12d, [rsp+0x30]
00007ff1409d037d  xor r12d, ecx
00007ff1409d0380  rorx r8d, edi, 0x19
00007ff1409d0386  xor r14d, r8d
00007ff1409d0389  and r12d, r9d
00007ff1409d038c  rorx r8d, r9d, 0x16
00007ff1409d0392  xor r10d, r8d
00007ff1409d0395  mov [rsp+0x20], r10d
00007ff1409d039a  mov r10d, r10d
00007ff1409d039d  mov [r15+0xD0], r10
00007ff1409d03a4  lea r10d, [edx+esi*1]
00007ff1409d03a9  mov r9d, [rsp+0x10]
00007ff1409d03ae  xor r12d, r9d
00007ff1409d03b1  lea r9d, [r10d+r14d*1]
00007ff1409d03b6  lea r14, [r11+0x04]
00007ff1409d03ba  mov [r15+0x88], r14
00007ff1409d03c1  mov r11d, [rsp+0x20]
00007ff1409d03c6  lea r10d, [r12d+r11d*1]
00007ff1409d03cb  lea r11d, [r9d+eax*1]
00007ff1409d03d0  mov r11d, r11d
00007ff1409d03d3  mov [r15+0xB8], r11
00007ff1409d03da  xor eax, eax
00007ff1409d03dc  mov r12d, 0x100
00007ff1409d03e2  cmp r14, r12
00007ff1409d03e5  cmc
00007ff1409d03e6  lahf
00007ff1409d03e7  seto al
00007ff1409d03ea  mov [r15+0x108], eax
00007ff1409d03f1  lea eax, [r10d+r9d*1]
00007ff1409d03f6  mov eax, eax
00007ff1409d03f8  mov [r15+0xA8], rax
00007ff1409d03ff  mov ebp, ebp
00007ff1409d0401  mov [r15+0xB0], rbp
00007ff1409d0408  mov eax, [rsp+0x50]
00007ff1409d040c  mov eax, eax
00007ff1409d040e  mov [r15+0xC0], rax
00007ff1409d0415  mov edi, edi
00007ff1409d0417  mov [r15+0xC8], rdi
00007ff1409d041e  mov eax, [r15+0x108]
00007ff1409d0425  sahf
00007ff1409d0426  jnz 0x00007FF1409D0458
00007ff1409d0428  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0430  jz 0x00007FF1409D04A0
00007ff1409d0436  nop [rax+rax*1], ax
00007ff1409d043f  nop [rax+rax*1], eax
00007ff1409d0447  mov eax, 0x41094C
00007ff1409d044c  mov [r15+0x100], rax
00007ff1409d0453  jmp 0x00007FF1407FE110
00007ff1409d0458  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0460  jz 0x00007FF1409D0270
00007ff1409d0466  nop [rax+rax*1], ax
00007ff1409d046f  nop [rax+rax*1], eax
00007ff1409d0477  mov eax, 0x4108C0
00007ff1409d047c  mov [r15+0x100], rax
00007ff1409d0483  jmp 0x00007FF1407FE110
00007ff1409d0488  int3
00007ff1409d0489  call 0x00007FF140849010
00007ff1409d048e  jmp 0x00007FF1409D031F
00007ff1409d0493  call 0x00007FF140825930
00007ff1409d0498  jmp 0x00007FF1409D035C
00007ff1409d049d  int3
00007ff1409d049e  nop
00007ff1409d04a0  mov eax, [r15+0x98]
00007ff1409d04a7  mov r14d, [r15+0x70]
00007ff1409d04ab  lea r12d, [eax+r14d*1]
00007ff1409d04b0  mov eax, [r15+0x28]
00007ff1409d04b4  mov r14d, [r15+0x68]
00007ff1409d04b8  lea r11d, [eax+r14d*1]
00007ff1409d04bd  mov qword ptr [r15+0x88], 0x00
00007ff1409d04c8  mov eax, [r15+0xA8]
00007ff1409d04cf  mov r14d, [r15+0x78]
00007ff1409d04d3  lea r10d, [eax+r14d*1]
00007ff1409d04d8  mov [rsp+0x10], r10d
00007ff1409d04dd  mov r10d, r10d
00007ff1409d04e0  mov [r15+0x78], r10
00007ff1409d04e4  mov eax, [r15+0x38]
00007ff1409d04e8  mov r14d, [r15+0x80]
00007ff1409d04ef  lea r10d, [eax+r14d*1]
00007ff1409d04f4  mov [rsp+0x20], r10d
00007ff1409d04f9  mov r10d, r10d
00007ff1409d04fc  mov [r15+0x80], r10
00007ff1409d0503  mov rax, [r15]
00007ff1409d0506  lea r14, [rax+0x08]
00007ff1409d050a  mov [r13+r14*1], r12d
00007ff1409d050f  lea r14, [rax+0x0C]
00007ff1409d0513  mov [r13+r14*1], r11d
00007ff1409d0518  mov r14d, [r15+0xB8]
00007ff1409d051f  mov r12d, [r15+0x18]
00007ff1409d0523  lea r11d, [r14d+r12d*1]
00007ff1409d0528  mov [rsp+0x30], r11d
00007ff1409d052d  mov r11d, r11d
00007ff1409d0530  mov [r15+0x68], r11
00007ff1409d0534  mov r14d, [r15+0x30]
00007ff1409d0538  mov r12d, [r15+0x90]
00007ff1409d053f  lea r11d, [r14d+r12d*1]
00007ff1409d0544  mov [rsp+0x40], r11d
00007ff1409d0549  mov r11d, r11d
00007ff1409d054c  mov [r15+0x70], r11
00007ff1409d0550  mov r14d, [r15+0x20]
00007ff1409d0554  mov r12d, [r15+0x58]
00007ff1409d0558  lea r11d, [r14d+r12d*1]
00007ff1409d055d  mov [rsp+0x50], r11d
00007ff1409d0562  mov r11d, r11d
00007ff1409d0565  mov [r15+0x58], r11
00007ff1409d0569  mov r14d, [r15+0xA0]
00007ff1409d0570  mov r12d, [r15+0x60]
00007ff1409d0574  lea r11d, [r14d+r12d*1]
00007ff1409d0579  mov [rsp+0x60], r11d
00007ff1409d057e  mov r11d, r11d
00007ff1409d0581  mov [r15+0x60], r11
00007ff1409d0585  mov r14d, [rsp+0x10]
00007ff1409d058a  mov [r13+rax*1], r14d
00007ff1409d058f  lea r14, [rax+0x04]
00007ff1409d0593  mov r12d, [rsp+0x20]
00007ff1409d0598  mov [r13+r14*1], r12d
00007ff1409d059d  lea r14, [rax+0x10]
00007ff1409d05a1  mov r12d, [rsp+0x30]
00007ff1409d05a6  mov [r13+r14*1], r12d
00007ff1409d05ab  lea r14, [rax+0x14]
00007ff1409d05af  mov r12d, [rsp+0x40]
00007ff1409d05b4  mov [r13+r14*1], r12d
00007ff1409d05b9  lea r14, [rax+0x18]
00007ff1409d05bd  mov r12d, [rsp+0x50]
00007ff1409d05c2  mov [r13+r14*1], r12d
00007ff1409d05c7  lea r14, [rax+0x1C]
00007ff1409d05cb  mov r12d, [rsp+0x60]
00007ff1409d05d0  mov [r13+r14*1], r12d
00007ff1409d05d5  lea r14, [rax+0x68]
00007ff1409d05d9  xor eax, eax
00007ff1409d05db  mov [r13+r14*1], rax
00007ff1409d05e0  cmp dword ptr [r15+0x318], 0x00
00007ff1409d05e8  jz 0x00007FF1409CF0E0
00007ff1409d05ee  nop [rax+rax*1], ax
00007ff1409d05f7  nop [rax+rax*1], eax
00007ff1409d05ff  mov eax, 0x410768
00007ff1409d0604  mov [r15+0x100], rax
00007ff1409d060b  jmp 0x00007FF1407FE110
00007ff1409d0610  int3
00007ff1409d0611  call 0x00007FF1408E2BA0
00007ff1409d0616  jmp 0x00007FF1409D050F
00007ff1409d061b  call 0x00007FF1408E1920
00007ff1409d0620  jmp 0x00007FF1409D0518
00007ff1409d0625  call 0x00007FF14080DFE0
00007ff1409d062a  jmp 0x00007FF1409D058F
00007ff1409d062f  call 0x00007FF1408E2BA0
00007ff1409d0634  jmp 0x00007FF1409D059D
00007ff1409d0639  call 0x00007FF1408E2BA0
00007ff1409d063e  jmp 0x00007FF1409D05AB
00007ff1409d0643  call 0x00007FF1408E2BA0
00007ff1409d0648  jmp 0x00007FF1409D05B9
00007ff1409d064d  call 0x00007FF1408E2BA0
00007ff1409d0652  jmp 0x00007FF1409D05C7
00007ff1409d0657  call 0x00007FF1408E2BA0
00007ff1409d065c  jmp 0x00007FF1409D05D5
00007ff1409d0661  call 0x00007FF1408D5EB0
00007ff1409d0666  jmp 0x00007FF1409D05E0
00007ff1409d066b  int3
00007ff1409d066c  nop [rax], eax
00007ff1409d0670  mov rax, [r15+0xF8]
00007ff1409d0677  lea r14, [rax+0x140]
00007ff1409d067e  mov r12, [r13+r14*1]
00007ff1409d0683  lea r14, [rax+0x148]
00007ff1409d068a  mov r11, [r13+r14*1]
00007ff1409d068f  mov [r15+0xA0], r12
00007ff1409d0696  mov [r15+0x98], r11
00007ff1409d069d  lea r14, [rax+0x130]
00007ff1409d06a4  mov r12, [r13+r14*1]
00007ff1409d06a9  lea r14, [rax+0x138]
00007ff1409d06b0  mov r11, [r13+r14*1]
00007ff1409d06b5  mov [r15+0xB0], r12
00007ff1409d06bc  mov [r15+0xA8], r11
00007ff1409d06c3  lea r14, [rax+0x120]
00007ff1409d06ca  mov r12, [r13+r14*1]
00007ff1409d06cf  lea r14, [rax+0x128]
00007ff1409d06d6  mov r11, [r13+r14*1]
00007ff1409d06db  mov [r15+0xC0], r12
00007ff1409d06e2  mov [r15+0xB8], r11
00007ff1409d06e9  lea r14, [rax+0x110]
00007ff1409d06f0  mov r12, [r13+r14*1]
00007ff1409d06f5  lea r14, [rax+0x118]
00007ff1409d06fc  mov r11, [r13+r14*1]
00007ff1409d0701  mov [r15+0xD0], r12
00007ff1409d0708  mov [r15+0xC8], r11
00007ff1409d070f  lea r14, [rax+0x100]
00007ff1409d0716  mov r12, [r13+r14*1]
00007ff1409d071b  lea r14, [rax+0x108]
00007ff1409d0722  mov r11, [r13+r14*1]
00007ff1409d0727  mov [r15+0xE8], r12
00007ff1409d072e  mov [r15+0xD8], r11
00007ff1409d0735  lea r14, [rax+0x150]
00007ff1409d073c  mov [r15+0xF8], r14
00007ff1409d0743  mov rax, [r15+0xF0]
00007ff1409d074a  mov [r15+0x100], rax
00007ff1409d0751  jmp 0x00007FF1409CE5C0
00007ff1409d0756  int3
00007ff1409d0757  call 0x00007FF1408E27E0
00007ff1409d075c  jmp 0x00007FF1409D0683
00007ff1409d0761  call 0x00007FF1408E1570
00007ff1409d0766  jmp 0x00007FF1409D068F
00007ff1409d076b  call 0x00007FF1408E27E0
00007ff1409d0770  jmp 0x00007FF1409D06A9
00007ff1409d0775  call 0x00007FF1408E1570
00007ff1409d077a  jmp 0x00007FF1409D06B5
00007ff1409d077f  call 0x00007FF1408E27E0
00007ff1409d0784  jmp 0x00007FF1409D06CF
00007ff1409d0789  call 0x00007FF1408E1570
00007ff1409d078e  jmp 0x00007FF1409D06DB
00007ff1409d0793  call 0x00007FF1408E27E0
00007ff1409d0798  jmp 0x00007FF1409D06F5
00007ff1409d079d  call 0x00007FF1408E1570
00007ff1409d07a2  jmp 0x00007FF1409D0701
00007ff1409d07a7  call 0x00007FF1408E27E0
00007ff1409d07ac  jmp 0x00007FF1409D071B
00007ff1409d07b1  call 0x00007FF1408E1570
00007ff1409d07b6  jmp 0x00007FF1409D0727
00007ff1409d07bb  int3
00007ff1409d07bc  nop [rax], eax
00007ff1409d07c0  mov eax, [r15+0xA0]
00007ff1409d07c7  mov [rsp+0x10], eax
00007ff1409d07cb  xor eax, eax
00007ff1409d07cd  mov r14d, [rsp+0x10]
00007ff1409d07d2  sub r14d, 0x01
00007ff1409d07d6  cmc
00007ff1409d07d7  lahf
00007ff1409d07d8  seto al
00007ff1409d07db  mov [r15+0x108], eax
00007ff1409d07e2  mov r14d, r14d
00007ff1409d07e5  mov [r15+0xA0], r14
00007ff1409d07ec  mov eax, [r15+0x108]
00007ff1409d07f3  sahf
00007ff1409d07f4  jnz 0x00007FF1409D0826
00007ff1409d07f6  cmp dword ptr [r15+0x318], 0x00
00007ff1409d07fe  jz 0x00007FF1409D0900
00007ff1409d0804  nop [rax+rax*1], ax
00007ff1409d080d  nop [rax+rax*1], eax
00007ff1409d0815  mov eax, 0x41028C
00007ff1409d081a  mov [r15+0x100], rax
00007ff1409d0821  jmp 0x00007FF1407FE110
00007ff1409d0826  cmp dword ptr [r15+0x318], 0x00
00007ff1409d082e  jz 0x00007FF1409D0860
00007ff1409d0834  nop [rax+rax*1], ax
00007ff1409d083d  nop [rax+rax*1], eax
00007ff1409d0845  mov eax, 0x410274
00007ff1409d084a  mov [r15+0x100], rax
00007ff1409d0851  jmp 0x00007FF1407FE110
00007ff1409d0856  int3
00007ff1409d0857  int3
00007ff1409d0858  nop [rax+rax*1], eax
00007ff1409d0860  mov rax, [r15+0xF8]
00007ff1409d0867  lea r14, [rax+0x100]
00007ff1409d086e  mov [r15], r14
00007ff1409d0871  mov rax, [r15+0x98]
00007ff1409d0878  mov [r15+0x08], rax
00007ff1409d087c  mov qword ptr [r15+0x10], 0x12C
00007ff1409d0884  mov qword ptr [r15+0xF0], 0x410284
00007ff1409d088f  mov r14d, [r15+0x320]
00007ff1409d0896  mov eax, 0x410284
00007ff1409d089b  mov rcx, 0x7FF1409D07C0
00007ff1409d08a5  mov [r15+r14*8+0x328], rax
00007ff1409d08ad  mov [r15+r14*8+0x368], rcx
00007ff1409d08b5  add r14d, 0x01
00007ff1409d08b9  and r14d, 0x07
00007ff1409d08bd  mov [r15+0x320], r14d
00007ff1409d08c4  cmp dword ptr [r15+0x318], 0x00
00007ff1409d08cc  jz 0x00007FF1409CED70
00007ff1409d08d2  nop [rax+rax*1], ax
00007ff1409d08db  nop [rax+rax*1], eax
00007ff1409d08e3  mov eax, 0x410728
00007ff1409d08e8  mov [r15+0x100], rax
00007ff1409d08ef  jmp 0x00007FF1407FE110
00007ff1409d08f4  int3
00007ff1409d08f5  int3
00007ff1409d08f6  nop [rax+rax*1], ax
00007ff1409d08ff  nop
00007ff1409d0900  mov rax, [r15+0xF8]
00007ff1409d0907  lea r14, [rax+0x120]
00007ff1409d090e  mov r12, [r13+r14*1]
00007ff1409d0913  mov [r15+0x98], r12
00007ff1409d091a  mov qword ptr [r15+0x40], 0x80
00007ff1409d0922  lea r14, [rax+0x100]
00007ff1409d0929  mov [r15], r14
00007ff1409d092c  lea r14, [rax+0x17C]
00007ff1409d0933  mov [r15+0x08], r14
00007ff1409d0937  mov qword ptr [r15+0x10], 0x01
00007ff1409d093f  lea r14, [rax+0x17C]
00007ff1409d0946  mov eax, 0x80
00007ff1409d094b  mov [r13+r14*1], al
00007ff1409d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007ff1409d095b  mov r14d, [r15+0x320]
00007ff1409d0962  mov eax, 0x4102A8
00007ff1409d0967  mov rcx, 0x7FF1409D09E0
00007ff1409d0971  mov [r15+r14*8+0x328], rax
00007ff1409d0979  mov [r15+r14*8+0x368], rcx
00007ff1409d0981  add r14d, 0x01
00007ff1409d0985  and r14d, 0x07
00007ff1409d0989  mov [r15+0x320], r14d
00007ff1409d0990  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0998  jz 0x00007FF1409CED70
00007ff1409d099e  nop [rax+rax*1], ax
00007ff1409d09a7  nop [rax+rax*1], eax
00007ff1409d09af  mov eax, 0x410728
00007ff1409d09b4  mov [r15+0x100], rax
00007ff1409d09bb  jmp 0x00007FF1407FE110
00007ff1409d09c0  int3
00007ff1409d09c1  call 0x00007FF1408E27E0
00007ff1409d09c6  jmp 0x00007FF1409D0913
00007ff1409d09cb  call 0x00007FF1408D5AF0
00007ff1409d09d0  jmp 0x00007FF1409D0950
00007ff1409d09d5  int3
00007ff1409d09d6  nop [rax+rax*1], ax
00007ff1409d09df  nop
00007ff1409d09e0  mov rax, [r15+0xF8]
00007ff1409d09e7  lea r14, [rax+0x168]
00007ff1409d09ee  mov r12, [r13+r14*1]
00007ff1409d09f3  mov [r15+0x40], r12
00007ff1409d09f7  lea r14, [rax+0x178]
00007ff1409d09fe  xor eax, eax
00007ff1409d0a00  mov [r13+r14*1], al
00007ff1409d0a05  xor eax, eax
00007ff1409d0a07  mov r14d, 0x38
00007ff1409d0a0d  cmp r12, r14
00007ff1409d0a10  cmc
00007ff1409d0a11  lahf
00007ff1409d0a12  seto al
00007ff1409d0a15  mov [r15+0x108], eax
00007ff1409d0a1c  mov eax, [r15+0x108]
00007ff1409d0a23  sahf
00007ff1409d0a24  jz 0x00007FF1409D0A56
00007ff1409d0a26  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0a2e  jz 0x00007FF1409D0AA0
00007ff1409d0a34  nop [rax+rax*1], ax
00007ff1409d0a3d  nop [rax+rax*1], eax
00007ff1409d0a45  mov eax, 0x4102B8
00007ff1409d0a4a  mov [r15+0x100], rax
00007ff1409d0a51  jmp 0x00007FF1407FE110
00007ff1409d0a56  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0a5e  jz 0x00007FF1409D0BF0
00007ff1409d0a64  nop [rax+rax*1], ax
00007ff1409d0a6d  nop [rax+rax*1], eax
00007ff1409d0a75  mov eax, 0x4102D4
00007ff1409d0a7a  mov [r15+0x100], rax
00007ff1409d0a81  jmp 0x00007FF1407FE110
00007ff1409d0a86  int3
00007ff1409d0a87  call 0x00007FF1408E27E0
00007ff1409d0a8c  jmp 0x00007FF1409D09F3
00007ff1409d0a91  call 0x00007FF1408D5AF0
00007ff1409d0a96  jmp 0x00007FF1409D0A05
00007ff1409d0a9b  int3
00007ff1409d0a9c  nop [rax], eax
00007ff1409d0aa0  mov rax, [r15+0xF8]
00007ff1409d0aa7  lea r14, [rax+0x100]
00007ff1409d0aae  mov [r15], r14
00007ff1409d0ab1  lea r14, [rax+0x178]
00007ff1409d0ab8  mov [r15+0x08], r14
00007ff1409d0abc  mov qword ptr [r15+0x10], 0x01
00007ff1409d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007ff1409d0acf  mov r14d, [r15+0x320]
00007ff1409d0ad6  mov eax, 0x4102C8
00007ff1409d0adb  mov rcx, 0x7FF1409D0B40
00007ff1409d0ae5  mov [r15+r14*8+0x328], rax
00007ff1409d0aed  mov [r15+r14*8+0x368], rcx
00007ff1409d0af5  add r14d, 0x01
00007ff1409d0af9  and r14d, 0x07
00007ff1409d0afd  mov [r15+0x320], r14d
00007ff1409d0b04  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0b0c  jz 0x00007FF1409CED70
00007ff1409d0b12  nop [rax+rax*1], ax
00007ff1409d0b1b  nop [rax+rax*1], eax
00007ff1409d0b23  mov eax, 0x410728
00007ff1409d0b28  mov [r15+0x100], rax
00007ff1409d0b2f  jmp 0x00007FF1407FE110
00007ff1409d0b34  int3
00007ff1409d0b35  int3
00007ff1409d0b36  nop [rax+rax*1], ax
00007ff1409d0b3f  nop
00007ff1409d0b40  mov rax, [r15+0xF8]
00007ff1409d0b47  lea r14, [rax+0x168]
00007ff1409d0b4e  mov rax, [r13+r14*1]
00007ff1409d0b53  mov [r15+0x40], rax
00007ff1409d0b57  mov [rsp+0x10], rax
00007ff1409d0b5c  xor eax, eax
00007ff1409d0b5e  mov r14, [rsp+0x10]
00007ff1409d0b63  mov r12d, 0x38
00007ff1409d0b69  cmp r14, r12
00007ff1409d0b6c  cmc
00007ff1409d0b6d  lahf
00007ff1409d0b6e  seto al
00007ff1409d0b71  mov [r15+0x108], eax
00007ff1409d0b78  mov eax, [r15+0x108]
00007ff1409d0b7f  sahf
00007ff1409d0b80  jnz 0x00007FF1409D0BB2
00007ff1409d0b82  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0b8a  jz 0x00007FF1409D0BF0
00007ff1409d0b90  nop [rax+rax*1], ax
00007ff1409d0b99  nop [rax+rax*1], eax
00007ff1409d0ba1  mov eax, 0x4102D4
00007ff1409d0ba6  mov [r15+0x100], rax
00007ff1409d0bad  jmp 0x00007FF1407FE110
00007ff1409d0bb2  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0bba  jz 0x00007FF1409D0AA0
00007ff1409d0bc0  nop [rax+rax*1], ax
00007ff1409d0bc9  nop [rax+rax*1], eax
00007ff1409d0bd1  mov eax, 0x4102B8
00007ff1409d0bd6  mov [r15+0x100], rax
00007ff1409d0bdd  jmp 0x00007FF1407FE110
00007ff1409d0be2  int3
00007ff1409d0be3  call 0x00007FF1408D59C0
00007ff1409d0be8  jmp 0x00007FF1409D0B53
00007ff1409d0bed  int3
00007ff1409d0bee  nop
00007ff1409d0bf0  mov rax, [r15+0x98]
00007ff1409d0bf7  rorx r14, rax, 0x3D
00007ff1409d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007ff1409d0c01  mov rax, [r15+0xF8]
00007ff1409d0c08  lea r12, [rax+0x100]
00007ff1409d0c0f  mov [r15], r12
00007ff1409d0c12  lea r12, [rax+0x170]
00007ff1409d0c19  mov [r15+0x08], r12
00007ff1409d0c1d  mov qword ptr [r15+0x10], 0x08
00007ff1409d0c25  bswap r14
00007ff1409d0c28  mov [r15+0x40], r14
00007ff1409d0c2c  lea r12, [rax+0x170]
00007ff1409d0c33  mov [r13+r12*1], r14
00007ff1409d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007ff1409d0c43  mov r14d, [r15+0x320]
00007ff1409d0c4a  mov eax, 0x4102F0
00007ff1409d0c4f  mov rcx, 0x7FF1409D0CC0
00007ff1409d0c59  mov [r15+r14*8+0x328], rax
00007ff1409d0c61  mov [r15+r14*8+0x368], rcx
00007ff1409d0c69  add r14d, 0x01
00007ff1409d0c6d  and r14d, 0x07
00007ff1409d0c71  mov [r15+0x320], r14d
00007ff1409d0c78  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0c80  jz 0x00007FF1409CED70
00007ff1409d0c86  nop [rax+rax*1], ax
00007ff1409d0c8f  nop [rax+rax*1], eax
00007ff1409d0c97  mov eax, 0x410728
00007ff1409d0c9c  mov [r15+0x100], rax
00007ff1409d0ca3  jmp 0x00007FF1407FE110
00007ff1409d0ca8  int3
00007ff1409d0ca9  call 0x00007FF1408C3FE0
00007ff1409d0cae  jmp 0x00007FF1409D0C38
00007ff1409d0cb3  int3
00007ff1409d0cb4  nop [rax+rax*1], ax
00007ff1409d0cbd  nop [rax], eax
00007ff1409d0cc0  mov rax, [r15+0xF8]
00007ff1409d0cc7  lea r14, [rax+0x100]
00007ff1409d0cce  mov r12d, [r13+r14*1]
00007ff1409d0cd3  lea r14, [rax+0x104]
00007ff1409d0cda  mov r11d, [r13+r14*1]
00007ff1409d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007ff1409d0ce7  lea r14, [rax+0x108]
00007ff1409d0cee  mov r10d, [r13+r14*1]
00007ff1409d0cf3  lea r14, [rax+0x10C]
00007ff1409d0cfa  mov r9d, [r13+r14*1]
00007ff1409d0cff  bswap r12d
00007ff1409d0d02  bswap r11d
00007ff1409d0d05  mov qword ptr [r15+0xA0], 0x00
00007ff1409d0d10  mov r14d, 0x430C90
00007ff1409d0d16  mov [r13+r14*1], r12d
00007ff1409d0d1b  mov r14d, 0x430C94
00007ff1409d0d21  mov [r13+r14*1], r11d
00007ff1409d0d26  bswap r10d
00007ff1409d0d29  lea r14, [rax+0x110]
00007ff1409d0d30  mov r12d, [r13+r14*1]
00007ff1409d0d35  bswap r9d
00007ff1409d0d38  lea r14, [rax+0x114]
00007ff1409d0d3f  mov r11d, [r13+r14*1]
00007ff1409d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007ff1409d0d4f  mov r14d, 0x430C98
00007ff1409d0d55  mov [r13+r14*1], r10d
00007ff1409d0d5a  mov r14d, 0x430C9C
00007ff1409d0d60  mov [r13+r14*1], r9d
00007ff1409d0d65  bswap r12d
00007ff1409d0d68  lea r14, [rax+0x118]
00007ff1409d0d6f  mov r10d, [r13+r14*1]
00007ff1409d0d74  bswap r11d
00007ff1409d0d77  mov [rsp+0x10], r11d
00007ff1409d0d7c  mov r11d, r11d
00007ff1409d0d7f  mov [r15+0x58], r11
00007ff1409d0d83  lea r14, [rax+0x11C]
00007ff1409d0d8a  mov eax, [r13+r14*1]
00007ff1409d0d8f  mov [rsp+0x20], eax
00007ff1409d0d93  mov eax, eax
00007ff1409d0d95  mov [r15+0x60], rax
00007ff1409d0d99  mov eax, 0x430CA0
00007ff1409d0d9e  mov [r13+rax*1], r12d
00007ff1409d0da3  mov eax, 0x430CA4
00007ff1409d0da8  mov r14d, [rsp+0x10]
00007ff1409d0dad  mov [r13+rax*1], r14d
00007ff1409d0db2  bswap r10d
00007ff1409d0db5  mov [rsp+0x10], r10d
00007ff1409d0dba  mov r10d, r10d
00007ff1409d0dbd  mov [r15+0x40], r10
00007ff1409d0dc1  mov eax, [rsp+0x20]
00007ff1409d0dc5  bswap eax
00007ff1409d0dc7  mov [rsp+0x20], eax
00007ff1409d0dcb  mov eax, eax
00007ff1409d0dcd  mov [r15+0x50], rax
00007ff1409d0dd1  mov eax, 0x430CA8
00007ff1409d0dd6  mov r14d, [rsp+0x10]
00007ff1409d0ddb  mov [r13+rax*1], r14d
00007ff1409d0de0  mov eax, 0x430CAC
00007ff1409d0de5  mov r14d, [rsp+0x20]
00007ff1409d0dea  mov [r13+rax*1], r14d
00007ff1409d0def  mov eax, [r15+0xA0]
00007ff1409d0df6  lea r14d, [eax+0x11]
00007ff1409d0dfb  mov r14d, r14d
00007ff1409d0dfe  mov [r15], r14
00007ff1409d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007ff1409d0e0c  mov r14d, [r15+0x320]
00007ff1409d0e13  mov eax, 0x41035C
00007ff1409d0e18  mov rcx, 0x7FF1409D0F90
00007ff1409d0e22  mov [r15+r14*8+0x328], rax
00007ff1409d0e2a  mov [r15+r14*8+0x368], rcx
00007ff1409d0e32  add r14d, 0x01
00007ff1409d0e36  and r14d, 0x07
00007ff1409d0e3a  mov [r15+0x320], r14d
00007ff1409d0e41  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0e49  jz 0x00007FF1409D0F20
00007ff1409d0e4f  nop [rax+rax*1], ax
00007ff1409d0e58  nop [rax+rax*1], eax
00007ff1409d0e60  mov eax, 0x4109A4
00007ff1409d0e65  mov [r15+0x100], rax
00007ff1409d0e6c  jmp 0x00007FF1407FE110
00007ff1409d0e71  int3
00007ff1409d0e72  call 0x00007FF1408E26A0
00007ff1409d0e77  jmp 0x00007FF1409D0CD3
00007ff1409d0e7c  call 0x00007FF1408E1430
00007ff1409d0e81  jmp 0x00007FF1409D0CDF
00007ff1409d0e86  call 0x00007FF1408E01C0
00007ff1409d0e8b  jmp 0x00007FF1409D0CF3
00007ff1409d0e90  call 0x00007FF1408DEF50
00007ff1409d0e95  jmp 0x00007FF1409D0CFF
00007ff1409d0e9a  call 0x00007FF1408E2BA0
00007ff1409d0e9f  jmp 0x00007FF1409D0D1B
00007ff1409d0ea4  call 0x00007FF1408E1920
00007ff1409d0ea9  jmp 0x00007FF1409D0D26
00007ff1409d0eae  call 0x00007FF1408E26A0
00007ff1409d0eb3  jmp 0x00007FF1409D0D35
00007ff1409d0eb8  call 0x00007FF1408E1430
00007ff1409d0ebd  jmp 0x00007FF1409D0D44
00007ff1409d0ec2  call 0x00007FF1408E06B0
00007ff1409d0ec7  jmp 0x00007FF1409D0D5A
00007ff1409d0ecc  call 0x00007FF1408DF440
00007ff1409d0ed1  jmp 0x00007FF1409D0D65
00007ff1409d0ed6  call 0x00007FF1408E01C0
00007ff1409d0edb  jmp 0x00007FF1409D0D74
00007ff1409d0ee0  call 0x00007FF1408D5890
00007ff1409d0ee5  jmp 0x00007FF1409D0D8F
00007ff1409d0eea  call 0x00007FF14080BAE0
00007ff1409d0eef  jmp 0x00007FF1409D0DA3
00007ff1409d0ef4  call 0x00007FF14080DFE0
00007ff1409d0ef9  jmp 0x00007FF1409D0DB2
00007ff1409d0efe  call 0x00007FF14080DFE0
00007ff1409d0f03  jmp 0x00007FF1409D0DE0
00007ff1409d0f08  call 0x00007FF14080DFE0
00007ff1409d0f0d  jmp 0x00007FF1409D0DEF
00007ff1409d0f12  int3
00007ff1409d0f13  nop [rax+rax*1], ax
00007ff1409d0f1c  nop [rax], eax
00007ff1409d0f20  mov eax, [r15]
00007ff1409d0f23  mov [rsp+0x10], eax
00007ff1409d0f27  shr eax, 0x10
00007ff1409d0f2a  mov r14d, [rsp+0x10]
00007ff1409d0f2f  xor r14d, eax
00007ff1409d0f32  imul r14d, r14d, 0x7FEB352D
00007ff1409d0f39  mov eax, 0x846CA68B
00007ff1409d0f3e  mov eax, eax
00007ff1409d0f40  mov [r15+0x48], rax
00007ff1409d0f44  mov [rsp+0x10], r14d
00007ff1409d0f49  shr r14d, 0x0F
00007ff1409d0f4d  mov eax, [rsp+0x10]
00007ff1409d0f51  xor eax, r14d
00007ff1409d0f54  imul eax, eax, 0x846CA68B
00007ff1409d0f5a  mov [rsp+0x10], eax
00007ff1409d0f5e  mov eax, eax
00007ff1409d0f60  mov [r15+0x40], rax
00007ff1409d0f64  mov eax, [rsp+0x10]
00007ff1409d0f68  shr eax, 0x10
00007ff1409d0f6b  mov r14d, [rsp+0x10]
00007ff1409d0f70  xor r14d, eax
00007ff1409d0f73  mov r14d, r14d
00007ff1409d0f76  mov [r15], r14
00007ff1409d0f79  mov rax, [r15+0xF0]
00007ff1409d0f80  mov [r15+0x100], rax
00007ff1409d0f87  jmp 0x00007FF1409CE5C0
00007ff1409d0f8c  int3
00007ff1409d0f8d  int3
00007ff1409d0f8e  nop
00007ff1409d0f90  mov rax, [r15+0xA0]
00007ff1409d0f97  mov [rsp+0x10], rax
00007ff1409d0f9c  shl rax, 0x02
00007ff1409d0fa0  mov r14, [r15+0x98]
00007ff1409d0fa7  lea r12, [r14+rax*1]
00007ff1409d0fab  mov eax, [r15]
00007ff1409d0fae  mov [r13+r12*1], eax
00007ff1409d0fb3  mov rax, [rsp+0x10]
00007ff1409d0fb8  lea r14, [rax+0x01]
00007ff1409d0fbc  mov [r15+0xA0], r14
00007ff1409d0fc3  xor eax, eax
00007ff1409d0fc5  mov r12d, 0x400
00007ff1409d0fcb  cmp r14, r12
00007ff1409d0fce  cmc
00007ff1409d0fcf  lahf
00007ff1409d0fd0  seto al
00007ff1409d0fd3  mov [r15+0x108], eax
00007ff1409d0fda  mov eax, [r15+0x108]
00007ff1409d0fe1  sahf
00007ff1409d0fe2  jnz 0x00007FF1409D1014
00007ff1409d0fe4  cmp dword ptr [r15+0x318], 0x00
00007ff1409d0fec  jz 0x00007FF1409D10E0
00007ff1409d0ff2  nop [rax+rax*1], ax
00007ff1409d0ffb  nop [rax+rax*1], eax
00007ff1409d1003  mov eax, 0x41036C
00007ff1409d1008  mov [r15+0x100], rax
00007ff1409d100f  jmp 0x00007FF1407FE110
00007ff1409d1014  cmp dword ptr [r15+0x318], 0x00
00007ff1409d101c  jz 0x00007FF1409D1050
00007ff1409d1022  nop [rax+rax*1], ax
00007ff1409d102b  nop [rax+rax*1], eax
00007ff1409d1033  mov eax, 0x410354
00007ff1409d1038  mov [r15+0x100], rax
00007ff1409d103f  jmp 0x00007FF1407FE110
00007ff1409d1044  int3
00007ff1409d1045  call 0x00007FF1408B4B70
00007ff1409d104a  jmp 0x00007FF1409D0FB3
00007ff1409d104f  int3
00007ff1409d1050  mov eax, [r15+0xA0]
00007ff1409d1057  lea r14d, [eax+0x11]
00007ff1409d105c  mov r14d, r14d
00007ff1409d105f  mov [r15], r14
00007ff1409d1062  mov qword ptr [r15+0xF0], 0x41035C
00007ff1409d106d  mov r14d, [r15+0x320]
00007ff1409d1074  mov eax, 0x41035C
00007ff1409d1079  mov rcx, 0x7FF1409D0F90
00007ff1409d1083  mov [r15+r14*8+0x328], rax
00007ff1409d108b  mov [r15+r14*8+0x368], rcx
00007ff1409d1093  add r14d, 0x01
00007ff1409d1097  and r14d, 0x07
00007ff1409d109b  mov [r15+0x320], r14d
00007ff1409d10a2  cmp dword ptr [r15+0x318], 0x00
00007ff1409d10aa  jz 0x00007FF1409D0F20
00007ff1409d10b0  nop [rax+rax*1], ax
00007ff1409d10b9  nop [rax+rax*1], eax
00007ff1409d10c1  mov eax, 0x4109A4
00007ff1409d10c6  mov [r15+0x100], rax
00007ff1409d10cd  jmp 0x00007FF1407FE110
00007ff1409d10d2  int3
00007ff1409d10d3  int3
00007ff1409d10d4  nop [rax+rax*1], ax
00007ff1409d10dd  nop [rax], eax
00007ff1409d10e0  mov qword ptr [r15+0x40], 0x01
00007ff1409d10e8  cmp dword ptr [r15+0x318], 0x00
00007ff1409d10f0  jz 0x00007FF1409D1120
00007ff1409d10f6  nop [rax+rax*1], ax
00007ff1409d10ff  nop [rax+rax*1], eax
00007ff1409d1107  mov eax, 0x410388
00007ff1409d110c  mov [r15+0x100], rax
00007ff1409d1113  jmp 0x00007FF1407FE110
00007ff1409d1118  int3
00007ff1409d1119  int3
00007ff1409d111a  nop [rax+rax*1], ax
00007ff1409d1120  mov rax, [r15+0x40]
00007ff1409d1124  mov [rsp+0x10], rax
00007ff1409d1129  shl rax, 0x02
00007ff1409d112d  mov r14, [r15+0x98]
00007ff1409d1134  lea r12, [r14+rax*1]
00007ff1409d1138  mov eax, [r13+r12*1]
00007ff1409d113d  mov [rsp+0x20], eax
00007ff1409d1141  mov eax, eax
00007ff1409d1143  mov [r15+0x48], rax
00007ff1409d1147  mov rax, [rsp+0x10]
00007ff1409d114c  mov [r15+0x50], rax
00007ff1409d1150  mov eax, [r15+0x50]
00007ff1409d1154  lea r12d, [eax-0x01]
00007ff1409d1159  mov r12d, r12d
00007ff1409d115c  mov [r15+0x58], r12
00007ff1409d1160  mov rax, [r15+0x58]
00007ff1409d1164  mov r12d, eax
00007ff1409d1167  mov r12d, r12d
00007ff1409d116a  shl r12, 0x02
00007ff1409d116e  lea rax, [r14+r12*1]
00007ff1409d1172  mov r14d, [r13+rax*1]
00007ff1409d1177  mov [rsp+0x10], r14d
00007ff1409d117c  mov r14d, r14d
00007ff1409d117f  mov [r15+0x60], r14
00007ff1409d1183  xor eax, eax
00007ff1409d1185  mov r14d, [rsp+0x10]
00007ff1409d118a  mov r12d, [rsp+0x20]
00007ff1409d118f  cmp r14d, r12d
00007ff1409d1192  cmc
00007ff1409d1193  lahf
00007ff1409d1194  seto al
00007ff1409d1197  mov [r15+0x108], eax
00007ff1409d119e  mov eax, [r15+0x108]
00007ff1409d11a5  sahf
00007ff1409d11a6  cmc
00007ff1409d11a7  jbe 0x00007FF1409D11D9
00007ff1409d11a9  cmp dword ptr [r15+0x318], 0x00
00007ff1409d11b1  jz 0x00007FF1409D1220
00007ff1409d11b7  nop [rax+rax*1], ax
00007ff1409d11c0  nop [rax+rax*1], eax
00007ff1409d11c8  mov eax, 0x4103A0
00007ff1409d11cd  mov [r15+0x100], rax
00007ff1409d11d4  jmp 0x00007FF1407FE110
00007ff1409d11d9  cmp dword ptr [r15+0x318], 0x00
00007ff1409d11e1  jz 0x00007FF1409D14C0
00007ff1409d11e7  nop [rax+rax*1], ax
00007ff1409d11f0  nop [rax+rax*1], eax
00007ff1409d11f8  mov eax, 0x410378
00007ff1409d11fd  mov [r15+0x100], rax
00007ff1409d1204  jmp 0x00007FF1407FE110
00007ff1409d1209  int3
00007ff1409d120a  call 0x00007FF1408B4690
00007ff1409d120f  jmp 0x00007FF1409D113D
00007ff1409d1214  call 0x00007FF14080DAE0
00007ff1409d1219  jmp 0x00007FF1409D1177
00007ff1409d121e  int3
00007ff1409d121f  nop
00007ff1409d1220  mov rax, [r15+0x50]
00007ff1409d1224  mov [rsp+0x10], rax
00007ff1409d1229  shl rax, 0x02
00007ff1409d122d  mov r14, [r15+0x98]
00007ff1409d1234  lea r12, [r14+rax*1]
00007ff1409d1238  mov eax, [r15+0x60]
00007ff1409d123c  mov [r13+r12*1], eax
00007ff1409d1241  mov rax, [rsp+0x10]
00007ff1409d1246  lea r14, [rax-0x01]
00007ff1409d124a  mov [r15+0x50], r14
00007ff1409d124e  mov rax, [r15+0x58]
00007ff1409d1252  test rax, rax
00007ff1409d1255  setz al
00007ff1409d1258  movzx rax, al
00007ff1409d125c  mov [rsp+0x414], al
00007ff1409d1263  cmp byte ptr [rsp+0x414], 0x00
00007ff1409d126b  jz 0x00007FF1409D129D
00007ff1409d126d  cmp dword ptr [r15+0x318], 0x00
00007ff1409d1275  jz 0x00007FF1409D12E0
00007ff1409d127b  nop [rax+rax*1], ax
00007ff1409d1284  nop [rax+rax*1], eax
00007ff1409d128c  mov eax, 0x4103AC
00007ff1409d1291  mov [r15+0x100], rax
00007ff1409d1298  jmp 0x00007FF1407FE110
00007ff1409d129d  cmp dword ptr [r15+0x318], 0x00
00007ff1409d12a5  jz 0x00007FF1409D13E0
00007ff1409d12ab  nop [rax+rax*1], ax
00007ff1409d12b4  nop [rax+rax*1], eax
00007ff1409d12bc  mov eax, 0x410390
00007ff1409d12c1  mov [r15+0x100], rax
00007ff1409d12c8  jmp 0x00007FF1407FE110
00007ff1409d12cd  int3
00007ff1409d12ce  call 0x00007FF1408B4B70
00007ff1409d12d3  jmp 0x00007FF1409D1241
00007ff1409d12d8  int3
00007ff1409d12d9  nop [rax], eax
00007ff1409d12e0  cmp dword ptr [r15+0x318], 0x00
00007ff1409d12e8  jz 0x00007FF1409D1320
00007ff1409d12ee  nop [rax+rax*1], ax
00007ff1409d12f7  nop [rax+rax*1], eax
00007ff1409d12ff  mov eax, 0x410374
00007ff1409d1304  mov [r15+0x100], rax
00007ff1409d130b  jmp 0x00007FF1407FE110
00007ff1409d1310  int3
00007ff1409d1311  int3
00007ff1409d1312  nop [rax+rax*1], ax
00007ff1409d131b  nop [rax+rax*1], eax
00007ff1409d1320  mov qword ptr [r15+0x50], 0x00
00007ff1409d1328  mov rax, [r15+0x40]
00007ff1409d132c  lea r14, [rax+0x01]
00007ff1409d1330  mov [r15+0x40], r14
00007ff1409d1334  mov rax, [r15+0x98]
00007ff1409d133b  mov r12d, [r15+0x48]
00007ff1409d133f  mov [r13+rax*1], r12d
00007ff1409d1344  xor eax, eax
00007ff1409d1346  mov r12d, 0x400
00007ff1409d134c  cmp r14, r12
00007ff1409d134f  cmc
00007ff1409d1350  lahf
00007ff1409d1351  seto al
00007ff1409d1354  mov [r15+0x108], eax
00007ff1409d135b  mov eax, [r15+0x108]
00007ff1409d1362  sahf
00007ff1409d1363  jz 0x00007FF1409D1395
00007ff1409d1365  cmp dword ptr [r15+0x318], 0x00
00007ff1409d136d  jz 0x00007FF1409D1120
00007ff1409d1373  nop [rax+rax*1], ax
00007ff1409d137c  nop [rax+rax*1], eax
00007ff1409d1384  mov eax, 0x410388
00007ff1409d1389  mov [r15+0x100], rax
00007ff1409d1390  jmp 0x00007FF1407FE110
00007ff1409d1395  cmp dword ptr [r15+0x318], 0x00
00007ff1409d139d  jz 0x00007FF1409D1580
00007ff1409d13a3  nop [rax+rax*1], ax
00007ff1409d13ac  nop [rax+rax*1], eax
00007ff1409d13b4  mov eax, 0x4103B0
00007ff1409d13b9  mov [r15+0x100], rax
00007ff1409d13c0  jmp 0x00007FF1407FE110
00007ff1409d13c5  int3
00007ff1409d13c6  call 0x00007FF14080BAE0
00007ff1409d13cb  jmp 0x00007FF1409D1344
00007ff1409d13d0  int3
00007ff1409d13d1  nop [rax+rax*1], ax
00007ff1409d13da  nop [rax+rax*1], ax
00007ff1409d13e0  mov eax, [r15+0x50]
00007ff1409d13e4  lea r14d, [eax-0x01]
00007ff1409d13e9  mov r14d, r14d
00007ff1409d13ec  mov [r15+0x58], r14
00007ff1409d13f0  mov rax, [r15+0x58]
00007ff1409d13f4  mov r14d, eax
00007ff1409d13f7  mov r14d, r14d
00007ff1409d13fa  shl r14, 0x02
00007ff1409d13fe  mov rax, [r15+0x98]
00007ff1409d1405  lea r12, [rax+r14*1]
00007ff1409d1409  mov eax, [r13+r12*1]
00007ff1409d140e  mov [rsp+0x10], eax
00007ff1409d1412  mov eax, eax
00007ff1409d1414  mov [r15+0x60], rax
00007ff1409d1418  mov eax, [r15+0x48]
00007ff1409d141c  mov [rsp+0x20], eax
00007ff1409d1420  xor eax, eax
00007ff1409d1422  mov r14d, [rsp+0x10]
00007ff1409d1427  mov r12d, [rsp+0x20]
00007ff1409d142c  cmp r14d, r12d
00007ff1409d142f  cmc
00007ff1409d1430  lahf
00007ff1409d1431  seto al
00007ff1409d1434  mov [r15+0x108], eax
00007ff1409d143b  mov eax, [r15+0x108]
00007ff1409d1442  sahf
00007ff1409d1443  cmc
00007ff1409d1444  jbe 0x00007FF1409D1476
00007ff1409d1446  cmp dword ptr [r15+0x318], 0x00
00007ff1409d144e  jz 0x00007FF1409D1220
00007ff1409d1454  nop [rax+rax*1], ax
00007ff1409d145d  nop [rax+rax*1], eax
00007ff1409d1465  mov eax, 0x4103A0
00007ff1409d146a  mov [r15+0x100], rax
00007ff1409d1471  jmp 0x00007FF1407FE110
00007ff1409d1476  cmp dword ptr [r15+0x318], 0x00
00007ff1409d147e  jz 0x00007FF1409D14C0
00007ff1409d1484  nop [rax+rax*1], ax
00007ff1409d148d  nop [rax+rax*1], eax
00007ff1409d1495  mov eax, 0x410378
00007ff1409d149a  mov [r15+0x100], rax
00007ff1409d14a1  jmp 0x00007FF1407FE110
00007ff1409d14a6  int3
00007ff1409d14a7  call 0x00007FF1408B4690
00007ff1409d14ac  jmp 0x00007FF1409D140E
00007ff1409d14b1  int3
00007ff1409d14b2  nop [rax+rax*1], ax
00007ff1409d14bb  nop [rax+rax*1], eax
00007ff1409d14c0  mov rax, [r15+0x40]
00007ff1409d14c4  lea r14, [rax+0x01]
00007ff1409d14c8  mov [r15+0x40], r14
00007ff1409d14cc  mov rax, [r15+0x50]
00007ff1409d14d0  mov r12d, eax
00007ff1409d14d3  mov r12d, r12d
00007ff1409d14d6  shl r12, 0x02
00007ff1409d14da  mov rax, [r15+0x98]
00007ff1409d14e1  lea r11, [rax+r12*1]
00007ff1409d14e5  mov eax, [r15+0x48]
00007ff1409d14e9  mov [r13+r11*1], eax
00007ff1409d14ee  xor eax, eax
00007ff1409d14f0  mov r12d, 0x400
00007ff1409d14f6  cmp r14, r12
00007ff1409d14f9  cmc
00007ff1409d14fa  lahf
00007ff1409d14fb  seto al
00007ff1409d14fe  mov [r15+0x108], eax
00007ff1409d1505  mov eax, [r15+0x108]
00007ff1409d150c  sahf
00007ff1409d150d  jz 0x00007FF1409D153F
00007ff1409d150f  cmp dword ptr [r15+0x318], 0x00
00007ff1409d1517  jz 0x00007FF1409D1120
00007ff1409d151d  nop [rax+rax*1], ax
00007ff1409d1526  nop [rax+rax*1], eax
00007ff1409d152e  mov eax, 0x410388
00007ff1409d1533  mov [r15+0x100], rax
00007ff1409d153a  jmp 0x00007FF1407FE110
00007ff1409d153f  cmp dword ptr [r15+0x318], 0x00
00007ff1409d1547  jz 0x00007FF1409D1580
00007ff1409d154d  nop [rax+rax*1], ax
00007ff1409d1556  nop [rax+rax*1], eax
00007ff1409d155e  mov eax, 0x4103B0
00007ff1409d1563  mov [r15+0x100], rax
00007ff1409d156a  jmp 0x00007FF1407FE110
00007ff1409d156f  int3
00007ff1409d1570  call 0x00007FF1408A4270
00007ff1409d1575  jmp 0x00007FF1409D14EE
00007ff1409d157a  int3
00007ff1409d157b  nop [rax+rax*1], eax
00007ff1409d1580  mov qword ptr [r15+0x40], 0x430000
00007ff1409d1588  mov eax, 0x430CB0
00007ff1409d158d  mov r14, [r13+rax*1]
00007ff1409d1592  mov rax, [r15+0x98]
00007ff1409d1599  mov r12d, [r13+rax*1]
00007ff1409d159e  lea r11, [rax+0x04]
00007ff1409d15a2  mov eax, [r13+r11*1]
00007ff1409d15a7  mov r12d, r12d
00007ff1409d15aa  mov [r15+0x68], r12
00007ff1409d15ae  mov eax, eax
00007ff1409d15b0  mov [r15+0x60], rax
00007ff1409d15b4  mov rax, [r15+0x68]
00007ff1409d15b8  mov [r15+0x68], rax
00007ff1409d15bc  mov qword ptr [r15+0x58], 0x02
00007ff1409d15c4  mov [rsp+0x10], rax
00007ff1409d15c9  xor eax, eax
00007ff1409d15cb  mov r12d, 0x02
00007ff1409d15d1  mov r11d, 0x400
00007ff1409d15d7  cmp r12, r11
00007ff1409d15da  cmc
00007ff1409d15db  lahf
00007ff1409d15dc  seto al
00007ff1409d15df  mov [r15+0x108], eax
00007ff1409d15e6  mov rax, [r15+0x60]
00007ff1409d15ea  mov r12d, 0x02
00007ff1409d15f0  imul rax, r12
00007ff1409d15f4  mov [r15+0x50], rax
00007ff1409d15f8  mov rax, [rsp+0x10]
00007ff1409d15fd  lea r12, [rax+r14*1]
00007ff1409d1601  mov [r15+0x48], r12
00007ff1409d1605  mov eax, [r15+0x108]
00007ff1409d160c  sahf
00007ff1409d160d  jnz 0x00007FF1409D163F
00007ff1409d160f  cmp dword ptr [r15+0x318], 0x00
00007ff1409d1617  jz 0x00007FF1409D17B0
00007ff1409d161d  nop [rax+rax*1], ax
00007ff1409d1626  nop [rax+rax*1], eax
00007ff1409d162e  mov eax, 0x4103E0
00007ff1409d1633  mov [r15+0x100], rax
00007ff1409d163a  jmp 0x00007FF1407FE110
00007ff1409d163f  cmp dword ptr [r15+0x318], 0x00
00007ff1409d1647  jz 0x00007FF1409D1690
00007ff1409d164d  nop [rax+rax*1], ax
00007ff1409d1656  nop [rax+rax*1], eax
00007ff1409d165e  mov eax, 0x4103C0
00007ff1409d1663  mov [r15+0x100], rax
00007ff1409d166a  jmp 0x00007FF1407FE110
00007ff1409d166f  int3
00007ff1409d1670  call 0x00007FF14080DC20
00007ff1409d1675  jmp 0x00007FF1409D1592
00007ff1409d167a  call 0x00007FF14080B5E0
00007ff1409d167f  jmp 0x00007FF1409D159E
00007ff1409d1684  call 0x00007FF1408A3D90
00007ff1409d1689  jmp 0x00007FF1409D15A7
00007ff1409d168e  int3
00007ff1409d168f  nop
00007ff1409d1690  mov rax, [r15+0x98]
00007ff1409d1697  mov r14, [r15+0x58]
00007ff1409d169b  mov [rsp+0x10], r14
00007ff1409d16a0  shl r14, 0x02
00007ff1409d16a4  lea r12, [rax+r14*1]
00007ff1409d16a8  mov eax, [r13+r12*1]
00007ff1409d16ad  lea r14, [r12+0x04]
00007ff1409d16b2  mov r12d, [r13+r14*1]
00007ff1409d16b7  mov eax, eax
00007ff1409d16b9  mov [r15+0x68], rax
00007ff1409d16bd  mov r12d, r12d
00007ff1409d16c0  mov [r15+0x60], r12
00007ff1409d16c4  mov rax, [r15+0x68]
00007ff1409d16c8  mov [rsp+0x20], rax
00007ff1409d16cd  mov r14, [rsp+0x10]
00007ff1409d16d2  imul rax, r14
00007ff1409d16d6  mov r12, [rsp+0x20]
00007ff1409d16db  lea r11, [r12+rax*1]
00007ff1409d16df  mov [r15+0x68], r11
00007ff1409d16e3  lea rax, [r14+0x02]
00007ff1409d16e7  mov [r15+0x58], rax
00007ff1409d16eb  mov [rsp+0x10], rax
00007ff1409d16f0  xor eax, eax
00007ff1409d16f2  mov r14, [rsp+0x10]
00007ff1409d16f7  mov r12d, 0x400
00007ff1409d16fd  cmp r14, r12
00007ff1409d1700  cmc
00007ff1409d1701  lahf
00007ff1409d1702  seto al
00007ff1409d1705  mov [r15+0x108], eax
00007ff1409d170c  mov rax, [r15+0x50]
00007ff1409d1710  mov r12, [r15+0x60]
00007ff1409d1714  imul r14, r12
00007ff1409d1718  lea r12, [rax+r14*1]
00007ff1409d171c  mov [r15+0x50], r12
00007ff1409d1720  mov rax, [r15+0x48]
00007ff1409d1724  lea r14, [r11+rax*1]
00007ff1409d1728  mov [r15+0x48], r14
00007ff1409d172c  mov eax, [r15+0x108]
00007ff1409d1733  sahf
00007ff1409d1734  jnz 0x00007FF1409D1766
00007ff1409d1736  cmp dword ptr [r15+0x318], 0x00
00007ff1409d173e  jz 0x00007FF1409D17B0
00007ff1409d1744  nop [rax+rax*1], ax
00007ff1409d174d  nop [rax+rax*1], eax
00007ff1409d1755  mov eax, 0x4103E0
00007ff1409d175a  mov [r15+0x100], rax
00007ff1409d1761  jmp 0x00007FF1407FE110
00007ff1409d1766  cmp dword ptr [r15+0x318], 0x00
00007ff1409d176e  jz 0x00007FF1409D1690
00007ff1409d1774  nop [rax+rax*1], ax
00007ff1409d177d  nop [rax+rax*1], eax
00007ff1409d1785  mov eax, 0x4103C0
00007ff1409d178a  mov [r15+0x100], rax
00007ff1409d1791  jmp 0x00007FF1407FE110
00007ff1409d1796  int3
00007ff1409d1797  call 0x00007FF1408B4690
00007ff1409d179c  jmp 0x00007FF1409D16AD
00007ff1409d17a1  call 0x00007FF1408E26A0
00007ff1409d17a6  jmp 0x00007FF1409D16B7
00007ff1409d17ab  int3
00007ff1409d17ac  nop [rax], eax
00007ff1409d17b0  mov qword ptr [r15+0x98], 0x00
00007ff1409d17bb  mov rax, [r15+0x50]
00007ff1409d17bf  mov r14, [r15+0x48]
00007ff1409d17c3  lea r12, [rax+r14*1]
00007ff1409d17c7  mov [r15+0x48], r12
00007ff1409d17cb  mov rax, [r15+0x40]
00007ff1409d17cf  lea r14, [rax+0xCB0]
00007ff1409d17d6  mov [r13+r14*1], r12
00007ff1409d17db  mov qword ptr [r15], 0x01
00007ff1409d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007ff1409d17ed  mov r14d, [r15+0x320]
00007ff1409d17f4  mov eax, 0x4103F8
00007ff1409d17f9  mov rcx, 0x7FF1409D1860
00007ff1409d1803  mov [r15+r14*8+0x328], rax
00007ff1409d180b  mov [r15+r14*8+0x368], rcx
00007ff1409d1813  add r14d, 0x01
00007ff1409d1817  and r14d, 0x07
00007ff1409d181b  mov [r15+0x320], r14d
00007ff1409d1822  cmp dword ptr [r15+0x318], 0x00
00007ff1409d182a  jz 0x00007FF1409D0F20
00007ff1409d1830  nop [rax+rax*1], ax
00007ff1409d1839  nop [rax+rax*1], eax
00007ff1409d1841  mov eax, 0x4109A4
00007ff1409d1846  mov [r15+0x100], rax
00007ff1409d184d  jmp 0x00007FF1407FE110
00007ff1409d1852  int3
00007ff1409d1853  call 0x00007FF1408E2CE0
00007ff1409d1858  jmp 0x00007FF1409D17DB
00007ff1409d185d  int3
00007ff1409d185e  nop
00007ff1409d1860  mov eax, [r15+0x98]
00007ff1409d1867  lea r14d, [eax+0x01]
00007ff1409d186c  mov [rsp+0x10], r14d
00007ff1409d1871  mov r14d, r14d
00007ff1409d1874  mov [r15+0x98], r14
00007ff1409d187b  xor eax, eax
00007ff1409d187d  mov r14d, [rsp+0x10]
00007ff1409d1882  cmp r14d, 0x10000
00007ff1409d1889  cmc
00007ff1409d188a  lahf
00007ff1409d188b  seto al
00007ff1409d188e  mov [r15+0x108], eax
00007ff1409d1895  mov eax, [r15+0x108]
00007ff1409d189c  sahf
00007ff1409d189d  jnz 0x00007FF1409D18CF
00007ff1409d189f  cmp dword ptr [r15+0x318], 0x00
00007ff1409d18a7  jz 0x00007FF1409D19A0
00007ff1409d18ad  nop [rax+rax*1], ax
00007ff1409d18b6  nop [rax+rax*1], eax
00007ff1409d18be  mov eax, 0x410404
00007ff1409d18c3  mov [r15+0x100], rax
00007ff1409d18ca  jmp 0x00007FF1407FE110
00007ff1409d18cf  cmp dword ptr [r15+0x318], 0x00
00007ff1409d18d7  jz 0x00007FF1409D1910
00007ff1409d18dd  nop [rax+rax*1], ax
00007ff1409d18e6  nop [rax+rax*1], eax
00007ff1409d18ee  mov eax, 0x4103F0
00007ff1409d18f3  mov [r15+0x100], rax
00007ff1409d18fa  jmp 0x00007FF1407FE110
00007ff1409d18ff  int3
00007ff1409d1900  int3
00007ff1409d1901  nop [rax+rax*1], ax
00007ff1409d190a  nop [rax+rax*1], ax
00007ff1409d1910  mov eax, [r15]
00007ff1409d1913  mov r14d, [r15+0x98]
00007ff1409d191a  lea r12d, [eax+r14d*1]
00007ff1409d191f  mov r12d, r12d
00007ff1409d1922  mov [r15], r12
00007ff1409d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007ff1409d1930  mov r14d, [r15+0x320]
00007ff1409d1937  mov eax, 0x4103F8
00007ff1409d193c  mov rcx, 0x7FF1409D1860
00007ff1409d1946  mov [r15+r14*8+0x328], rax
00007ff1409d194e  mov [r15+r14*8+0x368], rcx
00007ff1409d1956  add r14d, 0x01
00007ff1409d195a  and r14d, 0x07
00007ff1409d195e  mov [r15+0x320], r14d
00007ff1409d1965  cmp dword ptr [r15+0x318], 0x00
00007ff1409d196d  jz 0x00007FF1409D0F20
00007ff1409d1973  nop [rax+rax*1], ax
00007ff1409d197c  nop [rax+rax*1], eax
00007ff1409d1984  mov eax, 0x4109A4
00007ff1409d1989  mov [r15+0x100], rax
00007ff1409d1990  jmp 0x00007FF1407FE110
00007ff1409d1995  int3
00007ff1409d1996  int3
00007ff1409d1997  nop [rax+rax*1], ax
00007ff1409d19a0  vmovaps xmm1, [0x00007FF1405FE010]
00007ff1409d19a8  movq xmm1, xmm1
00007ff1409d19ac  movaps [r15+0x110], xmm1
00007ff1409d19b4  mov eax, 0x420B10
00007ff1409d19b9  mov r14, [r13+rax*1]
00007ff1409d19be  movq xmm1, r14
00007ff1409d19c3  movaps [r15+0x120], xmm1
00007ff1409d19cb  vmovaps xmm1, [0x00007FF1405FE020]
00007ff1409d19d3  movq xmm1, xmm1
00007ff1409d19d7  movaps [r15+0x140], xmm1
00007ff1409d19df  vmovaps xmm1, [0x00007FF1405FE030]
00007ff1409d19e7  vpbroadcastq xmm1, xmm1
00007ff1409d19ec  movaps [r15+0x150], xmm1
00007ff1409d19f4  mov qword ptr [r15+0x40], 0x02
00007ff1409d19fc  vmovaps xmm15, [0x00007FF1405FE040]
00007ff1409d1a04  movq xmm15, xmm15
00007ff1409d1a09  movaps [r15+0x160], xmm15
00007ff1409d1a11  vmovaps xmm15, [0x00007FF1405FE050]
00007ff1409d1a19  vpbroadcastq xmm15, xmm15
00007ff1409d1a1e  movaps [r15+0x130], xmm15
00007ff1409d1a26  mov rax, [r15+0x40]
00007ff1409d1a2a  vmovq xmm14, rax
00007ff1409d1a2f  vpbroadcastq xmm14, xmm14
00007ff1409d1a34  movaps [r15+0x170], xmm14
00007ff1409d1a3c  mov eax, 0x420A40
00007ff1409d1a41  movups xmm13, [r13+rax*1]
00007ff1409d1a47  mov qword ptr [r15+0x40], 0x431E00
00007ff1409d1a4f  mov eax, [r15]
00007ff1409d1a52  mov r14d, 0x430CB8
00007ff1409d1a58  mov [r13+r14*1], eax
00007ff1409d1a5d  mov qword ptr [r15+0x50], 0x432000
00007ff1409d1a65  vpmovqd xmm12, xmm13
00007ff1409d1a6b  pxor xmm11, xmm11
00007ff1409d1a70  punpcklqdq xmm12, xmm11
00007ff1409d1a75  movaps [r15+0x210], xmm12
00007ff1409d1a7d  movq xmm12, qword ptr [r15+0x140]
00007ff1409d1a86  movq xmm11, qword ptr [r15+0x120]
00007ff1409d1a8f  psubd xmm12, xmm11
00007ff1409d1a94  movq xmm12, xmm12
00007ff1409d1a99  paddq xmm13, xmm14
00007ff1409d1a9e  movaps [r15+0x180], xmm13
00007ff1409d1aa6  movq xmm14, qword ptr [r15+0x160]
00007ff1409d1aaf  paddd xmm11, xmm14
00007ff1409d1ab4  movq xmm11, xmm11
00007ff1409d1ab9  movq xmm11, xmm11
00007ff1409d1abe  movaps [r15+0x120], xmm11
00007ff1409d1ac6  pmovzxdq xmm12, xmm12
00007ff1409d1acc  psllq xmm12, 0x00
00007ff1409d1ad2  movq xmm14, qword ptr [r15+0x210]
00007ff1409d1adb  movq xmm13, qword ptr [r15+0x110]
00007ff1409d1ae4  paddd xmm14, xmm13
00007ff1409d1ae9  movq xmm14, xmm14
00007ff1409d1aee  vcvtuqq2pd xmm12, xmm12
00007ff1409d1af4  pmovzxdq xmm14, xmm14
00007ff1409d1afa  psllq xmm14, 0x00
00007ff1409d1b00  vcvtuqq2pd xmm14, xmm14
00007ff1409d1b06  movaps xmm13, xmm12
00007ff1409d1b0a  mulpd xmm13, xmm1
00007ff1409d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007ff1409d1b15  ptest xmm11, xmm11
00007ff1409d1b1b  jnz 0x00007FF1409D1C0F
00007ff1409d1b21  movaps [r15+0x220], xmm13
00007ff1409d1b29  mov eax, 0x432000
00007ff1409d1b2e  movups [r13+rax*1], xmm13
00007ff1409d1b34  movaps xmm1, xmm14
00007ff1409d1b38  mulpd xmm1, xmm15
00007ff1409d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007ff1409d1b42  ptest xmm13, xmm13
00007ff1409d1b48  jnz 0x00007FF1409D1D5C
00007ff1409d1b4e  movaps [r15+0x210], xmm1
00007ff1409d1b56  mov eax, 0x431E00
00007ff1409d1b5b  movups [r13+rax*1], xmm1
00007ff1409d1b61  mov qword ptr [r15+0x48], 0x10
00007ff1409d1b69  xor eax, eax
00007ff1409d1b6b  mov r14d, 0x10
00007ff1409d1b71  mov r12d, 0x200
00007ff1409d1b77  cmp r14, r12
00007ff1409d1b7a  cmc
00007ff1409d1b7b  lahf
00007ff1409d1b7c  seto al
00007ff1409d1b7f  mov [r15+0x108], eax
00007ff1409d1b86  mov eax, [r15+0x108]
00007ff1409d1b8d  sahf
00007ff1409d1b8e  jnz 0x00007FF1409D1BC0
00007ff1409d1b90  cmp dword ptr [r15+0x318], 0x00
00007ff1409d1b98  jz 0x00007FF1409D2300
00007ff1409d1b9e  nop [rax+rax*1], ax
00007ff1409d1ba7  nop [rax+rax*1], eax
00007ff1409d1baf  mov eax, 0x410490
00007ff1409d1bb4  mov [r15+0x100], rax
00007ff1409d1bbb  jmp 0x00007FF1407FE110
00007ff1409d1bc0  cmp dword ptr [r15+0x318], 0x00
00007ff1409d1bc8  jz 0x00007FF1409D1EB0
00007ff1409d1bce  nop [rax+rax*1], ax
00007ff1409d1bd7  nop [rax+rax*1], eax
00007ff1409d1bdf  mov eax, 0x410450
00007ff1409d1be4  mov [r15+0x100], rax
00007ff1409d1beb  jmp 0x00007FF1407FE110
00007ff1409d1bf0  int3
00007ff1409d1bf1  call 0x00007FF14080DC20
00007ff1409d1bf6  jmp 0x00007FF1409D19BE
00007ff1409d1bfb  call 0x00007FF14080C260
00007ff1409d1c00  jmp 0x00007FF1409D1A47
00007ff1409d1c05  call 0x00007FF1408D5D70
00007ff1409d1c0a  jmp 0x00007FF1409D1A5D
00007ff1409d1c0f  sub rsp, 0x08
00007ff1409d1c13  push rax
00007ff1409d1c14  push rcx
00007ff1409d1c15  push rdx
00007ff1409d1c16  push rdi
00007ff1409d1c17  push rsi
00007ff1409d1c18  push r8
00007ff1409d1c1a  push r9
00007ff1409d1c1c  push r10
00007ff1409d1c1e  push r11
00007ff1409d1c20  sub rsp, 0xF0
00007ff1409d1c27  vmovaps [rsp], xmm0
00007ff1409d1c2c  vmovaps [rsp+0x10], xmm1
00007ff1409d1c32  vmovaps [rsp+0x20], xmm2
00007ff1409d1c38  vmovaps [rsp+0x30], xmm3
00007ff1409d1c3e  vmovaps [rsp+0x40], xmm4
00007ff1409d1c44  vmovaps [rsp+0x50], xmm5
00007ff1409d1c4a  vmovaps [rsp+0x60], xmm6
00007ff1409d1c50  vmovaps [rsp+0x70], xmm7
00007ff1409d1c56  vmovaps [rsp+0x80], xmm8
00007ff1409d1c5f  vmovaps [rsp+0x90], xmm9
00007ff1409d1c68  vmovaps [rsp+0xA0], xmm10
00007ff1409d1c71  vmovaps [rsp+0xB0], xmm11
00007ff1409d1c7a  vmovaps [rsp+0xC0], xmm12
00007ff1409d1c83  vmovaps [rsp+0xD0], xmm14
00007ff1409d1c8c  vmovaps [rsp+0xE0], xmm15
00007ff1409d1c95  sub rsp, 0x30
00007ff1409d1c99  movaps [rsp], xmm13
00007ff1409d1c9e  movaps [rsp+0x10], xmm12
00007ff1409d1ca4  movaps [rsp+0x20], xmm1
00007ff1409d1ca9  lea rdi, [rsp]
00007ff1409d1cad  mov esi, 0x00
00007ff1409d1cb2  mov rax, 0x565C7F10C530
00007ff1409d1cbc  call rax
00007ff1409d1cbe  movaps xmm13, [rsp]
00007ff1409d1cc3  add rsp, 0x30
00007ff1409d1cc7  vmovaps xmm0, [rsp]
00007ff1409d1ccc  vmovaps xmm1, [rsp+0x10]
00007ff1409d1cd2  vmovaps xmm2, [rsp+0x20]
00007ff1409d1cd8  vmovaps xmm3, [rsp+0x30]
00007ff1409d1cde  vmovaps xmm4, [rsp+0x40]
00007ff1409d1ce4  vmovaps xmm5, [rsp+0x50]
00007ff1409d1cea  vmovaps xmm6, [rsp+0x60]
00007ff1409d1cf0  vmovaps xmm7, [rsp+0x70]
00007ff1409d1cf6  vmovaps xmm8, [rsp+0x80]
00007ff1409d1cff  vmovaps xmm9, [rsp+0x90]
00007ff1409d1d08  vmovaps xmm10, [rsp+0xA0]
00007ff1409d1d11  vmovaps xmm11, [rsp+0xB0]
00007ff1409d1d1a  vmovaps xmm12, [rsp+0xC0]
00007ff1409d1d23  vmovaps xmm14, [rsp+0xD0]
00007ff1409d1d2c  vmovaps xmm15, [rsp+0xE0]
00007ff1409d1d35  add rsp, 0xF0
00007ff1409d1d3c  pop r11
00007ff1409d1d3e  pop r10
00007ff1409d1d40  pop r9
00007ff1409d1d42  pop r8
00007ff1409d1d44  pop rsi
00007ff1409d1d45  pop rdi
00007ff1409d1d46  pop rdx
00007ff1409d1d47  pop rcx
00007ff1409d1d48  pop rax
00007ff1409d1d49  add rsp, 0x08
00007ff1409d1d4d  jmp 0x00007FF1409D1B21
00007ff1409d1d52  call 0x00007FF14080C380
00007ff1409d1d57  jmp 0x00007FF1409D1B34
00007ff1409d1d5c  sub rsp, 0x08
00007ff1409d1d60  push rax
00007ff1409d1d61  push rcx
00007ff1409d1d62  push rdx
00007ff1409d1d63  push rdi
00007ff1409d1d64  push rsi
00007ff1409d1d65  push r8
00007ff1409d1d67  push r9
00007ff1409d1d69  push r10
00007ff1409d1d6b  push r11
00007ff1409d1d6d  sub rsp, 0xF0
00007ff1409d1d74  vmovaps [rsp], xmm0
00007ff1409d1d79  vmovaps [rsp+0x10], xmm2
00007ff1409d1d7f  vmovaps [rsp+0x20], xmm3
00007ff1409d1d85  vmovaps [rsp+0x30], xmm4
00007ff1409d1d8b  vmovaps [rsp+0x40], xmm5
00007ff1409d1d91  vmovaps [rsp+0x50], xmm6
00007ff1409d1d97  vmovaps [rsp+0x60], xmm7
00007ff1409d1d9d  vmovaps [rsp+0x70], xmm8
00007ff1409d1da3  vmovaps [rsp+0x80], xmm9
00007ff1409d1dac  vmovaps [rsp+0x90], xmm10
00007ff1409d1db5  vmovaps [rsp+0xA0], xmm11
00007ff1409d1dbe  vmovaps [rsp+0xB0], xmm12
00007ff1409d1dc7  vmovaps [rsp+0xC0], xmm13
00007ff1409d1dd0  vmovaps [rsp+0xD0], xmm14
00007ff1409d1dd9  vmovaps [rsp+0xE0], xmm15
00007ff1409d1de2  sub rsp, 0x30
00007ff1409d1de6  movaps [rsp], xmm1
00007ff1409d1dea  movaps [rsp+0x10], xmm14
00007ff1409d1df0  movaps [rsp+0x20], xmm15
00007ff1409d1df6  lea rdi, [rsp]
00007ff1409d1dfa  mov esi, 0x00
00007ff1409d1dff  mov rax, 0x565C7F10C530
00007ff1409d1e09  call rax
00007ff1409d1e0b  movaps xmm1, [rsp]
00007ff1409d1e0f  add rsp, 0x30
00007ff1409d1e13  vmovaps xmm0, [rsp]
00007ff1409d1e18  vmovaps xmm2, [rsp+0x10]
00007ff1409d1e1e  vmovaps xmm3, [rsp+0x20]
00007ff1409d1e24  vmovaps xmm4, [rsp+0x30]
00007ff1409d1e2a  vmovaps xmm5, [rsp+0x40]
00007ff1409d1e30  vmovaps xmm6, [rsp+0x50]
00007ff1409d1e36  vmovaps xmm7, [rsp+0x60]
00007ff1409d1e3c  vmovaps xmm8, [rsp+0x70]
00007ff1409d1e42  vmovaps xmm9, [rsp+0x80]
00007ff1409d1e4b  vmovaps xmm10, [rsp+0x90]
00007ff1409d1e54  vmovaps xmm11, [rsp+0xA0]
00007ff1409d1e5d  vmovaps xmm12, [rsp+0xB0]
00007ff1409d1e66  vmovaps xmm13, [rsp+0xC0]
00007ff1409d1e6f  vmovaps xmm14, [rsp+0xD0]
00007ff1409d1e78  vmovaps xmm15, [rsp+0xE0]
00007ff1409d1e81  add rsp, 0xF0
00007ff1409d1e88  pop r11
00007ff1409d1e8a  pop r10
00007ff1409d1e8c  pop r9
00007ff1409d1e8e  pop r8
00007ff1409d1e90  pop rsi
00007ff1409d1e91  pop rdi
00007ff1409d1e92  pop rdx
00007ff1409d1e93  pop rcx
00007ff1409d1e94  pop rax
00007ff1409d1e95  add rsp, 0x08
00007ff1409d1e99  jmp 0x00007FF1409D1B4E
00007ff1409d1e9e  call 0x00007FF1407FF540
00007ff1409d1ea3  jmp 0x00007FF1409D1B61
00007ff1409d1ea8  int3
00007ff1409d1ea9  nop [rax], eax
00007ff1409d1eb0  movaps xmm1, [r15+0x180]
00007ff1409d1eb8  vpmovqd xmm15, xmm1
00007ff1409d1ebe  pxor xmm14, xmm14
00007ff1409d1ec3  punpcklqdq xmm15, xmm14
00007ff1409d1ec8  movaps [r15+0x210], xmm15
00007ff1409d1ed0  movq xmm15, qword ptr [r15+0x140]
00007ff1409d1ed9  movq xmm14, qword ptr [r15+0x120]
00007ff1409d1ee2  psubd xmm15, xmm14
00007ff1409d1ee7  movq xmm15, xmm15
00007ff1409d1eec  movaps xmm13, [r15+0x170]
00007ff1409d1ef4  paddq xmm1, xmm13
00007ff1409d1ef9  movaps [r15+0x180], xmm1
00007ff1409d1f01  movq xmm1, qword ptr [r15+0x160]
00007ff1409d1f0a  paddd xmm14, xmm1
00007ff1409d1f0f  movq xmm14, xmm14
00007ff1409d1f14  movq xmm14, xmm14
00007ff1409d1f19  movaps [r15+0x120], xmm14
00007ff1409d1f21  pmovzxdq xmm15, xmm15
00007ff1409d1f27  psllq xmm15, 0x00
00007ff1409d1f2d  movq xmm1, qword ptr [r15+0x210]
00007ff1409d1f36  movq xmm14, qword ptr [r15+0x110]
00007ff1409d1f3f  paddd xmm1, xmm14
00007ff1409d1f44  movq xmm1, xmm1
00007ff1409d1f48  vcvtuqq2pd xmm15, xmm15
00007ff1409d1f4e  pmovzxdq xmm1, xmm1
00007ff1409d1f53  psllq xmm1, 0x00
00007ff1409d1f58  vcvtuqq2pd xmm1, xmm1
00007ff1409d1f5e  movaps xmm14, [r15+0x150]
00007ff1409d1f66  movaps xmm13, xmm15
00007ff1409d1f6a  mulpd xmm13, xmm14
00007ff1409d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007ff1409d1f75  ptest xmm12, xmm12
00007ff1409d1f7b  jnz 0x00007FF1409D205E
00007ff1409d1f81  movaps [r15+0x220], xmm13
00007ff1409d1f89  mov rax, [r15+0x48]
00007ff1409d1f8d  mov r14, [r15+0x50]
00007ff1409d1f91  lea r12, [r14+rax*1]
00007ff1409d1f95  movups [r13+r12*1], xmm13
00007ff1409d1f9b  movaps xmm15, [r15+0x130]
00007ff1409d1fa3  movaps xmm14, xmm1
00007ff1409d1fa7  mulpd xmm14, xmm15
00007ff1409d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007ff1409d1fb2  ptest xmm13, xmm13
00007ff1409d1fb8  jnz 0x00007FF1409D21AC
00007ff1409d1fbe  movaps [r15+0x210], xmm14
00007ff1409d1fc6  mov r14, [r15+0x40]
00007ff1409d1fca  lea r12, [r14+rax*1]
00007ff1409d1fce  movups [r13+r12*1], xmm14
00007ff1409d1fd4  lea r14, [rax+0x10]
00007ff1409d1fd8  mov [r15+0x48], r14
00007ff1409d1fdc  xor eax, eax
00007ff1409d1fde  mov r12d, 0x200
00007ff1409d1fe4  cmp r14, r12
00007ff1409d1fe7  cmc
00007ff1409d1fe8  lahf
00007ff1409d1fe9  seto al
00007ff1409d1fec  mov [r15+0x108], eax
00007ff1409d1ff3  mov eax, [r15+0x108]
00007ff1409d1ffa  sahf
00007ff1409d1ffb  jnz 0x00007FF1409D202D
00007ff1409d1ffd  cmp dword ptr [r15+0x318], 0x00
00007ff1409d2005  jz 0x00007FF1409D2300
00007ff1409d200b  nop [rax+rax*1], ax
00007ff1409d2014  nop [rax+rax*1], eax
00007ff1409d201c  mov eax, 0x410490
00007ff1409d2021  mov [r15+0x100], rax
00007ff1409d2028  jmp 0x00007FF1407FE110
00007ff1409d202d  cmp dword ptr [r15+0x318], 0x00
00007ff1409d2035  jz 0x00007FF1409D1EB0
00007ff1409d203b  nop [rax+rax*1], ax
00007ff1409d2044  nop [rax+rax*1], eax
00007ff1409d204c  mov eax, 0x410450
00007ff1409d2051  mov [r15+0x100], rax
00007ff1409d2058  jmp 0x00007FF1407FE110
00007ff1409d205d  int3
00007ff1409d205e  sub rsp, 0x08
00007ff1409d2062  push rax
00007ff1409d2063  push rcx
00007ff1409d2064  push rdx
00007ff1409d2065  push rdi
00007ff1409d2066  push rsi
00007ff1409d2067  push r8
00007ff1409d2069  push r9
00007ff1409d206b  push r10
00007ff1409d206d  push r11
00007ff1409d206f  sub rsp, 0xF0
00007ff1409d2076  vmovaps [rsp], xmm0
00007ff1409d207b  vmovaps [rsp+0x10], xmm1
00007ff1409d2081  vmovaps [rsp+0x20], xmm2
00007ff1409d2087  vmovaps [rsp+0x30], xmm3
00007ff1409d208d  vmovaps [rsp+0x40], xmm4
00007ff1409d2093  vmovaps [rsp+0x50], xmm5
00007ff1409d2099  vmovaps [rsp+0x60], xmm6
00007ff1409d209f  vmovaps [rsp+0x70], xmm7
00007ff1409d20a5  vmovaps [rsp+0x80], xmm8
00007ff1409d20ae  vmovaps [rsp+0x90], xmm9
00007ff1409d20b7  vmovaps [rsp+0xA0], xmm10
00007ff1409d20c0  vmovaps [rsp+0xB0], xmm11
00007ff1409d20c9  vmovaps [rsp+0xC0], xmm12
00007ff1409d20d2  vmovaps [rsp+0xD0], xmm14
00007ff1409d20db  vmovaps [rsp+0xE0], xmm15
00007ff1409d20e4  sub rsp, 0x30
00007ff1409d20e8  movaps [rsp], xmm13
00007ff1409d20ed  movaps [rsp+0x10], xmm15
00007ff1409d20f3  movaps [rsp+0x20], xmm14
00007ff1409d20f9  lea rdi, [rsp]
00007ff1409d20fd  mov esi, 0x00
00007ff1409d2102  mov rax, 0x565C7F10C530
00007ff1409d210c  call rax
00007ff1409d210e  movaps xmm13, [rsp]
00007ff1409d2113  add rsp, 0x30
00007ff1409d2117  vmovaps xmm0, [rsp]
00007ff1409d211c  vmovaps xmm1, [rsp+0x10]
00007ff1409d2122  vmovaps xmm2, [rsp+0x20]
00007ff1409d2128  vmovaps xmm3, [rsp+0x30]
00007ff1409d212e  vmovaps xmm4, [rsp+0x40]
00007ff1409d2134  vmovaps xmm5, [rsp+0x50]
00007ff1409d213a  vmovaps xmm6, [rsp+0x60]
00007ff1409d2140  vmovaps xmm7, [rsp+0x70]
00007ff1409d2146  vmovaps xmm8, [rsp+0x80]
00007ff1409d214f  vmovaps xmm9, [rsp+0x90]
00007ff1409d2158  vmovaps xmm10, [rsp+0xA0]
00007ff1409d2161  vmovaps xmm11, [rsp+0xB0]
00007ff1409d216a  vmovaps xmm12, [rsp+0xC0]
00007ff1409d2173  vmovaps xmm14, [rsp+0xD0]
00007ff1409d217c  vmovaps xmm15, [rsp+0xE0]
00007ff1409d2185  add rsp, 0xF0
00007ff1409d218c  pop r11
00007ff1409d218e  pop r10
00007ff1409d2190  pop r9
00007ff1409d2192  pop r8
00007ff1409d2194  pop rsi
00007ff1409d2195  pop rdi
00007ff1409d2196  pop rdx
00007ff1409d2197  pop rcx
00007ff1409d2198  pop rax
00007ff1409d2199  add rsp, 0x08
00007ff1409d219d  jmp 0x00007FF1409D1F81
00007ff1409d21a2  call 0x00007FF1408C2240
00007ff1409d21a7  jmp 0x00007FF1409D1F9B
00007ff1409d21ac  sub rsp, 0x08
00007ff1409d21b0  push rax
00007ff1409d21b1  push rcx
00007ff1409d21b2  push rdx
00007ff1409d21b3  push rdi
00007ff1409d21b4  push rsi
00007ff1409d21b5  push r8
00007ff1409d21b7  push r9
00007ff1409d21b9  push r10
00007ff1409d21bb  push r11
00007ff1409d21bd  sub rsp, 0xF0
00007ff1409d21c4  vmovaps [rsp], xmm0
00007ff1409d21c9  vmovaps [rsp+0x10], xmm1
00007ff1409d21cf  vmovaps [rsp+0x20], xmm2
00007ff1409d21d5  vmovaps [rsp+0x30], xmm3
00007ff1409d21db  vmovaps [rsp+0x40], xmm4
00007ff1409d21e1  vmovaps [rsp+0x50], xmm5
00007ff1409d21e7  vmovaps [rsp+0x60], xmm6
00007ff1409d21ed  vmovaps [rsp+0x70], xmm7
00007ff1409d21f3  vmovaps [rsp+0x80], xmm8
00007ff1409d21fc  vmovaps [rsp+0x90], xmm9
00007ff1409d2205  vmovaps [rsp+0xA0], xmm10
00007ff1409d220e  vmovaps [rsp+0xB0], xmm11
00007ff1409d2217  vmovaps [rsp+0xC0], xmm12
00007ff1409d2220  vmovaps [rsp+0xD0], xmm13
00007ff1409d2229  vmovaps [rsp+0xE0], xmm15
00007ff1409d2232  sub rsp, 0x30
00007ff1409d2236  movaps [rsp], xmm14
00007ff1409d223b  movaps [rsp+0x10], xmm1
00007ff1409d2240  movaps [rsp+0x20], xmm15
00007ff1409d2246  lea rdi, [rsp]
00007ff1409d224a  mov esi, 0x00
00007ff1409d224f  mov rax, 0x565C7F10C530
00007ff1409d2259  call rax
00007ff1409d225b  movaps xmm14, [rsp]
00007ff1409d2260  add rsp, 0x30
00007ff1409d2264  vmovaps xmm0, [rsp]
00007ff1409d2269  vmovaps xmm1, [rsp+0x10]
00007ff1409d226f  vmovaps xmm2, [rsp+0x20]
00007ff1409d2275  vmovaps xmm3, [rsp+0x30]
00007ff1409d227b  vmovaps xmm4, [rsp+0x40]
00007ff1409d2281  vmovaps xmm5, [rsp+0x50]
00007ff1409d2287  vmovaps xmm6, [rsp+0x60]
00007ff1409d228d  vmovaps xmm7, [rsp+0x70]
00007ff1409d2293  vmovaps xmm8, [rsp+0x80]
00007ff1409d229c  vmovaps xmm9, [rsp+0x90]
00007ff1409d22a5  vmovaps xmm10, [rsp+0xA0]
00007ff1409d22ae  vmovaps xmm11, [rsp+0xB0]
00007ff1409d22b7  vmovaps xmm12, [rsp+0xC0]
00007ff1409d22c0  vmovaps xmm13, [rsp+0xD0]
00007ff1409d22c9  vmovaps xmm15, [rsp+0xE0]
00007ff1409d22d2  add rsp, 0xF0
00007ff1409d22d9  pop r11
00007ff1409d22db  pop r10
00007ff1409d22dd  pop r9
00007ff1409d22df  pop r8
00007ff1409d22e1  pop rsi
00007ff1409d22e2  pop rdi
00007ff1409d22e3  pop rdx
00007ff1409d22e4  pop rcx
00007ff1409d22e5  pop rax
00007ff1409d22e6  add rsp, 0x08
00007ff1409d22ea  jmp 0x00007FF1409D1FBE
00007ff1409d22ef  call 0x00007FF1408C34C0
00007ff1409d22f4  jmp 0x00007FF1409D1FD4
00007ff1409d22f9  int3
00007ff1409d22fa  nop [rax+rax*1], ax
00007ff1409d2300  mov rax, [r15+0x50]
00007ff1409d2304  lea r14, [rax+0x80]
00007ff1409d230b  movups xmm1, [r13+r14*1]
00007ff1409d2311  lea r14, [rax+0x90]
00007ff1409d2318  movups xmm15, [r13+r14*1]
00007ff1409d231e  vxorps xmm14, xmm14, xmm14
00007ff1409d2323  vpbroadcastq xmm14, xmm14
00007ff1409d2328  lea r14, [rax+0x40]
00007ff1409d232c  movups xmm13, [r13+r14*1]
00007ff1409d2332  lea r14, [rax+0x50]
00007ff1409d2336  movups xmm12, [r13+r14*1]
00007ff1409d233c  mov qword ptr [r15+0x48], 0x00
00007ff1409d2344  movups xmm11, [r13+rax*1]
00007ff1409d234a  lea r14, [rax+0x10]
00007ff1409d234e  movups xmm10, [r13+r14*1]
00007ff1409d2354  mov r14, [r15+0xF8]
00007ff1409d235b  lea r12, [r14+0xE0]
00007ff1409d2362  movups [r13+r12*1], xmm15
00007ff1409d2368  lea r12, [r14+0xF0]
00007ff1409d236f  movups [r13+r12*1], xmm1
00007ff1409d2375  lea r12, [rax+0xC0]
00007ff1409d237c  movups xmm1, [r13+r12*1]
00007ff1409d2382  lea r12, [rax+0xD0]
00007ff1409d2389  movups xmm15, [r13+r12*1]
00007ff1409d238f  lea r12, [rax+0x140]
00007ff1409d2396  movups xmm9, [r13+r12*1]
00007ff1409d239c  lea r12, [rax+0x150]
00007ff1409d23a3  movups xmm8, [r13+r12*1]
00007ff1409d23a9  lea r12, [rax+0x180]
00007ff1409d23b0  movups xmm7, [r13+r12*1]
00007ff1409d23b6  lea r12, [rax+0x190]
00007ff1409d23bd  movups xmm6, [r13+r12*1]
00007ff1409d23c3  lea r12, [r14+0xC0]
00007ff1409d23ca  movups [r13+r12*1], xmm15
00007ff1409d23d0  lea r12, [r14+0xD0]
00007ff1409d23d7  movups [r13+r12*1], xmm1
00007ff1409d23dd  lea r12, [rax+0x100]
00007ff1409d23e4  movups xmm1, [r13+r12*1]
00007ff1409d23ea  lea r12, [rax+0x110]
00007ff1409d23f1  movups xmm15, [r13+r12*1]
00007ff1409d23f7  lea r12, [rax+0x1C0]
00007ff1409d23fe  movups xmm5, [r13+r12*1]
00007ff1409d2404  lea r12, [rax+0x1D0]
00007ff1409d240b  movups xmm4, [r13+r12*1]
00007ff1409d2411  lea r12, [rax+0x20]
00007ff1409d2415  movups xmm3, [r13+r12*1]
00007ff1409d241b  lea r12, [rax+0x30]
00007ff1409d241f  movups xmm2, [r13+r12*1]
00007ff1409d2425  movaps [r15+0x1F0], xmm2
00007ff1409d242d  lea r12, [r14+0x20]
00007ff1409d2431  movups [r13+r12*1], xmm1
00007ff1409d2437  lea r12, [r14+0x30]
00007ff1409d243b  movups [r13+r12*1], xmm12
00007ff1409d2441  lea r12, [rax+0x60]
00007ff1409d2445  movups xmm1, [r13+r12*1]
00007ff1409d244b  lea r12, [rax+0x70]
00007ff1409d244f  movups xmm12, [r13+r12*1]
00007ff1409d2455  lea r12, [r14+0x60]
00007ff1409d2459  movups [r13+r12*1], xmm11
00007ff1409d245f  lea r12, [r14+0x70]
00007ff1409d2463  movups [r13+r12*1], xmm5
00007ff1409d2469  lea r12, [rax+0xE0]
00007ff1409d2470  movups xmm11, [r13+r12*1]
00007ff1409d2476  lea r12, [rax+0xF0]
00007ff1409d247d  movups xmm5, [r13+r12*1]
00007ff1409d2483  lea r12, [rax+0x120]
00007ff1409d248a  vmovaps [rsp+0x10], xmm1
00007ff1409d2490  movups xmm1, [r13+r12*1]
00007ff1409d2496  lea r12, [rax+0x130]
00007ff1409d249d  vmovaps [rsp+0x20], xmm1
00007ff1409d24a3  movups xmm1, [r13+r12*1]
00007ff1409d24a9  lea r12, [r14+0xA0]
00007ff1409d24b0  movups [r13+r12*1], xmm12
00007ff1409d24b6  lea r12, [r14+0xB0]
00007ff1409d24bd  vmovaps xmm12, [rsp+0x10]
00007ff1409d24c3  movups [r13+r12*1], xmm12
00007ff1409d24c9  lea r12, [rax+0xA0]
00007ff1409d24d0  movups xmm12, [r13+r12*1]
00007ff1409d24d6  lea r12, [rax+0xB0]
00007ff1409d24dd  vmovaps [rsp+0x10], xmm1
00007ff1409d24e3  movups xmm1, [r13+r12*1]
00007ff1409d24e9  lea r12, [rax+0x160]
00007ff1409d24f0  vmovaps [rsp+0x30], xmm1
00007ff1409d24f6  movups xmm1, [r13+r12*1]
00007ff1409d24fc  lea r12, [rax+0x170]
00007ff1409d2503  vmovaps [rsp+0x40], xmm1
00007ff1409d2509  movups xmm1, [r13+r12*1]
00007ff1409d250f  movaps [r15+0x2B0], xmm1
00007ff1409d2517  lea r12, [rax+0x1A0]
00007ff1409d251e  vmovaps [rsp+0x50], xmm1
00007ff1409d2524  movups xmm1, [r13+r12*1]
00007ff1409d252a  lea r12, [rax+0x1B0]
00007ff1409d2531  vmovaps [rsp+0x60], xmm1
00007ff1409d2537  movups xmm1, [r13+r12*1]
00007ff1409d253d  vmovaps [rsp+0x70], xmm1
00007ff1409d2543  vmovaps xmm1, [rsp+0x60]
00007ff1409d2549  movaps [r15+0x290], xmm1
00007ff1409d2551  vmovaps [rsp+0x60], xmm1
00007ff1409d2557  vmovaps xmm1, [rsp+0x70]
00007ff1409d255d  movaps [r15+0x1E0], xmm1
00007ff1409d2565  lea r12, [r14+0x80]
00007ff1409d256c  vmovaps [rsp+0x70], xmm1
00007ff1409d2572  vmovaps xmm1, [rsp+0x30]
00007ff1409d2578  movups [r13+r12*1], xmm1
00007ff1409d257e  lea r12, [r14+0x90]
00007ff1409d2585  movups [r13+r12*1], xmm12
00007ff1409d258b  lea r12, [rax+0x1E0]
00007ff1409d2592  movups xmm1, [r13+r12*1]
00007ff1409d2598  lea r12, [rax+0x1F0]
00007ff1409d259f  movups xmm12, [r13+r12*1]
00007ff1409d25a5  mov qword ptr [r15+0x50], 0x432200
00007ff1409d25ad  lea rax, [r14+0x40]
00007ff1409d25b1  vmovaps [rsp+0x30], xmm1
00007ff1409d25b7  vmovaps xmm1, [rsp+0x40]
00007ff1409d25bd  movups [r13+rax*1], xmm1
00007ff1409d25c3  lea rax, [r14+0x50]
00007ff1409d25c7  movups [r13+rax*1], xmm10
00007ff1409d25cd  movups [r13+r14*1], xmm12
00007ff1409d25d3  lea rax, [r14+0x10]
00007ff1409d25d7  vmovaps xmm1, [rsp+0x30]
00007ff1409d25dd  movups [r13+rax*1], xmm1
00007ff1409d25e3  mov rax, [r15+0x40]
00007ff1409d25e7  vmovaps [rsp+0x30], xmm3
00007ff1409d25ed  vmovaps xmm1, [rsp+0x30]
00007ff1409d25f3  por xmm3, xmm1
00007ff1409d25f7  vmovaps [rsp+0x30], xmm6
00007ff1409d25fd  vmovaps xmm12, [rsp+0x30]
00007ff1409d2603  por xmm6, xmm12
00007ff1409d2608  lea r12, [rax+0x30]
00007ff1409d260c  mov r11, [r13+r12*1]
00007ff1409d2611  lea r12, [rax+0x38]
00007ff1409d2615  mov r10, [r13+r12*1]
00007ff1409d261a  movq xmm12, r11
00007ff1409d261f  movq xmm10, r10
00007ff1409d2624  movq xmm12, xmm12
00007ff1409d2629  vmovaps [rsp+0x30], xmm12
00007ff1409d262f  movq xmm12, xmm12
00007ff1409d2634  movaps [r15+0x130], xmm12
00007ff1409d263c  movq xmm10, xmm10
00007ff1409d2641  vmovaps [rsp+0x40], xmm10
00007ff1409d2647  movq xmm10, xmm10
00007ff1409d264c  movaps [r15+0x280], xmm10
00007ff1409d2654  vmovaps [rsp+0x80], xmm9
00007ff1409d265d  vmovaps xmm12, [rsp+0x80]
00007ff1409d2666  por xmm9, xmm12
00007ff1409d266b  lea r12, [rax+0x20]
00007ff1409d266f  mov r11, [r13+r12*1]
00007ff1409d2674  lea r12, [rax+0x28]
00007ff1409d2678  mov r10, [r13+r12*1]
00007ff1409d267d  movq xmm12, r11
00007ff1409d2682  movq xmm10, r10
00007ff1409d2687  movq xmm12, xmm12
00007ff1409d268c  vmovaps [rsp+0x80], xmm12
00007ff1409d2695  movq xmm12, xmm12
00007ff1409d269a  movaps [r15+0x150], xmm12
00007ff1409d26a2  movq xmm10, xmm10
00007ff1409d26a7  vmovaps [rsp+0x90], xmm10
00007ff1409d26b0  movq xmm10, xmm10
00007ff1409d26b5  movaps [r15+0x140], xmm10
00007ff1409d26bd  lea r12, [rax+0x10]
00007ff1409d26c1  mov r11, [r13+r12*1]
00007ff1409d26c6  lea r12, [rax+0x18]
00007ff1409d26ca  mov r10, [r13+r12*1]
00007ff1409d26cf  movq xmm12, r11
00007ff1409d26d4  movq xmm10, r10
00007ff1409d26d9  movq xmm12, xmm12
00007ff1409d26de  vmovaps [rsp+0xA0], xmm12
00007ff1409d26e7  movq xmm12, xmm12
00007ff1409d26ec  movaps [r15+0x170], xmm12
00007ff1409d26f4  movq xmm10, xmm10
00007ff1409d26f9  vmovaps [rsp+0xB0], xmm10
00007ff1409d2702  movq xmm10, xmm10
00007ff1409d2707  movaps [r15+0x160], xmm10
00007ff1409d270f  mov r12, [r13+rax*1]
00007ff1409d2714  vmovq xmm12, r12
00007ff1409d2719  vpbroadcastq xmm12, xmm12
00007ff1409d271e  lea r12, [rax+0x08]
00007ff1409d2722  mov rax, [r13+r12*1]
00007ff1409d2727  movq xmm10, rax
00007ff1409d272c  movaps [r15+0x230], xmm10
00007ff1409d2734  lea rax, [r14+0x50]
00007ff1409d2738  movups xmm10, [r13+rax*1]
00007ff1409d273e  lea rax, [r14+0x60]
00007ff1409d2742  vmovaps [rsp+0xC0], xmm1
00007ff1409d274b  movups xmm1, [r13+rax*1]
00007ff1409d2751  lea rax, [r14+0x30]
00007ff1409d2755  vmovaps [rsp+0xD0], xmm1
00007ff1409d275e  movups xmm1, [r13+rax*1]
00007ff1409d2764  mov qword ptr [r15+0x60], 0x432200
00007ff1409d276c  mov qword ptr [r15+0x58], 0x40
00007ff1409d2774  vmovaps [rsp+0xE0], xmm1
00007ff1409d277d  vmovaps [rsp+0xF0], xmm15
00007ff1409d2786  vmovaps xmm15, [rsp+0xC0]
00007ff1409d278f  vmovaps [rsp+0xC0], xmm14
00007ff1409d2798  movaps xmm1, xmm12
00007ff1409d279c  mulpd xmm1, xmm15
00007ff1409d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007ff1409d27a6  ptest xmm14, xmm14
00007ff1409d27ac  jnz 0x00007FF1409D3863
00007ff1409d27b2  movq xmm15, qword ptr [r15+0x230]
00007ff1409d27bb  vmovaps [rsp+0x100], xmm15
00007ff1409d27c4  vpermilpd xmm15, xmm15, 0x00
00007ff1409d27ca  vmovaps [rsp+0x110], xmm1
00007ff1409d27d3  vmovaps xmm1, [rsp+0xE0]
00007ff1409d27dc  vmovaps [rsp+0xE0], xmm13
00007ff1409d27e5  movaps xmm14, xmm1
00007ff1409d27e9  mulpd xmm14, xmm15
00007ff1409d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007ff1409d27f4  ptest xmm13, xmm13
00007ff1409d27fa  jnz 0x00007FF1409D39A5
00007ff1409d2800  vxorps xmm1, xmm1, xmm1
00007ff1409d2804  vpbroadcastq xmm1, xmm1
00007ff1409d2809  vmovaps xmm13, [rsp+0xD0]
00007ff1409d2812  vmovaps [rsp+0xD0], xmm1
00007ff1409d281b  movaps xmm15, xmm12
00007ff1409d281f  mulpd xmm15, xmm13
00007ff1409d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007ff1409d282a  ptest xmm1, xmm1
00007ff1409d282f  jnz 0x00007FF1409D3AE8
00007ff1409d2835  movaps xmm1, xmm12
00007ff1409d2839  mulpd xmm1, xmm10
00007ff1409d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007ff1409d2843  ptest xmm13, xmm13
00007ff1409d2849  jnz 0x00007FF1409D3C2C
00007ff1409d284f  movaps xmm13, xmm12
00007ff1409d2853  mulpd xmm13, xmm2
00007ff1409d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007ff1409d285e  ptest xmm10, xmm10
00007ff1409d2864  jnz 0x00007FF1409D3D6E
00007ff1409d286a  vmovaps [rsp+0x120], xmm7
00007ff1409d2873  vmovaps xmm12, [rsp+0x120]
00007ff1409d287c  por xmm7, xmm12
00007ff1409d2881  vmovaps xmm12, [rsp+0xE0]
00007ff1409d288a  vmovaps xmm10, [rsp+0xE0]
00007ff1409d2893  por xmm12, xmm10
00007ff1409d2898  vmovaps xmm2, [rsp+0x100]
00007ff1409d28a1  vpermilpd xmm2, xmm2, 0x00
00007ff1409d28a7  vmovaps [rsp+0xE0], xmm1
00007ff1409d28b0  vmovaps [rsp+0x120], xmm15
00007ff1409d28b9  movaps xmm1, xmm10
00007ff1409d28bd  mulpd xmm1, xmm2
00007ff1409d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007ff1409d28c6  ptest xmm15, xmm15
00007ff1409d28cc  jnz 0x00007FF1409D3EB1
00007ff1409d28d2  xor eax, eax
00007ff1409d28d4  mov r12d, 0x40
00007ff1409d28da  mov r11d, 0x200
00007ff1409d28e0  cmp r12, r11
00007ff1409d28e3  cmc
00007ff1409d28e4  lahf
00007ff1409d28e5  seto al
00007ff1409d28e8  mov [r15+0x108], eax
00007ff1409d28ef  vmovaps xmm10, [rsp+0x110]
00007ff1409d28f8  vmovaps xmm2, [rsp+0xD0]
00007ff1409d2901  vmovaps [rsp+0xD0], xmm1
00007ff1409d290a  movaps xmm15, xmm10
00007ff1409d290e  addpd xmm15, xmm2
00007ff1409d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007ff1409d2919  ptest xmm1, xmm1
00007ff1409d291e  jnz 0x00007FF1409D3FF2
00007ff1409d2924  vmovaps xmm10, [rsp+0x120]
00007ff1409d292d  vmovaps [rsp+0x110], xmm15
00007ff1409d2936  vmovaps xmm15, [rsp+0xC0]
00007ff1409d293f  vmovaps [rsp+0xC0], xmm14
00007ff1409d2948  movaps xmm1, xmm10
00007ff1409d294c  addpd xmm1, xmm15
00007ff1409d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007ff1409d2956  ptest xmm14, xmm14
00007ff1409d295c  jnz 0x00007FF1409D4135
00007ff1409d2962  vmovaps xmm10, [rsp+0xE0]
00007ff1409d296b  vmovaps [rsp+0xE0], xmm1
00007ff1409d2974  movaps xmm14, xmm10
00007ff1409d2978  addpd xmm14, xmm15
00007ff1409d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007ff1409d2983  ptest xmm1, xmm1
00007ff1409d2988  jnz 0x00007FF1409D4277
00007ff1409d298e  vmovaps xmm1, [rsp+0x10]
00007ff1409d2994  vmovaps xmm15, [rsp+0x10]
00007ff1409d299a  por xmm1, xmm15
00007ff1409d299f  vmovaps xmm15, [rsp+0x20]
00007ff1409d29a5  vmovaps xmm10, [rsp+0x20]
00007ff1409d29ab  por xmm15, xmm10
00007ff1409d29b0  vmovaps [rsp+0x10], xmm5
00007ff1409d29b6  vmovaps xmm10, [rsp+0x10]
00007ff1409d29bc  por xmm5, xmm10
00007ff1409d29c1  vmovaps [rsp+0x10], xmm11
00007ff1409d29c7  vmovaps xmm10, [rsp+0x10]
00007ff1409d29cd  por xmm11, xmm10
00007ff1409d29d2  vmovaps [rsp+0x10], xmm4
00007ff1409d29d8  vmovaps xmm10, [rsp+0x10]
00007ff1409d29de  por xmm4, xmm10
00007ff1409d29e3  vmovaps [rsp+0x10], xmm8
00007ff1409d29e9  vmovaps xmm10, [rsp+0x10]
00007ff1409d29ef  por xmm8, xmm10
00007ff1409d29f4  vmovaps xmm10, [rsp+0xF0]
00007ff1409d29fd  vmovaps [rsp+0x10], xmm1
00007ff1409d2a03  vmovaps xmm1, [rsp+0xF0]
00007ff1409d2a0c  por xmm10, xmm1
00007ff1409d2a11  lea rax, [r14+0xA0]
00007ff1409d2a18  movups xmm1, [r13+rax*1]
00007ff1409d2a1e  lea rax, [r14+0xB0]
00007ff1409d2a25  vmovaps [rsp+0x20], xmm1
00007ff1409d2a2b  movups xmm1, [r13+rax*1]
00007ff1409d2a31  vmovaps [rsp+0xF0], xmm1
00007ff1409d2a3a  vmovaps [rsp+0x120], xmm15
00007ff1409d2a43  movaps xmm1, xmm13
00007ff1409d2a47  addpd xmm1, xmm2
00007ff1409d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007ff1409d2a50  ptest xmm15, xmm15
00007ff1409d2a56  jnz 0x00007FF1409D43CF
00007ff1409d2a5c  lea rax, [r14+0xF0]
00007ff1409d2a63  movups xmm15, [r13+rax*1]
00007ff1409d2a69  vmovaps xmm2, [rsp+0xE0]
00007ff1409d2a72  vmovaps [rsp+0xE0], xmm1
00007ff1409d2a7b  vmovaps xmm1, [rsp+0xD0]
00007ff1409d2a84  vmovaps [rsp+0xD0], xmm15
00007ff1409d2a8d  movaps xmm13, xmm2
00007ff1409d2a91  addpd xmm13, xmm1
00007ff1409d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007ff1409d2a9c  ptest xmm15, xmm15
00007ff1409d2aa2  jnz 0x00007FF1409D451A
00007ff1409d2aa8  vmovaps xmm15, [rsp+0xC0]
00007ff1409d2ab1  movaps xmm1, xmm14
00007ff1409d2ab5  addpd xmm1, xmm15
00007ff1409d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007ff1409d2abf  ptest xmm2, xmm2
00007ff1409d2ac4  jnz 0x00007FF1409D465C
00007ff1409d2aca  vmovaps xmm15, [rsp+0x100]
00007ff1409d2ad3  vpermilpd xmm15, xmm15, 0x00
00007ff1409d2ad9  vmovaps xmm2, [rsp+0xF0]
00007ff1409d2ae2  vmovaps [rsp+0xC0], xmm1
00007ff1409d2aeb  movaps xmm14, xmm2
00007ff1409d2aef  mulpd xmm14, xmm15
00007ff1409d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007ff1409d2afa  ptest xmm1, xmm1
00007ff1409d2aff  jnz 0x00007FF1409D479E
00007ff1409d2b05  vmovaps xmm1, [rsp+0xA0]
00007ff1409d2b0e  vpermilpd xmm1, xmm1, 0x00
00007ff1409d2b14  vmovaps xmm2, [rsp+0xD0]
00007ff1409d2b1d  vmovaps [rsp+0xD0], xmm14
00007ff1409d2b26  movaps xmm15, xmm2
00007ff1409d2b2a  mulpd xmm15, xmm1
00007ff1409d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007ff1409d2b35  ptest xmm14, xmm14
00007ff1409d2b3b  jnz 0x00007FF1409D48E1
00007ff1409d2b41  lea rax, [r14+0xE0]
00007ff1409d2b48  movups xmm1, [r13+rax*1]
00007ff1409d2b4e  vmovaps xmm14, [rsp+0x100]
00007ff1409d2b57  vpermilpd xmm14, xmm14, 0x00
00007ff1409d2b5d  vmovaps [rsp+0xF0], xmm1
00007ff1409d2b66  vmovaps xmm1, [rsp+0x20]
00007ff1409d2b6c  vmovaps [rsp+0x20], xmm15
00007ff1409d2b72  movaps xmm2, xmm1
00007ff1409d2b75  mulpd xmm2, xmm14
00007ff1409d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007ff1409d2b7f  ptest xmm15, xmm15
00007ff1409d2b85  jnz 0x00007FF1409D4A2D
00007ff1409d2b8b  vmovaps [rsp+0x100], xmm10
00007ff1409d2b94  vmovaps xmm1, [rsp+0x100]
00007ff1409d2b9d  por xmm10, xmm1
00007ff1409d2ba2  movaps [r15+0x300], xmm10
00007ff1409d2baa  vmovaps [rsp+0x100], xmm8
00007ff1409d2bb3  vmovaps xmm1, [rsp+0x100]
00007ff1409d2bbc  por xmm8, xmm1
00007ff1409d2bc1  movaps [r15+0x190], xmm8
00007ff1409d2bc9  vmovaps xmm1, [rsp+0xA0]
00007ff1409d2bd2  vpermilpd xmm1, xmm1, 0x00
00007ff1409d2bd8  vmovaps xmm14, [rsp+0xF0]
00007ff1409d2be1  vmovaps [rsp+0xF0], xmm13
00007ff1409d2bea  movaps xmm15, xmm14
00007ff1409d2bee  mulpd xmm15, xmm1
00007ff1409d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007ff1409d2bf9  ptest xmm13, xmm13
00007ff1409d2bff  jnz 0x00007FF1409D4B6E
00007ff1409d2c05  lea rax, [r14+0x90]
00007ff1409d2c0c  movups xmm1, [r13+rax*1]
00007ff1409d2c12  vmovaps [rsp+0x100], xmm4
00007ff1409d2c1b  vmovaps xmm14, [rsp+0x100]
00007ff1409d2c24  por xmm4, xmm14
00007ff1409d2c29  movaps [r15+0x1C0], xmm4
00007ff1409d2c31  vmovaps [rsp+0x100], xmm11
00007ff1409d2c3a  vmovaps xmm14, [rsp+0x100]
00007ff1409d2c43  por xmm11, xmm14
00007ff1409d2c48  movaps [r15+0x200], xmm11
00007ff1409d2c50  vmovaps [rsp+0x100], xmm5
00007ff1409d2c59  vmovaps xmm14, [rsp+0x100]
00007ff1409d2c62  por xmm5, xmm14
00007ff1409d2c67  movaps [r15+0x2D0], xmm5
00007ff1409d2c6f  vmovaps xmm14, [rsp+0x120]
00007ff1409d2c78  vmovaps xmm13, [rsp+0x120]
00007ff1409d2c81  por xmm14, xmm13
00007ff1409d2c86  movaps [r15+0x2E0], xmm14
00007ff1409d2c8e  vmovaps [rsp+0x100], xmm1
00007ff1409d2c97  vmovaps xmm1, [rsp+0x110]
00007ff1409d2ca0  vmovaps [rsp+0x110], xmm15
00007ff1409d2ca9  vmovaps xmm15, [rsp+0xD0]
00007ff1409d2cb2  vmovaps [rsp+0xD0], xmm14
00007ff1409d2cbb  movaps xmm13, xmm1
00007ff1409d2cbf  addpd xmm13, xmm15
00007ff1409d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007ff1409d2cca  ptest xmm14, xmm14
00007ff1409d2cd0  jnz 0x00007FF1409D4CBB
00007ff1409d2cd6  vmovaps xmm1, [rsp+0xA0]
00007ff1409d2cdf  vpermilpd xmm1, xmm1, 0x00
00007ff1409d2ce5  vmovaps xmm14, [rsp+0x100]
00007ff1409d2cee  vmovaps [rsp+0x100], xmm13
00007ff1409d2cf7  movaps xmm15, xmm14
00007ff1409d2cfb  mulpd xmm15, xmm1
00007ff1409d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007ff1409d2d06  ptest xmm13, xmm13
00007ff1409d2d0c  jnz 0x00007FF1409D4DFE
00007ff1409d2d12  lea rax, [r14+0x80]
00007ff1409d2d19  movups xmm1, [r13+rax*1]
00007ff1409d2d1f  vmovaps xmm13, [rsp+0xE0]
00007ff1409d2d28  vmovaps [rsp+0xE0], xmm1
00007ff1409d2d31  movaps xmm14, xmm13
00007ff1409d2d35  addpd xmm14, xmm2
00007ff1409d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007ff1409d2d40  ptest xmm1, xmm1
00007ff1409d2d45  jnz 0x00007FF1409D4F4B
00007ff1409d2d4b  vmovaps xmm13, [rsp+0xF0]
00007ff1409d2d54  vmovaps xmm2, [rsp+0x20]
00007ff1409d2d5a  vmovaps [rsp+0x20], xmm15
00007ff1409d2d60  movaps xmm1, xmm13
00007ff1409d2d64  addpd xmm1, xmm2
00007ff1409d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007ff1409d2d6d  ptest xmm15, xmm15
00007ff1409d2d73  jnz 0x00007FF1409D508E
00007ff1409d2d79  vmovaps xmm15, [rsp+0x10]
00007ff1409d2d7f  vmovaps xmm13, [rsp+0x10]
00007ff1409d2d85  por xmm15, xmm13
00007ff1409d2d8a  movaps [r15+0x2F0], xmm15
00007ff1409d2d92  vmovaps xmm13, [rsp+0xA0]
00007ff1409d2d9b  vpermilpd xmm13, xmm13, 0x00
00007ff1409d2da1  vmovaps [rsp+0x10], xmm1
00007ff1409d2da7  vmovaps xmm1, [rsp+0xE0]
00007ff1409d2db0  vmovaps [rsp+0xA0], xmm15
00007ff1409d2db9  movaps xmm2, xmm1
00007ff1409d2dbc  mulpd xmm2, xmm13
00007ff1409d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007ff1409d2dc6  ptest xmm15, xmm15
00007ff1409d2dcc  jnz 0x00007FF1409D51CF
00007ff1409d2dd2  lea rax, [r14+0xD0]
00007ff1409d2dd9  movups xmm1, [r13+rax*1]
00007ff1409d2ddf  vmovaps xmm13, [rsp+0xC0]
00007ff1409d2de8  vmovaps [rsp+0xC0], xmm1
00007ff1409d2df1  vmovaps xmm1, [rsp+0x110]
00007ff1409d2dfa  vmovaps [rsp+0xE0], xmm14
00007ff1409d2e03  movaps xmm15, xmm13
00007ff1409d2e07  addpd xmm15, xmm1
00007ff1409d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007ff1409d2e12  ptest xmm14, xmm14
00007ff1409d2e18  jnz 0x00007FF1409D531A
00007ff1409d2e1e  vmovaps xmm1, [rsp+0xB0]
00007ff1409d2e27  vpermilpd xmm1, xmm1, 0x00
00007ff1409d2e2d  movaps xmm14, xmm11
00007ff1409d2e31  mulpd xmm14, xmm1
00007ff1409d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007ff1409d2e3c  ptest xmm13, xmm13
00007ff1409d2e42  jnz 0x00007FF1409D545D
00007ff1409d2e48  movaps [r15+0x260], xmm14
00007ff1409d2e50  vxorps xmm1, xmm1, xmm1
00007ff1409d2e54  vpbroadcastq xmm1, xmm1
00007ff1409d2e59  movaps [r15+0x1B0], xmm1
00007ff1409d2e61  vmovaps xmm1, [rsp+0xB0]
00007ff1409d2e6a  vpermilpd xmm1, xmm1, 0x00
00007ff1409d2e70  vmovaps xmm11, [rsp+0xC0]
00007ff1409d2e79  vmovaps [rsp+0xC0], xmm15
00007ff1409d2e82  movaps xmm13, xmm11
00007ff1409d2e86  mulpd xmm13, xmm1
00007ff1409d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007ff1409d2e91  ptest xmm15, xmm15
00007ff1409d2e97  jnz 0x00007FF1409D55A0
00007ff1409d2e9d  lea rax, [r14+0xC0]
00007ff1409d2ea4  movups xmm1, [r13+rax*1]
00007ff1409d2eaa  vmovaps xmm11, [rsp+0x100]
00007ff1409d2eb3  vmovaps [rsp+0xF0], xmm1
00007ff1409d2ebc  vmovaps xmm1, [rsp+0x20]
00007ff1409d2ec2  vmovaps [rsp+0x20], xmm14
00007ff1409d2ec8  movaps xmm15, xmm11
00007ff1409d2ecc  addpd xmm15, xmm1
00007ff1409d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007ff1409d2ed7  ptest xmm14, xmm14
00007ff1409d2edd  jnz 0x00007FF1409D56ED
00007ff1409d2ee3  vmovaps [rsp+0x100], xmm9
00007ff1409d2eec  vmovaps xmm1, [rsp+0x100]
00007ff1409d2ef5  por xmm9, xmm1
00007ff1409d2efa  movaps [r15+0x270], xmm9
00007ff1409d2f02  vmovaps [rsp+0x100], xmm6
00007ff1409d2f0b  vmovaps xmm1, [rsp+0x100]
00007ff1409d2f14  por xmm6, xmm1
00007ff1409d2f18  movaps [r15+0x1A0], xmm6
00007ff1409d2f20  vmovaps xmm14, [rsp+0xB0]
00007ff1409d2f29  vpermilpd xmm14, xmm14, 0x00
00007ff1409d2f2f  vmovaps xmm6, [rsp+0xF0]
00007ff1409d2f38  vmovaps [rsp+0xF0], xmm1
00007ff1409d2f41  movaps xmm11, xmm6
00007ff1409d2f45  mulpd xmm11, xmm14
00007ff1409d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007ff1409d2f50  ptest xmm1, xmm1
00007ff1409d2f55  jnz 0x00007FF1409D5830
00007ff1409d2f5b  lea rax, [r14+0x20]
00007ff1409d2f5f  movups xmm1, [r13+rax*1]
00007ff1409d2f65  movaps [r15+0x110], xmm1
00007ff1409d2f6d  vmovaps xmm6, [rsp+0xE0]
00007ff1409d2f76  vmovaps [rsp+0xE0], xmm1
00007ff1409d2f7f  movaps xmm14, xmm6
00007ff1409d2f83  addpd xmm14, xmm2
00007ff1409d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007ff1409d2f8e  ptest xmm1, xmm1
00007ff1409d2f93  jnz 0x00007FF1409D597D
00007ff1409d2f99  vmovaps xmm1, [rsp+0xB0]
00007ff1409d2fa2  vpermilpd xmm1, xmm1, 0x00
00007ff1409d2fa8  movaps xmm6, xmm5
00007ff1409d2fab  mulpd xmm6, xmm1
00007ff1409d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007ff1409d2fb4  ptest xmm2, xmm2
00007ff1409d2fb9  jnz 0x00007FF1409D5ABF
00007ff1409d2fbf  vmovaps xmm5, [rsp+0x10]
00007ff1409d2fc5  movaps xmm1, xmm5
00007ff1409d2fc8  addpd xmm1, xmm13
00007ff1409d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007ff1409d2fd2  ptest xmm2, xmm2
00007ff1409d2fd7  jnz 0x00007FF1409D5BFF
00007ff1409d2fdd  vmovaps xmm13, [rsp+0x80]
00007ff1409d2fe6  vpermilpd xmm13, xmm13, 0x00
00007ff1409d2fec  vmovaps xmm2, [rsp+0xE0]
00007ff1409d2ff5  vmovaps [rsp+0x10], xmm1
00007ff1409d2ffb  movaps xmm5, xmm2
00007ff1409d2ffe  mulpd xmm5, xmm13
00007ff1409d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007ff1409d3008  ptest xmm1, xmm1
00007ff1409d300d  jnz 0x00007FF1409D5D40
00007ff1409d3013  vmovaps xmm1, [rsp+0x80]
00007ff1409d301c  vpermilpd xmm1, xmm1, 0x00
00007ff1409d3022  movaps xmm13, xmm10
00007ff1409d3026  mulpd xmm13, xmm1
00007ff1409d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007ff1409d3031  ptest xmm2, xmm2
00007ff1409d3036  jnz 0x00007FF1409D5E81
00007ff1409d303c  vmovaps xmm10, [rsp+0x20]
00007ff1409d3042  movaps xmm1, xmm15
00007ff1409d3046  addpd xmm1, xmm10
00007ff1409d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007ff1409d3050  ptest xmm2, xmm2
00007ff1409d3055  jnz 0x00007FF1409D5FC4
00007ff1409d305b  vmovaps xmm10, [rsp+0xC0]
00007ff1409d3064  movaps xmm15, xmm10
00007ff1409d3068  addpd xmm15, xmm11
00007ff1409d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007ff1409d3073  ptest xmm2, xmm2
00007ff1409d3078  jnz 0x00007FF1409D6106
00007ff1409d307e  vmovaps xmm11, [rsp+0x80]
00007ff1409d3087  vpermilpd xmm11, xmm11, 0x00
00007ff1409d308d  vmovaps xmm2, [rsp+0xD0]
00007ff1409d3096  vmovaps [rsp+0x20], xmm1
00007ff1409d309c  movaps xmm10, xmm2
00007ff1409d30a0  mulpd xmm10, xmm11
00007ff1409d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007ff1409d30ab  ptest xmm1, xmm1
00007ff1409d30b0  jnz 0x00007FF1409D624A
00007ff1409d30b6  vmovaps xmm1, [rsp+0x80]
00007ff1409d30bf  vpermilpd xmm1, xmm1, 0x00
00007ff1409d30c5  vmovaps xmm2, [rsp+0xA0]
00007ff1409d30ce  vmovaps [rsp+0x80], xmm15
00007ff1409d30d7  movaps xmm11, xmm2
00007ff1409d30db  mulpd xmm11, xmm1
00007ff1409d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007ff1409d30e6  ptest xmm15, xmm15
00007ff1409d30ec  jnz 0x00007FF1409D638D
00007ff1409d30f2  movaps xmm1, xmm14
00007ff1409d30f6  addpd xmm1, xmm6
00007ff1409d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007ff1409d30ff  ptest xmm15, xmm15
00007ff1409d3105  jnz 0x00007FF1409D64CF
00007ff1409d310b  vmovaps xmm14, [rsp+0x10]
00007ff1409d3111  movaps xmm15, xmm14
00007ff1409d3115  addpd xmm15, xmm5
00007ff1409d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007ff1409d3120  ptest xmm6, xmm6
00007ff1409d3125  jnz 0x00007FF1409D6610
00007ff1409d312b  vmovaps xmm14, [rsp+0x90]
00007ff1409d3134  vpermilpd xmm14, xmm14, 0x00
00007ff1409d313a  movaps xmm6, xmm9
00007ff1409d313e  mulpd xmm6, xmm14
00007ff1409d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007ff1409d3148  ptest xmm5, xmm5
00007ff1409d314d  jnz 0x00007FF1409D6753
00007ff1409d3153  vmovaps xmm9, [rsp+0x80]
00007ff1409d315c  movaps xmm14, xmm9
00007ff1409d3160  addpd xmm14, xmm13
00007ff1409d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007ff1409d316b  ptest xmm5, xmm5
00007ff1409d3170  jnz 0x00007FF1409D6895
00007ff1409d3176  vmovaps xmm9, [rsp+0x20]
00007ff1409d317c  movaps xmm13, xmm9
00007ff1409d3180  addpd xmm13, xmm10
00007ff1409d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007ff1409d318b  ptest xmm5, xmm5
00007ff1409d3190  jnz 0x00007FF1409D69D9
00007ff1409d3196  vmovaps [rsp+0x10], xmm12
00007ff1409d319c  vmovaps xmm10, [rsp+0x10]
00007ff1409d31a2  por xmm12, xmm10
00007ff1409d31a7  movaps [r15+0x250], xmm12
00007ff1409d31af  vmovaps [rsp+0x10], xmm7
00007ff1409d31b5  vmovaps xmm12, [rsp+0x10]
00007ff1409d31bb  por xmm7, xmm12
00007ff1409d31c0  movaps [r15+0x2A0], xmm7
00007ff1409d31c8  vmovaps [rsp+0x10], xmm3
00007ff1409d31ce  vmovaps xmm12, [rsp+0x10]
00007ff1409d31d4  por xmm3, xmm12
00007ff1409d31d9  movaps [r15+0x1D0], xmm3
00007ff1409d31e1  lea rax, [r14+0x40]
00007ff1409d31e5  movups xmm12, [r13+rax*1]
00007ff1409d31eb  movaps [r15+0x2C0], xmm12
00007ff1409d31f3  vmovaps xmm10, [rsp+0x90]
00007ff1409d31fc  vpermilpd xmm10, xmm10, 0x00
00007ff1409d3202  movaps xmm9, xmm8
00007ff1409d3206  mulpd xmm9, xmm10
00007ff1409d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007ff1409d3211  ptest xmm5, xmm5
00007ff1409d3216  jnz 0x00007FF1409D6B27
00007ff1409d321c  movaps xmm10, xmm1
00007ff1409d3220  addpd xmm10, xmm11
00007ff1409d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007ff1409d322b  ptest xmm8, xmm8
00007ff1409d3231  jnz 0x00007FF1409D6C6B
00007ff1409d3237  movaps xmm1, xmm15
00007ff1409d323b  addpd xmm1, xmm6
00007ff1409d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007ff1409d3244  ptest xmm11, xmm11
00007ff1409d324a  jnz 0x00007FF1409D6DAE
00007ff1409d3250  vmovaps xmm15, [rsp+0x90]
00007ff1409d3259  vpermilpd xmm15, xmm15, 0x00
00007ff1409d325f  movaps xmm11, xmm12
00007ff1409d3263  mulpd xmm11, xmm15
00007ff1409d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007ff1409d326e  ptest xmm8, xmm8
00007ff1409d3274  jnz 0x00007FF1409D6EEF
00007ff1409d327a  vmovaps xmm15, [rsp+0x90]
00007ff1409d3283  vpermilpd xmm15, xmm15, 0x00
00007ff1409d3289  vmovaps xmm8, [rsp+0x50]
00007ff1409d328f  movaps xmm12, xmm8
00007ff1409d3293  mulpd xmm12, xmm15
00007ff1409d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007ff1409d329e  ptest xmm6, xmm6
00007ff1409d32a3  jnz 0x00007FF1409D7033
00007ff1409d32a9  vmovaps xmm15, [rsp+0x30]
00007ff1409d32af  vpermilpd xmm15, xmm15, 0x00
00007ff1409d32b5  movaps xmm8, xmm7
00007ff1409d32b9  mulpd xmm8, xmm15
00007ff1409d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007ff1409d32c4  ptest xmm6, xmm6
00007ff1409d32c9  jnz 0x00007FF1409D7177
00007ff1409d32cf  movaps xmm15, xmm14
00007ff1409d32d3  addpd xmm15, xmm9
00007ff1409d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007ff1409d32de  ptest xmm7, xmm7
00007ff1409d32e3  jnz 0x00007FF1409D72BA
00007ff1409d32e9  vmovaps xmm14, [rsp+0x30]
00007ff1409d32ef  vpermilpd xmm14, xmm14, 0x00
00007ff1409d32f5  vmovaps xmm7, [rsp+0xF0]
00007ff1409d32fe  movaps xmm9, xmm7
00007ff1409d3302  mulpd xmm9, xmm14
00007ff1409d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007ff1409d330d  ptest xmm6, xmm6
00007ff1409d3312  jnz 0x00007FF1409D73FE
00007ff1409d3318  movaps xmm14, xmm13
00007ff1409d331c  addpd xmm14, xmm11
00007ff1409d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007ff1409d3327  ptest xmm7, xmm7
00007ff1409d332c  jnz 0x00007FF1409D7541
00007ff1409d3332  vmovaps xmm13, [rsp+0x30]
00007ff1409d3338  vpermilpd xmm13, xmm13, 0x00
00007ff1409d333e  vmovaps xmm7, [rsp+0x60]
00007ff1409d3344  movaps xmm11, xmm7
00007ff1409d3348  mulpd xmm11, xmm13
00007ff1409d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007ff1409d3353  ptest xmm6, xmm6
00007ff1409d3358  jnz 0x00007FF1409D7685
00007ff1409d335e  movaps xmm13, xmm10
00007ff1409d3362  addpd xmm13, xmm12
00007ff1409d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007ff1409d336d  ptest xmm7, xmm7
00007ff1409d3372  jnz 0x00007FF1409D77C8
00007ff1409d3378  vmovaps xmm12, [rsp+0x30]
00007ff1409d337e  vpermilpd xmm12, xmm12, 0x00
00007ff1409d3384  vmovaps xmm7, [rsp+0x70]
00007ff1409d338a  movaps xmm10, xmm7
00007ff1409d338e  mulpd xmm10, xmm12
00007ff1409d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007ff1409d3399  ptest xmm6, xmm6
00007ff1409d339e  jnz 0x00007FF1409D790C
00007ff1409d33a4  movaps xmm12, xmm1
00007ff1409d33a8  addpd xmm12, xmm8
00007ff1409d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007ff1409d33b3  ptest xmm7, xmm7
00007ff1409d33b8  jnz 0x00007FF1409D7A4F
00007ff1409d33be  lea rax, [r14+0x70]
00007ff1409d33c2  movups xmm1, [r13+rax*1]
00007ff1409d33c8  movaps [r15+0x240], xmm1
00007ff1409d33d0  movaps xmm8, xmm15
00007ff1409d33d4  addpd xmm8, xmm9
00007ff1409d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007ff1409d33df  ptest xmm7, xmm7
00007ff1409d33e4  jnz 0x00007FF1409D7B9C
00007ff1409d33ea  movaps [r15+0x170], xmm8
00007ff1409d33f2  vmovaps xmm15, [rsp+0x40]
00007ff1409d33f8  vpermilpd xmm15, xmm15, 0x00
00007ff1409d33fe  movaps xmm9, xmm1
00007ff1409d3402  mulpd xmm9, xmm15
00007ff1409d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007ff1409d340d  ptest xmm7, xmm7
00007ff1409d3412  jnz 0x00007FF1409D7CE0
00007ff1409d3418  vmovaps xmm1, [rsp+0x40]
00007ff1409d341e  vpermilpd xmm1, xmm1, 0x00
00007ff1409d3424  movaps xmm15, xmm4
00007ff1409d3428  mulpd xmm15, xmm1
00007ff1409d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007ff1409d3433  ptest xmm7, xmm7
00007ff1409d3438  jnz 0x00007FF1409D7E23
00007ff1409d343e  movaps [r15+0x180], xmm15
00007ff1409d3446  movaps xmm1, xmm14
00007ff1409d344a  addpd xmm1, xmm11
00007ff1409d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007ff1409d3454  ptest xmm7, xmm7
00007ff1409d3459  jnz 0x00007FF1409D7F65
00007ff1409d345f  movaps [r15+0x210], xmm1
00007ff1409d3467  movups xmm14, [r13+r14*1]
00007ff1409d346d  lea rax, [r14+0x10]
00007ff1409d3471  movups xmm11, [r13+rax*1]
00007ff1409d3477  movaps [r15+0x230], xmm11
00007ff1409d347f  movaps xmm7, xmm13
00007ff1409d3483  addpd xmm7, xmm10
00007ff1409d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007ff1409d348d  ptest xmm6, xmm6
00007ff1409d3492  jnz 0x00007FF1409D80BB
00007ff1409d3498  movaps [r15+0x130], xmm7
00007ff1409d34a0  vmovaps xmm13, [rsp+0x40]
00007ff1409d34a6  vpermilpd xmm13, xmm13, 0x00
00007ff1409d34ac  movaps xmm10, xmm11
00007ff1409d34b0  mulpd xmm10, xmm13
00007ff1409d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007ff1409d34bb  ptest xmm6, xmm6
00007ff1409d34c0  jnz 0x00007FF1409D81FD
00007ff1409d34c6  movaps [r15+0x220], xmm10
00007ff1409d34ce  vmovaps xmm13, [rsp+0x40]
00007ff1409d34d4  vpermilpd xmm13, xmm13, 0x00
00007ff1409d34da  movaps xmm11, xmm14
00007ff1409d34de  mulpd xmm11, xmm13
00007ff1409d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007ff1409d34e9  ptest xmm6, xmm6
00007ff1409d34ee  jnz 0x00007FF1409D8341
00007ff1409d34f4  movaps xmm14, xmm12
00007ff1409d34f8  addpd xmm14, xmm9
00007ff1409d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007ff1409d3503  ptest xmm13, xmm13
00007ff1409d3509  jnz 0x00007FF1409D8485
00007ff1409d350f  movaps [r15+0x140], xmm14
00007ff1409d3517  movaps xmm13, xmm8
00007ff1409d351b  addpd xmm13, xmm15
00007ff1409d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007ff1409d3526  ptest xmm12, xmm12
00007ff1409d352c  jnz 0x00007FF1409D85C9
00007ff1409d3532  movaps [r15+0x150], xmm13
00007ff1409d353a  movaps xmm15, xmm1
00007ff1409d353e  addpd xmm15, xmm10
00007ff1409d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007ff1409d3549  ptest xmm12, xmm12
00007ff1409d354f  jnz 0x00007FF1409D870D
00007ff1409d3555  movaps [r15+0x160], xmm15
00007ff1409d355d  movaps xmm1, xmm7
00007ff1409d3560  addpd xmm1, xmm11
00007ff1409d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007ff1409d356a  ptest xmm12, xmm12
00007ff1409d3570  jnz 0x00007FF1409D8850
00007ff1409d3576  movaps [r15+0x120], xmm1
00007ff1409d357e  mov eax, 0x432200
00007ff1409d3583  movups [r13+rax*1], xmm14
00007ff1409d3589  mov eax, 0x432210
00007ff1409d358e  movups [r13+rax*1], xmm13
00007ff1409d3594  mov eax, 0x432220
00007ff1409d3599  movups [r13+rax*1], xmm15
00007ff1409d359f  mov eax, 0x432230
00007ff1409d35a4  movups [r13+rax*1], xmm1
00007ff1409d35aa  mov eax, [r15+0x108]
00007ff1409d35b1  sahf
00007ff1409d35b2  jnz 0x00007FF1409D35E4
00007ff1409d35b4  cmp dword ptr [r15+0x318], 0x00
00007ff1409d35bc  jz 0x00007FF1409DEAE0
00007ff1409d35c2  nop [rax+rax*1], ax
00007ff1409d35cb  nop [rax+rax*1], eax
00007ff1409d35d3  mov eax, 0x4106D0
00007ff1409d35d8  mov [r15+0x100], rax
00007ff1409d35df  jmp 0x00007FF1407FE110
00007ff1409d35e4  cmp dword ptr [r15+0x318], 0x00
00007ff1409d35ec  jz 0x00007FF1409D89C0
00007ff1409d35f2  nop [rax+rax*1], ax
00007ff1409d35fb  nop [rax+rax*1], eax
00007ff1409d3603  mov eax, 0x410504
00007ff1409d3608  mov [r15+0x100], rax
00007ff1409d360f  jmp 0x00007FF1407FE110
00007ff1409d3614  int3
00007ff1409d3615  call 0x00007FF1408D64F0
00007ff1409d361a  jmp 0x00007FF1409D2311
00007ff1409d361f  call 0x00007FF1408E5820
00007ff1409d3624  jmp 0x00007FF1409D231E
00007ff1409d3629  call 0x00007FF1408E3320
00007ff1409d362e  jmp 0x00007FF1409D2332
00007ff1409d3633  call 0x00007FF1408E20A0
00007ff1409d3638  jmp 0x00007FF1409D233C
00007ff1409d363d  call 0x00007FF140809D70
00007ff1409d3642  jmp 0x00007FF1409D234A
00007ff1409d3647  call 0x00007FF1408DFBC0
00007ff1409d364c  jmp 0x00007FF1409D2354
00007ff1409d3651  call 0x00007FF1408C4740
00007ff1409d3656  jmp 0x00007FF1409D2368
00007ff1409d365b  call 0x00007FF1408B5400
00007ff1409d3660  jmp 0x00007FF1409D2375
00007ff1409d3665  call 0x00007FF1408B52F0
00007ff1409d366a  jmp 0x00007FF1409D2382
00007ff1409d366f  call 0x00007FF1408C4620
00007ff1409d3674  jmp 0x00007FF1409D238F
00007ff1409d3679  call 0x00007FF1408BD750
00007ff1409d367e  jmp 0x00007FF1409D239C
00007ff1409d3683  call 0x00007FF1408BC4E0
00007ff1409d3688  jmp 0x00007FF1409D23A9
00007ff1409d368d  call 0x00007FF1408BB270
00007ff1409d3692  jmp 0x00007FF1409D23B6
00007ff1409d3697  call 0x00007FF1408BA000
00007ff1409d369c  jmp 0x00007FF1409D23C3
00007ff1409d36a1  call 0x00007FF1408C4740
00007ff1409d36a6  jmp 0x00007FF1409D23D0
00007ff1409d36ab  call 0x00007FF1408B5400
00007ff1409d36b0  jmp 0x00007FF1409D23DD
00007ff1409d36b5  call 0x00007FF1408B52F0
00007ff1409d36ba  jmp 0x00007FF1409D23EA
00007ff1409d36bf  call 0x00007FF1408C4620
00007ff1409d36c4  jmp 0x00007FF1409D23F7
00007ff1409d36c9  call 0x00007FF1408B8D90
00007ff1409d36ce  jmp 0x00007FF1409D2404
00007ff1409d36d3  call 0x00007FF1408B8A20
00007ff1409d36d8  jmp 0x00007FF1409D2411
00007ff1409d36dd  call 0x00007FF1408B77B0
00007ff1409d36e2  jmp 0x00007FF1409D241B
00007ff1409d36e7  call 0x00007FF1408B6550
00007ff1409d36ec  jmp 0x00007FF1409D2425
00007ff1409d36f1  call 0x00007FF1408B5400
00007ff1409d36f6  jmp 0x00007FF1409D2437
00007ff1409d36fb  call 0x00007FF1408C0FC0
00007ff1409d3700  jmp 0x00007FF1409D2441
00007ff1409d3705  call 0x00007FF1408B52F0
00007ff1409d370a  jmp 0x00007FF1409D244B
00007ff1409d370f  call 0x00007FF1408C0EA0
00007ff1409d3714  jmp 0x00007FF1409D2455
00007ff1409d3719  call 0x00007FF1408BFD50
00007ff1409d371e  jmp 0x00007FF1409D245F
00007ff1409d3723  call 0x00007FF1408B8EA0
00007ff1409d3728  jmp 0x00007FF1409D2469
00007ff1409d372d  call 0x00007FF1408BFC30
00007ff1409d3732  jmp 0x00007FF1409D2476
00007ff1409d3737  call 0x00007FF1408B8D90
00007ff1409d373c  jmp 0x00007FF1409D2483
00007ff1409d3741  call 0x00007FF1408B52F0
00007ff1409d3746  jmp 0x00007FF1409D2496
00007ff1409d374b  call 0x00007FF1408B52F0
00007ff1409d3750  jmp 0x00007FF1409D24A9
00007ff1409d3755  call 0x00007FF1408C0FC0
00007ff1409d375a  jmp 0x00007FF1409D24B6
00007ff1409d375f  call 0x00007FF1408C0FC0
00007ff1409d3764  jmp 0x00007FF1409D24C9
00007ff1409d3769  call 0x00007FF1408C0EA0
00007ff1409d376e  jmp 0x00007FF1409D24D6
00007ff1409d3773  call 0x00007FF1408B52F0
00007ff1409d3778  jmp 0x00007FF1409D24E9
00007ff1409d377d  call 0x00007FF1408B52F0
00007ff1409d3782  jmp 0x00007FF1409D24FC
00007ff1409d3787  call 0x00007FF1408B52F0
00007ff1409d378c  jmp 0x00007FF1409D250F
00007ff1409d3791  call 0x00007FF1408B52F0
00007ff1409d3796  jmp 0x00007FF1409D252A
00007ff1409d379b  call 0x00007FF1408B52F0
00007ff1409d37a0  jmp 0x00007FF1409D253D
00007ff1409d37a5  call 0x00007FF1408B5400
00007ff1409d37aa  jmp 0x00007FF1409D257E
00007ff1409d37af  call 0x00007FF1408C0FC0
00007ff1409d37b4  jmp 0x00007FF1409D258B
00007ff1409d37b9  call 0x00007FF1408B52F0
00007ff1409d37be  jmp 0x00007FF1409D2598
00007ff1409d37c3  call 0x00007FF1408C0EA0
00007ff1409d37c8  jmp 0x00007FF1409D25A5
00007ff1409d37cd  call 0x00007FF1407FF540
00007ff1409d37d2  jmp 0x00007FF1409D25C3
00007ff1409d37d7  call 0x00007FF140808C20
00007ff1409d37dc  jmp 0x00007FF1409D25CD
00007ff1409d37e1  call 0x00007FF1408E21C0
00007ff1409d37e6  jmp 0x00007FF1409D25D3
00007ff1409d37eb  call 0x00007FF1407FF540
00007ff1409d37f0  jmp 0x00007FF1409D25E3
00007ff1409d37f5  call 0x00007FF1408C0370
00007ff1409d37fa  jmp 0x00007FF1409D2611
00007ff1409d37ff  call 0x00007FF1408BF100
00007ff1409d3804  jmp 0x00007FF1409D261A
00007ff1409d3809  call 0x00007FF1408C0370
00007ff1409d380e  jmp 0x00007FF1409D2674
00007ff1409d3813  call 0x00007FF1408BF100
00007ff1409d3818  jmp 0x00007FF1409D267D
00007ff1409d381d  call 0x00007FF1408C0370
00007ff1409d3822  jmp 0x00007FF1409D26C6
00007ff1409d3827  call 0x00007FF1408BF100
00007ff1409d382c  jmp 0x00007FF1409D26CF
00007ff1409d3831  call 0x00007FF14080B720
00007ff1409d3836  jmp 0x00007FF1409D2714
00007ff1409d383b  call 0x00007FF1408B47C0
00007ff1409d3840  jmp 0x00007FF1409D2727
00007ff1409d3845  call 0x00007FF140808B00
00007ff1409d384a  jmp 0x00007FF1409D273E
00007ff1409d384f  call 0x00007FF1407FF430
00007ff1409d3854  jmp 0x00007FF1409D2751
00007ff1409d3859  call 0x00007FF1407FF430
00007ff1409d385e  jmp 0x00007FF1409D2764
00007ff1409d3863  sub rsp, 0x08
00007ff1409d3867  push rax
00007ff1409d3868  push rcx
00007ff1409d3869  push rdx
00007ff1409d386a  push rdi
00007ff1409d386b  push rsi
00007ff1409d386c  push r8
00007ff1409d386e  push r9
00007ff1409d3870  push r10
00007ff1409d3872  push r11
00007ff1409d3874  sub rsp, 0xF0
00007ff1409d387b  vmovaps [rsp], xmm0
00007ff1409d3880  vmovaps [rsp+0x10], xmm2
00007ff1409d3886  vmovaps [rsp+0x20], xmm3
00007ff1409d388c  vmovaps [rsp+0x30], xmm4
00007ff1409d3892  vmovaps [rsp+0x40], xmm5
00007ff1409d3898  vmovaps [rsp+0x50], xmm6
00007ff1409d389e  vmovaps [rsp+0x60], xmm7
00007ff1409d38a4  vmovaps [rsp+0x70], xmm8
00007ff1409d38aa  vmovaps [rsp+0x80], xmm9
00007ff1409d38b3  vmovaps [rsp+0x90], xmm10
00007ff1409d38bc  vmovaps [rsp+0xA0], xmm11
00007ff1409d38c5  vmovaps [rsp+0xB0], xmm12
00007ff1409d38ce  vmovaps [rsp+0xC0], xmm13
00007ff1409d38d7  vmovaps [rsp+0xD0], xmm14
00007ff1409d38e0  vmovaps [rsp+0xE0], xmm15
00007ff1409d38e9  sub rsp, 0x30
00007ff1409d38ed  movaps [rsp], xmm1
00007ff1409d38f1  movaps [rsp+0x10], xmm12
00007ff1409d38f7  movaps [rsp+0x20], xmm15
00007ff1409d38fd  lea rdi, [rsp]
00007ff1409d3901  mov esi, 0x00
00007ff1409d3906  mov rax, 0x565C7F10C530
00007ff1409d3910  call rax
00007ff1409d3912  movaps xmm1, [rsp]
00007ff1409d3916  add rsp, 0x30
00007ff1409d391a  vmovaps xmm0, [rsp]
00007ff1409d391f  vmovaps xmm2, [rsp+0x10]
00007ff1409d3925  vmovaps xmm3, [rsp+0x20]
00007ff1409d392b  vmovaps xmm4, [rsp+0x30]
00007ff1409d3931  vmovaps xmm5, [rsp+0x40]
00007ff1409d3937  vmovaps xmm6, [rsp+0x50]
00007ff1409d393d  vmovaps xmm7, [rsp+0x60]
00007ff1409d3943  vmovaps xmm8, [rsp+0x70]
00007ff1409d3949  vmovaps xmm9, [rsp+0x80]
00007ff1409d3952  vmovaps xmm10, [rsp+0x90]
00007ff1409d395b  vmovaps xmm11, [rsp+0xA0]
00007ff1409d3964  vmovaps xmm12, [rsp+0xB0]
00007ff1409d396d  vmovaps xmm13, [rsp+0xC0]
00007ff1409d3976  vmovaps xmm14, [rsp+0xD0]
00007ff1409d397f  vmovaps xmm15, [rsp+0xE0]
00007ff1409d3988  add rsp, 0xF0
00007ff1409d398f  pop r11
00007ff1409d3991  pop r10
00007ff1409d3993  pop r9
00007ff1409d3995  pop r8
00007ff1409d3997  pop rsi
00007ff1409d3998  pop rdi
00007ff1409d3999  pop rdx
00007ff1409d399a  pop rcx
00007ff1409d399b  pop rax
00007ff1409d399c  add rsp, 0x08
00007ff1409d39a0  jmp 0x00007FF1409D27B2
00007ff1409d39a5  sub rsp, 0x08
00007ff1409d39a9  push rax
00007ff1409d39aa  push rcx
00007ff1409d39ab  push rdx
00007ff1409d39ac  push rdi
00007ff1409d39ad  push rsi
00007ff1409d39ae  push r8
00007ff1409d39b0  push r9
00007ff1409d39b2  push r10
00007ff1409d39b4  push r11
00007ff1409d39b6  sub rsp, 0xF0
00007ff1409d39bd  vmovaps [rsp], xmm0
00007ff1409d39c2  vmovaps [rsp+0x10], xmm1
00007ff1409d39c8  vmovaps [rsp+0x20], xmm2
00007ff1409d39ce  vmovaps [rsp+0x30], xmm3
00007ff1409d39d4  vmovaps [rsp+0x40], xmm4
00007ff1409d39da  vmovaps [rsp+0x50], xmm5
00007ff1409d39e0  vmovaps [rsp+0x60], xmm6
00007ff1409d39e6  vmovaps [rsp+0x70], xmm7
00007ff1409d39ec  vmovaps [rsp+0x80], xmm8
00007ff1409d39f5  vmovaps [rsp+0x90], xmm9
00007ff1409d39fe  vmovaps [rsp+0xA0], xmm10
00007ff1409d3a07  vmovaps [rsp+0xB0], xmm11
00007ff1409d3a10  vmovaps [rsp+0xC0], xmm12
00007ff1409d3a19  vmovaps [rsp+0xD0], xmm13
00007ff1409d3a22  vmovaps [rsp+0xE0], xmm15
00007ff1409d3a2b  sub rsp, 0x30
00007ff1409d3a2f  movaps [rsp], xmm14
00007ff1409d3a34  movaps [rsp+0x10], xmm1
00007ff1409d3a39  movaps [rsp+0x20], xmm15
00007ff1409d3a3f  lea rdi, [rsp]
00007ff1409d3a43  mov esi, 0x00
00007ff1409d3a48  mov rax, 0x565C7F10C530
00007ff1409d3a52  call rax
00007ff1409d3a54  movaps xmm14, [rsp]
00007ff1409d3a59  add rsp, 0x30
00007ff1409d3a5d  vmovaps xmm0, [rsp]
00007ff1409d3a62  vmovaps xmm1, [rsp+0x10]
00007ff1409d3a68  vmovaps xmm2, [rsp+0x20]
00007ff1409d3a6e  vmovaps xmm3, [rsp+0x30]
00007ff1409d3a74  vmovaps xmm4, [rsp+0x40]
00007ff1409d3a7a  vmovaps xmm5, [rsp+0x50]
00007ff1409d3a80  vmovaps xmm6, [rsp+0x60]
00007ff1409d3a86  vmovaps xmm7, [rsp+0x70]
00007ff1409d3a8c  vmovaps xmm8, [rsp+0x80]
00007ff1409d3a95  vmovaps xmm9, [rsp+0x90]
00007ff1409d3a9e  vmovaps xmm10, [rsp+0xA0]
00007ff1409d3aa7  vmovaps xmm11, [rsp+0xB0]
00007ff1409d3ab0  vmovaps xmm12, [rsp+0xC0]
00007ff1409d3ab9  vmovaps xmm13, [rsp+0xD0]
00007ff1409d3ac2  vmovaps xmm15, [rsp+0xE0]
00007ff1409d3acb  add rsp, 0xF0
00007ff1409d3ad2  pop r11
00007ff1409d3ad4  pop r10
00007ff1409d3ad6  pop r9
00007ff1409d3ad8  pop r8
00007ff1409d3ada  pop rsi
00007ff1409d3adb  pop rdi
00007ff1409d3adc  pop rdx
00007ff1409d3add  pop rcx
00007ff1409d3ade  pop rax
00007ff1409d3adf  add rsp, 0x08
00007ff1409d3ae3  jmp 0x00007FF1409D2800
00007ff1409d3ae8  sub rsp, 0x08
00007ff1409d3aec  push rax
00007ff1409d3aed  push rcx
00007ff1409d3aee  push rdx
00007ff1409d3aef  push rdi
00007ff1409d3af0  push rsi
00007ff1409d3af1  push r8
00007ff1409d3af3  push r9
00007ff1409d3af5  push r10
00007ff1409d3af7  push r11
00007ff1409d3af9  sub rsp, 0xF0
00007ff1409d3b00  vmovaps [rsp], xmm0
00007ff1409d3b05  vmovaps [rsp+0x10], xmm1
00007ff1409d3b0b  vmovaps [rsp+0x20], xmm2
00007ff1409d3b11  vmovaps [rsp+0x30], xmm3
00007ff1409d3b17  vmovaps [rsp+0x40], xmm4
00007ff1409d3b1d  vmovaps [rsp+0x50], xmm5
00007ff1409d3b23  vmovaps [rsp+0x60], xmm6
00007ff1409d3b29  vmovaps [rsp+0x70], xmm7
00007ff1409d3b2f  vmovaps [rsp+0x80], xmm8
00007ff1409d3b38  vmovaps [rsp+0x90], xmm9
00007ff1409d3b41  vmovaps [rsp+0xA0], xmm10
00007ff1409d3b4a  vmovaps [rsp+0xB0], xmm11
00007ff1409d3b53  vmovaps [rsp+0xC0], xmm12
00007ff1409d3b5c  vmovaps [rsp+0xD0], xmm13
00007ff1409d3b65  vmovaps [rsp+0xE0], xmm14
00007ff1409d3b6e  sub rsp, 0x30
00007ff1409d3b72  movaps [rsp], xmm15
00007ff1409d3b77  movaps [rsp+0x10], xmm12
00007ff1409d3b7d  movaps [rsp+0x20], xmm13
00007ff1409d3b83  lea rdi, [rsp]
00007ff1409d3b87  mov esi, 0x00
00007ff1409d3b8c  mov rax, 0x565C7F10C530
00007ff1409d3b96  call rax
00007ff1409d3b98  movaps xmm15, [rsp]
00007ff1409d3b9d  add rsp, 0x30
00007ff1409d3ba1  vmovaps xmm0, [rsp]
00007ff1409d3ba6  vmovaps xmm1, [rsp+0x10]
00007ff1409d3bac  vmovaps xmm2, [rsp+0x20]
00007ff1409d3bb2  vmovaps xmm3, [rsp+0x30]
00007ff1409d3bb8  vmovaps xmm4, [rsp+0x40]
00007ff1409d3bbe  vmovaps xmm5, [rsp+0x50]
00007ff1409d3bc4  vmovaps xmm6, [rsp+0x60]
00007ff1409d3bca  vmovaps xmm7, [rsp+0x70]
00007ff1409d3bd0  vmovaps xmm8, [rsp+0x80]
00007ff1409d3bd9  vmovaps xmm9, [rsp+0x90]
00007ff1409d3be2  vmovaps xmm10, [rsp+0xA0]
00007ff1409d3beb  vmovaps xmm11, [rsp+0xB0]
00007ff1409d3bf4  vmovaps xmm12, [rsp+0xC0]
00007ff1409d3bfd  vmovaps xmm13, [rsp+0xD0]
00007ff1409d3c06  vmovaps xmm14, [rsp+0xE0]
00007ff1409d3c0f  add rsp, 0xF0
00007ff1409d3c16  pop r11
00007ff1409d3c18  pop r10
00007ff1409d3c1a  pop r9
00007ff1409d3c1c  pop r8
00007ff1409d3c1e  pop rsi
00007ff1409d3c1f  pop rdi
00007ff1409d3c20  pop rdx
00007ff1409d3c21  pop rcx
00007ff1409d3c22  pop rax
00007ff1409d3c23  add rsp, 0x08
00007ff1409d3c27  jmp 0x00007FF1409D2835
00007ff1409d3c2c  sub rsp, 0x08
00007ff1409d3c30  push rax
00007ff1409d3c31  push rcx
00007ff1409d3c32  push rdx
00007ff1409d3c33  push rdi
00007ff1409d3c34  push rsi
00007ff1409d3c35  push r8
00007ff1409d3c37  push r9
00007ff1409d3c39  push r10
00007ff1409d3c3b  push r11
00007ff1409d3c3d  sub rsp, 0xF0
00007ff1409d3c44  vmovaps [rsp], xmm0
00007ff1409d3c49  vmovaps [rsp+0x10], xmm2
00007ff1409d3c4f  vmovaps [rsp+0x20], xmm3
00007ff1409d3c55  vmovaps [rsp+0x30], xmm4
00007ff1409d3c5b  vmovaps [rsp+0x40], xmm5
00007ff1409d3c61  vmovaps [rsp+0x50], xmm6
00007ff1409d3c67  vmovaps [rsp+0x60], xmm7
00007ff1409d3c6d  vmovaps [rsp+0x70], xmm8
00007ff1409d3c73  vmovaps [rsp+0x80], xmm9
00007ff1409d3c7c  vmovaps [rsp+0x90], xmm10
00007ff1409d3c85  vmovaps [rsp+0xA0], xmm11
00007ff1409d3c8e  vmovaps [rsp+0xB0], xmm12
00007ff1409d3c97  vmovaps [rsp+0xC0], xmm13
00007ff1409d3ca0  vmovaps [rsp+0xD0], xmm14
00007ff1409d3ca9  vmovaps [rsp+0xE0], xmm15
00007ff1409d3cb2  sub rsp, 0x30
00007ff1409d3cb6  movaps [rsp], xmm1
00007ff1409d3cba  movaps [rsp+0x10], xmm12
00007ff1409d3cc0  movaps [rsp+0x20], xmm10
00007ff1409d3cc6  lea rdi, [rsp]
00007ff1409d3cca  mov esi, 0x00
00007ff1409d3ccf  mov rax, 0x565C7F10C530
00007ff1409d3cd9  call rax
00007ff1409d3cdb  movaps xmm1, [rsp]
00007ff1409d3cdf  add rsp, 0x30
00007ff1409d3ce3  vmovaps xmm0, [rsp]
00007ff1409d3ce8  vmovaps xmm2, [rsp+0x10]
00007ff1409d3cee  vmovaps xmm3, [rsp+0x20]
00007ff1409d3cf4  vmovaps xmm4, [rsp+0x30]
00007ff1409d3cfa  vmovaps xmm5, [rsp+0x40]
00007ff1409d3d00  vmovaps xmm6, [rsp+0x50]
00007ff1409d3d06  vmovaps xmm7, [rsp+0x60]
00007ff1409d3d0c  vmovaps xmm8, [rsp+0x70]
00007ff1409d3d12  vmovaps xmm9, [rsp+0x80]
00007ff1409d3d1b  vmovaps xmm10, [rsp+0x90]
00007ff1409d3d24  vmovaps xmm11, [rsp+0xA0]
00007ff1409d3d2d  vmovaps xmm12, [rsp+0xB0]
00007ff1409d3d36  vmovaps xmm13, [rsp+0xC0]
00007ff1409d3d3f  vmovaps xmm14, [rsp+0xD0]
00007ff1409d3d48  vmovaps xmm15, [rsp+0xE0]
00007ff1409d3d51  add rsp, 0xF0
00007ff1409d3d58  pop r11
00007ff1409d3d5a  pop r10
00007ff1409d3d5c  pop r9
00007ff1409d3d5e  pop r8
00007ff1409d3d60  pop rsi
00007ff1409d3d61  pop rdi
00007ff1409d3d62  pop rdx
00007ff1409d3d63  pop rcx
00007ff1409d3d64  pop rax
00007ff1409d3d65  add rsp, 0x08
00007ff1409d3d69  jmp 0x00007FF1409D284F
00007ff1409d3d6e  sub rsp, 0x08
00007ff1409d3d72  push rax
00007ff1409d3d73  push rcx
00007ff1409d3d74  push rdx
00007ff1409d3d75  push rdi
00007ff1409d3d76  push rsi
00007ff1409d3d77  push r8
00007ff1409d3d79  push r9
00007ff1409d3d7b  push r10
00007ff1409d3d7d  push r11
00007ff1409d3d7f  sub rsp, 0xF0
00007ff1409d3d86  vmovaps [rsp], xmm0
00007ff1409d3d8b  vmovaps [rsp+0x10], xmm1
00007ff1409d3d91  vmovaps [rsp+0x20], xmm2
00007ff1409d3d97  vmovaps [rsp+0x30], xmm3
00007ff1409d3d9d  vmovaps [rsp+0x40], xmm4
00007ff1409d3da3  vmovaps [rsp+0x50], xmm5
00007ff1409d3da9  vmovaps [rsp+0x60], xmm6
00007ff1409d3daf  vmovaps [rsp+0x70], xmm7
00007ff1409d3db5  vmovaps [rsp+0x80], xmm8
00007ff1409d3dbe  vmovaps [rsp+0x90], xmm9
00007ff1409d3dc7  vmovaps [rsp+0xA0], xmm10
00007ff1409d3dd0  vmovaps [rsp+0xB0], xmm11
00007ff1409d3dd9  vmovaps [rsp+0xC0], xmm12
00007ff1409d3de2  vmovaps [rsp+0xD0], xmm14
00007ff1409d3deb  vmovaps [rsp+0xE0], xmm15
00007ff1409d3df4  sub rsp, 0x30
00007ff1409d3df8  movaps [rsp], xmm13
00007ff1409d3dfd  movaps [rsp+0x10], xmm12
00007ff1409d3e03  movaps [rsp+0x20], xmm2
00007ff1409d3e08  lea rdi, [rsp]
00007ff1409d3e0c  mov esi, 0x00
00007ff1409d3e11  mov rax, 0x565C7F10C530
00007ff1409d3e1b  call rax
00007ff1409d3e1d  movaps xmm13, [rsp]
00007ff1409d3e22  add rsp, 0x30
00007ff1409d3e26  vmovaps xmm0, [rsp]
00007ff1409d3e2b  vmovaps xmm1, [rsp+0x10]
00007ff1409d3e31  vmovaps xmm2, [rsp+0x20]
00007ff1409d3e37  vmovaps xmm3, [rsp+0x30]
00007ff1409d3e3d  vmovaps xmm4, [rsp+0x40]
00007ff1409d3e43  vmovaps xmm5, [rsp+0x50]
00007ff1409d3e49  vmovaps xmm6, [rsp+0x60]
00007ff1409d3e4f  vmovaps xmm7, [rsp+0x70]
00007ff1409d3e55  vmovaps xmm8, [rsp+0x80]
00007ff1409d3e5e  vmovaps xmm9, [rsp+0x90]
00007ff1409d3e67  vmovaps xmm10, [rsp+0xA0]
00007ff1409d3e70  vmovaps xmm11, [rsp+0xB0]
00007ff1409d3e79  vmovaps xmm12, [rsp+0xC0]
00007ff1409d3e82  vmovaps xmm14, [rsp+0xD0]
00007ff1409d3e8b  vmovaps xmm15, [rsp+0xE0]
00007ff1409d3e94  add rsp, 0xF0
00007ff1409d3e9b  pop r11
00007ff1409d3e9d  pop r10
00007ff1409d3e9f  pop r9
00007ff1409d3ea1  pop r8
00007ff1409d3ea3  pop rsi
00007ff1409d3ea4  pop rdi
00007ff1409d3ea5  pop rdx
00007ff1409d3ea6  pop rcx
00007ff1409d3ea7  pop rax
00007ff1409d3ea8  add rsp, 0x08
00007ff1409d3eac  jmp 0x00007FF1409D286A
00007ff1409d3eb1  sub rsp, 0x08
00007ff1409d3eb5  push rax
00007ff1409d3eb6  push rcx
00007ff1409d3eb7  push rdx
00007ff1409d3eb8  push rdi
00007ff1409d3eb9  push rsi
00007ff1409d3eba  push r8
00007ff1409d3ebc  push r9
00007ff1409d3ebe  push r10
00007ff1409d3ec0  push r11
00007ff1409d3ec2  sub rsp, 0xF0
00007ff1409d3ec9  vmovaps [rsp], xmm0
00007ff1409d3ece  vmovaps [rsp+0x10], xmm2
00007ff1409d3ed4  vmovaps [rsp+0x20], xmm3
00007ff1409d3eda  vmovaps [rsp+0x30], xmm4
00007ff1409d3ee0  vmovaps [rsp+0x40], xmm5
00007ff1409d3ee6  vmovaps [rsp+0x50], xmm6
00007ff1409d3eec  vmovaps [rsp+0x60], xmm7
00007ff1409d3ef2  vmovaps [rsp+0x70], xmm8
00007ff1409d3ef8  vmovaps [rsp+0x80], xmm9
00007ff1409d3f01  vmovaps [rsp+0x90], xmm10
00007ff1409d3f0a  vmovaps [rsp+0xA0], xmm11
00007ff1409d3f13  vmovaps [rsp+0xB0], xmm12
00007ff1409d3f1c  vmovaps [rsp+0xC0], xmm13
00007ff1409d3f25  vmovaps [rsp+0xD0], xmm14
00007ff1409d3f2e  vmovaps [rsp+0xE0], xmm15
00007ff1409d3f37  sub rsp, 0x30
00007ff1409d3f3b  movaps [rsp], xmm1
00007ff1409d3f3f  movaps [rsp+0x10], xmm10
00007ff1409d3f45  movaps [rsp+0x20], xmm2
00007ff1409d3f4a  lea rdi, [rsp]
00007ff1409d3f4e  mov esi, 0x00
00007ff1409d3f53  mov rax, 0x565C7F10C530
00007ff1409d3f5d  call rax
00007ff1409d3f5f  movaps xmm1, [rsp]
00007ff1409d3f63  add rsp, 0x30
00007ff1409d3f67  vmovaps xmm0, [rsp]
00007ff1409d3f6c  vmovaps xmm2, [rsp+0x10]
00007ff1409d3f72  vmovaps xmm3, [rsp+0x20]
00007ff1409d3f78  vmovaps xmm4, [rsp+0x30]
00007ff1409d3f7e  vmovaps xmm5, [rsp+0x40]
00007ff1409d3f84  vmovaps xmm6, [rsp+0x50]
00007ff1409d3f8a  vmovaps xmm7, [rsp+0x60]
00007ff1409d3f90  vmovaps xmm8, [rsp+0x70]
00007ff1409d3f96  vmovaps xmm9, [rsp+0x80]
00007ff1409d3f9f  vmovaps xmm10, [rsp+0x90]
00007ff1409d3fa8  vmovaps xmm11, [rsp+0xA0]
00007ff1409d3fb1  vmovaps xmm12, [rsp+0xB0]
00007ff1409d3fba  vmovaps xmm13, [rsp+0xC0]
00007ff1409d3fc3  vmovaps xmm14, [rsp+0xD0]
00007ff1409d3fcc  vmovaps xmm15, [rsp+0xE0]
00007ff1409d3fd5  add rsp, 0xF0
00007ff1409d3fdc  pop r11
00007ff1409d3fde  pop r10
00007ff1409d3fe0  pop r9
00007ff1409d3fe2  pop r8
00007ff1409d3fe4  pop rsi
00007ff1409d3fe5  pop rdi
00007ff1409d3fe6  pop rdx
00007ff1409d3fe7  pop rcx
00007ff1409d3fe8  pop rax
00007ff1409d3fe9  add rsp, 0x08
00007ff1409d3fed  jmp 0x00007FF1409D28D2
00007ff1409d3ff2  sub rsp, 0x08
00007ff1409d3ff6  push rax
00007ff1409d3ff7  push rcx
00007ff1409d3ff8  push rdx
00007ff1409d3ff9  push rdi
00007ff1409d3ffa  push rsi
00007ff1409d3ffb  push r8
00007ff1409d3ffd  push r9
00007ff1409d3fff  push r10
00007ff1409d4001  push r11
00007ff1409d4003  sub rsp, 0xF0
00007ff1409d400a  vmovaps [rsp], xmm0
00007ff1409d400f  vmovaps [rsp+0x10], xmm1
00007ff1409d4015  vmovaps [rsp+0x20], xmm2
00007ff1409d401b  vmovaps [rsp+0x30], xmm3
00007ff1409d4021  vmovaps [rsp+0x40], xmm4
00007ff1409d4027  vmovaps [rsp+0x50], xmm5
00007ff1409d402d  vmovaps [rsp+0x60], xmm6
00007ff1409d4033  vmovaps [rsp+0x70], xmm7
00007ff1409d4039  vmovaps [rsp+0x80], xmm8
00007ff1409d4042  vmovaps [rsp+0x90], xmm9
00007ff1409d404b  vmovaps [rsp+0xA0], xmm10
00007ff1409d4054  vmovaps [rsp+0xB0], xmm11
00007ff1409d405d  vmovaps [rsp+0xC0], xmm12
00007ff1409d4066  vmovaps [rsp+0xD0], xmm13
00007ff1409d406f  vmovaps [rsp+0xE0], xmm14
00007ff1409d4078  sub rsp, 0x30
00007ff1409d407c  movaps [rsp], xmm15
00007ff1409d4081  movaps [rsp+0x10], xmm10
00007ff1409d4087  movaps [rsp+0x20], xmm2
00007ff1409d408c  lea rdi, [rsp]
00007ff1409d4090  mov esi, 0x00
00007ff1409d4095  mov rax, 0x565C7F10C530
00007ff1409d409f  call rax
00007ff1409d40a1  movaps xmm15, [rsp]
00007ff1409d40a6  add rsp, 0x30
00007ff1409d40aa  vmovaps xmm0, [rsp]
00007ff1409d40af  vmovaps xmm1, [rsp+0x10]
00007ff1409d40b5  vmovaps xmm2, [rsp+0x20]
00007ff1409d40bb  vmovaps xmm3, [rsp+0x30]
00007ff1409d40c1  vmovaps xmm4, [rsp+0x40]
00007ff1409d40c7  vmovaps xmm5, [rsp+0x50]
00007ff1409d40cd  vmovaps xmm6, [rsp+0x60]
00007ff1409d40d3  vmovaps xmm7, [rsp+0x70]
00007ff1409d40d9  vmovaps xmm8, [rsp+0x80]
00007ff1409d40e2  vmovaps xmm9, [rsp+0x90]
00007ff1409d40eb  vmovaps xmm10, [rsp+0xA0]
00007ff1409d40f4  vmovaps xmm11, [rsp+0xB0]
00007ff1409d40fd  vmovaps xmm12, [rsp+0xC0]
00007ff1409d4106  vmovaps xmm13, [rsp+0xD0]
00007ff1409d410f  vmovaps xmm14, [rsp+0xE0]
00007ff1409d4118  add rsp, 0xF0
00007ff1409d411f  pop r11
00007ff1409d4121  pop r10
00007ff1409d4123  pop r9
00007ff1409d4125  pop r8
00007ff1409d4127  pop rsi
00007ff1409d4128  pop rdi
00007ff1409d4129  pop rdx
00007ff1409d412a  pop rcx
00007ff1409d412b  pop rax
00007ff1409d412c  add rsp, 0x08
00007ff1409d4130  jmp 0x00007FF1409D2924
00007ff1409d4135  sub rsp, 0x08
00007ff1409d4139  push rax
00007ff1409d413a  push rcx
00007ff1409d413b  push rdx
00007ff1409d413c  push rdi
00007ff1409d413d  push rsi
00007ff1409d413e  push r8
00007ff1409d4140  push r9
00007ff1409d4142  push r10
00007ff1409d4144  push r11
00007ff1409d4146  sub rsp, 0xF0
00007ff1409d414d  vmovaps [rsp], xmm0
00007ff1409d4152  vmovaps [rsp+0x10], xmm2
00007ff1409d4158  vmovaps [rsp+0x20], xmm3
00007ff1409d415e  vmovaps [rsp+0x30], xmm4
00007ff1409d4164  vmovaps [rsp+0x40], xmm5
00007ff1409d416a  vmovaps [rsp+0x50], xmm6
00007ff1409d4170  vmovaps [rsp+0x60], xmm7
00007ff1409d4176  vmovaps [rsp+0x70], xmm8
00007ff1409d417c  vmovaps [rsp+0x80], xmm9
00007ff1409d4185  vmovaps [rsp+0x90], xmm10
00007ff1409d418e  vmovaps [rsp+0xA0], xmm11
00007ff1409d4197  vmovaps [rsp+0xB0], xmm12
00007ff1409d41a0  vmovaps [rsp+0xC0], xmm13
00007ff1409d41a9  vmovaps [rsp+0xD0], xmm14
00007ff1409d41b2  vmovaps [rsp+0xE0], xmm15
00007ff1409d41bb  sub rsp, 0x30
00007ff1409d41bf  movaps [rsp], xmm1
00007ff1409d41c3  movaps [rsp+0x10], xmm10
00007ff1409d41c9  movaps [rsp+0x20], xmm15
00007ff1409d41cf  lea rdi, [rsp]
00007ff1409d41d3  mov esi, 0x00
00007ff1409d41d8  mov rax, 0x565C7F10C530
00007ff1409d41e2  call rax
00007ff1409d41e4  movaps xmm1, [rsp]
00007ff1409d41e8  add rsp, 0x30
00007ff1409d41ec  vmovaps xmm0, [rsp]
00007ff1409d41f1  vmovaps xmm2, [rsp+0x10]
00007ff1409d41f7  vmovaps xmm3, [rsp+0x20]
00007ff1409d41fd  vmovaps xmm4, [rsp+0x30]
00007ff1409d4203  vmovaps xmm5, [rsp+0x40]
00007ff1409d4209  vmovaps xmm6, [rsp+0x50]
00007ff1409d420f  vmovaps xmm7, [rsp+0x60]
00007ff1409d4215  vmovaps xmm8, [rsp+0x70]
00007ff1409d421b  vmovaps xmm9, [rsp+0x80]
00007ff1409d4224  vmovaps xmm10, [rsp+0x90]
00007ff1409d422d  vmovaps xmm11, [rsp+0xA0]
00007ff1409d4236  vmovaps xmm12, [rsp+0xB0]
00007ff1409d423f  vmovaps xmm13, [rsp+0xC0]
00007ff1409d4248  vmovaps xmm14, [rsp+0xD0]
00007ff1409d4251  vmovaps xmm15, [rsp+0xE0]
00007ff1409d425a  add rsp, 0xF0
00007ff1409d4261  pop r11
00007ff1409d4263  pop r10
00007ff1409d4265  pop r9
00007ff1409d4267  pop r8
00007ff1409d4269  pop rsi
00007ff1409d426a  pop rdi
00007ff1409d426b  pop rdx
00007ff1409d426c  pop rcx
00007ff1409d426d  pop rax
00007ff1409d426e  add rsp, 0x08
00007ff1409d4272  jmp 0x00007FF1409D2962
00007ff1409d4277  sub rsp, 0x08
00007ff1409d427b  push rax
00007ff1409d427c  push rcx
00007ff1409d427d  push rdx
00007ff1409d427e  push rdi
00007ff1409d427f  push rsi
00007ff1409d4280  push r8
00007ff1409d4282  push r9
00007ff1409d4284  push r10
00007ff1409d4286  push r11
00007ff1409d4288  sub rsp, 0xF0
00007ff1409d428f  vmovaps [rsp], xmm0
00007ff1409d4294  vmovaps [rsp+0x10], xmm1
00007ff1409d429a  vmovaps [rsp+0x20], xmm2
00007ff1409d42a0  vmovaps [rsp+0x30], xmm3
00007ff1409d42a6  vmovaps [rsp+0x40], xmm4
00007ff1409d42ac  vmovaps [rsp+0x50], xmm5
00007ff1409d42b2  vmovaps [rsp+0x60], xmm6
00007ff1409d42b8  vmovaps [rsp+0x70], xmm7
00007ff1409d42be  vmovaps [rsp+0x80], xmm8
00007ff1409d42c7  vmovaps [rsp+0x90], xmm9
00007ff1409d42d0  vmovaps [rsp+0xA0], xmm10
00007ff1409d42d9  vmovaps [rsp+0xB0], xmm11
00007ff1409d42e2  vmovaps [rsp+0xC0], xmm12
00007ff1409d42eb  vmovaps [rsp+0xD0], xmm13
00007ff1409d42f4  vmovaps [rsp+0xE0], xmm15
00007ff1409d42fd  sub rsp, 0x30
00007ff1409d4301  movaps [rsp], xmm14
00007ff1409d4306  movaps [rsp+0x10], xmm10
00007ff1409d430c  movaps [rsp+0x20], xmm15
00007ff1409d4312  lea rdi, [rsp]
00007ff1409d4316  mov esi, 0x00
00007ff1409d431b  mov rax, 0x565C7F10C530
00007ff1409d4325  call rax
00007ff1409d4327  movaps xmm14, [rsp]
00007ff1409d432c  add rsp, 0x30
00007ff1409d4330  vmovaps xmm0, [rsp]
00007ff1409d4335  vmovaps xmm1, [rsp+0x10]
00007ff1409d433b  vmovaps xmm2, [rsp+0x20]
00007ff1409d4341  vmovaps xmm3, [rsp+0x30]
00007ff1409d4347  vmovaps xmm4, [rsp+0x40]
00007ff1409d434d  vmovaps xmm5, [rsp+0x50]
00007ff1409d4353  vmovaps xmm6, [rsp+0x60]
00007ff1409d4359  vmovaps xmm7, [rsp+0x70]
00007ff1409d435f  vmovaps xmm8, [rsp+0x80]
00007ff1409d4368  vmovaps xmm9, [rsp+0x90]
00007ff1409d4371  vmovaps xmm10, [rsp+0xA0]
00007ff1409d437a  vmovaps xmm11, [rsp+0xB0]
00007ff1409d4383  vmovaps xmm12, [rsp+0xC0]
00007ff1409d438c  vmovaps xmm13, [rsp+0xD0]
00007ff1409d4395  vmovaps xmm15, [rsp+0xE0]
00007ff1409d439e  add rsp, 0xF0
00007ff1409d43a5  pop r11
00007ff1409d43a7  pop r10
00007ff1409d43a9  pop r9
00007ff1409d43ab  pop r8
00007ff1409d43ad  pop rsi
00007ff1409d43ae  pop rdi
00007ff1409d43af  pop rdx
00007ff1409d43b0  pop rcx
00007ff1409d43b1  pop rax
00007ff1409d43b2  add rsp, 0x08
00007ff1409d43b6  jmp 0x00007FF1409D298E
00007ff1409d43bb  call 0x00007FF1407FF430
00007ff1409d43c0  jmp 0x00007FF1409D2A1E
00007ff1409d43c5  call 0x00007FF1407FF430
00007ff1409d43ca  jmp 0x00007FF1409D2A31
00007ff1409d43cf  sub rsp, 0x08
00007ff1409d43d3  push rax
00007ff1409d43d4  push rcx
00007ff1409d43d5  push rdx
00007ff1409d43d6  push rdi
00007ff1409d43d7  push rsi
00007ff1409d43d8  push r8
00007ff1409d43da  push r9
00007ff1409d43dc  push r10
00007ff1409d43de  push r11
00007ff1409d43e0  sub rsp, 0xF0
00007ff1409d43e7  vmovaps [rsp], xmm0
00007ff1409d43ec  vmovaps [rsp+0x10], xmm2
00007ff1409d43f2  vmovaps [rsp+0x20], xmm3
00007ff1409d43f8  vmovaps [rsp+0x30], xmm4
00007ff1409d43fe  vmovaps [rsp+0x40], xmm5
00007ff1409d4404  vmovaps [rsp+0x50], xmm6
00007ff1409d440a  vmovaps [rsp+0x60], xmm7
00007ff1409d4410  vmovaps [rsp+0x70], xmm8
00007ff1409d4416  vmovaps [rsp+0x80], xmm9
00007ff1409d441f  vmovaps [rsp+0x90], xmm10
00007ff1409d4428  vmovaps [rsp+0xA0], xmm11
00007ff1409d4431  vmovaps [rsp+0xB0], xmm12
00007ff1409d443a  vmovaps [rsp+0xC0], xmm13
00007ff1409d4443  vmovaps [rsp+0xD0], xmm14
00007ff1409d444c  vmovaps [rsp+0xE0], xmm15
00007ff1409d4455  sub rsp, 0x30
00007ff1409d4459  movaps [rsp], xmm1
00007ff1409d445d  movaps [rsp+0x10], xmm13
00007ff1409d4463  movaps [rsp+0x20], xmm2
00007ff1409d4468  lea rdi, [rsp]
00007ff1409d446c  mov esi, 0x00
00007ff1409d4471  mov rax, 0x565C7F10C530
00007ff1409d447b  call rax
00007ff1409d447d  movaps xmm1, [rsp]
00007ff1409d4481  add rsp, 0x30
00007ff1409d4485  vmovaps xmm0, [rsp]
00007ff1409d448a  vmovaps xmm2, [rsp+0x10]
00007ff1409d4490  vmovaps xmm3, [rsp+0x20]
00007ff1409d4496  vmovaps xmm4, [rsp+0x30]
00007ff1409d449c  vmovaps xmm5, [rsp+0x40]
00007ff1409d44a2  vmovaps xmm6, [rsp+0x50]
00007ff1409d44a8  vmovaps xmm7, [rsp+0x60]
00007ff1409d44ae  vmovaps xmm8, [rsp+0x70]
00007ff1409d44b4  vmovaps xmm9, [rsp+0x80]
00007ff1409d44bd  vmovaps xmm10, [rsp+0x90]
00007ff1409d44c6  vmovaps xmm11, [rsp+0xA0]
00007ff1409d44cf  vmovaps xmm12, [rsp+0xB0]
00007ff1409d44d8  vmovaps xmm13, [rsp+0xC0]
00007ff1409d44e1  vmovaps xmm14, [rsp+0xD0]
00007ff1409d44ea  vmovaps xmm15, [rsp+0xE0]
00007ff1409d44f3  add rsp, 0xF0
00007ff1409d44fa  pop r11
00007ff1409d44fc  pop r10
00007ff1409d44fe  pop r9
00007ff1409d4500  pop r8
00007ff1409d4502  pop rsi
00007ff1409d4503  pop rdi
00007ff1409d4504  pop rdx
00007ff1409d4505  pop rcx
00007ff1409d4506  pop rax
00007ff1409d4507  add rsp, 0x08
00007ff1409d450b  jmp 0x00007FF1409D2A5C
00007ff1409d4510  call 0x00007FF14080E760
00007ff1409d4515  jmp 0x00007FF1409D2A69
00007ff1409d451a  sub rsp, 0x08
00007ff1409d451e  push rax
00007ff1409d451f  push rcx
00007ff1409d4520  push rdx
00007ff1409d4521  push rdi
00007ff1409d4522  push rsi
00007ff1409d4523  push r8
00007ff1409d4525  push r9
00007ff1409d4527  push r10
00007ff1409d4529  push r11
00007ff1409d452b  sub rsp, 0xF0
00007ff1409d4532  vmovaps [rsp], xmm0
00007ff1409d4537  vmovaps [rsp+0x10], xmm1
00007ff1409d453d  vmovaps [rsp+0x20], xmm2
00007ff1409d4543  vmovaps [rsp+0x30], xmm3
00007ff1409d4549  vmovaps [rsp+0x40], xmm4
00007ff1409d454f  vmovaps [rsp+0x50], xmm5
00007ff1409d4555  vmovaps [rsp+0x60], xmm6
00007ff1409d455b  vmovaps [rsp+0x70], xmm7
00007ff1409d4561  vmovaps [rsp+0x80], xmm8
00007ff1409d456a  vmovaps [rsp+0x90], xmm9
00007ff1409d4573  vmovaps [rsp+0xA0], xmm10
00007ff1409d457c  vmovaps [rsp+0xB0], xmm11
00007ff1409d4585  vmovaps [rsp+0xC0], xmm12
00007ff1409d458e  vmovaps [rsp+0xD0], xmm14
00007ff1409d4597  vmovaps [rsp+0xE0], xmm15
00007ff1409d45a0  sub rsp, 0x30
00007ff1409d45a4  movaps [rsp], xmm13
00007ff1409d45a9  movaps [rsp+0x10], xmm2
00007ff1409d45ae  movaps [rsp+0x20], xmm1
00007ff1409d45b3  lea rdi, [rsp]
00007ff1409d45b7  mov esi, 0x00
00007ff1409d45bc  mov rax, 0x565C7F10C530
00007ff1409d45c6  call rax
00007ff1409d45c8  movaps xmm13, [rsp]
00007ff1409d45cd  add rsp, 0x30
00007ff1409d45d1  vmovaps xmm0, [rsp]
00007ff1409d45d6  vmovaps xmm1, [rsp+0x10]
00007ff1409d45dc  vmovaps xmm2, [rsp+0x20]
00007ff1409d45e2  vmovaps xmm3, [rsp+0x30]
00007ff1409d45e8  vmovaps xmm4, [rsp+0x40]
00007ff1409d45ee  vmovaps xmm5, [rsp+0x50]
00007ff1409d45f4  vmovaps xmm6, [rsp+0x60]
00007ff1409d45fa  vmovaps xmm7, [rsp+0x70]
00007ff1409d4600  vmovaps xmm8, [rsp+0x80]
00007ff1409d4609  vmovaps xmm9, [rsp+0x90]
00007ff1409d4612  vmovaps xmm10, [rsp+0xA0]
00007ff1409d461b  vmovaps xmm11, [rsp+0xB0]
00007ff1409d4624  vmovaps xmm12, [rsp+0xC0]
00007ff1409d462d  vmovaps xmm14, [rsp+0xD0]
00007ff1409d4636  vmovaps xmm15, [rsp+0xE0]
00007ff1409d463f  add rsp, 0xF0
00007ff1409d4646  pop r11
00007ff1409d4648  pop r10
00007ff1409d464a  pop r9
00007ff1409d464c  pop r8
00007ff1409d464e  pop rsi
00007ff1409d464f  pop rdi
00007ff1409d4650  pop rdx
00007ff1409d4651  pop rcx
00007ff1409d4652  pop rax
00007ff1409d4653  add rsp, 0x08
00007ff1409d4657  jmp 0x00007FF1409D2AA8
00007ff1409d465c  sub rsp, 0x08
00007ff1409d4660  push rax
00007ff1409d4661  push rcx
00007ff1409d4662  push rdx
00007ff1409d4663  push rdi
00007ff1409d4664  push rsi
00007ff1409d4665  push r8
00007ff1409d4667  push r9
00007ff1409d4669  push r10
00007ff1409d466b  push r11
00007ff1409d466d  sub rsp, 0xF0
00007ff1409d4674  vmovaps [rsp], xmm0
00007ff1409d4679  vmovaps [rsp+0x10], xmm2
00007ff1409d467f  vmovaps [rsp+0x20], xmm3
00007ff1409d4685  vmovaps [rsp+0x30], xmm4
00007ff1409d468b  vmovaps [rsp+0x40], xmm5
00007ff1409d4691  vmovaps [rsp+0x50], xmm6
00007ff1409d4697  vmovaps [rsp+0x60], xmm7
00007ff1409d469d  vmovaps [rsp+0x70], xmm8
00007ff1409d46a3  vmovaps [rsp+0x80], xmm9
00007ff1409d46ac  vmovaps [rsp+0x90], xmm10
00007ff1409d46b5  vmovaps [rsp+0xA0], xmm11
00007ff1409d46be  vmovaps [rsp+0xB0], xmm12
00007ff1409d46c7  vmovaps [rsp+0xC0], xmm13
00007ff1409d46d0  vmovaps [rsp+0xD0], xmm14
00007ff1409d46d9  vmovaps [rsp+0xE0], xmm15
00007ff1409d46e2  sub rsp, 0x30
00007ff1409d46e6  movaps [rsp], xmm1
00007ff1409d46ea  movaps [rsp+0x10], xmm14
00007ff1409d46f0  movaps [rsp+0x20], xmm15
00007ff1409d46f6  lea rdi, [rsp]
00007ff1409d46fa  mov esi, 0x00
00007ff1409d46ff  mov rax, 0x565C7F10C530
00007ff1409d4709  call rax
00007ff1409d470b  movaps xmm1, [rsp]
00007ff1409d470f  add rsp, 0x30
00007ff1409d4713  vmovaps xmm0, [rsp]
00007ff1409d4718  vmovaps xmm2, [rsp+0x10]
00007ff1409d471e  vmovaps xmm3, [rsp+0x20]
00007ff1409d4724  vmovaps xmm4, [rsp+0x30]
00007ff1409d472a  vmovaps xmm5, [rsp+0x40]
00007ff1409d4730  vmovaps xmm6, [rsp+0x50]
00007ff1409d4736  vmovaps xmm7, [rsp+0x60]
00007ff1409d473c  vmovaps xmm8, [rsp+0x70]
00007ff1409d4742  vmovaps xmm9, [rsp+0x80]
00007ff1409d474b  vmovaps xmm10, [rsp+0x90]
00007ff1409d4754  vmovaps xmm11, [rsp+0xA0]
00007ff1409d475d  vmovaps xmm12, [rsp+0xB0]
00007ff1409d4766  vmovaps xmm13, [rsp+0xC0]
00007ff1409d476f  vmovaps xmm14, [rsp+0xD0]
00007ff1409d4778  vmovaps xmm15, [rsp+0xE0]
00007ff1409d4781  add rsp, 0xF0
00007ff1409d4788  pop r11
00007ff1409d478a  pop r10
00007ff1409d478c  pop r9
00007ff1409d478e  pop r8
00007ff1409d4790  pop rsi
00007ff1409d4791  pop rdi
00007ff1409d4792  pop rdx
00007ff1409d4793  pop rcx
00007ff1409d4794  pop rax
00007ff1409d4795  add rsp, 0x08
00007ff1409d4799  jmp 0x00007FF1409D2ACA
00007ff1409d479e  sub rsp, 0x08
00007ff1409d47a2  push rax
00007ff1409d47a3  push rcx
00007ff1409d47a4  push rdx
00007ff1409d47a5  push rdi
00007ff1409d47a6  push rsi
00007ff1409d47a7  push r8
00007ff1409d47a9  push r9
00007ff1409d47ab  push r10
00007ff1409d47ad  push r11
00007ff1409d47af  sub rsp, 0xF0
00007ff1409d47b6  vmovaps [rsp], xmm0
00007ff1409d47bb  vmovaps [rsp+0x10], xmm1
00007ff1409d47c1  vmovaps [rsp+0x20], xmm2
00007ff1409d47c7  vmovaps [rsp+0x30], xmm3
00007ff1409d47cd  vmovaps [rsp+0x40], xmm4
00007ff1409d47d3  vmovaps [rsp+0x50], xmm5
00007ff1409d47d9  vmovaps [rsp+0x60], xmm6
00007ff1409d47df  vmovaps [rsp+0x70], xmm7
00007ff1409d47e5  vmovaps [rsp+0x80], xmm8
00007ff1409d47ee  vmovaps [rsp+0x90], xmm9
00007ff1409d47f7  vmovaps [rsp+0xA0], xmm10
00007ff1409d4800  vmovaps [rsp+0xB0], xmm11
00007ff1409d4809  vmovaps [rsp+0xC0], xmm12
00007ff1409d4812  vmovaps [rsp+0xD0], xmm13
00007ff1409d481b  vmovaps [rsp+0xE0], xmm15
00007ff1409d4824  sub rsp, 0x30
00007ff1409d4828  movaps [rsp], xmm14
00007ff1409d482d  movaps [rsp+0x10], xmm2
00007ff1409d4832  movaps [rsp+0x20], xmm15
00007ff1409d4838  lea rdi, [rsp]
00007ff1409d483c  mov esi, 0x00
00007ff1409d4841  mov rax, 0x565C7F10C530
00007ff1409d484b  call rax
00007ff1409d484d  movaps xmm14, [rsp]
00007ff1409d4852  add rsp, 0x30
00007ff1409d4856  vmovaps xmm0, [rsp]
00007ff1409d485b  vmovaps xmm1, [rsp+0x10]
00007ff1409d4861  vmovaps xmm2, [rsp+0x20]
00007ff1409d4867  vmovaps xmm3, [rsp+0x30]
00007ff1409d486d  vmovaps xmm4, [rsp+0x40]
00007ff1409d4873  vmovaps xmm5, [rsp+0x50]
00007ff1409d4879  vmovaps xmm6, [rsp+0x60]
00007ff1409d487f  vmovaps xmm7, [rsp+0x70]
00007ff1409d4885  vmovaps xmm8, [rsp+0x80]
00007ff1409d488e  vmovaps xmm9, [rsp+0x90]
00007ff1409d4897  vmovaps xmm10, [rsp+0xA0]
00007ff1409d48a0  vmovaps xmm11, [rsp+0xB0]
00007ff1409d48a9  vmovaps xmm12, [rsp+0xC0]
00007ff1409d48b2  vmovaps xmm13, [rsp+0xD0]
00007ff1409d48bb  vmovaps xmm15, [rsp+0xE0]
00007ff1409d48c4  add rsp, 0xF0
00007ff1409d48cb  pop r11
00007ff1409d48cd  pop r10
00007ff1409d48cf  pop r9
00007ff1409d48d1  pop r8
00007ff1409d48d3  pop rsi
00007ff1409d48d4  pop rdi
00007ff1409d48d5  pop rdx
00007ff1409d48d6  pop rcx
00007ff1409d48d7  pop rax
00007ff1409d48d8  add rsp, 0x08
00007ff1409d48dc  jmp 0x00007FF1409D2B05
00007ff1409d48e1  sub rsp, 0x08
00007ff1409d48e5  push rax
00007ff1409d48e6  push rcx
00007ff1409d48e7  push rdx
00007ff1409d48e8  push rdi
00007ff1409d48e9  push rsi
00007ff1409d48ea  push r8
00007ff1409d48ec  push r9
00007ff1409d48ee  push r10
00007ff1409d48f0  push r11
00007ff1409d48f2  sub rsp, 0xF0
00007ff1409d48f9  vmovaps [rsp], xmm0
00007ff1409d48fe  vmovaps [rsp+0x10], xmm1
00007ff1409d4904  vmovaps [rsp+0x20], xmm2
00007ff1409d490a  vmovaps [rsp+0x30], xmm3
00007ff1409d4910  vmovaps [rsp+0x40], xmm4
00007ff1409d4916  vmovaps [rsp+0x50], xmm5
00007ff1409d491c  vmovaps [rsp+0x60], xmm6
00007ff1409d4922  vmovaps [rsp+0x70], xmm7
00007ff1409d4928  vmovaps [rsp+0x80], xmm8
00007ff1409d4931  vmovaps [rsp+0x90], xmm9
00007ff1409d493a  vmovaps [rsp+0xA0], xmm10
00007ff1409d4943  vmovaps [rsp+0xB0], xmm11
00007ff1409d494c  vmovaps [rsp+0xC0], xmm12
00007ff1409d4955  vmovaps [rsp+0xD0], xmm13
00007ff1409d495e  vmovaps [rsp+0xE0], xmm14
00007ff1409d4967  sub rsp, 0x30
00007ff1409d496b  movaps [rsp], xmm15
00007ff1409d4970  movaps [rsp+0x10], xmm2
00007ff1409d4975  movaps [rsp+0x20], xmm1
00007ff1409d497a  lea rdi, [rsp]
00007ff1409d497e  mov esi, 0x00
00007ff1409d4983  mov rax, 0x565C7F10C530
00007ff1409d498d  call rax
00007ff1409d498f  movaps xmm15, [rsp]
00007ff1409d4994  add rsp, 0x30
00007ff1409d4998  vmovaps xmm0, [rsp]
00007ff1409d499d  vmovaps xmm1, [rsp+0x10]
00007ff1409d49a3  vmovaps xmm2, [rsp+0x20]
00007ff1409d49a9  vmovaps xmm3, [rsp+0x30]
00007ff1409d49af  vmovaps xmm4, [rsp+0x40]
00007ff1409d49b5  vmovaps xmm5, [rsp+0x50]
00007ff1409d49bb  vmovaps xmm6, [rsp+0x60]
00007ff1409d49c1  vmovaps xmm7, [rsp+0x70]
00007ff1409d49c7  vmovaps xmm8, [rsp+0x80]
00007ff1409d49d0  vmovaps xmm9, [rsp+0x90]
00007ff1409d49d9  vmovaps xmm10, [rsp+0xA0]
00007ff1409d49e2  vmovaps xmm11, [rsp+0xB0]
00007ff1409d49eb  vmovaps xmm12, [rsp+0xC0]
00007ff1409d49f4  vmovaps xmm13, [rsp+0xD0]
00007ff1409d49fd  vmovaps xmm14, [rsp+0xE0]
00007ff1409d4a06  add rsp, 0xF0
00007ff1409d4a0d  pop r11
00007ff1409d4a0f  pop r10
00007ff1409d4a11  pop r9
00007ff1409d4a13  pop r8
00007ff1409d4a15  pop rsi
00007ff1409d4a16  pop rdi
00007ff1409d4a17  pop rdx
00007ff1409d4a18  pop rcx
00007ff1409d4a19  pop rax
00007ff1409d4a1a  add rsp, 0x08
00007ff1409d4a1e  jmp 0x00007FF1409D2B41
00007ff1409d4a23  call 0x00007FF1407FF430
00007ff1409d4a28  jmp 0x00007FF1409D2B4E
00007ff1409d4a2d  sub rsp, 0x08
00007ff1409d4a31  push rax
00007ff1409d4a32  push rcx
00007ff1409d4a33  push rdx
00007ff1409d4a34  push rdi
00007ff1409d4a35  push rsi
00007ff1409d4a36  push r8
00007ff1409d4a38  push r9
00007ff1409d4a3a  push r10
00007ff1409d4a3c  push r11
00007ff1409d4a3e  sub rsp, 0xF0
00007ff1409d4a45  vmovaps [rsp], xmm0
00007ff1409d4a4a  vmovaps [rsp+0x10], xmm1
00007ff1409d4a50  vmovaps [rsp+0x20], xmm3
00007ff1409d4a56  vmovaps [rsp+0x30], xmm4
00007ff1409d4a5c  vmovaps [rsp+0x40], xmm5
00007ff1409d4a62  vmovaps [rsp+0x50], xmm6
00007ff1409d4a68  vmovaps [rsp+0x60], xmm7
00007ff1409d4a6e  vmovaps [rsp+0x70], xmm8
00007ff1409d4a74  vmovaps [rsp+0x80], xmm9
00007ff1409d4a7d  vmovaps [rsp+0x90], xmm10
00007ff1409d4a86  vmovaps [rsp+0xA0], xmm11
00007ff1409d4a8f  vmovaps [rsp+0xB0], xmm12
00007ff1409d4a98  vmovaps [rsp+0xC0], xmm13
00007ff1409d4aa1  vmovaps [rsp+0xD0], xmm14
00007ff1409d4aaa  vmovaps [rsp+0xE0], xmm15
00007ff1409d4ab3  sub rsp, 0x30
00007ff1409d4ab7  movaps [rsp], xmm2
00007ff1409d4abb  movaps [rsp+0x10], xmm1
00007ff1409d4ac0  movaps [rsp+0x20], xmm14
00007ff1409d4ac6  lea rdi, [rsp]
00007ff1409d4aca  mov esi, 0x00
00007ff1409d4acf  mov rax, 0x565C7F10C530
00007ff1409d4ad9  call rax
00007ff1409d4adb  movaps xmm2, [rsp]
00007ff1409d4adf  add rsp, 0x30
00007ff1409d4ae3  vmovaps xmm0, [rsp]
00007ff1409d4ae8  vmovaps xmm1, [rsp+0x10]
00007ff1409d4aee  vmovaps xmm3, [rsp+0x20]
00007ff1409d4af4  vmovaps xmm4, [rsp+0x30]
00007ff1409d4afa  vmovaps xmm5, [rsp+0x40]
00007ff1409d4b00  vmovaps xmm6, [rsp+0x50]
00007ff1409d4b06  vmovaps xmm7, [rsp+0x60]
00007ff1409d4b0c  vmovaps xmm8, [rsp+0x70]
00007ff1409d4b12  vmovaps xmm9, [rsp+0x80]
00007ff1409d4b1b  vmovaps xmm10, [rsp+0x90]
00007ff1409d4b24  vmovaps xmm11, [rsp+0xA0]
00007ff1409d4b2d  vmovaps xmm12, [rsp+0xB0]
00007ff1409d4b36  vmovaps xmm13, [rsp+0xC0]
00007ff1409d4b3f  vmovaps xmm14, [rsp+0xD0]
00007ff1409d4b48  vmovaps xmm15, [rsp+0xE0]
00007ff1409d4b51  add rsp, 0xF0
00007ff1409d4b58  pop r11
00007ff1409d4b5a  pop r10
00007ff1409d4b5c  pop r9
00007ff1409d4b5e  pop r8
00007ff1409d4b60  pop rsi
00007ff1409d4b61  pop rdi
00007ff1409d4b62  pop rdx
00007ff1409d4b63  pop rcx
00007ff1409d4b64  pop rax
00007ff1409d4b65  add rsp, 0x08
00007ff1409d4b69  jmp 0x00007FF1409D2B8B
00007ff1409d4b6e  sub rsp, 0x08
00007ff1409d4b72  push rax
00007ff1409d4b73  push rcx
00007ff1409d4b74  push rdx
00007ff1409d4b75  push rdi
00007ff1409d4b76  push rsi
00007ff1409d4b77  push r8
00007ff1409d4b79  push r9
00007ff1409d4b7b  push r10
00007ff1409d4b7d  push r11
00007ff1409d4b7f  sub rsp, 0xF0
00007ff1409d4b86  vmovaps [rsp], xmm0
00007ff1409d4b8b  vmovaps [rsp+0x10], xmm1
00007ff1409d4b91  vmovaps [rsp+0x20], xmm2
00007ff1409d4b97  vmovaps [rsp+0x30], xmm3
00007ff1409d4b9d  vmovaps [rsp+0x40], xmm4
00007ff1409d4ba3  vmovaps [rsp+0x50], xmm5
00007ff1409d4ba9  vmovaps [rsp+0x60], xmm6
00007ff1409d4baf  vmovaps [rsp+0x70], xmm7
00007ff1409d4bb5  vmovaps [rsp+0x80], xmm8
00007ff1409d4bbe  vmovaps [rsp+0x90], xmm9
00007ff1409d4bc7  vmovaps [rsp+0xA0], xmm10
00007ff1409d4bd0  vmovaps [rsp+0xB0], xmm11
00007ff1409d4bd9  vmovaps [rsp+0xC0], xmm12
00007ff1409d4be2  vmovaps [rsp+0xD0], xmm13
00007ff1409d4beb  vmovaps [rsp+0xE0], xmm14
00007ff1409d4bf4  sub rsp, 0x30
00007ff1409d4bf8  movaps [rsp], xmm15
00007ff1409d4bfd  movaps [rsp+0x10], xmm14
00007ff1409d4c03  movaps [rsp+0x20], xmm1
00007ff1409d4c08  lea rdi, [rsp]
00007ff1409d4c0c  mov esi, 0x00
00007ff1409d4c11  mov rax, 0x565C7F10C530
00007ff1409d4c1b  call rax
00007ff1409d4c1d  movaps xmm15, [rsp]
00007ff1409d4c22  add rsp, 0x30
00007ff1409d4c26  vmovaps xmm0, [rsp]
00007ff1409d4c2b  vmovaps xmm1, [rsp+0x10]
00007ff1409d4c31  vmovaps xmm2, [rsp+0x20]
00007ff1409d4c37  vmovaps xmm3, [rsp+0x30]
00007ff1409d4c3d  vmovaps xmm4, [rsp+0x40]
00007ff1409d4c43  vmovaps xmm5, [rsp+0x50]
00007ff1409d4c49  vmovaps xmm6, [rsp+0x60]
00007ff1409d4c4f  vmovaps xmm7, [rsp+0x70]
00007ff1409d4c55  vmovaps xmm8, [rsp+0x80]
00007ff1409d4c5e  vmovaps xmm9, [rsp+0x90]
00007ff1409d4c67  vmovaps xmm10, [rsp+0xA0]
00007ff1409d4c70  vmovaps xmm11, [rsp+0xB0]
00007ff1409d4c79  vmovaps xmm12, [rsp+0xC0]
00007ff1409d4c82  vmovaps xmm13, [rsp+0xD0]
00007ff1409d4c8b  vmovaps xmm14, [rsp+0xE0]
00007ff1409d4c94  add rsp, 0xF0
00007ff1409d4c9b  pop r11
00007ff1409d4c9d  pop r10
00007ff1409d4c9f  pop r9
00007ff1409d4ca1  pop r8
00007ff1409d4ca3  pop rsi
00007ff1409d4ca4  pop rdi
00007ff1409d4ca5  pop rdx
00007ff1409d4ca6  pop rcx
00007ff1409d4ca7  pop rax
00007ff1409d4ca8  add rsp, 0x08
00007ff1409d4cac  jmp 0x00007FF1409D2C05
00007ff1409d4cb1  call 0x00007FF1407FF430
00007ff1409d4cb6  jmp 0x00007FF1409D2C12
00007ff1409d4cbb  sub rsp, 0x08
00007ff1409d4cbf  push rax
00007ff1409d4cc0  push rcx
00007ff1409d4cc1  push rdx
00007ff1409d4cc2  push rdi
00007ff1409d4cc3  push rsi
00007ff1409d4cc4  push r8
00007ff1409d4cc6  push r9
00007ff1409d4cc8  push r10
00007ff1409d4cca  push r11
00007ff1409d4ccc  sub rsp, 0xF0
00007ff1409d4cd3  vmovaps [rsp], xmm0
00007ff1409d4cd8  vmovaps [rsp+0x10], xmm1
00007ff1409d4cde  vmovaps [rsp+0x20], xmm2
00007ff1409d4ce4  vmovaps [rsp+0x30], xmm3
00007ff1409d4cea  vmovaps [rsp+0x40], xmm4
00007ff1409d4cf0  vmovaps [rsp+0x50], xmm5
00007ff1409d4cf6  vmovaps [rsp+0x60], xmm6
00007ff1409d4cfc  vmovaps [rsp+0x70], xmm7
00007ff1409d4d02  vmovaps [rsp+0x80], xmm8
00007ff1409d4d0b  vmovaps [rsp+0x90], xmm9
00007ff1409d4d14  vmovaps [rsp+0xA0], xmm10
00007ff1409d4d1d  vmovaps [rsp+0xB0], xmm11
00007ff1409d4d26  vmovaps [rsp+0xC0], xmm12
00007ff1409d4d2f  vmovaps [rsp+0xD0], xmm14
00007ff1409d4d38  vmovaps [rsp+0xE0], xmm15
00007ff1409d4d41  sub rsp, 0x30
00007ff1409d4d45  movaps [rsp], xmm13
00007ff1409d4d4a  movaps [rsp+0x10], xmm1
00007ff1409d4d4f  movaps [rsp+0x20], xmm15
00007ff1409d4d55  lea rdi, [rsp]
00007ff1409d4d59  mov esi, 0x00
00007ff1409d4d5e  mov rax, 0x565C7F10C530
00007ff1409d4d68  call rax
00007ff1409d4d6a  movaps xmm13, [rsp]
00007ff1409d4d6f  add rsp, 0x30
00007ff1409d4d73  vmovaps xmm0, [rsp]
00007ff1409d4d78  vmovaps xmm1, [rsp+0x10]
00007ff1409d4d7e  vmovaps xmm2, [rsp+0x20]
00007ff1409d4d84  vmovaps xmm3, [rsp+0x30]
00007ff1409d4d8a  vmovaps xmm4, [rsp+0x40]
00007ff1409d4d90  vmovaps xmm5, [rsp+0x50]
00007ff1409d4d96  vmovaps xmm6, [rsp+0x60]
00007ff1409d4d9c  vmovaps xmm7, [rsp+0x70]
00007ff1409d4da2  vmovaps xmm8, [rsp+0x80]
00007ff1409d4dab  vmovaps xmm9, [rsp+0x90]
00007ff1409d4db4  vmovaps xmm10, [rsp+0xA0]
00007ff1409d4dbd  vmovaps xmm11, [rsp+0xB0]
00007ff1409d4dc6  vmovaps xmm12, [rsp+0xC0]
00007ff1409d4dcf  vmovaps xmm14, [rsp+0xD0]
00007ff1409d4dd8  vmovaps xmm15, [rsp+0xE0]
00007ff1409d4de1  add rsp, 0xF0
00007ff1409d4de8  pop r11
00007ff1409d4dea  pop r10
00007ff1409d4dec  pop r9
00007ff1409d4dee  pop r8
00007ff1409d4df0  pop rsi
00007ff1409d4df1  pop rdi
00007ff1409d4df2  pop rdx
00007ff1409d4df3  pop rcx
00007ff1409d4df4  pop rax
00007ff1409d4df5  add rsp, 0x08
00007ff1409d4df9  jmp 0x00007FF1409D2CD6
00007ff1409d4dfe  sub rsp, 0x08
00007ff1409d4e02  push rax
00007ff1409d4e03  push rcx
00007ff1409d4e04  push rdx
00007ff1409d4e05  push rdi
00007ff1409d4e06  push rsi
00007ff1409d4e07  push r8
00007ff1409d4e09  push r9
00007ff1409d4e0b  push r10
00007ff1409d4e0d  push r11
00007ff1409d4e0f  sub rsp, 0xF0
00007ff1409d4e16  vmovaps [rsp], xmm0
00007ff1409d4e1b  vmovaps [rsp+0x10], xmm1
00007ff1409d4e21  vmovaps [rsp+0x20], xmm2
00007ff1409d4e27  vmovaps [rsp+0x30], xmm3
00007ff1409d4e2d  vmovaps [rsp+0x40], xmm4
00007ff1409d4e33  vmovaps [rsp+0x50], xmm5
00007ff1409d4e39  vmovaps [rsp+0x60], xmm6
00007ff1409d4e3f  vmovaps [rsp+0x70], xmm7
00007ff1409d4e45  vmovaps [rsp+0x80], xmm8
00007ff1409d4e4e  vmovaps [rsp+0x90], xmm9
00007ff1409d4e57  vmovaps [rsp+0xA0], xmm10
00007ff1409d4e60  vmovaps [rsp+0xB0], xmm11
00007ff1409d4e69  vmovaps [rsp+0xC0], xmm12
00007ff1409d4e72  vmovaps [rsp+0xD0], xmm13
00007ff1409d4e7b  vmovaps [rsp+0xE0], xmm14
00007ff1409d4e84  sub rsp, 0x30
00007ff1409d4e88  movaps [rsp], xmm15
00007ff1409d4e8d  movaps [rsp+0x10], xmm14
00007ff1409d4e93  movaps [rsp+0x20], xmm1
00007ff1409d4e98  lea rdi, [rsp]
00007ff1409d4e9c  mov esi, 0x00
00007ff1409d4ea1  mov rax, 0x565C7F10C530
00007ff1409d4eab  call rax
00007ff1409d4ead  movaps xmm15, [rsp]
00007ff1409d4eb2  add rsp, 0x30
00007ff1409d4eb6  vmovaps xmm0, [rsp]
00007ff1409d4ebb  vmovaps xmm1, [rsp+0x10]
00007ff1409d4ec1  vmovaps xmm2, [rsp+0x20]
00007ff1409d4ec7  vmovaps xmm3, [rsp+0x30]
00007ff1409d4ecd  vmovaps xmm4, [rsp+0x40]
00007ff1409d4ed3  vmovaps xmm5, [rsp+0x50]
00007ff1409d4ed9  vmovaps xmm6, [rsp+0x60]
00007ff1409d4edf  vmovaps xmm7, [rsp+0x70]
00007ff1409d4ee5  vmovaps xmm8, [rsp+0x80]
00007ff1409d4eee  vmovaps xmm9, [rsp+0x90]
00007ff1409d4ef7  vmovaps xmm10, [rsp+0xA0]
00007ff1409d4f00  vmovaps xmm11, [rsp+0xB0]
00007ff1409d4f09  vmovaps xmm12, [rsp+0xC0]
00007ff1409d4f12  vmovaps xmm13, [rsp+0xD0]
00007ff1409d4f1b  vmovaps xmm14, [rsp+0xE0]
00007ff1409d4f24  add rsp, 0xF0
00007ff1409d4f2b  pop r11
00007ff1409d4f2d  pop r10
00007ff1409d4f2f  pop r9
00007ff1409d4f31  pop r8
00007ff1409d4f33  pop rsi
00007ff1409d4f34  pop rdi
00007ff1409d4f35  pop rdx
00007ff1409d4f36  pop rcx
00007ff1409d4f37  pop rax
00007ff1409d4f38  add rsp, 0x08
00007ff1409d4f3c  jmp 0x00007FF1409D2D12
00007ff1409d4f41  call 0x00007FF1407FF430
00007ff1409d4f46  jmp 0x00007FF1409D2D1F
00007ff1409d4f4b  sub rsp, 0x08
00007ff1409d4f4f  push rax
00007ff1409d4f50  push rcx
00007ff1409d4f51  push rdx
00007ff1409d4f52  push rdi
00007ff1409d4f53  push rsi
00007ff1409d4f54  push r8
00007ff1409d4f56  push r9
00007ff1409d4f58  push r10
00007ff1409d4f5a  push r11
00007ff1409d4f5c  sub rsp, 0xF0
00007ff1409d4f63  vmovaps [rsp], xmm0
00007ff1409d4f68  vmovaps [rsp+0x10], xmm1
00007ff1409d4f6e  vmovaps [rsp+0x20], xmm2
00007ff1409d4f74  vmovaps [rsp+0x30], xmm3
00007ff1409d4f7a  vmovaps [rsp+0x40], xmm4
00007ff1409d4f80  vmovaps [rsp+0x50], xmm5
00007ff1409d4f86  vmovaps [rsp+0x60], xmm6
00007ff1409d4f8c  vmovaps [rsp+0x70], xmm7
00007ff1409d4f92  vmovaps [rsp+0x80], xmm8
00007ff1409d4f9b  vmovaps [rsp+0x90], xmm9
00007ff1409d4fa4  vmovaps [rsp+0xA0], xmm10
00007ff1409d4fad  vmovaps [rsp+0xB0], xmm11
00007ff1409d4fb6  vmovaps [rsp+0xC0], xmm12
00007ff1409d4fbf  vmovaps [rsp+0xD0], xmm13
00007ff1409d4fc8  vmovaps [rsp+0xE0], xmm15
00007ff1409d4fd1  sub rsp, 0x30
00007ff1409d4fd5  movaps [rsp], xmm14
00007ff1409d4fda  movaps [rsp+0x10], xmm13
00007ff1409d4fe0  movaps [rsp+0x20], xmm2
00007ff1409d4fe5  lea rdi, [rsp]
00007ff1409d4fe9  mov esi, 0x00
00007ff1409d4fee  mov rax, 0x565C7F10C530
00007ff1409d4ff8  call rax
00007ff1409d4ffa  movaps xmm14, [rsp]
00007ff1409d4fff  add rsp, 0x30
00007ff1409d5003  vmovaps xmm0, [rsp]
00007ff1409d5008  vmovaps xmm1, [rsp+0x10]
00007ff1409d500e  vmovaps xmm2, [rsp+0x20]
00007ff1409d5014  vmovaps xmm3, [rsp+0x30]
00007ff1409d501a  vmovaps xmm4, [rsp+0x40]
00007ff1409d5020  vmovaps xmm5, [rsp+0x50]
00007ff1409d5026  vmovaps xmm6, [rsp+0x60]
00007ff1409d502c  vmovaps xmm7, [rsp+0x70]
00007ff1409d5032  vmovaps xmm8, [rsp+0x80]
00007ff1409d503b  vmovaps xmm9, [rsp+0x90]
00007ff1409d5044  vmovaps xmm10, [rsp+0xA0]
00007ff1409d504d  vmovaps xmm11, [rsp+0xB0]
00007ff1409d5056  vmovaps xmm12, [rsp+0xC0]
00007ff1409d505f  vmovaps xmm13, [rsp+0xD0]
00007ff1409d5068  vmovaps xmm15, [rsp+0xE0]
00007ff1409d5071  add rsp, 0xF0
00007ff1409d5078  pop r11
00007ff1409d507a  pop r10
00007ff1409d507c  pop r9
00007ff1409d507e  pop r8
00007ff1409d5080  pop rsi
00007ff1409d5081  pop rdi
00007ff1409d5082  pop rdx
00007ff1409d5083  pop rcx
00007ff1409d5084  pop rax
00007ff1409d5085  add rsp, 0x08
00007ff1409d5089  jmp 0x00007FF1409D2D4B
00007ff1409d508e  sub rsp, 0x08
00007ff1409d5092  push rax
00007ff1409d5093  push rcx
00007ff1409d5094  push rdx
00007ff1409d5095  push rdi
00007ff1409d5096  push rsi
00007ff1409d5097  push r8
00007ff1409d5099  push r9
00007ff1409d509b  push r10
00007ff1409d509d  push r11
00007ff1409d509f  sub rsp, 0xF0
00007ff1409d50a6  vmovaps [rsp], xmm0
00007ff1409d50ab  vmovaps [rsp+0x10], xmm2
00007ff1409d50b1  vmovaps [rsp+0x20], xmm3
00007ff1409d50b7  vmovaps [rsp+0x30], xmm4
00007ff1409d50bd  vmovaps [rsp+0x40], xmm5
00007ff1409d50c3  vmovaps [rsp+0x50], xmm6
00007ff1409d50c9  vmovaps [rsp+0x60], xmm7
00007ff1409d50cf  vmovaps [rsp+0x70], xmm8
00007ff1409d50d5  vmovaps [rsp+0x80], xmm9
00007ff1409d50de  vmovaps [rsp+0x90], xmm10
00007ff1409d50e7  vmovaps [rsp+0xA0], xmm11
00007ff1409d50f0  vmovaps [rsp+0xB0], xmm12
00007ff1409d50f9  vmovaps [rsp+0xC0], xmm13
00007ff1409d5102  vmovaps [rsp+0xD0], xmm14
00007ff1409d510b  vmovaps [rsp+0xE0], xmm15
00007ff1409d5114  sub rsp, 0x30
00007ff1409d5118  movaps [rsp], xmm1
00007ff1409d511c  movaps [rsp+0x10], xmm13
00007ff1409d5122  movaps [rsp+0x20], xmm2
00007ff1409d5127  lea rdi, [rsp]
00007ff1409d512b  mov esi, 0x00
00007ff1409d5130  mov rax, 0x565C7F10C530
00007ff1409d513a  call rax
00007ff1409d513c  movaps xmm1, [rsp]
00007ff1409d5140  add rsp, 0x30
00007ff1409d5144  vmovaps xmm0, [rsp]
00007ff1409d5149  vmovaps xmm2, [rsp+0x10]
00007ff1409d514f  vmovaps xmm3, [rsp+0x20]
00007ff1409d5155  vmovaps xmm4, [rsp+0x30]
00007ff1409d515b  vmovaps xmm5, [rsp+0x40]
00007ff1409d5161  vmovaps xmm6, [rsp+0x50]
00007ff1409d5167  vmovaps xmm7, [rsp+0x60]
00007ff1409d516d  vmovaps xmm8, [rsp+0x70]
00007ff1409d5173  vmovaps xmm9, [rsp+0x80]
00007ff1409d517c  vmovaps xmm10, [rsp+0x90]
00007ff1409d5185  vmovaps xmm11, [rsp+0xA0]
00007ff1409d518e  vmovaps xmm12, [rsp+0xB0]
00007ff1409d5197  vmovaps xmm13, [rsp+0xC0]
00007ff1409d51a0  vmovaps xmm14, [rsp+0xD0]
00007ff1409d51a9  vmovaps xmm15, [rsp+0xE0]
00007ff1409d51b2  add rsp, 0xF0
00007ff1409d51b9  pop r11
00007ff1409d51bb  pop r10
00007ff1409d51bd  pop r9
00007ff1409d51bf  pop r8
00007ff1409d51c1  pop rsi
00007ff1409d51c2  pop rdi
00007ff1409d51c3  pop rdx
00007ff1409d51c4  pop rcx
00007ff1409d51c5  pop rax
00007ff1409d51c6  add rsp, 0x08
00007ff1409d51ca  jmp 0x00007FF1409D2D79
00007ff1409d51cf  sub rsp, 0x08
00007ff1409d51d3  push rax
00007ff1409d51d4  push rcx
00007ff1409d51d5  push rdx
00007ff1409d51d6  push rdi
00007ff1409d51d7  push rsi
00007ff1409d51d8  push r8
00007ff1409d51da  push r9
00007ff1409d51dc  push r10
00007ff1409d51de  push r11
00007ff1409d51e0  sub rsp, 0xF0
00007ff1409d51e7  vmovaps [rsp], xmm0
00007ff1409d51ec  vmovaps [rsp+0x10], xmm1
00007ff1409d51f2  vmovaps [rsp+0x20], xmm3
00007ff1409d51f8  vmovaps [rsp+0x30], xmm4
00007ff1409d51fe  vmovaps [rsp+0x40], xmm5
00007ff1409d5204  vmovaps [rsp+0x50], xmm6
00007ff1409d520a  vmovaps [rsp+0x60], xmm7
00007ff1409d5210  vmovaps [rsp+0x70], xmm8
00007ff1409d5216  vmovaps [rsp+0x80], xmm9
00007ff1409d521f  vmovaps [rsp+0x90], xmm10
00007ff1409d5228  vmovaps [rsp+0xA0], xmm11
00007ff1409d5231  vmovaps [rsp+0xB0], xmm12
00007ff1409d523a  vmovaps [rsp+0xC0], xmm13
00007ff1409d5243  vmovaps [rsp+0xD0], xmm14
00007ff1409d524c  vmovaps [rsp+0xE0], xmm15
00007ff1409d5255  sub rsp, 0x30
00007ff1409d5259  movaps [rsp], xmm2
00007ff1409d525d  movaps [rsp+0x10], xmm1
00007ff1409d5262  movaps [rsp+0x20], xmm13
00007ff1409d5268  lea rdi, [rsp]
00007ff1409d526c  mov esi, 0x00
00007ff1409d5271  mov rax, 0x565C7F10C530
00007ff1409d527b  call rax
00007ff1409d527d  movaps xmm2, [rsp]
00007ff1409d5281  add rsp, 0x30
00007ff1409d5285  vmovaps xmm0, [rsp]
00007ff1409d528a  vmovaps xmm1, [rsp+0x10]
00007ff1409d5290  vmovaps xmm3, [rsp+0x20]
00007ff1409d5296  vmovaps xmm4, [rsp+0x30]
00007ff1409d529c  vmovaps xmm5, [rsp+0x40]
00007ff1409d52a2  vmovaps xmm6, [rsp+0x50]
00007ff1409d52a8  vmovaps xmm7, [rsp+0x60]
00007ff1409d52ae  vmovaps xmm8, [rsp+0x70]
00007ff1409d52b4  vmovaps xmm9, [rsp+0x80]
00007ff1409d52bd  vmovaps xmm10, [rsp+0x90]
00007ff1409d52c6  vmovaps xmm11, [rsp+0xA0]
00007ff1409d52cf  vmovaps xmm12, [rsp+0xB0]
00007ff1409d52d8  vmovaps xmm13, [rsp+0xC0]
00007ff1409d52e1  vmovaps xmm14, [rsp+0xD0]
00007ff1409d52ea  vmovaps xmm15, [rsp+0xE0]
00007ff1409d52f3  add rsp, 0xF0
00007ff1409d52fa  pop r11
00007ff1409d52fc  pop r10
00007ff1409d52fe  pop r9
00007ff1409d5300  pop r8
00007ff1409d5302  pop rsi
00007ff1409d5303  pop rdi
00007ff1409d5304  pop rdx
00007ff1409d5305  pop rcx
00007ff1409d5306  pop rax
00007ff1409d5307  add rsp, 0x08
00007ff1409d530b  jmp 0x00007FF1409D2DD2
00007ff1409d5310  call 0x00007FF1407FF430
00007ff1409d5315  jmp 0x00007FF1409D2DDF
00007ff1409d531a  sub rsp, 0x08
00007ff1409d531e  push rax
00007ff1409d531f  push rcx
00007ff1409d5320  push rdx
00007ff1409d5321  push rdi
00007ff1409d5322  push rsi
00007ff1409d5323  push r8
00007ff1409d5325  push r9
00007ff1409d5327  push r10
00007ff1409d5329  push r11
00007ff1409d532b  sub rsp, 0xF0
00007ff1409d5332  vmovaps [rsp], xmm0
00007ff1409d5337  vmovaps [rsp+0x10], xmm1
00007ff1409d533d  vmovaps [rsp+0x20], xmm2
00007ff1409d5343  vmovaps [rsp+0x30], xmm3
00007ff1409d5349  vmovaps [rsp+0x40], xmm4
00007ff1409d534f  vmovaps [rsp+0x50], xmm5
00007ff1409d5355  vmovaps [rsp+0x60], xmm6
00007ff1409d535b  vmovaps [rsp+0x70], xmm7
00007ff1409d5361  vmovaps [rsp+0x80], xmm8
00007ff1409d536a  vmovaps [rsp+0x90], xmm9
00007ff1409d5373  vmovaps [rsp+0xA0], xmm10
00007ff1409d537c  vmovaps [rsp+0xB0], xmm11
00007ff1409d5385  vmovaps [rsp+0xC0], xmm12
00007ff1409d538e  vmovaps [rsp+0xD0], xmm13
00007ff1409d5397  vmovaps [rsp+0xE0], xmm14
00007ff1409d53a0  sub rsp, 0x30
00007ff1409d53a4  movaps [rsp], xmm15
00007ff1409d53a9  movaps [rsp+0x10], xmm13
00007ff1409d53af  movaps [rsp+0x20], xmm1
00007ff1409d53b4  lea rdi, [rsp]
00007ff1409d53b8  mov esi, 0x00
00007ff1409d53bd  mov rax, 0x565C7F10C530
00007ff1409d53c7  call rax
00007ff1409d53c9  movaps xmm15, [rsp]
00007ff1409d53ce  add rsp, 0x30
00007ff1409d53d2  vmovaps xmm0, [rsp]
00007ff1409d53d7  vmovaps xmm1, [rsp+0x10]
00007ff1409d53dd  vmovaps xmm2, [rsp+0x20]
00007ff1409d53e3  vmovaps xmm3, [rsp+0x30]
00007ff1409d53e9  vmovaps xmm4, [rsp+0x40]
00007ff1409d53ef  vmovaps xmm5, [rsp+0x50]
00007ff1409d53f5  vmovaps xmm6, [rsp+0x60]
00007ff1409d53fb  vmovaps xmm7, [rsp+0x70]
00007ff1409d5401  vmovaps xmm8, [rsp+0x80]
00007ff1409d540a  vmovaps xmm9, [rsp+0x90]
00007ff1409d5413  vmovaps xmm10, [rsp+0xA0]
00007ff1409d541c  vmovaps xmm11, [rsp+0xB0]
00007ff1409d5425  vmovaps xmm12, [rsp+0xC0]
00007ff1409d542e  vmovaps xmm13, [rsp+0xD0]
00007ff1409d5437  vmovaps xmm14, [rsp+0xE0]
00007ff1409d5440  add rsp, 0xF0
00007ff1409d5447  pop r11
00007ff1409d5449  pop r10
00007ff1409d544b  pop r9
00007ff1409d544d  pop r8
00007ff1409d544f  pop rsi
00007ff1409d5450  pop rdi
00007ff1409d5451  pop rdx
00007ff1409d5452  pop rcx
00007ff1409d5453  pop rax
00007ff1409d5454  add rsp, 0x08
00007ff1409d5458  jmp 0x00007FF1409D2E1E
00007ff1409d545d  sub rsp, 0x08
00007ff1409d5461  push rax
00007ff1409d5462  push rcx
00007ff1409d5463  push rdx
00007ff1409d5464  push rdi
00007ff1409d5465  push rsi
00007ff1409d5466  push r8
00007ff1409d5468  push r9
00007ff1409d546a  push r10
00007ff1409d546c  push r11
00007ff1409d546e  sub rsp, 0xF0
00007ff1409d5475  vmovaps [rsp], xmm0
00007ff1409d547a  vmovaps [rsp+0x10], xmm1
00007ff1409d5480  vmovaps [rsp+0x20], xmm2
00007ff1409d5486  vmovaps [rsp+0x30], xmm3
00007ff1409d548c  vmovaps [rsp+0x40], xmm4
00007ff1409d5492  vmovaps [rsp+0x50], xmm5
00007ff1409d5498  vmovaps [rsp+0x60], xmm6
00007ff1409d549e  vmovaps [rsp+0x70], xmm7
00007ff1409d54a4  vmovaps [rsp+0x80], xmm8
00007ff1409d54ad  vmovaps [rsp+0x90], xmm9
00007ff1409d54b6  vmovaps [rsp+0xA0], xmm10
00007ff1409d54bf  vmovaps [rsp+0xB0], xmm11
00007ff1409d54c8  vmovaps [rsp+0xC0], xmm12
00007ff1409d54d1  vmovaps [rsp+0xD0], xmm13
00007ff1409d54da  vmovaps [rsp+0xE0], xmm15
00007ff1409d54e3  sub rsp, 0x30
00007ff1409d54e7  movaps [rsp], xmm14
00007ff1409d54ec  movaps [rsp+0x10], xmm11
00007ff1409d54f2  movaps [rsp+0x20], xmm1
00007ff1409d54f7  lea rdi, [rsp]
00007ff1409d54fb  mov esi, 0x00
00007ff1409d5500  mov rax, 0x565C7F10C530
00007ff1409d550a  call rax
00007ff1409d550c  movaps xmm14, [rsp]
00007ff1409d5511  add rsp, 0x30
00007ff1409d5515  vmovaps xmm0, [rsp]
00007ff1409d551a  vmovaps xmm1, [rsp+0x10]
00007ff1409d5520  vmovaps xmm2, [rsp+0x20]
00007ff1409d5526  vmovaps xmm3, [rsp+0x30]
00007ff1409d552c  vmovaps xmm4, [rsp+0x40]
00007ff1409d5532  vmovaps xmm5, [rsp+0x50]
00007ff1409d5538  vmovaps xmm6, [rsp+0x60]
00007ff1409d553e  vmovaps xmm7, [rsp+0x70]
00007ff1409d5544  vmovaps xmm8, [rsp+0x80]
00007ff1409d554d  vmovaps xmm9, [rsp+0x90]
00007ff1409d5556  vmovaps xmm10, [rsp+0xA0]
00007ff1409d555f  vmovaps xmm11, [rsp+0xB0]
00007ff1409d5568  vmovaps xmm12, [rsp+0xC0]
00007ff1409d5571  vmovaps xmm13, [rsp+0xD0]
00007ff1409d557a  vmovaps xmm15, [rsp+0xE0]
00007ff1409d5583  add rsp, 0xF0
00007ff1409d558a  pop r11
00007ff1409d558c  pop r10
00007ff1409d558e  pop r9
00007ff1409d5590  pop r8
00007ff1409d5592  pop rsi
00007ff1409d5593  pop rdi
00007ff1409d5594  pop rdx
00007ff1409d5595  pop rcx
00007ff1409d5596  pop rax
00007ff1409d5597  add rsp, 0x08
00007ff1409d559b  jmp 0x00007FF1409D2E48
00007ff1409d55a0  sub rsp, 0x08
00007ff1409d55a4  push rax
00007ff1409d55a5  push rcx
00007ff1409d55a6  push rdx
00007ff1409d55a7  push rdi
00007ff1409d55a8  push rsi
00007ff1409d55a9  push r8
00007ff1409d55ab  push r9
00007ff1409d55ad  push r10
00007ff1409d55af  push r11
00007ff1409d55b1  sub rsp, 0xF0
00007ff1409d55b8  vmovaps [rsp], xmm0
00007ff1409d55bd  vmovaps [rsp+0x10], xmm1
00007ff1409d55c3  vmovaps [rsp+0x20], xmm2
00007ff1409d55c9  vmovaps [rsp+0x30], xmm3
00007ff1409d55cf  vmovaps [rsp+0x40], xmm4
00007ff1409d55d5  vmovaps [rsp+0x50], xmm5
00007ff1409d55db  vmovaps [rsp+0x60], xmm6
00007ff1409d55e1  vmovaps [rsp+0x70], xmm7
00007ff1409d55e7  vmovaps [rsp+0x80], xmm8
00007ff1409d55f0  vmovaps [rsp+0x90], xmm9
00007ff1409d55f9  vmovaps [rsp+0xA0], xmm10
00007ff1409d5602  vmovaps [rsp+0xB0], xmm11
00007ff1409d560b  vmovaps [rsp+0xC0], xmm12
00007ff1409d5614  vmovaps [rsp+0xD0], xmm14
00007ff1409d561d  vmovaps [rsp+0xE0], xmm15
00007ff1409d5626  sub rsp, 0x30
00007ff1409d562a  movaps [rsp], xmm13
00007ff1409d562f  movaps [rsp+0x10], xmm11
00007ff1409d5635  movaps [rsp+0x20], xmm1
00007ff1409d563a  lea rdi, [rsp]
00007ff1409d563e  mov esi, 0x00
00007ff1409d5643  mov rax, 0x565C7F10C530
00007ff1409d564d  call rax
00007ff1409d564f  movaps xmm13, [rsp]
00007ff1409d5654  add rsp, 0x30
00007ff1409d5658  vmovaps xmm0, [rsp]
00007ff1409d565d  vmovaps xmm1, [rsp+0x10]
00007ff1409d5663  vmovaps xmm2, [rsp+0x20]
00007ff1409d5669  vmovaps xmm3, [rsp+0x30]
00007ff1409d566f  vmovaps xmm4, [rsp+0x40]
00007ff1409d5675  vmovaps xmm5, [rsp+0x50]
00007ff1409d567b  vmovaps xmm6, [rsp+0x60]
00007ff1409d5681  vmovaps xmm7, [rsp+0x70]
00007ff1409d5687  vmovaps xmm8, [rsp+0x80]
00007ff1409d5690  vmovaps xmm9, [rsp+0x90]
00007ff1409d5699  vmovaps xmm10, [rsp+0xA0]
00007ff1409d56a2  vmovaps xmm11, [rsp+0xB0]
00007ff1409d56ab  vmovaps xmm12, [rsp+0xC0]
00007ff1409d56b4  vmovaps xmm14, [rsp+0xD0]
00007ff1409d56bd  vmovaps xmm15, [rsp+0xE0]
00007ff1409d56c6  add rsp, 0xF0
00007ff1409d56cd  pop r11
00007ff1409d56cf  pop r10
00007ff1409d56d1  pop r9
00007ff1409d56d3  pop r8
00007ff1409d56d5  pop rsi
00007ff1409d56d6  pop rdi
00007ff1409d56d7  pop rdx
00007ff1409d56d8  pop rcx
00007ff1409d56d9  pop rax
00007ff1409d56da  add rsp, 0x08
00007ff1409d56de  jmp 0x00007FF1409D2E9D
00007ff1409d56e3  call 0x00007FF1407FF430
00007ff1409d56e8  jmp 0x00007FF1409D2EAA
00007ff1409d56ed  sub rsp, 0x08
00007ff1409d56f1  push rax
00007ff1409d56f2  push rcx
00007ff1409d56f3  push rdx
00007ff1409d56f4  push rdi
00007ff1409d56f5  push rsi
00007ff1409d56f6  push r8
00007ff1409d56f8  push r9
00007ff1409d56fa  push r10
00007ff1409d56fc  push r11
00007ff1409d56fe  sub rsp, 0xF0
00007ff1409d5705  vmovaps [rsp], xmm0
00007ff1409d570a  vmovaps [rsp+0x10], xmm1
00007ff1409d5710  vmovaps [rsp+0x20], xmm2
00007ff1409d5716  vmovaps [rsp+0x30], xmm3
00007ff1409d571c  vmovaps [rsp+0x40], xmm4
00007ff1409d5722  vmovaps [rsp+0x50], xmm5
00007ff1409d5728  vmovaps [rsp+0x60], xmm6
00007ff1409d572e  vmovaps [rsp+0x70], xmm7
00007ff1409d5734  vmovaps [rsp+0x80], xmm8
00007ff1409d573d  vmovaps [rsp+0x90], xmm9
00007ff1409d5746  vmovaps [rsp+0xA0], xmm10
00007ff1409d574f  vmovaps [rsp+0xB0], xmm11
00007ff1409d5758  vmovaps [rsp+0xC0], xmm12
00007ff1409d5761  vmovaps [rsp+0xD0], xmm13
00007ff1409d576a  vmovaps [rsp+0xE0], xmm14
00007ff1409d5773  sub rsp, 0x30
00007ff1409d5777  movaps [rsp], xmm15
00007ff1409d577c  movaps [rsp+0x10], xmm11
00007ff1409d5782  movaps [rsp+0x20], xmm1
00007ff1409d5787  lea rdi, [rsp]
00007ff1409d578b  mov esi, 0x00
00007ff1409d5790  mov rax, 0x565C7F10C530
00007ff1409d579a  call rax
00007ff1409d579c  movaps xmm15, [rsp]
00007ff1409d57a1  add rsp, 0x30
00007ff1409d57a5  vmovaps xmm0, [rsp]
00007ff1409d57aa  vmovaps xmm1, [rsp+0x10]
00007ff1409d57b0  vmovaps xmm2, [rsp+0x20]
00007ff1409d57b6  vmovaps xmm3, [rsp+0x30]
00007ff1409d57bc  vmovaps xmm4, [rsp+0x40]
00007ff1409d57c2  vmovaps xmm5, [rsp+0x50]
00007ff1409d57c8  vmovaps xmm6, [rsp+0x60]
00007ff1409d57ce  vmovaps xmm7, [rsp+0x70]
00007ff1409d57d4  vmovaps xmm8, [rsp+0x80]
00007ff1409d57dd  vmovaps xmm9, [rsp+0x90]
00007ff1409d57e6  vmovaps xmm10, [rsp+0xA0]
00007ff1409d57ef  vmovaps xmm11, [rsp+0xB0]
00007ff1409d57f8  vmovaps xmm12, [rsp+0xC0]
00007ff1409d5801  vmovaps xmm13, [rsp+0xD0]
00007ff1409d580a  vmovaps xmm14, [rsp+0xE0]
00007ff1409d5813  add rsp, 0xF0
00007ff1409d581a  pop r11
00007ff1409d581c  pop r10
00007ff1409d581e  pop r9
00007ff1409d5820  pop r8
00007ff1409d5822  pop rsi
00007ff1409d5823  pop rdi
00007ff1409d5824  pop rdx
00007ff1409d5825  pop rcx
00007ff1409d5826  pop rax
00007ff1409d5827  add rsp, 0x08
00007ff1409d582b  jmp 0x00007FF1409D2EE3
00007ff1409d5830  sub rsp, 0x08
00007ff1409d5834  push rax
00007ff1409d5835  push rcx
00007ff1409d5836  push rdx
00007ff1409d5837  push rdi
00007ff1409d5838  push rsi
00007ff1409d5839  push r8
00007ff1409d583b  push r9
00007ff1409d583d  push r10
00007ff1409d583f  push r11
00007ff1409d5841  sub rsp, 0xF0
00007ff1409d5848  vmovaps [rsp], xmm0
00007ff1409d584d  vmovaps [rsp+0x10], xmm1
00007ff1409d5853  vmovaps [rsp+0x20], xmm2
00007ff1409d5859  vmovaps [rsp+0x30], xmm3
00007ff1409d585f  vmovaps [rsp+0x40], xmm4
00007ff1409d5865  vmovaps [rsp+0x50], xmm5
00007ff1409d586b  vmovaps [rsp+0x60], xmm6
00007ff1409d5871  vmovaps [rsp+0x70], xmm7
00007ff1409d5877  vmovaps [rsp+0x80], xmm8
00007ff1409d5880  vmovaps [rsp+0x90], xmm9
00007ff1409d5889  vmovaps [rsp+0xA0], xmm10
00007ff1409d5892  vmovaps [rsp+0xB0], xmm12
00007ff1409d589b  vmovaps [rsp+0xC0], xmm13
00007ff1409d58a4  vmovaps [rsp+0xD0], xmm14
00007ff1409d58ad  vmovaps [rsp+0xE0], xmm15
00007ff1409d58b6  sub rsp, 0x30
00007ff1409d58ba  movaps [rsp], xmm11
00007ff1409d58bf  movaps [rsp+0x10], xmm6
00007ff1409d58c4  movaps [rsp+0x20], xmm14
00007ff1409d58ca  lea rdi, [rsp]
00007ff1409d58ce  mov esi, 0x00
00007ff1409d58d3  mov rax, 0x565C7F10C530
00007ff1409d58dd  call rax
00007ff1409d58df  movaps xmm11, [rsp]
00007ff1409d58e4  add rsp, 0x30
00007ff1409d58e8  vmovaps xmm0, [rsp]
00007ff1409d58ed  vmovaps xmm1, [rsp+0x10]
00007ff1409d58f3  vmovaps xmm2, [rsp+0x20]
00007ff1409d58f9  vmovaps xmm3, [rsp+0x30]
00007ff1409d58ff  vmovaps xmm4, [rsp+0x40]
00007ff1409d5905  vmovaps xmm5, [rsp+0x50]
00007ff1409d590b  vmovaps xmm6, [rsp+0x60]
00007ff1409d5911  vmovaps xmm7, [rsp+0x70]
00007ff1409d5917  vmovaps xmm8, [rsp+0x80]
00007ff1409d5920  vmovaps xmm9, [rsp+0x90]
00007ff1409d5929  vmovaps xmm10, [rsp+0xA0]
00007ff1409d5932  vmovaps xmm12, [rsp+0xB0]
00007ff1409d593b  vmovaps xmm13, [rsp+0xC0]
00007ff1409d5944  vmovaps xmm14, [rsp+0xD0]
00007ff1409d594d  vmovaps xmm15, [rsp+0xE0]
00007ff1409d5956  add rsp, 0xF0
00007ff1409d595d  pop r11
00007ff1409d595f  pop r10
00007ff1409d5961  pop r9
00007ff1409d5963  pop r8
00007ff1409d5965  pop rsi
00007ff1409d5966  pop rdi
00007ff1409d5967  pop rdx
00007ff1409d5968  pop rcx
00007ff1409d5969  pop rax
00007ff1409d596a  add rsp, 0x08
00007ff1409d596e  jmp 0x00007FF1409D2F5B
00007ff1409d5973  call 0x00007FF1407FF430
00007ff1409d5978  jmp 0x00007FF1409D2F65
00007ff1409d597d  sub rsp, 0x08
00007ff1409d5981  push rax
00007ff1409d5982  push rcx
00007ff1409d5983  push rdx
00007ff1409d5984  push rdi
00007ff1409d5985  push rsi
00007ff1409d5986  push r8
00007ff1409d5988  push r9
00007ff1409d598a  push r10
00007ff1409d598c  push r11
00007ff1409d598e  sub rsp, 0xF0
00007ff1409d5995  vmovaps [rsp], xmm0
00007ff1409d599a  vmovaps [rsp+0x10], xmm1
00007ff1409d59a0  vmovaps [rsp+0x20], xmm2
00007ff1409d59a6  vmovaps [rsp+0x30], xmm3
00007ff1409d59ac  vmovaps [rsp+0x40], xmm4
00007ff1409d59b2  vmovaps [rsp+0x50], xmm5
00007ff1409d59b8  vmovaps [rsp+0x60], xmm6
00007ff1409d59be  vmovaps [rsp+0x70], xmm7
00007ff1409d59c4  vmovaps [rsp+0x80], xmm8
00007ff1409d59cd  vmovaps [rsp+0x90], xmm9
00007ff1409d59d6  vmovaps [rsp+0xA0], xmm10
00007ff1409d59df  vmovaps [rsp+0xB0], xmm11
00007ff1409d59e8  vmovaps [rsp+0xC0], xmm12
00007ff1409d59f1  vmovaps [rsp+0xD0], xmm13
00007ff1409d59fa  vmovaps [rsp+0xE0], xmm15
00007ff1409d5a03  sub rsp, 0x30
00007ff1409d5a07  movaps [rsp], xmm14
00007ff1409d5a0c  movaps [rsp+0x10], xmm6
00007ff1409d5a11  movaps [rsp+0x20], xmm2
00007ff1409d5a16  lea rdi, [rsp]
00007ff1409d5a1a  mov esi, 0x00
00007ff1409d5a1f  mov rax, 0x565C7F10C530
00007ff1409d5a29  call rax
00007ff1409d5a2b  movaps xmm14, [rsp]
00007ff1409d5a30  add rsp, 0x30
00007ff1409d5a34  vmovaps xmm0, [rsp]
00007ff1409d5a39  vmovaps xmm1, [rsp+0x10]
00007ff1409d5a3f  vmovaps xmm2, [rsp+0x20]
00007ff1409d5a45  vmovaps xmm3, [rsp+0x30]
00007ff1409d5a4b  vmovaps xmm4, [rsp+0x40]
00007ff1409d5a51  vmovaps xmm5, [rsp+0x50]
00007ff1409d5a57  vmovaps xmm6, [rsp+0x60]
00007ff1409d5a5d  vmovaps xmm7, [rsp+0x70]
00007ff1409d5a63  vmovaps xmm8, [rsp+0x80]
00007ff1409d5a6c  vmovaps xmm9, [rsp+0x90]
00007ff1409d5a75  vmovaps xmm10, [rsp+0xA0]
00007ff1409d5a7e  vmovaps xmm11, [rsp+0xB0]
00007ff1409d5a87  vmovaps xmm12, [rsp+0xC0]
00007ff1409d5a90  vmovaps xmm13, [rsp+0xD0]
00007ff1409d5a99  vmovaps xmm15, [rsp+0xE0]
00007ff1409d5aa2  add rsp, 0xF0
00007ff1409d5aa9  pop r11
00007ff1409d5aab  pop r10
00007ff1409d5aad  pop r9
00007ff1409d5aaf  pop r8
00007ff1409d5ab1  pop rsi
00007ff1409d5ab2  pop rdi
00007ff1409d5ab3  pop rdx
00007ff1409d5ab4  pop rcx
00007ff1409d5ab5  pop rax
00007ff1409d5ab6  add rsp, 0x08
00007ff1409d5aba  jmp 0x00007FF1409D2F99
00007ff1409d5abf  sub rsp, 0x08
00007ff1409d5ac3  push rax
00007ff1409d5ac4  push rcx
00007ff1409d5ac5  push rdx
00007ff1409d5ac6  push rdi
00007ff1409d5ac7  push rsi
00007ff1409d5ac8  push r8
00007ff1409d5aca  push r9
00007ff1409d5acc  push r10
00007ff1409d5ace  push r11
00007ff1409d5ad0  sub rsp, 0xF0
00007ff1409d5ad7  vmovaps [rsp], xmm0
00007ff1409d5adc  vmovaps [rsp+0x10], xmm1
00007ff1409d5ae2  vmovaps [rsp+0x20], xmm2
00007ff1409d5ae8  vmovaps [rsp+0x30], xmm3
00007ff1409d5aee  vmovaps [rsp+0x40], xmm4
00007ff1409d5af4  vmovaps [rsp+0x50], xmm5
00007ff1409d5afa  vmovaps [rsp+0x60], xmm7
00007ff1409d5b00  vmovaps [rsp+0x70], xmm8
00007ff1409d5b06  vmovaps [rsp+0x80], xmm9
00007ff1409d5b0f  vmovaps [rsp+0x90], xmm10
00007ff1409d5b18  vmovaps [rsp+0xA0], xmm11
00007ff1409d5b21  vmovaps [rsp+0xB0], xmm12
00007ff1409d5b2a  vmovaps [rsp+0xC0], xmm13
00007ff1409d5b33  vmovaps [rsp+0xD0], xmm14
00007ff1409d5b3c  vmovaps [rsp+0xE0], xmm15
00007ff1409d5b45  sub rsp, 0x30
00007ff1409d5b49  movaps [rsp], xmm6
00007ff1409d5b4d  movaps [rsp+0x10], xmm5
00007ff1409d5b52  movaps [rsp+0x20], xmm1
00007ff1409d5b57  lea rdi, [rsp]
00007ff1409d5b5b  mov esi, 0x00
00007ff1409d5b60  mov rax, 0x565C7F10C530
00007ff1409d5b6a  call rax
00007ff1409d5b6c  movaps xmm6, [rsp]
00007ff1409d5b70  add rsp, 0x30
00007ff1409d5b74  vmovaps xmm0, [rsp]
00007ff1409d5b79  vmovaps xmm1, [rsp+0x10]
00007ff1409d5b7f  vmovaps xmm2, [rsp+0x20]
00007ff1409d5b85  vmovaps xmm3, [rsp+0x30]
00007ff1409d5b8b  vmovaps xmm4, [rsp+0x40]
00007ff1409d5b91  vmovaps xmm5, [rsp+0x50]
00007ff1409d5b97  vmovaps xmm7, [rsp+0x60]
00007ff1409d5b9d  vmovaps xmm8, [rsp+0x70]
00007ff1409d5ba3  vmovaps xmm9, [rsp+0x80]
00007ff1409d5bac  vmovaps xmm10, [rsp+0x90]
00007ff1409d5bb5  vmovaps xmm11, [rsp+0xA0]
00007ff1409d5bbe  vmovaps xmm12, [rsp+0xB0]
00007ff1409d5bc7  vmovaps xmm13, [rsp+0xC0]
00007ff1409d5bd0  vmovaps xmm14, [rsp+0xD0]
00007ff1409d5bd9  vmovaps xmm15, [rsp+0xE0]
00007ff1409d5be2  add rsp, 0xF0
00007ff1409d5be9  pop r11
00007ff1409d5beb  pop r10
00007ff1409d5bed  pop r9
00007ff1409d5bef  pop r8
00007ff1409d5bf1  pop rsi
00007ff1409d5bf2  pop rdi
00007ff1409d5bf3  pop rdx
00007ff1409d5bf4  pop rcx
00007ff1409d5bf5  pop rax
00007ff1409d5bf6  add rsp, 0x08
00007ff1409d5bfa  jmp 0x00007FF1409D2FBF
00007ff1409d5bff  sub rsp, 0x08
00007ff1409d5c03  push rax
00007ff1409d5c04  push rcx
00007ff1409d5c05  push rdx
00007ff1409d5c06  push rdi
00007ff1409d5c07  push rsi
00007ff1409d5c08  push r8
00007ff1409d5c0a  push r9
00007ff1409d5c0c  push r10
00007ff1409d5c0e  push r11
00007ff1409d5c10  sub rsp, 0xF0
00007ff1409d5c17  vmovaps [rsp], xmm0
00007ff1409d5c1c  vmovaps [rsp+0x10], xmm2
00007ff1409d5c22  vmovaps [rsp+0x20], xmm3
00007ff1409d5c28  vmovaps [rsp+0x30], xmm4
00007ff1409d5c2e  vmovaps [rsp+0x40], xmm5
00007ff1409d5c34  vmovaps [rsp+0x50], xmm6
00007ff1409d5c3a  vmovaps [rsp+0x60], xmm7
00007ff1409d5c40  vmovaps [rsp+0x70], xmm8
00007ff1409d5c46  vmovaps [rsp+0x80], xmm9
00007ff1409d5c4f  vmovaps [rsp+0x90], xmm10
00007ff1409d5c58  vmovaps [rsp+0xA0], xmm11
00007ff1409d5c61  vmovaps [rsp+0xB0], xmm12
00007ff1409d5c6a  vmovaps [rsp+0xC0], xmm13
00007ff1409d5c73  vmovaps [rsp+0xD0], xmm14
00007ff1409d5c7c  vmovaps [rsp+0xE0], xmm15
00007ff1409d5c85  sub rsp, 0x30
00007ff1409d5c89  movaps [rsp], xmm1
00007ff1409d5c8d  movaps [rsp+0x10], xmm5
00007ff1409d5c92  movaps [rsp+0x20], xmm13
00007ff1409d5c98  lea rdi, [rsp]
00007ff1409d5c9c  mov esi, 0x00
00007ff1409d5ca1  mov rax, 0x565C7F10C530
00007ff1409d5cab  call rax
00007ff1409d5cad  movaps xmm1, [rsp]
00007ff1409d5cb1  add rsp, 0x30
00007ff1409d5cb5  vmovaps xmm0, [rsp]
00007ff1409d5cba  vmovaps xmm2, [rsp+0x10]
00007ff1409d5cc0  vmovaps xmm3, [rsp+0x20]
00007ff1409d5cc6  vmovaps xmm4, [rsp+0x30]
00007ff1409d5ccc  vmovaps xmm5, [rsp+0x40]
00007ff1409d5cd2  vmovaps xmm6, [rsp+0x50]
00007ff1409d5cd8  vmovaps xmm7, [rsp+0x60]
00007ff1409d5cde  vmovaps xmm8, [rsp+0x70]
00007ff1409d5ce4  vmovaps xmm9, [rsp+0x80]
00007ff1409d5ced  vmovaps xmm10, [rsp+0x90]
00007ff1409d5cf6  vmovaps xmm11, [rsp+0xA0]
00007ff1409d5cff  vmovaps xmm12, [rsp+0xB0]
00007ff1409d5d08  vmovaps xmm13, [rsp+0xC0]
00007ff1409d5d11  vmovaps xmm14, [rsp+0xD0]
00007ff1409d5d1a  vmovaps xmm15, [rsp+0xE0]
00007ff1409d5d23  add rsp, 0xF0
00007ff1409d5d2a  pop r11
00007ff1409d5d2c  pop r10
00007ff1409d5d2e  pop r9
00007ff1409d5d30  pop r8
00007ff1409d5d32  pop rsi
00007ff1409d5d33  pop rdi
00007ff1409d5d34  pop rdx
00007ff1409d5d35  pop rcx
00007ff1409d5d36  pop rax
00007ff1409d5d37  add rsp, 0x08
00007ff1409d5d3b  jmp 0x00007FF1409D2FDD
00007ff1409d5d40  sub rsp, 0x08
00007ff1409d5d44  push rax
00007ff1409d5d45  push rcx
00007ff1409d5d46  push rdx
00007ff1409d5d47  push rdi
00007ff1409d5d48  push rsi
00007ff1409d5d49  push r8
00007ff1409d5d4b  push r9
00007ff1409d5d4d  push r10
00007ff1409d5d4f  push r11
00007ff1409d5d51  sub rsp, 0xF0
00007ff1409d5d58  vmovaps [rsp], xmm0
00007ff1409d5d5d  vmovaps [rsp+0x10], xmm1
00007ff1409d5d63  vmovaps [rsp+0x20], xmm2
00007ff1409d5d69  vmovaps [rsp+0x30], xmm3
00007ff1409d5d6f  vmovaps [rsp+0x40], xmm4
00007ff1409d5d75  vmovaps [rsp+0x50], xmm6
00007ff1409d5d7b  vmovaps [rsp+0x60], xmm7
00007ff1409d5d81  vmovaps [rsp+0x70], xmm8
00007ff1409d5d87  vmovaps [rsp+0x80], xmm9
00007ff1409d5d90  vmovaps [rsp+0x90], xmm10
00007ff1409d5d99  vmovaps [rsp+0xA0], xmm11
00007ff1409d5da2  vmovaps [rsp+0xB0], xmm12
00007ff1409d5dab  vmovaps [rsp+0xC0], xmm13
00007ff1409d5db4  vmovaps [rsp+0xD0], xmm14
00007ff1409d5dbd  vmovaps [rsp+0xE0], xmm15
00007ff1409d5dc6  sub rsp, 0x30
00007ff1409d5dca  movaps [rsp], xmm5
00007ff1409d5dce  movaps [rsp+0x10], xmm2
00007ff1409d5dd3  movaps [rsp+0x20], xmm13
00007ff1409d5dd9  lea rdi, [rsp]
00007ff1409d5ddd  mov esi, 0x00
00007ff1409d5de2  mov rax, 0x565C7F10C530
00007ff1409d5dec  call rax
00007ff1409d5dee  movaps xmm5, [rsp]
00007ff1409d5df2  add rsp, 0x30
00007ff1409d5df6  vmovaps xmm0, [rsp]
00007ff1409d5dfb  vmovaps xmm1, [rsp+0x10]
00007ff1409d5e01  vmovaps xmm2, [rsp+0x20]
00007ff1409d5e07  vmovaps xmm3, [rsp+0x30]
00007ff1409d5e0d  vmovaps xmm4, [rsp+0x40]
00007ff1409d5e13  vmovaps xmm6, [rsp+0x50]
00007ff1409d5e19  vmovaps xmm7, [rsp+0x60]
00007ff1409d5e1f  vmovaps xmm8, [rsp+0x70]
00007ff1409d5e25  vmovaps xmm9, [rsp+0x80]
00007ff1409d5e2e  vmovaps xmm10, [rsp+0x90]
00007ff1409d5e37  vmovaps xmm11, [rsp+0xA0]
00007ff1409d5e40  vmovaps xmm12, [rsp+0xB0]
00007ff1409d5e49  vmovaps xmm13, [rsp+0xC0]
00007ff1409d5e52  vmovaps xmm14, [rsp+0xD0]
00007ff1409d5e5b  vmovaps xmm15, [rsp+0xE0]
00007ff1409d5e64  add rsp, 0xF0
00007ff1409d5e6b  pop r11
00007ff1409d5e6d  pop r10
00007ff1409d5e6f  pop r9
00007ff1409d5e71  pop r8
00007ff1409d5e73  pop rsi
00007ff1409d5e74  pop rdi
00007ff1409d5e75  pop rdx
00007ff1409d5e76  pop rcx
00007ff1409d5e77  pop rax
00007ff1409d5e78  add rsp, 0x08
00007ff1409d5e7c  jmp 0x00007FF1409D3013
00007ff1409d5e81  sub rsp, 0x08
00007ff1409d5e85  push rax
00007ff1409d5e86  push rcx
00007ff1409d5e87  push rdx
00007ff1409d5e88  push rdi
00007ff1409d5e89  push rsi
00007ff1409d5e8a  push r8
00007ff1409d5e8c  push r9
00007ff1409d5e8e  push r10
00007ff1409d5e90  push r11
00007ff1409d5e92  sub rsp, 0xF0
00007ff1409d5e99  vmovaps [rsp], xmm0
00007ff1409d5e9e  vmovaps [rsp+0x10], xmm1
00007ff1409d5ea4  vmovaps [rsp+0x20], xmm2
00007ff1409d5eaa  vmovaps [rsp+0x30], xmm3
00007ff1409d5eb0  vmovaps [rsp+0x40], xmm4
00007ff1409d5eb6  vmovaps [rsp+0x50], xmm5
00007ff1409d5ebc  vmovaps [rsp+0x60], xmm6
00007ff1409d5ec2  vmovaps [rsp+0x70], xmm7
00007ff1409d5ec8  vmovaps [rsp+0x80], xmm8
00007ff1409d5ed1  vmovaps [rsp+0x90], xmm9
00007ff1409d5eda  vmovaps [rsp+0xA0], xmm10
00007ff1409d5ee3  vmovaps [rsp+0xB0], xmm11
00007ff1409d5eec  vmovaps [rsp+0xC0], xmm12
00007ff1409d5ef5  vmovaps [rsp+0xD0], xmm14
00007ff1409d5efe  vmovaps [rsp+0xE0], xmm15
00007ff1409d5f07  sub rsp, 0x30
00007ff1409d5f0b  movaps [rsp], xmm13
00007ff1409d5f10  movaps [rsp+0x10], xmm10
00007ff1409d5f16  movaps [rsp+0x20], xmm1
00007ff1409d5f1b  lea rdi, [rsp]
00007ff1409d5f1f  mov esi, 0x00
00007ff1409d5f24  mov rax, 0x565C7F10C530
00007ff1409d5f2e  call rax
00007ff1409d5f30  movaps xmm13, [rsp]
00007ff1409d5f35  add rsp, 0x30
00007ff1409d5f39  vmovaps xmm0, [rsp]
00007ff1409d5f3e  vmovaps xmm1, [rsp+0x10]
00007ff1409d5f44  vmovaps xmm2, [rsp+0x20]
00007ff1409d5f4a  vmovaps xmm3, [rsp+0x30]
00007ff1409d5f50  vmovaps xmm4, [rsp+0x40]
00007ff1409d5f56  vmovaps xmm5, [rsp+0x50]
00007ff1409d5f5c  vmovaps xmm6, [rsp+0x60]
00007ff1409d5f62  vmovaps xmm7, [rsp+0x70]
00007ff1409d5f68  vmovaps xmm8, [rsp+0x80]
00007ff1409d5f71  vmovaps xmm9, [rsp+0x90]
00007ff1409d5f7a  vmovaps xmm10, [rsp+0xA0]
00007ff1409d5f83  vmovaps xmm11, [rsp+0xB0]
00007ff1409d5f8c  vmovaps xmm12, [rsp+0xC0]
00007ff1409d5f95  vmovaps xmm14, [rsp+0xD0]
00007ff1409d5f9e  vmovaps xmm15, [rsp+0xE0]
00007ff1409d5fa7  add rsp, 0xF0
00007ff1409d5fae  pop r11
00007ff1409d5fb0  pop r10
00007ff1409d5fb2  pop r9
00007ff1409d5fb4  pop r8
00007ff1409d5fb6  pop rsi
00007ff1409d5fb7  pop rdi
00007ff1409d5fb8  pop rdx
00007ff1409d5fb9  pop rcx
00007ff1409d5fba  pop rax
00007ff1409d5fbb  add rsp, 0x08
00007ff1409d5fbf  jmp 0x00007FF1409D303C
00007ff1409d5fc4  sub rsp, 0x08
00007ff1409d5fc8  push rax
00007ff1409d5fc9  push rcx
00007ff1409d5fca  push rdx
00007ff1409d5fcb  push rdi
00007ff1409d5fcc  push rsi
00007ff1409d5fcd  push r8
00007ff1409d5fcf  push r9
00007ff1409d5fd1  push r10
00007ff1409d5fd3  push r11
00007ff1409d5fd5  sub rsp, 0xF0
00007ff1409d5fdc  vmovaps [rsp], xmm0
00007ff1409d5fe1  vmovaps [rsp+0x10], xmm2
00007ff1409d5fe7  vmovaps [rsp+0x20], xmm3
00007ff1409d5fed  vmovaps [rsp+0x30], xmm4
00007ff1409d5ff3  vmovaps [rsp+0x40], xmm5
00007ff1409d5ff9  vmovaps [rsp+0x50], xmm6
00007ff1409d5fff  vmovaps [rsp+0x60], xmm7
00007ff1409d6005  vmovaps [rsp+0x70], xmm8
00007ff1409d600b  vmovaps [rsp+0x80], xmm9
00007ff1409d6014  vmovaps [rsp+0x90], xmm10
00007ff1409d601d  vmovaps [rsp+0xA0], xmm11
00007ff1409d6026  vmovaps [rsp+0xB0], xmm12
00007ff1409d602f  vmovaps [rsp+0xC0], xmm13
00007ff1409d6038  vmovaps [rsp+0xD0], xmm14
00007ff1409d6041  vmovaps [rsp+0xE0], xmm15
00007ff1409d604a  sub rsp, 0x30
00007ff1409d604e  movaps [rsp], xmm1
00007ff1409d6052  movaps [rsp+0x10], xmm15
00007ff1409d6058  movaps [rsp+0x20], xmm10
00007ff1409d605e  lea rdi, [rsp]
00007ff1409d6062  mov esi, 0x00
00007ff1409d6067  mov rax, 0x565C7F10C530
00007ff1409d6071  call rax
00007ff1409d6073  movaps xmm1, [rsp]
00007ff1409d6077  add rsp, 0x30
00007ff1409d607b  vmovaps xmm0, [rsp]
00007ff1409d6080  vmovaps xmm2, [rsp+0x10]
00007ff1409d6086  vmovaps xmm3, [rsp+0x20]
00007ff1409d608c  vmovaps xmm4, [rsp+0x30]
00007ff1409d6092  vmovaps xmm5, [rsp+0x40]
00007ff1409d6098  vmovaps xmm6, [rsp+0x50]
00007ff1409d609e  vmovaps xmm7, [rsp+0x60]
00007ff1409d60a4  vmovaps xmm8, [rsp+0x70]
00007ff1409d60aa  vmovaps xmm9, [rsp+0x80]
00007ff1409d60b3  vmovaps xmm10, [rsp+0x90]
00007ff1409d60bc  vmovaps xmm11, [rsp+0xA0]
00007ff1409d60c5  vmovaps xmm12, [rsp+0xB0]
00007ff1409d60ce  vmovaps xmm13, [rsp+0xC0]
00007ff1409d60d7  vmovaps xmm14, [rsp+0xD0]
00007ff1409d60e0  vmovaps xmm15, [rsp+0xE0]
00007ff1409d60e9  add rsp, 0xF0
00007ff1409d60f0  pop r11
00007ff1409d60f2  pop r10
00007ff1409d60f4  pop r9
00007ff1409d60f6  pop r8
00007ff1409d60f8  pop rsi
00007ff1409d60f9  pop rdi
00007ff1409d60fa  pop rdx
00007ff1409d60fb  pop rcx
00007ff1409d60fc  pop rax
00007ff1409d60fd  add rsp, 0x08
00007ff1409d6101  jmp 0x00007FF1409D305B
00007ff1409d6106  sub rsp, 0x08
00007ff1409d610a  push rax
00007ff1409d610b  push rcx
00007ff1409d610c  push rdx
00007ff1409d610d  push rdi
00007ff1409d610e  push rsi
00007ff1409d610f  push r8
00007ff1409d6111  push r9
00007ff1409d6113  push r10
00007ff1409d6115  push r11
00007ff1409d6117  sub rsp, 0xF0
00007ff1409d611e  vmovaps [rsp], xmm0
00007ff1409d6123  vmovaps [rsp+0x10], xmm1
00007ff1409d6129  vmovaps [rsp+0x20], xmm2
00007ff1409d612f  vmovaps [rsp+0x30], xmm3
00007ff1409d6135  vmovaps [rsp+0x40], xmm4
00007ff1409d613b  vmovaps [rsp+0x50], xmm5
00007ff1409d6141  vmovaps [rsp+0x60], xmm6
00007ff1409d6147  vmovaps [rsp+0x70], xmm7
00007ff1409d614d  vmovaps [rsp+0x80], xmm8
00007ff1409d6156  vmovaps [rsp+0x90], xmm9
00007ff1409d615f  vmovaps [rsp+0xA0], xmm10
00007ff1409d6168  vmovaps [rsp+0xB0], xmm11
00007ff1409d6171  vmovaps [rsp+0xC0], xmm12
00007ff1409d617a  vmovaps [rsp+0xD0], xmm13
00007ff1409d6183  vmovaps [rsp+0xE0], xmm14
00007ff1409d618c  sub rsp, 0x30
00007ff1409d6190  movaps [rsp], xmm15
00007ff1409d6195  movaps [rsp+0x10], xmm10
00007ff1409d619b  movaps [rsp+0x20], xmm11
00007ff1409d61a1  lea rdi, [rsp]
00007ff1409d61a5  mov esi, 0x00
00007ff1409d61aa  mov rax, 0x565C7F10C530
00007ff1409d61b4  call rax
00007ff1409d61b6  movaps xmm15, [rsp]
00007ff1409d61bb  add rsp, 0x30
00007ff1409d61bf  vmovaps xmm0, [rsp]
00007ff1409d61c4  vmovaps xmm1, [rsp+0x10]
00007ff1409d61ca  vmovaps xmm2, [rsp+0x20]
00007ff1409d61d0  vmovaps xmm3, [rsp+0x30]
00007ff1409d61d6  vmovaps xmm4, [rsp+0x40]
00007ff1409d61dc  vmovaps xmm5, [rsp+0x50]
00007ff1409d61e2  vmovaps xmm6, [rsp+0x60]
00007ff1409d61e8  vmovaps xmm7, [rsp+0x70]
00007ff1409d61ee  vmovaps xmm8, [rsp+0x80]
00007ff1409d61f7  vmovaps xmm9, [rsp+0x90]
00007ff1409d6200  vmovaps xmm10, [rsp+0xA0]
00007ff1409d6209  vmovaps xmm11, [rsp+0xB0]
00007ff1409d6212  vmovaps xmm12, [rsp+0xC0]
00007ff1409d621b  vmovaps xmm13, [rsp+0xD0]
00007ff1409d6224  vmovaps xmm14, [rsp+0xE0]
00007ff1409d622d  add rsp, 0xF0
00007ff1409d6234  pop r11
00007ff1409d6236  pop r10
00007ff1409d6238  pop r9
00007ff1409d623a  pop r8
00007ff1409d623c  pop rsi
00007ff1409d623d  pop rdi
00007ff1409d623e  pop rdx
00007ff1409d623f  pop rcx
00007ff1409d6240  pop rax
00007ff1409d6241  add rsp, 0x08
00007ff1409d6245  jmp 0x00007FF1409D307E
00007ff1409d624a  sub rsp, 0x08
00007ff1409d624e  push rax
00007ff1409d624f  push rcx
00007ff1409d6250  push rdx
00007ff1409d6251  push rdi
00007ff1409d6252  push rsi
00007ff1409d6253  push r8
00007ff1409d6255  push r9
00007ff1409d6257  push r10
00007ff1409d6259  push r11
00007ff1409d625b  sub rsp, 0xF0
00007ff1409d6262  vmovaps [rsp], xmm0
00007ff1409d6267  vmovaps [rsp+0x10], xmm1
00007ff1409d626d  vmovaps [rsp+0x20], xmm2
00007ff1409d6273  vmovaps [rsp+0x30], xmm3
00007ff1409d6279  vmovaps [rsp+0x40], xmm4
00007ff1409d627f  vmovaps [rsp+0x50], xmm5
00007ff1409d6285  vmovaps [rsp+0x60], xmm6
00007ff1409d628b  vmovaps [rsp+0x70], xmm7
00007ff1409d6291  vmovaps [rsp+0x80], xmm8
00007ff1409d629a  vmovaps [rsp+0x90], xmm9
00007ff1409d62a3  vmovaps [rsp+0xA0], xmm11
00007ff1409d62ac  vmovaps [rsp+0xB0], xmm12
00007ff1409d62b5  vmovaps [rsp+0xC0], xmm13
00007ff1409d62be  vmovaps [rsp+0xD0], xmm14
00007ff1409d62c7  vmovaps [rsp+0xE0], xmm15
00007ff1409d62d0  sub rsp, 0x30
00007ff1409d62d4  movaps [rsp], xmm10
00007ff1409d62d9  movaps [rsp+0x10], xmm2
00007ff1409d62de  movaps [rsp+0x20], xmm11
00007ff1409d62e4  lea rdi, [rsp]
00007ff1409d62e8  mov esi, 0x00
00007ff1409d62ed  mov rax, 0x565C7F10C530
00007ff1409d62f7  call rax
00007ff1409d62f9  movaps xmm10, [rsp]
00007ff1409d62fe  add rsp, 0x30
00007ff1409d6302  vmovaps xmm0, [rsp]
00007ff1409d6307  vmovaps xmm1, [rsp+0x10]
00007ff1409d630d  vmovaps xmm2, [rsp+0x20]
00007ff1409d6313  vmovaps xmm3, [rsp+0x30]
00007ff1409d6319  vmovaps xmm4, [rsp+0x40]
00007ff1409d631f  vmovaps xmm5, [rsp+0x50]
00007ff1409d6325  vmovaps xmm6, [rsp+0x60]
00007ff1409d632b  vmovaps xmm7, [rsp+0x70]
00007ff1409d6331  vmovaps xmm8, [rsp+0x80]
00007ff1409d633a  vmovaps xmm9, [rsp+0x90]
00007ff1409d6343  vmovaps xmm11, [rsp+0xA0]
00007ff1409d634c  vmovaps xmm12, [rsp+0xB0]
00007ff1409d6355  vmovaps xmm13, [rsp+0xC0]
00007ff1409d635e  vmovaps xmm14, [rsp+0xD0]
00007ff1409d6367  vmovaps xmm15, [rsp+0xE0]
00007ff1409d6370  add rsp, 0xF0
00007ff1409d6377  pop r11
00007ff1409d6379  pop r10
00007ff1409d637b  pop r9
00007ff1409d637d  pop r8
00007ff1409d637f  pop rsi
00007ff1409d6380  pop rdi
00007ff1409d6381  pop rdx
00007ff1409d6382  pop rcx
00007ff1409d6383  pop rax
00007ff1409d6384  add rsp, 0x08
00007ff1409d6388  jmp 0x00007FF1409D30B6
00007ff1409d638d  sub rsp, 0x08
00007ff1409d6391  push rax
00007ff1409d6392  push rcx
00007ff1409d6393  push rdx
00007ff1409d6394  push rdi
00007ff1409d6395  push rsi
00007ff1409d6396  push r8
00007ff1409d6398  push r9
00007ff1409d639a  push r10
00007ff1409d639c  push r11
00007ff1409d639e  sub rsp, 0xF0
00007ff1409d63a5  vmovaps [rsp], xmm0
00007ff1409d63aa  vmovaps [rsp+0x10], xmm1
00007ff1409d63b0  vmovaps [rsp+0x20], xmm2
00007ff1409d63b6  vmovaps [rsp+0x30], xmm3
00007ff1409d63bc  vmovaps [rsp+0x40], xmm4
00007ff1409d63c2  vmovaps [rsp+0x50], xmm5
00007ff1409d63c8  vmovaps [rsp+0x60], xmm6
00007ff1409d63ce  vmovaps [rsp+0x70], xmm7
00007ff1409d63d4  vmovaps [rsp+0x80], xmm8
00007ff1409d63dd  vmovaps [rsp+0x90], xmm9
00007ff1409d63e6  vmovaps [rsp+0xA0], xmm10
00007ff1409d63ef  vmovaps [rsp+0xB0], xmm12
00007ff1409d63f8  vmovaps [rsp+0xC0], xmm13
00007ff1409d6401  vmovaps [rsp+0xD0], xmm14
00007ff1409d640a  vmovaps [rsp+0xE0], xmm15
00007ff1409d6413  sub rsp, 0x30
00007ff1409d6417  movaps [rsp], xmm11
00007ff1409d641c  movaps [rsp+0x10], xmm2
00007ff1409d6421  movaps [rsp+0x20], xmm1
00007ff1409d6426  lea rdi, [rsp]
00007ff1409d642a  mov esi, 0x00
00007ff1409d642f  mov rax, 0x565C7F10C530
00007ff1409d6439  call rax
00007ff1409d643b  movaps xmm11, [rsp]
00007ff1409d6440  add rsp, 0x30
00007ff1409d6444  vmovaps xmm0, [rsp]
00007ff1409d6449  vmovaps xmm1, [rsp+0x10]
00007ff1409d644f  vmovaps xmm2, [rsp+0x20]
00007ff1409d6455  vmovaps xmm3, [rsp+0x30]
00007ff1409d645b  vmovaps xmm4, [rsp+0x40]
00007ff1409d6461  vmovaps xmm5, [rsp+0x50]
00007ff1409d6467  vmovaps xmm6, [rsp+0x60]
00007ff1409d646d  vmovaps xmm7, [rsp+0x70]
00007ff1409d6473  vmovaps xmm8, [rsp+0x80]
00007ff1409d647c  vmovaps xmm9, [rsp+0x90]
00007ff1409d6485  vmovaps xmm10, [rsp+0xA0]
00007ff1409d648e  vmovaps xmm12, [rsp+0xB0]
00007ff1409d6497  vmovaps xmm13, [rsp+0xC0]
00007ff1409d64a0  vmovaps xmm14, [rsp+0xD0]
00007ff1409d64a9  vmovaps xmm15, [rsp+0xE0]
00007ff1409d64b2  add rsp, 0xF0
00007ff1409d64b9  pop r11
00007ff1409d64bb  pop r10
00007ff1409d64bd  pop r9
00007ff1409d64bf  pop r8
00007ff1409d64c1  pop rsi
00007ff1409d64c2  pop rdi
00007ff1409d64c3  pop rdx
00007ff1409d64c4  pop rcx
00007ff1409d64c5  pop rax
00007ff1409d64c6  add rsp, 0x08
00007ff1409d64ca  jmp 0x00007FF1409D30F2
00007ff1409d64cf  sub rsp, 0x08
00007ff1409d64d3  push rax
00007ff1409d64d4  push rcx
00007ff1409d64d5  push rdx
00007ff1409d64d6  push rdi
00007ff1409d64d7  push rsi
00007ff1409d64d8  push r8
00007ff1409d64da  push r9
00007ff1409d64dc  push r10
00007ff1409d64de  push r11
00007ff1409d64e0  sub rsp, 0xF0
00007ff1409d64e7  vmovaps [rsp], xmm0
00007ff1409d64ec  vmovaps [rsp+0x10], xmm2
00007ff1409d64f2  vmovaps [rsp+0x20], xmm3
00007ff1409d64f8  vmovaps [rsp+0x30], xmm4
00007ff1409d64fe  vmovaps [rsp+0x40], xmm5
00007ff1409d6504  vmovaps [rsp+0x50], xmm6
00007ff1409d650a  vmovaps [rsp+0x60], xmm7
00007ff1409d6510  vmovaps [rsp+0x70], xmm8
00007ff1409d6516  vmovaps [rsp+0x80], xmm9
00007ff1409d651f  vmovaps [rsp+0x90], xmm10
00007ff1409d6528  vmovaps [rsp+0xA0], xmm11
00007ff1409d6531  vmovaps [rsp+0xB0], xmm12
00007ff1409d653a  vmovaps [rsp+0xC0], xmm13
00007ff1409d6543  vmovaps [rsp+0xD0], xmm14
00007ff1409d654c  vmovaps [rsp+0xE0], xmm15
00007ff1409d6555  sub rsp, 0x30
00007ff1409d6559  movaps [rsp], xmm1
00007ff1409d655d  movaps [rsp+0x10], xmm14
00007ff1409d6563  movaps [rsp+0x20], xmm6
00007ff1409d6568  lea rdi, [rsp]
00007ff1409d656c  mov esi, 0x00
00007ff1409d6571  mov rax, 0x565C7F10C530
00007ff1409d657b  call rax
00007ff1409d657d  movaps xmm1, [rsp]
00007ff1409d6581  add rsp, 0x30
00007ff1409d6585  vmovaps xmm0, [rsp]
00007ff1409d658a  vmovaps xmm2, [rsp+0x10]
00007ff1409d6590  vmovaps xmm3, [rsp+0x20]
00007ff1409d6596  vmovaps xmm4, [rsp+0x30]
00007ff1409d659c  vmovaps xmm5, [rsp+0x40]
00007ff1409d65a2  vmovaps xmm6, [rsp+0x50]
00007ff1409d65a8  vmovaps xmm7, [rsp+0x60]
00007ff1409d65ae  vmovaps xmm8, [rsp+0x70]
00007ff1409d65b4  vmovaps xmm9, [rsp+0x80]
00007ff1409d65bd  vmovaps xmm10, [rsp+0x90]
00007ff1409d65c6  vmovaps xmm11, [rsp+0xA0]
00007ff1409d65cf  vmovaps xmm12, [rsp+0xB0]
00007ff1409d65d8  vmovaps xmm13, [rsp+0xC0]
00007ff1409d65e1  vmovaps xmm14, [rsp+0xD0]
00007ff1409d65ea  vmovaps xmm15, [rsp+0xE0]
00007ff1409d65f3  add rsp, 0xF0
00007ff1409d65fa  pop r11
00007ff1409d65fc  pop r10
00007ff1409d65fe  pop r9
00007ff1409d6600  pop r8
00007ff1409d6602  pop rsi
00007ff1409d6603  pop rdi
00007ff1409d6604  pop rdx
00007ff1409d6605  pop rcx
00007ff1409d6606  pop rax
00007ff1409d6607  add rsp, 0x08
00007ff1409d660b  jmp 0x00007FF1409D310B
00007ff1409d6610  sub rsp, 0x08
00007ff1409d6614  push rax
00007ff1409d6615  push rcx
00007ff1409d6616  push rdx
00007ff1409d6617  push rdi
00007ff1409d6618  push rsi
00007ff1409d6619  push r8
00007ff1409d661b  push r9
00007ff1409d661d  push r10
00007ff1409d661f  push r11
00007ff1409d6621  sub rsp, 0xF0
00007ff1409d6628  vmovaps [rsp], xmm0
00007ff1409d662d  vmovaps [rsp+0x10], xmm1
00007ff1409d6633  vmovaps [rsp+0x20], xmm2
00007ff1409d6639  vmovaps [rsp+0x30], xmm3
00007ff1409d663f  vmovaps [rsp+0x40], xmm4
00007ff1409d6645  vmovaps [rsp+0x50], xmm5
00007ff1409d664b  vmovaps [rsp+0x60], xmm6
00007ff1409d6651  vmovaps [rsp+0x70], xmm7
00007ff1409d6657  vmovaps [rsp+0x80], xmm8
00007ff1409d6660  vmovaps [rsp+0x90], xmm9
00007ff1409d6669  vmovaps [rsp+0xA0], xmm10
00007ff1409d6672  vmovaps [rsp+0xB0], xmm11
00007ff1409d667b  vmovaps [rsp+0xC0], xmm12
00007ff1409d6684  vmovaps [rsp+0xD0], xmm13
00007ff1409d668d  vmovaps [rsp+0xE0], xmm14
00007ff1409d6696  sub rsp, 0x30
00007ff1409d669a  movaps [rsp], xmm15
00007ff1409d669f  movaps [rsp+0x10], xmm14
00007ff1409d66a5  movaps [rsp+0x20], xmm5
00007ff1409d66aa  lea rdi, [rsp]
00007ff1409d66ae  mov esi, 0x00
00007ff1409d66b3  mov rax, 0x565C7F10C530
00007ff1409d66bd  call rax
00007ff1409d66bf  movaps xmm15, [rsp]
00007ff1409d66c4  add rsp, 0x30
00007ff1409d66c8  vmovaps xmm0, [rsp]
00007ff1409d66cd  vmovaps xmm1, [rsp+0x10]
00007ff1409d66d3  vmovaps xmm2, [rsp+0x20]
00007ff1409d66d9  vmovaps xmm3, [rsp+0x30]
00007ff1409d66df  vmovaps xmm4, [rsp+0x40]
00007ff1409d66e5  vmovaps xmm5, [rsp+0x50]
00007ff1409d66eb  vmovaps xmm6, [rsp+0x60]
00007ff1409d66f1  vmovaps xmm7, [rsp+0x70]
00007ff1409d66f7  vmovaps xmm8, [rsp+0x80]
00007ff1409d6700  vmovaps xmm9, [rsp+0x90]
00007ff1409d6709  vmovaps xmm10, [rsp+0xA0]
00007ff1409d6712  vmovaps xmm11, [rsp+0xB0]
00007ff1409d671b  vmovaps xmm12, [rsp+0xC0]
00007ff1409d6724  vmovaps xmm13, [rsp+0xD0]
00007ff1409d672d  vmovaps xmm14, [rsp+0xE0]
00007ff1409d6736  add rsp, 0xF0
00007ff1409d673d  pop r11
00007ff1409d673f  pop r10
00007ff1409d6741  pop r9
00007ff1409d6743  pop r8
00007ff1409d6745  pop rsi
00007ff1409d6746  pop rdi
00007ff1409d6747  pop rdx
00007ff1409d6748  pop rcx
00007ff1409d6749  pop rax
00007ff1409d674a  add rsp, 0x08
00007ff1409d674e  jmp 0x00007FF1409D312B
00007ff1409d6753  sub rsp, 0x08
00007ff1409d6757  push rax
00007ff1409d6758  push rcx
00007ff1409d6759  push rdx
00007ff1409d675a  push rdi
00007ff1409d675b  push rsi
00007ff1409d675c  push r8
00007ff1409d675e  push r9
00007ff1409d6760  push r10
00007ff1409d6762  push r11
00007ff1409d6764  sub rsp, 0xF0
00007ff1409d676b  vmovaps [rsp], xmm0
00007ff1409d6770  vmovaps [rsp+0x10], xmm1
00007ff1409d6776  vmovaps [rsp+0x20], xmm2
00007ff1409d677c  vmovaps [rsp+0x30], xmm3
00007ff1409d6782  vmovaps [rsp+0x40], xmm4
00007ff1409d6788  vmovaps [rsp+0x50], xmm5
00007ff1409d678e  vmovaps [rsp+0x60], xmm7
00007ff1409d6794  vmovaps [rsp+0x70], xmm8
00007ff1409d679a  vmovaps [rsp+0x80], xmm9
00007ff1409d67a3  vmovaps [rsp+0x90], xmm10
00007ff1409d67ac  vmovaps [rsp+0xA0], xmm11
00007ff1409d67b5  vmovaps [rsp+0xB0], xmm12
00007ff1409d67be  vmovaps [rsp+0xC0], xmm13
00007ff1409d67c7  vmovaps [rsp+0xD0], xmm14
00007ff1409d67d0  vmovaps [rsp+0xE0], xmm15
00007ff1409d67d9  sub rsp, 0x30
00007ff1409d67dd  movaps [rsp], xmm6
00007ff1409d67e1  movaps [rsp+0x10], xmm9
00007ff1409d67e7  movaps [rsp+0x20], xmm14
00007ff1409d67ed  lea rdi, [rsp]
00007ff1409d67f1  mov esi, 0x00
00007ff1409d67f6  mov rax, 0x565C7F10C530
00007ff1409d6800  call rax
00007ff1409d6802  movaps xmm6, [rsp]
00007ff1409d6806  add rsp, 0x30
00007ff1409d680a  vmovaps xmm0, [rsp]
00007ff1409d680f  vmovaps xmm1, [rsp+0x10]
00007ff1409d6815  vmovaps xmm2, [rsp+0x20]
00007ff1409d681b  vmovaps xmm3, [rsp+0x30]
00007ff1409d6821  vmovaps xmm4, [rsp+0x40]
00007ff1409d6827  vmovaps xmm5, [rsp+0x50]
00007ff1409d682d  vmovaps xmm7, [rsp+0x60]
00007ff1409d6833  vmovaps xmm8, [rsp+0x70]
00007ff1409d6839  vmovaps xmm9, [rsp+0x80]
00007ff1409d6842  vmovaps xmm10, [rsp+0x90]
00007ff1409d684b  vmovaps xmm11, [rsp+0xA0]
00007ff1409d6854  vmovaps xmm12, [rsp+0xB0]
00007ff1409d685d  vmovaps xmm13, [rsp+0xC0]
00007ff1409d6866  vmovaps xmm14, [rsp+0xD0]
00007ff1409d686f  vmovaps xmm15, [rsp+0xE0]
00007ff1409d6878  add rsp, 0xF0
00007ff1409d687f  pop r11
00007ff1409d6881  pop r10
00007ff1409d6883  pop r9
00007ff1409d6885  pop r8
00007ff1409d6887  pop rsi
00007ff1409d6888  pop rdi
00007ff1409d6889  pop rdx
00007ff1409d688a  pop rcx
00007ff1409d688b  pop rax
00007ff1409d688c  add rsp, 0x08
00007ff1409d6890  jmp 0x00007FF1409D3153
00007ff1409d6895  sub rsp, 0x08
00007ff1409d6899  push rax
00007ff1409d689a  push rcx
00007ff1409d689b  push rdx
00007ff1409d689c  push rdi
00007ff1409d689d  push rsi
00007ff1409d689e  push r8
00007ff1409d68a0  push r9
00007ff1409d68a2  push r10
00007ff1409d68a4  push r11
00007ff1409d68a6  sub rsp, 0xF0
00007ff1409d68ad  vmovaps [rsp], xmm0
00007ff1409d68b2  vmovaps [rsp+0x10], xmm1
00007ff1409d68b8  vmovaps [rsp+0x20], xmm2
00007ff1409d68be  vmovaps [rsp+0x30], xmm3
00007ff1409d68c4  vmovaps [rsp+0x40], xmm4
00007ff1409d68ca  vmovaps [rsp+0x50], xmm5
00007ff1409d68d0  vmovaps [rsp+0x60], xmm6
00007ff1409d68d6  vmovaps [rsp+0x70], xmm7
00007ff1409d68dc  vmovaps [rsp+0x80], xmm8
00007ff1409d68e5  vmovaps [rsp+0x90], xmm9
00007ff1409d68ee  vmovaps [rsp+0xA0], xmm10
00007ff1409d68f7  vmovaps [rsp+0xB0], xmm11
00007ff1409d6900  vmovaps [rsp+0xC0], xmm12
00007ff1409d6909  vmovaps [rsp+0xD0], xmm13
00007ff1409d6912  vmovaps [rsp+0xE0], xmm15
00007ff1409d691b  sub rsp, 0x30
00007ff1409d691f  movaps [rsp], xmm14
00007ff1409d6924  movaps [rsp+0x10], xmm9
00007ff1409d692a  movaps [rsp+0x20], xmm13
00007ff1409d6930  lea rdi, [rsp]
00007ff1409d6934  mov esi, 0x00
00007ff1409d6939  mov rax, 0x565C7F10C530
00007ff1409d6943  call rax
00007ff1409d6945  movaps xmm14, [rsp]
00007ff1409d694a  add rsp, 0x30
00007ff1409d694e  vmovaps xmm0, [rsp]
00007ff1409d6953  vmovaps xmm1, [rsp+0x10]
00007ff1409d6959  vmovaps xmm2, [rsp+0x20]
00007ff1409d695f  vmovaps xmm3, [rsp+0x30]
00007ff1409d6965  vmovaps xmm4, [rsp+0x40]
00007ff1409d696b  vmovaps xmm5, [rsp+0x50]
00007ff1409d6971  vmovaps xmm6, [rsp+0x60]
00007ff1409d6977  vmovaps xmm7, [rsp+0x70]
00007ff1409d697d  vmovaps xmm8, [rsp+0x80]
00007ff1409d6986  vmovaps xmm9, [rsp+0x90]
00007ff1409d698f  vmovaps xmm10, [rsp+0xA0]
00007ff1409d6998  vmovaps xmm11, [rsp+0xB0]
00007ff1409d69a1  vmovaps xmm12, [rsp+0xC0]
00007ff1409d69aa  vmovaps xmm13, [rsp+0xD0]
00007ff1409d69b3  vmovaps xmm15, [rsp+0xE0]
00007ff1409d69bc  add rsp, 0xF0
00007ff1409d69c3  pop r11
00007ff1409d69c5  pop r10
00007ff1409d69c7  pop r9
00007ff1409d69c9  pop r8
00007ff1409d69cb  pop rsi
00007ff1409d69cc  pop rdi
00007ff1409d69cd  pop rdx
00007ff1409d69ce  pop rcx
00007ff1409d69cf  pop rax
00007ff1409d69d0  add rsp, 0x08
00007ff1409d69d4  jmp 0x00007FF1409D3176
00007ff1409d69d9  sub rsp, 0x08
00007ff1409d69dd  push rax
00007ff1409d69de  push rcx
00007ff1409d69df  push rdx
00007ff1409d69e0  push rdi
00007ff1409d69e1  push rsi
00007ff1409d69e2  push r8
00007ff1409d69e4  push r9
00007ff1409d69e6  push r10
00007ff1409d69e8  push r11
00007ff1409d69ea  sub rsp, 0xF0
00007ff1409d69f1  vmovaps [rsp], xmm0
00007ff1409d69f6  vmovaps [rsp+0x10], xmm1
00007ff1409d69fc  vmovaps [rsp+0x20], xmm2
00007ff1409d6a02  vmovaps [rsp+0x30], xmm3
00007ff1409d6a08  vmovaps [rsp+0x40], xmm4
00007ff1409d6a0e  vmovaps [rsp+0x50], xmm5
00007ff1409d6a14  vmovaps [rsp+0x60], xmm6
00007ff1409d6a1a  vmovaps [rsp+0x70], xmm7
00007ff1409d6a20  vmovaps [rsp+0x80], xmm8
00007ff1409d6a29  vmovaps [rsp+0x90], xmm9
00007ff1409d6a32  vmovaps [rsp+0xA0], xmm10
00007ff1409d6a3b  vmovaps [rsp+0xB0], xmm11
00007ff1409d6a44  vmovaps [rsp+0xC0], xmm12
00007ff1409d6a4d  vmovaps [rsp+0xD0], xmm14
00007ff1409d6a56  vmovaps [rsp+0xE0], xmm15
00007ff1409d6a5f  sub rsp, 0x30
00007ff1409d6a63  movaps [rsp], xmm13
00007ff1409d6a68  movaps [rsp+0x10], xmm9
00007ff1409d6a6e  movaps [rsp+0x20], xmm10
00007ff1409d6a74  lea rdi, [rsp]
00007ff1409d6a78  mov esi, 0x00
00007ff1409d6a7d  mov rax, 0x565C7F10C530
00007ff1409d6a87  call rax
00007ff1409d6a89  movaps xmm13, [rsp]
00007ff1409d6a8e  add rsp, 0x30
00007ff1409d6a92  vmovaps xmm0, [rsp]
00007ff1409d6a97  vmovaps xmm1, [rsp+0x10]
00007ff1409d6a9d  vmovaps xmm2, [rsp+0x20]
00007ff1409d6aa3  vmovaps xmm3, [rsp+0x30]
00007ff1409d6aa9  vmovaps xmm4, [rsp+0x40]
00007ff1409d6aaf  vmovaps xmm5, [rsp+0x50]
00007ff1409d6ab5  vmovaps xmm6, [rsp+0x60]
00007ff1409d6abb  vmovaps xmm7, [rsp+0x70]
00007ff1409d6ac1  vmovaps xmm8, [rsp+0x80]
00007ff1409d6aca  vmovaps xmm9, [rsp+0x90]
00007ff1409d6ad3  vmovaps xmm10, [rsp+0xA0]
00007ff1409d6adc  vmovaps xmm11, [rsp+0xB0]
00007ff1409d6ae5  vmovaps xmm12, [rsp+0xC0]
00007ff1409d6aee  vmovaps xmm14, [rsp+0xD0]
00007ff1409d6af7  vmovaps xmm15, [rsp+0xE0]
00007ff1409d6b00  add rsp, 0xF0
00007ff1409d6b07  pop r11
00007ff1409d6b09  pop r10
00007ff1409d6b0b  pop r9
00007ff1409d6b0d  pop r8
00007ff1409d6b0f  pop rsi
00007ff1409d6b10  pop rdi
00007ff1409d6b11  pop rdx
00007ff1409d6b12  pop rcx
00007ff1409d6b13  pop rax
00007ff1409d6b14  add rsp, 0x08
00007ff1409d6b18  jmp 0x00007FF1409D3196
00007ff1409d6b1d  call 0x00007FF14080AFE0
00007ff1409d6b22  jmp 0x00007FF1409D31EB
00007ff1409d6b27  sub rsp, 0x08
00007ff1409d6b2b  push rax
00007ff1409d6b2c  push rcx
00007ff1409d6b2d  push rdx
00007ff1409d6b2e  push rdi
00007ff1409d6b2f  push rsi
00007ff1409d6b30  push r8
00007ff1409d6b32  push r9
00007ff1409d6b34  push r10
00007ff1409d6b36  push r11
00007ff1409d6b38  sub rsp, 0xF0
00007ff1409d6b3f  vmovaps [rsp], xmm0
00007ff1409d6b44  vmovaps [rsp+0x10], xmm1
00007ff1409d6b4a  vmovaps [rsp+0x20], xmm2
00007ff1409d6b50  vmovaps [rsp+0x30], xmm3
00007ff1409d6b56  vmovaps [rsp+0x40], xmm4
00007ff1409d6b5c  vmovaps [rsp+0x50], xmm5
00007ff1409d6b62  vmovaps [rsp+0x60], xmm6
00007ff1409d6b68  vmovaps [rsp+0x70], xmm7
00007ff1409d6b6e  vmovaps [rsp+0x80], xmm8
00007ff1409d6b77  vmovaps [rsp+0x90], xmm10
00007ff1409d6b80  vmovaps [rsp+0xA0], xmm11
00007ff1409d6b89  vmovaps [rsp+0xB0], xmm12
00007ff1409d6b92  vmovaps [rsp+0xC0], xmm13
00007ff1409d6b9b  vmovaps [rsp+0xD0], xmm14
00007ff1409d6ba4  vmovaps [rsp+0xE0], xmm15
00007ff1409d6bad  sub rsp, 0x30
00007ff1409d6bb1  movaps [rsp], xmm9
00007ff1409d6bb6  movaps [rsp+0x10], xmm8
00007ff1409d6bbc  movaps [rsp+0x20], xmm10
00007ff1409d6bc2  lea rdi, [rsp]
00007ff1409d6bc6  mov esi, 0x00
00007ff1409d6bcb  mov rax, 0x565C7F10C530
00007ff1409d6bd5  call rax
00007ff1409d6bd7  movaps xmm9, [rsp]
00007ff1409d6bdc  add rsp, 0x30
00007ff1409d6be0  vmovaps xmm0, [rsp]
00007ff1409d6be5  vmovaps xmm1, [rsp+0x10]
00007ff1409d6beb  vmovaps xmm2, [rsp+0x20]
00007ff1409d6bf1  vmovaps xmm3, [rsp+0x30]
00007ff1409d6bf7  vmovaps xmm4, [rsp+0x40]
00007ff1409d6bfd  vmovaps xmm5, [rsp+0x50]
00007ff1409d6c03  vmovaps xmm6, [rsp+0x60]
00007ff1409d6c09  vmovaps xmm7, [rsp+0x70]
00007ff1409d6c0f  vmovaps xmm8, [rsp+0x80]
00007ff1409d6c18  vmovaps xmm10, [rsp+0x90]
00007ff1409d6c21  vmovaps xmm11, [rsp+0xA0]
00007ff1409d6c2a  vmovaps xmm12, [rsp+0xB0]
00007ff1409d6c33  vmovaps xmm13, [rsp+0xC0]
00007ff1409d6c3c  vmovaps xmm14, [rsp+0xD0]
00007ff1409d6c45  vmovaps xmm15, [rsp+0xE0]
00007ff1409d6c4e  add rsp, 0xF0
00007ff1409d6c55  pop r11
00007ff1409d6c57  pop r10
00007ff1409d6c59  pop r9
00007ff1409d6c5b  pop r8
00007ff1409d6c5d  pop rsi
00007ff1409d6c5e  pop rdi
00007ff1409d6c5f  pop rdx
00007ff1409d6c60  pop rcx
00007ff1409d6c61  pop rax
00007ff1409d6c62  add rsp, 0x08
00007ff1409d6c66  jmp 0x00007FF1409D321C
00007ff1409d6c6b  sub rsp, 0x08
00007ff1409d6c6f  push rax
00007ff1409d6c70  push rcx
00007ff1409d6c71  push rdx
00007ff1409d6c72  push rdi
00007ff1409d6c73  push rsi
00007ff1409d6c74  push r8
00007ff1409d6c76  push r9
00007ff1409d6c78  push r10
00007ff1409d6c7a  push r11
00007ff1409d6c7c  sub rsp, 0xF0
00007ff1409d6c83  vmovaps [rsp], xmm0
00007ff1409d6c88  vmovaps [rsp+0x10], xmm1
00007ff1409d6c8e  vmovaps [rsp+0x20], xmm2
00007ff1409d6c94  vmovaps [rsp+0x30], xmm3
00007ff1409d6c9a  vmovaps [rsp+0x40], xmm4
00007ff1409d6ca0  vmovaps [rsp+0x50], xmm5
00007ff1409d6ca6  vmovaps [rsp+0x60], xmm6
00007ff1409d6cac  vmovaps [rsp+0x70], xmm7
00007ff1409d6cb2  vmovaps [rsp+0x80], xmm8
00007ff1409d6cbb  vmovaps [rsp+0x90], xmm9
00007ff1409d6cc4  vmovaps [rsp+0xA0], xmm11
00007ff1409d6ccd  vmovaps [rsp+0xB0], xmm12
00007ff1409d6cd6  vmovaps [rsp+0xC0], xmm13
00007ff1409d6cdf  vmovaps [rsp+0xD0], xmm14
00007ff1409d6ce8  vmovaps [rsp+0xE0], xmm15
00007ff1409d6cf1  sub rsp, 0x30
00007ff1409d6cf5  movaps [rsp], xmm10
00007ff1409d6cfa  movaps [rsp+0x10], xmm1
00007ff1409d6cff  movaps [rsp+0x20], xmm11
00007ff1409d6d05  lea rdi, [rsp]
00007ff1409d6d09  mov esi, 0x00
00007ff1409d6d0e  mov rax, 0x565C7F10C530
00007ff1409d6d18  call rax
00007ff1409d6d1a  movaps xmm10, [rsp]
00007ff1409d6d1f  add rsp, 0x30
00007ff1409d6d23  vmovaps xmm0, [rsp]
00007ff1409d6d28  vmovaps xmm1, [rsp+0x10]
00007ff1409d6d2e  vmovaps xmm2, [rsp+0x20]
00007ff1409d6d34  vmovaps xmm3, [rsp+0x30]
00007ff1409d6d3a  vmovaps xmm4, [rsp+0x40]
00007ff1409d6d40  vmovaps xmm5, [rsp+0x50]
00007ff1409d6d46  vmovaps xmm6, [rsp+0x60]
00007ff1409d6d4c  vmovaps xmm7, [rsp+0x70]
00007ff1409d6d52  vmovaps xmm8, [rsp+0x80]
00007ff1409d6d5b  vmovaps xmm9, [rsp+0x90]
00007ff1409d6d64  vmovaps xmm11, [rsp+0xA0]
00007ff1409d6d6d  vmovaps xmm12, [rsp+0xB0]
00007ff1409d6d76  vmovaps xmm13, [rsp+0xC0]
00007ff1409d6d7f  vmovaps xmm14, [rsp+0xD0]
00007ff1409d6d88  vmovaps xmm15, [rsp+0xE0]
00007ff1409d6d91  add rsp, 0xF0
00007ff1409d6d98  pop r11
00007ff1409d6d9a  pop r10
00007ff1409d6d9c  pop r9
00007ff1409d6d9e  pop r8
00007ff1409d6da0  pop rsi
00007ff1409d6da1  pop rdi
00007ff1409d6da2  pop rdx
00007ff1409d6da3  pop rcx
00007ff1409d6da4  pop rax
00007ff1409d6da5  add rsp, 0x08
00007ff1409d6da9  jmp 0x00007FF1409D3237
00007ff1409d6dae  sub rsp, 0x08
00007ff1409d6db2  push rax
00007ff1409d6db3  push rcx
00007ff1409d6db4  push rdx
00007ff1409d6db5  push rdi
00007ff1409d6db6  push rsi
00007ff1409d6db7  push r8
00007ff1409d6db9  push r9
00007ff1409d6dbb  push r10
00007ff1409d6dbd  push r11
00007ff1409d6dbf  sub rsp, 0xF0
00007ff1409d6dc6  vmovaps [rsp], xmm0
00007ff1409d6dcb  vmovaps [rsp+0x10], xmm2
00007ff1409d6dd1  vmovaps [rsp+0x20], xmm3
00007ff1409d6dd7  vmovaps [rsp+0x30], xmm4
00007ff1409d6ddd  vmovaps [rsp+0x40], xmm5
00007ff1409d6de3  vmovaps [rsp+0x50], xmm6
00007ff1409d6de9  vmovaps [rsp+0x60], xmm7
00007ff1409d6def  vmovaps [rsp+0x70], xmm8
00007ff1409d6df5  vmovaps [rsp+0x80], xmm9
00007ff1409d6dfe  vmovaps [rsp+0x90], xmm10
00007ff1409d6e07  vmovaps [rsp+0xA0], xmm11
00007ff1409d6e10  vmovaps [rsp+0xB0], xmm12
00007ff1409d6e19  vmovaps [rsp+0xC0], xmm13
00007ff1409d6e22  vmovaps [rsp+0xD0], xmm14
00007ff1409d6e2b  vmovaps [rsp+0xE0], xmm15
00007ff1409d6e34  sub rsp, 0x30
00007ff1409d6e38  movaps [rsp], xmm1
00007ff1409d6e3c  movaps [rsp+0x10], xmm15
00007ff1409d6e42  movaps [rsp+0x20], xmm6
00007ff1409d6e47  lea rdi, [rsp]
00007ff1409d6e4b  mov esi, 0x00
00007ff1409d6e50  mov rax, 0x565C7F10C530
00007ff1409d6e5a  call rax
00007ff1409d6e5c  movaps xmm1, [rsp]
00007ff1409d6e60  add rsp, 0x30
00007ff1409d6e64  vmovaps xmm0, [rsp]
00007ff1409d6e69  vmovaps xmm2, [rsp+0x10]
00007ff1409d6e6f  vmovaps xmm3, [rsp+0x20]
00007ff1409d6e75  vmovaps xmm4, [rsp+0x30]
00007ff1409d6e7b  vmovaps xmm5, [rsp+0x40]
00007ff1409d6e81  vmovaps xmm6, [rsp+0x50]
00007ff1409d6e87  vmovaps xmm7, [rsp+0x60]
00007ff1409d6e8d  vmovaps xmm8, [rsp+0x70]
00007ff1409d6e93  vmovaps xmm9, [rsp+0x80]
00007ff1409d6e9c  vmovaps xmm10, [rsp+0x90]
00007ff1409d6ea5  vmovaps xmm11, [rsp+0xA0]
00007ff1409d6eae  vmovaps xmm12, [rsp+0xB0]
00007ff1409d6eb7  vmovaps xmm13, [rsp+0xC0]
00007ff1409d6ec0  vmovaps xmm14, [rsp+0xD0]
00007ff1409d6ec9  vmovaps xmm15, [rsp+0xE0]
00007ff1409d6ed2  add rsp, 0xF0
00007ff1409d6ed9  pop r11
00007ff1409d6edb  pop r10
00007ff1409d6edd  pop r9
00007ff1409d6edf  pop r8
00007ff1409d6ee1  pop rsi
00007ff1409d6ee2  pop rdi
00007ff1409d6ee3  pop rdx
00007ff1409d6ee4  pop rcx
00007ff1409d6ee5  pop rax
00007ff1409d6ee6  add rsp, 0x08
00007ff1409d6eea  jmp 0x00007FF1409D3250
00007ff1409d6eef  sub rsp, 0x08
00007ff1409d6ef3  push rax
00007ff1409d6ef4  push rcx
00007ff1409d6ef5  push rdx
00007ff1409d6ef6  push rdi
00007ff1409d6ef7  push rsi
00007ff1409d6ef8  push r8
00007ff1409d6efa  push r9
00007ff1409d6efc  push r10
00007ff1409d6efe  push r11
00007ff1409d6f00  sub rsp, 0xF0
00007ff1409d6f07  vmovaps [rsp], xmm0
00007ff1409d6f0c  vmovaps [rsp+0x10], xmm1
00007ff1409d6f12  vmovaps [rsp+0x20], xmm2
00007ff1409d6f18  vmovaps [rsp+0x30], xmm3
00007ff1409d6f1e  vmovaps [rsp+0x40], xmm4
00007ff1409d6f24  vmovaps [rsp+0x50], xmm5
00007ff1409d6f2a  vmovaps [rsp+0x60], xmm6
00007ff1409d6f30  vmovaps [rsp+0x70], xmm7
00007ff1409d6f36  vmovaps [rsp+0x80], xmm8
00007ff1409d6f3f  vmovaps [rsp+0x90], xmm9
00007ff1409d6f48  vmovaps [rsp+0xA0], xmm10
00007ff1409d6f51  vmovaps [rsp+0xB0], xmm12
00007ff1409d6f5a  vmovaps [rsp+0xC0], xmm13
00007ff1409d6f63  vmovaps [rsp+0xD0], xmm14
00007ff1409d6f6c  vmovaps [rsp+0xE0], xmm15
00007ff1409d6f75  sub rsp, 0x30
00007ff1409d6f79  movaps [rsp], xmm11
00007ff1409d6f7e  movaps [rsp+0x10], xmm12
00007ff1409d6f84  movaps [rsp+0x20], xmm15
00007ff1409d6f8a  lea rdi, [rsp]
00007ff1409d6f8e  mov esi, 0x00
00007ff1409d6f93  mov rax, 0x565C7F10C530
00007ff1409d6f9d  call rax
00007ff1409d6f9f  movaps xmm11, [rsp]
00007ff1409d6fa4  add rsp, 0x30
00007ff1409d6fa8  vmovaps xmm0, [rsp]
00007ff1409d6fad  vmovaps xmm1, [rsp+0x10]
00007ff1409d6fb3  vmovaps xmm2, [rsp+0x20]
00007ff1409d6fb9  vmovaps xmm3, [rsp+0x30]
00007ff1409d6fbf  vmovaps xmm4, [rsp+0x40]
00007ff1409d6fc5  vmovaps xmm5, [rsp+0x50]
00007ff1409d6fcb  vmovaps xmm6, [rsp+0x60]
00007ff1409d6fd1  vmovaps xmm7, [rsp+0x70]
00007ff1409d6fd7  vmovaps xmm8, [rsp+0x80]
00007ff1409d6fe0  vmovaps xmm9, [rsp+0x90]
00007ff1409d6fe9  vmovaps xmm10, [rsp+0xA0]
00007ff1409d6ff2  vmovaps xmm12, [rsp+0xB0]
00007ff1409d6ffb  vmovaps xmm13, [rsp+0xC0]
00007ff1409d7004  vmovaps xmm14, [rsp+0xD0]
00007ff1409d700d  vmovaps xmm15, [rsp+0xE0]
00007ff1409d7016  add rsp, 0xF0
00007ff1409d701d  pop r11
00007ff1409d701f  pop r10
00007ff1409d7021  pop r9
00007ff1409d7023  pop r8
00007ff1409d7025  pop rsi
00007ff1409d7026  pop rdi
00007ff1409d7027  pop rdx
00007ff1409d7028  pop rcx
00007ff1409d7029  pop rax
00007ff1409d702a  add rsp, 0x08
00007ff1409d702e  jmp 0x00007FF1409D327A
00007ff1409d7033  sub rsp, 0x08
00007ff1409d7037  push rax
00007ff1409d7038  push rcx
00007ff1409d7039  push rdx
00007ff1409d703a  push rdi
00007ff1409d703b  push rsi
00007ff1409d703c  push r8
00007ff1409d703e  push r9
00007ff1409d7040  push r10
00007ff1409d7042  push r11
00007ff1409d7044  sub rsp, 0xF0
00007ff1409d704b  vmovaps [rsp], xmm0
00007ff1409d7050  vmovaps [rsp+0x10], xmm1
00007ff1409d7056  vmovaps [rsp+0x20], xmm2
00007ff1409d705c  vmovaps [rsp+0x30], xmm3
00007ff1409d7062  vmovaps [rsp+0x40], xmm4
00007ff1409d7068  vmovaps [rsp+0x50], xmm5
00007ff1409d706e  vmovaps [rsp+0x60], xmm6
00007ff1409d7074  vmovaps [rsp+0x70], xmm7
00007ff1409d707a  vmovaps [rsp+0x80], xmm8
00007ff1409d7083  vmovaps [rsp+0x90], xmm9
00007ff1409d708c  vmovaps [rsp+0xA0], xmm10
00007ff1409d7095  vmovaps [rsp+0xB0], xmm11
00007ff1409d709e  vmovaps [rsp+0xC0], xmm13
00007ff1409d70a7  vmovaps [rsp+0xD0], xmm14
00007ff1409d70b0  vmovaps [rsp+0xE0], xmm15
00007ff1409d70b9  sub rsp, 0x30
00007ff1409d70bd  movaps [rsp], xmm12
00007ff1409d70c2  movaps [rsp+0x10], xmm8
00007ff1409d70c8  movaps [rsp+0x20], xmm15
00007ff1409d70ce  lea rdi, [rsp]
00007ff1409d70d2  mov esi, 0x00
00007ff1409d70d7  mov rax, 0x565C7F10C530
00007ff1409d70e1  call rax
00007ff1409d70e3  movaps xmm12, [rsp]
00007ff1409d70e8  add rsp, 0x30
00007ff1409d70ec  vmovaps xmm0, [rsp]
00007ff1409d70f1  vmovaps xmm1, [rsp+0x10]
00007ff1409d70f7  vmovaps xmm2, [rsp+0x20]
00007ff1409d70fd  vmovaps xmm3, [rsp+0x30]
00007ff1409d7103  vmovaps xmm4, [rsp+0x40]
00007ff1409d7109  vmovaps xmm5, [rsp+0x50]
00007ff1409d710f  vmovaps xmm6, [rsp+0x60]
00007ff1409d7115  vmovaps xmm7, [rsp+0x70]
00007ff1409d711b  vmovaps xmm8, [rsp+0x80]
00007ff1409d7124  vmovaps xmm9, [rsp+0x90]
00007ff1409d712d  vmovaps xmm10, [rsp+0xA0]
00007ff1409d7136  vmovaps xmm11, [rsp+0xB0]
00007ff1409d713f  vmovaps xmm13, [rsp+0xC0]
00007ff1409d7148  vmovaps xmm14, [rsp+0xD0]
00007ff1409d7151  vmovaps xmm15, [rsp+0xE0]
00007ff1409d715a  add rsp, 0xF0
00007ff1409d7161  pop r11
00007ff1409d7163  pop r10
00007ff1409d7165  pop r9
00007ff1409d7167  pop r8
00007ff1409d7169  pop rsi
00007ff1409d716a  pop rdi
00007ff1409d716b  pop rdx
00007ff1409d716c  pop rcx
00007ff1409d716d  pop rax
00007ff1409d716e  add rsp, 0x08
00007ff1409d7172  jmp 0x00007FF1409D32A9
00007ff1409d7177  sub rsp, 0x08
00007ff1409d717b  push rax
00007ff1409d717c  push rcx
00007ff1409d717d  push rdx
00007ff1409d717e  push rdi
00007ff1409d717f  push rsi
00007ff1409d7180  push r8
00007ff1409d7182  push r9
00007ff1409d7184  push r10
00007ff1409d7186  push r11
00007ff1409d7188  sub rsp, 0xF0
00007ff1409d718f  vmovaps [rsp], xmm0
00007ff1409d7194  vmovaps [rsp+0x10], xmm1
00007ff1409d719a  vmovaps [rsp+0x20], xmm2
00007ff1409d71a0  vmovaps [rsp+0x30], xmm3
00007ff1409d71a6  vmovaps [rsp+0x40], xmm4
00007ff1409d71ac  vmovaps [rsp+0x50], xmm5
00007ff1409d71b2  vmovaps [rsp+0x60], xmm6
00007ff1409d71b8  vmovaps [rsp+0x70], xmm7
00007ff1409d71be  vmovaps [rsp+0x80], xmm9
00007ff1409d71c7  vmovaps [rsp+0x90], xmm10
00007ff1409d71d0  vmovaps [rsp+0xA0], xmm11
00007ff1409d71d9  vmovaps [rsp+0xB0], xmm12
00007ff1409d71e2  vmovaps [rsp+0xC0], xmm13
00007ff1409d71eb  vmovaps [rsp+0xD0], xmm14
00007ff1409d71f4  vmovaps [rsp+0xE0], xmm15
00007ff1409d71fd  sub rsp, 0x30
00007ff1409d7201  movaps [rsp], xmm8
00007ff1409d7206  movaps [rsp+0x10], xmm7
00007ff1409d720b  movaps [rsp+0x20], xmm15
00007ff1409d7211  lea rdi, [rsp]
00007ff1409d7215  mov esi, 0x00
00007ff1409d721a  mov rax, 0x565C7F10C530
00007ff1409d7224  call rax
00007ff1409d7226  movaps xmm8, [rsp]
00007ff1409d722b  add rsp, 0x30
00007ff1409d722f  vmovaps xmm0, [rsp]
00007ff1409d7234  vmovaps xmm1, [rsp+0x10]
00007ff1409d723a  vmovaps xmm2, [rsp+0x20]
00007ff1409d7240  vmovaps xmm3, [rsp+0x30]
00007ff1409d7246  vmovaps xmm4, [rsp+0x40]
00007ff1409d724c  vmovaps xmm5, [rsp+0x50]
00007ff1409d7252  vmovaps xmm6, [rsp+0x60]
00007ff1409d7258  vmovaps xmm7, [rsp+0x70]
00007ff1409d725e  vmovaps xmm9, [rsp+0x80]
00007ff1409d7267  vmovaps xmm10, [rsp+0x90]
00007ff1409d7270  vmovaps xmm11, [rsp+0xA0]
00007ff1409d7279  vmovaps xmm12, [rsp+0xB0]
00007ff1409d7282  vmovaps xmm13, [rsp+0xC0]
00007ff1409d728b  vmovaps xmm14, [rsp+0xD0]
00007ff1409d7294  vmovaps xmm15, [rsp+0xE0]
00007ff1409d729d  add rsp, 0xF0
00007ff1409d72a4  pop r11
00007ff1409d72a6  pop r10
00007ff1409d72a8  pop r9
00007ff1409d72aa  pop r8
00007ff1409d72ac  pop rsi
00007ff1409d72ad  pop rdi
00007ff1409d72ae  pop rdx
00007ff1409d72af  pop rcx
00007ff1409d72b0  pop rax
00007ff1409d72b1  add rsp, 0x08
00007ff1409d72b5  jmp 0x00007FF1409D32CF
00007ff1409d72ba  sub rsp, 0x08
00007ff1409d72be  push rax
00007ff1409d72bf  push rcx
00007ff1409d72c0  push rdx
00007ff1409d72c1  push rdi
00007ff1409d72c2  push rsi
00007ff1409d72c3  push r8
00007ff1409d72c5  push r9
00007ff1409d72c7  push r10
00007ff1409d72c9  push r11
00007ff1409d72cb  sub rsp, 0xF0
00007ff1409d72d2  vmovaps [rsp], xmm0
00007ff1409d72d7  vmovaps [rsp+0x10], xmm1
00007ff1409d72dd  vmovaps [rsp+0x20], xmm2
00007ff1409d72e3  vmovaps [rsp+0x30], xmm3
00007ff1409d72e9  vmovaps [rsp+0x40], xmm4
00007ff1409d72ef  vmovaps [rsp+0x50], xmm5
00007ff1409d72f5  vmovaps [rsp+0x60], xmm6
00007ff1409d72fb  vmovaps [rsp+0x70], xmm7
00007ff1409d7301  vmovaps [rsp+0x80], xmm8
00007ff1409d730a  vmovaps [rsp+0x90], xmm9
00007ff1409d7313  vmovaps [rsp+0xA0], xmm10
00007ff1409d731c  vmovaps [rsp+0xB0], xmm11
00007ff1409d7325  vmovaps [rsp+0xC0], xmm12
00007ff1409d732e  vmovaps [rsp+0xD0], xmm13
00007ff1409d7337  vmovaps [rsp+0xE0], xmm14
00007ff1409d7340  sub rsp, 0x30
00007ff1409d7344  movaps [rsp], xmm15
00007ff1409d7349  movaps [rsp+0x10], xmm14
00007ff1409d734f  movaps [rsp+0x20], xmm9
00007ff1409d7355  lea rdi, [rsp]
00007ff1409d7359  mov esi, 0x00
00007ff1409d735e  mov rax, 0x565C7F10C530
00007ff1409d7368  call rax
00007ff1409d736a  movaps xmm15, [rsp]
00007ff1409d736f  add rsp, 0x30
00007ff1409d7373  vmovaps xmm0, [rsp]
00007ff1409d7378  vmovaps xmm1, [rsp+0x10]
00007ff1409d737e  vmovaps xmm2, [rsp+0x20]
00007ff1409d7384  vmovaps xmm3, [rsp+0x30]
00007ff1409d738a  vmovaps xmm4, [rsp+0x40]
00007ff1409d7390  vmovaps xmm5, [rsp+0x50]
00007ff1409d7396  vmovaps xmm6, [rsp+0x60]
00007ff1409d739c  vmovaps xmm7, [rsp+0x70]
00007ff1409d73a2  vmovaps xmm8, [rsp+0x80]
00007ff1409d73ab  vmovaps xmm9, [rsp+0x90]
00007ff1409d73b4  vmovaps xmm10, [rsp+0xA0]
00007ff1409d73bd  vmovaps xmm11, [rsp+0xB0]
00007ff1409d73c6  vmovaps xmm12, [rsp+0xC0]
00007ff1409d73cf  vmovaps xmm13, [rsp+0xD0]
00007ff1409d73d8  vmovaps xmm14, [rsp+0xE0]
00007ff1409d73e1  add rsp, 0xF0
00007ff1409d73e8  pop r11
00007ff1409d73ea  pop r10
00007ff1409d73ec  pop r9
00007ff1409d73ee  pop r8
00007ff1409d73f0  pop rsi
00007ff1409d73f1  pop rdi
00007ff1409d73f2  pop rdx
00007ff1409d73f3  pop rcx
00007ff1409d73f4  pop rax
00007ff1409d73f5  add rsp, 0x08
00007ff1409d73f9  jmp 0x00007FF1409D32E9
00007ff1409d73fe  sub rsp, 0x08
00007ff1409d7402  push rax
00007ff1409d7403  push rcx
00007ff1409d7404  push rdx
00007ff1409d7405  push rdi
00007ff1409d7406  push rsi
00007ff1409d7407  push r8
00007ff1409d7409  push r9
00007ff1409d740b  push r10
00007ff1409d740d  push r11
00007ff1409d740f  sub rsp, 0xF0
00007ff1409d7416  vmovaps [rsp], xmm0
00007ff1409d741b  vmovaps [rsp+0x10], xmm1
00007ff1409d7421  vmovaps [rsp+0x20], xmm2
00007ff1409d7427  vmovaps [rsp+0x30], xmm3
00007ff1409d742d  vmovaps [rsp+0x40], xmm4
00007ff1409d7433  vmovaps [rsp+0x50], xmm5
00007ff1409d7439  vmovaps [rsp+0x60], xmm6
00007ff1409d743f  vmovaps [rsp+0x70], xmm7
00007ff1409d7445  vmovaps [rsp+0x80], xmm8
00007ff1409d744e  vmovaps [rsp+0x90], xmm10
00007ff1409d7457  vmovaps [rsp+0xA0], xmm11
00007ff1409d7460  vmovaps [rsp+0xB0], xmm12
00007ff1409d7469  vmovaps [rsp+0xC0], xmm13
00007ff1409d7472  vmovaps [rsp+0xD0], xmm14
00007ff1409d747b  vmovaps [rsp+0xE0], xmm15
00007ff1409d7484  sub rsp, 0x30
00007ff1409d7488  movaps [rsp], xmm9
00007ff1409d748d  movaps [rsp+0x10], xmm7
00007ff1409d7492  movaps [rsp+0x20], xmm14
00007ff1409d7498  lea rdi, [rsp]
00007ff1409d749c  mov esi, 0x00
00007ff1409d74a1  mov rax, 0x565C7F10C530
00007ff1409d74ab  call rax
00007ff1409d74ad  movaps xmm9, [rsp]
00007ff1409d74b2  add rsp, 0x30
00007ff1409d74b6  vmovaps xmm0, [rsp]
00007ff1409d74bb  vmovaps xmm1, [rsp+0x10]
00007ff1409d74c1  vmovaps xmm2, [rsp+0x20]
00007ff1409d74c7  vmovaps xmm3, [rsp+0x30]
00007ff1409d74cd  vmovaps xmm4, [rsp+0x40]
00007ff1409d74d3  vmovaps xmm5, [rsp+0x50]
00007ff1409d74d9  vmovaps xmm6, [rsp+0x60]
00007ff1409d74df  vmovaps xmm7, [rsp+0x70]
00007ff1409d74e5  vmovaps xmm8, [rsp+0x80]
00007ff1409d74ee  vmovaps xmm10, [rsp+0x90]
00007ff1409d74f7  vmovaps xmm11, [rsp+0xA0]
00007ff1409d7500  vmovaps xmm12, [rsp+0xB0]
00007ff1409d7509  vmovaps xmm13, [rsp+0xC0]
00007ff1409d7512  vmovaps xmm14, [rsp+0xD0]
00007ff1409d751b  vmovaps xmm15, [rsp+0xE0]
00007ff1409d7524  add rsp, 0xF0
00007ff1409d752b  pop r11
00007ff1409d752d  pop r10
00007ff1409d752f  pop r9
00007ff1409d7531  pop r8
00007ff1409d7533  pop rsi
00007ff1409d7534  pop rdi
00007ff1409d7535  pop rdx
00007ff1409d7536  pop rcx
00007ff1409d7537  pop rax
00007ff1409d7538  add rsp, 0x08
00007ff1409d753c  jmp 0x00007FF1409D3318
00007ff1409d7541  sub rsp, 0x08
00007ff1409d7545  push rax
00007ff1409d7546  push rcx
00007ff1409d7547  push rdx
00007ff1409d7548  push rdi
00007ff1409d7549  push rsi
00007ff1409d754a  push r8
00007ff1409d754c  push r9
00007ff1409d754e  push r10
00007ff1409d7550  push r11
00007ff1409d7552  sub rsp, 0xF0
00007ff1409d7559  vmovaps [rsp], xmm0
00007ff1409d755e  vmovaps [rsp+0x10], xmm1
00007ff1409d7564  vmovaps [rsp+0x20], xmm2
00007ff1409d756a  vmovaps [rsp+0x30], xmm3
00007ff1409d7570  vmovaps [rsp+0x40], xmm4
00007ff1409d7576  vmovaps [rsp+0x50], xmm5
00007ff1409d757c  vmovaps [rsp+0x60], xmm6
00007ff1409d7582  vmovaps [rsp+0x70], xmm7
00007ff1409d7588  vmovaps [rsp+0x80], xmm8
00007ff1409d7591  vmovaps [rsp+0x90], xmm9
00007ff1409d759a  vmovaps [rsp+0xA0], xmm10
00007ff1409d75a3  vmovaps [rsp+0xB0], xmm11
00007ff1409d75ac  vmovaps [rsp+0xC0], xmm12
00007ff1409d75b5  vmovaps [rsp+0xD0], xmm13
00007ff1409d75be  vmovaps [rsp+0xE0], xmm15
00007ff1409d75c7  sub rsp, 0x30
00007ff1409d75cb  movaps [rsp], xmm14
00007ff1409d75d0  movaps [rsp+0x10], xmm13
00007ff1409d75d6  movaps [rsp+0x20], xmm11
00007ff1409d75dc  lea rdi, [rsp]
00007ff1409d75e0  mov esi, 0x00
00007ff1409d75e5  mov rax, 0x565C7F10C530
00007ff1409d75ef  call rax
00007ff1409d75f1  movaps xmm14, [rsp]
00007ff1409d75f6  add rsp, 0x30
00007ff1409d75fa  vmovaps xmm0, [rsp]
00007ff1409d75ff  vmovaps xmm1, [rsp+0x10]
00007ff1409d7605  vmovaps xmm2, [rsp+0x20]
00007ff1409d760b  vmovaps xmm3, [rsp+0x30]
00007ff1409d7611  vmovaps xmm4, [rsp+0x40]
00007ff1409d7617  vmovaps xmm5, [rsp+0x50]
00007ff1409d761d  vmovaps xmm6, [rsp+0x60]
00007ff1409d7623  vmovaps xmm7, [rsp+0x70]
00007ff1409d7629  vmovaps xmm8, [rsp+0x80]
00007ff1409d7632  vmovaps xmm9, [rsp+0x90]
00007ff1409d763b  vmovaps xmm10, [rsp+0xA0]
00007ff1409d7644  vmovaps xmm11, [rsp+0xB0]
00007ff1409d764d  vmovaps xmm12, [rsp+0xC0]
00007ff1409d7656  vmovaps xmm13, [rsp+0xD0]
00007ff1409d765f  vmovaps xmm15, [rsp+0xE0]
00007ff1409d7668  add rsp, 0xF0
00007ff1409d766f  pop r11
00007ff1409d7671  pop r10
00007ff1409d7673  pop r9
00007ff1409d7675  pop r8
00007ff1409d7677  pop rsi
00007ff1409d7678  pop rdi
00007ff1409d7679  pop rdx
00007ff1409d767a  pop rcx
00007ff1409d767b  pop rax
00007ff1409d767c  add rsp, 0x08
00007ff1409d7680  jmp 0x00007FF1409D3332
00007ff1409d7685  sub rsp, 0x08
00007ff1409d7689  push rax
00007ff1409d768a  push rcx
00007ff1409d768b  push rdx
00007ff1409d768c  push rdi
00007ff1409d768d  push rsi
00007ff1409d768e  push r8
00007ff1409d7690  push r9
00007ff1409d7692  push r10
00007ff1409d7694  push r11
00007ff1409d7696  sub rsp, 0xF0
00007ff1409d769d  vmovaps [rsp], xmm0
00007ff1409d76a2  vmovaps [rsp+0x10], xmm1
00007ff1409d76a8  vmovaps [rsp+0x20], xmm2
00007ff1409d76ae  vmovaps [rsp+0x30], xmm3
00007ff1409d76b4  vmovaps [rsp+0x40], xmm4
00007ff1409d76ba  vmovaps [rsp+0x50], xmm5
00007ff1409d76c0  vmovaps [rsp+0x60], xmm6
00007ff1409d76c6  vmovaps [rsp+0x70], xmm7
00007ff1409d76cc  vmovaps [rsp+0x80], xmm8
00007ff1409d76d5  vmovaps [rsp+0x90], xmm9
00007ff1409d76de  vmovaps [rsp+0xA0], xmm10
00007ff1409d76e7  vmovaps [rsp+0xB0], xmm12
00007ff1409d76f0  vmovaps [rsp+0xC0], xmm13
00007ff1409d76f9  vmovaps [rsp+0xD0], xmm14
00007ff1409d7702  vmovaps [rsp+0xE0], xmm15
00007ff1409d770b  sub rsp, 0x30
00007ff1409d770f  movaps [rsp], xmm11
00007ff1409d7714  movaps [rsp+0x10], xmm7
00007ff1409d7719  movaps [rsp+0x20], xmm13
00007ff1409d771f  lea rdi, [rsp]
00007ff1409d7723  mov esi, 0x00
00007ff1409d7728  mov rax, 0x565C7F10C530
00007ff1409d7732  call rax
00007ff1409d7734  movaps xmm11, [rsp]
00007ff1409d7739  add rsp, 0x30
00007ff1409d773d  vmovaps xmm0, [rsp]
00007ff1409d7742  vmovaps xmm1, [rsp+0x10]
00007ff1409d7748  vmovaps xmm2, [rsp+0x20]
00007ff1409d774e  vmovaps xmm3, [rsp+0x30]
00007ff1409d7754  vmovaps xmm4, [rsp+0x40]
00007ff1409d775a  vmovaps xmm5, [rsp+0x50]
00007ff1409d7760  vmovaps xmm6, [rsp+0x60]
00007ff1409d7766  vmovaps xmm7, [rsp+0x70]
00007ff1409d776c  vmovaps xmm8, [rsp+0x80]
00007ff1409d7775  vmovaps xmm9, [rsp+0x90]
00007ff1409d777e  vmovaps xmm10, [rsp+0xA0]
00007ff1409d7787  vmovaps xmm12, [rsp+0xB0]
00007ff1409d7790  vmovaps xmm13, [rsp+0xC0]
00007ff1409d7799  vmovaps xmm14, [rsp+0xD0]
00007ff1409d77a2  vmovaps xmm15, [rsp+0xE0]
00007ff1409d77ab  add rsp, 0xF0
00007ff1409d77b2  pop r11
00007ff1409d77b4  pop r10
00007ff1409d77b6  pop r9
00007ff1409d77b8  pop r8
00007ff1409d77ba  pop rsi
00007ff1409d77bb  pop rdi
00007ff1409d77bc  pop rdx
00007ff1409d77bd  pop rcx
00007ff1409d77be  pop rax
00007ff1409d77bf  add rsp, 0x08
00007ff1409d77c3  jmp 0x00007FF1409D335E
00007ff1409d77c8  sub rsp, 0x08
00007ff1409d77cc  push rax
00007ff1409d77cd  push rcx
00007ff1409d77ce  push rdx
00007ff1409d77cf  push rdi
00007ff1409d77d0  push rsi
00007ff1409d77d1  push r8
00007ff1409d77d3  push r9
00007ff1409d77d5  push r10
00007ff1409d77d7  push r11
00007ff1409d77d9  sub rsp, 0xF0
00007ff1409d77e0  vmovaps [rsp], xmm0
00007ff1409d77e5  vmovaps [rsp+0x10], xmm1
00007ff1409d77eb  vmovaps [rsp+0x20], xmm2
00007ff1409d77f1  vmovaps [rsp+0x30], xmm3
00007ff1409d77f7  vmovaps [rsp+0x40], xmm4
00007ff1409d77fd  vmovaps [rsp+0x50], xmm5
00007ff1409d7803  vmovaps [rsp+0x60], xmm6
00007ff1409d7809  vmovaps [rsp+0x70], xmm7
00007ff1409d780f  vmovaps [rsp+0x80], xmm8
00007ff1409d7818  vmovaps [rsp+0x90], xmm9
00007ff1409d7821  vmovaps [rsp+0xA0], xmm10
00007ff1409d782a  vmovaps [rsp+0xB0], xmm11
00007ff1409d7833  vmovaps [rsp+0xC0], xmm12
00007ff1409d783c  vmovaps [rsp+0xD0], xmm14
00007ff1409d7845  vmovaps [rsp+0xE0], xmm15
00007ff1409d784e  sub rsp, 0x30
00007ff1409d7852  movaps [rsp], xmm13
00007ff1409d7857  movaps [rsp+0x10], xmm10
00007ff1409d785d  movaps [rsp+0x20], xmm12
00007ff1409d7863  lea rdi, [rsp]
00007ff1409d7867  mov esi, 0x00
00007ff1409d786c  mov rax, 0x565C7F10C530
00007ff1409d7876  call rax
00007ff1409d7878  movaps xmm13, [rsp]
00007ff1409d787d  add rsp, 0x30
00007ff1409d7881  vmovaps xmm0, [rsp]
00007ff1409d7886  vmovaps xmm1, [rsp+0x10]
00007ff1409d788c  vmovaps xmm2, [rsp+0x20]
00007ff1409d7892  vmovaps xmm3, [rsp+0x30]
00007ff1409d7898  vmovaps xmm4, [rsp+0x40]
00007ff1409d789e  vmovaps xmm5, [rsp+0x50]
00007ff1409d78a4  vmovaps xmm6, [rsp+0x60]
00007ff1409d78aa  vmovaps xmm7, [rsp+0x70]
00007ff1409d78b0  vmovaps xmm8, [rsp+0x80]
00007ff1409d78b9  vmovaps xmm9, [rsp+0x90]
00007ff1409d78c2  vmovaps xmm10, [rsp+0xA0]
00007ff1409d78cb  vmovaps xmm11, [rsp+0xB0]
00007ff1409d78d4  vmovaps xmm12, [rsp+0xC0]
00007ff1409d78dd  vmovaps xmm14, [rsp+0xD0]
00007ff1409d78e6  vmovaps xmm15, [rsp+0xE0]
00007ff1409d78ef  add rsp, 0xF0
00007ff1409d78f6  pop r11
00007ff1409d78f8  pop r10
00007ff1409d78fa  pop r9
00007ff1409d78fc  pop r8
00007ff1409d78fe  pop rsi
00007ff1409d78ff  pop rdi
00007ff1409d7900  pop rdx
00007ff1409d7901  pop rcx
00007ff1409d7902  pop rax
00007ff1409d7903  add rsp, 0x08
00007ff1409d7907  jmp 0x00007FF1409D3378
00007ff1409d790c  sub rsp, 0x08
00007ff1409d7910  push rax
00007ff1409d7911  push rcx
00007ff1409d7912  push rdx
00007ff1409d7913  push rdi
00007ff1409d7914  push rsi
00007ff1409d7915  push r8
00007ff1409d7917  push r9
00007ff1409d7919  push r10
00007ff1409d791b  push r11
00007ff1409d791d  sub rsp, 0xF0
00007ff1409d7924  vmovaps [rsp], xmm0
00007ff1409d7929  vmovaps [rsp+0x10], xmm1
00007ff1409d792f  vmovaps [rsp+0x20], xmm2
00007ff1409d7935  vmovaps [rsp+0x30], xmm3
00007ff1409d793b  vmovaps [rsp+0x40], xmm4
00007ff1409d7941  vmovaps [rsp+0x50], xmm5
00007ff1409d7947  vmovaps [rsp+0x60], xmm6
00007ff1409d794d  vmovaps [rsp+0x70], xmm7
00007ff1409d7953  vmovaps [rsp+0x80], xmm8
00007ff1409d795c  vmovaps [rsp+0x90], xmm9
00007ff1409d7965  vmovaps [rsp+0xA0], xmm11
00007ff1409d796e  vmovaps [rsp+0xB0], xmm12
00007ff1409d7977  vmovaps [rsp+0xC0], xmm13
00007ff1409d7980  vmovaps [rsp+0xD0], xmm14
00007ff1409d7989  vmovaps [rsp+0xE0], xmm15
00007ff1409d7992  sub rsp, 0x30
00007ff1409d7996  movaps [rsp], xmm10
00007ff1409d799b  movaps [rsp+0x10], xmm7
00007ff1409d79a0  movaps [rsp+0x20], xmm12
00007ff1409d79a6  lea rdi, [rsp]
00007ff1409d79aa  mov esi, 0x00
00007ff1409d79af  mov rax, 0x565C7F10C530
00007ff1409d79b9  call rax
00007ff1409d79bb  movaps xmm10, [rsp]
00007ff1409d79c0  add rsp, 0x30
00007ff1409d79c4  vmovaps xmm0, [rsp]
00007ff1409d79c9  vmovaps xmm1, [rsp+0x10]
00007ff1409d79cf  vmovaps xmm2, [rsp+0x20]
00007ff1409d79d5  vmovaps xmm3, [rsp+0x30]
00007ff1409d79db  vmovaps xmm4, [rsp+0x40]
00007ff1409d79e1  vmovaps xmm5, [rsp+0x50]
00007ff1409d79e7  vmovaps xmm6, [rsp+0x60]
00007ff1409d79ed  vmovaps xmm7, [rsp+0x70]
00007ff1409d79f3  vmovaps xmm8, [rsp+0x80]
00007ff1409d79fc  vmovaps xmm9, [rsp+0x90]
00007ff1409d7a05  vmovaps xmm11, [rsp+0xA0]
00007ff1409d7a0e  vmovaps xmm12, [rsp+0xB0]
00007ff1409d7a17  vmovaps xmm13, [rsp+0xC0]
00007ff1409d7a20  vmovaps xmm14, [rsp+0xD0]
00007ff1409d7a29  vmovaps xmm15, [rsp+0xE0]
00007ff1409d7a32  add rsp, 0xF0
00007ff1409d7a39  pop r11
00007ff1409d7a3b  pop r10
00007ff1409d7a3d  pop r9
00007ff1409d7a3f  pop r8
00007ff1409d7a41  pop rsi
00007ff1409d7a42  pop rdi
00007ff1409d7a43  pop rdx
00007ff1409d7a44  pop rcx
00007ff1409d7a45  pop rax
00007ff1409d7a46  add rsp, 0x08
00007ff1409d7a4a  jmp 0x00007FF1409D33A4
00007ff1409d7a4f  sub rsp, 0x08
00007ff1409d7a53  push rax
00007ff1409d7a54  push rcx
00007ff1409d7a55  push rdx
00007ff1409d7a56  push rdi
00007ff1409d7a57  push rsi
00007ff1409d7a58  push r8
00007ff1409d7a5a  push r9
00007ff1409d7a5c  push r10
00007ff1409d7a5e  push r11
00007ff1409d7a60  sub rsp, 0xF0
00007ff1409d7a67  vmovaps [rsp], xmm0
00007ff1409d7a6c  vmovaps [rsp+0x10], xmm1
00007ff1409d7a72  vmovaps [rsp+0x20], xmm2
00007ff1409d7a78  vmovaps [rsp+0x30], xmm3
00007ff1409d7a7e  vmovaps [rsp+0x40], xmm4
00007ff1409d7a84  vmovaps [rsp+0x50], xmm5
00007ff1409d7a8a  vmovaps [rsp+0x60], xmm6
00007ff1409d7a90  vmovaps [rsp+0x70], xmm7
00007ff1409d7a96  vmovaps [rsp+0x80], xmm8
00007ff1409d7a9f  vmovaps [rsp+0x90], xmm9
00007ff1409d7aa8  vmovaps [rsp+0xA0], xmm10
00007ff1409d7ab1  vmovaps [rsp+0xB0], xmm11
00007ff1409d7aba  vmovaps [rsp+0xC0], xmm13
00007ff1409d7ac3  vmovaps [rsp+0xD0], xmm14
00007ff1409d7acc  vmovaps [rsp+0xE0], xmm15
00007ff1409d7ad5  sub rsp, 0x30
00007ff1409d7ad9  movaps [rsp], xmm12
00007ff1409d7ade  movaps [rsp+0x10], xmm1
00007ff1409d7ae3  movaps [rsp+0x20], xmm8
00007ff1409d7ae9  lea rdi, [rsp]
00007ff1409d7aed  mov esi, 0x00
00007ff1409d7af2  mov rax, 0x565C7F10C530
00007ff1409d7afc  call rax
00007ff1409d7afe  movaps xmm12, [rsp]
00007ff1409d7b03  add rsp, 0x30
00007ff1409d7b07  vmovaps xmm0, [rsp]
00007ff1409d7b0c  vmovaps xmm1, [rsp+0x10]
00007ff1409d7b12  vmovaps xmm2, [rsp+0x20]
00007ff1409d7b18  vmovaps xmm3, [rsp+0x30]
00007ff1409d7b1e  vmovaps xmm4, [rsp+0x40]
00007ff1409d7b24  vmovaps xmm5, [rsp+0x50]
00007ff1409d7b2a  vmovaps xmm6, [rsp+0x60]
00007ff1409d7b30  vmovaps xmm7, [rsp+0x70]
00007ff1409d7b36  vmovaps xmm8, [rsp+0x80]
00007ff1409d7b3f  vmovaps xmm9, [rsp+0x90]
00007ff1409d7b48  vmovaps xmm10, [rsp+0xA0]
00007ff1409d7b51  vmovaps xmm11, [rsp+0xB0]
00007ff1409d7b5a  vmovaps xmm13, [rsp+0xC0]
00007ff1409d7b63  vmovaps xmm14, [rsp+0xD0]
00007ff1409d7b6c  vmovaps xmm15, [rsp+0xE0]
00007ff1409d7b75  add rsp, 0xF0
00007ff1409d7b7c  pop r11
00007ff1409d7b7e  pop r10
00007ff1409d7b80  pop r9
00007ff1409d7b82  pop r8
00007ff1409d7b84  pop rsi
00007ff1409d7b85  pop rdi
00007ff1409d7b86  pop rdx
00007ff1409d7b87  pop rcx
00007ff1409d7b88  pop rax
00007ff1409d7b89  add rsp, 0x08
00007ff1409d7b8d  jmp 0x00007FF1409D33BE
00007ff1409d7b92  call 0x00007FF1407FF430
00007ff1409d7b97  jmp 0x00007FF1409D33C8
00007ff1409d7b9c  sub rsp, 0x08
00007ff1409d7ba0  push rax
00007ff1409d7ba1  push rcx
00007ff1409d7ba2  push rdx
00007ff1409d7ba3  push rdi
00007ff1409d7ba4  push rsi
00007ff1409d7ba5  push r8
00007ff1409d7ba7  push r9
00007ff1409d7ba9  push r10
00007ff1409d7bab  push r11
00007ff1409d7bad  sub rsp, 0xF0
00007ff1409d7bb4  vmovaps [rsp], xmm0
00007ff1409d7bb9  vmovaps [rsp+0x10], xmm1
00007ff1409d7bbf  vmovaps [rsp+0x20], xmm2
00007ff1409d7bc5  vmovaps [rsp+0x30], xmm3
00007ff1409d7bcb  vmovaps [rsp+0x40], xmm4
00007ff1409d7bd1  vmovaps [rsp+0x50], xmm5
00007ff1409d7bd7  vmovaps [rsp+0x60], xmm6
00007ff1409d7bdd  vmovaps [rsp+0x70], xmm7
00007ff1409d7be3  vmovaps [rsp+0x80], xmm9
00007ff1409d7bec  vmovaps [rsp+0x90], xmm10
00007ff1409d7bf5  vmovaps [rsp+0xA0], xmm11
00007ff1409d7bfe  vmovaps [rsp+0xB0], xmm12
00007ff1409d7c07  vmovaps [rsp+0xC0], xmm13
00007ff1409d7c10  vmovaps [rsp+0xD0], xmm14
00007ff1409d7c19  vmovaps [rsp+0xE0], xmm15
00007ff1409d7c22  sub rsp, 0x30
00007ff1409d7c26  movaps [rsp], xmm8
00007ff1409d7c2b  movaps [rsp+0x10], xmm15
00007ff1409d7c31  movaps [rsp+0x20], xmm9
00007ff1409d7c37  lea rdi, [rsp]
00007ff1409d7c3b  mov esi, 0x00
00007ff1409d7c40  mov rax, 0x565C7F10C530
00007ff1409d7c4a  call rax
00007ff1409d7c4c  movaps xmm8, [rsp]
00007ff1409d7c51  add rsp, 0x30
00007ff1409d7c55  vmovaps xmm0, [rsp]
00007ff1409d7c5a  vmovaps xmm1, [rsp+0x10]
00007ff1409d7c60  vmovaps xmm2, [rsp+0x20]
00007ff1409d7c66  vmovaps xmm3, [rsp+0x30]
00007ff1409d7c6c  vmovaps xmm4, [rsp+0x40]
00007ff1409d7c72  vmovaps xmm5, [rsp+0x50]
00007ff1409d7c78  vmovaps xmm6, [rsp+0x60]
00007ff1409d7c7e  vmovaps xmm7, [rsp+0x70]
00007ff1409d7c84  vmovaps xmm9, [rsp+0x80]
00007ff1409d7c8d  vmovaps xmm10, [rsp+0x90]
00007ff1409d7c96  vmovaps xmm11, [rsp+0xA0]
00007ff1409d7c9f  vmovaps xmm12, [rsp+0xB0]
00007ff1409d7ca8  vmovaps xmm13, [rsp+0xC0]
00007ff1409d7cb1  vmovaps xmm14, [rsp+0xD0]
00007ff1409d7cba  vmovaps xmm15, [rsp+0xE0]
00007ff1409d7cc3  add rsp, 0xF0
00007ff1409d7cca  pop r11
00007ff1409d7ccc  pop r10
00007ff1409d7cce  pop r9
00007ff1409d7cd0  pop r8
00007ff1409d7cd2  pop rsi
00007ff1409d7cd3  pop rdi
00007ff1409d7cd4  pop rdx
00007ff1409d7cd5  pop rcx
00007ff1409d7cd6  pop rax
00007ff1409d7cd7  add rsp, 0x08
00007ff1409d7cdb  jmp 0x00007FF1409D33EA
00007ff1409d7ce0  sub rsp, 0x08
00007ff1409d7ce4  push rax
00007ff1409d7ce5  push rcx
00007ff1409d7ce6  push rdx
00007ff1409d7ce7  push rdi
00007ff1409d7ce8  push rsi
00007ff1409d7ce9  push r8
00007ff1409d7ceb  push r9
00007ff1409d7ced  push r10
00007ff1409d7cef  push r11
00007ff1409d7cf1  sub rsp, 0xF0
00007ff1409d7cf8  vmovaps [rsp], xmm0
00007ff1409d7cfd  vmovaps [rsp+0x10], xmm1
00007ff1409d7d03  vmovaps [rsp+0x20], xmm2
00007ff1409d7d09  vmovaps [rsp+0x30], xmm3
00007ff1409d7d0f  vmovaps [rsp+0x40], xmm4
00007ff1409d7d15  vmovaps [rsp+0x50], xmm5
00007ff1409d7d1b  vmovaps [rsp+0x60], xmm6
00007ff1409d7d21  vmovaps [rsp+0x70], xmm7
00007ff1409d7d27  vmovaps [rsp+0x80], xmm8
00007ff1409d7d30  vmovaps [rsp+0x90], xmm10
00007ff1409d7d39  vmovaps [rsp+0xA0], xmm11
00007ff1409d7d42  vmovaps [rsp+0xB0], xmm12
00007ff1409d7d4b  vmovaps [rsp+0xC0], xmm13
00007ff1409d7d54  vmovaps [rsp+0xD0], xmm14
00007ff1409d7d5d  vmovaps [rsp+0xE0], xmm15
00007ff1409d7d66  sub rsp, 0x30
00007ff1409d7d6a  movaps [rsp], xmm9
00007ff1409d7d6f  movaps [rsp+0x10], xmm1
00007ff1409d7d74  movaps [rsp+0x20], xmm15
00007ff1409d7d7a  lea rdi, [rsp]
00007ff1409d7d7e  mov esi, 0x00
00007ff1409d7d83  mov rax, 0x565C7F10C530
00007ff1409d7d8d  call rax
00007ff1409d7d8f  movaps xmm9, [rsp]
00007ff1409d7d94  add rsp, 0x30
00007ff1409d7d98  vmovaps xmm0, [rsp]
00007ff1409d7d9d  vmovaps xmm1, [rsp+0x10]
00007ff1409d7da3  vmovaps xmm2, [rsp+0x20]
00007ff1409d7da9  vmovaps xmm3, [rsp+0x30]
00007ff1409d7daf  vmovaps xmm4, [rsp+0x40]
00007ff1409d7db5  vmovaps xmm5, [rsp+0x50]
00007ff1409d7dbb  vmovaps xmm6, [rsp+0x60]
00007ff1409d7dc1  vmovaps xmm7, [rsp+0x70]
00007ff1409d7dc7  vmovaps xmm8, [rsp+0x80]
00007ff1409d7dd0  vmovaps xmm10, [rsp+0x90]
00007ff1409d7dd9  vmovaps xmm11, [rsp+0xA0]
00007ff1409d7de2  vmovaps xmm12, [rsp+0xB0]
00007ff1409d7deb  vmovaps xmm13, [rsp+0xC0]
00007ff1409d7df4  vmovaps xmm14, [rsp+0xD0]
00007ff1409d7dfd  vmovaps xmm15, [rsp+0xE0]
00007ff1409d7e06  add rsp, 0xF0
00007ff1409d7e0d  pop r11
00007ff1409d7e0f  pop r10
00007ff1409d7e11  pop r9
00007ff1409d7e13  pop r8
00007ff1409d7e15  pop rsi
00007ff1409d7e16  pop rdi
00007ff1409d7e17  pop rdx
00007ff1409d7e18  pop rcx
00007ff1409d7e19  pop rax
00007ff1409d7e1a  add rsp, 0x08
00007ff1409d7e1e  jmp 0x00007FF1409D3418
00007ff1409d7e23  sub rsp, 0x08
00007ff1409d7e27  push rax
00007ff1409d7e28  push rcx
00007ff1409d7e29  push rdx
00007ff1409d7e2a  push rdi
00007ff1409d7e2b  push rsi
00007ff1409d7e2c  push r8
00007ff1409d7e2e  push r9
00007ff1409d7e30  push r10
00007ff1409d7e32  push r11
00007ff1409d7e34  sub rsp, 0xF0
00007ff1409d7e3b  vmovaps [rsp], xmm0
00007ff1409d7e40  vmovaps [rsp+0x10], xmm1
00007ff1409d7e46  vmovaps [rsp+0x20], xmm2
00007ff1409d7e4c  vmovaps [rsp+0x30], xmm3
00007ff1409d7e52  vmovaps [rsp+0x40], xmm4
00007ff1409d7e58  vmovaps [rsp+0x50], xmm5
00007ff1409d7e5e  vmovaps [rsp+0x60], xmm6
00007ff1409d7e64  vmovaps [rsp+0x70], xmm7
00007ff1409d7e6a  vmovaps [rsp+0x80], xmm8
00007ff1409d7e73  vmovaps [rsp+0x90], xmm9
00007ff1409d7e7c  vmovaps [rsp+0xA0], xmm10
00007ff1409d7e85  vmovaps [rsp+0xB0], xmm11
00007ff1409d7e8e  vmovaps [rsp+0xC0], xmm12
00007ff1409d7e97  vmovaps [rsp+0xD0], xmm13
00007ff1409d7ea0  vmovaps [rsp+0xE0], xmm14
00007ff1409d7ea9  sub rsp, 0x30
00007ff1409d7ead  movaps [rsp], xmm15
00007ff1409d7eb2  movaps [rsp+0x10], xmm4
00007ff1409d7eb7  movaps [rsp+0x20], xmm1
00007ff1409d7ebc  lea rdi, [rsp]
00007ff1409d7ec0  mov esi, 0x00
00007ff1409d7ec5  mov rax, 0x565C7F10C530
00007ff1409d7ecf  call rax
00007ff1409d7ed1  movaps xmm15, [rsp]
00007ff1409d7ed6  add rsp, 0x30
00007ff1409d7eda  vmovaps xmm0, [rsp]
00007ff1409d7edf  vmovaps xmm1, [rsp+0x10]
00007ff1409d7ee5  vmovaps xmm2, [rsp+0x20]
00007ff1409d7eeb  vmovaps xmm3, [rsp+0x30]
00007ff1409d7ef1  vmovaps xmm4, [rsp+0x40]
00007ff1409d7ef7  vmovaps xmm5, [rsp+0x50]
00007ff1409d7efd  vmovaps xmm6, [rsp+0x60]
00007ff1409d7f03  vmovaps xmm7, [rsp+0x70]
00007ff1409d7f09  vmovaps xmm8, [rsp+0x80]
00007ff1409d7f12  vmovaps xmm9, [rsp+0x90]
00007ff1409d7f1b  vmovaps xmm10, [rsp+0xA0]
00007ff1409d7f24  vmovaps xmm11, [rsp+0xB0]
00007ff1409d7f2d  vmovaps xmm12, [rsp+0xC0]
00007ff1409d7f36  vmovaps xmm13, [rsp+0xD0]
00007ff1409d7f3f  vmovaps xmm14, [rsp+0xE0]
00007ff1409d7f48  add rsp, 0xF0
00007ff1409d7f4f  pop r11
00007ff1409d7f51  pop r10
00007ff1409d7f53  pop r9
00007ff1409d7f55  pop r8
00007ff1409d7f57  pop rsi
00007ff1409d7f58  pop rdi
00007ff1409d7f59  pop rdx
00007ff1409d7f5a  pop rcx
00007ff1409d7f5b  pop rax
00007ff1409d7f5c  add rsp, 0x08
00007ff1409d7f60  jmp 0x00007FF1409D343E
00007ff1409d7f65  sub rsp, 0x08
00007ff1409d7f69  push rax
00007ff1409d7f6a  push rcx
00007ff1409d7f6b  push rdx
00007ff1409d7f6c  push rdi
00007ff1409d7f6d  push rsi
00007ff1409d7f6e  push r8
00007ff1409d7f70  push r9
00007ff1409d7f72  push r10
00007ff1409d7f74  push r11
00007ff1409d7f76  sub rsp, 0xF0
00007ff1409d7f7d  vmovaps [rsp], xmm0
00007ff1409d7f82  vmovaps [rsp+0x10], xmm2
00007ff1409d7f88  vmovaps [rsp+0x20], xmm3
00007ff1409d7f8e  vmovaps [rsp+0x30], xmm4
00007ff1409d7f94  vmovaps [rsp+0x40], xmm5
00007ff1409d7f9a  vmovaps [rsp+0x50], xmm6
00007ff1409d7fa0  vmovaps [rsp+0x60], xmm7
00007ff1409d7fa6  vmovaps [rsp+0x70], xmm8
00007ff1409d7fac  vmovaps [rsp+0x80], xmm9
00007ff1409d7fb5  vmovaps [rsp+0x90], xmm10
00007ff1409d7fbe  vmovaps [rsp+0xA0], xmm11
00007ff1409d7fc7  vmovaps [rsp+0xB0], xmm12
00007ff1409d7fd0  vmovaps [rsp+0xC0], xmm13
00007ff1409d7fd9  vmovaps [rsp+0xD0], xmm14
00007ff1409d7fe2  vmovaps [rsp+0xE0], xmm15
00007ff1409d7feb  sub rsp, 0x30
00007ff1409d7fef  movaps [rsp], xmm1
00007ff1409d7ff3  movaps [rsp+0x10], xmm14
00007ff1409d7ff9  movaps [rsp+0x20], xmm11
00007ff1409d7fff  lea rdi, [rsp]
00007ff1409d8003  mov esi, 0x00
00007ff1409d8008  mov rax, 0x565C7F10C530
00007ff1409d8012  call rax
00007ff1409d8014  movaps xmm1, [rsp]
00007ff1409d8018  add rsp, 0x30
00007ff1409d801c  vmovaps xmm0, [rsp]
00007ff1409d8021  vmovaps xmm2, [rsp+0x10]
00007ff1409d8027  vmovaps xmm3, [rsp+0x20]
00007ff1409d802d  vmovaps xmm4, [rsp+0x30]
00007ff1409d8033  vmovaps xmm5, [rsp+0x40]
00007ff1409d8039  vmovaps xmm6, [rsp+0x50]
00007ff1409d803f  vmovaps xmm7, [rsp+0x60]
00007ff1409d8045  vmovaps xmm8, [rsp+0x70]
00007ff1409d804b  vmovaps xmm9, [rsp+0x80]
00007ff1409d8054  vmovaps xmm10, [rsp+0x90]
00007ff1409d805d  vmovaps xmm11, [rsp+0xA0]
00007ff1409d8066  vmovaps xmm12, [rsp+0xB0]
00007ff1409d806f  vmovaps xmm13, [rsp+0xC0]
00007ff1409d8078  vmovaps xmm14, [rsp+0xD0]
00007ff1409d8081  vmovaps xmm15, [rsp+0xE0]
00007ff1409d808a  add rsp, 0xF0
00007ff1409d8091  pop r11
00007ff1409d8093  pop r10
00007ff1409d8095  pop r9
00007ff1409d8097  pop r8
00007ff1409d8099  pop rsi
00007ff1409d809a  pop rdi
00007ff1409d809b  pop rdx
00007ff1409d809c  pop rcx
00007ff1409d809d  pop rax
00007ff1409d809e  add rsp, 0x08
00007ff1409d80a2  jmp 0x00007FF1409D345F
00007ff1409d80a7  call 0x00007FF1408E45A0
00007ff1409d80ac  jmp 0x00007FF1409D346D
00007ff1409d80b1  call 0x00007FF140809D70
00007ff1409d80b6  jmp 0x00007FF1409D3477
00007ff1409d80bb  sub rsp, 0x08
00007ff1409d80bf  push rax
00007ff1409d80c0  push rcx
00007ff1409d80c1  push rdx
00007ff1409d80c2  push rdi
00007ff1409d80c3  push rsi
00007ff1409d80c4  push r8
00007ff1409d80c6  push r9
00007ff1409d80c8  push r10
00007ff1409d80ca  push r11
00007ff1409d80cc  sub rsp, 0xF0
00007ff1409d80d3  vmovaps [rsp], xmm0
00007ff1409d80d8  vmovaps [rsp+0x10], xmm1
00007ff1409d80de  vmovaps [rsp+0x20], xmm2
00007ff1409d80e4  vmovaps [rsp+0x30], xmm3
00007ff1409d80ea  vmovaps [rsp+0x40], xmm4
00007ff1409d80f0  vmovaps [rsp+0x50], xmm5
00007ff1409d80f6  vmovaps [rsp+0x60], xmm6
00007ff1409d80fc  vmovaps [rsp+0x70], xmm8
00007ff1409d8102  vmovaps [rsp+0x80], xmm9
00007ff1409d810b  vmovaps [rsp+0x90], xmm10
00007ff1409d8114  vmovaps [rsp+0xA0], xmm11
00007ff1409d811d  vmovaps [rsp+0xB0], xmm12
00007ff1409d8126  vmovaps [rsp+0xC0], xmm13
00007ff1409d812f  vmovaps [rsp+0xD0], xmm14
00007ff1409d8138  vmovaps [rsp+0xE0], xmm15
00007ff1409d8141  sub rsp, 0x30
00007ff1409d8145  movaps [rsp], xmm7
00007ff1409d8149  movaps [rsp+0x10], xmm13
00007ff1409d814f  movaps [rsp+0x20], xmm10
00007ff1409d8155  lea rdi, [rsp]
00007ff1409d8159  mov esi, 0x00
00007ff1409d815e  mov rax, 0x565C7F10C530
00007ff1409d8168  call rax
00007ff1409d816a  movaps xmm7, [rsp]
00007ff1409d816e  add rsp, 0x30
00007ff1409d8172  vmovaps xmm0, [rsp]
00007ff1409d8177  vmovaps xmm1, [rsp+0x10]
00007ff1409d817d  vmovaps xmm2, [rsp+0x20]
00007ff1409d8183  vmovaps xmm3, [rsp+0x30]
00007ff1409d8189  vmovaps xmm4, [rsp+0x40]
00007ff1409d818f  vmovaps xmm5, [rsp+0x50]
00007ff1409d8195  vmovaps xmm6, [rsp+0x60]
00007ff1409d819b  vmovaps xmm8, [rsp+0x70]
00007ff1409d81a1  vmovaps xmm9, [rsp+0x80]
00007ff1409d81aa  vmovaps xmm10, [rsp+0x90]
00007ff1409d81b3  vmovaps xmm11, [rsp+0xA0]
00007ff1409d81bc  vmovaps xmm12, [rsp+0xB0]
00007ff1409d81c5  vmovaps xmm13, [rsp+0xC0]
00007ff1409d81ce  vmovaps xmm14, [rsp+0xD0]
00007ff1409d81d7  vmovaps xmm15, [rsp+0xE0]
00007ff1409d81e0  add rsp, 0xF0
00007ff1409d81e7  pop r11
00007ff1409d81e9  pop r10
00007ff1409d81eb  pop r9
00007ff1409d81ed  pop r8
00007ff1409d81ef  pop rsi
00007ff1409d81f0  pop rdi
00007ff1409d81f1  pop rdx
00007ff1409d81f2  pop rcx
00007ff1409d81f3  pop rax
00007ff1409d81f4  add rsp, 0x08
00007ff1409d81f8  jmp 0x00007FF1409D3498
00007ff1409d81fd  sub rsp, 0x08
00007ff1409d8201  push rax
00007ff1409d8202  push rcx
00007ff1409d8203  push rdx
00007ff1409d8204  push rdi
00007ff1409d8205  push rsi
00007ff1409d8206  push r8
00007ff1409d8208  push r9
00007ff1409d820a  push r10
00007ff1409d820c  push r11
00007ff1409d820e  sub rsp, 0xF0
00007ff1409d8215  vmovaps [rsp], xmm0
00007ff1409d821a  vmovaps [rsp+0x10], xmm1
00007ff1409d8220  vmovaps [rsp+0x20], xmm2
00007ff1409d8226  vmovaps [rsp+0x30], xmm3
00007ff1409d822c  vmovaps [rsp+0x40], xmm4
00007ff1409d8232  vmovaps [rsp+0x50], xmm5
00007ff1409d8238  vmovaps [rsp+0x60], xmm6
00007ff1409d823e  vmovaps [rsp+0x70], xmm7
00007ff1409d8244  vmovaps [rsp+0x80], xmm8
00007ff1409d824d  vmovaps [rsp+0x90], xmm9
00007ff1409d8256  vmovaps [rsp+0xA0], xmm11
00007ff1409d825f  vmovaps [rsp+0xB0], xmm12
00007ff1409d8268  vmovaps [rsp+0xC0], xmm13
00007ff1409d8271  vmovaps [rsp+0xD0], xmm14
00007ff1409d827a  vmovaps [rsp+0xE0], xmm15
00007ff1409d8283  sub rsp, 0x30
00007ff1409d8287  movaps [rsp], xmm10
00007ff1409d828c  movaps [rsp+0x10], xmm11
00007ff1409d8292  movaps [rsp+0x20], xmm13
00007ff1409d8298  lea rdi, [rsp]
00007ff1409d829c  mov esi, 0x00
00007ff1409d82a1  mov rax, 0x565C7F10C530
00007ff1409d82ab  call rax
00007ff1409d82ad  movaps xmm10, [rsp]
00007ff1409d82b2  add rsp, 0x30
00007ff1409d82b6  vmovaps xmm0, [rsp]
00007ff1409d82bb  vmovaps xmm1, [rsp+0x10]
00007ff1409d82c1  vmovaps xmm2, [rsp+0x20]
00007ff1409d82c7  vmovaps xmm3, [rsp+0x30]
00007ff1409d82cd  vmovaps xmm4, [rsp+0x40]
00007ff1409d82d3  vmovaps xmm5, [rsp+0x50]
00007ff1409d82d9  vmovaps xmm6, [rsp+0x60]
00007ff1409d82df  vmovaps xmm7, [rsp+0x70]
00007ff1409d82e5  vmovaps xmm8, [rsp+0x80]
00007ff1409d82ee  vmovaps xmm9, [rsp+0x90]
00007ff1409d82f7  vmovaps xmm11, [rsp+0xA0]
00007ff1409d8300  vmovaps xmm12, [rsp+0xB0]
00007ff1409d8309  vmovaps xmm13, [rsp+0xC0]
00007ff1409d8312  vmovaps xmm14, [rsp+0xD0]
00007ff1409d831b  vmovaps xmm15, [rsp+0xE0]
00007ff1409d8324  add rsp, 0xF0
00007ff1409d832b  pop r11
00007ff1409d832d  pop r10
00007ff1409d832f  pop r9
00007ff1409d8331  pop r8
00007ff1409d8333  pop rsi
00007ff1409d8334  pop rdi
00007ff1409d8335  pop rdx
00007ff1409d8336  pop rcx
00007ff1409d8337  pop rax
00007ff1409d8338  add rsp, 0x08
00007ff1409d833c  jmp 0x00007FF1409D34C6
00007ff1409d8341  sub rsp, 0x08
00007ff1409d8345  push rax
00007ff1409d8346  push rcx
00007ff1409d8347  push rdx
00007ff1409d8348  push rdi
00007ff1409d8349  push rsi
00007ff1409d834a  push r8
00007ff1409d834c  push r9
00007ff1409d834e  push r10
00007ff1409d8350  push r11
00007ff1409d8352  sub rsp, 0xF0
00007ff1409d8359  vmovaps [rsp], xmm0
00007ff1409d835e  vmovaps [rsp+0x10], xmm1
00007ff1409d8364  vmovaps [rsp+0x20], xmm2
00007ff1409d836a  vmovaps [rsp+0x30], xmm3
00007ff1409d8370  vmovaps [rsp+0x40], xmm4
00007ff1409d8376  vmovaps [rsp+0x50], xmm5
00007ff1409d837c  vmovaps [rsp+0x60], xmm6
00007ff1409d8382  vmovaps [rsp+0x70], xmm7
00007ff1409d8388  vmovaps [rsp+0x80], xmm8
00007ff1409d8391  vmovaps [rsp+0x90], xmm9
00007ff1409d839a  vmovaps [rsp+0xA0], xmm10
00007ff1409d83a3  vmovaps [rsp+0xB0], xmm12
00007ff1409d83ac  vmovaps [rsp+0xC0], xmm13
00007ff1409d83b5  vmovaps [rsp+0xD0], xmm14
00007ff1409d83be  vmovaps [rsp+0xE0], xmm15
00007ff1409d83c7  sub rsp, 0x30
00007ff1409d83cb  movaps [rsp], xmm11
00007ff1409d83d0  movaps [rsp+0x10], xmm14
00007ff1409d83d6  movaps [rsp+0x20], xmm13
00007ff1409d83dc  lea rdi, [rsp]
00007ff1409d83e0  mov esi, 0x00
00007ff1409d83e5  mov rax, 0x565C7F10C530
00007ff1409d83ef  call rax
00007ff1409d83f1  movaps xmm11, [rsp]
00007ff1409d83f6  add rsp, 0x30
00007ff1409d83fa  vmovaps xmm0, [rsp]
00007ff1409d83ff  vmovaps xmm1, [rsp+0x10]
00007ff1409d8405  vmovaps xmm2, [rsp+0x20]
00007ff1409d840b  vmovaps xmm3, [rsp+0x30]
00007ff1409d8411  vmovaps xmm4, [rsp+0x40]
00007ff1409d8417  vmovaps xmm5, [rsp+0x50]
00007ff1409d841d  vmovaps xmm6, [rsp+0x60]
00007ff1409d8423  vmovaps xmm7, [rsp+0x70]
00007ff1409d8429  vmovaps xmm8, [rsp+0x80]
00007ff1409d8432  vmovaps xmm9, [rsp+0x90]
00007ff1409d843b  vmovaps xmm10, [rsp+0xA0]
00007ff1409d8444  vmovaps xmm12, [rsp+0xB0]
00007ff1409d844d  vmovaps xmm13, [rsp+0xC0]
00007ff1409d8456  vmovaps xmm14, [rsp+0xD0]
00007ff1409d845f  vmovaps xmm15, [rsp+0xE0]
00007ff1409d8468  add rsp, 0xF0
00007ff1409d846f  pop r11
00007ff1409d8471  pop r10
00007ff1409d8473  pop r9
00007ff1409d8475  pop r8
00007ff1409d8477  pop rsi
00007ff1409d8478  pop rdi
00007ff1409d8479  pop rdx
00007ff1409d847a  pop rcx
00007ff1409d847b  pop rax
00007ff1409d847c  add rsp, 0x08
00007ff1409d8480  jmp 0x00007FF1409D34F4
00007ff1409d8485  sub rsp, 0x08
00007ff1409d8489  push rax
00007ff1409d848a  push rcx
00007ff1409d848b  push rdx
00007ff1409d848c  push rdi
00007ff1409d848d  push rsi
00007ff1409d848e  push r8
00007ff1409d8490  push r9
00007ff1409d8492  push r10
00007ff1409d8494  push r11
00007ff1409d8496  sub rsp, 0xF0
00007ff1409d849d  vmovaps [rsp], xmm0
00007ff1409d84a2  vmovaps [rsp+0x10], xmm1
00007ff1409d84a8  vmovaps [rsp+0x20], xmm2
00007ff1409d84ae  vmovaps [rsp+0x30], xmm3
00007ff1409d84b4  vmovaps [rsp+0x40], xmm4
00007ff1409d84ba  vmovaps [rsp+0x50], xmm5
00007ff1409d84c0  vmovaps [rsp+0x60], xmm6
00007ff1409d84c6  vmovaps [rsp+0x70], xmm7
00007ff1409d84cc  vmovaps [rsp+0x80], xmm8
00007ff1409d84d5  vmovaps [rsp+0x90], xmm9
00007ff1409d84de  vmovaps [rsp+0xA0], xmm10
00007ff1409d84e7  vmovaps [rsp+0xB0], xmm11
00007ff1409d84f0  vmovaps [rsp+0xC0], xmm12
00007ff1409d84f9  vmovaps [rsp+0xD0], xmm13
00007ff1409d8502  vmovaps [rsp+0xE0], xmm15
00007ff1409d850b  sub rsp, 0x30
00007ff1409d850f  movaps [rsp], xmm14
00007ff1409d8514  movaps [rsp+0x10], xmm12
00007ff1409d851a  movaps [rsp+0x20], xmm9
00007ff1409d8520  lea rdi, [rsp]
00007ff1409d8524  mov esi, 0x00
00007ff1409d8529  mov rax, 0x565C7F10C530
00007ff1409d8533  call rax
00007ff1409d8535  movaps xmm14, [rsp]
00007ff1409d853a  add rsp, 0x30
00007ff1409d853e  vmovaps xmm0, [rsp]
00007ff1409d8543  vmovaps xmm1, [rsp+0x10]
00007ff1409d8549  vmovaps xmm2, [rsp+0x20]
00007ff1409d854f  vmovaps xmm3, [rsp+0x30]
00007ff1409d8555  vmovaps xmm4, [rsp+0x40]
00007ff1409d855b  vmovaps xmm5, [rsp+0x50]
00007ff1409d8561  vmovaps xmm6, [rsp+0x60]
00007ff1409d8567  vmovaps xmm7, [rsp+0x70]
00007ff1409d856d  vmovaps xmm8, [rsp+0x80]
00007ff1409d8576  vmovaps xmm9, [rsp+0x90]
00007ff1409d857f  vmovaps xmm10, [rsp+0xA0]
00007ff1409d8588  vmovaps xmm11, [rsp+0xB0]
00007ff1409d8591  vmovaps xmm12, [rsp+0xC0]
00007ff1409d859a  vmovaps xmm13, [rsp+0xD0]
00007ff1409d85a3  vmovaps xmm15, [rsp+0xE0]
00007ff1409d85ac  add rsp, 0xF0
00007ff1409d85b3  pop r11
00007ff1409d85b5  pop r10
00007ff1409d85b7  pop r9
00007ff1409d85b9  pop r8
00007ff1409d85bb  pop rsi
00007ff1409d85bc  pop rdi
00007ff1409d85bd  pop rdx
00007ff1409d85be  pop rcx
00007ff1409d85bf  pop rax
00007ff1409d85c0  add rsp, 0x08
00007ff1409d85c4  jmp 0x00007FF1409D350F
00007ff1409d85c9  sub rsp, 0x08
00007ff1409d85cd  push rax
00007ff1409d85ce  push rcx
00007ff1409d85cf  push rdx
00007ff1409d85d0  push rdi
00007ff1409d85d1  push rsi
00007ff1409d85d2  push r8
00007ff1409d85d4  push r9
00007ff1409d85d6  push r10
00007ff1409d85d8  push r11
00007ff1409d85da  sub rsp, 0xF0
00007ff1409d85e1  vmovaps [rsp], xmm0
00007ff1409d85e6  vmovaps [rsp+0x10], xmm1
00007ff1409d85ec  vmovaps [rsp+0x20], xmm2
00007ff1409d85f2  vmovaps [rsp+0x30], xmm3
00007ff1409d85f8  vmovaps [rsp+0x40], xmm4
00007ff1409d85fe  vmovaps [rsp+0x50], xmm5
00007ff1409d8604  vmovaps [rsp+0x60], xmm6
00007ff1409d860a  vmovaps [rsp+0x70], xmm7
00007ff1409d8610  vmovaps [rsp+0x80], xmm8
00007ff1409d8619  vmovaps [rsp+0x90], xmm9
00007ff1409d8622  vmovaps [rsp+0xA0], xmm10
00007ff1409d862b  vmovaps [rsp+0xB0], xmm11
00007ff1409d8634  vmovaps [rsp+0xC0], xmm12
00007ff1409d863d  vmovaps [rsp+0xD0], xmm14
00007ff1409d8646  vmovaps [rsp+0xE0], xmm15
00007ff1409d864f  sub rsp, 0x30
00007ff1409d8653  movaps [rsp], xmm13
00007ff1409d8658  movaps [rsp+0x10], xmm8
00007ff1409d865e  movaps [rsp+0x20], xmm15
00007ff1409d8664  lea rdi, [rsp]
00007ff1409d8668  mov esi, 0x00
00007ff1409d866d  mov rax, 0x565C7F10C530
00007ff1409d8677  call rax
00007ff1409d8679  movaps xmm13, [rsp]
00007ff1409d867e  add rsp, 0x30
00007ff1409d8682  vmovaps xmm0, [rsp]
00007ff1409d8687  vmovaps xmm1, [rsp+0x10]
00007ff1409d868d  vmovaps xmm2, [rsp+0x20]
00007ff1409d8693  vmovaps xmm3, [rsp+0x30]
00007ff1409d8699  vmovaps xmm4, [rsp+0x40]
00007ff1409d869f  vmovaps xmm5, [rsp+0x50]
00007ff1409d86a5  vmovaps xmm6, [rsp+0x60]
00007ff1409d86ab  vmovaps xmm7, [rsp+0x70]
00007ff1409d86b1  vmovaps xmm8, [rsp+0x80]
00007ff1409d86ba  vmovaps xmm9, [rsp+0x90]
00007ff1409d86c3  vmovaps xmm10, [rsp+0xA0]
00007ff1409d86cc  vmovaps xmm11, [rsp+0xB0]
00007ff1409d86d5  vmovaps xmm12, [rsp+0xC0]
00007ff1409d86de  vmovaps xmm14, [rsp+0xD0]
00007ff1409d86e7  vmovaps xmm15, [rsp+0xE0]
00007ff1409d86f0  add rsp, 0xF0
00007ff1409d86f7  pop r11
00007ff1409d86f9  pop r10
00007ff1409d86fb  pop r9
00007ff1409d86fd  pop r8
00007ff1409d86ff  pop rsi
00007ff1409d8700  pop rdi
00007ff1409d8701  pop rdx
00007ff1409d8702  pop rcx
00007ff1409d8703  pop rax
00007ff1409d8704  add rsp, 0x08
00007ff1409d8708  jmp 0x00007FF1409D3532
00007ff1409d870d  sub rsp, 0x08
00007ff1409d8711  push rax
00007ff1409d8712  push rcx
00007ff1409d8713  push rdx
00007ff1409d8714  push rdi
00007ff1409d8715  push rsi
00007ff1409d8716  push r8
00007ff1409d8718  push r9
00007ff1409d871a  push r10
00007ff1409d871c  push r11
00007ff1409d871e  sub rsp, 0xF0
00007ff1409d8725  vmovaps [rsp], xmm0
00007ff1409d872a  vmovaps [rsp+0x10], xmm1
00007ff1409d8730  vmovaps [rsp+0x20], xmm2
00007ff1409d8736  vmovaps [rsp+0x30], xmm3
00007ff1409d873c  vmovaps [rsp+0x40], xmm4
00007ff1409d8742  vmovaps [rsp+0x50], xmm5
00007ff1409d8748  vmovaps [rsp+0x60], xmm6
00007ff1409d874e  vmovaps [rsp+0x70], xmm7
00007ff1409d8754  vmovaps [rsp+0x80], xmm8
00007ff1409d875d  vmovaps [rsp+0x90], xmm9
00007ff1409d8766  vmovaps [rsp+0xA0], xmm10
00007ff1409d876f  vmovaps [rsp+0xB0], xmm11
00007ff1409d8778  vmovaps [rsp+0xC0], xmm12
00007ff1409d8781  vmovaps [rsp+0xD0], xmm13
00007ff1409d878a  vmovaps [rsp+0xE0], xmm14
00007ff1409d8793  sub rsp, 0x30
00007ff1409d8797  movaps [rsp], xmm15
00007ff1409d879c  movaps [rsp+0x10], xmm1
00007ff1409d87a1  movaps [rsp+0x20], xmm10
00007ff1409d87a7  lea rdi, [rsp]
00007ff1409d87ab  mov esi, 0x00
00007ff1409d87b0  mov rax, 0x565C7F10C530
00007ff1409d87ba  call rax
00007ff1409d87bc  movaps xmm15, [rsp]
00007ff1409d87c1  add rsp, 0x30
00007ff1409d87c5  vmovaps xmm0, [rsp]
00007ff1409d87ca  vmovaps xmm1, [rsp+0x10]
00007ff1409d87d0  vmovaps xmm2, [rsp+0x20]
00007ff1409d87d6  vmovaps xmm3, [rsp+0x30]
00007ff1409d87dc  vmovaps xmm4, [rsp+0x40]
00007ff1409d87e2  vmovaps xmm5, [rsp+0x50]
00007ff1409d87e8  vmovaps xmm6, [rsp+0x60]
00007ff1409d87ee  vmovaps xmm7, [rsp+0x70]
00007ff1409d87f4  vmovaps xmm8, [rsp+0x80]
00007ff1409d87fd  vmovaps xmm9, [rsp+0x90]
00007ff1409d8806  vmovaps xmm10, [rsp+0xA0]
00007ff1409d880f  vmovaps xmm11, [rsp+0xB0]
00007ff1409d8818  vmovaps xmm12, [rsp+0xC0]
00007ff1409d8821  vmovaps xmm13, [rsp+0xD0]
00007ff1409d882a  vmovaps xmm14, [rsp+0xE0]
00007ff1409d8833  add rsp, 0xF0
00007ff1409d883a  pop r11
00007ff1409d883c  pop r10
00007ff1409d883e  pop r9
00007ff1409d8840  pop r8
00007ff1409d8842  pop rsi
00007ff1409d8843  pop rdi
00007ff1409d8844  pop rdx
00007ff1409d8845  pop rcx
00007ff1409d8846  pop rax
00007ff1409d8847  add rsp, 0x08
00007ff1409d884b  jmp 0x00007FF1409D3555
00007ff1409d8850  sub rsp, 0x08
00007ff1409d8854  push rax
00007ff1409d8855  push rcx
00007ff1409d8856  push rdx
00007ff1409d8857  push rdi
00007ff1409d8858  push rsi
00007ff1409d8859  push r8
00007ff1409d885b  push r9
00007ff1409d885d  push r10
00007ff1409d885f  push r11
00007ff1409d8861  sub rsp, 0xF0
00007ff1409d8868  vmovaps [rsp], xmm0
00007ff1409d886d  vmovaps [rsp+0x10], xmm2
00007ff1409d8873  vmovaps [rsp+0x20], xmm3
00007ff1409d8879  vmovaps [rsp+0x30], xmm4
00007ff1409d887f  vmovaps [rsp+0x40], xmm5
00007ff1409d8885  vmovaps [rsp+0x50], xmm6
00007ff1409d888b  vmovaps [rsp+0x60], xmm7
00007ff1409d8891  vmovaps [rsp+0x70], xmm8
00007ff1409d8897  vmovaps [rsp+0x80], xmm9
00007ff1409d88a0  vmovaps [rsp+0x90], xmm10
00007ff1409d88a9  vmovaps [rsp+0xA0], xmm11
00007ff1409d88b2  vmovaps [rsp+0xB0], xmm12
00007ff1409d88bb  vmovaps [rsp+0xC0], xmm13
00007ff1409d88c4  vmovaps [rsp+0xD0], xmm14
00007ff1409d88cd  vmovaps [rsp+0xE0], xmm15
00007ff1409d88d6  sub rsp, 0x30
00007ff1409d88da  movaps [rsp], xmm1
00007ff1409d88de  movaps [rsp+0x10], xmm7
00007ff1409d88e3  movaps [rsp+0x20], xmm11
00007ff1409d88e9  lea rdi, [rsp]
00007ff1409d88ed  mov esi, 0x00
00007ff1409d88f2  mov rax, 0x565C7F10C530
00007ff1409d88fc  call rax
00007ff1409d88fe  movaps xmm1, [rsp]
00007ff1409d8902  add rsp, 0x30
00007ff1409d8906  vmovaps xmm0, [rsp]
00007ff1409d890b  vmovaps xmm2, [rsp+0x10]
00007ff1409d8911  vmovaps xmm3, [rsp+0x20]
00007ff1409d8917  vmovaps xmm4, [rsp+0x30]
00007ff1409d891d  vmovaps xmm5, [rsp+0x40]
00007ff1409d8923  vmovaps xmm6, [rsp+0x50]
00007ff1409d8929  vmovaps xmm7, [rsp+0x60]
00007ff1409d892f  vmovaps xmm8, [rsp+0x70]
00007ff1409d8935  vmovaps xmm9, [rsp+0x80]
00007ff1409d893e  vmovaps xmm10, [rsp+0x90]
00007ff1409d8947  vmovaps xmm11, [rsp+0xA0]
00007ff1409d8950  vmovaps xmm12, [rsp+0xB0]
00007ff1409d8959  vmovaps xmm13, [rsp+0xC0]
00007ff1409d8962  vmovaps xmm14, [rsp+0xD0]
00007ff1409d896b  vmovaps xmm15, [rsp+0xE0]
00007ff1409d8974  add rsp, 0xF0
00007ff1409d897b  pop r11
00007ff1409d897d  pop r10
00007ff1409d897f  pop r9
00007ff1409d8981  pop r8
00007ff1409d8983  pop rsi
00007ff1409d8984  pop rdi
00007ff1409d8985  pop rdx
00007ff1409d8986  pop rcx
00007ff1409d8987  pop rax
00007ff1409d8988  add rsp, 0x08
00007ff1409d898c  jmp 0x00007FF1409D3576
00007ff1409d8991  call 0x00007FF14080D600
00007ff1409d8996  jmp 0x00007FF1409D3589
00007ff1409d899b  call 0x00007FF14080C380
00007ff1409d89a0  jmp 0x00007FF1409D3594
00007ff1409d89a5  call 0x00007FF14080E880
00007ff1409d89aa  jmp 0x00007FF1409D359F
00007ff1409d89af  call 0x00007FF1407FF540
00007ff1409d89b4  jmp 0x00007FF1409D35AA
00007ff1409d89b9  int3
00007ff1409d89ba  nop [rax+rax*1], ax
00007ff1409d89c0  mov rax, [r15+0x40]
00007ff1409d89c4  mov r14, [r15+0x58]
00007ff1409d89c8  lea r12, [rax+r14*1]
00007ff1409d89cc  movaps xmm1, [r15+0x1D0]
00007ff1409d89d4  vmovaps [rsp+0x10], xmm1
00007ff1409d89da  vmovaps xmm15, [rsp+0x10]
00007ff1409d89e0  por xmm1, xmm15
00007ff1409d89e5  movaps xmm14, [r15+0x1A0]
00007ff1409d89ed  vmovaps [rsp+0x10], xmm14
00007ff1409d89f3  vmovaps xmm13, [rsp+0x10]
00007ff1409d89f9  por xmm14, xmm13
00007ff1409d89fe  lea rax, [r12+0x30]
00007ff1409d8a03  mov r11, [r13+rax*1]
00007ff1409d8a08  lea rax, [r12+0x38]
00007ff1409d8a0d  mov r10, [r13+rax*1]
00007ff1409d8a12  movq xmm13, r11
00007ff1409d8a17  movq xmm12, r10
00007ff1409d8a1c  movq xmm13, xmm13
00007ff1409d8a21  vmovaps [rsp+0x10], xmm13
00007ff1409d8a27  movq xmm13, xmm13
00007ff1409d8a2c  movaps [r15+0x130], xmm13
00007ff1409d8a34  movq xmm12, xmm12
00007ff1409d8a39  vmovaps [rsp+0x20], xmm12
00007ff1409d8a3f  movq xmm12, xmm12
00007ff1409d8a44  movaps [r15+0x280], xmm12
00007ff1409d8a4c  movaps xmm13, [r15+0x270]
00007ff1409d8a54  vmovaps [rsp+0x30], xmm13
00007ff1409d8a5a  vmovaps xmm12, [rsp+0x30]
00007ff1409d8a60  por xmm13, xmm12
00007ff1409d8a65  lea rax, [r12+0x20]
00007ff1409d8a6a  mov r11, [r13+rax*1]
00007ff1409d8a6f  lea rax, [r12+0x28]
00007ff1409d8a74  mov r10, [r13+rax*1]
00007ff1409d8a79  movq xmm12, r11
00007ff1409d8a7e  movq xmm11, r10
00007ff1409d8a83  movq xmm12, xmm12
00007ff1409d8a88  vmovaps [rsp+0x30], xmm12
00007ff1409d8a8e  movq xmm12, xmm12
00007ff1409d8a93  movaps [r15+0x150], xmm12
00007ff1409d8a9b  movq xmm11, xmm11
00007ff1409d8aa0  vmovaps [rsp+0x40], xmm11
00007ff1409d8aa6  movq xmm11, xmm11
00007ff1409d8aab  movaps [r15+0x140], xmm11
00007ff1409d8ab3  lea rax, [r12+0x10]
00007ff1409d8ab8  mov r11, [r13+rax*1]
00007ff1409d8abd  lea rax, [r12+0x18]
00007ff1409d8ac2  mov r10, [r13+rax*1]
00007ff1409d8ac7  movq xmm12, r11
00007ff1409d8acc  movq xmm11, r10
00007ff1409d8ad1  movq xmm12, xmm12
00007ff1409d8ad6  vmovaps [rsp+0x50], xmm12
00007ff1409d8adc  movq xmm12, xmm12
00007ff1409d8ae1  movaps [r15+0x170], xmm12
00007ff1409d8ae9  movq xmm11, xmm11
00007ff1409d8aee  vmovaps [rsp+0x60], xmm11
00007ff1409d8af4  movq xmm11, xmm11
00007ff1409d8af9  movaps [r15+0x160], xmm11
00007ff1409d8b01  mov rax, [r13+r12*1]
00007ff1409d8b06  vmovq xmm12, rax
00007ff1409d8b0b  vpbroadcastq xmm12, xmm12
00007ff1409d8b10  lea rax, [r12+0x08]
00007ff1409d8b15  mov r12, [r13+rax*1]
00007ff1409d8b1a  movq xmm11, r12
00007ff1409d8b1f  movaps [r15+0x230], xmm11
00007ff1409d8b27  mov rax, [r15+0xF8]
00007ff1409d8b2e  lea r12, [rax+0x50]
00007ff1409d8b32  movups xmm11, [r13+r12*1]
00007ff1409d8b38  lea r12, [rax+0x60]
00007ff1409d8b3c  movups xmm10, [r13+r12*1]
00007ff1409d8b42  lea r12, [rax+0x30]
00007ff1409d8b46  movups xmm9, [r13+r12*1]
00007ff1409d8b4c  mov r12, [r15+0x50]
00007ff1409d8b50  lea r11, [r12+r14*1]
00007ff1409d8b54  mov [r15+0x60], r11
00007ff1409d8b58  lea r12, [r14+0x40]
00007ff1409d8b5c  mov [r15+0x58], r12
00007ff1409d8b60  movaps xmm8, xmm12
00007ff1409d8b64  mulpd xmm8, xmm15
00007ff1409d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007ff1409d8b6f  ptest xmm7, xmm7
00007ff1409d8b74  jnz 0x00007FF1409D9997
00007ff1409d8b7a  movq xmm15, qword ptr [r15+0x230]
00007ff1409d8b83  vmovaps [rsp+0x70], xmm15
00007ff1409d8b89  vpermilpd xmm15, xmm15, 0x00
00007ff1409d8b8f  movaps xmm7, xmm9
00007ff1409d8b93  mulpd xmm7, xmm15
00007ff1409d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007ff1409d8b9d  ptest xmm6, xmm6
00007ff1409d8ba2  jnz 0x00007FF1409D9ADB
00007ff1409d8ba8  vxorps xmm15, xmm15, xmm15
00007ff1409d8bad  vpbroadcastq xmm15, xmm15
00007ff1409d8bb2  movaps xmm9, xmm12
00007ff1409d8bb6  mulpd xmm9, xmm10
00007ff1409d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007ff1409d8bc1  ptest xmm6, xmm6
00007ff1409d8bc6  jnz 0x00007FF1409D9C1D
00007ff1409d8bcc  movaps xmm10, xmm12
00007ff1409d8bd0  mulpd xmm10, xmm11
00007ff1409d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007ff1409d8bdb  ptest xmm6, xmm6
00007ff1409d8be0  jnz 0x00007FF1409D9D61
00007ff1409d8be6  movaps xmm11, [r15+0x1F0]
00007ff1409d8bee  movaps xmm6, xmm12
00007ff1409d8bf2  mulpd xmm6, xmm11
00007ff1409d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007ff1409d8bfc  ptest xmm5, xmm5
00007ff1409d8c01  jnz 0x00007FF1409D9EA5
00007ff1409d8c07  movaps xmm12, [r15+0x2A0]
00007ff1409d8c0f  vmovaps [rsp+0x80], xmm12
00007ff1409d8c18  vmovaps xmm11, [rsp+0x80]
00007ff1409d8c21  por xmm12, xmm11
00007ff1409d8c26  movaps xmm11, [r15+0x250]
00007ff1409d8c2e  vmovaps [rsp+0x80], xmm11
00007ff1409d8c37  vmovaps xmm5, [rsp+0x80]
00007ff1409d8c40  por xmm11, xmm5
00007ff1409d8c45  vmovaps xmm4, [rsp+0x70]
00007ff1409d8c4b  vpermilpd xmm4, xmm4, 0x00
00007ff1409d8c51  movaps xmm3, xmm5
00007ff1409d8c54  mulpd xmm3, xmm4
00007ff1409d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007ff1409d8c5d  ptest xmm2, xmm2
00007ff1409d8c62  jnz 0x00007FF1409D9FE7
00007ff1409d8c68  mov [rsp+0x80], rax
00007ff1409d8c70  xor eax, eax
00007ff1409d8c72  mov r14d, 0x200
00007ff1409d8c78  cmp r12, r14
00007ff1409d8c7b  cmc
00007ff1409d8c7c  lahf
00007ff1409d8c7d  seto al
00007ff1409d8c80  mov [r15+0x108], eax
00007ff1409d8c87  movaps xmm5, xmm8
00007ff1409d8c8b  addpd xmm5, xmm15
00007ff1409d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007ff1409d8c95  ptest xmm4, xmm4
00007ff1409d8c9a  jnz 0x00007FF1409DA127
00007ff1409d8ca0  movaps xmm8, [r15+0x1B0]
00007ff1409d8ca8  movaps xmm4, xmm9
00007ff1409d8cac  addpd xmm4, xmm8
00007ff1409d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007ff1409d8cb6  ptest xmm2, xmm2
00007ff1409d8cbb  jnz 0x00007FF1409DA269
00007ff1409d8cc1  movaps xmm9, xmm10
00007ff1409d8cc5  addpd xmm9, xmm8
00007ff1409d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007ff1409d8cd0  ptest xmm2, xmm2
00007ff1409d8cd5  jnz 0x00007FF1409DA3AB
00007ff1409d8cdb  movaps xmm10, [r15+0x2F0]
00007ff1409d8ce3  vmovaps [rsp+0x90], xmm10
00007ff1409d8cec  vmovaps xmm8, [rsp+0x90]
00007ff1409d8cf5  por xmm10, xmm8
00007ff1409d8cfa  movaps xmm8, [r15+0x2E0]
00007ff1409d8d02  vmovaps [rsp+0x90], xmm8
00007ff1409d8d0b  vmovaps xmm2, [rsp+0x90]
00007ff1409d8d14  por xmm8, xmm2
00007ff1409d8d19  movaps xmm2, [r15+0x2D0]
00007ff1409d8d21  vmovaps [rsp+0x90], xmm2
00007ff1409d8d2a  vmovaps [rsp+0xA0], xmm1
00007ff1409d8d33  vmovaps xmm1, [rsp+0x90]
00007ff1409d8d3c  por xmm2, xmm1
00007ff1409d8d40  movaps xmm1, [r15+0x200]
00007ff1409d8d48  vmovaps [rsp+0x90], xmm1
00007ff1409d8d51  vmovaps [rsp+0xB0], xmm15
00007ff1409d8d5a  vmovaps xmm15, [rsp+0x90]
00007ff1409d8d63  por xmm1, xmm15
00007ff1409d8d68  movaps xmm15, [r15+0x1C0]
00007ff1409d8d70  vmovaps [rsp+0x90], xmm15
00007ff1409d8d79  vmovaps [rsp+0xC0], xmm1
00007ff1409d8d82  vmovaps xmm1, [rsp+0x90]
00007ff1409d8d8b  por xmm15, xmm1
00007ff1409d8d90  movaps xmm1, [r15+0x190]
00007ff1409d8d98  vmovaps [rsp+0x90], xmm1
00007ff1409d8da1  vmovaps [rsp+0xD0], xmm15
00007ff1409d8daa  vmovaps xmm15, [rsp+0x90]
00007ff1409d8db3  por xmm1, xmm15
00007ff1409d8db8  movaps xmm15, [r15+0x300]
00007ff1409d8dc0  vmovaps [rsp+0x90], xmm15
00007ff1409d8dc9  vmovaps [rsp+0xE0], xmm1
00007ff1409d8dd2  vmovaps xmm1, [rsp+0x90]
00007ff1409d8ddb  por xmm15, xmm1
00007ff1409d8de0  mov rax, [rsp+0x80]
00007ff1409d8de8  lea r14, [rax+0xA0]
00007ff1409d8def  movups xmm1, [r13+r14*1]
00007ff1409d8df5  lea r14, [rax+0xB0]
00007ff1409d8dfc  vmovaps [rsp+0x80], xmm1
00007ff1409d8e05  movups xmm1, [r13+r14*1]
00007ff1409d8e0b  vmovaps [rsp+0x90], xmm1
00007ff1409d8e14  vmovaps [rsp+0xF0], xmm15
00007ff1409d8e1d  vmovaps xmm15, [rsp+0xB0]
00007ff1409d8e26  vmovaps [rsp+0xB0], xmm14
00007ff1409d8e2f  movaps xmm1, xmm6
00007ff1409d8e32  addpd xmm1, xmm15
00007ff1409d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007ff1409d8e3c  ptest xmm14, xmm14
00007ff1409d8e42  jnz 0x00007FF1409DA503
00007ff1409d8e48  lea r14, [rax+0xF0]
00007ff1409d8e4f  movups xmm15, [r13+r14*1]
00007ff1409d8e55  movaps xmm14, xmm4
00007ff1409d8e59  addpd xmm14, xmm3
00007ff1409d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007ff1409d8e64  ptest xmm6, xmm6
00007ff1409d8e69  jnz 0x00007FF1409DA64E
00007ff1409d8e6f  movaps xmm6, xmm9
00007ff1409d8e73  addpd xmm6, xmm7
00007ff1409d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007ff1409d8e7c  ptest xmm4, xmm4
00007ff1409d8e81  jnz 0x00007FF1409DA790
00007ff1409d8e87  vmovaps xmm9, [rsp+0x70]
00007ff1409d8e8d  vpermilpd xmm9, xmm9, 0x00
00007ff1409d8e93  vmovaps xmm4, [rsp+0x90]
00007ff1409d8e9c  movaps xmm7, xmm4
00007ff1409d8e9f  mulpd xmm7, xmm9
00007ff1409d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007ff1409d8ea9  ptest xmm3, xmm3
00007ff1409d8eae  jnz 0x00007FF1409DA8D1
00007ff1409d8eb4  vmovaps xmm9, [rsp+0x50]
00007ff1409d8eba  vpermilpd xmm9, xmm9, 0x00
00007ff1409d8ec0  movaps xmm4, xmm15
00007ff1409d8ec4  mulpd xmm4, xmm9
00007ff1409d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007ff1409d8ece  ptest xmm3, xmm3
00007ff1409d8ed3  jnz 0x00007FF1409DAA12
00007ff1409d8ed9  lea r14, [rax+0xE0]
00007ff1409d8ee0  movups xmm15, [r13+r14*1]
00007ff1409d8ee6  vmovaps xmm9, [rsp+0x70]
00007ff1409d8eec  vpermilpd xmm9, xmm9, 0x00
00007ff1409d8ef2  vmovaps [rsp+0x70], xmm1
00007ff1409d8ef8  vmovaps xmm1, [rsp+0x80]
00007ff1409d8f01  vmovaps [rsp+0x80], xmm15
00007ff1409d8f0a  movaps xmm3, xmm1
00007ff1409d8f0d  mulpd xmm3, xmm9
00007ff1409d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007ff1409d8f17  ptest xmm15, xmm15
00007ff1409d8f1d  jnz 0x00007FF1409DAB5E
00007ff1409d8f23  vmovaps xmm1, [rsp+0xF0]
00007ff1409d8f2c  vmovaps xmm15, [rsp+0xF0]
00007ff1409d8f35  por xmm1, xmm15
00007ff1409d8f3a  movaps [r15+0x300], xmm1
00007ff1409d8f42  vmovaps xmm15, [rsp+0xE0]
00007ff1409d8f4b  vmovaps xmm9, [rsp+0xE0]
00007ff1409d8f54  por xmm15, xmm9
00007ff1409d8f59  movaps [r15+0x190], xmm15
00007ff1409d8f61  vmovaps xmm9, [rsp+0x50]
00007ff1409d8f67  vpermilpd xmm9, xmm9, 0x00
00007ff1409d8f6d  vmovaps [rsp+0x90], xmm1
00007ff1409d8f76  vmovaps [rsp+0xE0], xmm15
00007ff1409d8f7f  vmovaps xmm15, [rsp+0x80]
00007ff1409d8f88  vmovaps [rsp+0x80], xmm14
00007ff1409d8f91  movaps xmm1, xmm15
00007ff1409d8f95  mulpd xmm1, xmm9
00007ff1409d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007ff1409d8f9f  ptest xmm14, xmm14
00007ff1409d8fa5  jnz 0x00007FF1409DAC9F
00007ff1409d8fab  lea r14, [rax+0x90]
00007ff1409d8fb2  movups xmm15, [r13+r14*1]
00007ff1409d8fb8  vmovaps xmm14, [rsp+0xD0]
00007ff1409d8fc1  vmovaps xmm9, [rsp+0xD0]
00007ff1409d8fca  por xmm14, xmm9
00007ff1409d8fcf  movaps [r15+0x1C0], xmm14
00007ff1409d8fd7  vmovaps xmm9, [rsp+0xC0]
00007ff1409d8fe0  vmovaps [rsp+0xD0], xmm1
00007ff1409d8fe9  vmovaps xmm1, [rsp+0xC0]
00007ff1409d8ff2  por xmm9, xmm1
00007ff1409d8ff7  movaps [r15+0x200], xmm9
00007ff1409d8fff  vmovaps [rsp+0xC0], xmm2
00007ff1409d9008  vmovaps xmm1, [rsp+0xC0]
00007ff1409d9011  por xmm2, xmm1
00007ff1409d9015  movaps [r15+0x2D0], xmm2
00007ff1409d901d  vmovaps [rsp+0xC0], xmm8
00007ff1409d9026  vmovaps xmm1, [rsp+0xC0]
00007ff1409d902f  por xmm8, xmm1
00007ff1409d9034  movaps [r15+0x2E0], xmm8
00007ff1409d903c  vmovaps [rsp+0xC0], xmm15
00007ff1409d9045  movaps xmm1, xmm5
00007ff1409d9048  addpd xmm1, xmm7
00007ff1409d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007ff1409d9051  ptest xmm15, xmm15
00007ff1409d9057  jnz 0x00007FF1409DADEB
00007ff1409d905d  vmovaps xmm15, [rsp+0x50]
00007ff1409d9063  vpermilpd xmm15, xmm15, 0x00
00007ff1409d9069  vmovaps xmm5, [rsp+0xC0]
00007ff1409d9072  vmovaps [rsp+0xC0], xmm1
00007ff1409d907b  movaps xmm7, xmm5
00007ff1409d907e  mulpd xmm7, xmm15
00007ff1409d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007ff1409d9088  ptest xmm1, xmm1
00007ff1409d908d  jnz 0x00007FF1409DAF2B
00007ff1409d9093  lea r14, [rax+0x80]
00007ff1409d909a  movups xmm1, [r13+r14*1]
00007ff1409d90a0  vmovaps xmm5, [rsp+0x70]
00007ff1409d90a6  vmovaps [rsp+0x70], xmm1
00007ff1409d90ac  movaps xmm15, xmm5
00007ff1409d90b0  addpd xmm15, xmm3
00007ff1409d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007ff1409d90bb  ptest xmm1, xmm1
00007ff1409d90c0  jnz 0x00007FF1409DB076
00007ff1409d90c6  vmovaps xmm5, [rsp+0x80]
00007ff1409d90cf  movaps xmm1, xmm5
00007ff1409d90d2  addpd xmm1, xmm4
00007ff1409d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007ff1409d90db  ptest xmm3, xmm3
00007ff1409d90e0  jnz 0x00007FF1409DB1B8
00007ff1409d90e6  vmovaps [rsp+0x80], xmm10
00007ff1409d90ef  vmovaps xmm5, [rsp+0x80]
00007ff1409d90f8  por xmm10, xmm5
00007ff1409d90fd  movaps [r15+0x2F0], xmm10
00007ff1409d9105  vmovaps xmm5, [rsp+0x50]
00007ff1409d910b  vpermilpd xmm5, xmm5, 0x00
00007ff1409d9111  vmovaps xmm3, [rsp+0x70]
00007ff1409d9117  vmovaps [rsp+0x50], xmm1
00007ff1409d911d  movaps xmm4, xmm3
00007ff1409d9120  mulpd xmm4, xmm5
00007ff1409d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007ff1409d9129  ptest xmm1, xmm1
00007ff1409d912e  jnz 0x00007FF1409DB2F8
00007ff1409d9134  lea r14, [rax+0xD0]
00007ff1409d913b  movups xmm1, [r13+r14*1]
00007ff1409d9141  vmovaps xmm3, [rsp+0xD0]
00007ff1409d914a  vmovaps [rsp+0x70], xmm1
00007ff1409d9150  movaps xmm5, xmm6
00007ff1409d9153  addpd xmm5, xmm3
00007ff1409d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007ff1409d915c  ptest xmm1, xmm1
00007ff1409d9161  jnz 0x00007FF1409DB442
00007ff1409d9167  vmovaps xmm1, [rsp+0x60]
00007ff1409d916d  vpermilpd xmm1, xmm1, 0x00
00007ff1409d9173  movaps xmm6, xmm9
00007ff1409d9177  mulpd xmm6, xmm1
00007ff1409d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007ff1409d9180  ptest xmm3, xmm3
00007ff1409d9185  jnz 0x00007FF1409DB582
00007ff1409d918b  movaps [r15+0x260], xmm6
00007ff1409d9193  vxorps xmm1, xmm1, xmm1
00007ff1409d9197  vpbroadcastq xmm1, xmm1
00007ff1409d919c  movaps [r15+0x1B0], xmm1
00007ff1409d91a4  vmovaps xmm1, [rsp+0x60]
00007ff1409d91aa  vpermilpd xmm1, xmm1, 0x00
00007ff1409d91b0  vmovaps xmm3, [rsp+0x70]
00007ff1409d91b6  vmovaps [rsp+0x70], xmm15
00007ff1409d91bc  movaps xmm9, xmm3
00007ff1409d91c0  mulpd xmm9, xmm1
00007ff1409d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007ff1409d91cb  ptest xmm15, xmm15
00007ff1409d91d1  jnz 0x00007FF1409DB6C3
00007ff1409d91d7  lea r14, [rax+0xC0]
00007ff1409d91de  movups xmm1, [r13+r14*1]
00007ff1409d91e4  vmovaps xmm3, [rsp+0xC0]
00007ff1409d91ed  vmovaps [rsp+0x80], xmm1
00007ff1409d91f6  movaps xmm15, xmm3
00007ff1409d91fa  addpd xmm15, xmm7
00007ff1409d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007ff1409d9205  ptest xmm1, xmm1
00007ff1409d920a  jnz 0x00007FF1409DB80F
00007ff1409d9210  vmovaps [rsp+0xC0], xmm13
00007ff1409d9219  vmovaps xmm1, [rsp+0xC0]
00007ff1409d9222  por xmm13, xmm1
00007ff1409d9227  movaps [r15+0x270], xmm13
00007ff1409d922f  vmovaps xmm1, [rsp+0xB0]
00007ff1409d9238  vmovaps xmm7, [rsp+0xB0]
00007ff1409d9241  por xmm1, xmm7
00007ff1409d9245  movaps [r15+0x1A0], xmm1
00007ff1409d924d  vmovaps xmm1, [rsp+0x60]
00007ff1409d9253  vpermilpd xmm1, xmm1, 0x00
00007ff1409d9259  vmovaps [rsp+0xB0], xmm1
00007ff1409d9262  vmovaps xmm1, [rsp+0x80]
00007ff1409d926b  vmovaps [rsp+0x80], xmm15
00007ff1409d9274  vmovaps xmm15, [rsp+0xB0]
00007ff1409d927d  vmovaps [rsp+0xB0], xmm14
00007ff1409d9286  movaps xmm3, xmm1
00007ff1409d9289  mulpd xmm3, xmm15
00007ff1409d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007ff1409d9293  ptest xmm14, xmm14
00007ff1409d9299  jnz 0x00007FF1409DB951
00007ff1409d929f  lea r14, [rax+0x20]
00007ff1409d92a3  movups xmm1, [r13+r14*1]
00007ff1409d92a9  movaps [r15+0x110], xmm1
00007ff1409d92b1  vmovaps xmm14, [rsp+0x70]
00007ff1409d92b7  vmovaps [rsp+0x70], xmm1
00007ff1409d92bd  movaps xmm15, xmm14
00007ff1409d92c1  addpd xmm15, xmm4
00007ff1409d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007ff1409d92cc  ptest xmm1, xmm1
00007ff1409d92d1  jnz 0x00007FF1409DBA9C
00007ff1409d92d7  vmovaps xmm1, [rsp+0x60]
00007ff1409d92dd  vpermilpd xmm1, xmm1, 0x00
00007ff1409d92e3  movaps xmm14, xmm2
00007ff1409d92e7  mulpd xmm14, xmm1
00007ff1409d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007ff1409d92f2  ptest xmm4, xmm4
00007ff1409d92f7  jnz 0x00007FF1409DBBDF
00007ff1409d92fd  vmovaps xmm4, [rsp+0x50]
00007ff1409d9303  movaps xmm1, xmm4
00007ff1409d9306  addpd xmm1, xmm9
00007ff1409d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007ff1409d9310  ptest xmm2, xmm2
00007ff1409d9315  jnz 0x00007FF1409DBD21
00007ff1409d931b  vmovaps xmm9, [rsp+0x30]
00007ff1409d9321  vpermilpd xmm9, xmm9, 0x00
00007ff1409d9327  vmovaps xmm2, [rsp+0x70]
00007ff1409d932d  vmovaps [rsp+0x50], xmm1
00007ff1409d9333  movaps xmm4, xmm2
00007ff1409d9336  mulpd xmm4, xmm9
00007ff1409d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007ff1409d9340  ptest xmm1, xmm1
00007ff1409d9345  jnz 0x00007FF1409DBE62
00007ff1409d934b  vmovaps xmm1, [rsp+0x30]
00007ff1409d9351  vpermilpd xmm1, xmm1, 0x00
00007ff1409d9357  vmovaps xmm2, [rsp+0x90]
00007ff1409d9360  vmovaps [rsp+0x60], xmm15
00007ff1409d9366  movaps xmm9, xmm2
00007ff1409d936a  mulpd xmm9, xmm1
00007ff1409d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007ff1409d9375  ptest xmm15, xmm15
00007ff1409d937b  jnz 0x00007FF1409DBFA3
00007ff1409d9381  vmovaps xmm15, [rsp+0x80]
00007ff1409d938a  movaps xmm1, xmm15
00007ff1409d938e  addpd xmm1, xmm6
00007ff1409d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007ff1409d9397  ptest xmm2, xmm2
00007ff1409d939c  jnz 0x00007FF1409DC0E5
00007ff1409d93a2  movaps xmm15, xmm5
00007ff1409d93a6  addpd xmm15, xmm3
00007ff1409d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007ff1409d93b1  ptest xmm6, xmm6
00007ff1409d93b6  jnz 0x00007FF1409DC226
00007ff1409d93bc  vmovaps xmm6, [rsp+0x30]
00007ff1409d93c2  vpermilpd xmm6, xmm6, 0x00
00007ff1409d93c8  movaps xmm5, xmm8
00007ff1409d93cc  mulpd xmm5, xmm6
00007ff1409d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007ff1409d93d5  ptest xmm3, xmm3
00007ff1409d93da  jnz 0x00007FF1409DC368
00007ff1409d93e0  vmovaps xmm8, [rsp+0x30]
00007ff1409d93e6  vpermilpd xmm8, xmm8, 0x00
00007ff1409d93ec  movaps xmm6, xmm10
00007ff1409d93f0  mulpd xmm6, xmm8
00007ff1409d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007ff1409d93fa  ptest xmm3, xmm3
00007ff1409d93ff  jnz 0x00007FF1409DC4A9
00007ff1409d9405  vmovaps xmm8, [rsp+0x60]
00007ff1409d940b  movaps xmm10, xmm8
00007ff1409d940f  addpd xmm10, xmm14
00007ff1409d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007ff1409d941a  ptest xmm3, xmm3
00007ff1409d941f  jnz 0x00007FF1409DC5EB
00007ff1409d9425  vmovaps xmm8, [rsp+0x50]
00007ff1409d942b  movaps xmm14, xmm8
00007ff1409d942f  addpd xmm14, xmm4
00007ff1409d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007ff1409d943a  ptest xmm3, xmm3
00007ff1409d943f  jnz 0x00007FF1409DC72F
00007ff1409d9445  vmovaps xmm8, [rsp+0x40]
00007ff1409d944b  vpermilpd xmm8, xmm8, 0x00
00007ff1409d9451  movaps xmm4, xmm13
00007ff1409d9455  mulpd xmm4, xmm8
00007ff1409d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007ff1409d945f  ptest xmm3, xmm3
00007ff1409d9464  jnz 0x00007FF1409DC872
00007ff1409d946a  movaps xmm13, xmm15
00007ff1409d946e  addpd xmm13, xmm9
00007ff1409d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007ff1409d9479  ptest xmm8, xmm8
00007ff1409d947f  jnz 0x00007FF1409DC9B4
00007ff1409d9485  movaps xmm15, xmm1
00007ff1409d9489  addpd xmm15, xmm5
00007ff1409d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007ff1409d9494  ptest xmm9, xmm9
00007ff1409d949a  jnz 0x00007FF1409DCAF8
00007ff1409d94a0  vmovaps [rsp+0x30], xmm11
00007ff1409d94a6  vmovaps xmm1, [rsp+0x30]
00007ff1409d94ac  por xmm11, xmm1
00007ff1409d94b1  movaps [r15+0x250], xmm11
00007ff1409d94b9  vmovaps [rsp+0x30], xmm12
00007ff1409d94bf  vmovaps xmm1, [rsp+0x30]
00007ff1409d94c5  por xmm12, xmm1
00007ff1409d94ca  movaps [r15+0x2A0], xmm12
00007ff1409d94d2  vmovaps xmm1, [rsp+0xA0]
00007ff1409d94db  vmovaps xmm11, [rsp+0xA0]
00007ff1409d94e4  por xmm1, xmm11
00007ff1409d94e9  movaps [r15+0x1D0], xmm1
00007ff1409d94f1  lea r14, [rax+0x40]
00007ff1409d94f5  movups xmm1, [r13+r14*1]
00007ff1409d94fb  movaps [r15+0x2C0], xmm1
00007ff1409d9503  vmovaps xmm11, [rsp+0x40]
00007ff1409d9509  vpermilpd xmm11, xmm11, 0x00
00007ff1409d950f  vmovaps xmm8, [rsp+0xE0]
00007ff1409d9518  movaps xmm9, xmm8
00007ff1409d951c  mulpd xmm9, xmm11
00007ff1409d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007ff1409d9527  ptest xmm5, xmm5
00007ff1409d952c  jnz 0x00007FF1409DCC44
00007ff1409d9532  movaps xmm11, xmm10
00007ff1409d9536  addpd xmm11, xmm6
00007ff1409d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007ff1409d9541  ptest xmm8, xmm8
00007ff1409d9547  jnz 0x00007FF1409DCD88
00007ff1409d954d  movaps xmm10, xmm14
00007ff1409d9551  addpd xmm10, xmm4
00007ff1409d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007ff1409d955c  ptest xmm8, xmm8
00007ff1409d9562  jnz 0x00007FF1409DCECB
00007ff1409d9568  vmovaps xmm14, [rsp+0x40]
00007ff1409d956e  vpermilpd xmm14, xmm14, 0x00
00007ff1409d9574  movaps xmm8, xmm1
00007ff1409d9578  mulpd xmm8, xmm14
00007ff1409d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007ff1409d9583  ptest xmm6, xmm6
00007ff1409d9588  jnz 0x00007FF1409DD00E
00007ff1409d958e  movaps xmm1, [r15+0x2B0]
00007ff1409d9596  vmovaps xmm14, [rsp+0x40]
00007ff1409d959c  vpermilpd xmm14, xmm14, 0x00
00007ff1409d95a2  movaps xmm6, xmm1
00007ff1409d95a5  mulpd xmm6, xmm14
00007ff1409d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007ff1409d95af  ptest xmm5, xmm5
00007ff1409d95b4  jnz 0x00007FF1409DD151
00007ff1409d95ba  vmovaps xmm1, [rsp+0x10]
00007ff1409d95c0  vpermilpd xmm1, xmm1, 0x00
00007ff1409d95c6  movaps xmm14, xmm12
00007ff1409d95ca  mulpd xmm14, xmm1
00007ff1409d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007ff1409d95d5  ptest xmm5, xmm5
00007ff1409d95da  jnz 0x00007FF1409DD292
00007ff1409d95e0  movaps xmm1, xmm13
00007ff1409d95e4  addpd xmm1, xmm9
00007ff1409d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007ff1409d95ee  ptest xmm12, xmm12
00007ff1409d95f4  jnz 0x00007FF1409DD3D5
00007ff1409d95fa  vmovaps xmm13, [rsp+0x10]
00007ff1409d9600  vpermilpd xmm13, xmm13, 0x00
00007ff1409d9606  movaps xmm12, xmm7
00007ff1409d960a  mulpd xmm12, xmm13
00007ff1409d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007ff1409d9615  ptest xmm9, xmm9
00007ff1409d961b  jnz 0x00007FF1409DD517
00007ff1409d9621  movaps xmm13, xmm15
00007ff1409d9625  addpd xmm13, xmm8
00007ff1409d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007ff1409d9630  ptest xmm9, xmm9
00007ff1409d9636  jnz 0x00007FF1409DD65A
00007ff1409d963c  movaps xmm15, [r15+0x290]
00007ff1409d9644  vmovaps xmm9, [rsp+0x10]
00007ff1409d964a  vpermilpd xmm9, xmm9, 0x00
00007ff1409d9650  movaps xmm8, xmm15
00007ff1409d9654  mulpd xmm8, xmm9
00007ff1409d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007ff1409d965f  ptest xmm7, xmm7
00007ff1409d9664  jnz 0x00007FF1409DD79E
00007ff1409d966a  movaps xmm15, xmm11
00007ff1409d966e  addpd xmm15, xmm6
00007ff1409d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007ff1409d9679  ptest xmm9, xmm9
00007ff1409d967f  jnz 0x00007FF1409DD8E2
00007ff1409d9685  movaps xmm11, [r15+0x1E0]
00007ff1409d968d  vmovaps xmm9, [rsp+0x10]
00007ff1409d9693  vpermilpd xmm9, xmm9, 0x00
00007ff1409d9699  movaps xmm7, xmm11
00007ff1409d969d  mulpd xmm7, xmm9
00007ff1409d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007ff1409d96a7  ptest xmm6, xmm6
00007ff1409d96ac  jnz 0x00007FF1409DDA25
00007ff1409d96b2  movaps xmm11, xmm10
00007ff1409d96b6  addpd xmm11, xmm14
00007ff1409d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007ff1409d96c1  ptest xmm9, xmm9
00007ff1409d96c7  jnz 0x00007FF1409DDB67
00007ff1409d96cd  lea r14, [rax+0x70]
00007ff1409d96d1  movups xmm14, [r13+r14*1]
00007ff1409d96d7  movaps [r15+0x240], xmm14
00007ff1409d96df  movaps xmm10, xmm1
00007ff1409d96e3  addpd xmm10, xmm12
00007ff1409d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007ff1409d96ee  ptest xmm9, xmm9
00007ff1409d96f4  jnz 0x00007FF1409DDCB5
00007ff1409d96fa  movaps [r15+0x170], xmm10
00007ff1409d9702  vmovaps xmm1, [rsp+0x20]
00007ff1409d9708  vpermilpd xmm1, xmm1, 0x00
00007ff1409d970e  movaps xmm12, xmm14
00007ff1409d9712  mulpd xmm12, xmm1
00007ff1409d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007ff1409d971d  ptest xmm9, xmm9
00007ff1409d9723  jnz 0x00007FF1409DDDF8
00007ff1409d9729  vmovaps xmm1, [rsp+0x20]
00007ff1409d972f  vpermilpd xmm1, xmm1, 0x00
00007ff1409d9735  vmovaps xmm9, [rsp+0xB0]
00007ff1409d973e  movaps xmm14, xmm9
00007ff1409d9742  mulpd xmm14, xmm1
00007ff1409d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007ff1409d974d  ptest xmm6, xmm6
00007ff1409d9752  jnz 0x00007FF1409DDF3B
00007ff1409d9758  movaps [r15+0x180], xmm14
00007ff1409d9760  movaps xmm1, xmm13
00007ff1409d9764  addpd xmm1, xmm8
00007ff1409d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007ff1409d976e  ptest xmm9, xmm9
00007ff1409d9774  jnz 0x00007FF1409DE07E
00007ff1409d977a  movaps [r15+0x210], xmm1
00007ff1409d9782  movups xmm13, [r13+rax*1]
00007ff1409d9788  lea r14, [rax+0x10]
00007ff1409d978c  movups xmm9, [r13+r14*1]
00007ff1409d9792  movaps [r15+0x230], xmm9
00007ff1409d979a  movaps xmm8, xmm15
00007ff1409d979e  addpd xmm8, xmm7
00007ff1409d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007ff1409d97a9  ptest xmm6, xmm6
00007ff1409d97ae  jnz 0x00007FF1409DE1D4
00007ff1409d97b4  movaps [r15+0x130], xmm8
00007ff1409d97bc  vmovaps xmm15, [rsp+0x20]
00007ff1409d97c2  vpermilpd xmm15, xmm15, 0x00
00007ff1409d97c8  movaps xmm7, xmm9
00007ff1409d97cc  mulpd xmm7, xmm15
00007ff1409d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007ff1409d97d6  ptest xmm6, xmm6
00007ff1409d97db  jnz 0x00007FF1409DE317
00007ff1409d97e1  movaps [r15+0x220], xmm7
00007ff1409d97e9  vmovaps xmm15, [rsp+0x20]
00007ff1409d97ef  vpermilpd xmm15, xmm15, 0x00
00007ff1409d97f5  movaps xmm9, xmm13
00007ff1409d97f9  mulpd xmm9, xmm15
00007ff1409d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007ff1409d9804  ptest xmm6, xmm6
00007ff1409d9809  jnz 0x00007FF1409DE459
00007ff1409d980f  movaps xmm15, xmm11
00007ff1409d9813  addpd xmm15, xmm12
00007ff1409d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007ff1409d981e  ptest xmm13, xmm13
00007ff1409d9824  jnz 0x00007FF1409DE59D
00007ff1409d982a  movaps [r15+0x140], xmm15
00007ff1409d9832  movaps xmm13, xmm10
00007ff1409d9836  addpd xmm13, xmm14
00007ff1409d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007ff1409d9841  ptest xmm12, xmm12
00007ff1409d9847  jnz 0x00007FF1409DE6E1
00007ff1409d984d  movaps [r15+0x150], xmm13
00007ff1409d9855  movaps xmm14, xmm1
00007ff1409d9859  addpd xmm14, xmm7
00007ff1409d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007ff1409d9864  ptest xmm12, xmm12
00007ff1409d986a  jnz 0x00007FF1409DE825
00007ff1409d9870  movaps [r15+0x160], xmm14
00007ff1409d9878  movaps xmm1, xmm8
00007ff1409d987c  addpd xmm1, xmm9
00007ff1409d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007ff1409d9886  ptest xmm12, xmm12
00007ff1409d988c  jnz 0x00007FF1409DE967
00007ff1409d9892  movaps [r15+0x120], xmm1
00007ff1409d989a  movups [r13+r11*1], xmm15
00007ff1409d98a0  lea rax, [r11+0x10]
00007ff1409d98a4  movups [r13+rax*1], xmm13
00007ff1409d98aa  lea rax, [r11+0x20]
00007ff1409d98ae  movups [r13+rax*1], xmm14
00007ff1409d98b4  lea rax, [r11+0x30]
00007ff1409d98b8  movups [r13+rax*1], xmm1
00007ff1409d98be  mov eax, [r15+0x108]
00007ff1409d98c5  sahf
00007ff1409d98c6  jnz 0x00007FF1409D98F8
00007ff1409d98c8  cmp dword ptr [r15+0x318], 0x00
00007ff1409d98d0  jz 0x00007FF1409DEAE0
00007ff1409d98d6  nop [rax+rax*1], ax
00007ff1409d98df  nop [rax+rax*1], eax
00007ff1409d98e7  mov eax, 0x4106D0
00007ff1409d98ec  mov [r15+0x100], rax
00007ff1409d98f3  jmp 0x00007FF1407FE110
00007ff1409d98f8  cmp dword ptr [r15+0x318], 0x00
00007ff1409d9900  jz 0x00007FF1409D89C0
00007ff1409d9906  nop [rax+rax*1], ax
00007ff1409d990f  nop [rax+rax*1], eax
00007ff1409d9917  mov eax, 0x410504
00007ff1409d991c  mov [r15+0x100], rax
00007ff1409d9923  jmp 0x00007FF1407FE110
00007ff1409d9928  int3
00007ff1409d9929  call 0x00007FF14080A4B0
00007ff1409d992e  jmp 0x00007FF1409D8A08
00007ff1409d9933  call 0x00007FF140809240
00007ff1409d9938  jmp 0x00007FF1409D8A12
00007ff1409d993d  call 0x00007FF14080A4B0
00007ff1409d9942  jmp 0x00007FF1409D8A6F
00007ff1409d9947  call 0x00007FF140809240
00007ff1409d994c  jmp 0x00007FF1409D8A79
00007ff1409d9951  call 0x00007FF14080A4B0
00007ff1409d9956  jmp 0x00007FF1409D8ABD
00007ff1409d995b  call 0x00007FF140809240
00007ff1409d9960  jmp 0x00007FF1409D8AC7
00007ff1409d9965  call 0x00007FF1408B47C0
00007ff1409d996a  jmp 0x00007FF1409D8B06
00007ff1409d996f  call 0x00007FF14080B720
00007ff1409d9974  jmp 0x00007FF1409D8B1A
00007ff1409d9979  call 0x00007FF1408BFC30
00007ff1409d997e  jmp 0x00007FF1409D8B38
00007ff1409d9983  call 0x00007FF1408BE9C0
00007ff1409d9988  jmp 0x00007FF1409D8B42
00007ff1409d998d  call 0x00007FF1408BD750
00007ff1409d9992  jmp 0x00007FF1409D8B4C
00007ff1409d9997  sub rsp, 0x08
00007ff1409d999b  push rax
00007ff1409d999c  push rcx
00007ff1409d999d  push rdx
00007ff1409d999e  push rdi
00007ff1409d999f  push rsi
00007ff1409d99a0  push r8
00007ff1409d99a2  push r9
00007ff1409d99a4  push r10
00007ff1409d99a6  push r11
00007ff1409d99a8  sub rsp, 0xF0
00007ff1409d99af  vmovaps [rsp], xmm0
00007ff1409d99b4  vmovaps [rsp+0x10], xmm1
00007ff1409d99ba  vmovaps [rsp+0x20], xmm2
00007ff1409d99c0  vmovaps [rsp+0x30], xmm3
00007ff1409d99c6  vmovaps [rsp+0x40], xmm4
00007ff1409d99cc  vmovaps [rsp+0x50], xmm5
00007ff1409d99d2  vmovaps [rsp+0x60], xmm6
00007ff1409d99d8  vmovaps [rsp+0x70], xmm7
00007ff1409d99de  vmovaps [rsp+0x80], xmm9
00007ff1409d99e7  vmovaps [rsp+0x90], xmm10
00007ff1409d99f0  vmovaps [rsp+0xA0], xmm11
00007ff1409d99f9  vmovaps [rsp+0xB0], xmm12
00007ff1409d9a02  vmovaps [rsp+0xC0], xmm13
00007ff1409d9a0b  vmovaps [rsp+0xD0], xmm14
00007ff1409d9a14  vmovaps [rsp+0xE0], xmm15
00007ff1409d9a1d  sub rsp, 0x30
00007ff1409d9a21  movaps [rsp], xmm8
00007ff1409d9a26  movaps [rsp+0x10], xmm12
00007ff1409d9a2c  movaps [rsp+0x20], xmm15
00007ff1409d9a32  lea rdi, [rsp]
00007ff1409d9a36  mov esi, 0x00
00007ff1409d9a3b  mov rax, 0x565C7F10C530
00007ff1409d9a45  call rax
00007ff1409d9a47  movaps xmm8, [rsp]
00007ff1409d9a4c  add rsp, 0x30
00007ff1409d9a50  vmovaps xmm0, [rsp]
00007ff1409d9a55  vmovaps xmm1, [rsp+0x10]
00007ff1409d9a5b  vmovaps xmm2, [rsp+0x20]
00007ff1409d9a61  vmovaps xmm3, [rsp+0x30]
00007ff1409d9a67  vmovaps xmm4, [rsp+0x40]
00007ff1409d9a6d  vmovaps xmm5, [rsp+0x50]
00007ff1409d9a73  vmovaps xmm6, [rsp+0x60]
00007ff1409d9a79  vmovaps xmm7, [rsp+0x70]
00007ff1409d9a7f  vmovaps xmm9, [rsp+0x80]
00007ff1409d9a88  vmovaps xmm10, [rsp+0x90]
00007ff1409d9a91  vmovaps xmm11, [rsp+0xA0]
00007ff1409d9a9a  vmovaps xmm12, [rsp+0xB0]
00007ff1409d9aa3  vmovaps xmm13, [rsp+0xC0]
00007ff1409d9aac  vmovaps xmm14, [rsp+0xD0]
00007ff1409d9ab5  vmovaps xmm15, [rsp+0xE0]
00007ff1409d9abe  add rsp, 0xF0
00007ff1409d9ac5  pop r11
00007ff1409d9ac7  pop r10
00007ff1409d9ac9  pop r9
00007ff1409d9acb  pop r8
00007ff1409d9acd  pop rsi
00007ff1409d9ace  pop rdi
00007ff1409d9acf  pop rdx
00007ff1409d9ad0  pop rcx
00007ff1409d9ad1  pop rax
00007ff1409d9ad2  add rsp, 0x08
00007ff1409d9ad6  jmp 0x00007FF1409D8B7A
00007ff1409d9adb  sub rsp, 0x08
00007ff1409d9adf  push rax
00007ff1409d9ae0  push rcx
00007ff1409d9ae1  push rdx
00007ff1409d9ae2  push rdi
00007ff1409d9ae3  push rsi
00007ff1409d9ae4  push r8
00007ff1409d9ae6  push r9
00007ff1409d9ae8  push r10
00007ff1409d9aea  push r11
00007ff1409d9aec  sub rsp, 0xF0
00007ff1409d9af3  vmovaps [rsp], xmm0
00007ff1409d9af8  vmovaps [rsp+0x10], xmm1
00007ff1409d9afe  vmovaps [rsp+0x20], xmm2
00007ff1409d9b04  vmovaps [rsp+0x30], xmm3
00007ff1409d9b0a  vmovaps [rsp+0x40], xmm4
00007ff1409d9b10  vmovaps [rsp+0x50], xmm5
00007ff1409d9b16  vmovaps [rsp+0x60], xmm6
00007ff1409d9b1c  vmovaps [rsp+0x70], xmm8
00007ff1409d9b22  vmovaps [rsp+0x80], xmm9
00007ff1409d9b2b  vmovaps [rsp+0x90], xmm10
00007ff1409d9b34  vmovaps [rsp+0xA0], xmm11
00007ff1409d9b3d  vmovaps [rsp+0xB0], xmm12
00007ff1409d9b46  vmovaps [rsp+0xC0], xmm13
00007ff1409d9b4f  vmovaps [rsp+0xD0], xmm14
00007ff1409d9b58  vmovaps [rsp+0xE0], xmm15
00007ff1409d9b61  sub rsp, 0x30
00007ff1409d9b65  movaps [rsp], xmm7
00007ff1409d9b69  movaps [rsp+0x10], xmm9
00007ff1409d9b6f  movaps [rsp+0x20], xmm15
00007ff1409d9b75  lea rdi, [rsp]
00007ff1409d9b79  mov esi, 0x00
00007ff1409d9b7e  mov rax, 0x565C7F10C530
00007ff1409d9b88  call rax
00007ff1409d9b8a  movaps xmm7, [rsp]
00007ff1409d9b8e  add rsp, 0x30
00007ff1409d9b92  vmovaps xmm0, [rsp]
00007ff1409d9b97  vmovaps xmm1, [rsp+0x10]
00007ff1409d9b9d  vmovaps xmm2, [rsp+0x20]
00007ff1409d9ba3  vmovaps xmm3, [rsp+0x30]
00007ff1409d9ba9  vmovaps xmm4, [rsp+0x40]
00007ff1409d9baf  vmovaps xmm5, [rsp+0x50]
00007ff1409d9bb5  vmovaps xmm6, [rsp+0x60]
00007ff1409d9bbb  vmovaps xmm8, [rsp+0x70]
00007ff1409d9bc1  vmovaps xmm9, [rsp+0x80]
00007ff1409d9bca  vmovaps xmm10, [rsp+0x90]
00007ff1409d9bd3  vmovaps xmm11, [rsp+0xA0]
00007ff1409d9bdc  vmovaps xmm12, [rsp+0xB0]
00007ff1409d9be5  vmovaps xmm13, [rsp+0xC0]
00007ff1409d9bee  vmovaps xmm14, [rsp+0xD0]
00007ff1409d9bf7  vmovaps xmm15, [rsp+0xE0]
00007ff1409d9c00  add rsp, 0xF0
00007ff1409d9c07  pop r11
00007ff1409d9c09  pop r10
00007ff1409d9c0b  pop r9
00007ff1409d9c0d  pop r8
00007ff1409d9c0f  pop rsi
00007ff1409d9c10  pop rdi
00007ff1409d9c11  pop rdx
00007ff1409d9c12  pop rcx
00007ff1409d9c13  pop rax
00007ff1409d9c14  add rsp, 0x08
00007ff1409d9c18  jmp 0x00007FF1409D8BA8
00007ff1409d9c1d  sub rsp, 0x08
00007ff1409d9c21  push rax
00007ff1409d9c22  push rcx
00007ff1409d9c23  push rdx
00007ff1409d9c24  push rdi
00007ff1409d9c25  push rsi
00007ff1409d9c26  push r8
00007ff1409d9c28  push r9
00007ff1409d9c2a  push r10
00007ff1409d9c2c  push r11
00007ff1409d9c2e  sub rsp, 0xF0
00007ff1409d9c35  vmovaps [rsp], xmm0
00007ff1409d9c3a  vmovaps [rsp+0x10], xmm1
00007ff1409d9c40  vmovaps [rsp+0x20], xmm2
00007ff1409d9c46  vmovaps [rsp+0x30], xmm3
00007ff1409d9c4c  vmovaps [rsp+0x40], xmm4
00007ff1409d9c52  vmovaps [rsp+0x50], xmm5
00007ff1409d9c58  vmovaps [rsp+0x60], xmm6
00007ff1409d9c5e  vmovaps [rsp+0x70], xmm7
00007ff1409d9c64  vmovaps [rsp+0x80], xmm8
00007ff1409d9c6d  vmovaps [rsp+0x90], xmm10
00007ff1409d9c76  vmovaps [rsp+0xA0], xmm11
00007ff1409d9c7f  vmovaps [rsp+0xB0], xmm12
00007ff1409d9c88  vmovaps [rsp+0xC0], xmm13
00007ff1409d9c91  vmovaps [rsp+0xD0], xmm14
00007ff1409d9c9a  vmovaps [rsp+0xE0], xmm15
00007ff1409d9ca3  sub rsp, 0x30
00007ff1409d9ca7  movaps [rsp], xmm9
00007ff1409d9cac  movaps [rsp+0x10], xmm12
00007ff1409d9cb2  movaps [rsp+0x20], xmm10
00007ff1409d9cb8  lea rdi, [rsp]
00007ff1409d9cbc  mov esi, 0x00
00007ff1409d9cc1  mov rax, 0x565C7F10C530
00007ff1409d9ccb  call rax
00007ff1409d9ccd  movaps xmm9, [rsp]
00007ff1409d9cd2  add rsp, 0x30
00007ff1409d9cd6  vmovaps xmm0, [rsp]
00007ff1409d9cdb  vmovaps xmm1, [rsp+0x10]
00007ff1409d9ce1  vmovaps xmm2, [rsp+0x20]
00007ff1409d9ce7  vmovaps xmm3, [rsp+0x30]
00007ff1409d9ced  vmovaps xmm4, [rsp+0x40]
00007ff1409d9cf3  vmovaps xmm5, [rsp+0x50]
00007ff1409d9cf9  vmovaps xmm6, [rsp+0x60]
00007ff1409d9cff  vmovaps xmm7, [rsp+0x70]
00007ff1409d9d05  vmovaps xmm8, [rsp+0x80]
00007ff1409d9d0e  vmovaps xmm10, [rsp+0x90]
00007ff1409d9d17  vmovaps xmm11, [rsp+0xA0]
00007ff1409d9d20  vmovaps xmm12, [rsp+0xB0]
00007ff1409d9d29  vmovaps xmm13, [rsp+0xC0]
00007ff1409d9d32  vmovaps xmm14, [rsp+0xD0]
00007ff1409d9d3b  vmovaps xmm15, [rsp+0xE0]
00007ff1409d9d44  add rsp, 0xF0
00007ff1409d9d4b  pop r11
00007ff1409d9d4d  pop r10
00007ff1409d9d4f  pop r9
00007ff1409d9d51  pop r8
00007ff1409d9d53  pop rsi
00007ff1409d9d54  pop rdi
00007ff1409d9d55  pop rdx
00007ff1409d9d56  pop rcx
00007ff1409d9d57  pop rax
00007ff1409d9d58  add rsp, 0x08
00007ff1409d9d5c  jmp 0x00007FF1409D8BCC
00007ff1409d9d61  sub rsp, 0x08
00007ff1409d9d65  push rax
00007ff1409d9d66  push rcx
00007ff1409d9d67  push rdx
00007ff1409d9d68  push rdi
00007ff1409d9d69  push rsi
00007ff1409d9d6a  push r8
00007ff1409d9d6c  push r9
00007ff1409d9d6e  push r10
00007ff1409d9d70  push r11
00007ff1409d9d72  sub rsp, 0xF0
00007ff1409d9d79  vmovaps [rsp], xmm0
00007ff1409d9d7e  vmovaps [rsp+0x10], xmm1
00007ff1409d9d84  vmovaps [rsp+0x20], xmm2
00007ff1409d9d8a  vmovaps [rsp+0x30], xmm3
00007ff1409d9d90  vmovaps [rsp+0x40], xmm4
00007ff1409d9d96  vmovaps [rsp+0x50], xmm5
00007ff1409d9d9c  vmovaps [rsp+0x60], xmm6
00007ff1409d9da2  vmovaps [rsp+0x70], xmm7
00007ff1409d9da8  vmovaps [rsp+0x80], xmm8
00007ff1409d9db1  vmovaps [rsp+0x90], xmm9
00007ff1409d9dba  vmovaps [rsp+0xA0], xmm11
00007ff1409d9dc3  vmovaps [rsp+0xB0], xmm12
00007ff1409d9dcc  vmovaps [rsp+0xC0], xmm13
00007ff1409d9dd5  vmovaps [rsp+0xD0], xmm14
00007ff1409d9dde  vmovaps [rsp+0xE0], xmm15
00007ff1409d9de7  sub rsp, 0x30
00007ff1409d9deb  movaps [rsp], xmm10
00007ff1409d9df0  movaps [rsp+0x10], xmm12
00007ff1409d9df6  movaps [rsp+0x20], xmm11
00007ff1409d9dfc  lea rdi, [rsp]
00007ff1409d9e00  mov esi, 0x00
00007ff1409d9e05  mov rax, 0x565C7F10C530
00007ff1409d9e0f  call rax
00007ff1409d9e11  movaps xmm10, [rsp]
00007ff1409d9e16  add rsp, 0x30
00007ff1409d9e1a  vmovaps xmm0, [rsp]
00007ff1409d9e1f  vmovaps xmm1, [rsp+0x10]
00007ff1409d9e25  vmovaps xmm2, [rsp+0x20]
00007ff1409d9e2b  vmovaps xmm3, [rsp+0x30]
00007ff1409d9e31  vmovaps xmm4, [rsp+0x40]
00007ff1409d9e37  vmovaps xmm5, [rsp+0x50]
00007ff1409d9e3d  vmovaps xmm6, [rsp+0x60]
00007ff1409d9e43  vmovaps xmm7, [rsp+0x70]
00007ff1409d9e49  vmovaps xmm8, [rsp+0x80]
00007ff1409d9e52  vmovaps xmm9, [rsp+0x90]
00007ff1409d9e5b  vmovaps xmm11, [rsp+0xA0]
00007ff1409d9e64  vmovaps xmm12, [rsp+0xB0]
00007ff1409d9e6d  vmovaps xmm13, [rsp+0xC0]
00007ff1409d9e76  vmovaps xmm14, [rsp+0xD0]
00007ff1409d9e7f  vmovaps xmm15, [rsp+0xE0]
00007ff1409d9e88  add rsp, 0xF0
00007ff1409d9e8f  pop r11
00007ff1409d9e91  pop r10
00007ff1409d9e93  pop r9
00007ff1409d9e95  pop r8
00007ff1409d9e97  pop rsi
00007ff1409d9e98  pop rdi
00007ff1409d9e99  pop rdx
00007ff1409d9e9a  pop rcx
00007ff1409d9e9b  pop rax
00007ff1409d9e9c  add rsp, 0x08
00007ff1409d9ea0  jmp 0x00007FF1409D8BE6
00007ff1409d9ea5  sub rsp, 0x08
00007ff1409d9ea9  push rax
00007ff1409d9eaa  push rcx
00007ff1409d9eab  push rdx
00007ff1409d9eac  push rdi
00007ff1409d9ead  push rsi
00007ff1409d9eae  push r8
00007ff1409d9eb0  push r9
00007ff1409d9eb2  push r10
00007ff1409d9eb4  push r11
00007ff1409d9eb6  sub rsp, 0xF0
00007ff1409d9ebd  vmovaps [rsp], xmm0
00007ff1409d9ec2  vmovaps [rsp+0x10], xmm1
00007ff1409d9ec8  vmovaps [rsp+0x20], xmm2
00007ff1409d9ece  vmovaps [rsp+0x30], xmm3
00007ff1409d9ed4  vmovaps [rsp+0x40], xmm4
00007ff1409d9eda  vmovaps [rsp+0x50], xmm5
00007ff1409d9ee0  vmovaps [rsp+0x60], xmm7
00007ff1409d9ee6  vmovaps [rsp+0x70], xmm8
00007ff1409d9eec  vmovaps [rsp+0x80], xmm9
00007ff1409d9ef5  vmovaps [rsp+0x90], xmm10
00007ff1409d9efe  vmovaps [rsp+0xA0], xmm11
00007ff1409d9f07  vmovaps [rsp+0xB0], xmm12
00007ff1409d9f10  vmovaps [rsp+0xC0], xmm13
00007ff1409d9f19  vmovaps [rsp+0xD0], xmm14
00007ff1409d9f22  vmovaps [rsp+0xE0], xmm15
00007ff1409d9f2b  sub rsp, 0x30
00007ff1409d9f2f  movaps [rsp], xmm6
00007ff1409d9f33  movaps [rsp+0x10], xmm12
00007ff1409d9f39  movaps [rsp+0x20], xmm11
00007ff1409d9f3f  lea rdi, [rsp]
00007ff1409d9f43  mov esi, 0x00
00007ff1409d9f48  mov rax, 0x565C7F10C530
00007ff1409d9f52  call rax
00007ff1409d9f54  movaps xmm6, [rsp]
00007ff1409d9f58  add rsp, 0x30
00007ff1409d9f5c  vmovaps xmm0, [rsp]
00007ff1409d9f61  vmovaps xmm1, [rsp+0x10]
00007ff1409d9f67  vmovaps xmm2, [rsp+0x20]
00007ff1409d9f6d  vmovaps xmm3, [rsp+0x30]
00007ff1409d9f73  vmovaps xmm4, [rsp+0x40]
00007ff1409d9f79  vmovaps xmm5, [rsp+0x50]
00007ff1409d9f7f  vmovaps xmm7, [rsp+0x60]
00007ff1409d9f85  vmovaps xmm8, [rsp+0x70]
00007ff1409d9f8b  vmovaps xmm9, [rsp+0x80]
00007ff1409d9f94  vmovaps xmm10, [rsp+0x90]
00007ff1409d9f9d  vmovaps xmm11, [rsp+0xA0]
00007ff1409d9fa6  vmovaps xmm12, [rsp+0xB0]
00007ff1409d9faf  vmovaps xmm13, [rsp+0xC0]
00007ff1409d9fb8  vmovaps xmm14, [rsp+0xD0]
00007ff1409d9fc1  vmovaps xmm15, [rsp+0xE0]
00007ff1409d9fca  add rsp, 0xF0
00007ff1409d9fd1  pop r11
00007ff1409d9fd3  pop r10
00007ff1409d9fd5  pop r9
00007ff1409d9fd7  pop r8
00007ff1409d9fd9  pop rsi
00007ff1409d9fda  pop rdi
00007ff1409d9fdb  pop rdx
00007ff1409d9fdc  pop rcx
00007ff1409d9fdd  pop rax
00007ff1409d9fde  add rsp, 0x08
00007ff1409d9fe2  jmp 0x00007FF1409D8C07
00007ff1409d9fe7  sub rsp, 0x08
00007ff1409d9feb  push rax
00007ff1409d9fec  push rcx
00007ff1409d9fed  push rdx
00007ff1409d9fee  push rdi
00007ff1409d9fef  push rsi
00007ff1409d9ff0  push r8
00007ff1409d9ff2  push r9
00007ff1409d9ff4  push r10
00007ff1409d9ff6  push r11
00007ff1409d9ff8  sub rsp, 0xF0
00007ff1409d9fff  vmovaps [rsp], xmm0
00007ff1409da004  vmovaps [rsp+0x10], xmm1
00007ff1409da00a  vmovaps [rsp+0x20], xmm2
00007ff1409da010  vmovaps [rsp+0x30], xmm4
00007ff1409da016  vmovaps [rsp+0x40], xmm5
00007ff1409da01c  vmovaps [rsp+0x50], xmm6
00007ff1409da022  vmovaps [rsp+0x60], xmm7
00007ff1409da028  vmovaps [rsp+0x70], xmm8
00007ff1409da02e  vmovaps [rsp+0x80], xmm9
00007ff1409da037  vmovaps [rsp+0x90], xmm10
00007ff1409da040  vmovaps [rsp+0xA0], xmm11
00007ff1409da049  vmovaps [rsp+0xB0], xmm12
00007ff1409da052  vmovaps [rsp+0xC0], xmm13
00007ff1409da05b  vmovaps [rsp+0xD0], xmm14
00007ff1409da064  vmovaps [rsp+0xE0], xmm15
00007ff1409da06d  sub rsp, 0x30
00007ff1409da071  movaps [rsp], xmm3
00007ff1409da075  movaps [rsp+0x10], xmm5
00007ff1409da07a  movaps [rsp+0x20], xmm4
00007ff1409da07f  lea rdi, [rsp]
00007ff1409da083  mov esi, 0x00
00007ff1409da088  mov rax, 0x565C7F10C530
00007ff1409da092  call rax
00007ff1409da094  movaps xmm3, [rsp]
00007ff1409da098  add rsp, 0x30
00007ff1409da09c  vmovaps xmm0, [rsp]
00007ff1409da0a1  vmovaps xmm1, [rsp+0x10]
00007ff1409da0a7  vmovaps xmm2, [rsp+0x20]
00007ff1409da0ad  vmovaps xmm4, [rsp+0x30]
00007ff1409da0b3  vmovaps xmm5, [rsp+0x40]
00007ff1409da0b9  vmovaps xmm6, [rsp+0x50]
00007ff1409da0bf  vmovaps xmm7, [rsp+0x60]
00007ff1409da0c5  vmovaps xmm8, [rsp+0x70]
00007ff1409da0cb  vmovaps xmm9, [rsp+0x80]
00007ff1409da0d4  vmovaps xmm10, [rsp+0x90]
00007ff1409da0dd  vmovaps xmm11, [rsp+0xA0]
00007ff1409da0e6  vmovaps xmm12, [rsp+0xB0]
00007ff1409da0ef  vmovaps xmm13, [rsp+0xC0]
00007ff1409da0f8  vmovaps xmm14, [rsp+0xD0]
00007ff1409da101  vmovaps xmm15, [rsp+0xE0]
00007ff1409da10a  add rsp, 0xF0
00007ff1409da111  pop r11
00007ff1409da113  pop r10
00007ff1409da115  pop r9
00007ff1409da117  pop r8
00007ff1409da119  pop rsi
00007ff1409da11a  pop rdi
00007ff1409da11b  pop rdx
00007ff1409da11c  pop rcx
00007ff1409da11d  pop rax
00007ff1409da11e  add rsp, 0x08
00007ff1409da122  jmp 0x00007FF1409D8C68
00007ff1409da127  sub rsp, 0x08
00007ff1409da12b  push rax
00007ff1409da12c  push rcx
00007ff1409da12d  push rdx
00007ff1409da12e  push rdi
00007ff1409da12f  push rsi
00007ff1409da130  push r8
00007ff1409da132  push r9
00007ff1409da134  push r10
00007ff1409da136  push r11
00007ff1409da138  sub rsp, 0xF0
00007ff1409da13f  vmovaps [rsp], xmm0
00007ff1409da144  vmovaps [rsp+0x10], xmm1
00007ff1409da14a  vmovaps [rsp+0x20], xmm2
00007ff1409da150  vmovaps [rsp+0x30], xmm3
00007ff1409da156  vmovaps [rsp+0x40], xmm4
00007ff1409da15c  vmovaps [rsp+0x50], xmm6
00007ff1409da162  vmovaps [rsp+0x60], xmm7
00007ff1409da168  vmovaps [rsp+0x70], xmm8
00007ff1409da16e  vmovaps [rsp+0x80], xmm9
00007ff1409da177  vmovaps [rsp+0x90], xmm10
00007ff1409da180  vmovaps [rsp+0xA0], xmm11
00007ff1409da189  vmovaps [rsp+0xB0], xmm12
00007ff1409da192  vmovaps [rsp+0xC0], xmm13
00007ff1409da19b  vmovaps [rsp+0xD0], xmm14
00007ff1409da1a4  vmovaps [rsp+0xE0], xmm15
00007ff1409da1ad  sub rsp, 0x30
00007ff1409da1b1  movaps [rsp], xmm5
00007ff1409da1b5  movaps [rsp+0x10], xmm8
00007ff1409da1bb  movaps [rsp+0x20], xmm15
00007ff1409da1c1  lea rdi, [rsp]
00007ff1409da1c5  mov esi, 0x00
00007ff1409da1ca  mov rax, 0x565C7F10C530
00007ff1409da1d4  call rax
00007ff1409da1d6  movaps xmm5, [rsp]
00007ff1409da1da  add rsp, 0x30
00007ff1409da1de  vmovaps xmm0, [rsp]
00007ff1409da1e3  vmovaps xmm1, [rsp+0x10]
00007ff1409da1e9  vmovaps xmm2, [rsp+0x20]
00007ff1409da1ef  vmovaps xmm3, [rsp+0x30]
00007ff1409da1f5  vmovaps xmm4, [rsp+0x40]
00007ff1409da1fb  vmovaps xmm6, [rsp+0x50]
00007ff1409da201  vmovaps xmm7, [rsp+0x60]
00007ff1409da207  vmovaps xmm8, [rsp+0x70]
00007ff1409da20d  vmovaps xmm9, [rsp+0x80]
00007ff1409da216  vmovaps xmm10, [rsp+0x90]
00007ff1409da21f  vmovaps xmm11, [rsp+0xA0]
00007ff1409da228  vmovaps xmm12, [rsp+0xB0]
00007ff1409da231  vmovaps xmm13, [rsp+0xC0]
00007ff1409da23a  vmovaps xmm14, [rsp+0xD0]
00007ff1409da243  vmovaps xmm15, [rsp+0xE0]
00007ff1409da24c  add rsp, 0xF0
00007ff1409da253  pop r11
00007ff1409da255  pop r10
00007ff1409da257  pop r9
00007ff1409da259  pop r8
00007ff1409da25b  pop rsi
00007ff1409da25c  pop rdi
00007ff1409da25d  pop rdx
00007ff1409da25e  pop rcx
00007ff1409da25f  pop rax
00007ff1409da260  add rsp, 0x08
00007ff1409da264  jmp 0x00007FF1409D8CA0
00007ff1409da269  sub rsp, 0x08
00007ff1409da26d  push rax
00007ff1409da26e  push rcx
00007ff1409da26f  push rdx
00007ff1409da270  push rdi
00007ff1409da271  push rsi
00007ff1409da272  push r8
00007ff1409da274  push r9
00007ff1409da276  push r10
00007ff1409da278  push r11
00007ff1409da27a  sub rsp, 0xF0
00007ff1409da281  vmovaps [rsp], xmm0
00007ff1409da286  vmovaps [rsp+0x10], xmm1
00007ff1409da28c  vmovaps [rsp+0x20], xmm2
00007ff1409da292  vmovaps [rsp+0x30], xmm3
00007ff1409da298  vmovaps [rsp+0x40], xmm5
00007ff1409da29e  vmovaps [rsp+0x50], xmm6
00007ff1409da2a4  vmovaps [rsp+0x60], xmm7
00007ff1409da2aa  vmovaps [rsp+0x70], xmm8
00007ff1409da2b0  vmovaps [rsp+0x80], xmm9
00007ff1409da2b9  vmovaps [rsp+0x90], xmm10
00007ff1409da2c2  vmovaps [rsp+0xA0], xmm11
00007ff1409da2cb  vmovaps [rsp+0xB0], xmm12
00007ff1409da2d4  vmovaps [rsp+0xC0], xmm13
00007ff1409da2dd  vmovaps [rsp+0xD0], xmm14
00007ff1409da2e6  vmovaps [rsp+0xE0], xmm15
00007ff1409da2ef  sub rsp, 0x30
00007ff1409da2f3  movaps [rsp], xmm4
00007ff1409da2f7  movaps [rsp+0x10], xmm9
00007ff1409da2fd  movaps [rsp+0x20], xmm8
00007ff1409da303  lea rdi, [rsp]
00007ff1409da307  mov esi, 0x00
00007ff1409da30c  mov rax, 0x565C7F10C530
00007ff1409da316  call rax
00007ff1409da318  movaps xmm4, [rsp]
00007ff1409da31c  add rsp, 0x30
00007ff1409da320  vmovaps xmm0, [rsp]
00007ff1409da325  vmovaps xmm1, [rsp+0x10]
00007ff1409da32b  vmovaps xmm2, [rsp+0x20]
00007ff1409da331  vmovaps xmm3, [rsp+0x30]
00007ff1409da337  vmovaps xmm5, [rsp+0x40]
00007ff1409da33d  vmovaps xmm6, [rsp+0x50]
00007ff1409da343  vmovaps xmm7, [rsp+0x60]
00007ff1409da349  vmovaps xmm8, [rsp+0x70]
00007ff1409da34f  vmovaps xmm9, [rsp+0x80]
00007ff1409da358  vmovaps xmm10, [rsp+0x90]
00007ff1409da361  vmovaps xmm11, [rsp+0xA0]
00007ff1409da36a  vmovaps xmm12, [rsp+0xB0]
00007ff1409da373  vmovaps xmm13, [rsp+0xC0]
00007ff1409da37c  vmovaps xmm14, [rsp+0xD0]
00007ff1409da385  vmovaps xmm15, [rsp+0xE0]
00007ff1409da38e  add rsp, 0xF0
00007ff1409da395  pop r11
00007ff1409da397  pop r10
00007ff1409da399  pop r9
00007ff1409da39b  pop r8
00007ff1409da39d  pop rsi
00007ff1409da39e  pop rdi
00007ff1409da39f  pop rdx
00007ff1409da3a0  pop rcx
00007ff1409da3a1  pop rax
00007ff1409da3a2  add rsp, 0x08
00007ff1409da3a6  jmp 0x00007FF1409D8CC1
00007ff1409da3ab  sub rsp, 0x08
00007ff1409da3af  push rax
00007ff1409da3b0  push rcx
00007ff1409da3b1  push rdx
00007ff1409da3b2  push rdi
00007ff1409da3b3  push rsi
00007ff1409da3b4  push r8
00007ff1409da3b6  push r9
00007ff1409da3b8  push r10
00007ff1409da3ba  push r11
00007ff1409da3bc  sub rsp, 0xF0
00007ff1409da3c3  vmovaps [rsp], xmm0
00007ff1409da3c8  vmovaps [rsp+0x10], xmm1
00007ff1409da3ce  vmovaps [rsp+0x20], xmm2
00007ff1409da3d4  vmovaps [rsp+0x30], xmm3
00007ff1409da3da  vmovaps [rsp+0x40], xmm4
00007ff1409da3e0  vmovaps [rsp+0x50], xmm5
00007ff1409da3e6  vmovaps [rsp+0x60], xmm6
00007ff1409da3ec  vmovaps [rsp+0x70], xmm7
00007ff1409da3f2  vmovaps [rsp+0x80], xmm8
00007ff1409da3fb  vmovaps [rsp+0x90], xmm10
00007ff1409da404  vmovaps [rsp+0xA0], xmm11
00007ff1409da40d  vmovaps [rsp+0xB0], xmm12
00007ff1409da416  vmovaps [rsp+0xC0], xmm13
00007ff1409da41f  vmovaps [rsp+0xD0], xmm14
00007ff1409da428  vmovaps [rsp+0xE0], xmm15
00007ff1409da431  sub rsp, 0x30
00007ff1409da435  movaps [rsp], xmm9
00007ff1409da43a  movaps [rsp+0x10], xmm10
00007ff1409da440  movaps [rsp+0x20], xmm8
00007ff1409da446  lea rdi, [rsp]
00007ff1409da44a  mov esi, 0x00
00007ff1409da44f  mov rax, 0x565C7F10C530
00007ff1409da459  call rax
00007ff1409da45b  movaps xmm9, [rsp]
00007ff1409da460  add rsp, 0x30
00007ff1409da464  vmovaps xmm0, [rsp]
00007ff1409da469  vmovaps xmm1, [rsp+0x10]
00007ff1409da46f  vmovaps xmm2, [rsp+0x20]
00007ff1409da475  vmovaps xmm3, [rsp+0x30]
00007ff1409da47b  vmovaps xmm4, [rsp+0x40]
00007ff1409da481  vmovaps xmm5, [rsp+0x50]
00007ff1409da487  vmovaps xmm6, [rsp+0x60]
00007ff1409da48d  vmovaps xmm7, [rsp+0x70]
00007ff1409da493  vmovaps xmm8, [rsp+0x80]
00007ff1409da49c  vmovaps xmm10, [rsp+0x90]
00007ff1409da4a5  vmovaps xmm11, [rsp+0xA0]
00007ff1409da4ae  vmovaps xmm12, [rsp+0xB0]
00007ff1409da4b7  vmovaps xmm13, [rsp+0xC0]
00007ff1409da4c0  vmovaps xmm14, [rsp+0xD0]
00007ff1409da4c9  vmovaps xmm15, [rsp+0xE0]
00007ff1409da4d2  add rsp, 0xF0
00007ff1409da4d9  pop r11
00007ff1409da4db  pop r10
00007ff1409da4dd  pop r9
00007ff1409da4df  pop r8
00007ff1409da4e1  pop rsi
00007ff1409da4e2  pop rdi
00007ff1409da4e3  pop rdx
00007ff1409da4e4  pop rcx
00007ff1409da4e5  pop rax
00007ff1409da4e6  add rsp, 0x08
00007ff1409da4ea  jmp 0x00007FF1409D8CDB
00007ff1409da4ef  call 0x00007FF1408D64F0
00007ff1409da4f4  jmp 0x00007FF1409D8DF5
00007ff1409da4f9  call 0x00007FF1408D64F0
00007ff1409da4fe  jmp 0x00007FF1409D8E0B
00007ff1409da503  sub rsp, 0x08
00007ff1409da507  push rax
00007ff1409da508  push rcx
00007ff1409da509  push rdx
00007ff1409da50a  push rdi
00007ff1409da50b  push rsi
00007ff1409da50c  push r8
00007ff1409da50e  push r9
00007ff1409da510  push r10
00007ff1409da512  push r11
00007ff1409da514  sub rsp, 0xF0
00007ff1409da51b  vmovaps [rsp], xmm0
00007ff1409da520  vmovaps [rsp+0x10], xmm2
00007ff1409da526  vmovaps [rsp+0x20], xmm3
00007ff1409da52c  vmovaps [rsp+0x30], xmm4
00007ff1409da532  vmovaps [rsp+0x40], xmm5
00007ff1409da538  vmovaps [rsp+0x50], xmm6
00007ff1409da53e  vmovaps [rsp+0x60], xmm7
00007ff1409da544  vmovaps [rsp+0x70], xmm8
00007ff1409da54a  vmovaps [rsp+0x80], xmm9
00007ff1409da553  vmovaps [rsp+0x90], xmm10
00007ff1409da55c  vmovaps [rsp+0xA0], xmm11
00007ff1409da565  vmovaps [rsp+0xB0], xmm12
00007ff1409da56e  vmovaps [rsp+0xC0], xmm13
00007ff1409da577  vmovaps [rsp+0xD0], xmm14
00007ff1409da580  vmovaps [rsp+0xE0], xmm15
00007ff1409da589  sub rsp, 0x30
00007ff1409da58d  movaps [rsp], xmm1
00007ff1409da591  movaps [rsp+0x10], xmm6
00007ff1409da596  movaps [rsp+0x20], xmm15
00007ff1409da59c  lea rdi, [rsp]
00007ff1409da5a0  mov esi, 0x00
00007ff1409da5a5  mov rax, 0x565C7F10C530
00007ff1409da5af  call rax
00007ff1409da5b1  movaps xmm1, [rsp]
00007ff1409da5b5  add rsp, 0x30
00007ff1409da5b9  vmovaps xmm0, [rsp]
00007ff1409da5be  vmovaps xmm2, [rsp+0x10]
00007ff1409da5c4  vmovaps xmm3, [rsp+0x20]
00007ff1409da5ca  vmovaps xmm4, [rsp+0x30]
00007ff1409da5d0  vmovaps xmm5, [rsp+0x40]
00007ff1409da5d6  vmovaps xmm6, [rsp+0x50]
00007ff1409da5dc  vmovaps xmm7, [rsp+0x60]
00007ff1409da5e2  vmovaps xmm8, [rsp+0x70]
00007ff1409da5e8  vmovaps xmm9, [rsp+0x80]
00007ff1409da5f1  vmovaps xmm10, [rsp+0x90]
00007ff1409da5fa  vmovaps xmm11, [rsp+0xA0]
00007ff1409da603  vmovaps xmm12, [rsp+0xB0]
00007ff1409da60c  vmovaps xmm13, [rsp+0xC0]
00007ff1409da615  vmovaps xmm14, [rsp+0xD0]
00007ff1409da61e  vmovaps xmm15, [rsp+0xE0]
00007ff1409da627  add rsp, 0xF0
00007ff1409da62e  pop r11
00007ff1409da630  pop r10
00007ff1409da632  pop r9
00007ff1409da634  pop r8
00007ff1409da636  pop rsi
00007ff1409da637  pop rdi
00007ff1409da638  pop rdx
00007ff1409da639  pop rcx
00007ff1409da63a  pop rax
00007ff1409da63b  add rsp, 0x08
00007ff1409da63f  jmp 0x00007FF1409D8E48
00007ff1409da644  call 0x00007FF1408E5820
00007ff1409da649  jmp 0x00007FF1409D8E55
00007ff1409da64e  sub rsp, 0x08
00007ff1409da652  push rax
00007ff1409da653  push rcx
00007ff1409da654  push rdx
00007ff1409da655  push rdi
00007ff1409da656  push rsi
00007ff1409da657  push r8
00007ff1409da659  push r9
00007ff1409da65b  push r10
00007ff1409da65d  push r11
00007ff1409da65f  sub rsp, 0xF0
00007ff1409da666  vmovaps [rsp], xmm0
00007ff1409da66b  vmovaps [rsp+0x10], xmm1
00007ff1409da671  vmovaps [rsp+0x20], xmm2
00007ff1409da677  vmovaps [rsp+0x30], xmm3
00007ff1409da67d  vmovaps [rsp+0x40], xmm4
00007ff1409da683  vmovaps [rsp+0x50], xmm5
00007ff1409da689  vmovaps [rsp+0x60], xmm6
00007ff1409da68f  vmovaps [rsp+0x70], xmm7
00007ff1409da695  vmovaps [rsp+0x80], xmm8
00007ff1409da69e  vmovaps [rsp+0x90], xmm9
00007ff1409da6a7  vmovaps [rsp+0xA0], xmm10
00007ff1409da6b0  vmovaps [rsp+0xB0], xmm11
00007ff1409da6b9  vmovaps [rsp+0xC0], xmm12
00007ff1409da6c2  vmovaps [rsp+0xD0], xmm13
00007ff1409da6cb  vmovaps [rsp+0xE0], xmm15
00007ff1409da6d4  sub rsp, 0x30
00007ff1409da6d8  movaps [rsp], xmm14
00007ff1409da6dd  movaps [rsp+0x10], xmm4
00007ff1409da6e2  movaps [rsp+0x20], xmm3
00007ff1409da6e7  lea rdi, [rsp]
00007ff1409da6eb  mov esi, 0x00
00007ff1409da6f0  mov rax, 0x565C7F10C530
00007ff1409da6fa  call rax
00007ff1409da6fc  movaps xmm14, [rsp]
00007ff1409da701  add rsp, 0x30
00007ff1409da705  vmovaps xmm0, [rsp]
00007ff1409da70a  vmovaps xmm1, [rsp+0x10]
00007ff1409da710  vmovaps xmm2, [rsp+0x20]
00007ff1409da716  vmovaps xmm3, [rsp+0x30]
00007ff1409da71c  vmovaps xmm4, [rsp+0x40]
00007ff1409da722  vmovaps xmm5, [rsp+0x50]
00007ff1409da728  vmovaps xmm6, [rsp+0x60]
00007ff1409da72e  vmovaps xmm7, [rsp+0x70]
00007ff1409da734  vmovaps xmm8, [rsp+0x80]
00007ff1409da73d  vmovaps xmm9, [rsp+0x90]
00007ff1409da746  vmovaps xmm10, [rsp+0xA0]
00007ff1409da74f  vmovaps xmm11, [rsp+0xB0]
00007ff1409da758  vmovaps xmm12, [rsp+0xC0]
00007ff1409da761  vmovaps xmm13, [rsp+0xD0]
00007ff1409da76a  vmovaps xmm15, [rsp+0xE0]
00007ff1409da773  add rsp, 0xF0
00007ff1409da77a  pop r11
00007ff1409da77c  pop r10
00007ff1409da77e  pop r9
00007ff1409da780  pop r8
00007ff1409da782  pop rsi
00007ff1409da783  pop rdi
00007ff1409da784  pop rdx
00007ff1409da785  pop rcx
00007ff1409da786  pop rax
00007ff1409da787  add rsp, 0x08
00007ff1409da78b  jmp 0x00007FF1409D8E6F
00007ff1409da790  sub rsp, 0x08
00007ff1409da794  push rax
00007ff1409da795  push rcx
00007ff1409da796  push rdx
00007ff1409da797  push rdi
00007ff1409da798  push rsi
00007ff1409da799  push r8
00007ff1409da79b  push r9
00007ff1409da79d  push r10
00007ff1409da79f  push r11
00007ff1409da7a1  sub rsp, 0xF0
00007ff1409da7a8  vmovaps [rsp], xmm0
00007ff1409da7ad  vmovaps [rsp+0x10], xmm1
00007ff1409da7b3  vmovaps [rsp+0x20], xmm2
00007ff1409da7b9  vmovaps [rsp+0x30], xmm3
00007ff1409da7bf  vmovaps [rsp+0x40], xmm4
00007ff1409da7c5  vmovaps [rsp+0x50], xmm5
00007ff1409da7cb  vmovaps [rsp+0x60], xmm7
00007ff1409da7d1  vmovaps [rsp+0x70], xmm8
00007ff1409da7d7  vmovaps [rsp+0x80], xmm9
00007ff1409da7e0  vmovaps [rsp+0x90], xmm10
00007ff1409da7e9  vmovaps [rsp+0xA0], xmm11
00007ff1409da7f2  vmovaps [rsp+0xB0], xmm12
00007ff1409da7fb  vmovaps [rsp+0xC0], xmm13
00007ff1409da804  vmovaps [rsp+0xD0], xmm14
00007ff1409da80d  vmovaps [rsp+0xE0], xmm15
00007ff1409da816  sub rsp, 0x30
00007ff1409da81a  movaps [rsp], xmm6
00007ff1409da81e  movaps [rsp+0x10], xmm9
00007ff1409da824  movaps [rsp+0x20], xmm7
00007ff1409da829  lea rdi, [rsp]
00007ff1409da82d  mov esi, 0x00
00007ff1409da832  mov rax, 0x565C7F10C530
00007ff1409da83c  call rax
00007ff1409da83e  movaps xmm6, [rsp]
00007ff1409da842  add rsp, 0x30
00007ff1409da846  vmovaps xmm0, [rsp]
00007ff1409da84b  vmovaps xmm1, [rsp+0x10]
00007ff1409da851  vmovaps xmm2, [rsp+0x20]
00007ff1409da857  vmovaps xmm3, [rsp+0x30]
00007ff1409da85d  vmovaps xmm4, [rsp+0x40]
00007ff1409da863  vmovaps xmm5, [rsp+0x50]
00007ff1409da869  vmovaps xmm7, [rsp+0x60]
00007ff1409da86f  vmovaps xmm8, [rsp+0x70]
00007ff1409da875  vmovaps xmm9, [rsp+0x80]
00007ff1409da87e  vmovaps xmm10, [rsp+0x90]
00007ff1409da887  vmovaps xmm11, [rsp+0xA0]
00007ff1409da890  vmovaps xmm12, [rsp+0xB0]
00007ff1409da899  vmovaps xmm13, [rsp+0xC0]
00007ff1409da8a2  vmovaps xmm14, [rsp+0xD0]
00007ff1409da8ab  vmovaps xmm15, [rsp+0xE0]
00007ff1409da8b4  add rsp, 0xF0
00007ff1409da8bb  pop r11
00007ff1409da8bd  pop r10
00007ff1409da8bf  pop r9
00007ff1409da8c1  pop r8
00007ff1409da8c3  pop rsi
00007ff1409da8c4  pop rdi
00007ff1409da8c5  pop rdx
00007ff1409da8c6  pop rcx
00007ff1409da8c7  pop rax
00007ff1409da8c8  add rsp, 0x08
00007ff1409da8cc  jmp 0x00007FF1409D8E87
00007ff1409da8d1  sub rsp, 0x08
00007ff1409da8d5  push rax
00007ff1409da8d6  push rcx
00007ff1409da8d7  push rdx
00007ff1409da8d8  push rdi
00007ff1409da8d9  push rsi
00007ff1409da8da  push r8
00007ff1409da8dc  push r9
00007ff1409da8de  push r10
00007ff1409da8e0  push r11
00007ff1409da8e2  sub rsp, 0xF0
00007ff1409da8e9  vmovaps [rsp], xmm0
00007ff1409da8ee  vmovaps [rsp+0x10], xmm1
00007ff1409da8f4  vmovaps [rsp+0x20], xmm2
00007ff1409da8fa  vmovaps [rsp+0x30], xmm3
00007ff1409da900  vmovaps [rsp+0x40], xmm4
00007ff1409da906  vmovaps [rsp+0x50], xmm5
00007ff1409da90c  vmovaps [rsp+0x60], xmm6
00007ff1409da912  vmovaps [rsp+0x70], xmm8
00007ff1409da918  vmovaps [rsp+0x80], xmm9
00007ff1409da921  vmovaps [rsp+0x90], xmm10
00007ff1409da92a  vmovaps [rsp+0xA0], xmm11
00007ff1409da933  vmovaps [rsp+0xB0], xmm12
00007ff1409da93c  vmovaps [rsp+0xC0], xmm13
00007ff1409da945  vmovaps [rsp+0xD0], xmm14
00007ff1409da94e  vmovaps [rsp+0xE0], xmm15
00007ff1409da957  sub rsp, 0x30
00007ff1409da95b  movaps [rsp], xmm7
00007ff1409da95f  movaps [rsp+0x10], xmm4
00007ff1409da964  movaps [rsp+0x20], xmm9
00007ff1409da96a  lea rdi, [rsp]
00007ff1409da96e  mov esi, 0x00
00007ff1409da973  mov rax, 0x565C7F10C530
00007ff1409da97d  call rax
00007ff1409da97f  movaps xmm7, [rsp]
00007ff1409da983  add rsp, 0x30
00007ff1409da987  vmovaps xmm0, [rsp]
00007ff1409da98c  vmovaps xmm1, [rsp+0x10]
00007ff1409da992  vmovaps xmm2, [rsp+0x20]
00007ff1409da998  vmovaps xmm3, [rsp+0x30]
00007ff1409da99e  vmovaps xmm4, [rsp+0x40]
00007ff1409da9a4  vmovaps xmm5, [rsp+0x50]
00007ff1409da9aa  vmovaps xmm6, [rsp+0x60]
00007ff1409da9b0  vmovaps xmm8, [rsp+0x70]
00007ff1409da9b6  vmovaps xmm9, [rsp+0x80]
00007ff1409da9bf  vmovaps xmm10, [rsp+0x90]
00007ff1409da9c8  vmovaps xmm11, [rsp+0xA0]
00007ff1409da9d1  vmovaps xmm12, [rsp+0xB0]
00007ff1409da9da  vmovaps xmm13, [rsp+0xC0]
00007ff1409da9e3  vmovaps xmm14, [rsp+0xD0]
00007ff1409da9ec  vmovaps xmm15, [rsp+0xE0]
00007ff1409da9f5  add rsp, 0xF0
00007ff1409da9fc  pop r11
00007ff1409da9fe  pop r10
00007ff1409daa00  pop r9
00007ff1409daa02  pop r8
00007ff1409daa04  pop rsi
00007ff1409daa05  pop rdi
00007ff1409daa06  pop rdx
00007ff1409daa07  pop rcx
00007ff1409daa08  pop rax
00007ff1409daa09  add rsp, 0x08
00007ff1409daa0d  jmp 0x00007FF1409D8EB4
00007ff1409daa12  sub rsp, 0x08
00007ff1409daa16  push rax
00007ff1409daa17  push rcx
00007ff1409daa18  push rdx
00007ff1409daa19  push rdi
00007ff1409daa1a  push rsi
00007ff1409daa1b  push r8
00007ff1409daa1d  push r9
00007ff1409daa1f  push r10
00007ff1409daa21  push r11
00007ff1409daa23  sub rsp, 0xF0
00007ff1409daa2a  vmovaps [rsp], xmm0
00007ff1409daa2f  vmovaps [rsp+0x10], xmm1
00007ff1409daa35  vmovaps [rsp+0x20], xmm2
00007ff1409daa3b  vmovaps [rsp+0x30], xmm3
00007ff1409daa41  vmovaps [rsp+0x40], xmm5
00007ff1409daa47  vmovaps [rsp+0x50], xmm6
00007ff1409daa4d  vmovaps [rsp+0x60], xmm7
00007ff1409daa53  vmovaps [rsp+0x70], xmm8
00007ff1409daa59  vmovaps [rsp+0x80], xmm9
00007ff1409daa62  vmovaps [rsp+0x90], xmm10
00007ff1409daa6b  vmovaps [rsp+0xA0], xmm11
00007ff1409daa74  vmovaps [rsp+0xB0], xmm12
00007ff1409daa7d  vmovaps [rsp+0xC0], xmm13
00007ff1409daa86  vmovaps [rsp+0xD0], xmm14
00007ff1409daa8f  vmovaps [rsp+0xE0], xmm15
00007ff1409daa98  sub rsp, 0x30
00007ff1409daa9c  movaps [rsp], xmm4
00007ff1409daaa0  movaps [rsp+0x10], xmm15
00007ff1409daaa6  movaps [rsp+0x20], xmm9
00007ff1409daaac  lea rdi, [rsp]
00007ff1409daab0  mov esi, 0x00
00007ff1409daab5  mov rax, 0x565C7F10C530
00007ff1409daabf  call rax
00007ff1409daac1  movaps xmm4, [rsp]
00007ff1409daac5  add rsp, 0x30
00007ff1409daac9  vmovaps xmm0, [rsp]
00007ff1409daace  vmovaps xmm1, [rsp+0x10]
00007ff1409daad4  vmovaps xmm2, [rsp+0x20]
00007ff1409daada  vmovaps xmm3, [rsp+0x30]
00007ff1409daae0  vmovaps xmm5, [rsp+0x40]
00007ff1409daae6  vmovaps xmm6, [rsp+0x50]
00007ff1409daaec  vmovaps xmm7, [rsp+0x60]
00007ff1409daaf2  vmovaps xmm8, [rsp+0x70]
00007ff1409daaf8  vmovaps xmm9, [rsp+0x80]
00007ff1409dab01  vmovaps xmm10, [rsp+0x90]
00007ff1409dab0a  vmovaps xmm11, [rsp+0xA0]
00007ff1409dab13  vmovaps xmm12, [rsp+0xB0]
00007ff1409dab1c  vmovaps xmm13, [rsp+0xC0]
00007ff1409dab25  vmovaps xmm14, [rsp+0xD0]
00007ff1409dab2e  vmovaps xmm15, [rsp+0xE0]
00007ff1409dab37  add rsp, 0xF0
00007ff1409dab3e  pop r11
00007ff1409dab40  pop r10
00007ff1409dab42  pop r9
00007ff1409dab44  pop r8
00007ff1409dab46  pop rsi
00007ff1409dab47  pop rdi
00007ff1409dab48  pop rdx
00007ff1409dab49  pop rcx
00007ff1409dab4a  pop rax
00007ff1409dab4b  add rsp, 0x08
00007ff1409dab4f  jmp 0x00007FF1409D8ED9
00007ff1409dab54  call 0x00007FF1408E5820
00007ff1409dab59  jmp 0x00007FF1409D8EE6
00007ff1409dab5e  sub rsp, 0x08
00007ff1409dab62  push rax
00007ff1409dab63  push rcx
00007ff1409dab64  push rdx
00007ff1409dab65  push rdi
00007ff1409dab66  push rsi
00007ff1409dab67  push r8
00007ff1409dab69  push r9
00007ff1409dab6b  push r10
00007ff1409dab6d  push r11
00007ff1409dab6f  sub rsp, 0xF0
00007ff1409dab76  vmovaps [rsp], xmm0
00007ff1409dab7b  vmovaps [rsp+0x10], xmm1
00007ff1409dab81  vmovaps [rsp+0x20], xmm2
00007ff1409dab87  vmovaps [rsp+0x30], xmm4
00007ff1409dab8d  vmovaps [rsp+0x40], xmm5
00007ff1409dab93  vmovaps [rsp+0x50], xmm6
00007ff1409dab99  vmovaps [rsp+0x60], xmm7
00007ff1409dab9f  vmovaps [rsp+0x70], xmm8
00007ff1409daba5  vmovaps [rsp+0x80], xmm9
00007ff1409dabae  vmovaps [rsp+0x90], xmm10
00007ff1409dabb7  vmovaps [rsp+0xA0], xmm11
00007ff1409dabc0  vmovaps [rsp+0xB0], xmm12
00007ff1409dabc9  vmovaps [rsp+0xC0], xmm13
00007ff1409dabd2  vmovaps [rsp+0xD0], xmm14
00007ff1409dabdb  vmovaps [rsp+0xE0], xmm15
00007ff1409dabe4  sub rsp, 0x30
00007ff1409dabe8  movaps [rsp], xmm3
00007ff1409dabec  movaps [rsp+0x10], xmm1
00007ff1409dabf1  movaps [rsp+0x20], xmm9
00007ff1409dabf7  lea rdi, [rsp]
00007ff1409dabfb  mov esi, 0x00
00007ff1409dac00  mov rax, 0x565C7F10C530
00007ff1409dac0a  call rax
00007ff1409dac0c  movaps xmm3, [rsp]
00007ff1409dac10  add rsp, 0x30
00007ff1409dac14  vmovaps xmm0, [rsp]
00007ff1409dac19  vmovaps xmm1, [rsp+0x10]
00007ff1409dac1f  vmovaps xmm2, [rsp+0x20]
00007ff1409dac25  vmovaps xmm4, [rsp+0x30]
00007ff1409dac2b  vmovaps xmm5, [rsp+0x40]
00007ff1409dac31  vmovaps xmm6, [rsp+0x50]
00007ff1409dac37  vmovaps xmm7, [rsp+0x60]
00007ff1409dac3d  vmovaps xmm8, [rsp+0x70]
00007ff1409dac43  vmovaps xmm9, [rsp+0x80]
00007ff1409dac4c  vmovaps xmm10, [rsp+0x90]
00007ff1409dac55  vmovaps xmm11, [rsp+0xA0]
00007ff1409dac5e  vmovaps xmm12, [rsp+0xB0]
00007ff1409dac67  vmovaps xmm13, [rsp+0xC0]
00007ff1409dac70  vmovaps xmm14, [rsp+0xD0]
00007ff1409dac79  vmovaps xmm15, [rsp+0xE0]
00007ff1409dac82  add rsp, 0xF0
00007ff1409dac89  pop r11
00007ff1409dac8b  pop r10
00007ff1409dac8d  pop r9
00007ff1409dac8f  pop r8
00007ff1409dac91  pop rsi
00007ff1409dac92  pop rdi
00007ff1409dac93  pop rdx
00007ff1409dac94  pop rcx
00007ff1409dac95  pop rax
00007ff1409dac96  add rsp, 0x08
00007ff1409dac9a  jmp 0x00007FF1409D8F23
00007ff1409dac9f  sub rsp, 0x08
00007ff1409daca3  push rax
00007ff1409daca4  push rcx
00007ff1409daca5  push rdx
00007ff1409daca6  push rdi
00007ff1409daca7  push rsi
00007ff1409daca8  push r8
00007ff1409dacaa  push r9
00007ff1409dacac  push r10
00007ff1409dacae  push r11
00007ff1409dacb0  sub rsp, 0xF0
00007ff1409dacb7  vmovaps [rsp], xmm0
00007ff1409dacbc  vmovaps [rsp+0x10], xmm2
00007ff1409dacc2  vmovaps [rsp+0x20], xmm3
00007ff1409dacc8  vmovaps [rsp+0x30], xmm4
00007ff1409dacce  vmovaps [rsp+0x40], xmm5
00007ff1409dacd4  vmovaps [rsp+0x50], xmm6
00007ff1409dacda  vmovaps [rsp+0x60], xmm7
00007ff1409dace0  vmovaps [rsp+0x70], xmm8
00007ff1409dace6  vmovaps [rsp+0x80], xmm9
00007ff1409dacef  vmovaps [rsp+0x90], xmm10
00007ff1409dacf8  vmovaps [rsp+0xA0], xmm11
00007ff1409dad01  vmovaps [rsp+0xB0], xmm12
00007ff1409dad0a  vmovaps [rsp+0xC0], xmm13
00007ff1409dad13  vmovaps [rsp+0xD0], xmm14
00007ff1409dad1c  vmovaps [rsp+0xE0], xmm15
00007ff1409dad25  sub rsp, 0x30
00007ff1409dad29  movaps [rsp], xmm1
00007ff1409dad2d  movaps [rsp+0x10], xmm15
00007ff1409dad33  movaps [rsp+0x20], xmm9
00007ff1409dad39  lea rdi, [rsp]
00007ff1409dad3d  mov esi, 0x00
00007ff1409dad42  mov rax, 0x565C7F10C530
00007ff1409dad4c  call rax
00007ff1409dad4e  movaps xmm1, [rsp]
00007ff1409dad52  add rsp, 0x30
00007ff1409dad56  vmovaps xmm0, [rsp]
00007ff1409dad5b  vmovaps xmm2, [rsp+0x10]
00007ff1409dad61  vmovaps xmm3, [rsp+0x20]
00007ff1409dad67  vmovaps xmm4, [rsp+0x30]
00007ff1409dad6d  vmovaps xmm5, [rsp+0x40]
00007ff1409dad73  vmovaps xmm6, [rsp+0x50]
00007ff1409dad79  vmovaps xmm7, [rsp+0x60]
00007ff1409dad7f  vmovaps xmm8, [rsp+0x70]
00007ff1409dad85  vmovaps xmm9, [rsp+0x80]
00007ff1409dad8e  vmovaps xmm10, [rsp+0x90]
00007ff1409dad97  vmovaps xmm11, [rsp+0xA0]
00007ff1409dada0  vmovaps xmm12, [rsp+0xB0]
00007ff1409dada9  vmovaps xmm13, [rsp+0xC0]
00007ff1409dadb2  vmovaps xmm14, [rsp+0xD0]
00007ff1409dadbb  vmovaps xmm15, [rsp+0xE0]
00007ff1409dadc4  add rsp, 0xF0
00007ff1409dadcb  pop r11
00007ff1409dadcd  pop r10
00007ff1409dadcf  pop r9
00007ff1409dadd1  pop r8
00007ff1409dadd3  pop rsi
00007ff1409dadd4  pop rdi
00007ff1409dadd5  pop rdx
00007ff1409dadd6  pop rcx
00007ff1409dadd7  pop rax
00007ff1409dadd8  add rsp, 0x08
00007ff1409daddc  jmp 0x00007FF1409D8FAB
00007ff1409dade1  call 0x00007FF1408E5820
00007ff1409dade6  jmp 0x00007FF1409D8FB8
00007ff1409dadeb  sub rsp, 0x08
00007ff1409dadef  push rax
00007ff1409dadf0  push rcx
00007ff1409dadf1  push rdx
00007ff1409dadf2  push rdi
00007ff1409dadf3  push rsi
00007ff1409dadf4  push r8
00007ff1409dadf6  push r9
00007ff1409dadf8  push r10
00007ff1409dadfa  push r11
00007ff1409dadfc  sub rsp, 0xF0
00007ff1409dae03  vmovaps [rsp], xmm0
00007ff1409dae08  vmovaps [rsp+0x10], xmm2
00007ff1409dae0e  vmovaps [rsp+0x20], xmm3
00007ff1409dae14  vmovaps [rsp+0x30], xmm4
00007ff1409dae1a  vmovaps [rsp+0x40], xmm5
00007ff1409dae20  vmovaps [rsp+0x50], xmm6
00007ff1409dae26  vmovaps [rsp+0x60], xmm7
00007ff1409dae2c  vmovaps [rsp+0x70], xmm8
00007ff1409dae32  vmovaps [rsp+0x80], xmm9
00007ff1409dae3b  vmovaps [rsp+0x90], xmm10
00007ff1409dae44  vmovaps [rsp+0xA0], xmm11
00007ff1409dae4d  vmovaps [rsp+0xB0], xmm12
00007ff1409dae56  vmovaps [rsp+0xC0], xmm13
00007ff1409dae5f  vmovaps [rsp+0xD0], xmm14
00007ff1409dae68  vmovaps [rsp+0xE0], xmm15
00007ff1409dae71  sub rsp, 0x30
00007ff1409dae75  movaps [rsp], xmm1
00007ff1409dae79  movaps [rsp+0x10], xmm5
00007ff1409dae7e  movaps [rsp+0x20], xmm7
00007ff1409dae83  lea rdi, [rsp]
00007ff1409dae87  mov esi, 0x00
00007ff1409dae8c  mov rax, 0x565C7F10C530
00007ff1409dae96  call rax
00007ff1409dae98  movaps xmm1, [rsp]
00007ff1409dae9c  add rsp, 0x30
00007ff1409daea0  vmovaps xmm0, [rsp]
00007ff1409daea5  vmovaps xmm2, [rsp+0x10]
00007ff1409daeab  vmovaps xmm3, [rsp+0x20]
00007ff1409daeb1  vmovaps xmm4, [rsp+0x30]
00007ff1409daeb7  vmovaps xmm5, [rsp+0x40]
00007ff1409daebd  vmovaps xmm6, [rsp+0x50]
00007ff1409daec3  vmovaps xmm7, [rsp+0x60]
00007ff1409daec9  vmovaps xmm8, [rsp+0x70]
00007ff1409daecf  vmovaps xmm9, [rsp+0x80]
00007ff1409daed8  vmovaps xmm10, [rsp+0x90]
00007ff1409daee1  vmovaps xmm11, [rsp+0xA0]
00007ff1409daeea  vmovaps xmm12, [rsp+0xB0]
00007ff1409daef3  vmovaps xmm13, [rsp+0xC0]
00007ff1409daefc  vmovaps xmm14, [rsp+0xD0]
00007ff1409daf05  vmovaps xmm15, [rsp+0xE0]
00007ff1409daf0e  add rsp, 0xF0
00007ff1409daf15  pop r11
00007ff1409daf17  pop r10
00007ff1409daf19  pop r9
00007ff1409daf1b  pop r8
00007ff1409daf1d  pop rsi
00007ff1409daf1e  pop rdi
00007ff1409daf1f  pop rdx
00007ff1409daf20  pop rcx
00007ff1409daf21  pop rax
00007ff1409daf22  add rsp, 0x08
00007ff1409daf26  jmp 0x00007FF1409D905D
00007ff1409daf2b  sub rsp, 0x08
00007ff1409daf2f  push rax
00007ff1409daf30  push rcx
00007ff1409daf31  push rdx
00007ff1409daf32  push rdi
00007ff1409daf33  push rsi
00007ff1409daf34  push r8
00007ff1409daf36  push r9
00007ff1409daf38  push r10
00007ff1409daf3a  push r11
00007ff1409daf3c  sub rsp, 0xF0
00007ff1409daf43  vmovaps [rsp], xmm0
00007ff1409daf48  vmovaps [rsp+0x10], xmm1
00007ff1409daf4e  vmovaps [rsp+0x20], xmm2
00007ff1409daf54  vmovaps [rsp+0x30], xmm3
00007ff1409daf5a  vmovaps [rsp+0x40], xmm4
00007ff1409daf60  vmovaps [rsp+0x50], xmm5
00007ff1409daf66  vmovaps [rsp+0x60], xmm6
00007ff1409daf6c  vmovaps [rsp+0x70], xmm8
00007ff1409daf72  vmovaps [rsp+0x80], xmm9
00007ff1409daf7b  vmovaps [rsp+0x90], xmm10
00007ff1409daf84  vmovaps [rsp+0xA0], xmm11
00007ff1409daf8d  vmovaps [rsp+0xB0], xmm12
00007ff1409daf96  vmovaps [rsp+0xC0], xmm13
00007ff1409daf9f  vmovaps [rsp+0xD0], xmm14
00007ff1409dafa8  vmovaps [rsp+0xE0], xmm15
00007ff1409dafb1  sub rsp, 0x30
00007ff1409dafb5  movaps [rsp], xmm7
00007ff1409dafb9  movaps [rsp+0x10], xmm5
00007ff1409dafbe  movaps [rsp+0x20], xmm15
00007ff1409dafc4  lea rdi, [rsp]
00007ff1409dafc8  mov esi, 0x00
00007ff1409dafcd  mov rax, 0x565C7F10C530
00007ff1409dafd7  call rax
00007ff1409dafd9  movaps xmm7, [rsp]
00007ff1409dafdd  add rsp, 0x30
00007ff1409dafe1  vmovaps xmm0, [rsp]
00007ff1409dafe6  vmovaps xmm1, [rsp+0x10]
00007ff1409dafec  vmovaps xmm2, [rsp+0x20]
00007ff1409daff2  vmovaps xmm3, [rsp+0x30]
00007ff1409daff8  vmovaps xmm4, [rsp+0x40]
00007ff1409daffe  vmovaps xmm5, [rsp+0x50]
00007ff1409db004  vmovaps xmm6, [rsp+0x60]
00007ff1409db00a  vmovaps xmm8, [rsp+0x70]
00007ff1409db010  vmovaps xmm9, [rsp+0x80]
00007ff1409db019  vmovaps xmm10, [rsp+0x90]
00007ff1409db022  vmovaps xmm11, [rsp+0xA0]
00007ff1409db02b  vmovaps xmm12, [rsp+0xB0]
00007ff1409db034  vmovaps xmm13, [rsp+0xC0]
00007ff1409db03d  vmovaps xmm14, [rsp+0xD0]
00007ff1409db046  vmovaps xmm15, [rsp+0xE0]
00007ff1409db04f  add rsp, 0xF0
00007ff1409db056  pop r11
00007ff1409db058  pop r10
00007ff1409db05a  pop r9
00007ff1409db05c  pop r8
00007ff1409db05e  pop rsi
00007ff1409db05f  pop rdi
00007ff1409db060  pop rdx
00007ff1409db061  pop rcx
00007ff1409db062  pop rax
00007ff1409db063  add rsp, 0x08
00007ff1409db067  jmp 0x00007FF1409D9093
00007ff1409db06c  call 0x00007FF1408D64F0
00007ff1409db071  jmp 0x00007FF1409D90A0
00007ff1409db076  sub rsp, 0x08
00007ff1409db07a  push rax
00007ff1409db07b  push rcx
00007ff1409db07c  push rdx
00007ff1409db07d  push rdi
00007ff1409db07e  push rsi
00007ff1409db07f  push r8
00007ff1409db081  push r9
00007ff1409db083  push r10
00007ff1409db085  push r11
00007ff1409db087  sub rsp, 0xF0
00007ff1409db08e  vmovaps [rsp], xmm0
00007ff1409db093  vmovaps [rsp+0x10], xmm1
00007ff1409db099  vmovaps [rsp+0x20], xmm2
00007ff1409db09f  vmovaps [rsp+0x30], xmm3
00007ff1409db0a5  vmovaps [rsp+0x40], xmm4
00007ff1409db0ab  vmovaps [rsp+0x50], xmm5
00007ff1409db0b1  vmovaps [rsp+0x60], xmm6
00007ff1409db0b7  vmovaps [rsp+0x70], xmm7
00007ff1409db0bd  vmovaps [rsp+0x80], xmm8
00007ff1409db0c6  vmovaps [rsp+0x90], xmm9
00007ff1409db0cf  vmovaps [rsp+0xA0], xmm10
00007ff1409db0d8  vmovaps [rsp+0xB0], xmm11
00007ff1409db0e1  vmovaps [rsp+0xC0], xmm12
00007ff1409db0ea  vmovaps [rsp+0xD0], xmm13
00007ff1409db0f3  vmovaps [rsp+0xE0], xmm14
00007ff1409db0fc  sub rsp, 0x30
00007ff1409db100  movaps [rsp], xmm15
00007ff1409db105  movaps [rsp+0x10], xmm5
00007ff1409db10a  movaps [rsp+0x20], xmm3
00007ff1409db10f  lea rdi, [rsp]
00007ff1409db113  mov esi, 0x00
00007ff1409db118  mov rax, 0x565C7F10C530
00007ff1409db122  call rax
00007ff1409db124  movaps xmm15, [rsp]
00007ff1409db129  add rsp, 0x30
00007ff1409db12d  vmovaps xmm0, [rsp]
00007ff1409db132  vmovaps xmm1, [rsp+0x10]
00007ff1409db138  vmovaps xmm2, [rsp+0x20]
00007ff1409db13e  vmovaps xmm3, [rsp+0x30]
00007ff1409db144  vmovaps xmm4, [rsp+0x40]
00007ff1409db14a  vmovaps xmm5, [rsp+0x50]
00007ff1409db150  vmovaps xmm6, [rsp+0x60]
00007ff1409db156  vmovaps xmm7, [rsp+0x70]
00007ff1409db15c  vmovaps xmm8, [rsp+0x80]
00007ff1409db165  vmovaps xmm9, [rsp+0x90]
00007ff1409db16e  vmovaps xmm10, [rsp+0xA0]
00007ff1409db177  vmovaps xmm11, [rsp+0xB0]
00007ff1409db180  vmovaps xmm12, [rsp+0xC0]
00007ff1409db189  vmovaps xmm13, [rsp+0xD0]
00007ff1409db192  vmovaps xmm14, [rsp+0xE0]
00007ff1409db19b  add rsp, 0xF0
00007ff1409db1a2  pop r11
00007ff1409db1a4  pop r10
00007ff1409db1a6  pop r9
00007ff1409db1a8  pop r8
00007ff1409db1aa  pop rsi
00007ff1409db1ab  pop rdi
00007ff1409db1ac  pop rdx
00007ff1409db1ad  pop rcx
00007ff1409db1ae  pop rax
00007ff1409db1af  add rsp, 0x08
00007ff1409db1b3  jmp 0x00007FF1409D90C6
00007ff1409db1b8  sub rsp, 0x08
00007ff1409db1bc  push rax
00007ff1409db1bd  push rcx
00007ff1409db1be  push rdx
00007ff1409db1bf  push rdi
00007ff1409db1c0  push rsi
00007ff1409db1c1  push r8
00007ff1409db1c3  push r9
00007ff1409db1c5  push r10
00007ff1409db1c7  push r11
00007ff1409db1c9  sub rsp, 0xF0
00007ff1409db1d0  vmovaps [rsp], xmm0
00007ff1409db1d5  vmovaps [rsp+0x10], xmm2
00007ff1409db1db  vmovaps [rsp+0x20], xmm3
00007ff1409db1e1  vmovaps [rsp+0x30], xmm4
00007ff1409db1e7  vmovaps [rsp+0x40], xmm5
00007ff1409db1ed  vmovaps [rsp+0x50], xmm6
00007ff1409db1f3  vmovaps [rsp+0x60], xmm7
00007ff1409db1f9  vmovaps [rsp+0x70], xmm8
00007ff1409db1ff  vmovaps [rsp+0x80], xmm9
00007ff1409db208  vmovaps [rsp+0x90], xmm10
00007ff1409db211  vmovaps [rsp+0xA0], xmm11
00007ff1409db21a  vmovaps [rsp+0xB0], xmm12
00007ff1409db223  vmovaps [rsp+0xC0], xmm13
00007ff1409db22c  vmovaps [rsp+0xD0], xmm14
00007ff1409db235  vmovaps [rsp+0xE0], xmm15
00007ff1409db23e  sub rsp, 0x30
00007ff1409db242  movaps [rsp], xmm1
00007ff1409db246  movaps [rsp+0x10], xmm5
00007ff1409db24b  movaps [rsp+0x20], xmm4
00007ff1409db250  lea rdi, [rsp]
00007ff1409db254  mov esi, 0x00
00007ff1409db259  mov rax, 0x565C7F10C530
00007ff1409db263  call rax
00007ff1409db265  movaps xmm1, [rsp]
00007ff1409db269  add rsp, 0x30
00007ff1409db26d  vmovaps xmm0, [rsp]
00007ff1409db272  vmovaps xmm2, [rsp+0x10]
00007ff1409db278  vmovaps xmm3, [rsp+0x20]
00007ff1409db27e  vmovaps xmm4, [rsp+0x30]
00007ff1409db284  vmovaps xmm5, [rsp+0x40]
00007ff1409db28a  vmovaps xmm6, [rsp+0x50]
00007ff1409db290  vmovaps xmm7, [rsp+0x60]
00007ff1409db296  vmovaps xmm8, [rsp+0x70]
00007ff1409db29c  vmovaps xmm9, [rsp+0x80]
00007ff1409db2a5  vmovaps xmm10, [rsp+0x90]
00007ff1409db2ae  vmovaps xmm11, [rsp+0xA0]
00007ff1409db2b7  vmovaps xmm12, [rsp+0xB0]
00007ff1409db2c0  vmovaps xmm13, [rsp+0xC0]
00007ff1409db2c9  vmovaps xmm14, [rsp+0xD0]
00007ff1409db2d2  vmovaps xmm15, [rsp+0xE0]
00007ff1409db2db  add rsp, 0xF0
00007ff1409db2e2  pop r11
00007ff1409db2e4  pop r10
00007ff1409db2e6  pop r9
00007ff1409db2e8  pop r8
00007ff1409db2ea  pop rsi
00007ff1409db2eb  pop rdi
00007ff1409db2ec  pop rdx
00007ff1409db2ed  pop rcx
00007ff1409db2ee  pop rax
00007ff1409db2ef  add rsp, 0x08
00007ff1409db2f3  jmp 0x00007FF1409D90E6
00007ff1409db2f8  sub rsp, 0x08
00007ff1409db2fc  push rax
00007ff1409db2fd  push rcx
00007ff1409db2fe  push rdx
00007ff1409db2ff  push rdi
00007ff1409db300  push rsi
00007ff1409db301  push r8
00007ff1409db303  push r9
00007ff1409db305  push r10
00007ff1409db307  push r11
00007ff1409db309  sub rsp, 0xF0
00007ff1409db310  vmovaps [rsp], xmm0
00007ff1409db315  vmovaps [rsp+0x10], xmm1
00007ff1409db31b  vmovaps [rsp+0x20], xmm2
00007ff1409db321  vmovaps [rsp+0x30], xmm3
00007ff1409db327  vmovaps [rsp+0x40], xmm5
00007ff1409db32d  vmovaps [rsp+0x50], xmm6
00007ff1409db333  vmovaps [rsp+0x60], xmm7
00007ff1409db339  vmovaps [rsp+0x70], xmm8
00007ff1409db33f  vmovaps [rsp+0x80], xmm9
00007ff1409db348  vmovaps [rsp+0x90], xmm10
00007ff1409db351  vmovaps [rsp+0xA0], xmm11
00007ff1409db35a  vmovaps [rsp+0xB0], xmm12
00007ff1409db363  vmovaps [rsp+0xC0], xmm13
00007ff1409db36c  vmovaps [rsp+0xD0], xmm14
00007ff1409db375  vmovaps [rsp+0xE0], xmm15
00007ff1409db37e  sub rsp, 0x30
00007ff1409db382  movaps [rsp], xmm4
00007ff1409db386  movaps [rsp+0x10], xmm3
00007ff1409db38b  movaps [rsp+0x20], xmm5
00007ff1409db390  lea rdi, [rsp]
00007ff1409db394  mov esi, 0x00
00007ff1409db399  mov rax, 0x565C7F10C530
00007ff1409db3a3  call rax
00007ff1409db3a5  movaps xmm4, [rsp]
00007ff1409db3a9  add rsp, 0x30
00007ff1409db3ad  vmovaps xmm0, [rsp]
00007ff1409db3b2  vmovaps xmm1, [rsp+0x10]
00007ff1409db3b8  vmovaps xmm2, [rsp+0x20]
00007ff1409db3be  vmovaps xmm3, [rsp+0x30]
00007ff1409db3c4  vmovaps xmm5, [rsp+0x40]
00007ff1409db3ca  vmovaps xmm6, [rsp+0x50]
00007ff1409db3d0  vmovaps xmm7, [rsp+0x60]
00007ff1409db3d6  vmovaps xmm8, [rsp+0x70]
00007ff1409db3dc  vmovaps xmm9, [rsp+0x80]
00007ff1409db3e5  vmovaps xmm10, [rsp+0x90]
00007ff1409db3ee  vmovaps xmm11, [rsp+0xA0]
00007ff1409db3f7  vmovaps xmm12, [rsp+0xB0]
00007ff1409db400  vmovaps xmm13, [rsp+0xC0]
00007ff1409db409  vmovaps xmm14, [rsp+0xD0]
00007ff1409db412  vmovaps xmm15, [rsp+0xE0]
00007ff1409db41b  add rsp, 0xF0
00007ff1409db422  pop r11
00007ff1409db424  pop r10
00007ff1409db426  pop r9
00007ff1409db428  pop r8
00007ff1409db42a  pop rsi
00007ff1409db42b  pop rdi
00007ff1409db42c  pop rdx
00007ff1409db42d  pop rcx
00007ff1409db42e  pop rax
00007ff1409db42f  add rsp, 0x08
00007ff1409db433  jmp 0x00007FF1409D9134
00007ff1409db438  call 0x00007FF1408D64F0
00007ff1409db43d  jmp 0x00007FF1409D9141
00007ff1409db442  sub rsp, 0x08
00007ff1409db446  push rax
00007ff1409db447  push rcx
00007ff1409db448  push rdx
00007ff1409db449  push rdi
00007ff1409db44a  push rsi
00007ff1409db44b  push r8
00007ff1409db44d  push r9
00007ff1409db44f  push r10
00007ff1409db451  push r11
00007ff1409db453  sub rsp, 0xF0
00007ff1409db45a  vmovaps [rsp], xmm0
00007ff1409db45f  vmovaps [rsp+0x10], xmm1
00007ff1409db465  vmovaps [rsp+0x20], xmm2
00007ff1409db46b  vmovaps [rsp+0x30], xmm3
00007ff1409db471  vmovaps [rsp+0x40], xmm4
00007ff1409db477  vmovaps [rsp+0x50], xmm6
00007ff1409db47d  vmovaps [rsp+0x60], xmm7
00007ff1409db483  vmovaps [rsp+0x70], xmm8
00007ff1409db489  vmovaps [rsp+0x80], xmm9
00007ff1409db492  vmovaps [rsp+0x90], xmm10
00007ff1409db49b  vmovaps [rsp+0xA0], xmm11
00007ff1409db4a4  vmovaps [rsp+0xB0], xmm12
00007ff1409db4ad  vmovaps [rsp+0xC0], xmm13
00007ff1409db4b6  vmovaps [rsp+0xD0], xmm14
00007ff1409db4bf  vmovaps [rsp+0xE0], xmm15
00007ff1409db4c8  sub rsp, 0x30
00007ff1409db4cc  movaps [rsp], xmm5
00007ff1409db4d0  movaps [rsp+0x10], xmm6
00007ff1409db4d5  movaps [rsp+0x20], xmm3
00007ff1409db4da  lea rdi, [rsp]
00007ff1409db4de  mov esi, 0x00
00007ff1409db4e3  mov rax, 0x565C7F10C530
00007ff1409db4ed  call rax
00007ff1409db4ef  movaps xmm5, [rsp]
00007ff1409db4f3  add rsp, 0x30
00007ff1409db4f7  vmovaps xmm0, [rsp]
00007ff1409db4fc  vmovaps xmm1, [rsp+0x10]
00007ff1409db502  vmovaps xmm2, [rsp+0x20]
00007ff1409db508  vmovaps xmm3, [rsp+0x30]
00007ff1409db50e  vmovaps xmm4, [rsp+0x40]
00007ff1409db514  vmovaps xmm6, [rsp+0x50]
00007ff1409db51a  vmovaps xmm7, [rsp+0x60]
00007ff1409db520  vmovaps xmm8, [rsp+0x70]
00007ff1409db526  vmovaps xmm9, [rsp+0x80]
00007ff1409db52f  vmovaps xmm10, [rsp+0x90]
00007ff1409db538  vmovaps xmm11, [rsp+0xA0]
00007ff1409db541  vmovaps xmm12, [rsp+0xB0]
00007ff1409db54a  vmovaps xmm13, [rsp+0xC0]
00007ff1409db553  vmovaps xmm14, [rsp+0xD0]
00007ff1409db55c  vmovaps xmm15, [rsp+0xE0]
00007ff1409db565  add rsp, 0xF0
00007ff1409db56c  pop r11
00007ff1409db56e  pop r10
00007ff1409db570  pop r9
00007ff1409db572  pop r8
00007ff1409db574  pop rsi
00007ff1409db575  pop rdi
00007ff1409db576  pop rdx
00007ff1409db577  pop rcx
00007ff1409db578  pop rax
00007ff1409db579  add rsp, 0x08
00007ff1409db57d  jmp 0x00007FF1409D9167
00007ff1409db582  sub rsp, 0x08
00007ff1409db586  push rax
00007ff1409db587  push rcx
00007ff1409db588  push rdx
00007ff1409db589  push rdi
00007ff1409db58a  push rsi
00007ff1409db58b  push r8
00007ff1409db58d  push r9
00007ff1409db58f  push r10
00007ff1409db591  push r11
00007ff1409db593  sub rsp, 0xF0
00007ff1409db59a  vmovaps [rsp], xmm0
00007ff1409db59f  vmovaps [rsp+0x10], xmm1
00007ff1409db5a5  vmovaps [rsp+0x20], xmm2
00007ff1409db5ab  vmovaps [rsp+0x30], xmm3
00007ff1409db5b1  vmovaps [rsp+0x40], xmm4
00007ff1409db5b7  vmovaps [rsp+0x50], xmm5
00007ff1409db5bd  vmovaps [rsp+0x60], xmm7
00007ff1409db5c3  vmovaps [rsp+0x70], xmm8
00007ff1409db5c9  vmovaps [rsp+0x80], xmm9
00007ff1409db5d2  vmovaps [rsp+0x90], xmm10
00007ff1409db5db  vmovaps [rsp+0xA0], xmm11
00007ff1409db5e4  vmovaps [rsp+0xB0], xmm12
00007ff1409db5ed  vmovaps [rsp+0xC0], xmm13
00007ff1409db5f6  vmovaps [rsp+0xD0], xmm14
00007ff1409db5ff  vmovaps [rsp+0xE0], xmm15
00007ff1409db608  sub rsp, 0x30
00007ff1409db60c  movaps [rsp], xmm6
00007ff1409db610  movaps [rsp+0x10], xmm9
00007ff1409db616  movaps [rsp+0x20], xmm1
00007ff1409db61b  lea rdi, [rsp]
00007ff1409db61f  mov esi, 0x00
00007ff1409db624  mov rax, 0x565C7F10C530
00007ff1409db62e  call rax
00007ff1409db630  movaps xmm6, [rsp]
00007ff1409db634  add rsp, 0x30
00007ff1409db638  vmovaps xmm0, [rsp]
00007ff1409db63d  vmovaps xmm1, [rsp+0x10]
00007ff1409db643  vmovaps xmm2, [rsp+0x20]
00007ff1409db649  vmovaps xmm3, [rsp+0x30]
00007ff1409db64f  vmovaps xmm4, [rsp+0x40]
00007ff1409db655  vmovaps xmm5, [rsp+0x50]
00007ff1409db65b  vmovaps xmm7, [rsp+0x60]
00007ff1409db661  vmovaps xmm8, [rsp+0x70]
00007ff1409db667  vmovaps xmm9, [rsp+0x80]
00007ff1409db670  vmovaps xmm10, [rsp+0x90]
00007ff1409db679  vmovaps xmm11, [rsp+0xA0]
00007ff1409db682  vmovaps xmm12, [rsp+0xB0]
00007ff1409db68b  vmovaps xmm13, [rsp+0xC0]
00007ff1409db694  vmovaps xmm14, [rsp+0xD0]
00007ff1409db69d  vmovaps xmm15, [rsp+0xE0]
00007ff1409db6a6  add rsp, 0xF0
00007ff1409db6ad  pop r11
00007ff1409db6af  pop r10
00007ff1409db6b1  pop r9
00007ff1409db6b3  pop r8
00007ff1409db6b5  pop rsi
00007ff1409db6b6  pop rdi
00007ff1409db6b7  pop rdx
00007ff1409db6b8  pop rcx
00007ff1409db6b9  pop rax
00007ff1409db6ba  add rsp, 0x08
00007ff1409db6be  jmp 0x00007FF1409D918B
00007ff1409db6c3  sub rsp, 0x08
00007ff1409db6c7  push rax
00007ff1409db6c8  push rcx
00007ff1409db6c9  push rdx
00007ff1409db6ca  push rdi
00007ff1409db6cb  push rsi
00007ff1409db6cc  push r8
00007ff1409db6ce  push r9
00007ff1409db6d0  push r10
00007ff1409db6d2  push r11
00007ff1409db6d4  sub rsp, 0xF0
00007ff1409db6db  vmovaps [rsp], xmm0
00007ff1409db6e0  vmovaps [rsp+0x10], xmm1
00007ff1409db6e6  vmovaps [rsp+0x20], xmm2
00007ff1409db6ec  vmovaps [rsp+0x30], xmm3
00007ff1409db6f2  vmovaps [rsp+0x40], xmm4
00007ff1409db6f8  vmovaps [rsp+0x50], xmm5
00007ff1409db6fe  vmovaps [rsp+0x60], xmm6
00007ff1409db704  vmovaps [rsp+0x70], xmm7
00007ff1409db70a  vmovaps [rsp+0x80], xmm8
00007ff1409db713  vmovaps [rsp+0x90], xmm10
00007ff1409db71c  vmovaps [rsp+0xA0], xmm11
00007ff1409db725  vmovaps [rsp+0xB0], xmm12
00007ff1409db72e  vmovaps [rsp+0xC0], xmm13
00007ff1409db737  vmovaps [rsp+0xD0], xmm14
00007ff1409db740  vmovaps [rsp+0xE0], xmm15
00007ff1409db749  sub rsp, 0x30
00007ff1409db74d  movaps [rsp], xmm9
00007ff1409db752  movaps [rsp+0x10], xmm3
00007ff1409db757  movaps [rsp+0x20], xmm1
00007ff1409db75c  lea rdi, [rsp]
00007ff1409db760  mov esi, 0x00
00007ff1409db765  mov rax, 0x565C7F10C530
00007ff1409db76f  call rax
00007ff1409db771  movaps xmm9, [rsp]
00007ff1409db776  add rsp, 0x30
00007ff1409db77a  vmovaps xmm0, [rsp]
00007ff1409db77f  vmovaps xmm1, [rsp+0x10]
00007ff1409db785  vmovaps xmm2, [rsp+0x20]
00007ff1409db78b  vmovaps xmm3, [rsp+0x30]
00007ff1409db791  vmovaps xmm4, [rsp+0x40]
00007ff1409db797  vmovaps xmm5, [rsp+0x50]
00007ff1409db79d  vmovaps xmm6, [rsp+0x60]
00007ff1409db7a3  vmovaps xmm7, [rsp+0x70]
00007ff1409db7a9  vmovaps xmm8, [rsp+0x80]
00007ff1409db7b2  vmovaps xmm10, [rsp+0x90]
00007ff1409db7bb  vmovaps xmm11, [rsp+0xA0]
00007ff1409db7c4  vmovaps xmm12, [rsp+0xB0]
00007ff1409db7cd  vmovaps xmm13, [rsp+0xC0]
00007ff1409db7d6  vmovaps xmm14, [rsp+0xD0]
00007ff1409db7df  vmovaps xmm15, [rsp+0xE0]
00007ff1409db7e8  add rsp, 0xF0
00007ff1409db7ef  pop r11
00007ff1409db7f1  pop r10
00007ff1409db7f3  pop r9
00007ff1409db7f5  pop r8
00007ff1409db7f7  pop rsi
00007ff1409db7f8  pop rdi
00007ff1409db7f9  pop rdx
00007ff1409db7fa  pop rcx
00007ff1409db7fb  pop rax
00007ff1409db7fc  add rsp, 0x08
00007ff1409db800  jmp 0x00007FF1409D91D7
00007ff1409db805  call 0x00007FF1408D64F0
00007ff1409db80a  jmp 0x00007FF1409D91E4
00007ff1409db80f  sub rsp, 0x08
00007ff1409db813  push rax
00007ff1409db814  push rcx
00007ff1409db815  push rdx
00007ff1409db816  push rdi
00007ff1409db817  push rsi
00007ff1409db818  push r8
00007ff1409db81a  push r9
00007ff1409db81c  push r10
00007ff1409db81e  push r11
00007ff1409db820  sub rsp, 0xF0
00007ff1409db827  vmovaps [rsp], xmm0
00007ff1409db82c  vmovaps [rsp+0x10], xmm1
00007ff1409db832  vmovaps [rsp+0x20], xmm2
00007ff1409db838  vmovaps [rsp+0x30], xmm3
00007ff1409db83e  vmovaps [rsp+0x40], xmm4
00007ff1409db844  vmovaps [rsp+0x50], xmm5
00007ff1409db84a  vmovaps [rsp+0x60], xmm6
00007ff1409db850  vmovaps [rsp+0x70], xmm7
00007ff1409db856  vmovaps [rsp+0x80], xmm8
00007ff1409db85f  vmovaps [rsp+0x90], xmm9
00007ff1409db868  vmovaps [rsp+0xA0], xmm10
00007ff1409db871  vmovaps [rsp+0xB0], xmm11
00007ff1409db87a  vmovaps [rsp+0xC0], xmm12
00007ff1409db883  vmovaps [rsp+0xD0], xmm13
00007ff1409db88c  vmovaps [rsp+0xE0], xmm14
00007ff1409db895  sub rsp, 0x30
00007ff1409db899  movaps [rsp], xmm15
00007ff1409db89e  movaps [rsp+0x10], xmm3
00007ff1409db8a3  movaps [rsp+0x20], xmm7
00007ff1409db8a8  lea rdi, [rsp]
00007ff1409db8ac  mov esi, 0x00
00007ff1409db8b1  mov rax, 0x565C7F10C530
00007ff1409db8bb  call rax
00007ff1409db8bd  movaps xmm15, [rsp]
00007ff1409db8c2  add rsp, 0x30
00007ff1409db8c6  vmovaps xmm0, [rsp]
00007ff1409db8cb  vmovaps xmm1, [rsp+0x10]
00007ff1409db8d1  vmovaps xmm2, [rsp+0x20]
00007ff1409db8d7  vmovaps xmm3, [rsp+0x30]
00007ff1409db8dd  vmovaps xmm4, [rsp+0x40]
00007ff1409db8e3  vmovaps xmm5, [rsp+0x50]
00007ff1409db8e9  vmovaps xmm6, [rsp+0x60]
00007ff1409db8ef  vmovaps xmm7, [rsp+0x70]
00007ff1409db8f5  vmovaps xmm8, [rsp+0x80]
00007ff1409db8fe  vmovaps xmm9, [rsp+0x90]
00007ff1409db907  vmovaps xmm10, [rsp+0xA0]
00007ff1409db910  vmovaps xmm11, [rsp+0xB0]
00007ff1409db919  vmovaps xmm12, [rsp+0xC0]
00007ff1409db922  vmovaps xmm13, [rsp+0xD0]
00007ff1409db92b  vmovaps xmm14, [rsp+0xE0]
00007ff1409db934  add rsp, 0xF0
00007ff1409db93b  pop r11
00007ff1409db93d  pop r10
00007ff1409db93f  pop r9
00007ff1409db941  pop r8
00007ff1409db943  pop rsi
00007ff1409db944  pop rdi
00007ff1409db945  pop rdx
00007ff1409db946  pop rcx
00007ff1409db947  pop rax
00007ff1409db948  add rsp, 0x08
00007ff1409db94c  jmp 0x00007FF1409D9210
00007ff1409db951  sub rsp, 0x08
00007ff1409db955  push rax
00007ff1409db956  push rcx
00007ff1409db957  push rdx
00007ff1409db958  push rdi
00007ff1409db959  push rsi
00007ff1409db95a  push r8
00007ff1409db95c  push r9
00007ff1409db95e  push r10
00007ff1409db960  push r11
00007ff1409db962  sub rsp, 0xF0
00007ff1409db969  vmovaps [rsp], xmm0
00007ff1409db96e  vmovaps [rsp+0x10], xmm1
00007ff1409db974  vmovaps [rsp+0x20], xmm2
00007ff1409db97a  vmovaps [rsp+0x30], xmm4
00007ff1409db980  vmovaps [rsp+0x40], xmm5
00007ff1409db986  vmovaps [rsp+0x50], xmm6
00007ff1409db98c  vmovaps [rsp+0x60], xmm7
00007ff1409db992  vmovaps [rsp+0x70], xmm8
00007ff1409db998  vmovaps [rsp+0x80], xmm9
00007ff1409db9a1  vmovaps [rsp+0x90], xmm10
00007ff1409db9aa  vmovaps [rsp+0xA0], xmm11
00007ff1409db9b3  vmovaps [rsp+0xB0], xmm12
00007ff1409db9bc  vmovaps [rsp+0xC0], xmm13
00007ff1409db9c5  vmovaps [rsp+0xD0], xmm14
00007ff1409db9ce  vmovaps [rsp+0xE0], xmm15
00007ff1409db9d7  sub rsp, 0x30
00007ff1409db9db  movaps [rsp], xmm3
00007ff1409db9df  movaps [rsp+0x10], xmm1
00007ff1409db9e4  movaps [rsp+0x20], xmm15
00007ff1409db9ea  lea rdi, [rsp]
00007ff1409db9ee  mov esi, 0x00
00007ff1409db9f3  mov rax, 0x565C7F10C530
00007ff1409db9fd  call rax
00007ff1409db9ff  movaps xmm3, [rsp]
00007ff1409dba03  add rsp, 0x30
00007ff1409dba07  vmovaps xmm0, [rsp]
00007ff1409dba0c  vmovaps xmm1, [rsp+0x10]
00007ff1409dba12  vmovaps xmm2, [rsp+0x20]
00007ff1409dba18  vmovaps xmm4, [rsp+0x30]
00007ff1409dba1e  vmovaps xmm5, [rsp+0x40]
00007ff1409dba24  vmovaps xmm6, [rsp+0x50]
00007ff1409dba2a  vmovaps xmm7, [rsp+0x60]
00007ff1409dba30  vmovaps xmm8, [rsp+0x70]
00007ff1409dba36  vmovaps xmm9, [rsp+0x80]
00007ff1409dba3f  vmovaps xmm10, [rsp+0x90]
00007ff1409dba48  vmovaps xmm11, [rsp+0xA0]
00007ff1409dba51  vmovaps xmm12, [rsp+0xB0]
00007ff1409dba5a  vmovaps xmm13, [rsp+0xC0]
00007ff1409dba63  vmovaps xmm14, [rsp+0xD0]
00007ff1409dba6c  vmovaps xmm15, [rsp+0xE0]
00007ff1409dba75  add rsp, 0xF0
00007ff1409dba7c  pop r11
00007ff1409dba7e  pop r10
00007ff1409dba80  pop r9
00007ff1409dba82  pop r8
00007ff1409dba84  pop rsi
00007ff1409dba85  pop rdi
00007ff1409dba86  pop rdx
00007ff1409dba87  pop rcx
00007ff1409dba88  pop rax
00007ff1409dba89  add rsp, 0x08
00007ff1409dba8d  jmp 0x00007FF1409D929F
00007ff1409dba92  call 0x00007FF1408D64F0
00007ff1409dba97  jmp 0x00007FF1409D92A9
00007ff1409dba9c  sub rsp, 0x08
00007ff1409dbaa0  push rax
00007ff1409dbaa1  push rcx
00007ff1409dbaa2  push rdx
00007ff1409dbaa3  push rdi
00007ff1409dbaa4  push rsi
00007ff1409dbaa5  push r8
00007ff1409dbaa7  push r9
00007ff1409dbaa9  push r10
00007ff1409dbaab  push r11
00007ff1409dbaad  sub rsp, 0xF0
00007ff1409dbab4  vmovaps [rsp], xmm0
00007ff1409dbab9  vmovaps [rsp+0x10], xmm1
00007ff1409dbabf  vmovaps [rsp+0x20], xmm2
00007ff1409dbac5  vmovaps [rsp+0x30], xmm3
00007ff1409dbacb  vmovaps [rsp+0x40], xmm4
00007ff1409dbad1  vmovaps [rsp+0x50], xmm5
00007ff1409dbad7  vmovaps [rsp+0x60], xmm6
00007ff1409dbadd  vmovaps [rsp+0x70], xmm7
00007ff1409dbae3  vmovaps [rsp+0x80], xmm8
00007ff1409dbaec  vmovaps [rsp+0x90], xmm9
00007ff1409dbaf5  vmovaps [rsp+0xA0], xmm10
00007ff1409dbafe  vmovaps [rsp+0xB0], xmm11
00007ff1409dbb07  vmovaps [rsp+0xC0], xmm12
00007ff1409dbb10  vmovaps [rsp+0xD0], xmm13
00007ff1409dbb19  vmovaps [rsp+0xE0], xmm14
00007ff1409dbb22  sub rsp, 0x30
00007ff1409dbb26  movaps [rsp], xmm15
00007ff1409dbb2b  movaps [rsp+0x10], xmm14
00007ff1409dbb31  movaps [rsp+0x20], xmm4
00007ff1409dbb36  lea rdi, [rsp]
00007ff1409dbb3a  mov esi, 0x00
00007ff1409dbb3f  mov rax, 0x565C7F10C530
00007ff1409dbb49  call rax
00007ff1409dbb4b  movaps xmm15, [rsp]
00007ff1409dbb50  add rsp, 0x30
00007ff1409dbb54  vmovaps xmm0, [rsp]
00007ff1409dbb59  vmovaps xmm1, [rsp+0x10]
00007ff1409dbb5f  vmovaps xmm2, [rsp+0x20]
00007ff1409dbb65  vmovaps xmm3, [rsp+0x30]
00007ff1409dbb6b  vmovaps xmm4, [rsp+0x40]
00007ff1409dbb71  vmovaps xmm5, [rsp+0x50]
00007ff1409dbb77  vmovaps xmm6, [rsp+0x60]
00007ff1409dbb7d  vmovaps xmm7, [rsp+0x70]
00007ff1409dbb83  vmovaps xmm8, [rsp+0x80]
00007ff1409dbb8c  vmovaps xmm9, [rsp+0x90]
00007ff1409dbb95  vmovaps xmm10, [rsp+0xA0]
00007ff1409dbb9e  vmovaps xmm11, [rsp+0xB0]
00007ff1409dbba7  vmovaps xmm12, [rsp+0xC0]
00007ff1409dbbb0  vmovaps xmm13, [rsp+0xD0]
00007ff1409dbbb9  vmovaps xmm14, [rsp+0xE0]
00007ff1409dbbc2  add rsp, 0xF0
00007ff1409dbbc9  pop r11
00007ff1409dbbcb  pop r10
00007ff1409dbbcd  pop r9
00007ff1409dbbcf  pop r8
00007ff1409dbbd1  pop rsi
00007ff1409dbbd2  pop rdi
00007ff1409dbbd3  pop rdx
00007ff1409dbbd4  pop rcx
00007ff1409dbbd5  pop rax
00007ff1409dbbd6  add rsp, 0x08
00007ff1409dbbda  jmp 0x00007FF1409D92D7
00007ff1409dbbdf  sub rsp, 0x08
00007ff1409dbbe3  push rax
00007ff1409dbbe4  push rcx
00007ff1409dbbe5  push rdx
00007ff1409dbbe6  push rdi
00007ff1409dbbe7  push rsi
00007ff1409dbbe8  push r8
00007ff1409dbbea  push r9
00007ff1409dbbec  push r10
00007ff1409dbbee  push r11
00007ff1409dbbf0  sub rsp, 0xF0
00007ff1409dbbf7  vmovaps [rsp], xmm0
00007ff1409dbbfc  vmovaps [rsp+0x10], xmm1
00007ff1409dbc02  vmovaps [rsp+0x20], xmm2
00007ff1409dbc08  vmovaps [rsp+0x30], xmm3
00007ff1409dbc0e  vmovaps [rsp+0x40], xmm4
00007ff1409dbc14  vmovaps [rsp+0x50], xmm5
00007ff1409dbc1a  vmovaps [rsp+0x60], xmm6
00007ff1409dbc20  vmovaps [rsp+0x70], xmm7
00007ff1409dbc26  vmovaps [rsp+0x80], xmm8
00007ff1409dbc2f  vmovaps [rsp+0x90], xmm9
00007ff1409dbc38  vmovaps [rsp+0xA0], xmm10
00007ff1409dbc41  vmovaps [rsp+0xB0], xmm11
00007ff1409dbc4a  vmovaps [rsp+0xC0], xmm12
00007ff1409dbc53  vmovaps [rsp+0xD0], xmm13
00007ff1409dbc5c  vmovaps [rsp+0xE0], xmm15
00007ff1409dbc65  sub rsp, 0x30
00007ff1409dbc69  movaps [rsp], xmm14
00007ff1409dbc6e  movaps [rsp+0x10], xmm2
00007ff1409dbc73  movaps [rsp+0x20], xmm1
00007ff1409dbc78  lea rdi, [rsp]
00007ff1409dbc7c  mov esi, 0x00
00007ff1409dbc81  mov rax, 0x565C7F10C530
00007ff1409dbc8b  call rax
00007ff1409dbc8d  movaps xmm14, [rsp]
00007ff1409dbc92  add rsp, 0x30
00007ff1409dbc96  vmovaps xmm0, [rsp]
00007ff1409dbc9b  vmovaps xmm1, [rsp+0x10]
00007ff1409dbca1  vmovaps xmm2, [rsp+0x20]
00007ff1409dbca7  vmovaps xmm3, [rsp+0x30]
00007ff1409dbcad  vmovaps xmm4, [rsp+0x40]
00007ff1409dbcb3  vmovaps xmm5, [rsp+0x50]
00007ff1409dbcb9  vmovaps xmm6, [rsp+0x60]
00007ff1409dbcbf  vmovaps xmm7, [rsp+0x70]
00007ff1409dbcc5  vmovaps xmm8, [rsp+0x80]
00007ff1409dbcce  vmovaps xmm9, [rsp+0x90]
00007ff1409dbcd7  vmovaps xmm10, [rsp+0xA0]
00007ff1409dbce0  vmovaps xmm11, [rsp+0xB0]
00007ff1409dbce9  vmovaps xmm12, [rsp+0xC0]
00007ff1409dbcf2  vmovaps xmm13, [rsp+0xD0]
00007ff1409dbcfb  vmovaps xmm15, [rsp+0xE0]
00007ff1409dbd04  add rsp, 0xF0
00007ff1409dbd0b  pop r11
00007ff1409dbd0d  pop r10
00007ff1409dbd0f  pop r9
00007ff1409dbd11  pop r8
00007ff1409dbd13  pop rsi
00007ff1409dbd14  pop rdi
00007ff1409dbd15  pop rdx
00007ff1409dbd16  pop rcx
00007ff1409dbd17  pop rax
00007ff1409dbd18  add rsp, 0x08
00007ff1409dbd1c  jmp 0x00007FF1409D92FD
00007ff1409dbd21  sub rsp, 0x08
00007ff1409dbd25  push rax
00007ff1409dbd26  push rcx
00007ff1409dbd27  push rdx
00007ff1409dbd28  push rdi
00007ff1409dbd29  push rsi
00007ff1409dbd2a  push r8
00007ff1409dbd2c  push r9
00007ff1409dbd2e  push r10
00007ff1409dbd30  push r11
00007ff1409dbd32  sub rsp, 0xF0
00007ff1409dbd39  vmovaps [rsp], xmm0
00007ff1409dbd3e  vmovaps [rsp+0x10], xmm2
00007ff1409dbd44  vmovaps [rsp+0x20], xmm3
00007ff1409dbd4a  vmovaps [rsp+0x30], xmm4
00007ff1409dbd50  vmovaps [rsp+0x40], xmm5
00007ff1409dbd56  vmovaps [rsp+0x50], xmm6
00007ff1409dbd5c  vmovaps [rsp+0x60], xmm7
00007ff1409dbd62  vmovaps [rsp+0x70], xmm8
00007ff1409dbd68  vmovaps [rsp+0x80], xmm9
00007ff1409dbd71  vmovaps [rsp+0x90], xmm10
00007ff1409dbd7a  vmovaps [rsp+0xA0], xmm11
00007ff1409dbd83  vmovaps [rsp+0xB0], xmm12
00007ff1409dbd8c  vmovaps [rsp+0xC0], xmm13
00007ff1409dbd95  vmovaps [rsp+0xD0], xmm14
00007ff1409dbd9e  vmovaps [rsp+0xE0], xmm15
00007ff1409dbda7  sub rsp, 0x30
00007ff1409dbdab  movaps [rsp], xmm1
00007ff1409dbdaf  movaps [rsp+0x10], xmm4
00007ff1409dbdb4  movaps [rsp+0x20], xmm9
00007ff1409dbdba  lea rdi, [rsp]
00007ff1409dbdbe  mov esi, 0x00
00007ff1409dbdc3  mov rax, 0x565C7F10C530
00007ff1409dbdcd  call rax
00007ff1409dbdcf  movaps xmm1, [rsp]
00007ff1409dbdd3  add rsp, 0x30
00007ff1409dbdd7  vmovaps xmm0, [rsp]
00007ff1409dbddc  vmovaps xmm2, [rsp+0x10]
00007ff1409dbde2  vmovaps xmm3, [rsp+0x20]
00007ff1409dbde8  vmovaps xmm4, [rsp+0x30]
00007ff1409dbdee  vmovaps xmm5, [rsp+0x40]
00007ff1409dbdf4  vmovaps xmm6, [rsp+0x50]
00007ff1409dbdfa  vmovaps xmm7, [rsp+0x60]
00007ff1409dbe00  vmovaps xmm8, [rsp+0x70]
00007ff1409dbe06  vmovaps xmm9, [rsp+0x80]
00007ff1409dbe0f  vmovaps xmm10, [rsp+0x90]
00007ff1409dbe18  vmovaps xmm11, [rsp+0xA0]
00007ff1409dbe21  vmovaps xmm12, [rsp+0xB0]
00007ff1409dbe2a  vmovaps xmm13, [rsp+0xC0]
00007ff1409dbe33  vmovaps xmm14, [rsp+0xD0]
00007ff1409dbe3c  vmovaps xmm15, [rsp+0xE0]
00007ff1409dbe45  add rsp, 0xF0
00007ff1409dbe4c  pop r11
00007ff1409dbe4e  pop r10
00007ff1409dbe50  pop r9
00007ff1409dbe52  pop r8
00007ff1409dbe54  pop rsi
00007ff1409dbe55  pop rdi
00007ff1409dbe56  pop rdx
00007ff1409dbe57  pop rcx
00007ff1409dbe58  pop rax
00007ff1409dbe59  add rsp, 0x08
00007ff1409dbe5d  jmp 0x00007FF1409D931B
00007ff1409dbe62  sub rsp, 0x08
00007ff1409dbe66  push rax
00007ff1409dbe67  push rcx
00007ff1409dbe68  push rdx
00007ff1409dbe69  push rdi
00007ff1409dbe6a  push rsi
00007ff1409dbe6b  push r8
00007ff1409dbe6d  push r9
00007ff1409dbe6f  push r10
00007ff1409dbe71  push r11
00007ff1409dbe73  sub rsp, 0xF0
00007ff1409dbe7a  vmovaps [rsp], xmm0
00007ff1409dbe7f  vmovaps [rsp+0x10], xmm1
00007ff1409dbe85  vmovaps [rsp+0x20], xmm2
00007ff1409dbe8b  vmovaps [rsp+0x30], xmm3
00007ff1409dbe91  vmovaps [rsp+0x40], xmm5
00007ff1409dbe97  vmovaps [rsp+0x50], xmm6
00007ff1409dbe9d  vmovaps [rsp+0x60], xmm7
00007ff1409dbea3  vmovaps [rsp+0x70], xmm8
00007ff1409dbea9  vmovaps [rsp+0x80], xmm9
00007ff1409dbeb2  vmovaps [rsp+0x90], xmm10
00007ff1409dbebb  vmovaps [rsp+0xA0], xmm11
00007ff1409dbec4  vmovaps [rsp+0xB0], xmm12
00007ff1409dbecd  vmovaps [rsp+0xC0], xmm13
00007ff1409dbed6  vmovaps [rsp+0xD0], xmm14
00007ff1409dbedf  vmovaps [rsp+0xE0], xmm15
00007ff1409dbee8  sub rsp, 0x30
00007ff1409dbeec  movaps [rsp], xmm4
00007ff1409dbef0  movaps [rsp+0x10], xmm2
00007ff1409dbef5  movaps [rsp+0x20], xmm9
00007ff1409dbefb  lea rdi, [rsp]
00007ff1409dbeff  mov esi, 0x00
00007ff1409dbf04  mov rax, 0x565C7F10C530
00007ff1409dbf0e  call rax
00007ff1409dbf10  movaps xmm4, [rsp]
00007ff1409dbf14  add rsp, 0x30
00007ff1409dbf18  vmovaps xmm0, [rsp]
00007ff1409dbf1d  vmovaps xmm1, [rsp+0x10]
00007ff1409dbf23  vmovaps xmm2, [rsp+0x20]
00007ff1409dbf29  vmovaps xmm3, [rsp+0x30]
00007ff1409dbf2f  vmovaps xmm5, [rsp+0x40]
00007ff1409dbf35  vmovaps xmm6, [rsp+0x50]
00007ff1409dbf3b  vmovaps xmm7, [rsp+0x60]
00007ff1409dbf41  vmovaps xmm8, [rsp+0x70]
00007ff1409dbf47  vmovaps xmm9, [rsp+0x80]
00007ff1409dbf50  vmovaps xmm10, [rsp+0x90]
00007ff1409dbf59  vmovaps xmm11, [rsp+0xA0]
00007ff1409dbf62  vmovaps xmm12, [rsp+0xB0]
00007ff1409dbf6b  vmovaps xmm13, [rsp+0xC0]
00007ff1409dbf74  vmovaps xmm14, [rsp+0xD0]
00007ff1409dbf7d  vmovaps xmm15, [rsp+0xE0]
00007ff1409dbf86  add rsp, 0xF0
00007ff1409dbf8d  pop r11
00007ff1409dbf8f  pop r10
00007ff1409dbf91  pop r9
00007ff1409dbf93  pop r8
00007ff1409dbf95  pop rsi
00007ff1409dbf96  pop rdi
00007ff1409dbf97  pop rdx
00007ff1409dbf98  pop rcx
00007ff1409dbf99  pop rax
00007ff1409dbf9a  add rsp, 0x08
00007ff1409dbf9e  jmp 0x00007FF1409D934B
00007ff1409dbfa3  sub rsp, 0x08
00007ff1409dbfa7  push rax
00007ff1409dbfa8  push rcx
00007ff1409dbfa9  push rdx
00007ff1409dbfaa  push rdi
00007ff1409dbfab  push rsi
00007ff1409dbfac  push r8
00007ff1409dbfae  push r9
00007ff1409dbfb0  push r10
00007ff1409dbfb2  push r11
00007ff1409dbfb4  sub rsp, 0xF0
00007ff1409dbfbb  vmovaps [rsp], xmm0
00007ff1409dbfc0  vmovaps [rsp+0x10], xmm1
00007ff1409dbfc6  vmovaps [rsp+0x20], xmm2
00007ff1409dbfcc  vmovaps [rsp+0x30], xmm3
00007ff1409dbfd2  vmovaps [rsp+0x40], xmm4
00007ff1409dbfd8  vmovaps [rsp+0x50], xmm5
00007ff1409dbfde  vmovaps [rsp+0x60], xmm6
00007ff1409dbfe4  vmovaps [rsp+0x70], xmm7
00007ff1409dbfea  vmovaps [rsp+0x80], xmm8
00007ff1409dbff3  vmovaps [rsp+0x90], xmm10
00007ff1409dbffc  vmovaps [rsp+0xA0], xmm11
00007ff1409dc005  vmovaps [rsp+0xB0], xmm12
00007ff1409dc00e  vmovaps [rsp+0xC0], xmm13
00007ff1409dc017  vmovaps [rsp+0xD0], xmm14
00007ff1409dc020  vmovaps [rsp+0xE0], xmm15
00007ff1409dc029  sub rsp, 0x30
00007ff1409dc02d  movaps [rsp], xmm9
00007ff1409dc032  movaps [rsp+0x10], xmm2
00007ff1409dc037  movaps [rsp+0x20], xmm1
00007ff1409dc03c  lea rdi, [rsp]
00007ff1409dc040  mov esi, 0x00
00007ff1409dc045  mov rax, 0x565C7F10C530
00007ff1409dc04f  call rax
00007ff1409dc051  movaps xmm9, [rsp]
00007ff1409dc056  add rsp, 0x30
00007ff1409dc05a  vmovaps xmm0, [rsp]
00007ff1409dc05f  vmovaps xmm1, [rsp+0x10]
00007ff1409dc065  vmovaps xmm2, [rsp+0x20]
00007ff1409dc06b  vmovaps xmm3, [rsp+0x30]
00007ff1409dc071  vmovaps xmm4, [rsp+0x40]
00007ff1409dc077  vmovaps xmm5, [rsp+0x50]
00007ff1409dc07d  vmovaps xmm6, [rsp+0x60]
00007ff1409dc083  vmovaps xmm7, [rsp+0x70]
00007ff1409dc089  vmovaps xmm8, [rsp+0x80]
00007ff1409dc092  vmovaps xmm10, [rsp+0x90]
00007ff1409dc09b  vmovaps xmm11, [rsp+0xA0]
00007ff1409dc0a4  vmovaps xmm12, [rsp+0xB0]
00007ff1409dc0ad  vmovaps xmm13, [rsp+0xC0]
00007ff1409dc0b6  vmovaps xmm14, [rsp+0xD0]
00007ff1409dc0bf  vmovaps xmm15, [rsp+0xE0]
00007ff1409dc0c8  add rsp, 0xF0
00007ff1409dc0cf  pop r11
00007ff1409dc0d1  pop r10
00007ff1409dc0d3  pop r9
00007ff1409dc0d5  pop r8
00007ff1409dc0d7  pop rsi
00007ff1409dc0d8  pop rdi
00007ff1409dc0d9  pop rdx
00007ff1409dc0da  pop rcx
00007ff1409dc0db  pop rax
00007ff1409dc0dc  add rsp, 0x08
00007ff1409dc0e0  jmp 0x00007FF1409D9381
00007ff1409dc0e5  sub rsp, 0x08
00007ff1409dc0e9  push rax
00007ff1409dc0ea  push rcx
00007ff1409dc0eb  push rdx
00007ff1409dc0ec  push rdi
00007ff1409dc0ed  push rsi
00007ff1409dc0ee  push r8
00007ff1409dc0f0  push r9
00007ff1409dc0f2  push r10
00007ff1409dc0f4  push r11
00007ff1409dc0f6  sub rsp, 0xF0
00007ff1409dc0fd  vmovaps [rsp], xmm0
00007ff1409dc102  vmovaps [rsp+0x10], xmm2
00007ff1409dc108  vmovaps [rsp+0x20], xmm3
00007ff1409dc10e  vmovaps [rsp+0x30], xmm4
00007ff1409dc114  vmovaps [rsp+0x40], xmm5
00007ff1409dc11a  vmovaps [rsp+0x50], xmm6
00007ff1409dc120  vmovaps [rsp+0x60], xmm7
00007ff1409dc126  vmovaps [rsp+0x70], xmm8
00007ff1409dc12c  vmovaps [rsp+0x80], xmm9
00007ff1409dc135  vmovaps [rsp+0x90], xmm10
00007ff1409dc13e  vmovaps [rsp+0xA0], xmm11
00007ff1409dc147  vmovaps [rsp+0xB0], xmm12
00007ff1409dc150  vmovaps [rsp+0xC0], xmm13
00007ff1409dc159  vmovaps [rsp+0xD0], xmm14
00007ff1409dc162  vmovaps [rsp+0xE0], xmm15
00007ff1409dc16b  sub rsp, 0x30
00007ff1409dc16f  movaps [rsp], xmm1
00007ff1409dc173  movaps [rsp+0x10], xmm15
00007ff1409dc179  movaps [rsp+0x20], xmm6
00007ff1409dc17e  lea rdi, [rsp]
00007ff1409dc182  mov esi, 0x00
00007ff1409dc187  mov rax, 0x565C7F10C530
00007ff1409dc191  call rax
00007ff1409dc193  movaps xmm1, [rsp]
00007ff1409dc197  add rsp, 0x30
00007ff1409dc19b  vmovaps xmm0, [rsp]
00007ff1409dc1a0  vmovaps xmm2, [rsp+0x10]
00007ff1409dc1a6  vmovaps xmm3, [rsp+0x20]
00007ff1409dc1ac  vmovaps xmm4, [rsp+0x30]
00007ff1409dc1b2  vmovaps xmm5, [rsp+0x40]
00007ff1409dc1b8  vmovaps xmm6, [rsp+0x50]
00007ff1409dc1be  vmovaps xmm7, [rsp+0x60]
00007ff1409dc1c4  vmovaps xmm8, [rsp+0x70]
00007ff1409dc1ca  vmovaps xmm9, [rsp+0x80]
00007ff1409dc1d3  vmovaps xmm10, [rsp+0x90]
00007ff1409dc1dc  vmovaps xmm11, [rsp+0xA0]
00007ff1409dc1e5  vmovaps xmm12, [rsp+0xB0]
00007ff1409dc1ee  vmovaps xmm13, [rsp+0xC0]
00007ff1409dc1f7  vmovaps xmm14, [rsp+0xD0]
00007ff1409dc200  vmovaps xmm15, [rsp+0xE0]
00007ff1409dc209  add rsp, 0xF0
00007ff1409dc210  pop r11
00007ff1409dc212  pop r10
00007ff1409dc214  pop r9
00007ff1409dc216  pop r8
00007ff1409dc218  pop rsi
00007ff1409dc219  pop rdi
00007ff1409dc21a  pop rdx
00007ff1409dc21b  pop rcx
00007ff1409dc21c  pop rax
00007ff1409dc21d  add rsp, 0x08
00007ff1409dc221  jmp 0x00007FF1409D93A2
00007ff1409dc226  sub rsp, 0x08
00007ff1409dc22a  push rax
00007ff1409dc22b  push rcx
00007ff1409dc22c  push rdx
00007ff1409dc22d  push rdi
00007ff1409dc22e  push rsi
00007ff1409dc22f  push r8
00007ff1409dc231  push r9
00007ff1409dc233  push r10
00007ff1409dc235  push r11
00007ff1409dc237  sub rsp, 0xF0
00007ff1409dc23e  vmovaps [rsp], xmm0
00007ff1409dc243  vmovaps [rsp+0x10], xmm1
00007ff1409dc249  vmovaps [rsp+0x20], xmm2
00007ff1409dc24f  vmovaps [rsp+0x30], xmm3
00007ff1409dc255  vmovaps [rsp+0x40], xmm4
00007ff1409dc25b  vmovaps [rsp+0x50], xmm5
00007ff1409dc261  vmovaps [rsp+0x60], xmm6
00007ff1409dc267  vmovaps [rsp+0x70], xmm7
00007ff1409dc26d  vmovaps [rsp+0x80], xmm8
00007ff1409dc276  vmovaps [rsp+0x90], xmm9
00007ff1409dc27f  vmovaps [rsp+0xA0], xmm10
00007ff1409dc288  vmovaps [rsp+0xB0], xmm11
00007ff1409dc291  vmovaps [rsp+0xC0], xmm12
00007ff1409dc29a  vmovaps [rsp+0xD0], xmm13
00007ff1409dc2a3  vmovaps [rsp+0xE0], xmm14
00007ff1409dc2ac  sub rsp, 0x30
00007ff1409dc2b0  movaps [rsp], xmm15
00007ff1409dc2b5  movaps [rsp+0x10], xmm5
00007ff1409dc2ba  movaps [rsp+0x20], xmm3
00007ff1409dc2bf  lea rdi, [rsp]
00007ff1409dc2c3  mov esi, 0x00
00007ff1409dc2c8  mov rax, 0x565C7F10C530
00007ff1409dc2d2  call rax
00007ff1409dc2d4  movaps xmm15, [rsp]
00007ff1409dc2d9  add rsp, 0x30
00007ff1409dc2dd  vmovaps xmm0, [rsp]
00007ff1409dc2e2  vmovaps xmm1, [rsp+0x10]
00007ff1409dc2e8  vmovaps xmm2, [rsp+0x20]
00007ff1409dc2ee  vmovaps xmm3, [rsp+0x30]
00007ff1409dc2f4  vmovaps xmm4, [rsp+0x40]
00007ff1409dc2fa  vmovaps xmm5, [rsp+0x50]
00007ff1409dc300  vmovaps xmm6, [rsp+0x60]
00007ff1409dc306  vmovaps xmm7, [rsp+0x70]
00007ff1409dc30c  vmovaps xmm8, [rsp+0x80]
00007ff1409dc315  vmovaps xmm9, [rsp+0x90]
00007ff1409dc31e  vmovaps xmm10, [rsp+0xA0]
00007ff1409dc327  vmovaps xmm11, [rsp+0xB0]
00007ff1409dc330  vmovaps xmm12, [rsp+0xC0]
00007ff1409dc339  vmovaps xmm13, [rsp+0xD0]
00007ff1409dc342  vmovaps xmm14, [rsp+0xE0]
00007ff1409dc34b  add rsp, 0xF0
00007ff1409dc352  pop r11
00007ff1409dc354  pop r10
00007ff1409dc356  pop r9
00007ff1409dc358  pop r8
00007ff1409dc35a  pop rsi
00007ff1409dc35b  pop rdi
00007ff1409dc35c  pop rdx
00007ff1409dc35d  pop rcx
00007ff1409dc35e  pop rax
00007ff1409dc35f  add rsp, 0x08
00007ff1409dc363  jmp 0x00007FF1409D93BC
00007ff1409dc368  sub rsp, 0x08
00007ff1409dc36c  push rax
00007ff1409dc36d  push rcx
00007ff1409dc36e  push rdx
00007ff1409dc36f  push rdi
00007ff1409dc370  push rsi
00007ff1409dc371  push r8
00007ff1409dc373  push r9
00007ff1409dc375  push r10
00007ff1409dc377  push r11
00007ff1409dc379  sub rsp, 0xF0
00007ff1409dc380  vmovaps [rsp], xmm0
00007ff1409dc385  vmovaps [rsp+0x10], xmm1
00007ff1409dc38b  vmovaps [rsp+0x20], xmm2
00007ff1409dc391  vmovaps [rsp+0x30], xmm3
00007ff1409dc397  vmovaps [rsp+0x40], xmm4
00007ff1409dc39d  vmovaps [rsp+0x50], xmm6
00007ff1409dc3a3  vmovaps [rsp+0x60], xmm7
00007ff1409dc3a9  vmovaps [rsp+0x70], xmm8
00007ff1409dc3af  vmovaps [rsp+0x80], xmm9
00007ff1409dc3b8  vmovaps [rsp+0x90], xmm10
00007ff1409dc3c1  vmovaps [rsp+0xA0], xmm11
00007ff1409dc3ca  vmovaps [rsp+0xB0], xmm12
00007ff1409dc3d3  vmovaps [rsp+0xC0], xmm13
00007ff1409dc3dc  vmovaps [rsp+0xD0], xmm14
00007ff1409dc3e5  vmovaps [rsp+0xE0], xmm15
00007ff1409dc3ee  sub rsp, 0x30
00007ff1409dc3f2  movaps [rsp], xmm5
00007ff1409dc3f6  movaps [rsp+0x10], xmm8
00007ff1409dc3fc  movaps [rsp+0x20], xmm6
00007ff1409dc401  lea rdi, [rsp]
00007ff1409dc405  mov esi, 0x00
00007ff1409dc40a  mov rax, 0x565C7F10C530
00007ff1409dc414  call rax
00007ff1409dc416  movaps xmm5, [rsp]
00007ff1409dc41a  add rsp, 0x30
00007ff1409dc41e  vmovaps xmm0, [rsp]
00007ff1409dc423  vmovaps xmm1, [rsp+0x10]
00007ff1409dc429  vmovaps xmm2, [rsp+0x20]
00007ff1409dc42f  vmovaps xmm3, [rsp+0x30]
00007ff1409dc435  vmovaps xmm4, [rsp+0x40]
00007ff1409dc43b  vmovaps xmm6, [rsp+0x50]
00007ff1409dc441  vmovaps xmm7, [rsp+0x60]
00007ff1409dc447  vmovaps xmm8, [rsp+0x70]
00007ff1409dc44d  vmovaps xmm9, [rsp+0x80]
00007ff1409dc456  vmovaps xmm10, [rsp+0x90]
00007ff1409dc45f  vmovaps xmm11, [rsp+0xA0]
00007ff1409dc468  vmovaps xmm12, [rsp+0xB0]
00007ff1409dc471  vmovaps xmm13, [rsp+0xC0]
00007ff1409dc47a  vmovaps xmm14, [rsp+0xD0]
00007ff1409dc483  vmovaps xmm15, [rsp+0xE0]
00007ff1409dc48c  add rsp, 0xF0
00007ff1409dc493  pop r11
00007ff1409dc495  pop r10
00007ff1409dc497  pop r9
00007ff1409dc499  pop r8
00007ff1409dc49b  pop rsi
00007ff1409dc49c  pop rdi
00007ff1409dc49d  pop rdx
00007ff1409dc49e  pop rcx
00007ff1409dc49f  pop rax
00007ff1409dc4a0  add rsp, 0x08
00007ff1409dc4a4  jmp 0x00007FF1409D93E0
00007ff1409dc4a9  sub rsp, 0x08
00007ff1409dc4ad  push rax
00007ff1409dc4ae  push rcx
00007ff1409dc4af  push rdx
00007ff1409dc4b0  push rdi
00007ff1409dc4b1  push rsi
00007ff1409dc4b2  push r8
00007ff1409dc4b4  push r9
00007ff1409dc4b6  push r10
00007ff1409dc4b8  push r11
00007ff1409dc4ba  sub rsp, 0xF0
00007ff1409dc4c1  vmovaps [rsp], xmm0
00007ff1409dc4c6  vmovaps [rsp+0x10], xmm1
00007ff1409dc4cc  vmovaps [rsp+0x20], xmm2
00007ff1409dc4d2  vmovaps [rsp+0x30], xmm3
00007ff1409dc4d8  vmovaps [rsp+0x40], xmm4
00007ff1409dc4de  vmovaps [rsp+0x50], xmm5
00007ff1409dc4e4  vmovaps [rsp+0x60], xmm7
00007ff1409dc4ea  vmovaps [rsp+0x70], xmm8
00007ff1409dc4f0  vmovaps [rsp+0x80], xmm9
00007ff1409dc4f9  vmovaps [rsp+0x90], xmm10
00007ff1409dc502  vmovaps [rsp+0xA0], xmm11
00007ff1409dc50b  vmovaps [rsp+0xB0], xmm12
00007ff1409dc514  vmovaps [rsp+0xC0], xmm13
00007ff1409dc51d  vmovaps [rsp+0xD0], xmm14
00007ff1409dc526  vmovaps [rsp+0xE0], xmm15
00007ff1409dc52f  sub rsp, 0x30
00007ff1409dc533  movaps [rsp], xmm6
00007ff1409dc537  movaps [rsp+0x10], xmm10
00007ff1409dc53d  movaps [rsp+0x20], xmm8
00007ff1409dc543  lea rdi, [rsp]
00007ff1409dc547  mov esi, 0x00
00007ff1409dc54c  mov rax, 0x565C7F10C530
00007ff1409dc556  call rax
00007ff1409dc558  movaps xmm6, [rsp]
00007ff1409dc55c  add rsp, 0x30
00007ff1409dc560  vmovaps xmm0, [rsp]
00007ff1409dc565  vmovaps xmm1, [rsp+0x10]
00007ff1409dc56b  vmovaps xmm2, [rsp+0x20]
00007ff1409dc571  vmovaps xmm3, [rsp+0x30]
00007ff1409dc577  vmovaps xmm4, [rsp+0x40]
00007ff1409dc57d  vmovaps xmm5, [rsp+0x50]
00007ff1409dc583  vmovaps xmm7, [rsp+0x60]
00007ff1409dc589  vmovaps xmm8, [rsp+0x70]
00007ff1409dc58f  vmovaps xmm9, [rsp+0x80]
00007ff1409dc598  vmovaps xmm10, [rsp+0x90]
00007ff1409dc5a1  vmovaps xmm11, [rsp+0xA0]
00007ff1409dc5aa  vmovaps xmm12, [rsp+0xB0]
00007ff1409dc5b3  vmovaps xmm13, [rsp+0xC0]
00007ff1409dc5bc  vmovaps xmm14, [rsp+0xD0]
00007ff1409dc5c5  vmovaps xmm15, [rsp+0xE0]
00007ff1409dc5ce  add rsp, 0xF0
00007ff1409dc5d5  pop r11
00007ff1409dc5d7  pop r10
00007ff1409dc5d9  pop r9
00007ff1409dc5db  pop r8
00007ff1409dc5dd  pop rsi
00007ff1409dc5de  pop rdi
00007ff1409dc5df  pop rdx
00007ff1409dc5e0  pop rcx
00007ff1409dc5e1  pop rax
00007ff1409dc5e2  add rsp, 0x08
00007ff1409dc5e6  jmp 0x00007FF1409D9405
00007ff1409dc5eb  sub rsp, 0x08
00007ff1409dc5ef  push rax
00007ff1409dc5f0  push rcx
00007ff1409dc5f1  push rdx
00007ff1409dc5f2  push rdi
00007ff1409dc5f3  push rsi
00007ff1409dc5f4  push r8
00007ff1409dc5f6  push r9
00007ff1409dc5f8  push r10
00007ff1409dc5fa  push r11
00007ff1409dc5fc  sub rsp, 0xF0
00007ff1409dc603  vmovaps [rsp], xmm0
00007ff1409dc608  vmovaps [rsp+0x10], xmm1
00007ff1409dc60e  vmovaps [rsp+0x20], xmm2
00007ff1409dc614  vmovaps [rsp+0x30], xmm3
00007ff1409dc61a  vmovaps [rsp+0x40], xmm4
00007ff1409dc620  vmovaps [rsp+0x50], xmm5
00007ff1409dc626  vmovaps [rsp+0x60], xmm6
00007ff1409dc62c  vmovaps [rsp+0x70], xmm7
00007ff1409dc632  vmovaps [rsp+0x80], xmm8
00007ff1409dc63b  vmovaps [rsp+0x90], xmm9
00007ff1409dc644  vmovaps [rsp+0xA0], xmm11
00007ff1409dc64d  vmovaps [rsp+0xB0], xmm12
00007ff1409dc656  vmovaps [rsp+0xC0], xmm13
00007ff1409dc65f  vmovaps [rsp+0xD0], xmm14
00007ff1409dc668  vmovaps [rsp+0xE0], xmm15
00007ff1409dc671  sub rsp, 0x30
00007ff1409dc675  movaps [rsp], xmm10
00007ff1409dc67a  movaps [rsp+0x10], xmm8
00007ff1409dc680  movaps [rsp+0x20], xmm14
00007ff1409dc686  lea rdi, [rsp]
00007ff1409dc68a  mov esi, 0x00
00007ff1409dc68f  mov rax, 0x565C7F10C530
00007ff1409dc699  call rax
00007ff1409dc69b  movaps xmm10, [rsp]
00007ff1409dc6a0  add rsp, 0x30
00007ff1409dc6a4  vmovaps xmm0, [rsp]
00007ff1409dc6a9  vmovaps xmm1, [rsp+0x10]
00007ff1409dc6af  vmovaps xmm2, [rsp+0x20]
00007ff1409dc6b5  vmovaps xmm3, [rsp+0x30]
00007ff1409dc6bb  vmovaps xmm4, [rsp+0x40]
00007ff1409dc6c1  vmovaps xmm5, [rsp+0x50]
00007ff1409dc6c7  vmovaps xmm6, [rsp+0x60]
00007ff1409dc6cd  vmovaps xmm7, [rsp+0x70]
00007ff1409dc6d3  vmovaps xmm8, [rsp+0x80]
00007ff1409dc6dc  vmovaps xmm9, [rsp+0x90]
00007ff1409dc6e5  vmovaps xmm11, [rsp+0xA0]
00007ff1409dc6ee  vmovaps xmm12, [rsp+0xB0]
00007ff1409dc6f7  vmovaps xmm13, [rsp+0xC0]
00007ff1409dc700  vmovaps xmm14, [rsp+0xD0]
00007ff1409dc709  vmovaps xmm15, [rsp+0xE0]
00007ff1409dc712  add rsp, 0xF0
00007ff1409dc719  pop r11
00007ff1409dc71b  pop r10
00007ff1409dc71d  pop r9
00007ff1409dc71f  pop r8
00007ff1409dc721  pop rsi
00007ff1409dc722  pop rdi
00007ff1409dc723  pop rdx
00007ff1409dc724  pop rcx
00007ff1409dc725  pop rax
00007ff1409dc726  add rsp, 0x08
00007ff1409dc72a  jmp 0x00007FF1409D9425
00007ff1409dc72f  sub rsp, 0x08
00007ff1409dc733  push rax
00007ff1409dc734  push rcx
00007ff1409dc735  push rdx
00007ff1409dc736  push rdi
00007ff1409dc737  push rsi
00007ff1409dc738  push r8
00007ff1409dc73a  push r9
00007ff1409dc73c  push r10
00007ff1409dc73e  push r11
00007ff1409dc740  sub rsp, 0xF0
00007ff1409dc747  vmovaps [rsp], xmm0
00007ff1409dc74c  vmovaps [rsp+0x10], xmm1
00007ff1409dc752  vmovaps [rsp+0x20], xmm2
00007ff1409dc758  vmovaps [rsp+0x30], xmm3
00007ff1409dc75e  vmovaps [rsp+0x40], xmm4
00007ff1409dc764  vmovaps [rsp+0x50], xmm5
00007ff1409dc76a  vmovaps [rsp+0x60], xmm6
00007ff1409dc770  vmovaps [rsp+0x70], xmm7
00007ff1409dc776  vmovaps [rsp+0x80], xmm8
00007ff1409dc77f  vmovaps [rsp+0x90], xmm9
00007ff1409dc788  vmovaps [rsp+0xA0], xmm10
00007ff1409dc791  vmovaps [rsp+0xB0], xmm11
00007ff1409dc79a  vmovaps [rsp+0xC0], xmm12
00007ff1409dc7a3  vmovaps [rsp+0xD0], xmm13
00007ff1409dc7ac  vmovaps [rsp+0xE0], xmm15
00007ff1409dc7b5  sub rsp, 0x30
00007ff1409dc7b9  movaps [rsp], xmm14
00007ff1409dc7be  movaps [rsp+0x10], xmm8
00007ff1409dc7c4  movaps [rsp+0x20], xmm4
00007ff1409dc7c9  lea rdi, [rsp]
00007ff1409dc7cd  mov esi, 0x00
00007ff1409dc7d2  mov rax, 0x565C7F10C530
00007ff1409dc7dc  call rax
00007ff1409dc7de  movaps xmm14, [rsp]
00007ff1409dc7e3  add rsp, 0x30
00007ff1409dc7e7  vmovaps xmm0, [rsp]
00007ff1409dc7ec  vmovaps xmm1, [rsp+0x10]
00007ff1409dc7f2  vmovaps xmm2, [rsp+0x20]
00007ff1409dc7f8  vmovaps xmm3, [rsp+0x30]
00007ff1409dc7fe  vmovaps xmm4, [rsp+0x40]
00007ff1409dc804  vmovaps xmm5, [rsp+0x50]
00007ff1409dc80a  vmovaps xmm6, [rsp+0x60]
00007ff1409dc810  vmovaps xmm7, [rsp+0x70]
00007ff1409dc816  vmovaps xmm8, [rsp+0x80]
00007ff1409dc81f  vmovaps xmm9, [rsp+0x90]
00007ff1409dc828  vmovaps xmm10, [rsp+0xA0]
00007ff1409dc831  vmovaps xmm11, [rsp+0xB0]
00007ff1409dc83a  vmovaps xmm12, [rsp+0xC0]
00007ff1409dc843  vmovaps xmm13, [rsp+0xD0]
00007ff1409dc84c  vmovaps xmm15, [rsp+0xE0]
00007ff1409dc855  add rsp, 0xF0
00007ff1409dc85c  pop r11
00007ff1409dc85e  pop r10
00007ff1409dc860  pop r9
00007ff1409dc862  pop r8
00007ff1409dc864  pop rsi
00007ff1409dc865  pop rdi
00007ff1409dc866  pop rdx
00007ff1409dc867  pop rcx
00007ff1409dc868  pop rax
00007ff1409dc869  add rsp, 0x08
00007ff1409dc86d  jmp 0x00007FF1409D9445
00007ff1409dc872  sub rsp, 0x08
00007ff1409dc876  push rax
00007ff1409dc877  push rcx
00007ff1409dc878  push rdx
00007ff1409dc879  push rdi
00007ff1409dc87a  push rsi
00007ff1409dc87b  push r8
00007ff1409dc87d  push r9
00007ff1409dc87f  push r10
00007ff1409dc881  push r11
00007ff1409dc883  sub rsp, 0xF0
00007ff1409dc88a  vmovaps [rsp], xmm0
00007ff1409dc88f  vmovaps [rsp+0x10], xmm1
00007ff1409dc895  vmovaps [rsp+0x20], xmm2
00007ff1409dc89b  vmovaps [rsp+0x30], xmm3
00007ff1409dc8a1  vmovaps [rsp+0x40], xmm5
00007ff1409dc8a7  vmovaps [rsp+0x50], xmm6
00007ff1409dc8ad  vmovaps [rsp+0x60], xmm7
00007ff1409dc8b3  vmovaps [rsp+0x70], xmm8
00007ff1409dc8b9  vmovaps [rsp+0x80], xmm9
00007ff1409dc8c2  vmovaps [rsp+0x90], xmm10
00007ff1409dc8cb  vmovaps [rsp+0xA0], xmm11
00007ff1409dc8d4  vmovaps [rsp+0xB0], xmm12
00007ff1409dc8dd  vmovaps [rsp+0xC0], xmm13
00007ff1409dc8e6  vmovaps [rsp+0xD0], xmm14
00007ff1409dc8ef  vmovaps [rsp+0xE0], xmm15
00007ff1409dc8f8  sub rsp, 0x30
00007ff1409dc8fc  movaps [rsp], xmm4
00007ff1409dc900  movaps [rsp+0x10], xmm13
00007ff1409dc906  movaps [rsp+0x20], xmm8
00007ff1409dc90c  lea rdi, [rsp]
00007ff1409dc910  mov esi, 0x00
00007ff1409dc915  mov rax, 0x565C7F10C530
00007ff1409dc91f  call rax
00007ff1409dc921  movaps xmm4, [rsp]
00007ff1409dc925  add rsp, 0x30
00007ff1409dc929  vmovaps xmm0, [rsp]
00007ff1409dc92e  vmovaps xmm1, [rsp+0x10]
00007ff1409dc934  vmovaps xmm2, [rsp+0x20]
00007ff1409dc93a  vmovaps xmm3, [rsp+0x30]
00007ff1409dc940  vmovaps xmm5, [rsp+0x40]
00007ff1409dc946  vmovaps xmm6, [rsp+0x50]
00007ff1409dc94c  vmovaps xmm7, [rsp+0x60]
00007ff1409dc952  vmovaps xmm8, [rsp+0x70]
00007ff1409dc958  vmovaps xmm9, [rsp+0x80]
00007ff1409dc961  vmovaps xmm10, [rsp+0x90]
00007ff1409dc96a  vmovaps xmm11, [rsp+0xA0]
00007ff1409dc973  vmovaps xmm12, [rsp+0xB0]
00007ff1409dc97c  vmovaps xmm13, [rsp+0xC0]
00007ff1409dc985  vmovaps xmm14, [rsp+0xD0]
00007ff1409dc98e  vmovaps xmm15, [rsp+0xE0]
00007ff1409dc997  add rsp, 0xF0
00007ff1409dc99e  pop r11
00007ff1409dc9a0  pop r10
00007ff1409dc9a2  pop r9
00007ff1409dc9a4  pop r8
00007ff1409dc9a6  pop rsi
00007ff1409dc9a7  pop rdi
00007ff1409dc9a8  pop rdx
00007ff1409dc9a9  pop rcx
00007ff1409dc9aa  pop rax
00007ff1409dc9ab  add rsp, 0x08
00007ff1409dc9af  jmp 0x00007FF1409D946A
00007ff1409dc9b4  sub rsp, 0x08
00007ff1409dc9b8  push rax
00007ff1409dc9b9  push rcx
00007ff1409dc9ba  push rdx
00007ff1409dc9bb  push rdi
00007ff1409dc9bc  push rsi
00007ff1409dc9bd  push r8
00007ff1409dc9bf  push r9
00007ff1409dc9c1  push r10
00007ff1409dc9c3  push r11
00007ff1409dc9c5  sub rsp, 0xF0
00007ff1409dc9cc  vmovaps [rsp], xmm0
00007ff1409dc9d1  vmovaps [rsp+0x10], xmm1
00007ff1409dc9d7  vmovaps [rsp+0x20], xmm2
00007ff1409dc9dd  vmovaps [rsp+0x30], xmm3
00007ff1409dc9e3  vmovaps [rsp+0x40], xmm4
00007ff1409dc9e9  vmovaps [rsp+0x50], xmm5
00007ff1409dc9ef  vmovaps [rsp+0x60], xmm6
00007ff1409dc9f5  vmovaps [rsp+0x70], xmm7
00007ff1409dc9fb  vmovaps [rsp+0x80], xmm8
00007ff1409dca04  vmovaps [rsp+0x90], xmm9
00007ff1409dca0d  vmovaps [rsp+0xA0], xmm10
00007ff1409dca16  vmovaps [rsp+0xB0], xmm11
00007ff1409dca1f  vmovaps [rsp+0xC0], xmm12
00007ff1409dca28  vmovaps [rsp+0xD0], xmm14
00007ff1409dca31  vmovaps [rsp+0xE0], xmm15
00007ff1409dca3a  sub rsp, 0x30
00007ff1409dca3e  movaps [rsp], xmm13
00007ff1409dca43  movaps [rsp+0x10], xmm15
00007ff1409dca49  movaps [rsp+0x20], xmm9
00007ff1409dca4f  lea rdi, [rsp]
00007ff1409dca53  mov esi, 0x00
00007ff1409dca58  mov rax, 0x565C7F10C530
00007ff1409dca62  call rax
00007ff1409dca64  movaps xmm13, [rsp]
00007ff1409dca69  add rsp, 0x30
00007ff1409dca6d  vmovaps xmm0, [rsp]
00007ff1409dca72  vmovaps xmm1, [rsp+0x10]
00007ff1409dca78  vmovaps xmm2, [rsp+0x20]
00007ff1409dca7e  vmovaps xmm3, [rsp+0x30]
00007ff1409dca84  vmovaps xmm4, [rsp+0x40]
00007ff1409dca8a  vmovaps xmm5, [rsp+0x50]
00007ff1409dca90  vmovaps xmm6, [rsp+0x60]
00007ff1409dca96  vmovaps xmm7, [rsp+0x70]
00007ff1409dca9c  vmovaps xmm8, [rsp+0x80]
00007ff1409dcaa5  vmovaps xmm9, [rsp+0x90]
00007ff1409dcaae  vmovaps xmm10, [rsp+0xA0]
00007ff1409dcab7  vmovaps xmm11, [rsp+0xB0]
00007ff1409dcac0  vmovaps xmm12, [rsp+0xC0]
00007ff1409dcac9  vmovaps xmm14, [rsp+0xD0]
00007ff1409dcad2  vmovaps xmm15, [rsp+0xE0]
00007ff1409dcadb  add rsp, 0xF0
00007ff1409dcae2  pop r11
00007ff1409dcae4  pop r10
00007ff1409dcae6  pop r9
00007ff1409dcae8  pop r8
00007ff1409dcaea  pop rsi
00007ff1409dcaeb  pop rdi
00007ff1409dcaec  pop rdx
00007ff1409dcaed  pop rcx
00007ff1409dcaee  pop rax
00007ff1409dcaef  add rsp, 0x08
00007ff1409dcaf3  jmp 0x00007FF1409D9485
00007ff1409dcaf8  sub rsp, 0x08
00007ff1409dcafc  push rax
00007ff1409dcafd  push rcx
00007ff1409dcafe  push rdx
00007ff1409dcaff  push rdi
00007ff1409dcb00  push rsi
00007ff1409dcb01  push r8
00007ff1409dcb03  push r9
00007ff1409dcb05  push r10
00007ff1409dcb07  push r11
00007ff1409dcb09  sub rsp, 0xF0
00007ff1409dcb10  vmovaps [rsp], xmm0
00007ff1409dcb15  vmovaps [rsp+0x10], xmm1
00007ff1409dcb1b  vmovaps [rsp+0x20], xmm2
00007ff1409dcb21  vmovaps [rsp+0x30], xmm3
00007ff1409dcb27  vmovaps [rsp+0x40], xmm4
00007ff1409dcb2d  vmovaps [rsp+0x50], xmm5
00007ff1409dcb33  vmovaps [rsp+0x60], xmm6
00007ff1409dcb39  vmovaps [rsp+0x70], xmm7
00007ff1409dcb3f  vmovaps [rsp+0x80], xmm8
00007ff1409dcb48  vmovaps [rsp+0x90], xmm9
00007ff1409dcb51  vmovaps [rsp+0xA0], xmm10
00007ff1409dcb5a  vmovaps [rsp+0xB0], xmm11
00007ff1409dcb63  vmovaps [rsp+0xC0], xmm12
00007ff1409dcb6c  vmovaps [rsp+0xD0], xmm13
00007ff1409dcb75  vmovaps [rsp+0xE0], xmm14
00007ff1409dcb7e  sub rsp, 0x30
00007ff1409dcb82  movaps [rsp], xmm15
00007ff1409dcb87  movaps [rsp+0x10], xmm1
00007ff1409dcb8c  movaps [rsp+0x20], xmm5
00007ff1409dcb91  lea rdi, [rsp]
00007ff1409dcb95  mov esi, 0x00
00007ff1409dcb9a  mov rax, 0x565C7F10C530
00007ff1409dcba4  call rax
00007ff1409dcba6  movaps xmm15, [rsp]
00007ff1409dcbab  add rsp, 0x30
00007ff1409dcbaf  vmovaps xmm0, [rsp]
00007ff1409dcbb4  vmovaps xmm1, [rsp+0x10]
00007ff1409dcbba  vmovaps xmm2, [rsp+0x20]
00007ff1409dcbc0  vmovaps xmm3, [rsp+0x30]
00007ff1409dcbc6  vmovaps xmm4, [rsp+0x40]
00007ff1409dcbcc  vmovaps xmm5, [rsp+0x50]
00007ff1409dcbd2  vmovaps xmm6, [rsp+0x60]
00007ff1409dcbd8  vmovaps xmm7, [rsp+0x70]
00007ff1409dcbde  vmovaps xmm8, [rsp+0x80]
00007ff1409dcbe7  vmovaps xmm9, [rsp+0x90]
00007ff1409dcbf0  vmovaps xmm10, [rsp+0xA0]
00007ff1409dcbf9  vmovaps xmm11, [rsp+0xB0]
00007ff1409dcc02  vmovaps xmm12, [rsp+0xC0]
00007ff1409dcc0b  vmovaps xmm13, [rsp+0xD0]
00007ff1409dcc14  vmovaps xmm14, [rsp+0xE0]
00007ff1409dcc1d  add rsp, 0xF0
00007ff1409dcc24  pop r11
00007ff1409dcc26  pop r10
00007ff1409dcc28  pop r9
00007ff1409dcc2a  pop r8
00007ff1409dcc2c  pop rsi
00007ff1409dcc2d  pop rdi
00007ff1409dcc2e  pop rdx
00007ff1409dcc2f  pop rcx
00007ff1409dcc30  pop rax
00007ff1409dcc31  add rsp, 0x08
00007ff1409dcc35  jmp 0x00007FF1409D94A0
00007ff1409dcc3a  call 0x00007FF1408D64F0
00007ff1409dcc3f  jmp 0x00007FF1409D94FB
00007ff1409dcc44  sub rsp, 0x08
00007ff1409dcc48  push rax
00007ff1409dcc49  push rcx
00007ff1409dcc4a  push rdx
00007ff1409dcc4b  push rdi
00007ff1409dcc4c  push rsi
00007ff1409dcc4d  push r8
00007ff1409dcc4f  push r9
00007ff1409dcc51  push r10
00007ff1409dcc53  push r11
00007ff1409dcc55  sub rsp, 0xF0
00007ff1409dcc5c  vmovaps [rsp], xmm0
00007ff1409dcc61  vmovaps [rsp+0x10], xmm1
00007ff1409dcc67  vmovaps [rsp+0x20], xmm2
00007ff1409dcc6d  vmovaps [rsp+0x30], xmm3
00007ff1409dcc73  vmovaps [rsp+0x40], xmm4
00007ff1409dcc79  vmovaps [rsp+0x50], xmm5
00007ff1409dcc7f  vmovaps [rsp+0x60], xmm6
00007ff1409dcc85  vmovaps [rsp+0x70], xmm7
00007ff1409dcc8b  vmovaps [rsp+0x80], xmm8
00007ff1409dcc94  vmovaps [rsp+0x90], xmm10
00007ff1409dcc9d  vmovaps [rsp+0xA0], xmm11
00007ff1409dcca6  vmovaps [rsp+0xB0], xmm12
00007ff1409dccaf  vmovaps [rsp+0xC0], xmm13
00007ff1409dccb8  vmovaps [rsp+0xD0], xmm14
00007ff1409dccc1  vmovaps [rsp+0xE0], xmm15
00007ff1409dccca  sub rsp, 0x30
00007ff1409dccce  movaps [rsp], xmm9
00007ff1409dccd3  movaps [rsp+0x10], xmm8
00007ff1409dccd9  movaps [rsp+0x20], xmm11
00007ff1409dccdf  lea rdi, [rsp]
00007ff1409dcce3  mov esi, 0x00
00007ff1409dcce8  mov rax, 0x565C7F10C530
00007ff1409dccf2  call rax
00007ff1409dccf4  movaps xmm9, [rsp]
00007ff1409dccf9  add rsp, 0x30
00007ff1409dccfd  vmovaps xmm0, [rsp]
00007ff1409dcd02  vmovaps xmm1, [rsp+0x10]
00007ff1409dcd08  vmovaps xmm2, [rsp+0x20]
00007ff1409dcd0e  vmovaps xmm3, [rsp+0x30]
00007ff1409dcd14  vmovaps xmm4, [rsp+0x40]
00007ff1409dcd1a  vmovaps xmm5, [rsp+0x50]
00007ff1409dcd20  vmovaps xmm6, [rsp+0x60]
00007ff1409dcd26  vmovaps xmm7, [rsp+0x70]
00007ff1409dcd2c  vmovaps xmm8, [rsp+0x80]
00007ff1409dcd35  vmovaps xmm10, [rsp+0x90]
00007ff1409dcd3e  vmovaps xmm11, [rsp+0xA0]
00007ff1409dcd47  vmovaps xmm12, [rsp+0xB0]
00007ff1409dcd50  vmovaps xmm13, [rsp+0xC0]
00007ff1409dcd59  vmovaps xmm14, [rsp+0xD0]
00007ff1409dcd62  vmovaps xmm15, [rsp+0xE0]
00007ff1409dcd6b  add rsp, 0xF0
00007ff1409dcd72  pop r11
00007ff1409dcd74  pop r10
00007ff1409dcd76  pop r9
00007ff1409dcd78  pop r8
00007ff1409dcd7a  pop rsi
00007ff1409dcd7b  pop rdi
00007ff1409dcd7c  pop rdx
00007ff1409dcd7d  pop rcx
00007ff1409dcd7e  pop rax
00007ff1409dcd7f  add rsp, 0x08
00007ff1409dcd83  jmp 0x00007FF1409D9532
00007ff1409dcd88  sub rsp, 0x08
00007ff1409dcd8c  push rax
00007ff1409dcd8d  push rcx
00007ff1409dcd8e  push rdx
00007ff1409dcd8f  push rdi
00007ff1409dcd90  push rsi
00007ff1409dcd91  push r8
00007ff1409dcd93  push r9
00007ff1409dcd95  push r10
00007ff1409dcd97  push r11
00007ff1409dcd99  sub rsp, 0xF0
00007ff1409dcda0  vmovaps [rsp], xmm0
00007ff1409dcda5  vmovaps [rsp+0x10], xmm1
00007ff1409dcdab  vmovaps [rsp+0x20], xmm2
00007ff1409dcdb1  vmovaps [rsp+0x30], xmm3
00007ff1409dcdb7  vmovaps [rsp+0x40], xmm4
00007ff1409dcdbd  vmovaps [rsp+0x50], xmm5
00007ff1409dcdc3  vmovaps [rsp+0x60], xmm6
00007ff1409dcdc9  vmovaps [rsp+0x70], xmm7
00007ff1409dcdcf  vmovaps [rsp+0x80], xmm8
00007ff1409dcdd8  vmovaps [rsp+0x90], xmm9
00007ff1409dcde1  vmovaps [rsp+0xA0], xmm10
00007ff1409dcdea  vmovaps [rsp+0xB0], xmm12
00007ff1409dcdf3  vmovaps [rsp+0xC0], xmm13
00007ff1409dcdfc  vmovaps [rsp+0xD0], xmm14
00007ff1409dce05  vmovaps [rsp+0xE0], xmm15
00007ff1409dce0e  sub rsp, 0x30
00007ff1409dce12  movaps [rsp], xmm11
00007ff1409dce17  movaps [rsp+0x10], xmm10
00007ff1409dce1d  movaps [rsp+0x20], xmm6
00007ff1409dce22  lea rdi, [rsp]
00007ff1409dce26  mov esi, 0x00
00007ff1409dce2b  mov rax, 0x565C7F10C530
00007ff1409dce35  call rax
00007ff1409dce37  movaps xmm11, [rsp]
00007ff1409dce3c  add rsp, 0x30
00007ff1409dce40  vmovaps xmm0, [rsp]
00007ff1409dce45  vmovaps xmm1, [rsp+0x10]
00007ff1409dce4b  vmovaps xmm2, [rsp+0x20]
00007ff1409dce51  vmovaps xmm3, [rsp+0x30]
00007ff1409dce57  vmovaps xmm4, [rsp+0x40]
00007ff1409dce5d  vmovaps xmm5, [rsp+0x50]
00007ff1409dce63  vmovaps xmm6, [rsp+0x60]
00007ff1409dce69  vmovaps xmm7, [rsp+0x70]
00007ff1409dce6f  vmovaps xmm8, [rsp+0x80]
00007ff1409dce78  vmovaps xmm9, [rsp+0x90]
00007ff1409dce81  vmovaps xmm10, [rsp+0xA0]
00007ff1409dce8a  vmovaps xmm12, [rsp+0xB0]
00007ff1409dce93  vmovaps xmm13, [rsp+0xC0]
00007ff1409dce9c  vmovaps xmm14, [rsp+0xD0]
00007ff1409dcea5  vmovaps xmm15, [rsp+0xE0]
00007ff1409dceae  add rsp, 0xF0
00007ff1409dceb5  pop r11
00007ff1409dceb7  pop r10
00007ff1409dceb9  pop r9
00007ff1409dcebb  pop r8
00007ff1409dcebd  pop rsi
00007ff1409dcebe  pop rdi
00007ff1409dcebf  pop rdx
00007ff1409dcec0  pop rcx
00007ff1409dcec1  pop rax
00007ff1409dcec2  add rsp, 0x08
00007ff1409dcec6  jmp 0x00007FF1409D954D
00007ff1409dcecb  sub rsp, 0x08
00007ff1409dcecf  push rax
00007ff1409dced0  push rcx
00007ff1409dced1  push rdx
00007ff1409dced2  push rdi
00007ff1409dced3  push rsi
00007ff1409dced4  push r8
00007ff1409dced6  push r9
00007ff1409dced8  push r10
00007ff1409dceda  push r11
00007ff1409dcedc  sub rsp, 0xF0
00007ff1409dcee3  vmovaps [rsp], xmm0
00007ff1409dcee8  vmovaps [rsp+0x10], xmm1
00007ff1409dceee  vmovaps [rsp+0x20], xmm2
00007ff1409dcef4  vmovaps [rsp+0x30], xmm3
00007ff1409dcefa  vmovaps [rsp+0x40], xmm4
00007ff1409dcf00  vmovaps [rsp+0x50], xmm5
00007ff1409dcf06  vmovaps [rsp+0x60], xmm6
00007ff1409dcf0c  vmovaps [rsp+0x70], xmm7
00007ff1409dcf12  vmovaps [rsp+0x80], xmm8
00007ff1409dcf1b  vmovaps [rsp+0x90], xmm9
00007ff1409dcf24  vmovaps [rsp+0xA0], xmm11
00007ff1409dcf2d  vmovaps [rsp+0xB0], xmm12
00007ff1409dcf36  vmovaps [rsp+0xC0], xmm13
00007ff1409dcf3f  vmovaps [rsp+0xD0], xmm14
00007ff1409dcf48  vmovaps [rsp+0xE0], xmm15
00007ff1409dcf51  sub rsp, 0x30
00007ff1409dcf55  movaps [rsp], xmm10
00007ff1409dcf5a  movaps [rsp+0x10], xmm14
00007ff1409dcf60  movaps [rsp+0x20], xmm4
00007ff1409dcf65  lea rdi, [rsp]
00007ff1409dcf69  mov esi, 0x00
00007ff1409dcf6e  mov rax, 0x565C7F10C530
00007ff1409dcf78  call rax
00007ff1409dcf7a  movaps xmm10, [rsp]
00007ff1409dcf7f  add rsp, 0x30
00007ff1409dcf83  vmovaps xmm0, [rsp]
00007ff1409dcf88  vmovaps xmm1, [rsp+0x10]
00007ff1409dcf8e  vmovaps xmm2, [rsp+0x20]
00007ff1409dcf94  vmovaps xmm3, [rsp+0x30]
00007ff1409dcf9a  vmovaps xmm4, [rsp+0x40]
00007ff1409dcfa0  vmovaps xmm5, [rsp+0x50]
00007ff1409dcfa6  vmovaps xmm6, [rsp+0x60]
00007ff1409dcfac  vmovaps xmm7, [rsp+0x70]
00007ff1409dcfb2  vmovaps xmm8, [rsp+0x80]
00007ff1409dcfbb  vmovaps xmm9, [rsp+0x90]
00007ff1409dcfc4  vmovaps xmm11, [rsp+0xA0]
00007ff1409dcfcd  vmovaps xmm12, [rsp+0xB0]
00007ff1409dcfd6  vmovaps xmm13, [rsp+0xC0]
00007ff1409dcfdf  vmovaps xmm14, [rsp+0xD0]
00007ff1409dcfe8  vmovaps xmm15, [rsp+0xE0]
00007ff1409dcff1  add rsp, 0xF0
00007ff1409dcff8  pop r11
00007ff1409dcffa  pop r10
00007ff1409dcffc  pop r9
00007ff1409dcffe  pop r8
00007ff1409dd000  pop rsi
00007ff1409dd001  pop rdi
00007ff1409dd002  pop rdx
00007ff1409dd003  pop rcx
00007ff1409dd004  pop rax
00007ff1409dd005  add rsp, 0x08
00007ff1409dd009  jmp 0x00007FF1409D9568
00007ff1409dd00e  sub rsp, 0x08
00007ff1409dd012  push rax
00007ff1409dd013  push rcx
00007ff1409dd014  push rdx
00007ff1409dd015  push rdi
00007ff1409dd016  push rsi
00007ff1409dd017  push r8
00007ff1409dd019  push r9
00007ff1409dd01b  push r10
00007ff1409dd01d  push r11
00007ff1409dd01f  sub rsp, 0xF0
00007ff1409dd026  vmovaps [rsp], xmm0
00007ff1409dd02b  vmovaps [rsp+0x10], xmm1
00007ff1409dd031  vmovaps [rsp+0x20], xmm2
00007ff1409dd037  vmovaps [rsp+0x30], xmm3
00007ff1409dd03d  vmovaps [rsp+0x40], xmm4
00007ff1409dd043  vmovaps [rsp+0x50], xmm5
00007ff1409dd049  vmovaps [rsp+0x60], xmm6
00007ff1409dd04f  vmovaps [rsp+0x70], xmm7
00007ff1409dd055  vmovaps [rsp+0x80], xmm9
00007ff1409dd05e  vmovaps [rsp+0x90], xmm10
00007ff1409dd067  vmovaps [rsp+0xA0], xmm11
00007ff1409dd070  vmovaps [rsp+0xB0], xmm12
00007ff1409dd079  vmovaps [rsp+0xC0], xmm13
00007ff1409dd082  vmovaps [rsp+0xD0], xmm14
00007ff1409dd08b  vmovaps [rsp+0xE0], xmm15
00007ff1409dd094  sub rsp, 0x30
00007ff1409dd098  movaps [rsp], xmm8
00007ff1409dd09d  movaps [rsp+0x10], xmm1
00007ff1409dd0a2  movaps [rsp+0x20], xmm14
00007ff1409dd0a8  lea rdi, [rsp]
00007ff1409dd0ac  mov esi, 0x00
00007ff1409dd0b1  mov rax, 0x565C7F10C530
00007ff1409dd0bb  call rax
00007ff1409dd0bd  movaps xmm8, [rsp]
00007ff1409dd0c2  add rsp, 0x30
00007ff1409dd0c6  vmovaps xmm0, [rsp]
00007ff1409dd0cb  vmovaps xmm1, [rsp+0x10]
00007ff1409dd0d1  vmovaps xmm2, [rsp+0x20]
00007ff1409dd0d7  vmovaps xmm3, [rsp+0x30]
00007ff1409dd0dd  vmovaps xmm4, [rsp+0x40]
00007ff1409dd0e3  vmovaps xmm5, [rsp+0x50]
00007ff1409dd0e9  vmovaps xmm6, [rsp+0x60]
00007ff1409dd0ef  vmovaps xmm7, [rsp+0x70]
00007ff1409dd0f5  vmovaps xmm9, [rsp+0x80]
00007ff1409dd0fe  vmovaps xmm10, [rsp+0x90]
00007ff1409dd107  vmovaps xmm11, [rsp+0xA0]
00007ff1409dd110  vmovaps xmm12, [rsp+0xB0]
00007ff1409dd119  vmovaps xmm13, [rsp+0xC0]
00007ff1409dd122  vmovaps xmm14, [rsp+0xD0]
00007ff1409dd12b  vmovaps xmm15, [rsp+0xE0]
00007ff1409dd134  add rsp, 0xF0
00007ff1409dd13b  pop r11
00007ff1409dd13d  pop r10
00007ff1409dd13f  pop r9
00007ff1409dd141  pop r8
00007ff1409dd143  pop rsi
00007ff1409dd144  pop rdi
00007ff1409dd145  pop rdx
00007ff1409dd146  pop rcx
00007ff1409dd147  pop rax
00007ff1409dd148  add rsp, 0x08
00007ff1409dd14c  jmp 0x00007FF1409D958E
00007ff1409dd151  sub rsp, 0x08
00007ff1409dd155  push rax
00007ff1409dd156  push rcx
00007ff1409dd157  push rdx
00007ff1409dd158  push rdi
00007ff1409dd159  push rsi
00007ff1409dd15a  push r8
00007ff1409dd15c  push r9
00007ff1409dd15e  push r10
00007ff1409dd160  push r11
00007ff1409dd162  sub rsp, 0xF0
00007ff1409dd169  vmovaps [rsp], xmm0
00007ff1409dd16e  vmovaps [rsp+0x10], xmm1
00007ff1409dd174  vmovaps [rsp+0x20], xmm2
00007ff1409dd17a  vmovaps [rsp+0x30], xmm3
00007ff1409dd180  vmovaps [rsp+0x40], xmm4
00007ff1409dd186  vmovaps [rsp+0x50], xmm5
00007ff1409dd18c  vmovaps [rsp+0x60], xmm7
00007ff1409dd192  vmovaps [rsp+0x70], xmm8
00007ff1409dd198  vmovaps [rsp+0x80], xmm9
00007ff1409dd1a1  vmovaps [rsp+0x90], xmm10
00007ff1409dd1aa  vmovaps [rsp+0xA0], xmm11
00007ff1409dd1b3  vmovaps [rsp+0xB0], xmm12
00007ff1409dd1bc  vmovaps [rsp+0xC0], xmm13
00007ff1409dd1c5  vmovaps [rsp+0xD0], xmm14
00007ff1409dd1ce  vmovaps [rsp+0xE0], xmm15
00007ff1409dd1d7  sub rsp, 0x30
00007ff1409dd1db  movaps [rsp], xmm6
00007ff1409dd1df  movaps [rsp+0x10], xmm1
00007ff1409dd1e4  movaps [rsp+0x20], xmm14
00007ff1409dd1ea  lea rdi, [rsp]
00007ff1409dd1ee  mov esi, 0x00
00007ff1409dd1f3  mov rax, 0x565C7F10C530
00007ff1409dd1fd  call rax
00007ff1409dd1ff  movaps xmm6, [rsp]
00007ff1409dd203  add rsp, 0x30
00007ff1409dd207  vmovaps xmm0, [rsp]
00007ff1409dd20c  vmovaps xmm1, [rsp+0x10]
00007ff1409dd212  vmovaps xmm2, [rsp+0x20]
00007ff1409dd218  vmovaps xmm3, [rsp+0x30]
00007ff1409dd21e  vmovaps xmm4, [rsp+0x40]
00007ff1409dd224  vmovaps xmm5, [rsp+0x50]
00007ff1409dd22a  vmovaps xmm7, [rsp+0x60]
00007ff1409dd230  vmovaps xmm8, [rsp+0x70]
00007ff1409dd236  vmovaps xmm9, [rsp+0x80]
00007ff1409dd23f  vmovaps xmm10, [rsp+0x90]
00007ff1409dd248  vmovaps xmm11, [rsp+0xA0]
00007ff1409dd251  vmovaps xmm12, [rsp+0xB0]
00007ff1409dd25a  vmovaps xmm13, [rsp+0xC0]
00007ff1409dd263  vmovaps xmm14, [rsp+0xD0]
00007ff1409dd26c  vmovaps xmm15, [rsp+0xE0]
00007ff1409dd275  add rsp, 0xF0
00007ff1409dd27c  pop r11
00007ff1409dd27e  pop r10
00007ff1409dd280  pop r9
00007ff1409dd282  pop r8
00007ff1409dd284  pop rsi
00007ff1409dd285  pop rdi
00007ff1409dd286  pop rdx
00007ff1409dd287  pop rcx
00007ff1409dd288  pop rax
00007ff1409dd289  add rsp, 0x08
00007ff1409dd28d  jmp 0x00007FF1409D95BA
00007ff1409dd292  sub rsp, 0x08
00007ff1409dd296  push rax
00007ff1409dd297  push rcx
00007ff1409dd298  push rdx
00007ff1409dd299  push rdi
00007ff1409dd29a  push rsi
00007ff1409dd29b  push r8
00007ff1409dd29d  push r9
00007ff1409dd29f  push r10
00007ff1409dd2a1  push r11
00007ff1409dd2a3  sub rsp, 0xF0
00007ff1409dd2aa  vmovaps [rsp], xmm0
00007ff1409dd2af  vmovaps [rsp+0x10], xmm1
00007ff1409dd2b5  vmovaps [rsp+0x20], xmm2
00007ff1409dd2bb  vmovaps [rsp+0x30], xmm3
00007ff1409dd2c1  vmovaps [rsp+0x40], xmm4
00007ff1409dd2c7  vmovaps [rsp+0x50], xmm5
00007ff1409dd2cd  vmovaps [rsp+0x60], xmm6
00007ff1409dd2d3  vmovaps [rsp+0x70], xmm7
00007ff1409dd2d9  vmovaps [rsp+0x80], xmm8
00007ff1409dd2e2  vmovaps [rsp+0x90], xmm9
00007ff1409dd2eb  vmovaps [rsp+0xA0], xmm10
00007ff1409dd2f4  vmovaps [rsp+0xB0], xmm11
00007ff1409dd2fd  vmovaps [rsp+0xC0], xmm12
00007ff1409dd306  vmovaps [rsp+0xD0], xmm13
00007ff1409dd30f  vmovaps [rsp+0xE0], xmm15
00007ff1409dd318  sub rsp, 0x30
00007ff1409dd31c  movaps [rsp], xmm14
00007ff1409dd321  movaps [rsp+0x10], xmm12
00007ff1409dd327  movaps [rsp+0x20], xmm1
00007ff1409dd32c  lea rdi, [rsp]
00007ff1409dd330  mov esi, 0x00
00007ff1409dd335  mov rax, 0x565C7F10C530
00007ff1409dd33f  call rax
00007ff1409dd341  movaps xmm14, [rsp]
00007ff1409dd346  add rsp, 0x30
00007ff1409dd34a  vmovaps xmm0, [rsp]
00007ff1409dd34f  vmovaps xmm1, [rsp+0x10]
00007ff1409dd355  vmovaps xmm2, [rsp+0x20]
00007ff1409dd35b  vmovaps xmm3, [rsp+0x30]
00007ff1409dd361  vmovaps xmm4, [rsp+0x40]
00007ff1409dd367  vmovaps xmm5, [rsp+0x50]
00007ff1409dd36d  vmovaps xmm6, [rsp+0x60]
00007ff1409dd373  vmovaps xmm7, [rsp+0x70]
00007ff1409dd379  vmovaps xmm8, [rsp+0x80]
00007ff1409dd382  vmovaps xmm9, [rsp+0x90]
00007ff1409dd38b  vmovaps xmm10, [rsp+0xA0]
00007ff1409dd394  vmovaps xmm11, [rsp+0xB0]
00007ff1409dd39d  vmovaps xmm12, [rsp+0xC0]
00007ff1409dd3a6  vmovaps xmm13, [rsp+0xD0]
00007ff1409dd3af  vmovaps xmm15, [rsp+0xE0]
00007ff1409dd3b8  add rsp, 0xF0
00007ff1409dd3bf  pop r11
00007ff1409dd3c1  pop r10
00007ff1409dd3c3  pop r9
00007ff1409dd3c5  pop r8
00007ff1409dd3c7  pop rsi
00007ff1409dd3c8  pop rdi
00007ff1409dd3c9  pop rdx
00007ff1409dd3ca  pop rcx
00007ff1409dd3cb  pop rax
00007ff1409dd3cc  add rsp, 0x08
00007ff1409dd3d0  jmp 0x00007FF1409D95E0
00007ff1409dd3d5  sub rsp, 0x08
00007ff1409dd3d9  push rax
00007ff1409dd3da  push rcx
00007ff1409dd3db  push rdx
00007ff1409dd3dc  push rdi
00007ff1409dd3dd  push rsi
00007ff1409dd3de  push r8
00007ff1409dd3e0  push r9
00007ff1409dd3e2  push r10
00007ff1409dd3e4  push r11
00007ff1409dd3e6  sub rsp, 0xF0
00007ff1409dd3ed  vmovaps [rsp], xmm0
00007ff1409dd3f2  vmovaps [rsp+0x10], xmm2
00007ff1409dd3f8  vmovaps [rsp+0x20], xmm3
00007ff1409dd3fe  vmovaps [rsp+0x30], xmm4
00007ff1409dd404  vmovaps [rsp+0x40], xmm5
00007ff1409dd40a  vmovaps [rsp+0x50], xmm6
00007ff1409dd410  vmovaps [rsp+0x60], xmm7
00007ff1409dd416  vmovaps [rsp+0x70], xmm8
00007ff1409dd41c  vmovaps [rsp+0x80], xmm9
00007ff1409dd425  vmovaps [rsp+0x90], xmm10
00007ff1409dd42e  vmovaps [rsp+0xA0], xmm11
00007ff1409dd437  vmovaps [rsp+0xB0], xmm12
00007ff1409dd440  vmovaps [rsp+0xC0], xmm13
00007ff1409dd449  vmovaps [rsp+0xD0], xmm14
00007ff1409dd452  vmovaps [rsp+0xE0], xmm15
00007ff1409dd45b  sub rsp, 0x30
00007ff1409dd45f  movaps [rsp], xmm1
00007ff1409dd463  movaps [rsp+0x10], xmm13
00007ff1409dd469  movaps [rsp+0x20], xmm9
00007ff1409dd46f  lea rdi, [rsp]
00007ff1409dd473  mov esi, 0x00
00007ff1409dd478  mov rax, 0x565C7F10C530
00007ff1409dd482  call rax
00007ff1409dd484  movaps xmm1, [rsp]
00007ff1409dd488  add rsp, 0x30
00007ff1409dd48c  vmovaps xmm0, [rsp]
00007ff1409dd491  vmovaps xmm2, [rsp+0x10]
00007ff1409dd497  vmovaps xmm3, [rsp+0x20]
00007ff1409dd49d  vmovaps xmm4, [rsp+0x30]
00007ff1409dd4a3  vmovaps xmm5, [rsp+0x40]
00007ff1409dd4a9  vmovaps xmm6, [rsp+0x50]
00007ff1409dd4af  vmovaps xmm7, [rsp+0x60]
00007ff1409dd4b5  vmovaps xmm8, [rsp+0x70]
00007ff1409dd4bb  vmovaps xmm9, [rsp+0x80]
00007ff1409dd4c4  vmovaps xmm10, [rsp+0x90]
00007ff1409dd4cd  vmovaps xmm11, [rsp+0xA0]
00007ff1409dd4d6  vmovaps xmm12, [rsp+0xB0]
00007ff1409dd4df  vmovaps xmm13, [rsp+0xC0]
00007ff1409dd4e8  vmovaps xmm14, [rsp+0xD0]
00007ff1409dd4f1  vmovaps xmm15, [rsp+0xE0]
00007ff1409dd4fa  add rsp, 0xF0
00007ff1409dd501  pop r11
00007ff1409dd503  pop r10
00007ff1409dd505  pop r9
00007ff1409dd507  pop r8
00007ff1409dd509  pop rsi
00007ff1409dd50a  pop rdi
00007ff1409dd50b  pop rdx
00007ff1409dd50c  pop rcx
00007ff1409dd50d  pop rax
00007ff1409dd50e  add rsp, 0x08
00007ff1409dd512  jmp 0x00007FF1409D95FA
00007ff1409dd517  sub rsp, 0x08
00007ff1409dd51b  push rax
00007ff1409dd51c  push rcx
00007ff1409dd51d  push rdx
00007ff1409dd51e  push rdi
00007ff1409dd51f  push rsi
00007ff1409dd520  push r8
00007ff1409dd522  push r9
00007ff1409dd524  push r10
00007ff1409dd526  push r11
00007ff1409dd528  sub rsp, 0xF0
00007ff1409dd52f  vmovaps [rsp], xmm0
00007ff1409dd534  vmovaps [rsp+0x10], xmm1
00007ff1409dd53a  vmovaps [rsp+0x20], xmm2
00007ff1409dd540  vmovaps [rsp+0x30], xmm3
00007ff1409dd546  vmovaps [rsp+0x40], xmm4
00007ff1409dd54c  vmovaps [rsp+0x50], xmm5
00007ff1409dd552  vmovaps [rsp+0x60], xmm6
00007ff1409dd558  vmovaps [rsp+0x70], xmm7
00007ff1409dd55e  vmovaps [rsp+0x80], xmm8
00007ff1409dd567  vmovaps [rsp+0x90], xmm9
00007ff1409dd570  vmovaps [rsp+0xA0], xmm10
00007ff1409dd579  vmovaps [rsp+0xB0], xmm11
00007ff1409dd582  vmovaps [rsp+0xC0], xmm13
00007ff1409dd58b  vmovaps [rsp+0xD0], xmm14
00007ff1409dd594  vmovaps [rsp+0xE0], xmm15
00007ff1409dd59d  sub rsp, 0x30
00007ff1409dd5a1  movaps [rsp], xmm12
00007ff1409dd5a6  movaps [rsp+0x10], xmm7
00007ff1409dd5ab  movaps [rsp+0x20], xmm13
00007ff1409dd5b1  lea rdi, [rsp]
00007ff1409dd5b5  mov esi, 0x00
00007ff1409dd5ba  mov rax, 0x565C7F10C530
00007ff1409dd5c4  call rax
00007ff1409dd5c6  movaps xmm12, [rsp]
00007ff1409dd5cb  add rsp, 0x30
00007ff1409dd5cf  vmovaps xmm0, [rsp]
00007ff1409dd5d4  vmovaps xmm1, [rsp+0x10]
00007ff1409dd5da  vmovaps xmm2, [rsp+0x20]
00007ff1409dd5e0  vmovaps xmm3, [rsp+0x30]
00007ff1409dd5e6  vmovaps xmm4, [rsp+0x40]
00007ff1409dd5ec  vmovaps xmm5, [rsp+0x50]
00007ff1409dd5f2  vmovaps xmm6, [rsp+0x60]
00007ff1409dd5f8  vmovaps xmm7, [rsp+0x70]
00007ff1409dd5fe  vmovaps xmm8, [rsp+0x80]
00007ff1409dd607  vmovaps xmm9, [rsp+0x90]
00007ff1409dd610  vmovaps xmm10, [rsp+0xA0]
00007ff1409dd619  vmovaps xmm11, [rsp+0xB0]
00007ff1409dd622  vmovaps xmm13, [rsp+0xC0]
00007ff1409dd62b  vmovaps xmm14, [rsp+0xD0]
00007ff1409dd634  vmovaps xmm15, [rsp+0xE0]
00007ff1409dd63d  add rsp, 0xF0
00007ff1409dd644  pop r11
00007ff1409dd646  pop r10
00007ff1409dd648  pop r9
00007ff1409dd64a  pop r8
00007ff1409dd64c  pop rsi
00007ff1409dd64d  pop rdi
00007ff1409dd64e  pop rdx
00007ff1409dd64f  pop rcx
00007ff1409dd650  pop rax
00007ff1409dd651  add rsp, 0x08
00007ff1409dd655  jmp 0x00007FF1409D9621
00007ff1409dd65a  sub rsp, 0x08
00007ff1409dd65e  push rax
00007ff1409dd65f  push rcx
00007ff1409dd660  push rdx
00007ff1409dd661  push rdi
00007ff1409dd662  push rsi
00007ff1409dd663  push r8
00007ff1409dd665  push r9
00007ff1409dd667  push r10
00007ff1409dd669  push r11
00007ff1409dd66b  sub rsp, 0xF0
00007ff1409dd672  vmovaps [rsp], xmm0
00007ff1409dd677  vmovaps [rsp+0x10], xmm1
00007ff1409dd67d  vmovaps [rsp+0x20], xmm2
00007ff1409dd683  vmovaps [rsp+0x30], xmm3
00007ff1409dd689  vmovaps [rsp+0x40], xmm4
00007ff1409dd68f  vmovaps [rsp+0x50], xmm5
00007ff1409dd695  vmovaps [rsp+0x60], xmm6
00007ff1409dd69b  vmovaps [rsp+0x70], xmm7
00007ff1409dd6a1  vmovaps [rsp+0x80], xmm8
00007ff1409dd6aa  vmovaps [rsp+0x90], xmm9
00007ff1409dd6b3  vmovaps [rsp+0xA0], xmm10
00007ff1409dd6bc  vmovaps [rsp+0xB0], xmm11
00007ff1409dd6c5  vmovaps [rsp+0xC0], xmm12
00007ff1409dd6ce  vmovaps [rsp+0xD0], xmm14
00007ff1409dd6d7  vmovaps [rsp+0xE0], xmm15
00007ff1409dd6e0  sub rsp, 0x30
00007ff1409dd6e4  movaps [rsp], xmm13
00007ff1409dd6e9  movaps [rsp+0x10], xmm15
00007ff1409dd6ef  movaps [rsp+0x20], xmm8
00007ff1409dd6f5  lea rdi, [rsp]
00007ff1409dd6f9  mov esi, 0x00
00007ff1409dd6fe  mov rax, 0x565C7F10C530
00007ff1409dd708  call rax
00007ff1409dd70a  movaps xmm13, [rsp]
00007ff1409dd70f  add rsp, 0x30
00007ff1409dd713  vmovaps xmm0, [rsp]
00007ff1409dd718  vmovaps xmm1, [rsp+0x10]
00007ff1409dd71e  vmovaps xmm2, [rsp+0x20]
00007ff1409dd724  vmovaps xmm3, [rsp+0x30]
00007ff1409dd72a  vmovaps xmm4, [rsp+0x40]
00007ff1409dd730  vmovaps xmm5, [rsp+0x50]
00007ff1409dd736  vmovaps xmm6, [rsp+0x60]
00007ff1409dd73c  vmovaps xmm7, [rsp+0x70]
00007ff1409dd742  vmovaps xmm8, [rsp+0x80]
00007ff1409dd74b  vmovaps xmm9, [rsp+0x90]
00007ff1409dd754  vmovaps xmm10, [rsp+0xA0]
00007ff1409dd75d  vmovaps xmm11, [rsp+0xB0]
00007ff1409dd766  vmovaps xmm12, [rsp+0xC0]
00007ff1409dd76f  vmovaps xmm14, [rsp+0xD0]
00007ff1409dd778  vmovaps xmm15, [rsp+0xE0]
00007ff1409dd781  add rsp, 0xF0
00007ff1409dd788  pop r11
00007ff1409dd78a  pop r10
00007ff1409dd78c  pop r9
00007ff1409dd78e  pop r8
00007ff1409dd790  pop rsi
00007ff1409dd791  pop rdi
00007ff1409dd792  pop rdx
00007ff1409dd793  pop rcx
00007ff1409dd794  pop rax
00007ff1409dd795  add rsp, 0x08
00007ff1409dd799  jmp 0x00007FF1409D963C
00007ff1409dd79e  sub rsp, 0x08
00007ff1409dd7a2  push rax
00007ff1409dd7a3  push rcx
00007ff1409dd7a4  push rdx
00007ff1409dd7a5  push rdi
00007ff1409dd7a6  push rsi
00007ff1409dd7a7  push r8
00007ff1409dd7a9  push r9
00007ff1409dd7ab  push r10
00007ff1409dd7ad  push r11
00007ff1409dd7af  sub rsp, 0xF0
00007ff1409dd7b6  vmovaps [rsp], xmm0
00007ff1409dd7bb  vmovaps [rsp+0x10], xmm1
00007ff1409dd7c1  vmovaps [rsp+0x20], xmm2
00007ff1409dd7c7  vmovaps [rsp+0x30], xmm3
00007ff1409dd7cd  vmovaps [rsp+0x40], xmm4
00007ff1409dd7d3  vmovaps [rsp+0x50], xmm5
00007ff1409dd7d9  vmovaps [rsp+0x60], xmm6
00007ff1409dd7df  vmovaps [rsp+0x70], xmm7
00007ff1409dd7e5  vmovaps [rsp+0x80], xmm9
00007ff1409dd7ee  vmovaps [rsp+0x90], xmm10
00007ff1409dd7f7  vmovaps [rsp+0xA0], xmm11
00007ff1409dd800  vmovaps [rsp+0xB0], xmm12
00007ff1409dd809  vmovaps [rsp+0xC0], xmm13
00007ff1409dd812  vmovaps [rsp+0xD0], xmm14
00007ff1409dd81b  vmovaps [rsp+0xE0], xmm15
00007ff1409dd824  sub rsp, 0x30
00007ff1409dd828  movaps [rsp], xmm8
00007ff1409dd82d  movaps [rsp+0x10], xmm15
00007ff1409dd833  movaps [rsp+0x20], xmm9
00007ff1409dd839  lea rdi, [rsp]
00007ff1409dd83d  mov esi, 0x00
00007ff1409dd842  mov rax, 0x565C7F10C530
00007ff1409dd84c  call rax
00007ff1409dd84e  movaps xmm8, [rsp]
00007ff1409dd853  add rsp, 0x30
00007ff1409dd857  vmovaps xmm0, [rsp]
00007ff1409dd85c  vmovaps xmm1, [rsp+0x10]
00007ff1409dd862  vmovaps xmm2, [rsp+0x20]
00007ff1409dd868  vmovaps xmm3, [rsp+0x30]
00007ff1409dd86e  vmovaps xmm4, [rsp+0x40]
00007ff1409dd874  vmovaps xmm5, [rsp+0x50]
00007ff1409dd87a  vmovaps xmm6, [rsp+0x60]
00007ff1409dd880  vmovaps xmm7, [rsp+0x70]
00007ff1409dd886  vmovaps xmm9, [rsp+0x80]
00007ff1409dd88f  vmovaps xmm10, [rsp+0x90]
00007ff1409dd898  vmovaps xmm11, [rsp+0xA0]
00007ff1409dd8a1  vmovaps xmm12, [rsp+0xB0]
00007ff1409dd8aa  vmovaps xmm13, [rsp+0xC0]
00007ff1409dd8b3  vmovaps xmm14, [rsp+0xD0]
00007ff1409dd8bc  vmovaps xmm15, [rsp+0xE0]
00007ff1409dd8c5  add rsp, 0xF0
00007ff1409dd8cc  pop r11
00007ff1409dd8ce  pop r10
00007ff1409dd8d0  pop r9
00007ff1409dd8d2  pop r8
00007ff1409dd8d4  pop rsi
00007ff1409dd8d5  pop rdi
00007ff1409dd8d6  pop rdx
00007ff1409dd8d7  pop rcx
00007ff1409dd8d8  pop rax
00007ff1409dd8d9  add rsp, 0x08
00007ff1409dd8dd  jmp 0x00007FF1409D966A
00007ff1409dd8e2  sub rsp, 0x08
00007ff1409dd8e6  push rax
00007ff1409dd8e7  push rcx
00007ff1409dd8e8  push rdx
00007ff1409dd8e9  push rdi
00007ff1409dd8ea  push rsi
00007ff1409dd8eb  push r8
00007ff1409dd8ed  push r9
00007ff1409dd8ef  push r10
00007ff1409dd8f1  push r11
00007ff1409dd8f3  sub rsp, 0xF0
00007ff1409dd8fa  vmovaps [rsp], xmm0
00007ff1409dd8ff  vmovaps [rsp+0x10], xmm1
00007ff1409dd905  vmovaps [rsp+0x20], xmm2
00007ff1409dd90b  vmovaps [rsp+0x30], xmm3
00007ff1409dd911  vmovaps [rsp+0x40], xmm4
00007ff1409dd917  vmovaps [rsp+0x50], xmm5
00007ff1409dd91d  vmovaps [rsp+0x60], xmm6
00007ff1409dd923  vmovaps [rsp+0x70], xmm7
00007ff1409dd929  vmovaps [rsp+0x80], xmm8
00007ff1409dd932  vmovaps [rsp+0x90], xmm9
00007ff1409dd93b  vmovaps [rsp+0xA0], xmm10
00007ff1409dd944  vmovaps [rsp+0xB0], xmm11
00007ff1409dd94d  vmovaps [rsp+0xC0], xmm12
00007ff1409dd956  vmovaps [rsp+0xD0], xmm13
00007ff1409dd95f  vmovaps [rsp+0xE0], xmm14
00007ff1409dd968  sub rsp, 0x30
00007ff1409dd96c  movaps [rsp], xmm15
00007ff1409dd971  movaps [rsp+0x10], xmm11
00007ff1409dd977  movaps [rsp+0x20], xmm6
00007ff1409dd97c  lea rdi, [rsp]
00007ff1409dd980  mov esi, 0x00
00007ff1409dd985  mov rax, 0x565C7F10C530
00007ff1409dd98f  call rax
00007ff1409dd991  movaps xmm15, [rsp]
00007ff1409dd996  add rsp, 0x30
00007ff1409dd99a  vmovaps xmm0, [rsp]
00007ff1409dd99f  vmovaps xmm1, [rsp+0x10]
00007ff1409dd9a5  vmovaps xmm2, [rsp+0x20]
00007ff1409dd9ab  vmovaps xmm3, [rsp+0x30]
00007ff1409dd9b1  vmovaps xmm4, [rsp+0x40]
00007ff1409dd9b7  vmovaps xmm5, [rsp+0x50]
00007ff1409dd9bd  vmovaps xmm6, [rsp+0x60]
00007ff1409dd9c3  vmovaps xmm7, [rsp+0x70]
00007ff1409dd9c9  vmovaps xmm8, [rsp+0x80]
00007ff1409dd9d2  vmovaps xmm9, [rsp+0x90]
00007ff1409dd9db  vmovaps xmm10, [rsp+0xA0]
00007ff1409dd9e4  vmovaps xmm11, [rsp+0xB0]
00007ff1409dd9ed  vmovaps xmm12, [rsp+0xC0]
00007ff1409dd9f6  vmovaps xmm13, [rsp+0xD0]
00007ff1409dd9ff  vmovaps xmm14, [rsp+0xE0]
00007ff1409dda08  add rsp, 0xF0
00007ff1409dda0f  pop r11
00007ff1409dda11  pop r10
00007ff1409dda13  pop r9
00007ff1409dda15  pop r8
00007ff1409dda17  pop rsi
00007ff1409dda18  pop rdi
00007ff1409dda19  pop rdx
00007ff1409dda1a  pop rcx
00007ff1409dda1b  pop rax
00007ff1409dda1c  add rsp, 0x08
00007ff1409dda20  jmp 0x00007FF1409D9685
00007ff1409dda25  sub rsp, 0x08
00007ff1409dda29  push rax
00007ff1409dda2a  push rcx
00007ff1409dda2b  push rdx
00007ff1409dda2c  push rdi
00007ff1409dda2d  push rsi
00007ff1409dda2e  push r8
00007ff1409dda30  push r9
00007ff1409dda32  push r10
00007ff1409dda34  push r11
00007ff1409dda36  sub rsp, 0xF0
00007ff1409dda3d  vmovaps [rsp], xmm0
00007ff1409dda42  vmovaps [rsp+0x10], xmm1
00007ff1409dda48  vmovaps [rsp+0x20], xmm2
00007ff1409dda4e  vmovaps [rsp+0x30], xmm3
00007ff1409dda54  vmovaps [rsp+0x40], xmm4
00007ff1409dda5a  vmovaps [rsp+0x50], xmm5
00007ff1409dda60  vmovaps [rsp+0x60], xmm6
00007ff1409dda66  vmovaps [rsp+0x70], xmm8
00007ff1409dda6c  vmovaps [rsp+0x80], xmm9
00007ff1409dda75  vmovaps [rsp+0x90], xmm10
00007ff1409dda7e  vmovaps [rsp+0xA0], xmm11
00007ff1409dda87  vmovaps [rsp+0xB0], xmm12
00007ff1409dda90  vmovaps [rsp+0xC0], xmm13
00007ff1409dda99  vmovaps [rsp+0xD0], xmm14
00007ff1409ddaa2  vmovaps [rsp+0xE0], xmm15
00007ff1409ddaab  sub rsp, 0x30
00007ff1409ddaaf  movaps [rsp], xmm7
00007ff1409ddab3  movaps [rsp+0x10], xmm11
00007ff1409ddab9  movaps [rsp+0x20], xmm9
00007ff1409ddabf  lea rdi, [rsp]
00007ff1409ddac3  mov esi, 0x00
00007ff1409ddac8  mov rax, 0x565C7F10C530
00007ff1409ddad2  call rax
00007ff1409ddad4  movaps xmm7, [rsp]
00007ff1409ddad8  add rsp, 0x30
00007ff1409ddadc  vmovaps xmm0, [rsp]
00007ff1409ddae1  vmovaps xmm1, [rsp+0x10]
00007ff1409ddae7  vmovaps xmm2, [rsp+0x20]
00007ff1409ddaed  vmovaps xmm3, [rsp+0x30]
00007ff1409ddaf3  vmovaps xmm4, [rsp+0x40]
00007ff1409ddaf9  vmovaps xmm5, [rsp+0x50]
00007ff1409ddaff  vmovaps xmm6, [rsp+0x60]
00007ff1409ddb05  vmovaps xmm8, [rsp+0x70]
00007ff1409ddb0b  vmovaps xmm9, [rsp+0x80]
00007ff1409ddb14  vmovaps xmm10, [rsp+0x90]
00007ff1409ddb1d  vmovaps xmm11, [rsp+0xA0]
00007ff1409ddb26  vmovaps xmm12, [rsp+0xB0]
00007ff1409ddb2f  vmovaps xmm13, [rsp+0xC0]
00007ff1409ddb38  vmovaps xmm14, [rsp+0xD0]
00007ff1409ddb41  vmovaps xmm15, [rsp+0xE0]
00007ff1409ddb4a  add rsp, 0xF0
00007ff1409ddb51  pop r11
00007ff1409ddb53  pop r10
00007ff1409ddb55  pop r9
00007ff1409ddb57  pop r8
00007ff1409ddb59  pop rsi
00007ff1409ddb5a  pop rdi
00007ff1409ddb5b  pop rdx
00007ff1409ddb5c  pop rcx
00007ff1409ddb5d  pop rax
00007ff1409ddb5e  add rsp, 0x08
00007ff1409ddb62  jmp 0x00007FF1409D96B2
00007ff1409ddb67  sub rsp, 0x08
00007ff1409ddb6b  push rax
00007ff1409ddb6c  push rcx
00007ff1409ddb6d  push rdx
00007ff1409ddb6e  push rdi
00007ff1409ddb6f  push rsi
00007ff1409ddb70  push r8
00007ff1409ddb72  push r9
00007ff1409ddb74  push r10
00007ff1409ddb76  push r11
00007ff1409ddb78  sub rsp, 0xF0
00007ff1409ddb7f  vmovaps [rsp], xmm0
00007ff1409ddb84  vmovaps [rsp+0x10], xmm1
00007ff1409ddb8a  vmovaps [rsp+0x20], xmm2
00007ff1409ddb90  vmovaps [rsp+0x30], xmm3
00007ff1409ddb96  vmovaps [rsp+0x40], xmm4
00007ff1409ddb9c  vmovaps [rsp+0x50], xmm5
00007ff1409ddba2  vmovaps [rsp+0x60], xmm6
00007ff1409ddba8  vmovaps [rsp+0x70], xmm7
00007ff1409ddbae  vmovaps [rsp+0x80], xmm8
00007ff1409ddbb7  vmovaps [rsp+0x90], xmm9
00007ff1409ddbc0  vmovaps [rsp+0xA0], xmm10
00007ff1409ddbc9  vmovaps [rsp+0xB0], xmm12
00007ff1409ddbd2  vmovaps [rsp+0xC0], xmm13
00007ff1409ddbdb  vmovaps [rsp+0xD0], xmm14
00007ff1409ddbe4  vmovaps [rsp+0xE0], xmm15
00007ff1409ddbed  sub rsp, 0x30
00007ff1409ddbf1  movaps [rsp], xmm11
00007ff1409ddbf6  movaps [rsp+0x10], xmm10
00007ff1409ddbfc  movaps [rsp+0x20], xmm14
00007ff1409ddc02  lea rdi, [rsp]
00007ff1409ddc06  mov esi, 0x00
00007ff1409ddc0b  mov rax, 0x565C7F10C530
00007ff1409ddc15  call rax
00007ff1409ddc17  movaps xmm11, [rsp]
00007ff1409ddc1c  add rsp, 0x30
00007ff1409ddc20  vmovaps xmm0, [rsp]
00007ff1409ddc25  vmovaps xmm1, [rsp+0x10]
00007ff1409ddc2b  vmovaps xmm2, [rsp+0x20]
00007ff1409ddc31  vmovaps xmm3, [rsp+0x30]
00007ff1409ddc37  vmovaps xmm4, [rsp+0x40]
00007ff1409ddc3d  vmovaps xmm5, [rsp+0x50]
00007ff1409ddc43  vmovaps xmm6, [rsp+0x60]
00007ff1409ddc49  vmovaps xmm7, [rsp+0x70]
00007ff1409ddc4f  vmovaps xmm8, [rsp+0x80]
00007ff1409ddc58  vmovaps xmm9, [rsp+0x90]
00007ff1409ddc61  vmovaps xmm10, [rsp+0xA0]
00007ff1409ddc6a  vmovaps xmm12, [rsp+0xB0]
00007ff1409ddc73  vmovaps xmm13, [rsp+0xC0]
00007ff1409ddc7c  vmovaps xmm14, [rsp+0xD0]
00007ff1409ddc85  vmovaps xmm15, [rsp+0xE0]
00007ff1409ddc8e  add rsp, 0xF0
00007ff1409ddc95  pop r11
00007ff1409ddc97  pop r10
00007ff1409ddc99  pop r9
00007ff1409ddc9b  pop r8
00007ff1409ddc9d  pop rsi
00007ff1409ddc9e  pop rdi
00007ff1409ddc9f  pop rdx
00007ff1409ddca0  pop rcx
00007ff1409ddca1  pop rax
00007ff1409ddca2  add rsp, 0x08
00007ff1409ddca6  jmp 0x00007FF1409D96CD
00007ff1409ddcab  call 0x00007FF1408E45A0
00007ff1409ddcb0  jmp 0x00007FF1409D96D7
00007ff1409ddcb5  sub rsp, 0x08
00007ff1409ddcb9  push rax
00007ff1409ddcba  push rcx
00007ff1409ddcbb  push rdx
00007ff1409ddcbc  push rdi
00007ff1409ddcbd  push rsi
00007ff1409ddcbe  push r8
00007ff1409ddcc0  push r9
00007ff1409ddcc2  push r10
00007ff1409ddcc4  push r11
00007ff1409ddcc6  sub rsp, 0xF0
00007ff1409ddccd  vmovaps [rsp], xmm0
00007ff1409ddcd2  vmovaps [rsp+0x10], xmm1
00007ff1409ddcd8  vmovaps [rsp+0x20], xmm2
00007ff1409ddcde  vmovaps [rsp+0x30], xmm3
00007ff1409ddce4  vmovaps [rsp+0x40], xmm4
00007ff1409ddcea  vmovaps [rsp+0x50], xmm5
00007ff1409ddcf0  vmovaps [rsp+0x60], xmm6
00007ff1409ddcf6  vmovaps [rsp+0x70], xmm7
00007ff1409ddcfc  vmovaps [rsp+0x80], xmm8
00007ff1409ddd05  vmovaps [rsp+0x90], xmm9
00007ff1409ddd0e  vmovaps [rsp+0xA0], xmm11
00007ff1409ddd17  vmovaps [rsp+0xB0], xmm12
00007ff1409ddd20  vmovaps [rsp+0xC0], xmm13
00007ff1409ddd29  vmovaps [rsp+0xD0], xmm14
00007ff1409ddd32  vmovaps [rsp+0xE0], xmm15
00007ff1409ddd3b  sub rsp, 0x30
00007ff1409ddd3f  movaps [rsp], xmm10
00007ff1409ddd44  movaps [rsp+0x10], xmm1
00007ff1409ddd49  movaps [rsp+0x20], xmm12
00007ff1409ddd4f  lea rdi, [rsp]
00007ff1409ddd53  mov esi, 0x00
00007ff1409ddd58  mov rax, 0x565C7F10C530
00007ff1409ddd62  call rax
00007ff1409ddd64  movaps xmm10, [rsp]
00007ff1409ddd69  add rsp, 0x30
00007ff1409ddd6d  vmovaps xmm0, [rsp]
00007ff1409ddd72  vmovaps xmm1, [rsp+0x10]
00007ff1409ddd78  vmovaps xmm2, [rsp+0x20]
00007ff1409ddd7e  vmovaps xmm3, [rsp+0x30]
00007ff1409ddd84  vmovaps xmm4, [rsp+0x40]
00007ff1409ddd8a  vmovaps xmm5, [rsp+0x50]
00007ff1409ddd90  vmovaps xmm6, [rsp+0x60]
00007ff1409ddd96  vmovaps xmm7, [rsp+0x70]
00007ff1409ddd9c  vmovaps xmm8, [rsp+0x80]
00007ff1409ddda5  vmovaps xmm9, [rsp+0x90]
00007ff1409dddae  vmovaps xmm11, [rsp+0xA0]
00007ff1409dddb7  vmovaps xmm12, [rsp+0xB0]
00007ff1409dddc0  vmovaps xmm13, [rsp+0xC0]
00007ff1409dddc9  vmovaps xmm14, [rsp+0xD0]
00007ff1409dddd2  vmovaps xmm15, [rsp+0xE0]
00007ff1409ddddb  add rsp, 0xF0
00007ff1409ddde2  pop r11
00007ff1409ddde4  pop r10
00007ff1409ddde6  pop r9
00007ff1409ddde8  pop r8
00007ff1409dddea  pop rsi
00007ff1409dddeb  pop rdi
00007ff1409dddec  pop rdx
00007ff1409ddded  pop rcx
00007ff1409dddee  pop rax
00007ff1409dddef  add rsp, 0x08
00007ff1409dddf3  jmp 0x00007FF1409D96FA
00007ff1409dddf8  sub rsp, 0x08
00007ff1409dddfc  push rax
00007ff1409dddfd  push rcx
00007ff1409dddfe  push rdx
00007ff1409dddff  push rdi
00007ff1409dde00  push rsi
00007ff1409dde01  push r8
00007ff1409dde03  push r9
00007ff1409dde05  push r10
00007ff1409dde07  push r11
00007ff1409dde09  sub rsp, 0xF0
00007ff1409dde10  vmovaps [rsp], xmm0
00007ff1409dde15  vmovaps [rsp+0x10], xmm1
00007ff1409dde1b  vmovaps [rsp+0x20], xmm2
00007ff1409dde21  vmovaps [rsp+0x30], xmm3
00007ff1409dde27  vmovaps [rsp+0x40], xmm4
00007ff1409dde2d  vmovaps [rsp+0x50], xmm5
00007ff1409dde33  vmovaps [rsp+0x60], xmm6
00007ff1409dde39  vmovaps [rsp+0x70], xmm7
00007ff1409dde3f  vmovaps [rsp+0x80], xmm8
00007ff1409dde48  vmovaps [rsp+0x90], xmm9
00007ff1409dde51  vmovaps [rsp+0xA0], xmm10
00007ff1409dde5a  vmovaps [rsp+0xB0], xmm11
00007ff1409dde63  vmovaps [rsp+0xC0], xmm13
00007ff1409dde6c  vmovaps [rsp+0xD0], xmm14
00007ff1409dde75  vmovaps [rsp+0xE0], xmm15
00007ff1409dde7e  sub rsp, 0x30
00007ff1409dde82  movaps [rsp], xmm12
00007ff1409dde87  movaps [rsp+0x10], xmm14
00007ff1409dde8d  movaps [rsp+0x20], xmm1
00007ff1409dde92  lea rdi, [rsp]
00007ff1409dde96  mov esi, 0x00
00007ff1409dde9b  mov rax, 0x565C7F10C530
00007ff1409ddea5  call rax
00007ff1409ddea7  movaps xmm12, [rsp]
00007ff1409ddeac  add rsp, 0x30
00007ff1409ddeb0  vmovaps xmm0, [rsp]
00007ff1409ddeb5  vmovaps xmm1, [rsp+0x10]
00007ff1409ddebb  vmovaps xmm2, [rsp+0x20]
00007ff1409ddec1  vmovaps xmm3, [rsp+0x30]
00007ff1409ddec7  vmovaps xmm4, [rsp+0x40]
00007ff1409ddecd  vmovaps xmm5, [rsp+0x50]
00007ff1409dded3  vmovaps xmm6, [rsp+0x60]
00007ff1409dded9  vmovaps xmm7, [rsp+0x70]
00007ff1409ddedf  vmovaps xmm8, [rsp+0x80]
00007ff1409ddee8  vmovaps xmm9, [rsp+0x90]
00007ff1409ddef1  vmovaps xmm10, [rsp+0xA0]
00007ff1409ddefa  vmovaps xmm11, [rsp+0xB0]
00007ff1409ddf03  vmovaps xmm13, [rsp+0xC0]
00007ff1409ddf0c  vmovaps xmm14, [rsp+0xD0]
00007ff1409ddf15  vmovaps xmm15, [rsp+0xE0]
00007ff1409ddf1e  add rsp, 0xF0
00007ff1409ddf25  pop r11
00007ff1409ddf27  pop r10
00007ff1409ddf29  pop r9
00007ff1409ddf2b  pop r8
00007ff1409ddf2d  pop rsi
00007ff1409ddf2e  pop rdi
00007ff1409ddf2f  pop rdx
00007ff1409ddf30  pop rcx
00007ff1409ddf31  pop rax
00007ff1409ddf32  add rsp, 0x08
00007ff1409ddf36  jmp 0x00007FF1409D9729
00007ff1409ddf3b  sub rsp, 0x08
00007ff1409ddf3f  push rax
00007ff1409ddf40  push rcx
00007ff1409ddf41  push rdx
00007ff1409ddf42  push rdi
00007ff1409ddf43  push rsi
00007ff1409ddf44  push r8
00007ff1409ddf46  push r9
00007ff1409ddf48  push r10
00007ff1409ddf4a  push r11
00007ff1409ddf4c  sub rsp, 0xF0
00007ff1409ddf53  vmovaps [rsp], xmm0
00007ff1409ddf58  vmovaps [rsp+0x10], xmm1
00007ff1409ddf5e  vmovaps [rsp+0x20], xmm2
00007ff1409ddf64  vmovaps [rsp+0x30], xmm3
00007ff1409ddf6a  vmovaps [rsp+0x40], xmm4
00007ff1409ddf70  vmovaps [rsp+0x50], xmm5
00007ff1409ddf76  vmovaps [rsp+0x60], xmm6
00007ff1409ddf7c  vmovaps [rsp+0x70], xmm7
00007ff1409ddf82  vmovaps [rsp+0x80], xmm8
00007ff1409ddf8b  vmovaps [rsp+0x90], xmm9
00007ff1409ddf94  vmovaps [rsp+0xA0], xmm10
00007ff1409ddf9d  vmovaps [rsp+0xB0], xmm11
00007ff1409ddfa6  vmovaps [rsp+0xC0], xmm12
00007ff1409ddfaf  vmovaps [rsp+0xD0], xmm13
00007ff1409ddfb8  vmovaps [rsp+0xE0], xmm15
00007ff1409ddfc1  sub rsp, 0x30
00007ff1409ddfc5  movaps [rsp], xmm14
00007ff1409ddfca  movaps [rsp+0x10], xmm9
00007ff1409ddfd0  movaps [rsp+0x20], xmm1
00007ff1409ddfd5  lea rdi, [rsp]
00007ff1409ddfd9  mov esi, 0x00
00007ff1409ddfde  mov rax, 0x565C7F10C530
00007ff1409ddfe8  call rax
00007ff1409ddfea  movaps xmm14, [rsp]
00007ff1409ddfef  add rsp, 0x30
00007ff1409ddff3  vmovaps xmm0, [rsp]
00007ff1409ddff8  vmovaps xmm1, [rsp+0x10]
00007ff1409ddffe  vmovaps xmm2, [rsp+0x20]
00007ff1409de004  vmovaps xmm3, [rsp+0x30]
00007ff1409de00a  vmovaps xmm4, [rsp+0x40]
00007ff1409de010  vmovaps xmm5, [rsp+0x50]
00007ff1409de016  vmovaps xmm6, [rsp+0x60]
00007ff1409de01c  vmovaps xmm7, [rsp+0x70]
00007ff1409de022  vmovaps xmm8, [rsp+0x80]
00007ff1409de02b  vmovaps xmm9, [rsp+0x90]
00007ff1409de034  vmovaps xmm10, [rsp+0xA0]
00007ff1409de03d  vmovaps xmm11, [rsp+0xB0]
00007ff1409de046  vmovaps xmm12, [rsp+0xC0]
00007ff1409de04f  vmovaps xmm13, [rsp+0xD0]
00007ff1409de058  vmovaps xmm15, [rsp+0xE0]
00007ff1409de061  add rsp, 0xF0
00007ff1409de068  pop r11
00007ff1409de06a  pop r10
00007ff1409de06c  pop r9
00007ff1409de06e  pop r8
00007ff1409de070  pop rsi
00007ff1409de071  pop rdi
00007ff1409de072  pop rdx
00007ff1409de073  pop rcx
00007ff1409de074  pop rax
00007ff1409de075  add rsp, 0x08
00007ff1409de079  jmp 0x00007FF1409D9758
00007ff1409de07e  sub rsp, 0x08
00007ff1409de082  push rax
00007ff1409de083  push rcx
00007ff1409de084  push rdx
00007ff1409de085  push rdi
00007ff1409de086  push rsi
00007ff1409de087  push r8
00007ff1409de089  push r9
00007ff1409de08b  push r10
00007ff1409de08d  push r11
00007ff1409de08f  sub rsp, 0xF0
00007ff1409de096  vmovaps [rsp], xmm0
00007ff1409de09b  vmovaps [rsp+0x10], xmm2
00007ff1409de0a1  vmovaps [rsp+0x20], xmm3
00007ff1409de0a7  vmovaps [rsp+0x30], xmm4
00007ff1409de0ad  vmovaps [rsp+0x40], xmm5
00007ff1409de0b3  vmovaps [rsp+0x50], xmm6
00007ff1409de0b9  vmovaps [rsp+0x60], xmm7
00007ff1409de0bf  vmovaps [rsp+0x70], xmm8
00007ff1409de0c5  vmovaps [rsp+0x80], xmm9
00007ff1409de0ce  vmovaps [rsp+0x90], xmm10
00007ff1409de0d7  vmovaps [rsp+0xA0], xmm11
00007ff1409de0e0  vmovaps [rsp+0xB0], xmm12
00007ff1409de0e9  vmovaps [rsp+0xC0], xmm13
00007ff1409de0f2  vmovaps [rsp+0xD0], xmm14
00007ff1409de0fb  vmovaps [rsp+0xE0], xmm15
00007ff1409de104  sub rsp, 0x30
00007ff1409de108  movaps [rsp], xmm1
00007ff1409de10c  movaps [rsp+0x10], xmm13
00007ff1409de112  movaps [rsp+0x20], xmm8
00007ff1409de118  lea rdi, [rsp]
00007ff1409de11c  mov esi, 0x00
00007ff1409de121  mov rax, 0x565C7F10C530
00007ff1409de12b  call rax
00007ff1409de12d  movaps xmm1, [rsp]
00007ff1409de131  add rsp, 0x30
00007ff1409de135  vmovaps xmm0, [rsp]
00007ff1409de13a  vmovaps xmm2, [rsp+0x10]
00007ff1409de140  vmovaps xmm3, [rsp+0x20]
00007ff1409de146  vmovaps xmm4, [rsp+0x30]
00007ff1409de14c  vmovaps xmm5, [rsp+0x40]
00007ff1409de152  vmovaps xmm6, [rsp+0x50]
00007ff1409de158  vmovaps xmm7, [rsp+0x60]
00007ff1409de15e  vmovaps xmm8, [rsp+0x70]
00007ff1409de164  vmovaps xmm9, [rsp+0x80]
00007ff1409de16d  vmovaps xmm10, [rsp+0x90]
00007ff1409de176  vmovaps xmm11, [rsp+0xA0]
00007ff1409de17f  vmovaps xmm12, [rsp+0xB0]
00007ff1409de188  vmovaps xmm13, [rsp+0xC0]
00007ff1409de191  vmovaps xmm14, [rsp+0xD0]
00007ff1409de19a  vmovaps xmm15, [rsp+0xE0]
00007ff1409de1a3  add rsp, 0xF0
00007ff1409de1aa  pop r11
00007ff1409de1ac  pop r10
00007ff1409de1ae  pop r9
00007ff1409de1b0  pop r8
00007ff1409de1b2  pop rsi
00007ff1409de1b3  pop rdi
00007ff1409de1b4  pop rdx
00007ff1409de1b5  pop rcx
00007ff1409de1b6  pop rax
00007ff1409de1b7  add rsp, 0x08
00007ff1409de1bb  jmp 0x00007FF1409D977A
00007ff1409de1c0  call 0x00007FF14080C260
00007ff1409de1c5  jmp 0x00007FF1409D9788
00007ff1409de1ca  call 0x00007FF1408DE950
00007ff1409de1cf  jmp 0x00007FF1409D9792
00007ff1409de1d4  sub rsp, 0x08
00007ff1409de1d8  push rax
00007ff1409de1d9  push rcx
00007ff1409de1da  push rdx
00007ff1409de1db  push rdi
00007ff1409de1dc  push rsi
00007ff1409de1dd  push r8
00007ff1409de1df  push r9
00007ff1409de1e1  push r10
00007ff1409de1e3  push r11
00007ff1409de1e5  sub rsp, 0xF0
00007ff1409de1ec  vmovaps [rsp], xmm0
00007ff1409de1f1  vmovaps [rsp+0x10], xmm1
00007ff1409de1f7  vmovaps [rsp+0x20], xmm2
00007ff1409de1fd  vmovaps [rsp+0x30], xmm3
00007ff1409de203  vmovaps [rsp+0x40], xmm4
00007ff1409de209  vmovaps [rsp+0x50], xmm5
00007ff1409de20f  vmovaps [rsp+0x60], xmm6
00007ff1409de215  vmovaps [rsp+0x70], xmm7
00007ff1409de21b  vmovaps [rsp+0x80], xmm9
00007ff1409de224  vmovaps [rsp+0x90], xmm10
00007ff1409de22d  vmovaps [rsp+0xA0], xmm11
00007ff1409de236  vmovaps [rsp+0xB0], xmm12
00007ff1409de23f  vmovaps [rsp+0xC0], xmm13
00007ff1409de248  vmovaps [rsp+0xD0], xmm14
00007ff1409de251  vmovaps [rsp+0xE0], xmm15
00007ff1409de25a  sub rsp, 0x30
00007ff1409de25e  movaps [rsp], xmm8
00007ff1409de263  movaps [rsp+0x10], xmm15
00007ff1409de269  movaps [rsp+0x20], xmm7
00007ff1409de26e  lea rdi, [rsp]
00007ff1409de272  mov esi, 0x00
00007ff1409de277  mov rax, 0x565C7F10C530
00007ff1409de281  call rax
00007ff1409de283  movaps xmm8, [rsp]
00007ff1409de288  add rsp, 0x30
00007ff1409de28c  vmovaps xmm0, [rsp]
00007ff1409de291  vmovaps xmm1, [rsp+0x10]
00007ff1409de297  vmovaps xmm2, [rsp+0x20]
00007ff1409de29d  vmovaps xmm3, [rsp+0x30]
00007ff1409de2a3  vmovaps xmm4, [rsp+0x40]
00007ff1409de2a9  vmovaps xmm5, [rsp+0x50]
00007ff1409de2af  vmovaps xmm6, [rsp+0x60]
00007ff1409de2b5  vmovaps xmm7, [rsp+0x70]
00007ff1409de2bb  vmovaps xmm9, [rsp+0x80]
00007ff1409de2c4  vmovaps xmm10, [rsp+0x90]
00007ff1409de2cd  vmovaps xmm11, [rsp+0xA0]
00007ff1409de2d6  vmovaps xmm12, [rsp+0xB0]
00007ff1409de2df  vmovaps xmm13, [rsp+0xC0]
00007ff1409de2e8  vmovaps xmm14, [rsp+0xD0]
00007ff1409de2f1  vmovaps xmm15, [rsp+0xE0]
00007ff1409de2fa  add rsp, 0xF0
00007ff1409de301  pop r11
00007ff1409de303  pop r10
00007ff1409de305  pop r9
00007ff1409de307  pop r8
00007ff1409de309  pop rsi
00007ff1409de30a  pop rdi
00007ff1409de30b  pop rdx
00007ff1409de30c  pop rcx
00007ff1409de30d  pop rax
00007ff1409de30e  add rsp, 0x08
00007ff1409de312  jmp 0x00007FF1409D97B4
00007ff1409de317  sub rsp, 0x08
00007ff1409de31b  push rax
00007ff1409de31c  push rcx
00007ff1409de31d  push rdx
00007ff1409de31e  push rdi
00007ff1409de31f  push rsi
00007ff1409de320  push r8
00007ff1409de322  push r9
00007ff1409de324  push r10
00007ff1409de326  push r11
00007ff1409de328  sub rsp, 0xF0
00007ff1409de32f  vmovaps [rsp], xmm0
00007ff1409de334  vmovaps [rsp+0x10], xmm1
00007ff1409de33a  vmovaps [rsp+0x20], xmm2
00007ff1409de340  vmovaps [rsp+0x30], xmm3
00007ff1409de346  vmovaps [rsp+0x40], xmm4
00007ff1409de34c  vmovaps [rsp+0x50], xmm5
00007ff1409de352  vmovaps [rsp+0x60], xmm6
00007ff1409de358  vmovaps [rsp+0x70], xmm8
00007ff1409de35e  vmovaps [rsp+0x80], xmm9
00007ff1409de367  vmovaps [rsp+0x90], xmm10
00007ff1409de370  vmovaps [rsp+0xA0], xmm11
00007ff1409de379  vmovaps [rsp+0xB0], xmm12
00007ff1409de382  vmovaps [rsp+0xC0], xmm13
00007ff1409de38b  vmovaps [rsp+0xD0], xmm14
00007ff1409de394  vmovaps [rsp+0xE0], xmm15
00007ff1409de39d  sub rsp, 0x30
00007ff1409de3a1  movaps [rsp], xmm7
00007ff1409de3a5  movaps [rsp+0x10], xmm9
00007ff1409de3ab  movaps [rsp+0x20], xmm15
00007ff1409de3b1  lea rdi, [rsp]
00007ff1409de3b5  mov esi, 0x00
00007ff1409de3ba  mov rax, 0x565C7F10C530
00007ff1409de3c4  call rax
00007ff1409de3c6  movaps xmm7, [rsp]
00007ff1409de3ca  add rsp, 0x30
00007ff1409de3ce  vmovaps xmm0, [rsp]
00007ff1409de3d3  vmovaps xmm1, [rsp+0x10]
00007ff1409de3d9  vmovaps xmm2, [rsp+0x20]
00007ff1409de3df  vmovaps xmm3, [rsp+0x30]
00007ff1409de3e5  vmovaps xmm4, [rsp+0x40]
00007ff1409de3eb  vmovaps xmm5, [rsp+0x50]
00007ff1409de3f1  vmovaps xmm6, [rsp+0x60]
00007ff1409de3f7  vmovaps xmm8, [rsp+0x70]
00007ff1409de3fd  vmovaps xmm9, [rsp+0x80]
00007ff1409de406  vmovaps xmm10, [rsp+0x90]
00007ff1409de40f  vmovaps xmm11, [rsp+0xA0]
00007ff1409de418  vmovaps xmm12, [rsp+0xB0]
00007ff1409de421  vmovaps xmm13, [rsp+0xC0]
00007ff1409de42a  vmovaps xmm14, [rsp+0xD0]
00007ff1409de433  vmovaps xmm15, [rsp+0xE0]
00007ff1409de43c  add rsp, 0xF0
00007ff1409de443  pop r11
00007ff1409de445  pop r10
00007ff1409de447  pop r9
00007ff1409de449  pop r8
00007ff1409de44b  pop rsi
00007ff1409de44c  pop rdi
00007ff1409de44d  pop rdx
00007ff1409de44e  pop rcx
00007ff1409de44f  pop rax
00007ff1409de450  add rsp, 0x08
00007ff1409de454  jmp 0x00007FF1409D97E1
00007ff1409de459  sub rsp, 0x08
00007ff1409de45d  push rax
00007ff1409de45e  push rcx
00007ff1409de45f  push rdx
00007ff1409de460  push rdi
00007ff1409de461  push rsi
00007ff1409de462  push r8
00007ff1409de464  push r9
00007ff1409de466  push r10
00007ff1409de468  push r11
00007ff1409de46a  sub rsp, 0xF0
00007ff1409de471  vmovaps [rsp], xmm0
00007ff1409de476  vmovaps [rsp+0x10], xmm1
00007ff1409de47c  vmovaps [rsp+0x20], xmm2
00007ff1409de482  vmovaps [rsp+0x30], xmm3
00007ff1409de488  vmovaps [rsp+0x40], xmm4
00007ff1409de48e  vmovaps [rsp+0x50], xmm5
00007ff1409de494  vmovaps [rsp+0x60], xmm6
00007ff1409de49a  vmovaps [rsp+0x70], xmm7
00007ff1409de4a0  vmovaps [rsp+0x80], xmm8
00007ff1409de4a9  vmovaps [rsp+0x90], xmm10
00007ff1409de4b2  vmovaps [rsp+0xA0], xmm11
00007ff1409de4bb  vmovaps [rsp+0xB0], xmm12
00007ff1409de4c4  vmovaps [rsp+0xC0], xmm13
00007ff1409de4cd  vmovaps [rsp+0xD0], xmm14
00007ff1409de4d6  vmovaps [rsp+0xE0], xmm15
00007ff1409de4df  sub rsp, 0x30
00007ff1409de4e3  movaps [rsp], xmm9
00007ff1409de4e8  movaps [rsp+0x10], xmm13
00007ff1409de4ee  movaps [rsp+0x20], xmm15
00007ff1409de4f4  lea rdi, [rsp]
00007ff1409de4f8  mov esi, 0x00
00007ff1409de4fd  mov rax, 0x565C7F10C530
00007ff1409de507  call rax
00007ff1409de509  movaps xmm9, [rsp]
00007ff1409de50e  add rsp, 0x30
00007ff1409de512  vmovaps xmm0, [rsp]
00007ff1409de517  vmovaps xmm1, [rsp+0x10]
00007ff1409de51d  vmovaps xmm2, [rsp+0x20]
00007ff1409de523  vmovaps xmm3, [rsp+0x30]
00007ff1409de529  vmovaps xmm4, [rsp+0x40]
00007ff1409de52f  vmovaps xmm5, [rsp+0x50]
00007ff1409de535  vmovaps xmm6, [rsp+0x60]
00007ff1409de53b  vmovaps xmm7, [rsp+0x70]
00007ff1409de541  vmovaps xmm8, [rsp+0x80]
00007ff1409de54a  vmovaps xmm10, [rsp+0x90]
00007ff1409de553  vmovaps xmm11, [rsp+0xA0]
00007ff1409de55c  vmovaps xmm12, [rsp+0xB0]
00007ff1409de565  vmovaps xmm13, [rsp+0xC0]
00007ff1409de56e  vmovaps xmm14, [rsp+0xD0]
00007ff1409de577  vmovaps xmm15, [rsp+0xE0]
00007ff1409de580  add rsp, 0xF0
00007ff1409de587  pop r11
00007ff1409de589  pop r10
00007ff1409de58b  pop r9
00007ff1409de58d  pop r8
00007ff1409de58f  pop rsi
00007ff1409de590  pop rdi
00007ff1409de591  pop rdx
00007ff1409de592  pop rcx
00007ff1409de593  pop rax
00007ff1409de594  add rsp, 0x08
00007ff1409de598  jmp 0x00007FF1409D980F
00007ff1409de59d  sub rsp, 0x08
00007ff1409de5a1  push rax
00007ff1409de5a2  push rcx
00007ff1409de5a3  push rdx
00007ff1409de5a4  push rdi
00007ff1409de5a5  push rsi
00007ff1409de5a6  push r8
00007ff1409de5a8  push r9
00007ff1409de5aa  push r10
00007ff1409de5ac  push r11
00007ff1409de5ae  sub rsp, 0xF0
00007ff1409de5b5  vmovaps [rsp], xmm0
00007ff1409de5ba  vmovaps [rsp+0x10], xmm1
00007ff1409de5c0  vmovaps [rsp+0x20], xmm2
00007ff1409de5c6  vmovaps [rsp+0x30], xmm3
00007ff1409de5cc  vmovaps [rsp+0x40], xmm4
00007ff1409de5d2  vmovaps [rsp+0x50], xmm5
00007ff1409de5d8  vmovaps [rsp+0x60], xmm6
00007ff1409de5de  vmovaps [rsp+0x70], xmm7
00007ff1409de5e4  vmovaps [rsp+0x80], xmm8
00007ff1409de5ed  vmovaps [rsp+0x90], xmm9
00007ff1409de5f6  vmovaps [rsp+0xA0], xmm10
00007ff1409de5ff  vmovaps [rsp+0xB0], xmm11
00007ff1409de608  vmovaps [rsp+0xC0], xmm12
00007ff1409de611  vmovaps [rsp+0xD0], xmm13
00007ff1409de61a  vmovaps [rsp+0xE0], xmm14
00007ff1409de623  sub rsp, 0x30
00007ff1409de627  movaps [rsp], xmm15
00007ff1409de62c  movaps [rsp+0x10], xmm11
00007ff1409de632  movaps [rsp+0x20], xmm12
00007ff1409de638  lea rdi, [rsp]
00007ff1409de63c  mov esi, 0x00
00007ff1409de641  mov rax, 0x565C7F10C530
00007ff1409de64b  call rax
00007ff1409de64d  movaps xmm15, [rsp]
00007ff1409de652  add rsp, 0x30
00007ff1409de656  vmovaps xmm0, [rsp]
00007ff1409de65b  vmovaps xmm1, [rsp+0x10]
00007ff1409de661  vmovaps xmm2, [rsp+0x20]
00007ff1409de667  vmovaps xmm3, [rsp+0x30]
00007ff1409de66d  vmovaps xmm4, [rsp+0x40]
00007ff1409de673  vmovaps xmm5, [rsp+0x50]
00007ff1409de679  vmovaps xmm6, [rsp+0x60]
00007ff1409de67f  vmovaps xmm7, [rsp+0x70]
00007ff1409de685  vmovaps xmm8, [rsp+0x80]
00007ff1409de68e  vmovaps xmm9, [rsp+0x90]
00007ff1409de697  vmovaps xmm10, [rsp+0xA0]
00007ff1409de6a0  vmovaps xmm11, [rsp+0xB0]
00007ff1409de6a9  vmovaps xmm12, [rsp+0xC0]
00007ff1409de6b2  vmovaps xmm13, [rsp+0xD0]
00007ff1409de6bb  vmovaps xmm14, [rsp+0xE0]
00007ff1409de6c4  add rsp, 0xF0
00007ff1409de6cb  pop r11
00007ff1409de6cd  pop r10
00007ff1409de6cf  pop r9
00007ff1409de6d1  pop r8
00007ff1409de6d3  pop rsi
00007ff1409de6d4  pop rdi
00007ff1409de6d5  pop rdx
00007ff1409de6d6  pop rcx
00007ff1409de6d7  pop rax
00007ff1409de6d8  add rsp, 0x08
00007ff1409de6dc  jmp 0x00007FF1409D982A
00007ff1409de6e1  sub rsp, 0x08
00007ff1409de6e5  push rax
00007ff1409de6e6  push rcx
00007ff1409de6e7  push rdx
00007ff1409de6e8  push rdi
00007ff1409de6e9  push rsi
00007ff1409de6ea  push r8
00007ff1409de6ec  push r9
00007ff1409de6ee  push r10
00007ff1409de6f0  push r11
00007ff1409de6f2  sub rsp, 0xF0
00007ff1409de6f9  vmovaps [rsp], xmm0
00007ff1409de6fe  vmovaps [rsp+0x10], xmm1
00007ff1409de704  vmovaps [rsp+0x20], xmm2
00007ff1409de70a  vmovaps [rsp+0x30], xmm3
00007ff1409de710  vmovaps [rsp+0x40], xmm4
00007ff1409de716  vmovaps [rsp+0x50], xmm5
00007ff1409de71c  vmovaps [rsp+0x60], xmm6
00007ff1409de722  vmovaps [rsp+0x70], xmm7
00007ff1409de728  vmovaps [rsp+0x80], xmm8
00007ff1409de731  vmovaps [rsp+0x90], xmm9
00007ff1409de73a  vmovaps [rsp+0xA0], xmm10
00007ff1409de743  vmovaps [rsp+0xB0], xmm11
00007ff1409de74c  vmovaps [rsp+0xC0], xmm12
00007ff1409de755  vmovaps [rsp+0xD0], xmm14
00007ff1409de75e  vmovaps [rsp+0xE0], xmm15
00007ff1409de767  sub rsp, 0x30
00007ff1409de76b  movaps [rsp], xmm13
00007ff1409de770  movaps [rsp+0x10], xmm10
00007ff1409de776  movaps [rsp+0x20], xmm14
00007ff1409de77c  lea rdi, [rsp]
00007ff1409de780  mov esi, 0x00
00007ff1409de785  mov rax, 0x565C7F10C530
00007ff1409de78f  call rax
00007ff1409de791  movaps xmm13, [rsp]
00007ff1409de796  add rsp, 0x30
00007ff1409de79a  vmovaps xmm0, [rsp]
00007ff1409de79f  vmovaps xmm1, [rsp+0x10]
00007ff1409de7a5  vmovaps xmm2, [rsp+0x20]
00007ff1409de7ab  vmovaps xmm3, [rsp+0x30]
00007ff1409de7b1  vmovaps xmm4, [rsp+0x40]
00007ff1409de7b7  vmovaps xmm5, [rsp+0x50]
00007ff1409de7bd  vmovaps xmm6, [rsp+0x60]
00007ff1409de7c3  vmovaps xmm7, [rsp+0x70]
00007ff1409de7c9  vmovaps xmm8, [rsp+0x80]
00007ff1409de7d2  vmovaps xmm9, [rsp+0x90]
00007ff1409de7db  vmovaps xmm10, [rsp+0xA0]
00007ff1409de7e4  vmovaps xmm11, [rsp+0xB0]
00007ff1409de7ed  vmovaps xmm12, [rsp+0xC0]
00007ff1409de7f6  vmovaps xmm14, [rsp+0xD0]
00007ff1409de7ff  vmovaps xmm15, [rsp+0xE0]
00007ff1409de808  add rsp, 0xF0
00007ff1409de80f  pop r11
00007ff1409de811  pop r10
00007ff1409de813  pop r9
00007ff1409de815  pop r8
00007ff1409de817  pop rsi
00007ff1409de818  pop rdi
00007ff1409de819  pop rdx
00007ff1409de81a  pop rcx
00007ff1409de81b  pop rax
00007ff1409de81c  add rsp, 0x08
00007ff1409de820  jmp 0x00007FF1409D984D
00007ff1409de825  sub rsp, 0x08
00007ff1409de829  push rax
00007ff1409de82a  push rcx
00007ff1409de82b  push rdx
00007ff1409de82c  push rdi
00007ff1409de82d  push rsi
00007ff1409de82e  push r8
00007ff1409de830  push r9
00007ff1409de832  push r10
00007ff1409de834  push r11
00007ff1409de836  sub rsp, 0xF0
00007ff1409de83d  vmovaps [rsp], xmm0
00007ff1409de842  vmovaps [rsp+0x10], xmm1
00007ff1409de848  vmovaps [rsp+0x20], xmm2
00007ff1409de84e  vmovaps [rsp+0x30], xmm3
00007ff1409de854  vmovaps [rsp+0x40], xmm4
00007ff1409de85a  vmovaps [rsp+0x50], xmm5
00007ff1409de860  vmovaps [rsp+0x60], xmm6
00007ff1409de866  vmovaps [rsp+0x70], xmm7
00007ff1409de86c  vmovaps [rsp+0x80], xmm8
00007ff1409de875  vmovaps [rsp+0x90], xmm9
00007ff1409de87e  vmovaps [rsp+0xA0], xmm10
00007ff1409de887  vmovaps [rsp+0xB0], xmm11
00007ff1409de890  vmovaps [rsp+0xC0], xmm12
00007ff1409de899  vmovaps [rsp+0xD0], xmm13
00007ff1409de8a2  vmovaps [rsp+0xE0], xmm15
00007ff1409de8ab  sub rsp, 0x30
00007ff1409de8af  movaps [rsp], xmm14
00007ff1409de8b4  movaps [rsp+0x10], xmm1
00007ff1409de8b9  movaps [rsp+0x20], xmm7
00007ff1409de8be  lea rdi, [rsp]
00007ff1409de8c2  mov esi, 0x00
00007ff1409de8c7  mov rax, 0x565C7F10C530
00007ff1409de8d1  call rax
00007ff1409de8d3  movaps xmm14, [rsp]
00007ff1409de8d8  add rsp, 0x30
00007ff1409de8dc  vmovaps xmm0, [rsp]
00007ff1409de8e1  vmovaps xmm1, [rsp+0x10]
00007ff1409de8e7  vmovaps xmm2, [rsp+0x20]
00007ff1409de8ed  vmovaps xmm3, [rsp+0x30]
00007ff1409de8f3  vmovaps xmm4, [rsp+0x40]
00007ff1409de8f9  vmovaps xmm5, [rsp+0x50]
00007ff1409de8ff  vmovaps xmm6, [rsp+0x60]
00007ff1409de905  vmovaps xmm7, [rsp+0x70]
00007ff1409de90b  vmovaps xmm8, [rsp+0x80]
00007ff1409de914  vmovaps xmm9, [rsp+0x90]
00007ff1409de91d  vmovaps xmm10, [rsp+0xA0]
00007ff1409de926  vmovaps xmm11, [rsp+0xB0]
00007ff1409de92f  vmovaps xmm12, [rsp+0xC0]
00007ff1409de938  vmovaps xmm13, [rsp+0xD0]
00007ff1409de941  vmovaps xmm15, [rsp+0xE0]
00007ff1409de94a  add rsp, 0xF0
00007ff1409de951  pop r11
00007ff1409de953  pop r10
00007ff1409de955  pop r9
00007ff1409de957  pop r8
00007ff1409de959  pop rsi
00007ff1409de95a  pop rdi
00007ff1409de95b  pop rdx
00007ff1409de95c  pop rcx
00007ff1409de95d  pop rax
00007ff1409de95e  add rsp, 0x08
00007ff1409de962  jmp 0x00007FF1409D9870
00007ff1409de967  sub rsp, 0x08
00007ff1409de96b  push rax
00007ff1409de96c  push rcx
00007ff1409de96d  push rdx
00007ff1409de96e  push rdi
00007ff1409de96f  push rsi
00007ff1409de970  push r8
00007ff1409de972  push r9
00007ff1409de974  push r10
00007ff1409de976  push r11
00007ff1409de978  sub rsp, 0xF0
00007ff1409de97f  vmovaps [rsp], xmm0
00007ff1409de984  vmovaps [rsp+0x10], xmm2
00007ff1409de98a  vmovaps [rsp+0x20], xmm3
00007ff1409de990  vmovaps [rsp+0x30], xmm4
00007ff1409de996  vmovaps [rsp+0x40], xmm5
00007ff1409de99c  vmovaps [rsp+0x50], xmm6
00007ff1409de9a2  vmovaps [rsp+0x60], xmm7
00007ff1409de9a8  vmovaps [rsp+0x70], xmm8
00007ff1409de9ae  vmovaps [rsp+0x80], xmm9
00007ff1409de9b7  vmovaps [rsp+0x90], xmm10
00007ff1409de9c0  vmovaps [rsp+0xA0], xmm11
00007ff1409de9c9  vmovaps [rsp+0xB0], xmm12
00007ff1409de9d2  vmovaps [rsp+0xC0], xmm13
00007ff1409de9db  vmovaps [rsp+0xD0], xmm14
00007ff1409de9e4  vmovaps [rsp+0xE0], xmm15
00007ff1409de9ed  sub rsp, 0x30
00007ff1409de9f1  movaps [rsp], xmm1
00007ff1409de9f5  movaps [rsp+0x10], xmm8
00007ff1409de9fb  movaps [rsp+0x20], xmm9
00007ff1409dea01  lea rdi, [rsp]
00007ff1409dea05  mov esi, 0x00
00007ff1409dea0a  mov rax, 0x565C7F10C530
00007ff1409dea14  call rax
00007ff1409dea16  movaps xmm1, [rsp]
00007ff1409dea1a  add rsp, 0x30
00007ff1409dea1e  vmovaps xmm0, [rsp]
00007ff1409dea23  vmovaps xmm2, [rsp+0x10]
00007ff1409dea29  vmovaps xmm3, [rsp+0x20]
00007ff1409dea2f  vmovaps xmm4, [rsp+0x30]
00007ff1409dea35  vmovaps xmm5, [rsp+0x40]
00007ff1409dea3b  vmovaps xmm6, [rsp+0x50]
00007ff1409dea41  vmovaps xmm7, [rsp+0x60]
00007ff1409dea47  vmovaps xmm8, [rsp+0x70]
00007ff1409dea4d  vmovaps xmm9, [rsp+0x80]
00007ff1409dea56  vmovaps xmm10, [rsp+0x90]
00007ff1409dea5f  vmovaps xmm11, [rsp+0xA0]
00007ff1409dea68  vmovaps xmm12, [rsp+0xB0]
00007ff1409dea71  vmovaps xmm13, [rsp+0xC0]
00007ff1409dea7a  vmovaps xmm14, [rsp+0xD0]
00007ff1409dea83  vmovaps xmm15, [rsp+0xE0]
00007ff1409dea8c  add rsp, 0xF0
00007ff1409dea93  pop r11
00007ff1409dea95  pop r10
00007ff1409dea97  pop r9
00007ff1409dea99  pop r8
00007ff1409dea9b  pop rsi
00007ff1409dea9c  pop rdi
00007ff1409dea9d  pop rdx
00007ff1409dea9e  pop rcx
00007ff1409dea9f  pop rax
00007ff1409deaa0  add rsp, 0x08
00007ff1409deaa4  jmp 0x00007FF1409D9892
00007ff1409deaa9  call 0x00007FF1408B3E40
00007ff1409deaae  jmp 0x00007FF1409D98A0
00007ff1409deab3  call 0x00007FF14080C380
00007ff1409deab8  jmp 0x00007FF1409D98AA
00007ff1409deabd  call 0x00007FF14080D600
00007ff1409deac2  jmp 0x00007FF1409D98B4
00007ff1409deac7  call 0x00007FF1407FF540
00007ff1409deacc  jmp 0x00007FF1409D98BE
00007ff1409dead1  int3
00007ff1409dead2  nop [rax+rax*1], ax
00007ff1409deadb  nop [rax+rax*1], eax
00007ff1409deae0  mov eax, [r15+0x48]
00007ff1409deae4  lea r14d, [eax+0x01]
00007ff1409deae9  mov [rsp+0x10], r14d
00007ff1409deaee  mov r14d, r14d
00007ff1409deaf1  mov [r15+0x48], r14
00007ff1409deaf5  xor eax, eax
00007ff1409deaf7  mov r14d, [rsp+0x10]
00007ff1409deafc  cmp r14d, 0x1F4
00007ff1409deb03  cmc
00007ff1409deb04  lahf
00007ff1409deb05  seto al
00007ff1409deb08  mov [r15+0x108], eax
00007ff1409deb0f  mov eax, [r15+0x108]
00007ff1409deb16  sahf
00007ff1409deb17  jnz 0x00007FF1409DEB49
00007ff1409deb19  cmp dword ptr [r15+0x318], 0x00
00007ff1409deb21  jz 0x00007FF1409E4C90
00007ff1409deb27  nop [rax+rax*1], ax
00007ff1409deb30  nop [rax+rax*1], eax
00007ff1409deb38  mov eax, 0x4106DC
00007ff1409deb3d  mov [r15+0x100], rax
00007ff1409deb44  jmp 0x00007FF1407FE110
00007ff1409deb49  cmp dword ptr [r15+0x318], 0x00
00007ff1409deb51  jz 0x00007FF1409DEB80
00007ff1409deb57  nop [rax+rax*1], ax
00007ff1409deb60  nop [rax+rax*1], eax
00007ff1409deb68  mov eax, 0x410500
00007ff1409deb6d  mov [r15+0x100], rax
00007ff1409deb74  jmp 0x00007FF1407FE110
00007ff1409deb79  int3
00007ff1409deb7a  int3
00007ff1409deb7b  nop [rax+rax*1], eax
00007ff1409deb80  mov rax, [r15+0x40]
00007ff1409deb84  movaps xmm1, [r15+0x1D0]
00007ff1409deb8c  vmovaps [rsp+0x10], xmm1
00007ff1409deb92  vmovaps xmm15, [rsp+0x10]
00007ff1409deb98  por xmm1, xmm15
00007ff1409deb9d  movaps xmm14, [r15+0x1A0]
00007ff1409deba5  vmovaps [rsp+0x10], xmm14
00007ff1409debab  vmovaps xmm13, [rsp+0x10]
00007ff1409debb1  por xmm14, xmm13
00007ff1409debb6  lea r14, [rax+0x30]
00007ff1409debba  mov r12, [r13+r14*1]
00007ff1409debbf  lea r14, [rax+0x38]
00007ff1409debc3  mov r11, [r13+r14*1]
00007ff1409debc8  movq xmm13, r12
00007ff1409debcd  movq xmm12, r11
00007ff1409debd2  movq xmm13, xmm13
00007ff1409debd7  vmovaps [rsp+0x10], xmm13
00007ff1409debdd  movq xmm13, xmm13
00007ff1409debe2  movaps [r15+0x130], xmm13
00007ff1409debea  movq xmm12, xmm12
00007ff1409debef  vmovaps [rsp+0x20], xmm12
00007ff1409debf5  movq xmm12, xmm12
00007ff1409debfa  movaps [r15+0x280], xmm12
00007ff1409dec02  movaps xmm13, [r15+0x270]
00007ff1409dec0a  vmovaps [rsp+0x30], xmm13
00007ff1409dec10  vmovaps xmm12, [rsp+0x30]
00007ff1409dec16  por xmm13, xmm12
00007ff1409dec1b  lea r14, [rax+0x20]
00007ff1409dec1f  mov r12, [r13+r14*1]
00007ff1409dec24  lea r14, [rax+0x28]
00007ff1409dec28  mov r11, [r13+r14*1]
00007ff1409dec2d  movq xmm12, r12
00007ff1409dec32  movq xmm11, r11
00007ff1409dec37  movq xmm12, xmm12
00007ff1409dec3c  vmovaps [rsp+0x30], xmm12
00007ff1409dec42  movq xmm12, xmm12
00007ff1409dec47  movaps [r15+0x150], xmm12
00007ff1409dec4f  movq xmm11, xmm11
00007ff1409dec54  vmovaps [rsp+0x40], xmm11
00007ff1409dec5a  movq xmm11, xmm11
00007ff1409dec5f  movaps [r15+0x140], xmm11
00007ff1409dec67  lea r14, [rax+0x10]
00007ff1409dec6b  mov r12, [r13+r14*1]
00007ff1409dec70  lea r14, [rax+0x18]
00007ff1409dec74  mov r11, [r13+r14*1]
00007ff1409dec79  movq xmm12, r12
00007ff1409dec7e  movq xmm11, r11
00007ff1409dec83  movq xmm12, xmm12
00007ff1409dec88  vmovaps [rsp+0x50], xmm12
00007ff1409dec8e  movq xmm12, xmm12
00007ff1409dec93  movaps [r15+0x170], xmm12
00007ff1409dec9b  movq xmm11, xmm11
00007ff1409deca0  vmovaps [rsp+0x60], xmm11
00007ff1409deca6  movq xmm11, xmm11
00007ff1409decab  movaps [r15+0x160], xmm11
00007ff1409decb3  mov r14, [r13+rax*1]
00007ff1409decb8  vmovq xmm12, r14
00007ff1409decbd  vpbroadcastq xmm12, xmm12
00007ff1409decc2  lea r14, [rax+0x08]
00007ff1409decc6  mov rax, [r13+r14*1]
00007ff1409deccb  movq xmm11, rax
00007ff1409decd0  movaps [r15+0x230], xmm11
00007ff1409decd8  mov rax, [r15+0xF8]
00007ff1409decdf  lea r14, [rax+0x50]
00007ff1409dece3  movups xmm11, [r13+r14*1]
00007ff1409dece9  lea r14, [rax+0x60]
00007ff1409deced  movups xmm10, [r13+r14*1]
00007ff1409decf3  lea r14, [rax+0x30]
00007ff1409decf7  movups xmm9, [r13+r14*1]
00007ff1409decfd  mov r14, [r15+0x50]
00007ff1409ded01  mov [r15+0x60], r14
00007ff1409ded05  mov qword ptr [r15+0x58], 0x40
00007ff1409ded0d  movaps xmm8, xmm12
00007ff1409ded11  mulpd xmm8, xmm15
00007ff1409ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007ff1409ded1c  ptest xmm7, xmm7
00007ff1409ded21  jnz 0x00007FF1409DFB4A
00007ff1409ded27  movq xmm15, qword ptr [r15+0x230]
00007ff1409ded30  vmovaps [rsp+0x70], xmm15
00007ff1409ded36  vpermilpd xmm15, xmm15, 0x00
00007ff1409ded3c  movaps xmm7, xmm9
00007ff1409ded40  mulpd xmm7, xmm15
00007ff1409ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007ff1409ded4a  ptest xmm6, xmm6
00007ff1409ded4f  jnz 0x00007FF1409DFC8E
00007ff1409ded55  vxorps xmm15, xmm15, xmm15
00007ff1409ded5a  vpbroadcastq xmm15, xmm15
00007ff1409ded5f  movaps xmm9, xmm12
00007ff1409ded63  mulpd xmm9, xmm10
00007ff1409ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007ff1409ded6e  ptest xmm6, xmm6
00007ff1409ded73  jnz 0x00007FF1409DFDD0
00007ff1409ded79  movaps xmm10, xmm12
00007ff1409ded7d  mulpd xmm10, xmm11
00007ff1409ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007ff1409ded88  ptest xmm6, xmm6
00007ff1409ded8d  jnz 0x00007FF1409DFF14
00007ff1409ded93  movaps xmm11, [r15+0x1F0]
00007ff1409ded9b  movaps xmm6, xmm12
00007ff1409ded9f  mulpd xmm6, xmm11
00007ff1409deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007ff1409deda9  ptest xmm5, xmm5
00007ff1409dedae  jnz 0x00007FF1409E0058
00007ff1409dedb4  movaps xmm12, [r15+0x2A0]
00007ff1409dedbc  vmovaps [rsp+0x80], xmm12
00007ff1409dedc5  vmovaps xmm11, [rsp+0x80]
00007ff1409dedce  por xmm12, xmm11
00007ff1409dedd3  movaps xmm11, [r15+0x250]
00007ff1409deddb  vmovaps [rsp+0x80], xmm11
00007ff1409dede4  vmovaps xmm5, [rsp+0x80]
00007ff1409deded  por xmm11, xmm5
00007ff1409dedf2  vmovaps xmm4, [rsp+0x70]
00007ff1409dedf8  vpermilpd xmm4, xmm4, 0x00
00007ff1409dedfe  movaps xmm3, xmm5
00007ff1409dee01  mulpd xmm3, xmm4
00007ff1409dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007ff1409dee0a  ptest xmm2, xmm2
00007ff1409dee0f  jnz 0x00007FF1409E019A
00007ff1409dee15  mov [rsp+0x80], rax
00007ff1409dee1d  xor eax, eax
00007ff1409dee1f  mov r12d, 0x40
00007ff1409dee25  mov r11d, 0x200
00007ff1409dee2b  cmp r12, r11
00007ff1409dee2e  cmc
00007ff1409dee2f  lahf
00007ff1409dee30  seto al
00007ff1409dee33  mov [r15+0x108], eax
00007ff1409dee3a  movaps xmm5, xmm8
00007ff1409dee3e  addpd xmm5, xmm15
00007ff1409dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007ff1409dee48  ptest xmm4, xmm4
00007ff1409dee4d  jnz 0x00007FF1409E02DA
00007ff1409dee53  movaps xmm8, [r15+0x1B0]
00007ff1409dee5b  movaps xmm4, xmm9
00007ff1409dee5f  addpd xmm4, xmm8
00007ff1409dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007ff1409dee69  ptest xmm2, xmm2
00007ff1409dee6e  jnz 0x00007FF1409E041C
00007ff1409dee74  movaps xmm9, xmm10
00007ff1409dee78  addpd xmm9, xmm8
00007ff1409dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007ff1409dee83  ptest xmm2, xmm2
00007ff1409dee88  jnz 0x00007FF1409E055E
00007ff1409dee8e  movaps xmm10, [r15+0x2F0]
00007ff1409dee96  vmovaps [rsp+0x90], xmm10
00007ff1409dee9f  vmovaps xmm8, [rsp+0x90]
00007ff1409deea8  por xmm10, xmm8
00007ff1409deead  movaps xmm8, [r15+0x2E0]
00007ff1409deeb5  vmovaps [rsp+0x90], xmm8
00007ff1409deebe  vmovaps xmm2, [rsp+0x90]
00007ff1409deec7  por xmm8, xmm2
00007ff1409deecc  movaps xmm2, [r15+0x2D0]
00007ff1409deed4  vmovaps [rsp+0x90], xmm2
00007ff1409deedd  vmovaps [rsp+0xA0], xmm1
00007ff1409deee6  vmovaps xmm1, [rsp+0x90]
00007ff1409deeef  por xmm2, xmm1
00007ff1409deef3  movaps xmm1, [r15+0x200]
00007ff1409deefb  vmovaps [rsp+0x90], xmm1
00007ff1409def04  vmovaps [rsp+0xB0], xmm15
00007ff1409def0d  vmovaps xmm15, [rsp+0x90]
00007ff1409def16  por xmm1, xmm15
00007ff1409def1b  movaps xmm15, [r15+0x1C0]
00007ff1409def23  vmovaps [rsp+0x90], xmm15
00007ff1409def2c  vmovaps [rsp+0xC0], xmm1
00007ff1409def35  vmovaps xmm1, [rsp+0x90]
00007ff1409def3e  por xmm15, xmm1
00007ff1409def43  movaps xmm1, [r15+0x190]
00007ff1409def4b  vmovaps [rsp+0x90], xmm1
00007ff1409def54  vmovaps [rsp+0xD0], xmm15
00007ff1409def5d  vmovaps xmm15, [rsp+0x90]
00007ff1409def66  por xmm1, xmm15
00007ff1409def6b  movaps xmm15, [r15+0x300]
00007ff1409def73  vmovaps [rsp+0x90], xmm15
00007ff1409def7c  vmovaps [rsp+0xE0], xmm1
00007ff1409def85  vmovaps xmm1, [rsp+0x90]
00007ff1409def8e  por xmm15, xmm1
00007ff1409def93  mov rax, [rsp+0x80]
00007ff1409def9b  lea r12, [rax+0xA0]
00007ff1409defa2  movups xmm1, [r13+r12*1]
00007ff1409defa8  lea r12, [rax+0xB0]
00007ff1409defaf  vmovaps [rsp+0x80], xmm1
00007ff1409defb8  movups xmm1, [r13+r12*1]
00007ff1409defbe  vmovaps [rsp+0x90], xmm1
00007ff1409defc7  vmovaps [rsp+0xF0], xmm15
00007ff1409defd0  vmovaps xmm15, [rsp+0xB0]
00007ff1409defd9  vmovaps [rsp+0xB0], xmm14
00007ff1409defe2  movaps xmm1, xmm6
00007ff1409defe5  addpd xmm1, xmm15
00007ff1409defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007ff1409defef  ptest xmm14, xmm14
00007ff1409deff5  jnz 0x00007FF1409E06B6
00007ff1409deffb  lea r12, [rax+0xF0]
00007ff1409df002  movups xmm15, [r13+r12*1]
00007ff1409df008  movaps xmm14, xmm4
00007ff1409df00c  addpd xmm14, xmm3
00007ff1409df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007ff1409df017  ptest xmm6, xmm6
00007ff1409df01c  jnz 0x00007FF1409E0801
00007ff1409df022  movaps xmm6, xmm9
00007ff1409df026  addpd xmm6, xmm7
00007ff1409df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007ff1409df02f  ptest xmm4, xmm4
00007ff1409df034  jnz 0x00007FF1409E0943
00007ff1409df03a  vmovaps xmm9, [rsp+0x70]
00007ff1409df040  vpermilpd xmm9, xmm9, 0x00
00007ff1409df046  vmovaps xmm4, [rsp+0x90]
00007ff1409df04f  movaps xmm7, xmm4
00007ff1409df052  mulpd xmm7, xmm9
00007ff1409df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007ff1409df05c  ptest xmm3, xmm3
00007ff1409df061  jnz 0x00007FF1409E0A84
00007ff1409df067  vmovaps xmm9, [rsp+0x50]
00007ff1409df06d  vpermilpd xmm9, xmm9, 0x00
00007ff1409df073  movaps xmm4, xmm15
00007ff1409df077  mulpd xmm4, xmm9
00007ff1409df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007ff1409df081  ptest xmm3, xmm3
00007ff1409df086  jnz 0x00007FF1409E0BC5
00007ff1409df08c  lea r12, [rax+0xE0]
00007ff1409df093  movups xmm15, [r13+r12*1]
00007ff1409df099  vmovaps xmm9, [rsp+0x70]
00007ff1409df09f  vpermilpd xmm9, xmm9, 0x00
00007ff1409df0a5  vmovaps [rsp+0x70], xmm1
00007ff1409df0ab  vmovaps xmm1, [rsp+0x80]
00007ff1409df0b4  vmovaps [rsp+0x80], xmm15
00007ff1409df0bd  movaps xmm3, xmm1
00007ff1409df0c0  mulpd xmm3, xmm9
00007ff1409df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007ff1409df0ca  ptest xmm15, xmm15
00007ff1409df0d0  jnz 0x00007FF1409E0D11
00007ff1409df0d6  vmovaps xmm1, [rsp+0xF0]
00007ff1409df0df  vmovaps xmm15, [rsp+0xF0]
00007ff1409df0e8  por xmm1, xmm15
00007ff1409df0ed  movaps [r15+0x300], xmm1
00007ff1409df0f5  vmovaps xmm15, [rsp+0xE0]
00007ff1409df0fe  vmovaps xmm9, [rsp+0xE0]
00007ff1409df107  por xmm15, xmm9
00007ff1409df10c  movaps [r15+0x190], xmm15
00007ff1409df114  vmovaps xmm9, [rsp+0x50]
00007ff1409df11a  vpermilpd xmm9, xmm9, 0x00
00007ff1409df120  vmovaps [rsp+0x90], xmm1
00007ff1409df129  vmovaps [rsp+0xE0], xmm15
00007ff1409df132  vmovaps xmm15, [rsp+0x80]
00007ff1409df13b  vmovaps [rsp+0x80], xmm14
00007ff1409df144  movaps xmm1, xmm15
00007ff1409df148  mulpd xmm1, xmm9
00007ff1409df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007ff1409df152  ptest xmm14, xmm14
00007ff1409df158  jnz 0x00007FF1409E0E52
00007ff1409df15e  lea r12, [rax+0x90]
00007ff1409df165  movups xmm15, [r13+r12*1]
00007ff1409df16b  vmovaps xmm14, [rsp+0xD0]
00007ff1409df174  vmovaps xmm9, [rsp+0xD0]
00007ff1409df17d  por xmm14, xmm9
00007ff1409df182  movaps [r15+0x1C0], xmm14
00007ff1409df18a  vmovaps xmm9, [rsp+0xC0]
00007ff1409df193  vmovaps [rsp+0xD0], xmm1
00007ff1409df19c  vmovaps xmm1, [rsp+0xC0]
00007ff1409df1a5  por xmm9, xmm1
00007ff1409df1aa  movaps [r15+0x200], xmm9
00007ff1409df1b2  vmovaps [rsp+0xC0], xmm2
00007ff1409df1bb  vmovaps xmm1, [rsp+0xC0]
00007ff1409df1c4  por xmm2, xmm1
00007ff1409df1c8  movaps [r15+0x2D0], xmm2
00007ff1409df1d0  vmovaps [rsp+0xC0], xmm8
00007ff1409df1d9  vmovaps xmm1, [rsp+0xC0]
00007ff1409df1e2  por xmm8, xmm1
00007ff1409df1e7  movaps [r15+0x2E0], xmm8
00007ff1409df1ef  vmovaps [rsp+0xC0], xmm15
00007ff1409df1f8  movaps xmm1, xmm5
00007ff1409df1fb  addpd xmm1, xmm7
00007ff1409df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007ff1409df204  ptest xmm15, xmm15
00007ff1409df20a  jnz 0x00007FF1409E0F9E
00007ff1409df210  vmovaps xmm15, [rsp+0x50]
00007ff1409df216  vpermilpd xmm15, xmm15, 0x00
00007ff1409df21c  vmovaps xmm5, [rsp+0xC0]
00007ff1409df225  vmovaps [rsp+0xC0], xmm1
00007ff1409df22e  movaps xmm7, xmm5
00007ff1409df231  mulpd xmm7, xmm15
00007ff1409df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007ff1409df23b  ptest xmm1, xmm1
00007ff1409df240  jnz 0x00007FF1409E10DE
00007ff1409df246  lea r12, [rax+0x80]
00007ff1409df24d  movups xmm1, [r13+r12*1]
00007ff1409df253  vmovaps xmm5, [rsp+0x70]
00007ff1409df259  vmovaps [rsp+0x70], xmm1
00007ff1409df25f  movaps xmm15, xmm5
00007ff1409df263  addpd xmm15, xmm3
00007ff1409df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007ff1409df26e  ptest xmm1, xmm1
00007ff1409df273  jnz 0x00007FF1409E1229
00007ff1409df279  vmovaps xmm5, [rsp+0x80]
00007ff1409df282  movaps xmm1, xmm5
00007ff1409df285  addpd xmm1, xmm4
00007ff1409df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007ff1409df28e  ptest xmm3, xmm3
00007ff1409df293  jnz 0x00007FF1409E136B
00007ff1409df299  vmovaps [rsp+0x80], xmm10
00007ff1409df2a2  vmovaps xmm5, [rsp+0x80]
00007ff1409df2ab  por xmm10, xmm5
00007ff1409df2b0  movaps [r15+0x2F0], xmm10
00007ff1409df2b8  vmovaps xmm5, [rsp+0x50]
00007ff1409df2be  vpermilpd xmm5, xmm5, 0x00
00007ff1409df2c4  vmovaps xmm3, [rsp+0x70]
00007ff1409df2ca  vmovaps [rsp+0x50], xmm1
00007ff1409df2d0  movaps xmm4, xmm3
00007ff1409df2d3  mulpd xmm4, xmm5
00007ff1409df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007ff1409df2dc  ptest xmm1, xmm1
00007ff1409df2e1  jnz 0x00007FF1409E14AB
00007ff1409df2e7  lea r12, [rax+0xD0]
00007ff1409df2ee  movups xmm1, [r13+r12*1]
00007ff1409df2f4  vmovaps xmm3, [rsp+0xD0]
00007ff1409df2fd  vmovaps [rsp+0x70], xmm1
00007ff1409df303  movaps xmm5, xmm6
00007ff1409df306  addpd xmm5, xmm3
00007ff1409df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007ff1409df30f  ptest xmm1, xmm1
00007ff1409df314  jnz 0x00007FF1409E15F5
00007ff1409df31a  vmovaps xmm1, [rsp+0x60]
00007ff1409df320  vpermilpd xmm1, xmm1, 0x00
00007ff1409df326  movaps xmm6, xmm9
00007ff1409df32a  mulpd xmm6, xmm1
00007ff1409df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007ff1409df333  ptest xmm3, xmm3
00007ff1409df338  jnz 0x00007FF1409E1735
00007ff1409df33e  movaps [r15+0x260], xmm6
00007ff1409df346  vxorps xmm1, xmm1, xmm1
00007ff1409df34a  vpbroadcastq xmm1, xmm1
00007ff1409df34f  movaps [r15+0x1B0], xmm1
00007ff1409df357  vmovaps xmm1, [rsp+0x60]
00007ff1409df35d  vpermilpd xmm1, xmm1, 0x00
00007ff1409df363  vmovaps xmm3, [rsp+0x70]
00007ff1409df369  vmovaps [rsp+0x70], xmm15
00007ff1409df36f  movaps xmm9, xmm3
00007ff1409df373  mulpd xmm9, xmm1
00007ff1409df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007ff1409df37e  ptest xmm15, xmm15
00007ff1409df384  jnz 0x00007FF1409E1876
00007ff1409df38a  lea r12, [rax+0xC0]
00007ff1409df391  movups xmm1, [r13+r12*1]
00007ff1409df397  vmovaps xmm3, [rsp+0xC0]
00007ff1409df3a0  vmovaps [rsp+0x80], xmm1
00007ff1409df3a9  movaps xmm15, xmm3
00007ff1409df3ad  addpd xmm15, xmm7
00007ff1409df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007ff1409df3b8  ptest xmm1, xmm1
00007ff1409df3bd  jnz 0x00007FF1409E19C2
00007ff1409df3c3  vmovaps [rsp+0xC0], xmm13
00007ff1409df3cc  vmovaps xmm1, [rsp+0xC0]
00007ff1409df3d5  por xmm13, xmm1
00007ff1409df3da  movaps [r15+0x270], xmm13
00007ff1409df3e2  vmovaps xmm1, [rsp+0xB0]
00007ff1409df3eb  vmovaps xmm7, [rsp+0xB0]
00007ff1409df3f4  por xmm1, xmm7
00007ff1409df3f8  movaps [r15+0x1A0], xmm1
00007ff1409df400  vmovaps xmm1, [rsp+0x60]
00007ff1409df406  vpermilpd xmm1, xmm1, 0x00
00007ff1409df40c  vmovaps [rsp+0xB0], xmm1
00007ff1409df415  vmovaps xmm1, [rsp+0x80]
00007ff1409df41e  vmovaps [rsp+0x80], xmm15
00007ff1409df427  vmovaps xmm15, [rsp+0xB0]
00007ff1409df430  vmovaps [rsp+0xB0], xmm14
00007ff1409df439  movaps xmm3, xmm1
00007ff1409df43c  mulpd xmm3, xmm15
00007ff1409df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007ff1409df446  ptest xmm14, xmm14
00007ff1409df44c  jnz 0x00007FF1409E1B04
00007ff1409df452  lea r12, [rax+0x20]
00007ff1409df456  movups xmm1, [r13+r12*1]
00007ff1409df45c  movaps [r15+0x110], xmm1
00007ff1409df464  vmovaps xmm14, [rsp+0x70]
00007ff1409df46a  vmovaps [rsp+0x70], xmm1
00007ff1409df470  movaps xmm15, xmm14
00007ff1409df474  addpd xmm15, xmm4
00007ff1409df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007ff1409df47f  ptest xmm1, xmm1
00007ff1409df484  jnz 0x00007FF1409E1C4F
00007ff1409df48a  vmovaps xmm1, [rsp+0x60]
00007ff1409df490  vpermilpd xmm1, xmm1, 0x00
00007ff1409df496  movaps xmm14, xmm2
00007ff1409df49a  mulpd xmm14, xmm1
00007ff1409df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007ff1409df4a5  ptest xmm4, xmm4
00007ff1409df4aa  jnz 0x00007FF1409E1D92
00007ff1409df4b0  vmovaps xmm4, [rsp+0x50]
00007ff1409df4b6  movaps xmm1, xmm4
00007ff1409df4b9  addpd xmm1, xmm9
00007ff1409df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007ff1409df4c3  ptest xmm2, xmm2
00007ff1409df4c8  jnz 0x00007FF1409E1ED4
00007ff1409df4ce  vmovaps xmm9, [rsp+0x30]
00007ff1409df4d4  vpermilpd xmm9, xmm9, 0x00
00007ff1409df4da  vmovaps xmm2, [rsp+0x70]
00007ff1409df4e0  vmovaps [rsp+0x50], xmm1
00007ff1409df4e6  movaps xmm4, xmm2
00007ff1409df4e9  mulpd xmm4, xmm9
00007ff1409df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007ff1409df4f3  ptest xmm1, xmm1
00007ff1409df4f8  jnz 0x00007FF1409E2015
00007ff1409df4fe  vmovaps xmm1, [rsp+0x30]
00007ff1409df504  vpermilpd xmm1, xmm1, 0x00
00007ff1409df50a  vmovaps xmm2, [rsp+0x90]
00007ff1409df513  vmovaps [rsp+0x60], xmm15
00007ff1409df519  movaps xmm9, xmm2
00007ff1409df51d  mulpd xmm9, xmm1
00007ff1409df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007ff1409df528  ptest xmm15, xmm15
00007ff1409df52e  jnz 0x00007FF1409E2156
00007ff1409df534  vmovaps xmm15, [rsp+0x80]
00007ff1409df53d  movaps xmm1, xmm15
00007ff1409df541  addpd xmm1, xmm6
00007ff1409df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007ff1409df54a  ptest xmm2, xmm2
00007ff1409df54f  jnz 0x00007FF1409E2298
00007ff1409df555  movaps xmm15, xmm5
00007ff1409df559  addpd xmm15, xmm3
00007ff1409df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007ff1409df564  ptest xmm6, xmm6
00007ff1409df569  jnz 0x00007FF1409E23D9
00007ff1409df56f  vmovaps xmm6, [rsp+0x30]
00007ff1409df575  vpermilpd xmm6, xmm6, 0x00
00007ff1409df57b  movaps xmm5, xmm8
00007ff1409df57f  mulpd xmm5, xmm6
00007ff1409df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007ff1409df588  ptest xmm3, xmm3
00007ff1409df58d  jnz 0x00007FF1409E251B
00007ff1409df593  vmovaps xmm8, [rsp+0x30]
00007ff1409df599  vpermilpd xmm8, xmm8, 0x00
00007ff1409df59f  movaps xmm6, xmm10
00007ff1409df5a3  mulpd xmm6, xmm8
00007ff1409df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007ff1409df5ad  ptest xmm3, xmm3
00007ff1409df5b2  jnz 0x00007FF1409E265C
00007ff1409df5b8  vmovaps xmm8, [rsp+0x60]
00007ff1409df5be  movaps xmm10, xmm8
00007ff1409df5c2  addpd xmm10, xmm14
00007ff1409df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007ff1409df5cd  ptest xmm3, xmm3
00007ff1409df5d2  jnz 0x00007FF1409E279E
00007ff1409df5d8  vmovaps xmm8, [rsp+0x50]
00007ff1409df5de  movaps xmm14, xmm8
00007ff1409df5e2  addpd xmm14, xmm4
00007ff1409df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007ff1409df5ed  ptest xmm3, xmm3
00007ff1409df5f2  jnz 0x00007FF1409E28E2
00007ff1409df5f8  vmovaps xmm8, [rsp+0x40]
00007ff1409df5fe  vpermilpd xmm8, xmm8, 0x00
00007ff1409df604  movaps xmm4, xmm13
00007ff1409df608  mulpd xmm4, xmm8
00007ff1409df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007ff1409df612  ptest xmm3, xmm3
00007ff1409df617  jnz 0x00007FF1409E2A25
00007ff1409df61d  movaps xmm13, xmm15
00007ff1409df621  addpd xmm13, xmm9
00007ff1409df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007ff1409df62c  ptest xmm8, xmm8
00007ff1409df632  jnz 0x00007FF1409E2B67
00007ff1409df638  movaps xmm15, xmm1
00007ff1409df63c  addpd xmm15, xmm5
00007ff1409df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007ff1409df647  ptest xmm9, xmm9
00007ff1409df64d  jnz 0x00007FF1409E2CAB
00007ff1409df653  vmovaps [rsp+0x30], xmm11
00007ff1409df659  vmovaps xmm1, [rsp+0x30]
00007ff1409df65f  por xmm11, xmm1
00007ff1409df664  movaps [r15+0x250], xmm11
00007ff1409df66c  vmovaps [rsp+0x30], xmm12
00007ff1409df672  vmovaps xmm1, [rsp+0x30]
00007ff1409df678  por xmm12, xmm1
00007ff1409df67d  movaps [r15+0x2A0], xmm12
00007ff1409df685  vmovaps xmm1, [rsp+0xA0]
00007ff1409df68e  vmovaps xmm11, [rsp+0xA0]
00007ff1409df697  por xmm1, xmm11
00007ff1409df69c  movaps [r15+0x1D0], xmm1
00007ff1409df6a4  lea r12, [rax+0x40]
00007ff1409df6a8  movups xmm1, [r13+r12*1]
00007ff1409df6ae  movaps [r15+0x2C0], xmm1
00007ff1409df6b6  vmovaps xmm11, [rsp+0x40]
00007ff1409df6bc  vpermilpd xmm11, xmm11, 0x00
00007ff1409df6c2  vmovaps xmm8, [rsp+0xE0]
00007ff1409df6cb  movaps xmm9, xmm8
00007ff1409df6cf  mulpd xmm9, xmm11
00007ff1409df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007ff1409df6da  ptest xmm5, xmm5
00007ff1409df6df  jnz 0x00007FF1409E2DF7
00007ff1409df6e5  movaps xmm11, xmm10
00007ff1409df6e9  addpd xmm11, xmm6
00007ff1409df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007ff1409df6f4  ptest xmm8, xmm8
00007ff1409df6fa  jnz 0x00007FF1409E2F3B
00007ff1409df700  movaps xmm10, xmm14
00007ff1409df704  addpd xmm10, xmm4
00007ff1409df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007ff1409df70f  ptest xmm8, xmm8
00007ff1409df715  jnz 0x00007FF1409E307E
00007ff1409df71b  vmovaps xmm14, [rsp+0x40]
00007ff1409df721  vpermilpd xmm14, xmm14, 0x00
00007ff1409df727  movaps xmm8, xmm1
00007ff1409df72b  mulpd xmm8, xmm14
00007ff1409df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007ff1409df736  ptest xmm6, xmm6
00007ff1409df73b  jnz 0x00007FF1409E31C1
00007ff1409df741  movaps xmm1, [r15+0x2B0]
00007ff1409df749  vmovaps xmm14, [rsp+0x40]
00007ff1409df74f  vpermilpd xmm14, xmm14, 0x00
00007ff1409df755  movaps xmm6, xmm1
00007ff1409df758  mulpd xmm6, xmm14
00007ff1409df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007ff1409df762  ptest xmm5, xmm5
00007ff1409df767  jnz 0x00007FF1409E3304
00007ff1409df76d  vmovaps xmm1, [rsp+0x10]
00007ff1409df773  vpermilpd xmm1, xmm1, 0x00
00007ff1409df779  movaps xmm14, xmm12
00007ff1409df77d  mulpd xmm14, xmm1
00007ff1409df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007ff1409df788  ptest xmm5, xmm5
00007ff1409df78d  jnz 0x00007FF1409E3445
00007ff1409df793  movaps xmm1, xmm13
00007ff1409df797  addpd xmm1, xmm9
00007ff1409df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007ff1409df7a1  ptest xmm12, xmm12
00007ff1409df7a7  jnz 0x00007FF1409E3588
00007ff1409df7ad  vmovaps xmm13, [rsp+0x10]
00007ff1409df7b3  vpermilpd xmm13, xmm13, 0x00
00007ff1409df7b9  movaps xmm12, xmm7
00007ff1409df7bd  mulpd xmm12, xmm13
00007ff1409df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007ff1409df7c8  ptest xmm9, xmm9
00007ff1409df7ce  jnz 0x00007FF1409E36CA
00007ff1409df7d4  movaps xmm13, xmm15
00007ff1409df7d8  addpd xmm13, xmm8
00007ff1409df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007ff1409df7e3  ptest xmm9, xmm9
00007ff1409df7e9  jnz 0x00007FF1409E380D
00007ff1409df7ef  movaps xmm15, [r15+0x290]
00007ff1409df7f7  vmovaps xmm9, [rsp+0x10]
00007ff1409df7fd  vpermilpd xmm9, xmm9, 0x00
00007ff1409df803  movaps xmm8, xmm15
00007ff1409df807  mulpd xmm8, xmm9
00007ff1409df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007ff1409df812  ptest xmm7, xmm7
00007ff1409df817  jnz 0x00007FF1409E3951
00007ff1409df81d  movaps xmm15, xmm11
00007ff1409df821  addpd xmm15, xmm6
00007ff1409df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007ff1409df82c  ptest xmm9, xmm9
00007ff1409df832  jnz 0x00007FF1409E3A95
00007ff1409df838  movaps xmm11, [r15+0x1E0]
00007ff1409df840  vmovaps xmm9, [rsp+0x10]
00007ff1409df846  vpermilpd xmm9, xmm9, 0x00
00007ff1409df84c  movaps xmm7, xmm11
00007ff1409df850  mulpd xmm7, xmm9
00007ff1409df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007ff1409df85a  ptest xmm6, xmm6
00007ff1409df85f  jnz 0x00007FF1409E3BD8
00007ff1409df865  movaps xmm11, xmm10
00007ff1409df869  addpd xmm11, xmm14
00007ff1409df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007ff1409df874  ptest xmm9, xmm9
00007ff1409df87a  jnz 0x00007FF1409E3D1A
00007ff1409df880  lea r12, [rax+0x70]
00007ff1409df884  movups xmm14, [r13+r12*1]
00007ff1409df88a  movaps [r15+0x240], xmm14
00007ff1409df892  movaps xmm10, xmm1
00007ff1409df896  addpd xmm10, xmm12
00007ff1409df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007ff1409df8a1  ptest xmm9, xmm9
00007ff1409df8a7  jnz 0x00007FF1409E3E68
00007ff1409df8ad  movaps [r15+0x170], xmm10
00007ff1409df8b5  vmovaps xmm1, [rsp+0x20]
00007ff1409df8bb  vpermilpd xmm1, xmm1, 0x00
00007ff1409df8c1  movaps xmm12, xmm14
00007ff1409df8c5  mulpd xmm12, xmm1
00007ff1409df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007ff1409df8d0  ptest xmm9, xmm9
00007ff1409df8d6  jnz 0x00007FF1409E3FAB
00007ff1409df8dc  vmovaps xmm1, [rsp+0x20]
00007ff1409df8e2  vpermilpd xmm1, xmm1, 0x00
00007ff1409df8e8  vmovaps xmm9, [rsp+0xB0]
00007ff1409df8f1  movaps xmm14, xmm9
00007ff1409df8f5  mulpd xmm14, xmm1
00007ff1409df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007ff1409df900  ptest xmm6, xmm6
00007ff1409df905  jnz 0x00007FF1409E40EE
00007ff1409df90b  movaps [r15+0x180], xmm14
00007ff1409df913  movaps xmm1, xmm13
00007ff1409df917  addpd xmm1, xmm8
00007ff1409df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007ff1409df921  ptest xmm9, xmm9
00007ff1409df927  jnz 0x00007FF1409E4231
00007ff1409df92d  movaps [r15+0x210], xmm1
00007ff1409df935  movups xmm13, [r13+rax*1]
00007ff1409df93b  lea r12, [rax+0x10]
00007ff1409df93f  movups xmm9, [r13+r12*1]
00007ff1409df945  movaps [r15+0x230], xmm9
00007ff1409df94d  movaps xmm8, xmm15
00007ff1409df951  addpd xmm8, xmm7
00007ff1409df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007ff1409df95c  ptest xmm6, xmm6
00007ff1409df961  jnz 0x00007FF1409E4387
00007ff1409df967  movaps [r15+0x130], xmm8
00007ff1409df96f  vmovaps xmm15, [rsp+0x20]
00007ff1409df975  vpermilpd xmm15, xmm15, 0x00
00007ff1409df97b  movaps xmm7, xmm9
00007ff1409df97f  mulpd xmm7, xmm15
00007ff1409df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007ff1409df989  ptest xmm6, xmm6
00007ff1409df98e  jnz 0x00007FF1409E44CA
00007ff1409df994  movaps [r15+0x220], xmm7
00007ff1409df99c  vmovaps xmm15, [rsp+0x20]
00007ff1409df9a2  vpermilpd xmm15, xmm15, 0x00
00007ff1409df9a8  movaps xmm9, xmm13
00007ff1409df9ac  mulpd xmm9, xmm15
00007ff1409df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007ff1409df9b7  ptest xmm6, xmm6
00007ff1409df9bc  jnz 0x00007FF1409E460C
00007ff1409df9c2  movaps xmm15, xmm11
00007ff1409df9c6  addpd xmm15, xmm12
00007ff1409df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007ff1409df9d1  ptest xmm13, xmm13
00007ff1409df9d7  jnz 0x00007FF1409E4750
00007ff1409df9dd  movaps [r15+0x140], xmm15
00007ff1409df9e5  movaps xmm13, xmm10
00007ff1409df9e9  addpd xmm13, xmm14
00007ff1409df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007ff1409df9f4  ptest xmm12, xmm12
00007ff1409df9fa  jnz 0x00007FF1409E4894
00007ff1409dfa00  movaps [r15+0x150], xmm13
00007ff1409dfa08  movaps xmm14, xmm1
00007ff1409dfa0c  addpd xmm14, xmm7
00007ff1409dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007ff1409dfa17  ptest xmm12, xmm12
00007ff1409dfa1d  jnz 0x00007FF1409E49D8
00007ff1409dfa23  movaps [r15+0x160], xmm14
00007ff1409dfa2b  movaps xmm1, xmm8
00007ff1409dfa2f  addpd xmm1, xmm9
00007ff1409dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007ff1409dfa39  ptest xmm12, xmm12
00007ff1409dfa3f  jnz 0x00007FF1409E4B1A
00007ff1409dfa45  movaps [r15+0x120], xmm1
00007ff1409dfa4d  movups [r13+r14*1], xmm15
00007ff1409dfa53  lea rax, [r14+0x10]
00007ff1409dfa57  movups [r13+rax*1], xmm13
00007ff1409dfa5d  lea rax, [r14+0x20]
00007ff1409dfa61  movups [r13+rax*1], xmm14
00007ff1409dfa67  lea rax, [r14+0x30]
00007ff1409dfa6b  movups [r13+rax*1], xmm1
00007ff1409dfa71  mov eax, [r15+0x108]
00007ff1409dfa78  sahf
00007ff1409dfa79  jnz 0x00007FF1409DFAAB
00007ff1409dfa7b  cmp dword ptr [r15+0x318], 0x00
00007ff1409dfa83  jz 0x00007FF1409DEAE0
00007ff1409dfa89  nop [rax+rax*1], ax
00007ff1409dfa92  nop [rax+rax*1], eax
00007ff1409dfa9a  mov eax, 0x4106D0
00007ff1409dfa9f  mov [r15+0x100], rax
00007ff1409dfaa6  jmp 0x00007FF1407FE110
00007ff1409dfaab  cmp dword ptr [r15+0x318], 0x00
00007ff1409dfab3  jz 0x00007FF1409D89C0
00007ff1409dfab9  nop [rax+rax*1], ax
00007ff1409dfac2  nop [rax+rax*1], eax
00007ff1409dfaca  mov eax, 0x410504
00007ff1409dfacf  mov [r15+0x100], rax
00007ff1409dfad6  jmp 0x00007FF1407FE110
00007ff1409dfadb  int3
00007ff1409dfadc  call 0x00007FF1408E27E0
00007ff1409dfae1  jmp 0x00007FF1409DEBBF
00007ff1409dfae6  call 0x00007FF1408E1570
00007ff1409dfaeb  jmp 0x00007FF1409DEBC8
00007ff1409dfaf0  call 0x00007FF1408E27E0
00007ff1409dfaf5  jmp 0x00007FF1409DEC24
00007ff1409dfafa  call 0x00007FF1408E1570
00007ff1409dfaff  jmp 0x00007FF1409DEC2D
00007ff1409dfb04  call 0x00007FF1408E27E0
00007ff1409dfb09  jmp 0x00007FF1409DEC70
00007ff1409dfb0e  call 0x00007FF1408E1570
00007ff1409dfb13  jmp 0x00007FF1409DEC79
00007ff1409dfb18  call 0x00007FF14080DC20
00007ff1409dfb1d  jmp 0x00007FF1409DECB8
00007ff1409dfb22  call 0x00007FF1408D59C0
00007ff1409dfb27  jmp 0x00007FF1409DECCB
00007ff1409dfb2c  call 0x00007FF1408E0E30
00007ff1409dfb31  jmp 0x00007FF1409DECE9
00007ff1409dfb36  call 0x00007FF1408DFBC0
00007ff1409dfb3b  jmp 0x00007FF1409DECF3
00007ff1409dfb40  call 0x00007FF1408DE950
00007ff1409dfb45  jmp 0x00007FF1409DECFD
00007ff1409dfb4a  sub rsp, 0x08
00007ff1409dfb4e  push rax
00007ff1409dfb4f  push rcx
00007ff1409dfb50  push rdx
00007ff1409dfb51  push rdi
00007ff1409dfb52  push rsi
00007ff1409dfb53  push r8
00007ff1409dfb55  push r9
00007ff1409dfb57  push r10
00007ff1409dfb59  push r11
00007ff1409dfb5b  sub rsp, 0xF0
00007ff1409dfb62  vmovaps [rsp], xmm0
00007ff1409dfb67  vmovaps [rsp+0x10], xmm1
00007ff1409dfb6d  vmovaps [rsp+0x20], xmm2
00007ff1409dfb73  vmovaps [rsp+0x30], xmm3
00007ff1409dfb79  vmovaps [rsp+0x40], xmm4
00007ff1409dfb7f  vmovaps [rsp+0x50], xmm5
00007ff1409dfb85  vmovaps [rsp+0x60], xmm6
00007ff1409dfb8b  vmovaps [rsp+0x70], xmm7
00007ff1409dfb91  vmovaps [rsp+0x80], xmm9
00007ff1409dfb9a  vmovaps [rsp+0x90], xmm10
00007ff1409dfba3  vmovaps [rsp+0xA0], xmm11
00007ff1409dfbac  vmovaps [rsp+0xB0], xmm12
00007ff1409dfbb5  vmovaps [rsp+0xC0], xmm13
00007ff1409dfbbe  vmovaps [rsp+0xD0], xmm14
00007ff1409dfbc7  vmovaps [rsp+0xE0], xmm15
00007ff1409dfbd0  sub rsp, 0x30
00007ff1409dfbd4  movaps [rsp], xmm8
00007ff1409dfbd9  movaps [rsp+0x10], xmm12
00007ff1409dfbdf  movaps [rsp+0x20], xmm15
00007ff1409dfbe5  lea rdi, [rsp]
00007ff1409dfbe9  mov esi, 0x00
00007ff1409dfbee  mov rax, 0x565C7F10C530
00007ff1409dfbf8  call rax
00007ff1409dfbfa  movaps xmm8, [rsp]
00007ff1409dfbff  add rsp, 0x30
00007ff1409dfc03  vmovaps xmm0, [rsp]
00007ff1409dfc08  vmovaps xmm1, [rsp+0x10]
00007ff1409dfc0e  vmovaps xmm2, [rsp+0x20]
00007ff1409dfc14  vmovaps xmm3, [rsp+0x30]
00007ff1409dfc1a  vmovaps xmm4, [rsp+0x40]
00007ff1409dfc20  vmovaps xmm5, [rsp+0x50]
00007ff1409dfc26  vmovaps xmm6, [rsp+0x60]
00007ff1409dfc2c  vmovaps xmm7, [rsp+0x70]
00007ff1409dfc32  vmovaps xmm9, [rsp+0x80]
00007ff1409dfc3b  vmovaps xmm10, [rsp+0x90]
00007ff1409dfc44  vmovaps xmm11, [rsp+0xA0]
00007ff1409dfc4d  vmovaps xmm12, [rsp+0xB0]
00007ff1409dfc56  vmovaps xmm13, [rsp+0xC0]
00007ff1409dfc5f  vmovaps xmm14, [rsp+0xD0]
00007ff1409dfc68  vmovaps xmm15, [rsp+0xE0]
00007ff1409dfc71  add rsp, 0xF0
00007ff1409dfc78  pop r11
00007ff1409dfc7a  pop r10
00007ff1409dfc7c  pop r9
00007ff1409dfc7e  pop r8
00007ff1409dfc80  pop rsi
00007ff1409dfc81  pop rdi
00007ff1409dfc82  pop rdx
00007ff1409dfc83  pop rcx
00007ff1409dfc84  pop rax
00007ff1409dfc85  add rsp, 0x08
00007ff1409dfc89  jmp 0x00007FF1409DED27
00007ff1409dfc8e  sub rsp, 0x08
00007ff1409dfc92  push rax
00007ff1409dfc93  push rcx
00007ff1409dfc94  push rdx
00007ff1409dfc95  push rdi
00007ff1409dfc96  push rsi
00007ff1409dfc97  push r8
00007ff1409dfc99  push r9
00007ff1409dfc9b  push r10
00007ff1409dfc9d  push r11
00007ff1409dfc9f  sub rsp, 0xF0
00007ff1409dfca6  vmovaps [rsp], xmm0
00007ff1409dfcab  vmovaps [rsp+0x10], xmm1
00007ff1409dfcb1  vmovaps [rsp+0x20], xmm2
00007ff1409dfcb7  vmovaps [rsp+0x30], xmm3
00007ff1409dfcbd  vmovaps [rsp+0x40], xmm4
00007ff1409dfcc3  vmovaps [rsp+0x50], xmm5
00007ff1409dfcc9  vmovaps [rsp+0x60], xmm6
00007ff1409dfccf  vmovaps [rsp+0x70], xmm8
00007ff1409dfcd5  vmovaps [rsp+0x80], xmm9
00007ff1409dfcde  vmovaps [rsp+0x90], xmm10
00007ff1409dfce7  vmovaps [rsp+0xA0], xmm11
00007ff1409dfcf0  vmovaps [rsp+0xB0], xmm12
00007ff1409dfcf9  vmovaps [rsp+0xC0], xmm13
00007ff1409dfd02  vmovaps [rsp+0xD0], xmm14
00007ff1409dfd0b  vmovaps [rsp+0xE0], xmm15
00007ff1409dfd14  sub rsp, 0x30
00007ff1409dfd18  movaps [rsp], xmm7
00007ff1409dfd1c  movaps [rsp+0x10], xmm9
00007ff1409dfd22  movaps [rsp+0x20], xmm15
00007ff1409dfd28  lea rdi, [rsp]
00007ff1409dfd2c  mov esi, 0x00
00007ff1409dfd31  mov rax, 0x565C7F10C530
00007ff1409dfd3b  call rax
00007ff1409dfd3d  movaps xmm7, [rsp]
00007ff1409dfd41  add rsp, 0x30
00007ff1409dfd45  vmovaps xmm0, [rsp]
00007ff1409dfd4a  vmovaps xmm1, [rsp+0x10]
00007ff1409dfd50  vmovaps xmm2, [rsp+0x20]
00007ff1409dfd56  vmovaps xmm3, [rsp+0x30]
00007ff1409dfd5c  vmovaps xmm4, [rsp+0x40]
00007ff1409dfd62  vmovaps xmm5, [rsp+0x50]
00007ff1409dfd68  vmovaps xmm6, [rsp+0x60]
00007ff1409dfd6e  vmovaps xmm8, [rsp+0x70]
00007ff1409dfd74  vmovaps xmm9, [rsp+0x80]
00007ff1409dfd7d  vmovaps xmm10, [rsp+0x90]
00007ff1409dfd86  vmovaps xmm11, [rsp+0xA0]
00007ff1409dfd8f  vmovaps xmm12, [rsp+0xB0]
00007ff1409dfd98  vmovaps xmm13, [rsp+0xC0]
00007ff1409dfda1  vmovaps xmm14, [rsp+0xD0]
00007ff1409dfdaa  vmovaps xmm15, [rsp+0xE0]
00007ff1409dfdb3  add rsp, 0xF0
00007ff1409dfdba  pop r11
00007ff1409dfdbc  pop r10
00007ff1409dfdbe  pop r9
00007ff1409dfdc0  pop r8
00007ff1409dfdc2  pop rsi
00007ff1409dfdc3  pop rdi
00007ff1409dfdc4  pop rdx
00007ff1409dfdc5  pop rcx
00007ff1409dfdc6  pop rax
00007ff1409dfdc7  add rsp, 0x08
00007ff1409dfdcb  jmp 0x00007FF1409DED55
00007ff1409dfdd0  sub rsp, 0x08
00007ff1409dfdd4  push rax
00007ff1409dfdd5  push rcx
00007ff1409dfdd6  push rdx
00007ff1409dfdd7  push rdi
00007ff1409dfdd8  push rsi
00007ff1409dfdd9  push r8
00007ff1409dfddb  push r9
00007ff1409dfddd  push r10
00007ff1409dfddf  push r11
00007ff1409dfde1  sub rsp, 0xF0
00007ff1409dfde8  vmovaps [rsp], xmm0
00007ff1409dfded  vmovaps [rsp+0x10], xmm1
00007ff1409dfdf3  vmovaps [rsp+0x20], xmm2
00007ff1409dfdf9  vmovaps [rsp+0x30], xmm3
00007ff1409dfdff  vmovaps [rsp+0x40], xmm4
00007ff1409dfe05  vmovaps [rsp+0x50], xmm5
00007ff1409dfe0b  vmovaps [rsp+0x60], xmm6
00007ff1409dfe11  vmovaps [rsp+0x70], xmm7
00007ff1409dfe17  vmovaps [rsp+0x80], xmm8
00007ff1409dfe20  vmovaps [rsp+0x90], xmm10
00007ff1409dfe29  vmovaps [rsp+0xA0], xmm11
00007ff1409dfe32  vmovaps [rsp+0xB0], xmm12
00007ff1409dfe3b  vmovaps [rsp+0xC0], xmm13
00007ff1409dfe44  vmovaps [rsp+0xD0], xmm14
00007ff1409dfe4d  vmovaps [rsp+0xE0], xmm15
00007ff1409dfe56  sub rsp, 0x30
00007ff1409dfe5a  movaps [rsp], xmm9
00007ff1409dfe5f  movaps [rsp+0x10], xmm12
00007ff1409dfe65  movaps [rsp+0x20], xmm10
00007ff1409dfe6b  lea rdi, [rsp]
00007ff1409dfe6f  mov esi, 0x00
00007ff1409dfe74  mov rax, 0x565C7F10C530
00007ff1409dfe7e  call rax
00007ff1409dfe80  movaps xmm9, [rsp]
00007ff1409dfe85  add rsp, 0x30
00007ff1409dfe89  vmovaps xmm0, [rsp]
00007ff1409dfe8e  vmovaps xmm1, [rsp+0x10]
00007ff1409dfe94  vmovaps xmm2, [rsp+0x20]
00007ff1409dfe9a  vmovaps xmm3, [rsp+0x30]
00007ff1409dfea0  vmovaps xmm4, [rsp+0x40]
00007ff1409dfea6  vmovaps xmm5, [rsp+0x50]
00007ff1409dfeac  vmovaps xmm6, [rsp+0x60]
00007ff1409dfeb2  vmovaps xmm7, [rsp+0x70]
00007ff1409dfeb8  vmovaps xmm8, [rsp+0x80]
00007ff1409dfec1  vmovaps xmm10, [rsp+0x90]
00007ff1409dfeca  vmovaps xmm11, [rsp+0xA0]
00007ff1409dfed3  vmovaps xmm12, [rsp+0xB0]
00007ff1409dfedc  vmovaps xmm13, [rsp+0xC0]
00007ff1409dfee5  vmovaps xmm14, [rsp+0xD0]
00007ff1409dfeee  vmovaps xmm15, [rsp+0xE0]
00007ff1409dfef7  add rsp, 0xF0
00007ff1409dfefe  pop r11
00007ff1409dff00  pop r10
00007ff1409dff02  pop r9
00007ff1409dff04  pop r8
00007ff1409dff06  pop rsi
00007ff1409dff07  pop rdi
00007ff1409dff08  pop rdx
00007ff1409dff09  pop rcx
00007ff1409dff0a  pop rax
00007ff1409dff0b  add rsp, 0x08
00007ff1409dff0f  jmp 0x00007FF1409DED79
00007ff1409dff14  sub rsp, 0x08
00007ff1409dff18  push rax
00007ff1409dff19  push rcx
00007ff1409dff1a  push rdx
00007ff1409dff1b  push rdi
00007ff1409dff1c  push rsi
00007ff1409dff1d  push r8
00007ff1409dff1f  push r9
00007ff1409dff21  push r10
00007ff1409dff23  push r11
00007ff1409dff25  sub rsp, 0xF0
00007ff1409dff2c  vmovaps [rsp], xmm0
00007ff1409dff31  vmovaps [rsp+0x10], xmm1
00007ff1409dff37  vmovaps [rsp+0x20], xmm2
00007ff1409dff3d  vmovaps [rsp+0x30], xmm3
00007ff1409dff43  vmovaps [rsp+0x40], xmm4
00007ff1409dff49  vmovaps [rsp+0x50], xmm5
00007ff1409dff4f  vmovaps [rsp+0x60], xmm6
00007ff1409dff55  vmovaps [rsp+0x70], xmm7
00007ff1409dff5b  vmovaps [rsp+0x80], xmm8
00007ff1409dff64  vmovaps [rsp+0x90], xmm9
00007ff1409dff6d  vmovaps [rsp+0xA0], xmm11
00007ff1409dff76  vmovaps [rsp+0xB0], xmm12
00007ff1409dff7f  vmovaps [rsp+0xC0], xmm13
00007ff1409dff88  vmovaps [rsp+0xD0], xmm14
00007ff1409dff91  vmovaps [rsp+0xE0], xmm15
00007ff1409dff9a  sub rsp, 0x30
00007ff1409dff9e  movaps [rsp], xmm10
00007ff1409dffa3  movaps [rsp+0x10], xmm12
00007ff1409dffa9  movaps [rsp+0x20], xmm11
00007ff1409dffaf  lea rdi, [rsp]
00007ff1409dffb3  mov esi, 0x00
00007ff1409dffb8  mov rax, 0x565C7F10C530
00007ff1409dffc2  call rax
00007ff1409dffc4  movaps xmm10, [rsp]
00007ff1409dffc9  add rsp, 0x30
00007ff1409dffcd  vmovaps xmm0, [rsp]
00007ff1409dffd2  vmovaps xmm1, [rsp+0x10]
00007ff1409dffd8  vmovaps xmm2, [rsp+0x20]
00007ff1409dffde  vmovaps xmm3, [rsp+0x30]
00007ff1409dffe4  vmovaps xmm4, [rsp+0x40]
00007ff1409dffea  vmovaps xmm5, [rsp+0x50]
00007ff1409dfff0  vmovaps xmm6, [rsp+0x60]
00007ff1409dfff6  vmovaps xmm7, [rsp+0x70]
00007ff1409dfffc  vmovaps xmm8, [rsp+0x80]
00007ff1409e0005  vmovaps xmm9, [rsp+0x90]
00007ff1409e000e  vmovaps xmm11, [rsp+0xA0]
00007ff1409e0017  vmovaps xmm12, [rsp+0xB0]
00007ff1409e0020  vmovaps xmm13, [rsp+0xC0]
00007ff1409e0029  vmovaps xmm14, [rsp+0xD0]
00007ff1409e0032  vmovaps xmm15, [rsp+0xE0]
00007ff1409e003b  add rsp, 0xF0
00007ff1409e0042  pop r11
00007ff1409e0044  pop r10
00007ff1409e0046  pop r9
00007ff1409e0048  pop r8
00007ff1409e004a  pop rsi
00007ff1409e004b  pop rdi
00007ff1409e004c  pop rdx
00007ff1409e004d  pop rcx
00007ff1409e004e  pop rax
00007ff1409e004f  add rsp, 0x08
00007ff1409e0053  jmp 0x00007FF1409DED93
00007ff1409e0058  sub rsp, 0x08
00007ff1409e005c  push rax
00007ff1409e005d  push rcx
00007ff1409e005e  push rdx
00007ff1409e005f  push rdi
00007ff1409e0060  push rsi
00007ff1409e0061  push r8
00007ff1409e0063  push r9
00007ff1409e0065  push r10
00007ff1409e0067  push r11
00007ff1409e0069  sub rsp, 0xF0
00007ff1409e0070  vmovaps [rsp], xmm0
00007ff1409e0075  vmovaps [rsp+0x10], xmm1
00007ff1409e007b  vmovaps [rsp+0x20], xmm2
00007ff1409e0081  vmovaps [rsp+0x30], xmm3
00007ff1409e0087  vmovaps [rsp+0x40], xmm4
00007ff1409e008d  vmovaps [rsp+0x50], xmm5
00007ff1409e0093  vmovaps [rsp+0x60], xmm7
00007ff1409e0099  vmovaps [rsp+0x70], xmm8
00007ff1409e009f  vmovaps [rsp+0x80], xmm9
00007ff1409e00a8  vmovaps [rsp+0x90], xmm10
00007ff1409e00b1  vmovaps [rsp+0xA0], xmm11
00007ff1409e00ba  vmovaps [rsp+0xB0], xmm12
00007ff1409e00c3  vmovaps [rsp+0xC0], xmm13
00007ff1409e00cc  vmovaps [rsp+0xD0], xmm14
00007ff1409e00d5  vmovaps [rsp+0xE0], xmm15
00007ff1409e00de  sub rsp, 0x30
00007ff1409e00e2  movaps [rsp], xmm6
00007ff1409e00e6  movaps [rsp+0x10], xmm12
00007ff1409e00ec  movaps [rsp+0x20], xmm11
00007ff1409e00f2  lea rdi, [rsp]
00007ff1409e00f6  mov esi, 0x00
00007ff1409e00fb  mov rax, 0x565C7F10C530
00007ff1409e0105  call rax
00007ff1409e0107  movaps xmm6, [rsp]
00007ff1409e010b  add rsp, 0x30
00007ff1409e010f  vmovaps xmm0, [rsp]
00007ff1409e0114  vmovaps xmm1, [rsp+0x10]
00007ff1409e011a  vmovaps xmm2, [rsp+0x20]
00007ff1409e0120  vmovaps xmm3, [rsp+0x30]
00007ff1409e0126  vmovaps xmm4, [rsp+0x40]
00007ff1409e012c  vmovaps xmm5, [rsp+0x50]
00007ff1409e0132  vmovaps xmm7, [rsp+0x60]
00007ff1409e0138  vmovaps xmm8, [rsp+0x70]
00007ff1409e013e  vmovaps xmm9, [rsp+0x80]
00007ff1409e0147  vmovaps xmm10, [rsp+0x90]
00007ff1409e0150  vmovaps xmm11, [rsp+0xA0]
00007ff1409e0159  vmovaps xmm12, [rsp+0xB0]
00007ff1409e0162  vmovaps xmm13, [rsp+0xC0]
00007ff1409e016b  vmovaps xmm14, [rsp+0xD0]
00007ff1409e0174  vmovaps xmm15, [rsp+0xE0]
00007ff1409e017d  add rsp, 0xF0
00007ff1409e0184  pop r11
00007ff1409e0186  pop r10
00007ff1409e0188  pop r9
00007ff1409e018a  pop r8
00007ff1409e018c  pop rsi
00007ff1409e018d  pop rdi
00007ff1409e018e  pop rdx
00007ff1409e018f  pop rcx
00007ff1409e0190  pop rax
00007ff1409e0191  add rsp, 0x08
00007ff1409e0195  jmp 0x00007FF1409DEDB4
00007ff1409e019a  sub rsp, 0x08
00007ff1409e019e  push rax
00007ff1409e019f  push rcx
00007ff1409e01a0  push rdx
00007ff1409e01a1  push rdi
00007ff1409e01a2  push rsi
00007ff1409e01a3  push r8
00007ff1409e01a5  push r9
00007ff1409e01a7  push r10
00007ff1409e01a9  push r11
00007ff1409e01ab  sub rsp, 0xF0
00007ff1409e01b2  vmovaps [rsp], xmm0
00007ff1409e01b7  vmovaps [rsp+0x10], xmm1
00007ff1409e01bd  vmovaps [rsp+0x20], xmm2
00007ff1409e01c3  vmovaps [rsp+0x30], xmm4
00007ff1409e01c9  vmovaps [rsp+0x40], xmm5
00007ff1409e01cf  vmovaps [rsp+0x50], xmm6
00007ff1409e01d5  vmovaps [rsp+0x60], xmm7
00007ff1409e01db  vmovaps [rsp+0x70], xmm8
00007ff1409e01e1  vmovaps [rsp+0x80], xmm9
00007ff1409e01ea  vmovaps [rsp+0x90], xmm10
00007ff1409e01f3  vmovaps [rsp+0xA0], xmm11
00007ff1409e01fc  vmovaps [rsp+0xB0], xmm12
00007ff1409e0205  vmovaps [rsp+0xC0], xmm13
00007ff1409e020e  vmovaps [rsp+0xD0], xmm14
00007ff1409e0217  vmovaps [rsp+0xE0], xmm15
00007ff1409e0220  sub rsp, 0x30
00007ff1409e0224  movaps [rsp], xmm3
00007ff1409e0228  movaps [rsp+0x10], xmm5
00007ff1409e022d  movaps [rsp+0x20], xmm4
00007ff1409e0232  lea rdi, [rsp]
00007ff1409e0236  mov esi, 0x00
00007ff1409e023b  mov rax, 0x565C7F10C530
00007ff1409e0245  call rax
00007ff1409e0247  movaps xmm3, [rsp]
00007ff1409e024b  add rsp, 0x30
00007ff1409e024f  vmovaps xmm0, [rsp]
00007ff1409e0254  vmovaps xmm1, [rsp+0x10]
00007ff1409e025a  vmovaps xmm2, [rsp+0x20]
00007ff1409e0260  vmovaps xmm4, [rsp+0x30]
00007ff1409e0266  vmovaps xmm5, [rsp+0x40]
00007ff1409e026c  vmovaps xmm6, [rsp+0x50]
00007ff1409e0272  vmovaps xmm7, [rsp+0x60]
00007ff1409e0278  vmovaps xmm8, [rsp+0x70]
00007ff1409e027e  vmovaps xmm9, [rsp+0x80]
00007ff1409e0287  vmovaps xmm10, [rsp+0x90]
00007ff1409e0290  vmovaps xmm11, [rsp+0xA0]
00007ff1409e0299  vmovaps xmm12, [rsp+0xB0]
00007ff1409e02a2  vmovaps xmm13, [rsp+0xC0]
00007ff1409e02ab  vmovaps xmm14, [rsp+0xD0]
00007ff1409e02b4  vmovaps xmm15, [rsp+0xE0]
00007ff1409e02bd  add rsp, 0xF0
00007ff1409e02c4  pop r11
00007ff1409e02c6  pop r10
00007ff1409e02c8  pop r9
00007ff1409e02ca  pop r8
00007ff1409e02cc  pop rsi
00007ff1409e02cd  pop rdi
00007ff1409e02ce  pop rdx
00007ff1409e02cf  pop rcx
00007ff1409e02d0  pop rax
00007ff1409e02d1  add rsp, 0x08
00007ff1409e02d5  jmp 0x00007FF1409DEE15
00007ff1409e02da  sub rsp, 0x08
00007ff1409e02de  push rax
00007ff1409e02df  push rcx
00007ff1409e02e0  push rdx
00007ff1409e02e1  push rdi
00007ff1409e02e2  push rsi
00007ff1409e02e3  push r8
00007ff1409e02e5  push r9
00007ff1409e02e7  push r10
00007ff1409e02e9  push r11
00007ff1409e02eb  sub rsp, 0xF0
00007ff1409e02f2  vmovaps [rsp], xmm0
00007ff1409e02f7  vmovaps [rsp+0x10], xmm1
00007ff1409e02fd  vmovaps [rsp+0x20], xmm2
00007ff1409e0303  vmovaps [rsp+0x30], xmm3
00007ff1409e0309  vmovaps [rsp+0x40], xmm4
00007ff1409e030f  vmovaps [rsp+0x50], xmm6
00007ff1409e0315  vmovaps [rsp+0x60], xmm7
00007ff1409e031b  vmovaps [rsp+0x70], xmm8
00007ff1409e0321  vmovaps [rsp+0x80], xmm9
00007ff1409e032a  vmovaps [rsp+0x90], xmm10
00007ff1409e0333  vmovaps [rsp+0xA0], xmm11
00007ff1409e033c  vmovaps [rsp+0xB0], xmm12
00007ff1409e0345  vmovaps [rsp+0xC0], xmm13
00007ff1409e034e  vmovaps [rsp+0xD0], xmm14
00007ff1409e0357  vmovaps [rsp+0xE0], xmm15
00007ff1409e0360  sub rsp, 0x30
00007ff1409e0364  movaps [rsp], xmm5
00007ff1409e0368  movaps [rsp+0x10], xmm8
00007ff1409e036e  movaps [rsp+0x20], xmm15
00007ff1409e0374  lea rdi, [rsp]
00007ff1409e0378  mov esi, 0x00
00007ff1409e037d  mov rax, 0x565C7F10C530
00007ff1409e0387  call rax
00007ff1409e0389  movaps xmm5, [rsp]
00007ff1409e038d  add rsp, 0x30
00007ff1409e0391  vmovaps xmm0, [rsp]
00007ff1409e0396  vmovaps xmm1, [rsp+0x10]
00007ff1409e039c  vmovaps xmm2, [rsp+0x20]
00007ff1409e03a2  vmovaps xmm3, [rsp+0x30]
00007ff1409e03a8  vmovaps xmm4, [rsp+0x40]
00007ff1409e03ae  vmovaps xmm6, [rsp+0x50]
00007ff1409e03b4  vmovaps xmm7, [rsp+0x60]
00007ff1409e03ba  vmovaps xmm8, [rsp+0x70]
00007ff1409e03c0  vmovaps xmm9, [rsp+0x80]
00007ff1409e03c9  vmovaps xmm10, [rsp+0x90]
00007ff1409e03d2  vmovaps xmm11, [rsp+0xA0]
00007ff1409e03db  vmovaps xmm12, [rsp+0xB0]
00007ff1409e03e4  vmovaps xmm13, [rsp+0xC0]
00007ff1409e03ed  vmovaps xmm14, [rsp+0xD0]
00007ff1409e03f6  vmovaps xmm15, [rsp+0xE0]
00007ff1409e03ff  add rsp, 0xF0
00007ff1409e0406  pop r11
00007ff1409e0408  pop r10
00007ff1409e040a  pop r9
00007ff1409e040c  pop r8
00007ff1409e040e  pop rsi
00007ff1409e040f  pop rdi
00007ff1409e0410  pop rdx
00007ff1409e0411  pop rcx
00007ff1409e0412  pop rax
00007ff1409e0413  add rsp, 0x08
00007ff1409e0417  jmp 0x00007FF1409DEE53
00007ff1409e041c  sub rsp, 0x08
00007ff1409e0420  push rax
00007ff1409e0421  push rcx
00007ff1409e0422  push rdx
00007ff1409e0423  push rdi
00007ff1409e0424  push rsi
00007ff1409e0425  push r8
00007ff1409e0427  push r9
00007ff1409e0429  push r10
00007ff1409e042b  push r11
00007ff1409e042d  sub rsp, 0xF0
00007ff1409e0434  vmovaps [rsp], xmm0
00007ff1409e0439  vmovaps [rsp+0x10], xmm1
00007ff1409e043f  vmovaps [rsp+0x20], xmm2
00007ff1409e0445  vmovaps [rsp+0x30], xmm3
00007ff1409e044b  vmovaps [rsp+0x40], xmm5
00007ff1409e0451  vmovaps [rsp+0x50], xmm6
00007ff1409e0457  vmovaps [rsp+0x60], xmm7
00007ff1409e045d  vmovaps [rsp+0x70], xmm8
00007ff1409e0463  vmovaps [rsp+0x80], xmm9
00007ff1409e046c  vmovaps [rsp+0x90], xmm10
00007ff1409e0475  vmovaps [rsp+0xA0], xmm11
00007ff1409e047e  vmovaps [rsp+0xB0], xmm12
00007ff1409e0487  vmovaps [rsp+0xC0], xmm13
00007ff1409e0490  vmovaps [rsp+0xD0], xmm14
00007ff1409e0499  vmovaps [rsp+0xE0], xmm15
00007ff1409e04a2  sub rsp, 0x30
00007ff1409e04a6  movaps [rsp], xmm4
00007ff1409e04aa  movaps [rsp+0x10], xmm9
00007ff1409e04b0  movaps [rsp+0x20], xmm8
00007ff1409e04b6  lea rdi, [rsp]
00007ff1409e04ba  mov esi, 0x00
00007ff1409e04bf  mov rax, 0x565C7F10C530
00007ff1409e04c9  call rax
00007ff1409e04cb  movaps xmm4, [rsp]
00007ff1409e04cf  add rsp, 0x30
00007ff1409e04d3  vmovaps xmm0, [rsp]
00007ff1409e04d8  vmovaps xmm1, [rsp+0x10]
00007ff1409e04de  vmovaps xmm2, [rsp+0x20]
00007ff1409e04e4  vmovaps xmm3, [rsp+0x30]
00007ff1409e04ea  vmovaps xmm5, [rsp+0x40]
00007ff1409e04f0  vmovaps xmm6, [rsp+0x50]
00007ff1409e04f6  vmovaps xmm7, [rsp+0x60]
00007ff1409e04fc  vmovaps xmm8, [rsp+0x70]
00007ff1409e0502  vmovaps xmm9, [rsp+0x80]
00007ff1409e050b  vmovaps xmm10, [rsp+0x90]
00007ff1409e0514  vmovaps xmm11, [rsp+0xA0]
00007ff1409e051d  vmovaps xmm12, [rsp+0xB0]
00007ff1409e0526  vmovaps xmm13, [rsp+0xC0]
00007ff1409e052f  vmovaps xmm14, [rsp+0xD0]
00007ff1409e0538  vmovaps xmm15, [rsp+0xE0]
00007ff1409e0541  add rsp, 0xF0
00007ff1409e0548  pop r11
00007ff1409e054a  pop r10
00007ff1409e054c  pop r9
00007ff1409e054e  pop r8
00007ff1409e0550  pop rsi
00007ff1409e0551  pop rdi
00007ff1409e0552  pop rdx
00007ff1409e0553  pop rcx
00007ff1409e0554  pop rax
00007ff1409e0555  add rsp, 0x08
00007ff1409e0559  jmp 0x00007FF1409DEE74
00007ff1409e055e  sub rsp, 0x08
00007ff1409e0562  push rax
00007ff1409e0563  push rcx
00007ff1409e0564  push rdx
00007ff1409e0565  push rdi
00007ff1409e0566  push rsi
00007ff1409e0567  push r8
00007ff1409e0569  push r9
00007ff1409e056b  push r10
00007ff1409e056d  push r11
00007ff1409e056f  sub rsp, 0xF0
00007ff1409e0576  vmovaps [rsp], xmm0
00007ff1409e057b  vmovaps [rsp+0x10], xmm1
00007ff1409e0581  vmovaps [rsp+0x20], xmm2
00007ff1409e0587  vmovaps [rsp+0x30], xmm3
00007ff1409e058d  vmovaps [rsp+0x40], xmm4
00007ff1409e0593  vmovaps [rsp+0x50], xmm5
00007ff1409e0599  vmovaps [rsp+0x60], xmm6
00007ff1409e059f  vmovaps [rsp+0x70], xmm7
00007ff1409e05a5  vmovaps [rsp+0x80], xmm8
00007ff1409e05ae  vmovaps [rsp+0x90], xmm10
00007ff1409e05b7  vmovaps [rsp+0xA0], xmm11
00007ff1409e05c0  vmovaps [rsp+0xB0], xmm12
00007ff1409e05c9  vmovaps [rsp+0xC0], xmm13
00007ff1409e05d2  vmovaps [rsp+0xD0], xmm14
00007ff1409e05db  vmovaps [rsp+0xE0], xmm15
00007ff1409e05e4  sub rsp, 0x30
00007ff1409e05e8  movaps [rsp], xmm9
00007ff1409e05ed  movaps [rsp+0x10], xmm10
00007ff1409e05f3  movaps [rsp+0x20], xmm8
00007ff1409e05f9  lea rdi, [rsp]
00007ff1409e05fd  mov esi, 0x00
00007ff1409e0602  mov rax, 0x565C7F10C530
00007ff1409e060c  call rax
00007ff1409e060e  movaps xmm9, [rsp]
00007ff1409e0613  add rsp, 0x30
00007ff1409e0617  vmovaps xmm0, [rsp]
00007ff1409e061c  vmovaps xmm1, [rsp+0x10]
00007ff1409e0622  vmovaps xmm2, [rsp+0x20]
00007ff1409e0628  vmovaps xmm3, [rsp+0x30]
00007ff1409e062e  vmovaps xmm4, [rsp+0x40]
00007ff1409e0634  vmovaps xmm5, [rsp+0x50]
00007ff1409e063a  vmovaps xmm6, [rsp+0x60]
00007ff1409e0640  vmovaps xmm7, [rsp+0x70]
00007ff1409e0646  vmovaps xmm8, [rsp+0x80]
00007ff1409e064f  vmovaps xmm10, [rsp+0x90]
00007ff1409e0658  vmovaps xmm11, [rsp+0xA0]
00007ff1409e0661  vmovaps xmm12, [rsp+0xB0]
00007ff1409e066a  vmovaps xmm13, [rsp+0xC0]
00007ff1409e0673  vmovaps xmm14, [rsp+0xD0]
00007ff1409e067c  vmovaps xmm15, [rsp+0xE0]
00007ff1409e0685  add rsp, 0xF0
00007ff1409e068c  pop r11
00007ff1409e068e  pop r10
00007ff1409e0690  pop r9
00007ff1409e0692  pop r8
00007ff1409e0694  pop rsi
00007ff1409e0695  pop rdi
00007ff1409e0696  pop rdx
00007ff1409e0697  pop rcx
00007ff1409e0698  pop rax
00007ff1409e0699  add rsp, 0x08
00007ff1409e069d  jmp 0x00007FF1409DEE8E
00007ff1409e06a2  call 0x00007FF1408B52F0
00007ff1409e06a7  jmp 0x00007FF1409DEFA8
00007ff1409e06ac  call 0x00007FF1408B52F0
00007ff1409e06b1  jmp 0x00007FF1409DEFBE
00007ff1409e06b6  sub rsp, 0x08
00007ff1409e06ba  push rax
00007ff1409e06bb  push rcx
00007ff1409e06bc  push rdx
00007ff1409e06bd  push rdi
00007ff1409e06be  push rsi
00007ff1409e06bf  push r8
00007ff1409e06c1  push r9
00007ff1409e06c3  push r10
00007ff1409e06c5  push r11
00007ff1409e06c7  sub rsp, 0xF0
00007ff1409e06ce  vmovaps [rsp], xmm0
00007ff1409e06d3  vmovaps [rsp+0x10], xmm2
00007ff1409e06d9  vmovaps [rsp+0x20], xmm3
00007ff1409e06df  vmovaps [rsp+0x30], xmm4
00007ff1409e06e5  vmovaps [rsp+0x40], xmm5
00007ff1409e06eb  vmovaps [rsp+0x50], xmm6
00007ff1409e06f1  vmovaps [rsp+0x60], xmm7
00007ff1409e06f7  vmovaps [rsp+0x70], xmm8
00007ff1409e06fd  vmovaps [rsp+0x80], xmm9
00007ff1409e0706  vmovaps [rsp+0x90], xmm10
00007ff1409e070f  vmovaps [rsp+0xA0], xmm11
00007ff1409e0718  vmovaps [rsp+0xB0], xmm12
00007ff1409e0721  vmovaps [rsp+0xC0], xmm13
00007ff1409e072a  vmovaps [rsp+0xD0], xmm14
00007ff1409e0733  vmovaps [rsp+0xE0], xmm15
00007ff1409e073c  sub rsp, 0x30
00007ff1409e0740  movaps [rsp], xmm1
00007ff1409e0744  movaps [rsp+0x10], xmm6
00007ff1409e0749  movaps [rsp+0x20], xmm15
00007ff1409e074f  lea rdi, [rsp]
00007ff1409e0753  mov esi, 0x00
00007ff1409e0758  mov rax, 0x565C7F10C530
00007ff1409e0762  call rax
00007ff1409e0764  movaps xmm1, [rsp]
00007ff1409e0768  add rsp, 0x30
00007ff1409e076c  vmovaps xmm0, [rsp]
00007ff1409e0771  vmovaps xmm2, [rsp+0x10]
00007ff1409e0777  vmovaps xmm3, [rsp+0x20]
00007ff1409e077d  vmovaps xmm4, [rsp+0x30]
00007ff1409e0783  vmovaps xmm5, [rsp+0x40]
00007ff1409e0789  vmovaps xmm6, [rsp+0x50]
00007ff1409e078f  vmovaps xmm7, [rsp+0x60]
00007ff1409e0795  vmovaps xmm8, [rsp+0x70]
00007ff1409e079b  vmovaps xmm9, [rsp+0x80]
00007ff1409e07a4  vmovaps xmm10, [rsp+0x90]
00007ff1409e07ad  vmovaps xmm11, [rsp+0xA0]
00007ff1409e07b6  vmovaps xmm12, [rsp+0xB0]
00007ff1409e07bf  vmovaps xmm13, [rsp+0xC0]
00007ff1409e07c8  vmovaps xmm14, [rsp+0xD0]
00007ff1409e07d1  vmovaps xmm15, [rsp+0xE0]
00007ff1409e07da  add rsp, 0xF0
00007ff1409e07e1  pop r11
00007ff1409e07e3  pop r10
00007ff1409e07e5  pop r9
00007ff1409e07e7  pop r8
00007ff1409e07e9  pop rsi
00007ff1409e07ea  pop rdi
00007ff1409e07eb  pop rdx
00007ff1409e07ec  pop rcx
00007ff1409e07ed  pop rax
00007ff1409e07ee  add rsp, 0x08
00007ff1409e07f2  jmp 0x00007FF1409DEFFB
00007ff1409e07f7  call 0x00007FF1408C4620
00007ff1409e07fc  jmp 0x00007FF1409DF008
00007ff1409e0801  sub rsp, 0x08
00007ff1409e0805  push rax
00007ff1409e0806  push rcx
00007ff1409e0807  push rdx
00007ff1409e0808  push rdi
00007ff1409e0809  push rsi
00007ff1409e080a  push r8
00007ff1409e080c  push r9
00007ff1409e080e  push r10
00007ff1409e0810  push r11
00007ff1409e0812  sub rsp, 0xF0
00007ff1409e0819  vmovaps [rsp], xmm0
00007ff1409e081e  vmovaps [rsp+0x10], xmm1
00007ff1409e0824  vmovaps [rsp+0x20], xmm2
00007ff1409e082a  vmovaps [rsp+0x30], xmm3
00007ff1409e0830  vmovaps [rsp+0x40], xmm4
00007ff1409e0836  vmovaps [rsp+0x50], xmm5
00007ff1409e083c  vmovaps [rsp+0x60], xmm6
00007ff1409e0842  vmovaps [rsp+0x70], xmm7
00007ff1409e0848  vmovaps [rsp+0x80], xmm8
00007ff1409e0851  vmovaps [rsp+0x90], xmm9
00007ff1409e085a  vmovaps [rsp+0xA0], xmm10
00007ff1409e0863  vmovaps [rsp+0xB0], xmm11
00007ff1409e086c  vmovaps [rsp+0xC0], xmm12
00007ff1409e0875  vmovaps [rsp+0xD0], xmm13
00007ff1409e087e  vmovaps [rsp+0xE0], xmm15
00007ff1409e0887  sub rsp, 0x30
00007ff1409e088b  movaps [rsp], xmm14
00007ff1409e0890  movaps [rsp+0x10], xmm4
00007ff1409e0895  movaps [rsp+0x20], xmm3
00007ff1409e089a  lea rdi, [rsp]
00007ff1409e089e  mov esi, 0x00
00007ff1409e08a3  mov rax, 0x565C7F10C530
00007ff1409e08ad  call rax
00007ff1409e08af  movaps xmm14, [rsp]
00007ff1409e08b4  add rsp, 0x30
00007ff1409e08b8  vmovaps xmm0, [rsp]
00007ff1409e08bd  vmovaps xmm1, [rsp+0x10]
00007ff1409e08c3  vmovaps xmm2, [rsp+0x20]
00007ff1409e08c9  vmovaps xmm3, [rsp+0x30]
00007ff1409e08cf  vmovaps xmm4, [rsp+0x40]
00007ff1409e08d5  vmovaps xmm5, [rsp+0x50]
00007ff1409e08db  vmovaps xmm6, [rsp+0x60]
00007ff1409e08e1  vmovaps xmm7, [rsp+0x70]
00007ff1409e08e7  vmovaps xmm8, [rsp+0x80]
00007ff1409e08f0  vmovaps xmm9, [rsp+0x90]
00007ff1409e08f9  vmovaps xmm10, [rsp+0xA0]
00007ff1409e0902  vmovaps xmm11, [rsp+0xB0]
00007ff1409e090b  vmovaps xmm12, [rsp+0xC0]
00007ff1409e0914  vmovaps xmm13, [rsp+0xD0]
00007ff1409e091d  vmovaps xmm15, [rsp+0xE0]
00007ff1409e0926  add rsp, 0xF0
00007ff1409e092d  pop r11
00007ff1409e092f  pop r10
00007ff1409e0931  pop r9
00007ff1409e0933  pop r8
00007ff1409e0935  pop rsi
00007ff1409e0936  pop rdi
00007ff1409e0937  pop rdx
00007ff1409e0938  pop rcx
00007ff1409e0939  pop rax
00007ff1409e093a  add rsp, 0x08
00007ff1409e093e  jmp 0x00007FF1409DF022
00007ff1409e0943  sub rsp, 0x08
00007ff1409e0947  push rax
00007ff1409e0948  push rcx
00007ff1409e0949  push rdx
00007ff1409e094a  push rdi
00007ff1409e094b  push rsi
00007ff1409e094c  push r8
00007ff1409e094e  push r9
00007ff1409e0950  push r10
00007ff1409e0952  push r11
00007ff1409e0954  sub rsp, 0xF0
00007ff1409e095b  vmovaps [rsp], xmm0
00007ff1409e0960  vmovaps [rsp+0x10], xmm1
00007ff1409e0966  vmovaps [rsp+0x20], xmm2
00007ff1409e096c  vmovaps [rsp+0x30], xmm3
00007ff1409e0972  vmovaps [rsp+0x40], xmm4
00007ff1409e0978  vmovaps [rsp+0x50], xmm5
00007ff1409e097e  vmovaps [rsp+0x60], xmm7
00007ff1409e0984  vmovaps [rsp+0x70], xmm8
00007ff1409e098a  vmovaps [rsp+0x80], xmm9
00007ff1409e0993  vmovaps [rsp+0x90], xmm10
00007ff1409e099c  vmovaps [rsp+0xA0], xmm11
00007ff1409e09a5  vmovaps [rsp+0xB0], xmm12
00007ff1409e09ae  vmovaps [rsp+0xC0], xmm13
00007ff1409e09b7  vmovaps [rsp+0xD0], xmm14
00007ff1409e09c0  vmovaps [rsp+0xE0], xmm15
00007ff1409e09c9  sub rsp, 0x30
00007ff1409e09cd  movaps [rsp], xmm6
00007ff1409e09d1  movaps [rsp+0x10], xmm9
00007ff1409e09d7  movaps [rsp+0x20], xmm7
00007ff1409e09dc  lea rdi, [rsp]
00007ff1409e09e0  mov esi, 0x00
00007ff1409e09e5  mov rax, 0x565C7F10C530
00007ff1409e09ef  call rax
00007ff1409e09f1  movaps xmm6, [rsp]
00007ff1409e09f5  add rsp, 0x30
00007ff1409e09f9  vmovaps xmm0, [rsp]
00007ff1409e09fe  vmovaps xmm1, [rsp+0x10]
00007ff1409e0a04  vmovaps xmm2, [rsp+0x20]
00007ff1409e0a0a  vmovaps xmm3, [rsp+0x30]
00007ff1409e0a10  vmovaps xmm4, [rsp+0x40]
00007ff1409e0a16  vmovaps xmm5, [rsp+0x50]
00007ff1409e0a1c  vmovaps xmm7, [rsp+0x60]
00007ff1409e0a22  vmovaps xmm8, [rsp+0x70]
00007ff1409e0a28  vmovaps xmm9, [rsp+0x80]
00007ff1409e0a31  vmovaps xmm10, [rsp+0x90]
00007ff1409e0a3a  vmovaps xmm11, [rsp+0xA0]
00007ff1409e0a43  vmovaps xmm12, [rsp+0xB0]
00007ff1409e0a4c  vmovaps xmm13, [rsp+0xC0]
00007ff1409e0a55  vmovaps xmm14, [rsp+0xD0]
00007ff1409e0a5e  vmovaps xmm15, [rsp+0xE0]
00007ff1409e0a67  add rsp, 0xF0
00007ff1409e0a6e  pop r11
00007ff1409e0a70  pop r10
00007ff1409e0a72  pop r9
00007ff1409e0a74  pop r8
00007ff1409e0a76  pop rsi
00007ff1409e0a77  pop rdi
00007ff1409e0a78  pop rdx
00007ff1409e0a79  pop rcx
00007ff1409e0a7a  pop rax
00007ff1409e0a7b  add rsp, 0x08
00007ff1409e0a7f  jmp 0x00007FF1409DF03A
00007ff1409e0a84  sub rsp, 0x08
00007ff1409e0a88  push rax
00007ff1409e0a89  push rcx
00007ff1409e0a8a  push rdx
00007ff1409e0a8b  push rdi
00007ff1409e0a8c  push rsi
00007ff1409e0a8d  push r8
00007ff1409e0a8f  push r9
00007ff1409e0a91  push r10
00007ff1409e0a93  push r11
00007ff1409e0a95  sub rsp, 0xF0
00007ff1409e0a9c  vmovaps [rsp], xmm0
00007ff1409e0aa1  vmovaps [rsp+0x10], xmm1
00007ff1409e0aa7  vmovaps [rsp+0x20], xmm2
00007ff1409e0aad  vmovaps [rsp+0x30], xmm3
00007ff1409e0ab3  vmovaps [rsp+0x40], xmm4
00007ff1409e0ab9  vmovaps [rsp+0x50], xmm5
00007ff1409e0abf  vmovaps [rsp+0x60], xmm6
00007ff1409e0ac5  vmovaps [rsp+0x70], xmm8
00007ff1409e0acb  vmovaps [rsp+0x80], xmm9
00007ff1409e0ad4  vmovaps [rsp+0x90], xmm10
00007ff1409e0add  vmovaps [rsp+0xA0], xmm11
00007ff1409e0ae6  vmovaps [rsp+0xB0], xmm12
00007ff1409e0aef  vmovaps [rsp+0xC0], xmm13
00007ff1409e0af8  vmovaps [rsp+0xD0], xmm14
00007ff1409e0b01  vmovaps [rsp+0xE0], xmm15
00007ff1409e0b0a  sub rsp, 0x30
00007ff1409e0b0e  movaps [rsp], xmm7
00007ff1409e0b12  movaps [rsp+0x10], xmm4
00007ff1409e0b17  movaps [rsp+0x20], xmm9
00007ff1409e0b1d  lea rdi, [rsp]
00007ff1409e0b21  mov esi, 0x00
00007ff1409e0b26  mov rax, 0x565C7F10C530
00007ff1409e0b30  call rax
00007ff1409e0b32  movaps xmm7, [rsp]
00007ff1409e0b36  add rsp, 0x30
00007ff1409e0b3a  vmovaps xmm0, [rsp]
00007ff1409e0b3f  vmovaps xmm1, [rsp+0x10]
00007ff1409e0b45  vmovaps xmm2, [rsp+0x20]
00007ff1409e0b4b  vmovaps xmm3, [rsp+0x30]
00007ff1409e0b51  vmovaps xmm4, [rsp+0x40]
00007ff1409e0b57  vmovaps xmm5, [rsp+0x50]
00007ff1409e0b5d  vmovaps xmm6, [rsp+0x60]
00007ff1409e0b63  vmovaps xmm8, [rsp+0x70]
00007ff1409e0b69  vmovaps xmm9, [rsp+0x80]
00007ff1409e0b72  vmovaps xmm10, [rsp+0x90]
00007ff1409e0b7b  vmovaps xmm11, [rsp+0xA0]
00007ff1409e0b84  vmovaps xmm12, [rsp+0xB0]
00007ff1409e0b8d  vmovaps xmm13, [rsp+0xC0]
00007ff1409e0b96  vmovaps xmm14, [rsp+0xD0]
00007ff1409e0b9f  vmovaps xmm15, [rsp+0xE0]
00007ff1409e0ba8  add rsp, 0xF0
00007ff1409e0baf  pop r11
00007ff1409e0bb1  pop r10
00007ff1409e0bb3  pop r9
00007ff1409e0bb5  pop r8
00007ff1409e0bb7  pop rsi
00007ff1409e0bb8  pop rdi
00007ff1409e0bb9  pop rdx
00007ff1409e0bba  pop rcx
00007ff1409e0bbb  pop rax
00007ff1409e0bbc  add rsp, 0x08
00007ff1409e0bc0  jmp 0x00007FF1409DF067
00007ff1409e0bc5  sub rsp, 0x08
00007ff1409e0bc9  push rax
00007ff1409e0bca  push rcx
00007ff1409e0bcb  push rdx
00007ff1409e0bcc  push rdi
00007ff1409e0bcd  push rsi
00007ff1409e0bce  push r8
00007ff1409e0bd0  push r9
00007ff1409e0bd2  push r10
00007ff1409e0bd4  push r11
00007ff1409e0bd6  sub rsp, 0xF0
00007ff1409e0bdd  vmovaps [rsp], xmm0
00007ff1409e0be2  vmovaps [rsp+0x10], xmm1
00007ff1409e0be8  vmovaps [rsp+0x20], xmm2
00007ff1409e0bee  vmovaps [rsp+0x30], xmm3
00007ff1409e0bf4  vmovaps [rsp+0x40], xmm5
00007ff1409e0bfa  vmovaps [rsp+0x50], xmm6
00007ff1409e0c00  vmovaps [rsp+0x60], xmm7
00007ff1409e0c06  vmovaps [rsp+0x70], xmm8
00007ff1409e0c0c  vmovaps [rsp+0x80], xmm9
00007ff1409e0c15  vmovaps [rsp+0x90], xmm10
00007ff1409e0c1e  vmovaps [rsp+0xA0], xmm11
00007ff1409e0c27  vmovaps [rsp+0xB0], xmm12
00007ff1409e0c30  vmovaps [rsp+0xC0], xmm13
00007ff1409e0c39  vmovaps [rsp+0xD0], xmm14
00007ff1409e0c42  vmovaps [rsp+0xE0], xmm15
00007ff1409e0c4b  sub rsp, 0x30
00007ff1409e0c4f  movaps [rsp], xmm4
00007ff1409e0c53  movaps [rsp+0x10], xmm15
00007ff1409e0c59  movaps [rsp+0x20], xmm9
00007ff1409e0c5f  lea rdi, [rsp]
00007ff1409e0c63  mov esi, 0x00
00007ff1409e0c68  mov rax, 0x565C7F10C530
00007ff1409e0c72  call rax
00007ff1409e0c74  movaps xmm4, [rsp]
00007ff1409e0c78  add rsp, 0x30
00007ff1409e0c7c  vmovaps xmm0, [rsp]
00007ff1409e0c81  vmovaps xmm1, [rsp+0x10]
00007ff1409e0c87  vmovaps xmm2, [rsp+0x20]
00007ff1409e0c8d  vmovaps xmm3, [rsp+0x30]
00007ff1409e0c93  vmovaps xmm5, [rsp+0x40]
00007ff1409e0c99  vmovaps xmm6, [rsp+0x50]
00007ff1409e0c9f  vmovaps xmm7, [rsp+0x60]
00007ff1409e0ca5  vmovaps xmm8, [rsp+0x70]
00007ff1409e0cab  vmovaps xmm9, [rsp+0x80]
00007ff1409e0cb4  vmovaps xmm10, [rsp+0x90]
00007ff1409e0cbd  vmovaps xmm11, [rsp+0xA0]
00007ff1409e0cc6  vmovaps xmm12, [rsp+0xB0]
00007ff1409e0ccf  vmovaps xmm13, [rsp+0xC0]
00007ff1409e0cd8  vmovaps xmm14, [rsp+0xD0]
00007ff1409e0ce1  vmovaps xmm15, [rsp+0xE0]
00007ff1409e0cea  add rsp, 0xF0
00007ff1409e0cf1  pop r11
00007ff1409e0cf3  pop r10
00007ff1409e0cf5  pop r9
00007ff1409e0cf7  pop r8
00007ff1409e0cf9  pop rsi
00007ff1409e0cfa  pop rdi
00007ff1409e0cfb  pop rdx
00007ff1409e0cfc  pop rcx
00007ff1409e0cfd  pop rax
00007ff1409e0cfe  add rsp, 0x08
00007ff1409e0d02  jmp 0x00007FF1409DF08C
00007ff1409e0d07  call 0x00007FF1408C4620
00007ff1409e0d0c  jmp 0x00007FF1409DF099
00007ff1409e0d11  sub rsp, 0x08
00007ff1409e0d15  push rax
00007ff1409e0d16  push rcx
00007ff1409e0d17  push rdx
00007ff1409e0d18  push rdi
00007ff1409e0d19  push rsi
00007ff1409e0d1a  push r8
00007ff1409e0d1c  push r9
00007ff1409e0d1e  push r10
00007ff1409e0d20  push r11
00007ff1409e0d22  sub rsp, 0xF0
00007ff1409e0d29  vmovaps [rsp], xmm0
00007ff1409e0d2e  vmovaps [rsp+0x10], xmm1
00007ff1409e0d34  vmovaps [rsp+0x20], xmm2
00007ff1409e0d3a  vmovaps [rsp+0x30], xmm4
00007ff1409e0d40  vmovaps [rsp+0x40], xmm5
00007ff1409e0d46  vmovaps [rsp+0x50], xmm6
00007ff1409e0d4c  vmovaps [rsp+0x60], xmm7
00007ff1409e0d52  vmovaps [rsp+0x70], xmm8
00007ff1409e0d58  vmovaps [rsp+0x80], xmm9
00007ff1409e0d61  vmovaps [rsp+0x90], xmm10
00007ff1409e0d6a  vmovaps [rsp+0xA0], xmm11
00007ff1409e0d73  vmovaps [rsp+0xB0], xmm12
00007ff1409e0d7c  vmovaps [rsp+0xC0], xmm13
00007ff1409e0d85  vmovaps [rsp+0xD0], xmm14
00007ff1409e0d8e  vmovaps [rsp+0xE0], xmm15
00007ff1409e0d97  sub rsp, 0x30
00007ff1409e0d9b  movaps [rsp], xmm3
00007ff1409e0d9f  movaps [rsp+0x10], xmm1
00007ff1409e0da4  movaps [rsp+0x20], xmm9
00007ff1409e0daa  lea rdi, [rsp]
00007ff1409e0dae  mov esi, 0x00
00007ff1409e0db3  mov rax, 0x565C7F10C530
00007ff1409e0dbd  call rax
00007ff1409e0dbf  movaps xmm3, [rsp]
00007ff1409e0dc3  add rsp, 0x30
00007ff1409e0dc7  vmovaps xmm0, [rsp]
00007ff1409e0dcc  vmovaps xmm1, [rsp+0x10]
00007ff1409e0dd2  vmovaps xmm2, [rsp+0x20]
00007ff1409e0dd8  vmovaps xmm4, [rsp+0x30]
00007ff1409e0dde  vmovaps xmm5, [rsp+0x40]
00007ff1409e0de4  vmovaps xmm6, [rsp+0x50]
00007ff1409e0dea  vmovaps xmm7, [rsp+0x60]
00007ff1409e0df0  vmovaps xmm8, [rsp+0x70]
00007ff1409e0df6  vmovaps xmm9, [rsp+0x80]
00007ff1409e0dff  vmovaps xmm10, [rsp+0x90]
00007ff1409e0e08  vmovaps xmm11, [rsp+0xA0]
00007ff1409e0e11  vmovaps xmm12, [rsp+0xB0]
00007ff1409e0e1a  vmovaps xmm13, [rsp+0xC0]
00007ff1409e0e23  vmovaps xmm14, [rsp+0xD0]
00007ff1409e0e2c  vmovaps xmm15, [rsp+0xE0]
00007ff1409e0e35  add rsp, 0xF0
00007ff1409e0e3c  pop r11
00007ff1409e0e3e  pop r10
00007ff1409e0e40  pop r9
00007ff1409e0e42  pop r8
00007ff1409e0e44  pop rsi
00007ff1409e0e45  pop rdi
00007ff1409e0e46  pop rdx
00007ff1409e0e47  pop rcx
00007ff1409e0e48  pop rax
00007ff1409e0e49  add rsp, 0x08
00007ff1409e0e4d  jmp 0x00007FF1409DF0D6
00007ff1409e0e52  sub rsp, 0x08
00007ff1409e0e56  push rax
00007ff1409e0e57  push rcx
00007ff1409e0e58  push rdx
00007ff1409e0e59  push rdi
00007ff1409e0e5a  push rsi
00007ff1409e0e5b  push r8
00007ff1409e0e5d  push r9
00007ff1409e0e5f  push r10
00007ff1409e0e61  push r11
00007ff1409e0e63  sub rsp, 0xF0
00007ff1409e0e6a  vmovaps [rsp], xmm0
00007ff1409e0e6f  vmovaps [rsp+0x10], xmm2
00007ff1409e0e75  vmovaps [rsp+0x20], xmm3
00007ff1409e0e7b  vmovaps [rsp+0x30], xmm4
00007ff1409e0e81  vmovaps [rsp+0x40], xmm5
00007ff1409e0e87  vmovaps [rsp+0x50], xmm6
00007ff1409e0e8d  vmovaps [rsp+0x60], xmm7
00007ff1409e0e93  vmovaps [rsp+0x70], xmm8
00007ff1409e0e99  vmovaps [rsp+0x80], xmm9
00007ff1409e0ea2  vmovaps [rsp+0x90], xmm10
00007ff1409e0eab  vmovaps [rsp+0xA0], xmm11
00007ff1409e0eb4  vmovaps [rsp+0xB0], xmm12
00007ff1409e0ebd  vmovaps [rsp+0xC0], xmm13
00007ff1409e0ec6  vmovaps [rsp+0xD0], xmm14
00007ff1409e0ecf  vmovaps [rsp+0xE0], xmm15
00007ff1409e0ed8  sub rsp, 0x30
00007ff1409e0edc  movaps [rsp], xmm1
00007ff1409e0ee0  movaps [rsp+0x10], xmm15
00007ff1409e0ee6  movaps [rsp+0x20], xmm9
00007ff1409e0eec  lea rdi, [rsp]
00007ff1409e0ef0  mov esi, 0x00
00007ff1409e0ef5  mov rax, 0x565C7F10C530
00007ff1409e0eff  call rax
00007ff1409e0f01  movaps xmm1, [rsp]
00007ff1409e0f05  add rsp, 0x30
00007ff1409e0f09  vmovaps xmm0, [rsp]
00007ff1409e0f0e  vmovaps xmm2, [rsp+0x10]
00007ff1409e0f14  vmovaps xmm3, [rsp+0x20]
00007ff1409e0f1a  vmovaps xmm4, [rsp+0x30]
00007ff1409e0f20  vmovaps xmm5, [rsp+0x40]
00007ff1409e0f26  vmovaps xmm6, [rsp+0x50]
00007ff1409e0f2c  vmovaps xmm7, [rsp+0x60]
00007ff1409e0f32  vmovaps xmm8, [rsp+0x70]
00007ff1409e0f38  vmovaps xmm9, [rsp+0x80]
00007ff1409e0f41  vmovaps xmm10, [rsp+0x90]
00007ff1409e0f4a  vmovaps xmm11, [rsp+0xA0]
00007ff1409e0f53  vmovaps xmm12, [rsp+0xB0]
00007ff1409e0f5c  vmovaps xmm13, [rsp+0xC0]
00007ff1409e0f65  vmovaps xmm14, [rsp+0xD0]
00007ff1409e0f6e  vmovaps xmm15, [rsp+0xE0]
00007ff1409e0f77  add rsp, 0xF0
00007ff1409e0f7e  pop r11
00007ff1409e0f80  pop r10
00007ff1409e0f82  pop r9
00007ff1409e0f84  pop r8
00007ff1409e0f86  pop rsi
00007ff1409e0f87  pop rdi
00007ff1409e0f88  pop rdx
00007ff1409e0f89  pop rcx
00007ff1409e0f8a  pop rax
00007ff1409e0f8b  add rsp, 0x08
00007ff1409e0f8f  jmp 0x00007FF1409DF15E
00007ff1409e0f94  call 0x00007FF1408C4620
00007ff1409e0f99  jmp 0x00007FF1409DF16B
00007ff1409e0f9e  sub rsp, 0x08
00007ff1409e0fa2  push rax
00007ff1409e0fa3  push rcx
00007ff1409e0fa4  push rdx
00007ff1409e0fa5  push rdi
00007ff1409e0fa6  push rsi
00007ff1409e0fa7  push r8
00007ff1409e0fa9  push r9
00007ff1409e0fab  push r10
00007ff1409e0fad  push r11
00007ff1409e0faf  sub rsp, 0xF0
00007ff1409e0fb6  vmovaps [rsp], xmm0
00007ff1409e0fbb  vmovaps [rsp+0x10], xmm2
00007ff1409e0fc1  vmovaps [rsp+0x20], xmm3
00007ff1409e0fc7  vmovaps [rsp+0x30], xmm4
00007ff1409e0fcd  vmovaps [rsp+0x40], xmm5
00007ff1409e0fd3  vmovaps [rsp+0x50], xmm6
00007ff1409e0fd9  vmovaps [rsp+0x60], xmm7
00007ff1409e0fdf  vmovaps [rsp+0x70], xmm8
00007ff1409e0fe5  vmovaps [rsp+0x80], xmm9
00007ff1409e0fee  vmovaps [rsp+0x90], xmm10
00007ff1409e0ff7  vmovaps [rsp+0xA0], xmm11
00007ff1409e1000  vmovaps [rsp+0xB0], xmm12
00007ff1409e1009  vmovaps [rsp+0xC0], xmm13
00007ff1409e1012  vmovaps [rsp+0xD0], xmm14
00007ff1409e101b  vmovaps [rsp+0xE0], xmm15
00007ff1409e1024  sub rsp, 0x30
00007ff1409e1028  movaps [rsp], xmm1
00007ff1409e102c  movaps [rsp+0x10], xmm5
00007ff1409e1031  movaps [rsp+0x20], xmm7
00007ff1409e1036  lea rdi, [rsp]
00007ff1409e103a  mov esi, 0x00
00007ff1409e103f  mov rax, 0x565C7F10C530
00007ff1409e1049  call rax
00007ff1409e104b  movaps xmm1, [rsp]
00007ff1409e104f  add rsp, 0x30
00007ff1409e1053  vmovaps xmm0, [rsp]
00007ff1409e1058  vmovaps xmm2, [rsp+0x10]
00007ff1409e105e  vmovaps xmm3, [rsp+0x20]
00007ff1409e1064  vmovaps xmm4, [rsp+0x30]
00007ff1409e106a  vmovaps xmm5, [rsp+0x40]
00007ff1409e1070  vmovaps xmm6, [rsp+0x50]
00007ff1409e1076  vmovaps xmm7, [rsp+0x60]
00007ff1409e107c  vmovaps xmm8, [rsp+0x70]
00007ff1409e1082  vmovaps xmm9, [rsp+0x80]
00007ff1409e108b  vmovaps xmm10, [rsp+0x90]
00007ff1409e1094  vmovaps xmm11, [rsp+0xA0]
00007ff1409e109d  vmovaps xmm12, [rsp+0xB0]
00007ff1409e10a6  vmovaps xmm13, [rsp+0xC0]
00007ff1409e10af  vmovaps xmm14, [rsp+0xD0]
00007ff1409e10b8  vmovaps xmm15, [rsp+0xE0]
00007ff1409e10c1  add rsp, 0xF0
00007ff1409e10c8  pop r11
00007ff1409e10ca  pop r10
00007ff1409e10cc  pop r9
00007ff1409e10ce  pop r8
00007ff1409e10d0  pop rsi
00007ff1409e10d1  pop rdi
00007ff1409e10d2  pop rdx
00007ff1409e10d3  pop rcx
00007ff1409e10d4  pop rax
00007ff1409e10d5  add rsp, 0x08
00007ff1409e10d9  jmp 0x00007FF1409DF210
00007ff1409e10de  sub rsp, 0x08
00007ff1409e10e2  push rax
00007ff1409e10e3  push rcx
00007ff1409e10e4  push rdx
00007ff1409e10e5  push rdi
00007ff1409e10e6  push rsi
00007ff1409e10e7  push r8
00007ff1409e10e9  push r9
00007ff1409e10eb  push r10
00007ff1409e10ed  push r11
00007ff1409e10ef  sub rsp, 0xF0
00007ff1409e10f6  vmovaps [rsp], xmm0
00007ff1409e10fb  vmovaps [rsp+0x10], xmm1
00007ff1409e1101  vmovaps [rsp+0x20], xmm2
00007ff1409e1107  vmovaps [rsp+0x30], xmm3
00007ff1409e110d  vmovaps [rsp+0x40], xmm4
00007ff1409e1113  vmovaps [rsp+0x50], xmm5
00007ff1409e1119  vmovaps [rsp+0x60], xmm6
00007ff1409e111f  vmovaps [rsp+0x70], xmm8
00007ff1409e1125  vmovaps [rsp+0x80], xmm9
00007ff1409e112e  vmovaps [rsp+0x90], xmm10
00007ff1409e1137  vmovaps [rsp+0xA0], xmm11
00007ff1409e1140  vmovaps [rsp+0xB0], xmm12
00007ff1409e1149  vmovaps [rsp+0xC0], xmm13
00007ff1409e1152  vmovaps [rsp+0xD0], xmm14
00007ff1409e115b  vmovaps [rsp+0xE0], xmm15
00007ff1409e1164  sub rsp, 0x30
00007ff1409e1168  movaps [rsp], xmm7
00007ff1409e116c  movaps [rsp+0x10], xmm5
00007ff1409e1171  movaps [rsp+0x20], xmm15
00007ff1409e1177  lea rdi, [rsp]
00007ff1409e117b  mov esi, 0x00
00007ff1409e1180  mov rax, 0x565C7F10C530
00007ff1409e118a  call rax
00007ff1409e118c  movaps xmm7, [rsp]
00007ff1409e1190  add rsp, 0x30
00007ff1409e1194  vmovaps xmm0, [rsp]
00007ff1409e1199  vmovaps xmm1, [rsp+0x10]
00007ff1409e119f  vmovaps xmm2, [rsp+0x20]
00007ff1409e11a5  vmovaps xmm3, [rsp+0x30]
00007ff1409e11ab  vmovaps xmm4, [rsp+0x40]
00007ff1409e11b1  vmovaps xmm5, [rsp+0x50]
00007ff1409e11b7  vmovaps xmm6, [rsp+0x60]
00007ff1409e11bd  vmovaps xmm8, [rsp+0x70]
00007ff1409e11c3  vmovaps xmm9, [rsp+0x80]
00007ff1409e11cc  vmovaps xmm10, [rsp+0x90]
00007ff1409e11d5  vmovaps xmm11, [rsp+0xA0]
00007ff1409e11de  vmovaps xmm12, [rsp+0xB0]
00007ff1409e11e7  vmovaps xmm13, [rsp+0xC0]
00007ff1409e11f0  vmovaps xmm14, [rsp+0xD0]
00007ff1409e11f9  vmovaps xmm15, [rsp+0xE0]
00007ff1409e1202  add rsp, 0xF0
00007ff1409e1209  pop r11
00007ff1409e120b  pop r10
00007ff1409e120d  pop r9
00007ff1409e120f  pop r8
00007ff1409e1211  pop rsi
00007ff1409e1212  pop rdi
00007ff1409e1213  pop rdx
00007ff1409e1214  pop rcx
00007ff1409e1215  pop rax
00007ff1409e1216  add rsp, 0x08
00007ff1409e121a  jmp 0x00007FF1409DF246
00007ff1409e121f  call 0x00007FF1408B52F0
00007ff1409e1224  jmp 0x00007FF1409DF253
00007ff1409e1229  sub rsp, 0x08
00007ff1409e122d  push rax
00007ff1409e122e  push rcx
00007ff1409e122f  push rdx
00007ff1409e1230  push rdi
00007ff1409e1231  push rsi
00007ff1409e1232  push r8
00007ff1409e1234  push r9
00007ff1409e1236  push r10
00007ff1409e1238  push r11
00007ff1409e123a  sub rsp, 0xF0
00007ff1409e1241  vmovaps [rsp], xmm0
00007ff1409e1246  vmovaps [rsp+0x10], xmm1
00007ff1409e124c  vmovaps [rsp+0x20], xmm2
00007ff1409e1252  vmovaps [rsp+0x30], xmm3
00007ff1409e1258  vmovaps [rsp+0x40], xmm4
00007ff1409e125e  vmovaps [rsp+0x50], xmm5
00007ff1409e1264  vmovaps [rsp+0x60], xmm6
00007ff1409e126a  vmovaps [rsp+0x70], xmm7
00007ff1409e1270  vmovaps [rsp+0x80], xmm8
00007ff1409e1279  vmovaps [rsp+0x90], xmm9
00007ff1409e1282  vmovaps [rsp+0xA0], xmm10
00007ff1409e128b  vmovaps [rsp+0xB0], xmm11
00007ff1409e1294  vmovaps [rsp+0xC0], xmm12
00007ff1409e129d  vmovaps [rsp+0xD0], xmm13
00007ff1409e12a6  vmovaps [rsp+0xE0], xmm14
00007ff1409e12af  sub rsp, 0x30
00007ff1409e12b3  movaps [rsp], xmm15
00007ff1409e12b8  movaps [rsp+0x10], xmm5
00007ff1409e12bd  movaps [rsp+0x20], xmm3
00007ff1409e12c2  lea rdi, [rsp]
00007ff1409e12c6  mov esi, 0x00
00007ff1409e12cb  mov rax, 0x565C7F10C530
00007ff1409e12d5  call rax
00007ff1409e12d7  movaps xmm15, [rsp]
00007ff1409e12dc  add rsp, 0x30
00007ff1409e12e0  vmovaps xmm0, [rsp]
00007ff1409e12e5  vmovaps xmm1, [rsp+0x10]
00007ff1409e12eb  vmovaps xmm2, [rsp+0x20]
00007ff1409e12f1  vmovaps xmm3, [rsp+0x30]
00007ff1409e12f7  vmovaps xmm4, [rsp+0x40]
00007ff1409e12fd  vmovaps xmm5, [rsp+0x50]
00007ff1409e1303  vmovaps xmm6, [rsp+0x60]
00007ff1409e1309  vmovaps xmm7, [rsp+0x70]
00007ff1409e130f  vmovaps xmm8, [rsp+0x80]
00007ff1409e1318  vmovaps xmm9, [rsp+0x90]
00007ff1409e1321  vmovaps xmm10, [rsp+0xA0]
00007ff1409e132a  vmovaps xmm11, [rsp+0xB0]
00007ff1409e1333  vmovaps xmm12, [rsp+0xC0]
00007ff1409e133c  vmovaps xmm13, [rsp+0xD0]
00007ff1409e1345  vmovaps xmm14, [rsp+0xE0]
00007ff1409e134e  add rsp, 0xF0
00007ff1409e1355  pop r11
00007ff1409e1357  pop r10
00007ff1409e1359  pop r9
00007ff1409e135b  pop r8
00007ff1409e135d  pop rsi
00007ff1409e135e  pop rdi
00007ff1409e135f  pop rdx
00007ff1409e1360  pop rcx
00007ff1409e1361  pop rax
00007ff1409e1362  add rsp, 0x08
00007ff1409e1366  jmp 0x00007FF1409DF279
00007ff1409e136b  sub rsp, 0x08
00007ff1409e136f  push rax
00007ff1409e1370  push rcx
00007ff1409e1371  push rdx
00007ff1409e1372  push rdi
00007ff1409e1373  push rsi
00007ff1409e1374  push r8
00007ff1409e1376  push r9
00007ff1409e1378  push r10
00007ff1409e137a  push r11
00007ff1409e137c  sub rsp, 0xF0
00007ff1409e1383  vmovaps [rsp], xmm0
00007ff1409e1388  vmovaps [rsp+0x10], xmm2
00007ff1409e138e  vmovaps [rsp+0x20], xmm3
00007ff1409e1394  vmovaps [rsp+0x30], xmm4
00007ff1409e139a  vmovaps [rsp+0x40], xmm5
00007ff1409e13a0  vmovaps [rsp+0x50], xmm6
00007ff1409e13a6  vmovaps [rsp+0x60], xmm7
00007ff1409e13ac  vmovaps [rsp+0x70], xmm8
00007ff1409e13b2  vmovaps [rsp+0x80], xmm9
00007ff1409e13bb  vmovaps [rsp+0x90], xmm10
00007ff1409e13c4  vmovaps [rsp+0xA0], xmm11
00007ff1409e13cd  vmovaps [rsp+0xB0], xmm12
00007ff1409e13d6  vmovaps [rsp+0xC0], xmm13
00007ff1409e13df  vmovaps [rsp+0xD0], xmm14
00007ff1409e13e8  vmovaps [rsp+0xE0], xmm15
00007ff1409e13f1  sub rsp, 0x30
00007ff1409e13f5  movaps [rsp], xmm1
00007ff1409e13f9  movaps [rsp+0x10], xmm5
00007ff1409e13fe  movaps [rsp+0x20], xmm4
00007ff1409e1403  lea rdi, [rsp]
00007ff1409e1407  mov esi, 0x00
00007ff1409e140c  mov rax, 0x565C7F10C530
00007ff1409e1416  call rax
00007ff1409e1418  movaps xmm1, [rsp]
00007ff1409e141c  add rsp, 0x30
00007ff1409e1420  vmovaps xmm0, [rsp]
00007ff1409e1425  vmovaps xmm2, [rsp+0x10]
00007ff1409e142b  vmovaps xmm3, [rsp+0x20]
00007ff1409e1431  vmovaps xmm4, [rsp+0x30]
00007ff1409e1437  vmovaps xmm5, [rsp+0x40]
00007ff1409e143d  vmovaps xmm6, [rsp+0x50]
00007ff1409e1443  vmovaps xmm7, [rsp+0x60]
00007ff1409e1449  vmovaps xmm8, [rsp+0x70]
00007ff1409e144f  vmovaps xmm9, [rsp+0x80]
00007ff1409e1458  vmovaps xmm10, [rsp+0x90]
00007ff1409e1461  vmovaps xmm11, [rsp+0xA0]
00007ff1409e146a  vmovaps xmm12, [rsp+0xB0]
00007ff1409e1473  vmovaps xmm13, [rsp+0xC0]
00007ff1409e147c  vmovaps xmm14, [rsp+0xD0]
00007ff1409e1485  vmovaps xmm15, [rsp+0xE0]
00007ff1409e148e  add rsp, 0xF0
00007ff1409e1495  pop r11
00007ff1409e1497  pop r10
00007ff1409e1499  pop r9
00007ff1409e149b  pop r8
00007ff1409e149d  pop rsi
00007ff1409e149e  pop rdi
00007ff1409e149f  pop rdx
00007ff1409e14a0  pop rcx
00007ff1409e14a1  pop rax
00007ff1409e14a2  add rsp, 0x08
00007ff1409e14a6  jmp 0x00007FF1409DF299
00007ff1409e14ab  sub rsp, 0x08
00007ff1409e14af  push rax
00007ff1409e14b0  push rcx
00007ff1409e14b1  push rdx
00007ff1409e14b2  push rdi
00007ff1409e14b3  push rsi
00007ff1409e14b4  push r8
00007ff1409e14b6  push r9
00007ff1409e14b8  push r10
00007ff1409e14ba  push r11
00007ff1409e14bc  sub rsp, 0xF0
00007ff1409e14c3  vmovaps [rsp], xmm0
00007ff1409e14c8  vmovaps [rsp+0x10], xmm1
00007ff1409e14ce  vmovaps [rsp+0x20], xmm2
00007ff1409e14d4  vmovaps [rsp+0x30], xmm3
00007ff1409e14da  vmovaps [rsp+0x40], xmm5
00007ff1409e14e0  vmovaps [rsp+0x50], xmm6
00007ff1409e14e6  vmovaps [rsp+0x60], xmm7
00007ff1409e14ec  vmovaps [rsp+0x70], xmm8
00007ff1409e14f2  vmovaps [rsp+0x80], xmm9
00007ff1409e14fb  vmovaps [rsp+0x90], xmm10
00007ff1409e1504  vmovaps [rsp+0xA0], xmm11
00007ff1409e150d  vmovaps [rsp+0xB0], xmm12
00007ff1409e1516  vmovaps [rsp+0xC0], xmm13
00007ff1409e151f  vmovaps [rsp+0xD0], xmm14
00007ff1409e1528  vmovaps [rsp+0xE0], xmm15
00007ff1409e1531  sub rsp, 0x30
00007ff1409e1535  movaps [rsp], xmm4
00007ff1409e1539  movaps [rsp+0x10], xmm3
00007ff1409e153e  movaps [rsp+0x20], xmm5
00007ff1409e1543  lea rdi, [rsp]
00007ff1409e1547  mov esi, 0x00
00007ff1409e154c  mov rax, 0x565C7F10C530
00007ff1409e1556  call rax
00007ff1409e1558  movaps xmm4, [rsp]
00007ff1409e155c  add rsp, 0x30
00007ff1409e1560  vmovaps xmm0, [rsp]
00007ff1409e1565  vmovaps xmm1, [rsp+0x10]
00007ff1409e156b  vmovaps xmm2, [rsp+0x20]
00007ff1409e1571  vmovaps xmm3, [rsp+0x30]
00007ff1409e1577  vmovaps xmm5, [rsp+0x40]
00007ff1409e157d  vmovaps xmm6, [rsp+0x50]
00007ff1409e1583  vmovaps xmm7, [rsp+0x60]
00007ff1409e1589  vmovaps xmm8, [rsp+0x70]
00007ff1409e158f  vmovaps xmm9, [rsp+0x80]
00007ff1409e1598  vmovaps xmm10, [rsp+0x90]
00007ff1409e15a1  vmovaps xmm11, [rsp+0xA0]
00007ff1409e15aa  vmovaps xmm12, [rsp+0xB0]
00007ff1409e15b3  vmovaps xmm13, [rsp+0xC0]
00007ff1409e15bc  vmovaps xmm14, [rsp+0xD0]
00007ff1409e15c5  vmovaps xmm15, [rsp+0xE0]
00007ff1409e15ce  add rsp, 0xF0
00007ff1409e15d5  pop r11
00007ff1409e15d7  pop r10
00007ff1409e15d9  pop r9
00007ff1409e15db  pop r8
00007ff1409e15dd  pop rsi
00007ff1409e15de  pop rdi
00007ff1409e15df  pop rdx
00007ff1409e15e0  pop rcx
00007ff1409e15e1  pop rax
00007ff1409e15e2  add rsp, 0x08
00007ff1409e15e6  jmp 0x00007FF1409DF2E7
00007ff1409e15eb  call 0x00007FF1408B52F0
00007ff1409e15f0  jmp 0x00007FF1409DF2F4
00007ff1409e15f5  sub rsp, 0x08
00007ff1409e15f9  push rax
00007ff1409e15fa  push rcx
00007ff1409e15fb  push rdx
00007ff1409e15fc  push rdi
00007ff1409e15fd  push rsi
00007ff1409e15fe  push r8
00007ff1409e1600  push r9
00007ff1409e1602  push r10
00007ff1409e1604  push r11
00007ff1409e1606  sub rsp, 0xF0
00007ff1409e160d  vmovaps [rsp], xmm0
00007ff1409e1612  vmovaps [rsp+0x10], xmm1
00007ff1409e1618  vmovaps [rsp+0x20], xmm2
00007ff1409e161e  vmovaps [rsp+0x30], xmm3
00007ff1409e1624  vmovaps [rsp+0x40], xmm4
00007ff1409e162a  vmovaps [rsp+0x50], xmm6
00007ff1409e1630  vmovaps [rsp+0x60], xmm7
00007ff1409e1636  vmovaps [rsp+0x70], xmm8
00007ff1409e163c  vmovaps [rsp+0x80], xmm9
00007ff1409e1645  vmovaps [rsp+0x90], xmm10
00007ff1409e164e  vmovaps [rsp+0xA0], xmm11
00007ff1409e1657  vmovaps [rsp+0xB0], xmm12
00007ff1409e1660  vmovaps [rsp+0xC0], xmm13
00007ff1409e1669  vmovaps [rsp+0xD0], xmm14
00007ff1409e1672  vmovaps [rsp+0xE0], xmm15
00007ff1409e167b  sub rsp, 0x30
00007ff1409e167f  movaps [rsp], xmm5
00007ff1409e1683  movaps [rsp+0x10], xmm6
00007ff1409e1688  movaps [rsp+0x20], xmm3
00007ff1409e168d  lea rdi, [rsp]
00007ff1409e1691  mov esi, 0x00
00007ff1409e1696  mov rax, 0x565C7F10C530
00007ff1409e16a0  call rax
00007ff1409e16a2  movaps xmm5, [rsp]
00007ff1409e16a6  add rsp, 0x30
00007ff1409e16aa  vmovaps xmm0, [rsp]
00007ff1409e16af  vmovaps xmm1, [rsp+0x10]
00007ff1409e16b5  vmovaps xmm2, [rsp+0x20]
00007ff1409e16bb  vmovaps xmm3, [rsp+0x30]
00007ff1409e16c1  vmovaps xmm4, [rsp+0x40]
00007ff1409e16c7  vmovaps xmm6, [rsp+0x50]
00007ff1409e16cd  vmovaps xmm7, [rsp+0x60]
00007ff1409e16d3  vmovaps xmm8, [rsp+0x70]
00007ff1409e16d9  vmovaps xmm9, [rsp+0x80]
00007ff1409e16e2  vmovaps xmm10, [rsp+0x90]
00007ff1409e16eb  vmovaps xmm11, [rsp+0xA0]
00007ff1409e16f4  vmovaps xmm12, [rsp+0xB0]
00007ff1409e16fd  vmovaps xmm13, [rsp+0xC0]
00007ff1409e1706  vmovaps xmm14, [rsp+0xD0]
00007ff1409e170f  vmovaps xmm15, [rsp+0xE0]
00007ff1409e1718  add rsp, 0xF0
00007ff1409e171f  pop r11
00007ff1409e1721  pop r10
00007ff1409e1723  pop r9
00007ff1409e1725  pop r8
00007ff1409e1727  pop rsi
00007ff1409e1728  pop rdi
00007ff1409e1729  pop rdx
00007ff1409e172a  pop rcx
00007ff1409e172b  pop rax
00007ff1409e172c  add rsp, 0x08
00007ff1409e1730  jmp 0x00007FF1409DF31A
00007ff1409e1735  sub rsp, 0x08
00007ff1409e1739  push rax
00007ff1409e173a  push rcx
00007ff1409e173b  push rdx
00007ff1409e173c  push rdi
00007ff1409e173d  push rsi
00007ff1409e173e  push r8
00007ff1409e1740  push r9
00007ff1409e1742  push r10
00007ff1409e1744  push r11
00007ff1409e1746  sub rsp, 0xF0
00007ff1409e174d  vmovaps [rsp], xmm0
00007ff1409e1752  vmovaps [rsp+0x10], xmm1
00007ff1409e1758  vmovaps [rsp+0x20], xmm2
00007ff1409e175e  vmovaps [rsp+0x30], xmm3
00007ff1409e1764  vmovaps [rsp+0x40], xmm4
00007ff1409e176a  vmovaps [rsp+0x50], xmm5
00007ff1409e1770  vmovaps [rsp+0x60], xmm7
00007ff1409e1776  vmovaps [rsp+0x70], xmm8
00007ff1409e177c  vmovaps [rsp+0x80], xmm9
00007ff1409e1785  vmovaps [rsp+0x90], xmm10
00007ff1409e178e  vmovaps [rsp+0xA0], xmm11
00007ff1409e1797  vmovaps [rsp+0xB0], xmm12
00007ff1409e17a0  vmovaps [rsp+0xC0], xmm13
00007ff1409e17a9  vmovaps [rsp+0xD0], xmm14
00007ff1409e17b2  vmovaps [rsp+0xE0], xmm15
00007ff1409e17bb  sub rsp, 0x30
00007ff1409e17bf  movaps [rsp], xmm6
00007ff1409e17c3  movaps [rsp+0x10], xmm9
00007ff1409e17c9  movaps [rsp+0x20], xmm1
00007ff1409e17ce  lea rdi, [rsp]
00007ff1409e17d2  mov esi, 0x00
00007ff1409e17d7  mov rax, 0x565C7F10C530
00007ff1409e17e1  call rax
00007ff1409e17e3  movaps xmm6, [rsp]
00007ff1409e17e7  add rsp, 0x30
00007ff1409e17eb  vmovaps xmm0, [rsp]
00007ff1409e17f0  vmovaps xmm1, [rsp+0x10]
00007ff1409e17f6  vmovaps xmm2, [rsp+0x20]
00007ff1409e17fc  vmovaps xmm3, [rsp+0x30]
00007ff1409e1802  vmovaps xmm4, [rsp+0x40]
00007ff1409e1808  vmovaps xmm5, [rsp+0x50]
00007ff1409e180e  vmovaps xmm7, [rsp+0x60]
00007ff1409e1814  vmovaps xmm8, [rsp+0x70]
00007ff1409e181a  vmovaps xmm9, [rsp+0x80]
00007ff1409e1823  vmovaps xmm10, [rsp+0x90]
00007ff1409e182c  vmovaps xmm11, [rsp+0xA0]
00007ff1409e1835  vmovaps xmm12, [rsp+0xB0]
00007ff1409e183e  vmovaps xmm13, [rsp+0xC0]
00007ff1409e1847  vmovaps xmm14, [rsp+0xD0]
00007ff1409e1850  vmovaps xmm15, [rsp+0xE0]
00007ff1409e1859  add rsp, 0xF0
00007ff1409e1860  pop r11
00007ff1409e1862  pop r10
00007ff1409e1864  pop r9
00007ff1409e1866  pop r8
00007ff1409e1868  pop rsi
00007ff1409e1869  pop rdi
00007ff1409e186a  pop rdx
00007ff1409e186b  pop rcx
00007ff1409e186c  pop rax
00007ff1409e186d  add rsp, 0x08
00007ff1409e1871  jmp 0x00007FF1409DF33E
00007ff1409e1876  sub rsp, 0x08
00007ff1409e187a  push rax
00007ff1409e187b  push rcx
00007ff1409e187c  push rdx
00007ff1409e187d  push rdi
00007ff1409e187e  push rsi
00007ff1409e187f  push r8
00007ff1409e1881  push r9
00007ff1409e1883  push r10
00007ff1409e1885  push r11
00007ff1409e1887  sub rsp, 0xF0
00007ff1409e188e  vmovaps [rsp], xmm0
00007ff1409e1893  vmovaps [rsp+0x10], xmm1
00007ff1409e1899  vmovaps [rsp+0x20], xmm2
00007ff1409e189f  vmovaps [rsp+0x30], xmm3
00007ff1409e18a5  vmovaps [rsp+0x40], xmm4
00007ff1409e18ab  vmovaps [rsp+0x50], xmm5
00007ff1409e18b1  vmovaps [rsp+0x60], xmm6
00007ff1409e18b7  vmovaps [rsp+0x70], xmm7
00007ff1409e18bd  vmovaps [rsp+0x80], xmm8
00007ff1409e18c6  vmovaps [rsp+0x90], xmm10
00007ff1409e18cf  vmovaps [rsp+0xA0], xmm11
00007ff1409e18d8  vmovaps [rsp+0xB0], xmm12
00007ff1409e18e1  vmovaps [rsp+0xC0], xmm13
00007ff1409e18ea  vmovaps [rsp+0xD0], xmm14
00007ff1409e18f3  vmovaps [rsp+0xE0], xmm15
00007ff1409e18fc  sub rsp, 0x30
00007ff1409e1900  movaps [rsp], xmm9
00007ff1409e1905  movaps [rsp+0x10], xmm3
00007ff1409e190a  movaps [rsp+0x20], xmm1
00007ff1409e190f  lea rdi, [rsp]
00007ff1409e1913  mov esi, 0x00
00007ff1409e1918  mov rax, 0x565C7F10C530
00007ff1409e1922  call rax
00007ff1409e1924  movaps xmm9, [rsp]
00007ff1409e1929  add rsp, 0x30
00007ff1409e192d  vmovaps xmm0, [rsp]
00007ff1409e1932  vmovaps xmm1, [rsp+0x10]
00007ff1409e1938  vmovaps xmm2, [rsp+0x20]
00007ff1409e193e  vmovaps xmm3, [rsp+0x30]
00007ff1409e1944  vmovaps xmm4, [rsp+0x40]
00007ff1409e194a  vmovaps xmm5, [rsp+0x50]
00007ff1409e1950  vmovaps xmm6, [rsp+0x60]
00007ff1409e1956  vmovaps xmm7, [rsp+0x70]
00007ff1409e195c  vmovaps xmm8, [rsp+0x80]
00007ff1409e1965  vmovaps xmm10, [rsp+0x90]
00007ff1409e196e  vmovaps xmm11, [rsp+0xA0]
00007ff1409e1977  vmovaps xmm12, [rsp+0xB0]
00007ff1409e1980  vmovaps xmm13, [rsp+0xC0]
00007ff1409e1989  vmovaps xmm14, [rsp+0xD0]
00007ff1409e1992  vmovaps xmm15, [rsp+0xE0]
00007ff1409e199b  add rsp, 0xF0
00007ff1409e19a2  pop r11
00007ff1409e19a4  pop r10
00007ff1409e19a6  pop r9
00007ff1409e19a8  pop r8
00007ff1409e19aa  pop rsi
00007ff1409e19ab  pop rdi
00007ff1409e19ac  pop rdx
00007ff1409e19ad  pop rcx
00007ff1409e19ae  pop rax
00007ff1409e19af  add rsp, 0x08
00007ff1409e19b3  jmp 0x00007FF1409DF38A
00007ff1409e19b8  call 0x00007FF1408B52F0
00007ff1409e19bd  jmp 0x00007FF1409DF397
00007ff1409e19c2  sub rsp, 0x08
00007ff1409e19c6  push rax
00007ff1409e19c7  push rcx
00007ff1409e19c8  push rdx
00007ff1409e19c9  push rdi
00007ff1409e19ca  push rsi
00007ff1409e19cb  push r8
00007ff1409e19cd  push r9
00007ff1409e19cf  push r10
00007ff1409e19d1  push r11
00007ff1409e19d3  sub rsp, 0xF0
00007ff1409e19da  vmovaps [rsp], xmm0
00007ff1409e19df  vmovaps [rsp+0x10], xmm1
00007ff1409e19e5  vmovaps [rsp+0x20], xmm2
00007ff1409e19eb  vmovaps [rsp+0x30], xmm3
00007ff1409e19f1  vmovaps [rsp+0x40], xmm4
00007ff1409e19f7  vmovaps [rsp+0x50], xmm5
00007ff1409e19fd  vmovaps [rsp+0x60], xmm6
00007ff1409e1a03  vmovaps [rsp+0x70], xmm7
00007ff1409e1a09  vmovaps [rsp+0x80], xmm8
00007ff1409e1a12  vmovaps [rsp+0x90], xmm9
00007ff1409e1a1b  vmovaps [rsp+0xA0], xmm10
00007ff1409e1a24  vmovaps [rsp+0xB0], xmm11
00007ff1409e1a2d  vmovaps [rsp+0xC0], xmm12
00007ff1409e1a36  vmovaps [rsp+0xD0], xmm13
00007ff1409e1a3f  vmovaps [rsp+0xE0], xmm14
00007ff1409e1a48  sub rsp, 0x30
00007ff1409e1a4c  movaps [rsp], xmm15
00007ff1409e1a51  movaps [rsp+0x10], xmm3
00007ff1409e1a56  movaps [rsp+0x20], xmm7
00007ff1409e1a5b  lea rdi, [rsp]
00007ff1409e1a5f  mov esi, 0x00
00007ff1409e1a64  mov rax, 0x565C7F10C530
00007ff1409e1a6e  call rax
00007ff1409e1a70  movaps xmm15, [rsp]
00007ff1409e1a75  add rsp, 0x30
00007ff1409e1a79  vmovaps xmm0, [rsp]
00007ff1409e1a7e  vmovaps xmm1, [rsp+0x10]
00007ff1409e1a84  vmovaps xmm2, [rsp+0x20]
00007ff1409e1a8a  vmovaps xmm3, [rsp+0x30]
00007ff1409e1a90  vmovaps xmm4, [rsp+0x40]
00007ff1409e1a96  vmovaps xmm5, [rsp+0x50]
00007ff1409e1a9c  vmovaps xmm6, [rsp+0x60]
00007ff1409e1aa2  vmovaps xmm7, [rsp+0x70]
00007ff1409e1aa8  vmovaps xmm8, [rsp+0x80]
00007ff1409e1ab1  vmovaps xmm9, [rsp+0x90]
00007ff1409e1aba  vmovaps xmm10, [rsp+0xA0]
00007ff1409e1ac3  vmovaps xmm11, [rsp+0xB0]
00007ff1409e1acc  vmovaps xmm12, [rsp+0xC0]
00007ff1409e1ad5  vmovaps xmm13, [rsp+0xD0]
00007ff1409e1ade  vmovaps xmm14, [rsp+0xE0]
00007ff1409e1ae7  add rsp, 0xF0
00007ff1409e1aee  pop r11
00007ff1409e1af0  pop r10
00007ff1409e1af2  pop r9
00007ff1409e1af4  pop r8
00007ff1409e1af6  pop rsi
00007ff1409e1af7  pop rdi
00007ff1409e1af8  pop rdx
00007ff1409e1af9  pop rcx
00007ff1409e1afa  pop rax
00007ff1409e1afb  add rsp, 0x08
00007ff1409e1aff  jmp 0x00007FF1409DF3C3
00007ff1409e1b04  sub rsp, 0x08
00007ff1409e1b08  push rax
00007ff1409e1b09  push rcx
00007ff1409e1b0a  push rdx
00007ff1409e1b0b  push rdi
00007ff1409e1b0c  push rsi
00007ff1409e1b0d  push r8
00007ff1409e1b0f  push r9
00007ff1409e1b11  push r10
00007ff1409e1b13  push r11
00007ff1409e1b15  sub rsp, 0xF0
00007ff1409e1b1c  vmovaps [rsp], xmm0
00007ff1409e1b21  vmovaps [rsp+0x10], xmm1
00007ff1409e1b27  vmovaps [rsp+0x20], xmm2
00007ff1409e1b2d  vmovaps [rsp+0x30], xmm4
00007ff1409e1b33  vmovaps [rsp+0x40], xmm5
00007ff1409e1b39  vmovaps [rsp+0x50], xmm6
00007ff1409e1b3f  vmovaps [rsp+0x60], xmm7
00007ff1409e1b45  vmovaps [rsp+0x70], xmm8
00007ff1409e1b4b  vmovaps [rsp+0x80], xmm9
00007ff1409e1b54  vmovaps [rsp+0x90], xmm10
00007ff1409e1b5d  vmovaps [rsp+0xA0], xmm11
00007ff1409e1b66  vmovaps [rsp+0xB0], xmm12
00007ff1409e1b6f  vmovaps [rsp+0xC0], xmm13
00007ff1409e1b78  vmovaps [rsp+0xD0], xmm14
00007ff1409e1b81  vmovaps [rsp+0xE0], xmm15
00007ff1409e1b8a  sub rsp, 0x30
00007ff1409e1b8e  movaps [rsp], xmm3
00007ff1409e1b92  movaps [rsp+0x10], xmm1
00007ff1409e1b97  movaps [rsp+0x20], xmm15
00007ff1409e1b9d  lea rdi, [rsp]
00007ff1409e1ba1  mov esi, 0x00
00007ff1409e1ba6  mov rax, 0x565C7F10C530
00007ff1409e1bb0  call rax
00007ff1409e1bb2  movaps xmm3, [rsp]
00007ff1409e1bb6  add rsp, 0x30
00007ff1409e1bba  vmovaps xmm0, [rsp]
00007ff1409e1bbf  vmovaps xmm1, [rsp+0x10]
00007ff1409e1bc5  vmovaps xmm2, [rsp+0x20]
00007ff1409e1bcb  vmovaps xmm4, [rsp+0x30]
00007ff1409e1bd1  vmovaps xmm5, [rsp+0x40]
00007ff1409e1bd7  vmovaps xmm6, [rsp+0x50]
00007ff1409e1bdd  vmovaps xmm7, [rsp+0x60]
00007ff1409e1be3  vmovaps xmm8, [rsp+0x70]
00007ff1409e1be9  vmovaps xmm9, [rsp+0x80]
00007ff1409e1bf2  vmovaps xmm10, [rsp+0x90]
00007ff1409e1bfb  vmovaps xmm11, [rsp+0xA0]
00007ff1409e1c04  vmovaps xmm12, [rsp+0xB0]
00007ff1409e1c0d  vmovaps xmm13, [rsp+0xC0]
00007ff1409e1c16  vmovaps xmm14, [rsp+0xD0]
00007ff1409e1c1f  vmovaps xmm15, [rsp+0xE0]
00007ff1409e1c28  add rsp, 0xF0
00007ff1409e1c2f  pop r11
00007ff1409e1c31  pop r10
00007ff1409e1c33  pop r9
00007ff1409e1c35  pop r8
00007ff1409e1c37  pop rsi
00007ff1409e1c38  pop rdi
00007ff1409e1c39  pop rdx
00007ff1409e1c3a  pop rcx
00007ff1409e1c3b  pop rax
00007ff1409e1c3c  add rsp, 0x08
00007ff1409e1c40  jmp 0x00007FF1409DF452
00007ff1409e1c45  call 0x00007FF1408B52F0
00007ff1409e1c4a  jmp 0x00007FF1409DF45C
00007ff1409e1c4f  sub rsp, 0x08
00007ff1409e1c53  push rax
00007ff1409e1c54  push rcx
00007ff1409e1c55  push rdx
00007ff1409e1c56  push rdi
00007ff1409e1c57  push rsi
00007ff1409e1c58  push r8
00007ff1409e1c5a  push r9
00007ff1409e1c5c  push r10
00007ff1409e1c5e  push r11
00007ff1409e1c60  sub rsp, 0xF0
00007ff1409e1c67  vmovaps [rsp], xmm0
00007ff1409e1c6c  vmovaps [rsp+0x10], xmm1
00007ff1409e1c72  vmovaps [rsp+0x20], xmm2
00007ff1409e1c78  vmovaps [rsp+0x30], xmm3
00007ff1409e1c7e  vmovaps [rsp+0x40], xmm4
00007ff1409e1c84  vmovaps [rsp+0x50], xmm5
00007ff1409e1c8a  vmovaps [rsp+0x60], xmm6
00007ff1409e1c90  vmovaps [rsp+0x70], xmm7
00007ff1409e1c96  vmovaps [rsp+0x80], xmm8
00007ff1409e1c9f  vmovaps [rsp+0x90], xmm9
00007ff1409e1ca8  vmovaps [rsp+0xA0], xmm10
00007ff1409e1cb1  vmovaps [rsp+0xB0], xmm11
00007ff1409e1cba  vmovaps [rsp+0xC0], xmm12
00007ff1409e1cc3  vmovaps [rsp+0xD0], xmm13
00007ff1409e1ccc  vmovaps [rsp+0xE0], xmm14
00007ff1409e1cd5  sub rsp, 0x30
00007ff1409e1cd9  movaps [rsp], xmm15
00007ff1409e1cde  movaps [rsp+0x10], xmm14
00007ff1409e1ce4  movaps [rsp+0x20], xmm4
00007ff1409e1ce9  lea rdi, [rsp]
00007ff1409e1ced  mov esi, 0x00
00007ff1409e1cf2  mov rax, 0x565C7F10C530
00007ff1409e1cfc  call rax
00007ff1409e1cfe  movaps xmm15, [rsp]
00007ff1409e1d03  add rsp, 0x30
00007ff1409e1d07  vmovaps xmm0, [rsp]
00007ff1409e1d0c  vmovaps xmm1, [rsp+0x10]
00007ff1409e1d12  vmovaps xmm2, [rsp+0x20]
00007ff1409e1d18  vmovaps xmm3, [rsp+0x30]
00007ff1409e1d1e  vmovaps xmm4, [rsp+0x40]
00007ff1409e1d24  vmovaps xmm5, [rsp+0x50]
00007ff1409e1d2a  vmovaps xmm6, [rsp+0x60]
00007ff1409e1d30  vmovaps xmm7, [rsp+0x70]
00007ff1409e1d36  vmovaps xmm8, [rsp+0x80]
00007ff1409e1d3f  vmovaps xmm9, [rsp+0x90]
00007ff1409e1d48  vmovaps xmm10, [rsp+0xA0]
00007ff1409e1d51  vmovaps xmm11, [rsp+0xB0]
00007ff1409e1d5a  vmovaps xmm12, [rsp+0xC0]
00007ff1409e1d63  vmovaps xmm13, [rsp+0xD0]
00007ff1409e1d6c  vmovaps xmm14, [rsp+0xE0]
00007ff1409e1d75  add rsp, 0xF0
00007ff1409e1d7c  pop r11
00007ff1409e1d7e  pop r10
00007ff1409e1d80  pop r9
00007ff1409e1d82  pop r8
00007ff1409e1d84  pop rsi
00007ff1409e1d85  pop rdi
00007ff1409e1d86  pop rdx
00007ff1409e1d87  pop rcx
00007ff1409e1d88  pop rax
00007ff1409e1d89  add rsp, 0x08
00007ff1409e1d8d  jmp 0x00007FF1409DF48A
00007ff1409e1d92  sub rsp, 0x08
00007ff1409e1d96  push rax
00007ff1409e1d97  push rcx
00007ff1409e1d98  push rdx
00007ff1409e1d99  push rdi
00007ff1409e1d9a  push rsi
00007ff1409e1d9b  push r8
00007ff1409e1d9d  push r9
00007ff1409e1d9f  push r10
00007ff1409e1da1  push r11
00007ff1409e1da3  sub rsp, 0xF0
00007ff1409e1daa  vmovaps [rsp], xmm0
00007ff1409e1daf  vmovaps [rsp+0x10], xmm1
00007ff1409e1db5  vmovaps [rsp+0x20], xmm2
00007ff1409e1dbb  vmovaps [rsp+0x30], xmm3
00007ff1409e1dc1  vmovaps [rsp+0x40], xmm4
00007ff1409e1dc7  vmovaps [rsp+0x50], xmm5
00007ff1409e1dcd  vmovaps [rsp+0x60], xmm6
00007ff1409e1dd3  vmovaps [rsp+0x70], xmm7
00007ff1409e1dd9  vmovaps [rsp+0x80], xmm8
00007ff1409e1de2  vmovaps [rsp+0x90], xmm9
00007ff1409e1deb  vmovaps [rsp+0xA0], xmm10
00007ff1409e1df4  vmovaps [rsp+0xB0], xmm11
00007ff1409e1dfd  vmovaps [rsp+0xC0], xmm12
00007ff1409e1e06  vmovaps [rsp+0xD0], xmm13
00007ff1409e1e0f  vmovaps [rsp+0xE0], xmm15
00007ff1409e1e18  sub rsp, 0x30
00007ff1409e1e1c  movaps [rsp], xmm14
00007ff1409e1e21  movaps [rsp+0x10], xmm2
00007ff1409e1e26  movaps [rsp+0x20], xmm1
00007ff1409e1e2b  lea rdi, [rsp]
00007ff1409e1e2f  mov esi, 0x00
00007ff1409e1e34  mov rax, 0x565C7F10C530
00007ff1409e1e3e  call rax
00007ff1409e1e40  movaps xmm14, [rsp]
00007ff1409e1e45  add rsp, 0x30
00007ff1409e1e49  vmovaps xmm0, [rsp]
00007ff1409e1e4e  vmovaps xmm1, [rsp+0x10]
00007ff1409e1e54  vmovaps xmm2, [rsp+0x20]
00007ff1409e1e5a  vmovaps xmm3, [rsp+0x30]
00007ff1409e1e60  vmovaps xmm4, [rsp+0x40]
00007ff1409e1e66  vmovaps xmm5, [rsp+0x50]
00007ff1409e1e6c  vmovaps xmm6, [rsp+0x60]
00007ff1409e1e72  vmovaps xmm7, [rsp+0x70]
00007ff1409e1e78  vmovaps xmm8, [rsp+0x80]
00007ff1409e1e81  vmovaps xmm9, [rsp+0x90]
00007ff1409e1e8a  vmovaps xmm10, [rsp+0xA0]
00007ff1409e1e93  vmovaps xmm11, [rsp+0xB0]
00007ff1409e1e9c  vmovaps xmm12, [rsp+0xC0]
00007ff1409e1ea5  vmovaps xmm13, [rsp+0xD0]
00007ff1409e1eae  vmovaps xmm15, [rsp+0xE0]
00007ff1409e1eb7  add rsp, 0xF0
00007ff1409e1ebe  pop r11
00007ff1409e1ec0  pop r10
00007ff1409e1ec2  pop r9
00007ff1409e1ec4  pop r8
00007ff1409e1ec6  pop rsi
00007ff1409e1ec7  pop rdi
00007ff1409e1ec8  pop rdx
00007ff1409e1ec9  pop rcx
00007ff1409e1eca  pop rax
00007ff1409e1ecb  add rsp, 0x08
00007ff1409e1ecf  jmp 0x00007FF1409DF4B0
00007ff1409e1ed4  sub rsp, 0x08
00007ff1409e1ed8  push rax
00007ff1409e1ed9  push rcx
00007ff1409e1eda  push rdx
00007ff1409e1edb  push rdi
00007ff1409e1edc  push rsi
00007ff1409e1edd  push r8
00007ff1409e1edf  push r9
00007ff1409e1ee1  push r10
00007ff1409e1ee3  push r11
00007ff1409e1ee5  sub rsp, 0xF0
00007ff1409e1eec  vmovaps [rsp], xmm0
00007ff1409e1ef1  vmovaps [rsp+0x10], xmm2
00007ff1409e1ef7  vmovaps [rsp+0x20], xmm3
00007ff1409e1efd  vmovaps [rsp+0x30], xmm4
00007ff1409e1f03  vmovaps [rsp+0x40], xmm5
00007ff1409e1f09  vmovaps [rsp+0x50], xmm6
00007ff1409e1f0f  vmovaps [rsp+0x60], xmm7
00007ff1409e1f15  vmovaps [rsp+0x70], xmm8
00007ff1409e1f1b  vmovaps [rsp+0x80], xmm9
00007ff1409e1f24  vmovaps [rsp+0x90], xmm10
00007ff1409e1f2d  vmovaps [rsp+0xA0], xmm11
00007ff1409e1f36  vmovaps [rsp+0xB0], xmm12
00007ff1409e1f3f  vmovaps [rsp+0xC0], xmm13
00007ff1409e1f48  vmovaps [rsp+0xD0], xmm14
00007ff1409e1f51  vmovaps [rsp+0xE0], xmm15
00007ff1409e1f5a  sub rsp, 0x30
00007ff1409e1f5e  movaps [rsp], xmm1
00007ff1409e1f62  movaps [rsp+0x10], xmm4
00007ff1409e1f67  movaps [rsp+0x20], xmm9
00007ff1409e1f6d  lea rdi, [rsp]
00007ff1409e1f71  mov esi, 0x00
00007ff1409e1f76  mov rax, 0x565C7F10C530
00007ff1409e1f80  call rax
00007ff1409e1f82  movaps xmm1, [rsp]
00007ff1409e1f86  add rsp, 0x30
00007ff1409e1f8a  vmovaps xmm0, [rsp]
00007ff1409e1f8f  vmovaps xmm2, [rsp+0x10]
00007ff1409e1f95  vmovaps xmm3, [rsp+0x20]
00007ff1409e1f9b  vmovaps xmm4, [rsp+0x30]
00007ff1409e1fa1  vmovaps xmm5, [rsp+0x40]
00007ff1409e1fa7  vmovaps xmm6, [rsp+0x50]
00007ff1409e1fad  vmovaps xmm7, [rsp+0x60]
00007ff1409e1fb3  vmovaps xmm8, [rsp+0x70]
00007ff1409e1fb9  vmovaps xmm9, [rsp+0x80]
00007ff1409e1fc2  vmovaps xmm10, [rsp+0x90]
00007ff1409e1fcb  vmovaps xmm11, [rsp+0xA0]
00007ff1409e1fd4  vmovaps xmm12, [rsp+0xB0]
00007ff1409e1fdd  vmovaps xmm13, [rsp+0xC0]
00007ff1409e1fe6  vmovaps xmm14, [rsp+0xD0]
00007ff1409e1fef  vmovaps xmm15, [rsp+0xE0]
00007ff1409e1ff8  add rsp, 0xF0
00007ff1409e1fff  pop r11
00007ff1409e2001  pop r10
00007ff1409e2003  pop r9
00007ff1409e2005  pop r8
00007ff1409e2007  pop rsi
00007ff1409e2008  pop rdi
00007ff1409e2009  pop rdx
00007ff1409e200a  pop rcx
00007ff1409e200b  pop rax
00007ff1409e200c  add rsp, 0x08
00007ff1409e2010  jmp 0x00007FF1409DF4CE
00007ff1409e2015  sub rsp, 0x08
00007ff1409e2019  push rax
00007ff1409e201a  push rcx
00007ff1409e201b  push rdx
00007ff1409e201c  push rdi
00007ff1409e201d  push rsi
00007ff1409e201e  push r8
00007ff1409e2020  push r9
00007ff1409e2022  push r10
00007ff1409e2024  push r11
00007ff1409e2026  sub rsp, 0xF0
00007ff1409e202d  vmovaps [rsp], xmm0
00007ff1409e2032  vmovaps [rsp+0x10], xmm1
00007ff1409e2038  vmovaps [rsp+0x20], xmm2
00007ff1409e203e  vmovaps [rsp+0x30], xmm3
00007ff1409e2044  vmovaps [rsp+0x40], xmm5
00007ff1409e204a  vmovaps [rsp+0x50], xmm6
00007ff1409e2050  vmovaps [rsp+0x60], xmm7
00007ff1409e2056  vmovaps [rsp+0x70], xmm8
00007ff1409e205c  vmovaps [rsp+0x80], xmm9
00007ff1409e2065  vmovaps [rsp+0x90], xmm10
00007ff1409e206e  vmovaps [rsp+0xA0], xmm11
00007ff1409e2077  vmovaps [rsp+0xB0], xmm12
00007ff1409e2080  vmovaps [rsp+0xC0], xmm13
00007ff1409e2089  vmovaps [rsp+0xD0], xmm14
00007ff1409e2092  vmovaps [rsp+0xE0], xmm15
00007ff1409e209b  sub rsp, 0x30
00007ff1409e209f  movaps [rsp], xmm4
00007ff1409e20a3  movaps [rsp+0x10], xmm2
00007ff1409e20a8  movaps [rsp+0x20], xmm9
00007ff1409e20ae  lea rdi, [rsp]
00007ff1409e20b2  mov esi, 0x00
00007ff1409e20b7  mov rax, 0x565C7F10C530
00007ff1409e20c1  call rax
00007ff1409e20c3  movaps xmm4, [rsp]
00007ff1409e20c7  add rsp, 0x30
00007ff1409e20cb  vmovaps xmm0, [rsp]
00007ff1409e20d0  vmovaps xmm1, [rsp+0x10]
00007ff1409e20d6  vmovaps xmm2, [rsp+0x20]
00007ff1409e20dc  vmovaps xmm3, [rsp+0x30]
00007ff1409e20e2  vmovaps xmm5, [rsp+0x40]
00007ff1409e20e8  vmovaps xmm6, [rsp+0x50]
00007ff1409e20ee  vmovaps xmm7, [rsp+0x60]
00007ff1409e20f4  vmovaps xmm8, [rsp+0x70]
00007ff1409e20fa  vmovaps xmm9, [rsp+0x80]
00007ff1409e2103  vmovaps xmm10, [rsp+0x90]
00007ff1409e210c  vmovaps xmm11, [rsp+0xA0]
00007ff1409e2115  vmovaps xmm12, [rsp+0xB0]
00007ff1409e211e  vmovaps xmm13, [rsp+0xC0]
00007ff1409e2127  vmovaps xmm14, [rsp+0xD0]
00007ff1409e2130  vmovaps xmm15, [rsp+0xE0]
00007ff1409e2139  add rsp, 0xF0
00007ff1409e2140  pop r11
00007ff1409e2142  pop r10
00007ff1409e2144  pop r9
00007ff1409e2146  pop r8
00007ff1409e2148  pop rsi
00007ff1409e2149  pop rdi
00007ff1409e214a  pop rdx
00007ff1409e214b  pop rcx
00007ff1409e214c  pop rax
00007ff1409e214d  add rsp, 0x08
00007ff1409e2151  jmp 0x00007FF1409DF4FE
00007ff1409e2156  sub rsp, 0x08
00007ff1409e215a  push rax
00007ff1409e215b  push rcx
00007ff1409e215c  push rdx
00007ff1409e215d  push rdi
00007ff1409e215e  push rsi
00007ff1409e215f  push r8
00007ff1409e2161  push r9
00007ff1409e2163  push r10
00007ff1409e2165  push r11
00007ff1409e2167  sub rsp, 0xF0
00007ff1409e216e  vmovaps [rsp], xmm0
00007ff1409e2173  vmovaps [rsp+0x10], xmm1
00007ff1409e2179  vmovaps [rsp+0x20], xmm2
00007ff1409e217f  vmovaps [rsp+0x30], xmm3
00007ff1409e2185  vmovaps [rsp+0x40], xmm4
00007ff1409e218b  vmovaps [rsp+0x50], xmm5
00007ff1409e2191  vmovaps [rsp+0x60], xmm6
00007ff1409e2197  vmovaps [rsp+0x70], xmm7
00007ff1409e219d  vmovaps [rsp+0x80], xmm8
00007ff1409e21a6  vmovaps [rsp+0x90], xmm10
00007ff1409e21af  vmovaps [rsp+0xA0], xmm11
00007ff1409e21b8  vmovaps [rsp+0xB0], xmm12
00007ff1409e21c1  vmovaps [rsp+0xC0], xmm13
00007ff1409e21ca  vmovaps [rsp+0xD0], xmm14
00007ff1409e21d3  vmovaps [rsp+0xE0], xmm15
00007ff1409e21dc  sub rsp, 0x30
00007ff1409e21e0  movaps [rsp], xmm9
00007ff1409e21e5  movaps [rsp+0x10], xmm2
00007ff1409e21ea  movaps [rsp+0x20], xmm1
00007ff1409e21ef  lea rdi, [rsp]
00007ff1409e21f3  mov esi, 0x00
00007ff1409e21f8  mov rax, 0x565C7F10C530
00007ff1409e2202  call rax
00007ff1409e2204  movaps xmm9, [rsp]
00007ff1409e2209  add rsp, 0x30
00007ff1409e220d  vmovaps xmm0, [rsp]
00007ff1409e2212  vmovaps xmm1, [rsp+0x10]
00007ff1409e2218  vmovaps xmm2, [rsp+0x20]
00007ff1409e221e  vmovaps xmm3, [rsp+0x30]
00007ff1409e2224  vmovaps xmm4, [rsp+0x40]
00007ff1409e222a  vmovaps xmm5, [rsp+0x50]
00007ff1409e2230  vmovaps xmm6, [rsp+0x60]
00007ff1409e2236  vmovaps xmm7, [rsp+0x70]
00007ff1409e223c  vmovaps xmm8, [rsp+0x80]
00007ff1409e2245  vmovaps xmm10, [rsp+0x90]
00007ff1409e224e  vmovaps xmm11, [rsp+0xA0]
00007ff1409e2257  vmovaps xmm12, [rsp+0xB0]
00007ff1409e2260  vmovaps xmm13, [rsp+0xC0]
00007ff1409e2269  vmovaps xmm14, [rsp+0xD0]
00007ff1409e2272  vmovaps xmm15, [rsp+0xE0]
00007ff1409e227b  add rsp, 0xF0
00007ff1409e2282  pop r11
00007ff1409e2284  pop r10
00007ff1409e2286  pop r9
00007ff1409e2288  pop r8
00007ff1409e228a  pop rsi
00007ff1409e228b  pop rdi
00007ff1409e228c  pop rdx
00007ff1409e228d  pop rcx
00007ff1409e228e  pop rax
00007ff1409e228f  add rsp, 0x08
00007ff1409e2293  jmp 0x00007FF1409DF534
00007ff1409e2298  sub rsp, 0x08
00007ff1409e229c  push rax
00007ff1409e229d  push rcx
00007ff1409e229e  push rdx
00007ff1409e229f  push rdi
00007ff1409e22a0  push rsi
00007ff1409e22a1  push r8
00007ff1409e22a3  push r9
00007ff1409e22a5  push r10
00007ff1409e22a7  push r11
00007ff1409e22a9  sub rsp, 0xF0
00007ff1409e22b0  vmovaps [rsp], xmm0
00007ff1409e22b5  vmovaps [rsp+0x10], xmm2
00007ff1409e22bb  vmovaps [rsp+0x20], xmm3
00007ff1409e22c1  vmovaps [rsp+0x30], xmm4
00007ff1409e22c7  vmovaps [rsp+0x40], xmm5
00007ff1409e22cd  vmovaps [rsp+0x50], xmm6
00007ff1409e22d3  vmovaps [rsp+0x60], xmm7
00007ff1409e22d9  vmovaps [rsp+0x70], xmm8
00007ff1409e22df  vmovaps [rsp+0x80], xmm9
00007ff1409e22e8  vmovaps [rsp+0x90], xmm10
00007ff1409e22f1  vmovaps [rsp+0xA0], xmm11
00007ff1409e22fa  vmovaps [rsp+0xB0], xmm12
00007ff1409e2303  vmovaps [rsp+0xC0], xmm13
00007ff1409e230c  vmovaps [rsp+0xD0], xmm14
00007ff1409e2315  vmovaps [rsp+0xE0], xmm15
00007ff1409e231e  sub rsp, 0x30
00007ff1409e2322  movaps [rsp], xmm1
00007ff1409e2326  movaps [rsp+0x10], xmm15
00007ff1409e232c  movaps [rsp+0x20], xmm6
00007ff1409e2331  lea rdi, [rsp]
00007ff1409e2335  mov esi, 0x00
00007ff1409e233a  mov rax, 0x565C7F10C530
00007ff1409e2344  call rax
00007ff1409e2346  movaps xmm1, [rsp]
00007ff1409e234a  add rsp, 0x30
00007ff1409e234e  vmovaps xmm0, [rsp]
00007ff1409e2353  vmovaps xmm2, [rsp+0x10]
00007ff1409e2359  vmovaps xmm3, [rsp+0x20]
00007ff1409e235f  vmovaps xmm4, [rsp+0x30]
00007ff1409e2365  vmovaps xmm5, [rsp+0x40]
00007ff1409e236b  vmovaps xmm6, [rsp+0x50]
00007ff1409e2371  vmovaps xmm7, [rsp+0x60]
00007ff1409e2377  vmovaps xmm8, [rsp+0x70]
00007ff1409e237d  vmovaps xmm9, [rsp+0x80]
00007ff1409e2386  vmovaps xmm10, [rsp+0x90]
00007ff1409e238f  vmovaps xmm11, [rsp+0xA0]
00007ff1409e2398  vmovaps xmm12, [rsp+0xB0]
00007ff1409e23a1  vmovaps xmm13, [rsp+0xC0]
00007ff1409e23aa  vmovaps xmm14, [rsp+0xD0]
00007ff1409e23b3  vmovaps xmm15, [rsp+0xE0]
00007ff1409e23bc  add rsp, 0xF0
00007ff1409e23c3  pop r11
00007ff1409e23c5  pop r10
00007ff1409e23c7  pop r9
00007ff1409e23c9  pop r8
00007ff1409e23cb  pop rsi
00007ff1409e23cc  pop rdi
00007ff1409e23cd  pop rdx
00007ff1409e23ce  pop rcx
00007ff1409e23cf  pop rax
00007ff1409e23d0  add rsp, 0x08
00007ff1409e23d4  jmp 0x00007FF1409DF555
00007ff1409e23d9  sub rsp, 0x08
00007ff1409e23dd  push rax
00007ff1409e23de  push rcx
00007ff1409e23df  push rdx
00007ff1409e23e0  push rdi
00007ff1409e23e1  push rsi
00007ff1409e23e2  push r8
00007ff1409e23e4  push r9
00007ff1409e23e6  push r10
00007ff1409e23e8  push r11
00007ff1409e23ea  sub rsp, 0xF0
00007ff1409e23f1  vmovaps [rsp], xmm0
00007ff1409e23f6  vmovaps [rsp+0x10], xmm1
00007ff1409e23fc  vmovaps [rsp+0x20], xmm2
00007ff1409e2402  vmovaps [rsp+0x30], xmm3
00007ff1409e2408  vmovaps [rsp+0x40], xmm4
00007ff1409e240e  vmovaps [rsp+0x50], xmm5
00007ff1409e2414  vmovaps [rsp+0x60], xmm6
00007ff1409e241a  vmovaps [rsp+0x70], xmm7
00007ff1409e2420  vmovaps [rsp+0x80], xmm8
00007ff1409e2429  vmovaps [rsp+0x90], xmm9
00007ff1409e2432  vmovaps [rsp+0xA0], xmm10
00007ff1409e243b  vmovaps [rsp+0xB0], xmm11
00007ff1409e2444  vmovaps [rsp+0xC0], xmm12
00007ff1409e244d  vmovaps [rsp+0xD0], xmm13
00007ff1409e2456  vmovaps [rsp+0xE0], xmm14
00007ff1409e245f  sub rsp, 0x30
00007ff1409e2463  movaps [rsp], xmm15
00007ff1409e2468  movaps [rsp+0x10], xmm5
00007ff1409e246d  movaps [rsp+0x20], xmm3
00007ff1409e2472  lea rdi, [rsp]
00007ff1409e2476  mov esi, 0x00
00007ff1409e247b  mov rax, 0x565C7F10C530
00007ff1409e2485  call rax
00007ff1409e2487  movaps xmm15, [rsp]
00007ff1409e248c  add rsp, 0x30
00007ff1409e2490  vmovaps xmm0, [rsp]
00007ff1409e2495  vmovaps xmm1, [rsp+0x10]
00007ff1409e249b  vmovaps xmm2, [rsp+0x20]
00007ff1409e24a1  vmovaps xmm3, [rsp+0x30]
00007ff1409e24a7  vmovaps xmm4, [rsp+0x40]
00007ff1409e24ad  vmovaps xmm5, [rsp+0x50]
00007ff1409e24b3  vmovaps xmm6, [rsp+0x60]
00007ff1409e24b9  vmovaps xmm7, [rsp+0x70]
00007ff1409e24bf  vmovaps xmm8, [rsp+0x80]
00007ff1409e24c8  vmovaps xmm9, [rsp+0x90]
00007ff1409e24d1  vmovaps xmm10, [rsp+0xA0]
00007ff1409e24da  vmovaps xmm11, [rsp+0xB0]
00007ff1409e24e3  vmovaps xmm12, [rsp+0xC0]
00007ff1409e24ec  vmovaps xmm13, [rsp+0xD0]
00007ff1409e24f5  vmovaps xmm14, [rsp+0xE0]
00007ff1409e24fe  add rsp, 0xF0
00007ff1409e2505  pop r11
00007ff1409e2507  pop r10
00007ff1409e2509  pop r9
00007ff1409e250b  pop r8
00007ff1409e250d  pop rsi
00007ff1409e250e  pop rdi
00007ff1409e250f  pop rdx
00007ff1409e2510  pop rcx
00007ff1409e2511  pop rax
00007ff1409e2512  add rsp, 0x08
00007ff1409e2516  jmp 0x00007FF1409DF56F
00007ff1409e251b  sub rsp, 0x08
00007ff1409e251f  push rax
00007ff1409e2520  push rcx
00007ff1409e2521  push rdx
00007ff1409e2522  push rdi
00007ff1409e2523  push rsi
00007ff1409e2524  push r8
00007ff1409e2526  push r9
00007ff1409e2528  push r10
00007ff1409e252a  push r11
00007ff1409e252c  sub rsp, 0xF0
00007ff1409e2533  vmovaps [rsp], xmm0
00007ff1409e2538  vmovaps [rsp+0x10], xmm1
00007ff1409e253e  vmovaps [rsp+0x20], xmm2
00007ff1409e2544  vmovaps [rsp+0x30], xmm3
00007ff1409e254a  vmovaps [rsp+0x40], xmm4
00007ff1409e2550  vmovaps [rsp+0x50], xmm6
00007ff1409e2556  vmovaps [rsp+0x60], xmm7
00007ff1409e255c  vmovaps [rsp+0x70], xmm8
00007ff1409e2562  vmovaps [rsp+0x80], xmm9
00007ff1409e256b  vmovaps [rsp+0x90], xmm10
00007ff1409e2574  vmovaps [rsp+0xA0], xmm11
00007ff1409e257d  vmovaps [rsp+0xB0], xmm12
00007ff1409e2586  vmovaps [rsp+0xC0], xmm13
00007ff1409e258f  vmovaps [rsp+0xD0], xmm14
00007ff1409e2598  vmovaps [rsp+0xE0], xmm15
00007ff1409e25a1  sub rsp, 0x30
00007ff1409e25a5  movaps [rsp], xmm5
00007ff1409e25a9  movaps [rsp+0x10], xmm8
00007ff1409e25af  movaps [rsp+0x20], xmm6
00007ff1409e25b4  lea rdi, [rsp]
00007ff1409e25b8  mov esi, 0x00
00007ff1409e25bd  mov rax, 0x565C7F10C530
00007ff1409e25c7  call rax
00007ff1409e25c9  movaps xmm5, [rsp]
00007ff1409e25cd  add rsp, 0x30
00007ff1409e25d1  vmovaps xmm0, [rsp]
00007ff1409e25d6  vmovaps xmm1, [rsp+0x10]
00007ff1409e25dc  vmovaps xmm2, [rsp+0x20]
00007ff1409e25e2  vmovaps xmm3, [rsp+0x30]
00007ff1409e25e8  vmovaps xmm4, [rsp+0x40]
00007ff1409e25ee  vmovaps xmm6, [rsp+0x50]
00007ff1409e25f4  vmovaps xmm7, [rsp+0x60]
00007ff1409e25fa  vmovaps xmm8, [rsp+0x70]
00007ff1409e2600  vmovaps xmm9, [rsp+0x80]
00007ff1409e2609  vmovaps xmm10, [rsp+0x90]
00007ff1409e2612  vmovaps xmm11, [rsp+0xA0]
00007ff1409e261b  vmovaps xmm12, [rsp+0xB0]
00007ff1409e2624  vmovaps xmm13, [rsp+0xC0]
00007ff1409e262d  vmovaps xmm14, [rsp+0xD0]
00007ff1409e2636  vmovaps xmm15, [rsp+0xE0]
00007ff1409e263f  add rsp, 0xF0
00007ff1409e2646  pop r11
00007ff1409e2648  pop r10
00007ff1409e264a  pop r9
00007ff1409e264c  pop r8
00007ff1409e264e  pop rsi
00007ff1409e264f  pop rdi
00007ff1409e2650  pop rdx
00007ff1409e2651  pop rcx
00007ff1409e2652  pop rax
00007ff1409e2653  add rsp, 0x08
00007ff1409e2657  jmp 0x00007FF1409DF593
00007ff1409e265c  sub rsp, 0x08
00007ff1409e2660  push rax
00007ff1409e2661  push rcx
00007ff1409e2662  push rdx
00007ff1409e2663  push rdi
00007ff1409e2664  push rsi
00007ff1409e2665  push r8
00007ff1409e2667  push r9
00007ff1409e2669  push r10
00007ff1409e266b  push r11
00007ff1409e266d  sub rsp, 0xF0
00007ff1409e2674  vmovaps [rsp], xmm0
00007ff1409e2679  vmovaps [rsp+0x10], xmm1
00007ff1409e267f  vmovaps [rsp+0x20], xmm2
00007ff1409e2685  vmovaps [rsp+0x30], xmm3
00007ff1409e268b  vmovaps [rsp+0x40], xmm4
00007ff1409e2691  vmovaps [rsp+0x50], xmm5
00007ff1409e2697  vmovaps [rsp+0x60], xmm7
00007ff1409e269d  vmovaps [rsp+0x70], xmm8
00007ff1409e26a3  vmovaps [rsp+0x80], xmm9
00007ff1409e26ac  vmovaps [rsp+0x90], xmm10
00007ff1409e26b5  vmovaps [rsp+0xA0], xmm11
00007ff1409e26be  vmovaps [rsp+0xB0], xmm12
00007ff1409e26c7  vmovaps [rsp+0xC0], xmm13
00007ff1409e26d0  vmovaps [rsp+0xD0], xmm14
00007ff1409e26d9  vmovaps [rsp+0xE0], xmm15
00007ff1409e26e2  sub rsp, 0x30
00007ff1409e26e6  movaps [rsp], xmm6
00007ff1409e26ea  movaps [rsp+0x10], xmm10
00007ff1409e26f0  movaps [rsp+0x20], xmm8
00007ff1409e26f6  lea rdi, [rsp]
00007ff1409e26fa  mov esi, 0x00
00007ff1409e26ff  mov rax, 0x565C7F10C530
00007ff1409e2709  call rax
00007ff1409e270b  movaps xmm6, [rsp]
00007ff1409e270f  add rsp, 0x30
00007ff1409e2713  vmovaps xmm0, [rsp]
00007ff1409e2718  vmovaps xmm1, [rsp+0x10]
00007ff1409e271e  vmovaps xmm2, [rsp+0x20]
00007ff1409e2724  vmovaps xmm3, [rsp+0x30]
00007ff1409e272a  vmovaps xmm4, [rsp+0x40]
00007ff1409e2730  vmovaps xmm5, [rsp+0x50]
00007ff1409e2736  vmovaps xmm7, [rsp+0x60]
00007ff1409e273c  vmovaps xmm8, [rsp+0x70]
00007ff1409e2742  vmovaps xmm9, [rsp+0x80]
00007ff1409e274b  vmovaps xmm10, [rsp+0x90]
00007ff1409e2754  vmovaps xmm11, [rsp+0xA0]
00007ff1409e275d  vmovaps xmm12, [rsp+0xB0]
00007ff1409e2766  vmovaps xmm13, [rsp+0xC0]
00007ff1409e276f  vmovaps xmm14, [rsp+0xD0]
00007ff1409e2778  vmovaps xmm15, [rsp+0xE0]
00007ff1409e2781  add rsp, 0xF0
00007ff1409e2788  pop r11
00007ff1409e278a  pop r10
00007ff1409e278c  pop r9
00007ff1409e278e  pop r8
00007ff1409e2790  pop rsi
00007ff1409e2791  pop rdi
00007ff1409e2792  pop rdx
00007ff1409e2793  pop rcx
00007ff1409e2794  pop rax
00007ff1409e2795  add rsp, 0x08
00007ff1409e2799  jmp 0x00007FF1409DF5B8
00007ff1409e279e  sub rsp, 0x08
00007ff1409e27a2  push rax
00007ff1409e27a3  push rcx
00007ff1409e27a4  push rdx
00007ff1409e27a5  push rdi
00007ff1409e27a6  push rsi
00007ff1409e27a7  push r8
00007ff1409e27a9  push r9
00007ff1409e27ab  push r10
00007ff1409e27ad  push r11
00007ff1409e27af  sub rsp, 0xF0
00007ff1409e27b6  vmovaps [rsp], xmm0
00007ff1409e27bb  vmovaps [rsp+0x10], xmm1
00007ff1409e27c1  vmovaps [rsp+0x20], xmm2
00007ff1409e27c7  vmovaps [rsp+0x30], xmm3
00007ff1409e27cd  vmovaps [rsp+0x40], xmm4
00007ff1409e27d3  vmovaps [rsp+0x50], xmm5
00007ff1409e27d9  vmovaps [rsp+0x60], xmm6
00007ff1409e27df  vmovaps [rsp+0x70], xmm7
00007ff1409e27e5  vmovaps [rsp+0x80], xmm8
00007ff1409e27ee  vmovaps [rsp+0x90], xmm9
00007ff1409e27f7  vmovaps [rsp+0xA0], xmm11
00007ff1409e2800  vmovaps [rsp+0xB0], xmm12
00007ff1409e2809  vmovaps [rsp+0xC0], xmm13
00007ff1409e2812  vmovaps [rsp+0xD0], xmm14
00007ff1409e281b  vmovaps [rsp+0xE0], xmm15
00007ff1409e2824  sub rsp, 0x30
00007ff1409e2828  movaps [rsp], xmm10
00007ff1409e282d  movaps [rsp+0x10], xmm8
00007ff1409e2833  movaps [rsp+0x20], xmm14
00007ff1409e2839  lea rdi, [rsp]
00007ff1409e283d  mov esi, 0x00
00007ff1409e2842  mov rax, 0x565C7F10C530
00007ff1409e284c  call rax
00007ff1409e284e  movaps xmm10, [rsp]
00007ff1409e2853  add rsp, 0x30
00007ff1409e2857  vmovaps xmm0, [rsp]
00007ff1409e285c  vmovaps xmm1, [rsp+0x10]
00007ff1409e2862  vmovaps xmm2, [rsp+0x20]
00007ff1409e2868  vmovaps xmm3, [rsp+0x30]
00007ff1409e286e  vmovaps xmm4, [rsp+0x40]
00007ff1409e2874  vmovaps xmm5, [rsp+0x50]
00007ff1409e287a  vmovaps xmm6, [rsp+0x60]
00007ff1409e2880  vmovaps xmm7, [rsp+0x70]
00007ff1409e2886  vmovaps xmm8, [rsp+0x80]
00007ff1409e288f  vmovaps xmm9, [rsp+0x90]
00007ff1409e2898  vmovaps xmm11, [rsp+0xA0]
00007ff1409e28a1  vmovaps xmm12, [rsp+0xB0]
00007ff1409e28aa  vmovaps xmm13, [rsp+0xC0]
00007ff1409e28b3  vmovaps xmm14, [rsp+0xD0]
00007ff1409e28bc  vmovaps xmm15, [rsp+0xE0]
00007ff1409e28c5  add rsp, 0xF0
00007ff1409e28cc  pop r11
00007ff1409e28ce  pop r10
00007ff1409e28d0  pop r9
00007ff1409e28d2  pop r8
00007ff1409e28d4  pop rsi
00007ff1409e28d5  pop rdi
00007ff1409e28d6  pop rdx
00007ff1409e28d7  pop rcx
00007ff1409e28d8  pop rax
00007ff1409e28d9  add rsp, 0x08
00007ff1409e28dd  jmp 0x00007FF1409DF5D8
00007ff1409e28e2  sub rsp, 0x08
00007ff1409e28e6  push rax
00007ff1409e28e7  push rcx
00007ff1409e28e8  push rdx
00007ff1409e28e9  push rdi
00007ff1409e28ea  push rsi
00007ff1409e28eb  push r8
00007ff1409e28ed  push r9
00007ff1409e28ef  push r10
00007ff1409e28f1  push r11
00007ff1409e28f3  sub rsp, 0xF0
00007ff1409e28fa  vmovaps [rsp], xmm0
00007ff1409e28ff  vmovaps [rsp+0x10], xmm1
00007ff1409e2905  vmovaps [rsp+0x20], xmm2
00007ff1409e290b  vmovaps [rsp+0x30], xmm3
00007ff1409e2911  vmovaps [rsp+0x40], xmm4
00007ff1409e2917  vmovaps [rsp+0x50], xmm5
00007ff1409e291d  vmovaps [rsp+0x60], xmm6
00007ff1409e2923  vmovaps [rsp+0x70], xmm7
00007ff1409e2929  vmovaps [rsp+0x80], xmm8
00007ff1409e2932  vmovaps [rsp+0x90], xmm9
00007ff1409e293b  vmovaps [rsp+0xA0], xmm10
00007ff1409e2944  vmovaps [rsp+0xB0], xmm11
00007ff1409e294d  vmovaps [rsp+0xC0], xmm12
00007ff1409e2956  vmovaps [rsp+0xD0], xmm13
00007ff1409e295f  vmovaps [rsp+0xE0], xmm15
00007ff1409e2968  sub rsp, 0x30
00007ff1409e296c  movaps [rsp], xmm14
00007ff1409e2971  movaps [rsp+0x10], xmm8
00007ff1409e2977  movaps [rsp+0x20], xmm4
00007ff1409e297c  lea rdi, [rsp]
00007ff1409e2980  mov esi, 0x00
00007ff1409e2985  mov rax, 0x565C7F10C530
00007ff1409e298f  call rax
00007ff1409e2991  movaps xmm14, [rsp]
00007ff1409e2996  add rsp, 0x30
00007ff1409e299a  vmovaps xmm0, [rsp]
00007ff1409e299f  vmovaps xmm1, [rsp+0x10]
00007ff1409e29a5  vmovaps xmm2, [rsp+0x20]
00007ff1409e29ab  vmovaps xmm3, [rsp+0x30]
00007ff1409e29b1  vmovaps xmm4, [rsp+0x40]
00007ff1409e29b7  vmovaps xmm5, [rsp+0x50]
00007ff1409e29bd  vmovaps xmm6, [rsp+0x60]
00007ff1409e29c3  vmovaps xmm7, [rsp+0x70]
00007ff1409e29c9  vmovaps xmm8, [rsp+0x80]
00007ff1409e29d2  vmovaps xmm9, [rsp+0x90]
00007ff1409e29db  vmovaps xmm10, [rsp+0xA0]
00007ff1409e29e4  vmovaps xmm11, [rsp+0xB0]
00007ff1409e29ed  vmovaps xmm12, [rsp+0xC0]
00007ff1409e29f6  vmovaps xmm13, [rsp+0xD0]
00007ff1409e29ff  vmovaps xmm15, [rsp+0xE0]
00007ff1409e2a08  add rsp, 0xF0
00007ff1409e2a0f  pop r11
00007ff1409e2a11  pop r10
00007ff1409e2a13  pop r9
00007ff1409e2a15  pop r8
00007ff1409e2a17  pop rsi
00007ff1409e2a18  pop rdi
00007ff1409e2a19  pop rdx
00007ff1409e2a1a  pop rcx
00007ff1409e2a1b  pop rax
00007ff1409e2a1c  add rsp, 0x08
00007ff1409e2a20  jmp 0x00007FF1409DF5F8
00007ff1409e2a25  sub rsp, 0x08
00007ff1409e2a29  push rax
00007ff1409e2a2a  push rcx
00007ff1409e2a2b  push rdx
00007ff1409e2a2c  push rdi
00007ff1409e2a2d  push rsi
00007ff1409e2a2e  push r8
00007ff1409e2a30  push r9
00007ff1409e2a32  push r10
00007ff1409e2a34  push r11
00007ff1409e2a36  sub rsp, 0xF0
00007ff1409e2a3d  vmovaps [rsp], xmm0
00007ff1409e2a42  vmovaps [rsp+0x10], xmm1
00007ff1409e2a48  vmovaps [rsp+0x20], xmm2
00007ff1409e2a4e  vmovaps [rsp+0x30], xmm3
00007ff1409e2a54  vmovaps [rsp+0x40], xmm5
00007ff1409e2a5a  vmovaps [rsp+0x50], xmm6
00007ff1409e2a60  vmovaps [rsp+0x60], xmm7
00007ff1409e2a66  vmovaps [rsp+0x70], xmm8
00007ff1409e2a6c  vmovaps [rsp+0x80], xmm9
00007ff1409e2a75  vmovaps [rsp+0x90], xmm10
00007ff1409e2a7e  vmovaps [rsp+0xA0], xmm11
00007ff1409e2a87  vmovaps [rsp+0xB0], xmm12
00007ff1409e2a90  vmovaps [rsp+0xC0], xmm13
00007ff1409e2a99  vmovaps [rsp+0xD0], xmm14
00007ff1409e2aa2  vmovaps [rsp+0xE0], xmm15
00007ff1409e2aab  sub rsp, 0x30
00007ff1409e2aaf  movaps [rsp], xmm4
00007ff1409e2ab3  movaps [rsp+0x10], xmm13
00007ff1409e2ab9  movaps [rsp+0x20], xmm8
00007ff1409e2abf  lea rdi, [rsp]
00007ff1409e2ac3  mov esi, 0x00
00007ff1409e2ac8  mov rax, 0x565C7F10C530
00007ff1409e2ad2  call rax
00007ff1409e2ad4  movaps xmm4, [rsp]
00007ff1409e2ad8  add rsp, 0x30
00007ff1409e2adc  vmovaps xmm0, [rsp]
00007ff1409e2ae1  vmovaps xmm1, [rsp+0x10]
00007ff1409e2ae7  vmovaps xmm2, [rsp+0x20]
00007ff1409e2aed  vmovaps xmm3, [rsp+0x30]
00007ff1409e2af3  vmovaps xmm5, [rsp+0x40]
00007ff1409e2af9  vmovaps xmm6, [rsp+0x50]
00007ff1409e2aff  vmovaps xmm7, [rsp+0x60]
00007ff1409e2b05  vmovaps xmm8, [rsp+0x70]
00007ff1409e2b0b  vmovaps xmm9, [rsp+0x80]
00007ff1409e2b14  vmovaps xmm10, [rsp+0x90]
00007ff1409e2b1d  vmovaps xmm11, [rsp+0xA0]
00007ff1409e2b26  vmovaps xmm12, [rsp+0xB0]
00007ff1409e2b2f  vmovaps xmm13, [rsp+0xC0]
00007ff1409e2b38  vmovaps xmm14, [rsp+0xD0]
00007ff1409e2b41  vmovaps xmm15, [rsp+0xE0]
00007ff1409e2b4a  add rsp, 0xF0
00007ff1409e2b51  pop r11
00007ff1409e2b53  pop r10
00007ff1409e2b55  pop r9
00007ff1409e2b57  pop r8
00007ff1409e2b59  pop rsi
00007ff1409e2b5a  pop rdi
00007ff1409e2b5b  pop rdx
00007ff1409e2b5c  pop rcx
00007ff1409e2b5d  pop rax
00007ff1409e2b5e  add rsp, 0x08
00007ff1409e2b62  jmp 0x00007FF1409DF61D
00007ff1409e2b67  sub rsp, 0x08
00007ff1409e2b6b  push rax
00007ff1409e2b6c  push rcx
00007ff1409e2b6d  push rdx
00007ff1409e2b6e  push rdi
00007ff1409e2b6f  push rsi
00007ff1409e2b70  push r8
00007ff1409e2b72  push r9
00007ff1409e2b74  push r10
00007ff1409e2b76  push r11
00007ff1409e2b78  sub rsp, 0xF0
00007ff1409e2b7f  vmovaps [rsp], xmm0
00007ff1409e2b84  vmovaps [rsp+0x10], xmm1
00007ff1409e2b8a  vmovaps [rsp+0x20], xmm2
00007ff1409e2b90  vmovaps [rsp+0x30], xmm3
00007ff1409e2b96  vmovaps [rsp+0x40], xmm4
00007ff1409e2b9c  vmovaps [rsp+0x50], xmm5
00007ff1409e2ba2  vmovaps [rsp+0x60], xmm6
00007ff1409e2ba8  vmovaps [rsp+0x70], xmm7
00007ff1409e2bae  vmovaps [rsp+0x80], xmm8
00007ff1409e2bb7  vmovaps [rsp+0x90], xmm9
00007ff1409e2bc0  vmovaps [rsp+0xA0], xmm10
00007ff1409e2bc9  vmovaps [rsp+0xB0], xmm11
00007ff1409e2bd2  vmovaps [rsp+0xC0], xmm12
00007ff1409e2bdb  vmovaps [rsp+0xD0], xmm14
00007ff1409e2be4  vmovaps [rsp+0xE0], xmm15
00007ff1409e2bed  sub rsp, 0x30
00007ff1409e2bf1  movaps [rsp], xmm13
00007ff1409e2bf6  movaps [rsp+0x10], xmm15
00007ff1409e2bfc  movaps [rsp+0x20], xmm9
00007ff1409e2c02  lea rdi, [rsp]
00007ff1409e2c06  mov esi, 0x00
00007ff1409e2c0b  mov rax, 0x565C7F10C530
00007ff1409e2c15  call rax
00007ff1409e2c17  movaps xmm13, [rsp]
00007ff1409e2c1c  add rsp, 0x30
00007ff1409e2c20  vmovaps xmm0, [rsp]
00007ff1409e2c25  vmovaps xmm1, [rsp+0x10]
00007ff1409e2c2b  vmovaps xmm2, [rsp+0x20]
00007ff1409e2c31  vmovaps xmm3, [rsp+0x30]
00007ff1409e2c37  vmovaps xmm4, [rsp+0x40]
00007ff1409e2c3d  vmovaps xmm5, [rsp+0x50]
00007ff1409e2c43  vmovaps xmm6, [rsp+0x60]
00007ff1409e2c49  vmovaps xmm7, [rsp+0x70]
00007ff1409e2c4f  vmovaps xmm8, [rsp+0x80]
00007ff1409e2c58  vmovaps xmm9, [rsp+0x90]
00007ff1409e2c61  vmovaps xmm10, [rsp+0xA0]
00007ff1409e2c6a  vmovaps xmm11, [rsp+0xB0]
00007ff1409e2c73  vmovaps xmm12, [rsp+0xC0]
00007ff1409e2c7c  vmovaps xmm14, [rsp+0xD0]
00007ff1409e2c85  vmovaps xmm15, [rsp+0xE0]
00007ff1409e2c8e  add rsp, 0xF0
00007ff1409e2c95  pop r11
00007ff1409e2c97  pop r10
00007ff1409e2c99  pop r9
00007ff1409e2c9b  pop r8
00007ff1409e2c9d  pop rsi
00007ff1409e2c9e  pop rdi
00007ff1409e2c9f  pop rdx
00007ff1409e2ca0  pop rcx
00007ff1409e2ca1  pop rax
00007ff1409e2ca2  add rsp, 0x08
00007ff1409e2ca6  jmp 0x00007FF1409DF638
00007ff1409e2cab  sub rsp, 0x08
00007ff1409e2caf  push rax
00007ff1409e2cb0  push rcx
00007ff1409e2cb1  push rdx
00007ff1409e2cb2  push rdi
00007ff1409e2cb3  push rsi
00007ff1409e2cb4  push r8
00007ff1409e2cb6  push r9
00007ff1409e2cb8  push r10
00007ff1409e2cba  push r11
00007ff1409e2cbc  sub rsp, 0xF0
00007ff1409e2cc3  vmovaps [rsp], xmm0
00007ff1409e2cc8  vmovaps [rsp+0x10], xmm1
00007ff1409e2cce  vmovaps [rsp+0x20], xmm2
00007ff1409e2cd4  vmovaps [rsp+0x30], xmm3
00007ff1409e2cda  vmovaps [rsp+0x40], xmm4
00007ff1409e2ce0  vmovaps [rsp+0x50], xmm5
00007ff1409e2ce6  vmovaps [rsp+0x60], xmm6
00007ff1409e2cec  vmovaps [rsp+0x70], xmm7
00007ff1409e2cf2  vmovaps [rsp+0x80], xmm8
00007ff1409e2cfb  vmovaps [rsp+0x90], xmm9
00007ff1409e2d04  vmovaps [rsp+0xA0], xmm10
00007ff1409e2d0d  vmovaps [rsp+0xB0], xmm11
00007ff1409e2d16  vmovaps [rsp+0xC0], xmm12
00007ff1409e2d1f  vmovaps [rsp+0xD0], xmm13
00007ff1409e2d28  vmovaps [rsp+0xE0], xmm14
00007ff1409e2d31  sub rsp, 0x30
00007ff1409e2d35  movaps [rsp], xmm15
00007ff1409e2d3a  movaps [rsp+0x10], xmm1
00007ff1409e2d3f  movaps [rsp+0x20], xmm5
00007ff1409e2d44  lea rdi, [rsp]
00007ff1409e2d48  mov esi, 0x00
00007ff1409e2d4d  mov rax, 0x565C7F10C530
00007ff1409e2d57  call rax
00007ff1409e2d59  movaps xmm15, [rsp]
00007ff1409e2d5e  add rsp, 0x30
00007ff1409e2d62  vmovaps xmm0, [rsp]
00007ff1409e2d67  vmovaps xmm1, [rsp+0x10]
00007ff1409e2d6d  vmovaps xmm2, [rsp+0x20]
00007ff1409e2d73  vmovaps xmm3, [rsp+0x30]
00007ff1409e2d79  vmovaps xmm4, [rsp+0x40]
00007ff1409e2d7f  vmovaps xmm5, [rsp+0x50]
00007ff1409e2d85  vmovaps xmm6, [rsp+0x60]
00007ff1409e2d8b  vmovaps xmm7, [rsp+0x70]
00007ff1409e2d91  vmovaps xmm8, [rsp+0x80]
00007ff1409e2d9a  vmovaps xmm9, [rsp+0x90]
00007ff1409e2da3  vmovaps xmm10, [rsp+0xA0]
00007ff1409e2dac  vmovaps xmm11, [rsp+0xB0]
00007ff1409e2db5  vmovaps xmm12, [rsp+0xC0]
00007ff1409e2dbe  vmovaps xmm13, [rsp+0xD0]
00007ff1409e2dc7  vmovaps xmm14, [rsp+0xE0]
00007ff1409e2dd0  add rsp, 0xF0
00007ff1409e2dd7  pop r11
00007ff1409e2dd9  pop r10
00007ff1409e2ddb  pop r9
00007ff1409e2ddd  pop r8
00007ff1409e2ddf  pop rsi
00007ff1409e2de0  pop rdi
00007ff1409e2de1  pop rdx
00007ff1409e2de2  pop rcx
00007ff1409e2de3  pop rax
00007ff1409e2de4  add rsp, 0x08
00007ff1409e2de8  jmp 0x00007FF1409DF653
00007ff1409e2ded  call 0x00007FF1408B52F0
00007ff1409e2df2  jmp 0x00007FF1409DF6AE
00007ff1409e2df7  sub rsp, 0x08
00007ff1409e2dfb  push rax
00007ff1409e2dfc  push rcx
00007ff1409e2dfd  push rdx
00007ff1409e2dfe  push rdi
00007ff1409e2dff  push rsi
00007ff1409e2e00  push r8
00007ff1409e2e02  push r9
00007ff1409e2e04  push r10
00007ff1409e2e06  push r11
00007ff1409e2e08  sub rsp, 0xF0
00007ff1409e2e0f  vmovaps [rsp], xmm0
00007ff1409e2e14  vmovaps [rsp+0x10], xmm1
00007ff1409e2e1a  vmovaps [rsp+0x20], xmm2
00007ff1409e2e20  vmovaps [rsp+0x30], xmm3
00007ff1409e2e26  vmovaps [rsp+0x40], xmm4
00007ff1409e2e2c  vmovaps [rsp+0x50], xmm5
00007ff1409e2e32  vmovaps [rsp+0x60], xmm6
00007ff1409e2e38  vmovaps [rsp+0x70], xmm7
00007ff1409e2e3e  vmovaps [rsp+0x80], xmm8
00007ff1409e2e47  vmovaps [rsp+0x90], xmm10
00007ff1409e2e50  vmovaps [rsp+0xA0], xmm11
00007ff1409e2e59  vmovaps [rsp+0xB0], xmm12
00007ff1409e2e62  vmovaps [rsp+0xC0], xmm13
00007ff1409e2e6b  vmovaps [rsp+0xD0], xmm14
00007ff1409e2e74  vmovaps [rsp+0xE0], xmm15
00007ff1409e2e7d  sub rsp, 0x30
00007ff1409e2e81  movaps [rsp], xmm9
00007ff1409e2e86  movaps [rsp+0x10], xmm8
00007ff1409e2e8c  movaps [rsp+0x20], xmm11
00007ff1409e2e92  lea rdi, [rsp]
00007ff1409e2e96  mov esi, 0x00
00007ff1409e2e9b  mov rax, 0x565C7F10C530
00007ff1409e2ea5  call rax
00007ff1409e2ea7  movaps xmm9, [rsp]
00007ff1409e2eac  add rsp, 0x30
00007ff1409e2eb0  vmovaps xmm0, [rsp]
00007ff1409e2eb5  vmovaps xmm1, [rsp+0x10]
00007ff1409e2ebb  vmovaps xmm2, [rsp+0x20]
00007ff1409e2ec1  vmovaps xmm3, [rsp+0x30]
00007ff1409e2ec7  vmovaps xmm4, [rsp+0x40]
00007ff1409e2ecd  vmovaps xmm5, [rsp+0x50]
00007ff1409e2ed3  vmovaps xmm6, [rsp+0x60]
00007ff1409e2ed9  vmovaps xmm7, [rsp+0x70]
00007ff1409e2edf  vmovaps xmm8, [rsp+0x80]
00007ff1409e2ee8  vmovaps xmm10, [rsp+0x90]
00007ff1409e2ef1  vmovaps xmm11, [rsp+0xA0]
00007ff1409e2efa  vmovaps xmm12, [rsp+0xB0]
00007ff1409e2f03  vmovaps xmm13, [rsp+0xC0]
00007ff1409e2f0c  vmovaps xmm14, [rsp+0xD0]
00007ff1409e2f15  vmovaps xmm15, [rsp+0xE0]
00007ff1409e2f1e  add rsp, 0xF0
00007ff1409e2f25  pop r11
00007ff1409e2f27  pop r10
00007ff1409e2f29  pop r9
00007ff1409e2f2b  pop r8
00007ff1409e2f2d  pop rsi
00007ff1409e2f2e  pop rdi
00007ff1409e2f2f  pop rdx
00007ff1409e2f30  pop rcx
00007ff1409e2f31  pop rax
00007ff1409e2f32  add rsp, 0x08
00007ff1409e2f36  jmp 0x00007FF1409DF6E5
00007ff1409e2f3b  sub rsp, 0x08
00007ff1409e2f3f  push rax
00007ff1409e2f40  push rcx
00007ff1409e2f41  push rdx
00007ff1409e2f42  push rdi
00007ff1409e2f43  push rsi
00007ff1409e2f44  push r8
00007ff1409e2f46  push r9
00007ff1409e2f48  push r10
00007ff1409e2f4a  push r11
00007ff1409e2f4c  sub rsp, 0xF0
00007ff1409e2f53  vmovaps [rsp], xmm0
00007ff1409e2f58  vmovaps [rsp+0x10], xmm1
00007ff1409e2f5e  vmovaps [rsp+0x20], xmm2
00007ff1409e2f64  vmovaps [rsp+0x30], xmm3
00007ff1409e2f6a  vmovaps [rsp+0x40], xmm4
00007ff1409e2f70  vmovaps [rsp+0x50], xmm5
00007ff1409e2f76  vmovaps [rsp+0x60], xmm6
00007ff1409e2f7c  vmovaps [rsp+0x70], xmm7
00007ff1409e2f82  vmovaps [rsp+0x80], xmm8
00007ff1409e2f8b  vmovaps [rsp+0x90], xmm9
00007ff1409e2f94  vmovaps [rsp+0xA0], xmm10
00007ff1409e2f9d  vmovaps [rsp+0xB0], xmm12
00007ff1409e2fa6  vmovaps [rsp+0xC0], xmm13
00007ff1409e2faf  vmovaps [rsp+0xD0], xmm14
00007ff1409e2fb8  vmovaps [rsp+0xE0], xmm15
00007ff1409e2fc1  sub rsp, 0x30
00007ff1409e2fc5  movaps [rsp], xmm11
00007ff1409e2fca  movaps [rsp+0x10], xmm10
00007ff1409e2fd0  movaps [rsp+0x20], xmm6
00007ff1409e2fd5  lea rdi, [rsp]
00007ff1409e2fd9  mov esi, 0x00
00007ff1409e2fde  mov rax, 0x565C7F10C530
00007ff1409e2fe8  call rax
00007ff1409e2fea  movaps xmm11, [rsp]
00007ff1409e2fef  add rsp, 0x30
00007ff1409e2ff3  vmovaps xmm0, [rsp]
00007ff1409e2ff8  vmovaps xmm1, [rsp+0x10]
00007ff1409e2ffe  vmovaps xmm2, [rsp+0x20]
00007ff1409e3004  vmovaps xmm3, [rsp+0x30]
00007ff1409e300a  vmovaps xmm4, [rsp+0x40]
00007ff1409e3010  vmovaps xmm5, [rsp+0x50]
00007ff1409e3016  vmovaps xmm6, [rsp+0x60]
00007ff1409e301c  vmovaps xmm7, [rsp+0x70]
00007ff1409e3022  vmovaps xmm8, [rsp+0x80]
00007ff1409e302b  vmovaps xmm9, [rsp+0x90]
00007ff1409e3034  vmovaps xmm10, [rsp+0xA0]
00007ff1409e303d  vmovaps xmm12, [rsp+0xB0]
00007ff1409e3046  vmovaps xmm13, [rsp+0xC0]
00007ff1409e304f  vmovaps xmm14, [rsp+0xD0]
00007ff1409e3058  vmovaps xmm15, [rsp+0xE0]
00007ff1409e3061  add rsp, 0xF0
00007ff1409e3068  pop r11
00007ff1409e306a  pop r10
00007ff1409e306c  pop r9
00007ff1409e306e  pop r8
00007ff1409e3070  pop rsi
00007ff1409e3071  pop rdi
00007ff1409e3072  pop rdx
00007ff1409e3073  pop rcx
00007ff1409e3074  pop rax
00007ff1409e3075  add rsp, 0x08
00007ff1409e3079  jmp 0x00007FF1409DF700
00007ff1409e307e  sub rsp, 0x08
00007ff1409e3082  push rax
00007ff1409e3083  push rcx
00007ff1409e3084  push rdx
00007ff1409e3085  push rdi
00007ff1409e3086  push rsi
00007ff1409e3087  push r8
00007ff1409e3089  push r9
00007ff1409e308b  push r10
00007ff1409e308d  push r11
00007ff1409e308f  sub rsp, 0xF0
00007ff1409e3096  vmovaps [rsp], xmm0
00007ff1409e309b  vmovaps [rsp+0x10], xmm1
00007ff1409e30a1  vmovaps [rsp+0x20], xmm2
00007ff1409e30a7  vmovaps [rsp+0x30], xmm3
00007ff1409e30ad  vmovaps [rsp+0x40], xmm4
00007ff1409e30b3  vmovaps [rsp+0x50], xmm5
00007ff1409e30b9  vmovaps [rsp+0x60], xmm6
00007ff1409e30bf  vmovaps [rsp+0x70], xmm7
00007ff1409e30c5  vmovaps [rsp+0x80], xmm8
00007ff1409e30ce  vmovaps [rsp+0x90], xmm9
00007ff1409e30d7  vmovaps [rsp+0xA0], xmm11
00007ff1409e30e0  vmovaps [rsp+0xB0], xmm12
00007ff1409e30e9  vmovaps [rsp+0xC0], xmm13
00007ff1409e30f2  vmovaps [rsp+0xD0], xmm14
00007ff1409e30fb  vmovaps [rsp+0xE0], xmm15
00007ff1409e3104  sub rsp, 0x30
00007ff1409e3108  movaps [rsp], xmm10
00007ff1409e310d  movaps [rsp+0x10], xmm14
00007ff1409e3113  movaps [rsp+0x20], xmm4
00007ff1409e3118  lea rdi, [rsp]
00007ff1409e311c  mov esi, 0x00
00007ff1409e3121  mov rax, 0x565C7F10C530
00007ff1409e312b  call rax
00007ff1409e312d  movaps xmm10, [rsp]
00007ff1409e3132  add rsp, 0x30
00007ff1409e3136  vmovaps xmm0, [rsp]
00007ff1409e313b  vmovaps xmm1, [rsp+0x10]
00007ff1409e3141  vmovaps xmm2, [rsp+0x20]
00007ff1409e3147  vmovaps xmm3, [rsp+0x30]
00007ff1409e314d  vmovaps xmm4, [rsp+0x40]
00007ff1409e3153  vmovaps xmm5, [rsp+0x50]
00007ff1409e3159  vmovaps xmm6, [rsp+0x60]
00007ff1409e315f  vmovaps xmm7, [rsp+0x70]
00007ff1409e3165  vmovaps xmm8, [rsp+0x80]
00007ff1409e316e  vmovaps xmm9, [rsp+0x90]
00007ff1409e3177  vmovaps xmm11, [rsp+0xA0]
00007ff1409e3180  vmovaps xmm12, [rsp+0xB0]
00007ff1409e3189  vmovaps xmm13, [rsp+0xC0]
00007ff1409e3192  vmovaps xmm14, [rsp+0xD0]
00007ff1409e319b  vmovaps xmm15, [rsp+0xE0]
00007ff1409e31a4  add rsp, 0xF0
00007ff1409e31ab  pop r11
00007ff1409e31ad  pop r10
00007ff1409e31af  pop r9
00007ff1409e31b1  pop r8
00007ff1409e31b3  pop rsi
00007ff1409e31b4  pop rdi
00007ff1409e31b5  pop rdx
00007ff1409e31b6  pop rcx
00007ff1409e31b7  pop rax
00007ff1409e31b8  add rsp, 0x08
00007ff1409e31bc  jmp 0x00007FF1409DF71B
00007ff1409e31c1  sub rsp, 0x08
00007ff1409e31c5  push rax
00007ff1409e31c6  push rcx
00007ff1409e31c7  push rdx
00007ff1409e31c8  push rdi
00007ff1409e31c9  push rsi
00007ff1409e31ca  push r8
00007ff1409e31cc  push r9
00007ff1409e31ce  push r10
00007ff1409e31d0  push r11
00007ff1409e31d2  sub rsp, 0xF0
00007ff1409e31d9  vmovaps [rsp], xmm0
00007ff1409e31de  vmovaps [rsp+0x10], xmm1
00007ff1409e31e4  vmovaps [rsp+0x20], xmm2
00007ff1409e31ea  vmovaps [rsp+0x30], xmm3
00007ff1409e31f0  vmovaps [rsp+0x40], xmm4
00007ff1409e31f6  vmovaps [rsp+0x50], xmm5
00007ff1409e31fc  vmovaps [rsp+0x60], xmm6
00007ff1409e3202  vmovaps [rsp+0x70], xmm7
00007ff1409e3208  vmovaps [rsp+0x80], xmm9
00007ff1409e3211  vmovaps [rsp+0x90], xmm10
00007ff1409e321a  vmovaps [rsp+0xA0], xmm11
00007ff1409e3223  vmovaps [rsp+0xB0], xmm12
00007ff1409e322c  vmovaps [rsp+0xC0], xmm13
00007ff1409e3235  vmovaps [rsp+0xD0], xmm14
00007ff1409e323e  vmovaps [rsp+0xE0], xmm15
00007ff1409e3247  sub rsp, 0x30
00007ff1409e324b  movaps [rsp], xmm8
00007ff1409e3250  movaps [rsp+0x10], xmm1
00007ff1409e3255  movaps [rsp+0x20], xmm14
00007ff1409e325b  lea rdi, [rsp]
00007ff1409e325f  mov esi, 0x00
00007ff1409e3264  mov rax, 0x565C7F10C530
00007ff1409e326e  call rax
00007ff1409e3270  movaps xmm8, [rsp]
00007ff1409e3275  add rsp, 0x30
00007ff1409e3279  vmovaps xmm0, [rsp]
00007ff1409e327e  vmovaps xmm1, [rsp+0x10]
00007ff1409e3284  vmovaps xmm2, [rsp+0x20]
00007ff1409e328a  vmovaps xmm3, [rsp+0x30]
00007ff1409e3290  vmovaps xmm4, [rsp+0x40]
00007ff1409e3296  vmovaps xmm5, [rsp+0x50]
00007ff1409e329c  vmovaps xmm6, [rsp+0x60]
00007ff1409e32a2  vmovaps xmm7, [rsp+0x70]
00007ff1409e32a8  vmovaps xmm9, [rsp+0x80]
00007ff1409e32b1  vmovaps xmm10, [rsp+0x90]
00007ff1409e32ba  vmovaps xmm11, [rsp+0xA0]
00007ff1409e32c3  vmovaps xmm12, [rsp+0xB0]
00007ff1409e32cc  vmovaps xmm13, [rsp+0xC0]
00007ff1409e32d5  vmovaps xmm14, [rsp+0xD0]
00007ff1409e32de  vmovaps xmm15, [rsp+0xE0]
00007ff1409e32e7  add rsp, 0xF0
00007ff1409e32ee  pop r11
00007ff1409e32f0  pop r10
00007ff1409e32f2  pop r9
00007ff1409e32f4  pop r8
00007ff1409e32f6  pop rsi
00007ff1409e32f7  pop rdi
00007ff1409e32f8  pop rdx
00007ff1409e32f9  pop rcx
00007ff1409e32fa  pop rax
00007ff1409e32fb  add rsp, 0x08
00007ff1409e32ff  jmp 0x00007FF1409DF741
00007ff1409e3304  sub rsp, 0x08
00007ff1409e3308  push rax
00007ff1409e3309  push rcx
00007ff1409e330a  push rdx
00007ff1409e330b  push rdi
00007ff1409e330c  push rsi
00007ff1409e330d  push r8
00007ff1409e330f  push r9
00007ff1409e3311  push r10
00007ff1409e3313  push r11
00007ff1409e3315  sub rsp, 0xF0
00007ff1409e331c  vmovaps [rsp], xmm0
00007ff1409e3321  vmovaps [rsp+0x10], xmm1
00007ff1409e3327  vmovaps [rsp+0x20], xmm2
00007ff1409e332d  vmovaps [rsp+0x30], xmm3
00007ff1409e3333  vmovaps [rsp+0x40], xmm4
00007ff1409e3339  vmovaps [rsp+0x50], xmm5
00007ff1409e333f  vmovaps [rsp+0x60], xmm7
00007ff1409e3345  vmovaps [rsp+0x70], xmm8
00007ff1409e334b  vmovaps [rsp+0x80], xmm9
00007ff1409e3354  vmovaps [rsp+0x90], xmm10
00007ff1409e335d  vmovaps [rsp+0xA0], xmm11
00007ff1409e3366  vmovaps [rsp+0xB0], xmm12
00007ff1409e336f  vmovaps [rsp+0xC0], xmm13
00007ff1409e3378  vmovaps [rsp+0xD0], xmm14
00007ff1409e3381  vmovaps [rsp+0xE0], xmm15
00007ff1409e338a  sub rsp, 0x30
00007ff1409e338e  movaps [rsp], xmm6
00007ff1409e3392  movaps [rsp+0x10], xmm1
00007ff1409e3397  movaps [rsp+0x20], xmm14
00007ff1409e339d  lea rdi, [rsp]
00007ff1409e33a1  mov esi, 0x00
00007ff1409e33a6  mov rax, 0x565C7F10C530
00007ff1409e33b0  call rax
00007ff1409e33b2  movaps xmm6, [rsp]
00007ff1409e33b6  add rsp, 0x30
00007ff1409e33ba  vmovaps xmm0, [rsp]
00007ff1409e33bf  vmovaps xmm1, [rsp+0x10]
00007ff1409e33c5  vmovaps xmm2, [rsp+0x20]
00007ff1409e33cb  vmovaps xmm3, [rsp+0x30]
00007ff1409e33d1  vmovaps xmm4, [rsp+0x40]
00007ff1409e33d7  vmovaps xmm5, [rsp+0x50]
00007ff1409e33dd  vmovaps xmm7, [rsp+0x60]
00007ff1409e33e3  vmovaps xmm8, [rsp+0x70]
00007ff1409e33e9  vmovaps xmm9, [rsp+0x80]
00007ff1409e33f2  vmovaps xmm10, [rsp+0x90]
00007ff1409e33fb  vmovaps xmm11, [rsp+0xA0]
00007ff1409e3404  vmovaps xmm12, [rsp+0xB0]
00007ff1409e340d  vmovaps xmm13, [rsp+0xC0]
00007ff1409e3416  vmovaps xmm14, [rsp+0xD0]
00007ff1409e341f  vmovaps xmm15, [rsp+0xE0]
00007ff1409e3428  add rsp, 0xF0
00007ff1409e342f  pop r11
00007ff1409e3431  pop r10
00007ff1409e3433  pop r9
00007ff1409e3435  pop r8
00007ff1409e3437  pop rsi
00007ff1409e3438  pop rdi
00007ff1409e3439  pop rdx
00007ff1409e343a  pop rcx
00007ff1409e343b  pop rax
00007ff1409e343c  add rsp, 0x08
00007ff1409e3440  jmp 0x00007FF1409DF76D
00007ff1409e3445  sub rsp, 0x08
00007ff1409e3449  push rax
00007ff1409e344a  push rcx
00007ff1409e344b  push rdx
00007ff1409e344c  push rdi
00007ff1409e344d  push rsi
00007ff1409e344e  push r8
00007ff1409e3450  push r9
00007ff1409e3452  push r10
00007ff1409e3454  push r11
00007ff1409e3456  sub rsp, 0xF0
00007ff1409e345d  vmovaps [rsp], xmm0
00007ff1409e3462  vmovaps [rsp+0x10], xmm1
00007ff1409e3468  vmovaps [rsp+0x20], xmm2
00007ff1409e346e  vmovaps [rsp+0x30], xmm3
00007ff1409e3474  vmovaps [rsp+0x40], xmm4
00007ff1409e347a  vmovaps [rsp+0x50], xmm5
00007ff1409e3480  vmovaps [rsp+0x60], xmm6
00007ff1409e3486  vmovaps [rsp+0x70], xmm7
00007ff1409e348c  vmovaps [rsp+0x80], xmm8
00007ff1409e3495  vmovaps [rsp+0x90], xmm9
00007ff1409e349e  vmovaps [rsp+0xA0], xmm10
00007ff1409e34a7  vmovaps [rsp+0xB0], xmm11
00007ff1409e34b0  vmovaps [rsp+0xC0], xmm12
00007ff1409e34b9  vmovaps [rsp+0xD0], xmm13
00007ff1409e34c2  vmovaps [rsp+0xE0], xmm15
00007ff1409e34cb  sub rsp, 0x30
00007ff1409e34cf  movaps [rsp], xmm14
00007ff1409e34d4  movaps [rsp+0x10], xmm12
00007ff1409e34da  movaps [rsp+0x20], xmm1
00007ff1409e34df  lea rdi, [rsp]
00007ff1409e34e3  mov esi, 0x00
00007ff1409e34e8  mov rax, 0x565C7F10C530
00007ff1409e34f2  call rax
00007ff1409e34f4  movaps xmm14, [rsp]
00007ff1409e34f9  add rsp, 0x30
00007ff1409e34fd  vmovaps xmm0, [rsp]
00007ff1409e3502  vmovaps xmm1, [rsp+0x10]
00007ff1409e3508  vmovaps xmm2, [rsp+0x20]
00007ff1409e350e  vmovaps xmm3, [rsp+0x30]
00007ff1409e3514  vmovaps xmm4, [rsp+0x40]
00007ff1409e351a  vmovaps xmm5, [rsp+0x50]
00007ff1409e3520  vmovaps xmm6, [rsp+0x60]
00007ff1409e3526  vmovaps xmm7, [rsp+0x70]
00007ff1409e352c  vmovaps xmm8, [rsp+0x80]
00007ff1409e3535  vmovaps xmm9, [rsp+0x90]
00007ff1409e353e  vmovaps xmm10, [rsp+0xA0]
00007ff1409e3547  vmovaps xmm11, [rsp+0xB0]
00007ff1409e3550  vmovaps xmm12, [rsp+0xC0]
00007ff1409e3559  vmovaps xmm13, [rsp+0xD0]
00007ff1409e3562  vmovaps xmm15, [rsp+0xE0]
00007ff1409e356b  add rsp, 0xF0
00007ff1409e3572  pop r11
00007ff1409e3574  pop r10
00007ff1409e3576  pop r9
00007ff1409e3578  pop r8
00007ff1409e357a  pop rsi
00007ff1409e357b  pop rdi
00007ff1409e357c  pop rdx
00007ff1409e357d  pop rcx
00007ff1409e357e  pop rax
00007ff1409e357f  add rsp, 0x08
00007ff1409e3583  jmp 0x00007FF1409DF793
00007ff1409e3588  sub rsp, 0x08
00007ff1409e358c  push rax
00007ff1409e358d  push rcx
00007ff1409e358e  push rdx
00007ff1409e358f  push rdi
00007ff1409e3590  push rsi
00007ff1409e3591  push r8
00007ff1409e3593  push r9
00007ff1409e3595  push r10
00007ff1409e3597  push r11
00007ff1409e3599  sub rsp, 0xF0
00007ff1409e35a0  vmovaps [rsp], xmm0
00007ff1409e35a5  vmovaps [rsp+0x10], xmm2
00007ff1409e35ab  vmovaps [rsp+0x20], xmm3
00007ff1409e35b1  vmovaps [rsp+0x30], xmm4
00007ff1409e35b7  vmovaps [rsp+0x40], xmm5
00007ff1409e35bd  vmovaps [rsp+0x50], xmm6
00007ff1409e35c3  vmovaps [rsp+0x60], xmm7
00007ff1409e35c9  vmovaps [rsp+0x70], xmm8
00007ff1409e35cf  vmovaps [rsp+0x80], xmm9
00007ff1409e35d8  vmovaps [rsp+0x90], xmm10
00007ff1409e35e1  vmovaps [rsp+0xA0], xmm11
00007ff1409e35ea  vmovaps [rsp+0xB0], xmm12
00007ff1409e35f3  vmovaps [rsp+0xC0], xmm13
00007ff1409e35fc  vmovaps [rsp+0xD0], xmm14
00007ff1409e3605  vmovaps [rsp+0xE0], xmm15
00007ff1409e360e  sub rsp, 0x30
00007ff1409e3612  movaps [rsp], xmm1
00007ff1409e3616  movaps [rsp+0x10], xmm13
00007ff1409e361c  movaps [rsp+0x20], xmm9
00007ff1409e3622  lea rdi, [rsp]
00007ff1409e3626  mov esi, 0x00
00007ff1409e362b  mov rax, 0x565C7F10C530
00007ff1409e3635  call rax
00007ff1409e3637  movaps xmm1, [rsp]
00007ff1409e363b  add rsp, 0x30
00007ff1409e363f  vmovaps xmm0, [rsp]
00007ff1409e3644  vmovaps xmm2, [rsp+0x10]
00007ff1409e364a  vmovaps xmm3, [rsp+0x20]
00007ff1409e3650  vmovaps xmm4, [rsp+0x30]
00007ff1409e3656  vmovaps xmm5, [rsp+0x40]
00007ff1409e365c  vmovaps xmm6, [rsp+0x50]
00007ff1409e3662  vmovaps xmm7, [rsp+0x60]
00007ff1409e3668  vmovaps xmm8, [rsp+0x70]
00007ff1409e366e  vmovaps xmm9, [rsp+0x80]
00007ff1409e3677  vmovaps xmm10, [rsp+0x90]
00007ff1409e3680  vmovaps xmm11, [rsp+0xA0]
00007ff1409e3689  vmovaps xmm12, [rsp+0xB0]
00007ff1409e3692  vmovaps xmm13, [rsp+0xC0]
00007ff1409e369b  vmovaps xmm14, [rsp+0xD0]
00007ff1409e36a4  vmovaps xmm15, [rsp+0xE0]
00007ff1409e36ad  add rsp, 0xF0
00007ff1409e36b4  pop r11
00007ff1409e36b6  pop r10
00007ff1409e36b8  pop r9
00007ff1409e36ba  pop r8
00007ff1409e36bc  pop rsi
00007ff1409e36bd  pop rdi
00007ff1409e36be  pop rdx
00007ff1409e36bf  pop rcx
00007ff1409e36c0  pop rax
00007ff1409e36c1  add rsp, 0x08
00007ff1409e36c5  jmp 0x00007FF1409DF7AD
00007ff1409e36ca  sub rsp, 0x08
00007ff1409e36ce  push rax
00007ff1409e36cf  push rcx
00007ff1409e36d0  push rdx
00007ff1409e36d1  push rdi
00007ff1409e36d2  push rsi
00007ff1409e36d3  push r8
00007ff1409e36d5  push r9
00007ff1409e36d7  push r10
00007ff1409e36d9  push r11
00007ff1409e36db  sub rsp, 0xF0
00007ff1409e36e2  vmovaps [rsp], xmm0
00007ff1409e36e7  vmovaps [rsp+0x10], xmm1
00007ff1409e36ed  vmovaps [rsp+0x20], xmm2
00007ff1409e36f3  vmovaps [rsp+0x30], xmm3
00007ff1409e36f9  vmovaps [rsp+0x40], xmm4
00007ff1409e36ff  vmovaps [rsp+0x50], xmm5
00007ff1409e3705  vmovaps [rsp+0x60], xmm6
00007ff1409e370b  vmovaps [rsp+0x70], xmm7
00007ff1409e3711  vmovaps [rsp+0x80], xmm8
00007ff1409e371a  vmovaps [rsp+0x90], xmm9
00007ff1409e3723  vmovaps [rsp+0xA0], xmm10
00007ff1409e372c  vmovaps [rsp+0xB0], xmm11
00007ff1409e3735  vmovaps [rsp+0xC0], xmm13
00007ff1409e373e  vmovaps [rsp+0xD0], xmm14
00007ff1409e3747  vmovaps [rsp+0xE0], xmm15
00007ff1409e3750  sub rsp, 0x30
00007ff1409e3754  movaps [rsp], xmm12
00007ff1409e3759  movaps [rsp+0x10], xmm7
00007ff1409e375e  movaps [rsp+0x20], xmm13
00007ff1409e3764  lea rdi, [rsp]
00007ff1409e3768  mov esi, 0x00
00007ff1409e376d  mov rax, 0x565C7F10C530
00007ff1409e3777  call rax
00007ff1409e3779  movaps xmm12, [rsp]
00007ff1409e377e  add rsp, 0x30
00007ff1409e3782  vmovaps xmm0, [rsp]
00007ff1409e3787  vmovaps xmm1, [rsp+0x10]
00007ff1409e378d  vmovaps xmm2, [rsp+0x20]
00007ff1409e3793  vmovaps xmm3, [rsp+0x30]
00007ff1409e3799  vmovaps xmm4, [rsp+0x40]
00007ff1409e379f  vmovaps xmm5, [rsp+0x50]
00007ff1409e37a5  vmovaps xmm6, [rsp+0x60]
00007ff1409e37ab  vmovaps xmm7, [rsp+0x70]
00007ff1409e37b1  vmovaps xmm8, [rsp+0x80]
00007ff1409e37ba  vmovaps xmm9, [rsp+0x90]
00007ff1409e37c3  vmovaps xmm10, [rsp+0xA0]
00007ff1409e37cc  vmovaps xmm11, [rsp+0xB0]
00007ff1409e37d5  vmovaps xmm13, [rsp+0xC0]
00007ff1409e37de  vmovaps xmm14, [rsp+0xD0]
00007ff1409e37e7  vmovaps xmm15, [rsp+0xE0]
00007ff1409e37f0  add rsp, 0xF0
00007ff1409e37f7  pop r11
00007ff1409e37f9  pop r10
00007ff1409e37fb  pop r9
00007ff1409e37fd  pop r8
00007ff1409e37ff  pop rsi
00007ff1409e3800  pop rdi
00007ff1409e3801  pop rdx
00007ff1409e3802  pop rcx
00007ff1409e3803  pop rax
00007ff1409e3804  add rsp, 0x08
00007ff1409e3808  jmp 0x00007FF1409DF7D4
00007ff1409e380d  sub rsp, 0x08
00007ff1409e3811  push rax
00007ff1409e3812  push rcx
00007ff1409e3813  push rdx
00007ff1409e3814  push rdi
00007ff1409e3815  push rsi
00007ff1409e3816  push r8
00007ff1409e3818  push r9
00007ff1409e381a  push r10
00007ff1409e381c  push r11
00007ff1409e381e  sub rsp, 0xF0
00007ff1409e3825  vmovaps [rsp], xmm0
00007ff1409e382a  vmovaps [rsp+0x10], xmm1
00007ff1409e3830  vmovaps [rsp+0x20], xmm2
00007ff1409e3836  vmovaps [rsp+0x30], xmm3
00007ff1409e383c  vmovaps [rsp+0x40], xmm4
00007ff1409e3842  vmovaps [rsp+0x50], xmm5
00007ff1409e3848  vmovaps [rsp+0x60], xmm6
00007ff1409e384e  vmovaps [rsp+0x70], xmm7
00007ff1409e3854  vmovaps [rsp+0x80], xmm8
00007ff1409e385d  vmovaps [rsp+0x90], xmm9
00007ff1409e3866  vmovaps [rsp+0xA0], xmm10
00007ff1409e386f  vmovaps [rsp+0xB0], xmm11
00007ff1409e3878  vmovaps [rsp+0xC0], xmm12
00007ff1409e3881  vmovaps [rsp+0xD0], xmm14
00007ff1409e388a  vmovaps [rsp+0xE0], xmm15
00007ff1409e3893  sub rsp, 0x30
00007ff1409e3897  movaps [rsp], xmm13
00007ff1409e389c  movaps [rsp+0x10], xmm15
00007ff1409e38a2  movaps [rsp+0x20], xmm8
00007ff1409e38a8  lea rdi, [rsp]
00007ff1409e38ac  mov esi, 0x00
00007ff1409e38b1  mov rax, 0x565C7F10C530
00007ff1409e38bb  call rax
00007ff1409e38bd  movaps xmm13, [rsp]
00007ff1409e38c2  add rsp, 0x30
00007ff1409e38c6  vmovaps xmm0, [rsp]
00007ff1409e38cb  vmovaps xmm1, [rsp+0x10]
00007ff1409e38d1  vmovaps xmm2, [rsp+0x20]
00007ff1409e38d7  vmovaps xmm3, [rsp+0x30]
00007ff1409e38dd  vmovaps xmm4, [rsp+0x40]
00007ff1409e38e3  vmovaps xmm5, [rsp+0x50]
00007ff1409e38e9  vmovaps xmm6, [rsp+0x60]
00007ff1409e38ef  vmovaps xmm7, [rsp+0x70]
00007ff1409e38f5  vmovaps xmm8, [rsp+0x80]
00007ff1409e38fe  vmovaps xmm9, [rsp+0x90]
00007ff1409e3907  vmovaps xmm10, [rsp+0xA0]
00007ff1409e3910  vmovaps xmm11, [rsp+0xB0]
00007ff1409e3919  vmovaps xmm12, [rsp+0xC0]
00007ff1409e3922  vmovaps xmm14, [rsp+0xD0]
00007ff1409e392b  vmovaps xmm15, [rsp+0xE0]
00007ff1409e3934  add rsp, 0xF0
00007ff1409e393b  pop r11
00007ff1409e393d  pop r10
00007ff1409e393f  pop r9
00007ff1409e3941  pop r8
00007ff1409e3943  pop rsi
00007ff1409e3944  pop rdi
00007ff1409e3945  pop rdx
00007ff1409e3946  pop rcx
00007ff1409e3947  pop rax
00007ff1409e3948  add rsp, 0x08
00007ff1409e394c  jmp 0x00007FF1409DF7EF
00007ff1409e3951  sub rsp, 0x08
00007ff1409e3955  push rax
00007ff1409e3956  push rcx
00007ff1409e3957  push rdx
00007ff1409e3958  push rdi
00007ff1409e3959  push rsi
00007ff1409e395a  push r8
00007ff1409e395c  push r9
00007ff1409e395e  push r10
00007ff1409e3960  push r11
00007ff1409e3962  sub rsp, 0xF0
00007ff1409e3969  vmovaps [rsp], xmm0
00007ff1409e396e  vmovaps [rsp+0x10], xmm1
00007ff1409e3974  vmovaps [rsp+0x20], xmm2
00007ff1409e397a  vmovaps [rsp+0x30], xmm3
00007ff1409e3980  vmovaps [rsp+0x40], xmm4
00007ff1409e3986  vmovaps [rsp+0x50], xmm5
00007ff1409e398c  vmovaps [rsp+0x60], xmm6
00007ff1409e3992  vmovaps [rsp+0x70], xmm7
00007ff1409e3998  vmovaps [rsp+0x80], xmm9
00007ff1409e39a1  vmovaps [rsp+0x90], xmm10
00007ff1409e39aa  vmovaps [rsp+0xA0], xmm11
00007ff1409e39b3  vmovaps [rsp+0xB0], xmm12
00007ff1409e39bc  vmovaps [rsp+0xC0], xmm13
00007ff1409e39c5  vmovaps [rsp+0xD0], xmm14
00007ff1409e39ce  vmovaps [rsp+0xE0], xmm15
00007ff1409e39d7  sub rsp, 0x30
00007ff1409e39db  movaps [rsp], xmm8
00007ff1409e39e0  movaps [rsp+0x10], xmm15
00007ff1409e39e6  movaps [rsp+0x20], xmm9
00007ff1409e39ec  lea rdi, [rsp]
00007ff1409e39f0  mov esi, 0x00
00007ff1409e39f5  mov rax, 0x565C7F10C530
00007ff1409e39ff  call rax
00007ff1409e3a01  movaps xmm8, [rsp]
00007ff1409e3a06  add rsp, 0x30
00007ff1409e3a0a  vmovaps xmm0, [rsp]
00007ff1409e3a0f  vmovaps xmm1, [rsp+0x10]
00007ff1409e3a15  vmovaps xmm2, [rsp+0x20]
00007ff1409e3a1b  vmovaps xmm3, [rsp+0x30]
00007ff1409e3a21  vmovaps xmm4, [rsp+0x40]
00007ff1409e3a27  vmovaps xmm5, [rsp+0x50]
00007ff1409e3a2d  vmovaps xmm6, [rsp+0x60]
00007ff1409e3a33  vmovaps xmm7, [rsp+0x70]
00007ff1409e3a39  vmovaps xmm9, [rsp+0x80]
00007ff1409e3a42  vmovaps xmm10, [rsp+0x90]
00007ff1409e3a4b  vmovaps xmm11, [rsp+0xA0]
00007ff1409e3a54  vmovaps xmm12, [rsp+0xB0]
00007ff1409e3a5d  vmovaps xmm13, [rsp+0xC0]
00007ff1409e3a66  vmovaps xmm14, [rsp+0xD0]
00007ff1409e3a6f  vmovaps xmm15, [rsp+0xE0]
00007ff1409e3a78  add rsp, 0xF0
00007ff1409e3a7f  pop r11
00007ff1409e3a81  pop r10
00007ff1409e3a83  pop r9
00007ff1409e3a85  pop r8
00007ff1409e3a87  pop rsi
00007ff1409e3a88  pop rdi
00007ff1409e3a89  pop rdx
00007ff1409e3a8a  pop rcx
00007ff1409e3a8b  pop rax
00007ff1409e3a8c  add rsp, 0x08
00007ff1409e3a90  jmp 0x00007FF1409DF81D
00007ff1409e3a95  sub rsp, 0x08
00007ff1409e3a99  push rax
00007ff1409e3a9a  push rcx
00007ff1409e3a9b  push rdx
00007ff1409e3a9c  push rdi
00007ff1409e3a9d  push rsi
00007ff1409e3a9e  push r8
00007ff1409e3aa0  push r9
00007ff1409e3aa2  push r10
00007ff1409e3aa4  push r11
00007ff1409e3aa6  sub rsp, 0xF0
00007ff1409e3aad  vmovaps [rsp], xmm0
00007ff1409e3ab2  vmovaps [rsp+0x10], xmm1
00007ff1409e3ab8  vmovaps [rsp+0x20], xmm2
00007ff1409e3abe  vmovaps [rsp+0x30], xmm3
00007ff1409e3ac4  vmovaps [rsp+0x40], xmm4
00007ff1409e3aca  vmovaps [rsp+0x50], xmm5
00007ff1409e3ad0  vmovaps [rsp+0x60], xmm6
00007ff1409e3ad6  vmovaps [rsp+0x70], xmm7
00007ff1409e3adc  vmovaps [rsp+0x80], xmm8
00007ff1409e3ae5  vmovaps [rsp+0x90], xmm9
00007ff1409e3aee  vmovaps [rsp+0xA0], xmm10
00007ff1409e3af7  vmovaps [rsp+0xB0], xmm11
00007ff1409e3b00  vmovaps [rsp+0xC0], xmm12
00007ff1409e3b09  vmovaps [rsp+0xD0], xmm13
00007ff1409e3b12  vmovaps [rsp+0xE0], xmm14
00007ff1409e3b1b  sub rsp, 0x30
00007ff1409e3b1f  movaps [rsp], xmm15
00007ff1409e3b24  movaps [rsp+0x10], xmm11
00007ff1409e3b2a  movaps [rsp+0x20], xmm6
00007ff1409e3b2f  lea rdi, [rsp]
00007ff1409e3b33  mov esi, 0x00
00007ff1409e3b38  mov rax, 0x565C7F10C530
00007ff1409e3b42  call rax
00007ff1409e3b44  movaps xmm15, [rsp]
00007ff1409e3b49  add rsp, 0x30
00007ff1409e3b4d  vmovaps xmm0, [rsp]
00007ff1409e3b52  vmovaps xmm1, [rsp+0x10]
00007ff1409e3b58  vmovaps xmm2, [rsp+0x20]
00007ff1409e3b5e  vmovaps xmm3, [rsp+0x30]
00007ff1409e3b64  vmovaps xmm4, [rsp+0x40]
00007ff1409e3b6a  vmovaps xmm5, [rsp+0x50]
00007ff1409e3b70  vmovaps xmm6, [rsp+0x60]
00007ff1409e3b76  vmovaps xmm7, [rsp+0x70]
00007ff1409e3b7c  vmovaps xmm8, [rsp+0x80]
00007ff1409e3b85  vmovaps xmm9, [rsp+0x90]
00007ff1409e3b8e  vmovaps xmm10, [rsp+0xA0]
00007ff1409e3b97  vmovaps xmm11, [rsp+0xB0]
00007ff1409e3ba0  vmovaps xmm12, [rsp+0xC0]
00007ff1409e3ba9  vmovaps xmm13, [rsp+0xD0]
00007ff1409e3bb2  vmovaps xmm14, [rsp+0xE0]
00007ff1409e3bbb  add rsp, 0xF0
00007ff1409e3bc2  pop r11
00007ff1409e3bc4  pop r10
00007ff1409e3bc6  pop r9
00007ff1409e3bc8  pop r8
00007ff1409e3bca  pop rsi
00007ff1409e3bcb  pop rdi
00007ff1409e3bcc  pop rdx
00007ff1409e3bcd  pop rcx
00007ff1409e3bce  pop rax
00007ff1409e3bcf  add rsp, 0x08
00007ff1409e3bd3  jmp 0x00007FF1409DF838
00007ff1409e3bd8  sub rsp, 0x08
00007ff1409e3bdc  push rax
00007ff1409e3bdd  push rcx
00007ff1409e3bde  push rdx
00007ff1409e3bdf  push rdi
00007ff1409e3be0  push rsi
00007ff1409e3be1  push r8
00007ff1409e3be3  push r9
00007ff1409e3be5  push r10
00007ff1409e3be7  push r11
00007ff1409e3be9  sub rsp, 0xF0
00007ff1409e3bf0  vmovaps [rsp], xmm0
00007ff1409e3bf5  vmovaps [rsp+0x10], xmm1
00007ff1409e3bfb  vmovaps [rsp+0x20], xmm2
00007ff1409e3c01  vmovaps [rsp+0x30], xmm3
00007ff1409e3c07  vmovaps [rsp+0x40], xmm4
00007ff1409e3c0d  vmovaps [rsp+0x50], xmm5
00007ff1409e3c13  vmovaps [rsp+0x60], xmm6
00007ff1409e3c19  vmovaps [rsp+0x70], xmm8
00007ff1409e3c1f  vmovaps [rsp+0x80], xmm9
00007ff1409e3c28  vmovaps [rsp+0x90], xmm10
00007ff1409e3c31  vmovaps [rsp+0xA0], xmm11
00007ff1409e3c3a  vmovaps [rsp+0xB0], xmm12
00007ff1409e3c43  vmovaps [rsp+0xC0], xmm13
00007ff1409e3c4c  vmovaps [rsp+0xD0], xmm14
00007ff1409e3c55  vmovaps [rsp+0xE0], xmm15
00007ff1409e3c5e  sub rsp, 0x30
00007ff1409e3c62  movaps [rsp], xmm7
00007ff1409e3c66  movaps [rsp+0x10], xmm11
00007ff1409e3c6c  movaps [rsp+0x20], xmm9
00007ff1409e3c72  lea rdi, [rsp]
00007ff1409e3c76  mov esi, 0x00
00007ff1409e3c7b  mov rax, 0x565C7F10C530
00007ff1409e3c85  call rax
00007ff1409e3c87  movaps xmm7, [rsp]
00007ff1409e3c8b  add rsp, 0x30
00007ff1409e3c8f  vmovaps xmm0, [rsp]
00007ff1409e3c94  vmovaps xmm1, [rsp+0x10]
00007ff1409e3c9a  vmovaps xmm2, [rsp+0x20]
00007ff1409e3ca0  vmovaps xmm3, [rsp+0x30]
00007ff1409e3ca6  vmovaps xmm4, [rsp+0x40]
00007ff1409e3cac  vmovaps xmm5, [rsp+0x50]
00007ff1409e3cb2  vmovaps xmm6, [rsp+0x60]
00007ff1409e3cb8  vmovaps xmm8, [rsp+0x70]
00007ff1409e3cbe  vmovaps xmm9, [rsp+0x80]
00007ff1409e3cc7  vmovaps xmm10, [rsp+0x90]
00007ff1409e3cd0  vmovaps xmm11, [rsp+0xA0]
00007ff1409e3cd9  vmovaps xmm12, [rsp+0xB0]
00007ff1409e3ce2  vmovaps xmm13, [rsp+0xC0]
00007ff1409e3ceb  vmovaps xmm14, [rsp+0xD0]
00007ff1409e3cf4  vmovaps xmm15, [rsp+0xE0]
00007ff1409e3cfd  add rsp, 0xF0
00007ff1409e3d04  pop r11
00007ff1409e3d06  pop r10
00007ff1409e3d08  pop r9
00007ff1409e3d0a  pop r8
00007ff1409e3d0c  pop rsi
00007ff1409e3d0d  pop rdi
00007ff1409e3d0e  pop rdx
00007ff1409e3d0f  pop rcx
00007ff1409e3d10  pop rax
00007ff1409e3d11  add rsp, 0x08
00007ff1409e3d15  jmp 0x00007FF1409DF865
00007ff1409e3d1a  sub rsp, 0x08
00007ff1409e3d1e  push rax
00007ff1409e3d1f  push rcx
00007ff1409e3d20  push rdx
00007ff1409e3d21  push rdi
00007ff1409e3d22  push rsi
00007ff1409e3d23  push r8
00007ff1409e3d25  push r9
00007ff1409e3d27  push r10
00007ff1409e3d29  push r11
00007ff1409e3d2b  sub rsp, 0xF0
00007ff1409e3d32  vmovaps [rsp], xmm0
00007ff1409e3d37  vmovaps [rsp+0x10], xmm1
00007ff1409e3d3d  vmovaps [rsp+0x20], xmm2
00007ff1409e3d43  vmovaps [rsp+0x30], xmm3
00007ff1409e3d49  vmovaps [rsp+0x40], xmm4
00007ff1409e3d4f  vmovaps [rsp+0x50], xmm5
00007ff1409e3d55  vmovaps [rsp+0x60], xmm6
00007ff1409e3d5b  vmovaps [rsp+0x70], xmm7
00007ff1409e3d61  vmovaps [rsp+0x80], xmm8
00007ff1409e3d6a  vmovaps [rsp+0x90], xmm9
00007ff1409e3d73  vmovaps [rsp+0xA0], xmm10
00007ff1409e3d7c  vmovaps [rsp+0xB0], xmm12
00007ff1409e3d85  vmovaps [rsp+0xC0], xmm13
00007ff1409e3d8e  vmovaps [rsp+0xD0], xmm14
00007ff1409e3d97  vmovaps [rsp+0xE0], xmm15
00007ff1409e3da0  sub rsp, 0x30
00007ff1409e3da4  movaps [rsp], xmm11
00007ff1409e3da9  movaps [rsp+0x10], xmm10
00007ff1409e3daf  movaps [rsp+0x20], xmm14
00007ff1409e3db5  lea rdi, [rsp]
00007ff1409e3db9  mov esi, 0x00
00007ff1409e3dbe  mov rax, 0x565C7F10C530
00007ff1409e3dc8  call rax
00007ff1409e3dca  movaps xmm11, [rsp]
00007ff1409e3dcf  add rsp, 0x30
00007ff1409e3dd3  vmovaps xmm0, [rsp]
00007ff1409e3dd8  vmovaps xmm1, [rsp+0x10]
00007ff1409e3dde  vmovaps xmm2, [rsp+0x20]
00007ff1409e3de4  vmovaps xmm3, [rsp+0x30]
00007ff1409e3dea  vmovaps xmm4, [rsp+0x40]
00007ff1409e3df0  vmovaps xmm5, [rsp+0x50]
00007ff1409e3df6  vmovaps xmm6, [rsp+0x60]
00007ff1409e3dfc  vmovaps xmm7, [rsp+0x70]
00007ff1409e3e02  vmovaps xmm8, [rsp+0x80]
00007ff1409e3e0b  vmovaps xmm9, [rsp+0x90]
00007ff1409e3e14  vmovaps xmm10, [rsp+0xA0]
00007ff1409e3e1d  vmovaps xmm12, [rsp+0xB0]
00007ff1409e3e26  vmovaps xmm13, [rsp+0xC0]
00007ff1409e3e2f  vmovaps xmm14, [rsp+0xD0]
00007ff1409e3e38  vmovaps xmm15, [rsp+0xE0]
00007ff1409e3e41  add rsp, 0xF0
00007ff1409e3e48  pop r11
00007ff1409e3e4a  pop r10
00007ff1409e3e4c  pop r9
00007ff1409e3e4e  pop r8
00007ff1409e3e50  pop rsi
00007ff1409e3e51  pop rdi
00007ff1409e3e52  pop rdx
00007ff1409e3e53  pop rcx
00007ff1409e3e54  pop rax
00007ff1409e3e55  add rsp, 0x08
00007ff1409e3e59  jmp 0x00007FF1409DF880
00007ff1409e3e5e  call 0x00007FF1408C33A0
00007ff1409e3e63  jmp 0x00007FF1409DF88A
00007ff1409e3e68  sub rsp, 0x08
00007ff1409e3e6c  push rax
00007ff1409e3e6d  push rcx
00007ff1409e3e6e  push rdx
00007ff1409e3e6f  push rdi
00007ff1409e3e70  push rsi
00007ff1409e3e71  push r8
00007ff1409e3e73  push r9
00007ff1409e3e75  push r10
00007ff1409e3e77  push r11
00007ff1409e3e79  sub rsp, 0xF0
00007ff1409e3e80  vmovaps [rsp], xmm0
00007ff1409e3e85  vmovaps [rsp+0x10], xmm1
00007ff1409e3e8b  vmovaps [rsp+0x20], xmm2
00007ff1409e3e91  vmovaps [rsp+0x30], xmm3
00007ff1409e3e97  vmovaps [rsp+0x40], xmm4
00007ff1409e3e9d  vmovaps [rsp+0x50], xmm5
00007ff1409e3ea3  vmovaps [rsp+0x60], xmm6
00007ff1409e3ea9  vmovaps [rsp+0x70], xmm7
00007ff1409e3eaf  vmovaps [rsp+0x80], xmm8
00007ff1409e3eb8  vmovaps [rsp+0x90], xmm9
00007ff1409e3ec1  vmovaps [rsp+0xA0], xmm11
00007ff1409e3eca  vmovaps [rsp+0xB0], xmm12
00007ff1409e3ed3  vmovaps [rsp+0xC0], xmm13
00007ff1409e3edc  vmovaps [rsp+0xD0], xmm14
00007ff1409e3ee5  vmovaps [rsp+0xE0], xmm15
00007ff1409e3eee  sub rsp, 0x30
00007ff1409e3ef2  movaps [rsp], xmm10
00007ff1409e3ef7  movaps [rsp+0x10], xmm1
00007ff1409e3efc  movaps [rsp+0x20], xmm12
00007ff1409e3f02  lea rdi, [rsp]
00007ff1409e3f06  mov esi, 0x00
00007ff1409e3f0b  mov rax, 0x565C7F10C530
00007ff1409e3f15  call rax
00007ff1409e3f17  movaps xmm10, [rsp]
00007ff1409e3f1c  add rsp, 0x30
00007ff1409e3f20  vmovaps xmm0, [rsp]
00007ff1409e3f25  vmovaps xmm1, [rsp+0x10]
00007ff1409e3f2b  vmovaps xmm2, [rsp+0x20]
00007ff1409e3f31  vmovaps xmm3, [rsp+0x30]
00007ff1409e3f37  vmovaps xmm4, [rsp+0x40]
00007ff1409e3f3d  vmovaps xmm5, [rsp+0x50]
00007ff1409e3f43  vmovaps xmm6, [rsp+0x60]
00007ff1409e3f49  vmovaps xmm7, [rsp+0x70]
00007ff1409e3f4f  vmovaps xmm8, [rsp+0x80]
00007ff1409e3f58  vmovaps xmm9, [rsp+0x90]
00007ff1409e3f61  vmovaps xmm11, [rsp+0xA0]
00007ff1409e3f6a  vmovaps xmm12, [rsp+0xB0]
00007ff1409e3f73  vmovaps xmm13, [rsp+0xC0]
00007ff1409e3f7c  vmovaps xmm14, [rsp+0xD0]
00007ff1409e3f85  vmovaps xmm15, [rsp+0xE0]
00007ff1409e3f8e  add rsp, 0xF0
00007ff1409e3f95  pop r11
00007ff1409e3f97  pop r10
00007ff1409e3f99  pop r9
00007ff1409e3f9b  pop r8
00007ff1409e3f9d  pop rsi
00007ff1409e3f9e  pop rdi
00007ff1409e3f9f  pop rdx
00007ff1409e3fa0  pop rcx
00007ff1409e3fa1  pop rax
00007ff1409e3fa2  add rsp, 0x08
00007ff1409e3fa6  jmp 0x00007FF1409DF8AD
00007ff1409e3fab  sub rsp, 0x08
00007ff1409e3faf  push rax
00007ff1409e3fb0  push rcx
00007ff1409e3fb1  push rdx
00007ff1409e3fb2  push rdi
00007ff1409e3fb3  push rsi
00007ff1409e3fb4  push r8
00007ff1409e3fb6  push r9
00007ff1409e3fb8  push r10
00007ff1409e3fba  push r11
00007ff1409e3fbc  sub rsp, 0xF0
00007ff1409e3fc3  vmovaps [rsp], xmm0
00007ff1409e3fc8  vmovaps [rsp+0x10], xmm1
00007ff1409e3fce  vmovaps [rsp+0x20], xmm2
00007ff1409e3fd4  vmovaps [rsp+0x30], xmm3
00007ff1409e3fda  vmovaps [rsp+0x40], xmm4
00007ff1409e3fe0  vmovaps [rsp+0x50], xmm5
00007ff1409e3fe6  vmovaps [rsp+0x60], xmm6
00007ff1409e3fec  vmovaps [rsp+0x70], xmm7
00007ff1409e3ff2  vmovaps [rsp+0x80], xmm8
00007ff1409e3ffb  vmovaps [rsp+0x90], xmm9
00007ff1409e4004  vmovaps [rsp+0xA0], xmm10
00007ff1409e400d  vmovaps [rsp+0xB0], xmm11
00007ff1409e4016  vmovaps [rsp+0xC0], xmm13
00007ff1409e401f  vmovaps [rsp+0xD0], xmm14
00007ff1409e4028  vmovaps [rsp+0xE0], xmm15
00007ff1409e4031  sub rsp, 0x30
00007ff1409e4035  movaps [rsp], xmm12
00007ff1409e403a  movaps [rsp+0x10], xmm14
00007ff1409e4040  movaps [rsp+0x20], xmm1
00007ff1409e4045  lea rdi, [rsp]
00007ff1409e4049  mov esi, 0x00
00007ff1409e404e  mov rax, 0x565C7F10C530
00007ff1409e4058  call rax
00007ff1409e405a  movaps xmm12, [rsp]
00007ff1409e405f  add rsp, 0x30
00007ff1409e4063  vmovaps xmm0, [rsp]
00007ff1409e4068  vmovaps xmm1, [rsp+0x10]
00007ff1409e406e  vmovaps xmm2, [rsp+0x20]
00007ff1409e4074  vmovaps xmm3, [rsp+0x30]
00007ff1409e407a  vmovaps xmm4, [rsp+0x40]
00007ff1409e4080  vmovaps xmm5, [rsp+0x50]
00007ff1409e4086  vmovaps xmm6, [rsp+0x60]
00007ff1409e408c  vmovaps xmm7, [rsp+0x70]
00007ff1409e4092  vmovaps xmm8, [rsp+0x80]
00007ff1409e409b  vmovaps xmm9, [rsp+0x90]
00007ff1409e40a4  vmovaps xmm10, [rsp+0xA0]
00007ff1409e40ad  vmovaps xmm11, [rsp+0xB0]
00007ff1409e40b6  vmovaps xmm13, [rsp+0xC0]
00007ff1409e40bf  vmovaps xmm14, [rsp+0xD0]
00007ff1409e40c8  vmovaps xmm15, [rsp+0xE0]
00007ff1409e40d1  add rsp, 0xF0
00007ff1409e40d8  pop r11
00007ff1409e40da  pop r10
00007ff1409e40dc  pop r9
00007ff1409e40de  pop r8
00007ff1409e40e0  pop rsi
00007ff1409e40e1  pop rdi
00007ff1409e40e2  pop rdx
00007ff1409e40e3  pop rcx
00007ff1409e40e4  pop rax
00007ff1409e40e5  add rsp, 0x08
00007ff1409e40e9  jmp 0x00007FF1409DF8DC
00007ff1409e40ee  sub rsp, 0x08
00007ff1409e40f2  push rax
00007ff1409e40f3  push rcx
00007ff1409e40f4  push rdx
00007ff1409e40f5  push rdi
00007ff1409e40f6  push rsi
00007ff1409e40f7  push r8
00007ff1409e40f9  push r9
00007ff1409e40fb  push r10
00007ff1409e40fd  push r11
00007ff1409e40ff  sub rsp, 0xF0
00007ff1409e4106  vmovaps [rsp], xmm0
00007ff1409e410b  vmovaps [rsp+0x10], xmm1
00007ff1409e4111  vmovaps [rsp+0x20], xmm2
00007ff1409e4117  vmovaps [rsp+0x30], xmm3
00007ff1409e411d  vmovaps [rsp+0x40], xmm4
00007ff1409e4123  vmovaps [rsp+0x50], xmm5
00007ff1409e4129  vmovaps [rsp+0x60], xmm6
00007ff1409e412f  vmovaps [rsp+0x70], xmm7
00007ff1409e4135  vmovaps [rsp+0x80], xmm8
00007ff1409e413e  vmovaps [rsp+0x90], xmm9
00007ff1409e4147  vmovaps [rsp+0xA0], xmm10
00007ff1409e4150  vmovaps [rsp+0xB0], xmm11
00007ff1409e4159  vmovaps [rsp+0xC0], xmm12
00007ff1409e4162  vmovaps [rsp+0xD0], xmm13
00007ff1409e416b  vmovaps [rsp+0xE0], xmm15
00007ff1409e4174  sub rsp, 0x30
00007ff1409e4178  movaps [rsp], xmm14
00007ff1409e417d  movaps [rsp+0x10], xmm9
00007ff1409e4183  movaps [rsp+0x20], xmm1
00007ff1409e4188  lea rdi, [rsp]
00007ff1409e418c  mov esi, 0x00
00007ff1409e4191  mov rax, 0x565C7F10C530
00007ff1409e419b  call rax
00007ff1409e419d  movaps xmm14, [rsp]
00007ff1409e41a2  add rsp, 0x30
00007ff1409e41a6  vmovaps xmm0, [rsp]
00007ff1409e41ab  vmovaps xmm1, [rsp+0x10]
00007ff1409e41b1  vmovaps xmm2, [rsp+0x20]
00007ff1409e41b7  vmovaps xmm3, [rsp+0x30]
00007ff1409e41bd  vmovaps xmm4, [rsp+0x40]
00007ff1409e41c3  vmovaps xmm5, [rsp+0x50]
00007ff1409e41c9  vmovaps xmm6, [rsp+0x60]
00007ff1409e41cf  vmovaps xmm7, [rsp+0x70]
00007ff1409e41d5  vmovaps xmm8, [rsp+0x80]
00007ff1409e41de  vmovaps xmm9, [rsp+0x90]
00007ff1409e41e7  vmovaps xmm10, [rsp+0xA0]
00007ff1409e41f0  vmovaps xmm11, [rsp+0xB0]
00007ff1409e41f9  vmovaps xmm12, [rsp+0xC0]
00007ff1409e4202  vmovaps xmm13, [rsp+0xD0]
00007ff1409e420b  vmovaps xmm15, [rsp+0xE0]
00007ff1409e4214  add rsp, 0xF0
00007ff1409e421b  pop r11
00007ff1409e421d  pop r10
00007ff1409e421f  pop r9
00007ff1409e4221  pop r8
00007ff1409e4223  pop rsi
00007ff1409e4224  pop rdi
00007ff1409e4225  pop rdx
00007ff1409e4226  pop rcx
00007ff1409e4227  pop rax
00007ff1409e4228  add rsp, 0x08
00007ff1409e422c  jmp 0x00007FF1409DF90B
00007ff1409e4231  sub rsp, 0x08
00007ff1409e4235  push rax
00007ff1409e4236  push rcx
00007ff1409e4237  push rdx
00007ff1409e4238  push rdi
00007ff1409e4239  push rsi
00007ff1409e423a  push r8
00007ff1409e423c  push r9
00007ff1409e423e  push r10
00007ff1409e4240  push r11
00007ff1409e4242  sub rsp, 0xF0
00007ff1409e4249  vmovaps [rsp], xmm0
00007ff1409e424e  vmovaps [rsp+0x10], xmm2
00007ff1409e4254  vmovaps [rsp+0x20], xmm3
00007ff1409e425a  vmovaps [rsp+0x30], xmm4
00007ff1409e4260  vmovaps [rsp+0x40], xmm5
00007ff1409e4266  vmovaps [rsp+0x50], xmm6
00007ff1409e426c  vmovaps [rsp+0x60], xmm7
00007ff1409e4272  vmovaps [rsp+0x70], xmm8
00007ff1409e4278  vmovaps [rsp+0x80], xmm9
00007ff1409e4281  vmovaps [rsp+0x90], xmm10
00007ff1409e428a  vmovaps [rsp+0xA0], xmm11
00007ff1409e4293  vmovaps [rsp+0xB0], xmm12
00007ff1409e429c  vmovaps [rsp+0xC0], xmm13
00007ff1409e42a5  vmovaps [rsp+0xD0], xmm14
00007ff1409e42ae  vmovaps [rsp+0xE0], xmm15
00007ff1409e42b7  sub rsp, 0x30
00007ff1409e42bb  movaps [rsp], xmm1
00007ff1409e42bf  movaps [rsp+0x10], xmm13
00007ff1409e42c5  movaps [rsp+0x20], xmm8
00007ff1409e42cb  lea rdi, [rsp]
00007ff1409e42cf  mov esi, 0x00
00007ff1409e42d4  mov rax, 0x565C7F10C530
00007ff1409e42de  call rax
00007ff1409e42e0  movaps xmm1, [rsp]
00007ff1409e42e4  add rsp, 0x30
00007ff1409e42e8  vmovaps xmm0, [rsp]
00007ff1409e42ed  vmovaps xmm2, [rsp+0x10]
00007ff1409e42f3  vmovaps xmm3, [rsp+0x20]
00007ff1409e42f9  vmovaps xmm4, [rsp+0x30]
00007ff1409e42ff  vmovaps xmm5, [rsp+0x40]
00007ff1409e4305  vmovaps xmm6, [rsp+0x50]
00007ff1409e430b  vmovaps xmm7, [rsp+0x60]
00007ff1409e4311  vmovaps xmm8, [rsp+0x70]
00007ff1409e4317  vmovaps xmm9, [rsp+0x80]
00007ff1409e4320  vmovaps xmm10, [rsp+0x90]
00007ff1409e4329  vmovaps xmm11, [rsp+0xA0]
00007ff1409e4332  vmovaps xmm12, [rsp+0xB0]
00007ff1409e433b  vmovaps xmm13, [rsp+0xC0]
00007ff1409e4344  vmovaps xmm14, [rsp+0xD0]
00007ff1409e434d  vmovaps xmm15, [rsp+0xE0]
00007ff1409e4356  add rsp, 0xF0
00007ff1409e435d  pop r11
00007ff1409e435f  pop r10
00007ff1409e4361  pop r9
00007ff1409e4363  pop r8
00007ff1409e4365  pop rsi
00007ff1409e4366  pop rdi
00007ff1409e4367  pop rdx
00007ff1409e4368  pop rcx
00007ff1409e4369  pop rax
00007ff1409e436a  add rsp, 0x08
00007ff1409e436e  jmp 0x00007FF1409DF92D
00007ff1409e4373  call 0x00007FF14080C260
00007ff1409e4378  jmp 0x00007FF1409DF93B
00007ff1409e437d  call 0x00007FF1408BD750
00007ff1409e4382  jmp 0x00007FF1409DF945
00007ff1409e4387  sub rsp, 0x08
00007ff1409e438b  push rax
00007ff1409e438c  push rcx
00007ff1409e438d  push rdx
00007ff1409e438e  push rdi
00007ff1409e438f  push rsi
00007ff1409e4390  push r8
00007ff1409e4392  push r9
00007ff1409e4394  push r10
00007ff1409e4396  push r11
00007ff1409e4398  sub rsp, 0xF0
00007ff1409e439f  vmovaps [rsp], xmm0
00007ff1409e43a4  vmovaps [rsp+0x10], xmm1
00007ff1409e43aa  vmovaps [rsp+0x20], xmm2
00007ff1409e43b0  vmovaps [rsp+0x30], xmm3
00007ff1409e43b6  vmovaps [rsp+0x40], xmm4
00007ff1409e43bc  vmovaps [rsp+0x50], xmm5
00007ff1409e43c2  vmovaps [rsp+0x60], xmm6
00007ff1409e43c8  vmovaps [rsp+0x70], xmm7
00007ff1409e43ce  vmovaps [rsp+0x80], xmm9
00007ff1409e43d7  vmovaps [rsp+0x90], xmm10
00007ff1409e43e0  vmovaps [rsp+0xA0], xmm11
00007ff1409e43e9  vmovaps [rsp+0xB0], xmm12
00007ff1409e43f2  vmovaps [rsp+0xC0], xmm13
00007ff1409e43fb  vmovaps [rsp+0xD0], xmm14
00007ff1409e4404  vmovaps [rsp+0xE0], xmm15
00007ff1409e440d  sub rsp, 0x30
00007ff1409e4411  movaps [rsp], xmm8
00007ff1409e4416  movaps [rsp+0x10], xmm15
00007ff1409e441c  movaps [rsp+0x20], xmm7
00007ff1409e4421  lea rdi, [rsp]
00007ff1409e4425  mov esi, 0x00
00007ff1409e442a  mov rax, 0x565C7F10C530
00007ff1409e4434  call rax
00007ff1409e4436  movaps xmm8, [rsp]
00007ff1409e443b  add rsp, 0x30
00007ff1409e443f  vmovaps xmm0, [rsp]
00007ff1409e4444  vmovaps xmm1, [rsp+0x10]
00007ff1409e444a  vmovaps xmm2, [rsp+0x20]
00007ff1409e4450  vmovaps xmm3, [rsp+0x30]
00007ff1409e4456  vmovaps xmm4, [rsp+0x40]
00007ff1409e445c  vmovaps xmm5, [rsp+0x50]
00007ff1409e4462  vmovaps xmm6, [rsp+0x60]
00007ff1409e4468  vmovaps xmm7, [rsp+0x70]
00007ff1409e446e  vmovaps xmm9, [rsp+0x80]
00007ff1409e4477  vmovaps xmm10, [rsp+0x90]
00007ff1409e4480  vmovaps xmm11, [rsp+0xA0]
00007ff1409e4489  vmovaps xmm12, [rsp+0xB0]
00007ff1409e4492  vmovaps xmm13, [rsp+0xC0]
00007ff1409e449b  vmovaps xmm14, [rsp+0xD0]
00007ff1409e44a4  vmovaps xmm15, [rsp+0xE0]
00007ff1409e44ad  add rsp, 0xF0
00007ff1409e44b4  pop r11
00007ff1409e44b6  pop r10
00007ff1409e44b8  pop r9
00007ff1409e44ba  pop r8
00007ff1409e44bc  pop rsi
00007ff1409e44bd  pop rdi
00007ff1409e44be  pop rdx
00007ff1409e44bf  pop rcx
00007ff1409e44c0  pop rax
00007ff1409e44c1  add rsp, 0x08
00007ff1409e44c5  jmp 0x00007FF1409DF967
00007ff1409e44ca  sub rsp, 0x08
00007ff1409e44ce  push rax
00007ff1409e44cf  push rcx
00007ff1409e44d0  push rdx
00007ff1409e44d1  push rdi
00007ff1409e44d2  push rsi
00007ff1409e44d3  push r8
00007ff1409e44d5  push r9
00007ff1409e44d7  push r10
00007ff1409e44d9  push r11
00007ff1409e44db  sub rsp, 0xF0
00007ff1409e44e2  vmovaps [rsp], xmm0
00007ff1409e44e7  vmovaps [rsp+0x10], xmm1
00007ff1409e44ed  vmovaps [rsp+0x20], xmm2
00007ff1409e44f3  vmovaps [rsp+0x30], xmm3
00007ff1409e44f9  vmovaps [rsp+0x40], xmm4
00007ff1409e44ff  vmovaps [rsp+0x50], xmm5
00007ff1409e4505  vmovaps [rsp+0x60], xmm6
00007ff1409e450b  vmovaps [rsp+0x70], xmm8
00007ff1409e4511  vmovaps [rsp+0x80], xmm9
00007ff1409e451a  vmovaps [rsp+0x90], xmm10
00007ff1409e4523  vmovaps [rsp+0xA0], xmm11
00007ff1409e452c  vmovaps [rsp+0xB0], xmm12
00007ff1409e4535  vmovaps [rsp+0xC0], xmm13
00007ff1409e453e  vmovaps [rsp+0xD0], xmm14
00007ff1409e4547  vmovaps [rsp+0xE0], xmm15
00007ff1409e4550  sub rsp, 0x30
00007ff1409e4554  movaps [rsp], xmm7
00007ff1409e4558  movaps [rsp+0x10], xmm9
00007ff1409e455e  movaps [rsp+0x20], xmm15
00007ff1409e4564  lea rdi, [rsp]
00007ff1409e4568  mov esi, 0x00
00007ff1409e456d  mov rax, 0x565C7F10C530
00007ff1409e4577  call rax
00007ff1409e4579  movaps xmm7, [rsp]
00007ff1409e457d  add rsp, 0x30
00007ff1409e4581  vmovaps xmm0, [rsp]
00007ff1409e4586  vmovaps xmm1, [rsp+0x10]
00007ff1409e458c  vmovaps xmm2, [rsp+0x20]
00007ff1409e4592  vmovaps xmm3, [rsp+0x30]
00007ff1409e4598  vmovaps xmm4, [rsp+0x40]
00007ff1409e459e  vmovaps xmm5, [rsp+0x50]
00007ff1409e45a4  vmovaps xmm6, [rsp+0x60]
00007ff1409e45aa  vmovaps xmm8, [rsp+0x70]
00007ff1409e45b0  vmovaps xmm9, [rsp+0x80]
00007ff1409e45b9  vmovaps xmm10, [rsp+0x90]
00007ff1409e45c2  vmovaps xmm11, [rsp+0xA0]
00007ff1409e45cb  vmovaps xmm12, [rsp+0xB0]
00007ff1409e45d4  vmovaps xmm13, [rsp+0xC0]
00007ff1409e45dd  vmovaps xmm14, [rsp+0xD0]
00007ff1409e45e6  vmovaps xmm15, [rsp+0xE0]
00007ff1409e45ef  add rsp, 0xF0
00007ff1409e45f6  pop r11
00007ff1409e45f8  pop r10
00007ff1409e45fa  pop r9
00007ff1409e45fc  pop r8
00007ff1409e45fe  pop rsi
00007ff1409e45ff  pop rdi
00007ff1409e4600  pop rdx
00007ff1409e4601  pop rcx
00007ff1409e4602  pop rax
00007ff1409e4603  add rsp, 0x08
00007ff1409e4607  jmp 0x00007FF1409DF994
00007ff1409e460c  sub rsp, 0x08
00007ff1409e4610  push rax
00007ff1409e4611  push rcx
00007ff1409e4612  push rdx
00007ff1409e4613  push rdi
00007ff1409e4614  push rsi
00007ff1409e4615  push r8
00007ff1409e4617  push r9
00007ff1409e4619  push r10
00007ff1409e461b  push r11
00007ff1409e461d  sub rsp, 0xF0
00007ff1409e4624  vmovaps [rsp], xmm0
00007ff1409e4629  vmovaps [rsp+0x10], xmm1
00007ff1409e462f  vmovaps [rsp+0x20], xmm2
00007ff1409e4635  vmovaps [rsp+0x30], xmm3
00007ff1409e463b  vmovaps [rsp+0x40], xmm4
00007ff1409e4641  vmovaps [rsp+0x50], xmm5
00007ff1409e4647  vmovaps [rsp+0x60], xmm6
00007ff1409e464d  vmovaps [rsp+0x70], xmm7
00007ff1409e4653  vmovaps [rsp+0x80], xmm8
00007ff1409e465c  vmovaps [rsp+0x90], xmm10
00007ff1409e4665  vmovaps [rsp+0xA0], xmm11
00007ff1409e466e  vmovaps [rsp+0xB0], xmm12
00007ff1409e4677  vmovaps [rsp+0xC0], xmm13
00007ff1409e4680  vmovaps [rsp+0xD0], xmm14
00007ff1409e4689  vmovaps [rsp+0xE0], xmm15
00007ff1409e4692  sub rsp, 0x30
00007ff1409e4696  movaps [rsp], xmm9
00007ff1409e469b  movaps [rsp+0x10], xmm13
00007ff1409e46a1  movaps [rsp+0x20], xmm15
00007ff1409e46a7  lea rdi, [rsp]
00007ff1409e46ab  mov esi, 0x00
00007ff1409e46b0  mov rax, 0x565C7F10C530
00007ff1409e46ba  call rax
00007ff1409e46bc  movaps xmm9, [rsp]
00007ff1409e46c1  add rsp, 0x30
00007ff1409e46c5  vmovaps xmm0, [rsp]
00007ff1409e46ca  vmovaps xmm1, [rsp+0x10]
00007ff1409e46d0  vmovaps xmm2, [rsp+0x20]
00007ff1409e46d6  vmovaps xmm3, [rsp+0x30]
00007ff1409e46dc  vmovaps xmm4, [rsp+0x40]
00007ff1409e46e2  vmovaps xmm5, [rsp+0x50]
00007ff1409e46e8  vmovaps xmm6, [rsp+0x60]
00007ff1409e46ee  vmovaps xmm7, [rsp+0x70]
00007ff1409e46f4  vmovaps xmm8, [rsp+0x80]
00007ff1409e46fd  vmovaps xmm10, [rsp+0x90]
00007ff1409e4706  vmovaps xmm11, [rsp+0xA0]
00007ff1409e470f  vmovaps xmm12, [rsp+0xB0]
00007ff1409e4718  vmovaps xmm13, [rsp+0xC0]
00007ff1409e4721  vmovaps xmm14, [rsp+0xD0]
00007ff1409e472a  vmovaps xmm15, [rsp+0xE0]
00007ff1409e4733  add rsp, 0xF0
00007ff1409e473a  pop r11
00007ff1409e473c  pop r10
00007ff1409e473e  pop r9
00007ff1409e4740  pop r8
00007ff1409e4742  pop rsi
00007ff1409e4743  pop rdi
00007ff1409e4744  pop rdx
00007ff1409e4745  pop rcx
00007ff1409e4746  pop rax
00007ff1409e4747  add rsp, 0x08
00007ff1409e474b  jmp 0x00007FF1409DF9C2
00007ff1409e4750  sub rsp, 0x08
00007ff1409e4754  push rax
00007ff1409e4755  push rcx
00007ff1409e4756  push rdx
00007ff1409e4757  push rdi
00007ff1409e4758  push rsi
00007ff1409e4759  push r8
00007ff1409e475b  push r9
00007ff1409e475d  push r10
00007ff1409e475f  push r11
00007ff1409e4761  sub rsp, 0xF0
00007ff1409e4768  vmovaps [rsp], xmm0
00007ff1409e476d  vmovaps [rsp+0x10], xmm1
00007ff1409e4773  vmovaps [rsp+0x20], xmm2
00007ff1409e4779  vmovaps [rsp+0x30], xmm3
00007ff1409e477f  vmovaps [rsp+0x40], xmm4
00007ff1409e4785  vmovaps [rsp+0x50], xmm5
00007ff1409e478b  vmovaps [rsp+0x60], xmm6
00007ff1409e4791  vmovaps [rsp+0x70], xmm7
00007ff1409e4797  vmovaps [rsp+0x80], xmm8
00007ff1409e47a0  vmovaps [rsp+0x90], xmm9
00007ff1409e47a9  vmovaps [rsp+0xA0], xmm10
00007ff1409e47b2  vmovaps [rsp+0xB0], xmm11
00007ff1409e47bb  vmovaps [rsp+0xC0], xmm12
00007ff1409e47c4  vmovaps [rsp+0xD0], xmm13
00007ff1409e47cd  vmovaps [rsp+0xE0], xmm14
00007ff1409e47d6  sub rsp, 0x30
00007ff1409e47da  movaps [rsp], xmm15
00007ff1409e47df  movaps [rsp+0x10], xmm11
00007ff1409e47e5  movaps [rsp+0x20], xmm12
00007ff1409e47eb  lea rdi, [rsp]
00007ff1409e47ef  mov esi, 0x00
00007ff1409e47f4  mov rax, 0x565C7F10C530
00007ff1409e47fe  call rax
00007ff1409e4800  movaps xmm15, [rsp]
00007ff1409e4805  add rsp, 0x30
00007ff1409e4809  vmovaps xmm0, [rsp]
00007ff1409e480e  vmovaps xmm1, [rsp+0x10]
00007ff1409e4814  vmovaps xmm2, [rsp+0x20]
00007ff1409e481a  vmovaps xmm3, [rsp+0x30]
00007ff1409e4820  vmovaps xmm4, [rsp+0x40]
00007ff1409e4826  vmovaps xmm5, [rsp+0x50]
00007ff1409e482c  vmovaps xmm6, [rsp+0x60]
00007ff1409e4832  vmovaps xmm7, [rsp+0x70]
00007ff1409e4838  vmovaps xmm8, [rsp+0x80]
00007ff1409e4841  vmovaps xmm9, [rsp+0x90]
00007ff1409e484a  vmovaps xmm10, [rsp+0xA0]
00007ff1409e4853  vmovaps xmm11, [rsp+0xB0]
00007ff1409e485c  vmovaps xmm12, [rsp+0xC0]
00007ff1409e4865  vmovaps xmm13, [rsp+0xD0]
00007ff1409e486e  vmovaps xmm14, [rsp+0xE0]
00007ff1409e4877  add rsp, 0xF0
00007ff1409e487e  pop r11
00007ff1409e4880  pop r10
00007ff1409e4882  pop r9
00007ff1409e4884  pop r8
00007ff1409e4886  pop rsi
00007ff1409e4887  pop rdi
00007ff1409e4888  pop rdx
00007ff1409e4889  pop rcx
00007ff1409e488a  pop rax
00007ff1409e488b  add rsp, 0x08
00007ff1409e488f  jmp 0x00007FF1409DF9DD
00007ff1409e4894  sub rsp, 0x08
00007ff1409e4898  push rax
00007ff1409e4899  push rcx
00007ff1409e489a  push rdx
00007ff1409e489b  push rdi
00007ff1409e489c  push rsi
00007ff1409e489d  push r8
00007ff1409e489f  push r9
00007ff1409e48a1  push r10
00007ff1409e48a3  push r11
00007ff1409e48a5  sub rsp, 0xF0
00007ff1409e48ac  vmovaps [rsp], xmm0
00007ff1409e48b1  vmovaps [rsp+0x10], xmm1
00007ff1409e48b7  vmovaps [rsp+0x20], xmm2
00007ff1409e48bd  vmovaps [rsp+0x30], xmm3
00007ff1409e48c3  vmovaps [rsp+0x40], xmm4
00007ff1409e48c9  vmovaps [rsp+0x50], xmm5
00007ff1409e48cf  vmovaps [rsp+0x60], xmm6
00007ff1409e48d5  vmovaps [rsp+0x70], xmm7
00007ff1409e48db  vmovaps [rsp+0x80], xmm8
00007ff1409e48e4  vmovaps [rsp+0x90], xmm9
00007ff1409e48ed  vmovaps [rsp+0xA0], xmm10
00007ff1409e48f6  vmovaps [rsp+0xB0], xmm11
00007ff1409e48ff  vmovaps [rsp+0xC0], xmm12
00007ff1409e4908  vmovaps [rsp+0xD0], xmm14
00007ff1409e4911  vmovaps [rsp+0xE0], xmm15
00007ff1409e491a  sub rsp, 0x30
00007ff1409e491e  movaps [rsp], xmm13
00007ff1409e4923  movaps [rsp+0x10], xmm10
00007ff1409e4929  movaps [rsp+0x20], xmm14
00007ff1409e492f  lea rdi, [rsp]
00007ff1409e4933  mov esi, 0x00
00007ff1409e4938  mov rax, 0x565C7F10C530
00007ff1409e4942  call rax
00007ff1409e4944  movaps xmm13, [rsp]
00007ff1409e4949  add rsp, 0x30
00007ff1409e494d  vmovaps xmm0, [rsp]
00007ff1409e4952  vmovaps xmm1, [rsp+0x10]
00007ff1409e4958  vmovaps xmm2, [rsp+0x20]
00007ff1409e495e  vmovaps xmm3, [rsp+0x30]
00007ff1409e4964  vmovaps xmm4, [rsp+0x40]
00007ff1409e496a  vmovaps xmm5, [rsp+0x50]
00007ff1409e4970  vmovaps xmm6, [rsp+0x60]
00007ff1409e4976  vmovaps xmm7, [rsp+0x70]
00007ff1409e497c  vmovaps xmm8, [rsp+0x80]
00007ff1409e4985  vmovaps xmm9, [rsp+0x90]
00007ff1409e498e  vmovaps xmm10, [rsp+0xA0]
00007ff1409e4997  vmovaps xmm11, [rsp+0xB0]
00007ff1409e49a0  vmovaps xmm12, [rsp+0xC0]
00007ff1409e49a9  vmovaps xmm14, [rsp+0xD0]
00007ff1409e49b2  vmovaps xmm15, [rsp+0xE0]
00007ff1409e49bb  add rsp, 0xF0
00007ff1409e49c2  pop r11
00007ff1409e49c4  pop r10
00007ff1409e49c6  pop r9
00007ff1409e49c8  pop r8
00007ff1409e49ca  pop rsi
00007ff1409e49cb  pop rdi
00007ff1409e49cc  pop rdx
00007ff1409e49cd  pop rcx
00007ff1409e49ce  pop rax
00007ff1409e49cf  add rsp, 0x08
00007ff1409e49d3  jmp 0x00007FF1409DFA00
00007ff1409e49d8  sub rsp, 0x08
00007ff1409e49dc  push rax
00007ff1409e49dd  push rcx
00007ff1409e49de  push rdx
00007ff1409e49df  push rdi
00007ff1409e49e0  push rsi
00007ff1409e49e1  push r8
00007ff1409e49e3  push r9
00007ff1409e49e5  push r10
00007ff1409e49e7  push r11
00007ff1409e49e9  sub rsp, 0xF0
00007ff1409e49f0  vmovaps [rsp], xmm0
00007ff1409e49f5  vmovaps [rsp+0x10], xmm1
00007ff1409e49fb  vmovaps [rsp+0x20], xmm2
00007ff1409e4a01  vmovaps [rsp+0x30], xmm3
00007ff1409e4a07  vmovaps [rsp+0x40], xmm4
00007ff1409e4a0d  vmovaps [rsp+0x50], xmm5
00007ff1409e4a13  vmovaps [rsp+0x60], xmm6
00007ff1409e4a19  vmovaps [rsp+0x70], xmm7
00007ff1409e4a1f  vmovaps [rsp+0x80], xmm8
00007ff1409e4a28  vmovaps [rsp+0x90], xmm9
00007ff1409e4a31  vmovaps [rsp+0xA0], xmm10
00007ff1409e4a3a  vmovaps [rsp+0xB0], xmm11
00007ff1409e4a43  vmovaps [rsp+0xC0], xmm12
00007ff1409e4a4c  vmovaps [rsp+0xD0], xmm13
00007ff1409e4a55  vmovaps [rsp+0xE0], xmm15
00007ff1409e4a5e  sub rsp, 0x30
00007ff1409e4a62  movaps [rsp], xmm14
00007ff1409e4a67  movaps [rsp+0x10], xmm1
00007ff1409e4a6c  movaps [rsp+0x20], xmm7
00007ff1409e4a71  lea rdi, [rsp]
00007ff1409e4a75  mov esi, 0x00
00007ff1409e4a7a  mov rax, 0x565C7F10C530
00007ff1409e4a84  call rax
00007ff1409e4a86  movaps xmm14, [rsp]
00007ff1409e4a8b  add rsp, 0x30
00007ff1409e4a8f  vmovaps xmm0, [rsp]
00007ff1409e4a94  vmovaps xmm1, [rsp+0x10]
00007ff1409e4a9a  vmovaps xmm2, [rsp+0x20]
00007ff1409e4aa0  vmovaps xmm3, [rsp+0x30]
00007ff1409e4aa6  vmovaps xmm4, [rsp+0x40]
00007ff1409e4aac  vmovaps xmm5, [rsp+0x50]
00007ff1409e4ab2  vmovaps xmm6, [rsp+0x60]
00007ff1409e4ab8  vmovaps xmm7, [rsp+0x70]
00007ff1409e4abe  vmovaps xmm8, [rsp+0x80]
00007ff1409e4ac7  vmovaps xmm9, [rsp+0x90]
00007ff1409e4ad0  vmovaps xmm10, [rsp+0xA0]
00007ff1409e4ad9  vmovaps xmm11, [rsp+0xB0]
00007ff1409e4ae2  vmovaps xmm12, [rsp+0xC0]
00007ff1409e4aeb  vmovaps xmm13, [rsp+0xD0]
00007ff1409e4af4  vmovaps xmm15, [rsp+0xE0]
00007ff1409e4afd  add rsp, 0xF0
00007ff1409e4b04  pop r11
00007ff1409e4b06  pop r10
00007ff1409e4b08  pop r9
00007ff1409e4b0a  pop r8
00007ff1409e4b0c  pop rsi
00007ff1409e4b0d  pop rdi
00007ff1409e4b0e  pop rdx
00007ff1409e4b0f  pop rcx
00007ff1409e4b10  pop rax
00007ff1409e4b11  add rsp, 0x08
00007ff1409e4b15  jmp 0x00007FF1409DFA23
00007ff1409e4b1a  sub rsp, 0x08
00007ff1409e4b1e  push rax
00007ff1409e4b1f  push rcx
00007ff1409e4b20  push rdx
00007ff1409e4b21  push rdi
00007ff1409e4b22  push rsi
00007ff1409e4b23  push r8
00007ff1409e4b25  push r9
00007ff1409e4b27  push r10
00007ff1409e4b29  push r11
00007ff1409e4b2b  sub rsp, 0xF0
00007ff1409e4b32  vmovaps [rsp], xmm0
00007ff1409e4b37  vmovaps [rsp+0x10], xmm2
00007ff1409e4b3d  vmovaps [rsp+0x20], xmm3
00007ff1409e4b43  vmovaps [rsp+0x30], xmm4
00007ff1409e4b49  vmovaps [rsp+0x40], xmm5
00007ff1409e4b4f  vmovaps [rsp+0x50], xmm6
00007ff1409e4b55  vmovaps [rsp+0x60], xmm7
00007ff1409e4b5b  vmovaps [rsp+0x70], xmm8
00007ff1409e4b61  vmovaps [rsp+0x80], xmm9
00007ff1409e4b6a  vmovaps [rsp+0x90], xmm10
00007ff1409e4b73  vmovaps [rsp+0xA0], xmm11
00007ff1409e4b7c  vmovaps [rsp+0xB0], xmm12
00007ff1409e4b85  vmovaps [rsp+0xC0], xmm13
00007ff1409e4b8e  vmovaps [rsp+0xD0], xmm14
00007ff1409e4b97  vmovaps [rsp+0xE0], xmm15
00007ff1409e4ba0  sub rsp, 0x30
00007ff1409e4ba4  movaps [rsp], xmm1
00007ff1409e4ba8  movaps [rsp+0x10], xmm8
00007ff1409e4bae  movaps [rsp+0x20], xmm9
00007ff1409e4bb4  lea rdi, [rsp]
00007ff1409e4bb8  mov esi, 0x00
00007ff1409e4bbd  mov rax, 0x565C7F10C530
00007ff1409e4bc7  call rax
00007ff1409e4bc9  movaps xmm1, [rsp]
00007ff1409e4bcd  add rsp, 0x30
00007ff1409e4bd1  vmovaps xmm0, [rsp]
00007ff1409e4bd6  vmovaps xmm2, [rsp+0x10]
00007ff1409e4bdc  vmovaps xmm3, [rsp+0x20]
00007ff1409e4be2  vmovaps xmm4, [rsp+0x30]
00007ff1409e4be8  vmovaps xmm5, [rsp+0x40]
00007ff1409e4bee  vmovaps xmm6, [rsp+0x50]
00007ff1409e4bf4  vmovaps xmm7, [rsp+0x60]
00007ff1409e4bfa  vmovaps xmm8, [rsp+0x70]
00007ff1409e4c00  vmovaps xmm9, [rsp+0x80]
00007ff1409e4c09  vmovaps xmm10, [rsp+0x90]
00007ff1409e4c12  vmovaps xmm11, [rsp+0xA0]
00007ff1409e4c1b  vmovaps xmm12, [rsp+0xB0]
00007ff1409e4c24  vmovaps xmm13, [rsp+0xC0]
00007ff1409e4c2d  vmovaps xmm14, [rsp+0xD0]
00007ff1409e4c36  vmovaps xmm15, [rsp+0xE0]
00007ff1409e4c3f  add rsp, 0xF0
00007ff1409e4c46  pop r11
00007ff1409e4c48  pop r10
00007ff1409e4c4a  pop r9
00007ff1409e4c4c  pop r8
00007ff1409e4c4e  pop rsi
00007ff1409e4c4f  pop rdi
00007ff1409e4c50  pop rdx
00007ff1409e4c51  pop rcx
00007ff1409e4c52  pop rax
00007ff1409e4c53  add rsp, 0x08
00007ff1409e4c57  jmp 0x00007FF1409DFA45
00007ff1409e4c5c  call 0x00007FF1408E5940
00007ff1409e4c61  jmp 0x00007FF1409DFA53
00007ff1409e4c66  call 0x00007FF14080C380
00007ff1409e4c6b  jmp 0x00007FF1409DFA5D
00007ff1409e4c70  call 0x00007FF14080D600
00007ff1409e4c75  jmp 0x00007FF1409DFA67
00007ff1409e4c7a  call 0x00007FF1407FF540
00007ff1409e4c7f  jmp 0x00007FF1409DFA71
00007ff1409e4c84  int3
00007ff1409e4c85  nop [rax+rax*1], ax
00007ff1409e4c8e  nop
00007ff1409e4c90  mov qword ptr [r15+0x40], 0x430000
00007ff1409e4c98  mov eax, 0x430CC0
00007ff1409e4c9d  mov r14, [r13+rax*1]
00007ff1409e4ca2  movq xmm1, r14
00007ff1409e4ca7  mov rax, [r15+0x50]
00007ff1409e4cab  movups xmm15, [r13+rax*1]
00007ff1409e4cb1  movaps [r15+0x120], xmm15
00007ff1409e4cb9  mov qword ptr [r15+0x48], 0x10
00007ff1409e4cc1  xor eax, eax
00007ff1409e4cc3  mov r14d, 0x10
00007ff1409e4cc9  mov r12d, 0x200
00007ff1409e4ccf  cmp r14, r12
00007ff1409e4cd2  cmc
00007ff1409e4cd3  lahf
00007ff1409e4cd4  seto al
00007ff1409e4cd7  mov [r15+0x108], eax
00007ff1409e4cde  pextrq rax, xmm15, 0x01
00007ff1409e4ce5  movq xmm14, rax
00007ff1409e4cea  movaps [r15+0x130], xmm14
00007ff1409e4cf2  movq rax, xmm1
00007ff1409e4cf7  movq r14, xmm15
00007ff1409e4cfc  vmovq xmm1, rax
00007ff1409e4d01  vmovq xmm15, r14
00007ff1409e4d06  movaps xmm13, xmm1
00007ff1409e4d0a  addsd xmm13, xmm15
00007ff1409e4d0f  ucomisd xmm13, xmm13
00007ff1409e4d14  jp 0x00007FF1409E4DD3
00007ff1409e4d1a  movq xmm13, xmm13
00007ff1409e4d1f  movq rax, xmm13
00007ff1409e4d24  movq r14, xmm14
00007ff1409e4d29  vmovq xmm1, rax
00007ff1409e4d2e  vmovq xmm15, r14
00007ff1409e4d33  movaps xmm14, xmm1
00007ff1409e4d37  addsd xmm14, xmm15
00007ff1409e4d3c  ucomisd xmm14, xmm14
00007ff1409e4d41  jp 0x00007FF1409E4E1B
00007ff1409e4d47  movq xmm14, xmm14
00007ff1409e4d4c  movaps [r15+0x110], xmm14
00007ff1409e4d54  mov eax, [r15+0x108]
00007ff1409e4d5b  sahf
00007ff1409e4d5c  jnz 0x00007FF1409E4D8E
00007ff1409e4d5e  cmp dword ptr [r15+0x318], 0x00
00007ff1409e4d66  jz 0x00007FF1409E5030
00007ff1409e4d6c  nop [rax+rax*1], ax
00007ff1409e4d75  nop [rax+rax*1], eax
00007ff1409e4d7d  mov eax, 0x410704
00007ff1409e4d82  mov [r15+0x100], rax
00007ff1409e4d89  jmp 0x00007FF1407FE110
00007ff1409e4d8e  cmp dword ptr [r15+0x318], 0x00
00007ff1409e4d96  jz 0x00007FF1409E4E70
00007ff1409e4d9c  nop [rax+rax*1], ax
00007ff1409e4da5  nop [rax+rax*1], eax
00007ff1409e4dad  mov eax, 0x4106E8
00007ff1409e4db2  mov [r15+0x100], rax
00007ff1409e4db9  jmp 0x00007FF1407FE110
00007ff1409e4dbe  int3
00007ff1409e4dbf  call 0x00007FF14080DC20
00007ff1409e4dc4  jmp 0x00007FF1409E4CA2
00007ff1409e4dc9  call 0x00007FF14080E760
00007ff1409e4dce  jmp 0x00007FF1409E4CB1
00007ff1409e4dd3  ucomisd xmm1, xmm15
00007ff1409e4dd8  jp 0x00007FF1409E4DE7
00007ff1409e4dda  movaps xmm13, [0x00007FF1405FE060]
00007ff1409e4de2  jmp 0x00007FF1409E4D1A
00007ff1409e4de7  vxorps xmm0, xmm1, xmm15
00007ff1409e4dec  pextrw eax, xmm0, 0x03
00007ff1409e4df1  and eax, 0x7FF8
00007ff1409e4df6  cmp eax, 0x08
00007ff1409e4df9  jnz 0x00007FF1409E4D1A
00007ff1409e4dff  movq rax, xmm15
00007ff1409e4e04  shl rax, 0x0D
00007ff1409e4e08  jbe 0x00007FF1409E4D1A
00007ff1409e4e0e  vorps xmm13, xmm15, [0x00007FF1405FE070]
00007ff1409e4e16  jmp 0x00007FF1409E4D1A
00007ff1409e4e1b  ucomisd xmm1, xmm15
00007ff1409e4e20  jp 0x00007FF1409E4E2F
00007ff1409e4e22  movaps xmm14, [0x00007FF1405FE060]
00007ff1409e4e2a  jmp 0x00007FF1409E4D47
00007ff1409e4e2f  vxorps xmm0, xmm1, xmm15
00007ff1409e4e34  pextrw eax, xmm0, 0x03
00007ff1409e4e39  and eax, 0x7FF8
00007ff1409e4e3e  cmp eax, 0x08
00007ff1409e4e41  jnz 0x00007FF1409E4D47
00007ff1409e4e47  movq rax, xmm15
00007ff1409e4e4c  shl rax, 0x0D
00007ff1409e4e50  jbe 0x00007FF1409E4D47
00007ff1409e4e56  vorps xmm14, xmm15, [0x00007FF1405FE070]
00007ff1409e4e5e  jmp 0x00007FF1409E4D47
00007ff1409e4e63  int3
00007ff1409e4e64  nop [rax+rax*1], ax
00007ff1409e4e6d  nop [rax], eax
00007ff1409e4e70  mov rax, [r15+0x48]
00007ff1409e4e74  mov r14, [r15+0x50]
00007ff1409e4e78  lea r12, [r14+rax*1]
00007ff1409e4e7c  movups xmm1, [r13+r12*1]
00007ff1409e4e82  movaps [r15+0x120], xmm1
00007ff1409e4e8a  lea r14, [rax+0x10]
00007ff1409e4e8e  mov [r15+0x48], r14
00007ff1409e4e92  xor eax, eax
00007ff1409e4e94  mov r12d, 0x200
00007ff1409e4e9a  cmp r14, r12
00007ff1409e4e9d  cmc
00007ff1409e4e9e  lahf
00007ff1409e4e9f  seto al
00007ff1409e4ea2  mov [r15+0x108], eax
00007ff1409e4ea9  pextrq rax, xmm1, 0x01
00007ff1409e4eb0  movq xmm15, rax
00007ff1409e4eb5  movaps [r15+0x130], xmm15
00007ff1409e4ebd  movaps xmm14, [r15+0x110]
00007ff1409e4ec5  movq rax, xmm14
00007ff1409e4eca  movq r14, xmm1
00007ff1409e4ecf  vmovq xmm1, rax
00007ff1409e4ed4  vmovq xmm14, r14
00007ff1409e4ed9  movaps xmm13, xmm1
00007ff1409e4edd  addsd xmm13, xmm14
00007ff1409e4ee2  ucomisd xmm13, xmm13
00007ff1409e4ee7  jp 0x00007FF1409E4F9C
00007ff1409e4eed  movq xmm13, xmm13
00007ff1409e4ef2  movq rax, xmm13
00007ff1409e4ef7  movq r14, xmm15
00007ff1409e4efc  vmovq xmm1, rax
00007ff1409e4f01  vmovq xmm15, r14
00007ff1409e4f06  movaps xmm14, xmm1
00007ff1409e4f0a  addsd xmm14, xmm15
00007ff1409e4f0f  ucomisd xmm14, xmm14
00007ff1409e4f14  jp 0x00007FF1409E4FE4
00007ff1409e4f1a  movq xmm14, xmm14
00007ff1409e4f1f  movaps [r15+0x110], xmm14
00007ff1409e4f27  mov eax, [r15+0x108]
00007ff1409e4f2e  sahf
00007ff1409e4f2f  jnz 0x00007FF1409E4F61
00007ff1409e4f31  cmp dword ptr [r15+0x318], 0x00
00007ff1409e4f39  jz 0x00007FF1409E5030
00007ff1409e4f3f  nop [rax+rax*1], ax
00007ff1409e4f48  nop [rax+rax*1], eax
00007ff1409e4f50  mov eax, 0x410704
00007ff1409e4f55  mov [r15+0x100], rax
00007ff1409e4f5c  jmp 0x00007FF1407FE110
00007ff1409e4f61  cmp dword ptr [r15+0x318], 0x00
00007ff1409e4f69  jz 0x00007FF1409E4E70
00007ff1409e4f6f  nop [rax+rax*1], ax
00007ff1409e4f78  nop [rax+rax*1], eax
00007ff1409e4f80  mov eax, 0x4106E8
00007ff1409e4f85  mov [r15+0x100], rax
00007ff1409e4f8c  jmp 0x00007FF1407FE110
00007ff1409e4f91  int3
00007ff1409e4f92  call 0x00007FF1408B52F0
00007ff1409e4f97  jmp 0x00007FF1409E4E82
00007ff1409e4f9c  ucomisd xmm1, xmm14
00007ff1409e4fa1  jp 0x00007FF1409E4FB0
00007ff1409e4fa3  movaps xmm13, [0x00007FF1405FE060]
00007ff1409e4fab  jmp 0x00007FF1409E4EED
00007ff1409e4fb0  vxorps xmm0, xmm1, xmm14
00007ff1409e4fb5  pextrw eax, xmm0, 0x03
00007ff1409e4fba  and eax, 0x7FF8
00007ff1409e4fbf  cmp eax, 0x08
00007ff1409e4fc2  jnz 0x00007FF1409E4EED
00007ff1409e4fc8  movq rax, xmm14
00007ff1409e4fcd  shl rax, 0x0D
00007ff1409e4fd1  jbe 0x00007FF1409E4EED
00007ff1409e4fd7  vorps xmm13, xmm14, [0x00007FF1405FE070]
00007ff1409e4fdf  jmp 0x00007FF1409E4EED
00007ff1409e4fe4  ucomisd xmm1, xmm15
00007ff1409e4fe9  jp 0x00007FF1409E4FF8
00007ff1409e4feb  movaps xmm14, [0x00007FF1405FE060]
00007ff1409e4ff3  jmp 0x00007FF1409E4F1A
00007ff1409e4ff8  vxorps xmm0, xmm1, xmm15
00007ff1409e4ffd  pextrw eax, xmm0, 0x03
00007ff1409e5002  and eax, 0x7FF8
00007ff1409e5007  cmp eax, 0x08
00007ff1409e500a  jnz 0x00007FF1409E4F1A
00007ff1409e5010  movq rax, xmm15
00007ff1409e5015  shl rax, 0x0D
00007ff1409e5019  jbe 0x00007FF1409E4F1A
00007ff1409e501f  vorps xmm14, xmm15, [0x00007FF1405FE070]
00007ff1409e5027  jmp 0x00007FF1409E4F1A
00007ff1409e502c  int3
00007ff1409e502d  nop [rax], eax
00007ff1409e5030  mov rax, [r15+0xF8]
00007ff1409e5037  lea r14, [rax+0x1D0]
00007ff1409e503e  mov r12, [r13+r14*1]
00007ff1409e5043  lea r14, [rax+0x1D8]
00007ff1409e504a  mov r11, [r13+r14*1]
00007ff1409e504f  mov [r15+0xA0], r12
00007ff1409e5056  mov [r15+0x98], r11
00007ff1409e505d  mov r14, [r15+0x40]
00007ff1409e5061  lea r12, [r14+0xCC0]
00007ff1409e5068  movaps xmm1, [r15+0x110]
00007ff1409e5070  movq r14, xmm1
00007ff1409e5075  mov [r13+r12*1], r14
00007ff1409e507a  lea r14, [rax+0x1C0]
00007ff1409e5081  mov r12, [r13+r14*1]
00007ff1409e5086  lea r14, [rax+0x1C8]
00007ff1409e508d  mov r11, [r13+r14*1]
00007ff1409e5092  mov [r15+0xE8], r12
00007ff1409e5099  mov [r15+0xF0], r11
00007ff1409e50a0  lea r14, [rax+0x1B0]
00007ff1409e50a7  mov r12, [r13+r14*1]
00007ff1409e50ac  lea r14, [rax+0x1B8]
00007ff1409e50b3  mov r10, [r13+r14*1]
00007ff1409e50b8  movq xmm1, r12
00007ff1409e50bd  movq xmm15, r10
00007ff1409e50c2  movq xmm1, xmm1
00007ff1409e50c6  movq xmm1, xmm1
00007ff1409e50ca  movaps [r15+0x1A0], xmm1
00007ff1409e50d2  movq xmm15, xmm15
00007ff1409e50d7  movq xmm15, xmm15
00007ff1409e50dc  movaps [r15+0x190], xmm15
00007ff1409e50e4  lea r14, [rax+0x1A0]
00007ff1409e50eb  mov r12, [r13+r14*1]
00007ff1409e50f0  lea r14, [rax+0x1A8]
00007ff1409e50f7  mov r10, [r13+r14*1]
00007ff1409e50fc  movq xmm1, r12
00007ff1409e5101  movq xmm15, r10
00007ff1409e5106  movq xmm1, xmm1
00007ff1409e510a  movq xmm1, xmm1
00007ff1409e510e  movaps [r15+0x1C0], xmm1
00007ff1409e5116  movq xmm15, xmm15
00007ff1409e511b  movq xmm15, xmm15
00007ff1409e5120  movaps [r15+0x1B0], xmm15
00007ff1409e5128  lea r14, [rax+0x190]
00007ff1409e512f  mov r12, [r13+r14*1]
00007ff1409e5134  lea r14, [rax+0x198]
00007ff1409e513b  mov r10, [r13+r14*1]
00007ff1409e5140  movq xmm1, r12
00007ff1409e5145  movq xmm15, r10
00007ff1409e514a  movq xmm1, xmm1
00007ff1409e514e  movq xmm1, xmm1
00007ff1409e5152  movaps [r15+0x1E0], xmm1
00007ff1409e515a  movq xmm15, xmm15
00007ff1409e515f  movq xmm15, xmm15
00007ff1409e5164  movaps [r15+0x1D0], xmm15
00007ff1409e516c  lea r14, [rax+0x180]
00007ff1409e5173  mov r12, [r13+r14*1]
00007ff1409e5178  lea r14, [rax+0x188]
00007ff1409e517f  mov r10, [r13+r14*1]
00007ff1409e5184  movq xmm1, r12
00007ff1409e5189  movq xmm15, r10
00007ff1409e518e  movq xmm1, xmm1
00007ff1409e5192  movq xmm1, xmm1
00007ff1409e5196  movaps [r15+0x200], xmm1
00007ff1409e519e  movq xmm15, xmm15
00007ff1409e51a3  movq xmm15, xmm15
00007ff1409e51a8  movaps [r15+0x1F0], xmm15
00007ff1409e51b0  lea r14, [rax+0x1E0]
00007ff1409e51b7  mov [r15+0xF8], r14
00007ff1409e51be  mov [r15+0x100], r11
00007ff1409e51c5  jmp 0x00007FF1409CE5C0
00007ff1409e51ca  int3
00007ff1409e51cb  call 0x00007FF1408E27E0
00007ff1409e51d0  jmp 0x00007FF1409E5043
00007ff1409e51d5  call 0x00007FF1408E1570
00007ff1409e51da  jmp 0x00007FF1409E504F
00007ff1409e51df  call 0x00007FF1408C3FE0
00007ff1409e51e4  jmp 0x00007FF1409E507A
00007ff1409e51e9  call 0x00007FF1408E27E0
00007ff1409e51ee  jmp 0x00007FF1409E5086
00007ff1409e51f3  call 0x00007FF1408E1570
00007ff1409e51f8  jmp 0x00007FF1409E5092
00007ff1409e51fd  call 0x00007FF1408E27E0
00007ff1409e5202  jmp 0x00007FF1409E50AC
00007ff1409e5207  call 0x00007FF1408E0300
00007ff1409e520c  jmp 0x00007FF1409E50B8
00007ff1409e5211  call 0x00007FF1408E27E0
00007ff1409e5216  jmp 0x00007FF1409E50F0
00007ff1409e521b  call 0x00007FF1408E0300
00007ff1409e5220  jmp 0x00007FF1409E50FC
00007ff1409e5225  call 0x00007FF1408E27E0
00007ff1409e522a  jmp 0x00007FF1409E5134
00007ff1409e522f  call 0x00007FF1408E0300
00007ff1409e5234  jmp 0x00007FF1409E5140
00007ff1409e5239  call 0x00007FF1408E27E0
00007ff1409e523e  jmp 0x00007FF1409E5178
00007ff1409e5243  call 0x00007FF1408E0300
00007ff1409e5248  jmp 0x00007FF1409E5184
00007ff1409e524d  int3
00007ff1409e524e  nop
00007ff1409e5250  mov qword ptr [r15+0x100], 0x04
00007ff1409e525b  mov esi, 0x00
00007ff1409e5260  mov edx, 0x09
00007ff1409e5265  mov rdi, 0x7FFC13656710
00007ff1409e526f  mov rax, 0x565C7EF9F970
00007ff1409e5279  call rax
00007ff1409e527b  cmp dword ptr [r15+0x318], 0x00
00007ff1409e5283  jnz 0x00007FF1407FE110
00007ff1409e5289  jmp 0x00007FF1407FE0A0
00007ff1409e528e  int3
00007ff1409e528f  int3
