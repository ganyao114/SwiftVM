
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/baseline/0/2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13d,DWORD PTR [r12+0xa0]
   8:	mov    r14d,r13d
   b:	sub    r14d,0x1
   f:	pushf
  10:	pop    rdx
  11:	mov    r10d,edx
  14:	and    r10d,0xc0
  1b:	shl    r10d,0x18
  1f:	mov    r11d,edx
  22:	and    r11d,0x1
  26:	shl    r11d,0x1d
  2a:	or     r10d,r11d
  2d:	mov    r11d,edx
  30:	and    r11d,0x800
  37:	shl    r11d,0x11
  3b:	or     r10d,r11d
  3e:	mov    r11d,0xf0000000
  44:	and    r11,r10
  47:	movabs rsi,0xffffffff0fffffff
  51:	and    rbx,rsi
  54:	or     rbx,r11
  57:	btc    rbx,0x1d
  5c:	mov    QWORD PTR [r12+0xa0],r14
  64:	cmp    QWORD PTR [r12+0x380],0x0
  6d:	je     0x9a
  73:	mov    eax,0x410288
  78:	mov    QWORD PTR [r12+0x100],rax
  80:	mov    QWORD PTR [r12+0x108],rbx
  88:	mov    eax,0xc
  8d:	movabs r11,0x5b99604255f0
  97:	jmp    r11
  9a:	test   ebx,0x40000000
  a0:	je     0x175
  a6:	jmp    0xab
  ab:	mov    r13,QWORD PTR [r12+0xf8]
  b3:	mov    r14,r13
  b6:	add    r14,0x120
  bd:	mov    r15,QWORD PTR [r14]
  c0:	mov    QWORD PTR [r12+0x98],r15
  c8:	mov    r14d,0x80
  ce:	mov    QWORD PTR [r12+0x40],r14
  d3:	mov    r14,r13
  d6:	add    r14,0x100
  dd:	mov    QWORD PTR [r12],r14
  e1:	mov    r14,r13
  e4:	add    r14,0x17c
  eb:	mov    QWORD PTR [r12+0x8],r14
  f0:	mov    r14d,0x1
  f6:	mov    QWORD PTR [r12+0x10],r14
  fb:	mov    r14,r13
  fe:	add    r14,0x17c
 105:	movzx  r13d,BYTE PTR [r12+0x40]
 10b:	mov    BYTE PTR [r14],r13b
 10e:	mov    r13d,0x0
 114:	mov    DWORD PTR [r12+0x32c],r13d
 11c:	mov    r13d,0x4102a8
 122:	mov    QWORD PTR [r12+0xf0],r13
 12a:	mov    r13d,0x410728
 130:	mov    QWORD PTR [r12+0x100],r13
 138:	mov    QWORD PTR [r12+0x108],rbx
 140:	mov    edi,0x410728
 145:	mov    QWORD PTR [r12+0x100],rdi
 14d:	nop    DWORD PTR [rax]
 150:	jmp    QWORD PTR [rip+0x2]        # 0x158
 156:	xchg   ax,ax
 158:	sub    cl,0x8f
 15b:	(bad)
 15c:	fidiv  WORD PTR [rax+rax*1+0x0]
 160:	clc
 161:	sbb    eax,0x74de0690
 166:	add    BYTE PTR [rax],al
 168:	movabs r11,0x5b9960425370
 172:	jmp    r11
 175:	mov    r13,QWORD PTR [r12+0xf8]
 17d:	mov    r14,r13
 180:	add    r14,0x100
 187:	mov    QWORD PTR [r12],r14
 18b:	mov    r13d,0x0
 191:	mov    r14,QWORD PTR [r12+0x98]
 199:	mov    rcx,r14
 19c:	mov    r15,r13
 19f:	or     r15,rcx
 1a2:	mov    QWORD PTR [r12+0x8],r15
 1a7:	mov    r13d,0x12c
 1ad:	mov    QWORD PTR [r12+0x10],r13
 1b2:	mov    r13d,0x410284
 1b8:	mov    QWORD PTR [r12+0xf0],r13
 1c0:	mov    r13d,0x410728
 1c6:	mov    QWORD PTR [r12+0x100],r13
 1ce:	mov    QWORD PTR [r12+0x108],rbx
 1d6:	mov    edi,0x410728
 1db:	mov    QWORD PTR [r12+0x100],rdi
 1e3:	nop    DWORD PTR [rax+rax*1+0x0]
 1e8:	jmp    QWORD PTR [rip+0x2]        # 0x1f0
 1ee:	xchg   ax,ax
 1f0:	sub    cl,0x8f
 1f3:	(bad)
 1f4:	fidiv  WORD PTR [rax+rax*1+0x0]
 1f8:	nop
 1f9:	(bad)
 1fa:	nop
 1fb:	(bad)
 1fc:	fidiv  WORD PTR [rax+rax*1+0x0]
 200:	movabs r11,0x5b9960425370
 20a:	jmp    r11
 20d:	nop    DWORD PTR [rax]
 210:	jmp    0xab
 215:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 220:	jmp    0x175
 225:	nop
 226:	nop
 227:	nop
