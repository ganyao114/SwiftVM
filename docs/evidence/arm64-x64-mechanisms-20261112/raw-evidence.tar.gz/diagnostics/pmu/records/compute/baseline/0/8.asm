
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/baseline/0/8.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x140
       7:	mov    r13d,DWORD PTR [r12+0x98]
       f:	mov    r14d,r13d
      12:	add    r14d,0x1
      16:	mov    QWORD PTR [r12+0x98],r14
      1e:	mov    r13d,r14d
      21:	sub    r13d,0x10000
      28:	pushf
      29:	pop    rdx
      2a:	mov    r10d,edx
      2d:	and    r10d,0xc0
      34:	shl    r10d,0x18
      38:	mov    r11d,edx
      3b:	and    r11d,0x1
      3f:	shl    r11d,0x1d
      43:	or     r10d,r11d
      46:	mov    r11d,edx
      49:	and    r11d,0x800
      50:	shl    r11d,0x11
      54:	or     r10d,r11d
      57:	mov    r11d,0xf0000000
      5d:	and    r11,r10
      60:	movabs rsi,0xffffffff0fffffff
      6a:	and    rbx,rsi
      6d:	or     rbx,r11
      70:	btc    rbx,0x1d
      75:	cmp    QWORD PTR [r12+0x380],0x0
      7e:	je     0xb2
      84:	mov    eax,0x410400
      89:	mov    QWORD PTR [r12+0x100],rax
      91:	mov    QWORD PTR [r12+0x108],rbx
      99:	add    rsp,0x140
      a0:	mov    eax,0xc
      a5:	movabs r11,0x5b99604255f0
      af:	jmp    r11
      b2:	test   ebx,0x40000000
      b8:	je     0x92ec
      be:	jmp    0xc3
      c3:	mov    r13d,0x420000
      c9:	mov    QWORD PTR [r12+0x40],r13
      ce:	movabs r13,0x100000001
      d8:	mov    r14d,0x0
      de:	mov    QWORD PTR [r12+0x110],r13
      e6:	mov    QWORD PTR [r12+0x118],r14
      ee:	movabs r13,0x3fa0000000000000
      f8:	mov    QWORD PTR [r12+0x50],r13
      fd:	mov    r13d,0x420b10
     103:	mov    r14,QWORD PTR [r13+0x0]
     107:	mov    r13d,0x0
     10d:	mov    QWORD PTR [r12+0x120],r14
     115:	mov    QWORD PTR [r12+0x128],r13
     11d:	movabs r13,0x4100000041
     127:	mov    r14d,0x0
     12d:	mov    QWORD PTR [r12+0x140],r13
     135:	mov    QWORD PTR [r12+0x148],r14
     13d:	movabs r13,0x3fc0000000000000
     147:	movabs r14,0x3fc0000000000000
     151:	mov    QWORD PTR [r12+0x150],r13
     159:	mov    QWORD PTR [r12+0x158],r14
     161:	mov    r13d,0x2
     167:	mov    QWORD PTR [r12+0x40],r13
     16c:	movabs r13,0x200000002
     176:	mov    r14d,0x0
     17c:	mov    QWORD PTR [r12+0x160],r13
     184:	mov    QWORD PTR [r12+0x168],r14
     18c:	mov    r13,QWORD PTR [r12+0x50]
     191:	mov    r14,r13
     194:	and    r14,0xffffffffffffffff
     198:	mov    QWORD PTR [r12+0x130],r14
     1a0:	mov    QWORD PTR [r12+0x138],r14
     1a8:	mov    r13d,0x2
     1ae:	mov    QWORD PTR [r12+0x170],r13
     1b6:	mov    QWORD PTR [r12+0x178],r13
     1be:	mov    r13d,0x420000
     1c4:	mov    QWORD PTR [r12+0x40],r13
     1c9:	mov    r13d,0x430000
     1cf:	mov    QWORD PTR [r12+0x50],r13
     1d4:	mov    r13d,0x420a40
     1da:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     1e0:	movdqa xmm0,xmm2
     1e4:	movdqu XMMWORD PTR [r12+0x180],xmm0
     1ee:	mov    r13d,0x0
     1f4:	mov    QWORD PTR [r12+0x48],r13
     1f9:	mov    r13d,0x431000
     1ff:	mov    QWORD PTR [r12+0x40],r13
     204:	mov    r13d,0x431000
     20a:	mov    r14,r13
     20d:	add    r14,0xe00
     214:	mov    QWORD PTR [r12+0x40],r14
     219:	mov    r13d,0x430cb8
     21f:	mov    r14d,DWORD PTR [r12]
     223:	mov    DWORD PTR [r13+0x0],r14d
     227:	mov    r13d,0x0
     22d:	mov    DWORD PTR [r12+0x32c],r13d
     235:	mov    r13d,0x432000
     23b:	mov    QWORD PTR [r12+0x50],r13
     240:	mov    r13d,0x432000
     246:	mov    r14,r13
     249:	add    r14,0x0
     24d:	mov    QWORD PTR [r12+0x50],r14
     252:	jmp    0x257
     257:	mov    r13,QWORD PTR [r12+0x180]
     25f:	mov    r14,QWORD PTR [r12+0x188]
     267:	mov    r15d,0x0
     26d:	mov    rbp,r13
     270:	mov    r13,rbp
     273:	and    r13,0xffffffffffffffff
     277:	mov    ecx,0xffffffff
     27c:	mov    rbp,r13
     27f:	and    rbp,rcx
     282:	mov    r13,rbp
     285:	mov    rcx,r13
     288:	mov    rbp,r15
     28b:	or     rbp,rcx
     28e:	mov    r13,r14
     291:	mov    r14,r13
     294:	and    r14,0xffffffffffffffff
     298:	mov    ecx,0xffffffff
     29d:	mov    r13,r14
     2a0:	and    r13,rcx
     2a3:	mov    r14,r13
     2a6:	shl    r14,0x20
     2aa:	mov    rcx,r14
     2ad:	mov    r13,rbp
     2b0:	or     r13,rcx
     2b3:	mov    QWORD PTR [r12+0x210],r13
     2bb:	mov    QWORD PTR [r12+0x218],r15
     2c3:	movdqu xmm0,XMMWORD PTR [r12+0x140]
     2cd:	movdqa xmm2,xmm0
     2d1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     2db:	movdqa xmm3,xmm0
     2df:	movdqa xmm0,xmm2
     2e3:	movdqa xmm1,xmm3
     2e7:	psubd  xmm0,xmm1
     2eb:	movdqa xmm4,xmm0
     2ef:	movdqa xmm14,xmm4
     2f4:	movdqa xmm1,xmm14
     2f9:	movq   rax,xmm1
     2fe:	mov    r13,rax
     301:	mov    r14d,0x0
     307:	mov    QWORD PTR [r12+0x220],r13
     30f:	mov    QWORD PTR [r12+0x228],r14
     317:	movdqu xmm0,XMMWORD PTR [r12+0x180]
     321:	movdqa xmm2,xmm0
     325:	movdqu xmm0,XMMWORD PTR [r12+0x170]
     32f:	movdqa xmm4,xmm0
     333:	movdqa xmm0,xmm2
     337:	movdqa xmm1,xmm4
     33b:	paddq  xmm0,xmm1
     33f:	movdqa xmm5,xmm0
     343:	movdqa xmm0,xmm5
     347:	movdqu XMMWORD PTR [r12+0x180],xmm0
     351:	movdqu xmm0,XMMWORD PTR [r12+0x160]
     35b:	movdqa xmm2,xmm0
     35f:	movdqa xmm0,xmm3
     363:	movdqa xmm1,xmm2
     367:	paddd  xmm0,xmm1
     36b:	movdqa xmm4,xmm0
     36f:	movdqa xmm14,xmm4
     374:	movdqa xmm1,xmm14
     379:	movq   rax,xmm1
     37e:	mov    r14,rax
     381:	mov    r15d,0x0
     387:	mov    QWORD PTR [r12+0x120],r14
     38f:	mov    QWORD PTR [r12+0x128],r15
     397:	mov    r14d,0x0
     39d:	mov    r15,r13
     3a0:	mov    ecx,0xffffffff
     3a5:	mov    rbp,r15
     3a8:	and    rbp,rcx
     3ab:	mov    r15,rbp
     3ae:	mov    rbp,r15
     3b1:	and    rbp,0xffffffffffffffff
     3b5:	mov    r15,rbp
     3b8:	mov    rcx,r15
     3bb:	mov    rbp,r14
     3be:	or     rbp,rcx
     3c1:	mov    r15,r13
     3c4:	shr    r15,0x20
     3c8:	mov    ecx,0xffffffff
     3cd:	mov    r13,r15
     3d0:	and    r13,rcx
     3d3:	mov    r15,r13
     3d6:	mov    r13,r15
     3d9:	and    r13,0xffffffffffffffff
     3dd:	mov    r15,r13
     3e0:	mov    rcx,r15
     3e3:	mov    r13,r14
     3e6:	or     r13,rcx
     3e9:	mov    QWORD PTR [r12+0x220],rbp
     3f1:	mov    QWORD PTR [r12+0x228],r13
     3f9:	movdqu xmm0,XMMWORD PTR [r12+0x210]
     403:	movdqa xmm2,xmm0
     407:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     411:	movdqa xmm3,xmm0
     415:	movdqa xmm0,xmm2
     419:	movdqa xmm1,xmm3
     41d:	paddd  xmm0,xmm1
     421:	movdqa xmm4,xmm0
     425:	movdqa xmm14,xmm4
     42a:	movdqa xmm1,xmm14
     42f:	movq   rax,xmm1
     434:	mov    r13,rax
     437:	mov    r14d,0x0
     43d:	mov    QWORD PTR [r12+0x210],r13
     445:	mov    QWORD PTR [r12+0x218],r14
     44d:	lea    r13,[r12]
     451:	movabs r14,0xb6e61da31
     45b:	mov    r15d,0x410468
     461:	mov    QWORD PTR [r12+0x378],0x3
     46d:	mov    QWORD PTR [r12+0x108],rbx
     475:	stmxcsr DWORD PTR [r12-0x28]
     47b:	ldmxcsr DWORD PTR [r12-0x38]
     481:	movabs r11,0x5b996028a4c0
     48b:	mov    rdi,r13
     48e:	mov    rsi,r14
     491:	mov    rdx,r15
     494:	call   r11
     497:	ldmxcsr DWORD PTR [r12-0x28]
     49d:	mov    rbx,QWORD PTR [r12+0x108]
     4a5:	mov    QWORD PTR [r12+0x378],0x2
     4b1:	mov    rbp,rax
     4b4:	mov    r13,QWORD PTR [r12+0x210]
     4bc:	mov    r14d,0x0
     4c2:	mov    r15,r13
     4c5:	mov    ecx,0xffffffff
     4ca:	mov    rbp,r15
     4cd:	and    rbp,rcx
     4d0:	mov    r15,rbp
     4d3:	mov    rbp,r15
     4d6:	and    rbp,0xffffffffffffffff
     4da:	mov    r15,rbp
     4dd:	mov    rcx,r15
     4e0:	mov    rbp,r14
     4e3:	or     rbp,rcx
     4e6:	mov    r15,r13
     4e9:	shr    r15,0x20
     4ed:	mov    ecx,0xffffffff
     4f2:	mov    r13,r15
     4f5:	and    r13,rcx
     4f8:	mov    r15,r13
     4fb:	mov    r13,r15
     4fe:	and    r13,0xffffffffffffffff
     502:	mov    r15,r13
     505:	mov    rcx,r15
     508:	mov    r13,r14
     50b:	or     r13,rcx
     50e:	mov    QWORD PTR [r12+0x210],rbp
     516:	mov    QWORD PTR [r12+0x218],r13
     51e:	lea    r13,[r12]
     522:	movabs r14,0xb6e61da10
     52c:	mov    r15d,0x410470
     532:	mov    QWORD PTR [r12+0x378],0x3
     53e:	mov    QWORD PTR [r12+0x108],rbx
     546:	stmxcsr DWORD PTR [r12-0x28]
     54c:	ldmxcsr DWORD PTR [r12-0x38]
     552:	movabs r11,0x5b996028a4c0
     55c:	mov    rdi,r13
     55f:	mov    rsi,r14
     562:	mov    rdx,r15
     565:	call   r11
     568:	ldmxcsr DWORD PTR [r12-0x28]
     56e:	mov    rbx,QWORD PTR [r12+0x108]
     576:	mov    QWORD PTR [r12+0x378],0x2
     582:	mov    rbp,rax
     585:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     58f:	movdqa xmm2,xmm0
     593:	movdqu xmm0,XMMWORD PTR [r12+0x150]
     59d:	movdqa xmm3,xmm0
     5a1:	cmp    DWORD PTR [r12+0x310],0x0
     5aa:	jne    0x68e
     5b0:	movdqa xmm0,xmm2
     5b4:	movdqa xmm1,xmm3
     5b8:	movq   rax,xmm0
     5bd:	add    rax,rax
     5c0:	je     0x5d6
     5c2:	shr    rax,0x35
     5c6:	sub    eax,0x201
     5cb:	cmp    eax,0x3fc
     5d0:	ja     0x68e
     5d6:	movdqa xmm14,xmm0
     5db:	psrldq xmm14,0x8
     5e1:	movq   rax,xmm14
     5e6:	add    rax,rax
     5e9:	je     0x5ff
     5eb:	shr    rax,0x35
     5ef:	sub    eax,0x201
     5f4:	cmp    eax,0x3fc
     5f9:	ja     0x68e
     5ff:	movq   rax,xmm1
     604:	add    rax,rax
     607:	je     0x61d
     609:	shr    rax,0x35
     60d:	sub    eax,0x201
     612:	cmp    eax,0x3fc
     617:	ja     0x68e
     61d:	movdqa xmm14,xmm1
     622:	psrldq xmm14,0x8
     628:	movq   rax,xmm14
     62d:	add    rax,rax
     630:	je     0x646
     632:	shr    rax,0x35
     636:	sub    eax,0x201
     63b:	cmp    eax,0x3fc
     640:	ja     0x68e
     646:	stmxcsr DWORD PTR [rsp+0x100]
     64e:	mov    DWORD PTR [rsp+0x104],0x1f80
     659:	ldmxcsr DWORD PTR [rsp+0x104]
     661:	mulpd  xmm0,xmm1
     665:	stmxcsr DWORD PTR [rsp+0x104]
     66d:	ldmxcsr DWORD PTR [rsp+0x100]
     675:	mov    eax,DWORD PTR [rsp+0x104]
     67c:	shr    eax,1
     67e:	and    eax,0x10
     681:	or     DWORD PTR [r12+0x314],eax
     689:	jmp    0x73b
     68e:	movdqa xmm0,xmm2
     692:	movdqa xmm1,xmm3
     696:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     69f:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     6a8:	mov    QWORD PTR [r12+0x378],0x3
     6b4:	movdqu XMMWORD PTR [rsp],xmm2
     6b9:	movdqu XMMWORD PTR [rsp+0x10],xmm3
     6bf:	mov    QWORD PTR [r12+0x108],rbx
     6c7:	stmxcsr DWORD PTR [r12-0x28]
     6cd:	ldmxcsr DWORD PTR [r12-0x38]
     6d3:	lea    rdi,[rsp+0xf0]
     6db:	lea    rsi,[rsp+0xd0]
     6e3:	lea    rdx,[rsp+0xe0]
     6eb:	mov    ecx,0x16
     6f0:	mov    r8d,DWORD PTR [r12+0x310]
     6f8:	lea    r9,[r12+0x314]
     700:	movabs r11,0x5b9960291750
     70a:	call   r11
     70d:	ldmxcsr DWORD PTR [r12-0x28]
     713:	movdqu xmm2,XMMWORD PTR [rsp]
     718:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
     71e:	mov    rbx,QWORD PTR [r12+0x108]
     726:	mov    QWORD PTR [r12+0x378],0x2
     732:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     73b:	movdqa xmm4,xmm0
     73f:	movdqa xmm0,xmm4
     743:	movdqu XMMWORD PTR [r12+0x220],xmm0
     74d:	mov    r13,QWORD PTR [r12+0x48]
     752:	mov    r14,QWORD PTR [r12+0x50]
     757:	mov    rcx,r13
     75a:	mov    r15,r14
     75d:	add    r15,rcx
     760:	movdqu XMMWORD PTR [r15],xmm4
     765:	mov    r13d,0x0
     76b:	mov    DWORD PTR [r12+0x32c],r13d
     773:	movdqu xmm0,XMMWORD PTR [r12+0x210]
     77d:	movdqa xmm2,xmm0
     781:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     78b:	movdqa xmm3,xmm0
     78f:	cmp    DWORD PTR [r12+0x310],0x0
     798:	jne    0x87c
     79e:	movdqa xmm0,xmm2
     7a2:	movdqa xmm1,xmm3
     7a6:	movq   rax,xmm0
     7ab:	add    rax,rax
     7ae:	je     0x7c4
     7b0:	shr    rax,0x35
     7b4:	sub    eax,0x201
     7b9:	cmp    eax,0x3fc
     7be:	ja     0x87c
     7c4:	movdqa xmm14,xmm0
     7c9:	psrldq xmm14,0x8
     7cf:	movq   rax,xmm14
     7d4:	add    rax,rax
     7d7:	je     0x7ed
     7d9:	shr    rax,0x35
     7dd:	sub    eax,0x201
     7e2:	cmp    eax,0x3fc
     7e7:	ja     0x87c
     7ed:	movq   rax,xmm1
     7f2:	add    rax,rax
     7f5:	je     0x80b
     7f7:	shr    rax,0x35
     7fb:	sub    eax,0x201
     800:	cmp    eax,0x3fc
     805:	ja     0x87c
     80b:	movdqa xmm14,xmm1
     810:	psrldq xmm14,0x8
     816:	movq   rax,xmm14
     81b:	add    rax,rax
     81e:	je     0x834
     820:	shr    rax,0x35
     824:	sub    eax,0x201
     829:	cmp    eax,0x3fc
     82e:	ja     0x87c
     834:	stmxcsr DWORD PTR [rsp+0x100]
     83c:	mov    DWORD PTR [rsp+0x104],0x1f80
     847:	ldmxcsr DWORD PTR [rsp+0x104]
     84f:	mulpd  xmm0,xmm1
     853:	stmxcsr DWORD PTR [rsp+0x104]
     85b:	ldmxcsr DWORD PTR [rsp+0x100]
     863:	mov    eax,DWORD PTR [rsp+0x104]
     86a:	shr    eax,1
     86c:	and    eax,0x10
     86f:	or     DWORD PTR [r12+0x314],eax
     877:	jmp    0x929
     87c:	movdqa xmm0,xmm2
     880:	movdqa xmm1,xmm3
     884:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     88d:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     896:	mov    QWORD PTR [r12+0x378],0x3
     8a2:	movdqu XMMWORD PTR [rsp],xmm2
     8a7:	movdqu XMMWORD PTR [rsp+0x10],xmm3
     8ad:	mov    QWORD PTR [r12+0x108],rbx
     8b5:	stmxcsr DWORD PTR [r12-0x28]
     8bb:	ldmxcsr DWORD PTR [r12-0x38]
     8c1:	lea    rdi,[rsp+0xf0]
     8c9:	lea    rsi,[rsp+0xd0]
     8d1:	lea    rdx,[rsp+0xe0]
     8d9:	mov    ecx,0x16
     8de:	mov    r8d,DWORD PTR [r12+0x310]
     8e6:	lea    r9,[r12+0x314]
     8ee:	movabs r11,0x5b9960291750
     8f8:	call   r11
     8fb:	ldmxcsr DWORD PTR [r12-0x28]
     901:	movdqu xmm2,XMMWORD PTR [rsp]
     906:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
     90c:	mov    rbx,QWORD PTR [r12+0x108]
     914:	mov    QWORD PTR [r12+0x378],0x2
     920:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     929:	movdqa xmm4,xmm0
     92d:	movdqa xmm0,xmm4
     931:	movdqu XMMWORD PTR [r12+0x210],xmm0
     93b:	mov    r13,QWORD PTR [r12+0x48]
     940:	mov    r14,QWORD PTR [r12+0x40]
     945:	mov    rcx,r13
     948:	mov    r15,r14
     94b:	add    r15,rcx
     94e:	movdqu XMMWORD PTR [r15],xmm4
     953:	mov    r14d,0x0
     959:	mov    DWORD PTR [r12+0x32c],r14d
     961:	mov    r14,r13
     964:	add    r14,0x10
     968:	mov    QWORD PTR [r12+0x48],r14
     96d:	mov    r13,r14
     970:	sub    r13,0x200
     977:	pushf
     978:	pop    rdx
     979:	mov    r10d,edx
     97c:	and    r10d,0xc0
     983:	shl    r10d,0x18
     987:	mov    r11d,edx
     98a:	and    r11d,0x1
     98e:	shl    r11d,0x1d
     992:	or     r10d,r11d
     995:	mov    r11d,edx
     998:	and    r11d,0x800
     99f:	shl    r11d,0x11
     9a3:	or     r10d,r11d
     9a6:	mov    r11d,0xf0000000
     9ac:	and    r11,r10
     9af:	movabs rsi,0xffffffff0fffffff
     9b9:	and    rbx,rsi
     9bc:	or     rbx,r11
     9bf:	btc    rbx,0x1d
     9c4:	cmp    QWORD PTR [r12+0x380],0x0
     9cd:	je     0xa01
     9d3:	mov    eax,0x41048c
     9d8:	mov    QWORD PTR [r12+0x100],rax
     9e0:	mov    QWORD PTR [r12+0x108],rbx
     9e8:	add    rsp,0x140
     9ef:	mov    eax,0xc
     9f4:	movabs r11,0x5b99604255f0
     9fe:	jmp    r11
     a01:	test   ebx,0x40000000
     a07:	je     0x257
     a0d:	jmp    0xa12
     a12:	mov    r13,QWORD PTR [r12+0x50]
     a17:	mov    r14,r13
     a1a:	add    r14,0x80
     a21:	mov    r15,r14
     a24:	add    r15,0x10
     a28:	movdqu xmm2,XMMWORD PTR [r14]
     a2d:	movdqu xmm3,XMMWORD PTR [r15]
     a32:	movdqa xmm0,xmm2
     a36:	movdqu XMMWORD PTR [r12+0x130],xmm0
     a40:	movdqa xmm0,xmm3
     a44:	movdqu XMMWORD PTR [r12+0x110],xmm0
     a4e:	mov    r14d,0x0
     a54:	mov    r15d,0x0
     a5a:	mov    QWORD PTR [r12+0x1b0],r14
     a62:	mov    QWORD PTR [r12+0x1b8],r15
     a6a:	mov    r14,r13
     a6d:	add    r14,0x40
     a71:	mov    r15,r14
     a74:	add    r15,0x10
     a78:	movdqu xmm2,XMMWORD PTR [r14]
     a7d:	movdqu xmm3,XMMWORD PTR [r15]
     a82:	movdqa xmm0,xmm2
     a86:	movdqu XMMWORD PTR [r12+0x250],xmm0
     a90:	movdqa xmm0,xmm3
     a94:	movdqu XMMWORD PTR [r12+0x120],xmm0
     a9e:	mov    r14d,0x0
     aa4:	mov    QWORD PTR [r12+0x48],r14
     aa9:	mov    r14,r13
     aac:	add    r14,0x10
     ab0:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     ab6:	movdqu xmm3,XMMWORD PTR [r14]
     abb:	movdqa xmm0,xmm2
     abf:	movdqu XMMWORD PTR [r12+0x170],xmm0
     ac9:	movdqa xmm0,xmm3
     acd:	movdqu XMMWORD PTR [r12+0x180],xmm0
     ad7:	mov    r13,QWORD PTR [r12+0xf8]
     adf:	mov    r14,r13
     ae2:	add    r14,0xe0
     ae9:	mov    r13,r14
     aec:	add    r13,0x10
     af0:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     afa:	movdqa xmm2,xmm0
     afe:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     b08:	movdqa xmm3,xmm0
     b0c:	movdqu XMMWORD PTR [r14],xmm2
     b11:	mov    r14d,0x0
     b17:	mov    DWORD PTR [r12+0x32c],r14d
     b1f:	movdqu XMMWORD PTR [r13+0x0],xmm3
     b25:	mov    r13d,0x0
     b2b:	mov    DWORD PTR [r12+0x32c],r13d
     b33:	mov    r13,QWORD PTR [r12+0x50]
     b38:	mov    r14,r13
     b3b:	add    r14,0xc0
     b42:	mov    r15,r14
     b45:	add    r15,0x10
     b49:	movdqu xmm2,XMMWORD PTR [r14]
     b4e:	movdqu xmm3,XMMWORD PTR [r15]
     b53:	movdqa xmm0,xmm2
     b57:	movdqu XMMWORD PTR [r12+0x130],xmm0
     b61:	movdqa xmm0,xmm3
     b65:	movdqu XMMWORD PTR [r12+0x110],xmm0
     b6f:	mov    r14,r13
     b72:	add    r14,0x140
     b79:	mov    r15,r14
     b7c:	add    r15,0x10
     b80:	movdqu xmm2,XMMWORD PTR [r14]
     b85:	movdqu xmm3,XMMWORD PTR [r15]
     b8a:	movdqa xmm0,xmm2
     b8e:	movdqu XMMWORD PTR [r12+0x270],xmm0
     b98:	movdqa xmm0,xmm3
     b9c:	movdqu XMMWORD PTR [r12+0x190],xmm0
     ba6:	mov    r14,r13
     ba9:	add    r14,0x180
     bb0:	mov    r13,r14
     bb3:	add    r13,0x10
     bb7:	movdqu xmm2,XMMWORD PTR [r14]
     bbc:	movdqu xmm3,XMMWORD PTR [r13+0x0]
     bc2:	movdqa xmm0,xmm2
     bc6:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
     bd0:	movdqa xmm0,xmm3
     bd4:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
     bde:	mov    r13,QWORD PTR [r12+0xf8]
     be6:	mov    r14,r13
     be9:	add    r14,0xc0
     bf0:	mov    r13,r14
     bf3:	add    r13,0x10
     bf7:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     c01:	movdqa xmm2,xmm0
     c05:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     c0f:	movdqa xmm3,xmm0
     c13:	movdqu XMMWORD PTR [r14],xmm2
     c18:	mov    r14d,0x0
     c1e:	mov    DWORD PTR [r12+0x32c],r14d
     c26:	movdqu XMMWORD PTR [r13+0x0],xmm3
     c2c:	mov    r13d,0x0
     c32:	mov    DWORD PTR [r12+0x32c],r13d
     c3a:	mov    r13,QWORD PTR [r12+0x50]
     c3f:	mov    r14,r13
     c42:	add    r14,0x100
     c49:	mov    r15,r14
     c4c:	add    r15,0x10
     c50:	movdqu xmm2,XMMWORD PTR [r14]
     c55:	movdqu xmm3,XMMWORD PTR [r15]
     c5a:	movdqa xmm0,xmm2
     c5e:	movdqu XMMWORD PTR [r12+0x110],xmm0
     c68:	movdqa xmm0,xmm3
     c6c:	movdqu XMMWORD PTR [r12+0x300],xmm0
     c76:	mov    r14,r13
     c79:	add    r14,0x1c0
     c80:	mov    r15,r14
     c83:	add    r15,0x10
     c87:	movdqu xmm2,XMMWORD PTR [r14]
     c8c:	movdqu xmm3,XMMWORD PTR [r15]
     c91:	movdqa xmm0,xmm2
     c95:	movdqu XMMWORD PTR [r12+0x240],xmm0
     c9f:	movdqa xmm0,xmm3
     ca3:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
     cad:	mov    r14,r13
     cb0:	add    r14,0x20
     cb4:	mov    r13,r14
     cb7:	add    r13,0x10
     cbb:	movdqu xmm2,XMMWORD PTR [r14]
     cc0:	movdqu xmm3,XMMWORD PTR [r13+0x0]
     cc6:	movdqa xmm0,xmm2
     cca:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
     cd4:	movdqa xmm0,xmm3
     cd8:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
     ce2:	mov    r13,QWORD PTR [r12+0xf8]
     cea:	mov    r14,r13
     ced:	add    r14,0x20
     cf1:	mov    r15,r14
     cf4:	add    r15,0x10
     cf8:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     d02:	movdqa xmm2,xmm0
     d06:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     d10:	movdqa xmm3,xmm0
     d14:	movdqu XMMWORD PTR [r14],xmm2
     d19:	mov    r14d,0x0
     d1f:	mov    DWORD PTR [r12+0x32c],r14d
     d27:	movdqu XMMWORD PTR [r15],xmm3
     d2c:	mov    r14d,0x0
     d32:	mov    DWORD PTR [r12+0x32c],r14d
     d3a:	mov    r14,QWORD PTR [r12+0x50]
     d3f:	mov    r15,r14
     d42:	add    r15,0x60
     d46:	mov    rbp,r15
     d49:	add    rbp,0x10
     d4d:	movdqu xmm2,XMMWORD PTR [r15]
     d52:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     d57:	movdqa xmm0,xmm2
     d5b:	movdqu XMMWORD PTR [r12+0x110],xmm0
     d65:	movdqa xmm0,xmm3
     d69:	movdqu XMMWORD PTR [r12+0x120],xmm0
     d73:	mov    r15,r13
     d76:	add    r15,0x60
     d7a:	mov    r13,r15
     d7d:	add    r13,0x10
     d81:	movdqu xmm0,XMMWORD PTR [r12+0x170]
     d8b:	movdqa xmm2,xmm0
     d8f:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     d99:	movdqa xmm3,xmm0
     d9d:	movdqu XMMWORD PTR [r15],xmm2
     da2:	mov    r15d,0x0
     da8:	mov    DWORD PTR [r12+0x32c],r15d
     db0:	movdqu XMMWORD PTR [r13+0x0],xmm3
     db6:	mov    r13d,0x0
     dbc:	mov    DWORD PTR [r12+0x32c],r13d
     dc4:	mov    r13,r14
     dc7:	add    r13,0xe0
     dce:	mov    r15,r13
     dd1:	add    r15,0x10
     dd5:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     ddb:	movdqu xmm3,XMMWORD PTR [r15]
     de0:	movdqa xmm0,xmm2
     de4:	movdqu XMMWORD PTR [r12+0x200],xmm0
     dee:	movdqa xmm0,xmm3
     df2:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
     dfc:	mov    r13,r14
     dff:	add    r13,0x120
     e06:	mov    r14,r13
     e09:	add    r14,0x10
     e0d:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     e13:	movdqu xmm3,XMMWORD PTR [r14]
     e18:	movdqa xmm0,xmm2
     e1c:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
     e26:	movdqa xmm0,xmm3
     e2a:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
     e34:	mov    r13,QWORD PTR [r12+0xf8]
     e3c:	mov    r14,r13
     e3f:	add    r14,0xa0
     e46:	mov    r13,r14
     e49:	add    r13,0x10
     e4d:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     e57:	movdqa xmm2,xmm0
     e5b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     e65:	movdqa xmm3,xmm0
     e69:	movdqu XMMWORD PTR [r14],xmm2
     e6e:	mov    r14d,0x0
     e74:	mov    DWORD PTR [r12+0x32c],r14d
     e7c:	movdqu XMMWORD PTR [r13+0x0],xmm3
     e82:	mov    r13d,0x0
     e88:	mov    DWORD PTR [r12+0x32c],r13d
     e90:	mov    r13,QWORD PTR [r12+0x50]
     e95:	mov    r14,r13
     e98:	add    r14,0xa0
     e9f:	mov    r15,r14
     ea2:	add    r15,0x10
     ea6:	movdqu xmm2,XMMWORD PTR [r14]
     eab:	movdqu xmm3,XMMWORD PTR [r15]
     eb0:	movdqa xmm0,xmm2
     eb4:	movdqu XMMWORD PTR [r12+0x110],xmm0
     ebe:	movdqa xmm0,xmm3
     ec2:	movdqu XMMWORD PTR [r12+0x120],xmm0
     ecc:	mov    r14,r13
     ecf:	add    r14,0x160
     ed6:	mov    r15,r14
     ed9:	add    r15,0x10
     edd:	movdqu xmm2,XMMWORD PTR [r14]
     ee2:	movdqu xmm3,XMMWORD PTR [r15]
     ee7:	movdqa xmm0,xmm2
     eeb:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
     ef5:	movdqa xmm0,xmm3
     ef9:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
     f03:	mov    r14,r13
     f06:	add    r14,0x1a0
     f0d:	mov    r13,r14
     f10:	add    r13,0x10
     f14:	movdqu xmm2,XMMWORD PTR [r14]
     f19:	movdqu xmm3,XMMWORD PTR [r13+0x0]
     f1f:	movdqa xmm0,xmm2
     f23:	movdqu XMMWORD PTR [r12+0x290],xmm0
     f2d:	movdqa xmm0,xmm3
     f31:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
     f3b:	mov    r13,QWORD PTR [r12+0xf8]
     f43:	mov    r14,r13
     f46:	add    r14,0x80
     f4d:	mov    r15,r14
     f50:	add    r15,0x10
     f54:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     f5e:	movdqa xmm2,xmm0
     f62:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     f6c:	movdqa xmm3,xmm0
     f70:	movdqu XMMWORD PTR [r14],xmm2
     f75:	mov    r14d,0x0
     f7b:	mov    DWORD PTR [r12+0x32c],r14d
     f83:	movdqu XMMWORD PTR [r15],xmm3
     f88:	mov    r14d,0x0
     f8e:	mov    DWORD PTR [r12+0x32c],r14d
     f96:	mov    r14,QWORD PTR [r12+0x50]
     f9b:	mov    r15,r14
     f9e:	add    r15,0x1e0
     fa5:	mov    r14,r15
     fa8:	add    r14,0x10
     fac:	movdqu xmm2,XMMWORD PTR [r15]
     fb1:	movdqu xmm3,XMMWORD PTR [r14]
     fb6:	movdqa xmm0,xmm2
     fba:	movdqu XMMWORD PTR [r12+0x230],xmm0
     fc4:	movdqa xmm0,xmm3
     fc8:	movdqu XMMWORD PTR [r12+0x280],xmm0
     fd2:	mov    r14d,0x432000
     fd8:	mov    QWORD PTR [r12+0x50],r14
     fdd:	mov    r14d,0x432000
     fe3:	mov    r15,r14
     fe6:	add    r15,0x200
     fed:	mov    QWORD PTR [r12+0x50],r15
     ff2:	mov    r14,r13
     ff5:	add    r14,0x40
     ff9:	mov    r13,r14
     ffc:	add    r13,0x10
    1000:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    100a:	movdqa xmm4,xmm0
    100e:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    1018:	movdqa xmm5,xmm0
    101c:	movdqu XMMWORD PTR [r14],xmm4
    1021:	mov    r14d,0x0
    1027:	mov    DWORD PTR [r12+0x32c],r14d
    102f:	movdqu XMMWORD PTR [r13+0x0],xmm5
    1035:	mov    r13d,0x0
    103b:	mov    DWORD PTR [r12+0x32c],r13d
    1043:	mov    r13,QWORD PTR [r12+0xf8]
    104b:	mov    r14,r13
    104e:	add    r14,0x10
    1052:	movdqu XMMWORD PTR [r13+0x0],xmm3
    1058:	mov    r13d,0x0
    105e:	mov    DWORD PTR [r12+0x32c],r13d
    1066:	movdqu XMMWORD PTR [r14],xmm2
    106b:	mov    r13d,0x0
    1071:	mov    DWORD PTR [r12+0x32c],r13d
    1079:	jmp    0x107e
    107e:	mov    r13d,0x0
    1084:	mov    QWORD PTR [r12+0x58],r13
    1089:	jmp    0x108e
    108e:	mov    r13,QWORD PTR [r12+0x58]
    1093:	mov    r14,QWORD PTR [r12+0x40]
    1098:	mov    rcx,r13
    109b:	mov    r15,r14
    109e:	add    r15,rcx
    10a1:	mov    QWORD PTR [r12+0x60],r15
    10a6:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    10b0:	movdqa xmm2,xmm0
    10b4:	movdqa xmm0,xmm2
    10b8:	movdqa xmm1,xmm2
    10bc:	por    xmm0,xmm1
    10c0:	movdqa xmm3,xmm0
    10c4:	movdqa xmm0,xmm3
    10c8:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    10d2:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    10dc:	movdqa xmm2,xmm0
    10e0:	movdqa xmm0,xmm2
    10e4:	movdqa xmm1,xmm2
    10e8:	por    xmm0,xmm1
    10ec:	movdqa xmm3,xmm0
    10f0:	movdqa xmm0,xmm3
    10f4:	movdqu XMMWORD PTR [r12+0x120],xmm0
    10fe:	mov    r13,r15
    1101:	add    r13,0x30
    1105:	mov    r14,r13
    1108:	add    r14,0x8
    110c:	mov    r15,QWORD PTR [r13+0x0]
    1110:	mov    r13,QWORD PTR [r14]
    1113:	mov    r14d,0x0
    1119:	mov    QWORD PTR [r12+0x130],r15
    1121:	mov    QWORD PTR [r12+0x138],r14
    1129:	mov    r14d,0x0
    112f:	mov    QWORD PTR [r12+0x280],r13
    1137:	mov    QWORD PTR [r12+0x288],r14
    113f:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    1149:	movdqa xmm2,xmm0
    114d:	movdqa xmm0,xmm2
    1151:	movdqa xmm1,xmm2
    1155:	por    xmm0,xmm1
    1159:	movdqa xmm3,xmm0
    115d:	movdqa xmm0,xmm3
    1161:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    116b:	mov    r13,QWORD PTR [r12+0x60]
    1170:	mov    r14,r13
    1173:	add    r14,0x20
    1177:	mov    r15,r14
    117a:	add    r15,0x8
    117e:	mov    rbp,QWORD PTR [r14]
    1181:	mov    r14,QWORD PTR [r15]
    1184:	mov    r15d,0x0
    118a:	mov    QWORD PTR [r12+0x150],rbp
    1192:	mov    QWORD PTR [r12+0x158],r15
    119a:	mov    r15d,0x0
    11a0:	mov    QWORD PTR [r12+0x140],r14
    11a8:	mov    QWORD PTR [r12+0x148],r15
    11b0:	mov    r14,r13
    11b3:	add    r14,0x10
    11b7:	mov    r13,r14
    11ba:	add    r13,0x8
    11be:	mov    r15,QWORD PTR [r14]
    11c1:	mov    r14,QWORD PTR [r13+0x0]
    11c5:	mov    r13d,0x0
    11cb:	mov    QWORD PTR [r12+0x170],r15
    11d3:	mov    QWORD PTR [r12+0x178],r13
    11db:	mov    r13d,0x0
    11e1:	mov    QWORD PTR [r12+0x160],r14
    11e9:	mov    QWORD PTR [r12+0x168],r13
    11f1:	mov    r13,QWORD PTR [r12+0x60]
    11f6:	mov    r14d,0x8
    11fc:	mov    r15,QWORD PTR [r13+0x0]
    1200:	mov    QWORD PTR [r12+0x180],r15
    1208:	mov    QWORD PTR [r12+0x188],r15
    1210:	mov    rcx,r14
    1213:	mov    r15,r13
    1216:	add    r15,rcx
    1219:	mov    QWORD PTR [r12+0x60],r15
    121e:	mov    r13,QWORD PTR [r15]
    1221:	mov    r14d,0x0
    1227:	mov    QWORD PTR [r12+0x230],r13
    122f:	mov    QWORD PTR [r12+0x238],r14
    1237:	mov    r13,QWORD PTR [r12+0xf8]
    123f:	mov    r14,r13
    1242:	add    r14,0x50
    1246:	mov    r15,r14
    1249:	add    r15,0x10
    124d:	movdqu xmm2,XMMWORD PTR [r14]
    1252:	movdqu xmm3,XMMWORD PTR [r15]
    1257:	movdqa xmm0,xmm2
    125b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    1265:	movdqa xmm0,xmm3
    1269:	movdqu XMMWORD PTR [r12+0x210],xmm0
    1273:	mov    r14,r13
    1276:	add    r14,0x30
    127a:	movdqu xmm2,XMMWORD PTR [r14]
    127f:	movdqa xmm0,xmm2
    1283:	movdqu XMMWORD PTR [r12+0x110],xmm0
    128d:	mov    r13,QWORD PTR [r12+0x58]
    1292:	mov    r14,QWORD PTR [r12+0x50]
    1297:	mov    rcx,r13
    129a:	mov    r15,r14
    129d:	add    r15,rcx
    12a0:	mov    QWORD PTR [r12+0x60],r15
    12a5:	mov    r14,r13
    12a8:	add    r14,0x40
    12ac:	mov    QWORD PTR [r12+0x58],r14
    12b1:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    12bb:	movdqa xmm2,xmm0
    12bf:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    12c9:	movdqa xmm3,xmm0
    12cd:	cmp    DWORD PTR [r12+0x310],0x0
    12d6:	jne    0x13ba
    12dc:	movdqa xmm0,xmm2
    12e0:	movdqa xmm1,xmm3
    12e4:	movq   rax,xmm0
    12e9:	add    rax,rax
    12ec:	je     0x1302
    12ee:	shr    rax,0x35
    12f2:	sub    eax,0x201
    12f7:	cmp    eax,0x3fc
    12fc:	ja     0x13ba
    1302:	movdqa xmm14,xmm0
    1307:	psrldq xmm14,0x8
    130d:	movq   rax,xmm14
    1312:	add    rax,rax
    1315:	je     0x132b
    1317:	shr    rax,0x35
    131b:	sub    eax,0x201
    1320:	cmp    eax,0x3fc
    1325:	ja     0x13ba
    132b:	movq   rax,xmm1
    1330:	add    rax,rax
    1333:	je     0x1349
    1335:	shr    rax,0x35
    1339:	sub    eax,0x201
    133e:	cmp    eax,0x3fc
    1343:	ja     0x13ba
    1349:	movdqa xmm14,xmm1
    134e:	psrldq xmm14,0x8
    1354:	movq   rax,xmm14
    1359:	add    rax,rax
    135c:	je     0x1372
    135e:	shr    rax,0x35
    1362:	sub    eax,0x201
    1367:	cmp    eax,0x3fc
    136c:	ja     0x13ba
    1372:	stmxcsr DWORD PTR [rsp+0x100]
    137a:	mov    DWORD PTR [rsp+0x104],0x1f80
    1385:	ldmxcsr DWORD PTR [rsp+0x104]
    138d:	mulpd  xmm0,xmm1
    1391:	stmxcsr DWORD PTR [rsp+0x104]
    1399:	ldmxcsr DWORD PTR [rsp+0x100]
    13a1:	mov    eax,DWORD PTR [rsp+0x104]
    13a8:	shr    eax,1
    13aa:	and    eax,0x10
    13ad:	or     DWORD PTR [r12+0x314],eax
    13b5:	jmp    0x1467
    13ba:	movdqa xmm0,xmm2
    13be:	movdqa xmm1,xmm3
    13c2:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    13cb:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    13d4:	mov    QWORD PTR [r12+0x378],0x3
    13e0:	movdqu XMMWORD PTR [rsp],xmm2
    13e5:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    13eb:	mov    QWORD PTR [r12+0x108],rbx
    13f3:	stmxcsr DWORD PTR [r12-0x28]
    13f9:	ldmxcsr DWORD PTR [r12-0x38]
    13ff:	lea    rdi,[rsp+0xf0]
    1407:	lea    rsi,[rsp+0xd0]
    140f:	lea    rdx,[rsp+0xe0]
    1417:	mov    ecx,0x16
    141c:	mov    r8d,DWORD PTR [r12+0x310]
    1424:	lea    r9,[r12+0x314]
    142c:	movabs r11,0x5b9960291750
    1436:	call   r11
    1439:	ldmxcsr DWORD PTR [r12-0x28]
    143f:	movdqu xmm2,XMMWORD PTR [rsp]
    1444:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    144a:	mov    rbx,QWORD PTR [r12+0x108]
    1452:	mov    QWORD PTR [r12+0x378],0x2
    145e:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1467:	movdqa xmm4,xmm0
    146b:	movdqa xmm0,xmm4
    146f:	movdqu XMMWORD PTR [r12+0x240],xmm0
    1479:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    1483:	movdqa xmm2,xmm0
    1487:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1491:	movdqa xmm3,xmm0
    1495:	cmp    DWORD PTR [r12+0x310],0x0
    149e:	jne    0x1587
    14a4:	movdqa xmm0,xmm2
    14a8:	movdqa xmm1,xmm3
    14ac:	pshufd xmm1,xmm1,0x44
    14b1:	movq   rax,xmm0
    14b6:	add    rax,rax
    14b9:	je     0x14cf
    14bb:	shr    rax,0x35
    14bf:	sub    eax,0x201
    14c4:	cmp    eax,0x3fc
    14c9:	ja     0x1587
    14cf:	movdqa xmm14,xmm0
    14d4:	psrldq xmm14,0x8
    14da:	movq   rax,xmm14
    14df:	add    rax,rax
    14e2:	je     0x14f8
    14e4:	shr    rax,0x35
    14e8:	sub    eax,0x201
    14ed:	cmp    eax,0x3fc
    14f2:	ja     0x1587
    14f8:	movq   rax,xmm1
    14fd:	add    rax,rax
    1500:	je     0x1516
    1502:	shr    rax,0x35
    1506:	sub    eax,0x201
    150b:	cmp    eax,0x3fc
    1510:	ja     0x1587
    1516:	movdqa xmm14,xmm1
    151b:	psrldq xmm14,0x8
    1521:	movq   rax,xmm14
    1526:	add    rax,rax
    1529:	je     0x153f
    152b:	shr    rax,0x35
    152f:	sub    eax,0x201
    1534:	cmp    eax,0x3fc
    1539:	ja     0x1587
    153f:	stmxcsr DWORD PTR [rsp+0x100]
    1547:	mov    DWORD PTR [rsp+0x104],0x1f80
    1552:	ldmxcsr DWORD PTR [rsp+0x104]
    155a:	mulpd  xmm0,xmm1
    155e:	stmxcsr DWORD PTR [rsp+0x104]
    1566:	ldmxcsr DWORD PTR [rsp+0x100]
    156e:	mov    eax,DWORD PTR [rsp+0x104]
    1575:	shr    eax,1
    1577:	and    eax,0x10
    157a:	or     DWORD PTR [r12+0x314],eax
    1582:	jmp    0x1634
    1587:	movdqa xmm0,xmm2
    158b:	movdqa xmm1,xmm3
    158f:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1598:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    15a1:	mov    QWORD PTR [r12+0x378],0x3
    15ad:	movdqu XMMWORD PTR [rsp],xmm2
    15b2:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    15b8:	mov    QWORD PTR [r12+0x108],rbx
    15c0:	stmxcsr DWORD PTR [r12-0x28]
    15c6:	ldmxcsr DWORD PTR [r12-0x38]
    15cc:	lea    rdi,[rsp+0xf0]
    15d4:	lea    rsi,[rsp+0xd0]
    15dc:	lea    rdx,[rsp+0xe0]
    15e4:	mov    ecx,0x56
    15e9:	mov    r8d,DWORD PTR [r12+0x310]
    15f1:	lea    r9,[r12+0x314]
    15f9:	movabs r11,0x5b9960291750
    1603:	call   r11
    1606:	ldmxcsr DWORD PTR [r12-0x28]
    160c:	movdqu xmm2,XMMWORD PTR [rsp]
    1611:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1617:	mov    rbx,QWORD PTR [r12+0x108]
    161f:	mov    QWORD PTR [r12+0x378],0x2
    162b:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1634:	movdqa xmm4,xmm0
    1638:	movdqa xmm0,xmm4
    163c:	movdqu XMMWORD PTR [r12+0x260],xmm0
    1646:	mov    r13d,0x0
    164c:	mov    r14d,0x0
    1652:	mov    QWORD PTR [r12+0x110],r13
    165a:	mov    QWORD PTR [r12+0x118],r14
    1662:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    166c:	movdqa xmm2,xmm0
    1670:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    167a:	movdqa xmm3,xmm0
    167e:	cmp    DWORD PTR [r12+0x310],0x0
    1687:	jne    0x176b
    168d:	movdqa xmm0,xmm2
    1691:	movdqa xmm1,xmm3
    1695:	movq   rax,xmm0
    169a:	add    rax,rax
    169d:	je     0x16b3
    169f:	shr    rax,0x35
    16a3:	sub    eax,0x201
    16a8:	cmp    eax,0x3fc
    16ad:	ja     0x176b
    16b3:	movdqa xmm14,xmm0
    16b8:	psrldq xmm14,0x8
    16be:	movq   rax,xmm14
    16c3:	add    rax,rax
    16c6:	je     0x16dc
    16c8:	shr    rax,0x35
    16cc:	sub    eax,0x201
    16d1:	cmp    eax,0x3fc
    16d6:	ja     0x176b
    16dc:	movq   rax,xmm1
    16e1:	add    rax,rax
    16e4:	je     0x16fa
    16e6:	shr    rax,0x35
    16ea:	sub    eax,0x201
    16ef:	cmp    eax,0x3fc
    16f4:	ja     0x176b
    16fa:	movdqa xmm14,xmm1
    16ff:	psrldq xmm14,0x8
    1705:	movq   rax,xmm14
    170a:	add    rax,rax
    170d:	je     0x1723
    170f:	shr    rax,0x35
    1713:	sub    eax,0x201
    1718:	cmp    eax,0x3fc
    171d:	ja     0x176b
    1723:	stmxcsr DWORD PTR [rsp+0x100]
    172b:	mov    DWORD PTR [rsp+0x104],0x1f80
    1736:	ldmxcsr DWORD PTR [rsp+0x104]
    173e:	mulpd  xmm0,xmm1
    1742:	stmxcsr DWORD PTR [rsp+0x104]
    174a:	ldmxcsr DWORD PTR [rsp+0x100]
    1752:	mov    eax,DWORD PTR [rsp+0x104]
    1759:	shr    eax,1
    175b:	and    eax,0x10
    175e:	or     DWORD PTR [r12+0x314],eax
    1766:	jmp    0x1818
    176b:	movdqa xmm0,xmm2
    176f:	movdqa xmm1,xmm3
    1773:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    177c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1785:	mov    QWORD PTR [r12+0x378],0x3
    1791:	movdqu XMMWORD PTR [rsp],xmm2
    1796:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    179c:	mov    QWORD PTR [r12+0x108],rbx
    17a4:	stmxcsr DWORD PTR [r12-0x28]
    17aa:	ldmxcsr DWORD PTR [r12-0x38]
    17b0:	lea    rdi,[rsp+0xf0]
    17b8:	lea    rsi,[rsp+0xd0]
    17c0:	lea    rdx,[rsp+0xe0]
    17c8:	mov    ecx,0x16
    17cd:	mov    r8d,DWORD PTR [r12+0x310]
    17d5:	lea    r9,[r12+0x314]
    17dd:	movabs r11,0x5b9960291750
    17e7:	call   r11
    17ea:	ldmxcsr DWORD PTR [r12-0x28]
    17f0:	movdqu xmm2,XMMWORD PTR [rsp]
    17f5:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    17fb:	mov    rbx,QWORD PTR [r12+0x108]
    1803:	mov    QWORD PTR [r12+0x378],0x2
    180f:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1818:	movdqa xmm4,xmm0
    181c:	movdqa xmm0,xmm4
    1820:	movdqu XMMWORD PTR [r12+0x210],xmm0
    182a:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    1834:	movdqa xmm2,xmm0
    1838:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1842:	movdqa xmm3,xmm0
    1846:	cmp    DWORD PTR [r12+0x310],0x0
    184f:	jne    0x1933
    1855:	movdqa xmm0,xmm2
    1859:	movdqa xmm1,xmm3
    185d:	movq   rax,xmm0
    1862:	add    rax,rax
    1865:	je     0x187b
    1867:	shr    rax,0x35
    186b:	sub    eax,0x201
    1870:	cmp    eax,0x3fc
    1875:	ja     0x1933
    187b:	movdqa xmm14,xmm0
    1880:	psrldq xmm14,0x8
    1886:	movq   rax,xmm14
    188b:	add    rax,rax
    188e:	je     0x18a4
    1890:	shr    rax,0x35
    1894:	sub    eax,0x201
    1899:	cmp    eax,0x3fc
    189e:	ja     0x1933
    18a4:	movq   rax,xmm1
    18a9:	add    rax,rax
    18ac:	je     0x18c2
    18ae:	shr    rax,0x35
    18b2:	sub    eax,0x201
    18b7:	cmp    eax,0x3fc
    18bc:	ja     0x1933
    18c2:	movdqa xmm14,xmm1
    18c7:	psrldq xmm14,0x8
    18cd:	movq   rax,xmm14
    18d2:	add    rax,rax
    18d5:	je     0x18eb
    18d7:	shr    rax,0x35
    18db:	sub    eax,0x201
    18e0:	cmp    eax,0x3fc
    18e5:	ja     0x1933
    18eb:	stmxcsr DWORD PTR [rsp+0x100]
    18f3:	mov    DWORD PTR [rsp+0x104],0x1f80
    18fe:	ldmxcsr DWORD PTR [rsp+0x104]
    1906:	mulpd  xmm0,xmm1
    190a:	stmxcsr DWORD PTR [rsp+0x104]
    1912:	ldmxcsr DWORD PTR [rsp+0x100]
    191a:	mov    eax,DWORD PTR [rsp+0x104]
    1921:	shr    eax,1
    1923:	and    eax,0x10
    1926:	or     DWORD PTR [r12+0x314],eax
    192e:	jmp    0x19e0
    1933:	movdqa xmm0,xmm2
    1937:	movdqa xmm1,xmm3
    193b:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1944:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    194d:	mov    QWORD PTR [r12+0x378],0x3
    1959:	movdqu XMMWORD PTR [rsp],xmm2
    195e:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1964:	mov    QWORD PTR [r12+0x108],rbx
    196c:	stmxcsr DWORD PTR [r12-0x28]
    1972:	ldmxcsr DWORD PTR [r12-0x38]
    1978:	lea    rdi,[rsp+0xf0]
    1980:	lea    rsi,[rsp+0xd0]
    1988:	lea    rdx,[rsp+0xe0]
    1990:	mov    ecx,0x16
    1995:	mov    r8d,DWORD PTR [r12+0x310]
    199d:	lea    r9,[r12+0x314]
    19a5:	movabs r11,0x5b9960291750
    19af:	call   r11
    19b2:	ldmxcsr DWORD PTR [r12-0x28]
    19b8:	movdqu xmm2,XMMWORD PTR [rsp]
    19bd:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    19c3:	mov    rbx,QWORD PTR [r12+0x108]
    19cb:	mov    QWORD PTR [r12+0x378],0x2
    19d7:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    19e0:	movdqa xmm4,xmm0
    19e4:	movdqa xmm0,xmm4
    19e8:	movdqu XMMWORD PTR [r12+0x220],xmm0
    19f2:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    19fc:	movdqa xmm2,xmm0
    1a00:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    1a0a:	movdqa xmm3,xmm0
    1a0e:	cmp    DWORD PTR [r12+0x310],0x0
    1a17:	jne    0x1afb
    1a1d:	movdqa xmm0,xmm2
    1a21:	movdqa xmm1,xmm3
    1a25:	movq   rax,xmm0
    1a2a:	add    rax,rax
    1a2d:	je     0x1a43
    1a2f:	shr    rax,0x35
    1a33:	sub    eax,0x201
    1a38:	cmp    eax,0x3fc
    1a3d:	ja     0x1afb
    1a43:	movdqa xmm14,xmm0
    1a48:	psrldq xmm14,0x8
    1a4e:	movq   rax,xmm14
    1a53:	add    rax,rax
    1a56:	je     0x1a6c
    1a58:	shr    rax,0x35
    1a5c:	sub    eax,0x201
    1a61:	cmp    eax,0x3fc
    1a66:	ja     0x1afb
    1a6c:	movq   rax,xmm1
    1a71:	add    rax,rax
    1a74:	je     0x1a8a
    1a76:	shr    rax,0x35
    1a7a:	sub    eax,0x201
    1a7f:	cmp    eax,0x3fc
    1a84:	ja     0x1afb
    1a8a:	movdqa xmm14,xmm1
    1a8f:	psrldq xmm14,0x8
    1a95:	movq   rax,xmm14
    1a9a:	add    rax,rax
    1a9d:	je     0x1ab3
    1a9f:	shr    rax,0x35
    1aa3:	sub    eax,0x201
    1aa8:	cmp    eax,0x3fc
    1aad:	ja     0x1afb
    1ab3:	stmxcsr DWORD PTR [rsp+0x100]
    1abb:	mov    DWORD PTR [rsp+0x104],0x1f80
    1ac6:	ldmxcsr DWORD PTR [rsp+0x104]
    1ace:	mulpd  xmm0,xmm1
    1ad2:	stmxcsr DWORD PTR [rsp+0x104]
    1ada:	ldmxcsr DWORD PTR [rsp+0x100]
    1ae2:	mov    eax,DWORD PTR [rsp+0x104]
    1ae9:	shr    eax,1
    1aeb:	and    eax,0x10
    1aee:	or     DWORD PTR [r12+0x314],eax
    1af6:	jmp    0x1ba8
    1afb:	movdqa xmm0,xmm2
    1aff:	movdqa xmm1,xmm3
    1b03:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1b0c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1b15:	mov    QWORD PTR [r12+0x378],0x3
    1b21:	movdqu XMMWORD PTR [rsp],xmm2
    1b26:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1b2c:	mov    QWORD PTR [r12+0x108],rbx
    1b34:	stmxcsr DWORD PTR [r12-0x28]
    1b3a:	ldmxcsr DWORD PTR [r12-0x38]
    1b40:	lea    rdi,[rsp+0xf0]
    1b48:	lea    rsi,[rsp+0xd0]
    1b50:	lea    rdx,[rsp+0xe0]
    1b58:	mov    ecx,0x16
    1b5d:	mov    r8d,DWORD PTR [r12+0x310]
    1b65:	lea    r9,[r12+0x314]
    1b6d:	movabs r11,0x5b9960291750
    1b77:	call   r11
    1b7a:	ldmxcsr DWORD PTR [r12-0x28]
    1b80:	movdqu xmm2,XMMWORD PTR [rsp]
    1b85:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1b8b:	mov    rbx,QWORD PTR [r12+0x108]
    1b93:	mov    QWORD PTR [r12+0x378],0x2
    1b9f:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1ba8:	movdqa xmm4,xmm0
    1bac:	movdqa xmm0,xmm4
    1bb0:	movdqu XMMWORD PTR [r12+0x180],xmm0
    1bba:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    1bc4:	movdqa xmm2,xmm0
    1bc8:	movdqa xmm0,xmm2
    1bcc:	movdqa xmm1,xmm2
    1bd0:	por    xmm0,xmm1
    1bd4:	movdqa xmm3,xmm0
    1bd8:	movdqa xmm0,xmm3
    1bdc:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    1be6:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    1bf0:	movdqa xmm2,xmm0
    1bf4:	movdqa xmm0,xmm2
    1bf8:	movdqa xmm1,xmm2
    1bfc:	por    xmm0,xmm1
    1c00:	movdqa xmm3,xmm0
    1c04:	movdqa xmm0,xmm3
    1c08:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    1c12:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1c1c:	movdqa xmm3,xmm0
    1c20:	cmp    DWORD PTR [r12+0x310],0x0
    1c29:	jne    0x1d12
    1c2f:	movdqa xmm0,xmm2
    1c33:	movdqa xmm1,xmm3
    1c37:	pshufd xmm1,xmm1,0x44
    1c3c:	movq   rax,xmm0
    1c41:	add    rax,rax
    1c44:	je     0x1c5a
    1c46:	shr    rax,0x35
    1c4a:	sub    eax,0x201
    1c4f:	cmp    eax,0x3fc
    1c54:	ja     0x1d12
    1c5a:	movdqa xmm14,xmm0
    1c5f:	psrldq xmm14,0x8
    1c65:	movq   rax,xmm14
    1c6a:	add    rax,rax
    1c6d:	je     0x1c83
    1c6f:	shr    rax,0x35
    1c73:	sub    eax,0x201
    1c78:	cmp    eax,0x3fc
    1c7d:	ja     0x1d12
    1c83:	movq   rax,xmm1
    1c88:	add    rax,rax
    1c8b:	je     0x1ca1
    1c8d:	shr    rax,0x35
    1c91:	sub    eax,0x201
    1c96:	cmp    eax,0x3fc
    1c9b:	ja     0x1d12
    1ca1:	movdqa xmm14,xmm1
    1ca6:	psrldq xmm14,0x8
    1cac:	movq   rax,xmm14
    1cb1:	add    rax,rax
    1cb4:	je     0x1cca
    1cb6:	shr    rax,0x35
    1cba:	sub    eax,0x201
    1cbf:	cmp    eax,0x3fc
    1cc4:	ja     0x1d12
    1cca:	stmxcsr DWORD PTR [rsp+0x100]
    1cd2:	mov    DWORD PTR [rsp+0x104],0x1f80
    1cdd:	ldmxcsr DWORD PTR [rsp+0x104]
    1ce5:	mulpd  xmm0,xmm1
    1ce9:	stmxcsr DWORD PTR [rsp+0x104]
    1cf1:	ldmxcsr DWORD PTR [rsp+0x100]
    1cf9:	mov    eax,DWORD PTR [rsp+0x104]
    1d00:	shr    eax,1
    1d02:	and    eax,0x10
    1d05:	or     DWORD PTR [r12+0x314],eax
    1d0d:	jmp    0x1dbf
    1d12:	movdqa xmm0,xmm2
    1d16:	movdqa xmm1,xmm3
    1d1a:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1d23:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1d2c:	mov    QWORD PTR [r12+0x378],0x3
    1d38:	movdqu XMMWORD PTR [rsp],xmm2
    1d3d:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1d43:	mov    QWORD PTR [r12+0x108],rbx
    1d4b:	stmxcsr DWORD PTR [r12-0x28]
    1d51:	ldmxcsr DWORD PTR [r12-0x38]
    1d57:	lea    rdi,[rsp+0xf0]
    1d5f:	lea    rsi,[rsp+0xd0]
    1d67:	lea    rdx,[rsp+0xe0]
    1d6f:	mov    ecx,0x56
    1d74:	mov    r8d,DWORD PTR [r12+0x310]
    1d7c:	lea    r9,[r12+0x314]
    1d84:	movabs r11,0x5b9960291750
    1d8e:	call   r11
    1d91:	ldmxcsr DWORD PTR [r12-0x28]
    1d97:	movdqu xmm2,XMMWORD PTR [rsp]
    1d9c:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1da2:	mov    rbx,QWORD PTR [r12+0x108]
    1daa:	mov    QWORD PTR [r12+0x378],0x2
    1db6:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1dbf:	movdqa xmm4,xmm0
    1dc3:	movdqa xmm0,xmm4
    1dc7:	movdqu XMMWORD PTR [r12+0x250],xmm0
    1dd1:	mov    r13,QWORD PTR [r12+0x58]
    1dd6:	mov    r14,r13
    1dd9:	sub    r14,0x200
    1de0:	pushf
    1de1:	pop    rdx
    1de2:	mov    r10d,edx
    1de5:	and    r10d,0xc0
    1dec:	shl    r10d,0x18
    1df0:	mov    r11d,edx
    1df3:	and    r11d,0x1
    1df7:	shl    r11d,0x1d
    1dfb:	or     r10d,r11d
    1dfe:	mov    r11d,edx
    1e01:	and    r11d,0x800
    1e08:	shl    r11d,0x11
    1e0c:	or     r10d,r11d
    1e0f:	mov    r11d,0xf0000000
    1e15:	and    r11,r10
    1e18:	movabs rsi,0xffffffff0fffffff
    1e22:	and    rbx,rsi
    1e25:	or     rbx,r11
    1e28:	btc    rbx,0x1d
    1e2d:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1e37:	movdqa xmm2,xmm0
    1e3b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    1e45:	movdqa xmm3,xmm0
    1e49:	cmp    DWORD PTR [r12+0x310],0x0
    1e52:	jne    0x1f36
    1e58:	movdqa xmm0,xmm2
    1e5c:	movdqa xmm1,xmm3
    1e60:	movq   rax,xmm0
    1e65:	add    rax,rax
    1e68:	je     0x1e7e
    1e6a:	shr    rax,0x35
    1e6e:	sub    eax,0x201
    1e73:	cmp    eax,0x3fc
    1e78:	ja     0x1f36
    1e7e:	movdqa xmm14,xmm0
    1e83:	psrldq xmm14,0x8
    1e89:	movq   rax,xmm14
    1e8e:	add    rax,rax
    1e91:	je     0x1ea7
    1e93:	shr    rax,0x35
    1e97:	sub    eax,0x201
    1e9c:	cmp    eax,0x3fc
    1ea1:	ja     0x1f36
    1ea7:	movq   rax,xmm1
    1eac:	add    rax,rax
    1eaf:	je     0x1ec5
    1eb1:	shr    rax,0x35
    1eb5:	sub    eax,0x201
    1eba:	cmp    eax,0x3fc
    1ebf:	ja     0x1f36
    1ec5:	movdqa xmm14,xmm1
    1eca:	psrldq xmm14,0x8
    1ed0:	movq   rax,xmm14
    1ed5:	add    rax,rax
    1ed8:	je     0x1eee
    1eda:	shr    rax,0x35
    1ede:	sub    eax,0x201
    1ee3:	cmp    eax,0x3fc
    1ee8:	ja     0x1f36
    1eee:	stmxcsr DWORD PTR [rsp+0x100]
    1ef6:	mov    DWORD PTR [rsp+0x104],0x1f80
    1f01:	ldmxcsr DWORD PTR [rsp+0x104]
    1f09:	addpd  xmm0,xmm1
    1f0d:	stmxcsr DWORD PTR [rsp+0x104]
    1f15:	ldmxcsr DWORD PTR [rsp+0x100]
    1f1d:	mov    eax,DWORD PTR [rsp+0x104]
    1f24:	shr    eax,1
    1f26:	and    eax,0x10
    1f29:	or     DWORD PTR [r12+0x314],eax
    1f31:	jmp    0x1fe3
    1f36:	movdqa xmm0,xmm2
    1f3a:	movdqa xmm1,xmm3
    1f3e:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1f47:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1f50:	mov    QWORD PTR [r12+0x378],0x3
    1f5c:	movdqu XMMWORD PTR [rsp],xmm2
    1f61:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1f67:	mov    QWORD PTR [r12+0x108],rbx
    1f6f:	stmxcsr DWORD PTR [r12-0x28]
    1f75:	ldmxcsr DWORD PTR [r12-0x38]
    1f7b:	lea    rdi,[rsp+0xf0]
    1f83:	lea    rsi,[rsp+0xd0]
    1f8b:	lea    rdx,[rsp+0xe0]
    1f93:	mov    ecx,0x14
    1f98:	mov    r8d,DWORD PTR [r12+0x310]
    1fa0:	lea    r9,[r12+0x314]
    1fa8:	movabs r11,0x5b9960291750
    1fb2:	call   r11
    1fb5:	ldmxcsr DWORD PTR [r12-0x28]
    1fbb:	movdqu xmm2,XMMWORD PTR [rsp]
    1fc0:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1fc6:	mov    rbx,QWORD PTR [r12+0x108]
    1fce:	mov    QWORD PTR [r12+0x378],0x2
    1fda:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1fe3:	movdqa xmm4,xmm0
    1fe7:	movdqa xmm0,xmm4
    1feb:	movdqu XMMWORD PTR [r12+0x240],xmm0
    1ff5:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    1fff:	movdqa xmm2,xmm0
    2003:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    200d:	movdqa xmm3,xmm0
    2011:	cmp    DWORD PTR [r12+0x310],0x0
    201a:	jne    0x20fe
    2020:	movdqa xmm0,xmm2
    2024:	movdqa xmm1,xmm3
    2028:	movq   rax,xmm0
    202d:	add    rax,rax
    2030:	je     0x2046
    2032:	shr    rax,0x35
    2036:	sub    eax,0x201
    203b:	cmp    eax,0x3fc
    2040:	ja     0x20fe
    2046:	movdqa xmm14,xmm0
    204b:	psrldq xmm14,0x8
    2051:	movq   rax,xmm14
    2056:	add    rax,rax
    2059:	je     0x206f
    205b:	shr    rax,0x35
    205f:	sub    eax,0x201
    2064:	cmp    eax,0x3fc
    2069:	ja     0x20fe
    206f:	movq   rax,xmm1
    2074:	add    rax,rax
    2077:	je     0x208d
    2079:	shr    rax,0x35
    207d:	sub    eax,0x201
    2082:	cmp    eax,0x3fc
    2087:	ja     0x20fe
    208d:	movdqa xmm14,xmm1
    2092:	psrldq xmm14,0x8
    2098:	movq   rax,xmm14
    209d:	add    rax,rax
    20a0:	je     0x20b6
    20a2:	shr    rax,0x35
    20a6:	sub    eax,0x201
    20ab:	cmp    eax,0x3fc
    20b0:	ja     0x20fe
    20b6:	stmxcsr DWORD PTR [rsp+0x100]
    20be:	mov    DWORD PTR [rsp+0x104],0x1f80
    20c9:	ldmxcsr DWORD PTR [rsp+0x104]
    20d1:	addpd  xmm0,xmm1
    20d5:	stmxcsr DWORD PTR [rsp+0x104]
    20dd:	ldmxcsr DWORD PTR [rsp+0x100]
    20e5:	mov    eax,DWORD PTR [rsp+0x104]
    20ec:	shr    eax,1
    20ee:	and    eax,0x10
    20f1:	or     DWORD PTR [r12+0x314],eax
    20f9:	jmp    0x21ab
    20fe:	movdqa xmm0,xmm2
    2102:	movdqa xmm1,xmm3
    2106:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    210f:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2118:	mov    QWORD PTR [r12+0x378],0x3
    2124:	movdqu XMMWORD PTR [rsp],xmm2
    2129:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    212f:	mov    QWORD PTR [r12+0x108],rbx
    2137:	stmxcsr DWORD PTR [r12-0x28]
    213d:	ldmxcsr DWORD PTR [r12-0x38]
    2143:	lea    rdi,[rsp+0xf0]
    214b:	lea    rsi,[rsp+0xd0]
    2153:	lea    rdx,[rsp+0xe0]
    215b:	mov    ecx,0x14
    2160:	mov    r8d,DWORD PTR [r12+0x310]
    2168:	lea    r9,[r12+0x314]
    2170:	movabs r11,0x5b9960291750
    217a:	call   r11
    217d:	ldmxcsr DWORD PTR [r12-0x28]
    2183:	movdqu xmm2,XMMWORD PTR [rsp]
    2188:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    218e:	mov    rbx,QWORD PTR [r12+0x108]
    2196:	mov    QWORD PTR [r12+0x378],0x2
    21a2:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    21ab:	movdqa xmm4,xmm0
    21af:	movdqa xmm0,xmm4
    21b3:	movdqu XMMWORD PTR [r12+0x210],xmm0
    21bd:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    21c7:	movdqa xmm2,xmm0
    21cb:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    21d5:	movdqa xmm3,xmm0
    21d9:	cmp    DWORD PTR [r12+0x310],0x0
    21e2:	jne    0x22c6
    21e8:	movdqa xmm0,xmm2
    21ec:	movdqa xmm1,xmm3
    21f0:	movq   rax,xmm0
    21f5:	add    rax,rax
    21f8:	je     0x220e
    21fa:	shr    rax,0x35
    21fe:	sub    eax,0x201
    2203:	cmp    eax,0x3fc
    2208:	ja     0x22c6
    220e:	movdqa xmm14,xmm0
    2213:	psrldq xmm14,0x8
    2219:	movq   rax,xmm14
    221e:	add    rax,rax
    2221:	je     0x2237
    2223:	shr    rax,0x35
    2227:	sub    eax,0x201
    222c:	cmp    eax,0x3fc
    2231:	ja     0x22c6
    2237:	movq   rax,xmm1
    223c:	add    rax,rax
    223f:	je     0x2255
    2241:	shr    rax,0x35
    2245:	sub    eax,0x201
    224a:	cmp    eax,0x3fc
    224f:	ja     0x22c6
    2255:	movdqa xmm14,xmm1
    225a:	psrldq xmm14,0x8
    2260:	movq   rax,xmm14
    2265:	add    rax,rax
    2268:	je     0x227e
    226a:	shr    rax,0x35
    226e:	sub    eax,0x201
    2273:	cmp    eax,0x3fc
    2278:	ja     0x22c6
    227e:	stmxcsr DWORD PTR [rsp+0x100]
    2286:	mov    DWORD PTR [rsp+0x104],0x1f80
    2291:	ldmxcsr DWORD PTR [rsp+0x104]
    2299:	addpd  xmm0,xmm1
    229d:	stmxcsr DWORD PTR [rsp+0x104]
    22a5:	ldmxcsr DWORD PTR [rsp+0x100]
    22ad:	mov    eax,DWORD PTR [rsp+0x104]
    22b4:	shr    eax,1
    22b6:	and    eax,0x10
    22b9:	or     DWORD PTR [r12+0x314],eax
    22c1:	jmp    0x2373
    22c6:	movdqa xmm0,xmm2
    22ca:	movdqa xmm1,xmm3
    22ce:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    22d7:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    22e0:	mov    QWORD PTR [r12+0x378],0x3
    22ec:	movdqu XMMWORD PTR [rsp],xmm2
    22f1:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    22f7:	mov    QWORD PTR [r12+0x108],rbx
    22ff:	stmxcsr DWORD PTR [r12-0x28]
    2305:	ldmxcsr DWORD PTR [r12-0x38]
    230b:	lea    rdi,[rsp+0xf0]
    2313:	lea    rsi,[rsp+0xd0]
    231b:	lea    rdx,[rsp+0xe0]
    2323:	mov    ecx,0x14
    2328:	mov    r8d,DWORD PTR [r12+0x310]
    2330:	lea    r9,[r12+0x314]
    2338:	movabs r11,0x5b9960291750
    2342:	call   r11
    2345:	ldmxcsr DWORD PTR [r12-0x28]
    234b:	movdqu xmm2,XMMWORD PTR [rsp]
    2350:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2356:	mov    rbx,QWORD PTR [r12+0x108]
    235e:	mov    QWORD PTR [r12+0x378],0x2
    236a:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    2373:	movdqa xmm4,xmm0
    2377:	movdqa xmm0,xmm4
    237b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    2385:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    238f:	movdqa xmm2,xmm0
    2393:	movdqa xmm0,xmm2
    2397:	movdqa xmm1,xmm2
    239b:	por    xmm0,xmm1
    239f:	movdqa xmm3,xmm0
    23a3:	movdqa xmm0,xmm3
    23a7:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    23b1:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    23bb:	movdqa xmm2,xmm0
    23bf:	movdqa xmm0,xmm2
    23c3:	movdqa xmm1,xmm2
    23c7:	por    xmm0,xmm1
    23cb:	movdqa xmm3,xmm0
    23cf:	movdqa xmm0,xmm3
    23d3:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    23dd:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    23e7:	movdqa xmm2,xmm0
    23eb:	movdqa xmm0,xmm2
    23ef:	movdqa xmm1,xmm2
    23f3:	por    xmm0,xmm1
    23f7:	movdqa xmm3,xmm0
    23fb:	movdqa xmm0,xmm3
    23ff:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    2409:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    2413:	movdqa xmm2,xmm0
    2417:	movdqa xmm0,xmm2
    241b:	movdqa xmm1,xmm2
    241f:	por    xmm0,xmm1
    2423:	movdqa xmm3,xmm0
    2427:	movdqa xmm0,xmm3
    242b:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    2435:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    243f:	movdqa xmm2,xmm0
    2443:	movdqa xmm0,xmm2
    2447:	movdqa xmm1,xmm2
    244b:	por    xmm0,xmm1
    244f:	movdqa xmm3,xmm0
    2453:	movdqa xmm0,xmm3
    2457:	movdqu XMMWORD PTR [r12+0x200],xmm0
    2461:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    246b:	movdqa xmm2,xmm0
    246f:	movdqa xmm0,xmm2
    2473:	movdqa xmm1,xmm2
    2477:	por    xmm0,xmm1
    247b:	movdqa xmm3,xmm0
    247f:	movdqa xmm0,xmm3
    2483:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    248d:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    2497:	movdqa xmm2,xmm0
    249b:	movdqa xmm0,xmm2
    249f:	movdqa xmm1,xmm2
    24a3:	por    xmm0,xmm1
    24a7:	movdqa xmm3,xmm0
    24ab:	movdqa xmm0,xmm3
    24af:	movdqu XMMWORD PTR [r12+0x190],xmm0
    24b9:	mov    r13,QWORD PTR [r12+0xf8]
    24c1:	mov    r14,r13
    24c4:	add    r14,0xa0
    24cb:	mov    r13,r14
    24ce:	add    r13,0x10
    24d2:	movdqu xmm2,XMMWORD PTR [r14]
    24d7:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    24dd:	movdqa xmm0,xmm2
    24e1:	movdqu XMMWORD PTR [r12+0x300],xmm0
    24eb:	movdqa xmm0,xmm3
    24ef:	movdqu XMMWORD PTR [r12+0x270],xmm0
    24f9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    2503:	movdqa xmm2,xmm0
    2507:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    2511:	movdqa xmm3,xmm0
    2515:	cmp    DWORD PTR [r12+0x310],0x0
    251e:	jne    0x2602
    2524:	movdqa xmm0,xmm2
    2528:	movdqa xmm1,xmm3
    252c:	movq   rax,xmm0
    2531:	add    rax,rax
    2534:	je     0x254a
    2536:	shr    rax,0x35
    253a:	sub    eax,0x201
    253f:	cmp    eax,0x3fc
    2544:	ja     0x2602
    254a:	movdqa xmm14,xmm0
    254f:	psrldq xmm14,0x8
    2555:	movq   rax,xmm14
    255a:	add    rax,rax
    255d:	je     0x2573
    255f:	shr    rax,0x35
    2563:	sub    eax,0x201
    2568:	cmp    eax,0x3fc
    256d:	ja     0x2602
    2573:	movq   rax,xmm1
    2578:	add    rax,rax
    257b:	je     0x2591
    257d:	shr    rax,0x35
    2581:	sub    eax,0x201
    2586:	cmp    eax,0x3fc
    258b:	ja     0x2602
    2591:	movdqa xmm14,xmm1
    2596:	psrldq xmm14,0x8
    259c:	movq   rax,xmm14
    25a1:	add    rax,rax
    25a4:	je     0x25ba
    25a6:	shr    rax,0x35
    25aa:	sub    eax,0x201
    25af:	cmp    eax,0x3fc
    25b4:	ja     0x2602
    25ba:	stmxcsr DWORD PTR [rsp+0x100]
    25c2:	mov    DWORD PTR [rsp+0x104],0x1f80
    25cd:	ldmxcsr DWORD PTR [rsp+0x104]
    25d5:	addpd  xmm0,xmm1
    25d9:	stmxcsr DWORD PTR [rsp+0x104]
    25e1:	ldmxcsr DWORD PTR [rsp+0x100]
    25e9:	mov    eax,DWORD PTR [rsp+0x104]
    25f0:	shr    eax,1
    25f2:	and    eax,0x10
    25f5:	or     DWORD PTR [r12+0x314],eax
    25fd:	jmp    0x26af
    2602:	movdqa xmm0,xmm2
    2606:	movdqa xmm1,xmm3
    260a:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2613:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    261c:	mov    QWORD PTR [r12+0x378],0x3
    2628:	movdqu XMMWORD PTR [rsp],xmm2
    262d:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2633:	mov    QWORD PTR [r12+0x108],rbx
    263b:	stmxcsr DWORD PTR [r12-0x28]
    2641:	ldmxcsr DWORD PTR [r12-0x38]
    2647:	lea    rdi,[rsp+0xf0]
    264f:	lea    rsi,[rsp+0xd0]
    2657:	lea    rdx,[rsp+0xe0]
    265f:	mov    ecx,0x14
    2664:	mov    r8d,DWORD PTR [r12+0x310]
    266c:	lea    r9,[r12+0x314]
    2674:	movabs r11,0x5b9960291750
    267e:	call   r11
    2681:	ldmxcsr DWORD PTR [r12-0x28]
    2687:	movdqu xmm2,XMMWORD PTR [rsp]
    268c:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2692:	mov    rbx,QWORD PTR [r12+0x108]
    269a:	mov    QWORD PTR [r12+0x378],0x2
    26a6:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    26af:	movdqa xmm4,xmm0
    26b3:	movdqa xmm0,xmm4
    26b7:	movdqu XMMWORD PTR [r12+0x180],xmm0
    26c1:	mov    r13,QWORD PTR [r12+0xf8]
    26c9:	mov    r14,r13
    26cc:	add    r14,0xf0
    26d3:	movdqu xmm2,XMMWORD PTR [r14]
    26d8:	movdqa xmm0,xmm2
    26dc:	movdqu XMMWORD PTR [r12+0x110],xmm0
    26e6:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    26f0:	movdqa xmm2,xmm0
    26f4:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    26fe:	movdqa xmm3,xmm0
    2702:	cmp    DWORD PTR [r12+0x310],0x0
    270b:	jne    0x27ef
    2711:	movdqa xmm0,xmm2
    2715:	movdqa xmm1,xmm3
    2719:	movq   rax,xmm0
    271e:	add    rax,rax
    2721:	je     0x2737
    2723:	shr    rax,0x35
    2727:	sub    eax,0x201
    272c:	cmp    eax,0x3fc
    2731:	ja     0x27ef
    2737:	movdqa xmm14,xmm0
    273c:	psrldq xmm14,0x8
    2742:	movq   rax,xmm14
    2747:	add    rax,rax
    274a:	je     0x2760
    274c:	shr    rax,0x35
    2750:	sub    eax,0x201
    2755:	cmp    eax,0x3fc
    275a:	ja     0x27ef
    2760:	movq   rax,xmm1
    2765:	add    rax,rax
    2768:	je     0x277e
    276a:	shr    rax,0x35
    276e:	sub    eax,0x201
    2773:	cmp    eax,0x3fc
    2778:	ja     0x27ef
    277e:	movdqa xmm14,xmm1
    2783:	psrldq xmm14,0x8
    2789:	movq   rax,xmm14
    278e:	add    rax,rax
    2791:	je     0x27a7
    2793:	shr    rax,0x35
    2797:	sub    eax,0x201
    279c:	cmp    eax,0x3fc
    27a1:	ja     0x27ef
    27a7:	stmxcsr DWORD PTR [rsp+0x100]
    27af:	mov    DWORD PTR [rsp+0x104],0x1f80
    27ba:	ldmxcsr DWORD PTR [rsp+0x104]
    27c2:	addpd  xmm0,xmm1
    27c6:	stmxcsr DWORD PTR [rsp+0x104]
    27ce:	ldmxcsr DWORD PTR [rsp+0x100]
    27d6:	mov    eax,DWORD PTR [rsp+0x104]
    27dd:	shr    eax,1
    27df:	and    eax,0x10
    27e2:	or     DWORD PTR [r12+0x314],eax
    27ea:	jmp    0x289c
    27ef:	movdqa xmm0,xmm2
    27f3:	movdqa xmm1,xmm3
    27f7:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2800:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2809:	mov    QWORD PTR [r12+0x378],0x3
    2815:	movdqu XMMWORD PTR [rsp],xmm2
    281a:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2820:	mov    QWORD PTR [r12+0x108],rbx
    2828:	stmxcsr DWORD PTR [r12-0x28]
    282e:	ldmxcsr DWORD PTR [r12-0x38]
    2834:	lea    rdi,[rsp+0xf0]
    283c:	lea    rsi,[rsp+0xd0]
    2844:	lea    rdx,[rsp+0xe0]
    284c:	mov    ecx,0x14
    2851:	mov    r8d,DWORD PTR [r12+0x310]
    2859:	lea    r9,[r12+0x314]
    2861:	movabs r11,0x5b9960291750
    286b:	call   r11
    286e:	ldmxcsr DWORD PTR [r12-0x28]
    2874:	movdqu xmm2,XMMWORD PTR [rsp]
    2879:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    287f:	mov    rbx,QWORD PTR [r12+0x108]
    2887:	mov    QWORD PTR [r12+0x378],0x2
    2893:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    289c:	movdqa xmm4,xmm0
    28a0:	movdqa xmm0,xmm4
    28a4:	movdqu XMMWORD PTR [r12+0x210],xmm0
    28ae:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    28b8:	movdqa xmm2,xmm0
    28bc:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    28c6:	movdqa xmm3,xmm0
    28ca:	cmp    DWORD PTR [r12+0x310],0x0
    28d3:	jne    0x29b7
    28d9:	movdqa xmm0,xmm2
    28dd:	movdqa xmm1,xmm3
    28e1:	movq   rax,xmm0
    28e6:	add    rax,rax
    28e9:	je     0x28ff
    28eb:	shr    rax,0x35
    28ef:	sub    eax,0x201
    28f4:	cmp    eax,0x3fc
    28f9:	ja     0x29b7
    28ff:	movdqa xmm14,xmm0
    2904:	psrldq xmm14,0x8
    290a:	movq   rax,xmm14
    290f:	add    rax,rax
    2912:	je     0x2928
    2914:	shr    rax,0x35
    2918:	sub    eax,0x201
    291d:	cmp    eax,0x3fc
    2922:	ja     0x29b7
    2928:	movq   rax,xmm1
    292d:	add    rax,rax
    2930:	je     0x2946
    2932:	shr    rax,0x35
    2936:	sub    eax,0x201
    293b:	cmp    eax,0x3fc
    2940:	ja     0x29b7
    2946:	movdqa xmm14,xmm1
    294b:	psrldq xmm14,0x8
    2951:	movq   rax,xmm14
    2956:	add    rax,rax
    2959:	je     0x296f
    295b:	shr    rax,0x35
    295f:	sub    eax,0x201
    2964:	cmp    eax,0x3fc
    2969:	ja     0x29b7
    296f:	stmxcsr DWORD PTR [rsp+0x100]
    2977:	mov    DWORD PTR [rsp+0x104],0x1f80
    2982:	ldmxcsr DWORD PTR [rsp+0x104]
    298a:	addpd  xmm0,xmm1
    298e:	stmxcsr DWORD PTR [rsp+0x104]
    2996:	ldmxcsr DWORD PTR [rsp+0x100]
    299e:	mov    eax,DWORD PTR [rsp+0x104]
    29a5:	shr    eax,1
    29a7:	and    eax,0x10
    29aa:	or     DWORD PTR [r12+0x314],eax
    29b2:	jmp    0x2a64
    29b7:	movdqa xmm0,xmm2
    29bb:	movdqa xmm1,xmm3
    29bf:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    29c8:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    29d1:	mov    QWORD PTR [r12+0x378],0x3
    29dd:	movdqu XMMWORD PTR [rsp],xmm2
    29e2:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    29e8:	mov    QWORD PTR [r12+0x108],rbx
    29f0:	stmxcsr DWORD PTR [r12-0x28]
    29f6:	ldmxcsr DWORD PTR [r12-0x38]
    29fc:	lea    rdi,[rsp+0xf0]
    2a04:	lea    rsi,[rsp+0xd0]
    2a0c:	lea    rdx,[rsp+0xe0]
    2a14:	mov    ecx,0x14
    2a19:	mov    r8d,DWORD PTR [r12+0x310]
    2a21:	lea    r9,[r12+0x314]
    2a29:	movabs r11,0x5b9960291750
    2a33:	call   r11
    2a36:	ldmxcsr DWORD PTR [r12-0x28]
    2a3c:	movdqu xmm2,XMMWORD PTR [rsp]
    2a41:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2a47:	mov    rbx,QWORD PTR [r12+0x108]
    2a4f:	mov    QWORD PTR [r12+0x378],0x2
    2a5b:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    2a64:	movdqa xmm4,xmm0
    2a68:	movdqa xmm0,xmm4
    2a6c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    2a76:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    2a80:	movdqa xmm2,xmm0
    2a84:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    2a8e:	movdqa xmm3,xmm0
    2a92:	cmp    DWORD PTR [r12+0x310],0x0
    2a9b:	jne    0x2b84
    2aa1:	movdqa xmm0,xmm2
    2aa5:	movdqa xmm1,xmm3
    2aa9:	pshufd xmm1,xmm1,0x44
    2aae:	movq   rax,xmm0
    2ab3:	add    rax,rax
    2ab6:	je     0x2acc
    2ab8:	shr    rax,0x35
    2abc:	sub    eax,0x201
    2ac1:	cmp    eax,0x3fc
    2ac6:	ja     0x2b84
    2acc:	movdqa xmm14,xmm0
    2ad1:	psrldq xmm14,0x8
    2ad7:	movq   rax,xmm14
    2adc:	add    rax,rax
    2adf:	je     0x2af5
    2ae1:	shr    rax,0x35
    2ae5:	sub    eax,0x201
    2aea:	cmp    eax,0x3fc
    2aef:	ja     0x2b84
    2af5:	movq   rax,xmm1
    2afa:	add    rax,rax
    2afd:	je     0x2b13
    2aff:	shr    rax,0x35
    2b03:	sub    eax,0x201
    2b08:	cmp    eax,0x3fc
    2b0d:	ja     0x2b84
    2b13:	movdqa xmm14,xmm1
    2b18:	psrldq xmm14,0x8
    2b1e:	movq   rax,xmm14
    2b23:	add    rax,rax
    2b26:	je     0x2b3c
    2b28:	shr    rax,0x35
    2b2c:	sub    eax,0x201
    2b31:	cmp    eax,0x3fc
    2b36:	ja     0x2b84
    2b3c:	stmxcsr DWORD PTR [rsp+0x100]
    2b44:	mov    DWORD PTR [rsp+0x104],0x1f80
    2b4f:	ldmxcsr DWORD PTR [rsp+0x104]
    2b57:	mulpd  xmm0,xmm1
    2b5b:	stmxcsr DWORD PTR [rsp+0x104]
    2b63:	ldmxcsr DWORD PTR [rsp+0x100]
    2b6b:	mov    eax,DWORD PTR [rsp+0x104]
    2b72:	shr    eax,1
    2b74:	and    eax,0x10
    2b77:	or     DWORD PTR [r12+0x314],eax
    2b7f:	jmp    0x2c31
    2b84:	movdqa xmm0,xmm2
    2b88:	movdqa xmm1,xmm3
    2b8c:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2b95:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2b9e:	mov    QWORD PTR [r12+0x378],0x3
    2baa:	movdqu XMMWORD PTR [rsp],xmm2
    2baf:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2bb5:	mov    QWORD PTR [r12+0x108],rbx
    2bbd:	stmxcsr DWORD PTR [r12-0x28]
    2bc3:	ldmxcsr DWORD PTR [r12-0x38]
    2bc9:	lea    rdi,[rsp+0xf0]
    2bd1:	lea    rsi,[rsp+0xd0]
    2bd9:	lea    rdx,[rsp+0xe0]
    2be1:	mov    ecx,0x56
    2be6:	mov    r8d,DWORD PTR [r12+0x310]
    2bee:	lea    r9,[r12+0x314]
    2bf6:	movabs r11,0x5b9960291750
    2c00:	call   r11
    2c03:	ldmxcsr DWORD PTR [r12-0x28]
    2c09:	movdqu xmm2,XMMWORD PTR [rsp]
    2c0e:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2c14:	mov    rbx,QWORD PTR [r12+0x108]
    2c1c:	mov    QWORD PTR [r12+0x378],0x2
    2c28:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    2c31:	movdqa xmm4,xmm0
    2c35:	movdqa xmm0,xmm4
    2c39:	movdqu XMMWORD PTR [r12+0x270],xmm0
    2c43:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    2c4d:	movdqa xmm2,xmm0
    2c51:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    2c5b:	movdqa xmm3,xmm0
    2c5f:	cmp    DWORD PTR [r12+0x310],0x0
    2c68:	jne    0x2d51
    2c6e:	movdqa xmm0,xmm2
    2c72:	movdqa xmm1,xmm3
    2c76:	pshufd xmm1,xmm1,0x44
    2c7b:	movq   rax,xmm0
    2c80:	add    rax,rax
    2c83:	je     0x2c99
    2c85:	shr    rax,0x35
    2c89:	sub    eax,0x201
    2c8e:	cmp    eax,0x3fc
    2c93:	ja     0x2d51
    2c99:	movdqa xmm14,xmm0
    2c9e:	psrldq xmm14,0x8
    2ca4:	movq   rax,xmm14
    2ca9:	add    rax,rax
    2cac:	je     0x2cc2
    2cae:	shr    rax,0x35
    2cb2:	sub    eax,0x201
    2cb7:	cmp    eax,0x3fc
    2cbc:	ja     0x2d51
    2cc2:	movq   rax,xmm1
    2cc7:	add    rax,rax
    2cca:	je     0x2ce0
    2ccc:	shr    rax,0x35
    2cd0:	sub    eax,0x201
    2cd5:	cmp    eax,0x3fc
    2cda:	ja     0x2d51
    2ce0:	movdqa xmm14,xmm1
    2ce5:	psrldq xmm14,0x8
    2ceb:	movq   rax,xmm14
    2cf0:	add    rax,rax
    2cf3:	je     0x2d09
    2cf5:	shr    rax,0x35
    2cf9:	sub    eax,0x201
    2cfe:	cmp    eax,0x3fc
    2d03:	ja     0x2d51
    2d09:	stmxcsr DWORD PTR [rsp+0x100]
    2d11:	mov    DWORD PTR [rsp+0x104],0x1f80
    2d1c:	ldmxcsr DWORD PTR [rsp+0x104]
    2d24:	mulpd  xmm0,xmm1
    2d28:	stmxcsr DWORD PTR [rsp+0x104]
    2d30:	ldmxcsr DWORD PTR [rsp+0x100]
    2d38:	mov    eax,DWORD PTR [rsp+0x104]
    2d3f:	shr    eax,1
    2d41:	and    eax,0x10
    2d44:	or     DWORD PTR [r12+0x314],eax
    2d4c:	jmp    0x2dfe
    2d51:	movdqa xmm0,xmm2
    2d55:	movdqa xmm1,xmm3
    2d59:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2d62:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2d6b:	mov    QWORD PTR [r12+0x378],0x3
    2d77:	movdqu XMMWORD PTR [rsp],xmm2
    2d7c:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2d82:	mov    QWORD PTR [r12+0x108],rbx
    2d8a:	stmxcsr DWORD PTR [r12-0x28]
    2d90:	ldmxcsr DWORD PTR [r12-0x38]
    2d96:	lea    rdi,[rsp+0xf0]
    2d9e:	lea    rsi,[rsp+0xd0]
    2da6:	lea    rdx,[rsp+0xe0]
    2dae:	mov    ecx,0x56
    2db3:	mov    r8d,DWORD PTR [r12+0x310]
    2dbb:	lea    r9,[r12+0x314]
    2dc3:	movabs r11,0x5b9960291750
    2dcd:	call   r11
    2dd0:	ldmxcsr DWORD PTR [r12-0x28]
    2dd6:	movdqu xmm2,XMMWORD PTR [rsp]
    2ddb:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2de1:	mov    rbx,QWORD PTR [r12+0x108]
    2de9:	mov    QWORD PTR [r12+0x378],0x2
    2df5:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    2dfe:	movdqa xmm4,xmm0
    2e02:	movdqa xmm0,xmm4
    2e06:	movdqu XMMWORD PTR [r12+0x250],xmm0
    2e10:	mov    r13,QWORD PTR [r12+0xf8]
    2e18:	mov    r14,r13
    2e1b:	add    r14,0xe0
    2e22:	movdqu xmm2,XMMWORD PTR [r14]
    2e27:	movdqa xmm0,xmm2
    2e2b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    2e35:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    2e3f:	movdqa xmm2,xmm0
    2e43:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    2e4d:	movdqa xmm3,xmm0
    2e51:	cmp    DWORD PTR [r12+0x310],0x0
    2e5a:	jne    0x2f43
    2e60:	movdqa xmm0,xmm2
    2e64:	movdqa xmm1,xmm3
    2e68:	pshufd xmm1,xmm1,0x44
    2e6d:	movq   rax,xmm0
    2e72:	add    rax,rax
    2e75:	je     0x2e8b
    2e77:	shr    rax,0x35
    2e7b:	sub    eax,0x201
    2e80:	cmp    eax,0x3fc
    2e85:	ja     0x2f43
    2e8b:	movdqa xmm14,xmm0
    2e90:	psrldq xmm14,0x8
    2e96:	movq   rax,xmm14
    2e9b:	add    rax,rax
    2e9e:	je     0x2eb4
    2ea0:	shr    rax,0x35
    2ea4:	sub    eax,0x201
    2ea9:	cmp    eax,0x3fc
    2eae:	ja     0x2f43
    2eb4:	movq   rax,xmm1
    2eb9:	add    rax,rax
    2ebc:	je     0x2ed2
    2ebe:	shr    rax,0x35
    2ec2:	sub    eax,0x201
    2ec7:	cmp    eax,0x3fc
    2ecc:	ja     0x2f43
    2ed2:	movdqa xmm14,xmm1
    2ed7:	psrldq xmm14,0x8
    2edd:	movq   rax,xmm14
    2ee2:	add    rax,rax
    2ee5:	je     0x2efb
    2ee7:	shr    rax,0x35
    2eeb:	sub    eax,0x201
    2ef0:	cmp    eax,0x3fc
    2ef5:	ja     0x2f43
    2efb:	stmxcsr DWORD PTR [rsp+0x100]
    2f03:	mov    DWORD PTR [rsp+0x104],0x1f80
    2f0e:	ldmxcsr DWORD PTR [rsp+0x104]
    2f16:	mulpd  xmm0,xmm1
    2f1a:	stmxcsr DWORD PTR [rsp+0x104]
    2f22:	ldmxcsr DWORD PTR [rsp+0x100]
    2f2a:	mov    eax,DWORD PTR [rsp+0x104]
    2f31:	shr    eax,1
    2f33:	and    eax,0x10
    2f36:	or     DWORD PTR [r12+0x314],eax
    2f3e:	jmp    0x2ff0
    2f43:	movdqa xmm0,xmm2
    2f47:	movdqa xmm1,xmm3
    2f4b:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2f54:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2f5d:	mov    QWORD PTR [r12+0x378],0x3
    2f69:	movdqu XMMWORD PTR [rsp],xmm2
    2f6e:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2f74:	mov    QWORD PTR [r12+0x108],rbx
    2f7c:	stmxcsr DWORD PTR [r12-0x28]
    2f82:	ldmxcsr DWORD PTR [r12-0x38]
    2f88:	lea    rdi,[rsp+0xf0]
    2f90:	lea    rsi,[rsp+0xd0]
    2f98:	lea    rdx,[rsp+0xe0]
    2fa0:	mov    ecx,0x56
    2fa5:	mov    r8d,DWORD PTR [r12+0x310]
    2fad:	lea    r9,[r12+0x314]
    2fb5:	movabs r11,0x5b9960291750
    2fbf:	call   r11
    2fc2:	ldmxcsr DWORD PTR [r12-0x28]
    2fc8:	movdqu xmm2,XMMWORD PTR [rsp]
    2fcd:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2fd3:	mov    rbx,QWORD PTR [r12+0x108]
    2fdb:	mov    QWORD PTR [r12+0x378],0x2
    2fe7:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    2ff0:	movdqa xmm4,xmm0
    2ff4:	movdqa xmm0,xmm4
    2ff8:	movdqu XMMWORD PTR [r12+0x230],xmm0
    3002:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    300c:	movdqa xmm2,xmm0
    3010:	movdqa xmm0,xmm2
    3014:	movdqa xmm1,xmm2
    3018:	por    xmm0,xmm1
    301c:	movdqa xmm3,xmm0
    3020:	movdqa xmm0,xmm3
    3024:	movdqu XMMWORD PTR [r12+0x300],xmm0
    302e:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    3038:	movdqa xmm2,xmm0
    303c:	movdqa xmm0,xmm2
    3040:	movdqa xmm1,xmm2
    3044:	por    xmm0,xmm1
    3048:	movdqa xmm3,xmm0
    304c:	movdqa xmm0,xmm3
    3050:	movdqu XMMWORD PTR [r12+0x190],xmm0
    305a:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    3064:	movdqa xmm2,xmm0
    3068:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    3072:	movdqa xmm3,xmm0
    3076:	cmp    DWORD PTR [r12+0x310],0x0
    307f:	jne    0x3168
    3085:	movdqa xmm0,xmm2
    3089:	movdqa xmm1,xmm3
    308d:	pshufd xmm1,xmm1,0x44
    3092:	movq   rax,xmm0
    3097:	add    rax,rax
    309a:	je     0x30b0
    309c:	shr    rax,0x35
    30a0:	sub    eax,0x201
    30a5:	cmp    eax,0x3fc
    30aa:	ja     0x3168
    30b0:	movdqa xmm14,xmm0
    30b5:	psrldq xmm14,0x8
    30bb:	movq   rax,xmm14
    30c0:	add    rax,rax
    30c3:	je     0x30d9
    30c5:	shr    rax,0x35
    30c9:	sub    eax,0x201
    30ce:	cmp    eax,0x3fc
    30d3:	ja     0x3168
    30d9:	movq   rax,xmm1
    30de:	add    rax,rax
    30e1:	je     0x30f7
    30e3:	shr    rax,0x35
    30e7:	sub    eax,0x201
    30ec:	cmp    eax,0x3fc
    30f1:	ja     0x3168
    30f7:	movdqa xmm14,xmm1
    30fc:	psrldq xmm14,0x8
    3102:	movq   rax,xmm14
    3107:	add    rax,rax
    310a:	je     0x3120
    310c:	shr    rax,0x35
    3110:	sub    eax,0x201
    3115:	cmp    eax,0x3fc
    311a:	ja     0x3168
    3120:	stmxcsr DWORD PTR [rsp+0x100]
    3128:	mov    DWORD PTR [rsp+0x104],0x1f80
    3133:	ldmxcsr DWORD PTR [rsp+0x104]
    313b:	mulpd  xmm0,xmm1
    313f:	stmxcsr DWORD PTR [rsp+0x104]
    3147:	ldmxcsr DWORD PTR [rsp+0x100]
    314f:	mov    eax,DWORD PTR [rsp+0x104]
    3156:	shr    eax,1
    3158:	and    eax,0x10
    315b:	or     DWORD PTR [r12+0x314],eax
    3163:	jmp    0x3215
    3168:	movdqa xmm0,xmm2
    316c:	movdqa xmm1,xmm3
    3170:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3179:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3182:	mov    QWORD PTR [r12+0x378],0x3
    318e:	movdqu XMMWORD PTR [rsp],xmm2
    3193:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3199:	mov    QWORD PTR [r12+0x108],rbx
    31a1:	stmxcsr DWORD PTR [r12-0x28]
    31a7:	ldmxcsr DWORD PTR [r12-0x38]
    31ad:	lea    rdi,[rsp+0xf0]
    31b5:	lea    rsi,[rsp+0xd0]
    31bd:	lea    rdx,[rsp+0xe0]
    31c5:	mov    ecx,0x56
    31ca:	mov    r8d,DWORD PTR [r12+0x310]
    31d2:	lea    r9,[r12+0x314]
    31da:	movabs r11,0x5b9960291750
    31e4:	call   r11
    31e7:	ldmxcsr DWORD PTR [r12-0x28]
    31ed:	movdqu xmm2,XMMWORD PTR [rsp]
    31f2:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    31f8:	mov    rbx,QWORD PTR [r12+0x108]
    3200:	mov    QWORD PTR [r12+0x378],0x2
    320c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    3215:	movdqa xmm4,xmm0
    3219:	movdqa xmm0,xmm4
    321d:	movdqu XMMWORD PTR [r12+0x260],xmm0
    3227:	mov    r13,QWORD PTR [r12+0xf8]
    322f:	mov    r14,r13
    3232:	add    r14,0x90
    3239:	movdqu xmm2,XMMWORD PTR [r14]
    323e:	movdqa xmm0,xmm2
    3242:	movdqu XMMWORD PTR [r12+0x110],xmm0
    324c:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    3256:	movdqa xmm2,xmm0
    325a:	movdqa xmm0,xmm2
    325e:	movdqa xmm1,xmm2
    3262:	por    xmm0,xmm1
    3266:	movdqa xmm3,xmm0
    326a:	movdqa xmm0,xmm3
    326e:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    3278:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    3282:	movdqa xmm2,xmm0
    3286:	movdqa xmm0,xmm2
    328a:	movdqa xmm1,xmm2
    328e:	por    xmm0,xmm1
    3292:	movdqa xmm3,xmm0
    3296:	movdqa xmm0,xmm3
    329a:	movdqu XMMWORD PTR [r12+0x200],xmm0
    32a4:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    32ae:	movdqa xmm2,xmm0
    32b2:	movdqa xmm0,xmm2
    32b6:	movdqa xmm1,xmm2
    32ba:	por    xmm0,xmm1
    32be:	movdqa xmm3,xmm0
    32c2:	movdqa xmm0,xmm3
    32c6:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    32d0:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    32da:	movdqa xmm2,xmm0
    32de:	movdqa xmm0,xmm2
    32e2:	movdqa xmm1,xmm2
    32e6:	por    xmm0,xmm1
    32ea:	movdqa xmm3,xmm0
    32ee:	movdqa xmm0,xmm3
    32f2:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    32fc:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    3306:	movdqa xmm2,xmm0
    330a:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    3314:	movdqa xmm3,xmm0
    3318:	cmp    DWORD PTR [r12+0x310],0x0
    3321:	jne    0x3405
    3327:	movdqa xmm0,xmm2
    332b:	movdqa xmm1,xmm3
    332f:	movq   rax,xmm0
    3334:	add    rax,rax
    3337:	je     0x334d
    3339:	shr    rax,0x35
    333d:	sub    eax,0x201
    3342:	cmp    eax,0x3fc
    3347:	ja     0x3405
    334d:	movdqa xmm14,xmm0
    3352:	psrldq xmm14,0x8
    3358:	movq   rax,xmm14
    335d:	add    rax,rax
    3360:	je     0x3376
    3362:	shr    rax,0x35
    3366:	sub    eax,0x201
    336b:	cmp    eax,0x3fc
    3370:	ja     0x3405
    3376:	movq   rax,xmm1
    337b:	add    rax,rax
    337e:	je     0x3394
    3380:	shr    rax,0x35
    3384:	sub    eax,0x201
    3389:	cmp    eax,0x3fc
    338e:	ja     0x3405
    3394:	movdqa xmm14,xmm1
    3399:	psrldq xmm14,0x8
    339f:	movq   rax,xmm14
    33a4:	add    rax,rax
    33a7:	je     0x33bd
    33a9:	shr    rax,0x35
    33ad:	sub    eax,0x201
    33b2:	cmp    eax,0x3fc
    33b7:	ja     0x3405
    33bd:	stmxcsr DWORD PTR [rsp+0x100]
    33c5:	mov    DWORD PTR [rsp+0x104],0x1f80
    33d0:	ldmxcsr DWORD PTR [rsp+0x104]
    33d8:	addpd  xmm0,xmm1
    33dc:	stmxcsr DWORD PTR [rsp+0x104]
    33e4:	ldmxcsr DWORD PTR [rsp+0x100]
    33ec:	mov    eax,DWORD PTR [rsp+0x104]
    33f3:	shr    eax,1
    33f5:	and    eax,0x10
    33f8:	or     DWORD PTR [r12+0x314],eax
    3400:	jmp    0x34b2
    3405:	movdqa xmm0,xmm2
    3409:	movdqa xmm1,xmm3
    340d:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3416:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    341f:	mov    QWORD PTR [r12+0x378],0x3
    342b:	movdqu XMMWORD PTR [rsp],xmm2
    3430:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3436:	mov    QWORD PTR [r12+0x108],rbx
    343e:	stmxcsr DWORD PTR [r12-0x28]
    3444:	ldmxcsr DWORD PTR [r12-0x38]
    344a:	lea    rdi,[rsp+0xf0]
    3452:	lea    rsi,[rsp+0xd0]
    345a:	lea    rdx,[rsp+0xe0]
    3462:	mov    ecx,0x14
    3467:	mov    r8d,DWORD PTR [r12+0x310]
    346f:	lea    r9,[r12+0x314]
    3477:	movabs r11,0x5b9960291750
    3481:	call   r11
    3484:	ldmxcsr DWORD PTR [r12-0x28]
    348a:	movdqu xmm2,XMMWORD PTR [rsp]
    348f:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3495:	mov    rbx,QWORD PTR [r12+0x108]
    349d:	mov    QWORD PTR [r12+0x378],0x2
    34a9:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    34b2:	movdqa xmm4,xmm0
    34b6:	movdqa xmm0,xmm4
    34ba:	movdqu XMMWORD PTR [r12+0x240],xmm0
    34c4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    34ce:	movdqa xmm2,xmm0
    34d2:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    34dc:	movdqa xmm3,xmm0
    34e0:	cmp    DWORD PTR [r12+0x310],0x0
    34e9:	jne    0x35d2
    34ef:	movdqa xmm0,xmm2
    34f3:	movdqa xmm1,xmm3
    34f7:	pshufd xmm1,xmm1,0x44
    34fc:	movq   rax,xmm0
    3501:	add    rax,rax
    3504:	je     0x351a
    3506:	shr    rax,0x35
    350a:	sub    eax,0x201
    350f:	cmp    eax,0x3fc
    3514:	ja     0x35d2
    351a:	movdqa xmm14,xmm0
    351f:	psrldq xmm14,0x8
    3525:	movq   rax,xmm14
    352a:	add    rax,rax
    352d:	je     0x3543
    352f:	shr    rax,0x35
    3533:	sub    eax,0x201
    3538:	cmp    eax,0x3fc
    353d:	ja     0x35d2
    3543:	movq   rax,xmm1
    3548:	add    rax,rax
    354b:	je     0x3561
    354d:	shr    rax,0x35
    3551:	sub    eax,0x201
    3556:	cmp    eax,0x3fc
    355b:	ja     0x35d2
    3561:	movdqa xmm14,xmm1
    3566:	psrldq xmm14,0x8
    356c:	movq   rax,xmm14
    3571:	add    rax,rax
    3574:	je     0x358a
    3576:	shr    rax,0x35
    357a:	sub    eax,0x201
    357f:	cmp    eax,0x3fc
    3584:	ja     0x35d2
    358a:	stmxcsr DWORD PTR [rsp+0x100]
    3592:	mov    DWORD PTR [rsp+0x104],0x1f80
    359d:	ldmxcsr DWORD PTR [rsp+0x104]
    35a5:	mulpd  xmm0,xmm1
    35a9:	stmxcsr DWORD PTR [rsp+0x104]
    35b1:	ldmxcsr DWORD PTR [rsp+0x100]
    35b9:	mov    eax,DWORD PTR [rsp+0x104]
    35c0:	shr    eax,1
    35c2:	and    eax,0x10
    35c5:	or     DWORD PTR [r12+0x314],eax
    35cd:	jmp    0x367f
    35d2:	movdqa xmm0,xmm2
    35d6:	movdqa xmm1,xmm3
    35da:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    35e3:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    35ec:	mov    QWORD PTR [r12+0x378],0x3
    35f8:	movdqu XMMWORD PTR [rsp],xmm2
    35fd:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3603:	mov    QWORD PTR [r12+0x108],rbx
    360b:	stmxcsr DWORD PTR [r12-0x28]
    3611:	ldmxcsr DWORD PTR [r12-0x38]
    3617:	lea    rdi,[rsp+0xf0]
    361f:	lea    rsi,[rsp+0xd0]
    3627:	lea    rdx,[rsp+0xe0]
    362f:	mov    ecx,0x56
    3634:	mov    r8d,DWORD PTR [r12+0x310]
    363c:	lea    r9,[r12+0x314]
    3644:	movabs r11,0x5b9960291750
    364e:	call   r11
    3651:	ldmxcsr DWORD PTR [r12-0x28]
    3657:	movdqu xmm2,XMMWORD PTR [rsp]
    365c:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3662:	mov    rbx,QWORD PTR [r12+0x108]
    366a:	mov    QWORD PTR [r12+0x378],0x2
    3676:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    367f:	movdqa xmm4,xmm0
    3683:	movdqa xmm0,xmm4
    3687:	movdqu XMMWORD PTR [r12+0x270],xmm0
    3691:	mov    r13,QWORD PTR [r12+0xf8]
    3699:	mov    r14,r13
    369c:	add    r14,0x80
    36a3:	movdqu xmm2,XMMWORD PTR [r14]
    36a8:	movdqa xmm0,xmm2
    36ac:	movdqu XMMWORD PTR [r12+0x110],xmm0
    36b6:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    36c0:	movdqa xmm2,xmm0
    36c4:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    36ce:	movdqa xmm3,xmm0
    36d2:	cmp    DWORD PTR [r12+0x310],0x0
    36db:	jne    0x37bf
    36e1:	movdqa xmm0,xmm2
    36e5:	movdqa xmm1,xmm3
    36e9:	movq   rax,xmm0
    36ee:	add    rax,rax
    36f1:	je     0x3707
    36f3:	shr    rax,0x35
    36f7:	sub    eax,0x201
    36fc:	cmp    eax,0x3fc
    3701:	ja     0x37bf
    3707:	movdqa xmm14,xmm0
    370c:	psrldq xmm14,0x8
    3712:	movq   rax,xmm14
    3717:	add    rax,rax
    371a:	je     0x3730
    371c:	shr    rax,0x35
    3720:	sub    eax,0x201
    3725:	cmp    eax,0x3fc
    372a:	ja     0x37bf
    3730:	movq   rax,xmm1
    3735:	add    rax,rax
    3738:	je     0x374e
    373a:	shr    rax,0x35
    373e:	sub    eax,0x201
    3743:	cmp    eax,0x3fc
    3748:	ja     0x37bf
    374e:	movdqa xmm14,xmm1
    3753:	psrldq xmm14,0x8
    3759:	movq   rax,xmm14
    375e:	add    rax,rax
    3761:	je     0x3777
    3763:	shr    rax,0x35
    3767:	sub    eax,0x201
    376c:	cmp    eax,0x3fc
    3771:	ja     0x37bf
    3777:	stmxcsr DWORD PTR [rsp+0x100]
    377f:	mov    DWORD PTR [rsp+0x104],0x1f80
    378a:	ldmxcsr DWORD PTR [rsp+0x104]
    3792:	addpd  xmm0,xmm1
    3796:	stmxcsr DWORD PTR [rsp+0x104]
    379e:	ldmxcsr DWORD PTR [rsp+0x100]
    37a6:	mov    eax,DWORD PTR [rsp+0x104]
    37ad:	shr    eax,1
    37af:	and    eax,0x10
    37b2:	or     DWORD PTR [r12+0x314],eax
    37ba:	jmp    0x386c
    37bf:	movdqa xmm0,xmm2
    37c3:	movdqa xmm1,xmm3
    37c7:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    37d0:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    37d9:	mov    QWORD PTR [r12+0x378],0x3
    37e5:	movdqu XMMWORD PTR [rsp],xmm2
    37ea:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    37f0:	mov    QWORD PTR [r12+0x108],rbx
    37f8:	stmxcsr DWORD PTR [r12-0x28]
    37fe:	ldmxcsr DWORD PTR [r12-0x38]
    3804:	lea    rdi,[rsp+0xf0]
    380c:	lea    rsi,[rsp+0xd0]
    3814:	lea    rdx,[rsp+0xe0]
    381c:	mov    ecx,0x14
    3821:	mov    r8d,DWORD PTR [r12+0x310]
    3829:	lea    r9,[r12+0x314]
    3831:	movabs r11,0x5b9960291750
    383b:	call   r11
    383e:	ldmxcsr DWORD PTR [r12-0x28]
    3844:	movdqu xmm2,XMMWORD PTR [rsp]
    3849:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    384f:	mov    rbx,QWORD PTR [r12+0x108]
    3857:	mov    QWORD PTR [r12+0x378],0x2
    3863:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    386c:	movdqa xmm4,xmm0
    3870:	movdqa xmm0,xmm4
    3874:	movdqu XMMWORD PTR [r12+0x180],xmm0
    387e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    3888:	movdqa xmm2,xmm0
    388c:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    3896:	movdqa xmm3,xmm0
    389a:	cmp    DWORD PTR [r12+0x310],0x0
    38a3:	jne    0x3987
    38a9:	movdqa xmm0,xmm2
    38ad:	movdqa xmm1,xmm3
    38b1:	movq   rax,xmm0
    38b6:	add    rax,rax
    38b9:	je     0x38cf
    38bb:	shr    rax,0x35
    38bf:	sub    eax,0x201
    38c4:	cmp    eax,0x3fc
    38c9:	ja     0x3987
    38cf:	movdqa xmm14,xmm0
    38d4:	psrldq xmm14,0x8
    38da:	movq   rax,xmm14
    38df:	add    rax,rax
    38e2:	je     0x38f8
    38e4:	shr    rax,0x35
    38e8:	sub    eax,0x201
    38ed:	cmp    eax,0x3fc
    38f2:	ja     0x3987
    38f8:	movq   rax,xmm1
    38fd:	add    rax,rax
    3900:	je     0x3916
    3902:	shr    rax,0x35
    3906:	sub    eax,0x201
    390b:	cmp    eax,0x3fc
    3910:	ja     0x3987
    3916:	movdqa xmm14,xmm1
    391b:	psrldq xmm14,0x8
    3921:	movq   rax,xmm14
    3926:	add    rax,rax
    3929:	je     0x393f
    392b:	shr    rax,0x35
    392f:	sub    eax,0x201
    3934:	cmp    eax,0x3fc
    3939:	ja     0x3987
    393f:	stmxcsr DWORD PTR [rsp+0x100]
    3947:	mov    DWORD PTR [rsp+0x104],0x1f80
    3952:	ldmxcsr DWORD PTR [rsp+0x104]
    395a:	addpd  xmm0,xmm1
    395e:	stmxcsr DWORD PTR [rsp+0x104]
    3966:	ldmxcsr DWORD PTR [rsp+0x100]
    396e:	mov    eax,DWORD PTR [rsp+0x104]
    3975:	shr    eax,1
    3977:	and    eax,0x10
    397a:	or     DWORD PTR [r12+0x314],eax
    3982:	jmp    0x3a34
    3987:	movdqa xmm0,xmm2
    398b:	movdqa xmm1,xmm3
    398f:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3998:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    39a1:	mov    QWORD PTR [r12+0x378],0x3
    39ad:	movdqu XMMWORD PTR [rsp],xmm2
    39b2:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    39b8:	mov    QWORD PTR [r12+0x108],rbx
    39c0:	stmxcsr DWORD PTR [r12-0x28]
    39c6:	ldmxcsr DWORD PTR [r12-0x38]
    39cc:	lea    rdi,[rsp+0xf0]
    39d4:	lea    rsi,[rsp+0xd0]
    39dc:	lea    rdx,[rsp+0xe0]
    39e4:	mov    ecx,0x14
    39e9:	mov    r8d,DWORD PTR [r12+0x310]
    39f1:	lea    r9,[r12+0x314]
    39f9:	movabs r11,0x5b9960291750
    3a03:	call   r11
    3a06:	ldmxcsr DWORD PTR [r12-0x28]
    3a0c:	movdqu xmm2,XMMWORD PTR [rsp]
    3a11:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3a17:	mov    rbx,QWORD PTR [r12+0x108]
    3a1f:	mov    QWORD PTR [r12+0x378],0x2
    3a2b:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    3a34:	movdqa xmm4,xmm0
    3a38:	movdqa xmm0,xmm4
    3a3c:	movdqu XMMWORD PTR [r12+0x210],xmm0
    3a46:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    3a50:	movdqa xmm2,xmm0
    3a54:	movdqa xmm0,xmm2
    3a58:	movdqa xmm1,xmm2
    3a5c:	por    xmm0,xmm1
    3a60:	movdqa xmm3,xmm0
    3a64:	movdqa xmm0,xmm3
    3a68:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    3a72:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    3a7c:	movdqa xmm2,xmm0
    3a80:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    3a8a:	movdqa xmm3,xmm0
    3a8e:	cmp    DWORD PTR [r12+0x310],0x0
    3a97:	jne    0x3b80
    3a9d:	movdqa xmm0,xmm2
    3aa1:	movdqa xmm1,xmm3
    3aa5:	pshufd xmm1,xmm1,0x44
    3aaa:	movq   rax,xmm0
    3aaf:	add    rax,rax
    3ab2:	je     0x3ac8
    3ab4:	shr    rax,0x35
    3ab8:	sub    eax,0x201
    3abd:	cmp    eax,0x3fc
    3ac2:	ja     0x3b80
    3ac8:	movdqa xmm14,xmm0
    3acd:	psrldq xmm14,0x8
    3ad3:	movq   rax,xmm14
    3ad8:	add    rax,rax
    3adb:	je     0x3af1
    3add:	shr    rax,0x35
    3ae1:	sub    eax,0x201
    3ae6:	cmp    eax,0x3fc
    3aeb:	ja     0x3b80
    3af1:	movq   rax,xmm1
    3af6:	add    rax,rax
    3af9:	je     0x3b0f
    3afb:	shr    rax,0x35
    3aff:	sub    eax,0x201
    3b04:	cmp    eax,0x3fc
    3b09:	ja     0x3b80
    3b0f:	movdqa xmm14,xmm1
    3b14:	psrldq xmm14,0x8
    3b1a:	movq   rax,xmm14
    3b1f:	add    rax,rax
    3b22:	je     0x3b38
    3b24:	shr    rax,0x35
    3b28:	sub    eax,0x201
    3b2d:	cmp    eax,0x3fc
    3b32:	ja     0x3b80
    3b38:	stmxcsr DWORD PTR [rsp+0x100]
    3b40:	mov    DWORD PTR [rsp+0x104],0x1f80
    3b4b:	ldmxcsr DWORD PTR [rsp+0x104]
    3b53:	mulpd  xmm0,xmm1
    3b57:	stmxcsr DWORD PTR [rsp+0x104]
    3b5f:	ldmxcsr DWORD PTR [rsp+0x100]
    3b67:	mov    eax,DWORD PTR [rsp+0x104]
    3b6e:	shr    eax,1
    3b70:	and    eax,0x10
    3b73:	or     DWORD PTR [r12+0x314],eax
    3b7b:	jmp    0x3c2d
    3b80:	movdqa xmm0,xmm2
    3b84:	movdqa xmm1,xmm3
    3b88:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3b91:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3b9a:	mov    QWORD PTR [r12+0x378],0x3
    3ba6:	movdqu XMMWORD PTR [rsp],xmm2
    3bab:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3bb1:	mov    QWORD PTR [r12+0x108],rbx
    3bb9:	stmxcsr DWORD PTR [r12-0x28]
    3bbf:	ldmxcsr DWORD PTR [r12-0x38]
    3bc5:	lea    rdi,[rsp+0xf0]
    3bcd:	lea    rsi,[rsp+0xd0]
    3bd5:	lea    rdx,[rsp+0xe0]
    3bdd:	mov    ecx,0x56
    3be2:	mov    r8d,DWORD PTR [r12+0x310]
    3bea:	lea    r9,[r12+0x314]
    3bf2:	movabs r11,0x5b9960291750
    3bfc:	call   r11
    3bff:	ldmxcsr DWORD PTR [r12-0x28]
    3c05:	movdqu xmm2,XMMWORD PTR [rsp]
    3c0a:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3c10:	mov    rbx,QWORD PTR [r12+0x108]
    3c18:	mov    QWORD PTR [r12+0x378],0x2
    3c24:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    3c2d:	movdqa xmm4,xmm0
    3c31:	movdqa xmm0,xmm4
    3c35:	movdqu XMMWORD PTR [r12+0x170],xmm0
    3c3f:	mov    r13,QWORD PTR [r12+0xf8]
    3c47:	mov    r14,r13
    3c4a:	add    r14,0xd0
    3c51:	movdqu xmm2,XMMWORD PTR [r14]
    3c56:	movdqa xmm0,xmm2
    3c5a:	movdqu XMMWORD PTR [r12+0x110],xmm0
    3c64:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    3c6e:	movdqa xmm2,xmm0
    3c72:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    3c7c:	movdqa xmm3,xmm0
    3c80:	cmp    DWORD PTR [r12+0x310],0x0
    3c89:	jne    0x3d6d
    3c8f:	movdqa xmm0,xmm2
    3c93:	movdqa xmm1,xmm3
    3c97:	movq   rax,xmm0
    3c9c:	add    rax,rax
    3c9f:	je     0x3cb5
    3ca1:	shr    rax,0x35
    3ca5:	sub    eax,0x201
    3caa:	cmp    eax,0x3fc
    3caf:	ja     0x3d6d
    3cb5:	movdqa xmm14,xmm0
    3cba:	psrldq xmm14,0x8
    3cc0:	movq   rax,xmm14
    3cc5:	add    rax,rax
    3cc8:	je     0x3cde
    3cca:	shr    rax,0x35
    3cce:	sub    eax,0x201
    3cd3:	cmp    eax,0x3fc
    3cd8:	ja     0x3d6d
    3cde:	movq   rax,xmm1
    3ce3:	add    rax,rax
    3ce6:	je     0x3cfc
    3ce8:	shr    rax,0x35
    3cec:	sub    eax,0x201
    3cf1:	cmp    eax,0x3fc
    3cf6:	ja     0x3d6d
    3cfc:	movdqa xmm14,xmm1
    3d01:	psrldq xmm14,0x8
    3d07:	movq   rax,xmm14
    3d0c:	add    rax,rax
    3d0f:	je     0x3d25
    3d11:	shr    rax,0x35
    3d15:	sub    eax,0x201
    3d1a:	cmp    eax,0x3fc
    3d1f:	ja     0x3d6d
    3d25:	stmxcsr DWORD PTR [rsp+0x100]
    3d2d:	mov    DWORD PTR [rsp+0x104],0x1f80
    3d38:	ldmxcsr DWORD PTR [rsp+0x104]
    3d40:	addpd  xmm0,xmm1
    3d44:	stmxcsr DWORD PTR [rsp+0x104]
    3d4c:	ldmxcsr DWORD PTR [rsp+0x100]
    3d54:	mov    eax,DWORD PTR [rsp+0x104]
    3d5b:	shr    eax,1
    3d5d:	and    eax,0x10
    3d60:	or     DWORD PTR [r12+0x314],eax
    3d68:	jmp    0x3e1a
    3d6d:	movdqa xmm0,xmm2
    3d71:	movdqa xmm1,xmm3
    3d75:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3d7e:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3d87:	mov    QWORD PTR [r12+0x378],0x3
    3d93:	movdqu XMMWORD PTR [rsp],xmm2
    3d98:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3d9e:	mov    QWORD PTR [r12+0x108],rbx
    3da6:	stmxcsr DWORD PTR [r12-0x28]
    3dac:	ldmxcsr DWORD PTR [r12-0x38]
    3db2:	lea    rdi,[rsp+0xf0]
    3dba:	lea    rsi,[rsp+0xd0]
    3dc2:	lea    rdx,[rsp+0xe0]
    3dca:	mov    ecx,0x14
    3dcf:	mov    r8d,DWORD PTR [r12+0x310]
    3dd7:	lea    r9,[r12+0x314]
    3ddf:	movabs r11,0x5b9960291750
    3de9:	call   r11
    3dec:	ldmxcsr DWORD PTR [r12-0x28]
    3df2:	movdqu xmm2,XMMWORD PTR [rsp]
    3df7:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3dfd:	mov    rbx,QWORD PTR [r12+0x108]
    3e05:	mov    QWORD PTR [r12+0x378],0x2
    3e11:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    3e1a:	movdqa xmm4,xmm0
    3e1e:	movdqa xmm0,xmm4
    3e22:	movdqu XMMWORD PTR [r12+0x220],xmm0
    3e2c:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    3e36:	movdqa xmm2,xmm0
    3e3a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    3e44:	movdqa xmm3,xmm0
    3e48:	cmp    DWORD PTR [r12+0x310],0x0
    3e51:	jne    0x3f3a
    3e57:	movdqa xmm0,xmm2
    3e5b:	movdqa xmm1,xmm3
    3e5f:	pshufd xmm1,xmm1,0x44
    3e64:	movq   rax,xmm0
    3e69:	add    rax,rax
    3e6c:	je     0x3e82
    3e6e:	shr    rax,0x35
    3e72:	sub    eax,0x201
    3e77:	cmp    eax,0x3fc
    3e7c:	ja     0x3f3a
    3e82:	movdqa xmm14,xmm0
    3e87:	psrldq xmm14,0x8
    3e8d:	movq   rax,xmm14
    3e92:	add    rax,rax
    3e95:	je     0x3eab
    3e97:	shr    rax,0x35
    3e9b:	sub    eax,0x201
    3ea0:	cmp    eax,0x3fc
    3ea5:	ja     0x3f3a
    3eab:	movq   rax,xmm1
    3eb0:	add    rax,rax
    3eb3:	je     0x3ec9
    3eb5:	shr    rax,0x35
    3eb9:	sub    eax,0x201
    3ebe:	cmp    eax,0x3fc
    3ec3:	ja     0x3f3a
    3ec9:	movdqa xmm14,xmm1
    3ece:	psrldq xmm14,0x8
    3ed4:	movq   rax,xmm14
    3ed9:	add    rax,rax
    3edc:	je     0x3ef2
    3ede:	shr    rax,0x35
    3ee2:	sub    eax,0x201
    3ee7:	cmp    eax,0x3fc
    3eec:	ja     0x3f3a
    3ef2:	stmxcsr DWORD PTR [rsp+0x100]
    3efa:	mov    DWORD PTR [rsp+0x104],0x1f80
    3f05:	ldmxcsr DWORD PTR [rsp+0x104]
    3f0d:	mulpd  xmm0,xmm1
    3f11:	stmxcsr DWORD PTR [rsp+0x104]
    3f19:	ldmxcsr DWORD PTR [rsp+0x100]
    3f21:	mov    eax,DWORD PTR [rsp+0x104]
    3f28:	shr    eax,1
    3f2a:	and    eax,0x10
    3f2d:	or     DWORD PTR [r12+0x314],eax
    3f35:	jmp    0x3fe7
    3f3a:	movdqa xmm0,xmm2
    3f3e:	movdqa xmm1,xmm3
    3f42:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3f4b:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3f54:	mov    QWORD PTR [r12+0x378],0x3
    3f60:	movdqu XMMWORD PTR [rsp],xmm2
    3f65:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3f6b:	mov    QWORD PTR [r12+0x108],rbx
    3f73:	stmxcsr DWORD PTR [r12-0x28]
    3f79:	ldmxcsr DWORD PTR [r12-0x38]
    3f7f:	lea    rdi,[rsp+0xf0]
    3f87:	lea    rsi,[rsp+0xd0]
    3f8f:	lea    rdx,[rsp+0xe0]
    3f97:	mov    ecx,0x56
    3f9c:	mov    r8d,DWORD PTR [r12+0x310]
    3fa4:	lea    r9,[r12+0x314]
    3fac:	movabs r11,0x5b9960291750
    3fb6:	call   r11
    3fb9:	ldmxcsr DWORD PTR [r12-0x28]
    3fbf:	movdqu xmm2,XMMWORD PTR [rsp]
    3fc4:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3fca:	mov    rbx,QWORD PTR [r12+0x108]
    3fd2:	mov    QWORD PTR [r12+0x378],0x2
    3fde:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    3fe7:	movdqa xmm4,xmm0
    3feb:	movdqa xmm0,xmm4
    3fef:	movdqu XMMWORD PTR [r12+0x260],xmm0
    3ff9:	mov    r13d,0x0
    3fff:	mov    r14d,0x0
    4005:	mov    QWORD PTR [r12+0x1b0],r13
    400d:	mov    QWORD PTR [r12+0x1b8],r14
    4015:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    401f:	movdqa xmm2,xmm0
    4023:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    402d:	movdqa xmm3,xmm0
    4031:	cmp    DWORD PTR [r12+0x310],0x0
    403a:	jne    0x4123
    4040:	movdqa xmm0,xmm2
    4044:	movdqa xmm1,xmm3
    4048:	pshufd xmm1,xmm1,0x44
    404d:	movq   rax,xmm0
    4052:	add    rax,rax
    4055:	je     0x406b
    4057:	shr    rax,0x35
    405b:	sub    eax,0x201
    4060:	cmp    eax,0x3fc
    4065:	ja     0x4123
    406b:	movdqa xmm14,xmm0
    4070:	psrldq xmm14,0x8
    4076:	movq   rax,xmm14
    407b:	add    rax,rax
    407e:	je     0x4094
    4080:	shr    rax,0x35
    4084:	sub    eax,0x201
    4089:	cmp    eax,0x3fc
    408e:	ja     0x4123
    4094:	movq   rax,xmm1
    4099:	add    rax,rax
    409c:	je     0x40b2
    409e:	shr    rax,0x35
    40a2:	sub    eax,0x201
    40a7:	cmp    eax,0x3fc
    40ac:	ja     0x4123
    40b2:	movdqa xmm14,xmm1
    40b7:	psrldq xmm14,0x8
    40bd:	movq   rax,xmm14
    40c2:	add    rax,rax
    40c5:	je     0x40db
    40c7:	shr    rax,0x35
    40cb:	sub    eax,0x201
    40d0:	cmp    eax,0x3fc
    40d5:	ja     0x4123
    40db:	stmxcsr DWORD PTR [rsp+0x100]
    40e3:	mov    DWORD PTR [rsp+0x104],0x1f80
    40ee:	ldmxcsr DWORD PTR [rsp+0x104]
    40f6:	mulpd  xmm0,xmm1
    40fa:	stmxcsr DWORD PTR [rsp+0x104]
    4102:	ldmxcsr DWORD PTR [rsp+0x100]
    410a:	mov    eax,DWORD PTR [rsp+0x104]
    4111:	shr    eax,1
    4113:	and    eax,0x10
    4116:	or     DWORD PTR [r12+0x314],eax
    411e:	jmp    0x41d0
    4123:	movdqa xmm0,xmm2
    4127:	movdqa xmm1,xmm3
    412b:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4134:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    413d:	mov    QWORD PTR [r12+0x378],0x3
    4149:	movdqu XMMWORD PTR [rsp],xmm2
    414e:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4154:	mov    QWORD PTR [r12+0x108],rbx
    415c:	stmxcsr DWORD PTR [r12-0x28]
    4162:	ldmxcsr DWORD PTR [r12-0x38]
    4168:	lea    rdi,[rsp+0xf0]
    4170:	lea    rsi,[rsp+0xd0]
    4178:	lea    rdx,[rsp+0xe0]
    4180:	mov    ecx,0x56
    4185:	mov    r8d,DWORD PTR [r12+0x310]
    418d:	lea    r9,[r12+0x314]
    4195:	movabs r11,0x5b9960291750
    419f:	call   r11
    41a2:	ldmxcsr DWORD PTR [r12-0x28]
    41a8:	movdqu xmm2,XMMWORD PTR [rsp]
    41ad:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    41b3:	mov    rbx,QWORD PTR [r12+0x108]
    41bb:	mov    QWORD PTR [r12+0x378],0x2
    41c7:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    41d0:	movdqa xmm4,xmm0
    41d4:	movdqa xmm0,xmm4
    41d8:	movdqu XMMWORD PTR [r12+0x230],xmm0
    41e2:	mov    r13,QWORD PTR [r12+0xf8]
    41ea:	mov    r14,r13
    41ed:	add    r14,0xc0
    41f4:	movdqu xmm2,XMMWORD PTR [r14]
    41f9:	movdqa xmm0,xmm2
    41fd:	movdqu XMMWORD PTR [r12+0x110],xmm0
    4207:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    4211:	movdqa xmm2,xmm0
    4215:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    421f:	movdqa xmm3,xmm0
    4223:	cmp    DWORD PTR [r12+0x310],0x0
    422c:	jne    0x4310
    4232:	movdqa xmm0,xmm2
    4236:	movdqa xmm1,xmm3
    423a:	movq   rax,xmm0
    423f:	add    rax,rax
    4242:	je     0x4258
    4244:	shr    rax,0x35
    4248:	sub    eax,0x201
    424d:	cmp    eax,0x3fc
    4252:	ja     0x4310
    4258:	movdqa xmm14,xmm0
    425d:	psrldq xmm14,0x8
    4263:	movq   rax,xmm14
    4268:	add    rax,rax
    426b:	je     0x4281
    426d:	shr    rax,0x35
    4271:	sub    eax,0x201
    4276:	cmp    eax,0x3fc
    427b:	ja     0x4310
    4281:	movq   rax,xmm1
    4286:	add    rax,rax
    4289:	je     0x429f
    428b:	shr    rax,0x35
    428f:	sub    eax,0x201
    4294:	cmp    eax,0x3fc
    4299:	ja     0x4310
    429f:	movdqa xmm14,xmm1
    42a4:	psrldq xmm14,0x8
    42aa:	movq   rax,xmm14
    42af:	add    rax,rax
    42b2:	je     0x42c8
    42b4:	shr    rax,0x35
    42b8:	sub    eax,0x201
    42bd:	cmp    eax,0x3fc
    42c2:	ja     0x4310
    42c8:	stmxcsr DWORD PTR [rsp+0x100]
    42d0:	mov    DWORD PTR [rsp+0x104],0x1f80
    42db:	ldmxcsr DWORD PTR [rsp+0x104]
    42e3:	addpd  xmm0,xmm1
    42e7:	stmxcsr DWORD PTR [rsp+0x104]
    42ef:	ldmxcsr DWORD PTR [rsp+0x100]
    42f7:	mov    eax,DWORD PTR [rsp+0x104]
    42fe:	shr    eax,1
    4300:	and    eax,0x10
    4303:	or     DWORD PTR [r12+0x314],eax
    430b:	jmp    0x43bd
    4310:	movdqa xmm0,xmm2
    4314:	movdqa xmm1,xmm3
    4318:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4321:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    432a:	mov    QWORD PTR [r12+0x378],0x3
    4336:	movdqu XMMWORD PTR [rsp],xmm2
    433b:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4341:	mov    QWORD PTR [r12+0x108],rbx
    4349:	stmxcsr DWORD PTR [r12-0x28]
    434f:	ldmxcsr DWORD PTR [r12-0x38]
    4355:	lea    rdi,[rsp+0xf0]
    435d:	lea    rsi,[rsp+0xd0]
    4365:	lea    rdx,[rsp+0xe0]
    436d:	mov    ecx,0x14
    4372:	mov    r8d,DWORD PTR [r12+0x310]
    437a:	lea    r9,[r12+0x314]
    4382:	movabs r11,0x5b9960291750
    438c:	call   r11
    438f:	ldmxcsr DWORD PTR [r12-0x28]
    4395:	movdqu xmm2,XMMWORD PTR [rsp]
    439a:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    43a0:	mov    rbx,QWORD PTR [r12+0x108]
    43a8:	mov    QWORD PTR [r12+0x378],0x2
    43b4:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    43bd:	movdqa xmm4,xmm0
    43c1:	movdqa xmm0,xmm4
    43c5:	movdqu XMMWORD PTR [r12+0x240],xmm0
    43cf:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    43d9:	movdqa xmm2,xmm0
    43dd:	movdqa xmm0,xmm2
    43e1:	movdqa xmm1,xmm2
    43e5:	por    xmm0,xmm1
    43e9:	movdqa xmm3,xmm0
    43ed:	movdqa xmm0,xmm3
    43f1:	movdqu XMMWORD PTR [r12+0x270],xmm0
    43fb:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    4405:	movdqa xmm2,xmm0
    4409:	movdqa xmm0,xmm2
    440d:	movdqa xmm1,xmm2
    4411:	por    xmm0,xmm1
    4415:	movdqa xmm3,xmm0
    4419:	movdqa xmm0,xmm3
    441d:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    4427:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    4431:	movdqa xmm2,xmm0
    4435:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    443f:	movdqa xmm3,xmm0
    4443:	cmp    DWORD PTR [r12+0x310],0x0
    444c:	jne    0x4535
    4452:	movdqa xmm0,xmm2
    4456:	movdqa xmm1,xmm3
    445a:	pshufd xmm1,xmm1,0x44
    445f:	movq   rax,xmm0
    4464:	add    rax,rax
    4467:	je     0x447d
    4469:	shr    rax,0x35
    446d:	sub    eax,0x201
    4472:	cmp    eax,0x3fc
    4477:	ja     0x4535
    447d:	movdqa xmm14,xmm0
    4482:	psrldq xmm14,0x8
    4488:	movq   rax,xmm14
    448d:	add    rax,rax
    4490:	je     0x44a6
    4492:	shr    rax,0x35
    4496:	sub    eax,0x201
    449b:	cmp    eax,0x3fc
    44a0:	ja     0x4535
    44a6:	movq   rax,xmm1
    44ab:	add    rax,rax
    44ae:	je     0x44c4
    44b0:	shr    rax,0x35
    44b4:	sub    eax,0x201
    44b9:	cmp    eax,0x3fc
    44be:	ja     0x4535
    44c4:	movdqa xmm14,xmm1
    44c9:	psrldq xmm14,0x8
    44cf:	movq   rax,xmm14
    44d4:	add    rax,rax
    44d7:	je     0x44ed
    44d9:	shr    rax,0x35
    44dd:	sub    eax,0x201
    44e2:	cmp    eax,0x3fc
    44e7:	ja     0x4535
    44ed:	stmxcsr DWORD PTR [rsp+0x100]
    44f5:	mov    DWORD PTR [rsp+0x104],0x1f80
    4500:	ldmxcsr DWORD PTR [rsp+0x104]
    4508:	mulpd  xmm0,xmm1
    450c:	stmxcsr DWORD PTR [rsp+0x104]
    4514:	ldmxcsr DWORD PTR [rsp+0x100]
    451c:	mov    eax,DWORD PTR [rsp+0x104]
    4523:	shr    eax,1
    4525:	and    eax,0x10
    4528:	or     DWORD PTR [r12+0x314],eax
    4530:	jmp    0x45e2
    4535:	movdqa xmm0,xmm2
    4539:	movdqa xmm1,xmm3
    453d:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4546:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    454f:	mov    QWORD PTR [r12+0x378],0x3
    455b:	movdqu XMMWORD PTR [rsp],xmm2
    4560:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4566:	mov    QWORD PTR [r12+0x108],rbx
    456e:	stmxcsr DWORD PTR [r12-0x28]
    4574:	ldmxcsr DWORD PTR [r12-0x38]
    457a:	lea    rdi,[rsp+0xf0]
    4582:	lea    rsi,[rsp+0xd0]
    458a:	lea    rdx,[rsp+0xe0]
    4592:	mov    ecx,0x56
    4597:	mov    r8d,DWORD PTR [r12+0x310]
    459f:	lea    r9,[r12+0x314]
    45a7:	movabs r11,0x5b9960291750
    45b1:	call   r11
    45b4:	ldmxcsr DWORD PTR [r12-0x28]
    45ba:	movdqu xmm2,XMMWORD PTR [rsp]
    45bf:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    45c5:	mov    rbx,QWORD PTR [r12+0x108]
    45cd:	mov    QWORD PTR [r12+0x378],0x2
    45d9:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    45e2:	movdqa xmm4,xmm0
    45e6:	movdqa xmm0,xmm4
    45ea:	movdqu XMMWORD PTR [r12+0x250],xmm0
    45f4:	mov    r13,QWORD PTR [r12+0xf8]
    45fc:	mov    r14,r13
    45ff:	add    r14,0x20
    4603:	movdqu xmm2,XMMWORD PTR [r14]
    4608:	movdqa xmm0,xmm2
    460c:	movdqu XMMWORD PTR [r12+0x110],xmm0
    4616:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    4620:	movdqa xmm2,xmm0
    4624:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    462e:	movdqa xmm3,xmm0
    4632:	cmp    DWORD PTR [r12+0x310],0x0
    463b:	jne    0x471f
    4641:	movdqa xmm0,xmm2
    4645:	movdqa xmm1,xmm3
    4649:	movq   rax,xmm0
    464e:	add    rax,rax
    4651:	je     0x4667
    4653:	shr    rax,0x35
    4657:	sub    eax,0x201
    465c:	cmp    eax,0x3fc
    4661:	ja     0x471f
    4667:	movdqa xmm14,xmm0
    466c:	psrldq xmm14,0x8
    4672:	movq   rax,xmm14
    4677:	add    rax,rax
    467a:	je     0x4690
    467c:	shr    rax,0x35
    4680:	sub    eax,0x201
    4685:	cmp    eax,0x3fc
    468a:	ja     0x471f
    4690:	movq   rax,xmm1
    4695:	add    rax,rax
    4698:	je     0x46ae
    469a:	shr    rax,0x35
    469e:	sub    eax,0x201
    46a3:	cmp    eax,0x3fc
    46a8:	ja     0x471f
    46ae:	movdqa xmm14,xmm1
    46b3:	psrldq xmm14,0x8
    46b9:	movq   rax,xmm14
    46be:	add    rax,rax
    46c1:	je     0x46d7
    46c3:	shr    rax,0x35
    46c7:	sub    eax,0x201
    46cc:	cmp    eax,0x3fc
    46d1:	ja     0x471f
    46d7:	stmxcsr DWORD PTR [rsp+0x100]
    46df:	mov    DWORD PTR [rsp+0x104],0x1f80
    46ea:	ldmxcsr DWORD PTR [rsp+0x104]
    46f2:	addpd  xmm0,xmm1
    46f6:	stmxcsr DWORD PTR [rsp+0x104]
    46fe:	ldmxcsr DWORD PTR [rsp+0x100]
    4706:	mov    eax,DWORD PTR [rsp+0x104]
    470d:	shr    eax,1
    470f:	and    eax,0x10
    4712:	or     DWORD PTR [r12+0x314],eax
    471a:	jmp    0x47cc
    471f:	movdqa xmm0,xmm2
    4723:	movdqa xmm1,xmm3
    4727:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4730:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4739:	mov    QWORD PTR [r12+0x378],0x3
    4745:	movdqu XMMWORD PTR [rsp],xmm2
    474a:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4750:	mov    QWORD PTR [r12+0x108],rbx
    4758:	stmxcsr DWORD PTR [r12-0x28]
    475e:	ldmxcsr DWORD PTR [r12-0x38]
    4764:	lea    rdi,[rsp+0xf0]
    476c:	lea    rsi,[rsp+0xd0]
    4774:	lea    rdx,[rsp+0xe0]
    477c:	mov    ecx,0x14
    4781:	mov    r8d,DWORD PTR [r12+0x310]
    4789:	lea    r9,[r12+0x314]
    4791:	movabs r11,0x5b9960291750
    479b:	call   r11
    479e:	ldmxcsr DWORD PTR [r12-0x28]
    47a4:	movdqu xmm2,XMMWORD PTR [rsp]
    47a9:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    47af:	mov    rbx,QWORD PTR [r12+0x108]
    47b7:	mov    QWORD PTR [r12+0x378],0x2
    47c3:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    47cc:	movdqa xmm4,xmm0
    47d0:	movdqa xmm0,xmm4
    47d4:	movdqu XMMWORD PTR [r12+0x170],xmm0
    47de:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    47e8:	movdqa xmm2,xmm0
    47ec:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    47f6:	movdqa xmm3,xmm0
    47fa:	cmp    DWORD PTR [r12+0x310],0x0
    4803:	jne    0x48ec
    4809:	movdqa xmm0,xmm2
    480d:	movdqa xmm1,xmm3
    4811:	pshufd xmm1,xmm1,0x44
    4816:	movq   rax,xmm0
    481b:	add    rax,rax
    481e:	je     0x4834
    4820:	shr    rax,0x35
    4824:	sub    eax,0x201
    4829:	cmp    eax,0x3fc
    482e:	ja     0x48ec
    4834:	movdqa xmm14,xmm0
    4839:	psrldq xmm14,0x8
    483f:	movq   rax,xmm14
    4844:	add    rax,rax
    4847:	je     0x485d
    4849:	shr    rax,0x35
    484d:	sub    eax,0x201
    4852:	cmp    eax,0x3fc
    4857:	ja     0x48ec
    485d:	movq   rax,xmm1
    4862:	add    rax,rax
    4865:	je     0x487b
    4867:	shr    rax,0x35
    486b:	sub    eax,0x201
    4870:	cmp    eax,0x3fc
    4875:	ja     0x48ec
    487b:	movdqa xmm14,xmm1
    4880:	psrldq xmm14,0x8
    4886:	movq   rax,xmm14
    488b:	add    rax,rax
    488e:	je     0x48a4
    4890:	shr    rax,0x35
    4894:	sub    eax,0x201
    4899:	cmp    eax,0x3fc
    489e:	ja     0x48ec
    48a4:	stmxcsr DWORD PTR [rsp+0x100]
    48ac:	mov    DWORD PTR [rsp+0x104],0x1f80
    48b7:	ldmxcsr DWORD PTR [rsp+0x104]
    48bf:	mulpd  xmm0,xmm1
    48c3:	stmxcsr DWORD PTR [rsp+0x104]
    48cb:	ldmxcsr DWORD PTR [rsp+0x100]
    48d3:	mov    eax,DWORD PTR [rsp+0x104]
    48da:	shr    eax,1
    48dc:	and    eax,0x10
    48df:	or     DWORD PTR [r12+0x314],eax
    48e7:	jmp    0x4999
    48ec:	movdqa xmm0,xmm2
    48f0:	movdqa xmm1,xmm3
    48f4:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    48fd:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4906:	mov    QWORD PTR [r12+0x378],0x3
    4912:	movdqu XMMWORD PTR [rsp],xmm2
    4917:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    491d:	mov    QWORD PTR [r12+0x108],rbx
    4925:	stmxcsr DWORD PTR [r12-0x28]
    492b:	ldmxcsr DWORD PTR [r12-0x38]
    4931:	lea    rdi,[rsp+0xf0]
    4939:	lea    rsi,[rsp+0xd0]
    4941:	lea    rdx,[rsp+0xe0]
    4949:	mov    ecx,0x56
    494e:	mov    r8d,DWORD PTR [r12+0x310]
    4956:	lea    r9,[r12+0x314]
    495e:	movabs r11,0x5b9960291750
    4968:	call   r11
    496b:	ldmxcsr DWORD PTR [r12-0x28]
    4971:	movdqu xmm2,XMMWORD PTR [rsp]
    4976:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    497c:	mov    rbx,QWORD PTR [r12+0x108]
    4984:	mov    QWORD PTR [r12+0x378],0x2
    4990:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4999:	movdqa xmm4,xmm0
    499d:	movdqa xmm0,xmm4
    49a1:	movdqu XMMWORD PTR [r12+0x160],xmm0
    49ab:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    49b5:	movdqa xmm2,xmm0
    49b9:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    49c3:	movdqa xmm3,xmm0
    49c7:	cmp    DWORD PTR [r12+0x310],0x0
    49d0:	jne    0x4ab4
    49d6:	movdqa xmm0,xmm2
    49da:	movdqa xmm1,xmm3
    49de:	movq   rax,xmm0
    49e3:	add    rax,rax
    49e6:	je     0x49fc
    49e8:	shr    rax,0x35
    49ec:	sub    eax,0x201
    49f1:	cmp    eax,0x3fc
    49f6:	ja     0x4ab4
    49fc:	movdqa xmm14,xmm0
    4a01:	psrldq xmm14,0x8
    4a07:	movq   rax,xmm14
    4a0c:	add    rax,rax
    4a0f:	je     0x4a25
    4a11:	shr    rax,0x35
    4a15:	sub    eax,0x201
    4a1a:	cmp    eax,0x3fc
    4a1f:	ja     0x4ab4
    4a25:	movq   rax,xmm1
    4a2a:	add    rax,rax
    4a2d:	je     0x4a43
    4a2f:	shr    rax,0x35
    4a33:	sub    eax,0x201
    4a38:	cmp    eax,0x3fc
    4a3d:	ja     0x4ab4
    4a43:	movdqa xmm14,xmm1
    4a48:	psrldq xmm14,0x8
    4a4e:	movq   rax,xmm14
    4a53:	add    rax,rax
    4a56:	je     0x4a6c
    4a58:	shr    rax,0x35
    4a5c:	sub    eax,0x201
    4a61:	cmp    eax,0x3fc
    4a66:	ja     0x4ab4
    4a6c:	stmxcsr DWORD PTR [rsp+0x100]
    4a74:	mov    DWORD PTR [rsp+0x104],0x1f80
    4a7f:	ldmxcsr DWORD PTR [rsp+0x104]
    4a87:	addpd  xmm0,xmm1
    4a8b:	stmxcsr DWORD PTR [rsp+0x104]
    4a93:	ldmxcsr DWORD PTR [rsp+0x100]
    4a9b:	mov    eax,DWORD PTR [rsp+0x104]
    4aa2:	shr    eax,1
    4aa4:	and    eax,0x10
    4aa7:	or     DWORD PTR [r12+0x314],eax
    4aaf:	jmp    0x4b61
    4ab4:	movdqa xmm0,xmm2
    4ab8:	movdqa xmm1,xmm3
    4abc:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4ac5:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4ace:	mov    QWORD PTR [r12+0x378],0x3
    4ada:	movdqu XMMWORD PTR [rsp],xmm2
    4adf:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4ae5:	mov    QWORD PTR [r12+0x108],rbx
    4aed:	stmxcsr DWORD PTR [r12-0x28]
    4af3:	ldmxcsr DWORD PTR [r12-0x38]
    4af9:	lea    rdi,[rsp+0xf0]
    4b01:	lea    rsi,[rsp+0xd0]
    4b09:	lea    rdx,[rsp+0xe0]
    4b11:	mov    ecx,0x14
    4b16:	mov    r8d,DWORD PTR [r12+0x310]
    4b1e:	lea    r9,[r12+0x314]
    4b26:	movabs r11,0x5b9960291750
    4b30:	call   r11
    4b33:	ldmxcsr DWORD PTR [r12-0x28]
    4b39:	movdqu xmm2,XMMWORD PTR [rsp]
    4b3e:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    4b44:	mov    rbx,QWORD PTR [r12+0x108]
    4b4c:	mov    QWORD PTR [r12+0x378],0x2
    4b58:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4b61:	movdqa xmm4,xmm0
    4b65:	movdqa xmm0,xmm4
    4b69:	movdqu XMMWORD PTR [r12+0x180],xmm0
    4b73:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    4b7d:	movdqa xmm2,xmm0
    4b81:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    4b8b:	movdqa xmm3,xmm0
    4b8f:	cmp    DWORD PTR [r12+0x310],0x0
    4b98:	jne    0x4c81
    4b9e:	movdqa xmm0,xmm2
    4ba2:	movdqa xmm1,xmm3
    4ba6:	pshufd xmm1,xmm1,0x44
    4bab:	movq   rax,xmm0
    4bb0:	add    rax,rax
    4bb3:	je     0x4bc9
    4bb5:	shr    rax,0x35
    4bb9:	sub    eax,0x201
    4bbe:	cmp    eax,0x3fc
    4bc3:	ja     0x4c81
    4bc9:	movdqa xmm14,xmm0
    4bce:	psrldq xmm14,0x8
    4bd4:	movq   rax,xmm14
    4bd9:	add    rax,rax
    4bdc:	je     0x4bf2
    4bde:	shr    rax,0x35
    4be2:	sub    eax,0x201
    4be7:	cmp    eax,0x3fc
    4bec:	ja     0x4c81
    4bf2:	movq   rax,xmm1
    4bf7:	add    rax,rax
    4bfa:	je     0x4c10
    4bfc:	shr    rax,0x35
    4c00:	sub    eax,0x201
    4c05:	cmp    eax,0x3fc
    4c0a:	ja     0x4c81
    4c10:	movdqa xmm14,xmm1
    4c15:	psrldq xmm14,0x8
    4c1b:	movq   rax,xmm14
    4c20:	add    rax,rax
    4c23:	je     0x4c39
    4c25:	shr    rax,0x35
    4c29:	sub    eax,0x201
    4c2e:	cmp    eax,0x3fc
    4c33:	ja     0x4c81
    4c39:	stmxcsr DWORD PTR [rsp+0x100]
    4c41:	mov    DWORD PTR [rsp+0x104],0x1f80
    4c4c:	ldmxcsr DWORD PTR [rsp+0x104]
    4c54:	mulpd  xmm0,xmm1
    4c58:	stmxcsr DWORD PTR [rsp+0x104]
    4c60:	ldmxcsr DWORD PTR [rsp+0x100]
    4c68:	mov    eax,DWORD PTR [rsp+0x104]
    4c6f:	shr    eax,1
    4c71:	and    eax,0x10
    4c74:	or     DWORD PTR [r12+0x314],eax
    4c7c:	jmp    0x4d2e
    4c81:	movdqa xmm0,xmm2
    4c85:	movdqa xmm1,xmm3
    4c89:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4c92:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4c9b:	mov    QWORD PTR [r12+0x378],0x3
    4ca7:	movdqu XMMWORD PTR [rsp],xmm2
    4cac:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4cb2:	mov    QWORD PTR [r12+0x108],rbx
    4cba:	stmxcsr DWORD PTR [r12-0x28]
    4cc0:	ldmxcsr DWORD PTR [r12-0x38]
    4cc6:	lea    rdi,[rsp+0xf0]
    4cce:	lea    rsi,[rsp+0xd0]
    4cd6:	lea    rdx,[rsp+0xe0]
    4cde:	mov    ecx,0x56
    4ce3:	mov    r8d,DWORD PTR [r12+0x310]
    4ceb:	lea    r9,[r12+0x314]
    4cf3:	movabs r11,0x5b9960291750
    4cfd:	call   r11
    4d00:	ldmxcsr DWORD PTR [r12-0x28]
    4d06:	movdqu xmm2,XMMWORD PTR [rsp]
    4d0b:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    4d11:	mov    rbx,QWORD PTR [r12+0x108]
    4d19:	mov    QWORD PTR [r12+0x378],0x2
    4d25:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4d2e:	movdqa xmm4,xmm0
    4d32:	movdqa xmm0,xmm4
    4d36:	movdqu XMMWORD PTR [r12+0x210],xmm0
    4d40:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    4d4a:	movdqa xmm2,xmm0
    4d4e:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    4d58:	movdqa xmm3,xmm0
    4d5c:	cmp    DWORD PTR [r12+0x310],0x0
    4d65:	jne    0x4e4e
    4d6b:	movdqa xmm0,xmm2
    4d6f:	movdqa xmm1,xmm3
    4d73:	pshufd xmm1,xmm1,0x44
    4d78:	movq   rax,xmm0
    4d7d:	add    rax,rax
    4d80:	je     0x4d96
    4d82:	shr    rax,0x35
    4d86:	sub    eax,0x201
    4d8b:	cmp    eax,0x3fc
    4d90:	ja     0x4e4e
    4d96:	movdqa xmm14,xmm0
    4d9b:	psrldq xmm14,0x8
    4da1:	movq   rax,xmm14
    4da6:	add    rax,rax
    4da9:	je     0x4dbf
    4dab:	shr    rax,0x35
    4daf:	sub    eax,0x201
    4db4:	cmp    eax,0x3fc
    4db9:	ja     0x4e4e
    4dbf:	movq   rax,xmm1
    4dc4:	add    rax,rax
    4dc7:	je     0x4ddd
    4dc9:	shr    rax,0x35
    4dcd:	sub    eax,0x201
    4dd2:	cmp    eax,0x3fc
    4dd7:	ja     0x4e4e
    4ddd:	movdqa xmm14,xmm1
    4de2:	psrldq xmm14,0x8
    4de8:	movq   rax,xmm14
    4ded:	add    rax,rax
    4df0:	je     0x4e06
    4df2:	shr    rax,0x35
    4df6:	sub    eax,0x201
    4dfb:	cmp    eax,0x3fc
    4e00:	ja     0x4e4e
    4e06:	stmxcsr DWORD PTR [rsp+0x100]
    4e0e:	mov    DWORD PTR [rsp+0x104],0x1f80
    4e19:	ldmxcsr DWORD PTR [rsp+0x104]
    4e21:	mulpd  xmm0,xmm1
    4e25:	stmxcsr DWORD PTR [rsp+0x104]
    4e2d:	ldmxcsr DWORD PTR [rsp+0x100]
    4e35:	mov    eax,DWORD PTR [rsp+0x104]
    4e3c:	shr    eax,1
    4e3e:	and    eax,0x10
    4e41:	or     DWORD PTR [r12+0x314],eax
    4e49:	jmp    0x4efb
    4e4e:	movdqa xmm0,xmm2
    4e52:	movdqa xmm1,xmm3
    4e56:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4e5f:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4e68:	mov    QWORD PTR [r12+0x378],0x3
    4e74:	movdqu XMMWORD PTR [rsp],xmm2
    4e79:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4e7f:	mov    QWORD PTR [r12+0x108],rbx
    4e87:	stmxcsr DWORD PTR [r12-0x28]
    4e8d:	ldmxcsr DWORD PTR [r12-0x38]
    4e93:	lea    rdi,[rsp+0xf0]
    4e9b:	lea    rsi,[rsp+0xd0]
    4ea3:	lea    rdx,[rsp+0xe0]
    4eab:	mov    ecx,0x56
    4eb0:	mov    r8d,DWORD PTR [r12+0x310]
    4eb8:	lea    r9,[r12+0x314]
    4ec0:	movabs r11,0x5b9960291750
    4eca:	call   r11
    4ecd:	ldmxcsr DWORD PTR [r12-0x28]
    4ed3:	movdqu xmm2,XMMWORD PTR [rsp]
    4ed8:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    4ede:	mov    rbx,QWORD PTR [r12+0x108]
    4ee6:	mov    QWORD PTR [r12+0x378],0x2
    4ef2:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4efb:	movdqa xmm4,xmm0
    4eff:	movdqa xmm0,xmm4
    4f03:	movdqu XMMWORD PTR [r12+0x230],xmm0
    4f0d:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    4f17:	movdqa xmm2,xmm0
    4f1b:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    4f25:	movdqa xmm3,xmm0
    4f29:	cmp    DWORD PTR [r12+0x310],0x0
    4f32:	jne    0x5016
    4f38:	movdqa xmm0,xmm2
    4f3c:	movdqa xmm1,xmm3
    4f40:	movq   rax,xmm0
    4f45:	add    rax,rax
    4f48:	je     0x4f5e
    4f4a:	shr    rax,0x35
    4f4e:	sub    eax,0x201
    4f53:	cmp    eax,0x3fc
    4f58:	ja     0x5016
    4f5e:	movdqa xmm14,xmm0
    4f63:	psrldq xmm14,0x8
    4f69:	movq   rax,xmm14
    4f6e:	add    rax,rax
    4f71:	je     0x4f87
    4f73:	shr    rax,0x35
    4f77:	sub    eax,0x201
    4f7c:	cmp    eax,0x3fc
    4f81:	ja     0x5016
    4f87:	movq   rax,xmm1
    4f8c:	add    rax,rax
    4f8f:	je     0x4fa5
    4f91:	shr    rax,0x35
    4f95:	sub    eax,0x201
    4f9a:	cmp    eax,0x3fc
    4f9f:	ja     0x5016
    4fa5:	movdqa xmm14,xmm1
    4faa:	psrldq xmm14,0x8
    4fb0:	movq   rax,xmm14
    4fb5:	add    rax,rax
    4fb8:	je     0x4fce
    4fba:	shr    rax,0x35
    4fbe:	sub    eax,0x201
    4fc3:	cmp    eax,0x3fc
    4fc8:	ja     0x5016
    4fce:	stmxcsr DWORD PTR [rsp+0x100]
    4fd6:	mov    DWORD PTR [rsp+0x104],0x1f80
    4fe1:	ldmxcsr DWORD PTR [rsp+0x104]
    4fe9:	addpd  xmm0,xmm1
    4fed:	stmxcsr DWORD PTR [rsp+0x104]
    4ff5:	ldmxcsr DWORD PTR [rsp+0x100]
    4ffd:	mov    eax,DWORD PTR [rsp+0x104]
    5004:	shr    eax,1
    5006:	and    eax,0x10
    5009:	or     DWORD PTR [r12+0x314],eax
    5011:	jmp    0x50c3
    5016:	movdqa xmm0,xmm2
    501a:	movdqa xmm1,xmm3
    501e:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5027:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5030:	mov    QWORD PTR [r12+0x378],0x3
    503c:	movdqu XMMWORD PTR [rsp],xmm2
    5041:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5047:	mov    QWORD PTR [r12+0x108],rbx
    504f:	stmxcsr DWORD PTR [r12-0x28]
    5055:	ldmxcsr DWORD PTR [r12-0x38]
    505b:	lea    rdi,[rsp+0xf0]
    5063:	lea    rsi,[rsp+0xd0]
    506b:	lea    rdx,[rsp+0xe0]
    5073:	mov    ecx,0x14
    5078:	mov    r8d,DWORD PTR [r12+0x310]
    5080:	lea    r9,[r12+0x314]
    5088:	movabs r11,0x5b9960291750
    5092:	call   r11
    5095:	ldmxcsr DWORD PTR [r12-0x28]
    509b:	movdqu xmm2,XMMWORD PTR [rsp]
    50a0:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    50a6:	mov    rbx,QWORD PTR [r12+0x108]
    50ae:	mov    QWORD PTR [r12+0x378],0x2
    50ba:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    50c3:	movdqa xmm4,xmm0
    50c7:	movdqa xmm0,xmm4
    50cb:	movdqu XMMWORD PTR [r12+0x240],xmm0
    50d5:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    50df:	movdqa xmm2,xmm0
    50e3:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    50ed:	movdqa xmm3,xmm0
    50f1:	cmp    DWORD PTR [r12+0x310],0x0
    50fa:	jne    0x51de
    5100:	movdqa xmm0,xmm2
    5104:	movdqa xmm1,xmm3
    5108:	movq   rax,xmm0
    510d:	add    rax,rax
    5110:	je     0x5126
    5112:	shr    rax,0x35
    5116:	sub    eax,0x201
    511b:	cmp    eax,0x3fc
    5120:	ja     0x51de
    5126:	movdqa xmm14,xmm0
    512b:	psrldq xmm14,0x8
    5131:	movq   rax,xmm14
    5136:	add    rax,rax
    5139:	je     0x514f
    513b:	shr    rax,0x35
    513f:	sub    eax,0x201
    5144:	cmp    eax,0x3fc
    5149:	ja     0x51de
    514f:	movq   rax,xmm1
    5154:	add    rax,rax
    5157:	je     0x516d
    5159:	shr    rax,0x35
    515d:	sub    eax,0x201
    5162:	cmp    eax,0x3fc
    5167:	ja     0x51de
    516d:	movdqa xmm14,xmm1
    5172:	psrldq xmm14,0x8
    5178:	movq   rax,xmm14
    517d:	add    rax,rax
    5180:	je     0x5196
    5182:	shr    rax,0x35
    5186:	sub    eax,0x201
    518b:	cmp    eax,0x3fc
    5190:	ja     0x51de
    5196:	stmxcsr DWORD PTR [rsp+0x100]
    519e:	mov    DWORD PTR [rsp+0x104],0x1f80
    51a9:	ldmxcsr DWORD PTR [rsp+0x104]
    51b1:	addpd  xmm0,xmm1
    51b5:	stmxcsr DWORD PTR [rsp+0x104]
    51bd:	ldmxcsr DWORD PTR [rsp+0x100]
    51c5:	mov    eax,DWORD PTR [rsp+0x104]
    51cc:	shr    eax,1
    51ce:	and    eax,0x10
    51d1:	or     DWORD PTR [r12+0x314],eax
    51d9:	jmp    0x528b
    51de:	movdqa xmm0,xmm2
    51e2:	movdqa xmm1,xmm3
    51e6:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    51ef:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    51f8:	mov    QWORD PTR [r12+0x378],0x3
    5204:	movdqu XMMWORD PTR [rsp],xmm2
    5209:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    520f:	mov    QWORD PTR [r12+0x108],rbx
    5217:	stmxcsr DWORD PTR [r12-0x28]
    521d:	ldmxcsr DWORD PTR [r12-0x38]
    5223:	lea    rdi,[rsp+0xf0]
    522b:	lea    rsi,[rsp+0xd0]
    5233:	lea    rdx,[rsp+0xe0]
    523b:	mov    ecx,0x14
    5240:	mov    r8d,DWORD PTR [r12+0x310]
    5248:	lea    r9,[r12+0x314]
    5250:	movabs r11,0x5b9960291750
    525a:	call   r11
    525d:	ldmxcsr DWORD PTR [r12-0x28]
    5263:	movdqu xmm2,XMMWORD PTR [rsp]
    5268:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    526e:	mov    rbx,QWORD PTR [r12+0x108]
    5276:	mov    QWORD PTR [r12+0x378],0x2
    5282:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    528b:	movdqa xmm4,xmm0
    528f:	movdqa xmm0,xmm4
    5293:	movdqu XMMWORD PTR [r12+0x220],xmm0
    529d:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    52a7:	movdqa xmm2,xmm0
    52ab:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    52b5:	movdqa xmm3,xmm0
    52b9:	cmp    DWORD PTR [r12+0x310],0x0
    52c2:	jne    0x53ab
    52c8:	movdqa xmm0,xmm2
    52cc:	movdqa xmm1,xmm3
    52d0:	pshufd xmm1,xmm1,0x44
    52d5:	movq   rax,xmm0
    52da:	add    rax,rax
    52dd:	je     0x52f3
    52df:	shr    rax,0x35
    52e3:	sub    eax,0x201
    52e8:	cmp    eax,0x3fc
    52ed:	ja     0x53ab
    52f3:	movdqa xmm14,xmm0
    52f8:	psrldq xmm14,0x8
    52fe:	movq   rax,xmm14
    5303:	add    rax,rax
    5306:	je     0x531c
    5308:	shr    rax,0x35
    530c:	sub    eax,0x201
    5311:	cmp    eax,0x3fc
    5316:	ja     0x53ab
    531c:	movq   rax,xmm1
    5321:	add    rax,rax
    5324:	je     0x533a
    5326:	shr    rax,0x35
    532a:	sub    eax,0x201
    532f:	cmp    eax,0x3fc
    5334:	ja     0x53ab
    533a:	movdqa xmm14,xmm1
    533f:	psrldq xmm14,0x8
    5345:	movq   rax,xmm14
    534a:	add    rax,rax
    534d:	je     0x5363
    534f:	shr    rax,0x35
    5353:	sub    eax,0x201
    5358:	cmp    eax,0x3fc
    535d:	ja     0x53ab
    5363:	stmxcsr DWORD PTR [rsp+0x100]
    536b:	mov    DWORD PTR [rsp+0x104],0x1f80
    5376:	ldmxcsr DWORD PTR [rsp+0x104]
    537e:	mulpd  xmm0,xmm1
    5382:	stmxcsr DWORD PTR [rsp+0x104]
    538a:	ldmxcsr DWORD PTR [rsp+0x100]
    5392:	mov    eax,DWORD PTR [rsp+0x104]
    5399:	shr    eax,1
    539b:	and    eax,0x10
    539e:	or     DWORD PTR [r12+0x314],eax
    53a6:	jmp    0x5458
    53ab:	movdqa xmm0,xmm2
    53af:	movdqa xmm1,xmm3
    53b3:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    53bc:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    53c5:	mov    QWORD PTR [r12+0x378],0x3
    53d1:	movdqu XMMWORD PTR [rsp],xmm2
    53d6:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    53dc:	mov    QWORD PTR [r12+0x108],rbx
    53e4:	stmxcsr DWORD PTR [r12-0x28]
    53ea:	ldmxcsr DWORD PTR [r12-0x38]
    53f0:	lea    rdi,[rsp+0xf0]
    53f8:	lea    rsi,[rsp+0xd0]
    5400:	lea    rdx,[rsp+0xe0]
    5408:	mov    ecx,0x56
    540d:	mov    r8d,DWORD PTR [r12+0x310]
    5415:	lea    r9,[r12+0x314]
    541d:	movabs r11,0x5b9960291750
    5427:	call   r11
    542a:	ldmxcsr DWORD PTR [r12-0x28]
    5430:	movdqu xmm2,XMMWORD PTR [rsp]
    5435:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    543b:	mov    rbx,QWORD PTR [r12+0x108]
    5443:	mov    QWORD PTR [r12+0x378],0x2
    544f:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5458:	movdqa xmm4,xmm0
    545c:	movdqa xmm0,xmm4
    5460:	movdqu XMMWORD PTR [r12+0x250],xmm0
    546a:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    5474:	movdqa xmm2,xmm0
    5478:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    5482:	movdqa xmm3,xmm0
    5486:	cmp    DWORD PTR [r12+0x310],0x0
    548f:	jne    0x5578
    5495:	movdqa xmm0,xmm2
    5499:	movdqa xmm1,xmm3
    549d:	pshufd xmm1,xmm1,0x44
    54a2:	movq   rax,xmm0
    54a7:	add    rax,rax
    54aa:	je     0x54c0
    54ac:	shr    rax,0x35
    54b0:	sub    eax,0x201
    54b5:	cmp    eax,0x3fc
    54ba:	ja     0x5578
    54c0:	movdqa xmm14,xmm0
    54c5:	psrldq xmm14,0x8
    54cb:	movq   rax,xmm14
    54d0:	add    rax,rax
    54d3:	je     0x54e9
    54d5:	shr    rax,0x35
    54d9:	sub    eax,0x201
    54de:	cmp    eax,0x3fc
    54e3:	ja     0x5578
    54e9:	movq   rax,xmm1
    54ee:	add    rax,rax
    54f1:	je     0x5507
    54f3:	shr    rax,0x35
    54f7:	sub    eax,0x201
    54fc:	cmp    eax,0x3fc
    5501:	ja     0x5578
    5507:	movdqa xmm14,xmm1
    550c:	psrldq xmm14,0x8
    5512:	movq   rax,xmm14
    5517:	add    rax,rax
    551a:	je     0x5530
    551c:	shr    rax,0x35
    5520:	sub    eax,0x201
    5525:	cmp    eax,0x3fc
    552a:	ja     0x5578
    5530:	stmxcsr DWORD PTR [rsp+0x100]
    5538:	mov    DWORD PTR [rsp+0x104],0x1f80
    5543:	ldmxcsr DWORD PTR [rsp+0x104]
    554b:	mulpd  xmm0,xmm1
    554f:	stmxcsr DWORD PTR [rsp+0x104]
    5557:	ldmxcsr DWORD PTR [rsp+0x100]
    555f:	mov    eax,DWORD PTR [rsp+0x104]
    5566:	shr    eax,1
    5568:	and    eax,0x10
    556b:	or     DWORD PTR [r12+0x314],eax
    5573:	jmp    0x5625
    5578:	movdqa xmm0,xmm2
    557c:	movdqa xmm1,xmm3
    5580:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5589:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5592:	mov    QWORD PTR [r12+0x378],0x3
    559e:	movdqu XMMWORD PTR [rsp],xmm2
    55a3:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    55a9:	mov    QWORD PTR [r12+0x108],rbx
    55b1:	stmxcsr DWORD PTR [r12-0x28]
    55b7:	ldmxcsr DWORD PTR [r12-0x38]
    55bd:	lea    rdi,[rsp+0xf0]
    55c5:	lea    rsi,[rsp+0xd0]
    55cd:	lea    rdx,[rsp+0xe0]
    55d5:	mov    ecx,0x56
    55da:	mov    r8d,DWORD PTR [r12+0x310]
    55e2:	lea    r9,[r12+0x314]
    55ea:	movabs r11,0x5b9960291750
    55f4:	call   r11
    55f7:	ldmxcsr DWORD PTR [r12-0x28]
    55fd:	movdqu xmm2,XMMWORD PTR [rsp]
    5602:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5608:	mov    rbx,QWORD PTR [r12+0x108]
    5610:	mov    QWORD PTR [r12+0x378],0x2
    561c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5625:	movdqa xmm4,xmm0
    5629:	movdqa xmm0,xmm4
    562d:	movdqu XMMWORD PTR [r12+0x150],xmm0
    5637:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    5641:	movdqa xmm2,xmm0
    5645:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    564f:	movdqa xmm3,xmm0
    5653:	cmp    DWORD PTR [r12+0x310],0x0
    565c:	jne    0x5740
    5662:	movdqa xmm0,xmm2
    5666:	movdqa xmm1,xmm3
    566a:	movq   rax,xmm0
    566f:	add    rax,rax
    5672:	je     0x5688
    5674:	shr    rax,0x35
    5678:	sub    eax,0x201
    567d:	cmp    eax,0x3fc
    5682:	ja     0x5740
    5688:	movdqa xmm14,xmm0
    568d:	psrldq xmm14,0x8
    5693:	movq   rax,xmm14
    5698:	add    rax,rax
    569b:	je     0x56b1
    569d:	shr    rax,0x35
    56a1:	sub    eax,0x201
    56a6:	cmp    eax,0x3fc
    56ab:	ja     0x5740
    56b1:	movq   rax,xmm1
    56b6:	add    rax,rax
    56b9:	je     0x56cf
    56bb:	shr    rax,0x35
    56bf:	sub    eax,0x201
    56c4:	cmp    eax,0x3fc
    56c9:	ja     0x5740
    56cf:	movdqa xmm14,xmm1
    56d4:	psrldq xmm14,0x8
    56da:	movq   rax,xmm14
    56df:	add    rax,rax
    56e2:	je     0x56f8
    56e4:	shr    rax,0x35
    56e8:	sub    eax,0x201
    56ed:	cmp    eax,0x3fc
    56f2:	ja     0x5740
    56f8:	stmxcsr DWORD PTR [rsp+0x100]
    5700:	mov    DWORD PTR [rsp+0x104],0x1f80
    570b:	ldmxcsr DWORD PTR [rsp+0x104]
    5713:	addpd  xmm0,xmm1
    5717:	stmxcsr DWORD PTR [rsp+0x104]
    571f:	ldmxcsr DWORD PTR [rsp+0x100]
    5727:	mov    eax,DWORD PTR [rsp+0x104]
    572e:	shr    eax,1
    5730:	and    eax,0x10
    5733:	or     DWORD PTR [r12+0x314],eax
    573b:	jmp    0x57ed
    5740:	movdqa xmm0,xmm2
    5744:	movdqa xmm1,xmm3
    5748:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5751:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    575a:	mov    QWORD PTR [r12+0x378],0x3
    5766:	movdqu XMMWORD PTR [rsp],xmm2
    576b:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5771:	mov    QWORD PTR [r12+0x108],rbx
    5779:	stmxcsr DWORD PTR [r12-0x28]
    577f:	ldmxcsr DWORD PTR [r12-0x38]
    5785:	lea    rdi,[rsp+0xf0]
    578d:	lea    rsi,[rsp+0xd0]
    5795:	lea    rdx,[rsp+0xe0]
    579d:	mov    ecx,0x14
    57a2:	mov    r8d,DWORD PTR [r12+0x310]
    57aa:	lea    r9,[r12+0x314]
    57b2:	movabs r11,0x5b9960291750
    57bc:	call   r11
    57bf:	ldmxcsr DWORD PTR [r12-0x28]
    57c5:	movdqu xmm2,XMMWORD PTR [rsp]
    57ca:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    57d0:	mov    rbx,QWORD PTR [r12+0x108]
    57d8:	mov    QWORD PTR [r12+0x378],0x2
    57e4:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    57ed:	movdqa xmm4,xmm0
    57f1:	movdqa xmm0,xmm4
    57f5:	movdqu XMMWORD PTR [r12+0x160],xmm0
    57ff:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    5809:	movdqa xmm2,xmm0
    580d:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    5817:	movdqa xmm3,xmm0
    581b:	cmp    DWORD PTR [r12+0x310],0x0
    5824:	jne    0x5908
    582a:	movdqa xmm0,xmm2
    582e:	movdqa xmm1,xmm3
    5832:	movq   rax,xmm0
    5837:	add    rax,rax
    583a:	je     0x5850
    583c:	shr    rax,0x35
    5840:	sub    eax,0x201
    5845:	cmp    eax,0x3fc
    584a:	ja     0x5908
    5850:	movdqa xmm14,xmm0
    5855:	psrldq xmm14,0x8
    585b:	movq   rax,xmm14
    5860:	add    rax,rax
    5863:	je     0x5879
    5865:	shr    rax,0x35
    5869:	sub    eax,0x201
    586e:	cmp    eax,0x3fc
    5873:	ja     0x5908
    5879:	movq   rax,xmm1
    587e:	add    rax,rax
    5881:	je     0x5897
    5883:	shr    rax,0x35
    5887:	sub    eax,0x201
    588c:	cmp    eax,0x3fc
    5891:	ja     0x5908
    5897:	movdqa xmm14,xmm1
    589c:	psrldq xmm14,0x8
    58a2:	movq   rax,xmm14
    58a7:	add    rax,rax
    58aa:	je     0x58c0
    58ac:	shr    rax,0x35
    58b0:	sub    eax,0x201
    58b5:	cmp    eax,0x3fc
    58ba:	ja     0x5908
    58c0:	stmxcsr DWORD PTR [rsp+0x100]
    58c8:	mov    DWORD PTR [rsp+0x104],0x1f80
    58d3:	ldmxcsr DWORD PTR [rsp+0x104]
    58db:	addpd  xmm0,xmm1
    58df:	stmxcsr DWORD PTR [rsp+0x104]
    58e7:	ldmxcsr DWORD PTR [rsp+0x100]
    58ef:	mov    eax,DWORD PTR [rsp+0x104]
    58f6:	shr    eax,1
    58f8:	and    eax,0x10
    58fb:	or     DWORD PTR [r12+0x314],eax
    5903:	jmp    0x59b5
    5908:	movdqa xmm0,xmm2
    590c:	movdqa xmm1,xmm3
    5910:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5919:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5922:	mov    QWORD PTR [r12+0x378],0x3
    592e:	movdqu XMMWORD PTR [rsp],xmm2
    5933:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5939:	mov    QWORD PTR [r12+0x108],rbx
    5941:	stmxcsr DWORD PTR [r12-0x28]
    5947:	ldmxcsr DWORD PTR [r12-0x38]
    594d:	lea    rdi,[rsp+0xf0]
    5955:	lea    rsi,[rsp+0xd0]
    595d:	lea    rdx,[rsp+0xe0]
    5965:	mov    ecx,0x14
    596a:	mov    r8d,DWORD PTR [r12+0x310]
    5972:	lea    r9,[r12+0x314]
    597a:	movabs r11,0x5b9960291750
    5984:	call   r11
    5987:	ldmxcsr DWORD PTR [r12-0x28]
    598d:	movdqu xmm2,XMMWORD PTR [rsp]
    5992:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5998:	mov    rbx,QWORD PTR [r12+0x108]
    59a0:	mov    QWORD PTR [r12+0x378],0x2
    59ac:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    59b5:	movdqa xmm4,xmm0
    59b9:	movdqa xmm0,xmm4
    59bd:	movdqu XMMWORD PTR [r12+0x170],xmm0
    59c7:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    59d1:	movdqa xmm2,xmm0
    59d5:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    59df:	movdqa xmm3,xmm0
    59e3:	cmp    DWORD PTR [r12+0x310],0x0
    59ec:	jne    0x5ad5
    59f2:	movdqa xmm0,xmm2
    59f6:	movdqa xmm1,xmm3
    59fa:	pshufd xmm1,xmm1,0x44
    59ff:	movq   rax,xmm0
    5a04:	add    rax,rax
    5a07:	je     0x5a1d
    5a09:	shr    rax,0x35
    5a0d:	sub    eax,0x201
    5a12:	cmp    eax,0x3fc
    5a17:	ja     0x5ad5
    5a1d:	movdqa xmm14,xmm0
    5a22:	psrldq xmm14,0x8
    5a28:	movq   rax,xmm14
    5a2d:	add    rax,rax
    5a30:	je     0x5a46
    5a32:	shr    rax,0x35
    5a36:	sub    eax,0x201
    5a3b:	cmp    eax,0x3fc
    5a40:	ja     0x5ad5
    5a46:	movq   rax,xmm1
    5a4b:	add    rax,rax
    5a4e:	je     0x5a64
    5a50:	shr    rax,0x35
    5a54:	sub    eax,0x201
    5a59:	cmp    eax,0x3fc
    5a5e:	ja     0x5ad5
    5a64:	movdqa xmm14,xmm1
    5a69:	psrldq xmm14,0x8
    5a6f:	movq   rax,xmm14
    5a74:	add    rax,rax
    5a77:	je     0x5a8d
    5a79:	shr    rax,0x35
    5a7d:	sub    eax,0x201
    5a82:	cmp    eax,0x3fc
    5a87:	ja     0x5ad5
    5a8d:	stmxcsr DWORD PTR [rsp+0x100]
    5a95:	mov    DWORD PTR [rsp+0x104],0x1f80
    5aa0:	ldmxcsr DWORD PTR [rsp+0x104]
    5aa8:	mulpd  xmm0,xmm1
    5aac:	stmxcsr DWORD PTR [rsp+0x104]
    5ab4:	ldmxcsr DWORD PTR [rsp+0x100]
    5abc:	mov    eax,DWORD PTR [rsp+0x104]
    5ac3:	shr    eax,1
    5ac5:	and    eax,0x10
    5ac8:	or     DWORD PTR [r12+0x314],eax
    5ad0:	jmp    0x5b82
    5ad5:	movdqa xmm0,xmm2
    5ad9:	movdqa xmm1,xmm3
    5add:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5ae6:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5aef:	mov    QWORD PTR [r12+0x378],0x3
    5afb:	movdqu XMMWORD PTR [rsp],xmm2
    5b00:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5b06:	mov    QWORD PTR [r12+0x108],rbx
    5b0e:	stmxcsr DWORD PTR [r12-0x28]
    5b14:	ldmxcsr DWORD PTR [r12-0x38]
    5b1a:	lea    rdi,[rsp+0xf0]
    5b22:	lea    rsi,[rsp+0xd0]
    5b2a:	lea    rdx,[rsp+0xe0]
    5b32:	mov    ecx,0x56
    5b37:	mov    r8d,DWORD PTR [r12+0x310]
    5b3f:	lea    r9,[r12+0x314]
    5b47:	movabs r11,0x5b9960291750
    5b51:	call   r11
    5b54:	ldmxcsr DWORD PTR [r12-0x28]
    5b5a:	movdqu xmm2,XMMWORD PTR [rsp]
    5b5f:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5b65:	mov    rbx,QWORD PTR [r12+0x108]
    5b6d:	mov    QWORD PTR [r12+0x378],0x2
    5b79:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5b82:	movdqa xmm4,xmm0
    5b86:	movdqa xmm0,xmm4
    5b8a:	movdqu XMMWORD PTR [r12+0x180],xmm0
    5b94:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    5b9e:	movdqa xmm2,xmm0
    5ba2:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    5bac:	movdqa xmm3,xmm0
    5bb0:	cmp    DWORD PTR [r12+0x310],0x0
    5bb9:	jne    0x5c9d
    5bbf:	movdqa xmm0,xmm2
    5bc3:	movdqa xmm1,xmm3
    5bc7:	movq   rax,xmm0
    5bcc:	add    rax,rax
    5bcf:	je     0x5be5
    5bd1:	shr    rax,0x35
    5bd5:	sub    eax,0x201
    5bda:	cmp    eax,0x3fc
    5bdf:	ja     0x5c9d
    5be5:	movdqa xmm14,xmm0
    5bea:	psrldq xmm14,0x8
    5bf0:	movq   rax,xmm14
    5bf5:	add    rax,rax
    5bf8:	je     0x5c0e
    5bfa:	shr    rax,0x35
    5bfe:	sub    eax,0x201
    5c03:	cmp    eax,0x3fc
    5c08:	ja     0x5c9d
    5c0e:	movq   rax,xmm1
    5c13:	add    rax,rax
    5c16:	je     0x5c2c
    5c18:	shr    rax,0x35
    5c1c:	sub    eax,0x201
    5c21:	cmp    eax,0x3fc
    5c26:	ja     0x5c9d
    5c2c:	movdqa xmm14,xmm1
    5c31:	psrldq xmm14,0x8
    5c37:	movq   rax,xmm14
    5c3c:	add    rax,rax
    5c3f:	je     0x5c55
    5c41:	shr    rax,0x35
    5c45:	sub    eax,0x201
    5c4a:	cmp    eax,0x3fc
    5c4f:	ja     0x5c9d
    5c55:	stmxcsr DWORD PTR [rsp+0x100]
    5c5d:	mov    DWORD PTR [rsp+0x104],0x1f80
    5c68:	ldmxcsr DWORD PTR [rsp+0x104]
    5c70:	addpd  xmm0,xmm1
    5c74:	stmxcsr DWORD PTR [rsp+0x104]
    5c7c:	ldmxcsr DWORD PTR [rsp+0x100]
    5c84:	mov    eax,DWORD PTR [rsp+0x104]
    5c8b:	shr    eax,1
    5c8d:	and    eax,0x10
    5c90:	or     DWORD PTR [r12+0x314],eax
    5c98:	jmp    0x5d4a
    5c9d:	movdqa xmm0,xmm2
    5ca1:	movdqa xmm1,xmm3
    5ca5:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5cae:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5cb7:	mov    QWORD PTR [r12+0x378],0x3
    5cc3:	movdqu XMMWORD PTR [rsp],xmm2
    5cc8:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5cce:	mov    QWORD PTR [r12+0x108],rbx
    5cd6:	stmxcsr DWORD PTR [r12-0x28]
    5cdc:	ldmxcsr DWORD PTR [r12-0x38]
    5ce2:	lea    rdi,[rsp+0xf0]
    5cea:	lea    rsi,[rsp+0xd0]
    5cf2:	lea    rdx,[rsp+0xe0]
    5cfa:	mov    ecx,0x14
    5cff:	mov    r8d,DWORD PTR [r12+0x310]
    5d07:	lea    r9,[r12+0x314]
    5d0f:	movabs r11,0x5b9960291750
    5d19:	call   r11
    5d1c:	ldmxcsr DWORD PTR [r12-0x28]
    5d22:	movdqu xmm2,XMMWORD PTR [rsp]
    5d27:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5d2d:	mov    rbx,QWORD PTR [r12+0x108]
    5d35:	mov    QWORD PTR [r12+0x378],0x2
    5d41:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5d4a:	movdqa xmm4,xmm0
    5d4e:	movdqa xmm0,xmm4
    5d52:	movdqu XMMWORD PTR [r12+0x210],xmm0
    5d5c:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    5d66:	movdqa xmm2,xmm0
    5d6a:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    5d74:	movdqa xmm3,xmm0
    5d78:	cmp    DWORD PTR [r12+0x310],0x0
    5d81:	jne    0x5e65
    5d87:	movdqa xmm0,xmm2
    5d8b:	movdqa xmm1,xmm3
    5d8f:	movq   rax,xmm0
    5d94:	add    rax,rax
    5d97:	je     0x5dad
    5d99:	shr    rax,0x35
    5d9d:	sub    eax,0x201
    5da2:	cmp    eax,0x3fc
    5da7:	ja     0x5e65
    5dad:	movdqa xmm14,xmm0
    5db2:	psrldq xmm14,0x8
    5db8:	movq   rax,xmm14
    5dbd:	add    rax,rax
    5dc0:	je     0x5dd6
    5dc2:	shr    rax,0x35
    5dc6:	sub    eax,0x201
    5dcb:	cmp    eax,0x3fc
    5dd0:	ja     0x5e65
    5dd6:	movq   rax,xmm1
    5ddb:	add    rax,rax
    5dde:	je     0x5df4
    5de0:	shr    rax,0x35
    5de4:	sub    eax,0x201
    5de9:	cmp    eax,0x3fc
    5dee:	ja     0x5e65
    5df4:	movdqa xmm14,xmm1
    5df9:	psrldq xmm14,0x8
    5dff:	movq   rax,xmm14
    5e04:	add    rax,rax
    5e07:	je     0x5e1d
    5e09:	shr    rax,0x35
    5e0d:	sub    eax,0x201
    5e12:	cmp    eax,0x3fc
    5e17:	ja     0x5e65
    5e1d:	stmxcsr DWORD PTR [rsp+0x100]
    5e25:	mov    DWORD PTR [rsp+0x104],0x1f80
    5e30:	ldmxcsr DWORD PTR [rsp+0x104]
    5e38:	addpd  xmm0,xmm1
    5e3c:	stmxcsr DWORD PTR [rsp+0x104]
    5e44:	ldmxcsr DWORD PTR [rsp+0x100]
    5e4c:	mov    eax,DWORD PTR [rsp+0x104]
    5e53:	shr    eax,1
    5e55:	and    eax,0x10
    5e58:	or     DWORD PTR [r12+0x314],eax
    5e60:	jmp    0x5f12
    5e65:	movdqa xmm0,xmm2
    5e69:	movdqa xmm1,xmm3
    5e6d:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5e76:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5e7f:	mov    QWORD PTR [r12+0x378],0x3
    5e8b:	movdqu XMMWORD PTR [rsp],xmm2
    5e90:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5e96:	mov    QWORD PTR [r12+0x108],rbx
    5e9e:	stmxcsr DWORD PTR [r12-0x28]
    5ea4:	ldmxcsr DWORD PTR [r12-0x38]
    5eaa:	lea    rdi,[rsp+0xf0]
    5eb2:	lea    rsi,[rsp+0xd0]
    5eba:	lea    rdx,[rsp+0xe0]
    5ec2:	mov    ecx,0x14
    5ec7:	mov    r8d,DWORD PTR [r12+0x310]
    5ecf:	lea    r9,[r12+0x314]
    5ed7:	movabs r11,0x5b9960291750
    5ee1:	call   r11
    5ee4:	ldmxcsr DWORD PTR [r12-0x28]
    5eea:	movdqu xmm2,XMMWORD PTR [rsp]
    5eef:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5ef5:	mov    rbx,QWORD PTR [r12+0x108]
    5efd:	mov    QWORD PTR [r12+0x378],0x2
    5f09:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5f12:	movdqa xmm4,xmm0
    5f16:	movdqa xmm0,xmm4
    5f1a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    5f24:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    5f2e:	movdqa xmm2,xmm0
    5f32:	movdqa xmm0,xmm2
    5f36:	movdqa xmm1,xmm2
    5f3a:	por    xmm0,xmm1
    5f3e:	movdqa xmm3,xmm0
    5f42:	movdqa xmm0,xmm3
    5f46:	movdqu XMMWORD PTR [r12+0x250],xmm0
    5f50:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    5f5a:	movdqa xmm2,xmm0
    5f5e:	movdqa xmm0,xmm2
    5f62:	movdqa xmm1,xmm2
    5f66:	por    xmm0,xmm1
    5f6a:	movdqa xmm3,xmm0
    5f6e:	movdqa xmm0,xmm3
    5f72:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    5f7c:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    5f86:	movdqa xmm2,xmm0
    5f8a:	movdqa xmm0,xmm2
    5f8e:	movdqa xmm1,xmm2
    5f92:	por    xmm0,xmm1
    5f96:	movdqa xmm3,xmm0
    5f9a:	movdqa xmm0,xmm3
    5f9e:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    5fa8:	mov    r13,QWORD PTR [r12+0xf8]
    5fb0:	mov    r14,r13
    5fb3:	add    r14,0x40
    5fb7:	movdqu xmm2,XMMWORD PTR [r14]
    5fbc:	movdqa xmm0,xmm2
    5fc0:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    5fca:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    5fd4:	movdqa xmm2,xmm0
    5fd8:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    5fe2:	movdqa xmm3,xmm0
    5fe6:	cmp    DWORD PTR [r12+0x310],0x0
    5fef:	jne    0x60d8
    5ff5:	movdqa xmm0,xmm2
    5ff9:	movdqa xmm1,xmm3
    5ffd:	pshufd xmm1,xmm1,0x44
    6002:	movq   rax,xmm0
    6007:	add    rax,rax
    600a:	je     0x6020
    600c:	shr    rax,0x35
    6010:	sub    eax,0x201
    6015:	cmp    eax,0x3fc
    601a:	ja     0x60d8
    6020:	movdqa xmm14,xmm0
    6025:	psrldq xmm14,0x8
    602b:	movq   rax,xmm14
    6030:	add    rax,rax
    6033:	je     0x6049
    6035:	shr    rax,0x35
    6039:	sub    eax,0x201
    603e:	cmp    eax,0x3fc
    6043:	ja     0x60d8
    6049:	movq   rax,xmm1
    604e:	add    rax,rax
    6051:	je     0x6067
    6053:	shr    rax,0x35
    6057:	sub    eax,0x201
    605c:	cmp    eax,0x3fc
    6061:	ja     0x60d8
    6067:	movdqa xmm14,xmm1
    606c:	psrldq xmm14,0x8
    6072:	movq   rax,xmm14
    6077:	add    rax,rax
    607a:	je     0x6090
    607c:	shr    rax,0x35
    6080:	sub    eax,0x201
    6085:	cmp    eax,0x3fc
    608a:	ja     0x60d8
    6090:	stmxcsr DWORD PTR [rsp+0x100]
    6098:	mov    DWORD PTR [rsp+0x104],0x1f80
    60a3:	ldmxcsr DWORD PTR [rsp+0x104]
    60ab:	mulpd  xmm0,xmm1
    60af:	stmxcsr DWORD PTR [rsp+0x104]
    60b7:	ldmxcsr DWORD PTR [rsp+0x100]
    60bf:	mov    eax,DWORD PTR [rsp+0x104]
    60c6:	shr    eax,1
    60c8:	and    eax,0x10
    60cb:	or     DWORD PTR [r12+0x314],eax
    60d3:	jmp    0x6185
    60d8:	movdqa xmm0,xmm2
    60dc:	movdqa xmm1,xmm3
    60e0:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    60e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    60f2:	mov    QWORD PTR [r12+0x378],0x3
    60fe:	movdqu XMMWORD PTR [rsp],xmm2
    6103:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6109:	mov    QWORD PTR [r12+0x108],rbx
    6111:	stmxcsr DWORD PTR [r12-0x28]
    6117:	ldmxcsr DWORD PTR [r12-0x38]
    611d:	lea    rdi,[rsp+0xf0]
    6125:	lea    rsi,[rsp+0xd0]
    612d:	lea    rdx,[rsp+0xe0]
    6135:	mov    ecx,0x56
    613a:	mov    r8d,DWORD PTR [r12+0x310]
    6142:	lea    r9,[r12+0x314]
    614a:	movabs r11,0x5b9960291750
    6154:	call   r11
    6157:	ldmxcsr DWORD PTR [r12-0x28]
    615d:	movdqu xmm2,XMMWORD PTR [rsp]
    6162:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6168:	mov    rbx,QWORD PTR [r12+0x108]
    6170:	mov    QWORD PTR [r12+0x378],0x2
    617c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6185:	movdqa xmm4,xmm0
    6189:	movdqa xmm0,xmm4
    618d:	movdqu XMMWORD PTR [r12+0x220],xmm0
    6197:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    61a1:	movdqa xmm2,xmm0
    61a5:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    61af:	movdqa xmm3,xmm0
    61b3:	cmp    DWORD PTR [r12+0x310],0x0
    61bc:	jne    0x62a0
    61c2:	movdqa xmm0,xmm2
    61c6:	movdqa xmm1,xmm3
    61ca:	movq   rax,xmm0
    61cf:	add    rax,rax
    61d2:	je     0x61e8
    61d4:	shr    rax,0x35
    61d8:	sub    eax,0x201
    61dd:	cmp    eax,0x3fc
    61e2:	ja     0x62a0
    61e8:	movdqa xmm14,xmm0
    61ed:	psrldq xmm14,0x8
    61f3:	movq   rax,xmm14
    61f8:	add    rax,rax
    61fb:	je     0x6211
    61fd:	shr    rax,0x35
    6201:	sub    eax,0x201
    6206:	cmp    eax,0x3fc
    620b:	ja     0x62a0
    6211:	movq   rax,xmm1
    6216:	add    rax,rax
    6219:	je     0x622f
    621b:	shr    rax,0x35
    621f:	sub    eax,0x201
    6224:	cmp    eax,0x3fc
    6229:	ja     0x62a0
    622f:	movdqa xmm14,xmm1
    6234:	psrldq xmm14,0x8
    623a:	movq   rax,xmm14
    623f:	add    rax,rax
    6242:	je     0x6258
    6244:	shr    rax,0x35
    6248:	sub    eax,0x201
    624d:	cmp    eax,0x3fc
    6252:	ja     0x62a0
    6258:	stmxcsr DWORD PTR [rsp+0x100]
    6260:	mov    DWORD PTR [rsp+0x104],0x1f80
    626b:	ldmxcsr DWORD PTR [rsp+0x104]
    6273:	addpd  xmm0,xmm1
    6277:	stmxcsr DWORD PTR [rsp+0x104]
    627f:	ldmxcsr DWORD PTR [rsp+0x100]
    6287:	mov    eax,DWORD PTR [rsp+0x104]
    628e:	shr    eax,1
    6290:	and    eax,0x10
    6293:	or     DWORD PTR [r12+0x314],eax
    629b:	jmp    0x634d
    62a0:	movdqa xmm0,xmm2
    62a4:	movdqa xmm1,xmm3
    62a8:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    62b1:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    62ba:	mov    QWORD PTR [r12+0x378],0x3
    62c6:	movdqu XMMWORD PTR [rsp],xmm2
    62cb:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    62d1:	mov    QWORD PTR [r12+0x108],rbx
    62d9:	stmxcsr DWORD PTR [r12-0x28]
    62df:	ldmxcsr DWORD PTR [r12-0x38]
    62e5:	lea    rdi,[rsp+0xf0]
    62ed:	lea    rsi,[rsp+0xd0]
    62f5:	lea    rdx,[rsp+0xe0]
    62fd:	mov    ecx,0x14
    6302:	mov    r8d,DWORD PTR [r12+0x310]
    630a:	lea    r9,[r12+0x314]
    6312:	movabs r11,0x5b9960291750
    631c:	call   r11
    631f:	ldmxcsr DWORD PTR [r12-0x28]
    6325:	movdqu xmm2,XMMWORD PTR [rsp]
    632a:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6330:	mov    rbx,QWORD PTR [r12+0x108]
    6338:	mov    QWORD PTR [r12+0x378],0x2
    6344:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    634d:	movdqa xmm4,xmm0
    6351:	movdqa xmm0,xmm4
    6355:	movdqu XMMWORD PTR [r12+0x150],xmm0
    635f:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    6369:	movdqa xmm2,xmm0
    636d:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    6377:	movdqa xmm3,xmm0
    637b:	cmp    DWORD PTR [r12+0x310],0x0
    6384:	jne    0x6468
    638a:	movdqa xmm0,xmm2
    638e:	movdqa xmm1,xmm3
    6392:	movq   rax,xmm0
    6397:	add    rax,rax
    639a:	je     0x63b0
    639c:	shr    rax,0x35
    63a0:	sub    eax,0x201
    63a5:	cmp    eax,0x3fc
    63aa:	ja     0x6468
    63b0:	movdqa xmm14,xmm0
    63b5:	psrldq xmm14,0x8
    63bb:	movq   rax,xmm14
    63c0:	add    rax,rax
    63c3:	je     0x63d9
    63c5:	shr    rax,0x35
    63c9:	sub    eax,0x201
    63ce:	cmp    eax,0x3fc
    63d3:	ja     0x6468
    63d9:	movq   rax,xmm1
    63de:	add    rax,rax
    63e1:	je     0x63f7
    63e3:	shr    rax,0x35
    63e7:	sub    eax,0x201
    63ec:	cmp    eax,0x3fc
    63f1:	ja     0x6468
    63f7:	movdqa xmm14,xmm1
    63fc:	psrldq xmm14,0x8
    6402:	movq   rax,xmm14
    6407:	add    rax,rax
    640a:	je     0x6420
    640c:	shr    rax,0x35
    6410:	sub    eax,0x201
    6415:	cmp    eax,0x3fc
    641a:	ja     0x6468
    6420:	stmxcsr DWORD PTR [rsp+0x100]
    6428:	mov    DWORD PTR [rsp+0x104],0x1f80
    6433:	ldmxcsr DWORD PTR [rsp+0x104]
    643b:	addpd  xmm0,xmm1
    643f:	stmxcsr DWORD PTR [rsp+0x104]
    6447:	ldmxcsr DWORD PTR [rsp+0x100]
    644f:	mov    eax,DWORD PTR [rsp+0x104]
    6456:	shr    eax,1
    6458:	and    eax,0x10
    645b:	or     DWORD PTR [r12+0x314],eax
    6463:	jmp    0x6515
    6468:	movdqa xmm0,xmm2
    646c:	movdqa xmm1,xmm3
    6470:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6479:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6482:	mov    QWORD PTR [r12+0x378],0x3
    648e:	movdqu XMMWORD PTR [rsp],xmm2
    6493:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6499:	mov    QWORD PTR [r12+0x108],rbx
    64a1:	stmxcsr DWORD PTR [r12-0x28]
    64a7:	ldmxcsr DWORD PTR [r12-0x38]
    64ad:	lea    rdi,[rsp+0xf0]
    64b5:	lea    rsi,[rsp+0xd0]
    64bd:	lea    rdx,[rsp+0xe0]
    64c5:	mov    ecx,0x14
    64ca:	mov    r8d,DWORD PTR [r12+0x310]
    64d2:	lea    r9,[r12+0x314]
    64da:	movabs r11,0x5b9960291750
    64e4:	call   r11
    64e7:	ldmxcsr DWORD PTR [r12-0x28]
    64ed:	movdqu xmm2,XMMWORD PTR [rsp]
    64f2:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    64f8:	mov    rbx,QWORD PTR [r12+0x108]
    6500:	mov    QWORD PTR [r12+0x378],0x2
    650c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6515:	movdqa xmm4,xmm0
    6519:	movdqa xmm0,xmm4
    651d:	movdqu XMMWORD PTR [r12+0x160],xmm0
    6527:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    6531:	movdqa xmm2,xmm0
    6535:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    653f:	movdqa xmm3,xmm0
    6543:	cmp    DWORD PTR [r12+0x310],0x0
    654c:	jne    0x6635
    6552:	movdqa xmm0,xmm2
    6556:	movdqa xmm1,xmm3
    655a:	pshufd xmm1,xmm1,0x44
    655f:	movq   rax,xmm0
    6564:	add    rax,rax
    6567:	je     0x657d
    6569:	shr    rax,0x35
    656d:	sub    eax,0x201
    6572:	cmp    eax,0x3fc
    6577:	ja     0x6635
    657d:	movdqa xmm14,xmm0
    6582:	psrldq xmm14,0x8
    6588:	movq   rax,xmm14
    658d:	add    rax,rax
    6590:	je     0x65a6
    6592:	shr    rax,0x35
    6596:	sub    eax,0x201
    659b:	cmp    eax,0x3fc
    65a0:	ja     0x6635
    65a6:	movq   rax,xmm1
    65ab:	add    rax,rax
    65ae:	je     0x65c4
    65b0:	shr    rax,0x35
    65b4:	sub    eax,0x201
    65b9:	cmp    eax,0x3fc
    65be:	ja     0x6635
    65c4:	movdqa xmm14,xmm1
    65c9:	psrldq xmm14,0x8
    65cf:	movq   rax,xmm14
    65d4:	add    rax,rax
    65d7:	je     0x65ed
    65d9:	shr    rax,0x35
    65dd:	sub    eax,0x201
    65e2:	cmp    eax,0x3fc
    65e7:	ja     0x6635
    65ed:	stmxcsr DWORD PTR [rsp+0x100]
    65f5:	mov    DWORD PTR [rsp+0x104],0x1f80
    6600:	ldmxcsr DWORD PTR [rsp+0x104]
    6608:	mulpd  xmm0,xmm1
    660c:	stmxcsr DWORD PTR [rsp+0x104]
    6614:	ldmxcsr DWORD PTR [rsp+0x100]
    661c:	mov    eax,DWORD PTR [rsp+0x104]
    6623:	shr    eax,1
    6625:	and    eax,0x10
    6628:	or     DWORD PTR [r12+0x314],eax
    6630:	jmp    0x66e2
    6635:	movdqa xmm0,xmm2
    6639:	movdqa xmm1,xmm3
    663d:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6646:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    664f:	mov    QWORD PTR [r12+0x378],0x3
    665b:	movdqu XMMWORD PTR [rsp],xmm2
    6660:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6666:	mov    QWORD PTR [r12+0x108],rbx
    666e:	stmxcsr DWORD PTR [r12-0x28]
    6674:	ldmxcsr DWORD PTR [r12-0x38]
    667a:	lea    rdi,[rsp+0xf0]
    6682:	lea    rsi,[rsp+0xd0]
    668a:	lea    rdx,[rsp+0xe0]
    6692:	mov    ecx,0x56
    6697:	mov    r8d,DWORD PTR [r12+0x310]
    669f:	lea    r9,[r12+0x314]
    66a7:	movabs r11,0x5b9960291750
    66b1:	call   r11
    66b4:	ldmxcsr DWORD PTR [r12-0x28]
    66ba:	movdqu xmm2,XMMWORD PTR [rsp]
    66bf:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    66c5:	mov    rbx,QWORD PTR [r12+0x108]
    66cd:	mov    QWORD PTR [r12+0x378],0x2
    66d9:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    66e2:	movdqa xmm4,xmm0
    66e6:	movdqa xmm0,xmm4
    66ea:	movdqu XMMWORD PTR [r12+0x240],xmm0
    66f4:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    66fe:	movdqa xmm2,xmm0
    6702:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    670c:	movdqa xmm3,xmm0
    6710:	cmp    DWORD PTR [r12+0x310],0x0
    6719:	jne    0x6802
    671f:	movdqa xmm0,xmm2
    6723:	movdqa xmm1,xmm3
    6727:	pshufd xmm1,xmm1,0x44
    672c:	movq   rax,xmm0
    6731:	add    rax,rax
    6734:	je     0x674a
    6736:	shr    rax,0x35
    673a:	sub    eax,0x201
    673f:	cmp    eax,0x3fc
    6744:	ja     0x6802
    674a:	movdqa xmm14,xmm0
    674f:	psrldq xmm14,0x8
    6755:	movq   rax,xmm14
    675a:	add    rax,rax
    675d:	je     0x6773
    675f:	shr    rax,0x35
    6763:	sub    eax,0x201
    6768:	cmp    eax,0x3fc
    676d:	ja     0x6802
    6773:	movq   rax,xmm1
    6778:	add    rax,rax
    677b:	je     0x6791
    677d:	shr    rax,0x35
    6781:	sub    eax,0x201
    6786:	cmp    eax,0x3fc
    678b:	ja     0x6802
    6791:	movdqa xmm14,xmm1
    6796:	psrldq xmm14,0x8
    679c:	movq   rax,xmm14
    67a1:	add    rax,rax
    67a4:	je     0x67ba
    67a6:	shr    rax,0x35
    67aa:	sub    eax,0x201
    67af:	cmp    eax,0x3fc
    67b4:	ja     0x6802
    67ba:	stmxcsr DWORD PTR [rsp+0x100]
    67c2:	mov    DWORD PTR [rsp+0x104],0x1f80
    67cd:	ldmxcsr DWORD PTR [rsp+0x104]
    67d5:	mulpd  xmm0,xmm1
    67d9:	stmxcsr DWORD PTR [rsp+0x104]
    67e1:	ldmxcsr DWORD PTR [rsp+0x100]
    67e9:	mov    eax,DWORD PTR [rsp+0x104]
    67f0:	shr    eax,1
    67f2:	and    eax,0x10
    67f5:	or     DWORD PTR [r12+0x314],eax
    67fd:	jmp    0x68af
    6802:	movdqa xmm0,xmm2
    6806:	movdqa xmm1,xmm3
    680a:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6813:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    681c:	mov    QWORD PTR [r12+0x378],0x3
    6828:	movdqu XMMWORD PTR [rsp],xmm2
    682d:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6833:	mov    QWORD PTR [r12+0x108],rbx
    683b:	stmxcsr DWORD PTR [r12-0x28]
    6841:	ldmxcsr DWORD PTR [r12-0x38]
    6847:	lea    rdi,[rsp+0xf0]
    684f:	lea    rsi,[rsp+0xd0]
    6857:	lea    rdx,[rsp+0xe0]
    685f:	mov    ecx,0x56
    6864:	mov    r8d,DWORD PTR [r12+0x310]
    686c:	lea    r9,[r12+0x314]
    6874:	movabs r11,0x5b9960291750
    687e:	call   r11
    6881:	ldmxcsr DWORD PTR [r12-0x28]
    6887:	movdqu xmm2,XMMWORD PTR [rsp]
    688c:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6892:	mov    rbx,QWORD PTR [r12+0x108]
    689a:	mov    QWORD PTR [r12+0x378],0x2
    68a6:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    68af:	movdqa xmm4,xmm0
    68b3:	movdqa xmm0,xmm4
    68b7:	movdqu XMMWORD PTR [r12+0x140],xmm0
    68c1:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    68cb:	movdqa xmm2,xmm0
    68cf:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    68d9:	movdqa xmm3,xmm0
    68dd:	cmp    DWORD PTR [r12+0x310],0x0
    68e6:	jne    0x69cf
    68ec:	movdqa xmm0,xmm2
    68f0:	movdqa xmm1,xmm3
    68f4:	pshufd xmm1,xmm1,0x44
    68f9:	movq   rax,xmm0
    68fe:	add    rax,rax
    6901:	je     0x6917
    6903:	shr    rax,0x35
    6907:	sub    eax,0x201
    690c:	cmp    eax,0x3fc
    6911:	ja     0x69cf
    6917:	movdqa xmm14,xmm0
    691c:	psrldq xmm14,0x8
    6922:	movq   rax,xmm14
    6927:	add    rax,rax
    692a:	je     0x6940
    692c:	shr    rax,0x35
    6930:	sub    eax,0x201
    6935:	cmp    eax,0x3fc
    693a:	ja     0x69cf
    6940:	movq   rax,xmm1
    6945:	add    rax,rax
    6948:	je     0x695e
    694a:	shr    rax,0x35
    694e:	sub    eax,0x201
    6953:	cmp    eax,0x3fc
    6958:	ja     0x69cf
    695e:	movdqa xmm14,xmm1
    6963:	psrldq xmm14,0x8
    6969:	movq   rax,xmm14
    696e:	add    rax,rax
    6971:	je     0x6987
    6973:	shr    rax,0x35
    6977:	sub    eax,0x201
    697c:	cmp    eax,0x3fc
    6981:	ja     0x69cf
    6987:	stmxcsr DWORD PTR [rsp+0x100]
    698f:	mov    DWORD PTR [rsp+0x104],0x1f80
    699a:	ldmxcsr DWORD PTR [rsp+0x104]
    69a2:	mulpd  xmm0,xmm1
    69a6:	stmxcsr DWORD PTR [rsp+0x104]
    69ae:	ldmxcsr DWORD PTR [rsp+0x100]
    69b6:	mov    eax,DWORD PTR [rsp+0x104]
    69bd:	shr    eax,1
    69bf:	and    eax,0x10
    69c2:	or     DWORD PTR [r12+0x314],eax
    69ca:	jmp    0x6a7c
    69cf:	movdqa xmm0,xmm2
    69d3:	movdqa xmm1,xmm3
    69d7:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    69e0:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    69e9:	mov    QWORD PTR [r12+0x378],0x3
    69f5:	movdqu XMMWORD PTR [rsp],xmm2
    69fa:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6a00:	mov    QWORD PTR [r12+0x108],rbx
    6a08:	stmxcsr DWORD PTR [r12-0x28]
    6a0e:	ldmxcsr DWORD PTR [r12-0x38]
    6a14:	lea    rdi,[rsp+0xf0]
    6a1c:	lea    rsi,[rsp+0xd0]
    6a24:	lea    rdx,[rsp+0xe0]
    6a2c:	mov    ecx,0x56
    6a31:	mov    r8d,DWORD PTR [r12+0x310]
    6a39:	lea    r9,[r12+0x314]
    6a41:	movabs r11,0x5b9960291750
    6a4b:	call   r11
    6a4e:	ldmxcsr DWORD PTR [r12-0x28]
    6a54:	movdqu xmm2,XMMWORD PTR [rsp]
    6a59:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6a5f:	mov    rbx,QWORD PTR [r12+0x108]
    6a67:	mov    QWORD PTR [r12+0x378],0x2
    6a73:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6a7c:	movdqa xmm4,xmm0
    6a80:	movdqa xmm0,xmm4
    6a84:	movdqu XMMWORD PTR [r12+0x170],xmm0
    6a8e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    6a98:	movdqa xmm2,xmm0
    6a9c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    6aa6:	movdqa xmm3,xmm0
    6aaa:	cmp    DWORD PTR [r12+0x310],0x0
    6ab3:	jne    0x6b97
    6ab9:	movdqa xmm0,xmm2
    6abd:	movdqa xmm1,xmm3
    6ac1:	movq   rax,xmm0
    6ac6:	add    rax,rax
    6ac9:	je     0x6adf
    6acb:	shr    rax,0x35
    6acf:	sub    eax,0x201
    6ad4:	cmp    eax,0x3fc
    6ad9:	ja     0x6b97
    6adf:	movdqa xmm14,xmm0
    6ae4:	psrldq xmm14,0x8
    6aea:	movq   rax,xmm14
    6aef:	add    rax,rax
    6af2:	je     0x6b08
    6af4:	shr    rax,0x35
    6af8:	sub    eax,0x201
    6afd:	cmp    eax,0x3fc
    6b02:	ja     0x6b97
    6b08:	movq   rax,xmm1
    6b0d:	add    rax,rax
    6b10:	je     0x6b26
    6b12:	shr    rax,0x35
    6b16:	sub    eax,0x201
    6b1b:	cmp    eax,0x3fc
    6b20:	ja     0x6b97
    6b26:	movdqa xmm14,xmm1
    6b2b:	psrldq xmm14,0x8
    6b31:	movq   rax,xmm14
    6b36:	add    rax,rax
    6b39:	je     0x6b4f
    6b3b:	shr    rax,0x35
    6b3f:	sub    eax,0x201
    6b44:	cmp    eax,0x3fc
    6b49:	ja     0x6b97
    6b4f:	stmxcsr DWORD PTR [rsp+0x100]
    6b57:	mov    DWORD PTR [rsp+0x104],0x1f80
    6b62:	ldmxcsr DWORD PTR [rsp+0x104]
    6b6a:	addpd  xmm0,xmm1
    6b6e:	stmxcsr DWORD PTR [rsp+0x104]
    6b76:	ldmxcsr DWORD PTR [rsp+0x100]
    6b7e:	mov    eax,DWORD PTR [rsp+0x104]
    6b85:	shr    eax,1
    6b87:	and    eax,0x10
    6b8a:	or     DWORD PTR [r12+0x314],eax
    6b92:	jmp    0x6c44
    6b97:	movdqa xmm0,xmm2
    6b9b:	movdqa xmm1,xmm3
    6b9f:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6ba8:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6bb1:	mov    QWORD PTR [r12+0x378],0x3
    6bbd:	movdqu XMMWORD PTR [rsp],xmm2
    6bc2:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6bc8:	mov    QWORD PTR [r12+0x108],rbx
    6bd0:	stmxcsr DWORD PTR [r12-0x28]
    6bd6:	ldmxcsr DWORD PTR [r12-0x38]
    6bdc:	lea    rdi,[rsp+0xf0]
    6be4:	lea    rsi,[rsp+0xd0]
    6bec:	lea    rdx,[rsp+0xe0]
    6bf4:	mov    ecx,0x14
    6bf9:	mov    r8d,DWORD PTR [r12+0x310]
    6c01:	lea    r9,[r12+0x314]
    6c09:	movabs r11,0x5b9960291750
    6c13:	call   r11
    6c16:	ldmxcsr DWORD PTR [r12-0x28]
    6c1c:	movdqu xmm2,XMMWORD PTR [rsp]
    6c21:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6c27:	mov    rbx,QWORD PTR [r12+0x108]
    6c2f:	mov    QWORD PTR [r12+0x378],0x2
    6c3b:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6c44:	movdqa xmm4,xmm0
    6c48:	movdqa xmm0,xmm4
    6c4c:	movdqu XMMWORD PTR [r12+0x180],xmm0
    6c56:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    6c60:	movdqa xmm2,xmm0
    6c64:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    6c6e:	movdqa xmm3,xmm0
    6c72:	cmp    DWORD PTR [r12+0x310],0x0
    6c7b:	jne    0x6d64
    6c81:	movdqa xmm0,xmm2
    6c85:	movdqa xmm1,xmm3
    6c89:	pshufd xmm1,xmm1,0x44
    6c8e:	movq   rax,xmm0
    6c93:	add    rax,rax
    6c96:	je     0x6cac
    6c98:	shr    rax,0x35
    6c9c:	sub    eax,0x201
    6ca1:	cmp    eax,0x3fc
    6ca6:	ja     0x6d64
    6cac:	movdqa xmm14,xmm0
    6cb1:	psrldq xmm14,0x8
    6cb7:	movq   rax,xmm14
    6cbc:	add    rax,rax
    6cbf:	je     0x6cd5
    6cc1:	shr    rax,0x35
    6cc5:	sub    eax,0x201
    6cca:	cmp    eax,0x3fc
    6ccf:	ja     0x6d64
    6cd5:	movq   rax,xmm1
    6cda:	add    rax,rax
    6cdd:	je     0x6cf3
    6cdf:	shr    rax,0x35
    6ce3:	sub    eax,0x201
    6ce8:	cmp    eax,0x3fc
    6ced:	ja     0x6d64
    6cf3:	movdqa xmm14,xmm1
    6cf8:	psrldq xmm14,0x8
    6cfe:	movq   rax,xmm14
    6d03:	add    rax,rax
    6d06:	je     0x6d1c
    6d08:	shr    rax,0x35
    6d0c:	sub    eax,0x201
    6d11:	cmp    eax,0x3fc
    6d16:	ja     0x6d64
    6d1c:	stmxcsr DWORD PTR [rsp+0x100]
    6d24:	mov    DWORD PTR [rsp+0x104],0x1f80
    6d2f:	ldmxcsr DWORD PTR [rsp+0x104]
    6d37:	mulpd  xmm0,xmm1
    6d3b:	stmxcsr DWORD PTR [rsp+0x104]
    6d43:	ldmxcsr DWORD PTR [rsp+0x100]
    6d4b:	mov    eax,DWORD PTR [rsp+0x104]
    6d52:	shr    eax,1
    6d54:	and    eax,0x10
    6d57:	or     DWORD PTR [r12+0x314],eax
    6d5f:	jmp    0x6e11
    6d64:	movdqa xmm0,xmm2
    6d68:	movdqa xmm1,xmm3
    6d6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6d75:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6d7e:	mov    QWORD PTR [r12+0x378],0x3
    6d8a:	movdqu XMMWORD PTR [rsp],xmm2
    6d8f:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6d95:	mov    QWORD PTR [r12+0x108],rbx
    6d9d:	stmxcsr DWORD PTR [r12-0x28]
    6da3:	ldmxcsr DWORD PTR [r12-0x38]
    6da9:	lea    rdi,[rsp+0xf0]
    6db1:	lea    rsi,[rsp+0xd0]
    6db9:	lea    rdx,[rsp+0xe0]
    6dc1:	mov    ecx,0x56
    6dc6:	mov    r8d,DWORD PTR [r12+0x310]
    6dce:	lea    r9,[r12+0x314]
    6dd6:	movabs r11,0x5b9960291750
    6de0:	call   r11
    6de3:	ldmxcsr DWORD PTR [r12-0x28]
    6de9:	movdqu xmm2,XMMWORD PTR [rsp]
    6dee:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6df4:	mov    rbx,QWORD PTR [r12+0x108]
    6dfc:	mov    QWORD PTR [r12+0x378],0x2
    6e08:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6e11:	movdqa xmm4,xmm0
    6e15:	movdqa xmm0,xmm4
    6e19:	movdqu XMMWORD PTR [r12+0x210],xmm0
    6e23:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    6e2d:	movdqa xmm2,xmm0
    6e31:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    6e3b:	movdqa xmm3,xmm0
    6e3f:	cmp    DWORD PTR [r12+0x310],0x0
    6e48:	jne    0x6f2c
    6e4e:	movdqa xmm0,xmm2
    6e52:	movdqa xmm1,xmm3
    6e56:	movq   rax,xmm0
    6e5b:	add    rax,rax
    6e5e:	je     0x6e74
    6e60:	shr    rax,0x35
    6e64:	sub    eax,0x201
    6e69:	cmp    eax,0x3fc
    6e6e:	ja     0x6f2c
    6e74:	movdqa xmm14,xmm0
    6e79:	psrldq xmm14,0x8
    6e7f:	movq   rax,xmm14
    6e84:	add    rax,rax
    6e87:	je     0x6e9d
    6e89:	shr    rax,0x35
    6e8d:	sub    eax,0x201
    6e92:	cmp    eax,0x3fc
    6e97:	ja     0x6f2c
    6e9d:	movq   rax,xmm1
    6ea2:	add    rax,rax
    6ea5:	je     0x6ebb
    6ea7:	shr    rax,0x35
    6eab:	sub    eax,0x201
    6eb0:	cmp    eax,0x3fc
    6eb5:	ja     0x6f2c
    6ebb:	movdqa xmm14,xmm1
    6ec0:	psrldq xmm14,0x8
    6ec6:	movq   rax,xmm14
    6ecb:	add    rax,rax
    6ece:	je     0x6ee4
    6ed0:	shr    rax,0x35
    6ed4:	sub    eax,0x201
    6ed9:	cmp    eax,0x3fc
    6ede:	ja     0x6f2c
    6ee4:	stmxcsr DWORD PTR [rsp+0x100]
    6eec:	mov    DWORD PTR [rsp+0x104],0x1f80
    6ef7:	ldmxcsr DWORD PTR [rsp+0x104]
    6eff:	addpd  xmm0,xmm1
    6f03:	stmxcsr DWORD PTR [rsp+0x104]
    6f0b:	ldmxcsr DWORD PTR [rsp+0x100]
    6f13:	mov    eax,DWORD PTR [rsp+0x104]
    6f1a:	shr    eax,1
    6f1c:	and    eax,0x10
    6f1f:	or     DWORD PTR [r12+0x314],eax
    6f27:	jmp    0x6fd9
    6f2c:	movdqa xmm0,xmm2
    6f30:	movdqa xmm1,xmm3
    6f34:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6f3d:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6f46:	mov    QWORD PTR [r12+0x378],0x3
    6f52:	movdqu XMMWORD PTR [rsp],xmm2
    6f57:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6f5d:	mov    QWORD PTR [r12+0x108],rbx
    6f65:	stmxcsr DWORD PTR [r12-0x28]
    6f6b:	ldmxcsr DWORD PTR [r12-0x38]
    6f71:	lea    rdi,[rsp+0xf0]
    6f79:	lea    rsi,[rsp+0xd0]
    6f81:	lea    rdx,[rsp+0xe0]
    6f89:	mov    ecx,0x14
    6f8e:	mov    r8d,DWORD PTR [r12+0x310]
    6f96:	lea    r9,[r12+0x314]
    6f9e:	movabs r11,0x5b9960291750
    6fa8:	call   r11
    6fab:	ldmxcsr DWORD PTR [r12-0x28]
    6fb1:	movdqu xmm2,XMMWORD PTR [rsp]
    6fb6:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6fbc:	mov    rbx,QWORD PTR [r12+0x108]
    6fc4:	mov    QWORD PTR [r12+0x378],0x2
    6fd0:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6fd9:	movdqa xmm4,xmm0
    6fdd:	movdqa xmm0,xmm4
    6fe1:	movdqu XMMWORD PTR [r12+0x220],xmm0
    6feb:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    6ff5:	movdqa xmm2,xmm0
    6ff9:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7003:	movdqa xmm3,xmm0
    7007:	cmp    DWORD PTR [r12+0x310],0x0
    7010:	jne    0x70f9
    7016:	movdqa xmm0,xmm2
    701a:	movdqa xmm1,xmm3
    701e:	pshufd xmm1,xmm1,0x44
    7023:	movq   rax,xmm0
    7028:	add    rax,rax
    702b:	je     0x7041
    702d:	shr    rax,0x35
    7031:	sub    eax,0x201
    7036:	cmp    eax,0x3fc
    703b:	ja     0x70f9
    7041:	movdqa xmm14,xmm0
    7046:	psrldq xmm14,0x8
    704c:	movq   rax,xmm14
    7051:	add    rax,rax
    7054:	je     0x706a
    7056:	shr    rax,0x35
    705a:	sub    eax,0x201
    705f:	cmp    eax,0x3fc
    7064:	ja     0x70f9
    706a:	movq   rax,xmm1
    706f:	add    rax,rax
    7072:	je     0x7088
    7074:	shr    rax,0x35
    7078:	sub    eax,0x201
    707d:	cmp    eax,0x3fc
    7082:	ja     0x70f9
    7088:	movdqa xmm14,xmm1
    708d:	psrldq xmm14,0x8
    7093:	movq   rax,xmm14
    7098:	add    rax,rax
    709b:	je     0x70b1
    709d:	shr    rax,0x35
    70a1:	sub    eax,0x201
    70a6:	cmp    eax,0x3fc
    70ab:	ja     0x70f9
    70b1:	stmxcsr DWORD PTR [rsp+0x100]
    70b9:	mov    DWORD PTR [rsp+0x104],0x1f80
    70c4:	ldmxcsr DWORD PTR [rsp+0x104]
    70cc:	mulpd  xmm0,xmm1
    70d0:	stmxcsr DWORD PTR [rsp+0x104]
    70d8:	ldmxcsr DWORD PTR [rsp+0x100]
    70e0:	mov    eax,DWORD PTR [rsp+0x104]
    70e7:	shr    eax,1
    70e9:	and    eax,0x10
    70ec:	or     DWORD PTR [r12+0x314],eax
    70f4:	jmp    0x71a6
    70f9:	movdqa xmm0,xmm2
    70fd:	movdqa xmm1,xmm3
    7101:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    710a:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7113:	mov    QWORD PTR [r12+0x378],0x3
    711f:	movdqu XMMWORD PTR [rsp],xmm2
    7124:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    712a:	mov    QWORD PTR [r12+0x108],rbx
    7132:	stmxcsr DWORD PTR [r12-0x28]
    7138:	ldmxcsr DWORD PTR [r12-0x38]
    713e:	lea    rdi,[rsp+0xf0]
    7146:	lea    rsi,[rsp+0xd0]
    714e:	lea    rdx,[rsp+0xe0]
    7156:	mov    ecx,0x56
    715b:	mov    r8d,DWORD PTR [r12+0x310]
    7163:	lea    r9,[r12+0x314]
    716b:	movabs r11,0x5b9960291750
    7175:	call   r11
    7178:	ldmxcsr DWORD PTR [r12-0x28]
    717e:	movdqu xmm2,XMMWORD PTR [rsp]
    7183:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7189:	mov    rbx,QWORD PTR [r12+0x108]
    7191:	mov    QWORD PTR [r12+0x378],0x2
    719d:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    71a6:	movdqa xmm4,xmm0
    71aa:	movdqa xmm0,xmm4
    71ae:	movdqu XMMWORD PTR [r12+0x230],xmm0
    71b8:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    71c2:	movdqa xmm2,xmm0
    71c6:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    71d0:	movdqa xmm3,xmm0
    71d4:	cmp    DWORD PTR [r12+0x310],0x0
    71dd:	jne    0x72c1
    71e3:	movdqa xmm0,xmm2
    71e7:	movdqa xmm1,xmm3
    71eb:	movq   rax,xmm0
    71f0:	add    rax,rax
    71f3:	je     0x7209
    71f5:	shr    rax,0x35
    71f9:	sub    eax,0x201
    71fe:	cmp    eax,0x3fc
    7203:	ja     0x72c1
    7209:	movdqa xmm14,xmm0
    720e:	psrldq xmm14,0x8
    7214:	movq   rax,xmm14
    7219:	add    rax,rax
    721c:	je     0x7232
    721e:	shr    rax,0x35
    7222:	sub    eax,0x201
    7227:	cmp    eax,0x3fc
    722c:	ja     0x72c1
    7232:	movq   rax,xmm1
    7237:	add    rax,rax
    723a:	je     0x7250
    723c:	shr    rax,0x35
    7240:	sub    eax,0x201
    7245:	cmp    eax,0x3fc
    724a:	ja     0x72c1
    7250:	movdqa xmm14,xmm1
    7255:	psrldq xmm14,0x8
    725b:	movq   rax,xmm14
    7260:	add    rax,rax
    7263:	je     0x7279
    7265:	shr    rax,0x35
    7269:	sub    eax,0x201
    726e:	cmp    eax,0x3fc
    7273:	ja     0x72c1
    7279:	stmxcsr DWORD PTR [rsp+0x100]
    7281:	mov    DWORD PTR [rsp+0x104],0x1f80
    728c:	ldmxcsr DWORD PTR [rsp+0x104]
    7294:	addpd  xmm0,xmm1
    7298:	stmxcsr DWORD PTR [rsp+0x104]
    72a0:	ldmxcsr DWORD PTR [rsp+0x100]
    72a8:	mov    eax,DWORD PTR [rsp+0x104]
    72af:	shr    eax,1
    72b1:	and    eax,0x10
    72b4:	or     DWORD PTR [r12+0x314],eax
    72bc:	jmp    0x736e
    72c1:	movdqa xmm0,xmm2
    72c5:	movdqa xmm1,xmm3
    72c9:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    72d2:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    72db:	mov    QWORD PTR [r12+0x378],0x3
    72e7:	movdqu XMMWORD PTR [rsp],xmm2
    72ec:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    72f2:	mov    QWORD PTR [r12+0x108],rbx
    72fa:	stmxcsr DWORD PTR [r12-0x28]
    7300:	ldmxcsr DWORD PTR [r12-0x38]
    7306:	lea    rdi,[rsp+0xf0]
    730e:	lea    rsi,[rsp+0xd0]
    7316:	lea    rdx,[rsp+0xe0]
    731e:	mov    ecx,0x14
    7323:	mov    r8d,DWORD PTR [r12+0x310]
    732b:	lea    r9,[r12+0x314]
    7333:	movabs r11,0x5b9960291750
    733d:	call   r11
    7340:	ldmxcsr DWORD PTR [r12-0x28]
    7346:	movdqu xmm2,XMMWORD PTR [rsp]
    734b:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7351:	mov    rbx,QWORD PTR [r12+0x108]
    7359:	mov    QWORD PTR [r12+0x378],0x2
    7365:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    736e:	movdqa xmm4,xmm0
    7372:	movdqa xmm0,xmm4
    7376:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7380:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    738a:	movdqa xmm2,xmm0
    738e:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7398:	movdqa xmm3,xmm0
    739c:	cmp    DWORD PTR [r12+0x310],0x0
    73a5:	jne    0x748e
    73ab:	movdqa xmm0,xmm2
    73af:	movdqa xmm1,xmm3
    73b3:	pshufd xmm1,xmm1,0x44
    73b8:	movq   rax,xmm0
    73bd:	add    rax,rax
    73c0:	je     0x73d6
    73c2:	shr    rax,0x35
    73c6:	sub    eax,0x201
    73cb:	cmp    eax,0x3fc
    73d0:	ja     0x748e
    73d6:	movdqa xmm14,xmm0
    73db:	psrldq xmm14,0x8
    73e1:	movq   rax,xmm14
    73e6:	add    rax,rax
    73e9:	je     0x73ff
    73eb:	shr    rax,0x35
    73ef:	sub    eax,0x201
    73f4:	cmp    eax,0x3fc
    73f9:	ja     0x748e
    73ff:	movq   rax,xmm1
    7404:	add    rax,rax
    7407:	je     0x741d
    7409:	shr    rax,0x35
    740d:	sub    eax,0x201
    7412:	cmp    eax,0x3fc
    7417:	ja     0x748e
    741d:	movdqa xmm14,xmm1
    7422:	psrldq xmm14,0x8
    7428:	movq   rax,xmm14
    742d:	add    rax,rax
    7430:	je     0x7446
    7432:	shr    rax,0x35
    7436:	sub    eax,0x201
    743b:	cmp    eax,0x3fc
    7440:	ja     0x748e
    7446:	stmxcsr DWORD PTR [rsp+0x100]
    744e:	mov    DWORD PTR [rsp+0x104],0x1f80
    7459:	ldmxcsr DWORD PTR [rsp+0x104]
    7461:	mulpd  xmm0,xmm1
    7465:	stmxcsr DWORD PTR [rsp+0x104]
    746d:	ldmxcsr DWORD PTR [rsp+0x100]
    7475:	mov    eax,DWORD PTR [rsp+0x104]
    747c:	shr    eax,1
    747e:	and    eax,0x10
    7481:	or     DWORD PTR [r12+0x314],eax
    7489:	jmp    0x753b
    748e:	movdqa xmm0,xmm2
    7492:	movdqa xmm1,xmm3
    7496:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    749f:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    74a8:	mov    QWORD PTR [r12+0x378],0x3
    74b4:	movdqu XMMWORD PTR [rsp],xmm2
    74b9:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    74bf:	mov    QWORD PTR [r12+0x108],rbx
    74c7:	stmxcsr DWORD PTR [r12-0x28]
    74cd:	ldmxcsr DWORD PTR [r12-0x38]
    74d3:	lea    rdi,[rsp+0xf0]
    74db:	lea    rsi,[rsp+0xd0]
    74e3:	lea    rdx,[rsp+0xe0]
    74eb:	mov    ecx,0x56
    74f0:	mov    r8d,DWORD PTR [r12+0x310]
    74f8:	lea    r9,[r12+0x314]
    7500:	movabs r11,0x5b9960291750
    750a:	call   r11
    750d:	ldmxcsr DWORD PTR [r12-0x28]
    7513:	movdqu xmm2,XMMWORD PTR [rsp]
    7518:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    751e:	mov    rbx,QWORD PTR [r12+0x108]
    7526:	mov    QWORD PTR [r12+0x378],0x2
    7532:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    753b:	movdqa xmm4,xmm0
    753f:	movdqa xmm0,xmm4
    7543:	movdqu XMMWORD PTR [r12+0x130],xmm0
    754d:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7557:	movdqa xmm2,xmm0
    755b:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7565:	movdqa xmm3,xmm0
    7569:	cmp    DWORD PTR [r12+0x310],0x0
    7572:	jne    0x7656
    7578:	movdqa xmm0,xmm2
    757c:	movdqa xmm1,xmm3
    7580:	movq   rax,xmm0
    7585:	add    rax,rax
    7588:	je     0x759e
    758a:	shr    rax,0x35
    758e:	sub    eax,0x201
    7593:	cmp    eax,0x3fc
    7598:	ja     0x7656
    759e:	movdqa xmm14,xmm0
    75a3:	psrldq xmm14,0x8
    75a9:	movq   rax,xmm14
    75ae:	add    rax,rax
    75b1:	je     0x75c7
    75b3:	shr    rax,0x35
    75b7:	sub    eax,0x201
    75bc:	cmp    eax,0x3fc
    75c1:	ja     0x7656
    75c7:	movq   rax,xmm1
    75cc:	add    rax,rax
    75cf:	je     0x75e5
    75d1:	shr    rax,0x35
    75d5:	sub    eax,0x201
    75da:	cmp    eax,0x3fc
    75df:	ja     0x7656
    75e5:	movdqa xmm14,xmm1
    75ea:	psrldq xmm14,0x8
    75f0:	movq   rax,xmm14
    75f5:	add    rax,rax
    75f8:	je     0x760e
    75fa:	shr    rax,0x35
    75fe:	sub    eax,0x201
    7603:	cmp    eax,0x3fc
    7608:	ja     0x7656
    760e:	stmxcsr DWORD PTR [rsp+0x100]
    7616:	mov    DWORD PTR [rsp+0x104],0x1f80
    7621:	ldmxcsr DWORD PTR [rsp+0x104]
    7629:	addpd  xmm0,xmm1
    762d:	stmxcsr DWORD PTR [rsp+0x104]
    7635:	ldmxcsr DWORD PTR [rsp+0x100]
    763d:	mov    eax,DWORD PTR [rsp+0x104]
    7644:	shr    eax,1
    7646:	and    eax,0x10
    7649:	or     DWORD PTR [r12+0x314],eax
    7651:	jmp    0x7703
    7656:	movdqa xmm0,xmm2
    765a:	movdqa xmm1,xmm3
    765e:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7667:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7670:	mov    QWORD PTR [r12+0x378],0x3
    767c:	movdqu XMMWORD PTR [rsp],xmm2
    7681:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7687:	mov    QWORD PTR [r12+0x108],rbx
    768f:	stmxcsr DWORD PTR [r12-0x28]
    7695:	ldmxcsr DWORD PTR [r12-0x38]
    769b:	lea    rdi,[rsp+0xf0]
    76a3:	lea    rsi,[rsp+0xd0]
    76ab:	lea    rdx,[rsp+0xe0]
    76b3:	mov    ecx,0x14
    76b8:	mov    r8d,DWORD PTR [r12+0x310]
    76c0:	lea    r9,[r12+0x314]
    76c8:	movabs r11,0x5b9960291750
    76d2:	call   r11
    76d5:	ldmxcsr DWORD PTR [r12-0x28]
    76db:	movdqu xmm2,XMMWORD PTR [rsp]
    76e0:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    76e6:	mov    rbx,QWORD PTR [r12+0x108]
    76ee:	mov    QWORD PTR [r12+0x378],0x2
    76fa:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7703:	movdqa xmm4,xmm0
    7707:	movdqa xmm0,xmm4
    770b:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7715:	mov    r13,QWORD PTR [r12+0xf8]
    771d:	mov    r14,r13
    7720:	add    r14,0x70
    7724:	movdqu xmm2,XMMWORD PTR [r14]
    7729:	movdqa xmm0,xmm2
    772d:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7737:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7741:	movdqa xmm2,xmm0
    7745:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    774f:	movdqa xmm3,xmm0
    7753:	cmp    DWORD PTR [r12+0x310],0x0
    775c:	jne    0x7840
    7762:	movdqa xmm0,xmm2
    7766:	movdqa xmm1,xmm3
    776a:	movq   rax,xmm0
    776f:	add    rax,rax
    7772:	je     0x7788
    7774:	shr    rax,0x35
    7778:	sub    eax,0x201
    777d:	cmp    eax,0x3fc
    7782:	ja     0x7840
    7788:	movdqa xmm14,xmm0
    778d:	psrldq xmm14,0x8
    7793:	movq   rax,xmm14
    7798:	add    rax,rax
    779b:	je     0x77b1
    779d:	shr    rax,0x35
    77a1:	sub    eax,0x201
    77a6:	cmp    eax,0x3fc
    77ab:	ja     0x7840
    77b1:	movq   rax,xmm1
    77b6:	add    rax,rax
    77b9:	je     0x77cf
    77bb:	shr    rax,0x35
    77bf:	sub    eax,0x201
    77c4:	cmp    eax,0x3fc
    77c9:	ja     0x7840
    77cf:	movdqa xmm14,xmm1
    77d4:	psrldq xmm14,0x8
    77da:	movq   rax,xmm14
    77df:	add    rax,rax
    77e2:	je     0x77f8
    77e4:	shr    rax,0x35
    77e8:	sub    eax,0x201
    77ed:	cmp    eax,0x3fc
    77f2:	ja     0x7840
    77f8:	stmxcsr DWORD PTR [rsp+0x100]
    7800:	mov    DWORD PTR [rsp+0x104],0x1f80
    780b:	ldmxcsr DWORD PTR [rsp+0x104]
    7813:	addpd  xmm0,xmm1
    7817:	stmxcsr DWORD PTR [rsp+0x104]
    781f:	ldmxcsr DWORD PTR [rsp+0x100]
    7827:	mov    eax,DWORD PTR [rsp+0x104]
    782e:	shr    eax,1
    7830:	and    eax,0x10
    7833:	or     DWORD PTR [r12+0x314],eax
    783b:	jmp    0x78ed
    7840:	movdqa xmm0,xmm2
    7844:	movdqa xmm1,xmm3
    7848:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7851:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    785a:	mov    QWORD PTR [r12+0x378],0x3
    7866:	movdqu XMMWORD PTR [rsp],xmm2
    786b:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7871:	mov    QWORD PTR [r12+0x108],rbx
    7879:	stmxcsr DWORD PTR [r12-0x28]
    787f:	ldmxcsr DWORD PTR [r12-0x38]
    7885:	lea    rdi,[rsp+0xf0]
    788d:	lea    rsi,[rsp+0xd0]
    7895:	lea    rdx,[rsp+0xe0]
    789d:	mov    ecx,0x14
    78a2:	mov    r8d,DWORD PTR [r12+0x310]
    78aa:	lea    r9,[r12+0x314]
    78b2:	movabs r11,0x5b9960291750
    78bc:	call   r11
    78bf:	ldmxcsr DWORD PTR [r12-0x28]
    78c5:	movdqu xmm2,XMMWORD PTR [rsp]
    78ca:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    78d0:	mov    rbx,QWORD PTR [r12+0x108]
    78d8:	mov    QWORD PTR [r12+0x378],0x2
    78e4:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    78ed:	movdqa xmm4,xmm0
    78f1:	movdqa xmm0,xmm4
    78f5:	movdqu XMMWORD PTR [r12+0x170],xmm0
    78ff:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7909:	movdqa xmm2,xmm0
    790d:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7917:	movdqa xmm3,xmm0
    791b:	cmp    DWORD PTR [r12+0x310],0x0
    7924:	jne    0x7a0d
    792a:	movdqa xmm0,xmm2
    792e:	movdqa xmm1,xmm3
    7932:	pshufd xmm1,xmm1,0x44
    7937:	movq   rax,xmm0
    793c:	add    rax,rax
    793f:	je     0x7955
    7941:	shr    rax,0x35
    7945:	sub    eax,0x201
    794a:	cmp    eax,0x3fc
    794f:	ja     0x7a0d
    7955:	movdqa xmm14,xmm0
    795a:	psrldq xmm14,0x8
    7960:	movq   rax,xmm14
    7965:	add    rax,rax
    7968:	je     0x797e
    796a:	shr    rax,0x35
    796e:	sub    eax,0x201
    7973:	cmp    eax,0x3fc
    7978:	ja     0x7a0d
    797e:	movq   rax,xmm1
    7983:	add    rax,rax
    7986:	je     0x799c
    7988:	shr    rax,0x35
    798c:	sub    eax,0x201
    7991:	cmp    eax,0x3fc
    7996:	ja     0x7a0d
    799c:	movdqa xmm14,xmm1
    79a1:	psrldq xmm14,0x8
    79a7:	movq   rax,xmm14
    79ac:	add    rax,rax
    79af:	je     0x79c5
    79b1:	shr    rax,0x35
    79b5:	sub    eax,0x201
    79ba:	cmp    eax,0x3fc
    79bf:	ja     0x7a0d
    79c5:	stmxcsr DWORD PTR [rsp+0x100]
    79cd:	mov    DWORD PTR [rsp+0x104],0x1f80
    79d8:	ldmxcsr DWORD PTR [rsp+0x104]
    79e0:	mulpd  xmm0,xmm1
    79e4:	stmxcsr DWORD PTR [rsp+0x104]
    79ec:	ldmxcsr DWORD PTR [rsp+0x100]
    79f4:	mov    eax,DWORD PTR [rsp+0x104]
    79fb:	shr    eax,1
    79fd:	and    eax,0x10
    7a00:	or     DWORD PTR [r12+0x314],eax
    7a08:	jmp    0x7aba
    7a0d:	movdqa xmm0,xmm2
    7a11:	movdqa xmm1,xmm3
    7a15:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7a1e:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7a27:	mov    QWORD PTR [r12+0x378],0x3
    7a33:	movdqu XMMWORD PTR [rsp],xmm2
    7a38:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7a3e:	mov    QWORD PTR [r12+0x108],rbx
    7a46:	stmxcsr DWORD PTR [r12-0x28]
    7a4c:	ldmxcsr DWORD PTR [r12-0x38]
    7a52:	lea    rdi,[rsp+0xf0]
    7a5a:	lea    rsi,[rsp+0xd0]
    7a62:	lea    rdx,[rsp+0xe0]
    7a6a:	mov    ecx,0x56
    7a6f:	mov    r8d,DWORD PTR [r12+0x310]
    7a77:	lea    r9,[r12+0x314]
    7a7f:	movabs r11,0x5b9960291750
    7a89:	call   r11
    7a8c:	ldmxcsr DWORD PTR [r12-0x28]
    7a92:	movdqu xmm2,XMMWORD PTR [rsp]
    7a97:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7a9d:	mov    rbx,QWORD PTR [r12+0x108]
    7aa5:	mov    QWORD PTR [r12+0x378],0x2
    7ab1:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7aba:	movdqa xmm4,xmm0
    7abe:	movdqa xmm0,xmm4
    7ac2:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7acc:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7ad6:	movdqa xmm2,xmm0
    7ada:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7ae4:	movdqa xmm3,xmm0
    7ae8:	cmp    DWORD PTR [r12+0x310],0x0
    7af1:	jne    0x7bda
    7af7:	movdqa xmm0,xmm2
    7afb:	movdqa xmm1,xmm3
    7aff:	pshufd xmm1,xmm1,0x44
    7b04:	movq   rax,xmm0
    7b09:	add    rax,rax
    7b0c:	je     0x7b22
    7b0e:	shr    rax,0x35
    7b12:	sub    eax,0x201
    7b17:	cmp    eax,0x3fc
    7b1c:	ja     0x7bda
    7b22:	movdqa xmm14,xmm0
    7b27:	psrldq xmm14,0x8
    7b2d:	movq   rax,xmm14
    7b32:	add    rax,rax
    7b35:	je     0x7b4b
    7b37:	shr    rax,0x35
    7b3b:	sub    eax,0x201
    7b40:	cmp    eax,0x3fc
    7b45:	ja     0x7bda
    7b4b:	movq   rax,xmm1
    7b50:	add    rax,rax
    7b53:	je     0x7b69
    7b55:	shr    rax,0x35
    7b59:	sub    eax,0x201
    7b5e:	cmp    eax,0x3fc
    7b63:	ja     0x7bda
    7b69:	movdqa xmm14,xmm1
    7b6e:	psrldq xmm14,0x8
    7b74:	movq   rax,xmm14
    7b79:	add    rax,rax
    7b7c:	je     0x7b92
    7b7e:	shr    rax,0x35
    7b82:	sub    eax,0x201
    7b87:	cmp    eax,0x3fc
    7b8c:	ja     0x7bda
    7b92:	stmxcsr DWORD PTR [rsp+0x100]
    7b9a:	mov    DWORD PTR [rsp+0x104],0x1f80
    7ba5:	ldmxcsr DWORD PTR [rsp+0x104]
    7bad:	mulpd  xmm0,xmm1
    7bb1:	stmxcsr DWORD PTR [rsp+0x104]
    7bb9:	ldmxcsr DWORD PTR [rsp+0x100]
    7bc1:	mov    eax,DWORD PTR [rsp+0x104]
    7bc8:	shr    eax,1
    7bca:	and    eax,0x10
    7bcd:	or     DWORD PTR [r12+0x314],eax
    7bd5:	jmp    0x7c87
    7bda:	movdqa xmm0,xmm2
    7bde:	movdqa xmm1,xmm3
    7be2:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7beb:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7bf4:	mov    QWORD PTR [r12+0x378],0x3
    7c00:	movdqu XMMWORD PTR [rsp],xmm2
    7c05:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7c0b:	mov    QWORD PTR [r12+0x108],rbx
    7c13:	stmxcsr DWORD PTR [r12-0x28]
    7c19:	ldmxcsr DWORD PTR [r12-0x38]
    7c1f:	lea    rdi,[rsp+0xf0]
    7c27:	lea    rsi,[rsp+0xd0]
    7c2f:	lea    rdx,[rsp+0xe0]
    7c37:	mov    ecx,0x56
    7c3c:	mov    r8d,DWORD PTR [r12+0x310]
    7c44:	lea    r9,[r12+0x314]
    7c4c:	movabs r11,0x5b9960291750
    7c56:	call   r11
    7c59:	ldmxcsr DWORD PTR [r12-0x28]
    7c5f:	movdqu xmm2,XMMWORD PTR [rsp]
    7c64:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7c6a:	mov    rbx,QWORD PTR [r12+0x108]
    7c72:	mov    QWORD PTR [r12+0x378],0x2
    7c7e:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7c87:	movdqa xmm4,xmm0
    7c8b:	movdqa xmm0,xmm4
    7c8f:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c99:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7ca3:	movdqa xmm2,xmm0
    7ca7:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7cb1:	movdqa xmm3,xmm0
    7cb5:	cmp    DWORD PTR [r12+0x310],0x0
    7cbe:	jne    0x7da2
    7cc4:	movdqa xmm0,xmm2
    7cc8:	movdqa xmm1,xmm3
    7ccc:	movq   rax,xmm0
    7cd1:	add    rax,rax
    7cd4:	je     0x7cea
    7cd6:	shr    rax,0x35
    7cda:	sub    eax,0x201
    7cdf:	cmp    eax,0x3fc
    7ce4:	ja     0x7da2
    7cea:	movdqa xmm14,xmm0
    7cef:	psrldq xmm14,0x8
    7cf5:	movq   rax,xmm14
    7cfa:	add    rax,rax
    7cfd:	je     0x7d13
    7cff:	shr    rax,0x35
    7d03:	sub    eax,0x201
    7d08:	cmp    eax,0x3fc
    7d0d:	ja     0x7da2
    7d13:	movq   rax,xmm1
    7d18:	add    rax,rax
    7d1b:	je     0x7d31
    7d1d:	shr    rax,0x35
    7d21:	sub    eax,0x201
    7d26:	cmp    eax,0x3fc
    7d2b:	ja     0x7da2
    7d31:	movdqa xmm14,xmm1
    7d36:	psrldq xmm14,0x8
    7d3c:	movq   rax,xmm14
    7d41:	add    rax,rax
    7d44:	je     0x7d5a
    7d46:	shr    rax,0x35
    7d4a:	sub    eax,0x201
    7d4f:	cmp    eax,0x3fc
    7d54:	ja     0x7da2
    7d5a:	stmxcsr DWORD PTR [rsp+0x100]
    7d62:	mov    DWORD PTR [rsp+0x104],0x1f80
    7d6d:	ldmxcsr DWORD PTR [rsp+0x104]
    7d75:	addpd  xmm0,xmm1
    7d79:	stmxcsr DWORD PTR [rsp+0x104]
    7d81:	ldmxcsr DWORD PTR [rsp+0x100]
    7d89:	mov    eax,DWORD PTR [rsp+0x104]
    7d90:	shr    eax,1
    7d92:	and    eax,0x10
    7d95:	or     DWORD PTR [r12+0x314],eax
    7d9d:	jmp    0x7e4f
    7da2:	movdqa xmm0,xmm2
    7da6:	movdqa xmm1,xmm3
    7daa:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7db3:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7dbc:	mov    QWORD PTR [r12+0x378],0x3
    7dc8:	movdqu XMMWORD PTR [rsp],xmm2
    7dcd:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7dd3:	mov    QWORD PTR [r12+0x108],rbx
    7ddb:	stmxcsr DWORD PTR [r12-0x28]
    7de1:	ldmxcsr DWORD PTR [r12-0x38]
    7de7:	lea    rdi,[rsp+0xf0]
    7def:	lea    rsi,[rsp+0xd0]
    7df7:	lea    rdx,[rsp+0xe0]
    7dff:	mov    ecx,0x14
    7e04:	mov    r8d,DWORD PTR [r12+0x310]
    7e0c:	lea    r9,[r12+0x314]
    7e14:	movabs r11,0x5b9960291750
    7e1e:	call   r11
    7e21:	ldmxcsr DWORD PTR [r12-0x28]
    7e27:	movdqu xmm2,XMMWORD PTR [rsp]
    7e2c:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7e32:	mov    rbx,QWORD PTR [r12+0x108]
    7e3a:	mov    QWORD PTR [r12+0x378],0x2
    7e46:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7e4f:	movdqa xmm4,xmm0
    7e53:	movdqa xmm0,xmm4
    7e57:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7e61:	mov    r13,QWORD PTR [r12+0xf8]
    7e69:	mov    r14,r13
    7e6c:	add    r14,0x10
    7e70:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7e76:	movdqu xmm3,XMMWORD PTR [r14]
    7e7b:	movdqa xmm0,xmm2
    7e7f:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7e89:	movdqa xmm0,xmm3
    7e8d:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7e97:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7ea1:	movdqa xmm2,xmm0
    7ea5:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7eaf:	movdqa xmm3,xmm0
    7eb3:	cmp    DWORD PTR [r12+0x310],0x0
    7ebc:	jne    0x7fa0
    7ec2:	movdqa xmm0,xmm2
    7ec6:	movdqa xmm1,xmm3
    7eca:	movq   rax,xmm0
    7ecf:	add    rax,rax
    7ed2:	je     0x7ee8
    7ed4:	shr    rax,0x35
    7ed8:	sub    eax,0x201
    7edd:	cmp    eax,0x3fc
    7ee2:	ja     0x7fa0
    7ee8:	movdqa xmm14,xmm0
    7eed:	psrldq xmm14,0x8
    7ef3:	movq   rax,xmm14
    7ef8:	add    rax,rax
    7efb:	je     0x7f11
    7efd:	shr    rax,0x35
    7f01:	sub    eax,0x201
    7f06:	cmp    eax,0x3fc
    7f0b:	ja     0x7fa0
    7f11:	movq   rax,xmm1
    7f16:	add    rax,rax
    7f19:	je     0x7f2f
    7f1b:	shr    rax,0x35
    7f1f:	sub    eax,0x201
    7f24:	cmp    eax,0x3fc
    7f29:	ja     0x7fa0
    7f2f:	movdqa xmm14,xmm1
    7f34:	psrldq xmm14,0x8
    7f3a:	movq   rax,xmm14
    7f3f:	add    rax,rax
    7f42:	je     0x7f58
    7f44:	shr    rax,0x35
    7f48:	sub    eax,0x201
    7f4d:	cmp    eax,0x3fc
    7f52:	ja     0x7fa0
    7f58:	stmxcsr DWORD PTR [rsp+0x100]
    7f60:	mov    DWORD PTR [rsp+0x104],0x1f80
    7f6b:	ldmxcsr DWORD PTR [rsp+0x104]
    7f73:	addpd  xmm0,xmm1
    7f77:	stmxcsr DWORD PTR [rsp+0x104]
    7f7f:	ldmxcsr DWORD PTR [rsp+0x100]
    7f87:	mov    eax,DWORD PTR [rsp+0x104]
    7f8e:	shr    eax,1
    7f90:	and    eax,0x10
    7f93:	or     DWORD PTR [r12+0x314],eax
    7f9b:	jmp    0x804d
    7fa0:	movdqa xmm0,xmm2
    7fa4:	movdqa xmm1,xmm3
    7fa8:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7fb1:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7fba:	mov    QWORD PTR [r12+0x378],0x3
    7fc6:	movdqu XMMWORD PTR [rsp],xmm2
    7fcb:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7fd1:	mov    QWORD PTR [r12+0x108],rbx
    7fd9:	stmxcsr DWORD PTR [r12-0x28]
    7fdf:	ldmxcsr DWORD PTR [r12-0x38]
    7fe5:	lea    rdi,[rsp+0xf0]
    7fed:	lea    rsi,[rsp+0xd0]
    7ff5:	lea    rdx,[rsp+0xe0]
    7ffd:	mov    ecx,0x14
    8002:	mov    r8d,DWORD PTR [r12+0x310]
    800a:	lea    r9,[r12+0x314]
    8012:	movabs r11,0x5b9960291750
    801c:	call   r11
    801f:	ldmxcsr DWORD PTR [r12-0x28]
    8025:	movdqu xmm2,XMMWORD PTR [rsp]
    802a:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8030:	mov    rbx,QWORD PTR [r12+0x108]
    8038:	mov    QWORD PTR [r12+0x378],0x2
    8044:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    804d:	movdqa xmm4,xmm0
    8051:	movdqa xmm0,xmm4
    8055:	movdqu XMMWORD PTR [r12+0x130],xmm0
    805f:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    8069:	movdqa xmm2,xmm0
    806d:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    8077:	movdqa xmm3,xmm0
    807b:	cmp    DWORD PTR [r12+0x310],0x0
    8084:	jne    0x816d
    808a:	movdqa xmm0,xmm2
    808e:	movdqa xmm1,xmm3
    8092:	pshufd xmm1,xmm1,0x44
    8097:	movq   rax,xmm0
    809c:	add    rax,rax
    809f:	je     0x80b5
    80a1:	shr    rax,0x35
    80a5:	sub    eax,0x201
    80aa:	cmp    eax,0x3fc
    80af:	ja     0x816d
    80b5:	movdqa xmm14,xmm0
    80ba:	psrldq xmm14,0x8
    80c0:	movq   rax,xmm14
    80c5:	add    rax,rax
    80c8:	je     0x80de
    80ca:	shr    rax,0x35
    80ce:	sub    eax,0x201
    80d3:	cmp    eax,0x3fc
    80d8:	ja     0x816d
    80de:	movq   rax,xmm1
    80e3:	add    rax,rax
    80e6:	je     0x80fc
    80e8:	shr    rax,0x35
    80ec:	sub    eax,0x201
    80f1:	cmp    eax,0x3fc
    80f6:	ja     0x816d
    80fc:	movdqa xmm14,xmm1
    8101:	psrldq xmm14,0x8
    8107:	movq   rax,xmm14
    810c:	add    rax,rax
    810f:	je     0x8125
    8111:	shr    rax,0x35
    8115:	sub    eax,0x201
    811a:	cmp    eax,0x3fc
    811f:	ja     0x816d
    8125:	stmxcsr DWORD PTR [rsp+0x100]
    812d:	mov    DWORD PTR [rsp+0x104],0x1f80
    8138:	ldmxcsr DWORD PTR [rsp+0x104]
    8140:	mulpd  xmm0,xmm1
    8144:	stmxcsr DWORD PTR [rsp+0x104]
    814c:	ldmxcsr DWORD PTR [rsp+0x100]
    8154:	mov    eax,DWORD PTR [rsp+0x104]
    815b:	shr    eax,1
    815d:	and    eax,0x10
    8160:	or     DWORD PTR [r12+0x314],eax
    8168:	jmp    0x821a
    816d:	movdqa xmm0,xmm2
    8171:	movdqa xmm1,xmm3
    8175:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    817e:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    8187:	mov    QWORD PTR [r12+0x378],0x3
    8193:	movdqu XMMWORD PTR [rsp],xmm2
    8198:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    819e:	mov    QWORD PTR [r12+0x108],rbx
    81a6:	stmxcsr DWORD PTR [r12-0x28]
    81ac:	ldmxcsr DWORD PTR [r12-0x38]
    81b2:	lea    rdi,[rsp+0xf0]
    81ba:	lea    rsi,[rsp+0xd0]
    81c2:	lea    rdx,[rsp+0xe0]
    81ca:	mov    ecx,0x56
    81cf:	mov    r8d,DWORD PTR [r12+0x310]
    81d7:	lea    r9,[r12+0x314]
    81df:	movabs r11,0x5b9960291750
    81e9:	call   r11
    81ec:	ldmxcsr DWORD PTR [r12-0x28]
    81f2:	movdqu xmm2,XMMWORD PTR [rsp]
    81f7:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    81fd:	mov    rbx,QWORD PTR [r12+0x108]
    8205:	mov    QWORD PTR [r12+0x378],0x2
    8211:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    821a:	movdqa xmm4,xmm0
    821e:	movdqa xmm0,xmm4
    8222:	movdqu XMMWORD PTR [r12+0x220],xmm0
    822c:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    8236:	movdqa xmm2,xmm0
    823a:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    8244:	movdqa xmm3,xmm0
    8248:	cmp    DWORD PTR [r12+0x310],0x0
    8251:	jne    0x833a
    8257:	movdqa xmm0,xmm2
    825b:	movdqa xmm1,xmm3
    825f:	pshufd xmm1,xmm1,0x44
    8264:	movq   rax,xmm0
    8269:	add    rax,rax
    826c:	je     0x8282
    826e:	shr    rax,0x35
    8272:	sub    eax,0x201
    8277:	cmp    eax,0x3fc
    827c:	ja     0x833a
    8282:	movdqa xmm14,xmm0
    8287:	psrldq xmm14,0x8
    828d:	movq   rax,xmm14
    8292:	add    rax,rax
    8295:	je     0x82ab
    8297:	shr    rax,0x35
    829b:	sub    eax,0x201
    82a0:	cmp    eax,0x3fc
    82a5:	ja     0x833a
    82ab:	movq   rax,xmm1
    82b0:	add    rax,rax
    82b3:	je     0x82c9
    82b5:	shr    rax,0x35
    82b9:	sub    eax,0x201
    82be:	cmp    eax,0x3fc
    82c3:	ja     0x833a
    82c9:	movdqa xmm14,xmm1
    82ce:	psrldq xmm14,0x8
    82d4:	movq   rax,xmm14
    82d9:	add    rax,rax
    82dc:	je     0x82f2
    82de:	shr    rax,0x35
    82e2:	sub    eax,0x201
    82e7:	cmp    eax,0x3fc
    82ec:	ja     0x833a
    82f2:	stmxcsr DWORD PTR [rsp+0x100]
    82fa:	mov    DWORD PTR [rsp+0x104],0x1f80
    8305:	ldmxcsr DWORD PTR [rsp+0x104]
    830d:	mulpd  xmm0,xmm1
    8311:	stmxcsr DWORD PTR [rsp+0x104]
    8319:	ldmxcsr DWORD PTR [rsp+0x100]
    8321:	mov    eax,DWORD PTR [rsp+0x104]
    8328:	shr    eax,1
    832a:	and    eax,0x10
    832d:	or     DWORD PTR [r12+0x314],eax
    8335:	jmp    0x83e7
    833a:	movdqa xmm0,xmm2
    833e:	movdqa xmm1,xmm3
    8342:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    834b:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    8354:	mov    QWORD PTR [r12+0x378],0x3
    8360:	movdqu XMMWORD PTR [rsp],xmm2
    8365:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    836b:	mov    QWORD PTR [r12+0x108],rbx
    8373:	stmxcsr DWORD PTR [r12-0x28]
    8379:	ldmxcsr DWORD PTR [r12-0x38]
    837f:	lea    rdi,[rsp+0xf0]
    8387:	lea    rsi,[rsp+0xd0]
    838f:	lea    rdx,[rsp+0xe0]
    8397:	mov    ecx,0x56
    839c:	mov    r8d,DWORD PTR [r12+0x310]
    83a4:	lea    r9,[r12+0x314]
    83ac:	movabs r11,0x5b9960291750
    83b6:	call   r11
    83b9:	ldmxcsr DWORD PTR [r12-0x28]
    83bf:	movdqu xmm2,XMMWORD PTR [rsp]
    83c4:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    83ca:	mov    rbx,QWORD PTR [r12+0x108]
    83d2:	mov    QWORD PTR [r12+0x378],0x2
    83de:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    83e7:	movdqa xmm4,xmm0
    83eb:	movdqa xmm0,xmm4
    83ef:	movdqu XMMWORD PTR [r12+0x120],xmm0
    83f9:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    8403:	movdqa xmm2,xmm0
    8407:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    8411:	movdqa xmm3,xmm0
    8415:	cmp    DWORD PTR [r12+0x310],0x0
    841e:	jne    0x8502
    8424:	movdqa xmm0,xmm2
    8428:	movdqa xmm1,xmm3
    842c:	movq   rax,xmm0
    8431:	add    rax,rax
    8434:	je     0x844a
    8436:	shr    rax,0x35
    843a:	sub    eax,0x201
    843f:	cmp    eax,0x3fc
    8444:	ja     0x8502
    844a:	movdqa xmm14,xmm0
    844f:	psrldq xmm14,0x8
    8455:	movq   rax,xmm14
    845a:	add    rax,rax
    845d:	je     0x8473
    845f:	shr    rax,0x35
    8463:	sub    eax,0x201
    8468:	cmp    eax,0x3fc
    846d:	ja     0x8502
    8473:	movq   rax,xmm1
    8478:	add    rax,rax
    847b:	je     0x8491
    847d:	shr    rax,0x35
    8481:	sub    eax,0x201
    8486:	cmp    eax,0x3fc
    848b:	ja     0x8502
    8491:	movdqa xmm14,xmm1
    8496:	psrldq xmm14,0x8
    849c:	movq   rax,xmm14
    84a1:	add    rax,rax
    84a4:	je     0x84ba
    84a6:	shr    rax,0x35
    84aa:	sub    eax,0x201
    84af:	cmp    eax,0x3fc
    84b4:	ja     0x8502
    84ba:	stmxcsr DWORD PTR [rsp+0x100]
    84c2:	mov    DWORD PTR [rsp+0x104],0x1f80
    84cd:	ldmxcsr DWORD PTR [rsp+0x104]
    84d5:	addpd  xmm0,xmm1
    84d9:	stmxcsr DWORD PTR [rsp+0x104]
    84e1:	ldmxcsr DWORD PTR [rsp+0x100]
    84e9:	mov    eax,DWORD PTR [rsp+0x104]
    84f0:	shr    eax,1
    84f2:	and    eax,0x10
    84f5:	or     DWORD PTR [r12+0x314],eax
    84fd:	jmp    0x85af
    8502:	movdqa xmm0,xmm2
    8506:	movdqa xmm1,xmm3
    850a:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    8513:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    851c:	mov    QWORD PTR [r12+0x378],0x3
    8528:	movdqu XMMWORD PTR [rsp],xmm2
    852d:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    8533:	mov    QWORD PTR [r12+0x108],rbx
    853b:	stmxcsr DWORD PTR [r12-0x28]
    8541:	ldmxcsr DWORD PTR [r12-0x38]
    8547:	lea    rdi,[rsp+0xf0]
    854f:	lea    rsi,[rsp+0xd0]
    8557:	lea    rdx,[rsp+0xe0]
    855f:	mov    ecx,0x14
    8564:	mov    r8d,DWORD PTR [r12+0x310]
    856c:	lea    r9,[r12+0x314]
    8574:	movabs r11,0x5b9960291750
    857e:	call   r11
    8581:	ldmxcsr DWORD PTR [r12-0x28]
    8587:	movdqu xmm2,XMMWORD PTR [rsp]
    858c:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8592:	mov    rbx,QWORD PTR [r12+0x108]
    859a:	mov    QWORD PTR [r12+0x378],0x2
    85a6:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    85af:	movdqa xmm4,xmm0
    85b3:	movdqa xmm0,xmm4
    85b7:	movdqu XMMWORD PTR [r12+0x140],xmm0
    85c1:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    85cb:	movdqa xmm2,xmm0
    85cf:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    85d9:	movdqa xmm3,xmm0
    85dd:	cmp    DWORD PTR [r12+0x310],0x0
    85e6:	jne    0x86ca
    85ec:	movdqa xmm0,xmm2
    85f0:	movdqa xmm1,xmm3
    85f4:	movq   rax,xmm0
    85f9:	add    rax,rax
    85fc:	je     0x8612
    85fe:	shr    rax,0x35
    8602:	sub    eax,0x201
    8607:	cmp    eax,0x3fc
    860c:	ja     0x86ca
    8612:	movdqa xmm14,xmm0
    8617:	psrldq xmm14,0x8
    861d:	movq   rax,xmm14
    8622:	add    rax,rax
    8625:	je     0x863b
    8627:	shr    rax,0x35
    862b:	sub    eax,0x201
    8630:	cmp    eax,0x3fc
    8635:	ja     0x86ca
    863b:	movq   rax,xmm1
    8640:	add    rax,rax
    8643:	je     0x8659
    8645:	shr    rax,0x35
    8649:	sub    eax,0x201
    864e:	cmp    eax,0x3fc
    8653:	ja     0x86ca
    8659:	movdqa xmm14,xmm1
    865e:	psrldq xmm14,0x8
    8664:	movq   rax,xmm14
    8669:	add    rax,rax
    866c:	je     0x8682
    866e:	shr    rax,0x35
    8672:	sub    eax,0x201
    8677:	cmp    eax,0x3fc
    867c:	ja     0x86ca
    8682:	stmxcsr DWORD PTR [rsp+0x100]
    868a:	mov    DWORD PTR [rsp+0x104],0x1f80
    8695:	ldmxcsr DWORD PTR [rsp+0x104]
    869d:	addpd  xmm0,xmm1
    86a1:	stmxcsr DWORD PTR [rsp+0x104]
    86a9:	ldmxcsr DWORD PTR [rsp+0x100]
    86b1:	mov    eax,DWORD PTR [rsp+0x104]
    86b8:	shr    eax,1
    86ba:	and    eax,0x10
    86bd:	or     DWORD PTR [r12+0x314],eax
    86c5:	jmp    0x8777
    86ca:	movdqa xmm0,xmm2
    86ce:	movdqa xmm1,xmm3
    86d2:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    86db:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    86e4:	mov    QWORD PTR [r12+0x378],0x3
    86f0:	movdqu XMMWORD PTR [rsp],xmm2
    86f5:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    86fb:	mov    QWORD PTR [r12+0x108],rbx
    8703:	stmxcsr DWORD PTR [r12-0x28]
    8709:	ldmxcsr DWORD PTR [r12-0x38]
    870f:	lea    rdi,[rsp+0xf0]
    8717:	lea    rsi,[rsp+0xd0]
    871f:	lea    rdx,[rsp+0xe0]
    8727:	mov    ecx,0x14
    872c:	mov    r8d,DWORD PTR [r12+0x310]
    8734:	lea    r9,[r12+0x314]
    873c:	movabs r11,0x5b9960291750
    8746:	call   r11
    8749:	ldmxcsr DWORD PTR [r12-0x28]
    874f:	movdqu xmm2,XMMWORD PTR [rsp]
    8754:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    875a:	mov    rbx,QWORD PTR [r12+0x108]
    8762:	mov    QWORD PTR [r12+0x378],0x2
    876e:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    8777:	movdqa xmm4,xmm0
    877b:	movdqa xmm0,xmm4
    877f:	movdqu XMMWORD PTR [r12+0x150],xmm0
    8789:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    8793:	movdqa xmm2,xmm0
    8797:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    87a1:	movdqa xmm3,xmm0
    87a5:	cmp    DWORD PTR [r12+0x310],0x0
    87ae:	jne    0x8892
    87b4:	movdqa xmm0,xmm2
    87b8:	movdqa xmm1,xmm3
    87bc:	movq   rax,xmm0
    87c1:	add    rax,rax
    87c4:	je     0x87da
    87c6:	shr    rax,0x35
    87ca:	sub    eax,0x201
    87cf:	cmp    eax,0x3fc
    87d4:	ja     0x8892
    87da:	movdqa xmm14,xmm0
    87df:	psrldq xmm14,0x8
    87e5:	movq   rax,xmm14
    87ea:	add    rax,rax
    87ed:	je     0x8803
    87ef:	shr    rax,0x35
    87f3:	sub    eax,0x201
    87f8:	cmp    eax,0x3fc
    87fd:	ja     0x8892
    8803:	movq   rax,xmm1
    8808:	add    rax,rax
    880b:	je     0x8821
    880d:	shr    rax,0x35
    8811:	sub    eax,0x201
    8816:	cmp    eax,0x3fc
    881b:	ja     0x8892
    8821:	movdqa xmm14,xmm1
    8826:	psrldq xmm14,0x8
    882c:	movq   rax,xmm14
    8831:	add    rax,rax
    8834:	je     0x884a
    8836:	shr    rax,0x35
    883a:	sub    eax,0x201
    883f:	cmp    eax,0x3fc
    8844:	ja     0x8892
    884a:	stmxcsr DWORD PTR [rsp+0x100]
    8852:	mov    DWORD PTR [rsp+0x104],0x1f80
    885d:	ldmxcsr DWORD PTR [rsp+0x104]
    8865:	addpd  xmm0,xmm1
    8869:	stmxcsr DWORD PTR [rsp+0x104]
    8871:	ldmxcsr DWORD PTR [rsp+0x100]
    8879:	mov    eax,DWORD PTR [rsp+0x104]
    8880:	shr    eax,1
    8882:	and    eax,0x10
    8885:	or     DWORD PTR [r12+0x314],eax
    888d:	jmp    0x893f
    8892:	movdqa xmm0,xmm2
    8896:	movdqa xmm1,xmm3
    889a:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    88a3:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    88ac:	mov    QWORD PTR [r12+0x378],0x3
    88b8:	movdqu XMMWORD PTR [rsp],xmm2
    88bd:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    88c3:	mov    QWORD PTR [r12+0x108],rbx
    88cb:	stmxcsr DWORD PTR [r12-0x28]
    88d1:	ldmxcsr DWORD PTR [r12-0x38]
    88d7:	lea    rdi,[rsp+0xf0]
    88df:	lea    rsi,[rsp+0xd0]
    88e7:	lea    rdx,[rsp+0xe0]
    88ef:	mov    ecx,0x14
    88f4:	mov    r8d,DWORD PTR [r12+0x310]
    88fc:	lea    r9,[r12+0x314]
    8904:	movabs r11,0x5b9960291750
    890e:	call   r11
    8911:	ldmxcsr DWORD PTR [r12-0x28]
    8917:	movdqu xmm2,XMMWORD PTR [rsp]
    891c:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8922:	mov    rbx,QWORD PTR [r12+0x108]
    892a:	mov    QWORD PTR [r12+0x378],0x2
    8936:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    893f:	movdqa xmm4,xmm0
    8943:	movdqa xmm0,xmm4
    8947:	movdqu XMMWORD PTR [r12+0x160],xmm0
    8951:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    895b:	movdqa xmm2,xmm0
    895f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    8969:	movdqa xmm3,xmm0
    896d:	cmp    DWORD PTR [r12+0x310],0x0
    8976:	jne    0x8a5a
    897c:	movdqa xmm0,xmm2
    8980:	movdqa xmm1,xmm3
    8984:	movq   rax,xmm0
    8989:	add    rax,rax
    898c:	je     0x89a2
    898e:	shr    rax,0x35
    8992:	sub    eax,0x201
    8997:	cmp    eax,0x3fc
    899c:	ja     0x8a5a
    89a2:	movdqa xmm14,xmm0
    89a7:	psrldq xmm14,0x8
    89ad:	movq   rax,xmm14
    89b2:	add    rax,rax
    89b5:	je     0x89cb
    89b7:	shr    rax,0x35
    89bb:	sub    eax,0x201
    89c0:	cmp    eax,0x3fc
    89c5:	ja     0x8a5a
    89cb:	movq   rax,xmm1
    89d0:	add    rax,rax
    89d3:	je     0x89e9
    89d5:	shr    rax,0x35
    89d9:	sub    eax,0x201
    89de:	cmp    eax,0x3fc
    89e3:	ja     0x8a5a
    89e9:	movdqa xmm14,xmm1
    89ee:	psrldq xmm14,0x8
    89f4:	movq   rax,xmm14
    89f9:	add    rax,rax
    89fc:	je     0x8a12
    89fe:	shr    rax,0x35
    8a02:	sub    eax,0x201
    8a07:	cmp    eax,0x3fc
    8a0c:	ja     0x8a5a
    8a12:	stmxcsr DWORD PTR [rsp+0x100]
    8a1a:	mov    DWORD PTR [rsp+0x104],0x1f80
    8a25:	ldmxcsr DWORD PTR [rsp+0x104]
    8a2d:	addpd  xmm0,xmm1
    8a31:	stmxcsr DWORD PTR [rsp+0x104]
    8a39:	ldmxcsr DWORD PTR [rsp+0x100]
    8a41:	mov    eax,DWORD PTR [rsp+0x104]
    8a48:	shr    eax,1
    8a4a:	and    eax,0x10
    8a4d:	or     DWORD PTR [r12+0x314],eax
    8a55:	jmp    0x8b07
    8a5a:	movdqa xmm0,xmm2
    8a5e:	movdqa xmm1,xmm3
    8a62:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    8a6b:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    8a74:	mov    QWORD PTR [r12+0x378],0x3
    8a80:	movdqu XMMWORD PTR [rsp],xmm2
    8a85:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    8a8b:	mov    QWORD PTR [r12+0x108],rbx
    8a93:	stmxcsr DWORD PTR [r12-0x28]
    8a99:	ldmxcsr DWORD PTR [r12-0x38]
    8a9f:	lea    rdi,[rsp+0xf0]
    8aa7:	lea    rsi,[rsp+0xd0]
    8aaf:	lea    rdx,[rsp+0xe0]
    8ab7:	mov    ecx,0x14
    8abc:	mov    r8d,DWORD PTR [r12+0x310]
    8ac4:	lea    r9,[r12+0x314]
    8acc:	movabs r11,0x5b9960291750
    8ad6:	call   r11
    8ad9:	ldmxcsr DWORD PTR [r12-0x28]
    8adf:	movdqu xmm2,XMMWORD PTR [rsp]
    8ae4:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8aea:	mov    rbx,QWORD PTR [r12+0x108]
    8af2:	mov    QWORD PTR [r12+0x378],0x2
    8afe:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    8b07:	movdqa xmm4,xmm0
    8b0b:	movdqa xmm0,xmm4
    8b0f:	movdqu XMMWORD PTR [r12+0x120],xmm0
    8b19:	mov    r13,QWORD PTR [r12+0x60]
    8b1e:	mov    r14,r13
    8b21:	add    r14,0x10
    8b25:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    8b2f:	movdqa xmm2,xmm0
    8b33:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    8b3d:	movdqa xmm3,xmm0
    8b41:	movdqu XMMWORD PTR [r13+0x0],xmm2
    8b47:	mov    r15d,0x0
    8b4d:	mov    DWORD PTR [r12+0x32c],r15d
    8b55:	movdqu XMMWORD PTR [r14],xmm3
    8b5a:	mov    r14d,0x0
    8b60:	mov    DWORD PTR [r12+0x32c],r14d
    8b68:	mov    r14,r13
    8b6b:	add    r14,0x20
    8b6f:	mov    r13,r14
    8b72:	add    r13,0x10
    8b76:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    8b80:	movdqa xmm2,xmm0
    8b84:	movdqu XMMWORD PTR [r14],xmm2
    8b89:	mov    r14d,0x0
    8b8f:	mov    DWORD PTR [r12+0x32c],r14d
    8b97:	movdqu XMMWORD PTR [r13+0x0],xmm4
    8b9d:	mov    r13d,0x0
    8ba3:	mov    DWORD PTR [r12+0x32c],r13d
    8bab:	cmp    QWORD PTR [r12+0x380],0x0
    8bb4:	je     0x8be8
    8bba:	mov    eax,0x4106cc
    8bbf:	mov    QWORD PTR [r12+0x100],rax
    8bc7:	mov    QWORD PTR [r12+0x108],rbx
    8bcf:	add    rsp,0x140
    8bd6:	mov    eax,0xc
    8bdb:	movabs r11,0x5b99604255f0
    8be5:	jmp    r11
    8be8:	test   ebx,0x40000000
    8bee:	je     0x108e
    8bf4:	jmp    0x8bf9
    8bf9:	mov    r13d,DWORD PTR [r12+0x48]
    8bfe:	mov    r14d,r13d
    8c01:	add    r14d,0x1
    8c05:	mov    QWORD PTR [r12+0x48],r14
    8c0a:	mov    r13d,r14d
    8c0d:	sub    r13d,0x1f4
    8c14:	pushf
    8c15:	pop    rdx
    8c16:	mov    r10d,edx
    8c19:	and    r10d,0xc0
    8c20:	shl    r10d,0x18
    8c24:	mov    r11d,edx
    8c27:	and    r11d,0x1
    8c2b:	shl    r11d,0x1d
    8c2f:	or     r10d,r11d
    8c32:	mov    r11d,edx
    8c35:	and    r11d,0x800
    8c3c:	shl    r11d,0x11
    8c40:	or     r10d,r11d
    8c43:	mov    r11d,0xf0000000
    8c49:	and    r11,r10
    8c4c:	movabs rsi,0xffffffff0fffffff
    8c56:	and    rbx,rsi
    8c59:	or     rbx,r11
    8c5c:	btc    rbx,0x1d
    8c61:	cmp    QWORD PTR [r12+0x380],0x0
    8c6a:	je     0x8c9e
    8c70:	mov    eax,0x4106d8
    8c75:	mov    QWORD PTR [r12+0x100],rax
    8c7d:	mov    QWORD PTR [r12+0x108],rbx
    8c85:	add    rsp,0x140
    8c8c:	mov    eax,0xc
    8c91:	movabs r11,0x5b99604255f0
    8c9b:	jmp    r11
    8c9e:	test   ebx,0x40000000
    8ca4:	je     0x107e
    8caa:	jmp    0x8caf
    8caf:	mov    r13d,0x430000
    8cb5:	mov    QWORD PTR [r12+0x40],r13
    8cba:	mov    r13d,0x0
    8cc0:	mov    QWORD PTR [r12+0x48],r13
    8cc5:	mov    r13d,0x430cc0
    8ccb:	mov    r14,QWORD PTR [r13+0x0]
    8ccf:	mov    r13d,0x0
    8cd5:	mov    QWORD PTR [r12+0x110],r14
    8cdd:	mov    QWORD PTR [r12+0x118],r13
    8ce5:	jmp    0x8cea
    8cea:	mov    r13,QWORD PTR [r12+0x48]
    8cef:	mov    r14,QWORD PTR [r12+0x50]
    8cf4:	mov    rcx,r13
    8cf7:	mov    r15,r14
    8cfa:	add    r15,rcx
    8cfd:	movdqu xmm2,XMMWORD PTR [r15]
    8d02:	movdqa xmm0,xmm2
    8d06:	movdqu XMMWORD PTR [r12+0x120],xmm0
    8d10:	mov    r14,r13
    8d13:	add    r14,0x10
    8d17:	mov    QWORD PTR [r12+0x48],r14
    8d1c:	mov    r13,r14
    8d1f:	sub    r13,0x200
    8d26:	pushf
    8d27:	pop    rdx
    8d28:	mov    r10d,edx
    8d2b:	and    r10d,0xc0
    8d32:	shl    r10d,0x18
    8d36:	mov    r11d,edx
    8d39:	and    r11d,0x1
    8d3d:	shl    r11d,0x1d
    8d41:	or     r10d,r11d
    8d44:	mov    r11d,edx
    8d47:	and    r11d,0x800
    8d4e:	shl    r11d,0x11
    8d52:	or     r10d,r11d
    8d55:	mov    r11d,0xf0000000
    8d5b:	and    r11,r10
    8d5e:	movabs rsi,0xffffffff0fffffff
    8d68:	and    rbx,rsi
    8d6b:	or     rbx,r11
    8d6e:	btc    rbx,0x1d
    8d73:	mov    r13,QWORD PTR [r12+0x128]
    8d7b:	mov    r14d,0x0
    8d81:	mov    QWORD PTR [r12+0x130],r13
    8d89:	mov    QWORD PTR [r12+0x138],r14
    8d91:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    8d9b:	movdqa xmm2,xmm0
    8d9f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    8da9:	movdqa xmm3,xmm0
    8dad:	cmp    DWORD PTR [r12+0x310],0x0
    8db6:	jne    0x8e50
    8dbc:	movdqa xmm0,xmm2
    8dc0:	movdqa xmm1,xmm3
    8dc4:	movq   rax,xmm0
    8dc9:	add    rax,rax
    8dcc:	je     0x8de2
    8dce:	shr    rax,0x35
    8dd2:	sub    eax,0x201
    8dd7:	cmp    eax,0x3fc
    8ddc:	ja     0x8e50
    8de2:	movq   rax,xmm1
    8de7:	add    rax,rax
    8dea:	je     0x8e00
    8dec:	shr    rax,0x35
    8df0:	sub    eax,0x201
    8df5:	cmp    eax,0x3fc
    8dfa:	ja     0x8e50
    8e00:	movq   xmm0,xmm0
    8e04:	movq   xmm1,xmm1
    8e08:	stmxcsr DWORD PTR [rsp+0x100]
    8e10:	mov    DWORD PTR [rsp+0x104],0x1f80
    8e1b:	ldmxcsr DWORD PTR [rsp+0x104]
    8e23:	addsd  xmm0,xmm1
    8e27:	stmxcsr DWORD PTR [rsp+0x104]
    8e2f:	ldmxcsr DWORD PTR [rsp+0x100]
    8e37:	mov    eax,DWORD PTR [rsp+0x104]
    8e3e:	shr    eax,1
    8e40:	and    eax,0x10
    8e43:	or     DWORD PTR [r12+0x314],eax
    8e4b:	jmp    0x8efd
    8e50:	movdqa xmm0,xmm2
    8e54:	movdqa xmm1,xmm3
    8e58:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    8e61:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    8e6a:	mov    QWORD PTR [r12+0x378],0x3
    8e76:	movdqu XMMWORD PTR [rsp],xmm2
    8e7b:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    8e81:	mov    QWORD PTR [r12+0x108],rbx
    8e89:	stmxcsr DWORD PTR [r12-0x28]
    8e8f:	ldmxcsr DWORD PTR [r12-0x38]
    8e95:	lea    rdi,[rsp+0xf0]
    8e9d:	lea    rsi,[rsp+0xd0]
    8ea5:	lea    rdx,[rsp+0xe0]
    8ead:	mov    ecx,0xc
    8eb2:	mov    r8d,DWORD PTR [r12+0x310]
    8eba:	lea    r9,[r12+0x314]
    8ec2:	movabs r11,0x5b9960291750
    8ecc:	call   r11
    8ecf:	ldmxcsr DWORD PTR [r12-0x28]
    8ed5:	movdqu xmm2,XMMWORD PTR [rsp]
    8eda:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8ee0:	mov    rbx,QWORD PTR [r12+0x108]
    8ee8:	mov    QWORD PTR [r12+0x378],0x2
    8ef4:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    8efd:	movdqa xmm4,xmm0
    8f01:	movdqa xmm0,xmm4
    8f05:	movdqu XMMWORD PTR [r12+0x110],xmm0
    8f0f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    8f19:	movdqa xmm2,xmm0
    8f1d:	cmp    DWORD PTR [r12+0x310],0x0
    8f26:	jne    0x8fc0
    8f2c:	movdqa xmm0,xmm4
    8f30:	movdqa xmm1,xmm2
    8f34:	movq   rax,xmm0
    8f39:	add    rax,rax
    8f3c:	je     0x8f52
    8f3e:	shr    rax,0x35
    8f42:	sub    eax,0x201
    8f47:	cmp    eax,0x3fc
    8f4c:	ja     0x8fc0
    8f52:	movq   rax,xmm1
    8f57:	add    rax,rax
    8f5a:	je     0x8f70
    8f5c:	shr    rax,0x35
    8f60:	sub    eax,0x201
    8f65:	cmp    eax,0x3fc
    8f6a:	ja     0x8fc0
    8f70:	movq   xmm0,xmm0
    8f74:	movq   xmm1,xmm1
    8f78:	stmxcsr DWORD PTR [rsp+0x100]
    8f80:	mov    DWORD PTR [rsp+0x104],0x1f80
    8f8b:	ldmxcsr DWORD PTR [rsp+0x104]
    8f93:	addsd  xmm0,xmm1
    8f97:	stmxcsr DWORD PTR [rsp+0x104]
    8f9f:	ldmxcsr DWORD PTR [rsp+0x100]
    8fa7:	mov    eax,DWORD PTR [rsp+0x104]
    8fae:	shr    eax,1
    8fb0:	and    eax,0x10
    8fb3:	or     DWORD PTR [r12+0x314],eax
    8fbb:	jmp    0x906d
    8fc0:	movdqa xmm0,xmm4
    8fc4:	movdqa xmm1,xmm2
    8fc8:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    8fd1:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    8fda:	mov    QWORD PTR [r12+0x378],0x3
    8fe6:	movdqu XMMWORD PTR [rsp],xmm2
    8feb:	movdqu XMMWORD PTR [rsp+0x20],xmm4
    8ff1:	mov    QWORD PTR [r12+0x108],rbx
    8ff9:	stmxcsr DWORD PTR [r12-0x28]
    8fff:	ldmxcsr DWORD PTR [r12-0x38]
    9005:	lea    rdi,[rsp+0xf0]
    900d:	lea    rsi,[rsp+0xd0]
    9015:	lea    rdx,[rsp+0xe0]
    901d:	mov    ecx,0xc
    9022:	mov    r8d,DWORD PTR [r12+0x310]
    902a:	lea    r9,[r12+0x314]
    9032:	movabs r11,0x5b9960291750
    903c:	call   r11
    903f:	ldmxcsr DWORD PTR [r12-0x28]
    9045:	movdqu xmm2,XMMWORD PTR [rsp]
    904a:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
    9050:	mov    rbx,QWORD PTR [r12+0x108]
    9058:	mov    QWORD PTR [r12+0x378],0x2
    9064:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    906d:	movdqa xmm3,xmm0
    9071:	movdqa xmm0,xmm3
    9075:	movdqu XMMWORD PTR [r12+0x110],xmm0
    907f:	cmp    QWORD PTR [r12+0x380],0x0
    9088:	je     0x90bc
    908e:	mov    eax,0x410700
    9093:	mov    QWORD PTR [r12+0x100],rax
    909b:	mov    QWORD PTR [r12+0x108],rbx
    90a3:	add    rsp,0x140
    90aa:	mov    eax,0xc
    90af:	movabs r11,0x5b99604255f0
    90b9:	jmp    r11
    90bc:	test   ebx,0x40000000
    90c2:	je     0x8cea
    90c8:	jmp    0x90cd
    90cd:	mov    r13,QWORD PTR [r12+0xf8]
    90d5:	mov    r14,r13
    90d8:	add    r14,0x1d0
    90df:	mov    r15,r14
    90e2:	add    r15,0x8
    90e6:	mov    rbp,QWORD PTR [r14]
    90e9:	mov    r14,QWORD PTR [r15]
    90ec:	mov    QWORD PTR [r12+0xa0],rbp
    90f4:	mov    QWORD PTR [r12+0x98],r14
    90fc:	mov    r14,QWORD PTR [r12+0x40]
    9101:	mov    r15,r14
    9104:	add    r15,0xcc0
    910b:	mov    r14,QWORD PTR [r12+0x110]
    9113:	mov    QWORD PTR [r15],r14
    9116:	mov    r14d,0x0
    911c:	mov    DWORD PTR [r12+0x32c],r14d
    9124:	mov    r14,r13
    9127:	add    r14,0x1c0
    912e:	mov    r15,r14
    9131:	add    r15,0x8
    9135:	mov    rbp,QWORD PTR [r14]
    9138:	mov    r14,QWORD PTR [r15]
    913b:	mov    QWORD PTR [r12+0xe8],rbp
    9143:	mov    QWORD PTR [r12+0xf0],r14
    914b:	mov    r14,r13
    914e:	add    r14,0x1b0
    9155:	mov    r13,r14
    9158:	add    r13,0x8
    915c:	mov    r15,QWORD PTR [r14]
    915f:	mov    r14,QWORD PTR [r13+0x0]
    9163:	mov    r13d,0x0
    9169:	mov    QWORD PTR [r12+0x1a0],r15
    9171:	mov    QWORD PTR [r12+0x1a8],r13
    9179:	mov    r13d,0x0
    917f:	mov    QWORD PTR [r12+0x190],r14
    9187:	mov    QWORD PTR [r12+0x198],r13
    918f:	mov    r13,QWORD PTR [r12+0xf8]
    9197:	mov    r14,r13
    919a:	add    r14,0x1a0
    91a1:	mov    r15,r14
    91a4:	add    r15,0x8
    91a8:	mov    rbp,QWORD PTR [r14]
    91ab:	mov    r14,QWORD PTR [r15]
    91ae:	mov    r15d,0x0
    91b4:	mov    QWORD PTR [r12+0x1c0],rbp
    91bc:	mov    QWORD PTR [r12+0x1c8],r15
    91c4:	mov    r15d,0x0
    91ca:	mov    QWORD PTR [r12+0x1b0],r14
    91d2:	mov    QWORD PTR [r12+0x1b8],r15
    91da:	mov    r14,r13
    91dd:	add    r14,0x190
    91e4:	mov    r13,r14
    91e7:	add    r13,0x8
    91eb:	mov    r15,QWORD PTR [r14]
    91ee:	mov    r14,QWORD PTR [r13+0x0]
    91f2:	mov    r13d,0x0
    91f8:	mov    QWORD PTR [r12+0x1e0],r15
    9200:	mov    QWORD PTR [r12+0x1e8],r13
    9208:	mov    r13d,0x0
    920e:	mov    QWORD PTR [r12+0x1d0],r14
    9216:	mov    QWORD PTR [r12+0x1d8],r13
    921e:	mov    r13,QWORD PTR [r12+0xf8]
    9226:	mov    r14,r13
    9229:	add    r14,0x180
    9230:	mov    r15,r14
    9233:	add    r15,0x8
    9237:	mov    rbp,QWORD PTR [r14]
    923a:	mov    r14,QWORD PTR [r15]
    923d:	mov    r15d,0x0
    9243:	mov    QWORD PTR [r12+0x200],rbp
    924b:	mov    QWORD PTR [r12+0x208],r15
    9253:	mov    r15d,0x0
    9259:	mov    QWORD PTR [r12+0x1f0],r14
    9261:	mov    QWORD PTR [r12+0x1f8],r15
    9269:	mov    r14,r13
    926c:	add    r14,0x1e0
    9273:	mov    QWORD PTR [r12+0xf8],r14
    927b:	cmp    QWORD PTR [r12+0x380],0x0
    9284:	je     0x92b8
    928a:	mov    eax,0x410724
    928f:	mov    QWORD PTR [r12+0x100],rax
    9297:	mov    QWORD PTR [r12+0x108],rbx
    929f:	add    rsp,0x140
    92a6:	mov    eax,0xc
    92ab:	movabs r11,0x5b99604255f0
    92b5:	jmp    r11
    92b8:	mov    r13,QWORD PTR [r12+0xf0]
    92c0:	mov    QWORD PTR [r12+0x100],r13
    92c8:	mov    QWORD PTR [r12+0x108],rbx
    92d0:	mov    rdi,QWORD PTR [r12+0x100]
    92d8:	add    rsp,0x140
    92df:	movabs r11,0x5b9960425370
    92e9:	jmp    r11
    92ec:	mov    r13d,DWORD PTR [r12+0x98]
    92f4:	mov    r14d,DWORD PTR [r12]
    92f8:	mov    ecx,r13d
    92fb:	mov    r15d,r14d
    92fe:	add    r15d,ecx
    9301:	mov    QWORD PTR [r12],r15
    9305:	mov    r13d,0x4103f8
    930b:	mov    QWORD PTR [r12+0xf0],r13
    9313:	mov    r13d,0x4109a4
    9319:	mov    QWORD PTR [r12+0x100],r13
    9321:	mov    QWORD PTR [r12+0x108],rbx
    9329:	mov    edi,0x4109a4
    932e:	mov    QWORD PTR [r12+0x100],rdi
    9336:	add    rsp,0x140
    933d:	nop    DWORD PTR [rax]
    9340:	jmp    QWORD PTR [rip+0x2]        # 0x9348
    9346:	xchg   ax,ax
    9348:	xor    BYTE PTR [rcx],ch
    934a:	nop
    934b:	(bad)
    934c:	fidiv  WORD PTR [rax+rax*1+0x0]
    9350:	push   0xffffffffde0690c5
    9355:	je     0x9357
    9357:	add    BYTE PTR [rcx-0x45],cl
    935a:	jo     0x93af
    935c:	rex.X (bad)
    935e:	cdq
    935f:	pop    rbx
    9360:	add    BYTE PTR [rax],al
    9362:	jmp    r11
    9365:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    9370:	sub    rsp,0x140
    9377:	jmp    0xc3
    937c:	nop    DWORD PTR [rax+0x0]
    9380:	sub    rsp,0x140
    9387:	jmp    0x257
    938c:	nop    DWORD PTR [rax+0x0]
    9390:	sub    rsp,0x140
    9397:	jmp    0xa12
    939c:	nop    DWORD PTR [rax+0x0]
    93a0:	sub    rsp,0x140
    93a7:	jmp    0x107e
    93ac:	nop    DWORD PTR [rax+0x0]
    93b0:	sub    rsp,0x140
    93b7:	jmp    0x108e
    93bc:	nop    DWORD PTR [rax+0x0]
    93c0:	sub    rsp,0x140
    93c7:	jmp    0x8bf9
    93cc:	nop    DWORD PTR [rax+0x0]
    93d0:	sub    rsp,0x140
    93d7:	jmp    0x8caf
    93dc:	nop    DWORD PTR [rax+0x0]
    93e0:	sub    rsp,0x140
    93e7:	jmp    0x8cea
    93ec:	nop    DWORD PTR [rax+0x0]
    93f0:	sub    rsp,0x140
    93f7:	jmp    0x90cd
    93fc:	nop    DWORD PTR [rax+0x0]
    9400:	sub    rsp,0x140
    9407:	jmp    0x92ec
