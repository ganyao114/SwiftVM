
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/baseline/0/1.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x50
       4:	mov    r13,QWORD PTR [r12]
       8:	mov    r14,r13
       b:	add    r14,0x20
       f:	mov    r15,QWORD PTR [r14]
      12:	mov    QWORD PTR [r12+0x40],r15
      17:	mov    r14,QWORD PTR [r12+0x10]
      1c:	mov    rcx,r14
      1f:	mov    rbp,r15
      22:	add    rbp,rcx
      25:	mov    QWORD PTR [r12+0x40],rbp
      2a:	mov    r15,r13
      2d:	add    r15,0x20
      31:	mov    QWORD PTR [r15],rbp
      34:	mov    r13d,0x0
      3a:	mov    DWORD PTR [r12+0x32c],r13d
      42:	mov    rax,r14
      45:	test   rax,rax
      48:	sete   al
      4b:	movzx  eax,al
      4e:	and    eax,0x1
      51:	mov    r13,rax
      54:	mov    rax,r13
      57:	and    eax,0x1
      5a:	test   rax,rax
      5d:	jne    0x31fd
      63:	jmp    0x68
      68:	mov    r13,QWORD PTR [r12+0xf8]
      70:	mov    r14,r13
      73:	sub    r14,0x150
      7a:	mov    QWORD PTR [r12+0xf8],r14
      82:	mov    r13,QWORD PTR [r12]
      86:	mov    r15,r13
      89:	add    r15,0x68
      8d:	mov    rbp,QWORD PTR [r15]
      90:	mov    QWORD PTR [r12+0x88],rbp
      98:	mov    r15,r13
      9b:	add    r15,0x28
      9f:	mov    QWORD PTR [r12+0x40],r15
      a4:	mov    r13,r14
      a7:	add    r13,0x0
      ab:	mov    QWORD PTR [r12+0x48],r13
      b0:	mov    r13d,0x420000
      b6:	mov    QWORD PTR [r12+0x50],r13
      bb:	mov    r13d,0x420000
      c1:	mov    r15,r13
      c4:	add    r15,0xb90
      cb:	mov    QWORD PTR [r12+0x50],r15
      d0:	mov    r13,r14
      d3:	add    r13,0x100
      da:	mov    r14,r13
      dd:	add    r14,0x8
      e1:	mov    r15,QWORD PTR [r12+0xe8]
      e9:	mov    rbp,QWORD PTR [r12+0xd8]
      f1:	mov    QWORD PTR [r13+0x0],r15
      f5:	mov    r13d,0x0
      fb:	mov    DWORD PTR [r12+0x32c],r13d
     103:	mov    QWORD PTR [r14],rbp
     106:	mov    r13d,0x0
     10c:	mov    DWORD PTR [r12+0x32c],r13d
     114:	mov    r13,QWORD PTR [r12+0xf8]
     11c:	mov    r14,r13
     11f:	add    r14,0x110
     126:	mov    r15,r14
     129:	add    r15,0x8
     12d:	mov    rbp,QWORD PTR [r12+0xd0]
     135:	mov    r8,QWORD PTR [r12+0xc8]
     13d:	mov    QWORD PTR [r14],rbp
     140:	mov    r14d,0x0
     146:	mov    DWORD PTR [r12+0x32c],r14d
     14e:	mov    QWORD PTR [r15],r8
     151:	mov    r14d,0x0
     157:	mov    DWORD PTR [r12+0x32c],r14d
     15f:	mov    r14,r13
     162:	add    r14,0x120
     169:	mov    r15,r14
     16c:	add    r15,0x8
     170:	mov    rbp,QWORD PTR [r12+0xc0]
     178:	mov    r8,QWORD PTR [r12+0xb8]
     180:	mov    QWORD PTR [r14],rbp
     183:	mov    r14d,0x0
     189:	mov    DWORD PTR [r12+0x32c],r14d
     191:	mov    QWORD PTR [r15],r8
     194:	mov    r14d,0x0
     19a:	mov    DWORD PTR [r12+0x32c],r14d
     1a2:	mov    r14,r13
     1a5:	add    r14,0x130
     1ac:	mov    r15,r14
     1af:	add    r15,0x8
     1b3:	mov    rbp,QWORD PTR [r12+0xb0]
     1bb:	mov    r8,QWORD PTR [r12+0xa8]
     1c3:	mov    QWORD PTR [r14],rbp
     1c6:	mov    r14d,0x0
     1cc:	mov    DWORD PTR [r12+0x32c],r14d
     1d4:	mov    QWORD PTR [r15],r8
     1d7:	mov    r14d,0x0
     1dd:	mov    DWORD PTR [r12+0x32c],r14d
     1e5:	mov    r14,r13
     1e8:	add    r14,0x140
     1ef:	mov    r13,r14
     1f2:	add    r13,0x8
     1f6:	mov    r15,QWORD PTR [r12+0xa0]
     1fe:	mov    rbp,QWORD PTR [r12+0x98]
     206:	mov    QWORD PTR [r14],r15
     209:	mov    r14d,0x0
     20f:	mov    DWORD PTR [r12+0x32c],r14d
     217:	mov    QWORD PTR [r13+0x0],rbp
     21b:	mov    r13d,0x0
     221:	mov    DWORD PTR [r12+0x32c],r13d
     229:	jmp    0x22e
     22e:	mov    r13,QWORD PTR [r12+0x8]
     233:	mov    r14,r13
     236:	add    r14,0x1
     23a:	movzx  r15d,BYTE PTR [r13+0x0]
     23f:	mov    QWORD PTR [r12+0x58],r15
     244:	mov    QWORD PTR [r12+0x8],r14
     249:	mov    r13,QWORD PTR [r12+0x88]
     251:	mov    r14,r13
     254:	add    r14,0x1
     258:	mov    QWORD PTR [r12+0x60],r14
     25d:	mov    r15,QWORD PTR [r12]
     261:	mov    rbp,r15
     264:	add    rbp,0x68
     268:	mov    QWORD PTR [rbp+0x0],r14
     26c:	mov    r14d,0x0
     272:	mov    DWORD PTR [r12+0x32c],r14d
     27a:	mov    rcx,r13
     27d:	mov    r14,r15
     280:	add    r14,rcx
     283:	mov    QWORD PTR [r12+0x60],r14
     288:	mov    r13,r14
     28b:	add    r13,0x28
     28f:	movzx  r14d,BYTE PTR [r12+0x58]
     295:	mov    BYTE PTR [r13+0x0],r14b
     299:	mov    r13d,0x0
     29f:	mov    DWORD PTR [r12+0x32c],r13d
     2a7:	mov    r13,r15
     2aa:	add    r13,0x68
     2ae:	mov    r14,QWORD PTR [r13+0x0]
     2b2:	mov    QWORD PTR [r12+0x88],r14
     2ba:	mov    r13,r14
     2bd:	sub    r13,0x40
     2c1:	pushf
     2c2:	pop    rdx
     2c3:	mov    r10d,edx
     2c6:	and    r10d,0xc0
     2cd:	shl    r10d,0x18
     2d1:	mov    r11d,edx
     2d4:	and    r11d,0x1
     2d8:	shl    r11d,0x1d
     2dc:	or     r10d,r11d
     2df:	mov    r11d,edx
     2e2:	and    r11d,0x800
     2e9:	shl    r11d,0x11
     2ed:	or     r10d,r11d
     2f0:	mov    r11d,0xf0000000
     2f6:	and    r11,r10
     2f9:	movabs rsi,0xffffffff0fffffff
     303:	and    rbx,rsi
     306:	or     rbx,r11
     309:	btc    rbx,0x1d
     30e:	cmp    QWORD PTR [r12+0x380],0x0
     317:	je     0x348
     31d:	mov    eax,0x41078c
     322:	mov    QWORD PTR [r12+0x100],rax
     32a:	mov    QWORD PTR [r12+0x108],rbx
     332:	add    rsp,0x50
     336:	mov    eax,0xc
     33b:	movabs r11,0x5b99604255f0
     345:	jmp    r11
     348:	test   ebx,0x40000000
     34e:	je     0x30db
     354:	jmp    0x359
     359:	mov    rax,QWORD PTR [r12+0x40]
     35e:	mov    QWORD PTR [rsp],rax
     362:	mov    eax,0x0
     367:	mov    QWORD PTR [rsp+0x20],rax
     36c:	mov    eax,0x0
     371:	mov    QWORD PTR [rsp+0x18],rax
     376:	mov    eax,0x0
     37b:	mov    QWORD PTR [rsp+0x10],rax
     380:	mov    eax,0x0
     385:	mov    QWORD PTR [rsp+0x8],rax
     38a:	mov    rdi,QWORD PTR [rsp]
     38e:	movzx  r9d,BYTE PTR [rdi]
     392:	mov    r13,r9
     395:	mov    rcx,r13
     398:	mov    r9,QWORD PTR [rsp+0x20]
     39d:	or     r9,rcx
     3a0:	mov    r13,QWORD PTR [rsp]
     3a4:	add    r13,0x1
     3a8:	movzx  r8d,BYTE PTR [r13+0x0]
     3ad:	mov    r13,r8
     3b0:	mov    rcx,r13
     3b3:	mov    r8,QWORD PTR [rsp+0x18]
     3b8:	or     r8,rcx
     3bb:	mov    r13,QWORD PTR [rsp]
     3bf:	add    r13,0x2
     3c3:	movzx  ebp,BYTE PTR [r13+0x0]
     3c8:	mov    r13,rbp
     3cb:	mov    rcx,r13
     3ce:	mov    rbp,QWORD PTR [rsp+0x10]
     3d3:	or     rbp,rcx
     3d6:	mov    r13,QWORD PTR [rsp]
     3da:	add    r13,0x3
     3de:	movzx  r15d,BYTE PTR [r13+0x0]
     3e3:	mov    r13,r15
     3e6:	mov    rcx,r13
     3e9:	mov    r15,QWORD PTR [rsp+0x8]
     3ee:	or     r15,rcx
     3f1:	mov    r13,QWORD PTR [rsp]
     3f5:	add    r13,0x4
     3f9:	movzx  r14d,BYTE PTR [r13+0x0]
     3fe:	mov    r13,r14
     401:	shl    r13,0x8
     405:	mov    rcx,r13
     408:	mov    r14,r9
     40b:	or     r14,rcx
     40e:	mov    r13,QWORD PTR [rsp]
     412:	add    r13,0x5
     416:	movzx  r9d,BYTE PTR [r13+0x0]
     41b:	mov    r13,r9
     41e:	shl    r13,0x8
     422:	mov    rcx,r13
     425:	mov    r9,r8
     428:	or     r9,rcx
     42b:	mov    r13,QWORD PTR [rsp]
     42f:	add    r13,0x6
     433:	movzx  r8d,BYTE PTR [r13+0x0]
     438:	mov    r13,r8
     43b:	shl    r13,0x8
     43f:	mov    rcx,r13
     442:	mov    r8,rbp
     445:	or     r8,rcx
     448:	mov    r13,QWORD PTR [rsp]
     44c:	add    r13,0x7
     450:	movzx  ebp,BYTE PTR [r13+0x0]
     455:	mov    r13,rbp
     458:	shl    r13,0x8
     45c:	mov    rcx,r13
     45f:	mov    rbp,r15
     462:	or     rbp,rcx
     465:	mov    r13,QWORD PTR [rsp]
     469:	add    r13,0x8
     46d:	movzx  r15d,BYTE PTR [r13+0x0]
     472:	mov    r13,r15
     475:	shl    r13,0x10
     479:	mov    rcx,r13
     47c:	mov    r15,r14
     47f:	or     r15,rcx
     482:	mov    r13,QWORD PTR [rsp]
     486:	add    r13,0x9
     48a:	movzx  r14d,BYTE PTR [r13+0x0]
     48f:	mov    r13,r14
     492:	shl    r13,0x10
     496:	mov    rcx,r13
     499:	mov    r14,r9
     49c:	or     r14,rcx
     49f:	mov    r13,QWORD PTR [rsp]
     4a3:	add    r13,0xa
     4a7:	movzx  r9d,BYTE PTR [r13+0x0]
     4ac:	mov    r13,r9
     4af:	shl    r13,0x10
     4b3:	mov    rcx,r13
     4b6:	mov    r9,r8
     4b9:	or     r9,rcx
     4bc:	mov    r13,QWORD PTR [rsp]
     4c0:	add    r13,0xb
     4c4:	movzx  r8d,BYTE PTR [r13+0x0]
     4c9:	mov    r13,r8
     4cc:	shl    r13,0x10
     4d0:	mov    rcx,r13
     4d3:	mov    r8,rbp
     4d6:	or     r8,rcx
     4d9:	mov    r13,QWORD PTR [rsp]
     4dd:	add    r13,0xc
     4e1:	movzx  ebp,BYTE PTR [r13+0x0]
     4e6:	mov    r13,rbp
     4e9:	shl    r13,0x18
     4ed:	mov    rcx,r13
     4f0:	mov    rbp,r15
     4f3:	or     rbp,rcx
     4f6:	mov    r13,QWORD PTR [rsp]
     4fa:	add    r13,0xd
     4fe:	movzx  r15d,BYTE PTR [r13+0x0]
     503:	mov    r13,r15
     506:	shl    r13,0x18
     50a:	mov    rcx,r13
     50d:	mov    r15,r14
     510:	or     r15,rcx
     513:	mov    r13,QWORD PTR [rsp]
     517:	add    r13,0xe
     51b:	movzx  r14d,BYTE PTR [r13+0x0]
     520:	mov    r13,r14
     523:	shl    r13,0x18
     527:	mov    rcx,r13
     52a:	mov    r14,r9
     52d:	or     r14,rcx
     530:	mov    r13,QWORD PTR [rsp]
     534:	add    r13,0xf
     538:	movzx  r9d,BYTE PTR [r13+0x0]
     53d:	mov    r13,r9
     540:	shl    r13,0x18
     544:	mov    rcx,r13
     547:	mov    r9,r8
     54a:	or     r9,rcx
     54d:	mov    r13,QWORD PTR [rsp]
     551:	add    r13,0x10
     555:	movzx  r8d,BYTE PTR [r13+0x0]
     55a:	mov    r13,r8
     55d:	shl    r13,0x20
     561:	mov    rcx,r13
     564:	mov    r8,rbp
     567:	or     r8,rcx
     56a:	mov    r13,QWORD PTR [rsp]
     56e:	add    r13,0x11
     572:	movzx  ebp,BYTE PTR [r13+0x0]
     577:	mov    r13,rbp
     57a:	shl    r13,0x20
     57e:	mov    rcx,r13
     581:	mov    rbp,r15
     584:	or     rbp,rcx
     587:	mov    r13,QWORD PTR [rsp]
     58b:	add    r13,0x12
     58f:	movzx  r15d,BYTE PTR [r13+0x0]
     594:	mov    r13,r15
     597:	shl    r13,0x20
     59b:	mov    rcx,r13
     59e:	mov    r15,r14
     5a1:	or     r15,rcx
     5a4:	mov    r13,QWORD PTR [rsp]
     5a8:	add    r13,0x13
     5ac:	movzx  r14d,BYTE PTR [r13+0x0]
     5b1:	mov    r13,r14
     5b4:	shl    r13,0x20
     5b8:	mov    rcx,r13
     5bb:	mov    r14,r9
     5be:	or     r14,rcx
     5c1:	mov    r13,QWORD PTR [rsp]
     5c5:	add    r13,0x14
     5c9:	movzx  r9d,BYTE PTR [r13+0x0]
     5ce:	mov    r13,r9
     5d1:	shl    r13,0x28
     5d5:	mov    rcx,r13
     5d8:	mov    r9,r8
     5db:	or     r9,rcx
     5de:	mov    r13,QWORD PTR [rsp]
     5e2:	add    r13,0x15
     5e6:	movzx  r8d,BYTE PTR [r13+0x0]
     5eb:	mov    r13,r8
     5ee:	shl    r13,0x28
     5f2:	mov    rcx,r13
     5f5:	mov    r8,rbp
     5f8:	or     r8,rcx
     5fb:	mov    r13,QWORD PTR [rsp]
     5ff:	add    r13,0x16
     603:	movzx  ebp,BYTE PTR [r13+0x0]
     608:	mov    r13,rbp
     60b:	shl    r13,0x28
     60f:	mov    rcx,r13
     612:	mov    rbp,r15
     615:	or     rbp,rcx
     618:	mov    r13,QWORD PTR [rsp]
     61c:	add    r13,0x17
     620:	movzx  r15d,BYTE PTR [r13+0x0]
     625:	mov    r13,r15
     628:	shl    r13,0x28
     62c:	mov    rcx,r13
     62f:	mov    r15,r14
     632:	or     r15,rcx
     635:	mov    r13,QWORD PTR [rsp]
     639:	add    r13,0x18
     63d:	movzx  r14d,BYTE PTR [r13+0x0]
     642:	mov    r13,r14
     645:	shl    r13,0x30
     649:	mov    rcx,r13
     64c:	mov    r14,r9
     64f:	or     r14,rcx
     652:	mov    r13,QWORD PTR [rsp]
     656:	add    r13,0x19
     65a:	movzx  r9d,BYTE PTR [r13+0x0]
     65f:	mov    r13,r9
     662:	shl    r13,0x30
     666:	mov    rcx,r13
     669:	mov    r9,r8
     66c:	or     r9,rcx
     66f:	mov    r13,QWORD PTR [rsp]
     673:	add    r13,0x1a
     677:	movzx  r8d,BYTE PTR [r13+0x0]
     67c:	mov    r13,r8
     67f:	shl    r13,0x30
     683:	mov    rcx,r13
     686:	mov    r8,rbp
     689:	or     r8,rcx
     68c:	mov    r13,QWORD PTR [rsp]
     690:	add    r13,0x1b
     694:	movzx  ebp,BYTE PTR [r13+0x0]
     699:	mov    r13,rbp
     69c:	shl    r13,0x30
     6a0:	mov    rcx,r13
     6a3:	mov    rbp,r15
     6a6:	or     rbp,rcx
     6a9:	mov    r13,QWORD PTR [rsp]
     6ad:	add    r13,0x1c
     6b1:	movzx  r15d,BYTE PTR [r13+0x0]
     6b6:	mov    r13,r15
     6b9:	shl    r13,0x38
     6bd:	mov    rcx,r13
     6c0:	mov    rax,r14
     6c3:	or     rax,rcx
     6c6:	mov    QWORD PTR [rsp+0x40],rax
     6cb:	mov    r13,QWORD PTR [rsp]
     6cf:	add    r13,0x1d
     6d3:	movzx  r14d,BYTE PTR [r13+0x0]
     6d8:	mov    r13,r14
     6db:	shl    r13,0x38
     6df:	mov    rcx,r13
     6e2:	mov    rax,r9
     6e5:	or     rax,rcx
     6e8:	mov    QWORD PTR [rsp+0x30],rax
     6ed:	mov    r13,QWORD PTR [rsp]
     6f1:	add    r13,0x1e
     6f5:	movzx  r9d,BYTE PTR [r13+0x0]
     6fa:	mov    r13,r9
     6fd:	shl    r13,0x38
     701:	mov    rcx,r13
     704:	mov    rax,r8
     707:	or     rax,rcx
     70a:	mov    QWORD PTR [rsp+0x28],rax
     70f:	mov    r13,QWORD PTR [rsp]
     713:	add    r13,0x1f
     717:	movzx  r8d,BYTE PTR [r13+0x0]
     71c:	mov    r13,r8
     71f:	shl    r13,0x38
     723:	mov    rcx,r13
     726:	mov    rax,rbp
     729:	or     rax,rcx
     72c:	mov    QWORD PTR [rsp+0x38],rax
     731:	mov    r13,QWORD PTR [rsp]
     735:	add    r13,0x20
     739:	movzx  ebp,BYTE PTR [r13+0x0]
     73e:	mov    r13,rbp
     741:	mov    rcx,r13
     744:	mov    rbp,QWORD PTR [rsp+0x20]
     749:	or     rbp,rcx
     74c:	mov    r13,QWORD PTR [rsp]
     750:	add    r13,0x21
     754:	movzx  r9d,BYTE PTR [r13+0x0]
     759:	mov    r13,r9
     75c:	mov    rcx,r13
     75f:	mov    r9,QWORD PTR [rsp+0x18]
     764:	or     r9,rcx
     767:	mov    r13,QWORD PTR [rsp]
     76b:	add    r13,0x22
     76f:	movzx  r14d,BYTE PTR [r13+0x0]
     774:	mov    r13,r14
     777:	mov    rcx,r13
     77a:	mov    r14,QWORD PTR [rsp+0x10]
     77f:	or     r14,rcx
     782:	mov    r13,QWORD PTR [rsp]
     786:	add    r13,0x23
     78a:	movzx  r8d,BYTE PTR [r13+0x0]
     78f:	mov    r13,r8
     792:	mov    rcx,r13
     795:	mov    r8,QWORD PTR [rsp+0x8]
     79a:	or     r8,rcx
     79d:	mov    r13,QWORD PTR [rsp]
     7a1:	add    r13,0x24
     7a5:	movzx  r15d,BYTE PTR [r13+0x0]
     7aa:	mov    r13,r15
     7ad:	shl    r13,0x8
     7b1:	mov    rcx,r13
     7b4:	mov    r15,rbp
     7b7:	or     r15,rcx
     7ba:	mov    r13,QWORD PTR [rsp]
     7be:	add    r13,0x25
     7c2:	movzx  ebp,BYTE PTR [r13+0x0]
     7c7:	mov    r13,rbp
     7ca:	shl    r13,0x8
     7ce:	mov    rcx,r13
     7d1:	mov    rbp,r9
     7d4:	or     rbp,rcx
     7d7:	mov    r13,QWORD PTR [rsp]
     7db:	add    r13,0x26
     7df:	movzx  r9d,BYTE PTR [r13+0x0]
     7e4:	mov    r13,r9
     7e7:	shl    r13,0x8
     7eb:	mov    rcx,r13
     7ee:	mov    r9,r14
     7f1:	or     r9,rcx
     7f4:	mov    r13,QWORD PTR [rsp]
     7f8:	add    r13,0x27
     7fc:	movzx  r14d,BYTE PTR [r13+0x0]
     801:	mov    r13,r14
     804:	shl    r13,0x8
     808:	mov    rcx,r13
     80b:	mov    r14,r8
     80e:	or     r14,rcx
     811:	mov    r13,QWORD PTR [rsp]
     815:	add    r13,0x28
     819:	movzx  r8d,BYTE PTR [r13+0x0]
     81e:	mov    r13,r8
     821:	shl    r13,0x10
     825:	mov    rcx,r13
     828:	mov    r8,r15
     82b:	or     r8,rcx
     82e:	mov    r13,QWORD PTR [rsp]
     832:	add    r13,0x29
     836:	movzx  r15d,BYTE PTR [r13+0x0]
     83b:	mov    r13,r15
     83e:	shl    r13,0x10
     842:	mov    rcx,r13
     845:	mov    r15,rbp
     848:	or     r15,rcx
     84b:	mov    r13,QWORD PTR [rsp]
     84f:	add    r13,0x2a
     853:	movzx  ebp,BYTE PTR [r13+0x0]
     858:	mov    r13,rbp
     85b:	shl    r13,0x10
     85f:	mov    rcx,r13
     862:	mov    rbp,r9
     865:	or     rbp,rcx
     868:	mov    r13,QWORD PTR [rsp]
     86c:	add    r13,0x2b
     870:	movzx  r9d,BYTE PTR [r13+0x0]
     875:	mov    r13,r9
     878:	shl    r13,0x10
     87c:	mov    rcx,r13
     87f:	mov    r9,r14
     882:	or     r9,rcx
     885:	mov    r13,QWORD PTR [rsp]
     889:	add    r13,0x2c
     88d:	movzx  r14d,BYTE PTR [r13+0x0]
     892:	mov    r13,r14
     895:	shl    r13,0x18
     899:	mov    rcx,r13
     89c:	mov    r14,r8
     89f:	or     r14,rcx
     8a2:	mov    r13,QWORD PTR [rsp]
     8a6:	add    r13,0x2d
     8aa:	movzx  r8d,BYTE PTR [r13+0x0]
     8af:	mov    r13,r8
     8b2:	shl    r13,0x18
     8b6:	mov    rcx,r13
     8b9:	mov    r8,r15
     8bc:	or     r8,rcx
     8bf:	mov    r13,QWORD PTR [rsp]
     8c3:	add    r13,0x2e
     8c7:	movzx  r15d,BYTE PTR [r13+0x0]
     8cc:	mov    r13,r15
     8cf:	shl    r13,0x18
     8d3:	mov    rcx,r13
     8d6:	mov    r15,rbp
     8d9:	or     r15,rcx
     8dc:	mov    r13,QWORD PTR [rsp]
     8e0:	add    r13,0x2f
     8e4:	movzx  ebp,BYTE PTR [r13+0x0]
     8e9:	mov    r13,rbp
     8ec:	shl    r13,0x18
     8f0:	mov    rcx,r13
     8f3:	mov    rbp,r9
     8f6:	or     rbp,rcx
     8f9:	mov    r13,QWORD PTR [rsp]
     8fd:	add    r13,0x30
     901:	movzx  r9d,BYTE PTR [r13+0x0]
     906:	mov    r13,r9
     909:	shl    r13,0x20
     90d:	mov    rcx,r13
     910:	mov    r9,r14
     913:	or     r9,rcx
     916:	mov    r13,QWORD PTR [rsp]
     91a:	add    r13,0x31
     91e:	movzx  r14d,BYTE PTR [r13+0x0]
     923:	mov    r13,r14
     926:	shl    r13,0x20
     92a:	mov    rcx,r13
     92d:	mov    r14,r8
     930:	or     r14,rcx
     933:	mov    r13,QWORD PTR [rsp]
     937:	add    r13,0x32
     93b:	movzx  r8d,BYTE PTR [r13+0x0]
     940:	mov    r13,r8
     943:	shl    r13,0x20
     947:	mov    rcx,r13
     94a:	mov    r8,r15
     94d:	or     r8,rcx
     950:	mov    r13,QWORD PTR [rsp]
     954:	add    r13,0x33
     958:	movzx  r15d,BYTE PTR [r13+0x0]
     95d:	mov    r13,r15
     960:	shl    r13,0x20
     964:	mov    rcx,r13
     967:	mov    r15,rbp
     96a:	or     r15,rcx
     96d:	mov    r13,QWORD PTR [rsp]
     971:	add    r13,0x34
     975:	movzx  ebp,BYTE PTR [r13+0x0]
     97a:	mov    r13,rbp
     97d:	shl    r13,0x28
     981:	mov    rcx,r13
     984:	mov    rbp,r9
     987:	or     rbp,rcx
     98a:	mov    r13,QWORD PTR [rsp]
     98e:	add    r13,0x35
     992:	movzx  r9d,BYTE PTR [r13+0x0]
     997:	mov    r13,r9
     99a:	shl    r13,0x28
     99e:	mov    rcx,r13
     9a1:	mov    r9,r14
     9a4:	or     r9,rcx
     9a7:	mov    r13,QWORD PTR [rsp]
     9ab:	add    r13,0x36
     9af:	movzx  r14d,BYTE PTR [r13+0x0]
     9b4:	mov    r13,r14
     9b7:	shl    r13,0x28
     9bb:	mov    rcx,r13
     9be:	mov    r14,r8
     9c1:	or     r14,rcx
     9c4:	mov    r13,QWORD PTR [rsp]
     9c8:	add    r13,0x37
     9cc:	movzx  r8d,BYTE PTR [r13+0x0]
     9d1:	mov    r13,r8
     9d4:	shl    r13,0x28
     9d8:	mov    rcx,r13
     9db:	mov    r8,r15
     9de:	or     r8,rcx
     9e1:	mov    r13,QWORD PTR [rsp]
     9e5:	add    r13,0x38
     9e9:	movzx  r15d,BYTE PTR [r13+0x0]
     9ee:	mov    r13,r15
     9f1:	shl    r13,0x30
     9f5:	mov    rcx,r13
     9f8:	mov    r15,rbp
     9fb:	or     r15,rcx
     9fe:	mov    r13,QWORD PTR [rsp]
     a02:	add    r13,0x39
     a06:	movzx  ebp,BYTE PTR [r13+0x0]
     a0b:	mov    r13,rbp
     a0e:	shl    r13,0x30
     a12:	mov    rcx,r13
     a15:	mov    rbp,r9
     a18:	or     rbp,rcx
     a1b:	mov    r13,QWORD PTR [rsp]
     a1f:	add    r13,0x3a
     a23:	movzx  r9d,BYTE PTR [r13+0x0]
     a28:	mov    r13,r9
     a2b:	shl    r13,0x30
     a2f:	mov    rcx,r13
     a32:	mov    r9,r14
     a35:	or     r9,rcx
     a38:	mov    r13,QWORD PTR [rsp]
     a3c:	add    r13,0x3b
     a40:	movzx  r14d,BYTE PTR [r13+0x0]
     a45:	mov    r13,r14
     a48:	shl    r13,0x30
     a4c:	mov    rcx,r13
     a4f:	mov    r14,r8
     a52:	or     r14,rcx
     a55:	mov    r13,QWORD PTR [rsp]
     a59:	add    r13,0x3c
     a5d:	movzx  r8d,BYTE PTR [r13+0x0]
     a62:	mov    r13,r8
     a65:	shl    r13,0x38
     a69:	mov    rcx,r13
     a6c:	mov    r8,r15
     a6f:	or     r8,rcx
     a72:	mov    r13,QWORD PTR [rsp]
     a76:	add    r13,0x3d
     a7a:	movzx  r15d,BYTE PTR [r13+0x0]
     a7f:	mov    r13,r15
     a82:	shl    r13,0x38
     a86:	mov    rcx,r13
     a89:	mov    r15,rbp
     a8c:	or     r15,rcx
     a8f:	mov    r13,QWORD PTR [rsp]
     a93:	add    r13,0x3e
     a97:	movzx  ebp,BYTE PTR [r13+0x0]
     a9c:	mov    r13,rbp
     a9f:	shl    r13,0x38
     aa3:	mov    rcx,r13
     aa6:	mov    rbp,r9
     aa9:	or     rbp,rcx
     aac:	mov    r13,QWORD PTR [rsp]
     ab0:	add    r13,0x3f
     ab4:	movzx  r9d,BYTE PTR [r13+0x0]
     ab9:	mov    r13,r9
     abc:	shl    r13,0x38
     ac0:	mov    rcx,r13
     ac3:	mov    r9,r14
     ac6:	or     r9,rcx
     ac9:	mov    rax,QWORD PTR [rsp+0x40]
     ace:	mov    QWORD PTR [r12+0x110],rax
     ad6:	mov    QWORD PTR [r12+0x118],r8
     ade:	mov    rax,QWORD PTR [rsp+0x30]
     ae3:	mov    QWORD PTR [r12+0x120],rax
     aeb:	mov    QWORD PTR [r12+0x128],r15
     af3:	mov    rax,QWORD PTR [rsp+0x28]
     af8:	mov    QWORD PTR [r12+0x130],rax
     b00:	mov    QWORD PTR [r12+0x138],rbp
     b08:	mov    rax,QWORD PTR [rsp+0x38]
     b0d:	mov    QWORD PTR [r12+0x140],rax
     b15:	mov    QWORD PTR [r12+0x148],r9
     b1d:	mov    r13d,0x0
     b23:	mov    QWORD PTR [r12+0x58],r13
     b28:	mov    r13d,0x0
     b2e:	mov    r14,QWORD PTR [rsp+0x30]
     b33:	mov    r15,r14
     b36:	and    r15,0xff
     b3d:	mov    r14,r15
     b40:	mov    r15,r14
     b43:	and    r15,0xffff
     b4a:	mov    r14,r15
     b4d:	mov    rcx,r14
     b50:	mov    r15,r13
     b53:	or     r15,rcx
     b56:	mov    r14,QWORD PTR [rsp+0x30]
     b5b:	shr    r14,0x8
     b5f:	mov    rbp,r14
     b62:	and    rbp,0xff
     b69:	mov    r14,rbp
     b6c:	mov    rbp,r14
     b6f:	and    rbp,0xffff
     b76:	mov    r14,rbp
     b79:	shl    r14,0x10
     b7d:	mov    rcx,r14
     b80:	mov    rbp,r15
     b83:	or     rbp,rcx
     b86:	mov    r14,QWORD PTR [rsp+0x30]
     b8b:	shr    r14,0x10
     b8f:	mov    r15,r14
     b92:	and    r15,0xff
     b99:	mov    r14,r15
     b9c:	mov    r15,r14
     b9f:	and    r15,0xffff
     ba6:	mov    r14,r15
     ba9:	shl    r14,0x20
     bad:	mov    rcx,r14
     bb0:	mov    r15,rbp
     bb3:	or     r15,rcx
     bb6:	mov    r14,QWORD PTR [rsp+0x30]
     bbb:	shr    r14,0x18
     bbf:	mov    rbp,r14
     bc2:	and    rbp,0xff
     bc9:	mov    r14,rbp
     bcc:	mov    rbp,r14
     bcf:	and    rbp,0xffff
     bd6:	mov    r14,rbp
     bd9:	shl    r14,0x30
     bdd:	mov    rcx,r14
     be0:	mov    rbp,r15
     be3:	or     rbp,rcx
     be6:	mov    r14,QWORD PTR [rsp+0x30]
     beb:	shr    r14,0x20
     bef:	mov    r15,r14
     bf2:	and    r15,0xff
     bf9:	mov    r14,r15
     bfc:	mov    r15,r14
     bff:	and    r15,0xffff
     c06:	mov    r14,r15
     c09:	mov    rcx,r14
     c0c:	mov    r15,r13
     c0f:	or     r15,rcx
     c12:	mov    r13,QWORD PTR [rsp+0x30]
     c17:	shr    r13,0x28
     c1b:	mov    r14,r13
     c1e:	and    r14,0xff
     c25:	mov    r13,r14
     c28:	mov    r14,r13
     c2b:	and    r14,0xffff
     c32:	mov    r13,r14
     c35:	shl    r13,0x10
     c39:	mov    rcx,r13
     c3c:	mov    r14,r15
     c3f:	or     r14,rcx
     c42:	mov    r13,QWORD PTR [rsp+0x30]
     c47:	shr    r13,0x30
     c4b:	mov    r15,r13
     c4e:	and    r15,0xff
     c55:	mov    r13,r15
     c58:	mov    r15,r13
     c5b:	and    r15,0xffff
     c62:	mov    r13,r15
     c65:	shl    r13,0x20
     c69:	mov    rcx,r13
     c6c:	mov    r15,r14
     c6f:	or     r15,rcx
     c72:	mov    r13,QWORD PTR [rsp+0x30]
     c77:	shr    r13,0x38
     c7b:	mov    r14,r13
     c7e:	and    r14,0xff
     c85:	mov    r13,r14
     c88:	mov    r14,r13
     c8b:	and    r14,0xffff
     c92:	mov    r13,r14
     c95:	shl    r13,0x30
     c99:	mov    rcx,r13
     c9c:	mov    r14,r15
     c9f:	or     r14,rcx
     ca2:	mov    QWORD PTR [r12+0x150],rbp
     caa:	mov    QWORD PTR [r12+0x158],r14
     cb2:	mov    r13d,0x0
     cb8:	mov    r14,QWORD PTR [rsp+0x28]
     cbd:	mov    r15,r14
     cc0:	and    r15,0xff
     cc7:	mov    r14,r15
     cca:	mov    r15,r14
     ccd:	and    r15,0xffff
     cd4:	mov    r14,r15
     cd7:	mov    rcx,r14
     cda:	mov    r15,r13
     cdd:	or     r15,rcx
     ce0:	mov    r14,QWORD PTR [rsp+0x28]
     ce5:	shr    r14,0x8
     ce9:	mov    rbp,r14
     cec:	and    rbp,0xff
     cf3:	mov    r14,rbp
     cf6:	mov    rbp,r14
     cf9:	and    rbp,0xffff
     d00:	mov    r14,rbp
     d03:	shl    r14,0x10
     d07:	mov    rcx,r14
     d0a:	mov    rbp,r15
     d0d:	or     rbp,rcx
     d10:	mov    r14,QWORD PTR [rsp+0x28]
     d15:	shr    r14,0x10
     d19:	mov    r15,r14
     d1c:	and    r15,0xff
     d23:	mov    r14,r15
     d26:	mov    r15,r14
     d29:	and    r15,0xffff
     d30:	mov    r14,r15
     d33:	shl    r14,0x20
     d37:	mov    rcx,r14
     d3a:	mov    r15,rbp
     d3d:	or     r15,rcx
     d40:	mov    r14,QWORD PTR [rsp+0x28]
     d45:	shr    r14,0x18
     d49:	mov    rbp,r14
     d4c:	and    rbp,0xff
     d53:	mov    r14,rbp
     d56:	mov    rbp,r14
     d59:	and    rbp,0xffff
     d60:	mov    r14,rbp
     d63:	shl    r14,0x30
     d67:	mov    rcx,r14
     d6a:	mov    rbp,r15
     d6d:	or     rbp,rcx
     d70:	mov    r14,QWORD PTR [rsp+0x28]
     d75:	shr    r14,0x20
     d79:	mov    r15,r14
     d7c:	and    r15,0xff
     d83:	mov    r14,r15
     d86:	mov    r15,r14
     d89:	and    r15,0xffff
     d90:	mov    r14,r15
     d93:	mov    rcx,r14
     d96:	mov    r15,r13
     d99:	or     r15,rcx
     d9c:	mov    r13,QWORD PTR [rsp+0x28]
     da1:	shr    r13,0x28
     da5:	mov    r14,r13
     da8:	and    r14,0xff
     daf:	mov    r13,r14
     db2:	mov    r14,r13
     db5:	and    r14,0xffff
     dbc:	mov    r13,r14
     dbf:	shl    r13,0x10
     dc3:	mov    rcx,r13
     dc6:	mov    r14,r15
     dc9:	or     r14,rcx
     dcc:	mov    r13,QWORD PTR [rsp+0x28]
     dd1:	shr    r13,0x30
     dd5:	mov    r15,r13
     dd8:	and    r15,0xff
     ddf:	mov    r13,r15
     de2:	mov    r15,r13
     de5:	and    r15,0xffff
     dec:	mov    r13,r15
     def:	shl    r13,0x20
     df3:	mov    rcx,r13
     df6:	mov    r15,r14
     df9:	or     r15,rcx
     dfc:	mov    r13,QWORD PTR [rsp+0x28]
     e01:	shr    r13,0x38
     e05:	mov    r14,r13
     e08:	and    r14,0xff
     e0f:	mov    r13,r14
     e12:	mov    r14,r13
     e15:	and    r14,0xffff
     e1c:	mov    r13,r14
     e1f:	shl    r13,0x30
     e23:	mov    rcx,r13
     e26:	mov    r14,r15
     e29:	or     r14,rcx
     e2c:	mov    QWORD PTR [r12+0x160],rbp
     e34:	mov    QWORD PTR [r12+0x168],r14
     e3c:	mov    r13,QWORD PTR [r12+0x110]
     e44:	mov    r14d,0x0
     e4a:	mov    r15,r13
     e4d:	mov    rbp,r15
     e50:	and    rbp,0xff
     e57:	mov    r15,rbp
     e5a:	mov    rbp,r15
     e5d:	and    rbp,0xffff
     e64:	mov    r15,rbp
     e67:	mov    rcx,r15
     e6a:	mov    rbp,r14
     e6d:	or     rbp,rcx
     e70:	mov    r15,r13
     e73:	shr    r15,0x8
     e77:	mov    r8,r15
     e7a:	and    r8,0xff
     e81:	mov    r15,r8
     e84:	mov    r8,r15
     e87:	and    r8,0xffff
     e8e:	mov    r15,r8
     e91:	shl    r15,0x10
     e95:	mov    rcx,r15
     e98:	mov    r8,rbp
     e9b:	or     r8,rcx
     e9e:	mov    r15,r13
     ea1:	shr    r15,0x10
     ea5:	mov    rbp,r15
     ea8:	and    rbp,0xff
     eaf:	mov    r15,rbp
     eb2:	mov    rbp,r15
     eb5:	and    rbp,0xffff
     ebc:	mov    r15,rbp
     ebf:	shl    r15,0x20
     ec3:	mov    rcx,r15
     ec6:	mov    rbp,r8
     ec9:	or     rbp,rcx
     ecc:	mov    r15,r13
     ecf:	shr    r15,0x18
     ed3:	mov    r8,r15
     ed6:	and    r8,0xff
     edd:	mov    r15,r8
     ee0:	mov    r8,r15
     ee3:	and    r8,0xffff
     eea:	mov    r15,r8
     eed:	shl    r15,0x30
     ef1:	mov    rcx,r15
     ef4:	mov    r8,rbp
     ef7:	or     r8,rcx
     efa:	mov    r15,r13
     efd:	shr    r15,0x20
     f01:	mov    rbp,r15
     f04:	and    rbp,0xff
     f0b:	mov    r15,rbp
     f0e:	mov    rbp,r15
     f11:	and    rbp,0xffff
     f18:	mov    r15,rbp
     f1b:	mov    rcx,r15
     f1e:	mov    rbp,r14
     f21:	or     rbp,rcx
     f24:	mov    r14,r13
     f27:	shr    r14,0x28
     f2b:	mov    r15,r14
     f2e:	and    r15,0xff
     f35:	mov    r14,r15
     f38:	mov    r15,r14
     f3b:	and    r15,0xffff
     f42:	mov    r14,r15
     f45:	shl    r14,0x10
     f49:	mov    rcx,r14
     f4c:	mov    r15,rbp
     f4f:	or     r15,rcx
     f52:	mov    r14,r13
     f55:	shr    r14,0x30
     f59:	mov    rbp,r14
     f5c:	and    rbp,0xff
     f63:	mov    r14,rbp
     f66:	mov    rbp,r14
     f69:	and    rbp,0xffff
     f70:	mov    r14,rbp
     f73:	shl    r14,0x20
     f77:	mov    rcx,r14
     f7a:	mov    rbp,r15
     f7d:	or     rbp,rcx
     f80:	mov    r14,r13
     f83:	shr    r14,0x38
     f87:	mov    r13,r14
     f8a:	and    r13,0xff
     f91:	mov    r14,r13
     f94:	mov    r13,r14
     f97:	and    r13,0xffff
     f9e:	mov    r14,r13
     fa1:	shl    r14,0x30
     fa5:	mov    rcx,r14
     fa8:	mov    r13,rbp
     fab:	or     r13,rcx
     fae:	mov    QWORD PTR [r12+0x170],r8
     fb6:	mov    QWORD PTR [r12+0x178],r13
     fbe:	mov    r13,QWORD PTR [r12+0x118]
     fc6:	mov    r14d,0x0
     fcc:	mov    r15,r13
     fcf:	mov    rbp,r15
     fd2:	and    rbp,0xff
     fd9:	mov    r15,rbp
     fdc:	mov    rbp,r15
     fdf:	and    rbp,0xffff
     fe6:	mov    r15,rbp
     fe9:	mov    rcx,r15
     fec:	mov    rbp,r14
     fef:	or     rbp,rcx
     ff2:	mov    r15,r13
     ff5:	shr    r15,0x8
     ff9:	mov    r8,r15
     ffc:	and    r8,0xff
    1003:	mov    r15,r8
    1006:	mov    r8,r15
    1009:	and    r8,0xffff
    1010:	mov    r15,r8
    1013:	shl    r15,0x10
    1017:	mov    rcx,r15
    101a:	mov    r8,rbp
    101d:	or     r8,rcx
    1020:	mov    r15,r13
    1023:	shr    r15,0x10
    1027:	mov    rbp,r15
    102a:	and    rbp,0xff
    1031:	mov    r15,rbp
    1034:	mov    rbp,r15
    1037:	and    rbp,0xffff
    103e:	mov    r15,rbp
    1041:	shl    r15,0x20
    1045:	mov    rcx,r15
    1048:	mov    rbp,r8
    104b:	or     rbp,rcx
    104e:	mov    r15,r13
    1051:	shr    r15,0x18
    1055:	mov    r8,r15
    1058:	and    r8,0xff
    105f:	mov    r15,r8
    1062:	mov    r8,r15
    1065:	and    r8,0xffff
    106c:	mov    r15,r8
    106f:	shl    r15,0x30
    1073:	mov    rcx,r15
    1076:	mov    r8,rbp
    1079:	or     r8,rcx
    107c:	mov    r15,r13
    107f:	shr    r15,0x20
    1083:	mov    rbp,r15
    1086:	and    rbp,0xff
    108d:	mov    r15,rbp
    1090:	mov    rbp,r15
    1093:	and    rbp,0xffff
    109a:	mov    r15,rbp
    109d:	mov    rcx,r15
    10a0:	mov    rbp,r14
    10a3:	or     rbp,rcx
    10a6:	mov    r14,r13
    10a9:	shr    r14,0x28
    10ad:	mov    r15,r14
    10b0:	and    r15,0xff
    10b7:	mov    r14,r15
    10ba:	mov    r15,r14
    10bd:	and    r15,0xffff
    10c4:	mov    r14,r15
    10c7:	shl    r14,0x10
    10cb:	mov    rcx,r14
    10ce:	mov    r15,rbp
    10d1:	or     r15,rcx
    10d4:	mov    r14,r13
    10d7:	shr    r14,0x30
    10db:	mov    rbp,r14
    10de:	and    rbp,0xff
    10e5:	mov    r14,rbp
    10e8:	mov    rbp,r14
    10eb:	and    rbp,0xffff
    10f2:	mov    r14,rbp
    10f5:	shl    r14,0x20
    10f9:	mov    rcx,r14
    10fc:	mov    rbp,r15
    10ff:	or     rbp,rcx
    1102:	mov    r14,r13
    1105:	shr    r14,0x38
    1109:	mov    r13,r14
    110c:	and    r13,0xff
    1113:	mov    r14,r13
    1116:	mov    r13,r14
    1119:	and    r13,0xffff
    1120:	mov    r14,r13
    1123:	shl    r14,0x30
    1127:	mov    rcx,r14
    112a:	mov    r13,rbp
    112d:	or     r13,rcx
    1130:	mov    QWORD PTR [r12+0x180],r8
    1138:	mov    QWORD PTR [r12+0x188],r13
    1140:	mov    r13,QWORD PTR [r12+0x128]
    1148:	mov    r14d,0x0
    114e:	mov    r15,r13
    1151:	mov    rbp,r15
    1154:	and    rbp,0xff
    115b:	mov    r15,rbp
    115e:	mov    rbp,r15
    1161:	and    rbp,0xffff
    1168:	mov    r15,rbp
    116b:	mov    rcx,r15
    116e:	mov    rbp,r14
    1171:	or     rbp,rcx
    1174:	mov    r15,r13
    1177:	shr    r15,0x8
    117b:	mov    r8,r15
    117e:	and    r8,0xff
    1185:	mov    r15,r8
    1188:	mov    r8,r15
    118b:	and    r8,0xffff
    1192:	mov    r15,r8
    1195:	shl    r15,0x10
    1199:	mov    rcx,r15
    119c:	mov    r8,rbp
    119f:	or     r8,rcx
    11a2:	mov    r15,r13
    11a5:	shr    r15,0x10
    11a9:	mov    rbp,r15
    11ac:	and    rbp,0xff
    11b3:	mov    r15,rbp
    11b6:	mov    rbp,r15
    11b9:	and    rbp,0xffff
    11c0:	mov    r15,rbp
    11c3:	shl    r15,0x20
    11c7:	mov    rcx,r15
    11ca:	mov    rbp,r8
    11cd:	or     rbp,rcx
    11d0:	mov    r15,r13
    11d3:	shr    r15,0x18
    11d7:	mov    r8,r15
    11da:	and    r8,0xff
    11e1:	mov    r15,r8
    11e4:	mov    r8,r15
    11e7:	and    r8,0xffff
    11ee:	mov    r15,r8
    11f1:	shl    r15,0x30
    11f5:	mov    rcx,r15
    11f8:	mov    r8,rbp
    11fb:	or     r8,rcx
    11fe:	mov    r15,r13
    1201:	shr    r15,0x20
    1205:	mov    rbp,r15
    1208:	and    rbp,0xff
    120f:	mov    r15,rbp
    1212:	mov    rbp,r15
    1215:	and    rbp,0xffff
    121c:	mov    r15,rbp
    121f:	mov    rcx,r15
    1222:	mov    rbp,r14
    1225:	or     rbp,rcx
    1228:	mov    r14,r13
    122b:	shr    r14,0x28
    122f:	mov    r15,r14
    1232:	and    r15,0xff
    1239:	mov    r14,r15
    123c:	mov    r15,r14
    123f:	and    r15,0xffff
    1246:	mov    r14,r15
    1249:	shl    r14,0x10
    124d:	mov    rcx,r14
    1250:	mov    r15,rbp
    1253:	or     r15,rcx
    1256:	mov    r14,r13
    1259:	shr    r14,0x30
    125d:	mov    rbp,r14
    1260:	and    rbp,0xff
    1267:	mov    r14,rbp
    126a:	mov    rbp,r14
    126d:	and    rbp,0xffff
    1274:	mov    r14,rbp
    1277:	shl    r14,0x20
    127b:	mov    rcx,r14
    127e:	mov    rbp,r15
    1281:	or     rbp,rcx
    1284:	mov    r14,r13
    1287:	shr    r14,0x38
    128b:	mov    r13,r14
    128e:	and    r13,0xff
    1295:	mov    r14,r13
    1298:	mov    r13,r14
    129b:	and    r13,0xffff
    12a2:	mov    r14,r13
    12a5:	shl    r14,0x30
    12a9:	mov    rcx,r14
    12ac:	mov    r13,rbp
    12af:	or     r13,rcx
    12b2:	mov    QWORD PTR [r12+0x210],r8
    12ba:	mov    QWORD PTR [r12+0x218],r13
    12c2:	mov    r13,QWORD PTR [r12+0x138]
    12ca:	mov    r14d,0x0
    12d0:	mov    r15,r13
    12d3:	mov    rbp,r15
    12d6:	and    rbp,0xff
    12dd:	mov    r15,rbp
    12e0:	mov    rbp,r15
    12e3:	and    rbp,0xffff
    12ea:	mov    r15,rbp
    12ed:	mov    rcx,r15
    12f0:	mov    rbp,r14
    12f3:	or     rbp,rcx
    12f6:	mov    r15,r13
    12f9:	shr    r15,0x8
    12fd:	mov    r8,r15
    1300:	and    r8,0xff
    1307:	mov    r15,r8
    130a:	mov    r8,r15
    130d:	and    r8,0xffff
    1314:	mov    r15,r8
    1317:	shl    r15,0x10
    131b:	mov    rcx,r15
    131e:	mov    r8,rbp
    1321:	or     r8,rcx
    1324:	mov    r15,r13
    1327:	shr    r15,0x10
    132b:	mov    rbp,r15
    132e:	and    rbp,0xff
    1335:	mov    r15,rbp
    1338:	mov    rbp,r15
    133b:	and    rbp,0xffff
    1342:	mov    r15,rbp
    1345:	shl    r15,0x20
    1349:	mov    rcx,r15
    134c:	mov    rbp,r8
    134f:	or     rbp,rcx
    1352:	mov    r15,r13
    1355:	shr    r15,0x18
    1359:	mov    r8,r15
    135c:	and    r8,0xff
    1363:	mov    r15,r8
    1366:	mov    r8,r15
    1369:	and    r8,0xffff
    1370:	mov    r15,r8
    1373:	shl    r15,0x30
    1377:	mov    rcx,r15
    137a:	mov    r8,rbp
    137d:	or     r8,rcx
    1380:	mov    r15,r13
    1383:	shr    r15,0x20
    1387:	mov    rbp,r15
    138a:	and    rbp,0xff
    1391:	mov    r15,rbp
    1394:	mov    rbp,r15
    1397:	and    rbp,0xffff
    139e:	mov    r15,rbp
    13a1:	mov    rcx,r15
    13a4:	mov    rbp,r14
    13a7:	or     rbp,rcx
    13aa:	mov    r14,r13
    13ad:	shr    r14,0x28
    13b1:	mov    r15,r14
    13b4:	and    r15,0xff
    13bb:	mov    r14,r15
    13be:	mov    r15,r14
    13c1:	and    r15,0xffff
    13c8:	mov    r14,r15
    13cb:	shl    r14,0x10
    13cf:	mov    rcx,r14
    13d2:	mov    r15,rbp
    13d5:	or     r15,rcx
    13d8:	mov    r14,r13
    13db:	shr    r14,0x30
    13df:	mov    rbp,r14
    13e2:	and    rbp,0xff
    13e9:	mov    r14,rbp
    13ec:	mov    rbp,r14
    13ef:	and    rbp,0xffff
    13f6:	mov    r14,rbp
    13f9:	shl    r14,0x20
    13fd:	mov    rcx,r14
    1400:	mov    rbp,r15
    1403:	or     rbp,rcx
    1406:	mov    r14,r13
    1409:	shr    r14,0x38
    140d:	mov    r13,r14
    1410:	and    r13,0xff
    1417:	mov    r14,r13
    141a:	mov    r13,r14
    141d:	and    r13,0xffff
    1424:	mov    r14,r13
    1427:	shl    r14,0x30
    142b:	mov    rcx,r14
    142e:	mov    r13,rbp
    1431:	or     r13,rcx
    1434:	mov    QWORD PTR [r12+0x220],r8
    143c:	mov    QWORD PTR [r12+0x228],r13
    1444:	mov    r13,QWORD PTR [r12+0x140]
    144c:	mov    r14d,0x0
    1452:	mov    r15,r13
    1455:	mov    rbp,r15
    1458:	and    rbp,0xff
    145f:	mov    r15,rbp
    1462:	mov    rbp,r15
    1465:	and    rbp,0xffff
    146c:	mov    r15,rbp
    146f:	mov    rcx,r15
    1472:	mov    rbp,r14
    1475:	or     rbp,rcx
    1478:	mov    r15,r13
    147b:	shr    r15,0x8
    147f:	mov    r8,r15
    1482:	and    r8,0xff
    1489:	mov    r15,r8
    148c:	mov    r8,r15
    148f:	and    r8,0xffff
    1496:	mov    r15,r8
    1499:	shl    r15,0x10
    149d:	mov    rcx,r15
    14a0:	mov    r8,rbp
    14a3:	or     r8,rcx
    14a6:	mov    r15,r13
    14a9:	shr    r15,0x10
    14ad:	mov    rbp,r15
    14b0:	and    rbp,0xff
    14b7:	mov    r15,rbp
    14ba:	mov    rbp,r15
    14bd:	and    rbp,0xffff
    14c4:	mov    r15,rbp
    14c7:	shl    r15,0x20
    14cb:	mov    rcx,r15
    14ce:	mov    rbp,r8
    14d1:	or     rbp,rcx
    14d4:	mov    r15,r13
    14d7:	shr    r15,0x18
    14db:	mov    r8,r15
    14de:	and    r8,0xff
    14e5:	mov    r15,r8
    14e8:	mov    r8,r15
    14eb:	and    r8,0xffff
    14f2:	mov    r15,r8
    14f5:	shl    r15,0x30
    14f9:	mov    rcx,r15
    14fc:	mov    r8,rbp
    14ff:	or     r8,rcx
    1502:	mov    r15,r13
    1505:	shr    r15,0x20
    1509:	mov    rbp,r15
    150c:	and    rbp,0xff
    1513:	mov    r15,rbp
    1516:	mov    rbp,r15
    1519:	and    rbp,0xffff
    1520:	mov    r15,rbp
    1523:	mov    rcx,r15
    1526:	mov    rbp,r14
    1529:	or     rbp,rcx
    152c:	mov    r14,r13
    152f:	shr    r14,0x28
    1533:	mov    r15,r14
    1536:	and    r15,0xff
    153d:	mov    r14,r15
    1540:	mov    r15,r14
    1543:	and    r15,0xffff
    154a:	mov    r14,r15
    154d:	shl    r14,0x10
    1551:	mov    rcx,r14
    1554:	mov    r15,rbp
    1557:	or     r15,rcx
    155a:	mov    r14,r13
    155d:	shr    r14,0x30
    1561:	mov    rbp,r14
    1564:	and    rbp,0xff
    156b:	mov    r14,rbp
    156e:	mov    rbp,r14
    1571:	and    rbp,0xffff
    1578:	mov    r14,rbp
    157b:	shl    r14,0x20
    157f:	mov    rcx,r14
    1582:	mov    rbp,r15
    1585:	or     rbp,rcx
    1588:	mov    r14,r13
    158b:	shr    r14,0x38
    158f:	mov    r13,r14
    1592:	and    r13,0xff
    1599:	mov    r14,r13
    159c:	mov    r13,r14
    159f:	and    r13,0xffff
    15a6:	mov    r14,r13
    15a9:	shl    r14,0x30
    15ad:	mov    rcx,r14
    15b0:	mov    r13,rbp
    15b3:	or     r13,rcx
    15b6:	mov    QWORD PTR [r12+0x250],r8
    15be:	mov    QWORD PTR [r12+0x258],r13
    15c6:	mov    r13,QWORD PTR [r12+0x148]
    15ce:	mov    r14d,0x0
    15d4:	mov    r15,r13
    15d7:	mov    rbp,r15
    15da:	and    rbp,0xff
    15e1:	mov    r15,rbp
    15e4:	mov    rbp,r15
    15e7:	and    rbp,0xffff
    15ee:	mov    r15,rbp
    15f1:	mov    rcx,r15
    15f4:	mov    rbp,r14
    15f7:	or     rbp,rcx
    15fa:	mov    r15,r13
    15fd:	shr    r15,0x8
    1601:	mov    r8,r15
    1604:	and    r8,0xff
    160b:	mov    r15,r8
    160e:	mov    r8,r15
    1611:	and    r8,0xffff
    1618:	mov    r15,r8
    161b:	shl    r15,0x10
    161f:	mov    rcx,r15
    1622:	mov    r8,rbp
    1625:	or     r8,rcx
    1628:	mov    r15,r13
    162b:	shr    r15,0x10
    162f:	mov    rbp,r15
    1632:	and    rbp,0xff
    1639:	mov    r15,rbp
    163c:	mov    rbp,r15
    163f:	and    rbp,0xffff
    1646:	mov    r15,rbp
    1649:	shl    r15,0x20
    164d:	mov    rcx,r15
    1650:	mov    rbp,r8
    1653:	or     rbp,rcx
    1656:	mov    r15,r13
    1659:	shr    r15,0x18
    165d:	mov    r8,r15
    1660:	and    r8,0xff
    1667:	mov    r15,r8
    166a:	mov    r8,r15
    166d:	and    r8,0xffff
    1674:	mov    r15,r8
    1677:	shl    r15,0x30
    167b:	mov    rcx,r15
    167e:	mov    r8,rbp
    1681:	or     r8,rcx
    1684:	mov    r15,r13
    1687:	shr    r15,0x20
    168b:	mov    rbp,r15
    168e:	and    rbp,0xff
    1695:	mov    r15,rbp
    1698:	mov    rbp,r15
    169b:	and    rbp,0xffff
    16a2:	mov    r15,rbp
    16a5:	mov    rcx,r15
    16a8:	mov    rbp,r14
    16ab:	or     rbp,rcx
    16ae:	mov    r14,r13
    16b1:	shr    r14,0x28
    16b5:	mov    r15,r14
    16b8:	and    r15,0xff
    16bf:	mov    r14,r15
    16c2:	mov    r15,r14
    16c5:	and    r15,0xffff
    16cc:	mov    r14,r15
    16cf:	shl    r14,0x10
    16d3:	mov    rcx,r14
    16d6:	mov    r15,rbp
    16d9:	or     r15,rcx
    16dc:	mov    r14,r13
    16df:	shr    r14,0x30
    16e3:	mov    rbp,r14
    16e6:	and    rbp,0xff
    16ed:	mov    r14,rbp
    16f0:	mov    rbp,r14
    16f3:	and    rbp,0xffff
    16fa:	mov    r14,rbp
    16fd:	shl    r14,0x20
    1701:	mov    rcx,r14
    1704:	mov    rbp,r15
    1707:	or     rbp,rcx
    170a:	mov    r14,r13
    170d:	shr    r14,0x38
    1711:	mov    r13,r14
    1714:	and    r13,0xff
    171b:	mov    r14,r13
    171e:	mov    r13,r14
    1721:	and    r13,0xffff
    1728:	mov    r14,r13
    172b:	shl    r14,0x30
    172f:	mov    rcx,r14
    1732:	mov    r13,rbp
    1735:	or     r13,rcx
    1738:	mov    QWORD PTR [r12+0x110],r8
    1740:	mov    QWORD PTR [r12+0x118],r13
    1748:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    1752:	movdqa xmm2,xmm0
    1756:	pxor   xmm0,xmm0
    175a:	movdqa xmm3,xmm0
    175e:	movdqa xmm0,xmm2
    1762:	movdqa xmm1,xmm3
    1766:	punpcklwd xmm0,xmm1
    176a:	movdqa xmm4,xmm0
    176e:	movdqa xmm0,xmm4
    1772:	pslld  xmm0,0x10
    1777:	movdqa xmm2,xmm0
    177b:	movdqa xmm0,xmm2
    177f:	movdqu XMMWORD PTR [r12+0x230],xmm0
    1789:	mov    r13,QWORD PTR [r12+0x160]
    1791:	mov    r14d,0x0
    1797:	mov    r15,r13
    179a:	mov    rbp,r15
    179d:	and    rbp,0xffff
    17a4:	mov    r15,rbp
    17a7:	shl    r15,0x8
    17ab:	mov    ecx,0xffffffff
    17b0:	mov    rbp,r15
    17b3:	and    rbp,rcx
    17b6:	mov    r15,rbp
    17b9:	mov    rcx,r15
    17bc:	mov    rbp,r14
    17bf:	or     rbp,rcx
    17c2:	mov    r15,r13
    17c5:	shr    r15,0x10
    17c9:	mov    r8,r15
    17cc:	and    r8,0xffff
    17d3:	mov    r15,r8
    17d6:	shl    r15,0x8
    17da:	mov    ecx,0xffffffff
    17df:	mov    r8,r15
    17e2:	and    r8,rcx
    17e5:	mov    r15,r8
    17e8:	shl    r15,0x20
    17ec:	mov    rcx,r15
    17ef:	mov    r8,rbp
    17f2:	or     r8,rcx
    17f5:	mov    r15,r13
    17f8:	shr    r15,0x20
    17fc:	mov    rbp,r15
    17ff:	and    rbp,0xffff
    1806:	mov    r15,rbp
    1809:	shl    r15,0x8
    180d:	mov    ecx,0xffffffff
    1812:	mov    rbp,r15
    1815:	and    rbp,rcx
    1818:	mov    r15,rbp
    181b:	mov    rcx,r15
    181e:	mov    rbp,r14
    1821:	or     rbp,rcx
    1824:	mov    r14,r13
    1827:	shr    r14,0x30
    182b:	mov    r13,r14
    182e:	and    r13,0xffff
    1835:	mov    r14,r13
    1838:	shl    r14,0x8
    183c:	mov    ecx,0xffffffff
    1841:	mov    r13,r14
    1844:	and    r13,rcx
    1847:	mov    r14,r13
    184a:	shl    r14,0x20
    184e:	mov    rcx,r14
    1851:	mov    r13,rbp
    1854:	or     r13,rcx
    1857:	mov    QWORD PTR [r12+0x240],r8
    185f:	mov    QWORD PTR [r12+0x248],r13
    1867:	mov    r13,QWORD PTR [r12+0x178]
    186f:	mov    r14d,0x0
    1875:	mov    r15,r13
    1878:	mov    rbp,r15
    187b:	and    rbp,0xffff
    1882:	mov    r15,rbp
    1885:	mov    ecx,0xffffffff
    188a:	mov    rbp,r15
    188d:	and    rbp,rcx
    1890:	mov    r15,rbp
    1893:	mov    rcx,r15
    1896:	mov    rbp,r14
    1899:	or     rbp,rcx
    189c:	mov    r15,r13
    189f:	shr    r15,0x10
    18a3:	mov    r8,r15
    18a6:	and    r8,0xffff
    18ad:	mov    r15,r8
    18b0:	mov    ecx,0xffffffff
    18b5:	mov    r8,r15
    18b8:	and    r8,rcx
    18bb:	mov    r15,r8
    18be:	shl    r15,0x20
    18c2:	mov    rcx,r15
    18c5:	mov    r8,rbp
    18c8:	or     r8,rcx
    18cb:	mov    r15,r13
    18ce:	shr    r15,0x20
    18d2:	mov    rbp,r15
    18d5:	and    rbp,0xffff
    18dc:	mov    r15,rbp
    18df:	mov    ecx,0xffffffff
    18e4:	mov    rbp,r15
    18e7:	and    rbp,rcx
    18ea:	mov    r15,rbp
    18ed:	mov    rcx,r15
    18f0:	mov    rbp,r14
    18f3:	or     rbp,rcx
    18f6:	mov    r14,r13
    18f9:	shr    r14,0x30
    18fd:	mov    r13,r14
    1900:	and    r13,0xffff
    1907:	mov    r14,r13
    190a:	mov    ecx,0xffffffff
    190f:	mov    r13,r14
    1912:	and    r13,rcx
    1915:	mov    r14,r13
    1918:	shl    r14,0x20
    191c:	mov    rcx,r14
    191f:	mov    r13,rbp
    1922:	or     r13,rcx
    1925:	mov    QWORD PTR [r12+0x260],r8
    192d:	mov    QWORD PTR [r12+0x268],r13
    1935:	mov    r13,QWORD PTR [r12+0x188]
    193d:	mov    r14d,0x0
    1943:	mov    r15,r13
    1946:	mov    rbp,r15
    1949:	and    rbp,0xffff
    1950:	mov    r15,rbp
    1953:	mov    ecx,0xffffffff
    1958:	mov    rbp,r15
    195b:	and    rbp,rcx
    195e:	mov    r15,rbp
    1961:	mov    rcx,r15
    1964:	mov    rbp,r14
    1967:	or     rbp,rcx
    196a:	mov    r15,r13
    196d:	shr    r15,0x10
    1971:	mov    r8,r15
    1974:	and    r8,0xffff
    197b:	mov    r15,r8
    197e:	mov    ecx,0xffffffff
    1983:	mov    r8,r15
    1986:	and    r8,rcx
    1989:	mov    r15,r8
    198c:	shl    r15,0x20
    1990:	mov    rcx,r15
    1993:	mov    r8,rbp
    1996:	or     r8,rcx
    1999:	mov    r15,r13
    199c:	shr    r15,0x20
    19a0:	mov    rbp,r15
    19a3:	and    rbp,0xffff
    19aa:	mov    r15,rbp
    19ad:	mov    ecx,0xffffffff
    19b2:	mov    rbp,r15
    19b5:	and    rbp,rcx
    19b8:	mov    r15,rbp
    19bb:	mov    rcx,r15
    19be:	mov    rbp,r14
    19c1:	or     rbp,rcx
    19c4:	mov    r14,r13
    19c7:	shr    r14,0x30
    19cb:	mov    r13,r14
    19ce:	and    r13,0xffff
    19d5:	mov    r14,r13
    19d8:	mov    ecx,0xffffffff
    19dd:	mov    r13,r14
    19e0:	and    r13,rcx
    19e3:	mov    r14,r13
    19e6:	shl    r14,0x20
    19ea:	mov    rcx,r14
    19ed:	mov    r13,rbp
    19f0:	or     r13,rcx
    19f3:	mov    QWORD PTR [r12+0x270],r8
    19fb:	mov    QWORD PTR [r12+0x278],r13
    1a03:	mov    r13,QWORD PTR [r12+0x170]
    1a0b:	mov    r14d,0x0
    1a11:	mov    r15,r13
    1a14:	mov    rbp,r15
    1a17:	and    rbp,0xffff
    1a1e:	mov    r15,rbp
    1a21:	mov    ecx,0xffffffff
    1a26:	mov    rbp,r15
    1a29:	and    rbp,rcx
    1a2c:	mov    r15,rbp
    1a2f:	mov    rcx,r15
    1a32:	mov    rbp,r14
    1a35:	or     rbp,rcx
    1a38:	mov    r15,r13
    1a3b:	shr    r15,0x10
    1a3f:	mov    r8,r15
    1a42:	and    r8,0xffff
    1a49:	mov    r15,r8
    1a4c:	mov    ecx,0xffffffff
    1a51:	mov    r8,r15
    1a54:	and    r8,rcx
    1a57:	mov    r15,r8
    1a5a:	shl    r15,0x20
    1a5e:	mov    rcx,r15
    1a61:	mov    r8,rbp
    1a64:	or     r8,rcx
    1a67:	mov    r15,r13
    1a6a:	shr    r15,0x20
    1a6e:	mov    rbp,r15
    1a71:	and    rbp,0xffff
    1a78:	mov    r15,rbp
    1a7b:	mov    ecx,0xffffffff
    1a80:	mov    rbp,r15
    1a83:	and    rbp,rcx
    1a86:	mov    r15,rbp
    1a89:	mov    rcx,r15
    1a8c:	mov    rbp,r14
    1a8f:	or     rbp,rcx
    1a92:	mov    r14,r13
    1a95:	shr    r14,0x30
    1a99:	mov    r13,r14
    1a9c:	and    r13,0xffff
    1aa3:	mov    r14,r13
    1aa6:	mov    ecx,0xffffffff
    1aab:	mov    r13,r14
    1aae:	and    r13,rcx
    1ab1:	mov    r14,r13
    1ab4:	shl    r14,0x20
    1ab8:	mov    rcx,r14
    1abb:	mov    r13,rbp
    1abe:	or     r13,rcx
    1ac1:	mov    QWORD PTR [r12+0x170],r8
    1ac9:	mov    QWORD PTR [r12+0x178],r13
    1ad1:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    1adb:	movdqa xmm2,xmm0
    1adf:	pxor   xmm0,xmm0
    1ae3:	movdqa xmm3,xmm0
    1ae7:	movdqa xmm0,xmm2
    1aeb:	movdqa xmm1,xmm3
    1aef:	punpckhwd xmm0,xmm1
    1af3:	movdqa xmm4,xmm0
    1af7:	movdqa xmm0,xmm4
    1afb:	pslld  xmm0,0x10
    1b00:	movdqa xmm3,xmm0
    1b04:	movdqa xmm0,xmm3
    1b08:	movdqu XMMWORD PTR [r12+0x280],xmm0
    1b12:	mov    r13,QWORD PTR [r12+0x180]
    1b1a:	mov    r14d,0x0
    1b20:	mov    r15,r13
    1b23:	mov    rbp,r15
    1b26:	and    rbp,0xffff
    1b2d:	mov    r15,rbp
    1b30:	mov    ecx,0xffffffff
    1b35:	mov    rbp,r15
    1b38:	and    rbp,rcx
    1b3b:	mov    r15,rbp
    1b3e:	mov    rcx,r15
    1b41:	mov    rbp,r14
    1b44:	or     rbp,rcx
    1b47:	mov    r15,r13
    1b4a:	shr    r15,0x10
    1b4e:	mov    r8,r15
    1b51:	and    r8,0xffff
    1b58:	mov    r15,r8
    1b5b:	mov    ecx,0xffffffff
    1b60:	mov    r8,r15
    1b63:	and    r8,rcx
    1b66:	mov    r15,r8
    1b69:	shl    r15,0x20
    1b6d:	mov    rcx,r15
    1b70:	mov    r8,rbp
    1b73:	or     r8,rcx
    1b76:	mov    r15,r13
    1b79:	shr    r15,0x20
    1b7d:	mov    rbp,r15
    1b80:	and    rbp,0xffff
    1b87:	mov    r15,rbp
    1b8a:	mov    ecx,0xffffffff
    1b8f:	mov    rbp,r15
    1b92:	and    rbp,rcx
    1b95:	mov    r15,rbp
    1b98:	mov    rcx,r15
    1b9b:	mov    rbp,r14
    1b9e:	or     rbp,rcx
    1ba1:	mov    r14,r13
    1ba4:	shr    r14,0x30
    1ba8:	mov    r13,r14
    1bab:	and    r13,0xffff
    1bb2:	mov    r14,r13
    1bb5:	mov    ecx,0xffffffff
    1bba:	mov    r13,r14
    1bbd:	and    r13,rcx
    1bc0:	mov    r14,r13
    1bc3:	shl    r14,0x20
    1bc7:	mov    rcx,r14
    1bca:	mov    r13,rbp
    1bcd:	or     r13,rcx
    1bd0:	mov    QWORD PTR [r12+0x180],r8
    1bd8:	mov    QWORD PTR [r12+0x188],r13
    1be0:	pxor   xmm0,xmm0
    1be4:	movdqa xmm3,xmm0
    1be8:	movdqa xmm0,xmm2
    1bec:	movdqa xmm1,xmm3
    1bf0:	punpcklwd xmm0,xmm1
    1bf4:	movdqa xmm4,xmm0
    1bf8:	movdqa xmm0,xmm4
    1bfc:	pslld  xmm0,0x10
    1c01:	movdqa xmm2,xmm0
    1c05:	movdqa xmm0,xmm2
    1c09:	movdqu XMMWORD PTR [r12+0x210],xmm0
    1c13:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    1c1d:	movdqa xmm2,xmm0
    1c21:	pxor   xmm0,xmm0
    1c25:	movdqa xmm3,xmm0
    1c29:	movdqa xmm0,xmm2
    1c2d:	movdqa xmm1,xmm3
    1c31:	punpckhwd xmm0,xmm1
    1c35:	movdqa xmm4,xmm0
    1c39:	movdqa xmm0,xmm4
    1c3d:	pslld  xmm0,0x10
    1c42:	movdqa xmm2,xmm0
    1c46:	movdqa xmm0,xmm2
    1c4a:	movdqu XMMWORD PTR [r12+0x150],xmm0
    1c54:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1c5e:	movdqa xmm2,xmm0
    1c62:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1c6c:	movdqa xmm3,xmm0
    1c70:	movdqa xmm0,xmm3
    1c74:	movdqa xmm1,xmm2
    1c78:	por    xmm0,xmm1
    1c7c:	movdqa xmm4,xmm0
    1c80:	movdqa xmm0,xmm4
    1c84:	movdqu XMMWORD PTR [r12+0x230],xmm0
    1c8e:	mov    r13,QWORD PTR [r12+0x228]
    1c96:	mov    r14d,0x0
    1c9c:	mov    r15,r13
    1c9f:	mov    rbp,r15
    1ca2:	and    rbp,0xffff
    1ca9:	mov    r15,rbp
    1cac:	shl    r15,0x8
    1cb0:	mov    ecx,0xffffffff
    1cb5:	mov    rbp,r15
    1cb8:	and    rbp,rcx
    1cbb:	mov    r15,rbp
    1cbe:	mov    rcx,r15
    1cc1:	mov    rbp,r14
    1cc4:	or     rbp,rcx
    1cc7:	mov    r15,r13
    1cca:	shr    r15,0x10
    1cce:	mov    r8,r15
    1cd1:	and    r8,0xffff
    1cd8:	mov    r15,r8
    1cdb:	shl    r15,0x8
    1cdf:	mov    ecx,0xffffffff
    1ce4:	mov    r8,r15
    1ce7:	and    r8,rcx
    1cea:	mov    r15,r8
    1ced:	shl    r15,0x20
    1cf1:	mov    rcx,r15
    1cf4:	mov    r8,rbp
    1cf7:	or     r8,rcx
    1cfa:	mov    r15,r13
    1cfd:	shr    r15,0x20
    1d01:	mov    rbp,r15
    1d04:	and    rbp,0xffff
    1d0b:	mov    r15,rbp
    1d0e:	shl    r15,0x8
    1d12:	mov    ecx,0xffffffff
    1d17:	mov    rbp,r15
    1d1a:	and    rbp,rcx
    1d1d:	mov    r15,rbp
    1d20:	mov    rcx,r15
    1d23:	mov    rbp,r14
    1d26:	or     rbp,rcx
    1d29:	mov    r14,r13
    1d2c:	shr    r14,0x30
    1d30:	mov    r13,r14
    1d33:	and    r13,0xffff
    1d3a:	mov    r14,r13
    1d3d:	shl    r14,0x8
    1d41:	mov    ecx,0xffffffff
    1d46:	mov    r13,r14
    1d49:	and    r13,rcx
    1d4c:	mov    r14,r13
    1d4f:	shl    r14,0x20
    1d53:	mov    rcx,r14
    1d56:	mov    r13,rbp
    1d59:	or     r13,rcx
    1d5c:	mov    QWORD PTR [r12+0x240],r8
    1d64:	mov    QWORD PTR [r12+0x248],r13
    1d6c:	mov    r13,QWORD PTR [r12+0x220]
    1d74:	mov    r14d,0x0
    1d7a:	mov    r15,r13
    1d7d:	mov    rbp,r15
    1d80:	and    rbp,0xffff
    1d87:	mov    r15,rbp
    1d8a:	shl    r15,0x8
    1d8e:	mov    ecx,0xffffffff
    1d93:	mov    rbp,r15
    1d96:	and    rbp,rcx
    1d99:	mov    r15,rbp
    1d9c:	mov    rcx,r15
    1d9f:	mov    rbp,r14
    1da2:	or     rbp,rcx
    1da5:	mov    r15,r13
    1da8:	shr    r15,0x10
    1dac:	mov    r8,r15
    1daf:	and    r8,0xffff
    1db6:	mov    r15,r8
    1db9:	shl    r15,0x8
    1dbd:	mov    ecx,0xffffffff
    1dc2:	mov    r8,r15
    1dc5:	and    r8,rcx
    1dc8:	mov    r15,r8
    1dcb:	shl    r15,0x20
    1dcf:	mov    rcx,r15
    1dd2:	mov    r8,rbp
    1dd5:	or     r8,rcx
    1dd8:	mov    r15,r13
    1ddb:	shr    r15,0x20
    1ddf:	mov    rbp,r15
    1de2:	and    rbp,0xffff
    1de9:	mov    r15,rbp
    1dec:	shl    r15,0x8
    1df0:	mov    ecx,0xffffffff
    1df5:	mov    rbp,r15
    1df8:	and    rbp,rcx
    1dfb:	mov    r15,rbp
    1dfe:	mov    rcx,r15
    1e01:	mov    rbp,r14
    1e04:	or     rbp,rcx
    1e07:	mov    r14,r13
    1e0a:	shr    r14,0x30
    1e0e:	mov    r13,r14
    1e11:	and    r13,0xffff
    1e18:	mov    r14,r13
    1e1b:	shl    r14,0x8
    1e1f:	mov    ecx,0xffffffff
    1e24:	mov    r13,r14
    1e27:	and    r13,rcx
    1e2a:	mov    r14,r13
    1e2d:	shl    r14,0x20
    1e31:	mov    rcx,r14
    1e34:	mov    r13,rbp
    1e37:	or     r13,rcx
    1e3a:	mov    QWORD PTR [r12+0x220],r8
    1e42:	mov    QWORD PTR [r12+0x228],r13
    1e4a:	mov    r13,QWORD PTR [r12+0x168]
    1e52:	mov    r14d,0x0
    1e58:	mov    r15,r13
    1e5b:	mov    rbp,r15
    1e5e:	and    rbp,0xffff
    1e65:	mov    r15,rbp
    1e68:	shl    r15,0x8
    1e6c:	mov    ecx,0xffffffff
    1e71:	mov    rbp,r15
    1e74:	and    rbp,rcx
    1e77:	mov    r15,rbp
    1e7a:	mov    rcx,r15
    1e7d:	mov    rbp,r14
    1e80:	or     rbp,rcx
    1e83:	mov    r15,r13
    1e86:	shr    r15,0x10
    1e8a:	mov    r8,r15
    1e8d:	and    r8,0xffff
    1e94:	mov    r15,r8
    1e97:	shl    r15,0x8
    1e9b:	mov    ecx,0xffffffff
    1ea0:	mov    r8,r15
    1ea3:	and    r8,rcx
    1ea6:	mov    r15,r8
    1ea9:	shl    r15,0x20
    1ead:	mov    rcx,r15
    1eb0:	mov    r8,rbp
    1eb3:	or     r8,rcx
    1eb6:	mov    r15,r13
    1eb9:	shr    r15,0x20
    1ebd:	mov    rbp,r15
    1ec0:	and    rbp,0xffff
    1ec7:	mov    r15,rbp
    1eca:	shl    r15,0x8
    1ece:	mov    ecx,0xffffffff
    1ed3:	mov    rbp,r15
    1ed6:	and    rbp,rcx
    1ed9:	mov    r15,rbp
    1edc:	mov    rcx,r15
    1edf:	mov    rbp,r14
    1ee2:	or     rbp,rcx
    1ee5:	mov    r14,r13
    1ee8:	shr    r14,0x30
    1eec:	mov    r13,r14
    1eef:	and    r13,0xffff
    1ef6:	mov    r14,r13
    1ef9:	shl    r14,0x8
    1efd:	mov    ecx,0xffffffff
    1f02:	mov    r13,r14
    1f05:	and    r13,rcx
    1f08:	mov    r14,r13
    1f0b:	shl    r14,0x20
    1f0f:	mov    rcx,r14
    1f12:	mov    r13,rbp
    1f15:	or     r13,rcx
    1f18:	mov    QWORD PTR [r12+0x160],r8
    1f20:	mov    QWORD PTR [r12+0x168],r13
    1f28:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    1f32:	movdqa xmm2,xmm0
    1f36:	movdqa xmm0,xmm2
    1f3a:	pslld  xmm0,0x18
    1f3f:	movdqa xmm3,xmm0
    1f43:	movdqa xmm0,xmm3
    1f47:	movdqu XMMWORD PTR [r12+0x170],xmm0
    1f51:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    1f5b:	movdqa xmm2,xmm0
    1f5f:	movdqa xmm0,xmm2
    1f63:	pslld  xmm0,0x18
    1f68:	movdqa xmm3,xmm0
    1f6c:	movdqa xmm0,xmm3
    1f70:	movdqu XMMWORD PTR [r12+0x120],xmm0
    1f7a:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    1f84:	movdqa xmm2,xmm0
    1f88:	movdqa xmm0,xmm2
    1f8c:	pslld  xmm0,0x18
    1f91:	movdqa xmm3,xmm0
    1f95:	movdqa xmm0,xmm3
    1f99:	movdqu XMMWORD PTR [r12+0x180],xmm0
    1fa3:	mov    r13,QWORD PTR [r12+0x250]
    1fab:	mov    r14d,0x0
    1fb1:	mov    r15,r13
    1fb4:	mov    rbp,r15
    1fb7:	and    rbp,0xffff
    1fbe:	mov    r15,rbp
    1fc1:	mov    ecx,0xffffffff
    1fc6:	mov    rbp,r15
    1fc9:	and    rbp,rcx
    1fcc:	mov    r15,rbp
    1fcf:	mov    rcx,r15
    1fd2:	mov    rbp,r14
    1fd5:	or     rbp,rcx
    1fd8:	mov    r15,r13
    1fdb:	shr    r15,0x10
    1fdf:	mov    r8,r15
    1fe2:	and    r8,0xffff
    1fe9:	mov    r15,r8
    1fec:	mov    ecx,0xffffffff
    1ff1:	mov    r8,r15
    1ff4:	and    r8,rcx
    1ff7:	mov    r15,r8
    1ffa:	shl    r15,0x20
    1ffe:	mov    rcx,r15
    2001:	mov    r8,rbp
    2004:	or     r8,rcx
    2007:	mov    r15,r13
    200a:	shr    r15,0x20
    200e:	mov    rbp,r15
    2011:	and    rbp,0xffff
    2018:	mov    r15,rbp
    201b:	mov    ecx,0xffffffff
    2020:	mov    rbp,r15
    2023:	and    rbp,rcx
    2026:	mov    r15,rbp
    2029:	mov    rcx,r15
    202c:	mov    rbp,r14
    202f:	or     rbp,rcx
    2032:	mov    r14,r13
    2035:	shr    r14,0x30
    2039:	mov    r13,r14
    203c:	and    r13,0xffff
    2043:	mov    r14,r13
    2046:	mov    ecx,0xffffffff
    204b:	mov    r13,r14
    204e:	and    r13,rcx
    2051:	mov    r14,r13
    2054:	shl    r14,0x20
    2058:	mov    rcx,r14
    205b:	mov    r13,rbp
    205e:	or     r13,rcx
    2061:	mov    QWORD PTR [r12+0x140],r8
    2069:	mov    QWORD PTR [r12+0x148],r13
    2071:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    207b:	movdqa xmm2,xmm0
    207f:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    2089:	movdqa xmm3,xmm0
    208d:	movdqa xmm0,xmm3
    2091:	movdqa xmm1,xmm2
    2095:	por    xmm0,xmm1
    2099:	movdqa xmm4,xmm0
    209d:	movdqa xmm0,xmm4
    20a1:	movdqu XMMWORD PTR [r12+0x130],xmm0
    20ab:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    20b5:	movdqa xmm2,xmm0
    20b9:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    20c3:	movdqa xmm3,xmm0
    20c7:	movdqa xmm0,xmm3
    20cb:	movdqa xmm1,xmm2
    20cf:	por    xmm0,xmm1
    20d3:	movdqa xmm4,xmm0
    20d7:	movdqa xmm0,xmm4
    20db:	movdqu XMMWORD PTR [r12+0x210],xmm0
    20e5:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    20ef:	movdqa xmm2,xmm0
    20f3:	movdqa xmm0,xmm2
    20f7:	pslld  xmm0,0x18
    20fc:	movdqa xmm3,xmm0
    2100:	movdqa xmm0,xmm3
    2104:	movdqu XMMWORD PTR [r12+0x220],xmm0
    210e:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    2118:	movdqa xmm2,xmm0
    211c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    2126:	movdqa xmm3,xmm0
    212a:	movdqa xmm0,xmm3
    212e:	movdqa xmm1,xmm2
    2132:	por    xmm0,xmm1
    2136:	movdqa xmm4,xmm0
    213a:	movdqa xmm0,xmm4
    213e:	movdqu XMMWORD PTR [r12+0x150],xmm0
    2148:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    2152:	movdqa xmm2,xmm0
    2156:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    2160:	movdqa xmm3,xmm0
    2164:	movdqa xmm0,xmm3
    2168:	movdqa xmm1,xmm2
    216c:	por    xmm0,xmm1
    2170:	movdqa xmm4,xmm0
    2174:	movdqa xmm0,xmm4
    2178:	movdqu XMMWORD PTR [r12+0x160],xmm0
    2182:	mov    r13,QWORD PTR [r12+0x118]
    218a:	mov    r14d,0x0
    2190:	mov    r15,r13
    2193:	mov    rbp,r15
    2196:	and    rbp,0xffff
    219d:	mov    r15,rbp
    21a0:	mov    ecx,0xffffffff
    21a5:	mov    rbp,r15
    21a8:	and    rbp,rcx
    21ab:	mov    r15,rbp
    21ae:	mov    rcx,r15
    21b1:	mov    rbp,r14
    21b4:	or     rbp,rcx
    21b7:	mov    r15,r13
    21ba:	shr    r15,0x10
    21be:	mov    r8,r15
    21c1:	and    r8,0xffff
    21c8:	mov    r15,r8
    21cb:	mov    ecx,0xffffffff
    21d0:	mov    r8,r15
    21d3:	and    r8,rcx
    21d6:	mov    r15,r8
    21d9:	shl    r15,0x20
    21dd:	mov    rcx,r15
    21e0:	mov    r8,rbp
    21e3:	or     r8,rcx
    21e6:	mov    r15,r13
    21e9:	shr    r15,0x20
    21ed:	mov    rbp,r15
    21f0:	and    rbp,0xffff
    21f7:	mov    r15,rbp
    21fa:	mov    ecx,0xffffffff
    21ff:	mov    rbp,r15
    2202:	and    rbp,rcx
    2205:	mov    r15,rbp
    2208:	mov    rcx,r15
    220b:	mov    rbp,r14
    220e:	or     rbp,rcx
    2211:	mov    r14,r13
    2214:	shr    r14,0x30
    2218:	mov    r13,r14
    221b:	and    r13,0xffff
    2222:	mov    r14,r13
    2225:	mov    ecx,0xffffffff
    222a:	mov    r13,r14
    222d:	and    r13,rcx
    2230:	mov    r14,r13
    2233:	shl    r14,0x20
    2237:	mov    rcx,r14
    223a:	mov    r13,rbp
    223d:	or     r13,rcx
    2240:	mov    QWORD PTR [r12+0x170],r8
    2248:	mov    QWORD PTR [r12+0x178],r13
    2250:	mov    r13,QWORD PTR [r12+0x110]
    2258:	mov    r14d,0x0
    225e:	mov    r15,r13
    2261:	mov    rbp,r15
    2264:	and    rbp,0xffff
    226b:	mov    r15,rbp
    226e:	mov    ecx,0xffffffff
    2273:	mov    rbp,r15
    2276:	and    rbp,rcx
    2279:	mov    r15,rbp
    227c:	mov    rcx,r15
    227f:	mov    rbp,r14
    2282:	or     rbp,rcx
    2285:	mov    r15,r13
    2288:	shr    r15,0x10
    228c:	mov    r8,r15
    228f:	and    r8,0xffff
    2296:	mov    r15,r8
    2299:	mov    ecx,0xffffffff
    229e:	mov    r8,r15
    22a1:	and    r8,rcx
    22a4:	mov    r15,r8
    22a7:	shl    r15,0x20
    22ab:	mov    rcx,r15
    22ae:	mov    r8,rbp
    22b1:	or     r8,rcx
    22b4:	mov    r15,r13
    22b7:	shr    r15,0x20
    22bb:	mov    rbp,r15
    22be:	and    rbp,0xffff
    22c5:	mov    r15,rbp
    22c8:	mov    ecx,0xffffffff
    22cd:	mov    rbp,r15
    22d0:	and    rbp,rcx
    22d3:	mov    r15,rbp
    22d6:	mov    rcx,r15
    22d9:	mov    rbp,r14
    22dc:	or     rbp,rcx
    22df:	mov    r14,r13
    22e2:	shr    r14,0x30
    22e6:	mov    r13,r14
    22e9:	and    r13,0xffff
    22f0:	mov    r14,r13
    22f3:	mov    ecx,0xffffffff
    22f8:	mov    r13,r14
    22fb:	and    r13,rcx
    22fe:	mov    r14,r13
    2301:	shl    r14,0x20
    2305:	mov    rcx,r14
    2308:	mov    r13,rbp
    230b:	or     r13,rcx
    230e:	mov    QWORD PTR [r12+0x110],r8
    2316:	mov    QWORD PTR [r12+0x118],r13
    231e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    2328:	movdqa xmm2,xmm0
    232c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    2336:	movdqa xmm3,xmm0
    233a:	movdqa xmm0,xmm3
    233e:	movdqa xmm1,xmm2
    2342:	por    xmm0,xmm1
    2346:	movdqa xmm4,xmm0
    234a:	movdqa xmm0,xmm4
    234e:	movdqu XMMWORD PTR [r12+0x120],xmm0
    2358:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    2362:	movdqa xmm2,xmm0
    2366:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    2370:	movdqa xmm3,xmm0
    2374:	movdqa xmm0,xmm3
    2378:	movdqa xmm1,xmm2
    237c:	por    xmm0,xmm1
    2380:	movdqa xmm4,xmm0
    2384:	movdqa xmm0,xmm4
    2388:	movdqu XMMWORD PTR [r12+0x130],xmm0
    2392:	mov    r13,QWORD PTR [r12+0x258]
    239a:	mov    r14d,0x0
    23a0:	mov    r15,r13
    23a3:	mov    rbp,r15
    23a6:	and    rbp,0xffff
    23ad:	mov    r15,rbp
    23b0:	mov    ecx,0xffffffff
    23b5:	mov    rbp,r15
    23b8:	and    rbp,rcx
    23bb:	mov    r15,rbp
    23be:	mov    rcx,r15
    23c1:	mov    rbp,r14
    23c4:	or     rbp,rcx
    23c7:	mov    r15,r13
    23ca:	shr    r15,0x10
    23ce:	mov    r8,r15
    23d1:	and    r8,0xffff
    23d8:	mov    r15,r8
    23db:	mov    ecx,0xffffffff
    23e0:	mov    r8,r15
    23e3:	and    r8,rcx
    23e6:	mov    r15,r8
    23e9:	shl    r15,0x20
    23ed:	mov    rcx,r15
    23f0:	mov    r8,rbp
    23f3:	or     r8,rcx
    23f6:	mov    r15,r13
    23f9:	shr    r15,0x20
    23fd:	mov    rbp,r15
    2400:	and    rbp,0xffff
    2407:	mov    r15,rbp
    240a:	mov    ecx,0xffffffff
    240f:	mov    rbp,r15
    2412:	and    rbp,rcx
    2415:	mov    r15,rbp
    2418:	mov    rcx,r15
    241b:	mov    rbp,r14
    241e:	or     rbp,rcx
    2421:	mov    r14,r13
    2424:	shr    r14,0x30
    2428:	mov    r13,r14
    242b:	and    r13,0xffff
    2432:	mov    r14,r13
    2435:	mov    ecx,0xffffffff
    243a:	mov    r13,r14
    243d:	and    r13,rcx
    2440:	mov    r14,r13
    2443:	shl    r14,0x20
    2447:	mov    rcx,r14
    244a:	mov    r13,rbp
    244d:	or     r13,rcx
    2450:	mov    QWORD PTR [r12+0x180],r8
    2458:	mov    QWORD PTR [r12+0x188],r13
    2460:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    246a:	movdqa xmm2,xmm0
    246e:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    2478:	movdqa xmm3,xmm0
    247c:	movdqa xmm0,xmm3
    2480:	movdqa xmm1,xmm2
    2484:	por    xmm0,xmm1
    2488:	movdqa xmm4,xmm0
    248c:	movdqa xmm0,xmm4
    2490:	movdqu XMMWORD PTR [r12+0x150],xmm0
    249a:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    24a4:	movdqa xmm2,xmm0
    24a8:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    24b2:	movdqa xmm3,xmm0
    24b6:	movdqa xmm0,xmm3
    24ba:	movdqa xmm1,xmm2
    24be:	por    xmm0,xmm1
    24c2:	movdqa xmm5,xmm0
    24c6:	movdqa xmm0,xmm5
    24ca:	movdqu XMMWORD PTR [r12+0x140],xmm0
    24d4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    24de:	movdqa xmm2,xmm0
    24e2:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    24ec:	movdqa xmm3,xmm0
    24f0:	movdqa xmm0,xmm3
    24f4:	movdqa xmm1,xmm2
    24f8:	por    xmm0,xmm1
    24fc:	movdqa xmm5,xmm0
    2500:	movdqa xmm0,xmm5
    2504:	movdqu XMMWORD PTR [r12+0x110],xmm0
    250e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    2518:	movdqa xmm2,xmm0
    251c:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    2526:	movdqa xmm3,xmm0
    252a:	movdqa xmm0,xmm3
    252e:	movdqa xmm1,xmm2
    2532:	por    xmm0,xmm1
    2536:	movdqa xmm6,xmm0
    253a:	movdqa xmm0,xmm6
    253e:	movdqu XMMWORD PTR [r12+0x120],xmm0
    2548:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    2552:	movdqa xmm2,xmm0
    2556:	movdqa xmm0,xmm4
    255a:	movdqa xmm1,xmm2
    255e:	por    xmm0,xmm1
    2562:	movdqa xmm3,xmm0
    2566:	movdqa xmm0,xmm3
    256a:	movdqu XMMWORD PTR [r12+0x130],xmm0
    2574:	mov    r13,QWORD PTR [r12+0xf8]
    257c:	mov    r14,r13
    257f:	add    r14,0x20
    2583:	mov    r15,r14
    2586:	add    r15,0x10
    258a:	movdqu XMMWORD PTR [r14],xmm5
    258f:	mov    r14d,0x0
    2595:	mov    DWORD PTR [r12+0x32c],r14d
    259d:	movdqu XMMWORD PTR [r15],xmm6
    25a2:	mov    r14d,0x0
    25a8:	mov    DWORD PTR [r12+0x32c],r14d
    25b0:	mov    r14,r13
    25b3:	add    r14,0x10
    25b7:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    25c1:	movdqa xmm2,xmm0
    25c5:	movdqu XMMWORD PTR [r13+0x0],xmm2
    25cb:	mov    r15d,0x0
    25d1:	mov    DWORD PTR [r12+0x32c],r15d
    25d9:	movdqu XMMWORD PTR [r14],xmm3
    25de:	mov    r14d,0x0
    25e4:	mov    DWORD PTR [r12+0x32c],r14d
    25ec:	mov    r14d,DWORD PTR [r13+0x0]
    25f0:	mov    QWORD PTR [r12+0x60],r14
    25f5:	jmp    0x25fa
    25fa:	mov    r13,QWORD PTR [r12+0x58]
    25ff:	mov    r14,QWORD PTR [r12+0x48]
    2604:	mov    rcx,r13
    2607:	mov    r15,r14
    260a:	add    r15,rcx
    260d:	mov    QWORD PTR [r12+0x68],r15
    2612:	mov    r14,r13
    2615:	add    r14,0x4
    2619:	mov    QWORD PTR [r12+0x58],r14
    261e:	mov    r13,r15
    2621:	add    r13,0x4
    2625:	mov    ebp,DWORD PTR [r13+0x0]
    2629:	mov    QWORD PTR [r12+0x70],rbp
    262e:	mov    r13,r15
    2631:	add    r13,0x38
    2635:	mov    r8d,DWORD PTR [r13+0x0]
    2639:	mov    QWORD PTR [r12+0x78],r8
    263e:	mov    r13,r15
    2641:	add    r13,0x24
    2645:	mov    r15d,DWORD PTR [r13+0x0]
    2649:	mov    QWORD PTR [r12+0x90],r15
    2651:	mov    r13,r14
    2654:	sub    r13,0xc0
    265b:	pushf
    265c:	pop    rdx
    265d:	mov    r10d,edx
    2660:	and    r10d,0xc0
    2667:	shl    r10d,0x18
    266b:	mov    r11d,edx
    266e:	and    r11d,0x1
    2672:	shl    r11d,0x1d
    2676:	or     r10d,r11d
    2679:	mov    r11d,edx
    267c:	and    r11d,0x800
    2683:	shl    r11d,0x11
    2687:	or     r10d,r11d
    268a:	mov    r11d,0xf0000000
    2690:	and    r11,r10
    2693:	movabs rsi,0xffffffff0fffffff
    269d:	and    rbx,rsi
    26a0:	or     rbx,r11
    26a3:	btc    rbx,0x1d
    26a8:	mov    r13d,ebp
    26ab:	mov    r13d,r13d
    26ae:	ror    r13d,0x7
    26b2:	mov    r13d,r13d
    26b5:	mov    QWORD PTR [r12+0x80],r13
    26bd:	mov    eax,r8d
    26c0:	mov    eax,eax
    26c2:	ror    eax,0x11
    26c5:	mov    eax,eax
    26c7:	mov    QWORD PTR [rsp+0x48],rax
    26cc:	mov    rax,QWORD PTR [rsp+0x48]
    26d1:	mov    QWORD PTR [r12+0x88],rax
    26d9:	mov    r9d,DWORD PTR [r12+0x60]
    26de:	mov    ecx,r9d
    26e1:	mov    r14d,r15d
    26e4:	add    r14d,ecx
    26e7:	mov    QWORD PTR [r12+0x60],r14
    26ec:	mov    r14d,ebp
    26ef:	mov    r14d,r14d
    26f2:	shr    r14d,0x12
    26f6:	mov    r14d,r14d
    26f9:	mov    r15d,ebp
    26fc:	mov    r15d,r15d
    26ff:	shl    r15d,0xe
    2703:	mov    r15d,r15d
    2706:	mov    ecx,r15d
    2709:	mov    ebp,r14d
    270c:	or     rbp,rcx
    270f:	mov    ebp,ebp
    2711:	mov    ecx,ebp
    2713:	mov    r14d,r13d
    2716:	xor    r14,rcx
    2719:	mov    r14d,r14d
    271c:	mov    QWORD PTR [r12+0x80],r14
    2724:	mov    r13d,r8d
    2727:	mov    r13d,r13d
    272a:	shr    r13d,0x13
    272e:	mov    r13d,r13d
    2731:	mov    r15d,r8d
    2734:	mov    r15d,r15d
    2737:	shl    r15d,0xd
    273b:	mov    r15d,r15d
    273e:	mov    ecx,r15d
    2741:	mov    ebp,r13d
    2744:	or     rbp,rcx
    2747:	mov    ebp,ebp
    2749:	mov    ecx,ebp
    274b:	mov    r13d,DWORD PTR [rsp+0x48]
    2750:	xor    r13,rcx
    2753:	mov    r13d,r13d
    2756:	mov    QWORD PTR [r12+0x88],r13
    275e:	mov    r15d,DWORD PTR [r12+0x70]
    2763:	mov    ebp,r15d
    2766:	mov    ebp,ebp
    2768:	shr    ebp,0x3
    276b:	mov    ebp,ebp
    276d:	mov    ecx,ebp
    276f:	mov    r15d,r14d
    2772:	xor    r15,rcx
    2775:	mov    r15d,r15d
    2778:	mov    QWORD PTR [r12+0x80],r15
    2780:	mov    r14d,DWORD PTR [r12+0x78]
    2785:	mov    ebp,r14d
    2788:	mov    ebp,ebp
    278a:	shr    ebp,0xa
    278d:	mov    ebp,ebp
    278f:	mov    ecx,ebp
    2791:	mov    r14d,r13d
    2794:	xor    r14,rcx
    2797:	mov    r14d,r14d
    279a:	mov    QWORD PTR [r12+0x78],r14
    279f:	mov    r13d,DWORD PTR [r12+0x60]
    27a4:	mov    ecx,r15d
    27a7:	mov    ebp,r13d
    27aa:	add    ebp,ecx
    27ac:	mov    QWORD PTR [r12+0x60],rbp
    27b1:	mov    ecx,r14d
    27b4:	mov    r13d,ebp
    27b7:	add    r13d,ecx
    27ba:	mov    QWORD PTR [r12+0x60],r13
    27bf:	mov    r14,QWORD PTR [r12+0x68]
    27c4:	mov    r15,r14
    27c7:	add    r15,0x40
    27cb:	mov    DWORD PTR [r15],r13d
    27ce:	mov    r13d,0x0
    27d4:	mov    DWORD PTR [r12+0x32c],r13d
    27dc:	mov    r13d,0x0
    27e2:	mov    r14d,DWORD PTR [r12+0x70]
    27e7:	mov    ecx,r14d
    27ea:	mov    r15d,r13d
    27ed:	or     r15,rcx
    27f0:	mov    r15d,r15d
    27f3:	mov    QWORD PTR [r12+0x60],r15
    27f8:	cmp    QWORD PTR [r12+0x380],0x0
    2801:	je     0x2832
    2807:	mov    eax,0x410888
    280c:	mov    QWORD PTR [r12+0x100],rax
    2814:	mov    QWORD PTR [r12+0x108],rbx
    281c:	add    rsp,0x50
    2820:	mov    eax,0xc
    2825:	movabs r11,0x5b99604255f0
    282f:	jmp    r11
    2832:	test   ebx,0x40000000
    2838:	je     0x25fa
    283e:	jmp    0x2843
    2843:	mov    r13,QWORD PTR [r12]
    2847:	mov    r14,r13
    284a:	add    r14,0x4
    284e:	mov    r15d,DWORD PTR [r13+0x0]
    2852:	mov    ebp,DWORD PTR [r14]
    2855:	mov    QWORD PTR [r12+0x78],r15
    285a:	mov    QWORD PTR [r12+0x80],rbp
    2862:	mov    r14,r13
    2865:	add    r14,0x8
    2869:	mov    r15,r14
    286c:	add    r15,0x4
    2870:	mov    ebp,DWORD PTR [r14]
    2873:	mov    r14d,DWORD PTR [r15]
    2876:	mov    QWORD PTR [r12+0x70],rbp
    287b:	mov    QWORD PTR [r12+0x68],r14
    2880:	mov    r14,r13
    2883:	add    r14,0x18
    2887:	mov    r15,r14
    288a:	add    r15,0x4
    288e:	mov    ebp,DWORD PTR [r14]
    2891:	mov    r14d,DWORD PTR [r15]
    2894:	mov    QWORD PTR [r12+0x58],rbp
    2899:	mov    QWORD PTR [r12+0x60],r14
    289e:	mov    r14,r13
    28a1:	add    r14,0x10
    28a5:	mov    r13,r14
    28a8:	add    r13,0x4
    28ac:	mov    r15d,DWORD PTR [r14]
    28af:	mov    r14d,DWORD PTR [r13+0x0]
    28b3:	mov    QWORD PTR [r12+0x18],r15
    28b8:	mov    QWORD PTR [r12+0x90],r14
    28c0:	mov    r13d,0x0
    28c6:	mov    QWORD PTR [r12+0x88],r13
    28ce:	mov    r13d,0x0
    28d4:	mov    r14d,DWORD PTR [r12+0x78]
    28d9:	mov    ecx,r14d
    28dc:	mov    r15d,r13d
    28df:	or     r15,rcx
    28e2:	mov    r15d,r15d
    28e5:	mov    QWORD PTR [r12+0xa8],r15
    28ed:	mov    r13d,0x0
    28f3:	mov    r14d,DWORD PTR [r12+0x80]
    28fb:	mov    ecx,r14d
    28fe:	mov    r15d,r13d
    2901:	or     r15,rcx
    2904:	mov    r15d,r15d
    2907:	mov    QWORD PTR [r12+0x38],r15
    290c:	mov    r13d,0x0
    2912:	mov    r14d,DWORD PTR [r12+0x70]
    2917:	mov    ecx,r14d
    291a:	mov    r15d,r13d
    291d:	or     r15,rcx
    2920:	mov    r15d,r15d
    2923:	mov    QWORD PTR [r12+0x98],r15
    292b:	mov    r13d,0x0
    2931:	mov    r14d,DWORD PTR [r12+0x68]
    2936:	mov    ecx,r14d
    2939:	mov    r15d,r13d
    293c:	or     r15,rcx
    293f:	mov    r15d,r15d
    2942:	mov    QWORD PTR [r12+0x28],r15
    2947:	mov    r13d,0x0
    294d:	mov    r14d,DWORD PTR [r12+0x60]
    2952:	mov    ecx,r14d
    2955:	mov    r15d,r13d
    2958:	or     r15,rcx
    295b:	mov    r15d,r15d
    295e:	mov    QWORD PTR [r12+0xb0],r15
    2966:	mov    r13d,0x0
    296c:	mov    r14d,DWORD PTR [r12+0x58]
    2971:	mov    ecx,r14d
    2974:	mov    r15d,r13d
    2977:	or     r15,rcx
    297a:	mov    r15d,r15d
    297d:	mov    QWORD PTR [r12+0xc0],r15
    2985:	mov    r13d,0x0
    298b:	mov    r14d,DWORD PTR [r12+0x90]
    2993:	mov    ecx,r14d
    2996:	mov    r15d,r13d
    2999:	or     r15,rcx
    299c:	mov    r15d,r15d
    299f:	mov    QWORD PTR [r12+0xc8],r15
    29a7:	mov    r13d,0x0
    29ad:	mov    r14d,DWORD PTR [r12+0x18]
    29b2:	mov    ecx,r14d
    29b5:	mov    r15d,r13d
    29b8:	or     r15,rcx
    29bb:	mov    r15d,r15d
    29be:	mov    QWORD PTR [r12+0xb8],r15
    29c6:	jmp    0x29cb
    29cb:	mov    r13d,0x0
    29d1:	mov    r14d,DWORD PTR [r12+0xb8]
    29d9:	mov    ecx,r14d
    29dc:	mov    r15d,r13d
    29df:	or     r15,rcx
    29e2:	mov    r15d,r15d
    29e5:	mov    QWORD PTR [r12+0x30],r15
    29ea:	mov    r13d,0x0
    29f0:	mov    r14d,DWORD PTR [r12+0xc0]
    29f8:	mov    ecx,r14d
    29fb:	mov    r15d,r13d
    29fe:	or     r15,rcx
    2a01:	mov    r15d,r15d
    2a04:	mov    QWORD PTR [r12+0xa0],r15
    2a0c:	mov    r13d,0x0
    2a12:	mov    r14d,DWORD PTR [r12+0x28]
    2a17:	mov    ecx,r14d
    2a1a:	mov    r15d,r13d
    2a1d:	or     r15,rcx
    2a20:	mov    r15d,r15d
    2a23:	mov    QWORD PTR [r12+0xc0],r15
    2a2b:	mov    r13d,0x0
    2a31:	mov    r14d,DWORD PTR [r12+0x98]
    2a39:	mov    ecx,r14d
    2a3c:	mov    r15d,r13d
    2a3f:	or     r15,rcx
    2a42:	mov    r15d,r15d
    2a45:	mov    QWORD PTR [r12+0x28],r15
    2a4a:	mov    r13d,0x0
    2a50:	mov    r14d,DWORD PTR [r12+0x38]
    2a55:	mov    ecx,r14d
    2a58:	mov    r15d,r13d
    2a5b:	or     r15,rcx
    2a5e:	mov    r15d,r15d
    2a61:	mov    QWORD PTR [r12+0x98],r15
    2a69:	mov    r13d,0x0
    2a6f:	mov    r14d,DWORD PTR [r12+0xa8]
    2a77:	mov    ecx,r14d
    2a7a:	mov    r15d,r13d
    2a7d:	or     r15,rcx
    2a80:	mov    r15d,r15d
    2a83:	mov    QWORD PTR [r12+0x38],r15
    2a88:	mov    r13d,DWORD PTR [r12+0xb8]
    2a90:	mov    r14d,r13d
    2a93:	mov    r14d,r14d
    2a96:	ror    r14d,0x6
    2a9a:	mov    r14d,r14d
    2a9d:	mov    QWORD PTR [r12+0xb8],r14
    2aa5:	mov    r13d,DWORD PTR [r12+0x30]
    2aaa:	mov    r14d,DWORD PTR [r12+0xc8]
    2ab2:	mov    ecx,r14d
    2ab5:	mov    ebp,r13d
    2ab8:	and    rbp,rcx
    2abb:	mov    ebp,ebp
    2abd:	mov    QWORD PTR [r12+0xa8],rbp
    2ac5:	mov    r13d,r15d
    2ac8:	mov    r13d,r13d
    2acb:	ror    r13d,0x2
    2acf:	mov    r13d,r13d
    2ad2:	mov    QWORD PTR [r12+0xd0],r13
    2ada:	mov    r13d,0x0
    2ae0:	mov    ecx,r14d
    2ae3:	mov    r15d,r13d
    2ae6:	or     r15,rcx
    2ae9:	mov    r15d,r15d
    2aec:	mov    QWORD PTR [r12+0x20],r15
    2af1:	mov    r13,QWORD PTR [r12+0x88]
    2af9:	mov    r14,QWORD PTR [r12+0x50]
    2afe:	mov    rcx,r13
    2b01:	mov    r15,r14
    2b04:	add    r15,rcx
    2b07:	mov    r13d,DWORD PTR [r15]
    2b0a:	mov    QWORD PTR [r12+0xc8],r13
    2b12:	mov    r13d,DWORD PTR [r12+0xa0]
    2b1a:	mov    r14d,DWORD PTR [r12+0x30]
    2b1f:	mov    ecx,r14d
    2b22:	mov    r15d,r13d
    2b25:	not    rcx
    2b28:	and    r15,rcx
    2b2b:	mov    r15d,r15d
    2b2e:	mov    QWORD PTR [r12+0xd8],r15
    2b36:	mov    r13d,DWORD PTR [r12+0xb0]
    2b3e:	mov    r15d,DWORD PTR [r12+0xa8]
    2b46:	mov    ecx,r13d
    2b49:	mov    ebp,r15d
    2b4c:	add    ebp,ecx
    2b4e:	mov    QWORD PTR [r12+0xa8],rbp
    2b56:	mov    r13d,DWORD PTR [r12+0xb8]
    2b5e:	mov    r15d,r14d
    2b61:	mov    r15d,r15d
    2b64:	shr    r15d,0xb
    2b68:	mov    r15d,r15d
    2b6b:	mov    r8d,r14d
    2b6e:	mov    r8d,r8d
    2b71:	shl    r8d,0x15
    2b75:	mov    r8d,r8d
    2b78:	mov    ecx,r8d
    2b7b:	mov    r14d,r15d
    2b7e:	or     r14,rcx
    2b81:	mov    r14d,r14d
    2b84:	mov    ecx,r14d
    2b87:	mov    r15d,r13d
    2b8a:	xor    r15,rcx
    2b8d:	mov    r15d,r15d
    2b90:	mov    QWORD PTR [r12+0xb0],r15
    2b98:	mov    r13d,DWORD PTR [r12+0xd0]
    2ba0:	mov    r14d,DWORD PTR [r12+0x38]
    2ba5:	mov    r15d,r14d
    2ba8:	mov    r15d,r15d
    2bab:	shr    r15d,0xd
    2baf:	mov    r15d,r15d
    2bb2:	mov    r8d,r14d
    2bb5:	mov    r8d,r8d
    2bb8:	shl    r8d,0x13
    2bbc:	mov    r8d,r8d
    2bbf:	mov    ecx,r8d
    2bc2:	mov    r14d,r15d
    2bc5:	or     r14,rcx
    2bc8:	mov    r14d,r14d
    2bcb:	mov    ecx,r14d
    2bce:	mov    r15d,r13d
    2bd1:	xor    r15,rcx
    2bd4:	mov    r15d,r15d
    2bd7:	mov    QWORD PTR [r12+0xd0],r15
    2bdf:	mov    r13d,DWORD PTR [r12+0xd8]
    2be7:	mov    ecx,r13d
    2bea:	mov    r14d,ebp
    2bed:	add    r14d,ecx
    2bf0:	mov    QWORD PTR [r12+0xa8],r14
    2bf8:	mov    r13,QWORD PTR [r12+0x88]
    2c00:	mov    r15,QWORD PTR [r12+0x48]
    2c05:	mov    rcx,r13
    2c08:	mov    rbp,r15
    2c0b:	add    rbp,rcx
    2c0e:	mov    r13d,DWORD PTR [rbp+0x0]
    2c12:	mov    QWORD PTR [r12+0xb8],r13
    2c1a:	mov    r13d,DWORD PTR [r12+0x28]
    2c1f:	mov    r15d,DWORD PTR [r12+0x98]
    2c27:	mov    ecx,r15d
    2c2a:	mov    ebp,r13d
    2c2d:	and    rbp,rcx
    2c30:	mov    ebp,ebp
    2c32:	mov    QWORD PTR [r12+0xd8],rbp
    2c3a:	mov    ebp,DWORD PTR [r12+0xc8]
    2c42:	mov    ecx,ebp
    2c44:	mov    r8d,r14d
    2c47:	add    r8d,ecx
    2c4a:	mov    QWORD PTR [r12+0xa8],r8
    2c52:	mov    ecx,r15d
    2c55:	mov    r14d,r13d
    2c58:	xor    r14,rcx
    2c5b:	mov    r14d,r14d
    2c5e:	mov    QWORD PTR [r12+0xc8],r14
    2c66:	mov    r13d,DWORD PTR [r12+0xb0]
    2c6e:	mov    r15d,DWORD PTR [r12+0x30]
    2c73:	mov    ebp,r15d
    2c76:	mov    ebp,ebp
    2c78:	shr    ebp,0x19
    2c7b:	mov    ebp,ebp
    2c7d:	mov    r8d,r15d
    2c80:	mov    r8d,r8d
    2c83:	shl    r8d,0x7
    2c87:	mov    r8d,r8d
    2c8a:	mov    ecx,r8d
    2c8d:	mov    r15d,ebp
    2c90:	or     r15,rcx
    2c93:	mov    r15d,r15d
    2c96:	mov    ecx,r15d
    2c99:	mov    ebp,r13d
    2c9c:	xor    rbp,rcx
    2c9f:	mov    ebp,ebp
    2ca1:	mov    QWORD PTR [r12+0xb0],rbp
    2ca9:	mov    r13d,DWORD PTR [r12+0x38]
    2cae:	mov    ecx,r13d
    2cb1:	mov    r15d,r14d
    2cb4:	and    r15,rcx
    2cb7:	mov    r15d,r15d
    2cba:	mov    QWORD PTR [r12+0xc8],r15
    2cc2:	mov    r14d,DWORD PTR [r12+0xd0]
    2cca:	mov    ebp,r13d
    2ccd:	mov    ebp,ebp
    2ccf:	shr    ebp,0x16
    2cd2:	mov    ebp,ebp
    2cd4:	mov    r8d,r13d
    2cd7:	mov    r8d,r8d
    2cda:	shl    r8d,0xa
    2cde:	mov    r8d,r8d
    2ce1:	mov    ecx,r8d
    2ce4:	mov    r13d,ebp
    2ce7:	or     r13,rcx
    2cea:	mov    r13d,r13d
    2ced:	mov    ecx,r13d
    2cf0:	mov    ebp,r14d
    2cf3:	xor    rbp,rcx
    2cf6:	mov    ebp,ebp
    2cf8:	mov    QWORD PTR [r12+0xd0],rbp
    2d00:	mov    r13d,DWORD PTR [r12+0xb8]
    2d08:	mov    r14d,DWORD PTR [r12+0xa8]
    2d10:	mov    ecx,r13d
    2d13:	mov    ebp,r14d
    2d16:	add    ebp,ecx
    2d18:	mov    QWORD PTR [r12+0xa8],rbp
    2d20:	mov    r13d,DWORD PTR [r12+0xd8]
    2d28:	mov    ecx,r13d
    2d2b:	mov    r14d,r15d
    2d2e:	xor    r14,rcx
    2d31:	mov    r14d,r14d
    2d34:	mov    QWORD PTR [r12+0xb8],r14
    2d3c:	mov    r13d,DWORD PTR [r12+0xb0]
    2d44:	mov    ecx,r13d
    2d47:	mov    r15d,ebp
    2d4a:	add    r15d,ecx
    2d4d:	mov    QWORD PTR [r12+0xa8],r15
    2d55:	mov    r13,QWORD PTR [r12+0x88]
    2d5d:	mov    rbp,r13
    2d60:	add    rbp,0x4
    2d64:	mov    QWORD PTR [r12+0x88],rbp
    2d6c:	mov    r13d,DWORD PTR [r12+0xd0]
    2d74:	mov    ecx,r13d
    2d77:	mov    r8d,r14d
    2d7a:	add    r8d,ecx
    2d7d:	mov    QWORD PTR [r12+0xb0],r8
    2d85:	mov    r13d,DWORD PTR [r12+0xc0]
    2d8d:	mov    ecx,r13d
    2d90:	mov    r14d,r15d
    2d93:	add    r14d,ecx
    2d96:	mov    QWORD PTR [r12+0xb8],r14
    2d9e:	mov    r13,rbp
    2da1:	sub    r13,0x100
    2da8:	pushf
    2da9:	pop    rdx
    2daa:	mov    r10d,edx
    2dad:	and    r10d,0xc0
    2db4:	shl    r10d,0x18
    2db8:	mov    r11d,edx
    2dbb:	and    r11d,0x1
    2dbf:	shl    r11d,0x1d
    2dc3:	or     r10d,r11d
    2dc6:	mov    r11d,edx
    2dc9:	and    r11d,0x800
    2dd0:	shl    r11d,0x11
    2dd4:	or     r10d,r11d
    2dd7:	mov    r11d,0xf0000000
    2ddd:	and    r11,r10
    2de0:	movabs rsi,0xffffffff0fffffff
    2dea:	and    rbx,rsi
    2ded:	or     rbx,r11
    2df0:	btc    rbx,0x1d
    2df5:	mov    ecx,r15d
    2df8:	mov    r13d,r8d
    2dfb:	add    r13d,ecx
    2dfe:	mov    QWORD PTR [r12+0xa8],r13
    2e06:	mov    r13d,0x0
    2e0c:	mov    r14d,DWORD PTR [r12+0xa0]
    2e14:	mov    ecx,r14d
    2e17:	mov    r15d,r13d
    2e1a:	or     r15,rcx
    2e1d:	mov    r15d,r15d
    2e20:	mov    QWORD PTR [r12+0xb0],r15
    2e28:	mov    r13d,0x0
    2e2e:	mov    r14d,DWORD PTR [r12+0x20]
    2e33:	mov    ecx,r14d
    2e36:	mov    r15d,r13d
    2e39:	or     r15,rcx
    2e3c:	mov    r15d,r15d
    2e3f:	mov    QWORD PTR [r12+0xc0],r15
    2e47:	mov    r13d,0x0
    2e4d:	mov    r14d,DWORD PTR [r12+0x30]
    2e52:	mov    ecx,r14d
    2e55:	mov    r15d,r13d
    2e58:	or     r15,rcx
    2e5b:	mov    r15d,r15d
    2e5e:	mov    QWORD PTR [r12+0xc8],r15
    2e66:	cmp    QWORD PTR [r12+0x380],0x0
    2e6f:	je     0x2ea0
    2e75:	mov    eax,0x410948
    2e7a:	mov    QWORD PTR [r12+0x100],rax
    2e82:	mov    QWORD PTR [r12+0x108],rbx
    2e8a:	add    rsp,0x50
    2e8e:	mov    eax,0xc
    2e93:	movabs r11,0x5b99604255f0
    2e9d:	jmp    r11
    2ea0:	test   ebx,0x40000000
    2ea6:	je     0x29cb
    2eac:	jmp    0x2eb1
    2eb1:	mov    r13d,DWORD PTR [r12+0x70]
    2eb6:	mov    r14d,DWORD PTR [r12+0x98]
    2ebe:	mov    ecx,r13d
    2ec1:	mov    r15d,r14d
    2ec4:	add    r15d,ecx
    2ec7:	mov    QWORD PTR [r12+0x70],r15
    2ecc:	mov    r13d,DWORD PTR [r12+0x68]
    2ed1:	mov    r14d,DWORD PTR [r12+0x28]
    2ed6:	mov    ecx,r13d
    2ed9:	mov    r15d,r14d
    2edc:	add    r15d,ecx
    2edf:	mov    QWORD PTR [r12+0x68],r15
    2ee4:	mov    r13d,0x0
    2eea:	mov    QWORD PTR [r12+0x88],r13
    2ef2:	mov    r13d,DWORD PTR [r12+0x78]
    2ef7:	mov    r14d,DWORD PTR [r12+0xa8]
    2eff:	mov    ecx,r13d
    2f02:	mov    r15d,r14d
    2f05:	add    r15d,ecx
    2f08:	mov    QWORD PTR [r12+0x78],r15
    2f0d:	mov    r13d,DWORD PTR [r12+0x80]
    2f15:	mov    r14d,DWORD PTR [r12+0x38]
    2f1a:	mov    ecx,r13d
    2f1d:	mov    r15d,r14d
    2f20:	add    r15d,ecx
    2f23:	mov    QWORD PTR [r12+0x80],r15
    2f2b:	mov    r13,QWORD PTR [r12]
    2f2f:	mov    r14,r13
    2f32:	add    r14,0x8
    2f36:	mov    r13,r14
    2f39:	add    r13,0x4
    2f3d:	mov    r15d,DWORD PTR [r12+0x70]
    2f42:	mov    ebp,DWORD PTR [r12+0x68]
    2f47:	mov    DWORD PTR [r14],r15d
    2f4a:	mov    r14d,0x0
    2f50:	mov    DWORD PTR [r12+0x32c],r14d
    2f58:	mov    DWORD PTR [r13+0x0],ebp
    2f5c:	mov    r13d,0x0
    2f62:	mov    DWORD PTR [r12+0x32c],r13d
    2f6a:	mov    r13d,DWORD PTR [r12+0x18]
    2f6f:	mov    r14d,DWORD PTR [r12+0xb8]
    2f77:	mov    ecx,r13d
    2f7a:	mov    r15d,r14d
    2f7d:	add    r15d,ecx
    2f80:	mov    QWORD PTR [r12+0x68],r15
    2f85:	mov    r13d,DWORD PTR [r12+0x90]
    2f8d:	mov    r14d,DWORD PTR [r12+0x30]
    2f92:	mov    ecx,r13d
    2f95:	mov    r15d,r14d
    2f98:	add    r15d,ecx
    2f9b:	mov    QWORD PTR [r12+0x70],r15
    2fa0:	mov    r13d,DWORD PTR [r12+0x58]
    2fa5:	mov    r14d,DWORD PTR [r12+0x20]
    2faa:	mov    ecx,r13d
    2fad:	mov    r15d,r14d
    2fb0:	add    r15d,ecx
    2fb3:	mov    QWORD PTR [r12+0x58],r15
    2fb8:	mov    r13d,DWORD PTR [r12+0x60]
    2fbd:	mov    r14d,DWORD PTR [r12+0xa0]
    2fc5:	mov    ecx,r13d
    2fc8:	mov    r15d,r14d
    2fcb:	add    r15d,ecx
    2fce:	mov    QWORD PTR [r12+0x60],r15
    2fd3:	mov    r13,QWORD PTR [r12]
    2fd7:	mov    r14,r13
    2fda:	add    r14,0x4
    2fde:	mov    ebp,DWORD PTR [r12+0x78]
    2fe3:	mov    r8d,DWORD PTR [r12+0x80]
    2feb:	mov    DWORD PTR [r13+0x0],ebp
    2fef:	mov    ebp,0x0
    2ff4:	mov    DWORD PTR [r12+0x32c],ebp
    2ffc:	mov    DWORD PTR [r14],r8d
    2fff:	mov    r14d,0x0
    3005:	mov    DWORD PTR [r12+0x32c],r14d
    300d:	mov    r14,r13
    3010:	add    r14,0x10
    3014:	mov    rbp,r14
    3017:	add    rbp,0x4
    301b:	mov    r8d,DWORD PTR [r12+0x68]
    3020:	mov    r9d,DWORD PTR [r12+0x70]
    3025:	mov    DWORD PTR [r14],r8d
    3028:	mov    r14d,0x0
    302e:	mov    DWORD PTR [r12+0x32c],r14d
    3036:	mov    DWORD PTR [rbp+0x0],r9d
    303a:	mov    r14d,0x0
    3040:	mov    DWORD PTR [r12+0x32c],r14d
    3048:	mov    r14,r13
    304b:	add    r14,0x18
    304f:	mov    rbp,r14
    3052:	add    rbp,0x4
    3056:	mov    r8d,DWORD PTR [r12+0x58]
    305b:	mov    DWORD PTR [r14],r8d
    305e:	mov    r14d,0x0
    3064:	mov    DWORD PTR [r12+0x32c],r14d
    306c:	mov    DWORD PTR [rbp+0x0],r15d
    3070:	mov    r14d,0x0
    3076:	mov    DWORD PTR [r12+0x32c],r14d
    307e:	mov    r14,r13
    3081:	add    r14,0x68
    3085:	mov    r13d,0x0
    308b:	mov    QWORD PTR [r14],r13
    308e:	mov    r13d,0x0
    3094:	mov    DWORD PTR [r12+0x32c],r13d
    309c:	cmp    QWORD PTR [r12+0x380],0x0
    30a5:	je     0x30d6
    30ab:	mov    eax,0x410984
    30b0:	mov    QWORD PTR [r12+0x100],rax
    30b8:	mov    QWORD PTR [r12+0x108],rbx
    30c0:	add    rsp,0x50
    30c4:	mov    eax,0xc
    30c9:	movabs r11,0x5b99604255f0
    30d3:	jmp    r11
    30d6:	jmp    0x30db
    30db:	mov    r13,QWORD PTR [r12+0x10]
    30e0:	mov    r14,r13
    30e3:	sub    r14,0x1
    30e7:	mov    QWORD PTR [r12+0x10],r14
    30ec:	mov    rax,r14
    30ef:	test   rax,rax
    30f2:	sete   al
    30f5:	movzx  eax,al
    30f8:	and    eax,0x1
    30fb:	mov    r13,rax
    30fe:	mov    rax,r13
    3101:	and    eax,0x1
    3104:	test   rax,rax
    3107:	jne    0x3112
    310d:	jmp    0x22e
    3112:	mov    r13,QWORD PTR [r12+0xf8]
    311a:	mov    r14,r13
    311d:	add    r14,0x140
    3124:	mov    r15,r14
    3127:	add    r15,0x8
    312b:	mov    rbp,QWORD PTR [r14]
    312e:	mov    r14,QWORD PTR [r15]
    3131:	mov    QWORD PTR [r12+0xa0],rbp
    3139:	mov    QWORD PTR [r12+0x98],r14
    3141:	mov    r14,r13
    3144:	add    r14,0x130
    314b:	mov    r15,r14
    314e:	add    r15,0x8
    3152:	mov    rbp,QWORD PTR [r14]
    3155:	mov    r14,QWORD PTR [r15]
    3158:	mov    QWORD PTR [r12+0xb0],rbp
    3160:	mov    QWORD PTR [r12+0xa8],r14
    3168:	mov    r14,r13
    316b:	add    r14,0x120
    3172:	mov    r15,r14
    3175:	add    r15,0x8
    3179:	mov    rbp,QWORD PTR [r14]
    317c:	mov    r14,QWORD PTR [r15]
    317f:	mov    QWORD PTR [r12+0xc0],rbp
    3187:	mov    QWORD PTR [r12+0xb8],r14
    318f:	mov    r14,r13
    3192:	add    r14,0x110
    3199:	mov    r13,r14
    319c:	add    r13,0x8
    31a0:	mov    r15,QWORD PTR [r14]
    31a3:	mov    r14,QWORD PTR [r13+0x0]
    31a7:	mov    QWORD PTR [r12+0xd0],r15
    31af:	mov    QWORD PTR [r12+0xc8],r14
    31b7:	mov    r13,QWORD PTR [r12+0xf8]
    31bf:	mov    r14,r13
    31c2:	add    r14,0x100
    31c9:	mov    r15,r14
    31cc:	add    r15,0x8
    31d0:	mov    rbp,QWORD PTR [r14]
    31d3:	mov    r14,QWORD PTR [r15]
    31d6:	mov    QWORD PTR [r12+0xe8],rbp
    31de:	mov    QWORD PTR [r12+0xd8],r14
    31e6:	mov    r14,r13
    31e9:	add    r14,0x150
    31f0:	mov    QWORD PTR [r12+0xf8],r14
    31f8:	jmp    0x31fd
    31fd:	cmp    QWORD PTR [r12+0x380],0x0
    3206:	je     0x3237
    320c:	mov    eax,0x4109a0
    3211:	mov    QWORD PTR [r12+0x100],rax
    3219:	mov    QWORD PTR [r12+0x108],rbx
    3221:	add    rsp,0x50
    3225:	mov    eax,0xc
    322a:	movabs r11,0x5b99604255f0
    3234:	jmp    r11
    3237:	mov    r13,QWORD PTR [r12+0xf0]
    323f:	mov    QWORD PTR [r12+0x100],r13
    3247:	mov    QWORD PTR [r12+0x108],rbx
    324f:	mov    rdi,QWORD PTR [r12+0x100]
    3257:	add    rsp,0x50
    325b:	movabs r11,0x5b9960425370
    3265:	jmp    r11
    3268:	nop    DWORD PTR [rax+rax*1+0x0]
    3270:	sub    rsp,0x50
    3274:	jmp    0x68
    3279:	nop    DWORD PTR [rax+0x0]
    3280:	sub    rsp,0x50
    3284:	jmp    0x22e
    3289:	nop    DWORD PTR [rax+0x0]
    3290:	sub    rsp,0x50
    3294:	jmp    0x359
    3299:	nop    DWORD PTR [rax+0x0]
    32a0:	sub    rsp,0x50
    32a4:	jmp    0x25fa
    32a9:	nop    DWORD PTR [rax+0x0]
    32b0:	sub    rsp,0x50
    32b4:	jmp    0x2843
    32b9:	nop    DWORD PTR [rax+0x0]
    32c0:	sub    rsp,0x50
    32c4:	jmp    0x29cb
    32c9:	nop    DWORD PTR [rax+0x0]
    32d0:	sub    rsp,0x50
    32d4:	jmp    0x2eb1
    32d9:	nop    DWORD PTR [rax+0x0]
    32e0:	sub    rsp,0x50
    32e4:	jmp    0x30db
    32e9:	nop    DWORD PTR [rax+0x0]
    32f0:	sub    rsp,0x50
    32f4:	jmp    0x3112
    32f9:	nop    DWORD PTR [rax+0x0]
    3300:	sub    rsp,0x50
    3304:	jmp    0x31fd
    3309:	nop
    330a:	nop
    330b:	nop
