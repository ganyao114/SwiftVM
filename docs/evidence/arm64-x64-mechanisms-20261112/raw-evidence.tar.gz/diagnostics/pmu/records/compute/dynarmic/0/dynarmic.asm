000075038bdce69b  nop [rax+rax*1], eax
000075038bdce6a0  mov rax, [r15+0xF8]
000075038bdce6a7  lea r14, [rax-0x1E0]
000075038bdce6ae  mov [r15+0xF8], r14
000075038bdce6b5  lea rax, [r14+0x1D0]
000075038bdce6bc  mov r12, [r15+0xA0]
000075038bdce6c3  mov r11, [r15+0x98]
000075038bdce6ca  mov [r13+rax*1], r12
000075038bdce6cf  lea rax, [r14+0x1D8]
000075038bdce6d6  mov [r13+rax*1], r11
000075038bdce6db  mov eax, 0x420AA0
000075038bdce6e0  movups xmm1, [r13+rax*1]
000075038bdce6e6  mov eax, 0x420A30
000075038bdce6eb  movups xmm15, [r13+rax*1]
000075038bdce6f1  mov eax, 0x420AC0
000075038bdce6f6  movups xmm14, [r13+rax*1]
000075038bdce6fc  mov eax, 0x420A60
000075038bdce701  movups xmm13, [r13+rax*1]
000075038bdce707  mov qword ptr [r15+0x98], 0x430CD0
000075038bdce712  mov eax, 0x420AD0
000075038bdce717  movups xmm12, [r13+rax*1]
000075038bdce71d  mov eax, 0x430CD0
000075038bdce722  movups [r13+rax*1], xmm1
000075038bdce728  mov eax, 0x430CE0
000075038bdce72d  movups [r13+rax*1], xmm15
000075038bdce733  mov eax, 0x430CF0
000075038bdce738  movups [r13+rax*1], xmm14
000075038bdce73e  mov eax, 0x430D00
000075038bdce743  movups [r13+rax*1], xmm13
000075038bdce749  mov eax, 0x420A20
000075038bdce74e  movups xmm14, [r13+rax*1]
000075038bdce754  mov eax, 0x420A10
000075038bdce759  movups xmm13, [r13+rax*1]
000075038bdce75f  mov eax, 0x430DD0
000075038bdce764  movups [r13+rax*1], xmm1
000075038bdce76a  mov eax, 0x430DE0
000075038bdce76f  movups [r13+rax*1], xmm15
000075038bdce775  mov eax, 0x430D10
000075038bdce77a  movups [r13+rax*1], xmm12
000075038bdce780  mov eax, 0x430D20
000075038bdce785  movups [r13+rax*1], xmm14
000075038bdce78b  mov eax, 0x420A00
000075038bdce790  movups xmm1, [r13+rax*1]
000075038bdce796  mov eax, 0x420A70
000075038bdce79b  movups xmm15, [r13+rax*1]
000075038bdce7a1  mov eax, 0x430D30
000075038bdce7a6  movups [r13+rax*1], xmm13
000075038bdce7ac  mov eax, 0x430D40
000075038bdce7b1  movups [r13+rax*1], xmm1
000075038bdce7b7  mov eax, 0x420A80
000075038bdce7bc  movups xmm1, [r13+rax*1]
000075038bdce7c2  mov eax, 0x420A50
000075038bdce7c7  movups xmm14, [r13+rax*1]
000075038bdce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000075038bdce7d5  mov eax, 0x430D50
000075038bdce7da  movups [r13+rax*1], xmm15
000075038bdce7e0  mov eax, 0x430D60
000075038bdce7e5  movups [r13+rax*1], xmm1
000075038bdce7eb  mov eax, 0x420AF0
000075038bdce7f0  movups xmm1, [r13+rax*1]
000075038bdce7f6  mov eax, 0x420B00
000075038bdce7fb  movups xmm15, [r13+rax*1]
000075038bdce801  movaps [r15+0x150], xmm15
000075038bdce809  mov qword ptr [r15+0xA0], 0x3E8
000075038bdce814  mov eax, 0x430D70
000075038bdce819  movups [r13+rax*1], xmm14
000075038bdce81f  mov eax, 0x430D80
000075038bdce824  movups [r13+rax*1], xmm1
000075038bdce82a  mov eax, 0x420AE0
000075038bdce82f  movups xmm1, [r13+rax*1]
000075038bdce835  mov eax, 0x420A90
000075038bdce83a  movups xmm14, [r13+rax*1]
000075038bdce840  movaps [r15+0x140], xmm14
000075038bdce848  lea rax, [r14+0x180]
000075038bdce84f  movq xmm13, qword ptr [r15+0x200]
000075038bdce858  movq xmm12, qword ptr [r15+0x1F0]
000075038bdce861  movq r12, xmm13
000075038bdce866  movq r11, xmm12
000075038bdce86b  mov [r13+rax*1], r12
000075038bdce870  lea rax, [r14+0x188]
000075038bdce877  mov [r13+rax*1], r11
000075038bdce87c  mov eax, 0x430D90
000075038bdce881  movups [r13+rax*1], xmm15
000075038bdce887  mov eax, 0x430DA0
000075038bdce88c  movups [r13+rax*1], xmm1
000075038bdce892  mov eax, 0x420AB0
000075038bdce897  movups xmm1, [r13+rax*1]
000075038bdce89d  mov eax, 0x420B18
000075038bdce8a2  mov r12, [r13+rax*1]
000075038bdce8a7  movq xmm15, r12
000075038bdce8ac  mov qword ptr [r15+0x40], 0x420B20
000075038bdce8b4  mov eax, 0x430DB0
000075038bdce8b9  movups [r13+rax*1], xmm14
000075038bdce8bf  mov eax, 0x430DC0
000075038bdce8c4  movups [r13+rax*1], xmm1
000075038bdce8ca  mov eax, 0x420B80
000075038bdce8cf  movups xmm1, [r13+rax*1]
000075038bdce8d5  movq rax, xmm15
000075038bdce8da  mov r12d, 0x430DF0
000075038bdce8e0  mov [r13+r12*1], rax
000075038bdce8e5  mov eax, 0x420B60
000075038bdce8ea  movups xmm15, [r13+rax*1]
000075038bdce8f0  mov eax, 0x420B70
000075038bdce8f5  movups xmm14, [r13+rax*1]
000075038bdce8fb  lea rax, [r14+0x160]
000075038bdce902  movups [r13+rax*1], xmm1
000075038bdce908  lea rax, [r14+0x190]
000075038bdce90f  movq xmm1, qword ptr [r15+0x1E0]
000075038bdce918  movq xmm13, qword ptr [r15+0x1D0]
000075038bdce921  movq r12, xmm1
000075038bdce926  movq r11, xmm13
000075038bdce92b  mov [r13+rax*1], r12
000075038bdce930  lea rax, [r14+0x198]
000075038bdce937  mov [r13+rax*1], r11
000075038bdce93c  lea rax, [r14+0x140]
000075038bdce943  movups [r13+rax*1], xmm15
000075038bdce949  lea rax, [r14+0x150]
000075038bdce950  movups [r13+rax*1], xmm14
000075038bdce956  mov eax, 0x420B20
000075038bdce95b  movups xmm1, [r13+rax*1]
000075038bdce961  mov eax, 0x420B30
000075038bdce966  movups xmm15, [r13+rax*1]
000075038bdce96c  movaps [r15+0x120], xmm15
000075038bdce974  lea rax, [r14+0x1A0]
000075038bdce97b  movq xmm14, qword ptr [r15+0x1C0]
000075038bdce984  movq xmm13, qword ptr [r15+0x1B0]
000075038bdce98d  movq r12, xmm14
000075038bdce992  movq r11, xmm13
000075038bdce997  mov [r13+rax*1], r12
000075038bdce99c  lea rax, [r14+0x1A8]
000075038bdce9a3  mov [r13+rax*1], r11
000075038bdce9a8  lea rax, [r14+0x1B0]
000075038bdce9af  movq xmm14, qword ptr [r15+0x1A0]
000075038bdce9b8  movq xmm13, qword ptr [r15+0x190]
000075038bdce9c1  movq r12, xmm14
000075038bdce9c6  movq r11, xmm13
000075038bdce9cb  mov [r13+rax*1], r12
000075038bdce9d0  lea rax, [r14+0x1B8]
000075038bdce9d7  mov [r13+rax*1], r11
000075038bdce9dc  lea rax, [r14+0x100]
000075038bdce9e3  movups [r13+rax*1], xmm1
000075038bdce9e9  lea rax, [r14+0x110]
000075038bdce9f0  movups [r13+rax*1], xmm15
000075038bdce9f6  mov eax, 0x420B40
000075038bdce9fb  movups xmm1, [r13+rax*1]
000075038bdcea01  mov eax, 0x420B50
000075038bdcea06  movups xmm15, [r13+rax*1]
000075038bdcea0c  movaps [r15+0x110], xmm1
000075038bdcea14  movaps [r15+0x130], xmm15
000075038bdcea1c  lea rax, [r14+0x1C0]
000075038bdcea23  mov r12, [r15+0xE8]
000075038bdcea2a  mov r11, [r15+0xF0]
000075038bdcea31  mov [r13+rax*1], r12
000075038bdcea36  lea rax, [r14+0x1C8]
000075038bdcea3d  mov [r13+rax*1], r11
000075038bdcea42  mov eax, 0x430DF8
000075038bdcea47  mov r12d, 0x421DF8D3
000075038bdcea4d  mov [r13+rax*1], r12d
000075038bdcea52  lea rax, [r14+0x120]
000075038bdcea59  movups [r13+rax*1], xmm1
000075038bdcea5f  lea rax, [r14+0x130]
000075038bdcea66  movups [r13+rax*1], xmm15
000075038bdcea6c  lea rax, [r14+0x100]
000075038bdcea73  mov [r15], rax
000075038bdcea76  mov qword ptr [r15+0x08], 0x430CD0
000075038bdcea7e  mov qword ptr [r15+0x10], 0x12C
000075038bdcea86  mov qword ptr [r15+0xF0], 0x410284
000075038bdcea91  mov r14d, [r15+0x320]
000075038bdcea98  mov eax, 0x410284
000075038bdcea9d  mov rcx, 0x75038BDD07C0
000075038bdceaa7  mov [r15+r14*8+0x328], rax
000075038bdceaaf  mov [r15+r14*8+0x368], rcx
000075038bdceab7  add r14d, 0x01
000075038bdceabb  and r14d, 0x07
000075038bdceabf  mov [r15+0x320], r14d
000075038bdceac6  cmp dword ptr [r15+0x318], 0x00
000075038bdceace  jz 0x000075038BDCED70
000075038bdcead4  nop [rax+rax*1], ax
000075038bdceadd  nop [rax+rax*1], eax
000075038bdceae5  mov eax, 0x410728
000075038bdceaea  mov [r15+0x100], rax
000075038bdceaf1  jmp 0x000075038BBFE110
000075038bdceaf6  int3
000075038bdceaf7  call 0x000075038BC0BC20
000075038bdceafc  jmp 0x000075038BDCE6CF
000075038bdceb01  call 0x000075038BC0A9A0
000075038bdceb06  jmp 0x000075038BDCE6DB
000075038bdceb0b  call 0x000075038BBFF430
000075038bdceb10  jmp 0x000075038BDCE6E6
000075038bdceb15  call 0x000075038BC0E760
000075038bdceb1a  jmp 0x000075038BDCE6F1
000075038bdceb1f  call 0x000075038BC0D4E0
000075038bdceb24  jmp 0x000075038BDCE6FC
000075038bdceb29  call 0x000075038BC0C260
000075038bdceb2e  jmp 0x000075038BDCE707
000075038bdceb33  call 0x000075038BC0AFE0
000075038bdceb38  jmp 0x000075038BDCE71D
000075038bdceb3d  call 0x000075038BBFF540
000075038bdceb42  jmp 0x000075038BDCE728
000075038bdceb47  call 0x000075038BC0E880
000075038bdceb4c  jmp 0x000075038BDCE733
000075038bdceb51  call 0x000075038BC0D600
000075038bdceb56  jmp 0x000075038BDCE73E
000075038bdceb5b  call 0x000075038BC0C380
000075038bdceb60  jmp 0x000075038BDCE749
000075038bdceb65  call 0x000075038BC0D4E0
000075038bdceb6a  jmp 0x000075038BDCE754
000075038bdceb6f  call 0x000075038BC0C260
000075038bdceb74  jmp 0x000075038BDCE75F
000075038bdceb79  call 0x000075038BBFF540
000075038bdceb7e  jmp 0x000075038BDCE76A
000075038bdceb83  call 0x000075038BC0E880
000075038bdceb88  jmp 0x000075038BDCE775
000075038bdceb8d  call 0x000075038BC0B100
000075038bdceb92  jmp 0x000075038BDCE780
000075038bdceb97  call 0x000075038BC0D600
000075038bdceb9c  jmp 0x000075038BDCE78B
000075038bdceba1  call 0x000075038BBFF430
000075038bdceba6  jmp 0x000075038BDCE796
000075038bdcebab  call 0x000075038BC0E760
000075038bdcebb0  jmp 0x000075038BDCE7A1
000075038bdcebb5  call 0x000075038BC0C380
000075038bdcebba  jmp 0x000075038BDCE7AC
000075038bdcebbf  call 0x000075038BBFF540
000075038bdcebc4  jmp 0x000075038BDCE7B7
000075038bdcebc9  call 0x000075038BBFF430
000075038bdcebce  jmp 0x000075038BDCE7C2
000075038bdcebd3  call 0x000075038BC0D4E0
000075038bdcebd8  jmp 0x000075038BDCE7CD
000075038bdcebdd  call 0x000075038BC0E880
000075038bdcebe2  jmp 0x000075038BDCE7E0
000075038bdcebe7  call 0x000075038BBFF540
000075038bdcebec  jmp 0x000075038BDCE7EB
000075038bdcebf1  call 0x000075038BBFF430
000075038bdcebf6  jmp 0x000075038BDCE7F6
000075038bdcebfb  call 0x000075038BC0E760
000075038bdcec00  jmp 0x000075038BDCE801
000075038bdcec05  call 0x000075038BC0D600
000075038bdcec0a  jmp 0x000075038BDCE81F
000075038bdcec0f  call 0x000075038BBFF540
000075038bdcec14  jmp 0x000075038BDCE82A
000075038bdcec19  call 0x000075038BBFF430
000075038bdcec1e  jmp 0x000075038BDCE835
000075038bdcec23  call 0x000075038BC0D4E0
000075038bdcec28  jmp 0x000075038BDCE840
000075038bdcec2d  call 0x000075038BC0BC20
000075038bdcec32  jmp 0x000075038BDCE870
000075038bdcec37  call 0x000075038BC0A9A0
000075038bdcec3c  jmp 0x000075038BDCE87C
000075038bdcec41  call 0x000075038BC0E880
000075038bdcec46  jmp 0x000075038BDCE887
000075038bdcec4b  call 0x000075038BBFF540
000075038bdcec50  jmp 0x000075038BDCE892
000075038bdcec55  call 0x000075038BBFF430
000075038bdcec5a  jmp 0x000075038BDCE89D
000075038bdcec5f  call 0x000075038BC0B720
000075038bdcec64  jmp 0x000075038BDCE8A7
000075038bdcec69  call 0x000075038BC0D600
000075038bdcec6e  jmp 0x000075038BDCE8BF
000075038bdcec73  call 0x000075038BBFF540
000075038bdcec78  jmp 0x000075038BDCE8CA
000075038bdcec7d  call 0x000075038BBFF430
000075038bdcec82  jmp 0x000075038BDCE8D5
000075038bdcec87  call 0x000075038BCB4CB0
000075038bdcec8c  jmp 0x000075038BDCE8E5
000075038bdcec91  call 0x000075038BC0E760
000075038bdcec96  jmp 0x000075038BDCE8F0
000075038bdcec9b  call 0x000075038BC0D4E0
000075038bdceca0  jmp 0x000075038BDCE8FB
000075038bdceca5  call 0x000075038BBFF540
000075038bdcecaa  jmp 0x000075038BDCE908
000075038bdcecaf  call 0x000075038BC0BC20
000075038bdcecb4  jmp 0x000075038BDCE930
000075038bdcecb9  call 0x000075038BC0A9A0
000075038bdcecbe  jmp 0x000075038BDCE93C
000075038bdcecc3  call 0x000075038BC0E880
000075038bdcecc8  jmp 0x000075038BDCE949
000075038bdceccd  call 0x000075038BC0D600
000075038bdcecd2  jmp 0x000075038BDCE956
000075038bdcecd7  call 0x000075038BBFF430
000075038bdcecdc  jmp 0x000075038BDCE961
000075038bdcece1  call 0x000075038BC0E760
000075038bdcece6  jmp 0x000075038BDCE96C
000075038bdceceb  call 0x000075038BC0BC20
000075038bdcecf0  jmp 0x000075038BDCE99C
000075038bdcecf5  call 0x000075038BC0A9A0
000075038bdcecfa  jmp 0x000075038BDCE9A8
000075038bdcecff  call 0x000075038BC0BC20
000075038bdced04  jmp 0x000075038BDCE9D0
000075038bdced09  call 0x000075038BC0A9A0
000075038bdced0e  jmp 0x000075038BDCE9DC
000075038bdced13  call 0x000075038BBFF540
000075038bdced18  jmp 0x000075038BDCE9E9
000075038bdced1d  call 0x000075038BC0E880
000075038bdced22  jmp 0x000075038BDCE9F6
000075038bdced27  call 0x000075038BBFF430
000075038bdced2c  jmp 0x000075038BDCEA01
000075038bdced31  call 0x000075038BC0E760
000075038bdced36  jmp 0x000075038BDCEA0C
000075038bdced3b  call 0x000075038BC0BC20
000075038bdced40  jmp 0x000075038BDCEA36
000075038bdced45  call 0x000075038BC0A9A0
000075038bdced4a  jmp 0x000075038BDCEA42
000075038bdced4f  call 0x000075038BC0BAE0
000075038bdced54  jmp 0x000075038BDCEA52
000075038bdced59  call 0x000075038BBFF540
000075038bdced5e  jmp 0x000075038BDCEA5F
000075038bdced63  call 0x000075038BC0E880
000075038bdced68  jmp 0x000075038BDCEA6C
000075038bdced6d  int3
000075038bdced6e  nop
000075038bdced70  mov rax, [r15]
000075038bdced73  lea r14, [rax+0x20]
000075038bdced77  mov r12, [r13+r14*1]
000075038bdced7c  mov r14, [r15+0x10]
000075038bdced80  lea r11, [r12+r14*1]
000075038bdced84  mov [r15+0x40], r11
000075038bdced88  lea r12, [rax+0x20]
000075038bdced8c  mov [r13+r12*1], r11
000075038bdced91  test r14, r14
000075038bdced94  setz r14b
000075038bdced98  movzx r14, r14b
000075038bdced9c  mov [rsp+0x414], r14b
000075038bdceda4  cmp byte ptr [rsp+0x414], 0x00
000075038bdcedac  jz 0x000075038BDCEDDE
000075038bdcedae  cmp dword ptr [r15+0x318], 0x00
000075038bdcedb6  mov eax, 0x4109A0
000075038bdcedbb  mov [r15+0x100], rax
000075038bdcedc2  jz 0x000075038BBFE0A0
000075038bdcedc8  nop [rax+rax*1], eax
000075038bdcedcd  mov eax, 0x4109A0
000075038bdcedd2  mov [r15+0x100], rax
000075038bdcedd9  jmp 0x000075038BBFE110
000075038bdcedde  cmp dword ptr [r15+0x318], 0x00
000075038bdcede6  jz 0x000075038BDCEE30
000075038bdcedec  nop [rax+rax*1], ax
000075038bdcedf5  nop [rax+rax*1], eax
000075038bdcedfd  mov eax, 0x410738
000075038bdcee02  mov [r15+0x100], rax
000075038bdcee09  jmp 0x000075038BBFE110
000075038bdcee0e  int3
000075038bdcee0f  call 0x000075038BCE27E0
000075038bdcee14  jmp 0x000075038BDCED7C
000075038bdcee19  call 0x000075038BCC0860
000075038bdcee1e  jmp 0x000075038BDCED91
000075038bdcee23  int3
000075038bdcee24  nop [rax+rax*1], ax
000075038bdcee2d  nop [rax], eax
000075038bdcee30  mov rax, [r15+0xF8]
000075038bdcee37  lea r14, [rax-0x150]
000075038bdcee3e  mov [r15+0xF8], r14
000075038bdcee45  mov rax, [r15]
000075038bdcee48  lea r12, [rax+0x68]
000075038bdcee4c  mov r11, [r13+r12*1]
000075038bdcee51  mov [r15+0x88], r11
000075038bdcee58  lea r12, [rax+0x28]
000075038bdcee5c  mov [r15+0x40], r12
000075038bdcee60  mov [r15+0x48], r14
000075038bdcee64  mov qword ptr [r15+0x50], 0x420B90
000075038bdcee6c  lea rax, [r14+0x100]
000075038bdcee73  mov r12, [r15+0xE8]
000075038bdcee7a  mov r11, [r15+0xD8]
000075038bdcee81  mov [r13+rax*1], r12
000075038bdcee86  lea rax, [r14+0x108]
000075038bdcee8d  mov [r13+rax*1], r11
000075038bdcee92  lea rax, [r14+0x110]
000075038bdcee99  mov r12, [r15+0xD0]
000075038bdceea0  mov r11, [r15+0xC8]
000075038bdceea7  mov [r13+rax*1], r12
000075038bdceeac  lea rax, [r14+0x118]
000075038bdceeb3  mov [r13+rax*1], r11
000075038bdceeb8  lea rax, [r14+0x120]
000075038bdceebf  mov r12, [r15+0xC0]
000075038bdceec6  mov r11, [r15+0xB8]
000075038bdceecd  mov [r13+rax*1], r12
000075038bdceed2  lea rax, [r14+0x128]
000075038bdceed9  mov [r13+rax*1], r11
000075038bdceede  lea rax, [r14+0x130]
000075038bdceee5  mov r12, [r15+0xB0]
000075038bdceeec  mov r11, [r15+0xA8]
000075038bdceef3  mov [r13+rax*1], r12
000075038bdceef8  lea rax, [r14+0x138]
000075038bdceeff  mov [r13+rax*1], r11
000075038bdcef04  lea rax, [r14+0x140]
000075038bdcef0b  mov r12, [r15+0xA0]
000075038bdcef12  mov r11, [r15+0x98]
000075038bdcef19  mov [r13+rax*1], r12
000075038bdcef1e  lea rax, [r14+0x148]
000075038bdcef25  mov [r13+rax*1], r11
000075038bdcef2a  cmp dword ptr [r15+0x318], 0x00
000075038bdcef32  jz 0x000075038BDCEFD0
000075038bdcef38  nop [rax+rax*1], ax
000075038bdcef41  nop [rax+rax*1], eax
000075038bdcef49  mov eax, 0x410770
000075038bdcef4e  mov [r15+0x100], rax
000075038bdcef55  jmp 0x000075038BBFE110
000075038bdcef5a  int3
000075038bdcef5b  call 0x000075038BCC0370
000075038bdcef60  jmp 0x000075038BDCEE51
000075038bdcef65  call 0x000075038BC0BC20
000075038bdcef6a  jmp 0x000075038BDCEE86
000075038bdcef6f  call 0x000075038BC0A9A0
000075038bdcef74  jmp 0x000075038BDCEE92
000075038bdcef79  call 0x000075038BC0BC20
000075038bdcef7e  jmp 0x000075038BDCEEAC
000075038bdcef83  call 0x000075038BC0A9A0
000075038bdcef88  jmp 0x000075038BDCEEB8
000075038bdcef8d  call 0x000075038BC0BC20
000075038bdcef92  jmp 0x000075038BDCEED2
000075038bdcef97  call 0x000075038BC0A9A0
000075038bdcef9c  jmp 0x000075038BDCEEDE
000075038bdcefa1  call 0x000075038BC0BC20
000075038bdcefa6  jmp 0x000075038BDCEEF8
000075038bdcefab  call 0x000075038BC0A9A0
000075038bdcefb0  jmp 0x000075038BDCEF04
000075038bdcefb5  call 0x000075038BC0BC20
000075038bdcefba  jmp 0x000075038BDCEF1E
000075038bdcefbf  call 0x000075038BC0A9A0
000075038bdcefc4  jmp 0x000075038BDCEF2A
000075038bdcefc9  int3
000075038bdcefca  nop [rax+rax*1], ax
000075038bdcefd0  mov rax, [r15+0x08]
000075038bdcefd4  movzx r14d, byte ptr [r13+rax*1]
000075038bdcefda  movzx r14d, r14b
000075038bdcefde  mov [rsp+0x10], r14d
000075038bdcefe3  mov r14d, r14d
000075038bdcefe6  mov [r15+0x58], r14
000075038bdcefea  lea r14, [rax+0x01]
000075038bdcefee  mov [r15+0x08], r14
000075038bdceff2  mov rax, [r15+0x88]
000075038bdceff9  lea r14, [rax+0x01]
000075038bdceffd  mov r12, [r15]
000075038bdcf000  lea r11, [r12+0x68]
000075038bdcf005  mov [r13+r11*1], r14
000075038bdcf00a  lea r14, [r12+rax*1]
000075038bdcf00e  mov [r15+0x60], r14
000075038bdcf012  lea rax, [r14+0x28]
000075038bdcf016  mov r11d, [rsp+0x10]
000075038bdcf01b  movzx r14d, r11b
000075038bdcf01f  mov [r13+rax*1], r14b
000075038bdcf024  lea rax, [r12+0x68]
000075038bdcf029  mov r14, [r13+rax*1]
000075038bdcf02e  mov [r15+0x88], r14
000075038bdcf035  xor eax, eax
000075038bdcf037  mov r12d, 0x40
000075038bdcf03d  cmp r14, r12
000075038bdcf040  cmc
000075038bdcf041  lahf
000075038bdcf042  seto al
000075038bdcf045  mov [r15+0x108], eax
000075038bdcf04c  mov eax, [r15+0x108]
000075038bdcf053  sahf
000075038bdcf054  jnz 0x000075038BDCF086
000075038bdcf056  cmp dword ptr [r15+0x318], 0x00
000075038bdcf05e  jz 0x000075038BDCF170
000075038bdcf064  nop [rax+rax*1], ax
000075038bdcf06d  nop [rax+rax*1], eax
000075038bdcf075  mov eax, 0x410790
000075038bdcf07a  mov [r15+0x100], rax
000075038bdcf081  jmp 0x000075038BBFE110
000075038bdcf086  cmp dword ptr [r15+0x318], 0x00
000075038bdcf08e  jz 0x000075038BDCF0E0
000075038bdcf094  nop [rax+rax*1], ax
000075038bdcf09d  nop [rax+rax*1], eax
000075038bdcf0a5  mov eax, 0x410768
000075038bdcf0aa  mov [r15+0x100], rax
000075038bdcf0b1  jmp 0x000075038BBFE110
000075038bdcf0b6  int3
000075038bdcf0b7  call 0x000075038BC0D860
000075038bdcf0bc  jmp 0x000075038BDCEFDA
000075038bdcf0c1  call 0x000075038BCB36E0
000075038bdcf0c6  jmp 0x000075038BDCF00A
000075038bdcf0cb  call 0x000075038BC0DD60
000075038bdcf0d0  jmp 0x000075038BDCF024
000075038bdcf0d5  call 0x000075038BC0DC20
000075038bdcf0da  jmp 0x000075038BDCF02E
000075038bdcf0df  int3
000075038bdcf0e0  mov rax, [r15+0x10]
000075038bdcf0e4  lea r14, [rax-0x01]
000075038bdcf0e8  mov [r15+0x10], r14
000075038bdcf0ec  test r14, r14
000075038bdcf0ef  setz r14b
000075038bdcf0f3  movzx r14, r14b
000075038bdcf0f7  mov [rsp+0x414], r14b
000075038bdcf0ff  cmp byte ptr [rsp+0x414], 0x00
000075038bdcf107  jz 0x000075038BDCF139
000075038bdcf109  cmp dword ptr [r15+0x318], 0x00
000075038bdcf111  jz 0x000075038BDD0670
000075038bdcf117  nop [rax+rax*1], ax
000075038bdcf120  nop [rax+rax*1], eax
000075038bdcf128  mov eax, 0x410988
000075038bdcf12d  mov [r15+0x100], rax
000075038bdcf134  jmp 0x000075038BBFE110
000075038bdcf139  cmp dword ptr [r15+0x318], 0x00
000075038bdcf141  jz 0x000075038BDCEFD0
000075038bdcf147  nop [rax+rax*1], ax
000075038bdcf150  nop [rax+rax*1], eax
000075038bdcf158  mov eax, 0x410770
000075038bdcf15d  mov [r15+0x100], rax
000075038bdcf164  jmp 0x000075038BBFE110
000075038bdcf169  int3
000075038bdcf16a  int3
000075038bdcf16b  nop [rax+rax*1], eax
000075038bdcf170  mov rax, [r15+0x40]
000075038bdcf174  movzx r14d, byte ptr [r13+rax*1]
000075038bdcf17a  movaps xmm1, [r15+0x110]
000075038bdcf182  pinsrb xmm1, r14d, 0x00
000075038bdcf189  lea r14, [rax+0x01]
000075038bdcf18d  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf193  movaps xmm15, [r15+0x120]
000075038bdcf19b  pinsrb xmm15, r12d, 0x00
000075038bdcf1a2  lea r14, [rax+0x02]
000075038bdcf1a6  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf1ac  movaps xmm14, [r15+0x130]
000075038bdcf1b4  pinsrb xmm14, r12d, 0x00
000075038bdcf1bb  lea r14, [rax+0x03]
000075038bdcf1bf  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf1c5  movaps xmm13, [r15+0x140]
000075038bdcf1cd  pinsrb xmm13, r12d, 0x00
000075038bdcf1d4  lea r14, [rax+0x04]
000075038bdcf1d8  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf1de  pinsrb xmm1, r12d, 0x01
000075038bdcf1e5  lea r14, [rax+0x05]
000075038bdcf1e9  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf1ef  pinsrb xmm15, r12d, 0x01
000075038bdcf1f6  lea r14, [rax+0x06]
000075038bdcf1fa  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf200  pinsrb xmm14, r12d, 0x01
000075038bdcf207  lea r14, [rax+0x07]
000075038bdcf20b  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf211  pinsrb xmm13, r12d, 0x01
000075038bdcf218  lea r14, [rax+0x08]
000075038bdcf21c  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf222  pinsrb xmm1, r12d, 0x02
000075038bdcf229  lea r14, [rax+0x09]
000075038bdcf22d  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf233  pinsrb xmm15, r12d, 0x02
000075038bdcf23a  lea r14, [rax+0x0A]
000075038bdcf23e  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf244  pinsrb xmm14, r12d, 0x02
000075038bdcf24b  lea r14, [rax+0x0B]
000075038bdcf24f  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf255  pinsrb xmm13, r12d, 0x02
000075038bdcf25c  lea r14, [rax+0x0C]
000075038bdcf260  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf266  pinsrb xmm1, r12d, 0x03
000075038bdcf26d  lea r14, [rax+0x0D]
000075038bdcf271  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf277  pinsrb xmm15, r12d, 0x03
000075038bdcf27e  lea r14, [rax+0x0E]
000075038bdcf282  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf288  pinsrb xmm14, r12d, 0x03
000075038bdcf28f  lea r14, [rax+0x0F]
000075038bdcf293  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf299  pinsrb xmm13, r12d, 0x03
000075038bdcf2a0  lea r14, [rax+0x10]
000075038bdcf2a4  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf2aa  pinsrb xmm1, r12d, 0x04
000075038bdcf2b1  lea r14, [rax+0x11]
000075038bdcf2b5  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf2bb  pinsrb xmm15, r12d, 0x04
000075038bdcf2c2  lea r14, [rax+0x12]
000075038bdcf2c6  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf2cc  pinsrb xmm14, r12d, 0x04
000075038bdcf2d3  lea r14, [rax+0x13]
000075038bdcf2d7  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf2dd  pinsrb xmm13, r12d, 0x04
000075038bdcf2e4  lea r14, [rax+0x14]
000075038bdcf2e8  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf2ee  pinsrb xmm1, r12d, 0x05
000075038bdcf2f5  lea r14, [rax+0x15]
000075038bdcf2f9  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf2ff  pinsrb xmm15, r12d, 0x05
000075038bdcf306  lea r14, [rax+0x16]
000075038bdcf30a  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf310  pinsrb xmm14, r12d, 0x05
000075038bdcf317  lea r14, [rax+0x17]
000075038bdcf31b  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf321  pinsrb xmm13, r12d, 0x05
000075038bdcf328  lea r14, [rax+0x18]
000075038bdcf32c  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf332  pinsrb xmm1, r12d, 0x06
000075038bdcf339  lea r14, [rax+0x19]
000075038bdcf33d  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf343  pinsrb xmm15, r12d, 0x06
000075038bdcf34a  lea r14, [rax+0x1A]
000075038bdcf34e  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf354  pinsrb xmm14, r12d, 0x06
000075038bdcf35b  lea r14, [rax+0x1B]
000075038bdcf35f  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf365  pinsrb xmm13, r12d, 0x06
000075038bdcf36c  lea r14, [rax+0x1C]
000075038bdcf370  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf376  pinsrb xmm1, r12d, 0x07
000075038bdcf37d  lea r14, [rax+0x1D]
000075038bdcf381  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf387  pinsrb xmm15, r12d, 0x07
000075038bdcf38e  lea r14, [rax+0x1E]
000075038bdcf392  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf398  pinsrb xmm14, r12d, 0x07
000075038bdcf39f  lea r14, [rax+0x1F]
000075038bdcf3a3  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf3a9  pinsrb xmm13, r12d, 0x07
000075038bdcf3b0  lea r14, [rax+0x20]
000075038bdcf3b4  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf3ba  pinsrb xmm1, r12d, 0x08
000075038bdcf3c1  lea r14, [rax+0x21]
000075038bdcf3c5  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf3cb  pinsrb xmm15, r12d, 0x08
000075038bdcf3d2  lea r14, [rax+0x22]
000075038bdcf3d6  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf3dc  pinsrb xmm14, r12d, 0x08
000075038bdcf3e3  lea r14, [rax+0x23]
000075038bdcf3e7  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf3ed  pinsrb xmm13, r12d, 0x08
000075038bdcf3f4  lea r14, [rax+0x24]
000075038bdcf3f8  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf3fe  pinsrb xmm1, r12d, 0x09
000075038bdcf405  lea r14, [rax+0x25]
000075038bdcf409  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf40f  pinsrb xmm15, r12d, 0x09
000075038bdcf416  lea r14, [rax+0x26]
000075038bdcf41a  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf420  pinsrb xmm14, r12d, 0x09
000075038bdcf427  lea r14, [rax+0x27]
000075038bdcf42b  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf431  pinsrb xmm13, r12d, 0x09
000075038bdcf438  lea r14, [rax+0x28]
000075038bdcf43c  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf442  pinsrb xmm1, r12d, 0x0A
000075038bdcf449  lea r14, [rax+0x29]
000075038bdcf44d  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf453  pinsrb xmm15, r12d, 0x0A
000075038bdcf45a  lea r14, [rax+0x2A]
000075038bdcf45e  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf464  pinsrb xmm14, r12d, 0x0A
000075038bdcf46b  lea r14, [rax+0x2B]
000075038bdcf46f  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf475  pinsrb xmm13, r12d, 0x0A
000075038bdcf47c  lea r14, [rax+0x2C]
000075038bdcf480  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf486  pinsrb xmm1, r12d, 0x0B
000075038bdcf48d  lea r14, [rax+0x2D]
000075038bdcf491  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf497  pinsrb xmm15, r12d, 0x0B
000075038bdcf49e  lea r14, [rax+0x2E]
000075038bdcf4a2  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf4a8  pinsrb xmm14, r12d, 0x0B
000075038bdcf4af  lea r14, [rax+0x2F]
000075038bdcf4b3  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf4b9  pinsrb xmm13, r12d, 0x0B
000075038bdcf4c0  lea r14, [rax+0x30]
000075038bdcf4c4  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf4ca  pinsrb xmm1, r12d, 0x0C
000075038bdcf4d1  lea r14, [rax+0x31]
000075038bdcf4d5  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf4db  pinsrb xmm15, r12d, 0x0C
000075038bdcf4e2  lea r14, [rax+0x32]
000075038bdcf4e6  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf4ec  pinsrb xmm14, r12d, 0x0C
000075038bdcf4f3  lea r14, [rax+0x33]
000075038bdcf4f7  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf4fd  pinsrb xmm13, r12d, 0x0C
000075038bdcf504  lea r14, [rax+0x34]
000075038bdcf508  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf50e  pinsrb xmm1, r12d, 0x0D
000075038bdcf515  lea r14, [rax+0x35]
000075038bdcf519  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf51f  pinsrb xmm15, r12d, 0x0D
000075038bdcf526  lea r14, [rax+0x36]
000075038bdcf52a  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf530  pinsrb xmm14, r12d, 0x0D
000075038bdcf537  lea r14, [rax+0x37]
000075038bdcf53b  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf541  pinsrb xmm13, r12d, 0x0D
000075038bdcf548  lea r14, [rax+0x38]
000075038bdcf54c  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf552  pinsrb xmm1, r12d, 0x0E
000075038bdcf559  lea r14, [rax+0x39]
000075038bdcf55d  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf563  pinsrb xmm15, r12d, 0x0E
000075038bdcf56a  lea r14, [rax+0x3A]
000075038bdcf56e  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf574  pinsrb xmm14, r12d, 0x0E
000075038bdcf57b  lea r14, [rax+0x3B]
000075038bdcf57f  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf585  pinsrb xmm13, r12d, 0x0E
000075038bdcf58c  lea r14, [rax+0x3C]
000075038bdcf590  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf596  pinsrb xmm1, r12d, 0x0F
000075038bdcf59d  movaps [r15+0x110], xmm1
000075038bdcf5a5  lea r14, [rax+0x3D]
000075038bdcf5a9  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf5af  pinsrb xmm15, r12d, 0x0F
000075038bdcf5b6  movaps [r15+0x120], xmm15
000075038bdcf5be  lea r14, [rax+0x3E]
000075038bdcf5c2  movzx r12d, byte ptr [r13+r14*1]
000075038bdcf5c8  pinsrb xmm14, r12d, 0x0F
000075038bdcf5cf  movaps [r15+0x130], xmm14
000075038bdcf5d7  lea r14, [rax+0x3F]
000075038bdcf5db  movzx eax, byte ptr [r13+r14*1]
000075038bdcf5e1  pinsrb xmm13, eax, 0x0F
000075038bdcf5e8  movaps [r15+0x140], xmm13
000075038bdcf5f0  movq xmm1, qword ptr [r15+0x120]
000075038bdcf5f9  pmovzxbw xmm1, xmm1
000075038bdcf5fe  psllw xmm1, 0x00
000075038bdcf603  movaps [r15+0x150], xmm1
000075038bdcf60b  movq xmm1, qword ptr [r15+0x130]
000075038bdcf614  pmovzxbw xmm1, xmm1
000075038bdcf619  psllw xmm1, 0x00
000075038bdcf61e  movaps [r15+0x160], xmm1
000075038bdcf626  movq xmm1, qword ptr [r15+0x110]
000075038bdcf62f  pmovzxbw xmm1, xmm1
000075038bdcf634  psllw xmm1, 0x00
000075038bdcf639  movaps [r15+0x170], xmm1
000075038bdcf641  movaps xmm15, [r15+0x110]
000075038bdcf649  pextrq rax, xmm15, 0x01
000075038bdcf650  movq xmm15, rax
000075038bdcf655  pmovzxbw xmm15, xmm15
000075038bdcf65b  psllw xmm15, 0x00
000075038bdcf661  movaps [r15+0x180], xmm15
000075038bdcf669  movaps xmm14, [r15+0x120]
000075038bdcf671  pextrq rax, xmm14, 0x01
000075038bdcf678  movq xmm14, rax
000075038bdcf67d  pmovzxbw xmm14, xmm14
000075038bdcf683  psllw xmm14, 0x00
000075038bdcf689  movaps [r15+0x210], xmm14
000075038bdcf691  movaps xmm13, [r15+0x130]
000075038bdcf699  pextrq rax, xmm13, 0x01
000075038bdcf6a0  movq xmm13, rax
000075038bdcf6a5  pmovzxbw xmm13, xmm13
000075038bdcf6ab  psllw xmm13, 0x00
000075038bdcf6b1  movaps [r15+0x220], xmm13
000075038bdcf6b9  movq xmm12, qword ptr [r15+0x140]
000075038bdcf6c2  pmovzxbw xmm12, xmm12
000075038bdcf6c8  psllw xmm12, 0x00
000075038bdcf6ce  movaps [r15+0x250], xmm12
000075038bdcf6d6  movaps xmm12, [r15+0x140]
000075038bdcf6de  pextrq rax, xmm12, 0x01
000075038bdcf6e5  movq xmm12, rax
000075038bdcf6ea  pmovzxbw xmm12, xmm12
000075038bdcf6f0  psllw xmm12, 0x00
000075038bdcf6f6  movaps [r15+0x110], xmm12
000075038bdcf6fe  movq xmm11, qword ptr [r15+0x150]
000075038bdcf707  pmovzxwd xmm11, xmm11
000075038bdcf70d  pslld xmm11, 0x10
000075038bdcf713  movq xmm10, qword ptr [r15+0x160]
000075038bdcf71c  pmovzxwd xmm10, xmm10
000075038bdcf722  pslld xmm10, 0x08
000075038bdcf728  pextrq rax, xmm1, 0x01
000075038bdcf72f  movq xmm1, rax
000075038bdcf734  pmovzxwd xmm1, xmm1
000075038bdcf739  pslld xmm1, 0x00
000075038bdcf73e  movaps [r15+0x260], xmm1
000075038bdcf746  pextrq rax, xmm15, 0x01
000075038bdcf74d  movq xmm15, rax
000075038bdcf752  pmovzxwd xmm15, xmm15
000075038bdcf758  pslld xmm15, 0x00
000075038bdcf75e  movaps [r15+0x270], xmm15
000075038bdcf766  movq xmm9, qword ptr [r15+0x170]
000075038bdcf76f  pmovzxwd xmm9, xmm9
000075038bdcf775  pslld xmm9, 0x00
000075038bdcf77b  pextrq rax, xmm14, 0x01
000075038bdcf782  movq xmm14, rax
000075038bdcf787  pmovzxwd xmm14, xmm14
000075038bdcf78d  pslld xmm14, 0x10
000075038bdcf793  movaps [r15+0x280], xmm14
000075038bdcf79b  movq xmm8, qword ptr [r15+0x180]
000075038bdcf7a4  pmovzxwd xmm8, xmm8
000075038bdcf7aa  pslld xmm8, 0x00
000075038bdcf7b0  movq xmm7, qword ptr [r15+0x210]
000075038bdcf7b9  pmovzxwd xmm7, xmm7
000075038bdcf7be  pslld xmm7, 0x10
000075038bdcf7c3  movaps xmm6, [r15+0x150]
000075038bdcf7cb  pextrq rax, xmm6, 0x01
000075038bdcf7d2  movq xmm6, rax
000075038bdcf7d7  pmovzxwd xmm6, xmm6
000075038bdcf7dc  pslld xmm6, 0x10
000075038bdcf7e1  por xmm11, xmm10
000075038bdcf7e6  movaps [r15+0x230], xmm11
000075038bdcf7ee  pextrq rax, xmm13, 0x01
000075038bdcf7f5  movq xmm13, rax
000075038bdcf7fa  pmovzxwd xmm13, xmm13
000075038bdcf800  pslld xmm13, 0x08
000075038bdcf806  movaps [r15+0x240], xmm13
000075038bdcf80e  movq xmm10, qword ptr [r15+0x220]
000075038bdcf817  pmovzxwd xmm10, xmm10
000075038bdcf81d  pslld xmm10, 0x08
000075038bdcf823  movaps xmm5, [r15+0x160]
000075038bdcf82b  pextrq rax, xmm5, 0x01
000075038bdcf832  movq xmm5, rax
000075038bdcf837  pmovzxwd xmm5, xmm5
000075038bdcf83c  pslld xmm5, 0x08
000075038bdcf841  pslld xmm9, 0x18
000075038bdcf847  pslld xmm15, 0x18
000075038bdcf84d  pslld xmm8, 0x18
000075038bdcf853  movq xmm4, qword ptr [r15+0x250]
000075038bdcf85c  pmovzxwd xmm4, xmm4
000075038bdcf861  pslld xmm4, 0x00
000075038bdcf866  por xmm14, xmm13
000075038bdcf86b  por xmm7, xmm10
000075038bdcf870  movaps [r15+0x210], xmm7
000075038bdcf878  pslld xmm1, 0x18
000075038bdcf87d  movaps [r15+0x220], xmm1
000075038bdcf885  por xmm6, xmm5
000075038bdcf889  por xmm11, xmm9
000075038bdcf88e  movaps [r15+0x160], xmm11
000075038bdcf896  pextrq rax, xmm12, 0x01
000075038bdcf89d  movq xmm13, rax
000075038bdcf8a2  pmovzxwd xmm13, xmm13
000075038bdcf8a8  pslld xmm13, 0x00
000075038bdcf8ae  movaps [r15+0x170], xmm13
000075038bdcf8b6  movq xmm12, qword ptr [r15+0x110]
000075038bdcf8bf  pmovzxwd xmm12, xmm12
000075038bdcf8c5  pslld xmm12, 0x00
000075038bdcf8cb  por xmm14, xmm15
000075038bdcf8d0  por xmm7, xmm8
000075038bdcf8d5  movaps xmm15, [r15+0x250]
000075038bdcf8dd  pextrq rax, xmm15, 0x01
000075038bdcf8e4  movq xmm15, rax
000075038bdcf8e9  pmovzxwd xmm15, xmm15
000075038bdcf8ef  pslld xmm15, 0x00
000075038bdcf8f5  movaps [r15+0x180], xmm15
000075038bdcf8fd  por xmm6, xmm1
000075038bdcf901  movaps [r15+0x150], xmm6
000075038bdcf909  por xmm11, xmm4
000075038bdcf90e  movaps [r15+0x140], xmm11
000075038bdcf916  por xmm7, xmm12
000075038bdcf91b  movaps [r15+0x110], xmm7
000075038bdcf923  por xmm14, xmm13
000075038bdcf928  movaps [r15+0x120], xmm14
000075038bdcf930  por xmm6, xmm15
000075038bdcf935  movaps [r15+0x130], xmm6
000075038bdcf93d  mov rax, [r15+0xF8]
000075038bdcf944  lea r14, [rax+0x20]
000075038bdcf948  movups [r13+r14*1], xmm7
000075038bdcf94e  lea r14, [rax+0x30]
000075038bdcf952  movups [r13+r14*1], xmm14
000075038bdcf958  movups [r13+rax*1], xmm11
000075038bdcf95e  lea r14, [rax+0x10]
000075038bdcf962  movups [r13+r14*1], xmm6
000075038bdcf968  mov r14d, [r13+rax*1]
000075038bdcf96d  mov rax, [r15+0x48]
000075038bdcf971  mov [r15+0x68], rax
000075038bdcf975  mov qword ptr [r15+0x58], 0x04
000075038bdcf97d  lea r12, [rax+0x04]
000075038bdcf981  mov r11d, [r13+r12*1]
000075038bdcf986  mov [rsp+0x10], r11d
000075038bdcf98b  mov r11d, r11d
000075038bdcf98e  mov [r15+0x70], r11
000075038bdcf992  lea r12, [rax+0x38]
000075038bdcf996  mov r11d, [r13+r12*1]
000075038bdcf99b  lea r12, [rax+0x24]
000075038bdcf99f  mov r10d, [r13+r12*1]
000075038bdcf9a4  mov [rsp+0x20], r10d
000075038bdcf9a9  mov r10d, r10d
000075038bdcf9ac  mov [r15+0x90], r10
000075038bdcf9b3  mov [rsp+0x30], rax
000075038bdcf9b8  xor eax, eax
000075038bdcf9ba  mov r12d, 0x04
000075038bdcf9c0  mov r10d, 0xC0
000075038bdcf9c6  cmp r12, r10
000075038bdcf9c9  cmc
000075038bdcf9ca  lahf
000075038bdcf9cb  seto al
000075038bdcf9ce  mov [r15+0x108], eax
000075038bdcf9d5  mov eax, [rsp+0x10]
000075038bdcf9d9  mov r12d, [rsp+0x10]
000075038bdcf9de  shrd eax, r12d, 0x07
000075038bdcf9e3  mov [rsp+0x10], r11d
000075038bdcf9e8  mov r10d, [rsp+0x10]
000075038bdcf9ed  shrd r11d, r10d, 0x11
000075038bdcf9f2  mov r9d, [rsp+0x20]
000075038bdcf9f7  lea r8d, [r9d+r14d*1]
000075038bdcf9fc  rorx r14d, r12d, 0x12
000075038bdcfa02  xor eax, r14d
000075038bdcfa05  rorx r14d, r10d, 0x13
000075038bdcfa0b  xor r11d, r14d
000075038bdcfa0e  mov [rsp+0x10], r11d
000075038bdcfa13  mov r11d, r11d
000075038bdcfa16  mov [r15+0x88], r11
000075038bdcfa1d  mov [rsp+0x20], r12d
000075038bdcfa22  shr r12d, 0x03
000075038bdcfa26  xor eax, r12d
000075038bdcfa29  mov [rsp+0x40], eax
000075038bdcfa2d  mov eax, eax
000075038bdcfa2f  mov [r15+0x80], rax
000075038bdcfa36  shr r10d, 0x0A
000075038bdcfa3a  mov eax, [rsp+0x10]
000075038bdcfa3e  xor eax, r10d
000075038bdcfa41  mov [rsp+0x10], eax
000075038bdcfa45  mov eax, eax
000075038bdcfa47  mov [r15+0x78], rax
000075038bdcfa4b  mov eax, [rsp+0x40]
000075038bdcfa4f  lea r14d, [r8d+eax*1]
000075038bdcfa54  mov eax, [rsp+0x10]
000075038bdcfa58  lea r12d, [r14d+eax*1]
000075038bdcfa5d  mov rax, [rsp+0x30]
000075038bdcfa62  lea r14, [rax+0x40]
000075038bdcfa66  mov [r13+r14*1], r12d
000075038bdcfa6b  mov eax, [rsp+0x20]
000075038bdcfa6f  mov eax, eax
000075038bdcfa71  mov [r15+0x60], rax
000075038bdcfa75  mov eax, [r15+0x108]
000075038bdcfa7c  sahf
000075038bdcfa7d  jnz 0x000075038BDCFAAF
000075038bdcfa7f  cmp dword ptr [r15+0x318], 0x00
000075038bdcfa87  jz 0x000075038BDCFF70
000075038bdcfa8d  nop [rax+rax*1], ax
000075038bdcfa96  nop [rax+rax*1], eax
000075038bdcfa9e  mov eax, 0x41088C
000075038bdcfaa3  mov [r15+0x100], rax
000075038bdcfaaa  jmp 0x000075038BBFE110
000075038bdcfaaf  cmp dword ptr [r15+0x318], 0x00
000075038bdcfab7  jz 0x000075038BDCFDC0
000075038bdcfabd  nop [rax+rax*1], ax
000075038bdcfac6  nop [rax+rax*1], eax
000075038bdcface  mov eax, 0x410844
000075038bdcfad3  mov [r15+0x100], rax
000075038bdcfada  jmp 0x000075038BBFE110
000075038bdcfadf  int3
000075038bdcfae0  call 0x000075038BC0D860
000075038bdcfae5  jmp 0x000075038BDCF17A
000075038bdcfaea  call 0x000075038BCE2420
000075038bdcfaef  jmp 0x000075038BDCF193
000075038bdcfaf4  call 0x000075038BCE2420
000075038bdcfaf9  jmp 0x000075038BDCF1AC
000075038bdcfafe  call 0x000075038BCE2420
000075038bdcfb03  jmp 0x000075038BDCF1C5
000075038bdcfb08  call 0x000075038BCE2420
000075038bdcfb0d  jmp 0x000075038BDCF1DE
000075038bdcfb12  call 0x000075038BCE2420
000075038bdcfb17  jmp 0x000075038BDCF1EF
000075038bdcfb1c  call 0x000075038BCE2420
000075038bdcfb21  jmp 0x000075038BDCF200
000075038bdcfb26  call 0x000075038BCE2420
000075038bdcfb2b  jmp 0x000075038BDCF211
000075038bdcfb30  call 0x000075038BCE2420
000075038bdcfb35  jmp 0x000075038BDCF222
000075038bdcfb3a  call 0x000075038BCE2420
000075038bdcfb3f  jmp 0x000075038BDCF233
000075038bdcfb44  call 0x000075038BCE2420
000075038bdcfb49  jmp 0x000075038BDCF244
000075038bdcfb4e  call 0x000075038BCE2420
000075038bdcfb53  jmp 0x000075038BDCF255
000075038bdcfb58  call 0x000075038BCE2420
000075038bdcfb5d  jmp 0x000075038BDCF266
000075038bdcfb62  call 0x000075038BCE2420
000075038bdcfb67  jmp 0x000075038BDCF277
000075038bdcfb6c  call 0x000075038BCE2420
000075038bdcfb71  jmp 0x000075038BDCF288
000075038bdcfb76  call 0x000075038BCE2420
000075038bdcfb7b  jmp 0x000075038BDCF299
000075038bdcfb80  call 0x000075038BCE2420
000075038bdcfb85  jmp 0x000075038BDCF2AA
000075038bdcfb8a  call 0x000075038BCE2420
000075038bdcfb8f  jmp 0x000075038BDCF2BB
000075038bdcfb94  call 0x000075038BCE2420
000075038bdcfb99  jmp 0x000075038BDCF2CC
000075038bdcfb9e  call 0x000075038BCE2420
000075038bdcfba3  jmp 0x000075038BDCF2DD
000075038bdcfba8  call 0x000075038BCE2420
000075038bdcfbad  jmp 0x000075038BDCF2EE
000075038bdcfbb2  call 0x000075038BCE2420
000075038bdcfbb7  jmp 0x000075038BDCF2FF
000075038bdcfbbc  call 0x000075038BCE2420
000075038bdcfbc1  jmp 0x000075038BDCF310
000075038bdcfbc6  call 0x000075038BCE2420
000075038bdcfbcb  jmp 0x000075038BDCF321
000075038bdcfbd0  call 0x000075038BCE2420
000075038bdcfbd5  jmp 0x000075038BDCF332
000075038bdcfbda  call 0x000075038BCE2420
000075038bdcfbdf  jmp 0x000075038BDCF343
000075038bdcfbe4  call 0x000075038BCE2420
000075038bdcfbe9  jmp 0x000075038BDCF354
000075038bdcfbee  call 0x000075038BCE2420
000075038bdcfbf3  jmp 0x000075038BDCF365
000075038bdcfbf8  call 0x000075038BCE2420
000075038bdcfbfd  jmp 0x000075038BDCF376
000075038bdcfc02  call 0x000075038BCE2420
000075038bdcfc07  jmp 0x000075038BDCF387
000075038bdcfc0c  call 0x000075038BCE2420
000075038bdcfc11  jmp 0x000075038BDCF398
000075038bdcfc16  call 0x000075038BCE2420
000075038bdcfc1b  jmp 0x000075038BDCF3A9
000075038bdcfc20  call 0x000075038BCE2420
000075038bdcfc25  jmp 0x000075038BDCF3BA
000075038bdcfc2a  call 0x000075038BCE2420
000075038bdcfc2f  jmp 0x000075038BDCF3CB
000075038bdcfc34  call 0x000075038BCE2420
000075038bdcfc39  jmp 0x000075038BDCF3DC
000075038bdcfc3e  call 0x000075038BCE2420
000075038bdcfc43  jmp 0x000075038BDCF3ED
000075038bdcfc48  call 0x000075038BCE2420
000075038bdcfc4d  jmp 0x000075038BDCF3FE
000075038bdcfc52  call 0x000075038BCE2420
000075038bdcfc57  jmp 0x000075038BDCF40F
000075038bdcfc5c  call 0x000075038BCE2420
000075038bdcfc61  jmp 0x000075038BDCF420
000075038bdcfc66  call 0x000075038BCE2420
000075038bdcfc6b  jmp 0x000075038BDCF431
000075038bdcfc70  call 0x000075038BCE2420
000075038bdcfc75  jmp 0x000075038BDCF442
000075038bdcfc7a  call 0x000075038BCE2420
000075038bdcfc7f  jmp 0x000075038BDCF453
000075038bdcfc84  call 0x000075038BCE2420
000075038bdcfc89  jmp 0x000075038BDCF464
000075038bdcfc8e  call 0x000075038BCE2420
000075038bdcfc93  jmp 0x000075038BDCF475
000075038bdcfc98  call 0x000075038BCE2420
000075038bdcfc9d  jmp 0x000075038BDCF486
000075038bdcfca2  call 0x000075038BCE2420
000075038bdcfca7  jmp 0x000075038BDCF497
000075038bdcfcac  call 0x000075038BCE2420
000075038bdcfcb1  jmp 0x000075038BDCF4A8
000075038bdcfcb6  call 0x000075038BCE2420
000075038bdcfcbb  jmp 0x000075038BDCF4B9
000075038bdcfcc0  call 0x000075038BCE2420
000075038bdcfcc5  jmp 0x000075038BDCF4CA
000075038bdcfcca  call 0x000075038BCE2420
000075038bdcfccf  jmp 0x000075038BDCF4DB
000075038bdcfcd4  call 0x000075038BCE2420
000075038bdcfcd9  jmp 0x000075038BDCF4EC
000075038bdcfcde  call 0x000075038BCE2420
000075038bdcfce3  jmp 0x000075038BDCF4FD
000075038bdcfce8  call 0x000075038BCE2420
000075038bdcfced  jmp 0x000075038BDCF50E
000075038bdcfcf2  call 0x000075038BCE2420
000075038bdcfcf7  jmp 0x000075038BDCF51F
000075038bdcfcfc  call 0x000075038BCE2420
000075038bdcfd01  jmp 0x000075038BDCF530
000075038bdcfd06  call 0x000075038BCE2420
000075038bdcfd0b  jmp 0x000075038BDCF541
000075038bdcfd10  call 0x000075038BCE2420
000075038bdcfd15  jmp 0x000075038BDCF552
000075038bdcfd1a  call 0x000075038BCE2420
000075038bdcfd1f  jmp 0x000075038BDCF563
000075038bdcfd24  call 0x000075038BCE2420
000075038bdcfd29  jmp 0x000075038BDCF574
000075038bdcfd2e  call 0x000075038BCE2420
000075038bdcfd33  jmp 0x000075038BDCF585
000075038bdcfd38  call 0x000075038BCE2420
000075038bdcfd3d  jmp 0x000075038BDCF596
000075038bdcfd42  call 0x000075038BCE2420
000075038bdcfd47  jmp 0x000075038BDCF5AF
000075038bdcfd4c  call 0x000075038BCE2420
000075038bdcfd51  jmp 0x000075038BDCF5C8
000075038bdcfd56  call 0x000075038BCD5610
000075038bdcfd5b  jmp 0x000075038BDCF5E1
000075038bdcfd60  call 0x000075038BCDC580
000075038bdcfd65  jmp 0x000075038BDCF94E
000075038bdcfd6a  call 0x000075038BCE46C0
000075038bdcfd6f  jmp 0x000075038BDCF958
000075038bdcfd74  call 0x000075038BC09E90
000075038bdcfd79  jmp 0x000075038BDCF95E
000075038bdcfd7e  call 0x000075038BCDB310
000075038bdcfd83  jmp 0x000075038BDCF968
000075038bdcfd88  call 0x000075038BC0DAE0
000075038bdcfd8d  jmp 0x000075038BDCF96D
000075038bdcfd92  call 0x000075038BCC0230
000075038bdcfd97  jmp 0x000075038BDCF986
000075038bdcfd9c  call 0x000075038BCC0230
000075038bdcfda1  jmp 0x000075038BDCF99B
000075038bdcfda6  call 0x000075038BCBEFC0
000075038bdcfdab  jmp 0x000075038BDCF9A4
000075038bdcfdb0  call 0x000075038BCE2BA0
000075038bdcfdb5  jmp 0x000075038BDCFA6B
000075038bdcfdba  int3
000075038bdcfdbb  nop [rax+rax*1], eax
000075038bdcfdc0  mov rax, [r15+0x48]
000075038bdcfdc4  mov r14, [r15+0x58]
000075038bdcfdc8  lea r12, [rax+r14*1]
000075038bdcfdcc  mov [r15+0x68], r12
000075038bdcfdd0  lea rax, [r14+0x04]
000075038bdcfdd4  mov [r15+0x58], rax
000075038bdcfdd8  lea r14, [r12+0x04]
000075038bdcfddd  mov r11d, [r13+r14*1]
000075038bdcfde2  mov [rsp+0x10], r11d
000075038bdcfde7  mov r11d, r11d
000075038bdcfdea  mov [r15+0x70], r11
000075038bdcfdee  lea r14, [r12+0x38]
000075038bdcfdf3  mov r11d, [r13+r14*1]
000075038bdcfdf8  lea r14, [r12+0x24]
000075038bdcfdfd  mov r10d, [r13+r14*1]
000075038bdcfe02  mov [rsp+0x20], r10d
000075038bdcfe07  mov r10d, r10d
000075038bdcfe0a  mov [r15+0x90], r10
000075038bdcfe11  mov [rsp+0x30], rax
000075038bdcfe16  xor eax, eax
000075038bdcfe18  mov r14, [rsp+0x30]
000075038bdcfe1d  mov r10d, 0xC0
000075038bdcfe23  cmp r14, r10
000075038bdcfe26  cmc
000075038bdcfe27  lahf
000075038bdcfe28  seto al
000075038bdcfe2b  mov [r15+0x108], eax
000075038bdcfe32  mov eax, [rsp+0x10]
000075038bdcfe36  mov r14d, [rsp+0x10]
000075038bdcfe3b  shrd eax, r14d, 0x07
000075038bdcfe40  mov [rsp+0x10], r11d
000075038bdcfe45  mov r10d, [rsp+0x10]
000075038bdcfe4a  shrd r11d, r10d, 0x11
000075038bdcfe4f  mov r9d, [r15+0x60]
000075038bdcfe53  mov r8d, [rsp+0x20]
000075038bdcfe58  lea ebp, [r8d+r9d*1]
000075038bdcfe5d  rorx r9d, r14d, 0x12
000075038bdcfe63  xor eax, r9d
000075038bdcfe66  rorx r9d, r10d, 0x13
000075038bdcfe6c  xor r11d, r9d
000075038bdcfe6f  mov [rsp+0x10], r11d
000075038bdcfe74  mov r11d, r11d
000075038bdcfe77  mov [r15+0x88], r11
000075038bdcfe7e  mov [rsp+0x20], r14d
000075038bdcfe83  shr r14d, 0x03
000075038bdcfe87  xor eax, r14d
000075038bdcfe8a  mov [rsp+0x30], eax
000075038bdcfe8e  mov eax, eax
000075038bdcfe90  mov [r15+0x80], rax
000075038bdcfe97  shr r10d, 0x0A
000075038bdcfe9b  mov eax, [rsp+0x10]
000075038bdcfe9f  xor eax, r10d
000075038bdcfea2  mov [rsp+0x10], eax
000075038bdcfea6  mov eax, eax
000075038bdcfea8  mov [r15+0x78], rax
000075038bdcfeac  mov eax, [rsp+0x30]
000075038bdcfeb0  lea r14d, [ebp+eax*1]
000075038bdcfeb6  mov eax, [rsp+0x10]
000075038bdcfeba  lea r11d, [r14d+eax*1]
000075038bdcfebf  lea rax, [r12+0x40]
000075038bdcfec4  mov [r13+rax*1], r11d
000075038bdcfec9  mov eax, [rsp+0x20]
000075038bdcfecd  mov eax, eax
000075038bdcfecf  mov [r15+0x60], rax
000075038bdcfed3  mov eax, [r15+0x108]
000075038bdcfeda  sahf
000075038bdcfedb  jnz 0x000075038BDCFF0D
000075038bdcfedd  cmp dword ptr [r15+0x318], 0x00
000075038bdcfee5  jz 0x000075038BDCFF70
000075038bdcfeeb  nop [rax+rax*1], ax
000075038bdcfef4  nop [rax+rax*1], eax
000075038bdcfefc  mov eax, 0x41088C
000075038bdcff01  mov [r15+0x100], rax
000075038bdcff08  jmp 0x000075038BBFE110
000075038bdcff0d  cmp dword ptr [r15+0x318], 0x00
000075038bdcff15  jz 0x000075038BDCFDC0
000075038bdcff1b  nop [rax+rax*1], ax
000075038bdcff24  nop [rax+rax*1], eax
000075038bdcff2c  mov eax, 0x410844
000075038bdcff31  mov [r15+0x100], rax
000075038bdcff38  jmp 0x000075038BBFE110
000075038bdcff3d  int3
000075038bdcff3e  call 0x000075038BCE1430
000075038bdcff43  jmp 0x000075038BDCFDE2
000075038bdcff48  call 0x000075038BCE1430
000075038bdcff4d  jmp 0x000075038BDCFDF8
000075038bdcff52  call 0x000075038BCE01C0
000075038bdcff57  jmp 0x000075038BDCFE02
000075038bdcff5c  call 0x000075038BC0A860
000075038bdcff61  jmp 0x000075038BDCFEC9
000075038bdcff66  int3
000075038bdcff67  nop [rax+rax*1], ax
000075038bdcff70  mov rax, [r15]
000075038bdcff73  mov r14d, [r13+rax*1]
000075038bdcff78  lea r12, [rax+0x04]
000075038bdcff7c  mov r11d, [r13+r12*1]
000075038bdcff81  mov [rsp+0x10], r14d
000075038bdcff86  mov r14d, r14d
000075038bdcff89  mov [r15+0x78], r14
000075038bdcff8d  mov [rsp+0x20], r11d
000075038bdcff92  mov r11d, r11d
000075038bdcff95  mov [r15+0x80], r11
000075038bdcff9c  lea r14, [rax+0x08]
000075038bdcffa0  mov r12d, [r13+r14*1]
000075038bdcffa5  lea r14, [rax+0x0C]
000075038bdcffa9  mov r11d, [r13+r14*1]
000075038bdcffae  mov [rsp+0x30], r12d
000075038bdcffb3  mov r12d, r12d
000075038bdcffb6  mov [r15+0x70], r12
000075038bdcffba  mov [rsp+0x40], r11d
000075038bdcffbf  mov r11d, r11d
000075038bdcffc2  mov [r15+0x68], r11
000075038bdcffc6  lea r14, [rax+0x18]
000075038bdcffca  mov r12d, [r13+r14*1]
000075038bdcffcf  lea r14, [rax+0x1C]
000075038bdcffd3  mov r11d, [r13+r14*1]
000075038bdcffd8  mov [rsp+0x50], r12d
000075038bdcffdd  mov r12d, r12d
000075038bdcffe0  mov [r15+0x58], r12
000075038bdcffe4  mov [rsp+0x60], r11d
000075038bdcffe9  mov r11d, r11d
000075038bdcffec  mov [r15+0x60], r11
000075038bdcfff0  lea r14, [rax+0x10]
000075038bdcfff4  mov r12d, [r13+r14*1]
000075038bdcfff9  lea r14, [rax+0x14]
000075038bdcfffd  mov eax, [r13+r14*1]
000075038bdd0002  mov [rsp+0x70], r12d
000075038bdd0007  mov r12d, r12d
000075038bdd000a  mov [r15+0x18], r12
000075038bdd000e  mov [rsp+0x80], eax
000075038bdd0015  mov eax, eax
000075038bdd0017  mov [r15+0x90], rax
000075038bdd001e  mov eax, [rsp+0x70]
000075038bdd0022  mov eax, eax
000075038bdd0024  mov [r15+0x30], rax
000075038bdd0028  mov eax, [rsp+0x50]
000075038bdd002c  mov eax, eax
000075038bdd002e  mov [r15+0xA0], rax
000075038bdd0035  mov eax, [rsp+0x30]
000075038bdd0039  mov eax, eax
000075038bdd003b  mov [r15+0x28], rax
000075038bdd003f  mov eax, [rsp+0x20]
000075038bdd0043  mov eax, eax
000075038bdd0045  mov [r15+0x98], rax
000075038bdd004c  mov eax, [rsp+0x10]
000075038bdd0050  mov eax, eax
000075038bdd0052  mov [r15+0x38], rax
000075038bdd0056  mov eax, [rsp+0x70]
000075038bdd005a  mov r14d, [rsp+0x70]
000075038bdd005f  shrd eax, r14d, 0x06
000075038bdd0064  mov [rsp+0x70], r14d
000075038bdd0069  mov r12d, [rsp+0x80]
000075038bdd0071  and r14d, r12d
000075038bdd0074  mov r11d, [rsp+0x10]
000075038bdd0079  mov r10d, [rsp+0x10]
000075038bdd007e  shrd r11d, r10d, 0x02
000075038bdd0083  mov [rsp+0x10], r12d
000075038bdd0088  mov r12d, r12d
000075038bdd008b  mov [r15+0x20], r12
000075038bdd008f  mov r12, [r15+0x50]
000075038bdd0093  mov r9d, [r13+r12*1]
000075038bdd0098  mov r12d, [rsp+0x50]
000075038bdd009d  mov r8d, [rsp+0x70]
000075038bdd00a2  andn ebp, r8d, r12d
000075038bdd00a7  mov edi, [rsp+0x60]
000075038bdd00ab  lea esi, [r14d+edi*1]
000075038bdd00b0  rorx r14d, r8d, 0x0B
000075038bdd00b6  xor eax, r14d
000075038bdd00b9  rorx r14d, r10d, 0x0D
000075038bdd00bf  xor r11d, r14d
000075038bdd00c2  lea edi, [esi+ebp*1]
000075038bdd00c6  mov r14, [r15+0x48]
000075038bdd00ca  mov ebp, [r13+r14*1]
000075038bdd00cf  mov r14d, [rsp+0x30]
000075038bdd00d4  mov esi, [rsp+0x20]
000075038bdd00d8  and r14d, esi
000075038bdd00db  mov [rsp+0x20], r14d
000075038bdd00e0  mov r14d, r14d
000075038bdd00e3  mov [r15+0xD8], r14
000075038bdd00ea  lea r14d, [edi+r9d*1]
000075038bdd00ef  mov r9d, [rsp+0x30]
000075038bdd00f4  xor r9d, esi
000075038bdd00f7  rorx edi, r8d, 0x19
000075038bdd00fd  xor eax, edi
000075038bdd00ff  and r9d, r10d
000075038bdd0102  rorx edi, r10d, 0x16
000075038bdd0108  xor r11d, edi
000075038bdd010b  mov [rsp+0x30], r11d
000075038bdd0110  mov r11d, r11d
000075038bdd0113  mov [r15+0xD0], r11
000075038bdd011a  lea r11d, [r14d+ebp*1]
000075038bdd011f  mov r10d, [rsp+0x20]
000075038bdd0124  xor r9d, r10d
000075038bdd0127  lea r14d, [r11d+eax*1]
000075038bdd012c  mov qword ptr [r15+0x88], 0x04
000075038bdd0137  mov eax, [rsp+0x30]
000075038bdd013b  lea r11d, [r9d+eax*1]
000075038bdd0140  mov eax, [rsp+0x40]
000075038bdd0144  lea r10d, [r14d+eax*1]
000075038bdd0149  mov r10d, r10d
000075038bdd014c  mov [r15+0xB8], r10
000075038bdd0153  xor eax, eax
000075038bdd0155  mov r10d, 0x04
000075038bdd015b  mov r9d, 0x100
000075038bdd0161  cmp r10, r9
000075038bdd0164  cmc
000075038bdd0165  lahf
000075038bdd0166  seto al
000075038bdd0169  mov [r15+0x108], eax
000075038bdd0170  lea eax, [r11d+r14d*1]
000075038bdd0175  mov eax, eax
000075038bdd0177  mov [r15+0xA8], rax
000075038bdd017e  mov r12d, r12d
000075038bdd0181  mov [r15+0xB0], r12
000075038bdd0188  mov eax, [rsp+0x10]
000075038bdd018c  mov eax, eax
000075038bdd018e  mov [r15+0xC0], rax
000075038bdd0195  mov r8d, r8d
000075038bdd0198  mov [r15+0xC8], r8
000075038bdd019f  mov eax, [r15+0x108]
000075038bdd01a6  sahf
000075038bdd01a7  jnz 0x000075038BDD01D9
000075038bdd01a9  cmp dword ptr [r15+0x318], 0x00
000075038bdd01b1  jz 0x000075038BDD04A0
000075038bdd01b7  nop [rax+rax*1], ax
000075038bdd01c0  nop [rax+rax*1], eax
000075038bdd01c8  mov eax, 0x41094C
000075038bdd01cd  mov [r15+0x100], rax
000075038bdd01d4  jmp 0x000075038BBFE110
000075038bdd01d9  cmp dword ptr [r15+0x318], 0x00
000075038bdd01e1  jz 0x000075038BDD0270
000075038bdd01e7  nop [rax+rax*1], ax
000075038bdd01f0  nop [rax+rax*1], eax
000075038bdd01f8  mov eax, 0x4108C0
000075038bdd01fd  mov [r15+0x100], rax
000075038bdd0204  jmp 0x000075038BBFE110
000075038bdd0209  int3
000075038bdd020a  call 0x000075038BC0DAE0
000075038bdd020f  jmp 0x000075038BDCFF78
000075038bdd0214  call 0x000075038BCC0230
000075038bdd0219  jmp 0x000075038BDCFF81
000075038bdd021e  call 0x000075038BCE26A0
000075038bdd0223  jmp 0x000075038BDCFFA5
000075038bdd0228  call 0x000075038BCE1430
000075038bdd022d  jmp 0x000075038BDCFFAE
000075038bdd0232  call 0x000075038BCE26A0
000075038bdd0237  jmp 0x000075038BDCFFCF
000075038bdd023c  call 0x000075038BCE1430
000075038bdd0241  jmp 0x000075038BDCFFD8
000075038bdd0246  call 0x000075038BCE26A0
000075038bdd024b  jmp 0x000075038BDCFFF9
000075038bdd0250  call 0x000075038BCD5890
000075038bdd0255  jmp 0x000075038BDD0002
000075038bdd025a  call 0x000075038BCBDD50
000075038bdd025f  jmp 0x000075038BDD0098
000075038bdd0264  call 0x000075038BCDA580
000075038bdd0269  jmp 0x000075038BDD00CF
000075038bdd026e  int3
000075038bdd026f  nop
000075038bdd0270  mov eax, [r15+0xB8]
000075038bdd0277  mov [rsp+0x10], eax
000075038bdd027b  mov eax, eax
000075038bdd027d  mov [r15+0x30], rax
000075038bdd0281  mov eax, [r15+0xC0]
000075038bdd0288  mov [rsp+0x20], eax
000075038bdd028c  mov eax, eax
000075038bdd028e  mov [r15+0xA0], rax
000075038bdd0295  mov eax, [r15+0x28]
000075038bdd0299  mov r14d, [r15+0x98]
000075038bdd02a0  mov [rsp+0x30], r14d
000075038bdd02a5  mov r14d, r14d
000075038bdd02a8  mov [r15+0x28], r14
000075038bdd02ac  mov r14d, [r15+0x38]
000075038bdd02b0  mov [rsp+0x40], r14d
000075038bdd02b5  mov r14d, r14d
000075038bdd02b8  mov [r15+0x98], r14
000075038bdd02bf  mov r14d, [r15+0xA8]
000075038bdd02c6  mov [rsp+0x50], r14d
000075038bdd02cb  mov r14d, r14d
000075038bdd02ce  mov [r15+0x38], r14
000075038bdd02d2  mov r14d, [rsp+0x10]
000075038bdd02d7  mov r12d, [rsp+0x10]
000075038bdd02dc  shrd r14d, r12d, 0x06
000075038bdd02e1  mov r11d, [r15+0xC8]
000075038bdd02e8  mov [rsp+0x10], r12d
000075038bdd02ed  and r12d, r11d
000075038bdd02f0  mov r10d, [rsp+0x50]
000075038bdd02f5  mov r9d, [rsp+0x50]
000075038bdd02fa  shrd r10d, r9d, 0x02
000075038bdd02ff  mov [rsp+0x50], r11d
000075038bdd0304  mov r11d, r11d
000075038bdd0307  mov [r15+0x20], r11
000075038bdd030b  mov r11, [r15+0x88]
000075038bdd0312  mov r8, [r15+0x50]
000075038bdd0316  lea rbp, [r8+r11*1]
000075038bdd031a  mov r8d, [r13+rbp*1]
000075038bdd031f  mov ebp, [rsp+0x20]
000075038bdd0323  mov edi, [rsp+0x10]
000075038bdd0327  andn esi, edi, ebp
000075038bdd032c  mov edx, [r15+0xB0]
000075038bdd0333  lea ecx, [r12d+edx*1]
000075038bdd0338  rorx r12d, edi, 0x0B
000075038bdd033e  xor r14d, r12d
000075038bdd0341  rorx r12d, r9d, 0x0D
000075038bdd0347  xor r10d, r12d
000075038bdd034a  lea r12d, [ecx+esi*1]
000075038bdd034f  mov rsi, [r15+0x48]
000075038bdd0353  lea rdx, [rsi+r11*1]
000075038bdd0357  mov esi, [r13+rdx*1]
000075038bdd035c  mov edx, [rsp+0x30]
000075038bdd0360  mov ecx, [rsp+0x40]
000075038bdd0364  and edx, ecx
000075038bdd0366  mov [rsp+0x10], edx
000075038bdd036a  mov edx, edx
000075038bdd036c  mov [r15+0xD8], rdx
000075038bdd0373  lea edx, [r12d+r8d*1]
000075038bdd0378  mov r12d, [rsp+0x30]
000075038bdd037d  xor r12d, ecx
000075038bdd0380  rorx r8d, edi, 0x19
000075038bdd0386  xor r14d, r8d
000075038bdd0389  and r12d, r9d
000075038bdd038c  rorx r8d, r9d, 0x16
000075038bdd0392  xor r10d, r8d
000075038bdd0395  mov [rsp+0x20], r10d
000075038bdd039a  mov r10d, r10d
000075038bdd039d  mov [r15+0xD0], r10
000075038bdd03a4  lea r10d, [edx+esi*1]
000075038bdd03a9  mov r9d, [rsp+0x10]
000075038bdd03ae  xor r12d, r9d
000075038bdd03b1  lea r9d, [r10d+r14d*1]
000075038bdd03b6  lea r14, [r11+0x04]
000075038bdd03ba  mov [r15+0x88], r14
000075038bdd03c1  mov r11d, [rsp+0x20]
000075038bdd03c6  lea r10d, [r12d+r11d*1]
000075038bdd03cb  lea r11d, [r9d+eax*1]
000075038bdd03d0  mov r11d, r11d
000075038bdd03d3  mov [r15+0xB8], r11
000075038bdd03da  xor eax, eax
000075038bdd03dc  mov r12d, 0x100
000075038bdd03e2  cmp r14, r12
000075038bdd03e5  cmc
000075038bdd03e6  lahf
000075038bdd03e7  seto al
000075038bdd03ea  mov [r15+0x108], eax
000075038bdd03f1  lea eax, [r10d+r9d*1]
000075038bdd03f6  mov eax, eax
000075038bdd03f8  mov [r15+0xA8], rax
000075038bdd03ff  mov ebp, ebp
000075038bdd0401  mov [r15+0xB0], rbp
000075038bdd0408  mov eax, [rsp+0x50]
000075038bdd040c  mov eax, eax
000075038bdd040e  mov [r15+0xC0], rax
000075038bdd0415  mov edi, edi
000075038bdd0417  mov [r15+0xC8], rdi
000075038bdd041e  mov eax, [r15+0x108]
000075038bdd0425  sahf
000075038bdd0426  jnz 0x000075038BDD0458
000075038bdd0428  cmp dword ptr [r15+0x318], 0x00
000075038bdd0430  jz 0x000075038BDD04A0
000075038bdd0436  nop [rax+rax*1], ax
000075038bdd043f  nop [rax+rax*1], eax
000075038bdd0447  mov eax, 0x41094C
000075038bdd044c  mov [r15+0x100], rax
000075038bdd0453  jmp 0x000075038BBFE110
000075038bdd0458  cmp dword ptr [r15+0x318], 0x00
000075038bdd0460  jz 0x000075038BDD0270
000075038bdd0466  nop [rax+rax*1], ax
000075038bdd046f  nop [rax+rax*1], eax
000075038bdd0477  mov eax, 0x4108C0
000075038bdd047c  mov [r15+0x100], rax
000075038bdd0483  jmp 0x000075038BBFE110
000075038bdd0488  int3
000075038bdd0489  call 0x000075038BC49010
000075038bdd048e  jmp 0x000075038BDD031F
000075038bdd0493  call 0x000075038BC25930
000075038bdd0498  jmp 0x000075038BDD035C
000075038bdd049d  int3
000075038bdd049e  nop
000075038bdd04a0  mov eax, [r15+0x98]
000075038bdd04a7  mov r14d, [r15+0x70]
000075038bdd04ab  lea r12d, [eax+r14d*1]
000075038bdd04b0  mov eax, [r15+0x28]
000075038bdd04b4  mov r14d, [r15+0x68]
000075038bdd04b8  lea r11d, [eax+r14d*1]
000075038bdd04bd  mov qword ptr [r15+0x88], 0x00
000075038bdd04c8  mov eax, [r15+0xA8]
000075038bdd04cf  mov r14d, [r15+0x78]
000075038bdd04d3  lea r10d, [eax+r14d*1]
000075038bdd04d8  mov [rsp+0x10], r10d
000075038bdd04dd  mov r10d, r10d
000075038bdd04e0  mov [r15+0x78], r10
000075038bdd04e4  mov eax, [r15+0x38]
000075038bdd04e8  mov r14d, [r15+0x80]
000075038bdd04ef  lea r10d, [eax+r14d*1]
000075038bdd04f4  mov [rsp+0x20], r10d
000075038bdd04f9  mov r10d, r10d
000075038bdd04fc  mov [r15+0x80], r10
000075038bdd0503  mov rax, [r15]
000075038bdd0506  lea r14, [rax+0x08]
000075038bdd050a  mov [r13+r14*1], r12d
000075038bdd050f  lea r14, [rax+0x0C]
000075038bdd0513  mov [r13+r14*1], r11d
000075038bdd0518  mov r14d, [r15+0xB8]
000075038bdd051f  mov r12d, [r15+0x18]
000075038bdd0523  lea r11d, [r14d+r12d*1]
000075038bdd0528  mov [rsp+0x30], r11d
000075038bdd052d  mov r11d, r11d
000075038bdd0530  mov [r15+0x68], r11
000075038bdd0534  mov r14d, [r15+0x30]
000075038bdd0538  mov r12d, [r15+0x90]
000075038bdd053f  lea r11d, [r14d+r12d*1]
000075038bdd0544  mov [rsp+0x40], r11d
000075038bdd0549  mov r11d, r11d
000075038bdd054c  mov [r15+0x70], r11
000075038bdd0550  mov r14d, [r15+0x20]
000075038bdd0554  mov r12d, [r15+0x58]
000075038bdd0558  lea r11d, [r14d+r12d*1]
000075038bdd055d  mov [rsp+0x50], r11d
000075038bdd0562  mov r11d, r11d
000075038bdd0565  mov [r15+0x58], r11
000075038bdd0569  mov r14d, [r15+0xA0]
000075038bdd0570  mov r12d, [r15+0x60]
000075038bdd0574  lea r11d, [r14d+r12d*1]
000075038bdd0579  mov [rsp+0x60], r11d
000075038bdd057e  mov r11d, r11d
000075038bdd0581  mov [r15+0x60], r11
000075038bdd0585  mov r14d, [rsp+0x10]
000075038bdd058a  mov [r13+rax*1], r14d
000075038bdd058f  lea r14, [rax+0x04]
000075038bdd0593  mov r12d, [rsp+0x20]
000075038bdd0598  mov [r13+r14*1], r12d
000075038bdd059d  lea r14, [rax+0x10]
000075038bdd05a1  mov r12d, [rsp+0x30]
000075038bdd05a6  mov [r13+r14*1], r12d
000075038bdd05ab  lea r14, [rax+0x14]
000075038bdd05af  mov r12d, [rsp+0x40]
000075038bdd05b4  mov [r13+r14*1], r12d
000075038bdd05b9  lea r14, [rax+0x18]
000075038bdd05bd  mov r12d, [rsp+0x50]
000075038bdd05c2  mov [r13+r14*1], r12d
000075038bdd05c7  lea r14, [rax+0x1C]
000075038bdd05cb  mov r12d, [rsp+0x60]
000075038bdd05d0  mov [r13+r14*1], r12d
000075038bdd05d5  lea r14, [rax+0x68]
000075038bdd05d9  xor eax, eax
000075038bdd05db  mov [r13+r14*1], rax
000075038bdd05e0  cmp dword ptr [r15+0x318], 0x00
000075038bdd05e8  jz 0x000075038BDCF0E0
000075038bdd05ee  nop [rax+rax*1], ax
000075038bdd05f7  nop [rax+rax*1], eax
000075038bdd05ff  mov eax, 0x410768
000075038bdd0604  mov [r15+0x100], rax
000075038bdd060b  jmp 0x000075038BBFE110
000075038bdd0610  int3
000075038bdd0611  call 0x000075038BCE2BA0
000075038bdd0616  jmp 0x000075038BDD050F
000075038bdd061b  call 0x000075038BCE1920
000075038bdd0620  jmp 0x000075038BDD0518
000075038bdd0625  call 0x000075038BC0DFE0
000075038bdd062a  jmp 0x000075038BDD058F
000075038bdd062f  call 0x000075038BCE2BA0
000075038bdd0634  jmp 0x000075038BDD059D
000075038bdd0639  call 0x000075038BCE2BA0
000075038bdd063e  jmp 0x000075038BDD05AB
000075038bdd0643  call 0x000075038BCE2BA0
000075038bdd0648  jmp 0x000075038BDD05B9
000075038bdd064d  call 0x000075038BCE2BA0
000075038bdd0652  jmp 0x000075038BDD05C7
000075038bdd0657  call 0x000075038BCE2BA0
000075038bdd065c  jmp 0x000075038BDD05D5
000075038bdd0661  call 0x000075038BCD5EB0
000075038bdd0666  jmp 0x000075038BDD05E0
000075038bdd066b  int3
000075038bdd066c  nop [rax], eax
000075038bdd0670  mov rax, [r15+0xF8]
000075038bdd0677  lea r14, [rax+0x140]
000075038bdd067e  mov r12, [r13+r14*1]
000075038bdd0683  lea r14, [rax+0x148]
000075038bdd068a  mov r11, [r13+r14*1]
000075038bdd068f  mov [r15+0xA0], r12
000075038bdd0696  mov [r15+0x98], r11
000075038bdd069d  lea r14, [rax+0x130]
000075038bdd06a4  mov r12, [r13+r14*1]
000075038bdd06a9  lea r14, [rax+0x138]
000075038bdd06b0  mov r11, [r13+r14*1]
000075038bdd06b5  mov [r15+0xB0], r12
000075038bdd06bc  mov [r15+0xA8], r11
000075038bdd06c3  lea r14, [rax+0x120]
000075038bdd06ca  mov r12, [r13+r14*1]
000075038bdd06cf  lea r14, [rax+0x128]
000075038bdd06d6  mov r11, [r13+r14*1]
000075038bdd06db  mov [r15+0xC0], r12
000075038bdd06e2  mov [r15+0xB8], r11
000075038bdd06e9  lea r14, [rax+0x110]
000075038bdd06f0  mov r12, [r13+r14*1]
000075038bdd06f5  lea r14, [rax+0x118]
000075038bdd06fc  mov r11, [r13+r14*1]
000075038bdd0701  mov [r15+0xD0], r12
000075038bdd0708  mov [r15+0xC8], r11
000075038bdd070f  lea r14, [rax+0x100]
000075038bdd0716  mov r12, [r13+r14*1]
000075038bdd071b  lea r14, [rax+0x108]
000075038bdd0722  mov r11, [r13+r14*1]
000075038bdd0727  mov [r15+0xE8], r12
000075038bdd072e  mov [r15+0xD8], r11
000075038bdd0735  lea r14, [rax+0x150]
000075038bdd073c  mov [r15+0xF8], r14
000075038bdd0743  mov rax, [r15+0xF0]
000075038bdd074a  mov [r15+0x100], rax
000075038bdd0751  jmp 0x000075038BDCE5C0
000075038bdd0756  int3
000075038bdd0757  call 0x000075038BCE27E0
000075038bdd075c  jmp 0x000075038BDD0683
000075038bdd0761  call 0x000075038BCE1570
000075038bdd0766  jmp 0x000075038BDD068F
000075038bdd076b  call 0x000075038BCE27E0
000075038bdd0770  jmp 0x000075038BDD06A9
000075038bdd0775  call 0x000075038BCE1570
000075038bdd077a  jmp 0x000075038BDD06B5
000075038bdd077f  call 0x000075038BCE27E0
000075038bdd0784  jmp 0x000075038BDD06CF
000075038bdd0789  call 0x000075038BCE1570
000075038bdd078e  jmp 0x000075038BDD06DB
000075038bdd0793  call 0x000075038BCE27E0
000075038bdd0798  jmp 0x000075038BDD06F5
000075038bdd079d  call 0x000075038BCE1570
000075038bdd07a2  jmp 0x000075038BDD0701
000075038bdd07a7  call 0x000075038BCE27E0
000075038bdd07ac  jmp 0x000075038BDD071B
000075038bdd07b1  call 0x000075038BCE1570
000075038bdd07b6  jmp 0x000075038BDD0727
000075038bdd07bb  int3
000075038bdd07bc  nop [rax], eax
000075038bdd07c0  mov eax, [r15+0xA0]
000075038bdd07c7  mov [rsp+0x10], eax
000075038bdd07cb  xor eax, eax
000075038bdd07cd  mov r14d, [rsp+0x10]
000075038bdd07d2  sub r14d, 0x01
000075038bdd07d6  cmc
000075038bdd07d7  lahf
000075038bdd07d8  seto al
000075038bdd07db  mov [r15+0x108], eax
000075038bdd07e2  mov r14d, r14d
000075038bdd07e5  mov [r15+0xA0], r14
000075038bdd07ec  mov eax, [r15+0x108]
000075038bdd07f3  sahf
000075038bdd07f4  jnz 0x000075038BDD0826
000075038bdd07f6  cmp dword ptr [r15+0x318], 0x00
000075038bdd07fe  jz 0x000075038BDD0900
000075038bdd0804  nop [rax+rax*1], ax
000075038bdd080d  nop [rax+rax*1], eax
000075038bdd0815  mov eax, 0x41028C
000075038bdd081a  mov [r15+0x100], rax
000075038bdd0821  jmp 0x000075038BBFE110
000075038bdd0826  cmp dword ptr [r15+0x318], 0x00
000075038bdd082e  jz 0x000075038BDD0860
000075038bdd0834  nop [rax+rax*1], ax
000075038bdd083d  nop [rax+rax*1], eax
000075038bdd0845  mov eax, 0x410274
000075038bdd084a  mov [r15+0x100], rax
000075038bdd0851  jmp 0x000075038BBFE110
000075038bdd0856  int3
000075038bdd0857  int3
000075038bdd0858  nop [rax+rax*1], eax
000075038bdd0860  mov rax, [r15+0xF8]
000075038bdd0867  lea r14, [rax+0x100]
000075038bdd086e  mov [r15], r14
000075038bdd0871  mov rax, [r15+0x98]
000075038bdd0878  mov [r15+0x08], rax
000075038bdd087c  mov qword ptr [r15+0x10], 0x12C
000075038bdd0884  mov qword ptr [r15+0xF0], 0x410284
000075038bdd088f  mov r14d, [r15+0x320]
000075038bdd0896  mov eax, 0x410284
000075038bdd089b  mov rcx, 0x75038BDD07C0
000075038bdd08a5  mov [r15+r14*8+0x328], rax
000075038bdd08ad  mov [r15+r14*8+0x368], rcx
000075038bdd08b5  add r14d, 0x01
000075038bdd08b9  and r14d, 0x07
000075038bdd08bd  mov [r15+0x320], r14d
000075038bdd08c4  cmp dword ptr [r15+0x318], 0x00
000075038bdd08cc  jz 0x000075038BDCED70
000075038bdd08d2  nop [rax+rax*1], ax
000075038bdd08db  nop [rax+rax*1], eax
000075038bdd08e3  mov eax, 0x410728
000075038bdd08e8  mov [r15+0x100], rax
000075038bdd08ef  jmp 0x000075038BBFE110
000075038bdd08f4  int3
000075038bdd08f5  int3
000075038bdd08f6  nop [rax+rax*1], ax
000075038bdd08ff  nop
000075038bdd0900  mov rax, [r15+0xF8]
000075038bdd0907  lea r14, [rax+0x120]
000075038bdd090e  mov r12, [r13+r14*1]
000075038bdd0913  mov [r15+0x98], r12
000075038bdd091a  mov qword ptr [r15+0x40], 0x80
000075038bdd0922  lea r14, [rax+0x100]
000075038bdd0929  mov [r15], r14
000075038bdd092c  lea r14, [rax+0x17C]
000075038bdd0933  mov [r15+0x08], r14
000075038bdd0937  mov qword ptr [r15+0x10], 0x01
000075038bdd093f  lea r14, [rax+0x17C]
000075038bdd0946  mov eax, 0x80
000075038bdd094b  mov [r13+r14*1], al
000075038bdd0950  mov qword ptr [r15+0xF0], 0x4102A8
000075038bdd095b  mov r14d, [r15+0x320]
000075038bdd0962  mov eax, 0x4102A8
000075038bdd0967  mov rcx, 0x75038BDD09E0
000075038bdd0971  mov [r15+r14*8+0x328], rax
000075038bdd0979  mov [r15+r14*8+0x368], rcx
000075038bdd0981  add r14d, 0x01
000075038bdd0985  and r14d, 0x07
000075038bdd0989  mov [r15+0x320], r14d
000075038bdd0990  cmp dword ptr [r15+0x318], 0x00
000075038bdd0998  jz 0x000075038BDCED70
000075038bdd099e  nop [rax+rax*1], ax
000075038bdd09a7  nop [rax+rax*1], eax
000075038bdd09af  mov eax, 0x410728
000075038bdd09b4  mov [r15+0x100], rax
000075038bdd09bb  jmp 0x000075038BBFE110
000075038bdd09c0  int3
000075038bdd09c1  call 0x000075038BCE27E0
000075038bdd09c6  jmp 0x000075038BDD0913
000075038bdd09cb  call 0x000075038BCD5AF0
000075038bdd09d0  jmp 0x000075038BDD0950
000075038bdd09d5  int3
000075038bdd09d6  nop [rax+rax*1], ax
000075038bdd09df  nop
000075038bdd09e0  mov rax, [r15+0xF8]
000075038bdd09e7  lea r14, [rax+0x168]
000075038bdd09ee  mov r12, [r13+r14*1]
000075038bdd09f3  mov [r15+0x40], r12
000075038bdd09f7  lea r14, [rax+0x178]
000075038bdd09fe  xor eax, eax
000075038bdd0a00  mov [r13+r14*1], al
000075038bdd0a05  xor eax, eax
000075038bdd0a07  mov r14d, 0x38
000075038bdd0a0d  cmp r12, r14
000075038bdd0a10  cmc
000075038bdd0a11  lahf
000075038bdd0a12  seto al
000075038bdd0a15  mov [r15+0x108], eax
000075038bdd0a1c  mov eax, [r15+0x108]
000075038bdd0a23  sahf
000075038bdd0a24  jz 0x000075038BDD0A56
000075038bdd0a26  cmp dword ptr [r15+0x318], 0x00
000075038bdd0a2e  jz 0x000075038BDD0AA0
000075038bdd0a34  nop [rax+rax*1], ax
000075038bdd0a3d  nop [rax+rax*1], eax
000075038bdd0a45  mov eax, 0x4102B8
000075038bdd0a4a  mov [r15+0x100], rax
000075038bdd0a51  jmp 0x000075038BBFE110
000075038bdd0a56  cmp dword ptr [r15+0x318], 0x00
000075038bdd0a5e  jz 0x000075038BDD0BF0
000075038bdd0a64  nop [rax+rax*1], ax
000075038bdd0a6d  nop [rax+rax*1], eax
000075038bdd0a75  mov eax, 0x4102D4
000075038bdd0a7a  mov [r15+0x100], rax
000075038bdd0a81  jmp 0x000075038BBFE110
000075038bdd0a86  int3
000075038bdd0a87  call 0x000075038BCE27E0
000075038bdd0a8c  jmp 0x000075038BDD09F3
000075038bdd0a91  call 0x000075038BCD5AF0
000075038bdd0a96  jmp 0x000075038BDD0A05
000075038bdd0a9b  int3
000075038bdd0a9c  nop [rax], eax
000075038bdd0aa0  mov rax, [r15+0xF8]
000075038bdd0aa7  lea r14, [rax+0x100]
000075038bdd0aae  mov [r15], r14
000075038bdd0ab1  lea r14, [rax+0x178]
000075038bdd0ab8  mov [r15+0x08], r14
000075038bdd0abc  mov qword ptr [r15+0x10], 0x01
000075038bdd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000075038bdd0acf  mov r14d, [r15+0x320]
000075038bdd0ad6  mov eax, 0x4102C8
000075038bdd0adb  mov rcx, 0x75038BDD0B40
000075038bdd0ae5  mov [r15+r14*8+0x328], rax
000075038bdd0aed  mov [r15+r14*8+0x368], rcx
000075038bdd0af5  add r14d, 0x01
000075038bdd0af9  and r14d, 0x07
000075038bdd0afd  mov [r15+0x320], r14d
000075038bdd0b04  cmp dword ptr [r15+0x318], 0x00
000075038bdd0b0c  jz 0x000075038BDCED70
000075038bdd0b12  nop [rax+rax*1], ax
000075038bdd0b1b  nop [rax+rax*1], eax
000075038bdd0b23  mov eax, 0x410728
000075038bdd0b28  mov [r15+0x100], rax
000075038bdd0b2f  jmp 0x000075038BBFE110
000075038bdd0b34  int3
000075038bdd0b35  int3
000075038bdd0b36  nop [rax+rax*1], ax
000075038bdd0b3f  nop
000075038bdd0b40  mov rax, [r15+0xF8]
000075038bdd0b47  lea r14, [rax+0x168]
000075038bdd0b4e  mov rax, [r13+r14*1]
000075038bdd0b53  mov [r15+0x40], rax
000075038bdd0b57  mov [rsp+0x10], rax
000075038bdd0b5c  xor eax, eax
000075038bdd0b5e  mov r14, [rsp+0x10]
000075038bdd0b63  mov r12d, 0x38
000075038bdd0b69  cmp r14, r12
000075038bdd0b6c  cmc
000075038bdd0b6d  lahf
000075038bdd0b6e  seto al
000075038bdd0b71  mov [r15+0x108], eax
000075038bdd0b78  mov eax, [r15+0x108]
000075038bdd0b7f  sahf
000075038bdd0b80  jnz 0x000075038BDD0BB2
000075038bdd0b82  cmp dword ptr [r15+0x318], 0x00
000075038bdd0b8a  jz 0x000075038BDD0BF0
000075038bdd0b90  nop [rax+rax*1], ax
000075038bdd0b99  nop [rax+rax*1], eax
000075038bdd0ba1  mov eax, 0x4102D4
000075038bdd0ba6  mov [r15+0x100], rax
000075038bdd0bad  jmp 0x000075038BBFE110
000075038bdd0bb2  cmp dword ptr [r15+0x318], 0x00
000075038bdd0bba  jz 0x000075038BDD0AA0
000075038bdd0bc0  nop [rax+rax*1], ax
000075038bdd0bc9  nop [rax+rax*1], eax
000075038bdd0bd1  mov eax, 0x4102B8
000075038bdd0bd6  mov [r15+0x100], rax
000075038bdd0bdd  jmp 0x000075038BBFE110
000075038bdd0be2  int3
000075038bdd0be3  call 0x000075038BCD59C0
000075038bdd0be8  jmp 0x000075038BDD0B53
000075038bdd0bed  int3
000075038bdd0bee  nop
000075038bdd0bf0  mov rax, [r15+0x98]
000075038bdd0bf7  rorx r14, rax, 0x3D
000075038bdd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000075038bdd0c01  mov rax, [r15+0xF8]
000075038bdd0c08  lea r12, [rax+0x100]
000075038bdd0c0f  mov [r15], r12
000075038bdd0c12  lea r12, [rax+0x170]
000075038bdd0c19  mov [r15+0x08], r12
000075038bdd0c1d  mov qword ptr [r15+0x10], 0x08
000075038bdd0c25  bswap r14
000075038bdd0c28  mov [r15+0x40], r14
000075038bdd0c2c  lea r12, [rax+0x170]
000075038bdd0c33  mov [r13+r12*1], r14
000075038bdd0c38  mov qword ptr [r15+0xF0], 0x4102F0
000075038bdd0c43  mov r14d, [r15+0x320]
000075038bdd0c4a  mov eax, 0x4102F0
000075038bdd0c4f  mov rcx, 0x75038BDD0CC0
000075038bdd0c59  mov [r15+r14*8+0x328], rax
000075038bdd0c61  mov [r15+r14*8+0x368], rcx
000075038bdd0c69  add r14d, 0x01
000075038bdd0c6d  and r14d, 0x07
000075038bdd0c71  mov [r15+0x320], r14d
000075038bdd0c78  cmp dword ptr [r15+0x318], 0x00
000075038bdd0c80  jz 0x000075038BDCED70
000075038bdd0c86  nop [rax+rax*1], ax
000075038bdd0c8f  nop [rax+rax*1], eax
000075038bdd0c97  mov eax, 0x410728
000075038bdd0c9c  mov [r15+0x100], rax
000075038bdd0ca3  jmp 0x000075038BBFE110
000075038bdd0ca8  int3
000075038bdd0ca9  call 0x000075038BCC3FE0
000075038bdd0cae  jmp 0x000075038BDD0C38
000075038bdd0cb3  int3
000075038bdd0cb4  nop [rax+rax*1], ax
000075038bdd0cbd  nop [rax], eax
000075038bdd0cc0  mov rax, [r15+0xF8]
000075038bdd0cc7  lea r14, [rax+0x100]
000075038bdd0cce  mov r12d, [r13+r14*1]
000075038bdd0cd3  lea r14, [rax+0x104]
000075038bdd0cda  mov r11d, [r13+r14*1]
000075038bdd0cdf  mov qword ptr [r15+0x48], 0x430C90
000075038bdd0ce7  lea r14, [rax+0x108]
000075038bdd0cee  mov r10d, [r13+r14*1]
000075038bdd0cf3  lea r14, [rax+0x10C]
000075038bdd0cfa  mov r9d, [r13+r14*1]
000075038bdd0cff  bswap r12d
000075038bdd0d02  bswap r11d
000075038bdd0d05  mov qword ptr [r15+0xA0], 0x00
000075038bdd0d10  mov r14d, 0x430C90
000075038bdd0d16  mov [r13+r14*1], r12d
000075038bdd0d1b  mov r14d, 0x430C94
000075038bdd0d21  mov [r13+r14*1], r11d
000075038bdd0d26  bswap r10d
000075038bdd0d29  lea r14, [rax+0x110]
000075038bdd0d30  mov r12d, [r13+r14*1]
000075038bdd0d35  bswap r9d
000075038bdd0d38  lea r14, [rax+0x114]
000075038bdd0d3f  mov r11d, [r13+r14*1]
000075038bdd0d44  mov qword ptr [r15+0x98], 0x430DFC
000075038bdd0d4f  mov r14d, 0x430C98
000075038bdd0d55  mov [r13+r14*1], r10d
000075038bdd0d5a  mov r14d, 0x430C9C
000075038bdd0d60  mov [r13+r14*1], r9d
000075038bdd0d65  bswap r12d
000075038bdd0d68  lea r14, [rax+0x118]
000075038bdd0d6f  mov r10d, [r13+r14*1]
000075038bdd0d74  bswap r11d
000075038bdd0d77  mov [rsp+0x10], r11d
000075038bdd0d7c  mov r11d, r11d
000075038bdd0d7f  mov [r15+0x58], r11
000075038bdd0d83  lea r14, [rax+0x11C]
000075038bdd0d8a  mov eax, [r13+r14*1]
000075038bdd0d8f  mov [rsp+0x20], eax
000075038bdd0d93  mov eax, eax
000075038bdd0d95  mov [r15+0x60], rax
000075038bdd0d99  mov eax, 0x430CA0
000075038bdd0d9e  mov [r13+rax*1], r12d
000075038bdd0da3  mov eax, 0x430CA4
000075038bdd0da8  mov r14d, [rsp+0x10]
000075038bdd0dad  mov [r13+rax*1], r14d
000075038bdd0db2  bswap r10d
000075038bdd0db5  mov [rsp+0x10], r10d
000075038bdd0dba  mov r10d, r10d
000075038bdd0dbd  mov [r15+0x40], r10
000075038bdd0dc1  mov eax, [rsp+0x20]
000075038bdd0dc5  bswap eax
000075038bdd0dc7  mov [rsp+0x20], eax
000075038bdd0dcb  mov eax, eax
000075038bdd0dcd  mov [r15+0x50], rax
000075038bdd0dd1  mov eax, 0x430CA8
000075038bdd0dd6  mov r14d, [rsp+0x10]
000075038bdd0ddb  mov [r13+rax*1], r14d
000075038bdd0de0  mov eax, 0x430CAC
000075038bdd0de5  mov r14d, [rsp+0x20]
000075038bdd0dea  mov [r13+rax*1], r14d
000075038bdd0def  mov eax, [r15+0xA0]
000075038bdd0df6  lea r14d, [eax+0x11]
000075038bdd0dfb  mov r14d, r14d
000075038bdd0dfe  mov [r15], r14
000075038bdd0e01  mov qword ptr [r15+0xF0], 0x41035C
000075038bdd0e0c  mov r14d, [r15+0x320]
000075038bdd0e13  mov eax, 0x41035C
000075038bdd0e18  mov rcx, 0x75038BDD0F90
000075038bdd0e22  mov [r15+r14*8+0x328], rax
000075038bdd0e2a  mov [r15+r14*8+0x368], rcx
000075038bdd0e32  add r14d, 0x01
000075038bdd0e36  and r14d, 0x07
000075038bdd0e3a  mov [r15+0x320], r14d
000075038bdd0e41  cmp dword ptr [r15+0x318], 0x00
000075038bdd0e49  jz 0x000075038BDD0F20
000075038bdd0e4f  nop [rax+rax*1], ax
000075038bdd0e58  nop [rax+rax*1], eax
000075038bdd0e60  mov eax, 0x4109A4
000075038bdd0e65  mov [r15+0x100], rax
000075038bdd0e6c  jmp 0x000075038BBFE110
000075038bdd0e71  int3
000075038bdd0e72  call 0x000075038BCE26A0
000075038bdd0e77  jmp 0x000075038BDD0CD3
000075038bdd0e7c  call 0x000075038BCE1430
000075038bdd0e81  jmp 0x000075038BDD0CDF
000075038bdd0e86  call 0x000075038BCE01C0
000075038bdd0e8b  jmp 0x000075038BDD0CF3
000075038bdd0e90  call 0x000075038BCDEF50
000075038bdd0e95  jmp 0x000075038BDD0CFF
000075038bdd0e9a  call 0x000075038BCE2BA0
000075038bdd0e9f  jmp 0x000075038BDD0D1B
000075038bdd0ea4  call 0x000075038BCE1920
000075038bdd0ea9  jmp 0x000075038BDD0D26
000075038bdd0eae  call 0x000075038BCE26A0
000075038bdd0eb3  jmp 0x000075038BDD0D35
000075038bdd0eb8  call 0x000075038BCE1430
000075038bdd0ebd  jmp 0x000075038BDD0D44
000075038bdd0ec2  call 0x000075038BCE06B0
000075038bdd0ec7  jmp 0x000075038BDD0D5A
000075038bdd0ecc  call 0x000075038BCDF440
000075038bdd0ed1  jmp 0x000075038BDD0D65
000075038bdd0ed6  call 0x000075038BCE01C0
000075038bdd0edb  jmp 0x000075038BDD0D74
000075038bdd0ee0  call 0x000075038BCD5890
000075038bdd0ee5  jmp 0x000075038BDD0D8F
000075038bdd0eea  call 0x000075038BC0BAE0
000075038bdd0eef  jmp 0x000075038BDD0DA3
000075038bdd0ef4  call 0x000075038BC0DFE0
000075038bdd0ef9  jmp 0x000075038BDD0DB2
000075038bdd0efe  call 0x000075038BC0DFE0
000075038bdd0f03  jmp 0x000075038BDD0DE0
000075038bdd0f08  call 0x000075038BC0DFE0
000075038bdd0f0d  jmp 0x000075038BDD0DEF
000075038bdd0f12  int3
000075038bdd0f13  nop [rax+rax*1], ax
000075038bdd0f1c  nop [rax], eax
000075038bdd0f20  mov eax, [r15]
000075038bdd0f23  mov [rsp+0x10], eax
000075038bdd0f27  shr eax, 0x10
000075038bdd0f2a  mov r14d, [rsp+0x10]
000075038bdd0f2f  xor r14d, eax
000075038bdd0f32  imul r14d, r14d, 0x7FEB352D
000075038bdd0f39  mov eax, 0x846CA68B
000075038bdd0f3e  mov eax, eax
000075038bdd0f40  mov [r15+0x48], rax
000075038bdd0f44  mov [rsp+0x10], r14d
000075038bdd0f49  shr r14d, 0x0F
000075038bdd0f4d  mov eax, [rsp+0x10]
000075038bdd0f51  xor eax, r14d
000075038bdd0f54  imul eax, eax, 0x846CA68B
000075038bdd0f5a  mov [rsp+0x10], eax
000075038bdd0f5e  mov eax, eax
000075038bdd0f60  mov [r15+0x40], rax
000075038bdd0f64  mov eax, [rsp+0x10]
000075038bdd0f68  shr eax, 0x10
000075038bdd0f6b  mov r14d, [rsp+0x10]
000075038bdd0f70  xor r14d, eax
000075038bdd0f73  mov r14d, r14d
000075038bdd0f76  mov [r15], r14
000075038bdd0f79  mov rax, [r15+0xF0]
000075038bdd0f80  mov [r15+0x100], rax
000075038bdd0f87  jmp 0x000075038BDCE5C0
000075038bdd0f8c  int3
000075038bdd0f8d  int3
000075038bdd0f8e  nop
000075038bdd0f90  mov rax, [r15+0xA0]
000075038bdd0f97  mov [rsp+0x10], rax
000075038bdd0f9c  shl rax, 0x02
000075038bdd0fa0  mov r14, [r15+0x98]
000075038bdd0fa7  lea r12, [r14+rax*1]
000075038bdd0fab  mov eax, [r15]
000075038bdd0fae  mov [r13+r12*1], eax
000075038bdd0fb3  mov rax, [rsp+0x10]
000075038bdd0fb8  lea r14, [rax+0x01]
000075038bdd0fbc  mov [r15+0xA0], r14
000075038bdd0fc3  xor eax, eax
000075038bdd0fc5  mov r12d, 0x400
000075038bdd0fcb  cmp r14, r12
000075038bdd0fce  cmc
000075038bdd0fcf  lahf
000075038bdd0fd0  seto al
000075038bdd0fd3  mov [r15+0x108], eax
000075038bdd0fda  mov eax, [r15+0x108]
000075038bdd0fe1  sahf
000075038bdd0fe2  jnz 0x000075038BDD1014
000075038bdd0fe4  cmp dword ptr [r15+0x318], 0x00
000075038bdd0fec  jz 0x000075038BDD10E0
000075038bdd0ff2  nop [rax+rax*1], ax
000075038bdd0ffb  nop [rax+rax*1], eax
000075038bdd1003  mov eax, 0x41036C
000075038bdd1008  mov [r15+0x100], rax
000075038bdd100f  jmp 0x000075038BBFE110
000075038bdd1014  cmp dword ptr [r15+0x318], 0x00
000075038bdd101c  jz 0x000075038BDD1050
000075038bdd1022  nop [rax+rax*1], ax
000075038bdd102b  nop [rax+rax*1], eax
000075038bdd1033  mov eax, 0x410354
000075038bdd1038  mov [r15+0x100], rax
000075038bdd103f  jmp 0x000075038BBFE110
000075038bdd1044  int3
000075038bdd1045  call 0x000075038BCB4B70
000075038bdd104a  jmp 0x000075038BDD0FB3
000075038bdd104f  int3
000075038bdd1050  mov eax, [r15+0xA0]
000075038bdd1057  lea r14d, [eax+0x11]
000075038bdd105c  mov r14d, r14d
000075038bdd105f  mov [r15], r14
000075038bdd1062  mov qword ptr [r15+0xF0], 0x41035C
000075038bdd106d  mov r14d, [r15+0x320]
000075038bdd1074  mov eax, 0x41035C
000075038bdd1079  mov rcx, 0x75038BDD0F90
000075038bdd1083  mov [r15+r14*8+0x328], rax
000075038bdd108b  mov [r15+r14*8+0x368], rcx
000075038bdd1093  add r14d, 0x01
000075038bdd1097  and r14d, 0x07
000075038bdd109b  mov [r15+0x320], r14d
000075038bdd10a2  cmp dword ptr [r15+0x318], 0x00
000075038bdd10aa  jz 0x000075038BDD0F20
000075038bdd10b0  nop [rax+rax*1], ax
000075038bdd10b9  nop [rax+rax*1], eax
000075038bdd10c1  mov eax, 0x4109A4
000075038bdd10c6  mov [r15+0x100], rax
000075038bdd10cd  jmp 0x000075038BBFE110
000075038bdd10d2  int3
000075038bdd10d3  int3
000075038bdd10d4  nop [rax+rax*1], ax
000075038bdd10dd  nop [rax], eax
000075038bdd10e0  mov qword ptr [r15+0x40], 0x01
000075038bdd10e8  cmp dword ptr [r15+0x318], 0x00
000075038bdd10f0  jz 0x000075038BDD1120
000075038bdd10f6  nop [rax+rax*1], ax
000075038bdd10ff  nop [rax+rax*1], eax
000075038bdd1107  mov eax, 0x410388
000075038bdd110c  mov [r15+0x100], rax
000075038bdd1113  jmp 0x000075038BBFE110
000075038bdd1118  int3
000075038bdd1119  int3
000075038bdd111a  nop [rax+rax*1], ax
000075038bdd1120  mov rax, [r15+0x40]
000075038bdd1124  mov [rsp+0x10], rax
000075038bdd1129  shl rax, 0x02
000075038bdd112d  mov r14, [r15+0x98]
000075038bdd1134  lea r12, [r14+rax*1]
000075038bdd1138  mov eax, [r13+r12*1]
000075038bdd113d  mov [rsp+0x20], eax
000075038bdd1141  mov eax, eax
000075038bdd1143  mov [r15+0x48], rax
000075038bdd1147  mov rax, [rsp+0x10]
000075038bdd114c  mov [r15+0x50], rax
000075038bdd1150  mov eax, [r15+0x50]
000075038bdd1154  lea r12d, [eax-0x01]
000075038bdd1159  mov r12d, r12d
000075038bdd115c  mov [r15+0x58], r12
000075038bdd1160  mov rax, [r15+0x58]
000075038bdd1164  mov r12d, eax
000075038bdd1167  mov r12d, r12d
000075038bdd116a  shl r12, 0x02
000075038bdd116e  lea rax, [r14+r12*1]
000075038bdd1172  mov r14d, [r13+rax*1]
000075038bdd1177  mov [rsp+0x10], r14d
000075038bdd117c  mov r14d, r14d
000075038bdd117f  mov [r15+0x60], r14
000075038bdd1183  xor eax, eax
000075038bdd1185  mov r14d, [rsp+0x10]
000075038bdd118a  mov r12d, [rsp+0x20]
000075038bdd118f  cmp r14d, r12d
000075038bdd1192  cmc
000075038bdd1193  lahf
000075038bdd1194  seto al
000075038bdd1197  mov [r15+0x108], eax
000075038bdd119e  mov eax, [r15+0x108]
000075038bdd11a5  sahf
000075038bdd11a6  cmc
000075038bdd11a7  jbe 0x000075038BDD11D9
000075038bdd11a9  cmp dword ptr [r15+0x318], 0x00
000075038bdd11b1  jz 0x000075038BDD1220
000075038bdd11b7  nop [rax+rax*1], ax
000075038bdd11c0  nop [rax+rax*1], eax
000075038bdd11c8  mov eax, 0x4103A0
000075038bdd11cd  mov [r15+0x100], rax
000075038bdd11d4  jmp 0x000075038BBFE110
000075038bdd11d9  cmp dword ptr [r15+0x318], 0x00
000075038bdd11e1  jz 0x000075038BDD14C0
000075038bdd11e7  nop [rax+rax*1], ax
000075038bdd11f0  nop [rax+rax*1], eax
000075038bdd11f8  mov eax, 0x410378
000075038bdd11fd  mov [r15+0x100], rax
000075038bdd1204  jmp 0x000075038BBFE110
000075038bdd1209  int3
000075038bdd120a  call 0x000075038BCB4690
000075038bdd120f  jmp 0x000075038BDD113D
000075038bdd1214  call 0x000075038BC0DAE0
000075038bdd1219  jmp 0x000075038BDD1177
000075038bdd121e  int3
000075038bdd121f  nop
000075038bdd1220  mov rax, [r15+0x50]
000075038bdd1224  mov [rsp+0x10], rax
000075038bdd1229  shl rax, 0x02
000075038bdd122d  mov r14, [r15+0x98]
000075038bdd1234  lea r12, [r14+rax*1]
000075038bdd1238  mov eax, [r15+0x60]
000075038bdd123c  mov [r13+r12*1], eax
000075038bdd1241  mov rax, [rsp+0x10]
000075038bdd1246  lea r14, [rax-0x01]
000075038bdd124a  mov [r15+0x50], r14
000075038bdd124e  mov rax, [r15+0x58]
000075038bdd1252  test rax, rax
000075038bdd1255  setz al
000075038bdd1258  movzx rax, al
000075038bdd125c  mov [rsp+0x414], al
000075038bdd1263  cmp byte ptr [rsp+0x414], 0x00
000075038bdd126b  jz 0x000075038BDD129D
000075038bdd126d  cmp dword ptr [r15+0x318], 0x00
000075038bdd1275  jz 0x000075038BDD12E0
000075038bdd127b  nop [rax+rax*1], ax
000075038bdd1284  nop [rax+rax*1], eax
000075038bdd128c  mov eax, 0x4103AC
000075038bdd1291  mov [r15+0x100], rax
000075038bdd1298  jmp 0x000075038BBFE110
000075038bdd129d  cmp dword ptr [r15+0x318], 0x00
000075038bdd12a5  jz 0x000075038BDD13E0
000075038bdd12ab  nop [rax+rax*1], ax
000075038bdd12b4  nop [rax+rax*1], eax
000075038bdd12bc  mov eax, 0x410390
000075038bdd12c1  mov [r15+0x100], rax
000075038bdd12c8  jmp 0x000075038BBFE110
000075038bdd12cd  int3
000075038bdd12ce  call 0x000075038BCB4B70
000075038bdd12d3  jmp 0x000075038BDD1241
000075038bdd12d8  int3
000075038bdd12d9  nop [rax], eax
000075038bdd12e0  cmp dword ptr [r15+0x318], 0x00
000075038bdd12e8  jz 0x000075038BDD1320
000075038bdd12ee  nop [rax+rax*1], ax
000075038bdd12f7  nop [rax+rax*1], eax
000075038bdd12ff  mov eax, 0x410374
000075038bdd1304  mov [r15+0x100], rax
000075038bdd130b  jmp 0x000075038BBFE110
000075038bdd1310  int3
000075038bdd1311  int3
000075038bdd1312  nop [rax+rax*1], ax
000075038bdd131b  nop [rax+rax*1], eax
000075038bdd1320  mov qword ptr [r15+0x50], 0x00
000075038bdd1328  mov rax, [r15+0x40]
000075038bdd132c  lea r14, [rax+0x01]
000075038bdd1330  mov [r15+0x40], r14
000075038bdd1334  mov rax, [r15+0x98]
000075038bdd133b  mov r12d, [r15+0x48]
000075038bdd133f  mov [r13+rax*1], r12d
000075038bdd1344  xor eax, eax
000075038bdd1346  mov r12d, 0x400
000075038bdd134c  cmp r14, r12
000075038bdd134f  cmc
000075038bdd1350  lahf
000075038bdd1351  seto al
000075038bdd1354  mov [r15+0x108], eax
000075038bdd135b  mov eax, [r15+0x108]
000075038bdd1362  sahf
000075038bdd1363  jz 0x000075038BDD1395
000075038bdd1365  cmp dword ptr [r15+0x318], 0x00
000075038bdd136d  jz 0x000075038BDD1120
000075038bdd1373  nop [rax+rax*1], ax
000075038bdd137c  nop [rax+rax*1], eax
000075038bdd1384  mov eax, 0x410388
000075038bdd1389  mov [r15+0x100], rax
000075038bdd1390  jmp 0x000075038BBFE110
000075038bdd1395  cmp dword ptr [r15+0x318], 0x00
000075038bdd139d  jz 0x000075038BDD1580
000075038bdd13a3  nop [rax+rax*1], ax
000075038bdd13ac  nop [rax+rax*1], eax
000075038bdd13b4  mov eax, 0x4103B0
000075038bdd13b9  mov [r15+0x100], rax
000075038bdd13c0  jmp 0x000075038BBFE110
000075038bdd13c5  int3
000075038bdd13c6  call 0x000075038BC0BAE0
000075038bdd13cb  jmp 0x000075038BDD1344
000075038bdd13d0  int3
000075038bdd13d1  nop [rax+rax*1], ax
000075038bdd13da  nop [rax+rax*1], ax
000075038bdd13e0  mov eax, [r15+0x50]
000075038bdd13e4  lea r14d, [eax-0x01]
000075038bdd13e9  mov r14d, r14d
000075038bdd13ec  mov [r15+0x58], r14
000075038bdd13f0  mov rax, [r15+0x58]
000075038bdd13f4  mov r14d, eax
000075038bdd13f7  mov r14d, r14d
000075038bdd13fa  shl r14, 0x02
000075038bdd13fe  mov rax, [r15+0x98]
000075038bdd1405  lea r12, [rax+r14*1]
000075038bdd1409  mov eax, [r13+r12*1]
000075038bdd140e  mov [rsp+0x10], eax
000075038bdd1412  mov eax, eax
000075038bdd1414  mov [r15+0x60], rax
000075038bdd1418  mov eax, [r15+0x48]
000075038bdd141c  mov [rsp+0x20], eax
000075038bdd1420  xor eax, eax
000075038bdd1422  mov r14d, [rsp+0x10]
000075038bdd1427  mov r12d, [rsp+0x20]
000075038bdd142c  cmp r14d, r12d
000075038bdd142f  cmc
000075038bdd1430  lahf
000075038bdd1431  seto al
000075038bdd1434  mov [r15+0x108], eax
000075038bdd143b  mov eax, [r15+0x108]
000075038bdd1442  sahf
000075038bdd1443  cmc
000075038bdd1444  jbe 0x000075038BDD1476
000075038bdd1446  cmp dword ptr [r15+0x318], 0x00
000075038bdd144e  jz 0x000075038BDD1220
000075038bdd1454  nop [rax+rax*1], ax
000075038bdd145d  nop [rax+rax*1], eax
000075038bdd1465  mov eax, 0x4103A0
000075038bdd146a  mov [r15+0x100], rax
000075038bdd1471  jmp 0x000075038BBFE110
000075038bdd1476  cmp dword ptr [r15+0x318], 0x00
000075038bdd147e  jz 0x000075038BDD14C0
000075038bdd1484  nop [rax+rax*1], ax
000075038bdd148d  nop [rax+rax*1], eax
000075038bdd1495  mov eax, 0x410378
000075038bdd149a  mov [r15+0x100], rax
000075038bdd14a1  jmp 0x000075038BBFE110
000075038bdd14a6  int3
000075038bdd14a7  call 0x000075038BCB4690
000075038bdd14ac  jmp 0x000075038BDD140E
000075038bdd14b1  int3
000075038bdd14b2  nop [rax+rax*1], ax
000075038bdd14bb  nop [rax+rax*1], eax
000075038bdd14c0  mov rax, [r15+0x40]
000075038bdd14c4  lea r14, [rax+0x01]
000075038bdd14c8  mov [r15+0x40], r14
000075038bdd14cc  mov rax, [r15+0x50]
000075038bdd14d0  mov r12d, eax
000075038bdd14d3  mov r12d, r12d
000075038bdd14d6  shl r12, 0x02
000075038bdd14da  mov rax, [r15+0x98]
000075038bdd14e1  lea r11, [rax+r12*1]
000075038bdd14e5  mov eax, [r15+0x48]
000075038bdd14e9  mov [r13+r11*1], eax
000075038bdd14ee  xor eax, eax
000075038bdd14f0  mov r12d, 0x400
000075038bdd14f6  cmp r14, r12
000075038bdd14f9  cmc
000075038bdd14fa  lahf
000075038bdd14fb  seto al
000075038bdd14fe  mov [r15+0x108], eax
000075038bdd1505  mov eax, [r15+0x108]
000075038bdd150c  sahf
000075038bdd150d  jz 0x000075038BDD153F
000075038bdd150f  cmp dword ptr [r15+0x318], 0x00
000075038bdd1517  jz 0x000075038BDD1120
000075038bdd151d  nop [rax+rax*1], ax
000075038bdd1526  nop [rax+rax*1], eax
000075038bdd152e  mov eax, 0x410388
000075038bdd1533  mov [r15+0x100], rax
000075038bdd153a  jmp 0x000075038BBFE110
000075038bdd153f  cmp dword ptr [r15+0x318], 0x00
000075038bdd1547  jz 0x000075038BDD1580
000075038bdd154d  nop [rax+rax*1], ax
000075038bdd1556  nop [rax+rax*1], eax
000075038bdd155e  mov eax, 0x4103B0
000075038bdd1563  mov [r15+0x100], rax
000075038bdd156a  jmp 0x000075038BBFE110
000075038bdd156f  int3
000075038bdd1570  call 0x000075038BCA4270
000075038bdd1575  jmp 0x000075038BDD14EE
000075038bdd157a  int3
000075038bdd157b  nop [rax+rax*1], eax
000075038bdd1580  mov qword ptr [r15+0x40], 0x430000
000075038bdd1588  mov eax, 0x430CB0
000075038bdd158d  mov r14, [r13+rax*1]
000075038bdd1592  mov rax, [r15+0x98]
000075038bdd1599  mov r12d, [r13+rax*1]
000075038bdd159e  lea r11, [rax+0x04]
000075038bdd15a2  mov eax, [r13+r11*1]
000075038bdd15a7  mov r12d, r12d
000075038bdd15aa  mov [r15+0x68], r12
000075038bdd15ae  mov eax, eax
000075038bdd15b0  mov [r15+0x60], rax
000075038bdd15b4  mov rax, [r15+0x68]
000075038bdd15b8  mov [r15+0x68], rax
000075038bdd15bc  mov qword ptr [r15+0x58], 0x02
000075038bdd15c4  mov [rsp+0x10], rax
000075038bdd15c9  xor eax, eax
000075038bdd15cb  mov r12d, 0x02
000075038bdd15d1  mov r11d, 0x400
000075038bdd15d7  cmp r12, r11
000075038bdd15da  cmc
000075038bdd15db  lahf
000075038bdd15dc  seto al
000075038bdd15df  mov [r15+0x108], eax
000075038bdd15e6  mov rax, [r15+0x60]
000075038bdd15ea  mov r12d, 0x02
000075038bdd15f0  imul rax, r12
000075038bdd15f4  mov [r15+0x50], rax
000075038bdd15f8  mov rax, [rsp+0x10]
000075038bdd15fd  lea r12, [rax+r14*1]
000075038bdd1601  mov [r15+0x48], r12
000075038bdd1605  mov eax, [r15+0x108]
000075038bdd160c  sahf
000075038bdd160d  jnz 0x000075038BDD163F
000075038bdd160f  cmp dword ptr [r15+0x318], 0x00
000075038bdd1617  jz 0x000075038BDD17B0
000075038bdd161d  nop [rax+rax*1], ax
000075038bdd1626  nop [rax+rax*1], eax
000075038bdd162e  mov eax, 0x4103E0
000075038bdd1633  mov [r15+0x100], rax
000075038bdd163a  jmp 0x000075038BBFE110
000075038bdd163f  cmp dword ptr [r15+0x318], 0x00
000075038bdd1647  jz 0x000075038BDD1690
000075038bdd164d  nop [rax+rax*1], ax
000075038bdd1656  nop [rax+rax*1], eax
000075038bdd165e  mov eax, 0x4103C0
000075038bdd1663  mov [r15+0x100], rax
000075038bdd166a  jmp 0x000075038BBFE110
000075038bdd166f  int3
000075038bdd1670  call 0x000075038BC0DC20
000075038bdd1675  jmp 0x000075038BDD1592
000075038bdd167a  call 0x000075038BC0B5E0
000075038bdd167f  jmp 0x000075038BDD159E
000075038bdd1684  call 0x000075038BCA3D90
000075038bdd1689  jmp 0x000075038BDD15A7
000075038bdd168e  int3
000075038bdd168f  nop
000075038bdd1690  mov rax, [r15+0x98]
000075038bdd1697  mov r14, [r15+0x58]
000075038bdd169b  mov [rsp+0x10], r14
000075038bdd16a0  shl r14, 0x02
000075038bdd16a4  lea r12, [rax+r14*1]
000075038bdd16a8  mov eax, [r13+r12*1]
000075038bdd16ad  lea r14, [r12+0x04]
000075038bdd16b2  mov r12d, [r13+r14*1]
000075038bdd16b7  mov eax, eax
000075038bdd16b9  mov [r15+0x68], rax
000075038bdd16bd  mov r12d, r12d
000075038bdd16c0  mov [r15+0x60], r12
000075038bdd16c4  mov rax, [r15+0x68]
000075038bdd16c8  mov [rsp+0x20], rax
000075038bdd16cd  mov r14, [rsp+0x10]
000075038bdd16d2  imul rax, r14
000075038bdd16d6  mov r12, [rsp+0x20]
000075038bdd16db  lea r11, [r12+rax*1]
000075038bdd16df  mov [r15+0x68], r11
000075038bdd16e3  lea rax, [r14+0x02]
000075038bdd16e7  mov [r15+0x58], rax
000075038bdd16eb  mov [rsp+0x10], rax
000075038bdd16f0  xor eax, eax
000075038bdd16f2  mov r14, [rsp+0x10]
000075038bdd16f7  mov r12d, 0x400
000075038bdd16fd  cmp r14, r12
000075038bdd1700  cmc
000075038bdd1701  lahf
000075038bdd1702  seto al
000075038bdd1705  mov [r15+0x108], eax
000075038bdd170c  mov rax, [r15+0x50]
000075038bdd1710  mov r12, [r15+0x60]
000075038bdd1714  imul r14, r12
000075038bdd1718  lea r12, [rax+r14*1]
000075038bdd171c  mov [r15+0x50], r12
000075038bdd1720  mov rax, [r15+0x48]
000075038bdd1724  lea r14, [r11+rax*1]
000075038bdd1728  mov [r15+0x48], r14
000075038bdd172c  mov eax, [r15+0x108]
000075038bdd1733  sahf
000075038bdd1734  jnz 0x000075038BDD1766
000075038bdd1736  cmp dword ptr [r15+0x318], 0x00
000075038bdd173e  jz 0x000075038BDD17B0
000075038bdd1744  nop [rax+rax*1], ax
000075038bdd174d  nop [rax+rax*1], eax
000075038bdd1755  mov eax, 0x4103E0
000075038bdd175a  mov [r15+0x100], rax
000075038bdd1761  jmp 0x000075038BBFE110
000075038bdd1766  cmp dword ptr [r15+0x318], 0x00
000075038bdd176e  jz 0x000075038BDD1690
000075038bdd1774  nop [rax+rax*1], ax
000075038bdd177d  nop [rax+rax*1], eax
000075038bdd1785  mov eax, 0x4103C0
000075038bdd178a  mov [r15+0x100], rax
000075038bdd1791  jmp 0x000075038BBFE110
000075038bdd1796  int3
000075038bdd1797  call 0x000075038BCB4690
000075038bdd179c  jmp 0x000075038BDD16AD
000075038bdd17a1  call 0x000075038BCE26A0
000075038bdd17a6  jmp 0x000075038BDD16B7
000075038bdd17ab  int3
000075038bdd17ac  nop [rax], eax
000075038bdd17b0  mov qword ptr [r15+0x98], 0x00
000075038bdd17bb  mov rax, [r15+0x50]
000075038bdd17bf  mov r14, [r15+0x48]
000075038bdd17c3  lea r12, [rax+r14*1]
000075038bdd17c7  mov [r15+0x48], r12
000075038bdd17cb  mov rax, [r15+0x40]
000075038bdd17cf  lea r14, [rax+0xCB0]
000075038bdd17d6  mov [r13+r14*1], r12
000075038bdd17db  mov qword ptr [r15], 0x01
000075038bdd17e2  mov qword ptr [r15+0xF0], 0x4103F8
000075038bdd17ed  mov r14d, [r15+0x320]
000075038bdd17f4  mov eax, 0x4103F8
000075038bdd17f9  mov rcx, 0x75038BDD1860
000075038bdd1803  mov [r15+r14*8+0x328], rax
000075038bdd180b  mov [r15+r14*8+0x368], rcx
000075038bdd1813  add r14d, 0x01
000075038bdd1817  and r14d, 0x07
000075038bdd181b  mov [r15+0x320], r14d
000075038bdd1822  cmp dword ptr [r15+0x318], 0x00
000075038bdd182a  jz 0x000075038BDD0F20
000075038bdd1830  nop [rax+rax*1], ax
000075038bdd1839  nop [rax+rax*1], eax
000075038bdd1841  mov eax, 0x4109A4
000075038bdd1846  mov [r15+0x100], rax
000075038bdd184d  jmp 0x000075038BBFE110
000075038bdd1852  int3
000075038bdd1853  call 0x000075038BCE2CE0
000075038bdd1858  jmp 0x000075038BDD17DB
000075038bdd185d  int3
000075038bdd185e  nop
000075038bdd1860  mov eax, [r15+0x98]
000075038bdd1867  lea r14d, [eax+0x01]
000075038bdd186c  mov [rsp+0x10], r14d
000075038bdd1871  mov r14d, r14d
000075038bdd1874  mov [r15+0x98], r14
000075038bdd187b  xor eax, eax
000075038bdd187d  mov r14d, [rsp+0x10]
000075038bdd1882  cmp r14d, 0x10000
000075038bdd1889  cmc
000075038bdd188a  lahf
000075038bdd188b  seto al
000075038bdd188e  mov [r15+0x108], eax
000075038bdd1895  mov eax, [r15+0x108]
000075038bdd189c  sahf
000075038bdd189d  jnz 0x000075038BDD18CF
000075038bdd189f  cmp dword ptr [r15+0x318], 0x00
000075038bdd18a7  jz 0x000075038BDD19A0
000075038bdd18ad  nop [rax+rax*1], ax
000075038bdd18b6  nop [rax+rax*1], eax
000075038bdd18be  mov eax, 0x410404
000075038bdd18c3  mov [r15+0x100], rax
000075038bdd18ca  jmp 0x000075038BBFE110
000075038bdd18cf  cmp dword ptr [r15+0x318], 0x00
000075038bdd18d7  jz 0x000075038BDD1910
000075038bdd18dd  nop [rax+rax*1], ax
000075038bdd18e6  nop [rax+rax*1], eax
000075038bdd18ee  mov eax, 0x4103F0
000075038bdd18f3  mov [r15+0x100], rax
000075038bdd18fa  jmp 0x000075038BBFE110
000075038bdd18ff  int3
000075038bdd1900  int3
000075038bdd1901  nop [rax+rax*1], ax
000075038bdd190a  nop [rax+rax*1], ax
000075038bdd1910  mov eax, [r15]
000075038bdd1913  mov r14d, [r15+0x98]
000075038bdd191a  lea r12d, [eax+r14d*1]
000075038bdd191f  mov r12d, r12d
000075038bdd1922  mov [r15], r12
000075038bdd1925  mov qword ptr [r15+0xF0], 0x4103F8
000075038bdd1930  mov r14d, [r15+0x320]
000075038bdd1937  mov eax, 0x4103F8
000075038bdd193c  mov rcx, 0x75038BDD1860
000075038bdd1946  mov [r15+r14*8+0x328], rax
000075038bdd194e  mov [r15+r14*8+0x368], rcx
000075038bdd1956  add r14d, 0x01
000075038bdd195a  and r14d, 0x07
000075038bdd195e  mov [r15+0x320], r14d
000075038bdd1965  cmp dword ptr [r15+0x318], 0x00
000075038bdd196d  jz 0x000075038BDD0F20
000075038bdd1973  nop [rax+rax*1], ax
000075038bdd197c  nop [rax+rax*1], eax
000075038bdd1984  mov eax, 0x4109A4
000075038bdd1989  mov [r15+0x100], rax
000075038bdd1990  jmp 0x000075038BBFE110
000075038bdd1995  int3
000075038bdd1996  int3
000075038bdd1997  nop [rax+rax*1], ax
000075038bdd19a0  vmovaps xmm1, [0x000075038B9FE010]
000075038bdd19a8  movq xmm1, xmm1
000075038bdd19ac  movaps [r15+0x110], xmm1
000075038bdd19b4  mov eax, 0x420B10
000075038bdd19b9  mov r14, [r13+rax*1]
000075038bdd19be  movq xmm1, r14
000075038bdd19c3  movaps [r15+0x120], xmm1
000075038bdd19cb  vmovaps xmm1, [0x000075038B9FE020]
000075038bdd19d3  movq xmm1, xmm1
000075038bdd19d7  movaps [r15+0x140], xmm1
000075038bdd19df  vmovaps xmm1, [0x000075038B9FE030]
000075038bdd19e7  vpbroadcastq xmm1, xmm1
000075038bdd19ec  movaps [r15+0x150], xmm1
000075038bdd19f4  mov qword ptr [r15+0x40], 0x02
000075038bdd19fc  vmovaps xmm15, [0x000075038B9FE040]
000075038bdd1a04  movq xmm15, xmm15
000075038bdd1a09  movaps [r15+0x160], xmm15
000075038bdd1a11  vmovaps xmm15, [0x000075038B9FE050]
000075038bdd1a19  vpbroadcastq xmm15, xmm15
000075038bdd1a1e  movaps [r15+0x130], xmm15
000075038bdd1a26  mov rax, [r15+0x40]
000075038bdd1a2a  vmovq xmm14, rax
000075038bdd1a2f  vpbroadcastq xmm14, xmm14
000075038bdd1a34  movaps [r15+0x170], xmm14
000075038bdd1a3c  mov eax, 0x420A40
000075038bdd1a41  movups xmm13, [r13+rax*1]
000075038bdd1a47  mov qword ptr [r15+0x40], 0x431E00
000075038bdd1a4f  mov eax, [r15]
000075038bdd1a52  mov r14d, 0x430CB8
000075038bdd1a58  mov [r13+r14*1], eax
000075038bdd1a5d  mov qword ptr [r15+0x50], 0x432000
000075038bdd1a65  vpmovqd xmm12, xmm13
000075038bdd1a6b  pxor xmm11, xmm11
000075038bdd1a70  punpcklqdq xmm12, xmm11
000075038bdd1a75  movaps [r15+0x210], xmm12
000075038bdd1a7d  movq xmm12, qword ptr [r15+0x140]
000075038bdd1a86  movq xmm11, qword ptr [r15+0x120]
000075038bdd1a8f  psubd xmm12, xmm11
000075038bdd1a94  movq xmm12, xmm12
000075038bdd1a99  paddq xmm13, xmm14
000075038bdd1a9e  movaps [r15+0x180], xmm13
000075038bdd1aa6  movq xmm14, qword ptr [r15+0x160]
000075038bdd1aaf  paddd xmm11, xmm14
000075038bdd1ab4  movq xmm11, xmm11
000075038bdd1ab9  movq xmm11, xmm11
000075038bdd1abe  movaps [r15+0x120], xmm11
000075038bdd1ac6  pmovzxdq xmm12, xmm12
000075038bdd1acc  psllq xmm12, 0x00
000075038bdd1ad2  movq xmm14, qword ptr [r15+0x210]
000075038bdd1adb  movq xmm13, qword ptr [r15+0x110]
000075038bdd1ae4  paddd xmm14, xmm13
000075038bdd1ae9  movq xmm14, xmm14
000075038bdd1aee  vcvtuqq2pd xmm12, xmm12
000075038bdd1af4  pmovzxdq xmm14, xmm14
000075038bdd1afa  psllq xmm14, 0x00
000075038bdd1b00  vcvtuqq2pd xmm14, xmm14
000075038bdd1b06  movaps xmm13, xmm12
000075038bdd1b0a  mulpd xmm13, xmm1
000075038bdd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000075038bdd1b15  ptest xmm11, xmm11
000075038bdd1b1b  jnz 0x000075038BDD1C0F
000075038bdd1b21  movaps [r15+0x220], xmm13
000075038bdd1b29  mov eax, 0x432000
000075038bdd1b2e  movups [r13+rax*1], xmm13
000075038bdd1b34  movaps xmm1, xmm14
000075038bdd1b38  mulpd xmm1, xmm15
000075038bdd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000075038bdd1b42  ptest xmm13, xmm13
000075038bdd1b48  jnz 0x000075038BDD1D5C
000075038bdd1b4e  movaps [r15+0x210], xmm1
000075038bdd1b56  mov eax, 0x431E00
000075038bdd1b5b  movups [r13+rax*1], xmm1
000075038bdd1b61  mov qword ptr [r15+0x48], 0x10
000075038bdd1b69  xor eax, eax
000075038bdd1b6b  mov r14d, 0x10
000075038bdd1b71  mov r12d, 0x200
000075038bdd1b77  cmp r14, r12
000075038bdd1b7a  cmc
000075038bdd1b7b  lahf
000075038bdd1b7c  seto al
000075038bdd1b7f  mov [r15+0x108], eax
000075038bdd1b86  mov eax, [r15+0x108]
000075038bdd1b8d  sahf
000075038bdd1b8e  jnz 0x000075038BDD1BC0
000075038bdd1b90  cmp dword ptr [r15+0x318], 0x00
000075038bdd1b98  jz 0x000075038BDD2300
000075038bdd1b9e  nop [rax+rax*1], ax
000075038bdd1ba7  nop [rax+rax*1], eax
000075038bdd1baf  mov eax, 0x410490
000075038bdd1bb4  mov [r15+0x100], rax
000075038bdd1bbb  jmp 0x000075038BBFE110
000075038bdd1bc0  cmp dword ptr [r15+0x318], 0x00
000075038bdd1bc8  jz 0x000075038BDD1EB0
000075038bdd1bce  nop [rax+rax*1], ax
000075038bdd1bd7  nop [rax+rax*1], eax
000075038bdd1bdf  mov eax, 0x410450
000075038bdd1be4  mov [r15+0x100], rax
000075038bdd1beb  jmp 0x000075038BBFE110
000075038bdd1bf0  int3
000075038bdd1bf1  call 0x000075038BC0DC20
000075038bdd1bf6  jmp 0x000075038BDD19BE
000075038bdd1bfb  call 0x000075038BC0C260
000075038bdd1c00  jmp 0x000075038BDD1A47
000075038bdd1c05  call 0x000075038BCD5D70
000075038bdd1c0a  jmp 0x000075038BDD1A5D
000075038bdd1c0f  sub rsp, 0x08
000075038bdd1c13  push rax
000075038bdd1c14  push rcx
000075038bdd1c15  push rdx
000075038bdd1c16  push rdi
000075038bdd1c17  push rsi
000075038bdd1c18  push r8
000075038bdd1c1a  push r9
000075038bdd1c1c  push r10
000075038bdd1c1e  push r11
000075038bdd1c20  sub rsp, 0xF0
000075038bdd1c27  vmovaps [rsp], xmm0
000075038bdd1c2c  vmovaps [rsp+0x10], xmm1
000075038bdd1c32  vmovaps [rsp+0x20], xmm2
000075038bdd1c38  vmovaps [rsp+0x30], xmm3
000075038bdd1c3e  vmovaps [rsp+0x40], xmm4
000075038bdd1c44  vmovaps [rsp+0x50], xmm5
000075038bdd1c4a  vmovaps [rsp+0x60], xmm6
000075038bdd1c50  vmovaps [rsp+0x70], xmm7
000075038bdd1c56  vmovaps [rsp+0x80], xmm8
000075038bdd1c5f  vmovaps [rsp+0x90], xmm9
000075038bdd1c68  vmovaps [rsp+0xA0], xmm10
000075038bdd1c71  vmovaps [rsp+0xB0], xmm11
000075038bdd1c7a  vmovaps [rsp+0xC0], xmm12
000075038bdd1c83  vmovaps [rsp+0xD0], xmm14
000075038bdd1c8c  vmovaps [rsp+0xE0], xmm15
000075038bdd1c95  sub rsp, 0x30
000075038bdd1c99  movaps [rsp], xmm13
000075038bdd1c9e  movaps [rsp+0x10], xmm12
000075038bdd1ca4  movaps [rsp+0x20], xmm1
000075038bdd1ca9  lea rdi, [rsp]
000075038bdd1cad  mov esi, 0x00
000075038bdd1cb2  mov rax, 0x56ADB4492530
000075038bdd1cbc  call rax
000075038bdd1cbe  movaps xmm13, [rsp]
000075038bdd1cc3  add rsp, 0x30
000075038bdd1cc7  vmovaps xmm0, [rsp]
000075038bdd1ccc  vmovaps xmm1, [rsp+0x10]
000075038bdd1cd2  vmovaps xmm2, [rsp+0x20]
000075038bdd1cd8  vmovaps xmm3, [rsp+0x30]
000075038bdd1cde  vmovaps xmm4, [rsp+0x40]
000075038bdd1ce4  vmovaps xmm5, [rsp+0x50]
000075038bdd1cea  vmovaps xmm6, [rsp+0x60]
000075038bdd1cf0  vmovaps xmm7, [rsp+0x70]
000075038bdd1cf6  vmovaps xmm8, [rsp+0x80]
000075038bdd1cff  vmovaps xmm9, [rsp+0x90]
000075038bdd1d08  vmovaps xmm10, [rsp+0xA0]
000075038bdd1d11  vmovaps xmm11, [rsp+0xB0]
000075038bdd1d1a  vmovaps xmm12, [rsp+0xC0]
000075038bdd1d23  vmovaps xmm14, [rsp+0xD0]
000075038bdd1d2c  vmovaps xmm15, [rsp+0xE0]
000075038bdd1d35  add rsp, 0xF0
000075038bdd1d3c  pop r11
000075038bdd1d3e  pop r10
000075038bdd1d40  pop r9
000075038bdd1d42  pop r8
000075038bdd1d44  pop rsi
000075038bdd1d45  pop rdi
000075038bdd1d46  pop rdx
000075038bdd1d47  pop rcx
000075038bdd1d48  pop rax
000075038bdd1d49  add rsp, 0x08
000075038bdd1d4d  jmp 0x000075038BDD1B21
000075038bdd1d52  call 0x000075038BC0C380
000075038bdd1d57  jmp 0x000075038BDD1B34
000075038bdd1d5c  sub rsp, 0x08
000075038bdd1d60  push rax
000075038bdd1d61  push rcx
000075038bdd1d62  push rdx
000075038bdd1d63  push rdi
000075038bdd1d64  push rsi
000075038bdd1d65  push r8
000075038bdd1d67  push r9
000075038bdd1d69  push r10
000075038bdd1d6b  push r11
000075038bdd1d6d  sub rsp, 0xF0
000075038bdd1d74  vmovaps [rsp], xmm0
000075038bdd1d79  vmovaps [rsp+0x10], xmm2
000075038bdd1d7f  vmovaps [rsp+0x20], xmm3
000075038bdd1d85  vmovaps [rsp+0x30], xmm4
000075038bdd1d8b  vmovaps [rsp+0x40], xmm5
000075038bdd1d91  vmovaps [rsp+0x50], xmm6
000075038bdd1d97  vmovaps [rsp+0x60], xmm7
000075038bdd1d9d  vmovaps [rsp+0x70], xmm8
000075038bdd1da3  vmovaps [rsp+0x80], xmm9
000075038bdd1dac  vmovaps [rsp+0x90], xmm10
000075038bdd1db5  vmovaps [rsp+0xA0], xmm11
000075038bdd1dbe  vmovaps [rsp+0xB0], xmm12
000075038bdd1dc7  vmovaps [rsp+0xC0], xmm13
000075038bdd1dd0  vmovaps [rsp+0xD0], xmm14
000075038bdd1dd9  vmovaps [rsp+0xE0], xmm15
000075038bdd1de2  sub rsp, 0x30
000075038bdd1de6  movaps [rsp], xmm1
000075038bdd1dea  movaps [rsp+0x10], xmm14
000075038bdd1df0  movaps [rsp+0x20], xmm15
000075038bdd1df6  lea rdi, [rsp]
000075038bdd1dfa  mov esi, 0x00
000075038bdd1dff  mov rax, 0x56ADB4492530
000075038bdd1e09  call rax
000075038bdd1e0b  movaps xmm1, [rsp]
000075038bdd1e0f  add rsp, 0x30
000075038bdd1e13  vmovaps xmm0, [rsp]
000075038bdd1e18  vmovaps xmm2, [rsp+0x10]
000075038bdd1e1e  vmovaps xmm3, [rsp+0x20]
000075038bdd1e24  vmovaps xmm4, [rsp+0x30]
000075038bdd1e2a  vmovaps xmm5, [rsp+0x40]
000075038bdd1e30  vmovaps xmm6, [rsp+0x50]
000075038bdd1e36  vmovaps xmm7, [rsp+0x60]
000075038bdd1e3c  vmovaps xmm8, [rsp+0x70]
000075038bdd1e42  vmovaps xmm9, [rsp+0x80]
000075038bdd1e4b  vmovaps xmm10, [rsp+0x90]
000075038bdd1e54  vmovaps xmm11, [rsp+0xA0]
000075038bdd1e5d  vmovaps xmm12, [rsp+0xB0]
000075038bdd1e66  vmovaps xmm13, [rsp+0xC0]
000075038bdd1e6f  vmovaps xmm14, [rsp+0xD0]
000075038bdd1e78  vmovaps xmm15, [rsp+0xE0]
000075038bdd1e81  add rsp, 0xF0
000075038bdd1e88  pop r11
000075038bdd1e8a  pop r10
000075038bdd1e8c  pop r9
000075038bdd1e8e  pop r8
000075038bdd1e90  pop rsi
000075038bdd1e91  pop rdi
000075038bdd1e92  pop rdx
000075038bdd1e93  pop rcx
000075038bdd1e94  pop rax
000075038bdd1e95  add rsp, 0x08
000075038bdd1e99  jmp 0x000075038BDD1B4E
000075038bdd1e9e  call 0x000075038BBFF540
000075038bdd1ea3  jmp 0x000075038BDD1B61
000075038bdd1ea8  int3
000075038bdd1ea9  nop [rax], eax
000075038bdd1eb0  movaps xmm1, [r15+0x180]
000075038bdd1eb8  vpmovqd xmm15, xmm1
000075038bdd1ebe  pxor xmm14, xmm14
000075038bdd1ec3  punpcklqdq xmm15, xmm14
000075038bdd1ec8  movaps [r15+0x210], xmm15
000075038bdd1ed0  movq xmm15, qword ptr [r15+0x140]
000075038bdd1ed9  movq xmm14, qword ptr [r15+0x120]
000075038bdd1ee2  psubd xmm15, xmm14
000075038bdd1ee7  movq xmm15, xmm15
000075038bdd1eec  movaps xmm13, [r15+0x170]
000075038bdd1ef4  paddq xmm1, xmm13
000075038bdd1ef9  movaps [r15+0x180], xmm1
000075038bdd1f01  movq xmm1, qword ptr [r15+0x160]
000075038bdd1f0a  paddd xmm14, xmm1
000075038bdd1f0f  movq xmm14, xmm14
000075038bdd1f14  movq xmm14, xmm14
000075038bdd1f19  movaps [r15+0x120], xmm14
000075038bdd1f21  pmovzxdq xmm15, xmm15
000075038bdd1f27  psllq xmm15, 0x00
000075038bdd1f2d  movq xmm1, qword ptr [r15+0x210]
000075038bdd1f36  movq xmm14, qword ptr [r15+0x110]
000075038bdd1f3f  paddd xmm1, xmm14
000075038bdd1f44  movq xmm1, xmm1
000075038bdd1f48  vcvtuqq2pd xmm15, xmm15
000075038bdd1f4e  pmovzxdq xmm1, xmm1
000075038bdd1f53  psllq xmm1, 0x00
000075038bdd1f58  vcvtuqq2pd xmm1, xmm1
000075038bdd1f5e  movaps xmm14, [r15+0x150]
000075038bdd1f66  movaps xmm13, xmm15
000075038bdd1f6a  mulpd xmm13, xmm14
000075038bdd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000075038bdd1f75  ptest xmm12, xmm12
000075038bdd1f7b  jnz 0x000075038BDD205E
000075038bdd1f81  movaps [r15+0x220], xmm13
000075038bdd1f89  mov rax, [r15+0x48]
000075038bdd1f8d  mov r14, [r15+0x50]
000075038bdd1f91  lea r12, [r14+rax*1]
000075038bdd1f95  movups [r13+r12*1], xmm13
000075038bdd1f9b  movaps xmm15, [r15+0x130]
000075038bdd1fa3  movaps xmm14, xmm1
000075038bdd1fa7  mulpd xmm14, xmm15
000075038bdd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000075038bdd1fb2  ptest xmm13, xmm13
000075038bdd1fb8  jnz 0x000075038BDD21AC
000075038bdd1fbe  movaps [r15+0x210], xmm14
000075038bdd1fc6  mov r14, [r15+0x40]
000075038bdd1fca  lea r12, [r14+rax*1]
000075038bdd1fce  movups [r13+r12*1], xmm14
000075038bdd1fd4  lea r14, [rax+0x10]
000075038bdd1fd8  mov [r15+0x48], r14
000075038bdd1fdc  xor eax, eax
000075038bdd1fde  mov r12d, 0x200
000075038bdd1fe4  cmp r14, r12
000075038bdd1fe7  cmc
000075038bdd1fe8  lahf
000075038bdd1fe9  seto al
000075038bdd1fec  mov [r15+0x108], eax
000075038bdd1ff3  mov eax, [r15+0x108]
000075038bdd1ffa  sahf
000075038bdd1ffb  jnz 0x000075038BDD202D
000075038bdd1ffd  cmp dword ptr [r15+0x318], 0x00
000075038bdd2005  jz 0x000075038BDD2300
000075038bdd200b  nop [rax+rax*1], ax
000075038bdd2014  nop [rax+rax*1], eax
000075038bdd201c  mov eax, 0x410490
000075038bdd2021  mov [r15+0x100], rax
000075038bdd2028  jmp 0x000075038BBFE110
000075038bdd202d  cmp dword ptr [r15+0x318], 0x00
000075038bdd2035  jz 0x000075038BDD1EB0
000075038bdd203b  nop [rax+rax*1], ax
000075038bdd2044  nop [rax+rax*1], eax
000075038bdd204c  mov eax, 0x410450
000075038bdd2051  mov [r15+0x100], rax
000075038bdd2058  jmp 0x000075038BBFE110
000075038bdd205d  int3
000075038bdd205e  sub rsp, 0x08
000075038bdd2062  push rax
000075038bdd2063  push rcx
000075038bdd2064  push rdx
000075038bdd2065  push rdi
000075038bdd2066  push rsi
000075038bdd2067  push r8
000075038bdd2069  push r9
000075038bdd206b  push r10
000075038bdd206d  push r11
000075038bdd206f  sub rsp, 0xF0
000075038bdd2076  vmovaps [rsp], xmm0
000075038bdd207b  vmovaps [rsp+0x10], xmm1
000075038bdd2081  vmovaps [rsp+0x20], xmm2
000075038bdd2087  vmovaps [rsp+0x30], xmm3
000075038bdd208d  vmovaps [rsp+0x40], xmm4
000075038bdd2093  vmovaps [rsp+0x50], xmm5
000075038bdd2099  vmovaps [rsp+0x60], xmm6
000075038bdd209f  vmovaps [rsp+0x70], xmm7
000075038bdd20a5  vmovaps [rsp+0x80], xmm8
000075038bdd20ae  vmovaps [rsp+0x90], xmm9
000075038bdd20b7  vmovaps [rsp+0xA0], xmm10
000075038bdd20c0  vmovaps [rsp+0xB0], xmm11
000075038bdd20c9  vmovaps [rsp+0xC0], xmm12
000075038bdd20d2  vmovaps [rsp+0xD0], xmm14
000075038bdd20db  vmovaps [rsp+0xE0], xmm15
000075038bdd20e4  sub rsp, 0x30
000075038bdd20e8  movaps [rsp], xmm13
000075038bdd20ed  movaps [rsp+0x10], xmm15
000075038bdd20f3  movaps [rsp+0x20], xmm14
000075038bdd20f9  lea rdi, [rsp]
000075038bdd20fd  mov esi, 0x00
000075038bdd2102  mov rax, 0x56ADB4492530
000075038bdd210c  call rax
000075038bdd210e  movaps xmm13, [rsp]
000075038bdd2113  add rsp, 0x30
000075038bdd2117  vmovaps xmm0, [rsp]
000075038bdd211c  vmovaps xmm1, [rsp+0x10]
000075038bdd2122  vmovaps xmm2, [rsp+0x20]
000075038bdd2128  vmovaps xmm3, [rsp+0x30]
000075038bdd212e  vmovaps xmm4, [rsp+0x40]
000075038bdd2134  vmovaps xmm5, [rsp+0x50]
000075038bdd213a  vmovaps xmm6, [rsp+0x60]
000075038bdd2140  vmovaps xmm7, [rsp+0x70]
000075038bdd2146  vmovaps xmm8, [rsp+0x80]
000075038bdd214f  vmovaps xmm9, [rsp+0x90]
000075038bdd2158  vmovaps xmm10, [rsp+0xA0]
000075038bdd2161  vmovaps xmm11, [rsp+0xB0]
000075038bdd216a  vmovaps xmm12, [rsp+0xC0]
000075038bdd2173  vmovaps xmm14, [rsp+0xD0]
000075038bdd217c  vmovaps xmm15, [rsp+0xE0]
000075038bdd2185  add rsp, 0xF0
000075038bdd218c  pop r11
000075038bdd218e  pop r10
000075038bdd2190  pop r9
000075038bdd2192  pop r8
000075038bdd2194  pop rsi
000075038bdd2195  pop rdi
000075038bdd2196  pop rdx
000075038bdd2197  pop rcx
000075038bdd2198  pop rax
000075038bdd2199  add rsp, 0x08
000075038bdd219d  jmp 0x000075038BDD1F81
000075038bdd21a2  call 0x000075038BCC2240
000075038bdd21a7  jmp 0x000075038BDD1F9B
000075038bdd21ac  sub rsp, 0x08
000075038bdd21b0  push rax
000075038bdd21b1  push rcx
000075038bdd21b2  push rdx
000075038bdd21b3  push rdi
000075038bdd21b4  push rsi
000075038bdd21b5  push r8
000075038bdd21b7  push r9
000075038bdd21b9  push r10
000075038bdd21bb  push r11
000075038bdd21bd  sub rsp, 0xF0
000075038bdd21c4  vmovaps [rsp], xmm0
000075038bdd21c9  vmovaps [rsp+0x10], xmm1
000075038bdd21cf  vmovaps [rsp+0x20], xmm2
000075038bdd21d5  vmovaps [rsp+0x30], xmm3
000075038bdd21db  vmovaps [rsp+0x40], xmm4
000075038bdd21e1  vmovaps [rsp+0x50], xmm5
000075038bdd21e7  vmovaps [rsp+0x60], xmm6
000075038bdd21ed  vmovaps [rsp+0x70], xmm7
000075038bdd21f3  vmovaps [rsp+0x80], xmm8
000075038bdd21fc  vmovaps [rsp+0x90], xmm9
000075038bdd2205  vmovaps [rsp+0xA0], xmm10
000075038bdd220e  vmovaps [rsp+0xB0], xmm11
000075038bdd2217  vmovaps [rsp+0xC0], xmm12
000075038bdd2220  vmovaps [rsp+0xD0], xmm13
000075038bdd2229  vmovaps [rsp+0xE0], xmm15
000075038bdd2232  sub rsp, 0x30
000075038bdd2236  movaps [rsp], xmm14
000075038bdd223b  movaps [rsp+0x10], xmm1
000075038bdd2240  movaps [rsp+0x20], xmm15
000075038bdd2246  lea rdi, [rsp]
000075038bdd224a  mov esi, 0x00
000075038bdd224f  mov rax, 0x56ADB4492530
000075038bdd2259  call rax
000075038bdd225b  movaps xmm14, [rsp]
000075038bdd2260  add rsp, 0x30
000075038bdd2264  vmovaps xmm0, [rsp]
000075038bdd2269  vmovaps xmm1, [rsp+0x10]
000075038bdd226f  vmovaps xmm2, [rsp+0x20]
000075038bdd2275  vmovaps xmm3, [rsp+0x30]
000075038bdd227b  vmovaps xmm4, [rsp+0x40]
000075038bdd2281  vmovaps xmm5, [rsp+0x50]
000075038bdd2287  vmovaps xmm6, [rsp+0x60]
000075038bdd228d  vmovaps xmm7, [rsp+0x70]
000075038bdd2293  vmovaps xmm8, [rsp+0x80]
000075038bdd229c  vmovaps xmm9, [rsp+0x90]
000075038bdd22a5  vmovaps xmm10, [rsp+0xA0]
000075038bdd22ae  vmovaps xmm11, [rsp+0xB0]
000075038bdd22b7  vmovaps xmm12, [rsp+0xC0]
000075038bdd22c0  vmovaps xmm13, [rsp+0xD0]
000075038bdd22c9  vmovaps xmm15, [rsp+0xE0]
000075038bdd22d2  add rsp, 0xF0
000075038bdd22d9  pop r11
000075038bdd22db  pop r10
000075038bdd22dd  pop r9
000075038bdd22df  pop r8
000075038bdd22e1  pop rsi
000075038bdd22e2  pop rdi
000075038bdd22e3  pop rdx
000075038bdd22e4  pop rcx
000075038bdd22e5  pop rax
000075038bdd22e6  add rsp, 0x08
000075038bdd22ea  jmp 0x000075038BDD1FBE
000075038bdd22ef  call 0x000075038BCC34C0
000075038bdd22f4  jmp 0x000075038BDD1FD4
000075038bdd22f9  int3
000075038bdd22fa  nop [rax+rax*1], ax
000075038bdd2300  mov rax, [r15+0x50]
000075038bdd2304  lea r14, [rax+0x80]
000075038bdd230b  movups xmm1, [r13+r14*1]
000075038bdd2311  lea r14, [rax+0x90]
000075038bdd2318  movups xmm15, [r13+r14*1]
000075038bdd231e  vxorps xmm14, xmm14, xmm14
000075038bdd2323  vpbroadcastq xmm14, xmm14
000075038bdd2328  lea r14, [rax+0x40]
000075038bdd232c  movups xmm13, [r13+r14*1]
000075038bdd2332  lea r14, [rax+0x50]
000075038bdd2336  movups xmm12, [r13+r14*1]
000075038bdd233c  mov qword ptr [r15+0x48], 0x00
000075038bdd2344  movups xmm11, [r13+rax*1]
000075038bdd234a  lea r14, [rax+0x10]
000075038bdd234e  movups xmm10, [r13+r14*1]
000075038bdd2354  mov r14, [r15+0xF8]
000075038bdd235b  lea r12, [r14+0xE0]
000075038bdd2362  movups [r13+r12*1], xmm15
000075038bdd2368  lea r12, [r14+0xF0]
000075038bdd236f  movups [r13+r12*1], xmm1
000075038bdd2375  lea r12, [rax+0xC0]
000075038bdd237c  movups xmm1, [r13+r12*1]
000075038bdd2382  lea r12, [rax+0xD0]
000075038bdd2389  movups xmm15, [r13+r12*1]
000075038bdd238f  lea r12, [rax+0x140]
000075038bdd2396  movups xmm9, [r13+r12*1]
000075038bdd239c  lea r12, [rax+0x150]
000075038bdd23a3  movups xmm8, [r13+r12*1]
000075038bdd23a9  lea r12, [rax+0x180]
000075038bdd23b0  movups xmm7, [r13+r12*1]
000075038bdd23b6  lea r12, [rax+0x190]
000075038bdd23bd  movups xmm6, [r13+r12*1]
000075038bdd23c3  lea r12, [r14+0xC0]
000075038bdd23ca  movups [r13+r12*1], xmm15
000075038bdd23d0  lea r12, [r14+0xD0]
000075038bdd23d7  movups [r13+r12*1], xmm1
000075038bdd23dd  lea r12, [rax+0x100]
000075038bdd23e4  movups xmm1, [r13+r12*1]
000075038bdd23ea  lea r12, [rax+0x110]
000075038bdd23f1  movups xmm15, [r13+r12*1]
000075038bdd23f7  lea r12, [rax+0x1C0]
000075038bdd23fe  movups xmm5, [r13+r12*1]
000075038bdd2404  lea r12, [rax+0x1D0]
000075038bdd240b  movups xmm4, [r13+r12*1]
000075038bdd2411  lea r12, [rax+0x20]
000075038bdd2415  movups xmm3, [r13+r12*1]
000075038bdd241b  lea r12, [rax+0x30]
000075038bdd241f  movups xmm2, [r13+r12*1]
000075038bdd2425  movaps [r15+0x1F0], xmm2
000075038bdd242d  lea r12, [r14+0x20]
000075038bdd2431  movups [r13+r12*1], xmm1
000075038bdd2437  lea r12, [r14+0x30]
000075038bdd243b  movups [r13+r12*1], xmm12
000075038bdd2441  lea r12, [rax+0x60]
000075038bdd2445  movups xmm1, [r13+r12*1]
000075038bdd244b  lea r12, [rax+0x70]
000075038bdd244f  movups xmm12, [r13+r12*1]
000075038bdd2455  lea r12, [r14+0x60]
000075038bdd2459  movups [r13+r12*1], xmm11
000075038bdd245f  lea r12, [r14+0x70]
000075038bdd2463  movups [r13+r12*1], xmm5
000075038bdd2469  lea r12, [rax+0xE0]
000075038bdd2470  movups xmm11, [r13+r12*1]
000075038bdd2476  lea r12, [rax+0xF0]
000075038bdd247d  movups xmm5, [r13+r12*1]
000075038bdd2483  lea r12, [rax+0x120]
000075038bdd248a  vmovaps [rsp+0x10], xmm1
000075038bdd2490  movups xmm1, [r13+r12*1]
000075038bdd2496  lea r12, [rax+0x130]
000075038bdd249d  vmovaps [rsp+0x20], xmm1
000075038bdd24a3  movups xmm1, [r13+r12*1]
000075038bdd24a9  lea r12, [r14+0xA0]
000075038bdd24b0  movups [r13+r12*1], xmm12
000075038bdd24b6  lea r12, [r14+0xB0]
000075038bdd24bd  vmovaps xmm12, [rsp+0x10]
000075038bdd24c3  movups [r13+r12*1], xmm12
000075038bdd24c9  lea r12, [rax+0xA0]
000075038bdd24d0  movups xmm12, [r13+r12*1]
000075038bdd24d6  lea r12, [rax+0xB0]
000075038bdd24dd  vmovaps [rsp+0x10], xmm1
000075038bdd24e3  movups xmm1, [r13+r12*1]
000075038bdd24e9  lea r12, [rax+0x160]
000075038bdd24f0  vmovaps [rsp+0x30], xmm1
000075038bdd24f6  movups xmm1, [r13+r12*1]
000075038bdd24fc  lea r12, [rax+0x170]
000075038bdd2503  vmovaps [rsp+0x40], xmm1
000075038bdd2509  movups xmm1, [r13+r12*1]
000075038bdd250f  movaps [r15+0x2B0], xmm1
000075038bdd2517  lea r12, [rax+0x1A0]
000075038bdd251e  vmovaps [rsp+0x50], xmm1
000075038bdd2524  movups xmm1, [r13+r12*1]
000075038bdd252a  lea r12, [rax+0x1B0]
000075038bdd2531  vmovaps [rsp+0x60], xmm1
000075038bdd2537  movups xmm1, [r13+r12*1]
000075038bdd253d  vmovaps [rsp+0x70], xmm1
000075038bdd2543  vmovaps xmm1, [rsp+0x60]
000075038bdd2549  movaps [r15+0x290], xmm1
000075038bdd2551  vmovaps [rsp+0x60], xmm1
000075038bdd2557  vmovaps xmm1, [rsp+0x70]
000075038bdd255d  movaps [r15+0x1E0], xmm1
000075038bdd2565  lea r12, [r14+0x80]
000075038bdd256c  vmovaps [rsp+0x70], xmm1
000075038bdd2572  vmovaps xmm1, [rsp+0x30]
000075038bdd2578  movups [r13+r12*1], xmm1
000075038bdd257e  lea r12, [r14+0x90]
000075038bdd2585  movups [r13+r12*1], xmm12
000075038bdd258b  lea r12, [rax+0x1E0]
000075038bdd2592  movups xmm1, [r13+r12*1]
000075038bdd2598  lea r12, [rax+0x1F0]
000075038bdd259f  movups xmm12, [r13+r12*1]
000075038bdd25a5  mov qword ptr [r15+0x50], 0x432200
000075038bdd25ad  lea rax, [r14+0x40]
000075038bdd25b1  vmovaps [rsp+0x30], xmm1
000075038bdd25b7  vmovaps xmm1, [rsp+0x40]
000075038bdd25bd  movups [r13+rax*1], xmm1
000075038bdd25c3  lea rax, [r14+0x50]
000075038bdd25c7  movups [r13+rax*1], xmm10
000075038bdd25cd  movups [r13+r14*1], xmm12
000075038bdd25d3  lea rax, [r14+0x10]
000075038bdd25d7  vmovaps xmm1, [rsp+0x30]
000075038bdd25dd  movups [r13+rax*1], xmm1
000075038bdd25e3  mov rax, [r15+0x40]
000075038bdd25e7  vmovaps [rsp+0x30], xmm3
000075038bdd25ed  vmovaps xmm1, [rsp+0x30]
000075038bdd25f3  por xmm3, xmm1
000075038bdd25f7  vmovaps [rsp+0x30], xmm6
000075038bdd25fd  vmovaps xmm12, [rsp+0x30]
000075038bdd2603  por xmm6, xmm12
000075038bdd2608  lea r12, [rax+0x30]
000075038bdd260c  mov r11, [r13+r12*1]
000075038bdd2611  lea r12, [rax+0x38]
000075038bdd2615  mov r10, [r13+r12*1]
000075038bdd261a  movq xmm12, r11
000075038bdd261f  movq xmm10, r10
000075038bdd2624  movq xmm12, xmm12
000075038bdd2629  vmovaps [rsp+0x30], xmm12
000075038bdd262f  movq xmm12, xmm12
000075038bdd2634  movaps [r15+0x130], xmm12
000075038bdd263c  movq xmm10, xmm10
000075038bdd2641  vmovaps [rsp+0x40], xmm10
000075038bdd2647  movq xmm10, xmm10
000075038bdd264c  movaps [r15+0x280], xmm10
000075038bdd2654  vmovaps [rsp+0x80], xmm9
000075038bdd265d  vmovaps xmm12, [rsp+0x80]
000075038bdd2666  por xmm9, xmm12
000075038bdd266b  lea r12, [rax+0x20]
000075038bdd266f  mov r11, [r13+r12*1]
000075038bdd2674  lea r12, [rax+0x28]
000075038bdd2678  mov r10, [r13+r12*1]
000075038bdd267d  movq xmm12, r11
000075038bdd2682  movq xmm10, r10
000075038bdd2687  movq xmm12, xmm12
000075038bdd268c  vmovaps [rsp+0x80], xmm12
000075038bdd2695  movq xmm12, xmm12
000075038bdd269a  movaps [r15+0x150], xmm12
000075038bdd26a2  movq xmm10, xmm10
000075038bdd26a7  vmovaps [rsp+0x90], xmm10
000075038bdd26b0  movq xmm10, xmm10
000075038bdd26b5  movaps [r15+0x140], xmm10
000075038bdd26bd  lea r12, [rax+0x10]
000075038bdd26c1  mov r11, [r13+r12*1]
000075038bdd26c6  lea r12, [rax+0x18]
000075038bdd26ca  mov r10, [r13+r12*1]
000075038bdd26cf  movq xmm12, r11
000075038bdd26d4  movq xmm10, r10
000075038bdd26d9  movq xmm12, xmm12
000075038bdd26de  vmovaps [rsp+0xA0], xmm12
000075038bdd26e7  movq xmm12, xmm12
000075038bdd26ec  movaps [r15+0x170], xmm12
000075038bdd26f4  movq xmm10, xmm10
000075038bdd26f9  vmovaps [rsp+0xB0], xmm10
000075038bdd2702  movq xmm10, xmm10
000075038bdd2707  movaps [r15+0x160], xmm10
000075038bdd270f  mov r12, [r13+rax*1]
000075038bdd2714  vmovq xmm12, r12
000075038bdd2719  vpbroadcastq xmm12, xmm12
000075038bdd271e  lea r12, [rax+0x08]
000075038bdd2722  mov rax, [r13+r12*1]
000075038bdd2727  movq xmm10, rax
000075038bdd272c  movaps [r15+0x230], xmm10
000075038bdd2734  lea rax, [r14+0x50]
000075038bdd2738  movups xmm10, [r13+rax*1]
000075038bdd273e  lea rax, [r14+0x60]
000075038bdd2742  vmovaps [rsp+0xC0], xmm1
000075038bdd274b  movups xmm1, [r13+rax*1]
000075038bdd2751  lea rax, [r14+0x30]
000075038bdd2755  vmovaps [rsp+0xD0], xmm1
000075038bdd275e  movups xmm1, [r13+rax*1]
000075038bdd2764  mov qword ptr [r15+0x60], 0x432200
000075038bdd276c  mov qword ptr [r15+0x58], 0x40
000075038bdd2774  vmovaps [rsp+0xE0], xmm1
000075038bdd277d  vmovaps [rsp+0xF0], xmm15
000075038bdd2786  vmovaps xmm15, [rsp+0xC0]
000075038bdd278f  vmovaps [rsp+0xC0], xmm14
000075038bdd2798  movaps xmm1, xmm12
000075038bdd279c  mulpd xmm1, xmm15
000075038bdd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
000075038bdd27a6  ptest xmm14, xmm14
000075038bdd27ac  jnz 0x000075038BDD3863
000075038bdd27b2  movq xmm15, qword ptr [r15+0x230]
000075038bdd27bb  vmovaps [rsp+0x100], xmm15
000075038bdd27c4  vpermilpd xmm15, xmm15, 0x00
000075038bdd27ca  vmovaps [rsp+0x110], xmm1
000075038bdd27d3  vmovaps xmm1, [rsp+0xE0]
000075038bdd27dc  vmovaps [rsp+0xE0], xmm13
000075038bdd27e5  movaps xmm14, xmm1
000075038bdd27e9  mulpd xmm14, xmm15
000075038bdd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
000075038bdd27f4  ptest xmm13, xmm13
000075038bdd27fa  jnz 0x000075038BDD39A5
000075038bdd2800  vxorps xmm1, xmm1, xmm1
000075038bdd2804  vpbroadcastq xmm1, xmm1
000075038bdd2809  vmovaps xmm13, [rsp+0xD0]
000075038bdd2812  vmovaps [rsp+0xD0], xmm1
000075038bdd281b  movaps xmm15, xmm12
000075038bdd281f  mulpd xmm15, xmm13
000075038bdd2824  vcmppd xmm1, xmm15, xmm15, 0x03
000075038bdd282a  ptest xmm1, xmm1
000075038bdd282f  jnz 0x000075038BDD3AE8
000075038bdd2835  movaps xmm1, xmm12
000075038bdd2839  mulpd xmm1, xmm10
000075038bdd283e  vcmppd xmm13, xmm1, xmm1, 0x03
000075038bdd2843  ptest xmm13, xmm13
000075038bdd2849  jnz 0x000075038BDD3C2C
000075038bdd284f  movaps xmm13, xmm12
000075038bdd2853  mulpd xmm13, xmm2
000075038bdd2858  vcmppd xmm10, xmm13, xmm13, 0x03
000075038bdd285e  ptest xmm10, xmm10
000075038bdd2864  jnz 0x000075038BDD3D6E
000075038bdd286a  vmovaps [rsp+0x120], xmm7
000075038bdd2873  vmovaps xmm12, [rsp+0x120]
000075038bdd287c  por xmm7, xmm12
000075038bdd2881  vmovaps xmm12, [rsp+0xE0]
000075038bdd288a  vmovaps xmm10, [rsp+0xE0]
000075038bdd2893  por xmm12, xmm10
000075038bdd2898  vmovaps xmm2, [rsp+0x100]
000075038bdd28a1  vpermilpd xmm2, xmm2, 0x00
000075038bdd28a7  vmovaps [rsp+0xE0], xmm1
000075038bdd28b0  vmovaps [rsp+0x120], xmm15
000075038bdd28b9  movaps xmm1, xmm10
000075038bdd28bd  mulpd xmm1, xmm2
000075038bdd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
000075038bdd28c6  ptest xmm15, xmm15
000075038bdd28cc  jnz 0x000075038BDD3EB1
000075038bdd28d2  xor eax, eax
000075038bdd28d4  mov r12d, 0x40
000075038bdd28da  mov r11d, 0x200
000075038bdd28e0  cmp r12, r11
000075038bdd28e3  cmc
000075038bdd28e4  lahf
000075038bdd28e5  seto al
000075038bdd28e8  mov [r15+0x108], eax
000075038bdd28ef  vmovaps xmm10, [rsp+0x110]
000075038bdd28f8  vmovaps xmm2, [rsp+0xD0]
000075038bdd2901  vmovaps [rsp+0xD0], xmm1
000075038bdd290a  movaps xmm15, xmm10
000075038bdd290e  addpd xmm15, xmm2
000075038bdd2913  vcmppd xmm1, xmm15, xmm15, 0x03
000075038bdd2919  ptest xmm1, xmm1
000075038bdd291e  jnz 0x000075038BDD3FF2
000075038bdd2924  vmovaps xmm10, [rsp+0x120]
000075038bdd292d  vmovaps [rsp+0x110], xmm15
000075038bdd2936  vmovaps xmm15, [rsp+0xC0]
000075038bdd293f  vmovaps [rsp+0xC0], xmm14
000075038bdd2948  movaps xmm1, xmm10
000075038bdd294c  addpd xmm1, xmm15
000075038bdd2951  vcmppd xmm14, xmm1, xmm1, 0x03
000075038bdd2956  ptest xmm14, xmm14
000075038bdd295c  jnz 0x000075038BDD4135
000075038bdd2962  vmovaps xmm10, [rsp+0xE0]
000075038bdd296b  vmovaps [rsp+0xE0], xmm1
000075038bdd2974  movaps xmm14, xmm10
000075038bdd2978  addpd xmm14, xmm15
000075038bdd297d  vcmppd xmm1, xmm14, xmm14, 0x03
000075038bdd2983  ptest xmm1, xmm1
000075038bdd2988  jnz 0x000075038BDD4277
000075038bdd298e  vmovaps xmm1, [rsp+0x10]
000075038bdd2994  vmovaps xmm15, [rsp+0x10]
000075038bdd299a  por xmm1, xmm15
000075038bdd299f  vmovaps xmm15, [rsp+0x20]
000075038bdd29a5  vmovaps xmm10, [rsp+0x20]
000075038bdd29ab  por xmm15, xmm10
000075038bdd29b0  vmovaps [rsp+0x10], xmm5
000075038bdd29b6  vmovaps xmm10, [rsp+0x10]
000075038bdd29bc  por xmm5, xmm10
000075038bdd29c1  vmovaps [rsp+0x10], xmm11
000075038bdd29c7  vmovaps xmm10, [rsp+0x10]
000075038bdd29cd  por xmm11, xmm10
000075038bdd29d2  vmovaps [rsp+0x10], xmm4
000075038bdd29d8  vmovaps xmm10, [rsp+0x10]
000075038bdd29de  por xmm4, xmm10
000075038bdd29e3  vmovaps [rsp+0x10], xmm8
000075038bdd29e9  vmovaps xmm10, [rsp+0x10]
000075038bdd29ef  por xmm8, xmm10
000075038bdd29f4  vmovaps xmm10, [rsp+0xF0]
000075038bdd29fd  vmovaps [rsp+0x10], xmm1
000075038bdd2a03  vmovaps xmm1, [rsp+0xF0]
000075038bdd2a0c  por xmm10, xmm1
000075038bdd2a11  lea rax, [r14+0xA0]
000075038bdd2a18  movups xmm1, [r13+rax*1]
000075038bdd2a1e  lea rax, [r14+0xB0]
000075038bdd2a25  vmovaps [rsp+0x20], xmm1
000075038bdd2a2b  movups xmm1, [r13+rax*1]
000075038bdd2a31  vmovaps [rsp+0xF0], xmm1
000075038bdd2a3a  vmovaps [rsp+0x120], xmm15
000075038bdd2a43  movaps xmm1, xmm13
000075038bdd2a47  addpd xmm1, xmm2
000075038bdd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
000075038bdd2a50  ptest xmm15, xmm15
000075038bdd2a56  jnz 0x000075038BDD43CF
000075038bdd2a5c  lea rax, [r14+0xF0]
000075038bdd2a63  movups xmm15, [r13+rax*1]
000075038bdd2a69  vmovaps xmm2, [rsp+0xE0]
000075038bdd2a72  vmovaps [rsp+0xE0], xmm1
000075038bdd2a7b  vmovaps xmm1, [rsp+0xD0]
000075038bdd2a84  vmovaps [rsp+0xD0], xmm15
000075038bdd2a8d  movaps xmm13, xmm2
000075038bdd2a91  addpd xmm13, xmm1
000075038bdd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
000075038bdd2a9c  ptest xmm15, xmm15
000075038bdd2aa2  jnz 0x000075038BDD451A
000075038bdd2aa8  vmovaps xmm15, [rsp+0xC0]
000075038bdd2ab1  movaps xmm1, xmm14
000075038bdd2ab5  addpd xmm1, xmm15
000075038bdd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
000075038bdd2abf  ptest xmm2, xmm2
000075038bdd2ac4  jnz 0x000075038BDD465C
000075038bdd2aca  vmovaps xmm15, [rsp+0x100]
000075038bdd2ad3  vpermilpd xmm15, xmm15, 0x00
000075038bdd2ad9  vmovaps xmm2, [rsp+0xF0]
000075038bdd2ae2  vmovaps [rsp+0xC0], xmm1
000075038bdd2aeb  movaps xmm14, xmm2
000075038bdd2aef  mulpd xmm14, xmm15
000075038bdd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
000075038bdd2afa  ptest xmm1, xmm1
000075038bdd2aff  jnz 0x000075038BDD479E
000075038bdd2b05  vmovaps xmm1, [rsp+0xA0]
000075038bdd2b0e  vpermilpd xmm1, xmm1, 0x00
000075038bdd2b14  vmovaps xmm2, [rsp+0xD0]
000075038bdd2b1d  vmovaps [rsp+0xD0], xmm14
000075038bdd2b26  movaps xmm15, xmm2
000075038bdd2b2a  mulpd xmm15, xmm1
000075038bdd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
000075038bdd2b35  ptest xmm14, xmm14
000075038bdd2b3b  jnz 0x000075038BDD48E1
000075038bdd2b41  lea rax, [r14+0xE0]
000075038bdd2b48  movups xmm1, [r13+rax*1]
000075038bdd2b4e  vmovaps xmm14, [rsp+0x100]
000075038bdd2b57  vpermilpd xmm14, xmm14, 0x00
000075038bdd2b5d  vmovaps [rsp+0xF0], xmm1
000075038bdd2b66  vmovaps xmm1, [rsp+0x20]
000075038bdd2b6c  vmovaps [rsp+0x20], xmm15
000075038bdd2b72  movaps xmm2, xmm1
000075038bdd2b75  mulpd xmm2, xmm14
000075038bdd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
000075038bdd2b7f  ptest xmm15, xmm15
000075038bdd2b85  jnz 0x000075038BDD4A2D
000075038bdd2b8b  vmovaps [rsp+0x100], xmm10
000075038bdd2b94  vmovaps xmm1, [rsp+0x100]
000075038bdd2b9d  por xmm10, xmm1
000075038bdd2ba2  movaps [r15+0x300], xmm10
000075038bdd2baa  vmovaps [rsp+0x100], xmm8
000075038bdd2bb3  vmovaps xmm1, [rsp+0x100]
000075038bdd2bbc  por xmm8, xmm1
000075038bdd2bc1  movaps [r15+0x190], xmm8
000075038bdd2bc9  vmovaps xmm1, [rsp+0xA0]
000075038bdd2bd2  vpermilpd xmm1, xmm1, 0x00
000075038bdd2bd8  vmovaps xmm14, [rsp+0xF0]
000075038bdd2be1  vmovaps [rsp+0xF0], xmm13
000075038bdd2bea  movaps xmm15, xmm14
000075038bdd2bee  mulpd xmm15, xmm1
000075038bdd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
000075038bdd2bf9  ptest xmm13, xmm13
000075038bdd2bff  jnz 0x000075038BDD4B6E
000075038bdd2c05  lea rax, [r14+0x90]
000075038bdd2c0c  movups xmm1, [r13+rax*1]
000075038bdd2c12  vmovaps [rsp+0x100], xmm4
000075038bdd2c1b  vmovaps xmm14, [rsp+0x100]
000075038bdd2c24  por xmm4, xmm14
000075038bdd2c29  movaps [r15+0x1C0], xmm4
000075038bdd2c31  vmovaps [rsp+0x100], xmm11
000075038bdd2c3a  vmovaps xmm14, [rsp+0x100]
000075038bdd2c43  por xmm11, xmm14
000075038bdd2c48  movaps [r15+0x200], xmm11
000075038bdd2c50  vmovaps [rsp+0x100], xmm5
000075038bdd2c59  vmovaps xmm14, [rsp+0x100]
000075038bdd2c62  por xmm5, xmm14
000075038bdd2c67  movaps [r15+0x2D0], xmm5
000075038bdd2c6f  vmovaps xmm14, [rsp+0x120]
000075038bdd2c78  vmovaps xmm13, [rsp+0x120]
000075038bdd2c81  por xmm14, xmm13
000075038bdd2c86  movaps [r15+0x2E0], xmm14
000075038bdd2c8e  vmovaps [rsp+0x100], xmm1
000075038bdd2c97  vmovaps xmm1, [rsp+0x110]
000075038bdd2ca0  vmovaps [rsp+0x110], xmm15
000075038bdd2ca9  vmovaps xmm15, [rsp+0xD0]
000075038bdd2cb2  vmovaps [rsp+0xD0], xmm14
000075038bdd2cbb  movaps xmm13, xmm1
000075038bdd2cbf  addpd xmm13, xmm15
000075038bdd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
000075038bdd2cca  ptest xmm14, xmm14
000075038bdd2cd0  jnz 0x000075038BDD4CBB
000075038bdd2cd6  vmovaps xmm1, [rsp+0xA0]
000075038bdd2cdf  vpermilpd xmm1, xmm1, 0x00
000075038bdd2ce5  vmovaps xmm14, [rsp+0x100]
000075038bdd2cee  vmovaps [rsp+0x100], xmm13
000075038bdd2cf7  movaps xmm15, xmm14
000075038bdd2cfb  mulpd xmm15, xmm1
000075038bdd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
000075038bdd2d06  ptest xmm13, xmm13
000075038bdd2d0c  jnz 0x000075038BDD4DFE
000075038bdd2d12  lea rax, [r14+0x80]
000075038bdd2d19  movups xmm1, [r13+rax*1]
000075038bdd2d1f  vmovaps xmm13, [rsp+0xE0]
000075038bdd2d28  vmovaps [rsp+0xE0], xmm1
000075038bdd2d31  movaps xmm14, xmm13
000075038bdd2d35  addpd xmm14, xmm2
000075038bdd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
000075038bdd2d40  ptest xmm1, xmm1
000075038bdd2d45  jnz 0x000075038BDD4F4B
000075038bdd2d4b  vmovaps xmm13, [rsp+0xF0]
000075038bdd2d54  vmovaps xmm2, [rsp+0x20]
000075038bdd2d5a  vmovaps [rsp+0x20], xmm15
000075038bdd2d60  movaps xmm1, xmm13
000075038bdd2d64  addpd xmm1, xmm2
000075038bdd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
000075038bdd2d6d  ptest xmm15, xmm15
000075038bdd2d73  jnz 0x000075038BDD508E
000075038bdd2d79  vmovaps xmm15, [rsp+0x10]
000075038bdd2d7f  vmovaps xmm13, [rsp+0x10]
000075038bdd2d85  por xmm15, xmm13
000075038bdd2d8a  movaps [r15+0x2F0], xmm15
000075038bdd2d92  vmovaps xmm13, [rsp+0xA0]
000075038bdd2d9b  vpermilpd xmm13, xmm13, 0x00
000075038bdd2da1  vmovaps [rsp+0x10], xmm1
000075038bdd2da7  vmovaps xmm1, [rsp+0xE0]
000075038bdd2db0  vmovaps [rsp+0xA0], xmm15
000075038bdd2db9  movaps xmm2, xmm1
000075038bdd2dbc  mulpd xmm2, xmm13
000075038bdd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
000075038bdd2dc6  ptest xmm15, xmm15
000075038bdd2dcc  jnz 0x000075038BDD51CF
000075038bdd2dd2  lea rax, [r14+0xD0]
000075038bdd2dd9  movups xmm1, [r13+rax*1]
000075038bdd2ddf  vmovaps xmm13, [rsp+0xC0]
000075038bdd2de8  vmovaps [rsp+0xC0], xmm1
000075038bdd2df1  vmovaps xmm1, [rsp+0x110]
000075038bdd2dfa  vmovaps [rsp+0xE0], xmm14
000075038bdd2e03  movaps xmm15, xmm13
000075038bdd2e07  addpd xmm15, xmm1
000075038bdd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
000075038bdd2e12  ptest xmm14, xmm14
000075038bdd2e18  jnz 0x000075038BDD531A
000075038bdd2e1e  vmovaps xmm1, [rsp+0xB0]
000075038bdd2e27  vpermilpd xmm1, xmm1, 0x00
000075038bdd2e2d  movaps xmm14, xmm11
000075038bdd2e31  mulpd xmm14, xmm1
000075038bdd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
000075038bdd2e3c  ptest xmm13, xmm13
000075038bdd2e42  jnz 0x000075038BDD545D
000075038bdd2e48  movaps [r15+0x260], xmm14
000075038bdd2e50  vxorps xmm1, xmm1, xmm1
000075038bdd2e54  vpbroadcastq xmm1, xmm1
000075038bdd2e59  movaps [r15+0x1B0], xmm1
000075038bdd2e61  vmovaps xmm1, [rsp+0xB0]
000075038bdd2e6a  vpermilpd xmm1, xmm1, 0x00
000075038bdd2e70  vmovaps xmm11, [rsp+0xC0]
000075038bdd2e79  vmovaps [rsp+0xC0], xmm15
000075038bdd2e82  movaps xmm13, xmm11
000075038bdd2e86  mulpd xmm13, xmm1
000075038bdd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
000075038bdd2e91  ptest xmm15, xmm15
000075038bdd2e97  jnz 0x000075038BDD55A0
000075038bdd2e9d  lea rax, [r14+0xC0]
000075038bdd2ea4  movups xmm1, [r13+rax*1]
000075038bdd2eaa  vmovaps xmm11, [rsp+0x100]
000075038bdd2eb3  vmovaps [rsp+0xF0], xmm1
000075038bdd2ebc  vmovaps xmm1, [rsp+0x20]
000075038bdd2ec2  vmovaps [rsp+0x20], xmm14
000075038bdd2ec8  movaps xmm15, xmm11
000075038bdd2ecc  addpd xmm15, xmm1
000075038bdd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
000075038bdd2ed7  ptest xmm14, xmm14
000075038bdd2edd  jnz 0x000075038BDD56ED
000075038bdd2ee3  vmovaps [rsp+0x100], xmm9
000075038bdd2eec  vmovaps xmm1, [rsp+0x100]
000075038bdd2ef5  por xmm9, xmm1
000075038bdd2efa  movaps [r15+0x270], xmm9
000075038bdd2f02  vmovaps [rsp+0x100], xmm6
000075038bdd2f0b  vmovaps xmm1, [rsp+0x100]
000075038bdd2f14  por xmm6, xmm1
000075038bdd2f18  movaps [r15+0x1A0], xmm6
000075038bdd2f20  vmovaps xmm14, [rsp+0xB0]
000075038bdd2f29  vpermilpd xmm14, xmm14, 0x00
000075038bdd2f2f  vmovaps xmm6, [rsp+0xF0]
000075038bdd2f38  vmovaps [rsp+0xF0], xmm1
000075038bdd2f41  movaps xmm11, xmm6
000075038bdd2f45  mulpd xmm11, xmm14
000075038bdd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
000075038bdd2f50  ptest xmm1, xmm1
000075038bdd2f55  jnz 0x000075038BDD5830
000075038bdd2f5b  lea rax, [r14+0x20]
000075038bdd2f5f  movups xmm1, [r13+rax*1]
000075038bdd2f65  movaps [r15+0x110], xmm1
000075038bdd2f6d  vmovaps xmm6, [rsp+0xE0]
000075038bdd2f76  vmovaps [rsp+0xE0], xmm1
000075038bdd2f7f  movaps xmm14, xmm6
000075038bdd2f83  addpd xmm14, xmm2
000075038bdd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
000075038bdd2f8e  ptest xmm1, xmm1
000075038bdd2f93  jnz 0x000075038BDD597D
000075038bdd2f99  vmovaps xmm1, [rsp+0xB0]
000075038bdd2fa2  vpermilpd xmm1, xmm1, 0x00
000075038bdd2fa8  movaps xmm6, xmm5
000075038bdd2fab  mulpd xmm6, xmm1
000075038bdd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
000075038bdd2fb4  ptest xmm2, xmm2
000075038bdd2fb9  jnz 0x000075038BDD5ABF
000075038bdd2fbf  vmovaps xmm5, [rsp+0x10]
000075038bdd2fc5  movaps xmm1, xmm5
000075038bdd2fc8  addpd xmm1, xmm13
000075038bdd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
000075038bdd2fd2  ptest xmm2, xmm2
000075038bdd2fd7  jnz 0x000075038BDD5BFF
000075038bdd2fdd  vmovaps xmm13, [rsp+0x80]
000075038bdd2fe6  vpermilpd xmm13, xmm13, 0x00
000075038bdd2fec  vmovaps xmm2, [rsp+0xE0]
000075038bdd2ff5  vmovaps [rsp+0x10], xmm1
000075038bdd2ffb  movaps xmm5, xmm2
000075038bdd2ffe  mulpd xmm5, xmm13
000075038bdd3003  vcmppd xmm1, xmm5, xmm5, 0x03
000075038bdd3008  ptest xmm1, xmm1
000075038bdd300d  jnz 0x000075038BDD5D40
000075038bdd3013  vmovaps xmm1, [rsp+0x80]
000075038bdd301c  vpermilpd xmm1, xmm1, 0x00
000075038bdd3022  movaps xmm13, xmm10
000075038bdd3026  mulpd xmm13, xmm1
000075038bdd302b  vcmppd xmm2, xmm13, xmm13, 0x03
000075038bdd3031  ptest xmm2, xmm2
000075038bdd3036  jnz 0x000075038BDD5E81
000075038bdd303c  vmovaps xmm10, [rsp+0x20]
000075038bdd3042  movaps xmm1, xmm15
000075038bdd3046  addpd xmm1, xmm10
000075038bdd304b  vcmppd xmm2, xmm1, xmm1, 0x03
000075038bdd3050  ptest xmm2, xmm2
000075038bdd3055  jnz 0x000075038BDD5FC4
000075038bdd305b  vmovaps xmm10, [rsp+0xC0]
000075038bdd3064  movaps xmm15, xmm10
000075038bdd3068  addpd xmm15, xmm11
000075038bdd306d  vcmppd xmm2, xmm15, xmm15, 0x03
000075038bdd3073  ptest xmm2, xmm2
000075038bdd3078  jnz 0x000075038BDD6106
000075038bdd307e  vmovaps xmm11, [rsp+0x80]
000075038bdd3087  vpermilpd xmm11, xmm11, 0x00
000075038bdd308d  vmovaps xmm2, [rsp+0xD0]
000075038bdd3096  vmovaps [rsp+0x20], xmm1
000075038bdd309c  movaps xmm10, xmm2
000075038bdd30a0  mulpd xmm10, xmm11
000075038bdd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
000075038bdd30ab  ptest xmm1, xmm1
000075038bdd30b0  jnz 0x000075038BDD624A
000075038bdd30b6  vmovaps xmm1, [rsp+0x80]
000075038bdd30bf  vpermilpd xmm1, xmm1, 0x00
000075038bdd30c5  vmovaps xmm2, [rsp+0xA0]
000075038bdd30ce  vmovaps [rsp+0x80], xmm15
000075038bdd30d7  movaps xmm11, xmm2
000075038bdd30db  mulpd xmm11, xmm1
000075038bdd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
000075038bdd30e6  ptest xmm15, xmm15
000075038bdd30ec  jnz 0x000075038BDD638D
000075038bdd30f2  movaps xmm1, xmm14
000075038bdd30f6  addpd xmm1, xmm6
000075038bdd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
000075038bdd30ff  ptest xmm15, xmm15
000075038bdd3105  jnz 0x000075038BDD64CF
000075038bdd310b  vmovaps xmm14, [rsp+0x10]
000075038bdd3111  movaps xmm15, xmm14
000075038bdd3115  addpd xmm15, xmm5
000075038bdd311a  vcmppd xmm6, xmm15, xmm15, 0x03
000075038bdd3120  ptest xmm6, xmm6
000075038bdd3125  jnz 0x000075038BDD6610
000075038bdd312b  vmovaps xmm14, [rsp+0x90]
000075038bdd3134  vpermilpd xmm14, xmm14, 0x00
000075038bdd313a  movaps xmm6, xmm9
000075038bdd313e  mulpd xmm6, xmm14
000075038bdd3143  vcmppd xmm5, xmm6, xmm6, 0x03
000075038bdd3148  ptest xmm5, xmm5
000075038bdd314d  jnz 0x000075038BDD6753
000075038bdd3153  vmovaps xmm9, [rsp+0x80]
000075038bdd315c  movaps xmm14, xmm9
000075038bdd3160  addpd xmm14, xmm13
000075038bdd3165  vcmppd xmm5, xmm14, xmm14, 0x03
000075038bdd316b  ptest xmm5, xmm5
000075038bdd3170  jnz 0x000075038BDD6895
000075038bdd3176  vmovaps xmm9, [rsp+0x20]
000075038bdd317c  movaps xmm13, xmm9
000075038bdd3180  addpd xmm13, xmm10
000075038bdd3185  vcmppd xmm5, xmm13, xmm13, 0x03
000075038bdd318b  ptest xmm5, xmm5
000075038bdd3190  jnz 0x000075038BDD69D9
000075038bdd3196  vmovaps [rsp+0x10], xmm12
000075038bdd319c  vmovaps xmm10, [rsp+0x10]
000075038bdd31a2  por xmm12, xmm10
000075038bdd31a7  movaps [r15+0x250], xmm12
000075038bdd31af  vmovaps [rsp+0x10], xmm7
000075038bdd31b5  vmovaps xmm12, [rsp+0x10]
000075038bdd31bb  por xmm7, xmm12
000075038bdd31c0  movaps [r15+0x2A0], xmm7
000075038bdd31c8  vmovaps [rsp+0x10], xmm3
000075038bdd31ce  vmovaps xmm12, [rsp+0x10]
000075038bdd31d4  por xmm3, xmm12
000075038bdd31d9  movaps [r15+0x1D0], xmm3
000075038bdd31e1  lea rax, [r14+0x40]
000075038bdd31e5  movups xmm12, [r13+rax*1]
000075038bdd31eb  movaps [r15+0x2C0], xmm12
000075038bdd31f3  vmovaps xmm10, [rsp+0x90]
000075038bdd31fc  vpermilpd xmm10, xmm10, 0x00
000075038bdd3202  movaps xmm9, xmm8
000075038bdd3206  mulpd xmm9, xmm10
000075038bdd320b  vcmppd xmm5, xmm9, xmm9, 0x03
000075038bdd3211  ptest xmm5, xmm5
000075038bdd3216  jnz 0x000075038BDD6B27
000075038bdd321c  movaps xmm10, xmm1
000075038bdd3220  addpd xmm10, xmm11
000075038bdd3225  vcmppd xmm8, xmm10, xmm10, 0x03
000075038bdd322b  ptest xmm8, xmm8
000075038bdd3231  jnz 0x000075038BDD6C6B
000075038bdd3237  movaps xmm1, xmm15
000075038bdd323b  addpd xmm1, xmm6
000075038bdd323f  vcmppd xmm11, xmm1, xmm1, 0x03
000075038bdd3244  ptest xmm11, xmm11
000075038bdd324a  jnz 0x000075038BDD6DAE
000075038bdd3250  vmovaps xmm15, [rsp+0x90]
000075038bdd3259  vpermilpd xmm15, xmm15, 0x00
000075038bdd325f  movaps xmm11, xmm12
000075038bdd3263  mulpd xmm11, xmm15
000075038bdd3268  vcmppd xmm8, xmm11, xmm11, 0x03
000075038bdd326e  ptest xmm8, xmm8
000075038bdd3274  jnz 0x000075038BDD6EEF
000075038bdd327a  vmovaps xmm15, [rsp+0x90]
000075038bdd3283  vpermilpd xmm15, xmm15, 0x00
000075038bdd3289  vmovaps xmm8, [rsp+0x50]
000075038bdd328f  movaps xmm12, xmm8
000075038bdd3293  mulpd xmm12, xmm15
000075038bdd3298  vcmppd xmm6, xmm12, xmm12, 0x03
000075038bdd329e  ptest xmm6, xmm6
000075038bdd32a3  jnz 0x000075038BDD7033
000075038bdd32a9  vmovaps xmm15, [rsp+0x30]
000075038bdd32af  vpermilpd xmm15, xmm15, 0x00
000075038bdd32b5  movaps xmm8, xmm7
000075038bdd32b9  mulpd xmm8, xmm15
000075038bdd32be  vcmppd xmm6, xmm8, xmm8, 0x03
000075038bdd32c4  ptest xmm6, xmm6
000075038bdd32c9  jnz 0x000075038BDD7177
000075038bdd32cf  movaps xmm15, xmm14
000075038bdd32d3  addpd xmm15, xmm9
000075038bdd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
000075038bdd32de  ptest xmm7, xmm7
000075038bdd32e3  jnz 0x000075038BDD72BA
000075038bdd32e9  vmovaps xmm14, [rsp+0x30]
000075038bdd32ef  vpermilpd xmm14, xmm14, 0x00
000075038bdd32f5  vmovaps xmm7, [rsp+0xF0]
000075038bdd32fe  movaps xmm9, xmm7
000075038bdd3302  mulpd xmm9, xmm14
000075038bdd3307  vcmppd xmm6, xmm9, xmm9, 0x03
000075038bdd330d  ptest xmm6, xmm6
000075038bdd3312  jnz 0x000075038BDD73FE
000075038bdd3318  movaps xmm14, xmm13
000075038bdd331c  addpd xmm14, xmm11
000075038bdd3321  vcmppd xmm7, xmm14, xmm14, 0x03
000075038bdd3327  ptest xmm7, xmm7
000075038bdd332c  jnz 0x000075038BDD7541
000075038bdd3332  vmovaps xmm13, [rsp+0x30]
000075038bdd3338  vpermilpd xmm13, xmm13, 0x00
000075038bdd333e  vmovaps xmm7, [rsp+0x60]
000075038bdd3344  movaps xmm11, xmm7
000075038bdd3348  mulpd xmm11, xmm13
000075038bdd334d  vcmppd xmm6, xmm11, xmm11, 0x03
000075038bdd3353  ptest xmm6, xmm6
000075038bdd3358  jnz 0x000075038BDD7685
000075038bdd335e  movaps xmm13, xmm10
000075038bdd3362  addpd xmm13, xmm12
000075038bdd3367  vcmppd xmm7, xmm13, xmm13, 0x03
000075038bdd336d  ptest xmm7, xmm7
000075038bdd3372  jnz 0x000075038BDD77C8
000075038bdd3378  vmovaps xmm12, [rsp+0x30]
000075038bdd337e  vpermilpd xmm12, xmm12, 0x00
000075038bdd3384  vmovaps xmm7, [rsp+0x70]
000075038bdd338a  movaps xmm10, xmm7
000075038bdd338e  mulpd xmm10, xmm12
000075038bdd3393  vcmppd xmm6, xmm10, xmm10, 0x03
000075038bdd3399  ptest xmm6, xmm6
000075038bdd339e  jnz 0x000075038BDD790C
000075038bdd33a4  movaps xmm12, xmm1
000075038bdd33a8  addpd xmm12, xmm8
000075038bdd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
000075038bdd33b3  ptest xmm7, xmm7
000075038bdd33b8  jnz 0x000075038BDD7A4F
000075038bdd33be  lea rax, [r14+0x70]
000075038bdd33c2  movups xmm1, [r13+rax*1]
000075038bdd33c8  movaps [r15+0x240], xmm1
000075038bdd33d0  movaps xmm8, xmm15
000075038bdd33d4  addpd xmm8, xmm9
000075038bdd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
000075038bdd33df  ptest xmm7, xmm7
000075038bdd33e4  jnz 0x000075038BDD7B9C
000075038bdd33ea  movaps [r15+0x170], xmm8
000075038bdd33f2  vmovaps xmm15, [rsp+0x40]
000075038bdd33f8  vpermilpd xmm15, xmm15, 0x00
000075038bdd33fe  movaps xmm9, xmm1
000075038bdd3402  mulpd xmm9, xmm15
000075038bdd3407  vcmppd xmm7, xmm9, xmm9, 0x03
000075038bdd340d  ptest xmm7, xmm7
000075038bdd3412  jnz 0x000075038BDD7CE0
000075038bdd3418  vmovaps xmm1, [rsp+0x40]
000075038bdd341e  vpermilpd xmm1, xmm1, 0x00
000075038bdd3424  movaps xmm15, xmm4
000075038bdd3428  mulpd xmm15, xmm1
000075038bdd342d  vcmppd xmm7, xmm15, xmm15, 0x03
000075038bdd3433  ptest xmm7, xmm7
000075038bdd3438  jnz 0x000075038BDD7E23
000075038bdd343e  movaps [r15+0x180], xmm15
000075038bdd3446  movaps xmm1, xmm14
000075038bdd344a  addpd xmm1, xmm11
000075038bdd344f  vcmppd xmm7, xmm1, xmm1, 0x03
000075038bdd3454  ptest xmm7, xmm7
000075038bdd3459  jnz 0x000075038BDD7F65
000075038bdd345f  movaps [r15+0x210], xmm1
000075038bdd3467  movups xmm14, [r13+r14*1]
000075038bdd346d  lea rax, [r14+0x10]
000075038bdd3471  movups xmm11, [r13+rax*1]
000075038bdd3477  movaps [r15+0x230], xmm11
000075038bdd347f  movaps xmm7, xmm13
000075038bdd3483  addpd xmm7, xmm10
000075038bdd3488  vcmppd xmm6, xmm7, xmm7, 0x03
000075038bdd348d  ptest xmm6, xmm6
000075038bdd3492  jnz 0x000075038BDD80BB
000075038bdd3498  movaps [r15+0x130], xmm7
000075038bdd34a0  vmovaps xmm13, [rsp+0x40]
000075038bdd34a6  vpermilpd xmm13, xmm13, 0x00
000075038bdd34ac  movaps xmm10, xmm11
000075038bdd34b0  mulpd xmm10, xmm13
000075038bdd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
000075038bdd34bb  ptest xmm6, xmm6
000075038bdd34c0  jnz 0x000075038BDD81FD
000075038bdd34c6  movaps [r15+0x220], xmm10
000075038bdd34ce  vmovaps xmm13, [rsp+0x40]
000075038bdd34d4  vpermilpd xmm13, xmm13, 0x00
000075038bdd34da  movaps xmm11, xmm14
000075038bdd34de  mulpd xmm11, xmm13
000075038bdd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
000075038bdd34e9  ptest xmm6, xmm6
000075038bdd34ee  jnz 0x000075038BDD8341
000075038bdd34f4  movaps xmm14, xmm12
000075038bdd34f8  addpd xmm14, xmm9
000075038bdd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
000075038bdd3503  ptest xmm13, xmm13
000075038bdd3509  jnz 0x000075038BDD8485
000075038bdd350f  movaps [r15+0x140], xmm14
000075038bdd3517  movaps xmm13, xmm8
000075038bdd351b  addpd xmm13, xmm15
000075038bdd3520  vcmppd xmm12, xmm13, xmm13, 0x03
000075038bdd3526  ptest xmm12, xmm12
000075038bdd352c  jnz 0x000075038BDD85C9
000075038bdd3532  movaps [r15+0x150], xmm13
000075038bdd353a  movaps xmm15, xmm1
000075038bdd353e  addpd xmm15, xmm10
000075038bdd3543  vcmppd xmm12, xmm15, xmm15, 0x03
000075038bdd3549  ptest xmm12, xmm12
000075038bdd354f  jnz 0x000075038BDD870D
000075038bdd3555  movaps [r15+0x160], xmm15
000075038bdd355d  movaps xmm1, xmm7
000075038bdd3560  addpd xmm1, xmm11
000075038bdd3565  vcmppd xmm12, xmm1, xmm1, 0x03
000075038bdd356a  ptest xmm12, xmm12
000075038bdd3570  jnz 0x000075038BDD8850
000075038bdd3576  movaps [r15+0x120], xmm1
000075038bdd357e  mov eax, 0x432200
000075038bdd3583  movups [r13+rax*1], xmm14
000075038bdd3589  mov eax, 0x432210
000075038bdd358e  movups [r13+rax*1], xmm13
000075038bdd3594  mov eax, 0x432220
000075038bdd3599  movups [r13+rax*1], xmm15
000075038bdd359f  mov eax, 0x432230
000075038bdd35a4  movups [r13+rax*1], xmm1
000075038bdd35aa  mov eax, [r15+0x108]
000075038bdd35b1  sahf
000075038bdd35b2  jnz 0x000075038BDD35E4
000075038bdd35b4  cmp dword ptr [r15+0x318], 0x00
000075038bdd35bc  jz 0x000075038BDDEAE0
000075038bdd35c2  nop [rax+rax*1], ax
000075038bdd35cb  nop [rax+rax*1], eax
000075038bdd35d3  mov eax, 0x4106D0
000075038bdd35d8  mov [r15+0x100], rax
000075038bdd35df  jmp 0x000075038BBFE110
000075038bdd35e4  cmp dword ptr [r15+0x318], 0x00
000075038bdd35ec  jz 0x000075038BDD89C0
000075038bdd35f2  nop [rax+rax*1], ax
000075038bdd35fb  nop [rax+rax*1], eax
000075038bdd3603  mov eax, 0x410504
000075038bdd3608  mov [r15+0x100], rax
000075038bdd360f  jmp 0x000075038BBFE110
000075038bdd3614  int3
000075038bdd3615  call 0x000075038BCD64F0
000075038bdd361a  jmp 0x000075038BDD2311
000075038bdd361f  call 0x000075038BCE5820
000075038bdd3624  jmp 0x000075038BDD231E
000075038bdd3629  call 0x000075038BCE3320
000075038bdd362e  jmp 0x000075038BDD2332
000075038bdd3633  call 0x000075038BCE20A0
000075038bdd3638  jmp 0x000075038BDD233C
000075038bdd363d  call 0x000075038BC09D70
000075038bdd3642  jmp 0x000075038BDD234A
000075038bdd3647  call 0x000075038BCDFBC0
000075038bdd364c  jmp 0x000075038BDD2354
000075038bdd3651  call 0x000075038BCC4740
000075038bdd3656  jmp 0x000075038BDD2368
000075038bdd365b  call 0x000075038BCB5400
000075038bdd3660  jmp 0x000075038BDD2375
000075038bdd3665  call 0x000075038BCB52F0
000075038bdd366a  jmp 0x000075038BDD2382
000075038bdd366f  call 0x000075038BCC4620
000075038bdd3674  jmp 0x000075038BDD238F
000075038bdd3679  call 0x000075038BCBD750
000075038bdd367e  jmp 0x000075038BDD239C
000075038bdd3683  call 0x000075038BCBC4E0
000075038bdd3688  jmp 0x000075038BDD23A9
000075038bdd368d  call 0x000075038BCBB270
000075038bdd3692  jmp 0x000075038BDD23B6
000075038bdd3697  call 0x000075038BCBA000
000075038bdd369c  jmp 0x000075038BDD23C3
000075038bdd36a1  call 0x000075038BCC4740
000075038bdd36a6  jmp 0x000075038BDD23D0
000075038bdd36ab  call 0x000075038BCB5400
000075038bdd36b0  jmp 0x000075038BDD23DD
000075038bdd36b5  call 0x000075038BCB52F0
000075038bdd36ba  jmp 0x000075038BDD23EA
000075038bdd36bf  call 0x000075038BCC4620
000075038bdd36c4  jmp 0x000075038BDD23F7
000075038bdd36c9  call 0x000075038BCB8D90
000075038bdd36ce  jmp 0x000075038BDD2404
000075038bdd36d3  call 0x000075038BCB8A20
000075038bdd36d8  jmp 0x000075038BDD2411
000075038bdd36dd  call 0x000075038BCB77B0
000075038bdd36e2  jmp 0x000075038BDD241B
000075038bdd36e7  call 0x000075038BCB6550
000075038bdd36ec  jmp 0x000075038BDD2425
000075038bdd36f1  call 0x000075038BCB5400
000075038bdd36f6  jmp 0x000075038BDD2437
000075038bdd36fb  call 0x000075038BCC0FC0
000075038bdd3700  jmp 0x000075038BDD2441
000075038bdd3705  call 0x000075038BCB52F0
000075038bdd370a  jmp 0x000075038BDD244B
000075038bdd370f  call 0x000075038BCC0EA0
000075038bdd3714  jmp 0x000075038BDD2455
000075038bdd3719  call 0x000075038BCBFD50
000075038bdd371e  jmp 0x000075038BDD245F
000075038bdd3723  call 0x000075038BCB8EA0
000075038bdd3728  jmp 0x000075038BDD2469
000075038bdd372d  call 0x000075038BCBFC30
000075038bdd3732  jmp 0x000075038BDD2476
000075038bdd3737  call 0x000075038BCB8D90
000075038bdd373c  jmp 0x000075038BDD2483
000075038bdd3741  call 0x000075038BCB52F0
000075038bdd3746  jmp 0x000075038BDD2496
000075038bdd374b  call 0x000075038BCB52F0
000075038bdd3750  jmp 0x000075038BDD24A9
000075038bdd3755  call 0x000075038BCC0FC0
000075038bdd375a  jmp 0x000075038BDD24B6
000075038bdd375f  call 0x000075038BCC0FC0
000075038bdd3764  jmp 0x000075038BDD24C9
000075038bdd3769  call 0x000075038BCC0EA0
000075038bdd376e  jmp 0x000075038BDD24D6
000075038bdd3773  call 0x000075038BCB52F0
000075038bdd3778  jmp 0x000075038BDD24E9
000075038bdd377d  call 0x000075038BCB52F0
000075038bdd3782  jmp 0x000075038BDD24FC
000075038bdd3787  call 0x000075038BCB52F0
000075038bdd378c  jmp 0x000075038BDD250F
000075038bdd3791  call 0x000075038BCB52F0
000075038bdd3796  jmp 0x000075038BDD252A
000075038bdd379b  call 0x000075038BCB52F0
000075038bdd37a0  jmp 0x000075038BDD253D
000075038bdd37a5  call 0x000075038BCB5400
000075038bdd37aa  jmp 0x000075038BDD257E
000075038bdd37af  call 0x000075038BCC0FC0
000075038bdd37b4  jmp 0x000075038BDD258B
000075038bdd37b9  call 0x000075038BCB52F0
000075038bdd37be  jmp 0x000075038BDD2598
000075038bdd37c3  call 0x000075038BCC0EA0
000075038bdd37c8  jmp 0x000075038BDD25A5
000075038bdd37cd  call 0x000075038BBFF540
000075038bdd37d2  jmp 0x000075038BDD25C3
000075038bdd37d7  call 0x000075038BC08C20
000075038bdd37dc  jmp 0x000075038BDD25CD
000075038bdd37e1  call 0x000075038BCE21C0
000075038bdd37e6  jmp 0x000075038BDD25D3
000075038bdd37eb  call 0x000075038BBFF540
000075038bdd37f0  jmp 0x000075038BDD25E3
000075038bdd37f5  call 0x000075038BCC0370
000075038bdd37fa  jmp 0x000075038BDD2611
000075038bdd37ff  call 0x000075038BCBF100
000075038bdd3804  jmp 0x000075038BDD261A
000075038bdd3809  call 0x000075038BCC0370
000075038bdd380e  jmp 0x000075038BDD2674
000075038bdd3813  call 0x000075038BCBF100
000075038bdd3818  jmp 0x000075038BDD267D
000075038bdd381d  call 0x000075038BCC0370
000075038bdd3822  jmp 0x000075038BDD26C6
000075038bdd3827  call 0x000075038BCBF100
000075038bdd382c  jmp 0x000075038BDD26CF
000075038bdd3831  call 0x000075038BC0B720
000075038bdd3836  jmp 0x000075038BDD2714
000075038bdd383b  call 0x000075038BCB47C0
000075038bdd3840  jmp 0x000075038BDD2727
000075038bdd3845  call 0x000075038BC08B00
000075038bdd384a  jmp 0x000075038BDD273E
000075038bdd384f  call 0x000075038BBFF430
000075038bdd3854  jmp 0x000075038BDD2751
000075038bdd3859  call 0x000075038BBFF430
000075038bdd385e  jmp 0x000075038BDD2764
000075038bdd3863  sub rsp, 0x08
000075038bdd3867  push rax
000075038bdd3868  push rcx
000075038bdd3869  push rdx
000075038bdd386a  push rdi
000075038bdd386b  push rsi
000075038bdd386c  push r8
000075038bdd386e  push r9
000075038bdd3870  push r10
000075038bdd3872  push r11
000075038bdd3874  sub rsp, 0xF0
000075038bdd387b  vmovaps [rsp], xmm0
000075038bdd3880  vmovaps [rsp+0x10], xmm2
000075038bdd3886  vmovaps [rsp+0x20], xmm3
000075038bdd388c  vmovaps [rsp+0x30], xmm4
000075038bdd3892  vmovaps [rsp+0x40], xmm5
000075038bdd3898  vmovaps [rsp+0x50], xmm6
000075038bdd389e  vmovaps [rsp+0x60], xmm7
000075038bdd38a4  vmovaps [rsp+0x70], xmm8
000075038bdd38aa  vmovaps [rsp+0x80], xmm9
000075038bdd38b3  vmovaps [rsp+0x90], xmm10
000075038bdd38bc  vmovaps [rsp+0xA0], xmm11
000075038bdd38c5  vmovaps [rsp+0xB0], xmm12
000075038bdd38ce  vmovaps [rsp+0xC0], xmm13
000075038bdd38d7  vmovaps [rsp+0xD0], xmm14
000075038bdd38e0  vmovaps [rsp+0xE0], xmm15
000075038bdd38e9  sub rsp, 0x30
000075038bdd38ed  movaps [rsp], xmm1
000075038bdd38f1  movaps [rsp+0x10], xmm12
000075038bdd38f7  movaps [rsp+0x20], xmm15
000075038bdd38fd  lea rdi, [rsp]
000075038bdd3901  mov esi, 0x00
000075038bdd3906  mov rax, 0x56ADB4492530
000075038bdd3910  call rax
000075038bdd3912  movaps xmm1, [rsp]
000075038bdd3916  add rsp, 0x30
000075038bdd391a  vmovaps xmm0, [rsp]
000075038bdd391f  vmovaps xmm2, [rsp+0x10]
000075038bdd3925  vmovaps xmm3, [rsp+0x20]
000075038bdd392b  vmovaps xmm4, [rsp+0x30]
000075038bdd3931  vmovaps xmm5, [rsp+0x40]
000075038bdd3937  vmovaps xmm6, [rsp+0x50]
000075038bdd393d  vmovaps xmm7, [rsp+0x60]
000075038bdd3943  vmovaps xmm8, [rsp+0x70]
000075038bdd3949  vmovaps xmm9, [rsp+0x80]
000075038bdd3952  vmovaps xmm10, [rsp+0x90]
000075038bdd395b  vmovaps xmm11, [rsp+0xA0]
000075038bdd3964  vmovaps xmm12, [rsp+0xB0]
000075038bdd396d  vmovaps xmm13, [rsp+0xC0]
000075038bdd3976  vmovaps xmm14, [rsp+0xD0]
000075038bdd397f  vmovaps xmm15, [rsp+0xE0]
000075038bdd3988  add rsp, 0xF0
000075038bdd398f  pop r11
000075038bdd3991  pop r10
000075038bdd3993  pop r9
000075038bdd3995  pop r8
000075038bdd3997  pop rsi
000075038bdd3998  pop rdi
000075038bdd3999  pop rdx
000075038bdd399a  pop rcx
000075038bdd399b  pop rax
000075038bdd399c  add rsp, 0x08
000075038bdd39a0  jmp 0x000075038BDD27B2
000075038bdd39a5  sub rsp, 0x08
000075038bdd39a9  push rax
000075038bdd39aa  push rcx
000075038bdd39ab  push rdx
000075038bdd39ac  push rdi
000075038bdd39ad  push rsi
000075038bdd39ae  push r8
000075038bdd39b0  push r9
000075038bdd39b2  push r10
000075038bdd39b4  push r11
000075038bdd39b6  sub rsp, 0xF0
000075038bdd39bd  vmovaps [rsp], xmm0
000075038bdd39c2  vmovaps [rsp+0x10], xmm1
000075038bdd39c8  vmovaps [rsp+0x20], xmm2
000075038bdd39ce  vmovaps [rsp+0x30], xmm3
000075038bdd39d4  vmovaps [rsp+0x40], xmm4
000075038bdd39da  vmovaps [rsp+0x50], xmm5
000075038bdd39e0  vmovaps [rsp+0x60], xmm6
000075038bdd39e6  vmovaps [rsp+0x70], xmm7
000075038bdd39ec  vmovaps [rsp+0x80], xmm8
000075038bdd39f5  vmovaps [rsp+0x90], xmm9
000075038bdd39fe  vmovaps [rsp+0xA0], xmm10
000075038bdd3a07  vmovaps [rsp+0xB0], xmm11
000075038bdd3a10  vmovaps [rsp+0xC0], xmm12
000075038bdd3a19  vmovaps [rsp+0xD0], xmm13
000075038bdd3a22  vmovaps [rsp+0xE0], xmm15
000075038bdd3a2b  sub rsp, 0x30
000075038bdd3a2f  movaps [rsp], xmm14
000075038bdd3a34  movaps [rsp+0x10], xmm1
000075038bdd3a39  movaps [rsp+0x20], xmm15
000075038bdd3a3f  lea rdi, [rsp]
000075038bdd3a43  mov esi, 0x00
000075038bdd3a48  mov rax, 0x56ADB4492530
000075038bdd3a52  call rax
000075038bdd3a54  movaps xmm14, [rsp]
000075038bdd3a59  add rsp, 0x30
000075038bdd3a5d  vmovaps xmm0, [rsp]
000075038bdd3a62  vmovaps xmm1, [rsp+0x10]
000075038bdd3a68  vmovaps xmm2, [rsp+0x20]
000075038bdd3a6e  vmovaps xmm3, [rsp+0x30]
000075038bdd3a74  vmovaps xmm4, [rsp+0x40]
000075038bdd3a7a  vmovaps xmm5, [rsp+0x50]
000075038bdd3a80  vmovaps xmm6, [rsp+0x60]
000075038bdd3a86  vmovaps xmm7, [rsp+0x70]
000075038bdd3a8c  vmovaps xmm8, [rsp+0x80]
000075038bdd3a95  vmovaps xmm9, [rsp+0x90]
000075038bdd3a9e  vmovaps xmm10, [rsp+0xA0]
000075038bdd3aa7  vmovaps xmm11, [rsp+0xB0]
000075038bdd3ab0  vmovaps xmm12, [rsp+0xC0]
000075038bdd3ab9  vmovaps xmm13, [rsp+0xD0]
000075038bdd3ac2  vmovaps xmm15, [rsp+0xE0]
000075038bdd3acb  add rsp, 0xF0
000075038bdd3ad2  pop r11
000075038bdd3ad4  pop r10
000075038bdd3ad6  pop r9
000075038bdd3ad8  pop r8
000075038bdd3ada  pop rsi
000075038bdd3adb  pop rdi
000075038bdd3adc  pop rdx
000075038bdd3add  pop rcx
000075038bdd3ade  pop rax
000075038bdd3adf  add rsp, 0x08
000075038bdd3ae3  jmp 0x000075038BDD2800
000075038bdd3ae8  sub rsp, 0x08
000075038bdd3aec  push rax
000075038bdd3aed  push rcx
000075038bdd3aee  push rdx
000075038bdd3aef  push rdi
000075038bdd3af0  push rsi
000075038bdd3af1  push r8
000075038bdd3af3  push r9
000075038bdd3af5  push r10
000075038bdd3af7  push r11
000075038bdd3af9  sub rsp, 0xF0
000075038bdd3b00  vmovaps [rsp], xmm0
000075038bdd3b05  vmovaps [rsp+0x10], xmm1
000075038bdd3b0b  vmovaps [rsp+0x20], xmm2
000075038bdd3b11  vmovaps [rsp+0x30], xmm3
000075038bdd3b17  vmovaps [rsp+0x40], xmm4
000075038bdd3b1d  vmovaps [rsp+0x50], xmm5
000075038bdd3b23  vmovaps [rsp+0x60], xmm6
000075038bdd3b29  vmovaps [rsp+0x70], xmm7
000075038bdd3b2f  vmovaps [rsp+0x80], xmm8
000075038bdd3b38  vmovaps [rsp+0x90], xmm9
000075038bdd3b41  vmovaps [rsp+0xA0], xmm10
000075038bdd3b4a  vmovaps [rsp+0xB0], xmm11
000075038bdd3b53  vmovaps [rsp+0xC0], xmm12
000075038bdd3b5c  vmovaps [rsp+0xD0], xmm13
000075038bdd3b65  vmovaps [rsp+0xE0], xmm14
000075038bdd3b6e  sub rsp, 0x30
000075038bdd3b72  movaps [rsp], xmm15
000075038bdd3b77  movaps [rsp+0x10], xmm12
000075038bdd3b7d  movaps [rsp+0x20], xmm13
000075038bdd3b83  lea rdi, [rsp]
000075038bdd3b87  mov esi, 0x00
000075038bdd3b8c  mov rax, 0x56ADB4492530
000075038bdd3b96  call rax
000075038bdd3b98  movaps xmm15, [rsp]
000075038bdd3b9d  add rsp, 0x30
000075038bdd3ba1  vmovaps xmm0, [rsp]
000075038bdd3ba6  vmovaps xmm1, [rsp+0x10]
000075038bdd3bac  vmovaps xmm2, [rsp+0x20]
000075038bdd3bb2  vmovaps xmm3, [rsp+0x30]
000075038bdd3bb8  vmovaps xmm4, [rsp+0x40]
000075038bdd3bbe  vmovaps xmm5, [rsp+0x50]
000075038bdd3bc4  vmovaps xmm6, [rsp+0x60]
000075038bdd3bca  vmovaps xmm7, [rsp+0x70]
000075038bdd3bd0  vmovaps xmm8, [rsp+0x80]
000075038bdd3bd9  vmovaps xmm9, [rsp+0x90]
000075038bdd3be2  vmovaps xmm10, [rsp+0xA0]
000075038bdd3beb  vmovaps xmm11, [rsp+0xB0]
000075038bdd3bf4  vmovaps xmm12, [rsp+0xC0]
000075038bdd3bfd  vmovaps xmm13, [rsp+0xD0]
000075038bdd3c06  vmovaps xmm14, [rsp+0xE0]
000075038bdd3c0f  add rsp, 0xF0
000075038bdd3c16  pop r11
000075038bdd3c18  pop r10
000075038bdd3c1a  pop r9
000075038bdd3c1c  pop r8
000075038bdd3c1e  pop rsi
000075038bdd3c1f  pop rdi
000075038bdd3c20  pop rdx
000075038bdd3c21  pop rcx
000075038bdd3c22  pop rax
000075038bdd3c23  add rsp, 0x08
000075038bdd3c27  jmp 0x000075038BDD2835
000075038bdd3c2c  sub rsp, 0x08
000075038bdd3c30  push rax
000075038bdd3c31  push rcx
000075038bdd3c32  push rdx
000075038bdd3c33  push rdi
000075038bdd3c34  push rsi
000075038bdd3c35  push r8
000075038bdd3c37  push r9
000075038bdd3c39  push r10
000075038bdd3c3b  push r11
000075038bdd3c3d  sub rsp, 0xF0
000075038bdd3c44  vmovaps [rsp], xmm0
000075038bdd3c49  vmovaps [rsp+0x10], xmm2
000075038bdd3c4f  vmovaps [rsp+0x20], xmm3
000075038bdd3c55  vmovaps [rsp+0x30], xmm4
000075038bdd3c5b  vmovaps [rsp+0x40], xmm5
000075038bdd3c61  vmovaps [rsp+0x50], xmm6
000075038bdd3c67  vmovaps [rsp+0x60], xmm7
000075038bdd3c6d  vmovaps [rsp+0x70], xmm8
000075038bdd3c73  vmovaps [rsp+0x80], xmm9
000075038bdd3c7c  vmovaps [rsp+0x90], xmm10
000075038bdd3c85  vmovaps [rsp+0xA0], xmm11
000075038bdd3c8e  vmovaps [rsp+0xB0], xmm12
000075038bdd3c97  vmovaps [rsp+0xC0], xmm13
000075038bdd3ca0  vmovaps [rsp+0xD0], xmm14
000075038bdd3ca9  vmovaps [rsp+0xE0], xmm15
000075038bdd3cb2  sub rsp, 0x30
000075038bdd3cb6  movaps [rsp], xmm1
000075038bdd3cba  movaps [rsp+0x10], xmm12
000075038bdd3cc0  movaps [rsp+0x20], xmm10
000075038bdd3cc6  lea rdi, [rsp]
000075038bdd3cca  mov esi, 0x00
000075038bdd3ccf  mov rax, 0x56ADB4492530
000075038bdd3cd9  call rax
000075038bdd3cdb  movaps xmm1, [rsp]
000075038bdd3cdf  add rsp, 0x30
000075038bdd3ce3  vmovaps xmm0, [rsp]
000075038bdd3ce8  vmovaps xmm2, [rsp+0x10]
000075038bdd3cee  vmovaps xmm3, [rsp+0x20]
000075038bdd3cf4  vmovaps xmm4, [rsp+0x30]
000075038bdd3cfa  vmovaps xmm5, [rsp+0x40]
000075038bdd3d00  vmovaps xmm6, [rsp+0x50]
000075038bdd3d06  vmovaps xmm7, [rsp+0x60]
000075038bdd3d0c  vmovaps xmm8, [rsp+0x70]
000075038bdd3d12  vmovaps xmm9, [rsp+0x80]
000075038bdd3d1b  vmovaps xmm10, [rsp+0x90]
000075038bdd3d24  vmovaps xmm11, [rsp+0xA0]
000075038bdd3d2d  vmovaps xmm12, [rsp+0xB0]
000075038bdd3d36  vmovaps xmm13, [rsp+0xC0]
000075038bdd3d3f  vmovaps xmm14, [rsp+0xD0]
000075038bdd3d48  vmovaps xmm15, [rsp+0xE0]
000075038bdd3d51  add rsp, 0xF0
000075038bdd3d58  pop r11
000075038bdd3d5a  pop r10
000075038bdd3d5c  pop r9
000075038bdd3d5e  pop r8
000075038bdd3d60  pop rsi
000075038bdd3d61  pop rdi
000075038bdd3d62  pop rdx
000075038bdd3d63  pop rcx
000075038bdd3d64  pop rax
000075038bdd3d65  add rsp, 0x08
000075038bdd3d69  jmp 0x000075038BDD284F
000075038bdd3d6e  sub rsp, 0x08
000075038bdd3d72  push rax
000075038bdd3d73  push rcx
000075038bdd3d74  push rdx
000075038bdd3d75  push rdi
000075038bdd3d76  push rsi
000075038bdd3d77  push r8
000075038bdd3d79  push r9
000075038bdd3d7b  push r10
000075038bdd3d7d  push r11
000075038bdd3d7f  sub rsp, 0xF0
000075038bdd3d86  vmovaps [rsp], xmm0
000075038bdd3d8b  vmovaps [rsp+0x10], xmm1
000075038bdd3d91  vmovaps [rsp+0x20], xmm2
000075038bdd3d97  vmovaps [rsp+0x30], xmm3
000075038bdd3d9d  vmovaps [rsp+0x40], xmm4
000075038bdd3da3  vmovaps [rsp+0x50], xmm5
000075038bdd3da9  vmovaps [rsp+0x60], xmm6
000075038bdd3daf  vmovaps [rsp+0x70], xmm7
000075038bdd3db5  vmovaps [rsp+0x80], xmm8
000075038bdd3dbe  vmovaps [rsp+0x90], xmm9
000075038bdd3dc7  vmovaps [rsp+0xA0], xmm10
000075038bdd3dd0  vmovaps [rsp+0xB0], xmm11
000075038bdd3dd9  vmovaps [rsp+0xC0], xmm12
000075038bdd3de2  vmovaps [rsp+0xD0], xmm14
000075038bdd3deb  vmovaps [rsp+0xE0], xmm15
000075038bdd3df4  sub rsp, 0x30
000075038bdd3df8  movaps [rsp], xmm13
000075038bdd3dfd  movaps [rsp+0x10], xmm12
000075038bdd3e03  movaps [rsp+0x20], xmm2
000075038bdd3e08  lea rdi, [rsp]
000075038bdd3e0c  mov esi, 0x00
000075038bdd3e11  mov rax, 0x56ADB4492530
000075038bdd3e1b  call rax
000075038bdd3e1d  movaps xmm13, [rsp]
000075038bdd3e22  add rsp, 0x30
000075038bdd3e26  vmovaps xmm0, [rsp]
000075038bdd3e2b  vmovaps xmm1, [rsp+0x10]
000075038bdd3e31  vmovaps xmm2, [rsp+0x20]
000075038bdd3e37  vmovaps xmm3, [rsp+0x30]
000075038bdd3e3d  vmovaps xmm4, [rsp+0x40]
000075038bdd3e43  vmovaps xmm5, [rsp+0x50]
000075038bdd3e49  vmovaps xmm6, [rsp+0x60]
000075038bdd3e4f  vmovaps xmm7, [rsp+0x70]
000075038bdd3e55  vmovaps xmm8, [rsp+0x80]
000075038bdd3e5e  vmovaps xmm9, [rsp+0x90]
000075038bdd3e67  vmovaps xmm10, [rsp+0xA0]
000075038bdd3e70  vmovaps xmm11, [rsp+0xB0]
000075038bdd3e79  vmovaps xmm12, [rsp+0xC0]
000075038bdd3e82  vmovaps xmm14, [rsp+0xD0]
000075038bdd3e8b  vmovaps xmm15, [rsp+0xE0]
000075038bdd3e94  add rsp, 0xF0
000075038bdd3e9b  pop r11
000075038bdd3e9d  pop r10
000075038bdd3e9f  pop r9
000075038bdd3ea1  pop r8
000075038bdd3ea3  pop rsi
000075038bdd3ea4  pop rdi
000075038bdd3ea5  pop rdx
000075038bdd3ea6  pop rcx
000075038bdd3ea7  pop rax
000075038bdd3ea8  add rsp, 0x08
000075038bdd3eac  jmp 0x000075038BDD286A
000075038bdd3eb1  sub rsp, 0x08
000075038bdd3eb5  push rax
000075038bdd3eb6  push rcx
000075038bdd3eb7  push rdx
000075038bdd3eb8  push rdi
000075038bdd3eb9  push rsi
000075038bdd3eba  push r8
000075038bdd3ebc  push r9
000075038bdd3ebe  push r10
000075038bdd3ec0  push r11
000075038bdd3ec2  sub rsp, 0xF0
000075038bdd3ec9  vmovaps [rsp], xmm0
000075038bdd3ece  vmovaps [rsp+0x10], xmm2
000075038bdd3ed4  vmovaps [rsp+0x20], xmm3
000075038bdd3eda  vmovaps [rsp+0x30], xmm4
000075038bdd3ee0  vmovaps [rsp+0x40], xmm5
000075038bdd3ee6  vmovaps [rsp+0x50], xmm6
000075038bdd3eec  vmovaps [rsp+0x60], xmm7
000075038bdd3ef2  vmovaps [rsp+0x70], xmm8
000075038bdd3ef8  vmovaps [rsp+0x80], xmm9
000075038bdd3f01  vmovaps [rsp+0x90], xmm10
000075038bdd3f0a  vmovaps [rsp+0xA0], xmm11
000075038bdd3f13  vmovaps [rsp+0xB0], xmm12
000075038bdd3f1c  vmovaps [rsp+0xC0], xmm13
000075038bdd3f25  vmovaps [rsp+0xD0], xmm14
000075038bdd3f2e  vmovaps [rsp+0xE0], xmm15
000075038bdd3f37  sub rsp, 0x30
000075038bdd3f3b  movaps [rsp], xmm1
000075038bdd3f3f  movaps [rsp+0x10], xmm10
000075038bdd3f45  movaps [rsp+0x20], xmm2
000075038bdd3f4a  lea rdi, [rsp]
000075038bdd3f4e  mov esi, 0x00
000075038bdd3f53  mov rax, 0x56ADB4492530
000075038bdd3f5d  call rax
000075038bdd3f5f  movaps xmm1, [rsp]
000075038bdd3f63  add rsp, 0x30
000075038bdd3f67  vmovaps xmm0, [rsp]
000075038bdd3f6c  vmovaps xmm2, [rsp+0x10]
000075038bdd3f72  vmovaps xmm3, [rsp+0x20]
000075038bdd3f78  vmovaps xmm4, [rsp+0x30]
000075038bdd3f7e  vmovaps xmm5, [rsp+0x40]
000075038bdd3f84  vmovaps xmm6, [rsp+0x50]
000075038bdd3f8a  vmovaps xmm7, [rsp+0x60]
000075038bdd3f90  vmovaps xmm8, [rsp+0x70]
000075038bdd3f96  vmovaps xmm9, [rsp+0x80]
000075038bdd3f9f  vmovaps xmm10, [rsp+0x90]
000075038bdd3fa8  vmovaps xmm11, [rsp+0xA0]
000075038bdd3fb1  vmovaps xmm12, [rsp+0xB0]
000075038bdd3fba  vmovaps xmm13, [rsp+0xC0]
000075038bdd3fc3  vmovaps xmm14, [rsp+0xD0]
000075038bdd3fcc  vmovaps xmm15, [rsp+0xE0]
000075038bdd3fd5  add rsp, 0xF0
000075038bdd3fdc  pop r11
000075038bdd3fde  pop r10
000075038bdd3fe0  pop r9
000075038bdd3fe2  pop r8
000075038bdd3fe4  pop rsi
000075038bdd3fe5  pop rdi
000075038bdd3fe6  pop rdx
000075038bdd3fe7  pop rcx
000075038bdd3fe8  pop rax
000075038bdd3fe9  add rsp, 0x08
000075038bdd3fed  jmp 0x000075038BDD28D2
000075038bdd3ff2  sub rsp, 0x08
000075038bdd3ff6  push rax
000075038bdd3ff7  push rcx
000075038bdd3ff8  push rdx
000075038bdd3ff9  push rdi
000075038bdd3ffa  push rsi
000075038bdd3ffb  push r8
000075038bdd3ffd  push r9
000075038bdd3fff  push r10
000075038bdd4001  push r11
000075038bdd4003  sub rsp, 0xF0
000075038bdd400a  vmovaps [rsp], xmm0
000075038bdd400f  vmovaps [rsp+0x10], xmm1
000075038bdd4015  vmovaps [rsp+0x20], xmm2
000075038bdd401b  vmovaps [rsp+0x30], xmm3
000075038bdd4021  vmovaps [rsp+0x40], xmm4
000075038bdd4027  vmovaps [rsp+0x50], xmm5
000075038bdd402d  vmovaps [rsp+0x60], xmm6
000075038bdd4033  vmovaps [rsp+0x70], xmm7
000075038bdd4039  vmovaps [rsp+0x80], xmm8
000075038bdd4042  vmovaps [rsp+0x90], xmm9
000075038bdd404b  vmovaps [rsp+0xA0], xmm10
000075038bdd4054  vmovaps [rsp+0xB0], xmm11
000075038bdd405d  vmovaps [rsp+0xC0], xmm12
000075038bdd4066  vmovaps [rsp+0xD0], xmm13
000075038bdd406f  vmovaps [rsp+0xE0], xmm14
000075038bdd4078  sub rsp, 0x30
000075038bdd407c  movaps [rsp], xmm15
000075038bdd4081  movaps [rsp+0x10], xmm10
000075038bdd4087  movaps [rsp+0x20], xmm2
000075038bdd408c  lea rdi, [rsp]
000075038bdd4090  mov esi, 0x00
000075038bdd4095  mov rax, 0x56ADB4492530
000075038bdd409f  call rax
000075038bdd40a1  movaps xmm15, [rsp]
000075038bdd40a6  add rsp, 0x30
000075038bdd40aa  vmovaps xmm0, [rsp]
000075038bdd40af  vmovaps xmm1, [rsp+0x10]
000075038bdd40b5  vmovaps xmm2, [rsp+0x20]
000075038bdd40bb  vmovaps xmm3, [rsp+0x30]
000075038bdd40c1  vmovaps xmm4, [rsp+0x40]
000075038bdd40c7  vmovaps xmm5, [rsp+0x50]
000075038bdd40cd  vmovaps xmm6, [rsp+0x60]
000075038bdd40d3  vmovaps xmm7, [rsp+0x70]
000075038bdd40d9  vmovaps xmm8, [rsp+0x80]
000075038bdd40e2  vmovaps xmm9, [rsp+0x90]
000075038bdd40eb  vmovaps xmm10, [rsp+0xA0]
000075038bdd40f4  vmovaps xmm11, [rsp+0xB0]
000075038bdd40fd  vmovaps xmm12, [rsp+0xC0]
000075038bdd4106  vmovaps xmm13, [rsp+0xD0]
000075038bdd410f  vmovaps xmm14, [rsp+0xE0]
000075038bdd4118  add rsp, 0xF0
000075038bdd411f  pop r11
000075038bdd4121  pop r10
000075038bdd4123  pop r9
000075038bdd4125  pop r8
000075038bdd4127  pop rsi
000075038bdd4128  pop rdi
000075038bdd4129  pop rdx
000075038bdd412a  pop rcx
000075038bdd412b  pop rax
000075038bdd412c  add rsp, 0x08
000075038bdd4130  jmp 0x000075038BDD2924
000075038bdd4135  sub rsp, 0x08
000075038bdd4139  push rax
000075038bdd413a  push rcx
000075038bdd413b  push rdx
000075038bdd413c  push rdi
000075038bdd413d  push rsi
000075038bdd413e  push r8
000075038bdd4140  push r9
000075038bdd4142  push r10
000075038bdd4144  push r11
000075038bdd4146  sub rsp, 0xF0
000075038bdd414d  vmovaps [rsp], xmm0
000075038bdd4152  vmovaps [rsp+0x10], xmm2
000075038bdd4158  vmovaps [rsp+0x20], xmm3
000075038bdd415e  vmovaps [rsp+0x30], xmm4
000075038bdd4164  vmovaps [rsp+0x40], xmm5
000075038bdd416a  vmovaps [rsp+0x50], xmm6
000075038bdd4170  vmovaps [rsp+0x60], xmm7
000075038bdd4176  vmovaps [rsp+0x70], xmm8
000075038bdd417c  vmovaps [rsp+0x80], xmm9
000075038bdd4185  vmovaps [rsp+0x90], xmm10
000075038bdd418e  vmovaps [rsp+0xA0], xmm11
000075038bdd4197  vmovaps [rsp+0xB0], xmm12
000075038bdd41a0  vmovaps [rsp+0xC0], xmm13
000075038bdd41a9  vmovaps [rsp+0xD0], xmm14
000075038bdd41b2  vmovaps [rsp+0xE0], xmm15
000075038bdd41bb  sub rsp, 0x30
000075038bdd41bf  movaps [rsp], xmm1
000075038bdd41c3  movaps [rsp+0x10], xmm10
000075038bdd41c9  movaps [rsp+0x20], xmm15
000075038bdd41cf  lea rdi, [rsp]
000075038bdd41d3  mov esi, 0x00
000075038bdd41d8  mov rax, 0x56ADB4492530
000075038bdd41e2  call rax
000075038bdd41e4  movaps xmm1, [rsp]
000075038bdd41e8  add rsp, 0x30
000075038bdd41ec  vmovaps xmm0, [rsp]
000075038bdd41f1  vmovaps xmm2, [rsp+0x10]
000075038bdd41f7  vmovaps xmm3, [rsp+0x20]
000075038bdd41fd  vmovaps xmm4, [rsp+0x30]
000075038bdd4203  vmovaps xmm5, [rsp+0x40]
000075038bdd4209  vmovaps xmm6, [rsp+0x50]
000075038bdd420f  vmovaps xmm7, [rsp+0x60]
000075038bdd4215  vmovaps xmm8, [rsp+0x70]
000075038bdd421b  vmovaps xmm9, [rsp+0x80]
000075038bdd4224  vmovaps xmm10, [rsp+0x90]
000075038bdd422d  vmovaps xmm11, [rsp+0xA0]
000075038bdd4236  vmovaps xmm12, [rsp+0xB0]
000075038bdd423f  vmovaps xmm13, [rsp+0xC0]
000075038bdd4248  vmovaps xmm14, [rsp+0xD0]
000075038bdd4251  vmovaps xmm15, [rsp+0xE0]
000075038bdd425a  add rsp, 0xF0
000075038bdd4261  pop r11
000075038bdd4263  pop r10
000075038bdd4265  pop r9
000075038bdd4267  pop r8
000075038bdd4269  pop rsi
000075038bdd426a  pop rdi
000075038bdd426b  pop rdx
000075038bdd426c  pop rcx
000075038bdd426d  pop rax
000075038bdd426e  add rsp, 0x08
000075038bdd4272  jmp 0x000075038BDD2962
000075038bdd4277  sub rsp, 0x08
000075038bdd427b  push rax
000075038bdd427c  push rcx
000075038bdd427d  push rdx
000075038bdd427e  push rdi
000075038bdd427f  push rsi
000075038bdd4280  push r8
000075038bdd4282  push r9
000075038bdd4284  push r10
000075038bdd4286  push r11
000075038bdd4288  sub rsp, 0xF0
000075038bdd428f  vmovaps [rsp], xmm0
000075038bdd4294  vmovaps [rsp+0x10], xmm1
000075038bdd429a  vmovaps [rsp+0x20], xmm2
000075038bdd42a0  vmovaps [rsp+0x30], xmm3
000075038bdd42a6  vmovaps [rsp+0x40], xmm4
000075038bdd42ac  vmovaps [rsp+0x50], xmm5
000075038bdd42b2  vmovaps [rsp+0x60], xmm6
000075038bdd42b8  vmovaps [rsp+0x70], xmm7
000075038bdd42be  vmovaps [rsp+0x80], xmm8
000075038bdd42c7  vmovaps [rsp+0x90], xmm9
000075038bdd42d0  vmovaps [rsp+0xA0], xmm10
000075038bdd42d9  vmovaps [rsp+0xB0], xmm11
000075038bdd42e2  vmovaps [rsp+0xC0], xmm12
000075038bdd42eb  vmovaps [rsp+0xD0], xmm13
000075038bdd42f4  vmovaps [rsp+0xE0], xmm15
000075038bdd42fd  sub rsp, 0x30
000075038bdd4301  movaps [rsp], xmm14
000075038bdd4306  movaps [rsp+0x10], xmm10
000075038bdd430c  movaps [rsp+0x20], xmm15
000075038bdd4312  lea rdi, [rsp]
000075038bdd4316  mov esi, 0x00
000075038bdd431b  mov rax, 0x56ADB4492530
000075038bdd4325  call rax
000075038bdd4327  movaps xmm14, [rsp]
000075038bdd432c  add rsp, 0x30
000075038bdd4330  vmovaps xmm0, [rsp]
000075038bdd4335  vmovaps xmm1, [rsp+0x10]
000075038bdd433b  vmovaps xmm2, [rsp+0x20]
000075038bdd4341  vmovaps xmm3, [rsp+0x30]
000075038bdd4347  vmovaps xmm4, [rsp+0x40]
000075038bdd434d  vmovaps xmm5, [rsp+0x50]
000075038bdd4353  vmovaps xmm6, [rsp+0x60]
000075038bdd4359  vmovaps xmm7, [rsp+0x70]
000075038bdd435f  vmovaps xmm8, [rsp+0x80]
000075038bdd4368  vmovaps xmm9, [rsp+0x90]
000075038bdd4371  vmovaps xmm10, [rsp+0xA0]
000075038bdd437a  vmovaps xmm11, [rsp+0xB0]
000075038bdd4383  vmovaps xmm12, [rsp+0xC0]
000075038bdd438c  vmovaps xmm13, [rsp+0xD0]
000075038bdd4395  vmovaps xmm15, [rsp+0xE0]
000075038bdd439e  add rsp, 0xF0
000075038bdd43a5  pop r11
000075038bdd43a7  pop r10
000075038bdd43a9  pop r9
000075038bdd43ab  pop r8
000075038bdd43ad  pop rsi
000075038bdd43ae  pop rdi
000075038bdd43af  pop rdx
000075038bdd43b0  pop rcx
000075038bdd43b1  pop rax
000075038bdd43b2  add rsp, 0x08
000075038bdd43b6  jmp 0x000075038BDD298E
000075038bdd43bb  call 0x000075038BBFF430
000075038bdd43c0  jmp 0x000075038BDD2A1E
000075038bdd43c5  call 0x000075038BBFF430
000075038bdd43ca  jmp 0x000075038BDD2A31
000075038bdd43cf  sub rsp, 0x08
000075038bdd43d3  push rax
000075038bdd43d4  push rcx
000075038bdd43d5  push rdx
000075038bdd43d6  push rdi
000075038bdd43d7  push rsi
000075038bdd43d8  push r8
000075038bdd43da  push r9
000075038bdd43dc  push r10
000075038bdd43de  push r11
000075038bdd43e0  sub rsp, 0xF0
000075038bdd43e7  vmovaps [rsp], xmm0
000075038bdd43ec  vmovaps [rsp+0x10], xmm2
000075038bdd43f2  vmovaps [rsp+0x20], xmm3
000075038bdd43f8  vmovaps [rsp+0x30], xmm4
000075038bdd43fe  vmovaps [rsp+0x40], xmm5
000075038bdd4404  vmovaps [rsp+0x50], xmm6
000075038bdd440a  vmovaps [rsp+0x60], xmm7
000075038bdd4410  vmovaps [rsp+0x70], xmm8
000075038bdd4416  vmovaps [rsp+0x80], xmm9
000075038bdd441f  vmovaps [rsp+0x90], xmm10
000075038bdd4428  vmovaps [rsp+0xA0], xmm11
000075038bdd4431  vmovaps [rsp+0xB0], xmm12
000075038bdd443a  vmovaps [rsp+0xC0], xmm13
000075038bdd4443  vmovaps [rsp+0xD0], xmm14
000075038bdd444c  vmovaps [rsp+0xE0], xmm15
000075038bdd4455  sub rsp, 0x30
000075038bdd4459  movaps [rsp], xmm1
000075038bdd445d  movaps [rsp+0x10], xmm13
000075038bdd4463  movaps [rsp+0x20], xmm2
000075038bdd4468  lea rdi, [rsp]
000075038bdd446c  mov esi, 0x00
000075038bdd4471  mov rax, 0x56ADB4492530
000075038bdd447b  call rax
000075038bdd447d  movaps xmm1, [rsp]
000075038bdd4481  add rsp, 0x30
000075038bdd4485  vmovaps xmm0, [rsp]
000075038bdd448a  vmovaps xmm2, [rsp+0x10]
000075038bdd4490  vmovaps xmm3, [rsp+0x20]
000075038bdd4496  vmovaps xmm4, [rsp+0x30]
000075038bdd449c  vmovaps xmm5, [rsp+0x40]
000075038bdd44a2  vmovaps xmm6, [rsp+0x50]
000075038bdd44a8  vmovaps xmm7, [rsp+0x60]
000075038bdd44ae  vmovaps xmm8, [rsp+0x70]
000075038bdd44b4  vmovaps xmm9, [rsp+0x80]
000075038bdd44bd  vmovaps xmm10, [rsp+0x90]
000075038bdd44c6  vmovaps xmm11, [rsp+0xA0]
000075038bdd44cf  vmovaps xmm12, [rsp+0xB0]
000075038bdd44d8  vmovaps xmm13, [rsp+0xC0]
000075038bdd44e1  vmovaps xmm14, [rsp+0xD0]
000075038bdd44ea  vmovaps xmm15, [rsp+0xE0]
000075038bdd44f3  add rsp, 0xF0
000075038bdd44fa  pop r11
000075038bdd44fc  pop r10
000075038bdd44fe  pop r9
000075038bdd4500  pop r8
000075038bdd4502  pop rsi
000075038bdd4503  pop rdi
000075038bdd4504  pop rdx
000075038bdd4505  pop rcx
000075038bdd4506  pop rax
000075038bdd4507  add rsp, 0x08
000075038bdd450b  jmp 0x000075038BDD2A5C
000075038bdd4510  call 0x000075038BC0E760
000075038bdd4515  jmp 0x000075038BDD2A69
000075038bdd451a  sub rsp, 0x08
000075038bdd451e  push rax
000075038bdd451f  push rcx
000075038bdd4520  push rdx
000075038bdd4521  push rdi
000075038bdd4522  push rsi
000075038bdd4523  push r8
000075038bdd4525  push r9
000075038bdd4527  push r10
000075038bdd4529  push r11
000075038bdd452b  sub rsp, 0xF0
000075038bdd4532  vmovaps [rsp], xmm0
000075038bdd4537  vmovaps [rsp+0x10], xmm1
000075038bdd453d  vmovaps [rsp+0x20], xmm2
000075038bdd4543  vmovaps [rsp+0x30], xmm3
000075038bdd4549  vmovaps [rsp+0x40], xmm4
000075038bdd454f  vmovaps [rsp+0x50], xmm5
000075038bdd4555  vmovaps [rsp+0x60], xmm6
000075038bdd455b  vmovaps [rsp+0x70], xmm7
000075038bdd4561  vmovaps [rsp+0x80], xmm8
000075038bdd456a  vmovaps [rsp+0x90], xmm9
000075038bdd4573  vmovaps [rsp+0xA0], xmm10
000075038bdd457c  vmovaps [rsp+0xB0], xmm11
000075038bdd4585  vmovaps [rsp+0xC0], xmm12
000075038bdd458e  vmovaps [rsp+0xD0], xmm14
000075038bdd4597  vmovaps [rsp+0xE0], xmm15
000075038bdd45a0  sub rsp, 0x30
000075038bdd45a4  movaps [rsp], xmm13
000075038bdd45a9  movaps [rsp+0x10], xmm2
000075038bdd45ae  movaps [rsp+0x20], xmm1
000075038bdd45b3  lea rdi, [rsp]
000075038bdd45b7  mov esi, 0x00
000075038bdd45bc  mov rax, 0x56ADB4492530
000075038bdd45c6  call rax
000075038bdd45c8  movaps xmm13, [rsp]
000075038bdd45cd  add rsp, 0x30
000075038bdd45d1  vmovaps xmm0, [rsp]
000075038bdd45d6  vmovaps xmm1, [rsp+0x10]
000075038bdd45dc  vmovaps xmm2, [rsp+0x20]
000075038bdd45e2  vmovaps xmm3, [rsp+0x30]
000075038bdd45e8  vmovaps xmm4, [rsp+0x40]
000075038bdd45ee  vmovaps xmm5, [rsp+0x50]
000075038bdd45f4  vmovaps xmm6, [rsp+0x60]
000075038bdd45fa  vmovaps xmm7, [rsp+0x70]
000075038bdd4600  vmovaps xmm8, [rsp+0x80]
000075038bdd4609  vmovaps xmm9, [rsp+0x90]
000075038bdd4612  vmovaps xmm10, [rsp+0xA0]
000075038bdd461b  vmovaps xmm11, [rsp+0xB0]
000075038bdd4624  vmovaps xmm12, [rsp+0xC0]
000075038bdd462d  vmovaps xmm14, [rsp+0xD0]
000075038bdd4636  vmovaps xmm15, [rsp+0xE0]
000075038bdd463f  add rsp, 0xF0
000075038bdd4646  pop r11
000075038bdd4648  pop r10
000075038bdd464a  pop r9
000075038bdd464c  pop r8
000075038bdd464e  pop rsi
000075038bdd464f  pop rdi
000075038bdd4650  pop rdx
000075038bdd4651  pop rcx
000075038bdd4652  pop rax
000075038bdd4653  add rsp, 0x08
000075038bdd4657  jmp 0x000075038BDD2AA8
000075038bdd465c  sub rsp, 0x08
000075038bdd4660  push rax
000075038bdd4661  push rcx
000075038bdd4662  push rdx
000075038bdd4663  push rdi
000075038bdd4664  push rsi
000075038bdd4665  push r8
000075038bdd4667  push r9
000075038bdd4669  push r10
000075038bdd466b  push r11
000075038bdd466d  sub rsp, 0xF0
000075038bdd4674  vmovaps [rsp], xmm0
000075038bdd4679  vmovaps [rsp+0x10], xmm2
000075038bdd467f  vmovaps [rsp+0x20], xmm3
000075038bdd4685  vmovaps [rsp+0x30], xmm4
000075038bdd468b  vmovaps [rsp+0x40], xmm5
000075038bdd4691  vmovaps [rsp+0x50], xmm6
000075038bdd4697  vmovaps [rsp+0x60], xmm7
000075038bdd469d  vmovaps [rsp+0x70], xmm8
000075038bdd46a3  vmovaps [rsp+0x80], xmm9
000075038bdd46ac  vmovaps [rsp+0x90], xmm10
000075038bdd46b5  vmovaps [rsp+0xA0], xmm11
000075038bdd46be  vmovaps [rsp+0xB0], xmm12
000075038bdd46c7  vmovaps [rsp+0xC0], xmm13
000075038bdd46d0  vmovaps [rsp+0xD0], xmm14
000075038bdd46d9  vmovaps [rsp+0xE0], xmm15
000075038bdd46e2  sub rsp, 0x30
000075038bdd46e6  movaps [rsp], xmm1
000075038bdd46ea  movaps [rsp+0x10], xmm14
000075038bdd46f0  movaps [rsp+0x20], xmm15
000075038bdd46f6  lea rdi, [rsp]
000075038bdd46fa  mov esi, 0x00
000075038bdd46ff  mov rax, 0x56ADB4492530
000075038bdd4709  call rax
000075038bdd470b  movaps xmm1, [rsp]
000075038bdd470f  add rsp, 0x30
000075038bdd4713  vmovaps xmm0, [rsp]
000075038bdd4718  vmovaps xmm2, [rsp+0x10]
000075038bdd471e  vmovaps xmm3, [rsp+0x20]
000075038bdd4724  vmovaps xmm4, [rsp+0x30]
000075038bdd472a  vmovaps xmm5, [rsp+0x40]
000075038bdd4730  vmovaps xmm6, [rsp+0x50]
000075038bdd4736  vmovaps xmm7, [rsp+0x60]
000075038bdd473c  vmovaps xmm8, [rsp+0x70]
000075038bdd4742  vmovaps xmm9, [rsp+0x80]
000075038bdd474b  vmovaps xmm10, [rsp+0x90]
000075038bdd4754  vmovaps xmm11, [rsp+0xA0]
000075038bdd475d  vmovaps xmm12, [rsp+0xB0]
000075038bdd4766  vmovaps xmm13, [rsp+0xC0]
000075038bdd476f  vmovaps xmm14, [rsp+0xD0]
000075038bdd4778  vmovaps xmm15, [rsp+0xE0]
000075038bdd4781  add rsp, 0xF0
000075038bdd4788  pop r11
000075038bdd478a  pop r10
000075038bdd478c  pop r9
000075038bdd478e  pop r8
000075038bdd4790  pop rsi
000075038bdd4791  pop rdi
000075038bdd4792  pop rdx
000075038bdd4793  pop rcx
000075038bdd4794  pop rax
000075038bdd4795  add rsp, 0x08
000075038bdd4799  jmp 0x000075038BDD2ACA
000075038bdd479e  sub rsp, 0x08
000075038bdd47a2  push rax
000075038bdd47a3  push rcx
000075038bdd47a4  push rdx
000075038bdd47a5  push rdi
000075038bdd47a6  push rsi
000075038bdd47a7  push r8
000075038bdd47a9  push r9
000075038bdd47ab  push r10
000075038bdd47ad  push r11
000075038bdd47af  sub rsp, 0xF0
000075038bdd47b6  vmovaps [rsp], xmm0
000075038bdd47bb  vmovaps [rsp+0x10], xmm1
000075038bdd47c1  vmovaps [rsp+0x20], xmm2
000075038bdd47c7  vmovaps [rsp+0x30], xmm3
000075038bdd47cd  vmovaps [rsp+0x40], xmm4
000075038bdd47d3  vmovaps [rsp+0x50], xmm5
000075038bdd47d9  vmovaps [rsp+0x60], xmm6
000075038bdd47df  vmovaps [rsp+0x70], xmm7
000075038bdd47e5  vmovaps [rsp+0x80], xmm8
000075038bdd47ee  vmovaps [rsp+0x90], xmm9
000075038bdd47f7  vmovaps [rsp+0xA0], xmm10
000075038bdd4800  vmovaps [rsp+0xB0], xmm11
000075038bdd4809  vmovaps [rsp+0xC0], xmm12
000075038bdd4812  vmovaps [rsp+0xD0], xmm13
000075038bdd481b  vmovaps [rsp+0xE0], xmm15
000075038bdd4824  sub rsp, 0x30
000075038bdd4828  movaps [rsp], xmm14
000075038bdd482d  movaps [rsp+0x10], xmm2
000075038bdd4832  movaps [rsp+0x20], xmm15
000075038bdd4838  lea rdi, [rsp]
000075038bdd483c  mov esi, 0x00
000075038bdd4841  mov rax, 0x56ADB4492530
000075038bdd484b  call rax
000075038bdd484d  movaps xmm14, [rsp]
000075038bdd4852  add rsp, 0x30
000075038bdd4856  vmovaps xmm0, [rsp]
000075038bdd485b  vmovaps xmm1, [rsp+0x10]
000075038bdd4861  vmovaps xmm2, [rsp+0x20]
000075038bdd4867  vmovaps xmm3, [rsp+0x30]
000075038bdd486d  vmovaps xmm4, [rsp+0x40]
000075038bdd4873  vmovaps xmm5, [rsp+0x50]
000075038bdd4879  vmovaps xmm6, [rsp+0x60]
000075038bdd487f  vmovaps xmm7, [rsp+0x70]
000075038bdd4885  vmovaps xmm8, [rsp+0x80]
000075038bdd488e  vmovaps xmm9, [rsp+0x90]
000075038bdd4897  vmovaps xmm10, [rsp+0xA0]
000075038bdd48a0  vmovaps xmm11, [rsp+0xB0]
000075038bdd48a9  vmovaps xmm12, [rsp+0xC0]
000075038bdd48b2  vmovaps xmm13, [rsp+0xD0]
000075038bdd48bb  vmovaps xmm15, [rsp+0xE0]
000075038bdd48c4  add rsp, 0xF0
000075038bdd48cb  pop r11
000075038bdd48cd  pop r10
000075038bdd48cf  pop r9
000075038bdd48d1  pop r8
000075038bdd48d3  pop rsi
000075038bdd48d4  pop rdi
000075038bdd48d5  pop rdx
000075038bdd48d6  pop rcx
000075038bdd48d7  pop rax
000075038bdd48d8  add rsp, 0x08
000075038bdd48dc  jmp 0x000075038BDD2B05
000075038bdd48e1  sub rsp, 0x08
000075038bdd48e5  push rax
000075038bdd48e6  push rcx
000075038bdd48e7  push rdx
000075038bdd48e8  push rdi
000075038bdd48e9  push rsi
000075038bdd48ea  push r8
000075038bdd48ec  push r9
000075038bdd48ee  push r10
000075038bdd48f0  push r11
000075038bdd48f2  sub rsp, 0xF0
000075038bdd48f9  vmovaps [rsp], xmm0
000075038bdd48fe  vmovaps [rsp+0x10], xmm1
000075038bdd4904  vmovaps [rsp+0x20], xmm2
000075038bdd490a  vmovaps [rsp+0x30], xmm3
000075038bdd4910  vmovaps [rsp+0x40], xmm4
000075038bdd4916  vmovaps [rsp+0x50], xmm5
000075038bdd491c  vmovaps [rsp+0x60], xmm6
000075038bdd4922  vmovaps [rsp+0x70], xmm7
000075038bdd4928  vmovaps [rsp+0x80], xmm8
000075038bdd4931  vmovaps [rsp+0x90], xmm9
000075038bdd493a  vmovaps [rsp+0xA0], xmm10
000075038bdd4943  vmovaps [rsp+0xB0], xmm11
000075038bdd494c  vmovaps [rsp+0xC0], xmm12
000075038bdd4955  vmovaps [rsp+0xD0], xmm13
000075038bdd495e  vmovaps [rsp+0xE0], xmm14
000075038bdd4967  sub rsp, 0x30
000075038bdd496b  movaps [rsp], xmm15
000075038bdd4970  movaps [rsp+0x10], xmm2
000075038bdd4975  movaps [rsp+0x20], xmm1
000075038bdd497a  lea rdi, [rsp]
000075038bdd497e  mov esi, 0x00
000075038bdd4983  mov rax, 0x56ADB4492530
000075038bdd498d  call rax
000075038bdd498f  movaps xmm15, [rsp]
000075038bdd4994  add rsp, 0x30
000075038bdd4998  vmovaps xmm0, [rsp]
000075038bdd499d  vmovaps xmm1, [rsp+0x10]
000075038bdd49a3  vmovaps xmm2, [rsp+0x20]
000075038bdd49a9  vmovaps xmm3, [rsp+0x30]
000075038bdd49af  vmovaps xmm4, [rsp+0x40]
000075038bdd49b5  vmovaps xmm5, [rsp+0x50]
000075038bdd49bb  vmovaps xmm6, [rsp+0x60]
000075038bdd49c1  vmovaps xmm7, [rsp+0x70]
000075038bdd49c7  vmovaps xmm8, [rsp+0x80]
000075038bdd49d0  vmovaps xmm9, [rsp+0x90]
000075038bdd49d9  vmovaps xmm10, [rsp+0xA0]
000075038bdd49e2  vmovaps xmm11, [rsp+0xB0]
000075038bdd49eb  vmovaps xmm12, [rsp+0xC0]
000075038bdd49f4  vmovaps xmm13, [rsp+0xD0]
000075038bdd49fd  vmovaps xmm14, [rsp+0xE0]
000075038bdd4a06  add rsp, 0xF0
000075038bdd4a0d  pop r11
000075038bdd4a0f  pop r10
000075038bdd4a11  pop r9
000075038bdd4a13  pop r8
000075038bdd4a15  pop rsi
000075038bdd4a16  pop rdi
000075038bdd4a17  pop rdx
000075038bdd4a18  pop rcx
000075038bdd4a19  pop rax
000075038bdd4a1a  add rsp, 0x08
000075038bdd4a1e  jmp 0x000075038BDD2B41
000075038bdd4a23  call 0x000075038BBFF430
000075038bdd4a28  jmp 0x000075038BDD2B4E
000075038bdd4a2d  sub rsp, 0x08
000075038bdd4a31  push rax
000075038bdd4a32  push rcx
000075038bdd4a33  push rdx
000075038bdd4a34  push rdi
000075038bdd4a35  push rsi
000075038bdd4a36  push r8
000075038bdd4a38  push r9
000075038bdd4a3a  push r10
000075038bdd4a3c  push r11
000075038bdd4a3e  sub rsp, 0xF0
000075038bdd4a45  vmovaps [rsp], xmm0
000075038bdd4a4a  vmovaps [rsp+0x10], xmm1
000075038bdd4a50  vmovaps [rsp+0x20], xmm3
000075038bdd4a56  vmovaps [rsp+0x30], xmm4
000075038bdd4a5c  vmovaps [rsp+0x40], xmm5
000075038bdd4a62  vmovaps [rsp+0x50], xmm6
000075038bdd4a68  vmovaps [rsp+0x60], xmm7
000075038bdd4a6e  vmovaps [rsp+0x70], xmm8
000075038bdd4a74  vmovaps [rsp+0x80], xmm9
000075038bdd4a7d  vmovaps [rsp+0x90], xmm10
000075038bdd4a86  vmovaps [rsp+0xA0], xmm11
000075038bdd4a8f  vmovaps [rsp+0xB0], xmm12
000075038bdd4a98  vmovaps [rsp+0xC0], xmm13
000075038bdd4aa1  vmovaps [rsp+0xD0], xmm14
000075038bdd4aaa  vmovaps [rsp+0xE0], xmm15
000075038bdd4ab3  sub rsp, 0x30
000075038bdd4ab7  movaps [rsp], xmm2
000075038bdd4abb  movaps [rsp+0x10], xmm1
000075038bdd4ac0  movaps [rsp+0x20], xmm14
000075038bdd4ac6  lea rdi, [rsp]
000075038bdd4aca  mov esi, 0x00
000075038bdd4acf  mov rax, 0x56ADB4492530
000075038bdd4ad9  call rax
000075038bdd4adb  movaps xmm2, [rsp]
000075038bdd4adf  add rsp, 0x30
000075038bdd4ae3  vmovaps xmm0, [rsp]
000075038bdd4ae8  vmovaps xmm1, [rsp+0x10]
000075038bdd4aee  vmovaps xmm3, [rsp+0x20]
000075038bdd4af4  vmovaps xmm4, [rsp+0x30]
000075038bdd4afa  vmovaps xmm5, [rsp+0x40]
000075038bdd4b00  vmovaps xmm6, [rsp+0x50]
000075038bdd4b06  vmovaps xmm7, [rsp+0x60]
000075038bdd4b0c  vmovaps xmm8, [rsp+0x70]
000075038bdd4b12  vmovaps xmm9, [rsp+0x80]
000075038bdd4b1b  vmovaps xmm10, [rsp+0x90]
000075038bdd4b24  vmovaps xmm11, [rsp+0xA0]
000075038bdd4b2d  vmovaps xmm12, [rsp+0xB0]
000075038bdd4b36  vmovaps xmm13, [rsp+0xC0]
000075038bdd4b3f  vmovaps xmm14, [rsp+0xD0]
000075038bdd4b48  vmovaps xmm15, [rsp+0xE0]
000075038bdd4b51  add rsp, 0xF0
000075038bdd4b58  pop r11
000075038bdd4b5a  pop r10
000075038bdd4b5c  pop r9
000075038bdd4b5e  pop r8
000075038bdd4b60  pop rsi
000075038bdd4b61  pop rdi
000075038bdd4b62  pop rdx
000075038bdd4b63  pop rcx
000075038bdd4b64  pop rax
000075038bdd4b65  add rsp, 0x08
000075038bdd4b69  jmp 0x000075038BDD2B8B
000075038bdd4b6e  sub rsp, 0x08
000075038bdd4b72  push rax
000075038bdd4b73  push rcx
000075038bdd4b74  push rdx
000075038bdd4b75  push rdi
000075038bdd4b76  push rsi
000075038bdd4b77  push r8
000075038bdd4b79  push r9
000075038bdd4b7b  push r10
000075038bdd4b7d  push r11
000075038bdd4b7f  sub rsp, 0xF0
000075038bdd4b86  vmovaps [rsp], xmm0
000075038bdd4b8b  vmovaps [rsp+0x10], xmm1
000075038bdd4b91  vmovaps [rsp+0x20], xmm2
000075038bdd4b97  vmovaps [rsp+0x30], xmm3
000075038bdd4b9d  vmovaps [rsp+0x40], xmm4
000075038bdd4ba3  vmovaps [rsp+0x50], xmm5
000075038bdd4ba9  vmovaps [rsp+0x60], xmm6
000075038bdd4baf  vmovaps [rsp+0x70], xmm7
000075038bdd4bb5  vmovaps [rsp+0x80], xmm8
000075038bdd4bbe  vmovaps [rsp+0x90], xmm9
000075038bdd4bc7  vmovaps [rsp+0xA0], xmm10
000075038bdd4bd0  vmovaps [rsp+0xB0], xmm11
000075038bdd4bd9  vmovaps [rsp+0xC0], xmm12
000075038bdd4be2  vmovaps [rsp+0xD0], xmm13
000075038bdd4beb  vmovaps [rsp+0xE0], xmm14
000075038bdd4bf4  sub rsp, 0x30
000075038bdd4bf8  movaps [rsp], xmm15
000075038bdd4bfd  movaps [rsp+0x10], xmm14
000075038bdd4c03  movaps [rsp+0x20], xmm1
000075038bdd4c08  lea rdi, [rsp]
000075038bdd4c0c  mov esi, 0x00
000075038bdd4c11  mov rax, 0x56ADB4492530
000075038bdd4c1b  call rax
000075038bdd4c1d  movaps xmm15, [rsp]
000075038bdd4c22  add rsp, 0x30
000075038bdd4c26  vmovaps xmm0, [rsp]
000075038bdd4c2b  vmovaps xmm1, [rsp+0x10]
000075038bdd4c31  vmovaps xmm2, [rsp+0x20]
000075038bdd4c37  vmovaps xmm3, [rsp+0x30]
000075038bdd4c3d  vmovaps xmm4, [rsp+0x40]
000075038bdd4c43  vmovaps xmm5, [rsp+0x50]
000075038bdd4c49  vmovaps xmm6, [rsp+0x60]
000075038bdd4c4f  vmovaps xmm7, [rsp+0x70]
000075038bdd4c55  vmovaps xmm8, [rsp+0x80]
000075038bdd4c5e  vmovaps xmm9, [rsp+0x90]
000075038bdd4c67  vmovaps xmm10, [rsp+0xA0]
000075038bdd4c70  vmovaps xmm11, [rsp+0xB0]
000075038bdd4c79  vmovaps xmm12, [rsp+0xC0]
000075038bdd4c82  vmovaps xmm13, [rsp+0xD0]
000075038bdd4c8b  vmovaps xmm14, [rsp+0xE0]
000075038bdd4c94  add rsp, 0xF0
000075038bdd4c9b  pop r11
000075038bdd4c9d  pop r10
000075038bdd4c9f  pop r9
000075038bdd4ca1  pop r8
000075038bdd4ca3  pop rsi
000075038bdd4ca4  pop rdi
000075038bdd4ca5  pop rdx
000075038bdd4ca6  pop rcx
000075038bdd4ca7  pop rax
000075038bdd4ca8  add rsp, 0x08
000075038bdd4cac  jmp 0x000075038BDD2C05
000075038bdd4cb1  call 0x000075038BBFF430
000075038bdd4cb6  jmp 0x000075038BDD2C12
000075038bdd4cbb  sub rsp, 0x08
000075038bdd4cbf  push rax
000075038bdd4cc0  push rcx
000075038bdd4cc1  push rdx
000075038bdd4cc2  push rdi
000075038bdd4cc3  push rsi
000075038bdd4cc4  push r8
000075038bdd4cc6  push r9
000075038bdd4cc8  push r10
000075038bdd4cca  push r11
000075038bdd4ccc  sub rsp, 0xF0
000075038bdd4cd3  vmovaps [rsp], xmm0
000075038bdd4cd8  vmovaps [rsp+0x10], xmm1
000075038bdd4cde  vmovaps [rsp+0x20], xmm2
000075038bdd4ce4  vmovaps [rsp+0x30], xmm3
000075038bdd4cea  vmovaps [rsp+0x40], xmm4
000075038bdd4cf0  vmovaps [rsp+0x50], xmm5
000075038bdd4cf6  vmovaps [rsp+0x60], xmm6
000075038bdd4cfc  vmovaps [rsp+0x70], xmm7
000075038bdd4d02  vmovaps [rsp+0x80], xmm8
000075038bdd4d0b  vmovaps [rsp+0x90], xmm9
000075038bdd4d14  vmovaps [rsp+0xA0], xmm10
000075038bdd4d1d  vmovaps [rsp+0xB0], xmm11
000075038bdd4d26  vmovaps [rsp+0xC0], xmm12
000075038bdd4d2f  vmovaps [rsp+0xD0], xmm14
000075038bdd4d38  vmovaps [rsp+0xE0], xmm15
000075038bdd4d41  sub rsp, 0x30
000075038bdd4d45  movaps [rsp], xmm13
000075038bdd4d4a  movaps [rsp+0x10], xmm1
000075038bdd4d4f  movaps [rsp+0x20], xmm15
000075038bdd4d55  lea rdi, [rsp]
000075038bdd4d59  mov esi, 0x00
000075038bdd4d5e  mov rax, 0x56ADB4492530
000075038bdd4d68  call rax
000075038bdd4d6a  movaps xmm13, [rsp]
000075038bdd4d6f  add rsp, 0x30
000075038bdd4d73  vmovaps xmm0, [rsp]
000075038bdd4d78  vmovaps xmm1, [rsp+0x10]
000075038bdd4d7e  vmovaps xmm2, [rsp+0x20]
000075038bdd4d84  vmovaps xmm3, [rsp+0x30]
000075038bdd4d8a  vmovaps xmm4, [rsp+0x40]
000075038bdd4d90  vmovaps xmm5, [rsp+0x50]
000075038bdd4d96  vmovaps xmm6, [rsp+0x60]
000075038bdd4d9c  vmovaps xmm7, [rsp+0x70]
000075038bdd4da2  vmovaps xmm8, [rsp+0x80]
000075038bdd4dab  vmovaps xmm9, [rsp+0x90]
000075038bdd4db4  vmovaps xmm10, [rsp+0xA0]
000075038bdd4dbd  vmovaps xmm11, [rsp+0xB0]
000075038bdd4dc6  vmovaps xmm12, [rsp+0xC0]
000075038bdd4dcf  vmovaps xmm14, [rsp+0xD0]
000075038bdd4dd8  vmovaps xmm15, [rsp+0xE0]
000075038bdd4de1  add rsp, 0xF0
000075038bdd4de8  pop r11
000075038bdd4dea  pop r10
000075038bdd4dec  pop r9
000075038bdd4dee  pop r8
000075038bdd4df0  pop rsi
000075038bdd4df1  pop rdi
000075038bdd4df2  pop rdx
000075038bdd4df3  pop rcx
000075038bdd4df4  pop rax
000075038bdd4df5  add rsp, 0x08
000075038bdd4df9  jmp 0x000075038BDD2CD6
000075038bdd4dfe  sub rsp, 0x08
000075038bdd4e02  push rax
000075038bdd4e03  push rcx
000075038bdd4e04  push rdx
000075038bdd4e05  push rdi
000075038bdd4e06  push rsi
000075038bdd4e07  push r8
000075038bdd4e09  push r9
000075038bdd4e0b  push r10
000075038bdd4e0d  push r11
000075038bdd4e0f  sub rsp, 0xF0
000075038bdd4e16  vmovaps [rsp], xmm0
000075038bdd4e1b  vmovaps [rsp+0x10], xmm1
000075038bdd4e21  vmovaps [rsp+0x20], xmm2
000075038bdd4e27  vmovaps [rsp+0x30], xmm3
000075038bdd4e2d  vmovaps [rsp+0x40], xmm4
000075038bdd4e33  vmovaps [rsp+0x50], xmm5
000075038bdd4e39  vmovaps [rsp+0x60], xmm6
000075038bdd4e3f  vmovaps [rsp+0x70], xmm7
000075038bdd4e45  vmovaps [rsp+0x80], xmm8
000075038bdd4e4e  vmovaps [rsp+0x90], xmm9
000075038bdd4e57  vmovaps [rsp+0xA0], xmm10
000075038bdd4e60  vmovaps [rsp+0xB0], xmm11
000075038bdd4e69  vmovaps [rsp+0xC0], xmm12
000075038bdd4e72  vmovaps [rsp+0xD0], xmm13
000075038bdd4e7b  vmovaps [rsp+0xE0], xmm14
000075038bdd4e84  sub rsp, 0x30
000075038bdd4e88  movaps [rsp], xmm15
000075038bdd4e8d  movaps [rsp+0x10], xmm14
000075038bdd4e93  movaps [rsp+0x20], xmm1
000075038bdd4e98  lea rdi, [rsp]
000075038bdd4e9c  mov esi, 0x00
000075038bdd4ea1  mov rax, 0x56ADB4492530
000075038bdd4eab  call rax
000075038bdd4ead  movaps xmm15, [rsp]
000075038bdd4eb2  add rsp, 0x30
000075038bdd4eb6  vmovaps xmm0, [rsp]
000075038bdd4ebb  vmovaps xmm1, [rsp+0x10]
000075038bdd4ec1  vmovaps xmm2, [rsp+0x20]
000075038bdd4ec7  vmovaps xmm3, [rsp+0x30]
000075038bdd4ecd  vmovaps xmm4, [rsp+0x40]
000075038bdd4ed3  vmovaps xmm5, [rsp+0x50]
000075038bdd4ed9  vmovaps xmm6, [rsp+0x60]
000075038bdd4edf  vmovaps xmm7, [rsp+0x70]
000075038bdd4ee5  vmovaps xmm8, [rsp+0x80]
000075038bdd4eee  vmovaps xmm9, [rsp+0x90]
000075038bdd4ef7  vmovaps xmm10, [rsp+0xA0]
000075038bdd4f00  vmovaps xmm11, [rsp+0xB0]
000075038bdd4f09  vmovaps xmm12, [rsp+0xC0]
000075038bdd4f12  vmovaps xmm13, [rsp+0xD0]
000075038bdd4f1b  vmovaps xmm14, [rsp+0xE0]
000075038bdd4f24  add rsp, 0xF0
000075038bdd4f2b  pop r11
000075038bdd4f2d  pop r10
000075038bdd4f2f  pop r9
000075038bdd4f31  pop r8
000075038bdd4f33  pop rsi
000075038bdd4f34  pop rdi
000075038bdd4f35  pop rdx
000075038bdd4f36  pop rcx
000075038bdd4f37  pop rax
000075038bdd4f38  add rsp, 0x08
000075038bdd4f3c  jmp 0x000075038BDD2D12
000075038bdd4f41  call 0x000075038BBFF430
000075038bdd4f46  jmp 0x000075038BDD2D1F
000075038bdd4f4b  sub rsp, 0x08
000075038bdd4f4f  push rax
000075038bdd4f50  push rcx
000075038bdd4f51  push rdx
000075038bdd4f52  push rdi
000075038bdd4f53  push rsi
000075038bdd4f54  push r8
000075038bdd4f56  push r9
000075038bdd4f58  push r10
000075038bdd4f5a  push r11
000075038bdd4f5c  sub rsp, 0xF0
000075038bdd4f63  vmovaps [rsp], xmm0
000075038bdd4f68  vmovaps [rsp+0x10], xmm1
000075038bdd4f6e  vmovaps [rsp+0x20], xmm2
000075038bdd4f74  vmovaps [rsp+0x30], xmm3
000075038bdd4f7a  vmovaps [rsp+0x40], xmm4
000075038bdd4f80  vmovaps [rsp+0x50], xmm5
000075038bdd4f86  vmovaps [rsp+0x60], xmm6
000075038bdd4f8c  vmovaps [rsp+0x70], xmm7
000075038bdd4f92  vmovaps [rsp+0x80], xmm8
000075038bdd4f9b  vmovaps [rsp+0x90], xmm9
000075038bdd4fa4  vmovaps [rsp+0xA0], xmm10
000075038bdd4fad  vmovaps [rsp+0xB0], xmm11
000075038bdd4fb6  vmovaps [rsp+0xC0], xmm12
000075038bdd4fbf  vmovaps [rsp+0xD0], xmm13
000075038bdd4fc8  vmovaps [rsp+0xE0], xmm15
000075038bdd4fd1  sub rsp, 0x30
000075038bdd4fd5  movaps [rsp], xmm14
000075038bdd4fda  movaps [rsp+0x10], xmm13
000075038bdd4fe0  movaps [rsp+0x20], xmm2
000075038bdd4fe5  lea rdi, [rsp]
000075038bdd4fe9  mov esi, 0x00
000075038bdd4fee  mov rax, 0x56ADB4492530
000075038bdd4ff8  call rax
000075038bdd4ffa  movaps xmm14, [rsp]
000075038bdd4fff  add rsp, 0x30
000075038bdd5003  vmovaps xmm0, [rsp]
000075038bdd5008  vmovaps xmm1, [rsp+0x10]
000075038bdd500e  vmovaps xmm2, [rsp+0x20]
000075038bdd5014  vmovaps xmm3, [rsp+0x30]
000075038bdd501a  vmovaps xmm4, [rsp+0x40]
000075038bdd5020  vmovaps xmm5, [rsp+0x50]
000075038bdd5026  vmovaps xmm6, [rsp+0x60]
000075038bdd502c  vmovaps xmm7, [rsp+0x70]
000075038bdd5032  vmovaps xmm8, [rsp+0x80]
000075038bdd503b  vmovaps xmm9, [rsp+0x90]
000075038bdd5044  vmovaps xmm10, [rsp+0xA0]
000075038bdd504d  vmovaps xmm11, [rsp+0xB0]
000075038bdd5056  vmovaps xmm12, [rsp+0xC0]
000075038bdd505f  vmovaps xmm13, [rsp+0xD0]
000075038bdd5068  vmovaps xmm15, [rsp+0xE0]
000075038bdd5071  add rsp, 0xF0
000075038bdd5078  pop r11
000075038bdd507a  pop r10
000075038bdd507c  pop r9
000075038bdd507e  pop r8
000075038bdd5080  pop rsi
000075038bdd5081  pop rdi
000075038bdd5082  pop rdx
000075038bdd5083  pop rcx
000075038bdd5084  pop rax
000075038bdd5085  add rsp, 0x08
000075038bdd5089  jmp 0x000075038BDD2D4B
000075038bdd508e  sub rsp, 0x08
000075038bdd5092  push rax
000075038bdd5093  push rcx
000075038bdd5094  push rdx
000075038bdd5095  push rdi
000075038bdd5096  push rsi
000075038bdd5097  push r8
000075038bdd5099  push r9
000075038bdd509b  push r10
000075038bdd509d  push r11
000075038bdd509f  sub rsp, 0xF0
000075038bdd50a6  vmovaps [rsp], xmm0
000075038bdd50ab  vmovaps [rsp+0x10], xmm2
000075038bdd50b1  vmovaps [rsp+0x20], xmm3
000075038bdd50b7  vmovaps [rsp+0x30], xmm4
000075038bdd50bd  vmovaps [rsp+0x40], xmm5
000075038bdd50c3  vmovaps [rsp+0x50], xmm6
000075038bdd50c9  vmovaps [rsp+0x60], xmm7
000075038bdd50cf  vmovaps [rsp+0x70], xmm8
000075038bdd50d5  vmovaps [rsp+0x80], xmm9
000075038bdd50de  vmovaps [rsp+0x90], xmm10
000075038bdd50e7  vmovaps [rsp+0xA0], xmm11
000075038bdd50f0  vmovaps [rsp+0xB0], xmm12
000075038bdd50f9  vmovaps [rsp+0xC0], xmm13
000075038bdd5102  vmovaps [rsp+0xD0], xmm14
000075038bdd510b  vmovaps [rsp+0xE0], xmm15
000075038bdd5114  sub rsp, 0x30
000075038bdd5118  movaps [rsp], xmm1
000075038bdd511c  movaps [rsp+0x10], xmm13
000075038bdd5122  movaps [rsp+0x20], xmm2
000075038bdd5127  lea rdi, [rsp]
000075038bdd512b  mov esi, 0x00
000075038bdd5130  mov rax, 0x56ADB4492530
000075038bdd513a  call rax
000075038bdd513c  movaps xmm1, [rsp]
000075038bdd5140  add rsp, 0x30
000075038bdd5144  vmovaps xmm0, [rsp]
000075038bdd5149  vmovaps xmm2, [rsp+0x10]
000075038bdd514f  vmovaps xmm3, [rsp+0x20]
000075038bdd5155  vmovaps xmm4, [rsp+0x30]
000075038bdd515b  vmovaps xmm5, [rsp+0x40]
000075038bdd5161  vmovaps xmm6, [rsp+0x50]
000075038bdd5167  vmovaps xmm7, [rsp+0x60]
000075038bdd516d  vmovaps xmm8, [rsp+0x70]
000075038bdd5173  vmovaps xmm9, [rsp+0x80]
000075038bdd517c  vmovaps xmm10, [rsp+0x90]
000075038bdd5185  vmovaps xmm11, [rsp+0xA0]
000075038bdd518e  vmovaps xmm12, [rsp+0xB0]
000075038bdd5197  vmovaps xmm13, [rsp+0xC0]
000075038bdd51a0  vmovaps xmm14, [rsp+0xD0]
000075038bdd51a9  vmovaps xmm15, [rsp+0xE0]
000075038bdd51b2  add rsp, 0xF0
000075038bdd51b9  pop r11
000075038bdd51bb  pop r10
000075038bdd51bd  pop r9
000075038bdd51bf  pop r8
000075038bdd51c1  pop rsi
000075038bdd51c2  pop rdi
000075038bdd51c3  pop rdx
000075038bdd51c4  pop rcx
000075038bdd51c5  pop rax
000075038bdd51c6  add rsp, 0x08
000075038bdd51ca  jmp 0x000075038BDD2D79
000075038bdd51cf  sub rsp, 0x08
000075038bdd51d3  push rax
000075038bdd51d4  push rcx
000075038bdd51d5  push rdx
000075038bdd51d6  push rdi
000075038bdd51d7  push rsi
000075038bdd51d8  push r8
000075038bdd51da  push r9
000075038bdd51dc  push r10
000075038bdd51de  push r11
000075038bdd51e0  sub rsp, 0xF0
000075038bdd51e7  vmovaps [rsp], xmm0
000075038bdd51ec  vmovaps [rsp+0x10], xmm1
000075038bdd51f2  vmovaps [rsp+0x20], xmm3
000075038bdd51f8  vmovaps [rsp+0x30], xmm4
000075038bdd51fe  vmovaps [rsp+0x40], xmm5
000075038bdd5204  vmovaps [rsp+0x50], xmm6
000075038bdd520a  vmovaps [rsp+0x60], xmm7
000075038bdd5210  vmovaps [rsp+0x70], xmm8
000075038bdd5216  vmovaps [rsp+0x80], xmm9
000075038bdd521f  vmovaps [rsp+0x90], xmm10
000075038bdd5228  vmovaps [rsp+0xA0], xmm11
000075038bdd5231  vmovaps [rsp+0xB0], xmm12
000075038bdd523a  vmovaps [rsp+0xC0], xmm13
000075038bdd5243  vmovaps [rsp+0xD0], xmm14
000075038bdd524c  vmovaps [rsp+0xE0], xmm15
000075038bdd5255  sub rsp, 0x30
000075038bdd5259  movaps [rsp], xmm2
000075038bdd525d  movaps [rsp+0x10], xmm1
000075038bdd5262  movaps [rsp+0x20], xmm13
000075038bdd5268  lea rdi, [rsp]
000075038bdd526c  mov esi, 0x00
000075038bdd5271  mov rax, 0x56ADB4492530
000075038bdd527b  call rax
000075038bdd527d  movaps xmm2, [rsp]
000075038bdd5281  add rsp, 0x30
000075038bdd5285  vmovaps xmm0, [rsp]
000075038bdd528a  vmovaps xmm1, [rsp+0x10]
000075038bdd5290  vmovaps xmm3, [rsp+0x20]
000075038bdd5296  vmovaps xmm4, [rsp+0x30]
000075038bdd529c  vmovaps xmm5, [rsp+0x40]
000075038bdd52a2  vmovaps xmm6, [rsp+0x50]
000075038bdd52a8  vmovaps xmm7, [rsp+0x60]
000075038bdd52ae  vmovaps xmm8, [rsp+0x70]
000075038bdd52b4  vmovaps xmm9, [rsp+0x80]
000075038bdd52bd  vmovaps xmm10, [rsp+0x90]
000075038bdd52c6  vmovaps xmm11, [rsp+0xA0]
000075038bdd52cf  vmovaps xmm12, [rsp+0xB0]
000075038bdd52d8  vmovaps xmm13, [rsp+0xC0]
000075038bdd52e1  vmovaps xmm14, [rsp+0xD0]
000075038bdd52ea  vmovaps xmm15, [rsp+0xE0]
000075038bdd52f3  add rsp, 0xF0
000075038bdd52fa  pop r11
000075038bdd52fc  pop r10
000075038bdd52fe  pop r9
000075038bdd5300  pop r8
000075038bdd5302  pop rsi
000075038bdd5303  pop rdi
000075038bdd5304  pop rdx
000075038bdd5305  pop rcx
000075038bdd5306  pop rax
000075038bdd5307  add rsp, 0x08
000075038bdd530b  jmp 0x000075038BDD2DD2
000075038bdd5310  call 0x000075038BBFF430
000075038bdd5315  jmp 0x000075038BDD2DDF
000075038bdd531a  sub rsp, 0x08
000075038bdd531e  push rax
000075038bdd531f  push rcx
000075038bdd5320  push rdx
000075038bdd5321  push rdi
000075038bdd5322  push rsi
000075038bdd5323  push r8
000075038bdd5325  push r9
000075038bdd5327  push r10
000075038bdd5329  push r11
000075038bdd532b  sub rsp, 0xF0
000075038bdd5332  vmovaps [rsp], xmm0
000075038bdd5337  vmovaps [rsp+0x10], xmm1
000075038bdd533d  vmovaps [rsp+0x20], xmm2
000075038bdd5343  vmovaps [rsp+0x30], xmm3
000075038bdd5349  vmovaps [rsp+0x40], xmm4
000075038bdd534f  vmovaps [rsp+0x50], xmm5
000075038bdd5355  vmovaps [rsp+0x60], xmm6
000075038bdd535b  vmovaps [rsp+0x70], xmm7
000075038bdd5361  vmovaps [rsp+0x80], xmm8
000075038bdd536a  vmovaps [rsp+0x90], xmm9
000075038bdd5373  vmovaps [rsp+0xA0], xmm10
000075038bdd537c  vmovaps [rsp+0xB0], xmm11
000075038bdd5385  vmovaps [rsp+0xC0], xmm12
000075038bdd538e  vmovaps [rsp+0xD0], xmm13
000075038bdd5397  vmovaps [rsp+0xE0], xmm14
000075038bdd53a0  sub rsp, 0x30
000075038bdd53a4  movaps [rsp], xmm15
000075038bdd53a9  movaps [rsp+0x10], xmm13
000075038bdd53af  movaps [rsp+0x20], xmm1
000075038bdd53b4  lea rdi, [rsp]
000075038bdd53b8  mov esi, 0x00
000075038bdd53bd  mov rax, 0x56ADB4492530
000075038bdd53c7  call rax
000075038bdd53c9  movaps xmm15, [rsp]
000075038bdd53ce  add rsp, 0x30
000075038bdd53d2  vmovaps xmm0, [rsp]
000075038bdd53d7  vmovaps xmm1, [rsp+0x10]
000075038bdd53dd  vmovaps xmm2, [rsp+0x20]
000075038bdd53e3  vmovaps xmm3, [rsp+0x30]
000075038bdd53e9  vmovaps xmm4, [rsp+0x40]
000075038bdd53ef  vmovaps xmm5, [rsp+0x50]
000075038bdd53f5  vmovaps xmm6, [rsp+0x60]
000075038bdd53fb  vmovaps xmm7, [rsp+0x70]
000075038bdd5401  vmovaps xmm8, [rsp+0x80]
000075038bdd540a  vmovaps xmm9, [rsp+0x90]
000075038bdd5413  vmovaps xmm10, [rsp+0xA0]
000075038bdd541c  vmovaps xmm11, [rsp+0xB0]
000075038bdd5425  vmovaps xmm12, [rsp+0xC0]
000075038bdd542e  vmovaps xmm13, [rsp+0xD0]
000075038bdd5437  vmovaps xmm14, [rsp+0xE0]
000075038bdd5440  add rsp, 0xF0
000075038bdd5447  pop r11
000075038bdd5449  pop r10
000075038bdd544b  pop r9
000075038bdd544d  pop r8
000075038bdd544f  pop rsi
000075038bdd5450  pop rdi
000075038bdd5451  pop rdx
000075038bdd5452  pop rcx
000075038bdd5453  pop rax
000075038bdd5454  add rsp, 0x08
000075038bdd5458  jmp 0x000075038BDD2E1E
000075038bdd545d  sub rsp, 0x08
000075038bdd5461  push rax
000075038bdd5462  push rcx
000075038bdd5463  push rdx
000075038bdd5464  push rdi
000075038bdd5465  push rsi
000075038bdd5466  push r8
000075038bdd5468  push r9
000075038bdd546a  push r10
000075038bdd546c  push r11
000075038bdd546e  sub rsp, 0xF0
000075038bdd5475  vmovaps [rsp], xmm0
000075038bdd547a  vmovaps [rsp+0x10], xmm1
000075038bdd5480  vmovaps [rsp+0x20], xmm2
000075038bdd5486  vmovaps [rsp+0x30], xmm3
000075038bdd548c  vmovaps [rsp+0x40], xmm4
000075038bdd5492  vmovaps [rsp+0x50], xmm5
000075038bdd5498  vmovaps [rsp+0x60], xmm6
000075038bdd549e  vmovaps [rsp+0x70], xmm7
000075038bdd54a4  vmovaps [rsp+0x80], xmm8
000075038bdd54ad  vmovaps [rsp+0x90], xmm9
000075038bdd54b6  vmovaps [rsp+0xA0], xmm10
000075038bdd54bf  vmovaps [rsp+0xB0], xmm11
000075038bdd54c8  vmovaps [rsp+0xC0], xmm12
000075038bdd54d1  vmovaps [rsp+0xD0], xmm13
000075038bdd54da  vmovaps [rsp+0xE0], xmm15
000075038bdd54e3  sub rsp, 0x30
000075038bdd54e7  movaps [rsp], xmm14
000075038bdd54ec  movaps [rsp+0x10], xmm11
000075038bdd54f2  movaps [rsp+0x20], xmm1
000075038bdd54f7  lea rdi, [rsp]
000075038bdd54fb  mov esi, 0x00
000075038bdd5500  mov rax, 0x56ADB4492530
000075038bdd550a  call rax
000075038bdd550c  movaps xmm14, [rsp]
000075038bdd5511  add rsp, 0x30
000075038bdd5515  vmovaps xmm0, [rsp]
000075038bdd551a  vmovaps xmm1, [rsp+0x10]
000075038bdd5520  vmovaps xmm2, [rsp+0x20]
000075038bdd5526  vmovaps xmm3, [rsp+0x30]
000075038bdd552c  vmovaps xmm4, [rsp+0x40]
000075038bdd5532  vmovaps xmm5, [rsp+0x50]
000075038bdd5538  vmovaps xmm6, [rsp+0x60]
000075038bdd553e  vmovaps xmm7, [rsp+0x70]
000075038bdd5544  vmovaps xmm8, [rsp+0x80]
000075038bdd554d  vmovaps xmm9, [rsp+0x90]
000075038bdd5556  vmovaps xmm10, [rsp+0xA0]
000075038bdd555f  vmovaps xmm11, [rsp+0xB0]
000075038bdd5568  vmovaps xmm12, [rsp+0xC0]
000075038bdd5571  vmovaps xmm13, [rsp+0xD0]
000075038bdd557a  vmovaps xmm15, [rsp+0xE0]
000075038bdd5583  add rsp, 0xF0
000075038bdd558a  pop r11
000075038bdd558c  pop r10
000075038bdd558e  pop r9
000075038bdd5590  pop r8
000075038bdd5592  pop rsi
000075038bdd5593  pop rdi
000075038bdd5594  pop rdx
000075038bdd5595  pop rcx
000075038bdd5596  pop rax
000075038bdd5597  add rsp, 0x08
000075038bdd559b  jmp 0x000075038BDD2E48
000075038bdd55a0  sub rsp, 0x08
000075038bdd55a4  push rax
000075038bdd55a5  push rcx
000075038bdd55a6  push rdx
000075038bdd55a7  push rdi
000075038bdd55a8  push rsi
000075038bdd55a9  push r8
000075038bdd55ab  push r9
000075038bdd55ad  push r10
000075038bdd55af  push r11
000075038bdd55b1  sub rsp, 0xF0
000075038bdd55b8  vmovaps [rsp], xmm0
000075038bdd55bd  vmovaps [rsp+0x10], xmm1
000075038bdd55c3  vmovaps [rsp+0x20], xmm2
000075038bdd55c9  vmovaps [rsp+0x30], xmm3
000075038bdd55cf  vmovaps [rsp+0x40], xmm4
000075038bdd55d5  vmovaps [rsp+0x50], xmm5
000075038bdd55db  vmovaps [rsp+0x60], xmm6
000075038bdd55e1  vmovaps [rsp+0x70], xmm7
000075038bdd55e7  vmovaps [rsp+0x80], xmm8
000075038bdd55f0  vmovaps [rsp+0x90], xmm9
000075038bdd55f9  vmovaps [rsp+0xA0], xmm10
000075038bdd5602  vmovaps [rsp+0xB0], xmm11
000075038bdd560b  vmovaps [rsp+0xC0], xmm12
000075038bdd5614  vmovaps [rsp+0xD0], xmm14
000075038bdd561d  vmovaps [rsp+0xE0], xmm15
000075038bdd5626  sub rsp, 0x30
000075038bdd562a  movaps [rsp], xmm13
000075038bdd562f  movaps [rsp+0x10], xmm11
000075038bdd5635  movaps [rsp+0x20], xmm1
000075038bdd563a  lea rdi, [rsp]
000075038bdd563e  mov esi, 0x00
000075038bdd5643  mov rax, 0x56ADB4492530
000075038bdd564d  call rax
000075038bdd564f  movaps xmm13, [rsp]
000075038bdd5654  add rsp, 0x30
000075038bdd5658  vmovaps xmm0, [rsp]
000075038bdd565d  vmovaps xmm1, [rsp+0x10]
000075038bdd5663  vmovaps xmm2, [rsp+0x20]
000075038bdd5669  vmovaps xmm3, [rsp+0x30]
000075038bdd566f  vmovaps xmm4, [rsp+0x40]
000075038bdd5675  vmovaps xmm5, [rsp+0x50]
000075038bdd567b  vmovaps xmm6, [rsp+0x60]
000075038bdd5681  vmovaps xmm7, [rsp+0x70]
000075038bdd5687  vmovaps xmm8, [rsp+0x80]
000075038bdd5690  vmovaps xmm9, [rsp+0x90]
000075038bdd5699  vmovaps xmm10, [rsp+0xA0]
000075038bdd56a2  vmovaps xmm11, [rsp+0xB0]
000075038bdd56ab  vmovaps xmm12, [rsp+0xC0]
000075038bdd56b4  vmovaps xmm14, [rsp+0xD0]
000075038bdd56bd  vmovaps xmm15, [rsp+0xE0]
000075038bdd56c6  add rsp, 0xF0
000075038bdd56cd  pop r11
000075038bdd56cf  pop r10
000075038bdd56d1  pop r9
000075038bdd56d3  pop r8
000075038bdd56d5  pop rsi
000075038bdd56d6  pop rdi
000075038bdd56d7  pop rdx
000075038bdd56d8  pop rcx
000075038bdd56d9  pop rax
000075038bdd56da  add rsp, 0x08
000075038bdd56de  jmp 0x000075038BDD2E9D
000075038bdd56e3  call 0x000075038BBFF430
000075038bdd56e8  jmp 0x000075038BDD2EAA
000075038bdd56ed  sub rsp, 0x08
000075038bdd56f1  push rax
000075038bdd56f2  push rcx
000075038bdd56f3  push rdx
000075038bdd56f4  push rdi
000075038bdd56f5  push rsi
000075038bdd56f6  push r8
000075038bdd56f8  push r9
000075038bdd56fa  push r10
000075038bdd56fc  push r11
000075038bdd56fe  sub rsp, 0xF0
000075038bdd5705  vmovaps [rsp], xmm0
000075038bdd570a  vmovaps [rsp+0x10], xmm1
000075038bdd5710  vmovaps [rsp+0x20], xmm2
000075038bdd5716  vmovaps [rsp+0x30], xmm3
000075038bdd571c  vmovaps [rsp+0x40], xmm4
000075038bdd5722  vmovaps [rsp+0x50], xmm5
000075038bdd5728  vmovaps [rsp+0x60], xmm6
000075038bdd572e  vmovaps [rsp+0x70], xmm7
000075038bdd5734  vmovaps [rsp+0x80], xmm8
000075038bdd573d  vmovaps [rsp+0x90], xmm9
000075038bdd5746  vmovaps [rsp+0xA0], xmm10
000075038bdd574f  vmovaps [rsp+0xB0], xmm11
000075038bdd5758  vmovaps [rsp+0xC0], xmm12
000075038bdd5761  vmovaps [rsp+0xD0], xmm13
000075038bdd576a  vmovaps [rsp+0xE0], xmm14
000075038bdd5773  sub rsp, 0x30
000075038bdd5777  movaps [rsp], xmm15
000075038bdd577c  movaps [rsp+0x10], xmm11
000075038bdd5782  movaps [rsp+0x20], xmm1
000075038bdd5787  lea rdi, [rsp]
000075038bdd578b  mov esi, 0x00
000075038bdd5790  mov rax, 0x56ADB4492530
000075038bdd579a  call rax
000075038bdd579c  movaps xmm15, [rsp]
000075038bdd57a1  add rsp, 0x30
000075038bdd57a5  vmovaps xmm0, [rsp]
000075038bdd57aa  vmovaps xmm1, [rsp+0x10]
000075038bdd57b0  vmovaps xmm2, [rsp+0x20]
000075038bdd57b6  vmovaps xmm3, [rsp+0x30]
000075038bdd57bc  vmovaps xmm4, [rsp+0x40]
000075038bdd57c2  vmovaps xmm5, [rsp+0x50]
000075038bdd57c8  vmovaps xmm6, [rsp+0x60]
000075038bdd57ce  vmovaps xmm7, [rsp+0x70]
000075038bdd57d4  vmovaps xmm8, [rsp+0x80]
000075038bdd57dd  vmovaps xmm9, [rsp+0x90]
000075038bdd57e6  vmovaps xmm10, [rsp+0xA0]
000075038bdd57ef  vmovaps xmm11, [rsp+0xB0]
000075038bdd57f8  vmovaps xmm12, [rsp+0xC0]
000075038bdd5801  vmovaps xmm13, [rsp+0xD0]
000075038bdd580a  vmovaps xmm14, [rsp+0xE0]
000075038bdd5813  add rsp, 0xF0
000075038bdd581a  pop r11
000075038bdd581c  pop r10
000075038bdd581e  pop r9
000075038bdd5820  pop r8
000075038bdd5822  pop rsi
000075038bdd5823  pop rdi
000075038bdd5824  pop rdx
000075038bdd5825  pop rcx
000075038bdd5826  pop rax
000075038bdd5827  add rsp, 0x08
000075038bdd582b  jmp 0x000075038BDD2EE3
000075038bdd5830  sub rsp, 0x08
000075038bdd5834  push rax
000075038bdd5835  push rcx
000075038bdd5836  push rdx
000075038bdd5837  push rdi
000075038bdd5838  push rsi
000075038bdd5839  push r8
000075038bdd583b  push r9
000075038bdd583d  push r10
000075038bdd583f  push r11
000075038bdd5841  sub rsp, 0xF0
000075038bdd5848  vmovaps [rsp], xmm0
000075038bdd584d  vmovaps [rsp+0x10], xmm1
000075038bdd5853  vmovaps [rsp+0x20], xmm2
000075038bdd5859  vmovaps [rsp+0x30], xmm3
000075038bdd585f  vmovaps [rsp+0x40], xmm4
000075038bdd5865  vmovaps [rsp+0x50], xmm5
000075038bdd586b  vmovaps [rsp+0x60], xmm6
000075038bdd5871  vmovaps [rsp+0x70], xmm7
000075038bdd5877  vmovaps [rsp+0x80], xmm8
000075038bdd5880  vmovaps [rsp+0x90], xmm9
000075038bdd5889  vmovaps [rsp+0xA0], xmm10
000075038bdd5892  vmovaps [rsp+0xB0], xmm12
000075038bdd589b  vmovaps [rsp+0xC0], xmm13
000075038bdd58a4  vmovaps [rsp+0xD0], xmm14
000075038bdd58ad  vmovaps [rsp+0xE0], xmm15
000075038bdd58b6  sub rsp, 0x30
000075038bdd58ba  movaps [rsp], xmm11
000075038bdd58bf  movaps [rsp+0x10], xmm6
000075038bdd58c4  movaps [rsp+0x20], xmm14
000075038bdd58ca  lea rdi, [rsp]
000075038bdd58ce  mov esi, 0x00
000075038bdd58d3  mov rax, 0x56ADB4492530
000075038bdd58dd  call rax
000075038bdd58df  movaps xmm11, [rsp]
000075038bdd58e4  add rsp, 0x30
000075038bdd58e8  vmovaps xmm0, [rsp]
000075038bdd58ed  vmovaps xmm1, [rsp+0x10]
000075038bdd58f3  vmovaps xmm2, [rsp+0x20]
000075038bdd58f9  vmovaps xmm3, [rsp+0x30]
000075038bdd58ff  vmovaps xmm4, [rsp+0x40]
000075038bdd5905  vmovaps xmm5, [rsp+0x50]
000075038bdd590b  vmovaps xmm6, [rsp+0x60]
000075038bdd5911  vmovaps xmm7, [rsp+0x70]
000075038bdd5917  vmovaps xmm8, [rsp+0x80]
000075038bdd5920  vmovaps xmm9, [rsp+0x90]
000075038bdd5929  vmovaps xmm10, [rsp+0xA0]
000075038bdd5932  vmovaps xmm12, [rsp+0xB0]
000075038bdd593b  vmovaps xmm13, [rsp+0xC0]
000075038bdd5944  vmovaps xmm14, [rsp+0xD0]
000075038bdd594d  vmovaps xmm15, [rsp+0xE0]
000075038bdd5956  add rsp, 0xF0
000075038bdd595d  pop r11
000075038bdd595f  pop r10
000075038bdd5961  pop r9
000075038bdd5963  pop r8
000075038bdd5965  pop rsi
000075038bdd5966  pop rdi
000075038bdd5967  pop rdx
000075038bdd5968  pop rcx
000075038bdd5969  pop rax
000075038bdd596a  add rsp, 0x08
000075038bdd596e  jmp 0x000075038BDD2F5B
000075038bdd5973  call 0x000075038BBFF430
000075038bdd5978  jmp 0x000075038BDD2F65
000075038bdd597d  sub rsp, 0x08
000075038bdd5981  push rax
000075038bdd5982  push rcx
000075038bdd5983  push rdx
000075038bdd5984  push rdi
000075038bdd5985  push rsi
000075038bdd5986  push r8
000075038bdd5988  push r9
000075038bdd598a  push r10
000075038bdd598c  push r11
000075038bdd598e  sub rsp, 0xF0
000075038bdd5995  vmovaps [rsp], xmm0
000075038bdd599a  vmovaps [rsp+0x10], xmm1
000075038bdd59a0  vmovaps [rsp+0x20], xmm2
000075038bdd59a6  vmovaps [rsp+0x30], xmm3
000075038bdd59ac  vmovaps [rsp+0x40], xmm4
000075038bdd59b2  vmovaps [rsp+0x50], xmm5
000075038bdd59b8  vmovaps [rsp+0x60], xmm6
000075038bdd59be  vmovaps [rsp+0x70], xmm7
000075038bdd59c4  vmovaps [rsp+0x80], xmm8
000075038bdd59cd  vmovaps [rsp+0x90], xmm9
000075038bdd59d6  vmovaps [rsp+0xA0], xmm10
000075038bdd59df  vmovaps [rsp+0xB0], xmm11
000075038bdd59e8  vmovaps [rsp+0xC0], xmm12
000075038bdd59f1  vmovaps [rsp+0xD0], xmm13
000075038bdd59fa  vmovaps [rsp+0xE0], xmm15
000075038bdd5a03  sub rsp, 0x30
000075038bdd5a07  movaps [rsp], xmm14
000075038bdd5a0c  movaps [rsp+0x10], xmm6
000075038bdd5a11  movaps [rsp+0x20], xmm2
000075038bdd5a16  lea rdi, [rsp]
000075038bdd5a1a  mov esi, 0x00
000075038bdd5a1f  mov rax, 0x56ADB4492530
000075038bdd5a29  call rax
000075038bdd5a2b  movaps xmm14, [rsp]
000075038bdd5a30  add rsp, 0x30
000075038bdd5a34  vmovaps xmm0, [rsp]
000075038bdd5a39  vmovaps xmm1, [rsp+0x10]
000075038bdd5a3f  vmovaps xmm2, [rsp+0x20]
000075038bdd5a45  vmovaps xmm3, [rsp+0x30]
000075038bdd5a4b  vmovaps xmm4, [rsp+0x40]
000075038bdd5a51  vmovaps xmm5, [rsp+0x50]
000075038bdd5a57  vmovaps xmm6, [rsp+0x60]
000075038bdd5a5d  vmovaps xmm7, [rsp+0x70]
000075038bdd5a63  vmovaps xmm8, [rsp+0x80]
000075038bdd5a6c  vmovaps xmm9, [rsp+0x90]
000075038bdd5a75  vmovaps xmm10, [rsp+0xA0]
000075038bdd5a7e  vmovaps xmm11, [rsp+0xB0]
000075038bdd5a87  vmovaps xmm12, [rsp+0xC0]
000075038bdd5a90  vmovaps xmm13, [rsp+0xD0]
000075038bdd5a99  vmovaps xmm15, [rsp+0xE0]
000075038bdd5aa2  add rsp, 0xF0
000075038bdd5aa9  pop r11
000075038bdd5aab  pop r10
000075038bdd5aad  pop r9
000075038bdd5aaf  pop r8
000075038bdd5ab1  pop rsi
000075038bdd5ab2  pop rdi
000075038bdd5ab3  pop rdx
000075038bdd5ab4  pop rcx
000075038bdd5ab5  pop rax
000075038bdd5ab6  add rsp, 0x08
000075038bdd5aba  jmp 0x000075038BDD2F99
000075038bdd5abf  sub rsp, 0x08
000075038bdd5ac3  push rax
000075038bdd5ac4  push rcx
000075038bdd5ac5  push rdx
000075038bdd5ac6  push rdi
000075038bdd5ac7  push rsi
000075038bdd5ac8  push r8
000075038bdd5aca  push r9
000075038bdd5acc  push r10
000075038bdd5ace  push r11
000075038bdd5ad0  sub rsp, 0xF0
000075038bdd5ad7  vmovaps [rsp], xmm0
000075038bdd5adc  vmovaps [rsp+0x10], xmm1
000075038bdd5ae2  vmovaps [rsp+0x20], xmm2
000075038bdd5ae8  vmovaps [rsp+0x30], xmm3
000075038bdd5aee  vmovaps [rsp+0x40], xmm4
000075038bdd5af4  vmovaps [rsp+0x50], xmm5
000075038bdd5afa  vmovaps [rsp+0x60], xmm7
000075038bdd5b00  vmovaps [rsp+0x70], xmm8
000075038bdd5b06  vmovaps [rsp+0x80], xmm9
000075038bdd5b0f  vmovaps [rsp+0x90], xmm10
000075038bdd5b18  vmovaps [rsp+0xA0], xmm11
000075038bdd5b21  vmovaps [rsp+0xB0], xmm12
000075038bdd5b2a  vmovaps [rsp+0xC0], xmm13
000075038bdd5b33  vmovaps [rsp+0xD0], xmm14
000075038bdd5b3c  vmovaps [rsp+0xE0], xmm15
000075038bdd5b45  sub rsp, 0x30
000075038bdd5b49  movaps [rsp], xmm6
000075038bdd5b4d  movaps [rsp+0x10], xmm5
000075038bdd5b52  movaps [rsp+0x20], xmm1
000075038bdd5b57  lea rdi, [rsp]
000075038bdd5b5b  mov esi, 0x00
000075038bdd5b60  mov rax, 0x56ADB4492530
000075038bdd5b6a  call rax
000075038bdd5b6c  movaps xmm6, [rsp]
000075038bdd5b70  add rsp, 0x30
000075038bdd5b74  vmovaps xmm0, [rsp]
000075038bdd5b79  vmovaps xmm1, [rsp+0x10]
000075038bdd5b7f  vmovaps xmm2, [rsp+0x20]
000075038bdd5b85  vmovaps xmm3, [rsp+0x30]
000075038bdd5b8b  vmovaps xmm4, [rsp+0x40]
000075038bdd5b91  vmovaps xmm5, [rsp+0x50]
000075038bdd5b97  vmovaps xmm7, [rsp+0x60]
000075038bdd5b9d  vmovaps xmm8, [rsp+0x70]
000075038bdd5ba3  vmovaps xmm9, [rsp+0x80]
000075038bdd5bac  vmovaps xmm10, [rsp+0x90]
000075038bdd5bb5  vmovaps xmm11, [rsp+0xA0]
000075038bdd5bbe  vmovaps xmm12, [rsp+0xB0]
000075038bdd5bc7  vmovaps xmm13, [rsp+0xC0]
000075038bdd5bd0  vmovaps xmm14, [rsp+0xD0]
000075038bdd5bd9  vmovaps xmm15, [rsp+0xE0]
000075038bdd5be2  add rsp, 0xF0
000075038bdd5be9  pop r11
000075038bdd5beb  pop r10
000075038bdd5bed  pop r9
000075038bdd5bef  pop r8
000075038bdd5bf1  pop rsi
000075038bdd5bf2  pop rdi
000075038bdd5bf3  pop rdx
000075038bdd5bf4  pop rcx
000075038bdd5bf5  pop rax
000075038bdd5bf6  add rsp, 0x08
000075038bdd5bfa  jmp 0x000075038BDD2FBF
000075038bdd5bff  sub rsp, 0x08
000075038bdd5c03  push rax
000075038bdd5c04  push rcx
000075038bdd5c05  push rdx
000075038bdd5c06  push rdi
000075038bdd5c07  push rsi
000075038bdd5c08  push r8
000075038bdd5c0a  push r9
000075038bdd5c0c  push r10
000075038bdd5c0e  push r11
000075038bdd5c10  sub rsp, 0xF0
000075038bdd5c17  vmovaps [rsp], xmm0
000075038bdd5c1c  vmovaps [rsp+0x10], xmm2
000075038bdd5c22  vmovaps [rsp+0x20], xmm3
000075038bdd5c28  vmovaps [rsp+0x30], xmm4
000075038bdd5c2e  vmovaps [rsp+0x40], xmm5
000075038bdd5c34  vmovaps [rsp+0x50], xmm6
000075038bdd5c3a  vmovaps [rsp+0x60], xmm7
000075038bdd5c40  vmovaps [rsp+0x70], xmm8
000075038bdd5c46  vmovaps [rsp+0x80], xmm9
000075038bdd5c4f  vmovaps [rsp+0x90], xmm10
000075038bdd5c58  vmovaps [rsp+0xA0], xmm11
000075038bdd5c61  vmovaps [rsp+0xB0], xmm12
000075038bdd5c6a  vmovaps [rsp+0xC0], xmm13
000075038bdd5c73  vmovaps [rsp+0xD0], xmm14
000075038bdd5c7c  vmovaps [rsp+0xE0], xmm15
000075038bdd5c85  sub rsp, 0x30
000075038bdd5c89  movaps [rsp], xmm1
000075038bdd5c8d  movaps [rsp+0x10], xmm5
000075038bdd5c92  movaps [rsp+0x20], xmm13
000075038bdd5c98  lea rdi, [rsp]
000075038bdd5c9c  mov esi, 0x00
000075038bdd5ca1  mov rax, 0x56ADB4492530
000075038bdd5cab  call rax
000075038bdd5cad  movaps xmm1, [rsp]
000075038bdd5cb1  add rsp, 0x30
000075038bdd5cb5  vmovaps xmm0, [rsp]
000075038bdd5cba  vmovaps xmm2, [rsp+0x10]
000075038bdd5cc0  vmovaps xmm3, [rsp+0x20]
000075038bdd5cc6  vmovaps xmm4, [rsp+0x30]
000075038bdd5ccc  vmovaps xmm5, [rsp+0x40]
000075038bdd5cd2  vmovaps xmm6, [rsp+0x50]
000075038bdd5cd8  vmovaps xmm7, [rsp+0x60]
000075038bdd5cde  vmovaps xmm8, [rsp+0x70]
000075038bdd5ce4  vmovaps xmm9, [rsp+0x80]
000075038bdd5ced  vmovaps xmm10, [rsp+0x90]
000075038bdd5cf6  vmovaps xmm11, [rsp+0xA0]
000075038bdd5cff  vmovaps xmm12, [rsp+0xB0]
000075038bdd5d08  vmovaps xmm13, [rsp+0xC0]
000075038bdd5d11  vmovaps xmm14, [rsp+0xD0]
000075038bdd5d1a  vmovaps xmm15, [rsp+0xE0]
000075038bdd5d23  add rsp, 0xF0
000075038bdd5d2a  pop r11
000075038bdd5d2c  pop r10
000075038bdd5d2e  pop r9
000075038bdd5d30  pop r8
000075038bdd5d32  pop rsi
000075038bdd5d33  pop rdi
000075038bdd5d34  pop rdx
000075038bdd5d35  pop rcx
000075038bdd5d36  pop rax
000075038bdd5d37  add rsp, 0x08
000075038bdd5d3b  jmp 0x000075038BDD2FDD
000075038bdd5d40  sub rsp, 0x08
000075038bdd5d44  push rax
000075038bdd5d45  push rcx
000075038bdd5d46  push rdx
000075038bdd5d47  push rdi
000075038bdd5d48  push rsi
000075038bdd5d49  push r8
000075038bdd5d4b  push r9
000075038bdd5d4d  push r10
000075038bdd5d4f  push r11
000075038bdd5d51  sub rsp, 0xF0
000075038bdd5d58  vmovaps [rsp], xmm0
000075038bdd5d5d  vmovaps [rsp+0x10], xmm1
000075038bdd5d63  vmovaps [rsp+0x20], xmm2
000075038bdd5d69  vmovaps [rsp+0x30], xmm3
000075038bdd5d6f  vmovaps [rsp+0x40], xmm4
000075038bdd5d75  vmovaps [rsp+0x50], xmm6
000075038bdd5d7b  vmovaps [rsp+0x60], xmm7
000075038bdd5d81  vmovaps [rsp+0x70], xmm8
000075038bdd5d87  vmovaps [rsp+0x80], xmm9
000075038bdd5d90  vmovaps [rsp+0x90], xmm10
000075038bdd5d99  vmovaps [rsp+0xA0], xmm11
000075038bdd5da2  vmovaps [rsp+0xB0], xmm12
000075038bdd5dab  vmovaps [rsp+0xC0], xmm13
000075038bdd5db4  vmovaps [rsp+0xD0], xmm14
000075038bdd5dbd  vmovaps [rsp+0xE0], xmm15
000075038bdd5dc6  sub rsp, 0x30
000075038bdd5dca  movaps [rsp], xmm5
000075038bdd5dce  movaps [rsp+0x10], xmm2
000075038bdd5dd3  movaps [rsp+0x20], xmm13
000075038bdd5dd9  lea rdi, [rsp]
000075038bdd5ddd  mov esi, 0x00
000075038bdd5de2  mov rax, 0x56ADB4492530
000075038bdd5dec  call rax
000075038bdd5dee  movaps xmm5, [rsp]
000075038bdd5df2  add rsp, 0x30
000075038bdd5df6  vmovaps xmm0, [rsp]
000075038bdd5dfb  vmovaps xmm1, [rsp+0x10]
000075038bdd5e01  vmovaps xmm2, [rsp+0x20]
000075038bdd5e07  vmovaps xmm3, [rsp+0x30]
000075038bdd5e0d  vmovaps xmm4, [rsp+0x40]
000075038bdd5e13  vmovaps xmm6, [rsp+0x50]
000075038bdd5e19  vmovaps xmm7, [rsp+0x60]
000075038bdd5e1f  vmovaps xmm8, [rsp+0x70]
000075038bdd5e25  vmovaps xmm9, [rsp+0x80]
000075038bdd5e2e  vmovaps xmm10, [rsp+0x90]
000075038bdd5e37  vmovaps xmm11, [rsp+0xA0]
000075038bdd5e40  vmovaps xmm12, [rsp+0xB0]
000075038bdd5e49  vmovaps xmm13, [rsp+0xC0]
000075038bdd5e52  vmovaps xmm14, [rsp+0xD0]
000075038bdd5e5b  vmovaps xmm15, [rsp+0xE0]
000075038bdd5e64  add rsp, 0xF0
000075038bdd5e6b  pop r11
000075038bdd5e6d  pop r10
000075038bdd5e6f  pop r9
000075038bdd5e71  pop r8
000075038bdd5e73  pop rsi
000075038bdd5e74  pop rdi
000075038bdd5e75  pop rdx
000075038bdd5e76  pop rcx
000075038bdd5e77  pop rax
000075038bdd5e78  add rsp, 0x08
000075038bdd5e7c  jmp 0x000075038BDD3013
000075038bdd5e81  sub rsp, 0x08
000075038bdd5e85  push rax
000075038bdd5e86  push rcx
000075038bdd5e87  push rdx
000075038bdd5e88  push rdi
000075038bdd5e89  push rsi
000075038bdd5e8a  push r8
000075038bdd5e8c  push r9
000075038bdd5e8e  push r10
000075038bdd5e90  push r11
000075038bdd5e92  sub rsp, 0xF0
000075038bdd5e99  vmovaps [rsp], xmm0
000075038bdd5e9e  vmovaps [rsp+0x10], xmm1
000075038bdd5ea4  vmovaps [rsp+0x20], xmm2
000075038bdd5eaa  vmovaps [rsp+0x30], xmm3
000075038bdd5eb0  vmovaps [rsp+0x40], xmm4
000075038bdd5eb6  vmovaps [rsp+0x50], xmm5
000075038bdd5ebc  vmovaps [rsp+0x60], xmm6
000075038bdd5ec2  vmovaps [rsp+0x70], xmm7
000075038bdd5ec8  vmovaps [rsp+0x80], xmm8
000075038bdd5ed1  vmovaps [rsp+0x90], xmm9
000075038bdd5eda  vmovaps [rsp+0xA0], xmm10
000075038bdd5ee3  vmovaps [rsp+0xB0], xmm11
000075038bdd5eec  vmovaps [rsp+0xC0], xmm12
000075038bdd5ef5  vmovaps [rsp+0xD0], xmm14
000075038bdd5efe  vmovaps [rsp+0xE0], xmm15
000075038bdd5f07  sub rsp, 0x30
000075038bdd5f0b  movaps [rsp], xmm13
000075038bdd5f10  movaps [rsp+0x10], xmm10
000075038bdd5f16  movaps [rsp+0x20], xmm1
000075038bdd5f1b  lea rdi, [rsp]
000075038bdd5f1f  mov esi, 0x00
000075038bdd5f24  mov rax, 0x56ADB4492530
000075038bdd5f2e  call rax
000075038bdd5f30  movaps xmm13, [rsp]
000075038bdd5f35  add rsp, 0x30
000075038bdd5f39  vmovaps xmm0, [rsp]
000075038bdd5f3e  vmovaps xmm1, [rsp+0x10]
000075038bdd5f44  vmovaps xmm2, [rsp+0x20]
000075038bdd5f4a  vmovaps xmm3, [rsp+0x30]
000075038bdd5f50  vmovaps xmm4, [rsp+0x40]
000075038bdd5f56  vmovaps xmm5, [rsp+0x50]
000075038bdd5f5c  vmovaps xmm6, [rsp+0x60]
000075038bdd5f62  vmovaps xmm7, [rsp+0x70]
000075038bdd5f68  vmovaps xmm8, [rsp+0x80]
000075038bdd5f71  vmovaps xmm9, [rsp+0x90]
000075038bdd5f7a  vmovaps xmm10, [rsp+0xA0]
000075038bdd5f83  vmovaps xmm11, [rsp+0xB0]
000075038bdd5f8c  vmovaps xmm12, [rsp+0xC0]
000075038bdd5f95  vmovaps xmm14, [rsp+0xD0]
000075038bdd5f9e  vmovaps xmm15, [rsp+0xE0]
000075038bdd5fa7  add rsp, 0xF0
000075038bdd5fae  pop r11
000075038bdd5fb0  pop r10
000075038bdd5fb2  pop r9
000075038bdd5fb4  pop r8
000075038bdd5fb6  pop rsi
000075038bdd5fb7  pop rdi
000075038bdd5fb8  pop rdx
000075038bdd5fb9  pop rcx
000075038bdd5fba  pop rax
000075038bdd5fbb  add rsp, 0x08
000075038bdd5fbf  jmp 0x000075038BDD303C
000075038bdd5fc4  sub rsp, 0x08
000075038bdd5fc8  push rax
000075038bdd5fc9  push rcx
000075038bdd5fca  push rdx
000075038bdd5fcb  push rdi
000075038bdd5fcc  push rsi
000075038bdd5fcd  push r8
000075038bdd5fcf  push r9
000075038bdd5fd1  push r10
000075038bdd5fd3  push r11
000075038bdd5fd5  sub rsp, 0xF0
000075038bdd5fdc  vmovaps [rsp], xmm0
000075038bdd5fe1  vmovaps [rsp+0x10], xmm2
000075038bdd5fe7  vmovaps [rsp+0x20], xmm3
000075038bdd5fed  vmovaps [rsp+0x30], xmm4
000075038bdd5ff3  vmovaps [rsp+0x40], xmm5
000075038bdd5ff9  vmovaps [rsp+0x50], xmm6
000075038bdd5fff  vmovaps [rsp+0x60], xmm7
000075038bdd6005  vmovaps [rsp+0x70], xmm8
000075038bdd600b  vmovaps [rsp+0x80], xmm9
000075038bdd6014  vmovaps [rsp+0x90], xmm10
000075038bdd601d  vmovaps [rsp+0xA0], xmm11
000075038bdd6026  vmovaps [rsp+0xB0], xmm12
000075038bdd602f  vmovaps [rsp+0xC0], xmm13
000075038bdd6038  vmovaps [rsp+0xD0], xmm14
000075038bdd6041  vmovaps [rsp+0xE0], xmm15
000075038bdd604a  sub rsp, 0x30
000075038bdd604e  movaps [rsp], xmm1
000075038bdd6052  movaps [rsp+0x10], xmm15
000075038bdd6058  movaps [rsp+0x20], xmm10
000075038bdd605e  lea rdi, [rsp]
000075038bdd6062  mov esi, 0x00
000075038bdd6067  mov rax, 0x56ADB4492530
000075038bdd6071  call rax
000075038bdd6073  movaps xmm1, [rsp]
000075038bdd6077  add rsp, 0x30
000075038bdd607b  vmovaps xmm0, [rsp]
000075038bdd6080  vmovaps xmm2, [rsp+0x10]
000075038bdd6086  vmovaps xmm3, [rsp+0x20]
000075038bdd608c  vmovaps xmm4, [rsp+0x30]
000075038bdd6092  vmovaps xmm5, [rsp+0x40]
000075038bdd6098  vmovaps xmm6, [rsp+0x50]
000075038bdd609e  vmovaps xmm7, [rsp+0x60]
000075038bdd60a4  vmovaps xmm8, [rsp+0x70]
000075038bdd60aa  vmovaps xmm9, [rsp+0x80]
000075038bdd60b3  vmovaps xmm10, [rsp+0x90]
000075038bdd60bc  vmovaps xmm11, [rsp+0xA0]
000075038bdd60c5  vmovaps xmm12, [rsp+0xB0]
000075038bdd60ce  vmovaps xmm13, [rsp+0xC0]
000075038bdd60d7  vmovaps xmm14, [rsp+0xD0]
000075038bdd60e0  vmovaps xmm15, [rsp+0xE0]
000075038bdd60e9  add rsp, 0xF0
000075038bdd60f0  pop r11
000075038bdd60f2  pop r10
000075038bdd60f4  pop r9
000075038bdd60f6  pop r8
000075038bdd60f8  pop rsi
000075038bdd60f9  pop rdi
000075038bdd60fa  pop rdx
000075038bdd60fb  pop rcx
000075038bdd60fc  pop rax
000075038bdd60fd  add rsp, 0x08
000075038bdd6101  jmp 0x000075038BDD305B
000075038bdd6106  sub rsp, 0x08
000075038bdd610a  push rax
000075038bdd610b  push rcx
000075038bdd610c  push rdx
000075038bdd610d  push rdi
000075038bdd610e  push rsi
000075038bdd610f  push r8
000075038bdd6111  push r9
000075038bdd6113  push r10
000075038bdd6115  push r11
000075038bdd6117  sub rsp, 0xF0
000075038bdd611e  vmovaps [rsp], xmm0
000075038bdd6123  vmovaps [rsp+0x10], xmm1
000075038bdd6129  vmovaps [rsp+0x20], xmm2
000075038bdd612f  vmovaps [rsp+0x30], xmm3
000075038bdd6135  vmovaps [rsp+0x40], xmm4
000075038bdd613b  vmovaps [rsp+0x50], xmm5
000075038bdd6141  vmovaps [rsp+0x60], xmm6
000075038bdd6147  vmovaps [rsp+0x70], xmm7
000075038bdd614d  vmovaps [rsp+0x80], xmm8
000075038bdd6156  vmovaps [rsp+0x90], xmm9
000075038bdd615f  vmovaps [rsp+0xA0], xmm10
000075038bdd6168  vmovaps [rsp+0xB0], xmm11
000075038bdd6171  vmovaps [rsp+0xC0], xmm12
000075038bdd617a  vmovaps [rsp+0xD0], xmm13
000075038bdd6183  vmovaps [rsp+0xE0], xmm14
000075038bdd618c  sub rsp, 0x30
000075038bdd6190  movaps [rsp], xmm15
000075038bdd6195  movaps [rsp+0x10], xmm10
000075038bdd619b  movaps [rsp+0x20], xmm11
000075038bdd61a1  lea rdi, [rsp]
000075038bdd61a5  mov esi, 0x00
000075038bdd61aa  mov rax, 0x56ADB4492530
000075038bdd61b4  call rax
000075038bdd61b6  movaps xmm15, [rsp]
000075038bdd61bb  add rsp, 0x30
000075038bdd61bf  vmovaps xmm0, [rsp]
000075038bdd61c4  vmovaps xmm1, [rsp+0x10]
000075038bdd61ca  vmovaps xmm2, [rsp+0x20]
000075038bdd61d0  vmovaps xmm3, [rsp+0x30]
000075038bdd61d6  vmovaps xmm4, [rsp+0x40]
000075038bdd61dc  vmovaps xmm5, [rsp+0x50]
000075038bdd61e2  vmovaps xmm6, [rsp+0x60]
000075038bdd61e8  vmovaps xmm7, [rsp+0x70]
000075038bdd61ee  vmovaps xmm8, [rsp+0x80]
000075038bdd61f7  vmovaps xmm9, [rsp+0x90]
000075038bdd6200  vmovaps xmm10, [rsp+0xA0]
000075038bdd6209  vmovaps xmm11, [rsp+0xB0]
000075038bdd6212  vmovaps xmm12, [rsp+0xC0]
000075038bdd621b  vmovaps xmm13, [rsp+0xD0]
000075038bdd6224  vmovaps xmm14, [rsp+0xE0]
000075038bdd622d  add rsp, 0xF0
000075038bdd6234  pop r11
000075038bdd6236  pop r10
000075038bdd6238  pop r9
000075038bdd623a  pop r8
000075038bdd623c  pop rsi
000075038bdd623d  pop rdi
000075038bdd623e  pop rdx
000075038bdd623f  pop rcx
000075038bdd6240  pop rax
000075038bdd6241  add rsp, 0x08
000075038bdd6245  jmp 0x000075038BDD307E
000075038bdd624a  sub rsp, 0x08
000075038bdd624e  push rax
000075038bdd624f  push rcx
000075038bdd6250  push rdx
000075038bdd6251  push rdi
000075038bdd6252  push rsi
000075038bdd6253  push r8
000075038bdd6255  push r9
000075038bdd6257  push r10
000075038bdd6259  push r11
000075038bdd625b  sub rsp, 0xF0
000075038bdd6262  vmovaps [rsp], xmm0
000075038bdd6267  vmovaps [rsp+0x10], xmm1
000075038bdd626d  vmovaps [rsp+0x20], xmm2
000075038bdd6273  vmovaps [rsp+0x30], xmm3
000075038bdd6279  vmovaps [rsp+0x40], xmm4
000075038bdd627f  vmovaps [rsp+0x50], xmm5
000075038bdd6285  vmovaps [rsp+0x60], xmm6
000075038bdd628b  vmovaps [rsp+0x70], xmm7
000075038bdd6291  vmovaps [rsp+0x80], xmm8
000075038bdd629a  vmovaps [rsp+0x90], xmm9
000075038bdd62a3  vmovaps [rsp+0xA0], xmm11
000075038bdd62ac  vmovaps [rsp+0xB0], xmm12
000075038bdd62b5  vmovaps [rsp+0xC0], xmm13
000075038bdd62be  vmovaps [rsp+0xD0], xmm14
000075038bdd62c7  vmovaps [rsp+0xE0], xmm15
000075038bdd62d0  sub rsp, 0x30
000075038bdd62d4  movaps [rsp], xmm10
000075038bdd62d9  movaps [rsp+0x10], xmm2
000075038bdd62de  movaps [rsp+0x20], xmm11
000075038bdd62e4  lea rdi, [rsp]
000075038bdd62e8  mov esi, 0x00
000075038bdd62ed  mov rax, 0x56ADB4492530
000075038bdd62f7  call rax
000075038bdd62f9  movaps xmm10, [rsp]
000075038bdd62fe  add rsp, 0x30
000075038bdd6302  vmovaps xmm0, [rsp]
000075038bdd6307  vmovaps xmm1, [rsp+0x10]
000075038bdd630d  vmovaps xmm2, [rsp+0x20]
000075038bdd6313  vmovaps xmm3, [rsp+0x30]
000075038bdd6319  vmovaps xmm4, [rsp+0x40]
000075038bdd631f  vmovaps xmm5, [rsp+0x50]
000075038bdd6325  vmovaps xmm6, [rsp+0x60]
000075038bdd632b  vmovaps xmm7, [rsp+0x70]
000075038bdd6331  vmovaps xmm8, [rsp+0x80]
000075038bdd633a  vmovaps xmm9, [rsp+0x90]
000075038bdd6343  vmovaps xmm11, [rsp+0xA0]
000075038bdd634c  vmovaps xmm12, [rsp+0xB0]
000075038bdd6355  vmovaps xmm13, [rsp+0xC0]
000075038bdd635e  vmovaps xmm14, [rsp+0xD0]
000075038bdd6367  vmovaps xmm15, [rsp+0xE0]
000075038bdd6370  add rsp, 0xF0
000075038bdd6377  pop r11
000075038bdd6379  pop r10
000075038bdd637b  pop r9
000075038bdd637d  pop r8
000075038bdd637f  pop rsi
000075038bdd6380  pop rdi
000075038bdd6381  pop rdx
000075038bdd6382  pop rcx
000075038bdd6383  pop rax
000075038bdd6384  add rsp, 0x08
000075038bdd6388  jmp 0x000075038BDD30B6
000075038bdd638d  sub rsp, 0x08
000075038bdd6391  push rax
000075038bdd6392  push rcx
000075038bdd6393  push rdx
000075038bdd6394  push rdi
000075038bdd6395  push rsi
000075038bdd6396  push r8
000075038bdd6398  push r9
000075038bdd639a  push r10
000075038bdd639c  push r11
000075038bdd639e  sub rsp, 0xF0
000075038bdd63a5  vmovaps [rsp], xmm0
000075038bdd63aa  vmovaps [rsp+0x10], xmm1
000075038bdd63b0  vmovaps [rsp+0x20], xmm2
000075038bdd63b6  vmovaps [rsp+0x30], xmm3
000075038bdd63bc  vmovaps [rsp+0x40], xmm4
000075038bdd63c2  vmovaps [rsp+0x50], xmm5
000075038bdd63c8  vmovaps [rsp+0x60], xmm6
000075038bdd63ce  vmovaps [rsp+0x70], xmm7
000075038bdd63d4  vmovaps [rsp+0x80], xmm8
000075038bdd63dd  vmovaps [rsp+0x90], xmm9
000075038bdd63e6  vmovaps [rsp+0xA0], xmm10
000075038bdd63ef  vmovaps [rsp+0xB0], xmm12
000075038bdd63f8  vmovaps [rsp+0xC0], xmm13
000075038bdd6401  vmovaps [rsp+0xD0], xmm14
000075038bdd640a  vmovaps [rsp+0xE0], xmm15
000075038bdd6413  sub rsp, 0x30
000075038bdd6417  movaps [rsp], xmm11
000075038bdd641c  movaps [rsp+0x10], xmm2
000075038bdd6421  movaps [rsp+0x20], xmm1
000075038bdd6426  lea rdi, [rsp]
000075038bdd642a  mov esi, 0x00
000075038bdd642f  mov rax, 0x56ADB4492530
000075038bdd6439  call rax
000075038bdd643b  movaps xmm11, [rsp]
000075038bdd6440  add rsp, 0x30
000075038bdd6444  vmovaps xmm0, [rsp]
000075038bdd6449  vmovaps xmm1, [rsp+0x10]
000075038bdd644f  vmovaps xmm2, [rsp+0x20]
000075038bdd6455  vmovaps xmm3, [rsp+0x30]
000075038bdd645b  vmovaps xmm4, [rsp+0x40]
000075038bdd6461  vmovaps xmm5, [rsp+0x50]
000075038bdd6467  vmovaps xmm6, [rsp+0x60]
000075038bdd646d  vmovaps xmm7, [rsp+0x70]
000075038bdd6473  vmovaps xmm8, [rsp+0x80]
000075038bdd647c  vmovaps xmm9, [rsp+0x90]
000075038bdd6485  vmovaps xmm10, [rsp+0xA0]
000075038bdd648e  vmovaps xmm12, [rsp+0xB0]
000075038bdd6497  vmovaps xmm13, [rsp+0xC0]
000075038bdd64a0  vmovaps xmm14, [rsp+0xD0]
000075038bdd64a9  vmovaps xmm15, [rsp+0xE0]
000075038bdd64b2  add rsp, 0xF0
000075038bdd64b9  pop r11
000075038bdd64bb  pop r10
000075038bdd64bd  pop r9
000075038bdd64bf  pop r8
000075038bdd64c1  pop rsi
000075038bdd64c2  pop rdi
000075038bdd64c3  pop rdx
000075038bdd64c4  pop rcx
000075038bdd64c5  pop rax
000075038bdd64c6  add rsp, 0x08
000075038bdd64ca  jmp 0x000075038BDD30F2
000075038bdd64cf  sub rsp, 0x08
000075038bdd64d3  push rax
000075038bdd64d4  push rcx
000075038bdd64d5  push rdx
000075038bdd64d6  push rdi
000075038bdd64d7  push rsi
000075038bdd64d8  push r8
000075038bdd64da  push r9
000075038bdd64dc  push r10
000075038bdd64de  push r11
000075038bdd64e0  sub rsp, 0xF0
000075038bdd64e7  vmovaps [rsp], xmm0
000075038bdd64ec  vmovaps [rsp+0x10], xmm2
000075038bdd64f2  vmovaps [rsp+0x20], xmm3
000075038bdd64f8  vmovaps [rsp+0x30], xmm4
000075038bdd64fe  vmovaps [rsp+0x40], xmm5
000075038bdd6504  vmovaps [rsp+0x50], xmm6
000075038bdd650a  vmovaps [rsp+0x60], xmm7
000075038bdd6510  vmovaps [rsp+0x70], xmm8
000075038bdd6516  vmovaps [rsp+0x80], xmm9
000075038bdd651f  vmovaps [rsp+0x90], xmm10
000075038bdd6528  vmovaps [rsp+0xA0], xmm11
000075038bdd6531  vmovaps [rsp+0xB0], xmm12
000075038bdd653a  vmovaps [rsp+0xC0], xmm13
000075038bdd6543  vmovaps [rsp+0xD0], xmm14
000075038bdd654c  vmovaps [rsp+0xE0], xmm15
000075038bdd6555  sub rsp, 0x30
000075038bdd6559  movaps [rsp], xmm1
000075038bdd655d  movaps [rsp+0x10], xmm14
000075038bdd6563  movaps [rsp+0x20], xmm6
000075038bdd6568  lea rdi, [rsp]
000075038bdd656c  mov esi, 0x00
000075038bdd6571  mov rax, 0x56ADB4492530
000075038bdd657b  call rax
000075038bdd657d  movaps xmm1, [rsp]
000075038bdd6581  add rsp, 0x30
000075038bdd6585  vmovaps xmm0, [rsp]
000075038bdd658a  vmovaps xmm2, [rsp+0x10]
000075038bdd6590  vmovaps xmm3, [rsp+0x20]
000075038bdd6596  vmovaps xmm4, [rsp+0x30]
000075038bdd659c  vmovaps xmm5, [rsp+0x40]
000075038bdd65a2  vmovaps xmm6, [rsp+0x50]
000075038bdd65a8  vmovaps xmm7, [rsp+0x60]
000075038bdd65ae  vmovaps xmm8, [rsp+0x70]
000075038bdd65b4  vmovaps xmm9, [rsp+0x80]
000075038bdd65bd  vmovaps xmm10, [rsp+0x90]
000075038bdd65c6  vmovaps xmm11, [rsp+0xA0]
000075038bdd65cf  vmovaps xmm12, [rsp+0xB0]
000075038bdd65d8  vmovaps xmm13, [rsp+0xC0]
000075038bdd65e1  vmovaps xmm14, [rsp+0xD0]
000075038bdd65ea  vmovaps xmm15, [rsp+0xE0]
000075038bdd65f3  add rsp, 0xF0
000075038bdd65fa  pop r11
000075038bdd65fc  pop r10
000075038bdd65fe  pop r9
000075038bdd6600  pop r8
000075038bdd6602  pop rsi
000075038bdd6603  pop rdi
000075038bdd6604  pop rdx
000075038bdd6605  pop rcx
000075038bdd6606  pop rax
000075038bdd6607  add rsp, 0x08
000075038bdd660b  jmp 0x000075038BDD310B
000075038bdd6610  sub rsp, 0x08
000075038bdd6614  push rax
000075038bdd6615  push rcx
000075038bdd6616  push rdx
000075038bdd6617  push rdi
000075038bdd6618  push rsi
000075038bdd6619  push r8
000075038bdd661b  push r9
000075038bdd661d  push r10
000075038bdd661f  push r11
000075038bdd6621  sub rsp, 0xF0
000075038bdd6628  vmovaps [rsp], xmm0
000075038bdd662d  vmovaps [rsp+0x10], xmm1
000075038bdd6633  vmovaps [rsp+0x20], xmm2
000075038bdd6639  vmovaps [rsp+0x30], xmm3
000075038bdd663f  vmovaps [rsp+0x40], xmm4
000075038bdd6645  vmovaps [rsp+0x50], xmm5
000075038bdd664b  vmovaps [rsp+0x60], xmm6
000075038bdd6651  vmovaps [rsp+0x70], xmm7
000075038bdd6657  vmovaps [rsp+0x80], xmm8
000075038bdd6660  vmovaps [rsp+0x90], xmm9
000075038bdd6669  vmovaps [rsp+0xA0], xmm10
000075038bdd6672  vmovaps [rsp+0xB0], xmm11
000075038bdd667b  vmovaps [rsp+0xC0], xmm12
000075038bdd6684  vmovaps [rsp+0xD0], xmm13
000075038bdd668d  vmovaps [rsp+0xE0], xmm14
000075038bdd6696  sub rsp, 0x30
000075038bdd669a  movaps [rsp], xmm15
000075038bdd669f  movaps [rsp+0x10], xmm14
000075038bdd66a5  movaps [rsp+0x20], xmm5
000075038bdd66aa  lea rdi, [rsp]
000075038bdd66ae  mov esi, 0x00
000075038bdd66b3  mov rax, 0x56ADB4492530
000075038bdd66bd  call rax
000075038bdd66bf  movaps xmm15, [rsp]
000075038bdd66c4  add rsp, 0x30
000075038bdd66c8  vmovaps xmm0, [rsp]
000075038bdd66cd  vmovaps xmm1, [rsp+0x10]
000075038bdd66d3  vmovaps xmm2, [rsp+0x20]
000075038bdd66d9  vmovaps xmm3, [rsp+0x30]
000075038bdd66df  vmovaps xmm4, [rsp+0x40]
000075038bdd66e5  vmovaps xmm5, [rsp+0x50]
000075038bdd66eb  vmovaps xmm6, [rsp+0x60]
000075038bdd66f1  vmovaps xmm7, [rsp+0x70]
000075038bdd66f7  vmovaps xmm8, [rsp+0x80]
000075038bdd6700  vmovaps xmm9, [rsp+0x90]
000075038bdd6709  vmovaps xmm10, [rsp+0xA0]
000075038bdd6712  vmovaps xmm11, [rsp+0xB0]
000075038bdd671b  vmovaps xmm12, [rsp+0xC0]
000075038bdd6724  vmovaps xmm13, [rsp+0xD0]
000075038bdd672d  vmovaps xmm14, [rsp+0xE0]
000075038bdd6736  add rsp, 0xF0
000075038bdd673d  pop r11
000075038bdd673f  pop r10
000075038bdd6741  pop r9
000075038bdd6743  pop r8
000075038bdd6745  pop rsi
000075038bdd6746  pop rdi
000075038bdd6747  pop rdx
000075038bdd6748  pop rcx
000075038bdd6749  pop rax
000075038bdd674a  add rsp, 0x08
000075038bdd674e  jmp 0x000075038BDD312B
000075038bdd6753  sub rsp, 0x08
000075038bdd6757  push rax
000075038bdd6758  push rcx
000075038bdd6759  push rdx
000075038bdd675a  push rdi
000075038bdd675b  push rsi
000075038bdd675c  push r8
000075038bdd675e  push r9
000075038bdd6760  push r10
000075038bdd6762  push r11
000075038bdd6764  sub rsp, 0xF0
000075038bdd676b  vmovaps [rsp], xmm0
000075038bdd6770  vmovaps [rsp+0x10], xmm1
000075038bdd6776  vmovaps [rsp+0x20], xmm2
000075038bdd677c  vmovaps [rsp+0x30], xmm3
000075038bdd6782  vmovaps [rsp+0x40], xmm4
000075038bdd6788  vmovaps [rsp+0x50], xmm5
000075038bdd678e  vmovaps [rsp+0x60], xmm7
000075038bdd6794  vmovaps [rsp+0x70], xmm8
000075038bdd679a  vmovaps [rsp+0x80], xmm9
000075038bdd67a3  vmovaps [rsp+0x90], xmm10
000075038bdd67ac  vmovaps [rsp+0xA0], xmm11
000075038bdd67b5  vmovaps [rsp+0xB0], xmm12
000075038bdd67be  vmovaps [rsp+0xC0], xmm13
000075038bdd67c7  vmovaps [rsp+0xD0], xmm14
000075038bdd67d0  vmovaps [rsp+0xE0], xmm15
000075038bdd67d9  sub rsp, 0x30
000075038bdd67dd  movaps [rsp], xmm6
000075038bdd67e1  movaps [rsp+0x10], xmm9
000075038bdd67e7  movaps [rsp+0x20], xmm14
000075038bdd67ed  lea rdi, [rsp]
000075038bdd67f1  mov esi, 0x00
000075038bdd67f6  mov rax, 0x56ADB4492530
000075038bdd6800  call rax
000075038bdd6802  movaps xmm6, [rsp]
000075038bdd6806  add rsp, 0x30
000075038bdd680a  vmovaps xmm0, [rsp]
000075038bdd680f  vmovaps xmm1, [rsp+0x10]
000075038bdd6815  vmovaps xmm2, [rsp+0x20]
000075038bdd681b  vmovaps xmm3, [rsp+0x30]
000075038bdd6821  vmovaps xmm4, [rsp+0x40]
000075038bdd6827  vmovaps xmm5, [rsp+0x50]
000075038bdd682d  vmovaps xmm7, [rsp+0x60]
000075038bdd6833  vmovaps xmm8, [rsp+0x70]
000075038bdd6839  vmovaps xmm9, [rsp+0x80]
000075038bdd6842  vmovaps xmm10, [rsp+0x90]
000075038bdd684b  vmovaps xmm11, [rsp+0xA0]
000075038bdd6854  vmovaps xmm12, [rsp+0xB0]
000075038bdd685d  vmovaps xmm13, [rsp+0xC0]
000075038bdd6866  vmovaps xmm14, [rsp+0xD0]
000075038bdd686f  vmovaps xmm15, [rsp+0xE0]
000075038bdd6878  add rsp, 0xF0
000075038bdd687f  pop r11
000075038bdd6881  pop r10
000075038bdd6883  pop r9
000075038bdd6885  pop r8
000075038bdd6887  pop rsi
000075038bdd6888  pop rdi
000075038bdd6889  pop rdx
000075038bdd688a  pop rcx
000075038bdd688b  pop rax
000075038bdd688c  add rsp, 0x08
000075038bdd6890  jmp 0x000075038BDD3153
000075038bdd6895  sub rsp, 0x08
000075038bdd6899  push rax
000075038bdd689a  push rcx
000075038bdd689b  push rdx
000075038bdd689c  push rdi
000075038bdd689d  push rsi
000075038bdd689e  push r8
000075038bdd68a0  push r9
000075038bdd68a2  push r10
000075038bdd68a4  push r11
000075038bdd68a6  sub rsp, 0xF0
000075038bdd68ad  vmovaps [rsp], xmm0
000075038bdd68b2  vmovaps [rsp+0x10], xmm1
000075038bdd68b8  vmovaps [rsp+0x20], xmm2
000075038bdd68be  vmovaps [rsp+0x30], xmm3
000075038bdd68c4  vmovaps [rsp+0x40], xmm4
000075038bdd68ca  vmovaps [rsp+0x50], xmm5
000075038bdd68d0  vmovaps [rsp+0x60], xmm6
000075038bdd68d6  vmovaps [rsp+0x70], xmm7
000075038bdd68dc  vmovaps [rsp+0x80], xmm8
000075038bdd68e5  vmovaps [rsp+0x90], xmm9
000075038bdd68ee  vmovaps [rsp+0xA0], xmm10
000075038bdd68f7  vmovaps [rsp+0xB0], xmm11
000075038bdd6900  vmovaps [rsp+0xC0], xmm12
000075038bdd6909  vmovaps [rsp+0xD0], xmm13
000075038bdd6912  vmovaps [rsp+0xE0], xmm15
000075038bdd691b  sub rsp, 0x30
000075038bdd691f  movaps [rsp], xmm14
000075038bdd6924  movaps [rsp+0x10], xmm9
000075038bdd692a  movaps [rsp+0x20], xmm13
000075038bdd6930  lea rdi, [rsp]
000075038bdd6934  mov esi, 0x00
000075038bdd6939  mov rax, 0x56ADB4492530
000075038bdd6943  call rax
000075038bdd6945  movaps xmm14, [rsp]
000075038bdd694a  add rsp, 0x30
000075038bdd694e  vmovaps xmm0, [rsp]
000075038bdd6953  vmovaps xmm1, [rsp+0x10]
000075038bdd6959  vmovaps xmm2, [rsp+0x20]
000075038bdd695f  vmovaps xmm3, [rsp+0x30]
000075038bdd6965  vmovaps xmm4, [rsp+0x40]
000075038bdd696b  vmovaps xmm5, [rsp+0x50]
000075038bdd6971  vmovaps xmm6, [rsp+0x60]
000075038bdd6977  vmovaps xmm7, [rsp+0x70]
000075038bdd697d  vmovaps xmm8, [rsp+0x80]
000075038bdd6986  vmovaps xmm9, [rsp+0x90]
000075038bdd698f  vmovaps xmm10, [rsp+0xA0]
000075038bdd6998  vmovaps xmm11, [rsp+0xB0]
000075038bdd69a1  vmovaps xmm12, [rsp+0xC0]
000075038bdd69aa  vmovaps xmm13, [rsp+0xD0]
000075038bdd69b3  vmovaps xmm15, [rsp+0xE0]
000075038bdd69bc  add rsp, 0xF0
000075038bdd69c3  pop r11
000075038bdd69c5  pop r10
000075038bdd69c7  pop r9
000075038bdd69c9  pop r8
000075038bdd69cb  pop rsi
000075038bdd69cc  pop rdi
000075038bdd69cd  pop rdx
000075038bdd69ce  pop rcx
000075038bdd69cf  pop rax
000075038bdd69d0  add rsp, 0x08
000075038bdd69d4  jmp 0x000075038BDD3176
000075038bdd69d9  sub rsp, 0x08
000075038bdd69dd  push rax
000075038bdd69de  push rcx
000075038bdd69df  push rdx
000075038bdd69e0  push rdi
000075038bdd69e1  push rsi
000075038bdd69e2  push r8
000075038bdd69e4  push r9
000075038bdd69e6  push r10
000075038bdd69e8  push r11
000075038bdd69ea  sub rsp, 0xF0
000075038bdd69f1  vmovaps [rsp], xmm0
000075038bdd69f6  vmovaps [rsp+0x10], xmm1
000075038bdd69fc  vmovaps [rsp+0x20], xmm2
000075038bdd6a02  vmovaps [rsp+0x30], xmm3
000075038bdd6a08  vmovaps [rsp+0x40], xmm4
000075038bdd6a0e  vmovaps [rsp+0x50], xmm5
000075038bdd6a14  vmovaps [rsp+0x60], xmm6
000075038bdd6a1a  vmovaps [rsp+0x70], xmm7
000075038bdd6a20  vmovaps [rsp+0x80], xmm8
000075038bdd6a29  vmovaps [rsp+0x90], xmm9
000075038bdd6a32  vmovaps [rsp+0xA0], xmm10
000075038bdd6a3b  vmovaps [rsp+0xB0], xmm11
000075038bdd6a44  vmovaps [rsp+0xC0], xmm12
000075038bdd6a4d  vmovaps [rsp+0xD0], xmm14
000075038bdd6a56  vmovaps [rsp+0xE0], xmm15
000075038bdd6a5f  sub rsp, 0x30
000075038bdd6a63  movaps [rsp], xmm13
000075038bdd6a68  movaps [rsp+0x10], xmm9
000075038bdd6a6e  movaps [rsp+0x20], xmm10
000075038bdd6a74  lea rdi, [rsp]
000075038bdd6a78  mov esi, 0x00
000075038bdd6a7d  mov rax, 0x56ADB4492530
000075038bdd6a87  call rax
000075038bdd6a89  movaps xmm13, [rsp]
000075038bdd6a8e  add rsp, 0x30
000075038bdd6a92  vmovaps xmm0, [rsp]
000075038bdd6a97  vmovaps xmm1, [rsp+0x10]
000075038bdd6a9d  vmovaps xmm2, [rsp+0x20]
000075038bdd6aa3  vmovaps xmm3, [rsp+0x30]
000075038bdd6aa9  vmovaps xmm4, [rsp+0x40]
000075038bdd6aaf  vmovaps xmm5, [rsp+0x50]
000075038bdd6ab5  vmovaps xmm6, [rsp+0x60]
000075038bdd6abb  vmovaps xmm7, [rsp+0x70]
000075038bdd6ac1  vmovaps xmm8, [rsp+0x80]
000075038bdd6aca  vmovaps xmm9, [rsp+0x90]
000075038bdd6ad3  vmovaps xmm10, [rsp+0xA0]
000075038bdd6adc  vmovaps xmm11, [rsp+0xB0]
000075038bdd6ae5  vmovaps xmm12, [rsp+0xC0]
000075038bdd6aee  vmovaps xmm14, [rsp+0xD0]
000075038bdd6af7  vmovaps xmm15, [rsp+0xE0]
000075038bdd6b00  add rsp, 0xF0
000075038bdd6b07  pop r11
000075038bdd6b09  pop r10
000075038bdd6b0b  pop r9
000075038bdd6b0d  pop r8
000075038bdd6b0f  pop rsi
000075038bdd6b10  pop rdi
000075038bdd6b11  pop rdx
000075038bdd6b12  pop rcx
000075038bdd6b13  pop rax
000075038bdd6b14  add rsp, 0x08
000075038bdd6b18  jmp 0x000075038BDD3196
000075038bdd6b1d  call 0x000075038BC0AFE0
000075038bdd6b22  jmp 0x000075038BDD31EB
000075038bdd6b27  sub rsp, 0x08
000075038bdd6b2b  push rax
000075038bdd6b2c  push rcx
000075038bdd6b2d  push rdx
000075038bdd6b2e  push rdi
000075038bdd6b2f  push rsi
000075038bdd6b30  push r8
000075038bdd6b32  push r9
000075038bdd6b34  push r10
000075038bdd6b36  push r11
000075038bdd6b38  sub rsp, 0xF0
000075038bdd6b3f  vmovaps [rsp], xmm0
000075038bdd6b44  vmovaps [rsp+0x10], xmm1
000075038bdd6b4a  vmovaps [rsp+0x20], xmm2
000075038bdd6b50  vmovaps [rsp+0x30], xmm3
000075038bdd6b56  vmovaps [rsp+0x40], xmm4
000075038bdd6b5c  vmovaps [rsp+0x50], xmm5
000075038bdd6b62  vmovaps [rsp+0x60], xmm6
000075038bdd6b68  vmovaps [rsp+0x70], xmm7
000075038bdd6b6e  vmovaps [rsp+0x80], xmm8
000075038bdd6b77  vmovaps [rsp+0x90], xmm10
000075038bdd6b80  vmovaps [rsp+0xA0], xmm11
000075038bdd6b89  vmovaps [rsp+0xB0], xmm12
000075038bdd6b92  vmovaps [rsp+0xC0], xmm13
000075038bdd6b9b  vmovaps [rsp+0xD0], xmm14
000075038bdd6ba4  vmovaps [rsp+0xE0], xmm15
000075038bdd6bad  sub rsp, 0x30
000075038bdd6bb1  movaps [rsp], xmm9
000075038bdd6bb6  movaps [rsp+0x10], xmm8
000075038bdd6bbc  movaps [rsp+0x20], xmm10
000075038bdd6bc2  lea rdi, [rsp]
000075038bdd6bc6  mov esi, 0x00
000075038bdd6bcb  mov rax, 0x56ADB4492530
000075038bdd6bd5  call rax
000075038bdd6bd7  movaps xmm9, [rsp]
000075038bdd6bdc  add rsp, 0x30
000075038bdd6be0  vmovaps xmm0, [rsp]
000075038bdd6be5  vmovaps xmm1, [rsp+0x10]
000075038bdd6beb  vmovaps xmm2, [rsp+0x20]
000075038bdd6bf1  vmovaps xmm3, [rsp+0x30]
000075038bdd6bf7  vmovaps xmm4, [rsp+0x40]
000075038bdd6bfd  vmovaps xmm5, [rsp+0x50]
000075038bdd6c03  vmovaps xmm6, [rsp+0x60]
000075038bdd6c09  vmovaps xmm7, [rsp+0x70]
000075038bdd6c0f  vmovaps xmm8, [rsp+0x80]
000075038bdd6c18  vmovaps xmm10, [rsp+0x90]
000075038bdd6c21  vmovaps xmm11, [rsp+0xA0]
000075038bdd6c2a  vmovaps xmm12, [rsp+0xB0]
000075038bdd6c33  vmovaps xmm13, [rsp+0xC0]
000075038bdd6c3c  vmovaps xmm14, [rsp+0xD0]
000075038bdd6c45  vmovaps xmm15, [rsp+0xE0]
000075038bdd6c4e  add rsp, 0xF0
000075038bdd6c55  pop r11
000075038bdd6c57  pop r10
000075038bdd6c59  pop r9
000075038bdd6c5b  pop r8
000075038bdd6c5d  pop rsi
000075038bdd6c5e  pop rdi
000075038bdd6c5f  pop rdx
000075038bdd6c60  pop rcx
000075038bdd6c61  pop rax
000075038bdd6c62  add rsp, 0x08
000075038bdd6c66  jmp 0x000075038BDD321C
000075038bdd6c6b  sub rsp, 0x08
000075038bdd6c6f  push rax
000075038bdd6c70  push rcx
000075038bdd6c71  push rdx
000075038bdd6c72  push rdi
000075038bdd6c73  push rsi
000075038bdd6c74  push r8
000075038bdd6c76  push r9
000075038bdd6c78  push r10
000075038bdd6c7a  push r11
000075038bdd6c7c  sub rsp, 0xF0
000075038bdd6c83  vmovaps [rsp], xmm0
000075038bdd6c88  vmovaps [rsp+0x10], xmm1
000075038bdd6c8e  vmovaps [rsp+0x20], xmm2
000075038bdd6c94  vmovaps [rsp+0x30], xmm3
000075038bdd6c9a  vmovaps [rsp+0x40], xmm4
000075038bdd6ca0  vmovaps [rsp+0x50], xmm5
000075038bdd6ca6  vmovaps [rsp+0x60], xmm6
000075038bdd6cac  vmovaps [rsp+0x70], xmm7
000075038bdd6cb2  vmovaps [rsp+0x80], xmm8
000075038bdd6cbb  vmovaps [rsp+0x90], xmm9
000075038bdd6cc4  vmovaps [rsp+0xA0], xmm11
000075038bdd6ccd  vmovaps [rsp+0xB0], xmm12
000075038bdd6cd6  vmovaps [rsp+0xC0], xmm13
000075038bdd6cdf  vmovaps [rsp+0xD0], xmm14
000075038bdd6ce8  vmovaps [rsp+0xE0], xmm15
000075038bdd6cf1  sub rsp, 0x30
000075038bdd6cf5  movaps [rsp], xmm10
000075038bdd6cfa  movaps [rsp+0x10], xmm1
000075038bdd6cff  movaps [rsp+0x20], xmm11
000075038bdd6d05  lea rdi, [rsp]
000075038bdd6d09  mov esi, 0x00
000075038bdd6d0e  mov rax, 0x56ADB4492530
000075038bdd6d18  call rax
000075038bdd6d1a  movaps xmm10, [rsp]
000075038bdd6d1f  add rsp, 0x30
000075038bdd6d23  vmovaps xmm0, [rsp]
000075038bdd6d28  vmovaps xmm1, [rsp+0x10]
000075038bdd6d2e  vmovaps xmm2, [rsp+0x20]
000075038bdd6d34  vmovaps xmm3, [rsp+0x30]
000075038bdd6d3a  vmovaps xmm4, [rsp+0x40]
000075038bdd6d40  vmovaps xmm5, [rsp+0x50]
000075038bdd6d46  vmovaps xmm6, [rsp+0x60]
000075038bdd6d4c  vmovaps xmm7, [rsp+0x70]
000075038bdd6d52  vmovaps xmm8, [rsp+0x80]
000075038bdd6d5b  vmovaps xmm9, [rsp+0x90]
000075038bdd6d64  vmovaps xmm11, [rsp+0xA0]
000075038bdd6d6d  vmovaps xmm12, [rsp+0xB0]
000075038bdd6d76  vmovaps xmm13, [rsp+0xC0]
000075038bdd6d7f  vmovaps xmm14, [rsp+0xD0]
000075038bdd6d88  vmovaps xmm15, [rsp+0xE0]
000075038bdd6d91  add rsp, 0xF0
000075038bdd6d98  pop r11
000075038bdd6d9a  pop r10
000075038bdd6d9c  pop r9
000075038bdd6d9e  pop r8
000075038bdd6da0  pop rsi
000075038bdd6da1  pop rdi
000075038bdd6da2  pop rdx
000075038bdd6da3  pop rcx
000075038bdd6da4  pop rax
000075038bdd6da5  add rsp, 0x08
000075038bdd6da9  jmp 0x000075038BDD3237
000075038bdd6dae  sub rsp, 0x08
000075038bdd6db2  push rax
000075038bdd6db3  push rcx
000075038bdd6db4  push rdx
000075038bdd6db5  push rdi
000075038bdd6db6  push rsi
000075038bdd6db7  push r8
000075038bdd6db9  push r9
000075038bdd6dbb  push r10
000075038bdd6dbd  push r11
000075038bdd6dbf  sub rsp, 0xF0
000075038bdd6dc6  vmovaps [rsp], xmm0
000075038bdd6dcb  vmovaps [rsp+0x10], xmm2
000075038bdd6dd1  vmovaps [rsp+0x20], xmm3
000075038bdd6dd7  vmovaps [rsp+0x30], xmm4
000075038bdd6ddd  vmovaps [rsp+0x40], xmm5
000075038bdd6de3  vmovaps [rsp+0x50], xmm6
000075038bdd6de9  vmovaps [rsp+0x60], xmm7
000075038bdd6def  vmovaps [rsp+0x70], xmm8
000075038bdd6df5  vmovaps [rsp+0x80], xmm9
000075038bdd6dfe  vmovaps [rsp+0x90], xmm10
000075038bdd6e07  vmovaps [rsp+0xA0], xmm11
000075038bdd6e10  vmovaps [rsp+0xB0], xmm12
000075038bdd6e19  vmovaps [rsp+0xC0], xmm13
000075038bdd6e22  vmovaps [rsp+0xD0], xmm14
000075038bdd6e2b  vmovaps [rsp+0xE0], xmm15
000075038bdd6e34  sub rsp, 0x30
000075038bdd6e38  movaps [rsp], xmm1
000075038bdd6e3c  movaps [rsp+0x10], xmm15
000075038bdd6e42  movaps [rsp+0x20], xmm6
000075038bdd6e47  lea rdi, [rsp]
000075038bdd6e4b  mov esi, 0x00
000075038bdd6e50  mov rax, 0x56ADB4492530
000075038bdd6e5a  call rax
000075038bdd6e5c  movaps xmm1, [rsp]
000075038bdd6e60  add rsp, 0x30
000075038bdd6e64  vmovaps xmm0, [rsp]
000075038bdd6e69  vmovaps xmm2, [rsp+0x10]
000075038bdd6e6f  vmovaps xmm3, [rsp+0x20]
000075038bdd6e75  vmovaps xmm4, [rsp+0x30]
000075038bdd6e7b  vmovaps xmm5, [rsp+0x40]
000075038bdd6e81  vmovaps xmm6, [rsp+0x50]
000075038bdd6e87  vmovaps xmm7, [rsp+0x60]
000075038bdd6e8d  vmovaps xmm8, [rsp+0x70]
000075038bdd6e93  vmovaps xmm9, [rsp+0x80]
000075038bdd6e9c  vmovaps xmm10, [rsp+0x90]
000075038bdd6ea5  vmovaps xmm11, [rsp+0xA0]
000075038bdd6eae  vmovaps xmm12, [rsp+0xB0]
000075038bdd6eb7  vmovaps xmm13, [rsp+0xC0]
000075038bdd6ec0  vmovaps xmm14, [rsp+0xD0]
000075038bdd6ec9  vmovaps xmm15, [rsp+0xE0]
000075038bdd6ed2  add rsp, 0xF0
000075038bdd6ed9  pop r11
000075038bdd6edb  pop r10
000075038bdd6edd  pop r9
000075038bdd6edf  pop r8
000075038bdd6ee1  pop rsi
000075038bdd6ee2  pop rdi
000075038bdd6ee3  pop rdx
000075038bdd6ee4  pop rcx
000075038bdd6ee5  pop rax
000075038bdd6ee6  add rsp, 0x08
000075038bdd6eea  jmp 0x000075038BDD3250
000075038bdd6eef  sub rsp, 0x08
000075038bdd6ef3  push rax
000075038bdd6ef4  push rcx
000075038bdd6ef5  push rdx
000075038bdd6ef6  push rdi
000075038bdd6ef7  push rsi
000075038bdd6ef8  push r8
000075038bdd6efa  push r9
000075038bdd6efc  push r10
000075038bdd6efe  push r11
000075038bdd6f00  sub rsp, 0xF0
000075038bdd6f07  vmovaps [rsp], xmm0
000075038bdd6f0c  vmovaps [rsp+0x10], xmm1
000075038bdd6f12  vmovaps [rsp+0x20], xmm2
000075038bdd6f18  vmovaps [rsp+0x30], xmm3
000075038bdd6f1e  vmovaps [rsp+0x40], xmm4
000075038bdd6f24  vmovaps [rsp+0x50], xmm5
000075038bdd6f2a  vmovaps [rsp+0x60], xmm6
000075038bdd6f30  vmovaps [rsp+0x70], xmm7
000075038bdd6f36  vmovaps [rsp+0x80], xmm8
000075038bdd6f3f  vmovaps [rsp+0x90], xmm9
000075038bdd6f48  vmovaps [rsp+0xA0], xmm10
000075038bdd6f51  vmovaps [rsp+0xB0], xmm12
000075038bdd6f5a  vmovaps [rsp+0xC0], xmm13
000075038bdd6f63  vmovaps [rsp+0xD0], xmm14
000075038bdd6f6c  vmovaps [rsp+0xE0], xmm15
000075038bdd6f75  sub rsp, 0x30
000075038bdd6f79  movaps [rsp], xmm11
000075038bdd6f7e  movaps [rsp+0x10], xmm12
000075038bdd6f84  movaps [rsp+0x20], xmm15
000075038bdd6f8a  lea rdi, [rsp]
000075038bdd6f8e  mov esi, 0x00
000075038bdd6f93  mov rax, 0x56ADB4492530
000075038bdd6f9d  call rax
000075038bdd6f9f  movaps xmm11, [rsp]
000075038bdd6fa4  add rsp, 0x30
000075038bdd6fa8  vmovaps xmm0, [rsp]
000075038bdd6fad  vmovaps xmm1, [rsp+0x10]
000075038bdd6fb3  vmovaps xmm2, [rsp+0x20]
000075038bdd6fb9  vmovaps xmm3, [rsp+0x30]
000075038bdd6fbf  vmovaps xmm4, [rsp+0x40]
000075038bdd6fc5  vmovaps xmm5, [rsp+0x50]
000075038bdd6fcb  vmovaps xmm6, [rsp+0x60]
000075038bdd6fd1  vmovaps xmm7, [rsp+0x70]
000075038bdd6fd7  vmovaps xmm8, [rsp+0x80]
000075038bdd6fe0  vmovaps xmm9, [rsp+0x90]
000075038bdd6fe9  vmovaps xmm10, [rsp+0xA0]
000075038bdd6ff2  vmovaps xmm12, [rsp+0xB0]
000075038bdd6ffb  vmovaps xmm13, [rsp+0xC0]
000075038bdd7004  vmovaps xmm14, [rsp+0xD0]
000075038bdd700d  vmovaps xmm15, [rsp+0xE0]
000075038bdd7016  add rsp, 0xF0
000075038bdd701d  pop r11
000075038bdd701f  pop r10
000075038bdd7021  pop r9
000075038bdd7023  pop r8
000075038bdd7025  pop rsi
000075038bdd7026  pop rdi
000075038bdd7027  pop rdx
000075038bdd7028  pop rcx
000075038bdd7029  pop rax
000075038bdd702a  add rsp, 0x08
000075038bdd702e  jmp 0x000075038BDD327A
000075038bdd7033  sub rsp, 0x08
000075038bdd7037  push rax
000075038bdd7038  push rcx
000075038bdd7039  push rdx
000075038bdd703a  push rdi
000075038bdd703b  push rsi
000075038bdd703c  push r8
000075038bdd703e  push r9
000075038bdd7040  push r10
000075038bdd7042  push r11
000075038bdd7044  sub rsp, 0xF0
000075038bdd704b  vmovaps [rsp], xmm0
000075038bdd7050  vmovaps [rsp+0x10], xmm1
000075038bdd7056  vmovaps [rsp+0x20], xmm2
000075038bdd705c  vmovaps [rsp+0x30], xmm3
000075038bdd7062  vmovaps [rsp+0x40], xmm4
000075038bdd7068  vmovaps [rsp+0x50], xmm5
000075038bdd706e  vmovaps [rsp+0x60], xmm6
000075038bdd7074  vmovaps [rsp+0x70], xmm7
000075038bdd707a  vmovaps [rsp+0x80], xmm8
000075038bdd7083  vmovaps [rsp+0x90], xmm9
000075038bdd708c  vmovaps [rsp+0xA0], xmm10
000075038bdd7095  vmovaps [rsp+0xB0], xmm11
000075038bdd709e  vmovaps [rsp+0xC0], xmm13
000075038bdd70a7  vmovaps [rsp+0xD0], xmm14
000075038bdd70b0  vmovaps [rsp+0xE0], xmm15
000075038bdd70b9  sub rsp, 0x30
000075038bdd70bd  movaps [rsp], xmm12
000075038bdd70c2  movaps [rsp+0x10], xmm8
000075038bdd70c8  movaps [rsp+0x20], xmm15
000075038bdd70ce  lea rdi, [rsp]
000075038bdd70d2  mov esi, 0x00
000075038bdd70d7  mov rax, 0x56ADB4492530
000075038bdd70e1  call rax
000075038bdd70e3  movaps xmm12, [rsp]
000075038bdd70e8  add rsp, 0x30
000075038bdd70ec  vmovaps xmm0, [rsp]
000075038bdd70f1  vmovaps xmm1, [rsp+0x10]
000075038bdd70f7  vmovaps xmm2, [rsp+0x20]
000075038bdd70fd  vmovaps xmm3, [rsp+0x30]
000075038bdd7103  vmovaps xmm4, [rsp+0x40]
000075038bdd7109  vmovaps xmm5, [rsp+0x50]
000075038bdd710f  vmovaps xmm6, [rsp+0x60]
000075038bdd7115  vmovaps xmm7, [rsp+0x70]
000075038bdd711b  vmovaps xmm8, [rsp+0x80]
000075038bdd7124  vmovaps xmm9, [rsp+0x90]
000075038bdd712d  vmovaps xmm10, [rsp+0xA0]
000075038bdd7136  vmovaps xmm11, [rsp+0xB0]
000075038bdd713f  vmovaps xmm13, [rsp+0xC0]
000075038bdd7148  vmovaps xmm14, [rsp+0xD0]
000075038bdd7151  vmovaps xmm15, [rsp+0xE0]
000075038bdd715a  add rsp, 0xF0
000075038bdd7161  pop r11
000075038bdd7163  pop r10
000075038bdd7165  pop r9
000075038bdd7167  pop r8
000075038bdd7169  pop rsi
000075038bdd716a  pop rdi
000075038bdd716b  pop rdx
000075038bdd716c  pop rcx
000075038bdd716d  pop rax
000075038bdd716e  add rsp, 0x08
000075038bdd7172  jmp 0x000075038BDD32A9
000075038bdd7177  sub rsp, 0x08
000075038bdd717b  push rax
000075038bdd717c  push rcx
000075038bdd717d  push rdx
000075038bdd717e  push rdi
000075038bdd717f  push rsi
000075038bdd7180  push r8
000075038bdd7182  push r9
000075038bdd7184  push r10
000075038bdd7186  push r11
000075038bdd7188  sub rsp, 0xF0
000075038bdd718f  vmovaps [rsp], xmm0
000075038bdd7194  vmovaps [rsp+0x10], xmm1
000075038bdd719a  vmovaps [rsp+0x20], xmm2
000075038bdd71a0  vmovaps [rsp+0x30], xmm3
000075038bdd71a6  vmovaps [rsp+0x40], xmm4
000075038bdd71ac  vmovaps [rsp+0x50], xmm5
000075038bdd71b2  vmovaps [rsp+0x60], xmm6
000075038bdd71b8  vmovaps [rsp+0x70], xmm7
000075038bdd71be  vmovaps [rsp+0x80], xmm9
000075038bdd71c7  vmovaps [rsp+0x90], xmm10
000075038bdd71d0  vmovaps [rsp+0xA0], xmm11
000075038bdd71d9  vmovaps [rsp+0xB0], xmm12
000075038bdd71e2  vmovaps [rsp+0xC0], xmm13
000075038bdd71eb  vmovaps [rsp+0xD0], xmm14
000075038bdd71f4  vmovaps [rsp+0xE0], xmm15
000075038bdd71fd  sub rsp, 0x30
000075038bdd7201  movaps [rsp], xmm8
000075038bdd7206  movaps [rsp+0x10], xmm7
000075038bdd720b  movaps [rsp+0x20], xmm15
000075038bdd7211  lea rdi, [rsp]
000075038bdd7215  mov esi, 0x00
000075038bdd721a  mov rax, 0x56ADB4492530
000075038bdd7224  call rax
000075038bdd7226  movaps xmm8, [rsp]
000075038bdd722b  add rsp, 0x30
000075038bdd722f  vmovaps xmm0, [rsp]
000075038bdd7234  vmovaps xmm1, [rsp+0x10]
000075038bdd723a  vmovaps xmm2, [rsp+0x20]
000075038bdd7240  vmovaps xmm3, [rsp+0x30]
000075038bdd7246  vmovaps xmm4, [rsp+0x40]
000075038bdd724c  vmovaps xmm5, [rsp+0x50]
000075038bdd7252  vmovaps xmm6, [rsp+0x60]
000075038bdd7258  vmovaps xmm7, [rsp+0x70]
000075038bdd725e  vmovaps xmm9, [rsp+0x80]
000075038bdd7267  vmovaps xmm10, [rsp+0x90]
000075038bdd7270  vmovaps xmm11, [rsp+0xA0]
000075038bdd7279  vmovaps xmm12, [rsp+0xB0]
000075038bdd7282  vmovaps xmm13, [rsp+0xC0]
000075038bdd728b  vmovaps xmm14, [rsp+0xD0]
000075038bdd7294  vmovaps xmm15, [rsp+0xE0]
000075038bdd729d  add rsp, 0xF0
000075038bdd72a4  pop r11
000075038bdd72a6  pop r10
000075038bdd72a8  pop r9
000075038bdd72aa  pop r8
000075038bdd72ac  pop rsi
000075038bdd72ad  pop rdi
000075038bdd72ae  pop rdx
000075038bdd72af  pop rcx
000075038bdd72b0  pop rax
000075038bdd72b1  add rsp, 0x08
000075038bdd72b5  jmp 0x000075038BDD32CF
000075038bdd72ba  sub rsp, 0x08
000075038bdd72be  push rax
000075038bdd72bf  push rcx
000075038bdd72c0  push rdx
000075038bdd72c1  push rdi
000075038bdd72c2  push rsi
000075038bdd72c3  push r8
000075038bdd72c5  push r9
000075038bdd72c7  push r10
000075038bdd72c9  push r11
000075038bdd72cb  sub rsp, 0xF0
000075038bdd72d2  vmovaps [rsp], xmm0
000075038bdd72d7  vmovaps [rsp+0x10], xmm1
000075038bdd72dd  vmovaps [rsp+0x20], xmm2
000075038bdd72e3  vmovaps [rsp+0x30], xmm3
000075038bdd72e9  vmovaps [rsp+0x40], xmm4
000075038bdd72ef  vmovaps [rsp+0x50], xmm5
000075038bdd72f5  vmovaps [rsp+0x60], xmm6
000075038bdd72fb  vmovaps [rsp+0x70], xmm7
000075038bdd7301  vmovaps [rsp+0x80], xmm8
000075038bdd730a  vmovaps [rsp+0x90], xmm9
000075038bdd7313  vmovaps [rsp+0xA0], xmm10
000075038bdd731c  vmovaps [rsp+0xB0], xmm11
000075038bdd7325  vmovaps [rsp+0xC0], xmm12
000075038bdd732e  vmovaps [rsp+0xD0], xmm13
000075038bdd7337  vmovaps [rsp+0xE0], xmm14
000075038bdd7340  sub rsp, 0x30
000075038bdd7344  movaps [rsp], xmm15
000075038bdd7349  movaps [rsp+0x10], xmm14
000075038bdd734f  movaps [rsp+0x20], xmm9
000075038bdd7355  lea rdi, [rsp]
000075038bdd7359  mov esi, 0x00
000075038bdd735e  mov rax, 0x56ADB4492530
000075038bdd7368  call rax
000075038bdd736a  movaps xmm15, [rsp]
000075038bdd736f  add rsp, 0x30
000075038bdd7373  vmovaps xmm0, [rsp]
000075038bdd7378  vmovaps xmm1, [rsp+0x10]
000075038bdd737e  vmovaps xmm2, [rsp+0x20]
000075038bdd7384  vmovaps xmm3, [rsp+0x30]
000075038bdd738a  vmovaps xmm4, [rsp+0x40]
000075038bdd7390  vmovaps xmm5, [rsp+0x50]
000075038bdd7396  vmovaps xmm6, [rsp+0x60]
000075038bdd739c  vmovaps xmm7, [rsp+0x70]
000075038bdd73a2  vmovaps xmm8, [rsp+0x80]
000075038bdd73ab  vmovaps xmm9, [rsp+0x90]
000075038bdd73b4  vmovaps xmm10, [rsp+0xA0]
000075038bdd73bd  vmovaps xmm11, [rsp+0xB0]
000075038bdd73c6  vmovaps xmm12, [rsp+0xC0]
000075038bdd73cf  vmovaps xmm13, [rsp+0xD0]
000075038bdd73d8  vmovaps xmm14, [rsp+0xE0]
000075038bdd73e1  add rsp, 0xF0
000075038bdd73e8  pop r11
000075038bdd73ea  pop r10
000075038bdd73ec  pop r9
000075038bdd73ee  pop r8
000075038bdd73f0  pop rsi
000075038bdd73f1  pop rdi
000075038bdd73f2  pop rdx
000075038bdd73f3  pop rcx
000075038bdd73f4  pop rax
000075038bdd73f5  add rsp, 0x08
000075038bdd73f9  jmp 0x000075038BDD32E9
000075038bdd73fe  sub rsp, 0x08
000075038bdd7402  push rax
000075038bdd7403  push rcx
000075038bdd7404  push rdx
000075038bdd7405  push rdi
000075038bdd7406  push rsi
000075038bdd7407  push r8
000075038bdd7409  push r9
000075038bdd740b  push r10
000075038bdd740d  push r11
000075038bdd740f  sub rsp, 0xF0
000075038bdd7416  vmovaps [rsp], xmm0
000075038bdd741b  vmovaps [rsp+0x10], xmm1
000075038bdd7421  vmovaps [rsp+0x20], xmm2
000075038bdd7427  vmovaps [rsp+0x30], xmm3
000075038bdd742d  vmovaps [rsp+0x40], xmm4
000075038bdd7433  vmovaps [rsp+0x50], xmm5
000075038bdd7439  vmovaps [rsp+0x60], xmm6
000075038bdd743f  vmovaps [rsp+0x70], xmm7
000075038bdd7445  vmovaps [rsp+0x80], xmm8
000075038bdd744e  vmovaps [rsp+0x90], xmm10
000075038bdd7457  vmovaps [rsp+0xA0], xmm11
000075038bdd7460  vmovaps [rsp+0xB0], xmm12
000075038bdd7469  vmovaps [rsp+0xC0], xmm13
000075038bdd7472  vmovaps [rsp+0xD0], xmm14
000075038bdd747b  vmovaps [rsp+0xE0], xmm15
000075038bdd7484  sub rsp, 0x30
000075038bdd7488  movaps [rsp], xmm9
000075038bdd748d  movaps [rsp+0x10], xmm7
000075038bdd7492  movaps [rsp+0x20], xmm14
000075038bdd7498  lea rdi, [rsp]
000075038bdd749c  mov esi, 0x00
000075038bdd74a1  mov rax, 0x56ADB4492530
000075038bdd74ab  call rax
000075038bdd74ad  movaps xmm9, [rsp]
000075038bdd74b2  add rsp, 0x30
000075038bdd74b6  vmovaps xmm0, [rsp]
000075038bdd74bb  vmovaps xmm1, [rsp+0x10]
000075038bdd74c1  vmovaps xmm2, [rsp+0x20]
000075038bdd74c7  vmovaps xmm3, [rsp+0x30]
000075038bdd74cd  vmovaps xmm4, [rsp+0x40]
000075038bdd74d3  vmovaps xmm5, [rsp+0x50]
000075038bdd74d9  vmovaps xmm6, [rsp+0x60]
000075038bdd74df  vmovaps xmm7, [rsp+0x70]
000075038bdd74e5  vmovaps xmm8, [rsp+0x80]
000075038bdd74ee  vmovaps xmm10, [rsp+0x90]
000075038bdd74f7  vmovaps xmm11, [rsp+0xA0]
000075038bdd7500  vmovaps xmm12, [rsp+0xB0]
000075038bdd7509  vmovaps xmm13, [rsp+0xC0]
000075038bdd7512  vmovaps xmm14, [rsp+0xD0]
000075038bdd751b  vmovaps xmm15, [rsp+0xE0]
000075038bdd7524  add rsp, 0xF0
000075038bdd752b  pop r11
000075038bdd752d  pop r10
000075038bdd752f  pop r9
000075038bdd7531  pop r8
000075038bdd7533  pop rsi
000075038bdd7534  pop rdi
000075038bdd7535  pop rdx
000075038bdd7536  pop rcx
000075038bdd7537  pop rax
000075038bdd7538  add rsp, 0x08
000075038bdd753c  jmp 0x000075038BDD3318
000075038bdd7541  sub rsp, 0x08
000075038bdd7545  push rax
000075038bdd7546  push rcx
000075038bdd7547  push rdx
000075038bdd7548  push rdi
000075038bdd7549  push rsi
000075038bdd754a  push r8
000075038bdd754c  push r9
000075038bdd754e  push r10
000075038bdd7550  push r11
000075038bdd7552  sub rsp, 0xF0
000075038bdd7559  vmovaps [rsp], xmm0
000075038bdd755e  vmovaps [rsp+0x10], xmm1
000075038bdd7564  vmovaps [rsp+0x20], xmm2
000075038bdd756a  vmovaps [rsp+0x30], xmm3
000075038bdd7570  vmovaps [rsp+0x40], xmm4
000075038bdd7576  vmovaps [rsp+0x50], xmm5
000075038bdd757c  vmovaps [rsp+0x60], xmm6
000075038bdd7582  vmovaps [rsp+0x70], xmm7
000075038bdd7588  vmovaps [rsp+0x80], xmm8
000075038bdd7591  vmovaps [rsp+0x90], xmm9
000075038bdd759a  vmovaps [rsp+0xA0], xmm10
000075038bdd75a3  vmovaps [rsp+0xB0], xmm11
000075038bdd75ac  vmovaps [rsp+0xC0], xmm12
000075038bdd75b5  vmovaps [rsp+0xD0], xmm13
000075038bdd75be  vmovaps [rsp+0xE0], xmm15
000075038bdd75c7  sub rsp, 0x30
000075038bdd75cb  movaps [rsp], xmm14
000075038bdd75d0  movaps [rsp+0x10], xmm13
000075038bdd75d6  movaps [rsp+0x20], xmm11
000075038bdd75dc  lea rdi, [rsp]
000075038bdd75e0  mov esi, 0x00
000075038bdd75e5  mov rax, 0x56ADB4492530
000075038bdd75ef  call rax
000075038bdd75f1  movaps xmm14, [rsp]
000075038bdd75f6  add rsp, 0x30
000075038bdd75fa  vmovaps xmm0, [rsp]
000075038bdd75ff  vmovaps xmm1, [rsp+0x10]
000075038bdd7605  vmovaps xmm2, [rsp+0x20]
000075038bdd760b  vmovaps xmm3, [rsp+0x30]
000075038bdd7611  vmovaps xmm4, [rsp+0x40]
000075038bdd7617  vmovaps xmm5, [rsp+0x50]
000075038bdd761d  vmovaps xmm6, [rsp+0x60]
000075038bdd7623  vmovaps xmm7, [rsp+0x70]
000075038bdd7629  vmovaps xmm8, [rsp+0x80]
000075038bdd7632  vmovaps xmm9, [rsp+0x90]
000075038bdd763b  vmovaps xmm10, [rsp+0xA0]
000075038bdd7644  vmovaps xmm11, [rsp+0xB0]
000075038bdd764d  vmovaps xmm12, [rsp+0xC0]
000075038bdd7656  vmovaps xmm13, [rsp+0xD0]
000075038bdd765f  vmovaps xmm15, [rsp+0xE0]
000075038bdd7668  add rsp, 0xF0
000075038bdd766f  pop r11
000075038bdd7671  pop r10
000075038bdd7673  pop r9
000075038bdd7675  pop r8
000075038bdd7677  pop rsi
000075038bdd7678  pop rdi
000075038bdd7679  pop rdx
000075038bdd767a  pop rcx
000075038bdd767b  pop rax
000075038bdd767c  add rsp, 0x08
000075038bdd7680  jmp 0x000075038BDD3332
000075038bdd7685  sub rsp, 0x08
000075038bdd7689  push rax
000075038bdd768a  push rcx
000075038bdd768b  push rdx
000075038bdd768c  push rdi
000075038bdd768d  push rsi
000075038bdd768e  push r8
000075038bdd7690  push r9
000075038bdd7692  push r10
000075038bdd7694  push r11
000075038bdd7696  sub rsp, 0xF0
000075038bdd769d  vmovaps [rsp], xmm0
000075038bdd76a2  vmovaps [rsp+0x10], xmm1
000075038bdd76a8  vmovaps [rsp+0x20], xmm2
000075038bdd76ae  vmovaps [rsp+0x30], xmm3
000075038bdd76b4  vmovaps [rsp+0x40], xmm4
000075038bdd76ba  vmovaps [rsp+0x50], xmm5
000075038bdd76c0  vmovaps [rsp+0x60], xmm6
000075038bdd76c6  vmovaps [rsp+0x70], xmm7
000075038bdd76cc  vmovaps [rsp+0x80], xmm8
000075038bdd76d5  vmovaps [rsp+0x90], xmm9
000075038bdd76de  vmovaps [rsp+0xA0], xmm10
000075038bdd76e7  vmovaps [rsp+0xB0], xmm12
000075038bdd76f0  vmovaps [rsp+0xC0], xmm13
000075038bdd76f9  vmovaps [rsp+0xD0], xmm14
000075038bdd7702  vmovaps [rsp+0xE0], xmm15
000075038bdd770b  sub rsp, 0x30
000075038bdd770f  movaps [rsp], xmm11
000075038bdd7714  movaps [rsp+0x10], xmm7
000075038bdd7719  movaps [rsp+0x20], xmm13
000075038bdd771f  lea rdi, [rsp]
000075038bdd7723  mov esi, 0x00
000075038bdd7728  mov rax, 0x56ADB4492530
000075038bdd7732  call rax
000075038bdd7734  movaps xmm11, [rsp]
000075038bdd7739  add rsp, 0x30
000075038bdd773d  vmovaps xmm0, [rsp]
000075038bdd7742  vmovaps xmm1, [rsp+0x10]
000075038bdd7748  vmovaps xmm2, [rsp+0x20]
000075038bdd774e  vmovaps xmm3, [rsp+0x30]
000075038bdd7754  vmovaps xmm4, [rsp+0x40]
000075038bdd775a  vmovaps xmm5, [rsp+0x50]
000075038bdd7760  vmovaps xmm6, [rsp+0x60]
000075038bdd7766  vmovaps xmm7, [rsp+0x70]
000075038bdd776c  vmovaps xmm8, [rsp+0x80]
000075038bdd7775  vmovaps xmm9, [rsp+0x90]
000075038bdd777e  vmovaps xmm10, [rsp+0xA0]
000075038bdd7787  vmovaps xmm12, [rsp+0xB0]
000075038bdd7790  vmovaps xmm13, [rsp+0xC0]
000075038bdd7799  vmovaps xmm14, [rsp+0xD0]
000075038bdd77a2  vmovaps xmm15, [rsp+0xE0]
000075038bdd77ab  add rsp, 0xF0
000075038bdd77b2  pop r11
000075038bdd77b4  pop r10
000075038bdd77b6  pop r9
000075038bdd77b8  pop r8
000075038bdd77ba  pop rsi
000075038bdd77bb  pop rdi
000075038bdd77bc  pop rdx
000075038bdd77bd  pop rcx
000075038bdd77be  pop rax
000075038bdd77bf  add rsp, 0x08
000075038bdd77c3  jmp 0x000075038BDD335E
000075038bdd77c8  sub rsp, 0x08
000075038bdd77cc  push rax
000075038bdd77cd  push rcx
000075038bdd77ce  push rdx
000075038bdd77cf  push rdi
000075038bdd77d0  push rsi
000075038bdd77d1  push r8
000075038bdd77d3  push r9
000075038bdd77d5  push r10
000075038bdd77d7  push r11
000075038bdd77d9  sub rsp, 0xF0
000075038bdd77e0  vmovaps [rsp], xmm0
000075038bdd77e5  vmovaps [rsp+0x10], xmm1
000075038bdd77eb  vmovaps [rsp+0x20], xmm2
000075038bdd77f1  vmovaps [rsp+0x30], xmm3
000075038bdd77f7  vmovaps [rsp+0x40], xmm4
000075038bdd77fd  vmovaps [rsp+0x50], xmm5
000075038bdd7803  vmovaps [rsp+0x60], xmm6
000075038bdd7809  vmovaps [rsp+0x70], xmm7
000075038bdd780f  vmovaps [rsp+0x80], xmm8
000075038bdd7818  vmovaps [rsp+0x90], xmm9
000075038bdd7821  vmovaps [rsp+0xA0], xmm10
000075038bdd782a  vmovaps [rsp+0xB0], xmm11
000075038bdd7833  vmovaps [rsp+0xC0], xmm12
000075038bdd783c  vmovaps [rsp+0xD0], xmm14
000075038bdd7845  vmovaps [rsp+0xE0], xmm15
000075038bdd784e  sub rsp, 0x30
000075038bdd7852  movaps [rsp], xmm13
000075038bdd7857  movaps [rsp+0x10], xmm10
000075038bdd785d  movaps [rsp+0x20], xmm12
000075038bdd7863  lea rdi, [rsp]
000075038bdd7867  mov esi, 0x00
000075038bdd786c  mov rax, 0x56ADB4492530
000075038bdd7876  call rax
000075038bdd7878  movaps xmm13, [rsp]
000075038bdd787d  add rsp, 0x30
000075038bdd7881  vmovaps xmm0, [rsp]
000075038bdd7886  vmovaps xmm1, [rsp+0x10]
000075038bdd788c  vmovaps xmm2, [rsp+0x20]
000075038bdd7892  vmovaps xmm3, [rsp+0x30]
000075038bdd7898  vmovaps xmm4, [rsp+0x40]
000075038bdd789e  vmovaps xmm5, [rsp+0x50]
000075038bdd78a4  vmovaps xmm6, [rsp+0x60]
000075038bdd78aa  vmovaps xmm7, [rsp+0x70]
000075038bdd78b0  vmovaps xmm8, [rsp+0x80]
000075038bdd78b9  vmovaps xmm9, [rsp+0x90]
000075038bdd78c2  vmovaps xmm10, [rsp+0xA0]
000075038bdd78cb  vmovaps xmm11, [rsp+0xB0]
000075038bdd78d4  vmovaps xmm12, [rsp+0xC0]
000075038bdd78dd  vmovaps xmm14, [rsp+0xD0]
000075038bdd78e6  vmovaps xmm15, [rsp+0xE0]
000075038bdd78ef  add rsp, 0xF0
000075038bdd78f6  pop r11
000075038bdd78f8  pop r10
000075038bdd78fa  pop r9
000075038bdd78fc  pop r8
000075038bdd78fe  pop rsi
000075038bdd78ff  pop rdi
000075038bdd7900  pop rdx
000075038bdd7901  pop rcx
000075038bdd7902  pop rax
000075038bdd7903  add rsp, 0x08
000075038bdd7907  jmp 0x000075038BDD3378
000075038bdd790c  sub rsp, 0x08
000075038bdd7910  push rax
000075038bdd7911  push rcx
000075038bdd7912  push rdx
000075038bdd7913  push rdi
000075038bdd7914  push rsi
000075038bdd7915  push r8
000075038bdd7917  push r9
000075038bdd7919  push r10
000075038bdd791b  push r11
000075038bdd791d  sub rsp, 0xF0
000075038bdd7924  vmovaps [rsp], xmm0
000075038bdd7929  vmovaps [rsp+0x10], xmm1
000075038bdd792f  vmovaps [rsp+0x20], xmm2
000075038bdd7935  vmovaps [rsp+0x30], xmm3
000075038bdd793b  vmovaps [rsp+0x40], xmm4
000075038bdd7941  vmovaps [rsp+0x50], xmm5
000075038bdd7947  vmovaps [rsp+0x60], xmm6
000075038bdd794d  vmovaps [rsp+0x70], xmm7
000075038bdd7953  vmovaps [rsp+0x80], xmm8
000075038bdd795c  vmovaps [rsp+0x90], xmm9
000075038bdd7965  vmovaps [rsp+0xA0], xmm11
000075038bdd796e  vmovaps [rsp+0xB0], xmm12
000075038bdd7977  vmovaps [rsp+0xC0], xmm13
000075038bdd7980  vmovaps [rsp+0xD0], xmm14
000075038bdd7989  vmovaps [rsp+0xE0], xmm15
000075038bdd7992  sub rsp, 0x30
000075038bdd7996  movaps [rsp], xmm10
000075038bdd799b  movaps [rsp+0x10], xmm7
000075038bdd79a0  movaps [rsp+0x20], xmm12
000075038bdd79a6  lea rdi, [rsp]
000075038bdd79aa  mov esi, 0x00
000075038bdd79af  mov rax, 0x56ADB4492530
000075038bdd79b9  call rax
000075038bdd79bb  movaps xmm10, [rsp]
000075038bdd79c0  add rsp, 0x30
000075038bdd79c4  vmovaps xmm0, [rsp]
000075038bdd79c9  vmovaps xmm1, [rsp+0x10]
000075038bdd79cf  vmovaps xmm2, [rsp+0x20]
000075038bdd79d5  vmovaps xmm3, [rsp+0x30]
000075038bdd79db  vmovaps xmm4, [rsp+0x40]
000075038bdd79e1  vmovaps xmm5, [rsp+0x50]
000075038bdd79e7  vmovaps xmm6, [rsp+0x60]
000075038bdd79ed  vmovaps xmm7, [rsp+0x70]
000075038bdd79f3  vmovaps xmm8, [rsp+0x80]
000075038bdd79fc  vmovaps xmm9, [rsp+0x90]
000075038bdd7a05  vmovaps xmm11, [rsp+0xA0]
000075038bdd7a0e  vmovaps xmm12, [rsp+0xB0]
000075038bdd7a17  vmovaps xmm13, [rsp+0xC0]
000075038bdd7a20  vmovaps xmm14, [rsp+0xD0]
000075038bdd7a29  vmovaps xmm15, [rsp+0xE0]
000075038bdd7a32  add rsp, 0xF0
000075038bdd7a39  pop r11
000075038bdd7a3b  pop r10
000075038bdd7a3d  pop r9
000075038bdd7a3f  pop r8
000075038bdd7a41  pop rsi
000075038bdd7a42  pop rdi
000075038bdd7a43  pop rdx
000075038bdd7a44  pop rcx
000075038bdd7a45  pop rax
000075038bdd7a46  add rsp, 0x08
000075038bdd7a4a  jmp 0x000075038BDD33A4
000075038bdd7a4f  sub rsp, 0x08
000075038bdd7a53  push rax
000075038bdd7a54  push rcx
000075038bdd7a55  push rdx
000075038bdd7a56  push rdi
000075038bdd7a57  push rsi
000075038bdd7a58  push r8
000075038bdd7a5a  push r9
000075038bdd7a5c  push r10
000075038bdd7a5e  push r11
000075038bdd7a60  sub rsp, 0xF0
000075038bdd7a67  vmovaps [rsp], xmm0
000075038bdd7a6c  vmovaps [rsp+0x10], xmm1
000075038bdd7a72  vmovaps [rsp+0x20], xmm2
000075038bdd7a78  vmovaps [rsp+0x30], xmm3
000075038bdd7a7e  vmovaps [rsp+0x40], xmm4
000075038bdd7a84  vmovaps [rsp+0x50], xmm5
000075038bdd7a8a  vmovaps [rsp+0x60], xmm6
000075038bdd7a90  vmovaps [rsp+0x70], xmm7
000075038bdd7a96  vmovaps [rsp+0x80], xmm8
000075038bdd7a9f  vmovaps [rsp+0x90], xmm9
000075038bdd7aa8  vmovaps [rsp+0xA0], xmm10
000075038bdd7ab1  vmovaps [rsp+0xB0], xmm11
000075038bdd7aba  vmovaps [rsp+0xC0], xmm13
000075038bdd7ac3  vmovaps [rsp+0xD0], xmm14
000075038bdd7acc  vmovaps [rsp+0xE0], xmm15
000075038bdd7ad5  sub rsp, 0x30
000075038bdd7ad9  movaps [rsp], xmm12
000075038bdd7ade  movaps [rsp+0x10], xmm1
000075038bdd7ae3  movaps [rsp+0x20], xmm8
000075038bdd7ae9  lea rdi, [rsp]
000075038bdd7aed  mov esi, 0x00
000075038bdd7af2  mov rax, 0x56ADB4492530
000075038bdd7afc  call rax
000075038bdd7afe  movaps xmm12, [rsp]
000075038bdd7b03  add rsp, 0x30
000075038bdd7b07  vmovaps xmm0, [rsp]
000075038bdd7b0c  vmovaps xmm1, [rsp+0x10]
000075038bdd7b12  vmovaps xmm2, [rsp+0x20]
000075038bdd7b18  vmovaps xmm3, [rsp+0x30]
000075038bdd7b1e  vmovaps xmm4, [rsp+0x40]
000075038bdd7b24  vmovaps xmm5, [rsp+0x50]
000075038bdd7b2a  vmovaps xmm6, [rsp+0x60]
000075038bdd7b30  vmovaps xmm7, [rsp+0x70]
000075038bdd7b36  vmovaps xmm8, [rsp+0x80]
000075038bdd7b3f  vmovaps xmm9, [rsp+0x90]
000075038bdd7b48  vmovaps xmm10, [rsp+0xA0]
000075038bdd7b51  vmovaps xmm11, [rsp+0xB0]
000075038bdd7b5a  vmovaps xmm13, [rsp+0xC0]
000075038bdd7b63  vmovaps xmm14, [rsp+0xD0]
000075038bdd7b6c  vmovaps xmm15, [rsp+0xE0]
000075038bdd7b75  add rsp, 0xF0
000075038bdd7b7c  pop r11
000075038bdd7b7e  pop r10
000075038bdd7b80  pop r9
000075038bdd7b82  pop r8
000075038bdd7b84  pop rsi
000075038bdd7b85  pop rdi
000075038bdd7b86  pop rdx
000075038bdd7b87  pop rcx
000075038bdd7b88  pop rax
000075038bdd7b89  add rsp, 0x08
000075038bdd7b8d  jmp 0x000075038BDD33BE
000075038bdd7b92  call 0x000075038BBFF430
000075038bdd7b97  jmp 0x000075038BDD33C8
000075038bdd7b9c  sub rsp, 0x08
000075038bdd7ba0  push rax
000075038bdd7ba1  push rcx
000075038bdd7ba2  push rdx
000075038bdd7ba3  push rdi
000075038bdd7ba4  push rsi
000075038bdd7ba5  push r8
000075038bdd7ba7  push r9
000075038bdd7ba9  push r10
000075038bdd7bab  push r11
000075038bdd7bad  sub rsp, 0xF0
000075038bdd7bb4  vmovaps [rsp], xmm0
000075038bdd7bb9  vmovaps [rsp+0x10], xmm1
000075038bdd7bbf  vmovaps [rsp+0x20], xmm2
000075038bdd7bc5  vmovaps [rsp+0x30], xmm3
000075038bdd7bcb  vmovaps [rsp+0x40], xmm4
000075038bdd7bd1  vmovaps [rsp+0x50], xmm5
000075038bdd7bd7  vmovaps [rsp+0x60], xmm6
000075038bdd7bdd  vmovaps [rsp+0x70], xmm7
000075038bdd7be3  vmovaps [rsp+0x80], xmm9
000075038bdd7bec  vmovaps [rsp+0x90], xmm10
000075038bdd7bf5  vmovaps [rsp+0xA0], xmm11
000075038bdd7bfe  vmovaps [rsp+0xB0], xmm12
000075038bdd7c07  vmovaps [rsp+0xC0], xmm13
000075038bdd7c10  vmovaps [rsp+0xD0], xmm14
000075038bdd7c19  vmovaps [rsp+0xE0], xmm15
000075038bdd7c22  sub rsp, 0x30
000075038bdd7c26  movaps [rsp], xmm8
000075038bdd7c2b  movaps [rsp+0x10], xmm15
000075038bdd7c31  movaps [rsp+0x20], xmm9
000075038bdd7c37  lea rdi, [rsp]
000075038bdd7c3b  mov esi, 0x00
000075038bdd7c40  mov rax, 0x56ADB4492530
000075038bdd7c4a  call rax
000075038bdd7c4c  movaps xmm8, [rsp]
000075038bdd7c51  add rsp, 0x30
000075038bdd7c55  vmovaps xmm0, [rsp]
000075038bdd7c5a  vmovaps xmm1, [rsp+0x10]
000075038bdd7c60  vmovaps xmm2, [rsp+0x20]
000075038bdd7c66  vmovaps xmm3, [rsp+0x30]
000075038bdd7c6c  vmovaps xmm4, [rsp+0x40]
000075038bdd7c72  vmovaps xmm5, [rsp+0x50]
000075038bdd7c78  vmovaps xmm6, [rsp+0x60]
000075038bdd7c7e  vmovaps xmm7, [rsp+0x70]
000075038bdd7c84  vmovaps xmm9, [rsp+0x80]
000075038bdd7c8d  vmovaps xmm10, [rsp+0x90]
000075038bdd7c96  vmovaps xmm11, [rsp+0xA0]
000075038bdd7c9f  vmovaps xmm12, [rsp+0xB0]
000075038bdd7ca8  vmovaps xmm13, [rsp+0xC0]
000075038bdd7cb1  vmovaps xmm14, [rsp+0xD0]
000075038bdd7cba  vmovaps xmm15, [rsp+0xE0]
000075038bdd7cc3  add rsp, 0xF0
000075038bdd7cca  pop r11
000075038bdd7ccc  pop r10
000075038bdd7cce  pop r9
000075038bdd7cd0  pop r8
000075038bdd7cd2  pop rsi
000075038bdd7cd3  pop rdi
000075038bdd7cd4  pop rdx
000075038bdd7cd5  pop rcx
000075038bdd7cd6  pop rax
000075038bdd7cd7  add rsp, 0x08
000075038bdd7cdb  jmp 0x000075038BDD33EA
000075038bdd7ce0  sub rsp, 0x08
000075038bdd7ce4  push rax
000075038bdd7ce5  push rcx
000075038bdd7ce6  push rdx
000075038bdd7ce7  push rdi
000075038bdd7ce8  push rsi
000075038bdd7ce9  push r8
000075038bdd7ceb  push r9
000075038bdd7ced  push r10
000075038bdd7cef  push r11
000075038bdd7cf1  sub rsp, 0xF0
000075038bdd7cf8  vmovaps [rsp], xmm0
000075038bdd7cfd  vmovaps [rsp+0x10], xmm1
000075038bdd7d03  vmovaps [rsp+0x20], xmm2
000075038bdd7d09  vmovaps [rsp+0x30], xmm3
000075038bdd7d0f  vmovaps [rsp+0x40], xmm4
000075038bdd7d15  vmovaps [rsp+0x50], xmm5
000075038bdd7d1b  vmovaps [rsp+0x60], xmm6
000075038bdd7d21  vmovaps [rsp+0x70], xmm7
000075038bdd7d27  vmovaps [rsp+0x80], xmm8
000075038bdd7d30  vmovaps [rsp+0x90], xmm10
000075038bdd7d39  vmovaps [rsp+0xA0], xmm11
000075038bdd7d42  vmovaps [rsp+0xB0], xmm12
000075038bdd7d4b  vmovaps [rsp+0xC0], xmm13
000075038bdd7d54  vmovaps [rsp+0xD0], xmm14
000075038bdd7d5d  vmovaps [rsp+0xE0], xmm15
000075038bdd7d66  sub rsp, 0x30
000075038bdd7d6a  movaps [rsp], xmm9
000075038bdd7d6f  movaps [rsp+0x10], xmm1
000075038bdd7d74  movaps [rsp+0x20], xmm15
000075038bdd7d7a  lea rdi, [rsp]
000075038bdd7d7e  mov esi, 0x00
000075038bdd7d83  mov rax, 0x56ADB4492530
000075038bdd7d8d  call rax
000075038bdd7d8f  movaps xmm9, [rsp]
000075038bdd7d94  add rsp, 0x30
000075038bdd7d98  vmovaps xmm0, [rsp]
000075038bdd7d9d  vmovaps xmm1, [rsp+0x10]
000075038bdd7da3  vmovaps xmm2, [rsp+0x20]
000075038bdd7da9  vmovaps xmm3, [rsp+0x30]
000075038bdd7daf  vmovaps xmm4, [rsp+0x40]
000075038bdd7db5  vmovaps xmm5, [rsp+0x50]
000075038bdd7dbb  vmovaps xmm6, [rsp+0x60]
000075038bdd7dc1  vmovaps xmm7, [rsp+0x70]
000075038bdd7dc7  vmovaps xmm8, [rsp+0x80]
000075038bdd7dd0  vmovaps xmm10, [rsp+0x90]
000075038bdd7dd9  vmovaps xmm11, [rsp+0xA0]
000075038bdd7de2  vmovaps xmm12, [rsp+0xB0]
000075038bdd7deb  vmovaps xmm13, [rsp+0xC0]
000075038bdd7df4  vmovaps xmm14, [rsp+0xD0]
000075038bdd7dfd  vmovaps xmm15, [rsp+0xE0]
000075038bdd7e06  add rsp, 0xF0
000075038bdd7e0d  pop r11
000075038bdd7e0f  pop r10
000075038bdd7e11  pop r9
000075038bdd7e13  pop r8
000075038bdd7e15  pop rsi
000075038bdd7e16  pop rdi
000075038bdd7e17  pop rdx
000075038bdd7e18  pop rcx
000075038bdd7e19  pop rax
000075038bdd7e1a  add rsp, 0x08
000075038bdd7e1e  jmp 0x000075038BDD3418
000075038bdd7e23  sub rsp, 0x08
000075038bdd7e27  push rax
000075038bdd7e28  push rcx
000075038bdd7e29  push rdx
000075038bdd7e2a  push rdi
000075038bdd7e2b  push rsi
000075038bdd7e2c  push r8
000075038bdd7e2e  push r9
000075038bdd7e30  push r10
000075038bdd7e32  push r11
000075038bdd7e34  sub rsp, 0xF0
000075038bdd7e3b  vmovaps [rsp], xmm0
000075038bdd7e40  vmovaps [rsp+0x10], xmm1
000075038bdd7e46  vmovaps [rsp+0x20], xmm2
000075038bdd7e4c  vmovaps [rsp+0x30], xmm3
000075038bdd7e52  vmovaps [rsp+0x40], xmm4
000075038bdd7e58  vmovaps [rsp+0x50], xmm5
000075038bdd7e5e  vmovaps [rsp+0x60], xmm6
000075038bdd7e64  vmovaps [rsp+0x70], xmm7
000075038bdd7e6a  vmovaps [rsp+0x80], xmm8
000075038bdd7e73  vmovaps [rsp+0x90], xmm9
000075038bdd7e7c  vmovaps [rsp+0xA0], xmm10
000075038bdd7e85  vmovaps [rsp+0xB0], xmm11
000075038bdd7e8e  vmovaps [rsp+0xC0], xmm12
000075038bdd7e97  vmovaps [rsp+0xD0], xmm13
000075038bdd7ea0  vmovaps [rsp+0xE0], xmm14
000075038bdd7ea9  sub rsp, 0x30
000075038bdd7ead  movaps [rsp], xmm15
000075038bdd7eb2  movaps [rsp+0x10], xmm4
000075038bdd7eb7  movaps [rsp+0x20], xmm1
000075038bdd7ebc  lea rdi, [rsp]
000075038bdd7ec0  mov esi, 0x00
000075038bdd7ec5  mov rax, 0x56ADB4492530
000075038bdd7ecf  call rax
000075038bdd7ed1  movaps xmm15, [rsp]
000075038bdd7ed6  add rsp, 0x30
000075038bdd7eda  vmovaps xmm0, [rsp]
000075038bdd7edf  vmovaps xmm1, [rsp+0x10]
000075038bdd7ee5  vmovaps xmm2, [rsp+0x20]
000075038bdd7eeb  vmovaps xmm3, [rsp+0x30]
000075038bdd7ef1  vmovaps xmm4, [rsp+0x40]
000075038bdd7ef7  vmovaps xmm5, [rsp+0x50]
000075038bdd7efd  vmovaps xmm6, [rsp+0x60]
000075038bdd7f03  vmovaps xmm7, [rsp+0x70]
000075038bdd7f09  vmovaps xmm8, [rsp+0x80]
000075038bdd7f12  vmovaps xmm9, [rsp+0x90]
000075038bdd7f1b  vmovaps xmm10, [rsp+0xA0]
000075038bdd7f24  vmovaps xmm11, [rsp+0xB0]
000075038bdd7f2d  vmovaps xmm12, [rsp+0xC0]
000075038bdd7f36  vmovaps xmm13, [rsp+0xD0]
000075038bdd7f3f  vmovaps xmm14, [rsp+0xE0]
000075038bdd7f48  add rsp, 0xF0
000075038bdd7f4f  pop r11
000075038bdd7f51  pop r10
000075038bdd7f53  pop r9
000075038bdd7f55  pop r8
000075038bdd7f57  pop rsi
000075038bdd7f58  pop rdi
000075038bdd7f59  pop rdx
000075038bdd7f5a  pop rcx
000075038bdd7f5b  pop rax
000075038bdd7f5c  add rsp, 0x08
000075038bdd7f60  jmp 0x000075038BDD343E
000075038bdd7f65  sub rsp, 0x08
000075038bdd7f69  push rax
000075038bdd7f6a  push rcx
000075038bdd7f6b  push rdx
000075038bdd7f6c  push rdi
000075038bdd7f6d  push rsi
000075038bdd7f6e  push r8
000075038bdd7f70  push r9
000075038bdd7f72  push r10
000075038bdd7f74  push r11
000075038bdd7f76  sub rsp, 0xF0
000075038bdd7f7d  vmovaps [rsp], xmm0
000075038bdd7f82  vmovaps [rsp+0x10], xmm2
000075038bdd7f88  vmovaps [rsp+0x20], xmm3
000075038bdd7f8e  vmovaps [rsp+0x30], xmm4
000075038bdd7f94  vmovaps [rsp+0x40], xmm5
000075038bdd7f9a  vmovaps [rsp+0x50], xmm6
000075038bdd7fa0  vmovaps [rsp+0x60], xmm7
000075038bdd7fa6  vmovaps [rsp+0x70], xmm8
000075038bdd7fac  vmovaps [rsp+0x80], xmm9
000075038bdd7fb5  vmovaps [rsp+0x90], xmm10
000075038bdd7fbe  vmovaps [rsp+0xA0], xmm11
000075038bdd7fc7  vmovaps [rsp+0xB0], xmm12
000075038bdd7fd0  vmovaps [rsp+0xC0], xmm13
000075038bdd7fd9  vmovaps [rsp+0xD0], xmm14
000075038bdd7fe2  vmovaps [rsp+0xE0], xmm15
000075038bdd7feb  sub rsp, 0x30
000075038bdd7fef  movaps [rsp], xmm1
000075038bdd7ff3  movaps [rsp+0x10], xmm14
000075038bdd7ff9  movaps [rsp+0x20], xmm11
000075038bdd7fff  lea rdi, [rsp]
000075038bdd8003  mov esi, 0x00
000075038bdd8008  mov rax, 0x56ADB4492530
000075038bdd8012  call rax
000075038bdd8014  movaps xmm1, [rsp]
000075038bdd8018  add rsp, 0x30
000075038bdd801c  vmovaps xmm0, [rsp]
000075038bdd8021  vmovaps xmm2, [rsp+0x10]
000075038bdd8027  vmovaps xmm3, [rsp+0x20]
000075038bdd802d  vmovaps xmm4, [rsp+0x30]
000075038bdd8033  vmovaps xmm5, [rsp+0x40]
000075038bdd8039  vmovaps xmm6, [rsp+0x50]
000075038bdd803f  vmovaps xmm7, [rsp+0x60]
000075038bdd8045  vmovaps xmm8, [rsp+0x70]
000075038bdd804b  vmovaps xmm9, [rsp+0x80]
000075038bdd8054  vmovaps xmm10, [rsp+0x90]
000075038bdd805d  vmovaps xmm11, [rsp+0xA0]
000075038bdd8066  vmovaps xmm12, [rsp+0xB0]
000075038bdd806f  vmovaps xmm13, [rsp+0xC0]
000075038bdd8078  vmovaps xmm14, [rsp+0xD0]
000075038bdd8081  vmovaps xmm15, [rsp+0xE0]
000075038bdd808a  add rsp, 0xF0
000075038bdd8091  pop r11
000075038bdd8093  pop r10
000075038bdd8095  pop r9
000075038bdd8097  pop r8
000075038bdd8099  pop rsi
000075038bdd809a  pop rdi
000075038bdd809b  pop rdx
000075038bdd809c  pop rcx
000075038bdd809d  pop rax
000075038bdd809e  add rsp, 0x08
000075038bdd80a2  jmp 0x000075038BDD345F
000075038bdd80a7  call 0x000075038BCE45A0
000075038bdd80ac  jmp 0x000075038BDD346D
000075038bdd80b1  call 0x000075038BC09D70
000075038bdd80b6  jmp 0x000075038BDD3477
000075038bdd80bb  sub rsp, 0x08
000075038bdd80bf  push rax
000075038bdd80c0  push rcx
000075038bdd80c1  push rdx
000075038bdd80c2  push rdi
000075038bdd80c3  push rsi
000075038bdd80c4  push r8
000075038bdd80c6  push r9
000075038bdd80c8  push r10
000075038bdd80ca  push r11
000075038bdd80cc  sub rsp, 0xF0
000075038bdd80d3  vmovaps [rsp], xmm0
000075038bdd80d8  vmovaps [rsp+0x10], xmm1
000075038bdd80de  vmovaps [rsp+0x20], xmm2
000075038bdd80e4  vmovaps [rsp+0x30], xmm3
000075038bdd80ea  vmovaps [rsp+0x40], xmm4
000075038bdd80f0  vmovaps [rsp+0x50], xmm5
000075038bdd80f6  vmovaps [rsp+0x60], xmm6
000075038bdd80fc  vmovaps [rsp+0x70], xmm8
000075038bdd8102  vmovaps [rsp+0x80], xmm9
000075038bdd810b  vmovaps [rsp+0x90], xmm10
000075038bdd8114  vmovaps [rsp+0xA0], xmm11
000075038bdd811d  vmovaps [rsp+0xB0], xmm12
000075038bdd8126  vmovaps [rsp+0xC0], xmm13
000075038bdd812f  vmovaps [rsp+0xD0], xmm14
000075038bdd8138  vmovaps [rsp+0xE0], xmm15
000075038bdd8141  sub rsp, 0x30
000075038bdd8145  movaps [rsp], xmm7
000075038bdd8149  movaps [rsp+0x10], xmm13
000075038bdd814f  movaps [rsp+0x20], xmm10
000075038bdd8155  lea rdi, [rsp]
000075038bdd8159  mov esi, 0x00
000075038bdd815e  mov rax, 0x56ADB4492530
000075038bdd8168  call rax
000075038bdd816a  movaps xmm7, [rsp]
000075038bdd816e  add rsp, 0x30
000075038bdd8172  vmovaps xmm0, [rsp]
000075038bdd8177  vmovaps xmm1, [rsp+0x10]
000075038bdd817d  vmovaps xmm2, [rsp+0x20]
000075038bdd8183  vmovaps xmm3, [rsp+0x30]
000075038bdd8189  vmovaps xmm4, [rsp+0x40]
000075038bdd818f  vmovaps xmm5, [rsp+0x50]
000075038bdd8195  vmovaps xmm6, [rsp+0x60]
000075038bdd819b  vmovaps xmm8, [rsp+0x70]
000075038bdd81a1  vmovaps xmm9, [rsp+0x80]
000075038bdd81aa  vmovaps xmm10, [rsp+0x90]
000075038bdd81b3  vmovaps xmm11, [rsp+0xA0]
000075038bdd81bc  vmovaps xmm12, [rsp+0xB0]
000075038bdd81c5  vmovaps xmm13, [rsp+0xC0]
000075038bdd81ce  vmovaps xmm14, [rsp+0xD0]
000075038bdd81d7  vmovaps xmm15, [rsp+0xE0]
000075038bdd81e0  add rsp, 0xF0
000075038bdd81e7  pop r11
000075038bdd81e9  pop r10
000075038bdd81eb  pop r9
000075038bdd81ed  pop r8
000075038bdd81ef  pop rsi
000075038bdd81f0  pop rdi
000075038bdd81f1  pop rdx
000075038bdd81f2  pop rcx
000075038bdd81f3  pop rax
000075038bdd81f4  add rsp, 0x08
000075038bdd81f8  jmp 0x000075038BDD3498
000075038bdd81fd  sub rsp, 0x08
000075038bdd8201  push rax
000075038bdd8202  push rcx
000075038bdd8203  push rdx
000075038bdd8204  push rdi
000075038bdd8205  push rsi
000075038bdd8206  push r8
000075038bdd8208  push r9
000075038bdd820a  push r10
000075038bdd820c  push r11
000075038bdd820e  sub rsp, 0xF0
000075038bdd8215  vmovaps [rsp], xmm0
000075038bdd821a  vmovaps [rsp+0x10], xmm1
000075038bdd8220  vmovaps [rsp+0x20], xmm2
000075038bdd8226  vmovaps [rsp+0x30], xmm3
000075038bdd822c  vmovaps [rsp+0x40], xmm4
000075038bdd8232  vmovaps [rsp+0x50], xmm5
000075038bdd8238  vmovaps [rsp+0x60], xmm6
000075038bdd823e  vmovaps [rsp+0x70], xmm7
000075038bdd8244  vmovaps [rsp+0x80], xmm8
000075038bdd824d  vmovaps [rsp+0x90], xmm9
000075038bdd8256  vmovaps [rsp+0xA0], xmm11
000075038bdd825f  vmovaps [rsp+0xB0], xmm12
000075038bdd8268  vmovaps [rsp+0xC0], xmm13
000075038bdd8271  vmovaps [rsp+0xD0], xmm14
000075038bdd827a  vmovaps [rsp+0xE0], xmm15
000075038bdd8283  sub rsp, 0x30
000075038bdd8287  movaps [rsp], xmm10
000075038bdd828c  movaps [rsp+0x10], xmm11
000075038bdd8292  movaps [rsp+0x20], xmm13
000075038bdd8298  lea rdi, [rsp]
000075038bdd829c  mov esi, 0x00
000075038bdd82a1  mov rax, 0x56ADB4492530
000075038bdd82ab  call rax
000075038bdd82ad  movaps xmm10, [rsp]
000075038bdd82b2  add rsp, 0x30
000075038bdd82b6  vmovaps xmm0, [rsp]
000075038bdd82bb  vmovaps xmm1, [rsp+0x10]
000075038bdd82c1  vmovaps xmm2, [rsp+0x20]
000075038bdd82c7  vmovaps xmm3, [rsp+0x30]
000075038bdd82cd  vmovaps xmm4, [rsp+0x40]
000075038bdd82d3  vmovaps xmm5, [rsp+0x50]
000075038bdd82d9  vmovaps xmm6, [rsp+0x60]
000075038bdd82df  vmovaps xmm7, [rsp+0x70]
000075038bdd82e5  vmovaps xmm8, [rsp+0x80]
000075038bdd82ee  vmovaps xmm9, [rsp+0x90]
000075038bdd82f7  vmovaps xmm11, [rsp+0xA0]
000075038bdd8300  vmovaps xmm12, [rsp+0xB0]
000075038bdd8309  vmovaps xmm13, [rsp+0xC0]
000075038bdd8312  vmovaps xmm14, [rsp+0xD0]
000075038bdd831b  vmovaps xmm15, [rsp+0xE0]
000075038bdd8324  add rsp, 0xF0
000075038bdd832b  pop r11
000075038bdd832d  pop r10
000075038bdd832f  pop r9
000075038bdd8331  pop r8
000075038bdd8333  pop rsi
000075038bdd8334  pop rdi
000075038bdd8335  pop rdx
000075038bdd8336  pop rcx
000075038bdd8337  pop rax
000075038bdd8338  add rsp, 0x08
000075038bdd833c  jmp 0x000075038BDD34C6
000075038bdd8341  sub rsp, 0x08
000075038bdd8345  push rax
000075038bdd8346  push rcx
000075038bdd8347  push rdx
000075038bdd8348  push rdi
000075038bdd8349  push rsi
000075038bdd834a  push r8
000075038bdd834c  push r9
000075038bdd834e  push r10
000075038bdd8350  push r11
000075038bdd8352  sub rsp, 0xF0
000075038bdd8359  vmovaps [rsp], xmm0
000075038bdd835e  vmovaps [rsp+0x10], xmm1
000075038bdd8364  vmovaps [rsp+0x20], xmm2
000075038bdd836a  vmovaps [rsp+0x30], xmm3
000075038bdd8370  vmovaps [rsp+0x40], xmm4
000075038bdd8376  vmovaps [rsp+0x50], xmm5
000075038bdd837c  vmovaps [rsp+0x60], xmm6
000075038bdd8382  vmovaps [rsp+0x70], xmm7
000075038bdd8388  vmovaps [rsp+0x80], xmm8
000075038bdd8391  vmovaps [rsp+0x90], xmm9
000075038bdd839a  vmovaps [rsp+0xA0], xmm10
000075038bdd83a3  vmovaps [rsp+0xB0], xmm12
000075038bdd83ac  vmovaps [rsp+0xC0], xmm13
000075038bdd83b5  vmovaps [rsp+0xD0], xmm14
000075038bdd83be  vmovaps [rsp+0xE0], xmm15
000075038bdd83c7  sub rsp, 0x30
000075038bdd83cb  movaps [rsp], xmm11
000075038bdd83d0  movaps [rsp+0x10], xmm14
000075038bdd83d6  movaps [rsp+0x20], xmm13
000075038bdd83dc  lea rdi, [rsp]
000075038bdd83e0  mov esi, 0x00
000075038bdd83e5  mov rax, 0x56ADB4492530
000075038bdd83ef  call rax
000075038bdd83f1  movaps xmm11, [rsp]
000075038bdd83f6  add rsp, 0x30
000075038bdd83fa  vmovaps xmm0, [rsp]
000075038bdd83ff  vmovaps xmm1, [rsp+0x10]
000075038bdd8405  vmovaps xmm2, [rsp+0x20]
000075038bdd840b  vmovaps xmm3, [rsp+0x30]
000075038bdd8411  vmovaps xmm4, [rsp+0x40]
000075038bdd8417  vmovaps xmm5, [rsp+0x50]
000075038bdd841d  vmovaps xmm6, [rsp+0x60]
000075038bdd8423  vmovaps xmm7, [rsp+0x70]
000075038bdd8429  vmovaps xmm8, [rsp+0x80]
000075038bdd8432  vmovaps xmm9, [rsp+0x90]
000075038bdd843b  vmovaps xmm10, [rsp+0xA0]
000075038bdd8444  vmovaps xmm12, [rsp+0xB0]
000075038bdd844d  vmovaps xmm13, [rsp+0xC0]
000075038bdd8456  vmovaps xmm14, [rsp+0xD0]
000075038bdd845f  vmovaps xmm15, [rsp+0xE0]
000075038bdd8468  add rsp, 0xF0
000075038bdd846f  pop r11
000075038bdd8471  pop r10
000075038bdd8473  pop r9
000075038bdd8475  pop r8
000075038bdd8477  pop rsi
000075038bdd8478  pop rdi
000075038bdd8479  pop rdx
000075038bdd847a  pop rcx
000075038bdd847b  pop rax
000075038bdd847c  add rsp, 0x08
000075038bdd8480  jmp 0x000075038BDD34F4
000075038bdd8485  sub rsp, 0x08
000075038bdd8489  push rax
000075038bdd848a  push rcx
000075038bdd848b  push rdx
000075038bdd848c  push rdi
000075038bdd848d  push rsi
000075038bdd848e  push r8
000075038bdd8490  push r9
000075038bdd8492  push r10
000075038bdd8494  push r11
000075038bdd8496  sub rsp, 0xF0
000075038bdd849d  vmovaps [rsp], xmm0
000075038bdd84a2  vmovaps [rsp+0x10], xmm1
000075038bdd84a8  vmovaps [rsp+0x20], xmm2
000075038bdd84ae  vmovaps [rsp+0x30], xmm3
000075038bdd84b4  vmovaps [rsp+0x40], xmm4
000075038bdd84ba  vmovaps [rsp+0x50], xmm5
000075038bdd84c0  vmovaps [rsp+0x60], xmm6
000075038bdd84c6  vmovaps [rsp+0x70], xmm7
000075038bdd84cc  vmovaps [rsp+0x80], xmm8
000075038bdd84d5  vmovaps [rsp+0x90], xmm9
000075038bdd84de  vmovaps [rsp+0xA0], xmm10
000075038bdd84e7  vmovaps [rsp+0xB0], xmm11
000075038bdd84f0  vmovaps [rsp+0xC0], xmm12
000075038bdd84f9  vmovaps [rsp+0xD0], xmm13
000075038bdd8502  vmovaps [rsp+0xE0], xmm15
000075038bdd850b  sub rsp, 0x30
000075038bdd850f  movaps [rsp], xmm14
000075038bdd8514  movaps [rsp+0x10], xmm12
000075038bdd851a  movaps [rsp+0x20], xmm9
000075038bdd8520  lea rdi, [rsp]
000075038bdd8524  mov esi, 0x00
000075038bdd8529  mov rax, 0x56ADB4492530
000075038bdd8533  call rax
000075038bdd8535  movaps xmm14, [rsp]
000075038bdd853a  add rsp, 0x30
000075038bdd853e  vmovaps xmm0, [rsp]
000075038bdd8543  vmovaps xmm1, [rsp+0x10]
000075038bdd8549  vmovaps xmm2, [rsp+0x20]
000075038bdd854f  vmovaps xmm3, [rsp+0x30]
000075038bdd8555  vmovaps xmm4, [rsp+0x40]
000075038bdd855b  vmovaps xmm5, [rsp+0x50]
000075038bdd8561  vmovaps xmm6, [rsp+0x60]
000075038bdd8567  vmovaps xmm7, [rsp+0x70]
000075038bdd856d  vmovaps xmm8, [rsp+0x80]
000075038bdd8576  vmovaps xmm9, [rsp+0x90]
000075038bdd857f  vmovaps xmm10, [rsp+0xA0]
000075038bdd8588  vmovaps xmm11, [rsp+0xB0]
000075038bdd8591  vmovaps xmm12, [rsp+0xC0]
000075038bdd859a  vmovaps xmm13, [rsp+0xD0]
000075038bdd85a3  vmovaps xmm15, [rsp+0xE0]
000075038bdd85ac  add rsp, 0xF0
000075038bdd85b3  pop r11
000075038bdd85b5  pop r10
000075038bdd85b7  pop r9
000075038bdd85b9  pop r8
000075038bdd85bb  pop rsi
000075038bdd85bc  pop rdi
000075038bdd85bd  pop rdx
000075038bdd85be  pop rcx
000075038bdd85bf  pop rax
000075038bdd85c0  add rsp, 0x08
000075038bdd85c4  jmp 0x000075038BDD350F
000075038bdd85c9  sub rsp, 0x08
000075038bdd85cd  push rax
000075038bdd85ce  push rcx
000075038bdd85cf  push rdx
000075038bdd85d0  push rdi
000075038bdd85d1  push rsi
000075038bdd85d2  push r8
000075038bdd85d4  push r9
000075038bdd85d6  push r10
000075038bdd85d8  push r11
000075038bdd85da  sub rsp, 0xF0
000075038bdd85e1  vmovaps [rsp], xmm0
000075038bdd85e6  vmovaps [rsp+0x10], xmm1
000075038bdd85ec  vmovaps [rsp+0x20], xmm2
000075038bdd85f2  vmovaps [rsp+0x30], xmm3
000075038bdd85f8  vmovaps [rsp+0x40], xmm4
000075038bdd85fe  vmovaps [rsp+0x50], xmm5
000075038bdd8604  vmovaps [rsp+0x60], xmm6
000075038bdd860a  vmovaps [rsp+0x70], xmm7
000075038bdd8610  vmovaps [rsp+0x80], xmm8
000075038bdd8619  vmovaps [rsp+0x90], xmm9
000075038bdd8622  vmovaps [rsp+0xA0], xmm10
000075038bdd862b  vmovaps [rsp+0xB0], xmm11
000075038bdd8634  vmovaps [rsp+0xC0], xmm12
000075038bdd863d  vmovaps [rsp+0xD0], xmm14
000075038bdd8646  vmovaps [rsp+0xE0], xmm15
000075038bdd864f  sub rsp, 0x30
000075038bdd8653  movaps [rsp], xmm13
000075038bdd8658  movaps [rsp+0x10], xmm8
000075038bdd865e  movaps [rsp+0x20], xmm15
000075038bdd8664  lea rdi, [rsp]
000075038bdd8668  mov esi, 0x00
000075038bdd866d  mov rax, 0x56ADB4492530
000075038bdd8677  call rax
000075038bdd8679  movaps xmm13, [rsp]
000075038bdd867e  add rsp, 0x30
000075038bdd8682  vmovaps xmm0, [rsp]
000075038bdd8687  vmovaps xmm1, [rsp+0x10]
000075038bdd868d  vmovaps xmm2, [rsp+0x20]
000075038bdd8693  vmovaps xmm3, [rsp+0x30]
000075038bdd8699  vmovaps xmm4, [rsp+0x40]
000075038bdd869f  vmovaps xmm5, [rsp+0x50]
000075038bdd86a5  vmovaps xmm6, [rsp+0x60]
000075038bdd86ab  vmovaps xmm7, [rsp+0x70]
000075038bdd86b1  vmovaps xmm8, [rsp+0x80]
000075038bdd86ba  vmovaps xmm9, [rsp+0x90]
000075038bdd86c3  vmovaps xmm10, [rsp+0xA0]
000075038bdd86cc  vmovaps xmm11, [rsp+0xB0]
000075038bdd86d5  vmovaps xmm12, [rsp+0xC0]
000075038bdd86de  vmovaps xmm14, [rsp+0xD0]
000075038bdd86e7  vmovaps xmm15, [rsp+0xE0]
000075038bdd86f0  add rsp, 0xF0
000075038bdd86f7  pop r11
000075038bdd86f9  pop r10
000075038bdd86fb  pop r9
000075038bdd86fd  pop r8
000075038bdd86ff  pop rsi
000075038bdd8700  pop rdi
000075038bdd8701  pop rdx
000075038bdd8702  pop rcx
000075038bdd8703  pop rax
000075038bdd8704  add rsp, 0x08
000075038bdd8708  jmp 0x000075038BDD3532
000075038bdd870d  sub rsp, 0x08
000075038bdd8711  push rax
000075038bdd8712  push rcx
000075038bdd8713  push rdx
000075038bdd8714  push rdi
000075038bdd8715  push rsi
000075038bdd8716  push r8
000075038bdd8718  push r9
000075038bdd871a  push r10
000075038bdd871c  push r11
000075038bdd871e  sub rsp, 0xF0
000075038bdd8725  vmovaps [rsp], xmm0
000075038bdd872a  vmovaps [rsp+0x10], xmm1
000075038bdd8730  vmovaps [rsp+0x20], xmm2
000075038bdd8736  vmovaps [rsp+0x30], xmm3
000075038bdd873c  vmovaps [rsp+0x40], xmm4
000075038bdd8742  vmovaps [rsp+0x50], xmm5
000075038bdd8748  vmovaps [rsp+0x60], xmm6
000075038bdd874e  vmovaps [rsp+0x70], xmm7
000075038bdd8754  vmovaps [rsp+0x80], xmm8
000075038bdd875d  vmovaps [rsp+0x90], xmm9
000075038bdd8766  vmovaps [rsp+0xA0], xmm10
000075038bdd876f  vmovaps [rsp+0xB0], xmm11
000075038bdd8778  vmovaps [rsp+0xC0], xmm12
000075038bdd8781  vmovaps [rsp+0xD0], xmm13
000075038bdd878a  vmovaps [rsp+0xE0], xmm14
000075038bdd8793  sub rsp, 0x30
000075038bdd8797  movaps [rsp], xmm15
000075038bdd879c  movaps [rsp+0x10], xmm1
000075038bdd87a1  movaps [rsp+0x20], xmm10
000075038bdd87a7  lea rdi, [rsp]
000075038bdd87ab  mov esi, 0x00
000075038bdd87b0  mov rax, 0x56ADB4492530
000075038bdd87ba  call rax
000075038bdd87bc  movaps xmm15, [rsp]
000075038bdd87c1  add rsp, 0x30
000075038bdd87c5  vmovaps xmm0, [rsp]
000075038bdd87ca  vmovaps xmm1, [rsp+0x10]
000075038bdd87d0  vmovaps xmm2, [rsp+0x20]
000075038bdd87d6  vmovaps xmm3, [rsp+0x30]
000075038bdd87dc  vmovaps xmm4, [rsp+0x40]
000075038bdd87e2  vmovaps xmm5, [rsp+0x50]
000075038bdd87e8  vmovaps xmm6, [rsp+0x60]
000075038bdd87ee  vmovaps xmm7, [rsp+0x70]
000075038bdd87f4  vmovaps xmm8, [rsp+0x80]
000075038bdd87fd  vmovaps xmm9, [rsp+0x90]
000075038bdd8806  vmovaps xmm10, [rsp+0xA0]
000075038bdd880f  vmovaps xmm11, [rsp+0xB0]
000075038bdd8818  vmovaps xmm12, [rsp+0xC0]
000075038bdd8821  vmovaps xmm13, [rsp+0xD0]
000075038bdd882a  vmovaps xmm14, [rsp+0xE0]
000075038bdd8833  add rsp, 0xF0
000075038bdd883a  pop r11
000075038bdd883c  pop r10
000075038bdd883e  pop r9
000075038bdd8840  pop r8
000075038bdd8842  pop rsi
000075038bdd8843  pop rdi
000075038bdd8844  pop rdx
000075038bdd8845  pop rcx
000075038bdd8846  pop rax
000075038bdd8847  add rsp, 0x08
000075038bdd884b  jmp 0x000075038BDD3555
000075038bdd8850  sub rsp, 0x08
000075038bdd8854  push rax
000075038bdd8855  push rcx
000075038bdd8856  push rdx
000075038bdd8857  push rdi
000075038bdd8858  push rsi
000075038bdd8859  push r8
000075038bdd885b  push r9
000075038bdd885d  push r10
000075038bdd885f  push r11
000075038bdd8861  sub rsp, 0xF0
000075038bdd8868  vmovaps [rsp], xmm0
000075038bdd886d  vmovaps [rsp+0x10], xmm2
000075038bdd8873  vmovaps [rsp+0x20], xmm3
000075038bdd8879  vmovaps [rsp+0x30], xmm4
000075038bdd887f  vmovaps [rsp+0x40], xmm5
000075038bdd8885  vmovaps [rsp+0x50], xmm6
000075038bdd888b  vmovaps [rsp+0x60], xmm7
000075038bdd8891  vmovaps [rsp+0x70], xmm8
000075038bdd8897  vmovaps [rsp+0x80], xmm9
000075038bdd88a0  vmovaps [rsp+0x90], xmm10
000075038bdd88a9  vmovaps [rsp+0xA0], xmm11
000075038bdd88b2  vmovaps [rsp+0xB0], xmm12
000075038bdd88bb  vmovaps [rsp+0xC0], xmm13
000075038bdd88c4  vmovaps [rsp+0xD0], xmm14
000075038bdd88cd  vmovaps [rsp+0xE0], xmm15
000075038bdd88d6  sub rsp, 0x30
000075038bdd88da  movaps [rsp], xmm1
000075038bdd88de  movaps [rsp+0x10], xmm7
000075038bdd88e3  movaps [rsp+0x20], xmm11
000075038bdd88e9  lea rdi, [rsp]
000075038bdd88ed  mov esi, 0x00
000075038bdd88f2  mov rax, 0x56ADB4492530
000075038bdd88fc  call rax
000075038bdd88fe  movaps xmm1, [rsp]
000075038bdd8902  add rsp, 0x30
000075038bdd8906  vmovaps xmm0, [rsp]
000075038bdd890b  vmovaps xmm2, [rsp+0x10]
000075038bdd8911  vmovaps xmm3, [rsp+0x20]
000075038bdd8917  vmovaps xmm4, [rsp+0x30]
000075038bdd891d  vmovaps xmm5, [rsp+0x40]
000075038bdd8923  vmovaps xmm6, [rsp+0x50]
000075038bdd8929  vmovaps xmm7, [rsp+0x60]
000075038bdd892f  vmovaps xmm8, [rsp+0x70]
000075038bdd8935  vmovaps xmm9, [rsp+0x80]
000075038bdd893e  vmovaps xmm10, [rsp+0x90]
000075038bdd8947  vmovaps xmm11, [rsp+0xA0]
000075038bdd8950  vmovaps xmm12, [rsp+0xB0]
000075038bdd8959  vmovaps xmm13, [rsp+0xC0]
000075038bdd8962  vmovaps xmm14, [rsp+0xD0]
000075038bdd896b  vmovaps xmm15, [rsp+0xE0]
000075038bdd8974  add rsp, 0xF0
000075038bdd897b  pop r11
000075038bdd897d  pop r10
000075038bdd897f  pop r9
000075038bdd8981  pop r8
000075038bdd8983  pop rsi
000075038bdd8984  pop rdi
000075038bdd8985  pop rdx
000075038bdd8986  pop rcx
000075038bdd8987  pop rax
000075038bdd8988  add rsp, 0x08
000075038bdd898c  jmp 0x000075038BDD3576
000075038bdd8991  call 0x000075038BC0D600
000075038bdd8996  jmp 0x000075038BDD3589
000075038bdd899b  call 0x000075038BC0C380
000075038bdd89a0  jmp 0x000075038BDD3594
000075038bdd89a5  call 0x000075038BC0E880
000075038bdd89aa  jmp 0x000075038BDD359F
000075038bdd89af  call 0x000075038BBFF540
000075038bdd89b4  jmp 0x000075038BDD35AA
000075038bdd89b9  int3
000075038bdd89ba  nop [rax+rax*1], ax
000075038bdd89c0  mov rax, [r15+0x40]
000075038bdd89c4  mov r14, [r15+0x58]
000075038bdd89c8  lea r12, [rax+r14*1]
000075038bdd89cc  movaps xmm1, [r15+0x1D0]
000075038bdd89d4  vmovaps [rsp+0x10], xmm1
000075038bdd89da  vmovaps xmm15, [rsp+0x10]
000075038bdd89e0  por xmm1, xmm15
000075038bdd89e5  movaps xmm14, [r15+0x1A0]
000075038bdd89ed  vmovaps [rsp+0x10], xmm14
000075038bdd89f3  vmovaps xmm13, [rsp+0x10]
000075038bdd89f9  por xmm14, xmm13
000075038bdd89fe  lea rax, [r12+0x30]
000075038bdd8a03  mov r11, [r13+rax*1]
000075038bdd8a08  lea rax, [r12+0x38]
000075038bdd8a0d  mov r10, [r13+rax*1]
000075038bdd8a12  movq xmm13, r11
000075038bdd8a17  movq xmm12, r10
000075038bdd8a1c  movq xmm13, xmm13
000075038bdd8a21  vmovaps [rsp+0x10], xmm13
000075038bdd8a27  movq xmm13, xmm13
000075038bdd8a2c  movaps [r15+0x130], xmm13
000075038bdd8a34  movq xmm12, xmm12
000075038bdd8a39  vmovaps [rsp+0x20], xmm12
000075038bdd8a3f  movq xmm12, xmm12
000075038bdd8a44  movaps [r15+0x280], xmm12
000075038bdd8a4c  movaps xmm13, [r15+0x270]
000075038bdd8a54  vmovaps [rsp+0x30], xmm13
000075038bdd8a5a  vmovaps xmm12, [rsp+0x30]
000075038bdd8a60  por xmm13, xmm12
000075038bdd8a65  lea rax, [r12+0x20]
000075038bdd8a6a  mov r11, [r13+rax*1]
000075038bdd8a6f  lea rax, [r12+0x28]
000075038bdd8a74  mov r10, [r13+rax*1]
000075038bdd8a79  movq xmm12, r11
000075038bdd8a7e  movq xmm11, r10
000075038bdd8a83  movq xmm12, xmm12
000075038bdd8a88  vmovaps [rsp+0x30], xmm12
000075038bdd8a8e  movq xmm12, xmm12
000075038bdd8a93  movaps [r15+0x150], xmm12
000075038bdd8a9b  movq xmm11, xmm11
000075038bdd8aa0  vmovaps [rsp+0x40], xmm11
000075038bdd8aa6  movq xmm11, xmm11
000075038bdd8aab  movaps [r15+0x140], xmm11
000075038bdd8ab3  lea rax, [r12+0x10]
000075038bdd8ab8  mov r11, [r13+rax*1]
000075038bdd8abd  lea rax, [r12+0x18]
000075038bdd8ac2  mov r10, [r13+rax*1]
000075038bdd8ac7  movq xmm12, r11
000075038bdd8acc  movq xmm11, r10
000075038bdd8ad1  movq xmm12, xmm12
000075038bdd8ad6  vmovaps [rsp+0x50], xmm12
000075038bdd8adc  movq xmm12, xmm12
000075038bdd8ae1  movaps [r15+0x170], xmm12
000075038bdd8ae9  movq xmm11, xmm11
000075038bdd8aee  vmovaps [rsp+0x60], xmm11
000075038bdd8af4  movq xmm11, xmm11
000075038bdd8af9  movaps [r15+0x160], xmm11
000075038bdd8b01  mov rax, [r13+r12*1]
000075038bdd8b06  vmovq xmm12, rax
000075038bdd8b0b  vpbroadcastq xmm12, xmm12
000075038bdd8b10  lea rax, [r12+0x08]
000075038bdd8b15  mov r12, [r13+rax*1]
000075038bdd8b1a  movq xmm11, r12
000075038bdd8b1f  movaps [r15+0x230], xmm11
000075038bdd8b27  mov rax, [r15+0xF8]
000075038bdd8b2e  lea r12, [rax+0x50]
000075038bdd8b32  movups xmm11, [r13+r12*1]
000075038bdd8b38  lea r12, [rax+0x60]
000075038bdd8b3c  movups xmm10, [r13+r12*1]
000075038bdd8b42  lea r12, [rax+0x30]
000075038bdd8b46  movups xmm9, [r13+r12*1]
000075038bdd8b4c  mov r12, [r15+0x50]
000075038bdd8b50  lea r11, [r12+r14*1]
000075038bdd8b54  mov [r15+0x60], r11
000075038bdd8b58  lea r12, [r14+0x40]
000075038bdd8b5c  mov [r15+0x58], r12
000075038bdd8b60  movaps xmm8, xmm12
000075038bdd8b64  mulpd xmm8, xmm15
000075038bdd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
000075038bdd8b6f  ptest xmm7, xmm7
000075038bdd8b74  jnz 0x000075038BDD9997
000075038bdd8b7a  movq xmm15, qword ptr [r15+0x230]
000075038bdd8b83  vmovaps [rsp+0x70], xmm15
000075038bdd8b89  vpermilpd xmm15, xmm15, 0x00
000075038bdd8b8f  movaps xmm7, xmm9
000075038bdd8b93  mulpd xmm7, xmm15
000075038bdd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
000075038bdd8b9d  ptest xmm6, xmm6
000075038bdd8ba2  jnz 0x000075038BDD9ADB
000075038bdd8ba8  vxorps xmm15, xmm15, xmm15
000075038bdd8bad  vpbroadcastq xmm15, xmm15
000075038bdd8bb2  movaps xmm9, xmm12
000075038bdd8bb6  mulpd xmm9, xmm10
000075038bdd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
000075038bdd8bc1  ptest xmm6, xmm6
000075038bdd8bc6  jnz 0x000075038BDD9C1D
000075038bdd8bcc  movaps xmm10, xmm12
000075038bdd8bd0  mulpd xmm10, xmm11
000075038bdd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
000075038bdd8bdb  ptest xmm6, xmm6
000075038bdd8be0  jnz 0x000075038BDD9D61
000075038bdd8be6  movaps xmm11, [r15+0x1F0]
000075038bdd8bee  movaps xmm6, xmm12
000075038bdd8bf2  mulpd xmm6, xmm11
000075038bdd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
000075038bdd8bfc  ptest xmm5, xmm5
000075038bdd8c01  jnz 0x000075038BDD9EA5
000075038bdd8c07  movaps xmm12, [r15+0x2A0]
000075038bdd8c0f  vmovaps [rsp+0x80], xmm12
000075038bdd8c18  vmovaps xmm11, [rsp+0x80]
000075038bdd8c21  por xmm12, xmm11
000075038bdd8c26  movaps xmm11, [r15+0x250]
000075038bdd8c2e  vmovaps [rsp+0x80], xmm11
000075038bdd8c37  vmovaps xmm5, [rsp+0x80]
000075038bdd8c40  por xmm11, xmm5
000075038bdd8c45  vmovaps xmm4, [rsp+0x70]
000075038bdd8c4b  vpermilpd xmm4, xmm4, 0x00
000075038bdd8c51  movaps xmm3, xmm5
000075038bdd8c54  mulpd xmm3, xmm4
000075038bdd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
000075038bdd8c5d  ptest xmm2, xmm2
000075038bdd8c62  jnz 0x000075038BDD9FE7
000075038bdd8c68  mov [rsp+0x80], rax
000075038bdd8c70  xor eax, eax
000075038bdd8c72  mov r14d, 0x200
000075038bdd8c78  cmp r12, r14
000075038bdd8c7b  cmc
000075038bdd8c7c  lahf
000075038bdd8c7d  seto al
000075038bdd8c80  mov [r15+0x108], eax
000075038bdd8c87  movaps xmm5, xmm8
000075038bdd8c8b  addpd xmm5, xmm15
000075038bdd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
000075038bdd8c95  ptest xmm4, xmm4
000075038bdd8c9a  jnz 0x000075038BDDA127
000075038bdd8ca0  movaps xmm8, [r15+0x1B0]
000075038bdd8ca8  movaps xmm4, xmm9
000075038bdd8cac  addpd xmm4, xmm8
000075038bdd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
000075038bdd8cb6  ptest xmm2, xmm2
000075038bdd8cbb  jnz 0x000075038BDDA269
000075038bdd8cc1  movaps xmm9, xmm10
000075038bdd8cc5  addpd xmm9, xmm8
000075038bdd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
000075038bdd8cd0  ptest xmm2, xmm2
000075038bdd8cd5  jnz 0x000075038BDDA3AB
000075038bdd8cdb  movaps xmm10, [r15+0x2F0]
000075038bdd8ce3  vmovaps [rsp+0x90], xmm10
000075038bdd8cec  vmovaps xmm8, [rsp+0x90]
000075038bdd8cf5  por xmm10, xmm8
000075038bdd8cfa  movaps xmm8, [r15+0x2E0]
000075038bdd8d02  vmovaps [rsp+0x90], xmm8
000075038bdd8d0b  vmovaps xmm2, [rsp+0x90]
000075038bdd8d14  por xmm8, xmm2
000075038bdd8d19  movaps xmm2, [r15+0x2D0]
000075038bdd8d21  vmovaps [rsp+0x90], xmm2
000075038bdd8d2a  vmovaps [rsp+0xA0], xmm1
000075038bdd8d33  vmovaps xmm1, [rsp+0x90]
000075038bdd8d3c  por xmm2, xmm1
000075038bdd8d40  movaps xmm1, [r15+0x200]
000075038bdd8d48  vmovaps [rsp+0x90], xmm1
000075038bdd8d51  vmovaps [rsp+0xB0], xmm15
000075038bdd8d5a  vmovaps xmm15, [rsp+0x90]
000075038bdd8d63  por xmm1, xmm15
000075038bdd8d68  movaps xmm15, [r15+0x1C0]
000075038bdd8d70  vmovaps [rsp+0x90], xmm15
000075038bdd8d79  vmovaps [rsp+0xC0], xmm1
000075038bdd8d82  vmovaps xmm1, [rsp+0x90]
000075038bdd8d8b  por xmm15, xmm1
000075038bdd8d90  movaps xmm1, [r15+0x190]
000075038bdd8d98  vmovaps [rsp+0x90], xmm1
000075038bdd8da1  vmovaps [rsp+0xD0], xmm15
000075038bdd8daa  vmovaps xmm15, [rsp+0x90]
000075038bdd8db3  por xmm1, xmm15
000075038bdd8db8  movaps xmm15, [r15+0x300]
000075038bdd8dc0  vmovaps [rsp+0x90], xmm15
000075038bdd8dc9  vmovaps [rsp+0xE0], xmm1
000075038bdd8dd2  vmovaps xmm1, [rsp+0x90]
000075038bdd8ddb  por xmm15, xmm1
000075038bdd8de0  mov rax, [rsp+0x80]
000075038bdd8de8  lea r14, [rax+0xA0]
000075038bdd8def  movups xmm1, [r13+r14*1]
000075038bdd8df5  lea r14, [rax+0xB0]
000075038bdd8dfc  vmovaps [rsp+0x80], xmm1
000075038bdd8e05  movups xmm1, [r13+r14*1]
000075038bdd8e0b  vmovaps [rsp+0x90], xmm1
000075038bdd8e14  vmovaps [rsp+0xF0], xmm15
000075038bdd8e1d  vmovaps xmm15, [rsp+0xB0]
000075038bdd8e26  vmovaps [rsp+0xB0], xmm14
000075038bdd8e2f  movaps xmm1, xmm6
000075038bdd8e32  addpd xmm1, xmm15
000075038bdd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
000075038bdd8e3c  ptest xmm14, xmm14
000075038bdd8e42  jnz 0x000075038BDDA503
000075038bdd8e48  lea r14, [rax+0xF0]
000075038bdd8e4f  movups xmm15, [r13+r14*1]
000075038bdd8e55  movaps xmm14, xmm4
000075038bdd8e59  addpd xmm14, xmm3
000075038bdd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
000075038bdd8e64  ptest xmm6, xmm6
000075038bdd8e69  jnz 0x000075038BDDA64E
000075038bdd8e6f  movaps xmm6, xmm9
000075038bdd8e73  addpd xmm6, xmm7
000075038bdd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
000075038bdd8e7c  ptest xmm4, xmm4
000075038bdd8e81  jnz 0x000075038BDDA790
000075038bdd8e87  vmovaps xmm9, [rsp+0x70]
000075038bdd8e8d  vpermilpd xmm9, xmm9, 0x00
000075038bdd8e93  vmovaps xmm4, [rsp+0x90]
000075038bdd8e9c  movaps xmm7, xmm4
000075038bdd8e9f  mulpd xmm7, xmm9
000075038bdd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
000075038bdd8ea9  ptest xmm3, xmm3
000075038bdd8eae  jnz 0x000075038BDDA8D1
000075038bdd8eb4  vmovaps xmm9, [rsp+0x50]
000075038bdd8eba  vpermilpd xmm9, xmm9, 0x00
000075038bdd8ec0  movaps xmm4, xmm15
000075038bdd8ec4  mulpd xmm4, xmm9
000075038bdd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
000075038bdd8ece  ptest xmm3, xmm3
000075038bdd8ed3  jnz 0x000075038BDDAA12
000075038bdd8ed9  lea r14, [rax+0xE0]
000075038bdd8ee0  movups xmm15, [r13+r14*1]
000075038bdd8ee6  vmovaps xmm9, [rsp+0x70]
000075038bdd8eec  vpermilpd xmm9, xmm9, 0x00
000075038bdd8ef2  vmovaps [rsp+0x70], xmm1
000075038bdd8ef8  vmovaps xmm1, [rsp+0x80]
000075038bdd8f01  vmovaps [rsp+0x80], xmm15
000075038bdd8f0a  movaps xmm3, xmm1
000075038bdd8f0d  mulpd xmm3, xmm9
000075038bdd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
000075038bdd8f17  ptest xmm15, xmm15
000075038bdd8f1d  jnz 0x000075038BDDAB5E
000075038bdd8f23  vmovaps xmm1, [rsp+0xF0]
000075038bdd8f2c  vmovaps xmm15, [rsp+0xF0]
000075038bdd8f35  por xmm1, xmm15
000075038bdd8f3a  movaps [r15+0x300], xmm1
000075038bdd8f42  vmovaps xmm15, [rsp+0xE0]
000075038bdd8f4b  vmovaps xmm9, [rsp+0xE0]
000075038bdd8f54  por xmm15, xmm9
000075038bdd8f59  movaps [r15+0x190], xmm15
000075038bdd8f61  vmovaps xmm9, [rsp+0x50]
000075038bdd8f67  vpermilpd xmm9, xmm9, 0x00
000075038bdd8f6d  vmovaps [rsp+0x90], xmm1
000075038bdd8f76  vmovaps [rsp+0xE0], xmm15
000075038bdd8f7f  vmovaps xmm15, [rsp+0x80]
000075038bdd8f88  vmovaps [rsp+0x80], xmm14
000075038bdd8f91  movaps xmm1, xmm15
000075038bdd8f95  mulpd xmm1, xmm9
000075038bdd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
000075038bdd8f9f  ptest xmm14, xmm14
000075038bdd8fa5  jnz 0x000075038BDDAC9F
000075038bdd8fab  lea r14, [rax+0x90]
000075038bdd8fb2  movups xmm15, [r13+r14*1]
000075038bdd8fb8  vmovaps xmm14, [rsp+0xD0]
000075038bdd8fc1  vmovaps xmm9, [rsp+0xD0]
000075038bdd8fca  por xmm14, xmm9
000075038bdd8fcf  movaps [r15+0x1C0], xmm14
000075038bdd8fd7  vmovaps xmm9, [rsp+0xC0]
000075038bdd8fe0  vmovaps [rsp+0xD0], xmm1
000075038bdd8fe9  vmovaps xmm1, [rsp+0xC0]
000075038bdd8ff2  por xmm9, xmm1
000075038bdd8ff7  movaps [r15+0x200], xmm9
000075038bdd8fff  vmovaps [rsp+0xC0], xmm2
000075038bdd9008  vmovaps xmm1, [rsp+0xC0]
000075038bdd9011  por xmm2, xmm1
000075038bdd9015  movaps [r15+0x2D0], xmm2
000075038bdd901d  vmovaps [rsp+0xC0], xmm8
000075038bdd9026  vmovaps xmm1, [rsp+0xC0]
000075038bdd902f  por xmm8, xmm1
000075038bdd9034  movaps [r15+0x2E0], xmm8
000075038bdd903c  vmovaps [rsp+0xC0], xmm15
000075038bdd9045  movaps xmm1, xmm5
000075038bdd9048  addpd xmm1, xmm7
000075038bdd904c  vcmppd xmm15, xmm1, xmm1, 0x03
000075038bdd9051  ptest xmm15, xmm15
000075038bdd9057  jnz 0x000075038BDDADEB
000075038bdd905d  vmovaps xmm15, [rsp+0x50]
000075038bdd9063  vpermilpd xmm15, xmm15, 0x00
000075038bdd9069  vmovaps xmm5, [rsp+0xC0]
000075038bdd9072  vmovaps [rsp+0xC0], xmm1
000075038bdd907b  movaps xmm7, xmm5
000075038bdd907e  mulpd xmm7, xmm15
000075038bdd9083  vcmppd xmm1, xmm7, xmm7, 0x03
000075038bdd9088  ptest xmm1, xmm1
000075038bdd908d  jnz 0x000075038BDDAF2B
000075038bdd9093  lea r14, [rax+0x80]
000075038bdd909a  movups xmm1, [r13+r14*1]
000075038bdd90a0  vmovaps xmm5, [rsp+0x70]
000075038bdd90a6  vmovaps [rsp+0x70], xmm1
000075038bdd90ac  movaps xmm15, xmm5
000075038bdd90b0  addpd xmm15, xmm3
000075038bdd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
000075038bdd90bb  ptest xmm1, xmm1
000075038bdd90c0  jnz 0x000075038BDDB076
000075038bdd90c6  vmovaps xmm5, [rsp+0x80]
000075038bdd90cf  movaps xmm1, xmm5
000075038bdd90d2  addpd xmm1, xmm4
000075038bdd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
000075038bdd90db  ptest xmm3, xmm3
000075038bdd90e0  jnz 0x000075038BDDB1B8
000075038bdd90e6  vmovaps [rsp+0x80], xmm10
000075038bdd90ef  vmovaps xmm5, [rsp+0x80]
000075038bdd90f8  por xmm10, xmm5
000075038bdd90fd  movaps [r15+0x2F0], xmm10
000075038bdd9105  vmovaps xmm5, [rsp+0x50]
000075038bdd910b  vpermilpd xmm5, xmm5, 0x00
000075038bdd9111  vmovaps xmm3, [rsp+0x70]
000075038bdd9117  vmovaps [rsp+0x50], xmm1
000075038bdd911d  movaps xmm4, xmm3
000075038bdd9120  mulpd xmm4, xmm5
000075038bdd9124  vcmppd xmm1, xmm4, xmm4, 0x03
000075038bdd9129  ptest xmm1, xmm1
000075038bdd912e  jnz 0x000075038BDDB2F8
000075038bdd9134  lea r14, [rax+0xD0]
000075038bdd913b  movups xmm1, [r13+r14*1]
000075038bdd9141  vmovaps xmm3, [rsp+0xD0]
000075038bdd914a  vmovaps [rsp+0x70], xmm1
000075038bdd9150  movaps xmm5, xmm6
000075038bdd9153  addpd xmm5, xmm3
000075038bdd9157  vcmppd xmm1, xmm5, xmm5, 0x03
000075038bdd915c  ptest xmm1, xmm1
000075038bdd9161  jnz 0x000075038BDDB442
000075038bdd9167  vmovaps xmm1, [rsp+0x60]
000075038bdd916d  vpermilpd xmm1, xmm1, 0x00
000075038bdd9173  movaps xmm6, xmm9
000075038bdd9177  mulpd xmm6, xmm1
000075038bdd917b  vcmppd xmm3, xmm6, xmm6, 0x03
000075038bdd9180  ptest xmm3, xmm3
000075038bdd9185  jnz 0x000075038BDDB582
000075038bdd918b  movaps [r15+0x260], xmm6
000075038bdd9193  vxorps xmm1, xmm1, xmm1
000075038bdd9197  vpbroadcastq xmm1, xmm1
000075038bdd919c  movaps [r15+0x1B0], xmm1
000075038bdd91a4  vmovaps xmm1, [rsp+0x60]
000075038bdd91aa  vpermilpd xmm1, xmm1, 0x00
000075038bdd91b0  vmovaps xmm3, [rsp+0x70]
000075038bdd91b6  vmovaps [rsp+0x70], xmm15
000075038bdd91bc  movaps xmm9, xmm3
000075038bdd91c0  mulpd xmm9, xmm1
000075038bdd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
000075038bdd91cb  ptest xmm15, xmm15
000075038bdd91d1  jnz 0x000075038BDDB6C3
000075038bdd91d7  lea r14, [rax+0xC0]
000075038bdd91de  movups xmm1, [r13+r14*1]
000075038bdd91e4  vmovaps xmm3, [rsp+0xC0]
000075038bdd91ed  vmovaps [rsp+0x80], xmm1
000075038bdd91f6  movaps xmm15, xmm3
000075038bdd91fa  addpd xmm15, xmm7
000075038bdd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
000075038bdd9205  ptest xmm1, xmm1
000075038bdd920a  jnz 0x000075038BDDB80F
000075038bdd9210  vmovaps [rsp+0xC0], xmm13
000075038bdd9219  vmovaps xmm1, [rsp+0xC0]
000075038bdd9222  por xmm13, xmm1
000075038bdd9227  movaps [r15+0x270], xmm13
000075038bdd922f  vmovaps xmm1, [rsp+0xB0]
000075038bdd9238  vmovaps xmm7, [rsp+0xB0]
000075038bdd9241  por xmm1, xmm7
000075038bdd9245  movaps [r15+0x1A0], xmm1
000075038bdd924d  vmovaps xmm1, [rsp+0x60]
000075038bdd9253  vpermilpd xmm1, xmm1, 0x00
000075038bdd9259  vmovaps [rsp+0xB0], xmm1
000075038bdd9262  vmovaps xmm1, [rsp+0x80]
000075038bdd926b  vmovaps [rsp+0x80], xmm15
000075038bdd9274  vmovaps xmm15, [rsp+0xB0]
000075038bdd927d  vmovaps [rsp+0xB0], xmm14
000075038bdd9286  movaps xmm3, xmm1
000075038bdd9289  mulpd xmm3, xmm15
000075038bdd928e  vcmppd xmm14, xmm3, xmm3, 0x03
000075038bdd9293  ptest xmm14, xmm14
000075038bdd9299  jnz 0x000075038BDDB951
000075038bdd929f  lea r14, [rax+0x20]
000075038bdd92a3  movups xmm1, [r13+r14*1]
000075038bdd92a9  movaps [r15+0x110], xmm1
000075038bdd92b1  vmovaps xmm14, [rsp+0x70]
000075038bdd92b7  vmovaps [rsp+0x70], xmm1
000075038bdd92bd  movaps xmm15, xmm14
000075038bdd92c1  addpd xmm15, xmm4
000075038bdd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
000075038bdd92cc  ptest xmm1, xmm1
000075038bdd92d1  jnz 0x000075038BDDBA9C
000075038bdd92d7  vmovaps xmm1, [rsp+0x60]
000075038bdd92dd  vpermilpd xmm1, xmm1, 0x00
000075038bdd92e3  movaps xmm14, xmm2
000075038bdd92e7  mulpd xmm14, xmm1
000075038bdd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
000075038bdd92f2  ptest xmm4, xmm4
000075038bdd92f7  jnz 0x000075038BDDBBDF
000075038bdd92fd  vmovaps xmm4, [rsp+0x50]
000075038bdd9303  movaps xmm1, xmm4
000075038bdd9306  addpd xmm1, xmm9
000075038bdd930b  vcmppd xmm2, xmm1, xmm1, 0x03
000075038bdd9310  ptest xmm2, xmm2
000075038bdd9315  jnz 0x000075038BDDBD21
000075038bdd931b  vmovaps xmm9, [rsp+0x30]
000075038bdd9321  vpermilpd xmm9, xmm9, 0x00
000075038bdd9327  vmovaps xmm2, [rsp+0x70]
000075038bdd932d  vmovaps [rsp+0x50], xmm1
000075038bdd9333  movaps xmm4, xmm2
000075038bdd9336  mulpd xmm4, xmm9
000075038bdd933b  vcmppd xmm1, xmm4, xmm4, 0x03
000075038bdd9340  ptest xmm1, xmm1
000075038bdd9345  jnz 0x000075038BDDBE62
000075038bdd934b  vmovaps xmm1, [rsp+0x30]
000075038bdd9351  vpermilpd xmm1, xmm1, 0x00
000075038bdd9357  vmovaps xmm2, [rsp+0x90]
000075038bdd9360  vmovaps [rsp+0x60], xmm15
000075038bdd9366  movaps xmm9, xmm2
000075038bdd936a  mulpd xmm9, xmm1
000075038bdd936f  vcmppd xmm15, xmm9, xmm9, 0x03
000075038bdd9375  ptest xmm15, xmm15
000075038bdd937b  jnz 0x000075038BDDBFA3
000075038bdd9381  vmovaps xmm15, [rsp+0x80]
000075038bdd938a  movaps xmm1, xmm15
000075038bdd938e  addpd xmm1, xmm6
000075038bdd9392  vcmppd xmm2, xmm1, xmm1, 0x03
000075038bdd9397  ptest xmm2, xmm2
000075038bdd939c  jnz 0x000075038BDDC0E5
000075038bdd93a2  movaps xmm15, xmm5
000075038bdd93a6  addpd xmm15, xmm3
000075038bdd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
000075038bdd93b1  ptest xmm6, xmm6
000075038bdd93b6  jnz 0x000075038BDDC226
000075038bdd93bc  vmovaps xmm6, [rsp+0x30]
000075038bdd93c2  vpermilpd xmm6, xmm6, 0x00
000075038bdd93c8  movaps xmm5, xmm8
000075038bdd93cc  mulpd xmm5, xmm6
000075038bdd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
000075038bdd93d5  ptest xmm3, xmm3
000075038bdd93da  jnz 0x000075038BDDC368
000075038bdd93e0  vmovaps xmm8, [rsp+0x30]
000075038bdd93e6  vpermilpd xmm8, xmm8, 0x00
000075038bdd93ec  movaps xmm6, xmm10
000075038bdd93f0  mulpd xmm6, xmm8
000075038bdd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
000075038bdd93fa  ptest xmm3, xmm3
000075038bdd93ff  jnz 0x000075038BDDC4A9
000075038bdd9405  vmovaps xmm8, [rsp+0x60]
000075038bdd940b  movaps xmm10, xmm8
000075038bdd940f  addpd xmm10, xmm14
000075038bdd9414  vcmppd xmm3, xmm10, xmm10, 0x03
000075038bdd941a  ptest xmm3, xmm3
000075038bdd941f  jnz 0x000075038BDDC5EB
000075038bdd9425  vmovaps xmm8, [rsp+0x50]
000075038bdd942b  movaps xmm14, xmm8
000075038bdd942f  addpd xmm14, xmm4
000075038bdd9434  vcmppd xmm3, xmm14, xmm14, 0x03
000075038bdd943a  ptest xmm3, xmm3
000075038bdd943f  jnz 0x000075038BDDC72F
000075038bdd9445  vmovaps xmm8, [rsp+0x40]
000075038bdd944b  vpermilpd xmm8, xmm8, 0x00
000075038bdd9451  movaps xmm4, xmm13
000075038bdd9455  mulpd xmm4, xmm8
000075038bdd945a  vcmppd xmm3, xmm4, xmm4, 0x03
000075038bdd945f  ptest xmm3, xmm3
000075038bdd9464  jnz 0x000075038BDDC872
000075038bdd946a  movaps xmm13, xmm15
000075038bdd946e  addpd xmm13, xmm9
000075038bdd9473  vcmppd xmm8, xmm13, xmm13, 0x03
000075038bdd9479  ptest xmm8, xmm8
000075038bdd947f  jnz 0x000075038BDDC9B4
000075038bdd9485  movaps xmm15, xmm1
000075038bdd9489  addpd xmm15, xmm5
000075038bdd948e  vcmppd xmm9, xmm15, xmm15, 0x03
000075038bdd9494  ptest xmm9, xmm9
000075038bdd949a  jnz 0x000075038BDDCAF8
000075038bdd94a0  vmovaps [rsp+0x30], xmm11
000075038bdd94a6  vmovaps xmm1, [rsp+0x30]
000075038bdd94ac  por xmm11, xmm1
000075038bdd94b1  movaps [r15+0x250], xmm11
000075038bdd94b9  vmovaps [rsp+0x30], xmm12
000075038bdd94bf  vmovaps xmm1, [rsp+0x30]
000075038bdd94c5  por xmm12, xmm1
000075038bdd94ca  movaps [r15+0x2A0], xmm12
000075038bdd94d2  vmovaps xmm1, [rsp+0xA0]
000075038bdd94db  vmovaps xmm11, [rsp+0xA0]
000075038bdd94e4  por xmm1, xmm11
000075038bdd94e9  movaps [r15+0x1D0], xmm1
000075038bdd94f1  lea r14, [rax+0x40]
000075038bdd94f5  movups xmm1, [r13+r14*1]
000075038bdd94fb  movaps [r15+0x2C0], xmm1
000075038bdd9503  vmovaps xmm11, [rsp+0x40]
000075038bdd9509  vpermilpd xmm11, xmm11, 0x00
000075038bdd950f  vmovaps xmm8, [rsp+0xE0]
000075038bdd9518  movaps xmm9, xmm8
000075038bdd951c  mulpd xmm9, xmm11
000075038bdd9521  vcmppd xmm5, xmm9, xmm9, 0x03
000075038bdd9527  ptest xmm5, xmm5
000075038bdd952c  jnz 0x000075038BDDCC44
000075038bdd9532  movaps xmm11, xmm10
000075038bdd9536  addpd xmm11, xmm6
000075038bdd953b  vcmppd xmm8, xmm11, xmm11, 0x03
000075038bdd9541  ptest xmm8, xmm8
000075038bdd9547  jnz 0x000075038BDDCD88
000075038bdd954d  movaps xmm10, xmm14
000075038bdd9551  addpd xmm10, xmm4
000075038bdd9556  vcmppd xmm8, xmm10, xmm10, 0x03
000075038bdd955c  ptest xmm8, xmm8
000075038bdd9562  jnz 0x000075038BDDCECB
000075038bdd9568  vmovaps xmm14, [rsp+0x40]
000075038bdd956e  vpermilpd xmm14, xmm14, 0x00
000075038bdd9574  movaps xmm8, xmm1
000075038bdd9578  mulpd xmm8, xmm14
000075038bdd957d  vcmppd xmm6, xmm8, xmm8, 0x03
000075038bdd9583  ptest xmm6, xmm6
000075038bdd9588  jnz 0x000075038BDDD00E
000075038bdd958e  movaps xmm1, [r15+0x2B0]
000075038bdd9596  vmovaps xmm14, [rsp+0x40]
000075038bdd959c  vpermilpd xmm14, xmm14, 0x00
000075038bdd95a2  movaps xmm6, xmm1
000075038bdd95a5  mulpd xmm6, xmm14
000075038bdd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
000075038bdd95af  ptest xmm5, xmm5
000075038bdd95b4  jnz 0x000075038BDDD151
000075038bdd95ba  vmovaps xmm1, [rsp+0x10]
000075038bdd95c0  vpermilpd xmm1, xmm1, 0x00
000075038bdd95c6  movaps xmm14, xmm12
000075038bdd95ca  mulpd xmm14, xmm1
000075038bdd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
000075038bdd95d5  ptest xmm5, xmm5
000075038bdd95da  jnz 0x000075038BDDD292
000075038bdd95e0  movaps xmm1, xmm13
000075038bdd95e4  addpd xmm1, xmm9
000075038bdd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
000075038bdd95ee  ptest xmm12, xmm12
000075038bdd95f4  jnz 0x000075038BDDD3D5
000075038bdd95fa  vmovaps xmm13, [rsp+0x10]
000075038bdd9600  vpermilpd xmm13, xmm13, 0x00
000075038bdd9606  movaps xmm12, xmm7
000075038bdd960a  mulpd xmm12, xmm13
000075038bdd960f  vcmppd xmm9, xmm12, xmm12, 0x03
000075038bdd9615  ptest xmm9, xmm9
000075038bdd961b  jnz 0x000075038BDDD517
000075038bdd9621  movaps xmm13, xmm15
000075038bdd9625  addpd xmm13, xmm8
000075038bdd962a  vcmppd xmm9, xmm13, xmm13, 0x03
000075038bdd9630  ptest xmm9, xmm9
000075038bdd9636  jnz 0x000075038BDDD65A
000075038bdd963c  movaps xmm15, [r15+0x290]
000075038bdd9644  vmovaps xmm9, [rsp+0x10]
000075038bdd964a  vpermilpd xmm9, xmm9, 0x00
000075038bdd9650  movaps xmm8, xmm15
000075038bdd9654  mulpd xmm8, xmm9
000075038bdd9659  vcmppd xmm7, xmm8, xmm8, 0x03
000075038bdd965f  ptest xmm7, xmm7
000075038bdd9664  jnz 0x000075038BDDD79E
000075038bdd966a  movaps xmm15, xmm11
000075038bdd966e  addpd xmm15, xmm6
000075038bdd9673  vcmppd xmm9, xmm15, xmm15, 0x03
000075038bdd9679  ptest xmm9, xmm9
000075038bdd967f  jnz 0x000075038BDDD8E2
000075038bdd9685  movaps xmm11, [r15+0x1E0]
000075038bdd968d  vmovaps xmm9, [rsp+0x10]
000075038bdd9693  vpermilpd xmm9, xmm9, 0x00
000075038bdd9699  movaps xmm7, xmm11
000075038bdd969d  mulpd xmm7, xmm9
000075038bdd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
000075038bdd96a7  ptest xmm6, xmm6
000075038bdd96ac  jnz 0x000075038BDDDA25
000075038bdd96b2  movaps xmm11, xmm10
000075038bdd96b6  addpd xmm11, xmm14
000075038bdd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
000075038bdd96c1  ptest xmm9, xmm9
000075038bdd96c7  jnz 0x000075038BDDDB67
000075038bdd96cd  lea r14, [rax+0x70]
000075038bdd96d1  movups xmm14, [r13+r14*1]
000075038bdd96d7  movaps [r15+0x240], xmm14
000075038bdd96df  movaps xmm10, xmm1
000075038bdd96e3  addpd xmm10, xmm12
000075038bdd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
000075038bdd96ee  ptest xmm9, xmm9
000075038bdd96f4  jnz 0x000075038BDDDCB5
000075038bdd96fa  movaps [r15+0x170], xmm10
000075038bdd9702  vmovaps xmm1, [rsp+0x20]
000075038bdd9708  vpermilpd xmm1, xmm1, 0x00
000075038bdd970e  movaps xmm12, xmm14
000075038bdd9712  mulpd xmm12, xmm1
000075038bdd9717  vcmppd xmm9, xmm12, xmm12, 0x03
000075038bdd971d  ptest xmm9, xmm9
000075038bdd9723  jnz 0x000075038BDDDDF8
000075038bdd9729  vmovaps xmm1, [rsp+0x20]
000075038bdd972f  vpermilpd xmm1, xmm1, 0x00
000075038bdd9735  vmovaps xmm9, [rsp+0xB0]
000075038bdd973e  movaps xmm14, xmm9
000075038bdd9742  mulpd xmm14, xmm1
000075038bdd9747  vcmppd xmm6, xmm14, xmm14, 0x03
000075038bdd974d  ptest xmm6, xmm6
000075038bdd9752  jnz 0x000075038BDDDF3B
000075038bdd9758  movaps [r15+0x180], xmm14
000075038bdd9760  movaps xmm1, xmm13
000075038bdd9764  addpd xmm1, xmm8
000075038bdd9769  vcmppd xmm9, xmm1, xmm1, 0x03
000075038bdd976e  ptest xmm9, xmm9
000075038bdd9774  jnz 0x000075038BDDE07E
000075038bdd977a  movaps [r15+0x210], xmm1
000075038bdd9782  movups xmm13, [r13+rax*1]
000075038bdd9788  lea r14, [rax+0x10]
000075038bdd978c  movups xmm9, [r13+r14*1]
000075038bdd9792  movaps [r15+0x230], xmm9
000075038bdd979a  movaps xmm8, xmm15
000075038bdd979e  addpd xmm8, xmm7
000075038bdd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
000075038bdd97a9  ptest xmm6, xmm6
000075038bdd97ae  jnz 0x000075038BDDE1D4
000075038bdd97b4  movaps [r15+0x130], xmm8
000075038bdd97bc  vmovaps xmm15, [rsp+0x20]
000075038bdd97c2  vpermilpd xmm15, xmm15, 0x00
000075038bdd97c8  movaps xmm7, xmm9
000075038bdd97cc  mulpd xmm7, xmm15
000075038bdd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
000075038bdd97d6  ptest xmm6, xmm6
000075038bdd97db  jnz 0x000075038BDDE317
000075038bdd97e1  movaps [r15+0x220], xmm7
000075038bdd97e9  vmovaps xmm15, [rsp+0x20]
000075038bdd97ef  vpermilpd xmm15, xmm15, 0x00
000075038bdd97f5  movaps xmm9, xmm13
000075038bdd97f9  mulpd xmm9, xmm15
000075038bdd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
000075038bdd9804  ptest xmm6, xmm6
000075038bdd9809  jnz 0x000075038BDDE459
000075038bdd980f  movaps xmm15, xmm11
000075038bdd9813  addpd xmm15, xmm12
000075038bdd9818  vcmppd xmm13, xmm15, xmm15, 0x03
000075038bdd981e  ptest xmm13, xmm13
000075038bdd9824  jnz 0x000075038BDDE59D
000075038bdd982a  movaps [r15+0x140], xmm15
000075038bdd9832  movaps xmm13, xmm10
000075038bdd9836  addpd xmm13, xmm14
000075038bdd983b  vcmppd xmm12, xmm13, xmm13, 0x03
000075038bdd9841  ptest xmm12, xmm12
000075038bdd9847  jnz 0x000075038BDDE6E1
000075038bdd984d  movaps [r15+0x150], xmm13
000075038bdd9855  movaps xmm14, xmm1
000075038bdd9859  addpd xmm14, xmm7
000075038bdd985e  vcmppd xmm12, xmm14, xmm14, 0x03
000075038bdd9864  ptest xmm12, xmm12
000075038bdd986a  jnz 0x000075038BDDE825
000075038bdd9870  movaps [r15+0x160], xmm14
000075038bdd9878  movaps xmm1, xmm8
000075038bdd987c  addpd xmm1, xmm9
000075038bdd9881  vcmppd xmm12, xmm1, xmm1, 0x03
000075038bdd9886  ptest xmm12, xmm12
000075038bdd988c  jnz 0x000075038BDDE967
000075038bdd9892  movaps [r15+0x120], xmm1
000075038bdd989a  movups [r13+r11*1], xmm15
000075038bdd98a0  lea rax, [r11+0x10]
000075038bdd98a4  movups [r13+rax*1], xmm13
000075038bdd98aa  lea rax, [r11+0x20]
000075038bdd98ae  movups [r13+rax*1], xmm14
000075038bdd98b4  lea rax, [r11+0x30]
000075038bdd98b8  movups [r13+rax*1], xmm1
000075038bdd98be  mov eax, [r15+0x108]
000075038bdd98c5  sahf
000075038bdd98c6  jnz 0x000075038BDD98F8
000075038bdd98c8  cmp dword ptr [r15+0x318], 0x00
000075038bdd98d0  jz 0x000075038BDDEAE0
000075038bdd98d6  nop [rax+rax*1], ax
000075038bdd98df  nop [rax+rax*1], eax
000075038bdd98e7  mov eax, 0x4106D0
000075038bdd98ec  mov [r15+0x100], rax
000075038bdd98f3  jmp 0x000075038BBFE110
000075038bdd98f8  cmp dword ptr [r15+0x318], 0x00
000075038bdd9900  jz 0x000075038BDD89C0
000075038bdd9906  nop [rax+rax*1], ax
000075038bdd990f  nop [rax+rax*1], eax
000075038bdd9917  mov eax, 0x410504
000075038bdd991c  mov [r15+0x100], rax
000075038bdd9923  jmp 0x000075038BBFE110
000075038bdd9928  int3
000075038bdd9929  call 0x000075038BC0A4B0
000075038bdd992e  jmp 0x000075038BDD8A08
000075038bdd9933  call 0x000075038BC09240
000075038bdd9938  jmp 0x000075038BDD8A12
000075038bdd993d  call 0x000075038BC0A4B0
000075038bdd9942  jmp 0x000075038BDD8A6F
000075038bdd9947  call 0x000075038BC09240
000075038bdd994c  jmp 0x000075038BDD8A79
000075038bdd9951  call 0x000075038BC0A4B0
000075038bdd9956  jmp 0x000075038BDD8ABD
000075038bdd995b  call 0x000075038BC09240
000075038bdd9960  jmp 0x000075038BDD8AC7
000075038bdd9965  call 0x000075038BCB47C0
000075038bdd996a  jmp 0x000075038BDD8B06
000075038bdd996f  call 0x000075038BC0B720
000075038bdd9974  jmp 0x000075038BDD8B1A
000075038bdd9979  call 0x000075038BCBFC30
000075038bdd997e  jmp 0x000075038BDD8B38
000075038bdd9983  call 0x000075038BCBE9C0
000075038bdd9988  jmp 0x000075038BDD8B42
000075038bdd998d  call 0x000075038BCBD750
000075038bdd9992  jmp 0x000075038BDD8B4C
000075038bdd9997  sub rsp, 0x08
000075038bdd999b  push rax
000075038bdd999c  push rcx
000075038bdd999d  push rdx
000075038bdd999e  push rdi
000075038bdd999f  push rsi
000075038bdd99a0  push r8
000075038bdd99a2  push r9
000075038bdd99a4  push r10
000075038bdd99a6  push r11
000075038bdd99a8  sub rsp, 0xF0
000075038bdd99af  vmovaps [rsp], xmm0
000075038bdd99b4  vmovaps [rsp+0x10], xmm1
000075038bdd99ba  vmovaps [rsp+0x20], xmm2
000075038bdd99c0  vmovaps [rsp+0x30], xmm3
000075038bdd99c6  vmovaps [rsp+0x40], xmm4
000075038bdd99cc  vmovaps [rsp+0x50], xmm5
000075038bdd99d2  vmovaps [rsp+0x60], xmm6
000075038bdd99d8  vmovaps [rsp+0x70], xmm7
000075038bdd99de  vmovaps [rsp+0x80], xmm9
000075038bdd99e7  vmovaps [rsp+0x90], xmm10
000075038bdd99f0  vmovaps [rsp+0xA0], xmm11
000075038bdd99f9  vmovaps [rsp+0xB0], xmm12
000075038bdd9a02  vmovaps [rsp+0xC0], xmm13
000075038bdd9a0b  vmovaps [rsp+0xD0], xmm14
000075038bdd9a14  vmovaps [rsp+0xE0], xmm15
000075038bdd9a1d  sub rsp, 0x30
000075038bdd9a21  movaps [rsp], xmm8
000075038bdd9a26  movaps [rsp+0x10], xmm12
000075038bdd9a2c  movaps [rsp+0x20], xmm15
000075038bdd9a32  lea rdi, [rsp]
000075038bdd9a36  mov esi, 0x00
000075038bdd9a3b  mov rax, 0x56ADB4492530
000075038bdd9a45  call rax
000075038bdd9a47  movaps xmm8, [rsp]
000075038bdd9a4c  add rsp, 0x30
000075038bdd9a50  vmovaps xmm0, [rsp]
000075038bdd9a55  vmovaps xmm1, [rsp+0x10]
000075038bdd9a5b  vmovaps xmm2, [rsp+0x20]
000075038bdd9a61  vmovaps xmm3, [rsp+0x30]
000075038bdd9a67  vmovaps xmm4, [rsp+0x40]
000075038bdd9a6d  vmovaps xmm5, [rsp+0x50]
000075038bdd9a73  vmovaps xmm6, [rsp+0x60]
000075038bdd9a79  vmovaps xmm7, [rsp+0x70]
000075038bdd9a7f  vmovaps xmm9, [rsp+0x80]
000075038bdd9a88  vmovaps xmm10, [rsp+0x90]
000075038bdd9a91  vmovaps xmm11, [rsp+0xA0]
000075038bdd9a9a  vmovaps xmm12, [rsp+0xB0]
000075038bdd9aa3  vmovaps xmm13, [rsp+0xC0]
000075038bdd9aac  vmovaps xmm14, [rsp+0xD0]
000075038bdd9ab5  vmovaps xmm15, [rsp+0xE0]
000075038bdd9abe  add rsp, 0xF0
000075038bdd9ac5  pop r11
000075038bdd9ac7  pop r10
000075038bdd9ac9  pop r9
000075038bdd9acb  pop r8
000075038bdd9acd  pop rsi
000075038bdd9ace  pop rdi
000075038bdd9acf  pop rdx
000075038bdd9ad0  pop rcx
000075038bdd9ad1  pop rax
000075038bdd9ad2  add rsp, 0x08
000075038bdd9ad6  jmp 0x000075038BDD8B7A
000075038bdd9adb  sub rsp, 0x08
000075038bdd9adf  push rax
000075038bdd9ae0  push rcx
000075038bdd9ae1  push rdx
000075038bdd9ae2  push rdi
000075038bdd9ae3  push rsi
000075038bdd9ae4  push r8
000075038bdd9ae6  push r9
000075038bdd9ae8  push r10
000075038bdd9aea  push r11
000075038bdd9aec  sub rsp, 0xF0
000075038bdd9af3  vmovaps [rsp], xmm0
000075038bdd9af8  vmovaps [rsp+0x10], xmm1
000075038bdd9afe  vmovaps [rsp+0x20], xmm2
000075038bdd9b04  vmovaps [rsp+0x30], xmm3
000075038bdd9b0a  vmovaps [rsp+0x40], xmm4
000075038bdd9b10  vmovaps [rsp+0x50], xmm5
000075038bdd9b16  vmovaps [rsp+0x60], xmm6
000075038bdd9b1c  vmovaps [rsp+0x70], xmm8
000075038bdd9b22  vmovaps [rsp+0x80], xmm9
000075038bdd9b2b  vmovaps [rsp+0x90], xmm10
000075038bdd9b34  vmovaps [rsp+0xA0], xmm11
000075038bdd9b3d  vmovaps [rsp+0xB0], xmm12
000075038bdd9b46  vmovaps [rsp+0xC0], xmm13
000075038bdd9b4f  vmovaps [rsp+0xD0], xmm14
000075038bdd9b58  vmovaps [rsp+0xE0], xmm15
000075038bdd9b61  sub rsp, 0x30
000075038bdd9b65  movaps [rsp], xmm7
000075038bdd9b69  movaps [rsp+0x10], xmm9
000075038bdd9b6f  movaps [rsp+0x20], xmm15
000075038bdd9b75  lea rdi, [rsp]
000075038bdd9b79  mov esi, 0x00
000075038bdd9b7e  mov rax, 0x56ADB4492530
000075038bdd9b88  call rax
000075038bdd9b8a  movaps xmm7, [rsp]
000075038bdd9b8e  add rsp, 0x30
000075038bdd9b92  vmovaps xmm0, [rsp]
000075038bdd9b97  vmovaps xmm1, [rsp+0x10]
000075038bdd9b9d  vmovaps xmm2, [rsp+0x20]
000075038bdd9ba3  vmovaps xmm3, [rsp+0x30]
000075038bdd9ba9  vmovaps xmm4, [rsp+0x40]
000075038bdd9baf  vmovaps xmm5, [rsp+0x50]
000075038bdd9bb5  vmovaps xmm6, [rsp+0x60]
000075038bdd9bbb  vmovaps xmm8, [rsp+0x70]
000075038bdd9bc1  vmovaps xmm9, [rsp+0x80]
000075038bdd9bca  vmovaps xmm10, [rsp+0x90]
000075038bdd9bd3  vmovaps xmm11, [rsp+0xA0]
000075038bdd9bdc  vmovaps xmm12, [rsp+0xB0]
000075038bdd9be5  vmovaps xmm13, [rsp+0xC0]
000075038bdd9bee  vmovaps xmm14, [rsp+0xD0]
000075038bdd9bf7  vmovaps xmm15, [rsp+0xE0]
000075038bdd9c00  add rsp, 0xF0
000075038bdd9c07  pop r11
000075038bdd9c09  pop r10
000075038bdd9c0b  pop r9
000075038bdd9c0d  pop r8
000075038bdd9c0f  pop rsi
000075038bdd9c10  pop rdi
000075038bdd9c11  pop rdx
000075038bdd9c12  pop rcx
000075038bdd9c13  pop rax
000075038bdd9c14  add rsp, 0x08
000075038bdd9c18  jmp 0x000075038BDD8BA8
000075038bdd9c1d  sub rsp, 0x08
000075038bdd9c21  push rax
000075038bdd9c22  push rcx
000075038bdd9c23  push rdx
000075038bdd9c24  push rdi
000075038bdd9c25  push rsi
000075038bdd9c26  push r8
000075038bdd9c28  push r9
000075038bdd9c2a  push r10
000075038bdd9c2c  push r11
000075038bdd9c2e  sub rsp, 0xF0
000075038bdd9c35  vmovaps [rsp], xmm0
000075038bdd9c3a  vmovaps [rsp+0x10], xmm1
000075038bdd9c40  vmovaps [rsp+0x20], xmm2
000075038bdd9c46  vmovaps [rsp+0x30], xmm3
000075038bdd9c4c  vmovaps [rsp+0x40], xmm4
000075038bdd9c52  vmovaps [rsp+0x50], xmm5
000075038bdd9c58  vmovaps [rsp+0x60], xmm6
000075038bdd9c5e  vmovaps [rsp+0x70], xmm7
000075038bdd9c64  vmovaps [rsp+0x80], xmm8
000075038bdd9c6d  vmovaps [rsp+0x90], xmm10
000075038bdd9c76  vmovaps [rsp+0xA0], xmm11
000075038bdd9c7f  vmovaps [rsp+0xB0], xmm12
000075038bdd9c88  vmovaps [rsp+0xC0], xmm13
000075038bdd9c91  vmovaps [rsp+0xD0], xmm14
000075038bdd9c9a  vmovaps [rsp+0xE0], xmm15
000075038bdd9ca3  sub rsp, 0x30
000075038bdd9ca7  movaps [rsp], xmm9
000075038bdd9cac  movaps [rsp+0x10], xmm12
000075038bdd9cb2  movaps [rsp+0x20], xmm10
000075038bdd9cb8  lea rdi, [rsp]
000075038bdd9cbc  mov esi, 0x00
000075038bdd9cc1  mov rax, 0x56ADB4492530
000075038bdd9ccb  call rax
000075038bdd9ccd  movaps xmm9, [rsp]
000075038bdd9cd2  add rsp, 0x30
000075038bdd9cd6  vmovaps xmm0, [rsp]
000075038bdd9cdb  vmovaps xmm1, [rsp+0x10]
000075038bdd9ce1  vmovaps xmm2, [rsp+0x20]
000075038bdd9ce7  vmovaps xmm3, [rsp+0x30]
000075038bdd9ced  vmovaps xmm4, [rsp+0x40]
000075038bdd9cf3  vmovaps xmm5, [rsp+0x50]
000075038bdd9cf9  vmovaps xmm6, [rsp+0x60]
000075038bdd9cff  vmovaps xmm7, [rsp+0x70]
000075038bdd9d05  vmovaps xmm8, [rsp+0x80]
000075038bdd9d0e  vmovaps xmm10, [rsp+0x90]
000075038bdd9d17  vmovaps xmm11, [rsp+0xA0]
000075038bdd9d20  vmovaps xmm12, [rsp+0xB0]
000075038bdd9d29  vmovaps xmm13, [rsp+0xC0]
000075038bdd9d32  vmovaps xmm14, [rsp+0xD0]
000075038bdd9d3b  vmovaps xmm15, [rsp+0xE0]
000075038bdd9d44  add rsp, 0xF0
000075038bdd9d4b  pop r11
000075038bdd9d4d  pop r10
000075038bdd9d4f  pop r9
000075038bdd9d51  pop r8
000075038bdd9d53  pop rsi
000075038bdd9d54  pop rdi
000075038bdd9d55  pop rdx
000075038bdd9d56  pop rcx
000075038bdd9d57  pop rax
000075038bdd9d58  add rsp, 0x08
000075038bdd9d5c  jmp 0x000075038BDD8BCC
000075038bdd9d61  sub rsp, 0x08
000075038bdd9d65  push rax
000075038bdd9d66  push rcx
000075038bdd9d67  push rdx
000075038bdd9d68  push rdi
000075038bdd9d69  push rsi
000075038bdd9d6a  push r8
000075038bdd9d6c  push r9
000075038bdd9d6e  push r10
000075038bdd9d70  push r11
000075038bdd9d72  sub rsp, 0xF0
000075038bdd9d79  vmovaps [rsp], xmm0
000075038bdd9d7e  vmovaps [rsp+0x10], xmm1
000075038bdd9d84  vmovaps [rsp+0x20], xmm2
000075038bdd9d8a  vmovaps [rsp+0x30], xmm3
000075038bdd9d90  vmovaps [rsp+0x40], xmm4
000075038bdd9d96  vmovaps [rsp+0x50], xmm5
000075038bdd9d9c  vmovaps [rsp+0x60], xmm6
000075038bdd9da2  vmovaps [rsp+0x70], xmm7
000075038bdd9da8  vmovaps [rsp+0x80], xmm8
000075038bdd9db1  vmovaps [rsp+0x90], xmm9
000075038bdd9dba  vmovaps [rsp+0xA0], xmm11
000075038bdd9dc3  vmovaps [rsp+0xB0], xmm12
000075038bdd9dcc  vmovaps [rsp+0xC0], xmm13
000075038bdd9dd5  vmovaps [rsp+0xD0], xmm14
000075038bdd9dde  vmovaps [rsp+0xE0], xmm15
000075038bdd9de7  sub rsp, 0x30
000075038bdd9deb  movaps [rsp], xmm10
000075038bdd9df0  movaps [rsp+0x10], xmm12
000075038bdd9df6  movaps [rsp+0x20], xmm11
000075038bdd9dfc  lea rdi, [rsp]
000075038bdd9e00  mov esi, 0x00
000075038bdd9e05  mov rax, 0x56ADB4492530
000075038bdd9e0f  call rax
000075038bdd9e11  movaps xmm10, [rsp]
000075038bdd9e16  add rsp, 0x30
000075038bdd9e1a  vmovaps xmm0, [rsp]
000075038bdd9e1f  vmovaps xmm1, [rsp+0x10]
000075038bdd9e25  vmovaps xmm2, [rsp+0x20]
000075038bdd9e2b  vmovaps xmm3, [rsp+0x30]
000075038bdd9e31  vmovaps xmm4, [rsp+0x40]
000075038bdd9e37  vmovaps xmm5, [rsp+0x50]
000075038bdd9e3d  vmovaps xmm6, [rsp+0x60]
000075038bdd9e43  vmovaps xmm7, [rsp+0x70]
000075038bdd9e49  vmovaps xmm8, [rsp+0x80]
000075038bdd9e52  vmovaps xmm9, [rsp+0x90]
000075038bdd9e5b  vmovaps xmm11, [rsp+0xA0]
000075038bdd9e64  vmovaps xmm12, [rsp+0xB0]
000075038bdd9e6d  vmovaps xmm13, [rsp+0xC0]
000075038bdd9e76  vmovaps xmm14, [rsp+0xD0]
000075038bdd9e7f  vmovaps xmm15, [rsp+0xE0]
000075038bdd9e88  add rsp, 0xF0
000075038bdd9e8f  pop r11
000075038bdd9e91  pop r10
000075038bdd9e93  pop r9
000075038bdd9e95  pop r8
000075038bdd9e97  pop rsi
000075038bdd9e98  pop rdi
000075038bdd9e99  pop rdx
000075038bdd9e9a  pop rcx
000075038bdd9e9b  pop rax
000075038bdd9e9c  add rsp, 0x08
000075038bdd9ea0  jmp 0x000075038BDD8BE6
000075038bdd9ea5  sub rsp, 0x08
000075038bdd9ea9  push rax
000075038bdd9eaa  push rcx
000075038bdd9eab  push rdx
000075038bdd9eac  push rdi
000075038bdd9ead  push rsi
000075038bdd9eae  push r8
000075038bdd9eb0  push r9
000075038bdd9eb2  push r10
000075038bdd9eb4  push r11
000075038bdd9eb6  sub rsp, 0xF0
000075038bdd9ebd  vmovaps [rsp], xmm0
000075038bdd9ec2  vmovaps [rsp+0x10], xmm1
000075038bdd9ec8  vmovaps [rsp+0x20], xmm2
000075038bdd9ece  vmovaps [rsp+0x30], xmm3
000075038bdd9ed4  vmovaps [rsp+0x40], xmm4
000075038bdd9eda  vmovaps [rsp+0x50], xmm5
000075038bdd9ee0  vmovaps [rsp+0x60], xmm7
000075038bdd9ee6  vmovaps [rsp+0x70], xmm8
000075038bdd9eec  vmovaps [rsp+0x80], xmm9
000075038bdd9ef5  vmovaps [rsp+0x90], xmm10
000075038bdd9efe  vmovaps [rsp+0xA0], xmm11
000075038bdd9f07  vmovaps [rsp+0xB0], xmm12
000075038bdd9f10  vmovaps [rsp+0xC0], xmm13
000075038bdd9f19  vmovaps [rsp+0xD0], xmm14
000075038bdd9f22  vmovaps [rsp+0xE0], xmm15
000075038bdd9f2b  sub rsp, 0x30
000075038bdd9f2f  movaps [rsp], xmm6
000075038bdd9f33  movaps [rsp+0x10], xmm12
000075038bdd9f39  movaps [rsp+0x20], xmm11
000075038bdd9f3f  lea rdi, [rsp]
000075038bdd9f43  mov esi, 0x00
000075038bdd9f48  mov rax, 0x56ADB4492530
000075038bdd9f52  call rax
000075038bdd9f54  movaps xmm6, [rsp]
000075038bdd9f58  add rsp, 0x30
000075038bdd9f5c  vmovaps xmm0, [rsp]
000075038bdd9f61  vmovaps xmm1, [rsp+0x10]
000075038bdd9f67  vmovaps xmm2, [rsp+0x20]
000075038bdd9f6d  vmovaps xmm3, [rsp+0x30]
000075038bdd9f73  vmovaps xmm4, [rsp+0x40]
000075038bdd9f79  vmovaps xmm5, [rsp+0x50]
000075038bdd9f7f  vmovaps xmm7, [rsp+0x60]
000075038bdd9f85  vmovaps xmm8, [rsp+0x70]
000075038bdd9f8b  vmovaps xmm9, [rsp+0x80]
000075038bdd9f94  vmovaps xmm10, [rsp+0x90]
000075038bdd9f9d  vmovaps xmm11, [rsp+0xA0]
000075038bdd9fa6  vmovaps xmm12, [rsp+0xB0]
000075038bdd9faf  vmovaps xmm13, [rsp+0xC0]
000075038bdd9fb8  vmovaps xmm14, [rsp+0xD0]
000075038bdd9fc1  vmovaps xmm15, [rsp+0xE0]
000075038bdd9fca  add rsp, 0xF0
000075038bdd9fd1  pop r11
000075038bdd9fd3  pop r10
000075038bdd9fd5  pop r9
000075038bdd9fd7  pop r8
000075038bdd9fd9  pop rsi
000075038bdd9fda  pop rdi
000075038bdd9fdb  pop rdx
000075038bdd9fdc  pop rcx
000075038bdd9fdd  pop rax
000075038bdd9fde  add rsp, 0x08
000075038bdd9fe2  jmp 0x000075038BDD8C07
000075038bdd9fe7  sub rsp, 0x08
000075038bdd9feb  push rax
000075038bdd9fec  push rcx
000075038bdd9fed  push rdx
000075038bdd9fee  push rdi
000075038bdd9fef  push rsi
000075038bdd9ff0  push r8
000075038bdd9ff2  push r9
000075038bdd9ff4  push r10
000075038bdd9ff6  push r11
000075038bdd9ff8  sub rsp, 0xF0
000075038bdd9fff  vmovaps [rsp], xmm0
000075038bdda004  vmovaps [rsp+0x10], xmm1
000075038bdda00a  vmovaps [rsp+0x20], xmm2
000075038bdda010  vmovaps [rsp+0x30], xmm4
000075038bdda016  vmovaps [rsp+0x40], xmm5
000075038bdda01c  vmovaps [rsp+0x50], xmm6
000075038bdda022  vmovaps [rsp+0x60], xmm7
000075038bdda028  vmovaps [rsp+0x70], xmm8
000075038bdda02e  vmovaps [rsp+0x80], xmm9
000075038bdda037  vmovaps [rsp+0x90], xmm10
000075038bdda040  vmovaps [rsp+0xA0], xmm11
000075038bdda049  vmovaps [rsp+0xB0], xmm12
000075038bdda052  vmovaps [rsp+0xC0], xmm13
000075038bdda05b  vmovaps [rsp+0xD0], xmm14
000075038bdda064  vmovaps [rsp+0xE0], xmm15
000075038bdda06d  sub rsp, 0x30
000075038bdda071  movaps [rsp], xmm3
000075038bdda075  movaps [rsp+0x10], xmm5
000075038bdda07a  movaps [rsp+0x20], xmm4
000075038bdda07f  lea rdi, [rsp]
000075038bdda083  mov esi, 0x00
000075038bdda088  mov rax, 0x56ADB4492530
000075038bdda092  call rax
000075038bdda094  movaps xmm3, [rsp]
000075038bdda098  add rsp, 0x30
000075038bdda09c  vmovaps xmm0, [rsp]
000075038bdda0a1  vmovaps xmm1, [rsp+0x10]
000075038bdda0a7  vmovaps xmm2, [rsp+0x20]
000075038bdda0ad  vmovaps xmm4, [rsp+0x30]
000075038bdda0b3  vmovaps xmm5, [rsp+0x40]
000075038bdda0b9  vmovaps xmm6, [rsp+0x50]
000075038bdda0bf  vmovaps xmm7, [rsp+0x60]
000075038bdda0c5  vmovaps xmm8, [rsp+0x70]
000075038bdda0cb  vmovaps xmm9, [rsp+0x80]
000075038bdda0d4  vmovaps xmm10, [rsp+0x90]
000075038bdda0dd  vmovaps xmm11, [rsp+0xA0]
000075038bdda0e6  vmovaps xmm12, [rsp+0xB0]
000075038bdda0ef  vmovaps xmm13, [rsp+0xC0]
000075038bdda0f8  vmovaps xmm14, [rsp+0xD0]
000075038bdda101  vmovaps xmm15, [rsp+0xE0]
000075038bdda10a  add rsp, 0xF0
000075038bdda111  pop r11
000075038bdda113  pop r10
000075038bdda115  pop r9
000075038bdda117  pop r8
000075038bdda119  pop rsi
000075038bdda11a  pop rdi
000075038bdda11b  pop rdx
000075038bdda11c  pop rcx
000075038bdda11d  pop rax
000075038bdda11e  add rsp, 0x08
000075038bdda122  jmp 0x000075038BDD8C68
000075038bdda127  sub rsp, 0x08
000075038bdda12b  push rax
000075038bdda12c  push rcx
000075038bdda12d  push rdx
000075038bdda12e  push rdi
000075038bdda12f  push rsi
000075038bdda130  push r8
000075038bdda132  push r9
000075038bdda134  push r10
000075038bdda136  push r11
000075038bdda138  sub rsp, 0xF0
000075038bdda13f  vmovaps [rsp], xmm0
000075038bdda144  vmovaps [rsp+0x10], xmm1
000075038bdda14a  vmovaps [rsp+0x20], xmm2
000075038bdda150  vmovaps [rsp+0x30], xmm3
000075038bdda156  vmovaps [rsp+0x40], xmm4
000075038bdda15c  vmovaps [rsp+0x50], xmm6
000075038bdda162  vmovaps [rsp+0x60], xmm7
000075038bdda168  vmovaps [rsp+0x70], xmm8
000075038bdda16e  vmovaps [rsp+0x80], xmm9
000075038bdda177  vmovaps [rsp+0x90], xmm10
000075038bdda180  vmovaps [rsp+0xA0], xmm11
000075038bdda189  vmovaps [rsp+0xB0], xmm12
000075038bdda192  vmovaps [rsp+0xC0], xmm13
000075038bdda19b  vmovaps [rsp+0xD0], xmm14
000075038bdda1a4  vmovaps [rsp+0xE0], xmm15
000075038bdda1ad  sub rsp, 0x30
000075038bdda1b1  movaps [rsp], xmm5
000075038bdda1b5  movaps [rsp+0x10], xmm8
000075038bdda1bb  movaps [rsp+0x20], xmm15
000075038bdda1c1  lea rdi, [rsp]
000075038bdda1c5  mov esi, 0x00
000075038bdda1ca  mov rax, 0x56ADB4492530
000075038bdda1d4  call rax
000075038bdda1d6  movaps xmm5, [rsp]
000075038bdda1da  add rsp, 0x30
000075038bdda1de  vmovaps xmm0, [rsp]
000075038bdda1e3  vmovaps xmm1, [rsp+0x10]
000075038bdda1e9  vmovaps xmm2, [rsp+0x20]
000075038bdda1ef  vmovaps xmm3, [rsp+0x30]
000075038bdda1f5  vmovaps xmm4, [rsp+0x40]
000075038bdda1fb  vmovaps xmm6, [rsp+0x50]
000075038bdda201  vmovaps xmm7, [rsp+0x60]
000075038bdda207  vmovaps xmm8, [rsp+0x70]
000075038bdda20d  vmovaps xmm9, [rsp+0x80]
000075038bdda216  vmovaps xmm10, [rsp+0x90]
000075038bdda21f  vmovaps xmm11, [rsp+0xA0]
000075038bdda228  vmovaps xmm12, [rsp+0xB0]
000075038bdda231  vmovaps xmm13, [rsp+0xC0]
000075038bdda23a  vmovaps xmm14, [rsp+0xD0]
000075038bdda243  vmovaps xmm15, [rsp+0xE0]
000075038bdda24c  add rsp, 0xF0
000075038bdda253  pop r11
000075038bdda255  pop r10
000075038bdda257  pop r9
000075038bdda259  pop r8
000075038bdda25b  pop rsi
000075038bdda25c  pop rdi
000075038bdda25d  pop rdx
000075038bdda25e  pop rcx
000075038bdda25f  pop rax
000075038bdda260  add rsp, 0x08
000075038bdda264  jmp 0x000075038BDD8CA0
000075038bdda269  sub rsp, 0x08
000075038bdda26d  push rax
000075038bdda26e  push rcx
000075038bdda26f  push rdx
000075038bdda270  push rdi
000075038bdda271  push rsi
000075038bdda272  push r8
000075038bdda274  push r9
000075038bdda276  push r10
000075038bdda278  push r11
000075038bdda27a  sub rsp, 0xF0
000075038bdda281  vmovaps [rsp], xmm0
000075038bdda286  vmovaps [rsp+0x10], xmm1
000075038bdda28c  vmovaps [rsp+0x20], xmm2
000075038bdda292  vmovaps [rsp+0x30], xmm3
000075038bdda298  vmovaps [rsp+0x40], xmm5
000075038bdda29e  vmovaps [rsp+0x50], xmm6
000075038bdda2a4  vmovaps [rsp+0x60], xmm7
000075038bdda2aa  vmovaps [rsp+0x70], xmm8
000075038bdda2b0  vmovaps [rsp+0x80], xmm9
000075038bdda2b9  vmovaps [rsp+0x90], xmm10
000075038bdda2c2  vmovaps [rsp+0xA0], xmm11
000075038bdda2cb  vmovaps [rsp+0xB0], xmm12
000075038bdda2d4  vmovaps [rsp+0xC0], xmm13
000075038bdda2dd  vmovaps [rsp+0xD0], xmm14
000075038bdda2e6  vmovaps [rsp+0xE0], xmm15
000075038bdda2ef  sub rsp, 0x30
000075038bdda2f3  movaps [rsp], xmm4
000075038bdda2f7  movaps [rsp+0x10], xmm9
000075038bdda2fd  movaps [rsp+0x20], xmm8
000075038bdda303  lea rdi, [rsp]
000075038bdda307  mov esi, 0x00
000075038bdda30c  mov rax, 0x56ADB4492530
000075038bdda316  call rax
000075038bdda318  movaps xmm4, [rsp]
000075038bdda31c  add rsp, 0x30
000075038bdda320  vmovaps xmm0, [rsp]
000075038bdda325  vmovaps xmm1, [rsp+0x10]
000075038bdda32b  vmovaps xmm2, [rsp+0x20]
000075038bdda331  vmovaps xmm3, [rsp+0x30]
000075038bdda337  vmovaps xmm5, [rsp+0x40]
000075038bdda33d  vmovaps xmm6, [rsp+0x50]
000075038bdda343  vmovaps xmm7, [rsp+0x60]
000075038bdda349  vmovaps xmm8, [rsp+0x70]
000075038bdda34f  vmovaps xmm9, [rsp+0x80]
000075038bdda358  vmovaps xmm10, [rsp+0x90]
000075038bdda361  vmovaps xmm11, [rsp+0xA0]
000075038bdda36a  vmovaps xmm12, [rsp+0xB0]
000075038bdda373  vmovaps xmm13, [rsp+0xC0]
000075038bdda37c  vmovaps xmm14, [rsp+0xD0]
000075038bdda385  vmovaps xmm15, [rsp+0xE0]
000075038bdda38e  add rsp, 0xF0
000075038bdda395  pop r11
000075038bdda397  pop r10
000075038bdda399  pop r9
000075038bdda39b  pop r8
000075038bdda39d  pop rsi
000075038bdda39e  pop rdi
000075038bdda39f  pop rdx
000075038bdda3a0  pop rcx
000075038bdda3a1  pop rax
000075038bdda3a2  add rsp, 0x08
000075038bdda3a6  jmp 0x000075038BDD8CC1
000075038bdda3ab  sub rsp, 0x08
000075038bdda3af  push rax
000075038bdda3b0  push rcx
000075038bdda3b1  push rdx
000075038bdda3b2  push rdi
000075038bdda3b3  push rsi
000075038bdda3b4  push r8
000075038bdda3b6  push r9
000075038bdda3b8  push r10
000075038bdda3ba  push r11
000075038bdda3bc  sub rsp, 0xF0
000075038bdda3c3  vmovaps [rsp], xmm0
000075038bdda3c8  vmovaps [rsp+0x10], xmm1
000075038bdda3ce  vmovaps [rsp+0x20], xmm2
000075038bdda3d4  vmovaps [rsp+0x30], xmm3
000075038bdda3da  vmovaps [rsp+0x40], xmm4
000075038bdda3e0  vmovaps [rsp+0x50], xmm5
000075038bdda3e6  vmovaps [rsp+0x60], xmm6
000075038bdda3ec  vmovaps [rsp+0x70], xmm7
000075038bdda3f2  vmovaps [rsp+0x80], xmm8
000075038bdda3fb  vmovaps [rsp+0x90], xmm10
000075038bdda404  vmovaps [rsp+0xA0], xmm11
000075038bdda40d  vmovaps [rsp+0xB0], xmm12
000075038bdda416  vmovaps [rsp+0xC0], xmm13
000075038bdda41f  vmovaps [rsp+0xD0], xmm14
000075038bdda428  vmovaps [rsp+0xE0], xmm15
000075038bdda431  sub rsp, 0x30
000075038bdda435  movaps [rsp], xmm9
000075038bdda43a  movaps [rsp+0x10], xmm10
000075038bdda440  movaps [rsp+0x20], xmm8
000075038bdda446  lea rdi, [rsp]
000075038bdda44a  mov esi, 0x00
000075038bdda44f  mov rax, 0x56ADB4492530
000075038bdda459  call rax
000075038bdda45b  movaps xmm9, [rsp]
000075038bdda460  add rsp, 0x30
000075038bdda464  vmovaps xmm0, [rsp]
000075038bdda469  vmovaps xmm1, [rsp+0x10]
000075038bdda46f  vmovaps xmm2, [rsp+0x20]
000075038bdda475  vmovaps xmm3, [rsp+0x30]
000075038bdda47b  vmovaps xmm4, [rsp+0x40]
000075038bdda481  vmovaps xmm5, [rsp+0x50]
000075038bdda487  vmovaps xmm6, [rsp+0x60]
000075038bdda48d  vmovaps xmm7, [rsp+0x70]
000075038bdda493  vmovaps xmm8, [rsp+0x80]
000075038bdda49c  vmovaps xmm10, [rsp+0x90]
000075038bdda4a5  vmovaps xmm11, [rsp+0xA0]
000075038bdda4ae  vmovaps xmm12, [rsp+0xB0]
000075038bdda4b7  vmovaps xmm13, [rsp+0xC0]
000075038bdda4c0  vmovaps xmm14, [rsp+0xD0]
000075038bdda4c9  vmovaps xmm15, [rsp+0xE0]
000075038bdda4d2  add rsp, 0xF0
000075038bdda4d9  pop r11
000075038bdda4db  pop r10
000075038bdda4dd  pop r9
000075038bdda4df  pop r8
000075038bdda4e1  pop rsi
000075038bdda4e2  pop rdi
000075038bdda4e3  pop rdx
000075038bdda4e4  pop rcx
000075038bdda4e5  pop rax
000075038bdda4e6  add rsp, 0x08
000075038bdda4ea  jmp 0x000075038BDD8CDB
000075038bdda4ef  call 0x000075038BCD64F0
000075038bdda4f4  jmp 0x000075038BDD8DF5
000075038bdda4f9  call 0x000075038BCD64F0
000075038bdda4fe  jmp 0x000075038BDD8E0B
000075038bdda503  sub rsp, 0x08
000075038bdda507  push rax
000075038bdda508  push rcx
000075038bdda509  push rdx
000075038bdda50a  push rdi
000075038bdda50b  push rsi
000075038bdda50c  push r8
000075038bdda50e  push r9
000075038bdda510  push r10
000075038bdda512  push r11
000075038bdda514  sub rsp, 0xF0
000075038bdda51b  vmovaps [rsp], xmm0
000075038bdda520  vmovaps [rsp+0x10], xmm2
000075038bdda526  vmovaps [rsp+0x20], xmm3
000075038bdda52c  vmovaps [rsp+0x30], xmm4
000075038bdda532  vmovaps [rsp+0x40], xmm5
000075038bdda538  vmovaps [rsp+0x50], xmm6
000075038bdda53e  vmovaps [rsp+0x60], xmm7
000075038bdda544  vmovaps [rsp+0x70], xmm8
000075038bdda54a  vmovaps [rsp+0x80], xmm9
000075038bdda553  vmovaps [rsp+0x90], xmm10
000075038bdda55c  vmovaps [rsp+0xA0], xmm11
000075038bdda565  vmovaps [rsp+0xB0], xmm12
000075038bdda56e  vmovaps [rsp+0xC0], xmm13
000075038bdda577  vmovaps [rsp+0xD0], xmm14
000075038bdda580  vmovaps [rsp+0xE0], xmm15
000075038bdda589  sub rsp, 0x30
000075038bdda58d  movaps [rsp], xmm1
000075038bdda591  movaps [rsp+0x10], xmm6
000075038bdda596  movaps [rsp+0x20], xmm15
000075038bdda59c  lea rdi, [rsp]
000075038bdda5a0  mov esi, 0x00
000075038bdda5a5  mov rax, 0x56ADB4492530
000075038bdda5af  call rax
000075038bdda5b1  movaps xmm1, [rsp]
000075038bdda5b5  add rsp, 0x30
000075038bdda5b9  vmovaps xmm0, [rsp]
000075038bdda5be  vmovaps xmm2, [rsp+0x10]
000075038bdda5c4  vmovaps xmm3, [rsp+0x20]
000075038bdda5ca  vmovaps xmm4, [rsp+0x30]
000075038bdda5d0  vmovaps xmm5, [rsp+0x40]
000075038bdda5d6  vmovaps xmm6, [rsp+0x50]
000075038bdda5dc  vmovaps xmm7, [rsp+0x60]
000075038bdda5e2  vmovaps xmm8, [rsp+0x70]
000075038bdda5e8  vmovaps xmm9, [rsp+0x80]
000075038bdda5f1  vmovaps xmm10, [rsp+0x90]
000075038bdda5fa  vmovaps xmm11, [rsp+0xA0]
000075038bdda603  vmovaps xmm12, [rsp+0xB0]
000075038bdda60c  vmovaps xmm13, [rsp+0xC0]
000075038bdda615  vmovaps xmm14, [rsp+0xD0]
000075038bdda61e  vmovaps xmm15, [rsp+0xE0]
000075038bdda627  add rsp, 0xF0
000075038bdda62e  pop r11
000075038bdda630  pop r10
000075038bdda632  pop r9
000075038bdda634  pop r8
000075038bdda636  pop rsi
000075038bdda637  pop rdi
000075038bdda638  pop rdx
000075038bdda639  pop rcx
000075038bdda63a  pop rax
000075038bdda63b  add rsp, 0x08
000075038bdda63f  jmp 0x000075038BDD8E48
000075038bdda644  call 0x000075038BCE5820
000075038bdda649  jmp 0x000075038BDD8E55
000075038bdda64e  sub rsp, 0x08
000075038bdda652  push rax
000075038bdda653  push rcx
000075038bdda654  push rdx
000075038bdda655  push rdi
000075038bdda656  push rsi
000075038bdda657  push r8
000075038bdda659  push r9
000075038bdda65b  push r10
000075038bdda65d  push r11
000075038bdda65f  sub rsp, 0xF0
000075038bdda666  vmovaps [rsp], xmm0
000075038bdda66b  vmovaps [rsp+0x10], xmm1
000075038bdda671  vmovaps [rsp+0x20], xmm2
000075038bdda677  vmovaps [rsp+0x30], xmm3
000075038bdda67d  vmovaps [rsp+0x40], xmm4
000075038bdda683  vmovaps [rsp+0x50], xmm5
000075038bdda689  vmovaps [rsp+0x60], xmm6
000075038bdda68f  vmovaps [rsp+0x70], xmm7
000075038bdda695  vmovaps [rsp+0x80], xmm8
000075038bdda69e  vmovaps [rsp+0x90], xmm9
000075038bdda6a7  vmovaps [rsp+0xA0], xmm10
000075038bdda6b0  vmovaps [rsp+0xB0], xmm11
000075038bdda6b9  vmovaps [rsp+0xC0], xmm12
000075038bdda6c2  vmovaps [rsp+0xD0], xmm13
000075038bdda6cb  vmovaps [rsp+0xE0], xmm15
000075038bdda6d4  sub rsp, 0x30
000075038bdda6d8  movaps [rsp], xmm14
000075038bdda6dd  movaps [rsp+0x10], xmm4
000075038bdda6e2  movaps [rsp+0x20], xmm3
000075038bdda6e7  lea rdi, [rsp]
000075038bdda6eb  mov esi, 0x00
000075038bdda6f0  mov rax, 0x56ADB4492530
000075038bdda6fa  call rax
000075038bdda6fc  movaps xmm14, [rsp]
000075038bdda701  add rsp, 0x30
000075038bdda705  vmovaps xmm0, [rsp]
000075038bdda70a  vmovaps xmm1, [rsp+0x10]
000075038bdda710  vmovaps xmm2, [rsp+0x20]
000075038bdda716  vmovaps xmm3, [rsp+0x30]
000075038bdda71c  vmovaps xmm4, [rsp+0x40]
000075038bdda722  vmovaps xmm5, [rsp+0x50]
000075038bdda728  vmovaps xmm6, [rsp+0x60]
000075038bdda72e  vmovaps xmm7, [rsp+0x70]
000075038bdda734  vmovaps xmm8, [rsp+0x80]
000075038bdda73d  vmovaps xmm9, [rsp+0x90]
000075038bdda746  vmovaps xmm10, [rsp+0xA0]
000075038bdda74f  vmovaps xmm11, [rsp+0xB0]
000075038bdda758  vmovaps xmm12, [rsp+0xC0]
000075038bdda761  vmovaps xmm13, [rsp+0xD0]
000075038bdda76a  vmovaps xmm15, [rsp+0xE0]
000075038bdda773  add rsp, 0xF0
000075038bdda77a  pop r11
000075038bdda77c  pop r10
000075038bdda77e  pop r9
000075038bdda780  pop r8
000075038bdda782  pop rsi
000075038bdda783  pop rdi
000075038bdda784  pop rdx
000075038bdda785  pop rcx
000075038bdda786  pop rax
000075038bdda787  add rsp, 0x08
000075038bdda78b  jmp 0x000075038BDD8E6F
000075038bdda790  sub rsp, 0x08
000075038bdda794  push rax
000075038bdda795  push rcx
000075038bdda796  push rdx
000075038bdda797  push rdi
000075038bdda798  push rsi
000075038bdda799  push r8
000075038bdda79b  push r9
000075038bdda79d  push r10
000075038bdda79f  push r11
000075038bdda7a1  sub rsp, 0xF0
000075038bdda7a8  vmovaps [rsp], xmm0
000075038bdda7ad  vmovaps [rsp+0x10], xmm1
000075038bdda7b3  vmovaps [rsp+0x20], xmm2
000075038bdda7b9  vmovaps [rsp+0x30], xmm3
000075038bdda7bf  vmovaps [rsp+0x40], xmm4
000075038bdda7c5  vmovaps [rsp+0x50], xmm5
000075038bdda7cb  vmovaps [rsp+0x60], xmm7
000075038bdda7d1  vmovaps [rsp+0x70], xmm8
000075038bdda7d7  vmovaps [rsp+0x80], xmm9
000075038bdda7e0  vmovaps [rsp+0x90], xmm10
000075038bdda7e9  vmovaps [rsp+0xA0], xmm11
000075038bdda7f2  vmovaps [rsp+0xB0], xmm12
000075038bdda7fb  vmovaps [rsp+0xC0], xmm13
000075038bdda804  vmovaps [rsp+0xD0], xmm14
000075038bdda80d  vmovaps [rsp+0xE0], xmm15
000075038bdda816  sub rsp, 0x30
000075038bdda81a  movaps [rsp], xmm6
000075038bdda81e  movaps [rsp+0x10], xmm9
000075038bdda824  movaps [rsp+0x20], xmm7
000075038bdda829  lea rdi, [rsp]
000075038bdda82d  mov esi, 0x00
000075038bdda832  mov rax, 0x56ADB4492530
000075038bdda83c  call rax
000075038bdda83e  movaps xmm6, [rsp]
000075038bdda842  add rsp, 0x30
000075038bdda846  vmovaps xmm0, [rsp]
000075038bdda84b  vmovaps xmm1, [rsp+0x10]
000075038bdda851  vmovaps xmm2, [rsp+0x20]
000075038bdda857  vmovaps xmm3, [rsp+0x30]
000075038bdda85d  vmovaps xmm4, [rsp+0x40]
000075038bdda863  vmovaps xmm5, [rsp+0x50]
000075038bdda869  vmovaps xmm7, [rsp+0x60]
000075038bdda86f  vmovaps xmm8, [rsp+0x70]
000075038bdda875  vmovaps xmm9, [rsp+0x80]
000075038bdda87e  vmovaps xmm10, [rsp+0x90]
000075038bdda887  vmovaps xmm11, [rsp+0xA0]
000075038bdda890  vmovaps xmm12, [rsp+0xB0]
000075038bdda899  vmovaps xmm13, [rsp+0xC0]
000075038bdda8a2  vmovaps xmm14, [rsp+0xD0]
000075038bdda8ab  vmovaps xmm15, [rsp+0xE0]
000075038bdda8b4  add rsp, 0xF0
000075038bdda8bb  pop r11
000075038bdda8bd  pop r10
000075038bdda8bf  pop r9
000075038bdda8c1  pop r8
000075038bdda8c3  pop rsi
000075038bdda8c4  pop rdi
000075038bdda8c5  pop rdx
000075038bdda8c6  pop rcx
000075038bdda8c7  pop rax
000075038bdda8c8  add rsp, 0x08
000075038bdda8cc  jmp 0x000075038BDD8E87
000075038bdda8d1  sub rsp, 0x08
000075038bdda8d5  push rax
000075038bdda8d6  push rcx
000075038bdda8d7  push rdx
000075038bdda8d8  push rdi
000075038bdda8d9  push rsi
000075038bdda8da  push r8
000075038bdda8dc  push r9
000075038bdda8de  push r10
000075038bdda8e0  push r11
000075038bdda8e2  sub rsp, 0xF0
000075038bdda8e9  vmovaps [rsp], xmm0
000075038bdda8ee  vmovaps [rsp+0x10], xmm1
000075038bdda8f4  vmovaps [rsp+0x20], xmm2
000075038bdda8fa  vmovaps [rsp+0x30], xmm3
000075038bdda900  vmovaps [rsp+0x40], xmm4
000075038bdda906  vmovaps [rsp+0x50], xmm5
000075038bdda90c  vmovaps [rsp+0x60], xmm6
000075038bdda912  vmovaps [rsp+0x70], xmm8
000075038bdda918  vmovaps [rsp+0x80], xmm9
000075038bdda921  vmovaps [rsp+0x90], xmm10
000075038bdda92a  vmovaps [rsp+0xA0], xmm11
000075038bdda933  vmovaps [rsp+0xB0], xmm12
000075038bdda93c  vmovaps [rsp+0xC0], xmm13
000075038bdda945  vmovaps [rsp+0xD0], xmm14
000075038bdda94e  vmovaps [rsp+0xE0], xmm15
000075038bdda957  sub rsp, 0x30
000075038bdda95b  movaps [rsp], xmm7
000075038bdda95f  movaps [rsp+0x10], xmm4
000075038bdda964  movaps [rsp+0x20], xmm9
000075038bdda96a  lea rdi, [rsp]
000075038bdda96e  mov esi, 0x00
000075038bdda973  mov rax, 0x56ADB4492530
000075038bdda97d  call rax
000075038bdda97f  movaps xmm7, [rsp]
000075038bdda983  add rsp, 0x30
000075038bdda987  vmovaps xmm0, [rsp]
000075038bdda98c  vmovaps xmm1, [rsp+0x10]
000075038bdda992  vmovaps xmm2, [rsp+0x20]
000075038bdda998  vmovaps xmm3, [rsp+0x30]
000075038bdda99e  vmovaps xmm4, [rsp+0x40]
000075038bdda9a4  vmovaps xmm5, [rsp+0x50]
000075038bdda9aa  vmovaps xmm6, [rsp+0x60]
000075038bdda9b0  vmovaps xmm8, [rsp+0x70]
000075038bdda9b6  vmovaps xmm9, [rsp+0x80]
000075038bdda9bf  vmovaps xmm10, [rsp+0x90]
000075038bdda9c8  vmovaps xmm11, [rsp+0xA0]
000075038bdda9d1  vmovaps xmm12, [rsp+0xB0]
000075038bdda9da  vmovaps xmm13, [rsp+0xC0]
000075038bdda9e3  vmovaps xmm14, [rsp+0xD0]
000075038bdda9ec  vmovaps xmm15, [rsp+0xE0]
000075038bdda9f5  add rsp, 0xF0
000075038bdda9fc  pop r11
000075038bdda9fe  pop r10
000075038bddaa00  pop r9
000075038bddaa02  pop r8
000075038bddaa04  pop rsi
000075038bddaa05  pop rdi
000075038bddaa06  pop rdx
000075038bddaa07  pop rcx
000075038bddaa08  pop rax
000075038bddaa09  add rsp, 0x08
000075038bddaa0d  jmp 0x000075038BDD8EB4
000075038bddaa12  sub rsp, 0x08
000075038bddaa16  push rax
000075038bddaa17  push rcx
000075038bddaa18  push rdx
000075038bddaa19  push rdi
000075038bddaa1a  push rsi
000075038bddaa1b  push r8
000075038bddaa1d  push r9
000075038bddaa1f  push r10
000075038bddaa21  push r11
000075038bddaa23  sub rsp, 0xF0
000075038bddaa2a  vmovaps [rsp], xmm0
000075038bddaa2f  vmovaps [rsp+0x10], xmm1
000075038bddaa35  vmovaps [rsp+0x20], xmm2
000075038bddaa3b  vmovaps [rsp+0x30], xmm3
000075038bddaa41  vmovaps [rsp+0x40], xmm5
000075038bddaa47  vmovaps [rsp+0x50], xmm6
000075038bddaa4d  vmovaps [rsp+0x60], xmm7
000075038bddaa53  vmovaps [rsp+0x70], xmm8
000075038bddaa59  vmovaps [rsp+0x80], xmm9
000075038bddaa62  vmovaps [rsp+0x90], xmm10
000075038bddaa6b  vmovaps [rsp+0xA0], xmm11
000075038bddaa74  vmovaps [rsp+0xB0], xmm12
000075038bddaa7d  vmovaps [rsp+0xC0], xmm13
000075038bddaa86  vmovaps [rsp+0xD0], xmm14
000075038bddaa8f  vmovaps [rsp+0xE0], xmm15
000075038bddaa98  sub rsp, 0x30
000075038bddaa9c  movaps [rsp], xmm4
000075038bddaaa0  movaps [rsp+0x10], xmm15
000075038bddaaa6  movaps [rsp+0x20], xmm9
000075038bddaaac  lea rdi, [rsp]
000075038bddaab0  mov esi, 0x00
000075038bddaab5  mov rax, 0x56ADB4492530
000075038bddaabf  call rax
000075038bddaac1  movaps xmm4, [rsp]
000075038bddaac5  add rsp, 0x30
000075038bddaac9  vmovaps xmm0, [rsp]
000075038bddaace  vmovaps xmm1, [rsp+0x10]
000075038bddaad4  vmovaps xmm2, [rsp+0x20]
000075038bddaada  vmovaps xmm3, [rsp+0x30]
000075038bddaae0  vmovaps xmm5, [rsp+0x40]
000075038bddaae6  vmovaps xmm6, [rsp+0x50]
000075038bddaaec  vmovaps xmm7, [rsp+0x60]
000075038bddaaf2  vmovaps xmm8, [rsp+0x70]
000075038bddaaf8  vmovaps xmm9, [rsp+0x80]
000075038bddab01  vmovaps xmm10, [rsp+0x90]
000075038bddab0a  vmovaps xmm11, [rsp+0xA0]
000075038bddab13  vmovaps xmm12, [rsp+0xB0]
000075038bddab1c  vmovaps xmm13, [rsp+0xC0]
000075038bddab25  vmovaps xmm14, [rsp+0xD0]
000075038bddab2e  vmovaps xmm15, [rsp+0xE0]
000075038bddab37  add rsp, 0xF0
000075038bddab3e  pop r11
000075038bddab40  pop r10
000075038bddab42  pop r9
000075038bddab44  pop r8
000075038bddab46  pop rsi
000075038bddab47  pop rdi
000075038bddab48  pop rdx
000075038bddab49  pop rcx
000075038bddab4a  pop rax
000075038bddab4b  add rsp, 0x08
000075038bddab4f  jmp 0x000075038BDD8ED9
000075038bddab54  call 0x000075038BCE5820
000075038bddab59  jmp 0x000075038BDD8EE6
000075038bddab5e  sub rsp, 0x08
000075038bddab62  push rax
000075038bddab63  push rcx
000075038bddab64  push rdx
000075038bddab65  push rdi
000075038bddab66  push rsi
000075038bddab67  push r8
000075038bddab69  push r9
000075038bddab6b  push r10
000075038bddab6d  push r11
000075038bddab6f  sub rsp, 0xF0
000075038bddab76  vmovaps [rsp], xmm0
000075038bddab7b  vmovaps [rsp+0x10], xmm1
000075038bddab81  vmovaps [rsp+0x20], xmm2
000075038bddab87  vmovaps [rsp+0x30], xmm4
000075038bddab8d  vmovaps [rsp+0x40], xmm5
000075038bddab93  vmovaps [rsp+0x50], xmm6
000075038bddab99  vmovaps [rsp+0x60], xmm7
000075038bddab9f  vmovaps [rsp+0x70], xmm8
000075038bddaba5  vmovaps [rsp+0x80], xmm9
000075038bddabae  vmovaps [rsp+0x90], xmm10
000075038bddabb7  vmovaps [rsp+0xA0], xmm11
000075038bddabc0  vmovaps [rsp+0xB0], xmm12
000075038bddabc9  vmovaps [rsp+0xC0], xmm13
000075038bddabd2  vmovaps [rsp+0xD0], xmm14
000075038bddabdb  vmovaps [rsp+0xE0], xmm15
000075038bddabe4  sub rsp, 0x30
000075038bddabe8  movaps [rsp], xmm3
000075038bddabec  movaps [rsp+0x10], xmm1
000075038bddabf1  movaps [rsp+0x20], xmm9
000075038bddabf7  lea rdi, [rsp]
000075038bddabfb  mov esi, 0x00
000075038bddac00  mov rax, 0x56ADB4492530
000075038bddac0a  call rax
000075038bddac0c  movaps xmm3, [rsp]
000075038bddac10  add rsp, 0x30
000075038bddac14  vmovaps xmm0, [rsp]
000075038bddac19  vmovaps xmm1, [rsp+0x10]
000075038bddac1f  vmovaps xmm2, [rsp+0x20]
000075038bddac25  vmovaps xmm4, [rsp+0x30]
000075038bddac2b  vmovaps xmm5, [rsp+0x40]
000075038bddac31  vmovaps xmm6, [rsp+0x50]
000075038bddac37  vmovaps xmm7, [rsp+0x60]
000075038bddac3d  vmovaps xmm8, [rsp+0x70]
000075038bddac43  vmovaps xmm9, [rsp+0x80]
000075038bddac4c  vmovaps xmm10, [rsp+0x90]
000075038bddac55  vmovaps xmm11, [rsp+0xA0]
000075038bddac5e  vmovaps xmm12, [rsp+0xB0]
000075038bddac67  vmovaps xmm13, [rsp+0xC0]
000075038bddac70  vmovaps xmm14, [rsp+0xD0]
000075038bddac79  vmovaps xmm15, [rsp+0xE0]
000075038bddac82  add rsp, 0xF0
000075038bddac89  pop r11
000075038bddac8b  pop r10
000075038bddac8d  pop r9
000075038bddac8f  pop r8
000075038bddac91  pop rsi
000075038bddac92  pop rdi
000075038bddac93  pop rdx
000075038bddac94  pop rcx
000075038bddac95  pop rax
000075038bddac96  add rsp, 0x08
000075038bddac9a  jmp 0x000075038BDD8F23
000075038bddac9f  sub rsp, 0x08
000075038bddaca3  push rax
000075038bddaca4  push rcx
000075038bddaca5  push rdx
000075038bddaca6  push rdi
000075038bddaca7  push rsi
000075038bddaca8  push r8
000075038bddacaa  push r9
000075038bddacac  push r10
000075038bddacae  push r11
000075038bddacb0  sub rsp, 0xF0
000075038bddacb7  vmovaps [rsp], xmm0
000075038bddacbc  vmovaps [rsp+0x10], xmm2
000075038bddacc2  vmovaps [rsp+0x20], xmm3
000075038bddacc8  vmovaps [rsp+0x30], xmm4
000075038bddacce  vmovaps [rsp+0x40], xmm5
000075038bddacd4  vmovaps [rsp+0x50], xmm6
000075038bddacda  vmovaps [rsp+0x60], xmm7
000075038bddace0  vmovaps [rsp+0x70], xmm8
000075038bddace6  vmovaps [rsp+0x80], xmm9
000075038bddacef  vmovaps [rsp+0x90], xmm10
000075038bddacf8  vmovaps [rsp+0xA0], xmm11
000075038bddad01  vmovaps [rsp+0xB0], xmm12
000075038bddad0a  vmovaps [rsp+0xC0], xmm13
000075038bddad13  vmovaps [rsp+0xD0], xmm14
000075038bddad1c  vmovaps [rsp+0xE0], xmm15
000075038bddad25  sub rsp, 0x30
000075038bddad29  movaps [rsp], xmm1
000075038bddad2d  movaps [rsp+0x10], xmm15
000075038bddad33  movaps [rsp+0x20], xmm9
000075038bddad39  lea rdi, [rsp]
000075038bddad3d  mov esi, 0x00
000075038bddad42  mov rax, 0x56ADB4492530
000075038bddad4c  call rax
000075038bddad4e  movaps xmm1, [rsp]
000075038bddad52  add rsp, 0x30
000075038bddad56  vmovaps xmm0, [rsp]
000075038bddad5b  vmovaps xmm2, [rsp+0x10]
000075038bddad61  vmovaps xmm3, [rsp+0x20]
000075038bddad67  vmovaps xmm4, [rsp+0x30]
000075038bddad6d  vmovaps xmm5, [rsp+0x40]
000075038bddad73  vmovaps xmm6, [rsp+0x50]
000075038bddad79  vmovaps xmm7, [rsp+0x60]
000075038bddad7f  vmovaps xmm8, [rsp+0x70]
000075038bddad85  vmovaps xmm9, [rsp+0x80]
000075038bddad8e  vmovaps xmm10, [rsp+0x90]
000075038bddad97  vmovaps xmm11, [rsp+0xA0]
000075038bddada0  vmovaps xmm12, [rsp+0xB0]
000075038bddada9  vmovaps xmm13, [rsp+0xC0]
000075038bddadb2  vmovaps xmm14, [rsp+0xD0]
000075038bddadbb  vmovaps xmm15, [rsp+0xE0]
000075038bddadc4  add rsp, 0xF0
000075038bddadcb  pop r11
000075038bddadcd  pop r10
000075038bddadcf  pop r9
000075038bddadd1  pop r8
000075038bddadd3  pop rsi
000075038bddadd4  pop rdi
000075038bddadd5  pop rdx
000075038bddadd6  pop rcx
000075038bddadd7  pop rax
000075038bddadd8  add rsp, 0x08
000075038bddaddc  jmp 0x000075038BDD8FAB
000075038bddade1  call 0x000075038BCE5820
000075038bddade6  jmp 0x000075038BDD8FB8
000075038bddadeb  sub rsp, 0x08
000075038bddadef  push rax
000075038bddadf0  push rcx
000075038bddadf1  push rdx
000075038bddadf2  push rdi
000075038bddadf3  push rsi
000075038bddadf4  push r8
000075038bddadf6  push r9
000075038bddadf8  push r10
000075038bddadfa  push r11
000075038bddadfc  sub rsp, 0xF0
000075038bddae03  vmovaps [rsp], xmm0
000075038bddae08  vmovaps [rsp+0x10], xmm2
000075038bddae0e  vmovaps [rsp+0x20], xmm3
000075038bddae14  vmovaps [rsp+0x30], xmm4
000075038bddae1a  vmovaps [rsp+0x40], xmm5
000075038bddae20  vmovaps [rsp+0x50], xmm6
000075038bddae26  vmovaps [rsp+0x60], xmm7
000075038bddae2c  vmovaps [rsp+0x70], xmm8
000075038bddae32  vmovaps [rsp+0x80], xmm9
000075038bddae3b  vmovaps [rsp+0x90], xmm10
000075038bddae44  vmovaps [rsp+0xA0], xmm11
000075038bddae4d  vmovaps [rsp+0xB0], xmm12
000075038bddae56  vmovaps [rsp+0xC0], xmm13
000075038bddae5f  vmovaps [rsp+0xD0], xmm14
000075038bddae68  vmovaps [rsp+0xE0], xmm15
000075038bddae71  sub rsp, 0x30
000075038bddae75  movaps [rsp], xmm1
000075038bddae79  movaps [rsp+0x10], xmm5
000075038bddae7e  movaps [rsp+0x20], xmm7
000075038bddae83  lea rdi, [rsp]
000075038bddae87  mov esi, 0x00
000075038bddae8c  mov rax, 0x56ADB4492530
000075038bddae96  call rax
000075038bddae98  movaps xmm1, [rsp]
000075038bddae9c  add rsp, 0x30
000075038bddaea0  vmovaps xmm0, [rsp]
000075038bddaea5  vmovaps xmm2, [rsp+0x10]
000075038bddaeab  vmovaps xmm3, [rsp+0x20]
000075038bddaeb1  vmovaps xmm4, [rsp+0x30]
000075038bddaeb7  vmovaps xmm5, [rsp+0x40]
000075038bddaebd  vmovaps xmm6, [rsp+0x50]
000075038bddaec3  vmovaps xmm7, [rsp+0x60]
000075038bddaec9  vmovaps xmm8, [rsp+0x70]
000075038bddaecf  vmovaps xmm9, [rsp+0x80]
000075038bddaed8  vmovaps xmm10, [rsp+0x90]
000075038bddaee1  vmovaps xmm11, [rsp+0xA0]
000075038bddaeea  vmovaps xmm12, [rsp+0xB0]
000075038bddaef3  vmovaps xmm13, [rsp+0xC0]
000075038bddaefc  vmovaps xmm14, [rsp+0xD0]
000075038bddaf05  vmovaps xmm15, [rsp+0xE0]
000075038bddaf0e  add rsp, 0xF0
000075038bddaf15  pop r11
000075038bddaf17  pop r10
000075038bddaf19  pop r9
000075038bddaf1b  pop r8
000075038bddaf1d  pop rsi
000075038bddaf1e  pop rdi
000075038bddaf1f  pop rdx
000075038bddaf20  pop rcx
000075038bddaf21  pop rax
000075038bddaf22  add rsp, 0x08
000075038bddaf26  jmp 0x000075038BDD905D
000075038bddaf2b  sub rsp, 0x08
000075038bddaf2f  push rax
000075038bddaf30  push rcx
000075038bddaf31  push rdx
000075038bddaf32  push rdi
000075038bddaf33  push rsi
000075038bddaf34  push r8
000075038bddaf36  push r9
000075038bddaf38  push r10
000075038bddaf3a  push r11
000075038bddaf3c  sub rsp, 0xF0
000075038bddaf43  vmovaps [rsp], xmm0
000075038bddaf48  vmovaps [rsp+0x10], xmm1
000075038bddaf4e  vmovaps [rsp+0x20], xmm2
000075038bddaf54  vmovaps [rsp+0x30], xmm3
000075038bddaf5a  vmovaps [rsp+0x40], xmm4
000075038bddaf60  vmovaps [rsp+0x50], xmm5
000075038bddaf66  vmovaps [rsp+0x60], xmm6
000075038bddaf6c  vmovaps [rsp+0x70], xmm8
000075038bddaf72  vmovaps [rsp+0x80], xmm9
000075038bddaf7b  vmovaps [rsp+0x90], xmm10
000075038bddaf84  vmovaps [rsp+0xA0], xmm11
000075038bddaf8d  vmovaps [rsp+0xB0], xmm12
000075038bddaf96  vmovaps [rsp+0xC0], xmm13
000075038bddaf9f  vmovaps [rsp+0xD0], xmm14
000075038bddafa8  vmovaps [rsp+0xE0], xmm15
000075038bddafb1  sub rsp, 0x30
000075038bddafb5  movaps [rsp], xmm7
000075038bddafb9  movaps [rsp+0x10], xmm5
000075038bddafbe  movaps [rsp+0x20], xmm15
000075038bddafc4  lea rdi, [rsp]
000075038bddafc8  mov esi, 0x00
000075038bddafcd  mov rax, 0x56ADB4492530
000075038bddafd7  call rax
000075038bddafd9  movaps xmm7, [rsp]
000075038bddafdd  add rsp, 0x30
000075038bddafe1  vmovaps xmm0, [rsp]
000075038bddafe6  vmovaps xmm1, [rsp+0x10]
000075038bddafec  vmovaps xmm2, [rsp+0x20]
000075038bddaff2  vmovaps xmm3, [rsp+0x30]
000075038bddaff8  vmovaps xmm4, [rsp+0x40]
000075038bddaffe  vmovaps xmm5, [rsp+0x50]
000075038bddb004  vmovaps xmm6, [rsp+0x60]
000075038bddb00a  vmovaps xmm8, [rsp+0x70]
000075038bddb010  vmovaps xmm9, [rsp+0x80]
000075038bddb019  vmovaps xmm10, [rsp+0x90]
000075038bddb022  vmovaps xmm11, [rsp+0xA0]
000075038bddb02b  vmovaps xmm12, [rsp+0xB0]
000075038bddb034  vmovaps xmm13, [rsp+0xC0]
000075038bddb03d  vmovaps xmm14, [rsp+0xD0]
000075038bddb046  vmovaps xmm15, [rsp+0xE0]
000075038bddb04f  add rsp, 0xF0
000075038bddb056  pop r11
000075038bddb058  pop r10
000075038bddb05a  pop r9
000075038bddb05c  pop r8
000075038bddb05e  pop rsi
000075038bddb05f  pop rdi
000075038bddb060  pop rdx
000075038bddb061  pop rcx
000075038bddb062  pop rax
000075038bddb063  add rsp, 0x08
000075038bddb067  jmp 0x000075038BDD9093
000075038bddb06c  call 0x000075038BCD64F0
000075038bddb071  jmp 0x000075038BDD90A0
000075038bddb076  sub rsp, 0x08
000075038bddb07a  push rax
000075038bddb07b  push rcx
000075038bddb07c  push rdx
000075038bddb07d  push rdi
000075038bddb07e  push rsi
000075038bddb07f  push r8
000075038bddb081  push r9
000075038bddb083  push r10
000075038bddb085  push r11
000075038bddb087  sub rsp, 0xF0
000075038bddb08e  vmovaps [rsp], xmm0
000075038bddb093  vmovaps [rsp+0x10], xmm1
000075038bddb099  vmovaps [rsp+0x20], xmm2
000075038bddb09f  vmovaps [rsp+0x30], xmm3
000075038bddb0a5  vmovaps [rsp+0x40], xmm4
000075038bddb0ab  vmovaps [rsp+0x50], xmm5
000075038bddb0b1  vmovaps [rsp+0x60], xmm6
000075038bddb0b7  vmovaps [rsp+0x70], xmm7
000075038bddb0bd  vmovaps [rsp+0x80], xmm8
000075038bddb0c6  vmovaps [rsp+0x90], xmm9
000075038bddb0cf  vmovaps [rsp+0xA0], xmm10
000075038bddb0d8  vmovaps [rsp+0xB0], xmm11
000075038bddb0e1  vmovaps [rsp+0xC0], xmm12
000075038bddb0ea  vmovaps [rsp+0xD0], xmm13
000075038bddb0f3  vmovaps [rsp+0xE0], xmm14
000075038bddb0fc  sub rsp, 0x30
000075038bddb100  movaps [rsp], xmm15
000075038bddb105  movaps [rsp+0x10], xmm5
000075038bddb10a  movaps [rsp+0x20], xmm3
000075038bddb10f  lea rdi, [rsp]
000075038bddb113  mov esi, 0x00
000075038bddb118  mov rax, 0x56ADB4492530
000075038bddb122  call rax
000075038bddb124  movaps xmm15, [rsp]
000075038bddb129  add rsp, 0x30
000075038bddb12d  vmovaps xmm0, [rsp]
000075038bddb132  vmovaps xmm1, [rsp+0x10]
000075038bddb138  vmovaps xmm2, [rsp+0x20]
000075038bddb13e  vmovaps xmm3, [rsp+0x30]
000075038bddb144  vmovaps xmm4, [rsp+0x40]
000075038bddb14a  vmovaps xmm5, [rsp+0x50]
000075038bddb150  vmovaps xmm6, [rsp+0x60]
000075038bddb156  vmovaps xmm7, [rsp+0x70]
000075038bddb15c  vmovaps xmm8, [rsp+0x80]
000075038bddb165  vmovaps xmm9, [rsp+0x90]
000075038bddb16e  vmovaps xmm10, [rsp+0xA0]
000075038bddb177  vmovaps xmm11, [rsp+0xB0]
000075038bddb180  vmovaps xmm12, [rsp+0xC0]
000075038bddb189  vmovaps xmm13, [rsp+0xD0]
000075038bddb192  vmovaps xmm14, [rsp+0xE0]
000075038bddb19b  add rsp, 0xF0
000075038bddb1a2  pop r11
000075038bddb1a4  pop r10
000075038bddb1a6  pop r9
000075038bddb1a8  pop r8
000075038bddb1aa  pop rsi
000075038bddb1ab  pop rdi
000075038bddb1ac  pop rdx
000075038bddb1ad  pop rcx
000075038bddb1ae  pop rax
000075038bddb1af  add rsp, 0x08
000075038bddb1b3  jmp 0x000075038BDD90C6
000075038bddb1b8  sub rsp, 0x08
000075038bddb1bc  push rax
000075038bddb1bd  push rcx
000075038bddb1be  push rdx
000075038bddb1bf  push rdi
000075038bddb1c0  push rsi
000075038bddb1c1  push r8
000075038bddb1c3  push r9
000075038bddb1c5  push r10
000075038bddb1c7  push r11
000075038bddb1c9  sub rsp, 0xF0
000075038bddb1d0  vmovaps [rsp], xmm0
000075038bddb1d5  vmovaps [rsp+0x10], xmm2
000075038bddb1db  vmovaps [rsp+0x20], xmm3
000075038bddb1e1  vmovaps [rsp+0x30], xmm4
000075038bddb1e7  vmovaps [rsp+0x40], xmm5
000075038bddb1ed  vmovaps [rsp+0x50], xmm6
000075038bddb1f3  vmovaps [rsp+0x60], xmm7
000075038bddb1f9  vmovaps [rsp+0x70], xmm8
000075038bddb1ff  vmovaps [rsp+0x80], xmm9
000075038bddb208  vmovaps [rsp+0x90], xmm10
000075038bddb211  vmovaps [rsp+0xA0], xmm11
000075038bddb21a  vmovaps [rsp+0xB0], xmm12
000075038bddb223  vmovaps [rsp+0xC0], xmm13
000075038bddb22c  vmovaps [rsp+0xD0], xmm14
000075038bddb235  vmovaps [rsp+0xE0], xmm15
000075038bddb23e  sub rsp, 0x30
000075038bddb242  movaps [rsp], xmm1
000075038bddb246  movaps [rsp+0x10], xmm5
000075038bddb24b  movaps [rsp+0x20], xmm4
000075038bddb250  lea rdi, [rsp]
000075038bddb254  mov esi, 0x00
000075038bddb259  mov rax, 0x56ADB4492530
000075038bddb263  call rax
000075038bddb265  movaps xmm1, [rsp]
000075038bddb269  add rsp, 0x30
000075038bddb26d  vmovaps xmm0, [rsp]
000075038bddb272  vmovaps xmm2, [rsp+0x10]
000075038bddb278  vmovaps xmm3, [rsp+0x20]
000075038bddb27e  vmovaps xmm4, [rsp+0x30]
000075038bddb284  vmovaps xmm5, [rsp+0x40]
000075038bddb28a  vmovaps xmm6, [rsp+0x50]
000075038bddb290  vmovaps xmm7, [rsp+0x60]
000075038bddb296  vmovaps xmm8, [rsp+0x70]
000075038bddb29c  vmovaps xmm9, [rsp+0x80]
000075038bddb2a5  vmovaps xmm10, [rsp+0x90]
000075038bddb2ae  vmovaps xmm11, [rsp+0xA0]
000075038bddb2b7  vmovaps xmm12, [rsp+0xB0]
000075038bddb2c0  vmovaps xmm13, [rsp+0xC0]
000075038bddb2c9  vmovaps xmm14, [rsp+0xD0]
000075038bddb2d2  vmovaps xmm15, [rsp+0xE0]
000075038bddb2db  add rsp, 0xF0
000075038bddb2e2  pop r11
000075038bddb2e4  pop r10
000075038bddb2e6  pop r9
000075038bddb2e8  pop r8
000075038bddb2ea  pop rsi
000075038bddb2eb  pop rdi
000075038bddb2ec  pop rdx
000075038bddb2ed  pop rcx
000075038bddb2ee  pop rax
000075038bddb2ef  add rsp, 0x08
000075038bddb2f3  jmp 0x000075038BDD90E6
000075038bddb2f8  sub rsp, 0x08
000075038bddb2fc  push rax
000075038bddb2fd  push rcx
000075038bddb2fe  push rdx
000075038bddb2ff  push rdi
000075038bddb300  push rsi
000075038bddb301  push r8
000075038bddb303  push r9
000075038bddb305  push r10
000075038bddb307  push r11
000075038bddb309  sub rsp, 0xF0
000075038bddb310  vmovaps [rsp], xmm0
000075038bddb315  vmovaps [rsp+0x10], xmm1
000075038bddb31b  vmovaps [rsp+0x20], xmm2
000075038bddb321  vmovaps [rsp+0x30], xmm3
000075038bddb327  vmovaps [rsp+0x40], xmm5
000075038bddb32d  vmovaps [rsp+0x50], xmm6
000075038bddb333  vmovaps [rsp+0x60], xmm7
000075038bddb339  vmovaps [rsp+0x70], xmm8
000075038bddb33f  vmovaps [rsp+0x80], xmm9
000075038bddb348  vmovaps [rsp+0x90], xmm10
000075038bddb351  vmovaps [rsp+0xA0], xmm11
000075038bddb35a  vmovaps [rsp+0xB0], xmm12
000075038bddb363  vmovaps [rsp+0xC0], xmm13
000075038bddb36c  vmovaps [rsp+0xD0], xmm14
000075038bddb375  vmovaps [rsp+0xE0], xmm15
000075038bddb37e  sub rsp, 0x30
000075038bddb382  movaps [rsp], xmm4
000075038bddb386  movaps [rsp+0x10], xmm3
000075038bddb38b  movaps [rsp+0x20], xmm5
000075038bddb390  lea rdi, [rsp]
000075038bddb394  mov esi, 0x00
000075038bddb399  mov rax, 0x56ADB4492530
000075038bddb3a3  call rax
000075038bddb3a5  movaps xmm4, [rsp]
000075038bddb3a9  add rsp, 0x30
000075038bddb3ad  vmovaps xmm0, [rsp]
000075038bddb3b2  vmovaps xmm1, [rsp+0x10]
000075038bddb3b8  vmovaps xmm2, [rsp+0x20]
000075038bddb3be  vmovaps xmm3, [rsp+0x30]
000075038bddb3c4  vmovaps xmm5, [rsp+0x40]
000075038bddb3ca  vmovaps xmm6, [rsp+0x50]
000075038bddb3d0  vmovaps xmm7, [rsp+0x60]
000075038bddb3d6  vmovaps xmm8, [rsp+0x70]
000075038bddb3dc  vmovaps xmm9, [rsp+0x80]
000075038bddb3e5  vmovaps xmm10, [rsp+0x90]
000075038bddb3ee  vmovaps xmm11, [rsp+0xA0]
000075038bddb3f7  vmovaps xmm12, [rsp+0xB0]
000075038bddb400  vmovaps xmm13, [rsp+0xC0]
000075038bddb409  vmovaps xmm14, [rsp+0xD0]
000075038bddb412  vmovaps xmm15, [rsp+0xE0]
000075038bddb41b  add rsp, 0xF0
000075038bddb422  pop r11
000075038bddb424  pop r10
000075038bddb426  pop r9
000075038bddb428  pop r8
000075038bddb42a  pop rsi
000075038bddb42b  pop rdi
000075038bddb42c  pop rdx
000075038bddb42d  pop rcx
000075038bddb42e  pop rax
000075038bddb42f  add rsp, 0x08
000075038bddb433  jmp 0x000075038BDD9134
000075038bddb438  call 0x000075038BCD64F0
000075038bddb43d  jmp 0x000075038BDD9141
000075038bddb442  sub rsp, 0x08
000075038bddb446  push rax
000075038bddb447  push rcx
000075038bddb448  push rdx
000075038bddb449  push rdi
000075038bddb44a  push rsi
000075038bddb44b  push r8
000075038bddb44d  push r9
000075038bddb44f  push r10
000075038bddb451  push r11
000075038bddb453  sub rsp, 0xF0
000075038bddb45a  vmovaps [rsp], xmm0
000075038bddb45f  vmovaps [rsp+0x10], xmm1
000075038bddb465  vmovaps [rsp+0x20], xmm2
000075038bddb46b  vmovaps [rsp+0x30], xmm3
000075038bddb471  vmovaps [rsp+0x40], xmm4
000075038bddb477  vmovaps [rsp+0x50], xmm6
000075038bddb47d  vmovaps [rsp+0x60], xmm7
000075038bddb483  vmovaps [rsp+0x70], xmm8
000075038bddb489  vmovaps [rsp+0x80], xmm9
000075038bddb492  vmovaps [rsp+0x90], xmm10
000075038bddb49b  vmovaps [rsp+0xA0], xmm11
000075038bddb4a4  vmovaps [rsp+0xB0], xmm12
000075038bddb4ad  vmovaps [rsp+0xC0], xmm13
000075038bddb4b6  vmovaps [rsp+0xD0], xmm14
000075038bddb4bf  vmovaps [rsp+0xE0], xmm15
000075038bddb4c8  sub rsp, 0x30
000075038bddb4cc  movaps [rsp], xmm5
000075038bddb4d0  movaps [rsp+0x10], xmm6
000075038bddb4d5  movaps [rsp+0x20], xmm3
000075038bddb4da  lea rdi, [rsp]
000075038bddb4de  mov esi, 0x00
000075038bddb4e3  mov rax, 0x56ADB4492530
000075038bddb4ed  call rax
000075038bddb4ef  movaps xmm5, [rsp]
000075038bddb4f3  add rsp, 0x30
000075038bddb4f7  vmovaps xmm0, [rsp]
000075038bddb4fc  vmovaps xmm1, [rsp+0x10]
000075038bddb502  vmovaps xmm2, [rsp+0x20]
000075038bddb508  vmovaps xmm3, [rsp+0x30]
000075038bddb50e  vmovaps xmm4, [rsp+0x40]
000075038bddb514  vmovaps xmm6, [rsp+0x50]
000075038bddb51a  vmovaps xmm7, [rsp+0x60]
000075038bddb520  vmovaps xmm8, [rsp+0x70]
000075038bddb526  vmovaps xmm9, [rsp+0x80]
000075038bddb52f  vmovaps xmm10, [rsp+0x90]
000075038bddb538  vmovaps xmm11, [rsp+0xA0]
000075038bddb541  vmovaps xmm12, [rsp+0xB0]
000075038bddb54a  vmovaps xmm13, [rsp+0xC0]
000075038bddb553  vmovaps xmm14, [rsp+0xD0]
000075038bddb55c  vmovaps xmm15, [rsp+0xE0]
000075038bddb565  add rsp, 0xF0
000075038bddb56c  pop r11
000075038bddb56e  pop r10
000075038bddb570  pop r9
000075038bddb572  pop r8
000075038bddb574  pop rsi
000075038bddb575  pop rdi
000075038bddb576  pop rdx
000075038bddb577  pop rcx
000075038bddb578  pop rax
000075038bddb579  add rsp, 0x08
000075038bddb57d  jmp 0x000075038BDD9167
000075038bddb582  sub rsp, 0x08
000075038bddb586  push rax
000075038bddb587  push rcx
000075038bddb588  push rdx
000075038bddb589  push rdi
000075038bddb58a  push rsi
000075038bddb58b  push r8
000075038bddb58d  push r9
000075038bddb58f  push r10
000075038bddb591  push r11
000075038bddb593  sub rsp, 0xF0
000075038bddb59a  vmovaps [rsp], xmm0
000075038bddb59f  vmovaps [rsp+0x10], xmm1
000075038bddb5a5  vmovaps [rsp+0x20], xmm2
000075038bddb5ab  vmovaps [rsp+0x30], xmm3
000075038bddb5b1  vmovaps [rsp+0x40], xmm4
000075038bddb5b7  vmovaps [rsp+0x50], xmm5
000075038bddb5bd  vmovaps [rsp+0x60], xmm7
000075038bddb5c3  vmovaps [rsp+0x70], xmm8
000075038bddb5c9  vmovaps [rsp+0x80], xmm9
000075038bddb5d2  vmovaps [rsp+0x90], xmm10
000075038bddb5db  vmovaps [rsp+0xA0], xmm11
000075038bddb5e4  vmovaps [rsp+0xB0], xmm12
000075038bddb5ed  vmovaps [rsp+0xC0], xmm13
000075038bddb5f6  vmovaps [rsp+0xD0], xmm14
000075038bddb5ff  vmovaps [rsp+0xE0], xmm15
000075038bddb608  sub rsp, 0x30
000075038bddb60c  movaps [rsp], xmm6
000075038bddb610  movaps [rsp+0x10], xmm9
000075038bddb616  movaps [rsp+0x20], xmm1
000075038bddb61b  lea rdi, [rsp]
000075038bddb61f  mov esi, 0x00
000075038bddb624  mov rax, 0x56ADB4492530
000075038bddb62e  call rax
000075038bddb630  movaps xmm6, [rsp]
000075038bddb634  add rsp, 0x30
000075038bddb638  vmovaps xmm0, [rsp]
000075038bddb63d  vmovaps xmm1, [rsp+0x10]
000075038bddb643  vmovaps xmm2, [rsp+0x20]
000075038bddb649  vmovaps xmm3, [rsp+0x30]
000075038bddb64f  vmovaps xmm4, [rsp+0x40]
000075038bddb655  vmovaps xmm5, [rsp+0x50]
000075038bddb65b  vmovaps xmm7, [rsp+0x60]
000075038bddb661  vmovaps xmm8, [rsp+0x70]
000075038bddb667  vmovaps xmm9, [rsp+0x80]
000075038bddb670  vmovaps xmm10, [rsp+0x90]
000075038bddb679  vmovaps xmm11, [rsp+0xA0]
000075038bddb682  vmovaps xmm12, [rsp+0xB0]
000075038bddb68b  vmovaps xmm13, [rsp+0xC0]
000075038bddb694  vmovaps xmm14, [rsp+0xD0]
000075038bddb69d  vmovaps xmm15, [rsp+0xE0]
000075038bddb6a6  add rsp, 0xF0
000075038bddb6ad  pop r11
000075038bddb6af  pop r10
000075038bddb6b1  pop r9
000075038bddb6b3  pop r8
000075038bddb6b5  pop rsi
000075038bddb6b6  pop rdi
000075038bddb6b7  pop rdx
000075038bddb6b8  pop rcx
000075038bddb6b9  pop rax
000075038bddb6ba  add rsp, 0x08
000075038bddb6be  jmp 0x000075038BDD918B
000075038bddb6c3  sub rsp, 0x08
000075038bddb6c7  push rax
000075038bddb6c8  push rcx
000075038bddb6c9  push rdx
000075038bddb6ca  push rdi
000075038bddb6cb  push rsi
000075038bddb6cc  push r8
000075038bddb6ce  push r9
000075038bddb6d0  push r10
000075038bddb6d2  push r11
000075038bddb6d4  sub rsp, 0xF0
000075038bddb6db  vmovaps [rsp], xmm0
000075038bddb6e0  vmovaps [rsp+0x10], xmm1
000075038bddb6e6  vmovaps [rsp+0x20], xmm2
000075038bddb6ec  vmovaps [rsp+0x30], xmm3
000075038bddb6f2  vmovaps [rsp+0x40], xmm4
000075038bddb6f8  vmovaps [rsp+0x50], xmm5
000075038bddb6fe  vmovaps [rsp+0x60], xmm6
000075038bddb704  vmovaps [rsp+0x70], xmm7
000075038bddb70a  vmovaps [rsp+0x80], xmm8
000075038bddb713  vmovaps [rsp+0x90], xmm10
000075038bddb71c  vmovaps [rsp+0xA0], xmm11
000075038bddb725  vmovaps [rsp+0xB0], xmm12
000075038bddb72e  vmovaps [rsp+0xC0], xmm13
000075038bddb737  vmovaps [rsp+0xD0], xmm14
000075038bddb740  vmovaps [rsp+0xE0], xmm15
000075038bddb749  sub rsp, 0x30
000075038bddb74d  movaps [rsp], xmm9
000075038bddb752  movaps [rsp+0x10], xmm3
000075038bddb757  movaps [rsp+0x20], xmm1
000075038bddb75c  lea rdi, [rsp]
000075038bddb760  mov esi, 0x00
000075038bddb765  mov rax, 0x56ADB4492530
000075038bddb76f  call rax
000075038bddb771  movaps xmm9, [rsp]
000075038bddb776  add rsp, 0x30
000075038bddb77a  vmovaps xmm0, [rsp]
000075038bddb77f  vmovaps xmm1, [rsp+0x10]
000075038bddb785  vmovaps xmm2, [rsp+0x20]
000075038bddb78b  vmovaps xmm3, [rsp+0x30]
000075038bddb791  vmovaps xmm4, [rsp+0x40]
000075038bddb797  vmovaps xmm5, [rsp+0x50]
000075038bddb79d  vmovaps xmm6, [rsp+0x60]
000075038bddb7a3  vmovaps xmm7, [rsp+0x70]
000075038bddb7a9  vmovaps xmm8, [rsp+0x80]
000075038bddb7b2  vmovaps xmm10, [rsp+0x90]
000075038bddb7bb  vmovaps xmm11, [rsp+0xA0]
000075038bddb7c4  vmovaps xmm12, [rsp+0xB0]
000075038bddb7cd  vmovaps xmm13, [rsp+0xC0]
000075038bddb7d6  vmovaps xmm14, [rsp+0xD0]
000075038bddb7df  vmovaps xmm15, [rsp+0xE0]
000075038bddb7e8  add rsp, 0xF0
000075038bddb7ef  pop r11
000075038bddb7f1  pop r10
000075038bddb7f3  pop r9
000075038bddb7f5  pop r8
000075038bddb7f7  pop rsi
000075038bddb7f8  pop rdi
000075038bddb7f9  pop rdx
000075038bddb7fa  pop rcx
000075038bddb7fb  pop rax
000075038bddb7fc  add rsp, 0x08
000075038bddb800  jmp 0x000075038BDD91D7
000075038bddb805  call 0x000075038BCD64F0
000075038bddb80a  jmp 0x000075038BDD91E4
000075038bddb80f  sub rsp, 0x08
000075038bddb813  push rax
000075038bddb814  push rcx
000075038bddb815  push rdx
000075038bddb816  push rdi
000075038bddb817  push rsi
000075038bddb818  push r8
000075038bddb81a  push r9
000075038bddb81c  push r10
000075038bddb81e  push r11
000075038bddb820  sub rsp, 0xF0
000075038bddb827  vmovaps [rsp], xmm0
000075038bddb82c  vmovaps [rsp+0x10], xmm1
000075038bddb832  vmovaps [rsp+0x20], xmm2
000075038bddb838  vmovaps [rsp+0x30], xmm3
000075038bddb83e  vmovaps [rsp+0x40], xmm4
000075038bddb844  vmovaps [rsp+0x50], xmm5
000075038bddb84a  vmovaps [rsp+0x60], xmm6
000075038bddb850  vmovaps [rsp+0x70], xmm7
000075038bddb856  vmovaps [rsp+0x80], xmm8
000075038bddb85f  vmovaps [rsp+0x90], xmm9
000075038bddb868  vmovaps [rsp+0xA0], xmm10
000075038bddb871  vmovaps [rsp+0xB0], xmm11
000075038bddb87a  vmovaps [rsp+0xC0], xmm12
000075038bddb883  vmovaps [rsp+0xD0], xmm13
000075038bddb88c  vmovaps [rsp+0xE0], xmm14
000075038bddb895  sub rsp, 0x30
000075038bddb899  movaps [rsp], xmm15
000075038bddb89e  movaps [rsp+0x10], xmm3
000075038bddb8a3  movaps [rsp+0x20], xmm7
000075038bddb8a8  lea rdi, [rsp]
000075038bddb8ac  mov esi, 0x00
000075038bddb8b1  mov rax, 0x56ADB4492530
000075038bddb8bb  call rax
000075038bddb8bd  movaps xmm15, [rsp]
000075038bddb8c2  add rsp, 0x30
000075038bddb8c6  vmovaps xmm0, [rsp]
000075038bddb8cb  vmovaps xmm1, [rsp+0x10]
000075038bddb8d1  vmovaps xmm2, [rsp+0x20]
000075038bddb8d7  vmovaps xmm3, [rsp+0x30]
000075038bddb8dd  vmovaps xmm4, [rsp+0x40]
000075038bddb8e3  vmovaps xmm5, [rsp+0x50]
000075038bddb8e9  vmovaps xmm6, [rsp+0x60]
000075038bddb8ef  vmovaps xmm7, [rsp+0x70]
000075038bddb8f5  vmovaps xmm8, [rsp+0x80]
000075038bddb8fe  vmovaps xmm9, [rsp+0x90]
000075038bddb907  vmovaps xmm10, [rsp+0xA0]
000075038bddb910  vmovaps xmm11, [rsp+0xB0]
000075038bddb919  vmovaps xmm12, [rsp+0xC0]
000075038bddb922  vmovaps xmm13, [rsp+0xD0]
000075038bddb92b  vmovaps xmm14, [rsp+0xE0]
000075038bddb934  add rsp, 0xF0
000075038bddb93b  pop r11
000075038bddb93d  pop r10
000075038bddb93f  pop r9
000075038bddb941  pop r8
000075038bddb943  pop rsi
000075038bddb944  pop rdi
000075038bddb945  pop rdx
000075038bddb946  pop rcx
000075038bddb947  pop rax
000075038bddb948  add rsp, 0x08
000075038bddb94c  jmp 0x000075038BDD9210
000075038bddb951  sub rsp, 0x08
000075038bddb955  push rax
000075038bddb956  push rcx
000075038bddb957  push rdx
000075038bddb958  push rdi
000075038bddb959  push rsi
000075038bddb95a  push r8
000075038bddb95c  push r9
000075038bddb95e  push r10
000075038bddb960  push r11
000075038bddb962  sub rsp, 0xF0
000075038bddb969  vmovaps [rsp], xmm0
000075038bddb96e  vmovaps [rsp+0x10], xmm1
000075038bddb974  vmovaps [rsp+0x20], xmm2
000075038bddb97a  vmovaps [rsp+0x30], xmm4
000075038bddb980  vmovaps [rsp+0x40], xmm5
000075038bddb986  vmovaps [rsp+0x50], xmm6
000075038bddb98c  vmovaps [rsp+0x60], xmm7
000075038bddb992  vmovaps [rsp+0x70], xmm8
000075038bddb998  vmovaps [rsp+0x80], xmm9
000075038bddb9a1  vmovaps [rsp+0x90], xmm10
000075038bddb9aa  vmovaps [rsp+0xA0], xmm11
000075038bddb9b3  vmovaps [rsp+0xB0], xmm12
000075038bddb9bc  vmovaps [rsp+0xC0], xmm13
000075038bddb9c5  vmovaps [rsp+0xD0], xmm14
000075038bddb9ce  vmovaps [rsp+0xE0], xmm15
000075038bddb9d7  sub rsp, 0x30
000075038bddb9db  movaps [rsp], xmm3
000075038bddb9df  movaps [rsp+0x10], xmm1
000075038bddb9e4  movaps [rsp+0x20], xmm15
000075038bddb9ea  lea rdi, [rsp]
000075038bddb9ee  mov esi, 0x00
000075038bddb9f3  mov rax, 0x56ADB4492530
000075038bddb9fd  call rax
000075038bddb9ff  movaps xmm3, [rsp]
000075038bddba03  add rsp, 0x30
000075038bddba07  vmovaps xmm0, [rsp]
000075038bddba0c  vmovaps xmm1, [rsp+0x10]
000075038bddba12  vmovaps xmm2, [rsp+0x20]
000075038bddba18  vmovaps xmm4, [rsp+0x30]
000075038bddba1e  vmovaps xmm5, [rsp+0x40]
000075038bddba24  vmovaps xmm6, [rsp+0x50]
000075038bddba2a  vmovaps xmm7, [rsp+0x60]
000075038bddba30  vmovaps xmm8, [rsp+0x70]
000075038bddba36  vmovaps xmm9, [rsp+0x80]
000075038bddba3f  vmovaps xmm10, [rsp+0x90]
000075038bddba48  vmovaps xmm11, [rsp+0xA0]
000075038bddba51  vmovaps xmm12, [rsp+0xB0]
000075038bddba5a  vmovaps xmm13, [rsp+0xC0]
000075038bddba63  vmovaps xmm14, [rsp+0xD0]
000075038bddba6c  vmovaps xmm15, [rsp+0xE0]
000075038bddba75  add rsp, 0xF0
000075038bddba7c  pop r11
000075038bddba7e  pop r10
000075038bddba80  pop r9
000075038bddba82  pop r8
000075038bddba84  pop rsi
000075038bddba85  pop rdi
000075038bddba86  pop rdx
000075038bddba87  pop rcx
000075038bddba88  pop rax
000075038bddba89  add rsp, 0x08
000075038bddba8d  jmp 0x000075038BDD929F
000075038bddba92  call 0x000075038BCD64F0
000075038bddba97  jmp 0x000075038BDD92A9
000075038bddba9c  sub rsp, 0x08
000075038bddbaa0  push rax
000075038bddbaa1  push rcx
000075038bddbaa2  push rdx
000075038bddbaa3  push rdi
000075038bddbaa4  push rsi
000075038bddbaa5  push r8
000075038bddbaa7  push r9
000075038bddbaa9  push r10
000075038bddbaab  push r11
000075038bddbaad  sub rsp, 0xF0
000075038bddbab4  vmovaps [rsp], xmm0
000075038bddbab9  vmovaps [rsp+0x10], xmm1
000075038bddbabf  vmovaps [rsp+0x20], xmm2
000075038bddbac5  vmovaps [rsp+0x30], xmm3
000075038bddbacb  vmovaps [rsp+0x40], xmm4
000075038bddbad1  vmovaps [rsp+0x50], xmm5
000075038bddbad7  vmovaps [rsp+0x60], xmm6
000075038bddbadd  vmovaps [rsp+0x70], xmm7
000075038bddbae3  vmovaps [rsp+0x80], xmm8
000075038bddbaec  vmovaps [rsp+0x90], xmm9
000075038bddbaf5  vmovaps [rsp+0xA0], xmm10
000075038bddbafe  vmovaps [rsp+0xB0], xmm11
000075038bddbb07  vmovaps [rsp+0xC0], xmm12
000075038bddbb10  vmovaps [rsp+0xD0], xmm13
000075038bddbb19  vmovaps [rsp+0xE0], xmm14
000075038bddbb22  sub rsp, 0x30
000075038bddbb26  movaps [rsp], xmm15
000075038bddbb2b  movaps [rsp+0x10], xmm14
000075038bddbb31  movaps [rsp+0x20], xmm4
000075038bddbb36  lea rdi, [rsp]
000075038bddbb3a  mov esi, 0x00
000075038bddbb3f  mov rax, 0x56ADB4492530
000075038bddbb49  call rax
000075038bddbb4b  movaps xmm15, [rsp]
000075038bddbb50  add rsp, 0x30
000075038bddbb54  vmovaps xmm0, [rsp]
000075038bddbb59  vmovaps xmm1, [rsp+0x10]
000075038bddbb5f  vmovaps xmm2, [rsp+0x20]
000075038bddbb65  vmovaps xmm3, [rsp+0x30]
000075038bddbb6b  vmovaps xmm4, [rsp+0x40]
000075038bddbb71  vmovaps xmm5, [rsp+0x50]
000075038bddbb77  vmovaps xmm6, [rsp+0x60]
000075038bddbb7d  vmovaps xmm7, [rsp+0x70]
000075038bddbb83  vmovaps xmm8, [rsp+0x80]
000075038bddbb8c  vmovaps xmm9, [rsp+0x90]
000075038bddbb95  vmovaps xmm10, [rsp+0xA0]
000075038bddbb9e  vmovaps xmm11, [rsp+0xB0]
000075038bddbba7  vmovaps xmm12, [rsp+0xC0]
000075038bddbbb0  vmovaps xmm13, [rsp+0xD0]
000075038bddbbb9  vmovaps xmm14, [rsp+0xE0]
000075038bddbbc2  add rsp, 0xF0
000075038bddbbc9  pop r11
000075038bddbbcb  pop r10
000075038bddbbcd  pop r9
000075038bddbbcf  pop r8
000075038bddbbd1  pop rsi
000075038bddbbd2  pop rdi
000075038bddbbd3  pop rdx
000075038bddbbd4  pop rcx
000075038bddbbd5  pop rax
000075038bddbbd6  add rsp, 0x08
000075038bddbbda  jmp 0x000075038BDD92D7
000075038bddbbdf  sub rsp, 0x08
000075038bddbbe3  push rax
000075038bddbbe4  push rcx
000075038bddbbe5  push rdx
000075038bddbbe6  push rdi
000075038bddbbe7  push rsi
000075038bddbbe8  push r8
000075038bddbbea  push r9
000075038bddbbec  push r10
000075038bddbbee  push r11
000075038bddbbf0  sub rsp, 0xF0
000075038bddbbf7  vmovaps [rsp], xmm0
000075038bddbbfc  vmovaps [rsp+0x10], xmm1
000075038bddbc02  vmovaps [rsp+0x20], xmm2
000075038bddbc08  vmovaps [rsp+0x30], xmm3
000075038bddbc0e  vmovaps [rsp+0x40], xmm4
000075038bddbc14  vmovaps [rsp+0x50], xmm5
000075038bddbc1a  vmovaps [rsp+0x60], xmm6
000075038bddbc20  vmovaps [rsp+0x70], xmm7
000075038bddbc26  vmovaps [rsp+0x80], xmm8
000075038bddbc2f  vmovaps [rsp+0x90], xmm9
000075038bddbc38  vmovaps [rsp+0xA0], xmm10
000075038bddbc41  vmovaps [rsp+0xB0], xmm11
000075038bddbc4a  vmovaps [rsp+0xC0], xmm12
000075038bddbc53  vmovaps [rsp+0xD0], xmm13
000075038bddbc5c  vmovaps [rsp+0xE0], xmm15
000075038bddbc65  sub rsp, 0x30
000075038bddbc69  movaps [rsp], xmm14
000075038bddbc6e  movaps [rsp+0x10], xmm2
000075038bddbc73  movaps [rsp+0x20], xmm1
000075038bddbc78  lea rdi, [rsp]
000075038bddbc7c  mov esi, 0x00
000075038bddbc81  mov rax, 0x56ADB4492530
000075038bddbc8b  call rax
000075038bddbc8d  movaps xmm14, [rsp]
000075038bddbc92  add rsp, 0x30
000075038bddbc96  vmovaps xmm0, [rsp]
000075038bddbc9b  vmovaps xmm1, [rsp+0x10]
000075038bddbca1  vmovaps xmm2, [rsp+0x20]
000075038bddbca7  vmovaps xmm3, [rsp+0x30]
000075038bddbcad  vmovaps xmm4, [rsp+0x40]
000075038bddbcb3  vmovaps xmm5, [rsp+0x50]
000075038bddbcb9  vmovaps xmm6, [rsp+0x60]
000075038bddbcbf  vmovaps xmm7, [rsp+0x70]
000075038bddbcc5  vmovaps xmm8, [rsp+0x80]
000075038bddbcce  vmovaps xmm9, [rsp+0x90]
000075038bddbcd7  vmovaps xmm10, [rsp+0xA0]
000075038bddbce0  vmovaps xmm11, [rsp+0xB0]
000075038bddbce9  vmovaps xmm12, [rsp+0xC0]
000075038bddbcf2  vmovaps xmm13, [rsp+0xD0]
000075038bddbcfb  vmovaps xmm15, [rsp+0xE0]
000075038bddbd04  add rsp, 0xF0
000075038bddbd0b  pop r11
000075038bddbd0d  pop r10
000075038bddbd0f  pop r9
000075038bddbd11  pop r8
000075038bddbd13  pop rsi
000075038bddbd14  pop rdi
000075038bddbd15  pop rdx
000075038bddbd16  pop rcx
000075038bddbd17  pop rax
000075038bddbd18  add rsp, 0x08
000075038bddbd1c  jmp 0x000075038BDD92FD
000075038bddbd21  sub rsp, 0x08
000075038bddbd25  push rax
000075038bddbd26  push rcx
000075038bddbd27  push rdx
000075038bddbd28  push rdi
000075038bddbd29  push rsi
000075038bddbd2a  push r8
000075038bddbd2c  push r9
000075038bddbd2e  push r10
000075038bddbd30  push r11
000075038bddbd32  sub rsp, 0xF0
000075038bddbd39  vmovaps [rsp], xmm0
000075038bddbd3e  vmovaps [rsp+0x10], xmm2
000075038bddbd44  vmovaps [rsp+0x20], xmm3
000075038bddbd4a  vmovaps [rsp+0x30], xmm4
000075038bddbd50  vmovaps [rsp+0x40], xmm5
000075038bddbd56  vmovaps [rsp+0x50], xmm6
000075038bddbd5c  vmovaps [rsp+0x60], xmm7
000075038bddbd62  vmovaps [rsp+0x70], xmm8
000075038bddbd68  vmovaps [rsp+0x80], xmm9
000075038bddbd71  vmovaps [rsp+0x90], xmm10
000075038bddbd7a  vmovaps [rsp+0xA0], xmm11
000075038bddbd83  vmovaps [rsp+0xB0], xmm12
000075038bddbd8c  vmovaps [rsp+0xC0], xmm13
000075038bddbd95  vmovaps [rsp+0xD0], xmm14
000075038bddbd9e  vmovaps [rsp+0xE0], xmm15
000075038bddbda7  sub rsp, 0x30
000075038bddbdab  movaps [rsp], xmm1
000075038bddbdaf  movaps [rsp+0x10], xmm4
000075038bddbdb4  movaps [rsp+0x20], xmm9
000075038bddbdba  lea rdi, [rsp]
000075038bddbdbe  mov esi, 0x00
000075038bddbdc3  mov rax, 0x56ADB4492530
000075038bddbdcd  call rax
000075038bddbdcf  movaps xmm1, [rsp]
000075038bddbdd3  add rsp, 0x30
000075038bddbdd7  vmovaps xmm0, [rsp]
000075038bddbddc  vmovaps xmm2, [rsp+0x10]
000075038bddbde2  vmovaps xmm3, [rsp+0x20]
000075038bddbde8  vmovaps xmm4, [rsp+0x30]
000075038bddbdee  vmovaps xmm5, [rsp+0x40]
000075038bddbdf4  vmovaps xmm6, [rsp+0x50]
000075038bddbdfa  vmovaps xmm7, [rsp+0x60]
000075038bddbe00  vmovaps xmm8, [rsp+0x70]
000075038bddbe06  vmovaps xmm9, [rsp+0x80]
000075038bddbe0f  vmovaps xmm10, [rsp+0x90]
000075038bddbe18  vmovaps xmm11, [rsp+0xA0]
000075038bddbe21  vmovaps xmm12, [rsp+0xB0]
000075038bddbe2a  vmovaps xmm13, [rsp+0xC0]
000075038bddbe33  vmovaps xmm14, [rsp+0xD0]
000075038bddbe3c  vmovaps xmm15, [rsp+0xE0]
000075038bddbe45  add rsp, 0xF0
000075038bddbe4c  pop r11
000075038bddbe4e  pop r10
000075038bddbe50  pop r9
000075038bddbe52  pop r8
000075038bddbe54  pop rsi
000075038bddbe55  pop rdi
000075038bddbe56  pop rdx
000075038bddbe57  pop rcx
000075038bddbe58  pop rax
000075038bddbe59  add rsp, 0x08
000075038bddbe5d  jmp 0x000075038BDD931B
000075038bddbe62  sub rsp, 0x08
000075038bddbe66  push rax
000075038bddbe67  push rcx
000075038bddbe68  push rdx
000075038bddbe69  push rdi
000075038bddbe6a  push rsi
000075038bddbe6b  push r8
000075038bddbe6d  push r9
000075038bddbe6f  push r10
000075038bddbe71  push r11
000075038bddbe73  sub rsp, 0xF0
000075038bddbe7a  vmovaps [rsp], xmm0
000075038bddbe7f  vmovaps [rsp+0x10], xmm1
000075038bddbe85  vmovaps [rsp+0x20], xmm2
000075038bddbe8b  vmovaps [rsp+0x30], xmm3
000075038bddbe91  vmovaps [rsp+0x40], xmm5
000075038bddbe97  vmovaps [rsp+0x50], xmm6
000075038bddbe9d  vmovaps [rsp+0x60], xmm7
000075038bddbea3  vmovaps [rsp+0x70], xmm8
000075038bddbea9  vmovaps [rsp+0x80], xmm9
000075038bddbeb2  vmovaps [rsp+0x90], xmm10
000075038bddbebb  vmovaps [rsp+0xA0], xmm11
000075038bddbec4  vmovaps [rsp+0xB0], xmm12
000075038bddbecd  vmovaps [rsp+0xC0], xmm13
000075038bddbed6  vmovaps [rsp+0xD0], xmm14
000075038bddbedf  vmovaps [rsp+0xE0], xmm15
000075038bddbee8  sub rsp, 0x30
000075038bddbeec  movaps [rsp], xmm4
000075038bddbef0  movaps [rsp+0x10], xmm2
000075038bddbef5  movaps [rsp+0x20], xmm9
000075038bddbefb  lea rdi, [rsp]
000075038bddbeff  mov esi, 0x00
000075038bddbf04  mov rax, 0x56ADB4492530
000075038bddbf0e  call rax
000075038bddbf10  movaps xmm4, [rsp]
000075038bddbf14  add rsp, 0x30
000075038bddbf18  vmovaps xmm0, [rsp]
000075038bddbf1d  vmovaps xmm1, [rsp+0x10]
000075038bddbf23  vmovaps xmm2, [rsp+0x20]
000075038bddbf29  vmovaps xmm3, [rsp+0x30]
000075038bddbf2f  vmovaps xmm5, [rsp+0x40]
000075038bddbf35  vmovaps xmm6, [rsp+0x50]
000075038bddbf3b  vmovaps xmm7, [rsp+0x60]
000075038bddbf41  vmovaps xmm8, [rsp+0x70]
000075038bddbf47  vmovaps xmm9, [rsp+0x80]
000075038bddbf50  vmovaps xmm10, [rsp+0x90]
000075038bddbf59  vmovaps xmm11, [rsp+0xA0]
000075038bddbf62  vmovaps xmm12, [rsp+0xB0]
000075038bddbf6b  vmovaps xmm13, [rsp+0xC0]
000075038bddbf74  vmovaps xmm14, [rsp+0xD0]
000075038bddbf7d  vmovaps xmm15, [rsp+0xE0]
000075038bddbf86  add rsp, 0xF0
000075038bddbf8d  pop r11
000075038bddbf8f  pop r10
000075038bddbf91  pop r9
000075038bddbf93  pop r8
000075038bddbf95  pop rsi
000075038bddbf96  pop rdi
000075038bddbf97  pop rdx
000075038bddbf98  pop rcx
000075038bddbf99  pop rax
000075038bddbf9a  add rsp, 0x08
000075038bddbf9e  jmp 0x000075038BDD934B
000075038bddbfa3  sub rsp, 0x08
000075038bddbfa7  push rax
000075038bddbfa8  push rcx
000075038bddbfa9  push rdx
000075038bddbfaa  push rdi
000075038bddbfab  push rsi
000075038bddbfac  push r8
000075038bddbfae  push r9
000075038bddbfb0  push r10
000075038bddbfb2  push r11
000075038bddbfb4  sub rsp, 0xF0
000075038bddbfbb  vmovaps [rsp], xmm0
000075038bddbfc0  vmovaps [rsp+0x10], xmm1
000075038bddbfc6  vmovaps [rsp+0x20], xmm2
000075038bddbfcc  vmovaps [rsp+0x30], xmm3
000075038bddbfd2  vmovaps [rsp+0x40], xmm4
000075038bddbfd8  vmovaps [rsp+0x50], xmm5
000075038bddbfde  vmovaps [rsp+0x60], xmm6
000075038bddbfe4  vmovaps [rsp+0x70], xmm7
000075038bddbfea  vmovaps [rsp+0x80], xmm8
000075038bddbff3  vmovaps [rsp+0x90], xmm10
000075038bddbffc  vmovaps [rsp+0xA0], xmm11
000075038bddc005  vmovaps [rsp+0xB0], xmm12
000075038bddc00e  vmovaps [rsp+0xC0], xmm13
000075038bddc017  vmovaps [rsp+0xD0], xmm14
000075038bddc020  vmovaps [rsp+0xE0], xmm15
000075038bddc029  sub rsp, 0x30
000075038bddc02d  movaps [rsp], xmm9
000075038bddc032  movaps [rsp+0x10], xmm2
000075038bddc037  movaps [rsp+0x20], xmm1
000075038bddc03c  lea rdi, [rsp]
000075038bddc040  mov esi, 0x00
000075038bddc045  mov rax, 0x56ADB4492530
000075038bddc04f  call rax
000075038bddc051  movaps xmm9, [rsp]
000075038bddc056  add rsp, 0x30
000075038bddc05a  vmovaps xmm0, [rsp]
000075038bddc05f  vmovaps xmm1, [rsp+0x10]
000075038bddc065  vmovaps xmm2, [rsp+0x20]
000075038bddc06b  vmovaps xmm3, [rsp+0x30]
000075038bddc071  vmovaps xmm4, [rsp+0x40]
000075038bddc077  vmovaps xmm5, [rsp+0x50]
000075038bddc07d  vmovaps xmm6, [rsp+0x60]
000075038bddc083  vmovaps xmm7, [rsp+0x70]
000075038bddc089  vmovaps xmm8, [rsp+0x80]
000075038bddc092  vmovaps xmm10, [rsp+0x90]
000075038bddc09b  vmovaps xmm11, [rsp+0xA0]
000075038bddc0a4  vmovaps xmm12, [rsp+0xB0]
000075038bddc0ad  vmovaps xmm13, [rsp+0xC0]
000075038bddc0b6  vmovaps xmm14, [rsp+0xD0]
000075038bddc0bf  vmovaps xmm15, [rsp+0xE0]
000075038bddc0c8  add rsp, 0xF0
000075038bddc0cf  pop r11
000075038bddc0d1  pop r10
000075038bddc0d3  pop r9
000075038bddc0d5  pop r8
000075038bddc0d7  pop rsi
000075038bddc0d8  pop rdi
000075038bddc0d9  pop rdx
000075038bddc0da  pop rcx
000075038bddc0db  pop rax
000075038bddc0dc  add rsp, 0x08
000075038bddc0e0  jmp 0x000075038BDD9381
000075038bddc0e5  sub rsp, 0x08
000075038bddc0e9  push rax
000075038bddc0ea  push rcx
000075038bddc0eb  push rdx
000075038bddc0ec  push rdi
000075038bddc0ed  push rsi
000075038bddc0ee  push r8
000075038bddc0f0  push r9
000075038bddc0f2  push r10
000075038bddc0f4  push r11
000075038bddc0f6  sub rsp, 0xF0
000075038bddc0fd  vmovaps [rsp], xmm0
000075038bddc102  vmovaps [rsp+0x10], xmm2
000075038bddc108  vmovaps [rsp+0x20], xmm3
000075038bddc10e  vmovaps [rsp+0x30], xmm4
000075038bddc114  vmovaps [rsp+0x40], xmm5
000075038bddc11a  vmovaps [rsp+0x50], xmm6
000075038bddc120  vmovaps [rsp+0x60], xmm7
000075038bddc126  vmovaps [rsp+0x70], xmm8
000075038bddc12c  vmovaps [rsp+0x80], xmm9
000075038bddc135  vmovaps [rsp+0x90], xmm10
000075038bddc13e  vmovaps [rsp+0xA0], xmm11
000075038bddc147  vmovaps [rsp+0xB0], xmm12
000075038bddc150  vmovaps [rsp+0xC0], xmm13
000075038bddc159  vmovaps [rsp+0xD0], xmm14
000075038bddc162  vmovaps [rsp+0xE0], xmm15
000075038bddc16b  sub rsp, 0x30
000075038bddc16f  movaps [rsp], xmm1
000075038bddc173  movaps [rsp+0x10], xmm15
000075038bddc179  movaps [rsp+0x20], xmm6
000075038bddc17e  lea rdi, [rsp]
000075038bddc182  mov esi, 0x00
000075038bddc187  mov rax, 0x56ADB4492530
000075038bddc191  call rax
000075038bddc193  movaps xmm1, [rsp]
000075038bddc197  add rsp, 0x30
000075038bddc19b  vmovaps xmm0, [rsp]
000075038bddc1a0  vmovaps xmm2, [rsp+0x10]
000075038bddc1a6  vmovaps xmm3, [rsp+0x20]
000075038bddc1ac  vmovaps xmm4, [rsp+0x30]
000075038bddc1b2  vmovaps xmm5, [rsp+0x40]
000075038bddc1b8  vmovaps xmm6, [rsp+0x50]
000075038bddc1be  vmovaps xmm7, [rsp+0x60]
000075038bddc1c4  vmovaps xmm8, [rsp+0x70]
000075038bddc1ca  vmovaps xmm9, [rsp+0x80]
000075038bddc1d3  vmovaps xmm10, [rsp+0x90]
000075038bddc1dc  vmovaps xmm11, [rsp+0xA0]
000075038bddc1e5  vmovaps xmm12, [rsp+0xB0]
000075038bddc1ee  vmovaps xmm13, [rsp+0xC0]
000075038bddc1f7  vmovaps xmm14, [rsp+0xD0]
000075038bddc200  vmovaps xmm15, [rsp+0xE0]
000075038bddc209  add rsp, 0xF0
000075038bddc210  pop r11
000075038bddc212  pop r10
000075038bddc214  pop r9
000075038bddc216  pop r8
000075038bddc218  pop rsi
000075038bddc219  pop rdi
000075038bddc21a  pop rdx
000075038bddc21b  pop rcx
000075038bddc21c  pop rax
000075038bddc21d  add rsp, 0x08
000075038bddc221  jmp 0x000075038BDD93A2
000075038bddc226  sub rsp, 0x08
000075038bddc22a  push rax
000075038bddc22b  push rcx
000075038bddc22c  push rdx
000075038bddc22d  push rdi
000075038bddc22e  push rsi
000075038bddc22f  push r8
000075038bddc231  push r9
000075038bddc233  push r10
000075038bddc235  push r11
000075038bddc237  sub rsp, 0xF0
000075038bddc23e  vmovaps [rsp], xmm0
000075038bddc243  vmovaps [rsp+0x10], xmm1
000075038bddc249  vmovaps [rsp+0x20], xmm2
000075038bddc24f  vmovaps [rsp+0x30], xmm3
000075038bddc255  vmovaps [rsp+0x40], xmm4
000075038bddc25b  vmovaps [rsp+0x50], xmm5
000075038bddc261  vmovaps [rsp+0x60], xmm6
000075038bddc267  vmovaps [rsp+0x70], xmm7
000075038bddc26d  vmovaps [rsp+0x80], xmm8
000075038bddc276  vmovaps [rsp+0x90], xmm9
000075038bddc27f  vmovaps [rsp+0xA0], xmm10
000075038bddc288  vmovaps [rsp+0xB0], xmm11
000075038bddc291  vmovaps [rsp+0xC0], xmm12
000075038bddc29a  vmovaps [rsp+0xD0], xmm13
000075038bddc2a3  vmovaps [rsp+0xE0], xmm14
000075038bddc2ac  sub rsp, 0x30
000075038bddc2b0  movaps [rsp], xmm15
000075038bddc2b5  movaps [rsp+0x10], xmm5
000075038bddc2ba  movaps [rsp+0x20], xmm3
000075038bddc2bf  lea rdi, [rsp]
000075038bddc2c3  mov esi, 0x00
000075038bddc2c8  mov rax, 0x56ADB4492530
000075038bddc2d2  call rax
000075038bddc2d4  movaps xmm15, [rsp]
000075038bddc2d9  add rsp, 0x30
000075038bddc2dd  vmovaps xmm0, [rsp]
000075038bddc2e2  vmovaps xmm1, [rsp+0x10]
000075038bddc2e8  vmovaps xmm2, [rsp+0x20]
000075038bddc2ee  vmovaps xmm3, [rsp+0x30]
000075038bddc2f4  vmovaps xmm4, [rsp+0x40]
000075038bddc2fa  vmovaps xmm5, [rsp+0x50]
000075038bddc300  vmovaps xmm6, [rsp+0x60]
000075038bddc306  vmovaps xmm7, [rsp+0x70]
000075038bddc30c  vmovaps xmm8, [rsp+0x80]
000075038bddc315  vmovaps xmm9, [rsp+0x90]
000075038bddc31e  vmovaps xmm10, [rsp+0xA0]
000075038bddc327  vmovaps xmm11, [rsp+0xB0]
000075038bddc330  vmovaps xmm12, [rsp+0xC0]
000075038bddc339  vmovaps xmm13, [rsp+0xD0]
000075038bddc342  vmovaps xmm14, [rsp+0xE0]
000075038bddc34b  add rsp, 0xF0
000075038bddc352  pop r11
000075038bddc354  pop r10
000075038bddc356  pop r9
000075038bddc358  pop r8
000075038bddc35a  pop rsi
000075038bddc35b  pop rdi
000075038bddc35c  pop rdx
000075038bddc35d  pop rcx
000075038bddc35e  pop rax
000075038bddc35f  add rsp, 0x08
000075038bddc363  jmp 0x000075038BDD93BC
000075038bddc368  sub rsp, 0x08
000075038bddc36c  push rax
000075038bddc36d  push rcx
000075038bddc36e  push rdx
000075038bddc36f  push rdi
000075038bddc370  push rsi
000075038bddc371  push r8
000075038bddc373  push r9
000075038bddc375  push r10
000075038bddc377  push r11
000075038bddc379  sub rsp, 0xF0
000075038bddc380  vmovaps [rsp], xmm0
000075038bddc385  vmovaps [rsp+0x10], xmm1
000075038bddc38b  vmovaps [rsp+0x20], xmm2
000075038bddc391  vmovaps [rsp+0x30], xmm3
000075038bddc397  vmovaps [rsp+0x40], xmm4
000075038bddc39d  vmovaps [rsp+0x50], xmm6
000075038bddc3a3  vmovaps [rsp+0x60], xmm7
000075038bddc3a9  vmovaps [rsp+0x70], xmm8
000075038bddc3af  vmovaps [rsp+0x80], xmm9
000075038bddc3b8  vmovaps [rsp+0x90], xmm10
000075038bddc3c1  vmovaps [rsp+0xA0], xmm11
000075038bddc3ca  vmovaps [rsp+0xB0], xmm12
000075038bddc3d3  vmovaps [rsp+0xC0], xmm13
000075038bddc3dc  vmovaps [rsp+0xD0], xmm14
000075038bddc3e5  vmovaps [rsp+0xE0], xmm15
000075038bddc3ee  sub rsp, 0x30
000075038bddc3f2  movaps [rsp], xmm5
000075038bddc3f6  movaps [rsp+0x10], xmm8
000075038bddc3fc  movaps [rsp+0x20], xmm6
000075038bddc401  lea rdi, [rsp]
000075038bddc405  mov esi, 0x00
000075038bddc40a  mov rax, 0x56ADB4492530
000075038bddc414  call rax
000075038bddc416  movaps xmm5, [rsp]
000075038bddc41a  add rsp, 0x30
000075038bddc41e  vmovaps xmm0, [rsp]
000075038bddc423  vmovaps xmm1, [rsp+0x10]
000075038bddc429  vmovaps xmm2, [rsp+0x20]
000075038bddc42f  vmovaps xmm3, [rsp+0x30]
000075038bddc435  vmovaps xmm4, [rsp+0x40]
000075038bddc43b  vmovaps xmm6, [rsp+0x50]
000075038bddc441  vmovaps xmm7, [rsp+0x60]
000075038bddc447  vmovaps xmm8, [rsp+0x70]
000075038bddc44d  vmovaps xmm9, [rsp+0x80]
000075038bddc456  vmovaps xmm10, [rsp+0x90]
000075038bddc45f  vmovaps xmm11, [rsp+0xA0]
000075038bddc468  vmovaps xmm12, [rsp+0xB0]
000075038bddc471  vmovaps xmm13, [rsp+0xC0]
000075038bddc47a  vmovaps xmm14, [rsp+0xD0]
000075038bddc483  vmovaps xmm15, [rsp+0xE0]
000075038bddc48c  add rsp, 0xF0
000075038bddc493  pop r11
000075038bddc495  pop r10
000075038bddc497  pop r9
000075038bddc499  pop r8
000075038bddc49b  pop rsi
000075038bddc49c  pop rdi
000075038bddc49d  pop rdx
000075038bddc49e  pop rcx
000075038bddc49f  pop rax
000075038bddc4a0  add rsp, 0x08
000075038bddc4a4  jmp 0x000075038BDD93E0
000075038bddc4a9  sub rsp, 0x08
000075038bddc4ad  push rax
000075038bddc4ae  push rcx
000075038bddc4af  push rdx
000075038bddc4b0  push rdi
000075038bddc4b1  push rsi
000075038bddc4b2  push r8
000075038bddc4b4  push r9
000075038bddc4b6  push r10
000075038bddc4b8  push r11
000075038bddc4ba  sub rsp, 0xF0
000075038bddc4c1  vmovaps [rsp], xmm0
000075038bddc4c6  vmovaps [rsp+0x10], xmm1
000075038bddc4cc  vmovaps [rsp+0x20], xmm2
000075038bddc4d2  vmovaps [rsp+0x30], xmm3
000075038bddc4d8  vmovaps [rsp+0x40], xmm4
000075038bddc4de  vmovaps [rsp+0x50], xmm5
000075038bddc4e4  vmovaps [rsp+0x60], xmm7
000075038bddc4ea  vmovaps [rsp+0x70], xmm8
000075038bddc4f0  vmovaps [rsp+0x80], xmm9
000075038bddc4f9  vmovaps [rsp+0x90], xmm10
000075038bddc502  vmovaps [rsp+0xA0], xmm11
000075038bddc50b  vmovaps [rsp+0xB0], xmm12
000075038bddc514  vmovaps [rsp+0xC0], xmm13
000075038bddc51d  vmovaps [rsp+0xD0], xmm14
000075038bddc526  vmovaps [rsp+0xE0], xmm15
000075038bddc52f  sub rsp, 0x30
000075038bddc533  movaps [rsp], xmm6
000075038bddc537  movaps [rsp+0x10], xmm10
000075038bddc53d  movaps [rsp+0x20], xmm8
000075038bddc543  lea rdi, [rsp]
000075038bddc547  mov esi, 0x00
000075038bddc54c  mov rax, 0x56ADB4492530
000075038bddc556  call rax
000075038bddc558  movaps xmm6, [rsp]
000075038bddc55c  add rsp, 0x30
000075038bddc560  vmovaps xmm0, [rsp]
000075038bddc565  vmovaps xmm1, [rsp+0x10]
000075038bddc56b  vmovaps xmm2, [rsp+0x20]
000075038bddc571  vmovaps xmm3, [rsp+0x30]
000075038bddc577  vmovaps xmm4, [rsp+0x40]
000075038bddc57d  vmovaps xmm5, [rsp+0x50]
000075038bddc583  vmovaps xmm7, [rsp+0x60]
000075038bddc589  vmovaps xmm8, [rsp+0x70]
000075038bddc58f  vmovaps xmm9, [rsp+0x80]
000075038bddc598  vmovaps xmm10, [rsp+0x90]
000075038bddc5a1  vmovaps xmm11, [rsp+0xA0]
000075038bddc5aa  vmovaps xmm12, [rsp+0xB0]
000075038bddc5b3  vmovaps xmm13, [rsp+0xC0]
000075038bddc5bc  vmovaps xmm14, [rsp+0xD0]
000075038bddc5c5  vmovaps xmm15, [rsp+0xE0]
000075038bddc5ce  add rsp, 0xF0
000075038bddc5d5  pop r11
000075038bddc5d7  pop r10
000075038bddc5d9  pop r9
000075038bddc5db  pop r8
000075038bddc5dd  pop rsi
000075038bddc5de  pop rdi
000075038bddc5df  pop rdx
000075038bddc5e0  pop rcx
000075038bddc5e1  pop rax
000075038bddc5e2  add rsp, 0x08
000075038bddc5e6  jmp 0x000075038BDD9405
000075038bddc5eb  sub rsp, 0x08
000075038bddc5ef  push rax
000075038bddc5f0  push rcx
000075038bddc5f1  push rdx
000075038bddc5f2  push rdi
000075038bddc5f3  push rsi
000075038bddc5f4  push r8
000075038bddc5f6  push r9
000075038bddc5f8  push r10
000075038bddc5fa  push r11
000075038bddc5fc  sub rsp, 0xF0
000075038bddc603  vmovaps [rsp], xmm0
000075038bddc608  vmovaps [rsp+0x10], xmm1
000075038bddc60e  vmovaps [rsp+0x20], xmm2
000075038bddc614  vmovaps [rsp+0x30], xmm3
000075038bddc61a  vmovaps [rsp+0x40], xmm4
000075038bddc620  vmovaps [rsp+0x50], xmm5
000075038bddc626  vmovaps [rsp+0x60], xmm6
000075038bddc62c  vmovaps [rsp+0x70], xmm7
000075038bddc632  vmovaps [rsp+0x80], xmm8
000075038bddc63b  vmovaps [rsp+0x90], xmm9
000075038bddc644  vmovaps [rsp+0xA0], xmm11
000075038bddc64d  vmovaps [rsp+0xB0], xmm12
000075038bddc656  vmovaps [rsp+0xC0], xmm13
000075038bddc65f  vmovaps [rsp+0xD0], xmm14
000075038bddc668  vmovaps [rsp+0xE0], xmm15
000075038bddc671  sub rsp, 0x30
000075038bddc675  movaps [rsp], xmm10
000075038bddc67a  movaps [rsp+0x10], xmm8
000075038bddc680  movaps [rsp+0x20], xmm14
000075038bddc686  lea rdi, [rsp]
000075038bddc68a  mov esi, 0x00
000075038bddc68f  mov rax, 0x56ADB4492530
000075038bddc699  call rax
000075038bddc69b  movaps xmm10, [rsp]
000075038bddc6a0  add rsp, 0x30
000075038bddc6a4  vmovaps xmm0, [rsp]
000075038bddc6a9  vmovaps xmm1, [rsp+0x10]
000075038bddc6af  vmovaps xmm2, [rsp+0x20]
000075038bddc6b5  vmovaps xmm3, [rsp+0x30]
000075038bddc6bb  vmovaps xmm4, [rsp+0x40]
000075038bddc6c1  vmovaps xmm5, [rsp+0x50]
000075038bddc6c7  vmovaps xmm6, [rsp+0x60]
000075038bddc6cd  vmovaps xmm7, [rsp+0x70]
000075038bddc6d3  vmovaps xmm8, [rsp+0x80]
000075038bddc6dc  vmovaps xmm9, [rsp+0x90]
000075038bddc6e5  vmovaps xmm11, [rsp+0xA0]
000075038bddc6ee  vmovaps xmm12, [rsp+0xB0]
000075038bddc6f7  vmovaps xmm13, [rsp+0xC0]
000075038bddc700  vmovaps xmm14, [rsp+0xD0]
000075038bddc709  vmovaps xmm15, [rsp+0xE0]
000075038bddc712  add rsp, 0xF0
000075038bddc719  pop r11
000075038bddc71b  pop r10
000075038bddc71d  pop r9
000075038bddc71f  pop r8
000075038bddc721  pop rsi
000075038bddc722  pop rdi
000075038bddc723  pop rdx
000075038bddc724  pop rcx
000075038bddc725  pop rax
000075038bddc726  add rsp, 0x08
000075038bddc72a  jmp 0x000075038BDD9425
000075038bddc72f  sub rsp, 0x08
000075038bddc733  push rax
000075038bddc734  push rcx
000075038bddc735  push rdx
000075038bddc736  push rdi
000075038bddc737  push rsi
000075038bddc738  push r8
000075038bddc73a  push r9
000075038bddc73c  push r10
000075038bddc73e  push r11
000075038bddc740  sub rsp, 0xF0
000075038bddc747  vmovaps [rsp], xmm0
000075038bddc74c  vmovaps [rsp+0x10], xmm1
000075038bddc752  vmovaps [rsp+0x20], xmm2
000075038bddc758  vmovaps [rsp+0x30], xmm3
000075038bddc75e  vmovaps [rsp+0x40], xmm4
000075038bddc764  vmovaps [rsp+0x50], xmm5
000075038bddc76a  vmovaps [rsp+0x60], xmm6
000075038bddc770  vmovaps [rsp+0x70], xmm7
000075038bddc776  vmovaps [rsp+0x80], xmm8
000075038bddc77f  vmovaps [rsp+0x90], xmm9
000075038bddc788  vmovaps [rsp+0xA0], xmm10
000075038bddc791  vmovaps [rsp+0xB0], xmm11
000075038bddc79a  vmovaps [rsp+0xC0], xmm12
000075038bddc7a3  vmovaps [rsp+0xD0], xmm13
000075038bddc7ac  vmovaps [rsp+0xE0], xmm15
000075038bddc7b5  sub rsp, 0x30
000075038bddc7b9  movaps [rsp], xmm14
000075038bddc7be  movaps [rsp+0x10], xmm8
000075038bddc7c4  movaps [rsp+0x20], xmm4
000075038bddc7c9  lea rdi, [rsp]
000075038bddc7cd  mov esi, 0x00
000075038bddc7d2  mov rax, 0x56ADB4492530
000075038bddc7dc  call rax
000075038bddc7de  movaps xmm14, [rsp]
000075038bddc7e3  add rsp, 0x30
000075038bddc7e7  vmovaps xmm0, [rsp]
000075038bddc7ec  vmovaps xmm1, [rsp+0x10]
000075038bddc7f2  vmovaps xmm2, [rsp+0x20]
000075038bddc7f8  vmovaps xmm3, [rsp+0x30]
000075038bddc7fe  vmovaps xmm4, [rsp+0x40]
000075038bddc804  vmovaps xmm5, [rsp+0x50]
000075038bddc80a  vmovaps xmm6, [rsp+0x60]
000075038bddc810  vmovaps xmm7, [rsp+0x70]
000075038bddc816  vmovaps xmm8, [rsp+0x80]
000075038bddc81f  vmovaps xmm9, [rsp+0x90]
000075038bddc828  vmovaps xmm10, [rsp+0xA0]
000075038bddc831  vmovaps xmm11, [rsp+0xB0]
000075038bddc83a  vmovaps xmm12, [rsp+0xC0]
000075038bddc843  vmovaps xmm13, [rsp+0xD0]
000075038bddc84c  vmovaps xmm15, [rsp+0xE0]
000075038bddc855  add rsp, 0xF0
000075038bddc85c  pop r11
000075038bddc85e  pop r10
000075038bddc860  pop r9
000075038bddc862  pop r8
000075038bddc864  pop rsi
000075038bddc865  pop rdi
000075038bddc866  pop rdx
000075038bddc867  pop rcx
000075038bddc868  pop rax
000075038bddc869  add rsp, 0x08
000075038bddc86d  jmp 0x000075038BDD9445
000075038bddc872  sub rsp, 0x08
000075038bddc876  push rax
000075038bddc877  push rcx
000075038bddc878  push rdx
000075038bddc879  push rdi
000075038bddc87a  push rsi
000075038bddc87b  push r8
000075038bddc87d  push r9
000075038bddc87f  push r10
000075038bddc881  push r11
000075038bddc883  sub rsp, 0xF0
000075038bddc88a  vmovaps [rsp], xmm0
000075038bddc88f  vmovaps [rsp+0x10], xmm1
000075038bddc895  vmovaps [rsp+0x20], xmm2
000075038bddc89b  vmovaps [rsp+0x30], xmm3
000075038bddc8a1  vmovaps [rsp+0x40], xmm5
000075038bddc8a7  vmovaps [rsp+0x50], xmm6
000075038bddc8ad  vmovaps [rsp+0x60], xmm7
000075038bddc8b3  vmovaps [rsp+0x70], xmm8
000075038bddc8b9  vmovaps [rsp+0x80], xmm9
000075038bddc8c2  vmovaps [rsp+0x90], xmm10
000075038bddc8cb  vmovaps [rsp+0xA0], xmm11
000075038bddc8d4  vmovaps [rsp+0xB0], xmm12
000075038bddc8dd  vmovaps [rsp+0xC0], xmm13
000075038bddc8e6  vmovaps [rsp+0xD0], xmm14
000075038bddc8ef  vmovaps [rsp+0xE0], xmm15
000075038bddc8f8  sub rsp, 0x30
000075038bddc8fc  movaps [rsp], xmm4
000075038bddc900  movaps [rsp+0x10], xmm13
000075038bddc906  movaps [rsp+0x20], xmm8
000075038bddc90c  lea rdi, [rsp]
000075038bddc910  mov esi, 0x00
000075038bddc915  mov rax, 0x56ADB4492530
000075038bddc91f  call rax
000075038bddc921  movaps xmm4, [rsp]
000075038bddc925  add rsp, 0x30
000075038bddc929  vmovaps xmm0, [rsp]
000075038bddc92e  vmovaps xmm1, [rsp+0x10]
000075038bddc934  vmovaps xmm2, [rsp+0x20]
000075038bddc93a  vmovaps xmm3, [rsp+0x30]
000075038bddc940  vmovaps xmm5, [rsp+0x40]
000075038bddc946  vmovaps xmm6, [rsp+0x50]
000075038bddc94c  vmovaps xmm7, [rsp+0x60]
000075038bddc952  vmovaps xmm8, [rsp+0x70]
000075038bddc958  vmovaps xmm9, [rsp+0x80]
000075038bddc961  vmovaps xmm10, [rsp+0x90]
000075038bddc96a  vmovaps xmm11, [rsp+0xA0]
000075038bddc973  vmovaps xmm12, [rsp+0xB0]
000075038bddc97c  vmovaps xmm13, [rsp+0xC0]
000075038bddc985  vmovaps xmm14, [rsp+0xD0]
000075038bddc98e  vmovaps xmm15, [rsp+0xE0]
000075038bddc997  add rsp, 0xF0
000075038bddc99e  pop r11
000075038bddc9a0  pop r10
000075038bddc9a2  pop r9
000075038bddc9a4  pop r8
000075038bddc9a6  pop rsi
000075038bddc9a7  pop rdi
000075038bddc9a8  pop rdx
000075038bddc9a9  pop rcx
000075038bddc9aa  pop rax
000075038bddc9ab  add rsp, 0x08
000075038bddc9af  jmp 0x000075038BDD946A
000075038bddc9b4  sub rsp, 0x08
000075038bddc9b8  push rax
000075038bddc9b9  push rcx
000075038bddc9ba  push rdx
000075038bddc9bb  push rdi
000075038bddc9bc  push rsi
000075038bddc9bd  push r8
000075038bddc9bf  push r9
000075038bddc9c1  push r10
000075038bddc9c3  push r11
000075038bddc9c5  sub rsp, 0xF0
000075038bddc9cc  vmovaps [rsp], xmm0
000075038bddc9d1  vmovaps [rsp+0x10], xmm1
000075038bddc9d7  vmovaps [rsp+0x20], xmm2
000075038bddc9dd  vmovaps [rsp+0x30], xmm3
000075038bddc9e3  vmovaps [rsp+0x40], xmm4
000075038bddc9e9  vmovaps [rsp+0x50], xmm5
000075038bddc9ef  vmovaps [rsp+0x60], xmm6
000075038bddc9f5  vmovaps [rsp+0x70], xmm7
000075038bddc9fb  vmovaps [rsp+0x80], xmm8
000075038bddca04  vmovaps [rsp+0x90], xmm9
000075038bddca0d  vmovaps [rsp+0xA0], xmm10
000075038bddca16  vmovaps [rsp+0xB0], xmm11
000075038bddca1f  vmovaps [rsp+0xC0], xmm12
000075038bddca28  vmovaps [rsp+0xD0], xmm14
000075038bddca31  vmovaps [rsp+0xE0], xmm15
000075038bddca3a  sub rsp, 0x30
000075038bddca3e  movaps [rsp], xmm13
000075038bddca43  movaps [rsp+0x10], xmm15
000075038bddca49  movaps [rsp+0x20], xmm9
000075038bddca4f  lea rdi, [rsp]
000075038bddca53  mov esi, 0x00
000075038bddca58  mov rax, 0x56ADB4492530
000075038bddca62  call rax
000075038bddca64  movaps xmm13, [rsp]
000075038bddca69  add rsp, 0x30
000075038bddca6d  vmovaps xmm0, [rsp]
000075038bddca72  vmovaps xmm1, [rsp+0x10]
000075038bddca78  vmovaps xmm2, [rsp+0x20]
000075038bddca7e  vmovaps xmm3, [rsp+0x30]
000075038bddca84  vmovaps xmm4, [rsp+0x40]
000075038bddca8a  vmovaps xmm5, [rsp+0x50]
000075038bddca90  vmovaps xmm6, [rsp+0x60]
000075038bddca96  vmovaps xmm7, [rsp+0x70]
000075038bddca9c  vmovaps xmm8, [rsp+0x80]
000075038bddcaa5  vmovaps xmm9, [rsp+0x90]
000075038bddcaae  vmovaps xmm10, [rsp+0xA0]
000075038bddcab7  vmovaps xmm11, [rsp+0xB0]
000075038bddcac0  vmovaps xmm12, [rsp+0xC0]
000075038bddcac9  vmovaps xmm14, [rsp+0xD0]
000075038bddcad2  vmovaps xmm15, [rsp+0xE0]
000075038bddcadb  add rsp, 0xF0
000075038bddcae2  pop r11
000075038bddcae4  pop r10
000075038bddcae6  pop r9
000075038bddcae8  pop r8
000075038bddcaea  pop rsi
000075038bddcaeb  pop rdi
000075038bddcaec  pop rdx
000075038bddcaed  pop rcx
000075038bddcaee  pop rax
000075038bddcaef  add rsp, 0x08
000075038bddcaf3  jmp 0x000075038BDD9485
000075038bddcaf8  sub rsp, 0x08
000075038bddcafc  push rax
000075038bddcafd  push rcx
000075038bddcafe  push rdx
000075038bddcaff  push rdi
000075038bddcb00  push rsi
000075038bddcb01  push r8
000075038bddcb03  push r9
000075038bddcb05  push r10
000075038bddcb07  push r11
000075038bddcb09  sub rsp, 0xF0
000075038bddcb10  vmovaps [rsp], xmm0
000075038bddcb15  vmovaps [rsp+0x10], xmm1
000075038bddcb1b  vmovaps [rsp+0x20], xmm2
000075038bddcb21  vmovaps [rsp+0x30], xmm3
000075038bddcb27  vmovaps [rsp+0x40], xmm4
000075038bddcb2d  vmovaps [rsp+0x50], xmm5
000075038bddcb33  vmovaps [rsp+0x60], xmm6
000075038bddcb39  vmovaps [rsp+0x70], xmm7
000075038bddcb3f  vmovaps [rsp+0x80], xmm8
000075038bddcb48  vmovaps [rsp+0x90], xmm9
000075038bddcb51  vmovaps [rsp+0xA0], xmm10
000075038bddcb5a  vmovaps [rsp+0xB0], xmm11
000075038bddcb63  vmovaps [rsp+0xC0], xmm12
000075038bddcb6c  vmovaps [rsp+0xD0], xmm13
000075038bddcb75  vmovaps [rsp+0xE0], xmm14
000075038bddcb7e  sub rsp, 0x30
000075038bddcb82  movaps [rsp], xmm15
000075038bddcb87  movaps [rsp+0x10], xmm1
000075038bddcb8c  movaps [rsp+0x20], xmm5
000075038bddcb91  lea rdi, [rsp]
000075038bddcb95  mov esi, 0x00
000075038bddcb9a  mov rax, 0x56ADB4492530
000075038bddcba4  call rax
000075038bddcba6  movaps xmm15, [rsp]
000075038bddcbab  add rsp, 0x30
000075038bddcbaf  vmovaps xmm0, [rsp]
000075038bddcbb4  vmovaps xmm1, [rsp+0x10]
000075038bddcbba  vmovaps xmm2, [rsp+0x20]
000075038bddcbc0  vmovaps xmm3, [rsp+0x30]
000075038bddcbc6  vmovaps xmm4, [rsp+0x40]
000075038bddcbcc  vmovaps xmm5, [rsp+0x50]
000075038bddcbd2  vmovaps xmm6, [rsp+0x60]
000075038bddcbd8  vmovaps xmm7, [rsp+0x70]
000075038bddcbde  vmovaps xmm8, [rsp+0x80]
000075038bddcbe7  vmovaps xmm9, [rsp+0x90]
000075038bddcbf0  vmovaps xmm10, [rsp+0xA0]
000075038bddcbf9  vmovaps xmm11, [rsp+0xB0]
000075038bddcc02  vmovaps xmm12, [rsp+0xC0]
000075038bddcc0b  vmovaps xmm13, [rsp+0xD0]
000075038bddcc14  vmovaps xmm14, [rsp+0xE0]
000075038bddcc1d  add rsp, 0xF0
000075038bddcc24  pop r11
000075038bddcc26  pop r10
000075038bddcc28  pop r9
000075038bddcc2a  pop r8
000075038bddcc2c  pop rsi
000075038bddcc2d  pop rdi
000075038bddcc2e  pop rdx
000075038bddcc2f  pop rcx
000075038bddcc30  pop rax
000075038bddcc31  add rsp, 0x08
000075038bddcc35  jmp 0x000075038BDD94A0
000075038bddcc3a  call 0x000075038BCD64F0
000075038bddcc3f  jmp 0x000075038BDD94FB
000075038bddcc44  sub rsp, 0x08
000075038bddcc48  push rax
000075038bddcc49  push rcx
000075038bddcc4a  push rdx
000075038bddcc4b  push rdi
000075038bddcc4c  push rsi
000075038bddcc4d  push r8
000075038bddcc4f  push r9
000075038bddcc51  push r10
000075038bddcc53  push r11
000075038bddcc55  sub rsp, 0xF0
000075038bddcc5c  vmovaps [rsp], xmm0
000075038bddcc61  vmovaps [rsp+0x10], xmm1
000075038bddcc67  vmovaps [rsp+0x20], xmm2
000075038bddcc6d  vmovaps [rsp+0x30], xmm3
000075038bddcc73  vmovaps [rsp+0x40], xmm4
000075038bddcc79  vmovaps [rsp+0x50], xmm5
000075038bddcc7f  vmovaps [rsp+0x60], xmm6
000075038bddcc85  vmovaps [rsp+0x70], xmm7
000075038bddcc8b  vmovaps [rsp+0x80], xmm8
000075038bddcc94  vmovaps [rsp+0x90], xmm10
000075038bddcc9d  vmovaps [rsp+0xA0], xmm11
000075038bddcca6  vmovaps [rsp+0xB0], xmm12
000075038bddccaf  vmovaps [rsp+0xC0], xmm13
000075038bddccb8  vmovaps [rsp+0xD0], xmm14
000075038bddccc1  vmovaps [rsp+0xE0], xmm15
000075038bddccca  sub rsp, 0x30
000075038bddccce  movaps [rsp], xmm9
000075038bddccd3  movaps [rsp+0x10], xmm8
000075038bddccd9  movaps [rsp+0x20], xmm11
000075038bddccdf  lea rdi, [rsp]
000075038bddcce3  mov esi, 0x00
000075038bddcce8  mov rax, 0x56ADB4492530
000075038bddccf2  call rax
000075038bddccf4  movaps xmm9, [rsp]
000075038bddccf9  add rsp, 0x30
000075038bddccfd  vmovaps xmm0, [rsp]
000075038bddcd02  vmovaps xmm1, [rsp+0x10]
000075038bddcd08  vmovaps xmm2, [rsp+0x20]
000075038bddcd0e  vmovaps xmm3, [rsp+0x30]
000075038bddcd14  vmovaps xmm4, [rsp+0x40]
000075038bddcd1a  vmovaps xmm5, [rsp+0x50]
000075038bddcd20  vmovaps xmm6, [rsp+0x60]
000075038bddcd26  vmovaps xmm7, [rsp+0x70]
000075038bddcd2c  vmovaps xmm8, [rsp+0x80]
000075038bddcd35  vmovaps xmm10, [rsp+0x90]
000075038bddcd3e  vmovaps xmm11, [rsp+0xA0]
000075038bddcd47  vmovaps xmm12, [rsp+0xB0]
000075038bddcd50  vmovaps xmm13, [rsp+0xC0]
000075038bddcd59  vmovaps xmm14, [rsp+0xD0]
000075038bddcd62  vmovaps xmm15, [rsp+0xE0]
000075038bddcd6b  add rsp, 0xF0
000075038bddcd72  pop r11
000075038bddcd74  pop r10
000075038bddcd76  pop r9
000075038bddcd78  pop r8
000075038bddcd7a  pop rsi
000075038bddcd7b  pop rdi
000075038bddcd7c  pop rdx
000075038bddcd7d  pop rcx
000075038bddcd7e  pop rax
000075038bddcd7f  add rsp, 0x08
000075038bddcd83  jmp 0x000075038BDD9532
000075038bddcd88  sub rsp, 0x08
000075038bddcd8c  push rax
000075038bddcd8d  push rcx
000075038bddcd8e  push rdx
000075038bddcd8f  push rdi
000075038bddcd90  push rsi
000075038bddcd91  push r8
000075038bddcd93  push r9
000075038bddcd95  push r10
000075038bddcd97  push r11
000075038bddcd99  sub rsp, 0xF0
000075038bddcda0  vmovaps [rsp], xmm0
000075038bddcda5  vmovaps [rsp+0x10], xmm1
000075038bddcdab  vmovaps [rsp+0x20], xmm2
000075038bddcdb1  vmovaps [rsp+0x30], xmm3
000075038bddcdb7  vmovaps [rsp+0x40], xmm4
000075038bddcdbd  vmovaps [rsp+0x50], xmm5
000075038bddcdc3  vmovaps [rsp+0x60], xmm6
000075038bddcdc9  vmovaps [rsp+0x70], xmm7
000075038bddcdcf  vmovaps [rsp+0x80], xmm8
000075038bddcdd8  vmovaps [rsp+0x90], xmm9
000075038bddcde1  vmovaps [rsp+0xA0], xmm10
000075038bddcdea  vmovaps [rsp+0xB0], xmm12
000075038bddcdf3  vmovaps [rsp+0xC0], xmm13
000075038bddcdfc  vmovaps [rsp+0xD0], xmm14
000075038bddce05  vmovaps [rsp+0xE0], xmm15
000075038bddce0e  sub rsp, 0x30
000075038bddce12  movaps [rsp], xmm11
000075038bddce17  movaps [rsp+0x10], xmm10
000075038bddce1d  movaps [rsp+0x20], xmm6
000075038bddce22  lea rdi, [rsp]
000075038bddce26  mov esi, 0x00
000075038bddce2b  mov rax, 0x56ADB4492530
000075038bddce35  call rax
000075038bddce37  movaps xmm11, [rsp]
000075038bddce3c  add rsp, 0x30
000075038bddce40  vmovaps xmm0, [rsp]
000075038bddce45  vmovaps xmm1, [rsp+0x10]
000075038bddce4b  vmovaps xmm2, [rsp+0x20]
000075038bddce51  vmovaps xmm3, [rsp+0x30]
000075038bddce57  vmovaps xmm4, [rsp+0x40]
000075038bddce5d  vmovaps xmm5, [rsp+0x50]
000075038bddce63  vmovaps xmm6, [rsp+0x60]
000075038bddce69  vmovaps xmm7, [rsp+0x70]
000075038bddce6f  vmovaps xmm8, [rsp+0x80]
000075038bddce78  vmovaps xmm9, [rsp+0x90]
000075038bddce81  vmovaps xmm10, [rsp+0xA0]
000075038bddce8a  vmovaps xmm12, [rsp+0xB0]
000075038bddce93  vmovaps xmm13, [rsp+0xC0]
000075038bddce9c  vmovaps xmm14, [rsp+0xD0]
000075038bddcea5  vmovaps xmm15, [rsp+0xE0]
000075038bddceae  add rsp, 0xF0
000075038bddceb5  pop r11
000075038bddceb7  pop r10
000075038bddceb9  pop r9
000075038bddcebb  pop r8
000075038bddcebd  pop rsi
000075038bddcebe  pop rdi
000075038bddcebf  pop rdx
000075038bddcec0  pop rcx
000075038bddcec1  pop rax
000075038bddcec2  add rsp, 0x08
000075038bddcec6  jmp 0x000075038BDD954D
000075038bddcecb  sub rsp, 0x08
000075038bddcecf  push rax
000075038bddced0  push rcx
000075038bddced1  push rdx
000075038bddced2  push rdi
000075038bddced3  push rsi
000075038bddced4  push r8
000075038bddced6  push r9
000075038bddced8  push r10
000075038bddceda  push r11
000075038bddcedc  sub rsp, 0xF0
000075038bddcee3  vmovaps [rsp], xmm0
000075038bddcee8  vmovaps [rsp+0x10], xmm1
000075038bddceee  vmovaps [rsp+0x20], xmm2
000075038bddcef4  vmovaps [rsp+0x30], xmm3
000075038bddcefa  vmovaps [rsp+0x40], xmm4
000075038bddcf00  vmovaps [rsp+0x50], xmm5
000075038bddcf06  vmovaps [rsp+0x60], xmm6
000075038bddcf0c  vmovaps [rsp+0x70], xmm7
000075038bddcf12  vmovaps [rsp+0x80], xmm8
000075038bddcf1b  vmovaps [rsp+0x90], xmm9
000075038bddcf24  vmovaps [rsp+0xA0], xmm11
000075038bddcf2d  vmovaps [rsp+0xB0], xmm12
000075038bddcf36  vmovaps [rsp+0xC0], xmm13
000075038bddcf3f  vmovaps [rsp+0xD0], xmm14
000075038bddcf48  vmovaps [rsp+0xE0], xmm15
000075038bddcf51  sub rsp, 0x30
000075038bddcf55  movaps [rsp], xmm10
000075038bddcf5a  movaps [rsp+0x10], xmm14
000075038bddcf60  movaps [rsp+0x20], xmm4
000075038bddcf65  lea rdi, [rsp]
000075038bddcf69  mov esi, 0x00
000075038bddcf6e  mov rax, 0x56ADB4492530
000075038bddcf78  call rax
000075038bddcf7a  movaps xmm10, [rsp]
000075038bddcf7f  add rsp, 0x30
000075038bddcf83  vmovaps xmm0, [rsp]
000075038bddcf88  vmovaps xmm1, [rsp+0x10]
000075038bddcf8e  vmovaps xmm2, [rsp+0x20]
000075038bddcf94  vmovaps xmm3, [rsp+0x30]
000075038bddcf9a  vmovaps xmm4, [rsp+0x40]
000075038bddcfa0  vmovaps xmm5, [rsp+0x50]
000075038bddcfa6  vmovaps xmm6, [rsp+0x60]
000075038bddcfac  vmovaps xmm7, [rsp+0x70]
000075038bddcfb2  vmovaps xmm8, [rsp+0x80]
000075038bddcfbb  vmovaps xmm9, [rsp+0x90]
000075038bddcfc4  vmovaps xmm11, [rsp+0xA0]
000075038bddcfcd  vmovaps xmm12, [rsp+0xB0]
000075038bddcfd6  vmovaps xmm13, [rsp+0xC0]
000075038bddcfdf  vmovaps xmm14, [rsp+0xD0]
000075038bddcfe8  vmovaps xmm15, [rsp+0xE0]
000075038bddcff1  add rsp, 0xF0
000075038bddcff8  pop r11
000075038bddcffa  pop r10
000075038bddcffc  pop r9
000075038bddcffe  pop r8
000075038bddd000  pop rsi
000075038bddd001  pop rdi
000075038bddd002  pop rdx
000075038bddd003  pop rcx
000075038bddd004  pop rax
000075038bddd005  add rsp, 0x08
000075038bddd009  jmp 0x000075038BDD9568
000075038bddd00e  sub rsp, 0x08
000075038bddd012  push rax
000075038bddd013  push rcx
000075038bddd014  push rdx
000075038bddd015  push rdi
000075038bddd016  push rsi
000075038bddd017  push r8
000075038bddd019  push r9
000075038bddd01b  push r10
000075038bddd01d  push r11
000075038bddd01f  sub rsp, 0xF0
000075038bddd026  vmovaps [rsp], xmm0
000075038bddd02b  vmovaps [rsp+0x10], xmm1
000075038bddd031  vmovaps [rsp+0x20], xmm2
000075038bddd037  vmovaps [rsp+0x30], xmm3
000075038bddd03d  vmovaps [rsp+0x40], xmm4
000075038bddd043  vmovaps [rsp+0x50], xmm5
000075038bddd049  vmovaps [rsp+0x60], xmm6
000075038bddd04f  vmovaps [rsp+0x70], xmm7
000075038bddd055  vmovaps [rsp+0x80], xmm9
000075038bddd05e  vmovaps [rsp+0x90], xmm10
000075038bddd067  vmovaps [rsp+0xA0], xmm11
000075038bddd070  vmovaps [rsp+0xB0], xmm12
000075038bddd079  vmovaps [rsp+0xC0], xmm13
000075038bddd082  vmovaps [rsp+0xD0], xmm14
000075038bddd08b  vmovaps [rsp+0xE0], xmm15
000075038bddd094  sub rsp, 0x30
000075038bddd098  movaps [rsp], xmm8
000075038bddd09d  movaps [rsp+0x10], xmm1
000075038bddd0a2  movaps [rsp+0x20], xmm14
000075038bddd0a8  lea rdi, [rsp]
000075038bddd0ac  mov esi, 0x00
000075038bddd0b1  mov rax, 0x56ADB4492530
000075038bddd0bb  call rax
000075038bddd0bd  movaps xmm8, [rsp]
000075038bddd0c2  add rsp, 0x30
000075038bddd0c6  vmovaps xmm0, [rsp]
000075038bddd0cb  vmovaps xmm1, [rsp+0x10]
000075038bddd0d1  vmovaps xmm2, [rsp+0x20]
000075038bddd0d7  vmovaps xmm3, [rsp+0x30]
000075038bddd0dd  vmovaps xmm4, [rsp+0x40]
000075038bddd0e3  vmovaps xmm5, [rsp+0x50]
000075038bddd0e9  vmovaps xmm6, [rsp+0x60]
000075038bddd0ef  vmovaps xmm7, [rsp+0x70]
000075038bddd0f5  vmovaps xmm9, [rsp+0x80]
000075038bddd0fe  vmovaps xmm10, [rsp+0x90]
000075038bddd107  vmovaps xmm11, [rsp+0xA0]
000075038bddd110  vmovaps xmm12, [rsp+0xB0]
000075038bddd119  vmovaps xmm13, [rsp+0xC0]
000075038bddd122  vmovaps xmm14, [rsp+0xD0]
000075038bddd12b  vmovaps xmm15, [rsp+0xE0]
000075038bddd134  add rsp, 0xF0
000075038bddd13b  pop r11
000075038bddd13d  pop r10
000075038bddd13f  pop r9
000075038bddd141  pop r8
000075038bddd143  pop rsi
000075038bddd144  pop rdi
000075038bddd145  pop rdx
000075038bddd146  pop rcx
000075038bddd147  pop rax
000075038bddd148  add rsp, 0x08
000075038bddd14c  jmp 0x000075038BDD958E
000075038bddd151  sub rsp, 0x08
000075038bddd155  push rax
000075038bddd156  push rcx
000075038bddd157  push rdx
000075038bddd158  push rdi
000075038bddd159  push rsi
000075038bddd15a  push r8
000075038bddd15c  push r9
000075038bddd15e  push r10
000075038bddd160  push r11
000075038bddd162  sub rsp, 0xF0
000075038bddd169  vmovaps [rsp], xmm0
000075038bddd16e  vmovaps [rsp+0x10], xmm1
000075038bddd174  vmovaps [rsp+0x20], xmm2
000075038bddd17a  vmovaps [rsp+0x30], xmm3
000075038bddd180  vmovaps [rsp+0x40], xmm4
000075038bddd186  vmovaps [rsp+0x50], xmm5
000075038bddd18c  vmovaps [rsp+0x60], xmm7
000075038bddd192  vmovaps [rsp+0x70], xmm8
000075038bddd198  vmovaps [rsp+0x80], xmm9
000075038bddd1a1  vmovaps [rsp+0x90], xmm10
000075038bddd1aa  vmovaps [rsp+0xA0], xmm11
000075038bddd1b3  vmovaps [rsp+0xB0], xmm12
000075038bddd1bc  vmovaps [rsp+0xC0], xmm13
000075038bddd1c5  vmovaps [rsp+0xD0], xmm14
000075038bddd1ce  vmovaps [rsp+0xE0], xmm15
000075038bddd1d7  sub rsp, 0x30
000075038bddd1db  movaps [rsp], xmm6
000075038bddd1df  movaps [rsp+0x10], xmm1
000075038bddd1e4  movaps [rsp+0x20], xmm14
000075038bddd1ea  lea rdi, [rsp]
000075038bddd1ee  mov esi, 0x00
000075038bddd1f3  mov rax, 0x56ADB4492530
000075038bddd1fd  call rax
000075038bddd1ff  movaps xmm6, [rsp]
000075038bddd203  add rsp, 0x30
000075038bddd207  vmovaps xmm0, [rsp]
000075038bddd20c  vmovaps xmm1, [rsp+0x10]
000075038bddd212  vmovaps xmm2, [rsp+0x20]
000075038bddd218  vmovaps xmm3, [rsp+0x30]
000075038bddd21e  vmovaps xmm4, [rsp+0x40]
000075038bddd224  vmovaps xmm5, [rsp+0x50]
000075038bddd22a  vmovaps xmm7, [rsp+0x60]
000075038bddd230  vmovaps xmm8, [rsp+0x70]
000075038bddd236  vmovaps xmm9, [rsp+0x80]
000075038bddd23f  vmovaps xmm10, [rsp+0x90]
000075038bddd248  vmovaps xmm11, [rsp+0xA0]
000075038bddd251  vmovaps xmm12, [rsp+0xB0]
000075038bddd25a  vmovaps xmm13, [rsp+0xC0]
000075038bddd263  vmovaps xmm14, [rsp+0xD0]
000075038bddd26c  vmovaps xmm15, [rsp+0xE0]
000075038bddd275  add rsp, 0xF0
000075038bddd27c  pop r11
000075038bddd27e  pop r10
000075038bddd280  pop r9
000075038bddd282  pop r8
000075038bddd284  pop rsi
000075038bddd285  pop rdi
000075038bddd286  pop rdx
000075038bddd287  pop rcx
000075038bddd288  pop rax
000075038bddd289  add rsp, 0x08
000075038bddd28d  jmp 0x000075038BDD95BA
000075038bddd292  sub rsp, 0x08
000075038bddd296  push rax
000075038bddd297  push rcx
000075038bddd298  push rdx
000075038bddd299  push rdi
000075038bddd29a  push rsi
000075038bddd29b  push r8
000075038bddd29d  push r9
000075038bddd29f  push r10
000075038bddd2a1  push r11
000075038bddd2a3  sub rsp, 0xF0
000075038bddd2aa  vmovaps [rsp], xmm0
000075038bddd2af  vmovaps [rsp+0x10], xmm1
000075038bddd2b5  vmovaps [rsp+0x20], xmm2
000075038bddd2bb  vmovaps [rsp+0x30], xmm3
000075038bddd2c1  vmovaps [rsp+0x40], xmm4
000075038bddd2c7  vmovaps [rsp+0x50], xmm5
000075038bddd2cd  vmovaps [rsp+0x60], xmm6
000075038bddd2d3  vmovaps [rsp+0x70], xmm7
000075038bddd2d9  vmovaps [rsp+0x80], xmm8
000075038bddd2e2  vmovaps [rsp+0x90], xmm9
000075038bddd2eb  vmovaps [rsp+0xA0], xmm10
000075038bddd2f4  vmovaps [rsp+0xB0], xmm11
000075038bddd2fd  vmovaps [rsp+0xC0], xmm12
000075038bddd306  vmovaps [rsp+0xD0], xmm13
000075038bddd30f  vmovaps [rsp+0xE0], xmm15
000075038bddd318  sub rsp, 0x30
000075038bddd31c  movaps [rsp], xmm14
000075038bddd321  movaps [rsp+0x10], xmm12
000075038bddd327  movaps [rsp+0x20], xmm1
000075038bddd32c  lea rdi, [rsp]
000075038bddd330  mov esi, 0x00
000075038bddd335  mov rax, 0x56ADB4492530
000075038bddd33f  call rax
000075038bddd341  movaps xmm14, [rsp]
000075038bddd346  add rsp, 0x30
000075038bddd34a  vmovaps xmm0, [rsp]
000075038bddd34f  vmovaps xmm1, [rsp+0x10]
000075038bddd355  vmovaps xmm2, [rsp+0x20]
000075038bddd35b  vmovaps xmm3, [rsp+0x30]
000075038bddd361  vmovaps xmm4, [rsp+0x40]
000075038bddd367  vmovaps xmm5, [rsp+0x50]
000075038bddd36d  vmovaps xmm6, [rsp+0x60]
000075038bddd373  vmovaps xmm7, [rsp+0x70]
000075038bddd379  vmovaps xmm8, [rsp+0x80]
000075038bddd382  vmovaps xmm9, [rsp+0x90]
000075038bddd38b  vmovaps xmm10, [rsp+0xA0]
000075038bddd394  vmovaps xmm11, [rsp+0xB0]
000075038bddd39d  vmovaps xmm12, [rsp+0xC0]
000075038bddd3a6  vmovaps xmm13, [rsp+0xD0]
000075038bddd3af  vmovaps xmm15, [rsp+0xE0]
000075038bddd3b8  add rsp, 0xF0
000075038bddd3bf  pop r11
000075038bddd3c1  pop r10
000075038bddd3c3  pop r9
000075038bddd3c5  pop r8
000075038bddd3c7  pop rsi
000075038bddd3c8  pop rdi
000075038bddd3c9  pop rdx
000075038bddd3ca  pop rcx
000075038bddd3cb  pop rax
000075038bddd3cc  add rsp, 0x08
000075038bddd3d0  jmp 0x000075038BDD95E0
000075038bddd3d5  sub rsp, 0x08
000075038bddd3d9  push rax
000075038bddd3da  push rcx
000075038bddd3db  push rdx
000075038bddd3dc  push rdi
000075038bddd3dd  push rsi
000075038bddd3de  push r8
000075038bddd3e0  push r9
000075038bddd3e2  push r10
000075038bddd3e4  push r11
000075038bddd3e6  sub rsp, 0xF0
000075038bddd3ed  vmovaps [rsp], xmm0
000075038bddd3f2  vmovaps [rsp+0x10], xmm2
000075038bddd3f8  vmovaps [rsp+0x20], xmm3
000075038bddd3fe  vmovaps [rsp+0x30], xmm4
000075038bddd404  vmovaps [rsp+0x40], xmm5
000075038bddd40a  vmovaps [rsp+0x50], xmm6
000075038bddd410  vmovaps [rsp+0x60], xmm7
000075038bddd416  vmovaps [rsp+0x70], xmm8
000075038bddd41c  vmovaps [rsp+0x80], xmm9
000075038bddd425  vmovaps [rsp+0x90], xmm10
000075038bddd42e  vmovaps [rsp+0xA0], xmm11
000075038bddd437  vmovaps [rsp+0xB0], xmm12
000075038bddd440  vmovaps [rsp+0xC0], xmm13
000075038bddd449  vmovaps [rsp+0xD0], xmm14
000075038bddd452  vmovaps [rsp+0xE0], xmm15
000075038bddd45b  sub rsp, 0x30
000075038bddd45f  movaps [rsp], xmm1
000075038bddd463  movaps [rsp+0x10], xmm13
000075038bddd469  movaps [rsp+0x20], xmm9
000075038bddd46f  lea rdi, [rsp]
000075038bddd473  mov esi, 0x00
000075038bddd478  mov rax, 0x56ADB4492530
000075038bddd482  call rax
000075038bddd484  movaps xmm1, [rsp]
000075038bddd488  add rsp, 0x30
000075038bddd48c  vmovaps xmm0, [rsp]
000075038bddd491  vmovaps xmm2, [rsp+0x10]
000075038bddd497  vmovaps xmm3, [rsp+0x20]
000075038bddd49d  vmovaps xmm4, [rsp+0x30]
000075038bddd4a3  vmovaps xmm5, [rsp+0x40]
000075038bddd4a9  vmovaps xmm6, [rsp+0x50]
000075038bddd4af  vmovaps xmm7, [rsp+0x60]
000075038bddd4b5  vmovaps xmm8, [rsp+0x70]
000075038bddd4bb  vmovaps xmm9, [rsp+0x80]
000075038bddd4c4  vmovaps xmm10, [rsp+0x90]
000075038bddd4cd  vmovaps xmm11, [rsp+0xA0]
000075038bddd4d6  vmovaps xmm12, [rsp+0xB0]
000075038bddd4df  vmovaps xmm13, [rsp+0xC0]
000075038bddd4e8  vmovaps xmm14, [rsp+0xD0]
000075038bddd4f1  vmovaps xmm15, [rsp+0xE0]
000075038bddd4fa  add rsp, 0xF0
000075038bddd501  pop r11
000075038bddd503  pop r10
000075038bddd505  pop r9
000075038bddd507  pop r8
000075038bddd509  pop rsi
000075038bddd50a  pop rdi
000075038bddd50b  pop rdx
000075038bddd50c  pop rcx
000075038bddd50d  pop rax
000075038bddd50e  add rsp, 0x08
000075038bddd512  jmp 0x000075038BDD95FA
000075038bddd517  sub rsp, 0x08
000075038bddd51b  push rax
000075038bddd51c  push rcx
000075038bddd51d  push rdx
000075038bddd51e  push rdi
000075038bddd51f  push rsi
000075038bddd520  push r8
000075038bddd522  push r9
000075038bddd524  push r10
000075038bddd526  push r11
000075038bddd528  sub rsp, 0xF0
000075038bddd52f  vmovaps [rsp], xmm0
000075038bddd534  vmovaps [rsp+0x10], xmm1
000075038bddd53a  vmovaps [rsp+0x20], xmm2
000075038bddd540  vmovaps [rsp+0x30], xmm3
000075038bddd546  vmovaps [rsp+0x40], xmm4
000075038bddd54c  vmovaps [rsp+0x50], xmm5
000075038bddd552  vmovaps [rsp+0x60], xmm6
000075038bddd558  vmovaps [rsp+0x70], xmm7
000075038bddd55e  vmovaps [rsp+0x80], xmm8
000075038bddd567  vmovaps [rsp+0x90], xmm9
000075038bddd570  vmovaps [rsp+0xA0], xmm10
000075038bddd579  vmovaps [rsp+0xB0], xmm11
000075038bddd582  vmovaps [rsp+0xC0], xmm13
000075038bddd58b  vmovaps [rsp+0xD0], xmm14
000075038bddd594  vmovaps [rsp+0xE0], xmm15
000075038bddd59d  sub rsp, 0x30
000075038bddd5a1  movaps [rsp], xmm12
000075038bddd5a6  movaps [rsp+0x10], xmm7
000075038bddd5ab  movaps [rsp+0x20], xmm13
000075038bddd5b1  lea rdi, [rsp]
000075038bddd5b5  mov esi, 0x00
000075038bddd5ba  mov rax, 0x56ADB4492530
000075038bddd5c4  call rax
000075038bddd5c6  movaps xmm12, [rsp]
000075038bddd5cb  add rsp, 0x30
000075038bddd5cf  vmovaps xmm0, [rsp]
000075038bddd5d4  vmovaps xmm1, [rsp+0x10]
000075038bddd5da  vmovaps xmm2, [rsp+0x20]
000075038bddd5e0  vmovaps xmm3, [rsp+0x30]
000075038bddd5e6  vmovaps xmm4, [rsp+0x40]
000075038bddd5ec  vmovaps xmm5, [rsp+0x50]
000075038bddd5f2  vmovaps xmm6, [rsp+0x60]
000075038bddd5f8  vmovaps xmm7, [rsp+0x70]
000075038bddd5fe  vmovaps xmm8, [rsp+0x80]
000075038bddd607  vmovaps xmm9, [rsp+0x90]
000075038bddd610  vmovaps xmm10, [rsp+0xA0]
000075038bddd619  vmovaps xmm11, [rsp+0xB0]
000075038bddd622  vmovaps xmm13, [rsp+0xC0]
000075038bddd62b  vmovaps xmm14, [rsp+0xD0]
000075038bddd634  vmovaps xmm15, [rsp+0xE0]
000075038bddd63d  add rsp, 0xF0
000075038bddd644  pop r11
000075038bddd646  pop r10
000075038bddd648  pop r9
000075038bddd64a  pop r8
000075038bddd64c  pop rsi
000075038bddd64d  pop rdi
000075038bddd64e  pop rdx
000075038bddd64f  pop rcx
000075038bddd650  pop rax
000075038bddd651  add rsp, 0x08
000075038bddd655  jmp 0x000075038BDD9621
000075038bddd65a  sub rsp, 0x08
000075038bddd65e  push rax
000075038bddd65f  push rcx
000075038bddd660  push rdx
000075038bddd661  push rdi
000075038bddd662  push rsi
000075038bddd663  push r8
000075038bddd665  push r9
000075038bddd667  push r10
000075038bddd669  push r11
000075038bddd66b  sub rsp, 0xF0
000075038bddd672  vmovaps [rsp], xmm0
000075038bddd677  vmovaps [rsp+0x10], xmm1
000075038bddd67d  vmovaps [rsp+0x20], xmm2
000075038bddd683  vmovaps [rsp+0x30], xmm3
000075038bddd689  vmovaps [rsp+0x40], xmm4
000075038bddd68f  vmovaps [rsp+0x50], xmm5
000075038bddd695  vmovaps [rsp+0x60], xmm6
000075038bddd69b  vmovaps [rsp+0x70], xmm7
000075038bddd6a1  vmovaps [rsp+0x80], xmm8
000075038bddd6aa  vmovaps [rsp+0x90], xmm9
000075038bddd6b3  vmovaps [rsp+0xA0], xmm10
000075038bddd6bc  vmovaps [rsp+0xB0], xmm11
000075038bddd6c5  vmovaps [rsp+0xC0], xmm12
000075038bddd6ce  vmovaps [rsp+0xD0], xmm14
000075038bddd6d7  vmovaps [rsp+0xE0], xmm15
000075038bddd6e0  sub rsp, 0x30
000075038bddd6e4  movaps [rsp], xmm13
000075038bddd6e9  movaps [rsp+0x10], xmm15
000075038bddd6ef  movaps [rsp+0x20], xmm8
000075038bddd6f5  lea rdi, [rsp]
000075038bddd6f9  mov esi, 0x00
000075038bddd6fe  mov rax, 0x56ADB4492530
000075038bddd708  call rax
000075038bddd70a  movaps xmm13, [rsp]
000075038bddd70f  add rsp, 0x30
000075038bddd713  vmovaps xmm0, [rsp]
000075038bddd718  vmovaps xmm1, [rsp+0x10]
000075038bddd71e  vmovaps xmm2, [rsp+0x20]
000075038bddd724  vmovaps xmm3, [rsp+0x30]
000075038bddd72a  vmovaps xmm4, [rsp+0x40]
000075038bddd730  vmovaps xmm5, [rsp+0x50]
000075038bddd736  vmovaps xmm6, [rsp+0x60]
000075038bddd73c  vmovaps xmm7, [rsp+0x70]
000075038bddd742  vmovaps xmm8, [rsp+0x80]
000075038bddd74b  vmovaps xmm9, [rsp+0x90]
000075038bddd754  vmovaps xmm10, [rsp+0xA0]
000075038bddd75d  vmovaps xmm11, [rsp+0xB0]
000075038bddd766  vmovaps xmm12, [rsp+0xC0]
000075038bddd76f  vmovaps xmm14, [rsp+0xD0]
000075038bddd778  vmovaps xmm15, [rsp+0xE0]
000075038bddd781  add rsp, 0xF0
000075038bddd788  pop r11
000075038bddd78a  pop r10
000075038bddd78c  pop r9
000075038bddd78e  pop r8
000075038bddd790  pop rsi
000075038bddd791  pop rdi
000075038bddd792  pop rdx
000075038bddd793  pop rcx
000075038bddd794  pop rax
000075038bddd795  add rsp, 0x08
000075038bddd799  jmp 0x000075038BDD963C
000075038bddd79e  sub rsp, 0x08
000075038bddd7a2  push rax
000075038bddd7a3  push rcx
000075038bddd7a4  push rdx
000075038bddd7a5  push rdi
000075038bddd7a6  push rsi
000075038bddd7a7  push r8
000075038bddd7a9  push r9
000075038bddd7ab  push r10
000075038bddd7ad  push r11
000075038bddd7af  sub rsp, 0xF0
000075038bddd7b6  vmovaps [rsp], xmm0
000075038bddd7bb  vmovaps [rsp+0x10], xmm1
000075038bddd7c1  vmovaps [rsp+0x20], xmm2
000075038bddd7c7  vmovaps [rsp+0x30], xmm3
000075038bddd7cd  vmovaps [rsp+0x40], xmm4
000075038bddd7d3  vmovaps [rsp+0x50], xmm5
000075038bddd7d9  vmovaps [rsp+0x60], xmm6
000075038bddd7df  vmovaps [rsp+0x70], xmm7
000075038bddd7e5  vmovaps [rsp+0x80], xmm9
000075038bddd7ee  vmovaps [rsp+0x90], xmm10
000075038bddd7f7  vmovaps [rsp+0xA0], xmm11
000075038bddd800  vmovaps [rsp+0xB0], xmm12
000075038bddd809  vmovaps [rsp+0xC0], xmm13
000075038bddd812  vmovaps [rsp+0xD0], xmm14
000075038bddd81b  vmovaps [rsp+0xE0], xmm15
000075038bddd824  sub rsp, 0x30
000075038bddd828  movaps [rsp], xmm8
000075038bddd82d  movaps [rsp+0x10], xmm15
000075038bddd833  movaps [rsp+0x20], xmm9
000075038bddd839  lea rdi, [rsp]
000075038bddd83d  mov esi, 0x00
000075038bddd842  mov rax, 0x56ADB4492530
000075038bddd84c  call rax
000075038bddd84e  movaps xmm8, [rsp]
000075038bddd853  add rsp, 0x30
000075038bddd857  vmovaps xmm0, [rsp]
000075038bddd85c  vmovaps xmm1, [rsp+0x10]
000075038bddd862  vmovaps xmm2, [rsp+0x20]
000075038bddd868  vmovaps xmm3, [rsp+0x30]
000075038bddd86e  vmovaps xmm4, [rsp+0x40]
000075038bddd874  vmovaps xmm5, [rsp+0x50]
000075038bddd87a  vmovaps xmm6, [rsp+0x60]
000075038bddd880  vmovaps xmm7, [rsp+0x70]
000075038bddd886  vmovaps xmm9, [rsp+0x80]
000075038bddd88f  vmovaps xmm10, [rsp+0x90]
000075038bddd898  vmovaps xmm11, [rsp+0xA0]
000075038bddd8a1  vmovaps xmm12, [rsp+0xB0]
000075038bddd8aa  vmovaps xmm13, [rsp+0xC0]
000075038bddd8b3  vmovaps xmm14, [rsp+0xD0]
000075038bddd8bc  vmovaps xmm15, [rsp+0xE0]
000075038bddd8c5  add rsp, 0xF0
000075038bddd8cc  pop r11
000075038bddd8ce  pop r10
000075038bddd8d0  pop r9
000075038bddd8d2  pop r8
000075038bddd8d4  pop rsi
000075038bddd8d5  pop rdi
000075038bddd8d6  pop rdx
000075038bddd8d7  pop rcx
000075038bddd8d8  pop rax
000075038bddd8d9  add rsp, 0x08
000075038bddd8dd  jmp 0x000075038BDD966A
000075038bddd8e2  sub rsp, 0x08
000075038bddd8e6  push rax
000075038bddd8e7  push rcx
000075038bddd8e8  push rdx
000075038bddd8e9  push rdi
000075038bddd8ea  push rsi
000075038bddd8eb  push r8
000075038bddd8ed  push r9
000075038bddd8ef  push r10
000075038bddd8f1  push r11
000075038bddd8f3  sub rsp, 0xF0
000075038bddd8fa  vmovaps [rsp], xmm0
000075038bddd8ff  vmovaps [rsp+0x10], xmm1
000075038bddd905  vmovaps [rsp+0x20], xmm2
000075038bddd90b  vmovaps [rsp+0x30], xmm3
000075038bddd911  vmovaps [rsp+0x40], xmm4
000075038bddd917  vmovaps [rsp+0x50], xmm5
000075038bddd91d  vmovaps [rsp+0x60], xmm6
000075038bddd923  vmovaps [rsp+0x70], xmm7
000075038bddd929  vmovaps [rsp+0x80], xmm8
000075038bddd932  vmovaps [rsp+0x90], xmm9
000075038bddd93b  vmovaps [rsp+0xA0], xmm10
000075038bddd944  vmovaps [rsp+0xB0], xmm11
000075038bddd94d  vmovaps [rsp+0xC0], xmm12
000075038bddd956  vmovaps [rsp+0xD0], xmm13
000075038bddd95f  vmovaps [rsp+0xE0], xmm14
000075038bddd968  sub rsp, 0x30
000075038bddd96c  movaps [rsp], xmm15
000075038bddd971  movaps [rsp+0x10], xmm11
000075038bddd977  movaps [rsp+0x20], xmm6
000075038bddd97c  lea rdi, [rsp]
000075038bddd980  mov esi, 0x00
000075038bddd985  mov rax, 0x56ADB4492530
000075038bddd98f  call rax
000075038bddd991  movaps xmm15, [rsp]
000075038bddd996  add rsp, 0x30
000075038bddd99a  vmovaps xmm0, [rsp]
000075038bddd99f  vmovaps xmm1, [rsp+0x10]
000075038bddd9a5  vmovaps xmm2, [rsp+0x20]
000075038bddd9ab  vmovaps xmm3, [rsp+0x30]
000075038bddd9b1  vmovaps xmm4, [rsp+0x40]
000075038bddd9b7  vmovaps xmm5, [rsp+0x50]
000075038bddd9bd  vmovaps xmm6, [rsp+0x60]
000075038bddd9c3  vmovaps xmm7, [rsp+0x70]
000075038bddd9c9  vmovaps xmm8, [rsp+0x80]
000075038bddd9d2  vmovaps xmm9, [rsp+0x90]
000075038bddd9db  vmovaps xmm10, [rsp+0xA0]
000075038bddd9e4  vmovaps xmm11, [rsp+0xB0]
000075038bddd9ed  vmovaps xmm12, [rsp+0xC0]
000075038bddd9f6  vmovaps xmm13, [rsp+0xD0]
000075038bddd9ff  vmovaps xmm14, [rsp+0xE0]
000075038bddda08  add rsp, 0xF0
000075038bddda0f  pop r11
000075038bddda11  pop r10
000075038bddda13  pop r9
000075038bddda15  pop r8
000075038bddda17  pop rsi
000075038bddda18  pop rdi
000075038bddda19  pop rdx
000075038bddda1a  pop rcx
000075038bddda1b  pop rax
000075038bddda1c  add rsp, 0x08
000075038bddda20  jmp 0x000075038BDD9685
000075038bddda25  sub rsp, 0x08
000075038bddda29  push rax
000075038bddda2a  push rcx
000075038bddda2b  push rdx
000075038bddda2c  push rdi
000075038bddda2d  push rsi
000075038bddda2e  push r8
000075038bddda30  push r9
000075038bddda32  push r10
000075038bddda34  push r11
000075038bddda36  sub rsp, 0xF0
000075038bddda3d  vmovaps [rsp], xmm0
000075038bddda42  vmovaps [rsp+0x10], xmm1
000075038bddda48  vmovaps [rsp+0x20], xmm2
000075038bddda4e  vmovaps [rsp+0x30], xmm3
000075038bddda54  vmovaps [rsp+0x40], xmm4
000075038bddda5a  vmovaps [rsp+0x50], xmm5
000075038bddda60  vmovaps [rsp+0x60], xmm6
000075038bddda66  vmovaps [rsp+0x70], xmm8
000075038bddda6c  vmovaps [rsp+0x80], xmm9
000075038bddda75  vmovaps [rsp+0x90], xmm10
000075038bddda7e  vmovaps [rsp+0xA0], xmm11
000075038bddda87  vmovaps [rsp+0xB0], xmm12
000075038bddda90  vmovaps [rsp+0xC0], xmm13
000075038bddda99  vmovaps [rsp+0xD0], xmm14
000075038bdddaa2  vmovaps [rsp+0xE0], xmm15
000075038bdddaab  sub rsp, 0x30
000075038bdddaaf  movaps [rsp], xmm7
000075038bdddab3  movaps [rsp+0x10], xmm11
000075038bdddab9  movaps [rsp+0x20], xmm9
000075038bdddabf  lea rdi, [rsp]
000075038bdddac3  mov esi, 0x00
000075038bdddac8  mov rax, 0x56ADB4492530
000075038bdddad2  call rax
000075038bdddad4  movaps xmm7, [rsp]
000075038bdddad8  add rsp, 0x30
000075038bdddadc  vmovaps xmm0, [rsp]
000075038bdddae1  vmovaps xmm1, [rsp+0x10]
000075038bdddae7  vmovaps xmm2, [rsp+0x20]
000075038bdddaed  vmovaps xmm3, [rsp+0x30]
000075038bdddaf3  vmovaps xmm4, [rsp+0x40]
000075038bdddaf9  vmovaps xmm5, [rsp+0x50]
000075038bdddaff  vmovaps xmm6, [rsp+0x60]
000075038bdddb05  vmovaps xmm8, [rsp+0x70]
000075038bdddb0b  vmovaps xmm9, [rsp+0x80]
000075038bdddb14  vmovaps xmm10, [rsp+0x90]
000075038bdddb1d  vmovaps xmm11, [rsp+0xA0]
000075038bdddb26  vmovaps xmm12, [rsp+0xB0]
000075038bdddb2f  vmovaps xmm13, [rsp+0xC0]
000075038bdddb38  vmovaps xmm14, [rsp+0xD0]
000075038bdddb41  vmovaps xmm15, [rsp+0xE0]
000075038bdddb4a  add rsp, 0xF0
000075038bdddb51  pop r11
000075038bdddb53  pop r10
000075038bdddb55  pop r9
000075038bdddb57  pop r8
000075038bdddb59  pop rsi
000075038bdddb5a  pop rdi
000075038bdddb5b  pop rdx
000075038bdddb5c  pop rcx
000075038bdddb5d  pop rax
000075038bdddb5e  add rsp, 0x08
000075038bdddb62  jmp 0x000075038BDD96B2
000075038bdddb67  sub rsp, 0x08
000075038bdddb6b  push rax
000075038bdddb6c  push rcx
000075038bdddb6d  push rdx
000075038bdddb6e  push rdi
000075038bdddb6f  push rsi
000075038bdddb70  push r8
000075038bdddb72  push r9
000075038bdddb74  push r10
000075038bdddb76  push r11
000075038bdddb78  sub rsp, 0xF0
000075038bdddb7f  vmovaps [rsp], xmm0
000075038bdddb84  vmovaps [rsp+0x10], xmm1
000075038bdddb8a  vmovaps [rsp+0x20], xmm2
000075038bdddb90  vmovaps [rsp+0x30], xmm3
000075038bdddb96  vmovaps [rsp+0x40], xmm4
000075038bdddb9c  vmovaps [rsp+0x50], xmm5
000075038bdddba2  vmovaps [rsp+0x60], xmm6
000075038bdddba8  vmovaps [rsp+0x70], xmm7
000075038bdddbae  vmovaps [rsp+0x80], xmm8
000075038bdddbb7  vmovaps [rsp+0x90], xmm9
000075038bdddbc0  vmovaps [rsp+0xA0], xmm10
000075038bdddbc9  vmovaps [rsp+0xB0], xmm12
000075038bdddbd2  vmovaps [rsp+0xC0], xmm13
000075038bdddbdb  vmovaps [rsp+0xD0], xmm14
000075038bdddbe4  vmovaps [rsp+0xE0], xmm15
000075038bdddbed  sub rsp, 0x30
000075038bdddbf1  movaps [rsp], xmm11
000075038bdddbf6  movaps [rsp+0x10], xmm10
000075038bdddbfc  movaps [rsp+0x20], xmm14
000075038bdddc02  lea rdi, [rsp]
000075038bdddc06  mov esi, 0x00
000075038bdddc0b  mov rax, 0x56ADB4492530
000075038bdddc15  call rax
000075038bdddc17  movaps xmm11, [rsp]
000075038bdddc1c  add rsp, 0x30
000075038bdddc20  vmovaps xmm0, [rsp]
000075038bdddc25  vmovaps xmm1, [rsp+0x10]
000075038bdddc2b  vmovaps xmm2, [rsp+0x20]
000075038bdddc31  vmovaps xmm3, [rsp+0x30]
000075038bdddc37  vmovaps xmm4, [rsp+0x40]
000075038bdddc3d  vmovaps xmm5, [rsp+0x50]
000075038bdddc43  vmovaps xmm6, [rsp+0x60]
000075038bdddc49  vmovaps xmm7, [rsp+0x70]
000075038bdddc4f  vmovaps xmm8, [rsp+0x80]
000075038bdddc58  vmovaps xmm9, [rsp+0x90]
000075038bdddc61  vmovaps xmm10, [rsp+0xA0]
000075038bdddc6a  vmovaps xmm12, [rsp+0xB0]
000075038bdddc73  vmovaps xmm13, [rsp+0xC0]
000075038bdddc7c  vmovaps xmm14, [rsp+0xD0]
000075038bdddc85  vmovaps xmm15, [rsp+0xE0]
000075038bdddc8e  add rsp, 0xF0
000075038bdddc95  pop r11
000075038bdddc97  pop r10
000075038bdddc99  pop r9
000075038bdddc9b  pop r8
000075038bdddc9d  pop rsi
000075038bdddc9e  pop rdi
000075038bdddc9f  pop rdx
000075038bdddca0  pop rcx
000075038bdddca1  pop rax
000075038bdddca2  add rsp, 0x08
000075038bdddca6  jmp 0x000075038BDD96CD
000075038bdddcab  call 0x000075038BCE45A0
000075038bdddcb0  jmp 0x000075038BDD96D7
000075038bdddcb5  sub rsp, 0x08
000075038bdddcb9  push rax
000075038bdddcba  push rcx
000075038bdddcbb  push rdx
000075038bdddcbc  push rdi
000075038bdddcbd  push rsi
000075038bdddcbe  push r8
000075038bdddcc0  push r9
000075038bdddcc2  push r10
000075038bdddcc4  push r11
000075038bdddcc6  sub rsp, 0xF0
000075038bdddccd  vmovaps [rsp], xmm0
000075038bdddcd2  vmovaps [rsp+0x10], xmm1
000075038bdddcd8  vmovaps [rsp+0x20], xmm2
000075038bdddcde  vmovaps [rsp+0x30], xmm3
000075038bdddce4  vmovaps [rsp+0x40], xmm4
000075038bdddcea  vmovaps [rsp+0x50], xmm5
000075038bdddcf0  vmovaps [rsp+0x60], xmm6
000075038bdddcf6  vmovaps [rsp+0x70], xmm7
000075038bdddcfc  vmovaps [rsp+0x80], xmm8
000075038bdddd05  vmovaps [rsp+0x90], xmm9
000075038bdddd0e  vmovaps [rsp+0xA0], xmm11
000075038bdddd17  vmovaps [rsp+0xB0], xmm12
000075038bdddd20  vmovaps [rsp+0xC0], xmm13
000075038bdddd29  vmovaps [rsp+0xD0], xmm14
000075038bdddd32  vmovaps [rsp+0xE0], xmm15
000075038bdddd3b  sub rsp, 0x30
000075038bdddd3f  movaps [rsp], xmm10
000075038bdddd44  movaps [rsp+0x10], xmm1
000075038bdddd49  movaps [rsp+0x20], xmm12
000075038bdddd4f  lea rdi, [rsp]
000075038bdddd53  mov esi, 0x00
000075038bdddd58  mov rax, 0x56ADB4492530
000075038bdddd62  call rax
000075038bdddd64  movaps xmm10, [rsp]
000075038bdddd69  add rsp, 0x30
000075038bdddd6d  vmovaps xmm0, [rsp]
000075038bdddd72  vmovaps xmm1, [rsp+0x10]
000075038bdddd78  vmovaps xmm2, [rsp+0x20]
000075038bdddd7e  vmovaps xmm3, [rsp+0x30]
000075038bdddd84  vmovaps xmm4, [rsp+0x40]
000075038bdddd8a  vmovaps xmm5, [rsp+0x50]
000075038bdddd90  vmovaps xmm6, [rsp+0x60]
000075038bdddd96  vmovaps xmm7, [rsp+0x70]
000075038bdddd9c  vmovaps xmm8, [rsp+0x80]
000075038bdddda5  vmovaps xmm9, [rsp+0x90]
000075038bddddae  vmovaps xmm11, [rsp+0xA0]
000075038bddddb7  vmovaps xmm12, [rsp+0xB0]
000075038bddddc0  vmovaps xmm13, [rsp+0xC0]
000075038bddddc9  vmovaps xmm14, [rsp+0xD0]
000075038bddddd2  vmovaps xmm15, [rsp+0xE0]
000075038bdddddb  add rsp, 0xF0
000075038bdddde2  pop r11
000075038bdddde4  pop r10
000075038bdddde6  pop r9
000075038bdddde8  pop r8
000075038bddddea  pop rsi
000075038bddddeb  pop rdi
000075038bddddec  pop rdx
000075038bdddded  pop rcx
000075038bddddee  pop rax
000075038bddddef  add rsp, 0x08
000075038bddddf3  jmp 0x000075038BDD96FA
000075038bddddf8  sub rsp, 0x08
000075038bddddfc  push rax
000075038bddddfd  push rcx
000075038bddddfe  push rdx
000075038bddddff  push rdi
000075038bddde00  push rsi
000075038bddde01  push r8
000075038bddde03  push r9
000075038bddde05  push r10
000075038bddde07  push r11
000075038bddde09  sub rsp, 0xF0
000075038bddde10  vmovaps [rsp], xmm0
000075038bddde15  vmovaps [rsp+0x10], xmm1
000075038bddde1b  vmovaps [rsp+0x20], xmm2
000075038bddde21  vmovaps [rsp+0x30], xmm3
000075038bddde27  vmovaps [rsp+0x40], xmm4
000075038bddde2d  vmovaps [rsp+0x50], xmm5
000075038bddde33  vmovaps [rsp+0x60], xmm6
000075038bddde39  vmovaps [rsp+0x70], xmm7
000075038bddde3f  vmovaps [rsp+0x80], xmm8
000075038bddde48  vmovaps [rsp+0x90], xmm9
000075038bddde51  vmovaps [rsp+0xA0], xmm10
000075038bddde5a  vmovaps [rsp+0xB0], xmm11
000075038bddde63  vmovaps [rsp+0xC0], xmm13
000075038bddde6c  vmovaps [rsp+0xD0], xmm14
000075038bddde75  vmovaps [rsp+0xE0], xmm15
000075038bddde7e  sub rsp, 0x30
000075038bddde82  movaps [rsp], xmm12
000075038bddde87  movaps [rsp+0x10], xmm14
000075038bddde8d  movaps [rsp+0x20], xmm1
000075038bddde92  lea rdi, [rsp]
000075038bddde96  mov esi, 0x00
000075038bddde9b  mov rax, 0x56ADB4492530
000075038bdddea5  call rax
000075038bdddea7  movaps xmm12, [rsp]
000075038bdddeac  add rsp, 0x30
000075038bdddeb0  vmovaps xmm0, [rsp]
000075038bdddeb5  vmovaps xmm1, [rsp+0x10]
000075038bdddebb  vmovaps xmm2, [rsp+0x20]
000075038bdddec1  vmovaps xmm3, [rsp+0x30]
000075038bdddec7  vmovaps xmm4, [rsp+0x40]
000075038bdddecd  vmovaps xmm5, [rsp+0x50]
000075038bddded3  vmovaps xmm6, [rsp+0x60]
000075038bddded9  vmovaps xmm7, [rsp+0x70]
000075038bdddedf  vmovaps xmm8, [rsp+0x80]
000075038bdddee8  vmovaps xmm9, [rsp+0x90]
000075038bdddef1  vmovaps xmm10, [rsp+0xA0]
000075038bdddefa  vmovaps xmm11, [rsp+0xB0]
000075038bdddf03  vmovaps xmm13, [rsp+0xC0]
000075038bdddf0c  vmovaps xmm14, [rsp+0xD0]
000075038bdddf15  vmovaps xmm15, [rsp+0xE0]
000075038bdddf1e  add rsp, 0xF0
000075038bdddf25  pop r11
000075038bdddf27  pop r10
000075038bdddf29  pop r9
000075038bdddf2b  pop r8
000075038bdddf2d  pop rsi
000075038bdddf2e  pop rdi
000075038bdddf2f  pop rdx
000075038bdddf30  pop rcx
000075038bdddf31  pop rax
000075038bdddf32  add rsp, 0x08
000075038bdddf36  jmp 0x000075038BDD9729
000075038bdddf3b  sub rsp, 0x08
000075038bdddf3f  push rax
000075038bdddf40  push rcx
000075038bdddf41  push rdx
000075038bdddf42  push rdi
000075038bdddf43  push rsi
000075038bdddf44  push r8
000075038bdddf46  push r9
000075038bdddf48  push r10
000075038bdddf4a  push r11
000075038bdddf4c  sub rsp, 0xF0
000075038bdddf53  vmovaps [rsp], xmm0
000075038bdddf58  vmovaps [rsp+0x10], xmm1
000075038bdddf5e  vmovaps [rsp+0x20], xmm2
000075038bdddf64  vmovaps [rsp+0x30], xmm3
000075038bdddf6a  vmovaps [rsp+0x40], xmm4
000075038bdddf70  vmovaps [rsp+0x50], xmm5
000075038bdddf76  vmovaps [rsp+0x60], xmm6
000075038bdddf7c  vmovaps [rsp+0x70], xmm7
000075038bdddf82  vmovaps [rsp+0x80], xmm8
000075038bdddf8b  vmovaps [rsp+0x90], xmm9
000075038bdddf94  vmovaps [rsp+0xA0], xmm10
000075038bdddf9d  vmovaps [rsp+0xB0], xmm11
000075038bdddfa6  vmovaps [rsp+0xC0], xmm12
000075038bdddfaf  vmovaps [rsp+0xD0], xmm13
000075038bdddfb8  vmovaps [rsp+0xE0], xmm15
000075038bdddfc1  sub rsp, 0x30
000075038bdddfc5  movaps [rsp], xmm14
000075038bdddfca  movaps [rsp+0x10], xmm9
000075038bdddfd0  movaps [rsp+0x20], xmm1
000075038bdddfd5  lea rdi, [rsp]
000075038bdddfd9  mov esi, 0x00
000075038bdddfde  mov rax, 0x56ADB4492530
000075038bdddfe8  call rax
000075038bdddfea  movaps xmm14, [rsp]
000075038bdddfef  add rsp, 0x30
000075038bdddff3  vmovaps xmm0, [rsp]
000075038bdddff8  vmovaps xmm1, [rsp+0x10]
000075038bdddffe  vmovaps xmm2, [rsp+0x20]
000075038bdde004  vmovaps xmm3, [rsp+0x30]
000075038bdde00a  vmovaps xmm4, [rsp+0x40]
000075038bdde010  vmovaps xmm5, [rsp+0x50]
000075038bdde016  vmovaps xmm6, [rsp+0x60]
000075038bdde01c  vmovaps xmm7, [rsp+0x70]
000075038bdde022  vmovaps xmm8, [rsp+0x80]
000075038bdde02b  vmovaps xmm9, [rsp+0x90]
000075038bdde034  vmovaps xmm10, [rsp+0xA0]
000075038bdde03d  vmovaps xmm11, [rsp+0xB0]
000075038bdde046  vmovaps xmm12, [rsp+0xC0]
000075038bdde04f  vmovaps xmm13, [rsp+0xD0]
000075038bdde058  vmovaps xmm15, [rsp+0xE0]
000075038bdde061  add rsp, 0xF0
000075038bdde068  pop r11
000075038bdde06a  pop r10
000075038bdde06c  pop r9
000075038bdde06e  pop r8
000075038bdde070  pop rsi
000075038bdde071  pop rdi
000075038bdde072  pop rdx
000075038bdde073  pop rcx
000075038bdde074  pop rax
000075038bdde075  add rsp, 0x08
000075038bdde079  jmp 0x000075038BDD9758
000075038bdde07e  sub rsp, 0x08
000075038bdde082  push rax
000075038bdde083  push rcx
000075038bdde084  push rdx
000075038bdde085  push rdi
000075038bdde086  push rsi
000075038bdde087  push r8
000075038bdde089  push r9
000075038bdde08b  push r10
000075038bdde08d  push r11
000075038bdde08f  sub rsp, 0xF0
000075038bdde096  vmovaps [rsp], xmm0
000075038bdde09b  vmovaps [rsp+0x10], xmm2
000075038bdde0a1  vmovaps [rsp+0x20], xmm3
000075038bdde0a7  vmovaps [rsp+0x30], xmm4
000075038bdde0ad  vmovaps [rsp+0x40], xmm5
000075038bdde0b3  vmovaps [rsp+0x50], xmm6
000075038bdde0b9  vmovaps [rsp+0x60], xmm7
000075038bdde0bf  vmovaps [rsp+0x70], xmm8
000075038bdde0c5  vmovaps [rsp+0x80], xmm9
000075038bdde0ce  vmovaps [rsp+0x90], xmm10
000075038bdde0d7  vmovaps [rsp+0xA0], xmm11
000075038bdde0e0  vmovaps [rsp+0xB0], xmm12
000075038bdde0e9  vmovaps [rsp+0xC0], xmm13
000075038bdde0f2  vmovaps [rsp+0xD0], xmm14
000075038bdde0fb  vmovaps [rsp+0xE0], xmm15
000075038bdde104  sub rsp, 0x30
000075038bdde108  movaps [rsp], xmm1
000075038bdde10c  movaps [rsp+0x10], xmm13
000075038bdde112  movaps [rsp+0x20], xmm8
000075038bdde118  lea rdi, [rsp]
000075038bdde11c  mov esi, 0x00
000075038bdde121  mov rax, 0x56ADB4492530
000075038bdde12b  call rax
000075038bdde12d  movaps xmm1, [rsp]
000075038bdde131  add rsp, 0x30
000075038bdde135  vmovaps xmm0, [rsp]
000075038bdde13a  vmovaps xmm2, [rsp+0x10]
000075038bdde140  vmovaps xmm3, [rsp+0x20]
000075038bdde146  vmovaps xmm4, [rsp+0x30]
000075038bdde14c  vmovaps xmm5, [rsp+0x40]
000075038bdde152  vmovaps xmm6, [rsp+0x50]
000075038bdde158  vmovaps xmm7, [rsp+0x60]
000075038bdde15e  vmovaps xmm8, [rsp+0x70]
000075038bdde164  vmovaps xmm9, [rsp+0x80]
000075038bdde16d  vmovaps xmm10, [rsp+0x90]
000075038bdde176  vmovaps xmm11, [rsp+0xA0]
000075038bdde17f  vmovaps xmm12, [rsp+0xB0]
000075038bdde188  vmovaps xmm13, [rsp+0xC0]
000075038bdde191  vmovaps xmm14, [rsp+0xD0]
000075038bdde19a  vmovaps xmm15, [rsp+0xE0]
000075038bdde1a3  add rsp, 0xF0
000075038bdde1aa  pop r11
000075038bdde1ac  pop r10
000075038bdde1ae  pop r9
000075038bdde1b0  pop r8
000075038bdde1b2  pop rsi
000075038bdde1b3  pop rdi
000075038bdde1b4  pop rdx
000075038bdde1b5  pop rcx
000075038bdde1b6  pop rax
000075038bdde1b7  add rsp, 0x08
000075038bdde1bb  jmp 0x000075038BDD977A
000075038bdde1c0  call 0x000075038BC0C260
000075038bdde1c5  jmp 0x000075038BDD9788
000075038bdde1ca  call 0x000075038BCDE950
000075038bdde1cf  jmp 0x000075038BDD9792
000075038bdde1d4  sub rsp, 0x08
000075038bdde1d8  push rax
000075038bdde1d9  push rcx
000075038bdde1da  push rdx
000075038bdde1db  push rdi
000075038bdde1dc  push rsi
000075038bdde1dd  push r8
000075038bdde1df  push r9
000075038bdde1e1  push r10
000075038bdde1e3  push r11
000075038bdde1e5  sub rsp, 0xF0
000075038bdde1ec  vmovaps [rsp], xmm0
000075038bdde1f1  vmovaps [rsp+0x10], xmm1
000075038bdde1f7  vmovaps [rsp+0x20], xmm2
000075038bdde1fd  vmovaps [rsp+0x30], xmm3
000075038bdde203  vmovaps [rsp+0x40], xmm4
000075038bdde209  vmovaps [rsp+0x50], xmm5
000075038bdde20f  vmovaps [rsp+0x60], xmm6
000075038bdde215  vmovaps [rsp+0x70], xmm7
000075038bdde21b  vmovaps [rsp+0x80], xmm9
000075038bdde224  vmovaps [rsp+0x90], xmm10
000075038bdde22d  vmovaps [rsp+0xA0], xmm11
000075038bdde236  vmovaps [rsp+0xB0], xmm12
000075038bdde23f  vmovaps [rsp+0xC0], xmm13
000075038bdde248  vmovaps [rsp+0xD0], xmm14
000075038bdde251  vmovaps [rsp+0xE0], xmm15
000075038bdde25a  sub rsp, 0x30
000075038bdde25e  movaps [rsp], xmm8
000075038bdde263  movaps [rsp+0x10], xmm15
000075038bdde269  movaps [rsp+0x20], xmm7
000075038bdde26e  lea rdi, [rsp]
000075038bdde272  mov esi, 0x00
000075038bdde277  mov rax, 0x56ADB4492530
000075038bdde281  call rax
000075038bdde283  movaps xmm8, [rsp]
000075038bdde288  add rsp, 0x30
000075038bdde28c  vmovaps xmm0, [rsp]
000075038bdde291  vmovaps xmm1, [rsp+0x10]
000075038bdde297  vmovaps xmm2, [rsp+0x20]
000075038bdde29d  vmovaps xmm3, [rsp+0x30]
000075038bdde2a3  vmovaps xmm4, [rsp+0x40]
000075038bdde2a9  vmovaps xmm5, [rsp+0x50]
000075038bdde2af  vmovaps xmm6, [rsp+0x60]
000075038bdde2b5  vmovaps xmm7, [rsp+0x70]
000075038bdde2bb  vmovaps xmm9, [rsp+0x80]
000075038bdde2c4  vmovaps xmm10, [rsp+0x90]
000075038bdde2cd  vmovaps xmm11, [rsp+0xA0]
000075038bdde2d6  vmovaps xmm12, [rsp+0xB0]
000075038bdde2df  vmovaps xmm13, [rsp+0xC0]
000075038bdde2e8  vmovaps xmm14, [rsp+0xD0]
000075038bdde2f1  vmovaps xmm15, [rsp+0xE0]
000075038bdde2fa  add rsp, 0xF0
000075038bdde301  pop r11
000075038bdde303  pop r10
000075038bdde305  pop r9
000075038bdde307  pop r8
000075038bdde309  pop rsi
000075038bdde30a  pop rdi
000075038bdde30b  pop rdx
000075038bdde30c  pop rcx
000075038bdde30d  pop rax
000075038bdde30e  add rsp, 0x08
000075038bdde312  jmp 0x000075038BDD97B4
000075038bdde317  sub rsp, 0x08
000075038bdde31b  push rax
000075038bdde31c  push rcx
000075038bdde31d  push rdx
000075038bdde31e  push rdi
000075038bdde31f  push rsi
000075038bdde320  push r8
000075038bdde322  push r9
000075038bdde324  push r10
000075038bdde326  push r11
000075038bdde328  sub rsp, 0xF0
000075038bdde32f  vmovaps [rsp], xmm0
000075038bdde334  vmovaps [rsp+0x10], xmm1
000075038bdde33a  vmovaps [rsp+0x20], xmm2
000075038bdde340  vmovaps [rsp+0x30], xmm3
000075038bdde346  vmovaps [rsp+0x40], xmm4
000075038bdde34c  vmovaps [rsp+0x50], xmm5
000075038bdde352  vmovaps [rsp+0x60], xmm6
000075038bdde358  vmovaps [rsp+0x70], xmm8
000075038bdde35e  vmovaps [rsp+0x80], xmm9
000075038bdde367  vmovaps [rsp+0x90], xmm10
000075038bdde370  vmovaps [rsp+0xA0], xmm11
000075038bdde379  vmovaps [rsp+0xB0], xmm12
000075038bdde382  vmovaps [rsp+0xC0], xmm13
000075038bdde38b  vmovaps [rsp+0xD0], xmm14
000075038bdde394  vmovaps [rsp+0xE0], xmm15
000075038bdde39d  sub rsp, 0x30
000075038bdde3a1  movaps [rsp], xmm7
000075038bdde3a5  movaps [rsp+0x10], xmm9
000075038bdde3ab  movaps [rsp+0x20], xmm15
000075038bdde3b1  lea rdi, [rsp]
000075038bdde3b5  mov esi, 0x00
000075038bdde3ba  mov rax, 0x56ADB4492530
000075038bdde3c4  call rax
000075038bdde3c6  movaps xmm7, [rsp]
000075038bdde3ca  add rsp, 0x30
000075038bdde3ce  vmovaps xmm0, [rsp]
000075038bdde3d3  vmovaps xmm1, [rsp+0x10]
000075038bdde3d9  vmovaps xmm2, [rsp+0x20]
000075038bdde3df  vmovaps xmm3, [rsp+0x30]
000075038bdde3e5  vmovaps xmm4, [rsp+0x40]
000075038bdde3eb  vmovaps xmm5, [rsp+0x50]
000075038bdde3f1  vmovaps xmm6, [rsp+0x60]
000075038bdde3f7  vmovaps xmm8, [rsp+0x70]
000075038bdde3fd  vmovaps xmm9, [rsp+0x80]
000075038bdde406  vmovaps xmm10, [rsp+0x90]
000075038bdde40f  vmovaps xmm11, [rsp+0xA0]
000075038bdde418  vmovaps xmm12, [rsp+0xB0]
000075038bdde421  vmovaps xmm13, [rsp+0xC0]
000075038bdde42a  vmovaps xmm14, [rsp+0xD0]
000075038bdde433  vmovaps xmm15, [rsp+0xE0]
000075038bdde43c  add rsp, 0xF0
000075038bdde443  pop r11
000075038bdde445  pop r10
000075038bdde447  pop r9
000075038bdde449  pop r8
000075038bdde44b  pop rsi
000075038bdde44c  pop rdi
000075038bdde44d  pop rdx
000075038bdde44e  pop rcx
000075038bdde44f  pop rax
000075038bdde450  add rsp, 0x08
000075038bdde454  jmp 0x000075038BDD97E1
000075038bdde459  sub rsp, 0x08
000075038bdde45d  push rax
000075038bdde45e  push rcx
000075038bdde45f  push rdx
000075038bdde460  push rdi
000075038bdde461  push rsi
000075038bdde462  push r8
000075038bdde464  push r9
000075038bdde466  push r10
000075038bdde468  push r11
000075038bdde46a  sub rsp, 0xF0
000075038bdde471  vmovaps [rsp], xmm0
000075038bdde476  vmovaps [rsp+0x10], xmm1
000075038bdde47c  vmovaps [rsp+0x20], xmm2
000075038bdde482  vmovaps [rsp+0x30], xmm3
000075038bdde488  vmovaps [rsp+0x40], xmm4
000075038bdde48e  vmovaps [rsp+0x50], xmm5
000075038bdde494  vmovaps [rsp+0x60], xmm6
000075038bdde49a  vmovaps [rsp+0x70], xmm7
000075038bdde4a0  vmovaps [rsp+0x80], xmm8
000075038bdde4a9  vmovaps [rsp+0x90], xmm10
000075038bdde4b2  vmovaps [rsp+0xA0], xmm11
000075038bdde4bb  vmovaps [rsp+0xB0], xmm12
000075038bdde4c4  vmovaps [rsp+0xC0], xmm13
000075038bdde4cd  vmovaps [rsp+0xD0], xmm14
000075038bdde4d6  vmovaps [rsp+0xE0], xmm15
000075038bdde4df  sub rsp, 0x30
000075038bdde4e3  movaps [rsp], xmm9
000075038bdde4e8  movaps [rsp+0x10], xmm13
000075038bdde4ee  movaps [rsp+0x20], xmm15
000075038bdde4f4  lea rdi, [rsp]
000075038bdde4f8  mov esi, 0x00
000075038bdde4fd  mov rax, 0x56ADB4492530
000075038bdde507  call rax
000075038bdde509  movaps xmm9, [rsp]
000075038bdde50e  add rsp, 0x30
000075038bdde512  vmovaps xmm0, [rsp]
000075038bdde517  vmovaps xmm1, [rsp+0x10]
000075038bdde51d  vmovaps xmm2, [rsp+0x20]
000075038bdde523  vmovaps xmm3, [rsp+0x30]
000075038bdde529  vmovaps xmm4, [rsp+0x40]
000075038bdde52f  vmovaps xmm5, [rsp+0x50]
000075038bdde535  vmovaps xmm6, [rsp+0x60]
000075038bdde53b  vmovaps xmm7, [rsp+0x70]
000075038bdde541  vmovaps xmm8, [rsp+0x80]
000075038bdde54a  vmovaps xmm10, [rsp+0x90]
000075038bdde553  vmovaps xmm11, [rsp+0xA0]
000075038bdde55c  vmovaps xmm12, [rsp+0xB0]
000075038bdde565  vmovaps xmm13, [rsp+0xC0]
000075038bdde56e  vmovaps xmm14, [rsp+0xD0]
000075038bdde577  vmovaps xmm15, [rsp+0xE0]
000075038bdde580  add rsp, 0xF0
000075038bdde587  pop r11
000075038bdde589  pop r10
000075038bdde58b  pop r9
000075038bdde58d  pop r8
000075038bdde58f  pop rsi
000075038bdde590  pop rdi
000075038bdde591  pop rdx
000075038bdde592  pop rcx
000075038bdde593  pop rax
000075038bdde594  add rsp, 0x08
000075038bdde598  jmp 0x000075038BDD980F
000075038bdde59d  sub rsp, 0x08
000075038bdde5a1  push rax
000075038bdde5a2  push rcx
000075038bdde5a3  push rdx
000075038bdde5a4  push rdi
000075038bdde5a5  push rsi
000075038bdde5a6  push r8
000075038bdde5a8  push r9
000075038bdde5aa  push r10
000075038bdde5ac  push r11
000075038bdde5ae  sub rsp, 0xF0
000075038bdde5b5  vmovaps [rsp], xmm0
000075038bdde5ba  vmovaps [rsp+0x10], xmm1
000075038bdde5c0  vmovaps [rsp+0x20], xmm2
000075038bdde5c6  vmovaps [rsp+0x30], xmm3
000075038bdde5cc  vmovaps [rsp+0x40], xmm4
000075038bdde5d2  vmovaps [rsp+0x50], xmm5
000075038bdde5d8  vmovaps [rsp+0x60], xmm6
000075038bdde5de  vmovaps [rsp+0x70], xmm7
000075038bdde5e4  vmovaps [rsp+0x80], xmm8
000075038bdde5ed  vmovaps [rsp+0x90], xmm9
000075038bdde5f6  vmovaps [rsp+0xA0], xmm10
000075038bdde5ff  vmovaps [rsp+0xB0], xmm11
000075038bdde608  vmovaps [rsp+0xC0], xmm12
000075038bdde611  vmovaps [rsp+0xD0], xmm13
000075038bdde61a  vmovaps [rsp+0xE0], xmm14
000075038bdde623  sub rsp, 0x30
000075038bdde627  movaps [rsp], xmm15
000075038bdde62c  movaps [rsp+0x10], xmm11
000075038bdde632  movaps [rsp+0x20], xmm12
000075038bdde638  lea rdi, [rsp]
000075038bdde63c  mov esi, 0x00
000075038bdde641  mov rax, 0x56ADB4492530
000075038bdde64b  call rax
000075038bdde64d  movaps xmm15, [rsp]
000075038bdde652  add rsp, 0x30
000075038bdde656  vmovaps xmm0, [rsp]
000075038bdde65b  vmovaps xmm1, [rsp+0x10]
000075038bdde661  vmovaps xmm2, [rsp+0x20]
000075038bdde667  vmovaps xmm3, [rsp+0x30]
000075038bdde66d  vmovaps xmm4, [rsp+0x40]
000075038bdde673  vmovaps xmm5, [rsp+0x50]
000075038bdde679  vmovaps xmm6, [rsp+0x60]
000075038bdde67f  vmovaps xmm7, [rsp+0x70]
000075038bdde685  vmovaps xmm8, [rsp+0x80]
000075038bdde68e  vmovaps xmm9, [rsp+0x90]
000075038bdde697  vmovaps xmm10, [rsp+0xA0]
000075038bdde6a0  vmovaps xmm11, [rsp+0xB0]
000075038bdde6a9  vmovaps xmm12, [rsp+0xC0]
000075038bdde6b2  vmovaps xmm13, [rsp+0xD0]
000075038bdde6bb  vmovaps xmm14, [rsp+0xE0]
000075038bdde6c4  add rsp, 0xF0
000075038bdde6cb  pop r11
000075038bdde6cd  pop r10
000075038bdde6cf  pop r9
000075038bdde6d1  pop r8
000075038bdde6d3  pop rsi
000075038bdde6d4  pop rdi
000075038bdde6d5  pop rdx
000075038bdde6d6  pop rcx
000075038bdde6d7  pop rax
000075038bdde6d8  add rsp, 0x08
000075038bdde6dc  jmp 0x000075038BDD982A
000075038bdde6e1  sub rsp, 0x08
000075038bdde6e5  push rax
000075038bdde6e6  push rcx
000075038bdde6e7  push rdx
000075038bdde6e8  push rdi
000075038bdde6e9  push rsi
000075038bdde6ea  push r8
000075038bdde6ec  push r9
000075038bdde6ee  push r10
000075038bdde6f0  push r11
000075038bdde6f2  sub rsp, 0xF0
000075038bdde6f9  vmovaps [rsp], xmm0
000075038bdde6fe  vmovaps [rsp+0x10], xmm1
000075038bdde704  vmovaps [rsp+0x20], xmm2
000075038bdde70a  vmovaps [rsp+0x30], xmm3
000075038bdde710  vmovaps [rsp+0x40], xmm4
000075038bdde716  vmovaps [rsp+0x50], xmm5
000075038bdde71c  vmovaps [rsp+0x60], xmm6
000075038bdde722  vmovaps [rsp+0x70], xmm7
000075038bdde728  vmovaps [rsp+0x80], xmm8
000075038bdde731  vmovaps [rsp+0x90], xmm9
000075038bdde73a  vmovaps [rsp+0xA0], xmm10
000075038bdde743  vmovaps [rsp+0xB0], xmm11
000075038bdde74c  vmovaps [rsp+0xC0], xmm12
000075038bdde755  vmovaps [rsp+0xD0], xmm14
000075038bdde75e  vmovaps [rsp+0xE0], xmm15
000075038bdde767  sub rsp, 0x30
000075038bdde76b  movaps [rsp], xmm13
000075038bdde770  movaps [rsp+0x10], xmm10
000075038bdde776  movaps [rsp+0x20], xmm14
000075038bdde77c  lea rdi, [rsp]
000075038bdde780  mov esi, 0x00
000075038bdde785  mov rax, 0x56ADB4492530
000075038bdde78f  call rax
000075038bdde791  movaps xmm13, [rsp]
000075038bdde796  add rsp, 0x30
000075038bdde79a  vmovaps xmm0, [rsp]
000075038bdde79f  vmovaps xmm1, [rsp+0x10]
000075038bdde7a5  vmovaps xmm2, [rsp+0x20]
000075038bdde7ab  vmovaps xmm3, [rsp+0x30]
000075038bdde7b1  vmovaps xmm4, [rsp+0x40]
000075038bdde7b7  vmovaps xmm5, [rsp+0x50]
000075038bdde7bd  vmovaps xmm6, [rsp+0x60]
000075038bdde7c3  vmovaps xmm7, [rsp+0x70]
000075038bdde7c9  vmovaps xmm8, [rsp+0x80]
000075038bdde7d2  vmovaps xmm9, [rsp+0x90]
000075038bdde7db  vmovaps xmm10, [rsp+0xA0]
000075038bdde7e4  vmovaps xmm11, [rsp+0xB0]
000075038bdde7ed  vmovaps xmm12, [rsp+0xC0]
000075038bdde7f6  vmovaps xmm14, [rsp+0xD0]
000075038bdde7ff  vmovaps xmm15, [rsp+0xE0]
000075038bdde808  add rsp, 0xF0
000075038bdde80f  pop r11
000075038bdde811  pop r10
000075038bdde813  pop r9
000075038bdde815  pop r8
000075038bdde817  pop rsi
000075038bdde818  pop rdi
000075038bdde819  pop rdx
000075038bdde81a  pop rcx
000075038bdde81b  pop rax
000075038bdde81c  add rsp, 0x08
000075038bdde820  jmp 0x000075038BDD984D
000075038bdde825  sub rsp, 0x08
000075038bdde829  push rax
000075038bdde82a  push rcx
000075038bdde82b  push rdx
000075038bdde82c  push rdi
000075038bdde82d  push rsi
000075038bdde82e  push r8
000075038bdde830  push r9
000075038bdde832  push r10
000075038bdde834  push r11
000075038bdde836  sub rsp, 0xF0
000075038bdde83d  vmovaps [rsp], xmm0
000075038bdde842  vmovaps [rsp+0x10], xmm1
000075038bdde848  vmovaps [rsp+0x20], xmm2
000075038bdde84e  vmovaps [rsp+0x30], xmm3
000075038bdde854  vmovaps [rsp+0x40], xmm4
000075038bdde85a  vmovaps [rsp+0x50], xmm5
000075038bdde860  vmovaps [rsp+0x60], xmm6
000075038bdde866  vmovaps [rsp+0x70], xmm7
000075038bdde86c  vmovaps [rsp+0x80], xmm8
000075038bdde875  vmovaps [rsp+0x90], xmm9
000075038bdde87e  vmovaps [rsp+0xA0], xmm10
000075038bdde887  vmovaps [rsp+0xB0], xmm11
000075038bdde890  vmovaps [rsp+0xC0], xmm12
000075038bdde899  vmovaps [rsp+0xD0], xmm13
000075038bdde8a2  vmovaps [rsp+0xE0], xmm15
000075038bdde8ab  sub rsp, 0x30
000075038bdde8af  movaps [rsp], xmm14
000075038bdde8b4  movaps [rsp+0x10], xmm1
000075038bdde8b9  movaps [rsp+0x20], xmm7
000075038bdde8be  lea rdi, [rsp]
000075038bdde8c2  mov esi, 0x00
000075038bdde8c7  mov rax, 0x56ADB4492530
000075038bdde8d1  call rax
000075038bdde8d3  movaps xmm14, [rsp]
000075038bdde8d8  add rsp, 0x30
000075038bdde8dc  vmovaps xmm0, [rsp]
000075038bdde8e1  vmovaps xmm1, [rsp+0x10]
000075038bdde8e7  vmovaps xmm2, [rsp+0x20]
000075038bdde8ed  vmovaps xmm3, [rsp+0x30]
000075038bdde8f3  vmovaps xmm4, [rsp+0x40]
000075038bdde8f9  vmovaps xmm5, [rsp+0x50]
000075038bdde8ff  vmovaps xmm6, [rsp+0x60]
000075038bdde905  vmovaps xmm7, [rsp+0x70]
000075038bdde90b  vmovaps xmm8, [rsp+0x80]
000075038bdde914  vmovaps xmm9, [rsp+0x90]
000075038bdde91d  vmovaps xmm10, [rsp+0xA0]
000075038bdde926  vmovaps xmm11, [rsp+0xB0]
000075038bdde92f  vmovaps xmm12, [rsp+0xC0]
000075038bdde938  vmovaps xmm13, [rsp+0xD0]
000075038bdde941  vmovaps xmm15, [rsp+0xE0]
000075038bdde94a  add rsp, 0xF0
000075038bdde951  pop r11
000075038bdde953  pop r10
000075038bdde955  pop r9
000075038bdde957  pop r8
000075038bdde959  pop rsi
000075038bdde95a  pop rdi
000075038bdde95b  pop rdx
000075038bdde95c  pop rcx
000075038bdde95d  pop rax
000075038bdde95e  add rsp, 0x08
000075038bdde962  jmp 0x000075038BDD9870
000075038bdde967  sub rsp, 0x08
000075038bdde96b  push rax
000075038bdde96c  push rcx
000075038bdde96d  push rdx
000075038bdde96e  push rdi
000075038bdde96f  push rsi
000075038bdde970  push r8
000075038bdde972  push r9
000075038bdde974  push r10
000075038bdde976  push r11
000075038bdde978  sub rsp, 0xF0
000075038bdde97f  vmovaps [rsp], xmm0
000075038bdde984  vmovaps [rsp+0x10], xmm2
000075038bdde98a  vmovaps [rsp+0x20], xmm3
000075038bdde990  vmovaps [rsp+0x30], xmm4
000075038bdde996  vmovaps [rsp+0x40], xmm5
000075038bdde99c  vmovaps [rsp+0x50], xmm6
000075038bdde9a2  vmovaps [rsp+0x60], xmm7
000075038bdde9a8  vmovaps [rsp+0x70], xmm8
000075038bdde9ae  vmovaps [rsp+0x80], xmm9
000075038bdde9b7  vmovaps [rsp+0x90], xmm10
000075038bdde9c0  vmovaps [rsp+0xA0], xmm11
000075038bdde9c9  vmovaps [rsp+0xB0], xmm12
000075038bdde9d2  vmovaps [rsp+0xC0], xmm13
000075038bdde9db  vmovaps [rsp+0xD0], xmm14
000075038bdde9e4  vmovaps [rsp+0xE0], xmm15
000075038bdde9ed  sub rsp, 0x30
000075038bdde9f1  movaps [rsp], xmm1
000075038bdde9f5  movaps [rsp+0x10], xmm8
000075038bdde9fb  movaps [rsp+0x20], xmm9
000075038bddea01  lea rdi, [rsp]
000075038bddea05  mov esi, 0x00
000075038bddea0a  mov rax, 0x56ADB4492530
000075038bddea14  call rax
000075038bddea16  movaps xmm1, [rsp]
000075038bddea1a  add rsp, 0x30
000075038bddea1e  vmovaps xmm0, [rsp]
000075038bddea23  vmovaps xmm2, [rsp+0x10]
000075038bddea29  vmovaps xmm3, [rsp+0x20]
000075038bddea2f  vmovaps xmm4, [rsp+0x30]
000075038bddea35  vmovaps xmm5, [rsp+0x40]
000075038bddea3b  vmovaps xmm6, [rsp+0x50]
000075038bddea41  vmovaps xmm7, [rsp+0x60]
000075038bddea47  vmovaps xmm8, [rsp+0x70]
000075038bddea4d  vmovaps xmm9, [rsp+0x80]
000075038bddea56  vmovaps xmm10, [rsp+0x90]
000075038bddea5f  vmovaps xmm11, [rsp+0xA0]
000075038bddea68  vmovaps xmm12, [rsp+0xB0]
000075038bddea71  vmovaps xmm13, [rsp+0xC0]
000075038bddea7a  vmovaps xmm14, [rsp+0xD0]
000075038bddea83  vmovaps xmm15, [rsp+0xE0]
000075038bddea8c  add rsp, 0xF0
000075038bddea93  pop r11
000075038bddea95  pop r10
000075038bddea97  pop r9
000075038bddea99  pop r8
000075038bddea9b  pop rsi
000075038bddea9c  pop rdi
000075038bddea9d  pop rdx
000075038bddea9e  pop rcx
000075038bddea9f  pop rax
000075038bddeaa0  add rsp, 0x08
000075038bddeaa4  jmp 0x000075038BDD9892
000075038bddeaa9  call 0x000075038BCB3E40
000075038bddeaae  jmp 0x000075038BDD98A0
000075038bddeab3  call 0x000075038BC0C380
000075038bddeab8  jmp 0x000075038BDD98AA
000075038bddeabd  call 0x000075038BC0D600
000075038bddeac2  jmp 0x000075038BDD98B4
000075038bddeac7  call 0x000075038BBFF540
000075038bddeacc  jmp 0x000075038BDD98BE
000075038bddead1  int3
000075038bddead2  nop [rax+rax*1], ax
000075038bddeadb  nop [rax+rax*1], eax
000075038bddeae0  mov eax, [r15+0x48]
000075038bddeae4  lea r14d, [eax+0x01]
000075038bddeae9  mov [rsp+0x10], r14d
000075038bddeaee  mov r14d, r14d
000075038bddeaf1  mov [r15+0x48], r14
000075038bddeaf5  xor eax, eax
000075038bddeaf7  mov r14d, [rsp+0x10]
000075038bddeafc  cmp r14d, 0x1F4
000075038bddeb03  cmc
000075038bddeb04  lahf
000075038bddeb05  seto al
000075038bddeb08  mov [r15+0x108], eax
000075038bddeb0f  mov eax, [r15+0x108]
000075038bddeb16  sahf
000075038bddeb17  jnz 0x000075038BDDEB49
000075038bddeb19  cmp dword ptr [r15+0x318], 0x00
000075038bddeb21  jz 0x000075038BDE4C90
000075038bddeb27  nop [rax+rax*1], ax
000075038bddeb30  nop [rax+rax*1], eax
000075038bddeb38  mov eax, 0x4106DC
000075038bddeb3d  mov [r15+0x100], rax
000075038bddeb44  jmp 0x000075038BBFE110
000075038bddeb49  cmp dword ptr [r15+0x318], 0x00
000075038bddeb51  jz 0x000075038BDDEB80
000075038bddeb57  nop [rax+rax*1], ax
000075038bddeb60  nop [rax+rax*1], eax
000075038bddeb68  mov eax, 0x410500
000075038bddeb6d  mov [r15+0x100], rax
000075038bddeb74  jmp 0x000075038BBFE110
000075038bddeb79  int3
000075038bddeb7a  int3
000075038bddeb7b  nop [rax+rax*1], eax
000075038bddeb80  mov rax, [r15+0x40]
000075038bddeb84  movaps xmm1, [r15+0x1D0]
000075038bddeb8c  vmovaps [rsp+0x10], xmm1
000075038bddeb92  vmovaps xmm15, [rsp+0x10]
000075038bddeb98  por xmm1, xmm15
000075038bddeb9d  movaps xmm14, [r15+0x1A0]
000075038bddeba5  vmovaps [rsp+0x10], xmm14
000075038bddebab  vmovaps xmm13, [rsp+0x10]
000075038bddebb1  por xmm14, xmm13
000075038bddebb6  lea r14, [rax+0x30]
000075038bddebba  mov r12, [r13+r14*1]
000075038bddebbf  lea r14, [rax+0x38]
000075038bddebc3  mov r11, [r13+r14*1]
000075038bddebc8  movq xmm13, r12
000075038bddebcd  movq xmm12, r11
000075038bddebd2  movq xmm13, xmm13
000075038bddebd7  vmovaps [rsp+0x10], xmm13
000075038bddebdd  movq xmm13, xmm13
000075038bddebe2  movaps [r15+0x130], xmm13
000075038bddebea  movq xmm12, xmm12
000075038bddebef  vmovaps [rsp+0x20], xmm12
000075038bddebf5  movq xmm12, xmm12
000075038bddebfa  movaps [r15+0x280], xmm12
000075038bddec02  movaps xmm13, [r15+0x270]
000075038bddec0a  vmovaps [rsp+0x30], xmm13
000075038bddec10  vmovaps xmm12, [rsp+0x30]
000075038bddec16  por xmm13, xmm12
000075038bddec1b  lea r14, [rax+0x20]
000075038bddec1f  mov r12, [r13+r14*1]
000075038bddec24  lea r14, [rax+0x28]
000075038bddec28  mov r11, [r13+r14*1]
000075038bddec2d  movq xmm12, r12
000075038bddec32  movq xmm11, r11
000075038bddec37  movq xmm12, xmm12
000075038bddec3c  vmovaps [rsp+0x30], xmm12
000075038bddec42  movq xmm12, xmm12
000075038bddec47  movaps [r15+0x150], xmm12
000075038bddec4f  movq xmm11, xmm11
000075038bddec54  vmovaps [rsp+0x40], xmm11
000075038bddec5a  movq xmm11, xmm11
000075038bddec5f  movaps [r15+0x140], xmm11
000075038bddec67  lea r14, [rax+0x10]
000075038bddec6b  mov r12, [r13+r14*1]
000075038bddec70  lea r14, [rax+0x18]
000075038bddec74  mov r11, [r13+r14*1]
000075038bddec79  movq xmm12, r12
000075038bddec7e  movq xmm11, r11
000075038bddec83  movq xmm12, xmm12
000075038bddec88  vmovaps [rsp+0x50], xmm12
000075038bddec8e  movq xmm12, xmm12
000075038bddec93  movaps [r15+0x170], xmm12
000075038bddec9b  movq xmm11, xmm11
000075038bddeca0  vmovaps [rsp+0x60], xmm11
000075038bddeca6  movq xmm11, xmm11
000075038bddecab  movaps [r15+0x160], xmm11
000075038bddecb3  mov r14, [r13+rax*1]
000075038bddecb8  vmovq xmm12, r14
000075038bddecbd  vpbroadcastq xmm12, xmm12
000075038bddecc2  lea r14, [rax+0x08]
000075038bddecc6  mov rax, [r13+r14*1]
000075038bddeccb  movq xmm11, rax
000075038bddecd0  movaps [r15+0x230], xmm11
000075038bddecd8  mov rax, [r15+0xF8]
000075038bddecdf  lea r14, [rax+0x50]
000075038bddece3  movups xmm11, [r13+r14*1]
000075038bddece9  lea r14, [rax+0x60]
000075038bddeced  movups xmm10, [r13+r14*1]
000075038bddecf3  lea r14, [rax+0x30]
000075038bddecf7  movups xmm9, [r13+r14*1]
000075038bddecfd  mov r14, [r15+0x50]
000075038bdded01  mov [r15+0x60], r14
000075038bdded05  mov qword ptr [r15+0x58], 0x40
000075038bdded0d  movaps xmm8, xmm12
000075038bdded11  mulpd xmm8, xmm15
000075038bdded16  vcmppd xmm7, xmm8, xmm8, 0x03
000075038bdded1c  ptest xmm7, xmm7
000075038bdded21  jnz 0x000075038BDDFB4A
000075038bdded27  movq xmm15, qword ptr [r15+0x230]
000075038bdded30  vmovaps [rsp+0x70], xmm15
000075038bdded36  vpermilpd xmm15, xmm15, 0x00
000075038bdded3c  movaps xmm7, xmm9
000075038bdded40  mulpd xmm7, xmm15
000075038bdded45  vcmppd xmm6, xmm7, xmm7, 0x03
000075038bdded4a  ptest xmm6, xmm6
000075038bdded4f  jnz 0x000075038BDDFC8E
000075038bdded55  vxorps xmm15, xmm15, xmm15
000075038bdded5a  vpbroadcastq xmm15, xmm15
000075038bdded5f  movaps xmm9, xmm12
000075038bdded63  mulpd xmm9, xmm10
000075038bdded68  vcmppd xmm6, xmm9, xmm9, 0x03
000075038bdded6e  ptest xmm6, xmm6
000075038bdded73  jnz 0x000075038BDDFDD0
000075038bdded79  movaps xmm10, xmm12
000075038bdded7d  mulpd xmm10, xmm11
000075038bdded82  vcmppd xmm6, xmm10, xmm10, 0x03
000075038bdded88  ptest xmm6, xmm6
000075038bdded8d  jnz 0x000075038BDDFF14
000075038bdded93  movaps xmm11, [r15+0x1F0]
000075038bdded9b  movaps xmm6, xmm12
000075038bdded9f  mulpd xmm6, xmm11
000075038bddeda4  vcmppd xmm5, xmm6, xmm6, 0x03
000075038bddeda9  ptest xmm5, xmm5
000075038bddedae  jnz 0x000075038BDE0058
000075038bddedb4  movaps xmm12, [r15+0x2A0]
000075038bddedbc  vmovaps [rsp+0x80], xmm12
000075038bddedc5  vmovaps xmm11, [rsp+0x80]
000075038bddedce  por xmm12, xmm11
000075038bddedd3  movaps xmm11, [r15+0x250]
000075038bddeddb  vmovaps [rsp+0x80], xmm11
000075038bddede4  vmovaps xmm5, [rsp+0x80]
000075038bddeded  por xmm11, xmm5
000075038bddedf2  vmovaps xmm4, [rsp+0x70]
000075038bddedf8  vpermilpd xmm4, xmm4, 0x00
000075038bddedfe  movaps xmm3, xmm5
000075038bddee01  mulpd xmm3, xmm4
000075038bddee05  vcmppd xmm2, xmm3, xmm3, 0x03
000075038bddee0a  ptest xmm2, xmm2
000075038bddee0f  jnz 0x000075038BDE019A
000075038bddee15  mov [rsp+0x80], rax
000075038bddee1d  xor eax, eax
000075038bddee1f  mov r12d, 0x40
000075038bddee25  mov r11d, 0x200
000075038bddee2b  cmp r12, r11
000075038bddee2e  cmc
000075038bddee2f  lahf
000075038bddee30  seto al
000075038bddee33  mov [r15+0x108], eax
000075038bddee3a  movaps xmm5, xmm8
000075038bddee3e  addpd xmm5, xmm15
000075038bddee43  vcmppd xmm4, xmm5, xmm5, 0x03
000075038bddee48  ptest xmm4, xmm4
000075038bddee4d  jnz 0x000075038BDE02DA
000075038bddee53  movaps xmm8, [r15+0x1B0]
000075038bddee5b  movaps xmm4, xmm9
000075038bddee5f  addpd xmm4, xmm8
000075038bddee64  vcmppd xmm2, xmm4, xmm4, 0x03
000075038bddee69  ptest xmm2, xmm2
000075038bddee6e  jnz 0x000075038BDE041C
000075038bddee74  movaps xmm9, xmm10
000075038bddee78  addpd xmm9, xmm8
000075038bddee7d  vcmppd xmm2, xmm9, xmm9, 0x03
000075038bddee83  ptest xmm2, xmm2
000075038bddee88  jnz 0x000075038BDE055E
000075038bddee8e  movaps xmm10, [r15+0x2F0]
000075038bddee96  vmovaps [rsp+0x90], xmm10
000075038bddee9f  vmovaps xmm8, [rsp+0x90]
000075038bddeea8  por xmm10, xmm8
000075038bddeead  movaps xmm8, [r15+0x2E0]
000075038bddeeb5  vmovaps [rsp+0x90], xmm8
000075038bddeebe  vmovaps xmm2, [rsp+0x90]
000075038bddeec7  por xmm8, xmm2
000075038bddeecc  movaps xmm2, [r15+0x2D0]
000075038bddeed4  vmovaps [rsp+0x90], xmm2
000075038bddeedd  vmovaps [rsp+0xA0], xmm1
000075038bddeee6  vmovaps xmm1, [rsp+0x90]
000075038bddeeef  por xmm2, xmm1
000075038bddeef3  movaps xmm1, [r15+0x200]
000075038bddeefb  vmovaps [rsp+0x90], xmm1
000075038bddef04  vmovaps [rsp+0xB0], xmm15
000075038bddef0d  vmovaps xmm15, [rsp+0x90]
000075038bddef16  por xmm1, xmm15
000075038bddef1b  movaps xmm15, [r15+0x1C0]
000075038bddef23  vmovaps [rsp+0x90], xmm15
000075038bddef2c  vmovaps [rsp+0xC0], xmm1
000075038bddef35  vmovaps xmm1, [rsp+0x90]
000075038bddef3e  por xmm15, xmm1
000075038bddef43  movaps xmm1, [r15+0x190]
000075038bddef4b  vmovaps [rsp+0x90], xmm1
000075038bddef54  vmovaps [rsp+0xD0], xmm15
000075038bddef5d  vmovaps xmm15, [rsp+0x90]
000075038bddef66  por xmm1, xmm15
000075038bddef6b  movaps xmm15, [r15+0x300]
000075038bddef73  vmovaps [rsp+0x90], xmm15
000075038bddef7c  vmovaps [rsp+0xE0], xmm1
000075038bddef85  vmovaps xmm1, [rsp+0x90]
000075038bddef8e  por xmm15, xmm1
000075038bddef93  mov rax, [rsp+0x80]
000075038bddef9b  lea r12, [rax+0xA0]
000075038bddefa2  movups xmm1, [r13+r12*1]
000075038bddefa8  lea r12, [rax+0xB0]
000075038bddefaf  vmovaps [rsp+0x80], xmm1
000075038bddefb8  movups xmm1, [r13+r12*1]
000075038bddefbe  vmovaps [rsp+0x90], xmm1
000075038bddefc7  vmovaps [rsp+0xF0], xmm15
000075038bddefd0  vmovaps xmm15, [rsp+0xB0]
000075038bddefd9  vmovaps [rsp+0xB0], xmm14
000075038bddefe2  movaps xmm1, xmm6
000075038bddefe5  addpd xmm1, xmm15
000075038bddefea  vcmppd xmm14, xmm1, xmm1, 0x03
000075038bddefef  ptest xmm14, xmm14
000075038bddeff5  jnz 0x000075038BDE06B6
000075038bddeffb  lea r12, [rax+0xF0]
000075038bddf002  movups xmm15, [r13+r12*1]
000075038bddf008  movaps xmm14, xmm4
000075038bddf00c  addpd xmm14, xmm3
000075038bddf011  vcmppd xmm6, xmm14, xmm14, 0x03
000075038bddf017  ptest xmm6, xmm6
000075038bddf01c  jnz 0x000075038BDE0801
000075038bddf022  movaps xmm6, xmm9
000075038bddf026  addpd xmm6, xmm7
000075038bddf02a  vcmppd xmm4, xmm6, xmm6, 0x03
000075038bddf02f  ptest xmm4, xmm4
000075038bddf034  jnz 0x000075038BDE0943
000075038bddf03a  vmovaps xmm9, [rsp+0x70]
000075038bddf040  vpermilpd xmm9, xmm9, 0x00
000075038bddf046  vmovaps xmm4, [rsp+0x90]
000075038bddf04f  movaps xmm7, xmm4
000075038bddf052  mulpd xmm7, xmm9
000075038bddf057  vcmppd xmm3, xmm7, xmm7, 0x03
000075038bddf05c  ptest xmm3, xmm3
000075038bddf061  jnz 0x000075038BDE0A84
000075038bddf067  vmovaps xmm9, [rsp+0x50]
000075038bddf06d  vpermilpd xmm9, xmm9, 0x00
000075038bddf073  movaps xmm4, xmm15
000075038bddf077  mulpd xmm4, xmm9
000075038bddf07c  vcmppd xmm3, xmm4, xmm4, 0x03
000075038bddf081  ptest xmm3, xmm3
000075038bddf086  jnz 0x000075038BDE0BC5
000075038bddf08c  lea r12, [rax+0xE0]
000075038bddf093  movups xmm15, [r13+r12*1]
000075038bddf099  vmovaps xmm9, [rsp+0x70]
000075038bddf09f  vpermilpd xmm9, xmm9, 0x00
000075038bddf0a5  vmovaps [rsp+0x70], xmm1
000075038bddf0ab  vmovaps xmm1, [rsp+0x80]
000075038bddf0b4  vmovaps [rsp+0x80], xmm15
000075038bddf0bd  movaps xmm3, xmm1
000075038bddf0c0  mulpd xmm3, xmm9
000075038bddf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
000075038bddf0ca  ptest xmm15, xmm15
000075038bddf0d0  jnz 0x000075038BDE0D11
000075038bddf0d6  vmovaps xmm1, [rsp+0xF0]
000075038bddf0df  vmovaps xmm15, [rsp+0xF0]
000075038bddf0e8  por xmm1, xmm15
000075038bddf0ed  movaps [r15+0x300], xmm1
000075038bddf0f5  vmovaps xmm15, [rsp+0xE0]
000075038bddf0fe  vmovaps xmm9, [rsp+0xE0]
000075038bddf107  por xmm15, xmm9
000075038bddf10c  movaps [r15+0x190], xmm15
000075038bddf114  vmovaps xmm9, [rsp+0x50]
000075038bddf11a  vpermilpd xmm9, xmm9, 0x00
000075038bddf120  vmovaps [rsp+0x90], xmm1
000075038bddf129  vmovaps [rsp+0xE0], xmm15
000075038bddf132  vmovaps xmm15, [rsp+0x80]
000075038bddf13b  vmovaps [rsp+0x80], xmm14
000075038bddf144  movaps xmm1, xmm15
000075038bddf148  mulpd xmm1, xmm9
000075038bddf14d  vcmppd xmm14, xmm1, xmm1, 0x03
000075038bddf152  ptest xmm14, xmm14
000075038bddf158  jnz 0x000075038BDE0E52
000075038bddf15e  lea r12, [rax+0x90]
000075038bddf165  movups xmm15, [r13+r12*1]
000075038bddf16b  vmovaps xmm14, [rsp+0xD0]
000075038bddf174  vmovaps xmm9, [rsp+0xD0]
000075038bddf17d  por xmm14, xmm9
000075038bddf182  movaps [r15+0x1C0], xmm14
000075038bddf18a  vmovaps xmm9, [rsp+0xC0]
000075038bddf193  vmovaps [rsp+0xD0], xmm1
000075038bddf19c  vmovaps xmm1, [rsp+0xC0]
000075038bddf1a5  por xmm9, xmm1
000075038bddf1aa  movaps [r15+0x200], xmm9
000075038bddf1b2  vmovaps [rsp+0xC0], xmm2
000075038bddf1bb  vmovaps xmm1, [rsp+0xC0]
000075038bddf1c4  por xmm2, xmm1
000075038bddf1c8  movaps [r15+0x2D0], xmm2
000075038bddf1d0  vmovaps [rsp+0xC0], xmm8
000075038bddf1d9  vmovaps xmm1, [rsp+0xC0]
000075038bddf1e2  por xmm8, xmm1
000075038bddf1e7  movaps [r15+0x2E0], xmm8
000075038bddf1ef  vmovaps [rsp+0xC0], xmm15
000075038bddf1f8  movaps xmm1, xmm5
000075038bddf1fb  addpd xmm1, xmm7
000075038bddf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
000075038bddf204  ptest xmm15, xmm15
000075038bddf20a  jnz 0x000075038BDE0F9E
000075038bddf210  vmovaps xmm15, [rsp+0x50]
000075038bddf216  vpermilpd xmm15, xmm15, 0x00
000075038bddf21c  vmovaps xmm5, [rsp+0xC0]
000075038bddf225  vmovaps [rsp+0xC0], xmm1
000075038bddf22e  movaps xmm7, xmm5
000075038bddf231  mulpd xmm7, xmm15
000075038bddf236  vcmppd xmm1, xmm7, xmm7, 0x03
000075038bddf23b  ptest xmm1, xmm1
000075038bddf240  jnz 0x000075038BDE10DE
000075038bddf246  lea r12, [rax+0x80]
000075038bddf24d  movups xmm1, [r13+r12*1]
000075038bddf253  vmovaps xmm5, [rsp+0x70]
000075038bddf259  vmovaps [rsp+0x70], xmm1
000075038bddf25f  movaps xmm15, xmm5
000075038bddf263  addpd xmm15, xmm3
000075038bddf268  vcmppd xmm1, xmm15, xmm15, 0x03
000075038bddf26e  ptest xmm1, xmm1
000075038bddf273  jnz 0x000075038BDE1229
000075038bddf279  vmovaps xmm5, [rsp+0x80]
000075038bddf282  movaps xmm1, xmm5
000075038bddf285  addpd xmm1, xmm4
000075038bddf289  vcmppd xmm3, xmm1, xmm1, 0x03
000075038bddf28e  ptest xmm3, xmm3
000075038bddf293  jnz 0x000075038BDE136B
000075038bddf299  vmovaps [rsp+0x80], xmm10
000075038bddf2a2  vmovaps xmm5, [rsp+0x80]
000075038bddf2ab  por xmm10, xmm5
000075038bddf2b0  movaps [r15+0x2F0], xmm10
000075038bddf2b8  vmovaps xmm5, [rsp+0x50]
000075038bddf2be  vpermilpd xmm5, xmm5, 0x00
000075038bddf2c4  vmovaps xmm3, [rsp+0x70]
000075038bddf2ca  vmovaps [rsp+0x50], xmm1
000075038bddf2d0  movaps xmm4, xmm3
000075038bddf2d3  mulpd xmm4, xmm5
000075038bddf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
000075038bddf2dc  ptest xmm1, xmm1
000075038bddf2e1  jnz 0x000075038BDE14AB
000075038bddf2e7  lea r12, [rax+0xD0]
000075038bddf2ee  movups xmm1, [r13+r12*1]
000075038bddf2f4  vmovaps xmm3, [rsp+0xD0]
000075038bddf2fd  vmovaps [rsp+0x70], xmm1
000075038bddf303  movaps xmm5, xmm6
000075038bddf306  addpd xmm5, xmm3
000075038bddf30a  vcmppd xmm1, xmm5, xmm5, 0x03
000075038bddf30f  ptest xmm1, xmm1
000075038bddf314  jnz 0x000075038BDE15F5
000075038bddf31a  vmovaps xmm1, [rsp+0x60]
000075038bddf320  vpermilpd xmm1, xmm1, 0x00
000075038bddf326  movaps xmm6, xmm9
000075038bddf32a  mulpd xmm6, xmm1
000075038bddf32e  vcmppd xmm3, xmm6, xmm6, 0x03
000075038bddf333  ptest xmm3, xmm3
000075038bddf338  jnz 0x000075038BDE1735
000075038bddf33e  movaps [r15+0x260], xmm6
000075038bddf346  vxorps xmm1, xmm1, xmm1
000075038bddf34a  vpbroadcastq xmm1, xmm1
000075038bddf34f  movaps [r15+0x1B0], xmm1
000075038bddf357  vmovaps xmm1, [rsp+0x60]
000075038bddf35d  vpermilpd xmm1, xmm1, 0x00
000075038bddf363  vmovaps xmm3, [rsp+0x70]
000075038bddf369  vmovaps [rsp+0x70], xmm15
000075038bddf36f  movaps xmm9, xmm3
000075038bddf373  mulpd xmm9, xmm1
000075038bddf378  vcmppd xmm15, xmm9, xmm9, 0x03
000075038bddf37e  ptest xmm15, xmm15
000075038bddf384  jnz 0x000075038BDE1876
000075038bddf38a  lea r12, [rax+0xC0]
000075038bddf391  movups xmm1, [r13+r12*1]
000075038bddf397  vmovaps xmm3, [rsp+0xC0]
000075038bddf3a0  vmovaps [rsp+0x80], xmm1
000075038bddf3a9  movaps xmm15, xmm3
000075038bddf3ad  addpd xmm15, xmm7
000075038bddf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
000075038bddf3b8  ptest xmm1, xmm1
000075038bddf3bd  jnz 0x000075038BDE19C2
000075038bddf3c3  vmovaps [rsp+0xC0], xmm13
000075038bddf3cc  vmovaps xmm1, [rsp+0xC0]
000075038bddf3d5  por xmm13, xmm1
000075038bddf3da  movaps [r15+0x270], xmm13
000075038bddf3e2  vmovaps xmm1, [rsp+0xB0]
000075038bddf3eb  vmovaps xmm7, [rsp+0xB0]
000075038bddf3f4  por xmm1, xmm7
000075038bddf3f8  movaps [r15+0x1A0], xmm1
000075038bddf400  vmovaps xmm1, [rsp+0x60]
000075038bddf406  vpermilpd xmm1, xmm1, 0x00
000075038bddf40c  vmovaps [rsp+0xB0], xmm1
000075038bddf415  vmovaps xmm1, [rsp+0x80]
000075038bddf41e  vmovaps [rsp+0x80], xmm15
000075038bddf427  vmovaps xmm15, [rsp+0xB0]
000075038bddf430  vmovaps [rsp+0xB0], xmm14
000075038bddf439  movaps xmm3, xmm1
000075038bddf43c  mulpd xmm3, xmm15
000075038bddf441  vcmppd xmm14, xmm3, xmm3, 0x03
000075038bddf446  ptest xmm14, xmm14
000075038bddf44c  jnz 0x000075038BDE1B04
000075038bddf452  lea r12, [rax+0x20]
000075038bddf456  movups xmm1, [r13+r12*1]
000075038bddf45c  movaps [r15+0x110], xmm1
000075038bddf464  vmovaps xmm14, [rsp+0x70]
000075038bddf46a  vmovaps [rsp+0x70], xmm1
000075038bddf470  movaps xmm15, xmm14
000075038bddf474  addpd xmm15, xmm4
000075038bddf479  vcmppd xmm1, xmm15, xmm15, 0x03
000075038bddf47f  ptest xmm1, xmm1
000075038bddf484  jnz 0x000075038BDE1C4F
000075038bddf48a  vmovaps xmm1, [rsp+0x60]
000075038bddf490  vpermilpd xmm1, xmm1, 0x00
000075038bddf496  movaps xmm14, xmm2
000075038bddf49a  mulpd xmm14, xmm1
000075038bddf49f  vcmppd xmm4, xmm14, xmm14, 0x03
000075038bddf4a5  ptest xmm4, xmm4
000075038bddf4aa  jnz 0x000075038BDE1D92
000075038bddf4b0  vmovaps xmm4, [rsp+0x50]
000075038bddf4b6  movaps xmm1, xmm4
000075038bddf4b9  addpd xmm1, xmm9
000075038bddf4be  vcmppd xmm2, xmm1, xmm1, 0x03
000075038bddf4c3  ptest xmm2, xmm2
000075038bddf4c8  jnz 0x000075038BDE1ED4
000075038bddf4ce  vmovaps xmm9, [rsp+0x30]
000075038bddf4d4  vpermilpd xmm9, xmm9, 0x00
000075038bddf4da  vmovaps xmm2, [rsp+0x70]
000075038bddf4e0  vmovaps [rsp+0x50], xmm1
000075038bddf4e6  movaps xmm4, xmm2
000075038bddf4e9  mulpd xmm4, xmm9
000075038bddf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
000075038bddf4f3  ptest xmm1, xmm1
000075038bddf4f8  jnz 0x000075038BDE2015
000075038bddf4fe  vmovaps xmm1, [rsp+0x30]
000075038bddf504  vpermilpd xmm1, xmm1, 0x00
000075038bddf50a  vmovaps xmm2, [rsp+0x90]
000075038bddf513  vmovaps [rsp+0x60], xmm15
000075038bddf519  movaps xmm9, xmm2
000075038bddf51d  mulpd xmm9, xmm1
000075038bddf522  vcmppd xmm15, xmm9, xmm9, 0x03
000075038bddf528  ptest xmm15, xmm15
000075038bddf52e  jnz 0x000075038BDE2156
000075038bddf534  vmovaps xmm15, [rsp+0x80]
000075038bddf53d  movaps xmm1, xmm15
000075038bddf541  addpd xmm1, xmm6
000075038bddf545  vcmppd xmm2, xmm1, xmm1, 0x03
000075038bddf54a  ptest xmm2, xmm2
000075038bddf54f  jnz 0x000075038BDE2298
000075038bddf555  movaps xmm15, xmm5
000075038bddf559  addpd xmm15, xmm3
000075038bddf55e  vcmppd xmm6, xmm15, xmm15, 0x03
000075038bddf564  ptest xmm6, xmm6
000075038bddf569  jnz 0x000075038BDE23D9
000075038bddf56f  vmovaps xmm6, [rsp+0x30]
000075038bddf575  vpermilpd xmm6, xmm6, 0x00
000075038bddf57b  movaps xmm5, xmm8
000075038bddf57f  mulpd xmm5, xmm6
000075038bddf583  vcmppd xmm3, xmm5, xmm5, 0x03
000075038bddf588  ptest xmm3, xmm3
000075038bddf58d  jnz 0x000075038BDE251B
000075038bddf593  vmovaps xmm8, [rsp+0x30]
000075038bddf599  vpermilpd xmm8, xmm8, 0x00
000075038bddf59f  movaps xmm6, xmm10
000075038bddf5a3  mulpd xmm6, xmm8
000075038bddf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
000075038bddf5ad  ptest xmm3, xmm3
000075038bddf5b2  jnz 0x000075038BDE265C
000075038bddf5b8  vmovaps xmm8, [rsp+0x60]
000075038bddf5be  movaps xmm10, xmm8
000075038bddf5c2  addpd xmm10, xmm14
000075038bddf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
000075038bddf5cd  ptest xmm3, xmm3
000075038bddf5d2  jnz 0x000075038BDE279E
000075038bddf5d8  vmovaps xmm8, [rsp+0x50]
000075038bddf5de  movaps xmm14, xmm8
000075038bddf5e2  addpd xmm14, xmm4
000075038bddf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
000075038bddf5ed  ptest xmm3, xmm3
000075038bddf5f2  jnz 0x000075038BDE28E2
000075038bddf5f8  vmovaps xmm8, [rsp+0x40]
000075038bddf5fe  vpermilpd xmm8, xmm8, 0x00
000075038bddf604  movaps xmm4, xmm13
000075038bddf608  mulpd xmm4, xmm8
000075038bddf60d  vcmppd xmm3, xmm4, xmm4, 0x03
000075038bddf612  ptest xmm3, xmm3
000075038bddf617  jnz 0x000075038BDE2A25
000075038bddf61d  movaps xmm13, xmm15
000075038bddf621  addpd xmm13, xmm9
000075038bddf626  vcmppd xmm8, xmm13, xmm13, 0x03
000075038bddf62c  ptest xmm8, xmm8
000075038bddf632  jnz 0x000075038BDE2B67
000075038bddf638  movaps xmm15, xmm1
000075038bddf63c  addpd xmm15, xmm5
000075038bddf641  vcmppd xmm9, xmm15, xmm15, 0x03
000075038bddf647  ptest xmm9, xmm9
000075038bddf64d  jnz 0x000075038BDE2CAB
000075038bddf653  vmovaps [rsp+0x30], xmm11
000075038bddf659  vmovaps xmm1, [rsp+0x30]
000075038bddf65f  por xmm11, xmm1
000075038bddf664  movaps [r15+0x250], xmm11
000075038bddf66c  vmovaps [rsp+0x30], xmm12
000075038bddf672  vmovaps xmm1, [rsp+0x30]
000075038bddf678  por xmm12, xmm1
000075038bddf67d  movaps [r15+0x2A0], xmm12
000075038bddf685  vmovaps xmm1, [rsp+0xA0]
000075038bddf68e  vmovaps xmm11, [rsp+0xA0]
000075038bddf697  por xmm1, xmm11
000075038bddf69c  movaps [r15+0x1D0], xmm1
000075038bddf6a4  lea r12, [rax+0x40]
000075038bddf6a8  movups xmm1, [r13+r12*1]
000075038bddf6ae  movaps [r15+0x2C0], xmm1
000075038bddf6b6  vmovaps xmm11, [rsp+0x40]
000075038bddf6bc  vpermilpd xmm11, xmm11, 0x00
000075038bddf6c2  vmovaps xmm8, [rsp+0xE0]
000075038bddf6cb  movaps xmm9, xmm8
000075038bddf6cf  mulpd xmm9, xmm11
000075038bddf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
000075038bddf6da  ptest xmm5, xmm5
000075038bddf6df  jnz 0x000075038BDE2DF7
000075038bddf6e5  movaps xmm11, xmm10
000075038bddf6e9  addpd xmm11, xmm6
000075038bddf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
000075038bddf6f4  ptest xmm8, xmm8
000075038bddf6fa  jnz 0x000075038BDE2F3B
000075038bddf700  movaps xmm10, xmm14
000075038bddf704  addpd xmm10, xmm4
000075038bddf709  vcmppd xmm8, xmm10, xmm10, 0x03
000075038bddf70f  ptest xmm8, xmm8
000075038bddf715  jnz 0x000075038BDE307E
000075038bddf71b  vmovaps xmm14, [rsp+0x40]
000075038bddf721  vpermilpd xmm14, xmm14, 0x00
000075038bddf727  movaps xmm8, xmm1
000075038bddf72b  mulpd xmm8, xmm14
000075038bddf730  vcmppd xmm6, xmm8, xmm8, 0x03
000075038bddf736  ptest xmm6, xmm6
000075038bddf73b  jnz 0x000075038BDE31C1
000075038bddf741  movaps xmm1, [r15+0x2B0]
000075038bddf749  vmovaps xmm14, [rsp+0x40]
000075038bddf74f  vpermilpd xmm14, xmm14, 0x00
000075038bddf755  movaps xmm6, xmm1
000075038bddf758  mulpd xmm6, xmm14
000075038bddf75d  vcmppd xmm5, xmm6, xmm6, 0x03
000075038bddf762  ptest xmm5, xmm5
000075038bddf767  jnz 0x000075038BDE3304
000075038bddf76d  vmovaps xmm1, [rsp+0x10]
000075038bddf773  vpermilpd xmm1, xmm1, 0x00
000075038bddf779  movaps xmm14, xmm12
000075038bddf77d  mulpd xmm14, xmm1
000075038bddf782  vcmppd xmm5, xmm14, xmm14, 0x03
000075038bddf788  ptest xmm5, xmm5
000075038bddf78d  jnz 0x000075038BDE3445
000075038bddf793  movaps xmm1, xmm13
000075038bddf797  addpd xmm1, xmm9
000075038bddf79c  vcmppd xmm12, xmm1, xmm1, 0x03
000075038bddf7a1  ptest xmm12, xmm12
000075038bddf7a7  jnz 0x000075038BDE3588
000075038bddf7ad  vmovaps xmm13, [rsp+0x10]
000075038bddf7b3  vpermilpd xmm13, xmm13, 0x00
000075038bddf7b9  movaps xmm12, xmm7
000075038bddf7bd  mulpd xmm12, xmm13
000075038bddf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
000075038bddf7c8  ptest xmm9, xmm9
000075038bddf7ce  jnz 0x000075038BDE36CA
000075038bddf7d4  movaps xmm13, xmm15
000075038bddf7d8  addpd xmm13, xmm8
000075038bddf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
000075038bddf7e3  ptest xmm9, xmm9
000075038bddf7e9  jnz 0x000075038BDE380D
000075038bddf7ef  movaps xmm15, [r15+0x290]
000075038bddf7f7  vmovaps xmm9, [rsp+0x10]
000075038bddf7fd  vpermilpd xmm9, xmm9, 0x00
000075038bddf803  movaps xmm8, xmm15
000075038bddf807  mulpd xmm8, xmm9
000075038bddf80c  vcmppd xmm7, xmm8, xmm8, 0x03
000075038bddf812  ptest xmm7, xmm7
000075038bddf817  jnz 0x000075038BDE3951
000075038bddf81d  movaps xmm15, xmm11
000075038bddf821  addpd xmm15, xmm6
000075038bddf826  vcmppd xmm9, xmm15, xmm15, 0x03
000075038bddf82c  ptest xmm9, xmm9
000075038bddf832  jnz 0x000075038BDE3A95
000075038bddf838  movaps xmm11, [r15+0x1E0]
000075038bddf840  vmovaps xmm9, [rsp+0x10]
000075038bddf846  vpermilpd xmm9, xmm9, 0x00
000075038bddf84c  movaps xmm7, xmm11
000075038bddf850  mulpd xmm7, xmm9
000075038bddf855  vcmppd xmm6, xmm7, xmm7, 0x03
000075038bddf85a  ptest xmm6, xmm6
000075038bddf85f  jnz 0x000075038BDE3BD8
000075038bddf865  movaps xmm11, xmm10
000075038bddf869  addpd xmm11, xmm14
000075038bddf86e  vcmppd xmm9, xmm11, xmm11, 0x03
000075038bddf874  ptest xmm9, xmm9
000075038bddf87a  jnz 0x000075038BDE3D1A
000075038bddf880  lea r12, [rax+0x70]
000075038bddf884  movups xmm14, [r13+r12*1]
000075038bddf88a  movaps [r15+0x240], xmm14
000075038bddf892  movaps xmm10, xmm1
000075038bddf896  addpd xmm10, xmm12
000075038bddf89b  vcmppd xmm9, xmm10, xmm10, 0x03
000075038bddf8a1  ptest xmm9, xmm9
000075038bddf8a7  jnz 0x000075038BDE3E68
000075038bddf8ad  movaps [r15+0x170], xmm10
000075038bddf8b5  vmovaps xmm1, [rsp+0x20]
000075038bddf8bb  vpermilpd xmm1, xmm1, 0x00
000075038bddf8c1  movaps xmm12, xmm14
000075038bddf8c5  mulpd xmm12, xmm1
000075038bddf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
000075038bddf8d0  ptest xmm9, xmm9
000075038bddf8d6  jnz 0x000075038BDE3FAB
000075038bddf8dc  vmovaps xmm1, [rsp+0x20]
000075038bddf8e2  vpermilpd xmm1, xmm1, 0x00
000075038bddf8e8  vmovaps xmm9, [rsp+0xB0]
000075038bddf8f1  movaps xmm14, xmm9
000075038bddf8f5  mulpd xmm14, xmm1
000075038bddf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
000075038bddf900  ptest xmm6, xmm6
000075038bddf905  jnz 0x000075038BDE40EE
000075038bddf90b  movaps [r15+0x180], xmm14
000075038bddf913  movaps xmm1, xmm13
000075038bddf917  addpd xmm1, xmm8
000075038bddf91c  vcmppd xmm9, xmm1, xmm1, 0x03
000075038bddf921  ptest xmm9, xmm9
000075038bddf927  jnz 0x000075038BDE4231
000075038bddf92d  movaps [r15+0x210], xmm1
000075038bddf935  movups xmm13, [r13+rax*1]
000075038bddf93b  lea r12, [rax+0x10]
000075038bddf93f  movups xmm9, [r13+r12*1]
000075038bddf945  movaps [r15+0x230], xmm9
000075038bddf94d  movaps xmm8, xmm15
000075038bddf951  addpd xmm8, xmm7
000075038bddf956  vcmppd xmm6, xmm8, xmm8, 0x03
000075038bddf95c  ptest xmm6, xmm6
000075038bddf961  jnz 0x000075038BDE4387
000075038bddf967  movaps [r15+0x130], xmm8
000075038bddf96f  vmovaps xmm15, [rsp+0x20]
000075038bddf975  vpermilpd xmm15, xmm15, 0x00
000075038bddf97b  movaps xmm7, xmm9
000075038bddf97f  mulpd xmm7, xmm15
000075038bddf984  vcmppd xmm6, xmm7, xmm7, 0x03
000075038bddf989  ptest xmm6, xmm6
000075038bddf98e  jnz 0x000075038BDE44CA
000075038bddf994  movaps [r15+0x220], xmm7
000075038bddf99c  vmovaps xmm15, [rsp+0x20]
000075038bddf9a2  vpermilpd xmm15, xmm15, 0x00
000075038bddf9a8  movaps xmm9, xmm13
000075038bddf9ac  mulpd xmm9, xmm15
000075038bddf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
000075038bddf9b7  ptest xmm6, xmm6
000075038bddf9bc  jnz 0x000075038BDE460C
000075038bddf9c2  movaps xmm15, xmm11
000075038bddf9c6  addpd xmm15, xmm12
000075038bddf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
000075038bddf9d1  ptest xmm13, xmm13
000075038bddf9d7  jnz 0x000075038BDE4750
000075038bddf9dd  movaps [r15+0x140], xmm15
000075038bddf9e5  movaps xmm13, xmm10
000075038bddf9e9  addpd xmm13, xmm14
000075038bddf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
000075038bddf9f4  ptest xmm12, xmm12
000075038bddf9fa  jnz 0x000075038BDE4894
000075038bddfa00  movaps [r15+0x150], xmm13
000075038bddfa08  movaps xmm14, xmm1
000075038bddfa0c  addpd xmm14, xmm7
000075038bddfa11  vcmppd xmm12, xmm14, xmm14, 0x03
000075038bddfa17  ptest xmm12, xmm12
000075038bddfa1d  jnz 0x000075038BDE49D8
000075038bddfa23  movaps [r15+0x160], xmm14
000075038bddfa2b  movaps xmm1, xmm8
000075038bddfa2f  addpd xmm1, xmm9
000075038bddfa34  vcmppd xmm12, xmm1, xmm1, 0x03
000075038bddfa39  ptest xmm12, xmm12
000075038bddfa3f  jnz 0x000075038BDE4B1A
000075038bddfa45  movaps [r15+0x120], xmm1
000075038bddfa4d  movups [r13+r14*1], xmm15
000075038bddfa53  lea rax, [r14+0x10]
000075038bddfa57  movups [r13+rax*1], xmm13
000075038bddfa5d  lea rax, [r14+0x20]
000075038bddfa61  movups [r13+rax*1], xmm14
000075038bddfa67  lea rax, [r14+0x30]
000075038bddfa6b  movups [r13+rax*1], xmm1
000075038bddfa71  mov eax, [r15+0x108]
000075038bddfa78  sahf
000075038bddfa79  jnz 0x000075038BDDFAAB
000075038bddfa7b  cmp dword ptr [r15+0x318], 0x00
000075038bddfa83  jz 0x000075038BDDEAE0
000075038bddfa89  nop [rax+rax*1], ax
000075038bddfa92  nop [rax+rax*1], eax
000075038bddfa9a  mov eax, 0x4106D0
000075038bddfa9f  mov [r15+0x100], rax
000075038bddfaa6  jmp 0x000075038BBFE110
000075038bddfaab  cmp dword ptr [r15+0x318], 0x00
000075038bddfab3  jz 0x000075038BDD89C0
000075038bddfab9  nop [rax+rax*1], ax
000075038bddfac2  nop [rax+rax*1], eax
000075038bddfaca  mov eax, 0x410504
000075038bddfacf  mov [r15+0x100], rax
000075038bddfad6  jmp 0x000075038BBFE110
000075038bddfadb  int3
000075038bddfadc  call 0x000075038BCE27E0
000075038bddfae1  jmp 0x000075038BDDEBBF
000075038bddfae6  call 0x000075038BCE1570
000075038bddfaeb  jmp 0x000075038BDDEBC8
000075038bddfaf0  call 0x000075038BCE27E0
000075038bddfaf5  jmp 0x000075038BDDEC24
000075038bddfafa  call 0x000075038BCE1570
000075038bddfaff  jmp 0x000075038BDDEC2D
000075038bddfb04  call 0x000075038BCE27E0
000075038bddfb09  jmp 0x000075038BDDEC70
000075038bddfb0e  call 0x000075038BCE1570
000075038bddfb13  jmp 0x000075038BDDEC79
000075038bddfb18  call 0x000075038BC0DC20
000075038bddfb1d  jmp 0x000075038BDDECB8
000075038bddfb22  call 0x000075038BCD59C0
000075038bddfb27  jmp 0x000075038BDDECCB
000075038bddfb2c  call 0x000075038BCE0E30
000075038bddfb31  jmp 0x000075038BDDECE9
000075038bddfb36  call 0x000075038BCDFBC0
000075038bddfb3b  jmp 0x000075038BDDECF3
000075038bddfb40  call 0x000075038BCDE950
000075038bddfb45  jmp 0x000075038BDDECFD
000075038bddfb4a  sub rsp, 0x08
000075038bddfb4e  push rax
000075038bddfb4f  push rcx
000075038bddfb50  push rdx
000075038bddfb51  push rdi
000075038bddfb52  push rsi
000075038bddfb53  push r8
000075038bddfb55  push r9
000075038bddfb57  push r10
000075038bddfb59  push r11
000075038bddfb5b  sub rsp, 0xF0
000075038bddfb62  vmovaps [rsp], xmm0
000075038bddfb67  vmovaps [rsp+0x10], xmm1
000075038bddfb6d  vmovaps [rsp+0x20], xmm2
000075038bddfb73  vmovaps [rsp+0x30], xmm3
000075038bddfb79  vmovaps [rsp+0x40], xmm4
000075038bddfb7f  vmovaps [rsp+0x50], xmm5
000075038bddfb85  vmovaps [rsp+0x60], xmm6
000075038bddfb8b  vmovaps [rsp+0x70], xmm7
000075038bddfb91  vmovaps [rsp+0x80], xmm9
000075038bddfb9a  vmovaps [rsp+0x90], xmm10
000075038bddfba3  vmovaps [rsp+0xA0], xmm11
000075038bddfbac  vmovaps [rsp+0xB0], xmm12
000075038bddfbb5  vmovaps [rsp+0xC0], xmm13
000075038bddfbbe  vmovaps [rsp+0xD0], xmm14
000075038bddfbc7  vmovaps [rsp+0xE0], xmm15
000075038bddfbd0  sub rsp, 0x30
000075038bddfbd4  movaps [rsp], xmm8
000075038bddfbd9  movaps [rsp+0x10], xmm12
000075038bddfbdf  movaps [rsp+0x20], xmm15
000075038bddfbe5  lea rdi, [rsp]
000075038bddfbe9  mov esi, 0x00
000075038bddfbee  mov rax, 0x56ADB4492530
000075038bddfbf8  call rax
000075038bddfbfa  movaps xmm8, [rsp]
000075038bddfbff  add rsp, 0x30
000075038bddfc03  vmovaps xmm0, [rsp]
000075038bddfc08  vmovaps xmm1, [rsp+0x10]
000075038bddfc0e  vmovaps xmm2, [rsp+0x20]
000075038bddfc14  vmovaps xmm3, [rsp+0x30]
000075038bddfc1a  vmovaps xmm4, [rsp+0x40]
000075038bddfc20  vmovaps xmm5, [rsp+0x50]
000075038bddfc26  vmovaps xmm6, [rsp+0x60]
000075038bddfc2c  vmovaps xmm7, [rsp+0x70]
000075038bddfc32  vmovaps xmm9, [rsp+0x80]
000075038bddfc3b  vmovaps xmm10, [rsp+0x90]
000075038bddfc44  vmovaps xmm11, [rsp+0xA0]
000075038bddfc4d  vmovaps xmm12, [rsp+0xB0]
000075038bddfc56  vmovaps xmm13, [rsp+0xC0]
000075038bddfc5f  vmovaps xmm14, [rsp+0xD0]
000075038bddfc68  vmovaps xmm15, [rsp+0xE0]
000075038bddfc71  add rsp, 0xF0
000075038bddfc78  pop r11
000075038bddfc7a  pop r10
000075038bddfc7c  pop r9
000075038bddfc7e  pop r8
000075038bddfc80  pop rsi
000075038bddfc81  pop rdi
000075038bddfc82  pop rdx
000075038bddfc83  pop rcx
000075038bddfc84  pop rax
000075038bddfc85  add rsp, 0x08
000075038bddfc89  jmp 0x000075038BDDED27
000075038bddfc8e  sub rsp, 0x08
000075038bddfc92  push rax
000075038bddfc93  push rcx
000075038bddfc94  push rdx
000075038bddfc95  push rdi
000075038bddfc96  push rsi
000075038bddfc97  push r8
000075038bddfc99  push r9
000075038bddfc9b  push r10
000075038bddfc9d  push r11
000075038bddfc9f  sub rsp, 0xF0
000075038bddfca6  vmovaps [rsp], xmm0
000075038bddfcab  vmovaps [rsp+0x10], xmm1
000075038bddfcb1  vmovaps [rsp+0x20], xmm2
000075038bddfcb7  vmovaps [rsp+0x30], xmm3
000075038bddfcbd  vmovaps [rsp+0x40], xmm4
000075038bddfcc3  vmovaps [rsp+0x50], xmm5
000075038bddfcc9  vmovaps [rsp+0x60], xmm6
000075038bddfccf  vmovaps [rsp+0x70], xmm8
000075038bddfcd5  vmovaps [rsp+0x80], xmm9
000075038bddfcde  vmovaps [rsp+0x90], xmm10
000075038bddfce7  vmovaps [rsp+0xA0], xmm11
000075038bddfcf0  vmovaps [rsp+0xB0], xmm12
000075038bddfcf9  vmovaps [rsp+0xC0], xmm13
000075038bddfd02  vmovaps [rsp+0xD0], xmm14
000075038bddfd0b  vmovaps [rsp+0xE0], xmm15
000075038bddfd14  sub rsp, 0x30
000075038bddfd18  movaps [rsp], xmm7
000075038bddfd1c  movaps [rsp+0x10], xmm9
000075038bddfd22  movaps [rsp+0x20], xmm15
000075038bddfd28  lea rdi, [rsp]
000075038bddfd2c  mov esi, 0x00
000075038bddfd31  mov rax, 0x56ADB4492530
000075038bddfd3b  call rax
000075038bddfd3d  movaps xmm7, [rsp]
000075038bddfd41  add rsp, 0x30
000075038bddfd45  vmovaps xmm0, [rsp]
000075038bddfd4a  vmovaps xmm1, [rsp+0x10]
000075038bddfd50  vmovaps xmm2, [rsp+0x20]
000075038bddfd56  vmovaps xmm3, [rsp+0x30]
000075038bddfd5c  vmovaps xmm4, [rsp+0x40]
000075038bddfd62  vmovaps xmm5, [rsp+0x50]
000075038bddfd68  vmovaps xmm6, [rsp+0x60]
000075038bddfd6e  vmovaps xmm8, [rsp+0x70]
000075038bddfd74  vmovaps xmm9, [rsp+0x80]
000075038bddfd7d  vmovaps xmm10, [rsp+0x90]
000075038bddfd86  vmovaps xmm11, [rsp+0xA0]
000075038bddfd8f  vmovaps xmm12, [rsp+0xB0]
000075038bddfd98  vmovaps xmm13, [rsp+0xC0]
000075038bddfda1  vmovaps xmm14, [rsp+0xD0]
000075038bddfdaa  vmovaps xmm15, [rsp+0xE0]
000075038bddfdb3  add rsp, 0xF0
000075038bddfdba  pop r11
000075038bddfdbc  pop r10
000075038bddfdbe  pop r9
000075038bddfdc0  pop r8
000075038bddfdc2  pop rsi
000075038bddfdc3  pop rdi
000075038bddfdc4  pop rdx
000075038bddfdc5  pop rcx
000075038bddfdc6  pop rax
000075038bddfdc7  add rsp, 0x08
000075038bddfdcb  jmp 0x000075038BDDED55
000075038bddfdd0  sub rsp, 0x08
000075038bddfdd4  push rax
000075038bddfdd5  push rcx
000075038bddfdd6  push rdx
000075038bddfdd7  push rdi
000075038bddfdd8  push rsi
000075038bddfdd9  push r8
000075038bddfddb  push r9
000075038bddfddd  push r10
000075038bddfddf  push r11
000075038bddfde1  sub rsp, 0xF0
000075038bddfde8  vmovaps [rsp], xmm0
000075038bddfded  vmovaps [rsp+0x10], xmm1
000075038bddfdf3  vmovaps [rsp+0x20], xmm2
000075038bddfdf9  vmovaps [rsp+0x30], xmm3
000075038bddfdff  vmovaps [rsp+0x40], xmm4
000075038bddfe05  vmovaps [rsp+0x50], xmm5
000075038bddfe0b  vmovaps [rsp+0x60], xmm6
000075038bddfe11  vmovaps [rsp+0x70], xmm7
000075038bddfe17  vmovaps [rsp+0x80], xmm8
000075038bddfe20  vmovaps [rsp+0x90], xmm10
000075038bddfe29  vmovaps [rsp+0xA0], xmm11
000075038bddfe32  vmovaps [rsp+0xB0], xmm12
000075038bddfe3b  vmovaps [rsp+0xC0], xmm13
000075038bddfe44  vmovaps [rsp+0xD0], xmm14
000075038bddfe4d  vmovaps [rsp+0xE0], xmm15
000075038bddfe56  sub rsp, 0x30
000075038bddfe5a  movaps [rsp], xmm9
000075038bddfe5f  movaps [rsp+0x10], xmm12
000075038bddfe65  movaps [rsp+0x20], xmm10
000075038bddfe6b  lea rdi, [rsp]
000075038bddfe6f  mov esi, 0x00
000075038bddfe74  mov rax, 0x56ADB4492530
000075038bddfe7e  call rax
000075038bddfe80  movaps xmm9, [rsp]
000075038bddfe85  add rsp, 0x30
000075038bddfe89  vmovaps xmm0, [rsp]
000075038bddfe8e  vmovaps xmm1, [rsp+0x10]
000075038bddfe94  vmovaps xmm2, [rsp+0x20]
000075038bddfe9a  vmovaps xmm3, [rsp+0x30]
000075038bddfea0  vmovaps xmm4, [rsp+0x40]
000075038bddfea6  vmovaps xmm5, [rsp+0x50]
000075038bddfeac  vmovaps xmm6, [rsp+0x60]
000075038bddfeb2  vmovaps xmm7, [rsp+0x70]
000075038bddfeb8  vmovaps xmm8, [rsp+0x80]
000075038bddfec1  vmovaps xmm10, [rsp+0x90]
000075038bddfeca  vmovaps xmm11, [rsp+0xA0]
000075038bddfed3  vmovaps xmm12, [rsp+0xB0]
000075038bddfedc  vmovaps xmm13, [rsp+0xC0]
000075038bddfee5  vmovaps xmm14, [rsp+0xD0]
000075038bddfeee  vmovaps xmm15, [rsp+0xE0]
000075038bddfef7  add rsp, 0xF0
000075038bddfefe  pop r11
000075038bddff00  pop r10
000075038bddff02  pop r9
000075038bddff04  pop r8
000075038bddff06  pop rsi
000075038bddff07  pop rdi
000075038bddff08  pop rdx
000075038bddff09  pop rcx
000075038bddff0a  pop rax
000075038bddff0b  add rsp, 0x08
000075038bddff0f  jmp 0x000075038BDDED79
000075038bddff14  sub rsp, 0x08
000075038bddff18  push rax
000075038bddff19  push rcx
000075038bddff1a  push rdx
000075038bddff1b  push rdi
000075038bddff1c  push rsi
000075038bddff1d  push r8
000075038bddff1f  push r9
000075038bddff21  push r10
000075038bddff23  push r11
000075038bddff25  sub rsp, 0xF0
000075038bddff2c  vmovaps [rsp], xmm0
000075038bddff31  vmovaps [rsp+0x10], xmm1
000075038bddff37  vmovaps [rsp+0x20], xmm2
000075038bddff3d  vmovaps [rsp+0x30], xmm3
000075038bddff43  vmovaps [rsp+0x40], xmm4
000075038bddff49  vmovaps [rsp+0x50], xmm5
000075038bddff4f  vmovaps [rsp+0x60], xmm6
000075038bddff55  vmovaps [rsp+0x70], xmm7
000075038bddff5b  vmovaps [rsp+0x80], xmm8
000075038bddff64  vmovaps [rsp+0x90], xmm9
000075038bddff6d  vmovaps [rsp+0xA0], xmm11
000075038bddff76  vmovaps [rsp+0xB0], xmm12
000075038bddff7f  vmovaps [rsp+0xC0], xmm13
000075038bddff88  vmovaps [rsp+0xD0], xmm14
000075038bddff91  vmovaps [rsp+0xE0], xmm15
000075038bddff9a  sub rsp, 0x30
000075038bddff9e  movaps [rsp], xmm10
000075038bddffa3  movaps [rsp+0x10], xmm12
000075038bddffa9  movaps [rsp+0x20], xmm11
000075038bddffaf  lea rdi, [rsp]
000075038bddffb3  mov esi, 0x00
000075038bddffb8  mov rax, 0x56ADB4492530
000075038bddffc2  call rax
000075038bddffc4  movaps xmm10, [rsp]
000075038bddffc9  add rsp, 0x30
000075038bddffcd  vmovaps xmm0, [rsp]
000075038bddffd2  vmovaps xmm1, [rsp+0x10]
000075038bddffd8  vmovaps xmm2, [rsp+0x20]
000075038bddffde  vmovaps xmm3, [rsp+0x30]
000075038bddffe4  vmovaps xmm4, [rsp+0x40]
000075038bddffea  vmovaps xmm5, [rsp+0x50]
000075038bddfff0  vmovaps xmm6, [rsp+0x60]
000075038bddfff6  vmovaps xmm7, [rsp+0x70]
000075038bddfffc  vmovaps xmm8, [rsp+0x80]
000075038bde0005  vmovaps xmm9, [rsp+0x90]
000075038bde000e  vmovaps xmm11, [rsp+0xA0]
000075038bde0017  vmovaps xmm12, [rsp+0xB0]
000075038bde0020  vmovaps xmm13, [rsp+0xC0]
000075038bde0029  vmovaps xmm14, [rsp+0xD0]
000075038bde0032  vmovaps xmm15, [rsp+0xE0]
000075038bde003b  add rsp, 0xF0
000075038bde0042  pop r11
000075038bde0044  pop r10
000075038bde0046  pop r9
000075038bde0048  pop r8
000075038bde004a  pop rsi
000075038bde004b  pop rdi
000075038bde004c  pop rdx
000075038bde004d  pop rcx
000075038bde004e  pop rax
000075038bde004f  add rsp, 0x08
000075038bde0053  jmp 0x000075038BDDED93
000075038bde0058  sub rsp, 0x08
000075038bde005c  push rax
000075038bde005d  push rcx
000075038bde005e  push rdx
000075038bde005f  push rdi
000075038bde0060  push rsi
000075038bde0061  push r8
000075038bde0063  push r9
000075038bde0065  push r10
000075038bde0067  push r11
000075038bde0069  sub rsp, 0xF0
000075038bde0070  vmovaps [rsp], xmm0
000075038bde0075  vmovaps [rsp+0x10], xmm1
000075038bde007b  vmovaps [rsp+0x20], xmm2
000075038bde0081  vmovaps [rsp+0x30], xmm3
000075038bde0087  vmovaps [rsp+0x40], xmm4
000075038bde008d  vmovaps [rsp+0x50], xmm5
000075038bde0093  vmovaps [rsp+0x60], xmm7
000075038bde0099  vmovaps [rsp+0x70], xmm8
000075038bde009f  vmovaps [rsp+0x80], xmm9
000075038bde00a8  vmovaps [rsp+0x90], xmm10
000075038bde00b1  vmovaps [rsp+0xA0], xmm11
000075038bde00ba  vmovaps [rsp+0xB0], xmm12
000075038bde00c3  vmovaps [rsp+0xC0], xmm13
000075038bde00cc  vmovaps [rsp+0xD0], xmm14
000075038bde00d5  vmovaps [rsp+0xE0], xmm15
000075038bde00de  sub rsp, 0x30
000075038bde00e2  movaps [rsp], xmm6
000075038bde00e6  movaps [rsp+0x10], xmm12
000075038bde00ec  movaps [rsp+0x20], xmm11
000075038bde00f2  lea rdi, [rsp]
000075038bde00f6  mov esi, 0x00
000075038bde00fb  mov rax, 0x56ADB4492530
000075038bde0105  call rax
000075038bde0107  movaps xmm6, [rsp]
000075038bde010b  add rsp, 0x30
000075038bde010f  vmovaps xmm0, [rsp]
000075038bde0114  vmovaps xmm1, [rsp+0x10]
000075038bde011a  vmovaps xmm2, [rsp+0x20]
000075038bde0120  vmovaps xmm3, [rsp+0x30]
000075038bde0126  vmovaps xmm4, [rsp+0x40]
000075038bde012c  vmovaps xmm5, [rsp+0x50]
000075038bde0132  vmovaps xmm7, [rsp+0x60]
000075038bde0138  vmovaps xmm8, [rsp+0x70]
000075038bde013e  vmovaps xmm9, [rsp+0x80]
000075038bde0147  vmovaps xmm10, [rsp+0x90]
000075038bde0150  vmovaps xmm11, [rsp+0xA0]
000075038bde0159  vmovaps xmm12, [rsp+0xB0]
000075038bde0162  vmovaps xmm13, [rsp+0xC0]
000075038bde016b  vmovaps xmm14, [rsp+0xD0]
000075038bde0174  vmovaps xmm15, [rsp+0xE0]
000075038bde017d  add rsp, 0xF0
000075038bde0184  pop r11
000075038bde0186  pop r10
000075038bde0188  pop r9
000075038bde018a  pop r8
000075038bde018c  pop rsi
000075038bde018d  pop rdi
000075038bde018e  pop rdx
000075038bde018f  pop rcx
000075038bde0190  pop rax
000075038bde0191  add rsp, 0x08
000075038bde0195  jmp 0x000075038BDDEDB4
000075038bde019a  sub rsp, 0x08
000075038bde019e  push rax
000075038bde019f  push rcx
000075038bde01a0  push rdx
000075038bde01a1  push rdi
000075038bde01a2  push rsi
000075038bde01a3  push r8
000075038bde01a5  push r9
000075038bde01a7  push r10
000075038bde01a9  push r11
000075038bde01ab  sub rsp, 0xF0
000075038bde01b2  vmovaps [rsp], xmm0
000075038bde01b7  vmovaps [rsp+0x10], xmm1
000075038bde01bd  vmovaps [rsp+0x20], xmm2
000075038bde01c3  vmovaps [rsp+0x30], xmm4
000075038bde01c9  vmovaps [rsp+0x40], xmm5
000075038bde01cf  vmovaps [rsp+0x50], xmm6
000075038bde01d5  vmovaps [rsp+0x60], xmm7
000075038bde01db  vmovaps [rsp+0x70], xmm8
000075038bde01e1  vmovaps [rsp+0x80], xmm9
000075038bde01ea  vmovaps [rsp+0x90], xmm10
000075038bde01f3  vmovaps [rsp+0xA0], xmm11
000075038bde01fc  vmovaps [rsp+0xB0], xmm12
000075038bde0205  vmovaps [rsp+0xC0], xmm13
000075038bde020e  vmovaps [rsp+0xD0], xmm14
000075038bde0217  vmovaps [rsp+0xE0], xmm15
000075038bde0220  sub rsp, 0x30
000075038bde0224  movaps [rsp], xmm3
000075038bde0228  movaps [rsp+0x10], xmm5
000075038bde022d  movaps [rsp+0x20], xmm4
000075038bde0232  lea rdi, [rsp]
000075038bde0236  mov esi, 0x00
000075038bde023b  mov rax, 0x56ADB4492530
000075038bde0245  call rax
000075038bde0247  movaps xmm3, [rsp]
000075038bde024b  add rsp, 0x30
000075038bde024f  vmovaps xmm0, [rsp]
000075038bde0254  vmovaps xmm1, [rsp+0x10]
000075038bde025a  vmovaps xmm2, [rsp+0x20]
000075038bde0260  vmovaps xmm4, [rsp+0x30]
000075038bde0266  vmovaps xmm5, [rsp+0x40]
000075038bde026c  vmovaps xmm6, [rsp+0x50]
000075038bde0272  vmovaps xmm7, [rsp+0x60]
000075038bde0278  vmovaps xmm8, [rsp+0x70]
000075038bde027e  vmovaps xmm9, [rsp+0x80]
000075038bde0287  vmovaps xmm10, [rsp+0x90]
000075038bde0290  vmovaps xmm11, [rsp+0xA0]
000075038bde0299  vmovaps xmm12, [rsp+0xB0]
000075038bde02a2  vmovaps xmm13, [rsp+0xC0]
000075038bde02ab  vmovaps xmm14, [rsp+0xD0]
000075038bde02b4  vmovaps xmm15, [rsp+0xE0]
000075038bde02bd  add rsp, 0xF0
000075038bde02c4  pop r11
000075038bde02c6  pop r10
000075038bde02c8  pop r9
000075038bde02ca  pop r8
000075038bde02cc  pop rsi
000075038bde02cd  pop rdi
000075038bde02ce  pop rdx
000075038bde02cf  pop rcx
000075038bde02d0  pop rax
000075038bde02d1  add rsp, 0x08
000075038bde02d5  jmp 0x000075038BDDEE15
000075038bde02da  sub rsp, 0x08
000075038bde02de  push rax
000075038bde02df  push rcx
000075038bde02e0  push rdx
000075038bde02e1  push rdi
000075038bde02e2  push rsi
000075038bde02e3  push r8
000075038bde02e5  push r9
000075038bde02e7  push r10
000075038bde02e9  push r11
000075038bde02eb  sub rsp, 0xF0
000075038bde02f2  vmovaps [rsp], xmm0
000075038bde02f7  vmovaps [rsp+0x10], xmm1
000075038bde02fd  vmovaps [rsp+0x20], xmm2
000075038bde0303  vmovaps [rsp+0x30], xmm3
000075038bde0309  vmovaps [rsp+0x40], xmm4
000075038bde030f  vmovaps [rsp+0x50], xmm6
000075038bde0315  vmovaps [rsp+0x60], xmm7
000075038bde031b  vmovaps [rsp+0x70], xmm8
000075038bde0321  vmovaps [rsp+0x80], xmm9
000075038bde032a  vmovaps [rsp+0x90], xmm10
000075038bde0333  vmovaps [rsp+0xA0], xmm11
000075038bde033c  vmovaps [rsp+0xB0], xmm12
000075038bde0345  vmovaps [rsp+0xC0], xmm13
000075038bde034e  vmovaps [rsp+0xD0], xmm14
000075038bde0357  vmovaps [rsp+0xE0], xmm15
000075038bde0360  sub rsp, 0x30
000075038bde0364  movaps [rsp], xmm5
000075038bde0368  movaps [rsp+0x10], xmm8
000075038bde036e  movaps [rsp+0x20], xmm15
000075038bde0374  lea rdi, [rsp]
000075038bde0378  mov esi, 0x00
000075038bde037d  mov rax, 0x56ADB4492530
000075038bde0387  call rax
000075038bde0389  movaps xmm5, [rsp]
000075038bde038d  add rsp, 0x30
000075038bde0391  vmovaps xmm0, [rsp]
000075038bde0396  vmovaps xmm1, [rsp+0x10]
000075038bde039c  vmovaps xmm2, [rsp+0x20]
000075038bde03a2  vmovaps xmm3, [rsp+0x30]
000075038bde03a8  vmovaps xmm4, [rsp+0x40]
000075038bde03ae  vmovaps xmm6, [rsp+0x50]
000075038bde03b4  vmovaps xmm7, [rsp+0x60]
000075038bde03ba  vmovaps xmm8, [rsp+0x70]
000075038bde03c0  vmovaps xmm9, [rsp+0x80]
000075038bde03c9  vmovaps xmm10, [rsp+0x90]
000075038bde03d2  vmovaps xmm11, [rsp+0xA0]
000075038bde03db  vmovaps xmm12, [rsp+0xB0]
000075038bde03e4  vmovaps xmm13, [rsp+0xC0]
000075038bde03ed  vmovaps xmm14, [rsp+0xD0]
000075038bde03f6  vmovaps xmm15, [rsp+0xE0]
000075038bde03ff  add rsp, 0xF0
000075038bde0406  pop r11
000075038bde0408  pop r10
000075038bde040a  pop r9
000075038bde040c  pop r8
000075038bde040e  pop rsi
000075038bde040f  pop rdi
000075038bde0410  pop rdx
000075038bde0411  pop rcx
000075038bde0412  pop rax
000075038bde0413  add rsp, 0x08
000075038bde0417  jmp 0x000075038BDDEE53
000075038bde041c  sub rsp, 0x08
000075038bde0420  push rax
000075038bde0421  push rcx
000075038bde0422  push rdx
000075038bde0423  push rdi
000075038bde0424  push rsi
000075038bde0425  push r8
000075038bde0427  push r9
000075038bde0429  push r10
000075038bde042b  push r11
000075038bde042d  sub rsp, 0xF0
000075038bde0434  vmovaps [rsp], xmm0
000075038bde0439  vmovaps [rsp+0x10], xmm1
000075038bde043f  vmovaps [rsp+0x20], xmm2
000075038bde0445  vmovaps [rsp+0x30], xmm3
000075038bde044b  vmovaps [rsp+0x40], xmm5
000075038bde0451  vmovaps [rsp+0x50], xmm6
000075038bde0457  vmovaps [rsp+0x60], xmm7
000075038bde045d  vmovaps [rsp+0x70], xmm8
000075038bde0463  vmovaps [rsp+0x80], xmm9
000075038bde046c  vmovaps [rsp+0x90], xmm10
000075038bde0475  vmovaps [rsp+0xA0], xmm11
000075038bde047e  vmovaps [rsp+0xB0], xmm12
000075038bde0487  vmovaps [rsp+0xC0], xmm13
000075038bde0490  vmovaps [rsp+0xD0], xmm14
000075038bde0499  vmovaps [rsp+0xE0], xmm15
000075038bde04a2  sub rsp, 0x30
000075038bde04a6  movaps [rsp], xmm4
000075038bde04aa  movaps [rsp+0x10], xmm9
000075038bde04b0  movaps [rsp+0x20], xmm8
000075038bde04b6  lea rdi, [rsp]
000075038bde04ba  mov esi, 0x00
000075038bde04bf  mov rax, 0x56ADB4492530
000075038bde04c9  call rax
000075038bde04cb  movaps xmm4, [rsp]
000075038bde04cf  add rsp, 0x30
000075038bde04d3  vmovaps xmm0, [rsp]
000075038bde04d8  vmovaps xmm1, [rsp+0x10]
000075038bde04de  vmovaps xmm2, [rsp+0x20]
000075038bde04e4  vmovaps xmm3, [rsp+0x30]
000075038bde04ea  vmovaps xmm5, [rsp+0x40]
000075038bde04f0  vmovaps xmm6, [rsp+0x50]
000075038bde04f6  vmovaps xmm7, [rsp+0x60]
000075038bde04fc  vmovaps xmm8, [rsp+0x70]
000075038bde0502  vmovaps xmm9, [rsp+0x80]
000075038bde050b  vmovaps xmm10, [rsp+0x90]
000075038bde0514  vmovaps xmm11, [rsp+0xA0]
000075038bde051d  vmovaps xmm12, [rsp+0xB0]
000075038bde0526  vmovaps xmm13, [rsp+0xC0]
000075038bde052f  vmovaps xmm14, [rsp+0xD0]
000075038bde0538  vmovaps xmm15, [rsp+0xE0]
000075038bde0541  add rsp, 0xF0
000075038bde0548  pop r11
000075038bde054a  pop r10
000075038bde054c  pop r9
000075038bde054e  pop r8
000075038bde0550  pop rsi
000075038bde0551  pop rdi
000075038bde0552  pop rdx
000075038bde0553  pop rcx
000075038bde0554  pop rax
000075038bde0555  add rsp, 0x08
000075038bde0559  jmp 0x000075038BDDEE74
000075038bde055e  sub rsp, 0x08
000075038bde0562  push rax
000075038bde0563  push rcx
000075038bde0564  push rdx
000075038bde0565  push rdi
000075038bde0566  push rsi
000075038bde0567  push r8
000075038bde0569  push r9
000075038bde056b  push r10
000075038bde056d  push r11
000075038bde056f  sub rsp, 0xF0
000075038bde0576  vmovaps [rsp], xmm0
000075038bde057b  vmovaps [rsp+0x10], xmm1
000075038bde0581  vmovaps [rsp+0x20], xmm2
000075038bde0587  vmovaps [rsp+0x30], xmm3
000075038bde058d  vmovaps [rsp+0x40], xmm4
000075038bde0593  vmovaps [rsp+0x50], xmm5
000075038bde0599  vmovaps [rsp+0x60], xmm6
000075038bde059f  vmovaps [rsp+0x70], xmm7
000075038bde05a5  vmovaps [rsp+0x80], xmm8
000075038bde05ae  vmovaps [rsp+0x90], xmm10
000075038bde05b7  vmovaps [rsp+0xA0], xmm11
000075038bde05c0  vmovaps [rsp+0xB0], xmm12
000075038bde05c9  vmovaps [rsp+0xC0], xmm13
000075038bde05d2  vmovaps [rsp+0xD0], xmm14
000075038bde05db  vmovaps [rsp+0xE0], xmm15
000075038bde05e4  sub rsp, 0x30
000075038bde05e8  movaps [rsp], xmm9
000075038bde05ed  movaps [rsp+0x10], xmm10
000075038bde05f3  movaps [rsp+0x20], xmm8
000075038bde05f9  lea rdi, [rsp]
000075038bde05fd  mov esi, 0x00
000075038bde0602  mov rax, 0x56ADB4492530
000075038bde060c  call rax
000075038bde060e  movaps xmm9, [rsp]
000075038bde0613  add rsp, 0x30
000075038bde0617  vmovaps xmm0, [rsp]
000075038bde061c  vmovaps xmm1, [rsp+0x10]
000075038bde0622  vmovaps xmm2, [rsp+0x20]
000075038bde0628  vmovaps xmm3, [rsp+0x30]
000075038bde062e  vmovaps xmm4, [rsp+0x40]
000075038bde0634  vmovaps xmm5, [rsp+0x50]
000075038bde063a  vmovaps xmm6, [rsp+0x60]
000075038bde0640  vmovaps xmm7, [rsp+0x70]
000075038bde0646  vmovaps xmm8, [rsp+0x80]
000075038bde064f  vmovaps xmm10, [rsp+0x90]
000075038bde0658  vmovaps xmm11, [rsp+0xA0]
000075038bde0661  vmovaps xmm12, [rsp+0xB0]
000075038bde066a  vmovaps xmm13, [rsp+0xC0]
000075038bde0673  vmovaps xmm14, [rsp+0xD0]
000075038bde067c  vmovaps xmm15, [rsp+0xE0]
000075038bde0685  add rsp, 0xF0
000075038bde068c  pop r11
000075038bde068e  pop r10
000075038bde0690  pop r9
000075038bde0692  pop r8
000075038bde0694  pop rsi
000075038bde0695  pop rdi
000075038bde0696  pop rdx
000075038bde0697  pop rcx
000075038bde0698  pop rax
000075038bde0699  add rsp, 0x08
000075038bde069d  jmp 0x000075038BDDEE8E
000075038bde06a2  call 0x000075038BCB52F0
000075038bde06a7  jmp 0x000075038BDDEFA8
000075038bde06ac  call 0x000075038BCB52F0
000075038bde06b1  jmp 0x000075038BDDEFBE
000075038bde06b6  sub rsp, 0x08
000075038bde06ba  push rax
000075038bde06bb  push rcx
000075038bde06bc  push rdx
000075038bde06bd  push rdi
000075038bde06be  push rsi
000075038bde06bf  push r8
000075038bde06c1  push r9
000075038bde06c3  push r10
000075038bde06c5  push r11
000075038bde06c7  sub rsp, 0xF0
000075038bde06ce  vmovaps [rsp], xmm0
000075038bde06d3  vmovaps [rsp+0x10], xmm2
000075038bde06d9  vmovaps [rsp+0x20], xmm3
000075038bde06df  vmovaps [rsp+0x30], xmm4
000075038bde06e5  vmovaps [rsp+0x40], xmm5
000075038bde06eb  vmovaps [rsp+0x50], xmm6
000075038bde06f1  vmovaps [rsp+0x60], xmm7
000075038bde06f7  vmovaps [rsp+0x70], xmm8
000075038bde06fd  vmovaps [rsp+0x80], xmm9
000075038bde0706  vmovaps [rsp+0x90], xmm10
000075038bde070f  vmovaps [rsp+0xA0], xmm11
000075038bde0718  vmovaps [rsp+0xB0], xmm12
000075038bde0721  vmovaps [rsp+0xC0], xmm13
000075038bde072a  vmovaps [rsp+0xD0], xmm14
000075038bde0733  vmovaps [rsp+0xE0], xmm15
000075038bde073c  sub rsp, 0x30
000075038bde0740  movaps [rsp], xmm1
000075038bde0744  movaps [rsp+0x10], xmm6
000075038bde0749  movaps [rsp+0x20], xmm15
000075038bde074f  lea rdi, [rsp]
000075038bde0753  mov esi, 0x00
000075038bde0758  mov rax, 0x56ADB4492530
000075038bde0762  call rax
000075038bde0764  movaps xmm1, [rsp]
000075038bde0768  add rsp, 0x30
000075038bde076c  vmovaps xmm0, [rsp]
000075038bde0771  vmovaps xmm2, [rsp+0x10]
000075038bde0777  vmovaps xmm3, [rsp+0x20]
000075038bde077d  vmovaps xmm4, [rsp+0x30]
000075038bde0783  vmovaps xmm5, [rsp+0x40]
000075038bde0789  vmovaps xmm6, [rsp+0x50]
000075038bde078f  vmovaps xmm7, [rsp+0x60]
000075038bde0795  vmovaps xmm8, [rsp+0x70]
000075038bde079b  vmovaps xmm9, [rsp+0x80]
000075038bde07a4  vmovaps xmm10, [rsp+0x90]
000075038bde07ad  vmovaps xmm11, [rsp+0xA0]
000075038bde07b6  vmovaps xmm12, [rsp+0xB0]
000075038bde07bf  vmovaps xmm13, [rsp+0xC0]
000075038bde07c8  vmovaps xmm14, [rsp+0xD0]
000075038bde07d1  vmovaps xmm15, [rsp+0xE0]
000075038bde07da  add rsp, 0xF0
000075038bde07e1  pop r11
000075038bde07e3  pop r10
000075038bde07e5  pop r9
000075038bde07e7  pop r8
000075038bde07e9  pop rsi
000075038bde07ea  pop rdi
000075038bde07eb  pop rdx
000075038bde07ec  pop rcx
000075038bde07ed  pop rax
000075038bde07ee  add rsp, 0x08
000075038bde07f2  jmp 0x000075038BDDEFFB
000075038bde07f7  call 0x000075038BCC4620
000075038bde07fc  jmp 0x000075038BDDF008
000075038bde0801  sub rsp, 0x08
000075038bde0805  push rax
000075038bde0806  push rcx
000075038bde0807  push rdx
000075038bde0808  push rdi
000075038bde0809  push rsi
000075038bde080a  push r8
000075038bde080c  push r9
000075038bde080e  push r10
000075038bde0810  push r11
000075038bde0812  sub rsp, 0xF0
000075038bde0819  vmovaps [rsp], xmm0
000075038bde081e  vmovaps [rsp+0x10], xmm1
000075038bde0824  vmovaps [rsp+0x20], xmm2
000075038bde082a  vmovaps [rsp+0x30], xmm3
000075038bde0830  vmovaps [rsp+0x40], xmm4
000075038bde0836  vmovaps [rsp+0x50], xmm5
000075038bde083c  vmovaps [rsp+0x60], xmm6
000075038bde0842  vmovaps [rsp+0x70], xmm7
000075038bde0848  vmovaps [rsp+0x80], xmm8
000075038bde0851  vmovaps [rsp+0x90], xmm9
000075038bde085a  vmovaps [rsp+0xA0], xmm10
000075038bde0863  vmovaps [rsp+0xB0], xmm11
000075038bde086c  vmovaps [rsp+0xC0], xmm12
000075038bde0875  vmovaps [rsp+0xD0], xmm13
000075038bde087e  vmovaps [rsp+0xE0], xmm15
000075038bde0887  sub rsp, 0x30
000075038bde088b  movaps [rsp], xmm14
000075038bde0890  movaps [rsp+0x10], xmm4
000075038bde0895  movaps [rsp+0x20], xmm3
000075038bde089a  lea rdi, [rsp]
000075038bde089e  mov esi, 0x00
000075038bde08a3  mov rax, 0x56ADB4492530
000075038bde08ad  call rax
000075038bde08af  movaps xmm14, [rsp]
000075038bde08b4  add rsp, 0x30
000075038bde08b8  vmovaps xmm0, [rsp]
000075038bde08bd  vmovaps xmm1, [rsp+0x10]
000075038bde08c3  vmovaps xmm2, [rsp+0x20]
000075038bde08c9  vmovaps xmm3, [rsp+0x30]
000075038bde08cf  vmovaps xmm4, [rsp+0x40]
000075038bde08d5  vmovaps xmm5, [rsp+0x50]
000075038bde08db  vmovaps xmm6, [rsp+0x60]
000075038bde08e1  vmovaps xmm7, [rsp+0x70]
000075038bde08e7  vmovaps xmm8, [rsp+0x80]
000075038bde08f0  vmovaps xmm9, [rsp+0x90]
000075038bde08f9  vmovaps xmm10, [rsp+0xA0]
000075038bde0902  vmovaps xmm11, [rsp+0xB0]
000075038bde090b  vmovaps xmm12, [rsp+0xC0]
000075038bde0914  vmovaps xmm13, [rsp+0xD0]
000075038bde091d  vmovaps xmm15, [rsp+0xE0]
000075038bde0926  add rsp, 0xF0
000075038bde092d  pop r11
000075038bde092f  pop r10
000075038bde0931  pop r9
000075038bde0933  pop r8
000075038bde0935  pop rsi
000075038bde0936  pop rdi
000075038bde0937  pop rdx
000075038bde0938  pop rcx
000075038bde0939  pop rax
000075038bde093a  add rsp, 0x08
000075038bde093e  jmp 0x000075038BDDF022
000075038bde0943  sub rsp, 0x08
000075038bde0947  push rax
000075038bde0948  push rcx
000075038bde0949  push rdx
000075038bde094a  push rdi
000075038bde094b  push rsi
000075038bde094c  push r8
000075038bde094e  push r9
000075038bde0950  push r10
000075038bde0952  push r11
000075038bde0954  sub rsp, 0xF0
000075038bde095b  vmovaps [rsp], xmm0
000075038bde0960  vmovaps [rsp+0x10], xmm1
000075038bde0966  vmovaps [rsp+0x20], xmm2
000075038bde096c  vmovaps [rsp+0x30], xmm3
000075038bde0972  vmovaps [rsp+0x40], xmm4
000075038bde0978  vmovaps [rsp+0x50], xmm5
000075038bde097e  vmovaps [rsp+0x60], xmm7
000075038bde0984  vmovaps [rsp+0x70], xmm8
000075038bde098a  vmovaps [rsp+0x80], xmm9
000075038bde0993  vmovaps [rsp+0x90], xmm10
000075038bde099c  vmovaps [rsp+0xA0], xmm11
000075038bde09a5  vmovaps [rsp+0xB0], xmm12
000075038bde09ae  vmovaps [rsp+0xC0], xmm13
000075038bde09b7  vmovaps [rsp+0xD0], xmm14
000075038bde09c0  vmovaps [rsp+0xE0], xmm15
000075038bde09c9  sub rsp, 0x30
000075038bde09cd  movaps [rsp], xmm6
000075038bde09d1  movaps [rsp+0x10], xmm9
000075038bde09d7  movaps [rsp+0x20], xmm7
000075038bde09dc  lea rdi, [rsp]
000075038bde09e0  mov esi, 0x00
000075038bde09e5  mov rax, 0x56ADB4492530
000075038bde09ef  call rax
000075038bde09f1  movaps xmm6, [rsp]
000075038bde09f5  add rsp, 0x30
000075038bde09f9  vmovaps xmm0, [rsp]
000075038bde09fe  vmovaps xmm1, [rsp+0x10]
000075038bde0a04  vmovaps xmm2, [rsp+0x20]
000075038bde0a0a  vmovaps xmm3, [rsp+0x30]
000075038bde0a10  vmovaps xmm4, [rsp+0x40]
000075038bde0a16  vmovaps xmm5, [rsp+0x50]
000075038bde0a1c  vmovaps xmm7, [rsp+0x60]
000075038bde0a22  vmovaps xmm8, [rsp+0x70]
000075038bde0a28  vmovaps xmm9, [rsp+0x80]
000075038bde0a31  vmovaps xmm10, [rsp+0x90]
000075038bde0a3a  vmovaps xmm11, [rsp+0xA0]
000075038bde0a43  vmovaps xmm12, [rsp+0xB0]
000075038bde0a4c  vmovaps xmm13, [rsp+0xC0]
000075038bde0a55  vmovaps xmm14, [rsp+0xD0]
000075038bde0a5e  vmovaps xmm15, [rsp+0xE0]
000075038bde0a67  add rsp, 0xF0
000075038bde0a6e  pop r11
000075038bde0a70  pop r10
000075038bde0a72  pop r9
000075038bde0a74  pop r8
000075038bde0a76  pop rsi
000075038bde0a77  pop rdi
000075038bde0a78  pop rdx
000075038bde0a79  pop rcx
000075038bde0a7a  pop rax
000075038bde0a7b  add rsp, 0x08
000075038bde0a7f  jmp 0x000075038BDDF03A
000075038bde0a84  sub rsp, 0x08
000075038bde0a88  push rax
000075038bde0a89  push rcx
000075038bde0a8a  push rdx
000075038bde0a8b  push rdi
000075038bde0a8c  push rsi
000075038bde0a8d  push r8
000075038bde0a8f  push r9
000075038bde0a91  push r10
000075038bde0a93  push r11
000075038bde0a95  sub rsp, 0xF0
000075038bde0a9c  vmovaps [rsp], xmm0
000075038bde0aa1  vmovaps [rsp+0x10], xmm1
000075038bde0aa7  vmovaps [rsp+0x20], xmm2
000075038bde0aad  vmovaps [rsp+0x30], xmm3
000075038bde0ab3  vmovaps [rsp+0x40], xmm4
000075038bde0ab9  vmovaps [rsp+0x50], xmm5
000075038bde0abf  vmovaps [rsp+0x60], xmm6
000075038bde0ac5  vmovaps [rsp+0x70], xmm8
000075038bde0acb  vmovaps [rsp+0x80], xmm9
000075038bde0ad4  vmovaps [rsp+0x90], xmm10
000075038bde0add  vmovaps [rsp+0xA0], xmm11
000075038bde0ae6  vmovaps [rsp+0xB0], xmm12
000075038bde0aef  vmovaps [rsp+0xC0], xmm13
000075038bde0af8  vmovaps [rsp+0xD0], xmm14
000075038bde0b01  vmovaps [rsp+0xE0], xmm15
000075038bde0b0a  sub rsp, 0x30
000075038bde0b0e  movaps [rsp], xmm7
000075038bde0b12  movaps [rsp+0x10], xmm4
000075038bde0b17  movaps [rsp+0x20], xmm9
000075038bde0b1d  lea rdi, [rsp]
000075038bde0b21  mov esi, 0x00
000075038bde0b26  mov rax, 0x56ADB4492530
000075038bde0b30  call rax
000075038bde0b32  movaps xmm7, [rsp]
000075038bde0b36  add rsp, 0x30
000075038bde0b3a  vmovaps xmm0, [rsp]
000075038bde0b3f  vmovaps xmm1, [rsp+0x10]
000075038bde0b45  vmovaps xmm2, [rsp+0x20]
000075038bde0b4b  vmovaps xmm3, [rsp+0x30]
000075038bde0b51  vmovaps xmm4, [rsp+0x40]
000075038bde0b57  vmovaps xmm5, [rsp+0x50]
000075038bde0b5d  vmovaps xmm6, [rsp+0x60]
000075038bde0b63  vmovaps xmm8, [rsp+0x70]
000075038bde0b69  vmovaps xmm9, [rsp+0x80]
000075038bde0b72  vmovaps xmm10, [rsp+0x90]
000075038bde0b7b  vmovaps xmm11, [rsp+0xA0]
000075038bde0b84  vmovaps xmm12, [rsp+0xB0]
000075038bde0b8d  vmovaps xmm13, [rsp+0xC0]
000075038bde0b96  vmovaps xmm14, [rsp+0xD0]
000075038bde0b9f  vmovaps xmm15, [rsp+0xE0]
000075038bde0ba8  add rsp, 0xF0
000075038bde0baf  pop r11
000075038bde0bb1  pop r10
000075038bde0bb3  pop r9
000075038bde0bb5  pop r8
000075038bde0bb7  pop rsi
000075038bde0bb8  pop rdi
000075038bde0bb9  pop rdx
000075038bde0bba  pop rcx
000075038bde0bbb  pop rax
000075038bde0bbc  add rsp, 0x08
000075038bde0bc0  jmp 0x000075038BDDF067
000075038bde0bc5  sub rsp, 0x08
000075038bde0bc9  push rax
000075038bde0bca  push rcx
000075038bde0bcb  push rdx
000075038bde0bcc  push rdi
000075038bde0bcd  push rsi
000075038bde0bce  push r8
000075038bde0bd0  push r9
000075038bde0bd2  push r10
000075038bde0bd4  push r11
000075038bde0bd6  sub rsp, 0xF0
000075038bde0bdd  vmovaps [rsp], xmm0
000075038bde0be2  vmovaps [rsp+0x10], xmm1
000075038bde0be8  vmovaps [rsp+0x20], xmm2
000075038bde0bee  vmovaps [rsp+0x30], xmm3
000075038bde0bf4  vmovaps [rsp+0x40], xmm5
000075038bde0bfa  vmovaps [rsp+0x50], xmm6
000075038bde0c00  vmovaps [rsp+0x60], xmm7
000075038bde0c06  vmovaps [rsp+0x70], xmm8
000075038bde0c0c  vmovaps [rsp+0x80], xmm9
000075038bde0c15  vmovaps [rsp+0x90], xmm10
000075038bde0c1e  vmovaps [rsp+0xA0], xmm11
000075038bde0c27  vmovaps [rsp+0xB0], xmm12
000075038bde0c30  vmovaps [rsp+0xC0], xmm13
000075038bde0c39  vmovaps [rsp+0xD0], xmm14
000075038bde0c42  vmovaps [rsp+0xE0], xmm15
000075038bde0c4b  sub rsp, 0x30
000075038bde0c4f  movaps [rsp], xmm4
000075038bde0c53  movaps [rsp+0x10], xmm15
000075038bde0c59  movaps [rsp+0x20], xmm9
000075038bde0c5f  lea rdi, [rsp]
000075038bde0c63  mov esi, 0x00
000075038bde0c68  mov rax, 0x56ADB4492530
000075038bde0c72  call rax
000075038bde0c74  movaps xmm4, [rsp]
000075038bde0c78  add rsp, 0x30
000075038bde0c7c  vmovaps xmm0, [rsp]
000075038bde0c81  vmovaps xmm1, [rsp+0x10]
000075038bde0c87  vmovaps xmm2, [rsp+0x20]
000075038bde0c8d  vmovaps xmm3, [rsp+0x30]
000075038bde0c93  vmovaps xmm5, [rsp+0x40]
000075038bde0c99  vmovaps xmm6, [rsp+0x50]
000075038bde0c9f  vmovaps xmm7, [rsp+0x60]
000075038bde0ca5  vmovaps xmm8, [rsp+0x70]
000075038bde0cab  vmovaps xmm9, [rsp+0x80]
000075038bde0cb4  vmovaps xmm10, [rsp+0x90]
000075038bde0cbd  vmovaps xmm11, [rsp+0xA0]
000075038bde0cc6  vmovaps xmm12, [rsp+0xB0]
000075038bde0ccf  vmovaps xmm13, [rsp+0xC0]
000075038bde0cd8  vmovaps xmm14, [rsp+0xD0]
000075038bde0ce1  vmovaps xmm15, [rsp+0xE0]
000075038bde0cea  add rsp, 0xF0
000075038bde0cf1  pop r11
000075038bde0cf3  pop r10
000075038bde0cf5  pop r9
000075038bde0cf7  pop r8
000075038bde0cf9  pop rsi
000075038bde0cfa  pop rdi
000075038bde0cfb  pop rdx
000075038bde0cfc  pop rcx
000075038bde0cfd  pop rax
000075038bde0cfe  add rsp, 0x08
000075038bde0d02  jmp 0x000075038BDDF08C
000075038bde0d07  call 0x000075038BCC4620
000075038bde0d0c  jmp 0x000075038BDDF099
000075038bde0d11  sub rsp, 0x08
000075038bde0d15  push rax
000075038bde0d16  push rcx
000075038bde0d17  push rdx
000075038bde0d18  push rdi
000075038bde0d19  push rsi
000075038bde0d1a  push r8
000075038bde0d1c  push r9
000075038bde0d1e  push r10
000075038bde0d20  push r11
000075038bde0d22  sub rsp, 0xF0
000075038bde0d29  vmovaps [rsp], xmm0
000075038bde0d2e  vmovaps [rsp+0x10], xmm1
000075038bde0d34  vmovaps [rsp+0x20], xmm2
000075038bde0d3a  vmovaps [rsp+0x30], xmm4
000075038bde0d40  vmovaps [rsp+0x40], xmm5
000075038bde0d46  vmovaps [rsp+0x50], xmm6
000075038bde0d4c  vmovaps [rsp+0x60], xmm7
000075038bde0d52  vmovaps [rsp+0x70], xmm8
000075038bde0d58  vmovaps [rsp+0x80], xmm9
000075038bde0d61  vmovaps [rsp+0x90], xmm10
000075038bde0d6a  vmovaps [rsp+0xA0], xmm11
000075038bde0d73  vmovaps [rsp+0xB0], xmm12
000075038bde0d7c  vmovaps [rsp+0xC0], xmm13
000075038bde0d85  vmovaps [rsp+0xD0], xmm14
000075038bde0d8e  vmovaps [rsp+0xE0], xmm15
000075038bde0d97  sub rsp, 0x30
000075038bde0d9b  movaps [rsp], xmm3
000075038bde0d9f  movaps [rsp+0x10], xmm1
000075038bde0da4  movaps [rsp+0x20], xmm9
000075038bde0daa  lea rdi, [rsp]
000075038bde0dae  mov esi, 0x00
000075038bde0db3  mov rax, 0x56ADB4492530
000075038bde0dbd  call rax
000075038bde0dbf  movaps xmm3, [rsp]
000075038bde0dc3  add rsp, 0x30
000075038bde0dc7  vmovaps xmm0, [rsp]
000075038bde0dcc  vmovaps xmm1, [rsp+0x10]
000075038bde0dd2  vmovaps xmm2, [rsp+0x20]
000075038bde0dd8  vmovaps xmm4, [rsp+0x30]
000075038bde0dde  vmovaps xmm5, [rsp+0x40]
000075038bde0de4  vmovaps xmm6, [rsp+0x50]
000075038bde0dea  vmovaps xmm7, [rsp+0x60]
000075038bde0df0  vmovaps xmm8, [rsp+0x70]
000075038bde0df6  vmovaps xmm9, [rsp+0x80]
000075038bde0dff  vmovaps xmm10, [rsp+0x90]
000075038bde0e08  vmovaps xmm11, [rsp+0xA0]
000075038bde0e11  vmovaps xmm12, [rsp+0xB0]
000075038bde0e1a  vmovaps xmm13, [rsp+0xC0]
000075038bde0e23  vmovaps xmm14, [rsp+0xD0]
000075038bde0e2c  vmovaps xmm15, [rsp+0xE0]
000075038bde0e35  add rsp, 0xF0
000075038bde0e3c  pop r11
000075038bde0e3e  pop r10
000075038bde0e40  pop r9
000075038bde0e42  pop r8
000075038bde0e44  pop rsi
000075038bde0e45  pop rdi
000075038bde0e46  pop rdx
000075038bde0e47  pop rcx
000075038bde0e48  pop rax
000075038bde0e49  add rsp, 0x08
000075038bde0e4d  jmp 0x000075038BDDF0D6
000075038bde0e52  sub rsp, 0x08
000075038bde0e56  push rax
000075038bde0e57  push rcx
000075038bde0e58  push rdx
000075038bde0e59  push rdi
000075038bde0e5a  push rsi
000075038bde0e5b  push r8
000075038bde0e5d  push r9
000075038bde0e5f  push r10
000075038bde0e61  push r11
000075038bde0e63  sub rsp, 0xF0
000075038bde0e6a  vmovaps [rsp], xmm0
000075038bde0e6f  vmovaps [rsp+0x10], xmm2
000075038bde0e75  vmovaps [rsp+0x20], xmm3
000075038bde0e7b  vmovaps [rsp+0x30], xmm4
000075038bde0e81  vmovaps [rsp+0x40], xmm5
000075038bde0e87  vmovaps [rsp+0x50], xmm6
000075038bde0e8d  vmovaps [rsp+0x60], xmm7
000075038bde0e93  vmovaps [rsp+0x70], xmm8
000075038bde0e99  vmovaps [rsp+0x80], xmm9
000075038bde0ea2  vmovaps [rsp+0x90], xmm10
000075038bde0eab  vmovaps [rsp+0xA0], xmm11
000075038bde0eb4  vmovaps [rsp+0xB0], xmm12
000075038bde0ebd  vmovaps [rsp+0xC0], xmm13
000075038bde0ec6  vmovaps [rsp+0xD0], xmm14
000075038bde0ecf  vmovaps [rsp+0xE0], xmm15
000075038bde0ed8  sub rsp, 0x30
000075038bde0edc  movaps [rsp], xmm1
000075038bde0ee0  movaps [rsp+0x10], xmm15
000075038bde0ee6  movaps [rsp+0x20], xmm9
000075038bde0eec  lea rdi, [rsp]
000075038bde0ef0  mov esi, 0x00
000075038bde0ef5  mov rax, 0x56ADB4492530
000075038bde0eff  call rax
000075038bde0f01  movaps xmm1, [rsp]
000075038bde0f05  add rsp, 0x30
000075038bde0f09  vmovaps xmm0, [rsp]
000075038bde0f0e  vmovaps xmm2, [rsp+0x10]
000075038bde0f14  vmovaps xmm3, [rsp+0x20]
000075038bde0f1a  vmovaps xmm4, [rsp+0x30]
000075038bde0f20  vmovaps xmm5, [rsp+0x40]
000075038bde0f26  vmovaps xmm6, [rsp+0x50]
000075038bde0f2c  vmovaps xmm7, [rsp+0x60]
000075038bde0f32  vmovaps xmm8, [rsp+0x70]
000075038bde0f38  vmovaps xmm9, [rsp+0x80]
000075038bde0f41  vmovaps xmm10, [rsp+0x90]
000075038bde0f4a  vmovaps xmm11, [rsp+0xA0]
000075038bde0f53  vmovaps xmm12, [rsp+0xB0]
000075038bde0f5c  vmovaps xmm13, [rsp+0xC0]
000075038bde0f65  vmovaps xmm14, [rsp+0xD0]
000075038bde0f6e  vmovaps xmm15, [rsp+0xE0]
000075038bde0f77  add rsp, 0xF0
000075038bde0f7e  pop r11
000075038bde0f80  pop r10
000075038bde0f82  pop r9
000075038bde0f84  pop r8
000075038bde0f86  pop rsi
000075038bde0f87  pop rdi
000075038bde0f88  pop rdx
000075038bde0f89  pop rcx
000075038bde0f8a  pop rax
000075038bde0f8b  add rsp, 0x08
000075038bde0f8f  jmp 0x000075038BDDF15E
000075038bde0f94  call 0x000075038BCC4620
000075038bde0f99  jmp 0x000075038BDDF16B
000075038bde0f9e  sub rsp, 0x08
000075038bde0fa2  push rax
000075038bde0fa3  push rcx
000075038bde0fa4  push rdx
000075038bde0fa5  push rdi
000075038bde0fa6  push rsi
000075038bde0fa7  push r8
000075038bde0fa9  push r9
000075038bde0fab  push r10
000075038bde0fad  push r11
000075038bde0faf  sub rsp, 0xF0
000075038bde0fb6  vmovaps [rsp], xmm0
000075038bde0fbb  vmovaps [rsp+0x10], xmm2
000075038bde0fc1  vmovaps [rsp+0x20], xmm3
000075038bde0fc7  vmovaps [rsp+0x30], xmm4
000075038bde0fcd  vmovaps [rsp+0x40], xmm5
000075038bde0fd3  vmovaps [rsp+0x50], xmm6
000075038bde0fd9  vmovaps [rsp+0x60], xmm7
000075038bde0fdf  vmovaps [rsp+0x70], xmm8
000075038bde0fe5  vmovaps [rsp+0x80], xmm9
000075038bde0fee  vmovaps [rsp+0x90], xmm10
000075038bde0ff7  vmovaps [rsp+0xA0], xmm11
000075038bde1000  vmovaps [rsp+0xB0], xmm12
000075038bde1009  vmovaps [rsp+0xC0], xmm13
000075038bde1012  vmovaps [rsp+0xD0], xmm14
000075038bde101b  vmovaps [rsp+0xE0], xmm15
000075038bde1024  sub rsp, 0x30
000075038bde1028  movaps [rsp], xmm1
000075038bde102c  movaps [rsp+0x10], xmm5
000075038bde1031  movaps [rsp+0x20], xmm7
000075038bde1036  lea rdi, [rsp]
000075038bde103a  mov esi, 0x00
000075038bde103f  mov rax, 0x56ADB4492530
000075038bde1049  call rax
000075038bde104b  movaps xmm1, [rsp]
000075038bde104f  add rsp, 0x30
000075038bde1053  vmovaps xmm0, [rsp]
000075038bde1058  vmovaps xmm2, [rsp+0x10]
000075038bde105e  vmovaps xmm3, [rsp+0x20]
000075038bde1064  vmovaps xmm4, [rsp+0x30]
000075038bde106a  vmovaps xmm5, [rsp+0x40]
000075038bde1070  vmovaps xmm6, [rsp+0x50]
000075038bde1076  vmovaps xmm7, [rsp+0x60]
000075038bde107c  vmovaps xmm8, [rsp+0x70]
000075038bde1082  vmovaps xmm9, [rsp+0x80]
000075038bde108b  vmovaps xmm10, [rsp+0x90]
000075038bde1094  vmovaps xmm11, [rsp+0xA0]
000075038bde109d  vmovaps xmm12, [rsp+0xB0]
000075038bde10a6  vmovaps xmm13, [rsp+0xC0]
000075038bde10af  vmovaps xmm14, [rsp+0xD0]
000075038bde10b8  vmovaps xmm15, [rsp+0xE0]
000075038bde10c1  add rsp, 0xF0
000075038bde10c8  pop r11
000075038bde10ca  pop r10
000075038bde10cc  pop r9
000075038bde10ce  pop r8
000075038bde10d0  pop rsi
000075038bde10d1  pop rdi
000075038bde10d2  pop rdx
000075038bde10d3  pop rcx
000075038bde10d4  pop rax
000075038bde10d5  add rsp, 0x08
000075038bde10d9  jmp 0x000075038BDDF210
000075038bde10de  sub rsp, 0x08
000075038bde10e2  push rax
000075038bde10e3  push rcx
000075038bde10e4  push rdx
000075038bde10e5  push rdi
000075038bde10e6  push rsi
000075038bde10e7  push r8
000075038bde10e9  push r9
000075038bde10eb  push r10
000075038bde10ed  push r11
000075038bde10ef  sub rsp, 0xF0
000075038bde10f6  vmovaps [rsp], xmm0
000075038bde10fb  vmovaps [rsp+0x10], xmm1
000075038bde1101  vmovaps [rsp+0x20], xmm2
000075038bde1107  vmovaps [rsp+0x30], xmm3
000075038bde110d  vmovaps [rsp+0x40], xmm4
000075038bde1113  vmovaps [rsp+0x50], xmm5
000075038bde1119  vmovaps [rsp+0x60], xmm6
000075038bde111f  vmovaps [rsp+0x70], xmm8
000075038bde1125  vmovaps [rsp+0x80], xmm9
000075038bde112e  vmovaps [rsp+0x90], xmm10
000075038bde1137  vmovaps [rsp+0xA0], xmm11
000075038bde1140  vmovaps [rsp+0xB0], xmm12
000075038bde1149  vmovaps [rsp+0xC0], xmm13
000075038bde1152  vmovaps [rsp+0xD0], xmm14
000075038bde115b  vmovaps [rsp+0xE0], xmm15
000075038bde1164  sub rsp, 0x30
000075038bde1168  movaps [rsp], xmm7
000075038bde116c  movaps [rsp+0x10], xmm5
000075038bde1171  movaps [rsp+0x20], xmm15
000075038bde1177  lea rdi, [rsp]
000075038bde117b  mov esi, 0x00
000075038bde1180  mov rax, 0x56ADB4492530
000075038bde118a  call rax
000075038bde118c  movaps xmm7, [rsp]
000075038bde1190  add rsp, 0x30
000075038bde1194  vmovaps xmm0, [rsp]
000075038bde1199  vmovaps xmm1, [rsp+0x10]
000075038bde119f  vmovaps xmm2, [rsp+0x20]
000075038bde11a5  vmovaps xmm3, [rsp+0x30]
000075038bde11ab  vmovaps xmm4, [rsp+0x40]
000075038bde11b1  vmovaps xmm5, [rsp+0x50]
000075038bde11b7  vmovaps xmm6, [rsp+0x60]
000075038bde11bd  vmovaps xmm8, [rsp+0x70]
000075038bde11c3  vmovaps xmm9, [rsp+0x80]
000075038bde11cc  vmovaps xmm10, [rsp+0x90]
000075038bde11d5  vmovaps xmm11, [rsp+0xA0]
000075038bde11de  vmovaps xmm12, [rsp+0xB0]
000075038bde11e7  vmovaps xmm13, [rsp+0xC0]
000075038bde11f0  vmovaps xmm14, [rsp+0xD0]
000075038bde11f9  vmovaps xmm15, [rsp+0xE0]
000075038bde1202  add rsp, 0xF0
000075038bde1209  pop r11
000075038bde120b  pop r10
000075038bde120d  pop r9
000075038bde120f  pop r8
000075038bde1211  pop rsi
000075038bde1212  pop rdi
000075038bde1213  pop rdx
000075038bde1214  pop rcx
000075038bde1215  pop rax
000075038bde1216  add rsp, 0x08
000075038bde121a  jmp 0x000075038BDDF246
000075038bde121f  call 0x000075038BCB52F0
000075038bde1224  jmp 0x000075038BDDF253
000075038bde1229  sub rsp, 0x08
000075038bde122d  push rax
000075038bde122e  push rcx
000075038bde122f  push rdx
000075038bde1230  push rdi
000075038bde1231  push rsi
000075038bde1232  push r8
000075038bde1234  push r9
000075038bde1236  push r10
000075038bde1238  push r11
000075038bde123a  sub rsp, 0xF0
000075038bde1241  vmovaps [rsp], xmm0
000075038bde1246  vmovaps [rsp+0x10], xmm1
000075038bde124c  vmovaps [rsp+0x20], xmm2
000075038bde1252  vmovaps [rsp+0x30], xmm3
000075038bde1258  vmovaps [rsp+0x40], xmm4
000075038bde125e  vmovaps [rsp+0x50], xmm5
000075038bde1264  vmovaps [rsp+0x60], xmm6
000075038bde126a  vmovaps [rsp+0x70], xmm7
000075038bde1270  vmovaps [rsp+0x80], xmm8
000075038bde1279  vmovaps [rsp+0x90], xmm9
000075038bde1282  vmovaps [rsp+0xA0], xmm10
000075038bde128b  vmovaps [rsp+0xB0], xmm11
000075038bde1294  vmovaps [rsp+0xC0], xmm12
000075038bde129d  vmovaps [rsp+0xD0], xmm13
000075038bde12a6  vmovaps [rsp+0xE0], xmm14
000075038bde12af  sub rsp, 0x30
000075038bde12b3  movaps [rsp], xmm15
000075038bde12b8  movaps [rsp+0x10], xmm5
000075038bde12bd  movaps [rsp+0x20], xmm3
000075038bde12c2  lea rdi, [rsp]
000075038bde12c6  mov esi, 0x00
000075038bde12cb  mov rax, 0x56ADB4492530
000075038bde12d5  call rax
000075038bde12d7  movaps xmm15, [rsp]
000075038bde12dc  add rsp, 0x30
000075038bde12e0  vmovaps xmm0, [rsp]
000075038bde12e5  vmovaps xmm1, [rsp+0x10]
000075038bde12eb  vmovaps xmm2, [rsp+0x20]
000075038bde12f1  vmovaps xmm3, [rsp+0x30]
000075038bde12f7  vmovaps xmm4, [rsp+0x40]
000075038bde12fd  vmovaps xmm5, [rsp+0x50]
000075038bde1303  vmovaps xmm6, [rsp+0x60]
000075038bde1309  vmovaps xmm7, [rsp+0x70]
000075038bde130f  vmovaps xmm8, [rsp+0x80]
000075038bde1318  vmovaps xmm9, [rsp+0x90]
000075038bde1321  vmovaps xmm10, [rsp+0xA0]
000075038bde132a  vmovaps xmm11, [rsp+0xB0]
000075038bde1333  vmovaps xmm12, [rsp+0xC0]
000075038bde133c  vmovaps xmm13, [rsp+0xD0]
000075038bde1345  vmovaps xmm14, [rsp+0xE0]
000075038bde134e  add rsp, 0xF0
000075038bde1355  pop r11
000075038bde1357  pop r10
000075038bde1359  pop r9
000075038bde135b  pop r8
000075038bde135d  pop rsi
000075038bde135e  pop rdi
000075038bde135f  pop rdx
000075038bde1360  pop rcx
000075038bde1361  pop rax
000075038bde1362  add rsp, 0x08
000075038bde1366  jmp 0x000075038BDDF279
000075038bde136b  sub rsp, 0x08
000075038bde136f  push rax
000075038bde1370  push rcx
000075038bde1371  push rdx
000075038bde1372  push rdi
000075038bde1373  push rsi
000075038bde1374  push r8
000075038bde1376  push r9
000075038bde1378  push r10
000075038bde137a  push r11
000075038bde137c  sub rsp, 0xF0
000075038bde1383  vmovaps [rsp], xmm0
000075038bde1388  vmovaps [rsp+0x10], xmm2
000075038bde138e  vmovaps [rsp+0x20], xmm3
000075038bde1394  vmovaps [rsp+0x30], xmm4
000075038bde139a  vmovaps [rsp+0x40], xmm5
000075038bde13a0  vmovaps [rsp+0x50], xmm6
000075038bde13a6  vmovaps [rsp+0x60], xmm7
000075038bde13ac  vmovaps [rsp+0x70], xmm8
000075038bde13b2  vmovaps [rsp+0x80], xmm9
000075038bde13bb  vmovaps [rsp+0x90], xmm10
000075038bde13c4  vmovaps [rsp+0xA0], xmm11
000075038bde13cd  vmovaps [rsp+0xB0], xmm12
000075038bde13d6  vmovaps [rsp+0xC0], xmm13
000075038bde13df  vmovaps [rsp+0xD0], xmm14
000075038bde13e8  vmovaps [rsp+0xE0], xmm15
000075038bde13f1  sub rsp, 0x30
000075038bde13f5  movaps [rsp], xmm1
000075038bde13f9  movaps [rsp+0x10], xmm5
000075038bde13fe  movaps [rsp+0x20], xmm4
000075038bde1403  lea rdi, [rsp]
000075038bde1407  mov esi, 0x00
000075038bde140c  mov rax, 0x56ADB4492530
000075038bde1416  call rax
000075038bde1418  movaps xmm1, [rsp]
000075038bde141c  add rsp, 0x30
000075038bde1420  vmovaps xmm0, [rsp]
000075038bde1425  vmovaps xmm2, [rsp+0x10]
000075038bde142b  vmovaps xmm3, [rsp+0x20]
000075038bde1431  vmovaps xmm4, [rsp+0x30]
000075038bde1437  vmovaps xmm5, [rsp+0x40]
000075038bde143d  vmovaps xmm6, [rsp+0x50]
000075038bde1443  vmovaps xmm7, [rsp+0x60]
000075038bde1449  vmovaps xmm8, [rsp+0x70]
000075038bde144f  vmovaps xmm9, [rsp+0x80]
000075038bde1458  vmovaps xmm10, [rsp+0x90]
000075038bde1461  vmovaps xmm11, [rsp+0xA0]
000075038bde146a  vmovaps xmm12, [rsp+0xB0]
000075038bde1473  vmovaps xmm13, [rsp+0xC0]
000075038bde147c  vmovaps xmm14, [rsp+0xD0]
000075038bde1485  vmovaps xmm15, [rsp+0xE0]
000075038bde148e  add rsp, 0xF0
000075038bde1495  pop r11
000075038bde1497  pop r10
000075038bde1499  pop r9
000075038bde149b  pop r8
000075038bde149d  pop rsi
000075038bde149e  pop rdi
000075038bde149f  pop rdx
000075038bde14a0  pop rcx
000075038bde14a1  pop rax
000075038bde14a2  add rsp, 0x08
000075038bde14a6  jmp 0x000075038BDDF299
000075038bde14ab  sub rsp, 0x08
000075038bde14af  push rax
000075038bde14b0  push rcx
000075038bde14b1  push rdx
000075038bde14b2  push rdi
000075038bde14b3  push rsi
000075038bde14b4  push r8
000075038bde14b6  push r9
000075038bde14b8  push r10
000075038bde14ba  push r11
000075038bde14bc  sub rsp, 0xF0
000075038bde14c3  vmovaps [rsp], xmm0
000075038bde14c8  vmovaps [rsp+0x10], xmm1
000075038bde14ce  vmovaps [rsp+0x20], xmm2
000075038bde14d4  vmovaps [rsp+0x30], xmm3
000075038bde14da  vmovaps [rsp+0x40], xmm5
000075038bde14e0  vmovaps [rsp+0x50], xmm6
000075038bde14e6  vmovaps [rsp+0x60], xmm7
000075038bde14ec  vmovaps [rsp+0x70], xmm8
000075038bde14f2  vmovaps [rsp+0x80], xmm9
000075038bde14fb  vmovaps [rsp+0x90], xmm10
000075038bde1504  vmovaps [rsp+0xA0], xmm11
000075038bde150d  vmovaps [rsp+0xB0], xmm12
000075038bde1516  vmovaps [rsp+0xC0], xmm13
000075038bde151f  vmovaps [rsp+0xD0], xmm14
000075038bde1528  vmovaps [rsp+0xE0], xmm15
000075038bde1531  sub rsp, 0x30
000075038bde1535  movaps [rsp], xmm4
000075038bde1539  movaps [rsp+0x10], xmm3
000075038bde153e  movaps [rsp+0x20], xmm5
000075038bde1543  lea rdi, [rsp]
000075038bde1547  mov esi, 0x00
000075038bde154c  mov rax, 0x56ADB4492530
000075038bde1556  call rax
000075038bde1558  movaps xmm4, [rsp]
000075038bde155c  add rsp, 0x30
000075038bde1560  vmovaps xmm0, [rsp]
000075038bde1565  vmovaps xmm1, [rsp+0x10]
000075038bde156b  vmovaps xmm2, [rsp+0x20]
000075038bde1571  vmovaps xmm3, [rsp+0x30]
000075038bde1577  vmovaps xmm5, [rsp+0x40]
000075038bde157d  vmovaps xmm6, [rsp+0x50]
000075038bde1583  vmovaps xmm7, [rsp+0x60]
000075038bde1589  vmovaps xmm8, [rsp+0x70]
000075038bde158f  vmovaps xmm9, [rsp+0x80]
000075038bde1598  vmovaps xmm10, [rsp+0x90]
000075038bde15a1  vmovaps xmm11, [rsp+0xA0]
000075038bde15aa  vmovaps xmm12, [rsp+0xB0]
000075038bde15b3  vmovaps xmm13, [rsp+0xC0]
000075038bde15bc  vmovaps xmm14, [rsp+0xD0]
000075038bde15c5  vmovaps xmm15, [rsp+0xE0]
000075038bde15ce  add rsp, 0xF0
000075038bde15d5  pop r11
000075038bde15d7  pop r10
000075038bde15d9  pop r9
000075038bde15db  pop r8
000075038bde15dd  pop rsi
000075038bde15de  pop rdi
000075038bde15df  pop rdx
000075038bde15e0  pop rcx
000075038bde15e1  pop rax
000075038bde15e2  add rsp, 0x08
000075038bde15e6  jmp 0x000075038BDDF2E7
000075038bde15eb  call 0x000075038BCB52F0
000075038bde15f0  jmp 0x000075038BDDF2F4
000075038bde15f5  sub rsp, 0x08
000075038bde15f9  push rax
000075038bde15fa  push rcx
000075038bde15fb  push rdx
000075038bde15fc  push rdi
000075038bde15fd  push rsi
000075038bde15fe  push r8
000075038bde1600  push r9
000075038bde1602  push r10
000075038bde1604  push r11
000075038bde1606  sub rsp, 0xF0
000075038bde160d  vmovaps [rsp], xmm0
000075038bde1612  vmovaps [rsp+0x10], xmm1
000075038bde1618  vmovaps [rsp+0x20], xmm2
000075038bde161e  vmovaps [rsp+0x30], xmm3
000075038bde1624  vmovaps [rsp+0x40], xmm4
000075038bde162a  vmovaps [rsp+0x50], xmm6
000075038bde1630  vmovaps [rsp+0x60], xmm7
000075038bde1636  vmovaps [rsp+0x70], xmm8
000075038bde163c  vmovaps [rsp+0x80], xmm9
000075038bde1645  vmovaps [rsp+0x90], xmm10
000075038bde164e  vmovaps [rsp+0xA0], xmm11
000075038bde1657  vmovaps [rsp+0xB0], xmm12
000075038bde1660  vmovaps [rsp+0xC0], xmm13
000075038bde1669  vmovaps [rsp+0xD0], xmm14
000075038bde1672  vmovaps [rsp+0xE0], xmm15
000075038bde167b  sub rsp, 0x30
000075038bde167f  movaps [rsp], xmm5
000075038bde1683  movaps [rsp+0x10], xmm6
000075038bde1688  movaps [rsp+0x20], xmm3
000075038bde168d  lea rdi, [rsp]
000075038bde1691  mov esi, 0x00
000075038bde1696  mov rax, 0x56ADB4492530
000075038bde16a0  call rax
000075038bde16a2  movaps xmm5, [rsp]
000075038bde16a6  add rsp, 0x30
000075038bde16aa  vmovaps xmm0, [rsp]
000075038bde16af  vmovaps xmm1, [rsp+0x10]
000075038bde16b5  vmovaps xmm2, [rsp+0x20]
000075038bde16bb  vmovaps xmm3, [rsp+0x30]
000075038bde16c1  vmovaps xmm4, [rsp+0x40]
000075038bde16c7  vmovaps xmm6, [rsp+0x50]
000075038bde16cd  vmovaps xmm7, [rsp+0x60]
000075038bde16d3  vmovaps xmm8, [rsp+0x70]
000075038bde16d9  vmovaps xmm9, [rsp+0x80]
000075038bde16e2  vmovaps xmm10, [rsp+0x90]
000075038bde16eb  vmovaps xmm11, [rsp+0xA0]
000075038bde16f4  vmovaps xmm12, [rsp+0xB0]
000075038bde16fd  vmovaps xmm13, [rsp+0xC0]
000075038bde1706  vmovaps xmm14, [rsp+0xD0]
000075038bde170f  vmovaps xmm15, [rsp+0xE0]
000075038bde1718  add rsp, 0xF0
000075038bde171f  pop r11
000075038bde1721  pop r10
000075038bde1723  pop r9
000075038bde1725  pop r8
000075038bde1727  pop rsi
000075038bde1728  pop rdi
000075038bde1729  pop rdx
000075038bde172a  pop rcx
000075038bde172b  pop rax
000075038bde172c  add rsp, 0x08
000075038bde1730  jmp 0x000075038BDDF31A
000075038bde1735  sub rsp, 0x08
000075038bde1739  push rax
000075038bde173a  push rcx
000075038bde173b  push rdx
000075038bde173c  push rdi
000075038bde173d  push rsi
000075038bde173e  push r8
000075038bde1740  push r9
000075038bde1742  push r10
000075038bde1744  push r11
000075038bde1746  sub rsp, 0xF0
000075038bde174d  vmovaps [rsp], xmm0
000075038bde1752  vmovaps [rsp+0x10], xmm1
000075038bde1758  vmovaps [rsp+0x20], xmm2
000075038bde175e  vmovaps [rsp+0x30], xmm3
000075038bde1764  vmovaps [rsp+0x40], xmm4
000075038bde176a  vmovaps [rsp+0x50], xmm5
000075038bde1770  vmovaps [rsp+0x60], xmm7
000075038bde1776  vmovaps [rsp+0x70], xmm8
000075038bde177c  vmovaps [rsp+0x80], xmm9
000075038bde1785  vmovaps [rsp+0x90], xmm10
000075038bde178e  vmovaps [rsp+0xA0], xmm11
000075038bde1797  vmovaps [rsp+0xB0], xmm12
000075038bde17a0  vmovaps [rsp+0xC0], xmm13
000075038bde17a9  vmovaps [rsp+0xD0], xmm14
000075038bde17b2  vmovaps [rsp+0xE0], xmm15
000075038bde17bb  sub rsp, 0x30
000075038bde17bf  movaps [rsp], xmm6
000075038bde17c3  movaps [rsp+0x10], xmm9
000075038bde17c9  movaps [rsp+0x20], xmm1
000075038bde17ce  lea rdi, [rsp]
000075038bde17d2  mov esi, 0x00
000075038bde17d7  mov rax, 0x56ADB4492530
000075038bde17e1  call rax
000075038bde17e3  movaps xmm6, [rsp]
000075038bde17e7  add rsp, 0x30
000075038bde17eb  vmovaps xmm0, [rsp]
000075038bde17f0  vmovaps xmm1, [rsp+0x10]
000075038bde17f6  vmovaps xmm2, [rsp+0x20]
000075038bde17fc  vmovaps xmm3, [rsp+0x30]
000075038bde1802  vmovaps xmm4, [rsp+0x40]
000075038bde1808  vmovaps xmm5, [rsp+0x50]
000075038bde180e  vmovaps xmm7, [rsp+0x60]
000075038bde1814  vmovaps xmm8, [rsp+0x70]
000075038bde181a  vmovaps xmm9, [rsp+0x80]
000075038bde1823  vmovaps xmm10, [rsp+0x90]
000075038bde182c  vmovaps xmm11, [rsp+0xA0]
000075038bde1835  vmovaps xmm12, [rsp+0xB0]
000075038bde183e  vmovaps xmm13, [rsp+0xC0]
000075038bde1847  vmovaps xmm14, [rsp+0xD0]
000075038bde1850  vmovaps xmm15, [rsp+0xE0]
000075038bde1859  add rsp, 0xF0
000075038bde1860  pop r11
000075038bde1862  pop r10
000075038bde1864  pop r9
000075038bde1866  pop r8
000075038bde1868  pop rsi
000075038bde1869  pop rdi
000075038bde186a  pop rdx
000075038bde186b  pop rcx
000075038bde186c  pop rax
000075038bde186d  add rsp, 0x08
000075038bde1871  jmp 0x000075038BDDF33E
000075038bde1876  sub rsp, 0x08
000075038bde187a  push rax
000075038bde187b  push rcx
000075038bde187c  push rdx
000075038bde187d  push rdi
000075038bde187e  push rsi
000075038bde187f  push r8
000075038bde1881  push r9
000075038bde1883  push r10
000075038bde1885  push r11
000075038bde1887  sub rsp, 0xF0
000075038bde188e  vmovaps [rsp], xmm0
000075038bde1893  vmovaps [rsp+0x10], xmm1
000075038bde1899  vmovaps [rsp+0x20], xmm2
000075038bde189f  vmovaps [rsp+0x30], xmm3
000075038bde18a5  vmovaps [rsp+0x40], xmm4
000075038bde18ab  vmovaps [rsp+0x50], xmm5
000075038bde18b1  vmovaps [rsp+0x60], xmm6
000075038bde18b7  vmovaps [rsp+0x70], xmm7
000075038bde18bd  vmovaps [rsp+0x80], xmm8
000075038bde18c6  vmovaps [rsp+0x90], xmm10
000075038bde18cf  vmovaps [rsp+0xA0], xmm11
000075038bde18d8  vmovaps [rsp+0xB0], xmm12
000075038bde18e1  vmovaps [rsp+0xC0], xmm13
000075038bde18ea  vmovaps [rsp+0xD0], xmm14
000075038bde18f3  vmovaps [rsp+0xE0], xmm15
000075038bde18fc  sub rsp, 0x30
000075038bde1900  movaps [rsp], xmm9
000075038bde1905  movaps [rsp+0x10], xmm3
000075038bde190a  movaps [rsp+0x20], xmm1
000075038bde190f  lea rdi, [rsp]
000075038bde1913  mov esi, 0x00
000075038bde1918  mov rax, 0x56ADB4492530
000075038bde1922  call rax
000075038bde1924  movaps xmm9, [rsp]
000075038bde1929  add rsp, 0x30
000075038bde192d  vmovaps xmm0, [rsp]
000075038bde1932  vmovaps xmm1, [rsp+0x10]
000075038bde1938  vmovaps xmm2, [rsp+0x20]
000075038bde193e  vmovaps xmm3, [rsp+0x30]
000075038bde1944  vmovaps xmm4, [rsp+0x40]
000075038bde194a  vmovaps xmm5, [rsp+0x50]
000075038bde1950  vmovaps xmm6, [rsp+0x60]
000075038bde1956  vmovaps xmm7, [rsp+0x70]
000075038bde195c  vmovaps xmm8, [rsp+0x80]
000075038bde1965  vmovaps xmm10, [rsp+0x90]
000075038bde196e  vmovaps xmm11, [rsp+0xA0]
000075038bde1977  vmovaps xmm12, [rsp+0xB0]
000075038bde1980  vmovaps xmm13, [rsp+0xC0]
000075038bde1989  vmovaps xmm14, [rsp+0xD0]
000075038bde1992  vmovaps xmm15, [rsp+0xE0]
000075038bde199b  add rsp, 0xF0
000075038bde19a2  pop r11
000075038bde19a4  pop r10
000075038bde19a6  pop r9
000075038bde19a8  pop r8
000075038bde19aa  pop rsi
000075038bde19ab  pop rdi
000075038bde19ac  pop rdx
000075038bde19ad  pop rcx
000075038bde19ae  pop rax
000075038bde19af  add rsp, 0x08
000075038bde19b3  jmp 0x000075038BDDF38A
000075038bde19b8  call 0x000075038BCB52F0
000075038bde19bd  jmp 0x000075038BDDF397
000075038bde19c2  sub rsp, 0x08
000075038bde19c6  push rax
000075038bde19c7  push rcx
000075038bde19c8  push rdx
000075038bde19c9  push rdi
000075038bde19ca  push rsi
000075038bde19cb  push r8
000075038bde19cd  push r9
000075038bde19cf  push r10
000075038bde19d1  push r11
000075038bde19d3  sub rsp, 0xF0
000075038bde19da  vmovaps [rsp], xmm0
000075038bde19df  vmovaps [rsp+0x10], xmm1
000075038bde19e5  vmovaps [rsp+0x20], xmm2
000075038bde19eb  vmovaps [rsp+0x30], xmm3
000075038bde19f1  vmovaps [rsp+0x40], xmm4
000075038bde19f7  vmovaps [rsp+0x50], xmm5
000075038bde19fd  vmovaps [rsp+0x60], xmm6
000075038bde1a03  vmovaps [rsp+0x70], xmm7
000075038bde1a09  vmovaps [rsp+0x80], xmm8
000075038bde1a12  vmovaps [rsp+0x90], xmm9
000075038bde1a1b  vmovaps [rsp+0xA0], xmm10
000075038bde1a24  vmovaps [rsp+0xB0], xmm11
000075038bde1a2d  vmovaps [rsp+0xC0], xmm12
000075038bde1a36  vmovaps [rsp+0xD0], xmm13
000075038bde1a3f  vmovaps [rsp+0xE0], xmm14
000075038bde1a48  sub rsp, 0x30
000075038bde1a4c  movaps [rsp], xmm15
000075038bde1a51  movaps [rsp+0x10], xmm3
000075038bde1a56  movaps [rsp+0x20], xmm7
000075038bde1a5b  lea rdi, [rsp]
000075038bde1a5f  mov esi, 0x00
000075038bde1a64  mov rax, 0x56ADB4492530
000075038bde1a6e  call rax
000075038bde1a70  movaps xmm15, [rsp]
000075038bde1a75  add rsp, 0x30
000075038bde1a79  vmovaps xmm0, [rsp]
000075038bde1a7e  vmovaps xmm1, [rsp+0x10]
000075038bde1a84  vmovaps xmm2, [rsp+0x20]
000075038bde1a8a  vmovaps xmm3, [rsp+0x30]
000075038bde1a90  vmovaps xmm4, [rsp+0x40]
000075038bde1a96  vmovaps xmm5, [rsp+0x50]
000075038bde1a9c  vmovaps xmm6, [rsp+0x60]
000075038bde1aa2  vmovaps xmm7, [rsp+0x70]
000075038bde1aa8  vmovaps xmm8, [rsp+0x80]
000075038bde1ab1  vmovaps xmm9, [rsp+0x90]
000075038bde1aba  vmovaps xmm10, [rsp+0xA0]
000075038bde1ac3  vmovaps xmm11, [rsp+0xB0]
000075038bde1acc  vmovaps xmm12, [rsp+0xC0]
000075038bde1ad5  vmovaps xmm13, [rsp+0xD0]
000075038bde1ade  vmovaps xmm14, [rsp+0xE0]
000075038bde1ae7  add rsp, 0xF0
000075038bde1aee  pop r11
000075038bde1af0  pop r10
000075038bde1af2  pop r9
000075038bde1af4  pop r8
000075038bde1af6  pop rsi
000075038bde1af7  pop rdi
000075038bde1af8  pop rdx
000075038bde1af9  pop rcx
000075038bde1afa  pop rax
000075038bde1afb  add rsp, 0x08
000075038bde1aff  jmp 0x000075038BDDF3C3
000075038bde1b04  sub rsp, 0x08
000075038bde1b08  push rax
000075038bde1b09  push rcx
000075038bde1b0a  push rdx
000075038bde1b0b  push rdi
000075038bde1b0c  push rsi
000075038bde1b0d  push r8
000075038bde1b0f  push r9
000075038bde1b11  push r10
000075038bde1b13  push r11
000075038bde1b15  sub rsp, 0xF0
000075038bde1b1c  vmovaps [rsp], xmm0
000075038bde1b21  vmovaps [rsp+0x10], xmm1
000075038bde1b27  vmovaps [rsp+0x20], xmm2
000075038bde1b2d  vmovaps [rsp+0x30], xmm4
000075038bde1b33  vmovaps [rsp+0x40], xmm5
000075038bde1b39  vmovaps [rsp+0x50], xmm6
000075038bde1b3f  vmovaps [rsp+0x60], xmm7
000075038bde1b45  vmovaps [rsp+0x70], xmm8
000075038bde1b4b  vmovaps [rsp+0x80], xmm9
000075038bde1b54  vmovaps [rsp+0x90], xmm10
000075038bde1b5d  vmovaps [rsp+0xA0], xmm11
000075038bde1b66  vmovaps [rsp+0xB0], xmm12
000075038bde1b6f  vmovaps [rsp+0xC0], xmm13
000075038bde1b78  vmovaps [rsp+0xD0], xmm14
000075038bde1b81  vmovaps [rsp+0xE0], xmm15
000075038bde1b8a  sub rsp, 0x30
000075038bde1b8e  movaps [rsp], xmm3
000075038bde1b92  movaps [rsp+0x10], xmm1
000075038bde1b97  movaps [rsp+0x20], xmm15
000075038bde1b9d  lea rdi, [rsp]
000075038bde1ba1  mov esi, 0x00
000075038bde1ba6  mov rax, 0x56ADB4492530
000075038bde1bb0  call rax
000075038bde1bb2  movaps xmm3, [rsp]
000075038bde1bb6  add rsp, 0x30
000075038bde1bba  vmovaps xmm0, [rsp]
000075038bde1bbf  vmovaps xmm1, [rsp+0x10]
000075038bde1bc5  vmovaps xmm2, [rsp+0x20]
000075038bde1bcb  vmovaps xmm4, [rsp+0x30]
000075038bde1bd1  vmovaps xmm5, [rsp+0x40]
000075038bde1bd7  vmovaps xmm6, [rsp+0x50]
000075038bde1bdd  vmovaps xmm7, [rsp+0x60]
000075038bde1be3  vmovaps xmm8, [rsp+0x70]
000075038bde1be9  vmovaps xmm9, [rsp+0x80]
000075038bde1bf2  vmovaps xmm10, [rsp+0x90]
000075038bde1bfb  vmovaps xmm11, [rsp+0xA0]
000075038bde1c04  vmovaps xmm12, [rsp+0xB0]
000075038bde1c0d  vmovaps xmm13, [rsp+0xC0]
000075038bde1c16  vmovaps xmm14, [rsp+0xD0]
000075038bde1c1f  vmovaps xmm15, [rsp+0xE0]
000075038bde1c28  add rsp, 0xF0
000075038bde1c2f  pop r11
000075038bde1c31  pop r10
000075038bde1c33  pop r9
000075038bde1c35  pop r8
000075038bde1c37  pop rsi
000075038bde1c38  pop rdi
000075038bde1c39  pop rdx
000075038bde1c3a  pop rcx
000075038bde1c3b  pop rax
000075038bde1c3c  add rsp, 0x08
000075038bde1c40  jmp 0x000075038BDDF452
000075038bde1c45  call 0x000075038BCB52F0
000075038bde1c4a  jmp 0x000075038BDDF45C
000075038bde1c4f  sub rsp, 0x08
000075038bde1c53  push rax
000075038bde1c54  push rcx
000075038bde1c55  push rdx
000075038bde1c56  push rdi
000075038bde1c57  push rsi
000075038bde1c58  push r8
000075038bde1c5a  push r9
000075038bde1c5c  push r10
000075038bde1c5e  push r11
000075038bde1c60  sub rsp, 0xF0
000075038bde1c67  vmovaps [rsp], xmm0
000075038bde1c6c  vmovaps [rsp+0x10], xmm1
000075038bde1c72  vmovaps [rsp+0x20], xmm2
000075038bde1c78  vmovaps [rsp+0x30], xmm3
000075038bde1c7e  vmovaps [rsp+0x40], xmm4
000075038bde1c84  vmovaps [rsp+0x50], xmm5
000075038bde1c8a  vmovaps [rsp+0x60], xmm6
000075038bde1c90  vmovaps [rsp+0x70], xmm7
000075038bde1c96  vmovaps [rsp+0x80], xmm8
000075038bde1c9f  vmovaps [rsp+0x90], xmm9
000075038bde1ca8  vmovaps [rsp+0xA0], xmm10
000075038bde1cb1  vmovaps [rsp+0xB0], xmm11
000075038bde1cba  vmovaps [rsp+0xC0], xmm12
000075038bde1cc3  vmovaps [rsp+0xD0], xmm13
000075038bde1ccc  vmovaps [rsp+0xE0], xmm14
000075038bde1cd5  sub rsp, 0x30
000075038bde1cd9  movaps [rsp], xmm15
000075038bde1cde  movaps [rsp+0x10], xmm14
000075038bde1ce4  movaps [rsp+0x20], xmm4
000075038bde1ce9  lea rdi, [rsp]
000075038bde1ced  mov esi, 0x00
000075038bde1cf2  mov rax, 0x56ADB4492530
000075038bde1cfc  call rax
000075038bde1cfe  movaps xmm15, [rsp]
000075038bde1d03  add rsp, 0x30
000075038bde1d07  vmovaps xmm0, [rsp]
000075038bde1d0c  vmovaps xmm1, [rsp+0x10]
000075038bde1d12  vmovaps xmm2, [rsp+0x20]
000075038bde1d18  vmovaps xmm3, [rsp+0x30]
000075038bde1d1e  vmovaps xmm4, [rsp+0x40]
000075038bde1d24  vmovaps xmm5, [rsp+0x50]
000075038bde1d2a  vmovaps xmm6, [rsp+0x60]
000075038bde1d30  vmovaps xmm7, [rsp+0x70]
000075038bde1d36  vmovaps xmm8, [rsp+0x80]
000075038bde1d3f  vmovaps xmm9, [rsp+0x90]
000075038bde1d48  vmovaps xmm10, [rsp+0xA0]
000075038bde1d51  vmovaps xmm11, [rsp+0xB0]
000075038bde1d5a  vmovaps xmm12, [rsp+0xC0]
000075038bde1d63  vmovaps xmm13, [rsp+0xD0]
000075038bde1d6c  vmovaps xmm14, [rsp+0xE0]
000075038bde1d75  add rsp, 0xF0
000075038bde1d7c  pop r11
000075038bde1d7e  pop r10
000075038bde1d80  pop r9
000075038bde1d82  pop r8
000075038bde1d84  pop rsi
000075038bde1d85  pop rdi
000075038bde1d86  pop rdx
000075038bde1d87  pop rcx
000075038bde1d88  pop rax
000075038bde1d89  add rsp, 0x08
000075038bde1d8d  jmp 0x000075038BDDF48A
000075038bde1d92  sub rsp, 0x08
000075038bde1d96  push rax
000075038bde1d97  push rcx
000075038bde1d98  push rdx
000075038bde1d99  push rdi
000075038bde1d9a  push rsi
000075038bde1d9b  push r8
000075038bde1d9d  push r9
000075038bde1d9f  push r10
000075038bde1da1  push r11
000075038bde1da3  sub rsp, 0xF0
000075038bde1daa  vmovaps [rsp], xmm0
000075038bde1daf  vmovaps [rsp+0x10], xmm1
000075038bde1db5  vmovaps [rsp+0x20], xmm2
000075038bde1dbb  vmovaps [rsp+0x30], xmm3
000075038bde1dc1  vmovaps [rsp+0x40], xmm4
000075038bde1dc7  vmovaps [rsp+0x50], xmm5
000075038bde1dcd  vmovaps [rsp+0x60], xmm6
000075038bde1dd3  vmovaps [rsp+0x70], xmm7
000075038bde1dd9  vmovaps [rsp+0x80], xmm8
000075038bde1de2  vmovaps [rsp+0x90], xmm9
000075038bde1deb  vmovaps [rsp+0xA0], xmm10
000075038bde1df4  vmovaps [rsp+0xB0], xmm11
000075038bde1dfd  vmovaps [rsp+0xC0], xmm12
000075038bde1e06  vmovaps [rsp+0xD0], xmm13
000075038bde1e0f  vmovaps [rsp+0xE0], xmm15
000075038bde1e18  sub rsp, 0x30
000075038bde1e1c  movaps [rsp], xmm14
000075038bde1e21  movaps [rsp+0x10], xmm2
000075038bde1e26  movaps [rsp+0x20], xmm1
000075038bde1e2b  lea rdi, [rsp]
000075038bde1e2f  mov esi, 0x00
000075038bde1e34  mov rax, 0x56ADB4492530
000075038bde1e3e  call rax
000075038bde1e40  movaps xmm14, [rsp]
000075038bde1e45  add rsp, 0x30
000075038bde1e49  vmovaps xmm0, [rsp]
000075038bde1e4e  vmovaps xmm1, [rsp+0x10]
000075038bde1e54  vmovaps xmm2, [rsp+0x20]
000075038bde1e5a  vmovaps xmm3, [rsp+0x30]
000075038bde1e60  vmovaps xmm4, [rsp+0x40]
000075038bde1e66  vmovaps xmm5, [rsp+0x50]
000075038bde1e6c  vmovaps xmm6, [rsp+0x60]
000075038bde1e72  vmovaps xmm7, [rsp+0x70]
000075038bde1e78  vmovaps xmm8, [rsp+0x80]
000075038bde1e81  vmovaps xmm9, [rsp+0x90]
000075038bde1e8a  vmovaps xmm10, [rsp+0xA0]
000075038bde1e93  vmovaps xmm11, [rsp+0xB0]
000075038bde1e9c  vmovaps xmm12, [rsp+0xC0]
000075038bde1ea5  vmovaps xmm13, [rsp+0xD0]
000075038bde1eae  vmovaps xmm15, [rsp+0xE0]
000075038bde1eb7  add rsp, 0xF0
000075038bde1ebe  pop r11
000075038bde1ec0  pop r10
000075038bde1ec2  pop r9
000075038bde1ec4  pop r8
000075038bde1ec6  pop rsi
000075038bde1ec7  pop rdi
000075038bde1ec8  pop rdx
000075038bde1ec9  pop rcx
000075038bde1eca  pop rax
000075038bde1ecb  add rsp, 0x08
000075038bde1ecf  jmp 0x000075038BDDF4B0
000075038bde1ed4  sub rsp, 0x08
000075038bde1ed8  push rax
000075038bde1ed9  push rcx
000075038bde1eda  push rdx
000075038bde1edb  push rdi
000075038bde1edc  push rsi
000075038bde1edd  push r8
000075038bde1edf  push r9
000075038bde1ee1  push r10
000075038bde1ee3  push r11
000075038bde1ee5  sub rsp, 0xF0
000075038bde1eec  vmovaps [rsp], xmm0
000075038bde1ef1  vmovaps [rsp+0x10], xmm2
000075038bde1ef7  vmovaps [rsp+0x20], xmm3
000075038bde1efd  vmovaps [rsp+0x30], xmm4
000075038bde1f03  vmovaps [rsp+0x40], xmm5
000075038bde1f09  vmovaps [rsp+0x50], xmm6
000075038bde1f0f  vmovaps [rsp+0x60], xmm7
000075038bde1f15  vmovaps [rsp+0x70], xmm8
000075038bde1f1b  vmovaps [rsp+0x80], xmm9
000075038bde1f24  vmovaps [rsp+0x90], xmm10
000075038bde1f2d  vmovaps [rsp+0xA0], xmm11
000075038bde1f36  vmovaps [rsp+0xB0], xmm12
000075038bde1f3f  vmovaps [rsp+0xC0], xmm13
000075038bde1f48  vmovaps [rsp+0xD0], xmm14
000075038bde1f51  vmovaps [rsp+0xE0], xmm15
000075038bde1f5a  sub rsp, 0x30
000075038bde1f5e  movaps [rsp], xmm1
000075038bde1f62  movaps [rsp+0x10], xmm4
000075038bde1f67  movaps [rsp+0x20], xmm9
000075038bde1f6d  lea rdi, [rsp]
000075038bde1f71  mov esi, 0x00
000075038bde1f76  mov rax, 0x56ADB4492530
000075038bde1f80  call rax
000075038bde1f82  movaps xmm1, [rsp]
000075038bde1f86  add rsp, 0x30
000075038bde1f8a  vmovaps xmm0, [rsp]
000075038bde1f8f  vmovaps xmm2, [rsp+0x10]
000075038bde1f95  vmovaps xmm3, [rsp+0x20]
000075038bde1f9b  vmovaps xmm4, [rsp+0x30]
000075038bde1fa1  vmovaps xmm5, [rsp+0x40]
000075038bde1fa7  vmovaps xmm6, [rsp+0x50]
000075038bde1fad  vmovaps xmm7, [rsp+0x60]
000075038bde1fb3  vmovaps xmm8, [rsp+0x70]
000075038bde1fb9  vmovaps xmm9, [rsp+0x80]
000075038bde1fc2  vmovaps xmm10, [rsp+0x90]
000075038bde1fcb  vmovaps xmm11, [rsp+0xA0]
000075038bde1fd4  vmovaps xmm12, [rsp+0xB0]
000075038bde1fdd  vmovaps xmm13, [rsp+0xC0]
000075038bde1fe6  vmovaps xmm14, [rsp+0xD0]
000075038bde1fef  vmovaps xmm15, [rsp+0xE0]
000075038bde1ff8  add rsp, 0xF0
000075038bde1fff  pop r11
000075038bde2001  pop r10
000075038bde2003  pop r9
000075038bde2005  pop r8
000075038bde2007  pop rsi
000075038bde2008  pop rdi
000075038bde2009  pop rdx
000075038bde200a  pop rcx
000075038bde200b  pop rax
000075038bde200c  add rsp, 0x08
000075038bde2010  jmp 0x000075038BDDF4CE
000075038bde2015  sub rsp, 0x08
000075038bde2019  push rax
000075038bde201a  push rcx
000075038bde201b  push rdx
000075038bde201c  push rdi
000075038bde201d  push rsi
000075038bde201e  push r8
000075038bde2020  push r9
000075038bde2022  push r10
000075038bde2024  push r11
000075038bde2026  sub rsp, 0xF0
000075038bde202d  vmovaps [rsp], xmm0
000075038bde2032  vmovaps [rsp+0x10], xmm1
000075038bde2038  vmovaps [rsp+0x20], xmm2
000075038bde203e  vmovaps [rsp+0x30], xmm3
000075038bde2044  vmovaps [rsp+0x40], xmm5
000075038bde204a  vmovaps [rsp+0x50], xmm6
000075038bde2050  vmovaps [rsp+0x60], xmm7
000075038bde2056  vmovaps [rsp+0x70], xmm8
000075038bde205c  vmovaps [rsp+0x80], xmm9
000075038bde2065  vmovaps [rsp+0x90], xmm10
000075038bde206e  vmovaps [rsp+0xA0], xmm11
000075038bde2077  vmovaps [rsp+0xB0], xmm12
000075038bde2080  vmovaps [rsp+0xC0], xmm13
000075038bde2089  vmovaps [rsp+0xD0], xmm14
000075038bde2092  vmovaps [rsp+0xE0], xmm15
000075038bde209b  sub rsp, 0x30
000075038bde209f  movaps [rsp], xmm4
000075038bde20a3  movaps [rsp+0x10], xmm2
000075038bde20a8  movaps [rsp+0x20], xmm9
000075038bde20ae  lea rdi, [rsp]
000075038bde20b2  mov esi, 0x00
000075038bde20b7  mov rax, 0x56ADB4492530
000075038bde20c1  call rax
000075038bde20c3  movaps xmm4, [rsp]
000075038bde20c7  add rsp, 0x30
000075038bde20cb  vmovaps xmm0, [rsp]
000075038bde20d0  vmovaps xmm1, [rsp+0x10]
000075038bde20d6  vmovaps xmm2, [rsp+0x20]
000075038bde20dc  vmovaps xmm3, [rsp+0x30]
000075038bde20e2  vmovaps xmm5, [rsp+0x40]
000075038bde20e8  vmovaps xmm6, [rsp+0x50]
000075038bde20ee  vmovaps xmm7, [rsp+0x60]
000075038bde20f4  vmovaps xmm8, [rsp+0x70]
000075038bde20fa  vmovaps xmm9, [rsp+0x80]
000075038bde2103  vmovaps xmm10, [rsp+0x90]
000075038bde210c  vmovaps xmm11, [rsp+0xA0]
000075038bde2115  vmovaps xmm12, [rsp+0xB0]
000075038bde211e  vmovaps xmm13, [rsp+0xC0]
000075038bde2127  vmovaps xmm14, [rsp+0xD0]
000075038bde2130  vmovaps xmm15, [rsp+0xE0]
000075038bde2139  add rsp, 0xF0
000075038bde2140  pop r11
000075038bde2142  pop r10
000075038bde2144  pop r9
000075038bde2146  pop r8
000075038bde2148  pop rsi
000075038bde2149  pop rdi
000075038bde214a  pop rdx
000075038bde214b  pop rcx
000075038bde214c  pop rax
000075038bde214d  add rsp, 0x08
000075038bde2151  jmp 0x000075038BDDF4FE
000075038bde2156  sub rsp, 0x08
000075038bde215a  push rax
000075038bde215b  push rcx
000075038bde215c  push rdx
000075038bde215d  push rdi
000075038bde215e  push rsi
000075038bde215f  push r8
000075038bde2161  push r9
000075038bde2163  push r10
000075038bde2165  push r11
000075038bde2167  sub rsp, 0xF0
000075038bde216e  vmovaps [rsp], xmm0
000075038bde2173  vmovaps [rsp+0x10], xmm1
000075038bde2179  vmovaps [rsp+0x20], xmm2
000075038bde217f  vmovaps [rsp+0x30], xmm3
000075038bde2185  vmovaps [rsp+0x40], xmm4
000075038bde218b  vmovaps [rsp+0x50], xmm5
000075038bde2191  vmovaps [rsp+0x60], xmm6
000075038bde2197  vmovaps [rsp+0x70], xmm7
000075038bde219d  vmovaps [rsp+0x80], xmm8
000075038bde21a6  vmovaps [rsp+0x90], xmm10
000075038bde21af  vmovaps [rsp+0xA0], xmm11
000075038bde21b8  vmovaps [rsp+0xB0], xmm12
000075038bde21c1  vmovaps [rsp+0xC0], xmm13
000075038bde21ca  vmovaps [rsp+0xD0], xmm14
000075038bde21d3  vmovaps [rsp+0xE0], xmm15
000075038bde21dc  sub rsp, 0x30
000075038bde21e0  movaps [rsp], xmm9
000075038bde21e5  movaps [rsp+0x10], xmm2
000075038bde21ea  movaps [rsp+0x20], xmm1
000075038bde21ef  lea rdi, [rsp]
000075038bde21f3  mov esi, 0x00
000075038bde21f8  mov rax, 0x56ADB4492530
000075038bde2202  call rax
000075038bde2204  movaps xmm9, [rsp]
000075038bde2209  add rsp, 0x30
000075038bde220d  vmovaps xmm0, [rsp]
000075038bde2212  vmovaps xmm1, [rsp+0x10]
000075038bde2218  vmovaps xmm2, [rsp+0x20]
000075038bde221e  vmovaps xmm3, [rsp+0x30]
000075038bde2224  vmovaps xmm4, [rsp+0x40]
000075038bde222a  vmovaps xmm5, [rsp+0x50]
000075038bde2230  vmovaps xmm6, [rsp+0x60]
000075038bde2236  vmovaps xmm7, [rsp+0x70]
000075038bde223c  vmovaps xmm8, [rsp+0x80]
000075038bde2245  vmovaps xmm10, [rsp+0x90]
000075038bde224e  vmovaps xmm11, [rsp+0xA0]
000075038bde2257  vmovaps xmm12, [rsp+0xB0]
000075038bde2260  vmovaps xmm13, [rsp+0xC0]
000075038bde2269  vmovaps xmm14, [rsp+0xD0]
000075038bde2272  vmovaps xmm15, [rsp+0xE0]
000075038bde227b  add rsp, 0xF0
000075038bde2282  pop r11
000075038bde2284  pop r10
000075038bde2286  pop r9
000075038bde2288  pop r8
000075038bde228a  pop rsi
000075038bde228b  pop rdi
000075038bde228c  pop rdx
000075038bde228d  pop rcx
000075038bde228e  pop rax
000075038bde228f  add rsp, 0x08
000075038bde2293  jmp 0x000075038BDDF534
000075038bde2298  sub rsp, 0x08
000075038bde229c  push rax
000075038bde229d  push rcx
000075038bde229e  push rdx
000075038bde229f  push rdi
000075038bde22a0  push rsi
000075038bde22a1  push r8
000075038bde22a3  push r9
000075038bde22a5  push r10
000075038bde22a7  push r11
000075038bde22a9  sub rsp, 0xF0
000075038bde22b0  vmovaps [rsp], xmm0
000075038bde22b5  vmovaps [rsp+0x10], xmm2
000075038bde22bb  vmovaps [rsp+0x20], xmm3
000075038bde22c1  vmovaps [rsp+0x30], xmm4
000075038bde22c7  vmovaps [rsp+0x40], xmm5
000075038bde22cd  vmovaps [rsp+0x50], xmm6
000075038bde22d3  vmovaps [rsp+0x60], xmm7
000075038bde22d9  vmovaps [rsp+0x70], xmm8
000075038bde22df  vmovaps [rsp+0x80], xmm9
000075038bde22e8  vmovaps [rsp+0x90], xmm10
000075038bde22f1  vmovaps [rsp+0xA0], xmm11
000075038bde22fa  vmovaps [rsp+0xB0], xmm12
000075038bde2303  vmovaps [rsp+0xC0], xmm13
000075038bde230c  vmovaps [rsp+0xD0], xmm14
000075038bde2315  vmovaps [rsp+0xE0], xmm15
000075038bde231e  sub rsp, 0x30
000075038bde2322  movaps [rsp], xmm1
000075038bde2326  movaps [rsp+0x10], xmm15
000075038bde232c  movaps [rsp+0x20], xmm6
000075038bde2331  lea rdi, [rsp]
000075038bde2335  mov esi, 0x00
000075038bde233a  mov rax, 0x56ADB4492530
000075038bde2344  call rax
000075038bde2346  movaps xmm1, [rsp]
000075038bde234a  add rsp, 0x30
000075038bde234e  vmovaps xmm0, [rsp]
000075038bde2353  vmovaps xmm2, [rsp+0x10]
000075038bde2359  vmovaps xmm3, [rsp+0x20]
000075038bde235f  vmovaps xmm4, [rsp+0x30]
000075038bde2365  vmovaps xmm5, [rsp+0x40]
000075038bde236b  vmovaps xmm6, [rsp+0x50]
000075038bde2371  vmovaps xmm7, [rsp+0x60]
000075038bde2377  vmovaps xmm8, [rsp+0x70]
000075038bde237d  vmovaps xmm9, [rsp+0x80]
000075038bde2386  vmovaps xmm10, [rsp+0x90]
000075038bde238f  vmovaps xmm11, [rsp+0xA0]
000075038bde2398  vmovaps xmm12, [rsp+0xB0]
000075038bde23a1  vmovaps xmm13, [rsp+0xC0]
000075038bde23aa  vmovaps xmm14, [rsp+0xD0]
000075038bde23b3  vmovaps xmm15, [rsp+0xE0]
000075038bde23bc  add rsp, 0xF0
000075038bde23c3  pop r11
000075038bde23c5  pop r10
000075038bde23c7  pop r9
000075038bde23c9  pop r8
000075038bde23cb  pop rsi
000075038bde23cc  pop rdi
000075038bde23cd  pop rdx
000075038bde23ce  pop rcx
000075038bde23cf  pop rax
000075038bde23d0  add rsp, 0x08
000075038bde23d4  jmp 0x000075038BDDF555
000075038bde23d9  sub rsp, 0x08
000075038bde23dd  push rax
000075038bde23de  push rcx
000075038bde23df  push rdx
000075038bde23e0  push rdi
000075038bde23e1  push rsi
000075038bde23e2  push r8
000075038bde23e4  push r9
000075038bde23e6  push r10
000075038bde23e8  push r11
000075038bde23ea  sub rsp, 0xF0
000075038bde23f1  vmovaps [rsp], xmm0
000075038bde23f6  vmovaps [rsp+0x10], xmm1
000075038bde23fc  vmovaps [rsp+0x20], xmm2
000075038bde2402  vmovaps [rsp+0x30], xmm3
000075038bde2408  vmovaps [rsp+0x40], xmm4
000075038bde240e  vmovaps [rsp+0x50], xmm5
000075038bde2414  vmovaps [rsp+0x60], xmm6
000075038bde241a  vmovaps [rsp+0x70], xmm7
000075038bde2420  vmovaps [rsp+0x80], xmm8
000075038bde2429  vmovaps [rsp+0x90], xmm9
000075038bde2432  vmovaps [rsp+0xA0], xmm10
000075038bde243b  vmovaps [rsp+0xB0], xmm11
000075038bde2444  vmovaps [rsp+0xC0], xmm12
000075038bde244d  vmovaps [rsp+0xD0], xmm13
000075038bde2456  vmovaps [rsp+0xE0], xmm14
000075038bde245f  sub rsp, 0x30
000075038bde2463  movaps [rsp], xmm15
000075038bde2468  movaps [rsp+0x10], xmm5
000075038bde246d  movaps [rsp+0x20], xmm3
000075038bde2472  lea rdi, [rsp]
000075038bde2476  mov esi, 0x00
000075038bde247b  mov rax, 0x56ADB4492530
000075038bde2485  call rax
000075038bde2487  movaps xmm15, [rsp]
000075038bde248c  add rsp, 0x30
000075038bde2490  vmovaps xmm0, [rsp]
000075038bde2495  vmovaps xmm1, [rsp+0x10]
000075038bde249b  vmovaps xmm2, [rsp+0x20]
000075038bde24a1  vmovaps xmm3, [rsp+0x30]
000075038bde24a7  vmovaps xmm4, [rsp+0x40]
000075038bde24ad  vmovaps xmm5, [rsp+0x50]
000075038bde24b3  vmovaps xmm6, [rsp+0x60]
000075038bde24b9  vmovaps xmm7, [rsp+0x70]
000075038bde24bf  vmovaps xmm8, [rsp+0x80]
000075038bde24c8  vmovaps xmm9, [rsp+0x90]
000075038bde24d1  vmovaps xmm10, [rsp+0xA0]
000075038bde24da  vmovaps xmm11, [rsp+0xB0]
000075038bde24e3  vmovaps xmm12, [rsp+0xC0]
000075038bde24ec  vmovaps xmm13, [rsp+0xD0]
000075038bde24f5  vmovaps xmm14, [rsp+0xE0]
000075038bde24fe  add rsp, 0xF0
000075038bde2505  pop r11
000075038bde2507  pop r10
000075038bde2509  pop r9
000075038bde250b  pop r8
000075038bde250d  pop rsi
000075038bde250e  pop rdi
000075038bde250f  pop rdx
000075038bde2510  pop rcx
000075038bde2511  pop rax
000075038bde2512  add rsp, 0x08
000075038bde2516  jmp 0x000075038BDDF56F
000075038bde251b  sub rsp, 0x08
000075038bde251f  push rax
000075038bde2520  push rcx
000075038bde2521  push rdx
000075038bde2522  push rdi
000075038bde2523  push rsi
000075038bde2524  push r8
000075038bde2526  push r9
000075038bde2528  push r10
000075038bde252a  push r11
000075038bde252c  sub rsp, 0xF0
000075038bde2533  vmovaps [rsp], xmm0
000075038bde2538  vmovaps [rsp+0x10], xmm1
000075038bde253e  vmovaps [rsp+0x20], xmm2
000075038bde2544  vmovaps [rsp+0x30], xmm3
000075038bde254a  vmovaps [rsp+0x40], xmm4
000075038bde2550  vmovaps [rsp+0x50], xmm6
000075038bde2556  vmovaps [rsp+0x60], xmm7
000075038bde255c  vmovaps [rsp+0x70], xmm8
000075038bde2562  vmovaps [rsp+0x80], xmm9
000075038bde256b  vmovaps [rsp+0x90], xmm10
000075038bde2574  vmovaps [rsp+0xA0], xmm11
000075038bde257d  vmovaps [rsp+0xB0], xmm12
000075038bde2586  vmovaps [rsp+0xC0], xmm13
000075038bde258f  vmovaps [rsp+0xD0], xmm14
000075038bde2598  vmovaps [rsp+0xE0], xmm15
000075038bde25a1  sub rsp, 0x30
000075038bde25a5  movaps [rsp], xmm5
000075038bde25a9  movaps [rsp+0x10], xmm8
000075038bde25af  movaps [rsp+0x20], xmm6
000075038bde25b4  lea rdi, [rsp]
000075038bde25b8  mov esi, 0x00
000075038bde25bd  mov rax, 0x56ADB4492530
000075038bde25c7  call rax
000075038bde25c9  movaps xmm5, [rsp]
000075038bde25cd  add rsp, 0x30
000075038bde25d1  vmovaps xmm0, [rsp]
000075038bde25d6  vmovaps xmm1, [rsp+0x10]
000075038bde25dc  vmovaps xmm2, [rsp+0x20]
000075038bde25e2  vmovaps xmm3, [rsp+0x30]
000075038bde25e8  vmovaps xmm4, [rsp+0x40]
000075038bde25ee  vmovaps xmm6, [rsp+0x50]
000075038bde25f4  vmovaps xmm7, [rsp+0x60]
000075038bde25fa  vmovaps xmm8, [rsp+0x70]
000075038bde2600  vmovaps xmm9, [rsp+0x80]
000075038bde2609  vmovaps xmm10, [rsp+0x90]
000075038bde2612  vmovaps xmm11, [rsp+0xA0]
000075038bde261b  vmovaps xmm12, [rsp+0xB0]
000075038bde2624  vmovaps xmm13, [rsp+0xC0]
000075038bde262d  vmovaps xmm14, [rsp+0xD0]
000075038bde2636  vmovaps xmm15, [rsp+0xE0]
000075038bde263f  add rsp, 0xF0
000075038bde2646  pop r11
000075038bde2648  pop r10
000075038bde264a  pop r9
000075038bde264c  pop r8
000075038bde264e  pop rsi
000075038bde264f  pop rdi
000075038bde2650  pop rdx
000075038bde2651  pop rcx
000075038bde2652  pop rax
000075038bde2653  add rsp, 0x08
000075038bde2657  jmp 0x000075038BDDF593
000075038bde265c  sub rsp, 0x08
000075038bde2660  push rax
000075038bde2661  push rcx
000075038bde2662  push rdx
000075038bde2663  push rdi
000075038bde2664  push rsi
000075038bde2665  push r8
000075038bde2667  push r9
000075038bde2669  push r10
000075038bde266b  push r11
000075038bde266d  sub rsp, 0xF0
000075038bde2674  vmovaps [rsp], xmm0
000075038bde2679  vmovaps [rsp+0x10], xmm1
000075038bde267f  vmovaps [rsp+0x20], xmm2
000075038bde2685  vmovaps [rsp+0x30], xmm3
000075038bde268b  vmovaps [rsp+0x40], xmm4
000075038bde2691  vmovaps [rsp+0x50], xmm5
000075038bde2697  vmovaps [rsp+0x60], xmm7
000075038bde269d  vmovaps [rsp+0x70], xmm8
000075038bde26a3  vmovaps [rsp+0x80], xmm9
000075038bde26ac  vmovaps [rsp+0x90], xmm10
000075038bde26b5  vmovaps [rsp+0xA0], xmm11
000075038bde26be  vmovaps [rsp+0xB0], xmm12
000075038bde26c7  vmovaps [rsp+0xC0], xmm13
000075038bde26d0  vmovaps [rsp+0xD0], xmm14
000075038bde26d9  vmovaps [rsp+0xE0], xmm15
000075038bde26e2  sub rsp, 0x30
000075038bde26e6  movaps [rsp], xmm6
000075038bde26ea  movaps [rsp+0x10], xmm10
000075038bde26f0  movaps [rsp+0x20], xmm8
000075038bde26f6  lea rdi, [rsp]
000075038bde26fa  mov esi, 0x00
000075038bde26ff  mov rax, 0x56ADB4492530
000075038bde2709  call rax
000075038bde270b  movaps xmm6, [rsp]
000075038bde270f  add rsp, 0x30
000075038bde2713  vmovaps xmm0, [rsp]
000075038bde2718  vmovaps xmm1, [rsp+0x10]
000075038bde271e  vmovaps xmm2, [rsp+0x20]
000075038bde2724  vmovaps xmm3, [rsp+0x30]
000075038bde272a  vmovaps xmm4, [rsp+0x40]
000075038bde2730  vmovaps xmm5, [rsp+0x50]
000075038bde2736  vmovaps xmm7, [rsp+0x60]
000075038bde273c  vmovaps xmm8, [rsp+0x70]
000075038bde2742  vmovaps xmm9, [rsp+0x80]
000075038bde274b  vmovaps xmm10, [rsp+0x90]
000075038bde2754  vmovaps xmm11, [rsp+0xA0]
000075038bde275d  vmovaps xmm12, [rsp+0xB0]
000075038bde2766  vmovaps xmm13, [rsp+0xC0]
000075038bde276f  vmovaps xmm14, [rsp+0xD0]
000075038bde2778  vmovaps xmm15, [rsp+0xE0]
000075038bde2781  add rsp, 0xF0
000075038bde2788  pop r11
000075038bde278a  pop r10
000075038bde278c  pop r9
000075038bde278e  pop r8
000075038bde2790  pop rsi
000075038bde2791  pop rdi
000075038bde2792  pop rdx
000075038bde2793  pop rcx
000075038bde2794  pop rax
000075038bde2795  add rsp, 0x08
000075038bde2799  jmp 0x000075038BDDF5B8
000075038bde279e  sub rsp, 0x08
000075038bde27a2  push rax
000075038bde27a3  push rcx
000075038bde27a4  push rdx
000075038bde27a5  push rdi
000075038bde27a6  push rsi
000075038bde27a7  push r8
000075038bde27a9  push r9
000075038bde27ab  push r10
000075038bde27ad  push r11
000075038bde27af  sub rsp, 0xF0
000075038bde27b6  vmovaps [rsp], xmm0
000075038bde27bb  vmovaps [rsp+0x10], xmm1
000075038bde27c1  vmovaps [rsp+0x20], xmm2
000075038bde27c7  vmovaps [rsp+0x30], xmm3
000075038bde27cd  vmovaps [rsp+0x40], xmm4
000075038bde27d3  vmovaps [rsp+0x50], xmm5
000075038bde27d9  vmovaps [rsp+0x60], xmm6
000075038bde27df  vmovaps [rsp+0x70], xmm7
000075038bde27e5  vmovaps [rsp+0x80], xmm8
000075038bde27ee  vmovaps [rsp+0x90], xmm9
000075038bde27f7  vmovaps [rsp+0xA0], xmm11
000075038bde2800  vmovaps [rsp+0xB0], xmm12
000075038bde2809  vmovaps [rsp+0xC0], xmm13
000075038bde2812  vmovaps [rsp+0xD0], xmm14
000075038bde281b  vmovaps [rsp+0xE0], xmm15
000075038bde2824  sub rsp, 0x30
000075038bde2828  movaps [rsp], xmm10
000075038bde282d  movaps [rsp+0x10], xmm8
000075038bde2833  movaps [rsp+0x20], xmm14
000075038bde2839  lea rdi, [rsp]
000075038bde283d  mov esi, 0x00
000075038bde2842  mov rax, 0x56ADB4492530
000075038bde284c  call rax
000075038bde284e  movaps xmm10, [rsp]
000075038bde2853  add rsp, 0x30
000075038bde2857  vmovaps xmm0, [rsp]
000075038bde285c  vmovaps xmm1, [rsp+0x10]
000075038bde2862  vmovaps xmm2, [rsp+0x20]
000075038bde2868  vmovaps xmm3, [rsp+0x30]
000075038bde286e  vmovaps xmm4, [rsp+0x40]
000075038bde2874  vmovaps xmm5, [rsp+0x50]
000075038bde287a  vmovaps xmm6, [rsp+0x60]
000075038bde2880  vmovaps xmm7, [rsp+0x70]
000075038bde2886  vmovaps xmm8, [rsp+0x80]
000075038bde288f  vmovaps xmm9, [rsp+0x90]
000075038bde2898  vmovaps xmm11, [rsp+0xA0]
000075038bde28a1  vmovaps xmm12, [rsp+0xB0]
000075038bde28aa  vmovaps xmm13, [rsp+0xC0]
000075038bde28b3  vmovaps xmm14, [rsp+0xD0]
000075038bde28bc  vmovaps xmm15, [rsp+0xE0]
000075038bde28c5  add rsp, 0xF0
000075038bde28cc  pop r11
000075038bde28ce  pop r10
000075038bde28d0  pop r9
000075038bde28d2  pop r8
000075038bde28d4  pop rsi
000075038bde28d5  pop rdi
000075038bde28d6  pop rdx
000075038bde28d7  pop rcx
000075038bde28d8  pop rax
000075038bde28d9  add rsp, 0x08
000075038bde28dd  jmp 0x000075038BDDF5D8
000075038bde28e2  sub rsp, 0x08
000075038bde28e6  push rax
000075038bde28e7  push rcx
000075038bde28e8  push rdx
000075038bde28e9  push rdi
000075038bde28ea  push rsi
000075038bde28eb  push r8
000075038bde28ed  push r9
000075038bde28ef  push r10
000075038bde28f1  push r11
000075038bde28f3  sub rsp, 0xF0
000075038bde28fa  vmovaps [rsp], xmm0
000075038bde28ff  vmovaps [rsp+0x10], xmm1
000075038bde2905  vmovaps [rsp+0x20], xmm2
000075038bde290b  vmovaps [rsp+0x30], xmm3
000075038bde2911  vmovaps [rsp+0x40], xmm4
000075038bde2917  vmovaps [rsp+0x50], xmm5
000075038bde291d  vmovaps [rsp+0x60], xmm6
000075038bde2923  vmovaps [rsp+0x70], xmm7
000075038bde2929  vmovaps [rsp+0x80], xmm8
000075038bde2932  vmovaps [rsp+0x90], xmm9
000075038bde293b  vmovaps [rsp+0xA0], xmm10
000075038bde2944  vmovaps [rsp+0xB0], xmm11
000075038bde294d  vmovaps [rsp+0xC0], xmm12
000075038bde2956  vmovaps [rsp+0xD0], xmm13
000075038bde295f  vmovaps [rsp+0xE0], xmm15
000075038bde2968  sub rsp, 0x30
000075038bde296c  movaps [rsp], xmm14
000075038bde2971  movaps [rsp+0x10], xmm8
000075038bde2977  movaps [rsp+0x20], xmm4
000075038bde297c  lea rdi, [rsp]
000075038bde2980  mov esi, 0x00
000075038bde2985  mov rax, 0x56ADB4492530
000075038bde298f  call rax
000075038bde2991  movaps xmm14, [rsp]
000075038bde2996  add rsp, 0x30
000075038bde299a  vmovaps xmm0, [rsp]
000075038bde299f  vmovaps xmm1, [rsp+0x10]
000075038bde29a5  vmovaps xmm2, [rsp+0x20]
000075038bde29ab  vmovaps xmm3, [rsp+0x30]
000075038bde29b1  vmovaps xmm4, [rsp+0x40]
000075038bde29b7  vmovaps xmm5, [rsp+0x50]
000075038bde29bd  vmovaps xmm6, [rsp+0x60]
000075038bde29c3  vmovaps xmm7, [rsp+0x70]
000075038bde29c9  vmovaps xmm8, [rsp+0x80]
000075038bde29d2  vmovaps xmm9, [rsp+0x90]
000075038bde29db  vmovaps xmm10, [rsp+0xA0]
000075038bde29e4  vmovaps xmm11, [rsp+0xB0]
000075038bde29ed  vmovaps xmm12, [rsp+0xC0]
000075038bde29f6  vmovaps xmm13, [rsp+0xD0]
000075038bde29ff  vmovaps xmm15, [rsp+0xE0]
000075038bde2a08  add rsp, 0xF0
000075038bde2a0f  pop r11
000075038bde2a11  pop r10
000075038bde2a13  pop r9
000075038bde2a15  pop r8
000075038bde2a17  pop rsi
000075038bde2a18  pop rdi
000075038bde2a19  pop rdx
000075038bde2a1a  pop rcx
000075038bde2a1b  pop rax
000075038bde2a1c  add rsp, 0x08
000075038bde2a20  jmp 0x000075038BDDF5F8
000075038bde2a25  sub rsp, 0x08
000075038bde2a29  push rax
000075038bde2a2a  push rcx
000075038bde2a2b  push rdx
000075038bde2a2c  push rdi
000075038bde2a2d  push rsi
000075038bde2a2e  push r8
000075038bde2a30  push r9
000075038bde2a32  push r10
000075038bde2a34  push r11
000075038bde2a36  sub rsp, 0xF0
000075038bde2a3d  vmovaps [rsp], xmm0
000075038bde2a42  vmovaps [rsp+0x10], xmm1
000075038bde2a48  vmovaps [rsp+0x20], xmm2
000075038bde2a4e  vmovaps [rsp+0x30], xmm3
000075038bde2a54  vmovaps [rsp+0x40], xmm5
000075038bde2a5a  vmovaps [rsp+0x50], xmm6
000075038bde2a60  vmovaps [rsp+0x60], xmm7
000075038bde2a66  vmovaps [rsp+0x70], xmm8
000075038bde2a6c  vmovaps [rsp+0x80], xmm9
000075038bde2a75  vmovaps [rsp+0x90], xmm10
000075038bde2a7e  vmovaps [rsp+0xA0], xmm11
000075038bde2a87  vmovaps [rsp+0xB0], xmm12
000075038bde2a90  vmovaps [rsp+0xC0], xmm13
000075038bde2a99  vmovaps [rsp+0xD0], xmm14
000075038bde2aa2  vmovaps [rsp+0xE0], xmm15
000075038bde2aab  sub rsp, 0x30
000075038bde2aaf  movaps [rsp], xmm4
000075038bde2ab3  movaps [rsp+0x10], xmm13
000075038bde2ab9  movaps [rsp+0x20], xmm8
000075038bde2abf  lea rdi, [rsp]
000075038bde2ac3  mov esi, 0x00
000075038bde2ac8  mov rax, 0x56ADB4492530
000075038bde2ad2  call rax
000075038bde2ad4  movaps xmm4, [rsp]
000075038bde2ad8  add rsp, 0x30
000075038bde2adc  vmovaps xmm0, [rsp]
000075038bde2ae1  vmovaps xmm1, [rsp+0x10]
000075038bde2ae7  vmovaps xmm2, [rsp+0x20]
000075038bde2aed  vmovaps xmm3, [rsp+0x30]
000075038bde2af3  vmovaps xmm5, [rsp+0x40]
000075038bde2af9  vmovaps xmm6, [rsp+0x50]
000075038bde2aff  vmovaps xmm7, [rsp+0x60]
000075038bde2b05  vmovaps xmm8, [rsp+0x70]
000075038bde2b0b  vmovaps xmm9, [rsp+0x80]
000075038bde2b14  vmovaps xmm10, [rsp+0x90]
000075038bde2b1d  vmovaps xmm11, [rsp+0xA0]
000075038bde2b26  vmovaps xmm12, [rsp+0xB0]
000075038bde2b2f  vmovaps xmm13, [rsp+0xC0]
000075038bde2b38  vmovaps xmm14, [rsp+0xD0]
000075038bde2b41  vmovaps xmm15, [rsp+0xE0]
000075038bde2b4a  add rsp, 0xF0
000075038bde2b51  pop r11
000075038bde2b53  pop r10
000075038bde2b55  pop r9
000075038bde2b57  pop r8
000075038bde2b59  pop rsi
000075038bde2b5a  pop rdi
000075038bde2b5b  pop rdx
000075038bde2b5c  pop rcx
000075038bde2b5d  pop rax
000075038bde2b5e  add rsp, 0x08
000075038bde2b62  jmp 0x000075038BDDF61D
000075038bde2b67  sub rsp, 0x08
000075038bde2b6b  push rax
000075038bde2b6c  push rcx
000075038bde2b6d  push rdx
000075038bde2b6e  push rdi
000075038bde2b6f  push rsi
000075038bde2b70  push r8
000075038bde2b72  push r9
000075038bde2b74  push r10
000075038bde2b76  push r11
000075038bde2b78  sub rsp, 0xF0
000075038bde2b7f  vmovaps [rsp], xmm0
000075038bde2b84  vmovaps [rsp+0x10], xmm1
000075038bde2b8a  vmovaps [rsp+0x20], xmm2
000075038bde2b90  vmovaps [rsp+0x30], xmm3
000075038bde2b96  vmovaps [rsp+0x40], xmm4
000075038bde2b9c  vmovaps [rsp+0x50], xmm5
000075038bde2ba2  vmovaps [rsp+0x60], xmm6
000075038bde2ba8  vmovaps [rsp+0x70], xmm7
000075038bde2bae  vmovaps [rsp+0x80], xmm8
000075038bde2bb7  vmovaps [rsp+0x90], xmm9
000075038bde2bc0  vmovaps [rsp+0xA0], xmm10
000075038bde2bc9  vmovaps [rsp+0xB0], xmm11
000075038bde2bd2  vmovaps [rsp+0xC0], xmm12
000075038bde2bdb  vmovaps [rsp+0xD0], xmm14
000075038bde2be4  vmovaps [rsp+0xE0], xmm15
000075038bde2bed  sub rsp, 0x30
000075038bde2bf1  movaps [rsp], xmm13
000075038bde2bf6  movaps [rsp+0x10], xmm15
000075038bde2bfc  movaps [rsp+0x20], xmm9
000075038bde2c02  lea rdi, [rsp]
000075038bde2c06  mov esi, 0x00
000075038bde2c0b  mov rax, 0x56ADB4492530
000075038bde2c15  call rax
000075038bde2c17  movaps xmm13, [rsp]
000075038bde2c1c  add rsp, 0x30
000075038bde2c20  vmovaps xmm0, [rsp]
000075038bde2c25  vmovaps xmm1, [rsp+0x10]
000075038bde2c2b  vmovaps xmm2, [rsp+0x20]
000075038bde2c31  vmovaps xmm3, [rsp+0x30]
000075038bde2c37  vmovaps xmm4, [rsp+0x40]
000075038bde2c3d  vmovaps xmm5, [rsp+0x50]
000075038bde2c43  vmovaps xmm6, [rsp+0x60]
000075038bde2c49  vmovaps xmm7, [rsp+0x70]
000075038bde2c4f  vmovaps xmm8, [rsp+0x80]
000075038bde2c58  vmovaps xmm9, [rsp+0x90]
000075038bde2c61  vmovaps xmm10, [rsp+0xA0]
000075038bde2c6a  vmovaps xmm11, [rsp+0xB0]
000075038bde2c73  vmovaps xmm12, [rsp+0xC0]
000075038bde2c7c  vmovaps xmm14, [rsp+0xD0]
000075038bde2c85  vmovaps xmm15, [rsp+0xE0]
000075038bde2c8e  add rsp, 0xF0
000075038bde2c95  pop r11
000075038bde2c97  pop r10
000075038bde2c99  pop r9
000075038bde2c9b  pop r8
000075038bde2c9d  pop rsi
000075038bde2c9e  pop rdi
000075038bde2c9f  pop rdx
000075038bde2ca0  pop rcx
000075038bde2ca1  pop rax
000075038bde2ca2  add rsp, 0x08
000075038bde2ca6  jmp 0x000075038BDDF638
000075038bde2cab  sub rsp, 0x08
000075038bde2caf  push rax
000075038bde2cb0  push rcx
000075038bde2cb1  push rdx
000075038bde2cb2  push rdi
000075038bde2cb3  push rsi
000075038bde2cb4  push r8
000075038bde2cb6  push r9
000075038bde2cb8  push r10
000075038bde2cba  push r11
000075038bde2cbc  sub rsp, 0xF0
000075038bde2cc3  vmovaps [rsp], xmm0
000075038bde2cc8  vmovaps [rsp+0x10], xmm1
000075038bde2cce  vmovaps [rsp+0x20], xmm2
000075038bde2cd4  vmovaps [rsp+0x30], xmm3
000075038bde2cda  vmovaps [rsp+0x40], xmm4
000075038bde2ce0  vmovaps [rsp+0x50], xmm5
000075038bde2ce6  vmovaps [rsp+0x60], xmm6
000075038bde2cec  vmovaps [rsp+0x70], xmm7
000075038bde2cf2  vmovaps [rsp+0x80], xmm8
000075038bde2cfb  vmovaps [rsp+0x90], xmm9
000075038bde2d04  vmovaps [rsp+0xA0], xmm10
000075038bde2d0d  vmovaps [rsp+0xB0], xmm11
000075038bde2d16  vmovaps [rsp+0xC0], xmm12
000075038bde2d1f  vmovaps [rsp+0xD0], xmm13
000075038bde2d28  vmovaps [rsp+0xE0], xmm14
000075038bde2d31  sub rsp, 0x30
000075038bde2d35  movaps [rsp], xmm15
000075038bde2d3a  movaps [rsp+0x10], xmm1
000075038bde2d3f  movaps [rsp+0x20], xmm5
000075038bde2d44  lea rdi, [rsp]
000075038bde2d48  mov esi, 0x00
000075038bde2d4d  mov rax, 0x56ADB4492530
000075038bde2d57  call rax
000075038bde2d59  movaps xmm15, [rsp]
000075038bde2d5e  add rsp, 0x30
000075038bde2d62  vmovaps xmm0, [rsp]
000075038bde2d67  vmovaps xmm1, [rsp+0x10]
000075038bde2d6d  vmovaps xmm2, [rsp+0x20]
000075038bde2d73  vmovaps xmm3, [rsp+0x30]
000075038bde2d79  vmovaps xmm4, [rsp+0x40]
000075038bde2d7f  vmovaps xmm5, [rsp+0x50]
000075038bde2d85  vmovaps xmm6, [rsp+0x60]
000075038bde2d8b  vmovaps xmm7, [rsp+0x70]
000075038bde2d91  vmovaps xmm8, [rsp+0x80]
000075038bde2d9a  vmovaps xmm9, [rsp+0x90]
000075038bde2da3  vmovaps xmm10, [rsp+0xA0]
000075038bde2dac  vmovaps xmm11, [rsp+0xB0]
000075038bde2db5  vmovaps xmm12, [rsp+0xC0]
000075038bde2dbe  vmovaps xmm13, [rsp+0xD0]
000075038bde2dc7  vmovaps xmm14, [rsp+0xE0]
000075038bde2dd0  add rsp, 0xF0
000075038bde2dd7  pop r11
000075038bde2dd9  pop r10
000075038bde2ddb  pop r9
000075038bde2ddd  pop r8
000075038bde2ddf  pop rsi
000075038bde2de0  pop rdi
000075038bde2de1  pop rdx
000075038bde2de2  pop rcx
000075038bde2de3  pop rax
000075038bde2de4  add rsp, 0x08
000075038bde2de8  jmp 0x000075038BDDF653
000075038bde2ded  call 0x000075038BCB52F0
000075038bde2df2  jmp 0x000075038BDDF6AE
000075038bde2df7  sub rsp, 0x08
000075038bde2dfb  push rax
000075038bde2dfc  push rcx
000075038bde2dfd  push rdx
000075038bde2dfe  push rdi
000075038bde2dff  push rsi
000075038bde2e00  push r8
000075038bde2e02  push r9
000075038bde2e04  push r10
000075038bde2e06  push r11
000075038bde2e08  sub rsp, 0xF0
000075038bde2e0f  vmovaps [rsp], xmm0
000075038bde2e14  vmovaps [rsp+0x10], xmm1
000075038bde2e1a  vmovaps [rsp+0x20], xmm2
000075038bde2e20  vmovaps [rsp+0x30], xmm3
000075038bde2e26  vmovaps [rsp+0x40], xmm4
000075038bde2e2c  vmovaps [rsp+0x50], xmm5
000075038bde2e32  vmovaps [rsp+0x60], xmm6
000075038bde2e38  vmovaps [rsp+0x70], xmm7
000075038bde2e3e  vmovaps [rsp+0x80], xmm8
000075038bde2e47  vmovaps [rsp+0x90], xmm10
000075038bde2e50  vmovaps [rsp+0xA0], xmm11
000075038bde2e59  vmovaps [rsp+0xB0], xmm12
000075038bde2e62  vmovaps [rsp+0xC0], xmm13
000075038bde2e6b  vmovaps [rsp+0xD0], xmm14
000075038bde2e74  vmovaps [rsp+0xE0], xmm15
000075038bde2e7d  sub rsp, 0x30
000075038bde2e81  movaps [rsp], xmm9
000075038bde2e86  movaps [rsp+0x10], xmm8
000075038bde2e8c  movaps [rsp+0x20], xmm11
000075038bde2e92  lea rdi, [rsp]
000075038bde2e96  mov esi, 0x00
000075038bde2e9b  mov rax, 0x56ADB4492530
000075038bde2ea5  call rax
000075038bde2ea7  movaps xmm9, [rsp]
000075038bde2eac  add rsp, 0x30
000075038bde2eb0  vmovaps xmm0, [rsp]
000075038bde2eb5  vmovaps xmm1, [rsp+0x10]
000075038bde2ebb  vmovaps xmm2, [rsp+0x20]
000075038bde2ec1  vmovaps xmm3, [rsp+0x30]
000075038bde2ec7  vmovaps xmm4, [rsp+0x40]
000075038bde2ecd  vmovaps xmm5, [rsp+0x50]
000075038bde2ed3  vmovaps xmm6, [rsp+0x60]
000075038bde2ed9  vmovaps xmm7, [rsp+0x70]
000075038bde2edf  vmovaps xmm8, [rsp+0x80]
000075038bde2ee8  vmovaps xmm10, [rsp+0x90]
000075038bde2ef1  vmovaps xmm11, [rsp+0xA0]
000075038bde2efa  vmovaps xmm12, [rsp+0xB0]
000075038bde2f03  vmovaps xmm13, [rsp+0xC0]
000075038bde2f0c  vmovaps xmm14, [rsp+0xD0]
000075038bde2f15  vmovaps xmm15, [rsp+0xE0]
000075038bde2f1e  add rsp, 0xF0
000075038bde2f25  pop r11
000075038bde2f27  pop r10
000075038bde2f29  pop r9
000075038bde2f2b  pop r8
000075038bde2f2d  pop rsi
000075038bde2f2e  pop rdi
000075038bde2f2f  pop rdx
000075038bde2f30  pop rcx
000075038bde2f31  pop rax
000075038bde2f32  add rsp, 0x08
000075038bde2f36  jmp 0x000075038BDDF6E5
000075038bde2f3b  sub rsp, 0x08
000075038bde2f3f  push rax
000075038bde2f40  push rcx
000075038bde2f41  push rdx
000075038bde2f42  push rdi
000075038bde2f43  push rsi
000075038bde2f44  push r8
000075038bde2f46  push r9
000075038bde2f48  push r10
000075038bde2f4a  push r11
000075038bde2f4c  sub rsp, 0xF0
000075038bde2f53  vmovaps [rsp], xmm0
000075038bde2f58  vmovaps [rsp+0x10], xmm1
000075038bde2f5e  vmovaps [rsp+0x20], xmm2
000075038bde2f64  vmovaps [rsp+0x30], xmm3
000075038bde2f6a  vmovaps [rsp+0x40], xmm4
000075038bde2f70  vmovaps [rsp+0x50], xmm5
000075038bde2f76  vmovaps [rsp+0x60], xmm6
000075038bde2f7c  vmovaps [rsp+0x70], xmm7
000075038bde2f82  vmovaps [rsp+0x80], xmm8
000075038bde2f8b  vmovaps [rsp+0x90], xmm9
000075038bde2f94  vmovaps [rsp+0xA0], xmm10
000075038bde2f9d  vmovaps [rsp+0xB0], xmm12
000075038bde2fa6  vmovaps [rsp+0xC0], xmm13
000075038bde2faf  vmovaps [rsp+0xD0], xmm14
000075038bde2fb8  vmovaps [rsp+0xE0], xmm15
000075038bde2fc1  sub rsp, 0x30
000075038bde2fc5  movaps [rsp], xmm11
000075038bde2fca  movaps [rsp+0x10], xmm10
000075038bde2fd0  movaps [rsp+0x20], xmm6
000075038bde2fd5  lea rdi, [rsp]
000075038bde2fd9  mov esi, 0x00
000075038bde2fde  mov rax, 0x56ADB4492530
000075038bde2fe8  call rax
000075038bde2fea  movaps xmm11, [rsp]
000075038bde2fef  add rsp, 0x30
000075038bde2ff3  vmovaps xmm0, [rsp]
000075038bde2ff8  vmovaps xmm1, [rsp+0x10]
000075038bde2ffe  vmovaps xmm2, [rsp+0x20]
000075038bde3004  vmovaps xmm3, [rsp+0x30]
000075038bde300a  vmovaps xmm4, [rsp+0x40]
000075038bde3010  vmovaps xmm5, [rsp+0x50]
000075038bde3016  vmovaps xmm6, [rsp+0x60]
000075038bde301c  vmovaps xmm7, [rsp+0x70]
000075038bde3022  vmovaps xmm8, [rsp+0x80]
000075038bde302b  vmovaps xmm9, [rsp+0x90]
000075038bde3034  vmovaps xmm10, [rsp+0xA0]
000075038bde303d  vmovaps xmm12, [rsp+0xB0]
000075038bde3046  vmovaps xmm13, [rsp+0xC0]
000075038bde304f  vmovaps xmm14, [rsp+0xD0]
000075038bde3058  vmovaps xmm15, [rsp+0xE0]
000075038bde3061  add rsp, 0xF0
000075038bde3068  pop r11
000075038bde306a  pop r10
000075038bde306c  pop r9
000075038bde306e  pop r8
000075038bde3070  pop rsi
000075038bde3071  pop rdi
000075038bde3072  pop rdx
000075038bde3073  pop rcx
000075038bde3074  pop rax
000075038bde3075  add rsp, 0x08
000075038bde3079  jmp 0x000075038BDDF700
000075038bde307e  sub rsp, 0x08
000075038bde3082  push rax
000075038bde3083  push rcx
000075038bde3084  push rdx
000075038bde3085  push rdi
000075038bde3086  push rsi
000075038bde3087  push r8
000075038bde3089  push r9
000075038bde308b  push r10
000075038bde308d  push r11
000075038bde308f  sub rsp, 0xF0
000075038bde3096  vmovaps [rsp], xmm0
000075038bde309b  vmovaps [rsp+0x10], xmm1
000075038bde30a1  vmovaps [rsp+0x20], xmm2
000075038bde30a7  vmovaps [rsp+0x30], xmm3
000075038bde30ad  vmovaps [rsp+0x40], xmm4
000075038bde30b3  vmovaps [rsp+0x50], xmm5
000075038bde30b9  vmovaps [rsp+0x60], xmm6
000075038bde30bf  vmovaps [rsp+0x70], xmm7
000075038bde30c5  vmovaps [rsp+0x80], xmm8
000075038bde30ce  vmovaps [rsp+0x90], xmm9
000075038bde30d7  vmovaps [rsp+0xA0], xmm11
000075038bde30e0  vmovaps [rsp+0xB0], xmm12
000075038bde30e9  vmovaps [rsp+0xC0], xmm13
000075038bde30f2  vmovaps [rsp+0xD0], xmm14
000075038bde30fb  vmovaps [rsp+0xE0], xmm15
000075038bde3104  sub rsp, 0x30
000075038bde3108  movaps [rsp], xmm10
000075038bde310d  movaps [rsp+0x10], xmm14
000075038bde3113  movaps [rsp+0x20], xmm4
000075038bde3118  lea rdi, [rsp]
000075038bde311c  mov esi, 0x00
000075038bde3121  mov rax, 0x56ADB4492530
000075038bde312b  call rax
000075038bde312d  movaps xmm10, [rsp]
000075038bde3132  add rsp, 0x30
000075038bde3136  vmovaps xmm0, [rsp]
000075038bde313b  vmovaps xmm1, [rsp+0x10]
000075038bde3141  vmovaps xmm2, [rsp+0x20]
000075038bde3147  vmovaps xmm3, [rsp+0x30]
000075038bde314d  vmovaps xmm4, [rsp+0x40]
000075038bde3153  vmovaps xmm5, [rsp+0x50]
000075038bde3159  vmovaps xmm6, [rsp+0x60]
000075038bde315f  vmovaps xmm7, [rsp+0x70]
000075038bde3165  vmovaps xmm8, [rsp+0x80]
000075038bde316e  vmovaps xmm9, [rsp+0x90]
000075038bde3177  vmovaps xmm11, [rsp+0xA0]
000075038bde3180  vmovaps xmm12, [rsp+0xB0]
000075038bde3189  vmovaps xmm13, [rsp+0xC0]
000075038bde3192  vmovaps xmm14, [rsp+0xD0]
000075038bde319b  vmovaps xmm15, [rsp+0xE0]
000075038bde31a4  add rsp, 0xF0
000075038bde31ab  pop r11
000075038bde31ad  pop r10
000075038bde31af  pop r9
000075038bde31b1  pop r8
000075038bde31b3  pop rsi
000075038bde31b4  pop rdi
000075038bde31b5  pop rdx
000075038bde31b6  pop rcx
000075038bde31b7  pop rax
000075038bde31b8  add rsp, 0x08
000075038bde31bc  jmp 0x000075038BDDF71B
000075038bde31c1  sub rsp, 0x08
000075038bde31c5  push rax
000075038bde31c6  push rcx
000075038bde31c7  push rdx
000075038bde31c8  push rdi
000075038bde31c9  push rsi
000075038bde31ca  push r8
000075038bde31cc  push r9
000075038bde31ce  push r10
000075038bde31d0  push r11
000075038bde31d2  sub rsp, 0xF0
000075038bde31d9  vmovaps [rsp], xmm0
000075038bde31de  vmovaps [rsp+0x10], xmm1
000075038bde31e4  vmovaps [rsp+0x20], xmm2
000075038bde31ea  vmovaps [rsp+0x30], xmm3
000075038bde31f0  vmovaps [rsp+0x40], xmm4
000075038bde31f6  vmovaps [rsp+0x50], xmm5
000075038bde31fc  vmovaps [rsp+0x60], xmm6
000075038bde3202  vmovaps [rsp+0x70], xmm7
000075038bde3208  vmovaps [rsp+0x80], xmm9
000075038bde3211  vmovaps [rsp+0x90], xmm10
000075038bde321a  vmovaps [rsp+0xA0], xmm11
000075038bde3223  vmovaps [rsp+0xB0], xmm12
000075038bde322c  vmovaps [rsp+0xC0], xmm13
000075038bde3235  vmovaps [rsp+0xD0], xmm14
000075038bde323e  vmovaps [rsp+0xE0], xmm15
000075038bde3247  sub rsp, 0x30
000075038bde324b  movaps [rsp], xmm8
000075038bde3250  movaps [rsp+0x10], xmm1
000075038bde3255  movaps [rsp+0x20], xmm14
000075038bde325b  lea rdi, [rsp]
000075038bde325f  mov esi, 0x00
000075038bde3264  mov rax, 0x56ADB4492530
000075038bde326e  call rax
000075038bde3270  movaps xmm8, [rsp]
000075038bde3275  add rsp, 0x30
000075038bde3279  vmovaps xmm0, [rsp]
000075038bde327e  vmovaps xmm1, [rsp+0x10]
000075038bde3284  vmovaps xmm2, [rsp+0x20]
000075038bde328a  vmovaps xmm3, [rsp+0x30]
000075038bde3290  vmovaps xmm4, [rsp+0x40]
000075038bde3296  vmovaps xmm5, [rsp+0x50]
000075038bde329c  vmovaps xmm6, [rsp+0x60]
000075038bde32a2  vmovaps xmm7, [rsp+0x70]
000075038bde32a8  vmovaps xmm9, [rsp+0x80]
000075038bde32b1  vmovaps xmm10, [rsp+0x90]
000075038bde32ba  vmovaps xmm11, [rsp+0xA0]
000075038bde32c3  vmovaps xmm12, [rsp+0xB0]
000075038bde32cc  vmovaps xmm13, [rsp+0xC0]
000075038bde32d5  vmovaps xmm14, [rsp+0xD0]
000075038bde32de  vmovaps xmm15, [rsp+0xE0]
000075038bde32e7  add rsp, 0xF0
000075038bde32ee  pop r11
000075038bde32f0  pop r10
000075038bde32f2  pop r9
000075038bde32f4  pop r8
000075038bde32f6  pop rsi
000075038bde32f7  pop rdi
000075038bde32f8  pop rdx
000075038bde32f9  pop rcx
000075038bde32fa  pop rax
000075038bde32fb  add rsp, 0x08
000075038bde32ff  jmp 0x000075038BDDF741
000075038bde3304  sub rsp, 0x08
000075038bde3308  push rax
000075038bde3309  push rcx
000075038bde330a  push rdx
000075038bde330b  push rdi
000075038bde330c  push rsi
000075038bde330d  push r8
000075038bde330f  push r9
000075038bde3311  push r10
000075038bde3313  push r11
000075038bde3315  sub rsp, 0xF0
000075038bde331c  vmovaps [rsp], xmm0
000075038bde3321  vmovaps [rsp+0x10], xmm1
000075038bde3327  vmovaps [rsp+0x20], xmm2
000075038bde332d  vmovaps [rsp+0x30], xmm3
000075038bde3333  vmovaps [rsp+0x40], xmm4
000075038bde3339  vmovaps [rsp+0x50], xmm5
000075038bde333f  vmovaps [rsp+0x60], xmm7
000075038bde3345  vmovaps [rsp+0x70], xmm8
000075038bde334b  vmovaps [rsp+0x80], xmm9
000075038bde3354  vmovaps [rsp+0x90], xmm10
000075038bde335d  vmovaps [rsp+0xA0], xmm11
000075038bde3366  vmovaps [rsp+0xB0], xmm12
000075038bde336f  vmovaps [rsp+0xC0], xmm13
000075038bde3378  vmovaps [rsp+0xD0], xmm14
000075038bde3381  vmovaps [rsp+0xE0], xmm15
000075038bde338a  sub rsp, 0x30
000075038bde338e  movaps [rsp], xmm6
000075038bde3392  movaps [rsp+0x10], xmm1
000075038bde3397  movaps [rsp+0x20], xmm14
000075038bde339d  lea rdi, [rsp]
000075038bde33a1  mov esi, 0x00
000075038bde33a6  mov rax, 0x56ADB4492530
000075038bde33b0  call rax
000075038bde33b2  movaps xmm6, [rsp]
000075038bde33b6  add rsp, 0x30
000075038bde33ba  vmovaps xmm0, [rsp]
000075038bde33bf  vmovaps xmm1, [rsp+0x10]
000075038bde33c5  vmovaps xmm2, [rsp+0x20]
000075038bde33cb  vmovaps xmm3, [rsp+0x30]
000075038bde33d1  vmovaps xmm4, [rsp+0x40]
000075038bde33d7  vmovaps xmm5, [rsp+0x50]
000075038bde33dd  vmovaps xmm7, [rsp+0x60]
000075038bde33e3  vmovaps xmm8, [rsp+0x70]
000075038bde33e9  vmovaps xmm9, [rsp+0x80]
000075038bde33f2  vmovaps xmm10, [rsp+0x90]
000075038bde33fb  vmovaps xmm11, [rsp+0xA0]
000075038bde3404  vmovaps xmm12, [rsp+0xB0]
000075038bde340d  vmovaps xmm13, [rsp+0xC0]
000075038bde3416  vmovaps xmm14, [rsp+0xD0]
000075038bde341f  vmovaps xmm15, [rsp+0xE0]
000075038bde3428  add rsp, 0xF0
000075038bde342f  pop r11
000075038bde3431  pop r10
000075038bde3433  pop r9
000075038bde3435  pop r8
000075038bde3437  pop rsi
000075038bde3438  pop rdi
000075038bde3439  pop rdx
000075038bde343a  pop rcx
000075038bde343b  pop rax
000075038bde343c  add rsp, 0x08
000075038bde3440  jmp 0x000075038BDDF76D
000075038bde3445  sub rsp, 0x08
000075038bde3449  push rax
000075038bde344a  push rcx
000075038bde344b  push rdx
000075038bde344c  push rdi
000075038bde344d  push rsi
000075038bde344e  push r8
000075038bde3450  push r9
000075038bde3452  push r10
000075038bde3454  push r11
000075038bde3456  sub rsp, 0xF0
000075038bde345d  vmovaps [rsp], xmm0
000075038bde3462  vmovaps [rsp+0x10], xmm1
000075038bde3468  vmovaps [rsp+0x20], xmm2
000075038bde346e  vmovaps [rsp+0x30], xmm3
000075038bde3474  vmovaps [rsp+0x40], xmm4
000075038bde347a  vmovaps [rsp+0x50], xmm5
000075038bde3480  vmovaps [rsp+0x60], xmm6
000075038bde3486  vmovaps [rsp+0x70], xmm7
000075038bde348c  vmovaps [rsp+0x80], xmm8
000075038bde3495  vmovaps [rsp+0x90], xmm9
000075038bde349e  vmovaps [rsp+0xA0], xmm10
000075038bde34a7  vmovaps [rsp+0xB0], xmm11
000075038bde34b0  vmovaps [rsp+0xC0], xmm12
000075038bde34b9  vmovaps [rsp+0xD0], xmm13
000075038bde34c2  vmovaps [rsp+0xE0], xmm15
000075038bde34cb  sub rsp, 0x30
000075038bde34cf  movaps [rsp], xmm14
000075038bde34d4  movaps [rsp+0x10], xmm12
000075038bde34da  movaps [rsp+0x20], xmm1
000075038bde34df  lea rdi, [rsp]
000075038bde34e3  mov esi, 0x00
000075038bde34e8  mov rax, 0x56ADB4492530
000075038bde34f2  call rax
000075038bde34f4  movaps xmm14, [rsp]
000075038bde34f9  add rsp, 0x30
000075038bde34fd  vmovaps xmm0, [rsp]
000075038bde3502  vmovaps xmm1, [rsp+0x10]
000075038bde3508  vmovaps xmm2, [rsp+0x20]
000075038bde350e  vmovaps xmm3, [rsp+0x30]
000075038bde3514  vmovaps xmm4, [rsp+0x40]
000075038bde351a  vmovaps xmm5, [rsp+0x50]
000075038bde3520  vmovaps xmm6, [rsp+0x60]
000075038bde3526  vmovaps xmm7, [rsp+0x70]
000075038bde352c  vmovaps xmm8, [rsp+0x80]
000075038bde3535  vmovaps xmm9, [rsp+0x90]
000075038bde353e  vmovaps xmm10, [rsp+0xA0]
000075038bde3547  vmovaps xmm11, [rsp+0xB0]
000075038bde3550  vmovaps xmm12, [rsp+0xC0]
000075038bde3559  vmovaps xmm13, [rsp+0xD0]
000075038bde3562  vmovaps xmm15, [rsp+0xE0]
000075038bde356b  add rsp, 0xF0
000075038bde3572  pop r11
000075038bde3574  pop r10
000075038bde3576  pop r9
000075038bde3578  pop r8
000075038bde357a  pop rsi
000075038bde357b  pop rdi
000075038bde357c  pop rdx
000075038bde357d  pop rcx
000075038bde357e  pop rax
000075038bde357f  add rsp, 0x08
000075038bde3583  jmp 0x000075038BDDF793
000075038bde3588  sub rsp, 0x08
000075038bde358c  push rax
000075038bde358d  push rcx
000075038bde358e  push rdx
000075038bde358f  push rdi
000075038bde3590  push rsi
000075038bde3591  push r8
000075038bde3593  push r9
000075038bde3595  push r10
000075038bde3597  push r11
000075038bde3599  sub rsp, 0xF0
000075038bde35a0  vmovaps [rsp], xmm0
000075038bde35a5  vmovaps [rsp+0x10], xmm2
000075038bde35ab  vmovaps [rsp+0x20], xmm3
000075038bde35b1  vmovaps [rsp+0x30], xmm4
000075038bde35b7  vmovaps [rsp+0x40], xmm5
000075038bde35bd  vmovaps [rsp+0x50], xmm6
000075038bde35c3  vmovaps [rsp+0x60], xmm7
000075038bde35c9  vmovaps [rsp+0x70], xmm8
000075038bde35cf  vmovaps [rsp+0x80], xmm9
000075038bde35d8  vmovaps [rsp+0x90], xmm10
000075038bde35e1  vmovaps [rsp+0xA0], xmm11
000075038bde35ea  vmovaps [rsp+0xB0], xmm12
000075038bde35f3  vmovaps [rsp+0xC0], xmm13
000075038bde35fc  vmovaps [rsp+0xD0], xmm14
000075038bde3605  vmovaps [rsp+0xE0], xmm15
000075038bde360e  sub rsp, 0x30
000075038bde3612  movaps [rsp], xmm1
000075038bde3616  movaps [rsp+0x10], xmm13
000075038bde361c  movaps [rsp+0x20], xmm9
000075038bde3622  lea rdi, [rsp]
000075038bde3626  mov esi, 0x00
000075038bde362b  mov rax, 0x56ADB4492530
000075038bde3635  call rax
000075038bde3637  movaps xmm1, [rsp]
000075038bde363b  add rsp, 0x30
000075038bde363f  vmovaps xmm0, [rsp]
000075038bde3644  vmovaps xmm2, [rsp+0x10]
000075038bde364a  vmovaps xmm3, [rsp+0x20]
000075038bde3650  vmovaps xmm4, [rsp+0x30]
000075038bde3656  vmovaps xmm5, [rsp+0x40]
000075038bde365c  vmovaps xmm6, [rsp+0x50]
000075038bde3662  vmovaps xmm7, [rsp+0x60]
000075038bde3668  vmovaps xmm8, [rsp+0x70]
000075038bde366e  vmovaps xmm9, [rsp+0x80]
000075038bde3677  vmovaps xmm10, [rsp+0x90]
000075038bde3680  vmovaps xmm11, [rsp+0xA0]
000075038bde3689  vmovaps xmm12, [rsp+0xB0]
000075038bde3692  vmovaps xmm13, [rsp+0xC0]
000075038bde369b  vmovaps xmm14, [rsp+0xD0]
000075038bde36a4  vmovaps xmm15, [rsp+0xE0]
000075038bde36ad  add rsp, 0xF0
000075038bde36b4  pop r11
000075038bde36b6  pop r10
000075038bde36b8  pop r9
000075038bde36ba  pop r8
000075038bde36bc  pop rsi
000075038bde36bd  pop rdi
000075038bde36be  pop rdx
000075038bde36bf  pop rcx
000075038bde36c0  pop rax
000075038bde36c1  add rsp, 0x08
000075038bde36c5  jmp 0x000075038BDDF7AD
000075038bde36ca  sub rsp, 0x08
000075038bde36ce  push rax
000075038bde36cf  push rcx
000075038bde36d0  push rdx
000075038bde36d1  push rdi
000075038bde36d2  push rsi
000075038bde36d3  push r8
000075038bde36d5  push r9
000075038bde36d7  push r10
000075038bde36d9  push r11
000075038bde36db  sub rsp, 0xF0
000075038bde36e2  vmovaps [rsp], xmm0
000075038bde36e7  vmovaps [rsp+0x10], xmm1
000075038bde36ed  vmovaps [rsp+0x20], xmm2
000075038bde36f3  vmovaps [rsp+0x30], xmm3
000075038bde36f9  vmovaps [rsp+0x40], xmm4
000075038bde36ff  vmovaps [rsp+0x50], xmm5
000075038bde3705  vmovaps [rsp+0x60], xmm6
000075038bde370b  vmovaps [rsp+0x70], xmm7
000075038bde3711  vmovaps [rsp+0x80], xmm8
000075038bde371a  vmovaps [rsp+0x90], xmm9
000075038bde3723  vmovaps [rsp+0xA0], xmm10
000075038bde372c  vmovaps [rsp+0xB0], xmm11
000075038bde3735  vmovaps [rsp+0xC0], xmm13
000075038bde373e  vmovaps [rsp+0xD0], xmm14
000075038bde3747  vmovaps [rsp+0xE0], xmm15
000075038bde3750  sub rsp, 0x30
000075038bde3754  movaps [rsp], xmm12
000075038bde3759  movaps [rsp+0x10], xmm7
000075038bde375e  movaps [rsp+0x20], xmm13
000075038bde3764  lea rdi, [rsp]
000075038bde3768  mov esi, 0x00
000075038bde376d  mov rax, 0x56ADB4492530
000075038bde3777  call rax
000075038bde3779  movaps xmm12, [rsp]
000075038bde377e  add rsp, 0x30
000075038bde3782  vmovaps xmm0, [rsp]
000075038bde3787  vmovaps xmm1, [rsp+0x10]
000075038bde378d  vmovaps xmm2, [rsp+0x20]
000075038bde3793  vmovaps xmm3, [rsp+0x30]
000075038bde3799  vmovaps xmm4, [rsp+0x40]
000075038bde379f  vmovaps xmm5, [rsp+0x50]
000075038bde37a5  vmovaps xmm6, [rsp+0x60]
000075038bde37ab  vmovaps xmm7, [rsp+0x70]
000075038bde37b1  vmovaps xmm8, [rsp+0x80]
000075038bde37ba  vmovaps xmm9, [rsp+0x90]
000075038bde37c3  vmovaps xmm10, [rsp+0xA0]
000075038bde37cc  vmovaps xmm11, [rsp+0xB0]
000075038bde37d5  vmovaps xmm13, [rsp+0xC0]
000075038bde37de  vmovaps xmm14, [rsp+0xD0]
000075038bde37e7  vmovaps xmm15, [rsp+0xE0]
000075038bde37f0  add rsp, 0xF0
000075038bde37f7  pop r11
000075038bde37f9  pop r10
000075038bde37fb  pop r9
000075038bde37fd  pop r8
000075038bde37ff  pop rsi
000075038bde3800  pop rdi
000075038bde3801  pop rdx
000075038bde3802  pop rcx
000075038bde3803  pop rax
000075038bde3804  add rsp, 0x08
000075038bde3808  jmp 0x000075038BDDF7D4
000075038bde380d  sub rsp, 0x08
000075038bde3811  push rax
000075038bde3812  push rcx
000075038bde3813  push rdx
000075038bde3814  push rdi
000075038bde3815  push rsi
000075038bde3816  push r8
000075038bde3818  push r9
000075038bde381a  push r10
000075038bde381c  push r11
000075038bde381e  sub rsp, 0xF0
000075038bde3825  vmovaps [rsp], xmm0
000075038bde382a  vmovaps [rsp+0x10], xmm1
000075038bde3830  vmovaps [rsp+0x20], xmm2
000075038bde3836  vmovaps [rsp+0x30], xmm3
000075038bde383c  vmovaps [rsp+0x40], xmm4
000075038bde3842  vmovaps [rsp+0x50], xmm5
000075038bde3848  vmovaps [rsp+0x60], xmm6
000075038bde384e  vmovaps [rsp+0x70], xmm7
000075038bde3854  vmovaps [rsp+0x80], xmm8
000075038bde385d  vmovaps [rsp+0x90], xmm9
000075038bde3866  vmovaps [rsp+0xA0], xmm10
000075038bde386f  vmovaps [rsp+0xB0], xmm11
000075038bde3878  vmovaps [rsp+0xC0], xmm12
000075038bde3881  vmovaps [rsp+0xD0], xmm14
000075038bde388a  vmovaps [rsp+0xE0], xmm15
000075038bde3893  sub rsp, 0x30
000075038bde3897  movaps [rsp], xmm13
000075038bde389c  movaps [rsp+0x10], xmm15
000075038bde38a2  movaps [rsp+0x20], xmm8
000075038bde38a8  lea rdi, [rsp]
000075038bde38ac  mov esi, 0x00
000075038bde38b1  mov rax, 0x56ADB4492530
000075038bde38bb  call rax
000075038bde38bd  movaps xmm13, [rsp]
000075038bde38c2  add rsp, 0x30
000075038bde38c6  vmovaps xmm0, [rsp]
000075038bde38cb  vmovaps xmm1, [rsp+0x10]
000075038bde38d1  vmovaps xmm2, [rsp+0x20]
000075038bde38d7  vmovaps xmm3, [rsp+0x30]
000075038bde38dd  vmovaps xmm4, [rsp+0x40]
000075038bde38e3  vmovaps xmm5, [rsp+0x50]
000075038bde38e9  vmovaps xmm6, [rsp+0x60]
000075038bde38ef  vmovaps xmm7, [rsp+0x70]
000075038bde38f5  vmovaps xmm8, [rsp+0x80]
000075038bde38fe  vmovaps xmm9, [rsp+0x90]
000075038bde3907  vmovaps xmm10, [rsp+0xA0]
000075038bde3910  vmovaps xmm11, [rsp+0xB0]
000075038bde3919  vmovaps xmm12, [rsp+0xC0]
000075038bde3922  vmovaps xmm14, [rsp+0xD0]
000075038bde392b  vmovaps xmm15, [rsp+0xE0]
000075038bde3934  add rsp, 0xF0
000075038bde393b  pop r11
000075038bde393d  pop r10
000075038bde393f  pop r9
000075038bde3941  pop r8
000075038bde3943  pop rsi
000075038bde3944  pop rdi
000075038bde3945  pop rdx
000075038bde3946  pop rcx
000075038bde3947  pop rax
000075038bde3948  add rsp, 0x08
000075038bde394c  jmp 0x000075038BDDF7EF
000075038bde3951  sub rsp, 0x08
000075038bde3955  push rax
000075038bde3956  push rcx
000075038bde3957  push rdx
000075038bde3958  push rdi
000075038bde3959  push rsi
000075038bde395a  push r8
000075038bde395c  push r9
000075038bde395e  push r10
000075038bde3960  push r11
000075038bde3962  sub rsp, 0xF0
000075038bde3969  vmovaps [rsp], xmm0
000075038bde396e  vmovaps [rsp+0x10], xmm1
000075038bde3974  vmovaps [rsp+0x20], xmm2
000075038bde397a  vmovaps [rsp+0x30], xmm3
000075038bde3980  vmovaps [rsp+0x40], xmm4
000075038bde3986  vmovaps [rsp+0x50], xmm5
000075038bde398c  vmovaps [rsp+0x60], xmm6
000075038bde3992  vmovaps [rsp+0x70], xmm7
000075038bde3998  vmovaps [rsp+0x80], xmm9
000075038bde39a1  vmovaps [rsp+0x90], xmm10
000075038bde39aa  vmovaps [rsp+0xA0], xmm11
000075038bde39b3  vmovaps [rsp+0xB0], xmm12
000075038bde39bc  vmovaps [rsp+0xC0], xmm13
000075038bde39c5  vmovaps [rsp+0xD0], xmm14
000075038bde39ce  vmovaps [rsp+0xE0], xmm15
000075038bde39d7  sub rsp, 0x30
000075038bde39db  movaps [rsp], xmm8
000075038bde39e0  movaps [rsp+0x10], xmm15
000075038bde39e6  movaps [rsp+0x20], xmm9
000075038bde39ec  lea rdi, [rsp]
000075038bde39f0  mov esi, 0x00
000075038bde39f5  mov rax, 0x56ADB4492530
000075038bde39ff  call rax
000075038bde3a01  movaps xmm8, [rsp]
000075038bde3a06  add rsp, 0x30
000075038bde3a0a  vmovaps xmm0, [rsp]
000075038bde3a0f  vmovaps xmm1, [rsp+0x10]
000075038bde3a15  vmovaps xmm2, [rsp+0x20]
000075038bde3a1b  vmovaps xmm3, [rsp+0x30]
000075038bde3a21  vmovaps xmm4, [rsp+0x40]
000075038bde3a27  vmovaps xmm5, [rsp+0x50]
000075038bde3a2d  vmovaps xmm6, [rsp+0x60]
000075038bde3a33  vmovaps xmm7, [rsp+0x70]
000075038bde3a39  vmovaps xmm9, [rsp+0x80]
000075038bde3a42  vmovaps xmm10, [rsp+0x90]
000075038bde3a4b  vmovaps xmm11, [rsp+0xA0]
000075038bde3a54  vmovaps xmm12, [rsp+0xB0]
000075038bde3a5d  vmovaps xmm13, [rsp+0xC0]
000075038bde3a66  vmovaps xmm14, [rsp+0xD0]
000075038bde3a6f  vmovaps xmm15, [rsp+0xE0]
000075038bde3a78  add rsp, 0xF0
000075038bde3a7f  pop r11
000075038bde3a81  pop r10
000075038bde3a83  pop r9
000075038bde3a85  pop r8
000075038bde3a87  pop rsi
000075038bde3a88  pop rdi
000075038bde3a89  pop rdx
000075038bde3a8a  pop rcx
000075038bde3a8b  pop rax
000075038bde3a8c  add rsp, 0x08
000075038bde3a90  jmp 0x000075038BDDF81D
000075038bde3a95  sub rsp, 0x08
000075038bde3a99  push rax
000075038bde3a9a  push rcx
000075038bde3a9b  push rdx
000075038bde3a9c  push rdi
000075038bde3a9d  push rsi
000075038bde3a9e  push r8
000075038bde3aa0  push r9
000075038bde3aa2  push r10
000075038bde3aa4  push r11
000075038bde3aa6  sub rsp, 0xF0
000075038bde3aad  vmovaps [rsp], xmm0
000075038bde3ab2  vmovaps [rsp+0x10], xmm1
000075038bde3ab8  vmovaps [rsp+0x20], xmm2
000075038bde3abe  vmovaps [rsp+0x30], xmm3
000075038bde3ac4  vmovaps [rsp+0x40], xmm4
000075038bde3aca  vmovaps [rsp+0x50], xmm5
000075038bde3ad0  vmovaps [rsp+0x60], xmm6
000075038bde3ad6  vmovaps [rsp+0x70], xmm7
000075038bde3adc  vmovaps [rsp+0x80], xmm8
000075038bde3ae5  vmovaps [rsp+0x90], xmm9
000075038bde3aee  vmovaps [rsp+0xA0], xmm10
000075038bde3af7  vmovaps [rsp+0xB0], xmm11
000075038bde3b00  vmovaps [rsp+0xC0], xmm12
000075038bde3b09  vmovaps [rsp+0xD0], xmm13
000075038bde3b12  vmovaps [rsp+0xE0], xmm14
000075038bde3b1b  sub rsp, 0x30
000075038bde3b1f  movaps [rsp], xmm15
000075038bde3b24  movaps [rsp+0x10], xmm11
000075038bde3b2a  movaps [rsp+0x20], xmm6
000075038bde3b2f  lea rdi, [rsp]
000075038bde3b33  mov esi, 0x00
000075038bde3b38  mov rax, 0x56ADB4492530
000075038bde3b42  call rax
000075038bde3b44  movaps xmm15, [rsp]
000075038bde3b49  add rsp, 0x30
000075038bde3b4d  vmovaps xmm0, [rsp]
000075038bde3b52  vmovaps xmm1, [rsp+0x10]
000075038bde3b58  vmovaps xmm2, [rsp+0x20]
000075038bde3b5e  vmovaps xmm3, [rsp+0x30]
000075038bde3b64  vmovaps xmm4, [rsp+0x40]
000075038bde3b6a  vmovaps xmm5, [rsp+0x50]
000075038bde3b70  vmovaps xmm6, [rsp+0x60]
000075038bde3b76  vmovaps xmm7, [rsp+0x70]
000075038bde3b7c  vmovaps xmm8, [rsp+0x80]
000075038bde3b85  vmovaps xmm9, [rsp+0x90]
000075038bde3b8e  vmovaps xmm10, [rsp+0xA0]
000075038bde3b97  vmovaps xmm11, [rsp+0xB0]
000075038bde3ba0  vmovaps xmm12, [rsp+0xC0]
000075038bde3ba9  vmovaps xmm13, [rsp+0xD0]
000075038bde3bb2  vmovaps xmm14, [rsp+0xE0]
000075038bde3bbb  add rsp, 0xF0
000075038bde3bc2  pop r11
000075038bde3bc4  pop r10
000075038bde3bc6  pop r9
000075038bde3bc8  pop r8
000075038bde3bca  pop rsi
000075038bde3bcb  pop rdi
000075038bde3bcc  pop rdx
000075038bde3bcd  pop rcx
000075038bde3bce  pop rax
000075038bde3bcf  add rsp, 0x08
000075038bde3bd3  jmp 0x000075038BDDF838
000075038bde3bd8  sub rsp, 0x08
000075038bde3bdc  push rax
000075038bde3bdd  push rcx
000075038bde3bde  push rdx
000075038bde3bdf  push rdi
000075038bde3be0  push rsi
000075038bde3be1  push r8
000075038bde3be3  push r9
000075038bde3be5  push r10
000075038bde3be7  push r11
000075038bde3be9  sub rsp, 0xF0
000075038bde3bf0  vmovaps [rsp], xmm0
000075038bde3bf5  vmovaps [rsp+0x10], xmm1
000075038bde3bfb  vmovaps [rsp+0x20], xmm2
000075038bde3c01  vmovaps [rsp+0x30], xmm3
000075038bde3c07  vmovaps [rsp+0x40], xmm4
000075038bde3c0d  vmovaps [rsp+0x50], xmm5
000075038bde3c13  vmovaps [rsp+0x60], xmm6
000075038bde3c19  vmovaps [rsp+0x70], xmm8
000075038bde3c1f  vmovaps [rsp+0x80], xmm9
000075038bde3c28  vmovaps [rsp+0x90], xmm10
000075038bde3c31  vmovaps [rsp+0xA0], xmm11
000075038bde3c3a  vmovaps [rsp+0xB0], xmm12
000075038bde3c43  vmovaps [rsp+0xC0], xmm13
000075038bde3c4c  vmovaps [rsp+0xD0], xmm14
000075038bde3c55  vmovaps [rsp+0xE0], xmm15
000075038bde3c5e  sub rsp, 0x30
000075038bde3c62  movaps [rsp], xmm7
000075038bde3c66  movaps [rsp+0x10], xmm11
000075038bde3c6c  movaps [rsp+0x20], xmm9
000075038bde3c72  lea rdi, [rsp]
000075038bde3c76  mov esi, 0x00
000075038bde3c7b  mov rax, 0x56ADB4492530
000075038bde3c85  call rax
000075038bde3c87  movaps xmm7, [rsp]
000075038bde3c8b  add rsp, 0x30
000075038bde3c8f  vmovaps xmm0, [rsp]
000075038bde3c94  vmovaps xmm1, [rsp+0x10]
000075038bde3c9a  vmovaps xmm2, [rsp+0x20]
000075038bde3ca0  vmovaps xmm3, [rsp+0x30]
000075038bde3ca6  vmovaps xmm4, [rsp+0x40]
000075038bde3cac  vmovaps xmm5, [rsp+0x50]
000075038bde3cb2  vmovaps xmm6, [rsp+0x60]
000075038bde3cb8  vmovaps xmm8, [rsp+0x70]
000075038bde3cbe  vmovaps xmm9, [rsp+0x80]
000075038bde3cc7  vmovaps xmm10, [rsp+0x90]
000075038bde3cd0  vmovaps xmm11, [rsp+0xA0]
000075038bde3cd9  vmovaps xmm12, [rsp+0xB0]
000075038bde3ce2  vmovaps xmm13, [rsp+0xC0]
000075038bde3ceb  vmovaps xmm14, [rsp+0xD0]
000075038bde3cf4  vmovaps xmm15, [rsp+0xE0]
000075038bde3cfd  add rsp, 0xF0
000075038bde3d04  pop r11
000075038bde3d06  pop r10
000075038bde3d08  pop r9
000075038bde3d0a  pop r8
000075038bde3d0c  pop rsi
000075038bde3d0d  pop rdi
000075038bde3d0e  pop rdx
000075038bde3d0f  pop rcx
000075038bde3d10  pop rax
000075038bde3d11  add rsp, 0x08
000075038bde3d15  jmp 0x000075038BDDF865
000075038bde3d1a  sub rsp, 0x08
000075038bde3d1e  push rax
000075038bde3d1f  push rcx
000075038bde3d20  push rdx
000075038bde3d21  push rdi
000075038bde3d22  push rsi
000075038bde3d23  push r8
000075038bde3d25  push r9
000075038bde3d27  push r10
000075038bde3d29  push r11
000075038bde3d2b  sub rsp, 0xF0
000075038bde3d32  vmovaps [rsp], xmm0
000075038bde3d37  vmovaps [rsp+0x10], xmm1
000075038bde3d3d  vmovaps [rsp+0x20], xmm2
000075038bde3d43  vmovaps [rsp+0x30], xmm3
000075038bde3d49  vmovaps [rsp+0x40], xmm4
000075038bde3d4f  vmovaps [rsp+0x50], xmm5
000075038bde3d55  vmovaps [rsp+0x60], xmm6
000075038bde3d5b  vmovaps [rsp+0x70], xmm7
000075038bde3d61  vmovaps [rsp+0x80], xmm8
000075038bde3d6a  vmovaps [rsp+0x90], xmm9
000075038bde3d73  vmovaps [rsp+0xA0], xmm10
000075038bde3d7c  vmovaps [rsp+0xB0], xmm12
000075038bde3d85  vmovaps [rsp+0xC0], xmm13
000075038bde3d8e  vmovaps [rsp+0xD0], xmm14
000075038bde3d97  vmovaps [rsp+0xE0], xmm15
000075038bde3da0  sub rsp, 0x30
000075038bde3da4  movaps [rsp], xmm11
000075038bde3da9  movaps [rsp+0x10], xmm10
000075038bde3daf  movaps [rsp+0x20], xmm14
000075038bde3db5  lea rdi, [rsp]
000075038bde3db9  mov esi, 0x00
000075038bde3dbe  mov rax, 0x56ADB4492530
000075038bde3dc8  call rax
000075038bde3dca  movaps xmm11, [rsp]
000075038bde3dcf  add rsp, 0x30
000075038bde3dd3  vmovaps xmm0, [rsp]
000075038bde3dd8  vmovaps xmm1, [rsp+0x10]
000075038bde3dde  vmovaps xmm2, [rsp+0x20]
000075038bde3de4  vmovaps xmm3, [rsp+0x30]
000075038bde3dea  vmovaps xmm4, [rsp+0x40]
000075038bde3df0  vmovaps xmm5, [rsp+0x50]
000075038bde3df6  vmovaps xmm6, [rsp+0x60]
000075038bde3dfc  vmovaps xmm7, [rsp+0x70]
000075038bde3e02  vmovaps xmm8, [rsp+0x80]
000075038bde3e0b  vmovaps xmm9, [rsp+0x90]
000075038bde3e14  vmovaps xmm10, [rsp+0xA0]
000075038bde3e1d  vmovaps xmm12, [rsp+0xB0]
000075038bde3e26  vmovaps xmm13, [rsp+0xC0]
000075038bde3e2f  vmovaps xmm14, [rsp+0xD0]
000075038bde3e38  vmovaps xmm15, [rsp+0xE0]
000075038bde3e41  add rsp, 0xF0
000075038bde3e48  pop r11
000075038bde3e4a  pop r10
000075038bde3e4c  pop r9
000075038bde3e4e  pop r8
000075038bde3e50  pop rsi
000075038bde3e51  pop rdi
000075038bde3e52  pop rdx
000075038bde3e53  pop rcx
000075038bde3e54  pop rax
000075038bde3e55  add rsp, 0x08
000075038bde3e59  jmp 0x000075038BDDF880
000075038bde3e5e  call 0x000075038BCC33A0
000075038bde3e63  jmp 0x000075038BDDF88A
000075038bde3e68  sub rsp, 0x08
000075038bde3e6c  push rax
000075038bde3e6d  push rcx
000075038bde3e6e  push rdx
000075038bde3e6f  push rdi
000075038bde3e70  push rsi
000075038bde3e71  push r8
000075038bde3e73  push r9
000075038bde3e75  push r10
000075038bde3e77  push r11
000075038bde3e79  sub rsp, 0xF0
000075038bde3e80  vmovaps [rsp], xmm0
000075038bde3e85  vmovaps [rsp+0x10], xmm1
000075038bde3e8b  vmovaps [rsp+0x20], xmm2
000075038bde3e91  vmovaps [rsp+0x30], xmm3
000075038bde3e97  vmovaps [rsp+0x40], xmm4
000075038bde3e9d  vmovaps [rsp+0x50], xmm5
000075038bde3ea3  vmovaps [rsp+0x60], xmm6
000075038bde3ea9  vmovaps [rsp+0x70], xmm7
000075038bde3eaf  vmovaps [rsp+0x80], xmm8
000075038bde3eb8  vmovaps [rsp+0x90], xmm9
000075038bde3ec1  vmovaps [rsp+0xA0], xmm11
000075038bde3eca  vmovaps [rsp+0xB0], xmm12
000075038bde3ed3  vmovaps [rsp+0xC0], xmm13
000075038bde3edc  vmovaps [rsp+0xD0], xmm14
000075038bde3ee5  vmovaps [rsp+0xE0], xmm15
000075038bde3eee  sub rsp, 0x30
000075038bde3ef2  movaps [rsp], xmm10
000075038bde3ef7  movaps [rsp+0x10], xmm1
000075038bde3efc  movaps [rsp+0x20], xmm12
000075038bde3f02  lea rdi, [rsp]
000075038bde3f06  mov esi, 0x00
000075038bde3f0b  mov rax, 0x56ADB4492530
000075038bde3f15  call rax
000075038bde3f17  movaps xmm10, [rsp]
000075038bde3f1c  add rsp, 0x30
000075038bde3f20  vmovaps xmm0, [rsp]
000075038bde3f25  vmovaps xmm1, [rsp+0x10]
000075038bde3f2b  vmovaps xmm2, [rsp+0x20]
000075038bde3f31  vmovaps xmm3, [rsp+0x30]
000075038bde3f37  vmovaps xmm4, [rsp+0x40]
000075038bde3f3d  vmovaps xmm5, [rsp+0x50]
000075038bde3f43  vmovaps xmm6, [rsp+0x60]
000075038bde3f49  vmovaps xmm7, [rsp+0x70]
000075038bde3f4f  vmovaps xmm8, [rsp+0x80]
000075038bde3f58  vmovaps xmm9, [rsp+0x90]
000075038bde3f61  vmovaps xmm11, [rsp+0xA0]
000075038bde3f6a  vmovaps xmm12, [rsp+0xB0]
000075038bde3f73  vmovaps xmm13, [rsp+0xC0]
000075038bde3f7c  vmovaps xmm14, [rsp+0xD0]
000075038bde3f85  vmovaps xmm15, [rsp+0xE0]
000075038bde3f8e  add rsp, 0xF0
000075038bde3f95  pop r11
000075038bde3f97  pop r10
000075038bde3f99  pop r9
000075038bde3f9b  pop r8
000075038bde3f9d  pop rsi
000075038bde3f9e  pop rdi
000075038bde3f9f  pop rdx
000075038bde3fa0  pop rcx
000075038bde3fa1  pop rax
000075038bde3fa2  add rsp, 0x08
000075038bde3fa6  jmp 0x000075038BDDF8AD
000075038bde3fab  sub rsp, 0x08
000075038bde3faf  push rax
000075038bde3fb0  push rcx
000075038bde3fb1  push rdx
000075038bde3fb2  push rdi
000075038bde3fb3  push rsi
000075038bde3fb4  push r8
000075038bde3fb6  push r9
000075038bde3fb8  push r10
000075038bde3fba  push r11
000075038bde3fbc  sub rsp, 0xF0
000075038bde3fc3  vmovaps [rsp], xmm0
000075038bde3fc8  vmovaps [rsp+0x10], xmm1
000075038bde3fce  vmovaps [rsp+0x20], xmm2
000075038bde3fd4  vmovaps [rsp+0x30], xmm3
000075038bde3fda  vmovaps [rsp+0x40], xmm4
000075038bde3fe0  vmovaps [rsp+0x50], xmm5
000075038bde3fe6  vmovaps [rsp+0x60], xmm6
000075038bde3fec  vmovaps [rsp+0x70], xmm7
000075038bde3ff2  vmovaps [rsp+0x80], xmm8
000075038bde3ffb  vmovaps [rsp+0x90], xmm9
000075038bde4004  vmovaps [rsp+0xA0], xmm10
000075038bde400d  vmovaps [rsp+0xB0], xmm11
000075038bde4016  vmovaps [rsp+0xC0], xmm13
000075038bde401f  vmovaps [rsp+0xD0], xmm14
000075038bde4028  vmovaps [rsp+0xE0], xmm15
000075038bde4031  sub rsp, 0x30
000075038bde4035  movaps [rsp], xmm12
000075038bde403a  movaps [rsp+0x10], xmm14
000075038bde4040  movaps [rsp+0x20], xmm1
000075038bde4045  lea rdi, [rsp]
000075038bde4049  mov esi, 0x00
000075038bde404e  mov rax, 0x56ADB4492530
000075038bde4058  call rax
000075038bde405a  movaps xmm12, [rsp]
000075038bde405f  add rsp, 0x30
000075038bde4063  vmovaps xmm0, [rsp]
000075038bde4068  vmovaps xmm1, [rsp+0x10]
000075038bde406e  vmovaps xmm2, [rsp+0x20]
000075038bde4074  vmovaps xmm3, [rsp+0x30]
000075038bde407a  vmovaps xmm4, [rsp+0x40]
000075038bde4080  vmovaps xmm5, [rsp+0x50]
000075038bde4086  vmovaps xmm6, [rsp+0x60]
000075038bde408c  vmovaps xmm7, [rsp+0x70]
000075038bde4092  vmovaps xmm8, [rsp+0x80]
000075038bde409b  vmovaps xmm9, [rsp+0x90]
000075038bde40a4  vmovaps xmm10, [rsp+0xA0]
000075038bde40ad  vmovaps xmm11, [rsp+0xB0]
000075038bde40b6  vmovaps xmm13, [rsp+0xC0]
000075038bde40bf  vmovaps xmm14, [rsp+0xD0]
000075038bde40c8  vmovaps xmm15, [rsp+0xE0]
000075038bde40d1  add rsp, 0xF0
000075038bde40d8  pop r11
000075038bde40da  pop r10
000075038bde40dc  pop r9
000075038bde40de  pop r8
000075038bde40e0  pop rsi
000075038bde40e1  pop rdi
000075038bde40e2  pop rdx
000075038bde40e3  pop rcx
000075038bde40e4  pop rax
000075038bde40e5  add rsp, 0x08
000075038bde40e9  jmp 0x000075038BDDF8DC
000075038bde40ee  sub rsp, 0x08
000075038bde40f2  push rax
000075038bde40f3  push rcx
000075038bde40f4  push rdx
000075038bde40f5  push rdi
000075038bde40f6  push rsi
000075038bde40f7  push r8
000075038bde40f9  push r9
000075038bde40fb  push r10
000075038bde40fd  push r11
000075038bde40ff  sub rsp, 0xF0
000075038bde4106  vmovaps [rsp], xmm0
000075038bde410b  vmovaps [rsp+0x10], xmm1
000075038bde4111  vmovaps [rsp+0x20], xmm2
000075038bde4117  vmovaps [rsp+0x30], xmm3
000075038bde411d  vmovaps [rsp+0x40], xmm4
000075038bde4123  vmovaps [rsp+0x50], xmm5
000075038bde4129  vmovaps [rsp+0x60], xmm6
000075038bde412f  vmovaps [rsp+0x70], xmm7
000075038bde4135  vmovaps [rsp+0x80], xmm8
000075038bde413e  vmovaps [rsp+0x90], xmm9
000075038bde4147  vmovaps [rsp+0xA0], xmm10
000075038bde4150  vmovaps [rsp+0xB0], xmm11
000075038bde4159  vmovaps [rsp+0xC0], xmm12
000075038bde4162  vmovaps [rsp+0xD0], xmm13
000075038bde416b  vmovaps [rsp+0xE0], xmm15
000075038bde4174  sub rsp, 0x30
000075038bde4178  movaps [rsp], xmm14
000075038bde417d  movaps [rsp+0x10], xmm9
000075038bde4183  movaps [rsp+0x20], xmm1
000075038bde4188  lea rdi, [rsp]
000075038bde418c  mov esi, 0x00
000075038bde4191  mov rax, 0x56ADB4492530
000075038bde419b  call rax
000075038bde419d  movaps xmm14, [rsp]
000075038bde41a2  add rsp, 0x30
000075038bde41a6  vmovaps xmm0, [rsp]
000075038bde41ab  vmovaps xmm1, [rsp+0x10]
000075038bde41b1  vmovaps xmm2, [rsp+0x20]
000075038bde41b7  vmovaps xmm3, [rsp+0x30]
000075038bde41bd  vmovaps xmm4, [rsp+0x40]
000075038bde41c3  vmovaps xmm5, [rsp+0x50]
000075038bde41c9  vmovaps xmm6, [rsp+0x60]
000075038bde41cf  vmovaps xmm7, [rsp+0x70]
000075038bde41d5  vmovaps xmm8, [rsp+0x80]
000075038bde41de  vmovaps xmm9, [rsp+0x90]
000075038bde41e7  vmovaps xmm10, [rsp+0xA0]
000075038bde41f0  vmovaps xmm11, [rsp+0xB0]
000075038bde41f9  vmovaps xmm12, [rsp+0xC0]
000075038bde4202  vmovaps xmm13, [rsp+0xD0]
000075038bde420b  vmovaps xmm15, [rsp+0xE0]
000075038bde4214  add rsp, 0xF0
000075038bde421b  pop r11
000075038bde421d  pop r10
000075038bde421f  pop r9
000075038bde4221  pop r8
000075038bde4223  pop rsi
000075038bde4224  pop rdi
000075038bde4225  pop rdx
000075038bde4226  pop rcx
000075038bde4227  pop rax
000075038bde4228  add rsp, 0x08
000075038bde422c  jmp 0x000075038BDDF90B
000075038bde4231  sub rsp, 0x08
000075038bde4235  push rax
000075038bde4236  push rcx
000075038bde4237  push rdx
000075038bde4238  push rdi
000075038bde4239  push rsi
000075038bde423a  push r8
000075038bde423c  push r9
000075038bde423e  push r10
000075038bde4240  push r11
000075038bde4242  sub rsp, 0xF0
000075038bde4249  vmovaps [rsp], xmm0
000075038bde424e  vmovaps [rsp+0x10], xmm2
000075038bde4254  vmovaps [rsp+0x20], xmm3
000075038bde425a  vmovaps [rsp+0x30], xmm4
000075038bde4260  vmovaps [rsp+0x40], xmm5
000075038bde4266  vmovaps [rsp+0x50], xmm6
000075038bde426c  vmovaps [rsp+0x60], xmm7
000075038bde4272  vmovaps [rsp+0x70], xmm8
000075038bde4278  vmovaps [rsp+0x80], xmm9
000075038bde4281  vmovaps [rsp+0x90], xmm10
000075038bde428a  vmovaps [rsp+0xA0], xmm11
000075038bde4293  vmovaps [rsp+0xB0], xmm12
000075038bde429c  vmovaps [rsp+0xC0], xmm13
000075038bde42a5  vmovaps [rsp+0xD0], xmm14
000075038bde42ae  vmovaps [rsp+0xE0], xmm15
000075038bde42b7  sub rsp, 0x30
000075038bde42bb  movaps [rsp], xmm1
000075038bde42bf  movaps [rsp+0x10], xmm13
000075038bde42c5  movaps [rsp+0x20], xmm8
000075038bde42cb  lea rdi, [rsp]
000075038bde42cf  mov esi, 0x00
000075038bde42d4  mov rax, 0x56ADB4492530
000075038bde42de  call rax
000075038bde42e0  movaps xmm1, [rsp]
000075038bde42e4  add rsp, 0x30
000075038bde42e8  vmovaps xmm0, [rsp]
000075038bde42ed  vmovaps xmm2, [rsp+0x10]
000075038bde42f3  vmovaps xmm3, [rsp+0x20]
000075038bde42f9  vmovaps xmm4, [rsp+0x30]
000075038bde42ff  vmovaps xmm5, [rsp+0x40]
000075038bde4305  vmovaps xmm6, [rsp+0x50]
000075038bde430b  vmovaps xmm7, [rsp+0x60]
000075038bde4311  vmovaps xmm8, [rsp+0x70]
000075038bde4317  vmovaps xmm9, [rsp+0x80]
000075038bde4320  vmovaps xmm10, [rsp+0x90]
000075038bde4329  vmovaps xmm11, [rsp+0xA0]
000075038bde4332  vmovaps xmm12, [rsp+0xB0]
000075038bde433b  vmovaps xmm13, [rsp+0xC0]
000075038bde4344  vmovaps xmm14, [rsp+0xD0]
000075038bde434d  vmovaps xmm15, [rsp+0xE0]
000075038bde4356  add rsp, 0xF0
000075038bde435d  pop r11
000075038bde435f  pop r10
000075038bde4361  pop r9
000075038bde4363  pop r8
000075038bde4365  pop rsi
000075038bde4366  pop rdi
000075038bde4367  pop rdx
000075038bde4368  pop rcx
000075038bde4369  pop rax
000075038bde436a  add rsp, 0x08
000075038bde436e  jmp 0x000075038BDDF92D
000075038bde4373  call 0x000075038BC0C260
000075038bde4378  jmp 0x000075038BDDF93B
000075038bde437d  call 0x000075038BCBD750
000075038bde4382  jmp 0x000075038BDDF945
000075038bde4387  sub rsp, 0x08
000075038bde438b  push rax
000075038bde438c  push rcx
000075038bde438d  push rdx
000075038bde438e  push rdi
000075038bde438f  push rsi
000075038bde4390  push r8
000075038bde4392  push r9
000075038bde4394  push r10
000075038bde4396  push r11
000075038bde4398  sub rsp, 0xF0
000075038bde439f  vmovaps [rsp], xmm0
000075038bde43a4  vmovaps [rsp+0x10], xmm1
000075038bde43aa  vmovaps [rsp+0x20], xmm2
000075038bde43b0  vmovaps [rsp+0x30], xmm3
000075038bde43b6  vmovaps [rsp+0x40], xmm4
000075038bde43bc  vmovaps [rsp+0x50], xmm5
000075038bde43c2  vmovaps [rsp+0x60], xmm6
000075038bde43c8  vmovaps [rsp+0x70], xmm7
000075038bde43ce  vmovaps [rsp+0x80], xmm9
000075038bde43d7  vmovaps [rsp+0x90], xmm10
000075038bde43e0  vmovaps [rsp+0xA0], xmm11
000075038bde43e9  vmovaps [rsp+0xB0], xmm12
000075038bde43f2  vmovaps [rsp+0xC0], xmm13
000075038bde43fb  vmovaps [rsp+0xD0], xmm14
000075038bde4404  vmovaps [rsp+0xE0], xmm15
000075038bde440d  sub rsp, 0x30
000075038bde4411  movaps [rsp], xmm8
000075038bde4416  movaps [rsp+0x10], xmm15
000075038bde441c  movaps [rsp+0x20], xmm7
000075038bde4421  lea rdi, [rsp]
000075038bde4425  mov esi, 0x00
000075038bde442a  mov rax, 0x56ADB4492530
000075038bde4434  call rax
000075038bde4436  movaps xmm8, [rsp]
000075038bde443b  add rsp, 0x30
000075038bde443f  vmovaps xmm0, [rsp]
000075038bde4444  vmovaps xmm1, [rsp+0x10]
000075038bde444a  vmovaps xmm2, [rsp+0x20]
000075038bde4450  vmovaps xmm3, [rsp+0x30]
000075038bde4456  vmovaps xmm4, [rsp+0x40]
000075038bde445c  vmovaps xmm5, [rsp+0x50]
000075038bde4462  vmovaps xmm6, [rsp+0x60]
000075038bde4468  vmovaps xmm7, [rsp+0x70]
000075038bde446e  vmovaps xmm9, [rsp+0x80]
000075038bde4477  vmovaps xmm10, [rsp+0x90]
000075038bde4480  vmovaps xmm11, [rsp+0xA0]
000075038bde4489  vmovaps xmm12, [rsp+0xB0]
000075038bde4492  vmovaps xmm13, [rsp+0xC0]
000075038bde449b  vmovaps xmm14, [rsp+0xD0]
000075038bde44a4  vmovaps xmm15, [rsp+0xE0]
000075038bde44ad  add rsp, 0xF0
000075038bde44b4  pop r11
000075038bde44b6  pop r10
000075038bde44b8  pop r9
000075038bde44ba  pop r8
000075038bde44bc  pop rsi
000075038bde44bd  pop rdi
000075038bde44be  pop rdx
000075038bde44bf  pop rcx
000075038bde44c0  pop rax
000075038bde44c1  add rsp, 0x08
000075038bde44c5  jmp 0x000075038BDDF967
000075038bde44ca  sub rsp, 0x08
000075038bde44ce  push rax
000075038bde44cf  push rcx
000075038bde44d0  push rdx
000075038bde44d1  push rdi
000075038bde44d2  push rsi
000075038bde44d3  push r8
000075038bde44d5  push r9
000075038bde44d7  push r10
000075038bde44d9  push r11
000075038bde44db  sub rsp, 0xF0
000075038bde44e2  vmovaps [rsp], xmm0
000075038bde44e7  vmovaps [rsp+0x10], xmm1
000075038bde44ed  vmovaps [rsp+0x20], xmm2
000075038bde44f3  vmovaps [rsp+0x30], xmm3
000075038bde44f9  vmovaps [rsp+0x40], xmm4
000075038bde44ff  vmovaps [rsp+0x50], xmm5
000075038bde4505  vmovaps [rsp+0x60], xmm6
000075038bde450b  vmovaps [rsp+0x70], xmm8
000075038bde4511  vmovaps [rsp+0x80], xmm9
000075038bde451a  vmovaps [rsp+0x90], xmm10
000075038bde4523  vmovaps [rsp+0xA0], xmm11
000075038bde452c  vmovaps [rsp+0xB0], xmm12
000075038bde4535  vmovaps [rsp+0xC0], xmm13
000075038bde453e  vmovaps [rsp+0xD0], xmm14
000075038bde4547  vmovaps [rsp+0xE0], xmm15
000075038bde4550  sub rsp, 0x30
000075038bde4554  movaps [rsp], xmm7
000075038bde4558  movaps [rsp+0x10], xmm9
000075038bde455e  movaps [rsp+0x20], xmm15
000075038bde4564  lea rdi, [rsp]
000075038bde4568  mov esi, 0x00
000075038bde456d  mov rax, 0x56ADB4492530
000075038bde4577  call rax
000075038bde4579  movaps xmm7, [rsp]
000075038bde457d  add rsp, 0x30
000075038bde4581  vmovaps xmm0, [rsp]
000075038bde4586  vmovaps xmm1, [rsp+0x10]
000075038bde458c  vmovaps xmm2, [rsp+0x20]
000075038bde4592  vmovaps xmm3, [rsp+0x30]
000075038bde4598  vmovaps xmm4, [rsp+0x40]
000075038bde459e  vmovaps xmm5, [rsp+0x50]
000075038bde45a4  vmovaps xmm6, [rsp+0x60]
000075038bde45aa  vmovaps xmm8, [rsp+0x70]
000075038bde45b0  vmovaps xmm9, [rsp+0x80]
000075038bde45b9  vmovaps xmm10, [rsp+0x90]
000075038bde45c2  vmovaps xmm11, [rsp+0xA0]
000075038bde45cb  vmovaps xmm12, [rsp+0xB0]
000075038bde45d4  vmovaps xmm13, [rsp+0xC0]
000075038bde45dd  vmovaps xmm14, [rsp+0xD0]
000075038bde45e6  vmovaps xmm15, [rsp+0xE0]
000075038bde45ef  add rsp, 0xF0
000075038bde45f6  pop r11
000075038bde45f8  pop r10
000075038bde45fa  pop r9
000075038bde45fc  pop r8
000075038bde45fe  pop rsi
000075038bde45ff  pop rdi
000075038bde4600  pop rdx
000075038bde4601  pop rcx
000075038bde4602  pop rax
000075038bde4603  add rsp, 0x08
000075038bde4607  jmp 0x000075038BDDF994
000075038bde460c  sub rsp, 0x08
000075038bde4610  push rax
000075038bde4611  push rcx
000075038bde4612  push rdx
000075038bde4613  push rdi
000075038bde4614  push rsi
000075038bde4615  push r8
000075038bde4617  push r9
000075038bde4619  push r10
000075038bde461b  push r11
000075038bde461d  sub rsp, 0xF0
000075038bde4624  vmovaps [rsp], xmm0
000075038bde4629  vmovaps [rsp+0x10], xmm1
000075038bde462f  vmovaps [rsp+0x20], xmm2
000075038bde4635  vmovaps [rsp+0x30], xmm3
000075038bde463b  vmovaps [rsp+0x40], xmm4
000075038bde4641  vmovaps [rsp+0x50], xmm5
000075038bde4647  vmovaps [rsp+0x60], xmm6
000075038bde464d  vmovaps [rsp+0x70], xmm7
000075038bde4653  vmovaps [rsp+0x80], xmm8
000075038bde465c  vmovaps [rsp+0x90], xmm10
000075038bde4665  vmovaps [rsp+0xA0], xmm11
000075038bde466e  vmovaps [rsp+0xB0], xmm12
000075038bde4677  vmovaps [rsp+0xC0], xmm13
000075038bde4680  vmovaps [rsp+0xD0], xmm14
000075038bde4689  vmovaps [rsp+0xE0], xmm15
000075038bde4692  sub rsp, 0x30
000075038bde4696  movaps [rsp], xmm9
000075038bde469b  movaps [rsp+0x10], xmm13
000075038bde46a1  movaps [rsp+0x20], xmm15
000075038bde46a7  lea rdi, [rsp]
000075038bde46ab  mov esi, 0x00
000075038bde46b0  mov rax, 0x56ADB4492530
000075038bde46ba  call rax
000075038bde46bc  movaps xmm9, [rsp]
000075038bde46c1  add rsp, 0x30
000075038bde46c5  vmovaps xmm0, [rsp]
000075038bde46ca  vmovaps xmm1, [rsp+0x10]
000075038bde46d0  vmovaps xmm2, [rsp+0x20]
000075038bde46d6  vmovaps xmm3, [rsp+0x30]
000075038bde46dc  vmovaps xmm4, [rsp+0x40]
000075038bde46e2  vmovaps xmm5, [rsp+0x50]
000075038bde46e8  vmovaps xmm6, [rsp+0x60]
000075038bde46ee  vmovaps xmm7, [rsp+0x70]
000075038bde46f4  vmovaps xmm8, [rsp+0x80]
000075038bde46fd  vmovaps xmm10, [rsp+0x90]
000075038bde4706  vmovaps xmm11, [rsp+0xA0]
000075038bde470f  vmovaps xmm12, [rsp+0xB0]
000075038bde4718  vmovaps xmm13, [rsp+0xC0]
000075038bde4721  vmovaps xmm14, [rsp+0xD0]
000075038bde472a  vmovaps xmm15, [rsp+0xE0]
000075038bde4733  add rsp, 0xF0
000075038bde473a  pop r11
000075038bde473c  pop r10
000075038bde473e  pop r9
000075038bde4740  pop r8
000075038bde4742  pop rsi
000075038bde4743  pop rdi
000075038bde4744  pop rdx
000075038bde4745  pop rcx
000075038bde4746  pop rax
000075038bde4747  add rsp, 0x08
000075038bde474b  jmp 0x000075038BDDF9C2
000075038bde4750  sub rsp, 0x08
000075038bde4754  push rax
000075038bde4755  push rcx
000075038bde4756  push rdx
000075038bde4757  push rdi
000075038bde4758  push rsi
000075038bde4759  push r8
000075038bde475b  push r9
000075038bde475d  push r10
000075038bde475f  push r11
000075038bde4761  sub rsp, 0xF0
000075038bde4768  vmovaps [rsp], xmm0
000075038bde476d  vmovaps [rsp+0x10], xmm1
000075038bde4773  vmovaps [rsp+0x20], xmm2
000075038bde4779  vmovaps [rsp+0x30], xmm3
000075038bde477f  vmovaps [rsp+0x40], xmm4
000075038bde4785  vmovaps [rsp+0x50], xmm5
000075038bde478b  vmovaps [rsp+0x60], xmm6
000075038bde4791  vmovaps [rsp+0x70], xmm7
000075038bde4797  vmovaps [rsp+0x80], xmm8
000075038bde47a0  vmovaps [rsp+0x90], xmm9
000075038bde47a9  vmovaps [rsp+0xA0], xmm10
000075038bde47b2  vmovaps [rsp+0xB0], xmm11
000075038bde47bb  vmovaps [rsp+0xC0], xmm12
000075038bde47c4  vmovaps [rsp+0xD0], xmm13
000075038bde47cd  vmovaps [rsp+0xE0], xmm14
000075038bde47d6  sub rsp, 0x30
000075038bde47da  movaps [rsp], xmm15
000075038bde47df  movaps [rsp+0x10], xmm11
000075038bde47e5  movaps [rsp+0x20], xmm12
000075038bde47eb  lea rdi, [rsp]
000075038bde47ef  mov esi, 0x00
000075038bde47f4  mov rax, 0x56ADB4492530
000075038bde47fe  call rax
000075038bde4800  movaps xmm15, [rsp]
000075038bde4805  add rsp, 0x30
000075038bde4809  vmovaps xmm0, [rsp]
000075038bde480e  vmovaps xmm1, [rsp+0x10]
000075038bde4814  vmovaps xmm2, [rsp+0x20]
000075038bde481a  vmovaps xmm3, [rsp+0x30]
000075038bde4820  vmovaps xmm4, [rsp+0x40]
000075038bde4826  vmovaps xmm5, [rsp+0x50]
000075038bde482c  vmovaps xmm6, [rsp+0x60]
000075038bde4832  vmovaps xmm7, [rsp+0x70]
000075038bde4838  vmovaps xmm8, [rsp+0x80]
000075038bde4841  vmovaps xmm9, [rsp+0x90]
000075038bde484a  vmovaps xmm10, [rsp+0xA0]
000075038bde4853  vmovaps xmm11, [rsp+0xB0]
000075038bde485c  vmovaps xmm12, [rsp+0xC0]
000075038bde4865  vmovaps xmm13, [rsp+0xD0]
000075038bde486e  vmovaps xmm14, [rsp+0xE0]
000075038bde4877  add rsp, 0xF0
000075038bde487e  pop r11
000075038bde4880  pop r10
000075038bde4882  pop r9
000075038bde4884  pop r8
000075038bde4886  pop rsi
000075038bde4887  pop rdi
000075038bde4888  pop rdx
000075038bde4889  pop rcx
000075038bde488a  pop rax
000075038bde488b  add rsp, 0x08
000075038bde488f  jmp 0x000075038BDDF9DD
000075038bde4894  sub rsp, 0x08
000075038bde4898  push rax
000075038bde4899  push rcx
000075038bde489a  push rdx
000075038bde489b  push rdi
000075038bde489c  push rsi
000075038bde489d  push r8
000075038bde489f  push r9
000075038bde48a1  push r10
000075038bde48a3  push r11
000075038bde48a5  sub rsp, 0xF0
000075038bde48ac  vmovaps [rsp], xmm0
000075038bde48b1  vmovaps [rsp+0x10], xmm1
000075038bde48b7  vmovaps [rsp+0x20], xmm2
000075038bde48bd  vmovaps [rsp+0x30], xmm3
000075038bde48c3  vmovaps [rsp+0x40], xmm4
000075038bde48c9  vmovaps [rsp+0x50], xmm5
000075038bde48cf  vmovaps [rsp+0x60], xmm6
000075038bde48d5  vmovaps [rsp+0x70], xmm7
000075038bde48db  vmovaps [rsp+0x80], xmm8
000075038bde48e4  vmovaps [rsp+0x90], xmm9
000075038bde48ed  vmovaps [rsp+0xA0], xmm10
000075038bde48f6  vmovaps [rsp+0xB0], xmm11
000075038bde48ff  vmovaps [rsp+0xC0], xmm12
000075038bde4908  vmovaps [rsp+0xD0], xmm14
000075038bde4911  vmovaps [rsp+0xE0], xmm15
000075038bde491a  sub rsp, 0x30
000075038bde491e  movaps [rsp], xmm13
000075038bde4923  movaps [rsp+0x10], xmm10
000075038bde4929  movaps [rsp+0x20], xmm14
000075038bde492f  lea rdi, [rsp]
000075038bde4933  mov esi, 0x00
000075038bde4938  mov rax, 0x56ADB4492530
000075038bde4942  call rax
000075038bde4944  movaps xmm13, [rsp]
000075038bde4949  add rsp, 0x30
000075038bde494d  vmovaps xmm0, [rsp]
000075038bde4952  vmovaps xmm1, [rsp+0x10]
000075038bde4958  vmovaps xmm2, [rsp+0x20]
000075038bde495e  vmovaps xmm3, [rsp+0x30]
000075038bde4964  vmovaps xmm4, [rsp+0x40]
000075038bde496a  vmovaps xmm5, [rsp+0x50]
000075038bde4970  vmovaps xmm6, [rsp+0x60]
000075038bde4976  vmovaps xmm7, [rsp+0x70]
000075038bde497c  vmovaps xmm8, [rsp+0x80]
000075038bde4985  vmovaps xmm9, [rsp+0x90]
000075038bde498e  vmovaps xmm10, [rsp+0xA0]
000075038bde4997  vmovaps xmm11, [rsp+0xB0]
000075038bde49a0  vmovaps xmm12, [rsp+0xC0]
000075038bde49a9  vmovaps xmm14, [rsp+0xD0]
000075038bde49b2  vmovaps xmm15, [rsp+0xE0]
000075038bde49bb  add rsp, 0xF0
000075038bde49c2  pop r11
000075038bde49c4  pop r10
000075038bde49c6  pop r9
000075038bde49c8  pop r8
000075038bde49ca  pop rsi
000075038bde49cb  pop rdi
000075038bde49cc  pop rdx
000075038bde49cd  pop rcx
000075038bde49ce  pop rax
000075038bde49cf  add rsp, 0x08
000075038bde49d3  jmp 0x000075038BDDFA00
000075038bde49d8  sub rsp, 0x08
000075038bde49dc  push rax
000075038bde49dd  push rcx
000075038bde49de  push rdx
000075038bde49df  push rdi
000075038bde49e0  push rsi
000075038bde49e1  push r8
000075038bde49e3  push r9
000075038bde49e5  push r10
000075038bde49e7  push r11
000075038bde49e9  sub rsp, 0xF0
000075038bde49f0  vmovaps [rsp], xmm0
000075038bde49f5  vmovaps [rsp+0x10], xmm1
000075038bde49fb  vmovaps [rsp+0x20], xmm2
000075038bde4a01  vmovaps [rsp+0x30], xmm3
000075038bde4a07  vmovaps [rsp+0x40], xmm4
000075038bde4a0d  vmovaps [rsp+0x50], xmm5
000075038bde4a13  vmovaps [rsp+0x60], xmm6
000075038bde4a19  vmovaps [rsp+0x70], xmm7
000075038bde4a1f  vmovaps [rsp+0x80], xmm8
000075038bde4a28  vmovaps [rsp+0x90], xmm9
000075038bde4a31  vmovaps [rsp+0xA0], xmm10
000075038bde4a3a  vmovaps [rsp+0xB0], xmm11
000075038bde4a43  vmovaps [rsp+0xC0], xmm12
000075038bde4a4c  vmovaps [rsp+0xD0], xmm13
000075038bde4a55  vmovaps [rsp+0xE0], xmm15
000075038bde4a5e  sub rsp, 0x30
000075038bde4a62  movaps [rsp], xmm14
000075038bde4a67  movaps [rsp+0x10], xmm1
000075038bde4a6c  movaps [rsp+0x20], xmm7
000075038bde4a71  lea rdi, [rsp]
000075038bde4a75  mov esi, 0x00
000075038bde4a7a  mov rax, 0x56ADB4492530
000075038bde4a84  call rax
000075038bde4a86  movaps xmm14, [rsp]
000075038bde4a8b  add rsp, 0x30
000075038bde4a8f  vmovaps xmm0, [rsp]
000075038bde4a94  vmovaps xmm1, [rsp+0x10]
000075038bde4a9a  vmovaps xmm2, [rsp+0x20]
000075038bde4aa0  vmovaps xmm3, [rsp+0x30]
000075038bde4aa6  vmovaps xmm4, [rsp+0x40]
000075038bde4aac  vmovaps xmm5, [rsp+0x50]
000075038bde4ab2  vmovaps xmm6, [rsp+0x60]
000075038bde4ab8  vmovaps xmm7, [rsp+0x70]
000075038bde4abe  vmovaps xmm8, [rsp+0x80]
000075038bde4ac7  vmovaps xmm9, [rsp+0x90]
000075038bde4ad0  vmovaps xmm10, [rsp+0xA0]
000075038bde4ad9  vmovaps xmm11, [rsp+0xB0]
000075038bde4ae2  vmovaps xmm12, [rsp+0xC0]
000075038bde4aeb  vmovaps xmm13, [rsp+0xD0]
000075038bde4af4  vmovaps xmm15, [rsp+0xE0]
000075038bde4afd  add rsp, 0xF0
000075038bde4b04  pop r11
000075038bde4b06  pop r10
000075038bde4b08  pop r9
000075038bde4b0a  pop r8
000075038bde4b0c  pop rsi
000075038bde4b0d  pop rdi
000075038bde4b0e  pop rdx
000075038bde4b0f  pop rcx
000075038bde4b10  pop rax
000075038bde4b11  add rsp, 0x08
000075038bde4b15  jmp 0x000075038BDDFA23
000075038bde4b1a  sub rsp, 0x08
000075038bde4b1e  push rax
000075038bde4b1f  push rcx
000075038bde4b20  push rdx
000075038bde4b21  push rdi
000075038bde4b22  push rsi
000075038bde4b23  push r8
000075038bde4b25  push r9
000075038bde4b27  push r10
000075038bde4b29  push r11
000075038bde4b2b  sub rsp, 0xF0
000075038bde4b32  vmovaps [rsp], xmm0
000075038bde4b37  vmovaps [rsp+0x10], xmm2
000075038bde4b3d  vmovaps [rsp+0x20], xmm3
000075038bde4b43  vmovaps [rsp+0x30], xmm4
000075038bde4b49  vmovaps [rsp+0x40], xmm5
000075038bde4b4f  vmovaps [rsp+0x50], xmm6
000075038bde4b55  vmovaps [rsp+0x60], xmm7
000075038bde4b5b  vmovaps [rsp+0x70], xmm8
000075038bde4b61  vmovaps [rsp+0x80], xmm9
000075038bde4b6a  vmovaps [rsp+0x90], xmm10
000075038bde4b73  vmovaps [rsp+0xA0], xmm11
000075038bde4b7c  vmovaps [rsp+0xB0], xmm12
000075038bde4b85  vmovaps [rsp+0xC0], xmm13
000075038bde4b8e  vmovaps [rsp+0xD0], xmm14
000075038bde4b97  vmovaps [rsp+0xE0], xmm15
000075038bde4ba0  sub rsp, 0x30
000075038bde4ba4  movaps [rsp], xmm1
000075038bde4ba8  movaps [rsp+0x10], xmm8
000075038bde4bae  movaps [rsp+0x20], xmm9
000075038bde4bb4  lea rdi, [rsp]
000075038bde4bb8  mov esi, 0x00
000075038bde4bbd  mov rax, 0x56ADB4492530
000075038bde4bc7  call rax
000075038bde4bc9  movaps xmm1, [rsp]
000075038bde4bcd  add rsp, 0x30
000075038bde4bd1  vmovaps xmm0, [rsp]
000075038bde4bd6  vmovaps xmm2, [rsp+0x10]
000075038bde4bdc  vmovaps xmm3, [rsp+0x20]
000075038bde4be2  vmovaps xmm4, [rsp+0x30]
000075038bde4be8  vmovaps xmm5, [rsp+0x40]
000075038bde4bee  vmovaps xmm6, [rsp+0x50]
000075038bde4bf4  vmovaps xmm7, [rsp+0x60]
000075038bde4bfa  vmovaps xmm8, [rsp+0x70]
000075038bde4c00  vmovaps xmm9, [rsp+0x80]
000075038bde4c09  vmovaps xmm10, [rsp+0x90]
000075038bde4c12  vmovaps xmm11, [rsp+0xA0]
000075038bde4c1b  vmovaps xmm12, [rsp+0xB0]
000075038bde4c24  vmovaps xmm13, [rsp+0xC0]
000075038bde4c2d  vmovaps xmm14, [rsp+0xD0]
000075038bde4c36  vmovaps xmm15, [rsp+0xE0]
000075038bde4c3f  add rsp, 0xF0
000075038bde4c46  pop r11
000075038bde4c48  pop r10
000075038bde4c4a  pop r9
000075038bde4c4c  pop r8
000075038bde4c4e  pop rsi
000075038bde4c4f  pop rdi
000075038bde4c50  pop rdx
000075038bde4c51  pop rcx
000075038bde4c52  pop rax
000075038bde4c53  add rsp, 0x08
000075038bde4c57  jmp 0x000075038BDDFA45
000075038bde4c5c  call 0x000075038BCE5940
000075038bde4c61  jmp 0x000075038BDDFA53
000075038bde4c66  call 0x000075038BC0C380
000075038bde4c6b  jmp 0x000075038BDDFA5D
000075038bde4c70  call 0x000075038BC0D600
000075038bde4c75  jmp 0x000075038BDDFA67
000075038bde4c7a  call 0x000075038BBFF540
000075038bde4c7f  jmp 0x000075038BDDFA71
000075038bde4c84  int3
000075038bde4c85  nop [rax+rax*1], ax
000075038bde4c8e  nop
000075038bde4c90  mov qword ptr [r15+0x40], 0x430000
000075038bde4c98  mov eax, 0x430CC0
000075038bde4c9d  mov r14, [r13+rax*1]
000075038bde4ca2  movq xmm1, r14
000075038bde4ca7  mov rax, [r15+0x50]
000075038bde4cab  movups xmm15, [r13+rax*1]
000075038bde4cb1  movaps [r15+0x120], xmm15
000075038bde4cb9  mov qword ptr [r15+0x48], 0x10
000075038bde4cc1  xor eax, eax
000075038bde4cc3  mov r14d, 0x10
000075038bde4cc9  mov r12d, 0x200
000075038bde4ccf  cmp r14, r12
000075038bde4cd2  cmc
000075038bde4cd3  lahf
000075038bde4cd4  seto al
000075038bde4cd7  mov [r15+0x108], eax
000075038bde4cde  pextrq rax, xmm15, 0x01
000075038bde4ce5  movq xmm14, rax
000075038bde4cea  movaps [r15+0x130], xmm14
000075038bde4cf2  movq rax, xmm1
000075038bde4cf7  movq r14, xmm15
000075038bde4cfc  vmovq xmm1, rax
000075038bde4d01  vmovq xmm15, r14
000075038bde4d06  movaps xmm13, xmm1
000075038bde4d0a  addsd xmm13, xmm15
000075038bde4d0f  ucomisd xmm13, xmm13
000075038bde4d14  jp 0x000075038BDE4DD3
000075038bde4d1a  movq xmm13, xmm13
000075038bde4d1f  movq rax, xmm13
000075038bde4d24  movq r14, xmm14
000075038bde4d29  vmovq xmm1, rax
000075038bde4d2e  vmovq xmm15, r14
000075038bde4d33  movaps xmm14, xmm1
000075038bde4d37  addsd xmm14, xmm15
000075038bde4d3c  ucomisd xmm14, xmm14
000075038bde4d41  jp 0x000075038BDE4E1B
000075038bde4d47  movq xmm14, xmm14
000075038bde4d4c  movaps [r15+0x110], xmm14
000075038bde4d54  mov eax, [r15+0x108]
000075038bde4d5b  sahf
000075038bde4d5c  jnz 0x000075038BDE4D8E
000075038bde4d5e  cmp dword ptr [r15+0x318], 0x00
000075038bde4d66  jz 0x000075038BDE5030
000075038bde4d6c  nop [rax+rax*1], ax
000075038bde4d75  nop [rax+rax*1], eax
000075038bde4d7d  mov eax, 0x410704
000075038bde4d82  mov [r15+0x100], rax
000075038bde4d89  jmp 0x000075038BBFE110
000075038bde4d8e  cmp dword ptr [r15+0x318], 0x00
000075038bde4d96  jz 0x000075038BDE4E70
000075038bde4d9c  nop [rax+rax*1], ax
000075038bde4da5  nop [rax+rax*1], eax
000075038bde4dad  mov eax, 0x4106E8
000075038bde4db2  mov [r15+0x100], rax
000075038bde4db9  jmp 0x000075038BBFE110
000075038bde4dbe  int3
000075038bde4dbf  call 0x000075038BC0DC20
000075038bde4dc4  jmp 0x000075038BDE4CA2
000075038bde4dc9  call 0x000075038BC0E760
000075038bde4dce  jmp 0x000075038BDE4CB1
000075038bde4dd3  ucomisd xmm1, xmm15
000075038bde4dd8  jp 0x000075038BDE4DE7
000075038bde4dda  movaps xmm13, [0x000075038B9FE060]
000075038bde4de2  jmp 0x000075038BDE4D1A
000075038bde4de7  vxorps xmm0, xmm1, xmm15
000075038bde4dec  pextrw eax, xmm0, 0x03
000075038bde4df1  and eax, 0x7FF8
000075038bde4df6  cmp eax, 0x08
000075038bde4df9  jnz 0x000075038BDE4D1A
000075038bde4dff  movq rax, xmm15
000075038bde4e04  shl rax, 0x0D
000075038bde4e08  jbe 0x000075038BDE4D1A
000075038bde4e0e  vorps xmm13, xmm15, [0x000075038B9FE070]
000075038bde4e16  jmp 0x000075038BDE4D1A
000075038bde4e1b  ucomisd xmm1, xmm15
000075038bde4e20  jp 0x000075038BDE4E2F
000075038bde4e22  movaps xmm14, [0x000075038B9FE060]
000075038bde4e2a  jmp 0x000075038BDE4D47
000075038bde4e2f  vxorps xmm0, xmm1, xmm15
000075038bde4e34  pextrw eax, xmm0, 0x03
000075038bde4e39  and eax, 0x7FF8
000075038bde4e3e  cmp eax, 0x08
000075038bde4e41  jnz 0x000075038BDE4D47
000075038bde4e47  movq rax, xmm15
000075038bde4e4c  shl rax, 0x0D
000075038bde4e50  jbe 0x000075038BDE4D47
000075038bde4e56  vorps xmm14, xmm15, [0x000075038B9FE070]
000075038bde4e5e  jmp 0x000075038BDE4D47
000075038bde4e63  int3
000075038bde4e64  nop [rax+rax*1], ax
000075038bde4e6d  nop [rax], eax
000075038bde4e70  mov rax, [r15+0x48]
000075038bde4e74  mov r14, [r15+0x50]
000075038bde4e78  lea r12, [r14+rax*1]
000075038bde4e7c  movups xmm1, [r13+r12*1]
000075038bde4e82  movaps [r15+0x120], xmm1
000075038bde4e8a  lea r14, [rax+0x10]
000075038bde4e8e  mov [r15+0x48], r14
000075038bde4e92  xor eax, eax
000075038bde4e94  mov r12d, 0x200
000075038bde4e9a  cmp r14, r12
000075038bde4e9d  cmc
000075038bde4e9e  lahf
000075038bde4e9f  seto al
000075038bde4ea2  mov [r15+0x108], eax
000075038bde4ea9  pextrq rax, xmm1, 0x01
000075038bde4eb0  movq xmm15, rax
000075038bde4eb5  movaps [r15+0x130], xmm15
000075038bde4ebd  movaps xmm14, [r15+0x110]
000075038bde4ec5  movq rax, xmm14
000075038bde4eca  movq r14, xmm1
000075038bde4ecf  vmovq xmm1, rax
000075038bde4ed4  vmovq xmm14, r14
000075038bde4ed9  movaps xmm13, xmm1
000075038bde4edd  addsd xmm13, xmm14
000075038bde4ee2  ucomisd xmm13, xmm13
000075038bde4ee7  jp 0x000075038BDE4F9C
000075038bde4eed  movq xmm13, xmm13
000075038bde4ef2  movq rax, xmm13
000075038bde4ef7  movq r14, xmm15
000075038bde4efc  vmovq xmm1, rax
000075038bde4f01  vmovq xmm15, r14
000075038bde4f06  movaps xmm14, xmm1
000075038bde4f0a  addsd xmm14, xmm15
000075038bde4f0f  ucomisd xmm14, xmm14
000075038bde4f14  jp 0x000075038BDE4FE4
000075038bde4f1a  movq xmm14, xmm14
000075038bde4f1f  movaps [r15+0x110], xmm14
000075038bde4f27  mov eax, [r15+0x108]
000075038bde4f2e  sahf
000075038bde4f2f  jnz 0x000075038BDE4F61
000075038bde4f31  cmp dword ptr [r15+0x318], 0x00
000075038bde4f39  jz 0x000075038BDE5030
000075038bde4f3f  nop [rax+rax*1], ax
000075038bde4f48  nop [rax+rax*1], eax
000075038bde4f50  mov eax, 0x410704
000075038bde4f55  mov [r15+0x100], rax
000075038bde4f5c  jmp 0x000075038BBFE110
000075038bde4f61  cmp dword ptr [r15+0x318], 0x00
000075038bde4f69  jz 0x000075038BDE4E70
000075038bde4f6f  nop [rax+rax*1], ax
000075038bde4f78  nop [rax+rax*1], eax
000075038bde4f80  mov eax, 0x4106E8
000075038bde4f85  mov [r15+0x100], rax
000075038bde4f8c  jmp 0x000075038BBFE110
000075038bde4f91  int3
000075038bde4f92  call 0x000075038BCB52F0
000075038bde4f97  jmp 0x000075038BDE4E82
000075038bde4f9c  ucomisd xmm1, xmm14
000075038bde4fa1  jp 0x000075038BDE4FB0
000075038bde4fa3  movaps xmm13, [0x000075038B9FE060]
000075038bde4fab  jmp 0x000075038BDE4EED
000075038bde4fb0  vxorps xmm0, xmm1, xmm14
000075038bde4fb5  pextrw eax, xmm0, 0x03
000075038bde4fba  and eax, 0x7FF8
000075038bde4fbf  cmp eax, 0x08
000075038bde4fc2  jnz 0x000075038BDE4EED
000075038bde4fc8  movq rax, xmm14
000075038bde4fcd  shl rax, 0x0D
000075038bde4fd1  jbe 0x000075038BDE4EED
000075038bde4fd7  vorps xmm13, xmm14, [0x000075038B9FE070]
000075038bde4fdf  jmp 0x000075038BDE4EED
000075038bde4fe4  ucomisd xmm1, xmm15
000075038bde4fe9  jp 0x000075038BDE4FF8
000075038bde4feb  movaps xmm14, [0x000075038B9FE060]
000075038bde4ff3  jmp 0x000075038BDE4F1A
000075038bde4ff8  vxorps xmm0, xmm1, xmm15
000075038bde4ffd  pextrw eax, xmm0, 0x03
000075038bde5002  and eax, 0x7FF8
000075038bde5007  cmp eax, 0x08
000075038bde500a  jnz 0x000075038BDE4F1A
000075038bde5010  movq rax, xmm15
000075038bde5015  shl rax, 0x0D
000075038bde5019  jbe 0x000075038BDE4F1A
000075038bde501f  vorps xmm14, xmm15, [0x000075038B9FE070]
000075038bde5027  jmp 0x000075038BDE4F1A
000075038bde502c  int3
000075038bde502d  nop [rax], eax
000075038bde5030  mov rax, [r15+0xF8]
000075038bde5037  lea r14, [rax+0x1D0]
000075038bde503e  mov r12, [r13+r14*1]
000075038bde5043  lea r14, [rax+0x1D8]
000075038bde504a  mov r11, [r13+r14*1]
000075038bde504f  mov [r15+0xA0], r12
000075038bde5056  mov [r15+0x98], r11
000075038bde505d  mov r14, [r15+0x40]
000075038bde5061  lea r12, [r14+0xCC0]
000075038bde5068  movaps xmm1, [r15+0x110]
000075038bde5070  movq r14, xmm1
000075038bde5075  mov [r13+r12*1], r14
000075038bde507a  lea r14, [rax+0x1C0]
000075038bde5081  mov r12, [r13+r14*1]
000075038bde5086  lea r14, [rax+0x1C8]
000075038bde508d  mov r11, [r13+r14*1]
000075038bde5092  mov [r15+0xE8], r12
000075038bde5099  mov [r15+0xF0], r11
000075038bde50a0  lea r14, [rax+0x1B0]
000075038bde50a7  mov r12, [r13+r14*1]
000075038bde50ac  lea r14, [rax+0x1B8]
000075038bde50b3  mov r10, [r13+r14*1]
000075038bde50b8  movq xmm1, r12
000075038bde50bd  movq xmm15, r10
000075038bde50c2  movq xmm1, xmm1
000075038bde50c6  movq xmm1, xmm1
000075038bde50ca  movaps [r15+0x1A0], xmm1
000075038bde50d2  movq xmm15, xmm15
000075038bde50d7  movq xmm15, xmm15
000075038bde50dc  movaps [r15+0x190], xmm15
000075038bde50e4  lea r14, [rax+0x1A0]
000075038bde50eb  mov r12, [r13+r14*1]
000075038bde50f0  lea r14, [rax+0x1A8]
000075038bde50f7  mov r10, [r13+r14*1]
000075038bde50fc  movq xmm1, r12
000075038bde5101  movq xmm15, r10
000075038bde5106  movq xmm1, xmm1
000075038bde510a  movq xmm1, xmm1
000075038bde510e  movaps [r15+0x1C0], xmm1
000075038bde5116  movq xmm15, xmm15
000075038bde511b  movq xmm15, xmm15
000075038bde5120  movaps [r15+0x1B0], xmm15
000075038bde5128  lea r14, [rax+0x190]
000075038bde512f  mov r12, [r13+r14*1]
000075038bde5134  lea r14, [rax+0x198]
000075038bde513b  mov r10, [r13+r14*1]
000075038bde5140  movq xmm1, r12
000075038bde5145  movq xmm15, r10
000075038bde514a  movq xmm1, xmm1
000075038bde514e  movq xmm1, xmm1
000075038bde5152  movaps [r15+0x1E0], xmm1
000075038bde515a  movq xmm15, xmm15
000075038bde515f  movq xmm15, xmm15
000075038bde5164  movaps [r15+0x1D0], xmm15
000075038bde516c  lea r14, [rax+0x180]
000075038bde5173  mov r12, [r13+r14*1]
000075038bde5178  lea r14, [rax+0x188]
000075038bde517f  mov r10, [r13+r14*1]
000075038bde5184  movq xmm1, r12
000075038bde5189  movq xmm15, r10
000075038bde518e  movq xmm1, xmm1
000075038bde5192  movq xmm1, xmm1
000075038bde5196  movaps [r15+0x200], xmm1
000075038bde519e  movq xmm15, xmm15
000075038bde51a3  movq xmm15, xmm15
000075038bde51a8  movaps [r15+0x1F0], xmm15
000075038bde51b0  lea r14, [rax+0x1E0]
000075038bde51b7  mov [r15+0xF8], r14
000075038bde51be  mov [r15+0x100], r11
000075038bde51c5  jmp 0x000075038BDCE5C0
000075038bde51ca  int3
000075038bde51cb  call 0x000075038BCE27E0
000075038bde51d0  jmp 0x000075038BDE5043
000075038bde51d5  call 0x000075038BCE1570
000075038bde51da  jmp 0x000075038BDE504F
000075038bde51df  call 0x000075038BCC3FE0
000075038bde51e4  jmp 0x000075038BDE507A
000075038bde51e9  call 0x000075038BCE27E0
000075038bde51ee  jmp 0x000075038BDE5086
000075038bde51f3  call 0x000075038BCE1570
000075038bde51f8  jmp 0x000075038BDE5092
000075038bde51fd  call 0x000075038BCE27E0
000075038bde5202  jmp 0x000075038BDE50AC
000075038bde5207  call 0x000075038BCE0300
000075038bde520c  jmp 0x000075038BDE50B8
000075038bde5211  call 0x000075038BCE27E0
000075038bde5216  jmp 0x000075038BDE50F0
000075038bde521b  call 0x000075038BCE0300
000075038bde5220  jmp 0x000075038BDE50FC
000075038bde5225  call 0x000075038BCE27E0
000075038bde522a  jmp 0x000075038BDE5134
000075038bde522f  call 0x000075038BCE0300
000075038bde5234  jmp 0x000075038BDE5140
000075038bde5239  call 0x000075038BCE27E0
000075038bde523e  jmp 0x000075038BDE5178
000075038bde5243  call 0x000075038BCE0300
000075038bde5248  jmp 0x000075038BDE5184
000075038bde524d  int3
000075038bde524e  nop
000075038bde5250  mov qword ptr [r15+0x100], 0x04
000075038bde525b  mov esi, 0x00
000075038bde5260  mov edx, 0x09
000075038bde5265  mov rdi, 0x7FFE073C8900
000075038bde526f  mov rax, 0x56ADB4325970
000075038bde5279  call rax
000075038bde527b  cmp dword ptr [r15+0x318], 0x00
000075038bde5283  jnz 0x000075038BBFE110
000075038bde5289  jmp 0x000075038BBFE0A0
000075038bde528e  int3
000075038bde528f  int3
