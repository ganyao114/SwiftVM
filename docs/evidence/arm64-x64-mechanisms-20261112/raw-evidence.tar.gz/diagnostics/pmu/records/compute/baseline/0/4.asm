
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/baseline/0/4.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13,QWORD PTR [r12+0xf8]
   8:	mov    r14,r13
   b:	add    r14,0x168
  12:	mov    r13,QWORD PTR [r14]
  15:	mov    QWORD PTR [r12+0x40],r13
  1a:	mov    r14,r13
  1d:	sub    r14,0x38
  21:	pushf
  22:	pop    rdx
  23:	mov    r10d,edx
  26:	and    r10d,0xc0
  2d:	shl    r10d,0x18
  31:	mov    r11d,edx
  34:	and    r11d,0x1
  38:	shl    r11d,0x1d
  3c:	or     r10d,r11d
  3f:	mov    r11d,edx
  42:	and    r11d,0x800
  49:	shl    r11d,0x11
  4d:	or     r10d,r11d
  50:	mov    r11d,0xf0000000
  56:	and    r11,r10
  59:	movabs rsi,0xffffffff0fffffff
  63:	and    rbx,rsi
  66:	or     rbx,r11
  69:	btc    rbx,0x1d
  6e:	cmp    QWORD PTR [r12+0x380],0x0
  77:	je     0xa4
  7d:	mov    eax,0x4102d0
  82:	mov    QWORD PTR [r12+0x100],rax
  8a:	mov    QWORD PTR [r12+0x108],rbx
  92:	mov    eax,0xc
  97:	movabs r11,0x5b99604255f0
  a1:	jmp    r11
  a4:	test   ebx,0x40000000
  aa:	je     0xfd
  b0:	jmp    0xb5
  b5:	mov    r13d,0x4102d4
  bb:	mov    QWORD PTR [r12+0x100],r13
  c3:	mov    QWORD PTR [r12+0x108],rbx
  cb:	mov    edi,0x4102d4
  d0:	mov    QWORD PTR [r12+0x100],rdi
  d8:	jmp    QWORD PTR [rip+0x2]        # 0xe0
  de:	xchg   ax,ax
  e0:	push   rax
  e1:	and    DWORD PTR [rax+0x74de06],edx
  e7:	add    BYTE PTR [rax+0x22],dl
  ea:	nop
  eb:	(bad)
  ec:	fidiv  WORD PTR [rax+rax*1+0x0]
  f0:	movabs r11,0x5b9960425370
  fa:	jmp    r11
  fd:	mov    r13d,0x4102b8
 103:	mov    QWORD PTR [r12+0x100],r13
 10b:	mov    QWORD PTR [r12+0x108],rbx
 113:	mov    edi,0x4102b8
 118:	mov    QWORD PTR [r12+0x100],rdi
 120:	jmp    QWORD PTR [rip+0x2]        # 0x128
 126:	xchg   ax,ax
 128:	rex and DWORD PTR [rax+0x74de06],edx
 12f:	add    BYTE PTR [rax-0x21f96fde],bl
 135:	je     0x137
 137:	add    BYTE PTR [rcx-0x45],cl
 13a:	jo     0x18f
 13c:	rex.X (bad)
 13e:	cdq
 13f:	pop    rbx
 140:	add    BYTE PTR [rax],al
 142:	jmp    r11
 145:	nop
 146:	nop
 147:	nop
