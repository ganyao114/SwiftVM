
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-matrix/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x140
       7:	mov    r13d,0x420000
       d:	mov    QWORD PTR [r12+0x40],r13
      12:	movabs r13,0x100000001
      1c:	mov    r14d,0x0
      22:	mov    QWORD PTR [r12+0x110],r13
      2a:	mov    QWORD PTR [r12+0x118],r14
      32:	movabs r13,0x3fa0000000000000
      3c:	mov    QWORD PTR [r12+0x50],r13
      41:	movabs r13,0x4100000041
      4b:	mov    r14d,0x0
      51:	mov    QWORD PTR [r12+0x120],r13
      59:	mov    QWORD PTR [r12+0x128],r14
      61:	mov    r13d,0x4204c0
      67:	mov    r14,QWORD PTR [r13+0x0]
      6b:	mov    r13d,0x0
      71:	mov    QWORD PTR [r12+0x130],r14
      79:	mov    QWORD PTR [r12+0x138],r13
      81:	movabs r13,0x3fc0000000000000
      8b:	movabs r14,0x3fc0000000000000
      95:	mov    QWORD PTR [r12+0x140],r13
      9d:	mov    QWORD PTR [r12+0x148],r14
      a5:	mov    r13d,0x2
      ab:	mov    QWORD PTR [r12+0x40],r13
      b0:	movabs r13,0x200000002
      ba:	mov    r14d,0x0
      c0:	mov    QWORD PTR [r12+0x150],r13
      c8:	mov    QWORD PTR [r12+0x158],r14
      d0:	mov    r13d,0x420000
      d6:	mov    QWORD PTR [r12+0x58],r13
      db:	mov    r13,QWORD PTR [r12+0x50]
      e0:	mov    r14,r13
      e3:	and    r14,0xffffffffffffffff
      e7:	mov    QWORD PTR [r12+0x160],r14
      ef:	mov    QWORD PTR [r12+0x168],r14
      f7:	mov    r13d,0x2
      fd:	mov    QWORD PTR [r12+0x170],r13
     105:	mov    QWORD PTR [r12+0x178],r13
     10d:	mov    r13d,0x4204d0
     113:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     119:	movdqa xmm0,xmm2
     11d:	movdqu XMMWORD PTR [r12+0x180],xmm0
     127:	mov    r13d,0x0
     12d:	mov    QWORD PTR [r12+0x48],r13
     132:	mov    r13d,0x430000
     138:	mov    QWORD PTR [r12+0x40],r13
     13d:	mov    r13d,0x430000
     143:	mov    r14,r13
     146:	add    r14,0x518
     14d:	mov    QWORD PTR [r12+0x40],r14
     152:	mov    r13d,0x430000
     158:	mov    QWORD PTR [r12+0x50],r13
     15d:	mov    r13d,0x430000
     163:	mov    r14,r13
     166:	add    r14,0x720
     16d:	mov    QWORD PTR [r12+0x50],r14
     172:	jmp    0x177
     177:	mov    r13,QWORD PTR [r12+0x180]
     17f:	mov    r14,QWORD PTR [r12+0x188]
     187:	mov    r15d,0x0
     18d:	mov    rbp,r13
     190:	mov    r13,rbp
     193:	and    r13,0xffffffffffffffff
     197:	mov    ecx,0xffffffff
     19c:	mov    rbp,r13
     19f:	and    rbp,rcx
     1a2:	mov    r13,rbp
     1a5:	mov    rcx,r13
     1a8:	mov    rbp,r15
     1ab:	or     rbp,rcx
     1ae:	mov    r13,r14
     1b1:	mov    r14,r13
     1b4:	and    r14,0xffffffffffffffff
     1b8:	mov    ecx,0xffffffff
     1bd:	mov    r13,r14
     1c0:	and    r13,rcx
     1c3:	mov    r14,r13
     1c6:	shl    r14,0x20
     1ca:	mov    rcx,r14
     1cd:	mov    r13,rbp
     1d0:	or     r13,rcx
     1d3:	mov    QWORD PTR [r12+0x210],r13
     1db:	mov    QWORD PTR [r12+0x218],r15
     1e3:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     1ed:	movdqa xmm2,xmm0
     1f1:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     1fb:	movdqa xmm3,xmm0
     1ff:	movdqa xmm0,xmm2
     203:	movdqa xmm1,xmm3
     207:	psubd  xmm0,xmm1
     20b:	movdqa xmm4,xmm0
     20f:	movdqa xmm14,xmm4
     214:	movdqa xmm1,xmm14
     219:	movq   rax,xmm1
     21e:	mov    r13,rax
     221:	mov    r14d,0x0
     227:	mov    QWORD PTR [r12+0x220],r13
     22f:	mov    QWORD PTR [r12+0x228],r14
     237:	movdqu xmm0,XMMWORD PTR [r12+0x180]
     241:	movdqa xmm2,xmm0
     245:	movdqu xmm0,XMMWORD PTR [r12+0x170]
     24f:	movdqa xmm4,xmm0
     253:	movdqa xmm0,xmm2
     257:	movdqa xmm1,xmm4
     25b:	paddq  xmm0,xmm1
     25f:	movdqa xmm5,xmm0
     263:	movdqa xmm0,xmm5
     267:	movdqu XMMWORD PTR [r12+0x180],xmm0
     271:	movdqu xmm0,XMMWORD PTR [r12+0x150]
     27b:	movdqa xmm2,xmm0
     27f:	movdqa xmm0,xmm3
     283:	movdqa xmm1,xmm2
     287:	paddd  xmm0,xmm1
     28b:	movdqa xmm4,xmm0
     28f:	movdqa xmm14,xmm4
     294:	movdqa xmm1,xmm14
     299:	movq   rax,xmm1
     29e:	mov    r14,rax
     2a1:	mov    r15d,0x0
     2a7:	mov    QWORD PTR [r12+0x130],r14
     2af:	mov    QWORD PTR [r12+0x138],r15
     2b7:	mov    r14d,0x0
     2bd:	mov    r15,r13
     2c0:	mov    ecx,0xffffffff
     2c5:	mov    rbp,r15
     2c8:	and    rbp,rcx
     2cb:	mov    r15,rbp
     2ce:	mov    rbp,r15
     2d1:	and    rbp,0xffffffffffffffff
     2d5:	mov    r15,rbp
     2d8:	mov    rcx,r15
     2db:	mov    rbp,r14
     2de:	or     rbp,rcx
     2e1:	mov    r15,r13
     2e4:	shr    r15,0x20
     2e8:	mov    ecx,0xffffffff
     2ed:	mov    r13,r15
     2f0:	and    r13,rcx
     2f3:	mov    r15,r13
     2f6:	mov    r13,r15
     2f9:	and    r13,0xffffffffffffffff
     2fd:	mov    r15,r13
     300:	mov    rcx,r15
     303:	mov    r13,r14
     306:	or     r13,rcx
     309:	mov    QWORD PTR [r12+0x220],rbp
     311:	mov    QWORD PTR [r12+0x228],r13
     319:	movdqu xmm0,XMMWORD PTR [r12+0x210]
     323:	movdqa xmm2,xmm0
     327:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     331:	movdqa xmm3,xmm0
     335:	movdqa xmm0,xmm2
     339:	movdqa xmm1,xmm3
     33d:	paddd  xmm0,xmm1
     341:	movdqa xmm4,xmm0
     345:	movdqa xmm14,xmm4
     34a:	movdqa xmm1,xmm14
     34f:	movq   rax,xmm1
     354:	mov    r13,rax
     357:	mov    r14d,0x0
     35d:	mov    QWORD PTR [r12+0x210],r13
     365:	mov    QWORD PTR [r12+0x218],r14
     36d:	lea    r13,[r12]
     371:	movabs r14,0xb6e61da31
     37b:	mov    r15d,0x4101c4
     381:	mov    QWORD PTR [r12+0x378],0x3
     38d:	mov    QWORD PTR [r12+0x108],rbx
     395:	stmxcsr DWORD PTR [r12-0x28]
     39b:	ldmxcsr DWORD PTR [r12-0x38]
     3a1:	movabs r11,0x5a1b9d1834c0
     3ab:	mov    rdi,r13
     3ae:	mov    rsi,r14
     3b1:	mov    rdx,r15
     3b4:	call   r11
     3b7:	ldmxcsr DWORD PTR [r12-0x28]
     3bd:	mov    rbx,QWORD PTR [r12+0x108]
     3c5:	mov    QWORD PTR [r12+0x378],0x2
     3d1:	mov    rbp,rax
     3d4:	mov    r13,QWORD PTR [r12+0x210]
     3dc:	mov    r14d,0x0
     3e2:	mov    r15,r13
     3e5:	mov    ecx,0xffffffff
     3ea:	mov    rbp,r15
     3ed:	and    rbp,rcx
     3f0:	mov    r15,rbp
     3f3:	mov    rbp,r15
     3f6:	and    rbp,0xffffffffffffffff
     3fa:	mov    r15,rbp
     3fd:	mov    rcx,r15
     400:	mov    rbp,r14
     403:	or     rbp,rcx
     406:	mov    r15,r13
     409:	shr    r15,0x20
     40d:	mov    ecx,0xffffffff
     412:	mov    r13,r15
     415:	and    r13,rcx
     418:	mov    r15,r13
     41b:	mov    r13,r15
     41e:	and    r13,0xffffffffffffffff
     422:	mov    r15,r13
     425:	mov    rcx,r15
     428:	mov    r13,r14
     42b:	or     r13,rcx
     42e:	mov    QWORD PTR [r12+0x210],rbp
     436:	mov    QWORD PTR [r12+0x218],r13
     43e:	lea    r13,[r12]
     442:	movabs r14,0xb6e61da10
     44c:	mov    r15d,0x4101cc
     452:	mov    QWORD PTR [r12+0x378],0x3
     45e:	mov    QWORD PTR [r12+0x108],rbx
     466:	stmxcsr DWORD PTR [r12-0x28]
     46c:	ldmxcsr DWORD PTR [r12-0x38]
     472:	movabs r11,0x5a1b9d1834c0
     47c:	mov    rdi,r13
     47f:	mov    rsi,r14
     482:	mov    rdx,r15
     485:	call   r11
     488:	ldmxcsr DWORD PTR [r12-0x28]
     48e:	mov    rbx,QWORD PTR [r12+0x108]
     496:	mov    QWORD PTR [r12+0x378],0x2
     4a2:	mov    rbp,rax
     4a5:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     4af:	movdqa xmm2,xmm0
     4b3:	movdqu xmm0,XMMWORD PTR [r12+0x140]
     4bd:	movdqa xmm3,xmm0
     4c1:	cmp    DWORD PTR [r12+0x310],0x0
     4ca:	jne    0x5ae
     4d0:	movdqa xmm0,xmm2
     4d4:	movdqa xmm1,xmm3
     4d8:	movq   rax,xmm0
     4dd:	add    rax,rax
     4e0:	je     0x4f6
     4e2:	shr    rax,0x35
     4e6:	sub    eax,0x201
     4eb:	cmp    eax,0x3fc
     4f0:	ja     0x5ae
     4f6:	movdqa xmm14,xmm0
     4fb:	psrldq xmm14,0x8
     501:	movq   rax,xmm14
     506:	add    rax,rax
     509:	je     0x51f
     50b:	shr    rax,0x35
     50f:	sub    eax,0x201
     514:	cmp    eax,0x3fc
     519:	ja     0x5ae
     51f:	movq   rax,xmm1
     524:	add    rax,rax
     527:	je     0x53d
     529:	shr    rax,0x35
     52d:	sub    eax,0x201
     532:	cmp    eax,0x3fc
     537:	ja     0x5ae
     53d:	movdqa xmm14,xmm1
     542:	psrldq xmm14,0x8
     548:	movq   rax,xmm14
     54d:	add    rax,rax
     550:	je     0x566
     552:	shr    rax,0x35
     556:	sub    eax,0x201
     55b:	cmp    eax,0x3fc
     560:	ja     0x5ae
     566:	stmxcsr DWORD PTR [rsp+0x100]
     56e:	mov    DWORD PTR [rsp+0x104],0x1f80
     579:	ldmxcsr DWORD PTR [rsp+0x104]
     581:	mulpd  xmm0,xmm1
     585:	stmxcsr DWORD PTR [rsp+0x104]
     58d:	ldmxcsr DWORD PTR [rsp+0x100]
     595:	mov    eax,DWORD PTR [rsp+0x104]
     59c:	shr    eax,1
     59e:	and    eax,0x10
     5a1:	or     DWORD PTR [r12+0x314],eax
     5a9:	jmp    0x65b
     5ae:	movdqa xmm0,xmm2
     5b2:	movdqa xmm1,xmm3
     5b6:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     5bf:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     5c8:	mov    QWORD PTR [r12+0x378],0x3
     5d4:	movdqu XMMWORD PTR [rsp],xmm2
     5d9:	movdqu XMMWORD PTR [rsp+0x10],xmm3
     5df:	mov    QWORD PTR [r12+0x108],rbx
     5e7:	stmxcsr DWORD PTR [r12-0x28]
     5ed:	ldmxcsr DWORD PTR [r12-0x38]
     5f3:	lea    rdi,[rsp+0xf0]
     5fb:	lea    rsi,[rsp+0xd0]
     603:	lea    rdx,[rsp+0xe0]
     60b:	mov    ecx,0x16
     610:	mov    r8d,DWORD PTR [r12+0x310]
     618:	lea    r9,[r12+0x314]
     620:	movabs r11,0x5a1b9d18a750
     62a:	call   r11
     62d:	ldmxcsr DWORD PTR [r12-0x28]
     633:	movdqu xmm2,XMMWORD PTR [rsp]
     638:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
     63e:	mov    rbx,QWORD PTR [r12+0x108]
     646:	mov    QWORD PTR [r12+0x378],0x2
     652:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     65b:	movdqa xmm4,xmm0
     65f:	movdqa xmm0,xmm4
     663:	movdqu XMMWORD PTR [r12+0x220],xmm0
     66d:	mov    r13,QWORD PTR [r12+0x48]
     672:	mov    r14,QWORD PTR [r12+0x50]
     677:	mov    rcx,r13
     67a:	mov    r15,r14
     67d:	add    r15,rcx
     680:	movdqu XMMWORD PTR [r15],xmm4
     685:	mov    r13d,0x0
     68b:	mov    DWORD PTR [r12+0x32c],r13d
     693:	movdqu xmm0,XMMWORD PTR [r12+0x210]
     69d:	movdqa xmm2,xmm0
     6a1:	movdqu xmm0,XMMWORD PTR [r12+0x160]
     6ab:	movdqa xmm3,xmm0
     6af:	cmp    DWORD PTR [r12+0x310],0x0
     6b8:	jne    0x79c
     6be:	movdqa xmm0,xmm2
     6c2:	movdqa xmm1,xmm3
     6c6:	movq   rax,xmm0
     6cb:	add    rax,rax
     6ce:	je     0x6e4
     6d0:	shr    rax,0x35
     6d4:	sub    eax,0x201
     6d9:	cmp    eax,0x3fc
     6de:	ja     0x79c
     6e4:	movdqa xmm14,xmm0
     6e9:	psrldq xmm14,0x8
     6ef:	movq   rax,xmm14
     6f4:	add    rax,rax
     6f7:	je     0x70d
     6f9:	shr    rax,0x35
     6fd:	sub    eax,0x201
     702:	cmp    eax,0x3fc
     707:	ja     0x79c
     70d:	movq   rax,xmm1
     712:	add    rax,rax
     715:	je     0x72b
     717:	shr    rax,0x35
     71b:	sub    eax,0x201
     720:	cmp    eax,0x3fc
     725:	ja     0x79c
     72b:	movdqa xmm14,xmm1
     730:	psrldq xmm14,0x8
     736:	movq   rax,xmm14
     73b:	add    rax,rax
     73e:	je     0x754
     740:	shr    rax,0x35
     744:	sub    eax,0x201
     749:	cmp    eax,0x3fc
     74e:	ja     0x79c
     754:	stmxcsr DWORD PTR [rsp+0x100]
     75c:	mov    DWORD PTR [rsp+0x104],0x1f80
     767:	ldmxcsr DWORD PTR [rsp+0x104]
     76f:	mulpd  xmm0,xmm1
     773:	stmxcsr DWORD PTR [rsp+0x104]
     77b:	ldmxcsr DWORD PTR [rsp+0x100]
     783:	mov    eax,DWORD PTR [rsp+0x104]
     78a:	shr    eax,1
     78c:	and    eax,0x10
     78f:	or     DWORD PTR [r12+0x314],eax
     797:	jmp    0x849
     79c:	movdqa xmm0,xmm2
     7a0:	movdqa xmm1,xmm3
     7a4:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     7ad:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     7b6:	mov    QWORD PTR [r12+0x378],0x3
     7c2:	movdqu XMMWORD PTR [rsp],xmm2
     7c7:	movdqu XMMWORD PTR [rsp+0x10],xmm3
     7cd:	mov    QWORD PTR [r12+0x108],rbx
     7d5:	stmxcsr DWORD PTR [r12-0x28]
     7db:	ldmxcsr DWORD PTR [r12-0x38]
     7e1:	lea    rdi,[rsp+0xf0]
     7e9:	lea    rsi,[rsp+0xd0]
     7f1:	lea    rdx,[rsp+0xe0]
     7f9:	mov    ecx,0x16
     7fe:	mov    r8d,DWORD PTR [r12+0x310]
     806:	lea    r9,[r12+0x314]
     80e:	movabs r11,0x5a1b9d18a750
     818:	call   r11
     81b:	ldmxcsr DWORD PTR [r12-0x28]
     821:	movdqu xmm2,XMMWORD PTR [rsp]
     826:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
     82c:	mov    rbx,QWORD PTR [r12+0x108]
     834:	mov    QWORD PTR [r12+0x378],0x2
     840:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     849:	movdqa xmm4,xmm0
     84d:	movdqa xmm0,xmm4
     851:	movdqu XMMWORD PTR [r12+0x210],xmm0
     85b:	mov    r13,QWORD PTR [r12+0x48]
     860:	mov    r14,QWORD PTR [r12+0x40]
     865:	mov    rcx,r13
     868:	mov    r15,r14
     86b:	add    r15,rcx
     86e:	movdqu XMMWORD PTR [r15],xmm4
     873:	mov    r14d,0x0
     879:	mov    DWORD PTR [r12+0x32c],r14d
     881:	mov    r14,r13
     884:	add    r14,0x10
     888:	mov    QWORD PTR [r12+0x48],r14
     88d:	mov    r13,r14
     890:	sub    r13,0x200
     897:	pushf
     898:	pop    rdx
     899:	mov    r10d,edx
     89c:	and    r10d,0xc0
     8a3:	shl    r10d,0x18
     8a7:	mov    r11d,edx
     8aa:	and    r11d,0x1
     8ae:	shl    r11d,0x1d
     8b2:	or     r10d,r11d
     8b5:	mov    r11d,edx
     8b8:	and    r11d,0x800
     8bf:	shl    r11d,0x11
     8c3:	or     r10d,r11d
     8c6:	mov    r11d,0xf0000000
     8cc:	and    r11,r10
     8cf:	movabs rsi,0xffffffff0fffffff
     8d9:	and    rbx,rsi
     8dc:	or     rbx,r11
     8df:	btc    rbx,0x1d
     8e4:	cmp    QWORD PTR [r12+0x380],0x0
     8ed:	je     0x921
     8f3:	mov    eax,0x4101e8
     8f8:	mov    QWORD PTR [r12+0x100],rax
     900:	mov    QWORD PTR [r12+0x108],rbx
     908:	add    rsp,0x140
     90f:	mov    eax,0xc
     914:	movabs r11,0x5a1b9d31e5f0
     91e:	jmp    r11
     921:	test   ebx,0x40000000
     927:	je     0x177
     92d:	jmp    0x932
     932:	mov    r13,QWORD PTR [r12+0xf8]
     93a:	mov    r14,r13
     93d:	sub    r14,0x150
     944:	mov    QWORD PTR [r12+0xf8],r14
     94c:	mov    r13,QWORD PTR [r12+0x50]
     951:	mov    r15,r13
     954:	add    r15,0x80
     95b:	mov    rbp,r15
     95e:	add    rbp,0x10
     962:	movdqu xmm2,XMMWORD PTR [r15]
     967:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     96c:	movdqa xmm0,xmm2
     970:	movdqu XMMWORD PTR [r12+0x130],xmm0
     97a:	movdqa xmm0,xmm3
     97e:	movdqu XMMWORD PTR [r12+0x110],xmm0
     988:	mov    r15d,0x0
     98e:	mov    QWORD PTR [r12+0x48],r15
     993:	mov    r15,r13
     996:	add    r15,0x40
     99a:	mov    r13,r15
     99d:	add    r13,0x10
     9a1:	movdqu xmm2,XMMWORD PTR [r15]
     9a6:	movdqu xmm3,XMMWORD PTR [r13+0x0]
     9ac:	movdqa xmm0,xmm2
     9b0:	movdqu XMMWORD PTR [r12+0x250],xmm0
     9ba:	movdqa xmm0,xmm3
     9be:	movdqu XMMWORD PTR [r12+0x120],xmm0
     9c8:	mov    r13,r14
     9cb:	add    r13,0x120
     9d2:	mov    r14,r13
     9d5:	add    r14,0x8
     9d9:	mov    r15,QWORD PTR [r12+0x1c0]
     9e1:	mov    rbp,QWORD PTR [r12+0x1b0]
     9e9:	mov    QWORD PTR [r13+0x0],r15
     9ed:	mov    r13d,0x0
     9f3:	mov    DWORD PTR [r12+0x32c],r13d
     9fb:	mov    QWORD PTR [r14],rbp
     9fe:	mov    r13d,0x0
     a04:	mov    DWORD PTR [r12+0x32c],r13d
     a0c:	mov    r13d,0x0
     a12:	mov    r14d,0x0
     a18:	mov    QWORD PTR [r12+0x1b0],r13
     a20:	mov    QWORD PTR [r12+0x1b8],r14
     a28:	mov    r13,QWORD PTR [r12+0xf8]
     a30:	mov    r14,r13
     a33:	add    r14,0x100
     a3a:	mov    r15,r14
     a3d:	add    r15,0x8
     a41:	mov    rbp,QWORD PTR [r12+0x200]
     a49:	mov    r8,QWORD PTR [r12+0x1f0]
     a51:	mov    QWORD PTR [r14],rbp
     a54:	mov    r14d,0x0
     a5a:	mov    DWORD PTR [r12+0x32c],r14d
     a62:	mov    QWORD PTR [r15],r8
     a65:	mov    r14d,0x0
     a6b:	mov    DWORD PTR [r12+0x32c],r14d
     a73:	mov    r14,r13
     a76:	add    r14,0xe0
     a7d:	mov    r15,r14
     a80:	add    r15,0x10
     a84:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     a8e:	movdqa xmm2,xmm0
     a92:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     a9c:	movdqa xmm3,xmm0
     aa0:	movdqu XMMWORD PTR [r14],xmm2
     aa5:	mov    r14d,0x0
     aab:	mov    DWORD PTR [r12+0x32c],r14d
     ab3:	movdqu XMMWORD PTR [r15],xmm3
     ab8:	mov    r14d,0x0
     abe:	mov    DWORD PTR [r12+0x32c],r14d
     ac6:	mov    r14,QWORD PTR [r12+0x50]
     acb:	mov    r15,r14
     ace:	add    r15,0xc0
     ad5:	mov    rbp,r15
     ad8:	add    rbp,0x10
     adc:	movdqu xmm2,XMMWORD PTR [r15]
     ae1:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     ae6:	movdqa xmm0,xmm2
     aea:	movdqu XMMWORD PTR [r12+0x130],xmm0
     af4:	movdqa xmm0,xmm3
     af8:	movdqu XMMWORD PTR [r12+0x110],xmm0
     b02:	mov    r15,r13
     b05:	add    r15,0x110
     b0c:	mov    r13,r15
     b0f:	add    r13,0x8
     b13:	mov    rbp,QWORD PTR [r12+0x1e0]
     b1b:	mov    r8,QWORD PTR [r12+0x1d0]
     b23:	mov    QWORD PTR [r15],rbp
     b26:	mov    r15d,0x0
     b2c:	mov    DWORD PTR [r12+0x32c],r15d
     b34:	mov    QWORD PTR [r13+0x0],r8
     b38:	mov    r13d,0x0
     b3e:	mov    DWORD PTR [r12+0x32c],r13d
     b46:	mov    r13,r14
     b49:	add    r13,0x10
     b4d:	movdqu xmm2,XMMWORD PTR [r14]
     b52:	movdqu xmm3,XMMWORD PTR [r13+0x0]
     b58:	movdqa xmm0,xmm2
     b5c:	movdqu XMMWORD PTR [r12+0x170],xmm0
     b66:	movdqa xmm0,xmm3
     b6a:	movdqu XMMWORD PTR [r12+0x180],xmm0
     b74:	mov    r13,QWORD PTR [r12+0xf8]
     b7c:	mov    r14,r13
     b7f:	add    r14,0x130
     b86:	mov    r15,r14
     b89:	add    r15,0x8
     b8d:	mov    rbp,QWORD PTR [r12+0x1a0]
     b95:	mov    r8,QWORD PTR [r12+0x190]
     b9d:	mov    QWORD PTR [r14],rbp
     ba0:	mov    r14d,0x0
     ba6:	mov    DWORD PTR [r12+0x32c],r14d
     bae:	mov    QWORD PTR [r15],r8
     bb1:	mov    r14d,0x0
     bb7:	mov    DWORD PTR [r12+0x32c],r14d
     bbf:	mov    r14,QWORD PTR [r12+0x50]
     bc4:	mov    r15,r14
     bc7:	add    r15,0x140
     bce:	mov    rbp,r15
     bd1:	add    rbp,0x10
     bd5:	movdqu xmm2,XMMWORD PTR [r15]
     bda:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     bdf:	movdqa xmm0,xmm2
     be3:	movdqu XMMWORD PTR [r12+0x270],xmm0
     bed:	movdqa xmm0,xmm3
     bf1:	movdqu XMMWORD PTR [r12+0x190],xmm0
     bfb:	mov    r15,r13
     bfe:	add    r15,0xc0
     c05:	mov    r13,r15
     c08:	add    r13,0x10
     c0c:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     c16:	movdqa xmm2,xmm0
     c1a:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     c24:	movdqa xmm3,xmm0
     c28:	movdqu XMMWORD PTR [r15],xmm2
     c2d:	mov    r15d,0x0
     c33:	mov    DWORD PTR [r12+0x32c],r15d
     c3b:	movdqu XMMWORD PTR [r13+0x0],xmm3
     c41:	mov    r13d,0x0
     c47:	mov    DWORD PTR [r12+0x32c],r13d
     c4f:	mov    r13,r14
     c52:	add    r13,0x100
     c59:	mov    r14,r13
     c5c:	add    r14,0x10
     c60:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     c66:	movdqu xmm3,XMMWORD PTR [r14]
     c6b:	movdqa xmm0,xmm2
     c6f:	movdqu XMMWORD PTR [r12+0x110],xmm0
     c79:	movdqa xmm0,xmm3
     c7d:	movdqu XMMWORD PTR [r12+0x300],xmm0
     c87:	mov    r13,QWORD PTR [r12+0xf8]
     c8f:	mov    r14,r13
     c92:	add    r14,0x140
     c99:	mov    r15,QWORD PTR [r12+0xe8]
     ca1:	mov    QWORD PTR [r14],r15
     ca4:	mov    r14d,0x0
     caa:	mov    DWORD PTR [r12+0x32c],r14d
     cb2:	mov    r14,QWORD PTR [r12+0x50]
     cb7:	mov    r15,r14
     cba:	add    r15,0x180
     cc1:	mov    rbp,r15
     cc4:	add    rbp,0x10
     cc8:	movdqu xmm2,XMMWORD PTR [r15]
     ccd:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     cd2:	movdqa xmm0,xmm2
     cd6:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
     ce0:	movdqa xmm0,xmm3
     ce4:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
     cee:	mov    r15,r14
     cf1:	add    r15,0x1c0
     cf8:	mov    rbp,r15
     cfb:	add    rbp,0x10
     cff:	movdqu xmm2,XMMWORD PTR [r15]
     d04:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     d09:	movdqa xmm0,xmm2
     d0d:	movdqu XMMWORD PTR [r12+0x240],xmm0
     d17:	movdqa xmm0,xmm3
     d1b:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
     d25:	mov    r15,r13
     d28:	add    r15,0x20
     d2c:	mov    r13,r15
     d2f:	add    r13,0x10
     d33:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     d3d:	movdqa xmm2,xmm0
     d41:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     d4b:	movdqa xmm3,xmm0
     d4f:	movdqu XMMWORD PTR [r15],xmm2
     d54:	mov    r15d,0x0
     d5a:	mov    DWORD PTR [r12+0x32c],r15d
     d62:	movdqu XMMWORD PTR [r13+0x0],xmm3
     d68:	mov    r13d,0x0
     d6e:	mov    DWORD PTR [r12+0x32c],r13d
     d76:	mov    r13,r14
     d79:	add    r13,0x60
     d7d:	mov    r15,r13
     d80:	add    r15,0x10
     d84:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     d8a:	movdqu xmm3,XMMWORD PTR [r15]
     d8f:	movdqa xmm0,xmm2
     d93:	movdqu XMMWORD PTR [r12+0x110],xmm0
     d9d:	movdqa xmm0,xmm3
     da1:	movdqu XMMWORD PTR [r12+0x120],xmm0
     dab:	mov    r13,r14
     dae:	add    r13,0x20
     db2:	mov    r14,r13
     db5:	add    r14,0x10
     db9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     dbf:	movdqu xmm3,XMMWORD PTR [r14]
     dc4:	movdqa xmm0,xmm2
     dc8:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
     dd2:	movdqa xmm0,xmm3
     dd6:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
     de0:	mov    r13,QWORD PTR [r12+0xf8]
     de8:	mov    r14,r13
     deb:	add    r14,0x60
     def:	mov    r15,r14
     df2:	add    r15,0x10
     df6:	movdqu xmm0,XMMWORD PTR [r12+0x170]
     e00:	movdqa xmm2,xmm0
     e04:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     e0e:	movdqa xmm3,xmm0
     e12:	movdqu XMMWORD PTR [r14],xmm2
     e17:	mov    r14d,0x0
     e1d:	mov    DWORD PTR [r12+0x32c],r14d
     e25:	movdqu XMMWORD PTR [r15],xmm3
     e2a:	mov    r14d,0x0
     e30:	mov    DWORD PTR [r12+0x32c],r14d
     e38:	mov    r14,QWORD PTR [r12+0x50]
     e3d:	mov    r15,r14
     e40:	add    r15,0xe0
     e47:	mov    rbp,r15
     e4a:	add    rbp,0x10
     e4e:	movdqu xmm2,XMMWORD PTR [r15]
     e53:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     e58:	movdqa xmm0,xmm2
     e5c:	movdqu XMMWORD PTR [r12+0x200],xmm0
     e66:	movdqa xmm0,xmm3
     e6a:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
     e74:	mov    r15,r13
     e77:	add    r15,0xa0
     e7e:	mov    r13,r15
     e81:	add    r13,0x10
     e85:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     e8f:	movdqa xmm2,xmm0
     e93:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     e9d:	movdqa xmm3,xmm0
     ea1:	movdqu XMMWORD PTR [r15],xmm2
     ea6:	mov    r15d,0x0
     eac:	mov    DWORD PTR [r12+0x32c],r15d
     eb4:	movdqu XMMWORD PTR [r13+0x0],xmm3
     eba:	mov    r13d,0x0
     ec0:	mov    DWORD PTR [r12+0x32c],r13d
     ec8:	mov    r13,r14
     ecb:	add    r13,0xa0
     ed2:	mov    r15,r13
     ed5:	add    r15,0x10
     ed9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     edf:	movdqu xmm3,XMMWORD PTR [r15]
     ee4:	movdqa xmm0,xmm2
     ee8:	movdqu XMMWORD PTR [r12+0x110],xmm0
     ef2:	movdqa xmm0,xmm3
     ef6:	movdqu XMMWORD PTR [r12+0x120],xmm0
     f00:	mov    r13,r14
     f03:	add    r13,0x120
     f0a:	mov    r15,r13
     f0d:	add    r15,0x10
     f11:	movdqu xmm4,XMMWORD PTR [r13+0x0]
     f17:	movdqu xmm5,XMMWORD PTR [r15]
     f1c:	movdqa xmm0,xmm4
     f20:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
     f2a:	movdqa xmm0,xmm5
     f2e:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
     f38:	mov    r13,r14
     f3b:	add    r13,0x160
     f42:	mov    r14,r13
     f45:	add    r14,0x10
     f49:	movdqu xmm4,XMMWORD PTR [r13+0x0]
     f4f:	movdqu xmm5,XMMWORD PTR [r14]
     f54:	movdqa xmm0,xmm4
     f58:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
     f62:	movdqa xmm0,xmm5
     f66:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
     f70:	mov    r13,QWORD PTR [r12+0xf8]
     f78:	mov    r14,r13
     f7b:	add    r14,0x80
     f82:	mov    r15,r14
     f85:	add    r15,0x10
     f89:	movdqu XMMWORD PTR [r14],xmm3
     f8e:	mov    r14d,0x0
     f94:	mov    DWORD PTR [r12+0x32c],r14d
     f9c:	movdqu XMMWORD PTR [r15],xmm2
     fa1:	mov    r14d,0x0
     fa7:	mov    DWORD PTR [r12+0x32c],r14d
     faf:	mov    r14,QWORD PTR [r12+0x50]
     fb4:	mov    r15,r14
     fb7:	add    r15,0x1a0
     fbe:	mov    rbp,r15
     fc1:	add    rbp,0x10
     fc5:	movdqu xmm2,XMMWORD PTR [r15]
     fca:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     fcf:	movdqa xmm0,xmm2
     fd3:	movdqu XMMWORD PTR [r12+0x290],xmm0
     fdd:	movdqa xmm0,xmm3
     fe1:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
     feb:	mov    r15,r14
     fee:	add    r15,0x1e0
     ff5:	mov    r14,r15
     ff8:	add    r14,0x10
     ffc:	movdqu xmm2,XMMWORD PTR [r15]
    1001:	movdqu xmm3,XMMWORD PTR [r14]
    1006:	movdqa xmm0,xmm2
    100a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    1014:	movdqa xmm0,xmm3
    1018:	movdqu XMMWORD PTR [r12+0x280],xmm0
    1022:	mov    r14d,0x430000
    1028:	mov    QWORD PTR [r12+0x50],r14
    102d:	mov    r14d,0x430000
    1033:	mov    r15,r14
    1036:	add    r15,0x920
    103d:	mov    QWORD PTR [r12+0x50],r15
    1042:	mov    r14,r13
    1045:	add    r14,0x40
    1049:	mov    r15,r14
    104c:	add    r15,0x10
    1050:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    105a:	movdqa xmm5,xmm0
    105e:	movdqu XMMWORD PTR [r14],xmm4
    1063:	mov    r14d,0x0
    1069:	mov    DWORD PTR [r12+0x32c],r14d
    1071:	movdqu XMMWORD PTR [r15],xmm5
    1076:	mov    r14d,0x0
    107c:	mov    DWORD PTR [r12+0x32c],r14d
    1084:	mov    r14,r13
    1087:	add    r14,0x10
    108b:	movdqu XMMWORD PTR [r13+0x0],xmm3
    1091:	mov    r13d,0x0
    1097:	mov    DWORD PTR [r12+0x32c],r13d
    109f:	movdqu XMMWORD PTR [r14],xmm2
    10a4:	mov    r13d,0x0
    10aa:	mov    DWORD PTR [r12+0x32c],r13d
    10b2:	jmp    0x10b7
    10b7:	mov    r13d,0x0
    10bd:	mov    QWORD PTR [r12+0x58],r13
    10c2:	jmp    0x10c7
    10c7:	mov    r13,QWORD PTR [r12+0x58]
    10cc:	mov    r14,QWORD PTR [r12+0x40]
    10d1:	mov    rcx,r13
    10d4:	mov    r15,r14
    10d7:	add    r15,rcx
    10da:	mov    QWORD PTR [r12+0x60],r15
    10df:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    10e9:	movdqa xmm2,xmm0
    10ed:	movdqa xmm0,xmm2
    10f1:	movdqa xmm1,xmm2
    10f5:	por    xmm0,xmm1
    10f9:	movdqa xmm3,xmm0
    10fd:	movdqa xmm0,xmm3
    1101:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    110b:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    1115:	movdqa xmm2,xmm0
    1119:	movdqa xmm0,xmm2
    111d:	movdqa xmm1,xmm2
    1121:	por    xmm0,xmm1
    1125:	movdqa xmm3,xmm0
    1129:	movdqa xmm0,xmm3
    112d:	movdqu XMMWORD PTR [r12+0x120],xmm0
    1137:	mov    r13,r15
    113a:	add    r13,0x30
    113e:	mov    r14,r13
    1141:	add    r14,0x8
    1145:	mov    r15,QWORD PTR [r13+0x0]
    1149:	mov    r13,QWORD PTR [r14]
    114c:	mov    r14d,0x0
    1152:	mov    QWORD PTR [r12+0x130],r15
    115a:	mov    QWORD PTR [r12+0x138],r14
    1162:	mov    r14d,0x0
    1168:	mov    QWORD PTR [r12+0x280],r13
    1170:	mov    QWORD PTR [r12+0x288],r14
    1178:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    1182:	movdqa xmm2,xmm0
    1186:	movdqa xmm0,xmm2
    118a:	movdqa xmm1,xmm2
    118e:	por    xmm0,xmm1
    1192:	movdqa xmm3,xmm0
    1196:	movdqa xmm0,xmm3
    119a:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    11a4:	mov    r13,QWORD PTR [r12+0x60]
    11a9:	mov    r14,r13
    11ac:	add    r14,0x20
    11b0:	mov    r15,r14
    11b3:	add    r15,0x8
    11b7:	mov    rbp,QWORD PTR [r14]
    11ba:	mov    r14,QWORD PTR [r15]
    11bd:	mov    r15d,0x0
    11c3:	mov    QWORD PTR [r12+0x150],rbp
    11cb:	mov    QWORD PTR [r12+0x158],r15
    11d3:	mov    r15d,0x0
    11d9:	mov    QWORD PTR [r12+0x140],r14
    11e1:	mov    QWORD PTR [r12+0x148],r15
    11e9:	mov    r14,r13
    11ec:	add    r14,0x10
    11f0:	mov    r13,r14
    11f3:	add    r13,0x8
    11f7:	mov    r15,QWORD PTR [r14]
    11fa:	mov    r14,QWORD PTR [r13+0x0]
    11fe:	mov    r13d,0x0
    1204:	mov    QWORD PTR [r12+0x170],r15
    120c:	mov    QWORD PTR [r12+0x178],r13
    1214:	mov    r13d,0x0
    121a:	mov    QWORD PTR [r12+0x160],r14
    1222:	mov    QWORD PTR [r12+0x168],r13
    122a:	mov    r13,QWORD PTR [r12+0x60]
    122f:	mov    r14d,0x8
    1235:	mov    r15,QWORD PTR [r13+0x0]
    1239:	mov    QWORD PTR [r12+0x180],r15
    1241:	mov    QWORD PTR [r12+0x188],r15
    1249:	mov    rcx,r14
    124c:	mov    r15,r13
    124f:	add    r15,rcx
    1252:	mov    QWORD PTR [r12+0x60],r15
    1257:	mov    r13,QWORD PTR [r15]
    125a:	mov    r14d,0x0
    1260:	mov    QWORD PTR [r12+0x230],r13
    1268:	mov    QWORD PTR [r12+0x238],r14
    1270:	mov    r13,QWORD PTR [r12+0xf8]
    1278:	mov    r14,r13
    127b:	add    r14,0x50
    127f:	mov    r15,r14
    1282:	add    r15,0x10
    1286:	movdqu xmm2,XMMWORD PTR [r14]
    128b:	movdqu xmm3,XMMWORD PTR [r15]
    1290:	movdqa xmm0,xmm2
    1294:	movdqu XMMWORD PTR [r12+0x220],xmm0
    129e:	movdqa xmm0,xmm3
    12a2:	movdqu XMMWORD PTR [r12+0x210],xmm0
    12ac:	mov    r14,r13
    12af:	add    r14,0x30
    12b3:	movdqu xmm2,XMMWORD PTR [r14]
    12b8:	movdqa xmm0,xmm2
    12bc:	movdqu XMMWORD PTR [r12+0x110],xmm0
    12c6:	mov    r13,QWORD PTR [r12+0x58]
    12cb:	mov    r14,QWORD PTR [r12+0x50]
    12d0:	mov    rcx,r13
    12d3:	mov    r15,r14
    12d6:	add    r15,rcx
    12d9:	mov    QWORD PTR [r12+0x60],r15
    12de:	mov    r14,r13
    12e1:	add    r14,0x40
    12e5:	mov    QWORD PTR [r12+0x58],r14
    12ea:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    12f4:	movdqa xmm2,xmm0
    12f8:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    1302:	movdqa xmm3,xmm0
    1306:	cmp    DWORD PTR [r12+0x310],0x0
    130f:	jne    0x13f3
    1315:	movdqa xmm0,xmm2
    1319:	movdqa xmm1,xmm3
    131d:	movq   rax,xmm0
    1322:	add    rax,rax
    1325:	je     0x133b
    1327:	shr    rax,0x35
    132b:	sub    eax,0x201
    1330:	cmp    eax,0x3fc
    1335:	ja     0x13f3
    133b:	movdqa xmm14,xmm0
    1340:	psrldq xmm14,0x8
    1346:	movq   rax,xmm14
    134b:	add    rax,rax
    134e:	je     0x1364
    1350:	shr    rax,0x35
    1354:	sub    eax,0x201
    1359:	cmp    eax,0x3fc
    135e:	ja     0x13f3
    1364:	movq   rax,xmm1
    1369:	add    rax,rax
    136c:	je     0x1382
    136e:	shr    rax,0x35
    1372:	sub    eax,0x201
    1377:	cmp    eax,0x3fc
    137c:	ja     0x13f3
    1382:	movdqa xmm14,xmm1
    1387:	psrldq xmm14,0x8
    138d:	movq   rax,xmm14
    1392:	add    rax,rax
    1395:	je     0x13ab
    1397:	shr    rax,0x35
    139b:	sub    eax,0x201
    13a0:	cmp    eax,0x3fc
    13a5:	ja     0x13f3
    13ab:	stmxcsr DWORD PTR [rsp+0x100]
    13b3:	mov    DWORD PTR [rsp+0x104],0x1f80
    13be:	ldmxcsr DWORD PTR [rsp+0x104]
    13c6:	mulpd  xmm0,xmm1
    13ca:	stmxcsr DWORD PTR [rsp+0x104]
    13d2:	ldmxcsr DWORD PTR [rsp+0x100]
    13da:	mov    eax,DWORD PTR [rsp+0x104]
    13e1:	shr    eax,1
    13e3:	and    eax,0x10
    13e6:	or     DWORD PTR [r12+0x314],eax
    13ee:	jmp    0x14a0
    13f3:	movdqa xmm0,xmm2
    13f7:	movdqa xmm1,xmm3
    13fb:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1404:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    140d:	mov    QWORD PTR [r12+0x378],0x3
    1419:	movdqu XMMWORD PTR [rsp],xmm2
    141e:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1424:	mov    QWORD PTR [r12+0x108],rbx
    142c:	stmxcsr DWORD PTR [r12-0x28]
    1432:	ldmxcsr DWORD PTR [r12-0x38]
    1438:	lea    rdi,[rsp+0xf0]
    1440:	lea    rsi,[rsp+0xd0]
    1448:	lea    rdx,[rsp+0xe0]
    1450:	mov    ecx,0x16
    1455:	mov    r8d,DWORD PTR [r12+0x310]
    145d:	lea    r9,[r12+0x314]
    1465:	movabs r11,0x5a1b9d18a750
    146f:	call   r11
    1472:	ldmxcsr DWORD PTR [r12-0x28]
    1478:	movdqu xmm2,XMMWORD PTR [rsp]
    147d:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1483:	mov    rbx,QWORD PTR [r12+0x108]
    148b:	mov    QWORD PTR [r12+0x378],0x2
    1497:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    14a0:	movdqa xmm4,xmm0
    14a4:	movdqa xmm0,xmm4
    14a8:	movdqu XMMWORD PTR [r12+0x240],xmm0
    14b2:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    14bc:	movdqa xmm2,xmm0
    14c0:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    14ca:	movdqa xmm3,xmm0
    14ce:	cmp    DWORD PTR [r12+0x310],0x0
    14d7:	jne    0x15c0
    14dd:	movdqa xmm0,xmm2
    14e1:	movdqa xmm1,xmm3
    14e5:	pshufd xmm1,xmm1,0x44
    14ea:	movq   rax,xmm0
    14ef:	add    rax,rax
    14f2:	je     0x1508
    14f4:	shr    rax,0x35
    14f8:	sub    eax,0x201
    14fd:	cmp    eax,0x3fc
    1502:	ja     0x15c0
    1508:	movdqa xmm14,xmm0
    150d:	psrldq xmm14,0x8
    1513:	movq   rax,xmm14
    1518:	add    rax,rax
    151b:	je     0x1531
    151d:	shr    rax,0x35
    1521:	sub    eax,0x201
    1526:	cmp    eax,0x3fc
    152b:	ja     0x15c0
    1531:	movq   rax,xmm1
    1536:	add    rax,rax
    1539:	je     0x154f
    153b:	shr    rax,0x35
    153f:	sub    eax,0x201
    1544:	cmp    eax,0x3fc
    1549:	ja     0x15c0
    154f:	movdqa xmm14,xmm1
    1554:	psrldq xmm14,0x8
    155a:	movq   rax,xmm14
    155f:	add    rax,rax
    1562:	je     0x1578
    1564:	shr    rax,0x35
    1568:	sub    eax,0x201
    156d:	cmp    eax,0x3fc
    1572:	ja     0x15c0
    1578:	stmxcsr DWORD PTR [rsp+0x100]
    1580:	mov    DWORD PTR [rsp+0x104],0x1f80
    158b:	ldmxcsr DWORD PTR [rsp+0x104]
    1593:	mulpd  xmm0,xmm1
    1597:	stmxcsr DWORD PTR [rsp+0x104]
    159f:	ldmxcsr DWORD PTR [rsp+0x100]
    15a7:	mov    eax,DWORD PTR [rsp+0x104]
    15ae:	shr    eax,1
    15b0:	and    eax,0x10
    15b3:	or     DWORD PTR [r12+0x314],eax
    15bb:	jmp    0x166d
    15c0:	movdqa xmm0,xmm2
    15c4:	movdqa xmm1,xmm3
    15c8:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    15d1:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    15da:	mov    QWORD PTR [r12+0x378],0x3
    15e6:	movdqu XMMWORD PTR [rsp],xmm2
    15eb:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    15f1:	mov    QWORD PTR [r12+0x108],rbx
    15f9:	stmxcsr DWORD PTR [r12-0x28]
    15ff:	ldmxcsr DWORD PTR [r12-0x38]
    1605:	lea    rdi,[rsp+0xf0]
    160d:	lea    rsi,[rsp+0xd0]
    1615:	lea    rdx,[rsp+0xe0]
    161d:	mov    ecx,0x56
    1622:	mov    r8d,DWORD PTR [r12+0x310]
    162a:	lea    r9,[r12+0x314]
    1632:	movabs r11,0x5a1b9d18a750
    163c:	call   r11
    163f:	ldmxcsr DWORD PTR [r12-0x28]
    1645:	movdqu xmm2,XMMWORD PTR [rsp]
    164a:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1650:	mov    rbx,QWORD PTR [r12+0x108]
    1658:	mov    QWORD PTR [r12+0x378],0x2
    1664:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    166d:	movdqa xmm4,xmm0
    1671:	movdqa xmm0,xmm4
    1675:	movdqu XMMWORD PTR [r12+0x260],xmm0
    167f:	mov    r13d,0x0
    1685:	mov    r14d,0x0
    168b:	mov    QWORD PTR [r12+0x110],r13
    1693:	mov    QWORD PTR [r12+0x118],r14
    169b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    16a5:	movdqa xmm2,xmm0
    16a9:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    16b3:	movdqa xmm3,xmm0
    16b7:	cmp    DWORD PTR [r12+0x310],0x0
    16c0:	jne    0x17a4
    16c6:	movdqa xmm0,xmm2
    16ca:	movdqa xmm1,xmm3
    16ce:	movq   rax,xmm0
    16d3:	add    rax,rax
    16d6:	je     0x16ec
    16d8:	shr    rax,0x35
    16dc:	sub    eax,0x201
    16e1:	cmp    eax,0x3fc
    16e6:	ja     0x17a4
    16ec:	movdqa xmm14,xmm0
    16f1:	psrldq xmm14,0x8
    16f7:	movq   rax,xmm14
    16fc:	add    rax,rax
    16ff:	je     0x1715
    1701:	shr    rax,0x35
    1705:	sub    eax,0x201
    170a:	cmp    eax,0x3fc
    170f:	ja     0x17a4
    1715:	movq   rax,xmm1
    171a:	add    rax,rax
    171d:	je     0x1733
    171f:	shr    rax,0x35
    1723:	sub    eax,0x201
    1728:	cmp    eax,0x3fc
    172d:	ja     0x17a4
    1733:	movdqa xmm14,xmm1
    1738:	psrldq xmm14,0x8
    173e:	movq   rax,xmm14
    1743:	add    rax,rax
    1746:	je     0x175c
    1748:	shr    rax,0x35
    174c:	sub    eax,0x201
    1751:	cmp    eax,0x3fc
    1756:	ja     0x17a4
    175c:	stmxcsr DWORD PTR [rsp+0x100]
    1764:	mov    DWORD PTR [rsp+0x104],0x1f80
    176f:	ldmxcsr DWORD PTR [rsp+0x104]
    1777:	mulpd  xmm0,xmm1
    177b:	stmxcsr DWORD PTR [rsp+0x104]
    1783:	ldmxcsr DWORD PTR [rsp+0x100]
    178b:	mov    eax,DWORD PTR [rsp+0x104]
    1792:	shr    eax,1
    1794:	and    eax,0x10
    1797:	or     DWORD PTR [r12+0x314],eax
    179f:	jmp    0x1851
    17a4:	movdqa xmm0,xmm2
    17a8:	movdqa xmm1,xmm3
    17ac:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    17b5:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    17be:	mov    QWORD PTR [r12+0x378],0x3
    17ca:	movdqu XMMWORD PTR [rsp],xmm2
    17cf:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    17d5:	mov    QWORD PTR [r12+0x108],rbx
    17dd:	stmxcsr DWORD PTR [r12-0x28]
    17e3:	ldmxcsr DWORD PTR [r12-0x38]
    17e9:	lea    rdi,[rsp+0xf0]
    17f1:	lea    rsi,[rsp+0xd0]
    17f9:	lea    rdx,[rsp+0xe0]
    1801:	mov    ecx,0x16
    1806:	mov    r8d,DWORD PTR [r12+0x310]
    180e:	lea    r9,[r12+0x314]
    1816:	movabs r11,0x5a1b9d18a750
    1820:	call   r11
    1823:	ldmxcsr DWORD PTR [r12-0x28]
    1829:	movdqu xmm2,XMMWORD PTR [rsp]
    182e:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1834:	mov    rbx,QWORD PTR [r12+0x108]
    183c:	mov    QWORD PTR [r12+0x378],0x2
    1848:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1851:	movdqa xmm4,xmm0
    1855:	movdqa xmm0,xmm4
    1859:	movdqu XMMWORD PTR [r12+0x210],xmm0
    1863:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    186d:	movdqa xmm2,xmm0
    1871:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    187b:	movdqa xmm3,xmm0
    187f:	cmp    DWORD PTR [r12+0x310],0x0
    1888:	jne    0x196c
    188e:	movdqa xmm0,xmm2
    1892:	movdqa xmm1,xmm3
    1896:	movq   rax,xmm0
    189b:	add    rax,rax
    189e:	je     0x18b4
    18a0:	shr    rax,0x35
    18a4:	sub    eax,0x201
    18a9:	cmp    eax,0x3fc
    18ae:	ja     0x196c
    18b4:	movdqa xmm14,xmm0
    18b9:	psrldq xmm14,0x8
    18bf:	movq   rax,xmm14
    18c4:	add    rax,rax
    18c7:	je     0x18dd
    18c9:	shr    rax,0x35
    18cd:	sub    eax,0x201
    18d2:	cmp    eax,0x3fc
    18d7:	ja     0x196c
    18dd:	movq   rax,xmm1
    18e2:	add    rax,rax
    18e5:	je     0x18fb
    18e7:	shr    rax,0x35
    18eb:	sub    eax,0x201
    18f0:	cmp    eax,0x3fc
    18f5:	ja     0x196c
    18fb:	movdqa xmm14,xmm1
    1900:	psrldq xmm14,0x8
    1906:	movq   rax,xmm14
    190b:	add    rax,rax
    190e:	je     0x1924
    1910:	shr    rax,0x35
    1914:	sub    eax,0x201
    1919:	cmp    eax,0x3fc
    191e:	ja     0x196c
    1924:	stmxcsr DWORD PTR [rsp+0x100]
    192c:	mov    DWORD PTR [rsp+0x104],0x1f80
    1937:	ldmxcsr DWORD PTR [rsp+0x104]
    193f:	mulpd  xmm0,xmm1
    1943:	stmxcsr DWORD PTR [rsp+0x104]
    194b:	ldmxcsr DWORD PTR [rsp+0x100]
    1953:	mov    eax,DWORD PTR [rsp+0x104]
    195a:	shr    eax,1
    195c:	and    eax,0x10
    195f:	or     DWORD PTR [r12+0x314],eax
    1967:	jmp    0x1a19
    196c:	movdqa xmm0,xmm2
    1970:	movdqa xmm1,xmm3
    1974:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    197d:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1986:	mov    QWORD PTR [r12+0x378],0x3
    1992:	movdqu XMMWORD PTR [rsp],xmm2
    1997:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    199d:	mov    QWORD PTR [r12+0x108],rbx
    19a5:	stmxcsr DWORD PTR [r12-0x28]
    19ab:	ldmxcsr DWORD PTR [r12-0x38]
    19b1:	lea    rdi,[rsp+0xf0]
    19b9:	lea    rsi,[rsp+0xd0]
    19c1:	lea    rdx,[rsp+0xe0]
    19c9:	mov    ecx,0x16
    19ce:	mov    r8d,DWORD PTR [r12+0x310]
    19d6:	lea    r9,[r12+0x314]
    19de:	movabs r11,0x5a1b9d18a750
    19e8:	call   r11
    19eb:	ldmxcsr DWORD PTR [r12-0x28]
    19f1:	movdqu xmm2,XMMWORD PTR [rsp]
    19f6:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    19fc:	mov    rbx,QWORD PTR [r12+0x108]
    1a04:	mov    QWORD PTR [r12+0x378],0x2
    1a10:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1a19:	movdqa xmm4,xmm0
    1a1d:	movdqa xmm0,xmm4
    1a21:	movdqu XMMWORD PTR [r12+0x220],xmm0
    1a2b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    1a35:	movdqa xmm2,xmm0
    1a39:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    1a43:	movdqa xmm3,xmm0
    1a47:	cmp    DWORD PTR [r12+0x310],0x0
    1a50:	jne    0x1b34
    1a56:	movdqa xmm0,xmm2
    1a5a:	movdqa xmm1,xmm3
    1a5e:	movq   rax,xmm0
    1a63:	add    rax,rax
    1a66:	je     0x1a7c
    1a68:	shr    rax,0x35
    1a6c:	sub    eax,0x201
    1a71:	cmp    eax,0x3fc
    1a76:	ja     0x1b34
    1a7c:	movdqa xmm14,xmm0
    1a81:	psrldq xmm14,0x8
    1a87:	movq   rax,xmm14
    1a8c:	add    rax,rax
    1a8f:	je     0x1aa5
    1a91:	shr    rax,0x35
    1a95:	sub    eax,0x201
    1a9a:	cmp    eax,0x3fc
    1a9f:	ja     0x1b34
    1aa5:	movq   rax,xmm1
    1aaa:	add    rax,rax
    1aad:	je     0x1ac3
    1aaf:	shr    rax,0x35
    1ab3:	sub    eax,0x201
    1ab8:	cmp    eax,0x3fc
    1abd:	ja     0x1b34
    1ac3:	movdqa xmm14,xmm1
    1ac8:	psrldq xmm14,0x8
    1ace:	movq   rax,xmm14
    1ad3:	add    rax,rax
    1ad6:	je     0x1aec
    1ad8:	shr    rax,0x35
    1adc:	sub    eax,0x201
    1ae1:	cmp    eax,0x3fc
    1ae6:	ja     0x1b34
    1aec:	stmxcsr DWORD PTR [rsp+0x100]
    1af4:	mov    DWORD PTR [rsp+0x104],0x1f80
    1aff:	ldmxcsr DWORD PTR [rsp+0x104]
    1b07:	mulpd  xmm0,xmm1
    1b0b:	stmxcsr DWORD PTR [rsp+0x104]
    1b13:	ldmxcsr DWORD PTR [rsp+0x100]
    1b1b:	mov    eax,DWORD PTR [rsp+0x104]
    1b22:	shr    eax,1
    1b24:	and    eax,0x10
    1b27:	or     DWORD PTR [r12+0x314],eax
    1b2f:	jmp    0x1be1
    1b34:	movdqa xmm0,xmm2
    1b38:	movdqa xmm1,xmm3
    1b3c:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1b45:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1b4e:	mov    QWORD PTR [r12+0x378],0x3
    1b5a:	movdqu XMMWORD PTR [rsp],xmm2
    1b5f:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1b65:	mov    QWORD PTR [r12+0x108],rbx
    1b6d:	stmxcsr DWORD PTR [r12-0x28]
    1b73:	ldmxcsr DWORD PTR [r12-0x38]
    1b79:	lea    rdi,[rsp+0xf0]
    1b81:	lea    rsi,[rsp+0xd0]
    1b89:	lea    rdx,[rsp+0xe0]
    1b91:	mov    ecx,0x16
    1b96:	mov    r8d,DWORD PTR [r12+0x310]
    1b9e:	lea    r9,[r12+0x314]
    1ba6:	movabs r11,0x5a1b9d18a750
    1bb0:	call   r11
    1bb3:	ldmxcsr DWORD PTR [r12-0x28]
    1bb9:	movdqu xmm2,XMMWORD PTR [rsp]
    1bbe:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1bc4:	mov    rbx,QWORD PTR [r12+0x108]
    1bcc:	mov    QWORD PTR [r12+0x378],0x2
    1bd8:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1be1:	movdqa xmm4,xmm0
    1be5:	movdqa xmm0,xmm4
    1be9:	movdqu XMMWORD PTR [r12+0x180],xmm0
    1bf3:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    1bfd:	movdqa xmm2,xmm0
    1c01:	movdqa xmm0,xmm2
    1c05:	movdqa xmm1,xmm2
    1c09:	por    xmm0,xmm1
    1c0d:	movdqa xmm3,xmm0
    1c11:	movdqa xmm0,xmm3
    1c15:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    1c1f:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    1c29:	movdqa xmm2,xmm0
    1c2d:	movdqa xmm0,xmm2
    1c31:	movdqa xmm1,xmm2
    1c35:	por    xmm0,xmm1
    1c39:	movdqa xmm3,xmm0
    1c3d:	movdqa xmm0,xmm3
    1c41:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    1c4b:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1c55:	movdqa xmm3,xmm0
    1c59:	cmp    DWORD PTR [r12+0x310],0x0
    1c62:	jne    0x1d4b
    1c68:	movdqa xmm0,xmm2
    1c6c:	movdqa xmm1,xmm3
    1c70:	pshufd xmm1,xmm1,0x44
    1c75:	movq   rax,xmm0
    1c7a:	add    rax,rax
    1c7d:	je     0x1c93
    1c7f:	shr    rax,0x35
    1c83:	sub    eax,0x201
    1c88:	cmp    eax,0x3fc
    1c8d:	ja     0x1d4b
    1c93:	movdqa xmm14,xmm0
    1c98:	psrldq xmm14,0x8
    1c9e:	movq   rax,xmm14
    1ca3:	add    rax,rax
    1ca6:	je     0x1cbc
    1ca8:	shr    rax,0x35
    1cac:	sub    eax,0x201
    1cb1:	cmp    eax,0x3fc
    1cb6:	ja     0x1d4b
    1cbc:	movq   rax,xmm1
    1cc1:	add    rax,rax
    1cc4:	je     0x1cda
    1cc6:	shr    rax,0x35
    1cca:	sub    eax,0x201
    1ccf:	cmp    eax,0x3fc
    1cd4:	ja     0x1d4b
    1cda:	movdqa xmm14,xmm1
    1cdf:	psrldq xmm14,0x8
    1ce5:	movq   rax,xmm14
    1cea:	add    rax,rax
    1ced:	je     0x1d03
    1cef:	shr    rax,0x35
    1cf3:	sub    eax,0x201
    1cf8:	cmp    eax,0x3fc
    1cfd:	ja     0x1d4b
    1d03:	stmxcsr DWORD PTR [rsp+0x100]
    1d0b:	mov    DWORD PTR [rsp+0x104],0x1f80
    1d16:	ldmxcsr DWORD PTR [rsp+0x104]
    1d1e:	mulpd  xmm0,xmm1
    1d22:	stmxcsr DWORD PTR [rsp+0x104]
    1d2a:	ldmxcsr DWORD PTR [rsp+0x100]
    1d32:	mov    eax,DWORD PTR [rsp+0x104]
    1d39:	shr    eax,1
    1d3b:	and    eax,0x10
    1d3e:	or     DWORD PTR [r12+0x314],eax
    1d46:	jmp    0x1df8
    1d4b:	movdqa xmm0,xmm2
    1d4f:	movdqa xmm1,xmm3
    1d53:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1d5c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1d65:	mov    QWORD PTR [r12+0x378],0x3
    1d71:	movdqu XMMWORD PTR [rsp],xmm2
    1d76:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1d7c:	mov    QWORD PTR [r12+0x108],rbx
    1d84:	stmxcsr DWORD PTR [r12-0x28]
    1d8a:	ldmxcsr DWORD PTR [r12-0x38]
    1d90:	lea    rdi,[rsp+0xf0]
    1d98:	lea    rsi,[rsp+0xd0]
    1da0:	lea    rdx,[rsp+0xe0]
    1da8:	mov    ecx,0x56
    1dad:	mov    r8d,DWORD PTR [r12+0x310]
    1db5:	lea    r9,[r12+0x314]
    1dbd:	movabs r11,0x5a1b9d18a750
    1dc7:	call   r11
    1dca:	ldmxcsr DWORD PTR [r12-0x28]
    1dd0:	movdqu xmm2,XMMWORD PTR [rsp]
    1dd5:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1ddb:	mov    rbx,QWORD PTR [r12+0x108]
    1de3:	mov    QWORD PTR [r12+0x378],0x2
    1def:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1df8:	movdqa xmm4,xmm0
    1dfc:	movdqa xmm0,xmm4
    1e00:	movdqu XMMWORD PTR [r12+0x250],xmm0
    1e0a:	mov    r13,QWORD PTR [r12+0x58]
    1e0f:	mov    r14,r13
    1e12:	sub    r14,0x200
    1e19:	pushf
    1e1a:	pop    rdx
    1e1b:	mov    r10d,edx
    1e1e:	and    r10d,0xc0
    1e25:	shl    r10d,0x18
    1e29:	mov    r11d,edx
    1e2c:	and    r11d,0x1
    1e30:	shl    r11d,0x1d
    1e34:	or     r10d,r11d
    1e37:	mov    r11d,edx
    1e3a:	and    r11d,0x800
    1e41:	shl    r11d,0x11
    1e45:	or     r10d,r11d
    1e48:	mov    r11d,0xf0000000
    1e4e:	and    r11,r10
    1e51:	movabs rsi,0xffffffff0fffffff
    1e5b:	and    rbx,rsi
    1e5e:	or     rbx,r11
    1e61:	btc    rbx,0x1d
    1e66:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1e70:	movdqa xmm2,xmm0
    1e74:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    1e7e:	movdqa xmm3,xmm0
    1e82:	cmp    DWORD PTR [r12+0x310],0x0
    1e8b:	jne    0x1f6f
    1e91:	movdqa xmm0,xmm2
    1e95:	movdqa xmm1,xmm3
    1e99:	movq   rax,xmm0
    1e9e:	add    rax,rax
    1ea1:	je     0x1eb7
    1ea3:	shr    rax,0x35
    1ea7:	sub    eax,0x201
    1eac:	cmp    eax,0x3fc
    1eb1:	ja     0x1f6f
    1eb7:	movdqa xmm14,xmm0
    1ebc:	psrldq xmm14,0x8
    1ec2:	movq   rax,xmm14
    1ec7:	add    rax,rax
    1eca:	je     0x1ee0
    1ecc:	shr    rax,0x35
    1ed0:	sub    eax,0x201
    1ed5:	cmp    eax,0x3fc
    1eda:	ja     0x1f6f
    1ee0:	movq   rax,xmm1
    1ee5:	add    rax,rax
    1ee8:	je     0x1efe
    1eea:	shr    rax,0x35
    1eee:	sub    eax,0x201
    1ef3:	cmp    eax,0x3fc
    1ef8:	ja     0x1f6f
    1efe:	movdqa xmm14,xmm1
    1f03:	psrldq xmm14,0x8
    1f09:	movq   rax,xmm14
    1f0e:	add    rax,rax
    1f11:	je     0x1f27
    1f13:	shr    rax,0x35
    1f17:	sub    eax,0x201
    1f1c:	cmp    eax,0x3fc
    1f21:	ja     0x1f6f
    1f27:	stmxcsr DWORD PTR [rsp+0x100]
    1f2f:	mov    DWORD PTR [rsp+0x104],0x1f80
    1f3a:	ldmxcsr DWORD PTR [rsp+0x104]
    1f42:	addpd  xmm0,xmm1
    1f46:	stmxcsr DWORD PTR [rsp+0x104]
    1f4e:	ldmxcsr DWORD PTR [rsp+0x100]
    1f56:	mov    eax,DWORD PTR [rsp+0x104]
    1f5d:	shr    eax,1
    1f5f:	and    eax,0x10
    1f62:	or     DWORD PTR [r12+0x314],eax
    1f6a:	jmp    0x201c
    1f6f:	movdqa xmm0,xmm2
    1f73:	movdqa xmm1,xmm3
    1f77:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1f80:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1f89:	mov    QWORD PTR [r12+0x378],0x3
    1f95:	movdqu XMMWORD PTR [rsp],xmm2
    1f9a:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1fa0:	mov    QWORD PTR [r12+0x108],rbx
    1fa8:	stmxcsr DWORD PTR [r12-0x28]
    1fae:	ldmxcsr DWORD PTR [r12-0x38]
    1fb4:	lea    rdi,[rsp+0xf0]
    1fbc:	lea    rsi,[rsp+0xd0]
    1fc4:	lea    rdx,[rsp+0xe0]
    1fcc:	mov    ecx,0x14
    1fd1:	mov    r8d,DWORD PTR [r12+0x310]
    1fd9:	lea    r9,[r12+0x314]
    1fe1:	movabs r11,0x5a1b9d18a750
    1feb:	call   r11
    1fee:	ldmxcsr DWORD PTR [r12-0x28]
    1ff4:	movdqu xmm2,XMMWORD PTR [rsp]
    1ff9:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1fff:	mov    rbx,QWORD PTR [r12+0x108]
    2007:	mov    QWORD PTR [r12+0x378],0x2
    2013:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    201c:	movdqa xmm4,xmm0
    2020:	movdqa xmm0,xmm4
    2024:	movdqu XMMWORD PTR [r12+0x240],xmm0
    202e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    2038:	movdqa xmm2,xmm0
    203c:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    2046:	movdqa xmm3,xmm0
    204a:	cmp    DWORD PTR [r12+0x310],0x0
    2053:	jne    0x2137
    2059:	movdqa xmm0,xmm2
    205d:	movdqa xmm1,xmm3
    2061:	movq   rax,xmm0
    2066:	add    rax,rax
    2069:	je     0x207f
    206b:	shr    rax,0x35
    206f:	sub    eax,0x201
    2074:	cmp    eax,0x3fc
    2079:	ja     0x2137
    207f:	movdqa xmm14,xmm0
    2084:	psrldq xmm14,0x8
    208a:	movq   rax,xmm14
    208f:	add    rax,rax
    2092:	je     0x20a8
    2094:	shr    rax,0x35
    2098:	sub    eax,0x201
    209d:	cmp    eax,0x3fc
    20a2:	ja     0x2137
    20a8:	movq   rax,xmm1
    20ad:	add    rax,rax
    20b0:	je     0x20c6
    20b2:	shr    rax,0x35
    20b6:	sub    eax,0x201
    20bb:	cmp    eax,0x3fc
    20c0:	ja     0x2137
    20c6:	movdqa xmm14,xmm1
    20cb:	psrldq xmm14,0x8
    20d1:	movq   rax,xmm14
    20d6:	add    rax,rax
    20d9:	je     0x20ef
    20db:	shr    rax,0x35
    20df:	sub    eax,0x201
    20e4:	cmp    eax,0x3fc
    20e9:	ja     0x2137
    20ef:	stmxcsr DWORD PTR [rsp+0x100]
    20f7:	mov    DWORD PTR [rsp+0x104],0x1f80
    2102:	ldmxcsr DWORD PTR [rsp+0x104]
    210a:	addpd  xmm0,xmm1
    210e:	stmxcsr DWORD PTR [rsp+0x104]
    2116:	ldmxcsr DWORD PTR [rsp+0x100]
    211e:	mov    eax,DWORD PTR [rsp+0x104]
    2125:	shr    eax,1
    2127:	and    eax,0x10
    212a:	or     DWORD PTR [r12+0x314],eax
    2132:	jmp    0x21e4
    2137:	movdqa xmm0,xmm2
    213b:	movdqa xmm1,xmm3
    213f:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2148:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2151:	mov    QWORD PTR [r12+0x378],0x3
    215d:	movdqu XMMWORD PTR [rsp],xmm2
    2162:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2168:	mov    QWORD PTR [r12+0x108],rbx
    2170:	stmxcsr DWORD PTR [r12-0x28]
    2176:	ldmxcsr DWORD PTR [r12-0x38]
    217c:	lea    rdi,[rsp+0xf0]
    2184:	lea    rsi,[rsp+0xd0]
    218c:	lea    rdx,[rsp+0xe0]
    2194:	mov    ecx,0x14
    2199:	mov    r8d,DWORD PTR [r12+0x310]
    21a1:	lea    r9,[r12+0x314]
    21a9:	movabs r11,0x5a1b9d18a750
    21b3:	call   r11
    21b6:	ldmxcsr DWORD PTR [r12-0x28]
    21bc:	movdqu xmm2,XMMWORD PTR [rsp]
    21c1:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    21c7:	mov    rbx,QWORD PTR [r12+0x108]
    21cf:	mov    QWORD PTR [r12+0x378],0x2
    21db:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    21e4:	movdqa xmm4,xmm0
    21e8:	movdqa xmm0,xmm4
    21ec:	movdqu XMMWORD PTR [r12+0x210],xmm0
    21f6:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    2200:	movdqa xmm2,xmm0
    2204:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    220e:	movdqa xmm3,xmm0
    2212:	cmp    DWORD PTR [r12+0x310],0x0
    221b:	jne    0x22ff
    2221:	movdqa xmm0,xmm2
    2225:	movdqa xmm1,xmm3
    2229:	movq   rax,xmm0
    222e:	add    rax,rax
    2231:	je     0x2247
    2233:	shr    rax,0x35
    2237:	sub    eax,0x201
    223c:	cmp    eax,0x3fc
    2241:	ja     0x22ff
    2247:	movdqa xmm14,xmm0
    224c:	psrldq xmm14,0x8
    2252:	movq   rax,xmm14
    2257:	add    rax,rax
    225a:	je     0x2270
    225c:	shr    rax,0x35
    2260:	sub    eax,0x201
    2265:	cmp    eax,0x3fc
    226a:	ja     0x22ff
    2270:	movq   rax,xmm1
    2275:	add    rax,rax
    2278:	je     0x228e
    227a:	shr    rax,0x35
    227e:	sub    eax,0x201
    2283:	cmp    eax,0x3fc
    2288:	ja     0x22ff
    228e:	movdqa xmm14,xmm1
    2293:	psrldq xmm14,0x8
    2299:	movq   rax,xmm14
    229e:	add    rax,rax
    22a1:	je     0x22b7
    22a3:	shr    rax,0x35
    22a7:	sub    eax,0x201
    22ac:	cmp    eax,0x3fc
    22b1:	ja     0x22ff
    22b7:	stmxcsr DWORD PTR [rsp+0x100]
    22bf:	mov    DWORD PTR [rsp+0x104],0x1f80
    22ca:	ldmxcsr DWORD PTR [rsp+0x104]
    22d2:	addpd  xmm0,xmm1
    22d6:	stmxcsr DWORD PTR [rsp+0x104]
    22de:	ldmxcsr DWORD PTR [rsp+0x100]
    22e6:	mov    eax,DWORD PTR [rsp+0x104]
    22ed:	shr    eax,1
    22ef:	and    eax,0x10
    22f2:	or     DWORD PTR [r12+0x314],eax
    22fa:	jmp    0x23ac
    22ff:	movdqa xmm0,xmm2
    2303:	movdqa xmm1,xmm3
    2307:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2310:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2319:	mov    QWORD PTR [r12+0x378],0x3
    2325:	movdqu XMMWORD PTR [rsp],xmm2
    232a:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2330:	mov    QWORD PTR [r12+0x108],rbx
    2338:	stmxcsr DWORD PTR [r12-0x28]
    233e:	ldmxcsr DWORD PTR [r12-0x38]
    2344:	lea    rdi,[rsp+0xf0]
    234c:	lea    rsi,[rsp+0xd0]
    2354:	lea    rdx,[rsp+0xe0]
    235c:	mov    ecx,0x14
    2361:	mov    r8d,DWORD PTR [r12+0x310]
    2369:	lea    r9,[r12+0x314]
    2371:	movabs r11,0x5a1b9d18a750
    237b:	call   r11
    237e:	ldmxcsr DWORD PTR [r12-0x28]
    2384:	movdqu xmm2,XMMWORD PTR [rsp]
    2389:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    238f:	mov    rbx,QWORD PTR [r12+0x108]
    2397:	mov    QWORD PTR [r12+0x378],0x2
    23a3:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    23ac:	movdqa xmm4,xmm0
    23b0:	movdqa xmm0,xmm4
    23b4:	movdqu XMMWORD PTR [r12+0x220],xmm0
    23be:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    23c8:	movdqa xmm2,xmm0
    23cc:	movdqa xmm0,xmm2
    23d0:	movdqa xmm1,xmm2
    23d4:	por    xmm0,xmm1
    23d8:	movdqa xmm3,xmm0
    23dc:	movdqa xmm0,xmm3
    23e0:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    23ea:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    23f4:	movdqa xmm2,xmm0
    23f8:	movdqa xmm0,xmm2
    23fc:	movdqa xmm1,xmm2
    2400:	por    xmm0,xmm1
    2404:	movdqa xmm3,xmm0
    2408:	movdqa xmm0,xmm3
    240c:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    2416:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    2420:	movdqa xmm2,xmm0
    2424:	movdqa xmm0,xmm2
    2428:	movdqa xmm1,xmm2
    242c:	por    xmm0,xmm1
    2430:	movdqa xmm3,xmm0
    2434:	movdqa xmm0,xmm3
    2438:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    2442:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    244c:	movdqa xmm2,xmm0
    2450:	movdqa xmm0,xmm2
    2454:	movdqa xmm1,xmm2
    2458:	por    xmm0,xmm1
    245c:	movdqa xmm3,xmm0
    2460:	movdqa xmm0,xmm3
    2464:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    246e:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    2478:	movdqa xmm2,xmm0
    247c:	movdqa xmm0,xmm2
    2480:	movdqa xmm1,xmm2
    2484:	por    xmm0,xmm1
    2488:	movdqa xmm3,xmm0
    248c:	movdqa xmm0,xmm3
    2490:	movdqu XMMWORD PTR [r12+0x200],xmm0
    249a:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    24a4:	movdqa xmm2,xmm0
    24a8:	movdqa xmm0,xmm2
    24ac:	movdqa xmm1,xmm2
    24b0:	por    xmm0,xmm1
    24b4:	movdqa xmm3,xmm0
    24b8:	movdqa xmm0,xmm3
    24bc:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    24c6:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    24d0:	movdqa xmm2,xmm0
    24d4:	movdqa xmm0,xmm2
    24d8:	movdqa xmm1,xmm2
    24dc:	por    xmm0,xmm1
    24e0:	movdqa xmm3,xmm0
    24e4:	movdqa xmm0,xmm3
    24e8:	movdqu XMMWORD PTR [r12+0x190],xmm0
    24f2:	mov    r13,QWORD PTR [r12+0xf8]
    24fa:	mov    r14,r13
    24fd:	add    r14,0xa0
    2504:	mov    r13,r14
    2507:	add    r13,0x10
    250b:	movdqu xmm2,XMMWORD PTR [r14]
    2510:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    2516:	movdqa xmm0,xmm2
    251a:	movdqu XMMWORD PTR [r12+0x300],xmm0
    2524:	movdqa xmm0,xmm3
    2528:	movdqu XMMWORD PTR [r12+0x270],xmm0
    2532:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    253c:	movdqa xmm2,xmm0
    2540:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    254a:	movdqa xmm3,xmm0
    254e:	cmp    DWORD PTR [r12+0x310],0x0
    2557:	jne    0x263b
    255d:	movdqa xmm0,xmm2
    2561:	movdqa xmm1,xmm3
    2565:	movq   rax,xmm0
    256a:	add    rax,rax
    256d:	je     0x2583
    256f:	shr    rax,0x35
    2573:	sub    eax,0x201
    2578:	cmp    eax,0x3fc
    257d:	ja     0x263b
    2583:	movdqa xmm14,xmm0
    2588:	psrldq xmm14,0x8
    258e:	movq   rax,xmm14
    2593:	add    rax,rax
    2596:	je     0x25ac
    2598:	shr    rax,0x35
    259c:	sub    eax,0x201
    25a1:	cmp    eax,0x3fc
    25a6:	ja     0x263b
    25ac:	movq   rax,xmm1
    25b1:	add    rax,rax
    25b4:	je     0x25ca
    25b6:	shr    rax,0x35
    25ba:	sub    eax,0x201
    25bf:	cmp    eax,0x3fc
    25c4:	ja     0x263b
    25ca:	movdqa xmm14,xmm1
    25cf:	psrldq xmm14,0x8
    25d5:	movq   rax,xmm14
    25da:	add    rax,rax
    25dd:	je     0x25f3
    25df:	shr    rax,0x35
    25e3:	sub    eax,0x201
    25e8:	cmp    eax,0x3fc
    25ed:	ja     0x263b
    25f3:	stmxcsr DWORD PTR [rsp+0x100]
    25fb:	mov    DWORD PTR [rsp+0x104],0x1f80
    2606:	ldmxcsr DWORD PTR [rsp+0x104]
    260e:	addpd  xmm0,xmm1
    2612:	stmxcsr DWORD PTR [rsp+0x104]
    261a:	ldmxcsr DWORD PTR [rsp+0x100]
    2622:	mov    eax,DWORD PTR [rsp+0x104]
    2629:	shr    eax,1
    262b:	and    eax,0x10
    262e:	or     DWORD PTR [r12+0x314],eax
    2636:	jmp    0x26e8
    263b:	movdqa xmm0,xmm2
    263f:	movdqa xmm1,xmm3
    2643:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    264c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2655:	mov    QWORD PTR [r12+0x378],0x3
    2661:	movdqu XMMWORD PTR [rsp],xmm2
    2666:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    266c:	mov    QWORD PTR [r12+0x108],rbx
    2674:	stmxcsr DWORD PTR [r12-0x28]
    267a:	ldmxcsr DWORD PTR [r12-0x38]
    2680:	lea    rdi,[rsp+0xf0]
    2688:	lea    rsi,[rsp+0xd0]
    2690:	lea    rdx,[rsp+0xe0]
    2698:	mov    ecx,0x14
    269d:	mov    r8d,DWORD PTR [r12+0x310]
    26a5:	lea    r9,[r12+0x314]
    26ad:	movabs r11,0x5a1b9d18a750
    26b7:	call   r11
    26ba:	ldmxcsr DWORD PTR [r12-0x28]
    26c0:	movdqu xmm2,XMMWORD PTR [rsp]
    26c5:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    26cb:	mov    rbx,QWORD PTR [r12+0x108]
    26d3:	mov    QWORD PTR [r12+0x378],0x2
    26df:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    26e8:	movdqa xmm4,xmm0
    26ec:	movdqa xmm0,xmm4
    26f0:	movdqu XMMWORD PTR [r12+0x180],xmm0
    26fa:	mov    r13,QWORD PTR [r12+0xf8]
    2702:	mov    r14,r13
    2705:	add    r14,0xf0
    270c:	movdqu xmm2,XMMWORD PTR [r14]
    2711:	movdqa xmm0,xmm2
    2715:	movdqu XMMWORD PTR [r12+0x110],xmm0
    271f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    2729:	movdqa xmm2,xmm0
    272d:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    2737:	movdqa xmm3,xmm0
    273b:	cmp    DWORD PTR [r12+0x310],0x0
    2744:	jne    0x2828
    274a:	movdqa xmm0,xmm2
    274e:	movdqa xmm1,xmm3
    2752:	movq   rax,xmm0
    2757:	add    rax,rax
    275a:	je     0x2770
    275c:	shr    rax,0x35
    2760:	sub    eax,0x201
    2765:	cmp    eax,0x3fc
    276a:	ja     0x2828
    2770:	movdqa xmm14,xmm0
    2775:	psrldq xmm14,0x8
    277b:	movq   rax,xmm14
    2780:	add    rax,rax
    2783:	je     0x2799
    2785:	shr    rax,0x35
    2789:	sub    eax,0x201
    278e:	cmp    eax,0x3fc
    2793:	ja     0x2828
    2799:	movq   rax,xmm1
    279e:	add    rax,rax
    27a1:	je     0x27b7
    27a3:	shr    rax,0x35
    27a7:	sub    eax,0x201
    27ac:	cmp    eax,0x3fc
    27b1:	ja     0x2828
    27b7:	movdqa xmm14,xmm1
    27bc:	psrldq xmm14,0x8
    27c2:	movq   rax,xmm14
    27c7:	add    rax,rax
    27ca:	je     0x27e0
    27cc:	shr    rax,0x35
    27d0:	sub    eax,0x201
    27d5:	cmp    eax,0x3fc
    27da:	ja     0x2828
    27e0:	stmxcsr DWORD PTR [rsp+0x100]
    27e8:	mov    DWORD PTR [rsp+0x104],0x1f80
    27f3:	ldmxcsr DWORD PTR [rsp+0x104]
    27fb:	addpd  xmm0,xmm1
    27ff:	stmxcsr DWORD PTR [rsp+0x104]
    2807:	ldmxcsr DWORD PTR [rsp+0x100]
    280f:	mov    eax,DWORD PTR [rsp+0x104]
    2816:	shr    eax,1
    2818:	and    eax,0x10
    281b:	or     DWORD PTR [r12+0x314],eax
    2823:	jmp    0x28d5
    2828:	movdqa xmm0,xmm2
    282c:	movdqa xmm1,xmm3
    2830:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2839:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2842:	mov    QWORD PTR [r12+0x378],0x3
    284e:	movdqu XMMWORD PTR [rsp],xmm2
    2853:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2859:	mov    QWORD PTR [r12+0x108],rbx
    2861:	stmxcsr DWORD PTR [r12-0x28]
    2867:	ldmxcsr DWORD PTR [r12-0x38]
    286d:	lea    rdi,[rsp+0xf0]
    2875:	lea    rsi,[rsp+0xd0]
    287d:	lea    rdx,[rsp+0xe0]
    2885:	mov    ecx,0x14
    288a:	mov    r8d,DWORD PTR [r12+0x310]
    2892:	lea    r9,[r12+0x314]
    289a:	movabs r11,0x5a1b9d18a750
    28a4:	call   r11
    28a7:	ldmxcsr DWORD PTR [r12-0x28]
    28ad:	movdqu xmm2,XMMWORD PTR [rsp]
    28b2:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    28b8:	mov    rbx,QWORD PTR [r12+0x108]
    28c0:	mov    QWORD PTR [r12+0x378],0x2
    28cc:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    28d5:	movdqa xmm4,xmm0
    28d9:	movdqa xmm0,xmm4
    28dd:	movdqu XMMWORD PTR [r12+0x210],xmm0
    28e7:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    28f1:	movdqa xmm2,xmm0
    28f5:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    28ff:	movdqa xmm3,xmm0
    2903:	cmp    DWORD PTR [r12+0x310],0x0
    290c:	jne    0x29f0
    2912:	movdqa xmm0,xmm2
    2916:	movdqa xmm1,xmm3
    291a:	movq   rax,xmm0
    291f:	add    rax,rax
    2922:	je     0x2938
    2924:	shr    rax,0x35
    2928:	sub    eax,0x201
    292d:	cmp    eax,0x3fc
    2932:	ja     0x29f0
    2938:	movdqa xmm14,xmm0
    293d:	psrldq xmm14,0x8
    2943:	movq   rax,xmm14
    2948:	add    rax,rax
    294b:	je     0x2961
    294d:	shr    rax,0x35
    2951:	sub    eax,0x201
    2956:	cmp    eax,0x3fc
    295b:	ja     0x29f0
    2961:	movq   rax,xmm1
    2966:	add    rax,rax
    2969:	je     0x297f
    296b:	shr    rax,0x35
    296f:	sub    eax,0x201
    2974:	cmp    eax,0x3fc
    2979:	ja     0x29f0
    297f:	movdqa xmm14,xmm1
    2984:	psrldq xmm14,0x8
    298a:	movq   rax,xmm14
    298f:	add    rax,rax
    2992:	je     0x29a8
    2994:	shr    rax,0x35
    2998:	sub    eax,0x201
    299d:	cmp    eax,0x3fc
    29a2:	ja     0x29f0
    29a8:	stmxcsr DWORD PTR [rsp+0x100]
    29b0:	mov    DWORD PTR [rsp+0x104],0x1f80
    29bb:	ldmxcsr DWORD PTR [rsp+0x104]
    29c3:	addpd  xmm0,xmm1
    29c7:	stmxcsr DWORD PTR [rsp+0x104]
    29cf:	ldmxcsr DWORD PTR [rsp+0x100]
    29d7:	mov    eax,DWORD PTR [rsp+0x104]
    29de:	shr    eax,1
    29e0:	and    eax,0x10
    29e3:	or     DWORD PTR [r12+0x314],eax
    29eb:	jmp    0x2a9d
    29f0:	movdqa xmm0,xmm2
    29f4:	movdqa xmm1,xmm3
    29f8:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2a01:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2a0a:	mov    QWORD PTR [r12+0x378],0x3
    2a16:	movdqu XMMWORD PTR [rsp],xmm2
    2a1b:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2a21:	mov    QWORD PTR [r12+0x108],rbx
    2a29:	stmxcsr DWORD PTR [r12-0x28]
    2a2f:	ldmxcsr DWORD PTR [r12-0x38]
    2a35:	lea    rdi,[rsp+0xf0]
    2a3d:	lea    rsi,[rsp+0xd0]
    2a45:	lea    rdx,[rsp+0xe0]
    2a4d:	mov    ecx,0x14
    2a52:	mov    r8d,DWORD PTR [r12+0x310]
    2a5a:	lea    r9,[r12+0x314]
    2a62:	movabs r11,0x5a1b9d18a750
    2a6c:	call   r11
    2a6f:	ldmxcsr DWORD PTR [r12-0x28]
    2a75:	movdqu xmm2,XMMWORD PTR [rsp]
    2a7a:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2a80:	mov    rbx,QWORD PTR [r12+0x108]
    2a88:	mov    QWORD PTR [r12+0x378],0x2
    2a94:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    2a9d:	movdqa xmm4,xmm0
    2aa1:	movdqa xmm0,xmm4
    2aa5:	movdqu XMMWORD PTR [r12+0x220],xmm0
    2aaf:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    2ab9:	movdqa xmm2,xmm0
    2abd:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    2ac7:	movdqa xmm3,xmm0
    2acb:	cmp    DWORD PTR [r12+0x310],0x0
    2ad4:	jne    0x2bbd
    2ada:	movdqa xmm0,xmm2
    2ade:	movdqa xmm1,xmm3
    2ae2:	pshufd xmm1,xmm1,0x44
    2ae7:	movq   rax,xmm0
    2aec:	add    rax,rax
    2aef:	je     0x2b05
    2af1:	shr    rax,0x35
    2af5:	sub    eax,0x201
    2afa:	cmp    eax,0x3fc
    2aff:	ja     0x2bbd
    2b05:	movdqa xmm14,xmm0
    2b0a:	psrldq xmm14,0x8
    2b10:	movq   rax,xmm14
    2b15:	add    rax,rax
    2b18:	je     0x2b2e
    2b1a:	shr    rax,0x35
    2b1e:	sub    eax,0x201
    2b23:	cmp    eax,0x3fc
    2b28:	ja     0x2bbd
    2b2e:	movq   rax,xmm1
    2b33:	add    rax,rax
    2b36:	je     0x2b4c
    2b38:	shr    rax,0x35
    2b3c:	sub    eax,0x201
    2b41:	cmp    eax,0x3fc
    2b46:	ja     0x2bbd
    2b4c:	movdqa xmm14,xmm1
    2b51:	psrldq xmm14,0x8
    2b57:	movq   rax,xmm14
    2b5c:	add    rax,rax
    2b5f:	je     0x2b75
    2b61:	shr    rax,0x35
    2b65:	sub    eax,0x201
    2b6a:	cmp    eax,0x3fc
    2b6f:	ja     0x2bbd
    2b75:	stmxcsr DWORD PTR [rsp+0x100]
    2b7d:	mov    DWORD PTR [rsp+0x104],0x1f80
    2b88:	ldmxcsr DWORD PTR [rsp+0x104]
    2b90:	mulpd  xmm0,xmm1
    2b94:	stmxcsr DWORD PTR [rsp+0x104]
    2b9c:	ldmxcsr DWORD PTR [rsp+0x100]
    2ba4:	mov    eax,DWORD PTR [rsp+0x104]
    2bab:	shr    eax,1
    2bad:	and    eax,0x10
    2bb0:	or     DWORD PTR [r12+0x314],eax
    2bb8:	jmp    0x2c6a
    2bbd:	movdqa xmm0,xmm2
    2bc1:	movdqa xmm1,xmm3
    2bc5:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2bce:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2bd7:	mov    QWORD PTR [r12+0x378],0x3
    2be3:	movdqu XMMWORD PTR [rsp],xmm2
    2be8:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2bee:	mov    QWORD PTR [r12+0x108],rbx
    2bf6:	stmxcsr DWORD PTR [r12-0x28]
    2bfc:	ldmxcsr DWORD PTR [r12-0x38]
    2c02:	lea    rdi,[rsp+0xf0]
    2c0a:	lea    rsi,[rsp+0xd0]
    2c12:	lea    rdx,[rsp+0xe0]
    2c1a:	mov    ecx,0x56
    2c1f:	mov    r8d,DWORD PTR [r12+0x310]
    2c27:	lea    r9,[r12+0x314]
    2c2f:	movabs r11,0x5a1b9d18a750
    2c39:	call   r11
    2c3c:	ldmxcsr DWORD PTR [r12-0x28]
    2c42:	movdqu xmm2,XMMWORD PTR [rsp]
    2c47:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2c4d:	mov    rbx,QWORD PTR [r12+0x108]
    2c55:	mov    QWORD PTR [r12+0x378],0x2
    2c61:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    2c6a:	movdqa xmm4,xmm0
    2c6e:	movdqa xmm0,xmm4
    2c72:	movdqu XMMWORD PTR [r12+0x270],xmm0
    2c7c:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    2c86:	movdqa xmm2,xmm0
    2c8a:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    2c94:	movdqa xmm3,xmm0
    2c98:	cmp    DWORD PTR [r12+0x310],0x0
    2ca1:	jne    0x2d8a
    2ca7:	movdqa xmm0,xmm2
    2cab:	movdqa xmm1,xmm3
    2caf:	pshufd xmm1,xmm1,0x44
    2cb4:	movq   rax,xmm0
    2cb9:	add    rax,rax
    2cbc:	je     0x2cd2
    2cbe:	shr    rax,0x35
    2cc2:	sub    eax,0x201
    2cc7:	cmp    eax,0x3fc
    2ccc:	ja     0x2d8a
    2cd2:	movdqa xmm14,xmm0
    2cd7:	psrldq xmm14,0x8
    2cdd:	movq   rax,xmm14
    2ce2:	add    rax,rax
    2ce5:	je     0x2cfb
    2ce7:	shr    rax,0x35
    2ceb:	sub    eax,0x201
    2cf0:	cmp    eax,0x3fc
    2cf5:	ja     0x2d8a
    2cfb:	movq   rax,xmm1
    2d00:	add    rax,rax
    2d03:	je     0x2d19
    2d05:	shr    rax,0x35
    2d09:	sub    eax,0x201
    2d0e:	cmp    eax,0x3fc
    2d13:	ja     0x2d8a
    2d19:	movdqa xmm14,xmm1
    2d1e:	psrldq xmm14,0x8
    2d24:	movq   rax,xmm14
    2d29:	add    rax,rax
    2d2c:	je     0x2d42
    2d2e:	shr    rax,0x35
    2d32:	sub    eax,0x201
    2d37:	cmp    eax,0x3fc
    2d3c:	ja     0x2d8a
    2d42:	stmxcsr DWORD PTR [rsp+0x100]
    2d4a:	mov    DWORD PTR [rsp+0x104],0x1f80
    2d55:	ldmxcsr DWORD PTR [rsp+0x104]
    2d5d:	mulpd  xmm0,xmm1
    2d61:	stmxcsr DWORD PTR [rsp+0x104]
    2d69:	ldmxcsr DWORD PTR [rsp+0x100]
    2d71:	mov    eax,DWORD PTR [rsp+0x104]
    2d78:	shr    eax,1
    2d7a:	and    eax,0x10
    2d7d:	or     DWORD PTR [r12+0x314],eax
    2d85:	jmp    0x2e37
    2d8a:	movdqa xmm0,xmm2
    2d8e:	movdqa xmm1,xmm3
    2d92:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2d9b:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2da4:	mov    QWORD PTR [r12+0x378],0x3
    2db0:	movdqu XMMWORD PTR [rsp],xmm2
    2db5:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2dbb:	mov    QWORD PTR [r12+0x108],rbx
    2dc3:	stmxcsr DWORD PTR [r12-0x28]
    2dc9:	ldmxcsr DWORD PTR [r12-0x38]
    2dcf:	lea    rdi,[rsp+0xf0]
    2dd7:	lea    rsi,[rsp+0xd0]
    2ddf:	lea    rdx,[rsp+0xe0]
    2de7:	mov    ecx,0x56
    2dec:	mov    r8d,DWORD PTR [r12+0x310]
    2df4:	lea    r9,[r12+0x314]
    2dfc:	movabs r11,0x5a1b9d18a750
    2e06:	call   r11
    2e09:	ldmxcsr DWORD PTR [r12-0x28]
    2e0f:	movdqu xmm2,XMMWORD PTR [rsp]
    2e14:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2e1a:	mov    rbx,QWORD PTR [r12+0x108]
    2e22:	mov    QWORD PTR [r12+0x378],0x2
    2e2e:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    2e37:	movdqa xmm4,xmm0
    2e3b:	movdqa xmm0,xmm4
    2e3f:	movdqu XMMWORD PTR [r12+0x250],xmm0
    2e49:	mov    r13,QWORD PTR [r12+0xf8]
    2e51:	mov    r14,r13
    2e54:	add    r14,0xe0
    2e5b:	movdqu xmm2,XMMWORD PTR [r14]
    2e60:	movdqa xmm0,xmm2
    2e64:	movdqu XMMWORD PTR [r12+0x110],xmm0
    2e6e:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    2e78:	movdqa xmm2,xmm0
    2e7c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    2e86:	movdqa xmm3,xmm0
    2e8a:	cmp    DWORD PTR [r12+0x310],0x0
    2e93:	jne    0x2f7c
    2e99:	movdqa xmm0,xmm2
    2e9d:	movdqa xmm1,xmm3
    2ea1:	pshufd xmm1,xmm1,0x44
    2ea6:	movq   rax,xmm0
    2eab:	add    rax,rax
    2eae:	je     0x2ec4
    2eb0:	shr    rax,0x35
    2eb4:	sub    eax,0x201
    2eb9:	cmp    eax,0x3fc
    2ebe:	ja     0x2f7c
    2ec4:	movdqa xmm14,xmm0
    2ec9:	psrldq xmm14,0x8
    2ecf:	movq   rax,xmm14
    2ed4:	add    rax,rax
    2ed7:	je     0x2eed
    2ed9:	shr    rax,0x35
    2edd:	sub    eax,0x201
    2ee2:	cmp    eax,0x3fc
    2ee7:	ja     0x2f7c
    2eed:	movq   rax,xmm1
    2ef2:	add    rax,rax
    2ef5:	je     0x2f0b
    2ef7:	shr    rax,0x35
    2efb:	sub    eax,0x201
    2f00:	cmp    eax,0x3fc
    2f05:	ja     0x2f7c
    2f0b:	movdqa xmm14,xmm1
    2f10:	psrldq xmm14,0x8
    2f16:	movq   rax,xmm14
    2f1b:	add    rax,rax
    2f1e:	je     0x2f34
    2f20:	shr    rax,0x35
    2f24:	sub    eax,0x201
    2f29:	cmp    eax,0x3fc
    2f2e:	ja     0x2f7c
    2f34:	stmxcsr DWORD PTR [rsp+0x100]
    2f3c:	mov    DWORD PTR [rsp+0x104],0x1f80
    2f47:	ldmxcsr DWORD PTR [rsp+0x104]
    2f4f:	mulpd  xmm0,xmm1
    2f53:	stmxcsr DWORD PTR [rsp+0x104]
    2f5b:	ldmxcsr DWORD PTR [rsp+0x100]
    2f63:	mov    eax,DWORD PTR [rsp+0x104]
    2f6a:	shr    eax,1
    2f6c:	and    eax,0x10
    2f6f:	or     DWORD PTR [r12+0x314],eax
    2f77:	jmp    0x3029
    2f7c:	movdqa xmm0,xmm2
    2f80:	movdqa xmm1,xmm3
    2f84:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    2f8d:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    2f96:	mov    QWORD PTR [r12+0x378],0x3
    2fa2:	movdqu XMMWORD PTR [rsp],xmm2
    2fa7:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    2fad:	mov    QWORD PTR [r12+0x108],rbx
    2fb5:	stmxcsr DWORD PTR [r12-0x28]
    2fbb:	ldmxcsr DWORD PTR [r12-0x38]
    2fc1:	lea    rdi,[rsp+0xf0]
    2fc9:	lea    rsi,[rsp+0xd0]
    2fd1:	lea    rdx,[rsp+0xe0]
    2fd9:	mov    ecx,0x56
    2fde:	mov    r8d,DWORD PTR [r12+0x310]
    2fe6:	lea    r9,[r12+0x314]
    2fee:	movabs r11,0x5a1b9d18a750
    2ff8:	call   r11
    2ffb:	ldmxcsr DWORD PTR [r12-0x28]
    3001:	movdqu xmm2,XMMWORD PTR [rsp]
    3006:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    300c:	mov    rbx,QWORD PTR [r12+0x108]
    3014:	mov    QWORD PTR [r12+0x378],0x2
    3020:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    3029:	movdqa xmm4,xmm0
    302d:	movdqa xmm0,xmm4
    3031:	movdqu XMMWORD PTR [r12+0x230],xmm0
    303b:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    3045:	movdqa xmm2,xmm0
    3049:	movdqa xmm0,xmm2
    304d:	movdqa xmm1,xmm2
    3051:	por    xmm0,xmm1
    3055:	movdqa xmm3,xmm0
    3059:	movdqa xmm0,xmm3
    305d:	movdqu XMMWORD PTR [r12+0x300],xmm0
    3067:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    3071:	movdqa xmm2,xmm0
    3075:	movdqa xmm0,xmm2
    3079:	movdqa xmm1,xmm2
    307d:	por    xmm0,xmm1
    3081:	movdqa xmm3,xmm0
    3085:	movdqa xmm0,xmm3
    3089:	movdqu XMMWORD PTR [r12+0x190],xmm0
    3093:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    309d:	movdqa xmm2,xmm0
    30a1:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    30ab:	movdqa xmm3,xmm0
    30af:	cmp    DWORD PTR [r12+0x310],0x0
    30b8:	jne    0x31a1
    30be:	movdqa xmm0,xmm2
    30c2:	movdqa xmm1,xmm3
    30c6:	pshufd xmm1,xmm1,0x44
    30cb:	movq   rax,xmm0
    30d0:	add    rax,rax
    30d3:	je     0x30e9
    30d5:	shr    rax,0x35
    30d9:	sub    eax,0x201
    30de:	cmp    eax,0x3fc
    30e3:	ja     0x31a1
    30e9:	movdqa xmm14,xmm0
    30ee:	psrldq xmm14,0x8
    30f4:	movq   rax,xmm14
    30f9:	add    rax,rax
    30fc:	je     0x3112
    30fe:	shr    rax,0x35
    3102:	sub    eax,0x201
    3107:	cmp    eax,0x3fc
    310c:	ja     0x31a1
    3112:	movq   rax,xmm1
    3117:	add    rax,rax
    311a:	je     0x3130
    311c:	shr    rax,0x35
    3120:	sub    eax,0x201
    3125:	cmp    eax,0x3fc
    312a:	ja     0x31a1
    3130:	movdqa xmm14,xmm1
    3135:	psrldq xmm14,0x8
    313b:	movq   rax,xmm14
    3140:	add    rax,rax
    3143:	je     0x3159
    3145:	shr    rax,0x35
    3149:	sub    eax,0x201
    314e:	cmp    eax,0x3fc
    3153:	ja     0x31a1
    3159:	stmxcsr DWORD PTR [rsp+0x100]
    3161:	mov    DWORD PTR [rsp+0x104],0x1f80
    316c:	ldmxcsr DWORD PTR [rsp+0x104]
    3174:	mulpd  xmm0,xmm1
    3178:	stmxcsr DWORD PTR [rsp+0x104]
    3180:	ldmxcsr DWORD PTR [rsp+0x100]
    3188:	mov    eax,DWORD PTR [rsp+0x104]
    318f:	shr    eax,1
    3191:	and    eax,0x10
    3194:	or     DWORD PTR [r12+0x314],eax
    319c:	jmp    0x324e
    31a1:	movdqa xmm0,xmm2
    31a5:	movdqa xmm1,xmm3
    31a9:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    31b2:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    31bb:	mov    QWORD PTR [r12+0x378],0x3
    31c7:	movdqu XMMWORD PTR [rsp],xmm2
    31cc:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    31d2:	mov    QWORD PTR [r12+0x108],rbx
    31da:	stmxcsr DWORD PTR [r12-0x28]
    31e0:	ldmxcsr DWORD PTR [r12-0x38]
    31e6:	lea    rdi,[rsp+0xf0]
    31ee:	lea    rsi,[rsp+0xd0]
    31f6:	lea    rdx,[rsp+0xe0]
    31fe:	mov    ecx,0x56
    3203:	mov    r8d,DWORD PTR [r12+0x310]
    320b:	lea    r9,[r12+0x314]
    3213:	movabs r11,0x5a1b9d18a750
    321d:	call   r11
    3220:	ldmxcsr DWORD PTR [r12-0x28]
    3226:	movdqu xmm2,XMMWORD PTR [rsp]
    322b:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3231:	mov    rbx,QWORD PTR [r12+0x108]
    3239:	mov    QWORD PTR [r12+0x378],0x2
    3245:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    324e:	movdqa xmm4,xmm0
    3252:	movdqa xmm0,xmm4
    3256:	movdqu XMMWORD PTR [r12+0x260],xmm0
    3260:	mov    r13,QWORD PTR [r12+0xf8]
    3268:	mov    r14,r13
    326b:	add    r14,0x90
    3272:	movdqu xmm2,XMMWORD PTR [r14]
    3277:	movdqa xmm0,xmm2
    327b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    3285:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    328f:	movdqa xmm2,xmm0
    3293:	movdqa xmm0,xmm2
    3297:	movdqa xmm1,xmm2
    329b:	por    xmm0,xmm1
    329f:	movdqa xmm3,xmm0
    32a3:	movdqa xmm0,xmm3
    32a7:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    32b1:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    32bb:	movdqa xmm2,xmm0
    32bf:	movdqa xmm0,xmm2
    32c3:	movdqa xmm1,xmm2
    32c7:	por    xmm0,xmm1
    32cb:	movdqa xmm3,xmm0
    32cf:	movdqa xmm0,xmm3
    32d3:	movdqu XMMWORD PTR [r12+0x200],xmm0
    32dd:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    32e7:	movdqa xmm2,xmm0
    32eb:	movdqa xmm0,xmm2
    32ef:	movdqa xmm1,xmm2
    32f3:	por    xmm0,xmm1
    32f7:	movdqa xmm3,xmm0
    32fb:	movdqa xmm0,xmm3
    32ff:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    3309:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    3313:	movdqa xmm2,xmm0
    3317:	movdqa xmm0,xmm2
    331b:	movdqa xmm1,xmm2
    331f:	por    xmm0,xmm1
    3323:	movdqa xmm3,xmm0
    3327:	movdqa xmm0,xmm3
    332b:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    3335:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    333f:	movdqa xmm2,xmm0
    3343:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    334d:	movdqa xmm3,xmm0
    3351:	cmp    DWORD PTR [r12+0x310],0x0
    335a:	jne    0x343e
    3360:	movdqa xmm0,xmm2
    3364:	movdqa xmm1,xmm3
    3368:	movq   rax,xmm0
    336d:	add    rax,rax
    3370:	je     0x3386
    3372:	shr    rax,0x35
    3376:	sub    eax,0x201
    337b:	cmp    eax,0x3fc
    3380:	ja     0x343e
    3386:	movdqa xmm14,xmm0
    338b:	psrldq xmm14,0x8
    3391:	movq   rax,xmm14
    3396:	add    rax,rax
    3399:	je     0x33af
    339b:	shr    rax,0x35
    339f:	sub    eax,0x201
    33a4:	cmp    eax,0x3fc
    33a9:	ja     0x343e
    33af:	movq   rax,xmm1
    33b4:	add    rax,rax
    33b7:	je     0x33cd
    33b9:	shr    rax,0x35
    33bd:	sub    eax,0x201
    33c2:	cmp    eax,0x3fc
    33c7:	ja     0x343e
    33cd:	movdqa xmm14,xmm1
    33d2:	psrldq xmm14,0x8
    33d8:	movq   rax,xmm14
    33dd:	add    rax,rax
    33e0:	je     0x33f6
    33e2:	shr    rax,0x35
    33e6:	sub    eax,0x201
    33eb:	cmp    eax,0x3fc
    33f0:	ja     0x343e
    33f6:	stmxcsr DWORD PTR [rsp+0x100]
    33fe:	mov    DWORD PTR [rsp+0x104],0x1f80
    3409:	ldmxcsr DWORD PTR [rsp+0x104]
    3411:	addpd  xmm0,xmm1
    3415:	stmxcsr DWORD PTR [rsp+0x104]
    341d:	ldmxcsr DWORD PTR [rsp+0x100]
    3425:	mov    eax,DWORD PTR [rsp+0x104]
    342c:	shr    eax,1
    342e:	and    eax,0x10
    3431:	or     DWORD PTR [r12+0x314],eax
    3439:	jmp    0x34eb
    343e:	movdqa xmm0,xmm2
    3442:	movdqa xmm1,xmm3
    3446:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    344f:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3458:	mov    QWORD PTR [r12+0x378],0x3
    3464:	movdqu XMMWORD PTR [rsp],xmm2
    3469:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    346f:	mov    QWORD PTR [r12+0x108],rbx
    3477:	stmxcsr DWORD PTR [r12-0x28]
    347d:	ldmxcsr DWORD PTR [r12-0x38]
    3483:	lea    rdi,[rsp+0xf0]
    348b:	lea    rsi,[rsp+0xd0]
    3493:	lea    rdx,[rsp+0xe0]
    349b:	mov    ecx,0x14
    34a0:	mov    r8d,DWORD PTR [r12+0x310]
    34a8:	lea    r9,[r12+0x314]
    34b0:	movabs r11,0x5a1b9d18a750
    34ba:	call   r11
    34bd:	ldmxcsr DWORD PTR [r12-0x28]
    34c3:	movdqu xmm2,XMMWORD PTR [rsp]
    34c8:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    34ce:	mov    rbx,QWORD PTR [r12+0x108]
    34d6:	mov    QWORD PTR [r12+0x378],0x2
    34e2:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    34eb:	movdqa xmm4,xmm0
    34ef:	movdqa xmm0,xmm4
    34f3:	movdqu XMMWORD PTR [r12+0x240],xmm0
    34fd:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    3507:	movdqa xmm2,xmm0
    350b:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    3515:	movdqa xmm3,xmm0
    3519:	cmp    DWORD PTR [r12+0x310],0x0
    3522:	jne    0x360b
    3528:	movdqa xmm0,xmm2
    352c:	movdqa xmm1,xmm3
    3530:	pshufd xmm1,xmm1,0x44
    3535:	movq   rax,xmm0
    353a:	add    rax,rax
    353d:	je     0x3553
    353f:	shr    rax,0x35
    3543:	sub    eax,0x201
    3548:	cmp    eax,0x3fc
    354d:	ja     0x360b
    3553:	movdqa xmm14,xmm0
    3558:	psrldq xmm14,0x8
    355e:	movq   rax,xmm14
    3563:	add    rax,rax
    3566:	je     0x357c
    3568:	shr    rax,0x35
    356c:	sub    eax,0x201
    3571:	cmp    eax,0x3fc
    3576:	ja     0x360b
    357c:	movq   rax,xmm1
    3581:	add    rax,rax
    3584:	je     0x359a
    3586:	shr    rax,0x35
    358a:	sub    eax,0x201
    358f:	cmp    eax,0x3fc
    3594:	ja     0x360b
    359a:	movdqa xmm14,xmm1
    359f:	psrldq xmm14,0x8
    35a5:	movq   rax,xmm14
    35aa:	add    rax,rax
    35ad:	je     0x35c3
    35af:	shr    rax,0x35
    35b3:	sub    eax,0x201
    35b8:	cmp    eax,0x3fc
    35bd:	ja     0x360b
    35c3:	stmxcsr DWORD PTR [rsp+0x100]
    35cb:	mov    DWORD PTR [rsp+0x104],0x1f80
    35d6:	ldmxcsr DWORD PTR [rsp+0x104]
    35de:	mulpd  xmm0,xmm1
    35e2:	stmxcsr DWORD PTR [rsp+0x104]
    35ea:	ldmxcsr DWORD PTR [rsp+0x100]
    35f2:	mov    eax,DWORD PTR [rsp+0x104]
    35f9:	shr    eax,1
    35fb:	and    eax,0x10
    35fe:	or     DWORD PTR [r12+0x314],eax
    3606:	jmp    0x36b8
    360b:	movdqa xmm0,xmm2
    360f:	movdqa xmm1,xmm3
    3613:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    361c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3625:	mov    QWORD PTR [r12+0x378],0x3
    3631:	movdqu XMMWORD PTR [rsp],xmm2
    3636:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    363c:	mov    QWORD PTR [r12+0x108],rbx
    3644:	stmxcsr DWORD PTR [r12-0x28]
    364a:	ldmxcsr DWORD PTR [r12-0x38]
    3650:	lea    rdi,[rsp+0xf0]
    3658:	lea    rsi,[rsp+0xd0]
    3660:	lea    rdx,[rsp+0xe0]
    3668:	mov    ecx,0x56
    366d:	mov    r8d,DWORD PTR [r12+0x310]
    3675:	lea    r9,[r12+0x314]
    367d:	movabs r11,0x5a1b9d18a750
    3687:	call   r11
    368a:	ldmxcsr DWORD PTR [r12-0x28]
    3690:	movdqu xmm2,XMMWORD PTR [rsp]
    3695:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    369b:	mov    rbx,QWORD PTR [r12+0x108]
    36a3:	mov    QWORD PTR [r12+0x378],0x2
    36af:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    36b8:	movdqa xmm4,xmm0
    36bc:	movdqa xmm0,xmm4
    36c0:	movdqu XMMWORD PTR [r12+0x270],xmm0
    36ca:	mov    r13,QWORD PTR [r12+0xf8]
    36d2:	mov    r14,r13
    36d5:	add    r14,0x80
    36dc:	movdqu xmm2,XMMWORD PTR [r14]
    36e1:	movdqa xmm0,xmm2
    36e5:	movdqu XMMWORD PTR [r12+0x110],xmm0
    36ef:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    36f9:	movdqa xmm2,xmm0
    36fd:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    3707:	movdqa xmm3,xmm0
    370b:	cmp    DWORD PTR [r12+0x310],0x0
    3714:	jne    0x37f8
    371a:	movdqa xmm0,xmm2
    371e:	movdqa xmm1,xmm3
    3722:	movq   rax,xmm0
    3727:	add    rax,rax
    372a:	je     0x3740
    372c:	shr    rax,0x35
    3730:	sub    eax,0x201
    3735:	cmp    eax,0x3fc
    373a:	ja     0x37f8
    3740:	movdqa xmm14,xmm0
    3745:	psrldq xmm14,0x8
    374b:	movq   rax,xmm14
    3750:	add    rax,rax
    3753:	je     0x3769
    3755:	shr    rax,0x35
    3759:	sub    eax,0x201
    375e:	cmp    eax,0x3fc
    3763:	ja     0x37f8
    3769:	movq   rax,xmm1
    376e:	add    rax,rax
    3771:	je     0x3787
    3773:	shr    rax,0x35
    3777:	sub    eax,0x201
    377c:	cmp    eax,0x3fc
    3781:	ja     0x37f8
    3787:	movdqa xmm14,xmm1
    378c:	psrldq xmm14,0x8
    3792:	movq   rax,xmm14
    3797:	add    rax,rax
    379a:	je     0x37b0
    379c:	shr    rax,0x35
    37a0:	sub    eax,0x201
    37a5:	cmp    eax,0x3fc
    37aa:	ja     0x37f8
    37b0:	stmxcsr DWORD PTR [rsp+0x100]
    37b8:	mov    DWORD PTR [rsp+0x104],0x1f80
    37c3:	ldmxcsr DWORD PTR [rsp+0x104]
    37cb:	addpd  xmm0,xmm1
    37cf:	stmxcsr DWORD PTR [rsp+0x104]
    37d7:	ldmxcsr DWORD PTR [rsp+0x100]
    37df:	mov    eax,DWORD PTR [rsp+0x104]
    37e6:	shr    eax,1
    37e8:	and    eax,0x10
    37eb:	or     DWORD PTR [r12+0x314],eax
    37f3:	jmp    0x38a5
    37f8:	movdqa xmm0,xmm2
    37fc:	movdqa xmm1,xmm3
    3800:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3809:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3812:	mov    QWORD PTR [r12+0x378],0x3
    381e:	movdqu XMMWORD PTR [rsp],xmm2
    3823:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3829:	mov    QWORD PTR [r12+0x108],rbx
    3831:	stmxcsr DWORD PTR [r12-0x28]
    3837:	ldmxcsr DWORD PTR [r12-0x38]
    383d:	lea    rdi,[rsp+0xf0]
    3845:	lea    rsi,[rsp+0xd0]
    384d:	lea    rdx,[rsp+0xe0]
    3855:	mov    ecx,0x14
    385a:	mov    r8d,DWORD PTR [r12+0x310]
    3862:	lea    r9,[r12+0x314]
    386a:	movabs r11,0x5a1b9d18a750
    3874:	call   r11
    3877:	ldmxcsr DWORD PTR [r12-0x28]
    387d:	movdqu xmm2,XMMWORD PTR [rsp]
    3882:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3888:	mov    rbx,QWORD PTR [r12+0x108]
    3890:	mov    QWORD PTR [r12+0x378],0x2
    389c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    38a5:	movdqa xmm4,xmm0
    38a9:	movdqa xmm0,xmm4
    38ad:	movdqu XMMWORD PTR [r12+0x180],xmm0
    38b7:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    38c1:	movdqa xmm2,xmm0
    38c5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    38cf:	movdqa xmm3,xmm0
    38d3:	cmp    DWORD PTR [r12+0x310],0x0
    38dc:	jne    0x39c0
    38e2:	movdqa xmm0,xmm2
    38e6:	movdqa xmm1,xmm3
    38ea:	movq   rax,xmm0
    38ef:	add    rax,rax
    38f2:	je     0x3908
    38f4:	shr    rax,0x35
    38f8:	sub    eax,0x201
    38fd:	cmp    eax,0x3fc
    3902:	ja     0x39c0
    3908:	movdqa xmm14,xmm0
    390d:	psrldq xmm14,0x8
    3913:	movq   rax,xmm14
    3918:	add    rax,rax
    391b:	je     0x3931
    391d:	shr    rax,0x35
    3921:	sub    eax,0x201
    3926:	cmp    eax,0x3fc
    392b:	ja     0x39c0
    3931:	movq   rax,xmm1
    3936:	add    rax,rax
    3939:	je     0x394f
    393b:	shr    rax,0x35
    393f:	sub    eax,0x201
    3944:	cmp    eax,0x3fc
    3949:	ja     0x39c0
    394f:	movdqa xmm14,xmm1
    3954:	psrldq xmm14,0x8
    395a:	movq   rax,xmm14
    395f:	add    rax,rax
    3962:	je     0x3978
    3964:	shr    rax,0x35
    3968:	sub    eax,0x201
    396d:	cmp    eax,0x3fc
    3972:	ja     0x39c0
    3978:	stmxcsr DWORD PTR [rsp+0x100]
    3980:	mov    DWORD PTR [rsp+0x104],0x1f80
    398b:	ldmxcsr DWORD PTR [rsp+0x104]
    3993:	addpd  xmm0,xmm1
    3997:	stmxcsr DWORD PTR [rsp+0x104]
    399f:	ldmxcsr DWORD PTR [rsp+0x100]
    39a7:	mov    eax,DWORD PTR [rsp+0x104]
    39ae:	shr    eax,1
    39b0:	and    eax,0x10
    39b3:	or     DWORD PTR [r12+0x314],eax
    39bb:	jmp    0x3a6d
    39c0:	movdqa xmm0,xmm2
    39c4:	movdqa xmm1,xmm3
    39c8:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    39d1:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    39da:	mov    QWORD PTR [r12+0x378],0x3
    39e6:	movdqu XMMWORD PTR [rsp],xmm2
    39eb:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    39f1:	mov    QWORD PTR [r12+0x108],rbx
    39f9:	stmxcsr DWORD PTR [r12-0x28]
    39ff:	ldmxcsr DWORD PTR [r12-0x38]
    3a05:	lea    rdi,[rsp+0xf0]
    3a0d:	lea    rsi,[rsp+0xd0]
    3a15:	lea    rdx,[rsp+0xe0]
    3a1d:	mov    ecx,0x14
    3a22:	mov    r8d,DWORD PTR [r12+0x310]
    3a2a:	lea    r9,[r12+0x314]
    3a32:	movabs r11,0x5a1b9d18a750
    3a3c:	call   r11
    3a3f:	ldmxcsr DWORD PTR [r12-0x28]
    3a45:	movdqu xmm2,XMMWORD PTR [rsp]
    3a4a:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3a50:	mov    rbx,QWORD PTR [r12+0x108]
    3a58:	mov    QWORD PTR [r12+0x378],0x2
    3a64:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    3a6d:	movdqa xmm4,xmm0
    3a71:	movdqa xmm0,xmm4
    3a75:	movdqu XMMWORD PTR [r12+0x210],xmm0
    3a7f:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    3a89:	movdqa xmm2,xmm0
    3a8d:	movdqa xmm0,xmm2
    3a91:	movdqa xmm1,xmm2
    3a95:	por    xmm0,xmm1
    3a99:	movdqa xmm3,xmm0
    3a9d:	movdqa xmm0,xmm3
    3aa1:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    3aab:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    3ab5:	movdqa xmm2,xmm0
    3ab9:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    3ac3:	movdqa xmm3,xmm0
    3ac7:	cmp    DWORD PTR [r12+0x310],0x0
    3ad0:	jne    0x3bb9
    3ad6:	movdqa xmm0,xmm2
    3ada:	movdqa xmm1,xmm3
    3ade:	pshufd xmm1,xmm1,0x44
    3ae3:	movq   rax,xmm0
    3ae8:	add    rax,rax
    3aeb:	je     0x3b01
    3aed:	shr    rax,0x35
    3af1:	sub    eax,0x201
    3af6:	cmp    eax,0x3fc
    3afb:	ja     0x3bb9
    3b01:	movdqa xmm14,xmm0
    3b06:	psrldq xmm14,0x8
    3b0c:	movq   rax,xmm14
    3b11:	add    rax,rax
    3b14:	je     0x3b2a
    3b16:	shr    rax,0x35
    3b1a:	sub    eax,0x201
    3b1f:	cmp    eax,0x3fc
    3b24:	ja     0x3bb9
    3b2a:	movq   rax,xmm1
    3b2f:	add    rax,rax
    3b32:	je     0x3b48
    3b34:	shr    rax,0x35
    3b38:	sub    eax,0x201
    3b3d:	cmp    eax,0x3fc
    3b42:	ja     0x3bb9
    3b48:	movdqa xmm14,xmm1
    3b4d:	psrldq xmm14,0x8
    3b53:	movq   rax,xmm14
    3b58:	add    rax,rax
    3b5b:	je     0x3b71
    3b5d:	shr    rax,0x35
    3b61:	sub    eax,0x201
    3b66:	cmp    eax,0x3fc
    3b6b:	ja     0x3bb9
    3b71:	stmxcsr DWORD PTR [rsp+0x100]
    3b79:	mov    DWORD PTR [rsp+0x104],0x1f80
    3b84:	ldmxcsr DWORD PTR [rsp+0x104]
    3b8c:	mulpd  xmm0,xmm1
    3b90:	stmxcsr DWORD PTR [rsp+0x104]
    3b98:	ldmxcsr DWORD PTR [rsp+0x100]
    3ba0:	mov    eax,DWORD PTR [rsp+0x104]
    3ba7:	shr    eax,1
    3ba9:	and    eax,0x10
    3bac:	or     DWORD PTR [r12+0x314],eax
    3bb4:	jmp    0x3c66
    3bb9:	movdqa xmm0,xmm2
    3bbd:	movdqa xmm1,xmm3
    3bc1:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3bca:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3bd3:	mov    QWORD PTR [r12+0x378],0x3
    3bdf:	movdqu XMMWORD PTR [rsp],xmm2
    3be4:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3bea:	mov    QWORD PTR [r12+0x108],rbx
    3bf2:	stmxcsr DWORD PTR [r12-0x28]
    3bf8:	ldmxcsr DWORD PTR [r12-0x38]
    3bfe:	lea    rdi,[rsp+0xf0]
    3c06:	lea    rsi,[rsp+0xd0]
    3c0e:	lea    rdx,[rsp+0xe0]
    3c16:	mov    ecx,0x56
    3c1b:	mov    r8d,DWORD PTR [r12+0x310]
    3c23:	lea    r9,[r12+0x314]
    3c2b:	movabs r11,0x5a1b9d18a750
    3c35:	call   r11
    3c38:	ldmxcsr DWORD PTR [r12-0x28]
    3c3e:	movdqu xmm2,XMMWORD PTR [rsp]
    3c43:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3c49:	mov    rbx,QWORD PTR [r12+0x108]
    3c51:	mov    QWORD PTR [r12+0x378],0x2
    3c5d:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    3c66:	movdqa xmm4,xmm0
    3c6a:	movdqa xmm0,xmm4
    3c6e:	movdqu XMMWORD PTR [r12+0x170],xmm0
    3c78:	mov    r13,QWORD PTR [r12+0xf8]
    3c80:	mov    r14,r13
    3c83:	add    r14,0xd0
    3c8a:	movdqu xmm2,XMMWORD PTR [r14]
    3c8f:	movdqa xmm0,xmm2
    3c93:	movdqu XMMWORD PTR [r12+0x110],xmm0
    3c9d:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    3ca7:	movdqa xmm2,xmm0
    3cab:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    3cb5:	movdqa xmm3,xmm0
    3cb9:	cmp    DWORD PTR [r12+0x310],0x0
    3cc2:	jne    0x3da6
    3cc8:	movdqa xmm0,xmm2
    3ccc:	movdqa xmm1,xmm3
    3cd0:	movq   rax,xmm0
    3cd5:	add    rax,rax
    3cd8:	je     0x3cee
    3cda:	shr    rax,0x35
    3cde:	sub    eax,0x201
    3ce3:	cmp    eax,0x3fc
    3ce8:	ja     0x3da6
    3cee:	movdqa xmm14,xmm0
    3cf3:	psrldq xmm14,0x8
    3cf9:	movq   rax,xmm14
    3cfe:	add    rax,rax
    3d01:	je     0x3d17
    3d03:	shr    rax,0x35
    3d07:	sub    eax,0x201
    3d0c:	cmp    eax,0x3fc
    3d11:	ja     0x3da6
    3d17:	movq   rax,xmm1
    3d1c:	add    rax,rax
    3d1f:	je     0x3d35
    3d21:	shr    rax,0x35
    3d25:	sub    eax,0x201
    3d2a:	cmp    eax,0x3fc
    3d2f:	ja     0x3da6
    3d35:	movdqa xmm14,xmm1
    3d3a:	psrldq xmm14,0x8
    3d40:	movq   rax,xmm14
    3d45:	add    rax,rax
    3d48:	je     0x3d5e
    3d4a:	shr    rax,0x35
    3d4e:	sub    eax,0x201
    3d53:	cmp    eax,0x3fc
    3d58:	ja     0x3da6
    3d5e:	stmxcsr DWORD PTR [rsp+0x100]
    3d66:	mov    DWORD PTR [rsp+0x104],0x1f80
    3d71:	ldmxcsr DWORD PTR [rsp+0x104]
    3d79:	addpd  xmm0,xmm1
    3d7d:	stmxcsr DWORD PTR [rsp+0x104]
    3d85:	ldmxcsr DWORD PTR [rsp+0x100]
    3d8d:	mov    eax,DWORD PTR [rsp+0x104]
    3d94:	shr    eax,1
    3d96:	and    eax,0x10
    3d99:	or     DWORD PTR [r12+0x314],eax
    3da1:	jmp    0x3e53
    3da6:	movdqa xmm0,xmm2
    3daa:	movdqa xmm1,xmm3
    3dae:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3db7:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3dc0:	mov    QWORD PTR [r12+0x378],0x3
    3dcc:	movdqu XMMWORD PTR [rsp],xmm2
    3dd1:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3dd7:	mov    QWORD PTR [r12+0x108],rbx
    3ddf:	stmxcsr DWORD PTR [r12-0x28]
    3de5:	ldmxcsr DWORD PTR [r12-0x38]
    3deb:	lea    rdi,[rsp+0xf0]
    3df3:	lea    rsi,[rsp+0xd0]
    3dfb:	lea    rdx,[rsp+0xe0]
    3e03:	mov    ecx,0x14
    3e08:	mov    r8d,DWORD PTR [r12+0x310]
    3e10:	lea    r9,[r12+0x314]
    3e18:	movabs r11,0x5a1b9d18a750
    3e22:	call   r11
    3e25:	ldmxcsr DWORD PTR [r12-0x28]
    3e2b:	movdqu xmm2,XMMWORD PTR [rsp]
    3e30:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    3e36:	mov    rbx,QWORD PTR [r12+0x108]
    3e3e:	mov    QWORD PTR [r12+0x378],0x2
    3e4a:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    3e53:	movdqa xmm4,xmm0
    3e57:	movdqa xmm0,xmm4
    3e5b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    3e65:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    3e6f:	movdqa xmm2,xmm0
    3e73:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    3e7d:	movdqa xmm3,xmm0
    3e81:	cmp    DWORD PTR [r12+0x310],0x0
    3e8a:	jne    0x3f73
    3e90:	movdqa xmm0,xmm2
    3e94:	movdqa xmm1,xmm3
    3e98:	pshufd xmm1,xmm1,0x44
    3e9d:	movq   rax,xmm0
    3ea2:	add    rax,rax
    3ea5:	je     0x3ebb
    3ea7:	shr    rax,0x35
    3eab:	sub    eax,0x201
    3eb0:	cmp    eax,0x3fc
    3eb5:	ja     0x3f73
    3ebb:	movdqa xmm14,xmm0
    3ec0:	psrldq xmm14,0x8
    3ec6:	movq   rax,xmm14
    3ecb:	add    rax,rax
    3ece:	je     0x3ee4
    3ed0:	shr    rax,0x35
    3ed4:	sub    eax,0x201
    3ed9:	cmp    eax,0x3fc
    3ede:	ja     0x3f73
    3ee4:	movq   rax,xmm1
    3ee9:	add    rax,rax
    3eec:	je     0x3f02
    3eee:	shr    rax,0x35
    3ef2:	sub    eax,0x201
    3ef7:	cmp    eax,0x3fc
    3efc:	ja     0x3f73
    3f02:	movdqa xmm14,xmm1
    3f07:	psrldq xmm14,0x8
    3f0d:	movq   rax,xmm14
    3f12:	add    rax,rax
    3f15:	je     0x3f2b
    3f17:	shr    rax,0x35
    3f1b:	sub    eax,0x201
    3f20:	cmp    eax,0x3fc
    3f25:	ja     0x3f73
    3f2b:	stmxcsr DWORD PTR [rsp+0x100]
    3f33:	mov    DWORD PTR [rsp+0x104],0x1f80
    3f3e:	ldmxcsr DWORD PTR [rsp+0x104]
    3f46:	mulpd  xmm0,xmm1
    3f4a:	stmxcsr DWORD PTR [rsp+0x104]
    3f52:	ldmxcsr DWORD PTR [rsp+0x100]
    3f5a:	mov    eax,DWORD PTR [rsp+0x104]
    3f61:	shr    eax,1
    3f63:	and    eax,0x10
    3f66:	or     DWORD PTR [r12+0x314],eax
    3f6e:	jmp    0x4020
    3f73:	movdqa xmm0,xmm2
    3f77:	movdqa xmm1,xmm3
    3f7b:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    3f84:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    3f8d:	mov    QWORD PTR [r12+0x378],0x3
    3f99:	movdqu XMMWORD PTR [rsp],xmm2
    3f9e:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    3fa4:	mov    QWORD PTR [r12+0x108],rbx
    3fac:	stmxcsr DWORD PTR [r12-0x28]
    3fb2:	ldmxcsr DWORD PTR [r12-0x38]
    3fb8:	lea    rdi,[rsp+0xf0]
    3fc0:	lea    rsi,[rsp+0xd0]
    3fc8:	lea    rdx,[rsp+0xe0]
    3fd0:	mov    ecx,0x56
    3fd5:	mov    r8d,DWORD PTR [r12+0x310]
    3fdd:	lea    r9,[r12+0x314]
    3fe5:	movabs r11,0x5a1b9d18a750
    3fef:	call   r11
    3ff2:	ldmxcsr DWORD PTR [r12-0x28]
    3ff8:	movdqu xmm2,XMMWORD PTR [rsp]
    3ffd:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    4003:	mov    rbx,QWORD PTR [r12+0x108]
    400b:	mov    QWORD PTR [r12+0x378],0x2
    4017:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4020:	movdqa xmm4,xmm0
    4024:	movdqa xmm0,xmm4
    4028:	movdqu XMMWORD PTR [r12+0x260],xmm0
    4032:	mov    r13d,0x0
    4038:	mov    r14d,0x0
    403e:	mov    QWORD PTR [r12+0x1b0],r13
    4046:	mov    QWORD PTR [r12+0x1b8],r14
    404e:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    4058:	movdqa xmm2,xmm0
    405c:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    4066:	movdqa xmm3,xmm0
    406a:	cmp    DWORD PTR [r12+0x310],0x0
    4073:	jne    0x415c
    4079:	movdqa xmm0,xmm2
    407d:	movdqa xmm1,xmm3
    4081:	pshufd xmm1,xmm1,0x44
    4086:	movq   rax,xmm0
    408b:	add    rax,rax
    408e:	je     0x40a4
    4090:	shr    rax,0x35
    4094:	sub    eax,0x201
    4099:	cmp    eax,0x3fc
    409e:	ja     0x415c
    40a4:	movdqa xmm14,xmm0
    40a9:	psrldq xmm14,0x8
    40af:	movq   rax,xmm14
    40b4:	add    rax,rax
    40b7:	je     0x40cd
    40b9:	shr    rax,0x35
    40bd:	sub    eax,0x201
    40c2:	cmp    eax,0x3fc
    40c7:	ja     0x415c
    40cd:	movq   rax,xmm1
    40d2:	add    rax,rax
    40d5:	je     0x40eb
    40d7:	shr    rax,0x35
    40db:	sub    eax,0x201
    40e0:	cmp    eax,0x3fc
    40e5:	ja     0x415c
    40eb:	movdqa xmm14,xmm1
    40f0:	psrldq xmm14,0x8
    40f6:	movq   rax,xmm14
    40fb:	add    rax,rax
    40fe:	je     0x4114
    4100:	shr    rax,0x35
    4104:	sub    eax,0x201
    4109:	cmp    eax,0x3fc
    410e:	ja     0x415c
    4114:	stmxcsr DWORD PTR [rsp+0x100]
    411c:	mov    DWORD PTR [rsp+0x104],0x1f80
    4127:	ldmxcsr DWORD PTR [rsp+0x104]
    412f:	mulpd  xmm0,xmm1
    4133:	stmxcsr DWORD PTR [rsp+0x104]
    413b:	ldmxcsr DWORD PTR [rsp+0x100]
    4143:	mov    eax,DWORD PTR [rsp+0x104]
    414a:	shr    eax,1
    414c:	and    eax,0x10
    414f:	or     DWORD PTR [r12+0x314],eax
    4157:	jmp    0x4209
    415c:	movdqa xmm0,xmm2
    4160:	movdqa xmm1,xmm3
    4164:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    416d:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4176:	mov    QWORD PTR [r12+0x378],0x3
    4182:	movdqu XMMWORD PTR [rsp],xmm2
    4187:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    418d:	mov    QWORD PTR [r12+0x108],rbx
    4195:	stmxcsr DWORD PTR [r12-0x28]
    419b:	ldmxcsr DWORD PTR [r12-0x38]
    41a1:	lea    rdi,[rsp+0xf0]
    41a9:	lea    rsi,[rsp+0xd0]
    41b1:	lea    rdx,[rsp+0xe0]
    41b9:	mov    ecx,0x56
    41be:	mov    r8d,DWORD PTR [r12+0x310]
    41c6:	lea    r9,[r12+0x314]
    41ce:	movabs r11,0x5a1b9d18a750
    41d8:	call   r11
    41db:	ldmxcsr DWORD PTR [r12-0x28]
    41e1:	movdqu xmm2,XMMWORD PTR [rsp]
    41e6:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    41ec:	mov    rbx,QWORD PTR [r12+0x108]
    41f4:	mov    QWORD PTR [r12+0x378],0x2
    4200:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4209:	movdqa xmm4,xmm0
    420d:	movdqa xmm0,xmm4
    4211:	movdqu XMMWORD PTR [r12+0x230],xmm0
    421b:	mov    r13,QWORD PTR [r12+0xf8]
    4223:	mov    r14,r13
    4226:	add    r14,0xc0
    422d:	movdqu xmm2,XMMWORD PTR [r14]
    4232:	movdqa xmm0,xmm2
    4236:	movdqu XMMWORD PTR [r12+0x110],xmm0
    4240:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    424a:	movdqa xmm2,xmm0
    424e:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    4258:	movdqa xmm3,xmm0
    425c:	cmp    DWORD PTR [r12+0x310],0x0
    4265:	jne    0x4349
    426b:	movdqa xmm0,xmm2
    426f:	movdqa xmm1,xmm3
    4273:	movq   rax,xmm0
    4278:	add    rax,rax
    427b:	je     0x4291
    427d:	shr    rax,0x35
    4281:	sub    eax,0x201
    4286:	cmp    eax,0x3fc
    428b:	ja     0x4349
    4291:	movdqa xmm14,xmm0
    4296:	psrldq xmm14,0x8
    429c:	movq   rax,xmm14
    42a1:	add    rax,rax
    42a4:	je     0x42ba
    42a6:	shr    rax,0x35
    42aa:	sub    eax,0x201
    42af:	cmp    eax,0x3fc
    42b4:	ja     0x4349
    42ba:	movq   rax,xmm1
    42bf:	add    rax,rax
    42c2:	je     0x42d8
    42c4:	shr    rax,0x35
    42c8:	sub    eax,0x201
    42cd:	cmp    eax,0x3fc
    42d2:	ja     0x4349
    42d8:	movdqa xmm14,xmm1
    42dd:	psrldq xmm14,0x8
    42e3:	movq   rax,xmm14
    42e8:	add    rax,rax
    42eb:	je     0x4301
    42ed:	shr    rax,0x35
    42f1:	sub    eax,0x201
    42f6:	cmp    eax,0x3fc
    42fb:	ja     0x4349
    4301:	stmxcsr DWORD PTR [rsp+0x100]
    4309:	mov    DWORD PTR [rsp+0x104],0x1f80
    4314:	ldmxcsr DWORD PTR [rsp+0x104]
    431c:	addpd  xmm0,xmm1
    4320:	stmxcsr DWORD PTR [rsp+0x104]
    4328:	ldmxcsr DWORD PTR [rsp+0x100]
    4330:	mov    eax,DWORD PTR [rsp+0x104]
    4337:	shr    eax,1
    4339:	and    eax,0x10
    433c:	or     DWORD PTR [r12+0x314],eax
    4344:	jmp    0x43f6
    4349:	movdqa xmm0,xmm2
    434d:	movdqa xmm1,xmm3
    4351:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    435a:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4363:	mov    QWORD PTR [r12+0x378],0x3
    436f:	movdqu XMMWORD PTR [rsp],xmm2
    4374:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    437a:	mov    QWORD PTR [r12+0x108],rbx
    4382:	stmxcsr DWORD PTR [r12-0x28]
    4388:	ldmxcsr DWORD PTR [r12-0x38]
    438e:	lea    rdi,[rsp+0xf0]
    4396:	lea    rsi,[rsp+0xd0]
    439e:	lea    rdx,[rsp+0xe0]
    43a6:	mov    ecx,0x14
    43ab:	mov    r8d,DWORD PTR [r12+0x310]
    43b3:	lea    r9,[r12+0x314]
    43bb:	movabs r11,0x5a1b9d18a750
    43c5:	call   r11
    43c8:	ldmxcsr DWORD PTR [r12-0x28]
    43ce:	movdqu xmm2,XMMWORD PTR [rsp]
    43d3:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    43d9:	mov    rbx,QWORD PTR [r12+0x108]
    43e1:	mov    QWORD PTR [r12+0x378],0x2
    43ed:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    43f6:	movdqa xmm4,xmm0
    43fa:	movdqa xmm0,xmm4
    43fe:	movdqu XMMWORD PTR [r12+0x240],xmm0
    4408:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    4412:	movdqa xmm2,xmm0
    4416:	movdqa xmm0,xmm2
    441a:	movdqa xmm1,xmm2
    441e:	por    xmm0,xmm1
    4422:	movdqa xmm3,xmm0
    4426:	movdqa xmm0,xmm3
    442a:	movdqu XMMWORD PTR [r12+0x270],xmm0
    4434:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    443e:	movdqa xmm2,xmm0
    4442:	movdqa xmm0,xmm2
    4446:	movdqa xmm1,xmm2
    444a:	por    xmm0,xmm1
    444e:	movdqa xmm3,xmm0
    4452:	movdqa xmm0,xmm3
    4456:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    4460:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    446a:	movdqa xmm2,xmm0
    446e:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    4478:	movdqa xmm3,xmm0
    447c:	cmp    DWORD PTR [r12+0x310],0x0
    4485:	jne    0x456e
    448b:	movdqa xmm0,xmm2
    448f:	movdqa xmm1,xmm3
    4493:	pshufd xmm1,xmm1,0x44
    4498:	movq   rax,xmm0
    449d:	add    rax,rax
    44a0:	je     0x44b6
    44a2:	shr    rax,0x35
    44a6:	sub    eax,0x201
    44ab:	cmp    eax,0x3fc
    44b0:	ja     0x456e
    44b6:	movdqa xmm14,xmm0
    44bb:	psrldq xmm14,0x8
    44c1:	movq   rax,xmm14
    44c6:	add    rax,rax
    44c9:	je     0x44df
    44cb:	shr    rax,0x35
    44cf:	sub    eax,0x201
    44d4:	cmp    eax,0x3fc
    44d9:	ja     0x456e
    44df:	movq   rax,xmm1
    44e4:	add    rax,rax
    44e7:	je     0x44fd
    44e9:	shr    rax,0x35
    44ed:	sub    eax,0x201
    44f2:	cmp    eax,0x3fc
    44f7:	ja     0x456e
    44fd:	movdqa xmm14,xmm1
    4502:	psrldq xmm14,0x8
    4508:	movq   rax,xmm14
    450d:	add    rax,rax
    4510:	je     0x4526
    4512:	shr    rax,0x35
    4516:	sub    eax,0x201
    451b:	cmp    eax,0x3fc
    4520:	ja     0x456e
    4526:	stmxcsr DWORD PTR [rsp+0x100]
    452e:	mov    DWORD PTR [rsp+0x104],0x1f80
    4539:	ldmxcsr DWORD PTR [rsp+0x104]
    4541:	mulpd  xmm0,xmm1
    4545:	stmxcsr DWORD PTR [rsp+0x104]
    454d:	ldmxcsr DWORD PTR [rsp+0x100]
    4555:	mov    eax,DWORD PTR [rsp+0x104]
    455c:	shr    eax,1
    455e:	and    eax,0x10
    4561:	or     DWORD PTR [r12+0x314],eax
    4569:	jmp    0x461b
    456e:	movdqa xmm0,xmm2
    4572:	movdqa xmm1,xmm3
    4576:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    457f:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4588:	mov    QWORD PTR [r12+0x378],0x3
    4594:	movdqu XMMWORD PTR [rsp],xmm2
    4599:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    459f:	mov    QWORD PTR [r12+0x108],rbx
    45a7:	stmxcsr DWORD PTR [r12-0x28]
    45ad:	ldmxcsr DWORD PTR [r12-0x38]
    45b3:	lea    rdi,[rsp+0xf0]
    45bb:	lea    rsi,[rsp+0xd0]
    45c3:	lea    rdx,[rsp+0xe0]
    45cb:	mov    ecx,0x56
    45d0:	mov    r8d,DWORD PTR [r12+0x310]
    45d8:	lea    r9,[r12+0x314]
    45e0:	movabs r11,0x5a1b9d18a750
    45ea:	call   r11
    45ed:	ldmxcsr DWORD PTR [r12-0x28]
    45f3:	movdqu xmm2,XMMWORD PTR [rsp]
    45f8:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    45fe:	mov    rbx,QWORD PTR [r12+0x108]
    4606:	mov    QWORD PTR [r12+0x378],0x2
    4612:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    461b:	movdqa xmm4,xmm0
    461f:	movdqa xmm0,xmm4
    4623:	movdqu XMMWORD PTR [r12+0x250],xmm0
    462d:	mov    r13,QWORD PTR [r12+0xf8]
    4635:	mov    r14,r13
    4638:	add    r14,0x20
    463c:	movdqu xmm2,XMMWORD PTR [r14]
    4641:	movdqa xmm0,xmm2
    4645:	movdqu XMMWORD PTR [r12+0x110],xmm0
    464f:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    4659:	movdqa xmm2,xmm0
    465d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    4667:	movdqa xmm3,xmm0
    466b:	cmp    DWORD PTR [r12+0x310],0x0
    4674:	jne    0x4758
    467a:	movdqa xmm0,xmm2
    467e:	movdqa xmm1,xmm3
    4682:	movq   rax,xmm0
    4687:	add    rax,rax
    468a:	je     0x46a0
    468c:	shr    rax,0x35
    4690:	sub    eax,0x201
    4695:	cmp    eax,0x3fc
    469a:	ja     0x4758
    46a0:	movdqa xmm14,xmm0
    46a5:	psrldq xmm14,0x8
    46ab:	movq   rax,xmm14
    46b0:	add    rax,rax
    46b3:	je     0x46c9
    46b5:	shr    rax,0x35
    46b9:	sub    eax,0x201
    46be:	cmp    eax,0x3fc
    46c3:	ja     0x4758
    46c9:	movq   rax,xmm1
    46ce:	add    rax,rax
    46d1:	je     0x46e7
    46d3:	shr    rax,0x35
    46d7:	sub    eax,0x201
    46dc:	cmp    eax,0x3fc
    46e1:	ja     0x4758
    46e7:	movdqa xmm14,xmm1
    46ec:	psrldq xmm14,0x8
    46f2:	movq   rax,xmm14
    46f7:	add    rax,rax
    46fa:	je     0x4710
    46fc:	shr    rax,0x35
    4700:	sub    eax,0x201
    4705:	cmp    eax,0x3fc
    470a:	ja     0x4758
    4710:	stmxcsr DWORD PTR [rsp+0x100]
    4718:	mov    DWORD PTR [rsp+0x104],0x1f80
    4723:	ldmxcsr DWORD PTR [rsp+0x104]
    472b:	addpd  xmm0,xmm1
    472f:	stmxcsr DWORD PTR [rsp+0x104]
    4737:	ldmxcsr DWORD PTR [rsp+0x100]
    473f:	mov    eax,DWORD PTR [rsp+0x104]
    4746:	shr    eax,1
    4748:	and    eax,0x10
    474b:	or     DWORD PTR [r12+0x314],eax
    4753:	jmp    0x4805
    4758:	movdqa xmm0,xmm2
    475c:	movdqa xmm1,xmm3
    4760:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4769:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4772:	mov    QWORD PTR [r12+0x378],0x3
    477e:	movdqu XMMWORD PTR [rsp],xmm2
    4783:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4789:	mov    QWORD PTR [r12+0x108],rbx
    4791:	stmxcsr DWORD PTR [r12-0x28]
    4797:	ldmxcsr DWORD PTR [r12-0x38]
    479d:	lea    rdi,[rsp+0xf0]
    47a5:	lea    rsi,[rsp+0xd0]
    47ad:	lea    rdx,[rsp+0xe0]
    47b5:	mov    ecx,0x14
    47ba:	mov    r8d,DWORD PTR [r12+0x310]
    47c2:	lea    r9,[r12+0x314]
    47ca:	movabs r11,0x5a1b9d18a750
    47d4:	call   r11
    47d7:	ldmxcsr DWORD PTR [r12-0x28]
    47dd:	movdqu xmm2,XMMWORD PTR [rsp]
    47e2:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    47e8:	mov    rbx,QWORD PTR [r12+0x108]
    47f0:	mov    QWORD PTR [r12+0x378],0x2
    47fc:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4805:	movdqa xmm4,xmm0
    4809:	movdqa xmm0,xmm4
    480d:	movdqu XMMWORD PTR [r12+0x170],xmm0
    4817:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    4821:	movdqa xmm2,xmm0
    4825:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    482f:	movdqa xmm3,xmm0
    4833:	cmp    DWORD PTR [r12+0x310],0x0
    483c:	jne    0x4925
    4842:	movdqa xmm0,xmm2
    4846:	movdqa xmm1,xmm3
    484a:	pshufd xmm1,xmm1,0x44
    484f:	movq   rax,xmm0
    4854:	add    rax,rax
    4857:	je     0x486d
    4859:	shr    rax,0x35
    485d:	sub    eax,0x201
    4862:	cmp    eax,0x3fc
    4867:	ja     0x4925
    486d:	movdqa xmm14,xmm0
    4872:	psrldq xmm14,0x8
    4878:	movq   rax,xmm14
    487d:	add    rax,rax
    4880:	je     0x4896
    4882:	shr    rax,0x35
    4886:	sub    eax,0x201
    488b:	cmp    eax,0x3fc
    4890:	ja     0x4925
    4896:	movq   rax,xmm1
    489b:	add    rax,rax
    489e:	je     0x48b4
    48a0:	shr    rax,0x35
    48a4:	sub    eax,0x201
    48a9:	cmp    eax,0x3fc
    48ae:	ja     0x4925
    48b4:	movdqa xmm14,xmm1
    48b9:	psrldq xmm14,0x8
    48bf:	movq   rax,xmm14
    48c4:	add    rax,rax
    48c7:	je     0x48dd
    48c9:	shr    rax,0x35
    48cd:	sub    eax,0x201
    48d2:	cmp    eax,0x3fc
    48d7:	ja     0x4925
    48dd:	stmxcsr DWORD PTR [rsp+0x100]
    48e5:	mov    DWORD PTR [rsp+0x104],0x1f80
    48f0:	ldmxcsr DWORD PTR [rsp+0x104]
    48f8:	mulpd  xmm0,xmm1
    48fc:	stmxcsr DWORD PTR [rsp+0x104]
    4904:	ldmxcsr DWORD PTR [rsp+0x100]
    490c:	mov    eax,DWORD PTR [rsp+0x104]
    4913:	shr    eax,1
    4915:	and    eax,0x10
    4918:	or     DWORD PTR [r12+0x314],eax
    4920:	jmp    0x49d2
    4925:	movdqa xmm0,xmm2
    4929:	movdqa xmm1,xmm3
    492d:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4936:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    493f:	mov    QWORD PTR [r12+0x378],0x3
    494b:	movdqu XMMWORD PTR [rsp],xmm2
    4950:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4956:	mov    QWORD PTR [r12+0x108],rbx
    495e:	stmxcsr DWORD PTR [r12-0x28]
    4964:	ldmxcsr DWORD PTR [r12-0x38]
    496a:	lea    rdi,[rsp+0xf0]
    4972:	lea    rsi,[rsp+0xd0]
    497a:	lea    rdx,[rsp+0xe0]
    4982:	mov    ecx,0x56
    4987:	mov    r8d,DWORD PTR [r12+0x310]
    498f:	lea    r9,[r12+0x314]
    4997:	movabs r11,0x5a1b9d18a750
    49a1:	call   r11
    49a4:	ldmxcsr DWORD PTR [r12-0x28]
    49aa:	movdqu xmm2,XMMWORD PTR [rsp]
    49af:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    49b5:	mov    rbx,QWORD PTR [r12+0x108]
    49bd:	mov    QWORD PTR [r12+0x378],0x2
    49c9:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    49d2:	movdqa xmm4,xmm0
    49d6:	movdqa xmm0,xmm4
    49da:	movdqu XMMWORD PTR [r12+0x160],xmm0
    49e4:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    49ee:	movdqa xmm2,xmm0
    49f2:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    49fc:	movdqa xmm3,xmm0
    4a00:	cmp    DWORD PTR [r12+0x310],0x0
    4a09:	jne    0x4aed
    4a0f:	movdqa xmm0,xmm2
    4a13:	movdqa xmm1,xmm3
    4a17:	movq   rax,xmm0
    4a1c:	add    rax,rax
    4a1f:	je     0x4a35
    4a21:	shr    rax,0x35
    4a25:	sub    eax,0x201
    4a2a:	cmp    eax,0x3fc
    4a2f:	ja     0x4aed
    4a35:	movdqa xmm14,xmm0
    4a3a:	psrldq xmm14,0x8
    4a40:	movq   rax,xmm14
    4a45:	add    rax,rax
    4a48:	je     0x4a5e
    4a4a:	shr    rax,0x35
    4a4e:	sub    eax,0x201
    4a53:	cmp    eax,0x3fc
    4a58:	ja     0x4aed
    4a5e:	movq   rax,xmm1
    4a63:	add    rax,rax
    4a66:	je     0x4a7c
    4a68:	shr    rax,0x35
    4a6c:	sub    eax,0x201
    4a71:	cmp    eax,0x3fc
    4a76:	ja     0x4aed
    4a7c:	movdqa xmm14,xmm1
    4a81:	psrldq xmm14,0x8
    4a87:	movq   rax,xmm14
    4a8c:	add    rax,rax
    4a8f:	je     0x4aa5
    4a91:	shr    rax,0x35
    4a95:	sub    eax,0x201
    4a9a:	cmp    eax,0x3fc
    4a9f:	ja     0x4aed
    4aa5:	stmxcsr DWORD PTR [rsp+0x100]
    4aad:	mov    DWORD PTR [rsp+0x104],0x1f80
    4ab8:	ldmxcsr DWORD PTR [rsp+0x104]
    4ac0:	addpd  xmm0,xmm1
    4ac4:	stmxcsr DWORD PTR [rsp+0x104]
    4acc:	ldmxcsr DWORD PTR [rsp+0x100]
    4ad4:	mov    eax,DWORD PTR [rsp+0x104]
    4adb:	shr    eax,1
    4add:	and    eax,0x10
    4ae0:	or     DWORD PTR [r12+0x314],eax
    4ae8:	jmp    0x4b9a
    4aed:	movdqa xmm0,xmm2
    4af1:	movdqa xmm1,xmm3
    4af5:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4afe:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4b07:	mov    QWORD PTR [r12+0x378],0x3
    4b13:	movdqu XMMWORD PTR [rsp],xmm2
    4b18:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4b1e:	mov    QWORD PTR [r12+0x108],rbx
    4b26:	stmxcsr DWORD PTR [r12-0x28]
    4b2c:	ldmxcsr DWORD PTR [r12-0x38]
    4b32:	lea    rdi,[rsp+0xf0]
    4b3a:	lea    rsi,[rsp+0xd0]
    4b42:	lea    rdx,[rsp+0xe0]
    4b4a:	mov    ecx,0x14
    4b4f:	mov    r8d,DWORD PTR [r12+0x310]
    4b57:	lea    r9,[r12+0x314]
    4b5f:	movabs r11,0x5a1b9d18a750
    4b69:	call   r11
    4b6c:	ldmxcsr DWORD PTR [r12-0x28]
    4b72:	movdqu xmm2,XMMWORD PTR [rsp]
    4b77:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    4b7d:	mov    rbx,QWORD PTR [r12+0x108]
    4b85:	mov    QWORD PTR [r12+0x378],0x2
    4b91:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4b9a:	movdqa xmm4,xmm0
    4b9e:	movdqa xmm0,xmm4
    4ba2:	movdqu XMMWORD PTR [r12+0x180],xmm0
    4bac:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    4bb6:	movdqa xmm2,xmm0
    4bba:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    4bc4:	movdqa xmm3,xmm0
    4bc8:	cmp    DWORD PTR [r12+0x310],0x0
    4bd1:	jne    0x4cba
    4bd7:	movdqa xmm0,xmm2
    4bdb:	movdqa xmm1,xmm3
    4bdf:	pshufd xmm1,xmm1,0x44
    4be4:	movq   rax,xmm0
    4be9:	add    rax,rax
    4bec:	je     0x4c02
    4bee:	shr    rax,0x35
    4bf2:	sub    eax,0x201
    4bf7:	cmp    eax,0x3fc
    4bfc:	ja     0x4cba
    4c02:	movdqa xmm14,xmm0
    4c07:	psrldq xmm14,0x8
    4c0d:	movq   rax,xmm14
    4c12:	add    rax,rax
    4c15:	je     0x4c2b
    4c17:	shr    rax,0x35
    4c1b:	sub    eax,0x201
    4c20:	cmp    eax,0x3fc
    4c25:	ja     0x4cba
    4c2b:	movq   rax,xmm1
    4c30:	add    rax,rax
    4c33:	je     0x4c49
    4c35:	shr    rax,0x35
    4c39:	sub    eax,0x201
    4c3e:	cmp    eax,0x3fc
    4c43:	ja     0x4cba
    4c49:	movdqa xmm14,xmm1
    4c4e:	psrldq xmm14,0x8
    4c54:	movq   rax,xmm14
    4c59:	add    rax,rax
    4c5c:	je     0x4c72
    4c5e:	shr    rax,0x35
    4c62:	sub    eax,0x201
    4c67:	cmp    eax,0x3fc
    4c6c:	ja     0x4cba
    4c72:	stmxcsr DWORD PTR [rsp+0x100]
    4c7a:	mov    DWORD PTR [rsp+0x104],0x1f80
    4c85:	ldmxcsr DWORD PTR [rsp+0x104]
    4c8d:	mulpd  xmm0,xmm1
    4c91:	stmxcsr DWORD PTR [rsp+0x104]
    4c99:	ldmxcsr DWORD PTR [rsp+0x100]
    4ca1:	mov    eax,DWORD PTR [rsp+0x104]
    4ca8:	shr    eax,1
    4caa:	and    eax,0x10
    4cad:	or     DWORD PTR [r12+0x314],eax
    4cb5:	jmp    0x4d67
    4cba:	movdqa xmm0,xmm2
    4cbe:	movdqa xmm1,xmm3
    4cc2:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4ccb:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4cd4:	mov    QWORD PTR [r12+0x378],0x3
    4ce0:	movdqu XMMWORD PTR [rsp],xmm2
    4ce5:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4ceb:	mov    QWORD PTR [r12+0x108],rbx
    4cf3:	stmxcsr DWORD PTR [r12-0x28]
    4cf9:	ldmxcsr DWORD PTR [r12-0x38]
    4cff:	lea    rdi,[rsp+0xf0]
    4d07:	lea    rsi,[rsp+0xd0]
    4d0f:	lea    rdx,[rsp+0xe0]
    4d17:	mov    ecx,0x56
    4d1c:	mov    r8d,DWORD PTR [r12+0x310]
    4d24:	lea    r9,[r12+0x314]
    4d2c:	movabs r11,0x5a1b9d18a750
    4d36:	call   r11
    4d39:	ldmxcsr DWORD PTR [r12-0x28]
    4d3f:	movdqu xmm2,XMMWORD PTR [rsp]
    4d44:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    4d4a:	mov    rbx,QWORD PTR [r12+0x108]
    4d52:	mov    QWORD PTR [r12+0x378],0x2
    4d5e:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4d67:	movdqa xmm4,xmm0
    4d6b:	movdqa xmm0,xmm4
    4d6f:	movdqu XMMWORD PTR [r12+0x210],xmm0
    4d79:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    4d83:	movdqa xmm2,xmm0
    4d87:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    4d91:	movdqa xmm3,xmm0
    4d95:	cmp    DWORD PTR [r12+0x310],0x0
    4d9e:	jne    0x4e87
    4da4:	movdqa xmm0,xmm2
    4da8:	movdqa xmm1,xmm3
    4dac:	pshufd xmm1,xmm1,0x44
    4db1:	movq   rax,xmm0
    4db6:	add    rax,rax
    4db9:	je     0x4dcf
    4dbb:	shr    rax,0x35
    4dbf:	sub    eax,0x201
    4dc4:	cmp    eax,0x3fc
    4dc9:	ja     0x4e87
    4dcf:	movdqa xmm14,xmm0
    4dd4:	psrldq xmm14,0x8
    4dda:	movq   rax,xmm14
    4ddf:	add    rax,rax
    4de2:	je     0x4df8
    4de4:	shr    rax,0x35
    4de8:	sub    eax,0x201
    4ded:	cmp    eax,0x3fc
    4df2:	ja     0x4e87
    4df8:	movq   rax,xmm1
    4dfd:	add    rax,rax
    4e00:	je     0x4e16
    4e02:	shr    rax,0x35
    4e06:	sub    eax,0x201
    4e0b:	cmp    eax,0x3fc
    4e10:	ja     0x4e87
    4e16:	movdqa xmm14,xmm1
    4e1b:	psrldq xmm14,0x8
    4e21:	movq   rax,xmm14
    4e26:	add    rax,rax
    4e29:	je     0x4e3f
    4e2b:	shr    rax,0x35
    4e2f:	sub    eax,0x201
    4e34:	cmp    eax,0x3fc
    4e39:	ja     0x4e87
    4e3f:	stmxcsr DWORD PTR [rsp+0x100]
    4e47:	mov    DWORD PTR [rsp+0x104],0x1f80
    4e52:	ldmxcsr DWORD PTR [rsp+0x104]
    4e5a:	mulpd  xmm0,xmm1
    4e5e:	stmxcsr DWORD PTR [rsp+0x104]
    4e66:	ldmxcsr DWORD PTR [rsp+0x100]
    4e6e:	mov    eax,DWORD PTR [rsp+0x104]
    4e75:	shr    eax,1
    4e77:	and    eax,0x10
    4e7a:	or     DWORD PTR [r12+0x314],eax
    4e82:	jmp    0x4f34
    4e87:	movdqa xmm0,xmm2
    4e8b:	movdqa xmm1,xmm3
    4e8f:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    4e98:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    4ea1:	mov    QWORD PTR [r12+0x378],0x3
    4ead:	movdqu XMMWORD PTR [rsp],xmm2
    4eb2:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    4eb8:	mov    QWORD PTR [r12+0x108],rbx
    4ec0:	stmxcsr DWORD PTR [r12-0x28]
    4ec6:	ldmxcsr DWORD PTR [r12-0x38]
    4ecc:	lea    rdi,[rsp+0xf0]
    4ed4:	lea    rsi,[rsp+0xd0]
    4edc:	lea    rdx,[rsp+0xe0]
    4ee4:	mov    ecx,0x56
    4ee9:	mov    r8d,DWORD PTR [r12+0x310]
    4ef1:	lea    r9,[r12+0x314]
    4ef9:	movabs r11,0x5a1b9d18a750
    4f03:	call   r11
    4f06:	ldmxcsr DWORD PTR [r12-0x28]
    4f0c:	movdqu xmm2,XMMWORD PTR [rsp]
    4f11:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    4f17:	mov    rbx,QWORD PTR [r12+0x108]
    4f1f:	mov    QWORD PTR [r12+0x378],0x2
    4f2b:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    4f34:	movdqa xmm4,xmm0
    4f38:	movdqa xmm0,xmm4
    4f3c:	movdqu XMMWORD PTR [r12+0x230],xmm0
    4f46:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    4f50:	movdqa xmm2,xmm0
    4f54:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    4f5e:	movdqa xmm3,xmm0
    4f62:	cmp    DWORD PTR [r12+0x310],0x0
    4f6b:	jne    0x504f
    4f71:	movdqa xmm0,xmm2
    4f75:	movdqa xmm1,xmm3
    4f79:	movq   rax,xmm0
    4f7e:	add    rax,rax
    4f81:	je     0x4f97
    4f83:	shr    rax,0x35
    4f87:	sub    eax,0x201
    4f8c:	cmp    eax,0x3fc
    4f91:	ja     0x504f
    4f97:	movdqa xmm14,xmm0
    4f9c:	psrldq xmm14,0x8
    4fa2:	movq   rax,xmm14
    4fa7:	add    rax,rax
    4faa:	je     0x4fc0
    4fac:	shr    rax,0x35
    4fb0:	sub    eax,0x201
    4fb5:	cmp    eax,0x3fc
    4fba:	ja     0x504f
    4fc0:	movq   rax,xmm1
    4fc5:	add    rax,rax
    4fc8:	je     0x4fde
    4fca:	shr    rax,0x35
    4fce:	sub    eax,0x201
    4fd3:	cmp    eax,0x3fc
    4fd8:	ja     0x504f
    4fde:	movdqa xmm14,xmm1
    4fe3:	psrldq xmm14,0x8
    4fe9:	movq   rax,xmm14
    4fee:	add    rax,rax
    4ff1:	je     0x5007
    4ff3:	shr    rax,0x35
    4ff7:	sub    eax,0x201
    4ffc:	cmp    eax,0x3fc
    5001:	ja     0x504f
    5007:	stmxcsr DWORD PTR [rsp+0x100]
    500f:	mov    DWORD PTR [rsp+0x104],0x1f80
    501a:	ldmxcsr DWORD PTR [rsp+0x104]
    5022:	addpd  xmm0,xmm1
    5026:	stmxcsr DWORD PTR [rsp+0x104]
    502e:	ldmxcsr DWORD PTR [rsp+0x100]
    5036:	mov    eax,DWORD PTR [rsp+0x104]
    503d:	shr    eax,1
    503f:	and    eax,0x10
    5042:	or     DWORD PTR [r12+0x314],eax
    504a:	jmp    0x50fc
    504f:	movdqa xmm0,xmm2
    5053:	movdqa xmm1,xmm3
    5057:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5060:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5069:	mov    QWORD PTR [r12+0x378],0x3
    5075:	movdqu XMMWORD PTR [rsp],xmm2
    507a:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5080:	mov    QWORD PTR [r12+0x108],rbx
    5088:	stmxcsr DWORD PTR [r12-0x28]
    508e:	ldmxcsr DWORD PTR [r12-0x38]
    5094:	lea    rdi,[rsp+0xf0]
    509c:	lea    rsi,[rsp+0xd0]
    50a4:	lea    rdx,[rsp+0xe0]
    50ac:	mov    ecx,0x14
    50b1:	mov    r8d,DWORD PTR [r12+0x310]
    50b9:	lea    r9,[r12+0x314]
    50c1:	movabs r11,0x5a1b9d18a750
    50cb:	call   r11
    50ce:	ldmxcsr DWORD PTR [r12-0x28]
    50d4:	movdqu xmm2,XMMWORD PTR [rsp]
    50d9:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    50df:	mov    rbx,QWORD PTR [r12+0x108]
    50e7:	mov    QWORD PTR [r12+0x378],0x2
    50f3:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    50fc:	movdqa xmm4,xmm0
    5100:	movdqa xmm0,xmm4
    5104:	movdqu XMMWORD PTR [r12+0x240],xmm0
    510e:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    5118:	movdqa xmm2,xmm0
    511c:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    5126:	movdqa xmm3,xmm0
    512a:	cmp    DWORD PTR [r12+0x310],0x0
    5133:	jne    0x5217
    5139:	movdqa xmm0,xmm2
    513d:	movdqa xmm1,xmm3
    5141:	movq   rax,xmm0
    5146:	add    rax,rax
    5149:	je     0x515f
    514b:	shr    rax,0x35
    514f:	sub    eax,0x201
    5154:	cmp    eax,0x3fc
    5159:	ja     0x5217
    515f:	movdqa xmm14,xmm0
    5164:	psrldq xmm14,0x8
    516a:	movq   rax,xmm14
    516f:	add    rax,rax
    5172:	je     0x5188
    5174:	shr    rax,0x35
    5178:	sub    eax,0x201
    517d:	cmp    eax,0x3fc
    5182:	ja     0x5217
    5188:	movq   rax,xmm1
    518d:	add    rax,rax
    5190:	je     0x51a6
    5192:	shr    rax,0x35
    5196:	sub    eax,0x201
    519b:	cmp    eax,0x3fc
    51a0:	ja     0x5217
    51a6:	movdqa xmm14,xmm1
    51ab:	psrldq xmm14,0x8
    51b1:	movq   rax,xmm14
    51b6:	add    rax,rax
    51b9:	je     0x51cf
    51bb:	shr    rax,0x35
    51bf:	sub    eax,0x201
    51c4:	cmp    eax,0x3fc
    51c9:	ja     0x5217
    51cf:	stmxcsr DWORD PTR [rsp+0x100]
    51d7:	mov    DWORD PTR [rsp+0x104],0x1f80
    51e2:	ldmxcsr DWORD PTR [rsp+0x104]
    51ea:	addpd  xmm0,xmm1
    51ee:	stmxcsr DWORD PTR [rsp+0x104]
    51f6:	ldmxcsr DWORD PTR [rsp+0x100]
    51fe:	mov    eax,DWORD PTR [rsp+0x104]
    5205:	shr    eax,1
    5207:	and    eax,0x10
    520a:	or     DWORD PTR [r12+0x314],eax
    5212:	jmp    0x52c4
    5217:	movdqa xmm0,xmm2
    521b:	movdqa xmm1,xmm3
    521f:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5228:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5231:	mov    QWORD PTR [r12+0x378],0x3
    523d:	movdqu XMMWORD PTR [rsp],xmm2
    5242:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5248:	mov    QWORD PTR [r12+0x108],rbx
    5250:	stmxcsr DWORD PTR [r12-0x28]
    5256:	ldmxcsr DWORD PTR [r12-0x38]
    525c:	lea    rdi,[rsp+0xf0]
    5264:	lea    rsi,[rsp+0xd0]
    526c:	lea    rdx,[rsp+0xe0]
    5274:	mov    ecx,0x14
    5279:	mov    r8d,DWORD PTR [r12+0x310]
    5281:	lea    r9,[r12+0x314]
    5289:	movabs r11,0x5a1b9d18a750
    5293:	call   r11
    5296:	ldmxcsr DWORD PTR [r12-0x28]
    529c:	movdqu xmm2,XMMWORD PTR [rsp]
    52a1:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    52a7:	mov    rbx,QWORD PTR [r12+0x108]
    52af:	mov    QWORD PTR [r12+0x378],0x2
    52bb:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    52c4:	movdqa xmm4,xmm0
    52c8:	movdqa xmm0,xmm4
    52cc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    52d6:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    52e0:	movdqa xmm2,xmm0
    52e4:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    52ee:	movdqa xmm3,xmm0
    52f2:	cmp    DWORD PTR [r12+0x310],0x0
    52fb:	jne    0x53e4
    5301:	movdqa xmm0,xmm2
    5305:	movdqa xmm1,xmm3
    5309:	pshufd xmm1,xmm1,0x44
    530e:	movq   rax,xmm0
    5313:	add    rax,rax
    5316:	je     0x532c
    5318:	shr    rax,0x35
    531c:	sub    eax,0x201
    5321:	cmp    eax,0x3fc
    5326:	ja     0x53e4
    532c:	movdqa xmm14,xmm0
    5331:	psrldq xmm14,0x8
    5337:	movq   rax,xmm14
    533c:	add    rax,rax
    533f:	je     0x5355
    5341:	shr    rax,0x35
    5345:	sub    eax,0x201
    534a:	cmp    eax,0x3fc
    534f:	ja     0x53e4
    5355:	movq   rax,xmm1
    535a:	add    rax,rax
    535d:	je     0x5373
    535f:	shr    rax,0x35
    5363:	sub    eax,0x201
    5368:	cmp    eax,0x3fc
    536d:	ja     0x53e4
    5373:	movdqa xmm14,xmm1
    5378:	psrldq xmm14,0x8
    537e:	movq   rax,xmm14
    5383:	add    rax,rax
    5386:	je     0x539c
    5388:	shr    rax,0x35
    538c:	sub    eax,0x201
    5391:	cmp    eax,0x3fc
    5396:	ja     0x53e4
    539c:	stmxcsr DWORD PTR [rsp+0x100]
    53a4:	mov    DWORD PTR [rsp+0x104],0x1f80
    53af:	ldmxcsr DWORD PTR [rsp+0x104]
    53b7:	mulpd  xmm0,xmm1
    53bb:	stmxcsr DWORD PTR [rsp+0x104]
    53c3:	ldmxcsr DWORD PTR [rsp+0x100]
    53cb:	mov    eax,DWORD PTR [rsp+0x104]
    53d2:	shr    eax,1
    53d4:	and    eax,0x10
    53d7:	or     DWORD PTR [r12+0x314],eax
    53df:	jmp    0x5491
    53e4:	movdqa xmm0,xmm2
    53e8:	movdqa xmm1,xmm3
    53ec:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    53f5:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    53fe:	mov    QWORD PTR [r12+0x378],0x3
    540a:	movdqu XMMWORD PTR [rsp],xmm2
    540f:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5415:	mov    QWORD PTR [r12+0x108],rbx
    541d:	stmxcsr DWORD PTR [r12-0x28]
    5423:	ldmxcsr DWORD PTR [r12-0x38]
    5429:	lea    rdi,[rsp+0xf0]
    5431:	lea    rsi,[rsp+0xd0]
    5439:	lea    rdx,[rsp+0xe0]
    5441:	mov    ecx,0x56
    5446:	mov    r8d,DWORD PTR [r12+0x310]
    544e:	lea    r9,[r12+0x314]
    5456:	movabs r11,0x5a1b9d18a750
    5460:	call   r11
    5463:	ldmxcsr DWORD PTR [r12-0x28]
    5469:	movdqu xmm2,XMMWORD PTR [rsp]
    546e:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5474:	mov    rbx,QWORD PTR [r12+0x108]
    547c:	mov    QWORD PTR [r12+0x378],0x2
    5488:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5491:	movdqa xmm4,xmm0
    5495:	movdqa xmm0,xmm4
    5499:	movdqu XMMWORD PTR [r12+0x250],xmm0
    54a3:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    54ad:	movdqa xmm2,xmm0
    54b1:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    54bb:	movdqa xmm3,xmm0
    54bf:	cmp    DWORD PTR [r12+0x310],0x0
    54c8:	jne    0x55b1
    54ce:	movdqa xmm0,xmm2
    54d2:	movdqa xmm1,xmm3
    54d6:	pshufd xmm1,xmm1,0x44
    54db:	movq   rax,xmm0
    54e0:	add    rax,rax
    54e3:	je     0x54f9
    54e5:	shr    rax,0x35
    54e9:	sub    eax,0x201
    54ee:	cmp    eax,0x3fc
    54f3:	ja     0x55b1
    54f9:	movdqa xmm14,xmm0
    54fe:	psrldq xmm14,0x8
    5504:	movq   rax,xmm14
    5509:	add    rax,rax
    550c:	je     0x5522
    550e:	shr    rax,0x35
    5512:	sub    eax,0x201
    5517:	cmp    eax,0x3fc
    551c:	ja     0x55b1
    5522:	movq   rax,xmm1
    5527:	add    rax,rax
    552a:	je     0x5540
    552c:	shr    rax,0x35
    5530:	sub    eax,0x201
    5535:	cmp    eax,0x3fc
    553a:	ja     0x55b1
    5540:	movdqa xmm14,xmm1
    5545:	psrldq xmm14,0x8
    554b:	movq   rax,xmm14
    5550:	add    rax,rax
    5553:	je     0x5569
    5555:	shr    rax,0x35
    5559:	sub    eax,0x201
    555e:	cmp    eax,0x3fc
    5563:	ja     0x55b1
    5569:	stmxcsr DWORD PTR [rsp+0x100]
    5571:	mov    DWORD PTR [rsp+0x104],0x1f80
    557c:	ldmxcsr DWORD PTR [rsp+0x104]
    5584:	mulpd  xmm0,xmm1
    5588:	stmxcsr DWORD PTR [rsp+0x104]
    5590:	ldmxcsr DWORD PTR [rsp+0x100]
    5598:	mov    eax,DWORD PTR [rsp+0x104]
    559f:	shr    eax,1
    55a1:	and    eax,0x10
    55a4:	or     DWORD PTR [r12+0x314],eax
    55ac:	jmp    0x565e
    55b1:	movdqa xmm0,xmm2
    55b5:	movdqa xmm1,xmm3
    55b9:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    55c2:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    55cb:	mov    QWORD PTR [r12+0x378],0x3
    55d7:	movdqu XMMWORD PTR [rsp],xmm2
    55dc:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    55e2:	mov    QWORD PTR [r12+0x108],rbx
    55ea:	stmxcsr DWORD PTR [r12-0x28]
    55f0:	ldmxcsr DWORD PTR [r12-0x38]
    55f6:	lea    rdi,[rsp+0xf0]
    55fe:	lea    rsi,[rsp+0xd0]
    5606:	lea    rdx,[rsp+0xe0]
    560e:	mov    ecx,0x56
    5613:	mov    r8d,DWORD PTR [r12+0x310]
    561b:	lea    r9,[r12+0x314]
    5623:	movabs r11,0x5a1b9d18a750
    562d:	call   r11
    5630:	ldmxcsr DWORD PTR [r12-0x28]
    5636:	movdqu xmm2,XMMWORD PTR [rsp]
    563b:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5641:	mov    rbx,QWORD PTR [r12+0x108]
    5649:	mov    QWORD PTR [r12+0x378],0x2
    5655:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    565e:	movdqa xmm4,xmm0
    5662:	movdqa xmm0,xmm4
    5666:	movdqu XMMWORD PTR [r12+0x150],xmm0
    5670:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    567a:	movdqa xmm2,xmm0
    567e:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    5688:	movdqa xmm3,xmm0
    568c:	cmp    DWORD PTR [r12+0x310],0x0
    5695:	jne    0x5779
    569b:	movdqa xmm0,xmm2
    569f:	movdqa xmm1,xmm3
    56a3:	movq   rax,xmm0
    56a8:	add    rax,rax
    56ab:	je     0x56c1
    56ad:	shr    rax,0x35
    56b1:	sub    eax,0x201
    56b6:	cmp    eax,0x3fc
    56bb:	ja     0x5779
    56c1:	movdqa xmm14,xmm0
    56c6:	psrldq xmm14,0x8
    56cc:	movq   rax,xmm14
    56d1:	add    rax,rax
    56d4:	je     0x56ea
    56d6:	shr    rax,0x35
    56da:	sub    eax,0x201
    56df:	cmp    eax,0x3fc
    56e4:	ja     0x5779
    56ea:	movq   rax,xmm1
    56ef:	add    rax,rax
    56f2:	je     0x5708
    56f4:	shr    rax,0x35
    56f8:	sub    eax,0x201
    56fd:	cmp    eax,0x3fc
    5702:	ja     0x5779
    5708:	movdqa xmm14,xmm1
    570d:	psrldq xmm14,0x8
    5713:	movq   rax,xmm14
    5718:	add    rax,rax
    571b:	je     0x5731
    571d:	shr    rax,0x35
    5721:	sub    eax,0x201
    5726:	cmp    eax,0x3fc
    572b:	ja     0x5779
    5731:	stmxcsr DWORD PTR [rsp+0x100]
    5739:	mov    DWORD PTR [rsp+0x104],0x1f80
    5744:	ldmxcsr DWORD PTR [rsp+0x104]
    574c:	addpd  xmm0,xmm1
    5750:	stmxcsr DWORD PTR [rsp+0x104]
    5758:	ldmxcsr DWORD PTR [rsp+0x100]
    5760:	mov    eax,DWORD PTR [rsp+0x104]
    5767:	shr    eax,1
    5769:	and    eax,0x10
    576c:	or     DWORD PTR [r12+0x314],eax
    5774:	jmp    0x5826
    5779:	movdqa xmm0,xmm2
    577d:	movdqa xmm1,xmm3
    5781:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    578a:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5793:	mov    QWORD PTR [r12+0x378],0x3
    579f:	movdqu XMMWORD PTR [rsp],xmm2
    57a4:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    57aa:	mov    QWORD PTR [r12+0x108],rbx
    57b2:	stmxcsr DWORD PTR [r12-0x28]
    57b8:	ldmxcsr DWORD PTR [r12-0x38]
    57be:	lea    rdi,[rsp+0xf0]
    57c6:	lea    rsi,[rsp+0xd0]
    57ce:	lea    rdx,[rsp+0xe0]
    57d6:	mov    ecx,0x14
    57db:	mov    r8d,DWORD PTR [r12+0x310]
    57e3:	lea    r9,[r12+0x314]
    57eb:	movabs r11,0x5a1b9d18a750
    57f5:	call   r11
    57f8:	ldmxcsr DWORD PTR [r12-0x28]
    57fe:	movdqu xmm2,XMMWORD PTR [rsp]
    5803:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5809:	mov    rbx,QWORD PTR [r12+0x108]
    5811:	mov    QWORD PTR [r12+0x378],0x2
    581d:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5826:	movdqa xmm4,xmm0
    582a:	movdqa xmm0,xmm4
    582e:	movdqu XMMWORD PTR [r12+0x160],xmm0
    5838:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    5842:	movdqa xmm2,xmm0
    5846:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    5850:	movdqa xmm3,xmm0
    5854:	cmp    DWORD PTR [r12+0x310],0x0
    585d:	jne    0x5941
    5863:	movdqa xmm0,xmm2
    5867:	movdqa xmm1,xmm3
    586b:	movq   rax,xmm0
    5870:	add    rax,rax
    5873:	je     0x5889
    5875:	shr    rax,0x35
    5879:	sub    eax,0x201
    587e:	cmp    eax,0x3fc
    5883:	ja     0x5941
    5889:	movdqa xmm14,xmm0
    588e:	psrldq xmm14,0x8
    5894:	movq   rax,xmm14
    5899:	add    rax,rax
    589c:	je     0x58b2
    589e:	shr    rax,0x35
    58a2:	sub    eax,0x201
    58a7:	cmp    eax,0x3fc
    58ac:	ja     0x5941
    58b2:	movq   rax,xmm1
    58b7:	add    rax,rax
    58ba:	je     0x58d0
    58bc:	shr    rax,0x35
    58c0:	sub    eax,0x201
    58c5:	cmp    eax,0x3fc
    58ca:	ja     0x5941
    58d0:	movdqa xmm14,xmm1
    58d5:	psrldq xmm14,0x8
    58db:	movq   rax,xmm14
    58e0:	add    rax,rax
    58e3:	je     0x58f9
    58e5:	shr    rax,0x35
    58e9:	sub    eax,0x201
    58ee:	cmp    eax,0x3fc
    58f3:	ja     0x5941
    58f9:	stmxcsr DWORD PTR [rsp+0x100]
    5901:	mov    DWORD PTR [rsp+0x104],0x1f80
    590c:	ldmxcsr DWORD PTR [rsp+0x104]
    5914:	addpd  xmm0,xmm1
    5918:	stmxcsr DWORD PTR [rsp+0x104]
    5920:	ldmxcsr DWORD PTR [rsp+0x100]
    5928:	mov    eax,DWORD PTR [rsp+0x104]
    592f:	shr    eax,1
    5931:	and    eax,0x10
    5934:	or     DWORD PTR [r12+0x314],eax
    593c:	jmp    0x59ee
    5941:	movdqa xmm0,xmm2
    5945:	movdqa xmm1,xmm3
    5949:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5952:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    595b:	mov    QWORD PTR [r12+0x378],0x3
    5967:	movdqu XMMWORD PTR [rsp],xmm2
    596c:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5972:	mov    QWORD PTR [r12+0x108],rbx
    597a:	stmxcsr DWORD PTR [r12-0x28]
    5980:	ldmxcsr DWORD PTR [r12-0x38]
    5986:	lea    rdi,[rsp+0xf0]
    598e:	lea    rsi,[rsp+0xd0]
    5996:	lea    rdx,[rsp+0xe0]
    599e:	mov    ecx,0x14
    59a3:	mov    r8d,DWORD PTR [r12+0x310]
    59ab:	lea    r9,[r12+0x314]
    59b3:	movabs r11,0x5a1b9d18a750
    59bd:	call   r11
    59c0:	ldmxcsr DWORD PTR [r12-0x28]
    59c6:	movdqu xmm2,XMMWORD PTR [rsp]
    59cb:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    59d1:	mov    rbx,QWORD PTR [r12+0x108]
    59d9:	mov    QWORD PTR [r12+0x378],0x2
    59e5:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    59ee:	movdqa xmm4,xmm0
    59f2:	movdqa xmm0,xmm4
    59f6:	movdqu XMMWORD PTR [r12+0x170],xmm0
    5a00:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    5a0a:	movdqa xmm2,xmm0
    5a0e:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    5a18:	movdqa xmm3,xmm0
    5a1c:	cmp    DWORD PTR [r12+0x310],0x0
    5a25:	jne    0x5b0e
    5a2b:	movdqa xmm0,xmm2
    5a2f:	movdqa xmm1,xmm3
    5a33:	pshufd xmm1,xmm1,0x44
    5a38:	movq   rax,xmm0
    5a3d:	add    rax,rax
    5a40:	je     0x5a56
    5a42:	shr    rax,0x35
    5a46:	sub    eax,0x201
    5a4b:	cmp    eax,0x3fc
    5a50:	ja     0x5b0e
    5a56:	movdqa xmm14,xmm0
    5a5b:	psrldq xmm14,0x8
    5a61:	movq   rax,xmm14
    5a66:	add    rax,rax
    5a69:	je     0x5a7f
    5a6b:	shr    rax,0x35
    5a6f:	sub    eax,0x201
    5a74:	cmp    eax,0x3fc
    5a79:	ja     0x5b0e
    5a7f:	movq   rax,xmm1
    5a84:	add    rax,rax
    5a87:	je     0x5a9d
    5a89:	shr    rax,0x35
    5a8d:	sub    eax,0x201
    5a92:	cmp    eax,0x3fc
    5a97:	ja     0x5b0e
    5a9d:	movdqa xmm14,xmm1
    5aa2:	psrldq xmm14,0x8
    5aa8:	movq   rax,xmm14
    5aad:	add    rax,rax
    5ab0:	je     0x5ac6
    5ab2:	shr    rax,0x35
    5ab6:	sub    eax,0x201
    5abb:	cmp    eax,0x3fc
    5ac0:	ja     0x5b0e
    5ac6:	stmxcsr DWORD PTR [rsp+0x100]
    5ace:	mov    DWORD PTR [rsp+0x104],0x1f80
    5ad9:	ldmxcsr DWORD PTR [rsp+0x104]
    5ae1:	mulpd  xmm0,xmm1
    5ae5:	stmxcsr DWORD PTR [rsp+0x104]
    5aed:	ldmxcsr DWORD PTR [rsp+0x100]
    5af5:	mov    eax,DWORD PTR [rsp+0x104]
    5afc:	shr    eax,1
    5afe:	and    eax,0x10
    5b01:	or     DWORD PTR [r12+0x314],eax
    5b09:	jmp    0x5bbb
    5b0e:	movdqa xmm0,xmm2
    5b12:	movdqa xmm1,xmm3
    5b16:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5b1f:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5b28:	mov    QWORD PTR [r12+0x378],0x3
    5b34:	movdqu XMMWORD PTR [rsp],xmm2
    5b39:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5b3f:	mov    QWORD PTR [r12+0x108],rbx
    5b47:	stmxcsr DWORD PTR [r12-0x28]
    5b4d:	ldmxcsr DWORD PTR [r12-0x38]
    5b53:	lea    rdi,[rsp+0xf0]
    5b5b:	lea    rsi,[rsp+0xd0]
    5b63:	lea    rdx,[rsp+0xe0]
    5b6b:	mov    ecx,0x56
    5b70:	mov    r8d,DWORD PTR [r12+0x310]
    5b78:	lea    r9,[r12+0x314]
    5b80:	movabs r11,0x5a1b9d18a750
    5b8a:	call   r11
    5b8d:	ldmxcsr DWORD PTR [r12-0x28]
    5b93:	movdqu xmm2,XMMWORD PTR [rsp]
    5b98:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5b9e:	mov    rbx,QWORD PTR [r12+0x108]
    5ba6:	mov    QWORD PTR [r12+0x378],0x2
    5bb2:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5bbb:	movdqa xmm4,xmm0
    5bbf:	movdqa xmm0,xmm4
    5bc3:	movdqu XMMWORD PTR [r12+0x180],xmm0
    5bcd:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    5bd7:	movdqa xmm2,xmm0
    5bdb:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    5be5:	movdqa xmm3,xmm0
    5be9:	cmp    DWORD PTR [r12+0x310],0x0
    5bf2:	jne    0x5cd6
    5bf8:	movdqa xmm0,xmm2
    5bfc:	movdqa xmm1,xmm3
    5c00:	movq   rax,xmm0
    5c05:	add    rax,rax
    5c08:	je     0x5c1e
    5c0a:	shr    rax,0x35
    5c0e:	sub    eax,0x201
    5c13:	cmp    eax,0x3fc
    5c18:	ja     0x5cd6
    5c1e:	movdqa xmm14,xmm0
    5c23:	psrldq xmm14,0x8
    5c29:	movq   rax,xmm14
    5c2e:	add    rax,rax
    5c31:	je     0x5c47
    5c33:	shr    rax,0x35
    5c37:	sub    eax,0x201
    5c3c:	cmp    eax,0x3fc
    5c41:	ja     0x5cd6
    5c47:	movq   rax,xmm1
    5c4c:	add    rax,rax
    5c4f:	je     0x5c65
    5c51:	shr    rax,0x35
    5c55:	sub    eax,0x201
    5c5a:	cmp    eax,0x3fc
    5c5f:	ja     0x5cd6
    5c65:	movdqa xmm14,xmm1
    5c6a:	psrldq xmm14,0x8
    5c70:	movq   rax,xmm14
    5c75:	add    rax,rax
    5c78:	je     0x5c8e
    5c7a:	shr    rax,0x35
    5c7e:	sub    eax,0x201
    5c83:	cmp    eax,0x3fc
    5c88:	ja     0x5cd6
    5c8e:	stmxcsr DWORD PTR [rsp+0x100]
    5c96:	mov    DWORD PTR [rsp+0x104],0x1f80
    5ca1:	ldmxcsr DWORD PTR [rsp+0x104]
    5ca9:	addpd  xmm0,xmm1
    5cad:	stmxcsr DWORD PTR [rsp+0x104]
    5cb5:	ldmxcsr DWORD PTR [rsp+0x100]
    5cbd:	mov    eax,DWORD PTR [rsp+0x104]
    5cc4:	shr    eax,1
    5cc6:	and    eax,0x10
    5cc9:	or     DWORD PTR [r12+0x314],eax
    5cd1:	jmp    0x5d83
    5cd6:	movdqa xmm0,xmm2
    5cda:	movdqa xmm1,xmm3
    5cde:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5ce7:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5cf0:	mov    QWORD PTR [r12+0x378],0x3
    5cfc:	movdqu XMMWORD PTR [rsp],xmm2
    5d01:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5d07:	mov    QWORD PTR [r12+0x108],rbx
    5d0f:	stmxcsr DWORD PTR [r12-0x28]
    5d15:	ldmxcsr DWORD PTR [r12-0x38]
    5d1b:	lea    rdi,[rsp+0xf0]
    5d23:	lea    rsi,[rsp+0xd0]
    5d2b:	lea    rdx,[rsp+0xe0]
    5d33:	mov    ecx,0x14
    5d38:	mov    r8d,DWORD PTR [r12+0x310]
    5d40:	lea    r9,[r12+0x314]
    5d48:	movabs r11,0x5a1b9d18a750
    5d52:	call   r11
    5d55:	ldmxcsr DWORD PTR [r12-0x28]
    5d5b:	movdqu xmm2,XMMWORD PTR [rsp]
    5d60:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5d66:	mov    rbx,QWORD PTR [r12+0x108]
    5d6e:	mov    QWORD PTR [r12+0x378],0x2
    5d7a:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5d83:	movdqa xmm4,xmm0
    5d87:	movdqa xmm0,xmm4
    5d8b:	movdqu XMMWORD PTR [r12+0x210],xmm0
    5d95:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    5d9f:	movdqa xmm2,xmm0
    5da3:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    5dad:	movdqa xmm3,xmm0
    5db1:	cmp    DWORD PTR [r12+0x310],0x0
    5dba:	jne    0x5e9e
    5dc0:	movdqa xmm0,xmm2
    5dc4:	movdqa xmm1,xmm3
    5dc8:	movq   rax,xmm0
    5dcd:	add    rax,rax
    5dd0:	je     0x5de6
    5dd2:	shr    rax,0x35
    5dd6:	sub    eax,0x201
    5ddb:	cmp    eax,0x3fc
    5de0:	ja     0x5e9e
    5de6:	movdqa xmm14,xmm0
    5deb:	psrldq xmm14,0x8
    5df1:	movq   rax,xmm14
    5df6:	add    rax,rax
    5df9:	je     0x5e0f
    5dfb:	shr    rax,0x35
    5dff:	sub    eax,0x201
    5e04:	cmp    eax,0x3fc
    5e09:	ja     0x5e9e
    5e0f:	movq   rax,xmm1
    5e14:	add    rax,rax
    5e17:	je     0x5e2d
    5e19:	shr    rax,0x35
    5e1d:	sub    eax,0x201
    5e22:	cmp    eax,0x3fc
    5e27:	ja     0x5e9e
    5e2d:	movdqa xmm14,xmm1
    5e32:	psrldq xmm14,0x8
    5e38:	movq   rax,xmm14
    5e3d:	add    rax,rax
    5e40:	je     0x5e56
    5e42:	shr    rax,0x35
    5e46:	sub    eax,0x201
    5e4b:	cmp    eax,0x3fc
    5e50:	ja     0x5e9e
    5e56:	stmxcsr DWORD PTR [rsp+0x100]
    5e5e:	mov    DWORD PTR [rsp+0x104],0x1f80
    5e69:	ldmxcsr DWORD PTR [rsp+0x104]
    5e71:	addpd  xmm0,xmm1
    5e75:	stmxcsr DWORD PTR [rsp+0x104]
    5e7d:	ldmxcsr DWORD PTR [rsp+0x100]
    5e85:	mov    eax,DWORD PTR [rsp+0x104]
    5e8c:	shr    eax,1
    5e8e:	and    eax,0x10
    5e91:	or     DWORD PTR [r12+0x314],eax
    5e99:	jmp    0x5f4b
    5e9e:	movdqa xmm0,xmm2
    5ea2:	movdqa xmm1,xmm3
    5ea6:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    5eaf:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    5eb8:	mov    QWORD PTR [r12+0x378],0x3
    5ec4:	movdqu XMMWORD PTR [rsp],xmm2
    5ec9:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    5ecf:	mov    QWORD PTR [r12+0x108],rbx
    5ed7:	stmxcsr DWORD PTR [r12-0x28]
    5edd:	ldmxcsr DWORD PTR [r12-0x38]
    5ee3:	lea    rdi,[rsp+0xf0]
    5eeb:	lea    rsi,[rsp+0xd0]
    5ef3:	lea    rdx,[rsp+0xe0]
    5efb:	mov    ecx,0x14
    5f00:	mov    r8d,DWORD PTR [r12+0x310]
    5f08:	lea    r9,[r12+0x314]
    5f10:	movabs r11,0x5a1b9d18a750
    5f1a:	call   r11
    5f1d:	ldmxcsr DWORD PTR [r12-0x28]
    5f23:	movdqu xmm2,XMMWORD PTR [rsp]
    5f28:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    5f2e:	mov    rbx,QWORD PTR [r12+0x108]
    5f36:	mov    QWORD PTR [r12+0x378],0x2
    5f42:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    5f4b:	movdqa xmm4,xmm0
    5f4f:	movdqa xmm0,xmm4
    5f53:	movdqu XMMWORD PTR [r12+0x230],xmm0
    5f5d:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    5f67:	movdqa xmm2,xmm0
    5f6b:	movdqa xmm0,xmm2
    5f6f:	movdqa xmm1,xmm2
    5f73:	por    xmm0,xmm1
    5f77:	movdqa xmm3,xmm0
    5f7b:	movdqa xmm0,xmm3
    5f7f:	movdqu XMMWORD PTR [r12+0x250],xmm0
    5f89:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    5f93:	movdqa xmm2,xmm0
    5f97:	movdqa xmm0,xmm2
    5f9b:	movdqa xmm1,xmm2
    5f9f:	por    xmm0,xmm1
    5fa3:	movdqa xmm3,xmm0
    5fa7:	movdqa xmm0,xmm3
    5fab:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    5fb5:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    5fbf:	movdqa xmm2,xmm0
    5fc3:	movdqa xmm0,xmm2
    5fc7:	movdqa xmm1,xmm2
    5fcb:	por    xmm0,xmm1
    5fcf:	movdqa xmm3,xmm0
    5fd3:	movdqa xmm0,xmm3
    5fd7:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    5fe1:	mov    r13,QWORD PTR [r12+0xf8]
    5fe9:	mov    r14,r13
    5fec:	add    r14,0x40
    5ff0:	movdqu xmm2,XMMWORD PTR [r14]
    5ff5:	movdqa xmm0,xmm2
    5ff9:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    6003:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    600d:	movdqa xmm2,xmm0
    6011:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    601b:	movdqa xmm3,xmm0
    601f:	cmp    DWORD PTR [r12+0x310],0x0
    6028:	jne    0x6111
    602e:	movdqa xmm0,xmm2
    6032:	movdqa xmm1,xmm3
    6036:	pshufd xmm1,xmm1,0x44
    603b:	movq   rax,xmm0
    6040:	add    rax,rax
    6043:	je     0x6059
    6045:	shr    rax,0x35
    6049:	sub    eax,0x201
    604e:	cmp    eax,0x3fc
    6053:	ja     0x6111
    6059:	movdqa xmm14,xmm0
    605e:	psrldq xmm14,0x8
    6064:	movq   rax,xmm14
    6069:	add    rax,rax
    606c:	je     0x6082
    606e:	shr    rax,0x35
    6072:	sub    eax,0x201
    6077:	cmp    eax,0x3fc
    607c:	ja     0x6111
    6082:	movq   rax,xmm1
    6087:	add    rax,rax
    608a:	je     0x60a0
    608c:	shr    rax,0x35
    6090:	sub    eax,0x201
    6095:	cmp    eax,0x3fc
    609a:	ja     0x6111
    60a0:	movdqa xmm14,xmm1
    60a5:	psrldq xmm14,0x8
    60ab:	movq   rax,xmm14
    60b0:	add    rax,rax
    60b3:	je     0x60c9
    60b5:	shr    rax,0x35
    60b9:	sub    eax,0x201
    60be:	cmp    eax,0x3fc
    60c3:	ja     0x6111
    60c9:	stmxcsr DWORD PTR [rsp+0x100]
    60d1:	mov    DWORD PTR [rsp+0x104],0x1f80
    60dc:	ldmxcsr DWORD PTR [rsp+0x104]
    60e4:	mulpd  xmm0,xmm1
    60e8:	stmxcsr DWORD PTR [rsp+0x104]
    60f0:	ldmxcsr DWORD PTR [rsp+0x100]
    60f8:	mov    eax,DWORD PTR [rsp+0x104]
    60ff:	shr    eax,1
    6101:	and    eax,0x10
    6104:	or     DWORD PTR [r12+0x314],eax
    610c:	jmp    0x61be
    6111:	movdqa xmm0,xmm2
    6115:	movdqa xmm1,xmm3
    6119:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6122:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    612b:	mov    QWORD PTR [r12+0x378],0x3
    6137:	movdqu XMMWORD PTR [rsp],xmm2
    613c:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6142:	mov    QWORD PTR [r12+0x108],rbx
    614a:	stmxcsr DWORD PTR [r12-0x28]
    6150:	ldmxcsr DWORD PTR [r12-0x38]
    6156:	lea    rdi,[rsp+0xf0]
    615e:	lea    rsi,[rsp+0xd0]
    6166:	lea    rdx,[rsp+0xe0]
    616e:	mov    ecx,0x56
    6173:	mov    r8d,DWORD PTR [r12+0x310]
    617b:	lea    r9,[r12+0x314]
    6183:	movabs r11,0x5a1b9d18a750
    618d:	call   r11
    6190:	ldmxcsr DWORD PTR [r12-0x28]
    6196:	movdqu xmm2,XMMWORD PTR [rsp]
    619b:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    61a1:	mov    rbx,QWORD PTR [r12+0x108]
    61a9:	mov    QWORD PTR [r12+0x378],0x2
    61b5:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    61be:	movdqa xmm4,xmm0
    61c2:	movdqa xmm0,xmm4
    61c6:	movdqu XMMWORD PTR [r12+0x220],xmm0
    61d0:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    61da:	movdqa xmm2,xmm0
    61de:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    61e8:	movdqa xmm3,xmm0
    61ec:	cmp    DWORD PTR [r12+0x310],0x0
    61f5:	jne    0x62d9
    61fb:	movdqa xmm0,xmm2
    61ff:	movdqa xmm1,xmm3
    6203:	movq   rax,xmm0
    6208:	add    rax,rax
    620b:	je     0x6221
    620d:	shr    rax,0x35
    6211:	sub    eax,0x201
    6216:	cmp    eax,0x3fc
    621b:	ja     0x62d9
    6221:	movdqa xmm14,xmm0
    6226:	psrldq xmm14,0x8
    622c:	movq   rax,xmm14
    6231:	add    rax,rax
    6234:	je     0x624a
    6236:	shr    rax,0x35
    623a:	sub    eax,0x201
    623f:	cmp    eax,0x3fc
    6244:	ja     0x62d9
    624a:	movq   rax,xmm1
    624f:	add    rax,rax
    6252:	je     0x6268
    6254:	shr    rax,0x35
    6258:	sub    eax,0x201
    625d:	cmp    eax,0x3fc
    6262:	ja     0x62d9
    6268:	movdqa xmm14,xmm1
    626d:	psrldq xmm14,0x8
    6273:	movq   rax,xmm14
    6278:	add    rax,rax
    627b:	je     0x6291
    627d:	shr    rax,0x35
    6281:	sub    eax,0x201
    6286:	cmp    eax,0x3fc
    628b:	ja     0x62d9
    6291:	stmxcsr DWORD PTR [rsp+0x100]
    6299:	mov    DWORD PTR [rsp+0x104],0x1f80
    62a4:	ldmxcsr DWORD PTR [rsp+0x104]
    62ac:	addpd  xmm0,xmm1
    62b0:	stmxcsr DWORD PTR [rsp+0x104]
    62b8:	ldmxcsr DWORD PTR [rsp+0x100]
    62c0:	mov    eax,DWORD PTR [rsp+0x104]
    62c7:	shr    eax,1
    62c9:	and    eax,0x10
    62cc:	or     DWORD PTR [r12+0x314],eax
    62d4:	jmp    0x6386
    62d9:	movdqa xmm0,xmm2
    62dd:	movdqa xmm1,xmm3
    62e1:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    62ea:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    62f3:	mov    QWORD PTR [r12+0x378],0x3
    62ff:	movdqu XMMWORD PTR [rsp],xmm2
    6304:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    630a:	mov    QWORD PTR [r12+0x108],rbx
    6312:	stmxcsr DWORD PTR [r12-0x28]
    6318:	ldmxcsr DWORD PTR [r12-0x38]
    631e:	lea    rdi,[rsp+0xf0]
    6326:	lea    rsi,[rsp+0xd0]
    632e:	lea    rdx,[rsp+0xe0]
    6336:	mov    ecx,0x14
    633b:	mov    r8d,DWORD PTR [r12+0x310]
    6343:	lea    r9,[r12+0x314]
    634b:	movabs r11,0x5a1b9d18a750
    6355:	call   r11
    6358:	ldmxcsr DWORD PTR [r12-0x28]
    635e:	movdqu xmm2,XMMWORD PTR [rsp]
    6363:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6369:	mov    rbx,QWORD PTR [r12+0x108]
    6371:	mov    QWORD PTR [r12+0x378],0x2
    637d:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6386:	movdqa xmm4,xmm0
    638a:	movdqa xmm0,xmm4
    638e:	movdqu XMMWORD PTR [r12+0x150],xmm0
    6398:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    63a2:	movdqa xmm2,xmm0
    63a6:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    63b0:	movdqa xmm3,xmm0
    63b4:	cmp    DWORD PTR [r12+0x310],0x0
    63bd:	jne    0x64a1
    63c3:	movdqa xmm0,xmm2
    63c7:	movdqa xmm1,xmm3
    63cb:	movq   rax,xmm0
    63d0:	add    rax,rax
    63d3:	je     0x63e9
    63d5:	shr    rax,0x35
    63d9:	sub    eax,0x201
    63de:	cmp    eax,0x3fc
    63e3:	ja     0x64a1
    63e9:	movdqa xmm14,xmm0
    63ee:	psrldq xmm14,0x8
    63f4:	movq   rax,xmm14
    63f9:	add    rax,rax
    63fc:	je     0x6412
    63fe:	shr    rax,0x35
    6402:	sub    eax,0x201
    6407:	cmp    eax,0x3fc
    640c:	ja     0x64a1
    6412:	movq   rax,xmm1
    6417:	add    rax,rax
    641a:	je     0x6430
    641c:	shr    rax,0x35
    6420:	sub    eax,0x201
    6425:	cmp    eax,0x3fc
    642a:	ja     0x64a1
    6430:	movdqa xmm14,xmm1
    6435:	psrldq xmm14,0x8
    643b:	movq   rax,xmm14
    6440:	add    rax,rax
    6443:	je     0x6459
    6445:	shr    rax,0x35
    6449:	sub    eax,0x201
    644e:	cmp    eax,0x3fc
    6453:	ja     0x64a1
    6459:	stmxcsr DWORD PTR [rsp+0x100]
    6461:	mov    DWORD PTR [rsp+0x104],0x1f80
    646c:	ldmxcsr DWORD PTR [rsp+0x104]
    6474:	addpd  xmm0,xmm1
    6478:	stmxcsr DWORD PTR [rsp+0x104]
    6480:	ldmxcsr DWORD PTR [rsp+0x100]
    6488:	mov    eax,DWORD PTR [rsp+0x104]
    648f:	shr    eax,1
    6491:	and    eax,0x10
    6494:	or     DWORD PTR [r12+0x314],eax
    649c:	jmp    0x654e
    64a1:	movdqa xmm0,xmm2
    64a5:	movdqa xmm1,xmm3
    64a9:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    64b2:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    64bb:	mov    QWORD PTR [r12+0x378],0x3
    64c7:	movdqu XMMWORD PTR [rsp],xmm2
    64cc:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    64d2:	mov    QWORD PTR [r12+0x108],rbx
    64da:	stmxcsr DWORD PTR [r12-0x28]
    64e0:	ldmxcsr DWORD PTR [r12-0x38]
    64e6:	lea    rdi,[rsp+0xf0]
    64ee:	lea    rsi,[rsp+0xd0]
    64f6:	lea    rdx,[rsp+0xe0]
    64fe:	mov    ecx,0x14
    6503:	mov    r8d,DWORD PTR [r12+0x310]
    650b:	lea    r9,[r12+0x314]
    6513:	movabs r11,0x5a1b9d18a750
    651d:	call   r11
    6520:	ldmxcsr DWORD PTR [r12-0x28]
    6526:	movdqu xmm2,XMMWORD PTR [rsp]
    652b:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6531:	mov    rbx,QWORD PTR [r12+0x108]
    6539:	mov    QWORD PTR [r12+0x378],0x2
    6545:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    654e:	movdqa xmm4,xmm0
    6552:	movdqa xmm0,xmm4
    6556:	movdqu XMMWORD PTR [r12+0x160],xmm0
    6560:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    656a:	movdqa xmm2,xmm0
    656e:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    6578:	movdqa xmm3,xmm0
    657c:	cmp    DWORD PTR [r12+0x310],0x0
    6585:	jne    0x666e
    658b:	movdqa xmm0,xmm2
    658f:	movdqa xmm1,xmm3
    6593:	pshufd xmm1,xmm1,0x44
    6598:	movq   rax,xmm0
    659d:	add    rax,rax
    65a0:	je     0x65b6
    65a2:	shr    rax,0x35
    65a6:	sub    eax,0x201
    65ab:	cmp    eax,0x3fc
    65b0:	ja     0x666e
    65b6:	movdqa xmm14,xmm0
    65bb:	psrldq xmm14,0x8
    65c1:	movq   rax,xmm14
    65c6:	add    rax,rax
    65c9:	je     0x65df
    65cb:	shr    rax,0x35
    65cf:	sub    eax,0x201
    65d4:	cmp    eax,0x3fc
    65d9:	ja     0x666e
    65df:	movq   rax,xmm1
    65e4:	add    rax,rax
    65e7:	je     0x65fd
    65e9:	shr    rax,0x35
    65ed:	sub    eax,0x201
    65f2:	cmp    eax,0x3fc
    65f7:	ja     0x666e
    65fd:	movdqa xmm14,xmm1
    6602:	psrldq xmm14,0x8
    6608:	movq   rax,xmm14
    660d:	add    rax,rax
    6610:	je     0x6626
    6612:	shr    rax,0x35
    6616:	sub    eax,0x201
    661b:	cmp    eax,0x3fc
    6620:	ja     0x666e
    6626:	stmxcsr DWORD PTR [rsp+0x100]
    662e:	mov    DWORD PTR [rsp+0x104],0x1f80
    6639:	ldmxcsr DWORD PTR [rsp+0x104]
    6641:	mulpd  xmm0,xmm1
    6645:	stmxcsr DWORD PTR [rsp+0x104]
    664d:	ldmxcsr DWORD PTR [rsp+0x100]
    6655:	mov    eax,DWORD PTR [rsp+0x104]
    665c:	shr    eax,1
    665e:	and    eax,0x10
    6661:	or     DWORD PTR [r12+0x314],eax
    6669:	jmp    0x671b
    666e:	movdqa xmm0,xmm2
    6672:	movdqa xmm1,xmm3
    6676:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    667f:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6688:	mov    QWORD PTR [r12+0x378],0x3
    6694:	movdqu XMMWORD PTR [rsp],xmm2
    6699:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    669f:	mov    QWORD PTR [r12+0x108],rbx
    66a7:	stmxcsr DWORD PTR [r12-0x28]
    66ad:	ldmxcsr DWORD PTR [r12-0x38]
    66b3:	lea    rdi,[rsp+0xf0]
    66bb:	lea    rsi,[rsp+0xd0]
    66c3:	lea    rdx,[rsp+0xe0]
    66cb:	mov    ecx,0x56
    66d0:	mov    r8d,DWORD PTR [r12+0x310]
    66d8:	lea    r9,[r12+0x314]
    66e0:	movabs r11,0x5a1b9d18a750
    66ea:	call   r11
    66ed:	ldmxcsr DWORD PTR [r12-0x28]
    66f3:	movdqu xmm2,XMMWORD PTR [rsp]
    66f8:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    66fe:	mov    rbx,QWORD PTR [r12+0x108]
    6706:	mov    QWORD PTR [r12+0x378],0x2
    6712:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    671b:	movdqa xmm4,xmm0
    671f:	movdqa xmm0,xmm4
    6723:	movdqu XMMWORD PTR [r12+0x240],xmm0
    672d:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    6737:	movdqa xmm2,xmm0
    673b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    6745:	movdqa xmm3,xmm0
    6749:	cmp    DWORD PTR [r12+0x310],0x0
    6752:	jne    0x683b
    6758:	movdqa xmm0,xmm2
    675c:	movdqa xmm1,xmm3
    6760:	pshufd xmm1,xmm1,0x44
    6765:	movq   rax,xmm0
    676a:	add    rax,rax
    676d:	je     0x6783
    676f:	shr    rax,0x35
    6773:	sub    eax,0x201
    6778:	cmp    eax,0x3fc
    677d:	ja     0x683b
    6783:	movdqa xmm14,xmm0
    6788:	psrldq xmm14,0x8
    678e:	movq   rax,xmm14
    6793:	add    rax,rax
    6796:	je     0x67ac
    6798:	shr    rax,0x35
    679c:	sub    eax,0x201
    67a1:	cmp    eax,0x3fc
    67a6:	ja     0x683b
    67ac:	movq   rax,xmm1
    67b1:	add    rax,rax
    67b4:	je     0x67ca
    67b6:	shr    rax,0x35
    67ba:	sub    eax,0x201
    67bf:	cmp    eax,0x3fc
    67c4:	ja     0x683b
    67ca:	movdqa xmm14,xmm1
    67cf:	psrldq xmm14,0x8
    67d5:	movq   rax,xmm14
    67da:	add    rax,rax
    67dd:	je     0x67f3
    67df:	shr    rax,0x35
    67e3:	sub    eax,0x201
    67e8:	cmp    eax,0x3fc
    67ed:	ja     0x683b
    67f3:	stmxcsr DWORD PTR [rsp+0x100]
    67fb:	mov    DWORD PTR [rsp+0x104],0x1f80
    6806:	ldmxcsr DWORD PTR [rsp+0x104]
    680e:	mulpd  xmm0,xmm1
    6812:	stmxcsr DWORD PTR [rsp+0x104]
    681a:	ldmxcsr DWORD PTR [rsp+0x100]
    6822:	mov    eax,DWORD PTR [rsp+0x104]
    6829:	shr    eax,1
    682b:	and    eax,0x10
    682e:	or     DWORD PTR [r12+0x314],eax
    6836:	jmp    0x68e8
    683b:	movdqa xmm0,xmm2
    683f:	movdqa xmm1,xmm3
    6843:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    684c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6855:	mov    QWORD PTR [r12+0x378],0x3
    6861:	movdqu XMMWORD PTR [rsp],xmm2
    6866:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    686c:	mov    QWORD PTR [r12+0x108],rbx
    6874:	stmxcsr DWORD PTR [r12-0x28]
    687a:	ldmxcsr DWORD PTR [r12-0x38]
    6880:	lea    rdi,[rsp+0xf0]
    6888:	lea    rsi,[rsp+0xd0]
    6890:	lea    rdx,[rsp+0xe0]
    6898:	mov    ecx,0x56
    689d:	mov    r8d,DWORD PTR [r12+0x310]
    68a5:	lea    r9,[r12+0x314]
    68ad:	movabs r11,0x5a1b9d18a750
    68b7:	call   r11
    68ba:	ldmxcsr DWORD PTR [r12-0x28]
    68c0:	movdqu xmm2,XMMWORD PTR [rsp]
    68c5:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    68cb:	mov    rbx,QWORD PTR [r12+0x108]
    68d3:	mov    QWORD PTR [r12+0x378],0x2
    68df:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    68e8:	movdqa xmm4,xmm0
    68ec:	movdqa xmm0,xmm4
    68f0:	movdqu XMMWORD PTR [r12+0x140],xmm0
    68fa:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    6904:	movdqa xmm2,xmm0
    6908:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    6912:	movdqa xmm3,xmm0
    6916:	cmp    DWORD PTR [r12+0x310],0x0
    691f:	jne    0x6a08
    6925:	movdqa xmm0,xmm2
    6929:	movdqa xmm1,xmm3
    692d:	pshufd xmm1,xmm1,0x44
    6932:	movq   rax,xmm0
    6937:	add    rax,rax
    693a:	je     0x6950
    693c:	shr    rax,0x35
    6940:	sub    eax,0x201
    6945:	cmp    eax,0x3fc
    694a:	ja     0x6a08
    6950:	movdqa xmm14,xmm0
    6955:	psrldq xmm14,0x8
    695b:	movq   rax,xmm14
    6960:	add    rax,rax
    6963:	je     0x6979
    6965:	shr    rax,0x35
    6969:	sub    eax,0x201
    696e:	cmp    eax,0x3fc
    6973:	ja     0x6a08
    6979:	movq   rax,xmm1
    697e:	add    rax,rax
    6981:	je     0x6997
    6983:	shr    rax,0x35
    6987:	sub    eax,0x201
    698c:	cmp    eax,0x3fc
    6991:	ja     0x6a08
    6997:	movdqa xmm14,xmm1
    699c:	psrldq xmm14,0x8
    69a2:	movq   rax,xmm14
    69a7:	add    rax,rax
    69aa:	je     0x69c0
    69ac:	shr    rax,0x35
    69b0:	sub    eax,0x201
    69b5:	cmp    eax,0x3fc
    69ba:	ja     0x6a08
    69c0:	stmxcsr DWORD PTR [rsp+0x100]
    69c8:	mov    DWORD PTR [rsp+0x104],0x1f80
    69d3:	ldmxcsr DWORD PTR [rsp+0x104]
    69db:	mulpd  xmm0,xmm1
    69df:	stmxcsr DWORD PTR [rsp+0x104]
    69e7:	ldmxcsr DWORD PTR [rsp+0x100]
    69ef:	mov    eax,DWORD PTR [rsp+0x104]
    69f6:	shr    eax,1
    69f8:	and    eax,0x10
    69fb:	or     DWORD PTR [r12+0x314],eax
    6a03:	jmp    0x6ab5
    6a08:	movdqa xmm0,xmm2
    6a0c:	movdqa xmm1,xmm3
    6a10:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6a19:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6a22:	mov    QWORD PTR [r12+0x378],0x3
    6a2e:	movdqu XMMWORD PTR [rsp],xmm2
    6a33:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6a39:	mov    QWORD PTR [r12+0x108],rbx
    6a41:	stmxcsr DWORD PTR [r12-0x28]
    6a47:	ldmxcsr DWORD PTR [r12-0x38]
    6a4d:	lea    rdi,[rsp+0xf0]
    6a55:	lea    rsi,[rsp+0xd0]
    6a5d:	lea    rdx,[rsp+0xe0]
    6a65:	mov    ecx,0x56
    6a6a:	mov    r8d,DWORD PTR [r12+0x310]
    6a72:	lea    r9,[r12+0x314]
    6a7a:	movabs r11,0x5a1b9d18a750
    6a84:	call   r11
    6a87:	ldmxcsr DWORD PTR [r12-0x28]
    6a8d:	movdqu xmm2,XMMWORD PTR [rsp]
    6a92:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6a98:	mov    rbx,QWORD PTR [r12+0x108]
    6aa0:	mov    QWORD PTR [r12+0x378],0x2
    6aac:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6ab5:	movdqa xmm4,xmm0
    6ab9:	movdqa xmm0,xmm4
    6abd:	movdqu XMMWORD PTR [r12+0x170],xmm0
    6ac7:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    6ad1:	movdqa xmm2,xmm0
    6ad5:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    6adf:	movdqa xmm3,xmm0
    6ae3:	cmp    DWORD PTR [r12+0x310],0x0
    6aec:	jne    0x6bd0
    6af2:	movdqa xmm0,xmm2
    6af6:	movdqa xmm1,xmm3
    6afa:	movq   rax,xmm0
    6aff:	add    rax,rax
    6b02:	je     0x6b18
    6b04:	shr    rax,0x35
    6b08:	sub    eax,0x201
    6b0d:	cmp    eax,0x3fc
    6b12:	ja     0x6bd0
    6b18:	movdqa xmm14,xmm0
    6b1d:	psrldq xmm14,0x8
    6b23:	movq   rax,xmm14
    6b28:	add    rax,rax
    6b2b:	je     0x6b41
    6b2d:	shr    rax,0x35
    6b31:	sub    eax,0x201
    6b36:	cmp    eax,0x3fc
    6b3b:	ja     0x6bd0
    6b41:	movq   rax,xmm1
    6b46:	add    rax,rax
    6b49:	je     0x6b5f
    6b4b:	shr    rax,0x35
    6b4f:	sub    eax,0x201
    6b54:	cmp    eax,0x3fc
    6b59:	ja     0x6bd0
    6b5f:	movdqa xmm14,xmm1
    6b64:	psrldq xmm14,0x8
    6b6a:	movq   rax,xmm14
    6b6f:	add    rax,rax
    6b72:	je     0x6b88
    6b74:	shr    rax,0x35
    6b78:	sub    eax,0x201
    6b7d:	cmp    eax,0x3fc
    6b82:	ja     0x6bd0
    6b88:	stmxcsr DWORD PTR [rsp+0x100]
    6b90:	mov    DWORD PTR [rsp+0x104],0x1f80
    6b9b:	ldmxcsr DWORD PTR [rsp+0x104]
    6ba3:	addpd  xmm0,xmm1
    6ba7:	stmxcsr DWORD PTR [rsp+0x104]
    6baf:	ldmxcsr DWORD PTR [rsp+0x100]
    6bb7:	mov    eax,DWORD PTR [rsp+0x104]
    6bbe:	shr    eax,1
    6bc0:	and    eax,0x10
    6bc3:	or     DWORD PTR [r12+0x314],eax
    6bcb:	jmp    0x6c7d
    6bd0:	movdqa xmm0,xmm2
    6bd4:	movdqa xmm1,xmm3
    6bd8:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6be1:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6bea:	mov    QWORD PTR [r12+0x378],0x3
    6bf6:	movdqu XMMWORD PTR [rsp],xmm2
    6bfb:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6c01:	mov    QWORD PTR [r12+0x108],rbx
    6c09:	stmxcsr DWORD PTR [r12-0x28]
    6c0f:	ldmxcsr DWORD PTR [r12-0x38]
    6c15:	lea    rdi,[rsp+0xf0]
    6c1d:	lea    rsi,[rsp+0xd0]
    6c25:	lea    rdx,[rsp+0xe0]
    6c2d:	mov    ecx,0x14
    6c32:	mov    r8d,DWORD PTR [r12+0x310]
    6c3a:	lea    r9,[r12+0x314]
    6c42:	movabs r11,0x5a1b9d18a750
    6c4c:	call   r11
    6c4f:	ldmxcsr DWORD PTR [r12-0x28]
    6c55:	movdqu xmm2,XMMWORD PTR [rsp]
    6c5a:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6c60:	mov    rbx,QWORD PTR [r12+0x108]
    6c68:	mov    QWORD PTR [r12+0x378],0x2
    6c74:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6c7d:	movdqa xmm4,xmm0
    6c81:	movdqa xmm0,xmm4
    6c85:	movdqu XMMWORD PTR [r12+0x180],xmm0
    6c8f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    6c99:	movdqa xmm2,xmm0
    6c9d:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    6ca7:	movdqa xmm3,xmm0
    6cab:	cmp    DWORD PTR [r12+0x310],0x0
    6cb4:	jne    0x6d9d
    6cba:	movdqa xmm0,xmm2
    6cbe:	movdqa xmm1,xmm3
    6cc2:	pshufd xmm1,xmm1,0x44
    6cc7:	movq   rax,xmm0
    6ccc:	add    rax,rax
    6ccf:	je     0x6ce5
    6cd1:	shr    rax,0x35
    6cd5:	sub    eax,0x201
    6cda:	cmp    eax,0x3fc
    6cdf:	ja     0x6d9d
    6ce5:	movdqa xmm14,xmm0
    6cea:	psrldq xmm14,0x8
    6cf0:	movq   rax,xmm14
    6cf5:	add    rax,rax
    6cf8:	je     0x6d0e
    6cfa:	shr    rax,0x35
    6cfe:	sub    eax,0x201
    6d03:	cmp    eax,0x3fc
    6d08:	ja     0x6d9d
    6d0e:	movq   rax,xmm1
    6d13:	add    rax,rax
    6d16:	je     0x6d2c
    6d18:	shr    rax,0x35
    6d1c:	sub    eax,0x201
    6d21:	cmp    eax,0x3fc
    6d26:	ja     0x6d9d
    6d2c:	movdqa xmm14,xmm1
    6d31:	psrldq xmm14,0x8
    6d37:	movq   rax,xmm14
    6d3c:	add    rax,rax
    6d3f:	je     0x6d55
    6d41:	shr    rax,0x35
    6d45:	sub    eax,0x201
    6d4a:	cmp    eax,0x3fc
    6d4f:	ja     0x6d9d
    6d55:	stmxcsr DWORD PTR [rsp+0x100]
    6d5d:	mov    DWORD PTR [rsp+0x104],0x1f80
    6d68:	ldmxcsr DWORD PTR [rsp+0x104]
    6d70:	mulpd  xmm0,xmm1
    6d74:	stmxcsr DWORD PTR [rsp+0x104]
    6d7c:	ldmxcsr DWORD PTR [rsp+0x100]
    6d84:	mov    eax,DWORD PTR [rsp+0x104]
    6d8b:	shr    eax,1
    6d8d:	and    eax,0x10
    6d90:	or     DWORD PTR [r12+0x314],eax
    6d98:	jmp    0x6e4a
    6d9d:	movdqa xmm0,xmm2
    6da1:	movdqa xmm1,xmm3
    6da5:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6dae:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6db7:	mov    QWORD PTR [r12+0x378],0x3
    6dc3:	movdqu XMMWORD PTR [rsp],xmm2
    6dc8:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6dce:	mov    QWORD PTR [r12+0x108],rbx
    6dd6:	stmxcsr DWORD PTR [r12-0x28]
    6ddc:	ldmxcsr DWORD PTR [r12-0x38]
    6de2:	lea    rdi,[rsp+0xf0]
    6dea:	lea    rsi,[rsp+0xd0]
    6df2:	lea    rdx,[rsp+0xe0]
    6dfa:	mov    ecx,0x56
    6dff:	mov    r8d,DWORD PTR [r12+0x310]
    6e07:	lea    r9,[r12+0x314]
    6e0f:	movabs r11,0x5a1b9d18a750
    6e19:	call   r11
    6e1c:	ldmxcsr DWORD PTR [r12-0x28]
    6e22:	movdqu xmm2,XMMWORD PTR [rsp]
    6e27:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6e2d:	mov    rbx,QWORD PTR [r12+0x108]
    6e35:	mov    QWORD PTR [r12+0x378],0x2
    6e41:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    6e4a:	movdqa xmm4,xmm0
    6e4e:	movdqa xmm0,xmm4
    6e52:	movdqu XMMWORD PTR [r12+0x210],xmm0
    6e5c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    6e66:	movdqa xmm2,xmm0
    6e6a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    6e74:	movdqa xmm3,xmm0
    6e78:	cmp    DWORD PTR [r12+0x310],0x0
    6e81:	jne    0x6f65
    6e87:	movdqa xmm0,xmm2
    6e8b:	movdqa xmm1,xmm3
    6e8f:	movq   rax,xmm0
    6e94:	add    rax,rax
    6e97:	je     0x6ead
    6e99:	shr    rax,0x35
    6e9d:	sub    eax,0x201
    6ea2:	cmp    eax,0x3fc
    6ea7:	ja     0x6f65
    6ead:	movdqa xmm14,xmm0
    6eb2:	psrldq xmm14,0x8
    6eb8:	movq   rax,xmm14
    6ebd:	add    rax,rax
    6ec0:	je     0x6ed6
    6ec2:	shr    rax,0x35
    6ec6:	sub    eax,0x201
    6ecb:	cmp    eax,0x3fc
    6ed0:	ja     0x6f65
    6ed6:	movq   rax,xmm1
    6edb:	add    rax,rax
    6ede:	je     0x6ef4
    6ee0:	shr    rax,0x35
    6ee4:	sub    eax,0x201
    6ee9:	cmp    eax,0x3fc
    6eee:	ja     0x6f65
    6ef4:	movdqa xmm14,xmm1
    6ef9:	psrldq xmm14,0x8
    6eff:	movq   rax,xmm14
    6f04:	add    rax,rax
    6f07:	je     0x6f1d
    6f09:	shr    rax,0x35
    6f0d:	sub    eax,0x201
    6f12:	cmp    eax,0x3fc
    6f17:	ja     0x6f65
    6f1d:	stmxcsr DWORD PTR [rsp+0x100]
    6f25:	mov    DWORD PTR [rsp+0x104],0x1f80
    6f30:	ldmxcsr DWORD PTR [rsp+0x104]
    6f38:	addpd  xmm0,xmm1
    6f3c:	stmxcsr DWORD PTR [rsp+0x104]
    6f44:	ldmxcsr DWORD PTR [rsp+0x100]
    6f4c:	mov    eax,DWORD PTR [rsp+0x104]
    6f53:	shr    eax,1
    6f55:	and    eax,0x10
    6f58:	or     DWORD PTR [r12+0x314],eax
    6f60:	jmp    0x7012
    6f65:	movdqa xmm0,xmm2
    6f69:	movdqa xmm1,xmm3
    6f6d:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    6f76:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    6f7f:	mov    QWORD PTR [r12+0x378],0x3
    6f8b:	movdqu XMMWORD PTR [rsp],xmm2
    6f90:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    6f96:	mov    QWORD PTR [r12+0x108],rbx
    6f9e:	stmxcsr DWORD PTR [r12-0x28]
    6fa4:	ldmxcsr DWORD PTR [r12-0x38]
    6faa:	lea    rdi,[rsp+0xf0]
    6fb2:	lea    rsi,[rsp+0xd0]
    6fba:	lea    rdx,[rsp+0xe0]
    6fc2:	mov    ecx,0x14
    6fc7:	mov    r8d,DWORD PTR [r12+0x310]
    6fcf:	lea    r9,[r12+0x314]
    6fd7:	movabs r11,0x5a1b9d18a750
    6fe1:	call   r11
    6fe4:	ldmxcsr DWORD PTR [r12-0x28]
    6fea:	movdqu xmm2,XMMWORD PTR [rsp]
    6fef:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    6ff5:	mov    rbx,QWORD PTR [r12+0x108]
    6ffd:	mov    QWORD PTR [r12+0x378],0x2
    7009:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7012:	movdqa xmm4,xmm0
    7016:	movdqa xmm0,xmm4
    701a:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7024:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    702e:	movdqa xmm2,xmm0
    7032:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    703c:	movdqa xmm3,xmm0
    7040:	cmp    DWORD PTR [r12+0x310],0x0
    7049:	jne    0x7132
    704f:	movdqa xmm0,xmm2
    7053:	movdqa xmm1,xmm3
    7057:	pshufd xmm1,xmm1,0x44
    705c:	movq   rax,xmm0
    7061:	add    rax,rax
    7064:	je     0x707a
    7066:	shr    rax,0x35
    706a:	sub    eax,0x201
    706f:	cmp    eax,0x3fc
    7074:	ja     0x7132
    707a:	movdqa xmm14,xmm0
    707f:	psrldq xmm14,0x8
    7085:	movq   rax,xmm14
    708a:	add    rax,rax
    708d:	je     0x70a3
    708f:	shr    rax,0x35
    7093:	sub    eax,0x201
    7098:	cmp    eax,0x3fc
    709d:	ja     0x7132
    70a3:	movq   rax,xmm1
    70a8:	add    rax,rax
    70ab:	je     0x70c1
    70ad:	shr    rax,0x35
    70b1:	sub    eax,0x201
    70b6:	cmp    eax,0x3fc
    70bb:	ja     0x7132
    70c1:	movdqa xmm14,xmm1
    70c6:	psrldq xmm14,0x8
    70cc:	movq   rax,xmm14
    70d1:	add    rax,rax
    70d4:	je     0x70ea
    70d6:	shr    rax,0x35
    70da:	sub    eax,0x201
    70df:	cmp    eax,0x3fc
    70e4:	ja     0x7132
    70ea:	stmxcsr DWORD PTR [rsp+0x100]
    70f2:	mov    DWORD PTR [rsp+0x104],0x1f80
    70fd:	ldmxcsr DWORD PTR [rsp+0x104]
    7105:	mulpd  xmm0,xmm1
    7109:	stmxcsr DWORD PTR [rsp+0x104]
    7111:	ldmxcsr DWORD PTR [rsp+0x100]
    7119:	mov    eax,DWORD PTR [rsp+0x104]
    7120:	shr    eax,1
    7122:	and    eax,0x10
    7125:	or     DWORD PTR [r12+0x314],eax
    712d:	jmp    0x71df
    7132:	movdqa xmm0,xmm2
    7136:	movdqa xmm1,xmm3
    713a:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7143:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    714c:	mov    QWORD PTR [r12+0x378],0x3
    7158:	movdqu XMMWORD PTR [rsp],xmm2
    715d:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7163:	mov    QWORD PTR [r12+0x108],rbx
    716b:	stmxcsr DWORD PTR [r12-0x28]
    7171:	ldmxcsr DWORD PTR [r12-0x38]
    7177:	lea    rdi,[rsp+0xf0]
    717f:	lea    rsi,[rsp+0xd0]
    7187:	lea    rdx,[rsp+0xe0]
    718f:	mov    ecx,0x56
    7194:	mov    r8d,DWORD PTR [r12+0x310]
    719c:	lea    r9,[r12+0x314]
    71a4:	movabs r11,0x5a1b9d18a750
    71ae:	call   r11
    71b1:	ldmxcsr DWORD PTR [r12-0x28]
    71b7:	movdqu xmm2,XMMWORD PTR [rsp]
    71bc:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    71c2:	mov    rbx,QWORD PTR [r12+0x108]
    71ca:	mov    QWORD PTR [r12+0x378],0x2
    71d6:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    71df:	movdqa xmm4,xmm0
    71e3:	movdqa xmm0,xmm4
    71e7:	movdqu XMMWORD PTR [r12+0x230],xmm0
    71f1:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    71fb:	movdqa xmm2,xmm0
    71ff:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7209:	movdqa xmm3,xmm0
    720d:	cmp    DWORD PTR [r12+0x310],0x0
    7216:	jne    0x72fa
    721c:	movdqa xmm0,xmm2
    7220:	movdqa xmm1,xmm3
    7224:	movq   rax,xmm0
    7229:	add    rax,rax
    722c:	je     0x7242
    722e:	shr    rax,0x35
    7232:	sub    eax,0x201
    7237:	cmp    eax,0x3fc
    723c:	ja     0x72fa
    7242:	movdqa xmm14,xmm0
    7247:	psrldq xmm14,0x8
    724d:	movq   rax,xmm14
    7252:	add    rax,rax
    7255:	je     0x726b
    7257:	shr    rax,0x35
    725b:	sub    eax,0x201
    7260:	cmp    eax,0x3fc
    7265:	ja     0x72fa
    726b:	movq   rax,xmm1
    7270:	add    rax,rax
    7273:	je     0x7289
    7275:	shr    rax,0x35
    7279:	sub    eax,0x201
    727e:	cmp    eax,0x3fc
    7283:	ja     0x72fa
    7289:	movdqa xmm14,xmm1
    728e:	psrldq xmm14,0x8
    7294:	movq   rax,xmm14
    7299:	add    rax,rax
    729c:	je     0x72b2
    729e:	shr    rax,0x35
    72a2:	sub    eax,0x201
    72a7:	cmp    eax,0x3fc
    72ac:	ja     0x72fa
    72b2:	stmxcsr DWORD PTR [rsp+0x100]
    72ba:	mov    DWORD PTR [rsp+0x104],0x1f80
    72c5:	ldmxcsr DWORD PTR [rsp+0x104]
    72cd:	addpd  xmm0,xmm1
    72d1:	stmxcsr DWORD PTR [rsp+0x104]
    72d9:	ldmxcsr DWORD PTR [rsp+0x100]
    72e1:	mov    eax,DWORD PTR [rsp+0x104]
    72e8:	shr    eax,1
    72ea:	and    eax,0x10
    72ed:	or     DWORD PTR [r12+0x314],eax
    72f5:	jmp    0x73a7
    72fa:	movdqa xmm0,xmm2
    72fe:	movdqa xmm1,xmm3
    7302:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    730b:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7314:	mov    QWORD PTR [r12+0x378],0x3
    7320:	movdqu XMMWORD PTR [rsp],xmm2
    7325:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    732b:	mov    QWORD PTR [r12+0x108],rbx
    7333:	stmxcsr DWORD PTR [r12-0x28]
    7339:	ldmxcsr DWORD PTR [r12-0x38]
    733f:	lea    rdi,[rsp+0xf0]
    7347:	lea    rsi,[rsp+0xd0]
    734f:	lea    rdx,[rsp+0xe0]
    7357:	mov    ecx,0x14
    735c:	mov    r8d,DWORD PTR [r12+0x310]
    7364:	lea    r9,[r12+0x314]
    736c:	movabs r11,0x5a1b9d18a750
    7376:	call   r11
    7379:	ldmxcsr DWORD PTR [r12-0x28]
    737f:	movdqu xmm2,XMMWORD PTR [rsp]
    7384:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    738a:	mov    rbx,QWORD PTR [r12+0x108]
    7392:	mov    QWORD PTR [r12+0x378],0x2
    739e:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    73a7:	movdqa xmm4,xmm0
    73ab:	movdqa xmm0,xmm4
    73af:	movdqu XMMWORD PTR [r12+0x140],xmm0
    73b9:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    73c3:	movdqa xmm2,xmm0
    73c7:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    73d1:	movdqa xmm3,xmm0
    73d5:	cmp    DWORD PTR [r12+0x310],0x0
    73de:	jne    0x74c7
    73e4:	movdqa xmm0,xmm2
    73e8:	movdqa xmm1,xmm3
    73ec:	pshufd xmm1,xmm1,0x44
    73f1:	movq   rax,xmm0
    73f6:	add    rax,rax
    73f9:	je     0x740f
    73fb:	shr    rax,0x35
    73ff:	sub    eax,0x201
    7404:	cmp    eax,0x3fc
    7409:	ja     0x74c7
    740f:	movdqa xmm14,xmm0
    7414:	psrldq xmm14,0x8
    741a:	movq   rax,xmm14
    741f:	add    rax,rax
    7422:	je     0x7438
    7424:	shr    rax,0x35
    7428:	sub    eax,0x201
    742d:	cmp    eax,0x3fc
    7432:	ja     0x74c7
    7438:	movq   rax,xmm1
    743d:	add    rax,rax
    7440:	je     0x7456
    7442:	shr    rax,0x35
    7446:	sub    eax,0x201
    744b:	cmp    eax,0x3fc
    7450:	ja     0x74c7
    7456:	movdqa xmm14,xmm1
    745b:	psrldq xmm14,0x8
    7461:	movq   rax,xmm14
    7466:	add    rax,rax
    7469:	je     0x747f
    746b:	shr    rax,0x35
    746f:	sub    eax,0x201
    7474:	cmp    eax,0x3fc
    7479:	ja     0x74c7
    747f:	stmxcsr DWORD PTR [rsp+0x100]
    7487:	mov    DWORD PTR [rsp+0x104],0x1f80
    7492:	ldmxcsr DWORD PTR [rsp+0x104]
    749a:	mulpd  xmm0,xmm1
    749e:	stmxcsr DWORD PTR [rsp+0x104]
    74a6:	ldmxcsr DWORD PTR [rsp+0x100]
    74ae:	mov    eax,DWORD PTR [rsp+0x104]
    74b5:	shr    eax,1
    74b7:	and    eax,0x10
    74ba:	or     DWORD PTR [r12+0x314],eax
    74c2:	jmp    0x7574
    74c7:	movdqa xmm0,xmm2
    74cb:	movdqa xmm1,xmm3
    74cf:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    74d8:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    74e1:	mov    QWORD PTR [r12+0x378],0x3
    74ed:	movdqu XMMWORD PTR [rsp],xmm2
    74f2:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    74f8:	mov    QWORD PTR [r12+0x108],rbx
    7500:	stmxcsr DWORD PTR [r12-0x28]
    7506:	ldmxcsr DWORD PTR [r12-0x38]
    750c:	lea    rdi,[rsp+0xf0]
    7514:	lea    rsi,[rsp+0xd0]
    751c:	lea    rdx,[rsp+0xe0]
    7524:	mov    ecx,0x56
    7529:	mov    r8d,DWORD PTR [r12+0x310]
    7531:	lea    r9,[r12+0x314]
    7539:	movabs r11,0x5a1b9d18a750
    7543:	call   r11
    7546:	ldmxcsr DWORD PTR [r12-0x28]
    754c:	movdqu xmm2,XMMWORD PTR [rsp]
    7551:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7557:	mov    rbx,QWORD PTR [r12+0x108]
    755f:	mov    QWORD PTR [r12+0x378],0x2
    756b:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7574:	movdqa xmm4,xmm0
    7578:	movdqa xmm0,xmm4
    757c:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7586:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7590:	movdqa xmm2,xmm0
    7594:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    759e:	movdqa xmm3,xmm0
    75a2:	cmp    DWORD PTR [r12+0x310],0x0
    75ab:	jne    0x768f
    75b1:	movdqa xmm0,xmm2
    75b5:	movdqa xmm1,xmm3
    75b9:	movq   rax,xmm0
    75be:	add    rax,rax
    75c1:	je     0x75d7
    75c3:	shr    rax,0x35
    75c7:	sub    eax,0x201
    75cc:	cmp    eax,0x3fc
    75d1:	ja     0x768f
    75d7:	movdqa xmm14,xmm0
    75dc:	psrldq xmm14,0x8
    75e2:	movq   rax,xmm14
    75e7:	add    rax,rax
    75ea:	je     0x7600
    75ec:	shr    rax,0x35
    75f0:	sub    eax,0x201
    75f5:	cmp    eax,0x3fc
    75fa:	ja     0x768f
    7600:	movq   rax,xmm1
    7605:	add    rax,rax
    7608:	je     0x761e
    760a:	shr    rax,0x35
    760e:	sub    eax,0x201
    7613:	cmp    eax,0x3fc
    7618:	ja     0x768f
    761e:	movdqa xmm14,xmm1
    7623:	psrldq xmm14,0x8
    7629:	movq   rax,xmm14
    762e:	add    rax,rax
    7631:	je     0x7647
    7633:	shr    rax,0x35
    7637:	sub    eax,0x201
    763c:	cmp    eax,0x3fc
    7641:	ja     0x768f
    7647:	stmxcsr DWORD PTR [rsp+0x100]
    764f:	mov    DWORD PTR [rsp+0x104],0x1f80
    765a:	ldmxcsr DWORD PTR [rsp+0x104]
    7662:	addpd  xmm0,xmm1
    7666:	stmxcsr DWORD PTR [rsp+0x104]
    766e:	ldmxcsr DWORD PTR [rsp+0x100]
    7676:	mov    eax,DWORD PTR [rsp+0x104]
    767d:	shr    eax,1
    767f:	and    eax,0x10
    7682:	or     DWORD PTR [r12+0x314],eax
    768a:	jmp    0x773c
    768f:	movdqa xmm0,xmm2
    7693:	movdqa xmm1,xmm3
    7697:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    76a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    76a9:	mov    QWORD PTR [r12+0x378],0x3
    76b5:	movdqu XMMWORD PTR [rsp],xmm2
    76ba:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    76c0:	mov    QWORD PTR [r12+0x108],rbx
    76c8:	stmxcsr DWORD PTR [r12-0x28]
    76ce:	ldmxcsr DWORD PTR [r12-0x38]
    76d4:	lea    rdi,[rsp+0xf0]
    76dc:	lea    rsi,[rsp+0xd0]
    76e4:	lea    rdx,[rsp+0xe0]
    76ec:	mov    ecx,0x14
    76f1:	mov    r8d,DWORD PTR [r12+0x310]
    76f9:	lea    r9,[r12+0x314]
    7701:	movabs r11,0x5a1b9d18a750
    770b:	call   r11
    770e:	ldmxcsr DWORD PTR [r12-0x28]
    7714:	movdqu xmm2,XMMWORD PTR [rsp]
    7719:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    771f:	mov    rbx,QWORD PTR [r12+0x108]
    7727:	mov    QWORD PTR [r12+0x378],0x2
    7733:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    773c:	movdqa xmm4,xmm0
    7740:	movdqa xmm0,xmm4
    7744:	movdqu XMMWORD PTR [r12+0x150],xmm0
    774e:	mov    r13,QWORD PTR [r12+0xf8]
    7756:	mov    r14,r13
    7759:	add    r14,0x70
    775d:	movdqu xmm2,XMMWORD PTR [r14]
    7762:	movdqa xmm0,xmm2
    7766:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7770:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    777a:	movdqa xmm2,xmm0
    777e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7788:	movdqa xmm3,xmm0
    778c:	cmp    DWORD PTR [r12+0x310],0x0
    7795:	jne    0x7879
    779b:	movdqa xmm0,xmm2
    779f:	movdqa xmm1,xmm3
    77a3:	movq   rax,xmm0
    77a8:	add    rax,rax
    77ab:	je     0x77c1
    77ad:	shr    rax,0x35
    77b1:	sub    eax,0x201
    77b6:	cmp    eax,0x3fc
    77bb:	ja     0x7879
    77c1:	movdqa xmm14,xmm0
    77c6:	psrldq xmm14,0x8
    77cc:	movq   rax,xmm14
    77d1:	add    rax,rax
    77d4:	je     0x77ea
    77d6:	shr    rax,0x35
    77da:	sub    eax,0x201
    77df:	cmp    eax,0x3fc
    77e4:	ja     0x7879
    77ea:	movq   rax,xmm1
    77ef:	add    rax,rax
    77f2:	je     0x7808
    77f4:	shr    rax,0x35
    77f8:	sub    eax,0x201
    77fd:	cmp    eax,0x3fc
    7802:	ja     0x7879
    7808:	movdqa xmm14,xmm1
    780d:	psrldq xmm14,0x8
    7813:	movq   rax,xmm14
    7818:	add    rax,rax
    781b:	je     0x7831
    781d:	shr    rax,0x35
    7821:	sub    eax,0x201
    7826:	cmp    eax,0x3fc
    782b:	ja     0x7879
    7831:	stmxcsr DWORD PTR [rsp+0x100]
    7839:	mov    DWORD PTR [rsp+0x104],0x1f80
    7844:	ldmxcsr DWORD PTR [rsp+0x104]
    784c:	addpd  xmm0,xmm1
    7850:	stmxcsr DWORD PTR [rsp+0x104]
    7858:	ldmxcsr DWORD PTR [rsp+0x100]
    7860:	mov    eax,DWORD PTR [rsp+0x104]
    7867:	shr    eax,1
    7869:	and    eax,0x10
    786c:	or     DWORD PTR [r12+0x314],eax
    7874:	jmp    0x7926
    7879:	movdqa xmm0,xmm2
    787d:	movdqa xmm1,xmm3
    7881:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    788a:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7893:	mov    QWORD PTR [r12+0x378],0x3
    789f:	movdqu XMMWORD PTR [rsp],xmm2
    78a4:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    78aa:	mov    QWORD PTR [r12+0x108],rbx
    78b2:	stmxcsr DWORD PTR [r12-0x28]
    78b8:	ldmxcsr DWORD PTR [r12-0x38]
    78be:	lea    rdi,[rsp+0xf0]
    78c6:	lea    rsi,[rsp+0xd0]
    78ce:	lea    rdx,[rsp+0xe0]
    78d6:	mov    ecx,0x14
    78db:	mov    r8d,DWORD PTR [r12+0x310]
    78e3:	lea    r9,[r12+0x314]
    78eb:	movabs r11,0x5a1b9d18a750
    78f5:	call   r11
    78f8:	ldmxcsr DWORD PTR [r12-0x28]
    78fe:	movdqu xmm2,XMMWORD PTR [rsp]
    7903:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7909:	mov    rbx,QWORD PTR [r12+0x108]
    7911:	mov    QWORD PTR [r12+0x378],0x2
    791d:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7926:	movdqa xmm4,xmm0
    792a:	movdqa xmm0,xmm4
    792e:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7938:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7942:	movdqa xmm2,xmm0
    7946:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7950:	movdqa xmm3,xmm0
    7954:	cmp    DWORD PTR [r12+0x310],0x0
    795d:	jne    0x7a46
    7963:	movdqa xmm0,xmm2
    7967:	movdqa xmm1,xmm3
    796b:	pshufd xmm1,xmm1,0x44
    7970:	movq   rax,xmm0
    7975:	add    rax,rax
    7978:	je     0x798e
    797a:	shr    rax,0x35
    797e:	sub    eax,0x201
    7983:	cmp    eax,0x3fc
    7988:	ja     0x7a46
    798e:	movdqa xmm14,xmm0
    7993:	psrldq xmm14,0x8
    7999:	movq   rax,xmm14
    799e:	add    rax,rax
    79a1:	je     0x79b7
    79a3:	shr    rax,0x35
    79a7:	sub    eax,0x201
    79ac:	cmp    eax,0x3fc
    79b1:	ja     0x7a46
    79b7:	movq   rax,xmm1
    79bc:	add    rax,rax
    79bf:	je     0x79d5
    79c1:	shr    rax,0x35
    79c5:	sub    eax,0x201
    79ca:	cmp    eax,0x3fc
    79cf:	ja     0x7a46
    79d5:	movdqa xmm14,xmm1
    79da:	psrldq xmm14,0x8
    79e0:	movq   rax,xmm14
    79e5:	add    rax,rax
    79e8:	je     0x79fe
    79ea:	shr    rax,0x35
    79ee:	sub    eax,0x201
    79f3:	cmp    eax,0x3fc
    79f8:	ja     0x7a46
    79fe:	stmxcsr DWORD PTR [rsp+0x100]
    7a06:	mov    DWORD PTR [rsp+0x104],0x1f80
    7a11:	ldmxcsr DWORD PTR [rsp+0x104]
    7a19:	mulpd  xmm0,xmm1
    7a1d:	stmxcsr DWORD PTR [rsp+0x104]
    7a25:	ldmxcsr DWORD PTR [rsp+0x100]
    7a2d:	mov    eax,DWORD PTR [rsp+0x104]
    7a34:	shr    eax,1
    7a36:	and    eax,0x10
    7a39:	or     DWORD PTR [r12+0x314],eax
    7a41:	jmp    0x7af3
    7a46:	movdqa xmm0,xmm2
    7a4a:	movdqa xmm1,xmm3
    7a4e:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7a57:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7a60:	mov    QWORD PTR [r12+0x378],0x3
    7a6c:	movdqu XMMWORD PTR [rsp],xmm2
    7a71:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7a77:	mov    QWORD PTR [r12+0x108],rbx
    7a7f:	stmxcsr DWORD PTR [r12-0x28]
    7a85:	ldmxcsr DWORD PTR [r12-0x38]
    7a8b:	lea    rdi,[rsp+0xf0]
    7a93:	lea    rsi,[rsp+0xd0]
    7a9b:	lea    rdx,[rsp+0xe0]
    7aa3:	mov    ecx,0x56
    7aa8:	mov    r8d,DWORD PTR [r12+0x310]
    7ab0:	lea    r9,[r12+0x314]
    7ab8:	movabs r11,0x5a1b9d18a750
    7ac2:	call   r11
    7ac5:	ldmxcsr DWORD PTR [r12-0x28]
    7acb:	movdqu xmm2,XMMWORD PTR [rsp]
    7ad0:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7ad6:	mov    rbx,QWORD PTR [r12+0x108]
    7ade:	mov    QWORD PTR [r12+0x378],0x2
    7aea:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7af3:	movdqa xmm4,xmm0
    7af7:	movdqa xmm0,xmm4
    7afb:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7b05:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7b0f:	movdqa xmm2,xmm0
    7b13:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7b1d:	movdqa xmm3,xmm0
    7b21:	cmp    DWORD PTR [r12+0x310],0x0
    7b2a:	jne    0x7c13
    7b30:	movdqa xmm0,xmm2
    7b34:	movdqa xmm1,xmm3
    7b38:	pshufd xmm1,xmm1,0x44
    7b3d:	movq   rax,xmm0
    7b42:	add    rax,rax
    7b45:	je     0x7b5b
    7b47:	shr    rax,0x35
    7b4b:	sub    eax,0x201
    7b50:	cmp    eax,0x3fc
    7b55:	ja     0x7c13
    7b5b:	movdqa xmm14,xmm0
    7b60:	psrldq xmm14,0x8
    7b66:	movq   rax,xmm14
    7b6b:	add    rax,rax
    7b6e:	je     0x7b84
    7b70:	shr    rax,0x35
    7b74:	sub    eax,0x201
    7b79:	cmp    eax,0x3fc
    7b7e:	ja     0x7c13
    7b84:	movq   rax,xmm1
    7b89:	add    rax,rax
    7b8c:	je     0x7ba2
    7b8e:	shr    rax,0x35
    7b92:	sub    eax,0x201
    7b97:	cmp    eax,0x3fc
    7b9c:	ja     0x7c13
    7ba2:	movdqa xmm14,xmm1
    7ba7:	psrldq xmm14,0x8
    7bad:	movq   rax,xmm14
    7bb2:	add    rax,rax
    7bb5:	je     0x7bcb
    7bb7:	shr    rax,0x35
    7bbb:	sub    eax,0x201
    7bc0:	cmp    eax,0x3fc
    7bc5:	ja     0x7c13
    7bcb:	stmxcsr DWORD PTR [rsp+0x100]
    7bd3:	mov    DWORD PTR [rsp+0x104],0x1f80
    7bde:	ldmxcsr DWORD PTR [rsp+0x104]
    7be6:	mulpd  xmm0,xmm1
    7bea:	stmxcsr DWORD PTR [rsp+0x104]
    7bf2:	ldmxcsr DWORD PTR [rsp+0x100]
    7bfa:	mov    eax,DWORD PTR [rsp+0x104]
    7c01:	shr    eax,1
    7c03:	and    eax,0x10
    7c06:	or     DWORD PTR [r12+0x314],eax
    7c0e:	jmp    0x7cc0
    7c13:	movdqa xmm0,xmm2
    7c17:	movdqa xmm1,xmm3
    7c1b:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7c24:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7c2d:	mov    QWORD PTR [r12+0x378],0x3
    7c39:	movdqu XMMWORD PTR [rsp],xmm2
    7c3e:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7c44:	mov    QWORD PTR [r12+0x108],rbx
    7c4c:	stmxcsr DWORD PTR [r12-0x28]
    7c52:	ldmxcsr DWORD PTR [r12-0x38]
    7c58:	lea    rdi,[rsp+0xf0]
    7c60:	lea    rsi,[rsp+0xd0]
    7c68:	lea    rdx,[rsp+0xe0]
    7c70:	mov    ecx,0x56
    7c75:	mov    r8d,DWORD PTR [r12+0x310]
    7c7d:	lea    r9,[r12+0x314]
    7c85:	movabs r11,0x5a1b9d18a750
    7c8f:	call   r11
    7c92:	ldmxcsr DWORD PTR [r12-0x28]
    7c98:	movdqu xmm2,XMMWORD PTR [rsp]
    7c9d:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7ca3:	mov    rbx,QWORD PTR [r12+0x108]
    7cab:	mov    QWORD PTR [r12+0x378],0x2
    7cb7:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7cc0:	movdqa xmm4,xmm0
    7cc4:	movdqa xmm0,xmm4
    7cc8:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7cd2:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7cdc:	movdqa xmm2,xmm0
    7ce0:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7cea:	movdqa xmm3,xmm0
    7cee:	cmp    DWORD PTR [r12+0x310],0x0
    7cf7:	jne    0x7ddb
    7cfd:	movdqa xmm0,xmm2
    7d01:	movdqa xmm1,xmm3
    7d05:	movq   rax,xmm0
    7d0a:	add    rax,rax
    7d0d:	je     0x7d23
    7d0f:	shr    rax,0x35
    7d13:	sub    eax,0x201
    7d18:	cmp    eax,0x3fc
    7d1d:	ja     0x7ddb
    7d23:	movdqa xmm14,xmm0
    7d28:	psrldq xmm14,0x8
    7d2e:	movq   rax,xmm14
    7d33:	add    rax,rax
    7d36:	je     0x7d4c
    7d38:	shr    rax,0x35
    7d3c:	sub    eax,0x201
    7d41:	cmp    eax,0x3fc
    7d46:	ja     0x7ddb
    7d4c:	movq   rax,xmm1
    7d51:	add    rax,rax
    7d54:	je     0x7d6a
    7d56:	shr    rax,0x35
    7d5a:	sub    eax,0x201
    7d5f:	cmp    eax,0x3fc
    7d64:	ja     0x7ddb
    7d6a:	movdqa xmm14,xmm1
    7d6f:	psrldq xmm14,0x8
    7d75:	movq   rax,xmm14
    7d7a:	add    rax,rax
    7d7d:	je     0x7d93
    7d7f:	shr    rax,0x35
    7d83:	sub    eax,0x201
    7d88:	cmp    eax,0x3fc
    7d8d:	ja     0x7ddb
    7d93:	stmxcsr DWORD PTR [rsp+0x100]
    7d9b:	mov    DWORD PTR [rsp+0x104],0x1f80
    7da6:	ldmxcsr DWORD PTR [rsp+0x104]
    7dae:	addpd  xmm0,xmm1
    7db2:	stmxcsr DWORD PTR [rsp+0x104]
    7dba:	ldmxcsr DWORD PTR [rsp+0x100]
    7dc2:	mov    eax,DWORD PTR [rsp+0x104]
    7dc9:	shr    eax,1
    7dcb:	and    eax,0x10
    7dce:	or     DWORD PTR [r12+0x314],eax
    7dd6:	jmp    0x7e88
    7ddb:	movdqa xmm0,xmm2
    7ddf:	movdqa xmm1,xmm3
    7de3:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7dec:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7df5:	mov    QWORD PTR [r12+0x378],0x3
    7e01:	movdqu XMMWORD PTR [rsp],xmm2
    7e06:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    7e0c:	mov    QWORD PTR [r12+0x108],rbx
    7e14:	stmxcsr DWORD PTR [r12-0x28]
    7e1a:	ldmxcsr DWORD PTR [r12-0x38]
    7e20:	lea    rdi,[rsp+0xf0]
    7e28:	lea    rsi,[rsp+0xd0]
    7e30:	lea    rdx,[rsp+0xe0]
    7e38:	mov    ecx,0x14
    7e3d:	mov    r8d,DWORD PTR [r12+0x310]
    7e45:	lea    r9,[r12+0x314]
    7e4d:	movabs r11,0x5a1b9d18a750
    7e57:	call   r11
    7e5a:	ldmxcsr DWORD PTR [r12-0x28]
    7e60:	movdqu xmm2,XMMWORD PTR [rsp]
    7e65:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    7e6b:	mov    rbx,QWORD PTR [r12+0x108]
    7e73:	mov    QWORD PTR [r12+0x378],0x2
    7e7f:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    7e88:	movdqa xmm4,xmm0
    7e8c:	movdqa xmm0,xmm4
    7e90:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7e9a:	mov    r13,QWORD PTR [r12+0xf8]
    7ea2:	mov    r14,r13
    7ea5:	add    r14,0x10
    7ea9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7eaf:	movdqu xmm3,XMMWORD PTR [r14]
    7eb4:	movdqa xmm0,xmm2
    7eb8:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7ec2:	movdqa xmm0,xmm3
    7ec6:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7ed0:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7eda:	movdqa xmm2,xmm0
    7ede:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7ee8:	movdqa xmm3,xmm0
    7eec:	cmp    DWORD PTR [r12+0x310],0x0
    7ef5:	jne    0x7fd9
    7efb:	movdqa xmm0,xmm2
    7eff:	movdqa xmm1,xmm3
    7f03:	movq   rax,xmm0
    7f08:	add    rax,rax
    7f0b:	je     0x7f21
    7f0d:	shr    rax,0x35
    7f11:	sub    eax,0x201
    7f16:	cmp    eax,0x3fc
    7f1b:	ja     0x7fd9
    7f21:	movdqa xmm14,xmm0
    7f26:	psrldq xmm14,0x8
    7f2c:	movq   rax,xmm14
    7f31:	add    rax,rax
    7f34:	je     0x7f4a
    7f36:	shr    rax,0x35
    7f3a:	sub    eax,0x201
    7f3f:	cmp    eax,0x3fc
    7f44:	ja     0x7fd9
    7f4a:	movq   rax,xmm1
    7f4f:	add    rax,rax
    7f52:	je     0x7f68
    7f54:	shr    rax,0x35
    7f58:	sub    eax,0x201
    7f5d:	cmp    eax,0x3fc
    7f62:	ja     0x7fd9
    7f68:	movdqa xmm14,xmm1
    7f6d:	psrldq xmm14,0x8
    7f73:	movq   rax,xmm14
    7f78:	add    rax,rax
    7f7b:	je     0x7f91
    7f7d:	shr    rax,0x35
    7f81:	sub    eax,0x201
    7f86:	cmp    eax,0x3fc
    7f8b:	ja     0x7fd9
    7f91:	stmxcsr DWORD PTR [rsp+0x100]
    7f99:	mov    DWORD PTR [rsp+0x104],0x1f80
    7fa4:	ldmxcsr DWORD PTR [rsp+0x104]
    7fac:	addpd  xmm0,xmm1
    7fb0:	stmxcsr DWORD PTR [rsp+0x104]
    7fb8:	ldmxcsr DWORD PTR [rsp+0x100]
    7fc0:	mov    eax,DWORD PTR [rsp+0x104]
    7fc7:	shr    eax,1
    7fc9:	and    eax,0x10
    7fcc:	or     DWORD PTR [r12+0x314],eax
    7fd4:	jmp    0x8086
    7fd9:	movdqa xmm0,xmm2
    7fdd:	movdqa xmm1,xmm3
    7fe1:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    7fea:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    7ff3:	mov    QWORD PTR [r12+0x378],0x3
    7fff:	movdqu XMMWORD PTR [rsp],xmm2
    8004:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    800a:	mov    QWORD PTR [r12+0x108],rbx
    8012:	stmxcsr DWORD PTR [r12-0x28]
    8018:	ldmxcsr DWORD PTR [r12-0x38]
    801e:	lea    rdi,[rsp+0xf0]
    8026:	lea    rsi,[rsp+0xd0]
    802e:	lea    rdx,[rsp+0xe0]
    8036:	mov    ecx,0x14
    803b:	mov    r8d,DWORD PTR [r12+0x310]
    8043:	lea    r9,[r12+0x314]
    804b:	movabs r11,0x5a1b9d18a750
    8055:	call   r11
    8058:	ldmxcsr DWORD PTR [r12-0x28]
    805e:	movdqu xmm2,XMMWORD PTR [rsp]
    8063:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8069:	mov    rbx,QWORD PTR [r12+0x108]
    8071:	mov    QWORD PTR [r12+0x378],0x2
    807d:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    8086:	movdqa xmm4,xmm0
    808a:	movdqa xmm0,xmm4
    808e:	movdqu XMMWORD PTR [r12+0x130],xmm0
    8098:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    80a2:	movdqa xmm2,xmm0
    80a6:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    80b0:	movdqa xmm3,xmm0
    80b4:	cmp    DWORD PTR [r12+0x310],0x0
    80bd:	jne    0x81a6
    80c3:	movdqa xmm0,xmm2
    80c7:	movdqa xmm1,xmm3
    80cb:	pshufd xmm1,xmm1,0x44
    80d0:	movq   rax,xmm0
    80d5:	add    rax,rax
    80d8:	je     0x80ee
    80da:	shr    rax,0x35
    80de:	sub    eax,0x201
    80e3:	cmp    eax,0x3fc
    80e8:	ja     0x81a6
    80ee:	movdqa xmm14,xmm0
    80f3:	psrldq xmm14,0x8
    80f9:	movq   rax,xmm14
    80fe:	add    rax,rax
    8101:	je     0x8117
    8103:	shr    rax,0x35
    8107:	sub    eax,0x201
    810c:	cmp    eax,0x3fc
    8111:	ja     0x81a6
    8117:	movq   rax,xmm1
    811c:	add    rax,rax
    811f:	je     0x8135
    8121:	shr    rax,0x35
    8125:	sub    eax,0x201
    812a:	cmp    eax,0x3fc
    812f:	ja     0x81a6
    8135:	movdqa xmm14,xmm1
    813a:	psrldq xmm14,0x8
    8140:	movq   rax,xmm14
    8145:	add    rax,rax
    8148:	je     0x815e
    814a:	shr    rax,0x35
    814e:	sub    eax,0x201
    8153:	cmp    eax,0x3fc
    8158:	ja     0x81a6
    815e:	stmxcsr DWORD PTR [rsp+0x100]
    8166:	mov    DWORD PTR [rsp+0x104],0x1f80
    8171:	ldmxcsr DWORD PTR [rsp+0x104]
    8179:	mulpd  xmm0,xmm1
    817d:	stmxcsr DWORD PTR [rsp+0x104]
    8185:	ldmxcsr DWORD PTR [rsp+0x100]
    818d:	mov    eax,DWORD PTR [rsp+0x104]
    8194:	shr    eax,1
    8196:	and    eax,0x10
    8199:	or     DWORD PTR [r12+0x314],eax
    81a1:	jmp    0x8253
    81a6:	movdqa xmm0,xmm2
    81aa:	movdqa xmm1,xmm3
    81ae:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    81b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    81c0:	mov    QWORD PTR [r12+0x378],0x3
    81cc:	movdqu XMMWORD PTR [rsp],xmm2
    81d1:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    81d7:	mov    QWORD PTR [r12+0x108],rbx
    81df:	stmxcsr DWORD PTR [r12-0x28]
    81e5:	ldmxcsr DWORD PTR [r12-0x38]
    81eb:	lea    rdi,[rsp+0xf0]
    81f3:	lea    rsi,[rsp+0xd0]
    81fb:	lea    rdx,[rsp+0xe0]
    8203:	mov    ecx,0x56
    8208:	mov    r8d,DWORD PTR [r12+0x310]
    8210:	lea    r9,[r12+0x314]
    8218:	movabs r11,0x5a1b9d18a750
    8222:	call   r11
    8225:	ldmxcsr DWORD PTR [r12-0x28]
    822b:	movdqu xmm2,XMMWORD PTR [rsp]
    8230:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8236:	mov    rbx,QWORD PTR [r12+0x108]
    823e:	mov    QWORD PTR [r12+0x378],0x2
    824a:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    8253:	movdqa xmm4,xmm0
    8257:	movdqa xmm0,xmm4
    825b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    8265:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    826f:	movdqa xmm2,xmm0
    8273:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    827d:	movdqa xmm3,xmm0
    8281:	cmp    DWORD PTR [r12+0x310],0x0
    828a:	jne    0x8373
    8290:	movdqa xmm0,xmm2
    8294:	movdqa xmm1,xmm3
    8298:	pshufd xmm1,xmm1,0x44
    829d:	movq   rax,xmm0
    82a2:	add    rax,rax
    82a5:	je     0x82bb
    82a7:	shr    rax,0x35
    82ab:	sub    eax,0x201
    82b0:	cmp    eax,0x3fc
    82b5:	ja     0x8373
    82bb:	movdqa xmm14,xmm0
    82c0:	psrldq xmm14,0x8
    82c6:	movq   rax,xmm14
    82cb:	add    rax,rax
    82ce:	je     0x82e4
    82d0:	shr    rax,0x35
    82d4:	sub    eax,0x201
    82d9:	cmp    eax,0x3fc
    82de:	ja     0x8373
    82e4:	movq   rax,xmm1
    82e9:	add    rax,rax
    82ec:	je     0x8302
    82ee:	shr    rax,0x35
    82f2:	sub    eax,0x201
    82f7:	cmp    eax,0x3fc
    82fc:	ja     0x8373
    8302:	movdqa xmm14,xmm1
    8307:	psrldq xmm14,0x8
    830d:	movq   rax,xmm14
    8312:	add    rax,rax
    8315:	je     0x832b
    8317:	shr    rax,0x35
    831b:	sub    eax,0x201
    8320:	cmp    eax,0x3fc
    8325:	ja     0x8373
    832b:	stmxcsr DWORD PTR [rsp+0x100]
    8333:	mov    DWORD PTR [rsp+0x104],0x1f80
    833e:	ldmxcsr DWORD PTR [rsp+0x104]
    8346:	mulpd  xmm0,xmm1
    834a:	stmxcsr DWORD PTR [rsp+0x104]
    8352:	ldmxcsr DWORD PTR [rsp+0x100]
    835a:	mov    eax,DWORD PTR [rsp+0x104]
    8361:	shr    eax,1
    8363:	and    eax,0x10
    8366:	or     DWORD PTR [r12+0x314],eax
    836e:	jmp    0x8420
    8373:	movdqa xmm0,xmm2
    8377:	movdqa xmm1,xmm3
    837b:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    8384:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    838d:	mov    QWORD PTR [r12+0x378],0x3
    8399:	movdqu XMMWORD PTR [rsp],xmm2
    839e:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    83a4:	mov    QWORD PTR [r12+0x108],rbx
    83ac:	stmxcsr DWORD PTR [r12-0x28]
    83b2:	ldmxcsr DWORD PTR [r12-0x38]
    83b8:	lea    rdi,[rsp+0xf0]
    83c0:	lea    rsi,[rsp+0xd0]
    83c8:	lea    rdx,[rsp+0xe0]
    83d0:	mov    ecx,0x56
    83d5:	mov    r8d,DWORD PTR [r12+0x310]
    83dd:	lea    r9,[r12+0x314]
    83e5:	movabs r11,0x5a1b9d18a750
    83ef:	call   r11
    83f2:	ldmxcsr DWORD PTR [r12-0x28]
    83f8:	movdqu xmm2,XMMWORD PTR [rsp]
    83fd:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8403:	mov    rbx,QWORD PTR [r12+0x108]
    840b:	mov    QWORD PTR [r12+0x378],0x2
    8417:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    8420:	movdqa xmm4,xmm0
    8424:	movdqa xmm0,xmm4
    8428:	movdqu XMMWORD PTR [r12+0x120],xmm0
    8432:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    843c:	movdqa xmm2,xmm0
    8440:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    844a:	movdqa xmm3,xmm0
    844e:	cmp    DWORD PTR [r12+0x310],0x0
    8457:	jne    0x853b
    845d:	movdqa xmm0,xmm2
    8461:	movdqa xmm1,xmm3
    8465:	movq   rax,xmm0
    846a:	add    rax,rax
    846d:	je     0x8483
    846f:	shr    rax,0x35
    8473:	sub    eax,0x201
    8478:	cmp    eax,0x3fc
    847d:	ja     0x853b
    8483:	movdqa xmm14,xmm0
    8488:	psrldq xmm14,0x8
    848e:	movq   rax,xmm14
    8493:	add    rax,rax
    8496:	je     0x84ac
    8498:	shr    rax,0x35
    849c:	sub    eax,0x201
    84a1:	cmp    eax,0x3fc
    84a6:	ja     0x853b
    84ac:	movq   rax,xmm1
    84b1:	add    rax,rax
    84b4:	je     0x84ca
    84b6:	shr    rax,0x35
    84ba:	sub    eax,0x201
    84bf:	cmp    eax,0x3fc
    84c4:	ja     0x853b
    84ca:	movdqa xmm14,xmm1
    84cf:	psrldq xmm14,0x8
    84d5:	movq   rax,xmm14
    84da:	add    rax,rax
    84dd:	je     0x84f3
    84df:	shr    rax,0x35
    84e3:	sub    eax,0x201
    84e8:	cmp    eax,0x3fc
    84ed:	ja     0x853b
    84f3:	stmxcsr DWORD PTR [rsp+0x100]
    84fb:	mov    DWORD PTR [rsp+0x104],0x1f80
    8506:	ldmxcsr DWORD PTR [rsp+0x104]
    850e:	addpd  xmm0,xmm1
    8512:	stmxcsr DWORD PTR [rsp+0x104]
    851a:	ldmxcsr DWORD PTR [rsp+0x100]
    8522:	mov    eax,DWORD PTR [rsp+0x104]
    8529:	shr    eax,1
    852b:	and    eax,0x10
    852e:	or     DWORD PTR [r12+0x314],eax
    8536:	jmp    0x85e8
    853b:	movdqa xmm0,xmm2
    853f:	movdqa xmm1,xmm3
    8543:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    854c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    8555:	mov    QWORD PTR [r12+0x378],0x3
    8561:	movdqu XMMWORD PTR [rsp],xmm2
    8566:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    856c:	mov    QWORD PTR [r12+0x108],rbx
    8574:	stmxcsr DWORD PTR [r12-0x28]
    857a:	ldmxcsr DWORD PTR [r12-0x38]
    8580:	lea    rdi,[rsp+0xf0]
    8588:	lea    rsi,[rsp+0xd0]
    8590:	lea    rdx,[rsp+0xe0]
    8598:	mov    ecx,0x14
    859d:	mov    r8d,DWORD PTR [r12+0x310]
    85a5:	lea    r9,[r12+0x314]
    85ad:	movabs r11,0x5a1b9d18a750
    85b7:	call   r11
    85ba:	ldmxcsr DWORD PTR [r12-0x28]
    85c0:	movdqu xmm2,XMMWORD PTR [rsp]
    85c5:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    85cb:	mov    rbx,QWORD PTR [r12+0x108]
    85d3:	mov    QWORD PTR [r12+0x378],0x2
    85df:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    85e8:	movdqa xmm4,xmm0
    85ec:	movdqa xmm0,xmm4
    85f0:	movdqu XMMWORD PTR [r12+0x140],xmm0
    85fa:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    8604:	movdqa xmm2,xmm0
    8608:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    8612:	movdqa xmm3,xmm0
    8616:	cmp    DWORD PTR [r12+0x310],0x0
    861f:	jne    0x8703
    8625:	movdqa xmm0,xmm2
    8629:	movdqa xmm1,xmm3
    862d:	movq   rax,xmm0
    8632:	add    rax,rax
    8635:	je     0x864b
    8637:	shr    rax,0x35
    863b:	sub    eax,0x201
    8640:	cmp    eax,0x3fc
    8645:	ja     0x8703
    864b:	movdqa xmm14,xmm0
    8650:	psrldq xmm14,0x8
    8656:	movq   rax,xmm14
    865b:	add    rax,rax
    865e:	je     0x8674
    8660:	shr    rax,0x35
    8664:	sub    eax,0x201
    8669:	cmp    eax,0x3fc
    866e:	ja     0x8703
    8674:	movq   rax,xmm1
    8679:	add    rax,rax
    867c:	je     0x8692
    867e:	shr    rax,0x35
    8682:	sub    eax,0x201
    8687:	cmp    eax,0x3fc
    868c:	ja     0x8703
    8692:	movdqa xmm14,xmm1
    8697:	psrldq xmm14,0x8
    869d:	movq   rax,xmm14
    86a2:	add    rax,rax
    86a5:	je     0x86bb
    86a7:	shr    rax,0x35
    86ab:	sub    eax,0x201
    86b0:	cmp    eax,0x3fc
    86b5:	ja     0x8703
    86bb:	stmxcsr DWORD PTR [rsp+0x100]
    86c3:	mov    DWORD PTR [rsp+0x104],0x1f80
    86ce:	ldmxcsr DWORD PTR [rsp+0x104]
    86d6:	addpd  xmm0,xmm1
    86da:	stmxcsr DWORD PTR [rsp+0x104]
    86e2:	ldmxcsr DWORD PTR [rsp+0x100]
    86ea:	mov    eax,DWORD PTR [rsp+0x104]
    86f1:	shr    eax,1
    86f3:	and    eax,0x10
    86f6:	or     DWORD PTR [r12+0x314],eax
    86fe:	jmp    0x87b0
    8703:	movdqa xmm0,xmm2
    8707:	movdqa xmm1,xmm3
    870b:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    8714:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    871d:	mov    QWORD PTR [r12+0x378],0x3
    8729:	movdqu XMMWORD PTR [rsp],xmm2
    872e:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    8734:	mov    QWORD PTR [r12+0x108],rbx
    873c:	stmxcsr DWORD PTR [r12-0x28]
    8742:	ldmxcsr DWORD PTR [r12-0x38]
    8748:	lea    rdi,[rsp+0xf0]
    8750:	lea    rsi,[rsp+0xd0]
    8758:	lea    rdx,[rsp+0xe0]
    8760:	mov    ecx,0x14
    8765:	mov    r8d,DWORD PTR [r12+0x310]
    876d:	lea    r9,[r12+0x314]
    8775:	movabs r11,0x5a1b9d18a750
    877f:	call   r11
    8782:	ldmxcsr DWORD PTR [r12-0x28]
    8788:	movdqu xmm2,XMMWORD PTR [rsp]
    878d:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8793:	mov    rbx,QWORD PTR [r12+0x108]
    879b:	mov    QWORD PTR [r12+0x378],0x2
    87a7:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    87b0:	movdqa xmm4,xmm0
    87b4:	movdqa xmm0,xmm4
    87b8:	movdqu XMMWORD PTR [r12+0x150],xmm0
    87c2:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    87cc:	movdqa xmm2,xmm0
    87d0:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    87da:	movdqa xmm3,xmm0
    87de:	cmp    DWORD PTR [r12+0x310],0x0
    87e7:	jne    0x88cb
    87ed:	movdqa xmm0,xmm2
    87f1:	movdqa xmm1,xmm3
    87f5:	movq   rax,xmm0
    87fa:	add    rax,rax
    87fd:	je     0x8813
    87ff:	shr    rax,0x35
    8803:	sub    eax,0x201
    8808:	cmp    eax,0x3fc
    880d:	ja     0x88cb
    8813:	movdqa xmm14,xmm0
    8818:	psrldq xmm14,0x8
    881e:	movq   rax,xmm14
    8823:	add    rax,rax
    8826:	je     0x883c
    8828:	shr    rax,0x35
    882c:	sub    eax,0x201
    8831:	cmp    eax,0x3fc
    8836:	ja     0x88cb
    883c:	movq   rax,xmm1
    8841:	add    rax,rax
    8844:	je     0x885a
    8846:	shr    rax,0x35
    884a:	sub    eax,0x201
    884f:	cmp    eax,0x3fc
    8854:	ja     0x88cb
    885a:	movdqa xmm14,xmm1
    885f:	psrldq xmm14,0x8
    8865:	movq   rax,xmm14
    886a:	add    rax,rax
    886d:	je     0x8883
    886f:	shr    rax,0x35
    8873:	sub    eax,0x201
    8878:	cmp    eax,0x3fc
    887d:	ja     0x88cb
    8883:	stmxcsr DWORD PTR [rsp+0x100]
    888b:	mov    DWORD PTR [rsp+0x104],0x1f80
    8896:	ldmxcsr DWORD PTR [rsp+0x104]
    889e:	addpd  xmm0,xmm1
    88a2:	stmxcsr DWORD PTR [rsp+0x104]
    88aa:	ldmxcsr DWORD PTR [rsp+0x100]
    88b2:	mov    eax,DWORD PTR [rsp+0x104]
    88b9:	shr    eax,1
    88bb:	and    eax,0x10
    88be:	or     DWORD PTR [r12+0x314],eax
    88c6:	jmp    0x8978
    88cb:	movdqa xmm0,xmm2
    88cf:	movdqa xmm1,xmm3
    88d3:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    88dc:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    88e5:	mov    QWORD PTR [r12+0x378],0x3
    88f1:	movdqu XMMWORD PTR [rsp],xmm2
    88f6:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    88fc:	mov    QWORD PTR [r12+0x108],rbx
    8904:	stmxcsr DWORD PTR [r12-0x28]
    890a:	ldmxcsr DWORD PTR [r12-0x38]
    8910:	lea    rdi,[rsp+0xf0]
    8918:	lea    rsi,[rsp+0xd0]
    8920:	lea    rdx,[rsp+0xe0]
    8928:	mov    ecx,0x14
    892d:	mov    r8d,DWORD PTR [r12+0x310]
    8935:	lea    r9,[r12+0x314]
    893d:	movabs r11,0x5a1b9d18a750
    8947:	call   r11
    894a:	ldmxcsr DWORD PTR [r12-0x28]
    8950:	movdqu xmm2,XMMWORD PTR [rsp]
    8955:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    895b:	mov    rbx,QWORD PTR [r12+0x108]
    8963:	mov    QWORD PTR [r12+0x378],0x2
    896f:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    8978:	movdqa xmm4,xmm0
    897c:	movdqa xmm0,xmm4
    8980:	movdqu XMMWORD PTR [r12+0x160],xmm0
    898a:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    8994:	movdqa xmm2,xmm0
    8998:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    89a2:	movdqa xmm3,xmm0
    89a6:	cmp    DWORD PTR [r12+0x310],0x0
    89af:	jne    0x8a93
    89b5:	movdqa xmm0,xmm2
    89b9:	movdqa xmm1,xmm3
    89bd:	movq   rax,xmm0
    89c2:	add    rax,rax
    89c5:	je     0x89db
    89c7:	shr    rax,0x35
    89cb:	sub    eax,0x201
    89d0:	cmp    eax,0x3fc
    89d5:	ja     0x8a93
    89db:	movdqa xmm14,xmm0
    89e0:	psrldq xmm14,0x8
    89e6:	movq   rax,xmm14
    89eb:	add    rax,rax
    89ee:	je     0x8a04
    89f0:	shr    rax,0x35
    89f4:	sub    eax,0x201
    89f9:	cmp    eax,0x3fc
    89fe:	ja     0x8a93
    8a04:	movq   rax,xmm1
    8a09:	add    rax,rax
    8a0c:	je     0x8a22
    8a0e:	shr    rax,0x35
    8a12:	sub    eax,0x201
    8a17:	cmp    eax,0x3fc
    8a1c:	ja     0x8a93
    8a22:	movdqa xmm14,xmm1
    8a27:	psrldq xmm14,0x8
    8a2d:	movq   rax,xmm14
    8a32:	add    rax,rax
    8a35:	je     0x8a4b
    8a37:	shr    rax,0x35
    8a3b:	sub    eax,0x201
    8a40:	cmp    eax,0x3fc
    8a45:	ja     0x8a93
    8a4b:	stmxcsr DWORD PTR [rsp+0x100]
    8a53:	mov    DWORD PTR [rsp+0x104],0x1f80
    8a5e:	ldmxcsr DWORD PTR [rsp+0x104]
    8a66:	addpd  xmm0,xmm1
    8a6a:	stmxcsr DWORD PTR [rsp+0x104]
    8a72:	ldmxcsr DWORD PTR [rsp+0x100]
    8a7a:	mov    eax,DWORD PTR [rsp+0x104]
    8a81:	shr    eax,1
    8a83:	and    eax,0x10
    8a86:	or     DWORD PTR [r12+0x314],eax
    8a8e:	jmp    0x8b40
    8a93:	movdqa xmm0,xmm2
    8a97:	movdqa xmm1,xmm3
    8a9b:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    8aa4:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    8aad:	mov    QWORD PTR [r12+0x378],0x3
    8ab9:	movdqu XMMWORD PTR [rsp],xmm2
    8abe:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    8ac4:	mov    QWORD PTR [r12+0x108],rbx
    8acc:	stmxcsr DWORD PTR [r12-0x28]
    8ad2:	ldmxcsr DWORD PTR [r12-0x38]
    8ad8:	lea    rdi,[rsp+0xf0]
    8ae0:	lea    rsi,[rsp+0xd0]
    8ae8:	lea    rdx,[rsp+0xe0]
    8af0:	mov    ecx,0x14
    8af5:	mov    r8d,DWORD PTR [r12+0x310]
    8afd:	lea    r9,[r12+0x314]
    8b05:	movabs r11,0x5a1b9d18a750
    8b0f:	call   r11
    8b12:	ldmxcsr DWORD PTR [r12-0x28]
    8b18:	movdqu xmm2,XMMWORD PTR [rsp]
    8b1d:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    8b23:	mov    rbx,QWORD PTR [r12+0x108]
    8b2b:	mov    QWORD PTR [r12+0x378],0x2
    8b37:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    8b40:	movdqa xmm4,xmm0
    8b44:	movdqa xmm0,xmm4
    8b48:	movdqu XMMWORD PTR [r12+0x120],xmm0
    8b52:	mov    r13,QWORD PTR [r12+0x60]
    8b57:	mov    r14,r13
    8b5a:	add    r14,0x10
    8b5e:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    8b68:	movdqa xmm2,xmm0
    8b6c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    8b76:	movdqa xmm3,xmm0
    8b7a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    8b80:	mov    r15d,0x0
    8b86:	mov    DWORD PTR [r12+0x32c],r15d
    8b8e:	movdqu XMMWORD PTR [r14],xmm3
    8b93:	mov    r14d,0x0
    8b99:	mov    DWORD PTR [r12+0x32c],r14d
    8ba1:	mov    r14,r13
    8ba4:	add    r14,0x20
    8ba8:	mov    r13,r14
    8bab:	add    r13,0x10
    8baf:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    8bb9:	movdqa xmm2,xmm0
    8bbd:	movdqu XMMWORD PTR [r14],xmm2
    8bc2:	mov    r14d,0x0
    8bc8:	mov    DWORD PTR [r12+0x32c],r14d
    8bd0:	movdqu XMMWORD PTR [r13+0x0],xmm4
    8bd6:	mov    r13d,0x0
    8bdc:	mov    DWORD PTR [r12+0x32c],r13d
    8be4:	cmp    QWORD PTR [r12+0x380],0x0
    8bed:	je     0x8c21
    8bf3:	mov    eax,0x410440
    8bf8:	mov    QWORD PTR [r12+0x100],rax
    8c00:	mov    QWORD PTR [r12+0x108],rbx
    8c08:	add    rsp,0x140
    8c0f:	mov    eax,0xc
    8c14:	movabs r11,0x5a1b9d31e5f0
    8c1e:	jmp    r11
    8c21:	test   ebx,0x40000000
    8c27:	je     0x10c7
    8c2d:	jmp    0x8c32
    8c32:	mov    r13d,DWORD PTR [r12+0x48]
    8c37:	mov    r14d,r13d
    8c3a:	add    r14d,0x1
    8c3e:	mov    QWORD PTR [r12+0x48],r14
    8c43:	mov    r13d,r14d
    8c46:	sub    r13d,0x1f4
    8c4d:	pushf
    8c4e:	pop    rdx
    8c4f:	mov    r10d,edx
    8c52:	and    r10d,0xc0
    8c59:	shl    r10d,0x18
    8c5d:	mov    r11d,edx
    8c60:	and    r11d,0x1
    8c64:	shl    r11d,0x1d
    8c68:	or     r10d,r11d
    8c6b:	mov    r11d,edx
    8c6e:	and    r11d,0x800
    8c75:	shl    r11d,0x11
    8c79:	or     r10d,r11d
    8c7c:	mov    r11d,0xf0000000
    8c82:	and    r11,r10
    8c85:	movabs rsi,0xffffffff0fffffff
    8c8f:	and    rbx,rsi
    8c92:	or     rbx,r11
    8c95:	btc    rbx,0x1d
    8c9a:	cmp    QWORD PTR [r12+0x380],0x0
    8ca3:	je     0x8cd7
    8ca9:	mov    eax,0x41044c
    8cae:	mov    QWORD PTR [r12+0x100],rax
    8cb6:	mov    QWORD PTR [r12+0x108],rbx
    8cbe:	add    rsp,0x140
    8cc5:	mov    eax,0xc
    8cca:	movabs r11,0x5a1b9d31e5f0
    8cd4:	jmp    r11
    8cd7:	test   ebx,0x40000000
    8cdd:	je     0x10b7
    8ce3:	jmp    0x8ce8
    8ce8:	mov    r13d,0x0
    8cee:	mov    QWORD PTR [r12+0x48],r13
    8cf3:	mov    r13,QWORD PTR [r12+0xf8]
    8cfb:	mov    r14,r13
    8cfe:	add    r14,0x140
    8d05:	mov    r15,QWORD PTR [r14]
    8d08:	mov    QWORD PTR [r12+0xe8],r15
    8d10:	mov    r14,r13
    8d13:	add    r14,0x130
    8d1a:	mov    r15,r14
    8d1d:	add    r15,0x8
    8d21:	mov    rbp,QWORD PTR [r14]
    8d24:	mov    r14,QWORD PTR [r15]
    8d27:	mov    r15d,0x0
    8d2d:	mov    QWORD PTR [r12+0x1a0],rbp
    8d35:	mov    QWORD PTR [r12+0x1a8],r15
    8d3d:	mov    r15d,0x0
    8d43:	mov    QWORD PTR [r12+0x190],r14
    8d4b:	mov    QWORD PTR [r12+0x198],r15
    8d53:	mov    r14,r13
    8d56:	add    r14,0x120
    8d5d:	mov    r13,r14
    8d60:	add    r13,0x8
    8d64:	mov    r15,QWORD PTR [r14]
    8d67:	mov    r14,QWORD PTR [r13+0x0]
    8d6b:	mov    r13d,0x0
    8d71:	mov    QWORD PTR [r12+0x1c0],r15
    8d79:	mov    QWORD PTR [r12+0x1c8],r13
    8d81:	mov    r13d,0x0
    8d87:	mov    QWORD PTR [r12+0x1b0],r14
    8d8f:	mov    QWORD PTR [r12+0x1b8],r13
    8d97:	mov    r13,QWORD PTR [r12+0xf8]
    8d9f:	mov    r14,r13
    8da2:	add    r14,0x110
    8da9:	mov    r15,r14
    8dac:	add    r15,0x8
    8db0:	mov    rbp,QWORD PTR [r14]
    8db3:	mov    r14,QWORD PTR [r15]
    8db6:	mov    r15d,0x0
    8dbc:	mov    QWORD PTR [r12+0x1e0],rbp
    8dc4:	mov    QWORD PTR [r12+0x1e8],r15
    8dcc:	mov    r15d,0x0
    8dd2:	mov    QWORD PTR [r12+0x1d0],r14
    8dda:	mov    QWORD PTR [r12+0x1d8],r15
    8de2:	mov    r14,r13
    8de5:	add    r14,0x100
    8dec:	mov    r13,r14
    8def:	add    r13,0x8
    8df3:	mov    r15,QWORD PTR [r14]
    8df6:	mov    r14,QWORD PTR [r13+0x0]
    8dfa:	mov    r13d,0x0
    8e00:	mov    QWORD PTR [r12+0x200],r15
    8e08:	mov    QWORD PTR [r12+0x208],r13
    8e10:	mov    r13d,0x0
    8e16:	mov    QWORD PTR [r12+0x1f0],r14
    8e1e:	mov    QWORD PTR [r12+0x1f8],r13
    8e26:	mov    r13d,0x430000
    8e2c:	mov    QWORD PTR [r12+0x40],r13
    8e31:	mov    r13d,0x430510
    8e37:	mov    r14,QWORD PTR [r13+0x0]
    8e3b:	mov    r13d,0x0
    8e41:	mov    QWORD PTR [r12+0x110],r14
    8e49:	mov    QWORD PTR [r12+0x118],r13
    8e51:	mov    r13,QWORD PTR [r12+0xf8]
    8e59:	mov    r14,r13
    8e5c:	add    r14,0x150
    8e63:	mov    QWORD PTR [r12+0xf8],r14
    8e6b:	jmp    0x8e70
    8e70:	mov    r13,QWORD PTR [r12+0x48]
    8e75:	mov    r14,QWORD PTR [r12+0x50]
    8e7a:	mov    rcx,r13
    8e7d:	mov    r15,r14
    8e80:	add    r15,rcx
    8e83:	movdqu xmm2,XMMWORD PTR [r15]
    8e88:	movdqa xmm0,xmm2
    8e8c:	movdqu XMMWORD PTR [r12+0x120],xmm0
    8e96:	mov    r14,r13
    8e99:	add    r14,0x10
    8e9d:	mov    QWORD PTR [r12+0x48],r14
    8ea2:	mov    r13,r14
    8ea5:	sub    r13,0x200
    8eac:	pushf
    8ead:	pop    rdx
    8eae:	mov    r10d,edx
    8eb1:	and    r10d,0xc0
    8eb8:	shl    r10d,0x18
    8ebc:	mov    r11d,edx
    8ebf:	and    r11d,0x1
    8ec3:	shl    r11d,0x1d
    8ec7:	or     r10d,r11d
    8eca:	mov    r11d,edx
    8ecd:	and    r11d,0x800
    8ed4:	shl    r11d,0x11
    8ed8:	or     r10d,r11d
    8edb:	mov    r11d,0xf0000000
    8ee1:	and    r11,r10
    8ee4:	movabs rsi,0xffffffff0fffffff
    8eee:	and    rbx,rsi
    8ef1:	or     rbx,r11
    8ef4:	btc    rbx,0x1d
    8ef9:	mov    r13,QWORD PTR [r12+0x128]
    8f01:	mov    r14d,0x0
    8f07:	mov    QWORD PTR [r12+0x130],r13
    8f0f:	mov    QWORD PTR [r12+0x138],r14
    8f17:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    8f21:	movdqa xmm2,xmm0
    8f25:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    8f2f:	movdqa xmm3,xmm0
    8f33:	cmp    DWORD PTR [r12+0x310],0x0
    8f3c:	jne    0x8fd6
    8f42:	movdqa xmm0,xmm2
    8f46:	movdqa xmm1,xmm3
    8f4a:	movq   rax,xmm0
    8f4f:	add    rax,rax
    8f52:	je     0x8f68
    8f54:	shr    rax,0x35
    8f58:	sub    eax,0x201
    8f5d:	cmp    eax,0x3fc
    8f62:	ja     0x8fd6
    8f68:	movq   rax,xmm1
    8f6d:	add    rax,rax
    8f70:	je     0x8f86
    8f72:	shr    rax,0x35
    8f76:	sub    eax,0x201
    8f7b:	cmp    eax,0x3fc
    8f80:	ja     0x8fd6
    8f86:	movq   xmm0,xmm0
    8f8a:	movq   xmm1,xmm1
    8f8e:	stmxcsr DWORD PTR [rsp+0x100]
    8f96:	mov    DWORD PTR [rsp+0x104],0x1f80
    8fa1:	ldmxcsr DWORD PTR [rsp+0x104]
    8fa9:	addsd  xmm0,xmm1
    8fad:	stmxcsr DWORD PTR [rsp+0x104]
    8fb5:	ldmxcsr DWORD PTR [rsp+0x100]
    8fbd:	mov    eax,DWORD PTR [rsp+0x104]
    8fc4:	shr    eax,1
    8fc6:	and    eax,0x10
    8fc9:	or     DWORD PTR [r12+0x314],eax
    8fd1:	jmp    0x9083
    8fd6:	movdqa xmm0,xmm2
    8fda:	movdqa xmm1,xmm3
    8fde:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    8fe7:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    8ff0:	mov    QWORD PTR [r12+0x378],0x3
    8ffc:	movdqu XMMWORD PTR [rsp],xmm2
    9001:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    9007:	mov    QWORD PTR [r12+0x108],rbx
    900f:	stmxcsr DWORD PTR [r12-0x28]
    9015:	ldmxcsr DWORD PTR [r12-0x38]
    901b:	lea    rdi,[rsp+0xf0]
    9023:	lea    rsi,[rsp+0xd0]
    902b:	lea    rdx,[rsp+0xe0]
    9033:	mov    ecx,0xc
    9038:	mov    r8d,DWORD PTR [r12+0x310]
    9040:	lea    r9,[r12+0x314]
    9048:	movabs r11,0x5a1b9d18a750
    9052:	call   r11
    9055:	ldmxcsr DWORD PTR [r12-0x28]
    905b:	movdqu xmm2,XMMWORD PTR [rsp]
    9060:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    9066:	mov    rbx,QWORD PTR [r12+0x108]
    906e:	mov    QWORD PTR [r12+0x378],0x2
    907a:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    9083:	movdqa xmm4,xmm0
    9087:	movdqa xmm0,xmm4
    908b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    9095:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    909f:	movdqa xmm2,xmm0
    90a3:	cmp    DWORD PTR [r12+0x310],0x0
    90ac:	jne    0x9146
    90b2:	movdqa xmm0,xmm4
    90b6:	movdqa xmm1,xmm2
    90ba:	movq   rax,xmm0
    90bf:	add    rax,rax
    90c2:	je     0x90d8
    90c4:	shr    rax,0x35
    90c8:	sub    eax,0x201
    90cd:	cmp    eax,0x3fc
    90d2:	ja     0x9146
    90d8:	movq   rax,xmm1
    90dd:	add    rax,rax
    90e0:	je     0x90f6
    90e2:	shr    rax,0x35
    90e6:	sub    eax,0x201
    90eb:	cmp    eax,0x3fc
    90f0:	ja     0x9146
    90f6:	movq   xmm0,xmm0
    90fa:	movq   xmm1,xmm1
    90fe:	stmxcsr DWORD PTR [rsp+0x100]
    9106:	mov    DWORD PTR [rsp+0x104],0x1f80
    9111:	ldmxcsr DWORD PTR [rsp+0x104]
    9119:	addsd  xmm0,xmm1
    911d:	stmxcsr DWORD PTR [rsp+0x104]
    9125:	ldmxcsr DWORD PTR [rsp+0x100]
    912d:	mov    eax,DWORD PTR [rsp+0x104]
    9134:	shr    eax,1
    9136:	and    eax,0x10
    9139:	or     DWORD PTR [r12+0x314],eax
    9141:	jmp    0x91f3
    9146:	movdqa xmm0,xmm4
    914a:	movdqa xmm1,xmm2
    914e:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    9157:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    9160:	mov    QWORD PTR [r12+0x378],0x3
    916c:	movdqu XMMWORD PTR [rsp],xmm2
    9171:	movdqu XMMWORD PTR [rsp+0x20],xmm4
    9177:	mov    QWORD PTR [r12+0x108],rbx
    917f:	stmxcsr DWORD PTR [r12-0x28]
    9185:	ldmxcsr DWORD PTR [r12-0x38]
    918b:	lea    rdi,[rsp+0xf0]
    9193:	lea    rsi,[rsp+0xd0]
    919b:	lea    rdx,[rsp+0xe0]
    91a3:	mov    ecx,0xc
    91a8:	mov    r8d,DWORD PTR [r12+0x310]
    91b0:	lea    r9,[r12+0x314]
    91b8:	movabs r11,0x5a1b9d18a750
    91c2:	call   r11
    91c5:	ldmxcsr DWORD PTR [r12-0x28]
    91cb:	movdqu xmm2,XMMWORD PTR [rsp]
    91d0:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
    91d6:	mov    rbx,QWORD PTR [r12+0x108]
    91de:	mov    QWORD PTR [r12+0x378],0x2
    91ea:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    91f3:	movdqa xmm3,xmm0
    91f7:	movdqa xmm0,xmm3
    91fb:	movdqu XMMWORD PTR [r12+0x110],xmm0
    9205:	cmp    QWORD PTR [r12+0x380],0x0
    920e:	je     0x9242
    9214:	mov    eax,0x41048c
    9219:	mov    QWORD PTR [r12+0x100],rax
    9221:	mov    QWORD PTR [r12+0x108],rbx
    9229:	add    rsp,0x140
    9230:	mov    eax,0xc
    9235:	movabs r11,0x5a1b9d31e5f0
    923f:	jmp    r11
    9242:	test   ebx,0x40000000
    9248:	je     0x8e70
    924e:	jmp    0x9253
    9253:	mov    r13,QWORD PTR [r12+0x40]
    9258:	mov    r14,r13
    925b:	add    r14,0x510
    9262:	mov    r13,QWORD PTR [r12+0x110]
    926a:	mov    QWORD PTR [r14],r13
    926d:	mov    r13d,0x0
    9273:	mov    DWORD PTR [r12+0x32c],r13d
    927b:	cmp    QWORD PTR [r12+0x380],0x0
    9284:	je     0x92b8
    928a:	mov    eax,0x410494
    928f:	mov    QWORD PTR [r12+0x100],rax
    9297:	mov    QWORD PTR [r12+0x108],rbx
    929f:	add    rsp,0x140
    92a6:	mov    eax,0xc
    92ab:	movabs r11,0x5a1b9d31e5f0
    92b5:	jmp    r11
    92b8:	mov    r13,QWORD PTR [r12+0xf0]
    92c0:	mov    QWORD PTR [r12+0x100],r13
    92c8:	mov    QWORD PTR [r12+0x108],rbx
    92d0:	mov    rdi,QWORD PTR [r12+0x100]
    92d8:	add    rsp,0x140
    92df:	movabs r11,0x5a1b9d31e370
    92e9:	jmp    r11
    92ec:	nop    DWORD PTR [rax+0x0]
    92f0:	sub    rsp,0x140
    92f7:	jmp    0x177
    92fc:	nop    DWORD PTR [rax+0x0]
    9300:	sub    rsp,0x140
    9307:	jmp    0x932
    930c:	nop    DWORD PTR [rax+0x0]
    9310:	sub    rsp,0x140
    9317:	jmp    0x10b7
    931c:	nop    DWORD PTR [rax+0x0]
    9320:	sub    rsp,0x140
    9327:	jmp    0x10c7
    932c:	nop    DWORD PTR [rax+0x0]
    9330:	sub    rsp,0x140
    9337:	jmp    0x8c32
    933c:	nop    DWORD PTR [rax+0x0]
    9340:	sub    rsp,0x140
    9347:	jmp    0x8ce8
    934c:	nop    DWORD PTR [rax+0x0]
    9350:	sub    rsp,0x140
    9357:	jmp    0x8e70
    935c:	nop    DWORD PTR [rax+0x0]
    9360:	sub    rsp,0x140
    9367:	jmp    0x9253
