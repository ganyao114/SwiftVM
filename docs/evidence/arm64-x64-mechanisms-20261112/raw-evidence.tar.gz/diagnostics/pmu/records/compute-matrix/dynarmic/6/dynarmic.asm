0000794c94dce69b  nop [rax+rax*1], eax
0000794c94dce6a0  vmovaps xmm1, [0x0000794C949FE010]
0000794c94dce6a8  movq xmm1, xmm1
0000794c94dce6ac  movaps [r15+0x110], xmm1
0000794c94dce6b4  vmovaps xmm1, [0x0000794C949FE020]
0000794c94dce6bc  movq xmm1, xmm1
0000794c94dce6c0  movaps [r15+0x120], xmm1
0000794c94dce6c8  mov eax, 0x4204C0
0000794c94dce6cd  mov r14, [r13+rax*1]
0000794c94dce6d2  movq xmm1, r14
0000794c94dce6d7  movaps [r15+0x130], xmm1
0000794c94dce6df  vmovaps xmm1, [0x0000794C949FE030]
0000794c94dce6e7  vpbroadcastq xmm1, xmm1
0000794c94dce6ec  movaps [r15+0x140], xmm1
0000794c94dce6f4  mov qword ptr [r15+0x40], 0x02
0000794c94dce6fc  vmovaps xmm15, [0x0000794C949FE040]
0000794c94dce704  movq xmm15, xmm15
0000794c94dce709  movaps [r15+0x150], xmm15
0000794c94dce711  mov qword ptr [r15+0x58], 0x420000
0000794c94dce719  vmovaps xmm15, [0x0000794C949FE050]
0000794c94dce721  vpbroadcastq xmm15, xmm15
0000794c94dce726  movaps [r15+0x160], xmm15
0000794c94dce72e  mov rax, [r15+0x40]
0000794c94dce732  vmovq xmm14, rax
0000794c94dce737  vpbroadcastq xmm14, xmm14
0000794c94dce73c  movaps [r15+0x170], xmm14
0000794c94dce744  mov eax, 0x4204D0
0000794c94dce749  movups xmm13, [r13+rax*1]
0000794c94dce74f  mov qword ptr [r15+0x40], 0x430518
0000794c94dce757  mov qword ptr [r15+0x50], 0x430720
0000794c94dce75f  vpmovqd xmm12, xmm13
0000794c94dce765  pxor xmm11, xmm11
0000794c94dce76a  punpcklqdq xmm12, xmm11
0000794c94dce76f  movaps [r15+0x210], xmm12
0000794c94dce777  movq xmm12, qword ptr [r15+0x120]
0000794c94dce780  movq xmm11, qword ptr [r15+0x130]
0000794c94dce789  psubd xmm12, xmm11
0000794c94dce78e  movq xmm12, xmm12
0000794c94dce793  paddq xmm13, xmm14
0000794c94dce798  movaps [r15+0x180], xmm13
0000794c94dce7a0  movq xmm14, qword ptr [r15+0x150]
0000794c94dce7a9  paddd xmm11, xmm14
0000794c94dce7ae  movq xmm11, xmm11
0000794c94dce7b3  movq xmm11, xmm11
0000794c94dce7b8  movaps [r15+0x130], xmm11
0000794c94dce7c0  pmovzxdq xmm12, xmm12
0000794c94dce7c6  psllq xmm12, 0x00
0000794c94dce7cc  movq xmm14, qword ptr [r15+0x210]
0000794c94dce7d5  movq xmm13, qword ptr [r15+0x110]
0000794c94dce7de  paddd xmm14, xmm13
0000794c94dce7e3  movq xmm14, xmm14
0000794c94dce7e8  vcvtuqq2pd xmm12, xmm12
0000794c94dce7ee  pmovzxdq xmm14, xmm14
0000794c94dce7f4  psllq xmm14, 0x00
0000794c94dce7fa  vcvtuqq2pd xmm14, xmm14
0000794c94dce800  movaps xmm13, xmm12
0000794c94dce804  mulpd xmm13, xmm1
0000794c94dce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000794c94dce80f  ptest xmm11, xmm11
0000794c94dce815  jnz 0x0000794C94DCE8FF
0000794c94dce81b  movaps [r15+0x220], xmm13
0000794c94dce823  mov eax, 0x430720
0000794c94dce828  movups [r13+rax*1], xmm13
0000794c94dce82e  movaps xmm1, xmm14
0000794c94dce832  mulpd xmm1, xmm15
0000794c94dce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000794c94dce83c  ptest xmm13, xmm13
0000794c94dce842  jnz 0x0000794C94DCEA4C
0000794c94dce848  movaps [r15+0x210], xmm1
0000794c94dce850  mov eax, 0x430518
0000794c94dce855  movups [r13+rax*1], xmm1
0000794c94dce85b  mov qword ptr [r15+0x48], 0x10
0000794c94dce863  xor eax, eax
0000794c94dce865  mov r14d, 0x10
0000794c94dce86b  mov r12d, 0x200
0000794c94dce871  cmp r14, r12
0000794c94dce874  cmc
0000794c94dce875  lahf
0000794c94dce876  seto al
0000794c94dce879  mov [r15+0x108], eax
0000794c94dce880  mov eax, [r15+0x108]
0000794c94dce887  sahf
0000794c94dce888  jnz 0x0000794C94DCE8BA
0000794c94dce88a  cmp dword ptr [r15+0x318], 0x00
0000794c94dce892  jz 0x0000794C94DCEFF0
0000794c94dce898  nop [rax+rax*1], ax
0000794c94dce8a1  nop [rax+rax*1], eax
0000794c94dce8a9  mov eax, 0x4101EC
0000794c94dce8ae  mov [r15+0x100], rax
0000794c94dce8b5  jmp 0x0000794C94BFE110
0000794c94dce8ba  cmp dword ptr [r15+0x318], 0x00
0000794c94dce8c2  jz 0x0000794C94DCEBA0
0000794c94dce8c8  nop [rax+rax*1], ax
0000794c94dce8d1  nop [rax+rax*1], eax
0000794c94dce8d9  mov eax, 0x4101AC
0000794c94dce8de  mov [r15+0x100], rax
0000794c94dce8e5  jmp 0x0000794C94BFE110
0000794c94dce8ea  int3
0000794c94dce8eb  call 0x0000794C94C0DC20
0000794c94dce8f0  jmp 0x0000794C94DCE6D2
0000794c94dce8f5  call 0x0000794C94C0C260
0000794c94dce8fa  jmp 0x0000794C94DCE74F
0000794c94dce8ff  sub rsp, 0x08
0000794c94dce903  push rax
0000794c94dce904  push rcx
0000794c94dce905  push rdx
0000794c94dce906  push rdi
0000794c94dce907  push rsi
0000794c94dce908  push r8
0000794c94dce90a  push r9
0000794c94dce90c  push r10
0000794c94dce90e  push r11
0000794c94dce910  sub rsp, 0xF0
0000794c94dce917  vmovaps [rsp], xmm0
0000794c94dce91c  vmovaps [rsp+0x10], xmm1
0000794c94dce922  vmovaps [rsp+0x20], xmm2
0000794c94dce928  vmovaps [rsp+0x30], xmm3
0000794c94dce92e  vmovaps [rsp+0x40], xmm4
0000794c94dce934  vmovaps [rsp+0x50], xmm5
0000794c94dce93a  vmovaps [rsp+0x60], xmm6
0000794c94dce940  vmovaps [rsp+0x70], xmm7
0000794c94dce946  vmovaps [rsp+0x80], xmm8
0000794c94dce94f  vmovaps [rsp+0x90], xmm9
0000794c94dce958  vmovaps [rsp+0xA0], xmm10
0000794c94dce961  vmovaps [rsp+0xB0], xmm11
0000794c94dce96a  vmovaps [rsp+0xC0], xmm12
0000794c94dce973  vmovaps [rsp+0xD0], xmm14
0000794c94dce97c  vmovaps [rsp+0xE0], xmm15
0000794c94dce985  sub rsp, 0x30
0000794c94dce989  movaps [rsp], xmm13
0000794c94dce98e  movaps [rsp+0x10], xmm12
0000794c94dce994  movaps [rsp+0x20], xmm1
0000794c94dce999  lea rdi, [rsp]
0000794c94dce99d  mov esi, 0x00
0000794c94dce9a2  mov rax, 0x5AB2B8B81530
0000794c94dce9ac  call rax
0000794c94dce9ae  movaps xmm13, [rsp]
0000794c94dce9b3  add rsp, 0x30
0000794c94dce9b7  vmovaps xmm0, [rsp]
0000794c94dce9bc  vmovaps xmm1, [rsp+0x10]
0000794c94dce9c2  vmovaps xmm2, [rsp+0x20]
0000794c94dce9c8  vmovaps xmm3, [rsp+0x30]
0000794c94dce9ce  vmovaps xmm4, [rsp+0x40]
0000794c94dce9d4  vmovaps xmm5, [rsp+0x50]
0000794c94dce9da  vmovaps xmm6, [rsp+0x60]
0000794c94dce9e0  vmovaps xmm7, [rsp+0x70]
0000794c94dce9e6  vmovaps xmm8, [rsp+0x80]
0000794c94dce9ef  vmovaps xmm9, [rsp+0x90]
0000794c94dce9f8  vmovaps xmm10, [rsp+0xA0]
0000794c94dcea01  vmovaps xmm11, [rsp+0xB0]
0000794c94dcea0a  vmovaps xmm12, [rsp+0xC0]
0000794c94dcea13  vmovaps xmm14, [rsp+0xD0]
0000794c94dcea1c  vmovaps xmm15, [rsp+0xE0]
0000794c94dcea25  add rsp, 0xF0
0000794c94dcea2c  pop r11
0000794c94dcea2e  pop r10
0000794c94dcea30  pop r9
0000794c94dcea32  pop r8
0000794c94dcea34  pop rsi
0000794c94dcea35  pop rdi
0000794c94dcea36  pop rdx
0000794c94dcea37  pop rcx
0000794c94dcea38  pop rax
0000794c94dcea39  add rsp, 0x08
0000794c94dcea3d  jmp 0x0000794C94DCE81B
0000794c94dcea42  call 0x0000794C94C0C380
0000794c94dcea47  jmp 0x0000794C94DCE82E
0000794c94dcea4c  sub rsp, 0x08
0000794c94dcea50  push rax
0000794c94dcea51  push rcx
0000794c94dcea52  push rdx
0000794c94dcea53  push rdi
0000794c94dcea54  push rsi
0000794c94dcea55  push r8
0000794c94dcea57  push r9
0000794c94dcea59  push r10
0000794c94dcea5b  push r11
0000794c94dcea5d  sub rsp, 0xF0
0000794c94dcea64  vmovaps [rsp], xmm0
0000794c94dcea69  vmovaps [rsp+0x10], xmm2
0000794c94dcea6f  vmovaps [rsp+0x20], xmm3
0000794c94dcea75  vmovaps [rsp+0x30], xmm4
0000794c94dcea7b  vmovaps [rsp+0x40], xmm5
0000794c94dcea81  vmovaps [rsp+0x50], xmm6
0000794c94dcea87  vmovaps [rsp+0x60], xmm7
0000794c94dcea8d  vmovaps [rsp+0x70], xmm8
0000794c94dcea93  vmovaps [rsp+0x80], xmm9
0000794c94dcea9c  vmovaps [rsp+0x90], xmm10
0000794c94dceaa5  vmovaps [rsp+0xA0], xmm11
0000794c94dceaae  vmovaps [rsp+0xB0], xmm12
0000794c94dceab7  vmovaps [rsp+0xC0], xmm13
0000794c94dceac0  vmovaps [rsp+0xD0], xmm14
0000794c94dceac9  vmovaps [rsp+0xE0], xmm15
0000794c94dcead2  sub rsp, 0x30
0000794c94dcead6  movaps [rsp], xmm1
0000794c94dceada  movaps [rsp+0x10], xmm14
0000794c94dceae0  movaps [rsp+0x20], xmm15
0000794c94dceae6  lea rdi, [rsp]
0000794c94dceaea  mov esi, 0x00
0000794c94dceaef  mov rax, 0x5AB2B8B81530
0000794c94dceaf9  call rax
0000794c94dceafb  movaps xmm1, [rsp]
0000794c94dceaff  add rsp, 0x30
0000794c94dceb03  vmovaps xmm0, [rsp]
0000794c94dceb08  vmovaps xmm2, [rsp+0x10]
0000794c94dceb0e  vmovaps xmm3, [rsp+0x20]
0000794c94dceb14  vmovaps xmm4, [rsp+0x30]
0000794c94dceb1a  vmovaps xmm5, [rsp+0x40]
0000794c94dceb20  vmovaps xmm6, [rsp+0x50]
0000794c94dceb26  vmovaps xmm7, [rsp+0x60]
0000794c94dceb2c  vmovaps xmm8, [rsp+0x70]
0000794c94dceb32  vmovaps xmm9, [rsp+0x80]
0000794c94dceb3b  vmovaps xmm10, [rsp+0x90]
0000794c94dceb44  vmovaps xmm11, [rsp+0xA0]
0000794c94dceb4d  vmovaps xmm12, [rsp+0xB0]
0000794c94dceb56  vmovaps xmm13, [rsp+0xC0]
0000794c94dceb5f  vmovaps xmm14, [rsp+0xD0]
0000794c94dceb68  vmovaps xmm15, [rsp+0xE0]
0000794c94dceb71  add rsp, 0xF0
0000794c94dceb78  pop r11
0000794c94dceb7a  pop r10
0000794c94dceb7c  pop r9
0000794c94dceb7e  pop r8
0000794c94dceb80  pop rsi
0000794c94dceb81  pop rdi
0000794c94dceb82  pop rdx
0000794c94dceb83  pop rcx
0000794c94dceb84  pop rax
0000794c94dceb85  add rsp, 0x08
0000794c94dceb89  jmp 0x0000794C94DCE848
0000794c94dceb8e  call 0x0000794C94BFF540
0000794c94dceb93  jmp 0x0000794C94DCE85B
0000794c94dceb98  int3
0000794c94dceb99  nop [rax], eax
0000794c94dceba0  movaps xmm1, [r15+0x180]
0000794c94dceba8  vpmovqd xmm15, xmm1
0000794c94dcebae  pxor xmm14, xmm14
0000794c94dcebb3  punpcklqdq xmm15, xmm14
0000794c94dcebb8  movaps [r15+0x210], xmm15
0000794c94dcebc0  movq xmm15, qword ptr [r15+0x120]
0000794c94dcebc9  movq xmm14, qword ptr [r15+0x130]
0000794c94dcebd2  psubd xmm15, xmm14
0000794c94dcebd7  movq xmm15, xmm15
0000794c94dcebdc  movaps xmm13, [r15+0x170]
0000794c94dcebe4  paddq xmm1, xmm13
0000794c94dcebe9  movaps [r15+0x180], xmm1
0000794c94dcebf1  movq xmm1, qword ptr [r15+0x150]
0000794c94dcebfa  paddd xmm14, xmm1
0000794c94dcebff  movq xmm14, xmm14
0000794c94dcec04  movq xmm14, xmm14
0000794c94dcec09  movaps [r15+0x130], xmm14
0000794c94dcec11  pmovzxdq xmm15, xmm15
0000794c94dcec17  psllq xmm15, 0x00
0000794c94dcec1d  movq xmm1, qword ptr [r15+0x210]
0000794c94dcec26  movq xmm14, qword ptr [r15+0x110]
0000794c94dcec2f  paddd xmm1, xmm14
0000794c94dcec34  movq xmm1, xmm1
0000794c94dcec38  vcvtuqq2pd xmm15, xmm15
0000794c94dcec3e  pmovzxdq xmm1, xmm1
0000794c94dcec43  psllq xmm1, 0x00
0000794c94dcec48  vcvtuqq2pd xmm1, xmm1
0000794c94dcec4e  movaps xmm14, [r15+0x140]
0000794c94dcec56  movaps xmm13, xmm15
0000794c94dcec5a  mulpd xmm13, xmm14
0000794c94dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000794c94dcec65  ptest xmm12, xmm12
0000794c94dcec6b  jnz 0x0000794C94DCED4E
0000794c94dcec71  movaps [r15+0x220], xmm13
0000794c94dcec79  mov rax, [r15+0x48]
0000794c94dcec7d  mov r14, [r15+0x50]
0000794c94dcec81  lea r12, [r14+rax*1]
0000794c94dcec85  movups [r13+r12*1], xmm13
0000794c94dcec8b  movaps xmm15, [r15+0x160]
0000794c94dcec93  movaps xmm14, xmm1
0000794c94dcec97  mulpd xmm14, xmm15
0000794c94dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000794c94dceca2  ptest xmm13, xmm13
0000794c94dceca8  jnz 0x0000794C94DCEE9C
0000794c94dcecae  movaps [r15+0x210], xmm14
0000794c94dcecb6  mov r14, [r15+0x40]
0000794c94dcecba  lea r12, [r14+rax*1]
0000794c94dcecbe  movups [r13+r12*1], xmm14
0000794c94dcecc4  lea r14, [rax+0x10]
0000794c94dcecc8  mov [r15+0x48], r14
0000794c94dceccc  xor eax, eax
0000794c94dcecce  mov r12d, 0x200
0000794c94dcecd4  cmp r14, r12
0000794c94dcecd7  cmc
0000794c94dcecd8  lahf
0000794c94dcecd9  seto al
0000794c94dcecdc  mov [r15+0x108], eax
0000794c94dcece3  mov eax, [r15+0x108]
0000794c94dcecea  sahf
0000794c94dceceb  jnz 0x0000794C94DCED1D
0000794c94dceced  cmp dword ptr [r15+0x318], 0x00
0000794c94dcecf5  jz 0x0000794C94DCEFF0
0000794c94dcecfb  nop [rax+rax*1], ax
0000794c94dced04  nop [rax+rax*1], eax
0000794c94dced0c  mov eax, 0x4101EC
0000794c94dced11  mov [r15+0x100], rax
0000794c94dced18  jmp 0x0000794C94BFE110
0000794c94dced1d  cmp dword ptr [r15+0x318], 0x00
0000794c94dced25  jz 0x0000794C94DCEBA0
0000794c94dced2b  nop [rax+rax*1], ax
0000794c94dced34  nop [rax+rax*1], eax
0000794c94dced3c  mov eax, 0x4101AC
0000794c94dced41  mov [r15+0x100], rax
0000794c94dced48  jmp 0x0000794C94BFE110
0000794c94dced4d  int3
0000794c94dced4e  sub rsp, 0x08
0000794c94dced52  push rax
0000794c94dced53  push rcx
0000794c94dced54  push rdx
0000794c94dced55  push rdi
0000794c94dced56  push rsi
0000794c94dced57  push r8
0000794c94dced59  push r9
0000794c94dced5b  push r10
0000794c94dced5d  push r11
0000794c94dced5f  sub rsp, 0xF0
0000794c94dced66  vmovaps [rsp], xmm0
0000794c94dced6b  vmovaps [rsp+0x10], xmm1
0000794c94dced71  vmovaps [rsp+0x20], xmm2
0000794c94dced77  vmovaps [rsp+0x30], xmm3
0000794c94dced7d  vmovaps [rsp+0x40], xmm4
0000794c94dced83  vmovaps [rsp+0x50], xmm5
0000794c94dced89  vmovaps [rsp+0x60], xmm6
0000794c94dced8f  vmovaps [rsp+0x70], xmm7
0000794c94dced95  vmovaps [rsp+0x80], xmm8
0000794c94dced9e  vmovaps [rsp+0x90], xmm9
0000794c94dceda7  vmovaps [rsp+0xA0], xmm10
0000794c94dcedb0  vmovaps [rsp+0xB0], xmm11
0000794c94dcedb9  vmovaps [rsp+0xC0], xmm12
0000794c94dcedc2  vmovaps [rsp+0xD0], xmm14
0000794c94dcedcb  vmovaps [rsp+0xE0], xmm15
0000794c94dcedd4  sub rsp, 0x30
0000794c94dcedd8  movaps [rsp], xmm13
0000794c94dceddd  movaps [rsp+0x10], xmm15
0000794c94dcede3  movaps [rsp+0x20], xmm14
0000794c94dcede9  lea rdi, [rsp]
0000794c94dceded  mov esi, 0x00
0000794c94dcedf2  mov rax, 0x5AB2B8B81530
0000794c94dcedfc  call rax
0000794c94dcedfe  movaps xmm13, [rsp]
0000794c94dcee03  add rsp, 0x30
0000794c94dcee07  vmovaps xmm0, [rsp]
0000794c94dcee0c  vmovaps xmm1, [rsp+0x10]
0000794c94dcee12  vmovaps xmm2, [rsp+0x20]
0000794c94dcee18  vmovaps xmm3, [rsp+0x30]
0000794c94dcee1e  vmovaps xmm4, [rsp+0x40]
0000794c94dcee24  vmovaps xmm5, [rsp+0x50]
0000794c94dcee2a  vmovaps xmm6, [rsp+0x60]
0000794c94dcee30  vmovaps xmm7, [rsp+0x70]
0000794c94dcee36  vmovaps xmm8, [rsp+0x80]
0000794c94dcee3f  vmovaps xmm9, [rsp+0x90]
0000794c94dcee48  vmovaps xmm10, [rsp+0xA0]
0000794c94dcee51  vmovaps xmm11, [rsp+0xB0]
0000794c94dcee5a  vmovaps xmm12, [rsp+0xC0]
0000794c94dcee63  vmovaps xmm14, [rsp+0xD0]
0000794c94dcee6c  vmovaps xmm15, [rsp+0xE0]
0000794c94dcee75  add rsp, 0xF0
0000794c94dcee7c  pop r11
0000794c94dcee7e  pop r10
0000794c94dcee80  pop r9
0000794c94dcee82  pop r8
0000794c94dcee84  pop rsi
0000794c94dcee85  pop rdi
0000794c94dcee86  pop rdx
0000794c94dcee87  pop rcx
0000794c94dcee88  pop rax
0000794c94dcee89  add rsp, 0x08
0000794c94dcee8d  jmp 0x0000794C94DCEC71
0000794c94dcee92  call 0x0000794C94CC2240
0000794c94dcee97  jmp 0x0000794C94DCEC8B
0000794c94dcee9c  sub rsp, 0x08
0000794c94dceea0  push rax
0000794c94dceea1  push rcx
0000794c94dceea2  push rdx
0000794c94dceea3  push rdi
0000794c94dceea4  push rsi
0000794c94dceea5  push r8
0000794c94dceea7  push r9
0000794c94dceea9  push r10
0000794c94dceeab  push r11
0000794c94dceead  sub rsp, 0xF0
0000794c94dceeb4  vmovaps [rsp], xmm0
0000794c94dceeb9  vmovaps [rsp+0x10], xmm1
0000794c94dceebf  vmovaps [rsp+0x20], xmm2
0000794c94dceec5  vmovaps [rsp+0x30], xmm3
0000794c94dceecb  vmovaps [rsp+0x40], xmm4
0000794c94dceed1  vmovaps [rsp+0x50], xmm5
0000794c94dceed7  vmovaps [rsp+0x60], xmm6
0000794c94dceedd  vmovaps [rsp+0x70], xmm7
0000794c94dceee3  vmovaps [rsp+0x80], xmm8
0000794c94dceeec  vmovaps [rsp+0x90], xmm9
0000794c94dceef5  vmovaps [rsp+0xA0], xmm10
0000794c94dceefe  vmovaps [rsp+0xB0], xmm11
0000794c94dcef07  vmovaps [rsp+0xC0], xmm12
0000794c94dcef10  vmovaps [rsp+0xD0], xmm13
0000794c94dcef19  vmovaps [rsp+0xE0], xmm15
0000794c94dcef22  sub rsp, 0x30
0000794c94dcef26  movaps [rsp], xmm14
0000794c94dcef2b  movaps [rsp+0x10], xmm1
0000794c94dcef30  movaps [rsp+0x20], xmm15
0000794c94dcef36  lea rdi, [rsp]
0000794c94dcef3a  mov esi, 0x00
0000794c94dcef3f  mov rax, 0x5AB2B8B81530
0000794c94dcef49  call rax
0000794c94dcef4b  movaps xmm14, [rsp]
0000794c94dcef50  add rsp, 0x30
0000794c94dcef54  vmovaps xmm0, [rsp]
0000794c94dcef59  vmovaps xmm1, [rsp+0x10]
0000794c94dcef5f  vmovaps xmm2, [rsp+0x20]
0000794c94dcef65  vmovaps xmm3, [rsp+0x30]
0000794c94dcef6b  vmovaps xmm4, [rsp+0x40]
0000794c94dcef71  vmovaps xmm5, [rsp+0x50]
0000794c94dcef77  vmovaps xmm6, [rsp+0x60]
0000794c94dcef7d  vmovaps xmm7, [rsp+0x70]
0000794c94dcef83  vmovaps xmm8, [rsp+0x80]
0000794c94dcef8c  vmovaps xmm9, [rsp+0x90]
0000794c94dcef95  vmovaps xmm10, [rsp+0xA0]
0000794c94dcef9e  vmovaps xmm11, [rsp+0xB0]
0000794c94dcefa7  vmovaps xmm12, [rsp+0xC0]
0000794c94dcefb0  vmovaps xmm13, [rsp+0xD0]
0000794c94dcefb9  vmovaps xmm15, [rsp+0xE0]
0000794c94dcefc2  add rsp, 0xF0
0000794c94dcefc9  pop r11
0000794c94dcefcb  pop r10
0000794c94dcefcd  pop r9
0000794c94dcefcf  pop r8
0000794c94dcefd1  pop rsi
0000794c94dcefd2  pop rdi
0000794c94dcefd3  pop rdx
0000794c94dcefd4  pop rcx
0000794c94dcefd5  pop rax
0000794c94dcefd6  add rsp, 0x08
0000794c94dcefda  jmp 0x0000794C94DCECAE
0000794c94dcefdf  call 0x0000794C94CC34C0
0000794c94dcefe4  jmp 0x0000794C94DCECC4
0000794c94dcefe9  int3
0000794c94dcefea  nop [rax+rax*1], ax
0000794c94dceff0  mov rax, [r15+0xF8]
0000794c94dceff7  lea r14, [rax-0x150]
0000794c94dceffe  mov [r15+0xF8], r14
0000794c94dcf005  mov rax, [r15+0x50]
0000794c94dcf009  lea r12, [rax+0x80]
0000794c94dcf010  movups xmm1, [r13+r12*1]
0000794c94dcf016  lea r12, [rax+0x90]
0000794c94dcf01d  movups xmm15, [r13+r12*1]
0000794c94dcf023  mov qword ptr [r15+0x48], 0x00
0000794c94dcf02b  lea r12, [rax+0x40]
0000794c94dcf02f  movups xmm14, [r13+r12*1]
0000794c94dcf035  lea r12, [rax+0x50]
0000794c94dcf039  movups xmm13, [r13+r12*1]
0000794c94dcf03f  lea r12, [r14+0x120]
0000794c94dcf046  movq xmm12, qword ptr [r15+0x1C0]
0000794c94dcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000794c94dcf058  movq r11, xmm12
0000794c94dcf05d  movq r10, xmm11
0000794c94dcf062  mov [r13+r12*1], r11
0000794c94dcf067  lea r12, [r14+0x128]
0000794c94dcf06e  mov [r13+r12*1], r10
0000794c94dcf073  vxorps xmm12, xmm12, xmm12
0000794c94dcf078  vpbroadcastq xmm12, xmm12
0000794c94dcf07d  lea r12, [r14+0x100]
0000794c94dcf084  movq xmm11, qword ptr [r15+0x200]
0000794c94dcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000794c94dcf096  movq r11, xmm11
0000794c94dcf09b  movq r10, xmm10
0000794c94dcf0a0  mov [r13+r12*1], r11
0000794c94dcf0a5  lea r12, [r14+0x108]
0000794c94dcf0ac  mov [r13+r12*1], r10
0000794c94dcf0b1  lea r12, [r14+0xE0]
0000794c94dcf0b8  movups [r13+r12*1], xmm15
0000794c94dcf0be  lea r12, [r14+0xF0]
0000794c94dcf0c5  movups [r13+r12*1], xmm1
0000794c94dcf0cb  lea r12, [rax+0xC0]
0000794c94dcf0d2  movups xmm1, [r13+r12*1]
0000794c94dcf0d8  lea r12, [rax+0xD0]
0000794c94dcf0df  movups xmm15, [r13+r12*1]
0000794c94dcf0e5  lea r12, [r14+0x110]
0000794c94dcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000794c94dcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000794c94dcf0fe  movq r11, xmm11
0000794c94dcf103  movq r10, xmm10
0000794c94dcf108  mov [r13+r12*1], r11
0000794c94dcf10d  lea r12, [r14+0x118]
0000794c94dcf114  mov [r13+r12*1], r10
0000794c94dcf119  movups xmm11, [r13+rax*1]
0000794c94dcf11f  lea r12, [rax+0x10]
0000794c94dcf123  movups xmm10, [r13+r12*1]
0000794c94dcf129  lea r12, [r14+0x130]
0000794c94dcf130  movq xmm9, qword ptr [r15+0x1A0]
0000794c94dcf139  movq xmm8, qword ptr [r15+0x190]
0000794c94dcf142  movq r11, xmm9
0000794c94dcf147  movq r10, xmm8
0000794c94dcf14c  mov [r13+r12*1], r11
0000794c94dcf151  lea r12, [r14+0x138]
0000794c94dcf158  mov [r13+r12*1], r10
0000794c94dcf15d  lea r12, [rax+0x140]
0000794c94dcf164  movups xmm9, [r13+r12*1]
0000794c94dcf16a  lea r12, [rax+0x150]
0000794c94dcf171  movups xmm8, [r13+r12*1]
0000794c94dcf177  lea r12, [r14+0xC0]
0000794c94dcf17e  movups [r13+r12*1], xmm15
0000794c94dcf184  lea r12, [r14+0xD0]
0000794c94dcf18b  movups [r13+r12*1], xmm1
0000794c94dcf191  lea r12, [rax+0x100]
0000794c94dcf198  movups xmm1, [r13+r12*1]
0000794c94dcf19e  lea r12, [rax+0x110]
0000794c94dcf1a5  movups xmm15, [r13+r12*1]
0000794c94dcf1ab  lea r12, [r14+0x140]
0000794c94dcf1b2  mov r11, [r15+0xE8]
0000794c94dcf1b9  mov [r13+r12*1], r11
0000794c94dcf1be  lea r12, [rax+0x180]
0000794c94dcf1c5  movups xmm7, [r13+r12*1]
0000794c94dcf1cb  lea r12, [rax+0x190]
0000794c94dcf1d2  movups xmm6, [r13+r12*1]
0000794c94dcf1d8  lea r12, [rax+0x1C0]
0000794c94dcf1df  movups xmm5, [r13+r12*1]
0000794c94dcf1e5  lea r12, [rax+0x1D0]
0000794c94dcf1ec  movups xmm4, [r13+r12*1]
0000794c94dcf1f2  lea r12, [r14+0x20]
0000794c94dcf1f6  movups [r13+r12*1], xmm1
0000794c94dcf1fc  lea r12, [r14+0x30]
0000794c94dcf200  movups [r13+r12*1], xmm13
0000794c94dcf206  lea r12, [rax+0x60]
0000794c94dcf20a  movups xmm1, [r13+r12*1]
0000794c94dcf210  lea r12, [rax+0x70]
0000794c94dcf214  movups xmm13, [r13+r12*1]
0000794c94dcf21a  lea r12, [rax+0x20]
0000794c94dcf21e  movups xmm3, [r13+r12*1]
0000794c94dcf224  lea r12, [rax+0x30]
0000794c94dcf228  movups xmm2, [r13+r12*1]
0000794c94dcf22e  movaps [r15+0x1F0], xmm2
0000794c94dcf236  lea r12, [r14+0x60]
0000794c94dcf23a  movups [r13+r12*1], xmm11
0000794c94dcf240  lea r12, [r14+0x70]
0000794c94dcf244  movups [r13+r12*1], xmm5
0000794c94dcf24a  lea r12, [rax+0xE0]
0000794c94dcf251  movups xmm11, [r13+r12*1]
0000794c94dcf257  lea r12, [rax+0xF0]
0000794c94dcf25e  movups xmm5, [r13+r12*1]
0000794c94dcf264  lea r12, [r14+0xA0]
0000794c94dcf26b  movups [r13+r12*1], xmm13
0000794c94dcf271  lea r12, [r14+0xB0]
0000794c94dcf278  movups [r13+r12*1], xmm1
0000794c94dcf27e  lea r12, [rax+0xA0]
0000794c94dcf285  movups xmm1, [r13+r12*1]
0000794c94dcf28b  lea r12, [rax+0xB0]
0000794c94dcf292  movups xmm13, [r13+r12*1]
0000794c94dcf298  lea r12, [rax+0x120]
0000794c94dcf29f  vmovaps [rsp+0x10], xmm1
0000794c94dcf2a5  movups xmm1, [r13+r12*1]
0000794c94dcf2ab  lea r12, [rax+0x130]
0000794c94dcf2b2  vmovaps [rsp+0x20], xmm1
0000794c94dcf2b8  movups xmm1, [r13+r12*1]
0000794c94dcf2be  lea r12, [rax+0x160]
0000794c94dcf2c5  vmovaps [rsp+0x30], xmm1
0000794c94dcf2cb  movups xmm1, [r13+r12*1]
0000794c94dcf2d1  lea r12, [rax+0x170]
0000794c94dcf2d8  vmovaps [rsp+0x40], xmm1
0000794c94dcf2de  movups xmm1, [r13+r12*1]
0000794c94dcf2e4  movaps [r15+0x2B0], xmm1
0000794c94dcf2ec  lea r12, [r14+0x80]
0000794c94dcf2f3  movups [r13+r12*1], xmm13
0000794c94dcf2f9  lea r12, [r14+0x90]
0000794c94dcf300  vmovaps xmm13, [rsp+0x10]
0000794c94dcf306  movups [r13+r12*1], xmm13
0000794c94dcf30c  lea r12, [rax+0x1A0]
0000794c94dcf313  movups xmm13, [r13+r12*1]
0000794c94dcf319  lea r12, [rax+0x1B0]
0000794c94dcf320  vmovaps [rsp+0x10], xmm1
0000794c94dcf326  movups xmm1, [r13+r12*1]
0000794c94dcf32c  movaps [r15+0x290], xmm13
0000794c94dcf334  movaps [r15+0x1E0], xmm1
0000794c94dcf33c  lea r12, [rax+0x1E0]
0000794c94dcf343  vmovaps [rsp+0x50], xmm1
0000794c94dcf349  movups xmm1, [r13+r12*1]
0000794c94dcf34f  lea r12, [rax+0x1F0]
0000794c94dcf356  vmovaps [rsp+0x60], xmm1
0000794c94dcf35c  movups xmm1, [r13+r12*1]
0000794c94dcf362  mov qword ptr [r15+0x50], 0x430920
0000794c94dcf36a  lea rax, [r14+0x40]
0000794c94dcf36e  vmovaps [rsp+0x70], xmm1
0000794c94dcf374  vmovaps xmm1, [rsp+0x40]
0000794c94dcf37a  movups [r13+rax*1], xmm1
0000794c94dcf380  lea rax, [r14+0x50]
0000794c94dcf384  movups [r13+rax*1], xmm10
0000794c94dcf38a  vmovaps xmm1, [rsp+0x70]
0000794c94dcf390  movups [r13+r14*1], xmm1
0000794c94dcf396  lea rax, [r14+0x10]
0000794c94dcf39a  vmovaps xmm1, [rsp+0x60]
0000794c94dcf3a0  movups [r13+rax*1], xmm1
0000794c94dcf3a6  mov rax, [r15+0x40]
0000794c94dcf3aa  vmovaps [rsp+0x40], xmm3
0000794c94dcf3b0  vmovaps xmm1, [rsp+0x40]
0000794c94dcf3b6  por xmm3, xmm1
0000794c94dcf3ba  vmovaps [rsp+0x40], xmm6
0000794c94dcf3c0  vmovaps xmm10, [rsp+0x40]
0000794c94dcf3c6  por xmm6, xmm10
0000794c94dcf3cb  lea r12, [rax+0x30]
0000794c94dcf3cf  mov r11, [r13+r12*1]
0000794c94dcf3d4  lea r12, [rax+0x38]
0000794c94dcf3d8  mov r10, [r13+r12*1]
0000794c94dcf3dd  movq xmm10, r11
0000794c94dcf3e2  vmovaps [rsp+0x40], xmm1
0000794c94dcf3e8  movq xmm1, r10
0000794c94dcf3ed  movq xmm10, xmm10
0000794c94dcf3f2  vmovaps [rsp+0x60], xmm10
0000794c94dcf3f8  movq xmm10, xmm10
0000794c94dcf3fd  movaps [r15+0x130], xmm10
0000794c94dcf405  movq xmm1, xmm1
0000794c94dcf409  vmovaps [rsp+0x70], xmm1
0000794c94dcf40f  movq xmm1, xmm1
0000794c94dcf413  movaps [r15+0x280], xmm1
0000794c94dcf41b  vmovaps [rsp+0x80], xmm9
0000794c94dcf424  vmovaps xmm1, [rsp+0x80]
0000794c94dcf42d  por xmm9, xmm1
0000794c94dcf432  lea r12, [rax+0x20]
0000794c94dcf436  mov r11, [r13+r12*1]
0000794c94dcf43b  lea r12, [rax+0x28]
0000794c94dcf43f  mov r10, [r13+r12*1]
0000794c94dcf444  movq xmm1, r11
0000794c94dcf449  movq xmm10, r10
0000794c94dcf44e  movq xmm1, xmm1
0000794c94dcf452  vmovaps [rsp+0x80], xmm1
0000794c94dcf45b  movq xmm1, xmm1
0000794c94dcf45f  movaps [r15+0x150], xmm1
0000794c94dcf467  movq xmm10, xmm10
0000794c94dcf46c  vmovaps [rsp+0x90], xmm10
0000794c94dcf475  movq xmm10, xmm10
0000794c94dcf47a  movaps [r15+0x140], xmm10
0000794c94dcf482  lea r12, [rax+0x10]
0000794c94dcf486  mov r11, [r13+r12*1]
0000794c94dcf48b  lea r12, [rax+0x18]
0000794c94dcf48f  mov r10, [r13+r12*1]
0000794c94dcf494  movq xmm1, r11
0000794c94dcf499  movq xmm10, r10
0000794c94dcf49e  movq xmm1, xmm1
0000794c94dcf4a2  vmovaps [rsp+0xA0], xmm1
0000794c94dcf4ab  movq xmm1, xmm1
0000794c94dcf4af  movaps [r15+0x170], xmm1
0000794c94dcf4b7  movq xmm10, xmm10
0000794c94dcf4bc  vmovaps [rsp+0xB0], xmm10
0000794c94dcf4c5  movq xmm10, xmm10
0000794c94dcf4ca  movaps [r15+0x160], xmm10
0000794c94dcf4d2  mov r12, [r13+rax*1]
0000794c94dcf4d7  vmovq xmm1, r12
0000794c94dcf4dc  vpbroadcastq xmm1, xmm1
0000794c94dcf4e1  lea r12, [rax+0x08]
0000794c94dcf4e5  mov rax, [r13+r12*1]
0000794c94dcf4ea  movq xmm10, rax
0000794c94dcf4ef  movaps [r15+0x230], xmm10
0000794c94dcf4f7  lea rax, [r14+0x50]
0000794c94dcf4fb  movups xmm10, [r13+rax*1]
0000794c94dcf501  lea rax, [r14+0x60]
0000794c94dcf505  vmovaps [rsp+0xC0], xmm1
0000794c94dcf50e  movups xmm1, [r13+rax*1]
0000794c94dcf514  lea rax, [r14+0x30]
0000794c94dcf518  vmovaps [rsp+0xD0], xmm1
0000794c94dcf521  movups xmm1, [r13+rax*1]
0000794c94dcf527  mov qword ptr [r15+0x60], 0x430920
0000794c94dcf52f  mov qword ptr [r15+0x58], 0x40
0000794c94dcf537  vmovaps [rsp+0xE0], xmm1
0000794c94dcf540  vmovaps [rsp+0xF0], xmm15
0000794c94dcf549  vmovaps xmm15, [rsp+0xC0]
0000794c94dcf552  vmovaps [rsp+0xC0], xmm14
0000794c94dcf55b  vmovaps xmm14, [rsp+0x40]
0000794c94dcf561  vmovaps [rsp+0x40], xmm13
0000794c94dcf567  movaps xmm1, xmm15
0000794c94dcf56b  mulpd xmm1, xmm14
0000794c94dcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000794c94dcf575  ptest xmm13, xmm13
0000794c94dcf57b  jnz 0x0000794C94DD0682
0000794c94dcf581  movq xmm14, qword ptr [r15+0x230]
0000794c94dcf58a  vmovaps [rsp+0x100], xmm14
0000794c94dcf593  vpermilpd xmm14, xmm14, 0x00
0000794c94dcf599  vmovaps [rsp+0x110], xmm1
0000794c94dcf5a2  vmovaps xmm1, [rsp+0xE0]
0000794c94dcf5ab  vmovaps [rsp+0xE0], xmm15
0000794c94dcf5b4  movaps xmm13, xmm1
0000794c94dcf5b8  mulpd xmm13, xmm14
0000794c94dcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000794c94dcf5c3  ptest xmm15, xmm15
0000794c94dcf5c9  jnz 0x0000794C94DD07C4
0000794c94dcf5cf  vxorps xmm1, xmm1, xmm1
0000794c94dcf5d3  vpbroadcastq xmm1, xmm1
0000794c94dcf5d8  vmovaps xmm14, [rsp+0xE0]
0000794c94dcf5e1  vmovaps [rsp+0xE0], xmm1
0000794c94dcf5ea  vmovaps xmm1, [rsp+0xD0]
0000794c94dcf5f3  vmovaps [rsp+0xD0], xmm13
0000794c94dcf5fc  movaps xmm15, xmm14
0000794c94dcf600  mulpd xmm15, xmm1
0000794c94dcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000794c94dcf60b  ptest xmm13, xmm13
0000794c94dcf611  jnz 0x0000794C94DD0907
0000794c94dcf617  movaps xmm1, xmm14
0000794c94dcf61b  mulpd xmm1, xmm10
0000794c94dcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000794c94dcf625  ptest xmm13, xmm13
0000794c94dcf62b  jnz 0x0000794C94DD0A4A
0000794c94dcf631  movaps xmm13, xmm14
0000794c94dcf635  mulpd xmm13, xmm2
0000794c94dcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000794c94dcf640  ptest xmm10, xmm10
0000794c94dcf646  jnz 0x0000794C94DD0B8C
0000794c94dcf64c  vmovaps [rsp+0x120], xmm7
0000794c94dcf655  vmovaps xmm14, [rsp+0x120]
0000794c94dcf65e  por xmm7, xmm14
0000794c94dcf663  vmovaps xmm14, [rsp+0xC0]
0000794c94dcf66c  vmovaps xmm10, [rsp+0xC0]
0000794c94dcf675  por xmm14, xmm10
0000794c94dcf67a  vmovaps xmm2, [rsp+0x100]
0000794c94dcf683  vpermilpd xmm2, xmm2, 0x00
0000794c94dcf689  vmovaps [rsp+0xC0], xmm1
0000794c94dcf692  vmovaps [rsp+0x120], xmm15
0000794c94dcf69b  movaps xmm1, xmm10
0000794c94dcf69f  mulpd xmm1, xmm2
0000794c94dcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000794c94dcf6a8  ptest xmm15, xmm15
0000794c94dcf6ae  jnz 0x0000794C94DD0CCF
0000794c94dcf6b4  xor eax, eax
0000794c94dcf6b6  mov r12d, 0x40
0000794c94dcf6bc  mov r11d, 0x200
0000794c94dcf6c2  cmp r12, r11
0000794c94dcf6c5  cmc
0000794c94dcf6c6  lahf
0000794c94dcf6c7  seto al
0000794c94dcf6ca  mov [r15+0x108], eax
0000794c94dcf6d1  vmovaps xmm10, [rsp+0x110]
0000794c94dcf6da  vmovaps xmm2, [rsp+0xE0]
0000794c94dcf6e3  vmovaps [rsp+0xE0], xmm1
0000794c94dcf6ec  movaps xmm15, xmm10
0000794c94dcf6f0  addpd xmm15, xmm2
0000794c94dcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000794c94dcf6fb  ptest xmm1, xmm1
0000794c94dcf700  jnz 0x0000794C94DD0E10
0000794c94dcf706  vmovaps xmm10, [rsp+0x120]
0000794c94dcf70f  vmovaps [rsp+0x110], xmm15
0000794c94dcf718  movaps xmm1, xmm10
0000794c94dcf71c  addpd xmm1, xmm12
0000794c94dcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000794c94dcf726  ptest xmm15, xmm15
0000794c94dcf72c  jnz 0x0000794C94DD0F53
0000794c94dcf732  vmovaps xmm10, [rsp+0xC0]
0000794c94dcf73b  vmovaps [rsp+0xC0], xmm1
0000794c94dcf744  movaps xmm15, xmm10
0000794c94dcf748  addpd xmm15, xmm12
0000794c94dcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000794c94dcf753  ptest xmm1, xmm1
0000794c94dcf758  jnz 0x0000794C94DD1095
0000794c94dcf75e  vmovaps xmm1, [rsp+0x30]
0000794c94dcf764  vmovaps xmm12, [rsp+0x30]
0000794c94dcf76a  por xmm1, xmm12
0000794c94dcf76f  vmovaps xmm12, [rsp+0x20]
0000794c94dcf775  vmovaps xmm10, [rsp+0x20]
0000794c94dcf77b  por xmm12, xmm10
0000794c94dcf780  vmovaps [rsp+0x20], xmm5
0000794c94dcf786  vmovaps xmm10, [rsp+0x20]
0000794c94dcf78c  por xmm5, xmm10
0000794c94dcf791  vmovaps [rsp+0x20], xmm11
0000794c94dcf797  vmovaps xmm10, [rsp+0x20]
0000794c94dcf79d  por xmm11, xmm10
0000794c94dcf7a2  vmovaps [rsp+0x20], xmm4
0000794c94dcf7a8  vmovaps xmm10, [rsp+0x20]
0000794c94dcf7ae  por xmm4, xmm10
0000794c94dcf7b3  vmovaps [rsp+0x20], xmm8
0000794c94dcf7b9  vmovaps xmm10, [rsp+0x20]
0000794c94dcf7bf  por xmm8, xmm10
0000794c94dcf7c4  vmovaps xmm10, [rsp+0xF0]
0000794c94dcf7cd  vmovaps [rsp+0x20], xmm1
0000794c94dcf7d3  vmovaps xmm1, [rsp+0xF0]
0000794c94dcf7dc  por xmm10, xmm1
0000794c94dcf7e1  lea rax, [r14+0xA0]
0000794c94dcf7e8  movups xmm1, [r13+rax*1]
0000794c94dcf7ee  lea rax, [r14+0xB0]
0000794c94dcf7f5  vmovaps [rsp+0x30], xmm1
0000794c94dcf7fb  movups xmm1, [r13+rax*1]
0000794c94dcf801  vmovaps [rsp+0xF0], xmm1
0000794c94dcf80a  vmovaps [rsp+0x120], xmm15
0000794c94dcf813  movaps xmm1, xmm13
0000794c94dcf817  addpd xmm1, xmm2
0000794c94dcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000794c94dcf820  ptest xmm15, xmm15
0000794c94dcf826  jnz 0x0000794C94DD11ED
0000794c94dcf82c  lea rax, [r14+0xF0]
0000794c94dcf833  movups xmm15, [r13+rax*1]
0000794c94dcf839  vmovaps xmm2, [rsp+0xC0]
0000794c94dcf842  vmovaps [rsp+0xC0], xmm1
0000794c94dcf84b  vmovaps xmm1, [rsp+0xE0]
0000794c94dcf854  vmovaps [rsp+0xE0], xmm15
0000794c94dcf85d  movaps xmm13, xmm2
0000794c94dcf861  addpd xmm13, xmm1
0000794c94dcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000794c94dcf86c  ptest xmm15, xmm15
0000794c94dcf872  jnz 0x0000794C94DD1338
0000794c94dcf878  vmovaps xmm15, [rsp+0x120]
0000794c94dcf881  vmovaps xmm2, [rsp+0xD0]
0000794c94dcf88a  vmovaps [rsp+0xD0], xmm14
0000794c94dcf893  movaps xmm1, xmm15
0000794c94dcf897  addpd xmm1, xmm2
0000794c94dcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000794c94dcf8a0  ptest xmm14, xmm14
0000794c94dcf8a6  jnz 0x0000794C94DD147A
0000794c94dcf8ac  vmovaps xmm15, [rsp+0x100]
0000794c94dcf8b5  vpermilpd xmm15, xmm15, 0x00
0000794c94dcf8bb  vmovaps xmm2, [rsp+0xF0]
0000794c94dcf8c4  vmovaps [rsp+0xF0], xmm1
0000794c94dcf8cd  movaps xmm14, xmm2
0000794c94dcf8d1  mulpd xmm14, xmm15
0000794c94dcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000794c94dcf8dc  ptest xmm1, xmm1
0000794c94dcf8e1  jnz 0x0000794C94DD15BB
0000794c94dcf8e7  vmovaps xmm1, [rsp+0xA0]
0000794c94dcf8f0  vpermilpd xmm1, xmm1, 0x00
0000794c94dcf8f6  vmovaps xmm2, [rsp+0xE0]
0000794c94dcf8ff  vmovaps [rsp+0xE0], xmm14
0000794c94dcf908  movaps xmm15, xmm2
0000794c94dcf90c  mulpd xmm15, xmm1
0000794c94dcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000794c94dcf917  ptest xmm14, xmm14
0000794c94dcf91d  jnz 0x0000794C94DD16FE
0000794c94dcf923  lea rax, [r14+0xE0]
0000794c94dcf92a  movups xmm1, [r13+rax*1]
0000794c94dcf930  vmovaps xmm14, [rsp+0x100]
0000794c94dcf939  vpermilpd xmm14, xmm14, 0x00
0000794c94dcf93f  vmovaps [rsp+0x100], xmm1
0000794c94dcf948  vmovaps xmm1, [rsp+0x30]
0000794c94dcf94e  vmovaps [rsp+0x30], xmm15
0000794c94dcf954  movaps xmm2, xmm1
0000794c94dcf957  mulpd xmm2, xmm14
0000794c94dcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000794c94dcf961  ptest xmm15, xmm15
0000794c94dcf967  jnz 0x0000794C94DD184A
0000794c94dcf96d  vmovaps [rsp+0x120], xmm10
0000794c94dcf976  vmovaps xmm1, [rsp+0x120]
0000794c94dcf97f  por xmm10, xmm1
0000794c94dcf984  movaps [r15+0x300], xmm10
0000794c94dcf98c  vmovaps [rsp+0x120], xmm8
0000794c94dcf995  vmovaps xmm1, [rsp+0x120]
0000794c94dcf99e  por xmm8, xmm1
0000794c94dcf9a3  movaps [r15+0x190], xmm8
0000794c94dcf9ab  vmovaps xmm1, [rsp+0xA0]
0000794c94dcf9b4  vpermilpd xmm1, xmm1, 0x00
0000794c94dcf9ba  vmovaps xmm14, [rsp+0x100]
0000794c94dcf9c3  vmovaps [rsp+0x100], xmm13
0000794c94dcf9cc  movaps xmm15, xmm14
0000794c94dcf9d0  mulpd xmm15, xmm1
0000794c94dcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000794c94dcf9db  ptest xmm13, xmm13
0000794c94dcf9e1  jnz 0x0000794C94DD198B
0000794c94dcf9e7  lea rax, [r14+0x90]
0000794c94dcf9ee  movups xmm1, [r13+rax*1]
0000794c94dcf9f4  vmovaps [rsp+0x120], xmm4
0000794c94dcf9fd  vmovaps xmm14, [rsp+0x120]
0000794c94dcfa06  por xmm4, xmm14
0000794c94dcfa0b  movaps [r15+0x1C0], xmm4
0000794c94dcfa13  vmovaps [rsp+0x120], xmm11
0000794c94dcfa1c  vmovaps xmm14, [rsp+0x120]
0000794c94dcfa25  por xmm11, xmm14
0000794c94dcfa2a  movaps [r15+0x200], xmm11
0000794c94dcfa32  vmovaps [rsp+0x120], xmm5
0000794c94dcfa3b  vmovaps xmm14, [rsp+0x120]
0000794c94dcfa44  por xmm5, xmm14
0000794c94dcfa49  movaps [r15+0x2D0], xmm5
0000794c94dcfa51  vmovaps [rsp+0x120], xmm12
0000794c94dcfa5a  vmovaps xmm14, [rsp+0x120]
0000794c94dcfa63  por xmm12, xmm14
0000794c94dcfa68  movaps [r15+0x2E0], xmm12
0000794c94dcfa70  vmovaps xmm13, [rsp+0x110]
0000794c94dcfa79  vmovaps [rsp+0x110], xmm1
0000794c94dcfa82  vmovaps xmm1, [rsp+0xE0]
0000794c94dcfa8b  vmovaps [rsp+0xE0], xmm15
0000794c94dcfa94  movaps xmm14, xmm13
0000794c94dcfa98  addpd xmm14, xmm1
0000794c94dcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000794c94dcfaa3  ptest xmm15, xmm15
0000794c94dcfaa9  jnz 0x0000794C94DD1AD8
0000794c94dcfaaf  vmovaps xmm1, [rsp+0xA0]
0000794c94dcfab8  vpermilpd xmm1, xmm1, 0x00
0000794c94dcfabe  vmovaps xmm13, [rsp+0x110]
0000794c94dcfac7  vmovaps [rsp+0x110], xmm14
0000794c94dcfad0  movaps xmm15, xmm13
0000794c94dcfad4  mulpd xmm15, xmm1
0000794c94dcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000794c94dcfadf  ptest xmm14, xmm14
0000794c94dcfae5  jnz 0x0000794C94DD1C1B
0000794c94dcfaeb  lea rax, [r14+0x80]
0000794c94dcfaf2  movups xmm1, [r13+rax*1]
0000794c94dcfaf8  vmovaps xmm13, [rsp+0xC0]
0000794c94dcfb01  vmovaps [rsp+0xC0], xmm1
0000794c94dcfb0a  movaps xmm14, xmm13
0000794c94dcfb0e  addpd xmm14, xmm2
0000794c94dcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000794c94dcfb19  ptest xmm1, xmm1
0000794c94dcfb1e  jnz 0x0000794C94DD1D68
0000794c94dcfb24  vmovaps xmm13, [rsp+0x100]
0000794c94dcfb2d  vmovaps xmm2, [rsp+0x30]
0000794c94dcfb33  vmovaps [rsp+0x30], xmm15
0000794c94dcfb39  movaps xmm1, xmm13
0000794c94dcfb3d  addpd xmm1, xmm2
0000794c94dcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000794c94dcfb46  ptest xmm15, xmm15
0000794c94dcfb4c  jnz 0x0000794C94DD1EAB
0000794c94dcfb52  vmovaps xmm15, [rsp+0x20]
0000794c94dcfb58  vmovaps xmm13, [rsp+0x20]
0000794c94dcfb5e  por xmm15, xmm13
0000794c94dcfb63  movaps [r15+0x2F0], xmm15
0000794c94dcfb6b  vmovaps xmm13, [rsp+0xA0]
0000794c94dcfb74  vpermilpd xmm13, xmm13, 0x00
0000794c94dcfb7a  vmovaps [rsp+0x20], xmm1
0000794c94dcfb80  vmovaps xmm1, [rsp+0xC0]
0000794c94dcfb89  vmovaps [rsp+0xA0], xmm15
0000794c94dcfb92  movaps xmm2, xmm1
0000794c94dcfb95  mulpd xmm2, xmm13
0000794c94dcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000794c94dcfb9f  ptest xmm15, xmm15
0000794c94dcfba5  jnz 0x0000794C94DD1FEC
0000794c94dcfbab  lea rax, [r14+0xD0]
0000794c94dcfbb2  movups xmm1, [r13+rax*1]
0000794c94dcfbb8  vmovaps xmm13, [rsp+0xF0]
0000794c94dcfbc1  vmovaps [rsp+0xC0], xmm1
0000794c94dcfbca  vmovaps xmm1, [rsp+0xE0]
0000794c94dcfbd3  vmovaps [rsp+0xE0], xmm14
0000794c94dcfbdc  movaps xmm15, xmm13
0000794c94dcfbe0  addpd xmm15, xmm1
0000794c94dcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000794c94dcfbeb  ptest xmm14, xmm14
0000794c94dcfbf1  jnz 0x0000794C94DD2137
0000794c94dcfbf7  vmovaps xmm1, [rsp+0xB0]
0000794c94dcfc00  vpermilpd xmm1, xmm1, 0x00
0000794c94dcfc06  movaps xmm14, xmm11
0000794c94dcfc0a  mulpd xmm14, xmm1
0000794c94dcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000794c94dcfc15  ptest xmm13, xmm13
0000794c94dcfc1b  jnz 0x0000794C94DD227A
0000794c94dcfc21  movaps [r15+0x260], xmm14
0000794c94dcfc29  vxorps xmm1, xmm1, xmm1
0000794c94dcfc2d  vpbroadcastq xmm1, xmm1
0000794c94dcfc32  movaps [r15+0x1B0], xmm1
0000794c94dcfc3a  vmovaps xmm1, [rsp+0xB0]
0000794c94dcfc43  vpermilpd xmm1, xmm1, 0x00
0000794c94dcfc49  vmovaps xmm11, [rsp+0xC0]
0000794c94dcfc52  vmovaps [rsp+0xC0], xmm15
0000794c94dcfc5b  movaps xmm13, xmm11
0000794c94dcfc5f  mulpd xmm13, xmm1
0000794c94dcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000794c94dcfc6a  ptest xmm15, xmm15
0000794c94dcfc70  jnz 0x0000794C94DD23BD
0000794c94dcfc76  lea rax, [r14+0xC0]
0000794c94dcfc7d  movups xmm1, [r13+rax*1]
0000794c94dcfc83  vmovaps xmm11, [rsp+0x110]
0000794c94dcfc8c  vmovaps [rsp+0xF0], xmm1
0000794c94dcfc95  vmovaps xmm1, [rsp+0x30]
0000794c94dcfc9b  vmovaps [rsp+0x30], xmm14
0000794c94dcfca1  movaps xmm15, xmm11
0000794c94dcfca5  addpd xmm15, xmm1
0000794c94dcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000794c94dcfcb0  ptest xmm14, xmm14
0000794c94dcfcb6  jnz 0x0000794C94DD250A
0000794c94dcfcbc  vmovaps [rsp+0x100], xmm9
0000794c94dcfcc5  vmovaps xmm1, [rsp+0x100]
0000794c94dcfcce  por xmm9, xmm1
0000794c94dcfcd3  movaps [r15+0x270], xmm9
0000794c94dcfcdb  vmovaps [rsp+0x100], xmm6
0000794c94dcfce4  vmovaps xmm1, [rsp+0x100]
0000794c94dcfced  por xmm6, xmm1
0000794c94dcfcf1  movaps [r15+0x1A0], xmm6
0000794c94dcfcf9  vmovaps xmm14, [rsp+0xB0]
0000794c94dcfd02  vpermilpd xmm14, xmm14, 0x00
0000794c94dcfd08  vmovaps xmm6, [rsp+0xF0]
0000794c94dcfd11  vmovaps [rsp+0xF0], xmm1
0000794c94dcfd1a  movaps xmm11, xmm6
0000794c94dcfd1e  mulpd xmm11, xmm14
0000794c94dcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000794c94dcfd29  ptest xmm1, xmm1
0000794c94dcfd2e  jnz 0x0000794C94DD264D
0000794c94dcfd34  lea rax, [r14+0x20]
0000794c94dcfd38  movups xmm1, [r13+rax*1]
0000794c94dcfd3e  movaps [r15+0x110], xmm1
0000794c94dcfd46  vmovaps xmm6, [rsp+0xE0]
0000794c94dcfd4f  vmovaps [rsp+0xE0], xmm1
0000794c94dcfd58  movaps xmm14, xmm6
0000794c94dcfd5c  addpd xmm14, xmm2
0000794c94dcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000794c94dcfd67  ptest xmm1, xmm1
0000794c94dcfd6c  jnz 0x0000794C94DD279A
0000794c94dcfd72  vmovaps xmm1, [rsp+0xB0]
0000794c94dcfd7b  vpermilpd xmm1, xmm1, 0x00
0000794c94dcfd81  movaps xmm6, xmm5
0000794c94dcfd84  mulpd xmm6, xmm1
0000794c94dcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000794c94dcfd8d  ptest xmm2, xmm2
0000794c94dcfd92  jnz 0x0000794C94DD28DC
0000794c94dcfd98  vmovaps xmm5, [rsp+0x20]
0000794c94dcfd9e  movaps xmm1, xmm5
0000794c94dcfda1  addpd xmm1, xmm13
0000794c94dcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000794c94dcfdab  ptest xmm2, xmm2
0000794c94dcfdb0  jnz 0x0000794C94DD2A1C
0000794c94dcfdb6  vmovaps xmm13, [rsp+0x80]
0000794c94dcfdbf  vpermilpd xmm13, xmm13, 0x00
0000794c94dcfdc5  vmovaps xmm2, [rsp+0xE0]
0000794c94dcfdce  vmovaps [rsp+0x20], xmm1
0000794c94dcfdd4  movaps xmm5, xmm2
0000794c94dcfdd7  mulpd xmm5, xmm13
0000794c94dcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000794c94dcfde1  ptest xmm1, xmm1
0000794c94dcfde6  jnz 0x0000794C94DD2B5D
0000794c94dcfdec  vmovaps xmm1, [rsp+0x80]
0000794c94dcfdf5  vpermilpd xmm1, xmm1, 0x00
0000794c94dcfdfb  movaps xmm13, xmm10
0000794c94dcfdff  mulpd xmm13, xmm1
0000794c94dcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000794c94dcfe0a  ptest xmm2, xmm2
0000794c94dcfe0f  jnz 0x0000794C94DD2C9E
0000794c94dcfe15  vmovaps xmm10, [rsp+0x30]
0000794c94dcfe1b  movaps xmm1, xmm15
0000794c94dcfe1f  addpd xmm1, xmm10
0000794c94dcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000794c94dcfe29  ptest xmm2, xmm2
0000794c94dcfe2e  jnz 0x0000794C94DD2DE1
0000794c94dcfe34  vmovaps xmm10, [rsp+0xC0]
0000794c94dcfe3d  movaps xmm15, xmm10
0000794c94dcfe41  addpd xmm15, xmm11
0000794c94dcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000794c94dcfe4c  ptest xmm2, xmm2
0000794c94dcfe51  jnz 0x0000794C94DD2F23
0000794c94dcfe57  vmovaps xmm11, [rsp+0x80]
0000794c94dcfe60  vpermilpd xmm11, xmm11, 0x00
0000794c94dcfe66  movaps xmm10, xmm12
0000794c94dcfe6a  mulpd xmm10, xmm11
0000794c94dcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000794c94dcfe75  ptest xmm2, xmm2
0000794c94dcfe7a  jnz 0x0000794C94DD3067
0000794c94dcfe80  vmovaps xmm12, [rsp+0x80]
0000794c94dcfe89  vpermilpd xmm12, xmm12, 0x00
0000794c94dcfe8f  vmovaps xmm2, [rsp+0xA0]
0000794c94dcfe98  vmovaps [rsp+0x30], xmm1
0000794c94dcfe9e  movaps xmm11, xmm2
0000794c94dcfea2  mulpd xmm11, xmm12
0000794c94dcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000794c94dcfead  ptest xmm1, xmm1
0000794c94dcfeb2  jnz 0x0000794C94DD31AB
0000794c94dcfeb8  movaps xmm1, xmm14
0000794c94dcfebc  addpd xmm1, xmm6
0000794c94dcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000794c94dcfec5  ptest xmm12, xmm12
0000794c94dcfecb  jnz 0x0000794C94DD32EE
0000794c94dcfed1  vmovaps xmm12, [rsp+0x20]
0000794c94dcfed7  movaps xmm14, xmm12
0000794c94dcfedb  addpd xmm14, xmm5
0000794c94dcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000794c94dcfee6  ptest xmm6, xmm6
0000794c94dcfeeb  jnz 0x0000794C94DD342F
0000794c94dcfef1  vmovaps xmm12, [rsp+0x90]
0000794c94dcfefa  vpermilpd xmm12, xmm12, 0x00
0000794c94dcff00  movaps xmm6, xmm9
0000794c94dcff04  mulpd xmm6, xmm12
0000794c94dcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000794c94dcff0e  ptest xmm5, xmm5
0000794c94dcff13  jnz 0x0000794C94DD3572
0000794c94dcff19  movaps xmm12, xmm15
0000794c94dcff1d  addpd xmm12, xmm13
0000794c94dcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000794c94dcff28  ptest xmm9, xmm9
0000794c94dcff2e  jnz 0x0000794C94DD36B4
0000794c94dcff34  vmovaps xmm13, [rsp+0x30]
0000794c94dcff3a  movaps xmm15, xmm13
0000794c94dcff3e  addpd xmm15, xmm10
0000794c94dcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000794c94dcff49  ptest xmm9, xmm9
0000794c94dcff4f  jnz 0x0000794C94DD37F8
0000794c94dcff55  vmovaps xmm13, [rsp+0xD0]
0000794c94dcff5e  vmovaps xmm10, [rsp+0xD0]
0000794c94dcff67  por xmm13, xmm10
0000794c94dcff6c  movaps [r15+0x250], xmm13
0000794c94dcff74  vmovaps [rsp+0x20], xmm7
0000794c94dcff7a  vmovaps xmm13, [rsp+0x20]
0000794c94dcff80  por xmm7, xmm13
0000794c94dcff85  movaps [r15+0x2A0], xmm7
0000794c94dcff8d  vmovaps [rsp+0x20], xmm3
0000794c94dcff93  vmovaps xmm13, [rsp+0x20]
0000794c94dcff99  por xmm3, xmm13
0000794c94dcff9e  movaps [r15+0x1D0], xmm3
0000794c94dcffa6  lea rax, [r14+0x40]
0000794c94dcffaa  movups xmm13, [r13+rax*1]
0000794c94dcffb0  movaps [r15+0x2C0], xmm13
0000794c94dcffb8  vmovaps xmm10, [rsp+0x90]
0000794c94dcffc1  vpermilpd xmm10, xmm10, 0x00
0000794c94dcffc7  movaps xmm9, xmm8
0000794c94dcffcb  mulpd xmm9, xmm10
0000794c94dcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000794c94dcffd6  ptest xmm5, xmm5
0000794c94dcffdb  jnz 0x0000794C94DD3946
0000794c94dcffe1  movaps xmm10, xmm1
0000794c94dcffe5  addpd xmm10, xmm11
0000794c94dcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000794c94dcfff0  ptest xmm8, xmm8
0000794c94dcfff6  jnz 0x0000794C94DD3A8A
0000794c94dcfffc  movaps xmm1, xmm14
0000794c94dd0000  addpd xmm1, xmm6
0000794c94dd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000794c94dd0009  ptest xmm11, xmm11
0000794c94dd000f  jnz 0x0000794C94DD3BCD
0000794c94dd0015  vmovaps xmm14, [rsp+0x90]
0000794c94dd001e  vpermilpd xmm14, xmm14, 0x00
0000794c94dd0024  movaps xmm11, xmm13
0000794c94dd0028  mulpd xmm11, xmm14
0000794c94dd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000794c94dd0033  ptest xmm8, xmm8
0000794c94dd0039  jnz 0x0000794C94DD3D0E
0000794c94dd003f  vmovaps xmm14, [rsp+0x90]
0000794c94dd0048  vpermilpd xmm14, xmm14, 0x00
0000794c94dd004e  vmovaps xmm8, [rsp+0x10]
0000794c94dd0054  movaps xmm13, xmm8
0000794c94dd0058  mulpd xmm13, xmm14
0000794c94dd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000794c94dd0063  ptest xmm6, xmm6
0000794c94dd0068  jnz 0x0000794C94DD3E52
0000794c94dd006e  vmovaps xmm14, [rsp+0x60]
0000794c94dd0074  vpermilpd xmm14, xmm14, 0x00
0000794c94dd007a  movaps xmm8, xmm7
0000794c94dd007e  mulpd xmm8, xmm14
0000794c94dd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000794c94dd0089  ptest xmm6, xmm6
0000794c94dd008e  jnz 0x0000794C94DD3F96
0000794c94dd0094  movaps xmm14, xmm12
0000794c94dd0098  addpd xmm14, xmm9
0000794c94dd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000794c94dd00a3  ptest xmm7, xmm7
0000794c94dd00a8  jnz 0x0000794C94DD40D9
0000794c94dd00ae  vmovaps xmm12, [rsp+0x60]
0000794c94dd00b4  vpermilpd xmm12, xmm12, 0x00
0000794c94dd00ba  vmovaps xmm7, [rsp+0xF0]
0000794c94dd00c3  movaps xmm9, xmm7
0000794c94dd00c7  mulpd xmm9, xmm12
0000794c94dd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000794c94dd00d2  ptest xmm6, xmm6
0000794c94dd00d7  jnz 0x0000794C94DD421D
0000794c94dd00dd  movaps xmm12, xmm15
0000794c94dd00e1  addpd xmm12, xmm11
0000794c94dd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000794c94dd00ec  ptest xmm7, xmm7
0000794c94dd00f1  jnz 0x0000794C94DD4360
0000794c94dd00f7  vmovaps xmm15, [rsp+0x60]
0000794c94dd00fd  vpermilpd xmm15, xmm15, 0x00
0000794c94dd0103  vmovaps xmm7, [rsp+0x40]
0000794c94dd0109  movaps xmm11, xmm7
0000794c94dd010d  mulpd xmm11, xmm15
0000794c94dd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000794c94dd0118  ptest xmm6, xmm6
0000794c94dd011d  jnz 0x0000794C94DD44A4
0000794c94dd0123  movaps xmm15, xmm10
0000794c94dd0127  addpd xmm15, xmm13
0000794c94dd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000794c94dd0132  ptest xmm7, xmm7
0000794c94dd0137  jnz 0x0000794C94DD45E7
0000794c94dd013d  vmovaps xmm13, [rsp+0x60]
0000794c94dd0143  vpermilpd xmm13, xmm13, 0x00
0000794c94dd0149  vmovaps xmm7, [rsp+0x50]
0000794c94dd014f  movaps xmm10, xmm7
0000794c94dd0153  mulpd xmm10, xmm13
0000794c94dd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000794c94dd015e  ptest xmm6, xmm6
0000794c94dd0163  jnz 0x0000794C94DD472B
0000794c94dd0169  movaps xmm13, xmm1
0000794c94dd016d  addpd xmm13, xmm8
0000794c94dd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000794c94dd0178  ptest xmm7, xmm7
0000794c94dd017d  jnz 0x0000794C94DD486E
0000794c94dd0183  lea rax, [r14+0x70]
0000794c94dd0187  movups xmm1, [r13+rax*1]
0000794c94dd018d  movaps [r15+0x240], xmm1
0000794c94dd0195  movaps xmm8, xmm14
0000794c94dd0199  addpd xmm8, xmm9
0000794c94dd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000794c94dd01a4  ptest xmm7, xmm7
0000794c94dd01a9  jnz 0x0000794C94DD49BB
0000794c94dd01af  movaps [r15+0x170], xmm8
0000794c94dd01b7  vmovaps xmm14, [rsp+0x70]
0000794c94dd01bd  vpermilpd xmm14, xmm14, 0x00
0000794c94dd01c3  movaps xmm9, xmm1
0000794c94dd01c7  mulpd xmm9, xmm14
0000794c94dd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000794c94dd01d2  ptest xmm7, xmm7
0000794c94dd01d7  jnz 0x0000794C94DD4AFF
0000794c94dd01dd  vmovaps xmm1, [rsp+0x70]
0000794c94dd01e3  vpermilpd xmm1, xmm1, 0x00
0000794c94dd01e9  movaps xmm14, xmm4
0000794c94dd01ed  mulpd xmm14, xmm1
0000794c94dd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000794c94dd01f8  ptest xmm7, xmm7
0000794c94dd01fd  jnz 0x0000794C94DD4C42
0000794c94dd0203  movaps [r15+0x180], xmm14
0000794c94dd020b  movaps xmm1, xmm12
0000794c94dd020f  addpd xmm1, xmm11
0000794c94dd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000794c94dd0219  ptest xmm7, xmm7
0000794c94dd021e  jnz 0x0000794C94DD4D84
0000794c94dd0224  movaps [r15+0x210], xmm1
0000794c94dd022c  movups xmm12, [r13+r14*1]
0000794c94dd0232  lea rax, [r14+0x10]
0000794c94dd0236  movups xmm11, [r13+rax*1]
0000794c94dd023c  movaps [r15+0x230], xmm11
0000794c94dd0244  movaps xmm7, xmm15
0000794c94dd0248  addpd xmm7, xmm10
0000794c94dd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000794c94dd0252  ptest xmm6, xmm6
0000794c94dd0257  jnz 0x0000794C94DD4EDA
0000794c94dd025d  movaps [r15+0x130], xmm7
0000794c94dd0265  vmovaps xmm15, [rsp+0x70]
0000794c94dd026b  vpermilpd xmm15, xmm15, 0x00
0000794c94dd0271  movaps xmm10, xmm11
0000794c94dd0275  mulpd xmm10, xmm15
0000794c94dd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000794c94dd0280  ptest xmm6, xmm6
0000794c94dd0285  jnz 0x0000794C94DD501C
0000794c94dd028b  movaps [r15+0x220], xmm10
0000794c94dd0293  vmovaps xmm15, [rsp+0x70]
0000794c94dd0299  vpermilpd xmm15, xmm15, 0x00
0000794c94dd029f  movaps xmm11, xmm12
0000794c94dd02a3  mulpd xmm11, xmm15
0000794c94dd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000794c94dd02ae  ptest xmm6, xmm6
0000794c94dd02b3  jnz 0x0000794C94DD5160
0000794c94dd02b9  movaps xmm15, xmm13
0000794c94dd02bd  addpd xmm15, xmm9
0000794c94dd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000794c94dd02c8  ptest xmm12, xmm12
0000794c94dd02ce  jnz 0x0000794C94DD52A4
0000794c94dd02d4  movaps [r15+0x140], xmm15
0000794c94dd02dc  movaps xmm13, xmm8
0000794c94dd02e0  addpd xmm13, xmm14
0000794c94dd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000794c94dd02eb  ptest xmm12, xmm12
0000794c94dd02f1  jnz 0x0000794C94DD53E8
0000794c94dd02f7  movaps [r15+0x150], xmm13
0000794c94dd02ff  movaps xmm14, xmm1
0000794c94dd0303  addpd xmm14, xmm10
0000794c94dd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000794c94dd030e  ptest xmm12, xmm12
0000794c94dd0314  jnz 0x0000794C94DD552C
0000794c94dd031a  movaps [r15+0x160], xmm14
0000794c94dd0322  movaps xmm1, xmm7
0000794c94dd0325  addpd xmm1, xmm11
0000794c94dd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000794c94dd032f  ptest xmm12, xmm12
0000794c94dd0335  jnz 0x0000794C94DD566F
0000794c94dd033b  movaps [r15+0x120], xmm1
0000794c94dd0343  mov eax, 0x430920
0000794c94dd0348  movups [r13+rax*1], xmm15
0000794c94dd034e  mov eax, 0x430930
0000794c94dd0353  movups [r13+rax*1], xmm13
0000794c94dd0359  mov eax, 0x430940
0000794c94dd035e  movups [r13+rax*1], xmm14
0000794c94dd0364  mov eax, 0x430950
0000794c94dd0369  movups [r13+rax*1], xmm1
0000794c94dd036f  mov eax, [r15+0x108]
0000794c94dd0376  sahf
0000794c94dd0377  jnz 0x0000794C94DD03A9
0000794c94dd0379  cmp dword ptr [r15+0x318], 0x00
0000794c94dd0381  jz 0x0000794C94DDB900
0000794c94dd0387  nop [rax+rax*1], ax
0000794c94dd0390  nop [rax+rax*1], eax
0000794c94dd0398  mov eax, 0x410444
0000794c94dd039d  mov [r15+0x100], rax
0000794c94dd03a4  jmp 0x0000794C94BFE110
0000794c94dd03a9  cmp dword ptr [r15+0x318], 0x00
0000794c94dd03b1  jz 0x0000794C94DD57E0
0000794c94dd03b7  nop [rax+rax*1], ax
0000794c94dd03c0  nop [rax+rax*1], eax
0000794c94dd03c8  mov eax, 0x410278
0000794c94dd03cd  mov [r15+0x100], rax
0000794c94dd03d4  jmp 0x0000794C94BFE110
0000794c94dd03d9  int3
0000794c94dd03da  call 0x0000794C94CB52F0
0000794c94dd03df  jmp 0x0000794C94DCF016
0000794c94dd03e4  call 0x0000794C94CC4620
0000794c94dd03e9  jmp 0x0000794C94DCF023
0000794c94dd03ee  call 0x0000794C94CC33A0
0000794c94dd03f3  jmp 0x0000794C94DCF035
0000794c94dd03f8  call 0x0000794C94CC2120
0000794c94dd03fd  jmp 0x0000794C94DCF03F
0000794c94dd0402  call 0x0000794C94CC0860
0000794c94dd0407  jmp 0x0000794C94DCF067
0000794c94dd040c  call 0x0000794C94CBF5F0
0000794c94dd0411  jmp 0x0000794C94DCF073
0000794c94dd0416  call 0x0000794C94CC0860
0000794c94dd041b  jmp 0x0000794C94DCF0A5
0000794c94dd0420  call 0x0000794C94CBF5F0
0000794c94dd0425  jmp 0x0000794C94DCF0B1
0000794c94dd042a  call 0x0000794C94CC4740
0000794c94dd042f  jmp 0x0000794C94DCF0BE
0000794c94dd0434  call 0x0000794C94CB5400
0000794c94dd0439  jmp 0x0000794C94DCF0CB
0000794c94dd043e  call 0x0000794C94CB52F0
0000794c94dd0443  jmp 0x0000794C94DCF0D8
0000794c94dd0448  call 0x0000794C94CC4620
0000794c94dd044d  jmp 0x0000794C94DCF0E5
0000794c94dd0452  call 0x0000794C94CC0860
0000794c94dd0457  jmp 0x0000794C94DCF10D
0000794c94dd045c  call 0x0000794C94CBF5F0
0000794c94dd0461  jmp 0x0000794C94DCF119
0000794c94dd0466  call 0x0000794C94C09D70
0000794c94dd046b  jmp 0x0000794C94DCF11F
0000794c94dd0470  call 0x0000794C94CBE9C0
0000794c94dd0475  jmp 0x0000794C94DCF129
0000794c94dd047a  call 0x0000794C94CC0860
0000794c94dd047f  jmp 0x0000794C94DCF151
0000794c94dd0484  call 0x0000794C94CBF5F0
0000794c94dd0489  jmp 0x0000794C94DCF15D
0000794c94dd048e  call 0x0000794C94CBD750
0000794c94dd0493  jmp 0x0000794C94DCF16A
0000794c94dd0498  call 0x0000794C94CBC4E0
0000794c94dd049d  jmp 0x0000794C94DCF177
0000794c94dd04a2  call 0x0000794C94CC4740
0000794c94dd04a7  jmp 0x0000794C94DCF184
0000794c94dd04ac  call 0x0000794C94CB5400
0000794c94dd04b1  jmp 0x0000794C94DCF191
0000794c94dd04b6  call 0x0000794C94CB52F0
0000794c94dd04bb  jmp 0x0000794C94DCF19E
0000794c94dd04c0  call 0x0000794C94CC4620
0000794c94dd04c5  jmp 0x0000794C94DCF1AB
0000794c94dd04ca  call 0x0000794C94CC0860
0000794c94dd04cf  jmp 0x0000794C94DCF1BE
0000794c94dd04d4  call 0x0000794C94CBB270
0000794c94dd04d9  jmp 0x0000794C94DCF1CB
0000794c94dd04de  call 0x0000794C94CBA000
0000794c94dd04e3  jmp 0x0000794C94DCF1D8
0000794c94dd04e8  call 0x0000794C94CB8D90
0000794c94dd04ed  jmp 0x0000794C94DCF1E5
0000794c94dd04f2  call 0x0000794C94CB8A20
0000794c94dd04f7  jmp 0x0000794C94DCF1F2
0000794c94dd04fc  call 0x0000794C94CB5400
0000794c94dd0501  jmp 0x0000794C94DCF1FC
0000794c94dd0506  call 0x0000794C94CC2240
0000794c94dd050b  jmp 0x0000794C94DCF206
0000794c94dd0510  call 0x0000794C94CB52F0
0000794c94dd0515  jmp 0x0000794C94DCF210
0000794c94dd051a  call 0x0000794C94CC2120
0000794c94dd051f  jmp 0x0000794C94DCF21A
0000794c94dd0524  call 0x0000794C94CB77B0
0000794c94dd0529  jmp 0x0000794C94DCF224
0000794c94dd052e  call 0x0000794C94CB6550
0000794c94dd0533  jmp 0x0000794C94DCF22E
0000794c94dd0538  call 0x0000794C94CBFD50
0000794c94dd053d  jmp 0x0000794C94DCF240
0000794c94dd0542  call 0x0000794C94CB8EA0
0000794c94dd0547  jmp 0x0000794C94DCF24A
0000794c94dd054c  call 0x0000794C94CBFC30
0000794c94dd0551  jmp 0x0000794C94DCF257
0000794c94dd0556  call 0x0000794C94CB8D90
0000794c94dd055b  jmp 0x0000794C94DCF264
0000794c94dd0560  call 0x0000794C94CC2240
0000794c94dd0565  jmp 0x0000794C94DCF271
0000794c94dd056a  call 0x0000794C94CB5400
0000794c94dd056f  jmp 0x0000794C94DCF27E
0000794c94dd0574  call 0x0000794C94CB52F0
0000794c94dd0579  jmp 0x0000794C94DCF28B
0000794c94dd057e  call 0x0000794C94CC2120
0000794c94dd0583  jmp 0x0000794C94DCF298
0000794c94dd0588  call 0x0000794C94CB52F0
0000794c94dd058d  jmp 0x0000794C94DCF2AB
0000794c94dd0592  call 0x0000794C94CB52F0
0000794c94dd0597  jmp 0x0000794C94DCF2BE
0000794c94dd059c  call 0x0000794C94CB52F0
0000794c94dd05a1  jmp 0x0000794C94DCF2D1
0000794c94dd05a6  call 0x0000794C94CB52F0
0000794c94dd05ab  jmp 0x0000794C94DCF2E4
0000794c94dd05b0  call 0x0000794C94CC2240
0000794c94dd05b5  jmp 0x0000794C94DCF2F9
0000794c94dd05ba  call 0x0000794C94CC2240
0000794c94dd05bf  jmp 0x0000794C94DCF30C
0000794c94dd05c4  call 0x0000794C94CC2120
0000794c94dd05c9  jmp 0x0000794C94DCF319
0000794c94dd05ce  call 0x0000794C94CB52F0
0000794c94dd05d3  jmp 0x0000794C94DCF32C
0000794c94dd05d8  call 0x0000794C94CB52F0
0000794c94dd05dd  jmp 0x0000794C94DCF34F
0000794c94dd05e2  call 0x0000794C94CB52F0
0000794c94dd05e7  jmp 0x0000794C94DCF362
0000794c94dd05ec  call 0x0000794C94BFF540
0000794c94dd05f1  jmp 0x0000794C94DCF380
0000794c94dd05f6  call 0x0000794C94C08C20
0000794c94dd05fb  jmp 0x0000794C94DCF38A
0000794c94dd0600  call 0x0000794C94CD6600
0000794c94dd0605  jmp 0x0000794C94DCF396
0000794c94dd060a  call 0x0000794C94BFF540
0000794c94dd060f  jmp 0x0000794C94DCF3A6
0000794c94dd0614  call 0x0000794C94CC0370
0000794c94dd0619  jmp 0x0000794C94DCF3D4
0000794c94dd061e  call 0x0000794C94CBF100
0000794c94dd0623  jmp 0x0000794C94DCF3DD
0000794c94dd0628  call 0x0000794C94CC0370
0000794c94dd062d  jmp 0x0000794C94DCF43B
0000794c94dd0632  call 0x0000794C94CBF100
0000794c94dd0637  jmp 0x0000794C94DCF444
0000794c94dd063c  call 0x0000794C94CC0370
0000794c94dd0641  jmp 0x0000794C94DCF48B
0000794c94dd0646  call 0x0000794C94CBF100
0000794c94dd064b  jmp 0x0000794C94DCF494
0000794c94dd0650  call 0x0000794C94C0B720
0000794c94dd0655  jmp 0x0000794C94DCF4D7
0000794c94dd065a  call 0x0000794C94CB47C0
0000794c94dd065f  jmp 0x0000794C94DCF4EA
0000794c94dd0664  call 0x0000794C94C08B00
0000794c94dd0669  jmp 0x0000794C94DCF501
0000794c94dd066e  call 0x0000794C94BFF430
0000794c94dd0673  jmp 0x0000794C94DCF514
0000794c94dd0678  call 0x0000794C94BFF430
0000794c94dd067d  jmp 0x0000794C94DCF527
0000794c94dd0682  sub rsp, 0x08
0000794c94dd0686  push rax
0000794c94dd0687  push rcx
0000794c94dd0688  push rdx
0000794c94dd0689  push rdi
0000794c94dd068a  push rsi
0000794c94dd068b  push r8
0000794c94dd068d  push r9
0000794c94dd068f  push r10
0000794c94dd0691  push r11
0000794c94dd0693  sub rsp, 0xF0
0000794c94dd069a  vmovaps [rsp], xmm0
0000794c94dd069f  vmovaps [rsp+0x10], xmm2
0000794c94dd06a5  vmovaps [rsp+0x20], xmm3
0000794c94dd06ab  vmovaps [rsp+0x30], xmm4
0000794c94dd06b1  vmovaps [rsp+0x40], xmm5
0000794c94dd06b7  vmovaps [rsp+0x50], xmm6
0000794c94dd06bd  vmovaps [rsp+0x60], xmm7
0000794c94dd06c3  vmovaps [rsp+0x70], xmm8
0000794c94dd06c9  vmovaps [rsp+0x80], xmm9
0000794c94dd06d2  vmovaps [rsp+0x90], xmm10
0000794c94dd06db  vmovaps [rsp+0xA0], xmm11
0000794c94dd06e4  vmovaps [rsp+0xB0], xmm12
0000794c94dd06ed  vmovaps [rsp+0xC0], xmm13
0000794c94dd06f6  vmovaps [rsp+0xD0], xmm14
0000794c94dd06ff  vmovaps [rsp+0xE0], xmm15
0000794c94dd0708  sub rsp, 0x30
0000794c94dd070c  movaps [rsp], xmm1
0000794c94dd0710  movaps [rsp+0x10], xmm15
0000794c94dd0716  movaps [rsp+0x20], xmm14
0000794c94dd071c  lea rdi, [rsp]
0000794c94dd0720  mov esi, 0x00
0000794c94dd0725  mov rax, 0x5AB2B8B81530
0000794c94dd072f  call rax
0000794c94dd0731  movaps xmm1, [rsp]
0000794c94dd0735  add rsp, 0x30
0000794c94dd0739  vmovaps xmm0, [rsp]
0000794c94dd073e  vmovaps xmm2, [rsp+0x10]
0000794c94dd0744  vmovaps xmm3, [rsp+0x20]
0000794c94dd074a  vmovaps xmm4, [rsp+0x30]
0000794c94dd0750  vmovaps xmm5, [rsp+0x40]
0000794c94dd0756  vmovaps xmm6, [rsp+0x50]
0000794c94dd075c  vmovaps xmm7, [rsp+0x60]
0000794c94dd0762  vmovaps xmm8, [rsp+0x70]
0000794c94dd0768  vmovaps xmm9, [rsp+0x80]
0000794c94dd0771  vmovaps xmm10, [rsp+0x90]
0000794c94dd077a  vmovaps xmm11, [rsp+0xA0]
0000794c94dd0783  vmovaps xmm12, [rsp+0xB0]
0000794c94dd078c  vmovaps xmm13, [rsp+0xC0]
0000794c94dd0795  vmovaps xmm14, [rsp+0xD0]
0000794c94dd079e  vmovaps xmm15, [rsp+0xE0]
0000794c94dd07a7  add rsp, 0xF0
0000794c94dd07ae  pop r11
0000794c94dd07b0  pop r10
0000794c94dd07b2  pop r9
0000794c94dd07b4  pop r8
0000794c94dd07b6  pop rsi
0000794c94dd07b7  pop rdi
0000794c94dd07b8  pop rdx
0000794c94dd07b9  pop rcx
0000794c94dd07ba  pop rax
0000794c94dd07bb  add rsp, 0x08
0000794c94dd07bf  jmp 0x0000794C94DCF581
0000794c94dd07c4  sub rsp, 0x08
0000794c94dd07c8  push rax
0000794c94dd07c9  push rcx
0000794c94dd07ca  push rdx
0000794c94dd07cb  push rdi
0000794c94dd07cc  push rsi
0000794c94dd07cd  push r8
0000794c94dd07cf  push r9
0000794c94dd07d1  push r10
0000794c94dd07d3  push r11
0000794c94dd07d5  sub rsp, 0xF0
0000794c94dd07dc  vmovaps [rsp], xmm0
0000794c94dd07e1  vmovaps [rsp+0x10], xmm1
0000794c94dd07e7  vmovaps [rsp+0x20], xmm2
0000794c94dd07ed  vmovaps [rsp+0x30], xmm3
0000794c94dd07f3  vmovaps [rsp+0x40], xmm4
0000794c94dd07f9  vmovaps [rsp+0x50], xmm5
0000794c94dd07ff  vmovaps [rsp+0x60], xmm6
0000794c94dd0805  vmovaps [rsp+0x70], xmm7
0000794c94dd080b  vmovaps [rsp+0x80], xmm8
0000794c94dd0814  vmovaps [rsp+0x90], xmm9
0000794c94dd081d  vmovaps [rsp+0xA0], xmm10
0000794c94dd0826  vmovaps [rsp+0xB0], xmm11
0000794c94dd082f  vmovaps [rsp+0xC0], xmm12
0000794c94dd0838  vmovaps [rsp+0xD0], xmm14
0000794c94dd0841  vmovaps [rsp+0xE0], xmm15
0000794c94dd084a  sub rsp, 0x30
0000794c94dd084e  movaps [rsp], xmm13
0000794c94dd0853  movaps [rsp+0x10], xmm1
0000794c94dd0858  movaps [rsp+0x20], xmm14
0000794c94dd085e  lea rdi, [rsp]
0000794c94dd0862  mov esi, 0x00
0000794c94dd0867  mov rax, 0x5AB2B8B81530
0000794c94dd0871  call rax
0000794c94dd0873  movaps xmm13, [rsp]
0000794c94dd0878  add rsp, 0x30
0000794c94dd087c  vmovaps xmm0, [rsp]
0000794c94dd0881  vmovaps xmm1, [rsp+0x10]
0000794c94dd0887  vmovaps xmm2, [rsp+0x20]
0000794c94dd088d  vmovaps xmm3, [rsp+0x30]
0000794c94dd0893  vmovaps xmm4, [rsp+0x40]
0000794c94dd0899  vmovaps xmm5, [rsp+0x50]
0000794c94dd089f  vmovaps xmm6, [rsp+0x60]
0000794c94dd08a5  vmovaps xmm7, [rsp+0x70]
0000794c94dd08ab  vmovaps xmm8, [rsp+0x80]
0000794c94dd08b4  vmovaps xmm9, [rsp+0x90]
0000794c94dd08bd  vmovaps xmm10, [rsp+0xA0]
0000794c94dd08c6  vmovaps xmm11, [rsp+0xB0]
0000794c94dd08cf  vmovaps xmm12, [rsp+0xC0]
0000794c94dd08d8  vmovaps xmm14, [rsp+0xD0]
0000794c94dd08e1  vmovaps xmm15, [rsp+0xE0]
0000794c94dd08ea  add rsp, 0xF0
0000794c94dd08f1  pop r11
0000794c94dd08f3  pop r10
0000794c94dd08f5  pop r9
0000794c94dd08f7  pop r8
0000794c94dd08f9  pop rsi
0000794c94dd08fa  pop rdi
0000794c94dd08fb  pop rdx
0000794c94dd08fc  pop rcx
0000794c94dd08fd  pop rax
0000794c94dd08fe  add rsp, 0x08
0000794c94dd0902  jmp 0x0000794C94DCF5CF
0000794c94dd0907  sub rsp, 0x08
0000794c94dd090b  push rax
0000794c94dd090c  push rcx
0000794c94dd090d  push rdx
0000794c94dd090e  push rdi
0000794c94dd090f  push rsi
0000794c94dd0910  push r8
0000794c94dd0912  push r9
0000794c94dd0914  push r10
0000794c94dd0916  push r11
0000794c94dd0918  sub rsp, 0xF0
0000794c94dd091f  vmovaps [rsp], xmm0
0000794c94dd0924  vmovaps [rsp+0x10], xmm1
0000794c94dd092a  vmovaps [rsp+0x20], xmm2
0000794c94dd0930  vmovaps [rsp+0x30], xmm3
0000794c94dd0936  vmovaps [rsp+0x40], xmm4
0000794c94dd093c  vmovaps [rsp+0x50], xmm5
0000794c94dd0942  vmovaps [rsp+0x60], xmm6
0000794c94dd0948  vmovaps [rsp+0x70], xmm7
0000794c94dd094e  vmovaps [rsp+0x80], xmm8
0000794c94dd0957  vmovaps [rsp+0x90], xmm9
0000794c94dd0960  vmovaps [rsp+0xA0], xmm10
0000794c94dd0969  vmovaps [rsp+0xB0], xmm11
0000794c94dd0972  vmovaps [rsp+0xC0], xmm12
0000794c94dd097b  vmovaps [rsp+0xD0], xmm13
0000794c94dd0984  vmovaps [rsp+0xE0], xmm14
0000794c94dd098d  sub rsp, 0x30
0000794c94dd0991  movaps [rsp], xmm15
0000794c94dd0996  movaps [rsp+0x10], xmm14
0000794c94dd099c  movaps [rsp+0x20], xmm1
0000794c94dd09a1  lea rdi, [rsp]
0000794c94dd09a5  mov esi, 0x00
0000794c94dd09aa  mov rax, 0x5AB2B8B81530
0000794c94dd09b4  call rax
0000794c94dd09b6  movaps xmm15, [rsp]
0000794c94dd09bb  add rsp, 0x30
0000794c94dd09bf  vmovaps xmm0, [rsp]
0000794c94dd09c4  vmovaps xmm1, [rsp+0x10]
0000794c94dd09ca  vmovaps xmm2, [rsp+0x20]
0000794c94dd09d0  vmovaps xmm3, [rsp+0x30]
0000794c94dd09d6  vmovaps xmm4, [rsp+0x40]
0000794c94dd09dc  vmovaps xmm5, [rsp+0x50]
0000794c94dd09e2  vmovaps xmm6, [rsp+0x60]
0000794c94dd09e8  vmovaps xmm7, [rsp+0x70]
0000794c94dd09ee  vmovaps xmm8, [rsp+0x80]
0000794c94dd09f7  vmovaps xmm9, [rsp+0x90]
0000794c94dd0a00  vmovaps xmm10, [rsp+0xA0]
0000794c94dd0a09  vmovaps xmm11, [rsp+0xB0]
0000794c94dd0a12  vmovaps xmm12, [rsp+0xC0]
0000794c94dd0a1b  vmovaps xmm13, [rsp+0xD0]
0000794c94dd0a24  vmovaps xmm14, [rsp+0xE0]
0000794c94dd0a2d  add rsp, 0xF0
0000794c94dd0a34  pop r11
0000794c94dd0a36  pop r10
0000794c94dd0a38  pop r9
0000794c94dd0a3a  pop r8
0000794c94dd0a3c  pop rsi
0000794c94dd0a3d  pop rdi
0000794c94dd0a3e  pop rdx
0000794c94dd0a3f  pop rcx
0000794c94dd0a40  pop rax
0000794c94dd0a41  add rsp, 0x08
0000794c94dd0a45  jmp 0x0000794C94DCF617
0000794c94dd0a4a  sub rsp, 0x08
0000794c94dd0a4e  push rax
0000794c94dd0a4f  push rcx
0000794c94dd0a50  push rdx
0000794c94dd0a51  push rdi
0000794c94dd0a52  push rsi
0000794c94dd0a53  push r8
0000794c94dd0a55  push r9
0000794c94dd0a57  push r10
0000794c94dd0a59  push r11
0000794c94dd0a5b  sub rsp, 0xF0
0000794c94dd0a62  vmovaps [rsp], xmm0
0000794c94dd0a67  vmovaps [rsp+0x10], xmm2
0000794c94dd0a6d  vmovaps [rsp+0x20], xmm3
0000794c94dd0a73  vmovaps [rsp+0x30], xmm4
0000794c94dd0a79  vmovaps [rsp+0x40], xmm5
0000794c94dd0a7f  vmovaps [rsp+0x50], xmm6
0000794c94dd0a85  vmovaps [rsp+0x60], xmm7
0000794c94dd0a8b  vmovaps [rsp+0x70], xmm8
0000794c94dd0a91  vmovaps [rsp+0x80], xmm9
0000794c94dd0a9a  vmovaps [rsp+0x90], xmm10
0000794c94dd0aa3  vmovaps [rsp+0xA0], xmm11
0000794c94dd0aac  vmovaps [rsp+0xB0], xmm12
0000794c94dd0ab5  vmovaps [rsp+0xC0], xmm13
0000794c94dd0abe  vmovaps [rsp+0xD0], xmm14
0000794c94dd0ac7  vmovaps [rsp+0xE0], xmm15
0000794c94dd0ad0  sub rsp, 0x30
0000794c94dd0ad4  movaps [rsp], xmm1
0000794c94dd0ad8  movaps [rsp+0x10], xmm14
0000794c94dd0ade  movaps [rsp+0x20], xmm10
0000794c94dd0ae4  lea rdi, [rsp]
0000794c94dd0ae8  mov esi, 0x00
0000794c94dd0aed  mov rax, 0x5AB2B8B81530
0000794c94dd0af7  call rax
0000794c94dd0af9  movaps xmm1, [rsp]
0000794c94dd0afd  add rsp, 0x30
0000794c94dd0b01  vmovaps xmm0, [rsp]
0000794c94dd0b06  vmovaps xmm2, [rsp+0x10]
0000794c94dd0b0c  vmovaps xmm3, [rsp+0x20]
0000794c94dd0b12  vmovaps xmm4, [rsp+0x30]
0000794c94dd0b18  vmovaps xmm5, [rsp+0x40]
0000794c94dd0b1e  vmovaps xmm6, [rsp+0x50]
0000794c94dd0b24  vmovaps xmm7, [rsp+0x60]
0000794c94dd0b2a  vmovaps xmm8, [rsp+0x70]
0000794c94dd0b30  vmovaps xmm9, [rsp+0x80]
0000794c94dd0b39  vmovaps xmm10, [rsp+0x90]
0000794c94dd0b42  vmovaps xmm11, [rsp+0xA0]
0000794c94dd0b4b  vmovaps xmm12, [rsp+0xB0]
0000794c94dd0b54  vmovaps xmm13, [rsp+0xC0]
0000794c94dd0b5d  vmovaps xmm14, [rsp+0xD0]
0000794c94dd0b66  vmovaps xmm15, [rsp+0xE0]
0000794c94dd0b6f  add rsp, 0xF0
0000794c94dd0b76  pop r11
0000794c94dd0b78  pop r10
0000794c94dd0b7a  pop r9
0000794c94dd0b7c  pop r8
0000794c94dd0b7e  pop rsi
0000794c94dd0b7f  pop rdi
0000794c94dd0b80  pop rdx
0000794c94dd0b81  pop rcx
0000794c94dd0b82  pop rax
0000794c94dd0b83  add rsp, 0x08
0000794c94dd0b87  jmp 0x0000794C94DCF631
0000794c94dd0b8c  sub rsp, 0x08
0000794c94dd0b90  push rax
0000794c94dd0b91  push rcx
0000794c94dd0b92  push rdx
0000794c94dd0b93  push rdi
0000794c94dd0b94  push rsi
0000794c94dd0b95  push r8
0000794c94dd0b97  push r9
0000794c94dd0b99  push r10
0000794c94dd0b9b  push r11
0000794c94dd0b9d  sub rsp, 0xF0
0000794c94dd0ba4  vmovaps [rsp], xmm0
0000794c94dd0ba9  vmovaps [rsp+0x10], xmm1
0000794c94dd0baf  vmovaps [rsp+0x20], xmm2
0000794c94dd0bb5  vmovaps [rsp+0x30], xmm3
0000794c94dd0bbb  vmovaps [rsp+0x40], xmm4
0000794c94dd0bc1  vmovaps [rsp+0x50], xmm5
0000794c94dd0bc7  vmovaps [rsp+0x60], xmm6
0000794c94dd0bcd  vmovaps [rsp+0x70], xmm7
0000794c94dd0bd3  vmovaps [rsp+0x80], xmm8
0000794c94dd0bdc  vmovaps [rsp+0x90], xmm9
0000794c94dd0be5  vmovaps [rsp+0xA0], xmm10
0000794c94dd0bee  vmovaps [rsp+0xB0], xmm11
0000794c94dd0bf7  vmovaps [rsp+0xC0], xmm12
0000794c94dd0c00  vmovaps [rsp+0xD0], xmm14
0000794c94dd0c09  vmovaps [rsp+0xE0], xmm15
0000794c94dd0c12  sub rsp, 0x30
0000794c94dd0c16  movaps [rsp], xmm13
0000794c94dd0c1b  movaps [rsp+0x10], xmm14
0000794c94dd0c21  movaps [rsp+0x20], xmm2
0000794c94dd0c26  lea rdi, [rsp]
0000794c94dd0c2a  mov esi, 0x00
0000794c94dd0c2f  mov rax, 0x5AB2B8B81530
0000794c94dd0c39  call rax
0000794c94dd0c3b  movaps xmm13, [rsp]
0000794c94dd0c40  add rsp, 0x30
0000794c94dd0c44  vmovaps xmm0, [rsp]
0000794c94dd0c49  vmovaps xmm1, [rsp+0x10]
0000794c94dd0c4f  vmovaps xmm2, [rsp+0x20]
0000794c94dd0c55  vmovaps xmm3, [rsp+0x30]
0000794c94dd0c5b  vmovaps xmm4, [rsp+0x40]
0000794c94dd0c61  vmovaps xmm5, [rsp+0x50]
0000794c94dd0c67  vmovaps xmm6, [rsp+0x60]
0000794c94dd0c6d  vmovaps xmm7, [rsp+0x70]
0000794c94dd0c73  vmovaps xmm8, [rsp+0x80]
0000794c94dd0c7c  vmovaps xmm9, [rsp+0x90]
0000794c94dd0c85  vmovaps xmm10, [rsp+0xA0]
0000794c94dd0c8e  vmovaps xmm11, [rsp+0xB0]
0000794c94dd0c97  vmovaps xmm12, [rsp+0xC0]
0000794c94dd0ca0  vmovaps xmm14, [rsp+0xD0]
0000794c94dd0ca9  vmovaps xmm15, [rsp+0xE0]
0000794c94dd0cb2  add rsp, 0xF0
0000794c94dd0cb9  pop r11
0000794c94dd0cbb  pop r10
0000794c94dd0cbd  pop r9
0000794c94dd0cbf  pop r8
0000794c94dd0cc1  pop rsi
0000794c94dd0cc2  pop rdi
0000794c94dd0cc3  pop rdx
0000794c94dd0cc4  pop rcx
0000794c94dd0cc5  pop rax
0000794c94dd0cc6  add rsp, 0x08
0000794c94dd0cca  jmp 0x0000794C94DCF64C
0000794c94dd0ccf  sub rsp, 0x08
0000794c94dd0cd3  push rax
0000794c94dd0cd4  push rcx
0000794c94dd0cd5  push rdx
0000794c94dd0cd6  push rdi
0000794c94dd0cd7  push rsi
0000794c94dd0cd8  push r8
0000794c94dd0cda  push r9
0000794c94dd0cdc  push r10
0000794c94dd0cde  push r11
0000794c94dd0ce0  sub rsp, 0xF0
0000794c94dd0ce7  vmovaps [rsp], xmm0
0000794c94dd0cec  vmovaps [rsp+0x10], xmm2
0000794c94dd0cf2  vmovaps [rsp+0x20], xmm3
0000794c94dd0cf8  vmovaps [rsp+0x30], xmm4
0000794c94dd0cfe  vmovaps [rsp+0x40], xmm5
0000794c94dd0d04  vmovaps [rsp+0x50], xmm6
0000794c94dd0d0a  vmovaps [rsp+0x60], xmm7
0000794c94dd0d10  vmovaps [rsp+0x70], xmm8
0000794c94dd0d16  vmovaps [rsp+0x80], xmm9
0000794c94dd0d1f  vmovaps [rsp+0x90], xmm10
0000794c94dd0d28  vmovaps [rsp+0xA0], xmm11
0000794c94dd0d31  vmovaps [rsp+0xB0], xmm12
0000794c94dd0d3a  vmovaps [rsp+0xC0], xmm13
0000794c94dd0d43  vmovaps [rsp+0xD0], xmm14
0000794c94dd0d4c  vmovaps [rsp+0xE0], xmm15
0000794c94dd0d55  sub rsp, 0x30
0000794c94dd0d59  movaps [rsp], xmm1
0000794c94dd0d5d  movaps [rsp+0x10], xmm10
0000794c94dd0d63  movaps [rsp+0x20], xmm2
0000794c94dd0d68  lea rdi, [rsp]
0000794c94dd0d6c  mov esi, 0x00
0000794c94dd0d71  mov rax, 0x5AB2B8B81530
0000794c94dd0d7b  call rax
0000794c94dd0d7d  movaps xmm1, [rsp]
0000794c94dd0d81  add rsp, 0x30
0000794c94dd0d85  vmovaps xmm0, [rsp]
0000794c94dd0d8a  vmovaps xmm2, [rsp+0x10]
0000794c94dd0d90  vmovaps xmm3, [rsp+0x20]
0000794c94dd0d96  vmovaps xmm4, [rsp+0x30]
0000794c94dd0d9c  vmovaps xmm5, [rsp+0x40]
0000794c94dd0da2  vmovaps xmm6, [rsp+0x50]
0000794c94dd0da8  vmovaps xmm7, [rsp+0x60]
0000794c94dd0dae  vmovaps xmm8, [rsp+0x70]
0000794c94dd0db4  vmovaps xmm9, [rsp+0x80]
0000794c94dd0dbd  vmovaps xmm10, [rsp+0x90]
0000794c94dd0dc6  vmovaps xmm11, [rsp+0xA0]
0000794c94dd0dcf  vmovaps xmm12, [rsp+0xB0]
0000794c94dd0dd8  vmovaps xmm13, [rsp+0xC0]
0000794c94dd0de1  vmovaps xmm14, [rsp+0xD0]
0000794c94dd0dea  vmovaps xmm15, [rsp+0xE0]
0000794c94dd0df3  add rsp, 0xF0
0000794c94dd0dfa  pop r11
0000794c94dd0dfc  pop r10
0000794c94dd0dfe  pop r9
0000794c94dd0e00  pop r8
0000794c94dd0e02  pop rsi
0000794c94dd0e03  pop rdi
0000794c94dd0e04  pop rdx
0000794c94dd0e05  pop rcx
0000794c94dd0e06  pop rax
0000794c94dd0e07  add rsp, 0x08
0000794c94dd0e0b  jmp 0x0000794C94DCF6B4
0000794c94dd0e10  sub rsp, 0x08
0000794c94dd0e14  push rax
0000794c94dd0e15  push rcx
0000794c94dd0e16  push rdx
0000794c94dd0e17  push rdi
0000794c94dd0e18  push rsi
0000794c94dd0e19  push r8
0000794c94dd0e1b  push r9
0000794c94dd0e1d  push r10
0000794c94dd0e1f  push r11
0000794c94dd0e21  sub rsp, 0xF0
0000794c94dd0e28  vmovaps [rsp], xmm0
0000794c94dd0e2d  vmovaps [rsp+0x10], xmm1
0000794c94dd0e33  vmovaps [rsp+0x20], xmm2
0000794c94dd0e39  vmovaps [rsp+0x30], xmm3
0000794c94dd0e3f  vmovaps [rsp+0x40], xmm4
0000794c94dd0e45  vmovaps [rsp+0x50], xmm5
0000794c94dd0e4b  vmovaps [rsp+0x60], xmm6
0000794c94dd0e51  vmovaps [rsp+0x70], xmm7
0000794c94dd0e57  vmovaps [rsp+0x80], xmm8
0000794c94dd0e60  vmovaps [rsp+0x90], xmm9
0000794c94dd0e69  vmovaps [rsp+0xA0], xmm10
0000794c94dd0e72  vmovaps [rsp+0xB0], xmm11
0000794c94dd0e7b  vmovaps [rsp+0xC0], xmm12
0000794c94dd0e84  vmovaps [rsp+0xD0], xmm13
0000794c94dd0e8d  vmovaps [rsp+0xE0], xmm14
0000794c94dd0e96  sub rsp, 0x30
0000794c94dd0e9a  movaps [rsp], xmm15
0000794c94dd0e9f  movaps [rsp+0x10], xmm10
0000794c94dd0ea5  movaps [rsp+0x20], xmm2
0000794c94dd0eaa  lea rdi, [rsp]
0000794c94dd0eae  mov esi, 0x00
0000794c94dd0eb3  mov rax, 0x5AB2B8B81530
0000794c94dd0ebd  call rax
0000794c94dd0ebf  movaps xmm15, [rsp]
0000794c94dd0ec4  add rsp, 0x30
0000794c94dd0ec8  vmovaps xmm0, [rsp]
0000794c94dd0ecd  vmovaps xmm1, [rsp+0x10]
0000794c94dd0ed3  vmovaps xmm2, [rsp+0x20]
0000794c94dd0ed9  vmovaps xmm3, [rsp+0x30]
0000794c94dd0edf  vmovaps xmm4, [rsp+0x40]
0000794c94dd0ee5  vmovaps xmm5, [rsp+0x50]
0000794c94dd0eeb  vmovaps xmm6, [rsp+0x60]
0000794c94dd0ef1  vmovaps xmm7, [rsp+0x70]
0000794c94dd0ef7  vmovaps xmm8, [rsp+0x80]
0000794c94dd0f00  vmovaps xmm9, [rsp+0x90]
0000794c94dd0f09  vmovaps xmm10, [rsp+0xA0]
0000794c94dd0f12  vmovaps xmm11, [rsp+0xB0]
0000794c94dd0f1b  vmovaps xmm12, [rsp+0xC0]
0000794c94dd0f24  vmovaps xmm13, [rsp+0xD0]
0000794c94dd0f2d  vmovaps xmm14, [rsp+0xE0]
0000794c94dd0f36  add rsp, 0xF0
0000794c94dd0f3d  pop r11
0000794c94dd0f3f  pop r10
0000794c94dd0f41  pop r9
0000794c94dd0f43  pop r8
0000794c94dd0f45  pop rsi
0000794c94dd0f46  pop rdi
0000794c94dd0f47  pop rdx
0000794c94dd0f48  pop rcx
0000794c94dd0f49  pop rax
0000794c94dd0f4a  add rsp, 0x08
0000794c94dd0f4e  jmp 0x0000794C94DCF706
0000794c94dd0f53  sub rsp, 0x08
0000794c94dd0f57  push rax
0000794c94dd0f58  push rcx
0000794c94dd0f59  push rdx
0000794c94dd0f5a  push rdi
0000794c94dd0f5b  push rsi
0000794c94dd0f5c  push r8
0000794c94dd0f5e  push r9
0000794c94dd0f60  push r10
0000794c94dd0f62  push r11
0000794c94dd0f64  sub rsp, 0xF0
0000794c94dd0f6b  vmovaps [rsp], xmm0
0000794c94dd0f70  vmovaps [rsp+0x10], xmm2
0000794c94dd0f76  vmovaps [rsp+0x20], xmm3
0000794c94dd0f7c  vmovaps [rsp+0x30], xmm4
0000794c94dd0f82  vmovaps [rsp+0x40], xmm5
0000794c94dd0f88  vmovaps [rsp+0x50], xmm6
0000794c94dd0f8e  vmovaps [rsp+0x60], xmm7
0000794c94dd0f94  vmovaps [rsp+0x70], xmm8
0000794c94dd0f9a  vmovaps [rsp+0x80], xmm9
0000794c94dd0fa3  vmovaps [rsp+0x90], xmm10
0000794c94dd0fac  vmovaps [rsp+0xA0], xmm11
0000794c94dd0fb5  vmovaps [rsp+0xB0], xmm12
0000794c94dd0fbe  vmovaps [rsp+0xC0], xmm13
0000794c94dd0fc7  vmovaps [rsp+0xD0], xmm14
0000794c94dd0fd0  vmovaps [rsp+0xE0], xmm15
0000794c94dd0fd9  sub rsp, 0x30
0000794c94dd0fdd  movaps [rsp], xmm1
0000794c94dd0fe1  movaps [rsp+0x10], xmm10
0000794c94dd0fe7  movaps [rsp+0x20], xmm12
0000794c94dd0fed  lea rdi, [rsp]
0000794c94dd0ff1  mov esi, 0x00
0000794c94dd0ff6  mov rax, 0x5AB2B8B81530
0000794c94dd1000  call rax
0000794c94dd1002  movaps xmm1, [rsp]
0000794c94dd1006  add rsp, 0x30
0000794c94dd100a  vmovaps xmm0, [rsp]
0000794c94dd100f  vmovaps xmm2, [rsp+0x10]
0000794c94dd1015  vmovaps xmm3, [rsp+0x20]
0000794c94dd101b  vmovaps xmm4, [rsp+0x30]
0000794c94dd1021  vmovaps xmm5, [rsp+0x40]
0000794c94dd1027  vmovaps xmm6, [rsp+0x50]
0000794c94dd102d  vmovaps xmm7, [rsp+0x60]
0000794c94dd1033  vmovaps xmm8, [rsp+0x70]
0000794c94dd1039  vmovaps xmm9, [rsp+0x80]
0000794c94dd1042  vmovaps xmm10, [rsp+0x90]
0000794c94dd104b  vmovaps xmm11, [rsp+0xA0]
0000794c94dd1054  vmovaps xmm12, [rsp+0xB0]
0000794c94dd105d  vmovaps xmm13, [rsp+0xC0]
0000794c94dd1066  vmovaps xmm14, [rsp+0xD0]
0000794c94dd106f  vmovaps xmm15, [rsp+0xE0]
0000794c94dd1078  add rsp, 0xF0
0000794c94dd107f  pop r11
0000794c94dd1081  pop r10
0000794c94dd1083  pop r9
0000794c94dd1085  pop r8
0000794c94dd1087  pop rsi
0000794c94dd1088  pop rdi
0000794c94dd1089  pop rdx
0000794c94dd108a  pop rcx
0000794c94dd108b  pop rax
0000794c94dd108c  add rsp, 0x08
0000794c94dd1090  jmp 0x0000794C94DCF732
0000794c94dd1095  sub rsp, 0x08
0000794c94dd1099  push rax
0000794c94dd109a  push rcx
0000794c94dd109b  push rdx
0000794c94dd109c  push rdi
0000794c94dd109d  push rsi
0000794c94dd109e  push r8
0000794c94dd10a0  push r9
0000794c94dd10a2  push r10
0000794c94dd10a4  push r11
0000794c94dd10a6  sub rsp, 0xF0
0000794c94dd10ad  vmovaps [rsp], xmm0
0000794c94dd10b2  vmovaps [rsp+0x10], xmm1
0000794c94dd10b8  vmovaps [rsp+0x20], xmm2
0000794c94dd10be  vmovaps [rsp+0x30], xmm3
0000794c94dd10c4  vmovaps [rsp+0x40], xmm4
0000794c94dd10ca  vmovaps [rsp+0x50], xmm5
0000794c94dd10d0  vmovaps [rsp+0x60], xmm6
0000794c94dd10d6  vmovaps [rsp+0x70], xmm7
0000794c94dd10dc  vmovaps [rsp+0x80], xmm8
0000794c94dd10e5  vmovaps [rsp+0x90], xmm9
0000794c94dd10ee  vmovaps [rsp+0xA0], xmm10
0000794c94dd10f7  vmovaps [rsp+0xB0], xmm11
0000794c94dd1100  vmovaps [rsp+0xC0], xmm12
0000794c94dd1109  vmovaps [rsp+0xD0], xmm13
0000794c94dd1112  vmovaps [rsp+0xE0], xmm14
0000794c94dd111b  sub rsp, 0x30
0000794c94dd111f  movaps [rsp], xmm15
0000794c94dd1124  movaps [rsp+0x10], xmm10
0000794c94dd112a  movaps [rsp+0x20], xmm12
0000794c94dd1130  lea rdi, [rsp]
0000794c94dd1134  mov esi, 0x00
0000794c94dd1139  mov rax, 0x5AB2B8B81530
0000794c94dd1143  call rax
0000794c94dd1145  movaps xmm15, [rsp]
0000794c94dd114a  add rsp, 0x30
0000794c94dd114e  vmovaps xmm0, [rsp]
0000794c94dd1153  vmovaps xmm1, [rsp+0x10]
0000794c94dd1159  vmovaps xmm2, [rsp+0x20]
0000794c94dd115f  vmovaps xmm3, [rsp+0x30]
0000794c94dd1165  vmovaps xmm4, [rsp+0x40]
0000794c94dd116b  vmovaps xmm5, [rsp+0x50]
0000794c94dd1171  vmovaps xmm6, [rsp+0x60]
0000794c94dd1177  vmovaps xmm7, [rsp+0x70]
0000794c94dd117d  vmovaps xmm8, [rsp+0x80]
0000794c94dd1186  vmovaps xmm9, [rsp+0x90]
0000794c94dd118f  vmovaps xmm10, [rsp+0xA0]
0000794c94dd1198  vmovaps xmm11, [rsp+0xB0]
0000794c94dd11a1  vmovaps xmm12, [rsp+0xC0]
0000794c94dd11aa  vmovaps xmm13, [rsp+0xD0]
0000794c94dd11b3  vmovaps xmm14, [rsp+0xE0]
0000794c94dd11bc  add rsp, 0xF0
0000794c94dd11c3  pop r11
0000794c94dd11c5  pop r10
0000794c94dd11c7  pop r9
0000794c94dd11c9  pop r8
0000794c94dd11cb  pop rsi
0000794c94dd11cc  pop rdi
0000794c94dd11cd  pop rdx
0000794c94dd11ce  pop rcx
0000794c94dd11cf  pop rax
0000794c94dd11d0  add rsp, 0x08
0000794c94dd11d4  jmp 0x0000794C94DCF75E
0000794c94dd11d9  call 0x0000794C94BFF430
0000794c94dd11de  jmp 0x0000794C94DCF7EE
0000794c94dd11e3  call 0x0000794C94BFF430
0000794c94dd11e8  jmp 0x0000794C94DCF801
0000794c94dd11ed  sub rsp, 0x08
0000794c94dd11f1  push rax
0000794c94dd11f2  push rcx
0000794c94dd11f3  push rdx
0000794c94dd11f4  push rdi
0000794c94dd11f5  push rsi
0000794c94dd11f6  push r8
0000794c94dd11f8  push r9
0000794c94dd11fa  push r10
0000794c94dd11fc  push r11
0000794c94dd11fe  sub rsp, 0xF0
0000794c94dd1205  vmovaps [rsp], xmm0
0000794c94dd120a  vmovaps [rsp+0x10], xmm2
0000794c94dd1210  vmovaps [rsp+0x20], xmm3
0000794c94dd1216  vmovaps [rsp+0x30], xmm4
0000794c94dd121c  vmovaps [rsp+0x40], xmm5
0000794c94dd1222  vmovaps [rsp+0x50], xmm6
0000794c94dd1228  vmovaps [rsp+0x60], xmm7
0000794c94dd122e  vmovaps [rsp+0x70], xmm8
0000794c94dd1234  vmovaps [rsp+0x80], xmm9
0000794c94dd123d  vmovaps [rsp+0x90], xmm10
0000794c94dd1246  vmovaps [rsp+0xA0], xmm11
0000794c94dd124f  vmovaps [rsp+0xB0], xmm12
0000794c94dd1258  vmovaps [rsp+0xC0], xmm13
0000794c94dd1261  vmovaps [rsp+0xD0], xmm14
0000794c94dd126a  vmovaps [rsp+0xE0], xmm15
0000794c94dd1273  sub rsp, 0x30
0000794c94dd1277  movaps [rsp], xmm1
0000794c94dd127b  movaps [rsp+0x10], xmm13
0000794c94dd1281  movaps [rsp+0x20], xmm2
0000794c94dd1286  lea rdi, [rsp]
0000794c94dd128a  mov esi, 0x00
0000794c94dd128f  mov rax, 0x5AB2B8B81530
0000794c94dd1299  call rax
0000794c94dd129b  movaps xmm1, [rsp]
0000794c94dd129f  add rsp, 0x30
0000794c94dd12a3  vmovaps xmm0, [rsp]
0000794c94dd12a8  vmovaps xmm2, [rsp+0x10]
0000794c94dd12ae  vmovaps xmm3, [rsp+0x20]
0000794c94dd12b4  vmovaps xmm4, [rsp+0x30]
0000794c94dd12ba  vmovaps xmm5, [rsp+0x40]
0000794c94dd12c0  vmovaps xmm6, [rsp+0x50]
0000794c94dd12c6  vmovaps xmm7, [rsp+0x60]
0000794c94dd12cc  vmovaps xmm8, [rsp+0x70]
0000794c94dd12d2  vmovaps xmm9, [rsp+0x80]
0000794c94dd12db  vmovaps xmm10, [rsp+0x90]
0000794c94dd12e4  vmovaps xmm11, [rsp+0xA0]
0000794c94dd12ed  vmovaps xmm12, [rsp+0xB0]
0000794c94dd12f6  vmovaps xmm13, [rsp+0xC0]
0000794c94dd12ff  vmovaps xmm14, [rsp+0xD0]
0000794c94dd1308  vmovaps xmm15, [rsp+0xE0]
0000794c94dd1311  add rsp, 0xF0
0000794c94dd1318  pop r11
0000794c94dd131a  pop r10
0000794c94dd131c  pop r9
0000794c94dd131e  pop r8
0000794c94dd1320  pop rsi
0000794c94dd1321  pop rdi
0000794c94dd1322  pop rdx
0000794c94dd1323  pop rcx
0000794c94dd1324  pop rax
0000794c94dd1325  add rsp, 0x08
0000794c94dd1329  jmp 0x0000794C94DCF82C
0000794c94dd132e  call 0x0000794C94C0E760
0000794c94dd1333  jmp 0x0000794C94DCF839
0000794c94dd1338  sub rsp, 0x08
0000794c94dd133c  push rax
0000794c94dd133d  push rcx
0000794c94dd133e  push rdx
0000794c94dd133f  push rdi
0000794c94dd1340  push rsi
0000794c94dd1341  push r8
0000794c94dd1343  push r9
0000794c94dd1345  push r10
0000794c94dd1347  push r11
0000794c94dd1349  sub rsp, 0xF0
0000794c94dd1350  vmovaps [rsp], xmm0
0000794c94dd1355  vmovaps [rsp+0x10], xmm1
0000794c94dd135b  vmovaps [rsp+0x20], xmm2
0000794c94dd1361  vmovaps [rsp+0x30], xmm3
0000794c94dd1367  vmovaps [rsp+0x40], xmm4
0000794c94dd136d  vmovaps [rsp+0x50], xmm5
0000794c94dd1373  vmovaps [rsp+0x60], xmm6
0000794c94dd1379  vmovaps [rsp+0x70], xmm7
0000794c94dd137f  vmovaps [rsp+0x80], xmm8
0000794c94dd1388  vmovaps [rsp+0x90], xmm9
0000794c94dd1391  vmovaps [rsp+0xA0], xmm10
0000794c94dd139a  vmovaps [rsp+0xB0], xmm11
0000794c94dd13a3  vmovaps [rsp+0xC0], xmm12
0000794c94dd13ac  vmovaps [rsp+0xD0], xmm14
0000794c94dd13b5  vmovaps [rsp+0xE0], xmm15
0000794c94dd13be  sub rsp, 0x30
0000794c94dd13c2  movaps [rsp], xmm13
0000794c94dd13c7  movaps [rsp+0x10], xmm2
0000794c94dd13cc  movaps [rsp+0x20], xmm1
0000794c94dd13d1  lea rdi, [rsp]
0000794c94dd13d5  mov esi, 0x00
0000794c94dd13da  mov rax, 0x5AB2B8B81530
0000794c94dd13e4  call rax
0000794c94dd13e6  movaps xmm13, [rsp]
0000794c94dd13eb  add rsp, 0x30
0000794c94dd13ef  vmovaps xmm0, [rsp]
0000794c94dd13f4  vmovaps xmm1, [rsp+0x10]
0000794c94dd13fa  vmovaps xmm2, [rsp+0x20]
0000794c94dd1400  vmovaps xmm3, [rsp+0x30]
0000794c94dd1406  vmovaps xmm4, [rsp+0x40]
0000794c94dd140c  vmovaps xmm5, [rsp+0x50]
0000794c94dd1412  vmovaps xmm6, [rsp+0x60]
0000794c94dd1418  vmovaps xmm7, [rsp+0x70]
0000794c94dd141e  vmovaps xmm8, [rsp+0x80]
0000794c94dd1427  vmovaps xmm9, [rsp+0x90]
0000794c94dd1430  vmovaps xmm10, [rsp+0xA0]
0000794c94dd1439  vmovaps xmm11, [rsp+0xB0]
0000794c94dd1442  vmovaps xmm12, [rsp+0xC0]
0000794c94dd144b  vmovaps xmm14, [rsp+0xD0]
0000794c94dd1454  vmovaps xmm15, [rsp+0xE0]
0000794c94dd145d  add rsp, 0xF0
0000794c94dd1464  pop r11
0000794c94dd1466  pop r10
0000794c94dd1468  pop r9
0000794c94dd146a  pop r8
0000794c94dd146c  pop rsi
0000794c94dd146d  pop rdi
0000794c94dd146e  pop rdx
0000794c94dd146f  pop rcx
0000794c94dd1470  pop rax
0000794c94dd1471  add rsp, 0x08
0000794c94dd1475  jmp 0x0000794C94DCF878
0000794c94dd147a  sub rsp, 0x08
0000794c94dd147e  push rax
0000794c94dd147f  push rcx
0000794c94dd1480  push rdx
0000794c94dd1481  push rdi
0000794c94dd1482  push rsi
0000794c94dd1483  push r8
0000794c94dd1485  push r9
0000794c94dd1487  push r10
0000794c94dd1489  push r11
0000794c94dd148b  sub rsp, 0xF0
0000794c94dd1492  vmovaps [rsp], xmm0
0000794c94dd1497  vmovaps [rsp+0x10], xmm2
0000794c94dd149d  vmovaps [rsp+0x20], xmm3
0000794c94dd14a3  vmovaps [rsp+0x30], xmm4
0000794c94dd14a9  vmovaps [rsp+0x40], xmm5
0000794c94dd14af  vmovaps [rsp+0x50], xmm6
0000794c94dd14b5  vmovaps [rsp+0x60], xmm7
0000794c94dd14bb  vmovaps [rsp+0x70], xmm8
0000794c94dd14c1  vmovaps [rsp+0x80], xmm9
0000794c94dd14ca  vmovaps [rsp+0x90], xmm10
0000794c94dd14d3  vmovaps [rsp+0xA0], xmm11
0000794c94dd14dc  vmovaps [rsp+0xB0], xmm12
0000794c94dd14e5  vmovaps [rsp+0xC0], xmm13
0000794c94dd14ee  vmovaps [rsp+0xD0], xmm14
0000794c94dd14f7  vmovaps [rsp+0xE0], xmm15
0000794c94dd1500  sub rsp, 0x30
0000794c94dd1504  movaps [rsp], xmm1
0000794c94dd1508  movaps [rsp+0x10], xmm15
0000794c94dd150e  movaps [rsp+0x20], xmm2
0000794c94dd1513  lea rdi, [rsp]
0000794c94dd1517  mov esi, 0x00
0000794c94dd151c  mov rax, 0x5AB2B8B81530
0000794c94dd1526  call rax
0000794c94dd1528  movaps xmm1, [rsp]
0000794c94dd152c  add rsp, 0x30
0000794c94dd1530  vmovaps xmm0, [rsp]
0000794c94dd1535  vmovaps xmm2, [rsp+0x10]
0000794c94dd153b  vmovaps xmm3, [rsp+0x20]
0000794c94dd1541  vmovaps xmm4, [rsp+0x30]
0000794c94dd1547  vmovaps xmm5, [rsp+0x40]
0000794c94dd154d  vmovaps xmm6, [rsp+0x50]
0000794c94dd1553  vmovaps xmm7, [rsp+0x60]
0000794c94dd1559  vmovaps xmm8, [rsp+0x70]
0000794c94dd155f  vmovaps xmm9, [rsp+0x80]
0000794c94dd1568  vmovaps xmm10, [rsp+0x90]
0000794c94dd1571  vmovaps xmm11, [rsp+0xA0]
0000794c94dd157a  vmovaps xmm12, [rsp+0xB0]
0000794c94dd1583  vmovaps xmm13, [rsp+0xC0]
0000794c94dd158c  vmovaps xmm14, [rsp+0xD0]
0000794c94dd1595  vmovaps xmm15, [rsp+0xE0]
0000794c94dd159e  add rsp, 0xF0
0000794c94dd15a5  pop r11
0000794c94dd15a7  pop r10
0000794c94dd15a9  pop r9
0000794c94dd15ab  pop r8
0000794c94dd15ad  pop rsi
0000794c94dd15ae  pop rdi
0000794c94dd15af  pop rdx
0000794c94dd15b0  pop rcx
0000794c94dd15b1  pop rax
0000794c94dd15b2  add rsp, 0x08
0000794c94dd15b6  jmp 0x0000794C94DCF8AC
0000794c94dd15bb  sub rsp, 0x08
0000794c94dd15bf  push rax
0000794c94dd15c0  push rcx
0000794c94dd15c1  push rdx
0000794c94dd15c2  push rdi
0000794c94dd15c3  push rsi
0000794c94dd15c4  push r8
0000794c94dd15c6  push r9
0000794c94dd15c8  push r10
0000794c94dd15ca  push r11
0000794c94dd15cc  sub rsp, 0xF0
0000794c94dd15d3  vmovaps [rsp], xmm0
0000794c94dd15d8  vmovaps [rsp+0x10], xmm1
0000794c94dd15de  vmovaps [rsp+0x20], xmm2
0000794c94dd15e4  vmovaps [rsp+0x30], xmm3
0000794c94dd15ea  vmovaps [rsp+0x40], xmm4
0000794c94dd15f0  vmovaps [rsp+0x50], xmm5
0000794c94dd15f6  vmovaps [rsp+0x60], xmm6
0000794c94dd15fc  vmovaps [rsp+0x70], xmm7
0000794c94dd1602  vmovaps [rsp+0x80], xmm8
0000794c94dd160b  vmovaps [rsp+0x90], xmm9
0000794c94dd1614  vmovaps [rsp+0xA0], xmm10
0000794c94dd161d  vmovaps [rsp+0xB0], xmm11
0000794c94dd1626  vmovaps [rsp+0xC0], xmm12
0000794c94dd162f  vmovaps [rsp+0xD0], xmm13
0000794c94dd1638  vmovaps [rsp+0xE0], xmm15
0000794c94dd1641  sub rsp, 0x30
0000794c94dd1645  movaps [rsp], xmm14
0000794c94dd164a  movaps [rsp+0x10], xmm2
0000794c94dd164f  movaps [rsp+0x20], xmm15
0000794c94dd1655  lea rdi, [rsp]
0000794c94dd1659  mov esi, 0x00
0000794c94dd165e  mov rax, 0x5AB2B8B81530
0000794c94dd1668  call rax
0000794c94dd166a  movaps xmm14, [rsp]
0000794c94dd166f  add rsp, 0x30
0000794c94dd1673  vmovaps xmm0, [rsp]
0000794c94dd1678  vmovaps xmm1, [rsp+0x10]
0000794c94dd167e  vmovaps xmm2, [rsp+0x20]
0000794c94dd1684  vmovaps xmm3, [rsp+0x30]
0000794c94dd168a  vmovaps xmm4, [rsp+0x40]
0000794c94dd1690  vmovaps xmm5, [rsp+0x50]
0000794c94dd1696  vmovaps xmm6, [rsp+0x60]
0000794c94dd169c  vmovaps xmm7, [rsp+0x70]
0000794c94dd16a2  vmovaps xmm8, [rsp+0x80]
0000794c94dd16ab  vmovaps xmm9, [rsp+0x90]
0000794c94dd16b4  vmovaps xmm10, [rsp+0xA0]
0000794c94dd16bd  vmovaps xmm11, [rsp+0xB0]
0000794c94dd16c6  vmovaps xmm12, [rsp+0xC0]
0000794c94dd16cf  vmovaps xmm13, [rsp+0xD0]
0000794c94dd16d8  vmovaps xmm15, [rsp+0xE0]
0000794c94dd16e1  add rsp, 0xF0
0000794c94dd16e8  pop r11
0000794c94dd16ea  pop r10
0000794c94dd16ec  pop r9
0000794c94dd16ee  pop r8
0000794c94dd16f0  pop rsi
0000794c94dd16f1  pop rdi
0000794c94dd16f2  pop rdx
0000794c94dd16f3  pop rcx
0000794c94dd16f4  pop rax
0000794c94dd16f5  add rsp, 0x08
0000794c94dd16f9  jmp 0x0000794C94DCF8E7
0000794c94dd16fe  sub rsp, 0x08
0000794c94dd1702  push rax
0000794c94dd1703  push rcx
0000794c94dd1704  push rdx
0000794c94dd1705  push rdi
0000794c94dd1706  push rsi
0000794c94dd1707  push r8
0000794c94dd1709  push r9
0000794c94dd170b  push r10
0000794c94dd170d  push r11
0000794c94dd170f  sub rsp, 0xF0
0000794c94dd1716  vmovaps [rsp], xmm0
0000794c94dd171b  vmovaps [rsp+0x10], xmm1
0000794c94dd1721  vmovaps [rsp+0x20], xmm2
0000794c94dd1727  vmovaps [rsp+0x30], xmm3
0000794c94dd172d  vmovaps [rsp+0x40], xmm4
0000794c94dd1733  vmovaps [rsp+0x50], xmm5
0000794c94dd1739  vmovaps [rsp+0x60], xmm6
0000794c94dd173f  vmovaps [rsp+0x70], xmm7
0000794c94dd1745  vmovaps [rsp+0x80], xmm8
0000794c94dd174e  vmovaps [rsp+0x90], xmm9
0000794c94dd1757  vmovaps [rsp+0xA0], xmm10
0000794c94dd1760  vmovaps [rsp+0xB0], xmm11
0000794c94dd1769  vmovaps [rsp+0xC0], xmm12
0000794c94dd1772  vmovaps [rsp+0xD0], xmm13
0000794c94dd177b  vmovaps [rsp+0xE0], xmm14
0000794c94dd1784  sub rsp, 0x30
0000794c94dd1788  movaps [rsp], xmm15
0000794c94dd178d  movaps [rsp+0x10], xmm2
0000794c94dd1792  movaps [rsp+0x20], xmm1
0000794c94dd1797  lea rdi, [rsp]
0000794c94dd179b  mov esi, 0x00
0000794c94dd17a0  mov rax, 0x5AB2B8B81530
0000794c94dd17aa  call rax
0000794c94dd17ac  movaps xmm15, [rsp]
0000794c94dd17b1  add rsp, 0x30
0000794c94dd17b5  vmovaps xmm0, [rsp]
0000794c94dd17ba  vmovaps xmm1, [rsp+0x10]
0000794c94dd17c0  vmovaps xmm2, [rsp+0x20]
0000794c94dd17c6  vmovaps xmm3, [rsp+0x30]
0000794c94dd17cc  vmovaps xmm4, [rsp+0x40]
0000794c94dd17d2  vmovaps xmm5, [rsp+0x50]
0000794c94dd17d8  vmovaps xmm6, [rsp+0x60]
0000794c94dd17de  vmovaps xmm7, [rsp+0x70]
0000794c94dd17e4  vmovaps xmm8, [rsp+0x80]
0000794c94dd17ed  vmovaps xmm9, [rsp+0x90]
0000794c94dd17f6  vmovaps xmm10, [rsp+0xA0]
0000794c94dd17ff  vmovaps xmm11, [rsp+0xB0]
0000794c94dd1808  vmovaps xmm12, [rsp+0xC0]
0000794c94dd1811  vmovaps xmm13, [rsp+0xD0]
0000794c94dd181a  vmovaps xmm14, [rsp+0xE0]
0000794c94dd1823  add rsp, 0xF0
0000794c94dd182a  pop r11
0000794c94dd182c  pop r10
0000794c94dd182e  pop r9
0000794c94dd1830  pop r8
0000794c94dd1832  pop rsi
0000794c94dd1833  pop rdi
0000794c94dd1834  pop rdx
0000794c94dd1835  pop rcx
0000794c94dd1836  pop rax
0000794c94dd1837  add rsp, 0x08
0000794c94dd183b  jmp 0x0000794C94DCF923
0000794c94dd1840  call 0x0000794C94BFF430
0000794c94dd1845  jmp 0x0000794C94DCF930
0000794c94dd184a  sub rsp, 0x08
0000794c94dd184e  push rax
0000794c94dd184f  push rcx
0000794c94dd1850  push rdx
0000794c94dd1851  push rdi
0000794c94dd1852  push rsi
0000794c94dd1853  push r8
0000794c94dd1855  push r9
0000794c94dd1857  push r10
0000794c94dd1859  push r11
0000794c94dd185b  sub rsp, 0xF0
0000794c94dd1862  vmovaps [rsp], xmm0
0000794c94dd1867  vmovaps [rsp+0x10], xmm1
0000794c94dd186d  vmovaps [rsp+0x20], xmm3
0000794c94dd1873  vmovaps [rsp+0x30], xmm4
0000794c94dd1879  vmovaps [rsp+0x40], xmm5
0000794c94dd187f  vmovaps [rsp+0x50], xmm6
0000794c94dd1885  vmovaps [rsp+0x60], xmm7
0000794c94dd188b  vmovaps [rsp+0x70], xmm8
0000794c94dd1891  vmovaps [rsp+0x80], xmm9
0000794c94dd189a  vmovaps [rsp+0x90], xmm10
0000794c94dd18a3  vmovaps [rsp+0xA0], xmm11
0000794c94dd18ac  vmovaps [rsp+0xB0], xmm12
0000794c94dd18b5  vmovaps [rsp+0xC0], xmm13
0000794c94dd18be  vmovaps [rsp+0xD0], xmm14
0000794c94dd18c7  vmovaps [rsp+0xE0], xmm15
0000794c94dd18d0  sub rsp, 0x30
0000794c94dd18d4  movaps [rsp], xmm2
0000794c94dd18d8  movaps [rsp+0x10], xmm1
0000794c94dd18dd  movaps [rsp+0x20], xmm14
0000794c94dd18e3  lea rdi, [rsp]
0000794c94dd18e7  mov esi, 0x00
0000794c94dd18ec  mov rax, 0x5AB2B8B81530
0000794c94dd18f6  call rax
0000794c94dd18f8  movaps xmm2, [rsp]
0000794c94dd18fc  add rsp, 0x30
0000794c94dd1900  vmovaps xmm0, [rsp]
0000794c94dd1905  vmovaps xmm1, [rsp+0x10]
0000794c94dd190b  vmovaps xmm3, [rsp+0x20]
0000794c94dd1911  vmovaps xmm4, [rsp+0x30]
0000794c94dd1917  vmovaps xmm5, [rsp+0x40]
0000794c94dd191d  vmovaps xmm6, [rsp+0x50]
0000794c94dd1923  vmovaps xmm7, [rsp+0x60]
0000794c94dd1929  vmovaps xmm8, [rsp+0x70]
0000794c94dd192f  vmovaps xmm9, [rsp+0x80]
0000794c94dd1938  vmovaps xmm10, [rsp+0x90]
0000794c94dd1941  vmovaps xmm11, [rsp+0xA0]
0000794c94dd194a  vmovaps xmm12, [rsp+0xB0]
0000794c94dd1953  vmovaps xmm13, [rsp+0xC0]
0000794c94dd195c  vmovaps xmm14, [rsp+0xD0]
0000794c94dd1965  vmovaps xmm15, [rsp+0xE0]
0000794c94dd196e  add rsp, 0xF0
0000794c94dd1975  pop r11
0000794c94dd1977  pop r10
0000794c94dd1979  pop r9
0000794c94dd197b  pop r8
0000794c94dd197d  pop rsi
0000794c94dd197e  pop rdi
0000794c94dd197f  pop rdx
0000794c94dd1980  pop rcx
0000794c94dd1981  pop rax
0000794c94dd1982  add rsp, 0x08
0000794c94dd1986  jmp 0x0000794C94DCF96D
0000794c94dd198b  sub rsp, 0x08
0000794c94dd198f  push rax
0000794c94dd1990  push rcx
0000794c94dd1991  push rdx
0000794c94dd1992  push rdi
0000794c94dd1993  push rsi
0000794c94dd1994  push r8
0000794c94dd1996  push r9
0000794c94dd1998  push r10
0000794c94dd199a  push r11
0000794c94dd199c  sub rsp, 0xF0
0000794c94dd19a3  vmovaps [rsp], xmm0
0000794c94dd19a8  vmovaps [rsp+0x10], xmm1
0000794c94dd19ae  vmovaps [rsp+0x20], xmm2
0000794c94dd19b4  vmovaps [rsp+0x30], xmm3
0000794c94dd19ba  vmovaps [rsp+0x40], xmm4
0000794c94dd19c0  vmovaps [rsp+0x50], xmm5
0000794c94dd19c6  vmovaps [rsp+0x60], xmm6
0000794c94dd19cc  vmovaps [rsp+0x70], xmm7
0000794c94dd19d2  vmovaps [rsp+0x80], xmm8
0000794c94dd19db  vmovaps [rsp+0x90], xmm9
0000794c94dd19e4  vmovaps [rsp+0xA0], xmm10
0000794c94dd19ed  vmovaps [rsp+0xB0], xmm11
0000794c94dd19f6  vmovaps [rsp+0xC0], xmm12
0000794c94dd19ff  vmovaps [rsp+0xD0], xmm13
0000794c94dd1a08  vmovaps [rsp+0xE0], xmm14
0000794c94dd1a11  sub rsp, 0x30
0000794c94dd1a15  movaps [rsp], xmm15
0000794c94dd1a1a  movaps [rsp+0x10], xmm14
0000794c94dd1a20  movaps [rsp+0x20], xmm1
0000794c94dd1a25  lea rdi, [rsp]
0000794c94dd1a29  mov esi, 0x00
0000794c94dd1a2e  mov rax, 0x5AB2B8B81530
0000794c94dd1a38  call rax
0000794c94dd1a3a  movaps xmm15, [rsp]
0000794c94dd1a3f  add rsp, 0x30
0000794c94dd1a43  vmovaps xmm0, [rsp]
0000794c94dd1a48  vmovaps xmm1, [rsp+0x10]
0000794c94dd1a4e  vmovaps xmm2, [rsp+0x20]
0000794c94dd1a54  vmovaps xmm3, [rsp+0x30]
0000794c94dd1a5a  vmovaps xmm4, [rsp+0x40]
0000794c94dd1a60  vmovaps xmm5, [rsp+0x50]
0000794c94dd1a66  vmovaps xmm6, [rsp+0x60]
0000794c94dd1a6c  vmovaps xmm7, [rsp+0x70]
0000794c94dd1a72  vmovaps xmm8, [rsp+0x80]
0000794c94dd1a7b  vmovaps xmm9, [rsp+0x90]
0000794c94dd1a84  vmovaps xmm10, [rsp+0xA0]
0000794c94dd1a8d  vmovaps xmm11, [rsp+0xB0]
0000794c94dd1a96  vmovaps xmm12, [rsp+0xC0]
0000794c94dd1a9f  vmovaps xmm13, [rsp+0xD0]
0000794c94dd1aa8  vmovaps xmm14, [rsp+0xE0]
0000794c94dd1ab1  add rsp, 0xF0
0000794c94dd1ab8  pop r11
0000794c94dd1aba  pop r10
0000794c94dd1abc  pop r9
0000794c94dd1abe  pop r8
0000794c94dd1ac0  pop rsi
0000794c94dd1ac1  pop rdi
0000794c94dd1ac2  pop rdx
0000794c94dd1ac3  pop rcx
0000794c94dd1ac4  pop rax
0000794c94dd1ac5  add rsp, 0x08
0000794c94dd1ac9  jmp 0x0000794C94DCF9E7
0000794c94dd1ace  call 0x0000794C94BFF430
0000794c94dd1ad3  jmp 0x0000794C94DCF9F4
0000794c94dd1ad8  sub rsp, 0x08
0000794c94dd1adc  push rax
0000794c94dd1add  push rcx
0000794c94dd1ade  push rdx
0000794c94dd1adf  push rdi
0000794c94dd1ae0  push rsi
0000794c94dd1ae1  push r8
0000794c94dd1ae3  push r9
0000794c94dd1ae5  push r10
0000794c94dd1ae7  push r11
0000794c94dd1ae9  sub rsp, 0xF0
0000794c94dd1af0  vmovaps [rsp], xmm0
0000794c94dd1af5  vmovaps [rsp+0x10], xmm1
0000794c94dd1afb  vmovaps [rsp+0x20], xmm2
0000794c94dd1b01  vmovaps [rsp+0x30], xmm3
0000794c94dd1b07  vmovaps [rsp+0x40], xmm4
0000794c94dd1b0d  vmovaps [rsp+0x50], xmm5
0000794c94dd1b13  vmovaps [rsp+0x60], xmm6
0000794c94dd1b19  vmovaps [rsp+0x70], xmm7
0000794c94dd1b1f  vmovaps [rsp+0x80], xmm8
0000794c94dd1b28  vmovaps [rsp+0x90], xmm9
0000794c94dd1b31  vmovaps [rsp+0xA0], xmm10
0000794c94dd1b3a  vmovaps [rsp+0xB0], xmm11
0000794c94dd1b43  vmovaps [rsp+0xC0], xmm12
0000794c94dd1b4c  vmovaps [rsp+0xD0], xmm13
0000794c94dd1b55  vmovaps [rsp+0xE0], xmm15
0000794c94dd1b5e  sub rsp, 0x30
0000794c94dd1b62  movaps [rsp], xmm14
0000794c94dd1b67  movaps [rsp+0x10], xmm13
0000794c94dd1b6d  movaps [rsp+0x20], xmm1
0000794c94dd1b72  lea rdi, [rsp]
0000794c94dd1b76  mov esi, 0x00
0000794c94dd1b7b  mov rax, 0x5AB2B8B81530
0000794c94dd1b85  call rax
0000794c94dd1b87  movaps xmm14, [rsp]
0000794c94dd1b8c  add rsp, 0x30
0000794c94dd1b90  vmovaps xmm0, [rsp]
0000794c94dd1b95  vmovaps xmm1, [rsp+0x10]
0000794c94dd1b9b  vmovaps xmm2, [rsp+0x20]
0000794c94dd1ba1  vmovaps xmm3, [rsp+0x30]
0000794c94dd1ba7  vmovaps xmm4, [rsp+0x40]
0000794c94dd1bad  vmovaps xmm5, [rsp+0x50]
0000794c94dd1bb3  vmovaps xmm6, [rsp+0x60]
0000794c94dd1bb9  vmovaps xmm7, [rsp+0x70]
0000794c94dd1bbf  vmovaps xmm8, [rsp+0x80]
0000794c94dd1bc8  vmovaps xmm9, [rsp+0x90]
0000794c94dd1bd1  vmovaps xmm10, [rsp+0xA0]
0000794c94dd1bda  vmovaps xmm11, [rsp+0xB0]
0000794c94dd1be3  vmovaps xmm12, [rsp+0xC0]
0000794c94dd1bec  vmovaps xmm13, [rsp+0xD0]
0000794c94dd1bf5  vmovaps xmm15, [rsp+0xE0]
0000794c94dd1bfe  add rsp, 0xF0
0000794c94dd1c05  pop r11
0000794c94dd1c07  pop r10
0000794c94dd1c09  pop r9
0000794c94dd1c0b  pop r8
0000794c94dd1c0d  pop rsi
0000794c94dd1c0e  pop rdi
0000794c94dd1c0f  pop rdx
0000794c94dd1c10  pop rcx
0000794c94dd1c11  pop rax
0000794c94dd1c12  add rsp, 0x08
0000794c94dd1c16  jmp 0x0000794C94DCFAAF
0000794c94dd1c1b  sub rsp, 0x08
0000794c94dd1c1f  push rax
0000794c94dd1c20  push rcx
0000794c94dd1c21  push rdx
0000794c94dd1c22  push rdi
0000794c94dd1c23  push rsi
0000794c94dd1c24  push r8
0000794c94dd1c26  push r9
0000794c94dd1c28  push r10
0000794c94dd1c2a  push r11
0000794c94dd1c2c  sub rsp, 0xF0
0000794c94dd1c33  vmovaps [rsp], xmm0
0000794c94dd1c38  vmovaps [rsp+0x10], xmm1
0000794c94dd1c3e  vmovaps [rsp+0x20], xmm2
0000794c94dd1c44  vmovaps [rsp+0x30], xmm3
0000794c94dd1c4a  vmovaps [rsp+0x40], xmm4
0000794c94dd1c50  vmovaps [rsp+0x50], xmm5
0000794c94dd1c56  vmovaps [rsp+0x60], xmm6
0000794c94dd1c5c  vmovaps [rsp+0x70], xmm7
0000794c94dd1c62  vmovaps [rsp+0x80], xmm8
0000794c94dd1c6b  vmovaps [rsp+0x90], xmm9
0000794c94dd1c74  vmovaps [rsp+0xA0], xmm10
0000794c94dd1c7d  vmovaps [rsp+0xB0], xmm11
0000794c94dd1c86  vmovaps [rsp+0xC0], xmm12
0000794c94dd1c8f  vmovaps [rsp+0xD0], xmm13
0000794c94dd1c98  vmovaps [rsp+0xE0], xmm14
0000794c94dd1ca1  sub rsp, 0x30
0000794c94dd1ca5  movaps [rsp], xmm15
0000794c94dd1caa  movaps [rsp+0x10], xmm13
0000794c94dd1cb0  movaps [rsp+0x20], xmm1
0000794c94dd1cb5  lea rdi, [rsp]
0000794c94dd1cb9  mov esi, 0x00
0000794c94dd1cbe  mov rax, 0x5AB2B8B81530
0000794c94dd1cc8  call rax
0000794c94dd1cca  movaps xmm15, [rsp]
0000794c94dd1ccf  add rsp, 0x30
0000794c94dd1cd3  vmovaps xmm0, [rsp]
0000794c94dd1cd8  vmovaps xmm1, [rsp+0x10]
0000794c94dd1cde  vmovaps xmm2, [rsp+0x20]
0000794c94dd1ce4  vmovaps xmm3, [rsp+0x30]
0000794c94dd1cea  vmovaps xmm4, [rsp+0x40]
0000794c94dd1cf0  vmovaps xmm5, [rsp+0x50]
0000794c94dd1cf6  vmovaps xmm6, [rsp+0x60]
0000794c94dd1cfc  vmovaps xmm7, [rsp+0x70]
0000794c94dd1d02  vmovaps xmm8, [rsp+0x80]
0000794c94dd1d0b  vmovaps xmm9, [rsp+0x90]
0000794c94dd1d14  vmovaps xmm10, [rsp+0xA0]
0000794c94dd1d1d  vmovaps xmm11, [rsp+0xB0]
0000794c94dd1d26  vmovaps xmm12, [rsp+0xC0]
0000794c94dd1d2f  vmovaps xmm13, [rsp+0xD0]
0000794c94dd1d38  vmovaps xmm14, [rsp+0xE0]
0000794c94dd1d41  add rsp, 0xF0
0000794c94dd1d48  pop r11
0000794c94dd1d4a  pop r10
0000794c94dd1d4c  pop r9
0000794c94dd1d4e  pop r8
0000794c94dd1d50  pop rsi
0000794c94dd1d51  pop rdi
0000794c94dd1d52  pop rdx
0000794c94dd1d53  pop rcx
0000794c94dd1d54  pop rax
0000794c94dd1d55  add rsp, 0x08
0000794c94dd1d59  jmp 0x0000794C94DCFAEB
0000794c94dd1d5e  call 0x0000794C94BFF430
0000794c94dd1d63  jmp 0x0000794C94DCFAF8
0000794c94dd1d68  sub rsp, 0x08
0000794c94dd1d6c  push rax
0000794c94dd1d6d  push rcx
0000794c94dd1d6e  push rdx
0000794c94dd1d6f  push rdi
0000794c94dd1d70  push rsi
0000794c94dd1d71  push r8
0000794c94dd1d73  push r9
0000794c94dd1d75  push r10
0000794c94dd1d77  push r11
0000794c94dd1d79  sub rsp, 0xF0
0000794c94dd1d80  vmovaps [rsp], xmm0
0000794c94dd1d85  vmovaps [rsp+0x10], xmm1
0000794c94dd1d8b  vmovaps [rsp+0x20], xmm2
0000794c94dd1d91  vmovaps [rsp+0x30], xmm3
0000794c94dd1d97  vmovaps [rsp+0x40], xmm4
0000794c94dd1d9d  vmovaps [rsp+0x50], xmm5
0000794c94dd1da3  vmovaps [rsp+0x60], xmm6
0000794c94dd1da9  vmovaps [rsp+0x70], xmm7
0000794c94dd1daf  vmovaps [rsp+0x80], xmm8
0000794c94dd1db8  vmovaps [rsp+0x90], xmm9
0000794c94dd1dc1  vmovaps [rsp+0xA0], xmm10
0000794c94dd1dca  vmovaps [rsp+0xB0], xmm11
0000794c94dd1dd3  vmovaps [rsp+0xC0], xmm12
0000794c94dd1ddc  vmovaps [rsp+0xD0], xmm13
0000794c94dd1de5  vmovaps [rsp+0xE0], xmm15
0000794c94dd1dee  sub rsp, 0x30
0000794c94dd1df2  movaps [rsp], xmm14
0000794c94dd1df7  movaps [rsp+0x10], xmm13
0000794c94dd1dfd  movaps [rsp+0x20], xmm2
0000794c94dd1e02  lea rdi, [rsp]
0000794c94dd1e06  mov esi, 0x00
0000794c94dd1e0b  mov rax, 0x5AB2B8B81530
0000794c94dd1e15  call rax
0000794c94dd1e17  movaps xmm14, [rsp]
0000794c94dd1e1c  add rsp, 0x30
0000794c94dd1e20  vmovaps xmm0, [rsp]
0000794c94dd1e25  vmovaps xmm1, [rsp+0x10]
0000794c94dd1e2b  vmovaps xmm2, [rsp+0x20]
0000794c94dd1e31  vmovaps xmm3, [rsp+0x30]
0000794c94dd1e37  vmovaps xmm4, [rsp+0x40]
0000794c94dd1e3d  vmovaps xmm5, [rsp+0x50]
0000794c94dd1e43  vmovaps xmm6, [rsp+0x60]
0000794c94dd1e49  vmovaps xmm7, [rsp+0x70]
0000794c94dd1e4f  vmovaps xmm8, [rsp+0x80]
0000794c94dd1e58  vmovaps xmm9, [rsp+0x90]
0000794c94dd1e61  vmovaps xmm10, [rsp+0xA0]
0000794c94dd1e6a  vmovaps xmm11, [rsp+0xB0]
0000794c94dd1e73  vmovaps xmm12, [rsp+0xC0]
0000794c94dd1e7c  vmovaps xmm13, [rsp+0xD0]
0000794c94dd1e85  vmovaps xmm15, [rsp+0xE0]
0000794c94dd1e8e  add rsp, 0xF0
0000794c94dd1e95  pop r11
0000794c94dd1e97  pop r10
0000794c94dd1e99  pop r9
0000794c94dd1e9b  pop r8
0000794c94dd1e9d  pop rsi
0000794c94dd1e9e  pop rdi
0000794c94dd1e9f  pop rdx
0000794c94dd1ea0  pop rcx
0000794c94dd1ea1  pop rax
0000794c94dd1ea2  add rsp, 0x08
0000794c94dd1ea6  jmp 0x0000794C94DCFB24
0000794c94dd1eab  sub rsp, 0x08
0000794c94dd1eaf  push rax
0000794c94dd1eb0  push rcx
0000794c94dd1eb1  push rdx
0000794c94dd1eb2  push rdi
0000794c94dd1eb3  push rsi
0000794c94dd1eb4  push r8
0000794c94dd1eb6  push r9
0000794c94dd1eb8  push r10
0000794c94dd1eba  push r11
0000794c94dd1ebc  sub rsp, 0xF0
0000794c94dd1ec3  vmovaps [rsp], xmm0
0000794c94dd1ec8  vmovaps [rsp+0x10], xmm2
0000794c94dd1ece  vmovaps [rsp+0x20], xmm3
0000794c94dd1ed4  vmovaps [rsp+0x30], xmm4
0000794c94dd1eda  vmovaps [rsp+0x40], xmm5
0000794c94dd1ee0  vmovaps [rsp+0x50], xmm6
0000794c94dd1ee6  vmovaps [rsp+0x60], xmm7
0000794c94dd1eec  vmovaps [rsp+0x70], xmm8
0000794c94dd1ef2  vmovaps [rsp+0x80], xmm9
0000794c94dd1efb  vmovaps [rsp+0x90], xmm10
0000794c94dd1f04  vmovaps [rsp+0xA0], xmm11
0000794c94dd1f0d  vmovaps [rsp+0xB0], xmm12
0000794c94dd1f16  vmovaps [rsp+0xC0], xmm13
0000794c94dd1f1f  vmovaps [rsp+0xD0], xmm14
0000794c94dd1f28  vmovaps [rsp+0xE0], xmm15
0000794c94dd1f31  sub rsp, 0x30
0000794c94dd1f35  movaps [rsp], xmm1
0000794c94dd1f39  movaps [rsp+0x10], xmm13
0000794c94dd1f3f  movaps [rsp+0x20], xmm2
0000794c94dd1f44  lea rdi, [rsp]
0000794c94dd1f48  mov esi, 0x00
0000794c94dd1f4d  mov rax, 0x5AB2B8B81530
0000794c94dd1f57  call rax
0000794c94dd1f59  movaps xmm1, [rsp]
0000794c94dd1f5d  add rsp, 0x30
0000794c94dd1f61  vmovaps xmm0, [rsp]
0000794c94dd1f66  vmovaps xmm2, [rsp+0x10]
0000794c94dd1f6c  vmovaps xmm3, [rsp+0x20]
0000794c94dd1f72  vmovaps xmm4, [rsp+0x30]
0000794c94dd1f78  vmovaps xmm5, [rsp+0x40]
0000794c94dd1f7e  vmovaps xmm6, [rsp+0x50]
0000794c94dd1f84  vmovaps xmm7, [rsp+0x60]
0000794c94dd1f8a  vmovaps xmm8, [rsp+0x70]
0000794c94dd1f90  vmovaps xmm9, [rsp+0x80]
0000794c94dd1f99  vmovaps xmm10, [rsp+0x90]
0000794c94dd1fa2  vmovaps xmm11, [rsp+0xA0]
0000794c94dd1fab  vmovaps xmm12, [rsp+0xB0]
0000794c94dd1fb4  vmovaps xmm13, [rsp+0xC0]
0000794c94dd1fbd  vmovaps xmm14, [rsp+0xD0]
0000794c94dd1fc6  vmovaps xmm15, [rsp+0xE0]
0000794c94dd1fcf  add rsp, 0xF0
0000794c94dd1fd6  pop r11
0000794c94dd1fd8  pop r10
0000794c94dd1fda  pop r9
0000794c94dd1fdc  pop r8
0000794c94dd1fde  pop rsi
0000794c94dd1fdf  pop rdi
0000794c94dd1fe0  pop rdx
0000794c94dd1fe1  pop rcx
0000794c94dd1fe2  pop rax
0000794c94dd1fe3  add rsp, 0x08
0000794c94dd1fe7  jmp 0x0000794C94DCFB52
0000794c94dd1fec  sub rsp, 0x08
0000794c94dd1ff0  push rax
0000794c94dd1ff1  push rcx
0000794c94dd1ff2  push rdx
0000794c94dd1ff3  push rdi
0000794c94dd1ff4  push rsi
0000794c94dd1ff5  push r8
0000794c94dd1ff7  push r9
0000794c94dd1ff9  push r10
0000794c94dd1ffb  push r11
0000794c94dd1ffd  sub rsp, 0xF0
0000794c94dd2004  vmovaps [rsp], xmm0
0000794c94dd2009  vmovaps [rsp+0x10], xmm1
0000794c94dd200f  vmovaps [rsp+0x20], xmm3
0000794c94dd2015  vmovaps [rsp+0x30], xmm4
0000794c94dd201b  vmovaps [rsp+0x40], xmm5
0000794c94dd2021  vmovaps [rsp+0x50], xmm6
0000794c94dd2027  vmovaps [rsp+0x60], xmm7
0000794c94dd202d  vmovaps [rsp+0x70], xmm8
0000794c94dd2033  vmovaps [rsp+0x80], xmm9
0000794c94dd203c  vmovaps [rsp+0x90], xmm10
0000794c94dd2045  vmovaps [rsp+0xA0], xmm11
0000794c94dd204e  vmovaps [rsp+0xB0], xmm12
0000794c94dd2057  vmovaps [rsp+0xC0], xmm13
0000794c94dd2060  vmovaps [rsp+0xD0], xmm14
0000794c94dd2069  vmovaps [rsp+0xE0], xmm15
0000794c94dd2072  sub rsp, 0x30
0000794c94dd2076  movaps [rsp], xmm2
0000794c94dd207a  movaps [rsp+0x10], xmm1
0000794c94dd207f  movaps [rsp+0x20], xmm13
0000794c94dd2085  lea rdi, [rsp]
0000794c94dd2089  mov esi, 0x00
0000794c94dd208e  mov rax, 0x5AB2B8B81530
0000794c94dd2098  call rax
0000794c94dd209a  movaps xmm2, [rsp]
0000794c94dd209e  add rsp, 0x30
0000794c94dd20a2  vmovaps xmm0, [rsp]
0000794c94dd20a7  vmovaps xmm1, [rsp+0x10]
0000794c94dd20ad  vmovaps xmm3, [rsp+0x20]
0000794c94dd20b3  vmovaps xmm4, [rsp+0x30]
0000794c94dd20b9  vmovaps xmm5, [rsp+0x40]
0000794c94dd20bf  vmovaps xmm6, [rsp+0x50]
0000794c94dd20c5  vmovaps xmm7, [rsp+0x60]
0000794c94dd20cb  vmovaps xmm8, [rsp+0x70]
0000794c94dd20d1  vmovaps xmm9, [rsp+0x80]
0000794c94dd20da  vmovaps xmm10, [rsp+0x90]
0000794c94dd20e3  vmovaps xmm11, [rsp+0xA0]
0000794c94dd20ec  vmovaps xmm12, [rsp+0xB0]
0000794c94dd20f5  vmovaps xmm13, [rsp+0xC0]
0000794c94dd20fe  vmovaps xmm14, [rsp+0xD0]
0000794c94dd2107  vmovaps xmm15, [rsp+0xE0]
0000794c94dd2110  add rsp, 0xF0
0000794c94dd2117  pop r11
0000794c94dd2119  pop r10
0000794c94dd211b  pop r9
0000794c94dd211d  pop r8
0000794c94dd211f  pop rsi
0000794c94dd2120  pop rdi
0000794c94dd2121  pop rdx
0000794c94dd2122  pop rcx
0000794c94dd2123  pop rax
0000794c94dd2124  add rsp, 0x08
0000794c94dd2128  jmp 0x0000794C94DCFBAB
0000794c94dd212d  call 0x0000794C94BFF430
0000794c94dd2132  jmp 0x0000794C94DCFBB8
0000794c94dd2137  sub rsp, 0x08
0000794c94dd213b  push rax
0000794c94dd213c  push rcx
0000794c94dd213d  push rdx
0000794c94dd213e  push rdi
0000794c94dd213f  push rsi
0000794c94dd2140  push r8
0000794c94dd2142  push r9
0000794c94dd2144  push r10
0000794c94dd2146  push r11
0000794c94dd2148  sub rsp, 0xF0
0000794c94dd214f  vmovaps [rsp], xmm0
0000794c94dd2154  vmovaps [rsp+0x10], xmm1
0000794c94dd215a  vmovaps [rsp+0x20], xmm2
0000794c94dd2160  vmovaps [rsp+0x30], xmm3
0000794c94dd2166  vmovaps [rsp+0x40], xmm4
0000794c94dd216c  vmovaps [rsp+0x50], xmm5
0000794c94dd2172  vmovaps [rsp+0x60], xmm6
0000794c94dd2178  vmovaps [rsp+0x70], xmm7
0000794c94dd217e  vmovaps [rsp+0x80], xmm8
0000794c94dd2187  vmovaps [rsp+0x90], xmm9
0000794c94dd2190  vmovaps [rsp+0xA0], xmm10
0000794c94dd2199  vmovaps [rsp+0xB0], xmm11
0000794c94dd21a2  vmovaps [rsp+0xC0], xmm12
0000794c94dd21ab  vmovaps [rsp+0xD0], xmm13
0000794c94dd21b4  vmovaps [rsp+0xE0], xmm14
0000794c94dd21bd  sub rsp, 0x30
0000794c94dd21c1  movaps [rsp], xmm15
0000794c94dd21c6  movaps [rsp+0x10], xmm13
0000794c94dd21cc  movaps [rsp+0x20], xmm1
0000794c94dd21d1  lea rdi, [rsp]
0000794c94dd21d5  mov esi, 0x00
0000794c94dd21da  mov rax, 0x5AB2B8B81530
0000794c94dd21e4  call rax
0000794c94dd21e6  movaps xmm15, [rsp]
0000794c94dd21eb  add rsp, 0x30
0000794c94dd21ef  vmovaps xmm0, [rsp]
0000794c94dd21f4  vmovaps xmm1, [rsp+0x10]
0000794c94dd21fa  vmovaps xmm2, [rsp+0x20]
0000794c94dd2200  vmovaps xmm3, [rsp+0x30]
0000794c94dd2206  vmovaps xmm4, [rsp+0x40]
0000794c94dd220c  vmovaps xmm5, [rsp+0x50]
0000794c94dd2212  vmovaps xmm6, [rsp+0x60]
0000794c94dd2218  vmovaps xmm7, [rsp+0x70]
0000794c94dd221e  vmovaps xmm8, [rsp+0x80]
0000794c94dd2227  vmovaps xmm9, [rsp+0x90]
0000794c94dd2230  vmovaps xmm10, [rsp+0xA0]
0000794c94dd2239  vmovaps xmm11, [rsp+0xB0]
0000794c94dd2242  vmovaps xmm12, [rsp+0xC0]
0000794c94dd224b  vmovaps xmm13, [rsp+0xD0]
0000794c94dd2254  vmovaps xmm14, [rsp+0xE0]
0000794c94dd225d  add rsp, 0xF0
0000794c94dd2264  pop r11
0000794c94dd2266  pop r10
0000794c94dd2268  pop r9
0000794c94dd226a  pop r8
0000794c94dd226c  pop rsi
0000794c94dd226d  pop rdi
0000794c94dd226e  pop rdx
0000794c94dd226f  pop rcx
0000794c94dd2270  pop rax
0000794c94dd2271  add rsp, 0x08
0000794c94dd2275  jmp 0x0000794C94DCFBF7
0000794c94dd227a  sub rsp, 0x08
0000794c94dd227e  push rax
0000794c94dd227f  push rcx
0000794c94dd2280  push rdx
0000794c94dd2281  push rdi
0000794c94dd2282  push rsi
0000794c94dd2283  push r8
0000794c94dd2285  push r9
0000794c94dd2287  push r10
0000794c94dd2289  push r11
0000794c94dd228b  sub rsp, 0xF0
0000794c94dd2292  vmovaps [rsp], xmm0
0000794c94dd2297  vmovaps [rsp+0x10], xmm1
0000794c94dd229d  vmovaps [rsp+0x20], xmm2
0000794c94dd22a3  vmovaps [rsp+0x30], xmm3
0000794c94dd22a9  vmovaps [rsp+0x40], xmm4
0000794c94dd22af  vmovaps [rsp+0x50], xmm5
0000794c94dd22b5  vmovaps [rsp+0x60], xmm6
0000794c94dd22bb  vmovaps [rsp+0x70], xmm7
0000794c94dd22c1  vmovaps [rsp+0x80], xmm8
0000794c94dd22ca  vmovaps [rsp+0x90], xmm9
0000794c94dd22d3  vmovaps [rsp+0xA0], xmm10
0000794c94dd22dc  vmovaps [rsp+0xB0], xmm11
0000794c94dd22e5  vmovaps [rsp+0xC0], xmm12
0000794c94dd22ee  vmovaps [rsp+0xD0], xmm13
0000794c94dd22f7  vmovaps [rsp+0xE0], xmm15
0000794c94dd2300  sub rsp, 0x30
0000794c94dd2304  movaps [rsp], xmm14
0000794c94dd2309  movaps [rsp+0x10], xmm11
0000794c94dd230f  movaps [rsp+0x20], xmm1
0000794c94dd2314  lea rdi, [rsp]
0000794c94dd2318  mov esi, 0x00
0000794c94dd231d  mov rax, 0x5AB2B8B81530
0000794c94dd2327  call rax
0000794c94dd2329  movaps xmm14, [rsp]
0000794c94dd232e  add rsp, 0x30
0000794c94dd2332  vmovaps xmm0, [rsp]
0000794c94dd2337  vmovaps xmm1, [rsp+0x10]
0000794c94dd233d  vmovaps xmm2, [rsp+0x20]
0000794c94dd2343  vmovaps xmm3, [rsp+0x30]
0000794c94dd2349  vmovaps xmm4, [rsp+0x40]
0000794c94dd234f  vmovaps xmm5, [rsp+0x50]
0000794c94dd2355  vmovaps xmm6, [rsp+0x60]
0000794c94dd235b  vmovaps xmm7, [rsp+0x70]
0000794c94dd2361  vmovaps xmm8, [rsp+0x80]
0000794c94dd236a  vmovaps xmm9, [rsp+0x90]
0000794c94dd2373  vmovaps xmm10, [rsp+0xA0]
0000794c94dd237c  vmovaps xmm11, [rsp+0xB0]
0000794c94dd2385  vmovaps xmm12, [rsp+0xC0]
0000794c94dd238e  vmovaps xmm13, [rsp+0xD0]
0000794c94dd2397  vmovaps xmm15, [rsp+0xE0]
0000794c94dd23a0  add rsp, 0xF0
0000794c94dd23a7  pop r11
0000794c94dd23a9  pop r10
0000794c94dd23ab  pop r9
0000794c94dd23ad  pop r8
0000794c94dd23af  pop rsi
0000794c94dd23b0  pop rdi
0000794c94dd23b1  pop rdx
0000794c94dd23b2  pop rcx
0000794c94dd23b3  pop rax
0000794c94dd23b4  add rsp, 0x08
0000794c94dd23b8  jmp 0x0000794C94DCFC21
0000794c94dd23bd  sub rsp, 0x08
0000794c94dd23c1  push rax
0000794c94dd23c2  push rcx
0000794c94dd23c3  push rdx
0000794c94dd23c4  push rdi
0000794c94dd23c5  push rsi
0000794c94dd23c6  push r8
0000794c94dd23c8  push r9
0000794c94dd23ca  push r10
0000794c94dd23cc  push r11
0000794c94dd23ce  sub rsp, 0xF0
0000794c94dd23d5  vmovaps [rsp], xmm0
0000794c94dd23da  vmovaps [rsp+0x10], xmm1
0000794c94dd23e0  vmovaps [rsp+0x20], xmm2
0000794c94dd23e6  vmovaps [rsp+0x30], xmm3
0000794c94dd23ec  vmovaps [rsp+0x40], xmm4
0000794c94dd23f2  vmovaps [rsp+0x50], xmm5
0000794c94dd23f8  vmovaps [rsp+0x60], xmm6
0000794c94dd23fe  vmovaps [rsp+0x70], xmm7
0000794c94dd2404  vmovaps [rsp+0x80], xmm8
0000794c94dd240d  vmovaps [rsp+0x90], xmm9
0000794c94dd2416  vmovaps [rsp+0xA0], xmm10
0000794c94dd241f  vmovaps [rsp+0xB0], xmm11
0000794c94dd2428  vmovaps [rsp+0xC0], xmm12
0000794c94dd2431  vmovaps [rsp+0xD0], xmm14
0000794c94dd243a  vmovaps [rsp+0xE0], xmm15
0000794c94dd2443  sub rsp, 0x30
0000794c94dd2447  movaps [rsp], xmm13
0000794c94dd244c  movaps [rsp+0x10], xmm11
0000794c94dd2452  movaps [rsp+0x20], xmm1
0000794c94dd2457  lea rdi, [rsp]
0000794c94dd245b  mov esi, 0x00
0000794c94dd2460  mov rax, 0x5AB2B8B81530
0000794c94dd246a  call rax
0000794c94dd246c  movaps xmm13, [rsp]
0000794c94dd2471  add rsp, 0x30
0000794c94dd2475  vmovaps xmm0, [rsp]
0000794c94dd247a  vmovaps xmm1, [rsp+0x10]
0000794c94dd2480  vmovaps xmm2, [rsp+0x20]
0000794c94dd2486  vmovaps xmm3, [rsp+0x30]
0000794c94dd248c  vmovaps xmm4, [rsp+0x40]
0000794c94dd2492  vmovaps xmm5, [rsp+0x50]
0000794c94dd2498  vmovaps xmm6, [rsp+0x60]
0000794c94dd249e  vmovaps xmm7, [rsp+0x70]
0000794c94dd24a4  vmovaps xmm8, [rsp+0x80]
0000794c94dd24ad  vmovaps xmm9, [rsp+0x90]
0000794c94dd24b6  vmovaps xmm10, [rsp+0xA0]
0000794c94dd24bf  vmovaps xmm11, [rsp+0xB0]
0000794c94dd24c8  vmovaps xmm12, [rsp+0xC0]
0000794c94dd24d1  vmovaps xmm14, [rsp+0xD0]
0000794c94dd24da  vmovaps xmm15, [rsp+0xE0]
0000794c94dd24e3  add rsp, 0xF0
0000794c94dd24ea  pop r11
0000794c94dd24ec  pop r10
0000794c94dd24ee  pop r9
0000794c94dd24f0  pop r8
0000794c94dd24f2  pop rsi
0000794c94dd24f3  pop rdi
0000794c94dd24f4  pop rdx
0000794c94dd24f5  pop rcx
0000794c94dd24f6  pop rax
0000794c94dd24f7  add rsp, 0x08
0000794c94dd24fb  jmp 0x0000794C94DCFC76
0000794c94dd2500  call 0x0000794C94BFF430
0000794c94dd2505  jmp 0x0000794C94DCFC83
0000794c94dd250a  sub rsp, 0x08
0000794c94dd250e  push rax
0000794c94dd250f  push rcx
0000794c94dd2510  push rdx
0000794c94dd2511  push rdi
0000794c94dd2512  push rsi
0000794c94dd2513  push r8
0000794c94dd2515  push r9
0000794c94dd2517  push r10
0000794c94dd2519  push r11
0000794c94dd251b  sub rsp, 0xF0
0000794c94dd2522  vmovaps [rsp], xmm0
0000794c94dd2527  vmovaps [rsp+0x10], xmm1
0000794c94dd252d  vmovaps [rsp+0x20], xmm2
0000794c94dd2533  vmovaps [rsp+0x30], xmm3
0000794c94dd2539  vmovaps [rsp+0x40], xmm4
0000794c94dd253f  vmovaps [rsp+0x50], xmm5
0000794c94dd2545  vmovaps [rsp+0x60], xmm6
0000794c94dd254b  vmovaps [rsp+0x70], xmm7
0000794c94dd2551  vmovaps [rsp+0x80], xmm8
0000794c94dd255a  vmovaps [rsp+0x90], xmm9
0000794c94dd2563  vmovaps [rsp+0xA0], xmm10
0000794c94dd256c  vmovaps [rsp+0xB0], xmm11
0000794c94dd2575  vmovaps [rsp+0xC0], xmm12
0000794c94dd257e  vmovaps [rsp+0xD0], xmm13
0000794c94dd2587  vmovaps [rsp+0xE0], xmm14
0000794c94dd2590  sub rsp, 0x30
0000794c94dd2594  movaps [rsp], xmm15
0000794c94dd2599  movaps [rsp+0x10], xmm11
0000794c94dd259f  movaps [rsp+0x20], xmm1
0000794c94dd25a4  lea rdi, [rsp]
0000794c94dd25a8  mov esi, 0x00
0000794c94dd25ad  mov rax, 0x5AB2B8B81530
0000794c94dd25b7  call rax
0000794c94dd25b9  movaps xmm15, [rsp]
0000794c94dd25be  add rsp, 0x30
0000794c94dd25c2  vmovaps xmm0, [rsp]
0000794c94dd25c7  vmovaps xmm1, [rsp+0x10]
0000794c94dd25cd  vmovaps xmm2, [rsp+0x20]
0000794c94dd25d3  vmovaps xmm3, [rsp+0x30]
0000794c94dd25d9  vmovaps xmm4, [rsp+0x40]
0000794c94dd25df  vmovaps xmm5, [rsp+0x50]
0000794c94dd25e5  vmovaps xmm6, [rsp+0x60]
0000794c94dd25eb  vmovaps xmm7, [rsp+0x70]
0000794c94dd25f1  vmovaps xmm8, [rsp+0x80]
0000794c94dd25fa  vmovaps xmm9, [rsp+0x90]
0000794c94dd2603  vmovaps xmm10, [rsp+0xA0]
0000794c94dd260c  vmovaps xmm11, [rsp+0xB0]
0000794c94dd2615  vmovaps xmm12, [rsp+0xC0]
0000794c94dd261e  vmovaps xmm13, [rsp+0xD0]
0000794c94dd2627  vmovaps xmm14, [rsp+0xE0]
0000794c94dd2630  add rsp, 0xF0
0000794c94dd2637  pop r11
0000794c94dd2639  pop r10
0000794c94dd263b  pop r9
0000794c94dd263d  pop r8
0000794c94dd263f  pop rsi
0000794c94dd2640  pop rdi
0000794c94dd2641  pop rdx
0000794c94dd2642  pop rcx
0000794c94dd2643  pop rax
0000794c94dd2644  add rsp, 0x08
0000794c94dd2648  jmp 0x0000794C94DCFCBC
0000794c94dd264d  sub rsp, 0x08
0000794c94dd2651  push rax
0000794c94dd2652  push rcx
0000794c94dd2653  push rdx
0000794c94dd2654  push rdi
0000794c94dd2655  push rsi
0000794c94dd2656  push r8
0000794c94dd2658  push r9
0000794c94dd265a  push r10
0000794c94dd265c  push r11
0000794c94dd265e  sub rsp, 0xF0
0000794c94dd2665  vmovaps [rsp], xmm0
0000794c94dd266a  vmovaps [rsp+0x10], xmm1
0000794c94dd2670  vmovaps [rsp+0x20], xmm2
0000794c94dd2676  vmovaps [rsp+0x30], xmm3
0000794c94dd267c  vmovaps [rsp+0x40], xmm4
0000794c94dd2682  vmovaps [rsp+0x50], xmm5
0000794c94dd2688  vmovaps [rsp+0x60], xmm6
0000794c94dd268e  vmovaps [rsp+0x70], xmm7
0000794c94dd2694  vmovaps [rsp+0x80], xmm8
0000794c94dd269d  vmovaps [rsp+0x90], xmm9
0000794c94dd26a6  vmovaps [rsp+0xA0], xmm10
0000794c94dd26af  vmovaps [rsp+0xB0], xmm12
0000794c94dd26b8  vmovaps [rsp+0xC0], xmm13
0000794c94dd26c1  vmovaps [rsp+0xD0], xmm14
0000794c94dd26ca  vmovaps [rsp+0xE0], xmm15
0000794c94dd26d3  sub rsp, 0x30
0000794c94dd26d7  movaps [rsp], xmm11
0000794c94dd26dc  movaps [rsp+0x10], xmm6
0000794c94dd26e1  movaps [rsp+0x20], xmm14
0000794c94dd26e7  lea rdi, [rsp]
0000794c94dd26eb  mov esi, 0x00
0000794c94dd26f0  mov rax, 0x5AB2B8B81530
0000794c94dd26fa  call rax
0000794c94dd26fc  movaps xmm11, [rsp]
0000794c94dd2701  add rsp, 0x30
0000794c94dd2705  vmovaps xmm0, [rsp]
0000794c94dd270a  vmovaps xmm1, [rsp+0x10]
0000794c94dd2710  vmovaps xmm2, [rsp+0x20]
0000794c94dd2716  vmovaps xmm3, [rsp+0x30]
0000794c94dd271c  vmovaps xmm4, [rsp+0x40]
0000794c94dd2722  vmovaps xmm5, [rsp+0x50]
0000794c94dd2728  vmovaps xmm6, [rsp+0x60]
0000794c94dd272e  vmovaps xmm7, [rsp+0x70]
0000794c94dd2734  vmovaps xmm8, [rsp+0x80]
0000794c94dd273d  vmovaps xmm9, [rsp+0x90]
0000794c94dd2746  vmovaps xmm10, [rsp+0xA0]
0000794c94dd274f  vmovaps xmm12, [rsp+0xB0]
0000794c94dd2758  vmovaps xmm13, [rsp+0xC0]
0000794c94dd2761  vmovaps xmm14, [rsp+0xD0]
0000794c94dd276a  vmovaps xmm15, [rsp+0xE0]
0000794c94dd2773  add rsp, 0xF0
0000794c94dd277a  pop r11
0000794c94dd277c  pop r10
0000794c94dd277e  pop r9
0000794c94dd2780  pop r8
0000794c94dd2782  pop rsi
0000794c94dd2783  pop rdi
0000794c94dd2784  pop rdx
0000794c94dd2785  pop rcx
0000794c94dd2786  pop rax
0000794c94dd2787  add rsp, 0x08
0000794c94dd278b  jmp 0x0000794C94DCFD34
0000794c94dd2790  call 0x0000794C94BFF430
0000794c94dd2795  jmp 0x0000794C94DCFD3E
0000794c94dd279a  sub rsp, 0x08
0000794c94dd279e  push rax
0000794c94dd279f  push rcx
0000794c94dd27a0  push rdx
0000794c94dd27a1  push rdi
0000794c94dd27a2  push rsi
0000794c94dd27a3  push r8
0000794c94dd27a5  push r9
0000794c94dd27a7  push r10
0000794c94dd27a9  push r11
0000794c94dd27ab  sub rsp, 0xF0
0000794c94dd27b2  vmovaps [rsp], xmm0
0000794c94dd27b7  vmovaps [rsp+0x10], xmm1
0000794c94dd27bd  vmovaps [rsp+0x20], xmm2
0000794c94dd27c3  vmovaps [rsp+0x30], xmm3
0000794c94dd27c9  vmovaps [rsp+0x40], xmm4
0000794c94dd27cf  vmovaps [rsp+0x50], xmm5
0000794c94dd27d5  vmovaps [rsp+0x60], xmm6
0000794c94dd27db  vmovaps [rsp+0x70], xmm7
0000794c94dd27e1  vmovaps [rsp+0x80], xmm8
0000794c94dd27ea  vmovaps [rsp+0x90], xmm9
0000794c94dd27f3  vmovaps [rsp+0xA0], xmm10
0000794c94dd27fc  vmovaps [rsp+0xB0], xmm11
0000794c94dd2805  vmovaps [rsp+0xC0], xmm12
0000794c94dd280e  vmovaps [rsp+0xD0], xmm13
0000794c94dd2817  vmovaps [rsp+0xE0], xmm15
0000794c94dd2820  sub rsp, 0x30
0000794c94dd2824  movaps [rsp], xmm14
0000794c94dd2829  movaps [rsp+0x10], xmm6
0000794c94dd282e  movaps [rsp+0x20], xmm2
0000794c94dd2833  lea rdi, [rsp]
0000794c94dd2837  mov esi, 0x00
0000794c94dd283c  mov rax, 0x5AB2B8B81530
0000794c94dd2846  call rax
0000794c94dd2848  movaps xmm14, [rsp]
0000794c94dd284d  add rsp, 0x30
0000794c94dd2851  vmovaps xmm0, [rsp]
0000794c94dd2856  vmovaps xmm1, [rsp+0x10]
0000794c94dd285c  vmovaps xmm2, [rsp+0x20]
0000794c94dd2862  vmovaps xmm3, [rsp+0x30]
0000794c94dd2868  vmovaps xmm4, [rsp+0x40]
0000794c94dd286e  vmovaps xmm5, [rsp+0x50]
0000794c94dd2874  vmovaps xmm6, [rsp+0x60]
0000794c94dd287a  vmovaps xmm7, [rsp+0x70]
0000794c94dd2880  vmovaps xmm8, [rsp+0x80]
0000794c94dd2889  vmovaps xmm9, [rsp+0x90]
0000794c94dd2892  vmovaps xmm10, [rsp+0xA0]
0000794c94dd289b  vmovaps xmm11, [rsp+0xB0]
0000794c94dd28a4  vmovaps xmm12, [rsp+0xC0]
0000794c94dd28ad  vmovaps xmm13, [rsp+0xD0]
0000794c94dd28b6  vmovaps xmm15, [rsp+0xE0]
0000794c94dd28bf  add rsp, 0xF0
0000794c94dd28c6  pop r11
0000794c94dd28c8  pop r10
0000794c94dd28ca  pop r9
0000794c94dd28cc  pop r8
0000794c94dd28ce  pop rsi
0000794c94dd28cf  pop rdi
0000794c94dd28d0  pop rdx
0000794c94dd28d1  pop rcx
0000794c94dd28d2  pop rax
0000794c94dd28d3  add rsp, 0x08
0000794c94dd28d7  jmp 0x0000794C94DCFD72
0000794c94dd28dc  sub rsp, 0x08
0000794c94dd28e0  push rax
0000794c94dd28e1  push rcx
0000794c94dd28e2  push rdx
0000794c94dd28e3  push rdi
0000794c94dd28e4  push rsi
0000794c94dd28e5  push r8
0000794c94dd28e7  push r9
0000794c94dd28e9  push r10
0000794c94dd28eb  push r11
0000794c94dd28ed  sub rsp, 0xF0
0000794c94dd28f4  vmovaps [rsp], xmm0
0000794c94dd28f9  vmovaps [rsp+0x10], xmm1
0000794c94dd28ff  vmovaps [rsp+0x20], xmm2
0000794c94dd2905  vmovaps [rsp+0x30], xmm3
0000794c94dd290b  vmovaps [rsp+0x40], xmm4
0000794c94dd2911  vmovaps [rsp+0x50], xmm5
0000794c94dd2917  vmovaps [rsp+0x60], xmm7
0000794c94dd291d  vmovaps [rsp+0x70], xmm8
0000794c94dd2923  vmovaps [rsp+0x80], xmm9
0000794c94dd292c  vmovaps [rsp+0x90], xmm10
0000794c94dd2935  vmovaps [rsp+0xA0], xmm11
0000794c94dd293e  vmovaps [rsp+0xB0], xmm12
0000794c94dd2947  vmovaps [rsp+0xC0], xmm13
0000794c94dd2950  vmovaps [rsp+0xD0], xmm14
0000794c94dd2959  vmovaps [rsp+0xE0], xmm15
0000794c94dd2962  sub rsp, 0x30
0000794c94dd2966  movaps [rsp], xmm6
0000794c94dd296a  movaps [rsp+0x10], xmm5
0000794c94dd296f  movaps [rsp+0x20], xmm1
0000794c94dd2974  lea rdi, [rsp]
0000794c94dd2978  mov esi, 0x00
0000794c94dd297d  mov rax, 0x5AB2B8B81530
0000794c94dd2987  call rax
0000794c94dd2989  movaps xmm6, [rsp]
0000794c94dd298d  add rsp, 0x30
0000794c94dd2991  vmovaps xmm0, [rsp]
0000794c94dd2996  vmovaps xmm1, [rsp+0x10]
0000794c94dd299c  vmovaps xmm2, [rsp+0x20]
0000794c94dd29a2  vmovaps xmm3, [rsp+0x30]
0000794c94dd29a8  vmovaps xmm4, [rsp+0x40]
0000794c94dd29ae  vmovaps xmm5, [rsp+0x50]
0000794c94dd29b4  vmovaps xmm7, [rsp+0x60]
0000794c94dd29ba  vmovaps xmm8, [rsp+0x70]
0000794c94dd29c0  vmovaps xmm9, [rsp+0x80]
0000794c94dd29c9  vmovaps xmm10, [rsp+0x90]
0000794c94dd29d2  vmovaps xmm11, [rsp+0xA0]
0000794c94dd29db  vmovaps xmm12, [rsp+0xB0]
0000794c94dd29e4  vmovaps xmm13, [rsp+0xC0]
0000794c94dd29ed  vmovaps xmm14, [rsp+0xD0]
0000794c94dd29f6  vmovaps xmm15, [rsp+0xE0]
0000794c94dd29ff  add rsp, 0xF0
0000794c94dd2a06  pop r11
0000794c94dd2a08  pop r10
0000794c94dd2a0a  pop r9
0000794c94dd2a0c  pop r8
0000794c94dd2a0e  pop rsi
0000794c94dd2a0f  pop rdi
0000794c94dd2a10  pop rdx
0000794c94dd2a11  pop rcx
0000794c94dd2a12  pop rax
0000794c94dd2a13  add rsp, 0x08
0000794c94dd2a17  jmp 0x0000794C94DCFD98
0000794c94dd2a1c  sub rsp, 0x08
0000794c94dd2a20  push rax
0000794c94dd2a21  push rcx
0000794c94dd2a22  push rdx
0000794c94dd2a23  push rdi
0000794c94dd2a24  push rsi
0000794c94dd2a25  push r8
0000794c94dd2a27  push r9
0000794c94dd2a29  push r10
0000794c94dd2a2b  push r11
0000794c94dd2a2d  sub rsp, 0xF0
0000794c94dd2a34  vmovaps [rsp], xmm0
0000794c94dd2a39  vmovaps [rsp+0x10], xmm2
0000794c94dd2a3f  vmovaps [rsp+0x20], xmm3
0000794c94dd2a45  vmovaps [rsp+0x30], xmm4
0000794c94dd2a4b  vmovaps [rsp+0x40], xmm5
0000794c94dd2a51  vmovaps [rsp+0x50], xmm6
0000794c94dd2a57  vmovaps [rsp+0x60], xmm7
0000794c94dd2a5d  vmovaps [rsp+0x70], xmm8
0000794c94dd2a63  vmovaps [rsp+0x80], xmm9
0000794c94dd2a6c  vmovaps [rsp+0x90], xmm10
0000794c94dd2a75  vmovaps [rsp+0xA0], xmm11
0000794c94dd2a7e  vmovaps [rsp+0xB0], xmm12
0000794c94dd2a87  vmovaps [rsp+0xC0], xmm13
0000794c94dd2a90  vmovaps [rsp+0xD0], xmm14
0000794c94dd2a99  vmovaps [rsp+0xE0], xmm15
0000794c94dd2aa2  sub rsp, 0x30
0000794c94dd2aa6  movaps [rsp], xmm1
0000794c94dd2aaa  movaps [rsp+0x10], xmm5
0000794c94dd2aaf  movaps [rsp+0x20], xmm13
0000794c94dd2ab5  lea rdi, [rsp]
0000794c94dd2ab9  mov esi, 0x00
0000794c94dd2abe  mov rax, 0x5AB2B8B81530
0000794c94dd2ac8  call rax
0000794c94dd2aca  movaps xmm1, [rsp]
0000794c94dd2ace  add rsp, 0x30
0000794c94dd2ad2  vmovaps xmm0, [rsp]
0000794c94dd2ad7  vmovaps xmm2, [rsp+0x10]
0000794c94dd2add  vmovaps xmm3, [rsp+0x20]
0000794c94dd2ae3  vmovaps xmm4, [rsp+0x30]
0000794c94dd2ae9  vmovaps xmm5, [rsp+0x40]
0000794c94dd2aef  vmovaps xmm6, [rsp+0x50]
0000794c94dd2af5  vmovaps xmm7, [rsp+0x60]
0000794c94dd2afb  vmovaps xmm8, [rsp+0x70]
0000794c94dd2b01  vmovaps xmm9, [rsp+0x80]
0000794c94dd2b0a  vmovaps xmm10, [rsp+0x90]
0000794c94dd2b13  vmovaps xmm11, [rsp+0xA0]
0000794c94dd2b1c  vmovaps xmm12, [rsp+0xB0]
0000794c94dd2b25  vmovaps xmm13, [rsp+0xC0]
0000794c94dd2b2e  vmovaps xmm14, [rsp+0xD0]
0000794c94dd2b37  vmovaps xmm15, [rsp+0xE0]
0000794c94dd2b40  add rsp, 0xF0
0000794c94dd2b47  pop r11
0000794c94dd2b49  pop r10
0000794c94dd2b4b  pop r9
0000794c94dd2b4d  pop r8
0000794c94dd2b4f  pop rsi
0000794c94dd2b50  pop rdi
0000794c94dd2b51  pop rdx
0000794c94dd2b52  pop rcx
0000794c94dd2b53  pop rax
0000794c94dd2b54  add rsp, 0x08
0000794c94dd2b58  jmp 0x0000794C94DCFDB6
0000794c94dd2b5d  sub rsp, 0x08
0000794c94dd2b61  push rax
0000794c94dd2b62  push rcx
0000794c94dd2b63  push rdx
0000794c94dd2b64  push rdi
0000794c94dd2b65  push rsi
0000794c94dd2b66  push r8
0000794c94dd2b68  push r9
0000794c94dd2b6a  push r10
0000794c94dd2b6c  push r11
0000794c94dd2b6e  sub rsp, 0xF0
0000794c94dd2b75  vmovaps [rsp], xmm0
0000794c94dd2b7a  vmovaps [rsp+0x10], xmm1
0000794c94dd2b80  vmovaps [rsp+0x20], xmm2
0000794c94dd2b86  vmovaps [rsp+0x30], xmm3
0000794c94dd2b8c  vmovaps [rsp+0x40], xmm4
0000794c94dd2b92  vmovaps [rsp+0x50], xmm6
0000794c94dd2b98  vmovaps [rsp+0x60], xmm7
0000794c94dd2b9e  vmovaps [rsp+0x70], xmm8
0000794c94dd2ba4  vmovaps [rsp+0x80], xmm9
0000794c94dd2bad  vmovaps [rsp+0x90], xmm10
0000794c94dd2bb6  vmovaps [rsp+0xA0], xmm11
0000794c94dd2bbf  vmovaps [rsp+0xB0], xmm12
0000794c94dd2bc8  vmovaps [rsp+0xC0], xmm13
0000794c94dd2bd1  vmovaps [rsp+0xD0], xmm14
0000794c94dd2bda  vmovaps [rsp+0xE0], xmm15
0000794c94dd2be3  sub rsp, 0x30
0000794c94dd2be7  movaps [rsp], xmm5
0000794c94dd2beb  movaps [rsp+0x10], xmm2
0000794c94dd2bf0  movaps [rsp+0x20], xmm13
0000794c94dd2bf6  lea rdi, [rsp]
0000794c94dd2bfa  mov esi, 0x00
0000794c94dd2bff  mov rax, 0x5AB2B8B81530
0000794c94dd2c09  call rax
0000794c94dd2c0b  movaps xmm5, [rsp]
0000794c94dd2c0f  add rsp, 0x30
0000794c94dd2c13  vmovaps xmm0, [rsp]
0000794c94dd2c18  vmovaps xmm1, [rsp+0x10]
0000794c94dd2c1e  vmovaps xmm2, [rsp+0x20]
0000794c94dd2c24  vmovaps xmm3, [rsp+0x30]
0000794c94dd2c2a  vmovaps xmm4, [rsp+0x40]
0000794c94dd2c30  vmovaps xmm6, [rsp+0x50]
0000794c94dd2c36  vmovaps xmm7, [rsp+0x60]
0000794c94dd2c3c  vmovaps xmm8, [rsp+0x70]
0000794c94dd2c42  vmovaps xmm9, [rsp+0x80]
0000794c94dd2c4b  vmovaps xmm10, [rsp+0x90]
0000794c94dd2c54  vmovaps xmm11, [rsp+0xA0]
0000794c94dd2c5d  vmovaps xmm12, [rsp+0xB0]
0000794c94dd2c66  vmovaps xmm13, [rsp+0xC0]
0000794c94dd2c6f  vmovaps xmm14, [rsp+0xD0]
0000794c94dd2c78  vmovaps xmm15, [rsp+0xE0]
0000794c94dd2c81  add rsp, 0xF0
0000794c94dd2c88  pop r11
0000794c94dd2c8a  pop r10
0000794c94dd2c8c  pop r9
0000794c94dd2c8e  pop r8
0000794c94dd2c90  pop rsi
0000794c94dd2c91  pop rdi
0000794c94dd2c92  pop rdx
0000794c94dd2c93  pop rcx
0000794c94dd2c94  pop rax
0000794c94dd2c95  add rsp, 0x08
0000794c94dd2c99  jmp 0x0000794C94DCFDEC
0000794c94dd2c9e  sub rsp, 0x08
0000794c94dd2ca2  push rax
0000794c94dd2ca3  push rcx
0000794c94dd2ca4  push rdx
0000794c94dd2ca5  push rdi
0000794c94dd2ca6  push rsi
0000794c94dd2ca7  push r8
0000794c94dd2ca9  push r9
0000794c94dd2cab  push r10
0000794c94dd2cad  push r11
0000794c94dd2caf  sub rsp, 0xF0
0000794c94dd2cb6  vmovaps [rsp], xmm0
0000794c94dd2cbb  vmovaps [rsp+0x10], xmm1
0000794c94dd2cc1  vmovaps [rsp+0x20], xmm2
0000794c94dd2cc7  vmovaps [rsp+0x30], xmm3
0000794c94dd2ccd  vmovaps [rsp+0x40], xmm4
0000794c94dd2cd3  vmovaps [rsp+0x50], xmm5
0000794c94dd2cd9  vmovaps [rsp+0x60], xmm6
0000794c94dd2cdf  vmovaps [rsp+0x70], xmm7
0000794c94dd2ce5  vmovaps [rsp+0x80], xmm8
0000794c94dd2cee  vmovaps [rsp+0x90], xmm9
0000794c94dd2cf7  vmovaps [rsp+0xA0], xmm10
0000794c94dd2d00  vmovaps [rsp+0xB0], xmm11
0000794c94dd2d09  vmovaps [rsp+0xC0], xmm12
0000794c94dd2d12  vmovaps [rsp+0xD0], xmm14
0000794c94dd2d1b  vmovaps [rsp+0xE0], xmm15
0000794c94dd2d24  sub rsp, 0x30
0000794c94dd2d28  movaps [rsp], xmm13
0000794c94dd2d2d  movaps [rsp+0x10], xmm10
0000794c94dd2d33  movaps [rsp+0x20], xmm1
0000794c94dd2d38  lea rdi, [rsp]
0000794c94dd2d3c  mov esi, 0x00
0000794c94dd2d41  mov rax, 0x5AB2B8B81530
0000794c94dd2d4b  call rax
0000794c94dd2d4d  movaps xmm13, [rsp]
0000794c94dd2d52  add rsp, 0x30
0000794c94dd2d56  vmovaps xmm0, [rsp]
0000794c94dd2d5b  vmovaps xmm1, [rsp+0x10]
0000794c94dd2d61  vmovaps xmm2, [rsp+0x20]
0000794c94dd2d67  vmovaps xmm3, [rsp+0x30]
0000794c94dd2d6d  vmovaps xmm4, [rsp+0x40]
0000794c94dd2d73  vmovaps xmm5, [rsp+0x50]
0000794c94dd2d79  vmovaps xmm6, [rsp+0x60]
0000794c94dd2d7f  vmovaps xmm7, [rsp+0x70]
0000794c94dd2d85  vmovaps xmm8, [rsp+0x80]
0000794c94dd2d8e  vmovaps xmm9, [rsp+0x90]
0000794c94dd2d97  vmovaps xmm10, [rsp+0xA0]
0000794c94dd2da0  vmovaps xmm11, [rsp+0xB0]
0000794c94dd2da9  vmovaps xmm12, [rsp+0xC0]
0000794c94dd2db2  vmovaps xmm14, [rsp+0xD0]
0000794c94dd2dbb  vmovaps xmm15, [rsp+0xE0]
0000794c94dd2dc4  add rsp, 0xF0
0000794c94dd2dcb  pop r11
0000794c94dd2dcd  pop r10
0000794c94dd2dcf  pop r9
0000794c94dd2dd1  pop r8
0000794c94dd2dd3  pop rsi
0000794c94dd2dd4  pop rdi
0000794c94dd2dd5  pop rdx
0000794c94dd2dd6  pop rcx
0000794c94dd2dd7  pop rax
0000794c94dd2dd8  add rsp, 0x08
0000794c94dd2ddc  jmp 0x0000794C94DCFE15
0000794c94dd2de1  sub rsp, 0x08
0000794c94dd2de5  push rax
0000794c94dd2de6  push rcx
0000794c94dd2de7  push rdx
0000794c94dd2de8  push rdi
0000794c94dd2de9  push rsi
0000794c94dd2dea  push r8
0000794c94dd2dec  push r9
0000794c94dd2dee  push r10
0000794c94dd2df0  push r11
0000794c94dd2df2  sub rsp, 0xF0
0000794c94dd2df9  vmovaps [rsp], xmm0
0000794c94dd2dfe  vmovaps [rsp+0x10], xmm2
0000794c94dd2e04  vmovaps [rsp+0x20], xmm3
0000794c94dd2e0a  vmovaps [rsp+0x30], xmm4
0000794c94dd2e10  vmovaps [rsp+0x40], xmm5
0000794c94dd2e16  vmovaps [rsp+0x50], xmm6
0000794c94dd2e1c  vmovaps [rsp+0x60], xmm7
0000794c94dd2e22  vmovaps [rsp+0x70], xmm8
0000794c94dd2e28  vmovaps [rsp+0x80], xmm9
0000794c94dd2e31  vmovaps [rsp+0x90], xmm10
0000794c94dd2e3a  vmovaps [rsp+0xA0], xmm11
0000794c94dd2e43  vmovaps [rsp+0xB0], xmm12
0000794c94dd2e4c  vmovaps [rsp+0xC0], xmm13
0000794c94dd2e55  vmovaps [rsp+0xD0], xmm14
0000794c94dd2e5e  vmovaps [rsp+0xE0], xmm15
0000794c94dd2e67  sub rsp, 0x30
0000794c94dd2e6b  movaps [rsp], xmm1
0000794c94dd2e6f  movaps [rsp+0x10], xmm15
0000794c94dd2e75  movaps [rsp+0x20], xmm10
0000794c94dd2e7b  lea rdi, [rsp]
0000794c94dd2e7f  mov esi, 0x00
0000794c94dd2e84  mov rax, 0x5AB2B8B81530
0000794c94dd2e8e  call rax
0000794c94dd2e90  movaps xmm1, [rsp]
0000794c94dd2e94  add rsp, 0x30
0000794c94dd2e98  vmovaps xmm0, [rsp]
0000794c94dd2e9d  vmovaps xmm2, [rsp+0x10]
0000794c94dd2ea3  vmovaps xmm3, [rsp+0x20]
0000794c94dd2ea9  vmovaps xmm4, [rsp+0x30]
0000794c94dd2eaf  vmovaps xmm5, [rsp+0x40]
0000794c94dd2eb5  vmovaps xmm6, [rsp+0x50]
0000794c94dd2ebb  vmovaps xmm7, [rsp+0x60]
0000794c94dd2ec1  vmovaps xmm8, [rsp+0x70]
0000794c94dd2ec7  vmovaps xmm9, [rsp+0x80]
0000794c94dd2ed0  vmovaps xmm10, [rsp+0x90]
0000794c94dd2ed9  vmovaps xmm11, [rsp+0xA0]
0000794c94dd2ee2  vmovaps xmm12, [rsp+0xB0]
0000794c94dd2eeb  vmovaps xmm13, [rsp+0xC0]
0000794c94dd2ef4  vmovaps xmm14, [rsp+0xD0]
0000794c94dd2efd  vmovaps xmm15, [rsp+0xE0]
0000794c94dd2f06  add rsp, 0xF0
0000794c94dd2f0d  pop r11
0000794c94dd2f0f  pop r10
0000794c94dd2f11  pop r9
0000794c94dd2f13  pop r8
0000794c94dd2f15  pop rsi
0000794c94dd2f16  pop rdi
0000794c94dd2f17  pop rdx
0000794c94dd2f18  pop rcx
0000794c94dd2f19  pop rax
0000794c94dd2f1a  add rsp, 0x08
0000794c94dd2f1e  jmp 0x0000794C94DCFE34
0000794c94dd2f23  sub rsp, 0x08
0000794c94dd2f27  push rax
0000794c94dd2f28  push rcx
0000794c94dd2f29  push rdx
0000794c94dd2f2a  push rdi
0000794c94dd2f2b  push rsi
0000794c94dd2f2c  push r8
0000794c94dd2f2e  push r9
0000794c94dd2f30  push r10
0000794c94dd2f32  push r11
0000794c94dd2f34  sub rsp, 0xF0
0000794c94dd2f3b  vmovaps [rsp], xmm0
0000794c94dd2f40  vmovaps [rsp+0x10], xmm1
0000794c94dd2f46  vmovaps [rsp+0x20], xmm2
0000794c94dd2f4c  vmovaps [rsp+0x30], xmm3
0000794c94dd2f52  vmovaps [rsp+0x40], xmm4
0000794c94dd2f58  vmovaps [rsp+0x50], xmm5
0000794c94dd2f5e  vmovaps [rsp+0x60], xmm6
0000794c94dd2f64  vmovaps [rsp+0x70], xmm7
0000794c94dd2f6a  vmovaps [rsp+0x80], xmm8
0000794c94dd2f73  vmovaps [rsp+0x90], xmm9
0000794c94dd2f7c  vmovaps [rsp+0xA0], xmm10
0000794c94dd2f85  vmovaps [rsp+0xB0], xmm11
0000794c94dd2f8e  vmovaps [rsp+0xC0], xmm12
0000794c94dd2f97  vmovaps [rsp+0xD0], xmm13
0000794c94dd2fa0  vmovaps [rsp+0xE0], xmm14
0000794c94dd2fa9  sub rsp, 0x30
0000794c94dd2fad  movaps [rsp], xmm15
0000794c94dd2fb2  movaps [rsp+0x10], xmm10
0000794c94dd2fb8  movaps [rsp+0x20], xmm11
0000794c94dd2fbe  lea rdi, [rsp]
0000794c94dd2fc2  mov esi, 0x00
0000794c94dd2fc7  mov rax, 0x5AB2B8B81530
0000794c94dd2fd1  call rax
0000794c94dd2fd3  movaps xmm15, [rsp]
0000794c94dd2fd8  add rsp, 0x30
0000794c94dd2fdc  vmovaps xmm0, [rsp]
0000794c94dd2fe1  vmovaps xmm1, [rsp+0x10]
0000794c94dd2fe7  vmovaps xmm2, [rsp+0x20]
0000794c94dd2fed  vmovaps xmm3, [rsp+0x30]
0000794c94dd2ff3  vmovaps xmm4, [rsp+0x40]
0000794c94dd2ff9  vmovaps xmm5, [rsp+0x50]
0000794c94dd2fff  vmovaps xmm6, [rsp+0x60]
0000794c94dd3005  vmovaps xmm7, [rsp+0x70]
0000794c94dd300b  vmovaps xmm8, [rsp+0x80]
0000794c94dd3014  vmovaps xmm9, [rsp+0x90]
0000794c94dd301d  vmovaps xmm10, [rsp+0xA0]
0000794c94dd3026  vmovaps xmm11, [rsp+0xB0]
0000794c94dd302f  vmovaps xmm12, [rsp+0xC0]
0000794c94dd3038  vmovaps xmm13, [rsp+0xD0]
0000794c94dd3041  vmovaps xmm14, [rsp+0xE0]
0000794c94dd304a  add rsp, 0xF0
0000794c94dd3051  pop r11
0000794c94dd3053  pop r10
0000794c94dd3055  pop r9
0000794c94dd3057  pop r8
0000794c94dd3059  pop rsi
0000794c94dd305a  pop rdi
0000794c94dd305b  pop rdx
0000794c94dd305c  pop rcx
0000794c94dd305d  pop rax
0000794c94dd305e  add rsp, 0x08
0000794c94dd3062  jmp 0x0000794C94DCFE57
0000794c94dd3067  sub rsp, 0x08
0000794c94dd306b  push rax
0000794c94dd306c  push rcx
0000794c94dd306d  push rdx
0000794c94dd306e  push rdi
0000794c94dd306f  push rsi
0000794c94dd3070  push r8
0000794c94dd3072  push r9
0000794c94dd3074  push r10
0000794c94dd3076  push r11
0000794c94dd3078  sub rsp, 0xF0
0000794c94dd307f  vmovaps [rsp], xmm0
0000794c94dd3084  vmovaps [rsp+0x10], xmm1
0000794c94dd308a  vmovaps [rsp+0x20], xmm2
0000794c94dd3090  vmovaps [rsp+0x30], xmm3
0000794c94dd3096  vmovaps [rsp+0x40], xmm4
0000794c94dd309c  vmovaps [rsp+0x50], xmm5
0000794c94dd30a2  vmovaps [rsp+0x60], xmm6
0000794c94dd30a8  vmovaps [rsp+0x70], xmm7
0000794c94dd30ae  vmovaps [rsp+0x80], xmm8
0000794c94dd30b7  vmovaps [rsp+0x90], xmm9
0000794c94dd30c0  vmovaps [rsp+0xA0], xmm11
0000794c94dd30c9  vmovaps [rsp+0xB0], xmm12
0000794c94dd30d2  vmovaps [rsp+0xC0], xmm13
0000794c94dd30db  vmovaps [rsp+0xD0], xmm14
0000794c94dd30e4  vmovaps [rsp+0xE0], xmm15
0000794c94dd30ed  sub rsp, 0x30
0000794c94dd30f1  movaps [rsp], xmm10
0000794c94dd30f6  movaps [rsp+0x10], xmm12
0000794c94dd30fc  movaps [rsp+0x20], xmm11
0000794c94dd3102  lea rdi, [rsp]
0000794c94dd3106  mov esi, 0x00
0000794c94dd310b  mov rax, 0x5AB2B8B81530
0000794c94dd3115  call rax
0000794c94dd3117  movaps xmm10, [rsp]
0000794c94dd311c  add rsp, 0x30
0000794c94dd3120  vmovaps xmm0, [rsp]
0000794c94dd3125  vmovaps xmm1, [rsp+0x10]
0000794c94dd312b  vmovaps xmm2, [rsp+0x20]
0000794c94dd3131  vmovaps xmm3, [rsp+0x30]
0000794c94dd3137  vmovaps xmm4, [rsp+0x40]
0000794c94dd313d  vmovaps xmm5, [rsp+0x50]
0000794c94dd3143  vmovaps xmm6, [rsp+0x60]
0000794c94dd3149  vmovaps xmm7, [rsp+0x70]
0000794c94dd314f  vmovaps xmm8, [rsp+0x80]
0000794c94dd3158  vmovaps xmm9, [rsp+0x90]
0000794c94dd3161  vmovaps xmm11, [rsp+0xA0]
0000794c94dd316a  vmovaps xmm12, [rsp+0xB0]
0000794c94dd3173  vmovaps xmm13, [rsp+0xC0]
0000794c94dd317c  vmovaps xmm14, [rsp+0xD0]
0000794c94dd3185  vmovaps xmm15, [rsp+0xE0]
0000794c94dd318e  add rsp, 0xF0
0000794c94dd3195  pop r11
0000794c94dd3197  pop r10
0000794c94dd3199  pop r9
0000794c94dd319b  pop r8
0000794c94dd319d  pop rsi
0000794c94dd319e  pop rdi
0000794c94dd319f  pop rdx
0000794c94dd31a0  pop rcx
0000794c94dd31a1  pop rax
0000794c94dd31a2  add rsp, 0x08
0000794c94dd31a6  jmp 0x0000794C94DCFE80
0000794c94dd31ab  sub rsp, 0x08
0000794c94dd31af  push rax
0000794c94dd31b0  push rcx
0000794c94dd31b1  push rdx
0000794c94dd31b2  push rdi
0000794c94dd31b3  push rsi
0000794c94dd31b4  push r8
0000794c94dd31b6  push r9
0000794c94dd31b8  push r10
0000794c94dd31ba  push r11
0000794c94dd31bc  sub rsp, 0xF0
0000794c94dd31c3  vmovaps [rsp], xmm0
0000794c94dd31c8  vmovaps [rsp+0x10], xmm1
0000794c94dd31ce  vmovaps [rsp+0x20], xmm2
0000794c94dd31d4  vmovaps [rsp+0x30], xmm3
0000794c94dd31da  vmovaps [rsp+0x40], xmm4
0000794c94dd31e0  vmovaps [rsp+0x50], xmm5
0000794c94dd31e6  vmovaps [rsp+0x60], xmm6
0000794c94dd31ec  vmovaps [rsp+0x70], xmm7
0000794c94dd31f2  vmovaps [rsp+0x80], xmm8
0000794c94dd31fb  vmovaps [rsp+0x90], xmm9
0000794c94dd3204  vmovaps [rsp+0xA0], xmm10
0000794c94dd320d  vmovaps [rsp+0xB0], xmm12
0000794c94dd3216  vmovaps [rsp+0xC0], xmm13
0000794c94dd321f  vmovaps [rsp+0xD0], xmm14
0000794c94dd3228  vmovaps [rsp+0xE0], xmm15
0000794c94dd3231  sub rsp, 0x30
0000794c94dd3235  movaps [rsp], xmm11
0000794c94dd323a  movaps [rsp+0x10], xmm2
0000794c94dd323f  movaps [rsp+0x20], xmm12
0000794c94dd3245  lea rdi, [rsp]
0000794c94dd3249  mov esi, 0x00
0000794c94dd324e  mov rax, 0x5AB2B8B81530
0000794c94dd3258  call rax
0000794c94dd325a  movaps xmm11, [rsp]
0000794c94dd325f  add rsp, 0x30
0000794c94dd3263  vmovaps xmm0, [rsp]
0000794c94dd3268  vmovaps xmm1, [rsp+0x10]
0000794c94dd326e  vmovaps xmm2, [rsp+0x20]
0000794c94dd3274  vmovaps xmm3, [rsp+0x30]
0000794c94dd327a  vmovaps xmm4, [rsp+0x40]
0000794c94dd3280  vmovaps xmm5, [rsp+0x50]
0000794c94dd3286  vmovaps xmm6, [rsp+0x60]
0000794c94dd328c  vmovaps xmm7, [rsp+0x70]
0000794c94dd3292  vmovaps xmm8, [rsp+0x80]
0000794c94dd329b  vmovaps xmm9, [rsp+0x90]
0000794c94dd32a4  vmovaps xmm10, [rsp+0xA0]
0000794c94dd32ad  vmovaps xmm12, [rsp+0xB0]
0000794c94dd32b6  vmovaps xmm13, [rsp+0xC0]
0000794c94dd32bf  vmovaps xmm14, [rsp+0xD0]
0000794c94dd32c8  vmovaps xmm15, [rsp+0xE0]
0000794c94dd32d1  add rsp, 0xF0
0000794c94dd32d8  pop r11
0000794c94dd32da  pop r10
0000794c94dd32dc  pop r9
0000794c94dd32de  pop r8
0000794c94dd32e0  pop rsi
0000794c94dd32e1  pop rdi
0000794c94dd32e2  pop rdx
0000794c94dd32e3  pop rcx
0000794c94dd32e4  pop rax
0000794c94dd32e5  add rsp, 0x08
0000794c94dd32e9  jmp 0x0000794C94DCFEB8
0000794c94dd32ee  sub rsp, 0x08
0000794c94dd32f2  push rax
0000794c94dd32f3  push rcx
0000794c94dd32f4  push rdx
0000794c94dd32f5  push rdi
0000794c94dd32f6  push rsi
0000794c94dd32f7  push r8
0000794c94dd32f9  push r9
0000794c94dd32fb  push r10
0000794c94dd32fd  push r11
0000794c94dd32ff  sub rsp, 0xF0
0000794c94dd3306  vmovaps [rsp], xmm0
0000794c94dd330b  vmovaps [rsp+0x10], xmm2
0000794c94dd3311  vmovaps [rsp+0x20], xmm3
0000794c94dd3317  vmovaps [rsp+0x30], xmm4
0000794c94dd331d  vmovaps [rsp+0x40], xmm5
0000794c94dd3323  vmovaps [rsp+0x50], xmm6
0000794c94dd3329  vmovaps [rsp+0x60], xmm7
0000794c94dd332f  vmovaps [rsp+0x70], xmm8
0000794c94dd3335  vmovaps [rsp+0x80], xmm9
0000794c94dd333e  vmovaps [rsp+0x90], xmm10
0000794c94dd3347  vmovaps [rsp+0xA0], xmm11
0000794c94dd3350  vmovaps [rsp+0xB0], xmm12
0000794c94dd3359  vmovaps [rsp+0xC0], xmm13
0000794c94dd3362  vmovaps [rsp+0xD0], xmm14
0000794c94dd336b  vmovaps [rsp+0xE0], xmm15
0000794c94dd3374  sub rsp, 0x30
0000794c94dd3378  movaps [rsp], xmm1
0000794c94dd337c  movaps [rsp+0x10], xmm14
0000794c94dd3382  movaps [rsp+0x20], xmm6
0000794c94dd3387  lea rdi, [rsp]
0000794c94dd338b  mov esi, 0x00
0000794c94dd3390  mov rax, 0x5AB2B8B81530
0000794c94dd339a  call rax
0000794c94dd339c  movaps xmm1, [rsp]
0000794c94dd33a0  add rsp, 0x30
0000794c94dd33a4  vmovaps xmm0, [rsp]
0000794c94dd33a9  vmovaps xmm2, [rsp+0x10]
0000794c94dd33af  vmovaps xmm3, [rsp+0x20]
0000794c94dd33b5  vmovaps xmm4, [rsp+0x30]
0000794c94dd33bb  vmovaps xmm5, [rsp+0x40]
0000794c94dd33c1  vmovaps xmm6, [rsp+0x50]
0000794c94dd33c7  vmovaps xmm7, [rsp+0x60]
0000794c94dd33cd  vmovaps xmm8, [rsp+0x70]
0000794c94dd33d3  vmovaps xmm9, [rsp+0x80]
0000794c94dd33dc  vmovaps xmm10, [rsp+0x90]
0000794c94dd33e5  vmovaps xmm11, [rsp+0xA0]
0000794c94dd33ee  vmovaps xmm12, [rsp+0xB0]
0000794c94dd33f7  vmovaps xmm13, [rsp+0xC0]
0000794c94dd3400  vmovaps xmm14, [rsp+0xD0]
0000794c94dd3409  vmovaps xmm15, [rsp+0xE0]
0000794c94dd3412  add rsp, 0xF0
0000794c94dd3419  pop r11
0000794c94dd341b  pop r10
0000794c94dd341d  pop r9
0000794c94dd341f  pop r8
0000794c94dd3421  pop rsi
0000794c94dd3422  pop rdi
0000794c94dd3423  pop rdx
0000794c94dd3424  pop rcx
0000794c94dd3425  pop rax
0000794c94dd3426  add rsp, 0x08
0000794c94dd342a  jmp 0x0000794C94DCFED1
0000794c94dd342f  sub rsp, 0x08
0000794c94dd3433  push rax
0000794c94dd3434  push rcx
0000794c94dd3435  push rdx
0000794c94dd3436  push rdi
0000794c94dd3437  push rsi
0000794c94dd3438  push r8
0000794c94dd343a  push r9
0000794c94dd343c  push r10
0000794c94dd343e  push r11
0000794c94dd3440  sub rsp, 0xF0
0000794c94dd3447  vmovaps [rsp], xmm0
0000794c94dd344c  vmovaps [rsp+0x10], xmm1
0000794c94dd3452  vmovaps [rsp+0x20], xmm2
0000794c94dd3458  vmovaps [rsp+0x30], xmm3
0000794c94dd345e  vmovaps [rsp+0x40], xmm4
0000794c94dd3464  vmovaps [rsp+0x50], xmm5
0000794c94dd346a  vmovaps [rsp+0x60], xmm6
0000794c94dd3470  vmovaps [rsp+0x70], xmm7
0000794c94dd3476  vmovaps [rsp+0x80], xmm8
0000794c94dd347f  vmovaps [rsp+0x90], xmm9
0000794c94dd3488  vmovaps [rsp+0xA0], xmm10
0000794c94dd3491  vmovaps [rsp+0xB0], xmm11
0000794c94dd349a  vmovaps [rsp+0xC0], xmm12
0000794c94dd34a3  vmovaps [rsp+0xD0], xmm13
0000794c94dd34ac  vmovaps [rsp+0xE0], xmm15
0000794c94dd34b5  sub rsp, 0x30
0000794c94dd34b9  movaps [rsp], xmm14
0000794c94dd34be  movaps [rsp+0x10], xmm12
0000794c94dd34c4  movaps [rsp+0x20], xmm5
0000794c94dd34c9  lea rdi, [rsp]
0000794c94dd34cd  mov esi, 0x00
0000794c94dd34d2  mov rax, 0x5AB2B8B81530
0000794c94dd34dc  call rax
0000794c94dd34de  movaps xmm14, [rsp]
0000794c94dd34e3  add rsp, 0x30
0000794c94dd34e7  vmovaps xmm0, [rsp]
0000794c94dd34ec  vmovaps xmm1, [rsp+0x10]
0000794c94dd34f2  vmovaps xmm2, [rsp+0x20]
0000794c94dd34f8  vmovaps xmm3, [rsp+0x30]
0000794c94dd34fe  vmovaps xmm4, [rsp+0x40]
0000794c94dd3504  vmovaps xmm5, [rsp+0x50]
0000794c94dd350a  vmovaps xmm6, [rsp+0x60]
0000794c94dd3510  vmovaps xmm7, [rsp+0x70]
0000794c94dd3516  vmovaps xmm8, [rsp+0x80]
0000794c94dd351f  vmovaps xmm9, [rsp+0x90]
0000794c94dd3528  vmovaps xmm10, [rsp+0xA0]
0000794c94dd3531  vmovaps xmm11, [rsp+0xB0]
0000794c94dd353a  vmovaps xmm12, [rsp+0xC0]
0000794c94dd3543  vmovaps xmm13, [rsp+0xD0]
0000794c94dd354c  vmovaps xmm15, [rsp+0xE0]
0000794c94dd3555  add rsp, 0xF0
0000794c94dd355c  pop r11
0000794c94dd355e  pop r10
0000794c94dd3560  pop r9
0000794c94dd3562  pop r8
0000794c94dd3564  pop rsi
0000794c94dd3565  pop rdi
0000794c94dd3566  pop rdx
0000794c94dd3567  pop rcx
0000794c94dd3568  pop rax
0000794c94dd3569  add rsp, 0x08
0000794c94dd356d  jmp 0x0000794C94DCFEF1
0000794c94dd3572  sub rsp, 0x08
0000794c94dd3576  push rax
0000794c94dd3577  push rcx
0000794c94dd3578  push rdx
0000794c94dd3579  push rdi
0000794c94dd357a  push rsi
0000794c94dd357b  push r8
0000794c94dd357d  push r9
0000794c94dd357f  push r10
0000794c94dd3581  push r11
0000794c94dd3583  sub rsp, 0xF0
0000794c94dd358a  vmovaps [rsp], xmm0
0000794c94dd358f  vmovaps [rsp+0x10], xmm1
0000794c94dd3595  vmovaps [rsp+0x20], xmm2
0000794c94dd359b  vmovaps [rsp+0x30], xmm3
0000794c94dd35a1  vmovaps [rsp+0x40], xmm4
0000794c94dd35a7  vmovaps [rsp+0x50], xmm5
0000794c94dd35ad  vmovaps [rsp+0x60], xmm7
0000794c94dd35b3  vmovaps [rsp+0x70], xmm8
0000794c94dd35b9  vmovaps [rsp+0x80], xmm9
0000794c94dd35c2  vmovaps [rsp+0x90], xmm10
0000794c94dd35cb  vmovaps [rsp+0xA0], xmm11
0000794c94dd35d4  vmovaps [rsp+0xB0], xmm12
0000794c94dd35dd  vmovaps [rsp+0xC0], xmm13
0000794c94dd35e6  vmovaps [rsp+0xD0], xmm14
0000794c94dd35ef  vmovaps [rsp+0xE0], xmm15
0000794c94dd35f8  sub rsp, 0x30
0000794c94dd35fc  movaps [rsp], xmm6
0000794c94dd3600  movaps [rsp+0x10], xmm9
0000794c94dd3606  movaps [rsp+0x20], xmm12
0000794c94dd360c  lea rdi, [rsp]
0000794c94dd3610  mov esi, 0x00
0000794c94dd3615  mov rax, 0x5AB2B8B81530
0000794c94dd361f  call rax
0000794c94dd3621  movaps xmm6, [rsp]
0000794c94dd3625  add rsp, 0x30
0000794c94dd3629  vmovaps xmm0, [rsp]
0000794c94dd362e  vmovaps xmm1, [rsp+0x10]
0000794c94dd3634  vmovaps xmm2, [rsp+0x20]
0000794c94dd363a  vmovaps xmm3, [rsp+0x30]
0000794c94dd3640  vmovaps xmm4, [rsp+0x40]
0000794c94dd3646  vmovaps xmm5, [rsp+0x50]
0000794c94dd364c  vmovaps xmm7, [rsp+0x60]
0000794c94dd3652  vmovaps xmm8, [rsp+0x70]
0000794c94dd3658  vmovaps xmm9, [rsp+0x80]
0000794c94dd3661  vmovaps xmm10, [rsp+0x90]
0000794c94dd366a  vmovaps xmm11, [rsp+0xA0]
0000794c94dd3673  vmovaps xmm12, [rsp+0xB0]
0000794c94dd367c  vmovaps xmm13, [rsp+0xC0]
0000794c94dd3685  vmovaps xmm14, [rsp+0xD0]
0000794c94dd368e  vmovaps xmm15, [rsp+0xE0]
0000794c94dd3697  add rsp, 0xF0
0000794c94dd369e  pop r11
0000794c94dd36a0  pop r10
0000794c94dd36a2  pop r9
0000794c94dd36a4  pop r8
0000794c94dd36a6  pop rsi
0000794c94dd36a7  pop rdi
0000794c94dd36a8  pop rdx
0000794c94dd36a9  pop rcx
0000794c94dd36aa  pop rax
0000794c94dd36ab  add rsp, 0x08
0000794c94dd36af  jmp 0x0000794C94DCFF19
0000794c94dd36b4  sub rsp, 0x08
0000794c94dd36b8  push rax
0000794c94dd36b9  push rcx
0000794c94dd36ba  push rdx
0000794c94dd36bb  push rdi
0000794c94dd36bc  push rsi
0000794c94dd36bd  push r8
0000794c94dd36bf  push r9
0000794c94dd36c1  push r10
0000794c94dd36c3  push r11
0000794c94dd36c5  sub rsp, 0xF0
0000794c94dd36cc  vmovaps [rsp], xmm0
0000794c94dd36d1  vmovaps [rsp+0x10], xmm1
0000794c94dd36d7  vmovaps [rsp+0x20], xmm2
0000794c94dd36dd  vmovaps [rsp+0x30], xmm3
0000794c94dd36e3  vmovaps [rsp+0x40], xmm4
0000794c94dd36e9  vmovaps [rsp+0x50], xmm5
0000794c94dd36ef  vmovaps [rsp+0x60], xmm6
0000794c94dd36f5  vmovaps [rsp+0x70], xmm7
0000794c94dd36fb  vmovaps [rsp+0x80], xmm8
0000794c94dd3704  vmovaps [rsp+0x90], xmm9
0000794c94dd370d  vmovaps [rsp+0xA0], xmm10
0000794c94dd3716  vmovaps [rsp+0xB0], xmm11
0000794c94dd371f  vmovaps [rsp+0xC0], xmm13
0000794c94dd3728  vmovaps [rsp+0xD0], xmm14
0000794c94dd3731  vmovaps [rsp+0xE0], xmm15
0000794c94dd373a  sub rsp, 0x30
0000794c94dd373e  movaps [rsp], xmm12
0000794c94dd3743  movaps [rsp+0x10], xmm15
0000794c94dd3749  movaps [rsp+0x20], xmm13
0000794c94dd374f  lea rdi, [rsp]
0000794c94dd3753  mov esi, 0x00
0000794c94dd3758  mov rax, 0x5AB2B8B81530
0000794c94dd3762  call rax
0000794c94dd3764  movaps xmm12, [rsp]
0000794c94dd3769  add rsp, 0x30
0000794c94dd376d  vmovaps xmm0, [rsp]
0000794c94dd3772  vmovaps xmm1, [rsp+0x10]
0000794c94dd3778  vmovaps xmm2, [rsp+0x20]
0000794c94dd377e  vmovaps xmm3, [rsp+0x30]
0000794c94dd3784  vmovaps xmm4, [rsp+0x40]
0000794c94dd378a  vmovaps xmm5, [rsp+0x50]
0000794c94dd3790  vmovaps xmm6, [rsp+0x60]
0000794c94dd3796  vmovaps xmm7, [rsp+0x70]
0000794c94dd379c  vmovaps xmm8, [rsp+0x80]
0000794c94dd37a5  vmovaps xmm9, [rsp+0x90]
0000794c94dd37ae  vmovaps xmm10, [rsp+0xA0]
0000794c94dd37b7  vmovaps xmm11, [rsp+0xB0]
0000794c94dd37c0  vmovaps xmm13, [rsp+0xC0]
0000794c94dd37c9  vmovaps xmm14, [rsp+0xD0]
0000794c94dd37d2  vmovaps xmm15, [rsp+0xE0]
0000794c94dd37db  add rsp, 0xF0
0000794c94dd37e2  pop r11
0000794c94dd37e4  pop r10
0000794c94dd37e6  pop r9
0000794c94dd37e8  pop r8
0000794c94dd37ea  pop rsi
0000794c94dd37eb  pop rdi
0000794c94dd37ec  pop rdx
0000794c94dd37ed  pop rcx
0000794c94dd37ee  pop rax
0000794c94dd37ef  add rsp, 0x08
0000794c94dd37f3  jmp 0x0000794C94DCFF34
0000794c94dd37f8  sub rsp, 0x08
0000794c94dd37fc  push rax
0000794c94dd37fd  push rcx
0000794c94dd37fe  push rdx
0000794c94dd37ff  push rdi
0000794c94dd3800  push rsi
0000794c94dd3801  push r8
0000794c94dd3803  push r9
0000794c94dd3805  push r10
0000794c94dd3807  push r11
0000794c94dd3809  sub rsp, 0xF0
0000794c94dd3810  vmovaps [rsp], xmm0
0000794c94dd3815  vmovaps [rsp+0x10], xmm1
0000794c94dd381b  vmovaps [rsp+0x20], xmm2
0000794c94dd3821  vmovaps [rsp+0x30], xmm3
0000794c94dd3827  vmovaps [rsp+0x40], xmm4
0000794c94dd382d  vmovaps [rsp+0x50], xmm5
0000794c94dd3833  vmovaps [rsp+0x60], xmm6
0000794c94dd3839  vmovaps [rsp+0x70], xmm7
0000794c94dd383f  vmovaps [rsp+0x80], xmm8
0000794c94dd3848  vmovaps [rsp+0x90], xmm9
0000794c94dd3851  vmovaps [rsp+0xA0], xmm10
0000794c94dd385a  vmovaps [rsp+0xB0], xmm11
0000794c94dd3863  vmovaps [rsp+0xC0], xmm12
0000794c94dd386c  vmovaps [rsp+0xD0], xmm13
0000794c94dd3875  vmovaps [rsp+0xE0], xmm14
0000794c94dd387e  sub rsp, 0x30
0000794c94dd3882  movaps [rsp], xmm15
0000794c94dd3887  movaps [rsp+0x10], xmm13
0000794c94dd388d  movaps [rsp+0x20], xmm10
0000794c94dd3893  lea rdi, [rsp]
0000794c94dd3897  mov esi, 0x00
0000794c94dd389c  mov rax, 0x5AB2B8B81530
0000794c94dd38a6  call rax
0000794c94dd38a8  movaps xmm15, [rsp]
0000794c94dd38ad  add rsp, 0x30
0000794c94dd38b1  vmovaps xmm0, [rsp]
0000794c94dd38b6  vmovaps xmm1, [rsp+0x10]
0000794c94dd38bc  vmovaps xmm2, [rsp+0x20]
0000794c94dd38c2  vmovaps xmm3, [rsp+0x30]
0000794c94dd38c8  vmovaps xmm4, [rsp+0x40]
0000794c94dd38ce  vmovaps xmm5, [rsp+0x50]
0000794c94dd38d4  vmovaps xmm6, [rsp+0x60]
0000794c94dd38da  vmovaps xmm7, [rsp+0x70]
0000794c94dd38e0  vmovaps xmm8, [rsp+0x80]
0000794c94dd38e9  vmovaps xmm9, [rsp+0x90]
0000794c94dd38f2  vmovaps xmm10, [rsp+0xA0]
0000794c94dd38fb  vmovaps xmm11, [rsp+0xB0]
0000794c94dd3904  vmovaps xmm12, [rsp+0xC0]
0000794c94dd390d  vmovaps xmm13, [rsp+0xD0]
0000794c94dd3916  vmovaps xmm14, [rsp+0xE0]
0000794c94dd391f  add rsp, 0xF0
0000794c94dd3926  pop r11
0000794c94dd3928  pop r10
0000794c94dd392a  pop r9
0000794c94dd392c  pop r8
0000794c94dd392e  pop rsi
0000794c94dd392f  pop rdi
0000794c94dd3930  pop rdx
0000794c94dd3931  pop rcx
0000794c94dd3932  pop rax
0000794c94dd3933  add rsp, 0x08
0000794c94dd3937  jmp 0x0000794C94DCFF55
0000794c94dd393c  call 0x0000794C94C0C260
0000794c94dd3941  jmp 0x0000794C94DCFFB0
0000794c94dd3946  sub rsp, 0x08
0000794c94dd394a  push rax
0000794c94dd394b  push rcx
0000794c94dd394c  push rdx
0000794c94dd394d  push rdi
0000794c94dd394e  push rsi
0000794c94dd394f  push r8
0000794c94dd3951  push r9
0000794c94dd3953  push r10
0000794c94dd3955  push r11
0000794c94dd3957  sub rsp, 0xF0
0000794c94dd395e  vmovaps [rsp], xmm0
0000794c94dd3963  vmovaps [rsp+0x10], xmm1
0000794c94dd3969  vmovaps [rsp+0x20], xmm2
0000794c94dd396f  vmovaps [rsp+0x30], xmm3
0000794c94dd3975  vmovaps [rsp+0x40], xmm4
0000794c94dd397b  vmovaps [rsp+0x50], xmm5
0000794c94dd3981  vmovaps [rsp+0x60], xmm6
0000794c94dd3987  vmovaps [rsp+0x70], xmm7
0000794c94dd398d  vmovaps [rsp+0x80], xmm8
0000794c94dd3996  vmovaps [rsp+0x90], xmm10
0000794c94dd399f  vmovaps [rsp+0xA0], xmm11
0000794c94dd39a8  vmovaps [rsp+0xB0], xmm12
0000794c94dd39b1  vmovaps [rsp+0xC0], xmm13
0000794c94dd39ba  vmovaps [rsp+0xD0], xmm14
0000794c94dd39c3  vmovaps [rsp+0xE0], xmm15
0000794c94dd39cc  sub rsp, 0x30
0000794c94dd39d0  movaps [rsp], xmm9
0000794c94dd39d5  movaps [rsp+0x10], xmm8
0000794c94dd39db  movaps [rsp+0x20], xmm10
0000794c94dd39e1  lea rdi, [rsp]
0000794c94dd39e5  mov esi, 0x00
0000794c94dd39ea  mov rax, 0x5AB2B8B81530
0000794c94dd39f4  call rax
0000794c94dd39f6  movaps xmm9, [rsp]
0000794c94dd39fb  add rsp, 0x30
0000794c94dd39ff  vmovaps xmm0, [rsp]
0000794c94dd3a04  vmovaps xmm1, [rsp+0x10]
0000794c94dd3a0a  vmovaps xmm2, [rsp+0x20]
0000794c94dd3a10  vmovaps xmm3, [rsp+0x30]
0000794c94dd3a16  vmovaps xmm4, [rsp+0x40]
0000794c94dd3a1c  vmovaps xmm5, [rsp+0x50]
0000794c94dd3a22  vmovaps xmm6, [rsp+0x60]
0000794c94dd3a28  vmovaps xmm7, [rsp+0x70]
0000794c94dd3a2e  vmovaps xmm8, [rsp+0x80]
0000794c94dd3a37  vmovaps xmm10, [rsp+0x90]
0000794c94dd3a40  vmovaps xmm11, [rsp+0xA0]
0000794c94dd3a49  vmovaps xmm12, [rsp+0xB0]
0000794c94dd3a52  vmovaps xmm13, [rsp+0xC0]
0000794c94dd3a5b  vmovaps xmm14, [rsp+0xD0]
0000794c94dd3a64  vmovaps xmm15, [rsp+0xE0]
0000794c94dd3a6d  add rsp, 0xF0
0000794c94dd3a74  pop r11
0000794c94dd3a76  pop r10
0000794c94dd3a78  pop r9
0000794c94dd3a7a  pop r8
0000794c94dd3a7c  pop rsi
0000794c94dd3a7d  pop rdi
0000794c94dd3a7e  pop rdx
0000794c94dd3a7f  pop rcx
0000794c94dd3a80  pop rax
0000794c94dd3a81  add rsp, 0x08
0000794c94dd3a85  jmp 0x0000794C94DCFFE1
0000794c94dd3a8a  sub rsp, 0x08
0000794c94dd3a8e  push rax
0000794c94dd3a8f  push rcx
0000794c94dd3a90  push rdx
0000794c94dd3a91  push rdi
0000794c94dd3a92  push rsi
0000794c94dd3a93  push r8
0000794c94dd3a95  push r9
0000794c94dd3a97  push r10
0000794c94dd3a99  push r11
0000794c94dd3a9b  sub rsp, 0xF0
0000794c94dd3aa2  vmovaps [rsp], xmm0
0000794c94dd3aa7  vmovaps [rsp+0x10], xmm1
0000794c94dd3aad  vmovaps [rsp+0x20], xmm2
0000794c94dd3ab3  vmovaps [rsp+0x30], xmm3
0000794c94dd3ab9  vmovaps [rsp+0x40], xmm4
0000794c94dd3abf  vmovaps [rsp+0x50], xmm5
0000794c94dd3ac5  vmovaps [rsp+0x60], xmm6
0000794c94dd3acb  vmovaps [rsp+0x70], xmm7
0000794c94dd3ad1  vmovaps [rsp+0x80], xmm8
0000794c94dd3ada  vmovaps [rsp+0x90], xmm9
0000794c94dd3ae3  vmovaps [rsp+0xA0], xmm11
0000794c94dd3aec  vmovaps [rsp+0xB0], xmm12
0000794c94dd3af5  vmovaps [rsp+0xC0], xmm13
0000794c94dd3afe  vmovaps [rsp+0xD0], xmm14
0000794c94dd3b07  vmovaps [rsp+0xE0], xmm15
0000794c94dd3b10  sub rsp, 0x30
0000794c94dd3b14  movaps [rsp], xmm10
0000794c94dd3b19  movaps [rsp+0x10], xmm1
0000794c94dd3b1e  movaps [rsp+0x20], xmm11
0000794c94dd3b24  lea rdi, [rsp]
0000794c94dd3b28  mov esi, 0x00
0000794c94dd3b2d  mov rax, 0x5AB2B8B81530
0000794c94dd3b37  call rax
0000794c94dd3b39  movaps xmm10, [rsp]
0000794c94dd3b3e  add rsp, 0x30
0000794c94dd3b42  vmovaps xmm0, [rsp]
0000794c94dd3b47  vmovaps xmm1, [rsp+0x10]
0000794c94dd3b4d  vmovaps xmm2, [rsp+0x20]
0000794c94dd3b53  vmovaps xmm3, [rsp+0x30]
0000794c94dd3b59  vmovaps xmm4, [rsp+0x40]
0000794c94dd3b5f  vmovaps xmm5, [rsp+0x50]
0000794c94dd3b65  vmovaps xmm6, [rsp+0x60]
0000794c94dd3b6b  vmovaps xmm7, [rsp+0x70]
0000794c94dd3b71  vmovaps xmm8, [rsp+0x80]
0000794c94dd3b7a  vmovaps xmm9, [rsp+0x90]
0000794c94dd3b83  vmovaps xmm11, [rsp+0xA0]
0000794c94dd3b8c  vmovaps xmm12, [rsp+0xB0]
0000794c94dd3b95  vmovaps xmm13, [rsp+0xC0]
0000794c94dd3b9e  vmovaps xmm14, [rsp+0xD0]
0000794c94dd3ba7  vmovaps xmm15, [rsp+0xE0]
0000794c94dd3bb0  add rsp, 0xF0
0000794c94dd3bb7  pop r11
0000794c94dd3bb9  pop r10
0000794c94dd3bbb  pop r9
0000794c94dd3bbd  pop r8
0000794c94dd3bbf  pop rsi
0000794c94dd3bc0  pop rdi
0000794c94dd3bc1  pop rdx
0000794c94dd3bc2  pop rcx
0000794c94dd3bc3  pop rax
0000794c94dd3bc4  add rsp, 0x08
0000794c94dd3bc8  jmp 0x0000794C94DCFFFC
0000794c94dd3bcd  sub rsp, 0x08
0000794c94dd3bd1  push rax
0000794c94dd3bd2  push rcx
0000794c94dd3bd3  push rdx
0000794c94dd3bd4  push rdi
0000794c94dd3bd5  push rsi
0000794c94dd3bd6  push r8
0000794c94dd3bd8  push r9
0000794c94dd3bda  push r10
0000794c94dd3bdc  push r11
0000794c94dd3bde  sub rsp, 0xF0
0000794c94dd3be5  vmovaps [rsp], xmm0
0000794c94dd3bea  vmovaps [rsp+0x10], xmm2
0000794c94dd3bf0  vmovaps [rsp+0x20], xmm3
0000794c94dd3bf6  vmovaps [rsp+0x30], xmm4
0000794c94dd3bfc  vmovaps [rsp+0x40], xmm5
0000794c94dd3c02  vmovaps [rsp+0x50], xmm6
0000794c94dd3c08  vmovaps [rsp+0x60], xmm7
0000794c94dd3c0e  vmovaps [rsp+0x70], xmm8
0000794c94dd3c14  vmovaps [rsp+0x80], xmm9
0000794c94dd3c1d  vmovaps [rsp+0x90], xmm10
0000794c94dd3c26  vmovaps [rsp+0xA0], xmm11
0000794c94dd3c2f  vmovaps [rsp+0xB0], xmm12
0000794c94dd3c38  vmovaps [rsp+0xC0], xmm13
0000794c94dd3c41  vmovaps [rsp+0xD0], xmm14
0000794c94dd3c4a  vmovaps [rsp+0xE0], xmm15
0000794c94dd3c53  sub rsp, 0x30
0000794c94dd3c57  movaps [rsp], xmm1
0000794c94dd3c5b  movaps [rsp+0x10], xmm14
0000794c94dd3c61  movaps [rsp+0x20], xmm6
0000794c94dd3c66  lea rdi, [rsp]
0000794c94dd3c6a  mov esi, 0x00
0000794c94dd3c6f  mov rax, 0x5AB2B8B81530
0000794c94dd3c79  call rax
0000794c94dd3c7b  movaps xmm1, [rsp]
0000794c94dd3c7f  add rsp, 0x30
0000794c94dd3c83  vmovaps xmm0, [rsp]
0000794c94dd3c88  vmovaps xmm2, [rsp+0x10]
0000794c94dd3c8e  vmovaps xmm3, [rsp+0x20]
0000794c94dd3c94  vmovaps xmm4, [rsp+0x30]
0000794c94dd3c9a  vmovaps xmm5, [rsp+0x40]
0000794c94dd3ca0  vmovaps xmm6, [rsp+0x50]
0000794c94dd3ca6  vmovaps xmm7, [rsp+0x60]
0000794c94dd3cac  vmovaps xmm8, [rsp+0x70]
0000794c94dd3cb2  vmovaps xmm9, [rsp+0x80]
0000794c94dd3cbb  vmovaps xmm10, [rsp+0x90]
0000794c94dd3cc4  vmovaps xmm11, [rsp+0xA0]
0000794c94dd3ccd  vmovaps xmm12, [rsp+0xB0]
0000794c94dd3cd6  vmovaps xmm13, [rsp+0xC0]
0000794c94dd3cdf  vmovaps xmm14, [rsp+0xD0]
0000794c94dd3ce8  vmovaps xmm15, [rsp+0xE0]
0000794c94dd3cf1  add rsp, 0xF0
0000794c94dd3cf8  pop r11
0000794c94dd3cfa  pop r10
0000794c94dd3cfc  pop r9
0000794c94dd3cfe  pop r8
0000794c94dd3d00  pop rsi
0000794c94dd3d01  pop rdi
0000794c94dd3d02  pop rdx
0000794c94dd3d03  pop rcx
0000794c94dd3d04  pop rax
0000794c94dd3d05  add rsp, 0x08
0000794c94dd3d09  jmp 0x0000794C94DD0015
0000794c94dd3d0e  sub rsp, 0x08
0000794c94dd3d12  push rax
0000794c94dd3d13  push rcx
0000794c94dd3d14  push rdx
0000794c94dd3d15  push rdi
0000794c94dd3d16  push rsi
0000794c94dd3d17  push r8
0000794c94dd3d19  push r9
0000794c94dd3d1b  push r10
0000794c94dd3d1d  push r11
0000794c94dd3d1f  sub rsp, 0xF0
0000794c94dd3d26  vmovaps [rsp], xmm0
0000794c94dd3d2b  vmovaps [rsp+0x10], xmm1
0000794c94dd3d31  vmovaps [rsp+0x20], xmm2
0000794c94dd3d37  vmovaps [rsp+0x30], xmm3
0000794c94dd3d3d  vmovaps [rsp+0x40], xmm4
0000794c94dd3d43  vmovaps [rsp+0x50], xmm5
0000794c94dd3d49  vmovaps [rsp+0x60], xmm6
0000794c94dd3d4f  vmovaps [rsp+0x70], xmm7
0000794c94dd3d55  vmovaps [rsp+0x80], xmm8
0000794c94dd3d5e  vmovaps [rsp+0x90], xmm9
0000794c94dd3d67  vmovaps [rsp+0xA0], xmm10
0000794c94dd3d70  vmovaps [rsp+0xB0], xmm12
0000794c94dd3d79  vmovaps [rsp+0xC0], xmm13
0000794c94dd3d82  vmovaps [rsp+0xD0], xmm14
0000794c94dd3d8b  vmovaps [rsp+0xE0], xmm15
0000794c94dd3d94  sub rsp, 0x30
0000794c94dd3d98  movaps [rsp], xmm11
0000794c94dd3d9d  movaps [rsp+0x10], xmm13
0000794c94dd3da3  movaps [rsp+0x20], xmm14
0000794c94dd3da9  lea rdi, [rsp]
0000794c94dd3dad  mov esi, 0x00
0000794c94dd3db2  mov rax, 0x5AB2B8B81530
0000794c94dd3dbc  call rax
0000794c94dd3dbe  movaps xmm11, [rsp]
0000794c94dd3dc3  add rsp, 0x30
0000794c94dd3dc7  vmovaps xmm0, [rsp]
0000794c94dd3dcc  vmovaps xmm1, [rsp+0x10]
0000794c94dd3dd2  vmovaps xmm2, [rsp+0x20]
0000794c94dd3dd8  vmovaps xmm3, [rsp+0x30]
0000794c94dd3dde  vmovaps xmm4, [rsp+0x40]
0000794c94dd3de4  vmovaps xmm5, [rsp+0x50]
0000794c94dd3dea  vmovaps xmm6, [rsp+0x60]
0000794c94dd3df0  vmovaps xmm7, [rsp+0x70]
0000794c94dd3df6  vmovaps xmm8, [rsp+0x80]
0000794c94dd3dff  vmovaps xmm9, [rsp+0x90]
0000794c94dd3e08  vmovaps xmm10, [rsp+0xA0]
0000794c94dd3e11  vmovaps xmm12, [rsp+0xB0]
0000794c94dd3e1a  vmovaps xmm13, [rsp+0xC0]
0000794c94dd3e23  vmovaps xmm14, [rsp+0xD0]
0000794c94dd3e2c  vmovaps xmm15, [rsp+0xE0]
0000794c94dd3e35  add rsp, 0xF0
0000794c94dd3e3c  pop r11
0000794c94dd3e3e  pop r10
0000794c94dd3e40  pop r9
0000794c94dd3e42  pop r8
0000794c94dd3e44  pop rsi
0000794c94dd3e45  pop rdi
0000794c94dd3e46  pop rdx
0000794c94dd3e47  pop rcx
0000794c94dd3e48  pop rax
0000794c94dd3e49  add rsp, 0x08
0000794c94dd3e4d  jmp 0x0000794C94DD003F
0000794c94dd3e52  sub rsp, 0x08
0000794c94dd3e56  push rax
0000794c94dd3e57  push rcx
0000794c94dd3e58  push rdx
0000794c94dd3e59  push rdi
0000794c94dd3e5a  push rsi
0000794c94dd3e5b  push r8
0000794c94dd3e5d  push r9
0000794c94dd3e5f  push r10
0000794c94dd3e61  push r11
0000794c94dd3e63  sub rsp, 0xF0
0000794c94dd3e6a  vmovaps [rsp], xmm0
0000794c94dd3e6f  vmovaps [rsp+0x10], xmm1
0000794c94dd3e75  vmovaps [rsp+0x20], xmm2
0000794c94dd3e7b  vmovaps [rsp+0x30], xmm3
0000794c94dd3e81  vmovaps [rsp+0x40], xmm4
0000794c94dd3e87  vmovaps [rsp+0x50], xmm5
0000794c94dd3e8d  vmovaps [rsp+0x60], xmm6
0000794c94dd3e93  vmovaps [rsp+0x70], xmm7
0000794c94dd3e99  vmovaps [rsp+0x80], xmm8
0000794c94dd3ea2  vmovaps [rsp+0x90], xmm9
0000794c94dd3eab  vmovaps [rsp+0xA0], xmm10
0000794c94dd3eb4  vmovaps [rsp+0xB0], xmm11
0000794c94dd3ebd  vmovaps [rsp+0xC0], xmm12
0000794c94dd3ec6  vmovaps [rsp+0xD0], xmm14
0000794c94dd3ecf  vmovaps [rsp+0xE0], xmm15
0000794c94dd3ed8  sub rsp, 0x30
0000794c94dd3edc  movaps [rsp], xmm13
0000794c94dd3ee1  movaps [rsp+0x10], xmm8
0000794c94dd3ee7  movaps [rsp+0x20], xmm14
0000794c94dd3eed  lea rdi, [rsp]
0000794c94dd3ef1  mov esi, 0x00
0000794c94dd3ef6  mov rax, 0x5AB2B8B81530
0000794c94dd3f00  call rax
0000794c94dd3f02  movaps xmm13, [rsp]
0000794c94dd3f07  add rsp, 0x30
0000794c94dd3f0b  vmovaps xmm0, [rsp]
0000794c94dd3f10  vmovaps xmm1, [rsp+0x10]
0000794c94dd3f16  vmovaps xmm2, [rsp+0x20]
0000794c94dd3f1c  vmovaps xmm3, [rsp+0x30]
0000794c94dd3f22  vmovaps xmm4, [rsp+0x40]
0000794c94dd3f28  vmovaps xmm5, [rsp+0x50]
0000794c94dd3f2e  vmovaps xmm6, [rsp+0x60]
0000794c94dd3f34  vmovaps xmm7, [rsp+0x70]
0000794c94dd3f3a  vmovaps xmm8, [rsp+0x80]
0000794c94dd3f43  vmovaps xmm9, [rsp+0x90]
0000794c94dd3f4c  vmovaps xmm10, [rsp+0xA0]
0000794c94dd3f55  vmovaps xmm11, [rsp+0xB0]
0000794c94dd3f5e  vmovaps xmm12, [rsp+0xC0]
0000794c94dd3f67  vmovaps xmm14, [rsp+0xD0]
0000794c94dd3f70  vmovaps xmm15, [rsp+0xE0]
0000794c94dd3f79  add rsp, 0xF0
0000794c94dd3f80  pop r11
0000794c94dd3f82  pop r10
0000794c94dd3f84  pop r9
0000794c94dd3f86  pop r8
0000794c94dd3f88  pop rsi
0000794c94dd3f89  pop rdi
0000794c94dd3f8a  pop rdx
0000794c94dd3f8b  pop rcx
0000794c94dd3f8c  pop rax
0000794c94dd3f8d  add rsp, 0x08
0000794c94dd3f91  jmp 0x0000794C94DD006E
0000794c94dd3f96  sub rsp, 0x08
0000794c94dd3f9a  push rax
0000794c94dd3f9b  push rcx
0000794c94dd3f9c  push rdx
0000794c94dd3f9d  push rdi
0000794c94dd3f9e  push rsi
0000794c94dd3f9f  push r8
0000794c94dd3fa1  push r9
0000794c94dd3fa3  push r10
0000794c94dd3fa5  push r11
0000794c94dd3fa7  sub rsp, 0xF0
0000794c94dd3fae  vmovaps [rsp], xmm0
0000794c94dd3fb3  vmovaps [rsp+0x10], xmm1
0000794c94dd3fb9  vmovaps [rsp+0x20], xmm2
0000794c94dd3fbf  vmovaps [rsp+0x30], xmm3
0000794c94dd3fc5  vmovaps [rsp+0x40], xmm4
0000794c94dd3fcb  vmovaps [rsp+0x50], xmm5
0000794c94dd3fd1  vmovaps [rsp+0x60], xmm6
0000794c94dd3fd7  vmovaps [rsp+0x70], xmm7
0000794c94dd3fdd  vmovaps [rsp+0x80], xmm9
0000794c94dd3fe6  vmovaps [rsp+0x90], xmm10
0000794c94dd3fef  vmovaps [rsp+0xA0], xmm11
0000794c94dd3ff8  vmovaps [rsp+0xB0], xmm12
0000794c94dd4001  vmovaps [rsp+0xC0], xmm13
0000794c94dd400a  vmovaps [rsp+0xD0], xmm14
0000794c94dd4013  vmovaps [rsp+0xE0], xmm15
0000794c94dd401c  sub rsp, 0x30
0000794c94dd4020  movaps [rsp], xmm8
0000794c94dd4025  movaps [rsp+0x10], xmm7
0000794c94dd402a  movaps [rsp+0x20], xmm14
0000794c94dd4030  lea rdi, [rsp]
0000794c94dd4034  mov esi, 0x00
0000794c94dd4039  mov rax, 0x5AB2B8B81530
0000794c94dd4043  call rax
0000794c94dd4045  movaps xmm8, [rsp]
0000794c94dd404a  add rsp, 0x30
0000794c94dd404e  vmovaps xmm0, [rsp]
0000794c94dd4053  vmovaps xmm1, [rsp+0x10]
0000794c94dd4059  vmovaps xmm2, [rsp+0x20]
0000794c94dd405f  vmovaps xmm3, [rsp+0x30]
0000794c94dd4065  vmovaps xmm4, [rsp+0x40]
0000794c94dd406b  vmovaps xmm5, [rsp+0x50]
0000794c94dd4071  vmovaps xmm6, [rsp+0x60]
0000794c94dd4077  vmovaps xmm7, [rsp+0x70]
0000794c94dd407d  vmovaps xmm9, [rsp+0x80]
0000794c94dd4086  vmovaps xmm10, [rsp+0x90]
0000794c94dd408f  vmovaps xmm11, [rsp+0xA0]
0000794c94dd4098  vmovaps xmm12, [rsp+0xB0]
0000794c94dd40a1  vmovaps xmm13, [rsp+0xC0]
0000794c94dd40aa  vmovaps xmm14, [rsp+0xD0]
0000794c94dd40b3  vmovaps xmm15, [rsp+0xE0]
0000794c94dd40bc  add rsp, 0xF0
0000794c94dd40c3  pop r11
0000794c94dd40c5  pop r10
0000794c94dd40c7  pop r9
0000794c94dd40c9  pop r8
0000794c94dd40cb  pop rsi
0000794c94dd40cc  pop rdi
0000794c94dd40cd  pop rdx
0000794c94dd40ce  pop rcx
0000794c94dd40cf  pop rax
0000794c94dd40d0  add rsp, 0x08
0000794c94dd40d4  jmp 0x0000794C94DD0094
0000794c94dd40d9  sub rsp, 0x08
0000794c94dd40dd  push rax
0000794c94dd40de  push rcx
0000794c94dd40df  push rdx
0000794c94dd40e0  push rdi
0000794c94dd40e1  push rsi
0000794c94dd40e2  push r8
0000794c94dd40e4  push r9
0000794c94dd40e6  push r10
0000794c94dd40e8  push r11
0000794c94dd40ea  sub rsp, 0xF0
0000794c94dd40f1  vmovaps [rsp], xmm0
0000794c94dd40f6  vmovaps [rsp+0x10], xmm1
0000794c94dd40fc  vmovaps [rsp+0x20], xmm2
0000794c94dd4102  vmovaps [rsp+0x30], xmm3
0000794c94dd4108  vmovaps [rsp+0x40], xmm4
0000794c94dd410e  vmovaps [rsp+0x50], xmm5
0000794c94dd4114  vmovaps [rsp+0x60], xmm6
0000794c94dd411a  vmovaps [rsp+0x70], xmm7
0000794c94dd4120  vmovaps [rsp+0x80], xmm8
0000794c94dd4129  vmovaps [rsp+0x90], xmm9
0000794c94dd4132  vmovaps [rsp+0xA0], xmm10
0000794c94dd413b  vmovaps [rsp+0xB0], xmm11
0000794c94dd4144  vmovaps [rsp+0xC0], xmm12
0000794c94dd414d  vmovaps [rsp+0xD0], xmm13
0000794c94dd4156  vmovaps [rsp+0xE0], xmm15
0000794c94dd415f  sub rsp, 0x30
0000794c94dd4163  movaps [rsp], xmm14
0000794c94dd4168  movaps [rsp+0x10], xmm12
0000794c94dd416e  movaps [rsp+0x20], xmm9
0000794c94dd4174  lea rdi, [rsp]
0000794c94dd4178  mov esi, 0x00
0000794c94dd417d  mov rax, 0x5AB2B8B81530
0000794c94dd4187  call rax
0000794c94dd4189  movaps xmm14, [rsp]
0000794c94dd418e  add rsp, 0x30
0000794c94dd4192  vmovaps xmm0, [rsp]
0000794c94dd4197  vmovaps xmm1, [rsp+0x10]
0000794c94dd419d  vmovaps xmm2, [rsp+0x20]
0000794c94dd41a3  vmovaps xmm3, [rsp+0x30]
0000794c94dd41a9  vmovaps xmm4, [rsp+0x40]
0000794c94dd41af  vmovaps xmm5, [rsp+0x50]
0000794c94dd41b5  vmovaps xmm6, [rsp+0x60]
0000794c94dd41bb  vmovaps xmm7, [rsp+0x70]
0000794c94dd41c1  vmovaps xmm8, [rsp+0x80]
0000794c94dd41ca  vmovaps xmm9, [rsp+0x90]
0000794c94dd41d3  vmovaps xmm10, [rsp+0xA0]
0000794c94dd41dc  vmovaps xmm11, [rsp+0xB0]
0000794c94dd41e5  vmovaps xmm12, [rsp+0xC0]
0000794c94dd41ee  vmovaps xmm13, [rsp+0xD0]
0000794c94dd41f7  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4200  add rsp, 0xF0
0000794c94dd4207  pop r11
0000794c94dd4209  pop r10
0000794c94dd420b  pop r9
0000794c94dd420d  pop r8
0000794c94dd420f  pop rsi
0000794c94dd4210  pop rdi
0000794c94dd4211  pop rdx
0000794c94dd4212  pop rcx
0000794c94dd4213  pop rax
0000794c94dd4214  add rsp, 0x08
0000794c94dd4218  jmp 0x0000794C94DD00AE
0000794c94dd421d  sub rsp, 0x08
0000794c94dd4221  push rax
0000794c94dd4222  push rcx
0000794c94dd4223  push rdx
0000794c94dd4224  push rdi
0000794c94dd4225  push rsi
0000794c94dd4226  push r8
0000794c94dd4228  push r9
0000794c94dd422a  push r10
0000794c94dd422c  push r11
0000794c94dd422e  sub rsp, 0xF0
0000794c94dd4235  vmovaps [rsp], xmm0
0000794c94dd423a  vmovaps [rsp+0x10], xmm1
0000794c94dd4240  vmovaps [rsp+0x20], xmm2
0000794c94dd4246  vmovaps [rsp+0x30], xmm3
0000794c94dd424c  vmovaps [rsp+0x40], xmm4
0000794c94dd4252  vmovaps [rsp+0x50], xmm5
0000794c94dd4258  vmovaps [rsp+0x60], xmm6
0000794c94dd425e  vmovaps [rsp+0x70], xmm7
0000794c94dd4264  vmovaps [rsp+0x80], xmm8
0000794c94dd426d  vmovaps [rsp+0x90], xmm10
0000794c94dd4276  vmovaps [rsp+0xA0], xmm11
0000794c94dd427f  vmovaps [rsp+0xB0], xmm12
0000794c94dd4288  vmovaps [rsp+0xC0], xmm13
0000794c94dd4291  vmovaps [rsp+0xD0], xmm14
0000794c94dd429a  vmovaps [rsp+0xE0], xmm15
0000794c94dd42a3  sub rsp, 0x30
0000794c94dd42a7  movaps [rsp], xmm9
0000794c94dd42ac  movaps [rsp+0x10], xmm7
0000794c94dd42b1  movaps [rsp+0x20], xmm12
0000794c94dd42b7  lea rdi, [rsp]
0000794c94dd42bb  mov esi, 0x00
0000794c94dd42c0  mov rax, 0x5AB2B8B81530
0000794c94dd42ca  call rax
0000794c94dd42cc  movaps xmm9, [rsp]
0000794c94dd42d1  add rsp, 0x30
0000794c94dd42d5  vmovaps xmm0, [rsp]
0000794c94dd42da  vmovaps xmm1, [rsp+0x10]
0000794c94dd42e0  vmovaps xmm2, [rsp+0x20]
0000794c94dd42e6  vmovaps xmm3, [rsp+0x30]
0000794c94dd42ec  vmovaps xmm4, [rsp+0x40]
0000794c94dd42f2  vmovaps xmm5, [rsp+0x50]
0000794c94dd42f8  vmovaps xmm6, [rsp+0x60]
0000794c94dd42fe  vmovaps xmm7, [rsp+0x70]
0000794c94dd4304  vmovaps xmm8, [rsp+0x80]
0000794c94dd430d  vmovaps xmm10, [rsp+0x90]
0000794c94dd4316  vmovaps xmm11, [rsp+0xA0]
0000794c94dd431f  vmovaps xmm12, [rsp+0xB0]
0000794c94dd4328  vmovaps xmm13, [rsp+0xC0]
0000794c94dd4331  vmovaps xmm14, [rsp+0xD0]
0000794c94dd433a  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4343  add rsp, 0xF0
0000794c94dd434a  pop r11
0000794c94dd434c  pop r10
0000794c94dd434e  pop r9
0000794c94dd4350  pop r8
0000794c94dd4352  pop rsi
0000794c94dd4353  pop rdi
0000794c94dd4354  pop rdx
0000794c94dd4355  pop rcx
0000794c94dd4356  pop rax
0000794c94dd4357  add rsp, 0x08
0000794c94dd435b  jmp 0x0000794C94DD00DD
0000794c94dd4360  sub rsp, 0x08
0000794c94dd4364  push rax
0000794c94dd4365  push rcx
0000794c94dd4366  push rdx
0000794c94dd4367  push rdi
0000794c94dd4368  push rsi
0000794c94dd4369  push r8
0000794c94dd436b  push r9
0000794c94dd436d  push r10
0000794c94dd436f  push r11
0000794c94dd4371  sub rsp, 0xF0
0000794c94dd4378  vmovaps [rsp], xmm0
0000794c94dd437d  vmovaps [rsp+0x10], xmm1
0000794c94dd4383  vmovaps [rsp+0x20], xmm2
0000794c94dd4389  vmovaps [rsp+0x30], xmm3
0000794c94dd438f  vmovaps [rsp+0x40], xmm4
0000794c94dd4395  vmovaps [rsp+0x50], xmm5
0000794c94dd439b  vmovaps [rsp+0x60], xmm6
0000794c94dd43a1  vmovaps [rsp+0x70], xmm7
0000794c94dd43a7  vmovaps [rsp+0x80], xmm8
0000794c94dd43b0  vmovaps [rsp+0x90], xmm9
0000794c94dd43b9  vmovaps [rsp+0xA0], xmm10
0000794c94dd43c2  vmovaps [rsp+0xB0], xmm11
0000794c94dd43cb  vmovaps [rsp+0xC0], xmm13
0000794c94dd43d4  vmovaps [rsp+0xD0], xmm14
0000794c94dd43dd  vmovaps [rsp+0xE0], xmm15
0000794c94dd43e6  sub rsp, 0x30
0000794c94dd43ea  movaps [rsp], xmm12
0000794c94dd43ef  movaps [rsp+0x10], xmm15
0000794c94dd43f5  movaps [rsp+0x20], xmm11
0000794c94dd43fb  lea rdi, [rsp]
0000794c94dd43ff  mov esi, 0x00
0000794c94dd4404  mov rax, 0x5AB2B8B81530
0000794c94dd440e  call rax
0000794c94dd4410  movaps xmm12, [rsp]
0000794c94dd4415  add rsp, 0x30
0000794c94dd4419  vmovaps xmm0, [rsp]
0000794c94dd441e  vmovaps xmm1, [rsp+0x10]
0000794c94dd4424  vmovaps xmm2, [rsp+0x20]
0000794c94dd442a  vmovaps xmm3, [rsp+0x30]
0000794c94dd4430  vmovaps xmm4, [rsp+0x40]
0000794c94dd4436  vmovaps xmm5, [rsp+0x50]
0000794c94dd443c  vmovaps xmm6, [rsp+0x60]
0000794c94dd4442  vmovaps xmm7, [rsp+0x70]
0000794c94dd4448  vmovaps xmm8, [rsp+0x80]
0000794c94dd4451  vmovaps xmm9, [rsp+0x90]
0000794c94dd445a  vmovaps xmm10, [rsp+0xA0]
0000794c94dd4463  vmovaps xmm11, [rsp+0xB0]
0000794c94dd446c  vmovaps xmm13, [rsp+0xC0]
0000794c94dd4475  vmovaps xmm14, [rsp+0xD0]
0000794c94dd447e  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4487  add rsp, 0xF0
0000794c94dd448e  pop r11
0000794c94dd4490  pop r10
0000794c94dd4492  pop r9
0000794c94dd4494  pop r8
0000794c94dd4496  pop rsi
0000794c94dd4497  pop rdi
0000794c94dd4498  pop rdx
0000794c94dd4499  pop rcx
0000794c94dd449a  pop rax
0000794c94dd449b  add rsp, 0x08
0000794c94dd449f  jmp 0x0000794C94DD00F7
0000794c94dd44a4  sub rsp, 0x08
0000794c94dd44a8  push rax
0000794c94dd44a9  push rcx
0000794c94dd44aa  push rdx
0000794c94dd44ab  push rdi
0000794c94dd44ac  push rsi
0000794c94dd44ad  push r8
0000794c94dd44af  push r9
0000794c94dd44b1  push r10
0000794c94dd44b3  push r11
0000794c94dd44b5  sub rsp, 0xF0
0000794c94dd44bc  vmovaps [rsp], xmm0
0000794c94dd44c1  vmovaps [rsp+0x10], xmm1
0000794c94dd44c7  vmovaps [rsp+0x20], xmm2
0000794c94dd44cd  vmovaps [rsp+0x30], xmm3
0000794c94dd44d3  vmovaps [rsp+0x40], xmm4
0000794c94dd44d9  vmovaps [rsp+0x50], xmm5
0000794c94dd44df  vmovaps [rsp+0x60], xmm6
0000794c94dd44e5  vmovaps [rsp+0x70], xmm7
0000794c94dd44eb  vmovaps [rsp+0x80], xmm8
0000794c94dd44f4  vmovaps [rsp+0x90], xmm9
0000794c94dd44fd  vmovaps [rsp+0xA0], xmm10
0000794c94dd4506  vmovaps [rsp+0xB0], xmm12
0000794c94dd450f  vmovaps [rsp+0xC0], xmm13
0000794c94dd4518  vmovaps [rsp+0xD0], xmm14
0000794c94dd4521  vmovaps [rsp+0xE0], xmm15
0000794c94dd452a  sub rsp, 0x30
0000794c94dd452e  movaps [rsp], xmm11
0000794c94dd4533  movaps [rsp+0x10], xmm7
0000794c94dd4538  movaps [rsp+0x20], xmm15
0000794c94dd453e  lea rdi, [rsp]
0000794c94dd4542  mov esi, 0x00
0000794c94dd4547  mov rax, 0x5AB2B8B81530
0000794c94dd4551  call rax
0000794c94dd4553  movaps xmm11, [rsp]
0000794c94dd4558  add rsp, 0x30
0000794c94dd455c  vmovaps xmm0, [rsp]
0000794c94dd4561  vmovaps xmm1, [rsp+0x10]
0000794c94dd4567  vmovaps xmm2, [rsp+0x20]
0000794c94dd456d  vmovaps xmm3, [rsp+0x30]
0000794c94dd4573  vmovaps xmm4, [rsp+0x40]
0000794c94dd4579  vmovaps xmm5, [rsp+0x50]
0000794c94dd457f  vmovaps xmm6, [rsp+0x60]
0000794c94dd4585  vmovaps xmm7, [rsp+0x70]
0000794c94dd458b  vmovaps xmm8, [rsp+0x80]
0000794c94dd4594  vmovaps xmm9, [rsp+0x90]
0000794c94dd459d  vmovaps xmm10, [rsp+0xA0]
0000794c94dd45a6  vmovaps xmm12, [rsp+0xB0]
0000794c94dd45af  vmovaps xmm13, [rsp+0xC0]
0000794c94dd45b8  vmovaps xmm14, [rsp+0xD0]
0000794c94dd45c1  vmovaps xmm15, [rsp+0xE0]
0000794c94dd45ca  add rsp, 0xF0
0000794c94dd45d1  pop r11
0000794c94dd45d3  pop r10
0000794c94dd45d5  pop r9
0000794c94dd45d7  pop r8
0000794c94dd45d9  pop rsi
0000794c94dd45da  pop rdi
0000794c94dd45db  pop rdx
0000794c94dd45dc  pop rcx
0000794c94dd45dd  pop rax
0000794c94dd45de  add rsp, 0x08
0000794c94dd45e2  jmp 0x0000794C94DD0123
0000794c94dd45e7  sub rsp, 0x08
0000794c94dd45eb  push rax
0000794c94dd45ec  push rcx
0000794c94dd45ed  push rdx
0000794c94dd45ee  push rdi
0000794c94dd45ef  push rsi
0000794c94dd45f0  push r8
0000794c94dd45f2  push r9
0000794c94dd45f4  push r10
0000794c94dd45f6  push r11
0000794c94dd45f8  sub rsp, 0xF0
0000794c94dd45ff  vmovaps [rsp], xmm0
0000794c94dd4604  vmovaps [rsp+0x10], xmm1
0000794c94dd460a  vmovaps [rsp+0x20], xmm2
0000794c94dd4610  vmovaps [rsp+0x30], xmm3
0000794c94dd4616  vmovaps [rsp+0x40], xmm4
0000794c94dd461c  vmovaps [rsp+0x50], xmm5
0000794c94dd4622  vmovaps [rsp+0x60], xmm6
0000794c94dd4628  vmovaps [rsp+0x70], xmm7
0000794c94dd462e  vmovaps [rsp+0x80], xmm8
0000794c94dd4637  vmovaps [rsp+0x90], xmm9
0000794c94dd4640  vmovaps [rsp+0xA0], xmm10
0000794c94dd4649  vmovaps [rsp+0xB0], xmm11
0000794c94dd4652  vmovaps [rsp+0xC0], xmm12
0000794c94dd465b  vmovaps [rsp+0xD0], xmm13
0000794c94dd4664  vmovaps [rsp+0xE0], xmm14
0000794c94dd466d  sub rsp, 0x30
0000794c94dd4671  movaps [rsp], xmm15
0000794c94dd4676  movaps [rsp+0x10], xmm10
0000794c94dd467c  movaps [rsp+0x20], xmm13
0000794c94dd4682  lea rdi, [rsp]
0000794c94dd4686  mov esi, 0x00
0000794c94dd468b  mov rax, 0x5AB2B8B81530
0000794c94dd4695  call rax
0000794c94dd4697  movaps xmm15, [rsp]
0000794c94dd469c  add rsp, 0x30
0000794c94dd46a0  vmovaps xmm0, [rsp]
0000794c94dd46a5  vmovaps xmm1, [rsp+0x10]
0000794c94dd46ab  vmovaps xmm2, [rsp+0x20]
0000794c94dd46b1  vmovaps xmm3, [rsp+0x30]
0000794c94dd46b7  vmovaps xmm4, [rsp+0x40]
0000794c94dd46bd  vmovaps xmm5, [rsp+0x50]
0000794c94dd46c3  vmovaps xmm6, [rsp+0x60]
0000794c94dd46c9  vmovaps xmm7, [rsp+0x70]
0000794c94dd46cf  vmovaps xmm8, [rsp+0x80]
0000794c94dd46d8  vmovaps xmm9, [rsp+0x90]
0000794c94dd46e1  vmovaps xmm10, [rsp+0xA0]
0000794c94dd46ea  vmovaps xmm11, [rsp+0xB0]
0000794c94dd46f3  vmovaps xmm12, [rsp+0xC0]
0000794c94dd46fc  vmovaps xmm13, [rsp+0xD0]
0000794c94dd4705  vmovaps xmm14, [rsp+0xE0]
0000794c94dd470e  add rsp, 0xF0
0000794c94dd4715  pop r11
0000794c94dd4717  pop r10
0000794c94dd4719  pop r9
0000794c94dd471b  pop r8
0000794c94dd471d  pop rsi
0000794c94dd471e  pop rdi
0000794c94dd471f  pop rdx
0000794c94dd4720  pop rcx
0000794c94dd4721  pop rax
0000794c94dd4722  add rsp, 0x08
0000794c94dd4726  jmp 0x0000794C94DD013D
0000794c94dd472b  sub rsp, 0x08
0000794c94dd472f  push rax
0000794c94dd4730  push rcx
0000794c94dd4731  push rdx
0000794c94dd4732  push rdi
0000794c94dd4733  push rsi
0000794c94dd4734  push r8
0000794c94dd4736  push r9
0000794c94dd4738  push r10
0000794c94dd473a  push r11
0000794c94dd473c  sub rsp, 0xF0
0000794c94dd4743  vmovaps [rsp], xmm0
0000794c94dd4748  vmovaps [rsp+0x10], xmm1
0000794c94dd474e  vmovaps [rsp+0x20], xmm2
0000794c94dd4754  vmovaps [rsp+0x30], xmm3
0000794c94dd475a  vmovaps [rsp+0x40], xmm4
0000794c94dd4760  vmovaps [rsp+0x50], xmm5
0000794c94dd4766  vmovaps [rsp+0x60], xmm6
0000794c94dd476c  vmovaps [rsp+0x70], xmm7
0000794c94dd4772  vmovaps [rsp+0x80], xmm8
0000794c94dd477b  vmovaps [rsp+0x90], xmm9
0000794c94dd4784  vmovaps [rsp+0xA0], xmm11
0000794c94dd478d  vmovaps [rsp+0xB0], xmm12
0000794c94dd4796  vmovaps [rsp+0xC0], xmm13
0000794c94dd479f  vmovaps [rsp+0xD0], xmm14
0000794c94dd47a8  vmovaps [rsp+0xE0], xmm15
0000794c94dd47b1  sub rsp, 0x30
0000794c94dd47b5  movaps [rsp], xmm10
0000794c94dd47ba  movaps [rsp+0x10], xmm7
0000794c94dd47bf  movaps [rsp+0x20], xmm13
0000794c94dd47c5  lea rdi, [rsp]
0000794c94dd47c9  mov esi, 0x00
0000794c94dd47ce  mov rax, 0x5AB2B8B81530
0000794c94dd47d8  call rax
0000794c94dd47da  movaps xmm10, [rsp]
0000794c94dd47df  add rsp, 0x30
0000794c94dd47e3  vmovaps xmm0, [rsp]
0000794c94dd47e8  vmovaps xmm1, [rsp+0x10]
0000794c94dd47ee  vmovaps xmm2, [rsp+0x20]
0000794c94dd47f4  vmovaps xmm3, [rsp+0x30]
0000794c94dd47fa  vmovaps xmm4, [rsp+0x40]
0000794c94dd4800  vmovaps xmm5, [rsp+0x50]
0000794c94dd4806  vmovaps xmm6, [rsp+0x60]
0000794c94dd480c  vmovaps xmm7, [rsp+0x70]
0000794c94dd4812  vmovaps xmm8, [rsp+0x80]
0000794c94dd481b  vmovaps xmm9, [rsp+0x90]
0000794c94dd4824  vmovaps xmm11, [rsp+0xA0]
0000794c94dd482d  vmovaps xmm12, [rsp+0xB0]
0000794c94dd4836  vmovaps xmm13, [rsp+0xC0]
0000794c94dd483f  vmovaps xmm14, [rsp+0xD0]
0000794c94dd4848  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4851  add rsp, 0xF0
0000794c94dd4858  pop r11
0000794c94dd485a  pop r10
0000794c94dd485c  pop r9
0000794c94dd485e  pop r8
0000794c94dd4860  pop rsi
0000794c94dd4861  pop rdi
0000794c94dd4862  pop rdx
0000794c94dd4863  pop rcx
0000794c94dd4864  pop rax
0000794c94dd4865  add rsp, 0x08
0000794c94dd4869  jmp 0x0000794C94DD0169
0000794c94dd486e  sub rsp, 0x08
0000794c94dd4872  push rax
0000794c94dd4873  push rcx
0000794c94dd4874  push rdx
0000794c94dd4875  push rdi
0000794c94dd4876  push rsi
0000794c94dd4877  push r8
0000794c94dd4879  push r9
0000794c94dd487b  push r10
0000794c94dd487d  push r11
0000794c94dd487f  sub rsp, 0xF0
0000794c94dd4886  vmovaps [rsp], xmm0
0000794c94dd488b  vmovaps [rsp+0x10], xmm1
0000794c94dd4891  vmovaps [rsp+0x20], xmm2
0000794c94dd4897  vmovaps [rsp+0x30], xmm3
0000794c94dd489d  vmovaps [rsp+0x40], xmm4
0000794c94dd48a3  vmovaps [rsp+0x50], xmm5
0000794c94dd48a9  vmovaps [rsp+0x60], xmm6
0000794c94dd48af  vmovaps [rsp+0x70], xmm7
0000794c94dd48b5  vmovaps [rsp+0x80], xmm8
0000794c94dd48be  vmovaps [rsp+0x90], xmm9
0000794c94dd48c7  vmovaps [rsp+0xA0], xmm10
0000794c94dd48d0  vmovaps [rsp+0xB0], xmm11
0000794c94dd48d9  vmovaps [rsp+0xC0], xmm12
0000794c94dd48e2  vmovaps [rsp+0xD0], xmm14
0000794c94dd48eb  vmovaps [rsp+0xE0], xmm15
0000794c94dd48f4  sub rsp, 0x30
0000794c94dd48f8  movaps [rsp], xmm13
0000794c94dd48fd  movaps [rsp+0x10], xmm1
0000794c94dd4902  movaps [rsp+0x20], xmm8
0000794c94dd4908  lea rdi, [rsp]
0000794c94dd490c  mov esi, 0x00
0000794c94dd4911  mov rax, 0x5AB2B8B81530
0000794c94dd491b  call rax
0000794c94dd491d  movaps xmm13, [rsp]
0000794c94dd4922  add rsp, 0x30
0000794c94dd4926  vmovaps xmm0, [rsp]
0000794c94dd492b  vmovaps xmm1, [rsp+0x10]
0000794c94dd4931  vmovaps xmm2, [rsp+0x20]
0000794c94dd4937  vmovaps xmm3, [rsp+0x30]
0000794c94dd493d  vmovaps xmm4, [rsp+0x40]
0000794c94dd4943  vmovaps xmm5, [rsp+0x50]
0000794c94dd4949  vmovaps xmm6, [rsp+0x60]
0000794c94dd494f  vmovaps xmm7, [rsp+0x70]
0000794c94dd4955  vmovaps xmm8, [rsp+0x80]
0000794c94dd495e  vmovaps xmm9, [rsp+0x90]
0000794c94dd4967  vmovaps xmm10, [rsp+0xA0]
0000794c94dd4970  vmovaps xmm11, [rsp+0xB0]
0000794c94dd4979  vmovaps xmm12, [rsp+0xC0]
0000794c94dd4982  vmovaps xmm14, [rsp+0xD0]
0000794c94dd498b  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4994  add rsp, 0xF0
0000794c94dd499b  pop r11
0000794c94dd499d  pop r10
0000794c94dd499f  pop r9
0000794c94dd49a1  pop r8
0000794c94dd49a3  pop rsi
0000794c94dd49a4  pop rdi
0000794c94dd49a5  pop rdx
0000794c94dd49a6  pop rcx
0000794c94dd49a7  pop rax
0000794c94dd49a8  add rsp, 0x08
0000794c94dd49ac  jmp 0x0000794C94DD0183
0000794c94dd49b1  call 0x0000794C94BFF430
0000794c94dd49b6  jmp 0x0000794C94DD018D
0000794c94dd49bb  sub rsp, 0x08
0000794c94dd49bf  push rax
0000794c94dd49c0  push rcx
0000794c94dd49c1  push rdx
0000794c94dd49c2  push rdi
0000794c94dd49c3  push rsi
0000794c94dd49c4  push r8
0000794c94dd49c6  push r9
0000794c94dd49c8  push r10
0000794c94dd49ca  push r11
0000794c94dd49cc  sub rsp, 0xF0
0000794c94dd49d3  vmovaps [rsp], xmm0
0000794c94dd49d8  vmovaps [rsp+0x10], xmm1
0000794c94dd49de  vmovaps [rsp+0x20], xmm2
0000794c94dd49e4  vmovaps [rsp+0x30], xmm3
0000794c94dd49ea  vmovaps [rsp+0x40], xmm4
0000794c94dd49f0  vmovaps [rsp+0x50], xmm5
0000794c94dd49f6  vmovaps [rsp+0x60], xmm6
0000794c94dd49fc  vmovaps [rsp+0x70], xmm7
0000794c94dd4a02  vmovaps [rsp+0x80], xmm9
0000794c94dd4a0b  vmovaps [rsp+0x90], xmm10
0000794c94dd4a14  vmovaps [rsp+0xA0], xmm11
0000794c94dd4a1d  vmovaps [rsp+0xB0], xmm12
0000794c94dd4a26  vmovaps [rsp+0xC0], xmm13
0000794c94dd4a2f  vmovaps [rsp+0xD0], xmm14
0000794c94dd4a38  vmovaps [rsp+0xE0], xmm15
0000794c94dd4a41  sub rsp, 0x30
0000794c94dd4a45  movaps [rsp], xmm8
0000794c94dd4a4a  movaps [rsp+0x10], xmm14
0000794c94dd4a50  movaps [rsp+0x20], xmm9
0000794c94dd4a56  lea rdi, [rsp]
0000794c94dd4a5a  mov esi, 0x00
0000794c94dd4a5f  mov rax, 0x5AB2B8B81530
0000794c94dd4a69  call rax
0000794c94dd4a6b  movaps xmm8, [rsp]
0000794c94dd4a70  add rsp, 0x30
0000794c94dd4a74  vmovaps xmm0, [rsp]
0000794c94dd4a79  vmovaps xmm1, [rsp+0x10]
0000794c94dd4a7f  vmovaps xmm2, [rsp+0x20]
0000794c94dd4a85  vmovaps xmm3, [rsp+0x30]
0000794c94dd4a8b  vmovaps xmm4, [rsp+0x40]
0000794c94dd4a91  vmovaps xmm5, [rsp+0x50]
0000794c94dd4a97  vmovaps xmm6, [rsp+0x60]
0000794c94dd4a9d  vmovaps xmm7, [rsp+0x70]
0000794c94dd4aa3  vmovaps xmm9, [rsp+0x80]
0000794c94dd4aac  vmovaps xmm10, [rsp+0x90]
0000794c94dd4ab5  vmovaps xmm11, [rsp+0xA0]
0000794c94dd4abe  vmovaps xmm12, [rsp+0xB0]
0000794c94dd4ac7  vmovaps xmm13, [rsp+0xC0]
0000794c94dd4ad0  vmovaps xmm14, [rsp+0xD0]
0000794c94dd4ad9  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4ae2  add rsp, 0xF0
0000794c94dd4ae9  pop r11
0000794c94dd4aeb  pop r10
0000794c94dd4aed  pop r9
0000794c94dd4aef  pop r8
0000794c94dd4af1  pop rsi
0000794c94dd4af2  pop rdi
0000794c94dd4af3  pop rdx
0000794c94dd4af4  pop rcx
0000794c94dd4af5  pop rax
0000794c94dd4af6  add rsp, 0x08
0000794c94dd4afa  jmp 0x0000794C94DD01AF
0000794c94dd4aff  sub rsp, 0x08
0000794c94dd4b03  push rax
0000794c94dd4b04  push rcx
0000794c94dd4b05  push rdx
0000794c94dd4b06  push rdi
0000794c94dd4b07  push rsi
0000794c94dd4b08  push r8
0000794c94dd4b0a  push r9
0000794c94dd4b0c  push r10
0000794c94dd4b0e  push r11
0000794c94dd4b10  sub rsp, 0xF0
0000794c94dd4b17  vmovaps [rsp], xmm0
0000794c94dd4b1c  vmovaps [rsp+0x10], xmm1
0000794c94dd4b22  vmovaps [rsp+0x20], xmm2
0000794c94dd4b28  vmovaps [rsp+0x30], xmm3
0000794c94dd4b2e  vmovaps [rsp+0x40], xmm4
0000794c94dd4b34  vmovaps [rsp+0x50], xmm5
0000794c94dd4b3a  vmovaps [rsp+0x60], xmm6
0000794c94dd4b40  vmovaps [rsp+0x70], xmm7
0000794c94dd4b46  vmovaps [rsp+0x80], xmm8
0000794c94dd4b4f  vmovaps [rsp+0x90], xmm10
0000794c94dd4b58  vmovaps [rsp+0xA0], xmm11
0000794c94dd4b61  vmovaps [rsp+0xB0], xmm12
0000794c94dd4b6a  vmovaps [rsp+0xC0], xmm13
0000794c94dd4b73  vmovaps [rsp+0xD0], xmm14
0000794c94dd4b7c  vmovaps [rsp+0xE0], xmm15
0000794c94dd4b85  sub rsp, 0x30
0000794c94dd4b89  movaps [rsp], xmm9
0000794c94dd4b8e  movaps [rsp+0x10], xmm1
0000794c94dd4b93  movaps [rsp+0x20], xmm14
0000794c94dd4b99  lea rdi, [rsp]
0000794c94dd4b9d  mov esi, 0x00
0000794c94dd4ba2  mov rax, 0x5AB2B8B81530
0000794c94dd4bac  call rax
0000794c94dd4bae  movaps xmm9, [rsp]
0000794c94dd4bb3  add rsp, 0x30
0000794c94dd4bb7  vmovaps xmm0, [rsp]
0000794c94dd4bbc  vmovaps xmm1, [rsp+0x10]
0000794c94dd4bc2  vmovaps xmm2, [rsp+0x20]
0000794c94dd4bc8  vmovaps xmm3, [rsp+0x30]
0000794c94dd4bce  vmovaps xmm4, [rsp+0x40]
0000794c94dd4bd4  vmovaps xmm5, [rsp+0x50]
0000794c94dd4bda  vmovaps xmm6, [rsp+0x60]
0000794c94dd4be0  vmovaps xmm7, [rsp+0x70]
0000794c94dd4be6  vmovaps xmm8, [rsp+0x80]
0000794c94dd4bef  vmovaps xmm10, [rsp+0x90]
0000794c94dd4bf8  vmovaps xmm11, [rsp+0xA0]
0000794c94dd4c01  vmovaps xmm12, [rsp+0xB0]
0000794c94dd4c0a  vmovaps xmm13, [rsp+0xC0]
0000794c94dd4c13  vmovaps xmm14, [rsp+0xD0]
0000794c94dd4c1c  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4c25  add rsp, 0xF0
0000794c94dd4c2c  pop r11
0000794c94dd4c2e  pop r10
0000794c94dd4c30  pop r9
0000794c94dd4c32  pop r8
0000794c94dd4c34  pop rsi
0000794c94dd4c35  pop rdi
0000794c94dd4c36  pop rdx
0000794c94dd4c37  pop rcx
0000794c94dd4c38  pop rax
0000794c94dd4c39  add rsp, 0x08
0000794c94dd4c3d  jmp 0x0000794C94DD01DD
0000794c94dd4c42  sub rsp, 0x08
0000794c94dd4c46  push rax
0000794c94dd4c47  push rcx
0000794c94dd4c48  push rdx
0000794c94dd4c49  push rdi
0000794c94dd4c4a  push rsi
0000794c94dd4c4b  push r8
0000794c94dd4c4d  push r9
0000794c94dd4c4f  push r10
0000794c94dd4c51  push r11
0000794c94dd4c53  sub rsp, 0xF0
0000794c94dd4c5a  vmovaps [rsp], xmm0
0000794c94dd4c5f  vmovaps [rsp+0x10], xmm1
0000794c94dd4c65  vmovaps [rsp+0x20], xmm2
0000794c94dd4c6b  vmovaps [rsp+0x30], xmm3
0000794c94dd4c71  vmovaps [rsp+0x40], xmm4
0000794c94dd4c77  vmovaps [rsp+0x50], xmm5
0000794c94dd4c7d  vmovaps [rsp+0x60], xmm6
0000794c94dd4c83  vmovaps [rsp+0x70], xmm7
0000794c94dd4c89  vmovaps [rsp+0x80], xmm8
0000794c94dd4c92  vmovaps [rsp+0x90], xmm9
0000794c94dd4c9b  vmovaps [rsp+0xA0], xmm10
0000794c94dd4ca4  vmovaps [rsp+0xB0], xmm11
0000794c94dd4cad  vmovaps [rsp+0xC0], xmm12
0000794c94dd4cb6  vmovaps [rsp+0xD0], xmm13
0000794c94dd4cbf  vmovaps [rsp+0xE0], xmm15
0000794c94dd4cc8  sub rsp, 0x30
0000794c94dd4ccc  movaps [rsp], xmm14
0000794c94dd4cd1  movaps [rsp+0x10], xmm4
0000794c94dd4cd6  movaps [rsp+0x20], xmm1
0000794c94dd4cdb  lea rdi, [rsp]
0000794c94dd4cdf  mov esi, 0x00
0000794c94dd4ce4  mov rax, 0x5AB2B8B81530
0000794c94dd4cee  call rax
0000794c94dd4cf0  movaps xmm14, [rsp]
0000794c94dd4cf5  add rsp, 0x30
0000794c94dd4cf9  vmovaps xmm0, [rsp]
0000794c94dd4cfe  vmovaps xmm1, [rsp+0x10]
0000794c94dd4d04  vmovaps xmm2, [rsp+0x20]
0000794c94dd4d0a  vmovaps xmm3, [rsp+0x30]
0000794c94dd4d10  vmovaps xmm4, [rsp+0x40]
0000794c94dd4d16  vmovaps xmm5, [rsp+0x50]
0000794c94dd4d1c  vmovaps xmm6, [rsp+0x60]
0000794c94dd4d22  vmovaps xmm7, [rsp+0x70]
0000794c94dd4d28  vmovaps xmm8, [rsp+0x80]
0000794c94dd4d31  vmovaps xmm9, [rsp+0x90]
0000794c94dd4d3a  vmovaps xmm10, [rsp+0xA0]
0000794c94dd4d43  vmovaps xmm11, [rsp+0xB0]
0000794c94dd4d4c  vmovaps xmm12, [rsp+0xC0]
0000794c94dd4d55  vmovaps xmm13, [rsp+0xD0]
0000794c94dd4d5e  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4d67  add rsp, 0xF0
0000794c94dd4d6e  pop r11
0000794c94dd4d70  pop r10
0000794c94dd4d72  pop r9
0000794c94dd4d74  pop r8
0000794c94dd4d76  pop rsi
0000794c94dd4d77  pop rdi
0000794c94dd4d78  pop rdx
0000794c94dd4d79  pop rcx
0000794c94dd4d7a  pop rax
0000794c94dd4d7b  add rsp, 0x08
0000794c94dd4d7f  jmp 0x0000794C94DD0203
0000794c94dd4d84  sub rsp, 0x08
0000794c94dd4d88  push rax
0000794c94dd4d89  push rcx
0000794c94dd4d8a  push rdx
0000794c94dd4d8b  push rdi
0000794c94dd4d8c  push rsi
0000794c94dd4d8d  push r8
0000794c94dd4d8f  push r9
0000794c94dd4d91  push r10
0000794c94dd4d93  push r11
0000794c94dd4d95  sub rsp, 0xF0
0000794c94dd4d9c  vmovaps [rsp], xmm0
0000794c94dd4da1  vmovaps [rsp+0x10], xmm2
0000794c94dd4da7  vmovaps [rsp+0x20], xmm3
0000794c94dd4dad  vmovaps [rsp+0x30], xmm4
0000794c94dd4db3  vmovaps [rsp+0x40], xmm5
0000794c94dd4db9  vmovaps [rsp+0x50], xmm6
0000794c94dd4dbf  vmovaps [rsp+0x60], xmm7
0000794c94dd4dc5  vmovaps [rsp+0x70], xmm8
0000794c94dd4dcb  vmovaps [rsp+0x80], xmm9
0000794c94dd4dd4  vmovaps [rsp+0x90], xmm10
0000794c94dd4ddd  vmovaps [rsp+0xA0], xmm11
0000794c94dd4de6  vmovaps [rsp+0xB0], xmm12
0000794c94dd4def  vmovaps [rsp+0xC0], xmm13
0000794c94dd4df8  vmovaps [rsp+0xD0], xmm14
0000794c94dd4e01  vmovaps [rsp+0xE0], xmm15
0000794c94dd4e0a  sub rsp, 0x30
0000794c94dd4e0e  movaps [rsp], xmm1
0000794c94dd4e12  movaps [rsp+0x10], xmm12
0000794c94dd4e18  movaps [rsp+0x20], xmm11
0000794c94dd4e1e  lea rdi, [rsp]
0000794c94dd4e22  mov esi, 0x00
0000794c94dd4e27  mov rax, 0x5AB2B8B81530
0000794c94dd4e31  call rax
0000794c94dd4e33  movaps xmm1, [rsp]
0000794c94dd4e37  add rsp, 0x30
0000794c94dd4e3b  vmovaps xmm0, [rsp]
0000794c94dd4e40  vmovaps xmm2, [rsp+0x10]
0000794c94dd4e46  vmovaps xmm3, [rsp+0x20]
0000794c94dd4e4c  vmovaps xmm4, [rsp+0x30]
0000794c94dd4e52  vmovaps xmm5, [rsp+0x40]
0000794c94dd4e58  vmovaps xmm6, [rsp+0x50]
0000794c94dd4e5e  vmovaps xmm7, [rsp+0x60]
0000794c94dd4e64  vmovaps xmm8, [rsp+0x70]
0000794c94dd4e6a  vmovaps xmm9, [rsp+0x80]
0000794c94dd4e73  vmovaps xmm10, [rsp+0x90]
0000794c94dd4e7c  vmovaps xmm11, [rsp+0xA0]
0000794c94dd4e85  vmovaps xmm12, [rsp+0xB0]
0000794c94dd4e8e  vmovaps xmm13, [rsp+0xC0]
0000794c94dd4e97  vmovaps xmm14, [rsp+0xD0]
0000794c94dd4ea0  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4ea9  add rsp, 0xF0
0000794c94dd4eb0  pop r11
0000794c94dd4eb2  pop r10
0000794c94dd4eb4  pop r9
0000794c94dd4eb6  pop r8
0000794c94dd4eb8  pop rsi
0000794c94dd4eb9  pop rdi
0000794c94dd4eba  pop rdx
0000794c94dd4ebb  pop rcx
0000794c94dd4ebc  pop rax
0000794c94dd4ebd  add rsp, 0x08
0000794c94dd4ec1  jmp 0x0000794C94DD0224
0000794c94dd4ec6  call 0x0000794C94CE20A0
0000794c94dd4ecb  jmp 0x0000794C94DD0232
0000794c94dd4ed0  call 0x0000794C94C09D70
0000794c94dd4ed5  jmp 0x0000794C94DD023C
0000794c94dd4eda  sub rsp, 0x08
0000794c94dd4ede  push rax
0000794c94dd4edf  push rcx
0000794c94dd4ee0  push rdx
0000794c94dd4ee1  push rdi
0000794c94dd4ee2  push rsi
0000794c94dd4ee3  push r8
0000794c94dd4ee5  push r9
0000794c94dd4ee7  push r10
0000794c94dd4ee9  push r11
0000794c94dd4eeb  sub rsp, 0xF0
0000794c94dd4ef2  vmovaps [rsp], xmm0
0000794c94dd4ef7  vmovaps [rsp+0x10], xmm1
0000794c94dd4efd  vmovaps [rsp+0x20], xmm2
0000794c94dd4f03  vmovaps [rsp+0x30], xmm3
0000794c94dd4f09  vmovaps [rsp+0x40], xmm4
0000794c94dd4f0f  vmovaps [rsp+0x50], xmm5
0000794c94dd4f15  vmovaps [rsp+0x60], xmm6
0000794c94dd4f1b  vmovaps [rsp+0x70], xmm8
0000794c94dd4f21  vmovaps [rsp+0x80], xmm9
0000794c94dd4f2a  vmovaps [rsp+0x90], xmm10
0000794c94dd4f33  vmovaps [rsp+0xA0], xmm11
0000794c94dd4f3c  vmovaps [rsp+0xB0], xmm12
0000794c94dd4f45  vmovaps [rsp+0xC0], xmm13
0000794c94dd4f4e  vmovaps [rsp+0xD0], xmm14
0000794c94dd4f57  vmovaps [rsp+0xE0], xmm15
0000794c94dd4f60  sub rsp, 0x30
0000794c94dd4f64  movaps [rsp], xmm7
0000794c94dd4f68  movaps [rsp+0x10], xmm15
0000794c94dd4f6e  movaps [rsp+0x20], xmm10
0000794c94dd4f74  lea rdi, [rsp]
0000794c94dd4f78  mov esi, 0x00
0000794c94dd4f7d  mov rax, 0x5AB2B8B81530
0000794c94dd4f87  call rax
0000794c94dd4f89  movaps xmm7, [rsp]
0000794c94dd4f8d  add rsp, 0x30
0000794c94dd4f91  vmovaps xmm0, [rsp]
0000794c94dd4f96  vmovaps xmm1, [rsp+0x10]
0000794c94dd4f9c  vmovaps xmm2, [rsp+0x20]
0000794c94dd4fa2  vmovaps xmm3, [rsp+0x30]
0000794c94dd4fa8  vmovaps xmm4, [rsp+0x40]
0000794c94dd4fae  vmovaps xmm5, [rsp+0x50]
0000794c94dd4fb4  vmovaps xmm6, [rsp+0x60]
0000794c94dd4fba  vmovaps xmm8, [rsp+0x70]
0000794c94dd4fc0  vmovaps xmm9, [rsp+0x80]
0000794c94dd4fc9  vmovaps xmm10, [rsp+0x90]
0000794c94dd4fd2  vmovaps xmm11, [rsp+0xA0]
0000794c94dd4fdb  vmovaps xmm12, [rsp+0xB0]
0000794c94dd4fe4  vmovaps xmm13, [rsp+0xC0]
0000794c94dd4fed  vmovaps xmm14, [rsp+0xD0]
0000794c94dd4ff6  vmovaps xmm15, [rsp+0xE0]
0000794c94dd4fff  add rsp, 0xF0
0000794c94dd5006  pop r11
0000794c94dd5008  pop r10
0000794c94dd500a  pop r9
0000794c94dd500c  pop r8
0000794c94dd500e  pop rsi
0000794c94dd500f  pop rdi
0000794c94dd5010  pop rdx
0000794c94dd5011  pop rcx
0000794c94dd5012  pop rax
0000794c94dd5013  add rsp, 0x08
0000794c94dd5017  jmp 0x0000794C94DD025D
0000794c94dd501c  sub rsp, 0x08
0000794c94dd5020  push rax
0000794c94dd5021  push rcx
0000794c94dd5022  push rdx
0000794c94dd5023  push rdi
0000794c94dd5024  push rsi
0000794c94dd5025  push r8
0000794c94dd5027  push r9
0000794c94dd5029  push r10
0000794c94dd502b  push r11
0000794c94dd502d  sub rsp, 0xF0
0000794c94dd5034  vmovaps [rsp], xmm0
0000794c94dd5039  vmovaps [rsp+0x10], xmm1
0000794c94dd503f  vmovaps [rsp+0x20], xmm2
0000794c94dd5045  vmovaps [rsp+0x30], xmm3
0000794c94dd504b  vmovaps [rsp+0x40], xmm4
0000794c94dd5051  vmovaps [rsp+0x50], xmm5
0000794c94dd5057  vmovaps [rsp+0x60], xmm6
0000794c94dd505d  vmovaps [rsp+0x70], xmm7
0000794c94dd5063  vmovaps [rsp+0x80], xmm8
0000794c94dd506c  vmovaps [rsp+0x90], xmm9
0000794c94dd5075  vmovaps [rsp+0xA0], xmm11
0000794c94dd507e  vmovaps [rsp+0xB0], xmm12
0000794c94dd5087  vmovaps [rsp+0xC0], xmm13
0000794c94dd5090  vmovaps [rsp+0xD0], xmm14
0000794c94dd5099  vmovaps [rsp+0xE0], xmm15
0000794c94dd50a2  sub rsp, 0x30
0000794c94dd50a6  movaps [rsp], xmm10
0000794c94dd50ab  movaps [rsp+0x10], xmm11
0000794c94dd50b1  movaps [rsp+0x20], xmm15
0000794c94dd50b7  lea rdi, [rsp]
0000794c94dd50bb  mov esi, 0x00
0000794c94dd50c0  mov rax, 0x5AB2B8B81530
0000794c94dd50ca  call rax
0000794c94dd50cc  movaps xmm10, [rsp]
0000794c94dd50d1  add rsp, 0x30
0000794c94dd50d5  vmovaps xmm0, [rsp]
0000794c94dd50da  vmovaps xmm1, [rsp+0x10]
0000794c94dd50e0  vmovaps xmm2, [rsp+0x20]
0000794c94dd50e6  vmovaps xmm3, [rsp+0x30]
0000794c94dd50ec  vmovaps xmm4, [rsp+0x40]
0000794c94dd50f2  vmovaps xmm5, [rsp+0x50]
0000794c94dd50f8  vmovaps xmm6, [rsp+0x60]
0000794c94dd50fe  vmovaps xmm7, [rsp+0x70]
0000794c94dd5104  vmovaps xmm8, [rsp+0x80]
0000794c94dd510d  vmovaps xmm9, [rsp+0x90]
0000794c94dd5116  vmovaps xmm11, [rsp+0xA0]
0000794c94dd511f  vmovaps xmm12, [rsp+0xB0]
0000794c94dd5128  vmovaps xmm13, [rsp+0xC0]
0000794c94dd5131  vmovaps xmm14, [rsp+0xD0]
0000794c94dd513a  vmovaps xmm15, [rsp+0xE0]
0000794c94dd5143  add rsp, 0xF0
0000794c94dd514a  pop r11
0000794c94dd514c  pop r10
0000794c94dd514e  pop r9
0000794c94dd5150  pop r8
0000794c94dd5152  pop rsi
0000794c94dd5153  pop rdi
0000794c94dd5154  pop rdx
0000794c94dd5155  pop rcx
0000794c94dd5156  pop rax
0000794c94dd5157  add rsp, 0x08
0000794c94dd515b  jmp 0x0000794C94DD028B
0000794c94dd5160  sub rsp, 0x08
0000794c94dd5164  push rax
0000794c94dd5165  push rcx
0000794c94dd5166  push rdx
0000794c94dd5167  push rdi
0000794c94dd5168  push rsi
0000794c94dd5169  push r8
0000794c94dd516b  push r9
0000794c94dd516d  push r10
0000794c94dd516f  push r11
0000794c94dd5171  sub rsp, 0xF0
0000794c94dd5178  vmovaps [rsp], xmm0
0000794c94dd517d  vmovaps [rsp+0x10], xmm1
0000794c94dd5183  vmovaps [rsp+0x20], xmm2
0000794c94dd5189  vmovaps [rsp+0x30], xmm3
0000794c94dd518f  vmovaps [rsp+0x40], xmm4
0000794c94dd5195  vmovaps [rsp+0x50], xmm5
0000794c94dd519b  vmovaps [rsp+0x60], xmm6
0000794c94dd51a1  vmovaps [rsp+0x70], xmm7
0000794c94dd51a7  vmovaps [rsp+0x80], xmm8
0000794c94dd51b0  vmovaps [rsp+0x90], xmm9
0000794c94dd51b9  vmovaps [rsp+0xA0], xmm10
0000794c94dd51c2  vmovaps [rsp+0xB0], xmm12
0000794c94dd51cb  vmovaps [rsp+0xC0], xmm13
0000794c94dd51d4  vmovaps [rsp+0xD0], xmm14
0000794c94dd51dd  vmovaps [rsp+0xE0], xmm15
0000794c94dd51e6  sub rsp, 0x30
0000794c94dd51ea  movaps [rsp], xmm11
0000794c94dd51ef  movaps [rsp+0x10], xmm12
0000794c94dd51f5  movaps [rsp+0x20], xmm15
0000794c94dd51fb  lea rdi, [rsp]
0000794c94dd51ff  mov esi, 0x00
0000794c94dd5204  mov rax, 0x5AB2B8B81530
0000794c94dd520e  call rax
0000794c94dd5210  movaps xmm11, [rsp]
0000794c94dd5215  add rsp, 0x30
0000794c94dd5219  vmovaps xmm0, [rsp]
0000794c94dd521e  vmovaps xmm1, [rsp+0x10]
0000794c94dd5224  vmovaps xmm2, [rsp+0x20]
0000794c94dd522a  vmovaps xmm3, [rsp+0x30]
0000794c94dd5230  vmovaps xmm4, [rsp+0x40]
0000794c94dd5236  vmovaps xmm5, [rsp+0x50]
0000794c94dd523c  vmovaps xmm6, [rsp+0x60]
0000794c94dd5242  vmovaps xmm7, [rsp+0x70]
0000794c94dd5248  vmovaps xmm8, [rsp+0x80]
0000794c94dd5251  vmovaps xmm9, [rsp+0x90]
0000794c94dd525a  vmovaps xmm10, [rsp+0xA0]
0000794c94dd5263  vmovaps xmm12, [rsp+0xB0]
0000794c94dd526c  vmovaps xmm13, [rsp+0xC0]
0000794c94dd5275  vmovaps xmm14, [rsp+0xD0]
0000794c94dd527e  vmovaps xmm15, [rsp+0xE0]
0000794c94dd5287  add rsp, 0xF0
0000794c94dd528e  pop r11
0000794c94dd5290  pop r10
0000794c94dd5292  pop r9
0000794c94dd5294  pop r8
0000794c94dd5296  pop rsi
0000794c94dd5297  pop rdi
0000794c94dd5298  pop rdx
0000794c94dd5299  pop rcx
0000794c94dd529a  pop rax
0000794c94dd529b  add rsp, 0x08
0000794c94dd529f  jmp 0x0000794C94DD02B9
0000794c94dd52a4  sub rsp, 0x08
0000794c94dd52a8  push rax
0000794c94dd52a9  push rcx
0000794c94dd52aa  push rdx
0000794c94dd52ab  push rdi
0000794c94dd52ac  push rsi
0000794c94dd52ad  push r8
0000794c94dd52af  push r9
0000794c94dd52b1  push r10
0000794c94dd52b3  push r11
0000794c94dd52b5  sub rsp, 0xF0
0000794c94dd52bc  vmovaps [rsp], xmm0
0000794c94dd52c1  vmovaps [rsp+0x10], xmm1
0000794c94dd52c7  vmovaps [rsp+0x20], xmm2
0000794c94dd52cd  vmovaps [rsp+0x30], xmm3
0000794c94dd52d3  vmovaps [rsp+0x40], xmm4
0000794c94dd52d9  vmovaps [rsp+0x50], xmm5
0000794c94dd52df  vmovaps [rsp+0x60], xmm6
0000794c94dd52e5  vmovaps [rsp+0x70], xmm7
0000794c94dd52eb  vmovaps [rsp+0x80], xmm8
0000794c94dd52f4  vmovaps [rsp+0x90], xmm9
0000794c94dd52fd  vmovaps [rsp+0xA0], xmm10
0000794c94dd5306  vmovaps [rsp+0xB0], xmm11
0000794c94dd530f  vmovaps [rsp+0xC0], xmm12
0000794c94dd5318  vmovaps [rsp+0xD0], xmm13
0000794c94dd5321  vmovaps [rsp+0xE0], xmm14
0000794c94dd532a  sub rsp, 0x30
0000794c94dd532e  movaps [rsp], xmm15
0000794c94dd5333  movaps [rsp+0x10], xmm13
0000794c94dd5339  movaps [rsp+0x20], xmm9
0000794c94dd533f  lea rdi, [rsp]
0000794c94dd5343  mov esi, 0x00
0000794c94dd5348  mov rax, 0x5AB2B8B81530
0000794c94dd5352  call rax
0000794c94dd5354  movaps xmm15, [rsp]
0000794c94dd5359  add rsp, 0x30
0000794c94dd535d  vmovaps xmm0, [rsp]
0000794c94dd5362  vmovaps xmm1, [rsp+0x10]
0000794c94dd5368  vmovaps xmm2, [rsp+0x20]
0000794c94dd536e  vmovaps xmm3, [rsp+0x30]
0000794c94dd5374  vmovaps xmm4, [rsp+0x40]
0000794c94dd537a  vmovaps xmm5, [rsp+0x50]
0000794c94dd5380  vmovaps xmm6, [rsp+0x60]
0000794c94dd5386  vmovaps xmm7, [rsp+0x70]
0000794c94dd538c  vmovaps xmm8, [rsp+0x80]
0000794c94dd5395  vmovaps xmm9, [rsp+0x90]
0000794c94dd539e  vmovaps xmm10, [rsp+0xA0]
0000794c94dd53a7  vmovaps xmm11, [rsp+0xB0]
0000794c94dd53b0  vmovaps xmm12, [rsp+0xC0]
0000794c94dd53b9  vmovaps xmm13, [rsp+0xD0]
0000794c94dd53c2  vmovaps xmm14, [rsp+0xE0]
0000794c94dd53cb  add rsp, 0xF0
0000794c94dd53d2  pop r11
0000794c94dd53d4  pop r10
0000794c94dd53d6  pop r9
0000794c94dd53d8  pop r8
0000794c94dd53da  pop rsi
0000794c94dd53db  pop rdi
0000794c94dd53dc  pop rdx
0000794c94dd53dd  pop rcx
0000794c94dd53de  pop rax
0000794c94dd53df  add rsp, 0x08
0000794c94dd53e3  jmp 0x0000794C94DD02D4
0000794c94dd53e8  sub rsp, 0x08
0000794c94dd53ec  push rax
0000794c94dd53ed  push rcx
0000794c94dd53ee  push rdx
0000794c94dd53ef  push rdi
0000794c94dd53f0  push rsi
0000794c94dd53f1  push r8
0000794c94dd53f3  push r9
0000794c94dd53f5  push r10
0000794c94dd53f7  push r11
0000794c94dd53f9  sub rsp, 0xF0
0000794c94dd5400  vmovaps [rsp], xmm0
0000794c94dd5405  vmovaps [rsp+0x10], xmm1
0000794c94dd540b  vmovaps [rsp+0x20], xmm2
0000794c94dd5411  vmovaps [rsp+0x30], xmm3
0000794c94dd5417  vmovaps [rsp+0x40], xmm4
0000794c94dd541d  vmovaps [rsp+0x50], xmm5
0000794c94dd5423  vmovaps [rsp+0x60], xmm6
0000794c94dd5429  vmovaps [rsp+0x70], xmm7
0000794c94dd542f  vmovaps [rsp+0x80], xmm8
0000794c94dd5438  vmovaps [rsp+0x90], xmm9
0000794c94dd5441  vmovaps [rsp+0xA0], xmm10
0000794c94dd544a  vmovaps [rsp+0xB0], xmm11
0000794c94dd5453  vmovaps [rsp+0xC0], xmm12
0000794c94dd545c  vmovaps [rsp+0xD0], xmm14
0000794c94dd5465  vmovaps [rsp+0xE0], xmm15
0000794c94dd546e  sub rsp, 0x30
0000794c94dd5472  movaps [rsp], xmm13
0000794c94dd5477  movaps [rsp+0x10], xmm8
0000794c94dd547d  movaps [rsp+0x20], xmm14
0000794c94dd5483  lea rdi, [rsp]
0000794c94dd5487  mov esi, 0x00
0000794c94dd548c  mov rax, 0x5AB2B8B81530
0000794c94dd5496  call rax
0000794c94dd5498  movaps xmm13, [rsp]
0000794c94dd549d  add rsp, 0x30
0000794c94dd54a1  vmovaps xmm0, [rsp]
0000794c94dd54a6  vmovaps xmm1, [rsp+0x10]
0000794c94dd54ac  vmovaps xmm2, [rsp+0x20]
0000794c94dd54b2  vmovaps xmm3, [rsp+0x30]
0000794c94dd54b8  vmovaps xmm4, [rsp+0x40]
0000794c94dd54be  vmovaps xmm5, [rsp+0x50]
0000794c94dd54c4  vmovaps xmm6, [rsp+0x60]
0000794c94dd54ca  vmovaps xmm7, [rsp+0x70]
0000794c94dd54d0  vmovaps xmm8, [rsp+0x80]
0000794c94dd54d9  vmovaps xmm9, [rsp+0x90]
0000794c94dd54e2  vmovaps xmm10, [rsp+0xA0]
0000794c94dd54eb  vmovaps xmm11, [rsp+0xB0]
0000794c94dd54f4  vmovaps xmm12, [rsp+0xC0]
0000794c94dd54fd  vmovaps xmm14, [rsp+0xD0]
0000794c94dd5506  vmovaps xmm15, [rsp+0xE0]
0000794c94dd550f  add rsp, 0xF0
0000794c94dd5516  pop r11
0000794c94dd5518  pop r10
0000794c94dd551a  pop r9
0000794c94dd551c  pop r8
0000794c94dd551e  pop rsi
0000794c94dd551f  pop rdi
0000794c94dd5520  pop rdx
0000794c94dd5521  pop rcx
0000794c94dd5522  pop rax
0000794c94dd5523  add rsp, 0x08
0000794c94dd5527  jmp 0x0000794C94DD02F7
0000794c94dd552c  sub rsp, 0x08
0000794c94dd5530  push rax
0000794c94dd5531  push rcx
0000794c94dd5532  push rdx
0000794c94dd5533  push rdi
0000794c94dd5534  push rsi
0000794c94dd5535  push r8
0000794c94dd5537  push r9
0000794c94dd5539  push r10
0000794c94dd553b  push r11
0000794c94dd553d  sub rsp, 0xF0
0000794c94dd5544  vmovaps [rsp], xmm0
0000794c94dd5549  vmovaps [rsp+0x10], xmm1
0000794c94dd554f  vmovaps [rsp+0x20], xmm2
0000794c94dd5555  vmovaps [rsp+0x30], xmm3
0000794c94dd555b  vmovaps [rsp+0x40], xmm4
0000794c94dd5561  vmovaps [rsp+0x50], xmm5
0000794c94dd5567  vmovaps [rsp+0x60], xmm6
0000794c94dd556d  vmovaps [rsp+0x70], xmm7
0000794c94dd5573  vmovaps [rsp+0x80], xmm8
0000794c94dd557c  vmovaps [rsp+0x90], xmm9
0000794c94dd5585  vmovaps [rsp+0xA0], xmm10
0000794c94dd558e  vmovaps [rsp+0xB0], xmm11
0000794c94dd5597  vmovaps [rsp+0xC0], xmm12
0000794c94dd55a0  vmovaps [rsp+0xD0], xmm13
0000794c94dd55a9  vmovaps [rsp+0xE0], xmm15
0000794c94dd55b2  sub rsp, 0x30
0000794c94dd55b6  movaps [rsp], xmm14
0000794c94dd55bb  movaps [rsp+0x10], xmm1
0000794c94dd55c0  movaps [rsp+0x20], xmm10
0000794c94dd55c6  lea rdi, [rsp]
0000794c94dd55ca  mov esi, 0x00
0000794c94dd55cf  mov rax, 0x5AB2B8B81530
0000794c94dd55d9  call rax
0000794c94dd55db  movaps xmm14, [rsp]
0000794c94dd55e0  add rsp, 0x30
0000794c94dd55e4  vmovaps xmm0, [rsp]
0000794c94dd55e9  vmovaps xmm1, [rsp+0x10]
0000794c94dd55ef  vmovaps xmm2, [rsp+0x20]
0000794c94dd55f5  vmovaps xmm3, [rsp+0x30]
0000794c94dd55fb  vmovaps xmm4, [rsp+0x40]
0000794c94dd5601  vmovaps xmm5, [rsp+0x50]
0000794c94dd5607  vmovaps xmm6, [rsp+0x60]
0000794c94dd560d  vmovaps xmm7, [rsp+0x70]
0000794c94dd5613  vmovaps xmm8, [rsp+0x80]
0000794c94dd561c  vmovaps xmm9, [rsp+0x90]
0000794c94dd5625  vmovaps xmm10, [rsp+0xA0]
0000794c94dd562e  vmovaps xmm11, [rsp+0xB0]
0000794c94dd5637  vmovaps xmm12, [rsp+0xC0]
0000794c94dd5640  vmovaps xmm13, [rsp+0xD0]
0000794c94dd5649  vmovaps xmm15, [rsp+0xE0]
0000794c94dd5652  add rsp, 0xF0
0000794c94dd5659  pop r11
0000794c94dd565b  pop r10
0000794c94dd565d  pop r9
0000794c94dd565f  pop r8
0000794c94dd5661  pop rsi
0000794c94dd5662  pop rdi
0000794c94dd5663  pop rdx
0000794c94dd5664  pop rcx
0000794c94dd5665  pop rax
0000794c94dd5666  add rsp, 0x08
0000794c94dd566a  jmp 0x0000794C94DD031A
0000794c94dd566f  sub rsp, 0x08
0000794c94dd5673  push rax
0000794c94dd5674  push rcx
0000794c94dd5675  push rdx
0000794c94dd5676  push rdi
0000794c94dd5677  push rsi
0000794c94dd5678  push r8
0000794c94dd567a  push r9
0000794c94dd567c  push r10
0000794c94dd567e  push r11
0000794c94dd5680  sub rsp, 0xF0
0000794c94dd5687  vmovaps [rsp], xmm0
0000794c94dd568c  vmovaps [rsp+0x10], xmm2
0000794c94dd5692  vmovaps [rsp+0x20], xmm3
0000794c94dd5698  vmovaps [rsp+0x30], xmm4
0000794c94dd569e  vmovaps [rsp+0x40], xmm5
0000794c94dd56a4  vmovaps [rsp+0x50], xmm6
0000794c94dd56aa  vmovaps [rsp+0x60], xmm7
0000794c94dd56b0  vmovaps [rsp+0x70], xmm8
0000794c94dd56b6  vmovaps [rsp+0x80], xmm9
0000794c94dd56bf  vmovaps [rsp+0x90], xmm10
0000794c94dd56c8  vmovaps [rsp+0xA0], xmm11
0000794c94dd56d1  vmovaps [rsp+0xB0], xmm12
0000794c94dd56da  vmovaps [rsp+0xC0], xmm13
0000794c94dd56e3  vmovaps [rsp+0xD0], xmm14
0000794c94dd56ec  vmovaps [rsp+0xE0], xmm15
0000794c94dd56f5  sub rsp, 0x30
0000794c94dd56f9  movaps [rsp], xmm1
0000794c94dd56fd  movaps [rsp+0x10], xmm7
0000794c94dd5702  movaps [rsp+0x20], xmm11
0000794c94dd5708  lea rdi, [rsp]
0000794c94dd570c  mov esi, 0x00
0000794c94dd5711  mov rax, 0x5AB2B8B81530
0000794c94dd571b  call rax
0000794c94dd571d  movaps xmm1, [rsp]
0000794c94dd5721  add rsp, 0x30
0000794c94dd5725  vmovaps xmm0, [rsp]
0000794c94dd572a  vmovaps xmm2, [rsp+0x10]
0000794c94dd5730  vmovaps xmm3, [rsp+0x20]
0000794c94dd5736  vmovaps xmm4, [rsp+0x30]
0000794c94dd573c  vmovaps xmm5, [rsp+0x40]
0000794c94dd5742  vmovaps xmm6, [rsp+0x50]
0000794c94dd5748  vmovaps xmm7, [rsp+0x60]
0000794c94dd574e  vmovaps xmm8, [rsp+0x70]
0000794c94dd5754  vmovaps xmm9, [rsp+0x80]
0000794c94dd575d  vmovaps xmm10, [rsp+0x90]
0000794c94dd5766  vmovaps xmm11, [rsp+0xA0]
0000794c94dd576f  vmovaps xmm12, [rsp+0xB0]
0000794c94dd5778  vmovaps xmm13, [rsp+0xC0]
0000794c94dd5781  vmovaps xmm14, [rsp+0xD0]
0000794c94dd578a  vmovaps xmm15, [rsp+0xE0]
0000794c94dd5793  add rsp, 0xF0
0000794c94dd579a  pop r11
0000794c94dd579c  pop r10
0000794c94dd579e  pop r9
0000794c94dd57a0  pop r8
0000794c94dd57a2  pop rsi
0000794c94dd57a3  pop rdi
0000794c94dd57a4  pop rdx
0000794c94dd57a5  pop rcx
0000794c94dd57a6  pop rax
0000794c94dd57a7  add rsp, 0x08
0000794c94dd57ab  jmp 0x0000794C94DD033B
0000794c94dd57b0  call 0x0000794C94C0E880
0000794c94dd57b5  jmp 0x0000794C94DD034E
0000794c94dd57ba  call 0x0000794C94C0C380
0000794c94dd57bf  jmp 0x0000794C94DD0359
0000794c94dd57c4  call 0x0000794C94C0D600
0000794c94dd57c9  jmp 0x0000794C94DD0364
0000794c94dd57ce  call 0x0000794C94BFF540
0000794c94dd57d3  jmp 0x0000794C94DD036F
0000794c94dd57d8  int3
0000794c94dd57d9  nop [rax], eax
0000794c94dd57e0  mov rax, [r15+0x40]
0000794c94dd57e4  mov r14, [r15+0x58]
0000794c94dd57e8  lea r12, [rax+r14*1]
0000794c94dd57ec  movaps xmm1, [r15+0x1D0]
0000794c94dd57f4  vmovaps [rsp+0x10], xmm1
0000794c94dd57fa  vmovaps xmm15, [rsp+0x10]
0000794c94dd5800  por xmm1, xmm15
0000794c94dd5805  movaps xmm14, [r15+0x1A0]
0000794c94dd580d  vmovaps [rsp+0x10], xmm14
0000794c94dd5813  vmovaps xmm13, [rsp+0x10]
0000794c94dd5819  por xmm14, xmm13
0000794c94dd581e  lea rax, [r12+0x30]
0000794c94dd5823  mov r11, [r13+rax*1]
0000794c94dd5828  lea rax, [r12+0x38]
0000794c94dd582d  mov r10, [r13+rax*1]
0000794c94dd5832  movq xmm13, r11
0000794c94dd5837  movq xmm12, r10
0000794c94dd583c  movq xmm13, xmm13
0000794c94dd5841  vmovaps [rsp+0x10], xmm13
0000794c94dd5847  movq xmm13, xmm13
0000794c94dd584c  movaps [r15+0x130], xmm13
0000794c94dd5854  movq xmm12, xmm12
0000794c94dd5859  vmovaps [rsp+0x20], xmm12
0000794c94dd585f  movq xmm12, xmm12
0000794c94dd5864  movaps [r15+0x280], xmm12
0000794c94dd586c  movaps xmm13, [r15+0x270]
0000794c94dd5874  vmovaps [rsp+0x30], xmm13
0000794c94dd587a  vmovaps xmm12, [rsp+0x30]
0000794c94dd5880  por xmm13, xmm12
0000794c94dd5885  lea rax, [r12+0x20]
0000794c94dd588a  mov r11, [r13+rax*1]
0000794c94dd588f  lea rax, [r12+0x28]
0000794c94dd5894  mov r10, [r13+rax*1]
0000794c94dd5899  movq xmm12, r11
0000794c94dd589e  movq xmm11, r10
0000794c94dd58a3  movq xmm12, xmm12
0000794c94dd58a8  vmovaps [rsp+0x30], xmm12
0000794c94dd58ae  movq xmm12, xmm12
0000794c94dd58b3  movaps [r15+0x150], xmm12
0000794c94dd58bb  movq xmm11, xmm11
0000794c94dd58c0  vmovaps [rsp+0x40], xmm11
0000794c94dd58c6  movq xmm11, xmm11
0000794c94dd58cb  movaps [r15+0x140], xmm11
0000794c94dd58d3  lea rax, [r12+0x10]
0000794c94dd58d8  mov r11, [r13+rax*1]
0000794c94dd58dd  lea rax, [r12+0x18]
0000794c94dd58e2  mov r10, [r13+rax*1]
0000794c94dd58e7  movq xmm12, r11
0000794c94dd58ec  movq xmm11, r10
0000794c94dd58f1  movq xmm12, xmm12
0000794c94dd58f6  vmovaps [rsp+0x50], xmm12
0000794c94dd58fc  movq xmm12, xmm12
0000794c94dd5901  movaps [r15+0x170], xmm12
0000794c94dd5909  movq xmm11, xmm11
0000794c94dd590e  vmovaps [rsp+0x60], xmm11
0000794c94dd5914  movq xmm11, xmm11
0000794c94dd5919  movaps [r15+0x160], xmm11
0000794c94dd5921  mov rax, [r13+r12*1]
0000794c94dd5926  vmovq xmm12, rax
0000794c94dd592b  vpbroadcastq xmm12, xmm12
0000794c94dd5930  lea rax, [r12+0x08]
0000794c94dd5935  mov r12, [r13+rax*1]
0000794c94dd593a  movq xmm11, r12
0000794c94dd593f  movaps [r15+0x230], xmm11
0000794c94dd5947  mov rax, [r15+0xF8]
0000794c94dd594e  lea r12, [rax+0x50]
0000794c94dd5952  movups xmm11, [r13+r12*1]
0000794c94dd5958  lea r12, [rax+0x60]
0000794c94dd595c  movups xmm10, [r13+r12*1]
0000794c94dd5962  lea r12, [rax+0x30]
0000794c94dd5966  movups xmm9, [r13+r12*1]
0000794c94dd596c  mov r12, [r15+0x50]
0000794c94dd5970  lea r11, [r12+r14*1]
0000794c94dd5974  mov [r15+0x60], r11
0000794c94dd5978  lea r12, [r14+0x40]
0000794c94dd597c  mov [r15+0x58], r12
0000794c94dd5980  movaps xmm8, xmm12
0000794c94dd5984  mulpd xmm8, xmm15
0000794c94dd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000794c94dd598f  ptest xmm7, xmm7
0000794c94dd5994  jnz 0x0000794C94DD67B7
0000794c94dd599a  movq xmm15, qword ptr [r15+0x230]
0000794c94dd59a3  vmovaps [rsp+0x70], xmm15
0000794c94dd59a9  vpermilpd xmm15, xmm15, 0x00
0000794c94dd59af  movaps xmm7, xmm9
0000794c94dd59b3  mulpd xmm7, xmm15
0000794c94dd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000794c94dd59bd  ptest xmm6, xmm6
0000794c94dd59c2  jnz 0x0000794C94DD68FB
0000794c94dd59c8  vxorps xmm15, xmm15, xmm15
0000794c94dd59cd  vpbroadcastq xmm15, xmm15
0000794c94dd59d2  movaps xmm9, xmm12
0000794c94dd59d6  mulpd xmm9, xmm10
0000794c94dd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000794c94dd59e1  ptest xmm6, xmm6
0000794c94dd59e6  jnz 0x0000794C94DD6A3D
0000794c94dd59ec  movaps xmm10, xmm12
0000794c94dd59f0  mulpd xmm10, xmm11
0000794c94dd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000794c94dd59fb  ptest xmm6, xmm6
0000794c94dd5a00  jnz 0x0000794C94DD6B81
0000794c94dd5a06  movaps xmm11, [r15+0x1F0]
0000794c94dd5a0e  movaps xmm6, xmm12
0000794c94dd5a12  mulpd xmm6, xmm11
0000794c94dd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000794c94dd5a1c  ptest xmm5, xmm5
0000794c94dd5a21  jnz 0x0000794C94DD6CC5
0000794c94dd5a27  movaps xmm12, [r15+0x2A0]
0000794c94dd5a2f  vmovaps [rsp+0x80], xmm12
0000794c94dd5a38  vmovaps xmm11, [rsp+0x80]
0000794c94dd5a41  por xmm12, xmm11
0000794c94dd5a46  movaps xmm11, [r15+0x250]
0000794c94dd5a4e  vmovaps [rsp+0x80], xmm11
0000794c94dd5a57  vmovaps xmm5, [rsp+0x80]
0000794c94dd5a60  por xmm11, xmm5
0000794c94dd5a65  vmovaps xmm4, [rsp+0x70]
0000794c94dd5a6b  vpermilpd xmm4, xmm4, 0x00
0000794c94dd5a71  movaps xmm3, xmm5
0000794c94dd5a74  mulpd xmm3, xmm4
0000794c94dd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000794c94dd5a7d  ptest xmm2, xmm2
0000794c94dd5a82  jnz 0x0000794C94DD6E07
0000794c94dd5a88  mov [rsp+0x80], rax
0000794c94dd5a90  xor eax, eax
0000794c94dd5a92  mov r14d, 0x200
0000794c94dd5a98  cmp r12, r14
0000794c94dd5a9b  cmc
0000794c94dd5a9c  lahf
0000794c94dd5a9d  seto al
0000794c94dd5aa0  mov [r15+0x108], eax
0000794c94dd5aa7  movaps xmm5, xmm8
0000794c94dd5aab  addpd xmm5, xmm15
0000794c94dd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000794c94dd5ab5  ptest xmm4, xmm4
0000794c94dd5aba  jnz 0x0000794C94DD6F47
0000794c94dd5ac0  movaps xmm8, [r15+0x1B0]
0000794c94dd5ac8  movaps xmm4, xmm9
0000794c94dd5acc  addpd xmm4, xmm8
0000794c94dd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000794c94dd5ad6  ptest xmm2, xmm2
0000794c94dd5adb  jnz 0x0000794C94DD7089
0000794c94dd5ae1  movaps xmm9, xmm10
0000794c94dd5ae5  addpd xmm9, xmm8
0000794c94dd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000794c94dd5af0  ptest xmm2, xmm2
0000794c94dd5af5  jnz 0x0000794C94DD71CB
0000794c94dd5afb  movaps xmm10, [r15+0x2F0]
0000794c94dd5b03  vmovaps [rsp+0x90], xmm10
0000794c94dd5b0c  vmovaps xmm8, [rsp+0x90]
0000794c94dd5b15  por xmm10, xmm8
0000794c94dd5b1a  movaps xmm8, [r15+0x2E0]
0000794c94dd5b22  vmovaps [rsp+0x90], xmm8
0000794c94dd5b2b  vmovaps xmm2, [rsp+0x90]
0000794c94dd5b34  por xmm8, xmm2
0000794c94dd5b39  movaps xmm2, [r15+0x2D0]
0000794c94dd5b41  vmovaps [rsp+0x90], xmm2
0000794c94dd5b4a  vmovaps [rsp+0xA0], xmm1
0000794c94dd5b53  vmovaps xmm1, [rsp+0x90]
0000794c94dd5b5c  por xmm2, xmm1
0000794c94dd5b60  movaps xmm1, [r15+0x200]
0000794c94dd5b68  vmovaps [rsp+0x90], xmm1
0000794c94dd5b71  vmovaps [rsp+0xB0], xmm15
0000794c94dd5b7a  vmovaps xmm15, [rsp+0x90]
0000794c94dd5b83  por xmm1, xmm15
0000794c94dd5b88  movaps xmm15, [r15+0x1C0]
0000794c94dd5b90  vmovaps [rsp+0x90], xmm15
0000794c94dd5b99  vmovaps [rsp+0xC0], xmm1
0000794c94dd5ba2  vmovaps xmm1, [rsp+0x90]
0000794c94dd5bab  por xmm15, xmm1
0000794c94dd5bb0  movaps xmm1, [r15+0x190]
0000794c94dd5bb8  vmovaps [rsp+0x90], xmm1
0000794c94dd5bc1  vmovaps [rsp+0xD0], xmm15
0000794c94dd5bca  vmovaps xmm15, [rsp+0x90]
0000794c94dd5bd3  por xmm1, xmm15
0000794c94dd5bd8  movaps xmm15, [r15+0x300]
0000794c94dd5be0  vmovaps [rsp+0x90], xmm15
0000794c94dd5be9  vmovaps [rsp+0xE0], xmm1
0000794c94dd5bf2  vmovaps xmm1, [rsp+0x90]
0000794c94dd5bfb  por xmm15, xmm1
0000794c94dd5c00  mov rax, [rsp+0x80]
0000794c94dd5c08  lea r14, [rax+0xA0]
0000794c94dd5c0f  movups xmm1, [r13+r14*1]
0000794c94dd5c15  lea r14, [rax+0xB0]
0000794c94dd5c1c  vmovaps [rsp+0x80], xmm1
0000794c94dd5c25  movups xmm1, [r13+r14*1]
0000794c94dd5c2b  vmovaps [rsp+0x90], xmm1
0000794c94dd5c34  vmovaps [rsp+0xF0], xmm15
0000794c94dd5c3d  vmovaps xmm15, [rsp+0xB0]
0000794c94dd5c46  vmovaps [rsp+0xB0], xmm14
0000794c94dd5c4f  movaps xmm1, xmm6
0000794c94dd5c52  addpd xmm1, xmm15
0000794c94dd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000794c94dd5c5c  ptest xmm14, xmm14
0000794c94dd5c62  jnz 0x0000794C94DD7323
0000794c94dd5c68  lea r14, [rax+0xF0]
0000794c94dd5c6f  movups xmm15, [r13+r14*1]
0000794c94dd5c75  movaps xmm14, xmm4
0000794c94dd5c79  addpd xmm14, xmm3
0000794c94dd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000794c94dd5c84  ptest xmm6, xmm6
0000794c94dd5c89  jnz 0x0000794C94DD746E
0000794c94dd5c8f  movaps xmm6, xmm9
0000794c94dd5c93  addpd xmm6, xmm7
0000794c94dd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000794c94dd5c9c  ptest xmm4, xmm4
0000794c94dd5ca1  jnz 0x0000794C94DD75B0
0000794c94dd5ca7  vmovaps xmm9, [rsp+0x70]
0000794c94dd5cad  vpermilpd xmm9, xmm9, 0x00
0000794c94dd5cb3  vmovaps xmm4, [rsp+0x90]
0000794c94dd5cbc  movaps xmm7, xmm4
0000794c94dd5cbf  mulpd xmm7, xmm9
0000794c94dd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000794c94dd5cc9  ptest xmm3, xmm3
0000794c94dd5cce  jnz 0x0000794C94DD76F1
0000794c94dd5cd4  vmovaps xmm9, [rsp+0x50]
0000794c94dd5cda  vpermilpd xmm9, xmm9, 0x00
0000794c94dd5ce0  movaps xmm4, xmm15
0000794c94dd5ce4  mulpd xmm4, xmm9
0000794c94dd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000794c94dd5cee  ptest xmm3, xmm3
0000794c94dd5cf3  jnz 0x0000794C94DD7832
0000794c94dd5cf9  lea r14, [rax+0xE0]
0000794c94dd5d00  movups xmm15, [r13+r14*1]
0000794c94dd5d06  vmovaps xmm9, [rsp+0x70]
0000794c94dd5d0c  vpermilpd xmm9, xmm9, 0x00
0000794c94dd5d12  vmovaps [rsp+0x70], xmm1
0000794c94dd5d18  vmovaps xmm1, [rsp+0x80]
0000794c94dd5d21  vmovaps [rsp+0x80], xmm15
0000794c94dd5d2a  movaps xmm3, xmm1
0000794c94dd5d2d  mulpd xmm3, xmm9
0000794c94dd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000794c94dd5d37  ptest xmm15, xmm15
0000794c94dd5d3d  jnz 0x0000794C94DD797E
0000794c94dd5d43  vmovaps xmm1, [rsp+0xF0]
0000794c94dd5d4c  vmovaps xmm15, [rsp+0xF0]
0000794c94dd5d55  por xmm1, xmm15
0000794c94dd5d5a  movaps [r15+0x300], xmm1
0000794c94dd5d62  vmovaps xmm15, [rsp+0xE0]
0000794c94dd5d6b  vmovaps xmm9, [rsp+0xE0]
0000794c94dd5d74  por xmm15, xmm9
0000794c94dd5d79  movaps [r15+0x190], xmm15
0000794c94dd5d81  vmovaps xmm9, [rsp+0x50]
0000794c94dd5d87  vpermilpd xmm9, xmm9, 0x00
0000794c94dd5d8d  vmovaps [rsp+0x90], xmm1
0000794c94dd5d96  vmovaps [rsp+0xE0], xmm15
0000794c94dd5d9f  vmovaps xmm15, [rsp+0x80]
0000794c94dd5da8  vmovaps [rsp+0x80], xmm14
0000794c94dd5db1  movaps xmm1, xmm15
0000794c94dd5db5  mulpd xmm1, xmm9
0000794c94dd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000794c94dd5dbf  ptest xmm14, xmm14
0000794c94dd5dc5  jnz 0x0000794C94DD7ABF
0000794c94dd5dcb  lea r14, [rax+0x90]
0000794c94dd5dd2  movups xmm15, [r13+r14*1]
0000794c94dd5dd8  vmovaps xmm14, [rsp+0xD0]
0000794c94dd5de1  vmovaps xmm9, [rsp+0xD0]
0000794c94dd5dea  por xmm14, xmm9
0000794c94dd5def  movaps [r15+0x1C0], xmm14
0000794c94dd5df7  vmovaps xmm9, [rsp+0xC0]
0000794c94dd5e00  vmovaps [rsp+0xD0], xmm1
0000794c94dd5e09  vmovaps xmm1, [rsp+0xC0]
0000794c94dd5e12  por xmm9, xmm1
0000794c94dd5e17  movaps [r15+0x200], xmm9
0000794c94dd5e1f  vmovaps [rsp+0xC0], xmm2
0000794c94dd5e28  vmovaps xmm1, [rsp+0xC0]
0000794c94dd5e31  por xmm2, xmm1
0000794c94dd5e35  movaps [r15+0x2D0], xmm2
0000794c94dd5e3d  vmovaps [rsp+0xC0], xmm8
0000794c94dd5e46  vmovaps xmm1, [rsp+0xC0]
0000794c94dd5e4f  por xmm8, xmm1
0000794c94dd5e54  movaps [r15+0x2E0], xmm8
0000794c94dd5e5c  vmovaps [rsp+0xC0], xmm15
0000794c94dd5e65  movaps xmm1, xmm5
0000794c94dd5e68  addpd xmm1, xmm7
0000794c94dd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000794c94dd5e71  ptest xmm15, xmm15
0000794c94dd5e77  jnz 0x0000794C94DD7C0B
0000794c94dd5e7d  vmovaps xmm15, [rsp+0x50]
0000794c94dd5e83  vpermilpd xmm15, xmm15, 0x00
0000794c94dd5e89  vmovaps xmm5, [rsp+0xC0]
0000794c94dd5e92  vmovaps [rsp+0xC0], xmm1
0000794c94dd5e9b  movaps xmm7, xmm5
0000794c94dd5e9e  mulpd xmm7, xmm15
0000794c94dd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000794c94dd5ea8  ptest xmm1, xmm1
0000794c94dd5ead  jnz 0x0000794C94DD7D4B
0000794c94dd5eb3  lea r14, [rax+0x80]
0000794c94dd5eba  movups xmm1, [r13+r14*1]
0000794c94dd5ec0  vmovaps xmm5, [rsp+0x70]
0000794c94dd5ec6  vmovaps [rsp+0x70], xmm1
0000794c94dd5ecc  movaps xmm15, xmm5
0000794c94dd5ed0  addpd xmm15, xmm3
0000794c94dd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000794c94dd5edb  ptest xmm1, xmm1
0000794c94dd5ee0  jnz 0x0000794C94DD7E96
0000794c94dd5ee6  vmovaps xmm5, [rsp+0x80]
0000794c94dd5eef  movaps xmm1, xmm5
0000794c94dd5ef2  addpd xmm1, xmm4
0000794c94dd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000794c94dd5efb  ptest xmm3, xmm3
0000794c94dd5f00  jnz 0x0000794C94DD7FD8
0000794c94dd5f06  vmovaps [rsp+0x80], xmm10
0000794c94dd5f0f  vmovaps xmm5, [rsp+0x80]
0000794c94dd5f18  por xmm10, xmm5
0000794c94dd5f1d  movaps [r15+0x2F0], xmm10
0000794c94dd5f25  vmovaps xmm5, [rsp+0x50]
0000794c94dd5f2b  vpermilpd xmm5, xmm5, 0x00
0000794c94dd5f31  vmovaps xmm3, [rsp+0x70]
0000794c94dd5f37  vmovaps [rsp+0x50], xmm1
0000794c94dd5f3d  movaps xmm4, xmm3
0000794c94dd5f40  mulpd xmm4, xmm5
0000794c94dd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000794c94dd5f49  ptest xmm1, xmm1
0000794c94dd5f4e  jnz 0x0000794C94DD8118
0000794c94dd5f54  lea r14, [rax+0xD0]
0000794c94dd5f5b  movups xmm1, [r13+r14*1]
0000794c94dd5f61  vmovaps xmm3, [rsp+0xD0]
0000794c94dd5f6a  vmovaps [rsp+0x70], xmm1
0000794c94dd5f70  movaps xmm5, xmm6
0000794c94dd5f73  addpd xmm5, xmm3
0000794c94dd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000794c94dd5f7c  ptest xmm1, xmm1
0000794c94dd5f81  jnz 0x0000794C94DD8262
0000794c94dd5f87  vmovaps xmm1, [rsp+0x60]
0000794c94dd5f8d  vpermilpd xmm1, xmm1, 0x00
0000794c94dd5f93  movaps xmm6, xmm9
0000794c94dd5f97  mulpd xmm6, xmm1
0000794c94dd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000794c94dd5fa0  ptest xmm3, xmm3
0000794c94dd5fa5  jnz 0x0000794C94DD83A2
0000794c94dd5fab  movaps [r15+0x260], xmm6
0000794c94dd5fb3  vxorps xmm1, xmm1, xmm1
0000794c94dd5fb7  vpbroadcastq xmm1, xmm1
0000794c94dd5fbc  movaps [r15+0x1B0], xmm1
0000794c94dd5fc4  vmovaps xmm1, [rsp+0x60]
0000794c94dd5fca  vpermilpd xmm1, xmm1, 0x00
0000794c94dd5fd0  vmovaps xmm3, [rsp+0x70]
0000794c94dd5fd6  vmovaps [rsp+0x70], xmm15
0000794c94dd5fdc  movaps xmm9, xmm3
0000794c94dd5fe0  mulpd xmm9, xmm1
0000794c94dd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000794c94dd5feb  ptest xmm15, xmm15
0000794c94dd5ff1  jnz 0x0000794C94DD84E3
0000794c94dd5ff7  lea r14, [rax+0xC0]
0000794c94dd5ffe  movups xmm1, [r13+r14*1]
0000794c94dd6004  vmovaps xmm3, [rsp+0xC0]
0000794c94dd600d  vmovaps [rsp+0x80], xmm1
0000794c94dd6016  movaps xmm15, xmm3
0000794c94dd601a  addpd xmm15, xmm7
0000794c94dd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000794c94dd6025  ptest xmm1, xmm1
0000794c94dd602a  jnz 0x0000794C94DD862F
0000794c94dd6030  vmovaps [rsp+0xC0], xmm13
0000794c94dd6039  vmovaps xmm1, [rsp+0xC0]
0000794c94dd6042  por xmm13, xmm1
0000794c94dd6047  movaps [r15+0x270], xmm13
0000794c94dd604f  vmovaps xmm1, [rsp+0xB0]
0000794c94dd6058  vmovaps xmm7, [rsp+0xB0]
0000794c94dd6061  por xmm1, xmm7
0000794c94dd6065  movaps [r15+0x1A0], xmm1
0000794c94dd606d  vmovaps xmm1, [rsp+0x60]
0000794c94dd6073  vpermilpd xmm1, xmm1, 0x00
0000794c94dd6079  vmovaps [rsp+0xB0], xmm1
0000794c94dd6082  vmovaps xmm1, [rsp+0x80]
0000794c94dd608b  vmovaps [rsp+0x80], xmm15
0000794c94dd6094  vmovaps xmm15, [rsp+0xB0]
0000794c94dd609d  vmovaps [rsp+0xB0], xmm14
0000794c94dd60a6  movaps xmm3, xmm1
0000794c94dd60a9  mulpd xmm3, xmm15
0000794c94dd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000794c94dd60b3  ptest xmm14, xmm14
0000794c94dd60b9  jnz 0x0000794C94DD8771
0000794c94dd60bf  lea r14, [rax+0x20]
0000794c94dd60c3  movups xmm1, [r13+r14*1]
0000794c94dd60c9  movaps [r15+0x110], xmm1
0000794c94dd60d1  vmovaps xmm14, [rsp+0x70]
0000794c94dd60d7  vmovaps [rsp+0x70], xmm1
0000794c94dd60dd  movaps xmm15, xmm14
0000794c94dd60e1  addpd xmm15, xmm4
0000794c94dd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000794c94dd60ec  ptest xmm1, xmm1
0000794c94dd60f1  jnz 0x0000794C94DD88BC
0000794c94dd60f7  vmovaps xmm1, [rsp+0x60]
0000794c94dd60fd  vpermilpd xmm1, xmm1, 0x00
0000794c94dd6103  movaps xmm14, xmm2
0000794c94dd6107  mulpd xmm14, xmm1
0000794c94dd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000794c94dd6112  ptest xmm4, xmm4
0000794c94dd6117  jnz 0x0000794C94DD89FF
0000794c94dd611d  vmovaps xmm4, [rsp+0x50]
0000794c94dd6123  movaps xmm1, xmm4
0000794c94dd6126  addpd xmm1, xmm9
0000794c94dd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000794c94dd6130  ptest xmm2, xmm2
0000794c94dd6135  jnz 0x0000794C94DD8B41
0000794c94dd613b  vmovaps xmm9, [rsp+0x30]
0000794c94dd6141  vpermilpd xmm9, xmm9, 0x00
0000794c94dd6147  vmovaps xmm2, [rsp+0x70]
0000794c94dd614d  vmovaps [rsp+0x50], xmm1
0000794c94dd6153  movaps xmm4, xmm2
0000794c94dd6156  mulpd xmm4, xmm9
0000794c94dd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000794c94dd6160  ptest xmm1, xmm1
0000794c94dd6165  jnz 0x0000794C94DD8C82
0000794c94dd616b  vmovaps xmm1, [rsp+0x30]
0000794c94dd6171  vpermilpd xmm1, xmm1, 0x00
0000794c94dd6177  vmovaps xmm2, [rsp+0x90]
0000794c94dd6180  vmovaps [rsp+0x60], xmm15
0000794c94dd6186  movaps xmm9, xmm2
0000794c94dd618a  mulpd xmm9, xmm1
0000794c94dd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000794c94dd6195  ptest xmm15, xmm15
0000794c94dd619b  jnz 0x0000794C94DD8DC3
0000794c94dd61a1  vmovaps xmm15, [rsp+0x80]
0000794c94dd61aa  movaps xmm1, xmm15
0000794c94dd61ae  addpd xmm1, xmm6
0000794c94dd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000794c94dd61b7  ptest xmm2, xmm2
0000794c94dd61bc  jnz 0x0000794C94DD8F05
0000794c94dd61c2  movaps xmm15, xmm5
0000794c94dd61c6  addpd xmm15, xmm3
0000794c94dd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000794c94dd61d1  ptest xmm6, xmm6
0000794c94dd61d6  jnz 0x0000794C94DD9046
0000794c94dd61dc  vmovaps xmm6, [rsp+0x30]
0000794c94dd61e2  vpermilpd xmm6, xmm6, 0x00
0000794c94dd61e8  movaps xmm5, xmm8
0000794c94dd61ec  mulpd xmm5, xmm6
0000794c94dd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000794c94dd61f5  ptest xmm3, xmm3
0000794c94dd61fa  jnz 0x0000794C94DD9188
0000794c94dd6200  vmovaps xmm8, [rsp+0x30]
0000794c94dd6206  vpermilpd xmm8, xmm8, 0x00
0000794c94dd620c  movaps xmm6, xmm10
0000794c94dd6210  mulpd xmm6, xmm8
0000794c94dd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000794c94dd621a  ptest xmm3, xmm3
0000794c94dd621f  jnz 0x0000794C94DD92C9
0000794c94dd6225  vmovaps xmm8, [rsp+0x60]
0000794c94dd622b  movaps xmm10, xmm8
0000794c94dd622f  addpd xmm10, xmm14
0000794c94dd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000794c94dd623a  ptest xmm3, xmm3
0000794c94dd623f  jnz 0x0000794C94DD940B
0000794c94dd6245  vmovaps xmm8, [rsp+0x50]
0000794c94dd624b  movaps xmm14, xmm8
0000794c94dd624f  addpd xmm14, xmm4
0000794c94dd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000794c94dd625a  ptest xmm3, xmm3
0000794c94dd625f  jnz 0x0000794C94DD954F
0000794c94dd6265  vmovaps xmm8, [rsp+0x40]
0000794c94dd626b  vpermilpd xmm8, xmm8, 0x00
0000794c94dd6271  movaps xmm4, xmm13
0000794c94dd6275  mulpd xmm4, xmm8
0000794c94dd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000794c94dd627f  ptest xmm3, xmm3
0000794c94dd6284  jnz 0x0000794C94DD9692
0000794c94dd628a  movaps xmm13, xmm15
0000794c94dd628e  addpd xmm13, xmm9
0000794c94dd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000794c94dd6299  ptest xmm8, xmm8
0000794c94dd629f  jnz 0x0000794C94DD97D4
0000794c94dd62a5  movaps xmm15, xmm1
0000794c94dd62a9  addpd xmm15, xmm5
0000794c94dd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000794c94dd62b4  ptest xmm9, xmm9
0000794c94dd62ba  jnz 0x0000794C94DD9918
0000794c94dd62c0  vmovaps [rsp+0x30], xmm11
0000794c94dd62c6  vmovaps xmm1, [rsp+0x30]
0000794c94dd62cc  por xmm11, xmm1
0000794c94dd62d1  movaps [r15+0x250], xmm11
0000794c94dd62d9  vmovaps [rsp+0x30], xmm12
0000794c94dd62df  vmovaps xmm1, [rsp+0x30]
0000794c94dd62e5  por xmm12, xmm1
0000794c94dd62ea  movaps [r15+0x2A0], xmm12
0000794c94dd62f2  vmovaps xmm1, [rsp+0xA0]
0000794c94dd62fb  vmovaps xmm11, [rsp+0xA0]
0000794c94dd6304  por xmm1, xmm11
0000794c94dd6309  movaps [r15+0x1D0], xmm1
0000794c94dd6311  lea r14, [rax+0x40]
0000794c94dd6315  movups xmm1, [r13+r14*1]
0000794c94dd631b  movaps [r15+0x2C0], xmm1
0000794c94dd6323  vmovaps xmm11, [rsp+0x40]
0000794c94dd6329  vpermilpd xmm11, xmm11, 0x00
0000794c94dd632f  vmovaps xmm8, [rsp+0xE0]
0000794c94dd6338  movaps xmm9, xmm8
0000794c94dd633c  mulpd xmm9, xmm11
0000794c94dd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000794c94dd6347  ptest xmm5, xmm5
0000794c94dd634c  jnz 0x0000794C94DD9A64
0000794c94dd6352  movaps xmm11, xmm10
0000794c94dd6356  addpd xmm11, xmm6
0000794c94dd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000794c94dd6361  ptest xmm8, xmm8
0000794c94dd6367  jnz 0x0000794C94DD9BA8
0000794c94dd636d  movaps xmm10, xmm14
0000794c94dd6371  addpd xmm10, xmm4
0000794c94dd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000794c94dd637c  ptest xmm8, xmm8
0000794c94dd6382  jnz 0x0000794C94DD9CEB
0000794c94dd6388  vmovaps xmm14, [rsp+0x40]
0000794c94dd638e  vpermilpd xmm14, xmm14, 0x00
0000794c94dd6394  movaps xmm8, xmm1
0000794c94dd6398  mulpd xmm8, xmm14
0000794c94dd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000794c94dd63a3  ptest xmm6, xmm6
0000794c94dd63a8  jnz 0x0000794C94DD9E2E
0000794c94dd63ae  movaps xmm1, [r15+0x2B0]
0000794c94dd63b6  vmovaps xmm14, [rsp+0x40]
0000794c94dd63bc  vpermilpd xmm14, xmm14, 0x00
0000794c94dd63c2  movaps xmm6, xmm1
0000794c94dd63c5  mulpd xmm6, xmm14
0000794c94dd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000794c94dd63cf  ptest xmm5, xmm5
0000794c94dd63d4  jnz 0x0000794C94DD9F71
0000794c94dd63da  vmovaps xmm1, [rsp+0x10]
0000794c94dd63e0  vpermilpd xmm1, xmm1, 0x00
0000794c94dd63e6  movaps xmm14, xmm12
0000794c94dd63ea  mulpd xmm14, xmm1
0000794c94dd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000794c94dd63f5  ptest xmm5, xmm5
0000794c94dd63fa  jnz 0x0000794C94DDA0B2
0000794c94dd6400  movaps xmm1, xmm13
0000794c94dd6404  addpd xmm1, xmm9
0000794c94dd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000794c94dd640e  ptest xmm12, xmm12
0000794c94dd6414  jnz 0x0000794C94DDA1F5
0000794c94dd641a  vmovaps xmm13, [rsp+0x10]
0000794c94dd6420  vpermilpd xmm13, xmm13, 0x00
0000794c94dd6426  movaps xmm12, xmm7
0000794c94dd642a  mulpd xmm12, xmm13
0000794c94dd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000794c94dd6435  ptest xmm9, xmm9
0000794c94dd643b  jnz 0x0000794C94DDA337
0000794c94dd6441  movaps xmm13, xmm15
0000794c94dd6445  addpd xmm13, xmm8
0000794c94dd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000794c94dd6450  ptest xmm9, xmm9
0000794c94dd6456  jnz 0x0000794C94DDA47A
0000794c94dd645c  movaps xmm15, [r15+0x290]
0000794c94dd6464  vmovaps xmm9, [rsp+0x10]
0000794c94dd646a  vpermilpd xmm9, xmm9, 0x00
0000794c94dd6470  movaps xmm8, xmm15
0000794c94dd6474  mulpd xmm8, xmm9
0000794c94dd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000794c94dd647f  ptest xmm7, xmm7
0000794c94dd6484  jnz 0x0000794C94DDA5BE
0000794c94dd648a  movaps xmm15, xmm11
0000794c94dd648e  addpd xmm15, xmm6
0000794c94dd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000794c94dd6499  ptest xmm9, xmm9
0000794c94dd649f  jnz 0x0000794C94DDA702
0000794c94dd64a5  movaps xmm11, [r15+0x1E0]
0000794c94dd64ad  vmovaps xmm9, [rsp+0x10]
0000794c94dd64b3  vpermilpd xmm9, xmm9, 0x00
0000794c94dd64b9  movaps xmm7, xmm11
0000794c94dd64bd  mulpd xmm7, xmm9
0000794c94dd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000794c94dd64c7  ptest xmm6, xmm6
0000794c94dd64cc  jnz 0x0000794C94DDA845
0000794c94dd64d2  movaps xmm11, xmm10
0000794c94dd64d6  addpd xmm11, xmm14
0000794c94dd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000794c94dd64e1  ptest xmm9, xmm9
0000794c94dd64e7  jnz 0x0000794C94DDA987
0000794c94dd64ed  lea r14, [rax+0x70]
0000794c94dd64f1  movups xmm14, [r13+r14*1]
0000794c94dd64f7  movaps [r15+0x240], xmm14
0000794c94dd64ff  movaps xmm10, xmm1
0000794c94dd6503  addpd xmm10, xmm12
0000794c94dd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000794c94dd650e  ptest xmm9, xmm9
0000794c94dd6514  jnz 0x0000794C94DDAAD5
0000794c94dd651a  movaps [r15+0x170], xmm10
0000794c94dd6522  vmovaps xmm1, [rsp+0x20]
0000794c94dd6528  vpermilpd xmm1, xmm1, 0x00
0000794c94dd652e  movaps xmm12, xmm14
0000794c94dd6532  mulpd xmm12, xmm1
0000794c94dd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000794c94dd653d  ptest xmm9, xmm9
0000794c94dd6543  jnz 0x0000794C94DDAC18
0000794c94dd6549  vmovaps xmm1, [rsp+0x20]
0000794c94dd654f  vpermilpd xmm1, xmm1, 0x00
0000794c94dd6555  vmovaps xmm9, [rsp+0xB0]
0000794c94dd655e  movaps xmm14, xmm9
0000794c94dd6562  mulpd xmm14, xmm1
0000794c94dd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000794c94dd656d  ptest xmm6, xmm6
0000794c94dd6572  jnz 0x0000794C94DDAD5B
0000794c94dd6578  movaps [r15+0x180], xmm14
0000794c94dd6580  movaps xmm1, xmm13
0000794c94dd6584  addpd xmm1, xmm8
0000794c94dd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000794c94dd658e  ptest xmm9, xmm9
0000794c94dd6594  jnz 0x0000794C94DDAE9E
0000794c94dd659a  movaps [r15+0x210], xmm1
0000794c94dd65a2  movups xmm13, [r13+rax*1]
0000794c94dd65a8  lea r14, [rax+0x10]
0000794c94dd65ac  movups xmm9, [r13+r14*1]
0000794c94dd65b2  movaps [r15+0x230], xmm9
0000794c94dd65ba  movaps xmm8, xmm15
0000794c94dd65be  addpd xmm8, xmm7
0000794c94dd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000794c94dd65c9  ptest xmm6, xmm6
0000794c94dd65ce  jnz 0x0000794C94DDAFF4
0000794c94dd65d4  movaps [r15+0x130], xmm8
0000794c94dd65dc  vmovaps xmm15, [rsp+0x20]
0000794c94dd65e2  vpermilpd xmm15, xmm15, 0x00
0000794c94dd65e8  movaps xmm7, xmm9
0000794c94dd65ec  mulpd xmm7, xmm15
0000794c94dd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000794c94dd65f6  ptest xmm6, xmm6
0000794c94dd65fb  jnz 0x0000794C94DDB137
0000794c94dd6601  movaps [r15+0x220], xmm7
0000794c94dd6609  vmovaps xmm15, [rsp+0x20]
0000794c94dd660f  vpermilpd xmm15, xmm15, 0x00
0000794c94dd6615  movaps xmm9, xmm13
0000794c94dd6619  mulpd xmm9, xmm15
0000794c94dd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000794c94dd6624  ptest xmm6, xmm6
0000794c94dd6629  jnz 0x0000794C94DDB279
0000794c94dd662f  movaps xmm15, xmm11
0000794c94dd6633  addpd xmm15, xmm12
0000794c94dd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000794c94dd663e  ptest xmm13, xmm13
0000794c94dd6644  jnz 0x0000794C94DDB3BD
0000794c94dd664a  movaps [r15+0x140], xmm15
0000794c94dd6652  movaps xmm13, xmm10
0000794c94dd6656  addpd xmm13, xmm14
0000794c94dd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000794c94dd6661  ptest xmm12, xmm12
0000794c94dd6667  jnz 0x0000794C94DDB501
0000794c94dd666d  movaps [r15+0x150], xmm13
0000794c94dd6675  movaps xmm14, xmm1
0000794c94dd6679  addpd xmm14, xmm7
0000794c94dd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000794c94dd6684  ptest xmm12, xmm12
0000794c94dd668a  jnz 0x0000794C94DDB645
0000794c94dd6690  movaps [r15+0x160], xmm14
0000794c94dd6698  movaps xmm1, xmm8
0000794c94dd669c  addpd xmm1, xmm9
0000794c94dd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000794c94dd66a6  ptest xmm12, xmm12
0000794c94dd66ac  jnz 0x0000794C94DDB787
0000794c94dd66b2  movaps [r15+0x120], xmm1
0000794c94dd66ba  movups [r13+r11*1], xmm15
0000794c94dd66c0  lea rax, [r11+0x10]
0000794c94dd66c4  movups [r13+rax*1], xmm13
0000794c94dd66ca  lea rax, [r11+0x20]
0000794c94dd66ce  movups [r13+rax*1], xmm14
0000794c94dd66d4  lea rax, [r11+0x30]
0000794c94dd66d8  movups [r13+rax*1], xmm1
0000794c94dd66de  mov eax, [r15+0x108]
0000794c94dd66e5  sahf
0000794c94dd66e6  jnz 0x0000794C94DD6718
0000794c94dd66e8  cmp dword ptr [r15+0x318], 0x00
0000794c94dd66f0  jz 0x0000794C94DDB900
0000794c94dd66f6  nop [rax+rax*1], ax
0000794c94dd66ff  nop [rax+rax*1], eax
0000794c94dd6707  mov eax, 0x410444
0000794c94dd670c  mov [r15+0x100], rax
0000794c94dd6713  jmp 0x0000794C94BFE110
0000794c94dd6718  cmp dword ptr [r15+0x318], 0x00
0000794c94dd6720  jz 0x0000794C94DD57E0
0000794c94dd6726  nop [rax+rax*1], ax
0000794c94dd672f  nop [rax+rax*1], eax
0000794c94dd6737  mov eax, 0x410278
0000794c94dd673c  mov [r15+0x100], rax
0000794c94dd6743  jmp 0x0000794C94BFE110
0000794c94dd6748  int3
0000794c94dd6749  call 0x0000794C94C0A4B0
0000794c94dd674e  jmp 0x0000794C94DD5828
0000794c94dd6753  call 0x0000794C94C09240
0000794c94dd6758  jmp 0x0000794C94DD5832
0000794c94dd675d  call 0x0000794C94C0A4B0
0000794c94dd6762  jmp 0x0000794C94DD588F
0000794c94dd6767  call 0x0000794C94C09240
0000794c94dd676c  jmp 0x0000794C94DD5899
0000794c94dd6771  call 0x0000794C94C0A4B0
0000794c94dd6776  jmp 0x0000794C94DD58DD
0000794c94dd677b  call 0x0000794C94C09240
0000794c94dd6780  jmp 0x0000794C94DD58E7
0000794c94dd6785  call 0x0000794C94CB47C0
0000794c94dd678a  jmp 0x0000794C94DD5926
0000794c94dd678f  call 0x0000794C94C0B720
0000794c94dd6794  jmp 0x0000794C94DD593A
0000794c94dd6799  call 0x0000794C94CBFC30
0000794c94dd679e  jmp 0x0000794C94DD5958
0000794c94dd67a3  call 0x0000794C94CBE9C0
0000794c94dd67a8  jmp 0x0000794C94DD5962
0000794c94dd67ad  call 0x0000794C94CBD750
0000794c94dd67b2  jmp 0x0000794C94DD596C
0000794c94dd67b7  sub rsp, 0x08
0000794c94dd67bb  push rax
0000794c94dd67bc  push rcx
0000794c94dd67bd  push rdx
0000794c94dd67be  push rdi
0000794c94dd67bf  push rsi
0000794c94dd67c0  push r8
0000794c94dd67c2  push r9
0000794c94dd67c4  push r10
0000794c94dd67c6  push r11
0000794c94dd67c8  sub rsp, 0xF0
0000794c94dd67cf  vmovaps [rsp], xmm0
0000794c94dd67d4  vmovaps [rsp+0x10], xmm1
0000794c94dd67da  vmovaps [rsp+0x20], xmm2
0000794c94dd67e0  vmovaps [rsp+0x30], xmm3
0000794c94dd67e6  vmovaps [rsp+0x40], xmm4
0000794c94dd67ec  vmovaps [rsp+0x50], xmm5
0000794c94dd67f2  vmovaps [rsp+0x60], xmm6
0000794c94dd67f8  vmovaps [rsp+0x70], xmm7
0000794c94dd67fe  vmovaps [rsp+0x80], xmm9
0000794c94dd6807  vmovaps [rsp+0x90], xmm10
0000794c94dd6810  vmovaps [rsp+0xA0], xmm11
0000794c94dd6819  vmovaps [rsp+0xB0], xmm12
0000794c94dd6822  vmovaps [rsp+0xC0], xmm13
0000794c94dd682b  vmovaps [rsp+0xD0], xmm14
0000794c94dd6834  vmovaps [rsp+0xE0], xmm15
0000794c94dd683d  sub rsp, 0x30
0000794c94dd6841  movaps [rsp], xmm8
0000794c94dd6846  movaps [rsp+0x10], xmm12
0000794c94dd684c  movaps [rsp+0x20], xmm15
0000794c94dd6852  lea rdi, [rsp]
0000794c94dd6856  mov esi, 0x00
0000794c94dd685b  mov rax, 0x5AB2B8B81530
0000794c94dd6865  call rax
0000794c94dd6867  movaps xmm8, [rsp]
0000794c94dd686c  add rsp, 0x30
0000794c94dd6870  vmovaps xmm0, [rsp]
0000794c94dd6875  vmovaps xmm1, [rsp+0x10]
0000794c94dd687b  vmovaps xmm2, [rsp+0x20]
0000794c94dd6881  vmovaps xmm3, [rsp+0x30]
0000794c94dd6887  vmovaps xmm4, [rsp+0x40]
0000794c94dd688d  vmovaps xmm5, [rsp+0x50]
0000794c94dd6893  vmovaps xmm6, [rsp+0x60]
0000794c94dd6899  vmovaps xmm7, [rsp+0x70]
0000794c94dd689f  vmovaps xmm9, [rsp+0x80]
0000794c94dd68a8  vmovaps xmm10, [rsp+0x90]
0000794c94dd68b1  vmovaps xmm11, [rsp+0xA0]
0000794c94dd68ba  vmovaps xmm12, [rsp+0xB0]
0000794c94dd68c3  vmovaps xmm13, [rsp+0xC0]
0000794c94dd68cc  vmovaps xmm14, [rsp+0xD0]
0000794c94dd68d5  vmovaps xmm15, [rsp+0xE0]
0000794c94dd68de  add rsp, 0xF0
0000794c94dd68e5  pop r11
0000794c94dd68e7  pop r10
0000794c94dd68e9  pop r9
0000794c94dd68eb  pop r8
0000794c94dd68ed  pop rsi
0000794c94dd68ee  pop rdi
0000794c94dd68ef  pop rdx
0000794c94dd68f0  pop rcx
0000794c94dd68f1  pop rax
0000794c94dd68f2  add rsp, 0x08
0000794c94dd68f6  jmp 0x0000794C94DD599A
0000794c94dd68fb  sub rsp, 0x08
0000794c94dd68ff  push rax
0000794c94dd6900  push rcx
0000794c94dd6901  push rdx
0000794c94dd6902  push rdi
0000794c94dd6903  push rsi
0000794c94dd6904  push r8
0000794c94dd6906  push r9
0000794c94dd6908  push r10
0000794c94dd690a  push r11
0000794c94dd690c  sub rsp, 0xF0
0000794c94dd6913  vmovaps [rsp], xmm0
0000794c94dd6918  vmovaps [rsp+0x10], xmm1
0000794c94dd691e  vmovaps [rsp+0x20], xmm2
0000794c94dd6924  vmovaps [rsp+0x30], xmm3
0000794c94dd692a  vmovaps [rsp+0x40], xmm4
0000794c94dd6930  vmovaps [rsp+0x50], xmm5
0000794c94dd6936  vmovaps [rsp+0x60], xmm6
0000794c94dd693c  vmovaps [rsp+0x70], xmm8
0000794c94dd6942  vmovaps [rsp+0x80], xmm9
0000794c94dd694b  vmovaps [rsp+0x90], xmm10
0000794c94dd6954  vmovaps [rsp+0xA0], xmm11
0000794c94dd695d  vmovaps [rsp+0xB0], xmm12
0000794c94dd6966  vmovaps [rsp+0xC0], xmm13
0000794c94dd696f  vmovaps [rsp+0xD0], xmm14
0000794c94dd6978  vmovaps [rsp+0xE0], xmm15
0000794c94dd6981  sub rsp, 0x30
0000794c94dd6985  movaps [rsp], xmm7
0000794c94dd6989  movaps [rsp+0x10], xmm9
0000794c94dd698f  movaps [rsp+0x20], xmm15
0000794c94dd6995  lea rdi, [rsp]
0000794c94dd6999  mov esi, 0x00
0000794c94dd699e  mov rax, 0x5AB2B8B81530
0000794c94dd69a8  call rax
0000794c94dd69aa  movaps xmm7, [rsp]
0000794c94dd69ae  add rsp, 0x30
0000794c94dd69b2  vmovaps xmm0, [rsp]
0000794c94dd69b7  vmovaps xmm1, [rsp+0x10]
0000794c94dd69bd  vmovaps xmm2, [rsp+0x20]
0000794c94dd69c3  vmovaps xmm3, [rsp+0x30]
0000794c94dd69c9  vmovaps xmm4, [rsp+0x40]
0000794c94dd69cf  vmovaps xmm5, [rsp+0x50]
0000794c94dd69d5  vmovaps xmm6, [rsp+0x60]
0000794c94dd69db  vmovaps xmm8, [rsp+0x70]
0000794c94dd69e1  vmovaps xmm9, [rsp+0x80]
0000794c94dd69ea  vmovaps xmm10, [rsp+0x90]
0000794c94dd69f3  vmovaps xmm11, [rsp+0xA0]
0000794c94dd69fc  vmovaps xmm12, [rsp+0xB0]
0000794c94dd6a05  vmovaps xmm13, [rsp+0xC0]
0000794c94dd6a0e  vmovaps xmm14, [rsp+0xD0]
0000794c94dd6a17  vmovaps xmm15, [rsp+0xE0]
0000794c94dd6a20  add rsp, 0xF0
0000794c94dd6a27  pop r11
0000794c94dd6a29  pop r10
0000794c94dd6a2b  pop r9
0000794c94dd6a2d  pop r8
0000794c94dd6a2f  pop rsi
0000794c94dd6a30  pop rdi
0000794c94dd6a31  pop rdx
0000794c94dd6a32  pop rcx
0000794c94dd6a33  pop rax
0000794c94dd6a34  add rsp, 0x08
0000794c94dd6a38  jmp 0x0000794C94DD59C8
0000794c94dd6a3d  sub rsp, 0x08
0000794c94dd6a41  push rax
0000794c94dd6a42  push rcx
0000794c94dd6a43  push rdx
0000794c94dd6a44  push rdi
0000794c94dd6a45  push rsi
0000794c94dd6a46  push r8
0000794c94dd6a48  push r9
0000794c94dd6a4a  push r10
0000794c94dd6a4c  push r11
0000794c94dd6a4e  sub rsp, 0xF0
0000794c94dd6a55  vmovaps [rsp], xmm0
0000794c94dd6a5a  vmovaps [rsp+0x10], xmm1
0000794c94dd6a60  vmovaps [rsp+0x20], xmm2
0000794c94dd6a66  vmovaps [rsp+0x30], xmm3
0000794c94dd6a6c  vmovaps [rsp+0x40], xmm4
0000794c94dd6a72  vmovaps [rsp+0x50], xmm5
0000794c94dd6a78  vmovaps [rsp+0x60], xmm6
0000794c94dd6a7e  vmovaps [rsp+0x70], xmm7
0000794c94dd6a84  vmovaps [rsp+0x80], xmm8
0000794c94dd6a8d  vmovaps [rsp+0x90], xmm10
0000794c94dd6a96  vmovaps [rsp+0xA0], xmm11
0000794c94dd6a9f  vmovaps [rsp+0xB0], xmm12
0000794c94dd6aa8  vmovaps [rsp+0xC0], xmm13
0000794c94dd6ab1  vmovaps [rsp+0xD0], xmm14
0000794c94dd6aba  vmovaps [rsp+0xE0], xmm15
0000794c94dd6ac3  sub rsp, 0x30
0000794c94dd6ac7  movaps [rsp], xmm9
0000794c94dd6acc  movaps [rsp+0x10], xmm12
0000794c94dd6ad2  movaps [rsp+0x20], xmm10
0000794c94dd6ad8  lea rdi, [rsp]
0000794c94dd6adc  mov esi, 0x00
0000794c94dd6ae1  mov rax, 0x5AB2B8B81530
0000794c94dd6aeb  call rax
0000794c94dd6aed  movaps xmm9, [rsp]
0000794c94dd6af2  add rsp, 0x30
0000794c94dd6af6  vmovaps xmm0, [rsp]
0000794c94dd6afb  vmovaps xmm1, [rsp+0x10]
0000794c94dd6b01  vmovaps xmm2, [rsp+0x20]
0000794c94dd6b07  vmovaps xmm3, [rsp+0x30]
0000794c94dd6b0d  vmovaps xmm4, [rsp+0x40]
0000794c94dd6b13  vmovaps xmm5, [rsp+0x50]
0000794c94dd6b19  vmovaps xmm6, [rsp+0x60]
0000794c94dd6b1f  vmovaps xmm7, [rsp+0x70]
0000794c94dd6b25  vmovaps xmm8, [rsp+0x80]
0000794c94dd6b2e  vmovaps xmm10, [rsp+0x90]
0000794c94dd6b37  vmovaps xmm11, [rsp+0xA0]
0000794c94dd6b40  vmovaps xmm12, [rsp+0xB0]
0000794c94dd6b49  vmovaps xmm13, [rsp+0xC0]
0000794c94dd6b52  vmovaps xmm14, [rsp+0xD0]
0000794c94dd6b5b  vmovaps xmm15, [rsp+0xE0]
0000794c94dd6b64  add rsp, 0xF0
0000794c94dd6b6b  pop r11
0000794c94dd6b6d  pop r10
0000794c94dd6b6f  pop r9
0000794c94dd6b71  pop r8
0000794c94dd6b73  pop rsi
0000794c94dd6b74  pop rdi
0000794c94dd6b75  pop rdx
0000794c94dd6b76  pop rcx
0000794c94dd6b77  pop rax
0000794c94dd6b78  add rsp, 0x08
0000794c94dd6b7c  jmp 0x0000794C94DD59EC
0000794c94dd6b81  sub rsp, 0x08
0000794c94dd6b85  push rax
0000794c94dd6b86  push rcx
0000794c94dd6b87  push rdx
0000794c94dd6b88  push rdi
0000794c94dd6b89  push rsi
0000794c94dd6b8a  push r8
0000794c94dd6b8c  push r9
0000794c94dd6b8e  push r10
0000794c94dd6b90  push r11
0000794c94dd6b92  sub rsp, 0xF0
0000794c94dd6b99  vmovaps [rsp], xmm0
0000794c94dd6b9e  vmovaps [rsp+0x10], xmm1
0000794c94dd6ba4  vmovaps [rsp+0x20], xmm2
0000794c94dd6baa  vmovaps [rsp+0x30], xmm3
0000794c94dd6bb0  vmovaps [rsp+0x40], xmm4
0000794c94dd6bb6  vmovaps [rsp+0x50], xmm5
0000794c94dd6bbc  vmovaps [rsp+0x60], xmm6
0000794c94dd6bc2  vmovaps [rsp+0x70], xmm7
0000794c94dd6bc8  vmovaps [rsp+0x80], xmm8
0000794c94dd6bd1  vmovaps [rsp+0x90], xmm9
0000794c94dd6bda  vmovaps [rsp+0xA0], xmm11
0000794c94dd6be3  vmovaps [rsp+0xB0], xmm12
0000794c94dd6bec  vmovaps [rsp+0xC0], xmm13
0000794c94dd6bf5  vmovaps [rsp+0xD0], xmm14
0000794c94dd6bfe  vmovaps [rsp+0xE0], xmm15
0000794c94dd6c07  sub rsp, 0x30
0000794c94dd6c0b  movaps [rsp], xmm10
0000794c94dd6c10  movaps [rsp+0x10], xmm12
0000794c94dd6c16  movaps [rsp+0x20], xmm11
0000794c94dd6c1c  lea rdi, [rsp]
0000794c94dd6c20  mov esi, 0x00
0000794c94dd6c25  mov rax, 0x5AB2B8B81530
0000794c94dd6c2f  call rax
0000794c94dd6c31  movaps xmm10, [rsp]
0000794c94dd6c36  add rsp, 0x30
0000794c94dd6c3a  vmovaps xmm0, [rsp]
0000794c94dd6c3f  vmovaps xmm1, [rsp+0x10]
0000794c94dd6c45  vmovaps xmm2, [rsp+0x20]
0000794c94dd6c4b  vmovaps xmm3, [rsp+0x30]
0000794c94dd6c51  vmovaps xmm4, [rsp+0x40]
0000794c94dd6c57  vmovaps xmm5, [rsp+0x50]
0000794c94dd6c5d  vmovaps xmm6, [rsp+0x60]
0000794c94dd6c63  vmovaps xmm7, [rsp+0x70]
0000794c94dd6c69  vmovaps xmm8, [rsp+0x80]
0000794c94dd6c72  vmovaps xmm9, [rsp+0x90]
0000794c94dd6c7b  vmovaps xmm11, [rsp+0xA0]
0000794c94dd6c84  vmovaps xmm12, [rsp+0xB0]
0000794c94dd6c8d  vmovaps xmm13, [rsp+0xC0]
0000794c94dd6c96  vmovaps xmm14, [rsp+0xD0]
0000794c94dd6c9f  vmovaps xmm15, [rsp+0xE0]
0000794c94dd6ca8  add rsp, 0xF0
0000794c94dd6caf  pop r11
0000794c94dd6cb1  pop r10
0000794c94dd6cb3  pop r9
0000794c94dd6cb5  pop r8
0000794c94dd6cb7  pop rsi
0000794c94dd6cb8  pop rdi
0000794c94dd6cb9  pop rdx
0000794c94dd6cba  pop rcx
0000794c94dd6cbb  pop rax
0000794c94dd6cbc  add rsp, 0x08
0000794c94dd6cc0  jmp 0x0000794C94DD5A06
0000794c94dd6cc5  sub rsp, 0x08
0000794c94dd6cc9  push rax
0000794c94dd6cca  push rcx
0000794c94dd6ccb  push rdx
0000794c94dd6ccc  push rdi
0000794c94dd6ccd  push rsi
0000794c94dd6cce  push r8
0000794c94dd6cd0  push r9
0000794c94dd6cd2  push r10
0000794c94dd6cd4  push r11
0000794c94dd6cd6  sub rsp, 0xF0
0000794c94dd6cdd  vmovaps [rsp], xmm0
0000794c94dd6ce2  vmovaps [rsp+0x10], xmm1
0000794c94dd6ce8  vmovaps [rsp+0x20], xmm2
0000794c94dd6cee  vmovaps [rsp+0x30], xmm3
0000794c94dd6cf4  vmovaps [rsp+0x40], xmm4
0000794c94dd6cfa  vmovaps [rsp+0x50], xmm5
0000794c94dd6d00  vmovaps [rsp+0x60], xmm7
0000794c94dd6d06  vmovaps [rsp+0x70], xmm8
0000794c94dd6d0c  vmovaps [rsp+0x80], xmm9
0000794c94dd6d15  vmovaps [rsp+0x90], xmm10
0000794c94dd6d1e  vmovaps [rsp+0xA0], xmm11
0000794c94dd6d27  vmovaps [rsp+0xB0], xmm12
0000794c94dd6d30  vmovaps [rsp+0xC0], xmm13
0000794c94dd6d39  vmovaps [rsp+0xD0], xmm14
0000794c94dd6d42  vmovaps [rsp+0xE0], xmm15
0000794c94dd6d4b  sub rsp, 0x30
0000794c94dd6d4f  movaps [rsp], xmm6
0000794c94dd6d53  movaps [rsp+0x10], xmm12
0000794c94dd6d59  movaps [rsp+0x20], xmm11
0000794c94dd6d5f  lea rdi, [rsp]
0000794c94dd6d63  mov esi, 0x00
0000794c94dd6d68  mov rax, 0x5AB2B8B81530
0000794c94dd6d72  call rax
0000794c94dd6d74  movaps xmm6, [rsp]
0000794c94dd6d78  add rsp, 0x30
0000794c94dd6d7c  vmovaps xmm0, [rsp]
0000794c94dd6d81  vmovaps xmm1, [rsp+0x10]
0000794c94dd6d87  vmovaps xmm2, [rsp+0x20]
0000794c94dd6d8d  vmovaps xmm3, [rsp+0x30]
0000794c94dd6d93  vmovaps xmm4, [rsp+0x40]
0000794c94dd6d99  vmovaps xmm5, [rsp+0x50]
0000794c94dd6d9f  vmovaps xmm7, [rsp+0x60]
0000794c94dd6da5  vmovaps xmm8, [rsp+0x70]
0000794c94dd6dab  vmovaps xmm9, [rsp+0x80]
0000794c94dd6db4  vmovaps xmm10, [rsp+0x90]
0000794c94dd6dbd  vmovaps xmm11, [rsp+0xA0]
0000794c94dd6dc6  vmovaps xmm12, [rsp+0xB0]
0000794c94dd6dcf  vmovaps xmm13, [rsp+0xC0]
0000794c94dd6dd8  vmovaps xmm14, [rsp+0xD0]
0000794c94dd6de1  vmovaps xmm15, [rsp+0xE0]
0000794c94dd6dea  add rsp, 0xF0
0000794c94dd6df1  pop r11
0000794c94dd6df3  pop r10
0000794c94dd6df5  pop r9
0000794c94dd6df7  pop r8
0000794c94dd6df9  pop rsi
0000794c94dd6dfa  pop rdi
0000794c94dd6dfb  pop rdx
0000794c94dd6dfc  pop rcx
0000794c94dd6dfd  pop rax
0000794c94dd6dfe  add rsp, 0x08
0000794c94dd6e02  jmp 0x0000794C94DD5A27
0000794c94dd6e07  sub rsp, 0x08
0000794c94dd6e0b  push rax
0000794c94dd6e0c  push rcx
0000794c94dd6e0d  push rdx
0000794c94dd6e0e  push rdi
0000794c94dd6e0f  push rsi
0000794c94dd6e10  push r8
0000794c94dd6e12  push r9
0000794c94dd6e14  push r10
0000794c94dd6e16  push r11
0000794c94dd6e18  sub rsp, 0xF0
0000794c94dd6e1f  vmovaps [rsp], xmm0
0000794c94dd6e24  vmovaps [rsp+0x10], xmm1
0000794c94dd6e2a  vmovaps [rsp+0x20], xmm2
0000794c94dd6e30  vmovaps [rsp+0x30], xmm4
0000794c94dd6e36  vmovaps [rsp+0x40], xmm5
0000794c94dd6e3c  vmovaps [rsp+0x50], xmm6
0000794c94dd6e42  vmovaps [rsp+0x60], xmm7
0000794c94dd6e48  vmovaps [rsp+0x70], xmm8
0000794c94dd6e4e  vmovaps [rsp+0x80], xmm9
0000794c94dd6e57  vmovaps [rsp+0x90], xmm10
0000794c94dd6e60  vmovaps [rsp+0xA0], xmm11
0000794c94dd6e69  vmovaps [rsp+0xB0], xmm12
0000794c94dd6e72  vmovaps [rsp+0xC0], xmm13
0000794c94dd6e7b  vmovaps [rsp+0xD0], xmm14
0000794c94dd6e84  vmovaps [rsp+0xE0], xmm15
0000794c94dd6e8d  sub rsp, 0x30
0000794c94dd6e91  movaps [rsp], xmm3
0000794c94dd6e95  movaps [rsp+0x10], xmm5
0000794c94dd6e9a  movaps [rsp+0x20], xmm4
0000794c94dd6e9f  lea rdi, [rsp]
0000794c94dd6ea3  mov esi, 0x00
0000794c94dd6ea8  mov rax, 0x5AB2B8B81530
0000794c94dd6eb2  call rax
0000794c94dd6eb4  movaps xmm3, [rsp]
0000794c94dd6eb8  add rsp, 0x30
0000794c94dd6ebc  vmovaps xmm0, [rsp]
0000794c94dd6ec1  vmovaps xmm1, [rsp+0x10]
0000794c94dd6ec7  vmovaps xmm2, [rsp+0x20]
0000794c94dd6ecd  vmovaps xmm4, [rsp+0x30]
0000794c94dd6ed3  vmovaps xmm5, [rsp+0x40]
0000794c94dd6ed9  vmovaps xmm6, [rsp+0x50]
0000794c94dd6edf  vmovaps xmm7, [rsp+0x60]
0000794c94dd6ee5  vmovaps xmm8, [rsp+0x70]
0000794c94dd6eeb  vmovaps xmm9, [rsp+0x80]
0000794c94dd6ef4  vmovaps xmm10, [rsp+0x90]
0000794c94dd6efd  vmovaps xmm11, [rsp+0xA0]
0000794c94dd6f06  vmovaps xmm12, [rsp+0xB0]
0000794c94dd6f0f  vmovaps xmm13, [rsp+0xC0]
0000794c94dd6f18  vmovaps xmm14, [rsp+0xD0]
0000794c94dd6f21  vmovaps xmm15, [rsp+0xE0]
0000794c94dd6f2a  add rsp, 0xF0
0000794c94dd6f31  pop r11
0000794c94dd6f33  pop r10
0000794c94dd6f35  pop r9
0000794c94dd6f37  pop r8
0000794c94dd6f39  pop rsi
0000794c94dd6f3a  pop rdi
0000794c94dd6f3b  pop rdx
0000794c94dd6f3c  pop rcx
0000794c94dd6f3d  pop rax
0000794c94dd6f3e  add rsp, 0x08
0000794c94dd6f42  jmp 0x0000794C94DD5A88
0000794c94dd6f47  sub rsp, 0x08
0000794c94dd6f4b  push rax
0000794c94dd6f4c  push rcx
0000794c94dd6f4d  push rdx
0000794c94dd6f4e  push rdi
0000794c94dd6f4f  push rsi
0000794c94dd6f50  push r8
0000794c94dd6f52  push r9
0000794c94dd6f54  push r10
0000794c94dd6f56  push r11
0000794c94dd6f58  sub rsp, 0xF0
0000794c94dd6f5f  vmovaps [rsp], xmm0
0000794c94dd6f64  vmovaps [rsp+0x10], xmm1
0000794c94dd6f6a  vmovaps [rsp+0x20], xmm2
0000794c94dd6f70  vmovaps [rsp+0x30], xmm3
0000794c94dd6f76  vmovaps [rsp+0x40], xmm4
0000794c94dd6f7c  vmovaps [rsp+0x50], xmm6
0000794c94dd6f82  vmovaps [rsp+0x60], xmm7
0000794c94dd6f88  vmovaps [rsp+0x70], xmm8
0000794c94dd6f8e  vmovaps [rsp+0x80], xmm9
0000794c94dd6f97  vmovaps [rsp+0x90], xmm10
0000794c94dd6fa0  vmovaps [rsp+0xA0], xmm11
0000794c94dd6fa9  vmovaps [rsp+0xB0], xmm12
0000794c94dd6fb2  vmovaps [rsp+0xC0], xmm13
0000794c94dd6fbb  vmovaps [rsp+0xD0], xmm14
0000794c94dd6fc4  vmovaps [rsp+0xE0], xmm15
0000794c94dd6fcd  sub rsp, 0x30
0000794c94dd6fd1  movaps [rsp], xmm5
0000794c94dd6fd5  movaps [rsp+0x10], xmm8
0000794c94dd6fdb  movaps [rsp+0x20], xmm15
0000794c94dd6fe1  lea rdi, [rsp]
0000794c94dd6fe5  mov esi, 0x00
0000794c94dd6fea  mov rax, 0x5AB2B8B81530
0000794c94dd6ff4  call rax
0000794c94dd6ff6  movaps xmm5, [rsp]
0000794c94dd6ffa  add rsp, 0x30
0000794c94dd6ffe  vmovaps xmm0, [rsp]
0000794c94dd7003  vmovaps xmm1, [rsp+0x10]
0000794c94dd7009  vmovaps xmm2, [rsp+0x20]
0000794c94dd700f  vmovaps xmm3, [rsp+0x30]
0000794c94dd7015  vmovaps xmm4, [rsp+0x40]
0000794c94dd701b  vmovaps xmm6, [rsp+0x50]
0000794c94dd7021  vmovaps xmm7, [rsp+0x60]
0000794c94dd7027  vmovaps xmm8, [rsp+0x70]
0000794c94dd702d  vmovaps xmm9, [rsp+0x80]
0000794c94dd7036  vmovaps xmm10, [rsp+0x90]
0000794c94dd703f  vmovaps xmm11, [rsp+0xA0]
0000794c94dd7048  vmovaps xmm12, [rsp+0xB0]
0000794c94dd7051  vmovaps xmm13, [rsp+0xC0]
0000794c94dd705a  vmovaps xmm14, [rsp+0xD0]
0000794c94dd7063  vmovaps xmm15, [rsp+0xE0]
0000794c94dd706c  add rsp, 0xF0
0000794c94dd7073  pop r11
0000794c94dd7075  pop r10
0000794c94dd7077  pop r9
0000794c94dd7079  pop r8
0000794c94dd707b  pop rsi
0000794c94dd707c  pop rdi
0000794c94dd707d  pop rdx
0000794c94dd707e  pop rcx
0000794c94dd707f  pop rax
0000794c94dd7080  add rsp, 0x08
0000794c94dd7084  jmp 0x0000794C94DD5AC0
0000794c94dd7089  sub rsp, 0x08
0000794c94dd708d  push rax
0000794c94dd708e  push rcx
0000794c94dd708f  push rdx
0000794c94dd7090  push rdi
0000794c94dd7091  push rsi
0000794c94dd7092  push r8
0000794c94dd7094  push r9
0000794c94dd7096  push r10
0000794c94dd7098  push r11
0000794c94dd709a  sub rsp, 0xF0
0000794c94dd70a1  vmovaps [rsp], xmm0
0000794c94dd70a6  vmovaps [rsp+0x10], xmm1
0000794c94dd70ac  vmovaps [rsp+0x20], xmm2
0000794c94dd70b2  vmovaps [rsp+0x30], xmm3
0000794c94dd70b8  vmovaps [rsp+0x40], xmm5
0000794c94dd70be  vmovaps [rsp+0x50], xmm6
0000794c94dd70c4  vmovaps [rsp+0x60], xmm7
0000794c94dd70ca  vmovaps [rsp+0x70], xmm8
0000794c94dd70d0  vmovaps [rsp+0x80], xmm9
0000794c94dd70d9  vmovaps [rsp+0x90], xmm10
0000794c94dd70e2  vmovaps [rsp+0xA0], xmm11
0000794c94dd70eb  vmovaps [rsp+0xB0], xmm12
0000794c94dd70f4  vmovaps [rsp+0xC0], xmm13
0000794c94dd70fd  vmovaps [rsp+0xD0], xmm14
0000794c94dd7106  vmovaps [rsp+0xE0], xmm15
0000794c94dd710f  sub rsp, 0x30
0000794c94dd7113  movaps [rsp], xmm4
0000794c94dd7117  movaps [rsp+0x10], xmm9
0000794c94dd711d  movaps [rsp+0x20], xmm8
0000794c94dd7123  lea rdi, [rsp]
0000794c94dd7127  mov esi, 0x00
0000794c94dd712c  mov rax, 0x5AB2B8B81530
0000794c94dd7136  call rax
0000794c94dd7138  movaps xmm4, [rsp]
0000794c94dd713c  add rsp, 0x30
0000794c94dd7140  vmovaps xmm0, [rsp]
0000794c94dd7145  vmovaps xmm1, [rsp+0x10]
0000794c94dd714b  vmovaps xmm2, [rsp+0x20]
0000794c94dd7151  vmovaps xmm3, [rsp+0x30]
0000794c94dd7157  vmovaps xmm5, [rsp+0x40]
0000794c94dd715d  vmovaps xmm6, [rsp+0x50]
0000794c94dd7163  vmovaps xmm7, [rsp+0x60]
0000794c94dd7169  vmovaps xmm8, [rsp+0x70]
0000794c94dd716f  vmovaps xmm9, [rsp+0x80]
0000794c94dd7178  vmovaps xmm10, [rsp+0x90]
0000794c94dd7181  vmovaps xmm11, [rsp+0xA0]
0000794c94dd718a  vmovaps xmm12, [rsp+0xB0]
0000794c94dd7193  vmovaps xmm13, [rsp+0xC0]
0000794c94dd719c  vmovaps xmm14, [rsp+0xD0]
0000794c94dd71a5  vmovaps xmm15, [rsp+0xE0]
0000794c94dd71ae  add rsp, 0xF0
0000794c94dd71b5  pop r11
0000794c94dd71b7  pop r10
0000794c94dd71b9  pop r9
0000794c94dd71bb  pop r8
0000794c94dd71bd  pop rsi
0000794c94dd71be  pop rdi
0000794c94dd71bf  pop rdx
0000794c94dd71c0  pop rcx
0000794c94dd71c1  pop rax
0000794c94dd71c2  add rsp, 0x08
0000794c94dd71c6  jmp 0x0000794C94DD5AE1
0000794c94dd71cb  sub rsp, 0x08
0000794c94dd71cf  push rax
0000794c94dd71d0  push rcx
0000794c94dd71d1  push rdx
0000794c94dd71d2  push rdi
0000794c94dd71d3  push rsi
0000794c94dd71d4  push r8
0000794c94dd71d6  push r9
0000794c94dd71d8  push r10
0000794c94dd71da  push r11
0000794c94dd71dc  sub rsp, 0xF0
0000794c94dd71e3  vmovaps [rsp], xmm0
0000794c94dd71e8  vmovaps [rsp+0x10], xmm1
0000794c94dd71ee  vmovaps [rsp+0x20], xmm2
0000794c94dd71f4  vmovaps [rsp+0x30], xmm3
0000794c94dd71fa  vmovaps [rsp+0x40], xmm4
0000794c94dd7200  vmovaps [rsp+0x50], xmm5
0000794c94dd7206  vmovaps [rsp+0x60], xmm6
0000794c94dd720c  vmovaps [rsp+0x70], xmm7
0000794c94dd7212  vmovaps [rsp+0x80], xmm8
0000794c94dd721b  vmovaps [rsp+0x90], xmm10
0000794c94dd7224  vmovaps [rsp+0xA0], xmm11
0000794c94dd722d  vmovaps [rsp+0xB0], xmm12
0000794c94dd7236  vmovaps [rsp+0xC0], xmm13
0000794c94dd723f  vmovaps [rsp+0xD0], xmm14
0000794c94dd7248  vmovaps [rsp+0xE0], xmm15
0000794c94dd7251  sub rsp, 0x30
0000794c94dd7255  movaps [rsp], xmm9
0000794c94dd725a  movaps [rsp+0x10], xmm10
0000794c94dd7260  movaps [rsp+0x20], xmm8
0000794c94dd7266  lea rdi, [rsp]
0000794c94dd726a  mov esi, 0x00
0000794c94dd726f  mov rax, 0x5AB2B8B81530
0000794c94dd7279  call rax
0000794c94dd727b  movaps xmm9, [rsp]
0000794c94dd7280  add rsp, 0x30
0000794c94dd7284  vmovaps xmm0, [rsp]
0000794c94dd7289  vmovaps xmm1, [rsp+0x10]
0000794c94dd728f  vmovaps xmm2, [rsp+0x20]
0000794c94dd7295  vmovaps xmm3, [rsp+0x30]
0000794c94dd729b  vmovaps xmm4, [rsp+0x40]
0000794c94dd72a1  vmovaps xmm5, [rsp+0x50]
0000794c94dd72a7  vmovaps xmm6, [rsp+0x60]
0000794c94dd72ad  vmovaps xmm7, [rsp+0x70]
0000794c94dd72b3  vmovaps xmm8, [rsp+0x80]
0000794c94dd72bc  vmovaps xmm10, [rsp+0x90]
0000794c94dd72c5  vmovaps xmm11, [rsp+0xA0]
0000794c94dd72ce  vmovaps xmm12, [rsp+0xB0]
0000794c94dd72d7  vmovaps xmm13, [rsp+0xC0]
0000794c94dd72e0  vmovaps xmm14, [rsp+0xD0]
0000794c94dd72e9  vmovaps xmm15, [rsp+0xE0]
0000794c94dd72f2  add rsp, 0xF0
0000794c94dd72f9  pop r11
0000794c94dd72fb  pop r10
0000794c94dd72fd  pop r9
0000794c94dd72ff  pop r8
0000794c94dd7301  pop rsi
0000794c94dd7302  pop rdi
0000794c94dd7303  pop rdx
0000794c94dd7304  pop rcx
0000794c94dd7305  pop rax
0000794c94dd7306  add rsp, 0x08
0000794c94dd730a  jmp 0x0000794C94DD5AFB
0000794c94dd730f  call 0x0000794C94CD64F0
0000794c94dd7314  jmp 0x0000794C94DD5C15
0000794c94dd7319  call 0x0000794C94CD64F0
0000794c94dd731e  jmp 0x0000794C94DD5C2B
0000794c94dd7323  sub rsp, 0x08
0000794c94dd7327  push rax
0000794c94dd7328  push rcx
0000794c94dd7329  push rdx
0000794c94dd732a  push rdi
0000794c94dd732b  push rsi
0000794c94dd732c  push r8
0000794c94dd732e  push r9
0000794c94dd7330  push r10
0000794c94dd7332  push r11
0000794c94dd7334  sub rsp, 0xF0
0000794c94dd733b  vmovaps [rsp], xmm0
0000794c94dd7340  vmovaps [rsp+0x10], xmm2
0000794c94dd7346  vmovaps [rsp+0x20], xmm3
0000794c94dd734c  vmovaps [rsp+0x30], xmm4
0000794c94dd7352  vmovaps [rsp+0x40], xmm5
0000794c94dd7358  vmovaps [rsp+0x50], xmm6
0000794c94dd735e  vmovaps [rsp+0x60], xmm7
0000794c94dd7364  vmovaps [rsp+0x70], xmm8
0000794c94dd736a  vmovaps [rsp+0x80], xmm9
0000794c94dd7373  vmovaps [rsp+0x90], xmm10
0000794c94dd737c  vmovaps [rsp+0xA0], xmm11
0000794c94dd7385  vmovaps [rsp+0xB0], xmm12
0000794c94dd738e  vmovaps [rsp+0xC0], xmm13
0000794c94dd7397  vmovaps [rsp+0xD0], xmm14
0000794c94dd73a0  vmovaps [rsp+0xE0], xmm15
0000794c94dd73a9  sub rsp, 0x30
0000794c94dd73ad  movaps [rsp], xmm1
0000794c94dd73b1  movaps [rsp+0x10], xmm6
0000794c94dd73b6  movaps [rsp+0x20], xmm15
0000794c94dd73bc  lea rdi, [rsp]
0000794c94dd73c0  mov esi, 0x00
0000794c94dd73c5  mov rax, 0x5AB2B8B81530
0000794c94dd73cf  call rax
0000794c94dd73d1  movaps xmm1, [rsp]
0000794c94dd73d5  add rsp, 0x30
0000794c94dd73d9  vmovaps xmm0, [rsp]
0000794c94dd73de  vmovaps xmm2, [rsp+0x10]
0000794c94dd73e4  vmovaps xmm3, [rsp+0x20]
0000794c94dd73ea  vmovaps xmm4, [rsp+0x30]
0000794c94dd73f0  vmovaps xmm5, [rsp+0x40]
0000794c94dd73f6  vmovaps xmm6, [rsp+0x50]
0000794c94dd73fc  vmovaps xmm7, [rsp+0x60]
0000794c94dd7402  vmovaps xmm8, [rsp+0x70]
0000794c94dd7408  vmovaps xmm9, [rsp+0x80]
0000794c94dd7411  vmovaps xmm10, [rsp+0x90]
0000794c94dd741a  vmovaps xmm11, [rsp+0xA0]
0000794c94dd7423  vmovaps xmm12, [rsp+0xB0]
0000794c94dd742c  vmovaps xmm13, [rsp+0xC0]
0000794c94dd7435  vmovaps xmm14, [rsp+0xD0]
0000794c94dd743e  vmovaps xmm15, [rsp+0xE0]
0000794c94dd7447  add rsp, 0xF0
0000794c94dd744e  pop r11
0000794c94dd7450  pop r10
0000794c94dd7452  pop r9
0000794c94dd7454  pop r8
0000794c94dd7456  pop rsi
0000794c94dd7457  pop rdi
0000794c94dd7458  pop rdx
0000794c94dd7459  pop rcx
0000794c94dd745a  pop rax
0000794c94dd745b  add rsp, 0x08
0000794c94dd745f  jmp 0x0000794C94DD5C68
0000794c94dd7464  call 0x0000794C94CE5820
0000794c94dd7469  jmp 0x0000794C94DD5C75
0000794c94dd746e  sub rsp, 0x08
0000794c94dd7472  push rax
0000794c94dd7473  push rcx
0000794c94dd7474  push rdx
0000794c94dd7475  push rdi
0000794c94dd7476  push rsi
0000794c94dd7477  push r8
0000794c94dd7479  push r9
0000794c94dd747b  push r10
0000794c94dd747d  push r11
0000794c94dd747f  sub rsp, 0xF0
0000794c94dd7486  vmovaps [rsp], xmm0
0000794c94dd748b  vmovaps [rsp+0x10], xmm1
0000794c94dd7491  vmovaps [rsp+0x20], xmm2
0000794c94dd7497  vmovaps [rsp+0x30], xmm3
0000794c94dd749d  vmovaps [rsp+0x40], xmm4
0000794c94dd74a3  vmovaps [rsp+0x50], xmm5
0000794c94dd74a9  vmovaps [rsp+0x60], xmm6
0000794c94dd74af  vmovaps [rsp+0x70], xmm7
0000794c94dd74b5  vmovaps [rsp+0x80], xmm8
0000794c94dd74be  vmovaps [rsp+0x90], xmm9
0000794c94dd74c7  vmovaps [rsp+0xA0], xmm10
0000794c94dd74d0  vmovaps [rsp+0xB0], xmm11
0000794c94dd74d9  vmovaps [rsp+0xC0], xmm12
0000794c94dd74e2  vmovaps [rsp+0xD0], xmm13
0000794c94dd74eb  vmovaps [rsp+0xE0], xmm15
0000794c94dd74f4  sub rsp, 0x30
0000794c94dd74f8  movaps [rsp], xmm14
0000794c94dd74fd  movaps [rsp+0x10], xmm4
0000794c94dd7502  movaps [rsp+0x20], xmm3
0000794c94dd7507  lea rdi, [rsp]
0000794c94dd750b  mov esi, 0x00
0000794c94dd7510  mov rax, 0x5AB2B8B81530
0000794c94dd751a  call rax
0000794c94dd751c  movaps xmm14, [rsp]
0000794c94dd7521  add rsp, 0x30
0000794c94dd7525  vmovaps xmm0, [rsp]
0000794c94dd752a  vmovaps xmm1, [rsp+0x10]
0000794c94dd7530  vmovaps xmm2, [rsp+0x20]
0000794c94dd7536  vmovaps xmm3, [rsp+0x30]
0000794c94dd753c  vmovaps xmm4, [rsp+0x40]
0000794c94dd7542  vmovaps xmm5, [rsp+0x50]
0000794c94dd7548  vmovaps xmm6, [rsp+0x60]
0000794c94dd754e  vmovaps xmm7, [rsp+0x70]
0000794c94dd7554  vmovaps xmm8, [rsp+0x80]
0000794c94dd755d  vmovaps xmm9, [rsp+0x90]
0000794c94dd7566  vmovaps xmm10, [rsp+0xA0]
0000794c94dd756f  vmovaps xmm11, [rsp+0xB0]
0000794c94dd7578  vmovaps xmm12, [rsp+0xC0]
0000794c94dd7581  vmovaps xmm13, [rsp+0xD0]
0000794c94dd758a  vmovaps xmm15, [rsp+0xE0]
0000794c94dd7593  add rsp, 0xF0
0000794c94dd759a  pop r11
0000794c94dd759c  pop r10
0000794c94dd759e  pop r9
0000794c94dd75a0  pop r8
0000794c94dd75a2  pop rsi
0000794c94dd75a3  pop rdi
0000794c94dd75a4  pop rdx
0000794c94dd75a5  pop rcx
0000794c94dd75a6  pop rax
0000794c94dd75a7  add rsp, 0x08
0000794c94dd75ab  jmp 0x0000794C94DD5C8F
0000794c94dd75b0  sub rsp, 0x08
0000794c94dd75b4  push rax
0000794c94dd75b5  push rcx
0000794c94dd75b6  push rdx
0000794c94dd75b7  push rdi
0000794c94dd75b8  push rsi
0000794c94dd75b9  push r8
0000794c94dd75bb  push r9
0000794c94dd75bd  push r10
0000794c94dd75bf  push r11
0000794c94dd75c1  sub rsp, 0xF0
0000794c94dd75c8  vmovaps [rsp], xmm0
0000794c94dd75cd  vmovaps [rsp+0x10], xmm1
0000794c94dd75d3  vmovaps [rsp+0x20], xmm2
0000794c94dd75d9  vmovaps [rsp+0x30], xmm3
0000794c94dd75df  vmovaps [rsp+0x40], xmm4
0000794c94dd75e5  vmovaps [rsp+0x50], xmm5
0000794c94dd75eb  vmovaps [rsp+0x60], xmm7
0000794c94dd75f1  vmovaps [rsp+0x70], xmm8
0000794c94dd75f7  vmovaps [rsp+0x80], xmm9
0000794c94dd7600  vmovaps [rsp+0x90], xmm10
0000794c94dd7609  vmovaps [rsp+0xA0], xmm11
0000794c94dd7612  vmovaps [rsp+0xB0], xmm12
0000794c94dd761b  vmovaps [rsp+0xC0], xmm13
0000794c94dd7624  vmovaps [rsp+0xD0], xmm14
0000794c94dd762d  vmovaps [rsp+0xE0], xmm15
0000794c94dd7636  sub rsp, 0x30
0000794c94dd763a  movaps [rsp], xmm6
0000794c94dd763e  movaps [rsp+0x10], xmm9
0000794c94dd7644  movaps [rsp+0x20], xmm7
0000794c94dd7649  lea rdi, [rsp]
0000794c94dd764d  mov esi, 0x00
0000794c94dd7652  mov rax, 0x5AB2B8B81530
0000794c94dd765c  call rax
0000794c94dd765e  movaps xmm6, [rsp]
0000794c94dd7662  add rsp, 0x30
0000794c94dd7666  vmovaps xmm0, [rsp]
0000794c94dd766b  vmovaps xmm1, [rsp+0x10]
0000794c94dd7671  vmovaps xmm2, [rsp+0x20]
0000794c94dd7677  vmovaps xmm3, [rsp+0x30]
0000794c94dd767d  vmovaps xmm4, [rsp+0x40]
0000794c94dd7683  vmovaps xmm5, [rsp+0x50]
0000794c94dd7689  vmovaps xmm7, [rsp+0x60]
0000794c94dd768f  vmovaps xmm8, [rsp+0x70]
0000794c94dd7695  vmovaps xmm9, [rsp+0x80]
0000794c94dd769e  vmovaps xmm10, [rsp+0x90]
0000794c94dd76a7  vmovaps xmm11, [rsp+0xA0]
0000794c94dd76b0  vmovaps xmm12, [rsp+0xB0]
0000794c94dd76b9  vmovaps xmm13, [rsp+0xC0]
0000794c94dd76c2  vmovaps xmm14, [rsp+0xD0]
0000794c94dd76cb  vmovaps xmm15, [rsp+0xE0]
0000794c94dd76d4  add rsp, 0xF0
0000794c94dd76db  pop r11
0000794c94dd76dd  pop r10
0000794c94dd76df  pop r9
0000794c94dd76e1  pop r8
0000794c94dd76e3  pop rsi
0000794c94dd76e4  pop rdi
0000794c94dd76e5  pop rdx
0000794c94dd76e6  pop rcx
0000794c94dd76e7  pop rax
0000794c94dd76e8  add rsp, 0x08
0000794c94dd76ec  jmp 0x0000794C94DD5CA7
0000794c94dd76f1  sub rsp, 0x08
0000794c94dd76f5  push rax
0000794c94dd76f6  push rcx
0000794c94dd76f7  push rdx
0000794c94dd76f8  push rdi
0000794c94dd76f9  push rsi
0000794c94dd76fa  push r8
0000794c94dd76fc  push r9
0000794c94dd76fe  push r10
0000794c94dd7700  push r11
0000794c94dd7702  sub rsp, 0xF0
0000794c94dd7709  vmovaps [rsp], xmm0
0000794c94dd770e  vmovaps [rsp+0x10], xmm1
0000794c94dd7714  vmovaps [rsp+0x20], xmm2
0000794c94dd771a  vmovaps [rsp+0x30], xmm3
0000794c94dd7720  vmovaps [rsp+0x40], xmm4
0000794c94dd7726  vmovaps [rsp+0x50], xmm5
0000794c94dd772c  vmovaps [rsp+0x60], xmm6
0000794c94dd7732  vmovaps [rsp+0x70], xmm8
0000794c94dd7738  vmovaps [rsp+0x80], xmm9
0000794c94dd7741  vmovaps [rsp+0x90], xmm10
0000794c94dd774a  vmovaps [rsp+0xA0], xmm11
0000794c94dd7753  vmovaps [rsp+0xB0], xmm12
0000794c94dd775c  vmovaps [rsp+0xC0], xmm13
0000794c94dd7765  vmovaps [rsp+0xD0], xmm14
0000794c94dd776e  vmovaps [rsp+0xE0], xmm15
0000794c94dd7777  sub rsp, 0x30
0000794c94dd777b  movaps [rsp], xmm7
0000794c94dd777f  movaps [rsp+0x10], xmm4
0000794c94dd7784  movaps [rsp+0x20], xmm9
0000794c94dd778a  lea rdi, [rsp]
0000794c94dd778e  mov esi, 0x00
0000794c94dd7793  mov rax, 0x5AB2B8B81530
0000794c94dd779d  call rax
0000794c94dd779f  movaps xmm7, [rsp]
0000794c94dd77a3  add rsp, 0x30
0000794c94dd77a7  vmovaps xmm0, [rsp]
0000794c94dd77ac  vmovaps xmm1, [rsp+0x10]
0000794c94dd77b2  vmovaps xmm2, [rsp+0x20]
0000794c94dd77b8  vmovaps xmm3, [rsp+0x30]
0000794c94dd77be  vmovaps xmm4, [rsp+0x40]
0000794c94dd77c4  vmovaps xmm5, [rsp+0x50]
0000794c94dd77ca  vmovaps xmm6, [rsp+0x60]
0000794c94dd77d0  vmovaps xmm8, [rsp+0x70]
0000794c94dd77d6  vmovaps xmm9, [rsp+0x80]
0000794c94dd77df  vmovaps xmm10, [rsp+0x90]
0000794c94dd77e8  vmovaps xmm11, [rsp+0xA0]
0000794c94dd77f1  vmovaps xmm12, [rsp+0xB0]
0000794c94dd77fa  vmovaps xmm13, [rsp+0xC0]
0000794c94dd7803  vmovaps xmm14, [rsp+0xD0]
0000794c94dd780c  vmovaps xmm15, [rsp+0xE0]
0000794c94dd7815  add rsp, 0xF0
0000794c94dd781c  pop r11
0000794c94dd781e  pop r10
0000794c94dd7820  pop r9
0000794c94dd7822  pop r8
0000794c94dd7824  pop rsi
0000794c94dd7825  pop rdi
0000794c94dd7826  pop rdx
0000794c94dd7827  pop rcx
0000794c94dd7828  pop rax
0000794c94dd7829  add rsp, 0x08
0000794c94dd782d  jmp 0x0000794C94DD5CD4
0000794c94dd7832  sub rsp, 0x08
0000794c94dd7836  push rax
0000794c94dd7837  push rcx
0000794c94dd7838  push rdx
0000794c94dd7839  push rdi
0000794c94dd783a  push rsi
0000794c94dd783b  push r8
0000794c94dd783d  push r9
0000794c94dd783f  push r10
0000794c94dd7841  push r11
0000794c94dd7843  sub rsp, 0xF0
0000794c94dd784a  vmovaps [rsp], xmm0
0000794c94dd784f  vmovaps [rsp+0x10], xmm1
0000794c94dd7855  vmovaps [rsp+0x20], xmm2
0000794c94dd785b  vmovaps [rsp+0x30], xmm3
0000794c94dd7861  vmovaps [rsp+0x40], xmm5
0000794c94dd7867  vmovaps [rsp+0x50], xmm6
0000794c94dd786d  vmovaps [rsp+0x60], xmm7
0000794c94dd7873  vmovaps [rsp+0x70], xmm8
0000794c94dd7879  vmovaps [rsp+0x80], xmm9
0000794c94dd7882  vmovaps [rsp+0x90], xmm10
0000794c94dd788b  vmovaps [rsp+0xA0], xmm11
0000794c94dd7894  vmovaps [rsp+0xB0], xmm12
0000794c94dd789d  vmovaps [rsp+0xC0], xmm13
0000794c94dd78a6  vmovaps [rsp+0xD0], xmm14
0000794c94dd78af  vmovaps [rsp+0xE0], xmm15
0000794c94dd78b8  sub rsp, 0x30
0000794c94dd78bc  movaps [rsp], xmm4
0000794c94dd78c0  movaps [rsp+0x10], xmm15
0000794c94dd78c6  movaps [rsp+0x20], xmm9
0000794c94dd78cc  lea rdi, [rsp]
0000794c94dd78d0  mov esi, 0x00
0000794c94dd78d5  mov rax, 0x5AB2B8B81530
0000794c94dd78df  call rax
0000794c94dd78e1  movaps xmm4, [rsp]
0000794c94dd78e5  add rsp, 0x30
0000794c94dd78e9  vmovaps xmm0, [rsp]
0000794c94dd78ee  vmovaps xmm1, [rsp+0x10]
0000794c94dd78f4  vmovaps xmm2, [rsp+0x20]
0000794c94dd78fa  vmovaps xmm3, [rsp+0x30]
0000794c94dd7900  vmovaps xmm5, [rsp+0x40]
0000794c94dd7906  vmovaps xmm6, [rsp+0x50]
0000794c94dd790c  vmovaps xmm7, [rsp+0x60]
0000794c94dd7912  vmovaps xmm8, [rsp+0x70]
0000794c94dd7918  vmovaps xmm9, [rsp+0x80]
0000794c94dd7921  vmovaps xmm10, [rsp+0x90]
0000794c94dd792a  vmovaps xmm11, [rsp+0xA0]
0000794c94dd7933  vmovaps xmm12, [rsp+0xB0]
0000794c94dd793c  vmovaps xmm13, [rsp+0xC0]
0000794c94dd7945  vmovaps xmm14, [rsp+0xD0]
0000794c94dd794e  vmovaps xmm15, [rsp+0xE0]
0000794c94dd7957  add rsp, 0xF0
0000794c94dd795e  pop r11
0000794c94dd7960  pop r10
0000794c94dd7962  pop r9
0000794c94dd7964  pop r8
0000794c94dd7966  pop rsi
0000794c94dd7967  pop rdi
0000794c94dd7968  pop rdx
0000794c94dd7969  pop rcx
0000794c94dd796a  pop rax
0000794c94dd796b  add rsp, 0x08
0000794c94dd796f  jmp 0x0000794C94DD5CF9
0000794c94dd7974  call 0x0000794C94CE5820
0000794c94dd7979  jmp 0x0000794C94DD5D06
0000794c94dd797e  sub rsp, 0x08
0000794c94dd7982  push rax
0000794c94dd7983  push rcx
0000794c94dd7984  push rdx
0000794c94dd7985  push rdi
0000794c94dd7986  push rsi
0000794c94dd7987  push r8
0000794c94dd7989  push r9
0000794c94dd798b  push r10
0000794c94dd798d  push r11
0000794c94dd798f  sub rsp, 0xF0
0000794c94dd7996  vmovaps [rsp], xmm0
0000794c94dd799b  vmovaps [rsp+0x10], xmm1
0000794c94dd79a1  vmovaps [rsp+0x20], xmm2
0000794c94dd79a7  vmovaps [rsp+0x30], xmm4
0000794c94dd79ad  vmovaps [rsp+0x40], xmm5
0000794c94dd79b3  vmovaps [rsp+0x50], xmm6
0000794c94dd79b9  vmovaps [rsp+0x60], xmm7
0000794c94dd79bf  vmovaps [rsp+0x70], xmm8
0000794c94dd79c5  vmovaps [rsp+0x80], xmm9
0000794c94dd79ce  vmovaps [rsp+0x90], xmm10
0000794c94dd79d7  vmovaps [rsp+0xA0], xmm11
0000794c94dd79e0  vmovaps [rsp+0xB0], xmm12
0000794c94dd79e9  vmovaps [rsp+0xC0], xmm13
0000794c94dd79f2  vmovaps [rsp+0xD0], xmm14
0000794c94dd79fb  vmovaps [rsp+0xE0], xmm15
0000794c94dd7a04  sub rsp, 0x30
0000794c94dd7a08  movaps [rsp], xmm3
0000794c94dd7a0c  movaps [rsp+0x10], xmm1
0000794c94dd7a11  movaps [rsp+0x20], xmm9
0000794c94dd7a17  lea rdi, [rsp]
0000794c94dd7a1b  mov esi, 0x00
0000794c94dd7a20  mov rax, 0x5AB2B8B81530
0000794c94dd7a2a  call rax
0000794c94dd7a2c  movaps xmm3, [rsp]
0000794c94dd7a30  add rsp, 0x30
0000794c94dd7a34  vmovaps xmm0, [rsp]
0000794c94dd7a39  vmovaps xmm1, [rsp+0x10]
0000794c94dd7a3f  vmovaps xmm2, [rsp+0x20]
0000794c94dd7a45  vmovaps xmm4, [rsp+0x30]
0000794c94dd7a4b  vmovaps xmm5, [rsp+0x40]
0000794c94dd7a51  vmovaps xmm6, [rsp+0x50]
0000794c94dd7a57  vmovaps xmm7, [rsp+0x60]
0000794c94dd7a5d  vmovaps xmm8, [rsp+0x70]
0000794c94dd7a63  vmovaps xmm9, [rsp+0x80]
0000794c94dd7a6c  vmovaps xmm10, [rsp+0x90]
0000794c94dd7a75  vmovaps xmm11, [rsp+0xA0]
0000794c94dd7a7e  vmovaps xmm12, [rsp+0xB0]
0000794c94dd7a87  vmovaps xmm13, [rsp+0xC0]
0000794c94dd7a90  vmovaps xmm14, [rsp+0xD0]
0000794c94dd7a99  vmovaps xmm15, [rsp+0xE0]
0000794c94dd7aa2  add rsp, 0xF0
0000794c94dd7aa9  pop r11
0000794c94dd7aab  pop r10
0000794c94dd7aad  pop r9
0000794c94dd7aaf  pop r8
0000794c94dd7ab1  pop rsi
0000794c94dd7ab2  pop rdi
0000794c94dd7ab3  pop rdx
0000794c94dd7ab4  pop rcx
0000794c94dd7ab5  pop rax
0000794c94dd7ab6  add rsp, 0x08
0000794c94dd7aba  jmp 0x0000794C94DD5D43
0000794c94dd7abf  sub rsp, 0x08
0000794c94dd7ac3  push rax
0000794c94dd7ac4  push rcx
0000794c94dd7ac5  push rdx
0000794c94dd7ac6  push rdi
0000794c94dd7ac7  push rsi
0000794c94dd7ac8  push r8
0000794c94dd7aca  push r9
0000794c94dd7acc  push r10
0000794c94dd7ace  push r11
0000794c94dd7ad0  sub rsp, 0xF0
0000794c94dd7ad7  vmovaps [rsp], xmm0
0000794c94dd7adc  vmovaps [rsp+0x10], xmm2
0000794c94dd7ae2  vmovaps [rsp+0x20], xmm3
0000794c94dd7ae8  vmovaps [rsp+0x30], xmm4
0000794c94dd7aee  vmovaps [rsp+0x40], xmm5
0000794c94dd7af4  vmovaps [rsp+0x50], xmm6
0000794c94dd7afa  vmovaps [rsp+0x60], xmm7
0000794c94dd7b00  vmovaps [rsp+0x70], xmm8
0000794c94dd7b06  vmovaps [rsp+0x80], xmm9
0000794c94dd7b0f  vmovaps [rsp+0x90], xmm10
0000794c94dd7b18  vmovaps [rsp+0xA0], xmm11
0000794c94dd7b21  vmovaps [rsp+0xB0], xmm12
0000794c94dd7b2a  vmovaps [rsp+0xC0], xmm13
0000794c94dd7b33  vmovaps [rsp+0xD0], xmm14
0000794c94dd7b3c  vmovaps [rsp+0xE0], xmm15
0000794c94dd7b45  sub rsp, 0x30
0000794c94dd7b49  movaps [rsp], xmm1
0000794c94dd7b4d  movaps [rsp+0x10], xmm15
0000794c94dd7b53  movaps [rsp+0x20], xmm9
0000794c94dd7b59  lea rdi, [rsp]
0000794c94dd7b5d  mov esi, 0x00
0000794c94dd7b62  mov rax, 0x5AB2B8B81530
0000794c94dd7b6c  call rax
0000794c94dd7b6e  movaps xmm1, [rsp]
0000794c94dd7b72  add rsp, 0x30
0000794c94dd7b76  vmovaps xmm0, [rsp]
0000794c94dd7b7b  vmovaps xmm2, [rsp+0x10]
0000794c94dd7b81  vmovaps xmm3, [rsp+0x20]
0000794c94dd7b87  vmovaps xmm4, [rsp+0x30]
0000794c94dd7b8d  vmovaps xmm5, [rsp+0x40]
0000794c94dd7b93  vmovaps xmm6, [rsp+0x50]
0000794c94dd7b99  vmovaps xmm7, [rsp+0x60]
0000794c94dd7b9f  vmovaps xmm8, [rsp+0x70]
0000794c94dd7ba5  vmovaps xmm9, [rsp+0x80]
0000794c94dd7bae  vmovaps xmm10, [rsp+0x90]
0000794c94dd7bb7  vmovaps xmm11, [rsp+0xA0]
0000794c94dd7bc0  vmovaps xmm12, [rsp+0xB0]
0000794c94dd7bc9  vmovaps xmm13, [rsp+0xC0]
0000794c94dd7bd2  vmovaps xmm14, [rsp+0xD0]
0000794c94dd7bdb  vmovaps xmm15, [rsp+0xE0]
0000794c94dd7be4  add rsp, 0xF0
0000794c94dd7beb  pop r11
0000794c94dd7bed  pop r10
0000794c94dd7bef  pop r9
0000794c94dd7bf1  pop r8
0000794c94dd7bf3  pop rsi
0000794c94dd7bf4  pop rdi
0000794c94dd7bf5  pop rdx
0000794c94dd7bf6  pop rcx
0000794c94dd7bf7  pop rax
0000794c94dd7bf8  add rsp, 0x08
0000794c94dd7bfc  jmp 0x0000794C94DD5DCB
0000794c94dd7c01  call 0x0000794C94CE5820
0000794c94dd7c06  jmp 0x0000794C94DD5DD8
0000794c94dd7c0b  sub rsp, 0x08
0000794c94dd7c0f  push rax
0000794c94dd7c10  push rcx
0000794c94dd7c11  push rdx
0000794c94dd7c12  push rdi
0000794c94dd7c13  push rsi
0000794c94dd7c14  push r8
0000794c94dd7c16  push r9
0000794c94dd7c18  push r10
0000794c94dd7c1a  push r11
0000794c94dd7c1c  sub rsp, 0xF0
0000794c94dd7c23  vmovaps [rsp], xmm0
0000794c94dd7c28  vmovaps [rsp+0x10], xmm2
0000794c94dd7c2e  vmovaps [rsp+0x20], xmm3
0000794c94dd7c34  vmovaps [rsp+0x30], xmm4
0000794c94dd7c3a  vmovaps [rsp+0x40], xmm5
0000794c94dd7c40  vmovaps [rsp+0x50], xmm6
0000794c94dd7c46  vmovaps [rsp+0x60], xmm7
0000794c94dd7c4c  vmovaps [rsp+0x70], xmm8
0000794c94dd7c52  vmovaps [rsp+0x80], xmm9
0000794c94dd7c5b  vmovaps [rsp+0x90], xmm10
0000794c94dd7c64  vmovaps [rsp+0xA0], xmm11
0000794c94dd7c6d  vmovaps [rsp+0xB0], xmm12
0000794c94dd7c76  vmovaps [rsp+0xC0], xmm13
0000794c94dd7c7f  vmovaps [rsp+0xD0], xmm14
0000794c94dd7c88  vmovaps [rsp+0xE0], xmm15
0000794c94dd7c91  sub rsp, 0x30
0000794c94dd7c95  movaps [rsp], xmm1
0000794c94dd7c99  movaps [rsp+0x10], xmm5
0000794c94dd7c9e  movaps [rsp+0x20], xmm7
0000794c94dd7ca3  lea rdi, [rsp]
0000794c94dd7ca7  mov esi, 0x00
0000794c94dd7cac  mov rax, 0x5AB2B8B81530
0000794c94dd7cb6  call rax
0000794c94dd7cb8  movaps xmm1, [rsp]
0000794c94dd7cbc  add rsp, 0x30
0000794c94dd7cc0  vmovaps xmm0, [rsp]
0000794c94dd7cc5  vmovaps xmm2, [rsp+0x10]
0000794c94dd7ccb  vmovaps xmm3, [rsp+0x20]
0000794c94dd7cd1  vmovaps xmm4, [rsp+0x30]
0000794c94dd7cd7  vmovaps xmm5, [rsp+0x40]
0000794c94dd7cdd  vmovaps xmm6, [rsp+0x50]
0000794c94dd7ce3  vmovaps xmm7, [rsp+0x60]
0000794c94dd7ce9  vmovaps xmm8, [rsp+0x70]
0000794c94dd7cef  vmovaps xmm9, [rsp+0x80]
0000794c94dd7cf8  vmovaps xmm10, [rsp+0x90]
0000794c94dd7d01  vmovaps xmm11, [rsp+0xA0]
0000794c94dd7d0a  vmovaps xmm12, [rsp+0xB0]
0000794c94dd7d13  vmovaps xmm13, [rsp+0xC0]
0000794c94dd7d1c  vmovaps xmm14, [rsp+0xD0]
0000794c94dd7d25  vmovaps xmm15, [rsp+0xE0]
0000794c94dd7d2e  add rsp, 0xF0
0000794c94dd7d35  pop r11
0000794c94dd7d37  pop r10
0000794c94dd7d39  pop r9
0000794c94dd7d3b  pop r8
0000794c94dd7d3d  pop rsi
0000794c94dd7d3e  pop rdi
0000794c94dd7d3f  pop rdx
0000794c94dd7d40  pop rcx
0000794c94dd7d41  pop rax
0000794c94dd7d42  add rsp, 0x08
0000794c94dd7d46  jmp 0x0000794C94DD5E7D
0000794c94dd7d4b  sub rsp, 0x08
0000794c94dd7d4f  push rax
0000794c94dd7d50  push rcx
0000794c94dd7d51  push rdx
0000794c94dd7d52  push rdi
0000794c94dd7d53  push rsi
0000794c94dd7d54  push r8
0000794c94dd7d56  push r9
0000794c94dd7d58  push r10
0000794c94dd7d5a  push r11
0000794c94dd7d5c  sub rsp, 0xF0
0000794c94dd7d63  vmovaps [rsp], xmm0
0000794c94dd7d68  vmovaps [rsp+0x10], xmm1
0000794c94dd7d6e  vmovaps [rsp+0x20], xmm2
0000794c94dd7d74  vmovaps [rsp+0x30], xmm3
0000794c94dd7d7a  vmovaps [rsp+0x40], xmm4
0000794c94dd7d80  vmovaps [rsp+0x50], xmm5
0000794c94dd7d86  vmovaps [rsp+0x60], xmm6
0000794c94dd7d8c  vmovaps [rsp+0x70], xmm8
0000794c94dd7d92  vmovaps [rsp+0x80], xmm9
0000794c94dd7d9b  vmovaps [rsp+0x90], xmm10
0000794c94dd7da4  vmovaps [rsp+0xA0], xmm11
0000794c94dd7dad  vmovaps [rsp+0xB0], xmm12
0000794c94dd7db6  vmovaps [rsp+0xC0], xmm13
0000794c94dd7dbf  vmovaps [rsp+0xD0], xmm14
0000794c94dd7dc8  vmovaps [rsp+0xE0], xmm15
0000794c94dd7dd1  sub rsp, 0x30
0000794c94dd7dd5  movaps [rsp], xmm7
0000794c94dd7dd9  movaps [rsp+0x10], xmm5
0000794c94dd7dde  movaps [rsp+0x20], xmm15
0000794c94dd7de4  lea rdi, [rsp]
0000794c94dd7de8  mov esi, 0x00
0000794c94dd7ded  mov rax, 0x5AB2B8B81530
0000794c94dd7df7  call rax
0000794c94dd7df9  movaps xmm7, [rsp]
0000794c94dd7dfd  add rsp, 0x30
0000794c94dd7e01  vmovaps xmm0, [rsp]
0000794c94dd7e06  vmovaps xmm1, [rsp+0x10]
0000794c94dd7e0c  vmovaps xmm2, [rsp+0x20]
0000794c94dd7e12  vmovaps xmm3, [rsp+0x30]
0000794c94dd7e18  vmovaps xmm4, [rsp+0x40]
0000794c94dd7e1e  vmovaps xmm5, [rsp+0x50]
0000794c94dd7e24  vmovaps xmm6, [rsp+0x60]
0000794c94dd7e2a  vmovaps xmm8, [rsp+0x70]
0000794c94dd7e30  vmovaps xmm9, [rsp+0x80]
0000794c94dd7e39  vmovaps xmm10, [rsp+0x90]
0000794c94dd7e42  vmovaps xmm11, [rsp+0xA0]
0000794c94dd7e4b  vmovaps xmm12, [rsp+0xB0]
0000794c94dd7e54  vmovaps xmm13, [rsp+0xC0]
0000794c94dd7e5d  vmovaps xmm14, [rsp+0xD0]
0000794c94dd7e66  vmovaps xmm15, [rsp+0xE0]
0000794c94dd7e6f  add rsp, 0xF0
0000794c94dd7e76  pop r11
0000794c94dd7e78  pop r10
0000794c94dd7e7a  pop r9
0000794c94dd7e7c  pop r8
0000794c94dd7e7e  pop rsi
0000794c94dd7e7f  pop rdi
0000794c94dd7e80  pop rdx
0000794c94dd7e81  pop rcx
0000794c94dd7e82  pop rax
0000794c94dd7e83  add rsp, 0x08
0000794c94dd7e87  jmp 0x0000794C94DD5EB3
0000794c94dd7e8c  call 0x0000794C94CD64F0
0000794c94dd7e91  jmp 0x0000794C94DD5EC0
0000794c94dd7e96  sub rsp, 0x08
0000794c94dd7e9a  push rax
0000794c94dd7e9b  push rcx
0000794c94dd7e9c  push rdx
0000794c94dd7e9d  push rdi
0000794c94dd7e9e  push rsi
0000794c94dd7e9f  push r8
0000794c94dd7ea1  push r9
0000794c94dd7ea3  push r10
0000794c94dd7ea5  push r11
0000794c94dd7ea7  sub rsp, 0xF0
0000794c94dd7eae  vmovaps [rsp], xmm0
0000794c94dd7eb3  vmovaps [rsp+0x10], xmm1
0000794c94dd7eb9  vmovaps [rsp+0x20], xmm2
0000794c94dd7ebf  vmovaps [rsp+0x30], xmm3
0000794c94dd7ec5  vmovaps [rsp+0x40], xmm4
0000794c94dd7ecb  vmovaps [rsp+0x50], xmm5
0000794c94dd7ed1  vmovaps [rsp+0x60], xmm6
0000794c94dd7ed7  vmovaps [rsp+0x70], xmm7
0000794c94dd7edd  vmovaps [rsp+0x80], xmm8
0000794c94dd7ee6  vmovaps [rsp+0x90], xmm9
0000794c94dd7eef  vmovaps [rsp+0xA0], xmm10
0000794c94dd7ef8  vmovaps [rsp+0xB0], xmm11
0000794c94dd7f01  vmovaps [rsp+0xC0], xmm12
0000794c94dd7f0a  vmovaps [rsp+0xD0], xmm13
0000794c94dd7f13  vmovaps [rsp+0xE0], xmm14
0000794c94dd7f1c  sub rsp, 0x30
0000794c94dd7f20  movaps [rsp], xmm15
0000794c94dd7f25  movaps [rsp+0x10], xmm5
0000794c94dd7f2a  movaps [rsp+0x20], xmm3
0000794c94dd7f2f  lea rdi, [rsp]
0000794c94dd7f33  mov esi, 0x00
0000794c94dd7f38  mov rax, 0x5AB2B8B81530
0000794c94dd7f42  call rax
0000794c94dd7f44  movaps xmm15, [rsp]
0000794c94dd7f49  add rsp, 0x30
0000794c94dd7f4d  vmovaps xmm0, [rsp]
0000794c94dd7f52  vmovaps xmm1, [rsp+0x10]
0000794c94dd7f58  vmovaps xmm2, [rsp+0x20]
0000794c94dd7f5e  vmovaps xmm3, [rsp+0x30]
0000794c94dd7f64  vmovaps xmm4, [rsp+0x40]
0000794c94dd7f6a  vmovaps xmm5, [rsp+0x50]
0000794c94dd7f70  vmovaps xmm6, [rsp+0x60]
0000794c94dd7f76  vmovaps xmm7, [rsp+0x70]
0000794c94dd7f7c  vmovaps xmm8, [rsp+0x80]
0000794c94dd7f85  vmovaps xmm9, [rsp+0x90]
0000794c94dd7f8e  vmovaps xmm10, [rsp+0xA0]
0000794c94dd7f97  vmovaps xmm11, [rsp+0xB0]
0000794c94dd7fa0  vmovaps xmm12, [rsp+0xC0]
0000794c94dd7fa9  vmovaps xmm13, [rsp+0xD0]
0000794c94dd7fb2  vmovaps xmm14, [rsp+0xE0]
0000794c94dd7fbb  add rsp, 0xF0
0000794c94dd7fc2  pop r11
0000794c94dd7fc4  pop r10
0000794c94dd7fc6  pop r9
0000794c94dd7fc8  pop r8
0000794c94dd7fca  pop rsi
0000794c94dd7fcb  pop rdi
0000794c94dd7fcc  pop rdx
0000794c94dd7fcd  pop rcx
0000794c94dd7fce  pop rax
0000794c94dd7fcf  add rsp, 0x08
0000794c94dd7fd3  jmp 0x0000794C94DD5EE6
0000794c94dd7fd8  sub rsp, 0x08
0000794c94dd7fdc  push rax
0000794c94dd7fdd  push rcx
0000794c94dd7fde  push rdx
0000794c94dd7fdf  push rdi
0000794c94dd7fe0  push rsi
0000794c94dd7fe1  push r8
0000794c94dd7fe3  push r9
0000794c94dd7fe5  push r10
0000794c94dd7fe7  push r11
0000794c94dd7fe9  sub rsp, 0xF0
0000794c94dd7ff0  vmovaps [rsp], xmm0
0000794c94dd7ff5  vmovaps [rsp+0x10], xmm2
0000794c94dd7ffb  vmovaps [rsp+0x20], xmm3
0000794c94dd8001  vmovaps [rsp+0x30], xmm4
0000794c94dd8007  vmovaps [rsp+0x40], xmm5
0000794c94dd800d  vmovaps [rsp+0x50], xmm6
0000794c94dd8013  vmovaps [rsp+0x60], xmm7
0000794c94dd8019  vmovaps [rsp+0x70], xmm8
0000794c94dd801f  vmovaps [rsp+0x80], xmm9
0000794c94dd8028  vmovaps [rsp+0x90], xmm10
0000794c94dd8031  vmovaps [rsp+0xA0], xmm11
0000794c94dd803a  vmovaps [rsp+0xB0], xmm12
0000794c94dd8043  vmovaps [rsp+0xC0], xmm13
0000794c94dd804c  vmovaps [rsp+0xD0], xmm14
0000794c94dd8055  vmovaps [rsp+0xE0], xmm15
0000794c94dd805e  sub rsp, 0x30
0000794c94dd8062  movaps [rsp], xmm1
0000794c94dd8066  movaps [rsp+0x10], xmm5
0000794c94dd806b  movaps [rsp+0x20], xmm4
0000794c94dd8070  lea rdi, [rsp]
0000794c94dd8074  mov esi, 0x00
0000794c94dd8079  mov rax, 0x5AB2B8B81530
0000794c94dd8083  call rax
0000794c94dd8085  movaps xmm1, [rsp]
0000794c94dd8089  add rsp, 0x30
0000794c94dd808d  vmovaps xmm0, [rsp]
0000794c94dd8092  vmovaps xmm2, [rsp+0x10]
0000794c94dd8098  vmovaps xmm3, [rsp+0x20]
0000794c94dd809e  vmovaps xmm4, [rsp+0x30]
0000794c94dd80a4  vmovaps xmm5, [rsp+0x40]
0000794c94dd80aa  vmovaps xmm6, [rsp+0x50]
0000794c94dd80b0  vmovaps xmm7, [rsp+0x60]
0000794c94dd80b6  vmovaps xmm8, [rsp+0x70]
0000794c94dd80bc  vmovaps xmm9, [rsp+0x80]
0000794c94dd80c5  vmovaps xmm10, [rsp+0x90]
0000794c94dd80ce  vmovaps xmm11, [rsp+0xA0]
0000794c94dd80d7  vmovaps xmm12, [rsp+0xB0]
0000794c94dd80e0  vmovaps xmm13, [rsp+0xC0]
0000794c94dd80e9  vmovaps xmm14, [rsp+0xD0]
0000794c94dd80f2  vmovaps xmm15, [rsp+0xE0]
0000794c94dd80fb  add rsp, 0xF0
0000794c94dd8102  pop r11
0000794c94dd8104  pop r10
0000794c94dd8106  pop r9
0000794c94dd8108  pop r8
0000794c94dd810a  pop rsi
0000794c94dd810b  pop rdi
0000794c94dd810c  pop rdx
0000794c94dd810d  pop rcx
0000794c94dd810e  pop rax
0000794c94dd810f  add rsp, 0x08
0000794c94dd8113  jmp 0x0000794C94DD5F06
0000794c94dd8118  sub rsp, 0x08
0000794c94dd811c  push rax
0000794c94dd811d  push rcx
0000794c94dd811e  push rdx
0000794c94dd811f  push rdi
0000794c94dd8120  push rsi
0000794c94dd8121  push r8
0000794c94dd8123  push r9
0000794c94dd8125  push r10
0000794c94dd8127  push r11
0000794c94dd8129  sub rsp, 0xF0
0000794c94dd8130  vmovaps [rsp], xmm0
0000794c94dd8135  vmovaps [rsp+0x10], xmm1
0000794c94dd813b  vmovaps [rsp+0x20], xmm2
0000794c94dd8141  vmovaps [rsp+0x30], xmm3
0000794c94dd8147  vmovaps [rsp+0x40], xmm5
0000794c94dd814d  vmovaps [rsp+0x50], xmm6
0000794c94dd8153  vmovaps [rsp+0x60], xmm7
0000794c94dd8159  vmovaps [rsp+0x70], xmm8
0000794c94dd815f  vmovaps [rsp+0x80], xmm9
0000794c94dd8168  vmovaps [rsp+0x90], xmm10
0000794c94dd8171  vmovaps [rsp+0xA0], xmm11
0000794c94dd817a  vmovaps [rsp+0xB0], xmm12
0000794c94dd8183  vmovaps [rsp+0xC0], xmm13
0000794c94dd818c  vmovaps [rsp+0xD0], xmm14
0000794c94dd8195  vmovaps [rsp+0xE0], xmm15
0000794c94dd819e  sub rsp, 0x30
0000794c94dd81a2  movaps [rsp], xmm4
0000794c94dd81a6  movaps [rsp+0x10], xmm3
0000794c94dd81ab  movaps [rsp+0x20], xmm5
0000794c94dd81b0  lea rdi, [rsp]
0000794c94dd81b4  mov esi, 0x00
0000794c94dd81b9  mov rax, 0x5AB2B8B81530
0000794c94dd81c3  call rax
0000794c94dd81c5  movaps xmm4, [rsp]
0000794c94dd81c9  add rsp, 0x30
0000794c94dd81cd  vmovaps xmm0, [rsp]
0000794c94dd81d2  vmovaps xmm1, [rsp+0x10]
0000794c94dd81d8  vmovaps xmm2, [rsp+0x20]
0000794c94dd81de  vmovaps xmm3, [rsp+0x30]
0000794c94dd81e4  vmovaps xmm5, [rsp+0x40]
0000794c94dd81ea  vmovaps xmm6, [rsp+0x50]
0000794c94dd81f0  vmovaps xmm7, [rsp+0x60]
0000794c94dd81f6  vmovaps xmm8, [rsp+0x70]
0000794c94dd81fc  vmovaps xmm9, [rsp+0x80]
0000794c94dd8205  vmovaps xmm10, [rsp+0x90]
0000794c94dd820e  vmovaps xmm11, [rsp+0xA0]
0000794c94dd8217  vmovaps xmm12, [rsp+0xB0]
0000794c94dd8220  vmovaps xmm13, [rsp+0xC0]
0000794c94dd8229  vmovaps xmm14, [rsp+0xD0]
0000794c94dd8232  vmovaps xmm15, [rsp+0xE0]
0000794c94dd823b  add rsp, 0xF0
0000794c94dd8242  pop r11
0000794c94dd8244  pop r10
0000794c94dd8246  pop r9
0000794c94dd8248  pop r8
0000794c94dd824a  pop rsi
0000794c94dd824b  pop rdi
0000794c94dd824c  pop rdx
0000794c94dd824d  pop rcx
0000794c94dd824e  pop rax
0000794c94dd824f  add rsp, 0x08
0000794c94dd8253  jmp 0x0000794C94DD5F54
0000794c94dd8258  call 0x0000794C94CD64F0
0000794c94dd825d  jmp 0x0000794C94DD5F61
0000794c94dd8262  sub rsp, 0x08
0000794c94dd8266  push rax
0000794c94dd8267  push rcx
0000794c94dd8268  push rdx
0000794c94dd8269  push rdi
0000794c94dd826a  push rsi
0000794c94dd826b  push r8
0000794c94dd826d  push r9
0000794c94dd826f  push r10
0000794c94dd8271  push r11
0000794c94dd8273  sub rsp, 0xF0
0000794c94dd827a  vmovaps [rsp], xmm0
0000794c94dd827f  vmovaps [rsp+0x10], xmm1
0000794c94dd8285  vmovaps [rsp+0x20], xmm2
0000794c94dd828b  vmovaps [rsp+0x30], xmm3
0000794c94dd8291  vmovaps [rsp+0x40], xmm4
0000794c94dd8297  vmovaps [rsp+0x50], xmm6
0000794c94dd829d  vmovaps [rsp+0x60], xmm7
0000794c94dd82a3  vmovaps [rsp+0x70], xmm8
0000794c94dd82a9  vmovaps [rsp+0x80], xmm9
0000794c94dd82b2  vmovaps [rsp+0x90], xmm10
0000794c94dd82bb  vmovaps [rsp+0xA0], xmm11
0000794c94dd82c4  vmovaps [rsp+0xB0], xmm12
0000794c94dd82cd  vmovaps [rsp+0xC0], xmm13
0000794c94dd82d6  vmovaps [rsp+0xD0], xmm14
0000794c94dd82df  vmovaps [rsp+0xE0], xmm15
0000794c94dd82e8  sub rsp, 0x30
0000794c94dd82ec  movaps [rsp], xmm5
0000794c94dd82f0  movaps [rsp+0x10], xmm6
0000794c94dd82f5  movaps [rsp+0x20], xmm3
0000794c94dd82fa  lea rdi, [rsp]
0000794c94dd82fe  mov esi, 0x00
0000794c94dd8303  mov rax, 0x5AB2B8B81530
0000794c94dd830d  call rax
0000794c94dd830f  movaps xmm5, [rsp]
0000794c94dd8313  add rsp, 0x30
0000794c94dd8317  vmovaps xmm0, [rsp]
0000794c94dd831c  vmovaps xmm1, [rsp+0x10]
0000794c94dd8322  vmovaps xmm2, [rsp+0x20]
0000794c94dd8328  vmovaps xmm3, [rsp+0x30]
0000794c94dd832e  vmovaps xmm4, [rsp+0x40]
0000794c94dd8334  vmovaps xmm6, [rsp+0x50]
0000794c94dd833a  vmovaps xmm7, [rsp+0x60]
0000794c94dd8340  vmovaps xmm8, [rsp+0x70]
0000794c94dd8346  vmovaps xmm9, [rsp+0x80]
0000794c94dd834f  vmovaps xmm10, [rsp+0x90]
0000794c94dd8358  vmovaps xmm11, [rsp+0xA0]
0000794c94dd8361  vmovaps xmm12, [rsp+0xB0]
0000794c94dd836a  vmovaps xmm13, [rsp+0xC0]
0000794c94dd8373  vmovaps xmm14, [rsp+0xD0]
0000794c94dd837c  vmovaps xmm15, [rsp+0xE0]
0000794c94dd8385  add rsp, 0xF0
0000794c94dd838c  pop r11
0000794c94dd838e  pop r10
0000794c94dd8390  pop r9
0000794c94dd8392  pop r8
0000794c94dd8394  pop rsi
0000794c94dd8395  pop rdi
0000794c94dd8396  pop rdx
0000794c94dd8397  pop rcx
0000794c94dd8398  pop rax
0000794c94dd8399  add rsp, 0x08
0000794c94dd839d  jmp 0x0000794C94DD5F87
0000794c94dd83a2  sub rsp, 0x08
0000794c94dd83a6  push rax
0000794c94dd83a7  push rcx
0000794c94dd83a8  push rdx
0000794c94dd83a9  push rdi
0000794c94dd83aa  push rsi
0000794c94dd83ab  push r8
0000794c94dd83ad  push r9
0000794c94dd83af  push r10
0000794c94dd83b1  push r11
0000794c94dd83b3  sub rsp, 0xF0
0000794c94dd83ba  vmovaps [rsp], xmm0
0000794c94dd83bf  vmovaps [rsp+0x10], xmm1
0000794c94dd83c5  vmovaps [rsp+0x20], xmm2
0000794c94dd83cb  vmovaps [rsp+0x30], xmm3
0000794c94dd83d1  vmovaps [rsp+0x40], xmm4
0000794c94dd83d7  vmovaps [rsp+0x50], xmm5
0000794c94dd83dd  vmovaps [rsp+0x60], xmm7
0000794c94dd83e3  vmovaps [rsp+0x70], xmm8
0000794c94dd83e9  vmovaps [rsp+0x80], xmm9
0000794c94dd83f2  vmovaps [rsp+0x90], xmm10
0000794c94dd83fb  vmovaps [rsp+0xA0], xmm11
0000794c94dd8404  vmovaps [rsp+0xB0], xmm12
0000794c94dd840d  vmovaps [rsp+0xC0], xmm13
0000794c94dd8416  vmovaps [rsp+0xD0], xmm14
0000794c94dd841f  vmovaps [rsp+0xE0], xmm15
0000794c94dd8428  sub rsp, 0x30
0000794c94dd842c  movaps [rsp], xmm6
0000794c94dd8430  movaps [rsp+0x10], xmm9
0000794c94dd8436  movaps [rsp+0x20], xmm1
0000794c94dd843b  lea rdi, [rsp]
0000794c94dd843f  mov esi, 0x00
0000794c94dd8444  mov rax, 0x5AB2B8B81530
0000794c94dd844e  call rax
0000794c94dd8450  movaps xmm6, [rsp]
0000794c94dd8454  add rsp, 0x30
0000794c94dd8458  vmovaps xmm0, [rsp]
0000794c94dd845d  vmovaps xmm1, [rsp+0x10]
0000794c94dd8463  vmovaps xmm2, [rsp+0x20]
0000794c94dd8469  vmovaps xmm3, [rsp+0x30]
0000794c94dd846f  vmovaps xmm4, [rsp+0x40]
0000794c94dd8475  vmovaps xmm5, [rsp+0x50]
0000794c94dd847b  vmovaps xmm7, [rsp+0x60]
0000794c94dd8481  vmovaps xmm8, [rsp+0x70]
0000794c94dd8487  vmovaps xmm9, [rsp+0x80]
0000794c94dd8490  vmovaps xmm10, [rsp+0x90]
0000794c94dd8499  vmovaps xmm11, [rsp+0xA0]
0000794c94dd84a2  vmovaps xmm12, [rsp+0xB0]
0000794c94dd84ab  vmovaps xmm13, [rsp+0xC0]
0000794c94dd84b4  vmovaps xmm14, [rsp+0xD0]
0000794c94dd84bd  vmovaps xmm15, [rsp+0xE0]
0000794c94dd84c6  add rsp, 0xF0
0000794c94dd84cd  pop r11
0000794c94dd84cf  pop r10
0000794c94dd84d1  pop r9
0000794c94dd84d3  pop r8
0000794c94dd84d5  pop rsi
0000794c94dd84d6  pop rdi
0000794c94dd84d7  pop rdx
0000794c94dd84d8  pop rcx
0000794c94dd84d9  pop rax
0000794c94dd84da  add rsp, 0x08
0000794c94dd84de  jmp 0x0000794C94DD5FAB
0000794c94dd84e3  sub rsp, 0x08
0000794c94dd84e7  push rax
0000794c94dd84e8  push rcx
0000794c94dd84e9  push rdx
0000794c94dd84ea  push rdi
0000794c94dd84eb  push rsi
0000794c94dd84ec  push r8
0000794c94dd84ee  push r9
0000794c94dd84f0  push r10
0000794c94dd84f2  push r11
0000794c94dd84f4  sub rsp, 0xF0
0000794c94dd84fb  vmovaps [rsp], xmm0
0000794c94dd8500  vmovaps [rsp+0x10], xmm1
0000794c94dd8506  vmovaps [rsp+0x20], xmm2
0000794c94dd850c  vmovaps [rsp+0x30], xmm3
0000794c94dd8512  vmovaps [rsp+0x40], xmm4
0000794c94dd8518  vmovaps [rsp+0x50], xmm5
0000794c94dd851e  vmovaps [rsp+0x60], xmm6
0000794c94dd8524  vmovaps [rsp+0x70], xmm7
0000794c94dd852a  vmovaps [rsp+0x80], xmm8
0000794c94dd8533  vmovaps [rsp+0x90], xmm10
0000794c94dd853c  vmovaps [rsp+0xA0], xmm11
0000794c94dd8545  vmovaps [rsp+0xB0], xmm12
0000794c94dd854e  vmovaps [rsp+0xC0], xmm13
0000794c94dd8557  vmovaps [rsp+0xD0], xmm14
0000794c94dd8560  vmovaps [rsp+0xE0], xmm15
0000794c94dd8569  sub rsp, 0x30
0000794c94dd856d  movaps [rsp], xmm9
0000794c94dd8572  movaps [rsp+0x10], xmm3
0000794c94dd8577  movaps [rsp+0x20], xmm1
0000794c94dd857c  lea rdi, [rsp]
0000794c94dd8580  mov esi, 0x00
0000794c94dd8585  mov rax, 0x5AB2B8B81530
0000794c94dd858f  call rax
0000794c94dd8591  movaps xmm9, [rsp]
0000794c94dd8596  add rsp, 0x30
0000794c94dd859a  vmovaps xmm0, [rsp]
0000794c94dd859f  vmovaps xmm1, [rsp+0x10]
0000794c94dd85a5  vmovaps xmm2, [rsp+0x20]
0000794c94dd85ab  vmovaps xmm3, [rsp+0x30]
0000794c94dd85b1  vmovaps xmm4, [rsp+0x40]
0000794c94dd85b7  vmovaps xmm5, [rsp+0x50]
0000794c94dd85bd  vmovaps xmm6, [rsp+0x60]
0000794c94dd85c3  vmovaps xmm7, [rsp+0x70]
0000794c94dd85c9  vmovaps xmm8, [rsp+0x80]
0000794c94dd85d2  vmovaps xmm10, [rsp+0x90]
0000794c94dd85db  vmovaps xmm11, [rsp+0xA0]
0000794c94dd85e4  vmovaps xmm12, [rsp+0xB0]
0000794c94dd85ed  vmovaps xmm13, [rsp+0xC0]
0000794c94dd85f6  vmovaps xmm14, [rsp+0xD0]
0000794c94dd85ff  vmovaps xmm15, [rsp+0xE0]
0000794c94dd8608  add rsp, 0xF0
0000794c94dd860f  pop r11
0000794c94dd8611  pop r10
0000794c94dd8613  pop r9
0000794c94dd8615  pop r8
0000794c94dd8617  pop rsi
0000794c94dd8618  pop rdi
0000794c94dd8619  pop rdx
0000794c94dd861a  pop rcx
0000794c94dd861b  pop rax
0000794c94dd861c  add rsp, 0x08
0000794c94dd8620  jmp 0x0000794C94DD5FF7
0000794c94dd8625  call 0x0000794C94CD64F0
0000794c94dd862a  jmp 0x0000794C94DD6004
0000794c94dd862f  sub rsp, 0x08
0000794c94dd8633  push rax
0000794c94dd8634  push rcx
0000794c94dd8635  push rdx
0000794c94dd8636  push rdi
0000794c94dd8637  push rsi
0000794c94dd8638  push r8
0000794c94dd863a  push r9
0000794c94dd863c  push r10
0000794c94dd863e  push r11
0000794c94dd8640  sub rsp, 0xF0
0000794c94dd8647  vmovaps [rsp], xmm0
0000794c94dd864c  vmovaps [rsp+0x10], xmm1
0000794c94dd8652  vmovaps [rsp+0x20], xmm2
0000794c94dd8658  vmovaps [rsp+0x30], xmm3
0000794c94dd865e  vmovaps [rsp+0x40], xmm4
0000794c94dd8664  vmovaps [rsp+0x50], xmm5
0000794c94dd866a  vmovaps [rsp+0x60], xmm6
0000794c94dd8670  vmovaps [rsp+0x70], xmm7
0000794c94dd8676  vmovaps [rsp+0x80], xmm8
0000794c94dd867f  vmovaps [rsp+0x90], xmm9
0000794c94dd8688  vmovaps [rsp+0xA0], xmm10
0000794c94dd8691  vmovaps [rsp+0xB0], xmm11
0000794c94dd869a  vmovaps [rsp+0xC0], xmm12
0000794c94dd86a3  vmovaps [rsp+0xD0], xmm13
0000794c94dd86ac  vmovaps [rsp+0xE0], xmm14
0000794c94dd86b5  sub rsp, 0x30
0000794c94dd86b9  movaps [rsp], xmm15
0000794c94dd86be  movaps [rsp+0x10], xmm3
0000794c94dd86c3  movaps [rsp+0x20], xmm7
0000794c94dd86c8  lea rdi, [rsp]
0000794c94dd86cc  mov esi, 0x00
0000794c94dd86d1  mov rax, 0x5AB2B8B81530
0000794c94dd86db  call rax
0000794c94dd86dd  movaps xmm15, [rsp]
0000794c94dd86e2  add rsp, 0x30
0000794c94dd86e6  vmovaps xmm0, [rsp]
0000794c94dd86eb  vmovaps xmm1, [rsp+0x10]
0000794c94dd86f1  vmovaps xmm2, [rsp+0x20]
0000794c94dd86f7  vmovaps xmm3, [rsp+0x30]
0000794c94dd86fd  vmovaps xmm4, [rsp+0x40]
0000794c94dd8703  vmovaps xmm5, [rsp+0x50]
0000794c94dd8709  vmovaps xmm6, [rsp+0x60]
0000794c94dd870f  vmovaps xmm7, [rsp+0x70]
0000794c94dd8715  vmovaps xmm8, [rsp+0x80]
0000794c94dd871e  vmovaps xmm9, [rsp+0x90]
0000794c94dd8727  vmovaps xmm10, [rsp+0xA0]
0000794c94dd8730  vmovaps xmm11, [rsp+0xB0]
0000794c94dd8739  vmovaps xmm12, [rsp+0xC0]
0000794c94dd8742  vmovaps xmm13, [rsp+0xD0]
0000794c94dd874b  vmovaps xmm14, [rsp+0xE0]
0000794c94dd8754  add rsp, 0xF0
0000794c94dd875b  pop r11
0000794c94dd875d  pop r10
0000794c94dd875f  pop r9
0000794c94dd8761  pop r8
0000794c94dd8763  pop rsi
0000794c94dd8764  pop rdi
0000794c94dd8765  pop rdx
0000794c94dd8766  pop rcx
0000794c94dd8767  pop rax
0000794c94dd8768  add rsp, 0x08
0000794c94dd876c  jmp 0x0000794C94DD6030
0000794c94dd8771  sub rsp, 0x08
0000794c94dd8775  push rax
0000794c94dd8776  push rcx
0000794c94dd8777  push rdx
0000794c94dd8778  push rdi
0000794c94dd8779  push rsi
0000794c94dd877a  push r8
0000794c94dd877c  push r9
0000794c94dd877e  push r10
0000794c94dd8780  push r11
0000794c94dd8782  sub rsp, 0xF0
0000794c94dd8789  vmovaps [rsp], xmm0
0000794c94dd878e  vmovaps [rsp+0x10], xmm1
0000794c94dd8794  vmovaps [rsp+0x20], xmm2
0000794c94dd879a  vmovaps [rsp+0x30], xmm4
0000794c94dd87a0  vmovaps [rsp+0x40], xmm5
0000794c94dd87a6  vmovaps [rsp+0x50], xmm6
0000794c94dd87ac  vmovaps [rsp+0x60], xmm7
0000794c94dd87b2  vmovaps [rsp+0x70], xmm8
0000794c94dd87b8  vmovaps [rsp+0x80], xmm9
0000794c94dd87c1  vmovaps [rsp+0x90], xmm10
0000794c94dd87ca  vmovaps [rsp+0xA0], xmm11
0000794c94dd87d3  vmovaps [rsp+0xB0], xmm12
0000794c94dd87dc  vmovaps [rsp+0xC0], xmm13
0000794c94dd87e5  vmovaps [rsp+0xD0], xmm14
0000794c94dd87ee  vmovaps [rsp+0xE0], xmm15
0000794c94dd87f7  sub rsp, 0x30
0000794c94dd87fb  movaps [rsp], xmm3
0000794c94dd87ff  movaps [rsp+0x10], xmm1
0000794c94dd8804  movaps [rsp+0x20], xmm15
0000794c94dd880a  lea rdi, [rsp]
0000794c94dd880e  mov esi, 0x00
0000794c94dd8813  mov rax, 0x5AB2B8B81530
0000794c94dd881d  call rax
0000794c94dd881f  movaps xmm3, [rsp]
0000794c94dd8823  add rsp, 0x30
0000794c94dd8827  vmovaps xmm0, [rsp]
0000794c94dd882c  vmovaps xmm1, [rsp+0x10]
0000794c94dd8832  vmovaps xmm2, [rsp+0x20]
0000794c94dd8838  vmovaps xmm4, [rsp+0x30]
0000794c94dd883e  vmovaps xmm5, [rsp+0x40]
0000794c94dd8844  vmovaps xmm6, [rsp+0x50]
0000794c94dd884a  vmovaps xmm7, [rsp+0x60]
0000794c94dd8850  vmovaps xmm8, [rsp+0x70]
0000794c94dd8856  vmovaps xmm9, [rsp+0x80]
0000794c94dd885f  vmovaps xmm10, [rsp+0x90]
0000794c94dd8868  vmovaps xmm11, [rsp+0xA0]
0000794c94dd8871  vmovaps xmm12, [rsp+0xB0]
0000794c94dd887a  vmovaps xmm13, [rsp+0xC0]
0000794c94dd8883  vmovaps xmm14, [rsp+0xD0]
0000794c94dd888c  vmovaps xmm15, [rsp+0xE0]
0000794c94dd8895  add rsp, 0xF0
0000794c94dd889c  pop r11
0000794c94dd889e  pop r10
0000794c94dd88a0  pop r9
0000794c94dd88a2  pop r8
0000794c94dd88a4  pop rsi
0000794c94dd88a5  pop rdi
0000794c94dd88a6  pop rdx
0000794c94dd88a7  pop rcx
0000794c94dd88a8  pop rax
0000794c94dd88a9  add rsp, 0x08
0000794c94dd88ad  jmp 0x0000794C94DD60BF
0000794c94dd88b2  call 0x0000794C94CD64F0
0000794c94dd88b7  jmp 0x0000794C94DD60C9
0000794c94dd88bc  sub rsp, 0x08
0000794c94dd88c0  push rax
0000794c94dd88c1  push rcx
0000794c94dd88c2  push rdx
0000794c94dd88c3  push rdi
0000794c94dd88c4  push rsi
0000794c94dd88c5  push r8
0000794c94dd88c7  push r9
0000794c94dd88c9  push r10
0000794c94dd88cb  push r11
0000794c94dd88cd  sub rsp, 0xF0
0000794c94dd88d4  vmovaps [rsp], xmm0
0000794c94dd88d9  vmovaps [rsp+0x10], xmm1
0000794c94dd88df  vmovaps [rsp+0x20], xmm2
0000794c94dd88e5  vmovaps [rsp+0x30], xmm3
0000794c94dd88eb  vmovaps [rsp+0x40], xmm4
0000794c94dd88f1  vmovaps [rsp+0x50], xmm5
0000794c94dd88f7  vmovaps [rsp+0x60], xmm6
0000794c94dd88fd  vmovaps [rsp+0x70], xmm7
0000794c94dd8903  vmovaps [rsp+0x80], xmm8
0000794c94dd890c  vmovaps [rsp+0x90], xmm9
0000794c94dd8915  vmovaps [rsp+0xA0], xmm10
0000794c94dd891e  vmovaps [rsp+0xB0], xmm11
0000794c94dd8927  vmovaps [rsp+0xC0], xmm12
0000794c94dd8930  vmovaps [rsp+0xD0], xmm13
0000794c94dd8939  vmovaps [rsp+0xE0], xmm14
0000794c94dd8942  sub rsp, 0x30
0000794c94dd8946  movaps [rsp], xmm15
0000794c94dd894b  movaps [rsp+0x10], xmm14
0000794c94dd8951  movaps [rsp+0x20], xmm4
0000794c94dd8956  lea rdi, [rsp]
0000794c94dd895a  mov esi, 0x00
0000794c94dd895f  mov rax, 0x5AB2B8B81530
0000794c94dd8969  call rax
0000794c94dd896b  movaps xmm15, [rsp]
0000794c94dd8970  add rsp, 0x30
0000794c94dd8974  vmovaps xmm0, [rsp]
0000794c94dd8979  vmovaps xmm1, [rsp+0x10]
0000794c94dd897f  vmovaps xmm2, [rsp+0x20]
0000794c94dd8985  vmovaps xmm3, [rsp+0x30]
0000794c94dd898b  vmovaps xmm4, [rsp+0x40]
0000794c94dd8991  vmovaps xmm5, [rsp+0x50]
0000794c94dd8997  vmovaps xmm6, [rsp+0x60]
0000794c94dd899d  vmovaps xmm7, [rsp+0x70]
0000794c94dd89a3  vmovaps xmm8, [rsp+0x80]
0000794c94dd89ac  vmovaps xmm9, [rsp+0x90]
0000794c94dd89b5  vmovaps xmm10, [rsp+0xA0]
0000794c94dd89be  vmovaps xmm11, [rsp+0xB0]
0000794c94dd89c7  vmovaps xmm12, [rsp+0xC0]
0000794c94dd89d0  vmovaps xmm13, [rsp+0xD0]
0000794c94dd89d9  vmovaps xmm14, [rsp+0xE0]
0000794c94dd89e2  add rsp, 0xF0
0000794c94dd89e9  pop r11
0000794c94dd89eb  pop r10
0000794c94dd89ed  pop r9
0000794c94dd89ef  pop r8
0000794c94dd89f1  pop rsi
0000794c94dd89f2  pop rdi
0000794c94dd89f3  pop rdx
0000794c94dd89f4  pop rcx
0000794c94dd89f5  pop rax
0000794c94dd89f6  add rsp, 0x08
0000794c94dd89fa  jmp 0x0000794C94DD60F7
0000794c94dd89ff  sub rsp, 0x08
0000794c94dd8a03  push rax
0000794c94dd8a04  push rcx
0000794c94dd8a05  push rdx
0000794c94dd8a06  push rdi
0000794c94dd8a07  push rsi
0000794c94dd8a08  push r8
0000794c94dd8a0a  push r9
0000794c94dd8a0c  push r10
0000794c94dd8a0e  push r11
0000794c94dd8a10  sub rsp, 0xF0
0000794c94dd8a17  vmovaps [rsp], xmm0
0000794c94dd8a1c  vmovaps [rsp+0x10], xmm1
0000794c94dd8a22  vmovaps [rsp+0x20], xmm2
0000794c94dd8a28  vmovaps [rsp+0x30], xmm3
0000794c94dd8a2e  vmovaps [rsp+0x40], xmm4
0000794c94dd8a34  vmovaps [rsp+0x50], xmm5
0000794c94dd8a3a  vmovaps [rsp+0x60], xmm6
0000794c94dd8a40  vmovaps [rsp+0x70], xmm7
0000794c94dd8a46  vmovaps [rsp+0x80], xmm8
0000794c94dd8a4f  vmovaps [rsp+0x90], xmm9
0000794c94dd8a58  vmovaps [rsp+0xA0], xmm10
0000794c94dd8a61  vmovaps [rsp+0xB0], xmm11
0000794c94dd8a6a  vmovaps [rsp+0xC0], xmm12
0000794c94dd8a73  vmovaps [rsp+0xD0], xmm13
0000794c94dd8a7c  vmovaps [rsp+0xE0], xmm15
0000794c94dd8a85  sub rsp, 0x30
0000794c94dd8a89  movaps [rsp], xmm14
0000794c94dd8a8e  movaps [rsp+0x10], xmm2
0000794c94dd8a93  movaps [rsp+0x20], xmm1
0000794c94dd8a98  lea rdi, [rsp]
0000794c94dd8a9c  mov esi, 0x00
0000794c94dd8aa1  mov rax, 0x5AB2B8B81530
0000794c94dd8aab  call rax
0000794c94dd8aad  movaps xmm14, [rsp]
0000794c94dd8ab2  add rsp, 0x30
0000794c94dd8ab6  vmovaps xmm0, [rsp]
0000794c94dd8abb  vmovaps xmm1, [rsp+0x10]
0000794c94dd8ac1  vmovaps xmm2, [rsp+0x20]
0000794c94dd8ac7  vmovaps xmm3, [rsp+0x30]
0000794c94dd8acd  vmovaps xmm4, [rsp+0x40]
0000794c94dd8ad3  vmovaps xmm5, [rsp+0x50]
0000794c94dd8ad9  vmovaps xmm6, [rsp+0x60]
0000794c94dd8adf  vmovaps xmm7, [rsp+0x70]
0000794c94dd8ae5  vmovaps xmm8, [rsp+0x80]
0000794c94dd8aee  vmovaps xmm9, [rsp+0x90]
0000794c94dd8af7  vmovaps xmm10, [rsp+0xA0]
0000794c94dd8b00  vmovaps xmm11, [rsp+0xB0]
0000794c94dd8b09  vmovaps xmm12, [rsp+0xC0]
0000794c94dd8b12  vmovaps xmm13, [rsp+0xD0]
0000794c94dd8b1b  vmovaps xmm15, [rsp+0xE0]
0000794c94dd8b24  add rsp, 0xF0
0000794c94dd8b2b  pop r11
0000794c94dd8b2d  pop r10
0000794c94dd8b2f  pop r9
0000794c94dd8b31  pop r8
0000794c94dd8b33  pop rsi
0000794c94dd8b34  pop rdi
0000794c94dd8b35  pop rdx
0000794c94dd8b36  pop rcx
0000794c94dd8b37  pop rax
0000794c94dd8b38  add rsp, 0x08
0000794c94dd8b3c  jmp 0x0000794C94DD611D
0000794c94dd8b41  sub rsp, 0x08
0000794c94dd8b45  push rax
0000794c94dd8b46  push rcx
0000794c94dd8b47  push rdx
0000794c94dd8b48  push rdi
0000794c94dd8b49  push rsi
0000794c94dd8b4a  push r8
0000794c94dd8b4c  push r9
0000794c94dd8b4e  push r10
0000794c94dd8b50  push r11
0000794c94dd8b52  sub rsp, 0xF0
0000794c94dd8b59  vmovaps [rsp], xmm0
0000794c94dd8b5e  vmovaps [rsp+0x10], xmm2
0000794c94dd8b64  vmovaps [rsp+0x20], xmm3
0000794c94dd8b6a  vmovaps [rsp+0x30], xmm4
0000794c94dd8b70  vmovaps [rsp+0x40], xmm5
0000794c94dd8b76  vmovaps [rsp+0x50], xmm6
0000794c94dd8b7c  vmovaps [rsp+0x60], xmm7
0000794c94dd8b82  vmovaps [rsp+0x70], xmm8
0000794c94dd8b88  vmovaps [rsp+0x80], xmm9
0000794c94dd8b91  vmovaps [rsp+0x90], xmm10
0000794c94dd8b9a  vmovaps [rsp+0xA0], xmm11
0000794c94dd8ba3  vmovaps [rsp+0xB0], xmm12
0000794c94dd8bac  vmovaps [rsp+0xC0], xmm13
0000794c94dd8bb5  vmovaps [rsp+0xD0], xmm14
0000794c94dd8bbe  vmovaps [rsp+0xE0], xmm15
0000794c94dd8bc7  sub rsp, 0x30
0000794c94dd8bcb  movaps [rsp], xmm1
0000794c94dd8bcf  movaps [rsp+0x10], xmm4
0000794c94dd8bd4  movaps [rsp+0x20], xmm9
0000794c94dd8bda  lea rdi, [rsp]
0000794c94dd8bde  mov esi, 0x00
0000794c94dd8be3  mov rax, 0x5AB2B8B81530
0000794c94dd8bed  call rax
0000794c94dd8bef  movaps xmm1, [rsp]
0000794c94dd8bf3  add rsp, 0x30
0000794c94dd8bf7  vmovaps xmm0, [rsp]
0000794c94dd8bfc  vmovaps xmm2, [rsp+0x10]
0000794c94dd8c02  vmovaps xmm3, [rsp+0x20]
0000794c94dd8c08  vmovaps xmm4, [rsp+0x30]
0000794c94dd8c0e  vmovaps xmm5, [rsp+0x40]
0000794c94dd8c14  vmovaps xmm6, [rsp+0x50]
0000794c94dd8c1a  vmovaps xmm7, [rsp+0x60]
0000794c94dd8c20  vmovaps xmm8, [rsp+0x70]
0000794c94dd8c26  vmovaps xmm9, [rsp+0x80]
0000794c94dd8c2f  vmovaps xmm10, [rsp+0x90]
0000794c94dd8c38  vmovaps xmm11, [rsp+0xA0]
0000794c94dd8c41  vmovaps xmm12, [rsp+0xB0]
0000794c94dd8c4a  vmovaps xmm13, [rsp+0xC0]
0000794c94dd8c53  vmovaps xmm14, [rsp+0xD0]
0000794c94dd8c5c  vmovaps xmm15, [rsp+0xE0]
0000794c94dd8c65  add rsp, 0xF0
0000794c94dd8c6c  pop r11
0000794c94dd8c6e  pop r10
0000794c94dd8c70  pop r9
0000794c94dd8c72  pop r8
0000794c94dd8c74  pop rsi
0000794c94dd8c75  pop rdi
0000794c94dd8c76  pop rdx
0000794c94dd8c77  pop rcx
0000794c94dd8c78  pop rax
0000794c94dd8c79  add rsp, 0x08
0000794c94dd8c7d  jmp 0x0000794C94DD613B
0000794c94dd8c82  sub rsp, 0x08
0000794c94dd8c86  push rax
0000794c94dd8c87  push rcx
0000794c94dd8c88  push rdx
0000794c94dd8c89  push rdi
0000794c94dd8c8a  push rsi
0000794c94dd8c8b  push r8
0000794c94dd8c8d  push r9
0000794c94dd8c8f  push r10
0000794c94dd8c91  push r11
0000794c94dd8c93  sub rsp, 0xF0
0000794c94dd8c9a  vmovaps [rsp], xmm0
0000794c94dd8c9f  vmovaps [rsp+0x10], xmm1
0000794c94dd8ca5  vmovaps [rsp+0x20], xmm2
0000794c94dd8cab  vmovaps [rsp+0x30], xmm3
0000794c94dd8cb1  vmovaps [rsp+0x40], xmm5
0000794c94dd8cb7  vmovaps [rsp+0x50], xmm6
0000794c94dd8cbd  vmovaps [rsp+0x60], xmm7
0000794c94dd8cc3  vmovaps [rsp+0x70], xmm8
0000794c94dd8cc9  vmovaps [rsp+0x80], xmm9
0000794c94dd8cd2  vmovaps [rsp+0x90], xmm10
0000794c94dd8cdb  vmovaps [rsp+0xA0], xmm11
0000794c94dd8ce4  vmovaps [rsp+0xB0], xmm12
0000794c94dd8ced  vmovaps [rsp+0xC0], xmm13
0000794c94dd8cf6  vmovaps [rsp+0xD0], xmm14
0000794c94dd8cff  vmovaps [rsp+0xE0], xmm15
0000794c94dd8d08  sub rsp, 0x30
0000794c94dd8d0c  movaps [rsp], xmm4
0000794c94dd8d10  movaps [rsp+0x10], xmm2
0000794c94dd8d15  movaps [rsp+0x20], xmm9
0000794c94dd8d1b  lea rdi, [rsp]
0000794c94dd8d1f  mov esi, 0x00
0000794c94dd8d24  mov rax, 0x5AB2B8B81530
0000794c94dd8d2e  call rax
0000794c94dd8d30  movaps xmm4, [rsp]
0000794c94dd8d34  add rsp, 0x30
0000794c94dd8d38  vmovaps xmm0, [rsp]
0000794c94dd8d3d  vmovaps xmm1, [rsp+0x10]
0000794c94dd8d43  vmovaps xmm2, [rsp+0x20]
0000794c94dd8d49  vmovaps xmm3, [rsp+0x30]
0000794c94dd8d4f  vmovaps xmm5, [rsp+0x40]
0000794c94dd8d55  vmovaps xmm6, [rsp+0x50]
0000794c94dd8d5b  vmovaps xmm7, [rsp+0x60]
0000794c94dd8d61  vmovaps xmm8, [rsp+0x70]
0000794c94dd8d67  vmovaps xmm9, [rsp+0x80]
0000794c94dd8d70  vmovaps xmm10, [rsp+0x90]
0000794c94dd8d79  vmovaps xmm11, [rsp+0xA0]
0000794c94dd8d82  vmovaps xmm12, [rsp+0xB0]
0000794c94dd8d8b  vmovaps xmm13, [rsp+0xC0]
0000794c94dd8d94  vmovaps xmm14, [rsp+0xD0]
0000794c94dd8d9d  vmovaps xmm15, [rsp+0xE0]
0000794c94dd8da6  add rsp, 0xF0
0000794c94dd8dad  pop r11
0000794c94dd8daf  pop r10
0000794c94dd8db1  pop r9
0000794c94dd8db3  pop r8
0000794c94dd8db5  pop rsi
0000794c94dd8db6  pop rdi
0000794c94dd8db7  pop rdx
0000794c94dd8db8  pop rcx
0000794c94dd8db9  pop rax
0000794c94dd8dba  add rsp, 0x08
0000794c94dd8dbe  jmp 0x0000794C94DD616B
0000794c94dd8dc3  sub rsp, 0x08
0000794c94dd8dc7  push rax
0000794c94dd8dc8  push rcx
0000794c94dd8dc9  push rdx
0000794c94dd8dca  push rdi
0000794c94dd8dcb  push rsi
0000794c94dd8dcc  push r8
0000794c94dd8dce  push r9
0000794c94dd8dd0  push r10
0000794c94dd8dd2  push r11
0000794c94dd8dd4  sub rsp, 0xF0
0000794c94dd8ddb  vmovaps [rsp], xmm0
0000794c94dd8de0  vmovaps [rsp+0x10], xmm1
0000794c94dd8de6  vmovaps [rsp+0x20], xmm2
0000794c94dd8dec  vmovaps [rsp+0x30], xmm3
0000794c94dd8df2  vmovaps [rsp+0x40], xmm4
0000794c94dd8df8  vmovaps [rsp+0x50], xmm5
0000794c94dd8dfe  vmovaps [rsp+0x60], xmm6
0000794c94dd8e04  vmovaps [rsp+0x70], xmm7
0000794c94dd8e0a  vmovaps [rsp+0x80], xmm8
0000794c94dd8e13  vmovaps [rsp+0x90], xmm10
0000794c94dd8e1c  vmovaps [rsp+0xA0], xmm11
0000794c94dd8e25  vmovaps [rsp+0xB0], xmm12
0000794c94dd8e2e  vmovaps [rsp+0xC0], xmm13
0000794c94dd8e37  vmovaps [rsp+0xD0], xmm14
0000794c94dd8e40  vmovaps [rsp+0xE0], xmm15
0000794c94dd8e49  sub rsp, 0x30
0000794c94dd8e4d  movaps [rsp], xmm9
0000794c94dd8e52  movaps [rsp+0x10], xmm2
0000794c94dd8e57  movaps [rsp+0x20], xmm1
0000794c94dd8e5c  lea rdi, [rsp]
0000794c94dd8e60  mov esi, 0x00
0000794c94dd8e65  mov rax, 0x5AB2B8B81530
0000794c94dd8e6f  call rax
0000794c94dd8e71  movaps xmm9, [rsp]
0000794c94dd8e76  add rsp, 0x30
0000794c94dd8e7a  vmovaps xmm0, [rsp]
0000794c94dd8e7f  vmovaps xmm1, [rsp+0x10]
0000794c94dd8e85  vmovaps xmm2, [rsp+0x20]
0000794c94dd8e8b  vmovaps xmm3, [rsp+0x30]
0000794c94dd8e91  vmovaps xmm4, [rsp+0x40]
0000794c94dd8e97  vmovaps xmm5, [rsp+0x50]
0000794c94dd8e9d  vmovaps xmm6, [rsp+0x60]
0000794c94dd8ea3  vmovaps xmm7, [rsp+0x70]
0000794c94dd8ea9  vmovaps xmm8, [rsp+0x80]
0000794c94dd8eb2  vmovaps xmm10, [rsp+0x90]
0000794c94dd8ebb  vmovaps xmm11, [rsp+0xA0]
0000794c94dd8ec4  vmovaps xmm12, [rsp+0xB0]
0000794c94dd8ecd  vmovaps xmm13, [rsp+0xC0]
0000794c94dd8ed6  vmovaps xmm14, [rsp+0xD0]
0000794c94dd8edf  vmovaps xmm15, [rsp+0xE0]
0000794c94dd8ee8  add rsp, 0xF0
0000794c94dd8eef  pop r11
0000794c94dd8ef1  pop r10
0000794c94dd8ef3  pop r9
0000794c94dd8ef5  pop r8
0000794c94dd8ef7  pop rsi
0000794c94dd8ef8  pop rdi
0000794c94dd8ef9  pop rdx
0000794c94dd8efa  pop rcx
0000794c94dd8efb  pop rax
0000794c94dd8efc  add rsp, 0x08
0000794c94dd8f00  jmp 0x0000794C94DD61A1
0000794c94dd8f05  sub rsp, 0x08
0000794c94dd8f09  push rax
0000794c94dd8f0a  push rcx
0000794c94dd8f0b  push rdx
0000794c94dd8f0c  push rdi
0000794c94dd8f0d  push rsi
0000794c94dd8f0e  push r8
0000794c94dd8f10  push r9
0000794c94dd8f12  push r10
0000794c94dd8f14  push r11
0000794c94dd8f16  sub rsp, 0xF0
0000794c94dd8f1d  vmovaps [rsp], xmm0
0000794c94dd8f22  vmovaps [rsp+0x10], xmm2
0000794c94dd8f28  vmovaps [rsp+0x20], xmm3
0000794c94dd8f2e  vmovaps [rsp+0x30], xmm4
0000794c94dd8f34  vmovaps [rsp+0x40], xmm5
0000794c94dd8f3a  vmovaps [rsp+0x50], xmm6
0000794c94dd8f40  vmovaps [rsp+0x60], xmm7
0000794c94dd8f46  vmovaps [rsp+0x70], xmm8
0000794c94dd8f4c  vmovaps [rsp+0x80], xmm9
0000794c94dd8f55  vmovaps [rsp+0x90], xmm10
0000794c94dd8f5e  vmovaps [rsp+0xA0], xmm11
0000794c94dd8f67  vmovaps [rsp+0xB0], xmm12
0000794c94dd8f70  vmovaps [rsp+0xC0], xmm13
0000794c94dd8f79  vmovaps [rsp+0xD0], xmm14
0000794c94dd8f82  vmovaps [rsp+0xE0], xmm15
0000794c94dd8f8b  sub rsp, 0x30
0000794c94dd8f8f  movaps [rsp], xmm1
0000794c94dd8f93  movaps [rsp+0x10], xmm15
0000794c94dd8f99  movaps [rsp+0x20], xmm6
0000794c94dd8f9e  lea rdi, [rsp]
0000794c94dd8fa2  mov esi, 0x00
0000794c94dd8fa7  mov rax, 0x5AB2B8B81530
0000794c94dd8fb1  call rax
0000794c94dd8fb3  movaps xmm1, [rsp]
0000794c94dd8fb7  add rsp, 0x30
0000794c94dd8fbb  vmovaps xmm0, [rsp]
0000794c94dd8fc0  vmovaps xmm2, [rsp+0x10]
0000794c94dd8fc6  vmovaps xmm3, [rsp+0x20]
0000794c94dd8fcc  vmovaps xmm4, [rsp+0x30]
0000794c94dd8fd2  vmovaps xmm5, [rsp+0x40]
0000794c94dd8fd8  vmovaps xmm6, [rsp+0x50]
0000794c94dd8fde  vmovaps xmm7, [rsp+0x60]
0000794c94dd8fe4  vmovaps xmm8, [rsp+0x70]
0000794c94dd8fea  vmovaps xmm9, [rsp+0x80]
0000794c94dd8ff3  vmovaps xmm10, [rsp+0x90]
0000794c94dd8ffc  vmovaps xmm11, [rsp+0xA0]
0000794c94dd9005  vmovaps xmm12, [rsp+0xB0]
0000794c94dd900e  vmovaps xmm13, [rsp+0xC0]
0000794c94dd9017  vmovaps xmm14, [rsp+0xD0]
0000794c94dd9020  vmovaps xmm15, [rsp+0xE0]
0000794c94dd9029  add rsp, 0xF0
0000794c94dd9030  pop r11
0000794c94dd9032  pop r10
0000794c94dd9034  pop r9
0000794c94dd9036  pop r8
0000794c94dd9038  pop rsi
0000794c94dd9039  pop rdi
0000794c94dd903a  pop rdx
0000794c94dd903b  pop rcx
0000794c94dd903c  pop rax
0000794c94dd903d  add rsp, 0x08
0000794c94dd9041  jmp 0x0000794C94DD61C2
0000794c94dd9046  sub rsp, 0x08
0000794c94dd904a  push rax
0000794c94dd904b  push rcx
0000794c94dd904c  push rdx
0000794c94dd904d  push rdi
0000794c94dd904e  push rsi
0000794c94dd904f  push r8
0000794c94dd9051  push r9
0000794c94dd9053  push r10
0000794c94dd9055  push r11
0000794c94dd9057  sub rsp, 0xF0
0000794c94dd905e  vmovaps [rsp], xmm0
0000794c94dd9063  vmovaps [rsp+0x10], xmm1
0000794c94dd9069  vmovaps [rsp+0x20], xmm2
0000794c94dd906f  vmovaps [rsp+0x30], xmm3
0000794c94dd9075  vmovaps [rsp+0x40], xmm4
0000794c94dd907b  vmovaps [rsp+0x50], xmm5
0000794c94dd9081  vmovaps [rsp+0x60], xmm6
0000794c94dd9087  vmovaps [rsp+0x70], xmm7
0000794c94dd908d  vmovaps [rsp+0x80], xmm8
0000794c94dd9096  vmovaps [rsp+0x90], xmm9
0000794c94dd909f  vmovaps [rsp+0xA0], xmm10
0000794c94dd90a8  vmovaps [rsp+0xB0], xmm11
0000794c94dd90b1  vmovaps [rsp+0xC0], xmm12
0000794c94dd90ba  vmovaps [rsp+0xD0], xmm13
0000794c94dd90c3  vmovaps [rsp+0xE0], xmm14
0000794c94dd90cc  sub rsp, 0x30
0000794c94dd90d0  movaps [rsp], xmm15
0000794c94dd90d5  movaps [rsp+0x10], xmm5
0000794c94dd90da  movaps [rsp+0x20], xmm3
0000794c94dd90df  lea rdi, [rsp]
0000794c94dd90e3  mov esi, 0x00
0000794c94dd90e8  mov rax, 0x5AB2B8B81530
0000794c94dd90f2  call rax
0000794c94dd90f4  movaps xmm15, [rsp]
0000794c94dd90f9  add rsp, 0x30
0000794c94dd90fd  vmovaps xmm0, [rsp]
0000794c94dd9102  vmovaps xmm1, [rsp+0x10]
0000794c94dd9108  vmovaps xmm2, [rsp+0x20]
0000794c94dd910e  vmovaps xmm3, [rsp+0x30]
0000794c94dd9114  vmovaps xmm4, [rsp+0x40]
0000794c94dd911a  vmovaps xmm5, [rsp+0x50]
0000794c94dd9120  vmovaps xmm6, [rsp+0x60]
0000794c94dd9126  vmovaps xmm7, [rsp+0x70]
0000794c94dd912c  vmovaps xmm8, [rsp+0x80]
0000794c94dd9135  vmovaps xmm9, [rsp+0x90]
0000794c94dd913e  vmovaps xmm10, [rsp+0xA0]
0000794c94dd9147  vmovaps xmm11, [rsp+0xB0]
0000794c94dd9150  vmovaps xmm12, [rsp+0xC0]
0000794c94dd9159  vmovaps xmm13, [rsp+0xD0]
0000794c94dd9162  vmovaps xmm14, [rsp+0xE0]
0000794c94dd916b  add rsp, 0xF0
0000794c94dd9172  pop r11
0000794c94dd9174  pop r10
0000794c94dd9176  pop r9
0000794c94dd9178  pop r8
0000794c94dd917a  pop rsi
0000794c94dd917b  pop rdi
0000794c94dd917c  pop rdx
0000794c94dd917d  pop rcx
0000794c94dd917e  pop rax
0000794c94dd917f  add rsp, 0x08
0000794c94dd9183  jmp 0x0000794C94DD61DC
0000794c94dd9188  sub rsp, 0x08
0000794c94dd918c  push rax
0000794c94dd918d  push rcx
0000794c94dd918e  push rdx
0000794c94dd918f  push rdi
0000794c94dd9190  push rsi
0000794c94dd9191  push r8
0000794c94dd9193  push r9
0000794c94dd9195  push r10
0000794c94dd9197  push r11
0000794c94dd9199  sub rsp, 0xF0
0000794c94dd91a0  vmovaps [rsp], xmm0
0000794c94dd91a5  vmovaps [rsp+0x10], xmm1
0000794c94dd91ab  vmovaps [rsp+0x20], xmm2
0000794c94dd91b1  vmovaps [rsp+0x30], xmm3
0000794c94dd91b7  vmovaps [rsp+0x40], xmm4
0000794c94dd91bd  vmovaps [rsp+0x50], xmm6
0000794c94dd91c3  vmovaps [rsp+0x60], xmm7
0000794c94dd91c9  vmovaps [rsp+0x70], xmm8
0000794c94dd91cf  vmovaps [rsp+0x80], xmm9
0000794c94dd91d8  vmovaps [rsp+0x90], xmm10
0000794c94dd91e1  vmovaps [rsp+0xA0], xmm11
0000794c94dd91ea  vmovaps [rsp+0xB0], xmm12
0000794c94dd91f3  vmovaps [rsp+0xC0], xmm13
0000794c94dd91fc  vmovaps [rsp+0xD0], xmm14
0000794c94dd9205  vmovaps [rsp+0xE0], xmm15
0000794c94dd920e  sub rsp, 0x30
0000794c94dd9212  movaps [rsp], xmm5
0000794c94dd9216  movaps [rsp+0x10], xmm8
0000794c94dd921c  movaps [rsp+0x20], xmm6
0000794c94dd9221  lea rdi, [rsp]
0000794c94dd9225  mov esi, 0x00
0000794c94dd922a  mov rax, 0x5AB2B8B81530
0000794c94dd9234  call rax
0000794c94dd9236  movaps xmm5, [rsp]
0000794c94dd923a  add rsp, 0x30
0000794c94dd923e  vmovaps xmm0, [rsp]
0000794c94dd9243  vmovaps xmm1, [rsp+0x10]
0000794c94dd9249  vmovaps xmm2, [rsp+0x20]
0000794c94dd924f  vmovaps xmm3, [rsp+0x30]
0000794c94dd9255  vmovaps xmm4, [rsp+0x40]
0000794c94dd925b  vmovaps xmm6, [rsp+0x50]
0000794c94dd9261  vmovaps xmm7, [rsp+0x60]
0000794c94dd9267  vmovaps xmm8, [rsp+0x70]
0000794c94dd926d  vmovaps xmm9, [rsp+0x80]
0000794c94dd9276  vmovaps xmm10, [rsp+0x90]
0000794c94dd927f  vmovaps xmm11, [rsp+0xA0]
0000794c94dd9288  vmovaps xmm12, [rsp+0xB0]
0000794c94dd9291  vmovaps xmm13, [rsp+0xC0]
0000794c94dd929a  vmovaps xmm14, [rsp+0xD0]
0000794c94dd92a3  vmovaps xmm15, [rsp+0xE0]
0000794c94dd92ac  add rsp, 0xF0
0000794c94dd92b3  pop r11
0000794c94dd92b5  pop r10
0000794c94dd92b7  pop r9
0000794c94dd92b9  pop r8
0000794c94dd92bb  pop rsi
0000794c94dd92bc  pop rdi
0000794c94dd92bd  pop rdx
0000794c94dd92be  pop rcx
0000794c94dd92bf  pop rax
0000794c94dd92c0  add rsp, 0x08
0000794c94dd92c4  jmp 0x0000794C94DD6200
0000794c94dd92c9  sub rsp, 0x08
0000794c94dd92cd  push rax
0000794c94dd92ce  push rcx
0000794c94dd92cf  push rdx
0000794c94dd92d0  push rdi
0000794c94dd92d1  push rsi
0000794c94dd92d2  push r8
0000794c94dd92d4  push r9
0000794c94dd92d6  push r10
0000794c94dd92d8  push r11
0000794c94dd92da  sub rsp, 0xF0
0000794c94dd92e1  vmovaps [rsp], xmm0
0000794c94dd92e6  vmovaps [rsp+0x10], xmm1
0000794c94dd92ec  vmovaps [rsp+0x20], xmm2
0000794c94dd92f2  vmovaps [rsp+0x30], xmm3
0000794c94dd92f8  vmovaps [rsp+0x40], xmm4
0000794c94dd92fe  vmovaps [rsp+0x50], xmm5
0000794c94dd9304  vmovaps [rsp+0x60], xmm7
0000794c94dd930a  vmovaps [rsp+0x70], xmm8
0000794c94dd9310  vmovaps [rsp+0x80], xmm9
0000794c94dd9319  vmovaps [rsp+0x90], xmm10
0000794c94dd9322  vmovaps [rsp+0xA0], xmm11
0000794c94dd932b  vmovaps [rsp+0xB0], xmm12
0000794c94dd9334  vmovaps [rsp+0xC0], xmm13
0000794c94dd933d  vmovaps [rsp+0xD0], xmm14
0000794c94dd9346  vmovaps [rsp+0xE0], xmm15
0000794c94dd934f  sub rsp, 0x30
0000794c94dd9353  movaps [rsp], xmm6
0000794c94dd9357  movaps [rsp+0x10], xmm10
0000794c94dd935d  movaps [rsp+0x20], xmm8
0000794c94dd9363  lea rdi, [rsp]
0000794c94dd9367  mov esi, 0x00
0000794c94dd936c  mov rax, 0x5AB2B8B81530
0000794c94dd9376  call rax
0000794c94dd9378  movaps xmm6, [rsp]
0000794c94dd937c  add rsp, 0x30
0000794c94dd9380  vmovaps xmm0, [rsp]
0000794c94dd9385  vmovaps xmm1, [rsp+0x10]
0000794c94dd938b  vmovaps xmm2, [rsp+0x20]
0000794c94dd9391  vmovaps xmm3, [rsp+0x30]
0000794c94dd9397  vmovaps xmm4, [rsp+0x40]
0000794c94dd939d  vmovaps xmm5, [rsp+0x50]
0000794c94dd93a3  vmovaps xmm7, [rsp+0x60]
0000794c94dd93a9  vmovaps xmm8, [rsp+0x70]
0000794c94dd93af  vmovaps xmm9, [rsp+0x80]
0000794c94dd93b8  vmovaps xmm10, [rsp+0x90]
0000794c94dd93c1  vmovaps xmm11, [rsp+0xA0]
0000794c94dd93ca  vmovaps xmm12, [rsp+0xB0]
0000794c94dd93d3  vmovaps xmm13, [rsp+0xC0]
0000794c94dd93dc  vmovaps xmm14, [rsp+0xD0]
0000794c94dd93e5  vmovaps xmm15, [rsp+0xE0]
0000794c94dd93ee  add rsp, 0xF0
0000794c94dd93f5  pop r11
0000794c94dd93f7  pop r10
0000794c94dd93f9  pop r9
0000794c94dd93fb  pop r8
0000794c94dd93fd  pop rsi
0000794c94dd93fe  pop rdi
0000794c94dd93ff  pop rdx
0000794c94dd9400  pop rcx
0000794c94dd9401  pop rax
0000794c94dd9402  add rsp, 0x08
0000794c94dd9406  jmp 0x0000794C94DD6225
0000794c94dd940b  sub rsp, 0x08
0000794c94dd940f  push rax
0000794c94dd9410  push rcx
0000794c94dd9411  push rdx
0000794c94dd9412  push rdi
0000794c94dd9413  push rsi
0000794c94dd9414  push r8
0000794c94dd9416  push r9
0000794c94dd9418  push r10
0000794c94dd941a  push r11
0000794c94dd941c  sub rsp, 0xF0
0000794c94dd9423  vmovaps [rsp], xmm0
0000794c94dd9428  vmovaps [rsp+0x10], xmm1
0000794c94dd942e  vmovaps [rsp+0x20], xmm2
0000794c94dd9434  vmovaps [rsp+0x30], xmm3
0000794c94dd943a  vmovaps [rsp+0x40], xmm4
0000794c94dd9440  vmovaps [rsp+0x50], xmm5
0000794c94dd9446  vmovaps [rsp+0x60], xmm6
0000794c94dd944c  vmovaps [rsp+0x70], xmm7
0000794c94dd9452  vmovaps [rsp+0x80], xmm8
0000794c94dd945b  vmovaps [rsp+0x90], xmm9
0000794c94dd9464  vmovaps [rsp+0xA0], xmm11
0000794c94dd946d  vmovaps [rsp+0xB0], xmm12
0000794c94dd9476  vmovaps [rsp+0xC0], xmm13
0000794c94dd947f  vmovaps [rsp+0xD0], xmm14
0000794c94dd9488  vmovaps [rsp+0xE0], xmm15
0000794c94dd9491  sub rsp, 0x30
0000794c94dd9495  movaps [rsp], xmm10
0000794c94dd949a  movaps [rsp+0x10], xmm8
0000794c94dd94a0  movaps [rsp+0x20], xmm14
0000794c94dd94a6  lea rdi, [rsp]
0000794c94dd94aa  mov esi, 0x00
0000794c94dd94af  mov rax, 0x5AB2B8B81530
0000794c94dd94b9  call rax
0000794c94dd94bb  movaps xmm10, [rsp]
0000794c94dd94c0  add rsp, 0x30
0000794c94dd94c4  vmovaps xmm0, [rsp]
0000794c94dd94c9  vmovaps xmm1, [rsp+0x10]
0000794c94dd94cf  vmovaps xmm2, [rsp+0x20]
0000794c94dd94d5  vmovaps xmm3, [rsp+0x30]
0000794c94dd94db  vmovaps xmm4, [rsp+0x40]
0000794c94dd94e1  vmovaps xmm5, [rsp+0x50]
0000794c94dd94e7  vmovaps xmm6, [rsp+0x60]
0000794c94dd94ed  vmovaps xmm7, [rsp+0x70]
0000794c94dd94f3  vmovaps xmm8, [rsp+0x80]
0000794c94dd94fc  vmovaps xmm9, [rsp+0x90]
0000794c94dd9505  vmovaps xmm11, [rsp+0xA0]
0000794c94dd950e  vmovaps xmm12, [rsp+0xB0]
0000794c94dd9517  vmovaps xmm13, [rsp+0xC0]
0000794c94dd9520  vmovaps xmm14, [rsp+0xD0]
0000794c94dd9529  vmovaps xmm15, [rsp+0xE0]
0000794c94dd9532  add rsp, 0xF0
0000794c94dd9539  pop r11
0000794c94dd953b  pop r10
0000794c94dd953d  pop r9
0000794c94dd953f  pop r8
0000794c94dd9541  pop rsi
0000794c94dd9542  pop rdi
0000794c94dd9543  pop rdx
0000794c94dd9544  pop rcx
0000794c94dd9545  pop rax
0000794c94dd9546  add rsp, 0x08
0000794c94dd954a  jmp 0x0000794C94DD6245
0000794c94dd954f  sub rsp, 0x08
0000794c94dd9553  push rax
0000794c94dd9554  push rcx
0000794c94dd9555  push rdx
0000794c94dd9556  push rdi
0000794c94dd9557  push rsi
0000794c94dd9558  push r8
0000794c94dd955a  push r9
0000794c94dd955c  push r10
0000794c94dd955e  push r11
0000794c94dd9560  sub rsp, 0xF0
0000794c94dd9567  vmovaps [rsp], xmm0
0000794c94dd956c  vmovaps [rsp+0x10], xmm1
0000794c94dd9572  vmovaps [rsp+0x20], xmm2
0000794c94dd9578  vmovaps [rsp+0x30], xmm3
0000794c94dd957e  vmovaps [rsp+0x40], xmm4
0000794c94dd9584  vmovaps [rsp+0x50], xmm5
0000794c94dd958a  vmovaps [rsp+0x60], xmm6
0000794c94dd9590  vmovaps [rsp+0x70], xmm7
0000794c94dd9596  vmovaps [rsp+0x80], xmm8
0000794c94dd959f  vmovaps [rsp+0x90], xmm9
0000794c94dd95a8  vmovaps [rsp+0xA0], xmm10
0000794c94dd95b1  vmovaps [rsp+0xB0], xmm11
0000794c94dd95ba  vmovaps [rsp+0xC0], xmm12
0000794c94dd95c3  vmovaps [rsp+0xD0], xmm13
0000794c94dd95cc  vmovaps [rsp+0xE0], xmm15
0000794c94dd95d5  sub rsp, 0x30
0000794c94dd95d9  movaps [rsp], xmm14
0000794c94dd95de  movaps [rsp+0x10], xmm8
0000794c94dd95e4  movaps [rsp+0x20], xmm4
0000794c94dd95e9  lea rdi, [rsp]
0000794c94dd95ed  mov esi, 0x00
0000794c94dd95f2  mov rax, 0x5AB2B8B81530
0000794c94dd95fc  call rax
0000794c94dd95fe  movaps xmm14, [rsp]
0000794c94dd9603  add rsp, 0x30
0000794c94dd9607  vmovaps xmm0, [rsp]
0000794c94dd960c  vmovaps xmm1, [rsp+0x10]
0000794c94dd9612  vmovaps xmm2, [rsp+0x20]
0000794c94dd9618  vmovaps xmm3, [rsp+0x30]
0000794c94dd961e  vmovaps xmm4, [rsp+0x40]
0000794c94dd9624  vmovaps xmm5, [rsp+0x50]
0000794c94dd962a  vmovaps xmm6, [rsp+0x60]
0000794c94dd9630  vmovaps xmm7, [rsp+0x70]
0000794c94dd9636  vmovaps xmm8, [rsp+0x80]
0000794c94dd963f  vmovaps xmm9, [rsp+0x90]
0000794c94dd9648  vmovaps xmm10, [rsp+0xA0]
0000794c94dd9651  vmovaps xmm11, [rsp+0xB0]
0000794c94dd965a  vmovaps xmm12, [rsp+0xC0]
0000794c94dd9663  vmovaps xmm13, [rsp+0xD0]
0000794c94dd966c  vmovaps xmm15, [rsp+0xE0]
0000794c94dd9675  add rsp, 0xF0
0000794c94dd967c  pop r11
0000794c94dd967e  pop r10
0000794c94dd9680  pop r9
0000794c94dd9682  pop r8
0000794c94dd9684  pop rsi
0000794c94dd9685  pop rdi
0000794c94dd9686  pop rdx
0000794c94dd9687  pop rcx
0000794c94dd9688  pop rax
0000794c94dd9689  add rsp, 0x08
0000794c94dd968d  jmp 0x0000794C94DD6265
0000794c94dd9692  sub rsp, 0x08
0000794c94dd9696  push rax
0000794c94dd9697  push rcx
0000794c94dd9698  push rdx
0000794c94dd9699  push rdi
0000794c94dd969a  push rsi
0000794c94dd969b  push r8
0000794c94dd969d  push r9
0000794c94dd969f  push r10
0000794c94dd96a1  push r11
0000794c94dd96a3  sub rsp, 0xF0
0000794c94dd96aa  vmovaps [rsp], xmm0
0000794c94dd96af  vmovaps [rsp+0x10], xmm1
0000794c94dd96b5  vmovaps [rsp+0x20], xmm2
0000794c94dd96bb  vmovaps [rsp+0x30], xmm3
0000794c94dd96c1  vmovaps [rsp+0x40], xmm5
0000794c94dd96c7  vmovaps [rsp+0x50], xmm6
0000794c94dd96cd  vmovaps [rsp+0x60], xmm7
0000794c94dd96d3  vmovaps [rsp+0x70], xmm8
0000794c94dd96d9  vmovaps [rsp+0x80], xmm9
0000794c94dd96e2  vmovaps [rsp+0x90], xmm10
0000794c94dd96eb  vmovaps [rsp+0xA0], xmm11
0000794c94dd96f4  vmovaps [rsp+0xB0], xmm12
0000794c94dd96fd  vmovaps [rsp+0xC0], xmm13
0000794c94dd9706  vmovaps [rsp+0xD0], xmm14
0000794c94dd970f  vmovaps [rsp+0xE0], xmm15
0000794c94dd9718  sub rsp, 0x30
0000794c94dd971c  movaps [rsp], xmm4
0000794c94dd9720  movaps [rsp+0x10], xmm13
0000794c94dd9726  movaps [rsp+0x20], xmm8
0000794c94dd972c  lea rdi, [rsp]
0000794c94dd9730  mov esi, 0x00
0000794c94dd9735  mov rax, 0x5AB2B8B81530
0000794c94dd973f  call rax
0000794c94dd9741  movaps xmm4, [rsp]
0000794c94dd9745  add rsp, 0x30
0000794c94dd9749  vmovaps xmm0, [rsp]
0000794c94dd974e  vmovaps xmm1, [rsp+0x10]
0000794c94dd9754  vmovaps xmm2, [rsp+0x20]
0000794c94dd975a  vmovaps xmm3, [rsp+0x30]
0000794c94dd9760  vmovaps xmm5, [rsp+0x40]
0000794c94dd9766  vmovaps xmm6, [rsp+0x50]
0000794c94dd976c  vmovaps xmm7, [rsp+0x60]
0000794c94dd9772  vmovaps xmm8, [rsp+0x70]
0000794c94dd9778  vmovaps xmm9, [rsp+0x80]
0000794c94dd9781  vmovaps xmm10, [rsp+0x90]
0000794c94dd978a  vmovaps xmm11, [rsp+0xA0]
0000794c94dd9793  vmovaps xmm12, [rsp+0xB0]
0000794c94dd979c  vmovaps xmm13, [rsp+0xC0]
0000794c94dd97a5  vmovaps xmm14, [rsp+0xD0]
0000794c94dd97ae  vmovaps xmm15, [rsp+0xE0]
0000794c94dd97b7  add rsp, 0xF0
0000794c94dd97be  pop r11
0000794c94dd97c0  pop r10
0000794c94dd97c2  pop r9
0000794c94dd97c4  pop r8
0000794c94dd97c6  pop rsi
0000794c94dd97c7  pop rdi
0000794c94dd97c8  pop rdx
0000794c94dd97c9  pop rcx
0000794c94dd97ca  pop rax
0000794c94dd97cb  add rsp, 0x08
0000794c94dd97cf  jmp 0x0000794C94DD628A
0000794c94dd97d4  sub rsp, 0x08
0000794c94dd97d8  push rax
0000794c94dd97d9  push rcx
0000794c94dd97da  push rdx
0000794c94dd97db  push rdi
0000794c94dd97dc  push rsi
0000794c94dd97dd  push r8
0000794c94dd97df  push r9
0000794c94dd97e1  push r10
0000794c94dd97e3  push r11
0000794c94dd97e5  sub rsp, 0xF0
0000794c94dd97ec  vmovaps [rsp], xmm0
0000794c94dd97f1  vmovaps [rsp+0x10], xmm1
0000794c94dd97f7  vmovaps [rsp+0x20], xmm2
0000794c94dd97fd  vmovaps [rsp+0x30], xmm3
0000794c94dd9803  vmovaps [rsp+0x40], xmm4
0000794c94dd9809  vmovaps [rsp+0x50], xmm5
0000794c94dd980f  vmovaps [rsp+0x60], xmm6
0000794c94dd9815  vmovaps [rsp+0x70], xmm7
0000794c94dd981b  vmovaps [rsp+0x80], xmm8
0000794c94dd9824  vmovaps [rsp+0x90], xmm9
0000794c94dd982d  vmovaps [rsp+0xA0], xmm10
0000794c94dd9836  vmovaps [rsp+0xB0], xmm11
0000794c94dd983f  vmovaps [rsp+0xC0], xmm12
0000794c94dd9848  vmovaps [rsp+0xD0], xmm14
0000794c94dd9851  vmovaps [rsp+0xE0], xmm15
0000794c94dd985a  sub rsp, 0x30
0000794c94dd985e  movaps [rsp], xmm13
0000794c94dd9863  movaps [rsp+0x10], xmm15
0000794c94dd9869  movaps [rsp+0x20], xmm9
0000794c94dd986f  lea rdi, [rsp]
0000794c94dd9873  mov esi, 0x00
0000794c94dd9878  mov rax, 0x5AB2B8B81530
0000794c94dd9882  call rax
0000794c94dd9884  movaps xmm13, [rsp]
0000794c94dd9889  add rsp, 0x30
0000794c94dd988d  vmovaps xmm0, [rsp]
0000794c94dd9892  vmovaps xmm1, [rsp+0x10]
0000794c94dd9898  vmovaps xmm2, [rsp+0x20]
0000794c94dd989e  vmovaps xmm3, [rsp+0x30]
0000794c94dd98a4  vmovaps xmm4, [rsp+0x40]
0000794c94dd98aa  vmovaps xmm5, [rsp+0x50]
0000794c94dd98b0  vmovaps xmm6, [rsp+0x60]
0000794c94dd98b6  vmovaps xmm7, [rsp+0x70]
0000794c94dd98bc  vmovaps xmm8, [rsp+0x80]
0000794c94dd98c5  vmovaps xmm9, [rsp+0x90]
0000794c94dd98ce  vmovaps xmm10, [rsp+0xA0]
0000794c94dd98d7  vmovaps xmm11, [rsp+0xB0]
0000794c94dd98e0  vmovaps xmm12, [rsp+0xC0]
0000794c94dd98e9  vmovaps xmm14, [rsp+0xD0]
0000794c94dd98f2  vmovaps xmm15, [rsp+0xE0]
0000794c94dd98fb  add rsp, 0xF0
0000794c94dd9902  pop r11
0000794c94dd9904  pop r10
0000794c94dd9906  pop r9
0000794c94dd9908  pop r8
0000794c94dd990a  pop rsi
0000794c94dd990b  pop rdi
0000794c94dd990c  pop rdx
0000794c94dd990d  pop rcx
0000794c94dd990e  pop rax
0000794c94dd990f  add rsp, 0x08
0000794c94dd9913  jmp 0x0000794C94DD62A5
0000794c94dd9918  sub rsp, 0x08
0000794c94dd991c  push rax
0000794c94dd991d  push rcx
0000794c94dd991e  push rdx
0000794c94dd991f  push rdi
0000794c94dd9920  push rsi
0000794c94dd9921  push r8
0000794c94dd9923  push r9
0000794c94dd9925  push r10
0000794c94dd9927  push r11
0000794c94dd9929  sub rsp, 0xF0
0000794c94dd9930  vmovaps [rsp], xmm0
0000794c94dd9935  vmovaps [rsp+0x10], xmm1
0000794c94dd993b  vmovaps [rsp+0x20], xmm2
0000794c94dd9941  vmovaps [rsp+0x30], xmm3
0000794c94dd9947  vmovaps [rsp+0x40], xmm4
0000794c94dd994d  vmovaps [rsp+0x50], xmm5
0000794c94dd9953  vmovaps [rsp+0x60], xmm6
0000794c94dd9959  vmovaps [rsp+0x70], xmm7
0000794c94dd995f  vmovaps [rsp+0x80], xmm8
0000794c94dd9968  vmovaps [rsp+0x90], xmm9
0000794c94dd9971  vmovaps [rsp+0xA0], xmm10
0000794c94dd997a  vmovaps [rsp+0xB0], xmm11
0000794c94dd9983  vmovaps [rsp+0xC0], xmm12
0000794c94dd998c  vmovaps [rsp+0xD0], xmm13
0000794c94dd9995  vmovaps [rsp+0xE0], xmm14
0000794c94dd999e  sub rsp, 0x30
0000794c94dd99a2  movaps [rsp], xmm15
0000794c94dd99a7  movaps [rsp+0x10], xmm1
0000794c94dd99ac  movaps [rsp+0x20], xmm5
0000794c94dd99b1  lea rdi, [rsp]
0000794c94dd99b5  mov esi, 0x00
0000794c94dd99ba  mov rax, 0x5AB2B8B81530
0000794c94dd99c4  call rax
0000794c94dd99c6  movaps xmm15, [rsp]
0000794c94dd99cb  add rsp, 0x30
0000794c94dd99cf  vmovaps xmm0, [rsp]
0000794c94dd99d4  vmovaps xmm1, [rsp+0x10]
0000794c94dd99da  vmovaps xmm2, [rsp+0x20]
0000794c94dd99e0  vmovaps xmm3, [rsp+0x30]
0000794c94dd99e6  vmovaps xmm4, [rsp+0x40]
0000794c94dd99ec  vmovaps xmm5, [rsp+0x50]
0000794c94dd99f2  vmovaps xmm6, [rsp+0x60]
0000794c94dd99f8  vmovaps xmm7, [rsp+0x70]
0000794c94dd99fe  vmovaps xmm8, [rsp+0x80]
0000794c94dd9a07  vmovaps xmm9, [rsp+0x90]
0000794c94dd9a10  vmovaps xmm10, [rsp+0xA0]
0000794c94dd9a19  vmovaps xmm11, [rsp+0xB0]
0000794c94dd9a22  vmovaps xmm12, [rsp+0xC0]
0000794c94dd9a2b  vmovaps xmm13, [rsp+0xD0]
0000794c94dd9a34  vmovaps xmm14, [rsp+0xE0]
0000794c94dd9a3d  add rsp, 0xF0
0000794c94dd9a44  pop r11
0000794c94dd9a46  pop r10
0000794c94dd9a48  pop r9
0000794c94dd9a4a  pop r8
0000794c94dd9a4c  pop rsi
0000794c94dd9a4d  pop rdi
0000794c94dd9a4e  pop rdx
0000794c94dd9a4f  pop rcx
0000794c94dd9a50  pop rax
0000794c94dd9a51  add rsp, 0x08
0000794c94dd9a55  jmp 0x0000794C94DD62C0
0000794c94dd9a5a  call 0x0000794C94CD64F0
0000794c94dd9a5f  jmp 0x0000794C94DD631B
0000794c94dd9a64  sub rsp, 0x08
0000794c94dd9a68  push rax
0000794c94dd9a69  push rcx
0000794c94dd9a6a  push rdx
0000794c94dd9a6b  push rdi
0000794c94dd9a6c  push rsi
0000794c94dd9a6d  push r8
0000794c94dd9a6f  push r9
0000794c94dd9a71  push r10
0000794c94dd9a73  push r11
0000794c94dd9a75  sub rsp, 0xF0
0000794c94dd9a7c  vmovaps [rsp], xmm0
0000794c94dd9a81  vmovaps [rsp+0x10], xmm1
0000794c94dd9a87  vmovaps [rsp+0x20], xmm2
0000794c94dd9a8d  vmovaps [rsp+0x30], xmm3
0000794c94dd9a93  vmovaps [rsp+0x40], xmm4
0000794c94dd9a99  vmovaps [rsp+0x50], xmm5
0000794c94dd9a9f  vmovaps [rsp+0x60], xmm6
0000794c94dd9aa5  vmovaps [rsp+0x70], xmm7
0000794c94dd9aab  vmovaps [rsp+0x80], xmm8
0000794c94dd9ab4  vmovaps [rsp+0x90], xmm10
0000794c94dd9abd  vmovaps [rsp+0xA0], xmm11
0000794c94dd9ac6  vmovaps [rsp+0xB0], xmm12
0000794c94dd9acf  vmovaps [rsp+0xC0], xmm13
0000794c94dd9ad8  vmovaps [rsp+0xD0], xmm14
0000794c94dd9ae1  vmovaps [rsp+0xE0], xmm15
0000794c94dd9aea  sub rsp, 0x30
0000794c94dd9aee  movaps [rsp], xmm9
0000794c94dd9af3  movaps [rsp+0x10], xmm8
0000794c94dd9af9  movaps [rsp+0x20], xmm11
0000794c94dd9aff  lea rdi, [rsp]
0000794c94dd9b03  mov esi, 0x00
0000794c94dd9b08  mov rax, 0x5AB2B8B81530
0000794c94dd9b12  call rax
0000794c94dd9b14  movaps xmm9, [rsp]
0000794c94dd9b19  add rsp, 0x30
0000794c94dd9b1d  vmovaps xmm0, [rsp]
0000794c94dd9b22  vmovaps xmm1, [rsp+0x10]
0000794c94dd9b28  vmovaps xmm2, [rsp+0x20]
0000794c94dd9b2e  vmovaps xmm3, [rsp+0x30]
0000794c94dd9b34  vmovaps xmm4, [rsp+0x40]
0000794c94dd9b3a  vmovaps xmm5, [rsp+0x50]
0000794c94dd9b40  vmovaps xmm6, [rsp+0x60]
0000794c94dd9b46  vmovaps xmm7, [rsp+0x70]
0000794c94dd9b4c  vmovaps xmm8, [rsp+0x80]
0000794c94dd9b55  vmovaps xmm10, [rsp+0x90]
0000794c94dd9b5e  vmovaps xmm11, [rsp+0xA0]
0000794c94dd9b67  vmovaps xmm12, [rsp+0xB0]
0000794c94dd9b70  vmovaps xmm13, [rsp+0xC0]
0000794c94dd9b79  vmovaps xmm14, [rsp+0xD0]
0000794c94dd9b82  vmovaps xmm15, [rsp+0xE0]
0000794c94dd9b8b  add rsp, 0xF0
0000794c94dd9b92  pop r11
0000794c94dd9b94  pop r10
0000794c94dd9b96  pop r9
0000794c94dd9b98  pop r8
0000794c94dd9b9a  pop rsi
0000794c94dd9b9b  pop rdi
0000794c94dd9b9c  pop rdx
0000794c94dd9b9d  pop rcx
0000794c94dd9b9e  pop rax
0000794c94dd9b9f  add rsp, 0x08
0000794c94dd9ba3  jmp 0x0000794C94DD6352
0000794c94dd9ba8  sub rsp, 0x08
0000794c94dd9bac  push rax
0000794c94dd9bad  push rcx
0000794c94dd9bae  push rdx
0000794c94dd9baf  push rdi
0000794c94dd9bb0  push rsi
0000794c94dd9bb1  push r8
0000794c94dd9bb3  push r9
0000794c94dd9bb5  push r10
0000794c94dd9bb7  push r11
0000794c94dd9bb9  sub rsp, 0xF0
0000794c94dd9bc0  vmovaps [rsp], xmm0
0000794c94dd9bc5  vmovaps [rsp+0x10], xmm1
0000794c94dd9bcb  vmovaps [rsp+0x20], xmm2
0000794c94dd9bd1  vmovaps [rsp+0x30], xmm3
0000794c94dd9bd7  vmovaps [rsp+0x40], xmm4
0000794c94dd9bdd  vmovaps [rsp+0x50], xmm5
0000794c94dd9be3  vmovaps [rsp+0x60], xmm6
0000794c94dd9be9  vmovaps [rsp+0x70], xmm7
0000794c94dd9bef  vmovaps [rsp+0x80], xmm8
0000794c94dd9bf8  vmovaps [rsp+0x90], xmm9
0000794c94dd9c01  vmovaps [rsp+0xA0], xmm10
0000794c94dd9c0a  vmovaps [rsp+0xB0], xmm12
0000794c94dd9c13  vmovaps [rsp+0xC0], xmm13
0000794c94dd9c1c  vmovaps [rsp+0xD0], xmm14
0000794c94dd9c25  vmovaps [rsp+0xE0], xmm15
0000794c94dd9c2e  sub rsp, 0x30
0000794c94dd9c32  movaps [rsp], xmm11
0000794c94dd9c37  movaps [rsp+0x10], xmm10
0000794c94dd9c3d  movaps [rsp+0x20], xmm6
0000794c94dd9c42  lea rdi, [rsp]
0000794c94dd9c46  mov esi, 0x00
0000794c94dd9c4b  mov rax, 0x5AB2B8B81530
0000794c94dd9c55  call rax
0000794c94dd9c57  movaps xmm11, [rsp]
0000794c94dd9c5c  add rsp, 0x30
0000794c94dd9c60  vmovaps xmm0, [rsp]
0000794c94dd9c65  vmovaps xmm1, [rsp+0x10]
0000794c94dd9c6b  vmovaps xmm2, [rsp+0x20]
0000794c94dd9c71  vmovaps xmm3, [rsp+0x30]
0000794c94dd9c77  vmovaps xmm4, [rsp+0x40]
0000794c94dd9c7d  vmovaps xmm5, [rsp+0x50]
0000794c94dd9c83  vmovaps xmm6, [rsp+0x60]
0000794c94dd9c89  vmovaps xmm7, [rsp+0x70]
0000794c94dd9c8f  vmovaps xmm8, [rsp+0x80]
0000794c94dd9c98  vmovaps xmm9, [rsp+0x90]
0000794c94dd9ca1  vmovaps xmm10, [rsp+0xA0]
0000794c94dd9caa  vmovaps xmm12, [rsp+0xB0]
0000794c94dd9cb3  vmovaps xmm13, [rsp+0xC0]
0000794c94dd9cbc  vmovaps xmm14, [rsp+0xD0]
0000794c94dd9cc5  vmovaps xmm15, [rsp+0xE0]
0000794c94dd9cce  add rsp, 0xF0
0000794c94dd9cd5  pop r11
0000794c94dd9cd7  pop r10
0000794c94dd9cd9  pop r9
0000794c94dd9cdb  pop r8
0000794c94dd9cdd  pop rsi
0000794c94dd9cde  pop rdi
0000794c94dd9cdf  pop rdx
0000794c94dd9ce0  pop rcx
0000794c94dd9ce1  pop rax
0000794c94dd9ce2  add rsp, 0x08
0000794c94dd9ce6  jmp 0x0000794C94DD636D
0000794c94dd9ceb  sub rsp, 0x08
0000794c94dd9cef  push rax
0000794c94dd9cf0  push rcx
0000794c94dd9cf1  push rdx
0000794c94dd9cf2  push rdi
0000794c94dd9cf3  push rsi
0000794c94dd9cf4  push r8
0000794c94dd9cf6  push r9
0000794c94dd9cf8  push r10
0000794c94dd9cfa  push r11
0000794c94dd9cfc  sub rsp, 0xF0
0000794c94dd9d03  vmovaps [rsp], xmm0
0000794c94dd9d08  vmovaps [rsp+0x10], xmm1
0000794c94dd9d0e  vmovaps [rsp+0x20], xmm2
0000794c94dd9d14  vmovaps [rsp+0x30], xmm3
0000794c94dd9d1a  vmovaps [rsp+0x40], xmm4
0000794c94dd9d20  vmovaps [rsp+0x50], xmm5
0000794c94dd9d26  vmovaps [rsp+0x60], xmm6
0000794c94dd9d2c  vmovaps [rsp+0x70], xmm7
0000794c94dd9d32  vmovaps [rsp+0x80], xmm8
0000794c94dd9d3b  vmovaps [rsp+0x90], xmm9
0000794c94dd9d44  vmovaps [rsp+0xA0], xmm11
0000794c94dd9d4d  vmovaps [rsp+0xB0], xmm12
0000794c94dd9d56  vmovaps [rsp+0xC0], xmm13
0000794c94dd9d5f  vmovaps [rsp+0xD0], xmm14
0000794c94dd9d68  vmovaps [rsp+0xE0], xmm15
0000794c94dd9d71  sub rsp, 0x30
0000794c94dd9d75  movaps [rsp], xmm10
0000794c94dd9d7a  movaps [rsp+0x10], xmm14
0000794c94dd9d80  movaps [rsp+0x20], xmm4
0000794c94dd9d85  lea rdi, [rsp]
0000794c94dd9d89  mov esi, 0x00
0000794c94dd9d8e  mov rax, 0x5AB2B8B81530
0000794c94dd9d98  call rax
0000794c94dd9d9a  movaps xmm10, [rsp]
0000794c94dd9d9f  add rsp, 0x30
0000794c94dd9da3  vmovaps xmm0, [rsp]
0000794c94dd9da8  vmovaps xmm1, [rsp+0x10]
0000794c94dd9dae  vmovaps xmm2, [rsp+0x20]
0000794c94dd9db4  vmovaps xmm3, [rsp+0x30]
0000794c94dd9dba  vmovaps xmm4, [rsp+0x40]
0000794c94dd9dc0  vmovaps xmm5, [rsp+0x50]
0000794c94dd9dc6  vmovaps xmm6, [rsp+0x60]
0000794c94dd9dcc  vmovaps xmm7, [rsp+0x70]
0000794c94dd9dd2  vmovaps xmm8, [rsp+0x80]
0000794c94dd9ddb  vmovaps xmm9, [rsp+0x90]
0000794c94dd9de4  vmovaps xmm11, [rsp+0xA0]
0000794c94dd9ded  vmovaps xmm12, [rsp+0xB0]
0000794c94dd9df6  vmovaps xmm13, [rsp+0xC0]
0000794c94dd9dff  vmovaps xmm14, [rsp+0xD0]
0000794c94dd9e08  vmovaps xmm15, [rsp+0xE0]
0000794c94dd9e11  add rsp, 0xF0
0000794c94dd9e18  pop r11
0000794c94dd9e1a  pop r10
0000794c94dd9e1c  pop r9
0000794c94dd9e1e  pop r8
0000794c94dd9e20  pop rsi
0000794c94dd9e21  pop rdi
0000794c94dd9e22  pop rdx
0000794c94dd9e23  pop rcx
0000794c94dd9e24  pop rax
0000794c94dd9e25  add rsp, 0x08
0000794c94dd9e29  jmp 0x0000794C94DD6388
0000794c94dd9e2e  sub rsp, 0x08
0000794c94dd9e32  push rax
0000794c94dd9e33  push rcx
0000794c94dd9e34  push rdx
0000794c94dd9e35  push rdi
0000794c94dd9e36  push rsi
0000794c94dd9e37  push r8
0000794c94dd9e39  push r9
0000794c94dd9e3b  push r10
0000794c94dd9e3d  push r11
0000794c94dd9e3f  sub rsp, 0xF0
0000794c94dd9e46  vmovaps [rsp], xmm0
0000794c94dd9e4b  vmovaps [rsp+0x10], xmm1
0000794c94dd9e51  vmovaps [rsp+0x20], xmm2
0000794c94dd9e57  vmovaps [rsp+0x30], xmm3
0000794c94dd9e5d  vmovaps [rsp+0x40], xmm4
0000794c94dd9e63  vmovaps [rsp+0x50], xmm5
0000794c94dd9e69  vmovaps [rsp+0x60], xmm6
0000794c94dd9e6f  vmovaps [rsp+0x70], xmm7
0000794c94dd9e75  vmovaps [rsp+0x80], xmm9
0000794c94dd9e7e  vmovaps [rsp+0x90], xmm10
0000794c94dd9e87  vmovaps [rsp+0xA0], xmm11
0000794c94dd9e90  vmovaps [rsp+0xB0], xmm12
0000794c94dd9e99  vmovaps [rsp+0xC0], xmm13
0000794c94dd9ea2  vmovaps [rsp+0xD0], xmm14
0000794c94dd9eab  vmovaps [rsp+0xE0], xmm15
0000794c94dd9eb4  sub rsp, 0x30
0000794c94dd9eb8  movaps [rsp], xmm8
0000794c94dd9ebd  movaps [rsp+0x10], xmm1
0000794c94dd9ec2  movaps [rsp+0x20], xmm14
0000794c94dd9ec8  lea rdi, [rsp]
0000794c94dd9ecc  mov esi, 0x00
0000794c94dd9ed1  mov rax, 0x5AB2B8B81530
0000794c94dd9edb  call rax
0000794c94dd9edd  movaps xmm8, [rsp]
0000794c94dd9ee2  add rsp, 0x30
0000794c94dd9ee6  vmovaps xmm0, [rsp]
0000794c94dd9eeb  vmovaps xmm1, [rsp+0x10]
0000794c94dd9ef1  vmovaps xmm2, [rsp+0x20]
0000794c94dd9ef7  vmovaps xmm3, [rsp+0x30]
0000794c94dd9efd  vmovaps xmm4, [rsp+0x40]
0000794c94dd9f03  vmovaps xmm5, [rsp+0x50]
0000794c94dd9f09  vmovaps xmm6, [rsp+0x60]
0000794c94dd9f0f  vmovaps xmm7, [rsp+0x70]
0000794c94dd9f15  vmovaps xmm9, [rsp+0x80]
0000794c94dd9f1e  vmovaps xmm10, [rsp+0x90]
0000794c94dd9f27  vmovaps xmm11, [rsp+0xA0]
0000794c94dd9f30  vmovaps xmm12, [rsp+0xB0]
0000794c94dd9f39  vmovaps xmm13, [rsp+0xC0]
0000794c94dd9f42  vmovaps xmm14, [rsp+0xD0]
0000794c94dd9f4b  vmovaps xmm15, [rsp+0xE0]
0000794c94dd9f54  add rsp, 0xF0
0000794c94dd9f5b  pop r11
0000794c94dd9f5d  pop r10
0000794c94dd9f5f  pop r9
0000794c94dd9f61  pop r8
0000794c94dd9f63  pop rsi
0000794c94dd9f64  pop rdi
0000794c94dd9f65  pop rdx
0000794c94dd9f66  pop rcx
0000794c94dd9f67  pop rax
0000794c94dd9f68  add rsp, 0x08
0000794c94dd9f6c  jmp 0x0000794C94DD63AE
0000794c94dd9f71  sub rsp, 0x08
0000794c94dd9f75  push rax
0000794c94dd9f76  push rcx
0000794c94dd9f77  push rdx
0000794c94dd9f78  push rdi
0000794c94dd9f79  push rsi
0000794c94dd9f7a  push r8
0000794c94dd9f7c  push r9
0000794c94dd9f7e  push r10
0000794c94dd9f80  push r11
0000794c94dd9f82  sub rsp, 0xF0
0000794c94dd9f89  vmovaps [rsp], xmm0
0000794c94dd9f8e  vmovaps [rsp+0x10], xmm1
0000794c94dd9f94  vmovaps [rsp+0x20], xmm2
0000794c94dd9f9a  vmovaps [rsp+0x30], xmm3
0000794c94dd9fa0  vmovaps [rsp+0x40], xmm4
0000794c94dd9fa6  vmovaps [rsp+0x50], xmm5
0000794c94dd9fac  vmovaps [rsp+0x60], xmm7
0000794c94dd9fb2  vmovaps [rsp+0x70], xmm8
0000794c94dd9fb8  vmovaps [rsp+0x80], xmm9
0000794c94dd9fc1  vmovaps [rsp+0x90], xmm10
0000794c94dd9fca  vmovaps [rsp+0xA0], xmm11
0000794c94dd9fd3  vmovaps [rsp+0xB0], xmm12
0000794c94dd9fdc  vmovaps [rsp+0xC0], xmm13
0000794c94dd9fe5  vmovaps [rsp+0xD0], xmm14
0000794c94dd9fee  vmovaps [rsp+0xE0], xmm15
0000794c94dd9ff7  sub rsp, 0x30
0000794c94dd9ffb  movaps [rsp], xmm6
0000794c94dd9fff  movaps [rsp+0x10], xmm1
0000794c94dda004  movaps [rsp+0x20], xmm14
0000794c94dda00a  lea rdi, [rsp]
0000794c94dda00e  mov esi, 0x00
0000794c94dda013  mov rax, 0x5AB2B8B81530
0000794c94dda01d  call rax
0000794c94dda01f  movaps xmm6, [rsp]
0000794c94dda023  add rsp, 0x30
0000794c94dda027  vmovaps xmm0, [rsp]
0000794c94dda02c  vmovaps xmm1, [rsp+0x10]
0000794c94dda032  vmovaps xmm2, [rsp+0x20]
0000794c94dda038  vmovaps xmm3, [rsp+0x30]
0000794c94dda03e  vmovaps xmm4, [rsp+0x40]
0000794c94dda044  vmovaps xmm5, [rsp+0x50]
0000794c94dda04a  vmovaps xmm7, [rsp+0x60]
0000794c94dda050  vmovaps xmm8, [rsp+0x70]
0000794c94dda056  vmovaps xmm9, [rsp+0x80]
0000794c94dda05f  vmovaps xmm10, [rsp+0x90]
0000794c94dda068  vmovaps xmm11, [rsp+0xA0]
0000794c94dda071  vmovaps xmm12, [rsp+0xB0]
0000794c94dda07a  vmovaps xmm13, [rsp+0xC0]
0000794c94dda083  vmovaps xmm14, [rsp+0xD0]
0000794c94dda08c  vmovaps xmm15, [rsp+0xE0]
0000794c94dda095  add rsp, 0xF0
0000794c94dda09c  pop r11
0000794c94dda09e  pop r10
0000794c94dda0a0  pop r9
0000794c94dda0a2  pop r8
0000794c94dda0a4  pop rsi
0000794c94dda0a5  pop rdi
0000794c94dda0a6  pop rdx
0000794c94dda0a7  pop rcx
0000794c94dda0a8  pop rax
0000794c94dda0a9  add rsp, 0x08
0000794c94dda0ad  jmp 0x0000794C94DD63DA
0000794c94dda0b2  sub rsp, 0x08
0000794c94dda0b6  push rax
0000794c94dda0b7  push rcx
0000794c94dda0b8  push rdx
0000794c94dda0b9  push rdi
0000794c94dda0ba  push rsi
0000794c94dda0bb  push r8
0000794c94dda0bd  push r9
0000794c94dda0bf  push r10
0000794c94dda0c1  push r11
0000794c94dda0c3  sub rsp, 0xF0
0000794c94dda0ca  vmovaps [rsp], xmm0
0000794c94dda0cf  vmovaps [rsp+0x10], xmm1
0000794c94dda0d5  vmovaps [rsp+0x20], xmm2
0000794c94dda0db  vmovaps [rsp+0x30], xmm3
0000794c94dda0e1  vmovaps [rsp+0x40], xmm4
0000794c94dda0e7  vmovaps [rsp+0x50], xmm5
0000794c94dda0ed  vmovaps [rsp+0x60], xmm6
0000794c94dda0f3  vmovaps [rsp+0x70], xmm7
0000794c94dda0f9  vmovaps [rsp+0x80], xmm8
0000794c94dda102  vmovaps [rsp+0x90], xmm9
0000794c94dda10b  vmovaps [rsp+0xA0], xmm10
0000794c94dda114  vmovaps [rsp+0xB0], xmm11
0000794c94dda11d  vmovaps [rsp+0xC0], xmm12
0000794c94dda126  vmovaps [rsp+0xD0], xmm13
0000794c94dda12f  vmovaps [rsp+0xE0], xmm15
0000794c94dda138  sub rsp, 0x30
0000794c94dda13c  movaps [rsp], xmm14
0000794c94dda141  movaps [rsp+0x10], xmm12
0000794c94dda147  movaps [rsp+0x20], xmm1
0000794c94dda14c  lea rdi, [rsp]
0000794c94dda150  mov esi, 0x00
0000794c94dda155  mov rax, 0x5AB2B8B81530
0000794c94dda15f  call rax
0000794c94dda161  movaps xmm14, [rsp]
0000794c94dda166  add rsp, 0x30
0000794c94dda16a  vmovaps xmm0, [rsp]
0000794c94dda16f  vmovaps xmm1, [rsp+0x10]
0000794c94dda175  vmovaps xmm2, [rsp+0x20]
0000794c94dda17b  vmovaps xmm3, [rsp+0x30]
0000794c94dda181  vmovaps xmm4, [rsp+0x40]
0000794c94dda187  vmovaps xmm5, [rsp+0x50]
0000794c94dda18d  vmovaps xmm6, [rsp+0x60]
0000794c94dda193  vmovaps xmm7, [rsp+0x70]
0000794c94dda199  vmovaps xmm8, [rsp+0x80]
0000794c94dda1a2  vmovaps xmm9, [rsp+0x90]
0000794c94dda1ab  vmovaps xmm10, [rsp+0xA0]
0000794c94dda1b4  vmovaps xmm11, [rsp+0xB0]
0000794c94dda1bd  vmovaps xmm12, [rsp+0xC0]
0000794c94dda1c6  vmovaps xmm13, [rsp+0xD0]
0000794c94dda1cf  vmovaps xmm15, [rsp+0xE0]
0000794c94dda1d8  add rsp, 0xF0
0000794c94dda1df  pop r11
0000794c94dda1e1  pop r10
0000794c94dda1e3  pop r9
0000794c94dda1e5  pop r8
0000794c94dda1e7  pop rsi
0000794c94dda1e8  pop rdi
0000794c94dda1e9  pop rdx
0000794c94dda1ea  pop rcx
0000794c94dda1eb  pop rax
0000794c94dda1ec  add rsp, 0x08
0000794c94dda1f0  jmp 0x0000794C94DD6400
0000794c94dda1f5  sub rsp, 0x08
0000794c94dda1f9  push rax
0000794c94dda1fa  push rcx
0000794c94dda1fb  push rdx
0000794c94dda1fc  push rdi
0000794c94dda1fd  push rsi
0000794c94dda1fe  push r8
0000794c94dda200  push r9
0000794c94dda202  push r10
0000794c94dda204  push r11
0000794c94dda206  sub rsp, 0xF0
0000794c94dda20d  vmovaps [rsp], xmm0
0000794c94dda212  vmovaps [rsp+0x10], xmm2
0000794c94dda218  vmovaps [rsp+0x20], xmm3
0000794c94dda21e  vmovaps [rsp+0x30], xmm4
0000794c94dda224  vmovaps [rsp+0x40], xmm5
0000794c94dda22a  vmovaps [rsp+0x50], xmm6
0000794c94dda230  vmovaps [rsp+0x60], xmm7
0000794c94dda236  vmovaps [rsp+0x70], xmm8
0000794c94dda23c  vmovaps [rsp+0x80], xmm9
0000794c94dda245  vmovaps [rsp+0x90], xmm10
0000794c94dda24e  vmovaps [rsp+0xA0], xmm11
0000794c94dda257  vmovaps [rsp+0xB0], xmm12
0000794c94dda260  vmovaps [rsp+0xC0], xmm13
0000794c94dda269  vmovaps [rsp+0xD0], xmm14
0000794c94dda272  vmovaps [rsp+0xE0], xmm15
0000794c94dda27b  sub rsp, 0x30
0000794c94dda27f  movaps [rsp], xmm1
0000794c94dda283  movaps [rsp+0x10], xmm13
0000794c94dda289  movaps [rsp+0x20], xmm9
0000794c94dda28f  lea rdi, [rsp]
0000794c94dda293  mov esi, 0x00
0000794c94dda298  mov rax, 0x5AB2B8B81530
0000794c94dda2a2  call rax
0000794c94dda2a4  movaps xmm1, [rsp]
0000794c94dda2a8  add rsp, 0x30
0000794c94dda2ac  vmovaps xmm0, [rsp]
0000794c94dda2b1  vmovaps xmm2, [rsp+0x10]
0000794c94dda2b7  vmovaps xmm3, [rsp+0x20]
0000794c94dda2bd  vmovaps xmm4, [rsp+0x30]
0000794c94dda2c3  vmovaps xmm5, [rsp+0x40]
0000794c94dda2c9  vmovaps xmm6, [rsp+0x50]
0000794c94dda2cf  vmovaps xmm7, [rsp+0x60]
0000794c94dda2d5  vmovaps xmm8, [rsp+0x70]
0000794c94dda2db  vmovaps xmm9, [rsp+0x80]
0000794c94dda2e4  vmovaps xmm10, [rsp+0x90]
0000794c94dda2ed  vmovaps xmm11, [rsp+0xA0]
0000794c94dda2f6  vmovaps xmm12, [rsp+0xB0]
0000794c94dda2ff  vmovaps xmm13, [rsp+0xC0]
0000794c94dda308  vmovaps xmm14, [rsp+0xD0]
0000794c94dda311  vmovaps xmm15, [rsp+0xE0]
0000794c94dda31a  add rsp, 0xF0
0000794c94dda321  pop r11
0000794c94dda323  pop r10
0000794c94dda325  pop r9
0000794c94dda327  pop r8
0000794c94dda329  pop rsi
0000794c94dda32a  pop rdi
0000794c94dda32b  pop rdx
0000794c94dda32c  pop rcx
0000794c94dda32d  pop rax
0000794c94dda32e  add rsp, 0x08
0000794c94dda332  jmp 0x0000794C94DD641A
0000794c94dda337  sub rsp, 0x08
0000794c94dda33b  push rax
0000794c94dda33c  push rcx
0000794c94dda33d  push rdx
0000794c94dda33e  push rdi
0000794c94dda33f  push rsi
0000794c94dda340  push r8
0000794c94dda342  push r9
0000794c94dda344  push r10
0000794c94dda346  push r11
0000794c94dda348  sub rsp, 0xF0
0000794c94dda34f  vmovaps [rsp], xmm0
0000794c94dda354  vmovaps [rsp+0x10], xmm1
0000794c94dda35a  vmovaps [rsp+0x20], xmm2
0000794c94dda360  vmovaps [rsp+0x30], xmm3
0000794c94dda366  vmovaps [rsp+0x40], xmm4
0000794c94dda36c  vmovaps [rsp+0x50], xmm5
0000794c94dda372  vmovaps [rsp+0x60], xmm6
0000794c94dda378  vmovaps [rsp+0x70], xmm7
0000794c94dda37e  vmovaps [rsp+0x80], xmm8
0000794c94dda387  vmovaps [rsp+0x90], xmm9
0000794c94dda390  vmovaps [rsp+0xA0], xmm10
0000794c94dda399  vmovaps [rsp+0xB0], xmm11
0000794c94dda3a2  vmovaps [rsp+0xC0], xmm13
0000794c94dda3ab  vmovaps [rsp+0xD0], xmm14
0000794c94dda3b4  vmovaps [rsp+0xE0], xmm15
0000794c94dda3bd  sub rsp, 0x30
0000794c94dda3c1  movaps [rsp], xmm12
0000794c94dda3c6  movaps [rsp+0x10], xmm7
0000794c94dda3cb  movaps [rsp+0x20], xmm13
0000794c94dda3d1  lea rdi, [rsp]
0000794c94dda3d5  mov esi, 0x00
0000794c94dda3da  mov rax, 0x5AB2B8B81530
0000794c94dda3e4  call rax
0000794c94dda3e6  movaps xmm12, [rsp]
0000794c94dda3eb  add rsp, 0x30
0000794c94dda3ef  vmovaps xmm0, [rsp]
0000794c94dda3f4  vmovaps xmm1, [rsp+0x10]
0000794c94dda3fa  vmovaps xmm2, [rsp+0x20]
0000794c94dda400  vmovaps xmm3, [rsp+0x30]
0000794c94dda406  vmovaps xmm4, [rsp+0x40]
0000794c94dda40c  vmovaps xmm5, [rsp+0x50]
0000794c94dda412  vmovaps xmm6, [rsp+0x60]
0000794c94dda418  vmovaps xmm7, [rsp+0x70]
0000794c94dda41e  vmovaps xmm8, [rsp+0x80]
0000794c94dda427  vmovaps xmm9, [rsp+0x90]
0000794c94dda430  vmovaps xmm10, [rsp+0xA0]
0000794c94dda439  vmovaps xmm11, [rsp+0xB0]
0000794c94dda442  vmovaps xmm13, [rsp+0xC0]
0000794c94dda44b  vmovaps xmm14, [rsp+0xD0]
0000794c94dda454  vmovaps xmm15, [rsp+0xE0]
0000794c94dda45d  add rsp, 0xF0
0000794c94dda464  pop r11
0000794c94dda466  pop r10
0000794c94dda468  pop r9
0000794c94dda46a  pop r8
0000794c94dda46c  pop rsi
0000794c94dda46d  pop rdi
0000794c94dda46e  pop rdx
0000794c94dda46f  pop rcx
0000794c94dda470  pop rax
0000794c94dda471  add rsp, 0x08
0000794c94dda475  jmp 0x0000794C94DD6441
0000794c94dda47a  sub rsp, 0x08
0000794c94dda47e  push rax
0000794c94dda47f  push rcx
0000794c94dda480  push rdx
0000794c94dda481  push rdi
0000794c94dda482  push rsi
0000794c94dda483  push r8
0000794c94dda485  push r9
0000794c94dda487  push r10
0000794c94dda489  push r11
0000794c94dda48b  sub rsp, 0xF0
0000794c94dda492  vmovaps [rsp], xmm0
0000794c94dda497  vmovaps [rsp+0x10], xmm1
0000794c94dda49d  vmovaps [rsp+0x20], xmm2
0000794c94dda4a3  vmovaps [rsp+0x30], xmm3
0000794c94dda4a9  vmovaps [rsp+0x40], xmm4
0000794c94dda4af  vmovaps [rsp+0x50], xmm5
0000794c94dda4b5  vmovaps [rsp+0x60], xmm6
0000794c94dda4bb  vmovaps [rsp+0x70], xmm7
0000794c94dda4c1  vmovaps [rsp+0x80], xmm8
0000794c94dda4ca  vmovaps [rsp+0x90], xmm9
0000794c94dda4d3  vmovaps [rsp+0xA0], xmm10
0000794c94dda4dc  vmovaps [rsp+0xB0], xmm11
0000794c94dda4e5  vmovaps [rsp+0xC0], xmm12
0000794c94dda4ee  vmovaps [rsp+0xD0], xmm14
0000794c94dda4f7  vmovaps [rsp+0xE0], xmm15
0000794c94dda500  sub rsp, 0x30
0000794c94dda504  movaps [rsp], xmm13
0000794c94dda509  movaps [rsp+0x10], xmm15
0000794c94dda50f  movaps [rsp+0x20], xmm8
0000794c94dda515  lea rdi, [rsp]
0000794c94dda519  mov esi, 0x00
0000794c94dda51e  mov rax, 0x5AB2B8B81530
0000794c94dda528  call rax
0000794c94dda52a  movaps xmm13, [rsp]
0000794c94dda52f  add rsp, 0x30
0000794c94dda533  vmovaps xmm0, [rsp]
0000794c94dda538  vmovaps xmm1, [rsp+0x10]
0000794c94dda53e  vmovaps xmm2, [rsp+0x20]
0000794c94dda544  vmovaps xmm3, [rsp+0x30]
0000794c94dda54a  vmovaps xmm4, [rsp+0x40]
0000794c94dda550  vmovaps xmm5, [rsp+0x50]
0000794c94dda556  vmovaps xmm6, [rsp+0x60]
0000794c94dda55c  vmovaps xmm7, [rsp+0x70]
0000794c94dda562  vmovaps xmm8, [rsp+0x80]
0000794c94dda56b  vmovaps xmm9, [rsp+0x90]
0000794c94dda574  vmovaps xmm10, [rsp+0xA0]
0000794c94dda57d  vmovaps xmm11, [rsp+0xB0]
0000794c94dda586  vmovaps xmm12, [rsp+0xC0]
0000794c94dda58f  vmovaps xmm14, [rsp+0xD0]
0000794c94dda598  vmovaps xmm15, [rsp+0xE0]
0000794c94dda5a1  add rsp, 0xF0
0000794c94dda5a8  pop r11
0000794c94dda5aa  pop r10
0000794c94dda5ac  pop r9
0000794c94dda5ae  pop r8
0000794c94dda5b0  pop rsi
0000794c94dda5b1  pop rdi
0000794c94dda5b2  pop rdx
0000794c94dda5b3  pop rcx
0000794c94dda5b4  pop rax
0000794c94dda5b5  add rsp, 0x08
0000794c94dda5b9  jmp 0x0000794C94DD645C
0000794c94dda5be  sub rsp, 0x08
0000794c94dda5c2  push rax
0000794c94dda5c3  push rcx
0000794c94dda5c4  push rdx
0000794c94dda5c5  push rdi
0000794c94dda5c6  push rsi
0000794c94dda5c7  push r8
0000794c94dda5c9  push r9
0000794c94dda5cb  push r10
0000794c94dda5cd  push r11
0000794c94dda5cf  sub rsp, 0xF0
0000794c94dda5d6  vmovaps [rsp], xmm0
0000794c94dda5db  vmovaps [rsp+0x10], xmm1
0000794c94dda5e1  vmovaps [rsp+0x20], xmm2
0000794c94dda5e7  vmovaps [rsp+0x30], xmm3
0000794c94dda5ed  vmovaps [rsp+0x40], xmm4
0000794c94dda5f3  vmovaps [rsp+0x50], xmm5
0000794c94dda5f9  vmovaps [rsp+0x60], xmm6
0000794c94dda5ff  vmovaps [rsp+0x70], xmm7
0000794c94dda605  vmovaps [rsp+0x80], xmm9
0000794c94dda60e  vmovaps [rsp+0x90], xmm10
0000794c94dda617  vmovaps [rsp+0xA0], xmm11
0000794c94dda620  vmovaps [rsp+0xB0], xmm12
0000794c94dda629  vmovaps [rsp+0xC0], xmm13
0000794c94dda632  vmovaps [rsp+0xD0], xmm14
0000794c94dda63b  vmovaps [rsp+0xE0], xmm15
0000794c94dda644  sub rsp, 0x30
0000794c94dda648  movaps [rsp], xmm8
0000794c94dda64d  movaps [rsp+0x10], xmm15
0000794c94dda653  movaps [rsp+0x20], xmm9
0000794c94dda659  lea rdi, [rsp]
0000794c94dda65d  mov esi, 0x00
0000794c94dda662  mov rax, 0x5AB2B8B81530
0000794c94dda66c  call rax
0000794c94dda66e  movaps xmm8, [rsp]
0000794c94dda673  add rsp, 0x30
0000794c94dda677  vmovaps xmm0, [rsp]
0000794c94dda67c  vmovaps xmm1, [rsp+0x10]
0000794c94dda682  vmovaps xmm2, [rsp+0x20]
0000794c94dda688  vmovaps xmm3, [rsp+0x30]
0000794c94dda68e  vmovaps xmm4, [rsp+0x40]
0000794c94dda694  vmovaps xmm5, [rsp+0x50]
0000794c94dda69a  vmovaps xmm6, [rsp+0x60]
0000794c94dda6a0  vmovaps xmm7, [rsp+0x70]
0000794c94dda6a6  vmovaps xmm9, [rsp+0x80]
0000794c94dda6af  vmovaps xmm10, [rsp+0x90]
0000794c94dda6b8  vmovaps xmm11, [rsp+0xA0]
0000794c94dda6c1  vmovaps xmm12, [rsp+0xB0]
0000794c94dda6ca  vmovaps xmm13, [rsp+0xC0]
0000794c94dda6d3  vmovaps xmm14, [rsp+0xD0]
0000794c94dda6dc  vmovaps xmm15, [rsp+0xE0]
0000794c94dda6e5  add rsp, 0xF0
0000794c94dda6ec  pop r11
0000794c94dda6ee  pop r10
0000794c94dda6f0  pop r9
0000794c94dda6f2  pop r8
0000794c94dda6f4  pop rsi
0000794c94dda6f5  pop rdi
0000794c94dda6f6  pop rdx
0000794c94dda6f7  pop rcx
0000794c94dda6f8  pop rax
0000794c94dda6f9  add rsp, 0x08
0000794c94dda6fd  jmp 0x0000794C94DD648A
0000794c94dda702  sub rsp, 0x08
0000794c94dda706  push rax
0000794c94dda707  push rcx
0000794c94dda708  push rdx
0000794c94dda709  push rdi
0000794c94dda70a  push rsi
0000794c94dda70b  push r8
0000794c94dda70d  push r9
0000794c94dda70f  push r10
0000794c94dda711  push r11
0000794c94dda713  sub rsp, 0xF0
0000794c94dda71a  vmovaps [rsp], xmm0
0000794c94dda71f  vmovaps [rsp+0x10], xmm1
0000794c94dda725  vmovaps [rsp+0x20], xmm2
0000794c94dda72b  vmovaps [rsp+0x30], xmm3
0000794c94dda731  vmovaps [rsp+0x40], xmm4
0000794c94dda737  vmovaps [rsp+0x50], xmm5
0000794c94dda73d  vmovaps [rsp+0x60], xmm6
0000794c94dda743  vmovaps [rsp+0x70], xmm7
0000794c94dda749  vmovaps [rsp+0x80], xmm8
0000794c94dda752  vmovaps [rsp+0x90], xmm9
0000794c94dda75b  vmovaps [rsp+0xA0], xmm10
0000794c94dda764  vmovaps [rsp+0xB0], xmm11
0000794c94dda76d  vmovaps [rsp+0xC0], xmm12
0000794c94dda776  vmovaps [rsp+0xD0], xmm13
0000794c94dda77f  vmovaps [rsp+0xE0], xmm14
0000794c94dda788  sub rsp, 0x30
0000794c94dda78c  movaps [rsp], xmm15
0000794c94dda791  movaps [rsp+0x10], xmm11
0000794c94dda797  movaps [rsp+0x20], xmm6
0000794c94dda79c  lea rdi, [rsp]
0000794c94dda7a0  mov esi, 0x00
0000794c94dda7a5  mov rax, 0x5AB2B8B81530
0000794c94dda7af  call rax
0000794c94dda7b1  movaps xmm15, [rsp]
0000794c94dda7b6  add rsp, 0x30
0000794c94dda7ba  vmovaps xmm0, [rsp]
0000794c94dda7bf  vmovaps xmm1, [rsp+0x10]
0000794c94dda7c5  vmovaps xmm2, [rsp+0x20]
0000794c94dda7cb  vmovaps xmm3, [rsp+0x30]
0000794c94dda7d1  vmovaps xmm4, [rsp+0x40]
0000794c94dda7d7  vmovaps xmm5, [rsp+0x50]
0000794c94dda7dd  vmovaps xmm6, [rsp+0x60]
0000794c94dda7e3  vmovaps xmm7, [rsp+0x70]
0000794c94dda7e9  vmovaps xmm8, [rsp+0x80]
0000794c94dda7f2  vmovaps xmm9, [rsp+0x90]
0000794c94dda7fb  vmovaps xmm10, [rsp+0xA0]
0000794c94dda804  vmovaps xmm11, [rsp+0xB0]
0000794c94dda80d  vmovaps xmm12, [rsp+0xC0]
0000794c94dda816  vmovaps xmm13, [rsp+0xD0]
0000794c94dda81f  vmovaps xmm14, [rsp+0xE0]
0000794c94dda828  add rsp, 0xF0
0000794c94dda82f  pop r11
0000794c94dda831  pop r10
0000794c94dda833  pop r9
0000794c94dda835  pop r8
0000794c94dda837  pop rsi
0000794c94dda838  pop rdi
0000794c94dda839  pop rdx
0000794c94dda83a  pop rcx
0000794c94dda83b  pop rax
0000794c94dda83c  add rsp, 0x08
0000794c94dda840  jmp 0x0000794C94DD64A5
0000794c94dda845  sub rsp, 0x08
0000794c94dda849  push rax
0000794c94dda84a  push rcx
0000794c94dda84b  push rdx
0000794c94dda84c  push rdi
0000794c94dda84d  push rsi
0000794c94dda84e  push r8
0000794c94dda850  push r9
0000794c94dda852  push r10
0000794c94dda854  push r11
0000794c94dda856  sub rsp, 0xF0
0000794c94dda85d  vmovaps [rsp], xmm0
0000794c94dda862  vmovaps [rsp+0x10], xmm1
0000794c94dda868  vmovaps [rsp+0x20], xmm2
0000794c94dda86e  vmovaps [rsp+0x30], xmm3
0000794c94dda874  vmovaps [rsp+0x40], xmm4
0000794c94dda87a  vmovaps [rsp+0x50], xmm5
0000794c94dda880  vmovaps [rsp+0x60], xmm6
0000794c94dda886  vmovaps [rsp+0x70], xmm8
0000794c94dda88c  vmovaps [rsp+0x80], xmm9
0000794c94dda895  vmovaps [rsp+0x90], xmm10
0000794c94dda89e  vmovaps [rsp+0xA0], xmm11
0000794c94dda8a7  vmovaps [rsp+0xB0], xmm12
0000794c94dda8b0  vmovaps [rsp+0xC0], xmm13
0000794c94dda8b9  vmovaps [rsp+0xD0], xmm14
0000794c94dda8c2  vmovaps [rsp+0xE0], xmm15
0000794c94dda8cb  sub rsp, 0x30
0000794c94dda8cf  movaps [rsp], xmm7
0000794c94dda8d3  movaps [rsp+0x10], xmm11
0000794c94dda8d9  movaps [rsp+0x20], xmm9
0000794c94dda8df  lea rdi, [rsp]
0000794c94dda8e3  mov esi, 0x00
0000794c94dda8e8  mov rax, 0x5AB2B8B81530
0000794c94dda8f2  call rax
0000794c94dda8f4  movaps xmm7, [rsp]
0000794c94dda8f8  add rsp, 0x30
0000794c94dda8fc  vmovaps xmm0, [rsp]
0000794c94dda901  vmovaps xmm1, [rsp+0x10]
0000794c94dda907  vmovaps xmm2, [rsp+0x20]
0000794c94dda90d  vmovaps xmm3, [rsp+0x30]
0000794c94dda913  vmovaps xmm4, [rsp+0x40]
0000794c94dda919  vmovaps xmm5, [rsp+0x50]
0000794c94dda91f  vmovaps xmm6, [rsp+0x60]
0000794c94dda925  vmovaps xmm8, [rsp+0x70]
0000794c94dda92b  vmovaps xmm9, [rsp+0x80]
0000794c94dda934  vmovaps xmm10, [rsp+0x90]
0000794c94dda93d  vmovaps xmm11, [rsp+0xA0]
0000794c94dda946  vmovaps xmm12, [rsp+0xB0]
0000794c94dda94f  vmovaps xmm13, [rsp+0xC0]
0000794c94dda958  vmovaps xmm14, [rsp+0xD0]
0000794c94dda961  vmovaps xmm15, [rsp+0xE0]
0000794c94dda96a  add rsp, 0xF0
0000794c94dda971  pop r11
0000794c94dda973  pop r10
0000794c94dda975  pop r9
0000794c94dda977  pop r8
0000794c94dda979  pop rsi
0000794c94dda97a  pop rdi
0000794c94dda97b  pop rdx
0000794c94dda97c  pop rcx
0000794c94dda97d  pop rax
0000794c94dda97e  add rsp, 0x08
0000794c94dda982  jmp 0x0000794C94DD64D2
0000794c94dda987  sub rsp, 0x08
0000794c94dda98b  push rax
0000794c94dda98c  push rcx
0000794c94dda98d  push rdx
0000794c94dda98e  push rdi
0000794c94dda98f  push rsi
0000794c94dda990  push r8
0000794c94dda992  push r9
0000794c94dda994  push r10
0000794c94dda996  push r11
0000794c94dda998  sub rsp, 0xF0
0000794c94dda99f  vmovaps [rsp], xmm0
0000794c94dda9a4  vmovaps [rsp+0x10], xmm1
0000794c94dda9aa  vmovaps [rsp+0x20], xmm2
0000794c94dda9b0  vmovaps [rsp+0x30], xmm3
0000794c94dda9b6  vmovaps [rsp+0x40], xmm4
0000794c94dda9bc  vmovaps [rsp+0x50], xmm5
0000794c94dda9c2  vmovaps [rsp+0x60], xmm6
0000794c94dda9c8  vmovaps [rsp+0x70], xmm7
0000794c94dda9ce  vmovaps [rsp+0x80], xmm8
0000794c94dda9d7  vmovaps [rsp+0x90], xmm9
0000794c94dda9e0  vmovaps [rsp+0xA0], xmm10
0000794c94dda9e9  vmovaps [rsp+0xB0], xmm12
0000794c94dda9f2  vmovaps [rsp+0xC0], xmm13
0000794c94dda9fb  vmovaps [rsp+0xD0], xmm14
0000794c94ddaa04  vmovaps [rsp+0xE0], xmm15
0000794c94ddaa0d  sub rsp, 0x30
0000794c94ddaa11  movaps [rsp], xmm11
0000794c94ddaa16  movaps [rsp+0x10], xmm10
0000794c94ddaa1c  movaps [rsp+0x20], xmm14
0000794c94ddaa22  lea rdi, [rsp]
0000794c94ddaa26  mov esi, 0x00
0000794c94ddaa2b  mov rax, 0x5AB2B8B81530
0000794c94ddaa35  call rax
0000794c94ddaa37  movaps xmm11, [rsp]
0000794c94ddaa3c  add rsp, 0x30
0000794c94ddaa40  vmovaps xmm0, [rsp]
0000794c94ddaa45  vmovaps xmm1, [rsp+0x10]
0000794c94ddaa4b  vmovaps xmm2, [rsp+0x20]
0000794c94ddaa51  vmovaps xmm3, [rsp+0x30]
0000794c94ddaa57  vmovaps xmm4, [rsp+0x40]
0000794c94ddaa5d  vmovaps xmm5, [rsp+0x50]
0000794c94ddaa63  vmovaps xmm6, [rsp+0x60]
0000794c94ddaa69  vmovaps xmm7, [rsp+0x70]
0000794c94ddaa6f  vmovaps xmm8, [rsp+0x80]
0000794c94ddaa78  vmovaps xmm9, [rsp+0x90]
0000794c94ddaa81  vmovaps xmm10, [rsp+0xA0]
0000794c94ddaa8a  vmovaps xmm12, [rsp+0xB0]
0000794c94ddaa93  vmovaps xmm13, [rsp+0xC0]
0000794c94ddaa9c  vmovaps xmm14, [rsp+0xD0]
0000794c94ddaaa5  vmovaps xmm15, [rsp+0xE0]
0000794c94ddaaae  add rsp, 0xF0
0000794c94ddaab5  pop r11
0000794c94ddaab7  pop r10
0000794c94ddaab9  pop r9
0000794c94ddaabb  pop r8
0000794c94ddaabd  pop rsi
0000794c94ddaabe  pop rdi
0000794c94ddaabf  pop rdx
0000794c94ddaac0  pop rcx
0000794c94ddaac1  pop rax
0000794c94ddaac2  add rsp, 0x08
0000794c94ddaac6  jmp 0x0000794C94DD64ED
0000794c94ddaacb  call 0x0000794C94CE45A0
0000794c94ddaad0  jmp 0x0000794C94DD64F7
0000794c94ddaad5  sub rsp, 0x08
0000794c94ddaad9  push rax
0000794c94ddaada  push rcx
0000794c94ddaadb  push rdx
0000794c94ddaadc  push rdi
0000794c94ddaadd  push rsi
0000794c94ddaade  push r8
0000794c94ddaae0  push r9
0000794c94ddaae2  push r10
0000794c94ddaae4  push r11
0000794c94ddaae6  sub rsp, 0xF0
0000794c94ddaaed  vmovaps [rsp], xmm0
0000794c94ddaaf2  vmovaps [rsp+0x10], xmm1
0000794c94ddaaf8  vmovaps [rsp+0x20], xmm2
0000794c94ddaafe  vmovaps [rsp+0x30], xmm3
0000794c94ddab04  vmovaps [rsp+0x40], xmm4
0000794c94ddab0a  vmovaps [rsp+0x50], xmm5
0000794c94ddab10  vmovaps [rsp+0x60], xmm6
0000794c94ddab16  vmovaps [rsp+0x70], xmm7
0000794c94ddab1c  vmovaps [rsp+0x80], xmm8
0000794c94ddab25  vmovaps [rsp+0x90], xmm9
0000794c94ddab2e  vmovaps [rsp+0xA0], xmm11
0000794c94ddab37  vmovaps [rsp+0xB0], xmm12
0000794c94ddab40  vmovaps [rsp+0xC0], xmm13
0000794c94ddab49  vmovaps [rsp+0xD0], xmm14
0000794c94ddab52  vmovaps [rsp+0xE0], xmm15
0000794c94ddab5b  sub rsp, 0x30
0000794c94ddab5f  movaps [rsp], xmm10
0000794c94ddab64  movaps [rsp+0x10], xmm1
0000794c94ddab69  movaps [rsp+0x20], xmm12
0000794c94ddab6f  lea rdi, [rsp]
0000794c94ddab73  mov esi, 0x00
0000794c94ddab78  mov rax, 0x5AB2B8B81530
0000794c94ddab82  call rax
0000794c94ddab84  movaps xmm10, [rsp]
0000794c94ddab89  add rsp, 0x30
0000794c94ddab8d  vmovaps xmm0, [rsp]
0000794c94ddab92  vmovaps xmm1, [rsp+0x10]
0000794c94ddab98  vmovaps xmm2, [rsp+0x20]
0000794c94ddab9e  vmovaps xmm3, [rsp+0x30]
0000794c94ddaba4  vmovaps xmm4, [rsp+0x40]
0000794c94ddabaa  vmovaps xmm5, [rsp+0x50]
0000794c94ddabb0  vmovaps xmm6, [rsp+0x60]
0000794c94ddabb6  vmovaps xmm7, [rsp+0x70]
0000794c94ddabbc  vmovaps xmm8, [rsp+0x80]
0000794c94ddabc5  vmovaps xmm9, [rsp+0x90]
0000794c94ddabce  vmovaps xmm11, [rsp+0xA0]
0000794c94ddabd7  vmovaps xmm12, [rsp+0xB0]
0000794c94ddabe0  vmovaps xmm13, [rsp+0xC0]
0000794c94ddabe9  vmovaps xmm14, [rsp+0xD0]
0000794c94ddabf2  vmovaps xmm15, [rsp+0xE0]
0000794c94ddabfb  add rsp, 0xF0
0000794c94ddac02  pop r11
0000794c94ddac04  pop r10
0000794c94ddac06  pop r9
0000794c94ddac08  pop r8
0000794c94ddac0a  pop rsi
0000794c94ddac0b  pop rdi
0000794c94ddac0c  pop rdx
0000794c94ddac0d  pop rcx
0000794c94ddac0e  pop rax
0000794c94ddac0f  add rsp, 0x08
0000794c94ddac13  jmp 0x0000794C94DD651A
0000794c94ddac18  sub rsp, 0x08
0000794c94ddac1c  push rax
0000794c94ddac1d  push rcx
0000794c94ddac1e  push rdx
0000794c94ddac1f  push rdi
0000794c94ddac20  push rsi
0000794c94ddac21  push r8
0000794c94ddac23  push r9
0000794c94ddac25  push r10
0000794c94ddac27  push r11
0000794c94ddac29  sub rsp, 0xF0
0000794c94ddac30  vmovaps [rsp], xmm0
0000794c94ddac35  vmovaps [rsp+0x10], xmm1
0000794c94ddac3b  vmovaps [rsp+0x20], xmm2
0000794c94ddac41  vmovaps [rsp+0x30], xmm3
0000794c94ddac47  vmovaps [rsp+0x40], xmm4
0000794c94ddac4d  vmovaps [rsp+0x50], xmm5
0000794c94ddac53  vmovaps [rsp+0x60], xmm6
0000794c94ddac59  vmovaps [rsp+0x70], xmm7
0000794c94ddac5f  vmovaps [rsp+0x80], xmm8
0000794c94ddac68  vmovaps [rsp+0x90], xmm9
0000794c94ddac71  vmovaps [rsp+0xA0], xmm10
0000794c94ddac7a  vmovaps [rsp+0xB0], xmm11
0000794c94ddac83  vmovaps [rsp+0xC0], xmm13
0000794c94ddac8c  vmovaps [rsp+0xD0], xmm14
0000794c94ddac95  vmovaps [rsp+0xE0], xmm15
0000794c94ddac9e  sub rsp, 0x30
0000794c94ddaca2  movaps [rsp], xmm12
0000794c94ddaca7  movaps [rsp+0x10], xmm14
0000794c94ddacad  movaps [rsp+0x20], xmm1
0000794c94ddacb2  lea rdi, [rsp]
0000794c94ddacb6  mov esi, 0x00
0000794c94ddacbb  mov rax, 0x5AB2B8B81530
0000794c94ddacc5  call rax
0000794c94ddacc7  movaps xmm12, [rsp]
0000794c94ddaccc  add rsp, 0x30
0000794c94ddacd0  vmovaps xmm0, [rsp]
0000794c94ddacd5  vmovaps xmm1, [rsp+0x10]
0000794c94ddacdb  vmovaps xmm2, [rsp+0x20]
0000794c94ddace1  vmovaps xmm3, [rsp+0x30]
0000794c94ddace7  vmovaps xmm4, [rsp+0x40]
0000794c94ddaced  vmovaps xmm5, [rsp+0x50]
0000794c94ddacf3  vmovaps xmm6, [rsp+0x60]
0000794c94ddacf9  vmovaps xmm7, [rsp+0x70]
0000794c94ddacff  vmovaps xmm8, [rsp+0x80]
0000794c94ddad08  vmovaps xmm9, [rsp+0x90]
0000794c94ddad11  vmovaps xmm10, [rsp+0xA0]
0000794c94ddad1a  vmovaps xmm11, [rsp+0xB0]
0000794c94ddad23  vmovaps xmm13, [rsp+0xC0]
0000794c94ddad2c  vmovaps xmm14, [rsp+0xD0]
0000794c94ddad35  vmovaps xmm15, [rsp+0xE0]
0000794c94ddad3e  add rsp, 0xF0
0000794c94ddad45  pop r11
0000794c94ddad47  pop r10
0000794c94ddad49  pop r9
0000794c94ddad4b  pop r8
0000794c94ddad4d  pop rsi
0000794c94ddad4e  pop rdi
0000794c94ddad4f  pop rdx
0000794c94ddad50  pop rcx
0000794c94ddad51  pop rax
0000794c94ddad52  add rsp, 0x08
0000794c94ddad56  jmp 0x0000794C94DD6549
0000794c94ddad5b  sub rsp, 0x08
0000794c94ddad5f  push rax
0000794c94ddad60  push rcx
0000794c94ddad61  push rdx
0000794c94ddad62  push rdi
0000794c94ddad63  push rsi
0000794c94ddad64  push r8
0000794c94ddad66  push r9
0000794c94ddad68  push r10
0000794c94ddad6a  push r11
0000794c94ddad6c  sub rsp, 0xF0
0000794c94ddad73  vmovaps [rsp], xmm0
0000794c94ddad78  vmovaps [rsp+0x10], xmm1
0000794c94ddad7e  vmovaps [rsp+0x20], xmm2
0000794c94ddad84  vmovaps [rsp+0x30], xmm3
0000794c94ddad8a  vmovaps [rsp+0x40], xmm4
0000794c94ddad90  vmovaps [rsp+0x50], xmm5
0000794c94ddad96  vmovaps [rsp+0x60], xmm6
0000794c94ddad9c  vmovaps [rsp+0x70], xmm7
0000794c94ddada2  vmovaps [rsp+0x80], xmm8
0000794c94ddadab  vmovaps [rsp+0x90], xmm9
0000794c94ddadb4  vmovaps [rsp+0xA0], xmm10
0000794c94ddadbd  vmovaps [rsp+0xB0], xmm11
0000794c94ddadc6  vmovaps [rsp+0xC0], xmm12
0000794c94ddadcf  vmovaps [rsp+0xD0], xmm13
0000794c94ddadd8  vmovaps [rsp+0xE0], xmm15
0000794c94ddade1  sub rsp, 0x30
0000794c94ddade5  movaps [rsp], xmm14
0000794c94ddadea  movaps [rsp+0x10], xmm9
0000794c94ddadf0  movaps [rsp+0x20], xmm1
0000794c94ddadf5  lea rdi, [rsp]
0000794c94ddadf9  mov esi, 0x00
0000794c94ddadfe  mov rax, 0x5AB2B8B81530
0000794c94ddae08  call rax
0000794c94ddae0a  movaps xmm14, [rsp]
0000794c94ddae0f  add rsp, 0x30
0000794c94ddae13  vmovaps xmm0, [rsp]
0000794c94ddae18  vmovaps xmm1, [rsp+0x10]
0000794c94ddae1e  vmovaps xmm2, [rsp+0x20]
0000794c94ddae24  vmovaps xmm3, [rsp+0x30]
0000794c94ddae2a  vmovaps xmm4, [rsp+0x40]
0000794c94ddae30  vmovaps xmm5, [rsp+0x50]
0000794c94ddae36  vmovaps xmm6, [rsp+0x60]
0000794c94ddae3c  vmovaps xmm7, [rsp+0x70]
0000794c94ddae42  vmovaps xmm8, [rsp+0x80]
0000794c94ddae4b  vmovaps xmm9, [rsp+0x90]
0000794c94ddae54  vmovaps xmm10, [rsp+0xA0]
0000794c94ddae5d  vmovaps xmm11, [rsp+0xB0]
0000794c94ddae66  vmovaps xmm12, [rsp+0xC0]
0000794c94ddae6f  vmovaps xmm13, [rsp+0xD0]
0000794c94ddae78  vmovaps xmm15, [rsp+0xE0]
0000794c94ddae81  add rsp, 0xF0
0000794c94ddae88  pop r11
0000794c94ddae8a  pop r10
0000794c94ddae8c  pop r9
0000794c94ddae8e  pop r8
0000794c94ddae90  pop rsi
0000794c94ddae91  pop rdi
0000794c94ddae92  pop rdx
0000794c94ddae93  pop rcx
0000794c94ddae94  pop rax
0000794c94ddae95  add rsp, 0x08
0000794c94ddae99  jmp 0x0000794C94DD6578
0000794c94ddae9e  sub rsp, 0x08
0000794c94ddaea2  push rax
0000794c94ddaea3  push rcx
0000794c94ddaea4  push rdx
0000794c94ddaea5  push rdi
0000794c94ddaea6  push rsi
0000794c94ddaea7  push r8
0000794c94ddaea9  push r9
0000794c94ddaeab  push r10
0000794c94ddaead  push r11
0000794c94ddaeaf  sub rsp, 0xF0
0000794c94ddaeb6  vmovaps [rsp], xmm0
0000794c94ddaebb  vmovaps [rsp+0x10], xmm2
0000794c94ddaec1  vmovaps [rsp+0x20], xmm3
0000794c94ddaec7  vmovaps [rsp+0x30], xmm4
0000794c94ddaecd  vmovaps [rsp+0x40], xmm5
0000794c94ddaed3  vmovaps [rsp+0x50], xmm6
0000794c94ddaed9  vmovaps [rsp+0x60], xmm7
0000794c94ddaedf  vmovaps [rsp+0x70], xmm8
0000794c94ddaee5  vmovaps [rsp+0x80], xmm9
0000794c94ddaeee  vmovaps [rsp+0x90], xmm10
0000794c94ddaef7  vmovaps [rsp+0xA0], xmm11
0000794c94ddaf00  vmovaps [rsp+0xB0], xmm12
0000794c94ddaf09  vmovaps [rsp+0xC0], xmm13
0000794c94ddaf12  vmovaps [rsp+0xD0], xmm14
0000794c94ddaf1b  vmovaps [rsp+0xE0], xmm15
0000794c94ddaf24  sub rsp, 0x30
0000794c94ddaf28  movaps [rsp], xmm1
0000794c94ddaf2c  movaps [rsp+0x10], xmm13
0000794c94ddaf32  movaps [rsp+0x20], xmm8
0000794c94ddaf38  lea rdi, [rsp]
0000794c94ddaf3c  mov esi, 0x00
0000794c94ddaf41  mov rax, 0x5AB2B8B81530
0000794c94ddaf4b  call rax
0000794c94ddaf4d  movaps xmm1, [rsp]
0000794c94ddaf51  add rsp, 0x30
0000794c94ddaf55  vmovaps xmm0, [rsp]
0000794c94ddaf5a  vmovaps xmm2, [rsp+0x10]
0000794c94ddaf60  vmovaps xmm3, [rsp+0x20]
0000794c94ddaf66  vmovaps xmm4, [rsp+0x30]
0000794c94ddaf6c  vmovaps xmm5, [rsp+0x40]
0000794c94ddaf72  vmovaps xmm6, [rsp+0x50]
0000794c94ddaf78  vmovaps xmm7, [rsp+0x60]
0000794c94ddaf7e  vmovaps xmm8, [rsp+0x70]
0000794c94ddaf84  vmovaps xmm9, [rsp+0x80]
0000794c94ddaf8d  vmovaps xmm10, [rsp+0x90]
0000794c94ddaf96  vmovaps xmm11, [rsp+0xA0]
0000794c94ddaf9f  vmovaps xmm12, [rsp+0xB0]
0000794c94ddafa8  vmovaps xmm13, [rsp+0xC0]
0000794c94ddafb1  vmovaps xmm14, [rsp+0xD0]
0000794c94ddafba  vmovaps xmm15, [rsp+0xE0]
0000794c94ddafc3  add rsp, 0xF0
0000794c94ddafca  pop r11
0000794c94ddafcc  pop r10
0000794c94ddafce  pop r9
0000794c94ddafd0  pop r8
0000794c94ddafd2  pop rsi
0000794c94ddafd3  pop rdi
0000794c94ddafd4  pop rdx
0000794c94ddafd5  pop rcx
0000794c94ddafd6  pop rax
0000794c94ddafd7  add rsp, 0x08
0000794c94ddafdb  jmp 0x0000794C94DD659A
0000794c94ddafe0  call 0x0000794C94C0C260
0000794c94ddafe5  jmp 0x0000794C94DD65A8
0000794c94ddafea  call 0x0000794C94CDE950
0000794c94ddafef  jmp 0x0000794C94DD65B2
0000794c94ddaff4  sub rsp, 0x08
0000794c94ddaff8  push rax
0000794c94ddaff9  push rcx
0000794c94ddaffa  push rdx
0000794c94ddaffb  push rdi
0000794c94ddaffc  push rsi
0000794c94ddaffd  push r8
0000794c94ddafff  push r9
0000794c94ddb001  push r10
0000794c94ddb003  push r11
0000794c94ddb005  sub rsp, 0xF0
0000794c94ddb00c  vmovaps [rsp], xmm0
0000794c94ddb011  vmovaps [rsp+0x10], xmm1
0000794c94ddb017  vmovaps [rsp+0x20], xmm2
0000794c94ddb01d  vmovaps [rsp+0x30], xmm3
0000794c94ddb023  vmovaps [rsp+0x40], xmm4
0000794c94ddb029  vmovaps [rsp+0x50], xmm5
0000794c94ddb02f  vmovaps [rsp+0x60], xmm6
0000794c94ddb035  vmovaps [rsp+0x70], xmm7
0000794c94ddb03b  vmovaps [rsp+0x80], xmm9
0000794c94ddb044  vmovaps [rsp+0x90], xmm10
0000794c94ddb04d  vmovaps [rsp+0xA0], xmm11
0000794c94ddb056  vmovaps [rsp+0xB0], xmm12
0000794c94ddb05f  vmovaps [rsp+0xC0], xmm13
0000794c94ddb068  vmovaps [rsp+0xD0], xmm14
0000794c94ddb071  vmovaps [rsp+0xE0], xmm15
0000794c94ddb07a  sub rsp, 0x30
0000794c94ddb07e  movaps [rsp], xmm8
0000794c94ddb083  movaps [rsp+0x10], xmm15
0000794c94ddb089  movaps [rsp+0x20], xmm7
0000794c94ddb08e  lea rdi, [rsp]
0000794c94ddb092  mov esi, 0x00
0000794c94ddb097  mov rax, 0x5AB2B8B81530
0000794c94ddb0a1  call rax
0000794c94ddb0a3  movaps xmm8, [rsp]
0000794c94ddb0a8  add rsp, 0x30
0000794c94ddb0ac  vmovaps xmm0, [rsp]
0000794c94ddb0b1  vmovaps xmm1, [rsp+0x10]
0000794c94ddb0b7  vmovaps xmm2, [rsp+0x20]
0000794c94ddb0bd  vmovaps xmm3, [rsp+0x30]
0000794c94ddb0c3  vmovaps xmm4, [rsp+0x40]
0000794c94ddb0c9  vmovaps xmm5, [rsp+0x50]
0000794c94ddb0cf  vmovaps xmm6, [rsp+0x60]
0000794c94ddb0d5  vmovaps xmm7, [rsp+0x70]
0000794c94ddb0db  vmovaps xmm9, [rsp+0x80]
0000794c94ddb0e4  vmovaps xmm10, [rsp+0x90]
0000794c94ddb0ed  vmovaps xmm11, [rsp+0xA0]
0000794c94ddb0f6  vmovaps xmm12, [rsp+0xB0]
0000794c94ddb0ff  vmovaps xmm13, [rsp+0xC0]
0000794c94ddb108  vmovaps xmm14, [rsp+0xD0]
0000794c94ddb111  vmovaps xmm15, [rsp+0xE0]
0000794c94ddb11a  add rsp, 0xF0
0000794c94ddb121  pop r11
0000794c94ddb123  pop r10
0000794c94ddb125  pop r9
0000794c94ddb127  pop r8
0000794c94ddb129  pop rsi
0000794c94ddb12a  pop rdi
0000794c94ddb12b  pop rdx
0000794c94ddb12c  pop rcx
0000794c94ddb12d  pop rax
0000794c94ddb12e  add rsp, 0x08
0000794c94ddb132  jmp 0x0000794C94DD65D4
0000794c94ddb137  sub rsp, 0x08
0000794c94ddb13b  push rax
0000794c94ddb13c  push rcx
0000794c94ddb13d  push rdx
0000794c94ddb13e  push rdi
0000794c94ddb13f  push rsi
0000794c94ddb140  push r8
0000794c94ddb142  push r9
0000794c94ddb144  push r10
0000794c94ddb146  push r11
0000794c94ddb148  sub rsp, 0xF0
0000794c94ddb14f  vmovaps [rsp], xmm0
0000794c94ddb154  vmovaps [rsp+0x10], xmm1
0000794c94ddb15a  vmovaps [rsp+0x20], xmm2
0000794c94ddb160  vmovaps [rsp+0x30], xmm3
0000794c94ddb166  vmovaps [rsp+0x40], xmm4
0000794c94ddb16c  vmovaps [rsp+0x50], xmm5
0000794c94ddb172  vmovaps [rsp+0x60], xmm6
0000794c94ddb178  vmovaps [rsp+0x70], xmm8
0000794c94ddb17e  vmovaps [rsp+0x80], xmm9
0000794c94ddb187  vmovaps [rsp+0x90], xmm10
0000794c94ddb190  vmovaps [rsp+0xA0], xmm11
0000794c94ddb199  vmovaps [rsp+0xB0], xmm12
0000794c94ddb1a2  vmovaps [rsp+0xC0], xmm13
0000794c94ddb1ab  vmovaps [rsp+0xD0], xmm14
0000794c94ddb1b4  vmovaps [rsp+0xE0], xmm15
0000794c94ddb1bd  sub rsp, 0x30
0000794c94ddb1c1  movaps [rsp], xmm7
0000794c94ddb1c5  movaps [rsp+0x10], xmm9
0000794c94ddb1cb  movaps [rsp+0x20], xmm15
0000794c94ddb1d1  lea rdi, [rsp]
0000794c94ddb1d5  mov esi, 0x00
0000794c94ddb1da  mov rax, 0x5AB2B8B81530
0000794c94ddb1e4  call rax
0000794c94ddb1e6  movaps xmm7, [rsp]
0000794c94ddb1ea  add rsp, 0x30
0000794c94ddb1ee  vmovaps xmm0, [rsp]
0000794c94ddb1f3  vmovaps xmm1, [rsp+0x10]
0000794c94ddb1f9  vmovaps xmm2, [rsp+0x20]
0000794c94ddb1ff  vmovaps xmm3, [rsp+0x30]
0000794c94ddb205  vmovaps xmm4, [rsp+0x40]
0000794c94ddb20b  vmovaps xmm5, [rsp+0x50]
0000794c94ddb211  vmovaps xmm6, [rsp+0x60]
0000794c94ddb217  vmovaps xmm8, [rsp+0x70]
0000794c94ddb21d  vmovaps xmm9, [rsp+0x80]
0000794c94ddb226  vmovaps xmm10, [rsp+0x90]
0000794c94ddb22f  vmovaps xmm11, [rsp+0xA0]
0000794c94ddb238  vmovaps xmm12, [rsp+0xB0]
0000794c94ddb241  vmovaps xmm13, [rsp+0xC0]
0000794c94ddb24a  vmovaps xmm14, [rsp+0xD0]
0000794c94ddb253  vmovaps xmm15, [rsp+0xE0]
0000794c94ddb25c  add rsp, 0xF0
0000794c94ddb263  pop r11
0000794c94ddb265  pop r10
0000794c94ddb267  pop r9
0000794c94ddb269  pop r8
0000794c94ddb26b  pop rsi
0000794c94ddb26c  pop rdi
0000794c94ddb26d  pop rdx
0000794c94ddb26e  pop rcx
0000794c94ddb26f  pop rax
0000794c94ddb270  add rsp, 0x08
0000794c94ddb274  jmp 0x0000794C94DD6601
0000794c94ddb279  sub rsp, 0x08
0000794c94ddb27d  push rax
0000794c94ddb27e  push rcx
0000794c94ddb27f  push rdx
0000794c94ddb280  push rdi
0000794c94ddb281  push rsi
0000794c94ddb282  push r8
0000794c94ddb284  push r9
0000794c94ddb286  push r10
0000794c94ddb288  push r11
0000794c94ddb28a  sub rsp, 0xF0
0000794c94ddb291  vmovaps [rsp], xmm0
0000794c94ddb296  vmovaps [rsp+0x10], xmm1
0000794c94ddb29c  vmovaps [rsp+0x20], xmm2
0000794c94ddb2a2  vmovaps [rsp+0x30], xmm3
0000794c94ddb2a8  vmovaps [rsp+0x40], xmm4
0000794c94ddb2ae  vmovaps [rsp+0x50], xmm5
0000794c94ddb2b4  vmovaps [rsp+0x60], xmm6
0000794c94ddb2ba  vmovaps [rsp+0x70], xmm7
0000794c94ddb2c0  vmovaps [rsp+0x80], xmm8
0000794c94ddb2c9  vmovaps [rsp+0x90], xmm10
0000794c94ddb2d2  vmovaps [rsp+0xA0], xmm11
0000794c94ddb2db  vmovaps [rsp+0xB0], xmm12
0000794c94ddb2e4  vmovaps [rsp+0xC0], xmm13
0000794c94ddb2ed  vmovaps [rsp+0xD0], xmm14
0000794c94ddb2f6  vmovaps [rsp+0xE0], xmm15
0000794c94ddb2ff  sub rsp, 0x30
0000794c94ddb303  movaps [rsp], xmm9
0000794c94ddb308  movaps [rsp+0x10], xmm13
0000794c94ddb30e  movaps [rsp+0x20], xmm15
0000794c94ddb314  lea rdi, [rsp]
0000794c94ddb318  mov esi, 0x00
0000794c94ddb31d  mov rax, 0x5AB2B8B81530
0000794c94ddb327  call rax
0000794c94ddb329  movaps xmm9, [rsp]
0000794c94ddb32e  add rsp, 0x30
0000794c94ddb332  vmovaps xmm0, [rsp]
0000794c94ddb337  vmovaps xmm1, [rsp+0x10]
0000794c94ddb33d  vmovaps xmm2, [rsp+0x20]
0000794c94ddb343  vmovaps xmm3, [rsp+0x30]
0000794c94ddb349  vmovaps xmm4, [rsp+0x40]
0000794c94ddb34f  vmovaps xmm5, [rsp+0x50]
0000794c94ddb355  vmovaps xmm6, [rsp+0x60]
0000794c94ddb35b  vmovaps xmm7, [rsp+0x70]
0000794c94ddb361  vmovaps xmm8, [rsp+0x80]
0000794c94ddb36a  vmovaps xmm10, [rsp+0x90]
0000794c94ddb373  vmovaps xmm11, [rsp+0xA0]
0000794c94ddb37c  vmovaps xmm12, [rsp+0xB0]
0000794c94ddb385  vmovaps xmm13, [rsp+0xC0]
0000794c94ddb38e  vmovaps xmm14, [rsp+0xD0]
0000794c94ddb397  vmovaps xmm15, [rsp+0xE0]
0000794c94ddb3a0  add rsp, 0xF0
0000794c94ddb3a7  pop r11
0000794c94ddb3a9  pop r10
0000794c94ddb3ab  pop r9
0000794c94ddb3ad  pop r8
0000794c94ddb3af  pop rsi
0000794c94ddb3b0  pop rdi
0000794c94ddb3b1  pop rdx
0000794c94ddb3b2  pop rcx
0000794c94ddb3b3  pop rax
0000794c94ddb3b4  add rsp, 0x08
0000794c94ddb3b8  jmp 0x0000794C94DD662F
0000794c94ddb3bd  sub rsp, 0x08
0000794c94ddb3c1  push rax
0000794c94ddb3c2  push rcx
0000794c94ddb3c3  push rdx
0000794c94ddb3c4  push rdi
0000794c94ddb3c5  push rsi
0000794c94ddb3c6  push r8
0000794c94ddb3c8  push r9
0000794c94ddb3ca  push r10
0000794c94ddb3cc  push r11
0000794c94ddb3ce  sub rsp, 0xF0
0000794c94ddb3d5  vmovaps [rsp], xmm0
0000794c94ddb3da  vmovaps [rsp+0x10], xmm1
0000794c94ddb3e0  vmovaps [rsp+0x20], xmm2
0000794c94ddb3e6  vmovaps [rsp+0x30], xmm3
0000794c94ddb3ec  vmovaps [rsp+0x40], xmm4
0000794c94ddb3f2  vmovaps [rsp+0x50], xmm5
0000794c94ddb3f8  vmovaps [rsp+0x60], xmm6
0000794c94ddb3fe  vmovaps [rsp+0x70], xmm7
0000794c94ddb404  vmovaps [rsp+0x80], xmm8
0000794c94ddb40d  vmovaps [rsp+0x90], xmm9
0000794c94ddb416  vmovaps [rsp+0xA0], xmm10
0000794c94ddb41f  vmovaps [rsp+0xB0], xmm11
0000794c94ddb428  vmovaps [rsp+0xC0], xmm12
0000794c94ddb431  vmovaps [rsp+0xD0], xmm13
0000794c94ddb43a  vmovaps [rsp+0xE0], xmm14
0000794c94ddb443  sub rsp, 0x30
0000794c94ddb447  movaps [rsp], xmm15
0000794c94ddb44c  movaps [rsp+0x10], xmm11
0000794c94ddb452  movaps [rsp+0x20], xmm12
0000794c94ddb458  lea rdi, [rsp]
0000794c94ddb45c  mov esi, 0x00
0000794c94ddb461  mov rax, 0x5AB2B8B81530
0000794c94ddb46b  call rax
0000794c94ddb46d  movaps xmm15, [rsp]
0000794c94ddb472  add rsp, 0x30
0000794c94ddb476  vmovaps xmm0, [rsp]
0000794c94ddb47b  vmovaps xmm1, [rsp+0x10]
0000794c94ddb481  vmovaps xmm2, [rsp+0x20]
0000794c94ddb487  vmovaps xmm3, [rsp+0x30]
0000794c94ddb48d  vmovaps xmm4, [rsp+0x40]
0000794c94ddb493  vmovaps xmm5, [rsp+0x50]
0000794c94ddb499  vmovaps xmm6, [rsp+0x60]
0000794c94ddb49f  vmovaps xmm7, [rsp+0x70]
0000794c94ddb4a5  vmovaps xmm8, [rsp+0x80]
0000794c94ddb4ae  vmovaps xmm9, [rsp+0x90]
0000794c94ddb4b7  vmovaps xmm10, [rsp+0xA0]
0000794c94ddb4c0  vmovaps xmm11, [rsp+0xB0]
0000794c94ddb4c9  vmovaps xmm12, [rsp+0xC0]
0000794c94ddb4d2  vmovaps xmm13, [rsp+0xD0]
0000794c94ddb4db  vmovaps xmm14, [rsp+0xE0]
0000794c94ddb4e4  add rsp, 0xF0
0000794c94ddb4eb  pop r11
0000794c94ddb4ed  pop r10
0000794c94ddb4ef  pop r9
0000794c94ddb4f1  pop r8
0000794c94ddb4f3  pop rsi
0000794c94ddb4f4  pop rdi
0000794c94ddb4f5  pop rdx
0000794c94ddb4f6  pop rcx
0000794c94ddb4f7  pop rax
0000794c94ddb4f8  add rsp, 0x08
0000794c94ddb4fc  jmp 0x0000794C94DD664A
0000794c94ddb501  sub rsp, 0x08
0000794c94ddb505  push rax
0000794c94ddb506  push rcx
0000794c94ddb507  push rdx
0000794c94ddb508  push rdi
0000794c94ddb509  push rsi
0000794c94ddb50a  push r8
0000794c94ddb50c  push r9
0000794c94ddb50e  push r10
0000794c94ddb510  push r11
0000794c94ddb512  sub rsp, 0xF0
0000794c94ddb519  vmovaps [rsp], xmm0
0000794c94ddb51e  vmovaps [rsp+0x10], xmm1
0000794c94ddb524  vmovaps [rsp+0x20], xmm2
0000794c94ddb52a  vmovaps [rsp+0x30], xmm3
0000794c94ddb530  vmovaps [rsp+0x40], xmm4
0000794c94ddb536  vmovaps [rsp+0x50], xmm5
0000794c94ddb53c  vmovaps [rsp+0x60], xmm6
0000794c94ddb542  vmovaps [rsp+0x70], xmm7
0000794c94ddb548  vmovaps [rsp+0x80], xmm8
0000794c94ddb551  vmovaps [rsp+0x90], xmm9
0000794c94ddb55a  vmovaps [rsp+0xA0], xmm10
0000794c94ddb563  vmovaps [rsp+0xB0], xmm11
0000794c94ddb56c  vmovaps [rsp+0xC0], xmm12
0000794c94ddb575  vmovaps [rsp+0xD0], xmm14
0000794c94ddb57e  vmovaps [rsp+0xE0], xmm15
0000794c94ddb587  sub rsp, 0x30
0000794c94ddb58b  movaps [rsp], xmm13
0000794c94ddb590  movaps [rsp+0x10], xmm10
0000794c94ddb596  movaps [rsp+0x20], xmm14
0000794c94ddb59c  lea rdi, [rsp]
0000794c94ddb5a0  mov esi, 0x00
0000794c94ddb5a5  mov rax, 0x5AB2B8B81530
0000794c94ddb5af  call rax
0000794c94ddb5b1  movaps xmm13, [rsp]
0000794c94ddb5b6  add rsp, 0x30
0000794c94ddb5ba  vmovaps xmm0, [rsp]
0000794c94ddb5bf  vmovaps xmm1, [rsp+0x10]
0000794c94ddb5c5  vmovaps xmm2, [rsp+0x20]
0000794c94ddb5cb  vmovaps xmm3, [rsp+0x30]
0000794c94ddb5d1  vmovaps xmm4, [rsp+0x40]
0000794c94ddb5d7  vmovaps xmm5, [rsp+0x50]
0000794c94ddb5dd  vmovaps xmm6, [rsp+0x60]
0000794c94ddb5e3  vmovaps xmm7, [rsp+0x70]
0000794c94ddb5e9  vmovaps xmm8, [rsp+0x80]
0000794c94ddb5f2  vmovaps xmm9, [rsp+0x90]
0000794c94ddb5fb  vmovaps xmm10, [rsp+0xA0]
0000794c94ddb604  vmovaps xmm11, [rsp+0xB0]
0000794c94ddb60d  vmovaps xmm12, [rsp+0xC0]
0000794c94ddb616  vmovaps xmm14, [rsp+0xD0]
0000794c94ddb61f  vmovaps xmm15, [rsp+0xE0]
0000794c94ddb628  add rsp, 0xF0
0000794c94ddb62f  pop r11
0000794c94ddb631  pop r10
0000794c94ddb633  pop r9
0000794c94ddb635  pop r8
0000794c94ddb637  pop rsi
0000794c94ddb638  pop rdi
0000794c94ddb639  pop rdx
0000794c94ddb63a  pop rcx
0000794c94ddb63b  pop rax
0000794c94ddb63c  add rsp, 0x08
0000794c94ddb640  jmp 0x0000794C94DD666D
0000794c94ddb645  sub rsp, 0x08
0000794c94ddb649  push rax
0000794c94ddb64a  push rcx
0000794c94ddb64b  push rdx
0000794c94ddb64c  push rdi
0000794c94ddb64d  push rsi
0000794c94ddb64e  push r8
0000794c94ddb650  push r9
0000794c94ddb652  push r10
0000794c94ddb654  push r11
0000794c94ddb656  sub rsp, 0xF0
0000794c94ddb65d  vmovaps [rsp], xmm0
0000794c94ddb662  vmovaps [rsp+0x10], xmm1
0000794c94ddb668  vmovaps [rsp+0x20], xmm2
0000794c94ddb66e  vmovaps [rsp+0x30], xmm3
0000794c94ddb674  vmovaps [rsp+0x40], xmm4
0000794c94ddb67a  vmovaps [rsp+0x50], xmm5
0000794c94ddb680  vmovaps [rsp+0x60], xmm6
0000794c94ddb686  vmovaps [rsp+0x70], xmm7
0000794c94ddb68c  vmovaps [rsp+0x80], xmm8
0000794c94ddb695  vmovaps [rsp+0x90], xmm9
0000794c94ddb69e  vmovaps [rsp+0xA0], xmm10
0000794c94ddb6a7  vmovaps [rsp+0xB0], xmm11
0000794c94ddb6b0  vmovaps [rsp+0xC0], xmm12
0000794c94ddb6b9  vmovaps [rsp+0xD0], xmm13
0000794c94ddb6c2  vmovaps [rsp+0xE0], xmm15
0000794c94ddb6cb  sub rsp, 0x30
0000794c94ddb6cf  movaps [rsp], xmm14
0000794c94ddb6d4  movaps [rsp+0x10], xmm1
0000794c94ddb6d9  movaps [rsp+0x20], xmm7
0000794c94ddb6de  lea rdi, [rsp]
0000794c94ddb6e2  mov esi, 0x00
0000794c94ddb6e7  mov rax, 0x5AB2B8B81530
0000794c94ddb6f1  call rax
0000794c94ddb6f3  movaps xmm14, [rsp]
0000794c94ddb6f8  add rsp, 0x30
0000794c94ddb6fc  vmovaps xmm0, [rsp]
0000794c94ddb701  vmovaps xmm1, [rsp+0x10]
0000794c94ddb707  vmovaps xmm2, [rsp+0x20]
0000794c94ddb70d  vmovaps xmm3, [rsp+0x30]
0000794c94ddb713  vmovaps xmm4, [rsp+0x40]
0000794c94ddb719  vmovaps xmm5, [rsp+0x50]
0000794c94ddb71f  vmovaps xmm6, [rsp+0x60]
0000794c94ddb725  vmovaps xmm7, [rsp+0x70]
0000794c94ddb72b  vmovaps xmm8, [rsp+0x80]
0000794c94ddb734  vmovaps xmm9, [rsp+0x90]
0000794c94ddb73d  vmovaps xmm10, [rsp+0xA0]
0000794c94ddb746  vmovaps xmm11, [rsp+0xB0]
0000794c94ddb74f  vmovaps xmm12, [rsp+0xC0]
0000794c94ddb758  vmovaps xmm13, [rsp+0xD0]
0000794c94ddb761  vmovaps xmm15, [rsp+0xE0]
0000794c94ddb76a  add rsp, 0xF0
0000794c94ddb771  pop r11
0000794c94ddb773  pop r10
0000794c94ddb775  pop r9
0000794c94ddb777  pop r8
0000794c94ddb779  pop rsi
0000794c94ddb77a  pop rdi
0000794c94ddb77b  pop rdx
0000794c94ddb77c  pop rcx
0000794c94ddb77d  pop rax
0000794c94ddb77e  add rsp, 0x08
0000794c94ddb782  jmp 0x0000794C94DD6690
0000794c94ddb787  sub rsp, 0x08
0000794c94ddb78b  push rax
0000794c94ddb78c  push rcx
0000794c94ddb78d  push rdx
0000794c94ddb78e  push rdi
0000794c94ddb78f  push rsi
0000794c94ddb790  push r8
0000794c94ddb792  push r9
0000794c94ddb794  push r10
0000794c94ddb796  push r11
0000794c94ddb798  sub rsp, 0xF0
0000794c94ddb79f  vmovaps [rsp], xmm0
0000794c94ddb7a4  vmovaps [rsp+0x10], xmm2
0000794c94ddb7aa  vmovaps [rsp+0x20], xmm3
0000794c94ddb7b0  vmovaps [rsp+0x30], xmm4
0000794c94ddb7b6  vmovaps [rsp+0x40], xmm5
0000794c94ddb7bc  vmovaps [rsp+0x50], xmm6
0000794c94ddb7c2  vmovaps [rsp+0x60], xmm7
0000794c94ddb7c8  vmovaps [rsp+0x70], xmm8
0000794c94ddb7ce  vmovaps [rsp+0x80], xmm9
0000794c94ddb7d7  vmovaps [rsp+0x90], xmm10
0000794c94ddb7e0  vmovaps [rsp+0xA0], xmm11
0000794c94ddb7e9  vmovaps [rsp+0xB0], xmm12
0000794c94ddb7f2  vmovaps [rsp+0xC0], xmm13
0000794c94ddb7fb  vmovaps [rsp+0xD0], xmm14
0000794c94ddb804  vmovaps [rsp+0xE0], xmm15
0000794c94ddb80d  sub rsp, 0x30
0000794c94ddb811  movaps [rsp], xmm1
0000794c94ddb815  movaps [rsp+0x10], xmm8
0000794c94ddb81b  movaps [rsp+0x20], xmm9
0000794c94ddb821  lea rdi, [rsp]
0000794c94ddb825  mov esi, 0x00
0000794c94ddb82a  mov rax, 0x5AB2B8B81530
0000794c94ddb834  call rax
0000794c94ddb836  movaps xmm1, [rsp]
0000794c94ddb83a  add rsp, 0x30
0000794c94ddb83e  vmovaps xmm0, [rsp]
0000794c94ddb843  vmovaps xmm2, [rsp+0x10]
0000794c94ddb849  vmovaps xmm3, [rsp+0x20]
0000794c94ddb84f  vmovaps xmm4, [rsp+0x30]
0000794c94ddb855  vmovaps xmm5, [rsp+0x40]
0000794c94ddb85b  vmovaps xmm6, [rsp+0x50]
0000794c94ddb861  vmovaps xmm7, [rsp+0x60]
0000794c94ddb867  vmovaps xmm8, [rsp+0x70]
0000794c94ddb86d  vmovaps xmm9, [rsp+0x80]
0000794c94ddb876  vmovaps xmm10, [rsp+0x90]
0000794c94ddb87f  vmovaps xmm11, [rsp+0xA0]
0000794c94ddb888  vmovaps xmm12, [rsp+0xB0]
0000794c94ddb891  vmovaps xmm13, [rsp+0xC0]
0000794c94ddb89a  vmovaps xmm14, [rsp+0xD0]
0000794c94ddb8a3  vmovaps xmm15, [rsp+0xE0]
0000794c94ddb8ac  add rsp, 0xF0
0000794c94ddb8b3  pop r11
0000794c94ddb8b5  pop r10
0000794c94ddb8b7  pop r9
0000794c94ddb8b9  pop r8
0000794c94ddb8bb  pop rsi
0000794c94ddb8bc  pop rdi
0000794c94ddb8bd  pop rdx
0000794c94ddb8be  pop rcx
0000794c94ddb8bf  pop rax
0000794c94ddb8c0  add rsp, 0x08
0000794c94ddb8c4  jmp 0x0000794C94DD66B2
0000794c94ddb8c9  call 0x0000794C94CB3E40
0000794c94ddb8ce  jmp 0x0000794C94DD66C0
0000794c94ddb8d3  call 0x0000794C94C0C380
0000794c94ddb8d8  jmp 0x0000794C94DD66CA
0000794c94ddb8dd  call 0x0000794C94C0D600
0000794c94ddb8e2  jmp 0x0000794C94DD66D4
0000794c94ddb8e7  call 0x0000794C94BFF540
0000794c94ddb8ec  jmp 0x0000794C94DD66DE
0000794c94ddb8f1  int3
0000794c94ddb8f2  nop [rax+rax*1], ax
0000794c94ddb8fb  nop [rax+rax*1], eax
0000794c94ddb900  mov eax, [r15+0x48]
0000794c94ddb904  lea r14d, [eax+0x01]
0000794c94ddb909  mov [rsp+0x10], r14d
0000794c94ddb90e  mov r14d, r14d
0000794c94ddb911  mov [r15+0x48], r14
0000794c94ddb915  xor eax, eax
0000794c94ddb917  mov r14d, [rsp+0x10]
0000794c94ddb91c  cmp r14d, 0x1F4
0000794c94ddb923  cmc
0000794c94ddb924  lahf
0000794c94ddb925  seto al
0000794c94ddb928  mov [r15+0x108], eax
0000794c94ddb92f  mov eax, [r15+0x108]
0000794c94ddb936  sahf
0000794c94ddb937  jnz 0x0000794C94DDB969
0000794c94ddb939  cmp dword ptr [r15+0x318], 0x00
0000794c94ddb941  jz 0x0000794C94DE1AB0
0000794c94ddb947  nop [rax+rax*1], ax
0000794c94ddb950  nop [rax+rax*1], eax
0000794c94ddb958  mov eax, 0x410450
0000794c94ddb95d  mov [r15+0x100], rax
0000794c94ddb964  jmp 0x0000794C94BFE110
0000794c94ddb969  cmp dword ptr [r15+0x318], 0x00
0000794c94ddb971  jz 0x0000794C94DDB9A0
0000794c94ddb977  nop [rax+rax*1], ax
0000794c94ddb980  nop [rax+rax*1], eax
0000794c94ddb988  mov eax, 0x410274
0000794c94ddb98d  mov [r15+0x100], rax
0000794c94ddb994  jmp 0x0000794C94BFE110
0000794c94ddb999  int3
0000794c94ddb99a  int3
0000794c94ddb99b  nop [rax+rax*1], eax
0000794c94ddb9a0  mov rax, [r15+0x40]
0000794c94ddb9a4  movaps xmm1, [r15+0x1D0]
0000794c94ddb9ac  vmovaps [rsp+0x10], xmm1
0000794c94ddb9b2  vmovaps xmm15, [rsp+0x10]
0000794c94ddb9b8  por xmm1, xmm15
0000794c94ddb9bd  movaps xmm14, [r15+0x1A0]
0000794c94ddb9c5  vmovaps [rsp+0x10], xmm14
0000794c94ddb9cb  vmovaps xmm13, [rsp+0x10]
0000794c94ddb9d1  por xmm14, xmm13
0000794c94ddb9d6  lea r14, [rax+0x30]
0000794c94ddb9da  mov r12, [r13+r14*1]
0000794c94ddb9df  lea r14, [rax+0x38]
0000794c94ddb9e3  mov r11, [r13+r14*1]
0000794c94ddb9e8  movq xmm13, r12
0000794c94ddb9ed  movq xmm12, r11
0000794c94ddb9f2  movq xmm13, xmm13
0000794c94ddb9f7  vmovaps [rsp+0x10], xmm13
0000794c94ddb9fd  movq xmm13, xmm13
0000794c94ddba02  movaps [r15+0x130], xmm13
0000794c94ddba0a  movq xmm12, xmm12
0000794c94ddba0f  vmovaps [rsp+0x20], xmm12
0000794c94ddba15  movq xmm12, xmm12
0000794c94ddba1a  movaps [r15+0x280], xmm12
0000794c94ddba22  movaps xmm13, [r15+0x270]
0000794c94ddba2a  vmovaps [rsp+0x30], xmm13
0000794c94ddba30  vmovaps xmm12, [rsp+0x30]
0000794c94ddba36  por xmm13, xmm12
0000794c94ddba3b  lea r14, [rax+0x20]
0000794c94ddba3f  mov r12, [r13+r14*1]
0000794c94ddba44  lea r14, [rax+0x28]
0000794c94ddba48  mov r11, [r13+r14*1]
0000794c94ddba4d  movq xmm12, r12
0000794c94ddba52  movq xmm11, r11
0000794c94ddba57  movq xmm12, xmm12
0000794c94ddba5c  vmovaps [rsp+0x30], xmm12
0000794c94ddba62  movq xmm12, xmm12
0000794c94ddba67  movaps [r15+0x150], xmm12
0000794c94ddba6f  movq xmm11, xmm11
0000794c94ddba74  vmovaps [rsp+0x40], xmm11
0000794c94ddba7a  movq xmm11, xmm11
0000794c94ddba7f  movaps [r15+0x140], xmm11
0000794c94ddba87  lea r14, [rax+0x10]
0000794c94ddba8b  mov r12, [r13+r14*1]
0000794c94ddba90  lea r14, [rax+0x18]
0000794c94ddba94  mov r11, [r13+r14*1]
0000794c94ddba99  movq xmm12, r12
0000794c94ddba9e  movq xmm11, r11
0000794c94ddbaa3  movq xmm12, xmm12
0000794c94ddbaa8  vmovaps [rsp+0x50], xmm12
0000794c94ddbaae  movq xmm12, xmm12
0000794c94ddbab3  movaps [r15+0x170], xmm12
0000794c94ddbabb  movq xmm11, xmm11
0000794c94ddbac0  vmovaps [rsp+0x60], xmm11
0000794c94ddbac6  movq xmm11, xmm11
0000794c94ddbacb  movaps [r15+0x160], xmm11
0000794c94ddbad3  mov r14, [r13+rax*1]
0000794c94ddbad8  vmovq xmm12, r14
0000794c94ddbadd  vpbroadcastq xmm12, xmm12
0000794c94ddbae2  lea r14, [rax+0x08]
0000794c94ddbae6  mov rax, [r13+r14*1]
0000794c94ddbaeb  movq xmm11, rax
0000794c94ddbaf0  movaps [r15+0x230], xmm11
0000794c94ddbaf8  mov rax, [r15+0xF8]
0000794c94ddbaff  lea r14, [rax+0x50]
0000794c94ddbb03  movups xmm11, [r13+r14*1]
0000794c94ddbb09  lea r14, [rax+0x60]
0000794c94ddbb0d  movups xmm10, [r13+r14*1]
0000794c94ddbb13  lea r14, [rax+0x30]
0000794c94ddbb17  movups xmm9, [r13+r14*1]
0000794c94ddbb1d  mov r14, [r15+0x50]
0000794c94ddbb21  mov [r15+0x60], r14
0000794c94ddbb25  mov qword ptr [r15+0x58], 0x40
0000794c94ddbb2d  movaps xmm8, xmm12
0000794c94ddbb31  mulpd xmm8, xmm15
0000794c94ddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000794c94ddbb3c  ptest xmm7, xmm7
0000794c94ddbb41  jnz 0x0000794C94DDC96A
0000794c94ddbb47  movq xmm15, qword ptr [r15+0x230]
0000794c94ddbb50  vmovaps [rsp+0x70], xmm15
0000794c94ddbb56  vpermilpd xmm15, xmm15, 0x00
0000794c94ddbb5c  movaps xmm7, xmm9
0000794c94ddbb60  mulpd xmm7, xmm15
0000794c94ddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000794c94ddbb6a  ptest xmm6, xmm6
0000794c94ddbb6f  jnz 0x0000794C94DDCAAE
0000794c94ddbb75  vxorps xmm15, xmm15, xmm15
0000794c94ddbb7a  vpbroadcastq xmm15, xmm15
0000794c94ddbb7f  movaps xmm9, xmm12
0000794c94ddbb83  mulpd xmm9, xmm10
0000794c94ddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000794c94ddbb8e  ptest xmm6, xmm6
0000794c94ddbb93  jnz 0x0000794C94DDCBF0
0000794c94ddbb99  movaps xmm10, xmm12
0000794c94ddbb9d  mulpd xmm10, xmm11
0000794c94ddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000794c94ddbba8  ptest xmm6, xmm6
0000794c94ddbbad  jnz 0x0000794C94DDCD34
0000794c94ddbbb3  movaps xmm11, [r15+0x1F0]
0000794c94ddbbbb  movaps xmm6, xmm12
0000794c94ddbbbf  mulpd xmm6, xmm11
0000794c94ddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000794c94ddbbc9  ptest xmm5, xmm5
0000794c94ddbbce  jnz 0x0000794C94DDCE78
0000794c94ddbbd4  movaps xmm12, [r15+0x2A0]
0000794c94ddbbdc  vmovaps [rsp+0x80], xmm12
0000794c94ddbbe5  vmovaps xmm11, [rsp+0x80]
0000794c94ddbbee  por xmm12, xmm11
0000794c94ddbbf3  movaps xmm11, [r15+0x250]
0000794c94ddbbfb  vmovaps [rsp+0x80], xmm11
0000794c94ddbc04  vmovaps xmm5, [rsp+0x80]
0000794c94ddbc0d  por xmm11, xmm5
0000794c94ddbc12  vmovaps xmm4, [rsp+0x70]
0000794c94ddbc18  vpermilpd xmm4, xmm4, 0x00
0000794c94ddbc1e  movaps xmm3, xmm5
0000794c94ddbc21  mulpd xmm3, xmm4
0000794c94ddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000794c94ddbc2a  ptest xmm2, xmm2
0000794c94ddbc2f  jnz 0x0000794C94DDCFBA
0000794c94ddbc35  mov [rsp+0x80], rax
0000794c94ddbc3d  xor eax, eax
0000794c94ddbc3f  mov r12d, 0x40
0000794c94ddbc45  mov r11d, 0x200
0000794c94ddbc4b  cmp r12, r11
0000794c94ddbc4e  cmc
0000794c94ddbc4f  lahf
0000794c94ddbc50  seto al
0000794c94ddbc53  mov [r15+0x108], eax
0000794c94ddbc5a  movaps xmm5, xmm8
0000794c94ddbc5e  addpd xmm5, xmm15
0000794c94ddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000794c94ddbc68  ptest xmm4, xmm4
0000794c94ddbc6d  jnz 0x0000794C94DDD0FA
0000794c94ddbc73  movaps xmm8, [r15+0x1B0]
0000794c94ddbc7b  movaps xmm4, xmm9
0000794c94ddbc7f  addpd xmm4, xmm8
0000794c94ddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000794c94ddbc89  ptest xmm2, xmm2
0000794c94ddbc8e  jnz 0x0000794C94DDD23C
0000794c94ddbc94  movaps xmm9, xmm10
0000794c94ddbc98  addpd xmm9, xmm8
0000794c94ddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000794c94ddbca3  ptest xmm2, xmm2
0000794c94ddbca8  jnz 0x0000794C94DDD37E
0000794c94ddbcae  movaps xmm10, [r15+0x2F0]
0000794c94ddbcb6  vmovaps [rsp+0x90], xmm10
0000794c94ddbcbf  vmovaps xmm8, [rsp+0x90]
0000794c94ddbcc8  por xmm10, xmm8
0000794c94ddbccd  movaps xmm8, [r15+0x2E0]
0000794c94ddbcd5  vmovaps [rsp+0x90], xmm8
0000794c94ddbcde  vmovaps xmm2, [rsp+0x90]
0000794c94ddbce7  por xmm8, xmm2
0000794c94ddbcec  movaps xmm2, [r15+0x2D0]
0000794c94ddbcf4  vmovaps [rsp+0x90], xmm2
0000794c94ddbcfd  vmovaps [rsp+0xA0], xmm1
0000794c94ddbd06  vmovaps xmm1, [rsp+0x90]
0000794c94ddbd0f  por xmm2, xmm1
0000794c94ddbd13  movaps xmm1, [r15+0x200]
0000794c94ddbd1b  vmovaps [rsp+0x90], xmm1
0000794c94ddbd24  vmovaps [rsp+0xB0], xmm15
0000794c94ddbd2d  vmovaps xmm15, [rsp+0x90]
0000794c94ddbd36  por xmm1, xmm15
0000794c94ddbd3b  movaps xmm15, [r15+0x1C0]
0000794c94ddbd43  vmovaps [rsp+0x90], xmm15
0000794c94ddbd4c  vmovaps [rsp+0xC0], xmm1
0000794c94ddbd55  vmovaps xmm1, [rsp+0x90]
0000794c94ddbd5e  por xmm15, xmm1
0000794c94ddbd63  movaps xmm1, [r15+0x190]
0000794c94ddbd6b  vmovaps [rsp+0x90], xmm1
0000794c94ddbd74  vmovaps [rsp+0xD0], xmm15
0000794c94ddbd7d  vmovaps xmm15, [rsp+0x90]
0000794c94ddbd86  por xmm1, xmm15
0000794c94ddbd8b  movaps xmm15, [r15+0x300]
0000794c94ddbd93  vmovaps [rsp+0x90], xmm15
0000794c94ddbd9c  vmovaps [rsp+0xE0], xmm1
0000794c94ddbda5  vmovaps xmm1, [rsp+0x90]
0000794c94ddbdae  por xmm15, xmm1
0000794c94ddbdb3  mov rax, [rsp+0x80]
0000794c94ddbdbb  lea r12, [rax+0xA0]
0000794c94ddbdc2  movups xmm1, [r13+r12*1]
0000794c94ddbdc8  lea r12, [rax+0xB0]
0000794c94ddbdcf  vmovaps [rsp+0x80], xmm1
0000794c94ddbdd8  movups xmm1, [r13+r12*1]
0000794c94ddbdde  vmovaps [rsp+0x90], xmm1
0000794c94ddbde7  vmovaps [rsp+0xF0], xmm15
0000794c94ddbdf0  vmovaps xmm15, [rsp+0xB0]
0000794c94ddbdf9  vmovaps [rsp+0xB0], xmm14
0000794c94ddbe02  movaps xmm1, xmm6
0000794c94ddbe05  addpd xmm1, xmm15
0000794c94ddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000794c94ddbe0f  ptest xmm14, xmm14
0000794c94ddbe15  jnz 0x0000794C94DDD4D6
0000794c94ddbe1b  lea r12, [rax+0xF0]
0000794c94ddbe22  movups xmm15, [r13+r12*1]
0000794c94ddbe28  movaps xmm14, xmm4
0000794c94ddbe2c  addpd xmm14, xmm3
0000794c94ddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000794c94ddbe37  ptest xmm6, xmm6
0000794c94ddbe3c  jnz 0x0000794C94DDD621
0000794c94ddbe42  movaps xmm6, xmm9
0000794c94ddbe46  addpd xmm6, xmm7
0000794c94ddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000794c94ddbe4f  ptest xmm4, xmm4
0000794c94ddbe54  jnz 0x0000794C94DDD763
0000794c94ddbe5a  vmovaps xmm9, [rsp+0x70]
0000794c94ddbe60  vpermilpd xmm9, xmm9, 0x00
0000794c94ddbe66  vmovaps xmm4, [rsp+0x90]
0000794c94ddbe6f  movaps xmm7, xmm4
0000794c94ddbe72  mulpd xmm7, xmm9
0000794c94ddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000794c94ddbe7c  ptest xmm3, xmm3
0000794c94ddbe81  jnz 0x0000794C94DDD8A4
0000794c94ddbe87  vmovaps xmm9, [rsp+0x50]
0000794c94ddbe8d  vpermilpd xmm9, xmm9, 0x00
0000794c94ddbe93  movaps xmm4, xmm15
0000794c94ddbe97  mulpd xmm4, xmm9
0000794c94ddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000794c94ddbea1  ptest xmm3, xmm3
0000794c94ddbea6  jnz 0x0000794C94DDD9E5
0000794c94ddbeac  lea r12, [rax+0xE0]
0000794c94ddbeb3  movups xmm15, [r13+r12*1]
0000794c94ddbeb9  vmovaps xmm9, [rsp+0x70]
0000794c94ddbebf  vpermilpd xmm9, xmm9, 0x00
0000794c94ddbec5  vmovaps [rsp+0x70], xmm1
0000794c94ddbecb  vmovaps xmm1, [rsp+0x80]
0000794c94ddbed4  vmovaps [rsp+0x80], xmm15
0000794c94ddbedd  movaps xmm3, xmm1
0000794c94ddbee0  mulpd xmm3, xmm9
0000794c94ddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000794c94ddbeea  ptest xmm15, xmm15
0000794c94ddbef0  jnz 0x0000794C94DDDB31
0000794c94ddbef6  vmovaps xmm1, [rsp+0xF0]
0000794c94ddbeff  vmovaps xmm15, [rsp+0xF0]
0000794c94ddbf08  por xmm1, xmm15
0000794c94ddbf0d  movaps [r15+0x300], xmm1
0000794c94ddbf15  vmovaps xmm15, [rsp+0xE0]
0000794c94ddbf1e  vmovaps xmm9, [rsp+0xE0]
0000794c94ddbf27  por xmm15, xmm9
0000794c94ddbf2c  movaps [r15+0x190], xmm15
0000794c94ddbf34  vmovaps xmm9, [rsp+0x50]
0000794c94ddbf3a  vpermilpd xmm9, xmm9, 0x00
0000794c94ddbf40  vmovaps [rsp+0x90], xmm1
0000794c94ddbf49  vmovaps [rsp+0xE0], xmm15
0000794c94ddbf52  vmovaps xmm15, [rsp+0x80]
0000794c94ddbf5b  vmovaps [rsp+0x80], xmm14
0000794c94ddbf64  movaps xmm1, xmm15
0000794c94ddbf68  mulpd xmm1, xmm9
0000794c94ddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000794c94ddbf72  ptest xmm14, xmm14
0000794c94ddbf78  jnz 0x0000794C94DDDC72
0000794c94ddbf7e  lea r12, [rax+0x90]
0000794c94ddbf85  movups xmm15, [r13+r12*1]
0000794c94ddbf8b  vmovaps xmm14, [rsp+0xD0]
0000794c94ddbf94  vmovaps xmm9, [rsp+0xD0]
0000794c94ddbf9d  por xmm14, xmm9
0000794c94ddbfa2  movaps [r15+0x1C0], xmm14
0000794c94ddbfaa  vmovaps xmm9, [rsp+0xC0]
0000794c94ddbfb3  vmovaps [rsp+0xD0], xmm1
0000794c94ddbfbc  vmovaps xmm1, [rsp+0xC0]
0000794c94ddbfc5  por xmm9, xmm1
0000794c94ddbfca  movaps [r15+0x200], xmm9
0000794c94ddbfd2  vmovaps [rsp+0xC0], xmm2
0000794c94ddbfdb  vmovaps xmm1, [rsp+0xC0]
0000794c94ddbfe4  por xmm2, xmm1
0000794c94ddbfe8  movaps [r15+0x2D0], xmm2
0000794c94ddbff0  vmovaps [rsp+0xC0], xmm8
0000794c94ddbff9  vmovaps xmm1, [rsp+0xC0]
0000794c94ddc002  por xmm8, xmm1
0000794c94ddc007  movaps [r15+0x2E0], xmm8
0000794c94ddc00f  vmovaps [rsp+0xC0], xmm15
0000794c94ddc018  movaps xmm1, xmm5
0000794c94ddc01b  addpd xmm1, xmm7
0000794c94ddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000794c94ddc024  ptest xmm15, xmm15
0000794c94ddc02a  jnz 0x0000794C94DDDDBE
0000794c94ddc030  vmovaps xmm15, [rsp+0x50]
0000794c94ddc036  vpermilpd xmm15, xmm15, 0x00
0000794c94ddc03c  vmovaps xmm5, [rsp+0xC0]
0000794c94ddc045  vmovaps [rsp+0xC0], xmm1
0000794c94ddc04e  movaps xmm7, xmm5
0000794c94ddc051  mulpd xmm7, xmm15
0000794c94ddc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000794c94ddc05b  ptest xmm1, xmm1
0000794c94ddc060  jnz 0x0000794C94DDDEFE
0000794c94ddc066  lea r12, [rax+0x80]
0000794c94ddc06d  movups xmm1, [r13+r12*1]
0000794c94ddc073  vmovaps xmm5, [rsp+0x70]
0000794c94ddc079  vmovaps [rsp+0x70], xmm1
0000794c94ddc07f  movaps xmm15, xmm5
0000794c94ddc083  addpd xmm15, xmm3
0000794c94ddc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000794c94ddc08e  ptest xmm1, xmm1
0000794c94ddc093  jnz 0x0000794C94DDE049
0000794c94ddc099  vmovaps xmm5, [rsp+0x80]
0000794c94ddc0a2  movaps xmm1, xmm5
0000794c94ddc0a5  addpd xmm1, xmm4
0000794c94ddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000794c94ddc0ae  ptest xmm3, xmm3
0000794c94ddc0b3  jnz 0x0000794C94DDE18B
0000794c94ddc0b9  vmovaps [rsp+0x80], xmm10
0000794c94ddc0c2  vmovaps xmm5, [rsp+0x80]
0000794c94ddc0cb  por xmm10, xmm5
0000794c94ddc0d0  movaps [r15+0x2F0], xmm10
0000794c94ddc0d8  vmovaps xmm5, [rsp+0x50]
0000794c94ddc0de  vpermilpd xmm5, xmm5, 0x00
0000794c94ddc0e4  vmovaps xmm3, [rsp+0x70]
0000794c94ddc0ea  vmovaps [rsp+0x50], xmm1
0000794c94ddc0f0  movaps xmm4, xmm3
0000794c94ddc0f3  mulpd xmm4, xmm5
0000794c94ddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000794c94ddc0fc  ptest xmm1, xmm1
0000794c94ddc101  jnz 0x0000794C94DDE2CB
0000794c94ddc107  lea r12, [rax+0xD0]
0000794c94ddc10e  movups xmm1, [r13+r12*1]
0000794c94ddc114  vmovaps xmm3, [rsp+0xD0]
0000794c94ddc11d  vmovaps [rsp+0x70], xmm1
0000794c94ddc123  movaps xmm5, xmm6
0000794c94ddc126  addpd xmm5, xmm3
0000794c94ddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000794c94ddc12f  ptest xmm1, xmm1
0000794c94ddc134  jnz 0x0000794C94DDE415
0000794c94ddc13a  vmovaps xmm1, [rsp+0x60]
0000794c94ddc140  vpermilpd xmm1, xmm1, 0x00
0000794c94ddc146  movaps xmm6, xmm9
0000794c94ddc14a  mulpd xmm6, xmm1
0000794c94ddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000794c94ddc153  ptest xmm3, xmm3
0000794c94ddc158  jnz 0x0000794C94DDE555
0000794c94ddc15e  movaps [r15+0x260], xmm6
0000794c94ddc166  vxorps xmm1, xmm1, xmm1
0000794c94ddc16a  vpbroadcastq xmm1, xmm1
0000794c94ddc16f  movaps [r15+0x1B0], xmm1
0000794c94ddc177  vmovaps xmm1, [rsp+0x60]
0000794c94ddc17d  vpermilpd xmm1, xmm1, 0x00
0000794c94ddc183  vmovaps xmm3, [rsp+0x70]
0000794c94ddc189  vmovaps [rsp+0x70], xmm15
0000794c94ddc18f  movaps xmm9, xmm3
0000794c94ddc193  mulpd xmm9, xmm1
0000794c94ddc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000794c94ddc19e  ptest xmm15, xmm15
0000794c94ddc1a4  jnz 0x0000794C94DDE696
0000794c94ddc1aa  lea r12, [rax+0xC0]
0000794c94ddc1b1  movups xmm1, [r13+r12*1]
0000794c94ddc1b7  vmovaps xmm3, [rsp+0xC0]
0000794c94ddc1c0  vmovaps [rsp+0x80], xmm1
0000794c94ddc1c9  movaps xmm15, xmm3
0000794c94ddc1cd  addpd xmm15, xmm7
0000794c94ddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000794c94ddc1d8  ptest xmm1, xmm1
0000794c94ddc1dd  jnz 0x0000794C94DDE7E2
0000794c94ddc1e3  vmovaps [rsp+0xC0], xmm13
0000794c94ddc1ec  vmovaps xmm1, [rsp+0xC0]
0000794c94ddc1f5  por xmm13, xmm1
0000794c94ddc1fa  movaps [r15+0x270], xmm13
0000794c94ddc202  vmovaps xmm1, [rsp+0xB0]
0000794c94ddc20b  vmovaps xmm7, [rsp+0xB0]
0000794c94ddc214  por xmm1, xmm7
0000794c94ddc218  movaps [r15+0x1A0], xmm1
0000794c94ddc220  vmovaps xmm1, [rsp+0x60]
0000794c94ddc226  vpermilpd xmm1, xmm1, 0x00
0000794c94ddc22c  vmovaps [rsp+0xB0], xmm1
0000794c94ddc235  vmovaps xmm1, [rsp+0x80]
0000794c94ddc23e  vmovaps [rsp+0x80], xmm15
0000794c94ddc247  vmovaps xmm15, [rsp+0xB0]
0000794c94ddc250  vmovaps [rsp+0xB0], xmm14
0000794c94ddc259  movaps xmm3, xmm1
0000794c94ddc25c  mulpd xmm3, xmm15
0000794c94ddc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000794c94ddc266  ptest xmm14, xmm14
0000794c94ddc26c  jnz 0x0000794C94DDE924
0000794c94ddc272  lea r12, [rax+0x20]
0000794c94ddc276  movups xmm1, [r13+r12*1]
0000794c94ddc27c  movaps [r15+0x110], xmm1
0000794c94ddc284  vmovaps xmm14, [rsp+0x70]
0000794c94ddc28a  vmovaps [rsp+0x70], xmm1
0000794c94ddc290  movaps xmm15, xmm14
0000794c94ddc294  addpd xmm15, xmm4
0000794c94ddc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000794c94ddc29f  ptest xmm1, xmm1
0000794c94ddc2a4  jnz 0x0000794C94DDEA6F
0000794c94ddc2aa  vmovaps xmm1, [rsp+0x60]
0000794c94ddc2b0  vpermilpd xmm1, xmm1, 0x00
0000794c94ddc2b6  movaps xmm14, xmm2
0000794c94ddc2ba  mulpd xmm14, xmm1
0000794c94ddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000794c94ddc2c5  ptest xmm4, xmm4
0000794c94ddc2ca  jnz 0x0000794C94DDEBB2
0000794c94ddc2d0  vmovaps xmm4, [rsp+0x50]
0000794c94ddc2d6  movaps xmm1, xmm4
0000794c94ddc2d9  addpd xmm1, xmm9
0000794c94ddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000794c94ddc2e3  ptest xmm2, xmm2
0000794c94ddc2e8  jnz 0x0000794C94DDECF4
0000794c94ddc2ee  vmovaps xmm9, [rsp+0x30]
0000794c94ddc2f4  vpermilpd xmm9, xmm9, 0x00
0000794c94ddc2fa  vmovaps xmm2, [rsp+0x70]
0000794c94ddc300  vmovaps [rsp+0x50], xmm1
0000794c94ddc306  movaps xmm4, xmm2
0000794c94ddc309  mulpd xmm4, xmm9
0000794c94ddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000794c94ddc313  ptest xmm1, xmm1
0000794c94ddc318  jnz 0x0000794C94DDEE35
0000794c94ddc31e  vmovaps xmm1, [rsp+0x30]
0000794c94ddc324  vpermilpd xmm1, xmm1, 0x00
0000794c94ddc32a  vmovaps xmm2, [rsp+0x90]
0000794c94ddc333  vmovaps [rsp+0x60], xmm15
0000794c94ddc339  movaps xmm9, xmm2
0000794c94ddc33d  mulpd xmm9, xmm1
0000794c94ddc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000794c94ddc348  ptest xmm15, xmm15
0000794c94ddc34e  jnz 0x0000794C94DDEF76
0000794c94ddc354  vmovaps xmm15, [rsp+0x80]
0000794c94ddc35d  movaps xmm1, xmm15
0000794c94ddc361  addpd xmm1, xmm6
0000794c94ddc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000794c94ddc36a  ptest xmm2, xmm2
0000794c94ddc36f  jnz 0x0000794C94DDF0B8
0000794c94ddc375  movaps xmm15, xmm5
0000794c94ddc379  addpd xmm15, xmm3
0000794c94ddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000794c94ddc384  ptest xmm6, xmm6
0000794c94ddc389  jnz 0x0000794C94DDF1F9
0000794c94ddc38f  vmovaps xmm6, [rsp+0x30]
0000794c94ddc395  vpermilpd xmm6, xmm6, 0x00
0000794c94ddc39b  movaps xmm5, xmm8
0000794c94ddc39f  mulpd xmm5, xmm6
0000794c94ddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000794c94ddc3a8  ptest xmm3, xmm3
0000794c94ddc3ad  jnz 0x0000794C94DDF33B
0000794c94ddc3b3  vmovaps xmm8, [rsp+0x30]
0000794c94ddc3b9  vpermilpd xmm8, xmm8, 0x00
0000794c94ddc3bf  movaps xmm6, xmm10
0000794c94ddc3c3  mulpd xmm6, xmm8
0000794c94ddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000794c94ddc3cd  ptest xmm3, xmm3
0000794c94ddc3d2  jnz 0x0000794C94DDF47C
0000794c94ddc3d8  vmovaps xmm8, [rsp+0x60]
0000794c94ddc3de  movaps xmm10, xmm8
0000794c94ddc3e2  addpd xmm10, xmm14
0000794c94ddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000794c94ddc3ed  ptest xmm3, xmm3
0000794c94ddc3f2  jnz 0x0000794C94DDF5BE
0000794c94ddc3f8  vmovaps xmm8, [rsp+0x50]
0000794c94ddc3fe  movaps xmm14, xmm8
0000794c94ddc402  addpd xmm14, xmm4
0000794c94ddc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000794c94ddc40d  ptest xmm3, xmm3
0000794c94ddc412  jnz 0x0000794C94DDF702
0000794c94ddc418  vmovaps xmm8, [rsp+0x40]
0000794c94ddc41e  vpermilpd xmm8, xmm8, 0x00
0000794c94ddc424  movaps xmm4, xmm13
0000794c94ddc428  mulpd xmm4, xmm8
0000794c94ddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000794c94ddc432  ptest xmm3, xmm3
0000794c94ddc437  jnz 0x0000794C94DDF845
0000794c94ddc43d  movaps xmm13, xmm15
0000794c94ddc441  addpd xmm13, xmm9
0000794c94ddc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000794c94ddc44c  ptest xmm8, xmm8
0000794c94ddc452  jnz 0x0000794C94DDF987
0000794c94ddc458  movaps xmm15, xmm1
0000794c94ddc45c  addpd xmm15, xmm5
0000794c94ddc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000794c94ddc467  ptest xmm9, xmm9
0000794c94ddc46d  jnz 0x0000794C94DDFACB
0000794c94ddc473  vmovaps [rsp+0x30], xmm11
0000794c94ddc479  vmovaps xmm1, [rsp+0x30]
0000794c94ddc47f  por xmm11, xmm1
0000794c94ddc484  movaps [r15+0x250], xmm11
0000794c94ddc48c  vmovaps [rsp+0x30], xmm12
0000794c94ddc492  vmovaps xmm1, [rsp+0x30]
0000794c94ddc498  por xmm12, xmm1
0000794c94ddc49d  movaps [r15+0x2A0], xmm12
0000794c94ddc4a5  vmovaps xmm1, [rsp+0xA0]
0000794c94ddc4ae  vmovaps xmm11, [rsp+0xA0]
0000794c94ddc4b7  por xmm1, xmm11
0000794c94ddc4bc  movaps [r15+0x1D0], xmm1
0000794c94ddc4c4  lea r12, [rax+0x40]
0000794c94ddc4c8  movups xmm1, [r13+r12*1]
0000794c94ddc4ce  movaps [r15+0x2C0], xmm1
0000794c94ddc4d6  vmovaps xmm11, [rsp+0x40]
0000794c94ddc4dc  vpermilpd xmm11, xmm11, 0x00
0000794c94ddc4e2  vmovaps xmm8, [rsp+0xE0]
0000794c94ddc4eb  movaps xmm9, xmm8
0000794c94ddc4ef  mulpd xmm9, xmm11
0000794c94ddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000794c94ddc4fa  ptest xmm5, xmm5
0000794c94ddc4ff  jnz 0x0000794C94DDFC17
0000794c94ddc505  movaps xmm11, xmm10
0000794c94ddc509  addpd xmm11, xmm6
0000794c94ddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000794c94ddc514  ptest xmm8, xmm8
0000794c94ddc51a  jnz 0x0000794C94DDFD5B
0000794c94ddc520  movaps xmm10, xmm14
0000794c94ddc524  addpd xmm10, xmm4
0000794c94ddc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000794c94ddc52f  ptest xmm8, xmm8
0000794c94ddc535  jnz 0x0000794C94DDFE9E
0000794c94ddc53b  vmovaps xmm14, [rsp+0x40]
0000794c94ddc541  vpermilpd xmm14, xmm14, 0x00
0000794c94ddc547  movaps xmm8, xmm1
0000794c94ddc54b  mulpd xmm8, xmm14
0000794c94ddc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000794c94ddc556  ptest xmm6, xmm6
0000794c94ddc55b  jnz 0x0000794C94DDFFE1
0000794c94ddc561  movaps xmm1, [r15+0x2B0]
0000794c94ddc569  vmovaps xmm14, [rsp+0x40]
0000794c94ddc56f  vpermilpd xmm14, xmm14, 0x00
0000794c94ddc575  movaps xmm6, xmm1
0000794c94ddc578  mulpd xmm6, xmm14
0000794c94ddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000794c94ddc582  ptest xmm5, xmm5
0000794c94ddc587  jnz 0x0000794C94DE0124
0000794c94ddc58d  vmovaps xmm1, [rsp+0x10]
0000794c94ddc593  vpermilpd xmm1, xmm1, 0x00
0000794c94ddc599  movaps xmm14, xmm12
0000794c94ddc59d  mulpd xmm14, xmm1
0000794c94ddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000794c94ddc5a8  ptest xmm5, xmm5
0000794c94ddc5ad  jnz 0x0000794C94DE0265
0000794c94ddc5b3  movaps xmm1, xmm13
0000794c94ddc5b7  addpd xmm1, xmm9
0000794c94ddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000794c94ddc5c1  ptest xmm12, xmm12
0000794c94ddc5c7  jnz 0x0000794C94DE03A8
0000794c94ddc5cd  vmovaps xmm13, [rsp+0x10]
0000794c94ddc5d3  vpermilpd xmm13, xmm13, 0x00
0000794c94ddc5d9  movaps xmm12, xmm7
0000794c94ddc5dd  mulpd xmm12, xmm13
0000794c94ddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000794c94ddc5e8  ptest xmm9, xmm9
0000794c94ddc5ee  jnz 0x0000794C94DE04EA
0000794c94ddc5f4  movaps xmm13, xmm15
0000794c94ddc5f8  addpd xmm13, xmm8
0000794c94ddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000794c94ddc603  ptest xmm9, xmm9
0000794c94ddc609  jnz 0x0000794C94DE062D
0000794c94ddc60f  movaps xmm15, [r15+0x290]
0000794c94ddc617  vmovaps xmm9, [rsp+0x10]
0000794c94ddc61d  vpermilpd xmm9, xmm9, 0x00
0000794c94ddc623  movaps xmm8, xmm15
0000794c94ddc627  mulpd xmm8, xmm9
0000794c94ddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000794c94ddc632  ptest xmm7, xmm7
0000794c94ddc637  jnz 0x0000794C94DE0771
0000794c94ddc63d  movaps xmm15, xmm11
0000794c94ddc641  addpd xmm15, xmm6
0000794c94ddc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000794c94ddc64c  ptest xmm9, xmm9
0000794c94ddc652  jnz 0x0000794C94DE08B5
0000794c94ddc658  movaps xmm11, [r15+0x1E0]
0000794c94ddc660  vmovaps xmm9, [rsp+0x10]
0000794c94ddc666  vpermilpd xmm9, xmm9, 0x00
0000794c94ddc66c  movaps xmm7, xmm11
0000794c94ddc670  mulpd xmm7, xmm9
0000794c94ddc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000794c94ddc67a  ptest xmm6, xmm6
0000794c94ddc67f  jnz 0x0000794C94DE09F8
0000794c94ddc685  movaps xmm11, xmm10
0000794c94ddc689  addpd xmm11, xmm14
0000794c94ddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000794c94ddc694  ptest xmm9, xmm9
0000794c94ddc69a  jnz 0x0000794C94DE0B3A
0000794c94ddc6a0  lea r12, [rax+0x70]
0000794c94ddc6a4  movups xmm14, [r13+r12*1]
0000794c94ddc6aa  movaps [r15+0x240], xmm14
0000794c94ddc6b2  movaps xmm10, xmm1
0000794c94ddc6b6  addpd xmm10, xmm12
0000794c94ddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000794c94ddc6c1  ptest xmm9, xmm9
0000794c94ddc6c7  jnz 0x0000794C94DE0C88
0000794c94ddc6cd  movaps [r15+0x170], xmm10
0000794c94ddc6d5  vmovaps xmm1, [rsp+0x20]
0000794c94ddc6db  vpermilpd xmm1, xmm1, 0x00
0000794c94ddc6e1  movaps xmm12, xmm14
0000794c94ddc6e5  mulpd xmm12, xmm1
0000794c94ddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000794c94ddc6f0  ptest xmm9, xmm9
0000794c94ddc6f6  jnz 0x0000794C94DE0DCB
0000794c94ddc6fc  vmovaps xmm1, [rsp+0x20]
0000794c94ddc702  vpermilpd xmm1, xmm1, 0x00
0000794c94ddc708  vmovaps xmm9, [rsp+0xB0]
0000794c94ddc711  movaps xmm14, xmm9
0000794c94ddc715  mulpd xmm14, xmm1
0000794c94ddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000794c94ddc720  ptest xmm6, xmm6
0000794c94ddc725  jnz 0x0000794C94DE0F0E
0000794c94ddc72b  movaps [r15+0x180], xmm14
0000794c94ddc733  movaps xmm1, xmm13
0000794c94ddc737  addpd xmm1, xmm8
0000794c94ddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000794c94ddc741  ptest xmm9, xmm9
0000794c94ddc747  jnz 0x0000794C94DE1051
0000794c94ddc74d  movaps [r15+0x210], xmm1
0000794c94ddc755  movups xmm13, [r13+rax*1]
0000794c94ddc75b  lea r12, [rax+0x10]
0000794c94ddc75f  movups xmm9, [r13+r12*1]
0000794c94ddc765  movaps [r15+0x230], xmm9
0000794c94ddc76d  movaps xmm8, xmm15
0000794c94ddc771  addpd xmm8, xmm7
0000794c94ddc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000794c94ddc77c  ptest xmm6, xmm6
0000794c94ddc781  jnz 0x0000794C94DE11A7
0000794c94ddc787  movaps [r15+0x130], xmm8
0000794c94ddc78f  vmovaps xmm15, [rsp+0x20]
0000794c94ddc795  vpermilpd xmm15, xmm15, 0x00
0000794c94ddc79b  movaps xmm7, xmm9
0000794c94ddc79f  mulpd xmm7, xmm15
0000794c94ddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000794c94ddc7a9  ptest xmm6, xmm6
0000794c94ddc7ae  jnz 0x0000794C94DE12EA
0000794c94ddc7b4  movaps [r15+0x220], xmm7
0000794c94ddc7bc  vmovaps xmm15, [rsp+0x20]
0000794c94ddc7c2  vpermilpd xmm15, xmm15, 0x00
0000794c94ddc7c8  movaps xmm9, xmm13
0000794c94ddc7cc  mulpd xmm9, xmm15
0000794c94ddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000794c94ddc7d7  ptest xmm6, xmm6
0000794c94ddc7dc  jnz 0x0000794C94DE142C
0000794c94ddc7e2  movaps xmm15, xmm11
0000794c94ddc7e6  addpd xmm15, xmm12
0000794c94ddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000794c94ddc7f1  ptest xmm13, xmm13
0000794c94ddc7f7  jnz 0x0000794C94DE1570
0000794c94ddc7fd  movaps [r15+0x140], xmm15
0000794c94ddc805  movaps xmm13, xmm10
0000794c94ddc809  addpd xmm13, xmm14
0000794c94ddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000794c94ddc814  ptest xmm12, xmm12
0000794c94ddc81a  jnz 0x0000794C94DE16B4
0000794c94ddc820  movaps [r15+0x150], xmm13
0000794c94ddc828  movaps xmm14, xmm1
0000794c94ddc82c  addpd xmm14, xmm7
0000794c94ddc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000794c94ddc837  ptest xmm12, xmm12
0000794c94ddc83d  jnz 0x0000794C94DE17F8
0000794c94ddc843  movaps [r15+0x160], xmm14
0000794c94ddc84b  movaps xmm1, xmm8
0000794c94ddc84f  addpd xmm1, xmm9
0000794c94ddc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000794c94ddc859  ptest xmm12, xmm12
0000794c94ddc85f  jnz 0x0000794C94DE193A
0000794c94ddc865  movaps [r15+0x120], xmm1
0000794c94ddc86d  movups [r13+r14*1], xmm15
0000794c94ddc873  lea rax, [r14+0x10]
0000794c94ddc877  movups [r13+rax*1], xmm13
0000794c94ddc87d  lea rax, [r14+0x20]
0000794c94ddc881  movups [r13+rax*1], xmm14
0000794c94ddc887  lea rax, [r14+0x30]
0000794c94ddc88b  movups [r13+rax*1], xmm1
0000794c94ddc891  mov eax, [r15+0x108]
0000794c94ddc898  sahf
0000794c94ddc899  jnz 0x0000794C94DDC8CB
0000794c94ddc89b  cmp dword ptr [r15+0x318], 0x00
0000794c94ddc8a3  jz 0x0000794C94DDB900
0000794c94ddc8a9  nop [rax+rax*1], ax
0000794c94ddc8b2  nop [rax+rax*1], eax
0000794c94ddc8ba  mov eax, 0x410444
0000794c94ddc8bf  mov [r15+0x100], rax
0000794c94ddc8c6  jmp 0x0000794C94BFE110
0000794c94ddc8cb  cmp dword ptr [r15+0x318], 0x00
0000794c94ddc8d3  jz 0x0000794C94DD57E0
0000794c94ddc8d9  nop [rax+rax*1], ax
0000794c94ddc8e2  nop [rax+rax*1], eax
0000794c94ddc8ea  mov eax, 0x410278
0000794c94ddc8ef  mov [r15+0x100], rax
0000794c94ddc8f6  jmp 0x0000794C94BFE110
0000794c94ddc8fb  int3
0000794c94ddc8fc  call 0x0000794C94CE27E0
0000794c94ddc901  jmp 0x0000794C94DDB9DF
0000794c94ddc906  call 0x0000794C94CE1570
0000794c94ddc90b  jmp 0x0000794C94DDB9E8
0000794c94ddc910  call 0x0000794C94CE27E0
0000794c94ddc915  jmp 0x0000794C94DDBA44
0000794c94ddc91a  call 0x0000794C94CE1570
0000794c94ddc91f  jmp 0x0000794C94DDBA4D
0000794c94ddc924  call 0x0000794C94CE27E0
0000794c94ddc929  jmp 0x0000794C94DDBA90
0000794c94ddc92e  call 0x0000794C94CE1570
0000794c94ddc933  jmp 0x0000794C94DDBA99
0000794c94ddc938  call 0x0000794C94C0DC20
0000794c94ddc93d  jmp 0x0000794C94DDBAD8
0000794c94ddc942  call 0x0000794C94CD59C0
0000794c94ddc947  jmp 0x0000794C94DDBAEB
0000794c94ddc94c  call 0x0000794C94CE0E30
0000794c94ddc951  jmp 0x0000794C94DDBB09
0000794c94ddc956  call 0x0000794C94CDFBC0
0000794c94ddc95b  jmp 0x0000794C94DDBB13
0000794c94ddc960  call 0x0000794C94CDE950
0000794c94ddc965  jmp 0x0000794C94DDBB1D
0000794c94ddc96a  sub rsp, 0x08
0000794c94ddc96e  push rax
0000794c94ddc96f  push rcx
0000794c94ddc970  push rdx
0000794c94ddc971  push rdi
0000794c94ddc972  push rsi
0000794c94ddc973  push r8
0000794c94ddc975  push r9
0000794c94ddc977  push r10
0000794c94ddc979  push r11
0000794c94ddc97b  sub rsp, 0xF0
0000794c94ddc982  vmovaps [rsp], xmm0
0000794c94ddc987  vmovaps [rsp+0x10], xmm1
0000794c94ddc98d  vmovaps [rsp+0x20], xmm2
0000794c94ddc993  vmovaps [rsp+0x30], xmm3
0000794c94ddc999  vmovaps [rsp+0x40], xmm4
0000794c94ddc99f  vmovaps [rsp+0x50], xmm5
0000794c94ddc9a5  vmovaps [rsp+0x60], xmm6
0000794c94ddc9ab  vmovaps [rsp+0x70], xmm7
0000794c94ddc9b1  vmovaps [rsp+0x80], xmm9
0000794c94ddc9ba  vmovaps [rsp+0x90], xmm10
0000794c94ddc9c3  vmovaps [rsp+0xA0], xmm11
0000794c94ddc9cc  vmovaps [rsp+0xB0], xmm12
0000794c94ddc9d5  vmovaps [rsp+0xC0], xmm13
0000794c94ddc9de  vmovaps [rsp+0xD0], xmm14
0000794c94ddc9e7  vmovaps [rsp+0xE0], xmm15
0000794c94ddc9f0  sub rsp, 0x30
0000794c94ddc9f4  movaps [rsp], xmm8
0000794c94ddc9f9  movaps [rsp+0x10], xmm12
0000794c94ddc9ff  movaps [rsp+0x20], xmm15
0000794c94ddca05  lea rdi, [rsp]
0000794c94ddca09  mov esi, 0x00
0000794c94ddca0e  mov rax, 0x5AB2B8B81530
0000794c94ddca18  call rax
0000794c94ddca1a  movaps xmm8, [rsp]
0000794c94ddca1f  add rsp, 0x30
0000794c94ddca23  vmovaps xmm0, [rsp]
0000794c94ddca28  vmovaps xmm1, [rsp+0x10]
0000794c94ddca2e  vmovaps xmm2, [rsp+0x20]
0000794c94ddca34  vmovaps xmm3, [rsp+0x30]
0000794c94ddca3a  vmovaps xmm4, [rsp+0x40]
0000794c94ddca40  vmovaps xmm5, [rsp+0x50]
0000794c94ddca46  vmovaps xmm6, [rsp+0x60]
0000794c94ddca4c  vmovaps xmm7, [rsp+0x70]
0000794c94ddca52  vmovaps xmm9, [rsp+0x80]
0000794c94ddca5b  vmovaps xmm10, [rsp+0x90]
0000794c94ddca64  vmovaps xmm11, [rsp+0xA0]
0000794c94ddca6d  vmovaps xmm12, [rsp+0xB0]
0000794c94ddca76  vmovaps xmm13, [rsp+0xC0]
0000794c94ddca7f  vmovaps xmm14, [rsp+0xD0]
0000794c94ddca88  vmovaps xmm15, [rsp+0xE0]
0000794c94ddca91  add rsp, 0xF0
0000794c94ddca98  pop r11
0000794c94ddca9a  pop r10
0000794c94ddca9c  pop r9
0000794c94ddca9e  pop r8
0000794c94ddcaa0  pop rsi
0000794c94ddcaa1  pop rdi
0000794c94ddcaa2  pop rdx
0000794c94ddcaa3  pop rcx
0000794c94ddcaa4  pop rax
0000794c94ddcaa5  add rsp, 0x08
0000794c94ddcaa9  jmp 0x0000794C94DDBB47
0000794c94ddcaae  sub rsp, 0x08
0000794c94ddcab2  push rax
0000794c94ddcab3  push rcx
0000794c94ddcab4  push rdx
0000794c94ddcab5  push rdi
0000794c94ddcab6  push rsi
0000794c94ddcab7  push r8
0000794c94ddcab9  push r9
0000794c94ddcabb  push r10
0000794c94ddcabd  push r11
0000794c94ddcabf  sub rsp, 0xF0
0000794c94ddcac6  vmovaps [rsp], xmm0
0000794c94ddcacb  vmovaps [rsp+0x10], xmm1
0000794c94ddcad1  vmovaps [rsp+0x20], xmm2
0000794c94ddcad7  vmovaps [rsp+0x30], xmm3
0000794c94ddcadd  vmovaps [rsp+0x40], xmm4
0000794c94ddcae3  vmovaps [rsp+0x50], xmm5
0000794c94ddcae9  vmovaps [rsp+0x60], xmm6
0000794c94ddcaef  vmovaps [rsp+0x70], xmm8
0000794c94ddcaf5  vmovaps [rsp+0x80], xmm9
0000794c94ddcafe  vmovaps [rsp+0x90], xmm10
0000794c94ddcb07  vmovaps [rsp+0xA0], xmm11
0000794c94ddcb10  vmovaps [rsp+0xB0], xmm12
0000794c94ddcb19  vmovaps [rsp+0xC0], xmm13
0000794c94ddcb22  vmovaps [rsp+0xD0], xmm14
0000794c94ddcb2b  vmovaps [rsp+0xE0], xmm15
0000794c94ddcb34  sub rsp, 0x30
0000794c94ddcb38  movaps [rsp], xmm7
0000794c94ddcb3c  movaps [rsp+0x10], xmm9
0000794c94ddcb42  movaps [rsp+0x20], xmm15
0000794c94ddcb48  lea rdi, [rsp]
0000794c94ddcb4c  mov esi, 0x00
0000794c94ddcb51  mov rax, 0x5AB2B8B81530
0000794c94ddcb5b  call rax
0000794c94ddcb5d  movaps xmm7, [rsp]
0000794c94ddcb61  add rsp, 0x30
0000794c94ddcb65  vmovaps xmm0, [rsp]
0000794c94ddcb6a  vmovaps xmm1, [rsp+0x10]
0000794c94ddcb70  vmovaps xmm2, [rsp+0x20]
0000794c94ddcb76  vmovaps xmm3, [rsp+0x30]
0000794c94ddcb7c  vmovaps xmm4, [rsp+0x40]
0000794c94ddcb82  vmovaps xmm5, [rsp+0x50]
0000794c94ddcb88  vmovaps xmm6, [rsp+0x60]
0000794c94ddcb8e  vmovaps xmm8, [rsp+0x70]
0000794c94ddcb94  vmovaps xmm9, [rsp+0x80]
0000794c94ddcb9d  vmovaps xmm10, [rsp+0x90]
0000794c94ddcba6  vmovaps xmm11, [rsp+0xA0]
0000794c94ddcbaf  vmovaps xmm12, [rsp+0xB0]
0000794c94ddcbb8  vmovaps xmm13, [rsp+0xC0]
0000794c94ddcbc1  vmovaps xmm14, [rsp+0xD0]
0000794c94ddcbca  vmovaps xmm15, [rsp+0xE0]
0000794c94ddcbd3  add rsp, 0xF0
0000794c94ddcbda  pop r11
0000794c94ddcbdc  pop r10
0000794c94ddcbde  pop r9
0000794c94ddcbe0  pop r8
0000794c94ddcbe2  pop rsi
0000794c94ddcbe3  pop rdi
0000794c94ddcbe4  pop rdx
0000794c94ddcbe5  pop rcx
0000794c94ddcbe6  pop rax
0000794c94ddcbe7  add rsp, 0x08
0000794c94ddcbeb  jmp 0x0000794C94DDBB75
0000794c94ddcbf0  sub rsp, 0x08
0000794c94ddcbf4  push rax
0000794c94ddcbf5  push rcx
0000794c94ddcbf6  push rdx
0000794c94ddcbf7  push rdi
0000794c94ddcbf8  push rsi
0000794c94ddcbf9  push r8
0000794c94ddcbfb  push r9
0000794c94ddcbfd  push r10
0000794c94ddcbff  push r11
0000794c94ddcc01  sub rsp, 0xF0
0000794c94ddcc08  vmovaps [rsp], xmm0
0000794c94ddcc0d  vmovaps [rsp+0x10], xmm1
0000794c94ddcc13  vmovaps [rsp+0x20], xmm2
0000794c94ddcc19  vmovaps [rsp+0x30], xmm3
0000794c94ddcc1f  vmovaps [rsp+0x40], xmm4
0000794c94ddcc25  vmovaps [rsp+0x50], xmm5
0000794c94ddcc2b  vmovaps [rsp+0x60], xmm6
0000794c94ddcc31  vmovaps [rsp+0x70], xmm7
0000794c94ddcc37  vmovaps [rsp+0x80], xmm8
0000794c94ddcc40  vmovaps [rsp+0x90], xmm10
0000794c94ddcc49  vmovaps [rsp+0xA0], xmm11
0000794c94ddcc52  vmovaps [rsp+0xB0], xmm12
0000794c94ddcc5b  vmovaps [rsp+0xC0], xmm13
0000794c94ddcc64  vmovaps [rsp+0xD0], xmm14
0000794c94ddcc6d  vmovaps [rsp+0xE0], xmm15
0000794c94ddcc76  sub rsp, 0x30
0000794c94ddcc7a  movaps [rsp], xmm9
0000794c94ddcc7f  movaps [rsp+0x10], xmm12
0000794c94ddcc85  movaps [rsp+0x20], xmm10
0000794c94ddcc8b  lea rdi, [rsp]
0000794c94ddcc8f  mov esi, 0x00
0000794c94ddcc94  mov rax, 0x5AB2B8B81530
0000794c94ddcc9e  call rax
0000794c94ddcca0  movaps xmm9, [rsp]
0000794c94ddcca5  add rsp, 0x30
0000794c94ddcca9  vmovaps xmm0, [rsp]
0000794c94ddccae  vmovaps xmm1, [rsp+0x10]
0000794c94ddccb4  vmovaps xmm2, [rsp+0x20]
0000794c94ddccba  vmovaps xmm3, [rsp+0x30]
0000794c94ddccc0  vmovaps xmm4, [rsp+0x40]
0000794c94ddccc6  vmovaps xmm5, [rsp+0x50]
0000794c94ddcccc  vmovaps xmm6, [rsp+0x60]
0000794c94ddccd2  vmovaps xmm7, [rsp+0x70]
0000794c94ddccd8  vmovaps xmm8, [rsp+0x80]
0000794c94ddcce1  vmovaps xmm10, [rsp+0x90]
0000794c94ddccea  vmovaps xmm11, [rsp+0xA0]
0000794c94ddccf3  vmovaps xmm12, [rsp+0xB0]
0000794c94ddccfc  vmovaps xmm13, [rsp+0xC0]
0000794c94ddcd05  vmovaps xmm14, [rsp+0xD0]
0000794c94ddcd0e  vmovaps xmm15, [rsp+0xE0]
0000794c94ddcd17  add rsp, 0xF0
0000794c94ddcd1e  pop r11
0000794c94ddcd20  pop r10
0000794c94ddcd22  pop r9
0000794c94ddcd24  pop r8
0000794c94ddcd26  pop rsi
0000794c94ddcd27  pop rdi
0000794c94ddcd28  pop rdx
0000794c94ddcd29  pop rcx
0000794c94ddcd2a  pop rax
0000794c94ddcd2b  add rsp, 0x08
0000794c94ddcd2f  jmp 0x0000794C94DDBB99
0000794c94ddcd34  sub rsp, 0x08
0000794c94ddcd38  push rax
0000794c94ddcd39  push rcx
0000794c94ddcd3a  push rdx
0000794c94ddcd3b  push rdi
0000794c94ddcd3c  push rsi
0000794c94ddcd3d  push r8
0000794c94ddcd3f  push r9
0000794c94ddcd41  push r10
0000794c94ddcd43  push r11
0000794c94ddcd45  sub rsp, 0xF0
0000794c94ddcd4c  vmovaps [rsp], xmm0
0000794c94ddcd51  vmovaps [rsp+0x10], xmm1
0000794c94ddcd57  vmovaps [rsp+0x20], xmm2
0000794c94ddcd5d  vmovaps [rsp+0x30], xmm3
0000794c94ddcd63  vmovaps [rsp+0x40], xmm4
0000794c94ddcd69  vmovaps [rsp+0x50], xmm5
0000794c94ddcd6f  vmovaps [rsp+0x60], xmm6
0000794c94ddcd75  vmovaps [rsp+0x70], xmm7
0000794c94ddcd7b  vmovaps [rsp+0x80], xmm8
0000794c94ddcd84  vmovaps [rsp+0x90], xmm9
0000794c94ddcd8d  vmovaps [rsp+0xA0], xmm11
0000794c94ddcd96  vmovaps [rsp+0xB0], xmm12
0000794c94ddcd9f  vmovaps [rsp+0xC0], xmm13
0000794c94ddcda8  vmovaps [rsp+0xD0], xmm14
0000794c94ddcdb1  vmovaps [rsp+0xE0], xmm15
0000794c94ddcdba  sub rsp, 0x30
0000794c94ddcdbe  movaps [rsp], xmm10
0000794c94ddcdc3  movaps [rsp+0x10], xmm12
0000794c94ddcdc9  movaps [rsp+0x20], xmm11
0000794c94ddcdcf  lea rdi, [rsp]
0000794c94ddcdd3  mov esi, 0x00
0000794c94ddcdd8  mov rax, 0x5AB2B8B81530
0000794c94ddcde2  call rax
0000794c94ddcde4  movaps xmm10, [rsp]
0000794c94ddcde9  add rsp, 0x30
0000794c94ddcded  vmovaps xmm0, [rsp]
0000794c94ddcdf2  vmovaps xmm1, [rsp+0x10]
0000794c94ddcdf8  vmovaps xmm2, [rsp+0x20]
0000794c94ddcdfe  vmovaps xmm3, [rsp+0x30]
0000794c94ddce04  vmovaps xmm4, [rsp+0x40]
0000794c94ddce0a  vmovaps xmm5, [rsp+0x50]
0000794c94ddce10  vmovaps xmm6, [rsp+0x60]
0000794c94ddce16  vmovaps xmm7, [rsp+0x70]
0000794c94ddce1c  vmovaps xmm8, [rsp+0x80]
0000794c94ddce25  vmovaps xmm9, [rsp+0x90]
0000794c94ddce2e  vmovaps xmm11, [rsp+0xA0]
0000794c94ddce37  vmovaps xmm12, [rsp+0xB0]
0000794c94ddce40  vmovaps xmm13, [rsp+0xC0]
0000794c94ddce49  vmovaps xmm14, [rsp+0xD0]
0000794c94ddce52  vmovaps xmm15, [rsp+0xE0]
0000794c94ddce5b  add rsp, 0xF0
0000794c94ddce62  pop r11
0000794c94ddce64  pop r10
0000794c94ddce66  pop r9
0000794c94ddce68  pop r8
0000794c94ddce6a  pop rsi
0000794c94ddce6b  pop rdi
0000794c94ddce6c  pop rdx
0000794c94ddce6d  pop rcx
0000794c94ddce6e  pop rax
0000794c94ddce6f  add rsp, 0x08
0000794c94ddce73  jmp 0x0000794C94DDBBB3
0000794c94ddce78  sub rsp, 0x08
0000794c94ddce7c  push rax
0000794c94ddce7d  push rcx
0000794c94ddce7e  push rdx
0000794c94ddce7f  push rdi
0000794c94ddce80  push rsi
0000794c94ddce81  push r8
0000794c94ddce83  push r9
0000794c94ddce85  push r10
0000794c94ddce87  push r11
0000794c94ddce89  sub rsp, 0xF0
0000794c94ddce90  vmovaps [rsp], xmm0
0000794c94ddce95  vmovaps [rsp+0x10], xmm1
0000794c94ddce9b  vmovaps [rsp+0x20], xmm2
0000794c94ddcea1  vmovaps [rsp+0x30], xmm3
0000794c94ddcea7  vmovaps [rsp+0x40], xmm4
0000794c94ddcead  vmovaps [rsp+0x50], xmm5
0000794c94ddceb3  vmovaps [rsp+0x60], xmm7
0000794c94ddceb9  vmovaps [rsp+0x70], xmm8
0000794c94ddcebf  vmovaps [rsp+0x80], xmm9
0000794c94ddcec8  vmovaps [rsp+0x90], xmm10
0000794c94ddced1  vmovaps [rsp+0xA0], xmm11
0000794c94ddceda  vmovaps [rsp+0xB0], xmm12
0000794c94ddcee3  vmovaps [rsp+0xC0], xmm13
0000794c94ddceec  vmovaps [rsp+0xD0], xmm14
0000794c94ddcef5  vmovaps [rsp+0xE0], xmm15
0000794c94ddcefe  sub rsp, 0x30
0000794c94ddcf02  movaps [rsp], xmm6
0000794c94ddcf06  movaps [rsp+0x10], xmm12
0000794c94ddcf0c  movaps [rsp+0x20], xmm11
0000794c94ddcf12  lea rdi, [rsp]
0000794c94ddcf16  mov esi, 0x00
0000794c94ddcf1b  mov rax, 0x5AB2B8B81530
0000794c94ddcf25  call rax
0000794c94ddcf27  movaps xmm6, [rsp]
0000794c94ddcf2b  add rsp, 0x30
0000794c94ddcf2f  vmovaps xmm0, [rsp]
0000794c94ddcf34  vmovaps xmm1, [rsp+0x10]
0000794c94ddcf3a  vmovaps xmm2, [rsp+0x20]
0000794c94ddcf40  vmovaps xmm3, [rsp+0x30]
0000794c94ddcf46  vmovaps xmm4, [rsp+0x40]
0000794c94ddcf4c  vmovaps xmm5, [rsp+0x50]
0000794c94ddcf52  vmovaps xmm7, [rsp+0x60]
0000794c94ddcf58  vmovaps xmm8, [rsp+0x70]
0000794c94ddcf5e  vmovaps xmm9, [rsp+0x80]
0000794c94ddcf67  vmovaps xmm10, [rsp+0x90]
0000794c94ddcf70  vmovaps xmm11, [rsp+0xA0]
0000794c94ddcf79  vmovaps xmm12, [rsp+0xB0]
0000794c94ddcf82  vmovaps xmm13, [rsp+0xC0]
0000794c94ddcf8b  vmovaps xmm14, [rsp+0xD0]
0000794c94ddcf94  vmovaps xmm15, [rsp+0xE0]
0000794c94ddcf9d  add rsp, 0xF0
0000794c94ddcfa4  pop r11
0000794c94ddcfa6  pop r10
0000794c94ddcfa8  pop r9
0000794c94ddcfaa  pop r8
0000794c94ddcfac  pop rsi
0000794c94ddcfad  pop rdi
0000794c94ddcfae  pop rdx
0000794c94ddcfaf  pop rcx
0000794c94ddcfb0  pop rax
0000794c94ddcfb1  add rsp, 0x08
0000794c94ddcfb5  jmp 0x0000794C94DDBBD4
0000794c94ddcfba  sub rsp, 0x08
0000794c94ddcfbe  push rax
0000794c94ddcfbf  push rcx
0000794c94ddcfc0  push rdx
0000794c94ddcfc1  push rdi
0000794c94ddcfc2  push rsi
0000794c94ddcfc3  push r8
0000794c94ddcfc5  push r9
0000794c94ddcfc7  push r10
0000794c94ddcfc9  push r11
0000794c94ddcfcb  sub rsp, 0xF0
0000794c94ddcfd2  vmovaps [rsp], xmm0
0000794c94ddcfd7  vmovaps [rsp+0x10], xmm1
0000794c94ddcfdd  vmovaps [rsp+0x20], xmm2
0000794c94ddcfe3  vmovaps [rsp+0x30], xmm4
0000794c94ddcfe9  vmovaps [rsp+0x40], xmm5
0000794c94ddcfef  vmovaps [rsp+0x50], xmm6
0000794c94ddcff5  vmovaps [rsp+0x60], xmm7
0000794c94ddcffb  vmovaps [rsp+0x70], xmm8
0000794c94ddd001  vmovaps [rsp+0x80], xmm9
0000794c94ddd00a  vmovaps [rsp+0x90], xmm10
0000794c94ddd013  vmovaps [rsp+0xA0], xmm11
0000794c94ddd01c  vmovaps [rsp+0xB0], xmm12
0000794c94ddd025  vmovaps [rsp+0xC0], xmm13
0000794c94ddd02e  vmovaps [rsp+0xD0], xmm14
0000794c94ddd037  vmovaps [rsp+0xE0], xmm15
0000794c94ddd040  sub rsp, 0x30
0000794c94ddd044  movaps [rsp], xmm3
0000794c94ddd048  movaps [rsp+0x10], xmm5
0000794c94ddd04d  movaps [rsp+0x20], xmm4
0000794c94ddd052  lea rdi, [rsp]
0000794c94ddd056  mov esi, 0x00
0000794c94ddd05b  mov rax, 0x5AB2B8B81530
0000794c94ddd065  call rax
0000794c94ddd067  movaps xmm3, [rsp]
0000794c94ddd06b  add rsp, 0x30
0000794c94ddd06f  vmovaps xmm0, [rsp]
0000794c94ddd074  vmovaps xmm1, [rsp+0x10]
0000794c94ddd07a  vmovaps xmm2, [rsp+0x20]
0000794c94ddd080  vmovaps xmm4, [rsp+0x30]
0000794c94ddd086  vmovaps xmm5, [rsp+0x40]
0000794c94ddd08c  vmovaps xmm6, [rsp+0x50]
0000794c94ddd092  vmovaps xmm7, [rsp+0x60]
0000794c94ddd098  vmovaps xmm8, [rsp+0x70]
0000794c94ddd09e  vmovaps xmm9, [rsp+0x80]
0000794c94ddd0a7  vmovaps xmm10, [rsp+0x90]
0000794c94ddd0b0  vmovaps xmm11, [rsp+0xA0]
0000794c94ddd0b9  vmovaps xmm12, [rsp+0xB0]
0000794c94ddd0c2  vmovaps xmm13, [rsp+0xC0]
0000794c94ddd0cb  vmovaps xmm14, [rsp+0xD0]
0000794c94ddd0d4  vmovaps xmm15, [rsp+0xE0]
0000794c94ddd0dd  add rsp, 0xF0
0000794c94ddd0e4  pop r11
0000794c94ddd0e6  pop r10
0000794c94ddd0e8  pop r9
0000794c94ddd0ea  pop r8
0000794c94ddd0ec  pop rsi
0000794c94ddd0ed  pop rdi
0000794c94ddd0ee  pop rdx
0000794c94ddd0ef  pop rcx
0000794c94ddd0f0  pop rax
0000794c94ddd0f1  add rsp, 0x08
0000794c94ddd0f5  jmp 0x0000794C94DDBC35
0000794c94ddd0fa  sub rsp, 0x08
0000794c94ddd0fe  push rax
0000794c94ddd0ff  push rcx
0000794c94ddd100  push rdx
0000794c94ddd101  push rdi
0000794c94ddd102  push rsi
0000794c94ddd103  push r8
0000794c94ddd105  push r9
0000794c94ddd107  push r10
0000794c94ddd109  push r11
0000794c94ddd10b  sub rsp, 0xF0
0000794c94ddd112  vmovaps [rsp], xmm0
0000794c94ddd117  vmovaps [rsp+0x10], xmm1
0000794c94ddd11d  vmovaps [rsp+0x20], xmm2
0000794c94ddd123  vmovaps [rsp+0x30], xmm3
0000794c94ddd129  vmovaps [rsp+0x40], xmm4
0000794c94ddd12f  vmovaps [rsp+0x50], xmm6
0000794c94ddd135  vmovaps [rsp+0x60], xmm7
0000794c94ddd13b  vmovaps [rsp+0x70], xmm8
0000794c94ddd141  vmovaps [rsp+0x80], xmm9
0000794c94ddd14a  vmovaps [rsp+0x90], xmm10
0000794c94ddd153  vmovaps [rsp+0xA0], xmm11
0000794c94ddd15c  vmovaps [rsp+0xB0], xmm12
0000794c94ddd165  vmovaps [rsp+0xC0], xmm13
0000794c94ddd16e  vmovaps [rsp+0xD0], xmm14
0000794c94ddd177  vmovaps [rsp+0xE0], xmm15
0000794c94ddd180  sub rsp, 0x30
0000794c94ddd184  movaps [rsp], xmm5
0000794c94ddd188  movaps [rsp+0x10], xmm8
0000794c94ddd18e  movaps [rsp+0x20], xmm15
0000794c94ddd194  lea rdi, [rsp]
0000794c94ddd198  mov esi, 0x00
0000794c94ddd19d  mov rax, 0x5AB2B8B81530
0000794c94ddd1a7  call rax
0000794c94ddd1a9  movaps xmm5, [rsp]
0000794c94ddd1ad  add rsp, 0x30
0000794c94ddd1b1  vmovaps xmm0, [rsp]
0000794c94ddd1b6  vmovaps xmm1, [rsp+0x10]
0000794c94ddd1bc  vmovaps xmm2, [rsp+0x20]
0000794c94ddd1c2  vmovaps xmm3, [rsp+0x30]
0000794c94ddd1c8  vmovaps xmm4, [rsp+0x40]
0000794c94ddd1ce  vmovaps xmm6, [rsp+0x50]
0000794c94ddd1d4  vmovaps xmm7, [rsp+0x60]
0000794c94ddd1da  vmovaps xmm8, [rsp+0x70]
0000794c94ddd1e0  vmovaps xmm9, [rsp+0x80]
0000794c94ddd1e9  vmovaps xmm10, [rsp+0x90]
0000794c94ddd1f2  vmovaps xmm11, [rsp+0xA0]
0000794c94ddd1fb  vmovaps xmm12, [rsp+0xB0]
0000794c94ddd204  vmovaps xmm13, [rsp+0xC0]
0000794c94ddd20d  vmovaps xmm14, [rsp+0xD0]
0000794c94ddd216  vmovaps xmm15, [rsp+0xE0]
0000794c94ddd21f  add rsp, 0xF0
0000794c94ddd226  pop r11
0000794c94ddd228  pop r10
0000794c94ddd22a  pop r9
0000794c94ddd22c  pop r8
0000794c94ddd22e  pop rsi
0000794c94ddd22f  pop rdi
0000794c94ddd230  pop rdx
0000794c94ddd231  pop rcx
0000794c94ddd232  pop rax
0000794c94ddd233  add rsp, 0x08
0000794c94ddd237  jmp 0x0000794C94DDBC73
0000794c94ddd23c  sub rsp, 0x08
0000794c94ddd240  push rax
0000794c94ddd241  push rcx
0000794c94ddd242  push rdx
0000794c94ddd243  push rdi
0000794c94ddd244  push rsi
0000794c94ddd245  push r8
0000794c94ddd247  push r9
0000794c94ddd249  push r10
0000794c94ddd24b  push r11
0000794c94ddd24d  sub rsp, 0xF0
0000794c94ddd254  vmovaps [rsp], xmm0
0000794c94ddd259  vmovaps [rsp+0x10], xmm1
0000794c94ddd25f  vmovaps [rsp+0x20], xmm2
0000794c94ddd265  vmovaps [rsp+0x30], xmm3
0000794c94ddd26b  vmovaps [rsp+0x40], xmm5
0000794c94ddd271  vmovaps [rsp+0x50], xmm6
0000794c94ddd277  vmovaps [rsp+0x60], xmm7
0000794c94ddd27d  vmovaps [rsp+0x70], xmm8
0000794c94ddd283  vmovaps [rsp+0x80], xmm9
0000794c94ddd28c  vmovaps [rsp+0x90], xmm10
0000794c94ddd295  vmovaps [rsp+0xA0], xmm11
0000794c94ddd29e  vmovaps [rsp+0xB0], xmm12
0000794c94ddd2a7  vmovaps [rsp+0xC0], xmm13
0000794c94ddd2b0  vmovaps [rsp+0xD0], xmm14
0000794c94ddd2b9  vmovaps [rsp+0xE0], xmm15
0000794c94ddd2c2  sub rsp, 0x30
0000794c94ddd2c6  movaps [rsp], xmm4
0000794c94ddd2ca  movaps [rsp+0x10], xmm9
0000794c94ddd2d0  movaps [rsp+0x20], xmm8
0000794c94ddd2d6  lea rdi, [rsp]
0000794c94ddd2da  mov esi, 0x00
0000794c94ddd2df  mov rax, 0x5AB2B8B81530
0000794c94ddd2e9  call rax
0000794c94ddd2eb  movaps xmm4, [rsp]
0000794c94ddd2ef  add rsp, 0x30
0000794c94ddd2f3  vmovaps xmm0, [rsp]
0000794c94ddd2f8  vmovaps xmm1, [rsp+0x10]
0000794c94ddd2fe  vmovaps xmm2, [rsp+0x20]
0000794c94ddd304  vmovaps xmm3, [rsp+0x30]
0000794c94ddd30a  vmovaps xmm5, [rsp+0x40]
0000794c94ddd310  vmovaps xmm6, [rsp+0x50]
0000794c94ddd316  vmovaps xmm7, [rsp+0x60]
0000794c94ddd31c  vmovaps xmm8, [rsp+0x70]
0000794c94ddd322  vmovaps xmm9, [rsp+0x80]
0000794c94ddd32b  vmovaps xmm10, [rsp+0x90]
0000794c94ddd334  vmovaps xmm11, [rsp+0xA0]
0000794c94ddd33d  vmovaps xmm12, [rsp+0xB0]
0000794c94ddd346  vmovaps xmm13, [rsp+0xC0]
0000794c94ddd34f  vmovaps xmm14, [rsp+0xD0]
0000794c94ddd358  vmovaps xmm15, [rsp+0xE0]
0000794c94ddd361  add rsp, 0xF0
0000794c94ddd368  pop r11
0000794c94ddd36a  pop r10
0000794c94ddd36c  pop r9
0000794c94ddd36e  pop r8
0000794c94ddd370  pop rsi
0000794c94ddd371  pop rdi
0000794c94ddd372  pop rdx
0000794c94ddd373  pop rcx
0000794c94ddd374  pop rax
0000794c94ddd375  add rsp, 0x08
0000794c94ddd379  jmp 0x0000794C94DDBC94
0000794c94ddd37e  sub rsp, 0x08
0000794c94ddd382  push rax
0000794c94ddd383  push rcx
0000794c94ddd384  push rdx
0000794c94ddd385  push rdi
0000794c94ddd386  push rsi
0000794c94ddd387  push r8
0000794c94ddd389  push r9
0000794c94ddd38b  push r10
0000794c94ddd38d  push r11
0000794c94ddd38f  sub rsp, 0xF0
0000794c94ddd396  vmovaps [rsp], xmm0
0000794c94ddd39b  vmovaps [rsp+0x10], xmm1
0000794c94ddd3a1  vmovaps [rsp+0x20], xmm2
0000794c94ddd3a7  vmovaps [rsp+0x30], xmm3
0000794c94ddd3ad  vmovaps [rsp+0x40], xmm4
0000794c94ddd3b3  vmovaps [rsp+0x50], xmm5
0000794c94ddd3b9  vmovaps [rsp+0x60], xmm6
0000794c94ddd3bf  vmovaps [rsp+0x70], xmm7
0000794c94ddd3c5  vmovaps [rsp+0x80], xmm8
0000794c94ddd3ce  vmovaps [rsp+0x90], xmm10
0000794c94ddd3d7  vmovaps [rsp+0xA0], xmm11
0000794c94ddd3e0  vmovaps [rsp+0xB0], xmm12
0000794c94ddd3e9  vmovaps [rsp+0xC0], xmm13
0000794c94ddd3f2  vmovaps [rsp+0xD0], xmm14
0000794c94ddd3fb  vmovaps [rsp+0xE0], xmm15
0000794c94ddd404  sub rsp, 0x30
0000794c94ddd408  movaps [rsp], xmm9
0000794c94ddd40d  movaps [rsp+0x10], xmm10
0000794c94ddd413  movaps [rsp+0x20], xmm8
0000794c94ddd419  lea rdi, [rsp]
0000794c94ddd41d  mov esi, 0x00
0000794c94ddd422  mov rax, 0x5AB2B8B81530
0000794c94ddd42c  call rax
0000794c94ddd42e  movaps xmm9, [rsp]
0000794c94ddd433  add rsp, 0x30
0000794c94ddd437  vmovaps xmm0, [rsp]
0000794c94ddd43c  vmovaps xmm1, [rsp+0x10]
0000794c94ddd442  vmovaps xmm2, [rsp+0x20]
0000794c94ddd448  vmovaps xmm3, [rsp+0x30]
0000794c94ddd44e  vmovaps xmm4, [rsp+0x40]
0000794c94ddd454  vmovaps xmm5, [rsp+0x50]
0000794c94ddd45a  vmovaps xmm6, [rsp+0x60]
0000794c94ddd460  vmovaps xmm7, [rsp+0x70]
0000794c94ddd466  vmovaps xmm8, [rsp+0x80]
0000794c94ddd46f  vmovaps xmm10, [rsp+0x90]
0000794c94ddd478  vmovaps xmm11, [rsp+0xA0]
0000794c94ddd481  vmovaps xmm12, [rsp+0xB0]
0000794c94ddd48a  vmovaps xmm13, [rsp+0xC0]
0000794c94ddd493  vmovaps xmm14, [rsp+0xD0]
0000794c94ddd49c  vmovaps xmm15, [rsp+0xE0]
0000794c94ddd4a5  add rsp, 0xF0
0000794c94ddd4ac  pop r11
0000794c94ddd4ae  pop r10
0000794c94ddd4b0  pop r9
0000794c94ddd4b2  pop r8
0000794c94ddd4b4  pop rsi
0000794c94ddd4b5  pop rdi
0000794c94ddd4b6  pop rdx
0000794c94ddd4b7  pop rcx
0000794c94ddd4b8  pop rax
0000794c94ddd4b9  add rsp, 0x08
0000794c94ddd4bd  jmp 0x0000794C94DDBCAE
0000794c94ddd4c2  call 0x0000794C94CB52F0
0000794c94ddd4c7  jmp 0x0000794C94DDBDC8
0000794c94ddd4cc  call 0x0000794C94CB52F0
0000794c94ddd4d1  jmp 0x0000794C94DDBDDE
0000794c94ddd4d6  sub rsp, 0x08
0000794c94ddd4da  push rax
0000794c94ddd4db  push rcx
0000794c94ddd4dc  push rdx
0000794c94ddd4dd  push rdi
0000794c94ddd4de  push rsi
0000794c94ddd4df  push r8
0000794c94ddd4e1  push r9
0000794c94ddd4e3  push r10
0000794c94ddd4e5  push r11
0000794c94ddd4e7  sub rsp, 0xF0
0000794c94ddd4ee  vmovaps [rsp], xmm0
0000794c94ddd4f3  vmovaps [rsp+0x10], xmm2
0000794c94ddd4f9  vmovaps [rsp+0x20], xmm3
0000794c94ddd4ff  vmovaps [rsp+0x30], xmm4
0000794c94ddd505  vmovaps [rsp+0x40], xmm5
0000794c94ddd50b  vmovaps [rsp+0x50], xmm6
0000794c94ddd511  vmovaps [rsp+0x60], xmm7
0000794c94ddd517  vmovaps [rsp+0x70], xmm8
0000794c94ddd51d  vmovaps [rsp+0x80], xmm9
0000794c94ddd526  vmovaps [rsp+0x90], xmm10
0000794c94ddd52f  vmovaps [rsp+0xA0], xmm11
0000794c94ddd538  vmovaps [rsp+0xB0], xmm12
0000794c94ddd541  vmovaps [rsp+0xC0], xmm13
0000794c94ddd54a  vmovaps [rsp+0xD0], xmm14
0000794c94ddd553  vmovaps [rsp+0xE0], xmm15
0000794c94ddd55c  sub rsp, 0x30
0000794c94ddd560  movaps [rsp], xmm1
0000794c94ddd564  movaps [rsp+0x10], xmm6
0000794c94ddd569  movaps [rsp+0x20], xmm15
0000794c94ddd56f  lea rdi, [rsp]
0000794c94ddd573  mov esi, 0x00
0000794c94ddd578  mov rax, 0x5AB2B8B81530
0000794c94ddd582  call rax
0000794c94ddd584  movaps xmm1, [rsp]
0000794c94ddd588  add rsp, 0x30
0000794c94ddd58c  vmovaps xmm0, [rsp]
0000794c94ddd591  vmovaps xmm2, [rsp+0x10]
0000794c94ddd597  vmovaps xmm3, [rsp+0x20]
0000794c94ddd59d  vmovaps xmm4, [rsp+0x30]
0000794c94ddd5a3  vmovaps xmm5, [rsp+0x40]
0000794c94ddd5a9  vmovaps xmm6, [rsp+0x50]
0000794c94ddd5af  vmovaps xmm7, [rsp+0x60]
0000794c94ddd5b5  vmovaps xmm8, [rsp+0x70]
0000794c94ddd5bb  vmovaps xmm9, [rsp+0x80]
0000794c94ddd5c4  vmovaps xmm10, [rsp+0x90]
0000794c94ddd5cd  vmovaps xmm11, [rsp+0xA0]
0000794c94ddd5d6  vmovaps xmm12, [rsp+0xB0]
0000794c94ddd5df  vmovaps xmm13, [rsp+0xC0]
0000794c94ddd5e8  vmovaps xmm14, [rsp+0xD0]
0000794c94ddd5f1  vmovaps xmm15, [rsp+0xE0]
0000794c94ddd5fa  add rsp, 0xF0
0000794c94ddd601  pop r11
0000794c94ddd603  pop r10
0000794c94ddd605  pop r9
0000794c94ddd607  pop r8
0000794c94ddd609  pop rsi
0000794c94ddd60a  pop rdi
0000794c94ddd60b  pop rdx
0000794c94ddd60c  pop rcx
0000794c94ddd60d  pop rax
0000794c94ddd60e  add rsp, 0x08
0000794c94ddd612  jmp 0x0000794C94DDBE1B
0000794c94ddd617  call 0x0000794C94CC4620
0000794c94ddd61c  jmp 0x0000794C94DDBE28
0000794c94ddd621  sub rsp, 0x08
0000794c94ddd625  push rax
0000794c94ddd626  push rcx
0000794c94ddd627  push rdx
0000794c94ddd628  push rdi
0000794c94ddd629  push rsi
0000794c94ddd62a  push r8
0000794c94ddd62c  push r9
0000794c94ddd62e  push r10
0000794c94ddd630  push r11
0000794c94ddd632  sub rsp, 0xF0
0000794c94ddd639  vmovaps [rsp], xmm0
0000794c94ddd63e  vmovaps [rsp+0x10], xmm1
0000794c94ddd644  vmovaps [rsp+0x20], xmm2
0000794c94ddd64a  vmovaps [rsp+0x30], xmm3
0000794c94ddd650  vmovaps [rsp+0x40], xmm4
0000794c94ddd656  vmovaps [rsp+0x50], xmm5
0000794c94ddd65c  vmovaps [rsp+0x60], xmm6
0000794c94ddd662  vmovaps [rsp+0x70], xmm7
0000794c94ddd668  vmovaps [rsp+0x80], xmm8
0000794c94ddd671  vmovaps [rsp+0x90], xmm9
0000794c94ddd67a  vmovaps [rsp+0xA0], xmm10
0000794c94ddd683  vmovaps [rsp+0xB0], xmm11
0000794c94ddd68c  vmovaps [rsp+0xC0], xmm12
0000794c94ddd695  vmovaps [rsp+0xD0], xmm13
0000794c94ddd69e  vmovaps [rsp+0xE0], xmm15
0000794c94ddd6a7  sub rsp, 0x30
0000794c94ddd6ab  movaps [rsp], xmm14
0000794c94ddd6b0  movaps [rsp+0x10], xmm4
0000794c94ddd6b5  movaps [rsp+0x20], xmm3
0000794c94ddd6ba  lea rdi, [rsp]
0000794c94ddd6be  mov esi, 0x00
0000794c94ddd6c3  mov rax, 0x5AB2B8B81530
0000794c94ddd6cd  call rax
0000794c94ddd6cf  movaps xmm14, [rsp]
0000794c94ddd6d4  add rsp, 0x30
0000794c94ddd6d8  vmovaps xmm0, [rsp]
0000794c94ddd6dd  vmovaps xmm1, [rsp+0x10]
0000794c94ddd6e3  vmovaps xmm2, [rsp+0x20]
0000794c94ddd6e9  vmovaps xmm3, [rsp+0x30]
0000794c94ddd6ef  vmovaps xmm4, [rsp+0x40]
0000794c94ddd6f5  vmovaps xmm5, [rsp+0x50]
0000794c94ddd6fb  vmovaps xmm6, [rsp+0x60]
0000794c94ddd701  vmovaps xmm7, [rsp+0x70]
0000794c94ddd707  vmovaps xmm8, [rsp+0x80]
0000794c94ddd710  vmovaps xmm9, [rsp+0x90]
0000794c94ddd719  vmovaps xmm10, [rsp+0xA0]
0000794c94ddd722  vmovaps xmm11, [rsp+0xB0]
0000794c94ddd72b  vmovaps xmm12, [rsp+0xC0]
0000794c94ddd734  vmovaps xmm13, [rsp+0xD0]
0000794c94ddd73d  vmovaps xmm15, [rsp+0xE0]
0000794c94ddd746  add rsp, 0xF0
0000794c94ddd74d  pop r11
0000794c94ddd74f  pop r10
0000794c94ddd751  pop r9
0000794c94ddd753  pop r8
0000794c94ddd755  pop rsi
0000794c94ddd756  pop rdi
0000794c94ddd757  pop rdx
0000794c94ddd758  pop rcx
0000794c94ddd759  pop rax
0000794c94ddd75a  add rsp, 0x08
0000794c94ddd75e  jmp 0x0000794C94DDBE42
0000794c94ddd763  sub rsp, 0x08
0000794c94ddd767  push rax
0000794c94ddd768  push rcx
0000794c94ddd769  push rdx
0000794c94ddd76a  push rdi
0000794c94ddd76b  push rsi
0000794c94ddd76c  push r8
0000794c94ddd76e  push r9
0000794c94ddd770  push r10
0000794c94ddd772  push r11
0000794c94ddd774  sub rsp, 0xF0
0000794c94ddd77b  vmovaps [rsp], xmm0
0000794c94ddd780  vmovaps [rsp+0x10], xmm1
0000794c94ddd786  vmovaps [rsp+0x20], xmm2
0000794c94ddd78c  vmovaps [rsp+0x30], xmm3
0000794c94ddd792  vmovaps [rsp+0x40], xmm4
0000794c94ddd798  vmovaps [rsp+0x50], xmm5
0000794c94ddd79e  vmovaps [rsp+0x60], xmm7
0000794c94ddd7a4  vmovaps [rsp+0x70], xmm8
0000794c94ddd7aa  vmovaps [rsp+0x80], xmm9
0000794c94ddd7b3  vmovaps [rsp+0x90], xmm10
0000794c94ddd7bc  vmovaps [rsp+0xA0], xmm11
0000794c94ddd7c5  vmovaps [rsp+0xB0], xmm12
0000794c94ddd7ce  vmovaps [rsp+0xC0], xmm13
0000794c94ddd7d7  vmovaps [rsp+0xD0], xmm14
0000794c94ddd7e0  vmovaps [rsp+0xE0], xmm15
0000794c94ddd7e9  sub rsp, 0x30
0000794c94ddd7ed  movaps [rsp], xmm6
0000794c94ddd7f1  movaps [rsp+0x10], xmm9
0000794c94ddd7f7  movaps [rsp+0x20], xmm7
0000794c94ddd7fc  lea rdi, [rsp]
0000794c94ddd800  mov esi, 0x00
0000794c94ddd805  mov rax, 0x5AB2B8B81530
0000794c94ddd80f  call rax
0000794c94ddd811  movaps xmm6, [rsp]
0000794c94ddd815  add rsp, 0x30
0000794c94ddd819  vmovaps xmm0, [rsp]
0000794c94ddd81e  vmovaps xmm1, [rsp+0x10]
0000794c94ddd824  vmovaps xmm2, [rsp+0x20]
0000794c94ddd82a  vmovaps xmm3, [rsp+0x30]
0000794c94ddd830  vmovaps xmm4, [rsp+0x40]
0000794c94ddd836  vmovaps xmm5, [rsp+0x50]
0000794c94ddd83c  vmovaps xmm7, [rsp+0x60]
0000794c94ddd842  vmovaps xmm8, [rsp+0x70]
0000794c94ddd848  vmovaps xmm9, [rsp+0x80]
0000794c94ddd851  vmovaps xmm10, [rsp+0x90]
0000794c94ddd85a  vmovaps xmm11, [rsp+0xA0]
0000794c94ddd863  vmovaps xmm12, [rsp+0xB0]
0000794c94ddd86c  vmovaps xmm13, [rsp+0xC0]
0000794c94ddd875  vmovaps xmm14, [rsp+0xD0]
0000794c94ddd87e  vmovaps xmm15, [rsp+0xE0]
0000794c94ddd887  add rsp, 0xF0
0000794c94ddd88e  pop r11
0000794c94ddd890  pop r10
0000794c94ddd892  pop r9
0000794c94ddd894  pop r8
0000794c94ddd896  pop rsi
0000794c94ddd897  pop rdi
0000794c94ddd898  pop rdx
0000794c94ddd899  pop rcx
0000794c94ddd89a  pop rax
0000794c94ddd89b  add rsp, 0x08
0000794c94ddd89f  jmp 0x0000794C94DDBE5A
0000794c94ddd8a4  sub rsp, 0x08
0000794c94ddd8a8  push rax
0000794c94ddd8a9  push rcx
0000794c94ddd8aa  push rdx
0000794c94ddd8ab  push rdi
0000794c94ddd8ac  push rsi
0000794c94ddd8ad  push r8
0000794c94ddd8af  push r9
0000794c94ddd8b1  push r10
0000794c94ddd8b3  push r11
0000794c94ddd8b5  sub rsp, 0xF0
0000794c94ddd8bc  vmovaps [rsp], xmm0
0000794c94ddd8c1  vmovaps [rsp+0x10], xmm1
0000794c94ddd8c7  vmovaps [rsp+0x20], xmm2
0000794c94ddd8cd  vmovaps [rsp+0x30], xmm3
0000794c94ddd8d3  vmovaps [rsp+0x40], xmm4
0000794c94ddd8d9  vmovaps [rsp+0x50], xmm5
0000794c94ddd8df  vmovaps [rsp+0x60], xmm6
0000794c94ddd8e5  vmovaps [rsp+0x70], xmm8
0000794c94ddd8eb  vmovaps [rsp+0x80], xmm9
0000794c94ddd8f4  vmovaps [rsp+0x90], xmm10
0000794c94ddd8fd  vmovaps [rsp+0xA0], xmm11
0000794c94ddd906  vmovaps [rsp+0xB0], xmm12
0000794c94ddd90f  vmovaps [rsp+0xC0], xmm13
0000794c94ddd918  vmovaps [rsp+0xD0], xmm14
0000794c94ddd921  vmovaps [rsp+0xE0], xmm15
0000794c94ddd92a  sub rsp, 0x30
0000794c94ddd92e  movaps [rsp], xmm7
0000794c94ddd932  movaps [rsp+0x10], xmm4
0000794c94ddd937  movaps [rsp+0x20], xmm9
0000794c94ddd93d  lea rdi, [rsp]
0000794c94ddd941  mov esi, 0x00
0000794c94ddd946  mov rax, 0x5AB2B8B81530
0000794c94ddd950  call rax
0000794c94ddd952  movaps xmm7, [rsp]
0000794c94ddd956  add rsp, 0x30
0000794c94ddd95a  vmovaps xmm0, [rsp]
0000794c94ddd95f  vmovaps xmm1, [rsp+0x10]
0000794c94ddd965  vmovaps xmm2, [rsp+0x20]
0000794c94ddd96b  vmovaps xmm3, [rsp+0x30]
0000794c94ddd971  vmovaps xmm4, [rsp+0x40]
0000794c94ddd977  vmovaps xmm5, [rsp+0x50]
0000794c94ddd97d  vmovaps xmm6, [rsp+0x60]
0000794c94ddd983  vmovaps xmm8, [rsp+0x70]
0000794c94ddd989  vmovaps xmm9, [rsp+0x80]
0000794c94ddd992  vmovaps xmm10, [rsp+0x90]
0000794c94ddd99b  vmovaps xmm11, [rsp+0xA0]
0000794c94ddd9a4  vmovaps xmm12, [rsp+0xB0]
0000794c94ddd9ad  vmovaps xmm13, [rsp+0xC0]
0000794c94ddd9b6  vmovaps xmm14, [rsp+0xD0]
0000794c94ddd9bf  vmovaps xmm15, [rsp+0xE0]
0000794c94ddd9c8  add rsp, 0xF0
0000794c94ddd9cf  pop r11
0000794c94ddd9d1  pop r10
0000794c94ddd9d3  pop r9
0000794c94ddd9d5  pop r8
0000794c94ddd9d7  pop rsi
0000794c94ddd9d8  pop rdi
0000794c94ddd9d9  pop rdx
0000794c94ddd9da  pop rcx
0000794c94ddd9db  pop rax
0000794c94ddd9dc  add rsp, 0x08
0000794c94ddd9e0  jmp 0x0000794C94DDBE87
0000794c94ddd9e5  sub rsp, 0x08
0000794c94ddd9e9  push rax
0000794c94ddd9ea  push rcx
0000794c94ddd9eb  push rdx
0000794c94ddd9ec  push rdi
0000794c94ddd9ed  push rsi
0000794c94ddd9ee  push r8
0000794c94ddd9f0  push r9
0000794c94ddd9f2  push r10
0000794c94ddd9f4  push r11
0000794c94ddd9f6  sub rsp, 0xF0
0000794c94ddd9fd  vmovaps [rsp], xmm0
0000794c94ddda02  vmovaps [rsp+0x10], xmm1
0000794c94ddda08  vmovaps [rsp+0x20], xmm2
0000794c94ddda0e  vmovaps [rsp+0x30], xmm3
0000794c94ddda14  vmovaps [rsp+0x40], xmm5
0000794c94ddda1a  vmovaps [rsp+0x50], xmm6
0000794c94ddda20  vmovaps [rsp+0x60], xmm7
0000794c94ddda26  vmovaps [rsp+0x70], xmm8
0000794c94ddda2c  vmovaps [rsp+0x80], xmm9
0000794c94ddda35  vmovaps [rsp+0x90], xmm10
0000794c94ddda3e  vmovaps [rsp+0xA0], xmm11
0000794c94ddda47  vmovaps [rsp+0xB0], xmm12
0000794c94ddda50  vmovaps [rsp+0xC0], xmm13
0000794c94ddda59  vmovaps [rsp+0xD0], xmm14
0000794c94ddda62  vmovaps [rsp+0xE0], xmm15
0000794c94ddda6b  sub rsp, 0x30
0000794c94ddda6f  movaps [rsp], xmm4
0000794c94ddda73  movaps [rsp+0x10], xmm15
0000794c94ddda79  movaps [rsp+0x20], xmm9
0000794c94ddda7f  lea rdi, [rsp]
0000794c94ddda83  mov esi, 0x00
0000794c94ddda88  mov rax, 0x5AB2B8B81530
0000794c94ddda92  call rax
0000794c94ddda94  movaps xmm4, [rsp]
0000794c94ddda98  add rsp, 0x30
0000794c94ddda9c  vmovaps xmm0, [rsp]
0000794c94dddaa1  vmovaps xmm1, [rsp+0x10]
0000794c94dddaa7  vmovaps xmm2, [rsp+0x20]
0000794c94dddaad  vmovaps xmm3, [rsp+0x30]
0000794c94dddab3  vmovaps xmm5, [rsp+0x40]
0000794c94dddab9  vmovaps xmm6, [rsp+0x50]
0000794c94dddabf  vmovaps xmm7, [rsp+0x60]
0000794c94dddac5  vmovaps xmm8, [rsp+0x70]
0000794c94dddacb  vmovaps xmm9, [rsp+0x80]
0000794c94dddad4  vmovaps xmm10, [rsp+0x90]
0000794c94dddadd  vmovaps xmm11, [rsp+0xA0]
0000794c94dddae6  vmovaps xmm12, [rsp+0xB0]
0000794c94dddaef  vmovaps xmm13, [rsp+0xC0]
0000794c94dddaf8  vmovaps xmm14, [rsp+0xD0]
0000794c94dddb01  vmovaps xmm15, [rsp+0xE0]
0000794c94dddb0a  add rsp, 0xF0
0000794c94dddb11  pop r11
0000794c94dddb13  pop r10
0000794c94dddb15  pop r9
0000794c94dddb17  pop r8
0000794c94dddb19  pop rsi
0000794c94dddb1a  pop rdi
0000794c94dddb1b  pop rdx
0000794c94dddb1c  pop rcx
0000794c94dddb1d  pop rax
0000794c94dddb1e  add rsp, 0x08
0000794c94dddb22  jmp 0x0000794C94DDBEAC
0000794c94dddb27  call 0x0000794C94CC4620
0000794c94dddb2c  jmp 0x0000794C94DDBEB9
0000794c94dddb31  sub rsp, 0x08
0000794c94dddb35  push rax
0000794c94dddb36  push rcx
0000794c94dddb37  push rdx
0000794c94dddb38  push rdi
0000794c94dddb39  push rsi
0000794c94dddb3a  push r8
0000794c94dddb3c  push r9
0000794c94dddb3e  push r10
0000794c94dddb40  push r11
0000794c94dddb42  sub rsp, 0xF0
0000794c94dddb49  vmovaps [rsp], xmm0
0000794c94dddb4e  vmovaps [rsp+0x10], xmm1
0000794c94dddb54  vmovaps [rsp+0x20], xmm2
0000794c94dddb5a  vmovaps [rsp+0x30], xmm4
0000794c94dddb60  vmovaps [rsp+0x40], xmm5
0000794c94dddb66  vmovaps [rsp+0x50], xmm6
0000794c94dddb6c  vmovaps [rsp+0x60], xmm7
0000794c94dddb72  vmovaps [rsp+0x70], xmm8
0000794c94dddb78  vmovaps [rsp+0x80], xmm9
0000794c94dddb81  vmovaps [rsp+0x90], xmm10
0000794c94dddb8a  vmovaps [rsp+0xA0], xmm11
0000794c94dddb93  vmovaps [rsp+0xB0], xmm12
0000794c94dddb9c  vmovaps [rsp+0xC0], xmm13
0000794c94dddba5  vmovaps [rsp+0xD0], xmm14
0000794c94dddbae  vmovaps [rsp+0xE0], xmm15
0000794c94dddbb7  sub rsp, 0x30
0000794c94dddbbb  movaps [rsp], xmm3
0000794c94dddbbf  movaps [rsp+0x10], xmm1
0000794c94dddbc4  movaps [rsp+0x20], xmm9
0000794c94dddbca  lea rdi, [rsp]
0000794c94dddbce  mov esi, 0x00
0000794c94dddbd3  mov rax, 0x5AB2B8B81530
0000794c94dddbdd  call rax
0000794c94dddbdf  movaps xmm3, [rsp]
0000794c94dddbe3  add rsp, 0x30
0000794c94dddbe7  vmovaps xmm0, [rsp]
0000794c94dddbec  vmovaps xmm1, [rsp+0x10]
0000794c94dddbf2  vmovaps xmm2, [rsp+0x20]
0000794c94dddbf8  vmovaps xmm4, [rsp+0x30]
0000794c94dddbfe  vmovaps xmm5, [rsp+0x40]
0000794c94dddc04  vmovaps xmm6, [rsp+0x50]
0000794c94dddc0a  vmovaps xmm7, [rsp+0x60]
0000794c94dddc10  vmovaps xmm8, [rsp+0x70]
0000794c94dddc16  vmovaps xmm9, [rsp+0x80]
0000794c94dddc1f  vmovaps xmm10, [rsp+0x90]
0000794c94dddc28  vmovaps xmm11, [rsp+0xA0]
0000794c94dddc31  vmovaps xmm12, [rsp+0xB0]
0000794c94dddc3a  vmovaps xmm13, [rsp+0xC0]
0000794c94dddc43  vmovaps xmm14, [rsp+0xD0]
0000794c94dddc4c  vmovaps xmm15, [rsp+0xE0]
0000794c94dddc55  add rsp, 0xF0
0000794c94dddc5c  pop r11
0000794c94dddc5e  pop r10
0000794c94dddc60  pop r9
0000794c94dddc62  pop r8
0000794c94dddc64  pop rsi
0000794c94dddc65  pop rdi
0000794c94dddc66  pop rdx
0000794c94dddc67  pop rcx
0000794c94dddc68  pop rax
0000794c94dddc69  add rsp, 0x08
0000794c94dddc6d  jmp 0x0000794C94DDBEF6
0000794c94dddc72  sub rsp, 0x08
0000794c94dddc76  push rax
0000794c94dddc77  push rcx
0000794c94dddc78  push rdx
0000794c94dddc79  push rdi
0000794c94dddc7a  push rsi
0000794c94dddc7b  push r8
0000794c94dddc7d  push r9
0000794c94dddc7f  push r10
0000794c94dddc81  push r11
0000794c94dddc83  sub rsp, 0xF0
0000794c94dddc8a  vmovaps [rsp], xmm0
0000794c94dddc8f  vmovaps [rsp+0x10], xmm2
0000794c94dddc95  vmovaps [rsp+0x20], xmm3
0000794c94dddc9b  vmovaps [rsp+0x30], xmm4
0000794c94dddca1  vmovaps [rsp+0x40], xmm5
0000794c94dddca7  vmovaps [rsp+0x50], xmm6
0000794c94dddcad  vmovaps [rsp+0x60], xmm7
0000794c94dddcb3  vmovaps [rsp+0x70], xmm8
0000794c94dddcb9  vmovaps [rsp+0x80], xmm9
0000794c94dddcc2  vmovaps [rsp+0x90], xmm10
0000794c94dddccb  vmovaps [rsp+0xA0], xmm11
0000794c94dddcd4  vmovaps [rsp+0xB0], xmm12
0000794c94dddcdd  vmovaps [rsp+0xC0], xmm13
0000794c94dddce6  vmovaps [rsp+0xD0], xmm14
0000794c94dddcef  vmovaps [rsp+0xE0], xmm15
0000794c94dddcf8  sub rsp, 0x30
0000794c94dddcfc  movaps [rsp], xmm1
0000794c94dddd00  movaps [rsp+0x10], xmm15
0000794c94dddd06  movaps [rsp+0x20], xmm9
0000794c94dddd0c  lea rdi, [rsp]
0000794c94dddd10  mov esi, 0x00
0000794c94dddd15  mov rax, 0x5AB2B8B81530
0000794c94dddd1f  call rax
0000794c94dddd21  movaps xmm1, [rsp]
0000794c94dddd25  add rsp, 0x30
0000794c94dddd29  vmovaps xmm0, [rsp]
0000794c94dddd2e  vmovaps xmm2, [rsp+0x10]
0000794c94dddd34  vmovaps xmm3, [rsp+0x20]
0000794c94dddd3a  vmovaps xmm4, [rsp+0x30]
0000794c94dddd40  vmovaps xmm5, [rsp+0x40]
0000794c94dddd46  vmovaps xmm6, [rsp+0x50]
0000794c94dddd4c  vmovaps xmm7, [rsp+0x60]
0000794c94dddd52  vmovaps xmm8, [rsp+0x70]
0000794c94dddd58  vmovaps xmm9, [rsp+0x80]
0000794c94dddd61  vmovaps xmm10, [rsp+0x90]
0000794c94dddd6a  vmovaps xmm11, [rsp+0xA0]
0000794c94dddd73  vmovaps xmm12, [rsp+0xB0]
0000794c94dddd7c  vmovaps xmm13, [rsp+0xC0]
0000794c94dddd85  vmovaps xmm14, [rsp+0xD0]
0000794c94dddd8e  vmovaps xmm15, [rsp+0xE0]
0000794c94dddd97  add rsp, 0xF0
0000794c94dddd9e  pop r11
0000794c94dddda0  pop r10
0000794c94dddda2  pop r9
0000794c94dddda4  pop r8
0000794c94dddda6  pop rsi
0000794c94dddda7  pop rdi
0000794c94dddda8  pop rdx
0000794c94dddda9  pop rcx
0000794c94ddddaa  pop rax
0000794c94ddddab  add rsp, 0x08
0000794c94ddddaf  jmp 0x0000794C94DDBF7E
0000794c94ddddb4  call 0x0000794C94CC4620
0000794c94ddddb9  jmp 0x0000794C94DDBF8B
0000794c94ddddbe  sub rsp, 0x08
0000794c94ddddc2  push rax
0000794c94ddddc3  push rcx
0000794c94ddddc4  push rdx
0000794c94ddddc5  push rdi
0000794c94ddddc6  push rsi
0000794c94ddddc7  push r8
0000794c94ddddc9  push r9
0000794c94ddddcb  push r10
0000794c94ddddcd  push r11
0000794c94ddddcf  sub rsp, 0xF0
0000794c94ddddd6  vmovaps [rsp], xmm0
0000794c94dddddb  vmovaps [rsp+0x10], xmm2
0000794c94dddde1  vmovaps [rsp+0x20], xmm3
0000794c94dddde7  vmovaps [rsp+0x30], xmm4
0000794c94dddded  vmovaps [rsp+0x40], xmm5
0000794c94ddddf3  vmovaps [rsp+0x50], xmm6
0000794c94ddddf9  vmovaps [rsp+0x60], xmm7
0000794c94ddddff  vmovaps [rsp+0x70], xmm8
0000794c94ddde05  vmovaps [rsp+0x80], xmm9
0000794c94ddde0e  vmovaps [rsp+0x90], xmm10
0000794c94ddde17  vmovaps [rsp+0xA0], xmm11
0000794c94ddde20  vmovaps [rsp+0xB0], xmm12
0000794c94ddde29  vmovaps [rsp+0xC0], xmm13
0000794c94ddde32  vmovaps [rsp+0xD0], xmm14
0000794c94ddde3b  vmovaps [rsp+0xE0], xmm15
0000794c94ddde44  sub rsp, 0x30
0000794c94ddde48  movaps [rsp], xmm1
0000794c94ddde4c  movaps [rsp+0x10], xmm5
0000794c94ddde51  movaps [rsp+0x20], xmm7
0000794c94ddde56  lea rdi, [rsp]
0000794c94ddde5a  mov esi, 0x00
0000794c94ddde5f  mov rax, 0x5AB2B8B81530
0000794c94ddde69  call rax
0000794c94ddde6b  movaps xmm1, [rsp]
0000794c94ddde6f  add rsp, 0x30
0000794c94ddde73  vmovaps xmm0, [rsp]
0000794c94ddde78  vmovaps xmm2, [rsp+0x10]
0000794c94ddde7e  vmovaps xmm3, [rsp+0x20]
0000794c94ddde84  vmovaps xmm4, [rsp+0x30]
0000794c94ddde8a  vmovaps xmm5, [rsp+0x40]
0000794c94ddde90  vmovaps xmm6, [rsp+0x50]
0000794c94ddde96  vmovaps xmm7, [rsp+0x60]
0000794c94ddde9c  vmovaps xmm8, [rsp+0x70]
0000794c94dddea2  vmovaps xmm9, [rsp+0x80]
0000794c94dddeab  vmovaps xmm10, [rsp+0x90]
0000794c94dddeb4  vmovaps xmm11, [rsp+0xA0]
0000794c94dddebd  vmovaps xmm12, [rsp+0xB0]
0000794c94dddec6  vmovaps xmm13, [rsp+0xC0]
0000794c94dddecf  vmovaps xmm14, [rsp+0xD0]
0000794c94ddded8  vmovaps xmm15, [rsp+0xE0]
0000794c94dddee1  add rsp, 0xF0
0000794c94dddee8  pop r11
0000794c94dddeea  pop r10
0000794c94dddeec  pop r9
0000794c94dddeee  pop r8
0000794c94dddef0  pop rsi
0000794c94dddef1  pop rdi
0000794c94dddef2  pop rdx
0000794c94dddef3  pop rcx
0000794c94dddef4  pop rax
0000794c94dddef5  add rsp, 0x08
0000794c94dddef9  jmp 0x0000794C94DDC030
0000794c94dddefe  sub rsp, 0x08
0000794c94dddf02  push rax
0000794c94dddf03  push rcx
0000794c94dddf04  push rdx
0000794c94dddf05  push rdi
0000794c94dddf06  push rsi
0000794c94dddf07  push r8
0000794c94dddf09  push r9
0000794c94dddf0b  push r10
0000794c94dddf0d  push r11
0000794c94dddf0f  sub rsp, 0xF0
0000794c94dddf16  vmovaps [rsp], xmm0
0000794c94dddf1b  vmovaps [rsp+0x10], xmm1
0000794c94dddf21  vmovaps [rsp+0x20], xmm2
0000794c94dddf27  vmovaps [rsp+0x30], xmm3
0000794c94dddf2d  vmovaps [rsp+0x40], xmm4
0000794c94dddf33  vmovaps [rsp+0x50], xmm5
0000794c94dddf39  vmovaps [rsp+0x60], xmm6
0000794c94dddf3f  vmovaps [rsp+0x70], xmm8
0000794c94dddf45  vmovaps [rsp+0x80], xmm9
0000794c94dddf4e  vmovaps [rsp+0x90], xmm10
0000794c94dddf57  vmovaps [rsp+0xA0], xmm11
0000794c94dddf60  vmovaps [rsp+0xB0], xmm12
0000794c94dddf69  vmovaps [rsp+0xC0], xmm13
0000794c94dddf72  vmovaps [rsp+0xD0], xmm14
0000794c94dddf7b  vmovaps [rsp+0xE0], xmm15
0000794c94dddf84  sub rsp, 0x30
0000794c94dddf88  movaps [rsp], xmm7
0000794c94dddf8c  movaps [rsp+0x10], xmm5
0000794c94dddf91  movaps [rsp+0x20], xmm15
0000794c94dddf97  lea rdi, [rsp]
0000794c94dddf9b  mov esi, 0x00
0000794c94dddfa0  mov rax, 0x5AB2B8B81530
0000794c94dddfaa  call rax
0000794c94dddfac  movaps xmm7, [rsp]
0000794c94dddfb0  add rsp, 0x30
0000794c94dddfb4  vmovaps xmm0, [rsp]
0000794c94dddfb9  vmovaps xmm1, [rsp+0x10]
0000794c94dddfbf  vmovaps xmm2, [rsp+0x20]
0000794c94dddfc5  vmovaps xmm3, [rsp+0x30]
0000794c94dddfcb  vmovaps xmm4, [rsp+0x40]
0000794c94dddfd1  vmovaps xmm5, [rsp+0x50]
0000794c94dddfd7  vmovaps xmm6, [rsp+0x60]
0000794c94dddfdd  vmovaps xmm8, [rsp+0x70]
0000794c94dddfe3  vmovaps xmm9, [rsp+0x80]
0000794c94dddfec  vmovaps xmm10, [rsp+0x90]
0000794c94dddff5  vmovaps xmm11, [rsp+0xA0]
0000794c94dddffe  vmovaps xmm12, [rsp+0xB0]
0000794c94dde007  vmovaps xmm13, [rsp+0xC0]
0000794c94dde010  vmovaps xmm14, [rsp+0xD0]
0000794c94dde019  vmovaps xmm15, [rsp+0xE0]
0000794c94dde022  add rsp, 0xF0
0000794c94dde029  pop r11
0000794c94dde02b  pop r10
0000794c94dde02d  pop r9
0000794c94dde02f  pop r8
0000794c94dde031  pop rsi
0000794c94dde032  pop rdi
0000794c94dde033  pop rdx
0000794c94dde034  pop rcx
0000794c94dde035  pop rax
0000794c94dde036  add rsp, 0x08
0000794c94dde03a  jmp 0x0000794C94DDC066
0000794c94dde03f  call 0x0000794C94CB52F0
0000794c94dde044  jmp 0x0000794C94DDC073
0000794c94dde049  sub rsp, 0x08
0000794c94dde04d  push rax
0000794c94dde04e  push rcx
0000794c94dde04f  push rdx
0000794c94dde050  push rdi
0000794c94dde051  push rsi
0000794c94dde052  push r8
0000794c94dde054  push r9
0000794c94dde056  push r10
0000794c94dde058  push r11
0000794c94dde05a  sub rsp, 0xF0
0000794c94dde061  vmovaps [rsp], xmm0
0000794c94dde066  vmovaps [rsp+0x10], xmm1
0000794c94dde06c  vmovaps [rsp+0x20], xmm2
0000794c94dde072  vmovaps [rsp+0x30], xmm3
0000794c94dde078  vmovaps [rsp+0x40], xmm4
0000794c94dde07e  vmovaps [rsp+0x50], xmm5
0000794c94dde084  vmovaps [rsp+0x60], xmm6
0000794c94dde08a  vmovaps [rsp+0x70], xmm7
0000794c94dde090  vmovaps [rsp+0x80], xmm8
0000794c94dde099  vmovaps [rsp+0x90], xmm9
0000794c94dde0a2  vmovaps [rsp+0xA0], xmm10
0000794c94dde0ab  vmovaps [rsp+0xB0], xmm11
0000794c94dde0b4  vmovaps [rsp+0xC0], xmm12
0000794c94dde0bd  vmovaps [rsp+0xD0], xmm13
0000794c94dde0c6  vmovaps [rsp+0xE0], xmm14
0000794c94dde0cf  sub rsp, 0x30
0000794c94dde0d3  movaps [rsp], xmm15
0000794c94dde0d8  movaps [rsp+0x10], xmm5
0000794c94dde0dd  movaps [rsp+0x20], xmm3
0000794c94dde0e2  lea rdi, [rsp]
0000794c94dde0e6  mov esi, 0x00
0000794c94dde0eb  mov rax, 0x5AB2B8B81530
0000794c94dde0f5  call rax
0000794c94dde0f7  movaps xmm15, [rsp]
0000794c94dde0fc  add rsp, 0x30
0000794c94dde100  vmovaps xmm0, [rsp]
0000794c94dde105  vmovaps xmm1, [rsp+0x10]
0000794c94dde10b  vmovaps xmm2, [rsp+0x20]
0000794c94dde111  vmovaps xmm3, [rsp+0x30]
0000794c94dde117  vmovaps xmm4, [rsp+0x40]
0000794c94dde11d  vmovaps xmm5, [rsp+0x50]
0000794c94dde123  vmovaps xmm6, [rsp+0x60]
0000794c94dde129  vmovaps xmm7, [rsp+0x70]
0000794c94dde12f  vmovaps xmm8, [rsp+0x80]
0000794c94dde138  vmovaps xmm9, [rsp+0x90]
0000794c94dde141  vmovaps xmm10, [rsp+0xA0]
0000794c94dde14a  vmovaps xmm11, [rsp+0xB0]
0000794c94dde153  vmovaps xmm12, [rsp+0xC0]
0000794c94dde15c  vmovaps xmm13, [rsp+0xD0]
0000794c94dde165  vmovaps xmm14, [rsp+0xE0]
0000794c94dde16e  add rsp, 0xF0
0000794c94dde175  pop r11
0000794c94dde177  pop r10
0000794c94dde179  pop r9
0000794c94dde17b  pop r8
0000794c94dde17d  pop rsi
0000794c94dde17e  pop rdi
0000794c94dde17f  pop rdx
0000794c94dde180  pop rcx
0000794c94dde181  pop rax
0000794c94dde182  add rsp, 0x08
0000794c94dde186  jmp 0x0000794C94DDC099
0000794c94dde18b  sub rsp, 0x08
0000794c94dde18f  push rax
0000794c94dde190  push rcx
0000794c94dde191  push rdx
0000794c94dde192  push rdi
0000794c94dde193  push rsi
0000794c94dde194  push r8
0000794c94dde196  push r9
0000794c94dde198  push r10
0000794c94dde19a  push r11
0000794c94dde19c  sub rsp, 0xF0
0000794c94dde1a3  vmovaps [rsp], xmm0
0000794c94dde1a8  vmovaps [rsp+0x10], xmm2
0000794c94dde1ae  vmovaps [rsp+0x20], xmm3
0000794c94dde1b4  vmovaps [rsp+0x30], xmm4
0000794c94dde1ba  vmovaps [rsp+0x40], xmm5
0000794c94dde1c0  vmovaps [rsp+0x50], xmm6
0000794c94dde1c6  vmovaps [rsp+0x60], xmm7
0000794c94dde1cc  vmovaps [rsp+0x70], xmm8
0000794c94dde1d2  vmovaps [rsp+0x80], xmm9
0000794c94dde1db  vmovaps [rsp+0x90], xmm10
0000794c94dde1e4  vmovaps [rsp+0xA0], xmm11
0000794c94dde1ed  vmovaps [rsp+0xB0], xmm12
0000794c94dde1f6  vmovaps [rsp+0xC0], xmm13
0000794c94dde1ff  vmovaps [rsp+0xD0], xmm14
0000794c94dde208  vmovaps [rsp+0xE0], xmm15
0000794c94dde211  sub rsp, 0x30
0000794c94dde215  movaps [rsp], xmm1
0000794c94dde219  movaps [rsp+0x10], xmm5
0000794c94dde21e  movaps [rsp+0x20], xmm4
0000794c94dde223  lea rdi, [rsp]
0000794c94dde227  mov esi, 0x00
0000794c94dde22c  mov rax, 0x5AB2B8B81530
0000794c94dde236  call rax
0000794c94dde238  movaps xmm1, [rsp]
0000794c94dde23c  add rsp, 0x30
0000794c94dde240  vmovaps xmm0, [rsp]
0000794c94dde245  vmovaps xmm2, [rsp+0x10]
0000794c94dde24b  vmovaps xmm3, [rsp+0x20]
0000794c94dde251  vmovaps xmm4, [rsp+0x30]
0000794c94dde257  vmovaps xmm5, [rsp+0x40]
0000794c94dde25d  vmovaps xmm6, [rsp+0x50]
0000794c94dde263  vmovaps xmm7, [rsp+0x60]
0000794c94dde269  vmovaps xmm8, [rsp+0x70]
0000794c94dde26f  vmovaps xmm9, [rsp+0x80]
0000794c94dde278  vmovaps xmm10, [rsp+0x90]
0000794c94dde281  vmovaps xmm11, [rsp+0xA0]
0000794c94dde28a  vmovaps xmm12, [rsp+0xB0]
0000794c94dde293  vmovaps xmm13, [rsp+0xC0]
0000794c94dde29c  vmovaps xmm14, [rsp+0xD0]
0000794c94dde2a5  vmovaps xmm15, [rsp+0xE0]
0000794c94dde2ae  add rsp, 0xF0
0000794c94dde2b5  pop r11
0000794c94dde2b7  pop r10
0000794c94dde2b9  pop r9
0000794c94dde2bb  pop r8
0000794c94dde2bd  pop rsi
0000794c94dde2be  pop rdi
0000794c94dde2bf  pop rdx
0000794c94dde2c0  pop rcx
0000794c94dde2c1  pop rax
0000794c94dde2c2  add rsp, 0x08
0000794c94dde2c6  jmp 0x0000794C94DDC0B9
0000794c94dde2cb  sub rsp, 0x08
0000794c94dde2cf  push rax
0000794c94dde2d0  push rcx
0000794c94dde2d1  push rdx
0000794c94dde2d2  push rdi
0000794c94dde2d3  push rsi
0000794c94dde2d4  push r8
0000794c94dde2d6  push r9
0000794c94dde2d8  push r10
0000794c94dde2da  push r11
0000794c94dde2dc  sub rsp, 0xF0
0000794c94dde2e3  vmovaps [rsp], xmm0
0000794c94dde2e8  vmovaps [rsp+0x10], xmm1
0000794c94dde2ee  vmovaps [rsp+0x20], xmm2
0000794c94dde2f4  vmovaps [rsp+0x30], xmm3
0000794c94dde2fa  vmovaps [rsp+0x40], xmm5
0000794c94dde300  vmovaps [rsp+0x50], xmm6
0000794c94dde306  vmovaps [rsp+0x60], xmm7
0000794c94dde30c  vmovaps [rsp+0x70], xmm8
0000794c94dde312  vmovaps [rsp+0x80], xmm9
0000794c94dde31b  vmovaps [rsp+0x90], xmm10
0000794c94dde324  vmovaps [rsp+0xA0], xmm11
0000794c94dde32d  vmovaps [rsp+0xB0], xmm12
0000794c94dde336  vmovaps [rsp+0xC0], xmm13
0000794c94dde33f  vmovaps [rsp+0xD0], xmm14
0000794c94dde348  vmovaps [rsp+0xE0], xmm15
0000794c94dde351  sub rsp, 0x30
0000794c94dde355  movaps [rsp], xmm4
0000794c94dde359  movaps [rsp+0x10], xmm3
0000794c94dde35e  movaps [rsp+0x20], xmm5
0000794c94dde363  lea rdi, [rsp]
0000794c94dde367  mov esi, 0x00
0000794c94dde36c  mov rax, 0x5AB2B8B81530
0000794c94dde376  call rax
0000794c94dde378  movaps xmm4, [rsp]
0000794c94dde37c  add rsp, 0x30
0000794c94dde380  vmovaps xmm0, [rsp]
0000794c94dde385  vmovaps xmm1, [rsp+0x10]
0000794c94dde38b  vmovaps xmm2, [rsp+0x20]
0000794c94dde391  vmovaps xmm3, [rsp+0x30]
0000794c94dde397  vmovaps xmm5, [rsp+0x40]
0000794c94dde39d  vmovaps xmm6, [rsp+0x50]
0000794c94dde3a3  vmovaps xmm7, [rsp+0x60]
0000794c94dde3a9  vmovaps xmm8, [rsp+0x70]
0000794c94dde3af  vmovaps xmm9, [rsp+0x80]
0000794c94dde3b8  vmovaps xmm10, [rsp+0x90]
0000794c94dde3c1  vmovaps xmm11, [rsp+0xA0]
0000794c94dde3ca  vmovaps xmm12, [rsp+0xB0]
0000794c94dde3d3  vmovaps xmm13, [rsp+0xC0]
0000794c94dde3dc  vmovaps xmm14, [rsp+0xD0]
0000794c94dde3e5  vmovaps xmm15, [rsp+0xE0]
0000794c94dde3ee  add rsp, 0xF0
0000794c94dde3f5  pop r11
0000794c94dde3f7  pop r10
0000794c94dde3f9  pop r9
0000794c94dde3fb  pop r8
0000794c94dde3fd  pop rsi
0000794c94dde3fe  pop rdi
0000794c94dde3ff  pop rdx
0000794c94dde400  pop rcx
0000794c94dde401  pop rax
0000794c94dde402  add rsp, 0x08
0000794c94dde406  jmp 0x0000794C94DDC107
0000794c94dde40b  call 0x0000794C94CB52F0
0000794c94dde410  jmp 0x0000794C94DDC114
0000794c94dde415  sub rsp, 0x08
0000794c94dde419  push rax
0000794c94dde41a  push rcx
0000794c94dde41b  push rdx
0000794c94dde41c  push rdi
0000794c94dde41d  push rsi
0000794c94dde41e  push r8
0000794c94dde420  push r9
0000794c94dde422  push r10
0000794c94dde424  push r11
0000794c94dde426  sub rsp, 0xF0
0000794c94dde42d  vmovaps [rsp], xmm0
0000794c94dde432  vmovaps [rsp+0x10], xmm1
0000794c94dde438  vmovaps [rsp+0x20], xmm2
0000794c94dde43e  vmovaps [rsp+0x30], xmm3
0000794c94dde444  vmovaps [rsp+0x40], xmm4
0000794c94dde44a  vmovaps [rsp+0x50], xmm6
0000794c94dde450  vmovaps [rsp+0x60], xmm7
0000794c94dde456  vmovaps [rsp+0x70], xmm8
0000794c94dde45c  vmovaps [rsp+0x80], xmm9
0000794c94dde465  vmovaps [rsp+0x90], xmm10
0000794c94dde46e  vmovaps [rsp+0xA0], xmm11
0000794c94dde477  vmovaps [rsp+0xB0], xmm12
0000794c94dde480  vmovaps [rsp+0xC0], xmm13
0000794c94dde489  vmovaps [rsp+0xD0], xmm14
0000794c94dde492  vmovaps [rsp+0xE0], xmm15
0000794c94dde49b  sub rsp, 0x30
0000794c94dde49f  movaps [rsp], xmm5
0000794c94dde4a3  movaps [rsp+0x10], xmm6
0000794c94dde4a8  movaps [rsp+0x20], xmm3
0000794c94dde4ad  lea rdi, [rsp]
0000794c94dde4b1  mov esi, 0x00
0000794c94dde4b6  mov rax, 0x5AB2B8B81530
0000794c94dde4c0  call rax
0000794c94dde4c2  movaps xmm5, [rsp]
0000794c94dde4c6  add rsp, 0x30
0000794c94dde4ca  vmovaps xmm0, [rsp]
0000794c94dde4cf  vmovaps xmm1, [rsp+0x10]
0000794c94dde4d5  vmovaps xmm2, [rsp+0x20]
0000794c94dde4db  vmovaps xmm3, [rsp+0x30]
0000794c94dde4e1  vmovaps xmm4, [rsp+0x40]
0000794c94dde4e7  vmovaps xmm6, [rsp+0x50]
0000794c94dde4ed  vmovaps xmm7, [rsp+0x60]
0000794c94dde4f3  vmovaps xmm8, [rsp+0x70]
0000794c94dde4f9  vmovaps xmm9, [rsp+0x80]
0000794c94dde502  vmovaps xmm10, [rsp+0x90]
0000794c94dde50b  vmovaps xmm11, [rsp+0xA0]
0000794c94dde514  vmovaps xmm12, [rsp+0xB0]
0000794c94dde51d  vmovaps xmm13, [rsp+0xC0]
0000794c94dde526  vmovaps xmm14, [rsp+0xD0]
0000794c94dde52f  vmovaps xmm15, [rsp+0xE0]
0000794c94dde538  add rsp, 0xF0
0000794c94dde53f  pop r11
0000794c94dde541  pop r10
0000794c94dde543  pop r9
0000794c94dde545  pop r8
0000794c94dde547  pop rsi
0000794c94dde548  pop rdi
0000794c94dde549  pop rdx
0000794c94dde54a  pop rcx
0000794c94dde54b  pop rax
0000794c94dde54c  add rsp, 0x08
0000794c94dde550  jmp 0x0000794C94DDC13A
0000794c94dde555  sub rsp, 0x08
0000794c94dde559  push rax
0000794c94dde55a  push rcx
0000794c94dde55b  push rdx
0000794c94dde55c  push rdi
0000794c94dde55d  push rsi
0000794c94dde55e  push r8
0000794c94dde560  push r9
0000794c94dde562  push r10
0000794c94dde564  push r11
0000794c94dde566  sub rsp, 0xF0
0000794c94dde56d  vmovaps [rsp], xmm0
0000794c94dde572  vmovaps [rsp+0x10], xmm1
0000794c94dde578  vmovaps [rsp+0x20], xmm2
0000794c94dde57e  vmovaps [rsp+0x30], xmm3
0000794c94dde584  vmovaps [rsp+0x40], xmm4
0000794c94dde58a  vmovaps [rsp+0x50], xmm5
0000794c94dde590  vmovaps [rsp+0x60], xmm7
0000794c94dde596  vmovaps [rsp+0x70], xmm8
0000794c94dde59c  vmovaps [rsp+0x80], xmm9
0000794c94dde5a5  vmovaps [rsp+0x90], xmm10
0000794c94dde5ae  vmovaps [rsp+0xA0], xmm11
0000794c94dde5b7  vmovaps [rsp+0xB0], xmm12
0000794c94dde5c0  vmovaps [rsp+0xC0], xmm13
0000794c94dde5c9  vmovaps [rsp+0xD0], xmm14
0000794c94dde5d2  vmovaps [rsp+0xE0], xmm15
0000794c94dde5db  sub rsp, 0x30
0000794c94dde5df  movaps [rsp], xmm6
0000794c94dde5e3  movaps [rsp+0x10], xmm9
0000794c94dde5e9  movaps [rsp+0x20], xmm1
0000794c94dde5ee  lea rdi, [rsp]
0000794c94dde5f2  mov esi, 0x00
0000794c94dde5f7  mov rax, 0x5AB2B8B81530
0000794c94dde601  call rax
0000794c94dde603  movaps xmm6, [rsp]
0000794c94dde607  add rsp, 0x30
0000794c94dde60b  vmovaps xmm0, [rsp]
0000794c94dde610  vmovaps xmm1, [rsp+0x10]
0000794c94dde616  vmovaps xmm2, [rsp+0x20]
0000794c94dde61c  vmovaps xmm3, [rsp+0x30]
0000794c94dde622  vmovaps xmm4, [rsp+0x40]
0000794c94dde628  vmovaps xmm5, [rsp+0x50]
0000794c94dde62e  vmovaps xmm7, [rsp+0x60]
0000794c94dde634  vmovaps xmm8, [rsp+0x70]
0000794c94dde63a  vmovaps xmm9, [rsp+0x80]
0000794c94dde643  vmovaps xmm10, [rsp+0x90]
0000794c94dde64c  vmovaps xmm11, [rsp+0xA0]
0000794c94dde655  vmovaps xmm12, [rsp+0xB0]
0000794c94dde65e  vmovaps xmm13, [rsp+0xC0]
0000794c94dde667  vmovaps xmm14, [rsp+0xD0]
0000794c94dde670  vmovaps xmm15, [rsp+0xE0]
0000794c94dde679  add rsp, 0xF0
0000794c94dde680  pop r11
0000794c94dde682  pop r10
0000794c94dde684  pop r9
0000794c94dde686  pop r8
0000794c94dde688  pop rsi
0000794c94dde689  pop rdi
0000794c94dde68a  pop rdx
0000794c94dde68b  pop rcx
0000794c94dde68c  pop rax
0000794c94dde68d  add rsp, 0x08
0000794c94dde691  jmp 0x0000794C94DDC15E
0000794c94dde696  sub rsp, 0x08
0000794c94dde69a  push rax
0000794c94dde69b  push rcx
0000794c94dde69c  push rdx
0000794c94dde69d  push rdi
0000794c94dde69e  push rsi
0000794c94dde69f  push r8
0000794c94dde6a1  push r9
0000794c94dde6a3  push r10
0000794c94dde6a5  push r11
0000794c94dde6a7  sub rsp, 0xF0
0000794c94dde6ae  vmovaps [rsp], xmm0
0000794c94dde6b3  vmovaps [rsp+0x10], xmm1
0000794c94dde6b9  vmovaps [rsp+0x20], xmm2
0000794c94dde6bf  vmovaps [rsp+0x30], xmm3
0000794c94dde6c5  vmovaps [rsp+0x40], xmm4
0000794c94dde6cb  vmovaps [rsp+0x50], xmm5
0000794c94dde6d1  vmovaps [rsp+0x60], xmm6
0000794c94dde6d7  vmovaps [rsp+0x70], xmm7
0000794c94dde6dd  vmovaps [rsp+0x80], xmm8
0000794c94dde6e6  vmovaps [rsp+0x90], xmm10
0000794c94dde6ef  vmovaps [rsp+0xA0], xmm11
0000794c94dde6f8  vmovaps [rsp+0xB0], xmm12
0000794c94dde701  vmovaps [rsp+0xC0], xmm13
0000794c94dde70a  vmovaps [rsp+0xD0], xmm14
0000794c94dde713  vmovaps [rsp+0xE0], xmm15
0000794c94dde71c  sub rsp, 0x30
0000794c94dde720  movaps [rsp], xmm9
0000794c94dde725  movaps [rsp+0x10], xmm3
0000794c94dde72a  movaps [rsp+0x20], xmm1
0000794c94dde72f  lea rdi, [rsp]
0000794c94dde733  mov esi, 0x00
0000794c94dde738  mov rax, 0x5AB2B8B81530
0000794c94dde742  call rax
0000794c94dde744  movaps xmm9, [rsp]
0000794c94dde749  add rsp, 0x30
0000794c94dde74d  vmovaps xmm0, [rsp]
0000794c94dde752  vmovaps xmm1, [rsp+0x10]
0000794c94dde758  vmovaps xmm2, [rsp+0x20]
0000794c94dde75e  vmovaps xmm3, [rsp+0x30]
0000794c94dde764  vmovaps xmm4, [rsp+0x40]
0000794c94dde76a  vmovaps xmm5, [rsp+0x50]
0000794c94dde770  vmovaps xmm6, [rsp+0x60]
0000794c94dde776  vmovaps xmm7, [rsp+0x70]
0000794c94dde77c  vmovaps xmm8, [rsp+0x80]
0000794c94dde785  vmovaps xmm10, [rsp+0x90]
0000794c94dde78e  vmovaps xmm11, [rsp+0xA0]
0000794c94dde797  vmovaps xmm12, [rsp+0xB0]
0000794c94dde7a0  vmovaps xmm13, [rsp+0xC0]
0000794c94dde7a9  vmovaps xmm14, [rsp+0xD0]
0000794c94dde7b2  vmovaps xmm15, [rsp+0xE0]
0000794c94dde7bb  add rsp, 0xF0
0000794c94dde7c2  pop r11
0000794c94dde7c4  pop r10
0000794c94dde7c6  pop r9
0000794c94dde7c8  pop r8
0000794c94dde7ca  pop rsi
0000794c94dde7cb  pop rdi
0000794c94dde7cc  pop rdx
0000794c94dde7cd  pop rcx
0000794c94dde7ce  pop rax
0000794c94dde7cf  add rsp, 0x08
0000794c94dde7d3  jmp 0x0000794C94DDC1AA
0000794c94dde7d8  call 0x0000794C94CB52F0
0000794c94dde7dd  jmp 0x0000794C94DDC1B7
0000794c94dde7e2  sub rsp, 0x08
0000794c94dde7e6  push rax
0000794c94dde7e7  push rcx
0000794c94dde7e8  push rdx
0000794c94dde7e9  push rdi
0000794c94dde7ea  push rsi
0000794c94dde7eb  push r8
0000794c94dde7ed  push r9
0000794c94dde7ef  push r10
0000794c94dde7f1  push r11
0000794c94dde7f3  sub rsp, 0xF0
0000794c94dde7fa  vmovaps [rsp], xmm0
0000794c94dde7ff  vmovaps [rsp+0x10], xmm1
0000794c94dde805  vmovaps [rsp+0x20], xmm2
0000794c94dde80b  vmovaps [rsp+0x30], xmm3
0000794c94dde811  vmovaps [rsp+0x40], xmm4
0000794c94dde817  vmovaps [rsp+0x50], xmm5
0000794c94dde81d  vmovaps [rsp+0x60], xmm6
0000794c94dde823  vmovaps [rsp+0x70], xmm7
0000794c94dde829  vmovaps [rsp+0x80], xmm8
0000794c94dde832  vmovaps [rsp+0x90], xmm9
0000794c94dde83b  vmovaps [rsp+0xA0], xmm10
0000794c94dde844  vmovaps [rsp+0xB0], xmm11
0000794c94dde84d  vmovaps [rsp+0xC0], xmm12
0000794c94dde856  vmovaps [rsp+0xD0], xmm13
0000794c94dde85f  vmovaps [rsp+0xE0], xmm14
0000794c94dde868  sub rsp, 0x30
0000794c94dde86c  movaps [rsp], xmm15
0000794c94dde871  movaps [rsp+0x10], xmm3
0000794c94dde876  movaps [rsp+0x20], xmm7
0000794c94dde87b  lea rdi, [rsp]
0000794c94dde87f  mov esi, 0x00
0000794c94dde884  mov rax, 0x5AB2B8B81530
0000794c94dde88e  call rax
0000794c94dde890  movaps xmm15, [rsp]
0000794c94dde895  add rsp, 0x30
0000794c94dde899  vmovaps xmm0, [rsp]
0000794c94dde89e  vmovaps xmm1, [rsp+0x10]
0000794c94dde8a4  vmovaps xmm2, [rsp+0x20]
0000794c94dde8aa  vmovaps xmm3, [rsp+0x30]
0000794c94dde8b0  vmovaps xmm4, [rsp+0x40]
0000794c94dde8b6  vmovaps xmm5, [rsp+0x50]
0000794c94dde8bc  vmovaps xmm6, [rsp+0x60]
0000794c94dde8c2  vmovaps xmm7, [rsp+0x70]
0000794c94dde8c8  vmovaps xmm8, [rsp+0x80]
0000794c94dde8d1  vmovaps xmm9, [rsp+0x90]
0000794c94dde8da  vmovaps xmm10, [rsp+0xA0]
0000794c94dde8e3  vmovaps xmm11, [rsp+0xB0]
0000794c94dde8ec  vmovaps xmm12, [rsp+0xC0]
0000794c94dde8f5  vmovaps xmm13, [rsp+0xD0]
0000794c94dde8fe  vmovaps xmm14, [rsp+0xE0]
0000794c94dde907  add rsp, 0xF0
0000794c94dde90e  pop r11
0000794c94dde910  pop r10
0000794c94dde912  pop r9
0000794c94dde914  pop r8
0000794c94dde916  pop rsi
0000794c94dde917  pop rdi
0000794c94dde918  pop rdx
0000794c94dde919  pop rcx
0000794c94dde91a  pop rax
0000794c94dde91b  add rsp, 0x08
0000794c94dde91f  jmp 0x0000794C94DDC1E3
0000794c94dde924  sub rsp, 0x08
0000794c94dde928  push rax
0000794c94dde929  push rcx
0000794c94dde92a  push rdx
0000794c94dde92b  push rdi
0000794c94dde92c  push rsi
0000794c94dde92d  push r8
0000794c94dde92f  push r9
0000794c94dde931  push r10
0000794c94dde933  push r11
0000794c94dde935  sub rsp, 0xF0
0000794c94dde93c  vmovaps [rsp], xmm0
0000794c94dde941  vmovaps [rsp+0x10], xmm1
0000794c94dde947  vmovaps [rsp+0x20], xmm2
0000794c94dde94d  vmovaps [rsp+0x30], xmm4
0000794c94dde953  vmovaps [rsp+0x40], xmm5
0000794c94dde959  vmovaps [rsp+0x50], xmm6
0000794c94dde95f  vmovaps [rsp+0x60], xmm7
0000794c94dde965  vmovaps [rsp+0x70], xmm8
0000794c94dde96b  vmovaps [rsp+0x80], xmm9
0000794c94dde974  vmovaps [rsp+0x90], xmm10
0000794c94dde97d  vmovaps [rsp+0xA0], xmm11
0000794c94dde986  vmovaps [rsp+0xB0], xmm12
0000794c94dde98f  vmovaps [rsp+0xC0], xmm13
0000794c94dde998  vmovaps [rsp+0xD0], xmm14
0000794c94dde9a1  vmovaps [rsp+0xE0], xmm15
0000794c94dde9aa  sub rsp, 0x30
0000794c94dde9ae  movaps [rsp], xmm3
0000794c94dde9b2  movaps [rsp+0x10], xmm1
0000794c94dde9b7  movaps [rsp+0x20], xmm15
0000794c94dde9bd  lea rdi, [rsp]
0000794c94dde9c1  mov esi, 0x00
0000794c94dde9c6  mov rax, 0x5AB2B8B81530
0000794c94dde9d0  call rax
0000794c94dde9d2  movaps xmm3, [rsp]
0000794c94dde9d6  add rsp, 0x30
0000794c94dde9da  vmovaps xmm0, [rsp]
0000794c94dde9df  vmovaps xmm1, [rsp+0x10]
0000794c94dde9e5  vmovaps xmm2, [rsp+0x20]
0000794c94dde9eb  vmovaps xmm4, [rsp+0x30]
0000794c94dde9f1  vmovaps xmm5, [rsp+0x40]
0000794c94dde9f7  vmovaps xmm6, [rsp+0x50]
0000794c94dde9fd  vmovaps xmm7, [rsp+0x60]
0000794c94ddea03  vmovaps xmm8, [rsp+0x70]
0000794c94ddea09  vmovaps xmm9, [rsp+0x80]
0000794c94ddea12  vmovaps xmm10, [rsp+0x90]
0000794c94ddea1b  vmovaps xmm11, [rsp+0xA0]
0000794c94ddea24  vmovaps xmm12, [rsp+0xB0]
0000794c94ddea2d  vmovaps xmm13, [rsp+0xC0]
0000794c94ddea36  vmovaps xmm14, [rsp+0xD0]
0000794c94ddea3f  vmovaps xmm15, [rsp+0xE0]
0000794c94ddea48  add rsp, 0xF0
0000794c94ddea4f  pop r11
0000794c94ddea51  pop r10
0000794c94ddea53  pop r9
0000794c94ddea55  pop r8
0000794c94ddea57  pop rsi
0000794c94ddea58  pop rdi
0000794c94ddea59  pop rdx
0000794c94ddea5a  pop rcx
0000794c94ddea5b  pop rax
0000794c94ddea5c  add rsp, 0x08
0000794c94ddea60  jmp 0x0000794C94DDC272
0000794c94ddea65  call 0x0000794C94CB52F0
0000794c94ddea6a  jmp 0x0000794C94DDC27C
0000794c94ddea6f  sub rsp, 0x08
0000794c94ddea73  push rax
0000794c94ddea74  push rcx
0000794c94ddea75  push rdx
0000794c94ddea76  push rdi
0000794c94ddea77  push rsi
0000794c94ddea78  push r8
0000794c94ddea7a  push r9
0000794c94ddea7c  push r10
0000794c94ddea7e  push r11
0000794c94ddea80  sub rsp, 0xF0
0000794c94ddea87  vmovaps [rsp], xmm0
0000794c94ddea8c  vmovaps [rsp+0x10], xmm1
0000794c94ddea92  vmovaps [rsp+0x20], xmm2
0000794c94ddea98  vmovaps [rsp+0x30], xmm3
0000794c94ddea9e  vmovaps [rsp+0x40], xmm4
0000794c94ddeaa4  vmovaps [rsp+0x50], xmm5
0000794c94ddeaaa  vmovaps [rsp+0x60], xmm6
0000794c94ddeab0  vmovaps [rsp+0x70], xmm7
0000794c94ddeab6  vmovaps [rsp+0x80], xmm8
0000794c94ddeabf  vmovaps [rsp+0x90], xmm9
0000794c94ddeac8  vmovaps [rsp+0xA0], xmm10
0000794c94ddead1  vmovaps [rsp+0xB0], xmm11
0000794c94ddeada  vmovaps [rsp+0xC0], xmm12
0000794c94ddeae3  vmovaps [rsp+0xD0], xmm13
0000794c94ddeaec  vmovaps [rsp+0xE0], xmm14
0000794c94ddeaf5  sub rsp, 0x30
0000794c94ddeaf9  movaps [rsp], xmm15
0000794c94ddeafe  movaps [rsp+0x10], xmm14
0000794c94ddeb04  movaps [rsp+0x20], xmm4
0000794c94ddeb09  lea rdi, [rsp]
0000794c94ddeb0d  mov esi, 0x00
0000794c94ddeb12  mov rax, 0x5AB2B8B81530
0000794c94ddeb1c  call rax
0000794c94ddeb1e  movaps xmm15, [rsp]
0000794c94ddeb23  add rsp, 0x30
0000794c94ddeb27  vmovaps xmm0, [rsp]
0000794c94ddeb2c  vmovaps xmm1, [rsp+0x10]
0000794c94ddeb32  vmovaps xmm2, [rsp+0x20]
0000794c94ddeb38  vmovaps xmm3, [rsp+0x30]
0000794c94ddeb3e  vmovaps xmm4, [rsp+0x40]
0000794c94ddeb44  vmovaps xmm5, [rsp+0x50]
0000794c94ddeb4a  vmovaps xmm6, [rsp+0x60]
0000794c94ddeb50  vmovaps xmm7, [rsp+0x70]
0000794c94ddeb56  vmovaps xmm8, [rsp+0x80]
0000794c94ddeb5f  vmovaps xmm9, [rsp+0x90]
0000794c94ddeb68  vmovaps xmm10, [rsp+0xA0]
0000794c94ddeb71  vmovaps xmm11, [rsp+0xB0]
0000794c94ddeb7a  vmovaps xmm12, [rsp+0xC0]
0000794c94ddeb83  vmovaps xmm13, [rsp+0xD0]
0000794c94ddeb8c  vmovaps xmm14, [rsp+0xE0]
0000794c94ddeb95  add rsp, 0xF0
0000794c94ddeb9c  pop r11
0000794c94ddeb9e  pop r10
0000794c94ddeba0  pop r9
0000794c94ddeba2  pop r8
0000794c94ddeba4  pop rsi
0000794c94ddeba5  pop rdi
0000794c94ddeba6  pop rdx
0000794c94ddeba7  pop rcx
0000794c94ddeba8  pop rax
0000794c94ddeba9  add rsp, 0x08
0000794c94ddebad  jmp 0x0000794C94DDC2AA
0000794c94ddebb2  sub rsp, 0x08
0000794c94ddebb6  push rax
0000794c94ddebb7  push rcx
0000794c94ddebb8  push rdx
0000794c94ddebb9  push rdi
0000794c94ddebba  push rsi
0000794c94ddebbb  push r8
0000794c94ddebbd  push r9
0000794c94ddebbf  push r10
0000794c94ddebc1  push r11
0000794c94ddebc3  sub rsp, 0xF0
0000794c94ddebca  vmovaps [rsp], xmm0
0000794c94ddebcf  vmovaps [rsp+0x10], xmm1
0000794c94ddebd5  vmovaps [rsp+0x20], xmm2
0000794c94ddebdb  vmovaps [rsp+0x30], xmm3
0000794c94ddebe1  vmovaps [rsp+0x40], xmm4
0000794c94ddebe7  vmovaps [rsp+0x50], xmm5
0000794c94ddebed  vmovaps [rsp+0x60], xmm6
0000794c94ddebf3  vmovaps [rsp+0x70], xmm7
0000794c94ddebf9  vmovaps [rsp+0x80], xmm8
0000794c94ddec02  vmovaps [rsp+0x90], xmm9
0000794c94ddec0b  vmovaps [rsp+0xA0], xmm10
0000794c94ddec14  vmovaps [rsp+0xB0], xmm11
0000794c94ddec1d  vmovaps [rsp+0xC0], xmm12
0000794c94ddec26  vmovaps [rsp+0xD0], xmm13
0000794c94ddec2f  vmovaps [rsp+0xE0], xmm15
0000794c94ddec38  sub rsp, 0x30
0000794c94ddec3c  movaps [rsp], xmm14
0000794c94ddec41  movaps [rsp+0x10], xmm2
0000794c94ddec46  movaps [rsp+0x20], xmm1
0000794c94ddec4b  lea rdi, [rsp]
0000794c94ddec4f  mov esi, 0x00
0000794c94ddec54  mov rax, 0x5AB2B8B81530
0000794c94ddec5e  call rax
0000794c94ddec60  movaps xmm14, [rsp]
0000794c94ddec65  add rsp, 0x30
0000794c94ddec69  vmovaps xmm0, [rsp]
0000794c94ddec6e  vmovaps xmm1, [rsp+0x10]
0000794c94ddec74  vmovaps xmm2, [rsp+0x20]
0000794c94ddec7a  vmovaps xmm3, [rsp+0x30]
0000794c94ddec80  vmovaps xmm4, [rsp+0x40]
0000794c94ddec86  vmovaps xmm5, [rsp+0x50]
0000794c94ddec8c  vmovaps xmm6, [rsp+0x60]
0000794c94ddec92  vmovaps xmm7, [rsp+0x70]
0000794c94ddec98  vmovaps xmm8, [rsp+0x80]
0000794c94ddeca1  vmovaps xmm9, [rsp+0x90]
0000794c94ddecaa  vmovaps xmm10, [rsp+0xA0]
0000794c94ddecb3  vmovaps xmm11, [rsp+0xB0]
0000794c94ddecbc  vmovaps xmm12, [rsp+0xC0]
0000794c94ddecc5  vmovaps xmm13, [rsp+0xD0]
0000794c94ddecce  vmovaps xmm15, [rsp+0xE0]
0000794c94ddecd7  add rsp, 0xF0
0000794c94ddecde  pop r11
0000794c94ddece0  pop r10
0000794c94ddece2  pop r9
0000794c94ddece4  pop r8
0000794c94ddece6  pop rsi
0000794c94ddece7  pop rdi
0000794c94ddece8  pop rdx
0000794c94ddece9  pop rcx
0000794c94ddecea  pop rax
0000794c94ddeceb  add rsp, 0x08
0000794c94ddecef  jmp 0x0000794C94DDC2D0
0000794c94ddecf4  sub rsp, 0x08
0000794c94ddecf8  push rax
0000794c94ddecf9  push rcx
0000794c94ddecfa  push rdx
0000794c94ddecfb  push rdi
0000794c94ddecfc  push rsi
0000794c94ddecfd  push r8
0000794c94ddecff  push r9
0000794c94dded01  push r10
0000794c94dded03  push r11
0000794c94dded05  sub rsp, 0xF0
0000794c94dded0c  vmovaps [rsp], xmm0
0000794c94dded11  vmovaps [rsp+0x10], xmm2
0000794c94dded17  vmovaps [rsp+0x20], xmm3
0000794c94dded1d  vmovaps [rsp+0x30], xmm4
0000794c94dded23  vmovaps [rsp+0x40], xmm5
0000794c94dded29  vmovaps [rsp+0x50], xmm6
0000794c94dded2f  vmovaps [rsp+0x60], xmm7
0000794c94dded35  vmovaps [rsp+0x70], xmm8
0000794c94dded3b  vmovaps [rsp+0x80], xmm9
0000794c94dded44  vmovaps [rsp+0x90], xmm10
0000794c94dded4d  vmovaps [rsp+0xA0], xmm11
0000794c94dded56  vmovaps [rsp+0xB0], xmm12
0000794c94dded5f  vmovaps [rsp+0xC0], xmm13
0000794c94dded68  vmovaps [rsp+0xD0], xmm14
0000794c94dded71  vmovaps [rsp+0xE0], xmm15
0000794c94dded7a  sub rsp, 0x30
0000794c94dded7e  movaps [rsp], xmm1
0000794c94dded82  movaps [rsp+0x10], xmm4
0000794c94dded87  movaps [rsp+0x20], xmm9
0000794c94dded8d  lea rdi, [rsp]
0000794c94dded91  mov esi, 0x00
0000794c94dded96  mov rax, 0x5AB2B8B81530
0000794c94ddeda0  call rax
0000794c94ddeda2  movaps xmm1, [rsp]
0000794c94ddeda6  add rsp, 0x30
0000794c94ddedaa  vmovaps xmm0, [rsp]
0000794c94ddedaf  vmovaps xmm2, [rsp+0x10]
0000794c94ddedb5  vmovaps xmm3, [rsp+0x20]
0000794c94ddedbb  vmovaps xmm4, [rsp+0x30]
0000794c94ddedc1  vmovaps xmm5, [rsp+0x40]
0000794c94ddedc7  vmovaps xmm6, [rsp+0x50]
0000794c94ddedcd  vmovaps xmm7, [rsp+0x60]
0000794c94ddedd3  vmovaps xmm8, [rsp+0x70]
0000794c94ddedd9  vmovaps xmm9, [rsp+0x80]
0000794c94ddede2  vmovaps xmm10, [rsp+0x90]
0000794c94ddedeb  vmovaps xmm11, [rsp+0xA0]
0000794c94ddedf4  vmovaps xmm12, [rsp+0xB0]
0000794c94ddedfd  vmovaps xmm13, [rsp+0xC0]
0000794c94ddee06  vmovaps xmm14, [rsp+0xD0]
0000794c94ddee0f  vmovaps xmm15, [rsp+0xE0]
0000794c94ddee18  add rsp, 0xF0
0000794c94ddee1f  pop r11
0000794c94ddee21  pop r10
0000794c94ddee23  pop r9
0000794c94ddee25  pop r8
0000794c94ddee27  pop rsi
0000794c94ddee28  pop rdi
0000794c94ddee29  pop rdx
0000794c94ddee2a  pop rcx
0000794c94ddee2b  pop rax
0000794c94ddee2c  add rsp, 0x08
0000794c94ddee30  jmp 0x0000794C94DDC2EE
0000794c94ddee35  sub rsp, 0x08
0000794c94ddee39  push rax
0000794c94ddee3a  push rcx
0000794c94ddee3b  push rdx
0000794c94ddee3c  push rdi
0000794c94ddee3d  push rsi
0000794c94ddee3e  push r8
0000794c94ddee40  push r9
0000794c94ddee42  push r10
0000794c94ddee44  push r11
0000794c94ddee46  sub rsp, 0xF0
0000794c94ddee4d  vmovaps [rsp], xmm0
0000794c94ddee52  vmovaps [rsp+0x10], xmm1
0000794c94ddee58  vmovaps [rsp+0x20], xmm2
0000794c94ddee5e  vmovaps [rsp+0x30], xmm3
0000794c94ddee64  vmovaps [rsp+0x40], xmm5
0000794c94ddee6a  vmovaps [rsp+0x50], xmm6
0000794c94ddee70  vmovaps [rsp+0x60], xmm7
0000794c94ddee76  vmovaps [rsp+0x70], xmm8
0000794c94ddee7c  vmovaps [rsp+0x80], xmm9
0000794c94ddee85  vmovaps [rsp+0x90], xmm10
0000794c94ddee8e  vmovaps [rsp+0xA0], xmm11
0000794c94ddee97  vmovaps [rsp+0xB0], xmm12
0000794c94ddeea0  vmovaps [rsp+0xC0], xmm13
0000794c94ddeea9  vmovaps [rsp+0xD0], xmm14
0000794c94ddeeb2  vmovaps [rsp+0xE0], xmm15
0000794c94ddeebb  sub rsp, 0x30
0000794c94ddeebf  movaps [rsp], xmm4
0000794c94ddeec3  movaps [rsp+0x10], xmm2
0000794c94ddeec8  movaps [rsp+0x20], xmm9
0000794c94ddeece  lea rdi, [rsp]
0000794c94ddeed2  mov esi, 0x00
0000794c94ddeed7  mov rax, 0x5AB2B8B81530
0000794c94ddeee1  call rax
0000794c94ddeee3  movaps xmm4, [rsp]
0000794c94ddeee7  add rsp, 0x30
0000794c94ddeeeb  vmovaps xmm0, [rsp]
0000794c94ddeef0  vmovaps xmm1, [rsp+0x10]
0000794c94ddeef6  vmovaps xmm2, [rsp+0x20]
0000794c94ddeefc  vmovaps xmm3, [rsp+0x30]
0000794c94ddef02  vmovaps xmm5, [rsp+0x40]
0000794c94ddef08  vmovaps xmm6, [rsp+0x50]
0000794c94ddef0e  vmovaps xmm7, [rsp+0x60]
0000794c94ddef14  vmovaps xmm8, [rsp+0x70]
0000794c94ddef1a  vmovaps xmm9, [rsp+0x80]
0000794c94ddef23  vmovaps xmm10, [rsp+0x90]
0000794c94ddef2c  vmovaps xmm11, [rsp+0xA0]
0000794c94ddef35  vmovaps xmm12, [rsp+0xB0]
0000794c94ddef3e  vmovaps xmm13, [rsp+0xC0]
0000794c94ddef47  vmovaps xmm14, [rsp+0xD0]
0000794c94ddef50  vmovaps xmm15, [rsp+0xE0]
0000794c94ddef59  add rsp, 0xF0
0000794c94ddef60  pop r11
0000794c94ddef62  pop r10
0000794c94ddef64  pop r9
0000794c94ddef66  pop r8
0000794c94ddef68  pop rsi
0000794c94ddef69  pop rdi
0000794c94ddef6a  pop rdx
0000794c94ddef6b  pop rcx
0000794c94ddef6c  pop rax
0000794c94ddef6d  add rsp, 0x08
0000794c94ddef71  jmp 0x0000794C94DDC31E
0000794c94ddef76  sub rsp, 0x08
0000794c94ddef7a  push rax
0000794c94ddef7b  push rcx
0000794c94ddef7c  push rdx
0000794c94ddef7d  push rdi
0000794c94ddef7e  push rsi
0000794c94ddef7f  push r8
0000794c94ddef81  push r9
0000794c94ddef83  push r10
0000794c94ddef85  push r11
0000794c94ddef87  sub rsp, 0xF0
0000794c94ddef8e  vmovaps [rsp], xmm0
0000794c94ddef93  vmovaps [rsp+0x10], xmm1
0000794c94ddef99  vmovaps [rsp+0x20], xmm2
0000794c94ddef9f  vmovaps [rsp+0x30], xmm3
0000794c94ddefa5  vmovaps [rsp+0x40], xmm4
0000794c94ddefab  vmovaps [rsp+0x50], xmm5
0000794c94ddefb1  vmovaps [rsp+0x60], xmm6
0000794c94ddefb7  vmovaps [rsp+0x70], xmm7
0000794c94ddefbd  vmovaps [rsp+0x80], xmm8
0000794c94ddefc6  vmovaps [rsp+0x90], xmm10
0000794c94ddefcf  vmovaps [rsp+0xA0], xmm11
0000794c94ddefd8  vmovaps [rsp+0xB0], xmm12
0000794c94ddefe1  vmovaps [rsp+0xC0], xmm13
0000794c94ddefea  vmovaps [rsp+0xD0], xmm14
0000794c94ddeff3  vmovaps [rsp+0xE0], xmm15
0000794c94ddeffc  sub rsp, 0x30
0000794c94ddf000  movaps [rsp], xmm9
0000794c94ddf005  movaps [rsp+0x10], xmm2
0000794c94ddf00a  movaps [rsp+0x20], xmm1
0000794c94ddf00f  lea rdi, [rsp]
0000794c94ddf013  mov esi, 0x00
0000794c94ddf018  mov rax, 0x5AB2B8B81530
0000794c94ddf022  call rax
0000794c94ddf024  movaps xmm9, [rsp]
0000794c94ddf029  add rsp, 0x30
0000794c94ddf02d  vmovaps xmm0, [rsp]
0000794c94ddf032  vmovaps xmm1, [rsp+0x10]
0000794c94ddf038  vmovaps xmm2, [rsp+0x20]
0000794c94ddf03e  vmovaps xmm3, [rsp+0x30]
0000794c94ddf044  vmovaps xmm4, [rsp+0x40]
0000794c94ddf04a  vmovaps xmm5, [rsp+0x50]
0000794c94ddf050  vmovaps xmm6, [rsp+0x60]
0000794c94ddf056  vmovaps xmm7, [rsp+0x70]
0000794c94ddf05c  vmovaps xmm8, [rsp+0x80]
0000794c94ddf065  vmovaps xmm10, [rsp+0x90]
0000794c94ddf06e  vmovaps xmm11, [rsp+0xA0]
0000794c94ddf077  vmovaps xmm12, [rsp+0xB0]
0000794c94ddf080  vmovaps xmm13, [rsp+0xC0]
0000794c94ddf089  vmovaps xmm14, [rsp+0xD0]
0000794c94ddf092  vmovaps xmm15, [rsp+0xE0]
0000794c94ddf09b  add rsp, 0xF0
0000794c94ddf0a2  pop r11
0000794c94ddf0a4  pop r10
0000794c94ddf0a6  pop r9
0000794c94ddf0a8  pop r8
0000794c94ddf0aa  pop rsi
0000794c94ddf0ab  pop rdi
0000794c94ddf0ac  pop rdx
0000794c94ddf0ad  pop rcx
0000794c94ddf0ae  pop rax
0000794c94ddf0af  add rsp, 0x08
0000794c94ddf0b3  jmp 0x0000794C94DDC354
0000794c94ddf0b8  sub rsp, 0x08
0000794c94ddf0bc  push rax
0000794c94ddf0bd  push rcx
0000794c94ddf0be  push rdx
0000794c94ddf0bf  push rdi
0000794c94ddf0c0  push rsi
0000794c94ddf0c1  push r8
0000794c94ddf0c3  push r9
0000794c94ddf0c5  push r10
0000794c94ddf0c7  push r11
0000794c94ddf0c9  sub rsp, 0xF0
0000794c94ddf0d0  vmovaps [rsp], xmm0
0000794c94ddf0d5  vmovaps [rsp+0x10], xmm2
0000794c94ddf0db  vmovaps [rsp+0x20], xmm3
0000794c94ddf0e1  vmovaps [rsp+0x30], xmm4
0000794c94ddf0e7  vmovaps [rsp+0x40], xmm5
0000794c94ddf0ed  vmovaps [rsp+0x50], xmm6
0000794c94ddf0f3  vmovaps [rsp+0x60], xmm7
0000794c94ddf0f9  vmovaps [rsp+0x70], xmm8
0000794c94ddf0ff  vmovaps [rsp+0x80], xmm9
0000794c94ddf108  vmovaps [rsp+0x90], xmm10
0000794c94ddf111  vmovaps [rsp+0xA0], xmm11
0000794c94ddf11a  vmovaps [rsp+0xB0], xmm12
0000794c94ddf123  vmovaps [rsp+0xC0], xmm13
0000794c94ddf12c  vmovaps [rsp+0xD0], xmm14
0000794c94ddf135  vmovaps [rsp+0xE0], xmm15
0000794c94ddf13e  sub rsp, 0x30
0000794c94ddf142  movaps [rsp], xmm1
0000794c94ddf146  movaps [rsp+0x10], xmm15
0000794c94ddf14c  movaps [rsp+0x20], xmm6
0000794c94ddf151  lea rdi, [rsp]
0000794c94ddf155  mov esi, 0x00
0000794c94ddf15a  mov rax, 0x5AB2B8B81530
0000794c94ddf164  call rax
0000794c94ddf166  movaps xmm1, [rsp]
0000794c94ddf16a  add rsp, 0x30
0000794c94ddf16e  vmovaps xmm0, [rsp]
0000794c94ddf173  vmovaps xmm2, [rsp+0x10]
0000794c94ddf179  vmovaps xmm3, [rsp+0x20]
0000794c94ddf17f  vmovaps xmm4, [rsp+0x30]
0000794c94ddf185  vmovaps xmm5, [rsp+0x40]
0000794c94ddf18b  vmovaps xmm6, [rsp+0x50]
0000794c94ddf191  vmovaps xmm7, [rsp+0x60]
0000794c94ddf197  vmovaps xmm8, [rsp+0x70]
0000794c94ddf19d  vmovaps xmm9, [rsp+0x80]
0000794c94ddf1a6  vmovaps xmm10, [rsp+0x90]
0000794c94ddf1af  vmovaps xmm11, [rsp+0xA0]
0000794c94ddf1b8  vmovaps xmm12, [rsp+0xB0]
0000794c94ddf1c1  vmovaps xmm13, [rsp+0xC0]
0000794c94ddf1ca  vmovaps xmm14, [rsp+0xD0]
0000794c94ddf1d3  vmovaps xmm15, [rsp+0xE0]
0000794c94ddf1dc  add rsp, 0xF0
0000794c94ddf1e3  pop r11
0000794c94ddf1e5  pop r10
0000794c94ddf1e7  pop r9
0000794c94ddf1e9  pop r8
0000794c94ddf1eb  pop rsi
0000794c94ddf1ec  pop rdi
0000794c94ddf1ed  pop rdx
0000794c94ddf1ee  pop rcx
0000794c94ddf1ef  pop rax
0000794c94ddf1f0  add rsp, 0x08
0000794c94ddf1f4  jmp 0x0000794C94DDC375
0000794c94ddf1f9  sub rsp, 0x08
0000794c94ddf1fd  push rax
0000794c94ddf1fe  push rcx
0000794c94ddf1ff  push rdx
0000794c94ddf200  push rdi
0000794c94ddf201  push rsi
0000794c94ddf202  push r8
0000794c94ddf204  push r9
0000794c94ddf206  push r10
0000794c94ddf208  push r11
0000794c94ddf20a  sub rsp, 0xF0
0000794c94ddf211  vmovaps [rsp], xmm0
0000794c94ddf216  vmovaps [rsp+0x10], xmm1
0000794c94ddf21c  vmovaps [rsp+0x20], xmm2
0000794c94ddf222  vmovaps [rsp+0x30], xmm3
0000794c94ddf228  vmovaps [rsp+0x40], xmm4
0000794c94ddf22e  vmovaps [rsp+0x50], xmm5
0000794c94ddf234  vmovaps [rsp+0x60], xmm6
0000794c94ddf23a  vmovaps [rsp+0x70], xmm7
0000794c94ddf240  vmovaps [rsp+0x80], xmm8
0000794c94ddf249  vmovaps [rsp+0x90], xmm9
0000794c94ddf252  vmovaps [rsp+0xA0], xmm10
0000794c94ddf25b  vmovaps [rsp+0xB0], xmm11
0000794c94ddf264  vmovaps [rsp+0xC0], xmm12
0000794c94ddf26d  vmovaps [rsp+0xD0], xmm13
0000794c94ddf276  vmovaps [rsp+0xE0], xmm14
0000794c94ddf27f  sub rsp, 0x30
0000794c94ddf283  movaps [rsp], xmm15
0000794c94ddf288  movaps [rsp+0x10], xmm5
0000794c94ddf28d  movaps [rsp+0x20], xmm3
0000794c94ddf292  lea rdi, [rsp]
0000794c94ddf296  mov esi, 0x00
0000794c94ddf29b  mov rax, 0x5AB2B8B81530
0000794c94ddf2a5  call rax
0000794c94ddf2a7  movaps xmm15, [rsp]
0000794c94ddf2ac  add rsp, 0x30
0000794c94ddf2b0  vmovaps xmm0, [rsp]
0000794c94ddf2b5  vmovaps xmm1, [rsp+0x10]
0000794c94ddf2bb  vmovaps xmm2, [rsp+0x20]
0000794c94ddf2c1  vmovaps xmm3, [rsp+0x30]
0000794c94ddf2c7  vmovaps xmm4, [rsp+0x40]
0000794c94ddf2cd  vmovaps xmm5, [rsp+0x50]
0000794c94ddf2d3  vmovaps xmm6, [rsp+0x60]
0000794c94ddf2d9  vmovaps xmm7, [rsp+0x70]
0000794c94ddf2df  vmovaps xmm8, [rsp+0x80]
0000794c94ddf2e8  vmovaps xmm9, [rsp+0x90]
0000794c94ddf2f1  vmovaps xmm10, [rsp+0xA0]
0000794c94ddf2fa  vmovaps xmm11, [rsp+0xB0]
0000794c94ddf303  vmovaps xmm12, [rsp+0xC0]
0000794c94ddf30c  vmovaps xmm13, [rsp+0xD0]
0000794c94ddf315  vmovaps xmm14, [rsp+0xE0]
0000794c94ddf31e  add rsp, 0xF0
0000794c94ddf325  pop r11
0000794c94ddf327  pop r10
0000794c94ddf329  pop r9
0000794c94ddf32b  pop r8
0000794c94ddf32d  pop rsi
0000794c94ddf32e  pop rdi
0000794c94ddf32f  pop rdx
0000794c94ddf330  pop rcx
0000794c94ddf331  pop rax
0000794c94ddf332  add rsp, 0x08
0000794c94ddf336  jmp 0x0000794C94DDC38F
0000794c94ddf33b  sub rsp, 0x08
0000794c94ddf33f  push rax
0000794c94ddf340  push rcx
0000794c94ddf341  push rdx
0000794c94ddf342  push rdi
0000794c94ddf343  push rsi
0000794c94ddf344  push r8
0000794c94ddf346  push r9
0000794c94ddf348  push r10
0000794c94ddf34a  push r11
0000794c94ddf34c  sub rsp, 0xF0
0000794c94ddf353  vmovaps [rsp], xmm0
0000794c94ddf358  vmovaps [rsp+0x10], xmm1
0000794c94ddf35e  vmovaps [rsp+0x20], xmm2
0000794c94ddf364  vmovaps [rsp+0x30], xmm3
0000794c94ddf36a  vmovaps [rsp+0x40], xmm4
0000794c94ddf370  vmovaps [rsp+0x50], xmm6
0000794c94ddf376  vmovaps [rsp+0x60], xmm7
0000794c94ddf37c  vmovaps [rsp+0x70], xmm8
0000794c94ddf382  vmovaps [rsp+0x80], xmm9
0000794c94ddf38b  vmovaps [rsp+0x90], xmm10
0000794c94ddf394  vmovaps [rsp+0xA0], xmm11
0000794c94ddf39d  vmovaps [rsp+0xB0], xmm12
0000794c94ddf3a6  vmovaps [rsp+0xC0], xmm13
0000794c94ddf3af  vmovaps [rsp+0xD0], xmm14
0000794c94ddf3b8  vmovaps [rsp+0xE0], xmm15
0000794c94ddf3c1  sub rsp, 0x30
0000794c94ddf3c5  movaps [rsp], xmm5
0000794c94ddf3c9  movaps [rsp+0x10], xmm8
0000794c94ddf3cf  movaps [rsp+0x20], xmm6
0000794c94ddf3d4  lea rdi, [rsp]
0000794c94ddf3d8  mov esi, 0x00
0000794c94ddf3dd  mov rax, 0x5AB2B8B81530
0000794c94ddf3e7  call rax
0000794c94ddf3e9  movaps xmm5, [rsp]
0000794c94ddf3ed  add rsp, 0x30
0000794c94ddf3f1  vmovaps xmm0, [rsp]
0000794c94ddf3f6  vmovaps xmm1, [rsp+0x10]
0000794c94ddf3fc  vmovaps xmm2, [rsp+0x20]
0000794c94ddf402  vmovaps xmm3, [rsp+0x30]
0000794c94ddf408  vmovaps xmm4, [rsp+0x40]
0000794c94ddf40e  vmovaps xmm6, [rsp+0x50]
0000794c94ddf414  vmovaps xmm7, [rsp+0x60]
0000794c94ddf41a  vmovaps xmm8, [rsp+0x70]
0000794c94ddf420  vmovaps xmm9, [rsp+0x80]
0000794c94ddf429  vmovaps xmm10, [rsp+0x90]
0000794c94ddf432  vmovaps xmm11, [rsp+0xA0]
0000794c94ddf43b  vmovaps xmm12, [rsp+0xB0]
0000794c94ddf444  vmovaps xmm13, [rsp+0xC0]
0000794c94ddf44d  vmovaps xmm14, [rsp+0xD0]
0000794c94ddf456  vmovaps xmm15, [rsp+0xE0]
0000794c94ddf45f  add rsp, 0xF0
0000794c94ddf466  pop r11
0000794c94ddf468  pop r10
0000794c94ddf46a  pop r9
0000794c94ddf46c  pop r8
0000794c94ddf46e  pop rsi
0000794c94ddf46f  pop rdi
0000794c94ddf470  pop rdx
0000794c94ddf471  pop rcx
0000794c94ddf472  pop rax
0000794c94ddf473  add rsp, 0x08
0000794c94ddf477  jmp 0x0000794C94DDC3B3
0000794c94ddf47c  sub rsp, 0x08
0000794c94ddf480  push rax
0000794c94ddf481  push rcx
0000794c94ddf482  push rdx
0000794c94ddf483  push rdi
0000794c94ddf484  push rsi
0000794c94ddf485  push r8
0000794c94ddf487  push r9
0000794c94ddf489  push r10
0000794c94ddf48b  push r11
0000794c94ddf48d  sub rsp, 0xF0
0000794c94ddf494  vmovaps [rsp], xmm0
0000794c94ddf499  vmovaps [rsp+0x10], xmm1
0000794c94ddf49f  vmovaps [rsp+0x20], xmm2
0000794c94ddf4a5  vmovaps [rsp+0x30], xmm3
0000794c94ddf4ab  vmovaps [rsp+0x40], xmm4
0000794c94ddf4b1  vmovaps [rsp+0x50], xmm5
0000794c94ddf4b7  vmovaps [rsp+0x60], xmm7
0000794c94ddf4bd  vmovaps [rsp+0x70], xmm8
0000794c94ddf4c3  vmovaps [rsp+0x80], xmm9
0000794c94ddf4cc  vmovaps [rsp+0x90], xmm10
0000794c94ddf4d5  vmovaps [rsp+0xA0], xmm11
0000794c94ddf4de  vmovaps [rsp+0xB0], xmm12
0000794c94ddf4e7  vmovaps [rsp+0xC0], xmm13
0000794c94ddf4f0  vmovaps [rsp+0xD0], xmm14
0000794c94ddf4f9  vmovaps [rsp+0xE0], xmm15
0000794c94ddf502  sub rsp, 0x30
0000794c94ddf506  movaps [rsp], xmm6
0000794c94ddf50a  movaps [rsp+0x10], xmm10
0000794c94ddf510  movaps [rsp+0x20], xmm8
0000794c94ddf516  lea rdi, [rsp]
0000794c94ddf51a  mov esi, 0x00
0000794c94ddf51f  mov rax, 0x5AB2B8B81530
0000794c94ddf529  call rax
0000794c94ddf52b  movaps xmm6, [rsp]
0000794c94ddf52f  add rsp, 0x30
0000794c94ddf533  vmovaps xmm0, [rsp]
0000794c94ddf538  vmovaps xmm1, [rsp+0x10]
0000794c94ddf53e  vmovaps xmm2, [rsp+0x20]
0000794c94ddf544  vmovaps xmm3, [rsp+0x30]
0000794c94ddf54a  vmovaps xmm4, [rsp+0x40]
0000794c94ddf550  vmovaps xmm5, [rsp+0x50]
0000794c94ddf556  vmovaps xmm7, [rsp+0x60]
0000794c94ddf55c  vmovaps xmm8, [rsp+0x70]
0000794c94ddf562  vmovaps xmm9, [rsp+0x80]
0000794c94ddf56b  vmovaps xmm10, [rsp+0x90]
0000794c94ddf574  vmovaps xmm11, [rsp+0xA0]
0000794c94ddf57d  vmovaps xmm12, [rsp+0xB0]
0000794c94ddf586  vmovaps xmm13, [rsp+0xC0]
0000794c94ddf58f  vmovaps xmm14, [rsp+0xD0]
0000794c94ddf598  vmovaps xmm15, [rsp+0xE0]
0000794c94ddf5a1  add rsp, 0xF0
0000794c94ddf5a8  pop r11
0000794c94ddf5aa  pop r10
0000794c94ddf5ac  pop r9
0000794c94ddf5ae  pop r8
0000794c94ddf5b0  pop rsi
0000794c94ddf5b1  pop rdi
0000794c94ddf5b2  pop rdx
0000794c94ddf5b3  pop rcx
0000794c94ddf5b4  pop rax
0000794c94ddf5b5  add rsp, 0x08
0000794c94ddf5b9  jmp 0x0000794C94DDC3D8
0000794c94ddf5be  sub rsp, 0x08
0000794c94ddf5c2  push rax
0000794c94ddf5c3  push rcx
0000794c94ddf5c4  push rdx
0000794c94ddf5c5  push rdi
0000794c94ddf5c6  push rsi
0000794c94ddf5c7  push r8
0000794c94ddf5c9  push r9
0000794c94ddf5cb  push r10
0000794c94ddf5cd  push r11
0000794c94ddf5cf  sub rsp, 0xF0
0000794c94ddf5d6  vmovaps [rsp], xmm0
0000794c94ddf5db  vmovaps [rsp+0x10], xmm1
0000794c94ddf5e1  vmovaps [rsp+0x20], xmm2
0000794c94ddf5e7  vmovaps [rsp+0x30], xmm3
0000794c94ddf5ed  vmovaps [rsp+0x40], xmm4
0000794c94ddf5f3  vmovaps [rsp+0x50], xmm5
0000794c94ddf5f9  vmovaps [rsp+0x60], xmm6
0000794c94ddf5ff  vmovaps [rsp+0x70], xmm7
0000794c94ddf605  vmovaps [rsp+0x80], xmm8
0000794c94ddf60e  vmovaps [rsp+0x90], xmm9
0000794c94ddf617  vmovaps [rsp+0xA0], xmm11
0000794c94ddf620  vmovaps [rsp+0xB0], xmm12
0000794c94ddf629  vmovaps [rsp+0xC0], xmm13
0000794c94ddf632  vmovaps [rsp+0xD0], xmm14
0000794c94ddf63b  vmovaps [rsp+0xE0], xmm15
0000794c94ddf644  sub rsp, 0x30
0000794c94ddf648  movaps [rsp], xmm10
0000794c94ddf64d  movaps [rsp+0x10], xmm8
0000794c94ddf653  movaps [rsp+0x20], xmm14
0000794c94ddf659  lea rdi, [rsp]
0000794c94ddf65d  mov esi, 0x00
0000794c94ddf662  mov rax, 0x5AB2B8B81530
0000794c94ddf66c  call rax
0000794c94ddf66e  movaps xmm10, [rsp]
0000794c94ddf673  add rsp, 0x30
0000794c94ddf677  vmovaps xmm0, [rsp]
0000794c94ddf67c  vmovaps xmm1, [rsp+0x10]
0000794c94ddf682  vmovaps xmm2, [rsp+0x20]
0000794c94ddf688  vmovaps xmm3, [rsp+0x30]
0000794c94ddf68e  vmovaps xmm4, [rsp+0x40]
0000794c94ddf694  vmovaps xmm5, [rsp+0x50]
0000794c94ddf69a  vmovaps xmm6, [rsp+0x60]
0000794c94ddf6a0  vmovaps xmm7, [rsp+0x70]
0000794c94ddf6a6  vmovaps xmm8, [rsp+0x80]
0000794c94ddf6af  vmovaps xmm9, [rsp+0x90]
0000794c94ddf6b8  vmovaps xmm11, [rsp+0xA0]
0000794c94ddf6c1  vmovaps xmm12, [rsp+0xB0]
0000794c94ddf6ca  vmovaps xmm13, [rsp+0xC0]
0000794c94ddf6d3  vmovaps xmm14, [rsp+0xD0]
0000794c94ddf6dc  vmovaps xmm15, [rsp+0xE0]
0000794c94ddf6e5  add rsp, 0xF0
0000794c94ddf6ec  pop r11
0000794c94ddf6ee  pop r10
0000794c94ddf6f0  pop r9
0000794c94ddf6f2  pop r8
0000794c94ddf6f4  pop rsi
0000794c94ddf6f5  pop rdi
0000794c94ddf6f6  pop rdx
0000794c94ddf6f7  pop rcx
0000794c94ddf6f8  pop rax
0000794c94ddf6f9  add rsp, 0x08
0000794c94ddf6fd  jmp 0x0000794C94DDC3F8
0000794c94ddf702  sub rsp, 0x08
0000794c94ddf706  push rax
0000794c94ddf707  push rcx
0000794c94ddf708  push rdx
0000794c94ddf709  push rdi
0000794c94ddf70a  push rsi
0000794c94ddf70b  push r8
0000794c94ddf70d  push r9
0000794c94ddf70f  push r10
0000794c94ddf711  push r11
0000794c94ddf713  sub rsp, 0xF0
0000794c94ddf71a  vmovaps [rsp], xmm0
0000794c94ddf71f  vmovaps [rsp+0x10], xmm1
0000794c94ddf725  vmovaps [rsp+0x20], xmm2
0000794c94ddf72b  vmovaps [rsp+0x30], xmm3
0000794c94ddf731  vmovaps [rsp+0x40], xmm4
0000794c94ddf737  vmovaps [rsp+0x50], xmm5
0000794c94ddf73d  vmovaps [rsp+0x60], xmm6
0000794c94ddf743  vmovaps [rsp+0x70], xmm7
0000794c94ddf749  vmovaps [rsp+0x80], xmm8
0000794c94ddf752  vmovaps [rsp+0x90], xmm9
0000794c94ddf75b  vmovaps [rsp+0xA0], xmm10
0000794c94ddf764  vmovaps [rsp+0xB0], xmm11
0000794c94ddf76d  vmovaps [rsp+0xC0], xmm12
0000794c94ddf776  vmovaps [rsp+0xD0], xmm13
0000794c94ddf77f  vmovaps [rsp+0xE0], xmm15
0000794c94ddf788  sub rsp, 0x30
0000794c94ddf78c  movaps [rsp], xmm14
0000794c94ddf791  movaps [rsp+0x10], xmm8
0000794c94ddf797  movaps [rsp+0x20], xmm4
0000794c94ddf79c  lea rdi, [rsp]
0000794c94ddf7a0  mov esi, 0x00
0000794c94ddf7a5  mov rax, 0x5AB2B8B81530
0000794c94ddf7af  call rax
0000794c94ddf7b1  movaps xmm14, [rsp]
0000794c94ddf7b6  add rsp, 0x30
0000794c94ddf7ba  vmovaps xmm0, [rsp]
0000794c94ddf7bf  vmovaps xmm1, [rsp+0x10]
0000794c94ddf7c5  vmovaps xmm2, [rsp+0x20]
0000794c94ddf7cb  vmovaps xmm3, [rsp+0x30]
0000794c94ddf7d1  vmovaps xmm4, [rsp+0x40]
0000794c94ddf7d7  vmovaps xmm5, [rsp+0x50]
0000794c94ddf7dd  vmovaps xmm6, [rsp+0x60]
0000794c94ddf7e3  vmovaps xmm7, [rsp+0x70]
0000794c94ddf7e9  vmovaps xmm8, [rsp+0x80]
0000794c94ddf7f2  vmovaps xmm9, [rsp+0x90]
0000794c94ddf7fb  vmovaps xmm10, [rsp+0xA0]
0000794c94ddf804  vmovaps xmm11, [rsp+0xB0]
0000794c94ddf80d  vmovaps xmm12, [rsp+0xC0]
0000794c94ddf816  vmovaps xmm13, [rsp+0xD0]
0000794c94ddf81f  vmovaps xmm15, [rsp+0xE0]
0000794c94ddf828  add rsp, 0xF0
0000794c94ddf82f  pop r11
0000794c94ddf831  pop r10
0000794c94ddf833  pop r9
0000794c94ddf835  pop r8
0000794c94ddf837  pop rsi
0000794c94ddf838  pop rdi
0000794c94ddf839  pop rdx
0000794c94ddf83a  pop rcx
0000794c94ddf83b  pop rax
0000794c94ddf83c  add rsp, 0x08
0000794c94ddf840  jmp 0x0000794C94DDC418
0000794c94ddf845  sub rsp, 0x08
0000794c94ddf849  push rax
0000794c94ddf84a  push rcx
0000794c94ddf84b  push rdx
0000794c94ddf84c  push rdi
0000794c94ddf84d  push rsi
0000794c94ddf84e  push r8
0000794c94ddf850  push r9
0000794c94ddf852  push r10
0000794c94ddf854  push r11
0000794c94ddf856  sub rsp, 0xF0
0000794c94ddf85d  vmovaps [rsp], xmm0
0000794c94ddf862  vmovaps [rsp+0x10], xmm1
0000794c94ddf868  vmovaps [rsp+0x20], xmm2
0000794c94ddf86e  vmovaps [rsp+0x30], xmm3
0000794c94ddf874  vmovaps [rsp+0x40], xmm5
0000794c94ddf87a  vmovaps [rsp+0x50], xmm6
0000794c94ddf880  vmovaps [rsp+0x60], xmm7
0000794c94ddf886  vmovaps [rsp+0x70], xmm8
0000794c94ddf88c  vmovaps [rsp+0x80], xmm9
0000794c94ddf895  vmovaps [rsp+0x90], xmm10
0000794c94ddf89e  vmovaps [rsp+0xA0], xmm11
0000794c94ddf8a7  vmovaps [rsp+0xB0], xmm12
0000794c94ddf8b0  vmovaps [rsp+0xC0], xmm13
0000794c94ddf8b9  vmovaps [rsp+0xD0], xmm14
0000794c94ddf8c2  vmovaps [rsp+0xE0], xmm15
0000794c94ddf8cb  sub rsp, 0x30
0000794c94ddf8cf  movaps [rsp], xmm4
0000794c94ddf8d3  movaps [rsp+0x10], xmm13
0000794c94ddf8d9  movaps [rsp+0x20], xmm8
0000794c94ddf8df  lea rdi, [rsp]
0000794c94ddf8e3  mov esi, 0x00
0000794c94ddf8e8  mov rax, 0x5AB2B8B81530
0000794c94ddf8f2  call rax
0000794c94ddf8f4  movaps xmm4, [rsp]
0000794c94ddf8f8  add rsp, 0x30
0000794c94ddf8fc  vmovaps xmm0, [rsp]
0000794c94ddf901  vmovaps xmm1, [rsp+0x10]
0000794c94ddf907  vmovaps xmm2, [rsp+0x20]
0000794c94ddf90d  vmovaps xmm3, [rsp+0x30]
0000794c94ddf913  vmovaps xmm5, [rsp+0x40]
0000794c94ddf919  vmovaps xmm6, [rsp+0x50]
0000794c94ddf91f  vmovaps xmm7, [rsp+0x60]
0000794c94ddf925  vmovaps xmm8, [rsp+0x70]
0000794c94ddf92b  vmovaps xmm9, [rsp+0x80]
0000794c94ddf934  vmovaps xmm10, [rsp+0x90]
0000794c94ddf93d  vmovaps xmm11, [rsp+0xA0]
0000794c94ddf946  vmovaps xmm12, [rsp+0xB0]
0000794c94ddf94f  vmovaps xmm13, [rsp+0xC0]
0000794c94ddf958  vmovaps xmm14, [rsp+0xD0]
0000794c94ddf961  vmovaps xmm15, [rsp+0xE0]
0000794c94ddf96a  add rsp, 0xF0
0000794c94ddf971  pop r11
0000794c94ddf973  pop r10
0000794c94ddf975  pop r9
0000794c94ddf977  pop r8
0000794c94ddf979  pop rsi
0000794c94ddf97a  pop rdi
0000794c94ddf97b  pop rdx
0000794c94ddf97c  pop rcx
0000794c94ddf97d  pop rax
0000794c94ddf97e  add rsp, 0x08
0000794c94ddf982  jmp 0x0000794C94DDC43D
0000794c94ddf987  sub rsp, 0x08
0000794c94ddf98b  push rax
0000794c94ddf98c  push rcx
0000794c94ddf98d  push rdx
0000794c94ddf98e  push rdi
0000794c94ddf98f  push rsi
0000794c94ddf990  push r8
0000794c94ddf992  push r9
0000794c94ddf994  push r10
0000794c94ddf996  push r11
0000794c94ddf998  sub rsp, 0xF0
0000794c94ddf99f  vmovaps [rsp], xmm0
0000794c94ddf9a4  vmovaps [rsp+0x10], xmm1
0000794c94ddf9aa  vmovaps [rsp+0x20], xmm2
0000794c94ddf9b0  vmovaps [rsp+0x30], xmm3
0000794c94ddf9b6  vmovaps [rsp+0x40], xmm4
0000794c94ddf9bc  vmovaps [rsp+0x50], xmm5
0000794c94ddf9c2  vmovaps [rsp+0x60], xmm6
0000794c94ddf9c8  vmovaps [rsp+0x70], xmm7
0000794c94ddf9ce  vmovaps [rsp+0x80], xmm8
0000794c94ddf9d7  vmovaps [rsp+0x90], xmm9
0000794c94ddf9e0  vmovaps [rsp+0xA0], xmm10
0000794c94ddf9e9  vmovaps [rsp+0xB0], xmm11
0000794c94ddf9f2  vmovaps [rsp+0xC0], xmm12
0000794c94ddf9fb  vmovaps [rsp+0xD0], xmm14
0000794c94ddfa04  vmovaps [rsp+0xE0], xmm15
0000794c94ddfa0d  sub rsp, 0x30
0000794c94ddfa11  movaps [rsp], xmm13
0000794c94ddfa16  movaps [rsp+0x10], xmm15
0000794c94ddfa1c  movaps [rsp+0x20], xmm9
0000794c94ddfa22  lea rdi, [rsp]
0000794c94ddfa26  mov esi, 0x00
0000794c94ddfa2b  mov rax, 0x5AB2B8B81530
0000794c94ddfa35  call rax
0000794c94ddfa37  movaps xmm13, [rsp]
0000794c94ddfa3c  add rsp, 0x30
0000794c94ddfa40  vmovaps xmm0, [rsp]
0000794c94ddfa45  vmovaps xmm1, [rsp+0x10]
0000794c94ddfa4b  vmovaps xmm2, [rsp+0x20]
0000794c94ddfa51  vmovaps xmm3, [rsp+0x30]
0000794c94ddfa57  vmovaps xmm4, [rsp+0x40]
0000794c94ddfa5d  vmovaps xmm5, [rsp+0x50]
0000794c94ddfa63  vmovaps xmm6, [rsp+0x60]
0000794c94ddfa69  vmovaps xmm7, [rsp+0x70]
0000794c94ddfa6f  vmovaps xmm8, [rsp+0x80]
0000794c94ddfa78  vmovaps xmm9, [rsp+0x90]
0000794c94ddfa81  vmovaps xmm10, [rsp+0xA0]
0000794c94ddfa8a  vmovaps xmm11, [rsp+0xB0]
0000794c94ddfa93  vmovaps xmm12, [rsp+0xC0]
0000794c94ddfa9c  vmovaps xmm14, [rsp+0xD0]
0000794c94ddfaa5  vmovaps xmm15, [rsp+0xE0]
0000794c94ddfaae  add rsp, 0xF0
0000794c94ddfab5  pop r11
0000794c94ddfab7  pop r10
0000794c94ddfab9  pop r9
0000794c94ddfabb  pop r8
0000794c94ddfabd  pop rsi
0000794c94ddfabe  pop rdi
0000794c94ddfabf  pop rdx
0000794c94ddfac0  pop rcx
0000794c94ddfac1  pop rax
0000794c94ddfac2  add rsp, 0x08
0000794c94ddfac6  jmp 0x0000794C94DDC458
0000794c94ddfacb  sub rsp, 0x08
0000794c94ddfacf  push rax
0000794c94ddfad0  push rcx
0000794c94ddfad1  push rdx
0000794c94ddfad2  push rdi
0000794c94ddfad3  push rsi
0000794c94ddfad4  push r8
0000794c94ddfad6  push r9
0000794c94ddfad8  push r10
0000794c94ddfada  push r11
0000794c94ddfadc  sub rsp, 0xF0
0000794c94ddfae3  vmovaps [rsp], xmm0
0000794c94ddfae8  vmovaps [rsp+0x10], xmm1
0000794c94ddfaee  vmovaps [rsp+0x20], xmm2
0000794c94ddfaf4  vmovaps [rsp+0x30], xmm3
0000794c94ddfafa  vmovaps [rsp+0x40], xmm4
0000794c94ddfb00  vmovaps [rsp+0x50], xmm5
0000794c94ddfb06  vmovaps [rsp+0x60], xmm6
0000794c94ddfb0c  vmovaps [rsp+0x70], xmm7
0000794c94ddfb12  vmovaps [rsp+0x80], xmm8
0000794c94ddfb1b  vmovaps [rsp+0x90], xmm9
0000794c94ddfb24  vmovaps [rsp+0xA0], xmm10
0000794c94ddfb2d  vmovaps [rsp+0xB0], xmm11
0000794c94ddfb36  vmovaps [rsp+0xC0], xmm12
0000794c94ddfb3f  vmovaps [rsp+0xD0], xmm13
0000794c94ddfb48  vmovaps [rsp+0xE0], xmm14
0000794c94ddfb51  sub rsp, 0x30
0000794c94ddfb55  movaps [rsp], xmm15
0000794c94ddfb5a  movaps [rsp+0x10], xmm1
0000794c94ddfb5f  movaps [rsp+0x20], xmm5
0000794c94ddfb64  lea rdi, [rsp]
0000794c94ddfb68  mov esi, 0x00
0000794c94ddfb6d  mov rax, 0x5AB2B8B81530
0000794c94ddfb77  call rax
0000794c94ddfb79  movaps xmm15, [rsp]
0000794c94ddfb7e  add rsp, 0x30
0000794c94ddfb82  vmovaps xmm0, [rsp]
0000794c94ddfb87  vmovaps xmm1, [rsp+0x10]
0000794c94ddfb8d  vmovaps xmm2, [rsp+0x20]
0000794c94ddfb93  vmovaps xmm3, [rsp+0x30]
0000794c94ddfb99  vmovaps xmm4, [rsp+0x40]
0000794c94ddfb9f  vmovaps xmm5, [rsp+0x50]
0000794c94ddfba5  vmovaps xmm6, [rsp+0x60]
0000794c94ddfbab  vmovaps xmm7, [rsp+0x70]
0000794c94ddfbb1  vmovaps xmm8, [rsp+0x80]
0000794c94ddfbba  vmovaps xmm9, [rsp+0x90]
0000794c94ddfbc3  vmovaps xmm10, [rsp+0xA0]
0000794c94ddfbcc  vmovaps xmm11, [rsp+0xB0]
0000794c94ddfbd5  vmovaps xmm12, [rsp+0xC0]
0000794c94ddfbde  vmovaps xmm13, [rsp+0xD0]
0000794c94ddfbe7  vmovaps xmm14, [rsp+0xE0]
0000794c94ddfbf0  add rsp, 0xF0
0000794c94ddfbf7  pop r11
0000794c94ddfbf9  pop r10
0000794c94ddfbfb  pop r9
0000794c94ddfbfd  pop r8
0000794c94ddfbff  pop rsi
0000794c94ddfc00  pop rdi
0000794c94ddfc01  pop rdx
0000794c94ddfc02  pop rcx
0000794c94ddfc03  pop rax
0000794c94ddfc04  add rsp, 0x08
0000794c94ddfc08  jmp 0x0000794C94DDC473
0000794c94ddfc0d  call 0x0000794C94CB52F0
0000794c94ddfc12  jmp 0x0000794C94DDC4CE
0000794c94ddfc17  sub rsp, 0x08
0000794c94ddfc1b  push rax
0000794c94ddfc1c  push rcx
0000794c94ddfc1d  push rdx
0000794c94ddfc1e  push rdi
0000794c94ddfc1f  push rsi
0000794c94ddfc20  push r8
0000794c94ddfc22  push r9
0000794c94ddfc24  push r10
0000794c94ddfc26  push r11
0000794c94ddfc28  sub rsp, 0xF0
0000794c94ddfc2f  vmovaps [rsp], xmm0
0000794c94ddfc34  vmovaps [rsp+0x10], xmm1
0000794c94ddfc3a  vmovaps [rsp+0x20], xmm2
0000794c94ddfc40  vmovaps [rsp+0x30], xmm3
0000794c94ddfc46  vmovaps [rsp+0x40], xmm4
0000794c94ddfc4c  vmovaps [rsp+0x50], xmm5
0000794c94ddfc52  vmovaps [rsp+0x60], xmm6
0000794c94ddfc58  vmovaps [rsp+0x70], xmm7
0000794c94ddfc5e  vmovaps [rsp+0x80], xmm8
0000794c94ddfc67  vmovaps [rsp+0x90], xmm10
0000794c94ddfc70  vmovaps [rsp+0xA0], xmm11
0000794c94ddfc79  vmovaps [rsp+0xB0], xmm12
0000794c94ddfc82  vmovaps [rsp+0xC0], xmm13
0000794c94ddfc8b  vmovaps [rsp+0xD0], xmm14
0000794c94ddfc94  vmovaps [rsp+0xE0], xmm15
0000794c94ddfc9d  sub rsp, 0x30
0000794c94ddfca1  movaps [rsp], xmm9
0000794c94ddfca6  movaps [rsp+0x10], xmm8
0000794c94ddfcac  movaps [rsp+0x20], xmm11
0000794c94ddfcb2  lea rdi, [rsp]
0000794c94ddfcb6  mov esi, 0x00
0000794c94ddfcbb  mov rax, 0x5AB2B8B81530
0000794c94ddfcc5  call rax
0000794c94ddfcc7  movaps xmm9, [rsp]
0000794c94ddfccc  add rsp, 0x30
0000794c94ddfcd0  vmovaps xmm0, [rsp]
0000794c94ddfcd5  vmovaps xmm1, [rsp+0x10]
0000794c94ddfcdb  vmovaps xmm2, [rsp+0x20]
0000794c94ddfce1  vmovaps xmm3, [rsp+0x30]
0000794c94ddfce7  vmovaps xmm4, [rsp+0x40]
0000794c94ddfced  vmovaps xmm5, [rsp+0x50]
0000794c94ddfcf3  vmovaps xmm6, [rsp+0x60]
0000794c94ddfcf9  vmovaps xmm7, [rsp+0x70]
0000794c94ddfcff  vmovaps xmm8, [rsp+0x80]
0000794c94ddfd08  vmovaps xmm10, [rsp+0x90]
0000794c94ddfd11  vmovaps xmm11, [rsp+0xA0]
0000794c94ddfd1a  vmovaps xmm12, [rsp+0xB0]
0000794c94ddfd23  vmovaps xmm13, [rsp+0xC0]
0000794c94ddfd2c  vmovaps xmm14, [rsp+0xD0]
0000794c94ddfd35  vmovaps xmm15, [rsp+0xE0]
0000794c94ddfd3e  add rsp, 0xF0
0000794c94ddfd45  pop r11
0000794c94ddfd47  pop r10
0000794c94ddfd49  pop r9
0000794c94ddfd4b  pop r8
0000794c94ddfd4d  pop rsi
0000794c94ddfd4e  pop rdi
0000794c94ddfd4f  pop rdx
0000794c94ddfd50  pop rcx
0000794c94ddfd51  pop rax
0000794c94ddfd52  add rsp, 0x08
0000794c94ddfd56  jmp 0x0000794C94DDC505
0000794c94ddfd5b  sub rsp, 0x08
0000794c94ddfd5f  push rax
0000794c94ddfd60  push rcx
0000794c94ddfd61  push rdx
0000794c94ddfd62  push rdi
0000794c94ddfd63  push rsi
0000794c94ddfd64  push r8
0000794c94ddfd66  push r9
0000794c94ddfd68  push r10
0000794c94ddfd6a  push r11
0000794c94ddfd6c  sub rsp, 0xF0
0000794c94ddfd73  vmovaps [rsp], xmm0
0000794c94ddfd78  vmovaps [rsp+0x10], xmm1
0000794c94ddfd7e  vmovaps [rsp+0x20], xmm2
0000794c94ddfd84  vmovaps [rsp+0x30], xmm3
0000794c94ddfd8a  vmovaps [rsp+0x40], xmm4
0000794c94ddfd90  vmovaps [rsp+0x50], xmm5
0000794c94ddfd96  vmovaps [rsp+0x60], xmm6
0000794c94ddfd9c  vmovaps [rsp+0x70], xmm7
0000794c94ddfda2  vmovaps [rsp+0x80], xmm8
0000794c94ddfdab  vmovaps [rsp+0x90], xmm9
0000794c94ddfdb4  vmovaps [rsp+0xA0], xmm10
0000794c94ddfdbd  vmovaps [rsp+0xB0], xmm12
0000794c94ddfdc6  vmovaps [rsp+0xC0], xmm13
0000794c94ddfdcf  vmovaps [rsp+0xD0], xmm14
0000794c94ddfdd8  vmovaps [rsp+0xE0], xmm15
0000794c94ddfde1  sub rsp, 0x30
0000794c94ddfde5  movaps [rsp], xmm11
0000794c94ddfdea  movaps [rsp+0x10], xmm10
0000794c94ddfdf0  movaps [rsp+0x20], xmm6
0000794c94ddfdf5  lea rdi, [rsp]
0000794c94ddfdf9  mov esi, 0x00
0000794c94ddfdfe  mov rax, 0x5AB2B8B81530
0000794c94ddfe08  call rax
0000794c94ddfe0a  movaps xmm11, [rsp]
0000794c94ddfe0f  add rsp, 0x30
0000794c94ddfe13  vmovaps xmm0, [rsp]
0000794c94ddfe18  vmovaps xmm1, [rsp+0x10]
0000794c94ddfe1e  vmovaps xmm2, [rsp+0x20]
0000794c94ddfe24  vmovaps xmm3, [rsp+0x30]
0000794c94ddfe2a  vmovaps xmm4, [rsp+0x40]
0000794c94ddfe30  vmovaps xmm5, [rsp+0x50]
0000794c94ddfe36  vmovaps xmm6, [rsp+0x60]
0000794c94ddfe3c  vmovaps xmm7, [rsp+0x70]
0000794c94ddfe42  vmovaps xmm8, [rsp+0x80]
0000794c94ddfe4b  vmovaps xmm9, [rsp+0x90]
0000794c94ddfe54  vmovaps xmm10, [rsp+0xA0]
0000794c94ddfe5d  vmovaps xmm12, [rsp+0xB0]
0000794c94ddfe66  vmovaps xmm13, [rsp+0xC0]
0000794c94ddfe6f  vmovaps xmm14, [rsp+0xD0]
0000794c94ddfe78  vmovaps xmm15, [rsp+0xE0]
0000794c94ddfe81  add rsp, 0xF0
0000794c94ddfe88  pop r11
0000794c94ddfe8a  pop r10
0000794c94ddfe8c  pop r9
0000794c94ddfe8e  pop r8
0000794c94ddfe90  pop rsi
0000794c94ddfe91  pop rdi
0000794c94ddfe92  pop rdx
0000794c94ddfe93  pop rcx
0000794c94ddfe94  pop rax
0000794c94ddfe95  add rsp, 0x08
0000794c94ddfe99  jmp 0x0000794C94DDC520
0000794c94ddfe9e  sub rsp, 0x08
0000794c94ddfea2  push rax
0000794c94ddfea3  push rcx
0000794c94ddfea4  push rdx
0000794c94ddfea5  push rdi
0000794c94ddfea6  push rsi
0000794c94ddfea7  push r8
0000794c94ddfea9  push r9
0000794c94ddfeab  push r10
0000794c94ddfead  push r11
0000794c94ddfeaf  sub rsp, 0xF0
0000794c94ddfeb6  vmovaps [rsp], xmm0
0000794c94ddfebb  vmovaps [rsp+0x10], xmm1
0000794c94ddfec1  vmovaps [rsp+0x20], xmm2
0000794c94ddfec7  vmovaps [rsp+0x30], xmm3
0000794c94ddfecd  vmovaps [rsp+0x40], xmm4
0000794c94ddfed3  vmovaps [rsp+0x50], xmm5
0000794c94ddfed9  vmovaps [rsp+0x60], xmm6
0000794c94ddfedf  vmovaps [rsp+0x70], xmm7
0000794c94ddfee5  vmovaps [rsp+0x80], xmm8
0000794c94ddfeee  vmovaps [rsp+0x90], xmm9
0000794c94ddfef7  vmovaps [rsp+0xA0], xmm11
0000794c94ddff00  vmovaps [rsp+0xB0], xmm12
0000794c94ddff09  vmovaps [rsp+0xC0], xmm13
0000794c94ddff12  vmovaps [rsp+0xD0], xmm14
0000794c94ddff1b  vmovaps [rsp+0xE0], xmm15
0000794c94ddff24  sub rsp, 0x30
0000794c94ddff28  movaps [rsp], xmm10
0000794c94ddff2d  movaps [rsp+0x10], xmm14
0000794c94ddff33  movaps [rsp+0x20], xmm4
0000794c94ddff38  lea rdi, [rsp]
0000794c94ddff3c  mov esi, 0x00
0000794c94ddff41  mov rax, 0x5AB2B8B81530
0000794c94ddff4b  call rax
0000794c94ddff4d  movaps xmm10, [rsp]
0000794c94ddff52  add rsp, 0x30
0000794c94ddff56  vmovaps xmm0, [rsp]
0000794c94ddff5b  vmovaps xmm1, [rsp+0x10]
0000794c94ddff61  vmovaps xmm2, [rsp+0x20]
0000794c94ddff67  vmovaps xmm3, [rsp+0x30]
0000794c94ddff6d  vmovaps xmm4, [rsp+0x40]
0000794c94ddff73  vmovaps xmm5, [rsp+0x50]
0000794c94ddff79  vmovaps xmm6, [rsp+0x60]
0000794c94ddff7f  vmovaps xmm7, [rsp+0x70]
0000794c94ddff85  vmovaps xmm8, [rsp+0x80]
0000794c94ddff8e  vmovaps xmm9, [rsp+0x90]
0000794c94ddff97  vmovaps xmm11, [rsp+0xA0]
0000794c94ddffa0  vmovaps xmm12, [rsp+0xB0]
0000794c94ddffa9  vmovaps xmm13, [rsp+0xC0]
0000794c94ddffb2  vmovaps xmm14, [rsp+0xD0]
0000794c94ddffbb  vmovaps xmm15, [rsp+0xE0]
0000794c94ddffc4  add rsp, 0xF0
0000794c94ddffcb  pop r11
0000794c94ddffcd  pop r10
0000794c94ddffcf  pop r9
0000794c94ddffd1  pop r8
0000794c94ddffd3  pop rsi
0000794c94ddffd4  pop rdi
0000794c94ddffd5  pop rdx
0000794c94ddffd6  pop rcx
0000794c94ddffd7  pop rax
0000794c94ddffd8  add rsp, 0x08
0000794c94ddffdc  jmp 0x0000794C94DDC53B
0000794c94ddffe1  sub rsp, 0x08
0000794c94ddffe5  push rax
0000794c94ddffe6  push rcx
0000794c94ddffe7  push rdx
0000794c94ddffe8  push rdi
0000794c94ddffe9  push rsi
0000794c94ddffea  push r8
0000794c94ddffec  push r9
0000794c94ddffee  push r10
0000794c94ddfff0  push r11
0000794c94ddfff2  sub rsp, 0xF0
0000794c94ddfff9  vmovaps [rsp], xmm0
0000794c94ddfffe  vmovaps [rsp+0x10], xmm1
0000794c94de0004  vmovaps [rsp+0x20], xmm2
0000794c94de000a  vmovaps [rsp+0x30], xmm3
0000794c94de0010  vmovaps [rsp+0x40], xmm4
0000794c94de0016  vmovaps [rsp+0x50], xmm5
0000794c94de001c  vmovaps [rsp+0x60], xmm6
0000794c94de0022  vmovaps [rsp+0x70], xmm7
0000794c94de0028  vmovaps [rsp+0x80], xmm9
0000794c94de0031  vmovaps [rsp+0x90], xmm10
0000794c94de003a  vmovaps [rsp+0xA0], xmm11
0000794c94de0043  vmovaps [rsp+0xB0], xmm12
0000794c94de004c  vmovaps [rsp+0xC0], xmm13
0000794c94de0055  vmovaps [rsp+0xD0], xmm14
0000794c94de005e  vmovaps [rsp+0xE0], xmm15
0000794c94de0067  sub rsp, 0x30
0000794c94de006b  movaps [rsp], xmm8
0000794c94de0070  movaps [rsp+0x10], xmm1
0000794c94de0075  movaps [rsp+0x20], xmm14
0000794c94de007b  lea rdi, [rsp]
0000794c94de007f  mov esi, 0x00
0000794c94de0084  mov rax, 0x5AB2B8B81530
0000794c94de008e  call rax
0000794c94de0090  movaps xmm8, [rsp]
0000794c94de0095  add rsp, 0x30
0000794c94de0099  vmovaps xmm0, [rsp]
0000794c94de009e  vmovaps xmm1, [rsp+0x10]
0000794c94de00a4  vmovaps xmm2, [rsp+0x20]
0000794c94de00aa  vmovaps xmm3, [rsp+0x30]
0000794c94de00b0  vmovaps xmm4, [rsp+0x40]
0000794c94de00b6  vmovaps xmm5, [rsp+0x50]
0000794c94de00bc  vmovaps xmm6, [rsp+0x60]
0000794c94de00c2  vmovaps xmm7, [rsp+0x70]
0000794c94de00c8  vmovaps xmm9, [rsp+0x80]
0000794c94de00d1  vmovaps xmm10, [rsp+0x90]
0000794c94de00da  vmovaps xmm11, [rsp+0xA0]
0000794c94de00e3  vmovaps xmm12, [rsp+0xB0]
0000794c94de00ec  vmovaps xmm13, [rsp+0xC0]
0000794c94de00f5  vmovaps xmm14, [rsp+0xD0]
0000794c94de00fe  vmovaps xmm15, [rsp+0xE0]
0000794c94de0107  add rsp, 0xF0
0000794c94de010e  pop r11
0000794c94de0110  pop r10
0000794c94de0112  pop r9
0000794c94de0114  pop r8
0000794c94de0116  pop rsi
0000794c94de0117  pop rdi
0000794c94de0118  pop rdx
0000794c94de0119  pop rcx
0000794c94de011a  pop rax
0000794c94de011b  add rsp, 0x08
0000794c94de011f  jmp 0x0000794C94DDC561
0000794c94de0124  sub rsp, 0x08
0000794c94de0128  push rax
0000794c94de0129  push rcx
0000794c94de012a  push rdx
0000794c94de012b  push rdi
0000794c94de012c  push rsi
0000794c94de012d  push r8
0000794c94de012f  push r9
0000794c94de0131  push r10
0000794c94de0133  push r11
0000794c94de0135  sub rsp, 0xF0
0000794c94de013c  vmovaps [rsp], xmm0
0000794c94de0141  vmovaps [rsp+0x10], xmm1
0000794c94de0147  vmovaps [rsp+0x20], xmm2
0000794c94de014d  vmovaps [rsp+0x30], xmm3
0000794c94de0153  vmovaps [rsp+0x40], xmm4
0000794c94de0159  vmovaps [rsp+0x50], xmm5
0000794c94de015f  vmovaps [rsp+0x60], xmm7
0000794c94de0165  vmovaps [rsp+0x70], xmm8
0000794c94de016b  vmovaps [rsp+0x80], xmm9
0000794c94de0174  vmovaps [rsp+0x90], xmm10
0000794c94de017d  vmovaps [rsp+0xA0], xmm11
0000794c94de0186  vmovaps [rsp+0xB0], xmm12
0000794c94de018f  vmovaps [rsp+0xC0], xmm13
0000794c94de0198  vmovaps [rsp+0xD0], xmm14
0000794c94de01a1  vmovaps [rsp+0xE0], xmm15
0000794c94de01aa  sub rsp, 0x30
0000794c94de01ae  movaps [rsp], xmm6
0000794c94de01b2  movaps [rsp+0x10], xmm1
0000794c94de01b7  movaps [rsp+0x20], xmm14
0000794c94de01bd  lea rdi, [rsp]
0000794c94de01c1  mov esi, 0x00
0000794c94de01c6  mov rax, 0x5AB2B8B81530
0000794c94de01d0  call rax
0000794c94de01d2  movaps xmm6, [rsp]
0000794c94de01d6  add rsp, 0x30
0000794c94de01da  vmovaps xmm0, [rsp]
0000794c94de01df  vmovaps xmm1, [rsp+0x10]
0000794c94de01e5  vmovaps xmm2, [rsp+0x20]
0000794c94de01eb  vmovaps xmm3, [rsp+0x30]
0000794c94de01f1  vmovaps xmm4, [rsp+0x40]
0000794c94de01f7  vmovaps xmm5, [rsp+0x50]
0000794c94de01fd  vmovaps xmm7, [rsp+0x60]
0000794c94de0203  vmovaps xmm8, [rsp+0x70]
0000794c94de0209  vmovaps xmm9, [rsp+0x80]
0000794c94de0212  vmovaps xmm10, [rsp+0x90]
0000794c94de021b  vmovaps xmm11, [rsp+0xA0]
0000794c94de0224  vmovaps xmm12, [rsp+0xB0]
0000794c94de022d  vmovaps xmm13, [rsp+0xC0]
0000794c94de0236  vmovaps xmm14, [rsp+0xD0]
0000794c94de023f  vmovaps xmm15, [rsp+0xE0]
0000794c94de0248  add rsp, 0xF0
0000794c94de024f  pop r11
0000794c94de0251  pop r10
0000794c94de0253  pop r9
0000794c94de0255  pop r8
0000794c94de0257  pop rsi
0000794c94de0258  pop rdi
0000794c94de0259  pop rdx
0000794c94de025a  pop rcx
0000794c94de025b  pop rax
0000794c94de025c  add rsp, 0x08
0000794c94de0260  jmp 0x0000794C94DDC58D
0000794c94de0265  sub rsp, 0x08
0000794c94de0269  push rax
0000794c94de026a  push rcx
0000794c94de026b  push rdx
0000794c94de026c  push rdi
0000794c94de026d  push rsi
0000794c94de026e  push r8
0000794c94de0270  push r9
0000794c94de0272  push r10
0000794c94de0274  push r11
0000794c94de0276  sub rsp, 0xF0
0000794c94de027d  vmovaps [rsp], xmm0
0000794c94de0282  vmovaps [rsp+0x10], xmm1
0000794c94de0288  vmovaps [rsp+0x20], xmm2
0000794c94de028e  vmovaps [rsp+0x30], xmm3
0000794c94de0294  vmovaps [rsp+0x40], xmm4
0000794c94de029a  vmovaps [rsp+0x50], xmm5
0000794c94de02a0  vmovaps [rsp+0x60], xmm6
0000794c94de02a6  vmovaps [rsp+0x70], xmm7
0000794c94de02ac  vmovaps [rsp+0x80], xmm8
0000794c94de02b5  vmovaps [rsp+0x90], xmm9
0000794c94de02be  vmovaps [rsp+0xA0], xmm10
0000794c94de02c7  vmovaps [rsp+0xB0], xmm11
0000794c94de02d0  vmovaps [rsp+0xC0], xmm12
0000794c94de02d9  vmovaps [rsp+0xD0], xmm13
0000794c94de02e2  vmovaps [rsp+0xE0], xmm15
0000794c94de02eb  sub rsp, 0x30
0000794c94de02ef  movaps [rsp], xmm14
0000794c94de02f4  movaps [rsp+0x10], xmm12
0000794c94de02fa  movaps [rsp+0x20], xmm1
0000794c94de02ff  lea rdi, [rsp]
0000794c94de0303  mov esi, 0x00
0000794c94de0308  mov rax, 0x5AB2B8B81530
0000794c94de0312  call rax
0000794c94de0314  movaps xmm14, [rsp]
0000794c94de0319  add rsp, 0x30
0000794c94de031d  vmovaps xmm0, [rsp]
0000794c94de0322  vmovaps xmm1, [rsp+0x10]
0000794c94de0328  vmovaps xmm2, [rsp+0x20]
0000794c94de032e  vmovaps xmm3, [rsp+0x30]
0000794c94de0334  vmovaps xmm4, [rsp+0x40]
0000794c94de033a  vmovaps xmm5, [rsp+0x50]
0000794c94de0340  vmovaps xmm6, [rsp+0x60]
0000794c94de0346  vmovaps xmm7, [rsp+0x70]
0000794c94de034c  vmovaps xmm8, [rsp+0x80]
0000794c94de0355  vmovaps xmm9, [rsp+0x90]
0000794c94de035e  vmovaps xmm10, [rsp+0xA0]
0000794c94de0367  vmovaps xmm11, [rsp+0xB0]
0000794c94de0370  vmovaps xmm12, [rsp+0xC0]
0000794c94de0379  vmovaps xmm13, [rsp+0xD0]
0000794c94de0382  vmovaps xmm15, [rsp+0xE0]
0000794c94de038b  add rsp, 0xF0
0000794c94de0392  pop r11
0000794c94de0394  pop r10
0000794c94de0396  pop r9
0000794c94de0398  pop r8
0000794c94de039a  pop rsi
0000794c94de039b  pop rdi
0000794c94de039c  pop rdx
0000794c94de039d  pop rcx
0000794c94de039e  pop rax
0000794c94de039f  add rsp, 0x08
0000794c94de03a3  jmp 0x0000794C94DDC5B3
0000794c94de03a8  sub rsp, 0x08
0000794c94de03ac  push rax
0000794c94de03ad  push rcx
0000794c94de03ae  push rdx
0000794c94de03af  push rdi
0000794c94de03b0  push rsi
0000794c94de03b1  push r8
0000794c94de03b3  push r9
0000794c94de03b5  push r10
0000794c94de03b7  push r11
0000794c94de03b9  sub rsp, 0xF0
0000794c94de03c0  vmovaps [rsp], xmm0
0000794c94de03c5  vmovaps [rsp+0x10], xmm2
0000794c94de03cb  vmovaps [rsp+0x20], xmm3
0000794c94de03d1  vmovaps [rsp+0x30], xmm4
0000794c94de03d7  vmovaps [rsp+0x40], xmm5
0000794c94de03dd  vmovaps [rsp+0x50], xmm6
0000794c94de03e3  vmovaps [rsp+0x60], xmm7
0000794c94de03e9  vmovaps [rsp+0x70], xmm8
0000794c94de03ef  vmovaps [rsp+0x80], xmm9
0000794c94de03f8  vmovaps [rsp+0x90], xmm10
0000794c94de0401  vmovaps [rsp+0xA0], xmm11
0000794c94de040a  vmovaps [rsp+0xB0], xmm12
0000794c94de0413  vmovaps [rsp+0xC0], xmm13
0000794c94de041c  vmovaps [rsp+0xD0], xmm14
0000794c94de0425  vmovaps [rsp+0xE0], xmm15
0000794c94de042e  sub rsp, 0x30
0000794c94de0432  movaps [rsp], xmm1
0000794c94de0436  movaps [rsp+0x10], xmm13
0000794c94de043c  movaps [rsp+0x20], xmm9
0000794c94de0442  lea rdi, [rsp]
0000794c94de0446  mov esi, 0x00
0000794c94de044b  mov rax, 0x5AB2B8B81530
0000794c94de0455  call rax
0000794c94de0457  movaps xmm1, [rsp]
0000794c94de045b  add rsp, 0x30
0000794c94de045f  vmovaps xmm0, [rsp]
0000794c94de0464  vmovaps xmm2, [rsp+0x10]
0000794c94de046a  vmovaps xmm3, [rsp+0x20]
0000794c94de0470  vmovaps xmm4, [rsp+0x30]
0000794c94de0476  vmovaps xmm5, [rsp+0x40]
0000794c94de047c  vmovaps xmm6, [rsp+0x50]
0000794c94de0482  vmovaps xmm7, [rsp+0x60]
0000794c94de0488  vmovaps xmm8, [rsp+0x70]
0000794c94de048e  vmovaps xmm9, [rsp+0x80]
0000794c94de0497  vmovaps xmm10, [rsp+0x90]
0000794c94de04a0  vmovaps xmm11, [rsp+0xA0]
0000794c94de04a9  vmovaps xmm12, [rsp+0xB0]
0000794c94de04b2  vmovaps xmm13, [rsp+0xC0]
0000794c94de04bb  vmovaps xmm14, [rsp+0xD0]
0000794c94de04c4  vmovaps xmm15, [rsp+0xE0]
0000794c94de04cd  add rsp, 0xF0
0000794c94de04d4  pop r11
0000794c94de04d6  pop r10
0000794c94de04d8  pop r9
0000794c94de04da  pop r8
0000794c94de04dc  pop rsi
0000794c94de04dd  pop rdi
0000794c94de04de  pop rdx
0000794c94de04df  pop rcx
0000794c94de04e0  pop rax
0000794c94de04e1  add rsp, 0x08
0000794c94de04e5  jmp 0x0000794C94DDC5CD
0000794c94de04ea  sub rsp, 0x08
0000794c94de04ee  push rax
0000794c94de04ef  push rcx
0000794c94de04f0  push rdx
0000794c94de04f1  push rdi
0000794c94de04f2  push rsi
0000794c94de04f3  push r8
0000794c94de04f5  push r9
0000794c94de04f7  push r10
0000794c94de04f9  push r11
0000794c94de04fb  sub rsp, 0xF0
0000794c94de0502  vmovaps [rsp], xmm0
0000794c94de0507  vmovaps [rsp+0x10], xmm1
0000794c94de050d  vmovaps [rsp+0x20], xmm2
0000794c94de0513  vmovaps [rsp+0x30], xmm3
0000794c94de0519  vmovaps [rsp+0x40], xmm4
0000794c94de051f  vmovaps [rsp+0x50], xmm5
0000794c94de0525  vmovaps [rsp+0x60], xmm6
0000794c94de052b  vmovaps [rsp+0x70], xmm7
0000794c94de0531  vmovaps [rsp+0x80], xmm8
0000794c94de053a  vmovaps [rsp+0x90], xmm9
0000794c94de0543  vmovaps [rsp+0xA0], xmm10
0000794c94de054c  vmovaps [rsp+0xB0], xmm11
0000794c94de0555  vmovaps [rsp+0xC0], xmm13
0000794c94de055e  vmovaps [rsp+0xD0], xmm14
0000794c94de0567  vmovaps [rsp+0xE0], xmm15
0000794c94de0570  sub rsp, 0x30
0000794c94de0574  movaps [rsp], xmm12
0000794c94de0579  movaps [rsp+0x10], xmm7
0000794c94de057e  movaps [rsp+0x20], xmm13
0000794c94de0584  lea rdi, [rsp]
0000794c94de0588  mov esi, 0x00
0000794c94de058d  mov rax, 0x5AB2B8B81530
0000794c94de0597  call rax
0000794c94de0599  movaps xmm12, [rsp]
0000794c94de059e  add rsp, 0x30
0000794c94de05a2  vmovaps xmm0, [rsp]
0000794c94de05a7  vmovaps xmm1, [rsp+0x10]
0000794c94de05ad  vmovaps xmm2, [rsp+0x20]
0000794c94de05b3  vmovaps xmm3, [rsp+0x30]
0000794c94de05b9  vmovaps xmm4, [rsp+0x40]
0000794c94de05bf  vmovaps xmm5, [rsp+0x50]
0000794c94de05c5  vmovaps xmm6, [rsp+0x60]
0000794c94de05cb  vmovaps xmm7, [rsp+0x70]
0000794c94de05d1  vmovaps xmm8, [rsp+0x80]
0000794c94de05da  vmovaps xmm9, [rsp+0x90]
0000794c94de05e3  vmovaps xmm10, [rsp+0xA0]
0000794c94de05ec  vmovaps xmm11, [rsp+0xB0]
0000794c94de05f5  vmovaps xmm13, [rsp+0xC0]
0000794c94de05fe  vmovaps xmm14, [rsp+0xD0]
0000794c94de0607  vmovaps xmm15, [rsp+0xE0]
0000794c94de0610  add rsp, 0xF0
0000794c94de0617  pop r11
0000794c94de0619  pop r10
0000794c94de061b  pop r9
0000794c94de061d  pop r8
0000794c94de061f  pop rsi
0000794c94de0620  pop rdi
0000794c94de0621  pop rdx
0000794c94de0622  pop rcx
0000794c94de0623  pop rax
0000794c94de0624  add rsp, 0x08
0000794c94de0628  jmp 0x0000794C94DDC5F4
0000794c94de062d  sub rsp, 0x08
0000794c94de0631  push rax
0000794c94de0632  push rcx
0000794c94de0633  push rdx
0000794c94de0634  push rdi
0000794c94de0635  push rsi
0000794c94de0636  push r8
0000794c94de0638  push r9
0000794c94de063a  push r10
0000794c94de063c  push r11
0000794c94de063e  sub rsp, 0xF0
0000794c94de0645  vmovaps [rsp], xmm0
0000794c94de064a  vmovaps [rsp+0x10], xmm1
0000794c94de0650  vmovaps [rsp+0x20], xmm2
0000794c94de0656  vmovaps [rsp+0x30], xmm3
0000794c94de065c  vmovaps [rsp+0x40], xmm4
0000794c94de0662  vmovaps [rsp+0x50], xmm5
0000794c94de0668  vmovaps [rsp+0x60], xmm6
0000794c94de066e  vmovaps [rsp+0x70], xmm7
0000794c94de0674  vmovaps [rsp+0x80], xmm8
0000794c94de067d  vmovaps [rsp+0x90], xmm9
0000794c94de0686  vmovaps [rsp+0xA0], xmm10
0000794c94de068f  vmovaps [rsp+0xB0], xmm11
0000794c94de0698  vmovaps [rsp+0xC0], xmm12
0000794c94de06a1  vmovaps [rsp+0xD0], xmm14
0000794c94de06aa  vmovaps [rsp+0xE0], xmm15
0000794c94de06b3  sub rsp, 0x30
0000794c94de06b7  movaps [rsp], xmm13
0000794c94de06bc  movaps [rsp+0x10], xmm15
0000794c94de06c2  movaps [rsp+0x20], xmm8
0000794c94de06c8  lea rdi, [rsp]
0000794c94de06cc  mov esi, 0x00
0000794c94de06d1  mov rax, 0x5AB2B8B81530
0000794c94de06db  call rax
0000794c94de06dd  movaps xmm13, [rsp]
0000794c94de06e2  add rsp, 0x30
0000794c94de06e6  vmovaps xmm0, [rsp]
0000794c94de06eb  vmovaps xmm1, [rsp+0x10]
0000794c94de06f1  vmovaps xmm2, [rsp+0x20]
0000794c94de06f7  vmovaps xmm3, [rsp+0x30]
0000794c94de06fd  vmovaps xmm4, [rsp+0x40]
0000794c94de0703  vmovaps xmm5, [rsp+0x50]
0000794c94de0709  vmovaps xmm6, [rsp+0x60]
0000794c94de070f  vmovaps xmm7, [rsp+0x70]
0000794c94de0715  vmovaps xmm8, [rsp+0x80]
0000794c94de071e  vmovaps xmm9, [rsp+0x90]
0000794c94de0727  vmovaps xmm10, [rsp+0xA0]
0000794c94de0730  vmovaps xmm11, [rsp+0xB0]
0000794c94de0739  vmovaps xmm12, [rsp+0xC0]
0000794c94de0742  vmovaps xmm14, [rsp+0xD0]
0000794c94de074b  vmovaps xmm15, [rsp+0xE0]
0000794c94de0754  add rsp, 0xF0
0000794c94de075b  pop r11
0000794c94de075d  pop r10
0000794c94de075f  pop r9
0000794c94de0761  pop r8
0000794c94de0763  pop rsi
0000794c94de0764  pop rdi
0000794c94de0765  pop rdx
0000794c94de0766  pop rcx
0000794c94de0767  pop rax
0000794c94de0768  add rsp, 0x08
0000794c94de076c  jmp 0x0000794C94DDC60F
0000794c94de0771  sub rsp, 0x08
0000794c94de0775  push rax
0000794c94de0776  push rcx
0000794c94de0777  push rdx
0000794c94de0778  push rdi
0000794c94de0779  push rsi
0000794c94de077a  push r8
0000794c94de077c  push r9
0000794c94de077e  push r10
0000794c94de0780  push r11
0000794c94de0782  sub rsp, 0xF0
0000794c94de0789  vmovaps [rsp], xmm0
0000794c94de078e  vmovaps [rsp+0x10], xmm1
0000794c94de0794  vmovaps [rsp+0x20], xmm2
0000794c94de079a  vmovaps [rsp+0x30], xmm3
0000794c94de07a0  vmovaps [rsp+0x40], xmm4
0000794c94de07a6  vmovaps [rsp+0x50], xmm5
0000794c94de07ac  vmovaps [rsp+0x60], xmm6
0000794c94de07b2  vmovaps [rsp+0x70], xmm7
0000794c94de07b8  vmovaps [rsp+0x80], xmm9
0000794c94de07c1  vmovaps [rsp+0x90], xmm10
0000794c94de07ca  vmovaps [rsp+0xA0], xmm11
0000794c94de07d3  vmovaps [rsp+0xB0], xmm12
0000794c94de07dc  vmovaps [rsp+0xC0], xmm13
0000794c94de07e5  vmovaps [rsp+0xD0], xmm14
0000794c94de07ee  vmovaps [rsp+0xE0], xmm15
0000794c94de07f7  sub rsp, 0x30
0000794c94de07fb  movaps [rsp], xmm8
0000794c94de0800  movaps [rsp+0x10], xmm15
0000794c94de0806  movaps [rsp+0x20], xmm9
0000794c94de080c  lea rdi, [rsp]
0000794c94de0810  mov esi, 0x00
0000794c94de0815  mov rax, 0x5AB2B8B81530
0000794c94de081f  call rax
0000794c94de0821  movaps xmm8, [rsp]
0000794c94de0826  add rsp, 0x30
0000794c94de082a  vmovaps xmm0, [rsp]
0000794c94de082f  vmovaps xmm1, [rsp+0x10]
0000794c94de0835  vmovaps xmm2, [rsp+0x20]
0000794c94de083b  vmovaps xmm3, [rsp+0x30]
0000794c94de0841  vmovaps xmm4, [rsp+0x40]
0000794c94de0847  vmovaps xmm5, [rsp+0x50]
0000794c94de084d  vmovaps xmm6, [rsp+0x60]
0000794c94de0853  vmovaps xmm7, [rsp+0x70]
0000794c94de0859  vmovaps xmm9, [rsp+0x80]
0000794c94de0862  vmovaps xmm10, [rsp+0x90]
0000794c94de086b  vmovaps xmm11, [rsp+0xA0]
0000794c94de0874  vmovaps xmm12, [rsp+0xB0]
0000794c94de087d  vmovaps xmm13, [rsp+0xC0]
0000794c94de0886  vmovaps xmm14, [rsp+0xD0]
0000794c94de088f  vmovaps xmm15, [rsp+0xE0]
0000794c94de0898  add rsp, 0xF0
0000794c94de089f  pop r11
0000794c94de08a1  pop r10
0000794c94de08a3  pop r9
0000794c94de08a5  pop r8
0000794c94de08a7  pop rsi
0000794c94de08a8  pop rdi
0000794c94de08a9  pop rdx
0000794c94de08aa  pop rcx
0000794c94de08ab  pop rax
0000794c94de08ac  add rsp, 0x08
0000794c94de08b0  jmp 0x0000794C94DDC63D
0000794c94de08b5  sub rsp, 0x08
0000794c94de08b9  push rax
0000794c94de08ba  push rcx
0000794c94de08bb  push rdx
0000794c94de08bc  push rdi
0000794c94de08bd  push rsi
0000794c94de08be  push r8
0000794c94de08c0  push r9
0000794c94de08c2  push r10
0000794c94de08c4  push r11
0000794c94de08c6  sub rsp, 0xF0
0000794c94de08cd  vmovaps [rsp], xmm0
0000794c94de08d2  vmovaps [rsp+0x10], xmm1
0000794c94de08d8  vmovaps [rsp+0x20], xmm2
0000794c94de08de  vmovaps [rsp+0x30], xmm3
0000794c94de08e4  vmovaps [rsp+0x40], xmm4
0000794c94de08ea  vmovaps [rsp+0x50], xmm5
0000794c94de08f0  vmovaps [rsp+0x60], xmm6
0000794c94de08f6  vmovaps [rsp+0x70], xmm7
0000794c94de08fc  vmovaps [rsp+0x80], xmm8
0000794c94de0905  vmovaps [rsp+0x90], xmm9
0000794c94de090e  vmovaps [rsp+0xA0], xmm10
0000794c94de0917  vmovaps [rsp+0xB0], xmm11
0000794c94de0920  vmovaps [rsp+0xC0], xmm12
0000794c94de0929  vmovaps [rsp+0xD0], xmm13
0000794c94de0932  vmovaps [rsp+0xE0], xmm14
0000794c94de093b  sub rsp, 0x30
0000794c94de093f  movaps [rsp], xmm15
0000794c94de0944  movaps [rsp+0x10], xmm11
0000794c94de094a  movaps [rsp+0x20], xmm6
0000794c94de094f  lea rdi, [rsp]
0000794c94de0953  mov esi, 0x00
0000794c94de0958  mov rax, 0x5AB2B8B81530
0000794c94de0962  call rax
0000794c94de0964  movaps xmm15, [rsp]
0000794c94de0969  add rsp, 0x30
0000794c94de096d  vmovaps xmm0, [rsp]
0000794c94de0972  vmovaps xmm1, [rsp+0x10]
0000794c94de0978  vmovaps xmm2, [rsp+0x20]
0000794c94de097e  vmovaps xmm3, [rsp+0x30]
0000794c94de0984  vmovaps xmm4, [rsp+0x40]
0000794c94de098a  vmovaps xmm5, [rsp+0x50]
0000794c94de0990  vmovaps xmm6, [rsp+0x60]
0000794c94de0996  vmovaps xmm7, [rsp+0x70]
0000794c94de099c  vmovaps xmm8, [rsp+0x80]
0000794c94de09a5  vmovaps xmm9, [rsp+0x90]
0000794c94de09ae  vmovaps xmm10, [rsp+0xA0]
0000794c94de09b7  vmovaps xmm11, [rsp+0xB0]
0000794c94de09c0  vmovaps xmm12, [rsp+0xC0]
0000794c94de09c9  vmovaps xmm13, [rsp+0xD0]
0000794c94de09d2  vmovaps xmm14, [rsp+0xE0]
0000794c94de09db  add rsp, 0xF0
0000794c94de09e2  pop r11
0000794c94de09e4  pop r10
0000794c94de09e6  pop r9
0000794c94de09e8  pop r8
0000794c94de09ea  pop rsi
0000794c94de09eb  pop rdi
0000794c94de09ec  pop rdx
0000794c94de09ed  pop rcx
0000794c94de09ee  pop rax
0000794c94de09ef  add rsp, 0x08
0000794c94de09f3  jmp 0x0000794C94DDC658
0000794c94de09f8  sub rsp, 0x08
0000794c94de09fc  push rax
0000794c94de09fd  push rcx
0000794c94de09fe  push rdx
0000794c94de09ff  push rdi
0000794c94de0a00  push rsi
0000794c94de0a01  push r8
0000794c94de0a03  push r9
0000794c94de0a05  push r10
0000794c94de0a07  push r11
0000794c94de0a09  sub rsp, 0xF0
0000794c94de0a10  vmovaps [rsp], xmm0
0000794c94de0a15  vmovaps [rsp+0x10], xmm1
0000794c94de0a1b  vmovaps [rsp+0x20], xmm2
0000794c94de0a21  vmovaps [rsp+0x30], xmm3
0000794c94de0a27  vmovaps [rsp+0x40], xmm4
0000794c94de0a2d  vmovaps [rsp+0x50], xmm5
0000794c94de0a33  vmovaps [rsp+0x60], xmm6
0000794c94de0a39  vmovaps [rsp+0x70], xmm8
0000794c94de0a3f  vmovaps [rsp+0x80], xmm9
0000794c94de0a48  vmovaps [rsp+0x90], xmm10
0000794c94de0a51  vmovaps [rsp+0xA0], xmm11
0000794c94de0a5a  vmovaps [rsp+0xB0], xmm12
0000794c94de0a63  vmovaps [rsp+0xC0], xmm13
0000794c94de0a6c  vmovaps [rsp+0xD0], xmm14
0000794c94de0a75  vmovaps [rsp+0xE0], xmm15
0000794c94de0a7e  sub rsp, 0x30
0000794c94de0a82  movaps [rsp], xmm7
0000794c94de0a86  movaps [rsp+0x10], xmm11
0000794c94de0a8c  movaps [rsp+0x20], xmm9
0000794c94de0a92  lea rdi, [rsp]
0000794c94de0a96  mov esi, 0x00
0000794c94de0a9b  mov rax, 0x5AB2B8B81530
0000794c94de0aa5  call rax
0000794c94de0aa7  movaps xmm7, [rsp]
0000794c94de0aab  add rsp, 0x30
0000794c94de0aaf  vmovaps xmm0, [rsp]
0000794c94de0ab4  vmovaps xmm1, [rsp+0x10]
0000794c94de0aba  vmovaps xmm2, [rsp+0x20]
0000794c94de0ac0  vmovaps xmm3, [rsp+0x30]
0000794c94de0ac6  vmovaps xmm4, [rsp+0x40]
0000794c94de0acc  vmovaps xmm5, [rsp+0x50]
0000794c94de0ad2  vmovaps xmm6, [rsp+0x60]
0000794c94de0ad8  vmovaps xmm8, [rsp+0x70]
0000794c94de0ade  vmovaps xmm9, [rsp+0x80]
0000794c94de0ae7  vmovaps xmm10, [rsp+0x90]
0000794c94de0af0  vmovaps xmm11, [rsp+0xA0]
0000794c94de0af9  vmovaps xmm12, [rsp+0xB0]
0000794c94de0b02  vmovaps xmm13, [rsp+0xC0]
0000794c94de0b0b  vmovaps xmm14, [rsp+0xD0]
0000794c94de0b14  vmovaps xmm15, [rsp+0xE0]
0000794c94de0b1d  add rsp, 0xF0
0000794c94de0b24  pop r11
0000794c94de0b26  pop r10
0000794c94de0b28  pop r9
0000794c94de0b2a  pop r8
0000794c94de0b2c  pop rsi
0000794c94de0b2d  pop rdi
0000794c94de0b2e  pop rdx
0000794c94de0b2f  pop rcx
0000794c94de0b30  pop rax
0000794c94de0b31  add rsp, 0x08
0000794c94de0b35  jmp 0x0000794C94DDC685
0000794c94de0b3a  sub rsp, 0x08
0000794c94de0b3e  push rax
0000794c94de0b3f  push rcx
0000794c94de0b40  push rdx
0000794c94de0b41  push rdi
0000794c94de0b42  push rsi
0000794c94de0b43  push r8
0000794c94de0b45  push r9
0000794c94de0b47  push r10
0000794c94de0b49  push r11
0000794c94de0b4b  sub rsp, 0xF0
0000794c94de0b52  vmovaps [rsp], xmm0
0000794c94de0b57  vmovaps [rsp+0x10], xmm1
0000794c94de0b5d  vmovaps [rsp+0x20], xmm2
0000794c94de0b63  vmovaps [rsp+0x30], xmm3
0000794c94de0b69  vmovaps [rsp+0x40], xmm4
0000794c94de0b6f  vmovaps [rsp+0x50], xmm5
0000794c94de0b75  vmovaps [rsp+0x60], xmm6
0000794c94de0b7b  vmovaps [rsp+0x70], xmm7
0000794c94de0b81  vmovaps [rsp+0x80], xmm8
0000794c94de0b8a  vmovaps [rsp+0x90], xmm9
0000794c94de0b93  vmovaps [rsp+0xA0], xmm10
0000794c94de0b9c  vmovaps [rsp+0xB0], xmm12
0000794c94de0ba5  vmovaps [rsp+0xC0], xmm13
0000794c94de0bae  vmovaps [rsp+0xD0], xmm14
0000794c94de0bb7  vmovaps [rsp+0xE0], xmm15
0000794c94de0bc0  sub rsp, 0x30
0000794c94de0bc4  movaps [rsp], xmm11
0000794c94de0bc9  movaps [rsp+0x10], xmm10
0000794c94de0bcf  movaps [rsp+0x20], xmm14
0000794c94de0bd5  lea rdi, [rsp]
0000794c94de0bd9  mov esi, 0x00
0000794c94de0bde  mov rax, 0x5AB2B8B81530
0000794c94de0be8  call rax
0000794c94de0bea  movaps xmm11, [rsp]
0000794c94de0bef  add rsp, 0x30
0000794c94de0bf3  vmovaps xmm0, [rsp]
0000794c94de0bf8  vmovaps xmm1, [rsp+0x10]
0000794c94de0bfe  vmovaps xmm2, [rsp+0x20]
0000794c94de0c04  vmovaps xmm3, [rsp+0x30]
0000794c94de0c0a  vmovaps xmm4, [rsp+0x40]
0000794c94de0c10  vmovaps xmm5, [rsp+0x50]
0000794c94de0c16  vmovaps xmm6, [rsp+0x60]
0000794c94de0c1c  vmovaps xmm7, [rsp+0x70]
0000794c94de0c22  vmovaps xmm8, [rsp+0x80]
0000794c94de0c2b  vmovaps xmm9, [rsp+0x90]
0000794c94de0c34  vmovaps xmm10, [rsp+0xA0]
0000794c94de0c3d  vmovaps xmm12, [rsp+0xB0]
0000794c94de0c46  vmovaps xmm13, [rsp+0xC0]
0000794c94de0c4f  vmovaps xmm14, [rsp+0xD0]
0000794c94de0c58  vmovaps xmm15, [rsp+0xE0]
0000794c94de0c61  add rsp, 0xF0
0000794c94de0c68  pop r11
0000794c94de0c6a  pop r10
0000794c94de0c6c  pop r9
0000794c94de0c6e  pop r8
0000794c94de0c70  pop rsi
0000794c94de0c71  pop rdi
0000794c94de0c72  pop rdx
0000794c94de0c73  pop rcx
0000794c94de0c74  pop rax
0000794c94de0c75  add rsp, 0x08
0000794c94de0c79  jmp 0x0000794C94DDC6A0
0000794c94de0c7e  call 0x0000794C94CC33A0
0000794c94de0c83  jmp 0x0000794C94DDC6AA
0000794c94de0c88  sub rsp, 0x08
0000794c94de0c8c  push rax
0000794c94de0c8d  push rcx
0000794c94de0c8e  push rdx
0000794c94de0c8f  push rdi
0000794c94de0c90  push rsi
0000794c94de0c91  push r8
0000794c94de0c93  push r9
0000794c94de0c95  push r10
0000794c94de0c97  push r11
0000794c94de0c99  sub rsp, 0xF0
0000794c94de0ca0  vmovaps [rsp], xmm0
0000794c94de0ca5  vmovaps [rsp+0x10], xmm1
0000794c94de0cab  vmovaps [rsp+0x20], xmm2
0000794c94de0cb1  vmovaps [rsp+0x30], xmm3
0000794c94de0cb7  vmovaps [rsp+0x40], xmm4
0000794c94de0cbd  vmovaps [rsp+0x50], xmm5
0000794c94de0cc3  vmovaps [rsp+0x60], xmm6
0000794c94de0cc9  vmovaps [rsp+0x70], xmm7
0000794c94de0ccf  vmovaps [rsp+0x80], xmm8
0000794c94de0cd8  vmovaps [rsp+0x90], xmm9
0000794c94de0ce1  vmovaps [rsp+0xA0], xmm11
0000794c94de0cea  vmovaps [rsp+0xB0], xmm12
0000794c94de0cf3  vmovaps [rsp+0xC0], xmm13
0000794c94de0cfc  vmovaps [rsp+0xD0], xmm14
0000794c94de0d05  vmovaps [rsp+0xE0], xmm15
0000794c94de0d0e  sub rsp, 0x30
0000794c94de0d12  movaps [rsp], xmm10
0000794c94de0d17  movaps [rsp+0x10], xmm1
0000794c94de0d1c  movaps [rsp+0x20], xmm12
0000794c94de0d22  lea rdi, [rsp]
0000794c94de0d26  mov esi, 0x00
0000794c94de0d2b  mov rax, 0x5AB2B8B81530
0000794c94de0d35  call rax
0000794c94de0d37  movaps xmm10, [rsp]
0000794c94de0d3c  add rsp, 0x30
0000794c94de0d40  vmovaps xmm0, [rsp]
0000794c94de0d45  vmovaps xmm1, [rsp+0x10]
0000794c94de0d4b  vmovaps xmm2, [rsp+0x20]
0000794c94de0d51  vmovaps xmm3, [rsp+0x30]
0000794c94de0d57  vmovaps xmm4, [rsp+0x40]
0000794c94de0d5d  vmovaps xmm5, [rsp+0x50]
0000794c94de0d63  vmovaps xmm6, [rsp+0x60]
0000794c94de0d69  vmovaps xmm7, [rsp+0x70]
0000794c94de0d6f  vmovaps xmm8, [rsp+0x80]
0000794c94de0d78  vmovaps xmm9, [rsp+0x90]
0000794c94de0d81  vmovaps xmm11, [rsp+0xA0]
0000794c94de0d8a  vmovaps xmm12, [rsp+0xB0]
0000794c94de0d93  vmovaps xmm13, [rsp+0xC0]
0000794c94de0d9c  vmovaps xmm14, [rsp+0xD0]
0000794c94de0da5  vmovaps xmm15, [rsp+0xE0]
0000794c94de0dae  add rsp, 0xF0
0000794c94de0db5  pop r11
0000794c94de0db7  pop r10
0000794c94de0db9  pop r9
0000794c94de0dbb  pop r8
0000794c94de0dbd  pop rsi
0000794c94de0dbe  pop rdi
0000794c94de0dbf  pop rdx
0000794c94de0dc0  pop rcx
0000794c94de0dc1  pop rax
0000794c94de0dc2  add rsp, 0x08
0000794c94de0dc6  jmp 0x0000794C94DDC6CD
0000794c94de0dcb  sub rsp, 0x08
0000794c94de0dcf  push rax
0000794c94de0dd0  push rcx
0000794c94de0dd1  push rdx
0000794c94de0dd2  push rdi
0000794c94de0dd3  push rsi
0000794c94de0dd4  push r8
0000794c94de0dd6  push r9
0000794c94de0dd8  push r10
0000794c94de0dda  push r11
0000794c94de0ddc  sub rsp, 0xF0
0000794c94de0de3  vmovaps [rsp], xmm0
0000794c94de0de8  vmovaps [rsp+0x10], xmm1
0000794c94de0dee  vmovaps [rsp+0x20], xmm2
0000794c94de0df4  vmovaps [rsp+0x30], xmm3
0000794c94de0dfa  vmovaps [rsp+0x40], xmm4
0000794c94de0e00  vmovaps [rsp+0x50], xmm5
0000794c94de0e06  vmovaps [rsp+0x60], xmm6
0000794c94de0e0c  vmovaps [rsp+0x70], xmm7
0000794c94de0e12  vmovaps [rsp+0x80], xmm8
0000794c94de0e1b  vmovaps [rsp+0x90], xmm9
0000794c94de0e24  vmovaps [rsp+0xA0], xmm10
0000794c94de0e2d  vmovaps [rsp+0xB0], xmm11
0000794c94de0e36  vmovaps [rsp+0xC0], xmm13
0000794c94de0e3f  vmovaps [rsp+0xD0], xmm14
0000794c94de0e48  vmovaps [rsp+0xE0], xmm15
0000794c94de0e51  sub rsp, 0x30
0000794c94de0e55  movaps [rsp], xmm12
0000794c94de0e5a  movaps [rsp+0x10], xmm14
0000794c94de0e60  movaps [rsp+0x20], xmm1
0000794c94de0e65  lea rdi, [rsp]
0000794c94de0e69  mov esi, 0x00
0000794c94de0e6e  mov rax, 0x5AB2B8B81530
0000794c94de0e78  call rax
0000794c94de0e7a  movaps xmm12, [rsp]
0000794c94de0e7f  add rsp, 0x30
0000794c94de0e83  vmovaps xmm0, [rsp]
0000794c94de0e88  vmovaps xmm1, [rsp+0x10]
0000794c94de0e8e  vmovaps xmm2, [rsp+0x20]
0000794c94de0e94  vmovaps xmm3, [rsp+0x30]
0000794c94de0e9a  vmovaps xmm4, [rsp+0x40]
0000794c94de0ea0  vmovaps xmm5, [rsp+0x50]
0000794c94de0ea6  vmovaps xmm6, [rsp+0x60]
0000794c94de0eac  vmovaps xmm7, [rsp+0x70]
0000794c94de0eb2  vmovaps xmm8, [rsp+0x80]
0000794c94de0ebb  vmovaps xmm9, [rsp+0x90]
0000794c94de0ec4  vmovaps xmm10, [rsp+0xA0]
0000794c94de0ecd  vmovaps xmm11, [rsp+0xB0]
0000794c94de0ed6  vmovaps xmm13, [rsp+0xC0]
0000794c94de0edf  vmovaps xmm14, [rsp+0xD0]
0000794c94de0ee8  vmovaps xmm15, [rsp+0xE0]
0000794c94de0ef1  add rsp, 0xF0
0000794c94de0ef8  pop r11
0000794c94de0efa  pop r10
0000794c94de0efc  pop r9
0000794c94de0efe  pop r8
0000794c94de0f00  pop rsi
0000794c94de0f01  pop rdi
0000794c94de0f02  pop rdx
0000794c94de0f03  pop rcx
0000794c94de0f04  pop rax
0000794c94de0f05  add rsp, 0x08
0000794c94de0f09  jmp 0x0000794C94DDC6FC
0000794c94de0f0e  sub rsp, 0x08
0000794c94de0f12  push rax
0000794c94de0f13  push rcx
0000794c94de0f14  push rdx
0000794c94de0f15  push rdi
0000794c94de0f16  push rsi
0000794c94de0f17  push r8
0000794c94de0f19  push r9
0000794c94de0f1b  push r10
0000794c94de0f1d  push r11
0000794c94de0f1f  sub rsp, 0xF0
0000794c94de0f26  vmovaps [rsp], xmm0
0000794c94de0f2b  vmovaps [rsp+0x10], xmm1
0000794c94de0f31  vmovaps [rsp+0x20], xmm2
0000794c94de0f37  vmovaps [rsp+0x30], xmm3
0000794c94de0f3d  vmovaps [rsp+0x40], xmm4
0000794c94de0f43  vmovaps [rsp+0x50], xmm5
0000794c94de0f49  vmovaps [rsp+0x60], xmm6
0000794c94de0f4f  vmovaps [rsp+0x70], xmm7
0000794c94de0f55  vmovaps [rsp+0x80], xmm8
0000794c94de0f5e  vmovaps [rsp+0x90], xmm9
0000794c94de0f67  vmovaps [rsp+0xA0], xmm10
0000794c94de0f70  vmovaps [rsp+0xB0], xmm11
0000794c94de0f79  vmovaps [rsp+0xC0], xmm12
0000794c94de0f82  vmovaps [rsp+0xD0], xmm13
0000794c94de0f8b  vmovaps [rsp+0xE0], xmm15
0000794c94de0f94  sub rsp, 0x30
0000794c94de0f98  movaps [rsp], xmm14
0000794c94de0f9d  movaps [rsp+0x10], xmm9
0000794c94de0fa3  movaps [rsp+0x20], xmm1
0000794c94de0fa8  lea rdi, [rsp]
0000794c94de0fac  mov esi, 0x00
0000794c94de0fb1  mov rax, 0x5AB2B8B81530
0000794c94de0fbb  call rax
0000794c94de0fbd  movaps xmm14, [rsp]
0000794c94de0fc2  add rsp, 0x30
0000794c94de0fc6  vmovaps xmm0, [rsp]
0000794c94de0fcb  vmovaps xmm1, [rsp+0x10]
0000794c94de0fd1  vmovaps xmm2, [rsp+0x20]
0000794c94de0fd7  vmovaps xmm3, [rsp+0x30]
0000794c94de0fdd  vmovaps xmm4, [rsp+0x40]
0000794c94de0fe3  vmovaps xmm5, [rsp+0x50]
0000794c94de0fe9  vmovaps xmm6, [rsp+0x60]
0000794c94de0fef  vmovaps xmm7, [rsp+0x70]
0000794c94de0ff5  vmovaps xmm8, [rsp+0x80]
0000794c94de0ffe  vmovaps xmm9, [rsp+0x90]
0000794c94de1007  vmovaps xmm10, [rsp+0xA0]
0000794c94de1010  vmovaps xmm11, [rsp+0xB0]
0000794c94de1019  vmovaps xmm12, [rsp+0xC0]
0000794c94de1022  vmovaps xmm13, [rsp+0xD0]
0000794c94de102b  vmovaps xmm15, [rsp+0xE0]
0000794c94de1034  add rsp, 0xF0
0000794c94de103b  pop r11
0000794c94de103d  pop r10
0000794c94de103f  pop r9
0000794c94de1041  pop r8
0000794c94de1043  pop rsi
0000794c94de1044  pop rdi
0000794c94de1045  pop rdx
0000794c94de1046  pop rcx
0000794c94de1047  pop rax
0000794c94de1048  add rsp, 0x08
0000794c94de104c  jmp 0x0000794C94DDC72B
0000794c94de1051  sub rsp, 0x08
0000794c94de1055  push rax
0000794c94de1056  push rcx
0000794c94de1057  push rdx
0000794c94de1058  push rdi
0000794c94de1059  push rsi
0000794c94de105a  push r8
0000794c94de105c  push r9
0000794c94de105e  push r10
0000794c94de1060  push r11
0000794c94de1062  sub rsp, 0xF0
0000794c94de1069  vmovaps [rsp], xmm0
0000794c94de106e  vmovaps [rsp+0x10], xmm2
0000794c94de1074  vmovaps [rsp+0x20], xmm3
0000794c94de107a  vmovaps [rsp+0x30], xmm4
0000794c94de1080  vmovaps [rsp+0x40], xmm5
0000794c94de1086  vmovaps [rsp+0x50], xmm6
0000794c94de108c  vmovaps [rsp+0x60], xmm7
0000794c94de1092  vmovaps [rsp+0x70], xmm8
0000794c94de1098  vmovaps [rsp+0x80], xmm9
0000794c94de10a1  vmovaps [rsp+0x90], xmm10
0000794c94de10aa  vmovaps [rsp+0xA0], xmm11
0000794c94de10b3  vmovaps [rsp+0xB0], xmm12
0000794c94de10bc  vmovaps [rsp+0xC0], xmm13
0000794c94de10c5  vmovaps [rsp+0xD0], xmm14
0000794c94de10ce  vmovaps [rsp+0xE0], xmm15
0000794c94de10d7  sub rsp, 0x30
0000794c94de10db  movaps [rsp], xmm1
0000794c94de10df  movaps [rsp+0x10], xmm13
0000794c94de10e5  movaps [rsp+0x20], xmm8
0000794c94de10eb  lea rdi, [rsp]
0000794c94de10ef  mov esi, 0x00
0000794c94de10f4  mov rax, 0x5AB2B8B81530
0000794c94de10fe  call rax
0000794c94de1100  movaps xmm1, [rsp]
0000794c94de1104  add rsp, 0x30
0000794c94de1108  vmovaps xmm0, [rsp]
0000794c94de110d  vmovaps xmm2, [rsp+0x10]
0000794c94de1113  vmovaps xmm3, [rsp+0x20]
0000794c94de1119  vmovaps xmm4, [rsp+0x30]
0000794c94de111f  vmovaps xmm5, [rsp+0x40]
0000794c94de1125  vmovaps xmm6, [rsp+0x50]
0000794c94de112b  vmovaps xmm7, [rsp+0x60]
0000794c94de1131  vmovaps xmm8, [rsp+0x70]
0000794c94de1137  vmovaps xmm9, [rsp+0x80]
0000794c94de1140  vmovaps xmm10, [rsp+0x90]
0000794c94de1149  vmovaps xmm11, [rsp+0xA0]
0000794c94de1152  vmovaps xmm12, [rsp+0xB0]
0000794c94de115b  vmovaps xmm13, [rsp+0xC0]
0000794c94de1164  vmovaps xmm14, [rsp+0xD0]
0000794c94de116d  vmovaps xmm15, [rsp+0xE0]
0000794c94de1176  add rsp, 0xF0
0000794c94de117d  pop r11
0000794c94de117f  pop r10
0000794c94de1181  pop r9
0000794c94de1183  pop r8
0000794c94de1185  pop rsi
0000794c94de1186  pop rdi
0000794c94de1187  pop rdx
0000794c94de1188  pop rcx
0000794c94de1189  pop rax
0000794c94de118a  add rsp, 0x08
0000794c94de118e  jmp 0x0000794C94DDC74D
0000794c94de1193  call 0x0000794C94C0C260
0000794c94de1198  jmp 0x0000794C94DDC75B
0000794c94de119d  call 0x0000794C94CBD750
0000794c94de11a2  jmp 0x0000794C94DDC765
0000794c94de11a7  sub rsp, 0x08
0000794c94de11ab  push rax
0000794c94de11ac  push rcx
0000794c94de11ad  push rdx
0000794c94de11ae  push rdi
0000794c94de11af  push rsi
0000794c94de11b0  push r8
0000794c94de11b2  push r9
0000794c94de11b4  push r10
0000794c94de11b6  push r11
0000794c94de11b8  sub rsp, 0xF0
0000794c94de11bf  vmovaps [rsp], xmm0
0000794c94de11c4  vmovaps [rsp+0x10], xmm1
0000794c94de11ca  vmovaps [rsp+0x20], xmm2
0000794c94de11d0  vmovaps [rsp+0x30], xmm3
0000794c94de11d6  vmovaps [rsp+0x40], xmm4
0000794c94de11dc  vmovaps [rsp+0x50], xmm5
0000794c94de11e2  vmovaps [rsp+0x60], xmm6
0000794c94de11e8  vmovaps [rsp+0x70], xmm7
0000794c94de11ee  vmovaps [rsp+0x80], xmm9
0000794c94de11f7  vmovaps [rsp+0x90], xmm10
0000794c94de1200  vmovaps [rsp+0xA0], xmm11
0000794c94de1209  vmovaps [rsp+0xB0], xmm12
0000794c94de1212  vmovaps [rsp+0xC0], xmm13
0000794c94de121b  vmovaps [rsp+0xD0], xmm14
0000794c94de1224  vmovaps [rsp+0xE0], xmm15
0000794c94de122d  sub rsp, 0x30
0000794c94de1231  movaps [rsp], xmm8
0000794c94de1236  movaps [rsp+0x10], xmm15
0000794c94de123c  movaps [rsp+0x20], xmm7
0000794c94de1241  lea rdi, [rsp]
0000794c94de1245  mov esi, 0x00
0000794c94de124a  mov rax, 0x5AB2B8B81530
0000794c94de1254  call rax
0000794c94de1256  movaps xmm8, [rsp]
0000794c94de125b  add rsp, 0x30
0000794c94de125f  vmovaps xmm0, [rsp]
0000794c94de1264  vmovaps xmm1, [rsp+0x10]
0000794c94de126a  vmovaps xmm2, [rsp+0x20]
0000794c94de1270  vmovaps xmm3, [rsp+0x30]
0000794c94de1276  vmovaps xmm4, [rsp+0x40]
0000794c94de127c  vmovaps xmm5, [rsp+0x50]
0000794c94de1282  vmovaps xmm6, [rsp+0x60]
0000794c94de1288  vmovaps xmm7, [rsp+0x70]
0000794c94de128e  vmovaps xmm9, [rsp+0x80]
0000794c94de1297  vmovaps xmm10, [rsp+0x90]
0000794c94de12a0  vmovaps xmm11, [rsp+0xA0]
0000794c94de12a9  vmovaps xmm12, [rsp+0xB0]
0000794c94de12b2  vmovaps xmm13, [rsp+0xC0]
0000794c94de12bb  vmovaps xmm14, [rsp+0xD0]
0000794c94de12c4  vmovaps xmm15, [rsp+0xE0]
0000794c94de12cd  add rsp, 0xF0
0000794c94de12d4  pop r11
0000794c94de12d6  pop r10
0000794c94de12d8  pop r9
0000794c94de12da  pop r8
0000794c94de12dc  pop rsi
0000794c94de12dd  pop rdi
0000794c94de12de  pop rdx
0000794c94de12df  pop rcx
0000794c94de12e0  pop rax
0000794c94de12e1  add rsp, 0x08
0000794c94de12e5  jmp 0x0000794C94DDC787
0000794c94de12ea  sub rsp, 0x08
0000794c94de12ee  push rax
0000794c94de12ef  push rcx
0000794c94de12f0  push rdx
0000794c94de12f1  push rdi
0000794c94de12f2  push rsi
0000794c94de12f3  push r8
0000794c94de12f5  push r9
0000794c94de12f7  push r10
0000794c94de12f9  push r11
0000794c94de12fb  sub rsp, 0xF0
0000794c94de1302  vmovaps [rsp], xmm0
0000794c94de1307  vmovaps [rsp+0x10], xmm1
0000794c94de130d  vmovaps [rsp+0x20], xmm2
0000794c94de1313  vmovaps [rsp+0x30], xmm3
0000794c94de1319  vmovaps [rsp+0x40], xmm4
0000794c94de131f  vmovaps [rsp+0x50], xmm5
0000794c94de1325  vmovaps [rsp+0x60], xmm6
0000794c94de132b  vmovaps [rsp+0x70], xmm8
0000794c94de1331  vmovaps [rsp+0x80], xmm9
0000794c94de133a  vmovaps [rsp+0x90], xmm10
0000794c94de1343  vmovaps [rsp+0xA0], xmm11
0000794c94de134c  vmovaps [rsp+0xB0], xmm12
0000794c94de1355  vmovaps [rsp+0xC0], xmm13
0000794c94de135e  vmovaps [rsp+0xD0], xmm14
0000794c94de1367  vmovaps [rsp+0xE0], xmm15
0000794c94de1370  sub rsp, 0x30
0000794c94de1374  movaps [rsp], xmm7
0000794c94de1378  movaps [rsp+0x10], xmm9
0000794c94de137e  movaps [rsp+0x20], xmm15
0000794c94de1384  lea rdi, [rsp]
0000794c94de1388  mov esi, 0x00
0000794c94de138d  mov rax, 0x5AB2B8B81530
0000794c94de1397  call rax
0000794c94de1399  movaps xmm7, [rsp]
0000794c94de139d  add rsp, 0x30
0000794c94de13a1  vmovaps xmm0, [rsp]
0000794c94de13a6  vmovaps xmm1, [rsp+0x10]
0000794c94de13ac  vmovaps xmm2, [rsp+0x20]
0000794c94de13b2  vmovaps xmm3, [rsp+0x30]
0000794c94de13b8  vmovaps xmm4, [rsp+0x40]
0000794c94de13be  vmovaps xmm5, [rsp+0x50]
0000794c94de13c4  vmovaps xmm6, [rsp+0x60]
0000794c94de13ca  vmovaps xmm8, [rsp+0x70]
0000794c94de13d0  vmovaps xmm9, [rsp+0x80]
0000794c94de13d9  vmovaps xmm10, [rsp+0x90]
0000794c94de13e2  vmovaps xmm11, [rsp+0xA0]
0000794c94de13eb  vmovaps xmm12, [rsp+0xB0]
0000794c94de13f4  vmovaps xmm13, [rsp+0xC0]
0000794c94de13fd  vmovaps xmm14, [rsp+0xD0]
0000794c94de1406  vmovaps xmm15, [rsp+0xE0]
0000794c94de140f  add rsp, 0xF0
0000794c94de1416  pop r11
0000794c94de1418  pop r10
0000794c94de141a  pop r9
0000794c94de141c  pop r8
0000794c94de141e  pop rsi
0000794c94de141f  pop rdi
0000794c94de1420  pop rdx
0000794c94de1421  pop rcx
0000794c94de1422  pop rax
0000794c94de1423  add rsp, 0x08
0000794c94de1427  jmp 0x0000794C94DDC7B4
0000794c94de142c  sub rsp, 0x08
0000794c94de1430  push rax
0000794c94de1431  push rcx
0000794c94de1432  push rdx
0000794c94de1433  push rdi
0000794c94de1434  push rsi
0000794c94de1435  push r8
0000794c94de1437  push r9
0000794c94de1439  push r10
0000794c94de143b  push r11
0000794c94de143d  sub rsp, 0xF0
0000794c94de1444  vmovaps [rsp], xmm0
0000794c94de1449  vmovaps [rsp+0x10], xmm1
0000794c94de144f  vmovaps [rsp+0x20], xmm2
0000794c94de1455  vmovaps [rsp+0x30], xmm3
0000794c94de145b  vmovaps [rsp+0x40], xmm4
0000794c94de1461  vmovaps [rsp+0x50], xmm5
0000794c94de1467  vmovaps [rsp+0x60], xmm6
0000794c94de146d  vmovaps [rsp+0x70], xmm7
0000794c94de1473  vmovaps [rsp+0x80], xmm8
0000794c94de147c  vmovaps [rsp+0x90], xmm10
0000794c94de1485  vmovaps [rsp+0xA0], xmm11
0000794c94de148e  vmovaps [rsp+0xB0], xmm12
0000794c94de1497  vmovaps [rsp+0xC0], xmm13
0000794c94de14a0  vmovaps [rsp+0xD0], xmm14
0000794c94de14a9  vmovaps [rsp+0xE0], xmm15
0000794c94de14b2  sub rsp, 0x30
0000794c94de14b6  movaps [rsp], xmm9
0000794c94de14bb  movaps [rsp+0x10], xmm13
0000794c94de14c1  movaps [rsp+0x20], xmm15
0000794c94de14c7  lea rdi, [rsp]
0000794c94de14cb  mov esi, 0x00
0000794c94de14d0  mov rax, 0x5AB2B8B81530
0000794c94de14da  call rax
0000794c94de14dc  movaps xmm9, [rsp]
0000794c94de14e1  add rsp, 0x30
0000794c94de14e5  vmovaps xmm0, [rsp]
0000794c94de14ea  vmovaps xmm1, [rsp+0x10]
0000794c94de14f0  vmovaps xmm2, [rsp+0x20]
0000794c94de14f6  vmovaps xmm3, [rsp+0x30]
0000794c94de14fc  vmovaps xmm4, [rsp+0x40]
0000794c94de1502  vmovaps xmm5, [rsp+0x50]
0000794c94de1508  vmovaps xmm6, [rsp+0x60]
0000794c94de150e  vmovaps xmm7, [rsp+0x70]
0000794c94de1514  vmovaps xmm8, [rsp+0x80]
0000794c94de151d  vmovaps xmm10, [rsp+0x90]
0000794c94de1526  vmovaps xmm11, [rsp+0xA0]
0000794c94de152f  vmovaps xmm12, [rsp+0xB0]
0000794c94de1538  vmovaps xmm13, [rsp+0xC0]
0000794c94de1541  vmovaps xmm14, [rsp+0xD0]
0000794c94de154a  vmovaps xmm15, [rsp+0xE0]
0000794c94de1553  add rsp, 0xF0
0000794c94de155a  pop r11
0000794c94de155c  pop r10
0000794c94de155e  pop r9
0000794c94de1560  pop r8
0000794c94de1562  pop rsi
0000794c94de1563  pop rdi
0000794c94de1564  pop rdx
0000794c94de1565  pop rcx
0000794c94de1566  pop rax
0000794c94de1567  add rsp, 0x08
0000794c94de156b  jmp 0x0000794C94DDC7E2
0000794c94de1570  sub rsp, 0x08
0000794c94de1574  push rax
0000794c94de1575  push rcx
0000794c94de1576  push rdx
0000794c94de1577  push rdi
0000794c94de1578  push rsi
0000794c94de1579  push r8
0000794c94de157b  push r9
0000794c94de157d  push r10
0000794c94de157f  push r11
0000794c94de1581  sub rsp, 0xF0
0000794c94de1588  vmovaps [rsp], xmm0
0000794c94de158d  vmovaps [rsp+0x10], xmm1
0000794c94de1593  vmovaps [rsp+0x20], xmm2
0000794c94de1599  vmovaps [rsp+0x30], xmm3
0000794c94de159f  vmovaps [rsp+0x40], xmm4
0000794c94de15a5  vmovaps [rsp+0x50], xmm5
0000794c94de15ab  vmovaps [rsp+0x60], xmm6
0000794c94de15b1  vmovaps [rsp+0x70], xmm7
0000794c94de15b7  vmovaps [rsp+0x80], xmm8
0000794c94de15c0  vmovaps [rsp+0x90], xmm9
0000794c94de15c9  vmovaps [rsp+0xA0], xmm10
0000794c94de15d2  vmovaps [rsp+0xB0], xmm11
0000794c94de15db  vmovaps [rsp+0xC0], xmm12
0000794c94de15e4  vmovaps [rsp+0xD0], xmm13
0000794c94de15ed  vmovaps [rsp+0xE0], xmm14
0000794c94de15f6  sub rsp, 0x30
0000794c94de15fa  movaps [rsp], xmm15
0000794c94de15ff  movaps [rsp+0x10], xmm11
0000794c94de1605  movaps [rsp+0x20], xmm12
0000794c94de160b  lea rdi, [rsp]
0000794c94de160f  mov esi, 0x00
0000794c94de1614  mov rax, 0x5AB2B8B81530
0000794c94de161e  call rax
0000794c94de1620  movaps xmm15, [rsp]
0000794c94de1625  add rsp, 0x30
0000794c94de1629  vmovaps xmm0, [rsp]
0000794c94de162e  vmovaps xmm1, [rsp+0x10]
0000794c94de1634  vmovaps xmm2, [rsp+0x20]
0000794c94de163a  vmovaps xmm3, [rsp+0x30]
0000794c94de1640  vmovaps xmm4, [rsp+0x40]
0000794c94de1646  vmovaps xmm5, [rsp+0x50]
0000794c94de164c  vmovaps xmm6, [rsp+0x60]
0000794c94de1652  vmovaps xmm7, [rsp+0x70]
0000794c94de1658  vmovaps xmm8, [rsp+0x80]
0000794c94de1661  vmovaps xmm9, [rsp+0x90]
0000794c94de166a  vmovaps xmm10, [rsp+0xA0]
0000794c94de1673  vmovaps xmm11, [rsp+0xB0]
0000794c94de167c  vmovaps xmm12, [rsp+0xC0]
0000794c94de1685  vmovaps xmm13, [rsp+0xD0]
0000794c94de168e  vmovaps xmm14, [rsp+0xE0]
0000794c94de1697  add rsp, 0xF0
0000794c94de169e  pop r11
0000794c94de16a0  pop r10
0000794c94de16a2  pop r9
0000794c94de16a4  pop r8
0000794c94de16a6  pop rsi
0000794c94de16a7  pop rdi
0000794c94de16a8  pop rdx
0000794c94de16a9  pop rcx
0000794c94de16aa  pop rax
0000794c94de16ab  add rsp, 0x08
0000794c94de16af  jmp 0x0000794C94DDC7FD
0000794c94de16b4  sub rsp, 0x08
0000794c94de16b8  push rax
0000794c94de16b9  push rcx
0000794c94de16ba  push rdx
0000794c94de16bb  push rdi
0000794c94de16bc  push rsi
0000794c94de16bd  push r8
0000794c94de16bf  push r9
0000794c94de16c1  push r10
0000794c94de16c3  push r11
0000794c94de16c5  sub rsp, 0xF0
0000794c94de16cc  vmovaps [rsp], xmm0
0000794c94de16d1  vmovaps [rsp+0x10], xmm1
0000794c94de16d7  vmovaps [rsp+0x20], xmm2
0000794c94de16dd  vmovaps [rsp+0x30], xmm3
0000794c94de16e3  vmovaps [rsp+0x40], xmm4
0000794c94de16e9  vmovaps [rsp+0x50], xmm5
0000794c94de16ef  vmovaps [rsp+0x60], xmm6
0000794c94de16f5  vmovaps [rsp+0x70], xmm7
0000794c94de16fb  vmovaps [rsp+0x80], xmm8
0000794c94de1704  vmovaps [rsp+0x90], xmm9
0000794c94de170d  vmovaps [rsp+0xA0], xmm10
0000794c94de1716  vmovaps [rsp+0xB0], xmm11
0000794c94de171f  vmovaps [rsp+0xC0], xmm12
0000794c94de1728  vmovaps [rsp+0xD0], xmm14
0000794c94de1731  vmovaps [rsp+0xE0], xmm15
0000794c94de173a  sub rsp, 0x30
0000794c94de173e  movaps [rsp], xmm13
0000794c94de1743  movaps [rsp+0x10], xmm10
0000794c94de1749  movaps [rsp+0x20], xmm14
0000794c94de174f  lea rdi, [rsp]
0000794c94de1753  mov esi, 0x00
0000794c94de1758  mov rax, 0x5AB2B8B81530
0000794c94de1762  call rax
0000794c94de1764  movaps xmm13, [rsp]
0000794c94de1769  add rsp, 0x30
0000794c94de176d  vmovaps xmm0, [rsp]
0000794c94de1772  vmovaps xmm1, [rsp+0x10]
0000794c94de1778  vmovaps xmm2, [rsp+0x20]
0000794c94de177e  vmovaps xmm3, [rsp+0x30]
0000794c94de1784  vmovaps xmm4, [rsp+0x40]
0000794c94de178a  vmovaps xmm5, [rsp+0x50]
0000794c94de1790  vmovaps xmm6, [rsp+0x60]
0000794c94de1796  vmovaps xmm7, [rsp+0x70]
0000794c94de179c  vmovaps xmm8, [rsp+0x80]
0000794c94de17a5  vmovaps xmm9, [rsp+0x90]
0000794c94de17ae  vmovaps xmm10, [rsp+0xA0]
0000794c94de17b7  vmovaps xmm11, [rsp+0xB0]
0000794c94de17c0  vmovaps xmm12, [rsp+0xC0]
0000794c94de17c9  vmovaps xmm14, [rsp+0xD0]
0000794c94de17d2  vmovaps xmm15, [rsp+0xE0]
0000794c94de17db  add rsp, 0xF0
0000794c94de17e2  pop r11
0000794c94de17e4  pop r10
0000794c94de17e6  pop r9
0000794c94de17e8  pop r8
0000794c94de17ea  pop rsi
0000794c94de17eb  pop rdi
0000794c94de17ec  pop rdx
0000794c94de17ed  pop rcx
0000794c94de17ee  pop rax
0000794c94de17ef  add rsp, 0x08
0000794c94de17f3  jmp 0x0000794C94DDC820
0000794c94de17f8  sub rsp, 0x08
0000794c94de17fc  push rax
0000794c94de17fd  push rcx
0000794c94de17fe  push rdx
0000794c94de17ff  push rdi
0000794c94de1800  push rsi
0000794c94de1801  push r8
0000794c94de1803  push r9
0000794c94de1805  push r10
0000794c94de1807  push r11
0000794c94de1809  sub rsp, 0xF0
0000794c94de1810  vmovaps [rsp], xmm0
0000794c94de1815  vmovaps [rsp+0x10], xmm1
0000794c94de181b  vmovaps [rsp+0x20], xmm2
0000794c94de1821  vmovaps [rsp+0x30], xmm3
0000794c94de1827  vmovaps [rsp+0x40], xmm4
0000794c94de182d  vmovaps [rsp+0x50], xmm5
0000794c94de1833  vmovaps [rsp+0x60], xmm6
0000794c94de1839  vmovaps [rsp+0x70], xmm7
0000794c94de183f  vmovaps [rsp+0x80], xmm8
0000794c94de1848  vmovaps [rsp+0x90], xmm9
0000794c94de1851  vmovaps [rsp+0xA0], xmm10
0000794c94de185a  vmovaps [rsp+0xB0], xmm11
0000794c94de1863  vmovaps [rsp+0xC0], xmm12
0000794c94de186c  vmovaps [rsp+0xD0], xmm13
0000794c94de1875  vmovaps [rsp+0xE0], xmm15
0000794c94de187e  sub rsp, 0x30
0000794c94de1882  movaps [rsp], xmm14
0000794c94de1887  movaps [rsp+0x10], xmm1
0000794c94de188c  movaps [rsp+0x20], xmm7
0000794c94de1891  lea rdi, [rsp]
0000794c94de1895  mov esi, 0x00
0000794c94de189a  mov rax, 0x5AB2B8B81530
0000794c94de18a4  call rax
0000794c94de18a6  movaps xmm14, [rsp]
0000794c94de18ab  add rsp, 0x30
0000794c94de18af  vmovaps xmm0, [rsp]
0000794c94de18b4  vmovaps xmm1, [rsp+0x10]
0000794c94de18ba  vmovaps xmm2, [rsp+0x20]
0000794c94de18c0  vmovaps xmm3, [rsp+0x30]
0000794c94de18c6  vmovaps xmm4, [rsp+0x40]
0000794c94de18cc  vmovaps xmm5, [rsp+0x50]
0000794c94de18d2  vmovaps xmm6, [rsp+0x60]
0000794c94de18d8  vmovaps xmm7, [rsp+0x70]
0000794c94de18de  vmovaps xmm8, [rsp+0x80]
0000794c94de18e7  vmovaps xmm9, [rsp+0x90]
0000794c94de18f0  vmovaps xmm10, [rsp+0xA0]
0000794c94de18f9  vmovaps xmm11, [rsp+0xB0]
0000794c94de1902  vmovaps xmm12, [rsp+0xC0]
0000794c94de190b  vmovaps xmm13, [rsp+0xD0]
0000794c94de1914  vmovaps xmm15, [rsp+0xE0]
0000794c94de191d  add rsp, 0xF0
0000794c94de1924  pop r11
0000794c94de1926  pop r10
0000794c94de1928  pop r9
0000794c94de192a  pop r8
0000794c94de192c  pop rsi
0000794c94de192d  pop rdi
0000794c94de192e  pop rdx
0000794c94de192f  pop rcx
0000794c94de1930  pop rax
0000794c94de1931  add rsp, 0x08
0000794c94de1935  jmp 0x0000794C94DDC843
0000794c94de193a  sub rsp, 0x08
0000794c94de193e  push rax
0000794c94de193f  push rcx
0000794c94de1940  push rdx
0000794c94de1941  push rdi
0000794c94de1942  push rsi
0000794c94de1943  push r8
0000794c94de1945  push r9
0000794c94de1947  push r10
0000794c94de1949  push r11
0000794c94de194b  sub rsp, 0xF0
0000794c94de1952  vmovaps [rsp], xmm0
0000794c94de1957  vmovaps [rsp+0x10], xmm2
0000794c94de195d  vmovaps [rsp+0x20], xmm3
0000794c94de1963  vmovaps [rsp+0x30], xmm4
0000794c94de1969  vmovaps [rsp+0x40], xmm5
0000794c94de196f  vmovaps [rsp+0x50], xmm6
0000794c94de1975  vmovaps [rsp+0x60], xmm7
0000794c94de197b  vmovaps [rsp+0x70], xmm8
0000794c94de1981  vmovaps [rsp+0x80], xmm9
0000794c94de198a  vmovaps [rsp+0x90], xmm10
0000794c94de1993  vmovaps [rsp+0xA0], xmm11
0000794c94de199c  vmovaps [rsp+0xB0], xmm12
0000794c94de19a5  vmovaps [rsp+0xC0], xmm13
0000794c94de19ae  vmovaps [rsp+0xD0], xmm14
0000794c94de19b7  vmovaps [rsp+0xE0], xmm15
0000794c94de19c0  sub rsp, 0x30
0000794c94de19c4  movaps [rsp], xmm1
0000794c94de19c8  movaps [rsp+0x10], xmm8
0000794c94de19ce  movaps [rsp+0x20], xmm9
0000794c94de19d4  lea rdi, [rsp]
0000794c94de19d8  mov esi, 0x00
0000794c94de19dd  mov rax, 0x5AB2B8B81530
0000794c94de19e7  call rax
0000794c94de19e9  movaps xmm1, [rsp]
0000794c94de19ed  add rsp, 0x30
0000794c94de19f1  vmovaps xmm0, [rsp]
0000794c94de19f6  vmovaps xmm2, [rsp+0x10]
0000794c94de19fc  vmovaps xmm3, [rsp+0x20]
0000794c94de1a02  vmovaps xmm4, [rsp+0x30]
0000794c94de1a08  vmovaps xmm5, [rsp+0x40]
0000794c94de1a0e  vmovaps xmm6, [rsp+0x50]
0000794c94de1a14  vmovaps xmm7, [rsp+0x60]
0000794c94de1a1a  vmovaps xmm8, [rsp+0x70]
0000794c94de1a20  vmovaps xmm9, [rsp+0x80]
0000794c94de1a29  vmovaps xmm10, [rsp+0x90]
0000794c94de1a32  vmovaps xmm11, [rsp+0xA0]
0000794c94de1a3b  vmovaps xmm12, [rsp+0xB0]
0000794c94de1a44  vmovaps xmm13, [rsp+0xC0]
0000794c94de1a4d  vmovaps xmm14, [rsp+0xD0]
0000794c94de1a56  vmovaps xmm15, [rsp+0xE0]
0000794c94de1a5f  add rsp, 0xF0
0000794c94de1a66  pop r11
0000794c94de1a68  pop r10
0000794c94de1a6a  pop r9
0000794c94de1a6c  pop r8
0000794c94de1a6e  pop rsi
0000794c94de1a6f  pop rdi
0000794c94de1a70  pop rdx
0000794c94de1a71  pop rcx
0000794c94de1a72  pop rax
0000794c94de1a73  add rsp, 0x08
0000794c94de1a77  jmp 0x0000794C94DDC865
0000794c94de1a7c  call 0x0000794C94CE5940
0000794c94de1a81  jmp 0x0000794C94DDC873
0000794c94de1a86  call 0x0000794C94C0C380
0000794c94de1a8b  jmp 0x0000794C94DDC87D
0000794c94de1a90  call 0x0000794C94C0D600
0000794c94de1a95  jmp 0x0000794C94DDC887
0000794c94de1a9a  call 0x0000794C94BFF540
0000794c94de1a9f  jmp 0x0000794C94DDC891
0000794c94de1aa4  int3
0000794c94de1aa5  nop [rax+rax*1], ax
0000794c94de1aae  nop
0000794c94de1ab0  mov rax, [r15+0xF8]
0000794c94de1ab7  lea r14, [rax+0x140]
0000794c94de1abe  mov r12, [r13+r14*1]
0000794c94de1ac3  mov [r15+0xE8], r12
0000794c94de1aca  lea r14, [rax+0x130]
0000794c94de1ad1  mov r12, [r13+r14*1]
0000794c94de1ad6  lea r14, [rax+0x138]
0000794c94de1add  mov r11, [r13+r14*1]
0000794c94de1ae2  movq xmm1, r12
0000794c94de1ae7  movq xmm15, r11
0000794c94de1aec  movq xmm1, xmm1
0000794c94de1af0  movq xmm1, xmm1
0000794c94de1af4  movaps [r15+0x1A0], xmm1
0000794c94de1afc  movq xmm15, xmm15
0000794c94de1b01  movq xmm15, xmm15
0000794c94de1b06  movaps [r15+0x190], xmm15
0000794c94de1b0e  lea r14, [rax+0x120]
0000794c94de1b15  mov r12, [r13+r14*1]
0000794c94de1b1a  lea r14, [rax+0x128]
0000794c94de1b21  mov r11, [r13+r14*1]
0000794c94de1b26  movq xmm1, r12
0000794c94de1b2b  movq xmm15, r11
0000794c94de1b30  movq xmm1, xmm1
0000794c94de1b34  movq xmm1, xmm1
0000794c94de1b38  movaps [r15+0x1C0], xmm1
0000794c94de1b40  movq xmm15, xmm15
0000794c94de1b45  movq xmm15, xmm15
0000794c94de1b4a  movaps [r15+0x1B0], xmm15
0000794c94de1b52  lea r14, [rax+0x110]
0000794c94de1b59  mov r12, [r13+r14*1]
0000794c94de1b5e  lea r14, [rax+0x118]
0000794c94de1b65  mov r11, [r13+r14*1]
0000794c94de1b6a  movq xmm1, r12
0000794c94de1b6f  movq xmm15, r11
0000794c94de1b74  movq xmm1, xmm1
0000794c94de1b78  movq xmm1, xmm1
0000794c94de1b7c  movaps [r15+0x1E0], xmm1
0000794c94de1b84  movq xmm15, xmm15
0000794c94de1b89  movq xmm15, xmm15
0000794c94de1b8e  movaps [r15+0x1D0], xmm15
0000794c94de1b96  lea r14, [rax+0x100]
0000794c94de1b9d  mov r12, [r13+r14*1]
0000794c94de1ba2  lea r14, [rax+0x108]
0000794c94de1ba9  mov r11, [r13+r14*1]
0000794c94de1bae  movq xmm1, r12
0000794c94de1bb3  movq xmm15, r11
0000794c94de1bb8  movq xmm1, xmm1
0000794c94de1bbc  movq xmm1, xmm1
0000794c94de1bc0  movaps [r15+0x200], xmm1
0000794c94de1bc8  movq xmm15, xmm15
0000794c94de1bcd  movq xmm15, xmm15
0000794c94de1bd2  movaps [r15+0x1F0], xmm15
0000794c94de1bda  mov qword ptr [r15+0x40], 0x430000
0000794c94de1be2  mov r14d, 0x430510
0000794c94de1be8  mov r12, [r13+r14*1]
0000794c94de1bed  movq xmm1, r12
0000794c94de1bf2  lea r14, [rax+0x150]
0000794c94de1bf9  mov [r15+0xF8], r14
0000794c94de1c00  mov rax, [r15+0x50]
0000794c94de1c04  movups xmm15, [r13+rax*1]
0000794c94de1c0a  movaps [r15+0x120], xmm15
0000794c94de1c12  mov qword ptr [r15+0x48], 0x10
0000794c94de1c1a  xor eax, eax
0000794c94de1c1c  mov r14d, 0x10
0000794c94de1c22  mov r12d, 0x200
0000794c94de1c28  cmp r14, r12
0000794c94de1c2b  cmc
0000794c94de1c2c  lahf
0000794c94de1c2d  seto al
0000794c94de1c30  mov [r15+0x108], eax
0000794c94de1c37  pextrq rax, xmm15, 0x01
0000794c94de1c3e  movq xmm14, rax
0000794c94de1c43  movaps [r15+0x130], xmm14
0000794c94de1c4b  movq rax, xmm1
0000794c94de1c50  movq r14, xmm15
0000794c94de1c55  vmovq xmm1, rax
0000794c94de1c5a  vmovq xmm15, r14
0000794c94de1c5f  movaps xmm13, xmm1
0000794c94de1c63  addsd xmm13, xmm15
0000794c94de1c68  ucomisd xmm13, xmm13
0000794c94de1c6d  jp 0x0000794C94DE1D86
0000794c94de1c73  movq xmm13, xmm13
0000794c94de1c78  movq rax, xmm13
0000794c94de1c7d  movq r14, xmm14
0000794c94de1c82  vmovq xmm1, rax
0000794c94de1c87  vmovq xmm15, r14
0000794c94de1c8c  movaps xmm14, xmm1
0000794c94de1c90  addsd xmm14, xmm15
0000794c94de1c95  ucomisd xmm14, xmm14
0000794c94de1c9a  jp 0x0000794C94DE1DCE
0000794c94de1ca0  movq xmm14, xmm14
0000794c94de1ca5  movaps [r15+0x110], xmm14
0000794c94de1cad  mov eax, [r15+0x108]
0000794c94de1cb4  sahf
0000794c94de1cb5  jnz 0x0000794C94DE1CE7
0000794c94de1cb7  cmp dword ptr [r15+0x318], 0x00
0000794c94de1cbf  jz 0x0000794C94DE1FE0
0000794c94de1cc5  nop [rax+rax*1], ax
0000794c94de1cce  nop [rax+rax*1], eax
0000794c94de1cd6  mov eax, 0x410490
0000794c94de1cdb  mov [r15+0x100], rax
0000794c94de1ce2  jmp 0x0000794C94BFE110
0000794c94de1ce7  cmp dword ptr [r15+0x318], 0x00
0000794c94de1cef  jz 0x0000794C94DE1E20
0000794c94de1cf5  nop [rax+rax*1], ax
0000794c94de1cfe  nop [rax+rax*1], eax
0000794c94de1d06  mov eax, 0x410474
0000794c94de1d0b  mov [r15+0x100], rax
0000794c94de1d12  jmp 0x0000794C94BFE110
0000794c94de1d17  int3
0000794c94de1d18  call 0x0000794C94CE27E0
0000794c94de1d1d  jmp 0x0000794C94DE1AC3
0000794c94de1d22  call 0x0000794C94CE27E0
0000794c94de1d27  jmp 0x0000794C94DE1AD6
0000794c94de1d2c  call 0x0000794C94CE1570
0000794c94de1d31  jmp 0x0000794C94DE1AE2
0000794c94de1d36  call 0x0000794C94CE27E0
0000794c94de1d3b  jmp 0x0000794C94DE1B1A
0000794c94de1d40  call 0x0000794C94CE1570
0000794c94de1d45  jmp 0x0000794C94DE1B26
0000794c94de1d4a  call 0x0000794C94CE27E0
0000794c94de1d4f  jmp 0x0000794C94DE1B5E
0000794c94de1d54  call 0x0000794C94CE1570
0000794c94de1d59  jmp 0x0000794C94DE1B6A
0000794c94de1d5e  call 0x0000794C94CE27E0
0000794c94de1d63  jmp 0x0000794C94DE1BA2
0000794c94de1d68  call 0x0000794C94CE1570
0000794c94de1d6d  jmp 0x0000794C94DE1BAE
0000794c94de1d72  call 0x0000794C94CE27E0
0000794c94de1d77  jmp 0x0000794C94DE1BED
0000794c94de1d7c  call 0x0000794C94C0E760
0000794c94de1d81  jmp 0x0000794C94DE1C0A
0000794c94de1d86  ucomisd xmm1, xmm15
0000794c94de1d8b  jp 0x0000794C94DE1D9A
0000794c94de1d8d  movaps xmm13, [0x0000794C949FE060]
0000794c94de1d95  jmp 0x0000794C94DE1C73
0000794c94de1d9a  vxorps xmm0, xmm1, xmm15
0000794c94de1d9f  pextrw eax, xmm0, 0x03
0000794c94de1da4  and eax, 0x7FF8
0000794c94de1da9  cmp eax, 0x08
0000794c94de1dac  jnz 0x0000794C94DE1C73
0000794c94de1db2  movq rax, xmm15
0000794c94de1db7  shl rax, 0x0D
0000794c94de1dbb  jbe 0x0000794C94DE1C73
0000794c94de1dc1  vorps xmm13, xmm15, [0x0000794C949FE070]
0000794c94de1dc9  jmp 0x0000794C94DE1C73
0000794c94de1dce  ucomisd xmm1, xmm15
0000794c94de1dd3  jp 0x0000794C94DE1DE2
0000794c94de1dd5  movaps xmm14, [0x0000794C949FE060]
0000794c94de1ddd  jmp 0x0000794C94DE1CA0
0000794c94de1de2  vxorps xmm0, xmm1, xmm15
0000794c94de1de7  pextrw eax, xmm0, 0x03
0000794c94de1dec  and eax, 0x7FF8
0000794c94de1df1  cmp eax, 0x08
0000794c94de1df4  jnz 0x0000794C94DE1CA0
0000794c94de1dfa  movq rax, xmm15
0000794c94de1dff  shl rax, 0x0D
0000794c94de1e03  jbe 0x0000794C94DE1CA0
0000794c94de1e09  vorps xmm14, xmm15, [0x0000794C949FE070]
0000794c94de1e11  jmp 0x0000794C94DE1CA0
0000794c94de1e16  int3
0000794c94de1e17  nop [rax+rax*1], ax
0000794c94de1e20  mov rax, [r15+0x48]
0000794c94de1e24  mov r14, [r15+0x50]
0000794c94de1e28  lea r12, [r14+rax*1]
0000794c94de1e2c  movups xmm1, [r13+r12*1]
0000794c94de1e32  movaps [r15+0x120], xmm1
0000794c94de1e3a  lea r14, [rax+0x10]
0000794c94de1e3e  mov [r15+0x48], r14
0000794c94de1e42  xor eax, eax
0000794c94de1e44  mov r12d, 0x200
0000794c94de1e4a  cmp r14, r12
0000794c94de1e4d  cmc
0000794c94de1e4e  lahf
0000794c94de1e4f  seto al
0000794c94de1e52  mov [r15+0x108], eax
0000794c94de1e59  pextrq rax, xmm1, 0x01
0000794c94de1e60  movq xmm15, rax
0000794c94de1e65  movaps [r15+0x130], xmm15
0000794c94de1e6d  movaps xmm14, [r15+0x110]
0000794c94de1e75  movq rax, xmm14
0000794c94de1e7a  movq r14, xmm1
0000794c94de1e7f  vmovq xmm1, rax
0000794c94de1e84  vmovq xmm14, r14
0000794c94de1e89  movaps xmm13, xmm1
0000794c94de1e8d  addsd xmm13, xmm14
0000794c94de1e92  ucomisd xmm13, xmm13
0000794c94de1e97  jp 0x0000794C94DE1F4C
0000794c94de1e9d  movq xmm13, xmm13
0000794c94de1ea2  movq rax, xmm13
0000794c94de1ea7  movq r14, xmm15
0000794c94de1eac  vmovq xmm1, rax
0000794c94de1eb1  vmovq xmm15, r14
0000794c94de1eb6  movaps xmm14, xmm1
0000794c94de1eba  addsd xmm14, xmm15
0000794c94de1ebf  ucomisd xmm14, xmm14
0000794c94de1ec4  jp 0x0000794C94DE1F94
0000794c94de1eca  movq xmm14, xmm14
0000794c94de1ecf  movaps [r15+0x110], xmm14
0000794c94de1ed7  mov eax, [r15+0x108]
0000794c94de1ede  sahf
0000794c94de1edf  jnz 0x0000794C94DE1F11
0000794c94de1ee1  cmp dword ptr [r15+0x318], 0x00
0000794c94de1ee9  jz 0x0000794C94DE1FE0
0000794c94de1eef  nop [rax+rax*1], ax
0000794c94de1ef8  nop [rax+rax*1], eax
0000794c94de1f00  mov eax, 0x410490
0000794c94de1f05  mov [r15+0x100], rax
0000794c94de1f0c  jmp 0x0000794C94BFE110
0000794c94de1f11  cmp dword ptr [r15+0x318], 0x00
0000794c94de1f19  jz 0x0000794C94DE1E20
0000794c94de1f1f  nop [rax+rax*1], ax
0000794c94de1f28  nop [rax+rax*1], eax
0000794c94de1f30  mov eax, 0x410474
0000794c94de1f35  mov [r15+0x100], rax
0000794c94de1f3c  jmp 0x0000794C94BFE110
0000794c94de1f41  int3
0000794c94de1f42  call 0x0000794C94CB52F0
0000794c94de1f47  jmp 0x0000794C94DE1E32
0000794c94de1f4c  ucomisd xmm1, xmm14
0000794c94de1f51  jp 0x0000794C94DE1F60
0000794c94de1f53  movaps xmm13, [0x0000794C949FE060]
0000794c94de1f5b  jmp 0x0000794C94DE1E9D
0000794c94de1f60  vxorps xmm0, xmm1, xmm14
0000794c94de1f65  pextrw eax, xmm0, 0x03
0000794c94de1f6a  and eax, 0x7FF8
0000794c94de1f6f  cmp eax, 0x08
0000794c94de1f72  jnz 0x0000794C94DE1E9D
0000794c94de1f78  movq rax, xmm14
0000794c94de1f7d  shl rax, 0x0D
0000794c94de1f81  jbe 0x0000794C94DE1E9D
0000794c94de1f87  vorps xmm13, xmm14, [0x0000794C949FE070]
0000794c94de1f8f  jmp 0x0000794C94DE1E9D
0000794c94de1f94  ucomisd xmm1, xmm15
0000794c94de1f99  jp 0x0000794C94DE1FA8
0000794c94de1f9b  movaps xmm14, [0x0000794C949FE060]
0000794c94de1fa3  jmp 0x0000794C94DE1ECA
0000794c94de1fa8  vxorps xmm0, xmm1, xmm15
0000794c94de1fad  pextrw eax, xmm0, 0x03
0000794c94de1fb2  and eax, 0x7FF8
0000794c94de1fb7  cmp eax, 0x08
0000794c94de1fba  jnz 0x0000794C94DE1ECA
0000794c94de1fc0  movq rax, xmm15
0000794c94de1fc5  shl rax, 0x0D
0000794c94de1fc9  jbe 0x0000794C94DE1ECA
0000794c94de1fcf  vorps xmm14, xmm15, [0x0000794C949FE070]
0000794c94de1fd7  jmp 0x0000794C94DE1ECA
0000794c94de1fdc  int3
0000794c94de1fdd  nop [rax], eax
0000794c94de1fe0  mov rax, [r15+0x40]
0000794c94de1fe4  lea r14, [rax+0x510]
0000794c94de1feb  movaps xmm1, [r15+0x110]
0000794c94de1ff3  movq rax, xmm1
0000794c94de1ff8  mov [r13+r14*1], rax
0000794c94de1ffd  mov rax, [r15+0xF0]
0000794c94de2004  mov [r15+0x100], rax
0000794c94de200b  jmp 0x0000794C94DCE5C0
0000794c94de2010  int3
0000794c94de2011  call 0x0000794C94CD5EB0
0000794c94de2016  jmp 0x0000794C94DE1FFD
0000794c94de201b  int3
0000794c94de201c  nop [rax], eax
0000794c94de2020  mov qword ptr [r15+0x100], 0x04
0000794c94de202b  mov esi, 0x00
0000794c94de2030  mov edx, 0x09
0000794c94de2035  mov rdi, 0x7FFC7F10A730
0000794c94de203f  mov rax, 0x5AB2B8A14970
0000794c94de2049  call rax
0000794c94de204b  cmp dword ptr [r15+0x318], 0x00
0000794c94de2053  jnz 0x0000794C94BFE110
0000794c94de2059  jmp 0x0000794C94BFE0A0
0000794c94de205e  int3
0000794c94de205f  int3
