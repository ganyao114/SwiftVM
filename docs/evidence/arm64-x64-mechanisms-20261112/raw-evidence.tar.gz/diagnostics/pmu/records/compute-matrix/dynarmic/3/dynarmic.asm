0000792ccedce69b  nop [rax+rax*1], eax
0000792ccedce6a0  vmovaps xmm1, [0x0000792CCE9FE010]
0000792ccedce6a8  movq xmm1, xmm1
0000792ccedce6ac  movaps [r15+0x110], xmm1
0000792ccedce6b4  vmovaps xmm1, [0x0000792CCE9FE020]
0000792ccedce6bc  movq xmm1, xmm1
0000792ccedce6c0  movaps [r15+0x120], xmm1
0000792ccedce6c8  mov eax, 0x4204C0
0000792ccedce6cd  mov r14, [r13+rax*1]
0000792ccedce6d2  movq xmm1, r14
0000792ccedce6d7  movaps [r15+0x130], xmm1
0000792ccedce6df  vmovaps xmm1, [0x0000792CCE9FE030]
0000792ccedce6e7  vpbroadcastq xmm1, xmm1
0000792ccedce6ec  movaps [r15+0x140], xmm1
0000792ccedce6f4  mov qword ptr [r15+0x40], 0x02
0000792ccedce6fc  vmovaps xmm15, [0x0000792CCE9FE040]
0000792ccedce704  movq xmm15, xmm15
0000792ccedce709  movaps [r15+0x150], xmm15
0000792ccedce711  mov qword ptr [r15+0x58], 0x420000
0000792ccedce719  vmovaps xmm15, [0x0000792CCE9FE050]
0000792ccedce721  vpbroadcastq xmm15, xmm15
0000792ccedce726  movaps [r15+0x160], xmm15
0000792ccedce72e  mov rax, [r15+0x40]
0000792ccedce732  vmovq xmm14, rax
0000792ccedce737  vpbroadcastq xmm14, xmm14
0000792ccedce73c  movaps [r15+0x170], xmm14
0000792ccedce744  mov eax, 0x4204D0
0000792ccedce749  movups xmm13, [r13+rax*1]
0000792ccedce74f  mov qword ptr [r15+0x40], 0x430518
0000792ccedce757  mov qword ptr [r15+0x50], 0x430720
0000792ccedce75f  vpmovqd xmm12, xmm13
0000792ccedce765  pxor xmm11, xmm11
0000792ccedce76a  punpcklqdq xmm12, xmm11
0000792ccedce76f  movaps [r15+0x210], xmm12
0000792ccedce777  movq xmm12, qword ptr [r15+0x120]
0000792ccedce780  movq xmm11, qword ptr [r15+0x130]
0000792ccedce789  psubd xmm12, xmm11
0000792ccedce78e  movq xmm12, xmm12
0000792ccedce793  paddq xmm13, xmm14
0000792ccedce798  movaps [r15+0x180], xmm13
0000792ccedce7a0  movq xmm14, qword ptr [r15+0x150]
0000792ccedce7a9  paddd xmm11, xmm14
0000792ccedce7ae  movq xmm11, xmm11
0000792ccedce7b3  movq xmm11, xmm11
0000792ccedce7b8  movaps [r15+0x130], xmm11
0000792ccedce7c0  pmovzxdq xmm12, xmm12
0000792ccedce7c6  psllq xmm12, 0x00
0000792ccedce7cc  movq xmm14, qword ptr [r15+0x210]
0000792ccedce7d5  movq xmm13, qword ptr [r15+0x110]
0000792ccedce7de  paddd xmm14, xmm13
0000792ccedce7e3  movq xmm14, xmm14
0000792ccedce7e8  vcvtuqq2pd xmm12, xmm12
0000792ccedce7ee  pmovzxdq xmm14, xmm14
0000792ccedce7f4  psllq xmm14, 0x00
0000792ccedce7fa  vcvtuqq2pd xmm14, xmm14
0000792ccedce800  movaps xmm13, xmm12
0000792ccedce804  mulpd xmm13, xmm1
0000792ccedce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000792ccedce80f  ptest xmm11, xmm11
0000792ccedce815  jnz 0x0000792CCEDCE8FF
0000792ccedce81b  movaps [r15+0x220], xmm13
0000792ccedce823  mov eax, 0x430720
0000792ccedce828  movups [r13+rax*1], xmm13
0000792ccedce82e  movaps xmm1, xmm14
0000792ccedce832  mulpd xmm1, xmm15
0000792ccedce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000792ccedce83c  ptest xmm13, xmm13
0000792ccedce842  jnz 0x0000792CCEDCEA4C
0000792ccedce848  movaps [r15+0x210], xmm1
0000792ccedce850  mov eax, 0x430518
0000792ccedce855  movups [r13+rax*1], xmm1
0000792ccedce85b  mov qword ptr [r15+0x48], 0x10
0000792ccedce863  xor eax, eax
0000792ccedce865  mov r14d, 0x10
0000792ccedce86b  mov r12d, 0x200
0000792ccedce871  cmp r14, r12
0000792ccedce874  cmc
0000792ccedce875  lahf
0000792ccedce876  seto al
0000792ccedce879  mov [r15+0x108], eax
0000792ccedce880  mov eax, [r15+0x108]
0000792ccedce887  sahf
0000792ccedce888  jnz 0x0000792CCEDCE8BA
0000792ccedce88a  cmp dword ptr [r15+0x318], 0x00
0000792ccedce892  jz 0x0000792CCEDCEFF0
0000792ccedce898  nop [rax+rax*1], ax
0000792ccedce8a1  nop [rax+rax*1], eax
0000792ccedce8a9  mov eax, 0x4101EC
0000792ccedce8ae  mov [r15+0x100], rax
0000792ccedce8b5  jmp 0x0000792CCEBFE110
0000792ccedce8ba  cmp dword ptr [r15+0x318], 0x00
0000792ccedce8c2  jz 0x0000792CCEDCEBA0
0000792ccedce8c8  nop [rax+rax*1], ax
0000792ccedce8d1  nop [rax+rax*1], eax
0000792ccedce8d9  mov eax, 0x4101AC
0000792ccedce8de  mov [r15+0x100], rax
0000792ccedce8e5  jmp 0x0000792CCEBFE110
0000792ccedce8ea  int3
0000792ccedce8eb  call 0x0000792CCEC0DC20
0000792ccedce8f0  jmp 0x0000792CCEDCE6D2
0000792ccedce8f5  call 0x0000792CCEC0C260
0000792ccedce8fa  jmp 0x0000792CCEDCE74F
0000792ccedce8ff  sub rsp, 0x08
0000792ccedce903  push rax
0000792ccedce904  push rcx
0000792ccedce905  push rdx
0000792ccedce906  push rdi
0000792ccedce907  push rsi
0000792ccedce908  push r8
0000792ccedce90a  push r9
0000792ccedce90c  push r10
0000792ccedce90e  push r11
0000792ccedce910  sub rsp, 0xF0
0000792ccedce917  vmovaps [rsp], xmm0
0000792ccedce91c  vmovaps [rsp+0x10], xmm1
0000792ccedce922  vmovaps [rsp+0x20], xmm2
0000792ccedce928  vmovaps [rsp+0x30], xmm3
0000792ccedce92e  vmovaps [rsp+0x40], xmm4
0000792ccedce934  vmovaps [rsp+0x50], xmm5
0000792ccedce93a  vmovaps [rsp+0x60], xmm6
0000792ccedce940  vmovaps [rsp+0x70], xmm7
0000792ccedce946  vmovaps [rsp+0x80], xmm8
0000792ccedce94f  vmovaps [rsp+0x90], xmm9
0000792ccedce958  vmovaps [rsp+0xA0], xmm10
0000792ccedce961  vmovaps [rsp+0xB0], xmm11
0000792ccedce96a  vmovaps [rsp+0xC0], xmm12
0000792ccedce973  vmovaps [rsp+0xD0], xmm14
0000792ccedce97c  vmovaps [rsp+0xE0], xmm15
0000792ccedce985  sub rsp, 0x30
0000792ccedce989  movaps [rsp], xmm13
0000792ccedce98e  movaps [rsp+0x10], xmm12
0000792ccedce994  movaps [rsp+0x20], xmm1
0000792ccedce999  lea rdi, [rsp]
0000792ccedce99d  mov esi, 0x00
0000792ccedce9a2  mov rax, 0x5AEE2D541530
0000792ccedce9ac  call rax
0000792ccedce9ae  movaps xmm13, [rsp]
0000792ccedce9b3  add rsp, 0x30
0000792ccedce9b7  vmovaps xmm0, [rsp]
0000792ccedce9bc  vmovaps xmm1, [rsp+0x10]
0000792ccedce9c2  vmovaps xmm2, [rsp+0x20]
0000792ccedce9c8  vmovaps xmm3, [rsp+0x30]
0000792ccedce9ce  vmovaps xmm4, [rsp+0x40]
0000792ccedce9d4  vmovaps xmm5, [rsp+0x50]
0000792ccedce9da  vmovaps xmm6, [rsp+0x60]
0000792ccedce9e0  vmovaps xmm7, [rsp+0x70]
0000792ccedce9e6  vmovaps xmm8, [rsp+0x80]
0000792ccedce9ef  vmovaps xmm9, [rsp+0x90]
0000792ccedce9f8  vmovaps xmm10, [rsp+0xA0]
0000792ccedcea01  vmovaps xmm11, [rsp+0xB0]
0000792ccedcea0a  vmovaps xmm12, [rsp+0xC0]
0000792ccedcea13  vmovaps xmm14, [rsp+0xD0]
0000792ccedcea1c  vmovaps xmm15, [rsp+0xE0]
0000792ccedcea25  add rsp, 0xF0
0000792ccedcea2c  pop r11
0000792ccedcea2e  pop r10
0000792ccedcea30  pop r9
0000792ccedcea32  pop r8
0000792ccedcea34  pop rsi
0000792ccedcea35  pop rdi
0000792ccedcea36  pop rdx
0000792ccedcea37  pop rcx
0000792ccedcea38  pop rax
0000792ccedcea39  add rsp, 0x08
0000792ccedcea3d  jmp 0x0000792CCEDCE81B
0000792ccedcea42  call 0x0000792CCEC0C380
0000792ccedcea47  jmp 0x0000792CCEDCE82E
0000792ccedcea4c  sub rsp, 0x08
0000792ccedcea50  push rax
0000792ccedcea51  push rcx
0000792ccedcea52  push rdx
0000792ccedcea53  push rdi
0000792ccedcea54  push rsi
0000792ccedcea55  push r8
0000792ccedcea57  push r9
0000792ccedcea59  push r10
0000792ccedcea5b  push r11
0000792ccedcea5d  sub rsp, 0xF0
0000792ccedcea64  vmovaps [rsp], xmm0
0000792ccedcea69  vmovaps [rsp+0x10], xmm2
0000792ccedcea6f  vmovaps [rsp+0x20], xmm3
0000792ccedcea75  vmovaps [rsp+0x30], xmm4
0000792ccedcea7b  vmovaps [rsp+0x40], xmm5
0000792ccedcea81  vmovaps [rsp+0x50], xmm6
0000792ccedcea87  vmovaps [rsp+0x60], xmm7
0000792ccedcea8d  vmovaps [rsp+0x70], xmm8
0000792ccedcea93  vmovaps [rsp+0x80], xmm9
0000792ccedcea9c  vmovaps [rsp+0x90], xmm10
0000792ccedceaa5  vmovaps [rsp+0xA0], xmm11
0000792ccedceaae  vmovaps [rsp+0xB0], xmm12
0000792ccedceab7  vmovaps [rsp+0xC0], xmm13
0000792ccedceac0  vmovaps [rsp+0xD0], xmm14
0000792ccedceac9  vmovaps [rsp+0xE0], xmm15
0000792ccedcead2  sub rsp, 0x30
0000792ccedcead6  movaps [rsp], xmm1
0000792ccedceada  movaps [rsp+0x10], xmm14
0000792ccedceae0  movaps [rsp+0x20], xmm15
0000792ccedceae6  lea rdi, [rsp]
0000792ccedceaea  mov esi, 0x00
0000792ccedceaef  mov rax, 0x5AEE2D541530
0000792ccedceaf9  call rax
0000792ccedceafb  movaps xmm1, [rsp]
0000792ccedceaff  add rsp, 0x30
0000792ccedceb03  vmovaps xmm0, [rsp]
0000792ccedceb08  vmovaps xmm2, [rsp+0x10]
0000792ccedceb0e  vmovaps xmm3, [rsp+0x20]
0000792ccedceb14  vmovaps xmm4, [rsp+0x30]
0000792ccedceb1a  vmovaps xmm5, [rsp+0x40]
0000792ccedceb20  vmovaps xmm6, [rsp+0x50]
0000792ccedceb26  vmovaps xmm7, [rsp+0x60]
0000792ccedceb2c  vmovaps xmm8, [rsp+0x70]
0000792ccedceb32  vmovaps xmm9, [rsp+0x80]
0000792ccedceb3b  vmovaps xmm10, [rsp+0x90]
0000792ccedceb44  vmovaps xmm11, [rsp+0xA0]
0000792ccedceb4d  vmovaps xmm12, [rsp+0xB0]
0000792ccedceb56  vmovaps xmm13, [rsp+0xC0]
0000792ccedceb5f  vmovaps xmm14, [rsp+0xD0]
0000792ccedceb68  vmovaps xmm15, [rsp+0xE0]
0000792ccedceb71  add rsp, 0xF0
0000792ccedceb78  pop r11
0000792ccedceb7a  pop r10
0000792ccedceb7c  pop r9
0000792ccedceb7e  pop r8
0000792ccedceb80  pop rsi
0000792ccedceb81  pop rdi
0000792ccedceb82  pop rdx
0000792ccedceb83  pop rcx
0000792ccedceb84  pop rax
0000792ccedceb85  add rsp, 0x08
0000792ccedceb89  jmp 0x0000792CCEDCE848
0000792ccedceb8e  call 0x0000792CCEBFF540
0000792ccedceb93  jmp 0x0000792CCEDCE85B
0000792ccedceb98  int3
0000792ccedceb99  nop [rax], eax
0000792ccedceba0  movaps xmm1, [r15+0x180]
0000792ccedceba8  vpmovqd xmm15, xmm1
0000792ccedcebae  pxor xmm14, xmm14
0000792ccedcebb3  punpcklqdq xmm15, xmm14
0000792ccedcebb8  movaps [r15+0x210], xmm15
0000792ccedcebc0  movq xmm15, qword ptr [r15+0x120]
0000792ccedcebc9  movq xmm14, qword ptr [r15+0x130]
0000792ccedcebd2  psubd xmm15, xmm14
0000792ccedcebd7  movq xmm15, xmm15
0000792ccedcebdc  movaps xmm13, [r15+0x170]
0000792ccedcebe4  paddq xmm1, xmm13
0000792ccedcebe9  movaps [r15+0x180], xmm1
0000792ccedcebf1  movq xmm1, qword ptr [r15+0x150]
0000792ccedcebfa  paddd xmm14, xmm1
0000792ccedcebff  movq xmm14, xmm14
0000792ccedcec04  movq xmm14, xmm14
0000792ccedcec09  movaps [r15+0x130], xmm14
0000792ccedcec11  pmovzxdq xmm15, xmm15
0000792ccedcec17  psllq xmm15, 0x00
0000792ccedcec1d  movq xmm1, qword ptr [r15+0x210]
0000792ccedcec26  movq xmm14, qword ptr [r15+0x110]
0000792ccedcec2f  paddd xmm1, xmm14
0000792ccedcec34  movq xmm1, xmm1
0000792ccedcec38  vcvtuqq2pd xmm15, xmm15
0000792ccedcec3e  pmovzxdq xmm1, xmm1
0000792ccedcec43  psllq xmm1, 0x00
0000792ccedcec48  vcvtuqq2pd xmm1, xmm1
0000792ccedcec4e  movaps xmm14, [r15+0x140]
0000792ccedcec56  movaps xmm13, xmm15
0000792ccedcec5a  mulpd xmm13, xmm14
0000792ccedcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000792ccedcec65  ptest xmm12, xmm12
0000792ccedcec6b  jnz 0x0000792CCEDCED4E
0000792ccedcec71  movaps [r15+0x220], xmm13
0000792ccedcec79  mov rax, [r15+0x48]
0000792ccedcec7d  mov r14, [r15+0x50]
0000792ccedcec81  lea r12, [r14+rax*1]
0000792ccedcec85  movups [r13+r12*1], xmm13
0000792ccedcec8b  movaps xmm15, [r15+0x160]
0000792ccedcec93  movaps xmm14, xmm1
0000792ccedcec97  mulpd xmm14, xmm15
0000792ccedcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000792ccedceca2  ptest xmm13, xmm13
0000792ccedceca8  jnz 0x0000792CCEDCEE9C
0000792ccedcecae  movaps [r15+0x210], xmm14
0000792ccedcecb6  mov r14, [r15+0x40]
0000792ccedcecba  lea r12, [r14+rax*1]
0000792ccedcecbe  movups [r13+r12*1], xmm14
0000792ccedcecc4  lea r14, [rax+0x10]
0000792ccedcecc8  mov [r15+0x48], r14
0000792ccedceccc  xor eax, eax
0000792ccedcecce  mov r12d, 0x200
0000792ccedcecd4  cmp r14, r12
0000792ccedcecd7  cmc
0000792ccedcecd8  lahf
0000792ccedcecd9  seto al
0000792ccedcecdc  mov [r15+0x108], eax
0000792ccedcece3  mov eax, [r15+0x108]
0000792ccedcecea  sahf
0000792ccedceceb  jnz 0x0000792CCEDCED1D
0000792ccedceced  cmp dword ptr [r15+0x318], 0x00
0000792ccedcecf5  jz 0x0000792CCEDCEFF0
0000792ccedcecfb  nop [rax+rax*1], ax
0000792ccedced04  nop [rax+rax*1], eax
0000792ccedced0c  mov eax, 0x4101EC
0000792ccedced11  mov [r15+0x100], rax
0000792ccedced18  jmp 0x0000792CCEBFE110
0000792ccedced1d  cmp dword ptr [r15+0x318], 0x00
0000792ccedced25  jz 0x0000792CCEDCEBA0
0000792ccedced2b  nop [rax+rax*1], ax
0000792ccedced34  nop [rax+rax*1], eax
0000792ccedced3c  mov eax, 0x4101AC
0000792ccedced41  mov [r15+0x100], rax
0000792ccedced48  jmp 0x0000792CCEBFE110
0000792ccedced4d  int3
0000792ccedced4e  sub rsp, 0x08
0000792ccedced52  push rax
0000792ccedced53  push rcx
0000792ccedced54  push rdx
0000792ccedced55  push rdi
0000792ccedced56  push rsi
0000792ccedced57  push r8
0000792ccedced59  push r9
0000792ccedced5b  push r10
0000792ccedced5d  push r11
0000792ccedced5f  sub rsp, 0xF0
0000792ccedced66  vmovaps [rsp], xmm0
0000792ccedced6b  vmovaps [rsp+0x10], xmm1
0000792ccedced71  vmovaps [rsp+0x20], xmm2
0000792ccedced77  vmovaps [rsp+0x30], xmm3
0000792ccedced7d  vmovaps [rsp+0x40], xmm4
0000792ccedced83  vmovaps [rsp+0x50], xmm5
0000792ccedced89  vmovaps [rsp+0x60], xmm6
0000792ccedced8f  vmovaps [rsp+0x70], xmm7
0000792ccedced95  vmovaps [rsp+0x80], xmm8
0000792ccedced9e  vmovaps [rsp+0x90], xmm9
0000792ccedceda7  vmovaps [rsp+0xA0], xmm10
0000792ccedcedb0  vmovaps [rsp+0xB0], xmm11
0000792ccedcedb9  vmovaps [rsp+0xC0], xmm12
0000792ccedcedc2  vmovaps [rsp+0xD0], xmm14
0000792ccedcedcb  vmovaps [rsp+0xE0], xmm15
0000792ccedcedd4  sub rsp, 0x30
0000792ccedcedd8  movaps [rsp], xmm13
0000792ccedceddd  movaps [rsp+0x10], xmm15
0000792ccedcede3  movaps [rsp+0x20], xmm14
0000792ccedcede9  lea rdi, [rsp]
0000792ccedceded  mov esi, 0x00
0000792ccedcedf2  mov rax, 0x5AEE2D541530
0000792ccedcedfc  call rax
0000792ccedcedfe  movaps xmm13, [rsp]
0000792ccedcee03  add rsp, 0x30
0000792ccedcee07  vmovaps xmm0, [rsp]
0000792ccedcee0c  vmovaps xmm1, [rsp+0x10]
0000792ccedcee12  vmovaps xmm2, [rsp+0x20]
0000792ccedcee18  vmovaps xmm3, [rsp+0x30]
0000792ccedcee1e  vmovaps xmm4, [rsp+0x40]
0000792ccedcee24  vmovaps xmm5, [rsp+0x50]
0000792ccedcee2a  vmovaps xmm6, [rsp+0x60]
0000792ccedcee30  vmovaps xmm7, [rsp+0x70]
0000792ccedcee36  vmovaps xmm8, [rsp+0x80]
0000792ccedcee3f  vmovaps xmm9, [rsp+0x90]
0000792ccedcee48  vmovaps xmm10, [rsp+0xA0]
0000792ccedcee51  vmovaps xmm11, [rsp+0xB0]
0000792ccedcee5a  vmovaps xmm12, [rsp+0xC0]
0000792ccedcee63  vmovaps xmm14, [rsp+0xD0]
0000792ccedcee6c  vmovaps xmm15, [rsp+0xE0]
0000792ccedcee75  add rsp, 0xF0
0000792ccedcee7c  pop r11
0000792ccedcee7e  pop r10
0000792ccedcee80  pop r9
0000792ccedcee82  pop r8
0000792ccedcee84  pop rsi
0000792ccedcee85  pop rdi
0000792ccedcee86  pop rdx
0000792ccedcee87  pop rcx
0000792ccedcee88  pop rax
0000792ccedcee89  add rsp, 0x08
0000792ccedcee8d  jmp 0x0000792CCEDCEC71
0000792ccedcee92  call 0x0000792CCECC2240
0000792ccedcee97  jmp 0x0000792CCEDCEC8B
0000792ccedcee9c  sub rsp, 0x08
0000792ccedceea0  push rax
0000792ccedceea1  push rcx
0000792ccedceea2  push rdx
0000792ccedceea3  push rdi
0000792ccedceea4  push rsi
0000792ccedceea5  push r8
0000792ccedceea7  push r9
0000792ccedceea9  push r10
0000792ccedceeab  push r11
0000792ccedceead  sub rsp, 0xF0
0000792ccedceeb4  vmovaps [rsp], xmm0
0000792ccedceeb9  vmovaps [rsp+0x10], xmm1
0000792ccedceebf  vmovaps [rsp+0x20], xmm2
0000792ccedceec5  vmovaps [rsp+0x30], xmm3
0000792ccedceecb  vmovaps [rsp+0x40], xmm4
0000792ccedceed1  vmovaps [rsp+0x50], xmm5
0000792ccedceed7  vmovaps [rsp+0x60], xmm6
0000792ccedceedd  vmovaps [rsp+0x70], xmm7
0000792ccedceee3  vmovaps [rsp+0x80], xmm8
0000792ccedceeec  vmovaps [rsp+0x90], xmm9
0000792ccedceef5  vmovaps [rsp+0xA0], xmm10
0000792ccedceefe  vmovaps [rsp+0xB0], xmm11
0000792ccedcef07  vmovaps [rsp+0xC0], xmm12
0000792ccedcef10  vmovaps [rsp+0xD0], xmm13
0000792ccedcef19  vmovaps [rsp+0xE0], xmm15
0000792ccedcef22  sub rsp, 0x30
0000792ccedcef26  movaps [rsp], xmm14
0000792ccedcef2b  movaps [rsp+0x10], xmm1
0000792ccedcef30  movaps [rsp+0x20], xmm15
0000792ccedcef36  lea rdi, [rsp]
0000792ccedcef3a  mov esi, 0x00
0000792ccedcef3f  mov rax, 0x5AEE2D541530
0000792ccedcef49  call rax
0000792ccedcef4b  movaps xmm14, [rsp]
0000792ccedcef50  add rsp, 0x30
0000792ccedcef54  vmovaps xmm0, [rsp]
0000792ccedcef59  vmovaps xmm1, [rsp+0x10]
0000792ccedcef5f  vmovaps xmm2, [rsp+0x20]
0000792ccedcef65  vmovaps xmm3, [rsp+0x30]
0000792ccedcef6b  vmovaps xmm4, [rsp+0x40]
0000792ccedcef71  vmovaps xmm5, [rsp+0x50]
0000792ccedcef77  vmovaps xmm6, [rsp+0x60]
0000792ccedcef7d  vmovaps xmm7, [rsp+0x70]
0000792ccedcef83  vmovaps xmm8, [rsp+0x80]
0000792ccedcef8c  vmovaps xmm9, [rsp+0x90]
0000792ccedcef95  vmovaps xmm10, [rsp+0xA0]
0000792ccedcef9e  vmovaps xmm11, [rsp+0xB0]
0000792ccedcefa7  vmovaps xmm12, [rsp+0xC0]
0000792ccedcefb0  vmovaps xmm13, [rsp+0xD0]
0000792ccedcefb9  vmovaps xmm15, [rsp+0xE0]
0000792ccedcefc2  add rsp, 0xF0
0000792ccedcefc9  pop r11
0000792ccedcefcb  pop r10
0000792ccedcefcd  pop r9
0000792ccedcefcf  pop r8
0000792ccedcefd1  pop rsi
0000792ccedcefd2  pop rdi
0000792ccedcefd3  pop rdx
0000792ccedcefd4  pop rcx
0000792ccedcefd5  pop rax
0000792ccedcefd6  add rsp, 0x08
0000792ccedcefda  jmp 0x0000792CCEDCECAE
0000792ccedcefdf  call 0x0000792CCECC34C0
0000792ccedcefe4  jmp 0x0000792CCEDCECC4
0000792ccedcefe9  int3
0000792ccedcefea  nop [rax+rax*1], ax
0000792ccedceff0  mov rax, [r15+0xF8]
0000792ccedceff7  lea r14, [rax-0x150]
0000792ccedceffe  mov [r15+0xF8], r14
0000792ccedcf005  mov rax, [r15+0x50]
0000792ccedcf009  lea r12, [rax+0x80]
0000792ccedcf010  movups xmm1, [r13+r12*1]
0000792ccedcf016  lea r12, [rax+0x90]
0000792ccedcf01d  movups xmm15, [r13+r12*1]
0000792ccedcf023  mov qword ptr [r15+0x48], 0x00
0000792ccedcf02b  lea r12, [rax+0x40]
0000792ccedcf02f  movups xmm14, [r13+r12*1]
0000792ccedcf035  lea r12, [rax+0x50]
0000792ccedcf039  movups xmm13, [r13+r12*1]
0000792ccedcf03f  lea r12, [r14+0x120]
0000792ccedcf046  movq xmm12, qword ptr [r15+0x1C0]
0000792ccedcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000792ccedcf058  movq r11, xmm12
0000792ccedcf05d  movq r10, xmm11
0000792ccedcf062  mov [r13+r12*1], r11
0000792ccedcf067  lea r12, [r14+0x128]
0000792ccedcf06e  mov [r13+r12*1], r10
0000792ccedcf073  vxorps xmm12, xmm12, xmm12
0000792ccedcf078  vpbroadcastq xmm12, xmm12
0000792ccedcf07d  lea r12, [r14+0x100]
0000792ccedcf084  movq xmm11, qword ptr [r15+0x200]
0000792ccedcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000792ccedcf096  movq r11, xmm11
0000792ccedcf09b  movq r10, xmm10
0000792ccedcf0a0  mov [r13+r12*1], r11
0000792ccedcf0a5  lea r12, [r14+0x108]
0000792ccedcf0ac  mov [r13+r12*1], r10
0000792ccedcf0b1  lea r12, [r14+0xE0]
0000792ccedcf0b8  movups [r13+r12*1], xmm15
0000792ccedcf0be  lea r12, [r14+0xF0]
0000792ccedcf0c5  movups [r13+r12*1], xmm1
0000792ccedcf0cb  lea r12, [rax+0xC0]
0000792ccedcf0d2  movups xmm1, [r13+r12*1]
0000792ccedcf0d8  lea r12, [rax+0xD0]
0000792ccedcf0df  movups xmm15, [r13+r12*1]
0000792ccedcf0e5  lea r12, [r14+0x110]
0000792ccedcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000792ccedcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000792ccedcf0fe  movq r11, xmm11
0000792ccedcf103  movq r10, xmm10
0000792ccedcf108  mov [r13+r12*1], r11
0000792ccedcf10d  lea r12, [r14+0x118]
0000792ccedcf114  mov [r13+r12*1], r10
0000792ccedcf119  movups xmm11, [r13+rax*1]
0000792ccedcf11f  lea r12, [rax+0x10]
0000792ccedcf123  movups xmm10, [r13+r12*1]
0000792ccedcf129  lea r12, [r14+0x130]
0000792ccedcf130  movq xmm9, qword ptr [r15+0x1A0]
0000792ccedcf139  movq xmm8, qword ptr [r15+0x190]
0000792ccedcf142  movq r11, xmm9
0000792ccedcf147  movq r10, xmm8
0000792ccedcf14c  mov [r13+r12*1], r11
0000792ccedcf151  lea r12, [r14+0x138]
0000792ccedcf158  mov [r13+r12*1], r10
0000792ccedcf15d  lea r12, [rax+0x140]
0000792ccedcf164  movups xmm9, [r13+r12*1]
0000792ccedcf16a  lea r12, [rax+0x150]
0000792ccedcf171  movups xmm8, [r13+r12*1]
0000792ccedcf177  lea r12, [r14+0xC0]
0000792ccedcf17e  movups [r13+r12*1], xmm15
0000792ccedcf184  lea r12, [r14+0xD0]
0000792ccedcf18b  movups [r13+r12*1], xmm1
0000792ccedcf191  lea r12, [rax+0x100]
0000792ccedcf198  movups xmm1, [r13+r12*1]
0000792ccedcf19e  lea r12, [rax+0x110]
0000792ccedcf1a5  movups xmm15, [r13+r12*1]
0000792ccedcf1ab  lea r12, [r14+0x140]
0000792ccedcf1b2  mov r11, [r15+0xE8]
0000792ccedcf1b9  mov [r13+r12*1], r11
0000792ccedcf1be  lea r12, [rax+0x180]
0000792ccedcf1c5  movups xmm7, [r13+r12*1]
0000792ccedcf1cb  lea r12, [rax+0x190]
0000792ccedcf1d2  movups xmm6, [r13+r12*1]
0000792ccedcf1d8  lea r12, [rax+0x1C0]
0000792ccedcf1df  movups xmm5, [r13+r12*1]
0000792ccedcf1e5  lea r12, [rax+0x1D0]
0000792ccedcf1ec  movups xmm4, [r13+r12*1]
0000792ccedcf1f2  lea r12, [r14+0x20]
0000792ccedcf1f6  movups [r13+r12*1], xmm1
0000792ccedcf1fc  lea r12, [r14+0x30]
0000792ccedcf200  movups [r13+r12*1], xmm13
0000792ccedcf206  lea r12, [rax+0x60]
0000792ccedcf20a  movups xmm1, [r13+r12*1]
0000792ccedcf210  lea r12, [rax+0x70]
0000792ccedcf214  movups xmm13, [r13+r12*1]
0000792ccedcf21a  lea r12, [rax+0x20]
0000792ccedcf21e  movups xmm3, [r13+r12*1]
0000792ccedcf224  lea r12, [rax+0x30]
0000792ccedcf228  movups xmm2, [r13+r12*1]
0000792ccedcf22e  movaps [r15+0x1F0], xmm2
0000792ccedcf236  lea r12, [r14+0x60]
0000792ccedcf23a  movups [r13+r12*1], xmm11
0000792ccedcf240  lea r12, [r14+0x70]
0000792ccedcf244  movups [r13+r12*1], xmm5
0000792ccedcf24a  lea r12, [rax+0xE0]
0000792ccedcf251  movups xmm11, [r13+r12*1]
0000792ccedcf257  lea r12, [rax+0xF0]
0000792ccedcf25e  movups xmm5, [r13+r12*1]
0000792ccedcf264  lea r12, [r14+0xA0]
0000792ccedcf26b  movups [r13+r12*1], xmm13
0000792ccedcf271  lea r12, [r14+0xB0]
0000792ccedcf278  movups [r13+r12*1], xmm1
0000792ccedcf27e  lea r12, [rax+0xA0]
0000792ccedcf285  movups xmm1, [r13+r12*1]
0000792ccedcf28b  lea r12, [rax+0xB0]
0000792ccedcf292  movups xmm13, [r13+r12*1]
0000792ccedcf298  lea r12, [rax+0x120]
0000792ccedcf29f  vmovaps [rsp+0x10], xmm1
0000792ccedcf2a5  movups xmm1, [r13+r12*1]
0000792ccedcf2ab  lea r12, [rax+0x130]
0000792ccedcf2b2  vmovaps [rsp+0x20], xmm1
0000792ccedcf2b8  movups xmm1, [r13+r12*1]
0000792ccedcf2be  lea r12, [rax+0x160]
0000792ccedcf2c5  vmovaps [rsp+0x30], xmm1
0000792ccedcf2cb  movups xmm1, [r13+r12*1]
0000792ccedcf2d1  lea r12, [rax+0x170]
0000792ccedcf2d8  vmovaps [rsp+0x40], xmm1
0000792ccedcf2de  movups xmm1, [r13+r12*1]
0000792ccedcf2e4  movaps [r15+0x2B0], xmm1
0000792ccedcf2ec  lea r12, [r14+0x80]
0000792ccedcf2f3  movups [r13+r12*1], xmm13
0000792ccedcf2f9  lea r12, [r14+0x90]
0000792ccedcf300  vmovaps xmm13, [rsp+0x10]
0000792ccedcf306  movups [r13+r12*1], xmm13
0000792ccedcf30c  lea r12, [rax+0x1A0]
0000792ccedcf313  movups xmm13, [r13+r12*1]
0000792ccedcf319  lea r12, [rax+0x1B0]
0000792ccedcf320  vmovaps [rsp+0x10], xmm1
0000792ccedcf326  movups xmm1, [r13+r12*1]
0000792ccedcf32c  movaps [r15+0x290], xmm13
0000792ccedcf334  movaps [r15+0x1E0], xmm1
0000792ccedcf33c  lea r12, [rax+0x1E0]
0000792ccedcf343  vmovaps [rsp+0x50], xmm1
0000792ccedcf349  movups xmm1, [r13+r12*1]
0000792ccedcf34f  lea r12, [rax+0x1F0]
0000792ccedcf356  vmovaps [rsp+0x60], xmm1
0000792ccedcf35c  movups xmm1, [r13+r12*1]
0000792ccedcf362  mov qword ptr [r15+0x50], 0x430920
0000792ccedcf36a  lea rax, [r14+0x40]
0000792ccedcf36e  vmovaps [rsp+0x70], xmm1
0000792ccedcf374  vmovaps xmm1, [rsp+0x40]
0000792ccedcf37a  movups [r13+rax*1], xmm1
0000792ccedcf380  lea rax, [r14+0x50]
0000792ccedcf384  movups [r13+rax*1], xmm10
0000792ccedcf38a  vmovaps xmm1, [rsp+0x70]
0000792ccedcf390  movups [r13+r14*1], xmm1
0000792ccedcf396  lea rax, [r14+0x10]
0000792ccedcf39a  vmovaps xmm1, [rsp+0x60]
0000792ccedcf3a0  movups [r13+rax*1], xmm1
0000792ccedcf3a6  mov rax, [r15+0x40]
0000792ccedcf3aa  vmovaps [rsp+0x40], xmm3
0000792ccedcf3b0  vmovaps xmm1, [rsp+0x40]
0000792ccedcf3b6  por xmm3, xmm1
0000792ccedcf3ba  vmovaps [rsp+0x40], xmm6
0000792ccedcf3c0  vmovaps xmm10, [rsp+0x40]
0000792ccedcf3c6  por xmm6, xmm10
0000792ccedcf3cb  lea r12, [rax+0x30]
0000792ccedcf3cf  mov r11, [r13+r12*1]
0000792ccedcf3d4  lea r12, [rax+0x38]
0000792ccedcf3d8  mov r10, [r13+r12*1]
0000792ccedcf3dd  movq xmm10, r11
0000792ccedcf3e2  vmovaps [rsp+0x40], xmm1
0000792ccedcf3e8  movq xmm1, r10
0000792ccedcf3ed  movq xmm10, xmm10
0000792ccedcf3f2  vmovaps [rsp+0x60], xmm10
0000792ccedcf3f8  movq xmm10, xmm10
0000792ccedcf3fd  movaps [r15+0x130], xmm10
0000792ccedcf405  movq xmm1, xmm1
0000792ccedcf409  vmovaps [rsp+0x70], xmm1
0000792ccedcf40f  movq xmm1, xmm1
0000792ccedcf413  movaps [r15+0x280], xmm1
0000792ccedcf41b  vmovaps [rsp+0x80], xmm9
0000792ccedcf424  vmovaps xmm1, [rsp+0x80]
0000792ccedcf42d  por xmm9, xmm1
0000792ccedcf432  lea r12, [rax+0x20]
0000792ccedcf436  mov r11, [r13+r12*1]
0000792ccedcf43b  lea r12, [rax+0x28]
0000792ccedcf43f  mov r10, [r13+r12*1]
0000792ccedcf444  movq xmm1, r11
0000792ccedcf449  movq xmm10, r10
0000792ccedcf44e  movq xmm1, xmm1
0000792ccedcf452  vmovaps [rsp+0x80], xmm1
0000792ccedcf45b  movq xmm1, xmm1
0000792ccedcf45f  movaps [r15+0x150], xmm1
0000792ccedcf467  movq xmm10, xmm10
0000792ccedcf46c  vmovaps [rsp+0x90], xmm10
0000792ccedcf475  movq xmm10, xmm10
0000792ccedcf47a  movaps [r15+0x140], xmm10
0000792ccedcf482  lea r12, [rax+0x10]
0000792ccedcf486  mov r11, [r13+r12*1]
0000792ccedcf48b  lea r12, [rax+0x18]
0000792ccedcf48f  mov r10, [r13+r12*1]
0000792ccedcf494  movq xmm1, r11
0000792ccedcf499  movq xmm10, r10
0000792ccedcf49e  movq xmm1, xmm1
0000792ccedcf4a2  vmovaps [rsp+0xA0], xmm1
0000792ccedcf4ab  movq xmm1, xmm1
0000792ccedcf4af  movaps [r15+0x170], xmm1
0000792ccedcf4b7  movq xmm10, xmm10
0000792ccedcf4bc  vmovaps [rsp+0xB0], xmm10
0000792ccedcf4c5  movq xmm10, xmm10
0000792ccedcf4ca  movaps [r15+0x160], xmm10
0000792ccedcf4d2  mov r12, [r13+rax*1]
0000792ccedcf4d7  vmovq xmm1, r12
0000792ccedcf4dc  vpbroadcastq xmm1, xmm1
0000792ccedcf4e1  lea r12, [rax+0x08]
0000792ccedcf4e5  mov rax, [r13+r12*1]
0000792ccedcf4ea  movq xmm10, rax
0000792ccedcf4ef  movaps [r15+0x230], xmm10
0000792ccedcf4f7  lea rax, [r14+0x50]
0000792ccedcf4fb  movups xmm10, [r13+rax*1]
0000792ccedcf501  lea rax, [r14+0x60]
0000792ccedcf505  vmovaps [rsp+0xC0], xmm1
0000792ccedcf50e  movups xmm1, [r13+rax*1]
0000792ccedcf514  lea rax, [r14+0x30]
0000792ccedcf518  vmovaps [rsp+0xD0], xmm1
0000792ccedcf521  movups xmm1, [r13+rax*1]
0000792ccedcf527  mov qword ptr [r15+0x60], 0x430920
0000792ccedcf52f  mov qword ptr [r15+0x58], 0x40
0000792ccedcf537  vmovaps [rsp+0xE0], xmm1
0000792ccedcf540  vmovaps [rsp+0xF0], xmm15
0000792ccedcf549  vmovaps xmm15, [rsp+0xC0]
0000792ccedcf552  vmovaps [rsp+0xC0], xmm14
0000792ccedcf55b  vmovaps xmm14, [rsp+0x40]
0000792ccedcf561  vmovaps [rsp+0x40], xmm13
0000792ccedcf567  movaps xmm1, xmm15
0000792ccedcf56b  mulpd xmm1, xmm14
0000792ccedcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000792ccedcf575  ptest xmm13, xmm13
0000792ccedcf57b  jnz 0x0000792CCEDD0682
0000792ccedcf581  movq xmm14, qword ptr [r15+0x230]
0000792ccedcf58a  vmovaps [rsp+0x100], xmm14
0000792ccedcf593  vpermilpd xmm14, xmm14, 0x00
0000792ccedcf599  vmovaps [rsp+0x110], xmm1
0000792ccedcf5a2  vmovaps xmm1, [rsp+0xE0]
0000792ccedcf5ab  vmovaps [rsp+0xE0], xmm15
0000792ccedcf5b4  movaps xmm13, xmm1
0000792ccedcf5b8  mulpd xmm13, xmm14
0000792ccedcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000792ccedcf5c3  ptest xmm15, xmm15
0000792ccedcf5c9  jnz 0x0000792CCEDD07C4
0000792ccedcf5cf  vxorps xmm1, xmm1, xmm1
0000792ccedcf5d3  vpbroadcastq xmm1, xmm1
0000792ccedcf5d8  vmovaps xmm14, [rsp+0xE0]
0000792ccedcf5e1  vmovaps [rsp+0xE0], xmm1
0000792ccedcf5ea  vmovaps xmm1, [rsp+0xD0]
0000792ccedcf5f3  vmovaps [rsp+0xD0], xmm13
0000792ccedcf5fc  movaps xmm15, xmm14
0000792ccedcf600  mulpd xmm15, xmm1
0000792ccedcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000792ccedcf60b  ptest xmm13, xmm13
0000792ccedcf611  jnz 0x0000792CCEDD0907
0000792ccedcf617  movaps xmm1, xmm14
0000792ccedcf61b  mulpd xmm1, xmm10
0000792ccedcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000792ccedcf625  ptest xmm13, xmm13
0000792ccedcf62b  jnz 0x0000792CCEDD0A4A
0000792ccedcf631  movaps xmm13, xmm14
0000792ccedcf635  mulpd xmm13, xmm2
0000792ccedcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000792ccedcf640  ptest xmm10, xmm10
0000792ccedcf646  jnz 0x0000792CCEDD0B8C
0000792ccedcf64c  vmovaps [rsp+0x120], xmm7
0000792ccedcf655  vmovaps xmm14, [rsp+0x120]
0000792ccedcf65e  por xmm7, xmm14
0000792ccedcf663  vmovaps xmm14, [rsp+0xC0]
0000792ccedcf66c  vmovaps xmm10, [rsp+0xC0]
0000792ccedcf675  por xmm14, xmm10
0000792ccedcf67a  vmovaps xmm2, [rsp+0x100]
0000792ccedcf683  vpermilpd xmm2, xmm2, 0x00
0000792ccedcf689  vmovaps [rsp+0xC0], xmm1
0000792ccedcf692  vmovaps [rsp+0x120], xmm15
0000792ccedcf69b  movaps xmm1, xmm10
0000792ccedcf69f  mulpd xmm1, xmm2
0000792ccedcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000792ccedcf6a8  ptest xmm15, xmm15
0000792ccedcf6ae  jnz 0x0000792CCEDD0CCF
0000792ccedcf6b4  xor eax, eax
0000792ccedcf6b6  mov r12d, 0x40
0000792ccedcf6bc  mov r11d, 0x200
0000792ccedcf6c2  cmp r12, r11
0000792ccedcf6c5  cmc
0000792ccedcf6c6  lahf
0000792ccedcf6c7  seto al
0000792ccedcf6ca  mov [r15+0x108], eax
0000792ccedcf6d1  vmovaps xmm10, [rsp+0x110]
0000792ccedcf6da  vmovaps xmm2, [rsp+0xE0]
0000792ccedcf6e3  vmovaps [rsp+0xE0], xmm1
0000792ccedcf6ec  movaps xmm15, xmm10
0000792ccedcf6f0  addpd xmm15, xmm2
0000792ccedcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000792ccedcf6fb  ptest xmm1, xmm1
0000792ccedcf700  jnz 0x0000792CCEDD0E10
0000792ccedcf706  vmovaps xmm10, [rsp+0x120]
0000792ccedcf70f  vmovaps [rsp+0x110], xmm15
0000792ccedcf718  movaps xmm1, xmm10
0000792ccedcf71c  addpd xmm1, xmm12
0000792ccedcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000792ccedcf726  ptest xmm15, xmm15
0000792ccedcf72c  jnz 0x0000792CCEDD0F53
0000792ccedcf732  vmovaps xmm10, [rsp+0xC0]
0000792ccedcf73b  vmovaps [rsp+0xC0], xmm1
0000792ccedcf744  movaps xmm15, xmm10
0000792ccedcf748  addpd xmm15, xmm12
0000792ccedcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000792ccedcf753  ptest xmm1, xmm1
0000792ccedcf758  jnz 0x0000792CCEDD1095
0000792ccedcf75e  vmovaps xmm1, [rsp+0x30]
0000792ccedcf764  vmovaps xmm12, [rsp+0x30]
0000792ccedcf76a  por xmm1, xmm12
0000792ccedcf76f  vmovaps xmm12, [rsp+0x20]
0000792ccedcf775  vmovaps xmm10, [rsp+0x20]
0000792ccedcf77b  por xmm12, xmm10
0000792ccedcf780  vmovaps [rsp+0x20], xmm5
0000792ccedcf786  vmovaps xmm10, [rsp+0x20]
0000792ccedcf78c  por xmm5, xmm10
0000792ccedcf791  vmovaps [rsp+0x20], xmm11
0000792ccedcf797  vmovaps xmm10, [rsp+0x20]
0000792ccedcf79d  por xmm11, xmm10
0000792ccedcf7a2  vmovaps [rsp+0x20], xmm4
0000792ccedcf7a8  vmovaps xmm10, [rsp+0x20]
0000792ccedcf7ae  por xmm4, xmm10
0000792ccedcf7b3  vmovaps [rsp+0x20], xmm8
0000792ccedcf7b9  vmovaps xmm10, [rsp+0x20]
0000792ccedcf7bf  por xmm8, xmm10
0000792ccedcf7c4  vmovaps xmm10, [rsp+0xF0]
0000792ccedcf7cd  vmovaps [rsp+0x20], xmm1
0000792ccedcf7d3  vmovaps xmm1, [rsp+0xF0]
0000792ccedcf7dc  por xmm10, xmm1
0000792ccedcf7e1  lea rax, [r14+0xA0]
0000792ccedcf7e8  movups xmm1, [r13+rax*1]
0000792ccedcf7ee  lea rax, [r14+0xB0]
0000792ccedcf7f5  vmovaps [rsp+0x30], xmm1
0000792ccedcf7fb  movups xmm1, [r13+rax*1]
0000792ccedcf801  vmovaps [rsp+0xF0], xmm1
0000792ccedcf80a  vmovaps [rsp+0x120], xmm15
0000792ccedcf813  movaps xmm1, xmm13
0000792ccedcf817  addpd xmm1, xmm2
0000792ccedcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000792ccedcf820  ptest xmm15, xmm15
0000792ccedcf826  jnz 0x0000792CCEDD11ED
0000792ccedcf82c  lea rax, [r14+0xF0]
0000792ccedcf833  movups xmm15, [r13+rax*1]
0000792ccedcf839  vmovaps xmm2, [rsp+0xC0]
0000792ccedcf842  vmovaps [rsp+0xC0], xmm1
0000792ccedcf84b  vmovaps xmm1, [rsp+0xE0]
0000792ccedcf854  vmovaps [rsp+0xE0], xmm15
0000792ccedcf85d  movaps xmm13, xmm2
0000792ccedcf861  addpd xmm13, xmm1
0000792ccedcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000792ccedcf86c  ptest xmm15, xmm15
0000792ccedcf872  jnz 0x0000792CCEDD1338
0000792ccedcf878  vmovaps xmm15, [rsp+0x120]
0000792ccedcf881  vmovaps xmm2, [rsp+0xD0]
0000792ccedcf88a  vmovaps [rsp+0xD0], xmm14
0000792ccedcf893  movaps xmm1, xmm15
0000792ccedcf897  addpd xmm1, xmm2
0000792ccedcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000792ccedcf8a0  ptest xmm14, xmm14
0000792ccedcf8a6  jnz 0x0000792CCEDD147A
0000792ccedcf8ac  vmovaps xmm15, [rsp+0x100]
0000792ccedcf8b5  vpermilpd xmm15, xmm15, 0x00
0000792ccedcf8bb  vmovaps xmm2, [rsp+0xF0]
0000792ccedcf8c4  vmovaps [rsp+0xF0], xmm1
0000792ccedcf8cd  movaps xmm14, xmm2
0000792ccedcf8d1  mulpd xmm14, xmm15
0000792ccedcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000792ccedcf8dc  ptest xmm1, xmm1
0000792ccedcf8e1  jnz 0x0000792CCEDD15BB
0000792ccedcf8e7  vmovaps xmm1, [rsp+0xA0]
0000792ccedcf8f0  vpermilpd xmm1, xmm1, 0x00
0000792ccedcf8f6  vmovaps xmm2, [rsp+0xE0]
0000792ccedcf8ff  vmovaps [rsp+0xE0], xmm14
0000792ccedcf908  movaps xmm15, xmm2
0000792ccedcf90c  mulpd xmm15, xmm1
0000792ccedcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000792ccedcf917  ptest xmm14, xmm14
0000792ccedcf91d  jnz 0x0000792CCEDD16FE
0000792ccedcf923  lea rax, [r14+0xE0]
0000792ccedcf92a  movups xmm1, [r13+rax*1]
0000792ccedcf930  vmovaps xmm14, [rsp+0x100]
0000792ccedcf939  vpermilpd xmm14, xmm14, 0x00
0000792ccedcf93f  vmovaps [rsp+0x100], xmm1
0000792ccedcf948  vmovaps xmm1, [rsp+0x30]
0000792ccedcf94e  vmovaps [rsp+0x30], xmm15
0000792ccedcf954  movaps xmm2, xmm1
0000792ccedcf957  mulpd xmm2, xmm14
0000792ccedcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000792ccedcf961  ptest xmm15, xmm15
0000792ccedcf967  jnz 0x0000792CCEDD184A
0000792ccedcf96d  vmovaps [rsp+0x120], xmm10
0000792ccedcf976  vmovaps xmm1, [rsp+0x120]
0000792ccedcf97f  por xmm10, xmm1
0000792ccedcf984  movaps [r15+0x300], xmm10
0000792ccedcf98c  vmovaps [rsp+0x120], xmm8
0000792ccedcf995  vmovaps xmm1, [rsp+0x120]
0000792ccedcf99e  por xmm8, xmm1
0000792ccedcf9a3  movaps [r15+0x190], xmm8
0000792ccedcf9ab  vmovaps xmm1, [rsp+0xA0]
0000792ccedcf9b4  vpermilpd xmm1, xmm1, 0x00
0000792ccedcf9ba  vmovaps xmm14, [rsp+0x100]
0000792ccedcf9c3  vmovaps [rsp+0x100], xmm13
0000792ccedcf9cc  movaps xmm15, xmm14
0000792ccedcf9d0  mulpd xmm15, xmm1
0000792ccedcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000792ccedcf9db  ptest xmm13, xmm13
0000792ccedcf9e1  jnz 0x0000792CCEDD198B
0000792ccedcf9e7  lea rax, [r14+0x90]
0000792ccedcf9ee  movups xmm1, [r13+rax*1]
0000792ccedcf9f4  vmovaps [rsp+0x120], xmm4
0000792ccedcf9fd  vmovaps xmm14, [rsp+0x120]
0000792ccedcfa06  por xmm4, xmm14
0000792ccedcfa0b  movaps [r15+0x1C0], xmm4
0000792ccedcfa13  vmovaps [rsp+0x120], xmm11
0000792ccedcfa1c  vmovaps xmm14, [rsp+0x120]
0000792ccedcfa25  por xmm11, xmm14
0000792ccedcfa2a  movaps [r15+0x200], xmm11
0000792ccedcfa32  vmovaps [rsp+0x120], xmm5
0000792ccedcfa3b  vmovaps xmm14, [rsp+0x120]
0000792ccedcfa44  por xmm5, xmm14
0000792ccedcfa49  movaps [r15+0x2D0], xmm5
0000792ccedcfa51  vmovaps [rsp+0x120], xmm12
0000792ccedcfa5a  vmovaps xmm14, [rsp+0x120]
0000792ccedcfa63  por xmm12, xmm14
0000792ccedcfa68  movaps [r15+0x2E0], xmm12
0000792ccedcfa70  vmovaps xmm13, [rsp+0x110]
0000792ccedcfa79  vmovaps [rsp+0x110], xmm1
0000792ccedcfa82  vmovaps xmm1, [rsp+0xE0]
0000792ccedcfa8b  vmovaps [rsp+0xE0], xmm15
0000792ccedcfa94  movaps xmm14, xmm13
0000792ccedcfa98  addpd xmm14, xmm1
0000792ccedcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000792ccedcfaa3  ptest xmm15, xmm15
0000792ccedcfaa9  jnz 0x0000792CCEDD1AD8
0000792ccedcfaaf  vmovaps xmm1, [rsp+0xA0]
0000792ccedcfab8  vpermilpd xmm1, xmm1, 0x00
0000792ccedcfabe  vmovaps xmm13, [rsp+0x110]
0000792ccedcfac7  vmovaps [rsp+0x110], xmm14
0000792ccedcfad0  movaps xmm15, xmm13
0000792ccedcfad4  mulpd xmm15, xmm1
0000792ccedcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000792ccedcfadf  ptest xmm14, xmm14
0000792ccedcfae5  jnz 0x0000792CCEDD1C1B
0000792ccedcfaeb  lea rax, [r14+0x80]
0000792ccedcfaf2  movups xmm1, [r13+rax*1]
0000792ccedcfaf8  vmovaps xmm13, [rsp+0xC0]
0000792ccedcfb01  vmovaps [rsp+0xC0], xmm1
0000792ccedcfb0a  movaps xmm14, xmm13
0000792ccedcfb0e  addpd xmm14, xmm2
0000792ccedcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000792ccedcfb19  ptest xmm1, xmm1
0000792ccedcfb1e  jnz 0x0000792CCEDD1D68
0000792ccedcfb24  vmovaps xmm13, [rsp+0x100]
0000792ccedcfb2d  vmovaps xmm2, [rsp+0x30]
0000792ccedcfb33  vmovaps [rsp+0x30], xmm15
0000792ccedcfb39  movaps xmm1, xmm13
0000792ccedcfb3d  addpd xmm1, xmm2
0000792ccedcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000792ccedcfb46  ptest xmm15, xmm15
0000792ccedcfb4c  jnz 0x0000792CCEDD1EAB
0000792ccedcfb52  vmovaps xmm15, [rsp+0x20]
0000792ccedcfb58  vmovaps xmm13, [rsp+0x20]
0000792ccedcfb5e  por xmm15, xmm13
0000792ccedcfb63  movaps [r15+0x2F0], xmm15
0000792ccedcfb6b  vmovaps xmm13, [rsp+0xA0]
0000792ccedcfb74  vpermilpd xmm13, xmm13, 0x00
0000792ccedcfb7a  vmovaps [rsp+0x20], xmm1
0000792ccedcfb80  vmovaps xmm1, [rsp+0xC0]
0000792ccedcfb89  vmovaps [rsp+0xA0], xmm15
0000792ccedcfb92  movaps xmm2, xmm1
0000792ccedcfb95  mulpd xmm2, xmm13
0000792ccedcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000792ccedcfb9f  ptest xmm15, xmm15
0000792ccedcfba5  jnz 0x0000792CCEDD1FEC
0000792ccedcfbab  lea rax, [r14+0xD0]
0000792ccedcfbb2  movups xmm1, [r13+rax*1]
0000792ccedcfbb8  vmovaps xmm13, [rsp+0xF0]
0000792ccedcfbc1  vmovaps [rsp+0xC0], xmm1
0000792ccedcfbca  vmovaps xmm1, [rsp+0xE0]
0000792ccedcfbd3  vmovaps [rsp+0xE0], xmm14
0000792ccedcfbdc  movaps xmm15, xmm13
0000792ccedcfbe0  addpd xmm15, xmm1
0000792ccedcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000792ccedcfbeb  ptest xmm14, xmm14
0000792ccedcfbf1  jnz 0x0000792CCEDD2137
0000792ccedcfbf7  vmovaps xmm1, [rsp+0xB0]
0000792ccedcfc00  vpermilpd xmm1, xmm1, 0x00
0000792ccedcfc06  movaps xmm14, xmm11
0000792ccedcfc0a  mulpd xmm14, xmm1
0000792ccedcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000792ccedcfc15  ptest xmm13, xmm13
0000792ccedcfc1b  jnz 0x0000792CCEDD227A
0000792ccedcfc21  movaps [r15+0x260], xmm14
0000792ccedcfc29  vxorps xmm1, xmm1, xmm1
0000792ccedcfc2d  vpbroadcastq xmm1, xmm1
0000792ccedcfc32  movaps [r15+0x1B0], xmm1
0000792ccedcfc3a  vmovaps xmm1, [rsp+0xB0]
0000792ccedcfc43  vpermilpd xmm1, xmm1, 0x00
0000792ccedcfc49  vmovaps xmm11, [rsp+0xC0]
0000792ccedcfc52  vmovaps [rsp+0xC0], xmm15
0000792ccedcfc5b  movaps xmm13, xmm11
0000792ccedcfc5f  mulpd xmm13, xmm1
0000792ccedcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000792ccedcfc6a  ptest xmm15, xmm15
0000792ccedcfc70  jnz 0x0000792CCEDD23BD
0000792ccedcfc76  lea rax, [r14+0xC0]
0000792ccedcfc7d  movups xmm1, [r13+rax*1]
0000792ccedcfc83  vmovaps xmm11, [rsp+0x110]
0000792ccedcfc8c  vmovaps [rsp+0xF0], xmm1
0000792ccedcfc95  vmovaps xmm1, [rsp+0x30]
0000792ccedcfc9b  vmovaps [rsp+0x30], xmm14
0000792ccedcfca1  movaps xmm15, xmm11
0000792ccedcfca5  addpd xmm15, xmm1
0000792ccedcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000792ccedcfcb0  ptest xmm14, xmm14
0000792ccedcfcb6  jnz 0x0000792CCEDD250A
0000792ccedcfcbc  vmovaps [rsp+0x100], xmm9
0000792ccedcfcc5  vmovaps xmm1, [rsp+0x100]
0000792ccedcfcce  por xmm9, xmm1
0000792ccedcfcd3  movaps [r15+0x270], xmm9
0000792ccedcfcdb  vmovaps [rsp+0x100], xmm6
0000792ccedcfce4  vmovaps xmm1, [rsp+0x100]
0000792ccedcfced  por xmm6, xmm1
0000792ccedcfcf1  movaps [r15+0x1A0], xmm6
0000792ccedcfcf9  vmovaps xmm14, [rsp+0xB0]
0000792ccedcfd02  vpermilpd xmm14, xmm14, 0x00
0000792ccedcfd08  vmovaps xmm6, [rsp+0xF0]
0000792ccedcfd11  vmovaps [rsp+0xF0], xmm1
0000792ccedcfd1a  movaps xmm11, xmm6
0000792ccedcfd1e  mulpd xmm11, xmm14
0000792ccedcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000792ccedcfd29  ptest xmm1, xmm1
0000792ccedcfd2e  jnz 0x0000792CCEDD264D
0000792ccedcfd34  lea rax, [r14+0x20]
0000792ccedcfd38  movups xmm1, [r13+rax*1]
0000792ccedcfd3e  movaps [r15+0x110], xmm1
0000792ccedcfd46  vmovaps xmm6, [rsp+0xE0]
0000792ccedcfd4f  vmovaps [rsp+0xE0], xmm1
0000792ccedcfd58  movaps xmm14, xmm6
0000792ccedcfd5c  addpd xmm14, xmm2
0000792ccedcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000792ccedcfd67  ptest xmm1, xmm1
0000792ccedcfd6c  jnz 0x0000792CCEDD279A
0000792ccedcfd72  vmovaps xmm1, [rsp+0xB0]
0000792ccedcfd7b  vpermilpd xmm1, xmm1, 0x00
0000792ccedcfd81  movaps xmm6, xmm5
0000792ccedcfd84  mulpd xmm6, xmm1
0000792ccedcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000792ccedcfd8d  ptest xmm2, xmm2
0000792ccedcfd92  jnz 0x0000792CCEDD28DC
0000792ccedcfd98  vmovaps xmm5, [rsp+0x20]
0000792ccedcfd9e  movaps xmm1, xmm5
0000792ccedcfda1  addpd xmm1, xmm13
0000792ccedcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000792ccedcfdab  ptest xmm2, xmm2
0000792ccedcfdb0  jnz 0x0000792CCEDD2A1C
0000792ccedcfdb6  vmovaps xmm13, [rsp+0x80]
0000792ccedcfdbf  vpermilpd xmm13, xmm13, 0x00
0000792ccedcfdc5  vmovaps xmm2, [rsp+0xE0]
0000792ccedcfdce  vmovaps [rsp+0x20], xmm1
0000792ccedcfdd4  movaps xmm5, xmm2
0000792ccedcfdd7  mulpd xmm5, xmm13
0000792ccedcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000792ccedcfde1  ptest xmm1, xmm1
0000792ccedcfde6  jnz 0x0000792CCEDD2B5D
0000792ccedcfdec  vmovaps xmm1, [rsp+0x80]
0000792ccedcfdf5  vpermilpd xmm1, xmm1, 0x00
0000792ccedcfdfb  movaps xmm13, xmm10
0000792ccedcfdff  mulpd xmm13, xmm1
0000792ccedcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000792ccedcfe0a  ptest xmm2, xmm2
0000792ccedcfe0f  jnz 0x0000792CCEDD2C9E
0000792ccedcfe15  vmovaps xmm10, [rsp+0x30]
0000792ccedcfe1b  movaps xmm1, xmm15
0000792ccedcfe1f  addpd xmm1, xmm10
0000792ccedcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000792ccedcfe29  ptest xmm2, xmm2
0000792ccedcfe2e  jnz 0x0000792CCEDD2DE1
0000792ccedcfe34  vmovaps xmm10, [rsp+0xC0]
0000792ccedcfe3d  movaps xmm15, xmm10
0000792ccedcfe41  addpd xmm15, xmm11
0000792ccedcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000792ccedcfe4c  ptest xmm2, xmm2
0000792ccedcfe51  jnz 0x0000792CCEDD2F23
0000792ccedcfe57  vmovaps xmm11, [rsp+0x80]
0000792ccedcfe60  vpermilpd xmm11, xmm11, 0x00
0000792ccedcfe66  movaps xmm10, xmm12
0000792ccedcfe6a  mulpd xmm10, xmm11
0000792ccedcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000792ccedcfe75  ptest xmm2, xmm2
0000792ccedcfe7a  jnz 0x0000792CCEDD3067
0000792ccedcfe80  vmovaps xmm12, [rsp+0x80]
0000792ccedcfe89  vpermilpd xmm12, xmm12, 0x00
0000792ccedcfe8f  vmovaps xmm2, [rsp+0xA0]
0000792ccedcfe98  vmovaps [rsp+0x30], xmm1
0000792ccedcfe9e  movaps xmm11, xmm2
0000792ccedcfea2  mulpd xmm11, xmm12
0000792ccedcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000792ccedcfead  ptest xmm1, xmm1
0000792ccedcfeb2  jnz 0x0000792CCEDD31AB
0000792ccedcfeb8  movaps xmm1, xmm14
0000792ccedcfebc  addpd xmm1, xmm6
0000792ccedcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000792ccedcfec5  ptest xmm12, xmm12
0000792ccedcfecb  jnz 0x0000792CCEDD32EE
0000792ccedcfed1  vmovaps xmm12, [rsp+0x20]
0000792ccedcfed7  movaps xmm14, xmm12
0000792ccedcfedb  addpd xmm14, xmm5
0000792ccedcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000792ccedcfee6  ptest xmm6, xmm6
0000792ccedcfeeb  jnz 0x0000792CCEDD342F
0000792ccedcfef1  vmovaps xmm12, [rsp+0x90]
0000792ccedcfefa  vpermilpd xmm12, xmm12, 0x00
0000792ccedcff00  movaps xmm6, xmm9
0000792ccedcff04  mulpd xmm6, xmm12
0000792ccedcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000792ccedcff0e  ptest xmm5, xmm5
0000792ccedcff13  jnz 0x0000792CCEDD3572
0000792ccedcff19  movaps xmm12, xmm15
0000792ccedcff1d  addpd xmm12, xmm13
0000792ccedcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000792ccedcff28  ptest xmm9, xmm9
0000792ccedcff2e  jnz 0x0000792CCEDD36B4
0000792ccedcff34  vmovaps xmm13, [rsp+0x30]
0000792ccedcff3a  movaps xmm15, xmm13
0000792ccedcff3e  addpd xmm15, xmm10
0000792ccedcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000792ccedcff49  ptest xmm9, xmm9
0000792ccedcff4f  jnz 0x0000792CCEDD37F8
0000792ccedcff55  vmovaps xmm13, [rsp+0xD0]
0000792ccedcff5e  vmovaps xmm10, [rsp+0xD0]
0000792ccedcff67  por xmm13, xmm10
0000792ccedcff6c  movaps [r15+0x250], xmm13
0000792ccedcff74  vmovaps [rsp+0x20], xmm7
0000792ccedcff7a  vmovaps xmm13, [rsp+0x20]
0000792ccedcff80  por xmm7, xmm13
0000792ccedcff85  movaps [r15+0x2A0], xmm7
0000792ccedcff8d  vmovaps [rsp+0x20], xmm3
0000792ccedcff93  vmovaps xmm13, [rsp+0x20]
0000792ccedcff99  por xmm3, xmm13
0000792ccedcff9e  movaps [r15+0x1D0], xmm3
0000792ccedcffa6  lea rax, [r14+0x40]
0000792ccedcffaa  movups xmm13, [r13+rax*1]
0000792ccedcffb0  movaps [r15+0x2C0], xmm13
0000792ccedcffb8  vmovaps xmm10, [rsp+0x90]
0000792ccedcffc1  vpermilpd xmm10, xmm10, 0x00
0000792ccedcffc7  movaps xmm9, xmm8
0000792ccedcffcb  mulpd xmm9, xmm10
0000792ccedcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000792ccedcffd6  ptest xmm5, xmm5
0000792ccedcffdb  jnz 0x0000792CCEDD3946
0000792ccedcffe1  movaps xmm10, xmm1
0000792ccedcffe5  addpd xmm10, xmm11
0000792ccedcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000792ccedcfff0  ptest xmm8, xmm8
0000792ccedcfff6  jnz 0x0000792CCEDD3A8A
0000792ccedcfffc  movaps xmm1, xmm14
0000792ccedd0000  addpd xmm1, xmm6
0000792ccedd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000792ccedd0009  ptest xmm11, xmm11
0000792ccedd000f  jnz 0x0000792CCEDD3BCD
0000792ccedd0015  vmovaps xmm14, [rsp+0x90]
0000792ccedd001e  vpermilpd xmm14, xmm14, 0x00
0000792ccedd0024  movaps xmm11, xmm13
0000792ccedd0028  mulpd xmm11, xmm14
0000792ccedd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000792ccedd0033  ptest xmm8, xmm8
0000792ccedd0039  jnz 0x0000792CCEDD3D0E
0000792ccedd003f  vmovaps xmm14, [rsp+0x90]
0000792ccedd0048  vpermilpd xmm14, xmm14, 0x00
0000792ccedd004e  vmovaps xmm8, [rsp+0x10]
0000792ccedd0054  movaps xmm13, xmm8
0000792ccedd0058  mulpd xmm13, xmm14
0000792ccedd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000792ccedd0063  ptest xmm6, xmm6
0000792ccedd0068  jnz 0x0000792CCEDD3E52
0000792ccedd006e  vmovaps xmm14, [rsp+0x60]
0000792ccedd0074  vpermilpd xmm14, xmm14, 0x00
0000792ccedd007a  movaps xmm8, xmm7
0000792ccedd007e  mulpd xmm8, xmm14
0000792ccedd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000792ccedd0089  ptest xmm6, xmm6
0000792ccedd008e  jnz 0x0000792CCEDD3F96
0000792ccedd0094  movaps xmm14, xmm12
0000792ccedd0098  addpd xmm14, xmm9
0000792ccedd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000792ccedd00a3  ptest xmm7, xmm7
0000792ccedd00a8  jnz 0x0000792CCEDD40D9
0000792ccedd00ae  vmovaps xmm12, [rsp+0x60]
0000792ccedd00b4  vpermilpd xmm12, xmm12, 0x00
0000792ccedd00ba  vmovaps xmm7, [rsp+0xF0]
0000792ccedd00c3  movaps xmm9, xmm7
0000792ccedd00c7  mulpd xmm9, xmm12
0000792ccedd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000792ccedd00d2  ptest xmm6, xmm6
0000792ccedd00d7  jnz 0x0000792CCEDD421D
0000792ccedd00dd  movaps xmm12, xmm15
0000792ccedd00e1  addpd xmm12, xmm11
0000792ccedd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000792ccedd00ec  ptest xmm7, xmm7
0000792ccedd00f1  jnz 0x0000792CCEDD4360
0000792ccedd00f7  vmovaps xmm15, [rsp+0x60]
0000792ccedd00fd  vpermilpd xmm15, xmm15, 0x00
0000792ccedd0103  vmovaps xmm7, [rsp+0x40]
0000792ccedd0109  movaps xmm11, xmm7
0000792ccedd010d  mulpd xmm11, xmm15
0000792ccedd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000792ccedd0118  ptest xmm6, xmm6
0000792ccedd011d  jnz 0x0000792CCEDD44A4
0000792ccedd0123  movaps xmm15, xmm10
0000792ccedd0127  addpd xmm15, xmm13
0000792ccedd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000792ccedd0132  ptest xmm7, xmm7
0000792ccedd0137  jnz 0x0000792CCEDD45E7
0000792ccedd013d  vmovaps xmm13, [rsp+0x60]
0000792ccedd0143  vpermilpd xmm13, xmm13, 0x00
0000792ccedd0149  vmovaps xmm7, [rsp+0x50]
0000792ccedd014f  movaps xmm10, xmm7
0000792ccedd0153  mulpd xmm10, xmm13
0000792ccedd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000792ccedd015e  ptest xmm6, xmm6
0000792ccedd0163  jnz 0x0000792CCEDD472B
0000792ccedd0169  movaps xmm13, xmm1
0000792ccedd016d  addpd xmm13, xmm8
0000792ccedd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000792ccedd0178  ptest xmm7, xmm7
0000792ccedd017d  jnz 0x0000792CCEDD486E
0000792ccedd0183  lea rax, [r14+0x70]
0000792ccedd0187  movups xmm1, [r13+rax*1]
0000792ccedd018d  movaps [r15+0x240], xmm1
0000792ccedd0195  movaps xmm8, xmm14
0000792ccedd0199  addpd xmm8, xmm9
0000792ccedd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000792ccedd01a4  ptest xmm7, xmm7
0000792ccedd01a9  jnz 0x0000792CCEDD49BB
0000792ccedd01af  movaps [r15+0x170], xmm8
0000792ccedd01b7  vmovaps xmm14, [rsp+0x70]
0000792ccedd01bd  vpermilpd xmm14, xmm14, 0x00
0000792ccedd01c3  movaps xmm9, xmm1
0000792ccedd01c7  mulpd xmm9, xmm14
0000792ccedd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000792ccedd01d2  ptest xmm7, xmm7
0000792ccedd01d7  jnz 0x0000792CCEDD4AFF
0000792ccedd01dd  vmovaps xmm1, [rsp+0x70]
0000792ccedd01e3  vpermilpd xmm1, xmm1, 0x00
0000792ccedd01e9  movaps xmm14, xmm4
0000792ccedd01ed  mulpd xmm14, xmm1
0000792ccedd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000792ccedd01f8  ptest xmm7, xmm7
0000792ccedd01fd  jnz 0x0000792CCEDD4C42
0000792ccedd0203  movaps [r15+0x180], xmm14
0000792ccedd020b  movaps xmm1, xmm12
0000792ccedd020f  addpd xmm1, xmm11
0000792ccedd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000792ccedd0219  ptest xmm7, xmm7
0000792ccedd021e  jnz 0x0000792CCEDD4D84
0000792ccedd0224  movaps [r15+0x210], xmm1
0000792ccedd022c  movups xmm12, [r13+r14*1]
0000792ccedd0232  lea rax, [r14+0x10]
0000792ccedd0236  movups xmm11, [r13+rax*1]
0000792ccedd023c  movaps [r15+0x230], xmm11
0000792ccedd0244  movaps xmm7, xmm15
0000792ccedd0248  addpd xmm7, xmm10
0000792ccedd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000792ccedd0252  ptest xmm6, xmm6
0000792ccedd0257  jnz 0x0000792CCEDD4EDA
0000792ccedd025d  movaps [r15+0x130], xmm7
0000792ccedd0265  vmovaps xmm15, [rsp+0x70]
0000792ccedd026b  vpermilpd xmm15, xmm15, 0x00
0000792ccedd0271  movaps xmm10, xmm11
0000792ccedd0275  mulpd xmm10, xmm15
0000792ccedd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000792ccedd0280  ptest xmm6, xmm6
0000792ccedd0285  jnz 0x0000792CCEDD501C
0000792ccedd028b  movaps [r15+0x220], xmm10
0000792ccedd0293  vmovaps xmm15, [rsp+0x70]
0000792ccedd0299  vpermilpd xmm15, xmm15, 0x00
0000792ccedd029f  movaps xmm11, xmm12
0000792ccedd02a3  mulpd xmm11, xmm15
0000792ccedd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000792ccedd02ae  ptest xmm6, xmm6
0000792ccedd02b3  jnz 0x0000792CCEDD5160
0000792ccedd02b9  movaps xmm15, xmm13
0000792ccedd02bd  addpd xmm15, xmm9
0000792ccedd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000792ccedd02c8  ptest xmm12, xmm12
0000792ccedd02ce  jnz 0x0000792CCEDD52A4
0000792ccedd02d4  movaps [r15+0x140], xmm15
0000792ccedd02dc  movaps xmm13, xmm8
0000792ccedd02e0  addpd xmm13, xmm14
0000792ccedd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000792ccedd02eb  ptest xmm12, xmm12
0000792ccedd02f1  jnz 0x0000792CCEDD53E8
0000792ccedd02f7  movaps [r15+0x150], xmm13
0000792ccedd02ff  movaps xmm14, xmm1
0000792ccedd0303  addpd xmm14, xmm10
0000792ccedd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000792ccedd030e  ptest xmm12, xmm12
0000792ccedd0314  jnz 0x0000792CCEDD552C
0000792ccedd031a  movaps [r15+0x160], xmm14
0000792ccedd0322  movaps xmm1, xmm7
0000792ccedd0325  addpd xmm1, xmm11
0000792ccedd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000792ccedd032f  ptest xmm12, xmm12
0000792ccedd0335  jnz 0x0000792CCEDD566F
0000792ccedd033b  movaps [r15+0x120], xmm1
0000792ccedd0343  mov eax, 0x430920
0000792ccedd0348  movups [r13+rax*1], xmm15
0000792ccedd034e  mov eax, 0x430930
0000792ccedd0353  movups [r13+rax*1], xmm13
0000792ccedd0359  mov eax, 0x430940
0000792ccedd035e  movups [r13+rax*1], xmm14
0000792ccedd0364  mov eax, 0x430950
0000792ccedd0369  movups [r13+rax*1], xmm1
0000792ccedd036f  mov eax, [r15+0x108]
0000792ccedd0376  sahf
0000792ccedd0377  jnz 0x0000792CCEDD03A9
0000792ccedd0379  cmp dword ptr [r15+0x318], 0x00
0000792ccedd0381  jz 0x0000792CCEDDB900
0000792ccedd0387  nop [rax+rax*1], ax
0000792ccedd0390  nop [rax+rax*1], eax
0000792ccedd0398  mov eax, 0x410444
0000792ccedd039d  mov [r15+0x100], rax
0000792ccedd03a4  jmp 0x0000792CCEBFE110
0000792ccedd03a9  cmp dword ptr [r15+0x318], 0x00
0000792ccedd03b1  jz 0x0000792CCEDD57E0
0000792ccedd03b7  nop [rax+rax*1], ax
0000792ccedd03c0  nop [rax+rax*1], eax
0000792ccedd03c8  mov eax, 0x410278
0000792ccedd03cd  mov [r15+0x100], rax
0000792ccedd03d4  jmp 0x0000792CCEBFE110
0000792ccedd03d9  int3
0000792ccedd03da  call 0x0000792CCECB52F0
0000792ccedd03df  jmp 0x0000792CCEDCF016
0000792ccedd03e4  call 0x0000792CCECC4620
0000792ccedd03e9  jmp 0x0000792CCEDCF023
0000792ccedd03ee  call 0x0000792CCECC33A0
0000792ccedd03f3  jmp 0x0000792CCEDCF035
0000792ccedd03f8  call 0x0000792CCECC2120
0000792ccedd03fd  jmp 0x0000792CCEDCF03F
0000792ccedd0402  call 0x0000792CCECC0860
0000792ccedd0407  jmp 0x0000792CCEDCF067
0000792ccedd040c  call 0x0000792CCECBF5F0
0000792ccedd0411  jmp 0x0000792CCEDCF073
0000792ccedd0416  call 0x0000792CCECC0860
0000792ccedd041b  jmp 0x0000792CCEDCF0A5
0000792ccedd0420  call 0x0000792CCECBF5F0
0000792ccedd0425  jmp 0x0000792CCEDCF0B1
0000792ccedd042a  call 0x0000792CCECC4740
0000792ccedd042f  jmp 0x0000792CCEDCF0BE
0000792ccedd0434  call 0x0000792CCECB5400
0000792ccedd0439  jmp 0x0000792CCEDCF0CB
0000792ccedd043e  call 0x0000792CCECB52F0
0000792ccedd0443  jmp 0x0000792CCEDCF0D8
0000792ccedd0448  call 0x0000792CCECC4620
0000792ccedd044d  jmp 0x0000792CCEDCF0E5
0000792ccedd0452  call 0x0000792CCECC0860
0000792ccedd0457  jmp 0x0000792CCEDCF10D
0000792ccedd045c  call 0x0000792CCECBF5F0
0000792ccedd0461  jmp 0x0000792CCEDCF119
0000792ccedd0466  call 0x0000792CCEC09D70
0000792ccedd046b  jmp 0x0000792CCEDCF11F
0000792ccedd0470  call 0x0000792CCECBE9C0
0000792ccedd0475  jmp 0x0000792CCEDCF129
0000792ccedd047a  call 0x0000792CCECC0860
0000792ccedd047f  jmp 0x0000792CCEDCF151
0000792ccedd0484  call 0x0000792CCECBF5F0
0000792ccedd0489  jmp 0x0000792CCEDCF15D
0000792ccedd048e  call 0x0000792CCECBD750
0000792ccedd0493  jmp 0x0000792CCEDCF16A
0000792ccedd0498  call 0x0000792CCECBC4E0
0000792ccedd049d  jmp 0x0000792CCEDCF177
0000792ccedd04a2  call 0x0000792CCECC4740
0000792ccedd04a7  jmp 0x0000792CCEDCF184
0000792ccedd04ac  call 0x0000792CCECB5400
0000792ccedd04b1  jmp 0x0000792CCEDCF191
0000792ccedd04b6  call 0x0000792CCECB52F0
0000792ccedd04bb  jmp 0x0000792CCEDCF19E
0000792ccedd04c0  call 0x0000792CCECC4620
0000792ccedd04c5  jmp 0x0000792CCEDCF1AB
0000792ccedd04ca  call 0x0000792CCECC0860
0000792ccedd04cf  jmp 0x0000792CCEDCF1BE
0000792ccedd04d4  call 0x0000792CCECBB270
0000792ccedd04d9  jmp 0x0000792CCEDCF1CB
0000792ccedd04de  call 0x0000792CCECBA000
0000792ccedd04e3  jmp 0x0000792CCEDCF1D8
0000792ccedd04e8  call 0x0000792CCECB8D90
0000792ccedd04ed  jmp 0x0000792CCEDCF1E5
0000792ccedd04f2  call 0x0000792CCECB8A20
0000792ccedd04f7  jmp 0x0000792CCEDCF1F2
0000792ccedd04fc  call 0x0000792CCECB5400
0000792ccedd0501  jmp 0x0000792CCEDCF1FC
0000792ccedd0506  call 0x0000792CCECC2240
0000792ccedd050b  jmp 0x0000792CCEDCF206
0000792ccedd0510  call 0x0000792CCECB52F0
0000792ccedd0515  jmp 0x0000792CCEDCF210
0000792ccedd051a  call 0x0000792CCECC2120
0000792ccedd051f  jmp 0x0000792CCEDCF21A
0000792ccedd0524  call 0x0000792CCECB77B0
0000792ccedd0529  jmp 0x0000792CCEDCF224
0000792ccedd052e  call 0x0000792CCECB6550
0000792ccedd0533  jmp 0x0000792CCEDCF22E
0000792ccedd0538  call 0x0000792CCECBFD50
0000792ccedd053d  jmp 0x0000792CCEDCF240
0000792ccedd0542  call 0x0000792CCECB8EA0
0000792ccedd0547  jmp 0x0000792CCEDCF24A
0000792ccedd054c  call 0x0000792CCECBFC30
0000792ccedd0551  jmp 0x0000792CCEDCF257
0000792ccedd0556  call 0x0000792CCECB8D90
0000792ccedd055b  jmp 0x0000792CCEDCF264
0000792ccedd0560  call 0x0000792CCECC2240
0000792ccedd0565  jmp 0x0000792CCEDCF271
0000792ccedd056a  call 0x0000792CCECB5400
0000792ccedd056f  jmp 0x0000792CCEDCF27E
0000792ccedd0574  call 0x0000792CCECB52F0
0000792ccedd0579  jmp 0x0000792CCEDCF28B
0000792ccedd057e  call 0x0000792CCECC2120
0000792ccedd0583  jmp 0x0000792CCEDCF298
0000792ccedd0588  call 0x0000792CCECB52F0
0000792ccedd058d  jmp 0x0000792CCEDCF2AB
0000792ccedd0592  call 0x0000792CCECB52F0
0000792ccedd0597  jmp 0x0000792CCEDCF2BE
0000792ccedd059c  call 0x0000792CCECB52F0
0000792ccedd05a1  jmp 0x0000792CCEDCF2D1
0000792ccedd05a6  call 0x0000792CCECB52F0
0000792ccedd05ab  jmp 0x0000792CCEDCF2E4
0000792ccedd05b0  call 0x0000792CCECC2240
0000792ccedd05b5  jmp 0x0000792CCEDCF2F9
0000792ccedd05ba  call 0x0000792CCECC2240
0000792ccedd05bf  jmp 0x0000792CCEDCF30C
0000792ccedd05c4  call 0x0000792CCECC2120
0000792ccedd05c9  jmp 0x0000792CCEDCF319
0000792ccedd05ce  call 0x0000792CCECB52F0
0000792ccedd05d3  jmp 0x0000792CCEDCF32C
0000792ccedd05d8  call 0x0000792CCECB52F0
0000792ccedd05dd  jmp 0x0000792CCEDCF34F
0000792ccedd05e2  call 0x0000792CCECB52F0
0000792ccedd05e7  jmp 0x0000792CCEDCF362
0000792ccedd05ec  call 0x0000792CCEBFF540
0000792ccedd05f1  jmp 0x0000792CCEDCF380
0000792ccedd05f6  call 0x0000792CCEC08C20
0000792ccedd05fb  jmp 0x0000792CCEDCF38A
0000792ccedd0600  call 0x0000792CCECD6600
0000792ccedd0605  jmp 0x0000792CCEDCF396
0000792ccedd060a  call 0x0000792CCEBFF540
0000792ccedd060f  jmp 0x0000792CCEDCF3A6
0000792ccedd0614  call 0x0000792CCECC0370
0000792ccedd0619  jmp 0x0000792CCEDCF3D4
0000792ccedd061e  call 0x0000792CCECBF100
0000792ccedd0623  jmp 0x0000792CCEDCF3DD
0000792ccedd0628  call 0x0000792CCECC0370
0000792ccedd062d  jmp 0x0000792CCEDCF43B
0000792ccedd0632  call 0x0000792CCECBF100
0000792ccedd0637  jmp 0x0000792CCEDCF444
0000792ccedd063c  call 0x0000792CCECC0370
0000792ccedd0641  jmp 0x0000792CCEDCF48B
0000792ccedd0646  call 0x0000792CCECBF100
0000792ccedd064b  jmp 0x0000792CCEDCF494
0000792ccedd0650  call 0x0000792CCEC0B720
0000792ccedd0655  jmp 0x0000792CCEDCF4D7
0000792ccedd065a  call 0x0000792CCECB47C0
0000792ccedd065f  jmp 0x0000792CCEDCF4EA
0000792ccedd0664  call 0x0000792CCEC08B00
0000792ccedd0669  jmp 0x0000792CCEDCF501
0000792ccedd066e  call 0x0000792CCEBFF430
0000792ccedd0673  jmp 0x0000792CCEDCF514
0000792ccedd0678  call 0x0000792CCEBFF430
0000792ccedd067d  jmp 0x0000792CCEDCF527
0000792ccedd0682  sub rsp, 0x08
0000792ccedd0686  push rax
0000792ccedd0687  push rcx
0000792ccedd0688  push rdx
0000792ccedd0689  push rdi
0000792ccedd068a  push rsi
0000792ccedd068b  push r8
0000792ccedd068d  push r9
0000792ccedd068f  push r10
0000792ccedd0691  push r11
0000792ccedd0693  sub rsp, 0xF0
0000792ccedd069a  vmovaps [rsp], xmm0
0000792ccedd069f  vmovaps [rsp+0x10], xmm2
0000792ccedd06a5  vmovaps [rsp+0x20], xmm3
0000792ccedd06ab  vmovaps [rsp+0x30], xmm4
0000792ccedd06b1  vmovaps [rsp+0x40], xmm5
0000792ccedd06b7  vmovaps [rsp+0x50], xmm6
0000792ccedd06bd  vmovaps [rsp+0x60], xmm7
0000792ccedd06c3  vmovaps [rsp+0x70], xmm8
0000792ccedd06c9  vmovaps [rsp+0x80], xmm9
0000792ccedd06d2  vmovaps [rsp+0x90], xmm10
0000792ccedd06db  vmovaps [rsp+0xA0], xmm11
0000792ccedd06e4  vmovaps [rsp+0xB0], xmm12
0000792ccedd06ed  vmovaps [rsp+0xC0], xmm13
0000792ccedd06f6  vmovaps [rsp+0xD0], xmm14
0000792ccedd06ff  vmovaps [rsp+0xE0], xmm15
0000792ccedd0708  sub rsp, 0x30
0000792ccedd070c  movaps [rsp], xmm1
0000792ccedd0710  movaps [rsp+0x10], xmm15
0000792ccedd0716  movaps [rsp+0x20], xmm14
0000792ccedd071c  lea rdi, [rsp]
0000792ccedd0720  mov esi, 0x00
0000792ccedd0725  mov rax, 0x5AEE2D541530
0000792ccedd072f  call rax
0000792ccedd0731  movaps xmm1, [rsp]
0000792ccedd0735  add rsp, 0x30
0000792ccedd0739  vmovaps xmm0, [rsp]
0000792ccedd073e  vmovaps xmm2, [rsp+0x10]
0000792ccedd0744  vmovaps xmm3, [rsp+0x20]
0000792ccedd074a  vmovaps xmm4, [rsp+0x30]
0000792ccedd0750  vmovaps xmm5, [rsp+0x40]
0000792ccedd0756  vmovaps xmm6, [rsp+0x50]
0000792ccedd075c  vmovaps xmm7, [rsp+0x60]
0000792ccedd0762  vmovaps xmm8, [rsp+0x70]
0000792ccedd0768  vmovaps xmm9, [rsp+0x80]
0000792ccedd0771  vmovaps xmm10, [rsp+0x90]
0000792ccedd077a  vmovaps xmm11, [rsp+0xA0]
0000792ccedd0783  vmovaps xmm12, [rsp+0xB0]
0000792ccedd078c  vmovaps xmm13, [rsp+0xC0]
0000792ccedd0795  vmovaps xmm14, [rsp+0xD0]
0000792ccedd079e  vmovaps xmm15, [rsp+0xE0]
0000792ccedd07a7  add rsp, 0xF0
0000792ccedd07ae  pop r11
0000792ccedd07b0  pop r10
0000792ccedd07b2  pop r9
0000792ccedd07b4  pop r8
0000792ccedd07b6  pop rsi
0000792ccedd07b7  pop rdi
0000792ccedd07b8  pop rdx
0000792ccedd07b9  pop rcx
0000792ccedd07ba  pop rax
0000792ccedd07bb  add rsp, 0x08
0000792ccedd07bf  jmp 0x0000792CCEDCF581
0000792ccedd07c4  sub rsp, 0x08
0000792ccedd07c8  push rax
0000792ccedd07c9  push rcx
0000792ccedd07ca  push rdx
0000792ccedd07cb  push rdi
0000792ccedd07cc  push rsi
0000792ccedd07cd  push r8
0000792ccedd07cf  push r9
0000792ccedd07d1  push r10
0000792ccedd07d3  push r11
0000792ccedd07d5  sub rsp, 0xF0
0000792ccedd07dc  vmovaps [rsp], xmm0
0000792ccedd07e1  vmovaps [rsp+0x10], xmm1
0000792ccedd07e7  vmovaps [rsp+0x20], xmm2
0000792ccedd07ed  vmovaps [rsp+0x30], xmm3
0000792ccedd07f3  vmovaps [rsp+0x40], xmm4
0000792ccedd07f9  vmovaps [rsp+0x50], xmm5
0000792ccedd07ff  vmovaps [rsp+0x60], xmm6
0000792ccedd0805  vmovaps [rsp+0x70], xmm7
0000792ccedd080b  vmovaps [rsp+0x80], xmm8
0000792ccedd0814  vmovaps [rsp+0x90], xmm9
0000792ccedd081d  vmovaps [rsp+0xA0], xmm10
0000792ccedd0826  vmovaps [rsp+0xB0], xmm11
0000792ccedd082f  vmovaps [rsp+0xC0], xmm12
0000792ccedd0838  vmovaps [rsp+0xD0], xmm14
0000792ccedd0841  vmovaps [rsp+0xE0], xmm15
0000792ccedd084a  sub rsp, 0x30
0000792ccedd084e  movaps [rsp], xmm13
0000792ccedd0853  movaps [rsp+0x10], xmm1
0000792ccedd0858  movaps [rsp+0x20], xmm14
0000792ccedd085e  lea rdi, [rsp]
0000792ccedd0862  mov esi, 0x00
0000792ccedd0867  mov rax, 0x5AEE2D541530
0000792ccedd0871  call rax
0000792ccedd0873  movaps xmm13, [rsp]
0000792ccedd0878  add rsp, 0x30
0000792ccedd087c  vmovaps xmm0, [rsp]
0000792ccedd0881  vmovaps xmm1, [rsp+0x10]
0000792ccedd0887  vmovaps xmm2, [rsp+0x20]
0000792ccedd088d  vmovaps xmm3, [rsp+0x30]
0000792ccedd0893  vmovaps xmm4, [rsp+0x40]
0000792ccedd0899  vmovaps xmm5, [rsp+0x50]
0000792ccedd089f  vmovaps xmm6, [rsp+0x60]
0000792ccedd08a5  vmovaps xmm7, [rsp+0x70]
0000792ccedd08ab  vmovaps xmm8, [rsp+0x80]
0000792ccedd08b4  vmovaps xmm9, [rsp+0x90]
0000792ccedd08bd  vmovaps xmm10, [rsp+0xA0]
0000792ccedd08c6  vmovaps xmm11, [rsp+0xB0]
0000792ccedd08cf  vmovaps xmm12, [rsp+0xC0]
0000792ccedd08d8  vmovaps xmm14, [rsp+0xD0]
0000792ccedd08e1  vmovaps xmm15, [rsp+0xE0]
0000792ccedd08ea  add rsp, 0xF0
0000792ccedd08f1  pop r11
0000792ccedd08f3  pop r10
0000792ccedd08f5  pop r9
0000792ccedd08f7  pop r8
0000792ccedd08f9  pop rsi
0000792ccedd08fa  pop rdi
0000792ccedd08fb  pop rdx
0000792ccedd08fc  pop rcx
0000792ccedd08fd  pop rax
0000792ccedd08fe  add rsp, 0x08
0000792ccedd0902  jmp 0x0000792CCEDCF5CF
0000792ccedd0907  sub rsp, 0x08
0000792ccedd090b  push rax
0000792ccedd090c  push rcx
0000792ccedd090d  push rdx
0000792ccedd090e  push rdi
0000792ccedd090f  push rsi
0000792ccedd0910  push r8
0000792ccedd0912  push r9
0000792ccedd0914  push r10
0000792ccedd0916  push r11
0000792ccedd0918  sub rsp, 0xF0
0000792ccedd091f  vmovaps [rsp], xmm0
0000792ccedd0924  vmovaps [rsp+0x10], xmm1
0000792ccedd092a  vmovaps [rsp+0x20], xmm2
0000792ccedd0930  vmovaps [rsp+0x30], xmm3
0000792ccedd0936  vmovaps [rsp+0x40], xmm4
0000792ccedd093c  vmovaps [rsp+0x50], xmm5
0000792ccedd0942  vmovaps [rsp+0x60], xmm6
0000792ccedd0948  vmovaps [rsp+0x70], xmm7
0000792ccedd094e  vmovaps [rsp+0x80], xmm8
0000792ccedd0957  vmovaps [rsp+0x90], xmm9
0000792ccedd0960  vmovaps [rsp+0xA0], xmm10
0000792ccedd0969  vmovaps [rsp+0xB0], xmm11
0000792ccedd0972  vmovaps [rsp+0xC0], xmm12
0000792ccedd097b  vmovaps [rsp+0xD0], xmm13
0000792ccedd0984  vmovaps [rsp+0xE0], xmm14
0000792ccedd098d  sub rsp, 0x30
0000792ccedd0991  movaps [rsp], xmm15
0000792ccedd0996  movaps [rsp+0x10], xmm14
0000792ccedd099c  movaps [rsp+0x20], xmm1
0000792ccedd09a1  lea rdi, [rsp]
0000792ccedd09a5  mov esi, 0x00
0000792ccedd09aa  mov rax, 0x5AEE2D541530
0000792ccedd09b4  call rax
0000792ccedd09b6  movaps xmm15, [rsp]
0000792ccedd09bb  add rsp, 0x30
0000792ccedd09bf  vmovaps xmm0, [rsp]
0000792ccedd09c4  vmovaps xmm1, [rsp+0x10]
0000792ccedd09ca  vmovaps xmm2, [rsp+0x20]
0000792ccedd09d0  vmovaps xmm3, [rsp+0x30]
0000792ccedd09d6  vmovaps xmm4, [rsp+0x40]
0000792ccedd09dc  vmovaps xmm5, [rsp+0x50]
0000792ccedd09e2  vmovaps xmm6, [rsp+0x60]
0000792ccedd09e8  vmovaps xmm7, [rsp+0x70]
0000792ccedd09ee  vmovaps xmm8, [rsp+0x80]
0000792ccedd09f7  vmovaps xmm9, [rsp+0x90]
0000792ccedd0a00  vmovaps xmm10, [rsp+0xA0]
0000792ccedd0a09  vmovaps xmm11, [rsp+0xB0]
0000792ccedd0a12  vmovaps xmm12, [rsp+0xC0]
0000792ccedd0a1b  vmovaps xmm13, [rsp+0xD0]
0000792ccedd0a24  vmovaps xmm14, [rsp+0xE0]
0000792ccedd0a2d  add rsp, 0xF0
0000792ccedd0a34  pop r11
0000792ccedd0a36  pop r10
0000792ccedd0a38  pop r9
0000792ccedd0a3a  pop r8
0000792ccedd0a3c  pop rsi
0000792ccedd0a3d  pop rdi
0000792ccedd0a3e  pop rdx
0000792ccedd0a3f  pop rcx
0000792ccedd0a40  pop rax
0000792ccedd0a41  add rsp, 0x08
0000792ccedd0a45  jmp 0x0000792CCEDCF617
0000792ccedd0a4a  sub rsp, 0x08
0000792ccedd0a4e  push rax
0000792ccedd0a4f  push rcx
0000792ccedd0a50  push rdx
0000792ccedd0a51  push rdi
0000792ccedd0a52  push rsi
0000792ccedd0a53  push r8
0000792ccedd0a55  push r9
0000792ccedd0a57  push r10
0000792ccedd0a59  push r11
0000792ccedd0a5b  sub rsp, 0xF0
0000792ccedd0a62  vmovaps [rsp], xmm0
0000792ccedd0a67  vmovaps [rsp+0x10], xmm2
0000792ccedd0a6d  vmovaps [rsp+0x20], xmm3
0000792ccedd0a73  vmovaps [rsp+0x30], xmm4
0000792ccedd0a79  vmovaps [rsp+0x40], xmm5
0000792ccedd0a7f  vmovaps [rsp+0x50], xmm6
0000792ccedd0a85  vmovaps [rsp+0x60], xmm7
0000792ccedd0a8b  vmovaps [rsp+0x70], xmm8
0000792ccedd0a91  vmovaps [rsp+0x80], xmm9
0000792ccedd0a9a  vmovaps [rsp+0x90], xmm10
0000792ccedd0aa3  vmovaps [rsp+0xA0], xmm11
0000792ccedd0aac  vmovaps [rsp+0xB0], xmm12
0000792ccedd0ab5  vmovaps [rsp+0xC0], xmm13
0000792ccedd0abe  vmovaps [rsp+0xD0], xmm14
0000792ccedd0ac7  vmovaps [rsp+0xE0], xmm15
0000792ccedd0ad0  sub rsp, 0x30
0000792ccedd0ad4  movaps [rsp], xmm1
0000792ccedd0ad8  movaps [rsp+0x10], xmm14
0000792ccedd0ade  movaps [rsp+0x20], xmm10
0000792ccedd0ae4  lea rdi, [rsp]
0000792ccedd0ae8  mov esi, 0x00
0000792ccedd0aed  mov rax, 0x5AEE2D541530
0000792ccedd0af7  call rax
0000792ccedd0af9  movaps xmm1, [rsp]
0000792ccedd0afd  add rsp, 0x30
0000792ccedd0b01  vmovaps xmm0, [rsp]
0000792ccedd0b06  vmovaps xmm2, [rsp+0x10]
0000792ccedd0b0c  vmovaps xmm3, [rsp+0x20]
0000792ccedd0b12  vmovaps xmm4, [rsp+0x30]
0000792ccedd0b18  vmovaps xmm5, [rsp+0x40]
0000792ccedd0b1e  vmovaps xmm6, [rsp+0x50]
0000792ccedd0b24  vmovaps xmm7, [rsp+0x60]
0000792ccedd0b2a  vmovaps xmm8, [rsp+0x70]
0000792ccedd0b30  vmovaps xmm9, [rsp+0x80]
0000792ccedd0b39  vmovaps xmm10, [rsp+0x90]
0000792ccedd0b42  vmovaps xmm11, [rsp+0xA0]
0000792ccedd0b4b  vmovaps xmm12, [rsp+0xB0]
0000792ccedd0b54  vmovaps xmm13, [rsp+0xC0]
0000792ccedd0b5d  vmovaps xmm14, [rsp+0xD0]
0000792ccedd0b66  vmovaps xmm15, [rsp+0xE0]
0000792ccedd0b6f  add rsp, 0xF0
0000792ccedd0b76  pop r11
0000792ccedd0b78  pop r10
0000792ccedd0b7a  pop r9
0000792ccedd0b7c  pop r8
0000792ccedd0b7e  pop rsi
0000792ccedd0b7f  pop rdi
0000792ccedd0b80  pop rdx
0000792ccedd0b81  pop rcx
0000792ccedd0b82  pop rax
0000792ccedd0b83  add rsp, 0x08
0000792ccedd0b87  jmp 0x0000792CCEDCF631
0000792ccedd0b8c  sub rsp, 0x08
0000792ccedd0b90  push rax
0000792ccedd0b91  push rcx
0000792ccedd0b92  push rdx
0000792ccedd0b93  push rdi
0000792ccedd0b94  push rsi
0000792ccedd0b95  push r8
0000792ccedd0b97  push r9
0000792ccedd0b99  push r10
0000792ccedd0b9b  push r11
0000792ccedd0b9d  sub rsp, 0xF0
0000792ccedd0ba4  vmovaps [rsp], xmm0
0000792ccedd0ba9  vmovaps [rsp+0x10], xmm1
0000792ccedd0baf  vmovaps [rsp+0x20], xmm2
0000792ccedd0bb5  vmovaps [rsp+0x30], xmm3
0000792ccedd0bbb  vmovaps [rsp+0x40], xmm4
0000792ccedd0bc1  vmovaps [rsp+0x50], xmm5
0000792ccedd0bc7  vmovaps [rsp+0x60], xmm6
0000792ccedd0bcd  vmovaps [rsp+0x70], xmm7
0000792ccedd0bd3  vmovaps [rsp+0x80], xmm8
0000792ccedd0bdc  vmovaps [rsp+0x90], xmm9
0000792ccedd0be5  vmovaps [rsp+0xA0], xmm10
0000792ccedd0bee  vmovaps [rsp+0xB0], xmm11
0000792ccedd0bf7  vmovaps [rsp+0xC0], xmm12
0000792ccedd0c00  vmovaps [rsp+0xD0], xmm14
0000792ccedd0c09  vmovaps [rsp+0xE0], xmm15
0000792ccedd0c12  sub rsp, 0x30
0000792ccedd0c16  movaps [rsp], xmm13
0000792ccedd0c1b  movaps [rsp+0x10], xmm14
0000792ccedd0c21  movaps [rsp+0x20], xmm2
0000792ccedd0c26  lea rdi, [rsp]
0000792ccedd0c2a  mov esi, 0x00
0000792ccedd0c2f  mov rax, 0x5AEE2D541530
0000792ccedd0c39  call rax
0000792ccedd0c3b  movaps xmm13, [rsp]
0000792ccedd0c40  add rsp, 0x30
0000792ccedd0c44  vmovaps xmm0, [rsp]
0000792ccedd0c49  vmovaps xmm1, [rsp+0x10]
0000792ccedd0c4f  vmovaps xmm2, [rsp+0x20]
0000792ccedd0c55  vmovaps xmm3, [rsp+0x30]
0000792ccedd0c5b  vmovaps xmm4, [rsp+0x40]
0000792ccedd0c61  vmovaps xmm5, [rsp+0x50]
0000792ccedd0c67  vmovaps xmm6, [rsp+0x60]
0000792ccedd0c6d  vmovaps xmm7, [rsp+0x70]
0000792ccedd0c73  vmovaps xmm8, [rsp+0x80]
0000792ccedd0c7c  vmovaps xmm9, [rsp+0x90]
0000792ccedd0c85  vmovaps xmm10, [rsp+0xA0]
0000792ccedd0c8e  vmovaps xmm11, [rsp+0xB0]
0000792ccedd0c97  vmovaps xmm12, [rsp+0xC0]
0000792ccedd0ca0  vmovaps xmm14, [rsp+0xD0]
0000792ccedd0ca9  vmovaps xmm15, [rsp+0xE0]
0000792ccedd0cb2  add rsp, 0xF0
0000792ccedd0cb9  pop r11
0000792ccedd0cbb  pop r10
0000792ccedd0cbd  pop r9
0000792ccedd0cbf  pop r8
0000792ccedd0cc1  pop rsi
0000792ccedd0cc2  pop rdi
0000792ccedd0cc3  pop rdx
0000792ccedd0cc4  pop rcx
0000792ccedd0cc5  pop rax
0000792ccedd0cc6  add rsp, 0x08
0000792ccedd0cca  jmp 0x0000792CCEDCF64C
0000792ccedd0ccf  sub rsp, 0x08
0000792ccedd0cd3  push rax
0000792ccedd0cd4  push rcx
0000792ccedd0cd5  push rdx
0000792ccedd0cd6  push rdi
0000792ccedd0cd7  push rsi
0000792ccedd0cd8  push r8
0000792ccedd0cda  push r9
0000792ccedd0cdc  push r10
0000792ccedd0cde  push r11
0000792ccedd0ce0  sub rsp, 0xF0
0000792ccedd0ce7  vmovaps [rsp], xmm0
0000792ccedd0cec  vmovaps [rsp+0x10], xmm2
0000792ccedd0cf2  vmovaps [rsp+0x20], xmm3
0000792ccedd0cf8  vmovaps [rsp+0x30], xmm4
0000792ccedd0cfe  vmovaps [rsp+0x40], xmm5
0000792ccedd0d04  vmovaps [rsp+0x50], xmm6
0000792ccedd0d0a  vmovaps [rsp+0x60], xmm7
0000792ccedd0d10  vmovaps [rsp+0x70], xmm8
0000792ccedd0d16  vmovaps [rsp+0x80], xmm9
0000792ccedd0d1f  vmovaps [rsp+0x90], xmm10
0000792ccedd0d28  vmovaps [rsp+0xA0], xmm11
0000792ccedd0d31  vmovaps [rsp+0xB0], xmm12
0000792ccedd0d3a  vmovaps [rsp+0xC0], xmm13
0000792ccedd0d43  vmovaps [rsp+0xD0], xmm14
0000792ccedd0d4c  vmovaps [rsp+0xE0], xmm15
0000792ccedd0d55  sub rsp, 0x30
0000792ccedd0d59  movaps [rsp], xmm1
0000792ccedd0d5d  movaps [rsp+0x10], xmm10
0000792ccedd0d63  movaps [rsp+0x20], xmm2
0000792ccedd0d68  lea rdi, [rsp]
0000792ccedd0d6c  mov esi, 0x00
0000792ccedd0d71  mov rax, 0x5AEE2D541530
0000792ccedd0d7b  call rax
0000792ccedd0d7d  movaps xmm1, [rsp]
0000792ccedd0d81  add rsp, 0x30
0000792ccedd0d85  vmovaps xmm0, [rsp]
0000792ccedd0d8a  vmovaps xmm2, [rsp+0x10]
0000792ccedd0d90  vmovaps xmm3, [rsp+0x20]
0000792ccedd0d96  vmovaps xmm4, [rsp+0x30]
0000792ccedd0d9c  vmovaps xmm5, [rsp+0x40]
0000792ccedd0da2  vmovaps xmm6, [rsp+0x50]
0000792ccedd0da8  vmovaps xmm7, [rsp+0x60]
0000792ccedd0dae  vmovaps xmm8, [rsp+0x70]
0000792ccedd0db4  vmovaps xmm9, [rsp+0x80]
0000792ccedd0dbd  vmovaps xmm10, [rsp+0x90]
0000792ccedd0dc6  vmovaps xmm11, [rsp+0xA0]
0000792ccedd0dcf  vmovaps xmm12, [rsp+0xB0]
0000792ccedd0dd8  vmovaps xmm13, [rsp+0xC0]
0000792ccedd0de1  vmovaps xmm14, [rsp+0xD0]
0000792ccedd0dea  vmovaps xmm15, [rsp+0xE0]
0000792ccedd0df3  add rsp, 0xF0
0000792ccedd0dfa  pop r11
0000792ccedd0dfc  pop r10
0000792ccedd0dfe  pop r9
0000792ccedd0e00  pop r8
0000792ccedd0e02  pop rsi
0000792ccedd0e03  pop rdi
0000792ccedd0e04  pop rdx
0000792ccedd0e05  pop rcx
0000792ccedd0e06  pop rax
0000792ccedd0e07  add rsp, 0x08
0000792ccedd0e0b  jmp 0x0000792CCEDCF6B4
0000792ccedd0e10  sub rsp, 0x08
0000792ccedd0e14  push rax
0000792ccedd0e15  push rcx
0000792ccedd0e16  push rdx
0000792ccedd0e17  push rdi
0000792ccedd0e18  push rsi
0000792ccedd0e19  push r8
0000792ccedd0e1b  push r9
0000792ccedd0e1d  push r10
0000792ccedd0e1f  push r11
0000792ccedd0e21  sub rsp, 0xF0
0000792ccedd0e28  vmovaps [rsp], xmm0
0000792ccedd0e2d  vmovaps [rsp+0x10], xmm1
0000792ccedd0e33  vmovaps [rsp+0x20], xmm2
0000792ccedd0e39  vmovaps [rsp+0x30], xmm3
0000792ccedd0e3f  vmovaps [rsp+0x40], xmm4
0000792ccedd0e45  vmovaps [rsp+0x50], xmm5
0000792ccedd0e4b  vmovaps [rsp+0x60], xmm6
0000792ccedd0e51  vmovaps [rsp+0x70], xmm7
0000792ccedd0e57  vmovaps [rsp+0x80], xmm8
0000792ccedd0e60  vmovaps [rsp+0x90], xmm9
0000792ccedd0e69  vmovaps [rsp+0xA0], xmm10
0000792ccedd0e72  vmovaps [rsp+0xB0], xmm11
0000792ccedd0e7b  vmovaps [rsp+0xC0], xmm12
0000792ccedd0e84  vmovaps [rsp+0xD0], xmm13
0000792ccedd0e8d  vmovaps [rsp+0xE0], xmm14
0000792ccedd0e96  sub rsp, 0x30
0000792ccedd0e9a  movaps [rsp], xmm15
0000792ccedd0e9f  movaps [rsp+0x10], xmm10
0000792ccedd0ea5  movaps [rsp+0x20], xmm2
0000792ccedd0eaa  lea rdi, [rsp]
0000792ccedd0eae  mov esi, 0x00
0000792ccedd0eb3  mov rax, 0x5AEE2D541530
0000792ccedd0ebd  call rax
0000792ccedd0ebf  movaps xmm15, [rsp]
0000792ccedd0ec4  add rsp, 0x30
0000792ccedd0ec8  vmovaps xmm0, [rsp]
0000792ccedd0ecd  vmovaps xmm1, [rsp+0x10]
0000792ccedd0ed3  vmovaps xmm2, [rsp+0x20]
0000792ccedd0ed9  vmovaps xmm3, [rsp+0x30]
0000792ccedd0edf  vmovaps xmm4, [rsp+0x40]
0000792ccedd0ee5  vmovaps xmm5, [rsp+0x50]
0000792ccedd0eeb  vmovaps xmm6, [rsp+0x60]
0000792ccedd0ef1  vmovaps xmm7, [rsp+0x70]
0000792ccedd0ef7  vmovaps xmm8, [rsp+0x80]
0000792ccedd0f00  vmovaps xmm9, [rsp+0x90]
0000792ccedd0f09  vmovaps xmm10, [rsp+0xA0]
0000792ccedd0f12  vmovaps xmm11, [rsp+0xB0]
0000792ccedd0f1b  vmovaps xmm12, [rsp+0xC0]
0000792ccedd0f24  vmovaps xmm13, [rsp+0xD0]
0000792ccedd0f2d  vmovaps xmm14, [rsp+0xE0]
0000792ccedd0f36  add rsp, 0xF0
0000792ccedd0f3d  pop r11
0000792ccedd0f3f  pop r10
0000792ccedd0f41  pop r9
0000792ccedd0f43  pop r8
0000792ccedd0f45  pop rsi
0000792ccedd0f46  pop rdi
0000792ccedd0f47  pop rdx
0000792ccedd0f48  pop rcx
0000792ccedd0f49  pop rax
0000792ccedd0f4a  add rsp, 0x08
0000792ccedd0f4e  jmp 0x0000792CCEDCF706
0000792ccedd0f53  sub rsp, 0x08
0000792ccedd0f57  push rax
0000792ccedd0f58  push rcx
0000792ccedd0f59  push rdx
0000792ccedd0f5a  push rdi
0000792ccedd0f5b  push rsi
0000792ccedd0f5c  push r8
0000792ccedd0f5e  push r9
0000792ccedd0f60  push r10
0000792ccedd0f62  push r11
0000792ccedd0f64  sub rsp, 0xF0
0000792ccedd0f6b  vmovaps [rsp], xmm0
0000792ccedd0f70  vmovaps [rsp+0x10], xmm2
0000792ccedd0f76  vmovaps [rsp+0x20], xmm3
0000792ccedd0f7c  vmovaps [rsp+0x30], xmm4
0000792ccedd0f82  vmovaps [rsp+0x40], xmm5
0000792ccedd0f88  vmovaps [rsp+0x50], xmm6
0000792ccedd0f8e  vmovaps [rsp+0x60], xmm7
0000792ccedd0f94  vmovaps [rsp+0x70], xmm8
0000792ccedd0f9a  vmovaps [rsp+0x80], xmm9
0000792ccedd0fa3  vmovaps [rsp+0x90], xmm10
0000792ccedd0fac  vmovaps [rsp+0xA0], xmm11
0000792ccedd0fb5  vmovaps [rsp+0xB0], xmm12
0000792ccedd0fbe  vmovaps [rsp+0xC0], xmm13
0000792ccedd0fc7  vmovaps [rsp+0xD0], xmm14
0000792ccedd0fd0  vmovaps [rsp+0xE0], xmm15
0000792ccedd0fd9  sub rsp, 0x30
0000792ccedd0fdd  movaps [rsp], xmm1
0000792ccedd0fe1  movaps [rsp+0x10], xmm10
0000792ccedd0fe7  movaps [rsp+0x20], xmm12
0000792ccedd0fed  lea rdi, [rsp]
0000792ccedd0ff1  mov esi, 0x00
0000792ccedd0ff6  mov rax, 0x5AEE2D541530
0000792ccedd1000  call rax
0000792ccedd1002  movaps xmm1, [rsp]
0000792ccedd1006  add rsp, 0x30
0000792ccedd100a  vmovaps xmm0, [rsp]
0000792ccedd100f  vmovaps xmm2, [rsp+0x10]
0000792ccedd1015  vmovaps xmm3, [rsp+0x20]
0000792ccedd101b  vmovaps xmm4, [rsp+0x30]
0000792ccedd1021  vmovaps xmm5, [rsp+0x40]
0000792ccedd1027  vmovaps xmm6, [rsp+0x50]
0000792ccedd102d  vmovaps xmm7, [rsp+0x60]
0000792ccedd1033  vmovaps xmm8, [rsp+0x70]
0000792ccedd1039  vmovaps xmm9, [rsp+0x80]
0000792ccedd1042  vmovaps xmm10, [rsp+0x90]
0000792ccedd104b  vmovaps xmm11, [rsp+0xA0]
0000792ccedd1054  vmovaps xmm12, [rsp+0xB0]
0000792ccedd105d  vmovaps xmm13, [rsp+0xC0]
0000792ccedd1066  vmovaps xmm14, [rsp+0xD0]
0000792ccedd106f  vmovaps xmm15, [rsp+0xE0]
0000792ccedd1078  add rsp, 0xF0
0000792ccedd107f  pop r11
0000792ccedd1081  pop r10
0000792ccedd1083  pop r9
0000792ccedd1085  pop r8
0000792ccedd1087  pop rsi
0000792ccedd1088  pop rdi
0000792ccedd1089  pop rdx
0000792ccedd108a  pop rcx
0000792ccedd108b  pop rax
0000792ccedd108c  add rsp, 0x08
0000792ccedd1090  jmp 0x0000792CCEDCF732
0000792ccedd1095  sub rsp, 0x08
0000792ccedd1099  push rax
0000792ccedd109a  push rcx
0000792ccedd109b  push rdx
0000792ccedd109c  push rdi
0000792ccedd109d  push rsi
0000792ccedd109e  push r8
0000792ccedd10a0  push r9
0000792ccedd10a2  push r10
0000792ccedd10a4  push r11
0000792ccedd10a6  sub rsp, 0xF0
0000792ccedd10ad  vmovaps [rsp], xmm0
0000792ccedd10b2  vmovaps [rsp+0x10], xmm1
0000792ccedd10b8  vmovaps [rsp+0x20], xmm2
0000792ccedd10be  vmovaps [rsp+0x30], xmm3
0000792ccedd10c4  vmovaps [rsp+0x40], xmm4
0000792ccedd10ca  vmovaps [rsp+0x50], xmm5
0000792ccedd10d0  vmovaps [rsp+0x60], xmm6
0000792ccedd10d6  vmovaps [rsp+0x70], xmm7
0000792ccedd10dc  vmovaps [rsp+0x80], xmm8
0000792ccedd10e5  vmovaps [rsp+0x90], xmm9
0000792ccedd10ee  vmovaps [rsp+0xA0], xmm10
0000792ccedd10f7  vmovaps [rsp+0xB0], xmm11
0000792ccedd1100  vmovaps [rsp+0xC0], xmm12
0000792ccedd1109  vmovaps [rsp+0xD0], xmm13
0000792ccedd1112  vmovaps [rsp+0xE0], xmm14
0000792ccedd111b  sub rsp, 0x30
0000792ccedd111f  movaps [rsp], xmm15
0000792ccedd1124  movaps [rsp+0x10], xmm10
0000792ccedd112a  movaps [rsp+0x20], xmm12
0000792ccedd1130  lea rdi, [rsp]
0000792ccedd1134  mov esi, 0x00
0000792ccedd1139  mov rax, 0x5AEE2D541530
0000792ccedd1143  call rax
0000792ccedd1145  movaps xmm15, [rsp]
0000792ccedd114a  add rsp, 0x30
0000792ccedd114e  vmovaps xmm0, [rsp]
0000792ccedd1153  vmovaps xmm1, [rsp+0x10]
0000792ccedd1159  vmovaps xmm2, [rsp+0x20]
0000792ccedd115f  vmovaps xmm3, [rsp+0x30]
0000792ccedd1165  vmovaps xmm4, [rsp+0x40]
0000792ccedd116b  vmovaps xmm5, [rsp+0x50]
0000792ccedd1171  vmovaps xmm6, [rsp+0x60]
0000792ccedd1177  vmovaps xmm7, [rsp+0x70]
0000792ccedd117d  vmovaps xmm8, [rsp+0x80]
0000792ccedd1186  vmovaps xmm9, [rsp+0x90]
0000792ccedd118f  vmovaps xmm10, [rsp+0xA0]
0000792ccedd1198  vmovaps xmm11, [rsp+0xB0]
0000792ccedd11a1  vmovaps xmm12, [rsp+0xC0]
0000792ccedd11aa  vmovaps xmm13, [rsp+0xD0]
0000792ccedd11b3  vmovaps xmm14, [rsp+0xE0]
0000792ccedd11bc  add rsp, 0xF0
0000792ccedd11c3  pop r11
0000792ccedd11c5  pop r10
0000792ccedd11c7  pop r9
0000792ccedd11c9  pop r8
0000792ccedd11cb  pop rsi
0000792ccedd11cc  pop rdi
0000792ccedd11cd  pop rdx
0000792ccedd11ce  pop rcx
0000792ccedd11cf  pop rax
0000792ccedd11d0  add rsp, 0x08
0000792ccedd11d4  jmp 0x0000792CCEDCF75E
0000792ccedd11d9  call 0x0000792CCEBFF430
0000792ccedd11de  jmp 0x0000792CCEDCF7EE
0000792ccedd11e3  call 0x0000792CCEBFF430
0000792ccedd11e8  jmp 0x0000792CCEDCF801
0000792ccedd11ed  sub rsp, 0x08
0000792ccedd11f1  push rax
0000792ccedd11f2  push rcx
0000792ccedd11f3  push rdx
0000792ccedd11f4  push rdi
0000792ccedd11f5  push rsi
0000792ccedd11f6  push r8
0000792ccedd11f8  push r9
0000792ccedd11fa  push r10
0000792ccedd11fc  push r11
0000792ccedd11fe  sub rsp, 0xF0
0000792ccedd1205  vmovaps [rsp], xmm0
0000792ccedd120a  vmovaps [rsp+0x10], xmm2
0000792ccedd1210  vmovaps [rsp+0x20], xmm3
0000792ccedd1216  vmovaps [rsp+0x30], xmm4
0000792ccedd121c  vmovaps [rsp+0x40], xmm5
0000792ccedd1222  vmovaps [rsp+0x50], xmm6
0000792ccedd1228  vmovaps [rsp+0x60], xmm7
0000792ccedd122e  vmovaps [rsp+0x70], xmm8
0000792ccedd1234  vmovaps [rsp+0x80], xmm9
0000792ccedd123d  vmovaps [rsp+0x90], xmm10
0000792ccedd1246  vmovaps [rsp+0xA0], xmm11
0000792ccedd124f  vmovaps [rsp+0xB0], xmm12
0000792ccedd1258  vmovaps [rsp+0xC0], xmm13
0000792ccedd1261  vmovaps [rsp+0xD0], xmm14
0000792ccedd126a  vmovaps [rsp+0xE0], xmm15
0000792ccedd1273  sub rsp, 0x30
0000792ccedd1277  movaps [rsp], xmm1
0000792ccedd127b  movaps [rsp+0x10], xmm13
0000792ccedd1281  movaps [rsp+0x20], xmm2
0000792ccedd1286  lea rdi, [rsp]
0000792ccedd128a  mov esi, 0x00
0000792ccedd128f  mov rax, 0x5AEE2D541530
0000792ccedd1299  call rax
0000792ccedd129b  movaps xmm1, [rsp]
0000792ccedd129f  add rsp, 0x30
0000792ccedd12a3  vmovaps xmm0, [rsp]
0000792ccedd12a8  vmovaps xmm2, [rsp+0x10]
0000792ccedd12ae  vmovaps xmm3, [rsp+0x20]
0000792ccedd12b4  vmovaps xmm4, [rsp+0x30]
0000792ccedd12ba  vmovaps xmm5, [rsp+0x40]
0000792ccedd12c0  vmovaps xmm6, [rsp+0x50]
0000792ccedd12c6  vmovaps xmm7, [rsp+0x60]
0000792ccedd12cc  vmovaps xmm8, [rsp+0x70]
0000792ccedd12d2  vmovaps xmm9, [rsp+0x80]
0000792ccedd12db  vmovaps xmm10, [rsp+0x90]
0000792ccedd12e4  vmovaps xmm11, [rsp+0xA0]
0000792ccedd12ed  vmovaps xmm12, [rsp+0xB0]
0000792ccedd12f6  vmovaps xmm13, [rsp+0xC0]
0000792ccedd12ff  vmovaps xmm14, [rsp+0xD0]
0000792ccedd1308  vmovaps xmm15, [rsp+0xE0]
0000792ccedd1311  add rsp, 0xF0
0000792ccedd1318  pop r11
0000792ccedd131a  pop r10
0000792ccedd131c  pop r9
0000792ccedd131e  pop r8
0000792ccedd1320  pop rsi
0000792ccedd1321  pop rdi
0000792ccedd1322  pop rdx
0000792ccedd1323  pop rcx
0000792ccedd1324  pop rax
0000792ccedd1325  add rsp, 0x08
0000792ccedd1329  jmp 0x0000792CCEDCF82C
0000792ccedd132e  call 0x0000792CCEC0E760
0000792ccedd1333  jmp 0x0000792CCEDCF839
0000792ccedd1338  sub rsp, 0x08
0000792ccedd133c  push rax
0000792ccedd133d  push rcx
0000792ccedd133e  push rdx
0000792ccedd133f  push rdi
0000792ccedd1340  push rsi
0000792ccedd1341  push r8
0000792ccedd1343  push r9
0000792ccedd1345  push r10
0000792ccedd1347  push r11
0000792ccedd1349  sub rsp, 0xF0
0000792ccedd1350  vmovaps [rsp], xmm0
0000792ccedd1355  vmovaps [rsp+0x10], xmm1
0000792ccedd135b  vmovaps [rsp+0x20], xmm2
0000792ccedd1361  vmovaps [rsp+0x30], xmm3
0000792ccedd1367  vmovaps [rsp+0x40], xmm4
0000792ccedd136d  vmovaps [rsp+0x50], xmm5
0000792ccedd1373  vmovaps [rsp+0x60], xmm6
0000792ccedd1379  vmovaps [rsp+0x70], xmm7
0000792ccedd137f  vmovaps [rsp+0x80], xmm8
0000792ccedd1388  vmovaps [rsp+0x90], xmm9
0000792ccedd1391  vmovaps [rsp+0xA0], xmm10
0000792ccedd139a  vmovaps [rsp+0xB0], xmm11
0000792ccedd13a3  vmovaps [rsp+0xC0], xmm12
0000792ccedd13ac  vmovaps [rsp+0xD0], xmm14
0000792ccedd13b5  vmovaps [rsp+0xE0], xmm15
0000792ccedd13be  sub rsp, 0x30
0000792ccedd13c2  movaps [rsp], xmm13
0000792ccedd13c7  movaps [rsp+0x10], xmm2
0000792ccedd13cc  movaps [rsp+0x20], xmm1
0000792ccedd13d1  lea rdi, [rsp]
0000792ccedd13d5  mov esi, 0x00
0000792ccedd13da  mov rax, 0x5AEE2D541530
0000792ccedd13e4  call rax
0000792ccedd13e6  movaps xmm13, [rsp]
0000792ccedd13eb  add rsp, 0x30
0000792ccedd13ef  vmovaps xmm0, [rsp]
0000792ccedd13f4  vmovaps xmm1, [rsp+0x10]
0000792ccedd13fa  vmovaps xmm2, [rsp+0x20]
0000792ccedd1400  vmovaps xmm3, [rsp+0x30]
0000792ccedd1406  vmovaps xmm4, [rsp+0x40]
0000792ccedd140c  vmovaps xmm5, [rsp+0x50]
0000792ccedd1412  vmovaps xmm6, [rsp+0x60]
0000792ccedd1418  vmovaps xmm7, [rsp+0x70]
0000792ccedd141e  vmovaps xmm8, [rsp+0x80]
0000792ccedd1427  vmovaps xmm9, [rsp+0x90]
0000792ccedd1430  vmovaps xmm10, [rsp+0xA0]
0000792ccedd1439  vmovaps xmm11, [rsp+0xB0]
0000792ccedd1442  vmovaps xmm12, [rsp+0xC0]
0000792ccedd144b  vmovaps xmm14, [rsp+0xD0]
0000792ccedd1454  vmovaps xmm15, [rsp+0xE0]
0000792ccedd145d  add rsp, 0xF0
0000792ccedd1464  pop r11
0000792ccedd1466  pop r10
0000792ccedd1468  pop r9
0000792ccedd146a  pop r8
0000792ccedd146c  pop rsi
0000792ccedd146d  pop rdi
0000792ccedd146e  pop rdx
0000792ccedd146f  pop rcx
0000792ccedd1470  pop rax
0000792ccedd1471  add rsp, 0x08
0000792ccedd1475  jmp 0x0000792CCEDCF878
0000792ccedd147a  sub rsp, 0x08
0000792ccedd147e  push rax
0000792ccedd147f  push rcx
0000792ccedd1480  push rdx
0000792ccedd1481  push rdi
0000792ccedd1482  push rsi
0000792ccedd1483  push r8
0000792ccedd1485  push r9
0000792ccedd1487  push r10
0000792ccedd1489  push r11
0000792ccedd148b  sub rsp, 0xF0
0000792ccedd1492  vmovaps [rsp], xmm0
0000792ccedd1497  vmovaps [rsp+0x10], xmm2
0000792ccedd149d  vmovaps [rsp+0x20], xmm3
0000792ccedd14a3  vmovaps [rsp+0x30], xmm4
0000792ccedd14a9  vmovaps [rsp+0x40], xmm5
0000792ccedd14af  vmovaps [rsp+0x50], xmm6
0000792ccedd14b5  vmovaps [rsp+0x60], xmm7
0000792ccedd14bb  vmovaps [rsp+0x70], xmm8
0000792ccedd14c1  vmovaps [rsp+0x80], xmm9
0000792ccedd14ca  vmovaps [rsp+0x90], xmm10
0000792ccedd14d3  vmovaps [rsp+0xA0], xmm11
0000792ccedd14dc  vmovaps [rsp+0xB0], xmm12
0000792ccedd14e5  vmovaps [rsp+0xC0], xmm13
0000792ccedd14ee  vmovaps [rsp+0xD0], xmm14
0000792ccedd14f7  vmovaps [rsp+0xE0], xmm15
0000792ccedd1500  sub rsp, 0x30
0000792ccedd1504  movaps [rsp], xmm1
0000792ccedd1508  movaps [rsp+0x10], xmm15
0000792ccedd150e  movaps [rsp+0x20], xmm2
0000792ccedd1513  lea rdi, [rsp]
0000792ccedd1517  mov esi, 0x00
0000792ccedd151c  mov rax, 0x5AEE2D541530
0000792ccedd1526  call rax
0000792ccedd1528  movaps xmm1, [rsp]
0000792ccedd152c  add rsp, 0x30
0000792ccedd1530  vmovaps xmm0, [rsp]
0000792ccedd1535  vmovaps xmm2, [rsp+0x10]
0000792ccedd153b  vmovaps xmm3, [rsp+0x20]
0000792ccedd1541  vmovaps xmm4, [rsp+0x30]
0000792ccedd1547  vmovaps xmm5, [rsp+0x40]
0000792ccedd154d  vmovaps xmm6, [rsp+0x50]
0000792ccedd1553  vmovaps xmm7, [rsp+0x60]
0000792ccedd1559  vmovaps xmm8, [rsp+0x70]
0000792ccedd155f  vmovaps xmm9, [rsp+0x80]
0000792ccedd1568  vmovaps xmm10, [rsp+0x90]
0000792ccedd1571  vmovaps xmm11, [rsp+0xA0]
0000792ccedd157a  vmovaps xmm12, [rsp+0xB0]
0000792ccedd1583  vmovaps xmm13, [rsp+0xC0]
0000792ccedd158c  vmovaps xmm14, [rsp+0xD0]
0000792ccedd1595  vmovaps xmm15, [rsp+0xE0]
0000792ccedd159e  add rsp, 0xF0
0000792ccedd15a5  pop r11
0000792ccedd15a7  pop r10
0000792ccedd15a9  pop r9
0000792ccedd15ab  pop r8
0000792ccedd15ad  pop rsi
0000792ccedd15ae  pop rdi
0000792ccedd15af  pop rdx
0000792ccedd15b0  pop rcx
0000792ccedd15b1  pop rax
0000792ccedd15b2  add rsp, 0x08
0000792ccedd15b6  jmp 0x0000792CCEDCF8AC
0000792ccedd15bb  sub rsp, 0x08
0000792ccedd15bf  push rax
0000792ccedd15c0  push rcx
0000792ccedd15c1  push rdx
0000792ccedd15c2  push rdi
0000792ccedd15c3  push rsi
0000792ccedd15c4  push r8
0000792ccedd15c6  push r9
0000792ccedd15c8  push r10
0000792ccedd15ca  push r11
0000792ccedd15cc  sub rsp, 0xF0
0000792ccedd15d3  vmovaps [rsp], xmm0
0000792ccedd15d8  vmovaps [rsp+0x10], xmm1
0000792ccedd15de  vmovaps [rsp+0x20], xmm2
0000792ccedd15e4  vmovaps [rsp+0x30], xmm3
0000792ccedd15ea  vmovaps [rsp+0x40], xmm4
0000792ccedd15f0  vmovaps [rsp+0x50], xmm5
0000792ccedd15f6  vmovaps [rsp+0x60], xmm6
0000792ccedd15fc  vmovaps [rsp+0x70], xmm7
0000792ccedd1602  vmovaps [rsp+0x80], xmm8
0000792ccedd160b  vmovaps [rsp+0x90], xmm9
0000792ccedd1614  vmovaps [rsp+0xA0], xmm10
0000792ccedd161d  vmovaps [rsp+0xB0], xmm11
0000792ccedd1626  vmovaps [rsp+0xC0], xmm12
0000792ccedd162f  vmovaps [rsp+0xD0], xmm13
0000792ccedd1638  vmovaps [rsp+0xE0], xmm15
0000792ccedd1641  sub rsp, 0x30
0000792ccedd1645  movaps [rsp], xmm14
0000792ccedd164a  movaps [rsp+0x10], xmm2
0000792ccedd164f  movaps [rsp+0x20], xmm15
0000792ccedd1655  lea rdi, [rsp]
0000792ccedd1659  mov esi, 0x00
0000792ccedd165e  mov rax, 0x5AEE2D541530
0000792ccedd1668  call rax
0000792ccedd166a  movaps xmm14, [rsp]
0000792ccedd166f  add rsp, 0x30
0000792ccedd1673  vmovaps xmm0, [rsp]
0000792ccedd1678  vmovaps xmm1, [rsp+0x10]
0000792ccedd167e  vmovaps xmm2, [rsp+0x20]
0000792ccedd1684  vmovaps xmm3, [rsp+0x30]
0000792ccedd168a  vmovaps xmm4, [rsp+0x40]
0000792ccedd1690  vmovaps xmm5, [rsp+0x50]
0000792ccedd1696  vmovaps xmm6, [rsp+0x60]
0000792ccedd169c  vmovaps xmm7, [rsp+0x70]
0000792ccedd16a2  vmovaps xmm8, [rsp+0x80]
0000792ccedd16ab  vmovaps xmm9, [rsp+0x90]
0000792ccedd16b4  vmovaps xmm10, [rsp+0xA0]
0000792ccedd16bd  vmovaps xmm11, [rsp+0xB0]
0000792ccedd16c6  vmovaps xmm12, [rsp+0xC0]
0000792ccedd16cf  vmovaps xmm13, [rsp+0xD0]
0000792ccedd16d8  vmovaps xmm15, [rsp+0xE0]
0000792ccedd16e1  add rsp, 0xF0
0000792ccedd16e8  pop r11
0000792ccedd16ea  pop r10
0000792ccedd16ec  pop r9
0000792ccedd16ee  pop r8
0000792ccedd16f0  pop rsi
0000792ccedd16f1  pop rdi
0000792ccedd16f2  pop rdx
0000792ccedd16f3  pop rcx
0000792ccedd16f4  pop rax
0000792ccedd16f5  add rsp, 0x08
0000792ccedd16f9  jmp 0x0000792CCEDCF8E7
0000792ccedd16fe  sub rsp, 0x08
0000792ccedd1702  push rax
0000792ccedd1703  push rcx
0000792ccedd1704  push rdx
0000792ccedd1705  push rdi
0000792ccedd1706  push rsi
0000792ccedd1707  push r8
0000792ccedd1709  push r9
0000792ccedd170b  push r10
0000792ccedd170d  push r11
0000792ccedd170f  sub rsp, 0xF0
0000792ccedd1716  vmovaps [rsp], xmm0
0000792ccedd171b  vmovaps [rsp+0x10], xmm1
0000792ccedd1721  vmovaps [rsp+0x20], xmm2
0000792ccedd1727  vmovaps [rsp+0x30], xmm3
0000792ccedd172d  vmovaps [rsp+0x40], xmm4
0000792ccedd1733  vmovaps [rsp+0x50], xmm5
0000792ccedd1739  vmovaps [rsp+0x60], xmm6
0000792ccedd173f  vmovaps [rsp+0x70], xmm7
0000792ccedd1745  vmovaps [rsp+0x80], xmm8
0000792ccedd174e  vmovaps [rsp+0x90], xmm9
0000792ccedd1757  vmovaps [rsp+0xA0], xmm10
0000792ccedd1760  vmovaps [rsp+0xB0], xmm11
0000792ccedd1769  vmovaps [rsp+0xC0], xmm12
0000792ccedd1772  vmovaps [rsp+0xD0], xmm13
0000792ccedd177b  vmovaps [rsp+0xE0], xmm14
0000792ccedd1784  sub rsp, 0x30
0000792ccedd1788  movaps [rsp], xmm15
0000792ccedd178d  movaps [rsp+0x10], xmm2
0000792ccedd1792  movaps [rsp+0x20], xmm1
0000792ccedd1797  lea rdi, [rsp]
0000792ccedd179b  mov esi, 0x00
0000792ccedd17a0  mov rax, 0x5AEE2D541530
0000792ccedd17aa  call rax
0000792ccedd17ac  movaps xmm15, [rsp]
0000792ccedd17b1  add rsp, 0x30
0000792ccedd17b5  vmovaps xmm0, [rsp]
0000792ccedd17ba  vmovaps xmm1, [rsp+0x10]
0000792ccedd17c0  vmovaps xmm2, [rsp+0x20]
0000792ccedd17c6  vmovaps xmm3, [rsp+0x30]
0000792ccedd17cc  vmovaps xmm4, [rsp+0x40]
0000792ccedd17d2  vmovaps xmm5, [rsp+0x50]
0000792ccedd17d8  vmovaps xmm6, [rsp+0x60]
0000792ccedd17de  vmovaps xmm7, [rsp+0x70]
0000792ccedd17e4  vmovaps xmm8, [rsp+0x80]
0000792ccedd17ed  vmovaps xmm9, [rsp+0x90]
0000792ccedd17f6  vmovaps xmm10, [rsp+0xA0]
0000792ccedd17ff  vmovaps xmm11, [rsp+0xB0]
0000792ccedd1808  vmovaps xmm12, [rsp+0xC0]
0000792ccedd1811  vmovaps xmm13, [rsp+0xD0]
0000792ccedd181a  vmovaps xmm14, [rsp+0xE0]
0000792ccedd1823  add rsp, 0xF0
0000792ccedd182a  pop r11
0000792ccedd182c  pop r10
0000792ccedd182e  pop r9
0000792ccedd1830  pop r8
0000792ccedd1832  pop rsi
0000792ccedd1833  pop rdi
0000792ccedd1834  pop rdx
0000792ccedd1835  pop rcx
0000792ccedd1836  pop rax
0000792ccedd1837  add rsp, 0x08
0000792ccedd183b  jmp 0x0000792CCEDCF923
0000792ccedd1840  call 0x0000792CCEBFF430
0000792ccedd1845  jmp 0x0000792CCEDCF930
0000792ccedd184a  sub rsp, 0x08
0000792ccedd184e  push rax
0000792ccedd184f  push rcx
0000792ccedd1850  push rdx
0000792ccedd1851  push rdi
0000792ccedd1852  push rsi
0000792ccedd1853  push r8
0000792ccedd1855  push r9
0000792ccedd1857  push r10
0000792ccedd1859  push r11
0000792ccedd185b  sub rsp, 0xF0
0000792ccedd1862  vmovaps [rsp], xmm0
0000792ccedd1867  vmovaps [rsp+0x10], xmm1
0000792ccedd186d  vmovaps [rsp+0x20], xmm3
0000792ccedd1873  vmovaps [rsp+0x30], xmm4
0000792ccedd1879  vmovaps [rsp+0x40], xmm5
0000792ccedd187f  vmovaps [rsp+0x50], xmm6
0000792ccedd1885  vmovaps [rsp+0x60], xmm7
0000792ccedd188b  vmovaps [rsp+0x70], xmm8
0000792ccedd1891  vmovaps [rsp+0x80], xmm9
0000792ccedd189a  vmovaps [rsp+0x90], xmm10
0000792ccedd18a3  vmovaps [rsp+0xA0], xmm11
0000792ccedd18ac  vmovaps [rsp+0xB0], xmm12
0000792ccedd18b5  vmovaps [rsp+0xC0], xmm13
0000792ccedd18be  vmovaps [rsp+0xD0], xmm14
0000792ccedd18c7  vmovaps [rsp+0xE0], xmm15
0000792ccedd18d0  sub rsp, 0x30
0000792ccedd18d4  movaps [rsp], xmm2
0000792ccedd18d8  movaps [rsp+0x10], xmm1
0000792ccedd18dd  movaps [rsp+0x20], xmm14
0000792ccedd18e3  lea rdi, [rsp]
0000792ccedd18e7  mov esi, 0x00
0000792ccedd18ec  mov rax, 0x5AEE2D541530
0000792ccedd18f6  call rax
0000792ccedd18f8  movaps xmm2, [rsp]
0000792ccedd18fc  add rsp, 0x30
0000792ccedd1900  vmovaps xmm0, [rsp]
0000792ccedd1905  vmovaps xmm1, [rsp+0x10]
0000792ccedd190b  vmovaps xmm3, [rsp+0x20]
0000792ccedd1911  vmovaps xmm4, [rsp+0x30]
0000792ccedd1917  vmovaps xmm5, [rsp+0x40]
0000792ccedd191d  vmovaps xmm6, [rsp+0x50]
0000792ccedd1923  vmovaps xmm7, [rsp+0x60]
0000792ccedd1929  vmovaps xmm8, [rsp+0x70]
0000792ccedd192f  vmovaps xmm9, [rsp+0x80]
0000792ccedd1938  vmovaps xmm10, [rsp+0x90]
0000792ccedd1941  vmovaps xmm11, [rsp+0xA0]
0000792ccedd194a  vmovaps xmm12, [rsp+0xB0]
0000792ccedd1953  vmovaps xmm13, [rsp+0xC0]
0000792ccedd195c  vmovaps xmm14, [rsp+0xD0]
0000792ccedd1965  vmovaps xmm15, [rsp+0xE0]
0000792ccedd196e  add rsp, 0xF0
0000792ccedd1975  pop r11
0000792ccedd1977  pop r10
0000792ccedd1979  pop r9
0000792ccedd197b  pop r8
0000792ccedd197d  pop rsi
0000792ccedd197e  pop rdi
0000792ccedd197f  pop rdx
0000792ccedd1980  pop rcx
0000792ccedd1981  pop rax
0000792ccedd1982  add rsp, 0x08
0000792ccedd1986  jmp 0x0000792CCEDCF96D
0000792ccedd198b  sub rsp, 0x08
0000792ccedd198f  push rax
0000792ccedd1990  push rcx
0000792ccedd1991  push rdx
0000792ccedd1992  push rdi
0000792ccedd1993  push rsi
0000792ccedd1994  push r8
0000792ccedd1996  push r9
0000792ccedd1998  push r10
0000792ccedd199a  push r11
0000792ccedd199c  sub rsp, 0xF0
0000792ccedd19a3  vmovaps [rsp], xmm0
0000792ccedd19a8  vmovaps [rsp+0x10], xmm1
0000792ccedd19ae  vmovaps [rsp+0x20], xmm2
0000792ccedd19b4  vmovaps [rsp+0x30], xmm3
0000792ccedd19ba  vmovaps [rsp+0x40], xmm4
0000792ccedd19c0  vmovaps [rsp+0x50], xmm5
0000792ccedd19c6  vmovaps [rsp+0x60], xmm6
0000792ccedd19cc  vmovaps [rsp+0x70], xmm7
0000792ccedd19d2  vmovaps [rsp+0x80], xmm8
0000792ccedd19db  vmovaps [rsp+0x90], xmm9
0000792ccedd19e4  vmovaps [rsp+0xA0], xmm10
0000792ccedd19ed  vmovaps [rsp+0xB0], xmm11
0000792ccedd19f6  vmovaps [rsp+0xC0], xmm12
0000792ccedd19ff  vmovaps [rsp+0xD0], xmm13
0000792ccedd1a08  vmovaps [rsp+0xE0], xmm14
0000792ccedd1a11  sub rsp, 0x30
0000792ccedd1a15  movaps [rsp], xmm15
0000792ccedd1a1a  movaps [rsp+0x10], xmm14
0000792ccedd1a20  movaps [rsp+0x20], xmm1
0000792ccedd1a25  lea rdi, [rsp]
0000792ccedd1a29  mov esi, 0x00
0000792ccedd1a2e  mov rax, 0x5AEE2D541530
0000792ccedd1a38  call rax
0000792ccedd1a3a  movaps xmm15, [rsp]
0000792ccedd1a3f  add rsp, 0x30
0000792ccedd1a43  vmovaps xmm0, [rsp]
0000792ccedd1a48  vmovaps xmm1, [rsp+0x10]
0000792ccedd1a4e  vmovaps xmm2, [rsp+0x20]
0000792ccedd1a54  vmovaps xmm3, [rsp+0x30]
0000792ccedd1a5a  vmovaps xmm4, [rsp+0x40]
0000792ccedd1a60  vmovaps xmm5, [rsp+0x50]
0000792ccedd1a66  vmovaps xmm6, [rsp+0x60]
0000792ccedd1a6c  vmovaps xmm7, [rsp+0x70]
0000792ccedd1a72  vmovaps xmm8, [rsp+0x80]
0000792ccedd1a7b  vmovaps xmm9, [rsp+0x90]
0000792ccedd1a84  vmovaps xmm10, [rsp+0xA0]
0000792ccedd1a8d  vmovaps xmm11, [rsp+0xB0]
0000792ccedd1a96  vmovaps xmm12, [rsp+0xC0]
0000792ccedd1a9f  vmovaps xmm13, [rsp+0xD0]
0000792ccedd1aa8  vmovaps xmm14, [rsp+0xE0]
0000792ccedd1ab1  add rsp, 0xF0
0000792ccedd1ab8  pop r11
0000792ccedd1aba  pop r10
0000792ccedd1abc  pop r9
0000792ccedd1abe  pop r8
0000792ccedd1ac0  pop rsi
0000792ccedd1ac1  pop rdi
0000792ccedd1ac2  pop rdx
0000792ccedd1ac3  pop rcx
0000792ccedd1ac4  pop rax
0000792ccedd1ac5  add rsp, 0x08
0000792ccedd1ac9  jmp 0x0000792CCEDCF9E7
0000792ccedd1ace  call 0x0000792CCEBFF430
0000792ccedd1ad3  jmp 0x0000792CCEDCF9F4
0000792ccedd1ad8  sub rsp, 0x08
0000792ccedd1adc  push rax
0000792ccedd1add  push rcx
0000792ccedd1ade  push rdx
0000792ccedd1adf  push rdi
0000792ccedd1ae0  push rsi
0000792ccedd1ae1  push r8
0000792ccedd1ae3  push r9
0000792ccedd1ae5  push r10
0000792ccedd1ae7  push r11
0000792ccedd1ae9  sub rsp, 0xF0
0000792ccedd1af0  vmovaps [rsp], xmm0
0000792ccedd1af5  vmovaps [rsp+0x10], xmm1
0000792ccedd1afb  vmovaps [rsp+0x20], xmm2
0000792ccedd1b01  vmovaps [rsp+0x30], xmm3
0000792ccedd1b07  vmovaps [rsp+0x40], xmm4
0000792ccedd1b0d  vmovaps [rsp+0x50], xmm5
0000792ccedd1b13  vmovaps [rsp+0x60], xmm6
0000792ccedd1b19  vmovaps [rsp+0x70], xmm7
0000792ccedd1b1f  vmovaps [rsp+0x80], xmm8
0000792ccedd1b28  vmovaps [rsp+0x90], xmm9
0000792ccedd1b31  vmovaps [rsp+0xA0], xmm10
0000792ccedd1b3a  vmovaps [rsp+0xB0], xmm11
0000792ccedd1b43  vmovaps [rsp+0xC0], xmm12
0000792ccedd1b4c  vmovaps [rsp+0xD0], xmm13
0000792ccedd1b55  vmovaps [rsp+0xE0], xmm15
0000792ccedd1b5e  sub rsp, 0x30
0000792ccedd1b62  movaps [rsp], xmm14
0000792ccedd1b67  movaps [rsp+0x10], xmm13
0000792ccedd1b6d  movaps [rsp+0x20], xmm1
0000792ccedd1b72  lea rdi, [rsp]
0000792ccedd1b76  mov esi, 0x00
0000792ccedd1b7b  mov rax, 0x5AEE2D541530
0000792ccedd1b85  call rax
0000792ccedd1b87  movaps xmm14, [rsp]
0000792ccedd1b8c  add rsp, 0x30
0000792ccedd1b90  vmovaps xmm0, [rsp]
0000792ccedd1b95  vmovaps xmm1, [rsp+0x10]
0000792ccedd1b9b  vmovaps xmm2, [rsp+0x20]
0000792ccedd1ba1  vmovaps xmm3, [rsp+0x30]
0000792ccedd1ba7  vmovaps xmm4, [rsp+0x40]
0000792ccedd1bad  vmovaps xmm5, [rsp+0x50]
0000792ccedd1bb3  vmovaps xmm6, [rsp+0x60]
0000792ccedd1bb9  vmovaps xmm7, [rsp+0x70]
0000792ccedd1bbf  vmovaps xmm8, [rsp+0x80]
0000792ccedd1bc8  vmovaps xmm9, [rsp+0x90]
0000792ccedd1bd1  vmovaps xmm10, [rsp+0xA0]
0000792ccedd1bda  vmovaps xmm11, [rsp+0xB0]
0000792ccedd1be3  vmovaps xmm12, [rsp+0xC0]
0000792ccedd1bec  vmovaps xmm13, [rsp+0xD0]
0000792ccedd1bf5  vmovaps xmm15, [rsp+0xE0]
0000792ccedd1bfe  add rsp, 0xF0
0000792ccedd1c05  pop r11
0000792ccedd1c07  pop r10
0000792ccedd1c09  pop r9
0000792ccedd1c0b  pop r8
0000792ccedd1c0d  pop rsi
0000792ccedd1c0e  pop rdi
0000792ccedd1c0f  pop rdx
0000792ccedd1c10  pop rcx
0000792ccedd1c11  pop rax
0000792ccedd1c12  add rsp, 0x08
0000792ccedd1c16  jmp 0x0000792CCEDCFAAF
0000792ccedd1c1b  sub rsp, 0x08
0000792ccedd1c1f  push rax
0000792ccedd1c20  push rcx
0000792ccedd1c21  push rdx
0000792ccedd1c22  push rdi
0000792ccedd1c23  push rsi
0000792ccedd1c24  push r8
0000792ccedd1c26  push r9
0000792ccedd1c28  push r10
0000792ccedd1c2a  push r11
0000792ccedd1c2c  sub rsp, 0xF0
0000792ccedd1c33  vmovaps [rsp], xmm0
0000792ccedd1c38  vmovaps [rsp+0x10], xmm1
0000792ccedd1c3e  vmovaps [rsp+0x20], xmm2
0000792ccedd1c44  vmovaps [rsp+0x30], xmm3
0000792ccedd1c4a  vmovaps [rsp+0x40], xmm4
0000792ccedd1c50  vmovaps [rsp+0x50], xmm5
0000792ccedd1c56  vmovaps [rsp+0x60], xmm6
0000792ccedd1c5c  vmovaps [rsp+0x70], xmm7
0000792ccedd1c62  vmovaps [rsp+0x80], xmm8
0000792ccedd1c6b  vmovaps [rsp+0x90], xmm9
0000792ccedd1c74  vmovaps [rsp+0xA0], xmm10
0000792ccedd1c7d  vmovaps [rsp+0xB0], xmm11
0000792ccedd1c86  vmovaps [rsp+0xC0], xmm12
0000792ccedd1c8f  vmovaps [rsp+0xD0], xmm13
0000792ccedd1c98  vmovaps [rsp+0xE0], xmm14
0000792ccedd1ca1  sub rsp, 0x30
0000792ccedd1ca5  movaps [rsp], xmm15
0000792ccedd1caa  movaps [rsp+0x10], xmm13
0000792ccedd1cb0  movaps [rsp+0x20], xmm1
0000792ccedd1cb5  lea rdi, [rsp]
0000792ccedd1cb9  mov esi, 0x00
0000792ccedd1cbe  mov rax, 0x5AEE2D541530
0000792ccedd1cc8  call rax
0000792ccedd1cca  movaps xmm15, [rsp]
0000792ccedd1ccf  add rsp, 0x30
0000792ccedd1cd3  vmovaps xmm0, [rsp]
0000792ccedd1cd8  vmovaps xmm1, [rsp+0x10]
0000792ccedd1cde  vmovaps xmm2, [rsp+0x20]
0000792ccedd1ce4  vmovaps xmm3, [rsp+0x30]
0000792ccedd1cea  vmovaps xmm4, [rsp+0x40]
0000792ccedd1cf0  vmovaps xmm5, [rsp+0x50]
0000792ccedd1cf6  vmovaps xmm6, [rsp+0x60]
0000792ccedd1cfc  vmovaps xmm7, [rsp+0x70]
0000792ccedd1d02  vmovaps xmm8, [rsp+0x80]
0000792ccedd1d0b  vmovaps xmm9, [rsp+0x90]
0000792ccedd1d14  vmovaps xmm10, [rsp+0xA0]
0000792ccedd1d1d  vmovaps xmm11, [rsp+0xB0]
0000792ccedd1d26  vmovaps xmm12, [rsp+0xC0]
0000792ccedd1d2f  vmovaps xmm13, [rsp+0xD0]
0000792ccedd1d38  vmovaps xmm14, [rsp+0xE0]
0000792ccedd1d41  add rsp, 0xF0
0000792ccedd1d48  pop r11
0000792ccedd1d4a  pop r10
0000792ccedd1d4c  pop r9
0000792ccedd1d4e  pop r8
0000792ccedd1d50  pop rsi
0000792ccedd1d51  pop rdi
0000792ccedd1d52  pop rdx
0000792ccedd1d53  pop rcx
0000792ccedd1d54  pop rax
0000792ccedd1d55  add rsp, 0x08
0000792ccedd1d59  jmp 0x0000792CCEDCFAEB
0000792ccedd1d5e  call 0x0000792CCEBFF430
0000792ccedd1d63  jmp 0x0000792CCEDCFAF8
0000792ccedd1d68  sub rsp, 0x08
0000792ccedd1d6c  push rax
0000792ccedd1d6d  push rcx
0000792ccedd1d6e  push rdx
0000792ccedd1d6f  push rdi
0000792ccedd1d70  push rsi
0000792ccedd1d71  push r8
0000792ccedd1d73  push r9
0000792ccedd1d75  push r10
0000792ccedd1d77  push r11
0000792ccedd1d79  sub rsp, 0xF0
0000792ccedd1d80  vmovaps [rsp], xmm0
0000792ccedd1d85  vmovaps [rsp+0x10], xmm1
0000792ccedd1d8b  vmovaps [rsp+0x20], xmm2
0000792ccedd1d91  vmovaps [rsp+0x30], xmm3
0000792ccedd1d97  vmovaps [rsp+0x40], xmm4
0000792ccedd1d9d  vmovaps [rsp+0x50], xmm5
0000792ccedd1da3  vmovaps [rsp+0x60], xmm6
0000792ccedd1da9  vmovaps [rsp+0x70], xmm7
0000792ccedd1daf  vmovaps [rsp+0x80], xmm8
0000792ccedd1db8  vmovaps [rsp+0x90], xmm9
0000792ccedd1dc1  vmovaps [rsp+0xA0], xmm10
0000792ccedd1dca  vmovaps [rsp+0xB0], xmm11
0000792ccedd1dd3  vmovaps [rsp+0xC0], xmm12
0000792ccedd1ddc  vmovaps [rsp+0xD0], xmm13
0000792ccedd1de5  vmovaps [rsp+0xE0], xmm15
0000792ccedd1dee  sub rsp, 0x30
0000792ccedd1df2  movaps [rsp], xmm14
0000792ccedd1df7  movaps [rsp+0x10], xmm13
0000792ccedd1dfd  movaps [rsp+0x20], xmm2
0000792ccedd1e02  lea rdi, [rsp]
0000792ccedd1e06  mov esi, 0x00
0000792ccedd1e0b  mov rax, 0x5AEE2D541530
0000792ccedd1e15  call rax
0000792ccedd1e17  movaps xmm14, [rsp]
0000792ccedd1e1c  add rsp, 0x30
0000792ccedd1e20  vmovaps xmm0, [rsp]
0000792ccedd1e25  vmovaps xmm1, [rsp+0x10]
0000792ccedd1e2b  vmovaps xmm2, [rsp+0x20]
0000792ccedd1e31  vmovaps xmm3, [rsp+0x30]
0000792ccedd1e37  vmovaps xmm4, [rsp+0x40]
0000792ccedd1e3d  vmovaps xmm5, [rsp+0x50]
0000792ccedd1e43  vmovaps xmm6, [rsp+0x60]
0000792ccedd1e49  vmovaps xmm7, [rsp+0x70]
0000792ccedd1e4f  vmovaps xmm8, [rsp+0x80]
0000792ccedd1e58  vmovaps xmm9, [rsp+0x90]
0000792ccedd1e61  vmovaps xmm10, [rsp+0xA0]
0000792ccedd1e6a  vmovaps xmm11, [rsp+0xB0]
0000792ccedd1e73  vmovaps xmm12, [rsp+0xC0]
0000792ccedd1e7c  vmovaps xmm13, [rsp+0xD0]
0000792ccedd1e85  vmovaps xmm15, [rsp+0xE0]
0000792ccedd1e8e  add rsp, 0xF0
0000792ccedd1e95  pop r11
0000792ccedd1e97  pop r10
0000792ccedd1e99  pop r9
0000792ccedd1e9b  pop r8
0000792ccedd1e9d  pop rsi
0000792ccedd1e9e  pop rdi
0000792ccedd1e9f  pop rdx
0000792ccedd1ea0  pop rcx
0000792ccedd1ea1  pop rax
0000792ccedd1ea2  add rsp, 0x08
0000792ccedd1ea6  jmp 0x0000792CCEDCFB24
0000792ccedd1eab  sub rsp, 0x08
0000792ccedd1eaf  push rax
0000792ccedd1eb0  push rcx
0000792ccedd1eb1  push rdx
0000792ccedd1eb2  push rdi
0000792ccedd1eb3  push rsi
0000792ccedd1eb4  push r8
0000792ccedd1eb6  push r9
0000792ccedd1eb8  push r10
0000792ccedd1eba  push r11
0000792ccedd1ebc  sub rsp, 0xF0
0000792ccedd1ec3  vmovaps [rsp], xmm0
0000792ccedd1ec8  vmovaps [rsp+0x10], xmm2
0000792ccedd1ece  vmovaps [rsp+0x20], xmm3
0000792ccedd1ed4  vmovaps [rsp+0x30], xmm4
0000792ccedd1eda  vmovaps [rsp+0x40], xmm5
0000792ccedd1ee0  vmovaps [rsp+0x50], xmm6
0000792ccedd1ee6  vmovaps [rsp+0x60], xmm7
0000792ccedd1eec  vmovaps [rsp+0x70], xmm8
0000792ccedd1ef2  vmovaps [rsp+0x80], xmm9
0000792ccedd1efb  vmovaps [rsp+0x90], xmm10
0000792ccedd1f04  vmovaps [rsp+0xA0], xmm11
0000792ccedd1f0d  vmovaps [rsp+0xB0], xmm12
0000792ccedd1f16  vmovaps [rsp+0xC0], xmm13
0000792ccedd1f1f  vmovaps [rsp+0xD0], xmm14
0000792ccedd1f28  vmovaps [rsp+0xE0], xmm15
0000792ccedd1f31  sub rsp, 0x30
0000792ccedd1f35  movaps [rsp], xmm1
0000792ccedd1f39  movaps [rsp+0x10], xmm13
0000792ccedd1f3f  movaps [rsp+0x20], xmm2
0000792ccedd1f44  lea rdi, [rsp]
0000792ccedd1f48  mov esi, 0x00
0000792ccedd1f4d  mov rax, 0x5AEE2D541530
0000792ccedd1f57  call rax
0000792ccedd1f59  movaps xmm1, [rsp]
0000792ccedd1f5d  add rsp, 0x30
0000792ccedd1f61  vmovaps xmm0, [rsp]
0000792ccedd1f66  vmovaps xmm2, [rsp+0x10]
0000792ccedd1f6c  vmovaps xmm3, [rsp+0x20]
0000792ccedd1f72  vmovaps xmm4, [rsp+0x30]
0000792ccedd1f78  vmovaps xmm5, [rsp+0x40]
0000792ccedd1f7e  vmovaps xmm6, [rsp+0x50]
0000792ccedd1f84  vmovaps xmm7, [rsp+0x60]
0000792ccedd1f8a  vmovaps xmm8, [rsp+0x70]
0000792ccedd1f90  vmovaps xmm9, [rsp+0x80]
0000792ccedd1f99  vmovaps xmm10, [rsp+0x90]
0000792ccedd1fa2  vmovaps xmm11, [rsp+0xA0]
0000792ccedd1fab  vmovaps xmm12, [rsp+0xB0]
0000792ccedd1fb4  vmovaps xmm13, [rsp+0xC0]
0000792ccedd1fbd  vmovaps xmm14, [rsp+0xD0]
0000792ccedd1fc6  vmovaps xmm15, [rsp+0xE0]
0000792ccedd1fcf  add rsp, 0xF0
0000792ccedd1fd6  pop r11
0000792ccedd1fd8  pop r10
0000792ccedd1fda  pop r9
0000792ccedd1fdc  pop r8
0000792ccedd1fde  pop rsi
0000792ccedd1fdf  pop rdi
0000792ccedd1fe0  pop rdx
0000792ccedd1fe1  pop rcx
0000792ccedd1fe2  pop rax
0000792ccedd1fe3  add rsp, 0x08
0000792ccedd1fe7  jmp 0x0000792CCEDCFB52
0000792ccedd1fec  sub rsp, 0x08
0000792ccedd1ff0  push rax
0000792ccedd1ff1  push rcx
0000792ccedd1ff2  push rdx
0000792ccedd1ff3  push rdi
0000792ccedd1ff4  push rsi
0000792ccedd1ff5  push r8
0000792ccedd1ff7  push r9
0000792ccedd1ff9  push r10
0000792ccedd1ffb  push r11
0000792ccedd1ffd  sub rsp, 0xF0
0000792ccedd2004  vmovaps [rsp], xmm0
0000792ccedd2009  vmovaps [rsp+0x10], xmm1
0000792ccedd200f  vmovaps [rsp+0x20], xmm3
0000792ccedd2015  vmovaps [rsp+0x30], xmm4
0000792ccedd201b  vmovaps [rsp+0x40], xmm5
0000792ccedd2021  vmovaps [rsp+0x50], xmm6
0000792ccedd2027  vmovaps [rsp+0x60], xmm7
0000792ccedd202d  vmovaps [rsp+0x70], xmm8
0000792ccedd2033  vmovaps [rsp+0x80], xmm9
0000792ccedd203c  vmovaps [rsp+0x90], xmm10
0000792ccedd2045  vmovaps [rsp+0xA0], xmm11
0000792ccedd204e  vmovaps [rsp+0xB0], xmm12
0000792ccedd2057  vmovaps [rsp+0xC0], xmm13
0000792ccedd2060  vmovaps [rsp+0xD0], xmm14
0000792ccedd2069  vmovaps [rsp+0xE0], xmm15
0000792ccedd2072  sub rsp, 0x30
0000792ccedd2076  movaps [rsp], xmm2
0000792ccedd207a  movaps [rsp+0x10], xmm1
0000792ccedd207f  movaps [rsp+0x20], xmm13
0000792ccedd2085  lea rdi, [rsp]
0000792ccedd2089  mov esi, 0x00
0000792ccedd208e  mov rax, 0x5AEE2D541530
0000792ccedd2098  call rax
0000792ccedd209a  movaps xmm2, [rsp]
0000792ccedd209e  add rsp, 0x30
0000792ccedd20a2  vmovaps xmm0, [rsp]
0000792ccedd20a7  vmovaps xmm1, [rsp+0x10]
0000792ccedd20ad  vmovaps xmm3, [rsp+0x20]
0000792ccedd20b3  vmovaps xmm4, [rsp+0x30]
0000792ccedd20b9  vmovaps xmm5, [rsp+0x40]
0000792ccedd20bf  vmovaps xmm6, [rsp+0x50]
0000792ccedd20c5  vmovaps xmm7, [rsp+0x60]
0000792ccedd20cb  vmovaps xmm8, [rsp+0x70]
0000792ccedd20d1  vmovaps xmm9, [rsp+0x80]
0000792ccedd20da  vmovaps xmm10, [rsp+0x90]
0000792ccedd20e3  vmovaps xmm11, [rsp+0xA0]
0000792ccedd20ec  vmovaps xmm12, [rsp+0xB0]
0000792ccedd20f5  vmovaps xmm13, [rsp+0xC0]
0000792ccedd20fe  vmovaps xmm14, [rsp+0xD0]
0000792ccedd2107  vmovaps xmm15, [rsp+0xE0]
0000792ccedd2110  add rsp, 0xF0
0000792ccedd2117  pop r11
0000792ccedd2119  pop r10
0000792ccedd211b  pop r9
0000792ccedd211d  pop r8
0000792ccedd211f  pop rsi
0000792ccedd2120  pop rdi
0000792ccedd2121  pop rdx
0000792ccedd2122  pop rcx
0000792ccedd2123  pop rax
0000792ccedd2124  add rsp, 0x08
0000792ccedd2128  jmp 0x0000792CCEDCFBAB
0000792ccedd212d  call 0x0000792CCEBFF430
0000792ccedd2132  jmp 0x0000792CCEDCFBB8
0000792ccedd2137  sub rsp, 0x08
0000792ccedd213b  push rax
0000792ccedd213c  push rcx
0000792ccedd213d  push rdx
0000792ccedd213e  push rdi
0000792ccedd213f  push rsi
0000792ccedd2140  push r8
0000792ccedd2142  push r9
0000792ccedd2144  push r10
0000792ccedd2146  push r11
0000792ccedd2148  sub rsp, 0xF0
0000792ccedd214f  vmovaps [rsp], xmm0
0000792ccedd2154  vmovaps [rsp+0x10], xmm1
0000792ccedd215a  vmovaps [rsp+0x20], xmm2
0000792ccedd2160  vmovaps [rsp+0x30], xmm3
0000792ccedd2166  vmovaps [rsp+0x40], xmm4
0000792ccedd216c  vmovaps [rsp+0x50], xmm5
0000792ccedd2172  vmovaps [rsp+0x60], xmm6
0000792ccedd2178  vmovaps [rsp+0x70], xmm7
0000792ccedd217e  vmovaps [rsp+0x80], xmm8
0000792ccedd2187  vmovaps [rsp+0x90], xmm9
0000792ccedd2190  vmovaps [rsp+0xA0], xmm10
0000792ccedd2199  vmovaps [rsp+0xB0], xmm11
0000792ccedd21a2  vmovaps [rsp+0xC0], xmm12
0000792ccedd21ab  vmovaps [rsp+0xD0], xmm13
0000792ccedd21b4  vmovaps [rsp+0xE0], xmm14
0000792ccedd21bd  sub rsp, 0x30
0000792ccedd21c1  movaps [rsp], xmm15
0000792ccedd21c6  movaps [rsp+0x10], xmm13
0000792ccedd21cc  movaps [rsp+0x20], xmm1
0000792ccedd21d1  lea rdi, [rsp]
0000792ccedd21d5  mov esi, 0x00
0000792ccedd21da  mov rax, 0x5AEE2D541530
0000792ccedd21e4  call rax
0000792ccedd21e6  movaps xmm15, [rsp]
0000792ccedd21eb  add rsp, 0x30
0000792ccedd21ef  vmovaps xmm0, [rsp]
0000792ccedd21f4  vmovaps xmm1, [rsp+0x10]
0000792ccedd21fa  vmovaps xmm2, [rsp+0x20]
0000792ccedd2200  vmovaps xmm3, [rsp+0x30]
0000792ccedd2206  vmovaps xmm4, [rsp+0x40]
0000792ccedd220c  vmovaps xmm5, [rsp+0x50]
0000792ccedd2212  vmovaps xmm6, [rsp+0x60]
0000792ccedd2218  vmovaps xmm7, [rsp+0x70]
0000792ccedd221e  vmovaps xmm8, [rsp+0x80]
0000792ccedd2227  vmovaps xmm9, [rsp+0x90]
0000792ccedd2230  vmovaps xmm10, [rsp+0xA0]
0000792ccedd2239  vmovaps xmm11, [rsp+0xB0]
0000792ccedd2242  vmovaps xmm12, [rsp+0xC0]
0000792ccedd224b  vmovaps xmm13, [rsp+0xD0]
0000792ccedd2254  vmovaps xmm14, [rsp+0xE0]
0000792ccedd225d  add rsp, 0xF0
0000792ccedd2264  pop r11
0000792ccedd2266  pop r10
0000792ccedd2268  pop r9
0000792ccedd226a  pop r8
0000792ccedd226c  pop rsi
0000792ccedd226d  pop rdi
0000792ccedd226e  pop rdx
0000792ccedd226f  pop rcx
0000792ccedd2270  pop rax
0000792ccedd2271  add rsp, 0x08
0000792ccedd2275  jmp 0x0000792CCEDCFBF7
0000792ccedd227a  sub rsp, 0x08
0000792ccedd227e  push rax
0000792ccedd227f  push rcx
0000792ccedd2280  push rdx
0000792ccedd2281  push rdi
0000792ccedd2282  push rsi
0000792ccedd2283  push r8
0000792ccedd2285  push r9
0000792ccedd2287  push r10
0000792ccedd2289  push r11
0000792ccedd228b  sub rsp, 0xF0
0000792ccedd2292  vmovaps [rsp], xmm0
0000792ccedd2297  vmovaps [rsp+0x10], xmm1
0000792ccedd229d  vmovaps [rsp+0x20], xmm2
0000792ccedd22a3  vmovaps [rsp+0x30], xmm3
0000792ccedd22a9  vmovaps [rsp+0x40], xmm4
0000792ccedd22af  vmovaps [rsp+0x50], xmm5
0000792ccedd22b5  vmovaps [rsp+0x60], xmm6
0000792ccedd22bb  vmovaps [rsp+0x70], xmm7
0000792ccedd22c1  vmovaps [rsp+0x80], xmm8
0000792ccedd22ca  vmovaps [rsp+0x90], xmm9
0000792ccedd22d3  vmovaps [rsp+0xA0], xmm10
0000792ccedd22dc  vmovaps [rsp+0xB0], xmm11
0000792ccedd22e5  vmovaps [rsp+0xC0], xmm12
0000792ccedd22ee  vmovaps [rsp+0xD0], xmm13
0000792ccedd22f7  vmovaps [rsp+0xE0], xmm15
0000792ccedd2300  sub rsp, 0x30
0000792ccedd2304  movaps [rsp], xmm14
0000792ccedd2309  movaps [rsp+0x10], xmm11
0000792ccedd230f  movaps [rsp+0x20], xmm1
0000792ccedd2314  lea rdi, [rsp]
0000792ccedd2318  mov esi, 0x00
0000792ccedd231d  mov rax, 0x5AEE2D541530
0000792ccedd2327  call rax
0000792ccedd2329  movaps xmm14, [rsp]
0000792ccedd232e  add rsp, 0x30
0000792ccedd2332  vmovaps xmm0, [rsp]
0000792ccedd2337  vmovaps xmm1, [rsp+0x10]
0000792ccedd233d  vmovaps xmm2, [rsp+0x20]
0000792ccedd2343  vmovaps xmm3, [rsp+0x30]
0000792ccedd2349  vmovaps xmm4, [rsp+0x40]
0000792ccedd234f  vmovaps xmm5, [rsp+0x50]
0000792ccedd2355  vmovaps xmm6, [rsp+0x60]
0000792ccedd235b  vmovaps xmm7, [rsp+0x70]
0000792ccedd2361  vmovaps xmm8, [rsp+0x80]
0000792ccedd236a  vmovaps xmm9, [rsp+0x90]
0000792ccedd2373  vmovaps xmm10, [rsp+0xA0]
0000792ccedd237c  vmovaps xmm11, [rsp+0xB0]
0000792ccedd2385  vmovaps xmm12, [rsp+0xC0]
0000792ccedd238e  vmovaps xmm13, [rsp+0xD0]
0000792ccedd2397  vmovaps xmm15, [rsp+0xE0]
0000792ccedd23a0  add rsp, 0xF0
0000792ccedd23a7  pop r11
0000792ccedd23a9  pop r10
0000792ccedd23ab  pop r9
0000792ccedd23ad  pop r8
0000792ccedd23af  pop rsi
0000792ccedd23b0  pop rdi
0000792ccedd23b1  pop rdx
0000792ccedd23b2  pop rcx
0000792ccedd23b3  pop rax
0000792ccedd23b4  add rsp, 0x08
0000792ccedd23b8  jmp 0x0000792CCEDCFC21
0000792ccedd23bd  sub rsp, 0x08
0000792ccedd23c1  push rax
0000792ccedd23c2  push rcx
0000792ccedd23c3  push rdx
0000792ccedd23c4  push rdi
0000792ccedd23c5  push rsi
0000792ccedd23c6  push r8
0000792ccedd23c8  push r9
0000792ccedd23ca  push r10
0000792ccedd23cc  push r11
0000792ccedd23ce  sub rsp, 0xF0
0000792ccedd23d5  vmovaps [rsp], xmm0
0000792ccedd23da  vmovaps [rsp+0x10], xmm1
0000792ccedd23e0  vmovaps [rsp+0x20], xmm2
0000792ccedd23e6  vmovaps [rsp+0x30], xmm3
0000792ccedd23ec  vmovaps [rsp+0x40], xmm4
0000792ccedd23f2  vmovaps [rsp+0x50], xmm5
0000792ccedd23f8  vmovaps [rsp+0x60], xmm6
0000792ccedd23fe  vmovaps [rsp+0x70], xmm7
0000792ccedd2404  vmovaps [rsp+0x80], xmm8
0000792ccedd240d  vmovaps [rsp+0x90], xmm9
0000792ccedd2416  vmovaps [rsp+0xA0], xmm10
0000792ccedd241f  vmovaps [rsp+0xB0], xmm11
0000792ccedd2428  vmovaps [rsp+0xC0], xmm12
0000792ccedd2431  vmovaps [rsp+0xD0], xmm14
0000792ccedd243a  vmovaps [rsp+0xE0], xmm15
0000792ccedd2443  sub rsp, 0x30
0000792ccedd2447  movaps [rsp], xmm13
0000792ccedd244c  movaps [rsp+0x10], xmm11
0000792ccedd2452  movaps [rsp+0x20], xmm1
0000792ccedd2457  lea rdi, [rsp]
0000792ccedd245b  mov esi, 0x00
0000792ccedd2460  mov rax, 0x5AEE2D541530
0000792ccedd246a  call rax
0000792ccedd246c  movaps xmm13, [rsp]
0000792ccedd2471  add rsp, 0x30
0000792ccedd2475  vmovaps xmm0, [rsp]
0000792ccedd247a  vmovaps xmm1, [rsp+0x10]
0000792ccedd2480  vmovaps xmm2, [rsp+0x20]
0000792ccedd2486  vmovaps xmm3, [rsp+0x30]
0000792ccedd248c  vmovaps xmm4, [rsp+0x40]
0000792ccedd2492  vmovaps xmm5, [rsp+0x50]
0000792ccedd2498  vmovaps xmm6, [rsp+0x60]
0000792ccedd249e  vmovaps xmm7, [rsp+0x70]
0000792ccedd24a4  vmovaps xmm8, [rsp+0x80]
0000792ccedd24ad  vmovaps xmm9, [rsp+0x90]
0000792ccedd24b6  vmovaps xmm10, [rsp+0xA0]
0000792ccedd24bf  vmovaps xmm11, [rsp+0xB0]
0000792ccedd24c8  vmovaps xmm12, [rsp+0xC0]
0000792ccedd24d1  vmovaps xmm14, [rsp+0xD0]
0000792ccedd24da  vmovaps xmm15, [rsp+0xE0]
0000792ccedd24e3  add rsp, 0xF0
0000792ccedd24ea  pop r11
0000792ccedd24ec  pop r10
0000792ccedd24ee  pop r9
0000792ccedd24f0  pop r8
0000792ccedd24f2  pop rsi
0000792ccedd24f3  pop rdi
0000792ccedd24f4  pop rdx
0000792ccedd24f5  pop rcx
0000792ccedd24f6  pop rax
0000792ccedd24f7  add rsp, 0x08
0000792ccedd24fb  jmp 0x0000792CCEDCFC76
0000792ccedd2500  call 0x0000792CCEBFF430
0000792ccedd2505  jmp 0x0000792CCEDCFC83
0000792ccedd250a  sub rsp, 0x08
0000792ccedd250e  push rax
0000792ccedd250f  push rcx
0000792ccedd2510  push rdx
0000792ccedd2511  push rdi
0000792ccedd2512  push rsi
0000792ccedd2513  push r8
0000792ccedd2515  push r9
0000792ccedd2517  push r10
0000792ccedd2519  push r11
0000792ccedd251b  sub rsp, 0xF0
0000792ccedd2522  vmovaps [rsp], xmm0
0000792ccedd2527  vmovaps [rsp+0x10], xmm1
0000792ccedd252d  vmovaps [rsp+0x20], xmm2
0000792ccedd2533  vmovaps [rsp+0x30], xmm3
0000792ccedd2539  vmovaps [rsp+0x40], xmm4
0000792ccedd253f  vmovaps [rsp+0x50], xmm5
0000792ccedd2545  vmovaps [rsp+0x60], xmm6
0000792ccedd254b  vmovaps [rsp+0x70], xmm7
0000792ccedd2551  vmovaps [rsp+0x80], xmm8
0000792ccedd255a  vmovaps [rsp+0x90], xmm9
0000792ccedd2563  vmovaps [rsp+0xA0], xmm10
0000792ccedd256c  vmovaps [rsp+0xB0], xmm11
0000792ccedd2575  vmovaps [rsp+0xC0], xmm12
0000792ccedd257e  vmovaps [rsp+0xD0], xmm13
0000792ccedd2587  vmovaps [rsp+0xE0], xmm14
0000792ccedd2590  sub rsp, 0x30
0000792ccedd2594  movaps [rsp], xmm15
0000792ccedd2599  movaps [rsp+0x10], xmm11
0000792ccedd259f  movaps [rsp+0x20], xmm1
0000792ccedd25a4  lea rdi, [rsp]
0000792ccedd25a8  mov esi, 0x00
0000792ccedd25ad  mov rax, 0x5AEE2D541530
0000792ccedd25b7  call rax
0000792ccedd25b9  movaps xmm15, [rsp]
0000792ccedd25be  add rsp, 0x30
0000792ccedd25c2  vmovaps xmm0, [rsp]
0000792ccedd25c7  vmovaps xmm1, [rsp+0x10]
0000792ccedd25cd  vmovaps xmm2, [rsp+0x20]
0000792ccedd25d3  vmovaps xmm3, [rsp+0x30]
0000792ccedd25d9  vmovaps xmm4, [rsp+0x40]
0000792ccedd25df  vmovaps xmm5, [rsp+0x50]
0000792ccedd25e5  vmovaps xmm6, [rsp+0x60]
0000792ccedd25eb  vmovaps xmm7, [rsp+0x70]
0000792ccedd25f1  vmovaps xmm8, [rsp+0x80]
0000792ccedd25fa  vmovaps xmm9, [rsp+0x90]
0000792ccedd2603  vmovaps xmm10, [rsp+0xA0]
0000792ccedd260c  vmovaps xmm11, [rsp+0xB0]
0000792ccedd2615  vmovaps xmm12, [rsp+0xC0]
0000792ccedd261e  vmovaps xmm13, [rsp+0xD0]
0000792ccedd2627  vmovaps xmm14, [rsp+0xE0]
0000792ccedd2630  add rsp, 0xF0
0000792ccedd2637  pop r11
0000792ccedd2639  pop r10
0000792ccedd263b  pop r9
0000792ccedd263d  pop r8
0000792ccedd263f  pop rsi
0000792ccedd2640  pop rdi
0000792ccedd2641  pop rdx
0000792ccedd2642  pop rcx
0000792ccedd2643  pop rax
0000792ccedd2644  add rsp, 0x08
0000792ccedd2648  jmp 0x0000792CCEDCFCBC
0000792ccedd264d  sub rsp, 0x08
0000792ccedd2651  push rax
0000792ccedd2652  push rcx
0000792ccedd2653  push rdx
0000792ccedd2654  push rdi
0000792ccedd2655  push rsi
0000792ccedd2656  push r8
0000792ccedd2658  push r9
0000792ccedd265a  push r10
0000792ccedd265c  push r11
0000792ccedd265e  sub rsp, 0xF0
0000792ccedd2665  vmovaps [rsp], xmm0
0000792ccedd266a  vmovaps [rsp+0x10], xmm1
0000792ccedd2670  vmovaps [rsp+0x20], xmm2
0000792ccedd2676  vmovaps [rsp+0x30], xmm3
0000792ccedd267c  vmovaps [rsp+0x40], xmm4
0000792ccedd2682  vmovaps [rsp+0x50], xmm5
0000792ccedd2688  vmovaps [rsp+0x60], xmm6
0000792ccedd268e  vmovaps [rsp+0x70], xmm7
0000792ccedd2694  vmovaps [rsp+0x80], xmm8
0000792ccedd269d  vmovaps [rsp+0x90], xmm9
0000792ccedd26a6  vmovaps [rsp+0xA0], xmm10
0000792ccedd26af  vmovaps [rsp+0xB0], xmm12
0000792ccedd26b8  vmovaps [rsp+0xC0], xmm13
0000792ccedd26c1  vmovaps [rsp+0xD0], xmm14
0000792ccedd26ca  vmovaps [rsp+0xE0], xmm15
0000792ccedd26d3  sub rsp, 0x30
0000792ccedd26d7  movaps [rsp], xmm11
0000792ccedd26dc  movaps [rsp+0x10], xmm6
0000792ccedd26e1  movaps [rsp+0x20], xmm14
0000792ccedd26e7  lea rdi, [rsp]
0000792ccedd26eb  mov esi, 0x00
0000792ccedd26f0  mov rax, 0x5AEE2D541530
0000792ccedd26fa  call rax
0000792ccedd26fc  movaps xmm11, [rsp]
0000792ccedd2701  add rsp, 0x30
0000792ccedd2705  vmovaps xmm0, [rsp]
0000792ccedd270a  vmovaps xmm1, [rsp+0x10]
0000792ccedd2710  vmovaps xmm2, [rsp+0x20]
0000792ccedd2716  vmovaps xmm3, [rsp+0x30]
0000792ccedd271c  vmovaps xmm4, [rsp+0x40]
0000792ccedd2722  vmovaps xmm5, [rsp+0x50]
0000792ccedd2728  vmovaps xmm6, [rsp+0x60]
0000792ccedd272e  vmovaps xmm7, [rsp+0x70]
0000792ccedd2734  vmovaps xmm8, [rsp+0x80]
0000792ccedd273d  vmovaps xmm9, [rsp+0x90]
0000792ccedd2746  vmovaps xmm10, [rsp+0xA0]
0000792ccedd274f  vmovaps xmm12, [rsp+0xB0]
0000792ccedd2758  vmovaps xmm13, [rsp+0xC0]
0000792ccedd2761  vmovaps xmm14, [rsp+0xD0]
0000792ccedd276a  vmovaps xmm15, [rsp+0xE0]
0000792ccedd2773  add rsp, 0xF0
0000792ccedd277a  pop r11
0000792ccedd277c  pop r10
0000792ccedd277e  pop r9
0000792ccedd2780  pop r8
0000792ccedd2782  pop rsi
0000792ccedd2783  pop rdi
0000792ccedd2784  pop rdx
0000792ccedd2785  pop rcx
0000792ccedd2786  pop rax
0000792ccedd2787  add rsp, 0x08
0000792ccedd278b  jmp 0x0000792CCEDCFD34
0000792ccedd2790  call 0x0000792CCEBFF430
0000792ccedd2795  jmp 0x0000792CCEDCFD3E
0000792ccedd279a  sub rsp, 0x08
0000792ccedd279e  push rax
0000792ccedd279f  push rcx
0000792ccedd27a0  push rdx
0000792ccedd27a1  push rdi
0000792ccedd27a2  push rsi
0000792ccedd27a3  push r8
0000792ccedd27a5  push r9
0000792ccedd27a7  push r10
0000792ccedd27a9  push r11
0000792ccedd27ab  sub rsp, 0xF0
0000792ccedd27b2  vmovaps [rsp], xmm0
0000792ccedd27b7  vmovaps [rsp+0x10], xmm1
0000792ccedd27bd  vmovaps [rsp+0x20], xmm2
0000792ccedd27c3  vmovaps [rsp+0x30], xmm3
0000792ccedd27c9  vmovaps [rsp+0x40], xmm4
0000792ccedd27cf  vmovaps [rsp+0x50], xmm5
0000792ccedd27d5  vmovaps [rsp+0x60], xmm6
0000792ccedd27db  vmovaps [rsp+0x70], xmm7
0000792ccedd27e1  vmovaps [rsp+0x80], xmm8
0000792ccedd27ea  vmovaps [rsp+0x90], xmm9
0000792ccedd27f3  vmovaps [rsp+0xA0], xmm10
0000792ccedd27fc  vmovaps [rsp+0xB0], xmm11
0000792ccedd2805  vmovaps [rsp+0xC0], xmm12
0000792ccedd280e  vmovaps [rsp+0xD0], xmm13
0000792ccedd2817  vmovaps [rsp+0xE0], xmm15
0000792ccedd2820  sub rsp, 0x30
0000792ccedd2824  movaps [rsp], xmm14
0000792ccedd2829  movaps [rsp+0x10], xmm6
0000792ccedd282e  movaps [rsp+0x20], xmm2
0000792ccedd2833  lea rdi, [rsp]
0000792ccedd2837  mov esi, 0x00
0000792ccedd283c  mov rax, 0x5AEE2D541530
0000792ccedd2846  call rax
0000792ccedd2848  movaps xmm14, [rsp]
0000792ccedd284d  add rsp, 0x30
0000792ccedd2851  vmovaps xmm0, [rsp]
0000792ccedd2856  vmovaps xmm1, [rsp+0x10]
0000792ccedd285c  vmovaps xmm2, [rsp+0x20]
0000792ccedd2862  vmovaps xmm3, [rsp+0x30]
0000792ccedd2868  vmovaps xmm4, [rsp+0x40]
0000792ccedd286e  vmovaps xmm5, [rsp+0x50]
0000792ccedd2874  vmovaps xmm6, [rsp+0x60]
0000792ccedd287a  vmovaps xmm7, [rsp+0x70]
0000792ccedd2880  vmovaps xmm8, [rsp+0x80]
0000792ccedd2889  vmovaps xmm9, [rsp+0x90]
0000792ccedd2892  vmovaps xmm10, [rsp+0xA0]
0000792ccedd289b  vmovaps xmm11, [rsp+0xB0]
0000792ccedd28a4  vmovaps xmm12, [rsp+0xC0]
0000792ccedd28ad  vmovaps xmm13, [rsp+0xD0]
0000792ccedd28b6  vmovaps xmm15, [rsp+0xE0]
0000792ccedd28bf  add rsp, 0xF0
0000792ccedd28c6  pop r11
0000792ccedd28c8  pop r10
0000792ccedd28ca  pop r9
0000792ccedd28cc  pop r8
0000792ccedd28ce  pop rsi
0000792ccedd28cf  pop rdi
0000792ccedd28d0  pop rdx
0000792ccedd28d1  pop rcx
0000792ccedd28d2  pop rax
0000792ccedd28d3  add rsp, 0x08
0000792ccedd28d7  jmp 0x0000792CCEDCFD72
0000792ccedd28dc  sub rsp, 0x08
0000792ccedd28e0  push rax
0000792ccedd28e1  push rcx
0000792ccedd28e2  push rdx
0000792ccedd28e3  push rdi
0000792ccedd28e4  push rsi
0000792ccedd28e5  push r8
0000792ccedd28e7  push r9
0000792ccedd28e9  push r10
0000792ccedd28eb  push r11
0000792ccedd28ed  sub rsp, 0xF0
0000792ccedd28f4  vmovaps [rsp], xmm0
0000792ccedd28f9  vmovaps [rsp+0x10], xmm1
0000792ccedd28ff  vmovaps [rsp+0x20], xmm2
0000792ccedd2905  vmovaps [rsp+0x30], xmm3
0000792ccedd290b  vmovaps [rsp+0x40], xmm4
0000792ccedd2911  vmovaps [rsp+0x50], xmm5
0000792ccedd2917  vmovaps [rsp+0x60], xmm7
0000792ccedd291d  vmovaps [rsp+0x70], xmm8
0000792ccedd2923  vmovaps [rsp+0x80], xmm9
0000792ccedd292c  vmovaps [rsp+0x90], xmm10
0000792ccedd2935  vmovaps [rsp+0xA0], xmm11
0000792ccedd293e  vmovaps [rsp+0xB0], xmm12
0000792ccedd2947  vmovaps [rsp+0xC0], xmm13
0000792ccedd2950  vmovaps [rsp+0xD0], xmm14
0000792ccedd2959  vmovaps [rsp+0xE0], xmm15
0000792ccedd2962  sub rsp, 0x30
0000792ccedd2966  movaps [rsp], xmm6
0000792ccedd296a  movaps [rsp+0x10], xmm5
0000792ccedd296f  movaps [rsp+0x20], xmm1
0000792ccedd2974  lea rdi, [rsp]
0000792ccedd2978  mov esi, 0x00
0000792ccedd297d  mov rax, 0x5AEE2D541530
0000792ccedd2987  call rax
0000792ccedd2989  movaps xmm6, [rsp]
0000792ccedd298d  add rsp, 0x30
0000792ccedd2991  vmovaps xmm0, [rsp]
0000792ccedd2996  vmovaps xmm1, [rsp+0x10]
0000792ccedd299c  vmovaps xmm2, [rsp+0x20]
0000792ccedd29a2  vmovaps xmm3, [rsp+0x30]
0000792ccedd29a8  vmovaps xmm4, [rsp+0x40]
0000792ccedd29ae  vmovaps xmm5, [rsp+0x50]
0000792ccedd29b4  vmovaps xmm7, [rsp+0x60]
0000792ccedd29ba  vmovaps xmm8, [rsp+0x70]
0000792ccedd29c0  vmovaps xmm9, [rsp+0x80]
0000792ccedd29c9  vmovaps xmm10, [rsp+0x90]
0000792ccedd29d2  vmovaps xmm11, [rsp+0xA0]
0000792ccedd29db  vmovaps xmm12, [rsp+0xB0]
0000792ccedd29e4  vmovaps xmm13, [rsp+0xC0]
0000792ccedd29ed  vmovaps xmm14, [rsp+0xD0]
0000792ccedd29f6  vmovaps xmm15, [rsp+0xE0]
0000792ccedd29ff  add rsp, 0xF0
0000792ccedd2a06  pop r11
0000792ccedd2a08  pop r10
0000792ccedd2a0a  pop r9
0000792ccedd2a0c  pop r8
0000792ccedd2a0e  pop rsi
0000792ccedd2a0f  pop rdi
0000792ccedd2a10  pop rdx
0000792ccedd2a11  pop rcx
0000792ccedd2a12  pop rax
0000792ccedd2a13  add rsp, 0x08
0000792ccedd2a17  jmp 0x0000792CCEDCFD98
0000792ccedd2a1c  sub rsp, 0x08
0000792ccedd2a20  push rax
0000792ccedd2a21  push rcx
0000792ccedd2a22  push rdx
0000792ccedd2a23  push rdi
0000792ccedd2a24  push rsi
0000792ccedd2a25  push r8
0000792ccedd2a27  push r9
0000792ccedd2a29  push r10
0000792ccedd2a2b  push r11
0000792ccedd2a2d  sub rsp, 0xF0
0000792ccedd2a34  vmovaps [rsp], xmm0
0000792ccedd2a39  vmovaps [rsp+0x10], xmm2
0000792ccedd2a3f  vmovaps [rsp+0x20], xmm3
0000792ccedd2a45  vmovaps [rsp+0x30], xmm4
0000792ccedd2a4b  vmovaps [rsp+0x40], xmm5
0000792ccedd2a51  vmovaps [rsp+0x50], xmm6
0000792ccedd2a57  vmovaps [rsp+0x60], xmm7
0000792ccedd2a5d  vmovaps [rsp+0x70], xmm8
0000792ccedd2a63  vmovaps [rsp+0x80], xmm9
0000792ccedd2a6c  vmovaps [rsp+0x90], xmm10
0000792ccedd2a75  vmovaps [rsp+0xA0], xmm11
0000792ccedd2a7e  vmovaps [rsp+0xB0], xmm12
0000792ccedd2a87  vmovaps [rsp+0xC0], xmm13
0000792ccedd2a90  vmovaps [rsp+0xD0], xmm14
0000792ccedd2a99  vmovaps [rsp+0xE0], xmm15
0000792ccedd2aa2  sub rsp, 0x30
0000792ccedd2aa6  movaps [rsp], xmm1
0000792ccedd2aaa  movaps [rsp+0x10], xmm5
0000792ccedd2aaf  movaps [rsp+0x20], xmm13
0000792ccedd2ab5  lea rdi, [rsp]
0000792ccedd2ab9  mov esi, 0x00
0000792ccedd2abe  mov rax, 0x5AEE2D541530
0000792ccedd2ac8  call rax
0000792ccedd2aca  movaps xmm1, [rsp]
0000792ccedd2ace  add rsp, 0x30
0000792ccedd2ad2  vmovaps xmm0, [rsp]
0000792ccedd2ad7  vmovaps xmm2, [rsp+0x10]
0000792ccedd2add  vmovaps xmm3, [rsp+0x20]
0000792ccedd2ae3  vmovaps xmm4, [rsp+0x30]
0000792ccedd2ae9  vmovaps xmm5, [rsp+0x40]
0000792ccedd2aef  vmovaps xmm6, [rsp+0x50]
0000792ccedd2af5  vmovaps xmm7, [rsp+0x60]
0000792ccedd2afb  vmovaps xmm8, [rsp+0x70]
0000792ccedd2b01  vmovaps xmm9, [rsp+0x80]
0000792ccedd2b0a  vmovaps xmm10, [rsp+0x90]
0000792ccedd2b13  vmovaps xmm11, [rsp+0xA0]
0000792ccedd2b1c  vmovaps xmm12, [rsp+0xB0]
0000792ccedd2b25  vmovaps xmm13, [rsp+0xC0]
0000792ccedd2b2e  vmovaps xmm14, [rsp+0xD0]
0000792ccedd2b37  vmovaps xmm15, [rsp+0xE0]
0000792ccedd2b40  add rsp, 0xF0
0000792ccedd2b47  pop r11
0000792ccedd2b49  pop r10
0000792ccedd2b4b  pop r9
0000792ccedd2b4d  pop r8
0000792ccedd2b4f  pop rsi
0000792ccedd2b50  pop rdi
0000792ccedd2b51  pop rdx
0000792ccedd2b52  pop rcx
0000792ccedd2b53  pop rax
0000792ccedd2b54  add rsp, 0x08
0000792ccedd2b58  jmp 0x0000792CCEDCFDB6
0000792ccedd2b5d  sub rsp, 0x08
0000792ccedd2b61  push rax
0000792ccedd2b62  push rcx
0000792ccedd2b63  push rdx
0000792ccedd2b64  push rdi
0000792ccedd2b65  push rsi
0000792ccedd2b66  push r8
0000792ccedd2b68  push r9
0000792ccedd2b6a  push r10
0000792ccedd2b6c  push r11
0000792ccedd2b6e  sub rsp, 0xF0
0000792ccedd2b75  vmovaps [rsp], xmm0
0000792ccedd2b7a  vmovaps [rsp+0x10], xmm1
0000792ccedd2b80  vmovaps [rsp+0x20], xmm2
0000792ccedd2b86  vmovaps [rsp+0x30], xmm3
0000792ccedd2b8c  vmovaps [rsp+0x40], xmm4
0000792ccedd2b92  vmovaps [rsp+0x50], xmm6
0000792ccedd2b98  vmovaps [rsp+0x60], xmm7
0000792ccedd2b9e  vmovaps [rsp+0x70], xmm8
0000792ccedd2ba4  vmovaps [rsp+0x80], xmm9
0000792ccedd2bad  vmovaps [rsp+0x90], xmm10
0000792ccedd2bb6  vmovaps [rsp+0xA0], xmm11
0000792ccedd2bbf  vmovaps [rsp+0xB0], xmm12
0000792ccedd2bc8  vmovaps [rsp+0xC0], xmm13
0000792ccedd2bd1  vmovaps [rsp+0xD0], xmm14
0000792ccedd2bda  vmovaps [rsp+0xE0], xmm15
0000792ccedd2be3  sub rsp, 0x30
0000792ccedd2be7  movaps [rsp], xmm5
0000792ccedd2beb  movaps [rsp+0x10], xmm2
0000792ccedd2bf0  movaps [rsp+0x20], xmm13
0000792ccedd2bf6  lea rdi, [rsp]
0000792ccedd2bfa  mov esi, 0x00
0000792ccedd2bff  mov rax, 0x5AEE2D541530
0000792ccedd2c09  call rax
0000792ccedd2c0b  movaps xmm5, [rsp]
0000792ccedd2c0f  add rsp, 0x30
0000792ccedd2c13  vmovaps xmm0, [rsp]
0000792ccedd2c18  vmovaps xmm1, [rsp+0x10]
0000792ccedd2c1e  vmovaps xmm2, [rsp+0x20]
0000792ccedd2c24  vmovaps xmm3, [rsp+0x30]
0000792ccedd2c2a  vmovaps xmm4, [rsp+0x40]
0000792ccedd2c30  vmovaps xmm6, [rsp+0x50]
0000792ccedd2c36  vmovaps xmm7, [rsp+0x60]
0000792ccedd2c3c  vmovaps xmm8, [rsp+0x70]
0000792ccedd2c42  vmovaps xmm9, [rsp+0x80]
0000792ccedd2c4b  vmovaps xmm10, [rsp+0x90]
0000792ccedd2c54  vmovaps xmm11, [rsp+0xA0]
0000792ccedd2c5d  vmovaps xmm12, [rsp+0xB0]
0000792ccedd2c66  vmovaps xmm13, [rsp+0xC0]
0000792ccedd2c6f  vmovaps xmm14, [rsp+0xD0]
0000792ccedd2c78  vmovaps xmm15, [rsp+0xE0]
0000792ccedd2c81  add rsp, 0xF0
0000792ccedd2c88  pop r11
0000792ccedd2c8a  pop r10
0000792ccedd2c8c  pop r9
0000792ccedd2c8e  pop r8
0000792ccedd2c90  pop rsi
0000792ccedd2c91  pop rdi
0000792ccedd2c92  pop rdx
0000792ccedd2c93  pop rcx
0000792ccedd2c94  pop rax
0000792ccedd2c95  add rsp, 0x08
0000792ccedd2c99  jmp 0x0000792CCEDCFDEC
0000792ccedd2c9e  sub rsp, 0x08
0000792ccedd2ca2  push rax
0000792ccedd2ca3  push rcx
0000792ccedd2ca4  push rdx
0000792ccedd2ca5  push rdi
0000792ccedd2ca6  push rsi
0000792ccedd2ca7  push r8
0000792ccedd2ca9  push r9
0000792ccedd2cab  push r10
0000792ccedd2cad  push r11
0000792ccedd2caf  sub rsp, 0xF0
0000792ccedd2cb6  vmovaps [rsp], xmm0
0000792ccedd2cbb  vmovaps [rsp+0x10], xmm1
0000792ccedd2cc1  vmovaps [rsp+0x20], xmm2
0000792ccedd2cc7  vmovaps [rsp+0x30], xmm3
0000792ccedd2ccd  vmovaps [rsp+0x40], xmm4
0000792ccedd2cd3  vmovaps [rsp+0x50], xmm5
0000792ccedd2cd9  vmovaps [rsp+0x60], xmm6
0000792ccedd2cdf  vmovaps [rsp+0x70], xmm7
0000792ccedd2ce5  vmovaps [rsp+0x80], xmm8
0000792ccedd2cee  vmovaps [rsp+0x90], xmm9
0000792ccedd2cf7  vmovaps [rsp+0xA0], xmm10
0000792ccedd2d00  vmovaps [rsp+0xB0], xmm11
0000792ccedd2d09  vmovaps [rsp+0xC0], xmm12
0000792ccedd2d12  vmovaps [rsp+0xD0], xmm14
0000792ccedd2d1b  vmovaps [rsp+0xE0], xmm15
0000792ccedd2d24  sub rsp, 0x30
0000792ccedd2d28  movaps [rsp], xmm13
0000792ccedd2d2d  movaps [rsp+0x10], xmm10
0000792ccedd2d33  movaps [rsp+0x20], xmm1
0000792ccedd2d38  lea rdi, [rsp]
0000792ccedd2d3c  mov esi, 0x00
0000792ccedd2d41  mov rax, 0x5AEE2D541530
0000792ccedd2d4b  call rax
0000792ccedd2d4d  movaps xmm13, [rsp]
0000792ccedd2d52  add rsp, 0x30
0000792ccedd2d56  vmovaps xmm0, [rsp]
0000792ccedd2d5b  vmovaps xmm1, [rsp+0x10]
0000792ccedd2d61  vmovaps xmm2, [rsp+0x20]
0000792ccedd2d67  vmovaps xmm3, [rsp+0x30]
0000792ccedd2d6d  vmovaps xmm4, [rsp+0x40]
0000792ccedd2d73  vmovaps xmm5, [rsp+0x50]
0000792ccedd2d79  vmovaps xmm6, [rsp+0x60]
0000792ccedd2d7f  vmovaps xmm7, [rsp+0x70]
0000792ccedd2d85  vmovaps xmm8, [rsp+0x80]
0000792ccedd2d8e  vmovaps xmm9, [rsp+0x90]
0000792ccedd2d97  vmovaps xmm10, [rsp+0xA0]
0000792ccedd2da0  vmovaps xmm11, [rsp+0xB0]
0000792ccedd2da9  vmovaps xmm12, [rsp+0xC0]
0000792ccedd2db2  vmovaps xmm14, [rsp+0xD0]
0000792ccedd2dbb  vmovaps xmm15, [rsp+0xE0]
0000792ccedd2dc4  add rsp, 0xF0
0000792ccedd2dcb  pop r11
0000792ccedd2dcd  pop r10
0000792ccedd2dcf  pop r9
0000792ccedd2dd1  pop r8
0000792ccedd2dd3  pop rsi
0000792ccedd2dd4  pop rdi
0000792ccedd2dd5  pop rdx
0000792ccedd2dd6  pop rcx
0000792ccedd2dd7  pop rax
0000792ccedd2dd8  add rsp, 0x08
0000792ccedd2ddc  jmp 0x0000792CCEDCFE15
0000792ccedd2de1  sub rsp, 0x08
0000792ccedd2de5  push rax
0000792ccedd2de6  push rcx
0000792ccedd2de7  push rdx
0000792ccedd2de8  push rdi
0000792ccedd2de9  push rsi
0000792ccedd2dea  push r8
0000792ccedd2dec  push r9
0000792ccedd2dee  push r10
0000792ccedd2df0  push r11
0000792ccedd2df2  sub rsp, 0xF0
0000792ccedd2df9  vmovaps [rsp], xmm0
0000792ccedd2dfe  vmovaps [rsp+0x10], xmm2
0000792ccedd2e04  vmovaps [rsp+0x20], xmm3
0000792ccedd2e0a  vmovaps [rsp+0x30], xmm4
0000792ccedd2e10  vmovaps [rsp+0x40], xmm5
0000792ccedd2e16  vmovaps [rsp+0x50], xmm6
0000792ccedd2e1c  vmovaps [rsp+0x60], xmm7
0000792ccedd2e22  vmovaps [rsp+0x70], xmm8
0000792ccedd2e28  vmovaps [rsp+0x80], xmm9
0000792ccedd2e31  vmovaps [rsp+0x90], xmm10
0000792ccedd2e3a  vmovaps [rsp+0xA0], xmm11
0000792ccedd2e43  vmovaps [rsp+0xB0], xmm12
0000792ccedd2e4c  vmovaps [rsp+0xC0], xmm13
0000792ccedd2e55  vmovaps [rsp+0xD0], xmm14
0000792ccedd2e5e  vmovaps [rsp+0xE0], xmm15
0000792ccedd2e67  sub rsp, 0x30
0000792ccedd2e6b  movaps [rsp], xmm1
0000792ccedd2e6f  movaps [rsp+0x10], xmm15
0000792ccedd2e75  movaps [rsp+0x20], xmm10
0000792ccedd2e7b  lea rdi, [rsp]
0000792ccedd2e7f  mov esi, 0x00
0000792ccedd2e84  mov rax, 0x5AEE2D541530
0000792ccedd2e8e  call rax
0000792ccedd2e90  movaps xmm1, [rsp]
0000792ccedd2e94  add rsp, 0x30
0000792ccedd2e98  vmovaps xmm0, [rsp]
0000792ccedd2e9d  vmovaps xmm2, [rsp+0x10]
0000792ccedd2ea3  vmovaps xmm3, [rsp+0x20]
0000792ccedd2ea9  vmovaps xmm4, [rsp+0x30]
0000792ccedd2eaf  vmovaps xmm5, [rsp+0x40]
0000792ccedd2eb5  vmovaps xmm6, [rsp+0x50]
0000792ccedd2ebb  vmovaps xmm7, [rsp+0x60]
0000792ccedd2ec1  vmovaps xmm8, [rsp+0x70]
0000792ccedd2ec7  vmovaps xmm9, [rsp+0x80]
0000792ccedd2ed0  vmovaps xmm10, [rsp+0x90]
0000792ccedd2ed9  vmovaps xmm11, [rsp+0xA0]
0000792ccedd2ee2  vmovaps xmm12, [rsp+0xB0]
0000792ccedd2eeb  vmovaps xmm13, [rsp+0xC0]
0000792ccedd2ef4  vmovaps xmm14, [rsp+0xD0]
0000792ccedd2efd  vmovaps xmm15, [rsp+0xE0]
0000792ccedd2f06  add rsp, 0xF0
0000792ccedd2f0d  pop r11
0000792ccedd2f0f  pop r10
0000792ccedd2f11  pop r9
0000792ccedd2f13  pop r8
0000792ccedd2f15  pop rsi
0000792ccedd2f16  pop rdi
0000792ccedd2f17  pop rdx
0000792ccedd2f18  pop rcx
0000792ccedd2f19  pop rax
0000792ccedd2f1a  add rsp, 0x08
0000792ccedd2f1e  jmp 0x0000792CCEDCFE34
0000792ccedd2f23  sub rsp, 0x08
0000792ccedd2f27  push rax
0000792ccedd2f28  push rcx
0000792ccedd2f29  push rdx
0000792ccedd2f2a  push rdi
0000792ccedd2f2b  push rsi
0000792ccedd2f2c  push r8
0000792ccedd2f2e  push r9
0000792ccedd2f30  push r10
0000792ccedd2f32  push r11
0000792ccedd2f34  sub rsp, 0xF0
0000792ccedd2f3b  vmovaps [rsp], xmm0
0000792ccedd2f40  vmovaps [rsp+0x10], xmm1
0000792ccedd2f46  vmovaps [rsp+0x20], xmm2
0000792ccedd2f4c  vmovaps [rsp+0x30], xmm3
0000792ccedd2f52  vmovaps [rsp+0x40], xmm4
0000792ccedd2f58  vmovaps [rsp+0x50], xmm5
0000792ccedd2f5e  vmovaps [rsp+0x60], xmm6
0000792ccedd2f64  vmovaps [rsp+0x70], xmm7
0000792ccedd2f6a  vmovaps [rsp+0x80], xmm8
0000792ccedd2f73  vmovaps [rsp+0x90], xmm9
0000792ccedd2f7c  vmovaps [rsp+0xA0], xmm10
0000792ccedd2f85  vmovaps [rsp+0xB0], xmm11
0000792ccedd2f8e  vmovaps [rsp+0xC0], xmm12
0000792ccedd2f97  vmovaps [rsp+0xD0], xmm13
0000792ccedd2fa0  vmovaps [rsp+0xE0], xmm14
0000792ccedd2fa9  sub rsp, 0x30
0000792ccedd2fad  movaps [rsp], xmm15
0000792ccedd2fb2  movaps [rsp+0x10], xmm10
0000792ccedd2fb8  movaps [rsp+0x20], xmm11
0000792ccedd2fbe  lea rdi, [rsp]
0000792ccedd2fc2  mov esi, 0x00
0000792ccedd2fc7  mov rax, 0x5AEE2D541530
0000792ccedd2fd1  call rax
0000792ccedd2fd3  movaps xmm15, [rsp]
0000792ccedd2fd8  add rsp, 0x30
0000792ccedd2fdc  vmovaps xmm0, [rsp]
0000792ccedd2fe1  vmovaps xmm1, [rsp+0x10]
0000792ccedd2fe7  vmovaps xmm2, [rsp+0x20]
0000792ccedd2fed  vmovaps xmm3, [rsp+0x30]
0000792ccedd2ff3  vmovaps xmm4, [rsp+0x40]
0000792ccedd2ff9  vmovaps xmm5, [rsp+0x50]
0000792ccedd2fff  vmovaps xmm6, [rsp+0x60]
0000792ccedd3005  vmovaps xmm7, [rsp+0x70]
0000792ccedd300b  vmovaps xmm8, [rsp+0x80]
0000792ccedd3014  vmovaps xmm9, [rsp+0x90]
0000792ccedd301d  vmovaps xmm10, [rsp+0xA0]
0000792ccedd3026  vmovaps xmm11, [rsp+0xB0]
0000792ccedd302f  vmovaps xmm12, [rsp+0xC0]
0000792ccedd3038  vmovaps xmm13, [rsp+0xD0]
0000792ccedd3041  vmovaps xmm14, [rsp+0xE0]
0000792ccedd304a  add rsp, 0xF0
0000792ccedd3051  pop r11
0000792ccedd3053  pop r10
0000792ccedd3055  pop r9
0000792ccedd3057  pop r8
0000792ccedd3059  pop rsi
0000792ccedd305a  pop rdi
0000792ccedd305b  pop rdx
0000792ccedd305c  pop rcx
0000792ccedd305d  pop rax
0000792ccedd305e  add rsp, 0x08
0000792ccedd3062  jmp 0x0000792CCEDCFE57
0000792ccedd3067  sub rsp, 0x08
0000792ccedd306b  push rax
0000792ccedd306c  push rcx
0000792ccedd306d  push rdx
0000792ccedd306e  push rdi
0000792ccedd306f  push rsi
0000792ccedd3070  push r8
0000792ccedd3072  push r9
0000792ccedd3074  push r10
0000792ccedd3076  push r11
0000792ccedd3078  sub rsp, 0xF0
0000792ccedd307f  vmovaps [rsp], xmm0
0000792ccedd3084  vmovaps [rsp+0x10], xmm1
0000792ccedd308a  vmovaps [rsp+0x20], xmm2
0000792ccedd3090  vmovaps [rsp+0x30], xmm3
0000792ccedd3096  vmovaps [rsp+0x40], xmm4
0000792ccedd309c  vmovaps [rsp+0x50], xmm5
0000792ccedd30a2  vmovaps [rsp+0x60], xmm6
0000792ccedd30a8  vmovaps [rsp+0x70], xmm7
0000792ccedd30ae  vmovaps [rsp+0x80], xmm8
0000792ccedd30b7  vmovaps [rsp+0x90], xmm9
0000792ccedd30c0  vmovaps [rsp+0xA0], xmm11
0000792ccedd30c9  vmovaps [rsp+0xB0], xmm12
0000792ccedd30d2  vmovaps [rsp+0xC0], xmm13
0000792ccedd30db  vmovaps [rsp+0xD0], xmm14
0000792ccedd30e4  vmovaps [rsp+0xE0], xmm15
0000792ccedd30ed  sub rsp, 0x30
0000792ccedd30f1  movaps [rsp], xmm10
0000792ccedd30f6  movaps [rsp+0x10], xmm12
0000792ccedd30fc  movaps [rsp+0x20], xmm11
0000792ccedd3102  lea rdi, [rsp]
0000792ccedd3106  mov esi, 0x00
0000792ccedd310b  mov rax, 0x5AEE2D541530
0000792ccedd3115  call rax
0000792ccedd3117  movaps xmm10, [rsp]
0000792ccedd311c  add rsp, 0x30
0000792ccedd3120  vmovaps xmm0, [rsp]
0000792ccedd3125  vmovaps xmm1, [rsp+0x10]
0000792ccedd312b  vmovaps xmm2, [rsp+0x20]
0000792ccedd3131  vmovaps xmm3, [rsp+0x30]
0000792ccedd3137  vmovaps xmm4, [rsp+0x40]
0000792ccedd313d  vmovaps xmm5, [rsp+0x50]
0000792ccedd3143  vmovaps xmm6, [rsp+0x60]
0000792ccedd3149  vmovaps xmm7, [rsp+0x70]
0000792ccedd314f  vmovaps xmm8, [rsp+0x80]
0000792ccedd3158  vmovaps xmm9, [rsp+0x90]
0000792ccedd3161  vmovaps xmm11, [rsp+0xA0]
0000792ccedd316a  vmovaps xmm12, [rsp+0xB0]
0000792ccedd3173  vmovaps xmm13, [rsp+0xC0]
0000792ccedd317c  vmovaps xmm14, [rsp+0xD0]
0000792ccedd3185  vmovaps xmm15, [rsp+0xE0]
0000792ccedd318e  add rsp, 0xF0
0000792ccedd3195  pop r11
0000792ccedd3197  pop r10
0000792ccedd3199  pop r9
0000792ccedd319b  pop r8
0000792ccedd319d  pop rsi
0000792ccedd319e  pop rdi
0000792ccedd319f  pop rdx
0000792ccedd31a0  pop rcx
0000792ccedd31a1  pop rax
0000792ccedd31a2  add rsp, 0x08
0000792ccedd31a6  jmp 0x0000792CCEDCFE80
0000792ccedd31ab  sub rsp, 0x08
0000792ccedd31af  push rax
0000792ccedd31b0  push rcx
0000792ccedd31b1  push rdx
0000792ccedd31b2  push rdi
0000792ccedd31b3  push rsi
0000792ccedd31b4  push r8
0000792ccedd31b6  push r9
0000792ccedd31b8  push r10
0000792ccedd31ba  push r11
0000792ccedd31bc  sub rsp, 0xF0
0000792ccedd31c3  vmovaps [rsp], xmm0
0000792ccedd31c8  vmovaps [rsp+0x10], xmm1
0000792ccedd31ce  vmovaps [rsp+0x20], xmm2
0000792ccedd31d4  vmovaps [rsp+0x30], xmm3
0000792ccedd31da  vmovaps [rsp+0x40], xmm4
0000792ccedd31e0  vmovaps [rsp+0x50], xmm5
0000792ccedd31e6  vmovaps [rsp+0x60], xmm6
0000792ccedd31ec  vmovaps [rsp+0x70], xmm7
0000792ccedd31f2  vmovaps [rsp+0x80], xmm8
0000792ccedd31fb  vmovaps [rsp+0x90], xmm9
0000792ccedd3204  vmovaps [rsp+0xA0], xmm10
0000792ccedd320d  vmovaps [rsp+0xB0], xmm12
0000792ccedd3216  vmovaps [rsp+0xC0], xmm13
0000792ccedd321f  vmovaps [rsp+0xD0], xmm14
0000792ccedd3228  vmovaps [rsp+0xE0], xmm15
0000792ccedd3231  sub rsp, 0x30
0000792ccedd3235  movaps [rsp], xmm11
0000792ccedd323a  movaps [rsp+0x10], xmm2
0000792ccedd323f  movaps [rsp+0x20], xmm12
0000792ccedd3245  lea rdi, [rsp]
0000792ccedd3249  mov esi, 0x00
0000792ccedd324e  mov rax, 0x5AEE2D541530
0000792ccedd3258  call rax
0000792ccedd325a  movaps xmm11, [rsp]
0000792ccedd325f  add rsp, 0x30
0000792ccedd3263  vmovaps xmm0, [rsp]
0000792ccedd3268  vmovaps xmm1, [rsp+0x10]
0000792ccedd326e  vmovaps xmm2, [rsp+0x20]
0000792ccedd3274  vmovaps xmm3, [rsp+0x30]
0000792ccedd327a  vmovaps xmm4, [rsp+0x40]
0000792ccedd3280  vmovaps xmm5, [rsp+0x50]
0000792ccedd3286  vmovaps xmm6, [rsp+0x60]
0000792ccedd328c  vmovaps xmm7, [rsp+0x70]
0000792ccedd3292  vmovaps xmm8, [rsp+0x80]
0000792ccedd329b  vmovaps xmm9, [rsp+0x90]
0000792ccedd32a4  vmovaps xmm10, [rsp+0xA0]
0000792ccedd32ad  vmovaps xmm12, [rsp+0xB0]
0000792ccedd32b6  vmovaps xmm13, [rsp+0xC0]
0000792ccedd32bf  vmovaps xmm14, [rsp+0xD0]
0000792ccedd32c8  vmovaps xmm15, [rsp+0xE0]
0000792ccedd32d1  add rsp, 0xF0
0000792ccedd32d8  pop r11
0000792ccedd32da  pop r10
0000792ccedd32dc  pop r9
0000792ccedd32de  pop r8
0000792ccedd32e0  pop rsi
0000792ccedd32e1  pop rdi
0000792ccedd32e2  pop rdx
0000792ccedd32e3  pop rcx
0000792ccedd32e4  pop rax
0000792ccedd32e5  add rsp, 0x08
0000792ccedd32e9  jmp 0x0000792CCEDCFEB8
0000792ccedd32ee  sub rsp, 0x08
0000792ccedd32f2  push rax
0000792ccedd32f3  push rcx
0000792ccedd32f4  push rdx
0000792ccedd32f5  push rdi
0000792ccedd32f6  push rsi
0000792ccedd32f7  push r8
0000792ccedd32f9  push r9
0000792ccedd32fb  push r10
0000792ccedd32fd  push r11
0000792ccedd32ff  sub rsp, 0xF0
0000792ccedd3306  vmovaps [rsp], xmm0
0000792ccedd330b  vmovaps [rsp+0x10], xmm2
0000792ccedd3311  vmovaps [rsp+0x20], xmm3
0000792ccedd3317  vmovaps [rsp+0x30], xmm4
0000792ccedd331d  vmovaps [rsp+0x40], xmm5
0000792ccedd3323  vmovaps [rsp+0x50], xmm6
0000792ccedd3329  vmovaps [rsp+0x60], xmm7
0000792ccedd332f  vmovaps [rsp+0x70], xmm8
0000792ccedd3335  vmovaps [rsp+0x80], xmm9
0000792ccedd333e  vmovaps [rsp+0x90], xmm10
0000792ccedd3347  vmovaps [rsp+0xA0], xmm11
0000792ccedd3350  vmovaps [rsp+0xB0], xmm12
0000792ccedd3359  vmovaps [rsp+0xC0], xmm13
0000792ccedd3362  vmovaps [rsp+0xD0], xmm14
0000792ccedd336b  vmovaps [rsp+0xE0], xmm15
0000792ccedd3374  sub rsp, 0x30
0000792ccedd3378  movaps [rsp], xmm1
0000792ccedd337c  movaps [rsp+0x10], xmm14
0000792ccedd3382  movaps [rsp+0x20], xmm6
0000792ccedd3387  lea rdi, [rsp]
0000792ccedd338b  mov esi, 0x00
0000792ccedd3390  mov rax, 0x5AEE2D541530
0000792ccedd339a  call rax
0000792ccedd339c  movaps xmm1, [rsp]
0000792ccedd33a0  add rsp, 0x30
0000792ccedd33a4  vmovaps xmm0, [rsp]
0000792ccedd33a9  vmovaps xmm2, [rsp+0x10]
0000792ccedd33af  vmovaps xmm3, [rsp+0x20]
0000792ccedd33b5  vmovaps xmm4, [rsp+0x30]
0000792ccedd33bb  vmovaps xmm5, [rsp+0x40]
0000792ccedd33c1  vmovaps xmm6, [rsp+0x50]
0000792ccedd33c7  vmovaps xmm7, [rsp+0x60]
0000792ccedd33cd  vmovaps xmm8, [rsp+0x70]
0000792ccedd33d3  vmovaps xmm9, [rsp+0x80]
0000792ccedd33dc  vmovaps xmm10, [rsp+0x90]
0000792ccedd33e5  vmovaps xmm11, [rsp+0xA0]
0000792ccedd33ee  vmovaps xmm12, [rsp+0xB0]
0000792ccedd33f7  vmovaps xmm13, [rsp+0xC0]
0000792ccedd3400  vmovaps xmm14, [rsp+0xD0]
0000792ccedd3409  vmovaps xmm15, [rsp+0xE0]
0000792ccedd3412  add rsp, 0xF0
0000792ccedd3419  pop r11
0000792ccedd341b  pop r10
0000792ccedd341d  pop r9
0000792ccedd341f  pop r8
0000792ccedd3421  pop rsi
0000792ccedd3422  pop rdi
0000792ccedd3423  pop rdx
0000792ccedd3424  pop rcx
0000792ccedd3425  pop rax
0000792ccedd3426  add rsp, 0x08
0000792ccedd342a  jmp 0x0000792CCEDCFED1
0000792ccedd342f  sub rsp, 0x08
0000792ccedd3433  push rax
0000792ccedd3434  push rcx
0000792ccedd3435  push rdx
0000792ccedd3436  push rdi
0000792ccedd3437  push rsi
0000792ccedd3438  push r8
0000792ccedd343a  push r9
0000792ccedd343c  push r10
0000792ccedd343e  push r11
0000792ccedd3440  sub rsp, 0xF0
0000792ccedd3447  vmovaps [rsp], xmm0
0000792ccedd344c  vmovaps [rsp+0x10], xmm1
0000792ccedd3452  vmovaps [rsp+0x20], xmm2
0000792ccedd3458  vmovaps [rsp+0x30], xmm3
0000792ccedd345e  vmovaps [rsp+0x40], xmm4
0000792ccedd3464  vmovaps [rsp+0x50], xmm5
0000792ccedd346a  vmovaps [rsp+0x60], xmm6
0000792ccedd3470  vmovaps [rsp+0x70], xmm7
0000792ccedd3476  vmovaps [rsp+0x80], xmm8
0000792ccedd347f  vmovaps [rsp+0x90], xmm9
0000792ccedd3488  vmovaps [rsp+0xA0], xmm10
0000792ccedd3491  vmovaps [rsp+0xB0], xmm11
0000792ccedd349a  vmovaps [rsp+0xC0], xmm12
0000792ccedd34a3  vmovaps [rsp+0xD0], xmm13
0000792ccedd34ac  vmovaps [rsp+0xE0], xmm15
0000792ccedd34b5  sub rsp, 0x30
0000792ccedd34b9  movaps [rsp], xmm14
0000792ccedd34be  movaps [rsp+0x10], xmm12
0000792ccedd34c4  movaps [rsp+0x20], xmm5
0000792ccedd34c9  lea rdi, [rsp]
0000792ccedd34cd  mov esi, 0x00
0000792ccedd34d2  mov rax, 0x5AEE2D541530
0000792ccedd34dc  call rax
0000792ccedd34de  movaps xmm14, [rsp]
0000792ccedd34e3  add rsp, 0x30
0000792ccedd34e7  vmovaps xmm0, [rsp]
0000792ccedd34ec  vmovaps xmm1, [rsp+0x10]
0000792ccedd34f2  vmovaps xmm2, [rsp+0x20]
0000792ccedd34f8  vmovaps xmm3, [rsp+0x30]
0000792ccedd34fe  vmovaps xmm4, [rsp+0x40]
0000792ccedd3504  vmovaps xmm5, [rsp+0x50]
0000792ccedd350a  vmovaps xmm6, [rsp+0x60]
0000792ccedd3510  vmovaps xmm7, [rsp+0x70]
0000792ccedd3516  vmovaps xmm8, [rsp+0x80]
0000792ccedd351f  vmovaps xmm9, [rsp+0x90]
0000792ccedd3528  vmovaps xmm10, [rsp+0xA0]
0000792ccedd3531  vmovaps xmm11, [rsp+0xB0]
0000792ccedd353a  vmovaps xmm12, [rsp+0xC0]
0000792ccedd3543  vmovaps xmm13, [rsp+0xD0]
0000792ccedd354c  vmovaps xmm15, [rsp+0xE0]
0000792ccedd3555  add rsp, 0xF0
0000792ccedd355c  pop r11
0000792ccedd355e  pop r10
0000792ccedd3560  pop r9
0000792ccedd3562  pop r8
0000792ccedd3564  pop rsi
0000792ccedd3565  pop rdi
0000792ccedd3566  pop rdx
0000792ccedd3567  pop rcx
0000792ccedd3568  pop rax
0000792ccedd3569  add rsp, 0x08
0000792ccedd356d  jmp 0x0000792CCEDCFEF1
0000792ccedd3572  sub rsp, 0x08
0000792ccedd3576  push rax
0000792ccedd3577  push rcx
0000792ccedd3578  push rdx
0000792ccedd3579  push rdi
0000792ccedd357a  push rsi
0000792ccedd357b  push r8
0000792ccedd357d  push r9
0000792ccedd357f  push r10
0000792ccedd3581  push r11
0000792ccedd3583  sub rsp, 0xF0
0000792ccedd358a  vmovaps [rsp], xmm0
0000792ccedd358f  vmovaps [rsp+0x10], xmm1
0000792ccedd3595  vmovaps [rsp+0x20], xmm2
0000792ccedd359b  vmovaps [rsp+0x30], xmm3
0000792ccedd35a1  vmovaps [rsp+0x40], xmm4
0000792ccedd35a7  vmovaps [rsp+0x50], xmm5
0000792ccedd35ad  vmovaps [rsp+0x60], xmm7
0000792ccedd35b3  vmovaps [rsp+0x70], xmm8
0000792ccedd35b9  vmovaps [rsp+0x80], xmm9
0000792ccedd35c2  vmovaps [rsp+0x90], xmm10
0000792ccedd35cb  vmovaps [rsp+0xA0], xmm11
0000792ccedd35d4  vmovaps [rsp+0xB0], xmm12
0000792ccedd35dd  vmovaps [rsp+0xC0], xmm13
0000792ccedd35e6  vmovaps [rsp+0xD0], xmm14
0000792ccedd35ef  vmovaps [rsp+0xE0], xmm15
0000792ccedd35f8  sub rsp, 0x30
0000792ccedd35fc  movaps [rsp], xmm6
0000792ccedd3600  movaps [rsp+0x10], xmm9
0000792ccedd3606  movaps [rsp+0x20], xmm12
0000792ccedd360c  lea rdi, [rsp]
0000792ccedd3610  mov esi, 0x00
0000792ccedd3615  mov rax, 0x5AEE2D541530
0000792ccedd361f  call rax
0000792ccedd3621  movaps xmm6, [rsp]
0000792ccedd3625  add rsp, 0x30
0000792ccedd3629  vmovaps xmm0, [rsp]
0000792ccedd362e  vmovaps xmm1, [rsp+0x10]
0000792ccedd3634  vmovaps xmm2, [rsp+0x20]
0000792ccedd363a  vmovaps xmm3, [rsp+0x30]
0000792ccedd3640  vmovaps xmm4, [rsp+0x40]
0000792ccedd3646  vmovaps xmm5, [rsp+0x50]
0000792ccedd364c  vmovaps xmm7, [rsp+0x60]
0000792ccedd3652  vmovaps xmm8, [rsp+0x70]
0000792ccedd3658  vmovaps xmm9, [rsp+0x80]
0000792ccedd3661  vmovaps xmm10, [rsp+0x90]
0000792ccedd366a  vmovaps xmm11, [rsp+0xA0]
0000792ccedd3673  vmovaps xmm12, [rsp+0xB0]
0000792ccedd367c  vmovaps xmm13, [rsp+0xC0]
0000792ccedd3685  vmovaps xmm14, [rsp+0xD0]
0000792ccedd368e  vmovaps xmm15, [rsp+0xE0]
0000792ccedd3697  add rsp, 0xF0
0000792ccedd369e  pop r11
0000792ccedd36a0  pop r10
0000792ccedd36a2  pop r9
0000792ccedd36a4  pop r8
0000792ccedd36a6  pop rsi
0000792ccedd36a7  pop rdi
0000792ccedd36a8  pop rdx
0000792ccedd36a9  pop rcx
0000792ccedd36aa  pop rax
0000792ccedd36ab  add rsp, 0x08
0000792ccedd36af  jmp 0x0000792CCEDCFF19
0000792ccedd36b4  sub rsp, 0x08
0000792ccedd36b8  push rax
0000792ccedd36b9  push rcx
0000792ccedd36ba  push rdx
0000792ccedd36bb  push rdi
0000792ccedd36bc  push rsi
0000792ccedd36bd  push r8
0000792ccedd36bf  push r9
0000792ccedd36c1  push r10
0000792ccedd36c3  push r11
0000792ccedd36c5  sub rsp, 0xF0
0000792ccedd36cc  vmovaps [rsp], xmm0
0000792ccedd36d1  vmovaps [rsp+0x10], xmm1
0000792ccedd36d7  vmovaps [rsp+0x20], xmm2
0000792ccedd36dd  vmovaps [rsp+0x30], xmm3
0000792ccedd36e3  vmovaps [rsp+0x40], xmm4
0000792ccedd36e9  vmovaps [rsp+0x50], xmm5
0000792ccedd36ef  vmovaps [rsp+0x60], xmm6
0000792ccedd36f5  vmovaps [rsp+0x70], xmm7
0000792ccedd36fb  vmovaps [rsp+0x80], xmm8
0000792ccedd3704  vmovaps [rsp+0x90], xmm9
0000792ccedd370d  vmovaps [rsp+0xA0], xmm10
0000792ccedd3716  vmovaps [rsp+0xB0], xmm11
0000792ccedd371f  vmovaps [rsp+0xC0], xmm13
0000792ccedd3728  vmovaps [rsp+0xD0], xmm14
0000792ccedd3731  vmovaps [rsp+0xE0], xmm15
0000792ccedd373a  sub rsp, 0x30
0000792ccedd373e  movaps [rsp], xmm12
0000792ccedd3743  movaps [rsp+0x10], xmm15
0000792ccedd3749  movaps [rsp+0x20], xmm13
0000792ccedd374f  lea rdi, [rsp]
0000792ccedd3753  mov esi, 0x00
0000792ccedd3758  mov rax, 0x5AEE2D541530
0000792ccedd3762  call rax
0000792ccedd3764  movaps xmm12, [rsp]
0000792ccedd3769  add rsp, 0x30
0000792ccedd376d  vmovaps xmm0, [rsp]
0000792ccedd3772  vmovaps xmm1, [rsp+0x10]
0000792ccedd3778  vmovaps xmm2, [rsp+0x20]
0000792ccedd377e  vmovaps xmm3, [rsp+0x30]
0000792ccedd3784  vmovaps xmm4, [rsp+0x40]
0000792ccedd378a  vmovaps xmm5, [rsp+0x50]
0000792ccedd3790  vmovaps xmm6, [rsp+0x60]
0000792ccedd3796  vmovaps xmm7, [rsp+0x70]
0000792ccedd379c  vmovaps xmm8, [rsp+0x80]
0000792ccedd37a5  vmovaps xmm9, [rsp+0x90]
0000792ccedd37ae  vmovaps xmm10, [rsp+0xA0]
0000792ccedd37b7  vmovaps xmm11, [rsp+0xB0]
0000792ccedd37c0  vmovaps xmm13, [rsp+0xC0]
0000792ccedd37c9  vmovaps xmm14, [rsp+0xD0]
0000792ccedd37d2  vmovaps xmm15, [rsp+0xE0]
0000792ccedd37db  add rsp, 0xF0
0000792ccedd37e2  pop r11
0000792ccedd37e4  pop r10
0000792ccedd37e6  pop r9
0000792ccedd37e8  pop r8
0000792ccedd37ea  pop rsi
0000792ccedd37eb  pop rdi
0000792ccedd37ec  pop rdx
0000792ccedd37ed  pop rcx
0000792ccedd37ee  pop rax
0000792ccedd37ef  add rsp, 0x08
0000792ccedd37f3  jmp 0x0000792CCEDCFF34
0000792ccedd37f8  sub rsp, 0x08
0000792ccedd37fc  push rax
0000792ccedd37fd  push rcx
0000792ccedd37fe  push rdx
0000792ccedd37ff  push rdi
0000792ccedd3800  push rsi
0000792ccedd3801  push r8
0000792ccedd3803  push r9
0000792ccedd3805  push r10
0000792ccedd3807  push r11
0000792ccedd3809  sub rsp, 0xF0
0000792ccedd3810  vmovaps [rsp], xmm0
0000792ccedd3815  vmovaps [rsp+0x10], xmm1
0000792ccedd381b  vmovaps [rsp+0x20], xmm2
0000792ccedd3821  vmovaps [rsp+0x30], xmm3
0000792ccedd3827  vmovaps [rsp+0x40], xmm4
0000792ccedd382d  vmovaps [rsp+0x50], xmm5
0000792ccedd3833  vmovaps [rsp+0x60], xmm6
0000792ccedd3839  vmovaps [rsp+0x70], xmm7
0000792ccedd383f  vmovaps [rsp+0x80], xmm8
0000792ccedd3848  vmovaps [rsp+0x90], xmm9
0000792ccedd3851  vmovaps [rsp+0xA0], xmm10
0000792ccedd385a  vmovaps [rsp+0xB0], xmm11
0000792ccedd3863  vmovaps [rsp+0xC0], xmm12
0000792ccedd386c  vmovaps [rsp+0xD0], xmm13
0000792ccedd3875  vmovaps [rsp+0xE0], xmm14
0000792ccedd387e  sub rsp, 0x30
0000792ccedd3882  movaps [rsp], xmm15
0000792ccedd3887  movaps [rsp+0x10], xmm13
0000792ccedd388d  movaps [rsp+0x20], xmm10
0000792ccedd3893  lea rdi, [rsp]
0000792ccedd3897  mov esi, 0x00
0000792ccedd389c  mov rax, 0x5AEE2D541530
0000792ccedd38a6  call rax
0000792ccedd38a8  movaps xmm15, [rsp]
0000792ccedd38ad  add rsp, 0x30
0000792ccedd38b1  vmovaps xmm0, [rsp]
0000792ccedd38b6  vmovaps xmm1, [rsp+0x10]
0000792ccedd38bc  vmovaps xmm2, [rsp+0x20]
0000792ccedd38c2  vmovaps xmm3, [rsp+0x30]
0000792ccedd38c8  vmovaps xmm4, [rsp+0x40]
0000792ccedd38ce  vmovaps xmm5, [rsp+0x50]
0000792ccedd38d4  vmovaps xmm6, [rsp+0x60]
0000792ccedd38da  vmovaps xmm7, [rsp+0x70]
0000792ccedd38e0  vmovaps xmm8, [rsp+0x80]
0000792ccedd38e9  vmovaps xmm9, [rsp+0x90]
0000792ccedd38f2  vmovaps xmm10, [rsp+0xA0]
0000792ccedd38fb  vmovaps xmm11, [rsp+0xB0]
0000792ccedd3904  vmovaps xmm12, [rsp+0xC0]
0000792ccedd390d  vmovaps xmm13, [rsp+0xD0]
0000792ccedd3916  vmovaps xmm14, [rsp+0xE0]
0000792ccedd391f  add rsp, 0xF0
0000792ccedd3926  pop r11
0000792ccedd3928  pop r10
0000792ccedd392a  pop r9
0000792ccedd392c  pop r8
0000792ccedd392e  pop rsi
0000792ccedd392f  pop rdi
0000792ccedd3930  pop rdx
0000792ccedd3931  pop rcx
0000792ccedd3932  pop rax
0000792ccedd3933  add rsp, 0x08
0000792ccedd3937  jmp 0x0000792CCEDCFF55
0000792ccedd393c  call 0x0000792CCEC0C260
0000792ccedd3941  jmp 0x0000792CCEDCFFB0
0000792ccedd3946  sub rsp, 0x08
0000792ccedd394a  push rax
0000792ccedd394b  push rcx
0000792ccedd394c  push rdx
0000792ccedd394d  push rdi
0000792ccedd394e  push rsi
0000792ccedd394f  push r8
0000792ccedd3951  push r9
0000792ccedd3953  push r10
0000792ccedd3955  push r11
0000792ccedd3957  sub rsp, 0xF0
0000792ccedd395e  vmovaps [rsp], xmm0
0000792ccedd3963  vmovaps [rsp+0x10], xmm1
0000792ccedd3969  vmovaps [rsp+0x20], xmm2
0000792ccedd396f  vmovaps [rsp+0x30], xmm3
0000792ccedd3975  vmovaps [rsp+0x40], xmm4
0000792ccedd397b  vmovaps [rsp+0x50], xmm5
0000792ccedd3981  vmovaps [rsp+0x60], xmm6
0000792ccedd3987  vmovaps [rsp+0x70], xmm7
0000792ccedd398d  vmovaps [rsp+0x80], xmm8
0000792ccedd3996  vmovaps [rsp+0x90], xmm10
0000792ccedd399f  vmovaps [rsp+0xA0], xmm11
0000792ccedd39a8  vmovaps [rsp+0xB0], xmm12
0000792ccedd39b1  vmovaps [rsp+0xC0], xmm13
0000792ccedd39ba  vmovaps [rsp+0xD0], xmm14
0000792ccedd39c3  vmovaps [rsp+0xE0], xmm15
0000792ccedd39cc  sub rsp, 0x30
0000792ccedd39d0  movaps [rsp], xmm9
0000792ccedd39d5  movaps [rsp+0x10], xmm8
0000792ccedd39db  movaps [rsp+0x20], xmm10
0000792ccedd39e1  lea rdi, [rsp]
0000792ccedd39e5  mov esi, 0x00
0000792ccedd39ea  mov rax, 0x5AEE2D541530
0000792ccedd39f4  call rax
0000792ccedd39f6  movaps xmm9, [rsp]
0000792ccedd39fb  add rsp, 0x30
0000792ccedd39ff  vmovaps xmm0, [rsp]
0000792ccedd3a04  vmovaps xmm1, [rsp+0x10]
0000792ccedd3a0a  vmovaps xmm2, [rsp+0x20]
0000792ccedd3a10  vmovaps xmm3, [rsp+0x30]
0000792ccedd3a16  vmovaps xmm4, [rsp+0x40]
0000792ccedd3a1c  vmovaps xmm5, [rsp+0x50]
0000792ccedd3a22  vmovaps xmm6, [rsp+0x60]
0000792ccedd3a28  vmovaps xmm7, [rsp+0x70]
0000792ccedd3a2e  vmovaps xmm8, [rsp+0x80]
0000792ccedd3a37  vmovaps xmm10, [rsp+0x90]
0000792ccedd3a40  vmovaps xmm11, [rsp+0xA0]
0000792ccedd3a49  vmovaps xmm12, [rsp+0xB0]
0000792ccedd3a52  vmovaps xmm13, [rsp+0xC0]
0000792ccedd3a5b  vmovaps xmm14, [rsp+0xD0]
0000792ccedd3a64  vmovaps xmm15, [rsp+0xE0]
0000792ccedd3a6d  add rsp, 0xF0
0000792ccedd3a74  pop r11
0000792ccedd3a76  pop r10
0000792ccedd3a78  pop r9
0000792ccedd3a7a  pop r8
0000792ccedd3a7c  pop rsi
0000792ccedd3a7d  pop rdi
0000792ccedd3a7e  pop rdx
0000792ccedd3a7f  pop rcx
0000792ccedd3a80  pop rax
0000792ccedd3a81  add rsp, 0x08
0000792ccedd3a85  jmp 0x0000792CCEDCFFE1
0000792ccedd3a8a  sub rsp, 0x08
0000792ccedd3a8e  push rax
0000792ccedd3a8f  push rcx
0000792ccedd3a90  push rdx
0000792ccedd3a91  push rdi
0000792ccedd3a92  push rsi
0000792ccedd3a93  push r8
0000792ccedd3a95  push r9
0000792ccedd3a97  push r10
0000792ccedd3a99  push r11
0000792ccedd3a9b  sub rsp, 0xF0
0000792ccedd3aa2  vmovaps [rsp], xmm0
0000792ccedd3aa7  vmovaps [rsp+0x10], xmm1
0000792ccedd3aad  vmovaps [rsp+0x20], xmm2
0000792ccedd3ab3  vmovaps [rsp+0x30], xmm3
0000792ccedd3ab9  vmovaps [rsp+0x40], xmm4
0000792ccedd3abf  vmovaps [rsp+0x50], xmm5
0000792ccedd3ac5  vmovaps [rsp+0x60], xmm6
0000792ccedd3acb  vmovaps [rsp+0x70], xmm7
0000792ccedd3ad1  vmovaps [rsp+0x80], xmm8
0000792ccedd3ada  vmovaps [rsp+0x90], xmm9
0000792ccedd3ae3  vmovaps [rsp+0xA0], xmm11
0000792ccedd3aec  vmovaps [rsp+0xB0], xmm12
0000792ccedd3af5  vmovaps [rsp+0xC0], xmm13
0000792ccedd3afe  vmovaps [rsp+0xD0], xmm14
0000792ccedd3b07  vmovaps [rsp+0xE0], xmm15
0000792ccedd3b10  sub rsp, 0x30
0000792ccedd3b14  movaps [rsp], xmm10
0000792ccedd3b19  movaps [rsp+0x10], xmm1
0000792ccedd3b1e  movaps [rsp+0x20], xmm11
0000792ccedd3b24  lea rdi, [rsp]
0000792ccedd3b28  mov esi, 0x00
0000792ccedd3b2d  mov rax, 0x5AEE2D541530
0000792ccedd3b37  call rax
0000792ccedd3b39  movaps xmm10, [rsp]
0000792ccedd3b3e  add rsp, 0x30
0000792ccedd3b42  vmovaps xmm0, [rsp]
0000792ccedd3b47  vmovaps xmm1, [rsp+0x10]
0000792ccedd3b4d  vmovaps xmm2, [rsp+0x20]
0000792ccedd3b53  vmovaps xmm3, [rsp+0x30]
0000792ccedd3b59  vmovaps xmm4, [rsp+0x40]
0000792ccedd3b5f  vmovaps xmm5, [rsp+0x50]
0000792ccedd3b65  vmovaps xmm6, [rsp+0x60]
0000792ccedd3b6b  vmovaps xmm7, [rsp+0x70]
0000792ccedd3b71  vmovaps xmm8, [rsp+0x80]
0000792ccedd3b7a  vmovaps xmm9, [rsp+0x90]
0000792ccedd3b83  vmovaps xmm11, [rsp+0xA0]
0000792ccedd3b8c  vmovaps xmm12, [rsp+0xB0]
0000792ccedd3b95  vmovaps xmm13, [rsp+0xC0]
0000792ccedd3b9e  vmovaps xmm14, [rsp+0xD0]
0000792ccedd3ba7  vmovaps xmm15, [rsp+0xE0]
0000792ccedd3bb0  add rsp, 0xF0
0000792ccedd3bb7  pop r11
0000792ccedd3bb9  pop r10
0000792ccedd3bbb  pop r9
0000792ccedd3bbd  pop r8
0000792ccedd3bbf  pop rsi
0000792ccedd3bc0  pop rdi
0000792ccedd3bc1  pop rdx
0000792ccedd3bc2  pop rcx
0000792ccedd3bc3  pop rax
0000792ccedd3bc4  add rsp, 0x08
0000792ccedd3bc8  jmp 0x0000792CCEDCFFFC
0000792ccedd3bcd  sub rsp, 0x08
0000792ccedd3bd1  push rax
0000792ccedd3bd2  push rcx
0000792ccedd3bd3  push rdx
0000792ccedd3bd4  push rdi
0000792ccedd3bd5  push rsi
0000792ccedd3bd6  push r8
0000792ccedd3bd8  push r9
0000792ccedd3bda  push r10
0000792ccedd3bdc  push r11
0000792ccedd3bde  sub rsp, 0xF0
0000792ccedd3be5  vmovaps [rsp], xmm0
0000792ccedd3bea  vmovaps [rsp+0x10], xmm2
0000792ccedd3bf0  vmovaps [rsp+0x20], xmm3
0000792ccedd3bf6  vmovaps [rsp+0x30], xmm4
0000792ccedd3bfc  vmovaps [rsp+0x40], xmm5
0000792ccedd3c02  vmovaps [rsp+0x50], xmm6
0000792ccedd3c08  vmovaps [rsp+0x60], xmm7
0000792ccedd3c0e  vmovaps [rsp+0x70], xmm8
0000792ccedd3c14  vmovaps [rsp+0x80], xmm9
0000792ccedd3c1d  vmovaps [rsp+0x90], xmm10
0000792ccedd3c26  vmovaps [rsp+0xA0], xmm11
0000792ccedd3c2f  vmovaps [rsp+0xB0], xmm12
0000792ccedd3c38  vmovaps [rsp+0xC0], xmm13
0000792ccedd3c41  vmovaps [rsp+0xD0], xmm14
0000792ccedd3c4a  vmovaps [rsp+0xE0], xmm15
0000792ccedd3c53  sub rsp, 0x30
0000792ccedd3c57  movaps [rsp], xmm1
0000792ccedd3c5b  movaps [rsp+0x10], xmm14
0000792ccedd3c61  movaps [rsp+0x20], xmm6
0000792ccedd3c66  lea rdi, [rsp]
0000792ccedd3c6a  mov esi, 0x00
0000792ccedd3c6f  mov rax, 0x5AEE2D541530
0000792ccedd3c79  call rax
0000792ccedd3c7b  movaps xmm1, [rsp]
0000792ccedd3c7f  add rsp, 0x30
0000792ccedd3c83  vmovaps xmm0, [rsp]
0000792ccedd3c88  vmovaps xmm2, [rsp+0x10]
0000792ccedd3c8e  vmovaps xmm3, [rsp+0x20]
0000792ccedd3c94  vmovaps xmm4, [rsp+0x30]
0000792ccedd3c9a  vmovaps xmm5, [rsp+0x40]
0000792ccedd3ca0  vmovaps xmm6, [rsp+0x50]
0000792ccedd3ca6  vmovaps xmm7, [rsp+0x60]
0000792ccedd3cac  vmovaps xmm8, [rsp+0x70]
0000792ccedd3cb2  vmovaps xmm9, [rsp+0x80]
0000792ccedd3cbb  vmovaps xmm10, [rsp+0x90]
0000792ccedd3cc4  vmovaps xmm11, [rsp+0xA0]
0000792ccedd3ccd  vmovaps xmm12, [rsp+0xB0]
0000792ccedd3cd6  vmovaps xmm13, [rsp+0xC0]
0000792ccedd3cdf  vmovaps xmm14, [rsp+0xD0]
0000792ccedd3ce8  vmovaps xmm15, [rsp+0xE0]
0000792ccedd3cf1  add rsp, 0xF0
0000792ccedd3cf8  pop r11
0000792ccedd3cfa  pop r10
0000792ccedd3cfc  pop r9
0000792ccedd3cfe  pop r8
0000792ccedd3d00  pop rsi
0000792ccedd3d01  pop rdi
0000792ccedd3d02  pop rdx
0000792ccedd3d03  pop rcx
0000792ccedd3d04  pop rax
0000792ccedd3d05  add rsp, 0x08
0000792ccedd3d09  jmp 0x0000792CCEDD0015
0000792ccedd3d0e  sub rsp, 0x08
0000792ccedd3d12  push rax
0000792ccedd3d13  push rcx
0000792ccedd3d14  push rdx
0000792ccedd3d15  push rdi
0000792ccedd3d16  push rsi
0000792ccedd3d17  push r8
0000792ccedd3d19  push r9
0000792ccedd3d1b  push r10
0000792ccedd3d1d  push r11
0000792ccedd3d1f  sub rsp, 0xF0
0000792ccedd3d26  vmovaps [rsp], xmm0
0000792ccedd3d2b  vmovaps [rsp+0x10], xmm1
0000792ccedd3d31  vmovaps [rsp+0x20], xmm2
0000792ccedd3d37  vmovaps [rsp+0x30], xmm3
0000792ccedd3d3d  vmovaps [rsp+0x40], xmm4
0000792ccedd3d43  vmovaps [rsp+0x50], xmm5
0000792ccedd3d49  vmovaps [rsp+0x60], xmm6
0000792ccedd3d4f  vmovaps [rsp+0x70], xmm7
0000792ccedd3d55  vmovaps [rsp+0x80], xmm8
0000792ccedd3d5e  vmovaps [rsp+0x90], xmm9
0000792ccedd3d67  vmovaps [rsp+0xA0], xmm10
0000792ccedd3d70  vmovaps [rsp+0xB0], xmm12
0000792ccedd3d79  vmovaps [rsp+0xC0], xmm13
0000792ccedd3d82  vmovaps [rsp+0xD0], xmm14
0000792ccedd3d8b  vmovaps [rsp+0xE0], xmm15
0000792ccedd3d94  sub rsp, 0x30
0000792ccedd3d98  movaps [rsp], xmm11
0000792ccedd3d9d  movaps [rsp+0x10], xmm13
0000792ccedd3da3  movaps [rsp+0x20], xmm14
0000792ccedd3da9  lea rdi, [rsp]
0000792ccedd3dad  mov esi, 0x00
0000792ccedd3db2  mov rax, 0x5AEE2D541530
0000792ccedd3dbc  call rax
0000792ccedd3dbe  movaps xmm11, [rsp]
0000792ccedd3dc3  add rsp, 0x30
0000792ccedd3dc7  vmovaps xmm0, [rsp]
0000792ccedd3dcc  vmovaps xmm1, [rsp+0x10]
0000792ccedd3dd2  vmovaps xmm2, [rsp+0x20]
0000792ccedd3dd8  vmovaps xmm3, [rsp+0x30]
0000792ccedd3dde  vmovaps xmm4, [rsp+0x40]
0000792ccedd3de4  vmovaps xmm5, [rsp+0x50]
0000792ccedd3dea  vmovaps xmm6, [rsp+0x60]
0000792ccedd3df0  vmovaps xmm7, [rsp+0x70]
0000792ccedd3df6  vmovaps xmm8, [rsp+0x80]
0000792ccedd3dff  vmovaps xmm9, [rsp+0x90]
0000792ccedd3e08  vmovaps xmm10, [rsp+0xA0]
0000792ccedd3e11  vmovaps xmm12, [rsp+0xB0]
0000792ccedd3e1a  vmovaps xmm13, [rsp+0xC0]
0000792ccedd3e23  vmovaps xmm14, [rsp+0xD0]
0000792ccedd3e2c  vmovaps xmm15, [rsp+0xE0]
0000792ccedd3e35  add rsp, 0xF0
0000792ccedd3e3c  pop r11
0000792ccedd3e3e  pop r10
0000792ccedd3e40  pop r9
0000792ccedd3e42  pop r8
0000792ccedd3e44  pop rsi
0000792ccedd3e45  pop rdi
0000792ccedd3e46  pop rdx
0000792ccedd3e47  pop rcx
0000792ccedd3e48  pop rax
0000792ccedd3e49  add rsp, 0x08
0000792ccedd3e4d  jmp 0x0000792CCEDD003F
0000792ccedd3e52  sub rsp, 0x08
0000792ccedd3e56  push rax
0000792ccedd3e57  push rcx
0000792ccedd3e58  push rdx
0000792ccedd3e59  push rdi
0000792ccedd3e5a  push rsi
0000792ccedd3e5b  push r8
0000792ccedd3e5d  push r9
0000792ccedd3e5f  push r10
0000792ccedd3e61  push r11
0000792ccedd3e63  sub rsp, 0xF0
0000792ccedd3e6a  vmovaps [rsp], xmm0
0000792ccedd3e6f  vmovaps [rsp+0x10], xmm1
0000792ccedd3e75  vmovaps [rsp+0x20], xmm2
0000792ccedd3e7b  vmovaps [rsp+0x30], xmm3
0000792ccedd3e81  vmovaps [rsp+0x40], xmm4
0000792ccedd3e87  vmovaps [rsp+0x50], xmm5
0000792ccedd3e8d  vmovaps [rsp+0x60], xmm6
0000792ccedd3e93  vmovaps [rsp+0x70], xmm7
0000792ccedd3e99  vmovaps [rsp+0x80], xmm8
0000792ccedd3ea2  vmovaps [rsp+0x90], xmm9
0000792ccedd3eab  vmovaps [rsp+0xA0], xmm10
0000792ccedd3eb4  vmovaps [rsp+0xB0], xmm11
0000792ccedd3ebd  vmovaps [rsp+0xC0], xmm12
0000792ccedd3ec6  vmovaps [rsp+0xD0], xmm14
0000792ccedd3ecf  vmovaps [rsp+0xE0], xmm15
0000792ccedd3ed8  sub rsp, 0x30
0000792ccedd3edc  movaps [rsp], xmm13
0000792ccedd3ee1  movaps [rsp+0x10], xmm8
0000792ccedd3ee7  movaps [rsp+0x20], xmm14
0000792ccedd3eed  lea rdi, [rsp]
0000792ccedd3ef1  mov esi, 0x00
0000792ccedd3ef6  mov rax, 0x5AEE2D541530
0000792ccedd3f00  call rax
0000792ccedd3f02  movaps xmm13, [rsp]
0000792ccedd3f07  add rsp, 0x30
0000792ccedd3f0b  vmovaps xmm0, [rsp]
0000792ccedd3f10  vmovaps xmm1, [rsp+0x10]
0000792ccedd3f16  vmovaps xmm2, [rsp+0x20]
0000792ccedd3f1c  vmovaps xmm3, [rsp+0x30]
0000792ccedd3f22  vmovaps xmm4, [rsp+0x40]
0000792ccedd3f28  vmovaps xmm5, [rsp+0x50]
0000792ccedd3f2e  vmovaps xmm6, [rsp+0x60]
0000792ccedd3f34  vmovaps xmm7, [rsp+0x70]
0000792ccedd3f3a  vmovaps xmm8, [rsp+0x80]
0000792ccedd3f43  vmovaps xmm9, [rsp+0x90]
0000792ccedd3f4c  vmovaps xmm10, [rsp+0xA0]
0000792ccedd3f55  vmovaps xmm11, [rsp+0xB0]
0000792ccedd3f5e  vmovaps xmm12, [rsp+0xC0]
0000792ccedd3f67  vmovaps xmm14, [rsp+0xD0]
0000792ccedd3f70  vmovaps xmm15, [rsp+0xE0]
0000792ccedd3f79  add rsp, 0xF0
0000792ccedd3f80  pop r11
0000792ccedd3f82  pop r10
0000792ccedd3f84  pop r9
0000792ccedd3f86  pop r8
0000792ccedd3f88  pop rsi
0000792ccedd3f89  pop rdi
0000792ccedd3f8a  pop rdx
0000792ccedd3f8b  pop rcx
0000792ccedd3f8c  pop rax
0000792ccedd3f8d  add rsp, 0x08
0000792ccedd3f91  jmp 0x0000792CCEDD006E
0000792ccedd3f96  sub rsp, 0x08
0000792ccedd3f9a  push rax
0000792ccedd3f9b  push rcx
0000792ccedd3f9c  push rdx
0000792ccedd3f9d  push rdi
0000792ccedd3f9e  push rsi
0000792ccedd3f9f  push r8
0000792ccedd3fa1  push r9
0000792ccedd3fa3  push r10
0000792ccedd3fa5  push r11
0000792ccedd3fa7  sub rsp, 0xF0
0000792ccedd3fae  vmovaps [rsp], xmm0
0000792ccedd3fb3  vmovaps [rsp+0x10], xmm1
0000792ccedd3fb9  vmovaps [rsp+0x20], xmm2
0000792ccedd3fbf  vmovaps [rsp+0x30], xmm3
0000792ccedd3fc5  vmovaps [rsp+0x40], xmm4
0000792ccedd3fcb  vmovaps [rsp+0x50], xmm5
0000792ccedd3fd1  vmovaps [rsp+0x60], xmm6
0000792ccedd3fd7  vmovaps [rsp+0x70], xmm7
0000792ccedd3fdd  vmovaps [rsp+0x80], xmm9
0000792ccedd3fe6  vmovaps [rsp+0x90], xmm10
0000792ccedd3fef  vmovaps [rsp+0xA0], xmm11
0000792ccedd3ff8  vmovaps [rsp+0xB0], xmm12
0000792ccedd4001  vmovaps [rsp+0xC0], xmm13
0000792ccedd400a  vmovaps [rsp+0xD0], xmm14
0000792ccedd4013  vmovaps [rsp+0xE0], xmm15
0000792ccedd401c  sub rsp, 0x30
0000792ccedd4020  movaps [rsp], xmm8
0000792ccedd4025  movaps [rsp+0x10], xmm7
0000792ccedd402a  movaps [rsp+0x20], xmm14
0000792ccedd4030  lea rdi, [rsp]
0000792ccedd4034  mov esi, 0x00
0000792ccedd4039  mov rax, 0x5AEE2D541530
0000792ccedd4043  call rax
0000792ccedd4045  movaps xmm8, [rsp]
0000792ccedd404a  add rsp, 0x30
0000792ccedd404e  vmovaps xmm0, [rsp]
0000792ccedd4053  vmovaps xmm1, [rsp+0x10]
0000792ccedd4059  vmovaps xmm2, [rsp+0x20]
0000792ccedd405f  vmovaps xmm3, [rsp+0x30]
0000792ccedd4065  vmovaps xmm4, [rsp+0x40]
0000792ccedd406b  vmovaps xmm5, [rsp+0x50]
0000792ccedd4071  vmovaps xmm6, [rsp+0x60]
0000792ccedd4077  vmovaps xmm7, [rsp+0x70]
0000792ccedd407d  vmovaps xmm9, [rsp+0x80]
0000792ccedd4086  vmovaps xmm10, [rsp+0x90]
0000792ccedd408f  vmovaps xmm11, [rsp+0xA0]
0000792ccedd4098  vmovaps xmm12, [rsp+0xB0]
0000792ccedd40a1  vmovaps xmm13, [rsp+0xC0]
0000792ccedd40aa  vmovaps xmm14, [rsp+0xD0]
0000792ccedd40b3  vmovaps xmm15, [rsp+0xE0]
0000792ccedd40bc  add rsp, 0xF0
0000792ccedd40c3  pop r11
0000792ccedd40c5  pop r10
0000792ccedd40c7  pop r9
0000792ccedd40c9  pop r8
0000792ccedd40cb  pop rsi
0000792ccedd40cc  pop rdi
0000792ccedd40cd  pop rdx
0000792ccedd40ce  pop rcx
0000792ccedd40cf  pop rax
0000792ccedd40d0  add rsp, 0x08
0000792ccedd40d4  jmp 0x0000792CCEDD0094
0000792ccedd40d9  sub rsp, 0x08
0000792ccedd40dd  push rax
0000792ccedd40de  push rcx
0000792ccedd40df  push rdx
0000792ccedd40e0  push rdi
0000792ccedd40e1  push rsi
0000792ccedd40e2  push r8
0000792ccedd40e4  push r9
0000792ccedd40e6  push r10
0000792ccedd40e8  push r11
0000792ccedd40ea  sub rsp, 0xF0
0000792ccedd40f1  vmovaps [rsp], xmm0
0000792ccedd40f6  vmovaps [rsp+0x10], xmm1
0000792ccedd40fc  vmovaps [rsp+0x20], xmm2
0000792ccedd4102  vmovaps [rsp+0x30], xmm3
0000792ccedd4108  vmovaps [rsp+0x40], xmm4
0000792ccedd410e  vmovaps [rsp+0x50], xmm5
0000792ccedd4114  vmovaps [rsp+0x60], xmm6
0000792ccedd411a  vmovaps [rsp+0x70], xmm7
0000792ccedd4120  vmovaps [rsp+0x80], xmm8
0000792ccedd4129  vmovaps [rsp+0x90], xmm9
0000792ccedd4132  vmovaps [rsp+0xA0], xmm10
0000792ccedd413b  vmovaps [rsp+0xB0], xmm11
0000792ccedd4144  vmovaps [rsp+0xC0], xmm12
0000792ccedd414d  vmovaps [rsp+0xD0], xmm13
0000792ccedd4156  vmovaps [rsp+0xE0], xmm15
0000792ccedd415f  sub rsp, 0x30
0000792ccedd4163  movaps [rsp], xmm14
0000792ccedd4168  movaps [rsp+0x10], xmm12
0000792ccedd416e  movaps [rsp+0x20], xmm9
0000792ccedd4174  lea rdi, [rsp]
0000792ccedd4178  mov esi, 0x00
0000792ccedd417d  mov rax, 0x5AEE2D541530
0000792ccedd4187  call rax
0000792ccedd4189  movaps xmm14, [rsp]
0000792ccedd418e  add rsp, 0x30
0000792ccedd4192  vmovaps xmm0, [rsp]
0000792ccedd4197  vmovaps xmm1, [rsp+0x10]
0000792ccedd419d  vmovaps xmm2, [rsp+0x20]
0000792ccedd41a3  vmovaps xmm3, [rsp+0x30]
0000792ccedd41a9  vmovaps xmm4, [rsp+0x40]
0000792ccedd41af  vmovaps xmm5, [rsp+0x50]
0000792ccedd41b5  vmovaps xmm6, [rsp+0x60]
0000792ccedd41bb  vmovaps xmm7, [rsp+0x70]
0000792ccedd41c1  vmovaps xmm8, [rsp+0x80]
0000792ccedd41ca  vmovaps xmm9, [rsp+0x90]
0000792ccedd41d3  vmovaps xmm10, [rsp+0xA0]
0000792ccedd41dc  vmovaps xmm11, [rsp+0xB0]
0000792ccedd41e5  vmovaps xmm12, [rsp+0xC0]
0000792ccedd41ee  vmovaps xmm13, [rsp+0xD0]
0000792ccedd41f7  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4200  add rsp, 0xF0
0000792ccedd4207  pop r11
0000792ccedd4209  pop r10
0000792ccedd420b  pop r9
0000792ccedd420d  pop r8
0000792ccedd420f  pop rsi
0000792ccedd4210  pop rdi
0000792ccedd4211  pop rdx
0000792ccedd4212  pop rcx
0000792ccedd4213  pop rax
0000792ccedd4214  add rsp, 0x08
0000792ccedd4218  jmp 0x0000792CCEDD00AE
0000792ccedd421d  sub rsp, 0x08
0000792ccedd4221  push rax
0000792ccedd4222  push rcx
0000792ccedd4223  push rdx
0000792ccedd4224  push rdi
0000792ccedd4225  push rsi
0000792ccedd4226  push r8
0000792ccedd4228  push r9
0000792ccedd422a  push r10
0000792ccedd422c  push r11
0000792ccedd422e  sub rsp, 0xF0
0000792ccedd4235  vmovaps [rsp], xmm0
0000792ccedd423a  vmovaps [rsp+0x10], xmm1
0000792ccedd4240  vmovaps [rsp+0x20], xmm2
0000792ccedd4246  vmovaps [rsp+0x30], xmm3
0000792ccedd424c  vmovaps [rsp+0x40], xmm4
0000792ccedd4252  vmovaps [rsp+0x50], xmm5
0000792ccedd4258  vmovaps [rsp+0x60], xmm6
0000792ccedd425e  vmovaps [rsp+0x70], xmm7
0000792ccedd4264  vmovaps [rsp+0x80], xmm8
0000792ccedd426d  vmovaps [rsp+0x90], xmm10
0000792ccedd4276  vmovaps [rsp+0xA0], xmm11
0000792ccedd427f  vmovaps [rsp+0xB0], xmm12
0000792ccedd4288  vmovaps [rsp+0xC0], xmm13
0000792ccedd4291  vmovaps [rsp+0xD0], xmm14
0000792ccedd429a  vmovaps [rsp+0xE0], xmm15
0000792ccedd42a3  sub rsp, 0x30
0000792ccedd42a7  movaps [rsp], xmm9
0000792ccedd42ac  movaps [rsp+0x10], xmm7
0000792ccedd42b1  movaps [rsp+0x20], xmm12
0000792ccedd42b7  lea rdi, [rsp]
0000792ccedd42bb  mov esi, 0x00
0000792ccedd42c0  mov rax, 0x5AEE2D541530
0000792ccedd42ca  call rax
0000792ccedd42cc  movaps xmm9, [rsp]
0000792ccedd42d1  add rsp, 0x30
0000792ccedd42d5  vmovaps xmm0, [rsp]
0000792ccedd42da  vmovaps xmm1, [rsp+0x10]
0000792ccedd42e0  vmovaps xmm2, [rsp+0x20]
0000792ccedd42e6  vmovaps xmm3, [rsp+0x30]
0000792ccedd42ec  vmovaps xmm4, [rsp+0x40]
0000792ccedd42f2  vmovaps xmm5, [rsp+0x50]
0000792ccedd42f8  vmovaps xmm6, [rsp+0x60]
0000792ccedd42fe  vmovaps xmm7, [rsp+0x70]
0000792ccedd4304  vmovaps xmm8, [rsp+0x80]
0000792ccedd430d  vmovaps xmm10, [rsp+0x90]
0000792ccedd4316  vmovaps xmm11, [rsp+0xA0]
0000792ccedd431f  vmovaps xmm12, [rsp+0xB0]
0000792ccedd4328  vmovaps xmm13, [rsp+0xC0]
0000792ccedd4331  vmovaps xmm14, [rsp+0xD0]
0000792ccedd433a  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4343  add rsp, 0xF0
0000792ccedd434a  pop r11
0000792ccedd434c  pop r10
0000792ccedd434e  pop r9
0000792ccedd4350  pop r8
0000792ccedd4352  pop rsi
0000792ccedd4353  pop rdi
0000792ccedd4354  pop rdx
0000792ccedd4355  pop rcx
0000792ccedd4356  pop rax
0000792ccedd4357  add rsp, 0x08
0000792ccedd435b  jmp 0x0000792CCEDD00DD
0000792ccedd4360  sub rsp, 0x08
0000792ccedd4364  push rax
0000792ccedd4365  push rcx
0000792ccedd4366  push rdx
0000792ccedd4367  push rdi
0000792ccedd4368  push rsi
0000792ccedd4369  push r8
0000792ccedd436b  push r9
0000792ccedd436d  push r10
0000792ccedd436f  push r11
0000792ccedd4371  sub rsp, 0xF0
0000792ccedd4378  vmovaps [rsp], xmm0
0000792ccedd437d  vmovaps [rsp+0x10], xmm1
0000792ccedd4383  vmovaps [rsp+0x20], xmm2
0000792ccedd4389  vmovaps [rsp+0x30], xmm3
0000792ccedd438f  vmovaps [rsp+0x40], xmm4
0000792ccedd4395  vmovaps [rsp+0x50], xmm5
0000792ccedd439b  vmovaps [rsp+0x60], xmm6
0000792ccedd43a1  vmovaps [rsp+0x70], xmm7
0000792ccedd43a7  vmovaps [rsp+0x80], xmm8
0000792ccedd43b0  vmovaps [rsp+0x90], xmm9
0000792ccedd43b9  vmovaps [rsp+0xA0], xmm10
0000792ccedd43c2  vmovaps [rsp+0xB0], xmm11
0000792ccedd43cb  vmovaps [rsp+0xC0], xmm13
0000792ccedd43d4  vmovaps [rsp+0xD0], xmm14
0000792ccedd43dd  vmovaps [rsp+0xE0], xmm15
0000792ccedd43e6  sub rsp, 0x30
0000792ccedd43ea  movaps [rsp], xmm12
0000792ccedd43ef  movaps [rsp+0x10], xmm15
0000792ccedd43f5  movaps [rsp+0x20], xmm11
0000792ccedd43fb  lea rdi, [rsp]
0000792ccedd43ff  mov esi, 0x00
0000792ccedd4404  mov rax, 0x5AEE2D541530
0000792ccedd440e  call rax
0000792ccedd4410  movaps xmm12, [rsp]
0000792ccedd4415  add rsp, 0x30
0000792ccedd4419  vmovaps xmm0, [rsp]
0000792ccedd441e  vmovaps xmm1, [rsp+0x10]
0000792ccedd4424  vmovaps xmm2, [rsp+0x20]
0000792ccedd442a  vmovaps xmm3, [rsp+0x30]
0000792ccedd4430  vmovaps xmm4, [rsp+0x40]
0000792ccedd4436  vmovaps xmm5, [rsp+0x50]
0000792ccedd443c  vmovaps xmm6, [rsp+0x60]
0000792ccedd4442  vmovaps xmm7, [rsp+0x70]
0000792ccedd4448  vmovaps xmm8, [rsp+0x80]
0000792ccedd4451  vmovaps xmm9, [rsp+0x90]
0000792ccedd445a  vmovaps xmm10, [rsp+0xA0]
0000792ccedd4463  vmovaps xmm11, [rsp+0xB0]
0000792ccedd446c  vmovaps xmm13, [rsp+0xC0]
0000792ccedd4475  vmovaps xmm14, [rsp+0xD0]
0000792ccedd447e  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4487  add rsp, 0xF0
0000792ccedd448e  pop r11
0000792ccedd4490  pop r10
0000792ccedd4492  pop r9
0000792ccedd4494  pop r8
0000792ccedd4496  pop rsi
0000792ccedd4497  pop rdi
0000792ccedd4498  pop rdx
0000792ccedd4499  pop rcx
0000792ccedd449a  pop rax
0000792ccedd449b  add rsp, 0x08
0000792ccedd449f  jmp 0x0000792CCEDD00F7
0000792ccedd44a4  sub rsp, 0x08
0000792ccedd44a8  push rax
0000792ccedd44a9  push rcx
0000792ccedd44aa  push rdx
0000792ccedd44ab  push rdi
0000792ccedd44ac  push rsi
0000792ccedd44ad  push r8
0000792ccedd44af  push r9
0000792ccedd44b1  push r10
0000792ccedd44b3  push r11
0000792ccedd44b5  sub rsp, 0xF0
0000792ccedd44bc  vmovaps [rsp], xmm0
0000792ccedd44c1  vmovaps [rsp+0x10], xmm1
0000792ccedd44c7  vmovaps [rsp+0x20], xmm2
0000792ccedd44cd  vmovaps [rsp+0x30], xmm3
0000792ccedd44d3  vmovaps [rsp+0x40], xmm4
0000792ccedd44d9  vmovaps [rsp+0x50], xmm5
0000792ccedd44df  vmovaps [rsp+0x60], xmm6
0000792ccedd44e5  vmovaps [rsp+0x70], xmm7
0000792ccedd44eb  vmovaps [rsp+0x80], xmm8
0000792ccedd44f4  vmovaps [rsp+0x90], xmm9
0000792ccedd44fd  vmovaps [rsp+0xA0], xmm10
0000792ccedd4506  vmovaps [rsp+0xB0], xmm12
0000792ccedd450f  vmovaps [rsp+0xC0], xmm13
0000792ccedd4518  vmovaps [rsp+0xD0], xmm14
0000792ccedd4521  vmovaps [rsp+0xE0], xmm15
0000792ccedd452a  sub rsp, 0x30
0000792ccedd452e  movaps [rsp], xmm11
0000792ccedd4533  movaps [rsp+0x10], xmm7
0000792ccedd4538  movaps [rsp+0x20], xmm15
0000792ccedd453e  lea rdi, [rsp]
0000792ccedd4542  mov esi, 0x00
0000792ccedd4547  mov rax, 0x5AEE2D541530
0000792ccedd4551  call rax
0000792ccedd4553  movaps xmm11, [rsp]
0000792ccedd4558  add rsp, 0x30
0000792ccedd455c  vmovaps xmm0, [rsp]
0000792ccedd4561  vmovaps xmm1, [rsp+0x10]
0000792ccedd4567  vmovaps xmm2, [rsp+0x20]
0000792ccedd456d  vmovaps xmm3, [rsp+0x30]
0000792ccedd4573  vmovaps xmm4, [rsp+0x40]
0000792ccedd4579  vmovaps xmm5, [rsp+0x50]
0000792ccedd457f  vmovaps xmm6, [rsp+0x60]
0000792ccedd4585  vmovaps xmm7, [rsp+0x70]
0000792ccedd458b  vmovaps xmm8, [rsp+0x80]
0000792ccedd4594  vmovaps xmm9, [rsp+0x90]
0000792ccedd459d  vmovaps xmm10, [rsp+0xA0]
0000792ccedd45a6  vmovaps xmm12, [rsp+0xB0]
0000792ccedd45af  vmovaps xmm13, [rsp+0xC0]
0000792ccedd45b8  vmovaps xmm14, [rsp+0xD0]
0000792ccedd45c1  vmovaps xmm15, [rsp+0xE0]
0000792ccedd45ca  add rsp, 0xF0
0000792ccedd45d1  pop r11
0000792ccedd45d3  pop r10
0000792ccedd45d5  pop r9
0000792ccedd45d7  pop r8
0000792ccedd45d9  pop rsi
0000792ccedd45da  pop rdi
0000792ccedd45db  pop rdx
0000792ccedd45dc  pop rcx
0000792ccedd45dd  pop rax
0000792ccedd45de  add rsp, 0x08
0000792ccedd45e2  jmp 0x0000792CCEDD0123
0000792ccedd45e7  sub rsp, 0x08
0000792ccedd45eb  push rax
0000792ccedd45ec  push rcx
0000792ccedd45ed  push rdx
0000792ccedd45ee  push rdi
0000792ccedd45ef  push rsi
0000792ccedd45f0  push r8
0000792ccedd45f2  push r9
0000792ccedd45f4  push r10
0000792ccedd45f6  push r11
0000792ccedd45f8  sub rsp, 0xF0
0000792ccedd45ff  vmovaps [rsp], xmm0
0000792ccedd4604  vmovaps [rsp+0x10], xmm1
0000792ccedd460a  vmovaps [rsp+0x20], xmm2
0000792ccedd4610  vmovaps [rsp+0x30], xmm3
0000792ccedd4616  vmovaps [rsp+0x40], xmm4
0000792ccedd461c  vmovaps [rsp+0x50], xmm5
0000792ccedd4622  vmovaps [rsp+0x60], xmm6
0000792ccedd4628  vmovaps [rsp+0x70], xmm7
0000792ccedd462e  vmovaps [rsp+0x80], xmm8
0000792ccedd4637  vmovaps [rsp+0x90], xmm9
0000792ccedd4640  vmovaps [rsp+0xA0], xmm10
0000792ccedd4649  vmovaps [rsp+0xB0], xmm11
0000792ccedd4652  vmovaps [rsp+0xC0], xmm12
0000792ccedd465b  vmovaps [rsp+0xD0], xmm13
0000792ccedd4664  vmovaps [rsp+0xE0], xmm14
0000792ccedd466d  sub rsp, 0x30
0000792ccedd4671  movaps [rsp], xmm15
0000792ccedd4676  movaps [rsp+0x10], xmm10
0000792ccedd467c  movaps [rsp+0x20], xmm13
0000792ccedd4682  lea rdi, [rsp]
0000792ccedd4686  mov esi, 0x00
0000792ccedd468b  mov rax, 0x5AEE2D541530
0000792ccedd4695  call rax
0000792ccedd4697  movaps xmm15, [rsp]
0000792ccedd469c  add rsp, 0x30
0000792ccedd46a0  vmovaps xmm0, [rsp]
0000792ccedd46a5  vmovaps xmm1, [rsp+0x10]
0000792ccedd46ab  vmovaps xmm2, [rsp+0x20]
0000792ccedd46b1  vmovaps xmm3, [rsp+0x30]
0000792ccedd46b7  vmovaps xmm4, [rsp+0x40]
0000792ccedd46bd  vmovaps xmm5, [rsp+0x50]
0000792ccedd46c3  vmovaps xmm6, [rsp+0x60]
0000792ccedd46c9  vmovaps xmm7, [rsp+0x70]
0000792ccedd46cf  vmovaps xmm8, [rsp+0x80]
0000792ccedd46d8  vmovaps xmm9, [rsp+0x90]
0000792ccedd46e1  vmovaps xmm10, [rsp+0xA0]
0000792ccedd46ea  vmovaps xmm11, [rsp+0xB0]
0000792ccedd46f3  vmovaps xmm12, [rsp+0xC0]
0000792ccedd46fc  vmovaps xmm13, [rsp+0xD0]
0000792ccedd4705  vmovaps xmm14, [rsp+0xE0]
0000792ccedd470e  add rsp, 0xF0
0000792ccedd4715  pop r11
0000792ccedd4717  pop r10
0000792ccedd4719  pop r9
0000792ccedd471b  pop r8
0000792ccedd471d  pop rsi
0000792ccedd471e  pop rdi
0000792ccedd471f  pop rdx
0000792ccedd4720  pop rcx
0000792ccedd4721  pop rax
0000792ccedd4722  add rsp, 0x08
0000792ccedd4726  jmp 0x0000792CCEDD013D
0000792ccedd472b  sub rsp, 0x08
0000792ccedd472f  push rax
0000792ccedd4730  push rcx
0000792ccedd4731  push rdx
0000792ccedd4732  push rdi
0000792ccedd4733  push rsi
0000792ccedd4734  push r8
0000792ccedd4736  push r9
0000792ccedd4738  push r10
0000792ccedd473a  push r11
0000792ccedd473c  sub rsp, 0xF0
0000792ccedd4743  vmovaps [rsp], xmm0
0000792ccedd4748  vmovaps [rsp+0x10], xmm1
0000792ccedd474e  vmovaps [rsp+0x20], xmm2
0000792ccedd4754  vmovaps [rsp+0x30], xmm3
0000792ccedd475a  vmovaps [rsp+0x40], xmm4
0000792ccedd4760  vmovaps [rsp+0x50], xmm5
0000792ccedd4766  vmovaps [rsp+0x60], xmm6
0000792ccedd476c  vmovaps [rsp+0x70], xmm7
0000792ccedd4772  vmovaps [rsp+0x80], xmm8
0000792ccedd477b  vmovaps [rsp+0x90], xmm9
0000792ccedd4784  vmovaps [rsp+0xA0], xmm11
0000792ccedd478d  vmovaps [rsp+0xB0], xmm12
0000792ccedd4796  vmovaps [rsp+0xC0], xmm13
0000792ccedd479f  vmovaps [rsp+0xD0], xmm14
0000792ccedd47a8  vmovaps [rsp+0xE0], xmm15
0000792ccedd47b1  sub rsp, 0x30
0000792ccedd47b5  movaps [rsp], xmm10
0000792ccedd47ba  movaps [rsp+0x10], xmm7
0000792ccedd47bf  movaps [rsp+0x20], xmm13
0000792ccedd47c5  lea rdi, [rsp]
0000792ccedd47c9  mov esi, 0x00
0000792ccedd47ce  mov rax, 0x5AEE2D541530
0000792ccedd47d8  call rax
0000792ccedd47da  movaps xmm10, [rsp]
0000792ccedd47df  add rsp, 0x30
0000792ccedd47e3  vmovaps xmm0, [rsp]
0000792ccedd47e8  vmovaps xmm1, [rsp+0x10]
0000792ccedd47ee  vmovaps xmm2, [rsp+0x20]
0000792ccedd47f4  vmovaps xmm3, [rsp+0x30]
0000792ccedd47fa  vmovaps xmm4, [rsp+0x40]
0000792ccedd4800  vmovaps xmm5, [rsp+0x50]
0000792ccedd4806  vmovaps xmm6, [rsp+0x60]
0000792ccedd480c  vmovaps xmm7, [rsp+0x70]
0000792ccedd4812  vmovaps xmm8, [rsp+0x80]
0000792ccedd481b  vmovaps xmm9, [rsp+0x90]
0000792ccedd4824  vmovaps xmm11, [rsp+0xA0]
0000792ccedd482d  vmovaps xmm12, [rsp+0xB0]
0000792ccedd4836  vmovaps xmm13, [rsp+0xC0]
0000792ccedd483f  vmovaps xmm14, [rsp+0xD0]
0000792ccedd4848  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4851  add rsp, 0xF0
0000792ccedd4858  pop r11
0000792ccedd485a  pop r10
0000792ccedd485c  pop r9
0000792ccedd485e  pop r8
0000792ccedd4860  pop rsi
0000792ccedd4861  pop rdi
0000792ccedd4862  pop rdx
0000792ccedd4863  pop rcx
0000792ccedd4864  pop rax
0000792ccedd4865  add rsp, 0x08
0000792ccedd4869  jmp 0x0000792CCEDD0169
0000792ccedd486e  sub rsp, 0x08
0000792ccedd4872  push rax
0000792ccedd4873  push rcx
0000792ccedd4874  push rdx
0000792ccedd4875  push rdi
0000792ccedd4876  push rsi
0000792ccedd4877  push r8
0000792ccedd4879  push r9
0000792ccedd487b  push r10
0000792ccedd487d  push r11
0000792ccedd487f  sub rsp, 0xF0
0000792ccedd4886  vmovaps [rsp], xmm0
0000792ccedd488b  vmovaps [rsp+0x10], xmm1
0000792ccedd4891  vmovaps [rsp+0x20], xmm2
0000792ccedd4897  vmovaps [rsp+0x30], xmm3
0000792ccedd489d  vmovaps [rsp+0x40], xmm4
0000792ccedd48a3  vmovaps [rsp+0x50], xmm5
0000792ccedd48a9  vmovaps [rsp+0x60], xmm6
0000792ccedd48af  vmovaps [rsp+0x70], xmm7
0000792ccedd48b5  vmovaps [rsp+0x80], xmm8
0000792ccedd48be  vmovaps [rsp+0x90], xmm9
0000792ccedd48c7  vmovaps [rsp+0xA0], xmm10
0000792ccedd48d0  vmovaps [rsp+0xB0], xmm11
0000792ccedd48d9  vmovaps [rsp+0xC0], xmm12
0000792ccedd48e2  vmovaps [rsp+0xD0], xmm14
0000792ccedd48eb  vmovaps [rsp+0xE0], xmm15
0000792ccedd48f4  sub rsp, 0x30
0000792ccedd48f8  movaps [rsp], xmm13
0000792ccedd48fd  movaps [rsp+0x10], xmm1
0000792ccedd4902  movaps [rsp+0x20], xmm8
0000792ccedd4908  lea rdi, [rsp]
0000792ccedd490c  mov esi, 0x00
0000792ccedd4911  mov rax, 0x5AEE2D541530
0000792ccedd491b  call rax
0000792ccedd491d  movaps xmm13, [rsp]
0000792ccedd4922  add rsp, 0x30
0000792ccedd4926  vmovaps xmm0, [rsp]
0000792ccedd492b  vmovaps xmm1, [rsp+0x10]
0000792ccedd4931  vmovaps xmm2, [rsp+0x20]
0000792ccedd4937  vmovaps xmm3, [rsp+0x30]
0000792ccedd493d  vmovaps xmm4, [rsp+0x40]
0000792ccedd4943  vmovaps xmm5, [rsp+0x50]
0000792ccedd4949  vmovaps xmm6, [rsp+0x60]
0000792ccedd494f  vmovaps xmm7, [rsp+0x70]
0000792ccedd4955  vmovaps xmm8, [rsp+0x80]
0000792ccedd495e  vmovaps xmm9, [rsp+0x90]
0000792ccedd4967  vmovaps xmm10, [rsp+0xA0]
0000792ccedd4970  vmovaps xmm11, [rsp+0xB0]
0000792ccedd4979  vmovaps xmm12, [rsp+0xC0]
0000792ccedd4982  vmovaps xmm14, [rsp+0xD0]
0000792ccedd498b  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4994  add rsp, 0xF0
0000792ccedd499b  pop r11
0000792ccedd499d  pop r10
0000792ccedd499f  pop r9
0000792ccedd49a1  pop r8
0000792ccedd49a3  pop rsi
0000792ccedd49a4  pop rdi
0000792ccedd49a5  pop rdx
0000792ccedd49a6  pop rcx
0000792ccedd49a7  pop rax
0000792ccedd49a8  add rsp, 0x08
0000792ccedd49ac  jmp 0x0000792CCEDD0183
0000792ccedd49b1  call 0x0000792CCEBFF430
0000792ccedd49b6  jmp 0x0000792CCEDD018D
0000792ccedd49bb  sub rsp, 0x08
0000792ccedd49bf  push rax
0000792ccedd49c0  push rcx
0000792ccedd49c1  push rdx
0000792ccedd49c2  push rdi
0000792ccedd49c3  push rsi
0000792ccedd49c4  push r8
0000792ccedd49c6  push r9
0000792ccedd49c8  push r10
0000792ccedd49ca  push r11
0000792ccedd49cc  sub rsp, 0xF0
0000792ccedd49d3  vmovaps [rsp], xmm0
0000792ccedd49d8  vmovaps [rsp+0x10], xmm1
0000792ccedd49de  vmovaps [rsp+0x20], xmm2
0000792ccedd49e4  vmovaps [rsp+0x30], xmm3
0000792ccedd49ea  vmovaps [rsp+0x40], xmm4
0000792ccedd49f0  vmovaps [rsp+0x50], xmm5
0000792ccedd49f6  vmovaps [rsp+0x60], xmm6
0000792ccedd49fc  vmovaps [rsp+0x70], xmm7
0000792ccedd4a02  vmovaps [rsp+0x80], xmm9
0000792ccedd4a0b  vmovaps [rsp+0x90], xmm10
0000792ccedd4a14  vmovaps [rsp+0xA0], xmm11
0000792ccedd4a1d  vmovaps [rsp+0xB0], xmm12
0000792ccedd4a26  vmovaps [rsp+0xC0], xmm13
0000792ccedd4a2f  vmovaps [rsp+0xD0], xmm14
0000792ccedd4a38  vmovaps [rsp+0xE0], xmm15
0000792ccedd4a41  sub rsp, 0x30
0000792ccedd4a45  movaps [rsp], xmm8
0000792ccedd4a4a  movaps [rsp+0x10], xmm14
0000792ccedd4a50  movaps [rsp+0x20], xmm9
0000792ccedd4a56  lea rdi, [rsp]
0000792ccedd4a5a  mov esi, 0x00
0000792ccedd4a5f  mov rax, 0x5AEE2D541530
0000792ccedd4a69  call rax
0000792ccedd4a6b  movaps xmm8, [rsp]
0000792ccedd4a70  add rsp, 0x30
0000792ccedd4a74  vmovaps xmm0, [rsp]
0000792ccedd4a79  vmovaps xmm1, [rsp+0x10]
0000792ccedd4a7f  vmovaps xmm2, [rsp+0x20]
0000792ccedd4a85  vmovaps xmm3, [rsp+0x30]
0000792ccedd4a8b  vmovaps xmm4, [rsp+0x40]
0000792ccedd4a91  vmovaps xmm5, [rsp+0x50]
0000792ccedd4a97  vmovaps xmm6, [rsp+0x60]
0000792ccedd4a9d  vmovaps xmm7, [rsp+0x70]
0000792ccedd4aa3  vmovaps xmm9, [rsp+0x80]
0000792ccedd4aac  vmovaps xmm10, [rsp+0x90]
0000792ccedd4ab5  vmovaps xmm11, [rsp+0xA0]
0000792ccedd4abe  vmovaps xmm12, [rsp+0xB0]
0000792ccedd4ac7  vmovaps xmm13, [rsp+0xC0]
0000792ccedd4ad0  vmovaps xmm14, [rsp+0xD0]
0000792ccedd4ad9  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4ae2  add rsp, 0xF0
0000792ccedd4ae9  pop r11
0000792ccedd4aeb  pop r10
0000792ccedd4aed  pop r9
0000792ccedd4aef  pop r8
0000792ccedd4af1  pop rsi
0000792ccedd4af2  pop rdi
0000792ccedd4af3  pop rdx
0000792ccedd4af4  pop rcx
0000792ccedd4af5  pop rax
0000792ccedd4af6  add rsp, 0x08
0000792ccedd4afa  jmp 0x0000792CCEDD01AF
0000792ccedd4aff  sub rsp, 0x08
0000792ccedd4b03  push rax
0000792ccedd4b04  push rcx
0000792ccedd4b05  push rdx
0000792ccedd4b06  push rdi
0000792ccedd4b07  push rsi
0000792ccedd4b08  push r8
0000792ccedd4b0a  push r9
0000792ccedd4b0c  push r10
0000792ccedd4b0e  push r11
0000792ccedd4b10  sub rsp, 0xF0
0000792ccedd4b17  vmovaps [rsp], xmm0
0000792ccedd4b1c  vmovaps [rsp+0x10], xmm1
0000792ccedd4b22  vmovaps [rsp+0x20], xmm2
0000792ccedd4b28  vmovaps [rsp+0x30], xmm3
0000792ccedd4b2e  vmovaps [rsp+0x40], xmm4
0000792ccedd4b34  vmovaps [rsp+0x50], xmm5
0000792ccedd4b3a  vmovaps [rsp+0x60], xmm6
0000792ccedd4b40  vmovaps [rsp+0x70], xmm7
0000792ccedd4b46  vmovaps [rsp+0x80], xmm8
0000792ccedd4b4f  vmovaps [rsp+0x90], xmm10
0000792ccedd4b58  vmovaps [rsp+0xA0], xmm11
0000792ccedd4b61  vmovaps [rsp+0xB0], xmm12
0000792ccedd4b6a  vmovaps [rsp+0xC0], xmm13
0000792ccedd4b73  vmovaps [rsp+0xD0], xmm14
0000792ccedd4b7c  vmovaps [rsp+0xE0], xmm15
0000792ccedd4b85  sub rsp, 0x30
0000792ccedd4b89  movaps [rsp], xmm9
0000792ccedd4b8e  movaps [rsp+0x10], xmm1
0000792ccedd4b93  movaps [rsp+0x20], xmm14
0000792ccedd4b99  lea rdi, [rsp]
0000792ccedd4b9d  mov esi, 0x00
0000792ccedd4ba2  mov rax, 0x5AEE2D541530
0000792ccedd4bac  call rax
0000792ccedd4bae  movaps xmm9, [rsp]
0000792ccedd4bb3  add rsp, 0x30
0000792ccedd4bb7  vmovaps xmm0, [rsp]
0000792ccedd4bbc  vmovaps xmm1, [rsp+0x10]
0000792ccedd4bc2  vmovaps xmm2, [rsp+0x20]
0000792ccedd4bc8  vmovaps xmm3, [rsp+0x30]
0000792ccedd4bce  vmovaps xmm4, [rsp+0x40]
0000792ccedd4bd4  vmovaps xmm5, [rsp+0x50]
0000792ccedd4bda  vmovaps xmm6, [rsp+0x60]
0000792ccedd4be0  vmovaps xmm7, [rsp+0x70]
0000792ccedd4be6  vmovaps xmm8, [rsp+0x80]
0000792ccedd4bef  vmovaps xmm10, [rsp+0x90]
0000792ccedd4bf8  vmovaps xmm11, [rsp+0xA0]
0000792ccedd4c01  vmovaps xmm12, [rsp+0xB0]
0000792ccedd4c0a  vmovaps xmm13, [rsp+0xC0]
0000792ccedd4c13  vmovaps xmm14, [rsp+0xD0]
0000792ccedd4c1c  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4c25  add rsp, 0xF0
0000792ccedd4c2c  pop r11
0000792ccedd4c2e  pop r10
0000792ccedd4c30  pop r9
0000792ccedd4c32  pop r8
0000792ccedd4c34  pop rsi
0000792ccedd4c35  pop rdi
0000792ccedd4c36  pop rdx
0000792ccedd4c37  pop rcx
0000792ccedd4c38  pop rax
0000792ccedd4c39  add rsp, 0x08
0000792ccedd4c3d  jmp 0x0000792CCEDD01DD
0000792ccedd4c42  sub rsp, 0x08
0000792ccedd4c46  push rax
0000792ccedd4c47  push rcx
0000792ccedd4c48  push rdx
0000792ccedd4c49  push rdi
0000792ccedd4c4a  push rsi
0000792ccedd4c4b  push r8
0000792ccedd4c4d  push r9
0000792ccedd4c4f  push r10
0000792ccedd4c51  push r11
0000792ccedd4c53  sub rsp, 0xF0
0000792ccedd4c5a  vmovaps [rsp], xmm0
0000792ccedd4c5f  vmovaps [rsp+0x10], xmm1
0000792ccedd4c65  vmovaps [rsp+0x20], xmm2
0000792ccedd4c6b  vmovaps [rsp+0x30], xmm3
0000792ccedd4c71  vmovaps [rsp+0x40], xmm4
0000792ccedd4c77  vmovaps [rsp+0x50], xmm5
0000792ccedd4c7d  vmovaps [rsp+0x60], xmm6
0000792ccedd4c83  vmovaps [rsp+0x70], xmm7
0000792ccedd4c89  vmovaps [rsp+0x80], xmm8
0000792ccedd4c92  vmovaps [rsp+0x90], xmm9
0000792ccedd4c9b  vmovaps [rsp+0xA0], xmm10
0000792ccedd4ca4  vmovaps [rsp+0xB0], xmm11
0000792ccedd4cad  vmovaps [rsp+0xC0], xmm12
0000792ccedd4cb6  vmovaps [rsp+0xD0], xmm13
0000792ccedd4cbf  vmovaps [rsp+0xE0], xmm15
0000792ccedd4cc8  sub rsp, 0x30
0000792ccedd4ccc  movaps [rsp], xmm14
0000792ccedd4cd1  movaps [rsp+0x10], xmm4
0000792ccedd4cd6  movaps [rsp+0x20], xmm1
0000792ccedd4cdb  lea rdi, [rsp]
0000792ccedd4cdf  mov esi, 0x00
0000792ccedd4ce4  mov rax, 0x5AEE2D541530
0000792ccedd4cee  call rax
0000792ccedd4cf0  movaps xmm14, [rsp]
0000792ccedd4cf5  add rsp, 0x30
0000792ccedd4cf9  vmovaps xmm0, [rsp]
0000792ccedd4cfe  vmovaps xmm1, [rsp+0x10]
0000792ccedd4d04  vmovaps xmm2, [rsp+0x20]
0000792ccedd4d0a  vmovaps xmm3, [rsp+0x30]
0000792ccedd4d10  vmovaps xmm4, [rsp+0x40]
0000792ccedd4d16  vmovaps xmm5, [rsp+0x50]
0000792ccedd4d1c  vmovaps xmm6, [rsp+0x60]
0000792ccedd4d22  vmovaps xmm7, [rsp+0x70]
0000792ccedd4d28  vmovaps xmm8, [rsp+0x80]
0000792ccedd4d31  vmovaps xmm9, [rsp+0x90]
0000792ccedd4d3a  vmovaps xmm10, [rsp+0xA0]
0000792ccedd4d43  vmovaps xmm11, [rsp+0xB0]
0000792ccedd4d4c  vmovaps xmm12, [rsp+0xC0]
0000792ccedd4d55  vmovaps xmm13, [rsp+0xD0]
0000792ccedd4d5e  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4d67  add rsp, 0xF0
0000792ccedd4d6e  pop r11
0000792ccedd4d70  pop r10
0000792ccedd4d72  pop r9
0000792ccedd4d74  pop r8
0000792ccedd4d76  pop rsi
0000792ccedd4d77  pop rdi
0000792ccedd4d78  pop rdx
0000792ccedd4d79  pop rcx
0000792ccedd4d7a  pop rax
0000792ccedd4d7b  add rsp, 0x08
0000792ccedd4d7f  jmp 0x0000792CCEDD0203
0000792ccedd4d84  sub rsp, 0x08
0000792ccedd4d88  push rax
0000792ccedd4d89  push rcx
0000792ccedd4d8a  push rdx
0000792ccedd4d8b  push rdi
0000792ccedd4d8c  push rsi
0000792ccedd4d8d  push r8
0000792ccedd4d8f  push r9
0000792ccedd4d91  push r10
0000792ccedd4d93  push r11
0000792ccedd4d95  sub rsp, 0xF0
0000792ccedd4d9c  vmovaps [rsp], xmm0
0000792ccedd4da1  vmovaps [rsp+0x10], xmm2
0000792ccedd4da7  vmovaps [rsp+0x20], xmm3
0000792ccedd4dad  vmovaps [rsp+0x30], xmm4
0000792ccedd4db3  vmovaps [rsp+0x40], xmm5
0000792ccedd4db9  vmovaps [rsp+0x50], xmm6
0000792ccedd4dbf  vmovaps [rsp+0x60], xmm7
0000792ccedd4dc5  vmovaps [rsp+0x70], xmm8
0000792ccedd4dcb  vmovaps [rsp+0x80], xmm9
0000792ccedd4dd4  vmovaps [rsp+0x90], xmm10
0000792ccedd4ddd  vmovaps [rsp+0xA0], xmm11
0000792ccedd4de6  vmovaps [rsp+0xB0], xmm12
0000792ccedd4def  vmovaps [rsp+0xC0], xmm13
0000792ccedd4df8  vmovaps [rsp+0xD0], xmm14
0000792ccedd4e01  vmovaps [rsp+0xE0], xmm15
0000792ccedd4e0a  sub rsp, 0x30
0000792ccedd4e0e  movaps [rsp], xmm1
0000792ccedd4e12  movaps [rsp+0x10], xmm12
0000792ccedd4e18  movaps [rsp+0x20], xmm11
0000792ccedd4e1e  lea rdi, [rsp]
0000792ccedd4e22  mov esi, 0x00
0000792ccedd4e27  mov rax, 0x5AEE2D541530
0000792ccedd4e31  call rax
0000792ccedd4e33  movaps xmm1, [rsp]
0000792ccedd4e37  add rsp, 0x30
0000792ccedd4e3b  vmovaps xmm0, [rsp]
0000792ccedd4e40  vmovaps xmm2, [rsp+0x10]
0000792ccedd4e46  vmovaps xmm3, [rsp+0x20]
0000792ccedd4e4c  vmovaps xmm4, [rsp+0x30]
0000792ccedd4e52  vmovaps xmm5, [rsp+0x40]
0000792ccedd4e58  vmovaps xmm6, [rsp+0x50]
0000792ccedd4e5e  vmovaps xmm7, [rsp+0x60]
0000792ccedd4e64  vmovaps xmm8, [rsp+0x70]
0000792ccedd4e6a  vmovaps xmm9, [rsp+0x80]
0000792ccedd4e73  vmovaps xmm10, [rsp+0x90]
0000792ccedd4e7c  vmovaps xmm11, [rsp+0xA0]
0000792ccedd4e85  vmovaps xmm12, [rsp+0xB0]
0000792ccedd4e8e  vmovaps xmm13, [rsp+0xC0]
0000792ccedd4e97  vmovaps xmm14, [rsp+0xD0]
0000792ccedd4ea0  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4ea9  add rsp, 0xF0
0000792ccedd4eb0  pop r11
0000792ccedd4eb2  pop r10
0000792ccedd4eb4  pop r9
0000792ccedd4eb6  pop r8
0000792ccedd4eb8  pop rsi
0000792ccedd4eb9  pop rdi
0000792ccedd4eba  pop rdx
0000792ccedd4ebb  pop rcx
0000792ccedd4ebc  pop rax
0000792ccedd4ebd  add rsp, 0x08
0000792ccedd4ec1  jmp 0x0000792CCEDD0224
0000792ccedd4ec6  call 0x0000792CCECE20A0
0000792ccedd4ecb  jmp 0x0000792CCEDD0232
0000792ccedd4ed0  call 0x0000792CCEC09D70
0000792ccedd4ed5  jmp 0x0000792CCEDD023C
0000792ccedd4eda  sub rsp, 0x08
0000792ccedd4ede  push rax
0000792ccedd4edf  push rcx
0000792ccedd4ee0  push rdx
0000792ccedd4ee1  push rdi
0000792ccedd4ee2  push rsi
0000792ccedd4ee3  push r8
0000792ccedd4ee5  push r9
0000792ccedd4ee7  push r10
0000792ccedd4ee9  push r11
0000792ccedd4eeb  sub rsp, 0xF0
0000792ccedd4ef2  vmovaps [rsp], xmm0
0000792ccedd4ef7  vmovaps [rsp+0x10], xmm1
0000792ccedd4efd  vmovaps [rsp+0x20], xmm2
0000792ccedd4f03  vmovaps [rsp+0x30], xmm3
0000792ccedd4f09  vmovaps [rsp+0x40], xmm4
0000792ccedd4f0f  vmovaps [rsp+0x50], xmm5
0000792ccedd4f15  vmovaps [rsp+0x60], xmm6
0000792ccedd4f1b  vmovaps [rsp+0x70], xmm8
0000792ccedd4f21  vmovaps [rsp+0x80], xmm9
0000792ccedd4f2a  vmovaps [rsp+0x90], xmm10
0000792ccedd4f33  vmovaps [rsp+0xA0], xmm11
0000792ccedd4f3c  vmovaps [rsp+0xB0], xmm12
0000792ccedd4f45  vmovaps [rsp+0xC0], xmm13
0000792ccedd4f4e  vmovaps [rsp+0xD0], xmm14
0000792ccedd4f57  vmovaps [rsp+0xE0], xmm15
0000792ccedd4f60  sub rsp, 0x30
0000792ccedd4f64  movaps [rsp], xmm7
0000792ccedd4f68  movaps [rsp+0x10], xmm15
0000792ccedd4f6e  movaps [rsp+0x20], xmm10
0000792ccedd4f74  lea rdi, [rsp]
0000792ccedd4f78  mov esi, 0x00
0000792ccedd4f7d  mov rax, 0x5AEE2D541530
0000792ccedd4f87  call rax
0000792ccedd4f89  movaps xmm7, [rsp]
0000792ccedd4f8d  add rsp, 0x30
0000792ccedd4f91  vmovaps xmm0, [rsp]
0000792ccedd4f96  vmovaps xmm1, [rsp+0x10]
0000792ccedd4f9c  vmovaps xmm2, [rsp+0x20]
0000792ccedd4fa2  vmovaps xmm3, [rsp+0x30]
0000792ccedd4fa8  vmovaps xmm4, [rsp+0x40]
0000792ccedd4fae  vmovaps xmm5, [rsp+0x50]
0000792ccedd4fb4  vmovaps xmm6, [rsp+0x60]
0000792ccedd4fba  vmovaps xmm8, [rsp+0x70]
0000792ccedd4fc0  vmovaps xmm9, [rsp+0x80]
0000792ccedd4fc9  vmovaps xmm10, [rsp+0x90]
0000792ccedd4fd2  vmovaps xmm11, [rsp+0xA0]
0000792ccedd4fdb  vmovaps xmm12, [rsp+0xB0]
0000792ccedd4fe4  vmovaps xmm13, [rsp+0xC0]
0000792ccedd4fed  vmovaps xmm14, [rsp+0xD0]
0000792ccedd4ff6  vmovaps xmm15, [rsp+0xE0]
0000792ccedd4fff  add rsp, 0xF0
0000792ccedd5006  pop r11
0000792ccedd5008  pop r10
0000792ccedd500a  pop r9
0000792ccedd500c  pop r8
0000792ccedd500e  pop rsi
0000792ccedd500f  pop rdi
0000792ccedd5010  pop rdx
0000792ccedd5011  pop rcx
0000792ccedd5012  pop rax
0000792ccedd5013  add rsp, 0x08
0000792ccedd5017  jmp 0x0000792CCEDD025D
0000792ccedd501c  sub rsp, 0x08
0000792ccedd5020  push rax
0000792ccedd5021  push rcx
0000792ccedd5022  push rdx
0000792ccedd5023  push rdi
0000792ccedd5024  push rsi
0000792ccedd5025  push r8
0000792ccedd5027  push r9
0000792ccedd5029  push r10
0000792ccedd502b  push r11
0000792ccedd502d  sub rsp, 0xF0
0000792ccedd5034  vmovaps [rsp], xmm0
0000792ccedd5039  vmovaps [rsp+0x10], xmm1
0000792ccedd503f  vmovaps [rsp+0x20], xmm2
0000792ccedd5045  vmovaps [rsp+0x30], xmm3
0000792ccedd504b  vmovaps [rsp+0x40], xmm4
0000792ccedd5051  vmovaps [rsp+0x50], xmm5
0000792ccedd5057  vmovaps [rsp+0x60], xmm6
0000792ccedd505d  vmovaps [rsp+0x70], xmm7
0000792ccedd5063  vmovaps [rsp+0x80], xmm8
0000792ccedd506c  vmovaps [rsp+0x90], xmm9
0000792ccedd5075  vmovaps [rsp+0xA0], xmm11
0000792ccedd507e  vmovaps [rsp+0xB0], xmm12
0000792ccedd5087  vmovaps [rsp+0xC0], xmm13
0000792ccedd5090  vmovaps [rsp+0xD0], xmm14
0000792ccedd5099  vmovaps [rsp+0xE0], xmm15
0000792ccedd50a2  sub rsp, 0x30
0000792ccedd50a6  movaps [rsp], xmm10
0000792ccedd50ab  movaps [rsp+0x10], xmm11
0000792ccedd50b1  movaps [rsp+0x20], xmm15
0000792ccedd50b7  lea rdi, [rsp]
0000792ccedd50bb  mov esi, 0x00
0000792ccedd50c0  mov rax, 0x5AEE2D541530
0000792ccedd50ca  call rax
0000792ccedd50cc  movaps xmm10, [rsp]
0000792ccedd50d1  add rsp, 0x30
0000792ccedd50d5  vmovaps xmm0, [rsp]
0000792ccedd50da  vmovaps xmm1, [rsp+0x10]
0000792ccedd50e0  vmovaps xmm2, [rsp+0x20]
0000792ccedd50e6  vmovaps xmm3, [rsp+0x30]
0000792ccedd50ec  vmovaps xmm4, [rsp+0x40]
0000792ccedd50f2  vmovaps xmm5, [rsp+0x50]
0000792ccedd50f8  vmovaps xmm6, [rsp+0x60]
0000792ccedd50fe  vmovaps xmm7, [rsp+0x70]
0000792ccedd5104  vmovaps xmm8, [rsp+0x80]
0000792ccedd510d  vmovaps xmm9, [rsp+0x90]
0000792ccedd5116  vmovaps xmm11, [rsp+0xA0]
0000792ccedd511f  vmovaps xmm12, [rsp+0xB0]
0000792ccedd5128  vmovaps xmm13, [rsp+0xC0]
0000792ccedd5131  vmovaps xmm14, [rsp+0xD0]
0000792ccedd513a  vmovaps xmm15, [rsp+0xE0]
0000792ccedd5143  add rsp, 0xF0
0000792ccedd514a  pop r11
0000792ccedd514c  pop r10
0000792ccedd514e  pop r9
0000792ccedd5150  pop r8
0000792ccedd5152  pop rsi
0000792ccedd5153  pop rdi
0000792ccedd5154  pop rdx
0000792ccedd5155  pop rcx
0000792ccedd5156  pop rax
0000792ccedd5157  add rsp, 0x08
0000792ccedd515b  jmp 0x0000792CCEDD028B
0000792ccedd5160  sub rsp, 0x08
0000792ccedd5164  push rax
0000792ccedd5165  push rcx
0000792ccedd5166  push rdx
0000792ccedd5167  push rdi
0000792ccedd5168  push rsi
0000792ccedd5169  push r8
0000792ccedd516b  push r9
0000792ccedd516d  push r10
0000792ccedd516f  push r11
0000792ccedd5171  sub rsp, 0xF0
0000792ccedd5178  vmovaps [rsp], xmm0
0000792ccedd517d  vmovaps [rsp+0x10], xmm1
0000792ccedd5183  vmovaps [rsp+0x20], xmm2
0000792ccedd5189  vmovaps [rsp+0x30], xmm3
0000792ccedd518f  vmovaps [rsp+0x40], xmm4
0000792ccedd5195  vmovaps [rsp+0x50], xmm5
0000792ccedd519b  vmovaps [rsp+0x60], xmm6
0000792ccedd51a1  vmovaps [rsp+0x70], xmm7
0000792ccedd51a7  vmovaps [rsp+0x80], xmm8
0000792ccedd51b0  vmovaps [rsp+0x90], xmm9
0000792ccedd51b9  vmovaps [rsp+0xA0], xmm10
0000792ccedd51c2  vmovaps [rsp+0xB0], xmm12
0000792ccedd51cb  vmovaps [rsp+0xC0], xmm13
0000792ccedd51d4  vmovaps [rsp+0xD0], xmm14
0000792ccedd51dd  vmovaps [rsp+0xE0], xmm15
0000792ccedd51e6  sub rsp, 0x30
0000792ccedd51ea  movaps [rsp], xmm11
0000792ccedd51ef  movaps [rsp+0x10], xmm12
0000792ccedd51f5  movaps [rsp+0x20], xmm15
0000792ccedd51fb  lea rdi, [rsp]
0000792ccedd51ff  mov esi, 0x00
0000792ccedd5204  mov rax, 0x5AEE2D541530
0000792ccedd520e  call rax
0000792ccedd5210  movaps xmm11, [rsp]
0000792ccedd5215  add rsp, 0x30
0000792ccedd5219  vmovaps xmm0, [rsp]
0000792ccedd521e  vmovaps xmm1, [rsp+0x10]
0000792ccedd5224  vmovaps xmm2, [rsp+0x20]
0000792ccedd522a  vmovaps xmm3, [rsp+0x30]
0000792ccedd5230  vmovaps xmm4, [rsp+0x40]
0000792ccedd5236  vmovaps xmm5, [rsp+0x50]
0000792ccedd523c  vmovaps xmm6, [rsp+0x60]
0000792ccedd5242  vmovaps xmm7, [rsp+0x70]
0000792ccedd5248  vmovaps xmm8, [rsp+0x80]
0000792ccedd5251  vmovaps xmm9, [rsp+0x90]
0000792ccedd525a  vmovaps xmm10, [rsp+0xA0]
0000792ccedd5263  vmovaps xmm12, [rsp+0xB0]
0000792ccedd526c  vmovaps xmm13, [rsp+0xC0]
0000792ccedd5275  vmovaps xmm14, [rsp+0xD0]
0000792ccedd527e  vmovaps xmm15, [rsp+0xE0]
0000792ccedd5287  add rsp, 0xF0
0000792ccedd528e  pop r11
0000792ccedd5290  pop r10
0000792ccedd5292  pop r9
0000792ccedd5294  pop r8
0000792ccedd5296  pop rsi
0000792ccedd5297  pop rdi
0000792ccedd5298  pop rdx
0000792ccedd5299  pop rcx
0000792ccedd529a  pop rax
0000792ccedd529b  add rsp, 0x08
0000792ccedd529f  jmp 0x0000792CCEDD02B9
0000792ccedd52a4  sub rsp, 0x08
0000792ccedd52a8  push rax
0000792ccedd52a9  push rcx
0000792ccedd52aa  push rdx
0000792ccedd52ab  push rdi
0000792ccedd52ac  push rsi
0000792ccedd52ad  push r8
0000792ccedd52af  push r9
0000792ccedd52b1  push r10
0000792ccedd52b3  push r11
0000792ccedd52b5  sub rsp, 0xF0
0000792ccedd52bc  vmovaps [rsp], xmm0
0000792ccedd52c1  vmovaps [rsp+0x10], xmm1
0000792ccedd52c7  vmovaps [rsp+0x20], xmm2
0000792ccedd52cd  vmovaps [rsp+0x30], xmm3
0000792ccedd52d3  vmovaps [rsp+0x40], xmm4
0000792ccedd52d9  vmovaps [rsp+0x50], xmm5
0000792ccedd52df  vmovaps [rsp+0x60], xmm6
0000792ccedd52e5  vmovaps [rsp+0x70], xmm7
0000792ccedd52eb  vmovaps [rsp+0x80], xmm8
0000792ccedd52f4  vmovaps [rsp+0x90], xmm9
0000792ccedd52fd  vmovaps [rsp+0xA0], xmm10
0000792ccedd5306  vmovaps [rsp+0xB0], xmm11
0000792ccedd530f  vmovaps [rsp+0xC0], xmm12
0000792ccedd5318  vmovaps [rsp+0xD0], xmm13
0000792ccedd5321  vmovaps [rsp+0xE0], xmm14
0000792ccedd532a  sub rsp, 0x30
0000792ccedd532e  movaps [rsp], xmm15
0000792ccedd5333  movaps [rsp+0x10], xmm13
0000792ccedd5339  movaps [rsp+0x20], xmm9
0000792ccedd533f  lea rdi, [rsp]
0000792ccedd5343  mov esi, 0x00
0000792ccedd5348  mov rax, 0x5AEE2D541530
0000792ccedd5352  call rax
0000792ccedd5354  movaps xmm15, [rsp]
0000792ccedd5359  add rsp, 0x30
0000792ccedd535d  vmovaps xmm0, [rsp]
0000792ccedd5362  vmovaps xmm1, [rsp+0x10]
0000792ccedd5368  vmovaps xmm2, [rsp+0x20]
0000792ccedd536e  vmovaps xmm3, [rsp+0x30]
0000792ccedd5374  vmovaps xmm4, [rsp+0x40]
0000792ccedd537a  vmovaps xmm5, [rsp+0x50]
0000792ccedd5380  vmovaps xmm6, [rsp+0x60]
0000792ccedd5386  vmovaps xmm7, [rsp+0x70]
0000792ccedd538c  vmovaps xmm8, [rsp+0x80]
0000792ccedd5395  vmovaps xmm9, [rsp+0x90]
0000792ccedd539e  vmovaps xmm10, [rsp+0xA0]
0000792ccedd53a7  vmovaps xmm11, [rsp+0xB0]
0000792ccedd53b0  vmovaps xmm12, [rsp+0xC0]
0000792ccedd53b9  vmovaps xmm13, [rsp+0xD0]
0000792ccedd53c2  vmovaps xmm14, [rsp+0xE0]
0000792ccedd53cb  add rsp, 0xF0
0000792ccedd53d2  pop r11
0000792ccedd53d4  pop r10
0000792ccedd53d6  pop r9
0000792ccedd53d8  pop r8
0000792ccedd53da  pop rsi
0000792ccedd53db  pop rdi
0000792ccedd53dc  pop rdx
0000792ccedd53dd  pop rcx
0000792ccedd53de  pop rax
0000792ccedd53df  add rsp, 0x08
0000792ccedd53e3  jmp 0x0000792CCEDD02D4
0000792ccedd53e8  sub rsp, 0x08
0000792ccedd53ec  push rax
0000792ccedd53ed  push rcx
0000792ccedd53ee  push rdx
0000792ccedd53ef  push rdi
0000792ccedd53f0  push rsi
0000792ccedd53f1  push r8
0000792ccedd53f3  push r9
0000792ccedd53f5  push r10
0000792ccedd53f7  push r11
0000792ccedd53f9  sub rsp, 0xF0
0000792ccedd5400  vmovaps [rsp], xmm0
0000792ccedd5405  vmovaps [rsp+0x10], xmm1
0000792ccedd540b  vmovaps [rsp+0x20], xmm2
0000792ccedd5411  vmovaps [rsp+0x30], xmm3
0000792ccedd5417  vmovaps [rsp+0x40], xmm4
0000792ccedd541d  vmovaps [rsp+0x50], xmm5
0000792ccedd5423  vmovaps [rsp+0x60], xmm6
0000792ccedd5429  vmovaps [rsp+0x70], xmm7
0000792ccedd542f  vmovaps [rsp+0x80], xmm8
0000792ccedd5438  vmovaps [rsp+0x90], xmm9
0000792ccedd5441  vmovaps [rsp+0xA0], xmm10
0000792ccedd544a  vmovaps [rsp+0xB0], xmm11
0000792ccedd5453  vmovaps [rsp+0xC0], xmm12
0000792ccedd545c  vmovaps [rsp+0xD0], xmm14
0000792ccedd5465  vmovaps [rsp+0xE0], xmm15
0000792ccedd546e  sub rsp, 0x30
0000792ccedd5472  movaps [rsp], xmm13
0000792ccedd5477  movaps [rsp+0x10], xmm8
0000792ccedd547d  movaps [rsp+0x20], xmm14
0000792ccedd5483  lea rdi, [rsp]
0000792ccedd5487  mov esi, 0x00
0000792ccedd548c  mov rax, 0x5AEE2D541530
0000792ccedd5496  call rax
0000792ccedd5498  movaps xmm13, [rsp]
0000792ccedd549d  add rsp, 0x30
0000792ccedd54a1  vmovaps xmm0, [rsp]
0000792ccedd54a6  vmovaps xmm1, [rsp+0x10]
0000792ccedd54ac  vmovaps xmm2, [rsp+0x20]
0000792ccedd54b2  vmovaps xmm3, [rsp+0x30]
0000792ccedd54b8  vmovaps xmm4, [rsp+0x40]
0000792ccedd54be  vmovaps xmm5, [rsp+0x50]
0000792ccedd54c4  vmovaps xmm6, [rsp+0x60]
0000792ccedd54ca  vmovaps xmm7, [rsp+0x70]
0000792ccedd54d0  vmovaps xmm8, [rsp+0x80]
0000792ccedd54d9  vmovaps xmm9, [rsp+0x90]
0000792ccedd54e2  vmovaps xmm10, [rsp+0xA0]
0000792ccedd54eb  vmovaps xmm11, [rsp+0xB0]
0000792ccedd54f4  vmovaps xmm12, [rsp+0xC0]
0000792ccedd54fd  vmovaps xmm14, [rsp+0xD0]
0000792ccedd5506  vmovaps xmm15, [rsp+0xE0]
0000792ccedd550f  add rsp, 0xF0
0000792ccedd5516  pop r11
0000792ccedd5518  pop r10
0000792ccedd551a  pop r9
0000792ccedd551c  pop r8
0000792ccedd551e  pop rsi
0000792ccedd551f  pop rdi
0000792ccedd5520  pop rdx
0000792ccedd5521  pop rcx
0000792ccedd5522  pop rax
0000792ccedd5523  add rsp, 0x08
0000792ccedd5527  jmp 0x0000792CCEDD02F7
0000792ccedd552c  sub rsp, 0x08
0000792ccedd5530  push rax
0000792ccedd5531  push rcx
0000792ccedd5532  push rdx
0000792ccedd5533  push rdi
0000792ccedd5534  push rsi
0000792ccedd5535  push r8
0000792ccedd5537  push r9
0000792ccedd5539  push r10
0000792ccedd553b  push r11
0000792ccedd553d  sub rsp, 0xF0
0000792ccedd5544  vmovaps [rsp], xmm0
0000792ccedd5549  vmovaps [rsp+0x10], xmm1
0000792ccedd554f  vmovaps [rsp+0x20], xmm2
0000792ccedd5555  vmovaps [rsp+0x30], xmm3
0000792ccedd555b  vmovaps [rsp+0x40], xmm4
0000792ccedd5561  vmovaps [rsp+0x50], xmm5
0000792ccedd5567  vmovaps [rsp+0x60], xmm6
0000792ccedd556d  vmovaps [rsp+0x70], xmm7
0000792ccedd5573  vmovaps [rsp+0x80], xmm8
0000792ccedd557c  vmovaps [rsp+0x90], xmm9
0000792ccedd5585  vmovaps [rsp+0xA0], xmm10
0000792ccedd558e  vmovaps [rsp+0xB0], xmm11
0000792ccedd5597  vmovaps [rsp+0xC0], xmm12
0000792ccedd55a0  vmovaps [rsp+0xD0], xmm13
0000792ccedd55a9  vmovaps [rsp+0xE0], xmm15
0000792ccedd55b2  sub rsp, 0x30
0000792ccedd55b6  movaps [rsp], xmm14
0000792ccedd55bb  movaps [rsp+0x10], xmm1
0000792ccedd55c0  movaps [rsp+0x20], xmm10
0000792ccedd55c6  lea rdi, [rsp]
0000792ccedd55ca  mov esi, 0x00
0000792ccedd55cf  mov rax, 0x5AEE2D541530
0000792ccedd55d9  call rax
0000792ccedd55db  movaps xmm14, [rsp]
0000792ccedd55e0  add rsp, 0x30
0000792ccedd55e4  vmovaps xmm0, [rsp]
0000792ccedd55e9  vmovaps xmm1, [rsp+0x10]
0000792ccedd55ef  vmovaps xmm2, [rsp+0x20]
0000792ccedd55f5  vmovaps xmm3, [rsp+0x30]
0000792ccedd55fb  vmovaps xmm4, [rsp+0x40]
0000792ccedd5601  vmovaps xmm5, [rsp+0x50]
0000792ccedd5607  vmovaps xmm6, [rsp+0x60]
0000792ccedd560d  vmovaps xmm7, [rsp+0x70]
0000792ccedd5613  vmovaps xmm8, [rsp+0x80]
0000792ccedd561c  vmovaps xmm9, [rsp+0x90]
0000792ccedd5625  vmovaps xmm10, [rsp+0xA0]
0000792ccedd562e  vmovaps xmm11, [rsp+0xB0]
0000792ccedd5637  vmovaps xmm12, [rsp+0xC0]
0000792ccedd5640  vmovaps xmm13, [rsp+0xD0]
0000792ccedd5649  vmovaps xmm15, [rsp+0xE0]
0000792ccedd5652  add rsp, 0xF0
0000792ccedd5659  pop r11
0000792ccedd565b  pop r10
0000792ccedd565d  pop r9
0000792ccedd565f  pop r8
0000792ccedd5661  pop rsi
0000792ccedd5662  pop rdi
0000792ccedd5663  pop rdx
0000792ccedd5664  pop rcx
0000792ccedd5665  pop rax
0000792ccedd5666  add rsp, 0x08
0000792ccedd566a  jmp 0x0000792CCEDD031A
0000792ccedd566f  sub rsp, 0x08
0000792ccedd5673  push rax
0000792ccedd5674  push rcx
0000792ccedd5675  push rdx
0000792ccedd5676  push rdi
0000792ccedd5677  push rsi
0000792ccedd5678  push r8
0000792ccedd567a  push r9
0000792ccedd567c  push r10
0000792ccedd567e  push r11
0000792ccedd5680  sub rsp, 0xF0
0000792ccedd5687  vmovaps [rsp], xmm0
0000792ccedd568c  vmovaps [rsp+0x10], xmm2
0000792ccedd5692  vmovaps [rsp+0x20], xmm3
0000792ccedd5698  vmovaps [rsp+0x30], xmm4
0000792ccedd569e  vmovaps [rsp+0x40], xmm5
0000792ccedd56a4  vmovaps [rsp+0x50], xmm6
0000792ccedd56aa  vmovaps [rsp+0x60], xmm7
0000792ccedd56b0  vmovaps [rsp+0x70], xmm8
0000792ccedd56b6  vmovaps [rsp+0x80], xmm9
0000792ccedd56bf  vmovaps [rsp+0x90], xmm10
0000792ccedd56c8  vmovaps [rsp+0xA0], xmm11
0000792ccedd56d1  vmovaps [rsp+0xB0], xmm12
0000792ccedd56da  vmovaps [rsp+0xC0], xmm13
0000792ccedd56e3  vmovaps [rsp+0xD0], xmm14
0000792ccedd56ec  vmovaps [rsp+0xE0], xmm15
0000792ccedd56f5  sub rsp, 0x30
0000792ccedd56f9  movaps [rsp], xmm1
0000792ccedd56fd  movaps [rsp+0x10], xmm7
0000792ccedd5702  movaps [rsp+0x20], xmm11
0000792ccedd5708  lea rdi, [rsp]
0000792ccedd570c  mov esi, 0x00
0000792ccedd5711  mov rax, 0x5AEE2D541530
0000792ccedd571b  call rax
0000792ccedd571d  movaps xmm1, [rsp]
0000792ccedd5721  add rsp, 0x30
0000792ccedd5725  vmovaps xmm0, [rsp]
0000792ccedd572a  vmovaps xmm2, [rsp+0x10]
0000792ccedd5730  vmovaps xmm3, [rsp+0x20]
0000792ccedd5736  vmovaps xmm4, [rsp+0x30]
0000792ccedd573c  vmovaps xmm5, [rsp+0x40]
0000792ccedd5742  vmovaps xmm6, [rsp+0x50]
0000792ccedd5748  vmovaps xmm7, [rsp+0x60]
0000792ccedd574e  vmovaps xmm8, [rsp+0x70]
0000792ccedd5754  vmovaps xmm9, [rsp+0x80]
0000792ccedd575d  vmovaps xmm10, [rsp+0x90]
0000792ccedd5766  vmovaps xmm11, [rsp+0xA0]
0000792ccedd576f  vmovaps xmm12, [rsp+0xB0]
0000792ccedd5778  vmovaps xmm13, [rsp+0xC0]
0000792ccedd5781  vmovaps xmm14, [rsp+0xD0]
0000792ccedd578a  vmovaps xmm15, [rsp+0xE0]
0000792ccedd5793  add rsp, 0xF0
0000792ccedd579a  pop r11
0000792ccedd579c  pop r10
0000792ccedd579e  pop r9
0000792ccedd57a0  pop r8
0000792ccedd57a2  pop rsi
0000792ccedd57a3  pop rdi
0000792ccedd57a4  pop rdx
0000792ccedd57a5  pop rcx
0000792ccedd57a6  pop rax
0000792ccedd57a7  add rsp, 0x08
0000792ccedd57ab  jmp 0x0000792CCEDD033B
0000792ccedd57b0  call 0x0000792CCEC0E880
0000792ccedd57b5  jmp 0x0000792CCEDD034E
0000792ccedd57ba  call 0x0000792CCEC0C380
0000792ccedd57bf  jmp 0x0000792CCEDD0359
0000792ccedd57c4  call 0x0000792CCEC0D600
0000792ccedd57c9  jmp 0x0000792CCEDD0364
0000792ccedd57ce  call 0x0000792CCEBFF540
0000792ccedd57d3  jmp 0x0000792CCEDD036F
0000792ccedd57d8  int3
0000792ccedd57d9  nop [rax], eax
0000792ccedd57e0  mov rax, [r15+0x40]
0000792ccedd57e4  mov r14, [r15+0x58]
0000792ccedd57e8  lea r12, [rax+r14*1]
0000792ccedd57ec  movaps xmm1, [r15+0x1D0]
0000792ccedd57f4  vmovaps [rsp+0x10], xmm1
0000792ccedd57fa  vmovaps xmm15, [rsp+0x10]
0000792ccedd5800  por xmm1, xmm15
0000792ccedd5805  movaps xmm14, [r15+0x1A0]
0000792ccedd580d  vmovaps [rsp+0x10], xmm14
0000792ccedd5813  vmovaps xmm13, [rsp+0x10]
0000792ccedd5819  por xmm14, xmm13
0000792ccedd581e  lea rax, [r12+0x30]
0000792ccedd5823  mov r11, [r13+rax*1]
0000792ccedd5828  lea rax, [r12+0x38]
0000792ccedd582d  mov r10, [r13+rax*1]
0000792ccedd5832  movq xmm13, r11
0000792ccedd5837  movq xmm12, r10
0000792ccedd583c  movq xmm13, xmm13
0000792ccedd5841  vmovaps [rsp+0x10], xmm13
0000792ccedd5847  movq xmm13, xmm13
0000792ccedd584c  movaps [r15+0x130], xmm13
0000792ccedd5854  movq xmm12, xmm12
0000792ccedd5859  vmovaps [rsp+0x20], xmm12
0000792ccedd585f  movq xmm12, xmm12
0000792ccedd5864  movaps [r15+0x280], xmm12
0000792ccedd586c  movaps xmm13, [r15+0x270]
0000792ccedd5874  vmovaps [rsp+0x30], xmm13
0000792ccedd587a  vmovaps xmm12, [rsp+0x30]
0000792ccedd5880  por xmm13, xmm12
0000792ccedd5885  lea rax, [r12+0x20]
0000792ccedd588a  mov r11, [r13+rax*1]
0000792ccedd588f  lea rax, [r12+0x28]
0000792ccedd5894  mov r10, [r13+rax*1]
0000792ccedd5899  movq xmm12, r11
0000792ccedd589e  movq xmm11, r10
0000792ccedd58a3  movq xmm12, xmm12
0000792ccedd58a8  vmovaps [rsp+0x30], xmm12
0000792ccedd58ae  movq xmm12, xmm12
0000792ccedd58b3  movaps [r15+0x150], xmm12
0000792ccedd58bb  movq xmm11, xmm11
0000792ccedd58c0  vmovaps [rsp+0x40], xmm11
0000792ccedd58c6  movq xmm11, xmm11
0000792ccedd58cb  movaps [r15+0x140], xmm11
0000792ccedd58d3  lea rax, [r12+0x10]
0000792ccedd58d8  mov r11, [r13+rax*1]
0000792ccedd58dd  lea rax, [r12+0x18]
0000792ccedd58e2  mov r10, [r13+rax*1]
0000792ccedd58e7  movq xmm12, r11
0000792ccedd58ec  movq xmm11, r10
0000792ccedd58f1  movq xmm12, xmm12
0000792ccedd58f6  vmovaps [rsp+0x50], xmm12
0000792ccedd58fc  movq xmm12, xmm12
0000792ccedd5901  movaps [r15+0x170], xmm12
0000792ccedd5909  movq xmm11, xmm11
0000792ccedd590e  vmovaps [rsp+0x60], xmm11
0000792ccedd5914  movq xmm11, xmm11
0000792ccedd5919  movaps [r15+0x160], xmm11
0000792ccedd5921  mov rax, [r13+r12*1]
0000792ccedd5926  vmovq xmm12, rax
0000792ccedd592b  vpbroadcastq xmm12, xmm12
0000792ccedd5930  lea rax, [r12+0x08]
0000792ccedd5935  mov r12, [r13+rax*1]
0000792ccedd593a  movq xmm11, r12
0000792ccedd593f  movaps [r15+0x230], xmm11
0000792ccedd5947  mov rax, [r15+0xF8]
0000792ccedd594e  lea r12, [rax+0x50]
0000792ccedd5952  movups xmm11, [r13+r12*1]
0000792ccedd5958  lea r12, [rax+0x60]
0000792ccedd595c  movups xmm10, [r13+r12*1]
0000792ccedd5962  lea r12, [rax+0x30]
0000792ccedd5966  movups xmm9, [r13+r12*1]
0000792ccedd596c  mov r12, [r15+0x50]
0000792ccedd5970  lea r11, [r12+r14*1]
0000792ccedd5974  mov [r15+0x60], r11
0000792ccedd5978  lea r12, [r14+0x40]
0000792ccedd597c  mov [r15+0x58], r12
0000792ccedd5980  movaps xmm8, xmm12
0000792ccedd5984  mulpd xmm8, xmm15
0000792ccedd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000792ccedd598f  ptest xmm7, xmm7
0000792ccedd5994  jnz 0x0000792CCEDD67B7
0000792ccedd599a  movq xmm15, qword ptr [r15+0x230]
0000792ccedd59a3  vmovaps [rsp+0x70], xmm15
0000792ccedd59a9  vpermilpd xmm15, xmm15, 0x00
0000792ccedd59af  movaps xmm7, xmm9
0000792ccedd59b3  mulpd xmm7, xmm15
0000792ccedd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000792ccedd59bd  ptest xmm6, xmm6
0000792ccedd59c2  jnz 0x0000792CCEDD68FB
0000792ccedd59c8  vxorps xmm15, xmm15, xmm15
0000792ccedd59cd  vpbroadcastq xmm15, xmm15
0000792ccedd59d2  movaps xmm9, xmm12
0000792ccedd59d6  mulpd xmm9, xmm10
0000792ccedd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000792ccedd59e1  ptest xmm6, xmm6
0000792ccedd59e6  jnz 0x0000792CCEDD6A3D
0000792ccedd59ec  movaps xmm10, xmm12
0000792ccedd59f0  mulpd xmm10, xmm11
0000792ccedd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000792ccedd59fb  ptest xmm6, xmm6
0000792ccedd5a00  jnz 0x0000792CCEDD6B81
0000792ccedd5a06  movaps xmm11, [r15+0x1F0]
0000792ccedd5a0e  movaps xmm6, xmm12
0000792ccedd5a12  mulpd xmm6, xmm11
0000792ccedd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000792ccedd5a1c  ptest xmm5, xmm5
0000792ccedd5a21  jnz 0x0000792CCEDD6CC5
0000792ccedd5a27  movaps xmm12, [r15+0x2A0]
0000792ccedd5a2f  vmovaps [rsp+0x80], xmm12
0000792ccedd5a38  vmovaps xmm11, [rsp+0x80]
0000792ccedd5a41  por xmm12, xmm11
0000792ccedd5a46  movaps xmm11, [r15+0x250]
0000792ccedd5a4e  vmovaps [rsp+0x80], xmm11
0000792ccedd5a57  vmovaps xmm5, [rsp+0x80]
0000792ccedd5a60  por xmm11, xmm5
0000792ccedd5a65  vmovaps xmm4, [rsp+0x70]
0000792ccedd5a6b  vpermilpd xmm4, xmm4, 0x00
0000792ccedd5a71  movaps xmm3, xmm5
0000792ccedd5a74  mulpd xmm3, xmm4
0000792ccedd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000792ccedd5a7d  ptest xmm2, xmm2
0000792ccedd5a82  jnz 0x0000792CCEDD6E07
0000792ccedd5a88  mov [rsp+0x80], rax
0000792ccedd5a90  xor eax, eax
0000792ccedd5a92  mov r14d, 0x200
0000792ccedd5a98  cmp r12, r14
0000792ccedd5a9b  cmc
0000792ccedd5a9c  lahf
0000792ccedd5a9d  seto al
0000792ccedd5aa0  mov [r15+0x108], eax
0000792ccedd5aa7  movaps xmm5, xmm8
0000792ccedd5aab  addpd xmm5, xmm15
0000792ccedd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000792ccedd5ab5  ptest xmm4, xmm4
0000792ccedd5aba  jnz 0x0000792CCEDD6F47
0000792ccedd5ac0  movaps xmm8, [r15+0x1B0]
0000792ccedd5ac8  movaps xmm4, xmm9
0000792ccedd5acc  addpd xmm4, xmm8
0000792ccedd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000792ccedd5ad6  ptest xmm2, xmm2
0000792ccedd5adb  jnz 0x0000792CCEDD7089
0000792ccedd5ae1  movaps xmm9, xmm10
0000792ccedd5ae5  addpd xmm9, xmm8
0000792ccedd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000792ccedd5af0  ptest xmm2, xmm2
0000792ccedd5af5  jnz 0x0000792CCEDD71CB
0000792ccedd5afb  movaps xmm10, [r15+0x2F0]
0000792ccedd5b03  vmovaps [rsp+0x90], xmm10
0000792ccedd5b0c  vmovaps xmm8, [rsp+0x90]
0000792ccedd5b15  por xmm10, xmm8
0000792ccedd5b1a  movaps xmm8, [r15+0x2E0]
0000792ccedd5b22  vmovaps [rsp+0x90], xmm8
0000792ccedd5b2b  vmovaps xmm2, [rsp+0x90]
0000792ccedd5b34  por xmm8, xmm2
0000792ccedd5b39  movaps xmm2, [r15+0x2D0]
0000792ccedd5b41  vmovaps [rsp+0x90], xmm2
0000792ccedd5b4a  vmovaps [rsp+0xA0], xmm1
0000792ccedd5b53  vmovaps xmm1, [rsp+0x90]
0000792ccedd5b5c  por xmm2, xmm1
0000792ccedd5b60  movaps xmm1, [r15+0x200]
0000792ccedd5b68  vmovaps [rsp+0x90], xmm1
0000792ccedd5b71  vmovaps [rsp+0xB0], xmm15
0000792ccedd5b7a  vmovaps xmm15, [rsp+0x90]
0000792ccedd5b83  por xmm1, xmm15
0000792ccedd5b88  movaps xmm15, [r15+0x1C0]
0000792ccedd5b90  vmovaps [rsp+0x90], xmm15
0000792ccedd5b99  vmovaps [rsp+0xC0], xmm1
0000792ccedd5ba2  vmovaps xmm1, [rsp+0x90]
0000792ccedd5bab  por xmm15, xmm1
0000792ccedd5bb0  movaps xmm1, [r15+0x190]
0000792ccedd5bb8  vmovaps [rsp+0x90], xmm1
0000792ccedd5bc1  vmovaps [rsp+0xD0], xmm15
0000792ccedd5bca  vmovaps xmm15, [rsp+0x90]
0000792ccedd5bd3  por xmm1, xmm15
0000792ccedd5bd8  movaps xmm15, [r15+0x300]
0000792ccedd5be0  vmovaps [rsp+0x90], xmm15
0000792ccedd5be9  vmovaps [rsp+0xE0], xmm1
0000792ccedd5bf2  vmovaps xmm1, [rsp+0x90]
0000792ccedd5bfb  por xmm15, xmm1
0000792ccedd5c00  mov rax, [rsp+0x80]
0000792ccedd5c08  lea r14, [rax+0xA0]
0000792ccedd5c0f  movups xmm1, [r13+r14*1]
0000792ccedd5c15  lea r14, [rax+0xB0]
0000792ccedd5c1c  vmovaps [rsp+0x80], xmm1
0000792ccedd5c25  movups xmm1, [r13+r14*1]
0000792ccedd5c2b  vmovaps [rsp+0x90], xmm1
0000792ccedd5c34  vmovaps [rsp+0xF0], xmm15
0000792ccedd5c3d  vmovaps xmm15, [rsp+0xB0]
0000792ccedd5c46  vmovaps [rsp+0xB0], xmm14
0000792ccedd5c4f  movaps xmm1, xmm6
0000792ccedd5c52  addpd xmm1, xmm15
0000792ccedd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000792ccedd5c5c  ptest xmm14, xmm14
0000792ccedd5c62  jnz 0x0000792CCEDD7323
0000792ccedd5c68  lea r14, [rax+0xF0]
0000792ccedd5c6f  movups xmm15, [r13+r14*1]
0000792ccedd5c75  movaps xmm14, xmm4
0000792ccedd5c79  addpd xmm14, xmm3
0000792ccedd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000792ccedd5c84  ptest xmm6, xmm6
0000792ccedd5c89  jnz 0x0000792CCEDD746E
0000792ccedd5c8f  movaps xmm6, xmm9
0000792ccedd5c93  addpd xmm6, xmm7
0000792ccedd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000792ccedd5c9c  ptest xmm4, xmm4
0000792ccedd5ca1  jnz 0x0000792CCEDD75B0
0000792ccedd5ca7  vmovaps xmm9, [rsp+0x70]
0000792ccedd5cad  vpermilpd xmm9, xmm9, 0x00
0000792ccedd5cb3  vmovaps xmm4, [rsp+0x90]
0000792ccedd5cbc  movaps xmm7, xmm4
0000792ccedd5cbf  mulpd xmm7, xmm9
0000792ccedd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000792ccedd5cc9  ptest xmm3, xmm3
0000792ccedd5cce  jnz 0x0000792CCEDD76F1
0000792ccedd5cd4  vmovaps xmm9, [rsp+0x50]
0000792ccedd5cda  vpermilpd xmm9, xmm9, 0x00
0000792ccedd5ce0  movaps xmm4, xmm15
0000792ccedd5ce4  mulpd xmm4, xmm9
0000792ccedd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000792ccedd5cee  ptest xmm3, xmm3
0000792ccedd5cf3  jnz 0x0000792CCEDD7832
0000792ccedd5cf9  lea r14, [rax+0xE0]
0000792ccedd5d00  movups xmm15, [r13+r14*1]
0000792ccedd5d06  vmovaps xmm9, [rsp+0x70]
0000792ccedd5d0c  vpermilpd xmm9, xmm9, 0x00
0000792ccedd5d12  vmovaps [rsp+0x70], xmm1
0000792ccedd5d18  vmovaps xmm1, [rsp+0x80]
0000792ccedd5d21  vmovaps [rsp+0x80], xmm15
0000792ccedd5d2a  movaps xmm3, xmm1
0000792ccedd5d2d  mulpd xmm3, xmm9
0000792ccedd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000792ccedd5d37  ptest xmm15, xmm15
0000792ccedd5d3d  jnz 0x0000792CCEDD797E
0000792ccedd5d43  vmovaps xmm1, [rsp+0xF0]
0000792ccedd5d4c  vmovaps xmm15, [rsp+0xF0]
0000792ccedd5d55  por xmm1, xmm15
0000792ccedd5d5a  movaps [r15+0x300], xmm1
0000792ccedd5d62  vmovaps xmm15, [rsp+0xE0]
0000792ccedd5d6b  vmovaps xmm9, [rsp+0xE0]
0000792ccedd5d74  por xmm15, xmm9
0000792ccedd5d79  movaps [r15+0x190], xmm15
0000792ccedd5d81  vmovaps xmm9, [rsp+0x50]
0000792ccedd5d87  vpermilpd xmm9, xmm9, 0x00
0000792ccedd5d8d  vmovaps [rsp+0x90], xmm1
0000792ccedd5d96  vmovaps [rsp+0xE0], xmm15
0000792ccedd5d9f  vmovaps xmm15, [rsp+0x80]
0000792ccedd5da8  vmovaps [rsp+0x80], xmm14
0000792ccedd5db1  movaps xmm1, xmm15
0000792ccedd5db5  mulpd xmm1, xmm9
0000792ccedd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000792ccedd5dbf  ptest xmm14, xmm14
0000792ccedd5dc5  jnz 0x0000792CCEDD7ABF
0000792ccedd5dcb  lea r14, [rax+0x90]
0000792ccedd5dd2  movups xmm15, [r13+r14*1]
0000792ccedd5dd8  vmovaps xmm14, [rsp+0xD0]
0000792ccedd5de1  vmovaps xmm9, [rsp+0xD0]
0000792ccedd5dea  por xmm14, xmm9
0000792ccedd5def  movaps [r15+0x1C0], xmm14
0000792ccedd5df7  vmovaps xmm9, [rsp+0xC0]
0000792ccedd5e00  vmovaps [rsp+0xD0], xmm1
0000792ccedd5e09  vmovaps xmm1, [rsp+0xC0]
0000792ccedd5e12  por xmm9, xmm1
0000792ccedd5e17  movaps [r15+0x200], xmm9
0000792ccedd5e1f  vmovaps [rsp+0xC0], xmm2
0000792ccedd5e28  vmovaps xmm1, [rsp+0xC0]
0000792ccedd5e31  por xmm2, xmm1
0000792ccedd5e35  movaps [r15+0x2D0], xmm2
0000792ccedd5e3d  vmovaps [rsp+0xC0], xmm8
0000792ccedd5e46  vmovaps xmm1, [rsp+0xC0]
0000792ccedd5e4f  por xmm8, xmm1
0000792ccedd5e54  movaps [r15+0x2E0], xmm8
0000792ccedd5e5c  vmovaps [rsp+0xC0], xmm15
0000792ccedd5e65  movaps xmm1, xmm5
0000792ccedd5e68  addpd xmm1, xmm7
0000792ccedd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000792ccedd5e71  ptest xmm15, xmm15
0000792ccedd5e77  jnz 0x0000792CCEDD7C0B
0000792ccedd5e7d  vmovaps xmm15, [rsp+0x50]
0000792ccedd5e83  vpermilpd xmm15, xmm15, 0x00
0000792ccedd5e89  vmovaps xmm5, [rsp+0xC0]
0000792ccedd5e92  vmovaps [rsp+0xC0], xmm1
0000792ccedd5e9b  movaps xmm7, xmm5
0000792ccedd5e9e  mulpd xmm7, xmm15
0000792ccedd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000792ccedd5ea8  ptest xmm1, xmm1
0000792ccedd5ead  jnz 0x0000792CCEDD7D4B
0000792ccedd5eb3  lea r14, [rax+0x80]
0000792ccedd5eba  movups xmm1, [r13+r14*1]
0000792ccedd5ec0  vmovaps xmm5, [rsp+0x70]
0000792ccedd5ec6  vmovaps [rsp+0x70], xmm1
0000792ccedd5ecc  movaps xmm15, xmm5
0000792ccedd5ed0  addpd xmm15, xmm3
0000792ccedd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000792ccedd5edb  ptest xmm1, xmm1
0000792ccedd5ee0  jnz 0x0000792CCEDD7E96
0000792ccedd5ee6  vmovaps xmm5, [rsp+0x80]
0000792ccedd5eef  movaps xmm1, xmm5
0000792ccedd5ef2  addpd xmm1, xmm4
0000792ccedd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000792ccedd5efb  ptest xmm3, xmm3
0000792ccedd5f00  jnz 0x0000792CCEDD7FD8
0000792ccedd5f06  vmovaps [rsp+0x80], xmm10
0000792ccedd5f0f  vmovaps xmm5, [rsp+0x80]
0000792ccedd5f18  por xmm10, xmm5
0000792ccedd5f1d  movaps [r15+0x2F0], xmm10
0000792ccedd5f25  vmovaps xmm5, [rsp+0x50]
0000792ccedd5f2b  vpermilpd xmm5, xmm5, 0x00
0000792ccedd5f31  vmovaps xmm3, [rsp+0x70]
0000792ccedd5f37  vmovaps [rsp+0x50], xmm1
0000792ccedd5f3d  movaps xmm4, xmm3
0000792ccedd5f40  mulpd xmm4, xmm5
0000792ccedd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000792ccedd5f49  ptest xmm1, xmm1
0000792ccedd5f4e  jnz 0x0000792CCEDD8118
0000792ccedd5f54  lea r14, [rax+0xD0]
0000792ccedd5f5b  movups xmm1, [r13+r14*1]
0000792ccedd5f61  vmovaps xmm3, [rsp+0xD0]
0000792ccedd5f6a  vmovaps [rsp+0x70], xmm1
0000792ccedd5f70  movaps xmm5, xmm6
0000792ccedd5f73  addpd xmm5, xmm3
0000792ccedd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000792ccedd5f7c  ptest xmm1, xmm1
0000792ccedd5f81  jnz 0x0000792CCEDD8262
0000792ccedd5f87  vmovaps xmm1, [rsp+0x60]
0000792ccedd5f8d  vpermilpd xmm1, xmm1, 0x00
0000792ccedd5f93  movaps xmm6, xmm9
0000792ccedd5f97  mulpd xmm6, xmm1
0000792ccedd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000792ccedd5fa0  ptest xmm3, xmm3
0000792ccedd5fa5  jnz 0x0000792CCEDD83A2
0000792ccedd5fab  movaps [r15+0x260], xmm6
0000792ccedd5fb3  vxorps xmm1, xmm1, xmm1
0000792ccedd5fb7  vpbroadcastq xmm1, xmm1
0000792ccedd5fbc  movaps [r15+0x1B0], xmm1
0000792ccedd5fc4  vmovaps xmm1, [rsp+0x60]
0000792ccedd5fca  vpermilpd xmm1, xmm1, 0x00
0000792ccedd5fd0  vmovaps xmm3, [rsp+0x70]
0000792ccedd5fd6  vmovaps [rsp+0x70], xmm15
0000792ccedd5fdc  movaps xmm9, xmm3
0000792ccedd5fe0  mulpd xmm9, xmm1
0000792ccedd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000792ccedd5feb  ptest xmm15, xmm15
0000792ccedd5ff1  jnz 0x0000792CCEDD84E3
0000792ccedd5ff7  lea r14, [rax+0xC0]
0000792ccedd5ffe  movups xmm1, [r13+r14*1]
0000792ccedd6004  vmovaps xmm3, [rsp+0xC0]
0000792ccedd600d  vmovaps [rsp+0x80], xmm1
0000792ccedd6016  movaps xmm15, xmm3
0000792ccedd601a  addpd xmm15, xmm7
0000792ccedd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000792ccedd6025  ptest xmm1, xmm1
0000792ccedd602a  jnz 0x0000792CCEDD862F
0000792ccedd6030  vmovaps [rsp+0xC0], xmm13
0000792ccedd6039  vmovaps xmm1, [rsp+0xC0]
0000792ccedd6042  por xmm13, xmm1
0000792ccedd6047  movaps [r15+0x270], xmm13
0000792ccedd604f  vmovaps xmm1, [rsp+0xB0]
0000792ccedd6058  vmovaps xmm7, [rsp+0xB0]
0000792ccedd6061  por xmm1, xmm7
0000792ccedd6065  movaps [r15+0x1A0], xmm1
0000792ccedd606d  vmovaps xmm1, [rsp+0x60]
0000792ccedd6073  vpermilpd xmm1, xmm1, 0x00
0000792ccedd6079  vmovaps [rsp+0xB0], xmm1
0000792ccedd6082  vmovaps xmm1, [rsp+0x80]
0000792ccedd608b  vmovaps [rsp+0x80], xmm15
0000792ccedd6094  vmovaps xmm15, [rsp+0xB0]
0000792ccedd609d  vmovaps [rsp+0xB0], xmm14
0000792ccedd60a6  movaps xmm3, xmm1
0000792ccedd60a9  mulpd xmm3, xmm15
0000792ccedd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000792ccedd60b3  ptest xmm14, xmm14
0000792ccedd60b9  jnz 0x0000792CCEDD8771
0000792ccedd60bf  lea r14, [rax+0x20]
0000792ccedd60c3  movups xmm1, [r13+r14*1]
0000792ccedd60c9  movaps [r15+0x110], xmm1
0000792ccedd60d1  vmovaps xmm14, [rsp+0x70]
0000792ccedd60d7  vmovaps [rsp+0x70], xmm1
0000792ccedd60dd  movaps xmm15, xmm14
0000792ccedd60e1  addpd xmm15, xmm4
0000792ccedd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000792ccedd60ec  ptest xmm1, xmm1
0000792ccedd60f1  jnz 0x0000792CCEDD88BC
0000792ccedd60f7  vmovaps xmm1, [rsp+0x60]
0000792ccedd60fd  vpermilpd xmm1, xmm1, 0x00
0000792ccedd6103  movaps xmm14, xmm2
0000792ccedd6107  mulpd xmm14, xmm1
0000792ccedd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000792ccedd6112  ptest xmm4, xmm4
0000792ccedd6117  jnz 0x0000792CCEDD89FF
0000792ccedd611d  vmovaps xmm4, [rsp+0x50]
0000792ccedd6123  movaps xmm1, xmm4
0000792ccedd6126  addpd xmm1, xmm9
0000792ccedd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000792ccedd6130  ptest xmm2, xmm2
0000792ccedd6135  jnz 0x0000792CCEDD8B41
0000792ccedd613b  vmovaps xmm9, [rsp+0x30]
0000792ccedd6141  vpermilpd xmm9, xmm9, 0x00
0000792ccedd6147  vmovaps xmm2, [rsp+0x70]
0000792ccedd614d  vmovaps [rsp+0x50], xmm1
0000792ccedd6153  movaps xmm4, xmm2
0000792ccedd6156  mulpd xmm4, xmm9
0000792ccedd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000792ccedd6160  ptest xmm1, xmm1
0000792ccedd6165  jnz 0x0000792CCEDD8C82
0000792ccedd616b  vmovaps xmm1, [rsp+0x30]
0000792ccedd6171  vpermilpd xmm1, xmm1, 0x00
0000792ccedd6177  vmovaps xmm2, [rsp+0x90]
0000792ccedd6180  vmovaps [rsp+0x60], xmm15
0000792ccedd6186  movaps xmm9, xmm2
0000792ccedd618a  mulpd xmm9, xmm1
0000792ccedd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000792ccedd6195  ptest xmm15, xmm15
0000792ccedd619b  jnz 0x0000792CCEDD8DC3
0000792ccedd61a1  vmovaps xmm15, [rsp+0x80]
0000792ccedd61aa  movaps xmm1, xmm15
0000792ccedd61ae  addpd xmm1, xmm6
0000792ccedd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000792ccedd61b7  ptest xmm2, xmm2
0000792ccedd61bc  jnz 0x0000792CCEDD8F05
0000792ccedd61c2  movaps xmm15, xmm5
0000792ccedd61c6  addpd xmm15, xmm3
0000792ccedd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000792ccedd61d1  ptest xmm6, xmm6
0000792ccedd61d6  jnz 0x0000792CCEDD9046
0000792ccedd61dc  vmovaps xmm6, [rsp+0x30]
0000792ccedd61e2  vpermilpd xmm6, xmm6, 0x00
0000792ccedd61e8  movaps xmm5, xmm8
0000792ccedd61ec  mulpd xmm5, xmm6
0000792ccedd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000792ccedd61f5  ptest xmm3, xmm3
0000792ccedd61fa  jnz 0x0000792CCEDD9188
0000792ccedd6200  vmovaps xmm8, [rsp+0x30]
0000792ccedd6206  vpermilpd xmm8, xmm8, 0x00
0000792ccedd620c  movaps xmm6, xmm10
0000792ccedd6210  mulpd xmm6, xmm8
0000792ccedd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000792ccedd621a  ptest xmm3, xmm3
0000792ccedd621f  jnz 0x0000792CCEDD92C9
0000792ccedd6225  vmovaps xmm8, [rsp+0x60]
0000792ccedd622b  movaps xmm10, xmm8
0000792ccedd622f  addpd xmm10, xmm14
0000792ccedd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000792ccedd623a  ptest xmm3, xmm3
0000792ccedd623f  jnz 0x0000792CCEDD940B
0000792ccedd6245  vmovaps xmm8, [rsp+0x50]
0000792ccedd624b  movaps xmm14, xmm8
0000792ccedd624f  addpd xmm14, xmm4
0000792ccedd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000792ccedd625a  ptest xmm3, xmm3
0000792ccedd625f  jnz 0x0000792CCEDD954F
0000792ccedd6265  vmovaps xmm8, [rsp+0x40]
0000792ccedd626b  vpermilpd xmm8, xmm8, 0x00
0000792ccedd6271  movaps xmm4, xmm13
0000792ccedd6275  mulpd xmm4, xmm8
0000792ccedd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000792ccedd627f  ptest xmm3, xmm3
0000792ccedd6284  jnz 0x0000792CCEDD9692
0000792ccedd628a  movaps xmm13, xmm15
0000792ccedd628e  addpd xmm13, xmm9
0000792ccedd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000792ccedd6299  ptest xmm8, xmm8
0000792ccedd629f  jnz 0x0000792CCEDD97D4
0000792ccedd62a5  movaps xmm15, xmm1
0000792ccedd62a9  addpd xmm15, xmm5
0000792ccedd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000792ccedd62b4  ptest xmm9, xmm9
0000792ccedd62ba  jnz 0x0000792CCEDD9918
0000792ccedd62c0  vmovaps [rsp+0x30], xmm11
0000792ccedd62c6  vmovaps xmm1, [rsp+0x30]
0000792ccedd62cc  por xmm11, xmm1
0000792ccedd62d1  movaps [r15+0x250], xmm11
0000792ccedd62d9  vmovaps [rsp+0x30], xmm12
0000792ccedd62df  vmovaps xmm1, [rsp+0x30]
0000792ccedd62e5  por xmm12, xmm1
0000792ccedd62ea  movaps [r15+0x2A0], xmm12
0000792ccedd62f2  vmovaps xmm1, [rsp+0xA0]
0000792ccedd62fb  vmovaps xmm11, [rsp+0xA0]
0000792ccedd6304  por xmm1, xmm11
0000792ccedd6309  movaps [r15+0x1D0], xmm1
0000792ccedd6311  lea r14, [rax+0x40]
0000792ccedd6315  movups xmm1, [r13+r14*1]
0000792ccedd631b  movaps [r15+0x2C0], xmm1
0000792ccedd6323  vmovaps xmm11, [rsp+0x40]
0000792ccedd6329  vpermilpd xmm11, xmm11, 0x00
0000792ccedd632f  vmovaps xmm8, [rsp+0xE0]
0000792ccedd6338  movaps xmm9, xmm8
0000792ccedd633c  mulpd xmm9, xmm11
0000792ccedd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000792ccedd6347  ptest xmm5, xmm5
0000792ccedd634c  jnz 0x0000792CCEDD9A64
0000792ccedd6352  movaps xmm11, xmm10
0000792ccedd6356  addpd xmm11, xmm6
0000792ccedd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000792ccedd6361  ptest xmm8, xmm8
0000792ccedd6367  jnz 0x0000792CCEDD9BA8
0000792ccedd636d  movaps xmm10, xmm14
0000792ccedd6371  addpd xmm10, xmm4
0000792ccedd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000792ccedd637c  ptest xmm8, xmm8
0000792ccedd6382  jnz 0x0000792CCEDD9CEB
0000792ccedd6388  vmovaps xmm14, [rsp+0x40]
0000792ccedd638e  vpermilpd xmm14, xmm14, 0x00
0000792ccedd6394  movaps xmm8, xmm1
0000792ccedd6398  mulpd xmm8, xmm14
0000792ccedd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000792ccedd63a3  ptest xmm6, xmm6
0000792ccedd63a8  jnz 0x0000792CCEDD9E2E
0000792ccedd63ae  movaps xmm1, [r15+0x2B0]
0000792ccedd63b6  vmovaps xmm14, [rsp+0x40]
0000792ccedd63bc  vpermilpd xmm14, xmm14, 0x00
0000792ccedd63c2  movaps xmm6, xmm1
0000792ccedd63c5  mulpd xmm6, xmm14
0000792ccedd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000792ccedd63cf  ptest xmm5, xmm5
0000792ccedd63d4  jnz 0x0000792CCEDD9F71
0000792ccedd63da  vmovaps xmm1, [rsp+0x10]
0000792ccedd63e0  vpermilpd xmm1, xmm1, 0x00
0000792ccedd63e6  movaps xmm14, xmm12
0000792ccedd63ea  mulpd xmm14, xmm1
0000792ccedd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000792ccedd63f5  ptest xmm5, xmm5
0000792ccedd63fa  jnz 0x0000792CCEDDA0B2
0000792ccedd6400  movaps xmm1, xmm13
0000792ccedd6404  addpd xmm1, xmm9
0000792ccedd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000792ccedd640e  ptest xmm12, xmm12
0000792ccedd6414  jnz 0x0000792CCEDDA1F5
0000792ccedd641a  vmovaps xmm13, [rsp+0x10]
0000792ccedd6420  vpermilpd xmm13, xmm13, 0x00
0000792ccedd6426  movaps xmm12, xmm7
0000792ccedd642a  mulpd xmm12, xmm13
0000792ccedd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000792ccedd6435  ptest xmm9, xmm9
0000792ccedd643b  jnz 0x0000792CCEDDA337
0000792ccedd6441  movaps xmm13, xmm15
0000792ccedd6445  addpd xmm13, xmm8
0000792ccedd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000792ccedd6450  ptest xmm9, xmm9
0000792ccedd6456  jnz 0x0000792CCEDDA47A
0000792ccedd645c  movaps xmm15, [r15+0x290]
0000792ccedd6464  vmovaps xmm9, [rsp+0x10]
0000792ccedd646a  vpermilpd xmm9, xmm9, 0x00
0000792ccedd6470  movaps xmm8, xmm15
0000792ccedd6474  mulpd xmm8, xmm9
0000792ccedd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000792ccedd647f  ptest xmm7, xmm7
0000792ccedd6484  jnz 0x0000792CCEDDA5BE
0000792ccedd648a  movaps xmm15, xmm11
0000792ccedd648e  addpd xmm15, xmm6
0000792ccedd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000792ccedd6499  ptest xmm9, xmm9
0000792ccedd649f  jnz 0x0000792CCEDDA702
0000792ccedd64a5  movaps xmm11, [r15+0x1E0]
0000792ccedd64ad  vmovaps xmm9, [rsp+0x10]
0000792ccedd64b3  vpermilpd xmm9, xmm9, 0x00
0000792ccedd64b9  movaps xmm7, xmm11
0000792ccedd64bd  mulpd xmm7, xmm9
0000792ccedd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000792ccedd64c7  ptest xmm6, xmm6
0000792ccedd64cc  jnz 0x0000792CCEDDA845
0000792ccedd64d2  movaps xmm11, xmm10
0000792ccedd64d6  addpd xmm11, xmm14
0000792ccedd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000792ccedd64e1  ptest xmm9, xmm9
0000792ccedd64e7  jnz 0x0000792CCEDDA987
0000792ccedd64ed  lea r14, [rax+0x70]
0000792ccedd64f1  movups xmm14, [r13+r14*1]
0000792ccedd64f7  movaps [r15+0x240], xmm14
0000792ccedd64ff  movaps xmm10, xmm1
0000792ccedd6503  addpd xmm10, xmm12
0000792ccedd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000792ccedd650e  ptest xmm9, xmm9
0000792ccedd6514  jnz 0x0000792CCEDDAAD5
0000792ccedd651a  movaps [r15+0x170], xmm10
0000792ccedd6522  vmovaps xmm1, [rsp+0x20]
0000792ccedd6528  vpermilpd xmm1, xmm1, 0x00
0000792ccedd652e  movaps xmm12, xmm14
0000792ccedd6532  mulpd xmm12, xmm1
0000792ccedd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000792ccedd653d  ptest xmm9, xmm9
0000792ccedd6543  jnz 0x0000792CCEDDAC18
0000792ccedd6549  vmovaps xmm1, [rsp+0x20]
0000792ccedd654f  vpermilpd xmm1, xmm1, 0x00
0000792ccedd6555  vmovaps xmm9, [rsp+0xB0]
0000792ccedd655e  movaps xmm14, xmm9
0000792ccedd6562  mulpd xmm14, xmm1
0000792ccedd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000792ccedd656d  ptest xmm6, xmm6
0000792ccedd6572  jnz 0x0000792CCEDDAD5B
0000792ccedd6578  movaps [r15+0x180], xmm14
0000792ccedd6580  movaps xmm1, xmm13
0000792ccedd6584  addpd xmm1, xmm8
0000792ccedd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000792ccedd658e  ptest xmm9, xmm9
0000792ccedd6594  jnz 0x0000792CCEDDAE9E
0000792ccedd659a  movaps [r15+0x210], xmm1
0000792ccedd65a2  movups xmm13, [r13+rax*1]
0000792ccedd65a8  lea r14, [rax+0x10]
0000792ccedd65ac  movups xmm9, [r13+r14*1]
0000792ccedd65b2  movaps [r15+0x230], xmm9
0000792ccedd65ba  movaps xmm8, xmm15
0000792ccedd65be  addpd xmm8, xmm7
0000792ccedd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000792ccedd65c9  ptest xmm6, xmm6
0000792ccedd65ce  jnz 0x0000792CCEDDAFF4
0000792ccedd65d4  movaps [r15+0x130], xmm8
0000792ccedd65dc  vmovaps xmm15, [rsp+0x20]
0000792ccedd65e2  vpermilpd xmm15, xmm15, 0x00
0000792ccedd65e8  movaps xmm7, xmm9
0000792ccedd65ec  mulpd xmm7, xmm15
0000792ccedd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000792ccedd65f6  ptest xmm6, xmm6
0000792ccedd65fb  jnz 0x0000792CCEDDB137
0000792ccedd6601  movaps [r15+0x220], xmm7
0000792ccedd6609  vmovaps xmm15, [rsp+0x20]
0000792ccedd660f  vpermilpd xmm15, xmm15, 0x00
0000792ccedd6615  movaps xmm9, xmm13
0000792ccedd6619  mulpd xmm9, xmm15
0000792ccedd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000792ccedd6624  ptest xmm6, xmm6
0000792ccedd6629  jnz 0x0000792CCEDDB279
0000792ccedd662f  movaps xmm15, xmm11
0000792ccedd6633  addpd xmm15, xmm12
0000792ccedd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000792ccedd663e  ptest xmm13, xmm13
0000792ccedd6644  jnz 0x0000792CCEDDB3BD
0000792ccedd664a  movaps [r15+0x140], xmm15
0000792ccedd6652  movaps xmm13, xmm10
0000792ccedd6656  addpd xmm13, xmm14
0000792ccedd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000792ccedd6661  ptest xmm12, xmm12
0000792ccedd6667  jnz 0x0000792CCEDDB501
0000792ccedd666d  movaps [r15+0x150], xmm13
0000792ccedd6675  movaps xmm14, xmm1
0000792ccedd6679  addpd xmm14, xmm7
0000792ccedd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000792ccedd6684  ptest xmm12, xmm12
0000792ccedd668a  jnz 0x0000792CCEDDB645
0000792ccedd6690  movaps [r15+0x160], xmm14
0000792ccedd6698  movaps xmm1, xmm8
0000792ccedd669c  addpd xmm1, xmm9
0000792ccedd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000792ccedd66a6  ptest xmm12, xmm12
0000792ccedd66ac  jnz 0x0000792CCEDDB787
0000792ccedd66b2  movaps [r15+0x120], xmm1
0000792ccedd66ba  movups [r13+r11*1], xmm15
0000792ccedd66c0  lea rax, [r11+0x10]
0000792ccedd66c4  movups [r13+rax*1], xmm13
0000792ccedd66ca  lea rax, [r11+0x20]
0000792ccedd66ce  movups [r13+rax*1], xmm14
0000792ccedd66d4  lea rax, [r11+0x30]
0000792ccedd66d8  movups [r13+rax*1], xmm1
0000792ccedd66de  mov eax, [r15+0x108]
0000792ccedd66e5  sahf
0000792ccedd66e6  jnz 0x0000792CCEDD6718
0000792ccedd66e8  cmp dword ptr [r15+0x318], 0x00
0000792ccedd66f0  jz 0x0000792CCEDDB900
0000792ccedd66f6  nop [rax+rax*1], ax
0000792ccedd66ff  nop [rax+rax*1], eax
0000792ccedd6707  mov eax, 0x410444
0000792ccedd670c  mov [r15+0x100], rax
0000792ccedd6713  jmp 0x0000792CCEBFE110
0000792ccedd6718  cmp dword ptr [r15+0x318], 0x00
0000792ccedd6720  jz 0x0000792CCEDD57E0
0000792ccedd6726  nop [rax+rax*1], ax
0000792ccedd672f  nop [rax+rax*1], eax
0000792ccedd6737  mov eax, 0x410278
0000792ccedd673c  mov [r15+0x100], rax
0000792ccedd6743  jmp 0x0000792CCEBFE110
0000792ccedd6748  int3
0000792ccedd6749  call 0x0000792CCEC0A4B0
0000792ccedd674e  jmp 0x0000792CCEDD5828
0000792ccedd6753  call 0x0000792CCEC09240
0000792ccedd6758  jmp 0x0000792CCEDD5832
0000792ccedd675d  call 0x0000792CCEC0A4B0
0000792ccedd6762  jmp 0x0000792CCEDD588F
0000792ccedd6767  call 0x0000792CCEC09240
0000792ccedd676c  jmp 0x0000792CCEDD5899
0000792ccedd6771  call 0x0000792CCEC0A4B0
0000792ccedd6776  jmp 0x0000792CCEDD58DD
0000792ccedd677b  call 0x0000792CCEC09240
0000792ccedd6780  jmp 0x0000792CCEDD58E7
0000792ccedd6785  call 0x0000792CCECB47C0
0000792ccedd678a  jmp 0x0000792CCEDD5926
0000792ccedd678f  call 0x0000792CCEC0B720
0000792ccedd6794  jmp 0x0000792CCEDD593A
0000792ccedd6799  call 0x0000792CCECBFC30
0000792ccedd679e  jmp 0x0000792CCEDD5958
0000792ccedd67a3  call 0x0000792CCECBE9C0
0000792ccedd67a8  jmp 0x0000792CCEDD5962
0000792ccedd67ad  call 0x0000792CCECBD750
0000792ccedd67b2  jmp 0x0000792CCEDD596C
0000792ccedd67b7  sub rsp, 0x08
0000792ccedd67bb  push rax
0000792ccedd67bc  push rcx
0000792ccedd67bd  push rdx
0000792ccedd67be  push rdi
0000792ccedd67bf  push rsi
0000792ccedd67c0  push r8
0000792ccedd67c2  push r9
0000792ccedd67c4  push r10
0000792ccedd67c6  push r11
0000792ccedd67c8  sub rsp, 0xF0
0000792ccedd67cf  vmovaps [rsp], xmm0
0000792ccedd67d4  vmovaps [rsp+0x10], xmm1
0000792ccedd67da  vmovaps [rsp+0x20], xmm2
0000792ccedd67e0  vmovaps [rsp+0x30], xmm3
0000792ccedd67e6  vmovaps [rsp+0x40], xmm4
0000792ccedd67ec  vmovaps [rsp+0x50], xmm5
0000792ccedd67f2  vmovaps [rsp+0x60], xmm6
0000792ccedd67f8  vmovaps [rsp+0x70], xmm7
0000792ccedd67fe  vmovaps [rsp+0x80], xmm9
0000792ccedd6807  vmovaps [rsp+0x90], xmm10
0000792ccedd6810  vmovaps [rsp+0xA0], xmm11
0000792ccedd6819  vmovaps [rsp+0xB0], xmm12
0000792ccedd6822  vmovaps [rsp+0xC0], xmm13
0000792ccedd682b  vmovaps [rsp+0xD0], xmm14
0000792ccedd6834  vmovaps [rsp+0xE0], xmm15
0000792ccedd683d  sub rsp, 0x30
0000792ccedd6841  movaps [rsp], xmm8
0000792ccedd6846  movaps [rsp+0x10], xmm12
0000792ccedd684c  movaps [rsp+0x20], xmm15
0000792ccedd6852  lea rdi, [rsp]
0000792ccedd6856  mov esi, 0x00
0000792ccedd685b  mov rax, 0x5AEE2D541530
0000792ccedd6865  call rax
0000792ccedd6867  movaps xmm8, [rsp]
0000792ccedd686c  add rsp, 0x30
0000792ccedd6870  vmovaps xmm0, [rsp]
0000792ccedd6875  vmovaps xmm1, [rsp+0x10]
0000792ccedd687b  vmovaps xmm2, [rsp+0x20]
0000792ccedd6881  vmovaps xmm3, [rsp+0x30]
0000792ccedd6887  vmovaps xmm4, [rsp+0x40]
0000792ccedd688d  vmovaps xmm5, [rsp+0x50]
0000792ccedd6893  vmovaps xmm6, [rsp+0x60]
0000792ccedd6899  vmovaps xmm7, [rsp+0x70]
0000792ccedd689f  vmovaps xmm9, [rsp+0x80]
0000792ccedd68a8  vmovaps xmm10, [rsp+0x90]
0000792ccedd68b1  vmovaps xmm11, [rsp+0xA0]
0000792ccedd68ba  vmovaps xmm12, [rsp+0xB0]
0000792ccedd68c3  vmovaps xmm13, [rsp+0xC0]
0000792ccedd68cc  vmovaps xmm14, [rsp+0xD0]
0000792ccedd68d5  vmovaps xmm15, [rsp+0xE0]
0000792ccedd68de  add rsp, 0xF0
0000792ccedd68e5  pop r11
0000792ccedd68e7  pop r10
0000792ccedd68e9  pop r9
0000792ccedd68eb  pop r8
0000792ccedd68ed  pop rsi
0000792ccedd68ee  pop rdi
0000792ccedd68ef  pop rdx
0000792ccedd68f0  pop rcx
0000792ccedd68f1  pop rax
0000792ccedd68f2  add rsp, 0x08
0000792ccedd68f6  jmp 0x0000792CCEDD599A
0000792ccedd68fb  sub rsp, 0x08
0000792ccedd68ff  push rax
0000792ccedd6900  push rcx
0000792ccedd6901  push rdx
0000792ccedd6902  push rdi
0000792ccedd6903  push rsi
0000792ccedd6904  push r8
0000792ccedd6906  push r9
0000792ccedd6908  push r10
0000792ccedd690a  push r11
0000792ccedd690c  sub rsp, 0xF0
0000792ccedd6913  vmovaps [rsp], xmm0
0000792ccedd6918  vmovaps [rsp+0x10], xmm1
0000792ccedd691e  vmovaps [rsp+0x20], xmm2
0000792ccedd6924  vmovaps [rsp+0x30], xmm3
0000792ccedd692a  vmovaps [rsp+0x40], xmm4
0000792ccedd6930  vmovaps [rsp+0x50], xmm5
0000792ccedd6936  vmovaps [rsp+0x60], xmm6
0000792ccedd693c  vmovaps [rsp+0x70], xmm8
0000792ccedd6942  vmovaps [rsp+0x80], xmm9
0000792ccedd694b  vmovaps [rsp+0x90], xmm10
0000792ccedd6954  vmovaps [rsp+0xA0], xmm11
0000792ccedd695d  vmovaps [rsp+0xB0], xmm12
0000792ccedd6966  vmovaps [rsp+0xC0], xmm13
0000792ccedd696f  vmovaps [rsp+0xD0], xmm14
0000792ccedd6978  vmovaps [rsp+0xE0], xmm15
0000792ccedd6981  sub rsp, 0x30
0000792ccedd6985  movaps [rsp], xmm7
0000792ccedd6989  movaps [rsp+0x10], xmm9
0000792ccedd698f  movaps [rsp+0x20], xmm15
0000792ccedd6995  lea rdi, [rsp]
0000792ccedd6999  mov esi, 0x00
0000792ccedd699e  mov rax, 0x5AEE2D541530
0000792ccedd69a8  call rax
0000792ccedd69aa  movaps xmm7, [rsp]
0000792ccedd69ae  add rsp, 0x30
0000792ccedd69b2  vmovaps xmm0, [rsp]
0000792ccedd69b7  vmovaps xmm1, [rsp+0x10]
0000792ccedd69bd  vmovaps xmm2, [rsp+0x20]
0000792ccedd69c3  vmovaps xmm3, [rsp+0x30]
0000792ccedd69c9  vmovaps xmm4, [rsp+0x40]
0000792ccedd69cf  vmovaps xmm5, [rsp+0x50]
0000792ccedd69d5  vmovaps xmm6, [rsp+0x60]
0000792ccedd69db  vmovaps xmm8, [rsp+0x70]
0000792ccedd69e1  vmovaps xmm9, [rsp+0x80]
0000792ccedd69ea  vmovaps xmm10, [rsp+0x90]
0000792ccedd69f3  vmovaps xmm11, [rsp+0xA0]
0000792ccedd69fc  vmovaps xmm12, [rsp+0xB0]
0000792ccedd6a05  vmovaps xmm13, [rsp+0xC0]
0000792ccedd6a0e  vmovaps xmm14, [rsp+0xD0]
0000792ccedd6a17  vmovaps xmm15, [rsp+0xE0]
0000792ccedd6a20  add rsp, 0xF0
0000792ccedd6a27  pop r11
0000792ccedd6a29  pop r10
0000792ccedd6a2b  pop r9
0000792ccedd6a2d  pop r8
0000792ccedd6a2f  pop rsi
0000792ccedd6a30  pop rdi
0000792ccedd6a31  pop rdx
0000792ccedd6a32  pop rcx
0000792ccedd6a33  pop rax
0000792ccedd6a34  add rsp, 0x08
0000792ccedd6a38  jmp 0x0000792CCEDD59C8
0000792ccedd6a3d  sub rsp, 0x08
0000792ccedd6a41  push rax
0000792ccedd6a42  push rcx
0000792ccedd6a43  push rdx
0000792ccedd6a44  push rdi
0000792ccedd6a45  push rsi
0000792ccedd6a46  push r8
0000792ccedd6a48  push r9
0000792ccedd6a4a  push r10
0000792ccedd6a4c  push r11
0000792ccedd6a4e  sub rsp, 0xF0
0000792ccedd6a55  vmovaps [rsp], xmm0
0000792ccedd6a5a  vmovaps [rsp+0x10], xmm1
0000792ccedd6a60  vmovaps [rsp+0x20], xmm2
0000792ccedd6a66  vmovaps [rsp+0x30], xmm3
0000792ccedd6a6c  vmovaps [rsp+0x40], xmm4
0000792ccedd6a72  vmovaps [rsp+0x50], xmm5
0000792ccedd6a78  vmovaps [rsp+0x60], xmm6
0000792ccedd6a7e  vmovaps [rsp+0x70], xmm7
0000792ccedd6a84  vmovaps [rsp+0x80], xmm8
0000792ccedd6a8d  vmovaps [rsp+0x90], xmm10
0000792ccedd6a96  vmovaps [rsp+0xA0], xmm11
0000792ccedd6a9f  vmovaps [rsp+0xB0], xmm12
0000792ccedd6aa8  vmovaps [rsp+0xC0], xmm13
0000792ccedd6ab1  vmovaps [rsp+0xD0], xmm14
0000792ccedd6aba  vmovaps [rsp+0xE0], xmm15
0000792ccedd6ac3  sub rsp, 0x30
0000792ccedd6ac7  movaps [rsp], xmm9
0000792ccedd6acc  movaps [rsp+0x10], xmm12
0000792ccedd6ad2  movaps [rsp+0x20], xmm10
0000792ccedd6ad8  lea rdi, [rsp]
0000792ccedd6adc  mov esi, 0x00
0000792ccedd6ae1  mov rax, 0x5AEE2D541530
0000792ccedd6aeb  call rax
0000792ccedd6aed  movaps xmm9, [rsp]
0000792ccedd6af2  add rsp, 0x30
0000792ccedd6af6  vmovaps xmm0, [rsp]
0000792ccedd6afb  vmovaps xmm1, [rsp+0x10]
0000792ccedd6b01  vmovaps xmm2, [rsp+0x20]
0000792ccedd6b07  vmovaps xmm3, [rsp+0x30]
0000792ccedd6b0d  vmovaps xmm4, [rsp+0x40]
0000792ccedd6b13  vmovaps xmm5, [rsp+0x50]
0000792ccedd6b19  vmovaps xmm6, [rsp+0x60]
0000792ccedd6b1f  vmovaps xmm7, [rsp+0x70]
0000792ccedd6b25  vmovaps xmm8, [rsp+0x80]
0000792ccedd6b2e  vmovaps xmm10, [rsp+0x90]
0000792ccedd6b37  vmovaps xmm11, [rsp+0xA0]
0000792ccedd6b40  vmovaps xmm12, [rsp+0xB0]
0000792ccedd6b49  vmovaps xmm13, [rsp+0xC0]
0000792ccedd6b52  vmovaps xmm14, [rsp+0xD0]
0000792ccedd6b5b  vmovaps xmm15, [rsp+0xE0]
0000792ccedd6b64  add rsp, 0xF0
0000792ccedd6b6b  pop r11
0000792ccedd6b6d  pop r10
0000792ccedd6b6f  pop r9
0000792ccedd6b71  pop r8
0000792ccedd6b73  pop rsi
0000792ccedd6b74  pop rdi
0000792ccedd6b75  pop rdx
0000792ccedd6b76  pop rcx
0000792ccedd6b77  pop rax
0000792ccedd6b78  add rsp, 0x08
0000792ccedd6b7c  jmp 0x0000792CCEDD59EC
0000792ccedd6b81  sub rsp, 0x08
0000792ccedd6b85  push rax
0000792ccedd6b86  push rcx
0000792ccedd6b87  push rdx
0000792ccedd6b88  push rdi
0000792ccedd6b89  push rsi
0000792ccedd6b8a  push r8
0000792ccedd6b8c  push r9
0000792ccedd6b8e  push r10
0000792ccedd6b90  push r11
0000792ccedd6b92  sub rsp, 0xF0
0000792ccedd6b99  vmovaps [rsp], xmm0
0000792ccedd6b9e  vmovaps [rsp+0x10], xmm1
0000792ccedd6ba4  vmovaps [rsp+0x20], xmm2
0000792ccedd6baa  vmovaps [rsp+0x30], xmm3
0000792ccedd6bb0  vmovaps [rsp+0x40], xmm4
0000792ccedd6bb6  vmovaps [rsp+0x50], xmm5
0000792ccedd6bbc  vmovaps [rsp+0x60], xmm6
0000792ccedd6bc2  vmovaps [rsp+0x70], xmm7
0000792ccedd6bc8  vmovaps [rsp+0x80], xmm8
0000792ccedd6bd1  vmovaps [rsp+0x90], xmm9
0000792ccedd6bda  vmovaps [rsp+0xA0], xmm11
0000792ccedd6be3  vmovaps [rsp+0xB0], xmm12
0000792ccedd6bec  vmovaps [rsp+0xC0], xmm13
0000792ccedd6bf5  vmovaps [rsp+0xD0], xmm14
0000792ccedd6bfe  vmovaps [rsp+0xE0], xmm15
0000792ccedd6c07  sub rsp, 0x30
0000792ccedd6c0b  movaps [rsp], xmm10
0000792ccedd6c10  movaps [rsp+0x10], xmm12
0000792ccedd6c16  movaps [rsp+0x20], xmm11
0000792ccedd6c1c  lea rdi, [rsp]
0000792ccedd6c20  mov esi, 0x00
0000792ccedd6c25  mov rax, 0x5AEE2D541530
0000792ccedd6c2f  call rax
0000792ccedd6c31  movaps xmm10, [rsp]
0000792ccedd6c36  add rsp, 0x30
0000792ccedd6c3a  vmovaps xmm0, [rsp]
0000792ccedd6c3f  vmovaps xmm1, [rsp+0x10]
0000792ccedd6c45  vmovaps xmm2, [rsp+0x20]
0000792ccedd6c4b  vmovaps xmm3, [rsp+0x30]
0000792ccedd6c51  vmovaps xmm4, [rsp+0x40]
0000792ccedd6c57  vmovaps xmm5, [rsp+0x50]
0000792ccedd6c5d  vmovaps xmm6, [rsp+0x60]
0000792ccedd6c63  vmovaps xmm7, [rsp+0x70]
0000792ccedd6c69  vmovaps xmm8, [rsp+0x80]
0000792ccedd6c72  vmovaps xmm9, [rsp+0x90]
0000792ccedd6c7b  vmovaps xmm11, [rsp+0xA0]
0000792ccedd6c84  vmovaps xmm12, [rsp+0xB0]
0000792ccedd6c8d  vmovaps xmm13, [rsp+0xC0]
0000792ccedd6c96  vmovaps xmm14, [rsp+0xD0]
0000792ccedd6c9f  vmovaps xmm15, [rsp+0xE0]
0000792ccedd6ca8  add rsp, 0xF0
0000792ccedd6caf  pop r11
0000792ccedd6cb1  pop r10
0000792ccedd6cb3  pop r9
0000792ccedd6cb5  pop r8
0000792ccedd6cb7  pop rsi
0000792ccedd6cb8  pop rdi
0000792ccedd6cb9  pop rdx
0000792ccedd6cba  pop rcx
0000792ccedd6cbb  pop rax
0000792ccedd6cbc  add rsp, 0x08
0000792ccedd6cc0  jmp 0x0000792CCEDD5A06
0000792ccedd6cc5  sub rsp, 0x08
0000792ccedd6cc9  push rax
0000792ccedd6cca  push rcx
0000792ccedd6ccb  push rdx
0000792ccedd6ccc  push rdi
0000792ccedd6ccd  push rsi
0000792ccedd6cce  push r8
0000792ccedd6cd0  push r9
0000792ccedd6cd2  push r10
0000792ccedd6cd4  push r11
0000792ccedd6cd6  sub rsp, 0xF0
0000792ccedd6cdd  vmovaps [rsp], xmm0
0000792ccedd6ce2  vmovaps [rsp+0x10], xmm1
0000792ccedd6ce8  vmovaps [rsp+0x20], xmm2
0000792ccedd6cee  vmovaps [rsp+0x30], xmm3
0000792ccedd6cf4  vmovaps [rsp+0x40], xmm4
0000792ccedd6cfa  vmovaps [rsp+0x50], xmm5
0000792ccedd6d00  vmovaps [rsp+0x60], xmm7
0000792ccedd6d06  vmovaps [rsp+0x70], xmm8
0000792ccedd6d0c  vmovaps [rsp+0x80], xmm9
0000792ccedd6d15  vmovaps [rsp+0x90], xmm10
0000792ccedd6d1e  vmovaps [rsp+0xA0], xmm11
0000792ccedd6d27  vmovaps [rsp+0xB0], xmm12
0000792ccedd6d30  vmovaps [rsp+0xC0], xmm13
0000792ccedd6d39  vmovaps [rsp+0xD0], xmm14
0000792ccedd6d42  vmovaps [rsp+0xE0], xmm15
0000792ccedd6d4b  sub rsp, 0x30
0000792ccedd6d4f  movaps [rsp], xmm6
0000792ccedd6d53  movaps [rsp+0x10], xmm12
0000792ccedd6d59  movaps [rsp+0x20], xmm11
0000792ccedd6d5f  lea rdi, [rsp]
0000792ccedd6d63  mov esi, 0x00
0000792ccedd6d68  mov rax, 0x5AEE2D541530
0000792ccedd6d72  call rax
0000792ccedd6d74  movaps xmm6, [rsp]
0000792ccedd6d78  add rsp, 0x30
0000792ccedd6d7c  vmovaps xmm0, [rsp]
0000792ccedd6d81  vmovaps xmm1, [rsp+0x10]
0000792ccedd6d87  vmovaps xmm2, [rsp+0x20]
0000792ccedd6d8d  vmovaps xmm3, [rsp+0x30]
0000792ccedd6d93  vmovaps xmm4, [rsp+0x40]
0000792ccedd6d99  vmovaps xmm5, [rsp+0x50]
0000792ccedd6d9f  vmovaps xmm7, [rsp+0x60]
0000792ccedd6da5  vmovaps xmm8, [rsp+0x70]
0000792ccedd6dab  vmovaps xmm9, [rsp+0x80]
0000792ccedd6db4  vmovaps xmm10, [rsp+0x90]
0000792ccedd6dbd  vmovaps xmm11, [rsp+0xA0]
0000792ccedd6dc6  vmovaps xmm12, [rsp+0xB0]
0000792ccedd6dcf  vmovaps xmm13, [rsp+0xC0]
0000792ccedd6dd8  vmovaps xmm14, [rsp+0xD0]
0000792ccedd6de1  vmovaps xmm15, [rsp+0xE0]
0000792ccedd6dea  add rsp, 0xF0
0000792ccedd6df1  pop r11
0000792ccedd6df3  pop r10
0000792ccedd6df5  pop r9
0000792ccedd6df7  pop r8
0000792ccedd6df9  pop rsi
0000792ccedd6dfa  pop rdi
0000792ccedd6dfb  pop rdx
0000792ccedd6dfc  pop rcx
0000792ccedd6dfd  pop rax
0000792ccedd6dfe  add rsp, 0x08
0000792ccedd6e02  jmp 0x0000792CCEDD5A27
0000792ccedd6e07  sub rsp, 0x08
0000792ccedd6e0b  push rax
0000792ccedd6e0c  push rcx
0000792ccedd6e0d  push rdx
0000792ccedd6e0e  push rdi
0000792ccedd6e0f  push rsi
0000792ccedd6e10  push r8
0000792ccedd6e12  push r9
0000792ccedd6e14  push r10
0000792ccedd6e16  push r11
0000792ccedd6e18  sub rsp, 0xF0
0000792ccedd6e1f  vmovaps [rsp], xmm0
0000792ccedd6e24  vmovaps [rsp+0x10], xmm1
0000792ccedd6e2a  vmovaps [rsp+0x20], xmm2
0000792ccedd6e30  vmovaps [rsp+0x30], xmm4
0000792ccedd6e36  vmovaps [rsp+0x40], xmm5
0000792ccedd6e3c  vmovaps [rsp+0x50], xmm6
0000792ccedd6e42  vmovaps [rsp+0x60], xmm7
0000792ccedd6e48  vmovaps [rsp+0x70], xmm8
0000792ccedd6e4e  vmovaps [rsp+0x80], xmm9
0000792ccedd6e57  vmovaps [rsp+0x90], xmm10
0000792ccedd6e60  vmovaps [rsp+0xA0], xmm11
0000792ccedd6e69  vmovaps [rsp+0xB0], xmm12
0000792ccedd6e72  vmovaps [rsp+0xC0], xmm13
0000792ccedd6e7b  vmovaps [rsp+0xD0], xmm14
0000792ccedd6e84  vmovaps [rsp+0xE0], xmm15
0000792ccedd6e8d  sub rsp, 0x30
0000792ccedd6e91  movaps [rsp], xmm3
0000792ccedd6e95  movaps [rsp+0x10], xmm5
0000792ccedd6e9a  movaps [rsp+0x20], xmm4
0000792ccedd6e9f  lea rdi, [rsp]
0000792ccedd6ea3  mov esi, 0x00
0000792ccedd6ea8  mov rax, 0x5AEE2D541530
0000792ccedd6eb2  call rax
0000792ccedd6eb4  movaps xmm3, [rsp]
0000792ccedd6eb8  add rsp, 0x30
0000792ccedd6ebc  vmovaps xmm0, [rsp]
0000792ccedd6ec1  vmovaps xmm1, [rsp+0x10]
0000792ccedd6ec7  vmovaps xmm2, [rsp+0x20]
0000792ccedd6ecd  vmovaps xmm4, [rsp+0x30]
0000792ccedd6ed3  vmovaps xmm5, [rsp+0x40]
0000792ccedd6ed9  vmovaps xmm6, [rsp+0x50]
0000792ccedd6edf  vmovaps xmm7, [rsp+0x60]
0000792ccedd6ee5  vmovaps xmm8, [rsp+0x70]
0000792ccedd6eeb  vmovaps xmm9, [rsp+0x80]
0000792ccedd6ef4  vmovaps xmm10, [rsp+0x90]
0000792ccedd6efd  vmovaps xmm11, [rsp+0xA0]
0000792ccedd6f06  vmovaps xmm12, [rsp+0xB0]
0000792ccedd6f0f  vmovaps xmm13, [rsp+0xC0]
0000792ccedd6f18  vmovaps xmm14, [rsp+0xD0]
0000792ccedd6f21  vmovaps xmm15, [rsp+0xE0]
0000792ccedd6f2a  add rsp, 0xF0
0000792ccedd6f31  pop r11
0000792ccedd6f33  pop r10
0000792ccedd6f35  pop r9
0000792ccedd6f37  pop r8
0000792ccedd6f39  pop rsi
0000792ccedd6f3a  pop rdi
0000792ccedd6f3b  pop rdx
0000792ccedd6f3c  pop rcx
0000792ccedd6f3d  pop rax
0000792ccedd6f3e  add rsp, 0x08
0000792ccedd6f42  jmp 0x0000792CCEDD5A88
0000792ccedd6f47  sub rsp, 0x08
0000792ccedd6f4b  push rax
0000792ccedd6f4c  push rcx
0000792ccedd6f4d  push rdx
0000792ccedd6f4e  push rdi
0000792ccedd6f4f  push rsi
0000792ccedd6f50  push r8
0000792ccedd6f52  push r9
0000792ccedd6f54  push r10
0000792ccedd6f56  push r11
0000792ccedd6f58  sub rsp, 0xF0
0000792ccedd6f5f  vmovaps [rsp], xmm0
0000792ccedd6f64  vmovaps [rsp+0x10], xmm1
0000792ccedd6f6a  vmovaps [rsp+0x20], xmm2
0000792ccedd6f70  vmovaps [rsp+0x30], xmm3
0000792ccedd6f76  vmovaps [rsp+0x40], xmm4
0000792ccedd6f7c  vmovaps [rsp+0x50], xmm6
0000792ccedd6f82  vmovaps [rsp+0x60], xmm7
0000792ccedd6f88  vmovaps [rsp+0x70], xmm8
0000792ccedd6f8e  vmovaps [rsp+0x80], xmm9
0000792ccedd6f97  vmovaps [rsp+0x90], xmm10
0000792ccedd6fa0  vmovaps [rsp+0xA0], xmm11
0000792ccedd6fa9  vmovaps [rsp+0xB0], xmm12
0000792ccedd6fb2  vmovaps [rsp+0xC0], xmm13
0000792ccedd6fbb  vmovaps [rsp+0xD0], xmm14
0000792ccedd6fc4  vmovaps [rsp+0xE0], xmm15
0000792ccedd6fcd  sub rsp, 0x30
0000792ccedd6fd1  movaps [rsp], xmm5
0000792ccedd6fd5  movaps [rsp+0x10], xmm8
0000792ccedd6fdb  movaps [rsp+0x20], xmm15
0000792ccedd6fe1  lea rdi, [rsp]
0000792ccedd6fe5  mov esi, 0x00
0000792ccedd6fea  mov rax, 0x5AEE2D541530
0000792ccedd6ff4  call rax
0000792ccedd6ff6  movaps xmm5, [rsp]
0000792ccedd6ffa  add rsp, 0x30
0000792ccedd6ffe  vmovaps xmm0, [rsp]
0000792ccedd7003  vmovaps xmm1, [rsp+0x10]
0000792ccedd7009  vmovaps xmm2, [rsp+0x20]
0000792ccedd700f  vmovaps xmm3, [rsp+0x30]
0000792ccedd7015  vmovaps xmm4, [rsp+0x40]
0000792ccedd701b  vmovaps xmm6, [rsp+0x50]
0000792ccedd7021  vmovaps xmm7, [rsp+0x60]
0000792ccedd7027  vmovaps xmm8, [rsp+0x70]
0000792ccedd702d  vmovaps xmm9, [rsp+0x80]
0000792ccedd7036  vmovaps xmm10, [rsp+0x90]
0000792ccedd703f  vmovaps xmm11, [rsp+0xA0]
0000792ccedd7048  vmovaps xmm12, [rsp+0xB0]
0000792ccedd7051  vmovaps xmm13, [rsp+0xC0]
0000792ccedd705a  vmovaps xmm14, [rsp+0xD0]
0000792ccedd7063  vmovaps xmm15, [rsp+0xE0]
0000792ccedd706c  add rsp, 0xF0
0000792ccedd7073  pop r11
0000792ccedd7075  pop r10
0000792ccedd7077  pop r9
0000792ccedd7079  pop r8
0000792ccedd707b  pop rsi
0000792ccedd707c  pop rdi
0000792ccedd707d  pop rdx
0000792ccedd707e  pop rcx
0000792ccedd707f  pop rax
0000792ccedd7080  add rsp, 0x08
0000792ccedd7084  jmp 0x0000792CCEDD5AC0
0000792ccedd7089  sub rsp, 0x08
0000792ccedd708d  push rax
0000792ccedd708e  push rcx
0000792ccedd708f  push rdx
0000792ccedd7090  push rdi
0000792ccedd7091  push rsi
0000792ccedd7092  push r8
0000792ccedd7094  push r9
0000792ccedd7096  push r10
0000792ccedd7098  push r11
0000792ccedd709a  sub rsp, 0xF0
0000792ccedd70a1  vmovaps [rsp], xmm0
0000792ccedd70a6  vmovaps [rsp+0x10], xmm1
0000792ccedd70ac  vmovaps [rsp+0x20], xmm2
0000792ccedd70b2  vmovaps [rsp+0x30], xmm3
0000792ccedd70b8  vmovaps [rsp+0x40], xmm5
0000792ccedd70be  vmovaps [rsp+0x50], xmm6
0000792ccedd70c4  vmovaps [rsp+0x60], xmm7
0000792ccedd70ca  vmovaps [rsp+0x70], xmm8
0000792ccedd70d0  vmovaps [rsp+0x80], xmm9
0000792ccedd70d9  vmovaps [rsp+0x90], xmm10
0000792ccedd70e2  vmovaps [rsp+0xA0], xmm11
0000792ccedd70eb  vmovaps [rsp+0xB0], xmm12
0000792ccedd70f4  vmovaps [rsp+0xC0], xmm13
0000792ccedd70fd  vmovaps [rsp+0xD0], xmm14
0000792ccedd7106  vmovaps [rsp+0xE0], xmm15
0000792ccedd710f  sub rsp, 0x30
0000792ccedd7113  movaps [rsp], xmm4
0000792ccedd7117  movaps [rsp+0x10], xmm9
0000792ccedd711d  movaps [rsp+0x20], xmm8
0000792ccedd7123  lea rdi, [rsp]
0000792ccedd7127  mov esi, 0x00
0000792ccedd712c  mov rax, 0x5AEE2D541530
0000792ccedd7136  call rax
0000792ccedd7138  movaps xmm4, [rsp]
0000792ccedd713c  add rsp, 0x30
0000792ccedd7140  vmovaps xmm0, [rsp]
0000792ccedd7145  vmovaps xmm1, [rsp+0x10]
0000792ccedd714b  vmovaps xmm2, [rsp+0x20]
0000792ccedd7151  vmovaps xmm3, [rsp+0x30]
0000792ccedd7157  vmovaps xmm5, [rsp+0x40]
0000792ccedd715d  vmovaps xmm6, [rsp+0x50]
0000792ccedd7163  vmovaps xmm7, [rsp+0x60]
0000792ccedd7169  vmovaps xmm8, [rsp+0x70]
0000792ccedd716f  vmovaps xmm9, [rsp+0x80]
0000792ccedd7178  vmovaps xmm10, [rsp+0x90]
0000792ccedd7181  vmovaps xmm11, [rsp+0xA0]
0000792ccedd718a  vmovaps xmm12, [rsp+0xB0]
0000792ccedd7193  vmovaps xmm13, [rsp+0xC0]
0000792ccedd719c  vmovaps xmm14, [rsp+0xD0]
0000792ccedd71a5  vmovaps xmm15, [rsp+0xE0]
0000792ccedd71ae  add rsp, 0xF0
0000792ccedd71b5  pop r11
0000792ccedd71b7  pop r10
0000792ccedd71b9  pop r9
0000792ccedd71bb  pop r8
0000792ccedd71bd  pop rsi
0000792ccedd71be  pop rdi
0000792ccedd71bf  pop rdx
0000792ccedd71c0  pop rcx
0000792ccedd71c1  pop rax
0000792ccedd71c2  add rsp, 0x08
0000792ccedd71c6  jmp 0x0000792CCEDD5AE1
0000792ccedd71cb  sub rsp, 0x08
0000792ccedd71cf  push rax
0000792ccedd71d0  push rcx
0000792ccedd71d1  push rdx
0000792ccedd71d2  push rdi
0000792ccedd71d3  push rsi
0000792ccedd71d4  push r8
0000792ccedd71d6  push r9
0000792ccedd71d8  push r10
0000792ccedd71da  push r11
0000792ccedd71dc  sub rsp, 0xF0
0000792ccedd71e3  vmovaps [rsp], xmm0
0000792ccedd71e8  vmovaps [rsp+0x10], xmm1
0000792ccedd71ee  vmovaps [rsp+0x20], xmm2
0000792ccedd71f4  vmovaps [rsp+0x30], xmm3
0000792ccedd71fa  vmovaps [rsp+0x40], xmm4
0000792ccedd7200  vmovaps [rsp+0x50], xmm5
0000792ccedd7206  vmovaps [rsp+0x60], xmm6
0000792ccedd720c  vmovaps [rsp+0x70], xmm7
0000792ccedd7212  vmovaps [rsp+0x80], xmm8
0000792ccedd721b  vmovaps [rsp+0x90], xmm10
0000792ccedd7224  vmovaps [rsp+0xA0], xmm11
0000792ccedd722d  vmovaps [rsp+0xB0], xmm12
0000792ccedd7236  vmovaps [rsp+0xC0], xmm13
0000792ccedd723f  vmovaps [rsp+0xD0], xmm14
0000792ccedd7248  vmovaps [rsp+0xE0], xmm15
0000792ccedd7251  sub rsp, 0x30
0000792ccedd7255  movaps [rsp], xmm9
0000792ccedd725a  movaps [rsp+0x10], xmm10
0000792ccedd7260  movaps [rsp+0x20], xmm8
0000792ccedd7266  lea rdi, [rsp]
0000792ccedd726a  mov esi, 0x00
0000792ccedd726f  mov rax, 0x5AEE2D541530
0000792ccedd7279  call rax
0000792ccedd727b  movaps xmm9, [rsp]
0000792ccedd7280  add rsp, 0x30
0000792ccedd7284  vmovaps xmm0, [rsp]
0000792ccedd7289  vmovaps xmm1, [rsp+0x10]
0000792ccedd728f  vmovaps xmm2, [rsp+0x20]
0000792ccedd7295  vmovaps xmm3, [rsp+0x30]
0000792ccedd729b  vmovaps xmm4, [rsp+0x40]
0000792ccedd72a1  vmovaps xmm5, [rsp+0x50]
0000792ccedd72a7  vmovaps xmm6, [rsp+0x60]
0000792ccedd72ad  vmovaps xmm7, [rsp+0x70]
0000792ccedd72b3  vmovaps xmm8, [rsp+0x80]
0000792ccedd72bc  vmovaps xmm10, [rsp+0x90]
0000792ccedd72c5  vmovaps xmm11, [rsp+0xA0]
0000792ccedd72ce  vmovaps xmm12, [rsp+0xB0]
0000792ccedd72d7  vmovaps xmm13, [rsp+0xC0]
0000792ccedd72e0  vmovaps xmm14, [rsp+0xD0]
0000792ccedd72e9  vmovaps xmm15, [rsp+0xE0]
0000792ccedd72f2  add rsp, 0xF0
0000792ccedd72f9  pop r11
0000792ccedd72fb  pop r10
0000792ccedd72fd  pop r9
0000792ccedd72ff  pop r8
0000792ccedd7301  pop rsi
0000792ccedd7302  pop rdi
0000792ccedd7303  pop rdx
0000792ccedd7304  pop rcx
0000792ccedd7305  pop rax
0000792ccedd7306  add rsp, 0x08
0000792ccedd730a  jmp 0x0000792CCEDD5AFB
0000792ccedd730f  call 0x0000792CCECD64F0
0000792ccedd7314  jmp 0x0000792CCEDD5C15
0000792ccedd7319  call 0x0000792CCECD64F0
0000792ccedd731e  jmp 0x0000792CCEDD5C2B
0000792ccedd7323  sub rsp, 0x08
0000792ccedd7327  push rax
0000792ccedd7328  push rcx
0000792ccedd7329  push rdx
0000792ccedd732a  push rdi
0000792ccedd732b  push rsi
0000792ccedd732c  push r8
0000792ccedd732e  push r9
0000792ccedd7330  push r10
0000792ccedd7332  push r11
0000792ccedd7334  sub rsp, 0xF0
0000792ccedd733b  vmovaps [rsp], xmm0
0000792ccedd7340  vmovaps [rsp+0x10], xmm2
0000792ccedd7346  vmovaps [rsp+0x20], xmm3
0000792ccedd734c  vmovaps [rsp+0x30], xmm4
0000792ccedd7352  vmovaps [rsp+0x40], xmm5
0000792ccedd7358  vmovaps [rsp+0x50], xmm6
0000792ccedd735e  vmovaps [rsp+0x60], xmm7
0000792ccedd7364  vmovaps [rsp+0x70], xmm8
0000792ccedd736a  vmovaps [rsp+0x80], xmm9
0000792ccedd7373  vmovaps [rsp+0x90], xmm10
0000792ccedd737c  vmovaps [rsp+0xA0], xmm11
0000792ccedd7385  vmovaps [rsp+0xB0], xmm12
0000792ccedd738e  vmovaps [rsp+0xC0], xmm13
0000792ccedd7397  vmovaps [rsp+0xD0], xmm14
0000792ccedd73a0  vmovaps [rsp+0xE0], xmm15
0000792ccedd73a9  sub rsp, 0x30
0000792ccedd73ad  movaps [rsp], xmm1
0000792ccedd73b1  movaps [rsp+0x10], xmm6
0000792ccedd73b6  movaps [rsp+0x20], xmm15
0000792ccedd73bc  lea rdi, [rsp]
0000792ccedd73c0  mov esi, 0x00
0000792ccedd73c5  mov rax, 0x5AEE2D541530
0000792ccedd73cf  call rax
0000792ccedd73d1  movaps xmm1, [rsp]
0000792ccedd73d5  add rsp, 0x30
0000792ccedd73d9  vmovaps xmm0, [rsp]
0000792ccedd73de  vmovaps xmm2, [rsp+0x10]
0000792ccedd73e4  vmovaps xmm3, [rsp+0x20]
0000792ccedd73ea  vmovaps xmm4, [rsp+0x30]
0000792ccedd73f0  vmovaps xmm5, [rsp+0x40]
0000792ccedd73f6  vmovaps xmm6, [rsp+0x50]
0000792ccedd73fc  vmovaps xmm7, [rsp+0x60]
0000792ccedd7402  vmovaps xmm8, [rsp+0x70]
0000792ccedd7408  vmovaps xmm9, [rsp+0x80]
0000792ccedd7411  vmovaps xmm10, [rsp+0x90]
0000792ccedd741a  vmovaps xmm11, [rsp+0xA0]
0000792ccedd7423  vmovaps xmm12, [rsp+0xB0]
0000792ccedd742c  vmovaps xmm13, [rsp+0xC0]
0000792ccedd7435  vmovaps xmm14, [rsp+0xD0]
0000792ccedd743e  vmovaps xmm15, [rsp+0xE0]
0000792ccedd7447  add rsp, 0xF0
0000792ccedd744e  pop r11
0000792ccedd7450  pop r10
0000792ccedd7452  pop r9
0000792ccedd7454  pop r8
0000792ccedd7456  pop rsi
0000792ccedd7457  pop rdi
0000792ccedd7458  pop rdx
0000792ccedd7459  pop rcx
0000792ccedd745a  pop rax
0000792ccedd745b  add rsp, 0x08
0000792ccedd745f  jmp 0x0000792CCEDD5C68
0000792ccedd7464  call 0x0000792CCECE5820
0000792ccedd7469  jmp 0x0000792CCEDD5C75
0000792ccedd746e  sub rsp, 0x08
0000792ccedd7472  push rax
0000792ccedd7473  push rcx
0000792ccedd7474  push rdx
0000792ccedd7475  push rdi
0000792ccedd7476  push rsi
0000792ccedd7477  push r8
0000792ccedd7479  push r9
0000792ccedd747b  push r10
0000792ccedd747d  push r11
0000792ccedd747f  sub rsp, 0xF0
0000792ccedd7486  vmovaps [rsp], xmm0
0000792ccedd748b  vmovaps [rsp+0x10], xmm1
0000792ccedd7491  vmovaps [rsp+0x20], xmm2
0000792ccedd7497  vmovaps [rsp+0x30], xmm3
0000792ccedd749d  vmovaps [rsp+0x40], xmm4
0000792ccedd74a3  vmovaps [rsp+0x50], xmm5
0000792ccedd74a9  vmovaps [rsp+0x60], xmm6
0000792ccedd74af  vmovaps [rsp+0x70], xmm7
0000792ccedd74b5  vmovaps [rsp+0x80], xmm8
0000792ccedd74be  vmovaps [rsp+0x90], xmm9
0000792ccedd74c7  vmovaps [rsp+0xA0], xmm10
0000792ccedd74d0  vmovaps [rsp+0xB0], xmm11
0000792ccedd74d9  vmovaps [rsp+0xC0], xmm12
0000792ccedd74e2  vmovaps [rsp+0xD0], xmm13
0000792ccedd74eb  vmovaps [rsp+0xE0], xmm15
0000792ccedd74f4  sub rsp, 0x30
0000792ccedd74f8  movaps [rsp], xmm14
0000792ccedd74fd  movaps [rsp+0x10], xmm4
0000792ccedd7502  movaps [rsp+0x20], xmm3
0000792ccedd7507  lea rdi, [rsp]
0000792ccedd750b  mov esi, 0x00
0000792ccedd7510  mov rax, 0x5AEE2D541530
0000792ccedd751a  call rax
0000792ccedd751c  movaps xmm14, [rsp]
0000792ccedd7521  add rsp, 0x30
0000792ccedd7525  vmovaps xmm0, [rsp]
0000792ccedd752a  vmovaps xmm1, [rsp+0x10]
0000792ccedd7530  vmovaps xmm2, [rsp+0x20]
0000792ccedd7536  vmovaps xmm3, [rsp+0x30]
0000792ccedd753c  vmovaps xmm4, [rsp+0x40]
0000792ccedd7542  vmovaps xmm5, [rsp+0x50]
0000792ccedd7548  vmovaps xmm6, [rsp+0x60]
0000792ccedd754e  vmovaps xmm7, [rsp+0x70]
0000792ccedd7554  vmovaps xmm8, [rsp+0x80]
0000792ccedd755d  vmovaps xmm9, [rsp+0x90]
0000792ccedd7566  vmovaps xmm10, [rsp+0xA0]
0000792ccedd756f  vmovaps xmm11, [rsp+0xB0]
0000792ccedd7578  vmovaps xmm12, [rsp+0xC0]
0000792ccedd7581  vmovaps xmm13, [rsp+0xD0]
0000792ccedd758a  vmovaps xmm15, [rsp+0xE0]
0000792ccedd7593  add rsp, 0xF0
0000792ccedd759a  pop r11
0000792ccedd759c  pop r10
0000792ccedd759e  pop r9
0000792ccedd75a0  pop r8
0000792ccedd75a2  pop rsi
0000792ccedd75a3  pop rdi
0000792ccedd75a4  pop rdx
0000792ccedd75a5  pop rcx
0000792ccedd75a6  pop rax
0000792ccedd75a7  add rsp, 0x08
0000792ccedd75ab  jmp 0x0000792CCEDD5C8F
0000792ccedd75b0  sub rsp, 0x08
0000792ccedd75b4  push rax
0000792ccedd75b5  push rcx
0000792ccedd75b6  push rdx
0000792ccedd75b7  push rdi
0000792ccedd75b8  push rsi
0000792ccedd75b9  push r8
0000792ccedd75bb  push r9
0000792ccedd75bd  push r10
0000792ccedd75bf  push r11
0000792ccedd75c1  sub rsp, 0xF0
0000792ccedd75c8  vmovaps [rsp], xmm0
0000792ccedd75cd  vmovaps [rsp+0x10], xmm1
0000792ccedd75d3  vmovaps [rsp+0x20], xmm2
0000792ccedd75d9  vmovaps [rsp+0x30], xmm3
0000792ccedd75df  vmovaps [rsp+0x40], xmm4
0000792ccedd75e5  vmovaps [rsp+0x50], xmm5
0000792ccedd75eb  vmovaps [rsp+0x60], xmm7
0000792ccedd75f1  vmovaps [rsp+0x70], xmm8
0000792ccedd75f7  vmovaps [rsp+0x80], xmm9
0000792ccedd7600  vmovaps [rsp+0x90], xmm10
0000792ccedd7609  vmovaps [rsp+0xA0], xmm11
0000792ccedd7612  vmovaps [rsp+0xB0], xmm12
0000792ccedd761b  vmovaps [rsp+0xC0], xmm13
0000792ccedd7624  vmovaps [rsp+0xD0], xmm14
0000792ccedd762d  vmovaps [rsp+0xE0], xmm15
0000792ccedd7636  sub rsp, 0x30
0000792ccedd763a  movaps [rsp], xmm6
0000792ccedd763e  movaps [rsp+0x10], xmm9
0000792ccedd7644  movaps [rsp+0x20], xmm7
0000792ccedd7649  lea rdi, [rsp]
0000792ccedd764d  mov esi, 0x00
0000792ccedd7652  mov rax, 0x5AEE2D541530
0000792ccedd765c  call rax
0000792ccedd765e  movaps xmm6, [rsp]
0000792ccedd7662  add rsp, 0x30
0000792ccedd7666  vmovaps xmm0, [rsp]
0000792ccedd766b  vmovaps xmm1, [rsp+0x10]
0000792ccedd7671  vmovaps xmm2, [rsp+0x20]
0000792ccedd7677  vmovaps xmm3, [rsp+0x30]
0000792ccedd767d  vmovaps xmm4, [rsp+0x40]
0000792ccedd7683  vmovaps xmm5, [rsp+0x50]
0000792ccedd7689  vmovaps xmm7, [rsp+0x60]
0000792ccedd768f  vmovaps xmm8, [rsp+0x70]
0000792ccedd7695  vmovaps xmm9, [rsp+0x80]
0000792ccedd769e  vmovaps xmm10, [rsp+0x90]
0000792ccedd76a7  vmovaps xmm11, [rsp+0xA0]
0000792ccedd76b0  vmovaps xmm12, [rsp+0xB0]
0000792ccedd76b9  vmovaps xmm13, [rsp+0xC0]
0000792ccedd76c2  vmovaps xmm14, [rsp+0xD0]
0000792ccedd76cb  vmovaps xmm15, [rsp+0xE0]
0000792ccedd76d4  add rsp, 0xF0
0000792ccedd76db  pop r11
0000792ccedd76dd  pop r10
0000792ccedd76df  pop r9
0000792ccedd76e1  pop r8
0000792ccedd76e3  pop rsi
0000792ccedd76e4  pop rdi
0000792ccedd76e5  pop rdx
0000792ccedd76e6  pop rcx
0000792ccedd76e7  pop rax
0000792ccedd76e8  add rsp, 0x08
0000792ccedd76ec  jmp 0x0000792CCEDD5CA7
0000792ccedd76f1  sub rsp, 0x08
0000792ccedd76f5  push rax
0000792ccedd76f6  push rcx
0000792ccedd76f7  push rdx
0000792ccedd76f8  push rdi
0000792ccedd76f9  push rsi
0000792ccedd76fa  push r8
0000792ccedd76fc  push r9
0000792ccedd76fe  push r10
0000792ccedd7700  push r11
0000792ccedd7702  sub rsp, 0xF0
0000792ccedd7709  vmovaps [rsp], xmm0
0000792ccedd770e  vmovaps [rsp+0x10], xmm1
0000792ccedd7714  vmovaps [rsp+0x20], xmm2
0000792ccedd771a  vmovaps [rsp+0x30], xmm3
0000792ccedd7720  vmovaps [rsp+0x40], xmm4
0000792ccedd7726  vmovaps [rsp+0x50], xmm5
0000792ccedd772c  vmovaps [rsp+0x60], xmm6
0000792ccedd7732  vmovaps [rsp+0x70], xmm8
0000792ccedd7738  vmovaps [rsp+0x80], xmm9
0000792ccedd7741  vmovaps [rsp+0x90], xmm10
0000792ccedd774a  vmovaps [rsp+0xA0], xmm11
0000792ccedd7753  vmovaps [rsp+0xB0], xmm12
0000792ccedd775c  vmovaps [rsp+0xC0], xmm13
0000792ccedd7765  vmovaps [rsp+0xD0], xmm14
0000792ccedd776e  vmovaps [rsp+0xE0], xmm15
0000792ccedd7777  sub rsp, 0x30
0000792ccedd777b  movaps [rsp], xmm7
0000792ccedd777f  movaps [rsp+0x10], xmm4
0000792ccedd7784  movaps [rsp+0x20], xmm9
0000792ccedd778a  lea rdi, [rsp]
0000792ccedd778e  mov esi, 0x00
0000792ccedd7793  mov rax, 0x5AEE2D541530
0000792ccedd779d  call rax
0000792ccedd779f  movaps xmm7, [rsp]
0000792ccedd77a3  add rsp, 0x30
0000792ccedd77a7  vmovaps xmm0, [rsp]
0000792ccedd77ac  vmovaps xmm1, [rsp+0x10]
0000792ccedd77b2  vmovaps xmm2, [rsp+0x20]
0000792ccedd77b8  vmovaps xmm3, [rsp+0x30]
0000792ccedd77be  vmovaps xmm4, [rsp+0x40]
0000792ccedd77c4  vmovaps xmm5, [rsp+0x50]
0000792ccedd77ca  vmovaps xmm6, [rsp+0x60]
0000792ccedd77d0  vmovaps xmm8, [rsp+0x70]
0000792ccedd77d6  vmovaps xmm9, [rsp+0x80]
0000792ccedd77df  vmovaps xmm10, [rsp+0x90]
0000792ccedd77e8  vmovaps xmm11, [rsp+0xA0]
0000792ccedd77f1  vmovaps xmm12, [rsp+0xB0]
0000792ccedd77fa  vmovaps xmm13, [rsp+0xC0]
0000792ccedd7803  vmovaps xmm14, [rsp+0xD0]
0000792ccedd780c  vmovaps xmm15, [rsp+0xE0]
0000792ccedd7815  add rsp, 0xF0
0000792ccedd781c  pop r11
0000792ccedd781e  pop r10
0000792ccedd7820  pop r9
0000792ccedd7822  pop r8
0000792ccedd7824  pop rsi
0000792ccedd7825  pop rdi
0000792ccedd7826  pop rdx
0000792ccedd7827  pop rcx
0000792ccedd7828  pop rax
0000792ccedd7829  add rsp, 0x08
0000792ccedd782d  jmp 0x0000792CCEDD5CD4
0000792ccedd7832  sub rsp, 0x08
0000792ccedd7836  push rax
0000792ccedd7837  push rcx
0000792ccedd7838  push rdx
0000792ccedd7839  push rdi
0000792ccedd783a  push rsi
0000792ccedd783b  push r8
0000792ccedd783d  push r9
0000792ccedd783f  push r10
0000792ccedd7841  push r11
0000792ccedd7843  sub rsp, 0xF0
0000792ccedd784a  vmovaps [rsp], xmm0
0000792ccedd784f  vmovaps [rsp+0x10], xmm1
0000792ccedd7855  vmovaps [rsp+0x20], xmm2
0000792ccedd785b  vmovaps [rsp+0x30], xmm3
0000792ccedd7861  vmovaps [rsp+0x40], xmm5
0000792ccedd7867  vmovaps [rsp+0x50], xmm6
0000792ccedd786d  vmovaps [rsp+0x60], xmm7
0000792ccedd7873  vmovaps [rsp+0x70], xmm8
0000792ccedd7879  vmovaps [rsp+0x80], xmm9
0000792ccedd7882  vmovaps [rsp+0x90], xmm10
0000792ccedd788b  vmovaps [rsp+0xA0], xmm11
0000792ccedd7894  vmovaps [rsp+0xB0], xmm12
0000792ccedd789d  vmovaps [rsp+0xC0], xmm13
0000792ccedd78a6  vmovaps [rsp+0xD0], xmm14
0000792ccedd78af  vmovaps [rsp+0xE0], xmm15
0000792ccedd78b8  sub rsp, 0x30
0000792ccedd78bc  movaps [rsp], xmm4
0000792ccedd78c0  movaps [rsp+0x10], xmm15
0000792ccedd78c6  movaps [rsp+0x20], xmm9
0000792ccedd78cc  lea rdi, [rsp]
0000792ccedd78d0  mov esi, 0x00
0000792ccedd78d5  mov rax, 0x5AEE2D541530
0000792ccedd78df  call rax
0000792ccedd78e1  movaps xmm4, [rsp]
0000792ccedd78e5  add rsp, 0x30
0000792ccedd78e9  vmovaps xmm0, [rsp]
0000792ccedd78ee  vmovaps xmm1, [rsp+0x10]
0000792ccedd78f4  vmovaps xmm2, [rsp+0x20]
0000792ccedd78fa  vmovaps xmm3, [rsp+0x30]
0000792ccedd7900  vmovaps xmm5, [rsp+0x40]
0000792ccedd7906  vmovaps xmm6, [rsp+0x50]
0000792ccedd790c  vmovaps xmm7, [rsp+0x60]
0000792ccedd7912  vmovaps xmm8, [rsp+0x70]
0000792ccedd7918  vmovaps xmm9, [rsp+0x80]
0000792ccedd7921  vmovaps xmm10, [rsp+0x90]
0000792ccedd792a  vmovaps xmm11, [rsp+0xA0]
0000792ccedd7933  vmovaps xmm12, [rsp+0xB0]
0000792ccedd793c  vmovaps xmm13, [rsp+0xC0]
0000792ccedd7945  vmovaps xmm14, [rsp+0xD0]
0000792ccedd794e  vmovaps xmm15, [rsp+0xE0]
0000792ccedd7957  add rsp, 0xF0
0000792ccedd795e  pop r11
0000792ccedd7960  pop r10
0000792ccedd7962  pop r9
0000792ccedd7964  pop r8
0000792ccedd7966  pop rsi
0000792ccedd7967  pop rdi
0000792ccedd7968  pop rdx
0000792ccedd7969  pop rcx
0000792ccedd796a  pop rax
0000792ccedd796b  add rsp, 0x08
0000792ccedd796f  jmp 0x0000792CCEDD5CF9
0000792ccedd7974  call 0x0000792CCECE5820
0000792ccedd7979  jmp 0x0000792CCEDD5D06
0000792ccedd797e  sub rsp, 0x08
0000792ccedd7982  push rax
0000792ccedd7983  push rcx
0000792ccedd7984  push rdx
0000792ccedd7985  push rdi
0000792ccedd7986  push rsi
0000792ccedd7987  push r8
0000792ccedd7989  push r9
0000792ccedd798b  push r10
0000792ccedd798d  push r11
0000792ccedd798f  sub rsp, 0xF0
0000792ccedd7996  vmovaps [rsp], xmm0
0000792ccedd799b  vmovaps [rsp+0x10], xmm1
0000792ccedd79a1  vmovaps [rsp+0x20], xmm2
0000792ccedd79a7  vmovaps [rsp+0x30], xmm4
0000792ccedd79ad  vmovaps [rsp+0x40], xmm5
0000792ccedd79b3  vmovaps [rsp+0x50], xmm6
0000792ccedd79b9  vmovaps [rsp+0x60], xmm7
0000792ccedd79bf  vmovaps [rsp+0x70], xmm8
0000792ccedd79c5  vmovaps [rsp+0x80], xmm9
0000792ccedd79ce  vmovaps [rsp+0x90], xmm10
0000792ccedd79d7  vmovaps [rsp+0xA0], xmm11
0000792ccedd79e0  vmovaps [rsp+0xB0], xmm12
0000792ccedd79e9  vmovaps [rsp+0xC0], xmm13
0000792ccedd79f2  vmovaps [rsp+0xD0], xmm14
0000792ccedd79fb  vmovaps [rsp+0xE0], xmm15
0000792ccedd7a04  sub rsp, 0x30
0000792ccedd7a08  movaps [rsp], xmm3
0000792ccedd7a0c  movaps [rsp+0x10], xmm1
0000792ccedd7a11  movaps [rsp+0x20], xmm9
0000792ccedd7a17  lea rdi, [rsp]
0000792ccedd7a1b  mov esi, 0x00
0000792ccedd7a20  mov rax, 0x5AEE2D541530
0000792ccedd7a2a  call rax
0000792ccedd7a2c  movaps xmm3, [rsp]
0000792ccedd7a30  add rsp, 0x30
0000792ccedd7a34  vmovaps xmm0, [rsp]
0000792ccedd7a39  vmovaps xmm1, [rsp+0x10]
0000792ccedd7a3f  vmovaps xmm2, [rsp+0x20]
0000792ccedd7a45  vmovaps xmm4, [rsp+0x30]
0000792ccedd7a4b  vmovaps xmm5, [rsp+0x40]
0000792ccedd7a51  vmovaps xmm6, [rsp+0x50]
0000792ccedd7a57  vmovaps xmm7, [rsp+0x60]
0000792ccedd7a5d  vmovaps xmm8, [rsp+0x70]
0000792ccedd7a63  vmovaps xmm9, [rsp+0x80]
0000792ccedd7a6c  vmovaps xmm10, [rsp+0x90]
0000792ccedd7a75  vmovaps xmm11, [rsp+0xA0]
0000792ccedd7a7e  vmovaps xmm12, [rsp+0xB0]
0000792ccedd7a87  vmovaps xmm13, [rsp+0xC0]
0000792ccedd7a90  vmovaps xmm14, [rsp+0xD0]
0000792ccedd7a99  vmovaps xmm15, [rsp+0xE0]
0000792ccedd7aa2  add rsp, 0xF0
0000792ccedd7aa9  pop r11
0000792ccedd7aab  pop r10
0000792ccedd7aad  pop r9
0000792ccedd7aaf  pop r8
0000792ccedd7ab1  pop rsi
0000792ccedd7ab2  pop rdi
0000792ccedd7ab3  pop rdx
0000792ccedd7ab4  pop rcx
0000792ccedd7ab5  pop rax
0000792ccedd7ab6  add rsp, 0x08
0000792ccedd7aba  jmp 0x0000792CCEDD5D43
0000792ccedd7abf  sub rsp, 0x08
0000792ccedd7ac3  push rax
0000792ccedd7ac4  push rcx
0000792ccedd7ac5  push rdx
0000792ccedd7ac6  push rdi
0000792ccedd7ac7  push rsi
0000792ccedd7ac8  push r8
0000792ccedd7aca  push r9
0000792ccedd7acc  push r10
0000792ccedd7ace  push r11
0000792ccedd7ad0  sub rsp, 0xF0
0000792ccedd7ad7  vmovaps [rsp], xmm0
0000792ccedd7adc  vmovaps [rsp+0x10], xmm2
0000792ccedd7ae2  vmovaps [rsp+0x20], xmm3
0000792ccedd7ae8  vmovaps [rsp+0x30], xmm4
0000792ccedd7aee  vmovaps [rsp+0x40], xmm5
0000792ccedd7af4  vmovaps [rsp+0x50], xmm6
0000792ccedd7afa  vmovaps [rsp+0x60], xmm7
0000792ccedd7b00  vmovaps [rsp+0x70], xmm8
0000792ccedd7b06  vmovaps [rsp+0x80], xmm9
0000792ccedd7b0f  vmovaps [rsp+0x90], xmm10
0000792ccedd7b18  vmovaps [rsp+0xA0], xmm11
0000792ccedd7b21  vmovaps [rsp+0xB0], xmm12
0000792ccedd7b2a  vmovaps [rsp+0xC0], xmm13
0000792ccedd7b33  vmovaps [rsp+0xD0], xmm14
0000792ccedd7b3c  vmovaps [rsp+0xE0], xmm15
0000792ccedd7b45  sub rsp, 0x30
0000792ccedd7b49  movaps [rsp], xmm1
0000792ccedd7b4d  movaps [rsp+0x10], xmm15
0000792ccedd7b53  movaps [rsp+0x20], xmm9
0000792ccedd7b59  lea rdi, [rsp]
0000792ccedd7b5d  mov esi, 0x00
0000792ccedd7b62  mov rax, 0x5AEE2D541530
0000792ccedd7b6c  call rax
0000792ccedd7b6e  movaps xmm1, [rsp]
0000792ccedd7b72  add rsp, 0x30
0000792ccedd7b76  vmovaps xmm0, [rsp]
0000792ccedd7b7b  vmovaps xmm2, [rsp+0x10]
0000792ccedd7b81  vmovaps xmm3, [rsp+0x20]
0000792ccedd7b87  vmovaps xmm4, [rsp+0x30]
0000792ccedd7b8d  vmovaps xmm5, [rsp+0x40]
0000792ccedd7b93  vmovaps xmm6, [rsp+0x50]
0000792ccedd7b99  vmovaps xmm7, [rsp+0x60]
0000792ccedd7b9f  vmovaps xmm8, [rsp+0x70]
0000792ccedd7ba5  vmovaps xmm9, [rsp+0x80]
0000792ccedd7bae  vmovaps xmm10, [rsp+0x90]
0000792ccedd7bb7  vmovaps xmm11, [rsp+0xA0]
0000792ccedd7bc0  vmovaps xmm12, [rsp+0xB0]
0000792ccedd7bc9  vmovaps xmm13, [rsp+0xC0]
0000792ccedd7bd2  vmovaps xmm14, [rsp+0xD0]
0000792ccedd7bdb  vmovaps xmm15, [rsp+0xE0]
0000792ccedd7be4  add rsp, 0xF0
0000792ccedd7beb  pop r11
0000792ccedd7bed  pop r10
0000792ccedd7bef  pop r9
0000792ccedd7bf1  pop r8
0000792ccedd7bf3  pop rsi
0000792ccedd7bf4  pop rdi
0000792ccedd7bf5  pop rdx
0000792ccedd7bf6  pop rcx
0000792ccedd7bf7  pop rax
0000792ccedd7bf8  add rsp, 0x08
0000792ccedd7bfc  jmp 0x0000792CCEDD5DCB
0000792ccedd7c01  call 0x0000792CCECE5820
0000792ccedd7c06  jmp 0x0000792CCEDD5DD8
0000792ccedd7c0b  sub rsp, 0x08
0000792ccedd7c0f  push rax
0000792ccedd7c10  push rcx
0000792ccedd7c11  push rdx
0000792ccedd7c12  push rdi
0000792ccedd7c13  push rsi
0000792ccedd7c14  push r8
0000792ccedd7c16  push r9
0000792ccedd7c18  push r10
0000792ccedd7c1a  push r11
0000792ccedd7c1c  sub rsp, 0xF0
0000792ccedd7c23  vmovaps [rsp], xmm0
0000792ccedd7c28  vmovaps [rsp+0x10], xmm2
0000792ccedd7c2e  vmovaps [rsp+0x20], xmm3
0000792ccedd7c34  vmovaps [rsp+0x30], xmm4
0000792ccedd7c3a  vmovaps [rsp+0x40], xmm5
0000792ccedd7c40  vmovaps [rsp+0x50], xmm6
0000792ccedd7c46  vmovaps [rsp+0x60], xmm7
0000792ccedd7c4c  vmovaps [rsp+0x70], xmm8
0000792ccedd7c52  vmovaps [rsp+0x80], xmm9
0000792ccedd7c5b  vmovaps [rsp+0x90], xmm10
0000792ccedd7c64  vmovaps [rsp+0xA0], xmm11
0000792ccedd7c6d  vmovaps [rsp+0xB0], xmm12
0000792ccedd7c76  vmovaps [rsp+0xC0], xmm13
0000792ccedd7c7f  vmovaps [rsp+0xD0], xmm14
0000792ccedd7c88  vmovaps [rsp+0xE0], xmm15
0000792ccedd7c91  sub rsp, 0x30
0000792ccedd7c95  movaps [rsp], xmm1
0000792ccedd7c99  movaps [rsp+0x10], xmm5
0000792ccedd7c9e  movaps [rsp+0x20], xmm7
0000792ccedd7ca3  lea rdi, [rsp]
0000792ccedd7ca7  mov esi, 0x00
0000792ccedd7cac  mov rax, 0x5AEE2D541530
0000792ccedd7cb6  call rax
0000792ccedd7cb8  movaps xmm1, [rsp]
0000792ccedd7cbc  add rsp, 0x30
0000792ccedd7cc0  vmovaps xmm0, [rsp]
0000792ccedd7cc5  vmovaps xmm2, [rsp+0x10]
0000792ccedd7ccb  vmovaps xmm3, [rsp+0x20]
0000792ccedd7cd1  vmovaps xmm4, [rsp+0x30]
0000792ccedd7cd7  vmovaps xmm5, [rsp+0x40]
0000792ccedd7cdd  vmovaps xmm6, [rsp+0x50]
0000792ccedd7ce3  vmovaps xmm7, [rsp+0x60]
0000792ccedd7ce9  vmovaps xmm8, [rsp+0x70]
0000792ccedd7cef  vmovaps xmm9, [rsp+0x80]
0000792ccedd7cf8  vmovaps xmm10, [rsp+0x90]
0000792ccedd7d01  vmovaps xmm11, [rsp+0xA0]
0000792ccedd7d0a  vmovaps xmm12, [rsp+0xB0]
0000792ccedd7d13  vmovaps xmm13, [rsp+0xC0]
0000792ccedd7d1c  vmovaps xmm14, [rsp+0xD0]
0000792ccedd7d25  vmovaps xmm15, [rsp+0xE0]
0000792ccedd7d2e  add rsp, 0xF0
0000792ccedd7d35  pop r11
0000792ccedd7d37  pop r10
0000792ccedd7d39  pop r9
0000792ccedd7d3b  pop r8
0000792ccedd7d3d  pop rsi
0000792ccedd7d3e  pop rdi
0000792ccedd7d3f  pop rdx
0000792ccedd7d40  pop rcx
0000792ccedd7d41  pop rax
0000792ccedd7d42  add rsp, 0x08
0000792ccedd7d46  jmp 0x0000792CCEDD5E7D
0000792ccedd7d4b  sub rsp, 0x08
0000792ccedd7d4f  push rax
0000792ccedd7d50  push rcx
0000792ccedd7d51  push rdx
0000792ccedd7d52  push rdi
0000792ccedd7d53  push rsi
0000792ccedd7d54  push r8
0000792ccedd7d56  push r9
0000792ccedd7d58  push r10
0000792ccedd7d5a  push r11
0000792ccedd7d5c  sub rsp, 0xF0
0000792ccedd7d63  vmovaps [rsp], xmm0
0000792ccedd7d68  vmovaps [rsp+0x10], xmm1
0000792ccedd7d6e  vmovaps [rsp+0x20], xmm2
0000792ccedd7d74  vmovaps [rsp+0x30], xmm3
0000792ccedd7d7a  vmovaps [rsp+0x40], xmm4
0000792ccedd7d80  vmovaps [rsp+0x50], xmm5
0000792ccedd7d86  vmovaps [rsp+0x60], xmm6
0000792ccedd7d8c  vmovaps [rsp+0x70], xmm8
0000792ccedd7d92  vmovaps [rsp+0x80], xmm9
0000792ccedd7d9b  vmovaps [rsp+0x90], xmm10
0000792ccedd7da4  vmovaps [rsp+0xA0], xmm11
0000792ccedd7dad  vmovaps [rsp+0xB0], xmm12
0000792ccedd7db6  vmovaps [rsp+0xC0], xmm13
0000792ccedd7dbf  vmovaps [rsp+0xD0], xmm14
0000792ccedd7dc8  vmovaps [rsp+0xE0], xmm15
0000792ccedd7dd1  sub rsp, 0x30
0000792ccedd7dd5  movaps [rsp], xmm7
0000792ccedd7dd9  movaps [rsp+0x10], xmm5
0000792ccedd7dde  movaps [rsp+0x20], xmm15
0000792ccedd7de4  lea rdi, [rsp]
0000792ccedd7de8  mov esi, 0x00
0000792ccedd7ded  mov rax, 0x5AEE2D541530
0000792ccedd7df7  call rax
0000792ccedd7df9  movaps xmm7, [rsp]
0000792ccedd7dfd  add rsp, 0x30
0000792ccedd7e01  vmovaps xmm0, [rsp]
0000792ccedd7e06  vmovaps xmm1, [rsp+0x10]
0000792ccedd7e0c  vmovaps xmm2, [rsp+0x20]
0000792ccedd7e12  vmovaps xmm3, [rsp+0x30]
0000792ccedd7e18  vmovaps xmm4, [rsp+0x40]
0000792ccedd7e1e  vmovaps xmm5, [rsp+0x50]
0000792ccedd7e24  vmovaps xmm6, [rsp+0x60]
0000792ccedd7e2a  vmovaps xmm8, [rsp+0x70]
0000792ccedd7e30  vmovaps xmm9, [rsp+0x80]
0000792ccedd7e39  vmovaps xmm10, [rsp+0x90]
0000792ccedd7e42  vmovaps xmm11, [rsp+0xA0]
0000792ccedd7e4b  vmovaps xmm12, [rsp+0xB0]
0000792ccedd7e54  vmovaps xmm13, [rsp+0xC0]
0000792ccedd7e5d  vmovaps xmm14, [rsp+0xD0]
0000792ccedd7e66  vmovaps xmm15, [rsp+0xE0]
0000792ccedd7e6f  add rsp, 0xF0
0000792ccedd7e76  pop r11
0000792ccedd7e78  pop r10
0000792ccedd7e7a  pop r9
0000792ccedd7e7c  pop r8
0000792ccedd7e7e  pop rsi
0000792ccedd7e7f  pop rdi
0000792ccedd7e80  pop rdx
0000792ccedd7e81  pop rcx
0000792ccedd7e82  pop rax
0000792ccedd7e83  add rsp, 0x08
0000792ccedd7e87  jmp 0x0000792CCEDD5EB3
0000792ccedd7e8c  call 0x0000792CCECD64F0
0000792ccedd7e91  jmp 0x0000792CCEDD5EC0
0000792ccedd7e96  sub rsp, 0x08
0000792ccedd7e9a  push rax
0000792ccedd7e9b  push rcx
0000792ccedd7e9c  push rdx
0000792ccedd7e9d  push rdi
0000792ccedd7e9e  push rsi
0000792ccedd7e9f  push r8
0000792ccedd7ea1  push r9
0000792ccedd7ea3  push r10
0000792ccedd7ea5  push r11
0000792ccedd7ea7  sub rsp, 0xF0
0000792ccedd7eae  vmovaps [rsp], xmm0
0000792ccedd7eb3  vmovaps [rsp+0x10], xmm1
0000792ccedd7eb9  vmovaps [rsp+0x20], xmm2
0000792ccedd7ebf  vmovaps [rsp+0x30], xmm3
0000792ccedd7ec5  vmovaps [rsp+0x40], xmm4
0000792ccedd7ecb  vmovaps [rsp+0x50], xmm5
0000792ccedd7ed1  vmovaps [rsp+0x60], xmm6
0000792ccedd7ed7  vmovaps [rsp+0x70], xmm7
0000792ccedd7edd  vmovaps [rsp+0x80], xmm8
0000792ccedd7ee6  vmovaps [rsp+0x90], xmm9
0000792ccedd7eef  vmovaps [rsp+0xA0], xmm10
0000792ccedd7ef8  vmovaps [rsp+0xB0], xmm11
0000792ccedd7f01  vmovaps [rsp+0xC0], xmm12
0000792ccedd7f0a  vmovaps [rsp+0xD0], xmm13
0000792ccedd7f13  vmovaps [rsp+0xE0], xmm14
0000792ccedd7f1c  sub rsp, 0x30
0000792ccedd7f20  movaps [rsp], xmm15
0000792ccedd7f25  movaps [rsp+0x10], xmm5
0000792ccedd7f2a  movaps [rsp+0x20], xmm3
0000792ccedd7f2f  lea rdi, [rsp]
0000792ccedd7f33  mov esi, 0x00
0000792ccedd7f38  mov rax, 0x5AEE2D541530
0000792ccedd7f42  call rax
0000792ccedd7f44  movaps xmm15, [rsp]
0000792ccedd7f49  add rsp, 0x30
0000792ccedd7f4d  vmovaps xmm0, [rsp]
0000792ccedd7f52  vmovaps xmm1, [rsp+0x10]
0000792ccedd7f58  vmovaps xmm2, [rsp+0x20]
0000792ccedd7f5e  vmovaps xmm3, [rsp+0x30]
0000792ccedd7f64  vmovaps xmm4, [rsp+0x40]
0000792ccedd7f6a  vmovaps xmm5, [rsp+0x50]
0000792ccedd7f70  vmovaps xmm6, [rsp+0x60]
0000792ccedd7f76  vmovaps xmm7, [rsp+0x70]
0000792ccedd7f7c  vmovaps xmm8, [rsp+0x80]
0000792ccedd7f85  vmovaps xmm9, [rsp+0x90]
0000792ccedd7f8e  vmovaps xmm10, [rsp+0xA0]
0000792ccedd7f97  vmovaps xmm11, [rsp+0xB0]
0000792ccedd7fa0  vmovaps xmm12, [rsp+0xC0]
0000792ccedd7fa9  vmovaps xmm13, [rsp+0xD0]
0000792ccedd7fb2  vmovaps xmm14, [rsp+0xE0]
0000792ccedd7fbb  add rsp, 0xF0
0000792ccedd7fc2  pop r11
0000792ccedd7fc4  pop r10
0000792ccedd7fc6  pop r9
0000792ccedd7fc8  pop r8
0000792ccedd7fca  pop rsi
0000792ccedd7fcb  pop rdi
0000792ccedd7fcc  pop rdx
0000792ccedd7fcd  pop rcx
0000792ccedd7fce  pop rax
0000792ccedd7fcf  add rsp, 0x08
0000792ccedd7fd3  jmp 0x0000792CCEDD5EE6
0000792ccedd7fd8  sub rsp, 0x08
0000792ccedd7fdc  push rax
0000792ccedd7fdd  push rcx
0000792ccedd7fde  push rdx
0000792ccedd7fdf  push rdi
0000792ccedd7fe0  push rsi
0000792ccedd7fe1  push r8
0000792ccedd7fe3  push r9
0000792ccedd7fe5  push r10
0000792ccedd7fe7  push r11
0000792ccedd7fe9  sub rsp, 0xF0
0000792ccedd7ff0  vmovaps [rsp], xmm0
0000792ccedd7ff5  vmovaps [rsp+0x10], xmm2
0000792ccedd7ffb  vmovaps [rsp+0x20], xmm3
0000792ccedd8001  vmovaps [rsp+0x30], xmm4
0000792ccedd8007  vmovaps [rsp+0x40], xmm5
0000792ccedd800d  vmovaps [rsp+0x50], xmm6
0000792ccedd8013  vmovaps [rsp+0x60], xmm7
0000792ccedd8019  vmovaps [rsp+0x70], xmm8
0000792ccedd801f  vmovaps [rsp+0x80], xmm9
0000792ccedd8028  vmovaps [rsp+0x90], xmm10
0000792ccedd8031  vmovaps [rsp+0xA0], xmm11
0000792ccedd803a  vmovaps [rsp+0xB0], xmm12
0000792ccedd8043  vmovaps [rsp+0xC0], xmm13
0000792ccedd804c  vmovaps [rsp+0xD0], xmm14
0000792ccedd8055  vmovaps [rsp+0xE0], xmm15
0000792ccedd805e  sub rsp, 0x30
0000792ccedd8062  movaps [rsp], xmm1
0000792ccedd8066  movaps [rsp+0x10], xmm5
0000792ccedd806b  movaps [rsp+0x20], xmm4
0000792ccedd8070  lea rdi, [rsp]
0000792ccedd8074  mov esi, 0x00
0000792ccedd8079  mov rax, 0x5AEE2D541530
0000792ccedd8083  call rax
0000792ccedd8085  movaps xmm1, [rsp]
0000792ccedd8089  add rsp, 0x30
0000792ccedd808d  vmovaps xmm0, [rsp]
0000792ccedd8092  vmovaps xmm2, [rsp+0x10]
0000792ccedd8098  vmovaps xmm3, [rsp+0x20]
0000792ccedd809e  vmovaps xmm4, [rsp+0x30]
0000792ccedd80a4  vmovaps xmm5, [rsp+0x40]
0000792ccedd80aa  vmovaps xmm6, [rsp+0x50]
0000792ccedd80b0  vmovaps xmm7, [rsp+0x60]
0000792ccedd80b6  vmovaps xmm8, [rsp+0x70]
0000792ccedd80bc  vmovaps xmm9, [rsp+0x80]
0000792ccedd80c5  vmovaps xmm10, [rsp+0x90]
0000792ccedd80ce  vmovaps xmm11, [rsp+0xA0]
0000792ccedd80d7  vmovaps xmm12, [rsp+0xB0]
0000792ccedd80e0  vmovaps xmm13, [rsp+0xC0]
0000792ccedd80e9  vmovaps xmm14, [rsp+0xD0]
0000792ccedd80f2  vmovaps xmm15, [rsp+0xE0]
0000792ccedd80fb  add rsp, 0xF0
0000792ccedd8102  pop r11
0000792ccedd8104  pop r10
0000792ccedd8106  pop r9
0000792ccedd8108  pop r8
0000792ccedd810a  pop rsi
0000792ccedd810b  pop rdi
0000792ccedd810c  pop rdx
0000792ccedd810d  pop rcx
0000792ccedd810e  pop rax
0000792ccedd810f  add rsp, 0x08
0000792ccedd8113  jmp 0x0000792CCEDD5F06
0000792ccedd8118  sub rsp, 0x08
0000792ccedd811c  push rax
0000792ccedd811d  push rcx
0000792ccedd811e  push rdx
0000792ccedd811f  push rdi
0000792ccedd8120  push rsi
0000792ccedd8121  push r8
0000792ccedd8123  push r9
0000792ccedd8125  push r10
0000792ccedd8127  push r11
0000792ccedd8129  sub rsp, 0xF0
0000792ccedd8130  vmovaps [rsp], xmm0
0000792ccedd8135  vmovaps [rsp+0x10], xmm1
0000792ccedd813b  vmovaps [rsp+0x20], xmm2
0000792ccedd8141  vmovaps [rsp+0x30], xmm3
0000792ccedd8147  vmovaps [rsp+0x40], xmm5
0000792ccedd814d  vmovaps [rsp+0x50], xmm6
0000792ccedd8153  vmovaps [rsp+0x60], xmm7
0000792ccedd8159  vmovaps [rsp+0x70], xmm8
0000792ccedd815f  vmovaps [rsp+0x80], xmm9
0000792ccedd8168  vmovaps [rsp+0x90], xmm10
0000792ccedd8171  vmovaps [rsp+0xA0], xmm11
0000792ccedd817a  vmovaps [rsp+0xB0], xmm12
0000792ccedd8183  vmovaps [rsp+0xC0], xmm13
0000792ccedd818c  vmovaps [rsp+0xD0], xmm14
0000792ccedd8195  vmovaps [rsp+0xE0], xmm15
0000792ccedd819e  sub rsp, 0x30
0000792ccedd81a2  movaps [rsp], xmm4
0000792ccedd81a6  movaps [rsp+0x10], xmm3
0000792ccedd81ab  movaps [rsp+0x20], xmm5
0000792ccedd81b0  lea rdi, [rsp]
0000792ccedd81b4  mov esi, 0x00
0000792ccedd81b9  mov rax, 0x5AEE2D541530
0000792ccedd81c3  call rax
0000792ccedd81c5  movaps xmm4, [rsp]
0000792ccedd81c9  add rsp, 0x30
0000792ccedd81cd  vmovaps xmm0, [rsp]
0000792ccedd81d2  vmovaps xmm1, [rsp+0x10]
0000792ccedd81d8  vmovaps xmm2, [rsp+0x20]
0000792ccedd81de  vmovaps xmm3, [rsp+0x30]
0000792ccedd81e4  vmovaps xmm5, [rsp+0x40]
0000792ccedd81ea  vmovaps xmm6, [rsp+0x50]
0000792ccedd81f0  vmovaps xmm7, [rsp+0x60]
0000792ccedd81f6  vmovaps xmm8, [rsp+0x70]
0000792ccedd81fc  vmovaps xmm9, [rsp+0x80]
0000792ccedd8205  vmovaps xmm10, [rsp+0x90]
0000792ccedd820e  vmovaps xmm11, [rsp+0xA0]
0000792ccedd8217  vmovaps xmm12, [rsp+0xB0]
0000792ccedd8220  vmovaps xmm13, [rsp+0xC0]
0000792ccedd8229  vmovaps xmm14, [rsp+0xD0]
0000792ccedd8232  vmovaps xmm15, [rsp+0xE0]
0000792ccedd823b  add rsp, 0xF0
0000792ccedd8242  pop r11
0000792ccedd8244  pop r10
0000792ccedd8246  pop r9
0000792ccedd8248  pop r8
0000792ccedd824a  pop rsi
0000792ccedd824b  pop rdi
0000792ccedd824c  pop rdx
0000792ccedd824d  pop rcx
0000792ccedd824e  pop rax
0000792ccedd824f  add rsp, 0x08
0000792ccedd8253  jmp 0x0000792CCEDD5F54
0000792ccedd8258  call 0x0000792CCECD64F0
0000792ccedd825d  jmp 0x0000792CCEDD5F61
0000792ccedd8262  sub rsp, 0x08
0000792ccedd8266  push rax
0000792ccedd8267  push rcx
0000792ccedd8268  push rdx
0000792ccedd8269  push rdi
0000792ccedd826a  push rsi
0000792ccedd826b  push r8
0000792ccedd826d  push r9
0000792ccedd826f  push r10
0000792ccedd8271  push r11
0000792ccedd8273  sub rsp, 0xF0
0000792ccedd827a  vmovaps [rsp], xmm0
0000792ccedd827f  vmovaps [rsp+0x10], xmm1
0000792ccedd8285  vmovaps [rsp+0x20], xmm2
0000792ccedd828b  vmovaps [rsp+0x30], xmm3
0000792ccedd8291  vmovaps [rsp+0x40], xmm4
0000792ccedd8297  vmovaps [rsp+0x50], xmm6
0000792ccedd829d  vmovaps [rsp+0x60], xmm7
0000792ccedd82a3  vmovaps [rsp+0x70], xmm8
0000792ccedd82a9  vmovaps [rsp+0x80], xmm9
0000792ccedd82b2  vmovaps [rsp+0x90], xmm10
0000792ccedd82bb  vmovaps [rsp+0xA0], xmm11
0000792ccedd82c4  vmovaps [rsp+0xB0], xmm12
0000792ccedd82cd  vmovaps [rsp+0xC0], xmm13
0000792ccedd82d6  vmovaps [rsp+0xD0], xmm14
0000792ccedd82df  vmovaps [rsp+0xE0], xmm15
0000792ccedd82e8  sub rsp, 0x30
0000792ccedd82ec  movaps [rsp], xmm5
0000792ccedd82f0  movaps [rsp+0x10], xmm6
0000792ccedd82f5  movaps [rsp+0x20], xmm3
0000792ccedd82fa  lea rdi, [rsp]
0000792ccedd82fe  mov esi, 0x00
0000792ccedd8303  mov rax, 0x5AEE2D541530
0000792ccedd830d  call rax
0000792ccedd830f  movaps xmm5, [rsp]
0000792ccedd8313  add rsp, 0x30
0000792ccedd8317  vmovaps xmm0, [rsp]
0000792ccedd831c  vmovaps xmm1, [rsp+0x10]
0000792ccedd8322  vmovaps xmm2, [rsp+0x20]
0000792ccedd8328  vmovaps xmm3, [rsp+0x30]
0000792ccedd832e  vmovaps xmm4, [rsp+0x40]
0000792ccedd8334  vmovaps xmm6, [rsp+0x50]
0000792ccedd833a  vmovaps xmm7, [rsp+0x60]
0000792ccedd8340  vmovaps xmm8, [rsp+0x70]
0000792ccedd8346  vmovaps xmm9, [rsp+0x80]
0000792ccedd834f  vmovaps xmm10, [rsp+0x90]
0000792ccedd8358  vmovaps xmm11, [rsp+0xA0]
0000792ccedd8361  vmovaps xmm12, [rsp+0xB0]
0000792ccedd836a  vmovaps xmm13, [rsp+0xC0]
0000792ccedd8373  vmovaps xmm14, [rsp+0xD0]
0000792ccedd837c  vmovaps xmm15, [rsp+0xE0]
0000792ccedd8385  add rsp, 0xF0
0000792ccedd838c  pop r11
0000792ccedd838e  pop r10
0000792ccedd8390  pop r9
0000792ccedd8392  pop r8
0000792ccedd8394  pop rsi
0000792ccedd8395  pop rdi
0000792ccedd8396  pop rdx
0000792ccedd8397  pop rcx
0000792ccedd8398  pop rax
0000792ccedd8399  add rsp, 0x08
0000792ccedd839d  jmp 0x0000792CCEDD5F87
0000792ccedd83a2  sub rsp, 0x08
0000792ccedd83a6  push rax
0000792ccedd83a7  push rcx
0000792ccedd83a8  push rdx
0000792ccedd83a9  push rdi
0000792ccedd83aa  push rsi
0000792ccedd83ab  push r8
0000792ccedd83ad  push r9
0000792ccedd83af  push r10
0000792ccedd83b1  push r11
0000792ccedd83b3  sub rsp, 0xF0
0000792ccedd83ba  vmovaps [rsp], xmm0
0000792ccedd83bf  vmovaps [rsp+0x10], xmm1
0000792ccedd83c5  vmovaps [rsp+0x20], xmm2
0000792ccedd83cb  vmovaps [rsp+0x30], xmm3
0000792ccedd83d1  vmovaps [rsp+0x40], xmm4
0000792ccedd83d7  vmovaps [rsp+0x50], xmm5
0000792ccedd83dd  vmovaps [rsp+0x60], xmm7
0000792ccedd83e3  vmovaps [rsp+0x70], xmm8
0000792ccedd83e9  vmovaps [rsp+0x80], xmm9
0000792ccedd83f2  vmovaps [rsp+0x90], xmm10
0000792ccedd83fb  vmovaps [rsp+0xA0], xmm11
0000792ccedd8404  vmovaps [rsp+0xB0], xmm12
0000792ccedd840d  vmovaps [rsp+0xC0], xmm13
0000792ccedd8416  vmovaps [rsp+0xD0], xmm14
0000792ccedd841f  vmovaps [rsp+0xE0], xmm15
0000792ccedd8428  sub rsp, 0x30
0000792ccedd842c  movaps [rsp], xmm6
0000792ccedd8430  movaps [rsp+0x10], xmm9
0000792ccedd8436  movaps [rsp+0x20], xmm1
0000792ccedd843b  lea rdi, [rsp]
0000792ccedd843f  mov esi, 0x00
0000792ccedd8444  mov rax, 0x5AEE2D541530
0000792ccedd844e  call rax
0000792ccedd8450  movaps xmm6, [rsp]
0000792ccedd8454  add rsp, 0x30
0000792ccedd8458  vmovaps xmm0, [rsp]
0000792ccedd845d  vmovaps xmm1, [rsp+0x10]
0000792ccedd8463  vmovaps xmm2, [rsp+0x20]
0000792ccedd8469  vmovaps xmm3, [rsp+0x30]
0000792ccedd846f  vmovaps xmm4, [rsp+0x40]
0000792ccedd8475  vmovaps xmm5, [rsp+0x50]
0000792ccedd847b  vmovaps xmm7, [rsp+0x60]
0000792ccedd8481  vmovaps xmm8, [rsp+0x70]
0000792ccedd8487  vmovaps xmm9, [rsp+0x80]
0000792ccedd8490  vmovaps xmm10, [rsp+0x90]
0000792ccedd8499  vmovaps xmm11, [rsp+0xA0]
0000792ccedd84a2  vmovaps xmm12, [rsp+0xB0]
0000792ccedd84ab  vmovaps xmm13, [rsp+0xC0]
0000792ccedd84b4  vmovaps xmm14, [rsp+0xD0]
0000792ccedd84bd  vmovaps xmm15, [rsp+0xE0]
0000792ccedd84c6  add rsp, 0xF0
0000792ccedd84cd  pop r11
0000792ccedd84cf  pop r10
0000792ccedd84d1  pop r9
0000792ccedd84d3  pop r8
0000792ccedd84d5  pop rsi
0000792ccedd84d6  pop rdi
0000792ccedd84d7  pop rdx
0000792ccedd84d8  pop rcx
0000792ccedd84d9  pop rax
0000792ccedd84da  add rsp, 0x08
0000792ccedd84de  jmp 0x0000792CCEDD5FAB
0000792ccedd84e3  sub rsp, 0x08
0000792ccedd84e7  push rax
0000792ccedd84e8  push rcx
0000792ccedd84e9  push rdx
0000792ccedd84ea  push rdi
0000792ccedd84eb  push rsi
0000792ccedd84ec  push r8
0000792ccedd84ee  push r9
0000792ccedd84f0  push r10
0000792ccedd84f2  push r11
0000792ccedd84f4  sub rsp, 0xF0
0000792ccedd84fb  vmovaps [rsp], xmm0
0000792ccedd8500  vmovaps [rsp+0x10], xmm1
0000792ccedd8506  vmovaps [rsp+0x20], xmm2
0000792ccedd850c  vmovaps [rsp+0x30], xmm3
0000792ccedd8512  vmovaps [rsp+0x40], xmm4
0000792ccedd8518  vmovaps [rsp+0x50], xmm5
0000792ccedd851e  vmovaps [rsp+0x60], xmm6
0000792ccedd8524  vmovaps [rsp+0x70], xmm7
0000792ccedd852a  vmovaps [rsp+0x80], xmm8
0000792ccedd8533  vmovaps [rsp+0x90], xmm10
0000792ccedd853c  vmovaps [rsp+0xA0], xmm11
0000792ccedd8545  vmovaps [rsp+0xB0], xmm12
0000792ccedd854e  vmovaps [rsp+0xC0], xmm13
0000792ccedd8557  vmovaps [rsp+0xD0], xmm14
0000792ccedd8560  vmovaps [rsp+0xE0], xmm15
0000792ccedd8569  sub rsp, 0x30
0000792ccedd856d  movaps [rsp], xmm9
0000792ccedd8572  movaps [rsp+0x10], xmm3
0000792ccedd8577  movaps [rsp+0x20], xmm1
0000792ccedd857c  lea rdi, [rsp]
0000792ccedd8580  mov esi, 0x00
0000792ccedd8585  mov rax, 0x5AEE2D541530
0000792ccedd858f  call rax
0000792ccedd8591  movaps xmm9, [rsp]
0000792ccedd8596  add rsp, 0x30
0000792ccedd859a  vmovaps xmm0, [rsp]
0000792ccedd859f  vmovaps xmm1, [rsp+0x10]
0000792ccedd85a5  vmovaps xmm2, [rsp+0x20]
0000792ccedd85ab  vmovaps xmm3, [rsp+0x30]
0000792ccedd85b1  vmovaps xmm4, [rsp+0x40]
0000792ccedd85b7  vmovaps xmm5, [rsp+0x50]
0000792ccedd85bd  vmovaps xmm6, [rsp+0x60]
0000792ccedd85c3  vmovaps xmm7, [rsp+0x70]
0000792ccedd85c9  vmovaps xmm8, [rsp+0x80]
0000792ccedd85d2  vmovaps xmm10, [rsp+0x90]
0000792ccedd85db  vmovaps xmm11, [rsp+0xA0]
0000792ccedd85e4  vmovaps xmm12, [rsp+0xB0]
0000792ccedd85ed  vmovaps xmm13, [rsp+0xC0]
0000792ccedd85f6  vmovaps xmm14, [rsp+0xD0]
0000792ccedd85ff  vmovaps xmm15, [rsp+0xE0]
0000792ccedd8608  add rsp, 0xF0
0000792ccedd860f  pop r11
0000792ccedd8611  pop r10
0000792ccedd8613  pop r9
0000792ccedd8615  pop r8
0000792ccedd8617  pop rsi
0000792ccedd8618  pop rdi
0000792ccedd8619  pop rdx
0000792ccedd861a  pop rcx
0000792ccedd861b  pop rax
0000792ccedd861c  add rsp, 0x08
0000792ccedd8620  jmp 0x0000792CCEDD5FF7
0000792ccedd8625  call 0x0000792CCECD64F0
0000792ccedd862a  jmp 0x0000792CCEDD6004
0000792ccedd862f  sub rsp, 0x08
0000792ccedd8633  push rax
0000792ccedd8634  push rcx
0000792ccedd8635  push rdx
0000792ccedd8636  push rdi
0000792ccedd8637  push rsi
0000792ccedd8638  push r8
0000792ccedd863a  push r9
0000792ccedd863c  push r10
0000792ccedd863e  push r11
0000792ccedd8640  sub rsp, 0xF0
0000792ccedd8647  vmovaps [rsp], xmm0
0000792ccedd864c  vmovaps [rsp+0x10], xmm1
0000792ccedd8652  vmovaps [rsp+0x20], xmm2
0000792ccedd8658  vmovaps [rsp+0x30], xmm3
0000792ccedd865e  vmovaps [rsp+0x40], xmm4
0000792ccedd8664  vmovaps [rsp+0x50], xmm5
0000792ccedd866a  vmovaps [rsp+0x60], xmm6
0000792ccedd8670  vmovaps [rsp+0x70], xmm7
0000792ccedd8676  vmovaps [rsp+0x80], xmm8
0000792ccedd867f  vmovaps [rsp+0x90], xmm9
0000792ccedd8688  vmovaps [rsp+0xA0], xmm10
0000792ccedd8691  vmovaps [rsp+0xB0], xmm11
0000792ccedd869a  vmovaps [rsp+0xC0], xmm12
0000792ccedd86a3  vmovaps [rsp+0xD0], xmm13
0000792ccedd86ac  vmovaps [rsp+0xE0], xmm14
0000792ccedd86b5  sub rsp, 0x30
0000792ccedd86b9  movaps [rsp], xmm15
0000792ccedd86be  movaps [rsp+0x10], xmm3
0000792ccedd86c3  movaps [rsp+0x20], xmm7
0000792ccedd86c8  lea rdi, [rsp]
0000792ccedd86cc  mov esi, 0x00
0000792ccedd86d1  mov rax, 0x5AEE2D541530
0000792ccedd86db  call rax
0000792ccedd86dd  movaps xmm15, [rsp]
0000792ccedd86e2  add rsp, 0x30
0000792ccedd86e6  vmovaps xmm0, [rsp]
0000792ccedd86eb  vmovaps xmm1, [rsp+0x10]
0000792ccedd86f1  vmovaps xmm2, [rsp+0x20]
0000792ccedd86f7  vmovaps xmm3, [rsp+0x30]
0000792ccedd86fd  vmovaps xmm4, [rsp+0x40]
0000792ccedd8703  vmovaps xmm5, [rsp+0x50]
0000792ccedd8709  vmovaps xmm6, [rsp+0x60]
0000792ccedd870f  vmovaps xmm7, [rsp+0x70]
0000792ccedd8715  vmovaps xmm8, [rsp+0x80]
0000792ccedd871e  vmovaps xmm9, [rsp+0x90]
0000792ccedd8727  vmovaps xmm10, [rsp+0xA0]
0000792ccedd8730  vmovaps xmm11, [rsp+0xB0]
0000792ccedd8739  vmovaps xmm12, [rsp+0xC0]
0000792ccedd8742  vmovaps xmm13, [rsp+0xD0]
0000792ccedd874b  vmovaps xmm14, [rsp+0xE0]
0000792ccedd8754  add rsp, 0xF0
0000792ccedd875b  pop r11
0000792ccedd875d  pop r10
0000792ccedd875f  pop r9
0000792ccedd8761  pop r8
0000792ccedd8763  pop rsi
0000792ccedd8764  pop rdi
0000792ccedd8765  pop rdx
0000792ccedd8766  pop rcx
0000792ccedd8767  pop rax
0000792ccedd8768  add rsp, 0x08
0000792ccedd876c  jmp 0x0000792CCEDD6030
0000792ccedd8771  sub rsp, 0x08
0000792ccedd8775  push rax
0000792ccedd8776  push rcx
0000792ccedd8777  push rdx
0000792ccedd8778  push rdi
0000792ccedd8779  push rsi
0000792ccedd877a  push r8
0000792ccedd877c  push r9
0000792ccedd877e  push r10
0000792ccedd8780  push r11
0000792ccedd8782  sub rsp, 0xF0
0000792ccedd8789  vmovaps [rsp], xmm0
0000792ccedd878e  vmovaps [rsp+0x10], xmm1
0000792ccedd8794  vmovaps [rsp+0x20], xmm2
0000792ccedd879a  vmovaps [rsp+0x30], xmm4
0000792ccedd87a0  vmovaps [rsp+0x40], xmm5
0000792ccedd87a6  vmovaps [rsp+0x50], xmm6
0000792ccedd87ac  vmovaps [rsp+0x60], xmm7
0000792ccedd87b2  vmovaps [rsp+0x70], xmm8
0000792ccedd87b8  vmovaps [rsp+0x80], xmm9
0000792ccedd87c1  vmovaps [rsp+0x90], xmm10
0000792ccedd87ca  vmovaps [rsp+0xA0], xmm11
0000792ccedd87d3  vmovaps [rsp+0xB0], xmm12
0000792ccedd87dc  vmovaps [rsp+0xC0], xmm13
0000792ccedd87e5  vmovaps [rsp+0xD0], xmm14
0000792ccedd87ee  vmovaps [rsp+0xE0], xmm15
0000792ccedd87f7  sub rsp, 0x30
0000792ccedd87fb  movaps [rsp], xmm3
0000792ccedd87ff  movaps [rsp+0x10], xmm1
0000792ccedd8804  movaps [rsp+0x20], xmm15
0000792ccedd880a  lea rdi, [rsp]
0000792ccedd880e  mov esi, 0x00
0000792ccedd8813  mov rax, 0x5AEE2D541530
0000792ccedd881d  call rax
0000792ccedd881f  movaps xmm3, [rsp]
0000792ccedd8823  add rsp, 0x30
0000792ccedd8827  vmovaps xmm0, [rsp]
0000792ccedd882c  vmovaps xmm1, [rsp+0x10]
0000792ccedd8832  vmovaps xmm2, [rsp+0x20]
0000792ccedd8838  vmovaps xmm4, [rsp+0x30]
0000792ccedd883e  vmovaps xmm5, [rsp+0x40]
0000792ccedd8844  vmovaps xmm6, [rsp+0x50]
0000792ccedd884a  vmovaps xmm7, [rsp+0x60]
0000792ccedd8850  vmovaps xmm8, [rsp+0x70]
0000792ccedd8856  vmovaps xmm9, [rsp+0x80]
0000792ccedd885f  vmovaps xmm10, [rsp+0x90]
0000792ccedd8868  vmovaps xmm11, [rsp+0xA0]
0000792ccedd8871  vmovaps xmm12, [rsp+0xB0]
0000792ccedd887a  vmovaps xmm13, [rsp+0xC0]
0000792ccedd8883  vmovaps xmm14, [rsp+0xD0]
0000792ccedd888c  vmovaps xmm15, [rsp+0xE0]
0000792ccedd8895  add rsp, 0xF0
0000792ccedd889c  pop r11
0000792ccedd889e  pop r10
0000792ccedd88a0  pop r9
0000792ccedd88a2  pop r8
0000792ccedd88a4  pop rsi
0000792ccedd88a5  pop rdi
0000792ccedd88a6  pop rdx
0000792ccedd88a7  pop rcx
0000792ccedd88a8  pop rax
0000792ccedd88a9  add rsp, 0x08
0000792ccedd88ad  jmp 0x0000792CCEDD60BF
0000792ccedd88b2  call 0x0000792CCECD64F0
0000792ccedd88b7  jmp 0x0000792CCEDD60C9
0000792ccedd88bc  sub rsp, 0x08
0000792ccedd88c0  push rax
0000792ccedd88c1  push rcx
0000792ccedd88c2  push rdx
0000792ccedd88c3  push rdi
0000792ccedd88c4  push rsi
0000792ccedd88c5  push r8
0000792ccedd88c7  push r9
0000792ccedd88c9  push r10
0000792ccedd88cb  push r11
0000792ccedd88cd  sub rsp, 0xF0
0000792ccedd88d4  vmovaps [rsp], xmm0
0000792ccedd88d9  vmovaps [rsp+0x10], xmm1
0000792ccedd88df  vmovaps [rsp+0x20], xmm2
0000792ccedd88e5  vmovaps [rsp+0x30], xmm3
0000792ccedd88eb  vmovaps [rsp+0x40], xmm4
0000792ccedd88f1  vmovaps [rsp+0x50], xmm5
0000792ccedd88f7  vmovaps [rsp+0x60], xmm6
0000792ccedd88fd  vmovaps [rsp+0x70], xmm7
0000792ccedd8903  vmovaps [rsp+0x80], xmm8
0000792ccedd890c  vmovaps [rsp+0x90], xmm9
0000792ccedd8915  vmovaps [rsp+0xA0], xmm10
0000792ccedd891e  vmovaps [rsp+0xB0], xmm11
0000792ccedd8927  vmovaps [rsp+0xC0], xmm12
0000792ccedd8930  vmovaps [rsp+0xD0], xmm13
0000792ccedd8939  vmovaps [rsp+0xE0], xmm14
0000792ccedd8942  sub rsp, 0x30
0000792ccedd8946  movaps [rsp], xmm15
0000792ccedd894b  movaps [rsp+0x10], xmm14
0000792ccedd8951  movaps [rsp+0x20], xmm4
0000792ccedd8956  lea rdi, [rsp]
0000792ccedd895a  mov esi, 0x00
0000792ccedd895f  mov rax, 0x5AEE2D541530
0000792ccedd8969  call rax
0000792ccedd896b  movaps xmm15, [rsp]
0000792ccedd8970  add rsp, 0x30
0000792ccedd8974  vmovaps xmm0, [rsp]
0000792ccedd8979  vmovaps xmm1, [rsp+0x10]
0000792ccedd897f  vmovaps xmm2, [rsp+0x20]
0000792ccedd8985  vmovaps xmm3, [rsp+0x30]
0000792ccedd898b  vmovaps xmm4, [rsp+0x40]
0000792ccedd8991  vmovaps xmm5, [rsp+0x50]
0000792ccedd8997  vmovaps xmm6, [rsp+0x60]
0000792ccedd899d  vmovaps xmm7, [rsp+0x70]
0000792ccedd89a3  vmovaps xmm8, [rsp+0x80]
0000792ccedd89ac  vmovaps xmm9, [rsp+0x90]
0000792ccedd89b5  vmovaps xmm10, [rsp+0xA0]
0000792ccedd89be  vmovaps xmm11, [rsp+0xB0]
0000792ccedd89c7  vmovaps xmm12, [rsp+0xC0]
0000792ccedd89d0  vmovaps xmm13, [rsp+0xD0]
0000792ccedd89d9  vmovaps xmm14, [rsp+0xE0]
0000792ccedd89e2  add rsp, 0xF0
0000792ccedd89e9  pop r11
0000792ccedd89eb  pop r10
0000792ccedd89ed  pop r9
0000792ccedd89ef  pop r8
0000792ccedd89f1  pop rsi
0000792ccedd89f2  pop rdi
0000792ccedd89f3  pop rdx
0000792ccedd89f4  pop rcx
0000792ccedd89f5  pop rax
0000792ccedd89f6  add rsp, 0x08
0000792ccedd89fa  jmp 0x0000792CCEDD60F7
0000792ccedd89ff  sub rsp, 0x08
0000792ccedd8a03  push rax
0000792ccedd8a04  push rcx
0000792ccedd8a05  push rdx
0000792ccedd8a06  push rdi
0000792ccedd8a07  push rsi
0000792ccedd8a08  push r8
0000792ccedd8a0a  push r9
0000792ccedd8a0c  push r10
0000792ccedd8a0e  push r11
0000792ccedd8a10  sub rsp, 0xF0
0000792ccedd8a17  vmovaps [rsp], xmm0
0000792ccedd8a1c  vmovaps [rsp+0x10], xmm1
0000792ccedd8a22  vmovaps [rsp+0x20], xmm2
0000792ccedd8a28  vmovaps [rsp+0x30], xmm3
0000792ccedd8a2e  vmovaps [rsp+0x40], xmm4
0000792ccedd8a34  vmovaps [rsp+0x50], xmm5
0000792ccedd8a3a  vmovaps [rsp+0x60], xmm6
0000792ccedd8a40  vmovaps [rsp+0x70], xmm7
0000792ccedd8a46  vmovaps [rsp+0x80], xmm8
0000792ccedd8a4f  vmovaps [rsp+0x90], xmm9
0000792ccedd8a58  vmovaps [rsp+0xA0], xmm10
0000792ccedd8a61  vmovaps [rsp+0xB0], xmm11
0000792ccedd8a6a  vmovaps [rsp+0xC0], xmm12
0000792ccedd8a73  vmovaps [rsp+0xD0], xmm13
0000792ccedd8a7c  vmovaps [rsp+0xE0], xmm15
0000792ccedd8a85  sub rsp, 0x30
0000792ccedd8a89  movaps [rsp], xmm14
0000792ccedd8a8e  movaps [rsp+0x10], xmm2
0000792ccedd8a93  movaps [rsp+0x20], xmm1
0000792ccedd8a98  lea rdi, [rsp]
0000792ccedd8a9c  mov esi, 0x00
0000792ccedd8aa1  mov rax, 0x5AEE2D541530
0000792ccedd8aab  call rax
0000792ccedd8aad  movaps xmm14, [rsp]
0000792ccedd8ab2  add rsp, 0x30
0000792ccedd8ab6  vmovaps xmm0, [rsp]
0000792ccedd8abb  vmovaps xmm1, [rsp+0x10]
0000792ccedd8ac1  vmovaps xmm2, [rsp+0x20]
0000792ccedd8ac7  vmovaps xmm3, [rsp+0x30]
0000792ccedd8acd  vmovaps xmm4, [rsp+0x40]
0000792ccedd8ad3  vmovaps xmm5, [rsp+0x50]
0000792ccedd8ad9  vmovaps xmm6, [rsp+0x60]
0000792ccedd8adf  vmovaps xmm7, [rsp+0x70]
0000792ccedd8ae5  vmovaps xmm8, [rsp+0x80]
0000792ccedd8aee  vmovaps xmm9, [rsp+0x90]
0000792ccedd8af7  vmovaps xmm10, [rsp+0xA0]
0000792ccedd8b00  vmovaps xmm11, [rsp+0xB0]
0000792ccedd8b09  vmovaps xmm12, [rsp+0xC0]
0000792ccedd8b12  vmovaps xmm13, [rsp+0xD0]
0000792ccedd8b1b  vmovaps xmm15, [rsp+0xE0]
0000792ccedd8b24  add rsp, 0xF0
0000792ccedd8b2b  pop r11
0000792ccedd8b2d  pop r10
0000792ccedd8b2f  pop r9
0000792ccedd8b31  pop r8
0000792ccedd8b33  pop rsi
0000792ccedd8b34  pop rdi
0000792ccedd8b35  pop rdx
0000792ccedd8b36  pop rcx
0000792ccedd8b37  pop rax
0000792ccedd8b38  add rsp, 0x08
0000792ccedd8b3c  jmp 0x0000792CCEDD611D
0000792ccedd8b41  sub rsp, 0x08
0000792ccedd8b45  push rax
0000792ccedd8b46  push rcx
0000792ccedd8b47  push rdx
0000792ccedd8b48  push rdi
0000792ccedd8b49  push rsi
0000792ccedd8b4a  push r8
0000792ccedd8b4c  push r9
0000792ccedd8b4e  push r10
0000792ccedd8b50  push r11
0000792ccedd8b52  sub rsp, 0xF0
0000792ccedd8b59  vmovaps [rsp], xmm0
0000792ccedd8b5e  vmovaps [rsp+0x10], xmm2
0000792ccedd8b64  vmovaps [rsp+0x20], xmm3
0000792ccedd8b6a  vmovaps [rsp+0x30], xmm4
0000792ccedd8b70  vmovaps [rsp+0x40], xmm5
0000792ccedd8b76  vmovaps [rsp+0x50], xmm6
0000792ccedd8b7c  vmovaps [rsp+0x60], xmm7
0000792ccedd8b82  vmovaps [rsp+0x70], xmm8
0000792ccedd8b88  vmovaps [rsp+0x80], xmm9
0000792ccedd8b91  vmovaps [rsp+0x90], xmm10
0000792ccedd8b9a  vmovaps [rsp+0xA0], xmm11
0000792ccedd8ba3  vmovaps [rsp+0xB0], xmm12
0000792ccedd8bac  vmovaps [rsp+0xC0], xmm13
0000792ccedd8bb5  vmovaps [rsp+0xD0], xmm14
0000792ccedd8bbe  vmovaps [rsp+0xE0], xmm15
0000792ccedd8bc7  sub rsp, 0x30
0000792ccedd8bcb  movaps [rsp], xmm1
0000792ccedd8bcf  movaps [rsp+0x10], xmm4
0000792ccedd8bd4  movaps [rsp+0x20], xmm9
0000792ccedd8bda  lea rdi, [rsp]
0000792ccedd8bde  mov esi, 0x00
0000792ccedd8be3  mov rax, 0x5AEE2D541530
0000792ccedd8bed  call rax
0000792ccedd8bef  movaps xmm1, [rsp]
0000792ccedd8bf3  add rsp, 0x30
0000792ccedd8bf7  vmovaps xmm0, [rsp]
0000792ccedd8bfc  vmovaps xmm2, [rsp+0x10]
0000792ccedd8c02  vmovaps xmm3, [rsp+0x20]
0000792ccedd8c08  vmovaps xmm4, [rsp+0x30]
0000792ccedd8c0e  vmovaps xmm5, [rsp+0x40]
0000792ccedd8c14  vmovaps xmm6, [rsp+0x50]
0000792ccedd8c1a  vmovaps xmm7, [rsp+0x60]
0000792ccedd8c20  vmovaps xmm8, [rsp+0x70]
0000792ccedd8c26  vmovaps xmm9, [rsp+0x80]
0000792ccedd8c2f  vmovaps xmm10, [rsp+0x90]
0000792ccedd8c38  vmovaps xmm11, [rsp+0xA0]
0000792ccedd8c41  vmovaps xmm12, [rsp+0xB0]
0000792ccedd8c4a  vmovaps xmm13, [rsp+0xC0]
0000792ccedd8c53  vmovaps xmm14, [rsp+0xD0]
0000792ccedd8c5c  vmovaps xmm15, [rsp+0xE0]
0000792ccedd8c65  add rsp, 0xF0
0000792ccedd8c6c  pop r11
0000792ccedd8c6e  pop r10
0000792ccedd8c70  pop r9
0000792ccedd8c72  pop r8
0000792ccedd8c74  pop rsi
0000792ccedd8c75  pop rdi
0000792ccedd8c76  pop rdx
0000792ccedd8c77  pop rcx
0000792ccedd8c78  pop rax
0000792ccedd8c79  add rsp, 0x08
0000792ccedd8c7d  jmp 0x0000792CCEDD613B
0000792ccedd8c82  sub rsp, 0x08
0000792ccedd8c86  push rax
0000792ccedd8c87  push rcx
0000792ccedd8c88  push rdx
0000792ccedd8c89  push rdi
0000792ccedd8c8a  push rsi
0000792ccedd8c8b  push r8
0000792ccedd8c8d  push r9
0000792ccedd8c8f  push r10
0000792ccedd8c91  push r11
0000792ccedd8c93  sub rsp, 0xF0
0000792ccedd8c9a  vmovaps [rsp], xmm0
0000792ccedd8c9f  vmovaps [rsp+0x10], xmm1
0000792ccedd8ca5  vmovaps [rsp+0x20], xmm2
0000792ccedd8cab  vmovaps [rsp+0x30], xmm3
0000792ccedd8cb1  vmovaps [rsp+0x40], xmm5
0000792ccedd8cb7  vmovaps [rsp+0x50], xmm6
0000792ccedd8cbd  vmovaps [rsp+0x60], xmm7
0000792ccedd8cc3  vmovaps [rsp+0x70], xmm8
0000792ccedd8cc9  vmovaps [rsp+0x80], xmm9
0000792ccedd8cd2  vmovaps [rsp+0x90], xmm10
0000792ccedd8cdb  vmovaps [rsp+0xA0], xmm11
0000792ccedd8ce4  vmovaps [rsp+0xB0], xmm12
0000792ccedd8ced  vmovaps [rsp+0xC0], xmm13
0000792ccedd8cf6  vmovaps [rsp+0xD0], xmm14
0000792ccedd8cff  vmovaps [rsp+0xE0], xmm15
0000792ccedd8d08  sub rsp, 0x30
0000792ccedd8d0c  movaps [rsp], xmm4
0000792ccedd8d10  movaps [rsp+0x10], xmm2
0000792ccedd8d15  movaps [rsp+0x20], xmm9
0000792ccedd8d1b  lea rdi, [rsp]
0000792ccedd8d1f  mov esi, 0x00
0000792ccedd8d24  mov rax, 0x5AEE2D541530
0000792ccedd8d2e  call rax
0000792ccedd8d30  movaps xmm4, [rsp]
0000792ccedd8d34  add rsp, 0x30
0000792ccedd8d38  vmovaps xmm0, [rsp]
0000792ccedd8d3d  vmovaps xmm1, [rsp+0x10]
0000792ccedd8d43  vmovaps xmm2, [rsp+0x20]
0000792ccedd8d49  vmovaps xmm3, [rsp+0x30]
0000792ccedd8d4f  vmovaps xmm5, [rsp+0x40]
0000792ccedd8d55  vmovaps xmm6, [rsp+0x50]
0000792ccedd8d5b  vmovaps xmm7, [rsp+0x60]
0000792ccedd8d61  vmovaps xmm8, [rsp+0x70]
0000792ccedd8d67  vmovaps xmm9, [rsp+0x80]
0000792ccedd8d70  vmovaps xmm10, [rsp+0x90]
0000792ccedd8d79  vmovaps xmm11, [rsp+0xA0]
0000792ccedd8d82  vmovaps xmm12, [rsp+0xB0]
0000792ccedd8d8b  vmovaps xmm13, [rsp+0xC0]
0000792ccedd8d94  vmovaps xmm14, [rsp+0xD0]
0000792ccedd8d9d  vmovaps xmm15, [rsp+0xE0]
0000792ccedd8da6  add rsp, 0xF0
0000792ccedd8dad  pop r11
0000792ccedd8daf  pop r10
0000792ccedd8db1  pop r9
0000792ccedd8db3  pop r8
0000792ccedd8db5  pop rsi
0000792ccedd8db6  pop rdi
0000792ccedd8db7  pop rdx
0000792ccedd8db8  pop rcx
0000792ccedd8db9  pop rax
0000792ccedd8dba  add rsp, 0x08
0000792ccedd8dbe  jmp 0x0000792CCEDD616B
0000792ccedd8dc3  sub rsp, 0x08
0000792ccedd8dc7  push rax
0000792ccedd8dc8  push rcx
0000792ccedd8dc9  push rdx
0000792ccedd8dca  push rdi
0000792ccedd8dcb  push rsi
0000792ccedd8dcc  push r8
0000792ccedd8dce  push r9
0000792ccedd8dd0  push r10
0000792ccedd8dd2  push r11
0000792ccedd8dd4  sub rsp, 0xF0
0000792ccedd8ddb  vmovaps [rsp], xmm0
0000792ccedd8de0  vmovaps [rsp+0x10], xmm1
0000792ccedd8de6  vmovaps [rsp+0x20], xmm2
0000792ccedd8dec  vmovaps [rsp+0x30], xmm3
0000792ccedd8df2  vmovaps [rsp+0x40], xmm4
0000792ccedd8df8  vmovaps [rsp+0x50], xmm5
0000792ccedd8dfe  vmovaps [rsp+0x60], xmm6
0000792ccedd8e04  vmovaps [rsp+0x70], xmm7
0000792ccedd8e0a  vmovaps [rsp+0x80], xmm8
0000792ccedd8e13  vmovaps [rsp+0x90], xmm10
0000792ccedd8e1c  vmovaps [rsp+0xA0], xmm11
0000792ccedd8e25  vmovaps [rsp+0xB0], xmm12
0000792ccedd8e2e  vmovaps [rsp+0xC0], xmm13
0000792ccedd8e37  vmovaps [rsp+0xD0], xmm14
0000792ccedd8e40  vmovaps [rsp+0xE0], xmm15
0000792ccedd8e49  sub rsp, 0x30
0000792ccedd8e4d  movaps [rsp], xmm9
0000792ccedd8e52  movaps [rsp+0x10], xmm2
0000792ccedd8e57  movaps [rsp+0x20], xmm1
0000792ccedd8e5c  lea rdi, [rsp]
0000792ccedd8e60  mov esi, 0x00
0000792ccedd8e65  mov rax, 0x5AEE2D541530
0000792ccedd8e6f  call rax
0000792ccedd8e71  movaps xmm9, [rsp]
0000792ccedd8e76  add rsp, 0x30
0000792ccedd8e7a  vmovaps xmm0, [rsp]
0000792ccedd8e7f  vmovaps xmm1, [rsp+0x10]
0000792ccedd8e85  vmovaps xmm2, [rsp+0x20]
0000792ccedd8e8b  vmovaps xmm3, [rsp+0x30]
0000792ccedd8e91  vmovaps xmm4, [rsp+0x40]
0000792ccedd8e97  vmovaps xmm5, [rsp+0x50]
0000792ccedd8e9d  vmovaps xmm6, [rsp+0x60]
0000792ccedd8ea3  vmovaps xmm7, [rsp+0x70]
0000792ccedd8ea9  vmovaps xmm8, [rsp+0x80]
0000792ccedd8eb2  vmovaps xmm10, [rsp+0x90]
0000792ccedd8ebb  vmovaps xmm11, [rsp+0xA0]
0000792ccedd8ec4  vmovaps xmm12, [rsp+0xB0]
0000792ccedd8ecd  vmovaps xmm13, [rsp+0xC0]
0000792ccedd8ed6  vmovaps xmm14, [rsp+0xD0]
0000792ccedd8edf  vmovaps xmm15, [rsp+0xE0]
0000792ccedd8ee8  add rsp, 0xF0
0000792ccedd8eef  pop r11
0000792ccedd8ef1  pop r10
0000792ccedd8ef3  pop r9
0000792ccedd8ef5  pop r8
0000792ccedd8ef7  pop rsi
0000792ccedd8ef8  pop rdi
0000792ccedd8ef9  pop rdx
0000792ccedd8efa  pop rcx
0000792ccedd8efb  pop rax
0000792ccedd8efc  add rsp, 0x08
0000792ccedd8f00  jmp 0x0000792CCEDD61A1
0000792ccedd8f05  sub rsp, 0x08
0000792ccedd8f09  push rax
0000792ccedd8f0a  push rcx
0000792ccedd8f0b  push rdx
0000792ccedd8f0c  push rdi
0000792ccedd8f0d  push rsi
0000792ccedd8f0e  push r8
0000792ccedd8f10  push r9
0000792ccedd8f12  push r10
0000792ccedd8f14  push r11
0000792ccedd8f16  sub rsp, 0xF0
0000792ccedd8f1d  vmovaps [rsp], xmm0
0000792ccedd8f22  vmovaps [rsp+0x10], xmm2
0000792ccedd8f28  vmovaps [rsp+0x20], xmm3
0000792ccedd8f2e  vmovaps [rsp+0x30], xmm4
0000792ccedd8f34  vmovaps [rsp+0x40], xmm5
0000792ccedd8f3a  vmovaps [rsp+0x50], xmm6
0000792ccedd8f40  vmovaps [rsp+0x60], xmm7
0000792ccedd8f46  vmovaps [rsp+0x70], xmm8
0000792ccedd8f4c  vmovaps [rsp+0x80], xmm9
0000792ccedd8f55  vmovaps [rsp+0x90], xmm10
0000792ccedd8f5e  vmovaps [rsp+0xA0], xmm11
0000792ccedd8f67  vmovaps [rsp+0xB0], xmm12
0000792ccedd8f70  vmovaps [rsp+0xC0], xmm13
0000792ccedd8f79  vmovaps [rsp+0xD0], xmm14
0000792ccedd8f82  vmovaps [rsp+0xE0], xmm15
0000792ccedd8f8b  sub rsp, 0x30
0000792ccedd8f8f  movaps [rsp], xmm1
0000792ccedd8f93  movaps [rsp+0x10], xmm15
0000792ccedd8f99  movaps [rsp+0x20], xmm6
0000792ccedd8f9e  lea rdi, [rsp]
0000792ccedd8fa2  mov esi, 0x00
0000792ccedd8fa7  mov rax, 0x5AEE2D541530
0000792ccedd8fb1  call rax
0000792ccedd8fb3  movaps xmm1, [rsp]
0000792ccedd8fb7  add rsp, 0x30
0000792ccedd8fbb  vmovaps xmm0, [rsp]
0000792ccedd8fc0  vmovaps xmm2, [rsp+0x10]
0000792ccedd8fc6  vmovaps xmm3, [rsp+0x20]
0000792ccedd8fcc  vmovaps xmm4, [rsp+0x30]
0000792ccedd8fd2  vmovaps xmm5, [rsp+0x40]
0000792ccedd8fd8  vmovaps xmm6, [rsp+0x50]
0000792ccedd8fde  vmovaps xmm7, [rsp+0x60]
0000792ccedd8fe4  vmovaps xmm8, [rsp+0x70]
0000792ccedd8fea  vmovaps xmm9, [rsp+0x80]
0000792ccedd8ff3  vmovaps xmm10, [rsp+0x90]
0000792ccedd8ffc  vmovaps xmm11, [rsp+0xA0]
0000792ccedd9005  vmovaps xmm12, [rsp+0xB0]
0000792ccedd900e  vmovaps xmm13, [rsp+0xC0]
0000792ccedd9017  vmovaps xmm14, [rsp+0xD0]
0000792ccedd9020  vmovaps xmm15, [rsp+0xE0]
0000792ccedd9029  add rsp, 0xF0
0000792ccedd9030  pop r11
0000792ccedd9032  pop r10
0000792ccedd9034  pop r9
0000792ccedd9036  pop r8
0000792ccedd9038  pop rsi
0000792ccedd9039  pop rdi
0000792ccedd903a  pop rdx
0000792ccedd903b  pop rcx
0000792ccedd903c  pop rax
0000792ccedd903d  add rsp, 0x08
0000792ccedd9041  jmp 0x0000792CCEDD61C2
0000792ccedd9046  sub rsp, 0x08
0000792ccedd904a  push rax
0000792ccedd904b  push rcx
0000792ccedd904c  push rdx
0000792ccedd904d  push rdi
0000792ccedd904e  push rsi
0000792ccedd904f  push r8
0000792ccedd9051  push r9
0000792ccedd9053  push r10
0000792ccedd9055  push r11
0000792ccedd9057  sub rsp, 0xF0
0000792ccedd905e  vmovaps [rsp], xmm0
0000792ccedd9063  vmovaps [rsp+0x10], xmm1
0000792ccedd9069  vmovaps [rsp+0x20], xmm2
0000792ccedd906f  vmovaps [rsp+0x30], xmm3
0000792ccedd9075  vmovaps [rsp+0x40], xmm4
0000792ccedd907b  vmovaps [rsp+0x50], xmm5
0000792ccedd9081  vmovaps [rsp+0x60], xmm6
0000792ccedd9087  vmovaps [rsp+0x70], xmm7
0000792ccedd908d  vmovaps [rsp+0x80], xmm8
0000792ccedd9096  vmovaps [rsp+0x90], xmm9
0000792ccedd909f  vmovaps [rsp+0xA0], xmm10
0000792ccedd90a8  vmovaps [rsp+0xB0], xmm11
0000792ccedd90b1  vmovaps [rsp+0xC0], xmm12
0000792ccedd90ba  vmovaps [rsp+0xD0], xmm13
0000792ccedd90c3  vmovaps [rsp+0xE0], xmm14
0000792ccedd90cc  sub rsp, 0x30
0000792ccedd90d0  movaps [rsp], xmm15
0000792ccedd90d5  movaps [rsp+0x10], xmm5
0000792ccedd90da  movaps [rsp+0x20], xmm3
0000792ccedd90df  lea rdi, [rsp]
0000792ccedd90e3  mov esi, 0x00
0000792ccedd90e8  mov rax, 0x5AEE2D541530
0000792ccedd90f2  call rax
0000792ccedd90f4  movaps xmm15, [rsp]
0000792ccedd90f9  add rsp, 0x30
0000792ccedd90fd  vmovaps xmm0, [rsp]
0000792ccedd9102  vmovaps xmm1, [rsp+0x10]
0000792ccedd9108  vmovaps xmm2, [rsp+0x20]
0000792ccedd910e  vmovaps xmm3, [rsp+0x30]
0000792ccedd9114  vmovaps xmm4, [rsp+0x40]
0000792ccedd911a  vmovaps xmm5, [rsp+0x50]
0000792ccedd9120  vmovaps xmm6, [rsp+0x60]
0000792ccedd9126  vmovaps xmm7, [rsp+0x70]
0000792ccedd912c  vmovaps xmm8, [rsp+0x80]
0000792ccedd9135  vmovaps xmm9, [rsp+0x90]
0000792ccedd913e  vmovaps xmm10, [rsp+0xA0]
0000792ccedd9147  vmovaps xmm11, [rsp+0xB0]
0000792ccedd9150  vmovaps xmm12, [rsp+0xC0]
0000792ccedd9159  vmovaps xmm13, [rsp+0xD0]
0000792ccedd9162  vmovaps xmm14, [rsp+0xE0]
0000792ccedd916b  add rsp, 0xF0
0000792ccedd9172  pop r11
0000792ccedd9174  pop r10
0000792ccedd9176  pop r9
0000792ccedd9178  pop r8
0000792ccedd917a  pop rsi
0000792ccedd917b  pop rdi
0000792ccedd917c  pop rdx
0000792ccedd917d  pop rcx
0000792ccedd917e  pop rax
0000792ccedd917f  add rsp, 0x08
0000792ccedd9183  jmp 0x0000792CCEDD61DC
0000792ccedd9188  sub rsp, 0x08
0000792ccedd918c  push rax
0000792ccedd918d  push rcx
0000792ccedd918e  push rdx
0000792ccedd918f  push rdi
0000792ccedd9190  push rsi
0000792ccedd9191  push r8
0000792ccedd9193  push r9
0000792ccedd9195  push r10
0000792ccedd9197  push r11
0000792ccedd9199  sub rsp, 0xF0
0000792ccedd91a0  vmovaps [rsp], xmm0
0000792ccedd91a5  vmovaps [rsp+0x10], xmm1
0000792ccedd91ab  vmovaps [rsp+0x20], xmm2
0000792ccedd91b1  vmovaps [rsp+0x30], xmm3
0000792ccedd91b7  vmovaps [rsp+0x40], xmm4
0000792ccedd91bd  vmovaps [rsp+0x50], xmm6
0000792ccedd91c3  vmovaps [rsp+0x60], xmm7
0000792ccedd91c9  vmovaps [rsp+0x70], xmm8
0000792ccedd91cf  vmovaps [rsp+0x80], xmm9
0000792ccedd91d8  vmovaps [rsp+0x90], xmm10
0000792ccedd91e1  vmovaps [rsp+0xA0], xmm11
0000792ccedd91ea  vmovaps [rsp+0xB0], xmm12
0000792ccedd91f3  vmovaps [rsp+0xC0], xmm13
0000792ccedd91fc  vmovaps [rsp+0xD0], xmm14
0000792ccedd9205  vmovaps [rsp+0xE0], xmm15
0000792ccedd920e  sub rsp, 0x30
0000792ccedd9212  movaps [rsp], xmm5
0000792ccedd9216  movaps [rsp+0x10], xmm8
0000792ccedd921c  movaps [rsp+0x20], xmm6
0000792ccedd9221  lea rdi, [rsp]
0000792ccedd9225  mov esi, 0x00
0000792ccedd922a  mov rax, 0x5AEE2D541530
0000792ccedd9234  call rax
0000792ccedd9236  movaps xmm5, [rsp]
0000792ccedd923a  add rsp, 0x30
0000792ccedd923e  vmovaps xmm0, [rsp]
0000792ccedd9243  vmovaps xmm1, [rsp+0x10]
0000792ccedd9249  vmovaps xmm2, [rsp+0x20]
0000792ccedd924f  vmovaps xmm3, [rsp+0x30]
0000792ccedd9255  vmovaps xmm4, [rsp+0x40]
0000792ccedd925b  vmovaps xmm6, [rsp+0x50]
0000792ccedd9261  vmovaps xmm7, [rsp+0x60]
0000792ccedd9267  vmovaps xmm8, [rsp+0x70]
0000792ccedd926d  vmovaps xmm9, [rsp+0x80]
0000792ccedd9276  vmovaps xmm10, [rsp+0x90]
0000792ccedd927f  vmovaps xmm11, [rsp+0xA0]
0000792ccedd9288  vmovaps xmm12, [rsp+0xB0]
0000792ccedd9291  vmovaps xmm13, [rsp+0xC0]
0000792ccedd929a  vmovaps xmm14, [rsp+0xD0]
0000792ccedd92a3  vmovaps xmm15, [rsp+0xE0]
0000792ccedd92ac  add rsp, 0xF0
0000792ccedd92b3  pop r11
0000792ccedd92b5  pop r10
0000792ccedd92b7  pop r9
0000792ccedd92b9  pop r8
0000792ccedd92bb  pop rsi
0000792ccedd92bc  pop rdi
0000792ccedd92bd  pop rdx
0000792ccedd92be  pop rcx
0000792ccedd92bf  pop rax
0000792ccedd92c0  add rsp, 0x08
0000792ccedd92c4  jmp 0x0000792CCEDD6200
0000792ccedd92c9  sub rsp, 0x08
0000792ccedd92cd  push rax
0000792ccedd92ce  push rcx
0000792ccedd92cf  push rdx
0000792ccedd92d0  push rdi
0000792ccedd92d1  push rsi
0000792ccedd92d2  push r8
0000792ccedd92d4  push r9
0000792ccedd92d6  push r10
0000792ccedd92d8  push r11
0000792ccedd92da  sub rsp, 0xF0
0000792ccedd92e1  vmovaps [rsp], xmm0
0000792ccedd92e6  vmovaps [rsp+0x10], xmm1
0000792ccedd92ec  vmovaps [rsp+0x20], xmm2
0000792ccedd92f2  vmovaps [rsp+0x30], xmm3
0000792ccedd92f8  vmovaps [rsp+0x40], xmm4
0000792ccedd92fe  vmovaps [rsp+0x50], xmm5
0000792ccedd9304  vmovaps [rsp+0x60], xmm7
0000792ccedd930a  vmovaps [rsp+0x70], xmm8
0000792ccedd9310  vmovaps [rsp+0x80], xmm9
0000792ccedd9319  vmovaps [rsp+0x90], xmm10
0000792ccedd9322  vmovaps [rsp+0xA0], xmm11
0000792ccedd932b  vmovaps [rsp+0xB0], xmm12
0000792ccedd9334  vmovaps [rsp+0xC0], xmm13
0000792ccedd933d  vmovaps [rsp+0xD0], xmm14
0000792ccedd9346  vmovaps [rsp+0xE0], xmm15
0000792ccedd934f  sub rsp, 0x30
0000792ccedd9353  movaps [rsp], xmm6
0000792ccedd9357  movaps [rsp+0x10], xmm10
0000792ccedd935d  movaps [rsp+0x20], xmm8
0000792ccedd9363  lea rdi, [rsp]
0000792ccedd9367  mov esi, 0x00
0000792ccedd936c  mov rax, 0x5AEE2D541530
0000792ccedd9376  call rax
0000792ccedd9378  movaps xmm6, [rsp]
0000792ccedd937c  add rsp, 0x30
0000792ccedd9380  vmovaps xmm0, [rsp]
0000792ccedd9385  vmovaps xmm1, [rsp+0x10]
0000792ccedd938b  vmovaps xmm2, [rsp+0x20]
0000792ccedd9391  vmovaps xmm3, [rsp+0x30]
0000792ccedd9397  vmovaps xmm4, [rsp+0x40]
0000792ccedd939d  vmovaps xmm5, [rsp+0x50]
0000792ccedd93a3  vmovaps xmm7, [rsp+0x60]
0000792ccedd93a9  vmovaps xmm8, [rsp+0x70]
0000792ccedd93af  vmovaps xmm9, [rsp+0x80]
0000792ccedd93b8  vmovaps xmm10, [rsp+0x90]
0000792ccedd93c1  vmovaps xmm11, [rsp+0xA0]
0000792ccedd93ca  vmovaps xmm12, [rsp+0xB0]
0000792ccedd93d3  vmovaps xmm13, [rsp+0xC0]
0000792ccedd93dc  vmovaps xmm14, [rsp+0xD0]
0000792ccedd93e5  vmovaps xmm15, [rsp+0xE0]
0000792ccedd93ee  add rsp, 0xF0
0000792ccedd93f5  pop r11
0000792ccedd93f7  pop r10
0000792ccedd93f9  pop r9
0000792ccedd93fb  pop r8
0000792ccedd93fd  pop rsi
0000792ccedd93fe  pop rdi
0000792ccedd93ff  pop rdx
0000792ccedd9400  pop rcx
0000792ccedd9401  pop rax
0000792ccedd9402  add rsp, 0x08
0000792ccedd9406  jmp 0x0000792CCEDD6225
0000792ccedd940b  sub rsp, 0x08
0000792ccedd940f  push rax
0000792ccedd9410  push rcx
0000792ccedd9411  push rdx
0000792ccedd9412  push rdi
0000792ccedd9413  push rsi
0000792ccedd9414  push r8
0000792ccedd9416  push r9
0000792ccedd9418  push r10
0000792ccedd941a  push r11
0000792ccedd941c  sub rsp, 0xF0
0000792ccedd9423  vmovaps [rsp], xmm0
0000792ccedd9428  vmovaps [rsp+0x10], xmm1
0000792ccedd942e  vmovaps [rsp+0x20], xmm2
0000792ccedd9434  vmovaps [rsp+0x30], xmm3
0000792ccedd943a  vmovaps [rsp+0x40], xmm4
0000792ccedd9440  vmovaps [rsp+0x50], xmm5
0000792ccedd9446  vmovaps [rsp+0x60], xmm6
0000792ccedd944c  vmovaps [rsp+0x70], xmm7
0000792ccedd9452  vmovaps [rsp+0x80], xmm8
0000792ccedd945b  vmovaps [rsp+0x90], xmm9
0000792ccedd9464  vmovaps [rsp+0xA0], xmm11
0000792ccedd946d  vmovaps [rsp+0xB0], xmm12
0000792ccedd9476  vmovaps [rsp+0xC0], xmm13
0000792ccedd947f  vmovaps [rsp+0xD0], xmm14
0000792ccedd9488  vmovaps [rsp+0xE0], xmm15
0000792ccedd9491  sub rsp, 0x30
0000792ccedd9495  movaps [rsp], xmm10
0000792ccedd949a  movaps [rsp+0x10], xmm8
0000792ccedd94a0  movaps [rsp+0x20], xmm14
0000792ccedd94a6  lea rdi, [rsp]
0000792ccedd94aa  mov esi, 0x00
0000792ccedd94af  mov rax, 0x5AEE2D541530
0000792ccedd94b9  call rax
0000792ccedd94bb  movaps xmm10, [rsp]
0000792ccedd94c0  add rsp, 0x30
0000792ccedd94c4  vmovaps xmm0, [rsp]
0000792ccedd94c9  vmovaps xmm1, [rsp+0x10]
0000792ccedd94cf  vmovaps xmm2, [rsp+0x20]
0000792ccedd94d5  vmovaps xmm3, [rsp+0x30]
0000792ccedd94db  vmovaps xmm4, [rsp+0x40]
0000792ccedd94e1  vmovaps xmm5, [rsp+0x50]
0000792ccedd94e7  vmovaps xmm6, [rsp+0x60]
0000792ccedd94ed  vmovaps xmm7, [rsp+0x70]
0000792ccedd94f3  vmovaps xmm8, [rsp+0x80]
0000792ccedd94fc  vmovaps xmm9, [rsp+0x90]
0000792ccedd9505  vmovaps xmm11, [rsp+0xA0]
0000792ccedd950e  vmovaps xmm12, [rsp+0xB0]
0000792ccedd9517  vmovaps xmm13, [rsp+0xC0]
0000792ccedd9520  vmovaps xmm14, [rsp+0xD0]
0000792ccedd9529  vmovaps xmm15, [rsp+0xE0]
0000792ccedd9532  add rsp, 0xF0
0000792ccedd9539  pop r11
0000792ccedd953b  pop r10
0000792ccedd953d  pop r9
0000792ccedd953f  pop r8
0000792ccedd9541  pop rsi
0000792ccedd9542  pop rdi
0000792ccedd9543  pop rdx
0000792ccedd9544  pop rcx
0000792ccedd9545  pop rax
0000792ccedd9546  add rsp, 0x08
0000792ccedd954a  jmp 0x0000792CCEDD6245
0000792ccedd954f  sub rsp, 0x08
0000792ccedd9553  push rax
0000792ccedd9554  push rcx
0000792ccedd9555  push rdx
0000792ccedd9556  push rdi
0000792ccedd9557  push rsi
0000792ccedd9558  push r8
0000792ccedd955a  push r9
0000792ccedd955c  push r10
0000792ccedd955e  push r11
0000792ccedd9560  sub rsp, 0xF0
0000792ccedd9567  vmovaps [rsp], xmm0
0000792ccedd956c  vmovaps [rsp+0x10], xmm1
0000792ccedd9572  vmovaps [rsp+0x20], xmm2
0000792ccedd9578  vmovaps [rsp+0x30], xmm3
0000792ccedd957e  vmovaps [rsp+0x40], xmm4
0000792ccedd9584  vmovaps [rsp+0x50], xmm5
0000792ccedd958a  vmovaps [rsp+0x60], xmm6
0000792ccedd9590  vmovaps [rsp+0x70], xmm7
0000792ccedd9596  vmovaps [rsp+0x80], xmm8
0000792ccedd959f  vmovaps [rsp+0x90], xmm9
0000792ccedd95a8  vmovaps [rsp+0xA0], xmm10
0000792ccedd95b1  vmovaps [rsp+0xB0], xmm11
0000792ccedd95ba  vmovaps [rsp+0xC0], xmm12
0000792ccedd95c3  vmovaps [rsp+0xD0], xmm13
0000792ccedd95cc  vmovaps [rsp+0xE0], xmm15
0000792ccedd95d5  sub rsp, 0x30
0000792ccedd95d9  movaps [rsp], xmm14
0000792ccedd95de  movaps [rsp+0x10], xmm8
0000792ccedd95e4  movaps [rsp+0x20], xmm4
0000792ccedd95e9  lea rdi, [rsp]
0000792ccedd95ed  mov esi, 0x00
0000792ccedd95f2  mov rax, 0x5AEE2D541530
0000792ccedd95fc  call rax
0000792ccedd95fe  movaps xmm14, [rsp]
0000792ccedd9603  add rsp, 0x30
0000792ccedd9607  vmovaps xmm0, [rsp]
0000792ccedd960c  vmovaps xmm1, [rsp+0x10]
0000792ccedd9612  vmovaps xmm2, [rsp+0x20]
0000792ccedd9618  vmovaps xmm3, [rsp+0x30]
0000792ccedd961e  vmovaps xmm4, [rsp+0x40]
0000792ccedd9624  vmovaps xmm5, [rsp+0x50]
0000792ccedd962a  vmovaps xmm6, [rsp+0x60]
0000792ccedd9630  vmovaps xmm7, [rsp+0x70]
0000792ccedd9636  vmovaps xmm8, [rsp+0x80]
0000792ccedd963f  vmovaps xmm9, [rsp+0x90]
0000792ccedd9648  vmovaps xmm10, [rsp+0xA0]
0000792ccedd9651  vmovaps xmm11, [rsp+0xB0]
0000792ccedd965a  vmovaps xmm12, [rsp+0xC0]
0000792ccedd9663  vmovaps xmm13, [rsp+0xD0]
0000792ccedd966c  vmovaps xmm15, [rsp+0xE0]
0000792ccedd9675  add rsp, 0xF0
0000792ccedd967c  pop r11
0000792ccedd967e  pop r10
0000792ccedd9680  pop r9
0000792ccedd9682  pop r8
0000792ccedd9684  pop rsi
0000792ccedd9685  pop rdi
0000792ccedd9686  pop rdx
0000792ccedd9687  pop rcx
0000792ccedd9688  pop rax
0000792ccedd9689  add rsp, 0x08
0000792ccedd968d  jmp 0x0000792CCEDD6265
0000792ccedd9692  sub rsp, 0x08
0000792ccedd9696  push rax
0000792ccedd9697  push rcx
0000792ccedd9698  push rdx
0000792ccedd9699  push rdi
0000792ccedd969a  push rsi
0000792ccedd969b  push r8
0000792ccedd969d  push r9
0000792ccedd969f  push r10
0000792ccedd96a1  push r11
0000792ccedd96a3  sub rsp, 0xF0
0000792ccedd96aa  vmovaps [rsp], xmm0
0000792ccedd96af  vmovaps [rsp+0x10], xmm1
0000792ccedd96b5  vmovaps [rsp+0x20], xmm2
0000792ccedd96bb  vmovaps [rsp+0x30], xmm3
0000792ccedd96c1  vmovaps [rsp+0x40], xmm5
0000792ccedd96c7  vmovaps [rsp+0x50], xmm6
0000792ccedd96cd  vmovaps [rsp+0x60], xmm7
0000792ccedd96d3  vmovaps [rsp+0x70], xmm8
0000792ccedd96d9  vmovaps [rsp+0x80], xmm9
0000792ccedd96e2  vmovaps [rsp+0x90], xmm10
0000792ccedd96eb  vmovaps [rsp+0xA0], xmm11
0000792ccedd96f4  vmovaps [rsp+0xB0], xmm12
0000792ccedd96fd  vmovaps [rsp+0xC0], xmm13
0000792ccedd9706  vmovaps [rsp+0xD0], xmm14
0000792ccedd970f  vmovaps [rsp+0xE0], xmm15
0000792ccedd9718  sub rsp, 0x30
0000792ccedd971c  movaps [rsp], xmm4
0000792ccedd9720  movaps [rsp+0x10], xmm13
0000792ccedd9726  movaps [rsp+0x20], xmm8
0000792ccedd972c  lea rdi, [rsp]
0000792ccedd9730  mov esi, 0x00
0000792ccedd9735  mov rax, 0x5AEE2D541530
0000792ccedd973f  call rax
0000792ccedd9741  movaps xmm4, [rsp]
0000792ccedd9745  add rsp, 0x30
0000792ccedd9749  vmovaps xmm0, [rsp]
0000792ccedd974e  vmovaps xmm1, [rsp+0x10]
0000792ccedd9754  vmovaps xmm2, [rsp+0x20]
0000792ccedd975a  vmovaps xmm3, [rsp+0x30]
0000792ccedd9760  vmovaps xmm5, [rsp+0x40]
0000792ccedd9766  vmovaps xmm6, [rsp+0x50]
0000792ccedd976c  vmovaps xmm7, [rsp+0x60]
0000792ccedd9772  vmovaps xmm8, [rsp+0x70]
0000792ccedd9778  vmovaps xmm9, [rsp+0x80]
0000792ccedd9781  vmovaps xmm10, [rsp+0x90]
0000792ccedd978a  vmovaps xmm11, [rsp+0xA0]
0000792ccedd9793  vmovaps xmm12, [rsp+0xB0]
0000792ccedd979c  vmovaps xmm13, [rsp+0xC0]
0000792ccedd97a5  vmovaps xmm14, [rsp+0xD0]
0000792ccedd97ae  vmovaps xmm15, [rsp+0xE0]
0000792ccedd97b7  add rsp, 0xF0
0000792ccedd97be  pop r11
0000792ccedd97c0  pop r10
0000792ccedd97c2  pop r9
0000792ccedd97c4  pop r8
0000792ccedd97c6  pop rsi
0000792ccedd97c7  pop rdi
0000792ccedd97c8  pop rdx
0000792ccedd97c9  pop rcx
0000792ccedd97ca  pop rax
0000792ccedd97cb  add rsp, 0x08
0000792ccedd97cf  jmp 0x0000792CCEDD628A
0000792ccedd97d4  sub rsp, 0x08
0000792ccedd97d8  push rax
0000792ccedd97d9  push rcx
0000792ccedd97da  push rdx
0000792ccedd97db  push rdi
0000792ccedd97dc  push rsi
0000792ccedd97dd  push r8
0000792ccedd97df  push r9
0000792ccedd97e1  push r10
0000792ccedd97e3  push r11
0000792ccedd97e5  sub rsp, 0xF0
0000792ccedd97ec  vmovaps [rsp], xmm0
0000792ccedd97f1  vmovaps [rsp+0x10], xmm1
0000792ccedd97f7  vmovaps [rsp+0x20], xmm2
0000792ccedd97fd  vmovaps [rsp+0x30], xmm3
0000792ccedd9803  vmovaps [rsp+0x40], xmm4
0000792ccedd9809  vmovaps [rsp+0x50], xmm5
0000792ccedd980f  vmovaps [rsp+0x60], xmm6
0000792ccedd9815  vmovaps [rsp+0x70], xmm7
0000792ccedd981b  vmovaps [rsp+0x80], xmm8
0000792ccedd9824  vmovaps [rsp+0x90], xmm9
0000792ccedd982d  vmovaps [rsp+0xA0], xmm10
0000792ccedd9836  vmovaps [rsp+0xB0], xmm11
0000792ccedd983f  vmovaps [rsp+0xC0], xmm12
0000792ccedd9848  vmovaps [rsp+0xD0], xmm14
0000792ccedd9851  vmovaps [rsp+0xE0], xmm15
0000792ccedd985a  sub rsp, 0x30
0000792ccedd985e  movaps [rsp], xmm13
0000792ccedd9863  movaps [rsp+0x10], xmm15
0000792ccedd9869  movaps [rsp+0x20], xmm9
0000792ccedd986f  lea rdi, [rsp]
0000792ccedd9873  mov esi, 0x00
0000792ccedd9878  mov rax, 0x5AEE2D541530
0000792ccedd9882  call rax
0000792ccedd9884  movaps xmm13, [rsp]
0000792ccedd9889  add rsp, 0x30
0000792ccedd988d  vmovaps xmm0, [rsp]
0000792ccedd9892  vmovaps xmm1, [rsp+0x10]
0000792ccedd9898  vmovaps xmm2, [rsp+0x20]
0000792ccedd989e  vmovaps xmm3, [rsp+0x30]
0000792ccedd98a4  vmovaps xmm4, [rsp+0x40]
0000792ccedd98aa  vmovaps xmm5, [rsp+0x50]
0000792ccedd98b0  vmovaps xmm6, [rsp+0x60]
0000792ccedd98b6  vmovaps xmm7, [rsp+0x70]
0000792ccedd98bc  vmovaps xmm8, [rsp+0x80]
0000792ccedd98c5  vmovaps xmm9, [rsp+0x90]
0000792ccedd98ce  vmovaps xmm10, [rsp+0xA0]
0000792ccedd98d7  vmovaps xmm11, [rsp+0xB0]
0000792ccedd98e0  vmovaps xmm12, [rsp+0xC0]
0000792ccedd98e9  vmovaps xmm14, [rsp+0xD0]
0000792ccedd98f2  vmovaps xmm15, [rsp+0xE0]
0000792ccedd98fb  add rsp, 0xF0
0000792ccedd9902  pop r11
0000792ccedd9904  pop r10
0000792ccedd9906  pop r9
0000792ccedd9908  pop r8
0000792ccedd990a  pop rsi
0000792ccedd990b  pop rdi
0000792ccedd990c  pop rdx
0000792ccedd990d  pop rcx
0000792ccedd990e  pop rax
0000792ccedd990f  add rsp, 0x08
0000792ccedd9913  jmp 0x0000792CCEDD62A5
0000792ccedd9918  sub rsp, 0x08
0000792ccedd991c  push rax
0000792ccedd991d  push rcx
0000792ccedd991e  push rdx
0000792ccedd991f  push rdi
0000792ccedd9920  push rsi
0000792ccedd9921  push r8
0000792ccedd9923  push r9
0000792ccedd9925  push r10
0000792ccedd9927  push r11
0000792ccedd9929  sub rsp, 0xF0
0000792ccedd9930  vmovaps [rsp], xmm0
0000792ccedd9935  vmovaps [rsp+0x10], xmm1
0000792ccedd993b  vmovaps [rsp+0x20], xmm2
0000792ccedd9941  vmovaps [rsp+0x30], xmm3
0000792ccedd9947  vmovaps [rsp+0x40], xmm4
0000792ccedd994d  vmovaps [rsp+0x50], xmm5
0000792ccedd9953  vmovaps [rsp+0x60], xmm6
0000792ccedd9959  vmovaps [rsp+0x70], xmm7
0000792ccedd995f  vmovaps [rsp+0x80], xmm8
0000792ccedd9968  vmovaps [rsp+0x90], xmm9
0000792ccedd9971  vmovaps [rsp+0xA0], xmm10
0000792ccedd997a  vmovaps [rsp+0xB0], xmm11
0000792ccedd9983  vmovaps [rsp+0xC0], xmm12
0000792ccedd998c  vmovaps [rsp+0xD0], xmm13
0000792ccedd9995  vmovaps [rsp+0xE0], xmm14
0000792ccedd999e  sub rsp, 0x30
0000792ccedd99a2  movaps [rsp], xmm15
0000792ccedd99a7  movaps [rsp+0x10], xmm1
0000792ccedd99ac  movaps [rsp+0x20], xmm5
0000792ccedd99b1  lea rdi, [rsp]
0000792ccedd99b5  mov esi, 0x00
0000792ccedd99ba  mov rax, 0x5AEE2D541530
0000792ccedd99c4  call rax
0000792ccedd99c6  movaps xmm15, [rsp]
0000792ccedd99cb  add rsp, 0x30
0000792ccedd99cf  vmovaps xmm0, [rsp]
0000792ccedd99d4  vmovaps xmm1, [rsp+0x10]
0000792ccedd99da  vmovaps xmm2, [rsp+0x20]
0000792ccedd99e0  vmovaps xmm3, [rsp+0x30]
0000792ccedd99e6  vmovaps xmm4, [rsp+0x40]
0000792ccedd99ec  vmovaps xmm5, [rsp+0x50]
0000792ccedd99f2  vmovaps xmm6, [rsp+0x60]
0000792ccedd99f8  vmovaps xmm7, [rsp+0x70]
0000792ccedd99fe  vmovaps xmm8, [rsp+0x80]
0000792ccedd9a07  vmovaps xmm9, [rsp+0x90]
0000792ccedd9a10  vmovaps xmm10, [rsp+0xA0]
0000792ccedd9a19  vmovaps xmm11, [rsp+0xB0]
0000792ccedd9a22  vmovaps xmm12, [rsp+0xC0]
0000792ccedd9a2b  vmovaps xmm13, [rsp+0xD0]
0000792ccedd9a34  vmovaps xmm14, [rsp+0xE0]
0000792ccedd9a3d  add rsp, 0xF0
0000792ccedd9a44  pop r11
0000792ccedd9a46  pop r10
0000792ccedd9a48  pop r9
0000792ccedd9a4a  pop r8
0000792ccedd9a4c  pop rsi
0000792ccedd9a4d  pop rdi
0000792ccedd9a4e  pop rdx
0000792ccedd9a4f  pop rcx
0000792ccedd9a50  pop rax
0000792ccedd9a51  add rsp, 0x08
0000792ccedd9a55  jmp 0x0000792CCEDD62C0
0000792ccedd9a5a  call 0x0000792CCECD64F0
0000792ccedd9a5f  jmp 0x0000792CCEDD631B
0000792ccedd9a64  sub rsp, 0x08
0000792ccedd9a68  push rax
0000792ccedd9a69  push rcx
0000792ccedd9a6a  push rdx
0000792ccedd9a6b  push rdi
0000792ccedd9a6c  push rsi
0000792ccedd9a6d  push r8
0000792ccedd9a6f  push r9
0000792ccedd9a71  push r10
0000792ccedd9a73  push r11
0000792ccedd9a75  sub rsp, 0xF0
0000792ccedd9a7c  vmovaps [rsp], xmm0
0000792ccedd9a81  vmovaps [rsp+0x10], xmm1
0000792ccedd9a87  vmovaps [rsp+0x20], xmm2
0000792ccedd9a8d  vmovaps [rsp+0x30], xmm3
0000792ccedd9a93  vmovaps [rsp+0x40], xmm4
0000792ccedd9a99  vmovaps [rsp+0x50], xmm5
0000792ccedd9a9f  vmovaps [rsp+0x60], xmm6
0000792ccedd9aa5  vmovaps [rsp+0x70], xmm7
0000792ccedd9aab  vmovaps [rsp+0x80], xmm8
0000792ccedd9ab4  vmovaps [rsp+0x90], xmm10
0000792ccedd9abd  vmovaps [rsp+0xA0], xmm11
0000792ccedd9ac6  vmovaps [rsp+0xB0], xmm12
0000792ccedd9acf  vmovaps [rsp+0xC0], xmm13
0000792ccedd9ad8  vmovaps [rsp+0xD0], xmm14
0000792ccedd9ae1  vmovaps [rsp+0xE0], xmm15
0000792ccedd9aea  sub rsp, 0x30
0000792ccedd9aee  movaps [rsp], xmm9
0000792ccedd9af3  movaps [rsp+0x10], xmm8
0000792ccedd9af9  movaps [rsp+0x20], xmm11
0000792ccedd9aff  lea rdi, [rsp]
0000792ccedd9b03  mov esi, 0x00
0000792ccedd9b08  mov rax, 0x5AEE2D541530
0000792ccedd9b12  call rax
0000792ccedd9b14  movaps xmm9, [rsp]
0000792ccedd9b19  add rsp, 0x30
0000792ccedd9b1d  vmovaps xmm0, [rsp]
0000792ccedd9b22  vmovaps xmm1, [rsp+0x10]
0000792ccedd9b28  vmovaps xmm2, [rsp+0x20]
0000792ccedd9b2e  vmovaps xmm3, [rsp+0x30]
0000792ccedd9b34  vmovaps xmm4, [rsp+0x40]
0000792ccedd9b3a  vmovaps xmm5, [rsp+0x50]
0000792ccedd9b40  vmovaps xmm6, [rsp+0x60]
0000792ccedd9b46  vmovaps xmm7, [rsp+0x70]
0000792ccedd9b4c  vmovaps xmm8, [rsp+0x80]
0000792ccedd9b55  vmovaps xmm10, [rsp+0x90]
0000792ccedd9b5e  vmovaps xmm11, [rsp+0xA0]
0000792ccedd9b67  vmovaps xmm12, [rsp+0xB0]
0000792ccedd9b70  vmovaps xmm13, [rsp+0xC0]
0000792ccedd9b79  vmovaps xmm14, [rsp+0xD0]
0000792ccedd9b82  vmovaps xmm15, [rsp+0xE0]
0000792ccedd9b8b  add rsp, 0xF0
0000792ccedd9b92  pop r11
0000792ccedd9b94  pop r10
0000792ccedd9b96  pop r9
0000792ccedd9b98  pop r8
0000792ccedd9b9a  pop rsi
0000792ccedd9b9b  pop rdi
0000792ccedd9b9c  pop rdx
0000792ccedd9b9d  pop rcx
0000792ccedd9b9e  pop rax
0000792ccedd9b9f  add rsp, 0x08
0000792ccedd9ba3  jmp 0x0000792CCEDD6352
0000792ccedd9ba8  sub rsp, 0x08
0000792ccedd9bac  push rax
0000792ccedd9bad  push rcx
0000792ccedd9bae  push rdx
0000792ccedd9baf  push rdi
0000792ccedd9bb0  push rsi
0000792ccedd9bb1  push r8
0000792ccedd9bb3  push r9
0000792ccedd9bb5  push r10
0000792ccedd9bb7  push r11
0000792ccedd9bb9  sub rsp, 0xF0
0000792ccedd9bc0  vmovaps [rsp], xmm0
0000792ccedd9bc5  vmovaps [rsp+0x10], xmm1
0000792ccedd9bcb  vmovaps [rsp+0x20], xmm2
0000792ccedd9bd1  vmovaps [rsp+0x30], xmm3
0000792ccedd9bd7  vmovaps [rsp+0x40], xmm4
0000792ccedd9bdd  vmovaps [rsp+0x50], xmm5
0000792ccedd9be3  vmovaps [rsp+0x60], xmm6
0000792ccedd9be9  vmovaps [rsp+0x70], xmm7
0000792ccedd9bef  vmovaps [rsp+0x80], xmm8
0000792ccedd9bf8  vmovaps [rsp+0x90], xmm9
0000792ccedd9c01  vmovaps [rsp+0xA0], xmm10
0000792ccedd9c0a  vmovaps [rsp+0xB0], xmm12
0000792ccedd9c13  vmovaps [rsp+0xC0], xmm13
0000792ccedd9c1c  vmovaps [rsp+0xD0], xmm14
0000792ccedd9c25  vmovaps [rsp+0xE0], xmm15
0000792ccedd9c2e  sub rsp, 0x30
0000792ccedd9c32  movaps [rsp], xmm11
0000792ccedd9c37  movaps [rsp+0x10], xmm10
0000792ccedd9c3d  movaps [rsp+0x20], xmm6
0000792ccedd9c42  lea rdi, [rsp]
0000792ccedd9c46  mov esi, 0x00
0000792ccedd9c4b  mov rax, 0x5AEE2D541530
0000792ccedd9c55  call rax
0000792ccedd9c57  movaps xmm11, [rsp]
0000792ccedd9c5c  add rsp, 0x30
0000792ccedd9c60  vmovaps xmm0, [rsp]
0000792ccedd9c65  vmovaps xmm1, [rsp+0x10]
0000792ccedd9c6b  vmovaps xmm2, [rsp+0x20]
0000792ccedd9c71  vmovaps xmm3, [rsp+0x30]
0000792ccedd9c77  vmovaps xmm4, [rsp+0x40]
0000792ccedd9c7d  vmovaps xmm5, [rsp+0x50]
0000792ccedd9c83  vmovaps xmm6, [rsp+0x60]
0000792ccedd9c89  vmovaps xmm7, [rsp+0x70]
0000792ccedd9c8f  vmovaps xmm8, [rsp+0x80]
0000792ccedd9c98  vmovaps xmm9, [rsp+0x90]
0000792ccedd9ca1  vmovaps xmm10, [rsp+0xA0]
0000792ccedd9caa  vmovaps xmm12, [rsp+0xB0]
0000792ccedd9cb3  vmovaps xmm13, [rsp+0xC0]
0000792ccedd9cbc  vmovaps xmm14, [rsp+0xD0]
0000792ccedd9cc5  vmovaps xmm15, [rsp+0xE0]
0000792ccedd9cce  add rsp, 0xF0
0000792ccedd9cd5  pop r11
0000792ccedd9cd7  pop r10
0000792ccedd9cd9  pop r9
0000792ccedd9cdb  pop r8
0000792ccedd9cdd  pop rsi
0000792ccedd9cde  pop rdi
0000792ccedd9cdf  pop rdx
0000792ccedd9ce0  pop rcx
0000792ccedd9ce1  pop rax
0000792ccedd9ce2  add rsp, 0x08
0000792ccedd9ce6  jmp 0x0000792CCEDD636D
0000792ccedd9ceb  sub rsp, 0x08
0000792ccedd9cef  push rax
0000792ccedd9cf0  push rcx
0000792ccedd9cf1  push rdx
0000792ccedd9cf2  push rdi
0000792ccedd9cf3  push rsi
0000792ccedd9cf4  push r8
0000792ccedd9cf6  push r9
0000792ccedd9cf8  push r10
0000792ccedd9cfa  push r11
0000792ccedd9cfc  sub rsp, 0xF0
0000792ccedd9d03  vmovaps [rsp], xmm0
0000792ccedd9d08  vmovaps [rsp+0x10], xmm1
0000792ccedd9d0e  vmovaps [rsp+0x20], xmm2
0000792ccedd9d14  vmovaps [rsp+0x30], xmm3
0000792ccedd9d1a  vmovaps [rsp+0x40], xmm4
0000792ccedd9d20  vmovaps [rsp+0x50], xmm5
0000792ccedd9d26  vmovaps [rsp+0x60], xmm6
0000792ccedd9d2c  vmovaps [rsp+0x70], xmm7
0000792ccedd9d32  vmovaps [rsp+0x80], xmm8
0000792ccedd9d3b  vmovaps [rsp+0x90], xmm9
0000792ccedd9d44  vmovaps [rsp+0xA0], xmm11
0000792ccedd9d4d  vmovaps [rsp+0xB0], xmm12
0000792ccedd9d56  vmovaps [rsp+0xC0], xmm13
0000792ccedd9d5f  vmovaps [rsp+0xD0], xmm14
0000792ccedd9d68  vmovaps [rsp+0xE0], xmm15
0000792ccedd9d71  sub rsp, 0x30
0000792ccedd9d75  movaps [rsp], xmm10
0000792ccedd9d7a  movaps [rsp+0x10], xmm14
0000792ccedd9d80  movaps [rsp+0x20], xmm4
0000792ccedd9d85  lea rdi, [rsp]
0000792ccedd9d89  mov esi, 0x00
0000792ccedd9d8e  mov rax, 0x5AEE2D541530
0000792ccedd9d98  call rax
0000792ccedd9d9a  movaps xmm10, [rsp]
0000792ccedd9d9f  add rsp, 0x30
0000792ccedd9da3  vmovaps xmm0, [rsp]
0000792ccedd9da8  vmovaps xmm1, [rsp+0x10]
0000792ccedd9dae  vmovaps xmm2, [rsp+0x20]
0000792ccedd9db4  vmovaps xmm3, [rsp+0x30]
0000792ccedd9dba  vmovaps xmm4, [rsp+0x40]
0000792ccedd9dc0  vmovaps xmm5, [rsp+0x50]
0000792ccedd9dc6  vmovaps xmm6, [rsp+0x60]
0000792ccedd9dcc  vmovaps xmm7, [rsp+0x70]
0000792ccedd9dd2  vmovaps xmm8, [rsp+0x80]
0000792ccedd9ddb  vmovaps xmm9, [rsp+0x90]
0000792ccedd9de4  vmovaps xmm11, [rsp+0xA0]
0000792ccedd9ded  vmovaps xmm12, [rsp+0xB0]
0000792ccedd9df6  vmovaps xmm13, [rsp+0xC0]
0000792ccedd9dff  vmovaps xmm14, [rsp+0xD0]
0000792ccedd9e08  vmovaps xmm15, [rsp+0xE0]
0000792ccedd9e11  add rsp, 0xF0
0000792ccedd9e18  pop r11
0000792ccedd9e1a  pop r10
0000792ccedd9e1c  pop r9
0000792ccedd9e1e  pop r8
0000792ccedd9e20  pop rsi
0000792ccedd9e21  pop rdi
0000792ccedd9e22  pop rdx
0000792ccedd9e23  pop rcx
0000792ccedd9e24  pop rax
0000792ccedd9e25  add rsp, 0x08
0000792ccedd9e29  jmp 0x0000792CCEDD6388
0000792ccedd9e2e  sub rsp, 0x08
0000792ccedd9e32  push rax
0000792ccedd9e33  push rcx
0000792ccedd9e34  push rdx
0000792ccedd9e35  push rdi
0000792ccedd9e36  push rsi
0000792ccedd9e37  push r8
0000792ccedd9e39  push r9
0000792ccedd9e3b  push r10
0000792ccedd9e3d  push r11
0000792ccedd9e3f  sub rsp, 0xF0
0000792ccedd9e46  vmovaps [rsp], xmm0
0000792ccedd9e4b  vmovaps [rsp+0x10], xmm1
0000792ccedd9e51  vmovaps [rsp+0x20], xmm2
0000792ccedd9e57  vmovaps [rsp+0x30], xmm3
0000792ccedd9e5d  vmovaps [rsp+0x40], xmm4
0000792ccedd9e63  vmovaps [rsp+0x50], xmm5
0000792ccedd9e69  vmovaps [rsp+0x60], xmm6
0000792ccedd9e6f  vmovaps [rsp+0x70], xmm7
0000792ccedd9e75  vmovaps [rsp+0x80], xmm9
0000792ccedd9e7e  vmovaps [rsp+0x90], xmm10
0000792ccedd9e87  vmovaps [rsp+0xA0], xmm11
0000792ccedd9e90  vmovaps [rsp+0xB0], xmm12
0000792ccedd9e99  vmovaps [rsp+0xC0], xmm13
0000792ccedd9ea2  vmovaps [rsp+0xD0], xmm14
0000792ccedd9eab  vmovaps [rsp+0xE0], xmm15
0000792ccedd9eb4  sub rsp, 0x30
0000792ccedd9eb8  movaps [rsp], xmm8
0000792ccedd9ebd  movaps [rsp+0x10], xmm1
0000792ccedd9ec2  movaps [rsp+0x20], xmm14
0000792ccedd9ec8  lea rdi, [rsp]
0000792ccedd9ecc  mov esi, 0x00
0000792ccedd9ed1  mov rax, 0x5AEE2D541530
0000792ccedd9edb  call rax
0000792ccedd9edd  movaps xmm8, [rsp]
0000792ccedd9ee2  add rsp, 0x30
0000792ccedd9ee6  vmovaps xmm0, [rsp]
0000792ccedd9eeb  vmovaps xmm1, [rsp+0x10]
0000792ccedd9ef1  vmovaps xmm2, [rsp+0x20]
0000792ccedd9ef7  vmovaps xmm3, [rsp+0x30]
0000792ccedd9efd  vmovaps xmm4, [rsp+0x40]
0000792ccedd9f03  vmovaps xmm5, [rsp+0x50]
0000792ccedd9f09  vmovaps xmm6, [rsp+0x60]
0000792ccedd9f0f  vmovaps xmm7, [rsp+0x70]
0000792ccedd9f15  vmovaps xmm9, [rsp+0x80]
0000792ccedd9f1e  vmovaps xmm10, [rsp+0x90]
0000792ccedd9f27  vmovaps xmm11, [rsp+0xA0]
0000792ccedd9f30  vmovaps xmm12, [rsp+0xB0]
0000792ccedd9f39  vmovaps xmm13, [rsp+0xC0]
0000792ccedd9f42  vmovaps xmm14, [rsp+0xD0]
0000792ccedd9f4b  vmovaps xmm15, [rsp+0xE0]
0000792ccedd9f54  add rsp, 0xF0
0000792ccedd9f5b  pop r11
0000792ccedd9f5d  pop r10
0000792ccedd9f5f  pop r9
0000792ccedd9f61  pop r8
0000792ccedd9f63  pop rsi
0000792ccedd9f64  pop rdi
0000792ccedd9f65  pop rdx
0000792ccedd9f66  pop rcx
0000792ccedd9f67  pop rax
0000792ccedd9f68  add rsp, 0x08
0000792ccedd9f6c  jmp 0x0000792CCEDD63AE
0000792ccedd9f71  sub rsp, 0x08
0000792ccedd9f75  push rax
0000792ccedd9f76  push rcx
0000792ccedd9f77  push rdx
0000792ccedd9f78  push rdi
0000792ccedd9f79  push rsi
0000792ccedd9f7a  push r8
0000792ccedd9f7c  push r9
0000792ccedd9f7e  push r10
0000792ccedd9f80  push r11
0000792ccedd9f82  sub rsp, 0xF0
0000792ccedd9f89  vmovaps [rsp], xmm0
0000792ccedd9f8e  vmovaps [rsp+0x10], xmm1
0000792ccedd9f94  vmovaps [rsp+0x20], xmm2
0000792ccedd9f9a  vmovaps [rsp+0x30], xmm3
0000792ccedd9fa0  vmovaps [rsp+0x40], xmm4
0000792ccedd9fa6  vmovaps [rsp+0x50], xmm5
0000792ccedd9fac  vmovaps [rsp+0x60], xmm7
0000792ccedd9fb2  vmovaps [rsp+0x70], xmm8
0000792ccedd9fb8  vmovaps [rsp+0x80], xmm9
0000792ccedd9fc1  vmovaps [rsp+0x90], xmm10
0000792ccedd9fca  vmovaps [rsp+0xA0], xmm11
0000792ccedd9fd3  vmovaps [rsp+0xB0], xmm12
0000792ccedd9fdc  vmovaps [rsp+0xC0], xmm13
0000792ccedd9fe5  vmovaps [rsp+0xD0], xmm14
0000792ccedd9fee  vmovaps [rsp+0xE0], xmm15
0000792ccedd9ff7  sub rsp, 0x30
0000792ccedd9ffb  movaps [rsp], xmm6
0000792ccedd9fff  movaps [rsp+0x10], xmm1
0000792ccedda004  movaps [rsp+0x20], xmm14
0000792ccedda00a  lea rdi, [rsp]
0000792ccedda00e  mov esi, 0x00
0000792ccedda013  mov rax, 0x5AEE2D541530
0000792ccedda01d  call rax
0000792ccedda01f  movaps xmm6, [rsp]
0000792ccedda023  add rsp, 0x30
0000792ccedda027  vmovaps xmm0, [rsp]
0000792ccedda02c  vmovaps xmm1, [rsp+0x10]
0000792ccedda032  vmovaps xmm2, [rsp+0x20]
0000792ccedda038  vmovaps xmm3, [rsp+0x30]
0000792ccedda03e  vmovaps xmm4, [rsp+0x40]
0000792ccedda044  vmovaps xmm5, [rsp+0x50]
0000792ccedda04a  vmovaps xmm7, [rsp+0x60]
0000792ccedda050  vmovaps xmm8, [rsp+0x70]
0000792ccedda056  vmovaps xmm9, [rsp+0x80]
0000792ccedda05f  vmovaps xmm10, [rsp+0x90]
0000792ccedda068  vmovaps xmm11, [rsp+0xA0]
0000792ccedda071  vmovaps xmm12, [rsp+0xB0]
0000792ccedda07a  vmovaps xmm13, [rsp+0xC0]
0000792ccedda083  vmovaps xmm14, [rsp+0xD0]
0000792ccedda08c  vmovaps xmm15, [rsp+0xE0]
0000792ccedda095  add rsp, 0xF0
0000792ccedda09c  pop r11
0000792ccedda09e  pop r10
0000792ccedda0a0  pop r9
0000792ccedda0a2  pop r8
0000792ccedda0a4  pop rsi
0000792ccedda0a5  pop rdi
0000792ccedda0a6  pop rdx
0000792ccedda0a7  pop rcx
0000792ccedda0a8  pop rax
0000792ccedda0a9  add rsp, 0x08
0000792ccedda0ad  jmp 0x0000792CCEDD63DA
0000792ccedda0b2  sub rsp, 0x08
0000792ccedda0b6  push rax
0000792ccedda0b7  push rcx
0000792ccedda0b8  push rdx
0000792ccedda0b9  push rdi
0000792ccedda0ba  push rsi
0000792ccedda0bb  push r8
0000792ccedda0bd  push r9
0000792ccedda0bf  push r10
0000792ccedda0c1  push r11
0000792ccedda0c3  sub rsp, 0xF0
0000792ccedda0ca  vmovaps [rsp], xmm0
0000792ccedda0cf  vmovaps [rsp+0x10], xmm1
0000792ccedda0d5  vmovaps [rsp+0x20], xmm2
0000792ccedda0db  vmovaps [rsp+0x30], xmm3
0000792ccedda0e1  vmovaps [rsp+0x40], xmm4
0000792ccedda0e7  vmovaps [rsp+0x50], xmm5
0000792ccedda0ed  vmovaps [rsp+0x60], xmm6
0000792ccedda0f3  vmovaps [rsp+0x70], xmm7
0000792ccedda0f9  vmovaps [rsp+0x80], xmm8
0000792ccedda102  vmovaps [rsp+0x90], xmm9
0000792ccedda10b  vmovaps [rsp+0xA0], xmm10
0000792ccedda114  vmovaps [rsp+0xB0], xmm11
0000792ccedda11d  vmovaps [rsp+0xC0], xmm12
0000792ccedda126  vmovaps [rsp+0xD0], xmm13
0000792ccedda12f  vmovaps [rsp+0xE0], xmm15
0000792ccedda138  sub rsp, 0x30
0000792ccedda13c  movaps [rsp], xmm14
0000792ccedda141  movaps [rsp+0x10], xmm12
0000792ccedda147  movaps [rsp+0x20], xmm1
0000792ccedda14c  lea rdi, [rsp]
0000792ccedda150  mov esi, 0x00
0000792ccedda155  mov rax, 0x5AEE2D541530
0000792ccedda15f  call rax
0000792ccedda161  movaps xmm14, [rsp]
0000792ccedda166  add rsp, 0x30
0000792ccedda16a  vmovaps xmm0, [rsp]
0000792ccedda16f  vmovaps xmm1, [rsp+0x10]
0000792ccedda175  vmovaps xmm2, [rsp+0x20]
0000792ccedda17b  vmovaps xmm3, [rsp+0x30]
0000792ccedda181  vmovaps xmm4, [rsp+0x40]
0000792ccedda187  vmovaps xmm5, [rsp+0x50]
0000792ccedda18d  vmovaps xmm6, [rsp+0x60]
0000792ccedda193  vmovaps xmm7, [rsp+0x70]
0000792ccedda199  vmovaps xmm8, [rsp+0x80]
0000792ccedda1a2  vmovaps xmm9, [rsp+0x90]
0000792ccedda1ab  vmovaps xmm10, [rsp+0xA0]
0000792ccedda1b4  vmovaps xmm11, [rsp+0xB0]
0000792ccedda1bd  vmovaps xmm12, [rsp+0xC0]
0000792ccedda1c6  vmovaps xmm13, [rsp+0xD0]
0000792ccedda1cf  vmovaps xmm15, [rsp+0xE0]
0000792ccedda1d8  add rsp, 0xF0
0000792ccedda1df  pop r11
0000792ccedda1e1  pop r10
0000792ccedda1e3  pop r9
0000792ccedda1e5  pop r8
0000792ccedda1e7  pop rsi
0000792ccedda1e8  pop rdi
0000792ccedda1e9  pop rdx
0000792ccedda1ea  pop rcx
0000792ccedda1eb  pop rax
0000792ccedda1ec  add rsp, 0x08
0000792ccedda1f0  jmp 0x0000792CCEDD6400
0000792ccedda1f5  sub rsp, 0x08
0000792ccedda1f9  push rax
0000792ccedda1fa  push rcx
0000792ccedda1fb  push rdx
0000792ccedda1fc  push rdi
0000792ccedda1fd  push rsi
0000792ccedda1fe  push r8
0000792ccedda200  push r9
0000792ccedda202  push r10
0000792ccedda204  push r11
0000792ccedda206  sub rsp, 0xF0
0000792ccedda20d  vmovaps [rsp], xmm0
0000792ccedda212  vmovaps [rsp+0x10], xmm2
0000792ccedda218  vmovaps [rsp+0x20], xmm3
0000792ccedda21e  vmovaps [rsp+0x30], xmm4
0000792ccedda224  vmovaps [rsp+0x40], xmm5
0000792ccedda22a  vmovaps [rsp+0x50], xmm6
0000792ccedda230  vmovaps [rsp+0x60], xmm7
0000792ccedda236  vmovaps [rsp+0x70], xmm8
0000792ccedda23c  vmovaps [rsp+0x80], xmm9
0000792ccedda245  vmovaps [rsp+0x90], xmm10
0000792ccedda24e  vmovaps [rsp+0xA0], xmm11
0000792ccedda257  vmovaps [rsp+0xB0], xmm12
0000792ccedda260  vmovaps [rsp+0xC0], xmm13
0000792ccedda269  vmovaps [rsp+0xD0], xmm14
0000792ccedda272  vmovaps [rsp+0xE0], xmm15
0000792ccedda27b  sub rsp, 0x30
0000792ccedda27f  movaps [rsp], xmm1
0000792ccedda283  movaps [rsp+0x10], xmm13
0000792ccedda289  movaps [rsp+0x20], xmm9
0000792ccedda28f  lea rdi, [rsp]
0000792ccedda293  mov esi, 0x00
0000792ccedda298  mov rax, 0x5AEE2D541530
0000792ccedda2a2  call rax
0000792ccedda2a4  movaps xmm1, [rsp]
0000792ccedda2a8  add rsp, 0x30
0000792ccedda2ac  vmovaps xmm0, [rsp]
0000792ccedda2b1  vmovaps xmm2, [rsp+0x10]
0000792ccedda2b7  vmovaps xmm3, [rsp+0x20]
0000792ccedda2bd  vmovaps xmm4, [rsp+0x30]
0000792ccedda2c3  vmovaps xmm5, [rsp+0x40]
0000792ccedda2c9  vmovaps xmm6, [rsp+0x50]
0000792ccedda2cf  vmovaps xmm7, [rsp+0x60]
0000792ccedda2d5  vmovaps xmm8, [rsp+0x70]
0000792ccedda2db  vmovaps xmm9, [rsp+0x80]
0000792ccedda2e4  vmovaps xmm10, [rsp+0x90]
0000792ccedda2ed  vmovaps xmm11, [rsp+0xA0]
0000792ccedda2f6  vmovaps xmm12, [rsp+0xB0]
0000792ccedda2ff  vmovaps xmm13, [rsp+0xC0]
0000792ccedda308  vmovaps xmm14, [rsp+0xD0]
0000792ccedda311  vmovaps xmm15, [rsp+0xE0]
0000792ccedda31a  add rsp, 0xF0
0000792ccedda321  pop r11
0000792ccedda323  pop r10
0000792ccedda325  pop r9
0000792ccedda327  pop r8
0000792ccedda329  pop rsi
0000792ccedda32a  pop rdi
0000792ccedda32b  pop rdx
0000792ccedda32c  pop rcx
0000792ccedda32d  pop rax
0000792ccedda32e  add rsp, 0x08
0000792ccedda332  jmp 0x0000792CCEDD641A
0000792ccedda337  sub rsp, 0x08
0000792ccedda33b  push rax
0000792ccedda33c  push rcx
0000792ccedda33d  push rdx
0000792ccedda33e  push rdi
0000792ccedda33f  push rsi
0000792ccedda340  push r8
0000792ccedda342  push r9
0000792ccedda344  push r10
0000792ccedda346  push r11
0000792ccedda348  sub rsp, 0xF0
0000792ccedda34f  vmovaps [rsp], xmm0
0000792ccedda354  vmovaps [rsp+0x10], xmm1
0000792ccedda35a  vmovaps [rsp+0x20], xmm2
0000792ccedda360  vmovaps [rsp+0x30], xmm3
0000792ccedda366  vmovaps [rsp+0x40], xmm4
0000792ccedda36c  vmovaps [rsp+0x50], xmm5
0000792ccedda372  vmovaps [rsp+0x60], xmm6
0000792ccedda378  vmovaps [rsp+0x70], xmm7
0000792ccedda37e  vmovaps [rsp+0x80], xmm8
0000792ccedda387  vmovaps [rsp+0x90], xmm9
0000792ccedda390  vmovaps [rsp+0xA0], xmm10
0000792ccedda399  vmovaps [rsp+0xB0], xmm11
0000792ccedda3a2  vmovaps [rsp+0xC0], xmm13
0000792ccedda3ab  vmovaps [rsp+0xD0], xmm14
0000792ccedda3b4  vmovaps [rsp+0xE0], xmm15
0000792ccedda3bd  sub rsp, 0x30
0000792ccedda3c1  movaps [rsp], xmm12
0000792ccedda3c6  movaps [rsp+0x10], xmm7
0000792ccedda3cb  movaps [rsp+0x20], xmm13
0000792ccedda3d1  lea rdi, [rsp]
0000792ccedda3d5  mov esi, 0x00
0000792ccedda3da  mov rax, 0x5AEE2D541530
0000792ccedda3e4  call rax
0000792ccedda3e6  movaps xmm12, [rsp]
0000792ccedda3eb  add rsp, 0x30
0000792ccedda3ef  vmovaps xmm0, [rsp]
0000792ccedda3f4  vmovaps xmm1, [rsp+0x10]
0000792ccedda3fa  vmovaps xmm2, [rsp+0x20]
0000792ccedda400  vmovaps xmm3, [rsp+0x30]
0000792ccedda406  vmovaps xmm4, [rsp+0x40]
0000792ccedda40c  vmovaps xmm5, [rsp+0x50]
0000792ccedda412  vmovaps xmm6, [rsp+0x60]
0000792ccedda418  vmovaps xmm7, [rsp+0x70]
0000792ccedda41e  vmovaps xmm8, [rsp+0x80]
0000792ccedda427  vmovaps xmm9, [rsp+0x90]
0000792ccedda430  vmovaps xmm10, [rsp+0xA0]
0000792ccedda439  vmovaps xmm11, [rsp+0xB0]
0000792ccedda442  vmovaps xmm13, [rsp+0xC0]
0000792ccedda44b  vmovaps xmm14, [rsp+0xD0]
0000792ccedda454  vmovaps xmm15, [rsp+0xE0]
0000792ccedda45d  add rsp, 0xF0
0000792ccedda464  pop r11
0000792ccedda466  pop r10
0000792ccedda468  pop r9
0000792ccedda46a  pop r8
0000792ccedda46c  pop rsi
0000792ccedda46d  pop rdi
0000792ccedda46e  pop rdx
0000792ccedda46f  pop rcx
0000792ccedda470  pop rax
0000792ccedda471  add rsp, 0x08
0000792ccedda475  jmp 0x0000792CCEDD6441
0000792ccedda47a  sub rsp, 0x08
0000792ccedda47e  push rax
0000792ccedda47f  push rcx
0000792ccedda480  push rdx
0000792ccedda481  push rdi
0000792ccedda482  push rsi
0000792ccedda483  push r8
0000792ccedda485  push r9
0000792ccedda487  push r10
0000792ccedda489  push r11
0000792ccedda48b  sub rsp, 0xF0
0000792ccedda492  vmovaps [rsp], xmm0
0000792ccedda497  vmovaps [rsp+0x10], xmm1
0000792ccedda49d  vmovaps [rsp+0x20], xmm2
0000792ccedda4a3  vmovaps [rsp+0x30], xmm3
0000792ccedda4a9  vmovaps [rsp+0x40], xmm4
0000792ccedda4af  vmovaps [rsp+0x50], xmm5
0000792ccedda4b5  vmovaps [rsp+0x60], xmm6
0000792ccedda4bb  vmovaps [rsp+0x70], xmm7
0000792ccedda4c1  vmovaps [rsp+0x80], xmm8
0000792ccedda4ca  vmovaps [rsp+0x90], xmm9
0000792ccedda4d3  vmovaps [rsp+0xA0], xmm10
0000792ccedda4dc  vmovaps [rsp+0xB0], xmm11
0000792ccedda4e5  vmovaps [rsp+0xC0], xmm12
0000792ccedda4ee  vmovaps [rsp+0xD0], xmm14
0000792ccedda4f7  vmovaps [rsp+0xE0], xmm15
0000792ccedda500  sub rsp, 0x30
0000792ccedda504  movaps [rsp], xmm13
0000792ccedda509  movaps [rsp+0x10], xmm15
0000792ccedda50f  movaps [rsp+0x20], xmm8
0000792ccedda515  lea rdi, [rsp]
0000792ccedda519  mov esi, 0x00
0000792ccedda51e  mov rax, 0x5AEE2D541530
0000792ccedda528  call rax
0000792ccedda52a  movaps xmm13, [rsp]
0000792ccedda52f  add rsp, 0x30
0000792ccedda533  vmovaps xmm0, [rsp]
0000792ccedda538  vmovaps xmm1, [rsp+0x10]
0000792ccedda53e  vmovaps xmm2, [rsp+0x20]
0000792ccedda544  vmovaps xmm3, [rsp+0x30]
0000792ccedda54a  vmovaps xmm4, [rsp+0x40]
0000792ccedda550  vmovaps xmm5, [rsp+0x50]
0000792ccedda556  vmovaps xmm6, [rsp+0x60]
0000792ccedda55c  vmovaps xmm7, [rsp+0x70]
0000792ccedda562  vmovaps xmm8, [rsp+0x80]
0000792ccedda56b  vmovaps xmm9, [rsp+0x90]
0000792ccedda574  vmovaps xmm10, [rsp+0xA0]
0000792ccedda57d  vmovaps xmm11, [rsp+0xB0]
0000792ccedda586  vmovaps xmm12, [rsp+0xC0]
0000792ccedda58f  vmovaps xmm14, [rsp+0xD0]
0000792ccedda598  vmovaps xmm15, [rsp+0xE0]
0000792ccedda5a1  add rsp, 0xF0
0000792ccedda5a8  pop r11
0000792ccedda5aa  pop r10
0000792ccedda5ac  pop r9
0000792ccedda5ae  pop r8
0000792ccedda5b0  pop rsi
0000792ccedda5b1  pop rdi
0000792ccedda5b2  pop rdx
0000792ccedda5b3  pop rcx
0000792ccedda5b4  pop rax
0000792ccedda5b5  add rsp, 0x08
0000792ccedda5b9  jmp 0x0000792CCEDD645C
0000792ccedda5be  sub rsp, 0x08
0000792ccedda5c2  push rax
0000792ccedda5c3  push rcx
0000792ccedda5c4  push rdx
0000792ccedda5c5  push rdi
0000792ccedda5c6  push rsi
0000792ccedda5c7  push r8
0000792ccedda5c9  push r9
0000792ccedda5cb  push r10
0000792ccedda5cd  push r11
0000792ccedda5cf  sub rsp, 0xF0
0000792ccedda5d6  vmovaps [rsp], xmm0
0000792ccedda5db  vmovaps [rsp+0x10], xmm1
0000792ccedda5e1  vmovaps [rsp+0x20], xmm2
0000792ccedda5e7  vmovaps [rsp+0x30], xmm3
0000792ccedda5ed  vmovaps [rsp+0x40], xmm4
0000792ccedda5f3  vmovaps [rsp+0x50], xmm5
0000792ccedda5f9  vmovaps [rsp+0x60], xmm6
0000792ccedda5ff  vmovaps [rsp+0x70], xmm7
0000792ccedda605  vmovaps [rsp+0x80], xmm9
0000792ccedda60e  vmovaps [rsp+0x90], xmm10
0000792ccedda617  vmovaps [rsp+0xA0], xmm11
0000792ccedda620  vmovaps [rsp+0xB0], xmm12
0000792ccedda629  vmovaps [rsp+0xC0], xmm13
0000792ccedda632  vmovaps [rsp+0xD0], xmm14
0000792ccedda63b  vmovaps [rsp+0xE0], xmm15
0000792ccedda644  sub rsp, 0x30
0000792ccedda648  movaps [rsp], xmm8
0000792ccedda64d  movaps [rsp+0x10], xmm15
0000792ccedda653  movaps [rsp+0x20], xmm9
0000792ccedda659  lea rdi, [rsp]
0000792ccedda65d  mov esi, 0x00
0000792ccedda662  mov rax, 0x5AEE2D541530
0000792ccedda66c  call rax
0000792ccedda66e  movaps xmm8, [rsp]
0000792ccedda673  add rsp, 0x30
0000792ccedda677  vmovaps xmm0, [rsp]
0000792ccedda67c  vmovaps xmm1, [rsp+0x10]
0000792ccedda682  vmovaps xmm2, [rsp+0x20]
0000792ccedda688  vmovaps xmm3, [rsp+0x30]
0000792ccedda68e  vmovaps xmm4, [rsp+0x40]
0000792ccedda694  vmovaps xmm5, [rsp+0x50]
0000792ccedda69a  vmovaps xmm6, [rsp+0x60]
0000792ccedda6a0  vmovaps xmm7, [rsp+0x70]
0000792ccedda6a6  vmovaps xmm9, [rsp+0x80]
0000792ccedda6af  vmovaps xmm10, [rsp+0x90]
0000792ccedda6b8  vmovaps xmm11, [rsp+0xA0]
0000792ccedda6c1  vmovaps xmm12, [rsp+0xB0]
0000792ccedda6ca  vmovaps xmm13, [rsp+0xC0]
0000792ccedda6d3  vmovaps xmm14, [rsp+0xD0]
0000792ccedda6dc  vmovaps xmm15, [rsp+0xE0]
0000792ccedda6e5  add rsp, 0xF0
0000792ccedda6ec  pop r11
0000792ccedda6ee  pop r10
0000792ccedda6f0  pop r9
0000792ccedda6f2  pop r8
0000792ccedda6f4  pop rsi
0000792ccedda6f5  pop rdi
0000792ccedda6f6  pop rdx
0000792ccedda6f7  pop rcx
0000792ccedda6f8  pop rax
0000792ccedda6f9  add rsp, 0x08
0000792ccedda6fd  jmp 0x0000792CCEDD648A
0000792ccedda702  sub rsp, 0x08
0000792ccedda706  push rax
0000792ccedda707  push rcx
0000792ccedda708  push rdx
0000792ccedda709  push rdi
0000792ccedda70a  push rsi
0000792ccedda70b  push r8
0000792ccedda70d  push r9
0000792ccedda70f  push r10
0000792ccedda711  push r11
0000792ccedda713  sub rsp, 0xF0
0000792ccedda71a  vmovaps [rsp], xmm0
0000792ccedda71f  vmovaps [rsp+0x10], xmm1
0000792ccedda725  vmovaps [rsp+0x20], xmm2
0000792ccedda72b  vmovaps [rsp+0x30], xmm3
0000792ccedda731  vmovaps [rsp+0x40], xmm4
0000792ccedda737  vmovaps [rsp+0x50], xmm5
0000792ccedda73d  vmovaps [rsp+0x60], xmm6
0000792ccedda743  vmovaps [rsp+0x70], xmm7
0000792ccedda749  vmovaps [rsp+0x80], xmm8
0000792ccedda752  vmovaps [rsp+0x90], xmm9
0000792ccedda75b  vmovaps [rsp+0xA0], xmm10
0000792ccedda764  vmovaps [rsp+0xB0], xmm11
0000792ccedda76d  vmovaps [rsp+0xC0], xmm12
0000792ccedda776  vmovaps [rsp+0xD0], xmm13
0000792ccedda77f  vmovaps [rsp+0xE0], xmm14
0000792ccedda788  sub rsp, 0x30
0000792ccedda78c  movaps [rsp], xmm15
0000792ccedda791  movaps [rsp+0x10], xmm11
0000792ccedda797  movaps [rsp+0x20], xmm6
0000792ccedda79c  lea rdi, [rsp]
0000792ccedda7a0  mov esi, 0x00
0000792ccedda7a5  mov rax, 0x5AEE2D541530
0000792ccedda7af  call rax
0000792ccedda7b1  movaps xmm15, [rsp]
0000792ccedda7b6  add rsp, 0x30
0000792ccedda7ba  vmovaps xmm0, [rsp]
0000792ccedda7bf  vmovaps xmm1, [rsp+0x10]
0000792ccedda7c5  vmovaps xmm2, [rsp+0x20]
0000792ccedda7cb  vmovaps xmm3, [rsp+0x30]
0000792ccedda7d1  vmovaps xmm4, [rsp+0x40]
0000792ccedda7d7  vmovaps xmm5, [rsp+0x50]
0000792ccedda7dd  vmovaps xmm6, [rsp+0x60]
0000792ccedda7e3  vmovaps xmm7, [rsp+0x70]
0000792ccedda7e9  vmovaps xmm8, [rsp+0x80]
0000792ccedda7f2  vmovaps xmm9, [rsp+0x90]
0000792ccedda7fb  vmovaps xmm10, [rsp+0xA0]
0000792ccedda804  vmovaps xmm11, [rsp+0xB0]
0000792ccedda80d  vmovaps xmm12, [rsp+0xC0]
0000792ccedda816  vmovaps xmm13, [rsp+0xD0]
0000792ccedda81f  vmovaps xmm14, [rsp+0xE0]
0000792ccedda828  add rsp, 0xF0
0000792ccedda82f  pop r11
0000792ccedda831  pop r10
0000792ccedda833  pop r9
0000792ccedda835  pop r8
0000792ccedda837  pop rsi
0000792ccedda838  pop rdi
0000792ccedda839  pop rdx
0000792ccedda83a  pop rcx
0000792ccedda83b  pop rax
0000792ccedda83c  add rsp, 0x08
0000792ccedda840  jmp 0x0000792CCEDD64A5
0000792ccedda845  sub rsp, 0x08
0000792ccedda849  push rax
0000792ccedda84a  push rcx
0000792ccedda84b  push rdx
0000792ccedda84c  push rdi
0000792ccedda84d  push rsi
0000792ccedda84e  push r8
0000792ccedda850  push r9
0000792ccedda852  push r10
0000792ccedda854  push r11
0000792ccedda856  sub rsp, 0xF0
0000792ccedda85d  vmovaps [rsp], xmm0
0000792ccedda862  vmovaps [rsp+0x10], xmm1
0000792ccedda868  vmovaps [rsp+0x20], xmm2
0000792ccedda86e  vmovaps [rsp+0x30], xmm3
0000792ccedda874  vmovaps [rsp+0x40], xmm4
0000792ccedda87a  vmovaps [rsp+0x50], xmm5
0000792ccedda880  vmovaps [rsp+0x60], xmm6
0000792ccedda886  vmovaps [rsp+0x70], xmm8
0000792ccedda88c  vmovaps [rsp+0x80], xmm9
0000792ccedda895  vmovaps [rsp+0x90], xmm10
0000792ccedda89e  vmovaps [rsp+0xA0], xmm11
0000792ccedda8a7  vmovaps [rsp+0xB0], xmm12
0000792ccedda8b0  vmovaps [rsp+0xC0], xmm13
0000792ccedda8b9  vmovaps [rsp+0xD0], xmm14
0000792ccedda8c2  vmovaps [rsp+0xE0], xmm15
0000792ccedda8cb  sub rsp, 0x30
0000792ccedda8cf  movaps [rsp], xmm7
0000792ccedda8d3  movaps [rsp+0x10], xmm11
0000792ccedda8d9  movaps [rsp+0x20], xmm9
0000792ccedda8df  lea rdi, [rsp]
0000792ccedda8e3  mov esi, 0x00
0000792ccedda8e8  mov rax, 0x5AEE2D541530
0000792ccedda8f2  call rax
0000792ccedda8f4  movaps xmm7, [rsp]
0000792ccedda8f8  add rsp, 0x30
0000792ccedda8fc  vmovaps xmm0, [rsp]
0000792ccedda901  vmovaps xmm1, [rsp+0x10]
0000792ccedda907  vmovaps xmm2, [rsp+0x20]
0000792ccedda90d  vmovaps xmm3, [rsp+0x30]
0000792ccedda913  vmovaps xmm4, [rsp+0x40]
0000792ccedda919  vmovaps xmm5, [rsp+0x50]
0000792ccedda91f  vmovaps xmm6, [rsp+0x60]
0000792ccedda925  vmovaps xmm8, [rsp+0x70]
0000792ccedda92b  vmovaps xmm9, [rsp+0x80]
0000792ccedda934  vmovaps xmm10, [rsp+0x90]
0000792ccedda93d  vmovaps xmm11, [rsp+0xA0]
0000792ccedda946  vmovaps xmm12, [rsp+0xB0]
0000792ccedda94f  vmovaps xmm13, [rsp+0xC0]
0000792ccedda958  vmovaps xmm14, [rsp+0xD0]
0000792ccedda961  vmovaps xmm15, [rsp+0xE0]
0000792ccedda96a  add rsp, 0xF0
0000792ccedda971  pop r11
0000792ccedda973  pop r10
0000792ccedda975  pop r9
0000792ccedda977  pop r8
0000792ccedda979  pop rsi
0000792ccedda97a  pop rdi
0000792ccedda97b  pop rdx
0000792ccedda97c  pop rcx
0000792ccedda97d  pop rax
0000792ccedda97e  add rsp, 0x08
0000792ccedda982  jmp 0x0000792CCEDD64D2
0000792ccedda987  sub rsp, 0x08
0000792ccedda98b  push rax
0000792ccedda98c  push rcx
0000792ccedda98d  push rdx
0000792ccedda98e  push rdi
0000792ccedda98f  push rsi
0000792ccedda990  push r8
0000792ccedda992  push r9
0000792ccedda994  push r10
0000792ccedda996  push r11
0000792ccedda998  sub rsp, 0xF0
0000792ccedda99f  vmovaps [rsp], xmm0
0000792ccedda9a4  vmovaps [rsp+0x10], xmm1
0000792ccedda9aa  vmovaps [rsp+0x20], xmm2
0000792ccedda9b0  vmovaps [rsp+0x30], xmm3
0000792ccedda9b6  vmovaps [rsp+0x40], xmm4
0000792ccedda9bc  vmovaps [rsp+0x50], xmm5
0000792ccedda9c2  vmovaps [rsp+0x60], xmm6
0000792ccedda9c8  vmovaps [rsp+0x70], xmm7
0000792ccedda9ce  vmovaps [rsp+0x80], xmm8
0000792ccedda9d7  vmovaps [rsp+0x90], xmm9
0000792ccedda9e0  vmovaps [rsp+0xA0], xmm10
0000792ccedda9e9  vmovaps [rsp+0xB0], xmm12
0000792ccedda9f2  vmovaps [rsp+0xC0], xmm13
0000792ccedda9fb  vmovaps [rsp+0xD0], xmm14
0000792cceddaa04  vmovaps [rsp+0xE0], xmm15
0000792cceddaa0d  sub rsp, 0x30
0000792cceddaa11  movaps [rsp], xmm11
0000792cceddaa16  movaps [rsp+0x10], xmm10
0000792cceddaa1c  movaps [rsp+0x20], xmm14
0000792cceddaa22  lea rdi, [rsp]
0000792cceddaa26  mov esi, 0x00
0000792cceddaa2b  mov rax, 0x5AEE2D541530
0000792cceddaa35  call rax
0000792cceddaa37  movaps xmm11, [rsp]
0000792cceddaa3c  add rsp, 0x30
0000792cceddaa40  vmovaps xmm0, [rsp]
0000792cceddaa45  vmovaps xmm1, [rsp+0x10]
0000792cceddaa4b  vmovaps xmm2, [rsp+0x20]
0000792cceddaa51  vmovaps xmm3, [rsp+0x30]
0000792cceddaa57  vmovaps xmm4, [rsp+0x40]
0000792cceddaa5d  vmovaps xmm5, [rsp+0x50]
0000792cceddaa63  vmovaps xmm6, [rsp+0x60]
0000792cceddaa69  vmovaps xmm7, [rsp+0x70]
0000792cceddaa6f  vmovaps xmm8, [rsp+0x80]
0000792cceddaa78  vmovaps xmm9, [rsp+0x90]
0000792cceddaa81  vmovaps xmm10, [rsp+0xA0]
0000792cceddaa8a  vmovaps xmm12, [rsp+0xB0]
0000792cceddaa93  vmovaps xmm13, [rsp+0xC0]
0000792cceddaa9c  vmovaps xmm14, [rsp+0xD0]
0000792cceddaaa5  vmovaps xmm15, [rsp+0xE0]
0000792cceddaaae  add rsp, 0xF0
0000792cceddaab5  pop r11
0000792cceddaab7  pop r10
0000792cceddaab9  pop r9
0000792cceddaabb  pop r8
0000792cceddaabd  pop rsi
0000792cceddaabe  pop rdi
0000792cceddaabf  pop rdx
0000792cceddaac0  pop rcx
0000792cceddaac1  pop rax
0000792cceddaac2  add rsp, 0x08
0000792cceddaac6  jmp 0x0000792CCEDD64ED
0000792cceddaacb  call 0x0000792CCECE45A0
0000792cceddaad0  jmp 0x0000792CCEDD64F7
0000792cceddaad5  sub rsp, 0x08
0000792cceddaad9  push rax
0000792cceddaada  push rcx
0000792cceddaadb  push rdx
0000792cceddaadc  push rdi
0000792cceddaadd  push rsi
0000792cceddaade  push r8
0000792cceddaae0  push r9
0000792cceddaae2  push r10
0000792cceddaae4  push r11
0000792cceddaae6  sub rsp, 0xF0
0000792cceddaaed  vmovaps [rsp], xmm0
0000792cceddaaf2  vmovaps [rsp+0x10], xmm1
0000792cceddaaf8  vmovaps [rsp+0x20], xmm2
0000792cceddaafe  vmovaps [rsp+0x30], xmm3
0000792cceddab04  vmovaps [rsp+0x40], xmm4
0000792cceddab0a  vmovaps [rsp+0x50], xmm5
0000792cceddab10  vmovaps [rsp+0x60], xmm6
0000792cceddab16  vmovaps [rsp+0x70], xmm7
0000792cceddab1c  vmovaps [rsp+0x80], xmm8
0000792cceddab25  vmovaps [rsp+0x90], xmm9
0000792cceddab2e  vmovaps [rsp+0xA0], xmm11
0000792cceddab37  vmovaps [rsp+0xB0], xmm12
0000792cceddab40  vmovaps [rsp+0xC0], xmm13
0000792cceddab49  vmovaps [rsp+0xD0], xmm14
0000792cceddab52  vmovaps [rsp+0xE0], xmm15
0000792cceddab5b  sub rsp, 0x30
0000792cceddab5f  movaps [rsp], xmm10
0000792cceddab64  movaps [rsp+0x10], xmm1
0000792cceddab69  movaps [rsp+0x20], xmm12
0000792cceddab6f  lea rdi, [rsp]
0000792cceddab73  mov esi, 0x00
0000792cceddab78  mov rax, 0x5AEE2D541530
0000792cceddab82  call rax
0000792cceddab84  movaps xmm10, [rsp]
0000792cceddab89  add rsp, 0x30
0000792cceddab8d  vmovaps xmm0, [rsp]
0000792cceddab92  vmovaps xmm1, [rsp+0x10]
0000792cceddab98  vmovaps xmm2, [rsp+0x20]
0000792cceddab9e  vmovaps xmm3, [rsp+0x30]
0000792cceddaba4  vmovaps xmm4, [rsp+0x40]
0000792cceddabaa  vmovaps xmm5, [rsp+0x50]
0000792cceddabb0  vmovaps xmm6, [rsp+0x60]
0000792cceddabb6  vmovaps xmm7, [rsp+0x70]
0000792cceddabbc  vmovaps xmm8, [rsp+0x80]
0000792cceddabc5  vmovaps xmm9, [rsp+0x90]
0000792cceddabce  vmovaps xmm11, [rsp+0xA0]
0000792cceddabd7  vmovaps xmm12, [rsp+0xB0]
0000792cceddabe0  vmovaps xmm13, [rsp+0xC0]
0000792cceddabe9  vmovaps xmm14, [rsp+0xD0]
0000792cceddabf2  vmovaps xmm15, [rsp+0xE0]
0000792cceddabfb  add rsp, 0xF0
0000792cceddac02  pop r11
0000792cceddac04  pop r10
0000792cceddac06  pop r9
0000792cceddac08  pop r8
0000792cceddac0a  pop rsi
0000792cceddac0b  pop rdi
0000792cceddac0c  pop rdx
0000792cceddac0d  pop rcx
0000792cceddac0e  pop rax
0000792cceddac0f  add rsp, 0x08
0000792cceddac13  jmp 0x0000792CCEDD651A
0000792cceddac18  sub rsp, 0x08
0000792cceddac1c  push rax
0000792cceddac1d  push rcx
0000792cceddac1e  push rdx
0000792cceddac1f  push rdi
0000792cceddac20  push rsi
0000792cceddac21  push r8
0000792cceddac23  push r9
0000792cceddac25  push r10
0000792cceddac27  push r11
0000792cceddac29  sub rsp, 0xF0
0000792cceddac30  vmovaps [rsp], xmm0
0000792cceddac35  vmovaps [rsp+0x10], xmm1
0000792cceddac3b  vmovaps [rsp+0x20], xmm2
0000792cceddac41  vmovaps [rsp+0x30], xmm3
0000792cceddac47  vmovaps [rsp+0x40], xmm4
0000792cceddac4d  vmovaps [rsp+0x50], xmm5
0000792cceddac53  vmovaps [rsp+0x60], xmm6
0000792cceddac59  vmovaps [rsp+0x70], xmm7
0000792cceddac5f  vmovaps [rsp+0x80], xmm8
0000792cceddac68  vmovaps [rsp+0x90], xmm9
0000792cceddac71  vmovaps [rsp+0xA0], xmm10
0000792cceddac7a  vmovaps [rsp+0xB0], xmm11
0000792cceddac83  vmovaps [rsp+0xC0], xmm13
0000792cceddac8c  vmovaps [rsp+0xD0], xmm14
0000792cceddac95  vmovaps [rsp+0xE0], xmm15
0000792cceddac9e  sub rsp, 0x30
0000792cceddaca2  movaps [rsp], xmm12
0000792cceddaca7  movaps [rsp+0x10], xmm14
0000792cceddacad  movaps [rsp+0x20], xmm1
0000792cceddacb2  lea rdi, [rsp]
0000792cceddacb6  mov esi, 0x00
0000792cceddacbb  mov rax, 0x5AEE2D541530
0000792cceddacc5  call rax
0000792cceddacc7  movaps xmm12, [rsp]
0000792cceddaccc  add rsp, 0x30
0000792cceddacd0  vmovaps xmm0, [rsp]
0000792cceddacd5  vmovaps xmm1, [rsp+0x10]
0000792cceddacdb  vmovaps xmm2, [rsp+0x20]
0000792cceddace1  vmovaps xmm3, [rsp+0x30]
0000792cceddace7  vmovaps xmm4, [rsp+0x40]
0000792cceddaced  vmovaps xmm5, [rsp+0x50]
0000792cceddacf3  vmovaps xmm6, [rsp+0x60]
0000792cceddacf9  vmovaps xmm7, [rsp+0x70]
0000792cceddacff  vmovaps xmm8, [rsp+0x80]
0000792cceddad08  vmovaps xmm9, [rsp+0x90]
0000792cceddad11  vmovaps xmm10, [rsp+0xA0]
0000792cceddad1a  vmovaps xmm11, [rsp+0xB0]
0000792cceddad23  vmovaps xmm13, [rsp+0xC0]
0000792cceddad2c  vmovaps xmm14, [rsp+0xD0]
0000792cceddad35  vmovaps xmm15, [rsp+0xE0]
0000792cceddad3e  add rsp, 0xF0
0000792cceddad45  pop r11
0000792cceddad47  pop r10
0000792cceddad49  pop r9
0000792cceddad4b  pop r8
0000792cceddad4d  pop rsi
0000792cceddad4e  pop rdi
0000792cceddad4f  pop rdx
0000792cceddad50  pop rcx
0000792cceddad51  pop rax
0000792cceddad52  add rsp, 0x08
0000792cceddad56  jmp 0x0000792CCEDD6549
0000792cceddad5b  sub rsp, 0x08
0000792cceddad5f  push rax
0000792cceddad60  push rcx
0000792cceddad61  push rdx
0000792cceddad62  push rdi
0000792cceddad63  push rsi
0000792cceddad64  push r8
0000792cceddad66  push r9
0000792cceddad68  push r10
0000792cceddad6a  push r11
0000792cceddad6c  sub rsp, 0xF0
0000792cceddad73  vmovaps [rsp], xmm0
0000792cceddad78  vmovaps [rsp+0x10], xmm1
0000792cceddad7e  vmovaps [rsp+0x20], xmm2
0000792cceddad84  vmovaps [rsp+0x30], xmm3
0000792cceddad8a  vmovaps [rsp+0x40], xmm4
0000792cceddad90  vmovaps [rsp+0x50], xmm5
0000792cceddad96  vmovaps [rsp+0x60], xmm6
0000792cceddad9c  vmovaps [rsp+0x70], xmm7
0000792cceddada2  vmovaps [rsp+0x80], xmm8
0000792cceddadab  vmovaps [rsp+0x90], xmm9
0000792cceddadb4  vmovaps [rsp+0xA0], xmm10
0000792cceddadbd  vmovaps [rsp+0xB0], xmm11
0000792cceddadc6  vmovaps [rsp+0xC0], xmm12
0000792cceddadcf  vmovaps [rsp+0xD0], xmm13
0000792cceddadd8  vmovaps [rsp+0xE0], xmm15
0000792cceddade1  sub rsp, 0x30
0000792cceddade5  movaps [rsp], xmm14
0000792cceddadea  movaps [rsp+0x10], xmm9
0000792cceddadf0  movaps [rsp+0x20], xmm1
0000792cceddadf5  lea rdi, [rsp]
0000792cceddadf9  mov esi, 0x00
0000792cceddadfe  mov rax, 0x5AEE2D541530
0000792cceddae08  call rax
0000792cceddae0a  movaps xmm14, [rsp]
0000792cceddae0f  add rsp, 0x30
0000792cceddae13  vmovaps xmm0, [rsp]
0000792cceddae18  vmovaps xmm1, [rsp+0x10]
0000792cceddae1e  vmovaps xmm2, [rsp+0x20]
0000792cceddae24  vmovaps xmm3, [rsp+0x30]
0000792cceddae2a  vmovaps xmm4, [rsp+0x40]
0000792cceddae30  vmovaps xmm5, [rsp+0x50]
0000792cceddae36  vmovaps xmm6, [rsp+0x60]
0000792cceddae3c  vmovaps xmm7, [rsp+0x70]
0000792cceddae42  vmovaps xmm8, [rsp+0x80]
0000792cceddae4b  vmovaps xmm9, [rsp+0x90]
0000792cceddae54  vmovaps xmm10, [rsp+0xA0]
0000792cceddae5d  vmovaps xmm11, [rsp+0xB0]
0000792cceddae66  vmovaps xmm12, [rsp+0xC0]
0000792cceddae6f  vmovaps xmm13, [rsp+0xD0]
0000792cceddae78  vmovaps xmm15, [rsp+0xE0]
0000792cceddae81  add rsp, 0xF0
0000792cceddae88  pop r11
0000792cceddae8a  pop r10
0000792cceddae8c  pop r9
0000792cceddae8e  pop r8
0000792cceddae90  pop rsi
0000792cceddae91  pop rdi
0000792cceddae92  pop rdx
0000792cceddae93  pop rcx
0000792cceddae94  pop rax
0000792cceddae95  add rsp, 0x08
0000792cceddae99  jmp 0x0000792CCEDD6578
0000792cceddae9e  sub rsp, 0x08
0000792cceddaea2  push rax
0000792cceddaea3  push rcx
0000792cceddaea4  push rdx
0000792cceddaea5  push rdi
0000792cceddaea6  push rsi
0000792cceddaea7  push r8
0000792cceddaea9  push r9
0000792cceddaeab  push r10
0000792cceddaead  push r11
0000792cceddaeaf  sub rsp, 0xF0
0000792cceddaeb6  vmovaps [rsp], xmm0
0000792cceddaebb  vmovaps [rsp+0x10], xmm2
0000792cceddaec1  vmovaps [rsp+0x20], xmm3
0000792cceddaec7  vmovaps [rsp+0x30], xmm4
0000792cceddaecd  vmovaps [rsp+0x40], xmm5
0000792cceddaed3  vmovaps [rsp+0x50], xmm6
0000792cceddaed9  vmovaps [rsp+0x60], xmm7
0000792cceddaedf  vmovaps [rsp+0x70], xmm8
0000792cceddaee5  vmovaps [rsp+0x80], xmm9
0000792cceddaeee  vmovaps [rsp+0x90], xmm10
0000792cceddaef7  vmovaps [rsp+0xA0], xmm11
0000792cceddaf00  vmovaps [rsp+0xB0], xmm12
0000792cceddaf09  vmovaps [rsp+0xC0], xmm13
0000792cceddaf12  vmovaps [rsp+0xD0], xmm14
0000792cceddaf1b  vmovaps [rsp+0xE0], xmm15
0000792cceddaf24  sub rsp, 0x30
0000792cceddaf28  movaps [rsp], xmm1
0000792cceddaf2c  movaps [rsp+0x10], xmm13
0000792cceddaf32  movaps [rsp+0x20], xmm8
0000792cceddaf38  lea rdi, [rsp]
0000792cceddaf3c  mov esi, 0x00
0000792cceddaf41  mov rax, 0x5AEE2D541530
0000792cceddaf4b  call rax
0000792cceddaf4d  movaps xmm1, [rsp]
0000792cceddaf51  add rsp, 0x30
0000792cceddaf55  vmovaps xmm0, [rsp]
0000792cceddaf5a  vmovaps xmm2, [rsp+0x10]
0000792cceddaf60  vmovaps xmm3, [rsp+0x20]
0000792cceddaf66  vmovaps xmm4, [rsp+0x30]
0000792cceddaf6c  vmovaps xmm5, [rsp+0x40]
0000792cceddaf72  vmovaps xmm6, [rsp+0x50]
0000792cceddaf78  vmovaps xmm7, [rsp+0x60]
0000792cceddaf7e  vmovaps xmm8, [rsp+0x70]
0000792cceddaf84  vmovaps xmm9, [rsp+0x80]
0000792cceddaf8d  vmovaps xmm10, [rsp+0x90]
0000792cceddaf96  vmovaps xmm11, [rsp+0xA0]
0000792cceddaf9f  vmovaps xmm12, [rsp+0xB0]
0000792cceddafa8  vmovaps xmm13, [rsp+0xC0]
0000792cceddafb1  vmovaps xmm14, [rsp+0xD0]
0000792cceddafba  vmovaps xmm15, [rsp+0xE0]
0000792cceddafc3  add rsp, 0xF0
0000792cceddafca  pop r11
0000792cceddafcc  pop r10
0000792cceddafce  pop r9
0000792cceddafd0  pop r8
0000792cceddafd2  pop rsi
0000792cceddafd3  pop rdi
0000792cceddafd4  pop rdx
0000792cceddafd5  pop rcx
0000792cceddafd6  pop rax
0000792cceddafd7  add rsp, 0x08
0000792cceddafdb  jmp 0x0000792CCEDD659A
0000792cceddafe0  call 0x0000792CCEC0C260
0000792cceddafe5  jmp 0x0000792CCEDD65A8
0000792cceddafea  call 0x0000792CCECDE950
0000792cceddafef  jmp 0x0000792CCEDD65B2
0000792cceddaff4  sub rsp, 0x08
0000792cceddaff8  push rax
0000792cceddaff9  push rcx
0000792cceddaffa  push rdx
0000792cceddaffb  push rdi
0000792cceddaffc  push rsi
0000792cceddaffd  push r8
0000792cceddafff  push r9
0000792cceddb001  push r10
0000792cceddb003  push r11
0000792cceddb005  sub rsp, 0xF0
0000792cceddb00c  vmovaps [rsp], xmm0
0000792cceddb011  vmovaps [rsp+0x10], xmm1
0000792cceddb017  vmovaps [rsp+0x20], xmm2
0000792cceddb01d  vmovaps [rsp+0x30], xmm3
0000792cceddb023  vmovaps [rsp+0x40], xmm4
0000792cceddb029  vmovaps [rsp+0x50], xmm5
0000792cceddb02f  vmovaps [rsp+0x60], xmm6
0000792cceddb035  vmovaps [rsp+0x70], xmm7
0000792cceddb03b  vmovaps [rsp+0x80], xmm9
0000792cceddb044  vmovaps [rsp+0x90], xmm10
0000792cceddb04d  vmovaps [rsp+0xA0], xmm11
0000792cceddb056  vmovaps [rsp+0xB0], xmm12
0000792cceddb05f  vmovaps [rsp+0xC0], xmm13
0000792cceddb068  vmovaps [rsp+0xD0], xmm14
0000792cceddb071  vmovaps [rsp+0xE0], xmm15
0000792cceddb07a  sub rsp, 0x30
0000792cceddb07e  movaps [rsp], xmm8
0000792cceddb083  movaps [rsp+0x10], xmm15
0000792cceddb089  movaps [rsp+0x20], xmm7
0000792cceddb08e  lea rdi, [rsp]
0000792cceddb092  mov esi, 0x00
0000792cceddb097  mov rax, 0x5AEE2D541530
0000792cceddb0a1  call rax
0000792cceddb0a3  movaps xmm8, [rsp]
0000792cceddb0a8  add rsp, 0x30
0000792cceddb0ac  vmovaps xmm0, [rsp]
0000792cceddb0b1  vmovaps xmm1, [rsp+0x10]
0000792cceddb0b7  vmovaps xmm2, [rsp+0x20]
0000792cceddb0bd  vmovaps xmm3, [rsp+0x30]
0000792cceddb0c3  vmovaps xmm4, [rsp+0x40]
0000792cceddb0c9  vmovaps xmm5, [rsp+0x50]
0000792cceddb0cf  vmovaps xmm6, [rsp+0x60]
0000792cceddb0d5  vmovaps xmm7, [rsp+0x70]
0000792cceddb0db  vmovaps xmm9, [rsp+0x80]
0000792cceddb0e4  vmovaps xmm10, [rsp+0x90]
0000792cceddb0ed  vmovaps xmm11, [rsp+0xA0]
0000792cceddb0f6  vmovaps xmm12, [rsp+0xB0]
0000792cceddb0ff  vmovaps xmm13, [rsp+0xC0]
0000792cceddb108  vmovaps xmm14, [rsp+0xD0]
0000792cceddb111  vmovaps xmm15, [rsp+0xE0]
0000792cceddb11a  add rsp, 0xF0
0000792cceddb121  pop r11
0000792cceddb123  pop r10
0000792cceddb125  pop r9
0000792cceddb127  pop r8
0000792cceddb129  pop rsi
0000792cceddb12a  pop rdi
0000792cceddb12b  pop rdx
0000792cceddb12c  pop rcx
0000792cceddb12d  pop rax
0000792cceddb12e  add rsp, 0x08
0000792cceddb132  jmp 0x0000792CCEDD65D4
0000792cceddb137  sub rsp, 0x08
0000792cceddb13b  push rax
0000792cceddb13c  push rcx
0000792cceddb13d  push rdx
0000792cceddb13e  push rdi
0000792cceddb13f  push rsi
0000792cceddb140  push r8
0000792cceddb142  push r9
0000792cceddb144  push r10
0000792cceddb146  push r11
0000792cceddb148  sub rsp, 0xF0
0000792cceddb14f  vmovaps [rsp], xmm0
0000792cceddb154  vmovaps [rsp+0x10], xmm1
0000792cceddb15a  vmovaps [rsp+0x20], xmm2
0000792cceddb160  vmovaps [rsp+0x30], xmm3
0000792cceddb166  vmovaps [rsp+0x40], xmm4
0000792cceddb16c  vmovaps [rsp+0x50], xmm5
0000792cceddb172  vmovaps [rsp+0x60], xmm6
0000792cceddb178  vmovaps [rsp+0x70], xmm8
0000792cceddb17e  vmovaps [rsp+0x80], xmm9
0000792cceddb187  vmovaps [rsp+0x90], xmm10
0000792cceddb190  vmovaps [rsp+0xA0], xmm11
0000792cceddb199  vmovaps [rsp+0xB0], xmm12
0000792cceddb1a2  vmovaps [rsp+0xC0], xmm13
0000792cceddb1ab  vmovaps [rsp+0xD0], xmm14
0000792cceddb1b4  vmovaps [rsp+0xE0], xmm15
0000792cceddb1bd  sub rsp, 0x30
0000792cceddb1c1  movaps [rsp], xmm7
0000792cceddb1c5  movaps [rsp+0x10], xmm9
0000792cceddb1cb  movaps [rsp+0x20], xmm15
0000792cceddb1d1  lea rdi, [rsp]
0000792cceddb1d5  mov esi, 0x00
0000792cceddb1da  mov rax, 0x5AEE2D541530
0000792cceddb1e4  call rax
0000792cceddb1e6  movaps xmm7, [rsp]
0000792cceddb1ea  add rsp, 0x30
0000792cceddb1ee  vmovaps xmm0, [rsp]
0000792cceddb1f3  vmovaps xmm1, [rsp+0x10]
0000792cceddb1f9  vmovaps xmm2, [rsp+0x20]
0000792cceddb1ff  vmovaps xmm3, [rsp+0x30]
0000792cceddb205  vmovaps xmm4, [rsp+0x40]
0000792cceddb20b  vmovaps xmm5, [rsp+0x50]
0000792cceddb211  vmovaps xmm6, [rsp+0x60]
0000792cceddb217  vmovaps xmm8, [rsp+0x70]
0000792cceddb21d  vmovaps xmm9, [rsp+0x80]
0000792cceddb226  vmovaps xmm10, [rsp+0x90]
0000792cceddb22f  vmovaps xmm11, [rsp+0xA0]
0000792cceddb238  vmovaps xmm12, [rsp+0xB0]
0000792cceddb241  vmovaps xmm13, [rsp+0xC0]
0000792cceddb24a  vmovaps xmm14, [rsp+0xD0]
0000792cceddb253  vmovaps xmm15, [rsp+0xE0]
0000792cceddb25c  add rsp, 0xF0
0000792cceddb263  pop r11
0000792cceddb265  pop r10
0000792cceddb267  pop r9
0000792cceddb269  pop r8
0000792cceddb26b  pop rsi
0000792cceddb26c  pop rdi
0000792cceddb26d  pop rdx
0000792cceddb26e  pop rcx
0000792cceddb26f  pop rax
0000792cceddb270  add rsp, 0x08
0000792cceddb274  jmp 0x0000792CCEDD6601
0000792cceddb279  sub rsp, 0x08
0000792cceddb27d  push rax
0000792cceddb27e  push rcx
0000792cceddb27f  push rdx
0000792cceddb280  push rdi
0000792cceddb281  push rsi
0000792cceddb282  push r8
0000792cceddb284  push r9
0000792cceddb286  push r10
0000792cceddb288  push r11
0000792cceddb28a  sub rsp, 0xF0
0000792cceddb291  vmovaps [rsp], xmm0
0000792cceddb296  vmovaps [rsp+0x10], xmm1
0000792cceddb29c  vmovaps [rsp+0x20], xmm2
0000792cceddb2a2  vmovaps [rsp+0x30], xmm3
0000792cceddb2a8  vmovaps [rsp+0x40], xmm4
0000792cceddb2ae  vmovaps [rsp+0x50], xmm5
0000792cceddb2b4  vmovaps [rsp+0x60], xmm6
0000792cceddb2ba  vmovaps [rsp+0x70], xmm7
0000792cceddb2c0  vmovaps [rsp+0x80], xmm8
0000792cceddb2c9  vmovaps [rsp+0x90], xmm10
0000792cceddb2d2  vmovaps [rsp+0xA0], xmm11
0000792cceddb2db  vmovaps [rsp+0xB0], xmm12
0000792cceddb2e4  vmovaps [rsp+0xC0], xmm13
0000792cceddb2ed  vmovaps [rsp+0xD0], xmm14
0000792cceddb2f6  vmovaps [rsp+0xE0], xmm15
0000792cceddb2ff  sub rsp, 0x30
0000792cceddb303  movaps [rsp], xmm9
0000792cceddb308  movaps [rsp+0x10], xmm13
0000792cceddb30e  movaps [rsp+0x20], xmm15
0000792cceddb314  lea rdi, [rsp]
0000792cceddb318  mov esi, 0x00
0000792cceddb31d  mov rax, 0x5AEE2D541530
0000792cceddb327  call rax
0000792cceddb329  movaps xmm9, [rsp]
0000792cceddb32e  add rsp, 0x30
0000792cceddb332  vmovaps xmm0, [rsp]
0000792cceddb337  vmovaps xmm1, [rsp+0x10]
0000792cceddb33d  vmovaps xmm2, [rsp+0x20]
0000792cceddb343  vmovaps xmm3, [rsp+0x30]
0000792cceddb349  vmovaps xmm4, [rsp+0x40]
0000792cceddb34f  vmovaps xmm5, [rsp+0x50]
0000792cceddb355  vmovaps xmm6, [rsp+0x60]
0000792cceddb35b  vmovaps xmm7, [rsp+0x70]
0000792cceddb361  vmovaps xmm8, [rsp+0x80]
0000792cceddb36a  vmovaps xmm10, [rsp+0x90]
0000792cceddb373  vmovaps xmm11, [rsp+0xA0]
0000792cceddb37c  vmovaps xmm12, [rsp+0xB0]
0000792cceddb385  vmovaps xmm13, [rsp+0xC0]
0000792cceddb38e  vmovaps xmm14, [rsp+0xD0]
0000792cceddb397  vmovaps xmm15, [rsp+0xE0]
0000792cceddb3a0  add rsp, 0xF0
0000792cceddb3a7  pop r11
0000792cceddb3a9  pop r10
0000792cceddb3ab  pop r9
0000792cceddb3ad  pop r8
0000792cceddb3af  pop rsi
0000792cceddb3b0  pop rdi
0000792cceddb3b1  pop rdx
0000792cceddb3b2  pop rcx
0000792cceddb3b3  pop rax
0000792cceddb3b4  add rsp, 0x08
0000792cceddb3b8  jmp 0x0000792CCEDD662F
0000792cceddb3bd  sub rsp, 0x08
0000792cceddb3c1  push rax
0000792cceddb3c2  push rcx
0000792cceddb3c3  push rdx
0000792cceddb3c4  push rdi
0000792cceddb3c5  push rsi
0000792cceddb3c6  push r8
0000792cceddb3c8  push r9
0000792cceddb3ca  push r10
0000792cceddb3cc  push r11
0000792cceddb3ce  sub rsp, 0xF0
0000792cceddb3d5  vmovaps [rsp], xmm0
0000792cceddb3da  vmovaps [rsp+0x10], xmm1
0000792cceddb3e0  vmovaps [rsp+0x20], xmm2
0000792cceddb3e6  vmovaps [rsp+0x30], xmm3
0000792cceddb3ec  vmovaps [rsp+0x40], xmm4
0000792cceddb3f2  vmovaps [rsp+0x50], xmm5
0000792cceddb3f8  vmovaps [rsp+0x60], xmm6
0000792cceddb3fe  vmovaps [rsp+0x70], xmm7
0000792cceddb404  vmovaps [rsp+0x80], xmm8
0000792cceddb40d  vmovaps [rsp+0x90], xmm9
0000792cceddb416  vmovaps [rsp+0xA0], xmm10
0000792cceddb41f  vmovaps [rsp+0xB0], xmm11
0000792cceddb428  vmovaps [rsp+0xC0], xmm12
0000792cceddb431  vmovaps [rsp+0xD0], xmm13
0000792cceddb43a  vmovaps [rsp+0xE0], xmm14
0000792cceddb443  sub rsp, 0x30
0000792cceddb447  movaps [rsp], xmm15
0000792cceddb44c  movaps [rsp+0x10], xmm11
0000792cceddb452  movaps [rsp+0x20], xmm12
0000792cceddb458  lea rdi, [rsp]
0000792cceddb45c  mov esi, 0x00
0000792cceddb461  mov rax, 0x5AEE2D541530
0000792cceddb46b  call rax
0000792cceddb46d  movaps xmm15, [rsp]
0000792cceddb472  add rsp, 0x30
0000792cceddb476  vmovaps xmm0, [rsp]
0000792cceddb47b  vmovaps xmm1, [rsp+0x10]
0000792cceddb481  vmovaps xmm2, [rsp+0x20]
0000792cceddb487  vmovaps xmm3, [rsp+0x30]
0000792cceddb48d  vmovaps xmm4, [rsp+0x40]
0000792cceddb493  vmovaps xmm5, [rsp+0x50]
0000792cceddb499  vmovaps xmm6, [rsp+0x60]
0000792cceddb49f  vmovaps xmm7, [rsp+0x70]
0000792cceddb4a5  vmovaps xmm8, [rsp+0x80]
0000792cceddb4ae  vmovaps xmm9, [rsp+0x90]
0000792cceddb4b7  vmovaps xmm10, [rsp+0xA0]
0000792cceddb4c0  vmovaps xmm11, [rsp+0xB0]
0000792cceddb4c9  vmovaps xmm12, [rsp+0xC0]
0000792cceddb4d2  vmovaps xmm13, [rsp+0xD0]
0000792cceddb4db  vmovaps xmm14, [rsp+0xE0]
0000792cceddb4e4  add rsp, 0xF0
0000792cceddb4eb  pop r11
0000792cceddb4ed  pop r10
0000792cceddb4ef  pop r9
0000792cceddb4f1  pop r8
0000792cceddb4f3  pop rsi
0000792cceddb4f4  pop rdi
0000792cceddb4f5  pop rdx
0000792cceddb4f6  pop rcx
0000792cceddb4f7  pop rax
0000792cceddb4f8  add rsp, 0x08
0000792cceddb4fc  jmp 0x0000792CCEDD664A
0000792cceddb501  sub rsp, 0x08
0000792cceddb505  push rax
0000792cceddb506  push rcx
0000792cceddb507  push rdx
0000792cceddb508  push rdi
0000792cceddb509  push rsi
0000792cceddb50a  push r8
0000792cceddb50c  push r9
0000792cceddb50e  push r10
0000792cceddb510  push r11
0000792cceddb512  sub rsp, 0xF0
0000792cceddb519  vmovaps [rsp], xmm0
0000792cceddb51e  vmovaps [rsp+0x10], xmm1
0000792cceddb524  vmovaps [rsp+0x20], xmm2
0000792cceddb52a  vmovaps [rsp+0x30], xmm3
0000792cceddb530  vmovaps [rsp+0x40], xmm4
0000792cceddb536  vmovaps [rsp+0x50], xmm5
0000792cceddb53c  vmovaps [rsp+0x60], xmm6
0000792cceddb542  vmovaps [rsp+0x70], xmm7
0000792cceddb548  vmovaps [rsp+0x80], xmm8
0000792cceddb551  vmovaps [rsp+0x90], xmm9
0000792cceddb55a  vmovaps [rsp+0xA0], xmm10
0000792cceddb563  vmovaps [rsp+0xB0], xmm11
0000792cceddb56c  vmovaps [rsp+0xC0], xmm12
0000792cceddb575  vmovaps [rsp+0xD0], xmm14
0000792cceddb57e  vmovaps [rsp+0xE0], xmm15
0000792cceddb587  sub rsp, 0x30
0000792cceddb58b  movaps [rsp], xmm13
0000792cceddb590  movaps [rsp+0x10], xmm10
0000792cceddb596  movaps [rsp+0x20], xmm14
0000792cceddb59c  lea rdi, [rsp]
0000792cceddb5a0  mov esi, 0x00
0000792cceddb5a5  mov rax, 0x5AEE2D541530
0000792cceddb5af  call rax
0000792cceddb5b1  movaps xmm13, [rsp]
0000792cceddb5b6  add rsp, 0x30
0000792cceddb5ba  vmovaps xmm0, [rsp]
0000792cceddb5bf  vmovaps xmm1, [rsp+0x10]
0000792cceddb5c5  vmovaps xmm2, [rsp+0x20]
0000792cceddb5cb  vmovaps xmm3, [rsp+0x30]
0000792cceddb5d1  vmovaps xmm4, [rsp+0x40]
0000792cceddb5d7  vmovaps xmm5, [rsp+0x50]
0000792cceddb5dd  vmovaps xmm6, [rsp+0x60]
0000792cceddb5e3  vmovaps xmm7, [rsp+0x70]
0000792cceddb5e9  vmovaps xmm8, [rsp+0x80]
0000792cceddb5f2  vmovaps xmm9, [rsp+0x90]
0000792cceddb5fb  vmovaps xmm10, [rsp+0xA0]
0000792cceddb604  vmovaps xmm11, [rsp+0xB0]
0000792cceddb60d  vmovaps xmm12, [rsp+0xC0]
0000792cceddb616  vmovaps xmm14, [rsp+0xD0]
0000792cceddb61f  vmovaps xmm15, [rsp+0xE0]
0000792cceddb628  add rsp, 0xF0
0000792cceddb62f  pop r11
0000792cceddb631  pop r10
0000792cceddb633  pop r9
0000792cceddb635  pop r8
0000792cceddb637  pop rsi
0000792cceddb638  pop rdi
0000792cceddb639  pop rdx
0000792cceddb63a  pop rcx
0000792cceddb63b  pop rax
0000792cceddb63c  add rsp, 0x08
0000792cceddb640  jmp 0x0000792CCEDD666D
0000792cceddb645  sub rsp, 0x08
0000792cceddb649  push rax
0000792cceddb64a  push rcx
0000792cceddb64b  push rdx
0000792cceddb64c  push rdi
0000792cceddb64d  push rsi
0000792cceddb64e  push r8
0000792cceddb650  push r9
0000792cceddb652  push r10
0000792cceddb654  push r11
0000792cceddb656  sub rsp, 0xF0
0000792cceddb65d  vmovaps [rsp], xmm0
0000792cceddb662  vmovaps [rsp+0x10], xmm1
0000792cceddb668  vmovaps [rsp+0x20], xmm2
0000792cceddb66e  vmovaps [rsp+0x30], xmm3
0000792cceddb674  vmovaps [rsp+0x40], xmm4
0000792cceddb67a  vmovaps [rsp+0x50], xmm5
0000792cceddb680  vmovaps [rsp+0x60], xmm6
0000792cceddb686  vmovaps [rsp+0x70], xmm7
0000792cceddb68c  vmovaps [rsp+0x80], xmm8
0000792cceddb695  vmovaps [rsp+0x90], xmm9
0000792cceddb69e  vmovaps [rsp+0xA0], xmm10
0000792cceddb6a7  vmovaps [rsp+0xB0], xmm11
0000792cceddb6b0  vmovaps [rsp+0xC0], xmm12
0000792cceddb6b9  vmovaps [rsp+0xD0], xmm13
0000792cceddb6c2  vmovaps [rsp+0xE0], xmm15
0000792cceddb6cb  sub rsp, 0x30
0000792cceddb6cf  movaps [rsp], xmm14
0000792cceddb6d4  movaps [rsp+0x10], xmm1
0000792cceddb6d9  movaps [rsp+0x20], xmm7
0000792cceddb6de  lea rdi, [rsp]
0000792cceddb6e2  mov esi, 0x00
0000792cceddb6e7  mov rax, 0x5AEE2D541530
0000792cceddb6f1  call rax
0000792cceddb6f3  movaps xmm14, [rsp]
0000792cceddb6f8  add rsp, 0x30
0000792cceddb6fc  vmovaps xmm0, [rsp]
0000792cceddb701  vmovaps xmm1, [rsp+0x10]
0000792cceddb707  vmovaps xmm2, [rsp+0x20]
0000792cceddb70d  vmovaps xmm3, [rsp+0x30]
0000792cceddb713  vmovaps xmm4, [rsp+0x40]
0000792cceddb719  vmovaps xmm5, [rsp+0x50]
0000792cceddb71f  vmovaps xmm6, [rsp+0x60]
0000792cceddb725  vmovaps xmm7, [rsp+0x70]
0000792cceddb72b  vmovaps xmm8, [rsp+0x80]
0000792cceddb734  vmovaps xmm9, [rsp+0x90]
0000792cceddb73d  vmovaps xmm10, [rsp+0xA0]
0000792cceddb746  vmovaps xmm11, [rsp+0xB0]
0000792cceddb74f  vmovaps xmm12, [rsp+0xC0]
0000792cceddb758  vmovaps xmm13, [rsp+0xD0]
0000792cceddb761  vmovaps xmm15, [rsp+0xE0]
0000792cceddb76a  add rsp, 0xF0
0000792cceddb771  pop r11
0000792cceddb773  pop r10
0000792cceddb775  pop r9
0000792cceddb777  pop r8
0000792cceddb779  pop rsi
0000792cceddb77a  pop rdi
0000792cceddb77b  pop rdx
0000792cceddb77c  pop rcx
0000792cceddb77d  pop rax
0000792cceddb77e  add rsp, 0x08
0000792cceddb782  jmp 0x0000792CCEDD6690
0000792cceddb787  sub rsp, 0x08
0000792cceddb78b  push rax
0000792cceddb78c  push rcx
0000792cceddb78d  push rdx
0000792cceddb78e  push rdi
0000792cceddb78f  push rsi
0000792cceddb790  push r8
0000792cceddb792  push r9
0000792cceddb794  push r10
0000792cceddb796  push r11
0000792cceddb798  sub rsp, 0xF0
0000792cceddb79f  vmovaps [rsp], xmm0
0000792cceddb7a4  vmovaps [rsp+0x10], xmm2
0000792cceddb7aa  vmovaps [rsp+0x20], xmm3
0000792cceddb7b0  vmovaps [rsp+0x30], xmm4
0000792cceddb7b6  vmovaps [rsp+0x40], xmm5
0000792cceddb7bc  vmovaps [rsp+0x50], xmm6
0000792cceddb7c2  vmovaps [rsp+0x60], xmm7
0000792cceddb7c8  vmovaps [rsp+0x70], xmm8
0000792cceddb7ce  vmovaps [rsp+0x80], xmm9
0000792cceddb7d7  vmovaps [rsp+0x90], xmm10
0000792cceddb7e0  vmovaps [rsp+0xA0], xmm11
0000792cceddb7e9  vmovaps [rsp+0xB0], xmm12
0000792cceddb7f2  vmovaps [rsp+0xC0], xmm13
0000792cceddb7fb  vmovaps [rsp+0xD0], xmm14
0000792cceddb804  vmovaps [rsp+0xE0], xmm15
0000792cceddb80d  sub rsp, 0x30
0000792cceddb811  movaps [rsp], xmm1
0000792cceddb815  movaps [rsp+0x10], xmm8
0000792cceddb81b  movaps [rsp+0x20], xmm9
0000792cceddb821  lea rdi, [rsp]
0000792cceddb825  mov esi, 0x00
0000792cceddb82a  mov rax, 0x5AEE2D541530
0000792cceddb834  call rax
0000792cceddb836  movaps xmm1, [rsp]
0000792cceddb83a  add rsp, 0x30
0000792cceddb83e  vmovaps xmm0, [rsp]
0000792cceddb843  vmovaps xmm2, [rsp+0x10]
0000792cceddb849  vmovaps xmm3, [rsp+0x20]
0000792cceddb84f  vmovaps xmm4, [rsp+0x30]
0000792cceddb855  vmovaps xmm5, [rsp+0x40]
0000792cceddb85b  vmovaps xmm6, [rsp+0x50]
0000792cceddb861  vmovaps xmm7, [rsp+0x60]
0000792cceddb867  vmovaps xmm8, [rsp+0x70]
0000792cceddb86d  vmovaps xmm9, [rsp+0x80]
0000792cceddb876  vmovaps xmm10, [rsp+0x90]
0000792cceddb87f  vmovaps xmm11, [rsp+0xA0]
0000792cceddb888  vmovaps xmm12, [rsp+0xB0]
0000792cceddb891  vmovaps xmm13, [rsp+0xC0]
0000792cceddb89a  vmovaps xmm14, [rsp+0xD0]
0000792cceddb8a3  vmovaps xmm15, [rsp+0xE0]
0000792cceddb8ac  add rsp, 0xF0
0000792cceddb8b3  pop r11
0000792cceddb8b5  pop r10
0000792cceddb8b7  pop r9
0000792cceddb8b9  pop r8
0000792cceddb8bb  pop rsi
0000792cceddb8bc  pop rdi
0000792cceddb8bd  pop rdx
0000792cceddb8be  pop rcx
0000792cceddb8bf  pop rax
0000792cceddb8c0  add rsp, 0x08
0000792cceddb8c4  jmp 0x0000792CCEDD66B2
0000792cceddb8c9  call 0x0000792CCECB3E40
0000792cceddb8ce  jmp 0x0000792CCEDD66C0
0000792cceddb8d3  call 0x0000792CCEC0C380
0000792cceddb8d8  jmp 0x0000792CCEDD66CA
0000792cceddb8dd  call 0x0000792CCEC0D600
0000792cceddb8e2  jmp 0x0000792CCEDD66D4
0000792cceddb8e7  call 0x0000792CCEBFF540
0000792cceddb8ec  jmp 0x0000792CCEDD66DE
0000792cceddb8f1  int3
0000792cceddb8f2  nop [rax+rax*1], ax
0000792cceddb8fb  nop [rax+rax*1], eax
0000792cceddb900  mov eax, [r15+0x48]
0000792cceddb904  lea r14d, [eax+0x01]
0000792cceddb909  mov [rsp+0x10], r14d
0000792cceddb90e  mov r14d, r14d
0000792cceddb911  mov [r15+0x48], r14
0000792cceddb915  xor eax, eax
0000792cceddb917  mov r14d, [rsp+0x10]
0000792cceddb91c  cmp r14d, 0x1F4
0000792cceddb923  cmc
0000792cceddb924  lahf
0000792cceddb925  seto al
0000792cceddb928  mov [r15+0x108], eax
0000792cceddb92f  mov eax, [r15+0x108]
0000792cceddb936  sahf
0000792cceddb937  jnz 0x0000792CCEDDB969
0000792cceddb939  cmp dword ptr [r15+0x318], 0x00
0000792cceddb941  jz 0x0000792CCEDE1AB0
0000792cceddb947  nop [rax+rax*1], ax
0000792cceddb950  nop [rax+rax*1], eax
0000792cceddb958  mov eax, 0x410450
0000792cceddb95d  mov [r15+0x100], rax
0000792cceddb964  jmp 0x0000792CCEBFE110
0000792cceddb969  cmp dword ptr [r15+0x318], 0x00
0000792cceddb971  jz 0x0000792CCEDDB9A0
0000792cceddb977  nop [rax+rax*1], ax
0000792cceddb980  nop [rax+rax*1], eax
0000792cceddb988  mov eax, 0x410274
0000792cceddb98d  mov [r15+0x100], rax
0000792cceddb994  jmp 0x0000792CCEBFE110
0000792cceddb999  int3
0000792cceddb99a  int3
0000792cceddb99b  nop [rax+rax*1], eax
0000792cceddb9a0  mov rax, [r15+0x40]
0000792cceddb9a4  movaps xmm1, [r15+0x1D0]
0000792cceddb9ac  vmovaps [rsp+0x10], xmm1
0000792cceddb9b2  vmovaps xmm15, [rsp+0x10]
0000792cceddb9b8  por xmm1, xmm15
0000792cceddb9bd  movaps xmm14, [r15+0x1A0]
0000792cceddb9c5  vmovaps [rsp+0x10], xmm14
0000792cceddb9cb  vmovaps xmm13, [rsp+0x10]
0000792cceddb9d1  por xmm14, xmm13
0000792cceddb9d6  lea r14, [rax+0x30]
0000792cceddb9da  mov r12, [r13+r14*1]
0000792cceddb9df  lea r14, [rax+0x38]
0000792cceddb9e3  mov r11, [r13+r14*1]
0000792cceddb9e8  movq xmm13, r12
0000792cceddb9ed  movq xmm12, r11
0000792cceddb9f2  movq xmm13, xmm13
0000792cceddb9f7  vmovaps [rsp+0x10], xmm13
0000792cceddb9fd  movq xmm13, xmm13
0000792cceddba02  movaps [r15+0x130], xmm13
0000792cceddba0a  movq xmm12, xmm12
0000792cceddba0f  vmovaps [rsp+0x20], xmm12
0000792cceddba15  movq xmm12, xmm12
0000792cceddba1a  movaps [r15+0x280], xmm12
0000792cceddba22  movaps xmm13, [r15+0x270]
0000792cceddba2a  vmovaps [rsp+0x30], xmm13
0000792cceddba30  vmovaps xmm12, [rsp+0x30]
0000792cceddba36  por xmm13, xmm12
0000792cceddba3b  lea r14, [rax+0x20]
0000792cceddba3f  mov r12, [r13+r14*1]
0000792cceddba44  lea r14, [rax+0x28]
0000792cceddba48  mov r11, [r13+r14*1]
0000792cceddba4d  movq xmm12, r12
0000792cceddba52  movq xmm11, r11
0000792cceddba57  movq xmm12, xmm12
0000792cceddba5c  vmovaps [rsp+0x30], xmm12
0000792cceddba62  movq xmm12, xmm12
0000792cceddba67  movaps [r15+0x150], xmm12
0000792cceddba6f  movq xmm11, xmm11
0000792cceddba74  vmovaps [rsp+0x40], xmm11
0000792cceddba7a  movq xmm11, xmm11
0000792cceddba7f  movaps [r15+0x140], xmm11
0000792cceddba87  lea r14, [rax+0x10]
0000792cceddba8b  mov r12, [r13+r14*1]
0000792cceddba90  lea r14, [rax+0x18]
0000792cceddba94  mov r11, [r13+r14*1]
0000792cceddba99  movq xmm12, r12
0000792cceddba9e  movq xmm11, r11
0000792cceddbaa3  movq xmm12, xmm12
0000792cceddbaa8  vmovaps [rsp+0x50], xmm12
0000792cceddbaae  movq xmm12, xmm12
0000792cceddbab3  movaps [r15+0x170], xmm12
0000792cceddbabb  movq xmm11, xmm11
0000792cceddbac0  vmovaps [rsp+0x60], xmm11
0000792cceddbac6  movq xmm11, xmm11
0000792cceddbacb  movaps [r15+0x160], xmm11
0000792cceddbad3  mov r14, [r13+rax*1]
0000792cceddbad8  vmovq xmm12, r14
0000792cceddbadd  vpbroadcastq xmm12, xmm12
0000792cceddbae2  lea r14, [rax+0x08]
0000792cceddbae6  mov rax, [r13+r14*1]
0000792cceddbaeb  movq xmm11, rax
0000792cceddbaf0  movaps [r15+0x230], xmm11
0000792cceddbaf8  mov rax, [r15+0xF8]
0000792cceddbaff  lea r14, [rax+0x50]
0000792cceddbb03  movups xmm11, [r13+r14*1]
0000792cceddbb09  lea r14, [rax+0x60]
0000792cceddbb0d  movups xmm10, [r13+r14*1]
0000792cceddbb13  lea r14, [rax+0x30]
0000792cceddbb17  movups xmm9, [r13+r14*1]
0000792cceddbb1d  mov r14, [r15+0x50]
0000792cceddbb21  mov [r15+0x60], r14
0000792cceddbb25  mov qword ptr [r15+0x58], 0x40
0000792cceddbb2d  movaps xmm8, xmm12
0000792cceddbb31  mulpd xmm8, xmm15
0000792cceddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000792cceddbb3c  ptest xmm7, xmm7
0000792cceddbb41  jnz 0x0000792CCEDDC96A
0000792cceddbb47  movq xmm15, qword ptr [r15+0x230]
0000792cceddbb50  vmovaps [rsp+0x70], xmm15
0000792cceddbb56  vpermilpd xmm15, xmm15, 0x00
0000792cceddbb5c  movaps xmm7, xmm9
0000792cceddbb60  mulpd xmm7, xmm15
0000792cceddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000792cceddbb6a  ptest xmm6, xmm6
0000792cceddbb6f  jnz 0x0000792CCEDDCAAE
0000792cceddbb75  vxorps xmm15, xmm15, xmm15
0000792cceddbb7a  vpbroadcastq xmm15, xmm15
0000792cceddbb7f  movaps xmm9, xmm12
0000792cceddbb83  mulpd xmm9, xmm10
0000792cceddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000792cceddbb8e  ptest xmm6, xmm6
0000792cceddbb93  jnz 0x0000792CCEDDCBF0
0000792cceddbb99  movaps xmm10, xmm12
0000792cceddbb9d  mulpd xmm10, xmm11
0000792cceddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000792cceddbba8  ptest xmm6, xmm6
0000792cceddbbad  jnz 0x0000792CCEDDCD34
0000792cceddbbb3  movaps xmm11, [r15+0x1F0]
0000792cceddbbbb  movaps xmm6, xmm12
0000792cceddbbbf  mulpd xmm6, xmm11
0000792cceddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000792cceddbbc9  ptest xmm5, xmm5
0000792cceddbbce  jnz 0x0000792CCEDDCE78
0000792cceddbbd4  movaps xmm12, [r15+0x2A0]
0000792cceddbbdc  vmovaps [rsp+0x80], xmm12
0000792cceddbbe5  vmovaps xmm11, [rsp+0x80]
0000792cceddbbee  por xmm12, xmm11
0000792cceddbbf3  movaps xmm11, [r15+0x250]
0000792cceddbbfb  vmovaps [rsp+0x80], xmm11
0000792cceddbc04  vmovaps xmm5, [rsp+0x80]
0000792cceddbc0d  por xmm11, xmm5
0000792cceddbc12  vmovaps xmm4, [rsp+0x70]
0000792cceddbc18  vpermilpd xmm4, xmm4, 0x00
0000792cceddbc1e  movaps xmm3, xmm5
0000792cceddbc21  mulpd xmm3, xmm4
0000792cceddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000792cceddbc2a  ptest xmm2, xmm2
0000792cceddbc2f  jnz 0x0000792CCEDDCFBA
0000792cceddbc35  mov [rsp+0x80], rax
0000792cceddbc3d  xor eax, eax
0000792cceddbc3f  mov r12d, 0x40
0000792cceddbc45  mov r11d, 0x200
0000792cceddbc4b  cmp r12, r11
0000792cceddbc4e  cmc
0000792cceddbc4f  lahf
0000792cceddbc50  seto al
0000792cceddbc53  mov [r15+0x108], eax
0000792cceddbc5a  movaps xmm5, xmm8
0000792cceddbc5e  addpd xmm5, xmm15
0000792cceddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000792cceddbc68  ptest xmm4, xmm4
0000792cceddbc6d  jnz 0x0000792CCEDDD0FA
0000792cceddbc73  movaps xmm8, [r15+0x1B0]
0000792cceddbc7b  movaps xmm4, xmm9
0000792cceddbc7f  addpd xmm4, xmm8
0000792cceddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000792cceddbc89  ptest xmm2, xmm2
0000792cceddbc8e  jnz 0x0000792CCEDDD23C
0000792cceddbc94  movaps xmm9, xmm10
0000792cceddbc98  addpd xmm9, xmm8
0000792cceddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000792cceddbca3  ptest xmm2, xmm2
0000792cceddbca8  jnz 0x0000792CCEDDD37E
0000792cceddbcae  movaps xmm10, [r15+0x2F0]
0000792cceddbcb6  vmovaps [rsp+0x90], xmm10
0000792cceddbcbf  vmovaps xmm8, [rsp+0x90]
0000792cceddbcc8  por xmm10, xmm8
0000792cceddbccd  movaps xmm8, [r15+0x2E0]
0000792cceddbcd5  vmovaps [rsp+0x90], xmm8
0000792cceddbcde  vmovaps xmm2, [rsp+0x90]
0000792cceddbce7  por xmm8, xmm2
0000792cceddbcec  movaps xmm2, [r15+0x2D0]
0000792cceddbcf4  vmovaps [rsp+0x90], xmm2
0000792cceddbcfd  vmovaps [rsp+0xA0], xmm1
0000792cceddbd06  vmovaps xmm1, [rsp+0x90]
0000792cceddbd0f  por xmm2, xmm1
0000792cceddbd13  movaps xmm1, [r15+0x200]
0000792cceddbd1b  vmovaps [rsp+0x90], xmm1
0000792cceddbd24  vmovaps [rsp+0xB0], xmm15
0000792cceddbd2d  vmovaps xmm15, [rsp+0x90]
0000792cceddbd36  por xmm1, xmm15
0000792cceddbd3b  movaps xmm15, [r15+0x1C0]
0000792cceddbd43  vmovaps [rsp+0x90], xmm15
0000792cceddbd4c  vmovaps [rsp+0xC0], xmm1
0000792cceddbd55  vmovaps xmm1, [rsp+0x90]
0000792cceddbd5e  por xmm15, xmm1
0000792cceddbd63  movaps xmm1, [r15+0x190]
0000792cceddbd6b  vmovaps [rsp+0x90], xmm1
0000792cceddbd74  vmovaps [rsp+0xD0], xmm15
0000792cceddbd7d  vmovaps xmm15, [rsp+0x90]
0000792cceddbd86  por xmm1, xmm15
0000792cceddbd8b  movaps xmm15, [r15+0x300]
0000792cceddbd93  vmovaps [rsp+0x90], xmm15
0000792cceddbd9c  vmovaps [rsp+0xE0], xmm1
0000792cceddbda5  vmovaps xmm1, [rsp+0x90]
0000792cceddbdae  por xmm15, xmm1
0000792cceddbdb3  mov rax, [rsp+0x80]
0000792cceddbdbb  lea r12, [rax+0xA0]
0000792cceddbdc2  movups xmm1, [r13+r12*1]
0000792cceddbdc8  lea r12, [rax+0xB0]
0000792cceddbdcf  vmovaps [rsp+0x80], xmm1
0000792cceddbdd8  movups xmm1, [r13+r12*1]
0000792cceddbdde  vmovaps [rsp+0x90], xmm1
0000792cceddbde7  vmovaps [rsp+0xF0], xmm15
0000792cceddbdf0  vmovaps xmm15, [rsp+0xB0]
0000792cceddbdf9  vmovaps [rsp+0xB0], xmm14
0000792cceddbe02  movaps xmm1, xmm6
0000792cceddbe05  addpd xmm1, xmm15
0000792cceddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000792cceddbe0f  ptest xmm14, xmm14
0000792cceddbe15  jnz 0x0000792CCEDDD4D6
0000792cceddbe1b  lea r12, [rax+0xF0]
0000792cceddbe22  movups xmm15, [r13+r12*1]
0000792cceddbe28  movaps xmm14, xmm4
0000792cceddbe2c  addpd xmm14, xmm3
0000792cceddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000792cceddbe37  ptest xmm6, xmm6
0000792cceddbe3c  jnz 0x0000792CCEDDD621
0000792cceddbe42  movaps xmm6, xmm9
0000792cceddbe46  addpd xmm6, xmm7
0000792cceddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000792cceddbe4f  ptest xmm4, xmm4
0000792cceddbe54  jnz 0x0000792CCEDDD763
0000792cceddbe5a  vmovaps xmm9, [rsp+0x70]
0000792cceddbe60  vpermilpd xmm9, xmm9, 0x00
0000792cceddbe66  vmovaps xmm4, [rsp+0x90]
0000792cceddbe6f  movaps xmm7, xmm4
0000792cceddbe72  mulpd xmm7, xmm9
0000792cceddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000792cceddbe7c  ptest xmm3, xmm3
0000792cceddbe81  jnz 0x0000792CCEDDD8A4
0000792cceddbe87  vmovaps xmm9, [rsp+0x50]
0000792cceddbe8d  vpermilpd xmm9, xmm9, 0x00
0000792cceddbe93  movaps xmm4, xmm15
0000792cceddbe97  mulpd xmm4, xmm9
0000792cceddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000792cceddbea1  ptest xmm3, xmm3
0000792cceddbea6  jnz 0x0000792CCEDDD9E5
0000792cceddbeac  lea r12, [rax+0xE0]
0000792cceddbeb3  movups xmm15, [r13+r12*1]
0000792cceddbeb9  vmovaps xmm9, [rsp+0x70]
0000792cceddbebf  vpermilpd xmm9, xmm9, 0x00
0000792cceddbec5  vmovaps [rsp+0x70], xmm1
0000792cceddbecb  vmovaps xmm1, [rsp+0x80]
0000792cceddbed4  vmovaps [rsp+0x80], xmm15
0000792cceddbedd  movaps xmm3, xmm1
0000792cceddbee0  mulpd xmm3, xmm9
0000792cceddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000792cceddbeea  ptest xmm15, xmm15
0000792cceddbef0  jnz 0x0000792CCEDDDB31
0000792cceddbef6  vmovaps xmm1, [rsp+0xF0]
0000792cceddbeff  vmovaps xmm15, [rsp+0xF0]
0000792cceddbf08  por xmm1, xmm15
0000792cceddbf0d  movaps [r15+0x300], xmm1
0000792cceddbf15  vmovaps xmm15, [rsp+0xE0]
0000792cceddbf1e  vmovaps xmm9, [rsp+0xE0]
0000792cceddbf27  por xmm15, xmm9
0000792cceddbf2c  movaps [r15+0x190], xmm15
0000792cceddbf34  vmovaps xmm9, [rsp+0x50]
0000792cceddbf3a  vpermilpd xmm9, xmm9, 0x00
0000792cceddbf40  vmovaps [rsp+0x90], xmm1
0000792cceddbf49  vmovaps [rsp+0xE0], xmm15
0000792cceddbf52  vmovaps xmm15, [rsp+0x80]
0000792cceddbf5b  vmovaps [rsp+0x80], xmm14
0000792cceddbf64  movaps xmm1, xmm15
0000792cceddbf68  mulpd xmm1, xmm9
0000792cceddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000792cceddbf72  ptest xmm14, xmm14
0000792cceddbf78  jnz 0x0000792CCEDDDC72
0000792cceddbf7e  lea r12, [rax+0x90]
0000792cceddbf85  movups xmm15, [r13+r12*1]
0000792cceddbf8b  vmovaps xmm14, [rsp+0xD0]
0000792cceddbf94  vmovaps xmm9, [rsp+0xD0]
0000792cceddbf9d  por xmm14, xmm9
0000792cceddbfa2  movaps [r15+0x1C0], xmm14
0000792cceddbfaa  vmovaps xmm9, [rsp+0xC0]
0000792cceddbfb3  vmovaps [rsp+0xD0], xmm1
0000792cceddbfbc  vmovaps xmm1, [rsp+0xC0]
0000792cceddbfc5  por xmm9, xmm1
0000792cceddbfca  movaps [r15+0x200], xmm9
0000792cceddbfd2  vmovaps [rsp+0xC0], xmm2
0000792cceddbfdb  vmovaps xmm1, [rsp+0xC0]
0000792cceddbfe4  por xmm2, xmm1
0000792cceddbfe8  movaps [r15+0x2D0], xmm2
0000792cceddbff0  vmovaps [rsp+0xC0], xmm8
0000792cceddbff9  vmovaps xmm1, [rsp+0xC0]
0000792cceddc002  por xmm8, xmm1
0000792cceddc007  movaps [r15+0x2E0], xmm8
0000792cceddc00f  vmovaps [rsp+0xC0], xmm15
0000792cceddc018  movaps xmm1, xmm5
0000792cceddc01b  addpd xmm1, xmm7
0000792cceddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000792cceddc024  ptest xmm15, xmm15
0000792cceddc02a  jnz 0x0000792CCEDDDDBE
0000792cceddc030  vmovaps xmm15, [rsp+0x50]
0000792cceddc036  vpermilpd xmm15, xmm15, 0x00
0000792cceddc03c  vmovaps xmm5, [rsp+0xC0]
0000792cceddc045  vmovaps [rsp+0xC0], xmm1
0000792cceddc04e  movaps xmm7, xmm5
0000792cceddc051  mulpd xmm7, xmm15
0000792cceddc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000792cceddc05b  ptest xmm1, xmm1
0000792cceddc060  jnz 0x0000792CCEDDDEFE
0000792cceddc066  lea r12, [rax+0x80]
0000792cceddc06d  movups xmm1, [r13+r12*1]
0000792cceddc073  vmovaps xmm5, [rsp+0x70]
0000792cceddc079  vmovaps [rsp+0x70], xmm1
0000792cceddc07f  movaps xmm15, xmm5
0000792cceddc083  addpd xmm15, xmm3
0000792cceddc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000792cceddc08e  ptest xmm1, xmm1
0000792cceddc093  jnz 0x0000792CCEDDE049
0000792cceddc099  vmovaps xmm5, [rsp+0x80]
0000792cceddc0a2  movaps xmm1, xmm5
0000792cceddc0a5  addpd xmm1, xmm4
0000792cceddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000792cceddc0ae  ptest xmm3, xmm3
0000792cceddc0b3  jnz 0x0000792CCEDDE18B
0000792cceddc0b9  vmovaps [rsp+0x80], xmm10
0000792cceddc0c2  vmovaps xmm5, [rsp+0x80]
0000792cceddc0cb  por xmm10, xmm5
0000792cceddc0d0  movaps [r15+0x2F0], xmm10
0000792cceddc0d8  vmovaps xmm5, [rsp+0x50]
0000792cceddc0de  vpermilpd xmm5, xmm5, 0x00
0000792cceddc0e4  vmovaps xmm3, [rsp+0x70]
0000792cceddc0ea  vmovaps [rsp+0x50], xmm1
0000792cceddc0f0  movaps xmm4, xmm3
0000792cceddc0f3  mulpd xmm4, xmm5
0000792cceddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000792cceddc0fc  ptest xmm1, xmm1
0000792cceddc101  jnz 0x0000792CCEDDE2CB
0000792cceddc107  lea r12, [rax+0xD0]
0000792cceddc10e  movups xmm1, [r13+r12*1]
0000792cceddc114  vmovaps xmm3, [rsp+0xD0]
0000792cceddc11d  vmovaps [rsp+0x70], xmm1
0000792cceddc123  movaps xmm5, xmm6
0000792cceddc126  addpd xmm5, xmm3
0000792cceddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000792cceddc12f  ptest xmm1, xmm1
0000792cceddc134  jnz 0x0000792CCEDDE415
0000792cceddc13a  vmovaps xmm1, [rsp+0x60]
0000792cceddc140  vpermilpd xmm1, xmm1, 0x00
0000792cceddc146  movaps xmm6, xmm9
0000792cceddc14a  mulpd xmm6, xmm1
0000792cceddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000792cceddc153  ptest xmm3, xmm3
0000792cceddc158  jnz 0x0000792CCEDDE555
0000792cceddc15e  movaps [r15+0x260], xmm6
0000792cceddc166  vxorps xmm1, xmm1, xmm1
0000792cceddc16a  vpbroadcastq xmm1, xmm1
0000792cceddc16f  movaps [r15+0x1B0], xmm1
0000792cceddc177  vmovaps xmm1, [rsp+0x60]
0000792cceddc17d  vpermilpd xmm1, xmm1, 0x00
0000792cceddc183  vmovaps xmm3, [rsp+0x70]
0000792cceddc189  vmovaps [rsp+0x70], xmm15
0000792cceddc18f  movaps xmm9, xmm3
0000792cceddc193  mulpd xmm9, xmm1
0000792cceddc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000792cceddc19e  ptest xmm15, xmm15
0000792cceddc1a4  jnz 0x0000792CCEDDE696
0000792cceddc1aa  lea r12, [rax+0xC0]
0000792cceddc1b1  movups xmm1, [r13+r12*1]
0000792cceddc1b7  vmovaps xmm3, [rsp+0xC0]
0000792cceddc1c0  vmovaps [rsp+0x80], xmm1
0000792cceddc1c9  movaps xmm15, xmm3
0000792cceddc1cd  addpd xmm15, xmm7
0000792cceddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000792cceddc1d8  ptest xmm1, xmm1
0000792cceddc1dd  jnz 0x0000792CCEDDE7E2
0000792cceddc1e3  vmovaps [rsp+0xC0], xmm13
0000792cceddc1ec  vmovaps xmm1, [rsp+0xC0]
0000792cceddc1f5  por xmm13, xmm1
0000792cceddc1fa  movaps [r15+0x270], xmm13
0000792cceddc202  vmovaps xmm1, [rsp+0xB0]
0000792cceddc20b  vmovaps xmm7, [rsp+0xB0]
0000792cceddc214  por xmm1, xmm7
0000792cceddc218  movaps [r15+0x1A0], xmm1
0000792cceddc220  vmovaps xmm1, [rsp+0x60]
0000792cceddc226  vpermilpd xmm1, xmm1, 0x00
0000792cceddc22c  vmovaps [rsp+0xB0], xmm1
0000792cceddc235  vmovaps xmm1, [rsp+0x80]
0000792cceddc23e  vmovaps [rsp+0x80], xmm15
0000792cceddc247  vmovaps xmm15, [rsp+0xB0]
0000792cceddc250  vmovaps [rsp+0xB0], xmm14
0000792cceddc259  movaps xmm3, xmm1
0000792cceddc25c  mulpd xmm3, xmm15
0000792cceddc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000792cceddc266  ptest xmm14, xmm14
0000792cceddc26c  jnz 0x0000792CCEDDE924
0000792cceddc272  lea r12, [rax+0x20]
0000792cceddc276  movups xmm1, [r13+r12*1]
0000792cceddc27c  movaps [r15+0x110], xmm1
0000792cceddc284  vmovaps xmm14, [rsp+0x70]
0000792cceddc28a  vmovaps [rsp+0x70], xmm1
0000792cceddc290  movaps xmm15, xmm14
0000792cceddc294  addpd xmm15, xmm4
0000792cceddc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000792cceddc29f  ptest xmm1, xmm1
0000792cceddc2a4  jnz 0x0000792CCEDDEA6F
0000792cceddc2aa  vmovaps xmm1, [rsp+0x60]
0000792cceddc2b0  vpermilpd xmm1, xmm1, 0x00
0000792cceddc2b6  movaps xmm14, xmm2
0000792cceddc2ba  mulpd xmm14, xmm1
0000792cceddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000792cceddc2c5  ptest xmm4, xmm4
0000792cceddc2ca  jnz 0x0000792CCEDDEBB2
0000792cceddc2d0  vmovaps xmm4, [rsp+0x50]
0000792cceddc2d6  movaps xmm1, xmm4
0000792cceddc2d9  addpd xmm1, xmm9
0000792cceddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000792cceddc2e3  ptest xmm2, xmm2
0000792cceddc2e8  jnz 0x0000792CCEDDECF4
0000792cceddc2ee  vmovaps xmm9, [rsp+0x30]
0000792cceddc2f4  vpermilpd xmm9, xmm9, 0x00
0000792cceddc2fa  vmovaps xmm2, [rsp+0x70]
0000792cceddc300  vmovaps [rsp+0x50], xmm1
0000792cceddc306  movaps xmm4, xmm2
0000792cceddc309  mulpd xmm4, xmm9
0000792cceddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000792cceddc313  ptest xmm1, xmm1
0000792cceddc318  jnz 0x0000792CCEDDEE35
0000792cceddc31e  vmovaps xmm1, [rsp+0x30]
0000792cceddc324  vpermilpd xmm1, xmm1, 0x00
0000792cceddc32a  vmovaps xmm2, [rsp+0x90]
0000792cceddc333  vmovaps [rsp+0x60], xmm15
0000792cceddc339  movaps xmm9, xmm2
0000792cceddc33d  mulpd xmm9, xmm1
0000792cceddc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000792cceddc348  ptest xmm15, xmm15
0000792cceddc34e  jnz 0x0000792CCEDDEF76
0000792cceddc354  vmovaps xmm15, [rsp+0x80]
0000792cceddc35d  movaps xmm1, xmm15
0000792cceddc361  addpd xmm1, xmm6
0000792cceddc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000792cceddc36a  ptest xmm2, xmm2
0000792cceddc36f  jnz 0x0000792CCEDDF0B8
0000792cceddc375  movaps xmm15, xmm5
0000792cceddc379  addpd xmm15, xmm3
0000792cceddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000792cceddc384  ptest xmm6, xmm6
0000792cceddc389  jnz 0x0000792CCEDDF1F9
0000792cceddc38f  vmovaps xmm6, [rsp+0x30]
0000792cceddc395  vpermilpd xmm6, xmm6, 0x00
0000792cceddc39b  movaps xmm5, xmm8
0000792cceddc39f  mulpd xmm5, xmm6
0000792cceddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000792cceddc3a8  ptest xmm3, xmm3
0000792cceddc3ad  jnz 0x0000792CCEDDF33B
0000792cceddc3b3  vmovaps xmm8, [rsp+0x30]
0000792cceddc3b9  vpermilpd xmm8, xmm8, 0x00
0000792cceddc3bf  movaps xmm6, xmm10
0000792cceddc3c3  mulpd xmm6, xmm8
0000792cceddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000792cceddc3cd  ptest xmm3, xmm3
0000792cceddc3d2  jnz 0x0000792CCEDDF47C
0000792cceddc3d8  vmovaps xmm8, [rsp+0x60]
0000792cceddc3de  movaps xmm10, xmm8
0000792cceddc3e2  addpd xmm10, xmm14
0000792cceddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000792cceddc3ed  ptest xmm3, xmm3
0000792cceddc3f2  jnz 0x0000792CCEDDF5BE
0000792cceddc3f8  vmovaps xmm8, [rsp+0x50]
0000792cceddc3fe  movaps xmm14, xmm8
0000792cceddc402  addpd xmm14, xmm4
0000792cceddc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000792cceddc40d  ptest xmm3, xmm3
0000792cceddc412  jnz 0x0000792CCEDDF702
0000792cceddc418  vmovaps xmm8, [rsp+0x40]
0000792cceddc41e  vpermilpd xmm8, xmm8, 0x00
0000792cceddc424  movaps xmm4, xmm13
0000792cceddc428  mulpd xmm4, xmm8
0000792cceddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000792cceddc432  ptest xmm3, xmm3
0000792cceddc437  jnz 0x0000792CCEDDF845
0000792cceddc43d  movaps xmm13, xmm15
0000792cceddc441  addpd xmm13, xmm9
0000792cceddc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000792cceddc44c  ptest xmm8, xmm8
0000792cceddc452  jnz 0x0000792CCEDDF987
0000792cceddc458  movaps xmm15, xmm1
0000792cceddc45c  addpd xmm15, xmm5
0000792cceddc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000792cceddc467  ptest xmm9, xmm9
0000792cceddc46d  jnz 0x0000792CCEDDFACB
0000792cceddc473  vmovaps [rsp+0x30], xmm11
0000792cceddc479  vmovaps xmm1, [rsp+0x30]
0000792cceddc47f  por xmm11, xmm1
0000792cceddc484  movaps [r15+0x250], xmm11
0000792cceddc48c  vmovaps [rsp+0x30], xmm12
0000792cceddc492  vmovaps xmm1, [rsp+0x30]
0000792cceddc498  por xmm12, xmm1
0000792cceddc49d  movaps [r15+0x2A0], xmm12
0000792cceddc4a5  vmovaps xmm1, [rsp+0xA0]
0000792cceddc4ae  vmovaps xmm11, [rsp+0xA0]
0000792cceddc4b7  por xmm1, xmm11
0000792cceddc4bc  movaps [r15+0x1D0], xmm1
0000792cceddc4c4  lea r12, [rax+0x40]
0000792cceddc4c8  movups xmm1, [r13+r12*1]
0000792cceddc4ce  movaps [r15+0x2C0], xmm1
0000792cceddc4d6  vmovaps xmm11, [rsp+0x40]
0000792cceddc4dc  vpermilpd xmm11, xmm11, 0x00
0000792cceddc4e2  vmovaps xmm8, [rsp+0xE0]
0000792cceddc4eb  movaps xmm9, xmm8
0000792cceddc4ef  mulpd xmm9, xmm11
0000792cceddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000792cceddc4fa  ptest xmm5, xmm5
0000792cceddc4ff  jnz 0x0000792CCEDDFC17
0000792cceddc505  movaps xmm11, xmm10
0000792cceddc509  addpd xmm11, xmm6
0000792cceddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000792cceddc514  ptest xmm8, xmm8
0000792cceddc51a  jnz 0x0000792CCEDDFD5B
0000792cceddc520  movaps xmm10, xmm14
0000792cceddc524  addpd xmm10, xmm4
0000792cceddc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000792cceddc52f  ptest xmm8, xmm8
0000792cceddc535  jnz 0x0000792CCEDDFE9E
0000792cceddc53b  vmovaps xmm14, [rsp+0x40]
0000792cceddc541  vpermilpd xmm14, xmm14, 0x00
0000792cceddc547  movaps xmm8, xmm1
0000792cceddc54b  mulpd xmm8, xmm14
0000792cceddc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000792cceddc556  ptest xmm6, xmm6
0000792cceddc55b  jnz 0x0000792CCEDDFFE1
0000792cceddc561  movaps xmm1, [r15+0x2B0]
0000792cceddc569  vmovaps xmm14, [rsp+0x40]
0000792cceddc56f  vpermilpd xmm14, xmm14, 0x00
0000792cceddc575  movaps xmm6, xmm1
0000792cceddc578  mulpd xmm6, xmm14
0000792cceddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000792cceddc582  ptest xmm5, xmm5
0000792cceddc587  jnz 0x0000792CCEDE0124
0000792cceddc58d  vmovaps xmm1, [rsp+0x10]
0000792cceddc593  vpermilpd xmm1, xmm1, 0x00
0000792cceddc599  movaps xmm14, xmm12
0000792cceddc59d  mulpd xmm14, xmm1
0000792cceddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000792cceddc5a8  ptest xmm5, xmm5
0000792cceddc5ad  jnz 0x0000792CCEDE0265
0000792cceddc5b3  movaps xmm1, xmm13
0000792cceddc5b7  addpd xmm1, xmm9
0000792cceddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000792cceddc5c1  ptest xmm12, xmm12
0000792cceddc5c7  jnz 0x0000792CCEDE03A8
0000792cceddc5cd  vmovaps xmm13, [rsp+0x10]
0000792cceddc5d3  vpermilpd xmm13, xmm13, 0x00
0000792cceddc5d9  movaps xmm12, xmm7
0000792cceddc5dd  mulpd xmm12, xmm13
0000792cceddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000792cceddc5e8  ptest xmm9, xmm9
0000792cceddc5ee  jnz 0x0000792CCEDE04EA
0000792cceddc5f4  movaps xmm13, xmm15
0000792cceddc5f8  addpd xmm13, xmm8
0000792cceddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000792cceddc603  ptest xmm9, xmm9
0000792cceddc609  jnz 0x0000792CCEDE062D
0000792cceddc60f  movaps xmm15, [r15+0x290]
0000792cceddc617  vmovaps xmm9, [rsp+0x10]
0000792cceddc61d  vpermilpd xmm9, xmm9, 0x00
0000792cceddc623  movaps xmm8, xmm15
0000792cceddc627  mulpd xmm8, xmm9
0000792cceddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000792cceddc632  ptest xmm7, xmm7
0000792cceddc637  jnz 0x0000792CCEDE0771
0000792cceddc63d  movaps xmm15, xmm11
0000792cceddc641  addpd xmm15, xmm6
0000792cceddc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000792cceddc64c  ptest xmm9, xmm9
0000792cceddc652  jnz 0x0000792CCEDE08B5
0000792cceddc658  movaps xmm11, [r15+0x1E0]
0000792cceddc660  vmovaps xmm9, [rsp+0x10]
0000792cceddc666  vpermilpd xmm9, xmm9, 0x00
0000792cceddc66c  movaps xmm7, xmm11
0000792cceddc670  mulpd xmm7, xmm9
0000792cceddc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000792cceddc67a  ptest xmm6, xmm6
0000792cceddc67f  jnz 0x0000792CCEDE09F8
0000792cceddc685  movaps xmm11, xmm10
0000792cceddc689  addpd xmm11, xmm14
0000792cceddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000792cceddc694  ptest xmm9, xmm9
0000792cceddc69a  jnz 0x0000792CCEDE0B3A
0000792cceddc6a0  lea r12, [rax+0x70]
0000792cceddc6a4  movups xmm14, [r13+r12*1]
0000792cceddc6aa  movaps [r15+0x240], xmm14
0000792cceddc6b2  movaps xmm10, xmm1
0000792cceddc6b6  addpd xmm10, xmm12
0000792cceddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000792cceddc6c1  ptest xmm9, xmm9
0000792cceddc6c7  jnz 0x0000792CCEDE0C88
0000792cceddc6cd  movaps [r15+0x170], xmm10
0000792cceddc6d5  vmovaps xmm1, [rsp+0x20]
0000792cceddc6db  vpermilpd xmm1, xmm1, 0x00
0000792cceddc6e1  movaps xmm12, xmm14
0000792cceddc6e5  mulpd xmm12, xmm1
0000792cceddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000792cceddc6f0  ptest xmm9, xmm9
0000792cceddc6f6  jnz 0x0000792CCEDE0DCB
0000792cceddc6fc  vmovaps xmm1, [rsp+0x20]
0000792cceddc702  vpermilpd xmm1, xmm1, 0x00
0000792cceddc708  vmovaps xmm9, [rsp+0xB0]
0000792cceddc711  movaps xmm14, xmm9
0000792cceddc715  mulpd xmm14, xmm1
0000792cceddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000792cceddc720  ptest xmm6, xmm6
0000792cceddc725  jnz 0x0000792CCEDE0F0E
0000792cceddc72b  movaps [r15+0x180], xmm14
0000792cceddc733  movaps xmm1, xmm13
0000792cceddc737  addpd xmm1, xmm8
0000792cceddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000792cceddc741  ptest xmm9, xmm9
0000792cceddc747  jnz 0x0000792CCEDE1051
0000792cceddc74d  movaps [r15+0x210], xmm1
0000792cceddc755  movups xmm13, [r13+rax*1]
0000792cceddc75b  lea r12, [rax+0x10]
0000792cceddc75f  movups xmm9, [r13+r12*1]
0000792cceddc765  movaps [r15+0x230], xmm9
0000792cceddc76d  movaps xmm8, xmm15
0000792cceddc771  addpd xmm8, xmm7
0000792cceddc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000792cceddc77c  ptest xmm6, xmm6
0000792cceddc781  jnz 0x0000792CCEDE11A7
0000792cceddc787  movaps [r15+0x130], xmm8
0000792cceddc78f  vmovaps xmm15, [rsp+0x20]
0000792cceddc795  vpermilpd xmm15, xmm15, 0x00
0000792cceddc79b  movaps xmm7, xmm9
0000792cceddc79f  mulpd xmm7, xmm15
0000792cceddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000792cceddc7a9  ptest xmm6, xmm6
0000792cceddc7ae  jnz 0x0000792CCEDE12EA
0000792cceddc7b4  movaps [r15+0x220], xmm7
0000792cceddc7bc  vmovaps xmm15, [rsp+0x20]
0000792cceddc7c2  vpermilpd xmm15, xmm15, 0x00
0000792cceddc7c8  movaps xmm9, xmm13
0000792cceddc7cc  mulpd xmm9, xmm15
0000792cceddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000792cceddc7d7  ptest xmm6, xmm6
0000792cceddc7dc  jnz 0x0000792CCEDE142C
0000792cceddc7e2  movaps xmm15, xmm11
0000792cceddc7e6  addpd xmm15, xmm12
0000792cceddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000792cceddc7f1  ptest xmm13, xmm13
0000792cceddc7f7  jnz 0x0000792CCEDE1570
0000792cceddc7fd  movaps [r15+0x140], xmm15
0000792cceddc805  movaps xmm13, xmm10
0000792cceddc809  addpd xmm13, xmm14
0000792cceddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000792cceddc814  ptest xmm12, xmm12
0000792cceddc81a  jnz 0x0000792CCEDE16B4
0000792cceddc820  movaps [r15+0x150], xmm13
0000792cceddc828  movaps xmm14, xmm1
0000792cceddc82c  addpd xmm14, xmm7
0000792cceddc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000792cceddc837  ptest xmm12, xmm12
0000792cceddc83d  jnz 0x0000792CCEDE17F8
0000792cceddc843  movaps [r15+0x160], xmm14
0000792cceddc84b  movaps xmm1, xmm8
0000792cceddc84f  addpd xmm1, xmm9
0000792cceddc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000792cceddc859  ptest xmm12, xmm12
0000792cceddc85f  jnz 0x0000792CCEDE193A
0000792cceddc865  movaps [r15+0x120], xmm1
0000792cceddc86d  movups [r13+r14*1], xmm15
0000792cceddc873  lea rax, [r14+0x10]
0000792cceddc877  movups [r13+rax*1], xmm13
0000792cceddc87d  lea rax, [r14+0x20]
0000792cceddc881  movups [r13+rax*1], xmm14
0000792cceddc887  lea rax, [r14+0x30]
0000792cceddc88b  movups [r13+rax*1], xmm1
0000792cceddc891  mov eax, [r15+0x108]
0000792cceddc898  sahf
0000792cceddc899  jnz 0x0000792CCEDDC8CB
0000792cceddc89b  cmp dword ptr [r15+0x318], 0x00
0000792cceddc8a3  jz 0x0000792CCEDDB900
0000792cceddc8a9  nop [rax+rax*1], ax
0000792cceddc8b2  nop [rax+rax*1], eax
0000792cceddc8ba  mov eax, 0x410444
0000792cceddc8bf  mov [r15+0x100], rax
0000792cceddc8c6  jmp 0x0000792CCEBFE110
0000792cceddc8cb  cmp dword ptr [r15+0x318], 0x00
0000792cceddc8d3  jz 0x0000792CCEDD57E0
0000792cceddc8d9  nop [rax+rax*1], ax
0000792cceddc8e2  nop [rax+rax*1], eax
0000792cceddc8ea  mov eax, 0x410278
0000792cceddc8ef  mov [r15+0x100], rax
0000792cceddc8f6  jmp 0x0000792CCEBFE110
0000792cceddc8fb  int3
0000792cceddc8fc  call 0x0000792CCECE27E0
0000792cceddc901  jmp 0x0000792CCEDDB9DF
0000792cceddc906  call 0x0000792CCECE1570
0000792cceddc90b  jmp 0x0000792CCEDDB9E8
0000792cceddc910  call 0x0000792CCECE27E0
0000792cceddc915  jmp 0x0000792CCEDDBA44
0000792cceddc91a  call 0x0000792CCECE1570
0000792cceddc91f  jmp 0x0000792CCEDDBA4D
0000792cceddc924  call 0x0000792CCECE27E0
0000792cceddc929  jmp 0x0000792CCEDDBA90
0000792cceddc92e  call 0x0000792CCECE1570
0000792cceddc933  jmp 0x0000792CCEDDBA99
0000792cceddc938  call 0x0000792CCEC0DC20
0000792cceddc93d  jmp 0x0000792CCEDDBAD8
0000792cceddc942  call 0x0000792CCECD59C0
0000792cceddc947  jmp 0x0000792CCEDDBAEB
0000792cceddc94c  call 0x0000792CCECE0E30
0000792cceddc951  jmp 0x0000792CCEDDBB09
0000792cceddc956  call 0x0000792CCECDFBC0
0000792cceddc95b  jmp 0x0000792CCEDDBB13
0000792cceddc960  call 0x0000792CCECDE950
0000792cceddc965  jmp 0x0000792CCEDDBB1D
0000792cceddc96a  sub rsp, 0x08
0000792cceddc96e  push rax
0000792cceddc96f  push rcx
0000792cceddc970  push rdx
0000792cceddc971  push rdi
0000792cceddc972  push rsi
0000792cceddc973  push r8
0000792cceddc975  push r9
0000792cceddc977  push r10
0000792cceddc979  push r11
0000792cceddc97b  sub rsp, 0xF0
0000792cceddc982  vmovaps [rsp], xmm0
0000792cceddc987  vmovaps [rsp+0x10], xmm1
0000792cceddc98d  vmovaps [rsp+0x20], xmm2
0000792cceddc993  vmovaps [rsp+0x30], xmm3
0000792cceddc999  vmovaps [rsp+0x40], xmm4
0000792cceddc99f  vmovaps [rsp+0x50], xmm5
0000792cceddc9a5  vmovaps [rsp+0x60], xmm6
0000792cceddc9ab  vmovaps [rsp+0x70], xmm7
0000792cceddc9b1  vmovaps [rsp+0x80], xmm9
0000792cceddc9ba  vmovaps [rsp+0x90], xmm10
0000792cceddc9c3  vmovaps [rsp+0xA0], xmm11
0000792cceddc9cc  vmovaps [rsp+0xB0], xmm12
0000792cceddc9d5  vmovaps [rsp+0xC0], xmm13
0000792cceddc9de  vmovaps [rsp+0xD0], xmm14
0000792cceddc9e7  vmovaps [rsp+0xE0], xmm15
0000792cceddc9f0  sub rsp, 0x30
0000792cceddc9f4  movaps [rsp], xmm8
0000792cceddc9f9  movaps [rsp+0x10], xmm12
0000792cceddc9ff  movaps [rsp+0x20], xmm15
0000792cceddca05  lea rdi, [rsp]
0000792cceddca09  mov esi, 0x00
0000792cceddca0e  mov rax, 0x5AEE2D541530
0000792cceddca18  call rax
0000792cceddca1a  movaps xmm8, [rsp]
0000792cceddca1f  add rsp, 0x30
0000792cceddca23  vmovaps xmm0, [rsp]
0000792cceddca28  vmovaps xmm1, [rsp+0x10]
0000792cceddca2e  vmovaps xmm2, [rsp+0x20]
0000792cceddca34  vmovaps xmm3, [rsp+0x30]
0000792cceddca3a  vmovaps xmm4, [rsp+0x40]
0000792cceddca40  vmovaps xmm5, [rsp+0x50]
0000792cceddca46  vmovaps xmm6, [rsp+0x60]
0000792cceddca4c  vmovaps xmm7, [rsp+0x70]
0000792cceddca52  vmovaps xmm9, [rsp+0x80]
0000792cceddca5b  vmovaps xmm10, [rsp+0x90]
0000792cceddca64  vmovaps xmm11, [rsp+0xA0]
0000792cceddca6d  vmovaps xmm12, [rsp+0xB0]
0000792cceddca76  vmovaps xmm13, [rsp+0xC0]
0000792cceddca7f  vmovaps xmm14, [rsp+0xD0]
0000792cceddca88  vmovaps xmm15, [rsp+0xE0]
0000792cceddca91  add rsp, 0xF0
0000792cceddca98  pop r11
0000792cceddca9a  pop r10
0000792cceddca9c  pop r9
0000792cceddca9e  pop r8
0000792cceddcaa0  pop rsi
0000792cceddcaa1  pop rdi
0000792cceddcaa2  pop rdx
0000792cceddcaa3  pop rcx
0000792cceddcaa4  pop rax
0000792cceddcaa5  add rsp, 0x08
0000792cceddcaa9  jmp 0x0000792CCEDDBB47
0000792cceddcaae  sub rsp, 0x08
0000792cceddcab2  push rax
0000792cceddcab3  push rcx
0000792cceddcab4  push rdx
0000792cceddcab5  push rdi
0000792cceddcab6  push rsi
0000792cceddcab7  push r8
0000792cceddcab9  push r9
0000792cceddcabb  push r10
0000792cceddcabd  push r11
0000792cceddcabf  sub rsp, 0xF0
0000792cceddcac6  vmovaps [rsp], xmm0
0000792cceddcacb  vmovaps [rsp+0x10], xmm1
0000792cceddcad1  vmovaps [rsp+0x20], xmm2
0000792cceddcad7  vmovaps [rsp+0x30], xmm3
0000792cceddcadd  vmovaps [rsp+0x40], xmm4
0000792cceddcae3  vmovaps [rsp+0x50], xmm5
0000792cceddcae9  vmovaps [rsp+0x60], xmm6
0000792cceddcaef  vmovaps [rsp+0x70], xmm8
0000792cceddcaf5  vmovaps [rsp+0x80], xmm9
0000792cceddcafe  vmovaps [rsp+0x90], xmm10
0000792cceddcb07  vmovaps [rsp+0xA0], xmm11
0000792cceddcb10  vmovaps [rsp+0xB0], xmm12
0000792cceddcb19  vmovaps [rsp+0xC0], xmm13
0000792cceddcb22  vmovaps [rsp+0xD0], xmm14
0000792cceddcb2b  vmovaps [rsp+0xE0], xmm15
0000792cceddcb34  sub rsp, 0x30
0000792cceddcb38  movaps [rsp], xmm7
0000792cceddcb3c  movaps [rsp+0x10], xmm9
0000792cceddcb42  movaps [rsp+0x20], xmm15
0000792cceddcb48  lea rdi, [rsp]
0000792cceddcb4c  mov esi, 0x00
0000792cceddcb51  mov rax, 0x5AEE2D541530
0000792cceddcb5b  call rax
0000792cceddcb5d  movaps xmm7, [rsp]
0000792cceddcb61  add rsp, 0x30
0000792cceddcb65  vmovaps xmm0, [rsp]
0000792cceddcb6a  vmovaps xmm1, [rsp+0x10]
0000792cceddcb70  vmovaps xmm2, [rsp+0x20]
0000792cceddcb76  vmovaps xmm3, [rsp+0x30]
0000792cceddcb7c  vmovaps xmm4, [rsp+0x40]
0000792cceddcb82  vmovaps xmm5, [rsp+0x50]
0000792cceddcb88  vmovaps xmm6, [rsp+0x60]
0000792cceddcb8e  vmovaps xmm8, [rsp+0x70]
0000792cceddcb94  vmovaps xmm9, [rsp+0x80]
0000792cceddcb9d  vmovaps xmm10, [rsp+0x90]
0000792cceddcba6  vmovaps xmm11, [rsp+0xA0]
0000792cceddcbaf  vmovaps xmm12, [rsp+0xB0]
0000792cceddcbb8  vmovaps xmm13, [rsp+0xC0]
0000792cceddcbc1  vmovaps xmm14, [rsp+0xD0]
0000792cceddcbca  vmovaps xmm15, [rsp+0xE0]
0000792cceddcbd3  add rsp, 0xF0
0000792cceddcbda  pop r11
0000792cceddcbdc  pop r10
0000792cceddcbde  pop r9
0000792cceddcbe0  pop r8
0000792cceddcbe2  pop rsi
0000792cceddcbe3  pop rdi
0000792cceddcbe4  pop rdx
0000792cceddcbe5  pop rcx
0000792cceddcbe6  pop rax
0000792cceddcbe7  add rsp, 0x08
0000792cceddcbeb  jmp 0x0000792CCEDDBB75
0000792cceddcbf0  sub rsp, 0x08
0000792cceddcbf4  push rax
0000792cceddcbf5  push rcx
0000792cceddcbf6  push rdx
0000792cceddcbf7  push rdi
0000792cceddcbf8  push rsi
0000792cceddcbf9  push r8
0000792cceddcbfb  push r9
0000792cceddcbfd  push r10
0000792cceddcbff  push r11
0000792cceddcc01  sub rsp, 0xF0
0000792cceddcc08  vmovaps [rsp], xmm0
0000792cceddcc0d  vmovaps [rsp+0x10], xmm1
0000792cceddcc13  vmovaps [rsp+0x20], xmm2
0000792cceddcc19  vmovaps [rsp+0x30], xmm3
0000792cceddcc1f  vmovaps [rsp+0x40], xmm4
0000792cceddcc25  vmovaps [rsp+0x50], xmm5
0000792cceddcc2b  vmovaps [rsp+0x60], xmm6
0000792cceddcc31  vmovaps [rsp+0x70], xmm7
0000792cceddcc37  vmovaps [rsp+0x80], xmm8
0000792cceddcc40  vmovaps [rsp+0x90], xmm10
0000792cceddcc49  vmovaps [rsp+0xA0], xmm11
0000792cceddcc52  vmovaps [rsp+0xB0], xmm12
0000792cceddcc5b  vmovaps [rsp+0xC0], xmm13
0000792cceddcc64  vmovaps [rsp+0xD0], xmm14
0000792cceddcc6d  vmovaps [rsp+0xE0], xmm15
0000792cceddcc76  sub rsp, 0x30
0000792cceddcc7a  movaps [rsp], xmm9
0000792cceddcc7f  movaps [rsp+0x10], xmm12
0000792cceddcc85  movaps [rsp+0x20], xmm10
0000792cceddcc8b  lea rdi, [rsp]
0000792cceddcc8f  mov esi, 0x00
0000792cceddcc94  mov rax, 0x5AEE2D541530
0000792cceddcc9e  call rax
0000792cceddcca0  movaps xmm9, [rsp]
0000792cceddcca5  add rsp, 0x30
0000792cceddcca9  vmovaps xmm0, [rsp]
0000792cceddccae  vmovaps xmm1, [rsp+0x10]
0000792cceddccb4  vmovaps xmm2, [rsp+0x20]
0000792cceddccba  vmovaps xmm3, [rsp+0x30]
0000792cceddccc0  vmovaps xmm4, [rsp+0x40]
0000792cceddccc6  vmovaps xmm5, [rsp+0x50]
0000792cceddcccc  vmovaps xmm6, [rsp+0x60]
0000792cceddccd2  vmovaps xmm7, [rsp+0x70]
0000792cceddccd8  vmovaps xmm8, [rsp+0x80]
0000792cceddcce1  vmovaps xmm10, [rsp+0x90]
0000792cceddccea  vmovaps xmm11, [rsp+0xA0]
0000792cceddccf3  vmovaps xmm12, [rsp+0xB0]
0000792cceddccfc  vmovaps xmm13, [rsp+0xC0]
0000792cceddcd05  vmovaps xmm14, [rsp+0xD0]
0000792cceddcd0e  vmovaps xmm15, [rsp+0xE0]
0000792cceddcd17  add rsp, 0xF0
0000792cceddcd1e  pop r11
0000792cceddcd20  pop r10
0000792cceddcd22  pop r9
0000792cceddcd24  pop r8
0000792cceddcd26  pop rsi
0000792cceddcd27  pop rdi
0000792cceddcd28  pop rdx
0000792cceddcd29  pop rcx
0000792cceddcd2a  pop rax
0000792cceddcd2b  add rsp, 0x08
0000792cceddcd2f  jmp 0x0000792CCEDDBB99
0000792cceddcd34  sub rsp, 0x08
0000792cceddcd38  push rax
0000792cceddcd39  push rcx
0000792cceddcd3a  push rdx
0000792cceddcd3b  push rdi
0000792cceddcd3c  push rsi
0000792cceddcd3d  push r8
0000792cceddcd3f  push r9
0000792cceddcd41  push r10
0000792cceddcd43  push r11
0000792cceddcd45  sub rsp, 0xF0
0000792cceddcd4c  vmovaps [rsp], xmm0
0000792cceddcd51  vmovaps [rsp+0x10], xmm1
0000792cceddcd57  vmovaps [rsp+0x20], xmm2
0000792cceddcd5d  vmovaps [rsp+0x30], xmm3
0000792cceddcd63  vmovaps [rsp+0x40], xmm4
0000792cceddcd69  vmovaps [rsp+0x50], xmm5
0000792cceddcd6f  vmovaps [rsp+0x60], xmm6
0000792cceddcd75  vmovaps [rsp+0x70], xmm7
0000792cceddcd7b  vmovaps [rsp+0x80], xmm8
0000792cceddcd84  vmovaps [rsp+0x90], xmm9
0000792cceddcd8d  vmovaps [rsp+0xA0], xmm11
0000792cceddcd96  vmovaps [rsp+0xB0], xmm12
0000792cceddcd9f  vmovaps [rsp+0xC0], xmm13
0000792cceddcda8  vmovaps [rsp+0xD0], xmm14
0000792cceddcdb1  vmovaps [rsp+0xE0], xmm15
0000792cceddcdba  sub rsp, 0x30
0000792cceddcdbe  movaps [rsp], xmm10
0000792cceddcdc3  movaps [rsp+0x10], xmm12
0000792cceddcdc9  movaps [rsp+0x20], xmm11
0000792cceddcdcf  lea rdi, [rsp]
0000792cceddcdd3  mov esi, 0x00
0000792cceddcdd8  mov rax, 0x5AEE2D541530
0000792cceddcde2  call rax
0000792cceddcde4  movaps xmm10, [rsp]
0000792cceddcde9  add rsp, 0x30
0000792cceddcded  vmovaps xmm0, [rsp]
0000792cceddcdf2  vmovaps xmm1, [rsp+0x10]
0000792cceddcdf8  vmovaps xmm2, [rsp+0x20]
0000792cceddcdfe  vmovaps xmm3, [rsp+0x30]
0000792cceddce04  vmovaps xmm4, [rsp+0x40]
0000792cceddce0a  vmovaps xmm5, [rsp+0x50]
0000792cceddce10  vmovaps xmm6, [rsp+0x60]
0000792cceddce16  vmovaps xmm7, [rsp+0x70]
0000792cceddce1c  vmovaps xmm8, [rsp+0x80]
0000792cceddce25  vmovaps xmm9, [rsp+0x90]
0000792cceddce2e  vmovaps xmm11, [rsp+0xA0]
0000792cceddce37  vmovaps xmm12, [rsp+0xB0]
0000792cceddce40  vmovaps xmm13, [rsp+0xC0]
0000792cceddce49  vmovaps xmm14, [rsp+0xD0]
0000792cceddce52  vmovaps xmm15, [rsp+0xE0]
0000792cceddce5b  add rsp, 0xF0
0000792cceddce62  pop r11
0000792cceddce64  pop r10
0000792cceddce66  pop r9
0000792cceddce68  pop r8
0000792cceddce6a  pop rsi
0000792cceddce6b  pop rdi
0000792cceddce6c  pop rdx
0000792cceddce6d  pop rcx
0000792cceddce6e  pop rax
0000792cceddce6f  add rsp, 0x08
0000792cceddce73  jmp 0x0000792CCEDDBBB3
0000792cceddce78  sub rsp, 0x08
0000792cceddce7c  push rax
0000792cceddce7d  push rcx
0000792cceddce7e  push rdx
0000792cceddce7f  push rdi
0000792cceddce80  push rsi
0000792cceddce81  push r8
0000792cceddce83  push r9
0000792cceddce85  push r10
0000792cceddce87  push r11
0000792cceddce89  sub rsp, 0xF0
0000792cceddce90  vmovaps [rsp], xmm0
0000792cceddce95  vmovaps [rsp+0x10], xmm1
0000792cceddce9b  vmovaps [rsp+0x20], xmm2
0000792cceddcea1  vmovaps [rsp+0x30], xmm3
0000792cceddcea7  vmovaps [rsp+0x40], xmm4
0000792cceddcead  vmovaps [rsp+0x50], xmm5
0000792cceddceb3  vmovaps [rsp+0x60], xmm7
0000792cceddceb9  vmovaps [rsp+0x70], xmm8
0000792cceddcebf  vmovaps [rsp+0x80], xmm9
0000792cceddcec8  vmovaps [rsp+0x90], xmm10
0000792cceddced1  vmovaps [rsp+0xA0], xmm11
0000792cceddceda  vmovaps [rsp+0xB0], xmm12
0000792cceddcee3  vmovaps [rsp+0xC0], xmm13
0000792cceddceec  vmovaps [rsp+0xD0], xmm14
0000792cceddcef5  vmovaps [rsp+0xE0], xmm15
0000792cceddcefe  sub rsp, 0x30
0000792cceddcf02  movaps [rsp], xmm6
0000792cceddcf06  movaps [rsp+0x10], xmm12
0000792cceddcf0c  movaps [rsp+0x20], xmm11
0000792cceddcf12  lea rdi, [rsp]
0000792cceddcf16  mov esi, 0x00
0000792cceddcf1b  mov rax, 0x5AEE2D541530
0000792cceddcf25  call rax
0000792cceddcf27  movaps xmm6, [rsp]
0000792cceddcf2b  add rsp, 0x30
0000792cceddcf2f  vmovaps xmm0, [rsp]
0000792cceddcf34  vmovaps xmm1, [rsp+0x10]
0000792cceddcf3a  vmovaps xmm2, [rsp+0x20]
0000792cceddcf40  vmovaps xmm3, [rsp+0x30]
0000792cceddcf46  vmovaps xmm4, [rsp+0x40]
0000792cceddcf4c  vmovaps xmm5, [rsp+0x50]
0000792cceddcf52  vmovaps xmm7, [rsp+0x60]
0000792cceddcf58  vmovaps xmm8, [rsp+0x70]
0000792cceddcf5e  vmovaps xmm9, [rsp+0x80]
0000792cceddcf67  vmovaps xmm10, [rsp+0x90]
0000792cceddcf70  vmovaps xmm11, [rsp+0xA0]
0000792cceddcf79  vmovaps xmm12, [rsp+0xB0]
0000792cceddcf82  vmovaps xmm13, [rsp+0xC0]
0000792cceddcf8b  vmovaps xmm14, [rsp+0xD0]
0000792cceddcf94  vmovaps xmm15, [rsp+0xE0]
0000792cceddcf9d  add rsp, 0xF0
0000792cceddcfa4  pop r11
0000792cceddcfa6  pop r10
0000792cceddcfa8  pop r9
0000792cceddcfaa  pop r8
0000792cceddcfac  pop rsi
0000792cceddcfad  pop rdi
0000792cceddcfae  pop rdx
0000792cceddcfaf  pop rcx
0000792cceddcfb0  pop rax
0000792cceddcfb1  add rsp, 0x08
0000792cceddcfb5  jmp 0x0000792CCEDDBBD4
0000792cceddcfba  sub rsp, 0x08
0000792cceddcfbe  push rax
0000792cceddcfbf  push rcx
0000792cceddcfc0  push rdx
0000792cceddcfc1  push rdi
0000792cceddcfc2  push rsi
0000792cceddcfc3  push r8
0000792cceddcfc5  push r9
0000792cceddcfc7  push r10
0000792cceddcfc9  push r11
0000792cceddcfcb  sub rsp, 0xF0
0000792cceddcfd2  vmovaps [rsp], xmm0
0000792cceddcfd7  vmovaps [rsp+0x10], xmm1
0000792cceddcfdd  vmovaps [rsp+0x20], xmm2
0000792cceddcfe3  vmovaps [rsp+0x30], xmm4
0000792cceddcfe9  vmovaps [rsp+0x40], xmm5
0000792cceddcfef  vmovaps [rsp+0x50], xmm6
0000792cceddcff5  vmovaps [rsp+0x60], xmm7
0000792cceddcffb  vmovaps [rsp+0x70], xmm8
0000792cceddd001  vmovaps [rsp+0x80], xmm9
0000792cceddd00a  vmovaps [rsp+0x90], xmm10
0000792cceddd013  vmovaps [rsp+0xA0], xmm11
0000792cceddd01c  vmovaps [rsp+0xB0], xmm12
0000792cceddd025  vmovaps [rsp+0xC0], xmm13
0000792cceddd02e  vmovaps [rsp+0xD0], xmm14
0000792cceddd037  vmovaps [rsp+0xE0], xmm15
0000792cceddd040  sub rsp, 0x30
0000792cceddd044  movaps [rsp], xmm3
0000792cceddd048  movaps [rsp+0x10], xmm5
0000792cceddd04d  movaps [rsp+0x20], xmm4
0000792cceddd052  lea rdi, [rsp]
0000792cceddd056  mov esi, 0x00
0000792cceddd05b  mov rax, 0x5AEE2D541530
0000792cceddd065  call rax
0000792cceddd067  movaps xmm3, [rsp]
0000792cceddd06b  add rsp, 0x30
0000792cceddd06f  vmovaps xmm0, [rsp]
0000792cceddd074  vmovaps xmm1, [rsp+0x10]
0000792cceddd07a  vmovaps xmm2, [rsp+0x20]
0000792cceddd080  vmovaps xmm4, [rsp+0x30]
0000792cceddd086  vmovaps xmm5, [rsp+0x40]
0000792cceddd08c  vmovaps xmm6, [rsp+0x50]
0000792cceddd092  vmovaps xmm7, [rsp+0x60]
0000792cceddd098  vmovaps xmm8, [rsp+0x70]
0000792cceddd09e  vmovaps xmm9, [rsp+0x80]
0000792cceddd0a7  vmovaps xmm10, [rsp+0x90]
0000792cceddd0b0  vmovaps xmm11, [rsp+0xA0]
0000792cceddd0b9  vmovaps xmm12, [rsp+0xB0]
0000792cceddd0c2  vmovaps xmm13, [rsp+0xC0]
0000792cceddd0cb  vmovaps xmm14, [rsp+0xD0]
0000792cceddd0d4  vmovaps xmm15, [rsp+0xE0]
0000792cceddd0dd  add rsp, 0xF0
0000792cceddd0e4  pop r11
0000792cceddd0e6  pop r10
0000792cceddd0e8  pop r9
0000792cceddd0ea  pop r8
0000792cceddd0ec  pop rsi
0000792cceddd0ed  pop rdi
0000792cceddd0ee  pop rdx
0000792cceddd0ef  pop rcx
0000792cceddd0f0  pop rax
0000792cceddd0f1  add rsp, 0x08
0000792cceddd0f5  jmp 0x0000792CCEDDBC35
0000792cceddd0fa  sub rsp, 0x08
0000792cceddd0fe  push rax
0000792cceddd0ff  push rcx
0000792cceddd100  push rdx
0000792cceddd101  push rdi
0000792cceddd102  push rsi
0000792cceddd103  push r8
0000792cceddd105  push r9
0000792cceddd107  push r10
0000792cceddd109  push r11
0000792cceddd10b  sub rsp, 0xF0
0000792cceddd112  vmovaps [rsp], xmm0
0000792cceddd117  vmovaps [rsp+0x10], xmm1
0000792cceddd11d  vmovaps [rsp+0x20], xmm2
0000792cceddd123  vmovaps [rsp+0x30], xmm3
0000792cceddd129  vmovaps [rsp+0x40], xmm4
0000792cceddd12f  vmovaps [rsp+0x50], xmm6
0000792cceddd135  vmovaps [rsp+0x60], xmm7
0000792cceddd13b  vmovaps [rsp+0x70], xmm8
0000792cceddd141  vmovaps [rsp+0x80], xmm9
0000792cceddd14a  vmovaps [rsp+0x90], xmm10
0000792cceddd153  vmovaps [rsp+0xA0], xmm11
0000792cceddd15c  vmovaps [rsp+0xB0], xmm12
0000792cceddd165  vmovaps [rsp+0xC0], xmm13
0000792cceddd16e  vmovaps [rsp+0xD0], xmm14
0000792cceddd177  vmovaps [rsp+0xE0], xmm15
0000792cceddd180  sub rsp, 0x30
0000792cceddd184  movaps [rsp], xmm5
0000792cceddd188  movaps [rsp+0x10], xmm8
0000792cceddd18e  movaps [rsp+0x20], xmm15
0000792cceddd194  lea rdi, [rsp]
0000792cceddd198  mov esi, 0x00
0000792cceddd19d  mov rax, 0x5AEE2D541530
0000792cceddd1a7  call rax
0000792cceddd1a9  movaps xmm5, [rsp]
0000792cceddd1ad  add rsp, 0x30
0000792cceddd1b1  vmovaps xmm0, [rsp]
0000792cceddd1b6  vmovaps xmm1, [rsp+0x10]
0000792cceddd1bc  vmovaps xmm2, [rsp+0x20]
0000792cceddd1c2  vmovaps xmm3, [rsp+0x30]
0000792cceddd1c8  vmovaps xmm4, [rsp+0x40]
0000792cceddd1ce  vmovaps xmm6, [rsp+0x50]
0000792cceddd1d4  vmovaps xmm7, [rsp+0x60]
0000792cceddd1da  vmovaps xmm8, [rsp+0x70]
0000792cceddd1e0  vmovaps xmm9, [rsp+0x80]
0000792cceddd1e9  vmovaps xmm10, [rsp+0x90]
0000792cceddd1f2  vmovaps xmm11, [rsp+0xA0]
0000792cceddd1fb  vmovaps xmm12, [rsp+0xB0]
0000792cceddd204  vmovaps xmm13, [rsp+0xC0]
0000792cceddd20d  vmovaps xmm14, [rsp+0xD0]
0000792cceddd216  vmovaps xmm15, [rsp+0xE0]
0000792cceddd21f  add rsp, 0xF0
0000792cceddd226  pop r11
0000792cceddd228  pop r10
0000792cceddd22a  pop r9
0000792cceddd22c  pop r8
0000792cceddd22e  pop rsi
0000792cceddd22f  pop rdi
0000792cceddd230  pop rdx
0000792cceddd231  pop rcx
0000792cceddd232  pop rax
0000792cceddd233  add rsp, 0x08
0000792cceddd237  jmp 0x0000792CCEDDBC73
0000792cceddd23c  sub rsp, 0x08
0000792cceddd240  push rax
0000792cceddd241  push rcx
0000792cceddd242  push rdx
0000792cceddd243  push rdi
0000792cceddd244  push rsi
0000792cceddd245  push r8
0000792cceddd247  push r9
0000792cceddd249  push r10
0000792cceddd24b  push r11
0000792cceddd24d  sub rsp, 0xF0
0000792cceddd254  vmovaps [rsp], xmm0
0000792cceddd259  vmovaps [rsp+0x10], xmm1
0000792cceddd25f  vmovaps [rsp+0x20], xmm2
0000792cceddd265  vmovaps [rsp+0x30], xmm3
0000792cceddd26b  vmovaps [rsp+0x40], xmm5
0000792cceddd271  vmovaps [rsp+0x50], xmm6
0000792cceddd277  vmovaps [rsp+0x60], xmm7
0000792cceddd27d  vmovaps [rsp+0x70], xmm8
0000792cceddd283  vmovaps [rsp+0x80], xmm9
0000792cceddd28c  vmovaps [rsp+0x90], xmm10
0000792cceddd295  vmovaps [rsp+0xA0], xmm11
0000792cceddd29e  vmovaps [rsp+0xB0], xmm12
0000792cceddd2a7  vmovaps [rsp+0xC0], xmm13
0000792cceddd2b0  vmovaps [rsp+0xD0], xmm14
0000792cceddd2b9  vmovaps [rsp+0xE0], xmm15
0000792cceddd2c2  sub rsp, 0x30
0000792cceddd2c6  movaps [rsp], xmm4
0000792cceddd2ca  movaps [rsp+0x10], xmm9
0000792cceddd2d0  movaps [rsp+0x20], xmm8
0000792cceddd2d6  lea rdi, [rsp]
0000792cceddd2da  mov esi, 0x00
0000792cceddd2df  mov rax, 0x5AEE2D541530
0000792cceddd2e9  call rax
0000792cceddd2eb  movaps xmm4, [rsp]
0000792cceddd2ef  add rsp, 0x30
0000792cceddd2f3  vmovaps xmm0, [rsp]
0000792cceddd2f8  vmovaps xmm1, [rsp+0x10]
0000792cceddd2fe  vmovaps xmm2, [rsp+0x20]
0000792cceddd304  vmovaps xmm3, [rsp+0x30]
0000792cceddd30a  vmovaps xmm5, [rsp+0x40]
0000792cceddd310  vmovaps xmm6, [rsp+0x50]
0000792cceddd316  vmovaps xmm7, [rsp+0x60]
0000792cceddd31c  vmovaps xmm8, [rsp+0x70]
0000792cceddd322  vmovaps xmm9, [rsp+0x80]
0000792cceddd32b  vmovaps xmm10, [rsp+0x90]
0000792cceddd334  vmovaps xmm11, [rsp+0xA0]
0000792cceddd33d  vmovaps xmm12, [rsp+0xB0]
0000792cceddd346  vmovaps xmm13, [rsp+0xC0]
0000792cceddd34f  vmovaps xmm14, [rsp+0xD0]
0000792cceddd358  vmovaps xmm15, [rsp+0xE0]
0000792cceddd361  add rsp, 0xF0
0000792cceddd368  pop r11
0000792cceddd36a  pop r10
0000792cceddd36c  pop r9
0000792cceddd36e  pop r8
0000792cceddd370  pop rsi
0000792cceddd371  pop rdi
0000792cceddd372  pop rdx
0000792cceddd373  pop rcx
0000792cceddd374  pop rax
0000792cceddd375  add rsp, 0x08
0000792cceddd379  jmp 0x0000792CCEDDBC94
0000792cceddd37e  sub rsp, 0x08
0000792cceddd382  push rax
0000792cceddd383  push rcx
0000792cceddd384  push rdx
0000792cceddd385  push rdi
0000792cceddd386  push rsi
0000792cceddd387  push r8
0000792cceddd389  push r9
0000792cceddd38b  push r10
0000792cceddd38d  push r11
0000792cceddd38f  sub rsp, 0xF0
0000792cceddd396  vmovaps [rsp], xmm0
0000792cceddd39b  vmovaps [rsp+0x10], xmm1
0000792cceddd3a1  vmovaps [rsp+0x20], xmm2
0000792cceddd3a7  vmovaps [rsp+0x30], xmm3
0000792cceddd3ad  vmovaps [rsp+0x40], xmm4
0000792cceddd3b3  vmovaps [rsp+0x50], xmm5
0000792cceddd3b9  vmovaps [rsp+0x60], xmm6
0000792cceddd3bf  vmovaps [rsp+0x70], xmm7
0000792cceddd3c5  vmovaps [rsp+0x80], xmm8
0000792cceddd3ce  vmovaps [rsp+0x90], xmm10
0000792cceddd3d7  vmovaps [rsp+0xA0], xmm11
0000792cceddd3e0  vmovaps [rsp+0xB0], xmm12
0000792cceddd3e9  vmovaps [rsp+0xC0], xmm13
0000792cceddd3f2  vmovaps [rsp+0xD0], xmm14
0000792cceddd3fb  vmovaps [rsp+0xE0], xmm15
0000792cceddd404  sub rsp, 0x30
0000792cceddd408  movaps [rsp], xmm9
0000792cceddd40d  movaps [rsp+0x10], xmm10
0000792cceddd413  movaps [rsp+0x20], xmm8
0000792cceddd419  lea rdi, [rsp]
0000792cceddd41d  mov esi, 0x00
0000792cceddd422  mov rax, 0x5AEE2D541530
0000792cceddd42c  call rax
0000792cceddd42e  movaps xmm9, [rsp]
0000792cceddd433  add rsp, 0x30
0000792cceddd437  vmovaps xmm0, [rsp]
0000792cceddd43c  vmovaps xmm1, [rsp+0x10]
0000792cceddd442  vmovaps xmm2, [rsp+0x20]
0000792cceddd448  vmovaps xmm3, [rsp+0x30]
0000792cceddd44e  vmovaps xmm4, [rsp+0x40]
0000792cceddd454  vmovaps xmm5, [rsp+0x50]
0000792cceddd45a  vmovaps xmm6, [rsp+0x60]
0000792cceddd460  vmovaps xmm7, [rsp+0x70]
0000792cceddd466  vmovaps xmm8, [rsp+0x80]
0000792cceddd46f  vmovaps xmm10, [rsp+0x90]
0000792cceddd478  vmovaps xmm11, [rsp+0xA0]
0000792cceddd481  vmovaps xmm12, [rsp+0xB0]
0000792cceddd48a  vmovaps xmm13, [rsp+0xC0]
0000792cceddd493  vmovaps xmm14, [rsp+0xD0]
0000792cceddd49c  vmovaps xmm15, [rsp+0xE0]
0000792cceddd4a5  add rsp, 0xF0
0000792cceddd4ac  pop r11
0000792cceddd4ae  pop r10
0000792cceddd4b0  pop r9
0000792cceddd4b2  pop r8
0000792cceddd4b4  pop rsi
0000792cceddd4b5  pop rdi
0000792cceddd4b6  pop rdx
0000792cceddd4b7  pop rcx
0000792cceddd4b8  pop rax
0000792cceddd4b9  add rsp, 0x08
0000792cceddd4bd  jmp 0x0000792CCEDDBCAE
0000792cceddd4c2  call 0x0000792CCECB52F0
0000792cceddd4c7  jmp 0x0000792CCEDDBDC8
0000792cceddd4cc  call 0x0000792CCECB52F0
0000792cceddd4d1  jmp 0x0000792CCEDDBDDE
0000792cceddd4d6  sub rsp, 0x08
0000792cceddd4da  push rax
0000792cceddd4db  push rcx
0000792cceddd4dc  push rdx
0000792cceddd4dd  push rdi
0000792cceddd4de  push rsi
0000792cceddd4df  push r8
0000792cceddd4e1  push r9
0000792cceddd4e3  push r10
0000792cceddd4e5  push r11
0000792cceddd4e7  sub rsp, 0xF0
0000792cceddd4ee  vmovaps [rsp], xmm0
0000792cceddd4f3  vmovaps [rsp+0x10], xmm2
0000792cceddd4f9  vmovaps [rsp+0x20], xmm3
0000792cceddd4ff  vmovaps [rsp+0x30], xmm4
0000792cceddd505  vmovaps [rsp+0x40], xmm5
0000792cceddd50b  vmovaps [rsp+0x50], xmm6
0000792cceddd511  vmovaps [rsp+0x60], xmm7
0000792cceddd517  vmovaps [rsp+0x70], xmm8
0000792cceddd51d  vmovaps [rsp+0x80], xmm9
0000792cceddd526  vmovaps [rsp+0x90], xmm10
0000792cceddd52f  vmovaps [rsp+0xA0], xmm11
0000792cceddd538  vmovaps [rsp+0xB0], xmm12
0000792cceddd541  vmovaps [rsp+0xC0], xmm13
0000792cceddd54a  vmovaps [rsp+0xD0], xmm14
0000792cceddd553  vmovaps [rsp+0xE0], xmm15
0000792cceddd55c  sub rsp, 0x30
0000792cceddd560  movaps [rsp], xmm1
0000792cceddd564  movaps [rsp+0x10], xmm6
0000792cceddd569  movaps [rsp+0x20], xmm15
0000792cceddd56f  lea rdi, [rsp]
0000792cceddd573  mov esi, 0x00
0000792cceddd578  mov rax, 0x5AEE2D541530
0000792cceddd582  call rax
0000792cceddd584  movaps xmm1, [rsp]
0000792cceddd588  add rsp, 0x30
0000792cceddd58c  vmovaps xmm0, [rsp]
0000792cceddd591  vmovaps xmm2, [rsp+0x10]
0000792cceddd597  vmovaps xmm3, [rsp+0x20]
0000792cceddd59d  vmovaps xmm4, [rsp+0x30]
0000792cceddd5a3  vmovaps xmm5, [rsp+0x40]
0000792cceddd5a9  vmovaps xmm6, [rsp+0x50]
0000792cceddd5af  vmovaps xmm7, [rsp+0x60]
0000792cceddd5b5  vmovaps xmm8, [rsp+0x70]
0000792cceddd5bb  vmovaps xmm9, [rsp+0x80]
0000792cceddd5c4  vmovaps xmm10, [rsp+0x90]
0000792cceddd5cd  vmovaps xmm11, [rsp+0xA0]
0000792cceddd5d6  vmovaps xmm12, [rsp+0xB0]
0000792cceddd5df  vmovaps xmm13, [rsp+0xC0]
0000792cceddd5e8  vmovaps xmm14, [rsp+0xD0]
0000792cceddd5f1  vmovaps xmm15, [rsp+0xE0]
0000792cceddd5fa  add rsp, 0xF0
0000792cceddd601  pop r11
0000792cceddd603  pop r10
0000792cceddd605  pop r9
0000792cceddd607  pop r8
0000792cceddd609  pop rsi
0000792cceddd60a  pop rdi
0000792cceddd60b  pop rdx
0000792cceddd60c  pop rcx
0000792cceddd60d  pop rax
0000792cceddd60e  add rsp, 0x08
0000792cceddd612  jmp 0x0000792CCEDDBE1B
0000792cceddd617  call 0x0000792CCECC4620
0000792cceddd61c  jmp 0x0000792CCEDDBE28
0000792cceddd621  sub rsp, 0x08
0000792cceddd625  push rax
0000792cceddd626  push rcx
0000792cceddd627  push rdx
0000792cceddd628  push rdi
0000792cceddd629  push rsi
0000792cceddd62a  push r8
0000792cceddd62c  push r9
0000792cceddd62e  push r10
0000792cceddd630  push r11
0000792cceddd632  sub rsp, 0xF0
0000792cceddd639  vmovaps [rsp], xmm0
0000792cceddd63e  vmovaps [rsp+0x10], xmm1
0000792cceddd644  vmovaps [rsp+0x20], xmm2
0000792cceddd64a  vmovaps [rsp+0x30], xmm3
0000792cceddd650  vmovaps [rsp+0x40], xmm4
0000792cceddd656  vmovaps [rsp+0x50], xmm5
0000792cceddd65c  vmovaps [rsp+0x60], xmm6
0000792cceddd662  vmovaps [rsp+0x70], xmm7
0000792cceddd668  vmovaps [rsp+0x80], xmm8
0000792cceddd671  vmovaps [rsp+0x90], xmm9
0000792cceddd67a  vmovaps [rsp+0xA0], xmm10
0000792cceddd683  vmovaps [rsp+0xB0], xmm11
0000792cceddd68c  vmovaps [rsp+0xC0], xmm12
0000792cceddd695  vmovaps [rsp+0xD0], xmm13
0000792cceddd69e  vmovaps [rsp+0xE0], xmm15
0000792cceddd6a7  sub rsp, 0x30
0000792cceddd6ab  movaps [rsp], xmm14
0000792cceddd6b0  movaps [rsp+0x10], xmm4
0000792cceddd6b5  movaps [rsp+0x20], xmm3
0000792cceddd6ba  lea rdi, [rsp]
0000792cceddd6be  mov esi, 0x00
0000792cceddd6c3  mov rax, 0x5AEE2D541530
0000792cceddd6cd  call rax
0000792cceddd6cf  movaps xmm14, [rsp]
0000792cceddd6d4  add rsp, 0x30
0000792cceddd6d8  vmovaps xmm0, [rsp]
0000792cceddd6dd  vmovaps xmm1, [rsp+0x10]
0000792cceddd6e3  vmovaps xmm2, [rsp+0x20]
0000792cceddd6e9  vmovaps xmm3, [rsp+0x30]
0000792cceddd6ef  vmovaps xmm4, [rsp+0x40]
0000792cceddd6f5  vmovaps xmm5, [rsp+0x50]
0000792cceddd6fb  vmovaps xmm6, [rsp+0x60]
0000792cceddd701  vmovaps xmm7, [rsp+0x70]
0000792cceddd707  vmovaps xmm8, [rsp+0x80]
0000792cceddd710  vmovaps xmm9, [rsp+0x90]
0000792cceddd719  vmovaps xmm10, [rsp+0xA0]
0000792cceddd722  vmovaps xmm11, [rsp+0xB0]
0000792cceddd72b  vmovaps xmm12, [rsp+0xC0]
0000792cceddd734  vmovaps xmm13, [rsp+0xD0]
0000792cceddd73d  vmovaps xmm15, [rsp+0xE0]
0000792cceddd746  add rsp, 0xF0
0000792cceddd74d  pop r11
0000792cceddd74f  pop r10
0000792cceddd751  pop r9
0000792cceddd753  pop r8
0000792cceddd755  pop rsi
0000792cceddd756  pop rdi
0000792cceddd757  pop rdx
0000792cceddd758  pop rcx
0000792cceddd759  pop rax
0000792cceddd75a  add rsp, 0x08
0000792cceddd75e  jmp 0x0000792CCEDDBE42
0000792cceddd763  sub rsp, 0x08
0000792cceddd767  push rax
0000792cceddd768  push rcx
0000792cceddd769  push rdx
0000792cceddd76a  push rdi
0000792cceddd76b  push rsi
0000792cceddd76c  push r8
0000792cceddd76e  push r9
0000792cceddd770  push r10
0000792cceddd772  push r11
0000792cceddd774  sub rsp, 0xF0
0000792cceddd77b  vmovaps [rsp], xmm0
0000792cceddd780  vmovaps [rsp+0x10], xmm1
0000792cceddd786  vmovaps [rsp+0x20], xmm2
0000792cceddd78c  vmovaps [rsp+0x30], xmm3
0000792cceddd792  vmovaps [rsp+0x40], xmm4
0000792cceddd798  vmovaps [rsp+0x50], xmm5
0000792cceddd79e  vmovaps [rsp+0x60], xmm7
0000792cceddd7a4  vmovaps [rsp+0x70], xmm8
0000792cceddd7aa  vmovaps [rsp+0x80], xmm9
0000792cceddd7b3  vmovaps [rsp+0x90], xmm10
0000792cceddd7bc  vmovaps [rsp+0xA0], xmm11
0000792cceddd7c5  vmovaps [rsp+0xB0], xmm12
0000792cceddd7ce  vmovaps [rsp+0xC0], xmm13
0000792cceddd7d7  vmovaps [rsp+0xD0], xmm14
0000792cceddd7e0  vmovaps [rsp+0xE0], xmm15
0000792cceddd7e9  sub rsp, 0x30
0000792cceddd7ed  movaps [rsp], xmm6
0000792cceddd7f1  movaps [rsp+0x10], xmm9
0000792cceddd7f7  movaps [rsp+0x20], xmm7
0000792cceddd7fc  lea rdi, [rsp]
0000792cceddd800  mov esi, 0x00
0000792cceddd805  mov rax, 0x5AEE2D541530
0000792cceddd80f  call rax
0000792cceddd811  movaps xmm6, [rsp]
0000792cceddd815  add rsp, 0x30
0000792cceddd819  vmovaps xmm0, [rsp]
0000792cceddd81e  vmovaps xmm1, [rsp+0x10]
0000792cceddd824  vmovaps xmm2, [rsp+0x20]
0000792cceddd82a  vmovaps xmm3, [rsp+0x30]
0000792cceddd830  vmovaps xmm4, [rsp+0x40]
0000792cceddd836  vmovaps xmm5, [rsp+0x50]
0000792cceddd83c  vmovaps xmm7, [rsp+0x60]
0000792cceddd842  vmovaps xmm8, [rsp+0x70]
0000792cceddd848  vmovaps xmm9, [rsp+0x80]
0000792cceddd851  vmovaps xmm10, [rsp+0x90]
0000792cceddd85a  vmovaps xmm11, [rsp+0xA0]
0000792cceddd863  vmovaps xmm12, [rsp+0xB0]
0000792cceddd86c  vmovaps xmm13, [rsp+0xC0]
0000792cceddd875  vmovaps xmm14, [rsp+0xD0]
0000792cceddd87e  vmovaps xmm15, [rsp+0xE0]
0000792cceddd887  add rsp, 0xF0
0000792cceddd88e  pop r11
0000792cceddd890  pop r10
0000792cceddd892  pop r9
0000792cceddd894  pop r8
0000792cceddd896  pop rsi
0000792cceddd897  pop rdi
0000792cceddd898  pop rdx
0000792cceddd899  pop rcx
0000792cceddd89a  pop rax
0000792cceddd89b  add rsp, 0x08
0000792cceddd89f  jmp 0x0000792CCEDDBE5A
0000792cceddd8a4  sub rsp, 0x08
0000792cceddd8a8  push rax
0000792cceddd8a9  push rcx
0000792cceddd8aa  push rdx
0000792cceddd8ab  push rdi
0000792cceddd8ac  push rsi
0000792cceddd8ad  push r8
0000792cceddd8af  push r9
0000792cceddd8b1  push r10
0000792cceddd8b3  push r11
0000792cceddd8b5  sub rsp, 0xF0
0000792cceddd8bc  vmovaps [rsp], xmm0
0000792cceddd8c1  vmovaps [rsp+0x10], xmm1
0000792cceddd8c7  vmovaps [rsp+0x20], xmm2
0000792cceddd8cd  vmovaps [rsp+0x30], xmm3
0000792cceddd8d3  vmovaps [rsp+0x40], xmm4
0000792cceddd8d9  vmovaps [rsp+0x50], xmm5
0000792cceddd8df  vmovaps [rsp+0x60], xmm6
0000792cceddd8e5  vmovaps [rsp+0x70], xmm8
0000792cceddd8eb  vmovaps [rsp+0x80], xmm9
0000792cceddd8f4  vmovaps [rsp+0x90], xmm10
0000792cceddd8fd  vmovaps [rsp+0xA0], xmm11
0000792cceddd906  vmovaps [rsp+0xB0], xmm12
0000792cceddd90f  vmovaps [rsp+0xC0], xmm13
0000792cceddd918  vmovaps [rsp+0xD0], xmm14
0000792cceddd921  vmovaps [rsp+0xE0], xmm15
0000792cceddd92a  sub rsp, 0x30
0000792cceddd92e  movaps [rsp], xmm7
0000792cceddd932  movaps [rsp+0x10], xmm4
0000792cceddd937  movaps [rsp+0x20], xmm9
0000792cceddd93d  lea rdi, [rsp]
0000792cceddd941  mov esi, 0x00
0000792cceddd946  mov rax, 0x5AEE2D541530
0000792cceddd950  call rax
0000792cceddd952  movaps xmm7, [rsp]
0000792cceddd956  add rsp, 0x30
0000792cceddd95a  vmovaps xmm0, [rsp]
0000792cceddd95f  vmovaps xmm1, [rsp+0x10]
0000792cceddd965  vmovaps xmm2, [rsp+0x20]
0000792cceddd96b  vmovaps xmm3, [rsp+0x30]
0000792cceddd971  vmovaps xmm4, [rsp+0x40]
0000792cceddd977  vmovaps xmm5, [rsp+0x50]
0000792cceddd97d  vmovaps xmm6, [rsp+0x60]
0000792cceddd983  vmovaps xmm8, [rsp+0x70]
0000792cceddd989  vmovaps xmm9, [rsp+0x80]
0000792cceddd992  vmovaps xmm10, [rsp+0x90]
0000792cceddd99b  vmovaps xmm11, [rsp+0xA0]
0000792cceddd9a4  vmovaps xmm12, [rsp+0xB0]
0000792cceddd9ad  vmovaps xmm13, [rsp+0xC0]
0000792cceddd9b6  vmovaps xmm14, [rsp+0xD0]
0000792cceddd9bf  vmovaps xmm15, [rsp+0xE0]
0000792cceddd9c8  add rsp, 0xF0
0000792cceddd9cf  pop r11
0000792cceddd9d1  pop r10
0000792cceddd9d3  pop r9
0000792cceddd9d5  pop r8
0000792cceddd9d7  pop rsi
0000792cceddd9d8  pop rdi
0000792cceddd9d9  pop rdx
0000792cceddd9da  pop rcx
0000792cceddd9db  pop rax
0000792cceddd9dc  add rsp, 0x08
0000792cceddd9e0  jmp 0x0000792CCEDDBE87
0000792cceddd9e5  sub rsp, 0x08
0000792cceddd9e9  push rax
0000792cceddd9ea  push rcx
0000792cceddd9eb  push rdx
0000792cceddd9ec  push rdi
0000792cceddd9ed  push rsi
0000792cceddd9ee  push r8
0000792cceddd9f0  push r9
0000792cceddd9f2  push r10
0000792cceddd9f4  push r11
0000792cceddd9f6  sub rsp, 0xF0
0000792cceddd9fd  vmovaps [rsp], xmm0
0000792cceddda02  vmovaps [rsp+0x10], xmm1
0000792cceddda08  vmovaps [rsp+0x20], xmm2
0000792cceddda0e  vmovaps [rsp+0x30], xmm3
0000792cceddda14  vmovaps [rsp+0x40], xmm5
0000792cceddda1a  vmovaps [rsp+0x50], xmm6
0000792cceddda20  vmovaps [rsp+0x60], xmm7
0000792cceddda26  vmovaps [rsp+0x70], xmm8
0000792cceddda2c  vmovaps [rsp+0x80], xmm9
0000792cceddda35  vmovaps [rsp+0x90], xmm10
0000792cceddda3e  vmovaps [rsp+0xA0], xmm11
0000792cceddda47  vmovaps [rsp+0xB0], xmm12
0000792cceddda50  vmovaps [rsp+0xC0], xmm13
0000792cceddda59  vmovaps [rsp+0xD0], xmm14
0000792cceddda62  vmovaps [rsp+0xE0], xmm15
0000792cceddda6b  sub rsp, 0x30
0000792cceddda6f  movaps [rsp], xmm4
0000792cceddda73  movaps [rsp+0x10], xmm15
0000792cceddda79  movaps [rsp+0x20], xmm9
0000792cceddda7f  lea rdi, [rsp]
0000792cceddda83  mov esi, 0x00
0000792cceddda88  mov rax, 0x5AEE2D541530
0000792cceddda92  call rax
0000792cceddda94  movaps xmm4, [rsp]
0000792cceddda98  add rsp, 0x30
0000792cceddda9c  vmovaps xmm0, [rsp]
0000792ccedddaa1  vmovaps xmm1, [rsp+0x10]
0000792ccedddaa7  vmovaps xmm2, [rsp+0x20]
0000792ccedddaad  vmovaps xmm3, [rsp+0x30]
0000792ccedddab3  vmovaps xmm5, [rsp+0x40]
0000792ccedddab9  vmovaps xmm6, [rsp+0x50]
0000792ccedddabf  vmovaps xmm7, [rsp+0x60]
0000792ccedddac5  vmovaps xmm8, [rsp+0x70]
0000792ccedddacb  vmovaps xmm9, [rsp+0x80]
0000792ccedddad4  vmovaps xmm10, [rsp+0x90]
0000792ccedddadd  vmovaps xmm11, [rsp+0xA0]
0000792ccedddae6  vmovaps xmm12, [rsp+0xB0]
0000792ccedddaef  vmovaps xmm13, [rsp+0xC0]
0000792ccedddaf8  vmovaps xmm14, [rsp+0xD0]
0000792ccedddb01  vmovaps xmm15, [rsp+0xE0]
0000792ccedddb0a  add rsp, 0xF0
0000792ccedddb11  pop r11
0000792ccedddb13  pop r10
0000792ccedddb15  pop r9
0000792ccedddb17  pop r8
0000792ccedddb19  pop rsi
0000792ccedddb1a  pop rdi
0000792ccedddb1b  pop rdx
0000792ccedddb1c  pop rcx
0000792ccedddb1d  pop rax
0000792ccedddb1e  add rsp, 0x08
0000792ccedddb22  jmp 0x0000792CCEDDBEAC
0000792ccedddb27  call 0x0000792CCECC4620
0000792ccedddb2c  jmp 0x0000792CCEDDBEB9
0000792ccedddb31  sub rsp, 0x08
0000792ccedddb35  push rax
0000792ccedddb36  push rcx
0000792ccedddb37  push rdx
0000792ccedddb38  push rdi
0000792ccedddb39  push rsi
0000792ccedddb3a  push r8
0000792ccedddb3c  push r9
0000792ccedddb3e  push r10
0000792ccedddb40  push r11
0000792ccedddb42  sub rsp, 0xF0
0000792ccedddb49  vmovaps [rsp], xmm0
0000792ccedddb4e  vmovaps [rsp+0x10], xmm1
0000792ccedddb54  vmovaps [rsp+0x20], xmm2
0000792ccedddb5a  vmovaps [rsp+0x30], xmm4
0000792ccedddb60  vmovaps [rsp+0x40], xmm5
0000792ccedddb66  vmovaps [rsp+0x50], xmm6
0000792ccedddb6c  vmovaps [rsp+0x60], xmm7
0000792ccedddb72  vmovaps [rsp+0x70], xmm8
0000792ccedddb78  vmovaps [rsp+0x80], xmm9
0000792ccedddb81  vmovaps [rsp+0x90], xmm10
0000792ccedddb8a  vmovaps [rsp+0xA0], xmm11
0000792ccedddb93  vmovaps [rsp+0xB0], xmm12
0000792ccedddb9c  vmovaps [rsp+0xC0], xmm13
0000792ccedddba5  vmovaps [rsp+0xD0], xmm14
0000792ccedddbae  vmovaps [rsp+0xE0], xmm15
0000792ccedddbb7  sub rsp, 0x30
0000792ccedddbbb  movaps [rsp], xmm3
0000792ccedddbbf  movaps [rsp+0x10], xmm1
0000792ccedddbc4  movaps [rsp+0x20], xmm9
0000792ccedddbca  lea rdi, [rsp]
0000792ccedddbce  mov esi, 0x00
0000792ccedddbd3  mov rax, 0x5AEE2D541530
0000792ccedddbdd  call rax
0000792ccedddbdf  movaps xmm3, [rsp]
0000792ccedddbe3  add rsp, 0x30
0000792ccedddbe7  vmovaps xmm0, [rsp]
0000792ccedddbec  vmovaps xmm1, [rsp+0x10]
0000792ccedddbf2  vmovaps xmm2, [rsp+0x20]
0000792ccedddbf8  vmovaps xmm4, [rsp+0x30]
0000792ccedddbfe  vmovaps xmm5, [rsp+0x40]
0000792ccedddc04  vmovaps xmm6, [rsp+0x50]
0000792ccedddc0a  vmovaps xmm7, [rsp+0x60]
0000792ccedddc10  vmovaps xmm8, [rsp+0x70]
0000792ccedddc16  vmovaps xmm9, [rsp+0x80]
0000792ccedddc1f  vmovaps xmm10, [rsp+0x90]
0000792ccedddc28  vmovaps xmm11, [rsp+0xA0]
0000792ccedddc31  vmovaps xmm12, [rsp+0xB0]
0000792ccedddc3a  vmovaps xmm13, [rsp+0xC0]
0000792ccedddc43  vmovaps xmm14, [rsp+0xD0]
0000792ccedddc4c  vmovaps xmm15, [rsp+0xE0]
0000792ccedddc55  add rsp, 0xF0
0000792ccedddc5c  pop r11
0000792ccedddc5e  pop r10
0000792ccedddc60  pop r9
0000792ccedddc62  pop r8
0000792ccedddc64  pop rsi
0000792ccedddc65  pop rdi
0000792ccedddc66  pop rdx
0000792ccedddc67  pop rcx
0000792ccedddc68  pop rax
0000792ccedddc69  add rsp, 0x08
0000792ccedddc6d  jmp 0x0000792CCEDDBEF6
0000792ccedddc72  sub rsp, 0x08
0000792ccedddc76  push rax
0000792ccedddc77  push rcx
0000792ccedddc78  push rdx
0000792ccedddc79  push rdi
0000792ccedddc7a  push rsi
0000792ccedddc7b  push r8
0000792ccedddc7d  push r9
0000792ccedddc7f  push r10
0000792ccedddc81  push r11
0000792ccedddc83  sub rsp, 0xF0
0000792ccedddc8a  vmovaps [rsp], xmm0
0000792ccedddc8f  vmovaps [rsp+0x10], xmm2
0000792ccedddc95  vmovaps [rsp+0x20], xmm3
0000792ccedddc9b  vmovaps [rsp+0x30], xmm4
0000792ccedddca1  vmovaps [rsp+0x40], xmm5
0000792ccedddca7  vmovaps [rsp+0x50], xmm6
0000792ccedddcad  vmovaps [rsp+0x60], xmm7
0000792ccedddcb3  vmovaps [rsp+0x70], xmm8
0000792ccedddcb9  vmovaps [rsp+0x80], xmm9
0000792ccedddcc2  vmovaps [rsp+0x90], xmm10
0000792ccedddccb  vmovaps [rsp+0xA0], xmm11
0000792ccedddcd4  vmovaps [rsp+0xB0], xmm12
0000792ccedddcdd  vmovaps [rsp+0xC0], xmm13
0000792ccedddce6  vmovaps [rsp+0xD0], xmm14
0000792ccedddcef  vmovaps [rsp+0xE0], xmm15
0000792ccedddcf8  sub rsp, 0x30
0000792ccedddcfc  movaps [rsp], xmm1
0000792ccedddd00  movaps [rsp+0x10], xmm15
0000792ccedddd06  movaps [rsp+0x20], xmm9
0000792ccedddd0c  lea rdi, [rsp]
0000792ccedddd10  mov esi, 0x00
0000792ccedddd15  mov rax, 0x5AEE2D541530
0000792ccedddd1f  call rax
0000792ccedddd21  movaps xmm1, [rsp]
0000792ccedddd25  add rsp, 0x30
0000792ccedddd29  vmovaps xmm0, [rsp]
0000792ccedddd2e  vmovaps xmm2, [rsp+0x10]
0000792ccedddd34  vmovaps xmm3, [rsp+0x20]
0000792ccedddd3a  vmovaps xmm4, [rsp+0x30]
0000792ccedddd40  vmovaps xmm5, [rsp+0x40]
0000792ccedddd46  vmovaps xmm6, [rsp+0x50]
0000792ccedddd4c  vmovaps xmm7, [rsp+0x60]
0000792ccedddd52  vmovaps xmm8, [rsp+0x70]
0000792ccedddd58  vmovaps xmm9, [rsp+0x80]
0000792ccedddd61  vmovaps xmm10, [rsp+0x90]
0000792ccedddd6a  vmovaps xmm11, [rsp+0xA0]
0000792ccedddd73  vmovaps xmm12, [rsp+0xB0]
0000792ccedddd7c  vmovaps xmm13, [rsp+0xC0]
0000792ccedddd85  vmovaps xmm14, [rsp+0xD0]
0000792ccedddd8e  vmovaps xmm15, [rsp+0xE0]
0000792ccedddd97  add rsp, 0xF0
0000792ccedddd9e  pop r11
0000792ccedddda0  pop r10
0000792ccedddda2  pop r9
0000792ccedddda4  pop r8
0000792ccedddda6  pop rsi
0000792ccedddda7  pop rdi
0000792ccedddda8  pop rdx
0000792ccedddda9  pop rcx
0000792cceddddaa  pop rax
0000792cceddddab  add rsp, 0x08
0000792cceddddaf  jmp 0x0000792CCEDDBF7E
0000792cceddddb4  call 0x0000792CCECC4620
0000792cceddddb9  jmp 0x0000792CCEDDBF8B
0000792cceddddbe  sub rsp, 0x08
0000792cceddddc2  push rax
0000792cceddddc3  push rcx
0000792cceddddc4  push rdx
0000792cceddddc5  push rdi
0000792cceddddc6  push rsi
0000792cceddddc7  push r8
0000792cceddddc9  push r9
0000792cceddddcb  push r10
0000792cceddddcd  push r11
0000792cceddddcf  sub rsp, 0xF0
0000792cceddddd6  vmovaps [rsp], xmm0
0000792ccedddddb  vmovaps [rsp+0x10], xmm2
0000792ccedddde1  vmovaps [rsp+0x20], xmm3
0000792ccedddde7  vmovaps [rsp+0x30], xmm4
0000792ccedddded  vmovaps [rsp+0x40], xmm5
0000792cceddddf3  vmovaps [rsp+0x50], xmm6
0000792cceddddf9  vmovaps [rsp+0x60], xmm7
0000792cceddddff  vmovaps [rsp+0x70], xmm8
0000792cceddde05  vmovaps [rsp+0x80], xmm9
0000792cceddde0e  vmovaps [rsp+0x90], xmm10
0000792cceddde17  vmovaps [rsp+0xA0], xmm11
0000792cceddde20  vmovaps [rsp+0xB0], xmm12
0000792cceddde29  vmovaps [rsp+0xC0], xmm13
0000792cceddde32  vmovaps [rsp+0xD0], xmm14
0000792cceddde3b  vmovaps [rsp+0xE0], xmm15
0000792cceddde44  sub rsp, 0x30
0000792cceddde48  movaps [rsp], xmm1
0000792cceddde4c  movaps [rsp+0x10], xmm5
0000792cceddde51  movaps [rsp+0x20], xmm7
0000792cceddde56  lea rdi, [rsp]
0000792cceddde5a  mov esi, 0x00
0000792cceddde5f  mov rax, 0x5AEE2D541530
0000792cceddde69  call rax
0000792cceddde6b  movaps xmm1, [rsp]
0000792cceddde6f  add rsp, 0x30
0000792cceddde73  vmovaps xmm0, [rsp]
0000792cceddde78  vmovaps xmm2, [rsp+0x10]
0000792cceddde7e  vmovaps xmm3, [rsp+0x20]
0000792cceddde84  vmovaps xmm4, [rsp+0x30]
0000792cceddde8a  vmovaps xmm5, [rsp+0x40]
0000792cceddde90  vmovaps xmm6, [rsp+0x50]
0000792cceddde96  vmovaps xmm7, [rsp+0x60]
0000792cceddde9c  vmovaps xmm8, [rsp+0x70]
0000792ccedddea2  vmovaps xmm9, [rsp+0x80]
0000792ccedddeab  vmovaps xmm10, [rsp+0x90]
0000792ccedddeb4  vmovaps xmm11, [rsp+0xA0]
0000792ccedddebd  vmovaps xmm12, [rsp+0xB0]
0000792ccedddec6  vmovaps xmm13, [rsp+0xC0]
0000792ccedddecf  vmovaps xmm14, [rsp+0xD0]
0000792cceddded8  vmovaps xmm15, [rsp+0xE0]
0000792ccedddee1  add rsp, 0xF0
0000792ccedddee8  pop r11
0000792ccedddeea  pop r10
0000792ccedddeec  pop r9
0000792ccedddeee  pop r8
0000792ccedddef0  pop rsi
0000792ccedddef1  pop rdi
0000792ccedddef2  pop rdx
0000792ccedddef3  pop rcx
0000792ccedddef4  pop rax
0000792ccedddef5  add rsp, 0x08
0000792ccedddef9  jmp 0x0000792CCEDDC030
0000792ccedddefe  sub rsp, 0x08
0000792ccedddf02  push rax
0000792ccedddf03  push rcx
0000792ccedddf04  push rdx
0000792ccedddf05  push rdi
0000792ccedddf06  push rsi
0000792ccedddf07  push r8
0000792ccedddf09  push r9
0000792ccedddf0b  push r10
0000792ccedddf0d  push r11
0000792ccedddf0f  sub rsp, 0xF0
0000792ccedddf16  vmovaps [rsp], xmm0
0000792ccedddf1b  vmovaps [rsp+0x10], xmm1
0000792ccedddf21  vmovaps [rsp+0x20], xmm2
0000792ccedddf27  vmovaps [rsp+0x30], xmm3
0000792ccedddf2d  vmovaps [rsp+0x40], xmm4
0000792ccedddf33  vmovaps [rsp+0x50], xmm5
0000792ccedddf39  vmovaps [rsp+0x60], xmm6
0000792ccedddf3f  vmovaps [rsp+0x70], xmm8
0000792ccedddf45  vmovaps [rsp+0x80], xmm9
0000792ccedddf4e  vmovaps [rsp+0x90], xmm10
0000792ccedddf57  vmovaps [rsp+0xA0], xmm11
0000792ccedddf60  vmovaps [rsp+0xB0], xmm12
0000792ccedddf69  vmovaps [rsp+0xC0], xmm13
0000792ccedddf72  vmovaps [rsp+0xD0], xmm14
0000792ccedddf7b  vmovaps [rsp+0xE0], xmm15
0000792ccedddf84  sub rsp, 0x30
0000792ccedddf88  movaps [rsp], xmm7
0000792ccedddf8c  movaps [rsp+0x10], xmm5
0000792ccedddf91  movaps [rsp+0x20], xmm15
0000792ccedddf97  lea rdi, [rsp]
0000792ccedddf9b  mov esi, 0x00
0000792ccedddfa0  mov rax, 0x5AEE2D541530
0000792ccedddfaa  call rax
0000792ccedddfac  movaps xmm7, [rsp]
0000792ccedddfb0  add rsp, 0x30
0000792ccedddfb4  vmovaps xmm0, [rsp]
0000792ccedddfb9  vmovaps xmm1, [rsp+0x10]
0000792ccedddfbf  vmovaps xmm2, [rsp+0x20]
0000792ccedddfc5  vmovaps xmm3, [rsp+0x30]
0000792ccedddfcb  vmovaps xmm4, [rsp+0x40]
0000792ccedddfd1  vmovaps xmm5, [rsp+0x50]
0000792ccedddfd7  vmovaps xmm6, [rsp+0x60]
0000792ccedddfdd  vmovaps xmm8, [rsp+0x70]
0000792ccedddfe3  vmovaps xmm9, [rsp+0x80]
0000792ccedddfec  vmovaps xmm10, [rsp+0x90]
0000792ccedddff5  vmovaps xmm11, [rsp+0xA0]
0000792ccedddffe  vmovaps xmm12, [rsp+0xB0]
0000792ccedde007  vmovaps xmm13, [rsp+0xC0]
0000792ccedde010  vmovaps xmm14, [rsp+0xD0]
0000792ccedde019  vmovaps xmm15, [rsp+0xE0]
0000792ccedde022  add rsp, 0xF0
0000792ccedde029  pop r11
0000792ccedde02b  pop r10
0000792ccedde02d  pop r9
0000792ccedde02f  pop r8
0000792ccedde031  pop rsi
0000792ccedde032  pop rdi
0000792ccedde033  pop rdx
0000792ccedde034  pop rcx
0000792ccedde035  pop rax
0000792ccedde036  add rsp, 0x08
0000792ccedde03a  jmp 0x0000792CCEDDC066
0000792ccedde03f  call 0x0000792CCECB52F0
0000792ccedde044  jmp 0x0000792CCEDDC073
0000792ccedde049  sub rsp, 0x08
0000792ccedde04d  push rax
0000792ccedde04e  push rcx
0000792ccedde04f  push rdx
0000792ccedde050  push rdi
0000792ccedde051  push rsi
0000792ccedde052  push r8
0000792ccedde054  push r9
0000792ccedde056  push r10
0000792ccedde058  push r11
0000792ccedde05a  sub rsp, 0xF0
0000792ccedde061  vmovaps [rsp], xmm0
0000792ccedde066  vmovaps [rsp+0x10], xmm1
0000792ccedde06c  vmovaps [rsp+0x20], xmm2
0000792ccedde072  vmovaps [rsp+0x30], xmm3
0000792ccedde078  vmovaps [rsp+0x40], xmm4
0000792ccedde07e  vmovaps [rsp+0x50], xmm5
0000792ccedde084  vmovaps [rsp+0x60], xmm6
0000792ccedde08a  vmovaps [rsp+0x70], xmm7
0000792ccedde090  vmovaps [rsp+0x80], xmm8
0000792ccedde099  vmovaps [rsp+0x90], xmm9
0000792ccedde0a2  vmovaps [rsp+0xA0], xmm10
0000792ccedde0ab  vmovaps [rsp+0xB0], xmm11
0000792ccedde0b4  vmovaps [rsp+0xC0], xmm12
0000792ccedde0bd  vmovaps [rsp+0xD0], xmm13
0000792ccedde0c6  vmovaps [rsp+0xE0], xmm14
0000792ccedde0cf  sub rsp, 0x30
0000792ccedde0d3  movaps [rsp], xmm15
0000792ccedde0d8  movaps [rsp+0x10], xmm5
0000792ccedde0dd  movaps [rsp+0x20], xmm3
0000792ccedde0e2  lea rdi, [rsp]
0000792ccedde0e6  mov esi, 0x00
0000792ccedde0eb  mov rax, 0x5AEE2D541530
0000792ccedde0f5  call rax
0000792ccedde0f7  movaps xmm15, [rsp]
0000792ccedde0fc  add rsp, 0x30
0000792ccedde100  vmovaps xmm0, [rsp]
0000792ccedde105  vmovaps xmm1, [rsp+0x10]
0000792ccedde10b  vmovaps xmm2, [rsp+0x20]
0000792ccedde111  vmovaps xmm3, [rsp+0x30]
0000792ccedde117  vmovaps xmm4, [rsp+0x40]
0000792ccedde11d  vmovaps xmm5, [rsp+0x50]
0000792ccedde123  vmovaps xmm6, [rsp+0x60]
0000792ccedde129  vmovaps xmm7, [rsp+0x70]
0000792ccedde12f  vmovaps xmm8, [rsp+0x80]
0000792ccedde138  vmovaps xmm9, [rsp+0x90]
0000792ccedde141  vmovaps xmm10, [rsp+0xA0]
0000792ccedde14a  vmovaps xmm11, [rsp+0xB0]
0000792ccedde153  vmovaps xmm12, [rsp+0xC0]
0000792ccedde15c  vmovaps xmm13, [rsp+0xD0]
0000792ccedde165  vmovaps xmm14, [rsp+0xE0]
0000792ccedde16e  add rsp, 0xF0
0000792ccedde175  pop r11
0000792ccedde177  pop r10
0000792ccedde179  pop r9
0000792ccedde17b  pop r8
0000792ccedde17d  pop rsi
0000792ccedde17e  pop rdi
0000792ccedde17f  pop rdx
0000792ccedde180  pop rcx
0000792ccedde181  pop rax
0000792ccedde182  add rsp, 0x08
0000792ccedde186  jmp 0x0000792CCEDDC099
0000792ccedde18b  sub rsp, 0x08
0000792ccedde18f  push rax
0000792ccedde190  push rcx
0000792ccedde191  push rdx
0000792ccedde192  push rdi
0000792ccedde193  push rsi
0000792ccedde194  push r8
0000792ccedde196  push r9
0000792ccedde198  push r10
0000792ccedde19a  push r11
0000792ccedde19c  sub rsp, 0xF0
0000792ccedde1a3  vmovaps [rsp], xmm0
0000792ccedde1a8  vmovaps [rsp+0x10], xmm2
0000792ccedde1ae  vmovaps [rsp+0x20], xmm3
0000792ccedde1b4  vmovaps [rsp+0x30], xmm4
0000792ccedde1ba  vmovaps [rsp+0x40], xmm5
0000792ccedde1c0  vmovaps [rsp+0x50], xmm6
0000792ccedde1c6  vmovaps [rsp+0x60], xmm7
0000792ccedde1cc  vmovaps [rsp+0x70], xmm8
0000792ccedde1d2  vmovaps [rsp+0x80], xmm9
0000792ccedde1db  vmovaps [rsp+0x90], xmm10
0000792ccedde1e4  vmovaps [rsp+0xA0], xmm11
0000792ccedde1ed  vmovaps [rsp+0xB0], xmm12
0000792ccedde1f6  vmovaps [rsp+0xC0], xmm13
0000792ccedde1ff  vmovaps [rsp+0xD0], xmm14
0000792ccedde208  vmovaps [rsp+0xE0], xmm15
0000792ccedde211  sub rsp, 0x30
0000792ccedde215  movaps [rsp], xmm1
0000792ccedde219  movaps [rsp+0x10], xmm5
0000792ccedde21e  movaps [rsp+0x20], xmm4
0000792ccedde223  lea rdi, [rsp]
0000792ccedde227  mov esi, 0x00
0000792ccedde22c  mov rax, 0x5AEE2D541530
0000792ccedde236  call rax
0000792ccedde238  movaps xmm1, [rsp]
0000792ccedde23c  add rsp, 0x30
0000792ccedde240  vmovaps xmm0, [rsp]
0000792ccedde245  vmovaps xmm2, [rsp+0x10]
0000792ccedde24b  vmovaps xmm3, [rsp+0x20]
0000792ccedde251  vmovaps xmm4, [rsp+0x30]
0000792ccedde257  vmovaps xmm5, [rsp+0x40]
0000792ccedde25d  vmovaps xmm6, [rsp+0x50]
0000792ccedde263  vmovaps xmm7, [rsp+0x60]
0000792ccedde269  vmovaps xmm8, [rsp+0x70]
0000792ccedde26f  vmovaps xmm9, [rsp+0x80]
0000792ccedde278  vmovaps xmm10, [rsp+0x90]
0000792ccedde281  vmovaps xmm11, [rsp+0xA0]
0000792ccedde28a  vmovaps xmm12, [rsp+0xB0]
0000792ccedde293  vmovaps xmm13, [rsp+0xC0]
0000792ccedde29c  vmovaps xmm14, [rsp+0xD0]
0000792ccedde2a5  vmovaps xmm15, [rsp+0xE0]
0000792ccedde2ae  add rsp, 0xF0
0000792ccedde2b5  pop r11
0000792ccedde2b7  pop r10
0000792ccedde2b9  pop r9
0000792ccedde2bb  pop r8
0000792ccedde2bd  pop rsi
0000792ccedde2be  pop rdi
0000792ccedde2bf  pop rdx
0000792ccedde2c0  pop rcx
0000792ccedde2c1  pop rax
0000792ccedde2c2  add rsp, 0x08
0000792ccedde2c6  jmp 0x0000792CCEDDC0B9
0000792ccedde2cb  sub rsp, 0x08
0000792ccedde2cf  push rax
0000792ccedde2d0  push rcx
0000792ccedde2d1  push rdx
0000792ccedde2d2  push rdi
0000792ccedde2d3  push rsi
0000792ccedde2d4  push r8
0000792ccedde2d6  push r9
0000792ccedde2d8  push r10
0000792ccedde2da  push r11
0000792ccedde2dc  sub rsp, 0xF0
0000792ccedde2e3  vmovaps [rsp], xmm0
0000792ccedde2e8  vmovaps [rsp+0x10], xmm1
0000792ccedde2ee  vmovaps [rsp+0x20], xmm2
0000792ccedde2f4  vmovaps [rsp+0x30], xmm3
0000792ccedde2fa  vmovaps [rsp+0x40], xmm5
0000792ccedde300  vmovaps [rsp+0x50], xmm6
0000792ccedde306  vmovaps [rsp+0x60], xmm7
0000792ccedde30c  vmovaps [rsp+0x70], xmm8
0000792ccedde312  vmovaps [rsp+0x80], xmm9
0000792ccedde31b  vmovaps [rsp+0x90], xmm10
0000792ccedde324  vmovaps [rsp+0xA0], xmm11
0000792ccedde32d  vmovaps [rsp+0xB0], xmm12
0000792ccedde336  vmovaps [rsp+0xC0], xmm13
0000792ccedde33f  vmovaps [rsp+0xD0], xmm14
0000792ccedde348  vmovaps [rsp+0xE0], xmm15
0000792ccedde351  sub rsp, 0x30
0000792ccedde355  movaps [rsp], xmm4
0000792ccedde359  movaps [rsp+0x10], xmm3
0000792ccedde35e  movaps [rsp+0x20], xmm5
0000792ccedde363  lea rdi, [rsp]
0000792ccedde367  mov esi, 0x00
0000792ccedde36c  mov rax, 0x5AEE2D541530
0000792ccedde376  call rax
0000792ccedde378  movaps xmm4, [rsp]
0000792ccedde37c  add rsp, 0x30
0000792ccedde380  vmovaps xmm0, [rsp]
0000792ccedde385  vmovaps xmm1, [rsp+0x10]
0000792ccedde38b  vmovaps xmm2, [rsp+0x20]
0000792ccedde391  vmovaps xmm3, [rsp+0x30]
0000792ccedde397  vmovaps xmm5, [rsp+0x40]
0000792ccedde39d  vmovaps xmm6, [rsp+0x50]
0000792ccedde3a3  vmovaps xmm7, [rsp+0x60]
0000792ccedde3a9  vmovaps xmm8, [rsp+0x70]
0000792ccedde3af  vmovaps xmm9, [rsp+0x80]
0000792ccedde3b8  vmovaps xmm10, [rsp+0x90]
0000792ccedde3c1  vmovaps xmm11, [rsp+0xA0]
0000792ccedde3ca  vmovaps xmm12, [rsp+0xB0]
0000792ccedde3d3  vmovaps xmm13, [rsp+0xC0]
0000792ccedde3dc  vmovaps xmm14, [rsp+0xD0]
0000792ccedde3e5  vmovaps xmm15, [rsp+0xE0]
0000792ccedde3ee  add rsp, 0xF0
0000792ccedde3f5  pop r11
0000792ccedde3f7  pop r10
0000792ccedde3f9  pop r9
0000792ccedde3fb  pop r8
0000792ccedde3fd  pop rsi
0000792ccedde3fe  pop rdi
0000792ccedde3ff  pop rdx
0000792ccedde400  pop rcx
0000792ccedde401  pop rax
0000792ccedde402  add rsp, 0x08
0000792ccedde406  jmp 0x0000792CCEDDC107
0000792ccedde40b  call 0x0000792CCECB52F0
0000792ccedde410  jmp 0x0000792CCEDDC114
0000792ccedde415  sub rsp, 0x08
0000792ccedde419  push rax
0000792ccedde41a  push rcx
0000792ccedde41b  push rdx
0000792ccedde41c  push rdi
0000792ccedde41d  push rsi
0000792ccedde41e  push r8
0000792ccedde420  push r9
0000792ccedde422  push r10
0000792ccedde424  push r11
0000792ccedde426  sub rsp, 0xF0
0000792ccedde42d  vmovaps [rsp], xmm0
0000792ccedde432  vmovaps [rsp+0x10], xmm1
0000792ccedde438  vmovaps [rsp+0x20], xmm2
0000792ccedde43e  vmovaps [rsp+0x30], xmm3
0000792ccedde444  vmovaps [rsp+0x40], xmm4
0000792ccedde44a  vmovaps [rsp+0x50], xmm6
0000792ccedde450  vmovaps [rsp+0x60], xmm7
0000792ccedde456  vmovaps [rsp+0x70], xmm8
0000792ccedde45c  vmovaps [rsp+0x80], xmm9
0000792ccedde465  vmovaps [rsp+0x90], xmm10
0000792ccedde46e  vmovaps [rsp+0xA0], xmm11
0000792ccedde477  vmovaps [rsp+0xB0], xmm12
0000792ccedde480  vmovaps [rsp+0xC0], xmm13
0000792ccedde489  vmovaps [rsp+0xD0], xmm14
0000792ccedde492  vmovaps [rsp+0xE0], xmm15
0000792ccedde49b  sub rsp, 0x30
0000792ccedde49f  movaps [rsp], xmm5
0000792ccedde4a3  movaps [rsp+0x10], xmm6
0000792ccedde4a8  movaps [rsp+0x20], xmm3
0000792ccedde4ad  lea rdi, [rsp]
0000792ccedde4b1  mov esi, 0x00
0000792ccedde4b6  mov rax, 0x5AEE2D541530
0000792ccedde4c0  call rax
0000792ccedde4c2  movaps xmm5, [rsp]
0000792ccedde4c6  add rsp, 0x30
0000792ccedde4ca  vmovaps xmm0, [rsp]
0000792ccedde4cf  vmovaps xmm1, [rsp+0x10]
0000792ccedde4d5  vmovaps xmm2, [rsp+0x20]
0000792ccedde4db  vmovaps xmm3, [rsp+0x30]
0000792ccedde4e1  vmovaps xmm4, [rsp+0x40]
0000792ccedde4e7  vmovaps xmm6, [rsp+0x50]
0000792ccedde4ed  vmovaps xmm7, [rsp+0x60]
0000792ccedde4f3  vmovaps xmm8, [rsp+0x70]
0000792ccedde4f9  vmovaps xmm9, [rsp+0x80]
0000792ccedde502  vmovaps xmm10, [rsp+0x90]
0000792ccedde50b  vmovaps xmm11, [rsp+0xA0]
0000792ccedde514  vmovaps xmm12, [rsp+0xB0]
0000792ccedde51d  vmovaps xmm13, [rsp+0xC0]
0000792ccedde526  vmovaps xmm14, [rsp+0xD0]
0000792ccedde52f  vmovaps xmm15, [rsp+0xE0]
0000792ccedde538  add rsp, 0xF0
0000792ccedde53f  pop r11
0000792ccedde541  pop r10
0000792ccedde543  pop r9
0000792ccedde545  pop r8
0000792ccedde547  pop rsi
0000792ccedde548  pop rdi
0000792ccedde549  pop rdx
0000792ccedde54a  pop rcx
0000792ccedde54b  pop rax
0000792ccedde54c  add rsp, 0x08
0000792ccedde550  jmp 0x0000792CCEDDC13A
0000792ccedde555  sub rsp, 0x08
0000792ccedde559  push rax
0000792ccedde55a  push rcx
0000792ccedde55b  push rdx
0000792ccedde55c  push rdi
0000792ccedde55d  push rsi
0000792ccedde55e  push r8
0000792ccedde560  push r9
0000792ccedde562  push r10
0000792ccedde564  push r11
0000792ccedde566  sub rsp, 0xF0
0000792ccedde56d  vmovaps [rsp], xmm0
0000792ccedde572  vmovaps [rsp+0x10], xmm1
0000792ccedde578  vmovaps [rsp+0x20], xmm2
0000792ccedde57e  vmovaps [rsp+0x30], xmm3
0000792ccedde584  vmovaps [rsp+0x40], xmm4
0000792ccedde58a  vmovaps [rsp+0x50], xmm5
0000792ccedde590  vmovaps [rsp+0x60], xmm7
0000792ccedde596  vmovaps [rsp+0x70], xmm8
0000792ccedde59c  vmovaps [rsp+0x80], xmm9
0000792ccedde5a5  vmovaps [rsp+0x90], xmm10
0000792ccedde5ae  vmovaps [rsp+0xA0], xmm11
0000792ccedde5b7  vmovaps [rsp+0xB0], xmm12
0000792ccedde5c0  vmovaps [rsp+0xC0], xmm13
0000792ccedde5c9  vmovaps [rsp+0xD0], xmm14
0000792ccedde5d2  vmovaps [rsp+0xE0], xmm15
0000792ccedde5db  sub rsp, 0x30
0000792ccedde5df  movaps [rsp], xmm6
0000792ccedde5e3  movaps [rsp+0x10], xmm9
0000792ccedde5e9  movaps [rsp+0x20], xmm1
0000792ccedde5ee  lea rdi, [rsp]
0000792ccedde5f2  mov esi, 0x00
0000792ccedde5f7  mov rax, 0x5AEE2D541530
0000792ccedde601  call rax
0000792ccedde603  movaps xmm6, [rsp]
0000792ccedde607  add rsp, 0x30
0000792ccedde60b  vmovaps xmm0, [rsp]
0000792ccedde610  vmovaps xmm1, [rsp+0x10]
0000792ccedde616  vmovaps xmm2, [rsp+0x20]
0000792ccedde61c  vmovaps xmm3, [rsp+0x30]
0000792ccedde622  vmovaps xmm4, [rsp+0x40]
0000792ccedde628  vmovaps xmm5, [rsp+0x50]
0000792ccedde62e  vmovaps xmm7, [rsp+0x60]
0000792ccedde634  vmovaps xmm8, [rsp+0x70]
0000792ccedde63a  vmovaps xmm9, [rsp+0x80]
0000792ccedde643  vmovaps xmm10, [rsp+0x90]
0000792ccedde64c  vmovaps xmm11, [rsp+0xA0]
0000792ccedde655  vmovaps xmm12, [rsp+0xB0]
0000792ccedde65e  vmovaps xmm13, [rsp+0xC0]
0000792ccedde667  vmovaps xmm14, [rsp+0xD0]
0000792ccedde670  vmovaps xmm15, [rsp+0xE0]
0000792ccedde679  add rsp, 0xF0
0000792ccedde680  pop r11
0000792ccedde682  pop r10
0000792ccedde684  pop r9
0000792ccedde686  pop r8
0000792ccedde688  pop rsi
0000792ccedde689  pop rdi
0000792ccedde68a  pop rdx
0000792ccedde68b  pop rcx
0000792ccedde68c  pop rax
0000792ccedde68d  add rsp, 0x08
0000792ccedde691  jmp 0x0000792CCEDDC15E
0000792ccedde696  sub rsp, 0x08
0000792ccedde69a  push rax
0000792ccedde69b  push rcx
0000792ccedde69c  push rdx
0000792ccedde69d  push rdi
0000792ccedde69e  push rsi
0000792ccedde69f  push r8
0000792ccedde6a1  push r9
0000792ccedde6a3  push r10
0000792ccedde6a5  push r11
0000792ccedde6a7  sub rsp, 0xF0
0000792ccedde6ae  vmovaps [rsp], xmm0
0000792ccedde6b3  vmovaps [rsp+0x10], xmm1
0000792ccedde6b9  vmovaps [rsp+0x20], xmm2
0000792ccedde6bf  vmovaps [rsp+0x30], xmm3
0000792ccedde6c5  vmovaps [rsp+0x40], xmm4
0000792ccedde6cb  vmovaps [rsp+0x50], xmm5
0000792ccedde6d1  vmovaps [rsp+0x60], xmm6
0000792ccedde6d7  vmovaps [rsp+0x70], xmm7
0000792ccedde6dd  vmovaps [rsp+0x80], xmm8
0000792ccedde6e6  vmovaps [rsp+0x90], xmm10
0000792ccedde6ef  vmovaps [rsp+0xA0], xmm11
0000792ccedde6f8  vmovaps [rsp+0xB0], xmm12
0000792ccedde701  vmovaps [rsp+0xC0], xmm13
0000792ccedde70a  vmovaps [rsp+0xD0], xmm14
0000792ccedde713  vmovaps [rsp+0xE0], xmm15
0000792ccedde71c  sub rsp, 0x30
0000792ccedde720  movaps [rsp], xmm9
0000792ccedde725  movaps [rsp+0x10], xmm3
0000792ccedde72a  movaps [rsp+0x20], xmm1
0000792ccedde72f  lea rdi, [rsp]
0000792ccedde733  mov esi, 0x00
0000792ccedde738  mov rax, 0x5AEE2D541530
0000792ccedde742  call rax
0000792ccedde744  movaps xmm9, [rsp]
0000792ccedde749  add rsp, 0x30
0000792ccedde74d  vmovaps xmm0, [rsp]
0000792ccedde752  vmovaps xmm1, [rsp+0x10]
0000792ccedde758  vmovaps xmm2, [rsp+0x20]
0000792ccedde75e  vmovaps xmm3, [rsp+0x30]
0000792ccedde764  vmovaps xmm4, [rsp+0x40]
0000792ccedde76a  vmovaps xmm5, [rsp+0x50]
0000792ccedde770  vmovaps xmm6, [rsp+0x60]
0000792ccedde776  vmovaps xmm7, [rsp+0x70]
0000792ccedde77c  vmovaps xmm8, [rsp+0x80]
0000792ccedde785  vmovaps xmm10, [rsp+0x90]
0000792ccedde78e  vmovaps xmm11, [rsp+0xA0]
0000792ccedde797  vmovaps xmm12, [rsp+0xB0]
0000792ccedde7a0  vmovaps xmm13, [rsp+0xC0]
0000792ccedde7a9  vmovaps xmm14, [rsp+0xD0]
0000792ccedde7b2  vmovaps xmm15, [rsp+0xE0]
0000792ccedde7bb  add rsp, 0xF0
0000792ccedde7c2  pop r11
0000792ccedde7c4  pop r10
0000792ccedde7c6  pop r9
0000792ccedde7c8  pop r8
0000792ccedde7ca  pop rsi
0000792ccedde7cb  pop rdi
0000792ccedde7cc  pop rdx
0000792ccedde7cd  pop rcx
0000792ccedde7ce  pop rax
0000792ccedde7cf  add rsp, 0x08
0000792ccedde7d3  jmp 0x0000792CCEDDC1AA
0000792ccedde7d8  call 0x0000792CCECB52F0
0000792ccedde7dd  jmp 0x0000792CCEDDC1B7
0000792ccedde7e2  sub rsp, 0x08
0000792ccedde7e6  push rax
0000792ccedde7e7  push rcx
0000792ccedde7e8  push rdx
0000792ccedde7e9  push rdi
0000792ccedde7ea  push rsi
0000792ccedde7eb  push r8
0000792ccedde7ed  push r9
0000792ccedde7ef  push r10
0000792ccedde7f1  push r11
0000792ccedde7f3  sub rsp, 0xF0
0000792ccedde7fa  vmovaps [rsp], xmm0
0000792ccedde7ff  vmovaps [rsp+0x10], xmm1
0000792ccedde805  vmovaps [rsp+0x20], xmm2
0000792ccedde80b  vmovaps [rsp+0x30], xmm3
0000792ccedde811  vmovaps [rsp+0x40], xmm4
0000792ccedde817  vmovaps [rsp+0x50], xmm5
0000792ccedde81d  vmovaps [rsp+0x60], xmm6
0000792ccedde823  vmovaps [rsp+0x70], xmm7
0000792ccedde829  vmovaps [rsp+0x80], xmm8
0000792ccedde832  vmovaps [rsp+0x90], xmm9
0000792ccedde83b  vmovaps [rsp+0xA0], xmm10
0000792ccedde844  vmovaps [rsp+0xB0], xmm11
0000792ccedde84d  vmovaps [rsp+0xC0], xmm12
0000792ccedde856  vmovaps [rsp+0xD0], xmm13
0000792ccedde85f  vmovaps [rsp+0xE0], xmm14
0000792ccedde868  sub rsp, 0x30
0000792ccedde86c  movaps [rsp], xmm15
0000792ccedde871  movaps [rsp+0x10], xmm3
0000792ccedde876  movaps [rsp+0x20], xmm7
0000792ccedde87b  lea rdi, [rsp]
0000792ccedde87f  mov esi, 0x00
0000792ccedde884  mov rax, 0x5AEE2D541530
0000792ccedde88e  call rax
0000792ccedde890  movaps xmm15, [rsp]
0000792ccedde895  add rsp, 0x30
0000792ccedde899  vmovaps xmm0, [rsp]
0000792ccedde89e  vmovaps xmm1, [rsp+0x10]
0000792ccedde8a4  vmovaps xmm2, [rsp+0x20]
0000792ccedde8aa  vmovaps xmm3, [rsp+0x30]
0000792ccedde8b0  vmovaps xmm4, [rsp+0x40]
0000792ccedde8b6  vmovaps xmm5, [rsp+0x50]
0000792ccedde8bc  vmovaps xmm6, [rsp+0x60]
0000792ccedde8c2  vmovaps xmm7, [rsp+0x70]
0000792ccedde8c8  vmovaps xmm8, [rsp+0x80]
0000792ccedde8d1  vmovaps xmm9, [rsp+0x90]
0000792ccedde8da  vmovaps xmm10, [rsp+0xA0]
0000792ccedde8e3  vmovaps xmm11, [rsp+0xB0]
0000792ccedde8ec  vmovaps xmm12, [rsp+0xC0]
0000792ccedde8f5  vmovaps xmm13, [rsp+0xD0]
0000792ccedde8fe  vmovaps xmm14, [rsp+0xE0]
0000792ccedde907  add rsp, 0xF0
0000792ccedde90e  pop r11
0000792ccedde910  pop r10
0000792ccedde912  pop r9
0000792ccedde914  pop r8
0000792ccedde916  pop rsi
0000792ccedde917  pop rdi
0000792ccedde918  pop rdx
0000792ccedde919  pop rcx
0000792ccedde91a  pop rax
0000792ccedde91b  add rsp, 0x08
0000792ccedde91f  jmp 0x0000792CCEDDC1E3
0000792ccedde924  sub rsp, 0x08
0000792ccedde928  push rax
0000792ccedde929  push rcx
0000792ccedde92a  push rdx
0000792ccedde92b  push rdi
0000792ccedde92c  push rsi
0000792ccedde92d  push r8
0000792ccedde92f  push r9
0000792ccedde931  push r10
0000792ccedde933  push r11
0000792ccedde935  sub rsp, 0xF0
0000792ccedde93c  vmovaps [rsp], xmm0
0000792ccedde941  vmovaps [rsp+0x10], xmm1
0000792ccedde947  vmovaps [rsp+0x20], xmm2
0000792ccedde94d  vmovaps [rsp+0x30], xmm4
0000792ccedde953  vmovaps [rsp+0x40], xmm5
0000792ccedde959  vmovaps [rsp+0x50], xmm6
0000792ccedde95f  vmovaps [rsp+0x60], xmm7
0000792ccedde965  vmovaps [rsp+0x70], xmm8
0000792ccedde96b  vmovaps [rsp+0x80], xmm9
0000792ccedde974  vmovaps [rsp+0x90], xmm10
0000792ccedde97d  vmovaps [rsp+0xA0], xmm11
0000792ccedde986  vmovaps [rsp+0xB0], xmm12
0000792ccedde98f  vmovaps [rsp+0xC0], xmm13
0000792ccedde998  vmovaps [rsp+0xD0], xmm14
0000792ccedde9a1  vmovaps [rsp+0xE0], xmm15
0000792ccedde9aa  sub rsp, 0x30
0000792ccedde9ae  movaps [rsp], xmm3
0000792ccedde9b2  movaps [rsp+0x10], xmm1
0000792ccedde9b7  movaps [rsp+0x20], xmm15
0000792ccedde9bd  lea rdi, [rsp]
0000792ccedde9c1  mov esi, 0x00
0000792ccedde9c6  mov rax, 0x5AEE2D541530
0000792ccedde9d0  call rax
0000792ccedde9d2  movaps xmm3, [rsp]
0000792ccedde9d6  add rsp, 0x30
0000792ccedde9da  vmovaps xmm0, [rsp]
0000792ccedde9df  vmovaps xmm1, [rsp+0x10]
0000792ccedde9e5  vmovaps xmm2, [rsp+0x20]
0000792ccedde9eb  vmovaps xmm4, [rsp+0x30]
0000792ccedde9f1  vmovaps xmm5, [rsp+0x40]
0000792ccedde9f7  vmovaps xmm6, [rsp+0x50]
0000792ccedde9fd  vmovaps xmm7, [rsp+0x60]
0000792cceddea03  vmovaps xmm8, [rsp+0x70]
0000792cceddea09  vmovaps xmm9, [rsp+0x80]
0000792cceddea12  vmovaps xmm10, [rsp+0x90]
0000792cceddea1b  vmovaps xmm11, [rsp+0xA0]
0000792cceddea24  vmovaps xmm12, [rsp+0xB0]
0000792cceddea2d  vmovaps xmm13, [rsp+0xC0]
0000792cceddea36  vmovaps xmm14, [rsp+0xD0]
0000792cceddea3f  vmovaps xmm15, [rsp+0xE0]
0000792cceddea48  add rsp, 0xF0
0000792cceddea4f  pop r11
0000792cceddea51  pop r10
0000792cceddea53  pop r9
0000792cceddea55  pop r8
0000792cceddea57  pop rsi
0000792cceddea58  pop rdi
0000792cceddea59  pop rdx
0000792cceddea5a  pop rcx
0000792cceddea5b  pop rax
0000792cceddea5c  add rsp, 0x08
0000792cceddea60  jmp 0x0000792CCEDDC272
0000792cceddea65  call 0x0000792CCECB52F0
0000792cceddea6a  jmp 0x0000792CCEDDC27C
0000792cceddea6f  sub rsp, 0x08
0000792cceddea73  push rax
0000792cceddea74  push rcx
0000792cceddea75  push rdx
0000792cceddea76  push rdi
0000792cceddea77  push rsi
0000792cceddea78  push r8
0000792cceddea7a  push r9
0000792cceddea7c  push r10
0000792cceddea7e  push r11
0000792cceddea80  sub rsp, 0xF0
0000792cceddea87  vmovaps [rsp], xmm0
0000792cceddea8c  vmovaps [rsp+0x10], xmm1
0000792cceddea92  vmovaps [rsp+0x20], xmm2
0000792cceddea98  vmovaps [rsp+0x30], xmm3
0000792cceddea9e  vmovaps [rsp+0x40], xmm4
0000792cceddeaa4  vmovaps [rsp+0x50], xmm5
0000792cceddeaaa  vmovaps [rsp+0x60], xmm6
0000792cceddeab0  vmovaps [rsp+0x70], xmm7
0000792cceddeab6  vmovaps [rsp+0x80], xmm8
0000792cceddeabf  vmovaps [rsp+0x90], xmm9
0000792cceddeac8  vmovaps [rsp+0xA0], xmm10
0000792cceddead1  vmovaps [rsp+0xB0], xmm11
0000792cceddeada  vmovaps [rsp+0xC0], xmm12
0000792cceddeae3  vmovaps [rsp+0xD0], xmm13
0000792cceddeaec  vmovaps [rsp+0xE0], xmm14
0000792cceddeaf5  sub rsp, 0x30
0000792cceddeaf9  movaps [rsp], xmm15
0000792cceddeafe  movaps [rsp+0x10], xmm14
0000792cceddeb04  movaps [rsp+0x20], xmm4
0000792cceddeb09  lea rdi, [rsp]
0000792cceddeb0d  mov esi, 0x00
0000792cceddeb12  mov rax, 0x5AEE2D541530
0000792cceddeb1c  call rax
0000792cceddeb1e  movaps xmm15, [rsp]
0000792cceddeb23  add rsp, 0x30
0000792cceddeb27  vmovaps xmm0, [rsp]
0000792cceddeb2c  vmovaps xmm1, [rsp+0x10]
0000792cceddeb32  vmovaps xmm2, [rsp+0x20]
0000792cceddeb38  vmovaps xmm3, [rsp+0x30]
0000792cceddeb3e  vmovaps xmm4, [rsp+0x40]
0000792cceddeb44  vmovaps xmm5, [rsp+0x50]
0000792cceddeb4a  vmovaps xmm6, [rsp+0x60]
0000792cceddeb50  vmovaps xmm7, [rsp+0x70]
0000792cceddeb56  vmovaps xmm8, [rsp+0x80]
0000792cceddeb5f  vmovaps xmm9, [rsp+0x90]
0000792cceddeb68  vmovaps xmm10, [rsp+0xA0]
0000792cceddeb71  vmovaps xmm11, [rsp+0xB0]
0000792cceddeb7a  vmovaps xmm12, [rsp+0xC0]
0000792cceddeb83  vmovaps xmm13, [rsp+0xD0]
0000792cceddeb8c  vmovaps xmm14, [rsp+0xE0]
0000792cceddeb95  add rsp, 0xF0
0000792cceddeb9c  pop r11
0000792cceddeb9e  pop r10
0000792cceddeba0  pop r9
0000792cceddeba2  pop r8
0000792cceddeba4  pop rsi
0000792cceddeba5  pop rdi
0000792cceddeba6  pop rdx
0000792cceddeba7  pop rcx
0000792cceddeba8  pop rax
0000792cceddeba9  add rsp, 0x08
0000792cceddebad  jmp 0x0000792CCEDDC2AA
0000792cceddebb2  sub rsp, 0x08
0000792cceddebb6  push rax
0000792cceddebb7  push rcx
0000792cceddebb8  push rdx
0000792cceddebb9  push rdi
0000792cceddebba  push rsi
0000792cceddebbb  push r8
0000792cceddebbd  push r9
0000792cceddebbf  push r10
0000792cceddebc1  push r11
0000792cceddebc3  sub rsp, 0xF0
0000792cceddebca  vmovaps [rsp], xmm0
0000792cceddebcf  vmovaps [rsp+0x10], xmm1
0000792cceddebd5  vmovaps [rsp+0x20], xmm2
0000792cceddebdb  vmovaps [rsp+0x30], xmm3
0000792cceddebe1  vmovaps [rsp+0x40], xmm4
0000792cceddebe7  vmovaps [rsp+0x50], xmm5
0000792cceddebed  vmovaps [rsp+0x60], xmm6
0000792cceddebf3  vmovaps [rsp+0x70], xmm7
0000792cceddebf9  vmovaps [rsp+0x80], xmm8
0000792cceddec02  vmovaps [rsp+0x90], xmm9
0000792cceddec0b  vmovaps [rsp+0xA0], xmm10
0000792cceddec14  vmovaps [rsp+0xB0], xmm11
0000792cceddec1d  vmovaps [rsp+0xC0], xmm12
0000792cceddec26  vmovaps [rsp+0xD0], xmm13
0000792cceddec2f  vmovaps [rsp+0xE0], xmm15
0000792cceddec38  sub rsp, 0x30
0000792cceddec3c  movaps [rsp], xmm14
0000792cceddec41  movaps [rsp+0x10], xmm2
0000792cceddec46  movaps [rsp+0x20], xmm1
0000792cceddec4b  lea rdi, [rsp]
0000792cceddec4f  mov esi, 0x00
0000792cceddec54  mov rax, 0x5AEE2D541530
0000792cceddec5e  call rax
0000792cceddec60  movaps xmm14, [rsp]
0000792cceddec65  add rsp, 0x30
0000792cceddec69  vmovaps xmm0, [rsp]
0000792cceddec6e  vmovaps xmm1, [rsp+0x10]
0000792cceddec74  vmovaps xmm2, [rsp+0x20]
0000792cceddec7a  vmovaps xmm3, [rsp+0x30]
0000792cceddec80  vmovaps xmm4, [rsp+0x40]
0000792cceddec86  vmovaps xmm5, [rsp+0x50]
0000792cceddec8c  vmovaps xmm6, [rsp+0x60]
0000792cceddec92  vmovaps xmm7, [rsp+0x70]
0000792cceddec98  vmovaps xmm8, [rsp+0x80]
0000792cceddeca1  vmovaps xmm9, [rsp+0x90]
0000792cceddecaa  vmovaps xmm10, [rsp+0xA0]
0000792cceddecb3  vmovaps xmm11, [rsp+0xB0]
0000792cceddecbc  vmovaps xmm12, [rsp+0xC0]
0000792cceddecc5  vmovaps xmm13, [rsp+0xD0]
0000792cceddecce  vmovaps xmm15, [rsp+0xE0]
0000792cceddecd7  add rsp, 0xF0
0000792cceddecde  pop r11
0000792cceddece0  pop r10
0000792cceddece2  pop r9
0000792cceddece4  pop r8
0000792cceddece6  pop rsi
0000792cceddece7  pop rdi
0000792cceddece8  pop rdx
0000792cceddece9  pop rcx
0000792cceddecea  pop rax
0000792cceddeceb  add rsp, 0x08
0000792cceddecef  jmp 0x0000792CCEDDC2D0
0000792cceddecf4  sub rsp, 0x08
0000792cceddecf8  push rax
0000792cceddecf9  push rcx
0000792cceddecfa  push rdx
0000792cceddecfb  push rdi
0000792cceddecfc  push rsi
0000792cceddecfd  push r8
0000792cceddecff  push r9
0000792ccedded01  push r10
0000792ccedded03  push r11
0000792ccedded05  sub rsp, 0xF0
0000792ccedded0c  vmovaps [rsp], xmm0
0000792ccedded11  vmovaps [rsp+0x10], xmm2
0000792ccedded17  vmovaps [rsp+0x20], xmm3
0000792ccedded1d  vmovaps [rsp+0x30], xmm4
0000792ccedded23  vmovaps [rsp+0x40], xmm5
0000792ccedded29  vmovaps [rsp+0x50], xmm6
0000792ccedded2f  vmovaps [rsp+0x60], xmm7
0000792ccedded35  vmovaps [rsp+0x70], xmm8
0000792ccedded3b  vmovaps [rsp+0x80], xmm9
0000792ccedded44  vmovaps [rsp+0x90], xmm10
0000792ccedded4d  vmovaps [rsp+0xA0], xmm11
0000792ccedded56  vmovaps [rsp+0xB0], xmm12
0000792ccedded5f  vmovaps [rsp+0xC0], xmm13
0000792ccedded68  vmovaps [rsp+0xD0], xmm14
0000792ccedded71  vmovaps [rsp+0xE0], xmm15
0000792ccedded7a  sub rsp, 0x30
0000792ccedded7e  movaps [rsp], xmm1
0000792ccedded82  movaps [rsp+0x10], xmm4
0000792ccedded87  movaps [rsp+0x20], xmm9
0000792ccedded8d  lea rdi, [rsp]
0000792ccedded91  mov esi, 0x00
0000792ccedded96  mov rax, 0x5AEE2D541530
0000792cceddeda0  call rax
0000792cceddeda2  movaps xmm1, [rsp]
0000792cceddeda6  add rsp, 0x30
0000792cceddedaa  vmovaps xmm0, [rsp]
0000792cceddedaf  vmovaps xmm2, [rsp+0x10]
0000792cceddedb5  vmovaps xmm3, [rsp+0x20]
0000792cceddedbb  vmovaps xmm4, [rsp+0x30]
0000792cceddedc1  vmovaps xmm5, [rsp+0x40]
0000792cceddedc7  vmovaps xmm6, [rsp+0x50]
0000792cceddedcd  vmovaps xmm7, [rsp+0x60]
0000792cceddedd3  vmovaps xmm8, [rsp+0x70]
0000792cceddedd9  vmovaps xmm9, [rsp+0x80]
0000792cceddede2  vmovaps xmm10, [rsp+0x90]
0000792cceddedeb  vmovaps xmm11, [rsp+0xA0]
0000792cceddedf4  vmovaps xmm12, [rsp+0xB0]
0000792cceddedfd  vmovaps xmm13, [rsp+0xC0]
0000792cceddee06  vmovaps xmm14, [rsp+0xD0]
0000792cceddee0f  vmovaps xmm15, [rsp+0xE0]
0000792cceddee18  add rsp, 0xF0
0000792cceddee1f  pop r11
0000792cceddee21  pop r10
0000792cceddee23  pop r9
0000792cceddee25  pop r8
0000792cceddee27  pop rsi
0000792cceddee28  pop rdi
0000792cceddee29  pop rdx
0000792cceddee2a  pop rcx
0000792cceddee2b  pop rax
0000792cceddee2c  add rsp, 0x08
0000792cceddee30  jmp 0x0000792CCEDDC2EE
0000792cceddee35  sub rsp, 0x08
0000792cceddee39  push rax
0000792cceddee3a  push rcx
0000792cceddee3b  push rdx
0000792cceddee3c  push rdi
0000792cceddee3d  push rsi
0000792cceddee3e  push r8
0000792cceddee40  push r9
0000792cceddee42  push r10
0000792cceddee44  push r11
0000792cceddee46  sub rsp, 0xF0
0000792cceddee4d  vmovaps [rsp], xmm0
0000792cceddee52  vmovaps [rsp+0x10], xmm1
0000792cceddee58  vmovaps [rsp+0x20], xmm2
0000792cceddee5e  vmovaps [rsp+0x30], xmm3
0000792cceddee64  vmovaps [rsp+0x40], xmm5
0000792cceddee6a  vmovaps [rsp+0x50], xmm6
0000792cceddee70  vmovaps [rsp+0x60], xmm7
0000792cceddee76  vmovaps [rsp+0x70], xmm8
0000792cceddee7c  vmovaps [rsp+0x80], xmm9
0000792cceddee85  vmovaps [rsp+0x90], xmm10
0000792cceddee8e  vmovaps [rsp+0xA0], xmm11
0000792cceddee97  vmovaps [rsp+0xB0], xmm12
0000792cceddeea0  vmovaps [rsp+0xC0], xmm13
0000792cceddeea9  vmovaps [rsp+0xD0], xmm14
0000792cceddeeb2  vmovaps [rsp+0xE0], xmm15
0000792cceddeebb  sub rsp, 0x30
0000792cceddeebf  movaps [rsp], xmm4
0000792cceddeec3  movaps [rsp+0x10], xmm2
0000792cceddeec8  movaps [rsp+0x20], xmm9
0000792cceddeece  lea rdi, [rsp]
0000792cceddeed2  mov esi, 0x00
0000792cceddeed7  mov rax, 0x5AEE2D541530
0000792cceddeee1  call rax
0000792cceddeee3  movaps xmm4, [rsp]
0000792cceddeee7  add rsp, 0x30
0000792cceddeeeb  vmovaps xmm0, [rsp]
0000792cceddeef0  vmovaps xmm1, [rsp+0x10]
0000792cceddeef6  vmovaps xmm2, [rsp+0x20]
0000792cceddeefc  vmovaps xmm3, [rsp+0x30]
0000792cceddef02  vmovaps xmm5, [rsp+0x40]
0000792cceddef08  vmovaps xmm6, [rsp+0x50]
0000792cceddef0e  vmovaps xmm7, [rsp+0x60]
0000792cceddef14  vmovaps xmm8, [rsp+0x70]
0000792cceddef1a  vmovaps xmm9, [rsp+0x80]
0000792cceddef23  vmovaps xmm10, [rsp+0x90]
0000792cceddef2c  vmovaps xmm11, [rsp+0xA0]
0000792cceddef35  vmovaps xmm12, [rsp+0xB0]
0000792cceddef3e  vmovaps xmm13, [rsp+0xC0]
0000792cceddef47  vmovaps xmm14, [rsp+0xD0]
0000792cceddef50  vmovaps xmm15, [rsp+0xE0]
0000792cceddef59  add rsp, 0xF0
0000792cceddef60  pop r11
0000792cceddef62  pop r10
0000792cceddef64  pop r9
0000792cceddef66  pop r8
0000792cceddef68  pop rsi
0000792cceddef69  pop rdi
0000792cceddef6a  pop rdx
0000792cceddef6b  pop rcx
0000792cceddef6c  pop rax
0000792cceddef6d  add rsp, 0x08
0000792cceddef71  jmp 0x0000792CCEDDC31E
0000792cceddef76  sub rsp, 0x08
0000792cceddef7a  push rax
0000792cceddef7b  push rcx
0000792cceddef7c  push rdx
0000792cceddef7d  push rdi
0000792cceddef7e  push rsi
0000792cceddef7f  push r8
0000792cceddef81  push r9
0000792cceddef83  push r10
0000792cceddef85  push r11
0000792cceddef87  sub rsp, 0xF0
0000792cceddef8e  vmovaps [rsp], xmm0
0000792cceddef93  vmovaps [rsp+0x10], xmm1
0000792cceddef99  vmovaps [rsp+0x20], xmm2
0000792cceddef9f  vmovaps [rsp+0x30], xmm3
0000792cceddefa5  vmovaps [rsp+0x40], xmm4
0000792cceddefab  vmovaps [rsp+0x50], xmm5
0000792cceddefb1  vmovaps [rsp+0x60], xmm6
0000792cceddefb7  vmovaps [rsp+0x70], xmm7
0000792cceddefbd  vmovaps [rsp+0x80], xmm8
0000792cceddefc6  vmovaps [rsp+0x90], xmm10
0000792cceddefcf  vmovaps [rsp+0xA0], xmm11
0000792cceddefd8  vmovaps [rsp+0xB0], xmm12
0000792cceddefe1  vmovaps [rsp+0xC0], xmm13
0000792cceddefea  vmovaps [rsp+0xD0], xmm14
0000792cceddeff3  vmovaps [rsp+0xE0], xmm15
0000792cceddeffc  sub rsp, 0x30
0000792cceddf000  movaps [rsp], xmm9
0000792cceddf005  movaps [rsp+0x10], xmm2
0000792cceddf00a  movaps [rsp+0x20], xmm1
0000792cceddf00f  lea rdi, [rsp]
0000792cceddf013  mov esi, 0x00
0000792cceddf018  mov rax, 0x5AEE2D541530
0000792cceddf022  call rax
0000792cceddf024  movaps xmm9, [rsp]
0000792cceddf029  add rsp, 0x30
0000792cceddf02d  vmovaps xmm0, [rsp]
0000792cceddf032  vmovaps xmm1, [rsp+0x10]
0000792cceddf038  vmovaps xmm2, [rsp+0x20]
0000792cceddf03e  vmovaps xmm3, [rsp+0x30]
0000792cceddf044  vmovaps xmm4, [rsp+0x40]
0000792cceddf04a  vmovaps xmm5, [rsp+0x50]
0000792cceddf050  vmovaps xmm6, [rsp+0x60]
0000792cceddf056  vmovaps xmm7, [rsp+0x70]
0000792cceddf05c  vmovaps xmm8, [rsp+0x80]
0000792cceddf065  vmovaps xmm10, [rsp+0x90]
0000792cceddf06e  vmovaps xmm11, [rsp+0xA0]
0000792cceddf077  vmovaps xmm12, [rsp+0xB0]
0000792cceddf080  vmovaps xmm13, [rsp+0xC0]
0000792cceddf089  vmovaps xmm14, [rsp+0xD0]
0000792cceddf092  vmovaps xmm15, [rsp+0xE0]
0000792cceddf09b  add rsp, 0xF0
0000792cceddf0a2  pop r11
0000792cceddf0a4  pop r10
0000792cceddf0a6  pop r9
0000792cceddf0a8  pop r8
0000792cceddf0aa  pop rsi
0000792cceddf0ab  pop rdi
0000792cceddf0ac  pop rdx
0000792cceddf0ad  pop rcx
0000792cceddf0ae  pop rax
0000792cceddf0af  add rsp, 0x08
0000792cceddf0b3  jmp 0x0000792CCEDDC354
0000792cceddf0b8  sub rsp, 0x08
0000792cceddf0bc  push rax
0000792cceddf0bd  push rcx
0000792cceddf0be  push rdx
0000792cceddf0bf  push rdi
0000792cceddf0c0  push rsi
0000792cceddf0c1  push r8
0000792cceddf0c3  push r9
0000792cceddf0c5  push r10
0000792cceddf0c7  push r11
0000792cceddf0c9  sub rsp, 0xF0
0000792cceddf0d0  vmovaps [rsp], xmm0
0000792cceddf0d5  vmovaps [rsp+0x10], xmm2
0000792cceddf0db  vmovaps [rsp+0x20], xmm3
0000792cceddf0e1  vmovaps [rsp+0x30], xmm4
0000792cceddf0e7  vmovaps [rsp+0x40], xmm5
0000792cceddf0ed  vmovaps [rsp+0x50], xmm6
0000792cceddf0f3  vmovaps [rsp+0x60], xmm7
0000792cceddf0f9  vmovaps [rsp+0x70], xmm8
0000792cceddf0ff  vmovaps [rsp+0x80], xmm9
0000792cceddf108  vmovaps [rsp+0x90], xmm10
0000792cceddf111  vmovaps [rsp+0xA0], xmm11
0000792cceddf11a  vmovaps [rsp+0xB0], xmm12
0000792cceddf123  vmovaps [rsp+0xC0], xmm13
0000792cceddf12c  vmovaps [rsp+0xD0], xmm14
0000792cceddf135  vmovaps [rsp+0xE0], xmm15
0000792cceddf13e  sub rsp, 0x30
0000792cceddf142  movaps [rsp], xmm1
0000792cceddf146  movaps [rsp+0x10], xmm15
0000792cceddf14c  movaps [rsp+0x20], xmm6
0000792cceddf151  lea rdi, [rsp]
0000792cceddf155  mov esi, 0x00
0000792cceddf15a  mov rax, 0x5AEE2D541530
0000792cceddf164  call rax
0000792cceddf166  movaps xmm1, [rsp]
0000792cceddf16a  add rsp, 0x30
0000792cceddf16e  vmovaps xmm0, [rsp]
0000792cceddf173  vmovaps xmm2, [rsp+0x10]
0000792cceddf179  vmovaps xmm3, [rsp+0x20]
0000792cceddf17f  vmovaps xmm4, [rsp+0x30]
0000792cceddf185  vmovaps xmm5, [rsp+0x40]
0000792cceddf18b  vmovaps xmm6, [rsp+0x50]
0000792cceddf191  vmovaps xmm7, [rsp+0x60]
0000792cceddf197  vmovaps xmm8, [rsp+0x70]
0000792cceddf19d  vmovaps xmm9, [rsp+0x80]
0000792cceddf1a6  vmovaps xmm10, [rsp+0x90]
0000792cceddf1af  vmovaps xmm11, [rsp+0xA0]
0000792cceddf1b8  vmovaps xmm12, [rsp+0xB0]
0000792cceddf1c1  vmovaps xmm13, [rsp+0xC0]
0000792cceddf1ca  vmovaps xmm14, [rsp+0xD0]
0000792cceddf1d3  vmovaps xmm15, [rsp+0xE0]
0000792cceddf1dc  add rsp, 0xF0
0000792cceddf1e3  pop r11
0000792cceddf1e5  pop r10
0000792cceddf1e7  pop r9
0000792cceddf1e9  pop r8
0000792cceddf1eb  pop rsi
0000792cceddf1ec  pop rdi
0000792cceddf1ed  pop rdx
0000792cceddf1ee  pop rcx
0000792cceddf1ef  pop rax
0000792cceddf1f0  add rsp, 0x08
0000792cceddf1f4  jmp 0x0000792CCEDDC375
0000792cceddf1f9  sub rsp, 0x08
0000792cceddf1fd  push rax
0000792cceddf1fe  push rcx
0000792cceddf1ff  push rdx
0000792cceddf200  push rdi
0000792cceddf201  push rsi
0000792cceddf202  push r8
0000792cceddf204  push r9
0000792cceddf206  push r10
0000792cceddf208  push r11
0000792cceddf20a  sub rsp, 0xF0
0000792cceddf211  vmovaps [rsp], xmm0
0000792cceddf216  vmovaps [rsp+0x10], xmm1
0000792cceddf21c  vmovaps [rsp+0x20], xmm2
0000792cceddf222  vmovaps [rsp+0x30], xmm3
0000792cceddf228  vmovaps [rsp+0x40], xmm4
0000792cceddf22e  vmovaps [rsp+0x50], xmm5
0000792cceddf234  vmovaps [rsp+0x60], xmm6
0000792cceddf23a  vmovaps [rsp+0x70], xmm7
0000792cceddf240  vmovaps [rsp+0x80], xmm8
0000792cceddf249  vmovaps [rsp+0x90], xmm9
0000792cceddf252  vmovaps [rsp+0xA0], xmm10
0000792cceddf25b  vmovaps [rsp+0xB0], xmm11
0000792cceddf264  vmovaps [rsp+0xC0], xmm12
0000792cceddf26d  vmovaps [rsp+0xD0], xmm13
0000792cceddf276  vmovaps [rsp+0xE0], xmm14
0000792cceddf27f  sub rsp, 0x30
0000792cceddf283  movaps [rsp], xmm15
0000792cceddf288  movaps [rsp+0x10], xmm5
0000792cceddf28d  movaps [rsp+0x20], xmm3
0000792cceddf292  lea rdi, [rsp]
0000792cceddf296  mov esi, 0x00
0000792cceddf29b  mov rax, 0x5AEE2D541530
0000792cceddf2a5  call rax
0000792cceddf2a7  movaps xmm15, [rsp]
0000792cceddf2ac  add rsp, 0x30
0000792cceddf2b0  vmovaps xmm0, [rsp]
0000792cceddf2b5  vmovaps xmm1, [rsp+0x10]
0000792cceddf2bb  vmovaps xmm2, [rsp+0x20]
0000792cceddf2c1  vmovaps xmm3, [rsp+0x30]
0000792cceddf2c7  vmovaps xmm4, [rsp+0x40]
0000792cceddf2cd  vmovaps xmm5, [rsp+0x50]
0000792cceddf2d3  vmovaps xmm6, [rsp+0x60]
0000792cceddf2d9  vmovaps xmm7, [rsp+0x70]
0000792cceddf2df  vmovaps xmm8, [rsp+0x80]
0000792cceddf2e8  vmovaps xmm9, [rsp+0x90]
0000792cceddf2f1  vmovaps xmm10, [rsp+0xA0]
0000792cceddf2fa  vmovaps xmm11, [rsp+0xB0]
0000792cceddf303  vmovaps xmm12, [rsp+0xC0]
0000792cceddf30c  vmovaps xmm13, [rsp+0xD0]
0000792cceddf315  vmovaps xmm14, [rsp+0xE0]
0000792cceddf31e  add rsp, 0xF0
0000792cceddf325  pop r11
0000792cceddf327  pop r10
0000792cceddf329  pop r9
0000792cceddf32b  pop r8
0000792cceddf32d  pop rsi
0000792cceddf32e  pop rdi
0000792cceddf32f  pop rdx
0000792cceddf330  pop rcx
0000792cceddf331  pop rax
0000792cceddf332  add rsp, 0x08
0000792cceddf336  jmp 0x0000792CCEDDC38F
0000792cceddf33b  sub rsp, 0x08
0000792cceddf33f  push rax
0000792cceddf340  push rcx
0000792cceddf341  push rdx
0000792cceddf342  push rdi
0000792cceddf343  push rsi
0000792cceddf344  push r8
0000792cceddf346  push r9
0000792cceddf348  push r10
0000792cceddf34a  push r11
0000792cceddf34c  sub rsp, 0xF0
0000792cceddf353  vmovaps [rsp], xmm0
0000792cceddf358  vmovaps [rsp+0x10], xmm1
0000792cceddf35e  vmovaps [rsp+0x20], xmm2
0000792cceddf364  vmovaps [rsp+0x30], xmm3
0000792cceddf36a  vmovaps [rsp+0x40], xmm4
0000792cceddf370  vmovaps [rsp+0x50], xmm6
0000792cceddf376  vmovaps [rsp+0x60], xmm7
0000792cceddf37c  vmovaps [rsp+0x70], xmm8
0000792cceddf382  vmovaps [rsp+0x80], xmm9
0000792cceddf38b  vmovaps [rsp+0x90], xmm10
0000792cceddf394  vmovaps [rsp+0xA0], xmm11
0000792cceddf39d  vmovaps [rsp+0xB0], xmm12
0000792cceddf3a6  vmovaps [rsp+0xC0], xmm13
0000792cceddf3af  vmovaps [rsp+0xD0], xmm14
0000792cceddf3b8  vmovaps [rsp+0xE0], xmm15
0000792cceddf3c1  sub rsp, 0x30
0000792cceddf3c5  movaps [rsp], xmm5
0000792cceddf3c9  movaps [rsp+0x10], xmm8
0000792cceddf3cf  movaps [rsp+0x20], xmm6
0000792cceddf3d4  lea rdi, [rsp]
0000792cceddf3d8  mov esi, 0x00
0000792cceddf3dd  mov rax, 0x5AEE2D541530
0000792cceddf3e7  call rax
0000792cceddf3e9  movaps xmm5, [rsp]
0000792cceddf3ed  add rsp, 0x30
0000792cceddf3f1  vmovaps xmm0, [rsp]
0000792cceddf3f6  vmovaps xmm1, [rsp+0x10]
0000792cceddf3fc  vmovaps xmm2, [rsp+0x20]
0000792cceddf402  vmovaps xmm3, [rsp+0x30]
0000792cceddf408  vmovaps xmm4, [rsp+0x40]
0000792cceddf40e  vmovaps xmm6, [rsp+0x50]
0000792cceddf414  vmovaps xmm7, [rsp+0x60]
0000792cceddf41a  vmovaps xmm8, [rsp+0x70]
0000792cceddf420  vmovaps xmm9, [rsp+0x80]
0000792cceddf429  vmovaps xmm10, [rsp+0x90]
0000792cceddf432  vmovaps xmm11, [rsp+0xA0]
0000792cceddf43b  vmovaps xmm12, [rsp+0xB0]
0000792cceddf444  vmovaps xmm13, [rsp+0xC0]
0000792cceddf44d  vmovaps xmm14, [rsp+0xD0]
0000792cceddf456  vmovaps xmm15, [rsp+0xE0]
0000792cceddf45f  add rsp, 0xF0
0000792cceddf466  pop r11
0000792cceddf468  pop r10
0000792cceddf46a  pop r9
0000792cceddf46c  pop r8
0000792cceddf46e  pop rsi
0000792cceddf46f  pop rdi
0000792cceddf470  pop rdx
0000792cceddf471  pop rcx
0000792cceddf472  pop rax
0000792cceddf473  add rsp, 0x08
0000792cceddf477  jmp 0x0000792CCEDDC3B3
0000792cceddf47c  sub rsp, 0x08
0000792cceddf480  push rax
0000792cceddf481  push rcx
0000792cceddf482  push rdx
0000792cceddf483  push rdi
0000792cceddf484  push rsi
0000792cceddf485  push r8
0000792cceddf487  push r9
0000792cceddf489  push r10
0000792cceddf48b  push r11
0000792cceddf48d  sub rsp, 0xF0
0000792cceddf494  vmovaps [rsp], xmm0
0000792cceddf499  vmovaps [rsp+0x10], xmm1
0000792cceddf49f  vmovaps [rsp+0x20], xmm2
0000792cceddf4a5  vmovaps [rsp+0x30], xmm3
0000792cceddf4ab  vmovaps [rsp+0x40], xmm4
0000792cceddf4b1  vmovaps [rsp+0x50], xmm5
0000792cceddf4b7  vmovaps [rsp+0x60], xmm7
0000792cceddf4bd  vmovaps [rsp+0x70], xmm8
0000792cceddf4c3  vmovaps [rsp+0x80], xmm9
0000792cceddf4cc  vmovaps [rsp+0x90], xmm10
0000792cceddf4d5  vmovaps [rsp+0xA0], xmm11
0000792cceddf4de  vmovaps [rsp+0xB0], xmm12
0000792cceddf4e7  vmovaps [rsp+0xC0], xmm13
0000792cceddf4f0  vmovaps [rsp+0xD0], xmm14
0000792cceddf4f9  vmovaps [rsp+0xE0], xmm15
0000792cceddf502  sub rsp, 0x30
0000792cceddf506  movaps [rsp], xmm6
0000792cceddf50a  movaps [rsp+0x10], xmm10
0000792cceddf510  movaps [rsp+0x20], xmm8
0000792cceddf516  lea rdi, [rsp]
0000792cceddf51a  mov esi, 0x00
0000792cceddf51f  mov rax, 0x5AEE2D541530
0000792cceddf529  call rax
0000792cceddf52b  movaps xmm6, [rsp]
0000792cceddf52f  add rsp, 0x30
0000792cceddf533  vmovaps xmm0, [rsp]
0000792cceddf538  vmovaps xmm1, [rsp+0x10]
0000792cceddf53e  vmovaps xmm2, [rsp+0x20]
0000792cceddf544  vmovaps xmm3, [rsp+0x30]
0000792cceddf54a  vmovaps xmm4, [rsp+0x40]
0000792cceddf550  vmovaps xmm5, [rsp+0x50]
0000792cceddf556  vmovaps xmm7, [rsp+0x60]
0000792cceddf55c  vmovaps xmm8, [rsp+0x70]
0000792cceddf562  vmovaps xmm9, [rsp+0x80]
0000792cceddf56b  vmovaps xmm10, [rsp+0x90]
0000792cceddf574  vmovaps xmm11, [rsp+0xA0]
0000792cceddf57d  vmovaps xmm12, [rsp+0xB0]
0000792cceddf586  vmovaps xmm13, [rsp+0xC0]
0000792cceddf58f  vmovaps xmm14, [rsp+0xD0]
0000792cceddf598  vmovaps xmm15, [rsp+0xE0]
0000792cceddf5a1  add rsp, 0xF0
0000792cceddf5a8  pop r11
0000792cceddf5aa  pop r10
0000792cceddf5ac  pop r9
0000792cceddf5ae  pop r8
0000792cceddf5b0  pop rsi
0000792cceddf5b1  pop rdi
0000792cceddf5b2  pop rdx
0000792cceddf5b3  pop rcx
0000792cceddf5b4  pop rax
0000792cceddf5b5  add rsp, 0x08
0000792cceddf5b9  jmp 0x0000792CCEDDC3D8
0000792cceddf5be  sub rsp, 0x08
0000792cceddf5c2  push rax
0000792cceddf5c3  push rcx
0000792cceddf5c4  push rdx
0000792cceddf5c5  push rdi
0000792cceddf5c6  push rsi
0000792cceddf5c7  push r8
0000792cceddf5c9  push r9
0000792cceddf5cb  push r10
0000792cceddf5cd  push r11
0000792cceddf5cf  sub rsp, 0xF0
0000792cceddf5d6  vmovaps [rsp], xmm0
0000792cceddf5db  vmovaps [rsp+0x10], xmm1
0000792cceddf5e1  vmovaps [rsp+0x20], xmm2
0000792cceddf5e7  vmovaps [rsp+0x30], xmm3
0000792cceddf5ed  vmovaps [rsp+0x40], xmm4
0000792cceddf5f3  vmovaps [rsp+0x50], xmm5
0000792cceddf5f9  vmovaps [rsp+0x60], xmm6
0000792cceddf5ff  vmovaps [rsp+0x70], xmm7
0000792cceddf605  vmovaps [rsp+0x80], xmm8
0000792cceddf60e  vmovaps [rsp+0x90], xmm9
0000792cceddf617  vmovaps [rsp+0xA0], xmm11
0000792cceddf620  vmovaps [rsp+0xB0], xmm12
0000792cceddf629  vmovaps [rsp+0xC0], xmm13
0000792cceddf632  vmovaps [rsp+0xD0], xmm14
0000792cceddf63b  vmovaps [rsp+0xE0], xmm15
0000792cceddf644  sub rsp, 0x30
0000792cceddf648  movaps [rsp], xmm10
0000792cceddf64d  movaps [rsp+0x10], xmm8
0000792cceddf653  movaps [rsp+0x20], xmm14
0000792cceddf659  lea rdi, [rsp]
0000792cceddf65d  mov esi, 0x00
0000792cceddf662  mov rax, 0x5AEE2D541530
0000792cceddf66c  call rax
0000792cceddf66e  movaps xmm10, [rsp]
0000792cceddf673  add rsp, 0x30
0000792cceddf677  vmovaps xmm0, [rsp]
0000792cceddf67c  vmovaps xmm1, [rsp+0x10]
0000792cceddf682  vmovaps xmm2, [rsp+0x20]
0000792cceddf688  vmovaps xmm3, [rsp+0x30]
0000792cceddf68e  vmovaps xmm4, [rsp+0x40]
0000792cceddf694  vmovaps xmm5, [rsp+0x50]
0000792cceddf69a  vmovaps xmm6, [rsp+0x60]
0000792cceddf6a0  vmovaps xmm7, [rsp+0x70]
0000792cceddf6a6  vmovaps xmm8, [rsp+0x80]
0000792cceddf6af  vmovaps xmm9, [rsp+0x90]
0000792cceddf6b8  vmovaps xmm11, [rsp+0xA0]
0000792cceddf6c1  vmovaps xmm12, [rsp+0xB0]
0000792cceddf6ca  vmovaps xmm13, [rsp+0xC0]
0000792cceddf6d3  vmovaps xmm14, [rsp+0xD0]
0000792cceddf6dc  vmovaps xmm15, [rsp+0xE0]
0000792cceddf6e5  add rsp, 0xF0
0000792cceddf6ec  pop r11
0000792cceddf6ee  pop r10
0000792cceddf6f0  pop r9
0000792cceddf6f2  pop r8
0000792cceddf6f4  pop rsi
0000792cceddf6f5  pop rdi
0000792cceddf6f6  pop rdx
0000792cceddf6f7  pop rcx
0000792cceddf6f8  pop rax
0000792cceddf6f9  add rsp, 0x08
0000792cceddf6fd  jmp 0x0000792CCEDDC3F8
0000792cceddf702  sub rsp, 0x08
0000792cceddf706  push rax
0000792cceddf707  push rcx
0000792cceddf708  push rdx
0000792cceddf709  push rdi
0000792cceddf70a  push rsi
0000792cceddf70b  push r8
0000792cceddf70d  push r9
0000792cceddf70f  push r10
0000792cceddf711  push r11
0000792cceddf713  sub rsp, 0xF0
0000792cceddf71a  vmovaps [rsp], xmm0
0000792cceddf71f  vmovaps [rsp+0x10], xmm1
0000792cceddf725  vmovaps [rsp+0x20], xmm2
0000792cceddf72b  vmovaps [rsp+0x30], xmm3
0000792cceddf731  vmovaps [rsp+0x40], xmm4
0000792cceddf737  vmovaps [rsp+0x50], xmm5
0000792cceddf73d  vmovaps [rsp+0x60], xmm6
0000792cceddf743  vmovaps [rsp+0x70], xmm7
0000792cceddf749  vmovaps [rsp+0x80], xmm8
0000792cceddf752  vmovaps [rsp+0x90], xmm9
0000792cceddf75b  vmovaps [rsp+0xA0], xmm10
0000792cceddf764  vmovaps [rsp+0xB0], xmm11
0000792cceddf76d  vmovaps [rsp+0xC0], xmm12
0000792cceddf776  vmovaps [rsp+0xD0], xmm13
0000792cceddf77f  vmovaps [rsp+0xE0], xmm15
0000792cceddf788  sub rsp, 0x30
0000792cceddf78c  movaps [rsp], xmm14
0000792cceddf791  movaps [rsp+0x10], xmm8
0000792cceddf797  movaps [rsp+0x20], xmm4
0000792cceddf79c  lea rdi, [rsp]
0000792cceddf7a0  mov esi, 0x00
0000792cceddf7a5  mov rax, 0x5AEE2D541530
0000792cceddf7af  call rax
0000792cceddf7b1  movaps xmm14, [rsp]
0000792cceddf7b6  add rsp, 0x30
0000792cceddf7ba  vmovaps xmm0, [rsp]
0000792cceddf7bf  vmovaps xmm1, [rsp+0x10]
0000792cceddf7c5  vmovaps xmm2, [rsp+0x20]
0000792cceddf7cb  vmovaps xmm3, [rsp+0x30]
0000792cceddf7d1  vmovaps xmm4, [rsp+0x40]
0000792cceddf7d7  vmovaps xmm5, [rsp+0x50]
0000792cceddf7dd  vmovaps xmm6, [rsp+0x60]
0000792cceddf7e3  vmovaps xmm7, [rsp+0x70]
0000792cceddf7e9  vmovaps xmm8, [rsp+0x80]
0000792cceddf7f2  vmovaps xmm9, [rsp+0x90]
0000792cceddf7fb  vmovaps xmm10, [rsp+0xA0]
0000792cceddf804  vmovaps xmm11, [rsp+0xB0]
0000792cceddf80d  vmovaps xmm12, [rsp+0xC0]
0000792cceddf816  vmovaps xmm13, [rsp+0xD0]
0000792cceddf81f  vmovaps xmm15, [rsp+0xE0]
0000792cceddf828  add rsp, 0xF0
0000792cceddf82f  pop r11
0000792cceddf831  pop r10
0000792cceddf833  pop r9
0000792cceddf835  pop r8
0000792cceddf837  pop rsi
0000792cceddf838  pop rdi
0000792cceddf839  pop rdx
0000792cceddf83a  pop rcx
0000792cceddf83b  pop rax
0000792cceddf83c  add rsp, 0x08
0000792cceddf840  jmp 0x0000792CCEDDC418
0000792cceddf845  sub rsp, 0x08
0000792cceddf849  push rax
0000792cceddf84a  push rcx
0000792cceddf84b  push rdx
0000792cceddf84c  push rdi
0000792cceddf84d  push rsi
0000792cceddf84e  push r8
0000792cceddf850  push r9
0000792cceddf852  push r10
0000792cceddf854  push r11
0000792cceddf856  sub rsp, 0xF0
0000792cceddf85d  vmovaps [rsp], xmm0
0000792cceddf862  vmovaps [rsp+0x10], xmm1
0000792cceddf868  vmovaps [rsp+0x20], xmm2
0000792cceddf86e  vmovaps [rsp+0x30], xmm3
0000792cceddf874  vmovaps [rsp+0x40], xmm5
0000792cceddf87a  vmovaps [rsp+0x50], xmm6
0000792cceddf880  vmovaps [rsp+0x60], xmm7
0000792cceddf886  vmovaps [rsp+0x70], xmm8
0000792cceddf88c  vmovaps [rsp+0x80], xmm9
0000792cceddf895  vmovaps [rsp+0x90], xmm10
0000792cceddf89e  vmovaps [rsp+0xA0], xmm11
0000792cceddf8a7  vmovaps [rsp+0xB0], xmm12
0000792cceddf8b0  vmovaps [rsp+0xC0], xmm13
0000792cceddf8b9  vmovaps [rsp+0xD0], xmm14
0000792cceddf8c2  vmovaps [rsp+0xE0], xmm15
0000792cceddf8cb  sub rsp, 0x30
0000792cceddf8cf  movaps [rsp], xmm4
0000792cceddf8d3  movaps [rsp+0x10], xmm13
0000792cceddf8d9  movaps [rsp+0x20], xmm8
0000792cceddf8df  lea rdi, [rsp]
0000792cceddf8e3  mov esi, 0x00
0000792cceddf8e8  mov rax, 0x5AEE2D541530
0000792cceddf8f2  call rax
0000792cceddf8f4  movaps xmm4, [rsp]
0000792cceddf8f8  add rsp, 0x30
0000792cceddf8fc  vmovaps xmm0, [rsp]
0000792cceddf901  vmovaps xmm1, [rsp+0x10]
0000792cceddf907  vmovaps xmm2, [rsp+0x20]
0000792cceddf90d  vmovaps xmm3, [rsp+0x30]
0000792cceddf913  vmovaps xmm5, [rsp+0x40]
0000792cceddf919  vmovaps xmm6, [rsp+0x50]
0000792cceddf91f  vmovaps xmm7, [rsp+0x60]
0000792cceddf925  vmovaps xmm8, [rsp+0x70]
0000792cceddf92b  vmovaps xmm9, [rsp+0x80]
0000792cceddf934  vmovaps xmm10, [rsp+0x90]
0000792cceddf93d  vmovaps xmm11, [rsp+0xA0]
0000792cceddf946  vmovaps xmm12, [rsp+0xB0]
0000792cceddf94f  vmovaps xmm13, [rsp+0xC0]
0000792cceddf958  vmovaps xmm14, [rsp+0xD0]
0000792cceddf961  vmovaps xmm15, [rsp+0xE0]
0000792cceddf96a  add rsp, 0xF0
0000792cceddf971  pop r11
0000792cceddf973  pop r10
0000792cceddf975  pop r9
0000792cceddf977  pop r8
0000792cceddf979  pop rsi
0000792cceddf97a  pop rdi
0000792cceddf97b  pop rdx
0000792cceddf97c  pop rcx
0000792cceddf97d  pop rax
0000792cceddf97e  add rsp, 0x08
0000792cceddf982  jmp 0x0000792CCEDDC43D
0000792cceddf987  sub rsp, 0x08
0000792cceddf98b  push rax
0000792cceddf98c  push rcx
0000792cceddf98d  push rdx
0000792cceddf98e  push rdi
0000792cceddf98f  push rsi
0000792cceddf990  push r8
0000792cceddf992  push r9
0000792cceddf994  push r10
0000792cceddf996  push r11
0000792cceddf998  sub rsp, 0xF0
0000792cceddf99f  vmovaps [rsp], xmm0
0000792cceddf9a4  vmovaps [rsp+0x10], xmm1
0000792cceddf9aa  vmovaps [rsp+0x20], xmm2
0000792cceddf9b0  vmovaps [rsp+0x30], xmm3
0000792cceddf9b6  vmovaps [rsp+0x40], xmm4
0000792cceddf9bc  vmovaps [rsp+0x50], xmm5
0000792cceddf9c2  vmovaps [rsp+0x60], xmm6
0000792cceddf9c8  vmovaps [rsp+0x70], xmm7
0000792cceddf9ce  vmovaps [rsp+0x80], xmm8
0000792cceddf9d7  vmovaps [rsp+0x90], xmm9
0000792cceddf9e0  vmovaps [rsp+0xA0], xmm10
0000792cceddf9e9  vmovaps [rsp+0xB0], xmm11
0000792cceddf9f2  vmovaps [rsp+0xC0], xmm12
0000792cceddf9fb  vmovaps [rsp+0xD0], xmm14
0000792cceddfa04  vmovaps [rsp+0xE0], xmm15
0000792cceddfa0d  sub rsp, 0x30
0000792cceddfa11  movaps [rsp], xmm13
0000792cceddfa16  movaps [rsp+0x10], xmm15
0000792cceddfa1c  movaps [rsp+0x20], xmm9
0000792cceddfa22  lea rdi, [rsp]
0000792cceddfa26  mov esi, 0x00
0000792cceddfa2b  mov rax, 0x5AEE2D541530
0000792cceddfa35  call rax
0000792cceddfa37  movaps xmm13, [rsp]
0000792cceddfa3c  add rsp, 0x30
0000792cceddfa40  vmovaps xmm0, [rsp]
0000792cceddfa45  vmovaps xmm1, [rsp+0x10]
0000792cceddfa4b  vmovaps xmm2, [rsp+0x20]
0000792cceddfa51  vmovaps xmm3, [rsp+0x30]
0000792cceddfa57  vmovaps xmm4, [rsp+0x40]
0000792cceddfa5d  vmovaps xmm5, [rsp+0x50]
0000792cceddfa63  vmovaps xmm6, [rsp+0x60]
0000792cceddfa69  vmovaps xmm7, [rsp+0x70]
0000792cceddfa6f  vmovaps xmm8, [rsp+0x80]
0000792cceddfa78  vmovaps xmm9, [rsp+0x90]
0000792cceddfa81  vmovaps xmm10, [rsp+0xA0]
0000792cceddfa8a  vmovaps xmm11, [rsp+0xB0]
0000792cceddfa93  vmovaps xmm12, [rsp+0xC0]
0000792cceddfa9c  vmovaps xmm14, [rsp+0xD0]
0000792cceddfaa5  vmovaps xmm15, [rsp+0xE0]
0000792cceddfaae  add rsp, 0xF0
0000792cceddfab5  pop r11
0000792cceddfab7  pop r10
0000792cceddfab9  pop r9
0000792cceddfabb  pop r8
0000792cceddfabd  pop rsi
0000792cceddfabe  pop rdi
0000792cceddfabf  pop rdx
0000792cceddfac0  pop rcx
0000792cceddfac1  pop rax
0000792cceddfac2  add rsp, 0x08
0000792cceddfac6  jmp 0x0000792CCEDDC458
0000792cceddfacb  sub rsp, 0x08
0000792cceddfacf  push rax
0000792cceddfad0  push rcx
0000792cceddfad1  push rdx
0000792cceddfad2  push rdi
0000792cceddfad3  push rsi
0000792cceddfad4  push r8
0000792cceddfad6  push r9
0000792cceddfad8  push r10
0000792cceddfada  push r11
0000792cceddfadc  sub rsp, 0xF0
0000792cceddfae3  vmovaps [rsp], xmm0
0000792cceddfae8  vmovaps [rsp+0x10], xmm1
0000792cceddfaee  vmovaps [rsp+0x20], xmm2
0000792cceddfaf4  vmovaps [rsp+0x30], xmm3
0000792cceddfafa  vmovaps [rsp+0x40], xmm4
0000792cceddfb00  vmovaps [rsp+0x50], xmm5
0000792cceddfb06  vmovaps [rsp+0x60], xmm6
0000792cceddfb0c  vmovaps [rsp+0x70], xmm7
0000792cceddfb12  vmovaps [rsp+0x80], xmm8
0000792cceddfb1b  vmovaps [rsp+0x90], xmm9
0000792cceddfb24  vmovaps [rsp+0xA0], xmm10
0000792cceddfb2d  vmovaps [rsp+0xB0], xmm11
0000792cceddfb36  vmovaps [rsp+0xC0], xmm12
0000792cceddfb3f  vmovaps [rsp+0xD0], xmm13
0000792cceddfb48  vmovaps [rsp+0xE0], xmm14
0000792cceddfb51  sub rsp, 0x30
0000792cceddfb55  movaps [rsp], xmm15
0000792cceddfb5a  movaps [rsp+0x10], xmm1
0000792cceddfb5f  movaps [rsp+0x20], xmm5
0000792cceddfb64  lea rdi, [rsp]
0000792cceddfb68  mov esi, 0x00
0000792cceddfb6d  mov rax, 0x5AEE2D541530
0000792cceddfb77  call rax
0000792cceddfb79  movaps xmm15, [rsp]
0000792cceddfb7e  add rsp, 0x30
0000792cceddfb82  vmovaps xmm0, [rsp]
0000792cceddfb87  vmovaps xmm1, [rsp+0x10]
0000792cceddfb8d  vmovaps xmm2, [rsp+0x20]
0000792cceddfb93  vmovaps xmm3, [rsp+0x30]
0000792cceddfb99  vmovaps xmm4, [rsp+0x40]
0000792cceddfb9f  vmovaps xmm5, [rsp+0x50]
0000792cceddfba5  vmovaps xmm6, [rsp+0x60]
0000792cceddfbab  vmovaps xmm7, [rsp+0x70]
0000792cceddfbb1  vmovaps xmm8, [rsp+0x80]
0000792cceddfbba  vmovaps xmm9, [rsp+0x90]
0000792cceddfbc3  vmovaps xmm10, [rsp+0xA0]
0000792cceddfbcc  vmovaps xmm11, [rsp+0xB0]
0000792cceddfbd5  vmovaps xmm12, [rsp+0xC0]
0000792cceddfbde  vmovaps xmm13, [rsp+0xD0]
0000792cceddfbe7  vmovaps xmm14, [rsp+0xE0]
0000792cceddfbf0  add rsp, 0xF0
0000792cceddfbf7  pop r11
0000792cceddfbf9  pop r10
0000792cceddfbfb  pop r9
0000792cceddfbfd  pop r8
0000792cceddfbff  pop rsi
0000792cceddfc00  pop rdi
0000792cceddfc01  pop rdx
0000792cceddfc02  pop rcx
0000792cceddfc03  pop rax
0000792cceddfc04  add rsp, 0x08
0000792cceddfc08  jmp 0x0000792CCEDDC473
0000792cceddfc0d  call 0x0000792CCECB52F0
0000792cceddfc12  jmp 0x0000792CCEDDC4CE
0000792cceddfc17  sub rsp, 0x08
0000792cceddfc1b  push rax
0000792cceddfc1c  push rcx
0000792cceddfc1d  push rdx
0000792cceddfc1e  push rdi
0000792cceddfc1f  push rsi
0000792cceddfc20  push r8
0000792cceddfc22  push r9
0000792cceddfc24  push r10
0000792cceddfc26  push r11
0000792cceddfc28  sub rsp, 0xF0
0000792cceddfc2f  vmovaps [rsp], xmm0
0000792cceddfc34  vmovaps [rsp+0x10], xmm1
0000792cceddfc3a  vmovaps [rsp+0x20], xmm2
0000792cceddfc40  vmovaps [rsp+0x30], xmm3
0000792cceddfc46  vmovaps [rsp+0x40], xmm4
0000792cceddfc4c  vmovaps [rsp+0x50], xmm5
0000792cceddfc52  vmovaps [rsp+0x60], xmm6
0000792cceddfc58  vmovaps [rsp+0x70], xmm7
0000792cceddfc5e  vmovaps [rsp+0x80], xmm8
0000792cceddfc67  vmovaps [rsp+0x90], xmm10
0000792cceddfc70  vmovaps [rsp+0xA0], xmm11
0000792cceddfc79  vmovaps [rsp+0xB0], xmm12
0000792cceddfc82  vmovaps [rsp+0xC0], xmm13
0000792cceddfc8b  vmovaps [rsp+0xD0], xmm14
0000792cceddfc94  vmovaps [rsp+0xE0], xmm15
0000792cceddfc9d  sub rsp, 0x30
0000792cceddfca1  movaps [rsp], xmm9
0000792cceddfca6  movaps [rsp+0x10], xmm8
0000792cceddfcac  movaps [rsp+0x20], xmm11
0000792cceddfcb2  lea rdi, [rsp]
0000792cceddfcb6  mov esi, 0x00
0000792cceddfcbb  mov rax, 0x5AEE2D541530
0000792cceddfcc5  call rax
0000792cceddfcc7  movaps xmm9, [rsp]
0000792cceddfccc  add rsp, 0x30
0000792cceddfcd0  vmovaps xmm0, [rsp]
0000792cceddfcd5  vmovaps xmm1, [rsp+0x10]
0000792cceddfcdb  vmovaps xmm2, [rsp+0x20]
0000792cceddfce1  vmovaps xmm3, [rsp+0x30]
0000792cceddfce7  vmovaps xmm4, [rsp+0x40]
0000792cceddfced  vmovaps xmm5, [rsp+0x50]
0000792cceddfcf3  vmovaps xmm6, [rsp+0x60]
0000792cceddfcf9  vmovaps xmm7, [rsp+0x70]
0000792cceddfcff  vmovaps xmm8, [rsp+0x80]
0000792cceddfd08  vmovaps xmm10, [rsp+0x90]
0000792cceddfd11  vmovaps xmm11, [rsp+0xA0]
0000792cceddfd1a  vmovaps xmm12, [rsp+0xB0]
0000792cceddfd23  vmovaps xmm13, [rsp+0xC0]
0000792cceddfd2c  vmovaps xmm14, [rsp+0xD0]
0000792cceddfd35  vmovaps xmm15, [rsp+0xE0]
0000792cceddfd3e  add rsp, 0xF0
0000792cceddfd45  pop r11
0000792cceddfd47  pop r10
0000792cceddfd49  pop r9
0000792cceddfd4b  pop r8
0000792cceddfd4d  pop rsi
0000792cceddfd4e  pop rdi
0000792cceddfd4f  pop rdx
0000792cceddfd50  pop rcx
0000792cceddfd51  pop rax
0000792cceddfd52  add rsp, 0x08
0000792cceddfd56  jmp 0x0000792CCEDDC505
0000792cceddfd5b  sub rsp, 0x08
0000792cceddfd5f  push rax
0000792cceddfd60  push rcx
0000792cceddfd61  push rdx
0000792cceddfd62  push rdi
0000792cceddfd63  push rsi
0000792cceddfd64  push r8
0000792cceddfd66  push r9
0000792cceddfd68  push r10
0000792cceddfd6a  push r11
0000792cceddfd6c  sub rsp, 0xF0
0000792cceddfd73  vmovaps [rsp], xmm0
0000792cceddfd78  vmovaps [rsp+0x10], xmm1
0000792cceddfd7e  vmovaps [rsp+0x20], xmm2
0000792cceddfd84  vmovaps [rsp+0x30], xmm3
0000792cceddfd8a  vmovaps [rsp+0x40], xmm4
0000792cceddfd90  vmovaps [rsp+0x50], xmm5
0000792cceddfd96  vmovaps [rsp+0x60], xmm6
0000792cceddfd9c  vmovaps [rsp+0x70], xmm7
0000792cceddfda2  vmovaps [rsp+0x80], xmm8
0000792cceddfdab  vmovaps [rsp+0x90], xmm9
0000792cceddfdb4  vmovaps [rsp+0xA0], xmm10
0000792cceddfdbd  vmovaps [rsp+0xB0], xmm12
0000792cceddfdc6  vmovaps [rsp+0xC0], xmm13
0000792cceddfdcf  vmovaps [rsp+0xD0], xmm14
0000792cceddfdd8  vmovaps [rsp+0xE0], xmm15
0000792cceddfde1  sub rsp, 0x30
0000792cceddfde5  movaps [rsp], xmm11
0000792cceddfdea  movaps [rsp+0x10], xmm10
0000792cceddfdf0  movaps [rsp+0x20], xmm6
0000792cceddfdf5  lea rdi, [rsp]
0000792cceddfdf9  mov esi, 0x00
0000792cceddfdfe  mov rax, 0x5AEE2D541530
0000792cceddfe08  call rax
0000792cceddfe0a  movaps xmm11, [rsp]
0000792cceddfe0f  add rsp, 0x30
0000792cceddfe13  vmovaps xmm0, [rsp]
0000792cceddfe18  vmovaps xmm1, [rsp+0x10]
0000792cceddfe1e  vmovaps xmm2, [rsp+0x20]
0000792cceddfe24  vmovaps xmm3, [rsp+0x30]
0000792cceddfe2a  vmovaps xmm4, [rsp+0x40]
0000792cceddfe30  vmovaps xmm5, [rsp+0x50]
0000792cceddfe36  vmovaps xmm6, [rsp+0x60]
0000792cceddfe3c  vmovaps xmm7, [rsp+0x70]
0000792cceddfe42  vmovaps xmm8, [rsp+0x80]
0000792cceddfe4b  vmovaps xmm9, [rsp+0x90]
0000792cceddfe54  vmovaps xmm10, [rsp+0xA0]
0000792cceddfe5d  vmovaps xmm12, [rsp+0xB0]
0000792cceddfe66  vmovaps xmm13, [rsp+0xC0]
0000792cceddfe6f  vmovaps xmm14, [rsp+0xD0]
0000792cceddfe78  vmovaps xmm15, [rsp+0xE0]
0000792cceddfe81  add rsp, 0xF0
0000792cceddfe88  pop r11
0000792cceddfe8a  pop r10
0000792cceddfe8c  pop r9
0000792cceddfe8e  pop r8
0000792cceddfe90  pop rsi
0000792cceddfe91  pop rdi
0000792cceddfe92  pop rdx
0000792cceddfe93  pop rcx
0000792cceddfe94  pop rax
0000792cceddfe95  add rsp, 0x08
0000792cceddfe99  jmp 0x0000792CCEDDC520
0000792cceddfe9e  sub rsp, 0x08
0000792cceddfea2  push rax
0000792cceddfea3  push rcx
0000792cceddfea4  push rdx
0000792cceddfea5  push rdi
0000792cceddfea6  push rsi
0000792cceddfea7  push r8
0000792cceddfea9  push r9
0000792cceddfeab  push r10
0000792cceddfead  push r11
0000792cceddfeaf  sub rsp, 0xF0
0000792cceddfeb6  vmovaps [rsp], xmm0
0000792cceddfebb  vmovaps [rsp+0x10], xmm1
0000792cceddfec1  vmovaps [rsp+0x20], xmm2
0000792cceddfec7  vmovaps [rsp+0x30], xmm3
0000792cceddfecd  vmovaps [rsp+0x40], xmm4
0000792cceddfed3  vmovaps [rsp+0x50], xmm5
0000792cceddfed9  vmovaps [rsp+0x60], xmm6
0000792cceddfedf  vmovaps [rsp+0x70], xmm7
0000792cceddfee5  vmovaps [rsp+0x80], xmm8
0000792cceddfeee  vmovaps [rsp+0x90], xmm9
0000792cceddfef7  vmovaps [rsp+0xA0], xmm11
0000792cceddff00  vmovaps [rsp+0xB0], xmm12
0000792cceddff09  vmovaps [rsp+0xC0], xmm13
0000792cceddff12  vmovaps [rsp+0xD0], xmm14
0000792cceddff1b  vmovaps [rsp+0xE0], xmm15
0000792cceddff24  sub rsp, 0x30
0000792cceddff28  movaps [rsp], xmm10
0000792cceddff2d  movaps [rsp+0x10], xmm14
0000792cceddff33  movaps [rsp+0x20], xmm4
0000792cceddff38  lea rdi, [rsp]
0000792cceddff3c  mov esi, 0x00
0000792cceddff41  mov rax, 0x5AEE2D541530
0000792cceddff4b  call rax
0000792cceddff4d  movaps xmm10, [rsp]
0000792cceddff52  add rsp, 0x30
0000792cceddff56  vmovaps xmm0, [rsp]
0000792cceddff5b  vmovaps xmm1, [rsp+0x10]
0000792cceddff61  vmovaps xmm2, [rsp+0x20]
0000792cceddff67  vmovaps xmm3, [rsp+0x30]
0000792cceddff6d  vmovaps xmm4, [rsp+0x40]
0000792cceddff73  vmovaps xmm5, [rsp+0x50]
0000792cceddff79  vmovaps xmm6, [rsp+0x60]
0000792cceddff7f  vmovaps xmm7, [rsp+0x70]
0000792cceddff85  vmovaps xmm8, [rsp+0x80]
0000792cceddff8e  vmovaps xmm9, [rsp+0x90]
0000792cceddff97  vmovaps xmm11, [rsp+0xA0]
0000792cceddffa0  vmovaps xmm12, [rsp+0xB0]
0000792cceddffa9  vmovaps xmm13, [rsp+0xC0]
0000792cceddffb2  vmovaps xmm14, [rsp+0xD0]
0000792cceddffbb  vmovaps xmm15, [rsp+0xE0]
0000792cceddffc4  add rsp, 0xF0
0000792cceddffcb  pop r11
0000792cceddffcd  pop r10
0000792cceddffcf  pop r9
0000792cceddffd1  pop r8
0000792cceddffd3  pop rsi
0000792cceddffd4  pop rdi
0000792cceddffd5  pop rdx
0000792cceddffd6  pop rcx
0000792cceddffd7  pop rax
0000792cceddffd8  add rsp, 0x08
0000792cceddffdc  jmp 0x0000792CCEDDC53B
0000792cceddffe1  sub rsp, 0x08
0000792cceddffe5  push rax
0000792cceddffe6  push rcx
0000792cceddffe7  push rdx
0000792cceddffe8  push rdi
0000792cceddffe9  push rsi
0000792cceddffea  push r8
0000792cceddffec  push r9
0000792cceddffee  push r10
0000792cceddfff0  push r11
0000792cceddfff2  sub rsp, 0xF0
0000792cceddfff9  vmovaps [rsp], xmm0
0000792cceddfffe  vmovaps [rsp+0x10], xmm1
0000792ccede0004  vmovaps [rsp+0x20], xmm2
0000792ccede000a  vmovaps [rsp+0x30], xmm3
0000792ccede0010  vmovaps [rsp+0x40], xmm4
0000792ccede0016  vmovaps [rsp+0x50], xmm5
0000792ccede001c  vmovaps [rsp+0x60], xmm6
0000792ccede0022  vmovaps [rsp+0x70], xmm7
0000792ccede0028  vmovaps [rsp+0x80], xmm9
0000792ccede0031  vmovaps [rsp+0x90], xmm10
0000792ccede003a  vmovaps [rsp+0xA0], xmm11
0000792ccede0043  vmovaps [rsp+0xB0], xmm12
0000792ccede004c  vmovaps [rsp+0xC0], xmm13
0000792ccede0055  vmovaps [rsp+0xD0], xmm14
0000792ccede005e  vmovaps [rsp+0xE0], xmm15
0000792ccede0067  sub rsp, 0x30
0000792ccede006b  movaps [rsp], xmm8
0000792ccede0070  movaps [rsp+0x10], xmm1
0000792ccede0075  movaps [rsp+0x20], xmm14
0000792ccede007b  lea rdi, [rsp]
0000792ccede007f  mov esi, 0x00
0000792ccede0084  mov rax, 0x5AEE2D541530
0000792ccede008e  call rax
0000792ccede0090  movaps xmm8, [rsp]
0000792ccede0095  add rsp, 0x30
0000792ccede0099  vmovaps xmm0, [rsp]
0000792ccede009e  vmovaps xmm1, [rsp+0x10]
0000792ccede00a4  vmovaps xmm2, [rsp+0x20]
0000792ccede00aa  vmovaps xmm3, [rsp+0x30]
0000792ccede00b0  vmovaps xmm4, [rsp+0x40]
0000792ccede00b6  vmovaps xmm5, [rsp+0x50]
0000792ccede00bc  vmovaps xmm6, [rsp+0x60]
0000792ccede00c2  vmovaps xmm7, [rsp+0x70]
0000792ccede00c8  vmovaps xmm9, [rsp+0x80]
0000792ccede00d1  vmovaps xmm10, [rsp+0x90]
0000792ccede00da  vmovaps xmm11, [rsp+0xA0]
0000792ccede00e3  vmovaps xmm12, [rsp+0xB0]
0000792ccede00ec  vmovaps xmm13, [rsp+0xC0]
0000792ccede00f5  vmovaps xmm14, [rsp+0xD0]
0000792ccede00fe  vmovaps xmm15, [rsp+0xE0]
0000792ccede0107  add rsp, 0xF0
0000792ccede010e  pop r11
0000792ccede0110  pop r10
0000792ccede0112  pop r9
0000792ccede0114  pop r8
0000792ccede0116  pop rsi
0000792ccede0117  pop rdi
0000792ccede0118  pop rdx
0000792ccede0119  pop rcx
0000792ccede011a  pop rax
0000792ccede011b  add rsp, 0x08
0000792ccede011f  jmp 0x0000792CCEDDC561
0000792ccede0124  sub rsp, 0x08
0000792ccede0128  push rax
0000792ccede0129  push rcx
0000792ccede012a  push rdx
0000792ccede012b  push rdi
0000792ccede012c  push rsi
0000792ccede012d  push r8
0000792ccede012f  push r9
0000792ccede0131  push r10
0000792ccede0133  push r11
0000792ccede0135  sub rsp, 0xF0
0000792ccede013c  vmovaps [rsp], xmm0
0000792ccede0141  vmovaps [rsp+0x10], xmm1
0000792ccede0147  vmovaps [rsp+0x20], xmm2
0000792ccede014d  vmovaps [rsp+0x30], xmm3
0000792ccede0153  vmovaps [rsp+0x40], xmm4
0000792ccede0159  vmovaps [rsp+0x50], xmm5
0000792ccede015f  vmovaps [rsp+0x60], xmm7
0000792ccede0165  vmovaps [rsp+0x70], xmm8
0000792ccede016b  vmovaps [rsp+0x80], xmm9
0000792ccede0174  vmovaps [rsp+0x90], xmm10
0000792ccede017d  vmovaps [rsp+0xA0], xmm11
0000792ccede0186  vmovaps [rsp+0xB0], xmm12
0000792ccede018f  vmovaps [rsp+0xC0], xmm13
0000792ccede0198  vmovaps [rsp+0xD0], xmm14
0000792ccede01a1  vmovaps [rsp+0xE0], xmm15
0000792ccede01aa  sub rsp, 0x30
0000792ccede01ae  movaps [rsp], xmm6
0000792ccede01b2  movaps [rsp+0x10], xmm1
0000792ccede01b7  movaps [rsp+0x20], xmm14
0000792ccede01bd  lea rdi, [rsp]
0000792ccede01c1  mov esi, 0x00
0000792ccede01c6  mov rax, 0x5AEE2D541530
0000792ccede01d0  call rax
0000792ccede01d2  movaps xmm6, [rsp]
0000792ccede01d6  add rsp, 0x30
0000792ccede01da  vmovaps xmm0, [rsp]
0000792ccede01df  vmovaps xmm1, [rsp+0x10]
0000792ccede01e5  vmovaps xmm2, [rsp+0x20]
0000792ccede01eb  vmovaps xmm3, [rsp+0x30]
0000792ccede01f1  vmovaps xmm4, [rsp+0x40]
0000792ccede01f7  vmovaps xmm5, [rsp+0x50]
0000792ccede01fd  vmovaps xmm7, [rsp+0x60]
0000792ccede0203  vmovaps xmm8, [rsp+0x70]
0000792ccede0209  vmovaps xmm9, [rsp+0x80]
0000792ccede0212  vmovaps xmm10, [rsp+0x90]
0000792ccede021b  vmovaps xmm11, [rsp+0xA0]
0000792ccede0224  vmovaps xmm12, [rsp+0xB0]
0000792ccede022d  vmovaps xmm13, [rsp+0xC0]
0000792ccede0236  vmovaps xmm14, [rsp+0xD0]
0000792ccede023f  vmovaps xmm15, [rsp+0xE0]
0000792ccede0248  add rsp, 0xF0
0000792ccede024f  pop r11
0000792ccede0251  pop r10
0000792ccede0253  pop r9
0000792ccede0255  pop r8
0000792ccede0257  pop rsi
0000792ccede0258  pop rdi
0000792ccede0259  pop rdx
0000792ccede025a  pop rcx
0000792ccede025b  pop rax
0000792ccede025c  add rsp, 0x08
0000792ccede0260  jmp 0x0000792CCEDDC58D
0000792ccede0265  sub rsp, 0x08
0000792ccede0269  push rax
0000792ccede026a  push rcx
0000792ccede026b  push rdx
0000792ccede026c  push rdi
0000792ccede026d  push rsi
0000792ccede026e  push r8
0000792ccede0270  push r9
0000792ccede0272  push r10
0000792ccede0274  push r11
0000792ccede0276  sub rsp, 0xF0
0000792ccede027d  vmovaps [rsp], xmm0
0000792ccede0282  vmovaps [rsp+0x10], xmm1
0000792ccede0288  vmovaps [rsp+0x20], xmm2
0000792ccede028e  vmovaps [rsp+0x30], xmm3
0000792ccede0294  vmovaps [rsp+0x40], xmm4
0000792ccede029a  vmovaps [rsp+0x50], xmm5
0000792ccede02a0  vmovaps [rsp+0x60], xmm6
0000792ccede02a6  vmovaps [rsp+0x70], xmm7
0000792ccede02ac  vmovaps [rsp+0x80], xmm8
0000792ccede02b5  vmovaps [rsp+0x90], xmm9
0000792ccede02be  vmovaps [rsp+0xA0], xmm10
0000792ccede02c7  vmovaps [rsp+0xB0], xmm11
0000792ccede02d0  vmovaps [rsp+0xC0], xmm12
0000792ccede02d9  vmovaps [rsp+0xD0], xmm13
0000792ccede02e2  vmovaps [rsp+0xE0], xmm15
0000792ccede02eb  sub rsp, 0x30
0000792ccede02ef  movaps [rsp], xmm14
0000792ccede02f4  movaps [rsp+0x10], xmm12
0000792ccede02fa  movaps [rsp+0x20], xmm1
0000792ccede02ff  lea rdi, [rsp]
0000792ccede0303  mov esi, 0x00
0000792ccede0308  mov rax, 0x5AEE2D541530
0000792ccede0312  call rax
0000792ccede0314  movaps xmm14, [rsp]
0000792ccede0319  add rsp, 0x30
0000792ccede031d  vmovaps xmm0, [rsp]
0000792ccede0322  vmovaps xmm1, [rsp+0x10]
0000792ccede0328  vmovaps xmm2, [rsp+0x20]
0000792ccede032e  vmovaps xmm3, [rsp+0x30]
0000792ccede0334  vmovaps xmm4, [rsp+0x40]
0000792ccede033a  vmovaps xmm5, [rsp+0x50]
0000792ccede0340  vmovaps xmm6, [rsp+0x60]
0000792ccede0346  vmovaps xmm7, [rsp+0x70]
0000792ccede034c  vmovaps xmm8, [rsp+0x80]
0000792ccede0355  vmovaps xmm9, [rsp+0x90]
0000792ccede035e  vmovaps xmm10, [rsp+0xA0]
0000792ccede0367  vmovaps xmm11, [rsp+0xB0]
0000792ccede0370  vmovaps xmm12, [rsp+0xC0]
0000792ccede0379  vmovaps xmm13, [rsp+0xD0]
0000792ccede0382  vmovaps xmm15, [rsp+0xE0]
0000792ccede038b  add rsp, 0xF0
0000792ccede0392  pop r11
0000792ccede0394  pop r10
0000792ccede0396  pop r9
0000792ccede0398  pop r8
0000792ccede039a  pop rsi
0000792ccede039b  pop rdi
0000792ccede039c  pop rdx
0000792ccede039d  pop rcx
0000792ccede039e  pop rax
0000792ccede039f  add rsp, 0x08
0000792ccede03a3  jmp 0x0000792CCEDDC5B3
0000792ccede03a8  sub rsp, 0x08
0000792ccede03ac  push rax
0000792ccede03ad  push rcx
0000792ccede03ae  push rdx
0000792ccede03af  push rdi
0000792ccede03b0  push rsi
0000792ccede03b1  push r8
0000792ccede03b3  push r9
0000792ccede03b5  push r10
0000792ccede03b7  push r11
0000792ccede03b9  sub rsp, 0xF0
0000792ccede03c0  vmovaps [rsp], xmm0
0000792ccede03c5  vmovaps [rsp+0x10], xmm2
0000792ccede03cb  vmovaps [rsp+0x20], xmm3
0000792ccede03d1  vmovaps [rsp+0x30], xmm4
0000792ccede03d7  vmovaps [rsp+0x40], xmm5
0000792ccede03dd  vmovaps [rsp+0x50], xmm6
0000792ccede03e3  vmovaps [rsp+0x60], xmm7
0000792ccede03e9  vmovaps [rsp+0x70], xmm8
0000792ccede03ef  vmovaps [rsp+0x80], xmm9
0000792ccede03f8  vmovaps [rsp+0x90], xmm10
0000792ccede0401  vmovaps [rsp+0xA0], xmm11
0000792ccede040a  vmovaps [rsp+0xB0], xmm12
0000792ccede0413  vmovaps [rsp+0xC0], xmm13
0000792ccede041c  vmovaps [rsp+0xD0], xmm14
0000792ccede0425  vmovaps [rsp+0xE0], xmm15
0000792ccede042e  sub rsp, 0x30
0000792ccede0432  movaps [rsp], xmm1
0000792ccede0436  movaps [rsp+0x10], xmm13
0000792ccede043c  movaps [rsp+0x20], xmm9
0000792ccede0442  lea rdi, [rsp]
0000792ccede0446  mov esi, 0x00
0000792ccede044b  mov rax, 0x5AEE2D541530
0000792ccede0455  call rax
0000792ccede0457  movaps xmm1, [rsp]
0000792ccede045b  add rsp, 0x30
0000792ccede045f  vmovaps xmm0, [rsp]
0000792ccede0464  vmovaps xmm2, [rsp+0x10]
0000792ccede046a  vmovaps xmm3, [rsp+0x20]
0000792ccede0470  vmovaps xmm4, [rsp+0x30]
0000792ccede0476  vmovaps xmm5, [rsp+0x40]
0000792ccede047c  vmovaps xmm6, [rsp+0x50]
0000792ccede0482  vmovaps xmm7, [rsp+0x60]
0000792ccede0488  vmovaps xmm8, [rsp+0x70]
0000792ccede048e  vmovaps xmm9, [rsp+0x80]
0000792ccede0497  vmovaps xmm10, [rsp+0x90]
0000792ccede04a0  vmovaps xmm11, [rsp+0xA0]
0000792ccede04a9  vmovaps xmm12, [rsp+0xB0]
0000792ccede04b2  vmovaps xmm13, [rsp+0xC0]
0000792ccede04bb  vmovaps xmm14, [rsp+0xD0]
0000792ccede04c4  vmovaps xmm15, [rsp+0xE0]
0000792ccede04cd  add rsp, 0xF0
0000792ccede04d4  pop r11
0000792ccede04d6  pop r10
0000792ccede04d8  pop r9
0000792ccede04da  pop r8
0000792ccede04dc  pop rsi
0000792ccede04dd  pop rdi
0000792ccede04de  pop rdx
0000792ccede04df  pop rcx
0000792ccede04e0  pop rax
0000792ccede04e1  add rsp, 0x08
0000792ccede04e5  jmp 0x0000792CCEDDC5CD
0000792ccede04ea  sub rsp, 0x08
0000792ccede04ee  push rax
0000792ccede04ef  push rcx
0000792ccede04f0  push rdx
0000792ccede04f1  push rdi
0000792ccede04f2  push rsi
0000792ccede04f3  push r8
0000792ccede04f5  push r9
0000792ccede04f7  push r10
0000792ccede04f9  push r11
0000792ccede04fb  sub rsp, 0xF0
0000792ccede0502  vmovaps [rsp], xmm0
0000792ccede0507  vmovaps [rsp+0x10], xmm1
0000792ccede050d  vmovaps [rsp+0x20], xmm2
0000792ccede0513  vmovaps [rsp+0x30], xmm3
0000792ccede0519  vmovaps [rsp+0x40], xmm4
0000792ccede051f  vmovaps [rsp+0x50], xmm5
0000792ccede0525  vmovaps [rsp+0x60], xmm6
0000792ccede052b  vmovaps [rsp+0x70], xmm7
0000792ccede0531  vmovaps [rsp+0x80], xmm8
0000792ccede053a  vmovaps [rsp+0x90], xmm9
0000792ccede0543  vmovaps [rsp+0xA0], xmm10
0000792ccede054c  vmovaps [rsp+0xB0], xmm11
0000792ccede0555  vmovaps [rsp+0xC0], xmm13
0000792ccede055e  vmovaps [rsp+0xD0], xmm14
0000792ccede0567  vmovaps [rsp+0xE0], xmm15
0000792ccede0570  sub rsp, 0x30
0000792ccede0574  movaps [rsp], xmm12
0000792ccede0579  movaps [rsp+0x10], xmm7
0000792ccede057e  movaps [rsp+0x20], xmm13
0000792ccede0584  lea rdi, [rsp]
0000792ccede0588  mov esi, 0x00
0000792ccede058d  mov rax, 0x5AEE2D541530
0000792ccede0597  call rax
0000792ccede0599  movaps xmm12, [rsp]
0000792ccede059e  add rsp, 0x30
0000792ccede05a2  vmovaps xmm0, [rsp]
0000792ccede05a7  vmovaps xmm1, [rsp+0x10]
0000792ccede05ad  vmovaps xmm2, [rsp+0x20]
0000792ccede05b3  vmovaps xmm3, [rsp+0x30]
0000792ccede05b9  vmovaps xmm4, [rsp+0x40]
0000792ccede05bf  vmovaps xmm5, [rsp+0x50]
0000792ccede05c5  vmovaps xmm6, [rsp+0x60]
0000792ccede05cb  vmovaps xmm7, [rsp+0x70]
0000792ccede05d1  vmovaps xmm8, [rsp+0x80]
0000792ccede05da  vmovaps xmm9, [rsp+0x90]
0000792ccede05e3  vmovaps xmm10, [rsp+0xA0]
0000792ccede05ec  vmovaps xmm11, [rsp+0xB0]
0000792ccede05f5  vmovaps xmm13, [rsp+0xC0]
0000792ccede05fe  vmovaps xmm14, [rsp+0xD0]
0000792ccede0607  vmovaps xmm15, [rsp+0xE0]
0000792ccede0610  add rsp, 0xF0
0000792ccede0617  pop r11
0000792ccede0619  pop r10
0000792ccede061b  pop r9
0000792ccede061d  pop r8
0000792ccede061f  pop rsi
0000792ccede0620  pop rdi
0000792ccede0621  pop rdx
0000792ccede0622  pop rcx
0000792ccede0623  pop rax
0000792ccede0624  add rsp, 0x08
0000792ccede0628  jmp 0x0000792CCEDDC5F4
0000792ccede062d  sub rsp, 0x08
0000792ccede0631  push rax
0000792ccede0632  push rcx
0000792ccede0633  push rdx
0000792ccede0634  push rdi
0000792ccede0635  push rsi
0000792ccede0636  push r8
0000792ccede0638  push r9
0000792ccede063a  push r10
0000792ccede063c  push r11
0000792ccede063e  sub rsp, 0xF0
0000792ccede0645  vmovaps [rsp], xmm0
0000792ccede064a  vmovaps [rsp+0x10], xmm1
0000792ccede0650  vmovaps [rsp+0x20], xmm2
0000792ccede0656  vmovaps [rsp+0x30], xmm3
0000792ccede065c  vmovaps [rsp+0x40], xmm4
0000792ccede0662  vmovaps [rsp+0x50], xmm5
0000792ccede0668  vmovaps [rsp+0x60], xmm6
0000792ccede066e  vmovaps [rsp+0x70], xmm7
0000792ccede0674  vmovaps [rsp+0x80], xmm8
0000792ccede067d  vmovaps [rsp+0x90], xmm9
0000792ccede0686  vmovaps [rsp+0xA0], xmm10
0000792ccede068f  vmovaps [rsp+0xB0], xmm11
0000792ccede0698  vmovaps [rsp+0xC0], xmm12
0000792ccede06a1  vmovaps [rsp+0xD0], xmm14
0000792ccede06aa  vmovaps [rsp+0xE0], xmm15
0000792ccede06b3  sub rsp, 0x30
0000792ccede06b7  movaps [rsp], xmm13
0000792ccede06bc  movaps [rsp+0x10], xmm15
0000792ccede06c2  movaps [rsp+0x20], xmm8
0000792ccede06c8  lea rdi, [rsp]
0000792ccede06cc  mov esi, 0x00
0000792ccede06d1  mov rax, 0x5AEE2D541530
0000792ccede06db  call rax
0000792ccede06dd  movaps xmm13, [rsp]
0000792ccede06e2  add rsp, 0x30
0000792ccede06e6  vmovaps xmm0, [rsp]
0000792ccede06eb  vmovaps xmm1, [rsp+0x10]
0000792ccede06f1  vmovaps xmm2, [rsp+0x20]
0000792ccede06f7  vmovaps xmm3, [rsp+0x30]
0000792ccede06fd  vmovaps xmm4, [rsp+0x40]
0000792ccede0703  vmovaps xmm5, [rsp+0x50]
0000792ccede0709  vmovaps xmm6, [rsp+0x60]
0000792ccede070f  vmovaps xmm7, [rsp+0x70]
0000792ccede0715  vmovaps xmm8, [rsp+0x80]
0000792ccede071e  vmovaps xmm9, [rsp+0x90]
0000792ccede0727  vmovaps xmm10, [rsp+0xA0]
0000792ccede0730  vmovaps xmm11, [rsp+0xB0]
0000792ccede0739  vmovaps xmm12, [rsp+0xC0]
0000792ccede0742  vmovaps xmm14, [rsp+0xD0]
0000792ccede074b  vmovaps xmm15, [rsp+0xE0]
0000792ccede0754  add rsp, 0xF0
0000792ccede075b  pop r11
0000792ccede075d  pop r10
0000792ccede075f  pop r9
0000792ccede0761  pop r8
0000792ccede0763  pop rsi
0000792ccede0764  pop rdi
0000792ccede0765  pop rdx
0000792ccede0766  pop rcx
0000792ccede0767  pop rax
0000792ccede0768  add rsp, 0x08
0000792ccede076c  jmp 0x0000792CCEDDC60F
0000792ccede0771  sub rsp, 0x08
0000792ccede0775  push rax
0000792ccede0776  push rcx
0000792ccede0777  push rdx
0000792ccede0778  push rdi
0000792ccede0779  push rsi
0000792ccede077a  push r8
0000792ccede077c  push r9
0000792ccede077e  push r10
0000792ccede0780  push r11
0000792ccede0782  sub rsp, 0xF0
0000792ccede0789  vmovaps [rsp], xmm0
0000792ccede078e  vmovaps [rsp+0x10], xmm1
0000792ccede0794  vmovaps [rsp+0x20], xmm2
0000792ccede079a  vmovaps [rsp+0x30], xmm3
0000792ccede07a0  vmovaps [rsp+0x40], xmm4
0000792ccede07a6  vmovaps [rsp+0x50], xmm5
0000792ccede07ac  vmovaps [rsp+0x60], xmm6
0000792ccede07b2  vmovaps [rsp+0x70], xmm7
0000792ccede07b8  vmovaps [rsp+0x80], xmm9
0000792ccede07c1  vmovaps [rsp+0x90], xmm10
0000792ccede07ca  vmovaps [rsp+0xA0], xmm11
0000792ccede07d3  vmovaps [rsp+0xB0], xmm12
0000792ccede07dc  vmovaps [rsp+0xC0], xmm13
0000792ccede07e5  vmovaps [rsp+0xD0], xmm14
0000792ccede07ee  vmovaps [rsp+0xE0], xmm15
0000792ccede07f7  sub rsp, 0x30
0000792ccede07fb  movaps [rsp], xmm8
0000792ccede0800  movaps [rsp+0x10], xmm15
0000792ccede0806  movaps [rsp+0x20], xmm9
0000792ccede080c  lea rdi, [rsp]
0000792ccede0810  mov esi, 0x00
0000792ccede0815  mov rax, 0x5AEE2D541530
0000792ccede081f  call rax
0000792ccede0821  movaps xmm8, [rsp]
0000792ccede0826  add rsp, 0x30
0000792ccede082a  vmovaps xmm0, [rsp]
0000792ccede082f  vmovaps xmm1, [rsp+0x10]
0000792ccede0835  vmovaps xmm2, [rsp+0x20]
0000792ccede083b  vmovaps xmm3, [rsp+0x30]
0000792ccede0841  vmovaps xmm4, [rsp+0x40]
0000792ccede0847  vmovaps xmm5, [rsp+0x50]
0000792ccede084d  vmovaps xmm6, [rsp+0x60]
0000792ccede0853  vmovaps xmm7, [rsp+0x70]
0000792ccede0859  vmovaps xmm9, [rsp+0x80]
0000792ccede0862  vmovaps xmm10, [rsp+0x90]
0000792ccede086b  vmovaps xmm11, [rsp+0xA0]
0000792ccede0874  vmovaps xmm12, [rsp+0xB0]
0000792ccede087d  vmovaps xmm13, [rsp+0xC0]
0000792ccede0886  vmovaps xmm14, [rsp+0xD0]
0000792ccede088f  vmovaps xmm15, [rsp+0xE0]
0000792ccede0898  add rsp, 0xF0
0000792ccede089f  pop r11
0000792ccede08a1  pop r10
0000792ccede08a3  pop r9
0000792ccede08a5  pop r8
0000792ccede08a7  pop rsi
0000792ccede08a8  pop rdi
0000792ccede08a9  pop rdx
0000792ccede08aa  pop rcx
0000792ccede08ab  pop rax
0000792ccede08ac  add rsp, 0x08
0000792ccede08b0  jmp 0x0000792CCEDDC63D
0000792ccede08b5  sub rsp, 0x08
0000792ccede08b9  push rax
0000792ccede08ba  push rcx
0000792ccede08bb  push rdx
0000792ccede08bc  push rdi
0000792ccede08bd  push rsi
0000792ccede08be  push r8
0000792ccede08c0  push r9
0000792ccede08c2  push r10
0000792ccede08c4  push r11
0000792ccede08c6  sub rsp, 0xF0
0000792ccede08cd  vmovaps [rsp], xmm0
0000792ccede08d2  vmovaps [rsp+0x10], xmm1
0000792ccede08d8  vmovaps [rsp+0x20], xmm2
0000792ccede08de  vmovaps [rsp+0x30], xmm3
0000792ccede08e4  vmovaps [rsp+0x40], xmm4
0000792ccede08ea  vmovaps [rsp+0x50], xmm5
0000792ccede08f0  vmovaps [rsp+0x60], xmm6
0000792ccede08f6  vmovaps [rsp+0x70], xmm7
0000792ccede08fc  vmovaps [rsp+0x80], xmm8
0000792ccede0905  vmovaps [rsp+0x90], xmm9
0000792ccede090e  vmovaps [rsp+0xA0], xmm10
0000792ccede0917  vmovaps [rsp+0xB0], xmm11
0000792ccede0920  vmovaps [rsp+0xC0], xmm12
0000792ccede0929  vmovaps [rsp+0xD0], xmm13
0000792ccede0932  vmovaps [rsp+0xE0], xmm14
0000792ccede093b  sub rsp, 0x30
0000792ccede093f  movaps [rsp], xmm15
0000792ccede0944  movaps [rsp+0x10], xmm11
0000792ccede094a  movaps [rsp+0x20], xmm6
0000792ccede094f  lea rdi, [rsp]
0000792ccede0953  mov esi, 0x00
0000792ccede0958  mov rax, 0x5AEE2D541530
0000792ccede0962  call rax
0000792ccede0964  movaps xmm15, [rsp]
0000792ccede0969  add rsp, 0x30
0000792ccede096d  vmovaps xmm0, [rsp]
0000792ccede0972  vmovaps xmm1, [rsp+0x10]
0000792ccede0978  vmovaps xmm2, [rsp+0x20]
0000792ccede097e  vmovaps xmm3, [rsp+0x30]
0000792ccede0984  vmovaps xmm4, [rsp+0x40]
0000792ccede098a  vmovaps xmm5, [rsp+0x50]
0000792ccede0990  vmovaps xmm6, [rsp+0x60]
0000792ccede0996  vmovaps xmm7, [rsp+0x70]
0000792ccede099c  vmovaps xmm8, [rsp+0x80]
0000792ccede09a5  vmovaps xmm9, [rsp+0x90]
0000792ccede09ae  vmovaps xmm10, [rsp+0xA0]
0000792ccede09b7  vmovaps xmm11, [rsp+0xB0]
0000792ccede09c0  vmovaps xmm12, [rsp+0xC0]
0000792ccede09c9  vmovaps xmm13, [rsp+0xD0]
0000792ccede09d2  vmovaps xmm14, [rsp+0xE0]
0000792ccede09db  add rsp, 0xF0
0000792ccede09e2  pop r11
0000792ccede09e4  pop r10
0000792ccede09e6  pop r9
0000792ccede09e8  pop r8
0000792ccede09ea  pop rsi
0000792ccede09eb  pop rdi
0000792ccede09ec  pop rdx
0000792ccede09ed  pop rcx
0000792ccede09ee  pop rax
0000792ccede09ef  add rsp, 0x08
0000792ccede09f3  jmp 0x0000792CCEDDC658
0000792ccede09f8  sub rsp, 0x08
0000792ccede09fc  push rax
0000792ccede09fd  push rcx
0000792ccede09fe  push rdx
0000792ccede09ff  push rdi
0000792ccede0a00  push rsi
0000792ccede0a01  push r8
0000792ccede0a03  push r9
0000792ccede0a05  push r10
0000792ccede0a07  push r11
0000792ccede0a09  sub rsp, 0xF0
0000792ccede0a10  vmovaps [rsp], xmm0
0000792ccede0a15  vmovaps [rsp+0x10], xmm1
0000792ccede0a1b  vmovaps [rsp+0x20], xmm2
0000792ccede0a21  vmovaps [rsp+0x30], xmm3
0000792ccede0a27  vmovaps [rsp+0x40], xmm4
0000792ccede0a2d  vmovaps [rsp+0x50], xmm5
0000792ccede0a33  vmovaps [rsp+0x60], xmm6
0000792ccede0a39  vmovaps [rsp+0x70], xmm8
0000792ccede0a3f  vmovaps [rsp+0x80], xmm9
0000792ccede0a48  vmovaps [rsp+0x90], xmm10
0000792ccede0a51  vmovaps [rsp+0xA0], xmm11
0000792ccede0a5a  vmovaps [rsp+0xB0], xmm12
0000792ccede0a63  vmovaps [rsp+0xC0], xmm13
0000792ccede0a6c  vmovaps [rsp+0xD0], xmm14
0000792ccede0a75  vmovaps [rsp+0xE0], xmm15
0000792ccede0a7e  sub rsp, 0x30
0000792ccede0a82  movaps [rsp], xmm7
0000792ccede0a86  movaps [rsp+0x10], xmm11
0000792ccede0a8c  movaps [rsp+0x20], xmm9
0000792ccede0a92  lea rdi, [rsp]
0000792ccede0a96  mov esi, 0x00
0000792ccede0a9b  mov rax, 0x5AEE2D541530
0000792ccede0aa5  call rax
0000792ccede0aa7  movaps xmm7, [rsp]
0000792ccede0aab  add rsp, 0x30
0000792ccede0aaf  vmovaps xmm0, [rsp]
0000792ccede0ab4  vmovaps xmm1, [rsp+0x10]
0000792ccede0aba  vmovaps xmm2, [rsp+0x20]
0000792ccede0ac0  vmovaps xmm3, [rsp+0x30]
0000792ccede0ac6  vmovaps xmm4, [rsp+0x40]
0000792ccede0acc  vmovaps xmm5, [rsp+0x50]
0000792ccede0ad2  vmovaps xmm6, [rsp+0x60]
0000792ccede0ad8  vmovaps xmm8, [rsp+0x70]
0000792ccede0ade  vmovaps xmm9, [rsp+0x80]
0000792ccede0ae7  vmovaps xmm10, [rsp+0x90]
0000792ccede0af0  vmovaps xmm11, [rsp+0xA0]
0000792ccede0af9  vmovaps xmm12, [rsp+0xB0]
0000792ccede0b02  vmovaps xmm13, [rsp+0xC0]
0000792ccede0b0b  vmovaps xmm14, [rsp+0xD0]
0000792ccede0b14  vmovaps xmm15, [rsp+0xE0]
0000792ccede0b1d  add rsp, 0xF0
0000792ccede0b24  pop r11
0000792ccede0b26  pop r10
0000792ccede0b28  pop r9
0000792ccede0b2a  pop r8
0000792ccede0b2c  pop rsi
0000792ccede0b2d  pop rdi
0000792ccede0b2e  pop rdx
0000792ccede0b2f  pop rcx
0000792ccede0b30  pop rax
0000792ccede0b31  add rsp, 0x08
0000792ccede0b35  jmp 0x0000792CCEDDC685
0000792ccede0b3a  sub rsp, 0x08
0000792ccede0b3e  push rax
0000792ccede0b3f  push rcx
0000792ccede0b40  push rdx
0000792ccede0b41  push rdi
0000792ccede0b42  push rsi
0000792ccede0b43  push r8
0000792ccede0b45  push r9
0000792ccede0b47  push r10
0000792ccede0b49  push r11
0000792ccede0b4b  sub rsp, 0xF0
0000792ccede0b52  vmovaps [rsp], xmm0
0000792ccede0b57  vmovaps [rsp+0x10], xmm1
0000792ccede0b5d  vmovaps [rsp+0x20], xmm2
0000792ccede0b63  vmovaps [rsp+0x30], xmm3
0000792ccede0b69  vmovaps [rsp+0x40], xmm4
0000792ccede0b6f  vmovaps [rsp+0x50], xmm5
0000792ccede0b75  vmovaps [rsp+0x60], xmm6
0000792ccede0b7b  vmovaps [rsp+0x70], xmm7
0000792ccede0b81  vmovaps [rsp+0x80], xmm8
0000792ccede0b8a  vmovaps [rsp+0x90], xmm9
0000792ccede0b93  vmovaps [rsp+0xA0], xmm10
0000792ccede0b9c  vmovaps [rsp+0xB0], xmm12
0000792ccede0ba5  vmovaps [rsp+0xC0], xmm13
0000792ccede0bae  vmovaps [rsp+0xD0], xmm14
0000792ccede0bb7  vmovaps [rsp+0xE0], xmm15
0000792ccede0bc0  sub rsp, 0x30
0000792ccede0bc4  movaps [rsp], xmm11
0000792ccede0bc9  movaps [rsp+0x10], xmm10
0000792ccede0bcf  movaps [rsp+0x20], xmm14
0000792ccede0bd5  lea rdi, [rsp]
0000792ccede0bd9  mov esi, 0x00
0000792ccede0bde  mov rax, 0x5AEE2D541530
0000792ccede0be8  call rax
0000792ccede0bea  movaps xmm11, [rsp]
0000792ccede0bef  add rsp, 0x30
0000792ccede0bf3  vmovaps xmm0, [rsp]
0000792ccede0bf8  vmovaps xmm1, [rsp+0x10]
0000792ccede0bfe  vmovaps xmm2, [rsp+0x20]
0000792ccede0c04  vmovaps xmm3, [rsp+0x30]
0000792ccede0c0a  vmovaps xmm4, [rsp+0x40]
0000792ccede0c10  vmovaps xmm5, [rsp+0x50]
0000792ccede0c16  vmovaps xmm6, [rsp+0x60]
0000792ccede0c1c  vmovaps xmm7, [rsp+0x70]
0000792ccede0c22  vmovaps xmm8, [rsp+0x80]
0000792ccede0c2b  vmovaps xmm9, [rsp+0x90]
0000792ccede0c34  vmovaps xmm10, [rsp+0xA0]
0000792ccede0c3d  vmovaps xmm12, [rsp+0xB0]
0000792ccede0c46  vmovaps xmm13, [rsp+0xC0]
0000792ccede0c4f  vmovaps xmm14, [rsp+0xD0]
0000792ccede0c58  vmovaps xmm15, [rsp+0xE0]
0000792ccede0c61  add rsp, 0xF0
0000792ccede0c68  pop r11
0000792ccede0c6a  pop r10
0000792ccede0c6c  pop r9
0000792ccede0c6e  pop r8
0000792ccede0c70  pop rsi
0000792ccede0c71  pop rdi
0000792ccede0c72  pop rdx
0000792ccede0c73  pop rcx
0000792ccede0c74  pop rax
0000792ccede0c75  add rsp, 0x08
0000792ccede0c79  jmp 0x0000792CCEDDC6A0
0000792ccede0c7e  call 0x0000792CCECC33A0
0000792ccede0c83  jmp 0x0000792CCEDDC6AA
0000792ccede0c88  sub rsp, 0x08
0000792ccede0c8c  push rax
0000792ccede0c8d  push rcx
0000792ccede0c8e  push rdx
0000792ccede0c8f  push rdi
0000792ccede0c90  push rsi
0000792ccede0c91  push r8
0000792ccede0c93  push r9
0000792ccede0c95  push r10
0000792ccede0c97  push r11
0000792ccede0c99  sub rsp, 0xF0
0000792ccede0ca0  vmovaps [rsp], xmm0
0000792ccede0ca5  vmovaps [rsp+0x10], xmm1
0000792ccede0cab  vmovaps [rsp+0x20], xmm2
0000792ccede0cb1  vmovaps [rsp+0x30], xmm3
0000792ccede0cb7  vmovaps [rsp+0x40], xmm4
0000792ccede0cbd  vmovaps [rsp+0x50], xmm5
0000792ccede0cc3  vmovaps [rsp+0x60], xmm6
0000792ccede0cc9  vmovaps [rsp+0x70], xmm7
0000792ccede0ccf  vmovaps [rsp+0x80], xmm8
0000792ccede0cd8  vmovaps [rsp+0x90], xmm9
0000792ccede0ce1  vmovaps [rsp+0xA0], xmm11
0000792ccede0cea  vmovaps [rsp+0xB0], xmm12
0000792ccede0cf3  vmovaps [rsp+0xC0], xmm13
0000792ccede0cfc  vmovaps [rsp+0xD0], xmm14
0000792ccede0d05  vmovaps [rsp+0xE0], xmm15
0000792ccede0d0e  sub rsp, 0x30
0000792ccede0d12  movaps [rsp], xmm10
0000792ccede0d17  movaps [rsp+0x10], xmm1
0000792ccede0d1c  movaps [rsp+0x20], xmm12
0000792ccede0d22  lea rdi, [rsp]
0000792ccede0d26  mov esi, 0x00
0000792ccede0d2b  mov rax, 0x5AEE2D541530
0000792ccede0d35  call rax
0000792ccede0d37  movaps xmm10, [rsp]
0000792ccede0d3c  add rsp, 0x30
0000792ccede0d40  vmovaps xmm0, [rsp]
0000792ccede0d45  vmovaps xmm1, [rsp+0x10]
0000792ccede0d4b  vmovaps xmm2, [rsp+0x20]
0000792ccede0d51  vmovaps xmm3, [rsp+0x30]
0000792ccede0d57  vmovaps xmm4, [rsp+0x40]
0000792ccede0d5d  vmovaps xmm5, [rsp+0x50]
0000792ccede0d63  vmovaps xmm6, [rsp+0x60]
0000792ccede0d69  vmovaps xmm7, [rsp+0x70]
0000792ccede0d6f  vmovaps xmm8, [rsp+0x80]
0000792ccede0d78  vmovaps xmm9, [rsp+0x90]
0000792ccede0d81  vmovaps xmm11, [rsp+0xA0]
0000792ccede0d8a  vmovaps xmm12, [rsp+0xB0]
0000792ccede0d93  vmovaps xmm13, [rsp+0xC0]
0000792ccede0d9c  vmovaps xmm14, [rsp+0xD0]
0000792ccede0da5  vmovaps xmm15, [rsp+0xE0]
0000792ccede0dae  add rsp, 0xF0
0000792ccede0db5  pop r11
0000792ccede0db7  pop r10
0000792ccede0db9  pop r9
0000792ccede0dbb  pop r8
0000792ccede0dbd  pop rsi
0000792ccede0dbe  pop rdi
0000792ccede0dbf  pop rdx
0000792ccede0dc0  pop rcx
0000792ccede0dc1  pop rax
0000792ccede0dc2  add rsp, 0x08
0000792ccede0dc6  jmp 0x0000792CCEDDC6CD
0000792ccede0dcb  sub rsp, 0x08
0000792ccede0dcf  push rax
0000792ccede0dd0  push rcx
0000792ccede0dd1  push rdx
0000792ccede0dd2  push rdi
0000792ccede0dd3  push rsi
0000792ccede0dd4  push r8
0000792ccede0dd6  push r9
0000792ccede0dd8  push r10
0000792ccede0dda  push r11
0000792ccede0ddc  sub rsp, 0xF0
0000792ccede0de3  vmovaps [rsp], xmm0
0000792ccede0de8  vmovaps [rsp+0x10], xmm1
0000792ccede0dee  vmovaps [rsp+0x20], xmm2
0000792ccede0df4  vmovaps [rsp+0x30], xmm3
0000792ccede0dfa  vmovaps [rsp+0x40], xmm4
0000792ccede0e00  vmovaps [rsp+0x50], xmm5
0000792ccede0e06  vmovaps [rsp+0x60], xmm6
0000792ccede0e0c  vmovaps [rsp+0x70], xmm7
0000792ccede0e12  vmovaps [rsp+0x80], xmm8
0000792ccede0e1b  vmovaps [rsp+0x90], xmm9
0000792ccede0e24  vmovaps [rsp+0xA0], xmm10
0000792ccede0e2d  vmovaps [rsp+0xB0], xmm11
0000792ccede0e36  vmovaps [rsp+0xC0], xmm13
0000792ccede0e3f  vmovaps [rsp+0xD0], xmm14
0000792ccede0e48  vmovaps [rsp+0xE0], xmm15
0000792ccede0e51  sub rsp, 0x30
0000792ccede0e55  movaps [rsp], xmm12
0000792ccede0e5a  movaps [rsp+0x10], xmm14
0000792ccede0e60  movaps [rsp+0x20], xmm1
0000792ccede0e65  lea rdi, [rsp]
0000792ccede0e69  mov esi, 0x00
0000792ccede0e6e  mov rax, 0x5AEE2D541530
0000792ccede0e78  call rax
0000792ccede0e7a  movaps xmm12, [rsp]
0000792ccede0e7f  add rsp, 0x30
0000792ccede0e83  vmovaps xmm0, [rsp]
0000792ccede0e88  vmovaps xmm1, [rsp+0x10]
0000792ccede0e8e  vmovaps xmm2, [rsp+0x20]
0000792ccede0e94  vmovaps xmm3, [rsp+0x30]
0000792ccede0e9a  vmovaps xmm4, [rsp+0x40]
0000792ccede0ea0  vmovaps xmm5, [rsp+0x50]
0000792ccede0ea6  vmovaps xmm6, [rsp+0x60]
0000792ccede0eac  vmovaps xmm7, [rsp+0x70]
0000792ccede0eb2  vmovaps xmm8, [rsp+0x80]
0000792ccede0ebb  vmovaps xmm9, [rsp+0x90]
0000792ccede0ec4  vmovaps xmm10, [rsp+0xA0]
0000792ccede0ecd  vmovaps xmm11, [rsp+0xB0]
0000792ccede0ed6  vmovaps xmm13, [rsp+0xC0]
0000792ccede0edf  vmovaps xmm14, [rsp+0xD0]
0000792ccede0ee8  vmovaps xmm15, [rsp+0xE0]
0000792ccede0ef1  add rsp, 0xF0
0000792ccede0ef8  pop r11
0000792ccede0efa  pop r10
0000792ccede0efc  pop r9
0000792ccede0efe  pop r8
0000792ccede0f00  pop rsi
0000792ccede0f01  pop rdi
0000792ccede0f02  pop rdx
0000792ccede0f03  pop rcx
0000792ccede0f04  pop rax
0000792ccede0f05  add rsp, 0x08
0000792ccede0f09  jmp 0x0000792CCEDDC6FC
0000792ccede0f0e  sub rsp, 0x08
0000792ccede0f12  push rax
0000792ccede0f13  push rcx
0000792ccede0f14  push rdx
0000792ccede0f15  push rdi
0000792ccede0f16  push rsi
0000792ccede0f17  push r8
0000792ccede0f19  push r9
0000792ccede0f1b  push r10
0000792ccede0f1d  push r11
0000792ccede0f1f  sub rsp, 0xF0
0000792ccede0f26  vmovaps [rsp], xmm0
0000792ccede0f2b  vmovaps [rsp+0x10], xmm1
0000792ccede0f31  vmovaps [rsp+0x20], xmm2
0000792ccede0f37  vmovaps [rsp+0x30], xmm3
0000792ccede0f3d  vmovaps [rsp+0x40], xmm4
0000792ccede0f43  vmovaps [rsp+0x50], xmm5
0000792ccede0f49  vmovaps [rsp+0x60], xmm6
0000792ccede0f4f  vmovaps [rsp+0x70], xmm7
0000792ccede0f55  vmovaps [rsp+0x80], xmm8
0000792ccede0f5e  vmovaps [rsp+0x90], xmm9
0000792ccede0f67  vmovaps [rsp+0xA0], xmm10
0000792ccede0f70  vmovaps [rsp+0xB0], xmm11
0000792ccede0f79  vmovaps [rsp+0xC0], xmm12
0000792ccede0f82  vmovaps [rsp+0xD0], xmm13
0000792ccede0f8b  vmovaps [rsp+0xE0], xmm15
0000792ccede0f94  sub rsp, 0x30
0000792ccede0f98  movaps [rsp], xmm14
0000792ccede0f9d  movaps [rsp+0x10], xmm9
0000792ccede0fa3  movaps [rsp+0x20], xmm1
0000792ccede0fa8  lea rdi, [rsp]
0000792ccede0fac  mov esi, 0x00
0000792ccede0fb1  mov rax, 0x5AEE2D541530
0000792ccede0fbb  call rax
0000792ccede0fbd  movaps xmm14, [rsp]
0000792ccede0fc2  add rsp, 0x30
0000792ccede0fc6  vmovaps xmm0, [rsp]
0000792ccede0fcb  vmovaps xmm1, [rsp+0x10]
0000792ccede0fd1  vmovaps xmm2, [rsp+0x20]
0000792ccede0fd7  vmovaps xmm3, [rsp+0x30]
0000792ccede0fdd  vmovaps xmm4, [rsp+0x40]
0000792ccede0fe3  vmovaps xmm5, [rsp+0x50]
0000792ccede0fe9  vmovaps xmm6, [rsp+0x60]
0000792ccede0fef  vmovaps xmm7, [rsp+0x70]
0000792ccede0ff5  vmovaps xmm8, [rsp+0x80]
0000792ccede0ffe  vmovaps xmm9, [rsp+0x90]
0000792ccede1007  vmovaps xmm10, [rsp+0xA0]
0000792ccede1010  vmovaps xmm11, [rsp+0xB0]
0000792ccede1019  vmovaps xmm12, [rsp+0xC0]
0000792ccede1022  vmovaps xmm13, [rsp+0xD0]
0000792ccede102b  vmovaps xmm15, [rsp+0xE0]
0000792ccede1034  add rsp, 0xF0
0000792ccede103b  pop r11
0000792ccede103d  pop r10
0000792ccede103f  pop r9
0000792ccede1041  pop r8
0000792ccede1043  pop rsi
0000792ccede1044  pop rdi
0000792ccede1045  pop rdx
0000792ccede1046  pop rcx
0000792ccede1047  pop rax
0000792ccede1048  add rsp, 0x08
0000792ccede104c  jmp 0x0000792CCEDDC72B
0000792ccede1051  sub rsp, 0x08
0000792ccede1055  push rax
0000792ccede1056  push rcx
0000792ccede1057  push rdx
0000792ccede1058  push rdi
0000792ccede1059  push rsi
0000792ccede105a  push r8
0000792ccede105c  push r9
0000792ccede105e  push r10
0000792ccede1060  push r11
0000792ccede1062  sub rsp, 0xF0
0000792ccede1069  vmovaps [rsp], xmm0
0000792ccede106e  vmovaps [rsp+0x10], xmm2
0000792ccede1074  vmovaps [rsp+0x20], xmm3
0000792ccede107a  vmovaps [rsp+0x30], xmm4
0000792ccede1080  vmovaps [rsp+0x40], xmm5
0000792ccede1086  vmovaps [rsp+0x50], xmm6
0000792ccede108c  vmovaps [rsp+0x60], xmm7
0000792ccede1092  vmovaps [rsp+0x70], xmm8
0000792ccede1098  vmovaps [rsp+0x80], xmm9
0000792ccede10a1  vmovaps [rsp+0x90], xmm10
0000792ccede10aa  vmovaps [rsp+0xA0], xmm11
0000792ccede10b3  vmovaps [rsp+0xB0], xmm12
0000792ccede10bc  vmovaps [rsp+0xC0], xmm13
0000792ccede10c5  vmovaps [rsp+0xD0], xmm14
0000792ccede10ce  vmovaps [rsp+0xE0], xmm15
0000792ccede10d7  sub rsp, 0x30
0000792ccede10db  movaps [rsp], xmm1
0000792ccede10df  movaps [rsp+0x10], xmm13
0000792ccede10e5  movaps [rsp+0x20], xmm8
0000792ccede10eb  lea rdi, [rsp]
0000792ccede10ef  mov esi, 0x00
0000792ccede10f4  mov rax, 0x5AEE2D541530
0000792ccede10fe  call rax
0000792ccede1100  movaps xmm1, [rsp]
0000792ccede1104  add rsp, 0x30
0000792ccede1108  vmovaps xmm0, [rsp]
0000792ccede110d  vmovaps xmm2, [rsp+0x10]
0000792ccede1113  vmovaps xmm3, [rsp+0x20]
0000792ccede1119  vmovaps xmm4, [rsp+0x30]
0000792ccede111f  vmovaps xmm5, [rsp+0x40]
0000792ccede1125  vmovaps xmm6, [rsp+0x50]
0000792ccede112b  vmovaps xmm7, [rsp+0x60]
0000792ccede1131  vmovaps xmm8, [rsp+0x70]
0000792ccede1137  vmovaps xmm9, [rsp+0x80]
0000792ccede1140  vmovaps xmm10, [rsp+0x90]
0000792ccede1149  vmovaps xmm11, [rsp+0xA0]
0000792ccede1152  vmovaps xmm12, [rsp+0xB0]
0000792ccede115b  vmovaps xmm13, [rsp+0xC0]
0000792ccede1164  vmovaps xmm14, [rsp+0xD0]
0000792ccede116d  vmovaps xmm15, [rsp+0xE0]
0000792ccede1176  add rsp, 0xF0
0000792ccede117d  pop r11
0000792ccede117f  pop r10
0000792ccede1181  pop r9
0000792ccede1183  pop r8
0000792ccede1185  pop rsi
0000792ccede1186  pop rdi
0000792ccede1187  pop rdx
0000792ccede1188  pop rcx
0000792ccede1189  pop rax
0000792ccede118a  add rsp, 0x08
0000792ccede118e  jmp 0x0000792CCEDDC74D
0000792ccede1193  call 0x0000792CCEC0C260
0000792ccede1198  jmp 0x0000792CCEDDC75B
0000792ccede119d  call 0x0000792CCECBD750
0000792ccede11a2  jmp 0x0000792CCEDDC765
0000792ccede11a7  sub rsp, 0x08
0000792ccede11ab  push rax
0000792ccede11ac  push rcx
0000792ccede11ad  push rdx
0000792ccede11ae  push rdi
0000792ccede11af  push rsi
0000792ccede11b0  push r8
0000792ccede11b2  push r9
0000792ccede11b4  push r10
0000792ccede11b6  push r11
0000792ccede11b8  sub rsp, 0xF0
0000792ccede11bf  vmovaps [rsp], xmm0
0000792ccede11c4  vmovaps [rsp+0x10], xmm1
0000792ccede11ca  vmovaps [rsp+0x20], xmm2
0000792ccede11d0  vmovaps [rsp+0x30], xmm3
0000792ccede11d6  vmovaps [rsp+0x40], xmm4
0000792ccede11dc  vmovaps [rsp+0x50], xmm5
0000792ccede11e2  vmovaps [rsp+0x60], xmm6
0000792ccede11e8  vmovaps [rsp+0x70], xmm7
0000792ccede11ee  vmovaps [rsp+0x80], xmm9
0000792ccede11f7  vmovaps [rsp+0x90], xmm10
0000792ccede1200  vmovaps [rsp+0xA0], xmm11
0000792ccede1209  vmovaps [rsp+0xB0], xmm12
0000792ccede1212  vmovaps [rsp+0xC0], xmm13
0000792ccede121b  vmovaps [rsp+0xD0], xmm14
0000792ccede1224  vmovaps [rsp+0xE0], xmm15
0000792ccede122d  sub rsp, 0x30
0000792ccede1231  movaps [rsp], xmm8
0000792ccede1236  movaps [rsp+0x10], xmm15
0000792ccede123c  movaps [rsp+0x20], xmm7
0000792ccede1241  lea rdi, [rsp]
0000792ccede1245  mov esi, 0x00
0000792ccede124a  mov rax, 0x5AEE2D541530
0000792ccede1254  call rax
0000792ccede1256  movaps xmm8, [rsp]
0000792ccede125b  add rsp, 0x30
0000792ccede125f  vmovaps xmm0, [rsp]
0000792ccede1264  vmovaps xmm1, [rsp+0x10]
0000792ccede126a  vmovaps xmm2, [rsp+0x20]
0000792ccede1270  vmovaps xmm3, [rsp+0x30]
0000792ccede1276  vmovaps xmm4, [rsp+0x40]
0000792ccede127c  vmovaps xmm5, [rsp+0x50]
0000792ccede1282  vmovaps xmm6, [rsp+0x60]
0000792ccede1288  vmovaps xmm7, [rsp+0x70]
0000792ccede128e  vmovaps xmm9, [rsp+0x80]
0000792ccede1297  vmovaps xmm10, [rsp+0x90]
0000792ccede12a0  vmovaps xmm11, [rsp+0xA0]
0000792ccede12a9  vmovaps xmm12, [rsp+0xB0]
0000792ccede12b2  vmovaps xmm13, [rsp+0xC0]
0000792ccede12bb  vmovaps xmm14, [rsp+0xD0]
0000792ccede12c4  vmovaps xmm15, [rsp+0xE0]
0000792ccede12cd  add rsp, 0xF0
0000792ccede12d4  pop r11
0000792ccede12d6  pop r10
0000792ccede12d8  pop r9
0000792ccede12da  pop r8
0000792ccede12dc  pop rsi
0000792ccede12dd  pop rdi
0000792ccede12de  pop rdx
0000792ccede12df  pop rcx
0000792ccede12e0  pop rax
0000792ccede12e1  add rsp, 0x08
0000792ccede12e5  jmp 0x0000792CCEDDC787
0000792ccede12ea  sub rsp, 0x08
0000792ccede12ee  push rax
0000792ccede12ef  push rcx
0000792ccede12f0  push rdx
0000792ccede12f1  push rdi
0000792ccede12f2  push rsi
0000792ccede12f3  push r8
0000792ccede12f5  push r9
0000792ccede12f7  push r10
0000792ccede12f9  push r11
0000792ccede12fb  sub rsp, 0xF0
0000792ccede1302  vmovaps [rsp], xmm0
0000792ccede1307  vmovaps [rsp+0x10], xmm1
0000792ccede130d  vmovaps [rsp+0x20], xmm2
0000792ccede1313  vmovaps [rsp+0x30], xmm3
0000792ccede1319  vmovaps [rsp+0x40], xmm4
0000792ccede131f  vmovaps [rsp+0x50], xmm5
0000792ccede1325  vmovaps [rsp+0x60], xmm6
0000792ccede132b  vmovaps [rsp+0x70], xmm8
0000792ccede1331  vmovaps [rsp+0x80], xmm9
0000792ccede133a  vmovaps [rsp+0x90], xmm10
0000792ccede1343  vmovaps [rsp+0xA0], xmm11
0000792ccede134c  vmovaps [rsp+0xB0], xmm12
0000792ccede1355  vmovaps [rsp+0xC0], xmm13
0000792ccede135e  vmovaps [rsp+0xD0], xmm14
0000792ccede1367  vmovaps [rsp+0xE0], xmm15
0000792ccede1370  sub rsp, 0x30
0000792ccede1374  movaps [rsp], xmm7
0000792ccede1378  movaps [rsp+0x10], xmm9
0000792ccede137e  movaps [rsp+0x20], xmm15
0000792ccede1384  lea rdi, [rsp]
0000792ccede1388  mov esi, 0x00
0000792ccede138d  mov rax, 0x5AEE2D541530
0000792ccede1397  call rax
0000792ccede1399  movaps xmm7, [rsp]
0000792ccede139d  add rsp, 0x30
0000792ccede13a1  vmovaps xmm0, [rsp]
0000792ccede13a6  vmovaps xmm1, [rsp+0x10]
0000792ccede13ac  vmovaps xmm2, [rsp+0x20]
0000792ccede13b2  vmovaps xmm3, [rsp+0x30]
0000792ccede13b8  vmovaps xmm4, [rsp+0x40]
0000792ccede13be  vmovaps xmm5, [rsp+0x50]
0000792ccede13c4  vmovaps xmm6, [rsp+0x60]
0000792ccede13ca  vmovaps xmm8, [rsp+0x70]
0000792ccede13d0  vmovaps xmm9, [rsp+0x80]
0000792ccede13d9  vmovaps xmm10, [rsp+0x90]
0000792ccede13e2  vmovaps xmm11, [rsp+0xA0]
0000792ccede13eb  vmovaps xmm12, [rsp+0xB0]
0000792ccede13f4  vmovaps xmm13, [rsp+0xC0]
0000792ccede13fd  vmovaps xmm14, [rsp+0xD0]
0000792ccede1406  vmovaps xmm15, [rsp+0xE0]
0000792ccede140f  add rsp, 0xF0
0000792ccede1416  pop r11
0000792ccede1418  pop r10
0000792ccede141a  pop r9
0000792ccede141c  pop r8
0000792ccede141e  pop rsi
0000792ccede141f  pop rdi
0000792ccede1420  pop rdx
0000792ccede1421  pop rcx
0000792ccede1422  pop rax
0000792ccede1423  add rsp, 0x08
0000792ccede1427  jmp 0x0000792CCEDDC7B4
0000792ccede142c  sub rsp, 0x08
0000792ccede1430  push rax
0000792ccede1431  push rcx
0000792ccede1432  push rdx
0000792ccede1433  push rdi
0000792ccede1434  push rsi
0000792ccede1435  push r8
0000792ccede1437  push r9
0000792ccede1439  push r10
0000792ccede143b  push r11
0000792ccede143d  sub rsp, 0xF0
0000792ccede1444  vmovaps [rsp], xmm0
0000792ccede1449  vmovaps [rsp+0x10], xmm1
0000792ccede144f  vmovaps [rsp+0x20], xmm2
0000792ccede1455  vmovaps [rsp+0x30], xmm3
0000792ccede145b  vmovaps [rsp+0x40], xmm4
0000792ccede1461  vmovaps [rsp+0x50], xmm5
0000792ccede1467  vmovaps [rsp+0x60], xmm6
0000792ccede146d  vmovaps [rsp+0x70], xmm7
0000792ccede1473  vmovaps [rsp+0x80], xmm8
0000792ccede147c  vmovaps [rsp+0x90], xmm10
0000792ccede1485  vmovaps [rsp+0xA0], xmm11
0000792ccede148e  vmovaps [rsp+0xB0], xmm12
0000792ccede1497  vmovaps [rsp+0xC0], xmm13
0000792ccede14a0  vmovaps [rsp+0xD0], xmm14
0000792ccede14a9  vmovaps [rsp+0xE0], xmm15
0000792ccede14b2  sub rsp, 0x30
0000792ccede14b6  movaps [rsp], xmm9
0000792ccede14bb  movaps [rsp+0x10], xmm13
0000792ccede14c1  movaps [rsp+0x20], xmm15
0000792ccede14c7  lea rdi, [rsp]
0000792ccede14cb  mov esi, 0x00
0000792ccede14d0  mov rax, 0x5AEE2D541530
0000792ccede14da  call rax
0000792ccede14dc  movaps xmm9, [rsp]
0000792ccede14e1  add rsp, 0x30
0000792ccede14e5  vmovaps xmm0, [rsp]
0000792ccede14ea  vmovaps xmm1, [rsp+0x10]
0000792ccede14f0  vmovaps xmm2, [rsp+0x20]
0000792ccede14f6  vmovaps xmm3, [rsp+0x30]
0000792ccede14fc  vmovaps xmm4, [rsp+0x40]
0000792ccede1502  vmovaps xmm5, [rsp+0x50]
0000792ccede1508  vmovaps xmm6, [rsp+0x60]
0000792ccede150e  vmovaps xmm7, [rsp+0x70]
0000792ccede1514  vmovaps xmm8, [rsp+0x80]
0000792ccede151d  vmovaps xmm10, [rsp+0x90]
0000792ccede1526  vmovaps xmm11, [rsp+0xA0]
0000792ccede152f  vmovaps xmm12, [rsp+0xB0]
0000792ccede1538  vmovaps xmm13, [rsp+0xC0]
0000792ccede1541  vmovaps xmm14, [rsp+0xD0]
0000792ccede154a  vmovaps xmm15, [rsp+0xE0]
0000792ccede1553  add rsp, 0xF0
0000792ccede155a  pop r11
0000792ccede155c  pop r10
0000792ccede155e  pop r9
0000792ccede1560  pop r8
0000792ccede1562  pop rsi
0000792ccede1563  pop rdi
0000792ccede1564  pop rdx
0000792ccede1565  pop rcx
0000792ccede1566  pop rax
0000792ccede1567  add rsp, 0x08
0000792ccede156b  jmp 0x0000792CCEDDC7E2
0000792ccede1570  sub rsp, 0x08
0000792ccede1574  push rax
0000792ccede1575  push rcx
0000792ccede1576  push rdx
0000792ccede1577  push rdi
0000792ccede1578  push rsi
0000792ccede1579  push r8
0000792ccede157b  push r9
0000792ccede157d  push r10
0000792ccede157f  push r11
0000792ccede1581  sub rsp, 0xF0
0000792ccede1588  vmovaps [rsp], xmm0
0000792ccede158d  vmovaps [rsp+0x10], xmm1
0000792ccede1593  vmovaps [rsp+0x20], xmm2
0000792ccede1599  vmovaps [rsp+0x30], xmm3
0000792ccede159f  vmovaps [rsp+0x40], xmm4
0000792ccede15a5  vmovaps [rsp+0x50], xmm5
0000792ccede15ab  vmovaps [rsp+0x60], xmm6
0000792ccede15b1  vmovaps [rsp+0x70], xmm7
0000792ccede15b7  vmovaps [rsp+0x80], xmm8
0000792ccede15c0  vmovaps [rsp+0x90], xmm9
0000792ccede15c9  vmovaps [rsp+0xA0], xmm10
0000792ccede15d2  vmovaps [rsp+0xB0], xmm11
0000792ccede15db  vmovaps [rsp+0xC0], xmm12
0000792ccede15e4  vmovaps [rsp+0xD0], xmm13
0000792ccede15ed  vmovaps [rsp+0xE0], xmm14
0000792ccede15f6  sub rsp, 0x30
0000792ccede15fa  movaps [rsp], xmm15
0000792ccede15ff  movaps [rsp+0x10], xmm11
0000792ccede1605  movaps [rsp+0x20], xmm12
0000792ccede160b  lea rdi, [rsp]
0000792ccede160f  mov esi, 0x00
0000792ccede1614  mov rax, 0x5AEE2D541530
0000792ccede161e  call rax
0000792ccede1620  movaps xmm15, [rsp]
0000792ccede1625  add rsp, 0x30
0000792ccede1629  vmovaps xmm0, [rsp]
0000792ccede162e  vmovaps xmm1, [rsp+0x10]
0000792ccede1634  vmovaps xmm2, [rsp+0x20]
0000792ccede163a  vmovaps xmm3, [rsp+0x30]
0000792ccede1640  vmovaps xmm4, [rsp+0x40]
0000792ccede1646  vmovaps xmm5, [rsp+0x50]
0000792ccede164c  vmovaps xmm6, [rsp+0x60]
0000792ccede1652  vmovaps xmm7, [rsp+0x70]
0000792ccede1658  vmovaps xmm8, [rsp+0x80]
0000792ccede1661  vmovaps xmm9, [rsp+0x90]
0000792ccede166a  vmovaps xmm10, [rsp+0xA0]
0000792ccede1673  vmovaps xmm11, [rsp+0xB0]
0000792ccede167c  vmovaps xmm12, [rsp+0xC0]
0000792ccede1685  vmovaps xmm13, [rsp+0xD0]
0000792ccede168e  vmovaps xmm14, [rsp+0xE0]
0000792ccede1697  add rsp, 0xF0
0000792ccede169e  pop r11
0000792ccede16a0  pop r10
0000792ccede16a2  pop r9
0000792ccede16a4  pop r8
0000792ccede16a6  pop rsi
0000792ccede16a7  pop rdi
0000792ccede16a8  pop rdx
0000792ccede16a9  pop rcx
0000792ccede16aa  pop rax
0000792ccede16ab  add rsp, 0x08
0000792ccede16af  jmp 0x0000792CCEDDC7FD
0000792ccede16b4  sub rsp, 0x08
0000792ccede16b8  push rax
0000792ccede16b9  push rcx
0000792ccede16ba  push rdx
0000792ccede16bb  push rdi
0000792ccede16bc  push rsi
0000792ccede16bd  push r8
0000792ccede16bf  push r9
0000792ccede16c1  push r10
0000792ccede16c3  push r11
0000792ccede16c5  sub rsp, 0xF0
0000792ccede16cc  vmovaps [rsp], xmm0
0000792ccede16d1  vmovaps [rsp+0x10], xmm1
0000792ccede16d7  vmovaps [rsp+0x20], xmm2
0000792ccede16dd  vmovaps [rsp+0x30], xmm3
0000792ccede16e3  vmovaps [rsp+0x40], xmm4
0000792ccede16e9  vmovaps [rsp+0x50], xmm5
0000792ccede16ef  vmovaps [rsp+0x60], xmm6
0000792ccede16f5  vmovaps [rsp+0x70], xmm7
0000792ccede16fb  vmovaps [rsp+0x80], xmm8
0000792ccede1704  vmovaps [rsp+0x90], xmm9
0000792ccede170d  vmovaps [rsp+0xA0], xmm10
0000792ccede1716  vmovaps [rsp+0xB0], xmm11
0000792ccede171f  vmovaps [rsp+0xC0], xmm12
0000792ccede1728  vmovaps [rsp+0xD0], xmm14
0000792ccede1731  vmovaps [rsp+0xE0], xmm15
0000792ccede173a  sub rsp, 0x30
0000792ccede173e  movaps [rsp], xmm13
0000792ccede1743  movaps [rsp+0x10], xmm10
0000792ccede1749  movaps [rsp+0x20], xmm14
0000792ccede174f  lea rdi, [rsp]
0000792ccede1753  mov esi, 0x00
0000792ccede1758  mov rax, 0x5AEE2D541530
0000792ccede1762  call rax
0000792ccede1764  movaps xmm13, [rsp]
0000792ccede1769  add rsp, 0x30
0000792ccede176d  vmovaps xmm0, [rsp]
0000792ccede1772  vmovaps xmm1, [rsp+0x10]
0000792ccede1778  vmovaps xmm2, [rsp+0x20]
0000792ccede177e  vmovaps xmm3, [rsp+0x30]
0000792ccede1784  vmovaps xmm4, [rsp+0x40]
0000792ccede178a  vmovaps xmm5, [rsp+0x50]
0000792ccede1790  vmovaps xmm6, [rsp+0x60]
0000792ccede1796  vmovaps xmm7, [rsp+0x70]
0000792ccede179c  vmovaps xmm8, [rsp+0x80]
0000792ccede17a5  vmovaps xmm9, [rsp+0x90]
0000792ccede17ae  vmovaps xmm10, [rsp+0xA0]
0000792ccede17b7  vmovaps xmm11, [rsp+0xB0]
0000792ccede17c0  vmovaps xmm12, [rsp+0xC0]
0000792ccede17c9  vmovaps xmm14, [rsp+0xD0]
0000792ccede17d2  vmovaps xmm15, [rsp+0xE0]
0000792ccede17db  add rsp, 0xF0
0000792ccede17e2  pop r11
0000792ccede17e4  pop r10
0000792ccede17e6  pop r9
0000792ccede17e8  pop r8
0000792ccede17ea  pop rsi
0000792ccede17eb  pop rdi
0000792ccede17ec  pop rdx
0000792ccede17ed  pop rcx
0000792ccede17ee  pop rax
0000792ccede17ef  add rsp, 0x08
0000792ccede17f3  jmp 0x0000792CCEDDC820
0000792ccede17f8  sub rsp, 0x08
0000792ccede17fc  push rax
0000792ccede17fd  push rcx
0000792ccede17fe  push rdx
0000792ccede17ff  push rdi
0000792ccede1800  push rsi
0000792ccede1801  push r8
0000792ccede1803  push r9
0000792ccede1805  push r10
0000792ccede1807  push r11
0000792ccede1809  sub rsp, 0xF0
0000792ccede1810  vmovaps [rsp], xmm0
0000792ccede1815  vmovaps [rsp+0x10], xmm1
0000792ccede181b  vmovaps [rsp+0x20], xmm2
0000792ccede1821  vmovaps [rsp+0x30], xmm3
0000792ccede1827  vmovaps [rsp+0x40], xmm4
0000792ccede182d  vmovaps [rsp+0x50], xmm5
0000792ccede1833  vmovaps [rsp+0x60], xmm6
0000792ccede1839  vmovaps [rsp+0x70], xmm7
0000792ccede183f  vmovaps [rsp+0x80], xmm8
0000792ccede1848  vmovaps [rsp+0x90], xmm9
0000792ccede1851  vmovaps [rsp+0xA0], xmm10
0000792ccede185a  vmovaps [rsp+0xB0], xmm11
0000792ccede1863  vmovaps [rsp+0xC0], xmm12
0000792ccede186c  vmovaps [rsp+0xD0], xmm13
0000792ccede1875  vmovaps [rsp+0xE0], xmm15
0000792ccede187e  sub rsp, 0x30
0000792ccede1882  movaps [rsp], xmm14
0000792ccede1887  movaps [rsp+0x10], xmm1
0000792ccede188c  movaps [rsp+0x20], xmm7
0000792ccede1891  lea rdi, [rsp]
0000792ccede1895  mov esi, 0x00
0000792ccede189a  mov rax, 0x5AEE2D541530
0000792ccede18a4  call rax
0000792ccede18a6  movaps xmm14, [rsp]
0000792ccede18ab  add rsp, 0x30
0000792ccede18af  vmovaps xmm0, [rsp]
0000792ccede18b4  vmovaps xmm1, [rsp+0x10]
0000792ccede18ba  vmovaps xmm2, [rsp+0x20]
0000792ccede18c0  vmovaps xmm3, [rsp+0x30]
0000792ccede18c6  vmovaps xmm4, [rsp+0x40]
0000792ccede18cc  vmovaps xmm5, [rsp+0x50]
0000792ccede18d2  vmovaps xmm6, [rsp+0x60]
0000792ccede18d8  vmovaps xmm7, [rsp+0x70]
0000792ccede18de  vmovaps xmm8, [rsp+0x80]
0000792ccede18e7  vmovaps xmm9, [rsp+0x90]
0000792ccede18f0  vmovaps xmm10, [rsp+0xA0]
0000792ccede18f9  vmovaps xmm11, [rsp+0xB0]
0000792ccede1902  vmovaps xmm12, [rsp+0xC0]
0000792ccede190b  vmovaps xmm13, [rsp+0xD0]
0000792ccede1914  vmovaps xmm15, [rsp+0xE0]
0000792ccede191d  add rsp, 0xF0
0000792ccede1924  pop r11
0000792ccede1926  pop r10
0000792ccede1928  pop r9
0000792ccede192a  pop r8
0000792ccede192c  pop rsi
0000792ccede192d  pop rdi
0000792ccede192e  pop rdx
0000792ccede192f  pop rcx
0000792ccede1930  pop rax
0000792ccede1931  add rsp, 0x08
0000792ccede1935  jmp 0x0000792CCEDDC843
0000792ccede193a  sub rsp, 0x08
0000792ccede193e  push rax
0000792ccede193f  push rcx
0000792ccede1940  push rdx
0000792ccede1941  push rdi
0000792ccede1942  push rsi
0000792ccede1943  push r8
0000792ccede1945  push r9
0000792ccede1947  push r10
0000792ccede1949  push r11
0000792ccede194b  sub rsp, 0xF0
0000792ccede1952  vmovaps [rsp], xmm0
0000792ccede1957  vmovaps [rsp+0x10], xmm2
0000792ccede195d  vmovaps [rsp+0x20], xmm3
0000792ccede1963  vmovaps [rsp+0x30], xmm4
0000792ccede1969  vmovaps [rsp+0x40], xmm5
0000792ccede196f  vmovaps [rsp+0x50], xmm6
0000792ccede1975  vmovaps [rsp+0x60], xmm7
0000792ccede197b  vmovaps [rsp+0x70], xmm8
0000792ccede1981  vmovaps [rsp+0x80], xmm9
0000792ccede198a  vmovaps [rsp+0x90], xmm10
0000792ccede1993  vmovaps [rsp+0xA0], xmm11
0000792ccede199c  vmovaps [rsp+0xB0], xmm12
0000792ccede19a5  vmovaps [rsp+0xC0], xmm13
0000792ccede19ae  vmovaps [rsp+0xD0], xmm14
0000792ccede19b7  vmovaps [rsp+0xE0], xmm15
0000792ccede19c0  sub rsp, 0x30
0000792ccede19c4  movaps [rsp], xmm1
0000792ccede19c8  movaps [rsp+0x10], xmm8
0000792ccede19ce  movaps [rsp+0x20], xmm9
0000792ccede19d4  lea rdi, [rsp]
0000792ccede19d8  mov esi, 0x00
0000792ccede19dd  mov rax, 0x5AEE2D541530
0000792ccede19e7  call rax
0000792ccede19e9  movaps xmm1, [rsp]
0000792ccede19ed  add rsp, 0x30
0000792ccede19f1  vmovaps xmm0, [rsp]
0000792ccede19f6  vmovaps xmm2, [rsp+0x10]
0000792ccede19fc  vmovaps xmm3, [rsp+0x20]
0000792ccede1a02  vmovaps xmm4, [rsp+0x30]
0000792ccede1a08  vmovaps xmm5, [rsp+0x40]
0000792ccede1a0e  vmovaps xmm6, [rsp+0x50]
0000792ccede1a14  vmovaps xmm7, [rsp+0x60]
0000792ccede1a1a  vmovaps xmm8, [rsp+0x70]
0000792ccede1a20  vmovaps xmm9, [rsp+0x80]
0000792ccede1a29  vmovaps xmm10, [rsp+0x90]
0000792ccede1a32  vmovaps xmm11, [rsp+0xA0]
0000792ccede1a3b  vmovaps xmm12, [rsp+0xB0]
0000792ccede1a44  vmovaps xmm13, [rsp+0xC0]
0000792ccede1a4d  vmovaps xmm14, [rsp+0xD0]
0000792ccede1a56  vmovaps xmm15, [rsp+0xE0]
0000792ccede1a5f  add rsp, 0xF0
0000792ccede1a66  pop r11
0000792ccede1a68  pop r10
0000792ccede1a6a  pop r9
0000792ccede1a6c  pop r8
0000792ccede1a6e  pop rsi
0000792ccede1a6f  pop rdi
0000792ccede1a70  pop rdx
0000792ccede1a71  pop rcx
0000792ccede1a72  pop rax
0000792ccede1a73  add rsp, 0x08
0000792ccede1a77  jmp 0x0000792CCEDDC865
0000792ccede1a7c  call 0x0000792CCECE5940
0000792ccede1a81  jmp 0x0000792CCEDDC873
0000792ccede1a86  call 0x0000792CCEC0C380
0000792ccede1a8b  jmp 0x0000792CCEDDC87D
0000792ccede1a90  call 0x0000792CCEC0D600
0000792ccede1a95  jmp 0x0000792CCEDDC887
0000792ccede1a9a  call 0x0000792CCEBFF540
0000792ccede1a9f  jmp 0x0000792CCEDDC891
0000792ccede1aa4  int3
0000792ccede1aa5  nop [rax+rax*1], ax
0000792ccede1aae  nop
0000792ccede1ab0  mov rax, [r15+0xF8]
0000792ccede1ab7  lea r14, [rax+0x140]
0000792ccede1abe  mov r12, [r13+r14*1]
0000792ccede1ac3  mov [r15+0xE8], r12
0000792ccede1aca  lea r14, [rax+0x130]
0000792ccede1ad1  mov r12, [r13+r14*1]
0000792ccede1ad6  lea r14, [rax+0x138]
0000792ccede1add  mov r11, [r13+r14*1]
0000792ccede1ae2  movq xmm1, r12
0000792ccede1ae7  movq xmm15, r11
0000792ccede1aec  movq xmm1, xmm1
0000792ccede1af0  movq xmm1, xmm1
0000792ccede1af4  movaps [r15+0x1A0], xmm1
0000792ccede1afc  movq xmm15, xmm15
0000792ccede1b01  movq xmm15, xmm15
0000792ccede1b06  movaps [r15+0x190], xmm15
0000792ccede1b0e  lea r14, [rax+0x120]
0000792ccede1b15  mov r12, [r13+r14*1]
0000792ccede1b1a  lea r14, [rax+0x128]
0000792ccede1b21  mov r11, [r13+r14*1]
0000792ccede1b26  movq xmm1, r12
0000792ccede1b2b  movq xmm15, r11
0000792ccede1b30  movq xmm1, xmm1
0000792ccede1b34  movq xmm1, xmm1
0000792ccede1b38  movaps [r15+0x1C0], xmm1
0000792ccede1b40  movq xmm15, xmm15
0000792ccede1b45  movq xmm15, xmm15
0000792ccede1b4a  movaps [r15+0x1B0], xmm15
0000792ccede1b52  lea r14, [rax+0x110]
0000792ccede1b59  mov r12, [r13+r14*1]
0000792ccede1b5e  lea r14, [rax+0x118]
0000792ccede1b65  mov r11, [r13+r14*1]
0000792ccede1b6a  movq xmm1, r12
0000792ccede1b6f  movq xmm15, r11
0000792ccede1b74  movq xmm1, xmm1
0000792ccede1b78  movq xmm1, xmm1
0000792ccede1b7c  movaps [r15+0x1E0], xmm1
0000792ccede1b84  movq xmm15, xmm15
0000792ccede1b89  movq xmm15, xmm15
0000792ccede1b8e  movaps [r15+0x1D0], xmm15
0000792ccede1b96  lea r14, [rax+0x100]
0000792ccede1b9d  mov r12, [r13+r14*1]
0000792ccede1ba2  lea r14, [rax+0x108]
0000792ccede1ba9  mov r11, [r13+r14*1]
0000792ccede1bae  movq xmm1, r12
0000792ccede1bb3  movq xmm15, r11
0000792ccede1bb8  movq xmm1, xmm1
0000792ccede1bbc  movq xmm1, xmm1
0000792ccede1bc0  movaps [r15+0x200], xmm1
0000792ccede1bc8  movq xmm15, xmm15
0000792ccede1bcd  movq xmm15, xmm15
0000792ccede1bd2  movaps [r15+0x1F0], xmm15
0000792ccede1bda  mov qword ptr [r15+0x40], 0x430000
0000792ccede1be2  mov r14d, 0x430510
0000792ccede1be8  mov r12, [r13+r14*1]
0000792ccede1bed  movq xmm1, r12
0000792ccede1bf2  lea r14, [rax+0x150]
0000792ccede1bf9  mov [r15+0xF8], r14
0000792ccede1c00  mov rax, [r15+0x50]
0000792ccede1c04  movups xmm15, [r13+rax*1]
0000792ccede1c0a  movaps [r15+0x120], xmm15
0000792ccede1c12  mov qword ptr [r15+0x48], 0x10
0000792ccede1c1a  xor eax, eax
0000792ccede1c1c  mov r14d, 0x10
0000792ccede1c22  mov r12d, 0x200
0000792ccede1c28  cmp r14, r12
0000792ccede1c2b  cmc
0000792ccede1c2c  lahf
0000792ccede1c2d  seto al
0000792ccede1c30  mov [r15+0x108], eax
0000792ccede1c37  pextrq rax, xmm15, 0x01
0000792ccede1c3e  movq xmm14, rax
0000792ccede1c43  movaps [r15+0x130], xmm14
0000792ccede1c4b  movq rax, xmm1
0000792ccede1c50  movq r14, xmm15
0000792ccede1c55  vmovq xmm1, rax
0000792ccede1c5a  vmovq xmm15, r14
0000792ccede1c5f  movaps xmm13, xmm1
0000792ccede1c63  addsd xmm13, xmm15
0000792ccede1c68  ucomisd xmm13, xmm13
0000792ccede1c6d  jp 0x0000792CCEDE1D86
0000792ccede1c73  movq xmm13, xmm13
0000792ccede1c78  movq rax, xmm13
0000792ccede1c7d  movq r14, xmm14
0000792ccede1c82  vmovq xmm1, rax
0000792ccede1c87  vmovq xmm15, r14
0000792ccede1c8c  movaps xmm14, xmm1
0000792ccede1c90  addsd xmm14, xmm15
0000792ccede1c95  ucomisd xmm14, xmm14
0000792ccede1c9a  jp 0x0000792CCEDE1DCE
0000792ccede1ca0  movq xmm14, xmm14
0000792ccede1ca5  movaps [r15+0x110], xmm14
0000792ccede1cad  mov eax, [r15+0x108]
0000792ccede1cb4  sahf
0000792ccede1cb5  jnz 0x0000792CCEDE1CE7
0000792ccede1cb7  cmp dword ptr [r15+0x318], 0x00
0000792ccede1cbf  jz 0x0000792CCEDE1FE0
0000792ccede1cc5  nop [rax+rax*1], ax
0000792ccede1cce  nop [rax+rax*1], eax
0000792ccede1cd6  mov eax, 0x410490
0000792ccede1cdb  mov [r15+0x100], rax
0000792ccede1ce2  jmp 0x0000792CCEBFE110
0000792ccede1ce7  cmp dword ptr [r15+0x318], 0x00
0000792ccede1cef  jz 0x0000792CCEDE1E20
0000792ccede1cf5  nop [rax+rax*1], ax
0000792ccede1cfe  nop [rax+rax*1], eax
0000792ccede1d06  mov eax, 0x410474
0000792ccede1d0b  mov [r15+0x100], rax
0000792ccede1d12  jmp 0x0000792CCEBFE110
0000792ccede1d17  int3
0000792ccede1d18  call 0x0000792CCECE27E0
0000792ccede1d1d  jmp 0x0000792CCEDE1AC3
0000792ccede1d22  call 0x0000792CCECE27E0
0000792ccede1d27  jmp 0x0000792CCEDE1AD6
0000792ccede1d2c  call 0x0000792CCECE1570
0000792ccede1d31  jmp 0x0000792CCEDE1AE2
0000792ccede1d36  call 0x0000792CCECE27E0
0000792ccede1d3b  jmp 0x0000792CCEDE1B1A
0000792ccede1d40  call 0x0000792CCECE1570
0000792ccede1d45  jmp 0x0000792CCEDE1B26
0000792ccede1d4a  call 0x0000792CCECE27E0
0000792ccede1d4f  jmp 0x0000792CCEDE1B5E
0000792ccede1d54  call 0x0000792CCECE1570
0000792ccede1d59  jmp 0x0000792CCEDE1B6A
0000792ccede1d5e  call 0x0000792CCECE27E0
0000792ccede1d63  jmp 0x0000792CCEDE1BA2
0000792ccede1d68  call 0x0000792CCECE1570
0000792ccede1d6d  jmp 0x0000792CCEDE1BAE
0000792ccede1d72  call 0x0000792CCECE27E0
0000792ccede1d77  jmp 0x0000792CCEDE1BED
0000792ccede1d7c  call 0x0000792CCEC0E760
0000792ccede1d81  jmp 0x0000792CCEDE1C0A
0000792ccede1d86  ucomisd xmm1, xmm15
0000792ccede1d8b  jp 0x0000792CCEDE1D9A
0000792ccede1d8d  movaps xmm13, [0x0000792CCE9FE060]
0000792ccede1d95  jmp 0x0000792CCEDE1C73
0000792ccede1d9a  vxorps xmm0, xmm1, xmm15
0000792ccede1d9f  pextrw eax, xmm0, 0x03
0000792ccede1da4  and eax, 0x7FF8
0000792ccede1da9  cmp eax, 0x08
0000792ccede1dac  jnz 0x0000792CCEDE1C73
0000792ccede1db2  movq rax, xmm15
0000792ccede1db7  shl rax, 0x0D
0000792ccede1dbb  jbe 0x0000792CCEDE1C73
0000792ccede1dc1  vorps xmm13, xmm15, [0x0000792CCE9FE070]
0000792ccede1dc9  jmp 0x0000792CCEDE1C73
0000792ccede1dce  ucomisd xmm1, xmm15
0000792ccede1dd3  jp 0x0000792CCEDE1DE2
0000792ccede1dd5  movaps xmm14, [0x0000792CCE9FE060]
0000792ccede1ddd  jmp 0x0000792CCEDE1CA0
0000792ccede1de2  vxorps xmm0, xmm1, xmm15
0000792ccede1de7  pextrw eax, xmm0, 0x03
0000792ccede1dec  and eax, 0x7FF8
0000792ccede1df1  cmp eax, 0x08
0000792ccede1df4  jnz 0x0000792CCEDE1CA0
0000792ccede1dfa  movq rax, xmm15
0000792ccede1dff  shl rax, 0x0D
0000792ccede1e03  jbe 0x0000792CCEDE1CA0
0000792ccede1e09  vorps xmm14, xmm15, [0x0000792CCE9FE070]
0000792ccede1e11  jmp 0x0000792CCEDE1CA0
0000792ccede1e16  int3
0000792ccede1e17  nop [rax+rax*1], ax
0000792ccede1e20  mov rax, [r15+0x48]
0000792ccede1e24  mov r14, [r15+0x50]
0000792ccede1e28  lea r12, [r14+rax*1]
0000792ccede1e2c  movups xmm1, [r13+r12*1]
0000792ccede1e32  movaps [r15+0x120], xmm1
0000792ccede1e3a  lea r14, [rax+0x10]
0000792ccede1e3e  mov [r15+0x48], r14
0000792ccede1e42  xor eax, eax
0000792ccede1e44  mov r12d, 0x200
0000792ccede1e4a  cmp r14, r12
0000792ccede1e4d  cmc
0000792ccede1e4e  lahf
0000792ccede1e4f  seto al
0000792ccede1e52  mov [r15+0x108], eax
0000792ccede1e59  pextrq rax, xmm1, 0x01
0000792ccede1e60  movq xmm15, rax
0000792ccede1e65  movaps [r15+0x130], xmm15
0000792ccede1e6d  movaps xmm14, [r15+0x110]
0000792ccede1e75  movq rax, xmm14
0000792ccede1e7a  movq r14, xmm1
0000792ccede1e7f  vmovq xmm1, rax
0000792ccede1e84  vmovq xmm14, r14
0000792ccede1e89  movaps xmm13, xmm1
0000792ccede1e8d  addsd xmm13, xmm14
0000792ccede1e92  ucomisd xmm13, xmm13
0000792ccede1e97  jp 0x0000792CCEDE1F4C
0000792ccede1e9d  movq xmm13, xmm13
0000792ccede1ea2  movq rax, xmm13
0000792ccede1ea7  movq r14, xmm15
0000792ccede1eac  vmovq xmm1, rax
0000792ccede1eb1  vmovq xmm15, r14
0000792ccede1eb6  movaps xmm14, xmm1
0000792ccede1eba  addsd xmm14, xmm15
0000792ccede1ebf  ucomisd xmm14, xmm14
0000792ccede1ec4  jp 0x0000792CCEDE1F94
0000792ccede1eca  movq xmm14, xmm14
0000792ccede1ecf  movaps [r15+0x110], xmm14
0000792ccede1ed7  mov eax, [r15+0x108]
0000792ccede1ede  sahf
0000792ccede1edf  jnz 0x0000792CCEDE1F11
0000792ccede1ee1  cmp dword ptr [r15+0x318], 0x00
0000792ccede1ee9  jz 0x0000792CCEDE1FE0
0000792ccede1eef  nop [rax+rax*1], ax
0000792ccede1ef8  nop [rax+rax*1], eax
0000792ccede1f00  mov eax, 0x410490
0000792ccede1f05  mov [r15+0x100], rax
0000792ccede1f0c  jmp 0x0000792CCEBFE110
0000792ccede1f11  cmp dword ptr [r15+0x318], 0x00
0000792ccede1f19  jz 0x0000792CCEDE1E20
0000792ccede1f1f  nop [rax+rax*1], ax
0000792ccede1f28  nop [rax+rax*1], eax
0000792ccede1f30  mov eax, 0x410474
0000792ccede1f35  mov [r15+0x100], rax
0000792ccede1f3c  jmp 0x0000792CCEBFE110
0000792ccede1f41  int3
0000792ccede1f42  call 0x0000792CCECB52F0
0000792ccede1f47  jmp 0x0000792CCEDE1E32
0000792ccede1f4c  ucomisd xmm1, xmm14
0000792ccede1f51  jp 0x0000792CCEDE1F60
0000792ccede1f53  movaps xmm13, [0x0000792CCE9FE060]
0000792ccede1f5b  jmp 0x0000792CCEDE1E9D
0000792ccede1f60  vxorps xmm0, xmm1, xmm14
0000792ccede1f65  pextrw eax, xmm0, 0x03
0000792ccede1f6a  and eax, 0x7FF8
0000792ccede1f6f  cmp eax, 0x08
0000792ccede1f72  jnz 0x0000792CCEDE1E9D
0000792ccede1f78  movq rax, xmm14
0000792ccede1f7d  shl rax, 0x0D
0000792ccede1f81  jbe 0x0000792CCEDE1E9D
0000792ccede1f87  vorps xmm13, xmm14, [0x0000792CCE9FE070]
0000792ccede1f8f  jmp 0x0000792CCEDE1E9D
0000792ccede1f94  ucomisd xmm1, xmm15
0000792ccede1f99  jp 0x0000792CCEDE1FA8
0000792ccede1f9b  movaps xmm14, [0x0000792CCE9FE060]
0000792ccede1fa3  jmp 0x0000792CCEDE1ECA
0000792ccede1fa8  vxorps xmm0, xmm1, xmm15
0000792ccede1fad  pextrw eax, xmm0, 0x03
0000792ccede1fb2  and eax, 0x7FF8
0000792ccede1fb7  cmp eax, 0x08
0000792ccede1fba  jnz 0x0000792CCEDE1ECA
0000792ccede1fc0  movq rax, xmm15
0000792ccede1fc5  shl rax, 0x0D
0000792ccede1fc9  jbe 0x0000792CCEDE1ECA
0000792ccede1fcf  vorps xmm14, xmm15, [0x0000792CCE9FE070]
0000792ccede1fd7  jmp 0x0000792CCEDE1ECA
0000792ccede1fdc  int3
0000792ccede1fdd  nop [rax], eax
0000792ccede1fe0  mov rax, [r15+0x40]
0000792ccede1fe4  lea r14, [rax+0x510]
0000792ccede1feb  movaps xmm1, [r15+0x110]
0000792ccede1ff3  movq rax, xmm1
0000792ccede1ff8  mov [r13+r14*1], rax
0000792ccede1ffd  mov rax, [r15+0xF0]
0000792ccede2004  mov [r15+0x100], rax
0000792ccede200b  jmp 0x0000792CCEDCE5C0
0000792ccede2010  int3
0000792ccede2011  call 0x0000792CCECD5EB0
0000792ccede2016  jmp 0x0000792CCEDE1FFD
0000792ccede201b  int3
0000792ccede201c  nop [rax], eax
0000792ccede2020  mov qword ptr [r15+0x100], 0x04
0000792ccede202b  mov esi, 0x00
0000792ccede2030  mov edx, 0x09
0000792ccede2035  mov rdi, 0x7FFFA39FCF30
0000792ccede203f  mov rax, 0x5AEE2D3D4970
0000792ccede2049  call rax
0000792ccede204b  cmp dword ptr [r15+0x318], 0x00
0000792ccede2053  jnz 0x0000792CCEBFE110
0000792ccede2059  jmp 0x0000792CCEBFE0A0
0000792ccede205e  int3
0000792ccede205f  int3
