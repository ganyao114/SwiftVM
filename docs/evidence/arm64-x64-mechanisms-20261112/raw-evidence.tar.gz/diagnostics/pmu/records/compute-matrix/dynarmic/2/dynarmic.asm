00007e55d47ce69b  nop [rax+rax*1], eax
00007e55d47ce6a0  vmovaps xmm1, [0x00007E55D43FE010]
00007e55d47ce6a8  movq xmm1, xmm1
00007e55d47ce6ac  movaps [r15+0x110], xmm1
00007e55d47ce6b4  vmovaps xmm1, [0x00007E55D43FE020]
00007e55d47ce6bc  movq xmm1, xmm1
00007e55d47ce6c0  movaps [r15+0x120], xmm1
00007e55d47ce6c8  mov eax, 0x4204C0
00007e55d47ce6cd  mov r14, [r13+rax*1]
00007e55d47ce6d2  movq xmm1, r14
00007e55d47ce6d7  movaps [r15+0x130], xmm1
00007e55d47ce6df  vmovaps xmm1, [0x00007E55D43FE030]
00007e55d47ce6e7  vpbroadcastq xmm1, xmm1
00007e55d47ce6ec  movaps [r15+0x140], xmm1
00007e55d47ce6f4  mov qword ptr [r15+0x40], 0x02
00007e55d47ce6fc  vmovaps xmm15, [0x00007E55D43FE040]
00007e55d47ce704  movq xmm15, xmm15
00007e55d47ce709  movaps [r15+0x150], xmm15
00007e55d47ce711  mov qword ptr [r15+0x58], 0x420000
00007e55d47ce719  vmovaps xmm15, [0x00007E55D43FE050]
00007e55d47ce721  vpbroadcastq xmm15, xmm15
00007e55d47ce726  movaps [r15+0x160], xmm15
00007e55d47ce72e  mov rax, [r15+0x40]
00007e55d47ce732  vmovq xmm14, rax
00007e55d47ce737  vpbroadcastq xmm14, xmm14
00007e55d47ce73c  movaps [r15+0x170], xmm14
00007e55d47ce744  mov eax, 0x4204D0
00007e55d47ce749  movups xmm13, [r13+rax*1]
00007e55d47ce74f  mov qword ptr [r15+0x40], 0x430518
00007e55d47ce757  mov qword ptr [r15+0x50], 0x430720
00007e55d47ce75f  vpmovqd xmm12, xmm13
00007e55d47ce765  pxor xmm11, xmm11
00007e55d47ce76a  punpcklqdq xmm12, xmm11
00007e55d47ce76f  movaps [r15+0x210], xmm12
00007e55d47ce777  movq xmm12, qword ptr [r15+0x120]
00007e55d47ce780  movq xmm11, qword ptr [r15+0x130]
00007e55d47ce789  psubd xmm12, xmm11
00007e55d47ce78e  movq xmm12, xmm12
00007e55d47ce793  paddq xmm13, xmm14
00007e55d47ce798  movaps [r15+0x180], xmm13
00007e55d47ce7a0  movq xmm14, qword ptr [r15+0x150]
00007e55d47ce7a9  paddd xmm11, xmm14
00007e55d47ce7ae  movq xmm11, xmm11
00007e55d47ce7b3  movq xmm11, xmm11
00007e55d47ce7b8  movaps [r15+0x130], xmm11
00007e55d47ce7c0  pmovzxdq xmm12, xmm12
00007e55d47ce7c6  psllq xmm12, 0x00
00007e55d47ce7cc  movq xmm14, qword ptr [r15+0x210]
00007e55d47ce7d5  movq xmm13, qword ptr [r15+0x110]
00007e55d47ce7de  paddd xmm14, xmm13
00007e55d47ce7e3  movq xmm14, xmm14
00007e55d47ce7e8  vcvtuqq2pd xmm12, xmm12
00007e55d47ce7ee  pmovzxdq xmm14, xmm14
00007e55d47ce7f4  psllq xmm14, 0x00
00007e55d47ce7fa  vcvtuqq2pd xmm14, xmm14
00007e55d47ce800  movaps xmm13, xmm12
00007e55d47ce804  mulpd xmm13, xmm1
00007e55d47ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007e55d47ce80f  ptest xmm11, xmm11
00007e55d47ce815  jnz 0x00007E55D47CE8FF
00007e55d47ce81b  movaps [r15+0x220], xmm13
00007e55d47ce823  mov eax, 0x430720
00007e55d47ce828  movups [r13+rax*1], xmm13
00007e55d47ce82e  movaps xmm1, xmm14
00007e55d47ce832  mulpd xmm1, xmm15
00007e55d47ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007e55d47ce83c  ptest xmm13, xmm13
00007e55d47ce842  jnz 0x00007E55D47CEA4C
00007e55d47ce848  movaps [r15+0x210], xmm1
00007e55d47ce850  mov eax, 0x430518
00007e55d47ce855  movups [r13+rax*1], xmm1
00007e55d47ce85b  mov qword ptr [r15+0x48], 0x10
00007e55d47ce863  xor eax, eax
00007e55d47ce865  mov r14d, 0x10
00007e55d47ce86b  mov r12d, 0x200
00007e55d47ce871  cmp r14, r12
00007e55d47ce874  cmc
00007e55d47ce875  lahf
00007e55d47ce876  seto al
00007e55d47ce879  mov [r15+0x108], eax
00007e55d47ce880  mov eax, [r15+0x108]
00007e55d47ce887  sahf
00007e55d47ce888  jnz 0x00007E55D47CE8BA
00007e55d47ce88a  cmp dword ptr [r15+0x318], 0x00
00007e55d47ce892  jz 0x00007E55D47CEFF0
00007e55d47ce898  nop [rax+rax*1], ax
00007e55d47ce8a1  nop [rax+rax*1], eax
00007e55d47ce8a9  mov eax, 0x4101EC
00007e55d47ce8ae  mov [r15+0x100], rax
00007e55d47ce8b5  jmp 0x00007E55D45FE110
00007e55d47ce8ba  cmp dword ptr [r15+0x318], 0x00
00007e55d47ce8c2  jz 0x00007E55D47CEBA0
00007e55d47ce8c8  nop [rax+rax*1], ax
00007e55d47ce8d1  nop [rax+rax*1], eax
00007e55d47ce8d9  mov eax, 0x4101AC
00007e55d47ce8de  mov [r15+0x100], rax
00007e55d47ce8e5  jmp 0x00007E55D45FE110
00007e55d47ce8ea  int3
00007e55d47ce8eb  call 0x00007E55D460DC20
00007e55d47ce8f0  jmp 0x00007E55D47CE6D2
00007e55d47ce8f5  call 0x00007E55D460C260
00007e55d47ce8fa  jmp 0x00007E55D47CE74F
00007e55d47ce8ff  sub rsp, 0x08
00007e55d47ce903  push rax
00007e55d47ce904  push rcx
00007e55d47ce905  push rdx
00007e55d47ce906  push rdi
00007e55d47ce907  push rsi
00007e55d47ce908  push r8
00007e55d47ce90a  push r9
00007e55d47ce90c  push r10
00007e55d47ce90e  push r11
00007e55d47ce910  sub rsp, 0xF0
00007e55d47ce917  vmovaps [rsp], xmm0
00007e55d47ce91c  vmovaps [rsp+0x10], xmm1
00007e55d47ce922  vmovaps [rsp+0x20], xmm2
00007e55d47ce928  vmovaps [rsp+0x30], xmm3
00007e55d47ce92e  vmovaps [rsp+0x40], xmm4
00007e55d47ce934  vmovaps [rsp+0x50], xmm5
00007e55d47ce93a  vmovaps [rsp+0x60], xmm6
00007e55d47ce940  vmovaps [rsp+0x70], xmm7
00007e55d47ce946  vmovaps [rsp+0x80], xmm8
00007e55d47ce94f  vmovaps [rsp+0x90], xmm9
00007e55d47ce958  vmovaps [rsp+0xA0], xmm10
00007e55d47ce961  vmovaps [rsp+0xB0], xmm11
00007e55d47ce96a  vmovaps [rsp+0xC0], xmm12
00007e55d47ce973  vmovaps [rsp+0xD0], xmm14
00007e55d47ce97c  vmovaps [rsp+0xE0], xmm15
00007e55d47ce985  sub rsp, 0x30
00007e55d47ce989  movaps [rsp], xmm13
00007e55d47ce98e  movaps [rsp+0x10], xmm12
00007e55d47ce994  movaps [rsp+0x20], xmm1
00007e55d47ce999  lea rdi, [rsp]
00007e55d47ce99d  mov esi, 0x00
00007e55d47ce9a2  mov rax, 0x55D0734A4530
00007e55d47ce9ac  call rax
00007e55d47ce9ae  movaps xmm13, [rsp]
00007e55d47ce9b3  add rsp, 0x30
00007e55d47ce9b7  vmovaps xmm0, [rsp]
00007e55d47ce9bc  vmovaps xmm1, [rsp+0x10]
00007e55d47ce9c2  vmovaps xmm2, [rsp+0x20]
00007e55d47ce9c8  vmovaps xmm3, [rsp+0x30]
00007e55d47ce9ce  vmovaps xmm4, [rsp+0x40]
00007e55d47ce9d4  vmovaps xmm5, [rsp+0x50]
00007e55d47ce9da  vmovaps xmm6, [rsp+0x60]
00007e55d47ce9e0  vmovaps xmm7, [rsp+0x70]
00007e55d47ce9e6  vmovaps xmm8, [rsp+0x80]
00007e55d47ce9ef  vmovaps xmm9, [rsp+0x90]
00007e55d47ce9f8  vmovaps xmm10, [rsp+0xA0]
00007e55d47cea01  vmovaps xmm11, [rsp+0xB0]
00007e55d47cea0a  vmovaps xmm12, [rsp+0xC0]
00007e55d47cea13  vmovaps xmm14, [rsp+0xD0]
00007e55d47cea1c  vmovaps xmm15, [rsp+0xE0]
00007e55d47cea25  add rsp, 0xF0
00007e55d47cea2c  pop r11
00007e55d47cea2e  pop r10
00007e55d47cea30  pop r9
00007e55d47cea32  pop r8
00007e55d47cea34  pop rsi
00007e55d47cea35  pop rdi
00007e55d47cea36  pop rdx
00007e55d47cea37  pop rcx
00007e55d47cea38  pop rax
00007e55d47cea39  add rsp, 0x08
00007e55d47cea3d  jmp 0x00007E55D47CE81B
00007e55d47cea42  call 0x00007E55D460C380
00007e55d47cea47  jmp 0x00007E55D47CE82E
00007e55d47cea4c  sub rsp, 0x08
00007e55d47cea50  push rax
00007e55d47cea51  push rcx
00007e55d47cea52  push rdx
00007e55d47cea53  push rdi
00007e55d47cea54  push rsi
00007e55d47cea55  push r8
00007e55d47cea57  push r9
00007e55d47cea59  push r10
00007e55d47cea5b  push r11
00007e55d47cea5d  sub rsp, 0xF0
00007e55d47cea64  vmovaps [rsp], xmm0
00007e55d47cea69  vmovaps [rsp+0x10], xmm2
00007e55d47cea6f  vmovaps [rsp+0x20], xmm3
00007e55d47cea75  vmovaps [rsp+0x30], xmm4
00007e55d47cea7b  vmovaps [rsp+0x40], xmm5
00007e55d47cea81  vmovaps [rsp+0x50], xmm6
00007e55d47cea87  vmovaps [rsp+0x60], xmm7
00007e55d47cea8d  vmovaps [rsp+0x70], xmm8
00007e55d47cea93  vmovaps [rsp+0x80], xmm9
00007e55d47cea9c  vmovaps [rsp+0x90], xmm10
00007e55d47ceaa5  vmovaps [rsp+0xA0], xmm11
00007e55d47ceaae  vmovaps [rsp+0xB0], xmm12
00007e55d47ceab7  vmovaps [rsp+0xC0], xmm13
00007e55d47ceac0  vmovaps [rsp+0xD0], xmm14
00007e55d47ceac9  vmovaps [rsp+0xE0], xmm15
00007e55d47cead2  sub rsp, 0x30
00007e55d47cead6  movaps [rsp], xmm1
00007e55d47ceada  movaps [rsp+0x10], xmm14
00007e55d47ceae0  movaps [rsp+0x20], xmm15
00007e55d47ceae6  lea rdi, [rsp]
00007e55d47ceaea  mov esi, 0x00
00007e55d47ceaef  mov rax, 0x55D0734A4530
00007e55d47ceaf9  call rax
00007e55d47ceafb  movaps xmm1, [rsp]
00007e55d47ceaff  add rsp, 0x30
00007e55d47ceb03  vmovaps xmm0, [rsp]
00007e55d47ceb08  vmovaps xmm2, [rsp+0x10]
00007e55d47ceb0e  vmovaps xmm3, [rsp+0x20]
00007e55d47ceb14  vmovaps xmm4, [rsp+0x30]
00007e55d47ceb1a  vmovaps xmm5, [rsp+0x40]
00007e55d47ceb20  vmovaps xmm6, [rsp+0x50]
00007e55d47ceb26  vmovaps xmm7, [rsp+0x60]
00007e55d47ceb2c  vmovaps xmm8, [rsp+0x70]
00007e55d47ceb32  vmovaps xmm9, [rsp+0x80]
00007e55d47ceb3b  vmovaps xmm10, [rsp+0x90]
00007e55d47ceb44  vmovaps xmm11, [rsp+0xA0]
00007e55d47ceb4d  vmovaps xmm12, [rsp+0xB0]
00007e55d47ceb56  vmovaps xmm13, [rsp+0xC0]
00007e55d47ceb5f  vmovaps xmm14, [rsp+0xD0]
00007e55d47ceb68  vmovaps xmm15, [rsp+0xE0]
00007e55d47ceb71  add rsp, 0xF0
00007e55d47ceb78  pop r11
00007e55d47ceb7a  pop r10
00007e55d47ceb7c  pop r9
00007e55d47ceb7e  pop r8
00007e55d47ceb80  pop rsi
00007e55d47ceb81  pop rdi
00007e55d47ceb82  pop rdx
00007e55d47ceb83  pop rcx
00007e55d47ceb84  pop rax
00007e55d47ceb85  add rsp, 0x08
00007e55d47ceb89  jmp 0x00007E55D47CE848
00007e55d47ceb8e  call 0x00007E55D45FF540
00007e55d47ceb93  jmp 0x00007E55D47CE85B
00007e55d47ceb98  int3
00007e55d47ceb99  nop [rax], eax
00007e55d47ceba0  movaps xmm1, [r15+0x180]
00007e55d47ceba8  vpmovqd xmm15, xmm1
00007e55d47cebae  pxor xmm14, xmm14
00007e55d47cebb3  punpcklqdq xmm15, xmm14
00007e55d47cebb8  movaps [r15+0x210], xmm15
00007e55d47cebc0  movq xmm15, qword ptr [r15+0x120]
00007e55d47cebc9  movq xmm14, qword ptr [r15+0x130]
00007e55d47cebd2  psubd xmm15, xmm14
00007e55d47cebd7  movq xmm15, xmm15
00007e55d47cebdc  movaps xmm13, [r15+0x170]
00007e55d47cebe4  paddq xmm1, xmm13
00007e55d47cebe9  movaps [r15+0x180], xmm1
00007e55d47cebf1  movq xmm1, qword ptr [r15+0x150]
00007e55d47cebfa  paddd xmm14, xmm1
00007e55d47cebff  movq xmm14, xmm14
00007e55d47cec04  movq xmm14, xmm14
00007e55d47cec09  movaps [r15+0x130], xmm14
00007e55d47cec11  pmovzxdq xmm15, xmm15
00007e55d47cec17  psllq xmm15, 0x00
00007e55d47cec1d  movq xmm1, qword ptr [r15+0x210]
00007e55d47cec26  movq xmm14, qword ptr [r15+0x110]
00007e55d47cec2f  paddd xmm1, xmm14
00007e55d47cec34  movq xmm1, xmm1
00007e55d47cec38  vcvtuqq2pd xmm15, xmm15
00007e55d47cec3e  pmovzxdq xmm1, xmm1
00007e55d47cec43  psllq xmm1, 0x00
00007e55d47cec48  vcvtuqq2pd xmm1, xmm1
00007e55d47cec4e  movaps xmm14, [r15+0x140]
00007e55d47cec56  movaps xmm13, xmm15
00007e55d47cec5a  mulpd xmm13, xmm14
00007e55d47cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007e55d47cec65  ptest xmm12, xmm12
00007e55d47cec6b  jnz 0x00007E55D47CED4E
00007e55d47cec71  movaps [r15+0x220], xmm13
00007e55d47cec79  mov rax, [r15+0x48]
00007e55d47cec7d  mov r14, [r15+0x50]
00007e55d47cec81  lea r12, [r14+rax*1]
00007e55d47cec85  movups [r13+r12*1], xmm13
00007e55d47cec8b  movaps xmm15, [r15+0x160]
00007e55d47cec93  movaps xmm14, xmm1
00007e55d47cec97  mulpd xmm14, xmm15
00007e55d47cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007e55d47ceca2  ptest xmm13, xmm13
00007e55d47ceca8  jnz 0x00007E55D47CEE9C
00007e55d47cecae  movaps [r15+0x210], xmm14
00007e55d47cecb6  mov r14, [r15+0x40]
00007e55d47cecba  lea r12, [r14+rax*1]
00007e55d47cecbe  movups [r13+r12*1], xmm14
00007e55d47cecc4  lea r14, [rax+0x10]
00007e55d47cecc8  mov [r15+0x48], r14
00007e55d47ceccc  xor eax, eax
00007e55d47cecce  mov r12d, 0x200
00007e55d47cecd4  cmp r14, r12
00007e55d47cecd7  cmc
00007e55d47cecd8  lahf
00007e55d47cecd9  seto al
00007e55d47cecdc  mov [r15+0x108], eax
00007e55d47cece3  mov eax, [r15+0x108]
00007e55d47cecea  sahf
00007e55d47ceceb  jnz 0x00007E55D47CED1D
00007e55d47ceced  cmp dword ptr [r15+0x318], 0x00
00007e55d47cecf5  jz 0x00007E55D47CEFF0
00007e55d47cecfb  nop [rax+rax*1], ax
00007e55d47ced04  nop [rax+rax*1], eax
00007e55d47ced0c  mov eax, 0x4101EC
00007e55d47ced11  mov [r15+0x100], rax
00007e55d47ced18  jmp 0x00007E55D45FE110
00007e55d47ced1d  cmp dword ptr [r15+0x318], 0x00
00007e55d47ced25  jz 0x00007E55D47CEBA0
00007e55d47ced2b  nop [rax+rax*1], ax
00007e55d47ced34  nop [rax+rax*1], eax
00007e55d47ced3c  mov eax, 0x4101AC
00007e55d47ced41  mov [r15+0x100], rax
00007e55d47ced48  jmp 0x00007E55D45FE110
00007e55d47ced4d  int3
00007e55d47ced4e  sub rsp, 0x08
00007e55d47ced52  push rax
00007e55d47ced53  push rcx
00007e55d47ced54  push rdx
00007e55d47ced55  push rdi
00007e55d47ced56  push rsi
00007e55d47ced57  push r8
00007e55d47ced59  push r9
00007e55d47ced5b  push r10
00007e55d47ced5d  push r11
00007e55d47ced5f  sub rsp, 0xF0
00007e55d47ced66  vmovaps [rsp], xmm0
00007e55d47ced6b  vmovaps [rsp+0x10], xmm1
00007e55d47ced71  vmovaps [rsp+0x20], xmm2
00007e55d47ced77  vmovaps [rsp+0x30], xmm3
00007e55d47ced7d  vmovaps [rsp+0x40], xmm4
00007e55d47ced83  vmovaps [rsp+0x50], xmm5
00007e55d47ced89  vmovaps [rsp+0x60], xmm6
00007e55d47ced8f  vmovaps [rsp+0x70], xmm7
00007e55d47ced95  vmovaps [rsp+0x80], xmm8
00007e55d47ced9e  vmovaps [rsp+0x90], xmm9
00007e55d47ceda7  vmovaps [rsp+0xA0], xmm10
00007e55d47cedb0  vmovaps [rsp+0xB0], xmm11
00007e55d47cedb9  vmovaps [rsp+0xC0], xmm12
00007e55d47cedc2  vmovaps [rsp+0xD0], xmm14
00007e55d47cedcb  vmovaps [rsp+0xE0], xmm15
00007e55d47cedd4  sub rsp, 0x30
00007e55d47cedd8  movaps [rsp], xmm13
00007e55d47ceddd  movaps [rsp+0x10], xmm15
00007e55d47cede3  movaps [rsp+0x20], xmm14
00007e55d47cede9  lea rdi, [rsp]
00007e55d47ceded  mov esi, 0x00
00007e55d47cedf2  mov rax, 0x55D0734A4530
00007e55d47cedfc  call rax
00007e55d47cedfe  movaps xmm13, [rsp]
00007e55d47cee03  add rsp, 0x30
00007e55d47cee07  vmovaps xmm0, [rsp]
00007e55d47cee0c  vmovaps xmm1, [rsp+0x10]
00007e55d47cee12  vmovaps xmm2, [rsp+0x20]
00007e55d47cee18  vmovaps xmm3, [rsp+0x30]
00007e55d47cee1e  vmovaps xmm4, [rsp+0x40]
00007e55d47cee24  vmovaps xmm5, [rsp+0x50]
00007e55d47cee2a  vmovaps xmm6, [rsp+0x60]
00007e55d47cee30  vmovaps xmm7, [rsp+0x70]
00007e55d47cee36  vmovaps xmm8, [rsp+0x80]
00007e55d47cee3f  vmovaps xmm9, [rsp+0x90]
00007e55d47cee48  vmovaps xmm10, [rsp+0xA0]
00007e55d47cee51  vmovaps xmm11, [rsp+0xB0]
00007e55d47cee5a  vmovaps xmm12, [rsp+0xC0]
00007e55d47cee63  vmovaps xmm14, [rsp+0xD0]
00007e55d47cee6c  vmovaps xmm15, [rsp+0xE0]
00007e55d47cee75  add rsp, 0xF0
00007e55d47cee7c  pop r11
00007e55d47cee7e  pop r10
00007e55d47cee80  pop r9
00007e55d47cee82  pop r8
00007e55d47cee84  pop rsi
00007e55d47cee85  pop rdi
00007e55d47cee86  pop rdx
00007e55d47cee87  pop rcx
00007e55d47cee88  pop rax
00007e55d47cee89  add rsp, 0x08
00007e55d47cee8d  jmp 0x00007E55D47CEC71
00007e55d47cee92  call 0x00007E55D46C2240
00007e55d47cee97  jmp 0x00007E55D47CEC8B
00007e55d47cee9c  sub rsp, 0x08
00007e55d47ceea0  push rax
00007e55d47ceea1  push rcx
00007e55d47ceea2  push rdx
00007e55d47ceea3  push rdi
00007e55d47ceea4  push rsi
00007e55d47ceea5  push r8
00007e55d47ceea7  push r9
00007e55d47ceea9  push r10
00007e55d47ceeab  push r11
00007e55d47ceead  sub rsp, 0xF0
00007e55d47ceeb4  vmovaps [rsp], xmm0
00007e55d47ceeb9  vmovaps [rsp+0x10], xmm1
00007e55d47ceebf  vmovaps [rsp+0x20], xmm2
00007e55d47ceec5  vmovaps [rsp+0x30], xmm3
00007e55d47ceecb  vmovaps [rsp+0x40], xmm4
00007e55d47ceed1  vmovaps [rsp+0x50], xmm5
00007e55d47ceed7  vmovaps [rsp+0x60], xmm6
00007e55d47ceedd  vmovaps [rsp+0x70], xmm7
00007e55d47ceee3  vmovaps [rsp+0x80], xmm8
00007e55d47ceeec  vmovaps [rsp+0x90], xmm9
00007e55d47ceef5  vmovaps [rsp+0xA0], xmm10
00007e55d47ceefe  vmovaps [rsp+0xB0], xmm11
00007e55d47cef07  vmovaps [rsp+0xC0], xmm12
00007e55d47cef10  vmovaps [rsp+0xD0], xmm13
00007e55d47cef19  vmovaps [rsp+0xE0], xmm15
00007e55d47cef22  sub rsp, 0x30
00007e55d47cef26  movaps [rsp], xmm14
00007e55d47cef2b  movaps [rsp+0x10], xmm1
00007e55d47cef30  movaps [rsp+0x20], xmm15
00007e55d47cef36  lea rdi, [rsp]
00007e55d47cef3a  mov esi, 0x00
00007e55d47cef3f  mov rax, 0x55D0734A4530
00007e55d47cef49  call rax
00007e55d47cef4b  movaps xmm14, [rsp]
00007e55d47cef50  add rsp, 0x30
00007e55d47cef54  vmovaps xmm0, [rsp]
00007e55d47cef59  vmovaps xmm1, [rsp+0x10]
00007e55d47cef5f  vmovaps xmm2, [rsp+0x20]
00007e55d47cef65  vmovaps xmm3, [rsp+0x30]
00007e55d47cef6b  vmovaps xmm4, [rsp+0x40]
00007e55d47cef71  vmovaps xmm5, [rsp+0x50]
00007e55d47cef77  vmovaps xmm6, [rsp+0x60]
00007e55d47cef7d  vmovaps xmm7, [rsp+0x70]
00007e55d47cef83  vmovaps xmm8, [rsp+0x80]
00007e55d47cef8c  vmovaps xmm9, [rsp+0x90]
00007e55d47cef95  vmovaps xmm10, [rsp+0xA0]
00007e55d47cef9e  vmovaps xmm11, [rsp+0xB0]
00007e55d47cefa7  vmovaps xmm12, [rsp+0xC0]
00007e55d47cefb0  vmovaps xmm13, [rsp+0xD0]
00007e55d47cefb9  vmovaps xmm15, [rsp+0xE0]
00007e55d47cefc2  add rsp, 0xF0
00007e55d47cefc9  pop r11
00007e55d47cefcb  pop r10
00007e55d47cefcd  pop r9
00007e55d47cefcf  pop r8
00007e55d47cefd1  pop rsi
00007e55d47cefd2  pop rdi
00007e55d47cefd3  pop rdx
00007e55d47cefd4  pop rcx
00007e55d47cefd5  pop rax
00007e55d47cefd6  add rsp, 0x08
00007e55d47cefda  jmp 0x00007E55D47CECAE
00007e55d47cefdf  call 0x00007E55D46C34C0
00007e55d47cefe4  jmp 0x00007E55D47CECC4
00007e55d47cefe9  int3
00007e55d47cefea  nop [rax+rax*1], ax
00007e55d47ceff0  mov rax, [r15+0xF8]
00007e55d47ceff7  lea r14, [rax-0x150]
00007e55d47ceffe  mov [r15+0xF8], r14
00007e55d47cf005  mov rax, [r15+0x50]
00007e55d47cf009  lea r12, [rax+0x80]
00007e55d47cf010  movups xmm1, [r13+r12*1]
00007e55d47cf016  lea r12, [rax+0x90]
00007e55d47cf01d  movups xmm15, [r13+r12*1]
00007e55d47cf023  mov qword ptr [r15+0x48], 0x00
00007e55d47cf02b  lea r12, [rax+0x40]
00007e55d47cf02f  movups xmm14, [r13+r12*1]
00007e55d47cf035  lea r12, [rax+0x50]
00007e55d47cf039  movups xmm13, [r13+r12*1]
00007e55d47cf03f  lea r12, [r14+0x120]
00007e55d47cf046  movq xmm12, qword ptr [r15+0x1C0]
00007e55d47cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007e55d47cf058  movq r11, xmm12
00007e55d47cf05d  movq r10, xmm11
00007e55d47cf062  mov [r13+r12*1], r11
00007e55d47cf067  lea r12, [r14+0x128]
00007e55d47cf06e  mov [r13+r12*1], r10
00007e55d47cf073  vxorps xmm12, xmm12, xmm12
00007e55d47cf078  vpbroadcastq xmm12, xmm12
00007e55d47cf07d  lea r12, [r14+0x100]
00007e55d47cf084  movq xmm11, qword ptr [r15+0x200]
00007e55d47cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007e55d47cf096  movq r11, xmm11
00007e55d47cf09b  movq r10, xmm10
00007e55d47cf0a0  mov [r13+r12*1], r11
00007e55d47cf0a5  lea r12, [r14+0x108]
00007e55d47cf0ac  mov [r13+r12*1], r10
00007e55d47cf0b1  lea r12, [r14+0xE0]
00007e55d47cf0b8  movups [r13+r12*1], xmm15
00007e55d47cf0be  lea r12, [r14+0xF0]
00007e55d47cf0c5  movups [r13+r12*1], xmm1
00007e55d47cf0cb  lea r12, [rax+0xC0]
00007e55d47cf0d2  movups xmm1, [r13+r12*1]
00007e55d47cf0d8  lea r12, [rax+0xD0]
00007e55d47cf0df  movups xmm15, [r13+r12*1]
00007e55d47cf0e5  lea r12, [r14+0x110]
00007e55d47cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007e55d47cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007e55d47cf0fe  movq r11, xmm11
00007e55d47cf103  movq r10, xmm10
00007e55d47cf108  mov [r13+r12*1], r11
00007e55d47cf10d  lea r12, [r14+0x118]
00007e55d47cf114  mov [r13+r12*1], r10
00007e55d47cf119  movups xmm11, [r13+rax*1]
00007e55d47cf11f  lea r12, [rax+0x10]
00007e55d47cf123  movups xmm10, [r13+r12*1]
00007e55d47cf129  lea r12, [r14+0x130]
00007e55d47cf130  movq xmm9, qword ptr [r15+0x1A0]
00007e55d47cf139  movq xmm8, qword ptr [r15+0x190]
00007e55d47cf142  movq r11, xmm9
00007e55d47cf147  movq r10, xmm8
00007e55d47cf14c  mov [r13+r12*1], r11
00007e55d47cf151  lea r12, [r14+0x138]
00007e55d47cf158  mov [r13+r12*1], r10
00007e55d47cf15d  lea r12, [rax+0x140]
00007e55d47cf164  movups xmm9, [r13+r12*1]
00007e55d47cf16a  lea r12, [rax+0x150]
00007e55d47cf171  movups xmm8, [r13+r12*1]
00007e55d47cf177  lea r12, [r14+0xC0]
00007e55d47cf17e  movups [r13+r12*1], xmm15
00007e55d47cf184  lea r12, [r14+0xD0]
00007e55d47cf18b  movups [r13+r12*1], xmm1
00007e55d47cf191  lea r12, [rax+0x100]
00007e55d47cf198  movups xmm1, [r13+r12*1]
00007e55d47cf19e  lea r12, [rax+0x110]
00007e55d47cf1a5  movups xmm15, [r13+r12*1]
00007e55d47cf1ab  lea r12, [r14+0x140]
00007e55d47cf1b2  mov r11, [r15+0xE8]
00007e55d47cf1b9  mov [r13+r12*1], r11
00007e55d47cf1be  lea r12, [rax+0x180]
00007e55d47cf1c5  movups xmm7, [r13+r12*1]
00007e55d47cf1cb  lea r12, [rax+0x190]
00007e55d47cf1d2  movups xmm6, [r13+r12*1]
00007e55d47cf1d8  lea r12, [rax+0x1C0]
00007e55d47cf1df  movups xmm5, [r13+r12*1]
00007e55d47cf1e5  lea r12, [rax+0x1D0]
00007e55d47cf1ec  movups xmm4, [r13+r12*1]
00007e55d47cf1f2  lea r12, [r14+0x20]
00007e55d47cf1f6  movups [r13+r12*1], xmm1
00007e55d47cf1fc  lea r12, [r14+0x30]
00007e55d47cf200  movups [r13+r12*1], xmm13
00007e55d47cf206  lea r12, [rax+0x60]
00007e55d47cf20a  movups xmm1, [r13+r12*1]
00007e55d47cf210  lea r12, [rax+0x70]
00007e55d47cf214  movups xmm13, [r13+r12*1]
00007e55d47cf21a  lea r12, [rax+0x20]
00007e55d47cf21e  movups xmm3, [r13+r12*1]
00007e55d47cf224  lea r12, [rax+0x30]
00007e55d47cf228  movups xmm2, [r13+r12*1]
00007e55d47cf22e  movaps [r15+0x1F0], xmm2
00007e55d47cf236  lea r12, [r14+0x60]
00007e55d47cf23a  movups [r13+r12*1], xmm11
00007e55d47cf240  lea r12, [r14+0x70]
00007e55d47cf244  movups [r13+r12*1], xmm5
00007e55d47cf24a  lea r12, [rax+0xE0]
00007e55d47cf251  movups xmm11, [r13+r12*1]
00007e55d47cf257  lea r12, [rax+0xF0]
00007e55d47cf25e  movups xmm5, [r13+r12*1]
00007e55d47cf264  lea r12, [r14+0xA0]
00007e55d47cf26b  movups [r13+r12*1], xmm13
00007e55d47cf271  lea r12, [r14+0xB0]
00007e55d47cf278  movups [r13+r12*1], xmm1
00007e55d47cf27e  lea r12, [rax+0xA0]
00007e55d47cf285  movups xmm1, [r13+r12*1]
00007e55d47cf28b  lea r12, [rax+0xB0]
00007e55d47cf292  movups xmm13, [r13+r12*1]
00007e55d47cf298  lea r12, [rax+0x120]
00007e55d47cf29f  vmovaps [rsp+0x10], xmm1
00007e55d47cf2a5  movups xmm1, [r13+r12*1]
00007e55d47cf2ab  lea r12, [rax+0x130]
00007e55d47cf2b2  vmovaps [rsp+0x20], xmm1
00007e55d47cf2b8  movups xmm1, [r13+r12*1]
00007e55d47cf2be  lea r12, [rax+0x160]
00007e55d47cf2c5  vmovaps [rsp+0x30], xmm1
00007e55d47cf2cb  movups xmm1, [r13+r12*1]
00007e55d47cf2d1  lea r12, [rax+0x170]
00007e55d47cf2d8  vmovaps [rsp+0x40], xmm1
00007e55d47cf2de  movups xmm1, [r13+r12*1]
00007e55d47cf2e4  movaps [r15+0x2B0], xmm1
00007e55d47cf2ec  lea r12, [r14+0x80]
00007e55d47cf2f3  movups [r13+r12*1], xmm13
00007e55d47cf2f9  lea r12, [r14+0x90]
00007e55d47cf300  vmovaps xmm13, [rsp+0x10]
00007e55d47cf306  movups [r13+r12*1], xmm13
00007e55d47cf30c  lea r12, [rax+0x1A0]
00007e55d47cf313  movups xmm13, [r13+r12*1]
00007e55d47cf319  lea r12, [rax+0x1B0]
00007e55d47cf320  vmovaps [rsp+0x10], xmm1
00007e55d47cf326  movups xmm1, [r13+r12*1]
00007e55d47cf32c  movaps [r15+0x290], xmm13
00007e55d47cf334  movaps [r15+0x1E0], xmm1
00007e55d47cf33c  lea r12, [rax+0x1E0]
00007e55d47cf343  vmovaps [rsp+0x50], xmm1
00007e55d47cf349  movups xmm1, [r13+r12*1]
00007e55d47cf34f  lea r12, [rax+0x1F0]
00007e55d47cf356  vmovaps [rsp+0x60], xmm1
00007e55d47cf35c  movups xmm1, [r13+r12*1]
00007e55d47cf362  mov qword ptr [r15+0x50], 0x430920
00007e55d47cf36a  lea rax, [r14+0x40]
00007e55d47cf36e  vmovaps [rsp+0x70], xmm1
00007e55d47cf374  vmovaps xmm1, [rsp+0x40]
00007e55d47cf37a  movups [r13+rax*1], xmm1
00007e55d47cf380  lea rax, [r14+0x50]
00007e55d47cf384  movups [r13+rax*1], xmm10
00007e55d47cf38a  vmovaps xmm1, [rsp+0x70]
00007e55d47cf390  movups [r13+r14*1], xmm1
00007e55d47cf396  lea rax, [r14+0x10]
00007e55d47cf39a  vmovaps xmm1, [rsp+0x60]
00007e55d47cf3a0  movups [r13+rax*1], xmm1
00007e55d47cf3a6  mov rax, [r15+0x40]
00007e55d47cf3aa  vmovaps [rsp+0x40], xmm3
00007e55d47cf3b0  vmovaps xmm1, [rsp+0x40]
00007e55d47cf3b6  por xmm3, xmm1
00007e55d47cf3ba  vmovaps [rsp+0x40], xmm6
00007e55d47cf3c0  vmovaps xmm10, [rsp+0x40]
00007e55d47cf3c6  por xmm6, xmm10
00007e55d47cf3cb  lea r12, [rax+0x30]
00007e55d47cf3cf  mov r11, [r13+r12*1]
00007e55d47cf3d4  lea r12, [rax+0x38]
00007e55d47cf3d8  mov r10, [r13+r12*1]
00007e55d47cf3dd  movq xmm10, r11
00007e55d47cf3e2  vmovaps [rsp+0x40], xmm1
00007e55d47cf3e8  movq xmm1, r10
00007e55d47cf3ed  movq xmm10, xmm10
00007e55d47cf3f2  vmovaps [rsp+0x60], xmm10
00007e55d47cf3f8  movq xmm10, xmm10
00007e55d47cf3fd  movaps [r15+0x130], xmm10
00007e55d47cf405  movq xmm1, xmm1
00007e55d47cf409  vmovaps [rsp+0x70], xmm1
00007e55d47cf40f  movq xmm1, xmm1
00007e55d47cf413  movaps [r15+0x280], xmm1
00007e55d47cf41b  vmovaps [rsp+0x80], xmm9
00007e55d47cf424  vmovaps xmm1, [rsp+0x80]
00007e55d47cf42d  por xmm9, xmm1
00007e55d47cf432  lea r12, [rax+0x20]
00007e55d47cf436  mov r11, [r13+r12*1]
00007e55d47cf43b  lea r12, [rax+0x28]
00007e55d47cf43f  mov r10, [r13+r12*1]
00007e55d47cf444  movq xmm1, r11
00007e55d47cf449  movq xmm10, r10
00007e55d47cf44e  movq xmm1, xmm1
00007e55d47cf452  vmovaps [rsp+0x80], xmm1
00007e55d47cf45b  movq xmm1, xmm1
00007e55d47cf45f  movaps [r15+0x150], xmm1
00007e55d47cf467  movq xmm10, xmm10
00007e55d47cf46c  vmovaps [rsp+0x90], xmm10
00007e55d47cf475  movq xmm10, xmm10
00007e55d47cf47a  movaps [r15+0x140], xmm10
00007e55d47cf482  lea r12, [rax+0x10]
00007e55d47cf486  mov r11, [r13+r12*1]
00007e55d47cf48b  lea r12, [rax+0x18]
00007e55d47cf48f  mov r10, [r13+r12*1]
00007e55d47cf494  movq xmm1, r11
00007e55d47cf499  movq xmm10, r10
00007e55d47cf49e  movq xmm1, xmm1
00007e55d47cf4a2  vmovaps [rsp+0xA0], xmm1
00007e55d47cf4ab  movq xmm1, xmm1
00007e55d47cf4af  movaps [r15+0x170], xmm1
00007e55d47cf4b7  movq xmm10, xmm10
00007e55d47cf4bc  vmovaps [rsp+0xB0], xmm10
00007e55d47cf4c5  movq xmm10, xmm10
00007e55d47cf4ca  movaps [r15+0x160], xmm10
00007e55d47cf4d2  mov r12, [r13+rax*1]
00007e55d47cf4d7  vmovq xmm1, r12
00007e55d47cf4dc  vpbroadcastq xmm1, xmm1
00007e55d47cf4e1  lea r12, [rax+0x08]
00007e55d47cf4e5  mov rax, [r13+r12*1]
00007e55d47cf4ea  movq xmm10, rax
00007e55d47cf4ef  movaps [r15+0x230], xmm10
00007e55d47cf4f7  lea rax, [r14+0x50]
00007e55d47cf4fb  movups xmm10, [r13+rax*1]
00007e55d47cf501  lea rax, [r14+0x60]
00007e55d47cf505  vmovaps [rsp+0xC0], xmm1
00007e55d47cf50e  movups xmm1, [r13+rax*1]
00007e55d47cf514  lea rax, [r14+0x30]
00007e55d47cf518  vmovaps [rsp+0xD0], xmm1
00007e55d47cf521  movups xmm1, [r13+rax*1]
00007e55d47cf527  mov qword ptr [r15+0x60], 0x430920
00007e55d47cf52f  mov qword ptr [r15+0x58], 0x40
00007e55d47cf537  vmovaps [rsp+0xE0], xmm1
00007e55d47cf540  vmovaps [rsp+0xF0], xmm15
00007e55d47cf549  vmovaps xmm15, [rsp+0xC0]
00007e55d47cf552  vmovaps [rsp+0xC0], xmm14
00007e55d47cf55b  vmovaps xmm14, [rsp+0x40]
00007e55d47cf561  vmovaps [rsp+0x40], xmm13
00007e55d47cf567  movaps xmm1, xmm15
00007e55d47cf56b  mulpd xmm1, xmm14
00007e55d47cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007e55d47cf575  ptest xmm13, xmm13
00007e55d47cf57b  jnz 0x00007E55D47D0682
00007e55d47cf581  movq xmm14, qword ptr [r15+0x230]
00007e55d47cf58a  vmovaps [rsp+0x100], xmm14
00007e55d47cf593  vpermilpd xmm14, xmm14, 0x00
00007e55d47cf599  vmovaps [rsp+0x110], xmm1
00007e55d47cf5a2  vmovaps xmm1, [rsp+0xE0]
00007e55d47cf5ab  vmovaps [rsp+0xE0], xmm15
00007e55d47cf5b4  movaps xmm13, xmm1
00007e55d47cf5b8  mulpd xmm13, xmm14
00007e55d47cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007e55d47cf5c3  ptest xmm15, xmm15
00007e55d47cf5c9  jnz 0x00007E55D47D07C4
00007e55d47cf5cf  vxorps xmm1, xmm1, xmm1
00007e55d47cf5d3  vpbroadcastq xmm1, xmm1
00007e55d47cf5d8  vmovaps xmm14, [rsp+0xE0]
00007e55d47cf5e1  vmovaps [rsp+0xE0], xmm1
00007e55d47cf5ea  vmovaps xmm1, [rsp+0xD0]
00007e55d47cf5f3  vmovaps [rsp+0xD0], xmm13
00007e55d47cf5fc  movaps xmm15, xmm14
00007e55d47cf600  mulpd xmm15, xmm1
00007e55d47cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007e55d47cf60b  ptest xmm13, xmm13
00007e55d47cf611  jnz 0x00007E55D47D0907
00007e55d47cf617  movaps xmm1, xmm14
00007e55d47cf61b  mulpd xmm1, xmm10
00007e55d47cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007e55d47cf625  ptest xmm13, xmm13
00007e55d47cf62b  jnz 0x00007E55D47D0A4A
00007e55d47cf631  movaps xmm13, xmm14
00007e55d47cf635  mulpd xmm13, xmm2
00007e55d47cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007e55d47cf640  ptest xmm10, xmm10
00007e55d47cf646  jnz 0x00007E55D47D0B8C
00007e55d47cf64c  vmovaps [rsp+0x120], xmm7
00007e55d47cf655  vmovaps xmm14, [rsp+0x120]
00007e55d47cf65e  por xmm7, xmm14
00007e55d47cf663  vmovaps xmm14, [rsp+0xC0]
00007e55d47cf66c  vmovaps xmm10, [rsp+0xC0]
00007e55d47cf675  por xmm14, xmm10
00007e55d47cf67a  vmovaps xmm2, [rsp+0x100]
00007e55d47cf683  vpermilpd xmm2, xmm2, 0x00
00007e55d47cf689  vmovaps [rsp+0xC0], xmm1
00007e55d47cf692  vmovaps [rsp+0x120], xmm15
00007e55d47cf69b  movaps xmm1, xmm10
00007e55d47cf69f  mulpd xmm1, xmm2
00007e55d47cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007e55d47cf6a8  ptest xmm15, xmm15
00007e55d47cf6ae  jnz 0x00007E55D47D0CCF
00007e55d47cf6b4  xor eax, eax
00007e55d47cf6b6  mov r12d, 0x40
00007e55d47cf6bc  mov r11d, 0x200
00007e55d47cf6c2  cmp r12, r11
00007e55d47cf6c5  cmc
00007e55d47cf6c6  lahf
00007e55d47cf6c7  seto al
00007e55d47cf6ca  mov [r15+0x108], eax
00007e55d47cf6d1  vmovaps xmm10, [rsp+0x110]
00007e55d47cf6da  vmovaps xmm2, [rsp+0xE0]
00007e55d47cf6e3  vmovaps [rsp+0xE0], xmm1
00007e55d47cf6ec  movaps xmm15, xmm10
00007e55d47cf6f0  addpd xmm15, xmm2
00007e55d47cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e55d47cf6fb  ptest xmm1, xmm1
00007e55d47cf700  jnz 0x00007E55D47D0E10
00007e55d47cf706  vmovaps xmm10, [rsp+0x120]
00007e55d47cf70f  vmovaps [rsp+0x110], xmm15
00007e55d47cf718  movaps xmm1, xmm10
00007e55d47cf71c  addpd xmm1, xmm12
00007e55d47cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007e55d47cf726  ptest xmm15, xmm15
00007e55d47cf72c  jnz 0x00007E55D47D0F53
00007e55d47cf732  vmovaps xmm10, [rsp+0xC0]
00007e55d47cf73b  vmovaps [rsp+0xC0], xmm1
00007e55d47cf744  movaps xmm15, xmm10
00007e55d47cf748  addpd xmm15, xmm12
00007e55d47cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007e55d47cf753  ptest xmm1, xmm1
00007e55d47cf758  jnz 0x00007E55D47D1095
00007e55d47cf75e  vmovaps xmm1, [rsp+0x30]
00007e55d47cf764  vmovaps xmm12, [rsp+0x30]
00007e55d47cf76a  por xmm1, xmm12
00007e55d47cf76f  vmovaps xmm12, [rsp+0x20]
00007e55d47cf775  vmovaps xmm10, [rsp+0x20]
00007e55d47cf77b  por xmm12, xmm10
00007e55d47cf780  vmovaps [rsp+0x20], xmm5
00007e55d47cf786  vmovaps xmm10, [rsp+0x20]
00007e55d47cf78c  por xmm5, xmm10
00007e55d47cf791  vmovaps [rsp+0x20], xmm11
00007e55d47cf797  vmovaps xmm10, [rsp+0x20]
00007e55d47cf79d  por xmm11, xmm10
00007e55d47cf7a2  vmovaps [rsp+0x20], xmm4
00007e55d47cf7a8  vmovaps xmm10, [rsp+0x20]
00007e55d47cf7ae  por xmm4, xmm10
00007e55d47cf7b3  vmovaps [rsp+0x20], xmm8
00007e55d47cf7b9  vmovaps xmm10, [rsp+0x20]
00007e55d47cf7bf  por xmm8, xmm10
00007e55d47cf7c4  vmovaps xmm10, [rsp+0xF0]
00007e55d47cf7cd  vmovaps [rsp+0x20], xmm1
00007e55d47cf7d3  vmovaps xmm1, [rsp+0xF0]
00007e55d47cf7dc  por xmm10, xmm1
00007e55d47cf7e1  lea rax, [r14+0xA0]
00007e55d47cf7e8  movups xmm1, [r13+rax*1]
00007e55d47cf7ee  lea rax, [r14+0xB0]
00007e55d47cf7f5  vmovaps [rsp+0x30], xmm1
00007e55d47cf7fb  movups xmm1, [r13+rax*1]
00007e55d47cf801  vmovaps [rsp+0xF0], xmm1
00007e55d47cf80a  vmovaps [rsp+0x120], xmm15
00007e55d47cf813  movaps xmm1, xmm13
00007e55d47cf817  addpd xmm1, xmm2
00007e55d47cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007e55d47cf820  ptest xmm15, xmm15
00007e55d47cf826  jnz 0x00007E55D47D11ED
00007e55d47cf82c  lea rax, [r14+0xF0]
00007e55d47cf833  movups xmm15, [r13+rax*1]
00007e55d47cf839  vmovaps xmm2, [rsp+0xC0]
00007e55d47cf842  vmovaps [rsp+0xC0], xmm1
00007e55d47cf84b  vmovaps xmm1, [rsp+0xE0]
00007e55d47cf854  vmovaps [rsp+0xE0], xmm15
00007e55d47cf85d  movaps xmm13, xmm2
00007e55d47cf861  addpd xmm13, xmm1
00007e55d47cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007e55d47cf86c  ptest xmm15, xmm15
00007e55d47cf872  jnz 0x00007E55D47D1338
00007e55d47cf878  vmovaps xmm15, [rsp+0x120]
00007e55d47cf881  vmovaps xmm2, [rsp+0xD0]
00007e55d47cf88a  vmovaps [rsp+0xD0], xmm14
00007e55d47cf893  movaps xmm1, xmm15
00007e55d47cf897  addpd xmm1, xmm2
00007e55d47cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007e55d47cf8a0  ptest xmm14, xmm14
00007e55d47cf8a6  jnz 0x00007E55D47D147A
00007e55d47cf8ac  vmovaps xmm15, [rsp+0x100]
00007e55d47cf8b5  vpermilpd xmm15, xmm15, 0x00
00007e55d47cf8bb  vmovaps xmm2, [rsp+0xF0]
00007e55d47cf8c4  vmovaps [rsp+0xF0], xmm1
00007e55d47cf8cd  movaps xmm14, xmm2
00007e55d47cf8d1  mulpd xmm14, xmm15
00007e55d47cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007e55d47cf8dc  ptest xmm1, xmm1
00007e55d47cf8e1  jnz 0x00007E55D47D15BB
00007e55d47cf8e7  vmovaps xmm1, [rsp+0xA0]
00007e55d47cf8f0  vpermilpd xmm1, xmm1, 0x00
00007e55d47cf8f6  vmovaps xmm2, [rsp+0xE0]
00007e55d47cf8ff  vmovaps [rsp+0xE0], xmm14
00007e55d47cf908  movaps xmm15, xmm2
00007e55d47cf90c  mulpd xmm15, xmm1
00007e55d47cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007e55d47cf917  ptest xmm14, xmm14
00007e55d47cf91d  jnz 0x00007E55D47D16FE
00007e55d47cf923  lea rax, [r14+0xE0]
00007e55d47cf92a  movups xmm1, [r13+rax*1]
00007e55d47cf930  vmovaps xmm14, [rsp+0x100]
00007e55d47cf939  vpermilpd xmm14, xmm14, 0x00
00007e55d47cf93f  vmovaps [rsp+0x100], xmm1
00007e55d47cf948  vmovaps xmm1, [rsp+0x30]
00007e55d47cf94e  vmovaps [rsp+0x30], xmm15
00007e55d47cf954  movaps xmm2, xmm1
00007e55d47cf957  mulpd xmm2, xmm14
00007e55d47cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007e55d47cf961  ptest xmm15, xmm15
00007e55d47cf967  jnz 0x00007E55D47D184A
00007e55d47cf96d  vmovaps [rsp+0x120], xmm10
00007e55d47cf976  vmovaps xmm1, [rsp+0x120]
00007e55d47cf97f  por xmm10, xmm1
00007e55d47cf984  movaps [r15+0x300], xmm10
00007e55d47cf98c  vmovaps [rsp+0x120], xmm8
00007e55d47cf995  vmovaps xmm1, [rsp+0x120]
00007e55d47cf99e  por xmm8, xmm1
00007e55d47cf9a3  movaps [r15+0x190], xmm8
00007e55d47cf9ab  vmovaps xmm1, [rsp+0xA0]
00007e55d47cf9b4  vpermilpd xmm1, xmm1, 0x00
00007e55d47cf9ba  vmovaps xmm14, [rsp+0x100]
00007e55d47cf9c3  vmovaps [rsp+0x100], xmm13
00007e55d47cf9cc  movaps xmm15, xmm14
00007e55d47cf9d0  mulpd xmm15, xmm1
00007e55d47cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007e55d47cf9db  ptest xmm13, xmm13
00007e55d47cf9e1  jnz 0x00007E55D47D198B
00007e55d47cf9e7  lea rax, [r14+0x90]
00007e55d47cf9ee  movups xmm1, [r13+rax*1]
00007e55d47cf9f4  vmovaps [rsp+0x120], xmm4
00007e55d47cf9fd  vmovaps xmm14, [rsp+0x120]
00007e55d47cfa06  por xmm4, xmm14
00007e55d47cfa0b  movaps [r15+0x1C0], xmm4
00007e55d47cfa13  vmovaps [rsp+0x120], xmm11
00007e55d47cfa1c  vmovaps xmm14, [rsp+0x120]
00007e55d47cfa25  por xmm11, xmm14
00007e55d47cfa2a  movaps [r15+0x200], xmm11
00007e55d47cfa32  vmovaps [rsp+0x120], xmm5
00007e55d47cfa3b  vmovaps xmm14, [rsp+0x120]
00007e55d47cfa44  por xmm5, xmm14
00007e55d47cfa49  movaps [r15+0x2D0], xmm5
00007e55d47cfa51  vmovaps [rsp+0x120], xmm12
00007e55d47cfa5a  vmovaps xmm14, [rsp+0x120]
00007e55d47cfa63  por xmm12, xmm14
00007e55d47cfa68  movaps [r15+0x2E0], xmm12
00007e55d47cfa70  vmovaps xmm13, [rsp+0x110]
00007e55d47cfa79  vmovaps [rsp+0x110], xmm1
00007e55d47cfa82  vmovaps xmm1, [rsp+0xE0]
00007e55d47cfa8b  vmovaps [rsp+0xE0], xmm15
00007e55d47cfa94  movaps xmm14, xmm13
00007e55d47cfa98  addpd xmm14, xmm1
00007e55d47cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007e55d47cfaa3  ptest xmm15, xmm15
00007e55d47cfaa9  jnz 0x00007E55D47D1AD8
00007e55d47cfaaf  vmovaps xmm1, [rsp+0xA0]
00007e55d47cfab8  vpermilpd xmm1, xmm1, 0x00
00007e55d47cfabe  vmovaps xmm13, [rsp+0x110]
00007e55d47cfac7  vmovaps [rsp+0x110], xmm14
00007e55d47cfad0  movaps xmm15, xmm13
00007e55d47cfad4  mulpd xmm15, xmm1
00007e55d47cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007e55d47cfadf  ptest xmm14, xmm14
00007e55d47cfae5  jnz 0x00007E55D47D1C1B
00007e55d47cfaeb  lea rax, [r14+0x80]
00007e55d47cfaf2  movups xmm1, [r13+rax*1]
00007e55d47cfaf8  vmovaps xmm13, [rsp+0xC0]
00007e55d47cfb01  vmovaps [rsp+0xC0], xmm1
00007e55d47cfb0a  movaps xmm14, xmm13
00007e55d47cfb0e  addpd xmm14, xmm2
00007e55d47cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007e55d47cfb19  ptest xmm1, xmm1
00007e55d47cfb1e  jnz 0x00007E55D47D1D68
00007e55d47cfb24  vmovaps xmm13, [rsp+0x100]
00007e55d47cfb2d  vmovaps xmm2, [rsp+0x30]
00007e55d47cfb33  vmovaps [rsp+0x30], xmm15
00007e55d47cfb39  movaps xmm1, xmm13
00007e55d47cfb3d  addpd xmm1, xmm2
00007e55d47cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007e55d47cfb46  ptest xmm15, xmm15
00007e55d47cfb4c  jnz 0x00007E55D47D1EAB
00007e55d47cfb52  vmovaps xmm15, [rsp+0x20]
00007e55d47cfb58  vmovaps xmm13, [rsp+0x20]
00007e55d47cfb5e  por xmm15, xmm13
00007e55d47cfb63  movaps [r15+0x2F0], xmm15
00007e55d47cfb6b  vmovaps xmm13, [rsp+0xA0]
00007e55d47cfb74  vpermilpd xmm13, xmm13, 0x00
00007e55d47cfb7a  vmovaps [rsp+0x20], xmm1
00007e55d47cfb80  vmovaps xmm1, [rsp+0xC0]
00007e55d47cfb89  vmovaps [rsp+0xA0], xmm15
00007e55d47cfb92  movaps xmm2, xmm1
00007e55d47cfb95  mulpd xmm2, xmm13
00007e55d47cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007e55d47cfb9f  ptest xmm15, xmm15
00007e55d47cfba5  jnz 0x00007E55D47D1FEC
00007e55d47cfbab  lea rax, [r14+0xD0]
00007e55d47cfbb2  movups xmm1, [r13+rax*1]
00007e55d47cfbb8  vmovaps xmm13, [rsp+0xF0]
00007e55d47cfbc1  vmovaps [rsp+0xC0], xmm1
00007e55d47cfbca  vmovaps xmm1, [rsp+0xE0]
00007e55d47cfbd3  vmovaps [rsp+0xE0], xmm14
00007e55d47cfbdc  movaps xmm15, xmm13
00007e55d47cfbe0  addpd xmm15, xmm1
00007e55d47cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007e55d47cfbeb  ptest xmm14, xmm14
00007e55d47cfbf1  jnz 0x00007E55D47D2137
00007e55d47cfbf7  vmovaps xmm1, [rsp+0xB0]
00007e55d47cfc00  vpermilpd xmm1, xmm1, 0x00
00007e55d47cfc06  movaps xmm14, xmm11
00007e55d47cfc0a  mulpd xmm14, xmm1
00007e55d47cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007e55d47cfc15  ptest xmm13, xmm13
00007e55d47cfc1b  jnz 0x00007E55D47D227A
00007e55d47cfc21  movaps [r15+0x260], xmm14
00007e55d47cfc29  vxorps xmm1, xmm1, xmm1
00007e55d47cfc2d  vpbroadcastq xmm1, xmm1
00007e55d47cfc32  movaps [r15+0x1B0], xmm1
00007e55d47cfc3a  vmovaps xmm1, [rsp+0xB0]
00007e55d47cfc43  vpermilpd xmm1, xmm1, 0x00
00007e55d47cfc49  vmovaps xmm11, [rsp+0xC0]
00007e55d47cfc52  vmovaps [rsp+0xC0], xmm15
00007e55d47cfc5b  movaps xmm13, xmm11
00007e55d47cfc5f  mulpd xmm13, xmm1
00007e55d47cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007e55d47cfc6a  ptest xmm15, xmm15
00007e55d47cfc70  jnz 0x00007E55D47D23BD
00007e55d47cfc76  lea rax, [r14+0xC0]
00007e55d47cfc7d  movups xmm1, [r13+rax*1]
00007e55d47cfc83  vmovaps xmm11, [rsp+0x110]
00007e55d47cfc8c  vmovaps [rsp+0xF0], xmm1
00007e55d47cfc95  vmovaps xmm1, [rsp+0x30]
00007e55d47cfc9b  vmovaps [rsp+0x30], xmm14
00007e55d47cfca1  movaps xmm15, xmm11
00007e55d47cfca5  addpd xmm15, xmm1
00007e55d47cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007e55d47cfcb0  ptest xmm14, xmm14
00007e55d47cfcb6  jnz 0x00007E55D47D250A
00007e55d47cfcbc  vmovaps [rsp+0x100], xmm9
00007e55d47cfcc5  vmovaps xmm1, [rsp+0x100]
00007e55d47cfcce  por xmm9, xmm1
00007e55d47cfcd3  movaps [r15+0x270], xmm9
00007e55d47cfcdb  vmovaps [rsp+0x100], xmm6
00007e55d47cfce4  vmovaps xmm1, [rsp+0x100]
00007e55d47cfced  por xmm6, xmm1
00007e55d47cfcf1  movaps [r15+0x1A0], xmm6
00007e55d47cfcf9  vmovaps xmm14, [rsp+0xB0]
00007e55d47cfd02  vpermilpd xmm14, xmm14, 0x00
00007e55d47cfd08  vmovaps xmm6, [rsp+0xF0]
00007e55d47cfd11  vmovaps [rsp+0xF0], xmm1
00007e55d47cfd1a  movaps xmm11, xmm6
00007e55d47cfd1e  mulpd xmm11, xmm14
00007e55d47cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007e55d47cfd29  ptest xmm1, xmm1
00007e55d47cfd2e  jnz 0x00007E55D47D264D
00007e55d47cfd34  lea rax, [r14+0x20]
00007e55d47cfd38  movups xmm1, [r13+rax*1]
00007e55d47cfd3e  movaps [r15+0x110], xmm1
00007e55d47cfd46  vmovaps xmm6, [rsp+0xE0]
00007e55d47cfd4f  vmovaps [rsp+0xE0], xmm1
00007e55d47cfd58  movaps xmm14, xmm6
00007e55d47cfd5c  addpd xmm14, xmm2
00007e55d47cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007e55d47cfd67  ptest xmm1, xmm1
00007e55d47cfd6c  jnz 0x00007E55D47D279A
00007e55d47cfd72  vmovaps xmm1, [rsp+0xB0]
00007e55d47cfd7b  vpermilpd xmm1, xmm1, 0x00
00007e55d47cfd81  movaps xmm6, xmm5
00007e55d47cfd84  mulpd xmm6, xmm1
00007e55d47cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007e55d47cfd8d  ptest xmm2, xmm2
00007e55d47cfd92  jnz 0x00007E55D47D28DC
00007e55d47cfd98  vmovaps xmm5, [rsp+0x20]
00007e55d47cfd9e  movaps xmm1, xmm5
00007e55d47cfda1  addpd xmm1, xmm13
00007e55d47cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007e55d47cfdab  ptest xmm2, xmm2
00007e55d47cfdb0  jnz 0x00007E55D47D2A1C
00007e55d47cfdb6  vmovaps xmm13, [rsp+0x80]
00007e55d47cfdbf  vpermilpd xmm13, xmm13, 0x00
00007e55d47cfdc5  vmovaps xmm2, [rsp+0xE0]
00007e55d47cfdce  vmovaps [rsp+0x20], xmm1
00007e55d47cfdd4  movaps xmm5, xmm2
00007e55d47cfdd7  mulpd xmm5, xmm13
00007e55d47cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007e55d47cfde1  ptest xmm1, xmm1
00007e55d47cfde6  jnz 0x00007E55D47D2B5D
00007e55d47cfdec  vmovaps xmm1, [rsp+0x80]
00007e55d47cfdf5  vpermilpd xmm1, xmm1, 0x00
00007e55d47cfdfb  movaps xmm13, xmm10
00007e55d47cfdff  mulpd xmm13, xmm1
00007e55d47cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007e55d47cfe0a  ptest xmm2, xmm2
00007e55d47cfe0f  jnz 0x00007E55D47D2C9E
00007e55d47cfe15  vmovaps xmm10, [rsp+0x30]
00007e55d47cfe1b  movaps xmm1, xmm15
00007e55d47cfe1f  addpd xmm1, xmm10
00007e55d47cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007e55d47cfe29  ptest xmm2, xmm2
00007e55d47cfe2e  jnz 0x00007E55D47D2DE1
00007e55d47cfe34  vmovaps xmm10, [rsp+0xC0]
00007e55d47cfe3d  movaps xmm15, xmm10
00007e55d47cfe41  addpd xmm15, xmm11
00007e55d47cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007e55d47cfe4c  ptest xmm2, xmm2
00007e55d47cfe51  jnz 0x00007E55D47D2F23
00007e55d47cfe57  vmovaps xmm11, [rsp+0x80]
00007e55d47cfe60  vpermilpd xmm11, xmm11, 0x00
00007e55d47cfe66  movaps xmm10, xmm12
00007e55d47cfe6a  mulpd xmm10, xmm11
00007e55d47cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007e55d47cfe75  ptest xmm2, xmm2
00007e55d47cfe7a  jnz 0x00007E55D47D3067
00007e55d47cfe80  vmovaps xmm12, [rsp+0x80]
00007e55d47cfe89  vpermilpd xmm12, xmm12, 0x00
00007e55d47cfe8f  vmovaps xmm2, [rsp+0xA0]
00007e55d47cfe98  vmovaps [rsp+0x30], xmm1
00007e55d47cfe9e  movaps xmm11, xmm2
00007e55d47cfea2  mulpd xmm11, xmm12
00007e55d47cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007e55d47cfead  ptest xmm1, xmm1
00007e55d47cfeb2  jnz 0x00007E55D47D31AB
00007e55d47cfeb8  movaps xmm1, xmm14
00007e55d47cfebc  addpd xmm1, xmm6
00007e55d47cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007e55d47cfec5  ptest xmm12, xmm12
00007e55d47cfecb  jnz 0x00007E55D47D32EE
00007e55d47cfed1  vmovaps xmm12, [rsp+0x20]
00007e55d47cfed7  movaps xmm14, xmm12
00007e55d47cfedb  addpd xmm14, xmm5
00007e55d47cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007e55d47cfee6  ptest xmm6, xmm6
00007e55d47cfeeb  jnz 0x00007E55D47D342F
00007e55d47cfef1  vmovaps xmm12, [rsp+0x90]
00007e55d47cfefa  vpermilpd xmm12, xmm12, 0x00
00007e55d47cff00  movaps xmm6, xmm9
00007e55d47cff04  mulpd xmm6, xmm12
00007e55d47cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007e55d47cff0e  ptest xmm5, xmm5
00007e55d47cff13  jnz 0x00007E55D47D3572
00007e55d47cff19  movaps xmm12, xmm15
00007e55d47cff1d  addpd xmm12, xmm13
00007e55d47cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007e55d47cff28  ptest xmm9, xmm9
00007e55d47cff2e  jnz 0x00007E55D47D36B4
00007e55d47cff34  vmovaps xmm13, [rsp+0x30]
00007e55d47cff3a  movaps xmm15, xmm13
00007e55d47cff3e  addpd xmm15, xmm10
00007e55d47cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007e55d47cff49  ptest xmm9, xmm9
00007e55d47cff4f  jnz 0x00007E55D47D37F8
00007e55d47cff55  vmovaps xmm13, [rsp+0xD0]
00007e55d47cff5e  vmovaps xmm10, [rsp+0xD0]
00007e55d47cff67  por xmm13, xmm10
00007e55d47cff6c  movaps [r15+0x250], xmm13
00007e55d47cff74  vmovaps [rsp+0x20], xmm7
00007e55d47cff7a  vmovaps xmm13, [rsp+0x20]
00007e55d47cff80  por xmm7, xmm13
00007e55d47cff85  movaps [r15+0x2A0], xmm7
00007e55d47cff8d  vmovaps [rsp+0x20], xmm3
00007e55d47cff93  vmovaps xmm13, [rsp+0x20]
00007e55d47cff99  por xmm3, xmm13
00007e55d47cff9e  movaps [r15+0x1D0], xmm3
00007e55d47cffa6  lea rax, [r14+0x40]
00007e55d47cffaa  movups xmm13, [r13+rax*1]
00007e55d47cffb0  movaps [r15+0x2C0], xmm13
00007e55d47cffb8  vmovaps xmm10, [rsp+0x90]
00007e55d47cffc1  vpermilpd xmm10, xmm10, 0x00
00007e55d47cffc7  movaps xmm9, xmm8
00007e55d47cffcb  mulpd xmm9, xmm10
00007e55d47cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007e55d47cffd6  ptest xmm5, xmm5
00007e55d47cffdb  jnz 0x00007E55D47D3946
00007e55d47cffe1  movaps xmm10, xmm1
00007e55d47cffe5  addpd xmm10, xmm11
00007e55d47cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007e55d47cfff0  ptest xmm8, xmm8
00007e55d47cfff6  jnz 0x00007E55D47D3A8A
00007e55d47cfffc  movaps xmm1, xmm14
00007e55d47d0000  addpd xmm1, xmm6
00007e55d47d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007e55d47d0009  ptest xmm11, xmm11
00007e55d47d000f  jnz 0x00007E55D47D3BCD
00007e55d47d0015  vmovaps xmm14, [rsp+0x90]
00007e55d47d001e  vpermilpd xmm14, xmm14, 0x00
00007e55d47d0024  movaps xmm11, xmm13
00007e55d47d0028  mulpd xmm11, xmm14
00007e55d47d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007e55d47d0033  ptest xmm8, xmm8
00007e55d47d0039  jnz 0x00007E55D47D3D0E
00007e55d47d003f  vmovaps xmm14, [rsp+0x90]
00007e55d47d0048  vpermilpd xmm14, xmm14, 0x00
00007e55d47d004e  vmovaps xmm8, [rsp+0x10]
00007e55d47d0054  movaps xmm13, xmm8
00007e55d47d0058  mulpd xmm13, xmm14
00007e55d47d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007e55d47d0063  ptest xmm6, xmm6
00007e55d47d0068  jnz 0x00007E55D47D3E52
00007e55d47d006e  vmovaps xmm14, [rsp+0x60]
00007e55d47d0074  vpermilpd xmm14, xmm14, 0x00
00007e55d47d007a  movaps xmm8, xmm7
00007e55d47d007e  mulpd xmm8, xmm14
00007e55d47d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007e55d47d0089  ptest xmm6, xmm6
00007e55d47d008e  jnz 0x00007E55D47D3F96
00007e55d47d0094  movaps xmm14, xmm12
00007e55d47d0098  addpd xmm14, xmm9
00007e55d47d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007e55d47d00a3  ptest xmm7, xmm7
00007e55d47d00a8  jnz 0x00007E55D47D40D9
00007e55d47d00ae  vmovaps xmm12, [rsp+0x60]
00007e55d47d00b4  vpermilpd xmm12, xmm12, 0x00
00007e55d47d00ba  vmovaps xmm7, [rsp+0xF0]
00007e55d47d00c3  movaps xmm9, xmm7
00007e55d47d00c7  mulpd xmm9, xmm12
00007e55d47d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007e55d47d00d2  ptest xmm6, xmm6
00007e55d47d00d7  jnz 0x00007E55D47D421D
00007e55d47d00dd  movaps xmm12, xmm15
00007e55d47d00e1  addpd xmm12, xmm11
00007e55d47d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007e55d47d00ec  ptest xmm7, xmm7
00007e55d47d00f1  jnz 0x00007E55D47D4360
00007e55d47d00f7  vmovaps xmm15, [rsp+0x60]
00007e55d47d00fd  vpermilpd xmm15, xmm15, 0x00
00007e55d47d0103  vmovaps xmm7, [rsp+0x40]
00007e55d47d0109  movaps xmm11, xmm7
00007e55d47d010d  mulpd xmm11, xmm15
00007e55d47d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007e55d47d0118  ptest xmm6, xmm6
00007e55d47d011d  jnz 0x00007E55D47D44A4
00007e55d47d0123  movaps xmm15, xmm10
00007e55d47d0127  addpd xmm15, xmm13
00007e55d47d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007e55d47d0132  ptest xmm7, xmm7
00007e55d47d0137  jnz 0x00007E55D47D45E7
00007e55d47d013d  vmovaps xmm13, [rsp+0x60]
00007e55d47d0143  vpermilpd xmm13, xmm13, 0x00
00007e55d47d0149  vmovaps xmm7, [rsp+0x50]
00007e55d47d014f  movaps xmm10, xmm7
00007e55d47d0153  mulpd xmm10, xmm13
00007e55d47d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007e55d47d015e  ptest xmm6, xmm6
00007e55d47d0163  jnz 0x00007E55D47D472B
00007e55d47d0169  movaps xmm13, xmm1
00007e55d47d016d  addpd xmm13, xmm8
00007e55d47d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007e55d47d0178  ptest xmm7, xmm7
00007e55d47d017d  jnz 0x00007E55D47D486E
00007e55d47d0183  lea rax, [r14+0x70]
00007e55d47d0187  movups xmm1, [r13+rax*1]
00007e55d47d018d  movaps [r15+0x240], xmm1
00007e55d47d0195  movaps xmm8, xmm14
00007e55d47d0199  addpd xmm8, xmm9
00007e55d47d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007e55d47d01a4  ptest xmm7, xmm7
00007e55d47d01a9  jnz 0x00007E55D47D49BB
00007e55d47d01af  movaps [r15+0x170], xmm8
00007e55d47d01b7  vmovaps xmm14, [rsp+0x70]
00007e55d47d01bd  vpermilpd xmm14, xmm14, 0x00
00007e55d47d01c3  movaps xmm9, xmm1
00007e55d47d01c7  mulpd xmm9, xmm14
00007e55d47d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007e55d47d01d2  ptest xmm7, xmm7
00007e55d47d01d7  jnz 0x00007E55D47D4AFF
00007e55d47d01dd  vmovaps xmm1, [rsp+0x70]
00007e55d47d01e3  vpermilpd xmm1, xmm1, 0x00
00007e55d47d01e9  movaps xmm14, xmm4
00007e55d47d01ed  mulpd xmm14, xmm1
00007e55d47d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007e55d47d01f8  ptest xmm7, xmm7
00007e55d47d01fd  jnz 0x00007E55D47D4C42
00007e55d47d0203  movaps [r15+0x180], xmm14
00007e55d47d020b  movaps xmm1, xmm12
00007e55d47d020f  addpd xmm1, xmm11
00007e55d47d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007e55d47d0219  ptest xmm7, xmm7
00007e55d47d021e  jnz 0x00007E55D47D4D84
00007e55d47d0224  movaps [r15+0x210], xmm1
00007e55d47d022c  movups xmm12, [r13+r14*1]
00007e55d47d0232  lea rax, [r14+0x10]
00007e55d47d0236  movups xmm11, [r13+rax*1]
00007e55d47d023c  movaps [r15+0x230], xmm11
00007e55d47d0244  movaps xmm7, xmm15
00007e55d47d0248  addpd xmm7, xmm10
00007e55d47d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007e55d47d0252  ptest xmm6, xmm6
00007e55d47d0257  jnz 0x00007E55D47D4EDA
00007e55d47d025d  movaps [r15+0x130], xmm7
00007e55d47d0265  vmovaps xmm15, [rsp+0x70]
00007e55d47d026b  vpermilpd xmm15, xmm15, 0x00
00007e55d47d0271  movaps xmm10, xmm11
00007e55d47d0275  mulpd xmm10, xmm15
00007e55d47d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007e55d47d0280  ptest xmm6, xmm6
00007e55d47d0285  jnz 0x00007E55D47D501C
00007e55d47d028b  movaps [r15+0x220], xmm10
00007e55d47d0293  vmovaps xmm15, [rsp+0x70]
00007e55d47d0299  vpermilpd xmm15, xmm15, 0x00
00007e55d47d029f  movaps xmm11, xmm12
00007e55d47d02a3  mulpd xmm11, xmm15
00007e55d47d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007e55d47d02ae  ptest xmm6, xmm6
00007e55d47d02b3  jnz 0x00007E55D47D5160
00007e55d47d02b9  movaps xmm15, xmm13
00007e55d47d02bd  addpd xmm15, xmm9
00007e55d47d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007e55d47d02c8  ptest xmm12, xmm12
00007e55d47d02ce  jnz 0x00007E55D47D52A4
00007e55d47d02d4  movaps [r15+0x140], xmm15
00007e55d47d02dc  movaps xmm13, xmm8
00007e55d47d02e0  addpd xmm13, xmm14
00007e55d47d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007e55d47d02eb  ptest xmm12, xmm12
00007e55d47d02f1  jnz 0x00007E55D47D53E8
00007e55d47d02f7  movaps [r15+0x150], xmm13
00007e55d47d02ff  movaps xmm14, xmm1
00007e55d47d0303  addpd xmm14, xmm10
00007e55d47d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007e55d47d030e  ptest xmm12, xmm12
00007e55d47d0314  jnz 0x00007E55D47D552C
00007e55d47d031a  movaps [r15+0x160], xmm14
00007e55d47d0322  movaps xmm1, xmm7
00007e55d47d0325  addpd xmm1, xmm11
00007e55d47d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007e55d47d032f  ptest xmm12, xmm12
00007e55d47d0335  jnz 0x00007E55D47D566F
00007e55d47d033b  movaps [r15+0x120], xmm1
00007e55d47d0343  mov eax, 0x430920
00007e55d47d0348  movups [r13+rax*1], xmm15
00007e55d47d034e  mov eax, 0x430930
00007e55d47d0353  movups [r13+rax*1], xmm13
00007e55d47d0359  mov eax, 0x430940
00007e55d47d035e  movups [r13+rax*1], xmm14
00007e55d47d0364  mov eax, 0x430950
00007e55d47d0369  movups [r13+rax*1], xmm1
00007e55d47d036f  mov eax, [r15+0x108]
00007e55d47d0376  sahf
00007e55d47d0377  jnz 0x00007E55D47D03A9
00007e55d47d0379  cmp dword ptr [r15+0x318], 0x00
00007e55d47d0381  jz 0x00007E55D47DB900
00007e55d47d0387  nop [rax+rax*1], ax
00007e55d47d0390  nop [rax+rax*1], eax
00007e55d47d0398  mov eax, 0x410444
00007e55d47d039d  mov [r15+0x100], rax
00007e55d47d03a4  jmp 0x00007E55D45FE110
00007e55d47d03a9  cmp dword ptr [r15+0x318], 0x00
00007e55d47d03b1  jz 0x00007E55D47D57E0
00007e55d47d03b7  nop [rax+rax*1], ax
00007e55d47d03c0  nop [rax+rax*1], eax
00007e55d47d03c8  mov eax, 0x410278
00007e55d47d03cd  mov [r15+0x100], rax
00007e55d47d03d4  jmp 0x00007E55D45FE110
00007e55d47d03d9  int3
00007e55d47d03da  call 0x00007E55D46B52F0
00007e55d47d03df  jmp 0x00007E55D47CF016
00007e55d47d03e4  call 0x00007E55D46C4620
00007e55d47d03e9  jmp 0x00007E55D47CF023
00007e55d47d03ee  call 0x00007E55D46C33A0
00007e55d47d03f3  jmp 0x00007E55D47CF035
00007e55d47d03f8  call 0x00007E55D46C2120
00007e55d47d03fd  jmp 0x00007E55D47CF03F
00007e55d47d0402  call 0x00007E55D46C0860
00007e55d47d0407  jmp 0x00007E55D47CF067
00007e55d47d040c  call 0x00007E55D46BF5F0
00007e55d47d0411  jmp 0x00007E55D47CF073
00007e55d47d0416  call 0x00007E55D46C0860
00007e55d47d041b  jmp 0x00007E55D47CF0A5
00007e55d47d0420  call 0x00007E55D46BF5F0
00007e55d47d0425  jmp 0x00007E55D47CF0B1
00007e55d47d042a  call 0x00007E55D46C4740
00007e55d47d042f  jmp 0x00007E55D47CF0BE
00007e55d47d0434  call 0x00007E55D46B5400
00007e55d47d0439  jmp 0x00007E55D47CF0CB
00007e55d47d043e  call 0x00007E55D46B52F0
00007e55d47d0443  jmp 0x00007E55D47CF0D8
00007e55d47d0448  call 0x00007E55D46C4620
00007e55d47d044d  jmp 0x00007E55D47CF0E5
00007e55d47d0452  call 0x00007E55D46C0860
00007e55d47d0457  jmp 0x00007E55D47CF10D
00007e55d47d045c  call 0x00007E55D46BF5F0
00007e55d47d0461  jmp 0x00007E55D47CF119
00007e55d47d0466  call 0x00007E55D4609D70
00007e55d47d046b  jmp 0x00007E55D47CF11F
00007e55d47d0470  call 0x00007E55D46BE9C0
00007e55d47d0475  jmp 0x00007E55D47CF129
00007e55d47d047a  call 0x00007E55D46C0860
00007e55d47d047f  jmp 0x00007E55D47CF151
00007e55d47d0484  call 0x00007E55D46BF5F0
00007e55d47d0489  jmp 0x00007E55D47CF15D
00007e55d47d048e  call 0x00007E55D46BD750
00007e55d47d0493  jmp 0x00007E55D47CF16A
00007e55d47d0498  call 0x00007E55D46BC4E0
00007e55d47d049d  jmp 0x00007E55D47CF177
00007e55d47d04a2  call 0x00007E55D46C4740
00007e55d47d04a7  jmp 0x00007E55D47CF184
00007e55d47d04ac  call 0x00007E55D46B5400
00007e55d47d04b1  jmp 0x00007E55D47CF191
00007e55d47d04b6  call 0x00007E55D46B52F0
00007e55d47d04bb  jmp 0x00007E55D47CF19E
00007e55d47d04c0  call 0x00007E55D46C4620
00007e55d47d04c5  jmp 0x00007E55D47CF1AB
00007e55d47d04ca  call 0x00007E55D46C0860
00007e55d47d04cf  jmp 0x00007E55D47CF1BE
00007e55d47d04d4  call 0x00007E55D46BB270
00007e55d47d04d9  jmp 0x00007E55D47CF1CB
00007e55d47d04de  call 0x00007E55D46BA000
00007e55d47d04e3  jmp 0x00007E55D47CF1D8
00007e55d47d04e8  call 0x00007E55D46B8D90
00007e55d47d04ed  jmp 0x00007E55D47CF1E5
00007e55d47d04f2  call 0x00007E55D46B8A20
00007e55d47d04f7  jmp 0x00007E55D47CF1F2
00007e55d47d04fc  call 0x00007E55D46B5400
00007e55d47d0501  jmp 0x00007E55D47CF1FC
00007e55d47d0506  call 0x00007E55D46C2240
00007e55d47d050b  jmp 0x00007E55D47CF206
00007e55d47d0510  call 0x00007E55D46B52F0
00007e55d47d0515  jmp 0x00007E55D47CF210
00007e55d47d051a  call 0x00007E55D46C2120
00007e55d47d051f  jmp 0x00007E55D47CF21A
00007e55d47d0524  call 0x00007E55D46B77B0
00007e55d47d0529  jmp 0x00007E55D47CF224
00007e55d47d052e  call 0x00007E55D46B6550
00007e55d47d0533  jmp 0x00007E55D47CF22E
00007e55d47d0538  call 0x00007E55D46BFD50
00007e55d47d053d  jmp 0x00007E55D47CF240
00007e55d47d0542  call 0x00007E55D46B8EA0
00007e55d47d0547  jmp 0x00007E55D47CF24A
00007e55d47d054c  call 0x00007E55D46BFC30
00007e55d47d0551  jmp 0x00007E55D47CF257
00007e55d47d0556  call 0x00007E55D46B8D90
00007e55d47d055b  jmp 0x00007E55D47CF264
00007e55d47d0560  call 0x00007E55D46C2240
00007e55d47d0565  jmp 0x00007E55D47CF271
00007e55d47d056a  call 0x00007E55D46B5400
00007e55d47d056f  jmp 0x00007E55D47CF27E
00007e55d47d0574  call 0x00007E55D46B52F0
00007e55d47d0579  jmp 0x00007E55D47CF28B
00007e55d47d057e  call 0x00007E55D46C2120
00007e55d47d0583  jmp 0x00007E55D47CF298
00007e55d47d0588  call 0x00007E55D46B52F0
00007e55d47d058d  jmp 0x00007E55D47CF2AB
00007e55d47d0592  call 0x00007E55D46B52F0
00007e55d47d0597  jmp 0x00007E55D47CF2BE
00007e55d47d059c  call 0x00007E55D46B52F0
00007e55d47d05a1  jmp 0x00007E55D47CF2D1
00007e55d47d05a6  call 0x00007E55D46B52F0
00007e55d47d05ab  jmp 0x00007E55D47CF2E4
00007e55d47d05b0  call 0x00007E55D46C2240
00007e55d47d05b5  jmp 0x00007E55D47CF2F9
00007e55d47d05ba  call 0x00007E55D46C2240
00007e55d47d05bf  jmp 0x00007E55D47CF30C
00007e55d47d05c4  call 0x00007E55D46C2120
00007e55d47d05c9  jmp 0x00007E55D47CF319
00007e55d47d05ce  call 0x00007E55D46B52F0
00007e55d47d05d3  jmp 0x00007E55D47CF32C
00007e55d47d05d8  call 0x00007E55D46B52F0
00007e55d47d05dd  jmp 0x00007E55D47CF34F
00007e55d47d05e2  call 0x00007E55D46B52F0
00007e55d47d05e7  jmp 0x00007E55D47CF362
00007e55d47d05ec  call 0x00007E55D45FF540
00007e55d47d05f1  jmp 0x00007E55D47CF380
00007e55d47d05f6  call 0x00007E55D4608C20
00007e55d47d05fb  jmp 0x00007E55D47CF38A
00007e55d47d0600  call 0x00007E55D46D6600
00007e55d47d0605  jmp 0x00007E55D47CF396
00007e55d47d060a  call 0x00007E55D45FF540
00007e55d47d060f  jmp 0x00007E55D47CF3A6
00007e55d47d0614  call 0x00007E55D46C0370
00007e55d47d0619  jmp 0x00007E55D47CF3D4
00007e55d47d061e  call 0x00007E55D46BF100
00007e55d47d0623  jmp 0x00007E55D47CF3DD
00007e55d47d0628  call 0x00007E55D46C0370
00007e55d47d062d  jmp 0x00007E55D47CF43B
00007e55d47d0632  call 0x00007E55D46BF100
00007e55d47d0637  jmp 0x00007E55D47CF444
00007e55d47d063c  call 0x00007E55D46C0370
00007e55d47d0641  jmp 0x00007E55D47CF48B
00007e55d47d0646  call 0x00007E55D46BF100
00007e55d47d064b  jmp 0x00007E55D47CF494
00007e55d47d0650  call 0x00007E55D460B720
00007e55d47d0655  jmp 0x00007E55D47CF4D7
00007e55d47d065a  call 0x00007E55D46B47C0
00007e55d47d065f  jmp 0x00007E55D47CF4EA
00007e55d47d0664  call 0x00007E55D4608B00
00007e55d47d0669  jmp 0x00007E55D47CF501
00007e55d47d066e  call 0x00007E55D45FF430
00007e55d47d0673  jmp 0x00007E55D47CF514
00007e55d47d0678  call 0x00007E55D45FF430
00007e55d47d067d  jmp 0x00007E55D47CF527
00007e55d47d0682  sub rsp, 0x08
00007e55d47d0686  push rax
00007e55d47d0687  push rcx
00007e55d47d0688  push rdx
00007e55d47d0689  push rdi
00007e55d47d068a  push rsi
00007e55d47d068b  push r8
00007e55d47d068d  push r9
00007e55d47d068f  push r10
00007e55d47d0691  push r11
00007e55d47d0693  sub rsp, 0xF0
00007e55d47d069a  vmovaps [rsp], xmm0
00007e55d47d069f  vmovaps [rsp+0x10], xmm2
00007e55d47d06a5  vmovaps [rsp+0x20], xmm3
00007e55d47d06ab  vmovaps [rsp+0x30], xmm4
00007e55d47d06b1  vmovaps [rsp+0x40], xmm5
00007e55d47d06b7  vmovaps [rsp+0x50], xmm6
00007e55d47d06bd  vmovaps [rsp+0x60], xmm7
00007e55d47d06c3  vmovaps [rsp+0x70], xmm8
00007e55d47d06c9  vmovaps [rsp+0x80], xmm9
00007e55d47d06d2  vmovaps [rsp+0x90], xmm10
00007e55d47d06db  vmovaps [rsp+0xA0], xmm11
00007e55d47d06e4  vmovaps [rsp+0xB0], xmm12
00007e55d47d06ed  vmovaps [rsp+0xC0], xmm13
00007e55d47d06f6  vmovaps [rsp+0xD0], xmm14
00007e55d47d06ff  vmovaps [rsp+0xE0], xmm15
00007e55d47d0708  sub rsp, 0x30
00007e55d47d070c  movaps [rsp], xmm1
00007e55d47d0710  movaps [rsp+0x10], xmm15
00007e55d47d0716  movaps [rsp+0x20], xmm14
00007e55d47d071c  lea rdi, [rsp]
00007e55d47d0720  mov esi, 0x00
00007e55d47d0725  mov rax, 0x55D0734A4530
00007e55d47d072f  call rax
00007e55d47d0731  movaps xmm1, [rsp]
00007e55d47d0735  add rsp, 0x30
00007e55d47d0739  vmovaps xmm0, [rsp]
00007e55d47d073e  vmovaps xmm2, [rsp+0x10]
00007e55d47d0744  vmovaps xmm3, [rsp+0x20]
00007e55d47d074a  vmovaps xmm4, [rsp+0x30]
00007e55d47d0750  vmovaps xmm5, [rsp+0x40]
00007e55d47d0756  vmovaps xmm6, [rsp+0x50]
00007e55d47d075c  vmovaps xmm7, [rsp+0x60]
00007e55d47d0762  vmovaps xmm8, [rsp+0x70]
00007e55d47d0768  vmovaps xmm9, [rsp+0x80]
00007e55d47d0771  vmovaps xmm10, [rsp+0x90]
00007e55d47d077a  vmovaps xmm11, [rsp+0xA0]
00007e55d47d0783  vmovaps xmm12, [rsp+0xB0]
00007e55d47d078c  vmovaps xmm13, [rsp+0xC0]
00007e55d47d0795  vmovaps xmm14, [rsp+0xD0]
00007e55d47d079e  vmovaps xmm15, [rsp+0xE0]
00007e55d47d07a7  add rsp, 0xF0
00007e55d47d07ae  pop r11
00007e55d47d07b0  pop r10
00007e55d47d07b2  pop r9
00007e55d47d07b4  pop r8
00007e55d47d07b6  pop rsi
00007e55d47d07b7  pop rdi
00007e55d47d07b8  pop rdx
00007e55d47d07b9  pop rcx
00007e55d47d07ba  pop rax
00007e55d47d07bb  add rsp, 0x08
00007e55d47d07bf  jmp 0x00007E55D47CF581
00007e55d47d07c4  sub rsp, 0x08
00007e55d47d07c8  push rax
00007e55d47d07c9  push rcx
00007e55d47d07ca  push rdx
00007e55d47d07cb  push rdi
00007e55d47d07cc  push rsi
00007e55d47d07cd  push r8
00007e55d47d07cf  push r9
00007e55d47d07d1  push r10
00007e55d47d07d3  push r11
00007e55d47d07d5  sub rsp, 0xF0
00007e55d47d07dc  vmovaps [rsp], xmm0
00007e55d47d07e1  vmovaps [rsp+0x10], xmm1
00007e55d47d07e7  vmovaps [rsp+0x20], xmm2
00007e55d47d07ed  vmovaps [rsp+0x30], xmm3
00007e55d47d07f3  vmovaps [rsp+0x40], xmm4
00007e55d47d07f9  vmovaps [rsp+0x50], xmm5
00007e55d47d07ff  vmovaps [rsp+0x60], xmm6
00007e55d47d0805  vmovaps [rsp+0x70], xmm7
00007e55d47d080b  vmovaps [rsp+0x80], xmm8
00007e55d47d0814  vmovaps [rsp+0x90], xmm9
00007e55d47d081d  vmovaps [rsp+0xA0], xmm10
00007e55d47d0826  vmovaps [rsp+0xB0], xmm11
00007e55d47d082f  vmovaps [rsp+0xC0], xmm12
00007e55d47d0838  vmovaps [rsp+0xD0], xmm14
00007e55d47d0841  vmovaps [rsp+0xE0], xmm15
00007e55d47d084a  sub rsp, 0x30
00007e55d47d084e  movaps [rsp], xmm13
00007e55d47d0853  movaps [rsp+0x10], xmm1
00007e55d47d0858  movaps [rsp+0x20], xmm14
00007e55d47d085e  lea rdi, [rsp]
00007e55d47d0862  mov esi, 0x00
00007e55d47d0867  mov rax, 0x55D0734A4530
00007e55d47d0871  call rax
00007e55d47d0873  movaps xmm13, [rsp]
00007e55d47d0878  add rsp, 0x30
00007e55d47d087c  vmovaps xmm0, [rsp]
00007e55d47d0881  vmovaps xmm1, [rsp+0x10]
00007e55d47d0887  vmovaps xmm2, [rsp+0x20]
00007e55d47d088d  vmovaps xmm3, [rsp+0x30]
00007e55d47d0893  vmovaps xmm4, [rsp+0x40]
00007e55d47d0899  vmovaps xmm5, [rsp+0x50]
00007e55d47d089f  vmovaps xmm6, [rsp+0x60]
00007e55d47d08a5  vmovaps xmm7, [rsp+0x70]
00007e55d47d08ab  vmovaps xmm8, [rsp+0x80]
00007e55d47d08b4  vmovaps xmm9, [rsp+0x90]
00007e55d47d08bd  vmovaps xmm10, [rsp+0xA0]
00007e55d47d08c6  vmovaps xmm11, [rsp+0xB0]
00007e55d47d08cf  vmovaps xmm12, [rsp+0xC0]
00007e55d47d08d8  vmovaps xmm14, [rsp+0xD0]
00007e55d47d08e1  vmovaps xmm15, [rsp+0xE0]
00007e55d47d08ea  add rsp, 0xF0
00007e55d47d08f1  pop r11
00007e55d47d08f3  pop r10
00007e55d47d08f5  pop r9
00007e55d47d08f7  pop r8
00007e55d47d08f9  pop rsi
00007e55d47d08fa  pop rdi
00007e55d47d08fb  pop rdx
00007e55d47d08fc  pop rcx
00007e55d47d08fd  pop rax
00007e55d47d08fe  add rsp, 0x08
00007e55d47d0902  jmp 0x00007E55D47CF5CF
00007e55d47d0907  sub rsp, 0x08
00007e55d47d090b  push rax
00007e55d47d090c  push rcx
00007e55d47d090d  push rdx
00007e55d47d090e  push rdi
00007e55d47d090f  push rsi
00007e55d47d0910  push r8
00007e55d47d0912  push r9
00007e55d47d0914  push r10
00007e55d47d0916  push r11
00007e55d47d0918  sub rsp, 0xF0
00007e55d47d091f  vmovaps [rsp], xmm0
00007e55d47d0924  vmovaps [rsp+0x10], xmm1
00007e55d47d092a  vmovaps [rsp+0x20], xmm2
00007e55d47d0930  vmovaps [rsp+0x30], xmm3
00007e55d47d0936  vmovaps [rsp+0x40], xmm4
00007e55d47d093c  vmovaps [rsp+0x50], xmm5
00007e55d47d0942  vmovaps [rsp+0x60], xmm6
00007e55d47d0948  vmovaps [rsp+0x70], xmm7
00007e55d47d094e  vmovaps [rsp+0x80], xmm8
00007e55d47d0957  vmovaps [rsp+0x90], xmm9
00007e55d47d0960  vmovaps [rsp+0xA0], xmm10
00007e55d47d0969  vmovaps [rsp+0xB0], xmm11
00007e55d47d0972  vmovaps [rsp+0xC0], xmm12
00007e55d47d097b  vmovaps [rsp+0xD0], xmm13
00007e55d47d0984  vmovaps [rsp+0xE0], xmm14
00007e55d47d098d  sub rsp, 0x30
00007e55d47d0991  movaps [rsp], xmm15
00007e55d47d0996  movaps [rsp+0x10], xmm14
00007e55d47d099c  movaps [rsp+0x20], xmm1
00007e55d47d09a1  lea rdi, [rsp]
00007e55d47d09a5  mov esi, 0x00
00007e55d47d09aa  mov rax, 0x55D0734A4530
00007e55d47d09b4  call rax
00007e55d47d09b6  movaps xmm15, [rsp]
00007e55d47d09bb  add rsp, 0x30
00007e55d47d09bf  vmovaps xmm0, [rsp]
00007e55d47d09c4  vmovaps xmm1, [rsp+0x10]
00007e55d47d09ca  vmovaps xmm2, [rsp+0x20]
00007e55d47d09d0  vmovaps xmm3, [rsp+0x30]
00007e55d47d09d6  vmovaps xmm4, [rsp+0x40]
00007e55d47d09dc  vmovaps xmm5, [rsp+0x50]
00007e55d47d09e2  vmovaps xmm6, [rsp+0x60]
00007e55d47d09e8  vmovaps xmm7, [rsp+0x70]
00007e55d47d09ee  vmovaps xmm8, [rsp+0x80]
00007e55d47d09f7  vmovaps xmm9, [rsp+0x90]
00007e55d47d0a00  vmovaps xmm10, [rsp+0xA0]
00007e55d47d0a09  vmovaps xmm11, [rsp+0xB0]
00007e55d47d0a12  vmovaps xmm12, [rsp+0xC0]
00007e55d47d0a1b  vmovaps xmm13, [rsp+0xD0]
00007e55d47d0a24  vmovaps xmm14, [rsp+0xE0]
00007e55d47d0a2d  add rsp, 0xF0
00007e55d47d0a34  pop r11
00007e55d47d0a36  pop r10
00007e55d47d0a38  pop r9
00007e55d47d0a3a  pop r8
00007e55d47d0a3c  pop rsi
00007e55d47d0a3d  pop rdi
00007e55d47d0a3e  pop rdx
00007e55d47d0a3f  pop rcx
00007e55d47d0a40  pop rax
00007e55d47d0a41  add rsp, 0x08
00007e55d47d0a45  jmp 0x00007E55D47CF617
00007e55d47d0a4a  sub rsp, 0x08
00007e55d47d0a4e  push rax
00007e55d47d0a4f  push rcx
00007e55d47d0a50  push rdx
00007e55d47d0a51  push rdi
00007e55d47d0a52  push rsi
00007e55d47d0a53  push r8
00007e55d47d0a55  push r9
00007e55d47d0a57  push r10
00007e55d47d0a59  push r11
00007e55d47d0a5b  sub rsp, 0xF0
00007e55d47d0a62  vmovaps [rsp], xmm0
00007e55d47d0a67  vmovaps [rsp+0x10], xmm2
00007e55d47d0a6d  vmovaps [rsp+0x20], xmm3
00007e55d47d0a73  vmovaps [rsp+0x30], xmm4
00007e55d47d0a79  vmovaps [rsp+0x40], xmm5
00007e55d47d0a7f  vmovaps [rsp+0x50], xmm6
00007e55d47d0a85  vmovaps [rsp+0x60], xmm7
00007e55d47d0a8b  vmovaps [rsp+0x70], xmm8
00007e55d47d0a91  vmovaps [rsp+0x80], xmm9
00007e55d47d0a9a  vmovaps [rsp+0x90], xmm10
00007e55d47d0aa3  vmovaps [rsp+0xA0], xmm11
00007e55d47d0aac  vmovaps [rsp+0xB0], xmm12
00007e55d47d0ab5  vmovaps [rsp+0xC0], xmm13
00007e55d47d0abe  vmovaps [rsp+0xD0], xmm14
00007e55d47d0ac7  vmovaps [rsp+0xE0], xmm15
00007e55d47d0ad0  sub rsp, 0x30
00007e55d47d0ad4  movaps [rsp], xmm1
00007e55d47d0ad8  movaps [rsp+0x10], xmm14
00007e55d47d0ade  movaps [rsp+0x20], xmm10
00007e55d47d0ae4  lea rdi, [rsp]
00007e55d47d0ae8  mov esi, 0x00
00007e55d47d0aed  mov rax, 0x55D0734A4530
00007e55d47d0af7  call rax
00007e55d47d0af9  movaps xmm1, [rsp]
00007e55d47d0afd  add rsp, 0x30
00007e55d47d0b01  vmovaps xmm0, [rsp]
00007e55d47d0b06  vmovaps xmm2, [rsp+0x10]
00007e55d47d0b0c  vmovaps xmm3, [rsp+0x20]
00007e55d47d0b12  vmovaps xmm4, [rsp+0x30]
00007e55d47d0b18  vmovaps xmm5, [rsp+0x40]
00007e55d47d0b1e  vmovaps xmm6, [rsp+0x50]
00007e55d47d0b24  vmovaps xmm7, [rsp+0x60]
00007e55d47d0b2a  vmovaps xmm8, [rsp+0x70]
00007e55d47d0b30  vmovaps xmm9, [rsp+0x80]
00007e55d47d0b39  vmovaps xmm10, [rsp+0x90]
00007e55d47d0b42  vmovaps xmm11, [rsp+0xA0]
00007e55d47d0b4b  vmovaps xmm12, [rsp+0xB0]
00007e55d47d0b54  vmovaps xmm13, [rsp+0xC0]
00007e55d47d0b5d  vmovaps xmm14, [rsp+0xD0]
00007e55d47d0b66  vmovaps xmm15, [rsp+0xE0]
00007e55d47d0b6f  add rsp, 0xF0
00007e55d47d0b76  pop r11
00007e55d47d0b78  pop r10
00007e55d47d0b7a  pop r9
00007e55d47d0b7c  pop r8
00007e55d47d0b7e  pop rsi
00007e55d47d0b7f  pop rdi
00007e55d47d0b80  pop rdx
00007e55d47d0b81  pop rcx
00007e55d47d0b82  pop rax
00007e55d47d0b83  add rsp, 0x08
00007e55d47d0b87  jmp 0x00007E55D47CF631
00007e55d47d0b8c  sub rsp, 0x08
00007e55d47d0b90  push rax
00007e55d47d0b91  push rcx
00007e55d47d0b92  push rdx
00007e55d47d0b93  push rdi
00007e55d47d0b94  push rsi
00007e55d47d0b95  push r8
00007e55d47d0b97  push r9
00007e55d47d0b99  push r10
00007e55d47d0b9b  push r11
00007e55d47d0b9d  sub rsp, 0xF0
00007e55d47d0ba4  vmovaps [rsp], xmm0
00007e55d47d0ba9  vmovaps [rsp+0x10], xmm1
00007e55d47d0baf  vmovaps [rsp+0x20], xmm2
00007e55d47d0bb5  vmovaps [rsp+0x30], xmm3
00007e55d47d0bbb  vmovaps [rsp+0x40], xmm4
00007e55d47d0bc1  vmovaps [rsp+0x50], xmm5
00007e55d47d0bc7  vmovaps [rsp+0x60], xmm6
00007e55d47d0bcd  vmovaps [rsp+0x70], xmm7
00007e55d47d0bd3  vmovaps [rsp+0x80], xmm8
00007e55d47d0bdc  vmovaps [rsp+0x90], xmm9
00007e55d47d0be5  vmovaps [rsp+0xA0], xmm10
00007e55d47d0bee  vmovaps [rsp+0xB0], xmm11
00007e55d47d0bf7  vmovaps [rsp+0xC0], xmm12
00007e55d47d0c00  vmovaps [rsp+0xD0], xmm14
00007e55d47d0c09  vmovaps [rsp+0xE0], xmm15
00007e55d47d0c12  sub rsp, 0x30
00007e55d47d0c16  movaps [rsp], xmm13
00007e55d47d0c1b  movaps [rsp+0x10], xmm14
00007e55d47d0c21  movaps [rsp+0x20], xmm2
00007e55d47d0c26  lea rdi, [rsp]
00007e55d47d0c2a  mov esi, 0x00
00007e55d47d0c2f  mov rax, 0x55D0734A4530
00007e55d47d0c39  call rax
00007e55d47d0c3b  movaps xmm13, [rsp]
00007e55d47d0c40  add rsp, 0x30
00007e55d47d0c44  vmovaps xmm0, [rsp]
00007e55d47d0c49  vmovaps xmm1, [rsp+0x10]
00007e55d47d0c4f  vmovaps xmm2, [rsp+0x20]
00007e55d47d0c55  vmovaps xmm3, [rsp+0x30]
00007e55d47d0c5b  vmovaps xmm4, [rsp+0x40]
00007e55d47d0c61  vmovaps xmm5, [rsp+0x50]
00007e55d47d0c67  vmovaps xmm6, [rsp+0x60]
00007e55d47d0c6d  vmovaps xmm7, [rsp+0x70]
00007e55d47d0c73  vmovaps xmm8, [rsp+0x80]
00007e55d47d0c7c  vmovaps xmm9, [rsp+0x90]
00007e55d47d0c85  vmovaps xmm10, [rsp+0xA0]
00007e55d47d0c8e  vmovaps xmm11, [rsp+0xB0]
00007e55d47d0c97  vmovaps xmm12, [rsp+0xC0]
00007e55d47d0ca0  vmovaps xmm14, [rsp+0xD0]
00007e55d47d0ca9  vmovaps xmm15, [rsp+0xE0]
00007e55d47d0cb2  add rsp, 0xF0
00007e55d47d0cb9  pop r11
00007e55d47d0cbb  pop r10
00007e55d47d0cbd  pop r9
00007e55d47d0cbf  pop r8
00007e55d47d0cc1  pop rsi
00007e55d47d0cc2  pop rdi
00007e55d47d0cc3  pop rdx
00007e55d47d0cc4  pop rcx
00007e55d47d0cc5  pop rax
00007e55d47d0cc6  add rsp, 0x08
00007e55d47d0cca  jmp 0x00007E55D47CF64C
00007e55d47d0ccf  sub rsp, 0x08
00007e55d47d0cd3  push rax
00007e55d47d0cd4  push rcx
00007e55d47d0cd5  push rdx
00007e55d47d0cd6  push rdi
00007e55d47d0cd7  push rsi
00007e55d47d0cd8  push r8
00007e55d47d0cda  push r9
00007e55d47d0cdc  push r10
00007e55d47d0cde  push r11
00007e55d47d0ce0  sub rsp, 0xF0
00007e55d47d0ce7  vmovaps [rsp], xmm0
00007e55d47d0cec  vmovaps [rsp+0x10], xmm2
00007e55d47d0cf2  vmovaps [rsp+0x20], xmm3
00007e55d47d0cf8  vmovaps [rsp+0x30], xmm4
00007e55d47d0cfe  vmovaps [rsp+0x40], xmm5
00007e55d47d0d04  vmovaps [rsp+0x50], xmm6
00007e55d47d0d0a  vmovaps [rsp+0x60], xmm7
00007e55d47d0d10  vmovaps [rsp+0x70], xmm8
00007e55d47d0d16  vmovaps [rsp+0x80], xmm9
00007e55d47d0d1f  vmovaps [rsp+0x90], xmm10
00007e55d47d0d28  vmovaps [rsp+0xA0], xmm11
00007e55d47d0d31  vmovaps [rsp+0xB0], xmm12
00007e55d47d0d3a  vmovaps [rsp+0xC0], xmm13
00007e55d47d0d43  vmovaps [rsp+0xD0], xmm14
00007e55d47d0d4c  vmovaps [rsp+0xE0], xmm15
00007e55d47d0d55  sub rsp, 0x30
00007e55d47d0d59  movaps [rsp], xmm1
00007e55d47d0d5d  movaps [rsp+0x10], xmm10
00007e55d47d0d63  movaps [rsp+0x20], xmm2
00007e55d47d0d68  lea rdi, [rsp]
00007e55d47d0d6c  mov esi, 0x00
00007e55d47d0d71  mov rax, 0x55D0734A4530
00007e55d47d0d7b  call rax
00007e55d47d0d7d  movaps xmm1, [rsp]
00007e55d47d0d81  add rsp, 0x30
00007e55d47d0d85  vmovaps xmm0, [rsp]
00007e55d47d0d8a  vmovaps xmm2, [rsp+0x10]
00007e55d47d0d90  vmovaps xmm3, [rsp+0x20]
00007e55d47d0d96  vmovaps xmm4, [rsp+0x30]
00007e55d47d0d9c  vmovaps xmm5, [rsp+0x40]
00007e55d47d0da2  vmovaps xmm6, [rsp+0x50]
00007e55d47d0da8  vmovaps xmm7, [rsp+0x60]
00007e55d47d0dae  vmovaps xmm8, [rsp+0x70]
00007e55d47d0db4  vmovaps xmm9, [rsp+0x80]
00007e55d47d0dbd  vmovaps xmm10, [rsp+0x90]
00007e55d47d0dc6  vmovaps xmm11, [rsp+0xA0]
00007e55d47d0dcf  vmovaps xmm12, [rsp+0xB0]
00007e55d47d0dd8  vmovaps xmm13, [rsp+0xC0]
00007e55d47d0de1  vmovaps xmm14, [rsp+0xD0]
00007e55d47d0dea  vmovaps xmm15, [rsp+0xE0]
00007e55d47d0df3  add rsp, 0xF0
00007e55d47d0dfa  pop r11
00007e55d47d0dfc  pop r10
00007e55d47d0dfe  pop r9
00007e55d47d0e00  pop r8
00007e55d47d0e02  pop rsi
00007e55d47d0e03  pop rdi
00007e55d47d0e04  pop rdx
00007e55d47d0e05  pop rcx
00007e55d47d0e06  pop rax
00007e55d47d0e07  add rsp, 0x08
00007e55d47d0e0b  jmp 0x00007E55D47CF6B4
00007e55d47d0e10  sub rsp, 0x08
00007e55d47d0e14  push rax
00007e55d47d0e15  push rcx
00007e55d47d0e16  push rdx
00007e55d47d0e17  push rdi
00007e55d47d0e18  push rsi
00007e55d47d0e19  push r8
00007e55d47d0e1b  push r9
00007e55d47d0e1d  push r10
00007e55d47d0e1f  push r11
00007e55d47d0e21  sub rsp, 0xF0
00007e55d47d0e28  vmovaps [rsp], xmm0
00007e55d47d0e2d  vmovaps [rsp+0x10], xmm1
00007e55d47d0e33  vmovaps [rsp+0x20], xmm2
00007e55d47d0e39  vmovaps [rsp+0x30], xmm3
00007e55d47d0e3f  vmovaps [rsp+0x40], xmm4
00007e55d47d0e45  vmovaps [rsp+0x50], xmm5
00007e55d47d0e4b  vmovaps [rsp+0x60], xmm6
00007e55d47d0e51  vmovaps [rsp+0x70], xmm7
00007e55d47d0e57  vmovaps [rsp+0x80], xmm8
00007e55d47d0e60  vmovaps [rsp+0x90], xmm9
00007e55d47d0e69  vmovaps [rsp+0xA0], xmm10
00007e55d47d0e72  vmovaps [rsp+0xB0], xmm11
00007e55d47d0e7b  vmovaps [rsp+0xC0], xmm12
00007e55d47d0e84  vmovaps [rsp+0xD0], xmm13
00007e55d47d0e8d  vmovaps [rsp+0xE0], xmm14
00007e55d47d0e96  sub rsp, 0x30
00007e55d47d0e9a  movaps [rsp], xmm15
00007e55d47d0e9f  movaps [rsp+0x10], xmm10
00007e55d47d0ea5  movaps [rsp+0x20], xmm2
00007e55d47d0eaa  lea rdi, [rsp]
00007e55d47d0eae  mov esi, 0x00
00007e55d47d0eb3  mov rax, 0x55D0734A4530
00007e55d47d0ebd  call rax
00007e55d47d0ebf  movaps xmm15, [rsp]
00007e55d47d0ec4  add rsp, 0x30
00007e55d47d0ec8  vmovaps xmm0, [rsp]
00007e55d47d0ecd  vmovaps xmm1, [rsp+0x10]
00007e55d47d0ed3  vmovaps xmm2, [rsp+0x20]
00007e55d47d0ed9  vmovaps xmm3, [rsp+0x30]
00007e55d47d0edf  vmovaps xmm4, [rsp+0x40]
00007e55d47d0ee5  vmovaps xmm5, [rsp+0x50]
00007e55d47d0eeb  vmovaps xmm6, [rsp+0x60]
00007e55d47d0ef1  vmovaps xmm7, [rsp+0x70]
00007e55d47d0ef7  vmovaps xmm8, [rsp+0x80]
00007e55d47d0f00  vmovaps xmm9, [rsp+0x90]
00007e55d47d0f09  vmovaps xmm10, [rsp+0xA0]
00007e55d47d0f12  vmovaps xmm11, [rsp+0xB0]
00007e55d47d0f1b  vmovaps xmm12, [rsp+0xC0]
00007e55d47d0f24  vmovaps xmm13, [rsp+0xD0]
00007e55d47d0f2d  vmovaps xmm14, [rsp+0xE0]
00007e55d47d0f36  add rsp, 0xF0
00007e55d47d0f3d  pop r11
00007e55d47d0f3f  pop r10
00007e55d47d0f41  pop r9
00007e55d47d0f43  pop r8
00007e55d47d0f45  pop rsi
00007e55d47d0f46  pop rdi
00007e55d47d0f47  pop rdx
00007e55d47d0f48  pop rcx
00007e55d47d0f49  pop rax
00007e55d47d0f4a  add rsp, 0x08
00007e55d47d0f4e  jmp 0x00007E55D47CF706
00007e55d47d0f53  sub rsp, 0x08
00007e55d47d0f57  push rax
00007e55d47d0f58  push rcx
00007e55d47d0f59  push rdx
00007e55d47d0f5a  push rdi
00007e55d47d0f5b  push rsi
00007e55d47d0f5c  push r8
00007e55d47d0f5e  push r9
00007e55d47d0f60  push r10
00007e55d47d0f62  push r11
00007e55d47d0f64  sub rsp, 0xF0
00007e55d47d0f6b  vmovaps [rsp], xmm0
00007e55d47d0f70  vmovaps [rsp+0x10], xmm2
00007e55d47d0f76  vmovaps [rsp+0x20], xmm3
00007e55d47d0f7c  vmovaps [rsp+0x30], xmm4
00007e55d47d0f82  vmovaps [rsp+0x40], xmm5
00007e55d47d0f88  vmovaps [rsp+0x50], xmm6
00007e55d47d0f8e  vmovaps [rsp+0x60], xmm7
00007e55d47d0f94  vmovaps [rsp+0x70], xmm8
00007e55d47d0f9a  vmovaps [rsp+0x80], xmm9
00007e55d47d0fa3  vmovaps [rsp+0x90], xmm10
00007e55d47d0fac  vmovaps [rsp+0xA0], xmm11
00007e55d47d0fb5  vmovaps [rsp+0xB0], xmm12
00007e55d47d0fbe  vmovaps [rsp+0xC0], xmm13
00007e55d47d0fc7  vmovaps [rsp+0xD0], xmm14
00007e55d47d0fd0  vmovaps [rsp+0xE0], xmm15
00007e55d47d0fd9  sub rsp, 0x30
00007e55d47d0fdd  movaps [rsp], xmm1
00007e55d47d0fe1  movaps [rsp+0x10], xmm10
00007e55d47d0fe7  movaps [rsp+0x20], xmm12
00007e55d47d0fed  lea rdi, [rsp]
00007e55d47d0ff1  mov esi, 0x00
00007e55d47d0ff6  mov rax, 0x55D0734A4530
00007e55d47d1000  call rax
00007e55d47d1002  movaps xmm1, [rsp]
00007e55d47d1006  add rsp, 0x30
00007e55d47d100a  vmovaps xmm0, [rsp]
00007e55d47d100f  vmovaps xmm2, [rsp+0x10]
00007e55d47d1015  vmovaps xmm3, [rsp+0x20]
00007e55d47d101b  vmovaps xmm4, [rsp+0x30]
00007e55d47d1021  vmovaps xmm5, [rsp+0x40]
00007e55d47d1027  vmovaps xmm6, [rsp+0x50]
00007e55d47d102d  vmovaps xmm7, [rsp+0x60]
00007e55d47d1033  vmovaps xmm8, [rsp+0x70]
00007e55d47d1039  vmovaps xmm9, [rsp+0x80]
00007e55d47d1042  vmovaps xmm10, [rsp+0x90]
00007e55d47d104b  vmovaps xmm11, [rsp+0xA0]
00007e55d47d1054  vmovaps xmm12, [rsp+0xB0]
00007e55d47d105d  vmovaps xmm13, [rsp+0xC0]
00007e55d47d1066  vmovaps xmm14, [rsp+0xD0]
00007e55d47d106f  vmovaps xmm15, [rsp+0xE0]
00007e55d47d1078  add rsp, 0xF0
00007e55d47d107f  pop r11
00007e55d47d1081  pop r10
00007e55d47d1083  pop r9
00007e55d47d1085  pop r8
00007e55d47d1087  pop rsi
00007e55d47d1088  pop rdi
00007e55d47d1089  pop rdx
00007e55d47d108a  pop rcx
00007e55d47d108b  pop rax
00007e55d47d108c  add rsp, 0x08
00007e55d47d1090  jmp 0x00007E55D47CF732
00007e55d47d1095  sub rsp, 0x08
00007e55d47d1099  push rax
00007e55d47d109a  push rcx
00007e55d47d109b  push rdx
00007e55d47d109c  push rdi
00007e55d47d109d  push rsi
00007e55d47d109e  push r8
00007e55d47d10a0  push r9
00007e55d47d10a2  push r10
00007e55d47d10a4  push r11
00007e55d47d10a6  sub rsp, 0xF0
00007e55d47d10ad  vmovaps [rsp], xmm0
00007e55d47d10b2  vmovaps [rsp+0x10], xmm1
00007e55d47d10b8  vmovaps [rsp+0x20], xmm2
00007e55d47d10be  vmovaps [rsp+0x30], xmm3
00007e55d47d10c4  vmovaps [rsp+0x40], xmm4
00007e55d47d10ca  vmovaps [rsp+0x50], xmm5
00007e55d47d10d0  vmovaps [rsp+0x60], xmm6
00007e55d47d10d6  vmovaps [rsp+0x70], xmm7
00007e55d47d10dc  vmovaps [rsp+0x80], xmm8
00007e55d47d10e5  vmovaps [rsp+0x90], xmm9
00007e55d47d10ee  vmovaps [rsp+0xA0], xmm10
00007e55d47d10f7  vmovaps [rsp+0xB0], xmm11
00007e55d47d1100  vmovaps [rsp+0xC0], xmm12
00007e55d47d1109  vmovaps [rsp+0xD0], xmm13
00007e55d47d1112  vmovaps [rsp+0xE0], xmm14
00007e55d47d111b  sub rsp, 0x30
00007e55d47d111f  movaps [rsp], xmm15
00007e55d47d1124  movaps [rsp+0x10], xmm10
00007e55d47d112a  movaps [rsp+0x20], xmm12
00007e55d47d1130  lea rdi, [rsp]
00007e55d47d1134  mov esi, 0x00
00007e55d47d1139  mov rax, 0x55D0734A4530
00007e55d47d1143  call rax
00007e55d47d1145  movaps xmm15, [rsp]
00007e55d47d114a  add rsp, 0x30
00007e55d47d114e  vmovaps xmm0, [rsp]
00007e55d47d1153  vmovaps xmm1, [rsp+0x10]
00007e55d47d1159  vmovaps xmm2, [rsp+0x20]
00007e55d47d115f  vmovaps xmm3, [rsp+0x30]
00007e55d47d1165  vmovaps xmm4, [rsp+0x40]
00007e55d47d116b  vmovaps xmm5, [rsp+0x50]
00007e55d47d1171  vmovaps xmm6, [rsp+0x60]
00007e55d47d1177  vmovaps xmm7, [rsp+0x70]
00007e55d47d117d  vmovaps xmm8, [rsp+0x80]
00007e55d47d1186  vmovaps xmm9, [rsp+0x90]
00007e55d47d118f  vmovaps xmm10, [rsp+0xA0]
00007e55d47d1198  vmovaps xmm11, [rsp+0xB0]
00007e55d47d11a1  vmovaps xmm12, [rsp+0xC0]
00007e55d47d11aa  vmovaps xmm13, [rsp+0xD0]
00007e55d47d11b3  vmovaps xmm14, [rsp+0xE0]
00007e55d47d11bc  add rsp, 0xF0
00007e55d47d11c3  pop r11
00007e55d47d11c5  pop r10
00007e55d47d11c7  pop r9
00007e55d47d11c9  pop r8
00007e55d47d11cb  pop rsi
00007e55d47d11cc  pop rdi
00007e55d47d11cd  pop rdx
00007e55d47d11ce  pop rcx
00007e55d47d11cf  pop rax
00007e55d47d11d0  add rsp, 0x08
00007e55d47d11d4  jmp 0x00007E55D47CF75E
00007e55d47d11d9  call 0x00007E55D45FF430
00007e55d47d11de  jmp 0x00007E55D47CF7EE
00007e55d47d11e3  call 0x00007E55D45FF430
00007e55d47d11e8  jmp 0x00007E55D47CF801
00007e55d47d11ed  sub rsp, 0x08
00007e55d47d11f1  push rax
00007e55d47d11f2  push rcx
00007e55d47d11f3  push rdx
00007e55d47d11f4  push rdi
00007e55d47d11f5  push rsi
00007e55d47d11f6  push r8
00007e55d47d11f8  push r9
00007e55d47d11fa  push r10
00007e55d47d11fc  push r11
00007e55d47d11fe  sub rsp, 0xF0
00007e55d47d1205  vmovaps [rsp], xmm0
00007e55d47d120a  vmovaps [rsp+0x10], xmm2
00007e55d47d1210  vmovaps [rsp+0x20], xmm3
00007e55d47d1216  vmovaps [rsp+0x30], xmm4
00007e55d47d121c  vmovaps [rsp+0x40], xmm5
00007e55d47d1222  vmovaps [rsp+0x50], xmm6
00007e55d47d1228  vmovaps [rsp+0x60], xmm7
00007e55d47d122e  vmovaps [rsp+0x70], xmm8
00007e55d47d1234  vmovaps [rsp+0x80], xmm9
00007e55d47d123d  vmovaps [rsp+0x90], xmm10
00007e55d47d1246  vmovaps [rsp+0xA0], xmm11
00007e55d47d124f  vmovaps [rsp+0xB0], xmm12
00007e55d47d1258  vmovaps [rsp+0xC0], xmm13
00007e55d47d1261  vmovaps [rsp+0xD0], xmm14
00007e55d47d126a  vmovaps [rsp+0xE0], xmm15
00007e55d47d1273  sub rsp, 0x30
00007e55d47d1277  movaps [rsp], xmm1
00007e55d47d127b  movaps [rsp+0x10], xmm13
00007e55d47d1281  movaps [rsp+0x20], xmm2
00007e55d47d1286  lea rdi, [rsp]
00007e55d47d128a  mov esi, 0x00
00007e55d47d128f  mov rax, 0x55D0734A4530
00007e55d47d1299  call rax
00007e55d47d129b  movaps xmm1, [rsp]
00007e55d47d129f  add rsp, 0x30
00007e55d47d12a3  vmovaps xmm0, [rsp]
00007e55d47d12a8  vmovaps xmm2, [rsp+0x10]
00007e55d47d12ae  vmovaps xmm3, [rsp+0x20]
00007e55d47d12b4  vmovaps xmm4, [rsp+0x30]
00007e55d47d12ba  vmovaps xmm5, [rsp+0x40]
00007e55d47d12c0  vmovaps xmm6, [rsp+0x50]
00007e55d47d12c6  vmovaps xmm7, [rsp+0x60]
00007e55d47d12cc  vmovaps xmm8, [rsp+0x70]
00007e55d47d12d2  vmovaps xmm9, [rsp+0x80]
00007e55d47d12db  vmovaps xmm10, [rsp+0x90]
00007e55d47d12e4  vmovaps xmm11, [rsp+0xA0]
00007e55d47d12ed  vmovaps xmm12, [rsp+0xB0]
00007e55d47d12f6  vmovaps xmm13, [rsp+0xC0]
00007e55d47d12ff  vmovaps xmm14, [rsp+0xD0]
00007e55d47d1308  vmovaps xmm15, [rsp+0xE0]
00007e55d47d1311  add rsp, 0xF0
00007e55d47d1318  pop r11
00007e55d47d131a  pop r10
00007e55d47d131c  pop r9
00007e55d47d131e  pop r8
00007e55d47d1320  pop rsi
00007e55d47d1321  pop rdi
00007e55d47d1322  pop rdx
00007e55d47d1323  pop rcx
00007e55d47d1324  pop rax
00007e55d47d1325  add rsp, 0x08
00007e55d47d1329  jmp 0x00007E55D47CF82C
00007e55d47d132e  call 0x00007E55D460E760
00007e55d47d1333  jmp 0x00007E55D47CF839
00007e55d47d1338  sub rsp, 0x08
00007e55d47d133c  push rax
00007e55d47d133d  push rcx
00007e55d47d133e  push rdx
00007e55d47d133f  push rdi
00007e55d47d1340  push rsi
00007e55d47d1341  push r8
00007e55d47d1343  push r9
00007e55d47d1345  push r10
00007e55d47d1347  push r11
00007e55d47d1349  sub rsp, 0xF0
00007e55d47d1350  vmovaps [rsp], xmm0
00007e55d47d1355  vmovaps [rsp+0x10], xmm1
00007e55d47d135b  vmovaps [rsp+0x20], xmm2
00007e55d47d1361  vmovaps [rsp+0x30], xmm3
00007e55d47d1367  vmovaps [rsp+0x40], xmm4
00007e55d47d136d  vmovaps [rsp+0x50], xmm5
00007e55d47d1373  vmovaps [rsp+0x60], xmm6
00007e55d47d1379  vmovaps [rsp+0x70], xmm7
00007e55d47d137f  vmovaps [rsp+0x80], xmm8
00007e55d47d1388  vmovaps [rsp+0x90], xmm9
00007e55d47d1391  vmovaps [rsp+0xA0], xmm10
00007e55d47d139a  vmovaps [rsp+0xB0], xmm11
00007e55d47d13a3  vmovaps [rsp+0xC0], xmm12
00007e55d47d13ac  vmovaps [rsp+0xD0], xmm14
00007e55d47d13b5  vmovaps [rsp+0xE0], xmm15
00007e55d47d13be  sub rsp, 0x30
00007e55d47d13c2  movaps [rsp], xmm13
00007e55d47d13c7  movaps [rsp+0x10], xmm2
00007e55d47d13cc  movaps [rsp+0x20], xmm1
00007e55d47d13d1  lea rdi, [rsp]
00007e55d47d13d5  mov esi, 0x00
00007e55d47d13da  mov rax, 0x55D0734A4530
00007e55d47d13e4  call rax
00007e55d47d13e6  movaps xmm13, [rsp]
00007e55d47d13eb  add rsp, 0x30
00007e55d47d13ef  vmovaps xmm0, [rsp]
00007e55d47d13f4  vmovaps xmm1, [rsp+0x10]
00007e55d47d13fa  vmovaps xmm2, [rsp+0x20]
00007e55d47d1400  vmovaps xmm3, [rsp+0x30]
00007e55d47d1406  vmovaps xmm4, [rsp+0x40]
00007e55d47d140c  vmovaps xmm5, [rsp+0x50]
00007e55d47d1412  vmovaps xmm6, [rsp+0x60]
00007e55d47d1418  vmovaps xmm7, [rsp+0x70]
00007e55d47d141e  vmovaps xmm8, [rsp+0x80]
00007e55d47d1427  vmovaps xmm9, [rsp+0x90]
00007e55d47d1430  vmovaps xmm10, [rsp+0xA0]
00007e55d47d1439  vmovaps xmm11, [rsp+0xB0]
00007e55d47d1442  vmovaps xmm12, [rsp+0xC0]
00007e55d47d144b  vmovaps xmm14, [rsp+0xD0]
00007e55d47d1454  vmovaps xmm15, [rsp+0xE0]
00007e55d47d145d  add rsp, 0xF0
00007e55d47d1464  pop r11
00007e55d47d1466  pop r10
00007e55d47d1468  pop r9
00007e55d47d146a  pop r8
00007e55d47d146c  pop rsi
00007e55d47d146d  pop rdi
00007e55d47d146e  pop rdx
00007e55d47d146f  pop rcx
00007e55d47d1470  pop rax
00007e55d47d1471  add rsp, 0x08
00007e55d47d1475  jmp 0x00007E55D47CF878
00007e55d47d147a  sub rsp, 0x08
00007e55d47d147e  push rax
00007e55d47d147f  push rcx
00007e55d47d1480  push rdx
00007e55d47d1481  push rdi
00007e55d47d1482  push rsi
00007e55d47d1483  push r8
00007e55d47d1485  push r9
00007e55d47d1487  push r10
00007e55d47d1489  push r11
00007e55d47d148b  sub rsp, 0xF0
00007e55d47d1492  vmovaps [rsp], xmm0
00007e55d47d1497  vmovaps [rsp+0x10], xmm2
00007e55d47d149d  vmovaps [rsp+0x20], xmm3
00007e55d47d14a3  vmovaps [rsp+0x30], xmm4
00007e55d47d14a9  vmovaps [rsp+0x40], xmm5
00007e55d47d14af  vmovaps [rsp+0x50], xmm6
00007e55d47d14b5  vmovaps [rsp+0x60], xmm7
00007e55d47d14bb  vmovaps [rsp+0x70], xmm8
00007e55d47d14c1  vmovaps [rsp+0x80], xmm9
00007e55d47d14ca  vmovaps [rsp+0x90], xmm10
00007e55d47d14d3  vmovaps [rsp+0xA0], xmm11
00007e55d47d14dc  vmovaps [rsp+0xB0], xmm12
00007e55d47d14e5  vmovaps [rsp+0xC0], xmm13
00007e55d47d14ee  vmovaps [rsp+0xD0], xmm14
00007e55d47d14f7  vmovaps [rsp+0xE0], xmm15
00007e55d47d1500  sub rsp, 0x30
00007e55d47d1504  movaps [rsp], xmm1
00007e55d47d1508  movaps [rsp+0x10], xmm15
00007e55d47d150e  movaps [rsp+0x20], xmm2
00007e55d47d1513  lea rdi, [rsp]
00007e55d47d1517  mov esi, 0x00
00007e55d47d151c  mov rax, 0x55D0734A4530
00007e55d47d1526  call rax
00007e55d47d1528  movaps xmm1, [rsp]
00007e55d47d152c  add rsp, 0x30
00007e55d47d1530  vmovaps xmm0, [rsp]
00007e55d47d1535  vmovaps xmm2, [rsp+0x10]
00007e55d47d153b  vmovaps xmm3, [rsp+0x20]
00007e55d47d1541  vmovaps xmm4, [rsp+0x30]
00007e55d47d1547  vmovaps xmm5, [rsp+0x40]
00007e55d47d154d  vmovaps xmm6, [rsp+0x50]
00007e55d47d1553  vmovaps xmm7, [rsp+0x60]
00007e55d47d1559  vmovaps xmm8, [rsp+0x70]
00007e55d47d155f  vmovaps xmm9, [rsp+0x80]
00007e55d47d1568  vmovaps xmm10, [rsp+0x90]
00007e55d47d1571  vmovaps xmm11, [rsp+0xA0]
00007e55d47d157a  vmovaps xmm12, [rsp+0xB0]
00007e55d47d1583  vmovaps xmm13, [rsp+0xC0]
00007e55d47d158c  vmovaps xmm14, [rsp+0xD0]
00007e55d47d1595  vmovaps xmm15, [rsp+0xE0]
00007e55d47d159e  add rsp, 0xF0
00007e55d47d15a5  pop r11
00007e55d47d15a7  pop r10
00007e55d47d15a9  pop r9
00007e55d47d15ab  pop r8
00007e55d47d15ad  pop rsi
00007e55d47d15ae  pop rdi
00007e55d47d15af  pop rdx
00007e55d47d15b0  pop rcx
00007e55d47d15b1  pop rax
00007e55d47d15b2  add rsp, 0x08
00007e55d47d15b6  jmp 0x00007E55D47CF8AC
00007e55d47d15bb  sub rsp, 0x08
00007e55d47d15bf  push rax
00007e55d47d15c0  push rcx
00007e55d47d15c1  push rdx
00007e55d47d15c2  push rdi
00007e55d47d15c3  push rsi
00007e55d47d15c4  push r8
00007e55d47d15c6  push r9
00007e55d47d15c8  push r10
00007e55d47d15ca  push r11
00007e55d47d15cc  sub rsp, 0xF0
00007e55d47d15d3  vmovaps [rsp], xmm0
00007e55d47d15d8  vmovaps [rsp+0x10], xmm1
00007e55d47d15de  vmovaps [rsp+0x20], xmm2
00007e55d47d15e4  vmovaps [rsp+0x30], xmm3
00007e55d47d15ea  vmovaps [rsp+0x40], xmm4
00007e55d47d15f0  vmovaps [rsp+0x50], xmm5
00007e55d47d15f6  vmovaps [rsp+0x60], xmm6
00007e55d47d15fc  vmovaps [rsp+0x70], xmm7
00007e55d47d1602  vmovaps [rsp+0x80], xmm8
00007e55d47d160b  vmovaps [rsp+0x90], xmm9
00007e55d47d1614  vmovaps [rsp+0xA0], xmm10
00007e55d47d161d  vmovaps [rsp+0xB0], xmm11
00007e55d47d1626  vmovaps [rsp+0xC0], xmm12
00007e55d47d162f  vmovaps [rsp+0xD0], xmm13
00007e55d47d1638  vmovaps [rsp+0xE0], xmm15
00007e55d47d1641  sub rsp, 0x30
00007e55d47d1645  movaps [rsp], xmm14
00007e55d47d164a  movaps [rsp+0x10], xmm2
00007e55d47d164f  movaps [rsp+0x20], xmm15
00007e55d47d1655  lea rdi, [rsp]
00007e55d47d1659  mov esi, 0x00
00007e55d47d165e  mov rax, 0x55D0734A4530
00007e55d47d1668  call rax
00007e55d47d166a  movaps xmm14, [rsp]
00007e55d47d166f  add rsp, 0x30
00007e55d47d1673  vmovaps xmm0, [rsp]
00007e55d47d1678  vmovaps xmm1, [rsp+0x10]
00007e55d47d167e  vmovaps xmm2, [rsp+0x20]
00007e55d47d1684  vmovaps xmm3, [rsp+0x30]
00007e55d47d168a  vmovaps xmm4, [rsp+0x40]
00007e55d47d1690  vmovaps xmm5, [rsp+0x50]
00007e55d47d1696  vmovaps xmm6, [rsp+0x60]
00007e55d47d169c  vmovaps xmm7, [rsp+0x70]
00007e55d47d16a2  vmovaps xmm8, [rsp+0x80]
00007e55d47d16ab  vmovaps xmm9, [rsp+0x90]
00007e55d47d16b4  vmovaps xmm10, [rsp+0xA0]
00007e55d47d16bd  vmovaps xmm11, [rsp+0xB0]
00007e55d47d16c6  vmovaps xmm12, [rsp+0xC0]
00007e55d47d16cf  vmovaps xmm13, [rsp+0xD0]
00007e55d47d16d8  vmovaps xmm15, [rsp+0xE0]
00007e55d47d16e1  add rsp, 0xF0
00007e55d47d16e8  pop r11
00007e55d47d16ea  pop r10
00007e55d47d16ec  pop r9
00007e55d47d16ee  pop r8
00007e55d47d16f0  pop rsi
00007e55d47d16f1  pop rdi
00007e55d47d16f2  pop rdx
00007e55d47d16f3  pop rcx
00007e55d47d16f4  pop rax
00007e55d47d16f5  add rsp, 0x08
00007e55d47d16f9  jmp 0x00007E55D47CF8E7
00007e55d47d16fe  sub rsp, 0x08
00007e55d47d1702  push rax
00007e55d47d1703  push rcx
00007e55d47d1704  push rdx
00007e55d47d1705  push rdi
00007e55d47d1706  push rsi
00007e55d47d1707  push r8
00007e55d47d1709  push r9
00007e55d47d170b  push r10
00007e55d47d170d  push r11
00007e55d47d170f  sub rsp, 0xF0
00007e55d47d1716  vmovaps [rsp], xmm0
00007e55d47d171b  vmovaps [rsp+0x10], xmm1
00007e55d47d1721  vmovaps [rsp+0x20], xmm2
00007e55d47d1727  vmovaps [rsp+0x30], xmm3
00007e55d47d172d  vmovaps [rsp+0x40], xmm4
00007e55d47d1733  vmovaps [rsp+0x50], xmm5
00007e55d47d1739  vmovaps [rsp+0x60], xmm6
00007e55d47d173f  vmovaps [rsp+0x70], xmm7
00007e55d47d1745  vmovaps [rsp+0x80], xmm8
00007e55d47d174e  vmovaps [rsp+0x90], xmm9
00007e55d47d1757  vmovaps [rsp+0xA0], xmm10
00007e55d47d1760  vmovaps [rsp+0xB0], xmm11
00007e55d47d1769  vmovaps [rsp+0xC0], xmm12
00007e55d47d1772  vmovaps [rsp+0xD0], xmm13
00007e55d47d177b  vmovaps [rsp+0xE0], xmm14
00007e55d47d1784  sub rsp, 0x30
00007e55d47d1788  movaps [rsp], xmm15
00007e55d47d178d  movaps [rsp+0x10], xmm2
00007e55d47d1792  movaps [rsp+0x20], xmm1
00007e55d47d1797  lea rdi, [rsp]
00007e55d47d179b  mov esi, 0x00
00007e55d47d17a0  mov rax, 0x55D0734A4530
00007e55d47d17aa  call rax
00007e55d47d17ac  movaps xmm15, [rsp]
00007e55d47d17b1  add rsp, 0x30
00007e55d47d17b5  vmovaps xmm0, [rsp]
00007e55d47d17ba  vmovaps xmm1, [rsp+0x10]
00007e55d47d17c0  vmovaps xmm2, [rsp+0x20]
00007e55d47d17c6  vmovaps xmm3, [rsp+0x30]
00007e55d47d17cc  vmovaps xmm4, [rsp+0x40]
00007e55d47d17d2  vmovaps xmm5, [rsp+0x50]
00007e55d47d17d8  vmovaps xmm6, [rsp+0x60]
00007e55d47d17de  vmovaps xmm7, [rsp+0x70]
00007e55d47d17e4  vmovaps xmm8, [rsp+0x80]
00007e55d47d17ed  vmovaps xmm9, [rsp+0x90]
00007e55d47d17f6  vmovaps xmm10, [rsp+0xA0]
00007e55d47d17ff  vmovaps xmm11, [rsp+0xB0]
00007e55d47d1808  vmovaps xmm12, [rsp+0xC0]
00007e55d47d1811  vmovaps xmm13, [rsp+0xD0]
00007e55d47d181a  vmovaps xmm14, [rsp+0xE0]
00007e55d47d1823  add rsp, 0xF0
00007e55d47d182a  pop r11
00007e55d47d182c  pop r10
00007e55d47d182e  pop r9
00007e55d47d1830  pop r8
00007e55d47d1832  pop rsi
00007e55d47d1833  pop rdi
00007e55d47d1834  pop rdx
00007e55d47d1835  pop rcx
00007e55d47d1836  pop rax
00007e55d47d1837  add rsp, 0x08
00007e55d47d183b  jmp 0x00007E55D47CF923
00007e55d47d1840  call 0x00007E55D45FF430
00007e55d47d1845  jmp 0x00007E55D47CF930
00007e55d47d184a  sub rsp, 0x08
00007e55d47d184e  push rax
00007e55d47d184f  push rcx
00007e55d47d1850  push rdx
00007e55d47d1851  push rdi
00007e55d47d1852  push rsi
00007e55d47d1853  push r8
00007e55d47d1855  push r9
00007e55d47d1857  push r10
00007e55d47d1859  push r11
00007e55d47d185b  sub rsp, 0xF0
00007e55d47d1862  vmovaps [rsp], xmm0
00007e55d47d1867  vmovaps [rsp+0x10], xmm1
00007e55d47d186d  vmovaps [rsp+0x20], xmm3
00007e55d47d1873  vmovaps [rsp+0x30], xmm4
00007e55d47d1879  vmovaps [rsp+0x40], xmm5
00007e55d47d187f  vmovaps [rsp+0x50], xmm6
00007e55d47d1885  vmovaps [rsp+0x60], xmm7
00007e55d47d188b  vmovaps [rsp+0x70], xmm8
00007e55d47d1891  vmovaps [rsp+0x80], xmm9
00007e55d47d189a  vmovaps [rsp+0x90], xmm10
00007e55d47d18a3  vmovaps [rsp+0xA0], xmm11
00007e55d47d18ac  vmovaps [rsp+0xB0], xmm12
00007e55d47d18b5  vmovaps [rsp+0xC0], xmm13
00007e55d47d18be  vmovaps [rsp+0xD0], xmm14
00007e55d47d18c7  vmovaps [rsp+0xE0], xmm15
00007e55d47d18d0  sub rsp, 0x30
00007e55d47d18d4  movaps [rsp], xmm2
00007e55d47d18d8  movaps [rsp+0x10], xmm1
00007e55d47d18dd  movaps [rsp+0x20], xmm14
00007e55d47d18e3  lea rdi, [rsp]
00007e55d47d18e7  mov esi, 0x00
00007e55d47d18ec  mov rax, 0x55D0734A4530
00007e55d47d18f6  call rax
00007e55d47d18f8  movaps xmm2, [rsp]
00007e55d47d18fc  add rsp, 0x30
00007e55d47d1900  vmovaps xmm0, [rsp]
00007e55d47d1905  vmovaps xmm1, [rsp+0x10]
00007e55d47d190b  vmovaps xmm3, [rsp+0x20]
00007e55d47d1911  vmovaps xmm4, [rsp+0x30]
00007e55d47d1917  vmovaps xmm5, [rsp+0x40]
00007e55d47d191d  vmovaps xmm6, [rsp+0x50]
00007e55d47d1923  vmovaps xmm7, [rsp+0x60]
00007e55d47d1929  vmovaps xmm8, [rsp+0x70]
00007e55d47d192f  vmovaps xmm9, [rsp+0x80]
00007e55d47d1938  vmovaps xmm10, [rsp+0x90]
00007e55d47d1941  vmovaps xmm11, [rsp+0xA0]
00007e55d47d194a  vmovaps xmm12, [rsp+0xB0]
00007e55d47d1953  vmovaps xmm13, [rsp+0xC0]
00007e55d47d195c  vmovaps xmm14, [rsp+0xD0]
00007e55d47d1965  vmovaps xmm15, [rsp+0xE0]
00007e55d47d196e  add rsp, 0xF0
00007e55d47d1975  pop r11
00007e55d47d1977  pop r10
00007e55d47d1979  pop r9
00007e55d47d197b  pop r8
00007e55d47d197d  pop rsi
00007e55d47d197e  pop rdi
00007e55d47d197f  pop rdx
00007e55d47d1980  pop rcx
00007e55d47d1981  pop rax
00007e55d47d1982  add rsp, 0x08
00007e55d47d1986  jmp 0x00007E55D47CF96D
00007e55d47d198b  sub rsp, 0x08
00007e55d47d198f  push rax
00007e55d47d1990  push rcx
00007e55d47d1991  push rdx
00007e55d47d1992  push rdi
00007e55d47d1993  push rsi
00007e55d47d1994  push r8
00007e55d47d1996  push r9
00007e55d47d1998  push r10
00007e55d47d199a  push r11
00007e55d47d199c  sub rsp, 0xF0
00007e55d47d19a3  vmovaps [rsp], xmm0
00007e55d47d19a8  vmovaps [rsp+0x10], xmm1
00007e55d47d19ae  vmovaps [rsp+0x20], xmm2
00007e55d47d19b4  vmovaps [rsp+0x30], xmm3
00007e55d47d19ba  vmovaps [rsp+0x40], xmm4
00007e55d47d19c0  vmovaps [rsp+0x50], xmm5
00007e55d47d19c6  vmovaps [rsp+0x60], xmm6
00007e55d47d19cc  vmovaps [rsp+0x70], xmm7
00007e55d47d19d2  vmovaps [rsp+0x80], xmm8
00007e55d47d19db  vmovaps [rsp+0x90], xmm9
00007e55d47d19e4  vmovaps [rsp+0xA0], xmm10
00007e55d47d19ed  vmovaps [rsp+0xB0], xmm11
00007e55d47d19f6  vmovaps [rsp+0xC0], xmm12
00007e55d47d19ff  vmovaps [rsp+0xD0], xmm13
00007e55d47d1a08  vmovaps [rsp+0xE0], xmm14
00007e55d47d1a11  sub rsp, 0x30
00007e55d47d1a15  movaps [rsp], xmm15
00007e55d47d1a1a  movaps [rsp+0x10], xmm14
00007e55d47d1a20  movaps [rsp+0x20], xmm1
00007e55d47d1a25  lea rdi, [rsp]
00007e55d47d1a29  mov esi, 0x00
00007e55d47d1a2e  mov rax, 0x55D0734A4530
00007e55d47d1a38  call rax
00007e55d47d1a3a  movaps xmm15, [rsp]
00007e55d47d1a3f  add rsp, 0x30
00007e55d47d1a43  vmovaps xmm0, [rsp]
00007e55d47d1a48  vmovaps xmm1, [rsp+0x10]
00007e55d47d1a4e  vmovaps xmm2, [rsp+0x20]
00007e55d47d1a54  vmovaps xmm3, [rsp+0x30]
00007e55d47d1a5a  vmovaps xmm4, [rsp+0x40]
00007e55d47d1a60  vmovaps xmm5, [rsp+0x50]
00007e55d47d1a66  vmovaps xmm6, [rsp+0x60]
00007e55d47d1a6c  vmovaps xmm7, [rsp+0x70]
00007e55d47d1a72  vmovaps xmm8, [rsp+0x80]
00007e55d47d1a7b  vmovaps xmm9, [rsp+0x90]
00007e55d47d1a84  vmovaps xmm10, [rsp+0xA0]
00007e55d47d1a8d  vmovaps xmm11, [rsp+0xB0]
00007e55d47d1a96  vmovaps xmm12, [rsp+0xC0]
00007e55d47d1a9f  vmovaps xmm13, [rsp+0xD0]
00007e55d47d1aa8  vmovaps xmm14, [rsp+0xE0]
00007e55d47d1ab1  add rsp, 0xF0
00007e55d47d1ab8  pop r11
00007e55d47d1aba  pop r10
00007e55d47d1abc  pop r9
00007e55d47d1abe  pop r8
00007e55d47d1ac0  pop rsi
00007e55d47d1ac1  pop rdi
00007e55d47d1ac2  pop rdx
00007e55d47d1ac3  pop rcx
00007e55d47d1ac4  pop rax
00007e55d47d1ac5  add rsp, 0x08
00007e55d47d1ac9  jmp 0x00007E55D47CF9E7
00007e55d47d1ace  call 0x00007E55D45FF430
00007e55d47d1ad3  jmp 0x00007E55D47CF9F4
00007e55d47d1ad8  sub rsp, 0x08
00007e55d47d1adc  push rax
00007e55d47d1add  push rcx
00007e55d47d1ade  push rdx
00007e55d47d1adf  push rdi
00007e55d47d1ae0  push rsi
00007e55d47d1ae1  push r8
00007e55d47d1ae3  push r9
00007e55d47d1ae5  push r10
00007e55d47d1ae7  push r11
00007e55d47d1ae9  sub rsp, 0xF0
00007e55d47d1af0  vmovaps [rsp], xmm0
00007e55d47d1af5  vmovaps [rsp+0x10], xmm1
00007e55d47d1afb  vmovaps [rsp+0x20], xmm2
00007e55d47d1b01  vmovaps [rsp+0x30], xmm3
00007e55d47d1b07  vmovaps [rsp+0x40], xmm4
00007e55d47d1b0d  vmovaps [rsp+0x50], xmm5
00007e55d47d1b13  vmovaps [rsp+0x60], xmm6
00007e55d47d1b19  vmovaps [rsp+0x70], xmm7
00007e55d47d1b1f  vmovaps [rsp+0x80], xmm8
00007e55d47d1b28  vmovaps [rsp+0x90], xmm9
00007e55d47d1b31  vmovaps [rsp+0xA0], xmm10
00007e55d47d1b3a  vmovaps [rsp+0xB0], xmm11
00007e55d47d1b43  vmovaps [rsp+0xC0], xmm12
00007e55d47d1b4c  vmovaps [rsp+0xD0], xmm13
00007e55d47d1b55  vmovaps [rsp+0xE0], xmm15
00007e55d47d1b5e  sub rsp, 0x30
00007e55d47d1b62  movaps [rsp], xmm14
00007e55d47d1b67  movaps [rsp+0x10], xmm13
00007e55d47d1b6d  movaps [rsp+0x20], xmm1
00007e55d47d1b72  lea rdi, [rsp]
00007e55d47d1b76  mov esi, 0x00
00007e55d47d1b7b  mov rax, 0x55D0734A4530
00007e55d47d1b85  call rax
00007e55d47d1b87  movaps xmm14, [rsp]
00007e55d47d1b8c  add rsp, 0x30
00007e55d47d1b90  vmovaps xmm0, [rsp]
00007e55d47d1b95  vmovaps xmm1, [rsp+0x10]
00007e55d47d1b9b  vmovaps xmm2, [rsp+0x20]
00007e55d47d1ba1  vmovaps xmm3, [rsp+0x30]
00007e55d47d1ba7  vmovaps xmm4, [rsp+0x40]
00007e55d47d1bad  vmovaps xmm5, [rsp+0x50]
00007e55d47d1bb3  vmovaps xmm6, [rsp+0x60]
00007e55d47d1bb9  vmovaps xmm7, [rsp+0x70]
00007e55d47d1bbf  vmovaps xmm8, [rsp+0x80]
00007e55d47d1bc8  vmovaps xmm9, [rsp+0x90]
00007e55d47d1bd1  vmovaps xmm10, [rsp+0xA0]
00007e55d47d1bda  vmovaps xmm11, [rsp+0xB0]
00007e55d47d1be3  vmovaps xmm12, [rsp+0xC0]
00007e55d47d1bec  vmovaps xmm13, [rsp+0xD0]
00007e55d47d1bf5  vmovaps xmm15, [rsp+0xE0]
00007e55d47d1bfe  add rsp, 0xF0
00007e55d47d1c05  pop r11
00007e55d47d1c07  pop r10
00007e55d47d1c09  pop r9
00007e55d47d1c0b  pop r8
00007e55d47d1c0d  pop rsi
00007e55d47d1c0e  pop rdi
00007e55d47d1c0f  pop rdx
00007e55d47d1c10  pop rcx
00007e55d47d1c11  pop rax
00007e55d47d1c12  add rsp, 0x08
00007e55d47d1c16  jmp 0x00007E55D47CFAAF
00007e55d47d1c1b  sub rsp, 0x08
00007e55d47d1c1f  push rax
00007e55d47d1c20  push rcx
00007e55d47d1c21  push rdx
00007e55d47d1c22  push rdi
00007e55d47d1c23  push rsi
00007e55d47d1c24  push r8
00007e55d47d1c26  push r9
00007e55d47d1c28  push r10
00007e55d47d1c2a  push r11
00007e55d47d1c2c  sub rsp, 0xF0
00007e55d47d1c33  vmovaps [rsp], xmm0
00007e55d47d1c38  vmovaps [rsp+0x10], xmm1
00007e55d47d1c3e  vmovaps [rsp+0x20], xmm2
00007e55d47d1c44  vmovaps [rsp+0x30], xmm3
00007e55d47d1c4a  vmovaps [rsp+0x40], xmm4
00007e55d47d1c50  vmovaps [rsp+0x50], xmm5
00007e55d47d1c56  vmovaps [rsp+0x60], xmm6
00007e55d47d1c5c  vmovaps [rsp+0x70], xmm7
00007e55d47d1c62  vmovaps [rsp+0x80], xmm8
00007e55d47d1c6b  vmovaps [rsp+0x90], xmm9
00007e55d47d1c74  vmovaps [rsp+0xA0], xmm10
00007e55d47d1c7d  vmovaps [rsp+0xB0], xmm11
00007e55d47d1c86  vmovaps [rsp+0xC0], xmm12
00007e55d47d1c8f  vmovaps [rsp+0xD0], xmm13
00007e55d47d1c98  vmovaps [rsp+0xE0], xmm14
00007e55d47d1ca1  sub rsp, 0x30
00007e55d47d1ca5  movaps [rsp], xmm15
00007e55d47d1caa  movaps [rsp+0x10], xmm13
00007e55d47d1cb0  movaps [rsp+0x20], xmm1
00007e55d47d1cb5  lea rdi, [rsp]
00007e55d47d1cb9  mov esi, 0x00
00007e55d47d1cbe  mov rax, 0x55D0734A4530
00007e55d47d1cc8  call rax
00007e55d47d1cca  movaps xmm15, [rsp]
00007e55d47d1ccf  add rsp, 0x30
00007e55d47d1cd3  vmovaps xmm0, [rsp]
00007e55d47d1cd8  vmovaps xmm1, [rsp+0x10]
00007e55d47d1cde  vmovaps xmm2, [rsp+0x20]
00007e55d47d1ce4  vmovaps xmm3, [rsp+0x30]
00007e55d47d1cea  vmovaps xmm4, [rsp+0x40]
00007e55d47d1cf0  vmovaps xmm5, [rsp+0x50]
00007e55d47d1cf6  vmovaps xmm6, [rsp+0x60]
00007e55d47d1cfc  vmovaps xmm7, [rsp+0x70]
00007e55d47d1d02  vmovaps xmm8, [rsp+0x80]
00007e55d47d1d0b  vmovaps xmm9, [rsp+0x90]
00007e55d47d1d14  vmovaps xmm10, [rsp+0xA0]
00007e55d47d1d1d  vmovaps xmm11, [rsp+0xB0]
00007e55d47d1d26  vmovaps xmm12, [rsp+0xC0]
00007e55d47d1d2f  vmovaps xmm13, [rsp+0xD0]
00007e55d47d1d38  vmovaps xmm14, [rsp+0xE0]
00007e55d47d1d41  add rsp, 0xF0
00007e55d47d1d48  pop r11
00007e55d47d1d4a  pop r10
00007e55d47d1d4c  pop r9
00007e55d47d1d4e  pop r8
00007e55d47d1d50  pop rsi
00007e55d47d1d51  pop rdi
00007e55d47d1d52  pop rdx
00007e55d47d1d53  pop rcx
00007e55d47d1d54  pop rax
00007e55d47d1d55  add rsp, 0x08
00007e55d47d1d59  jmp 0x00007E55D47CFAEB
00007e55d47d1d5e  call 0x00007E55D45FF430
00007e55d47d1d63  jmp 0x00007E55D47CFAF8
00007e55d47d1d68  sub rsp, 0x08
00007e55d47d1d6c  push rax
00007e55d47d1d6d  push rcx
00007e55d47d1d6e  push rdx
00007e55d47d1d6f  push rdi
00007e55d47d1d70  push rsi
00007e55d47d1d71  push r8
00007e55d47d1d73  push r9
00007e55d47d1d75  push r10
00007e55d47d1d77  push r11
00007e55d47d1d79  sub rsp, 0xF0
00007e55d47d1d80  vmovaps [rsp], xmm0
00007e55d47d1d85  vmovaps [rsp+0x10], xmm1
00007e55d47d1d8b  vmovaps [rsp+0x20], xmm2
00007e55d47d1d91  vmovaps [rsp+0x30], xmm3
00007e55d47d1d97  vmovaps [rsp+0x40], xmm4
00007e55d47d1d9d  vmovaps [rsp+0x50], xmm5
00007e55d47d1da3  vmovaps [rsp+0x60], xmm6
00007e55d47d1da9  vmovaps [rsp+0x70], xmm7
00007e55d47d1daf  vmovaps [rsp+0x80], xmm8
00007e55d47d1db8  vmovaps [rsp+0x90], xmm9
00007e55d47d1dc1  vmovaps [rsp+0xA0], xmm10
00007e55d47d1dca  vmovaps [rsp+0xB0], xmm11
00007e55d47d1dd3  vmovaps [rsp+0xC0], xmm12
00007e55d47d1ddc  vmovaps [rsp+0xD0], xmm13
00007e55d47d1de5  vmovaps [rsp+0xE0], xmm15
00007e55d47d1dee  sub rsp, 0x30
00007e55d47d1df2  movaps [rsp], xmm14
00007e55d47d1df7  movaps [rsp+0x10], xmm13
00007e55d47d1dfd  movaps [rsp+0x20], xmm2
00007e55d47d1e02  lea rdi, [rsp]
00007e55d47d1e06  mov esi, 0x00
00007e55d47d1e0b  mov rax, 0x55D0734A4530
00007e55d47d1e15  call rax
00007e55d47d1e17  movaps xmm14, [rsp]
00007e55d47d1e1c  add rsp, 0x30
00007e55d47d1e20  vmovaps xmm0, [rsp]
00007e55d47d1e25  vmovaps xmm1, [rsp+0x10]
00007e55d47d1e2b  vmovaps xmm2, [rsp+0x20]
00007e55d47d1e31  vmovaps xmm3, [rsp+0x30]
00007e55d47d1e37  vmovaps xmm4, [rsp+0x40]
00007e55d47d1e3d  vmovaps xmm5, [rsp+0x50]
00007e55d47d1e43  vmovaps xmm6, [rsp+0x60]
00007e55d47d1e49  vmovaps xmm7, [rsp+0x70]
00007e55d47d1e4f  vmovaps xmm8, [rsp+0x80]
00007e55d47d1e58  vmovaps xmm9, [rsp+0x90]
00007e55d47d1e61  vmovaps xmm10, [rsp+0xA0]
00007e55d47d1e6a  vmovaps xmm11, [rsp+0xB0]
00007e55d47d1e73  vmovaps xmm12, [rsp+0xC0]
00007e55d47d1e7c  vmovaps xmm13, [rsp+0xD0]
00007e55d47d1e85  vmovaps xmm15, [rsp+0xE0]
00007e55d47d1e8e  add rsp, 0xF0
00007e55d47d1e95  pop r11
00007e55d47d1e97  pop r10
00007e55d47d1e99  pop r9
00007e55d47d1e9b  pop r8
00007e55d47d1e9d  pop rsi
00007e55d47d1e9e  pop rdi
00007e55d47d1e9f  pop rdx
00007e55d47d1ea0  pop rcx
00007e55d47d1ea1  pop rax
00007e55d47d1ea2  add rsp, 0x08
00007e55d47d1ea6  jmp 0x00007E55D47CFB24
00007e55d47d1eab  sub rsp, 0x08
00007e55d47d1eaf  push rax
00007e55d47d1eb0  push rcx
00007e55d47d1eb1  push rdx
00007e55d47d1eb2  push rdi
00007e55d47d1eb3  push rsi
00007e55d47d1eb4  push r8
00007e55d47d1eb6  push r9
00007e55d47d1eb8  push r10
00007e55d47d1eba  push r11
00007e55d47d1ebc  sub rsp, 0xF0
00007e55d47d1ec3  vmovaps [rsp], xmm0
00007e55d47d1ec8  vmovaps [rsp+0x10], xmm2
00007e55d47d1ece  vmovaps [rsp+0x20], xmm3
00007e55d47d1ed4  vmovaps [rsp+0x30], xmm4
00007e55d47d1eda  vmovaps [rsp+0x40], xmm5
00007e55d47d1ee0  vmovaps [rsp+0x50], xmm6
00007e55d47d1ee6  vmovaps [rsp+0x60], xmm7
00007e55d47d1eec  vmovaps [rsp+0x70], xmm8
00007e55d47d1ef2  vmovaps [rsp+0x80], xmm9
00007e55d47d1efb  vmovaps [rsp+0x90], xmm10
00007e55d47d1f04  vmovaps [rsp+0xA0], xmm11
00007e55d47d1f0d  vmovaps [rsp+0xB0], xmm12
00007e55d47d1f16  vmovaps [rsp+0xC0], xmm13
00007e55d47d1f1f  vmovaps [rsp+0xD0], xmm14
00007e55d47d1f28  vmovaps [rsp+0xE0], xmm15
00007e55d47d1f31  sub rsp, 0x30
00007e55d47d1f35  movaps [rsp], xmm1
00007e55d47d1f39  movaps [rsp+0x10], xmm13
00007e55d47d1f3f  movaps [rsp+0x20], xmm2
00007e55d47d1f44  lea rdi, [rsp]
00007e55d47d1f48  mov esi, 0x00
00007e55d47d1f4d  mov rax, 0x55D0734A4530
00007e55d47d1f57  call rax
00007e55d47d1f59  movaps xmm1, [rsp]
00007e55d47d1f5d  add rsp, 0x30
00007e55d47d1f61  vmovaps xmm0, [rsp]
00007e55d47d1f66  vmovaps xmm2, [rsp+0x10]
00007e55d47d1f6c  vmovaps xmm3, [rsp+0x20]
00007e55d47d1f72  vmovaps xmm4, [rsp+0x30]
00007e55d47d1f78  vmovaps xmm5, [rsp+0x40]
00007e55d47d1f7e  vmovaps xmm6, [rsp+0x50]
00007e55d47d1f84  vmovaps xmm7, [rsp+0x60]
00007e55d47d1f8a  vmovaps xmm8, [rsp+0x70]
00007e55d47d1f90  vmovaps xmm9, [rsp+0x80]
00007e55d47d1f99  vmovaps xmm10, [rsp+0x90]
00007e55d47d1fa2  vmovaps xmm11, [rsp+0xA0]
00007e55d47d1fab  vmovaps xmm12, [rsp+0xB0]
00007e55d47d1fb4  vmovaps xmm13, [rsp+0xC0]
00007e55d47d1fbd  vmovaps xmm14, [rsp+0xD0]
00007e55d47d1fc6  vmovaps xmm15, [rsp+0xE0]
00007e55d47d1fcf  add rsp, 0xF0
00007e55d47d1fd6  pop r11
00007e55d47d1fd8  pop r10
00007e55d47d1fda  pop r9
00007e55d47d1fdc  pop r8
00007e55d47d1fde  pop rsi
00007e55d47d1fdf  pop rdi
00007e55d47d1fe0  pop rdx
00007e55d47d1fe1  pop rcx
00007e55d47d1fe2  pop rax
00007e55d47d1fe3  add rsp, 0x08
00007e55d47d1fe7  jmp 0x00007E55D47CFB52
00007e55d47d1fec  sub rsp, 0x08
00007e55d47d1ff0  push rax
00007e55d47d1ff1  push rcx
00007e55d47d1ff2  push rdx
00007e55d47d1ff3  push rdi
00007e55d47d1ff4  push rsi
00007e55d47d1ff5  push r8
00007e55d47d1ff7  push r9
00007e55d47d1ff9  push r10
00007e55d47d1ffb  push r11
00007e55d47d1ffd  sub rsp, 0xF0
00007e55d47d2004  vmovaps [rsp], xmm0
00007e55d47d2009  vmovaps [rsp+0x10], xmm1
00007e55d47d200f  vmovaps [rsp+0x20], xmm3
00007e55d47d2015  vmovaps [rsp+0x30], xmm4
00007e55d47d201b  vmovaps [rsp+0x40], xmm5
00007e55d47d2021  vmovaps [rsp+0x50], xmm6
00007e55d47d2027  vmovaps [rsp+0x60], xmm7
00007e55d47d202d  vmovaps [rsp+0x70], xmm8
00007e55d47d2033  vmovaps [rsp+0x80], xmm9
00007e55d47d203c  vmovaps [rsp+0x90], xmm10
00007e55d47d2045  vmovaps [rsp+0xA0], xmm11
00007e55d47d204e  vmovaps [rsp+0xB0], xmm12
00007e55d47d2057  vmovaps [rsp+0xC0], xmm13
00007e55d47d2060  vmovaps [rsp+0xD0], xmm14
00007e55d47d2069  vmovaps [rsp+0xE0], xmm15
00007e55d47d2072  sub rsp, 0x30
00007e55d47d2076  movaps [rsp], xmm2
00007e55d47d207a  movaps [rsp+0x10], xmm1
00007e55d47d207f  movaps [rsp+0x20], xmm13
00007e55d47d2085  lea rdi, [rsp]
00007e55d47d2089  mov esi, 0x00
00007e55d47d208e  mov rax, 0x55D0734A4530
00007e55d47d2098  call rax
00007e55d47d209a  movaps xmm2, [rsp]
00007e55d47d209e  add rsp, 0x30
00007e55d47d20a2  vmovaps xmm0, [rsp]
00007e55d47d20a7  vmovaps xmm1, [rsp+0x10]
00007e55d47d20ad  vmovaps xmm3, [rsp+0x20]
00007e55d47d20b3  vmovaps xmm4, [rsp+0x30]
00007e55d47d20b9  vmovaps xmm5, [rsp+0x40]
00007e55d47d20bf  vmovaps xmm6, [rsp+0x50]
00007e55d47d20c5  vmovaps xmm7, [rsp+0x60]
00007e55d47d20cb  vmovaps xmm8, [rsp+0x70]
00007e55d47d20d1  vmovaps xmm9, [rsp+0x80]
00007e55d47d20da  vmovaps xmm10, [rsp+0x90]
00007e55d47d20e3  vmovaps xmm11, [rsp+0xA0]
00007e55d47d20ec  vmovaps xmm12, [rsp+0xB0]
00007e55d47d20f5  vmovaps xmm13, [rsp+0xC0]
00007e55d47d20fe  vmovaps xmm14, [rsp+0xD0]
00007e55d47d2107  vmovaps xmm15, [rsp+0xE0]
00007e55d47d2110  add rsp, 0xF0
00007e55d47d2117  pop r11
00007e55d47d2119  pop r10
00007e55d47d211b  pop r9
00007e55d47d211d  pop r8
00007e55d47d211f  pop rsi
00007e55d47d2120  pop rdi
00007e55d47d2121  pop rdx
00007e55d47d2122  pop rcx
00007e55d47d2123  pop rax
00007e55d47d2124  add rsp, 0x08
00007e55d47d2128  jmp 0x00007E55D47CFBAB
00007e55d47d212d  call 0x00007E55D45FF430
00007e55d47d2132  jmp 0x00007E55D47CFBB8
00007e55d47d2137  sub rsp, 0x08
00007e55d47d213b  push rax
00007e55d47d213c  push rcx
00007e55d47d213d  push rdx
00007e55d47d213e  push rdi
00007e55d47d213f  push rsi
00007e55d47d2140  push r8
00007e55d47d2142  push r9
00007e55d47d2144  push r10
00007e55d47d2146  push r11
00007e55d47d2148  sub rsp, 0xF0
00007e55d47d214f  vmovaps [rsp], xmm0
00007e55d47d2154  vmovaps [rsp+0x10], xmm1
00007e55d47d215a  vmovaps [rsp+0x20], xmm2
00007e55d47d2160  vmovaps [rsp+0x30], xmm3
00007e55d47d2166  vmovaps [rsp+0x40], xmm4
00007e55d47d216c  vmovaps [rsp+0x50], xmm5
00007e55d47d2172  vmovaps [rsp+0x60], xmm6
00007e55d47d2178  vmovaps [rsp+0x70], xmm7
00007e55d47d217e  vmovaps [rsp+0x80], xmm8
00007e55d47d2187  vmovaps [rsp+0x90], xmm9
00007e55d47d2190  vmovaps [rsp+0xA0], xmm10
00007e55d47d2199  vmovaps [rsp+0xB0], xmm11
00007e55d47d21a2  vmovaps [rsp+0xC0], xmm12
00007e55d47d21ab  vmovaps [rsp+0xD0], xmm13
00007e55d47d21b4  vmovaps [rsp+0xE0], xmm14
00007e55d47d21bd  sub rsp, 0x30
00007e55d47d21c1  movaps [rsp], xmm15
00007e55d47d21c6  movaps [rsp+0x10], xmm13
00007e55d47d21cc  movaps [rsp+0x20], xmm1
00007e55d47d21d1  lea rdi, [rsp]
00007e55d47d21d5  mov esi, 0x00
00007e55d47d21da  mov rax, 0x55D0734A4530
00007e55d47d21e4  call rax
00007e55d47d21e6  movaps xmm15, [rsp]
00007e55d47d21eb  add rsp, 0x30
00007e55d47d21ef  vmovaps xmm0, [rsp]
00007e55d47d21f4  vmovaps xmm1, [rsp+0x10]
00007e55d47d21fa  vmovaps xmm2, [rsp+0x20]
00007e55d47d2200  vmovaps xmm3, [rsp+0x30]
00007e55d47d2206  vmovaps xmm4, [rsp+0x40]
00007e55d47d220c  vmovaps xmm5, [rsp+0x50]
00007e55d47d2212  vmovaps xmm6, [rsp+0x60]
00007e55d47d2218  vmovaps xmm7, [rsp+0x70]
00007e55d47d221e  vmovaps xmm8, [rsp+0x80]
00007e55d47d2227  vmovaps xmm9, [rsp+0x90]
00007e55d47d2230  vmovaps xmm10, [rsp+0xA0]
00007e55d47d2239  vmovaps xmm11, [rsp+0xB0]
00007e55d47d2242  vmovaps xmm12, [rsp+0xC0]
00007e55d47d224b  vmovaps xmm13, [rsp+0xD0]
00007e55d47d2254  vmovaps xmm14, [rsp+0xE0]
00007e55d47d225d  add rsp, 0xF0
00007e55d47d2264  pop r11
00007e55d47d2266  pop r10
00007e55d47d2268  pop r9
00007e55d47d226a  pop r8
00007e55d47d226c  pop rsi
00007e55d47d226d  pop rdi
00007e55d47d226e  pop rdx
00007e55d47d226f  pop rcx
00007e55d47d2270  pop rax
00007e55d47d2271  add rsp, 0x08
00007e55d47d2275  jmp 0x00007E55D47CFBF7
00007e55d47d227a  sub rsp, 0x08
00007e55d47d227e  push rax
00007e55d47d227f  push rcx
00007e55d47d2280  push rdx
00007e55d47d2281  push rdi
00007e55d47d2282  push rsi
00007e55d47d2283  push r8
00007e55d47d2285  push r9
00007e55d47d2287  push r10
00007e55d47d2289  push r11
00007e55d47d228b  sub rsp, 0xF0
00007e55d47d2292  vmovaps [rsp], xmm0
00007e55d47d2297  vmovaps [rsp+0x10], xmm1
00007e55d47d229d  vmovaps [rsp+0x20], xmm2
00007e55d47d22a3  vmovaps [rsp+0x30], xmm3
00007e55d47d22a9  vmovaps [rsp+0x40], xmm4
00007e55d47d22af  vmovaps [rsp+0x50], xmm5
00007e55d47d22b5  vmovaps [rsp+0x60], xmm6
00007e55d47d22bb  vmovaps [rsp+0x70], xmm7
00007e55d47d22c1  vmovaps [rsp+0x80], xmm8
00007e55d47d22ca  vmovaps [rsp+0x90], xmm9
00007e55d47d22d3  vmovaps [rsp+0xA0], xmm10
00007e55d47d22dc  vmovaps [rsp+0xB0], xmm11
00007e55d47d22e5  vmovaps [rsp+0xC0], xmm12
00007e55d47d22ee  vmovaps [rsp+0xD0], xmm13
00007e55d47d22f7  vmovaps [rsp+0xE0], xmm15
00007e55d47d2300  sub rsp, 0x30
00007e55d47d2304  movaps [rsp], xmm14
00007e55d47d2309  movaps [rsp+0x10], xmm11
00007e55d47d230f  movaps [rsp+0x20], xmm1
00007e55d47d2314  lea rdi, [rsp]
00007e55d47d2318  mov esi, 0x00
00007e55d47d231d  mov rax, 0x55D0734A4530
00007e55d47d2327  call rax
00007e55d47d2329  movaps xmm14, [rsp]
00007e55d47d232e  add rsp, 0x30
00007e55d47d2332  vmovaps xmm0, [rsp]
00007e55d47d2337  vmovaps xmm1, [rsp+0x10]
00007e55d47d233d  vmovaps xmm2, [rsp+0x20]
00007e55d47d2343  vmovaps xmm3, [rsp+0x30]
00007e55d47d2349  vmovaps xmm4, [rsp+0x40]
00007e55d47d234f  vmovaps xmm5, [rsp+0x50]
00007e55d47d2355  vmovaps xmm6, [rsp+0x60]
00007e55d47d235b  vmovaps xmm7, [rsp+0x70]
00007e55d47d2361  vmovaps xmm8, [rsp+0x80]
00007e55d47d236a  vmovaps xmm9, [rsp+0x90]
00007e55d47d2373  vmovaps xmm10, [rsp+0xA0]
00007e55d47d237c  vmovaps xmm11, [rsp+0xB0]
00007e55d47d2385  vmovaps xmm12, [rsp+0xC0]
00007e55d47d238e  vmovaps xmm13, [rsp+0xD0]
00007e55d47d2397  vmovaps xmm15, [rsp+0xE0]
00007e55d47d23a0  add rsp, 0xF0
00007e55d47d23a7  pop r11
00007e55d47d23a9  pop r10
00007e55d47d23ab  pop r9
00007e55d47d23ad  pop r8
00007e55d47d23af  pop rsi
00007e55d47d23b0  pop rdi
00007e55d47d23b1  pop rdx
00007e55d47d23b2  pop rcx
00007e55d47d23b3  pop rax
00007e55d47d23b4  add rsp, 0x08
00007e55d47d23b8  jmp 0x00007E55D47CFC21
00007e55d47d23bd  sub rsp, 0x08
00007e55d47d23c1  push rax
00007e55d47d23c2  push rcx
00007e55d47d23c3  push rdx
00007e55d47d23c4  push rdi
00007e55d47d23c5  push rsi
00007e55d47d23c6  push r8
00007e55d47d23c8  push r9
00007e55d47d23ca  push r10
00007e55d47d23cc  push r11
00007e55d47d23ce  sub rsp, 0xF0
00007e55d47d23d5  vmovaps [rsp], xmm0
00007e55d47d23da  vmovaps [rsp+0x10], xmm1
00007e55d47d23e0  vmovaps [rsp+0x20], xmm2
00007e55d47d23e6  vmovaps [rsp+0x30], xmm3
00007e55d47d23ec  vmovaps [rsp+0x40], xmm4
00007e55d47d23f2  vmovaps [rsp+0x50], xmm5
00007e55d47d23f8  vmovaps [rsp+0x60], xmm6
00007e55d47d23fe  vmovaps [rsp+0x70], xmm7
00007e55d47d2404  vmovaps [rsp+0x80], xmm8
00007e55d47d240d  vmovaps [rsp+0x90], xmm9
00007e55d47d2416  vmovaps [rsp+0xA0], xmm10
00007e55d47d241f  vmovaps [rsp+0xB0], xmm11
00007e55d47d2428  vmovaps [rsp+0xC0], xmm12
00007e55d47d2431  vmovaps [rsp+0xD0], xmm14
00007e55d47d243a  vmovaps [rsp+0xE0], xmm15
00007e55d47d2443  sub rsp, 0x30
00007e55d47d2447  movaps [rsp], xmm13
00007e55d47d244c  movaps [rsp+0x10], xmm11
00007e55d47d2452  movaps [rsp+0x20], xmm1
00007e55d47d2457  lea rdi, [rsp]
00007e55d47d245b  mov esi, 0x00
00007e55d47d2460  mov rax, 0x55D0734A4530
00007e55d47d246a  call rax
00007e55d47d246c  movaps xmm13, [rsp]
00007e55d47d2471  add rsp, 0x30
00007e55d47d2475  vmovaps xmm0, [rsp]
00007e55d47d247a  vmovaps xmm1, [rsp+0x10]
00007e55d47d2480  vmovaps xmm2, [rsp+0x20]
00007e55d47d2486  vmovaps xmm3, [rsp+0x30]
00007e55d47d248c  vmovaps xmm4, [rsp+0x40]
00007e55d47d2492  vmovaps xmm5, [rsp+0x50]
00007e55d47d2498  vmovaps xmm6, [rsp+0x60]
00007e55d47d249e  vmovaps xmm7, [rsp+0x70]
00007e55d47d24a4  vmovaps xmm8, [rsp+0x80]
00007e55d47d24ad  vmovaps xmm9, [rsp+0x90]
00007e55d47d24b6  vmovaps xmm10, [rsp+0xA0]
00007e55d47d24bf  vmovaps xmm11, [rsp+0xB0]
00007e55d47d24c8  vmovaps xmm12, [rsp+0xC0]
00007e55d47d24d1  vmovaps xmm14, [rsp+0xD0]
00007e55d47d24da  vmovaps xmm15, [rsp+0xE0]
00007e55d47d24e3  add rsp, 0xF0
00007e55d47d24ea  pop r11
00007e55d47d24ec  pop r10
00007e55d47d24ee  pop r9
00007e55d47d24f0  pop r8
00007e55d47d24f2  pop rsi
00007e55d47d24f3  pop rdi
00007e55d47d24f4  pop rdx
00007e55d47d24f5  pop rcx
00007e55d47d24f6  pop rax
00007e55d47d24f7  add rsp, 0x08
00007e55d47d24fb  jmp 0x00007E55D47CFC76
00007e55d47d2500  call 0x00007E55D45FF430
00007e55d47d2505  jmp 0x00007E55D47CFC83
00007e55d47d250a  sub rsp, 0x08
00007e55d47d250e  push rax
00007e55d47d250f  push rcx
00007e55d47d2510  push rdx
00007e55d47d2511  push rdi
00007e55d47d2512  push rsi
00007e55d47d2513  push r8
00007e55d47d2515  push r9
00007e55d47d2517  push r10
00007e55d47d2519  push r11
00007e55d47d251b  sub rsp, 0xF0
00007e55d47d2522  vmovaps [rsp], xmm0
00007e55d47d2527  vmovaps [rsp+0x10], xmm1
00007e55d47d252d  vmovaps [rsp+0x20], xmm2
00007e55d47d2533  vmovaps [rsp+0x30], xmm3
00007e55d47d2539  vmovaps [rsp+0x40], xmm4
00007e55d47d253f  vmovaps [rsp+0x50], xmm5
00007e55d47d2545  vmovaps [rsp+0x60], xmm6
00007e55d47d254b  vmovaps [rsp+0x70], xmm7
00007e55d47d2551  vmovaps [rsp+0x80], xmm8
00007e55d47d255a  vmovaps [rsp+0x90], xmm9
00007e55d47d2563  vmovaps [rsp+0xA0], xmm10
00007e55d47d256c  vmovaps [rsp+0xB0], xmm11
00007e55d47d2575  vmovaps [rsp+0xC0], xmm12
00007e55d47d257e  vmovaps [rsp+0xD0], xmm13
00007e55d47d2587  vmovaps [rsp+0xE0], xmm14
00007e55d47d2590  sub rsp, 0x30
00007e55d47d2594  movaps [rsp], xmm15
00007e55d47d2599  movaps [rsp+0x10], xmm11
00007e55d47d259f  movaps [rsp+0x20], xmm1
00007e55d47d25a4  lea rdi, [rsp]
00007e55d47d25a8  mov esi, 0x00
00007e55d47d25ad  mov rax, 0x55D0734A4530
00007e55d47d25b7  call rax
00007e55d47d25b9  movaps xmm15, [rsp]
00007e55d47d25be  add rsp, 0x30
00007e55d47d25c2  vmovaps xmm0, [rsp]
00007e55d47d25c7  vmovaps xmm1, [rsp+0x10]
00007e55d47d25cd  vmovaps xmm2, [rsp+0x20]
00007e55d47d25d3  vmovaps xmm3, [rsp+0x30]
00007e55d47d25d9  vmovaps xmm4, [rsp+0x40]
00007e55d47d25df  vmovaps xmm5, [rsp+0x50]
00007e55d47d25e5  vmovaps xmm6, [rsp+0x60]
00007e55d47d25eb  vmovaps xmm7, [rsp+0x70]
00007e55d47d25f1  vmovaps xmm8, [rsp+0x80]
00007e55d47d25fa  vmovaps xmm9, [rsp+0x90]
00007e55d47d2603  vmovaps xmm10, [rsp+0xA0]
00007e55d47d260c  vmovaps xmm11, [rsp+0xB0]
00007e55d47d2615  vmovaps xmm12, [rsp+0xC0]
00007e55d47d261e  vmovaps xmm13, [rsp+0xD0]
00007e55d47d2627  vmovaps xmm14, [rsp+0xE0]
00007e55d47d2630  add rsp, 0xF0
00007e55d47d2637  pop r11
00007e55d47d2639  pop r10
00007e55d47d263b  pop r9
00007e55d47d263d  pop r8
00007e55d47d263f  pop rsi
00007e55d47d2640  pop rdi
00007e55d47d2641  pop rdx
00007e55d47d2642  pop rcx
00007e55d47d2643  pop rax
00007e55d47d2644  add rsp, 0x08
00007e55d47d2648  jmp 0x00007E55D47CFCBC
00007e55d47d264d  sub rsp, 0x08
00007e55d47d2651  push rax
00007e55d47d2652  push rcx
00007e55d47d2653  push rdx
00007e55d47d2654  push rdi
00007e55d47d2655  push rsi
00007e55d47d2656  push r8
00007e55d47d2658  push r9
00007e55d47d265a  push r10
00007e55d47d265c  push r11
00007e55d47d265e  sub rsp, 0xF0
00007e55d47d2665  vmovaps [rsp], xmm0
00007e55d47d266a  vmovaps [rsp+0x10], xmm1
00007e55d47d2670  vmovaps [rsp+0x20], xmm2
00007e55d47d2676  vmovaps [rsp+0x30], xmm3
00007e55d47d267c  vmovaps [rsp+0x40], xmm4
00007e55d47d2682  vmovaps [rsp+0x50], xmm5
00007e55d47d2688  vmovaps [rsp+0x60], xmm6
00007e55d47d268e  vmovaps [rsp+0x70], xmm7
00007e55d47d2694  vmovaps [rsp+0x80], xmm8
00007e55d47d269d  vmovaps [rsp+0x90], xmm9
00007e55d47d26a6  vmovaps [rsp+0xA0], xmm10
00007e55d47d26af  vmovaps [rsp+0xB0], xmm12
00007e55d47d26b8  vmovaps [rsp+0xC0], xmm13
00007e55d47d26c1  vmovaps [rsp+0xD0], xmm14
00007e55d47d26ca  vmovaps [rsp+0xE0], xmm15
00007e55d47d26d3  sub rsp, 0x30
00007e55d47d26d7  movaps [rsp], xmm11
00007e55d47d26dc  movaps [rsp+0x10], xmm6
00007e55d47d26e1  movaps [rsp+0x20], xmm14
00007e55d47d26e7  lea rdi, [rsp]
00007e55d47d26eb  mov esi, 0x00
00007e55d47d26f0  mov rax, 0x55D0734A4530
00007e55d47d26fa  call rax
00007e55d47d26fc  movaps xmm11, [rsp]
00007e55d47d2701  add rsp, 0x30
00007e55d47d2705  vmovaps xmm0, [rsp]
00007e55d47d270a  vmovaps xmm1, [rsp+0x10]
00007e55d47d2710  vmovaps xmm2, [rsp+0x20]
00007e55d47d2716  vmovaps xmm3, [rsp+0x30]
00007e55d47d271c  vmovaps xmm4, [rsp+0x40]
00007e55d47d2722  vmovaps xmm5, [rsp+0x50]
00007e55d47d2728  vmovaps xmm6, [rsp+0x60]
00007e55d47d272e  vmovaps xmm7, [rsp+0x70]
00007e55d47d2734  vmovaps xmm8, [rsp+0x80]
00007e55d47d273d  vmovaps xmm9, [rsp+0x90]
00007e55d47d2746  vmovaps xmm10, [rsp+0xA0]
00007e55d47d274f  vmovaps xmm12, [rsp+0xB0]
00007e55d47d2758  vmovaps xmm13, [rsp+0xC0]
00007e55d47d2761  vmovaps xmm14, [rsp+0xD0]
00007e55d47d276a  vmovaps xmm15, [rsp+0xE0]
00007e55d47d2773  add rsp, 0xF0
00007e55d47d277a  pop r11
00007e55d47d277c  pop r10
00007e55d47d277e  pop r9
00007e55d47d2780  pop r8
00007e55d47d2782  pop rsi
00007e55d47d2783  pop rdi
00007e55d47d2784  pop rdx
00007e55d47d2785  pop rcx
00007e55d47d2786  pop rax
00007e55d47d2787  add rsp, 0x08
00007e55d47d278b  jmp 0x00007E55D47CFD34
00007e55d47d2790  call 0x00007E55D45FF430
00007e55d47d2795  jmp 0x00007E55D47CFD3E
00007e55d47d279a  sub rsp, 0x08
00007e55d47d279e  push rax
00007e55d47d279f  push rcx
00007e55d47d27a0  push rdx
00007e55d47d27a1  push rdi
00007e55d47d27a2  push rsi
00007e55d47d27a3  push r8
00007e55d47d27a5  push r9
00007e55d47d27a7  push r10
00007e55d47d27a9  push r11
00007e55d47d27ab  sub rsp, 0xF0
00007e55d47d27b2  vmovaps [rsp], xmm0
00007e55d47d27b7  vmovaps [rsp+0x10], xmm1
00007e55d47d27bd  vmovaps [rsp+0x20], xmm2
00007e55d47d27c3  vmovaps [rsp+0x30], xmm3
00007e55d47d27c9  vmovaps [rsp+0x40], xmm4
00007e55d47d27cf  vmovaps [rsp+0x50], xmm5
00007e55d47d27d5  vmovaps [rsp+0x60], xmm6
00007e55d47d27db  vmovaps [rsp+0x70], xmm7
00007e55d47d27e1  vmovaps [rsp+0x80], xmm8
00007e55d47d27ea  vmovaps [rsp+0x90], xmm9
00007e55d47d27f3  vmovaps [rsp+0xA0], xmm10
00007e55d47d27fc  vmovaps [rsp+0xB0], xmm11
00007e55d47d2805  vmovaps [rsp+0xC0], xmm12
00007e55d47d280e  vmovaps [rsp+0xD0], xmm13
00007e55d47d2817  vmovaps [rsp+0xE0], xmm15
00007e55d47d2820  sub rsp, 0x30
00007e55d47d2824  movaps [rsp], xmm14
00007e55d47d2829  movaps [rsp+0x10], xmm6
00007e55d47d282e  movaps [rsp+0x20], xmm2
00007e55d47d2833  lea rdi, [rsp]
00007e55d47d2837  mov esi, 0x00
00007e55d47d283c  mov rax, 0x55D0734A4530
00007e55d47d2846  call rax
00007e55d47d2848  movaps xmm14, [rsp]
00007e55d47d284d  add rsp, 0x30
00007e55d47d2851  vmovaps xmm0, [rsp]
00007e55d47d2856  vmovaps xmm1, [rsp+0x10]
00007e55d47d285c  vmovaps xmm2, [rsp+0x20]
00007e55d47d2862  vmovaps xmm3, [rsp+0x30]
00007e55d47d2868  vmovaps xmm4, [rsp+0x40]
00007e55d47d286e  vmovaps xmm5, [rsp+0x50]
00007e55d47d2874  vmovaps xmm6, [rsp+0x60]
00007e55d47d287a  vmovaps xmm7, [rsp+0x70]
00007e55d47d2880  vmovaps xmm8, [rsp+0x80]
00007e55d47d2889  vmovaps xmm9, [rsp+0x90]
00007e55d47d2892  vmovaps xmm10, [rsp+0xA0]
00007e55d47d289b  vmovaps xmm11, [rsp+0xB0]
00007e55d47d28a4  vmovaps xmm12, [rsp+0xC0]
00007e55d47d28ad  vmovaps xmm13, [rsp+0xD0]
00007e55d47d28b6  vmovaps xmm15, [rsp+0xE0]
00007e55d47d28bf  add rsp, 0xF0
00007e55d47d28c6  pop r11
00007e55d47d28c8  pop r10
00007e55d47d28ca  pop r9
00007e55d47d28cc  pop r8
00007e55d47d28ce  pop rsi
00007e55d47d28cf  pop rdi
00007e55d47d28d0  pop rdx
00007e55d47d28d1  pop rcx
00007e55d47d28d2  pop rax
00007e55d47d28d3  add rsp, 0x08
00007e55d47d28d7  jmp 0x00007E55D47CFD72
00007e55d47d28dc  sub rsp, 0x08
00007e55d47d28e0  push rax
00007e55d47d28e1  push rcx
00007e55d47d28e2  push rdx
00007e55d47d28e3  push rdi
00007e55d47d28e4  push rsi
00007e55d47d28e5  push r8
00007e55d47d28e7  push r9
00007e55d47d28e9  push r10
00007e55d47d28eb  push r11
00007e55d47d28ed  sub rsp, 0xF0
00007e55d47d28f4  vmovaps [rsp], xmm0
00007e55d47d28f9  vmovaps [rsp+0x10], xmm1
00007e55d47d28ff  vmovaps [rsp+0x20], xmm2
00007e55d47d2905  vmovaps [rsp+0x30], xmm3
00007e55d47d290b  vmovaps [rsp+0x40], xmm4
00007e55d47d2911  vmovaps [rsp+0x50], xmm5
00007e55d47d2917  vmovaps [rsp+0x60], xmm7
00007e55d47d291d  vmovaps [rsp+0x70], xmm8
00007e55d47d2923  vmovaps [rsp+0x80], xmm9
00007e55d47d292c  vmovaps [rsp+0x90], xmm10
00007e55d47d2935  vmovaps [rsp+0xA0], xmm11
00007e55d47d293e  vmovaps [rsp+0xB0], xmm12
00007e55d47d2947  vmovaps [rsp+0xC0], xmm13
00007e55d47d2950  vmovaps [rsp+0xD0], xmm14
00007e55d47d2959  vmovaps [rsp+0xE0], xmm15
00007e55d47d2962  sub rsp, 0x30
00007e55d47d2966  movaps [rsp], xmm6
00007e55d47d296a  movaps [rsp+0x10], xmm5
00007e55d47d296f  movaps [rsp+0x20], xmm1
00007e55d47d2974  lea rdi, [rsp]
00007e55d47d2978  mov esi, 0x00
00007e55d47d297d  mov rax, 0x55D0734A4530
00007e55d47d2987  call rax
00007e55d47d2989  movaps xmm6, [rsp]
00007e55d47d298d  add rsp, 0x30
00007e55d47d2991  vmovaps xmm0, [rsp]
00007e55d47d2996  vmovaps xmm1, [rsp+0x10]
00007e55d47d299c  vmovaps xmm2, [rsp+0x20]
00007e55d47d29a2  vmovaps xmm3, [rsp+0x30]
00007e55d47d29a8  vmovaps xmm4, [rsp+0x40]
00007e55d47d29ae  vmovaps xmm5, [rsp+0x50]
00007e55d47d29b4  vmovaps xmm7, [rsp+0x60]
00007e55d47d29ba  vmovaps xmm8, [rsp+0x70]
00007e55d47d29c0  vmovaps xmm9, [rsp+0x80]
00007e55d47d29c9  vmovaps xmm10, [rsp+0x90]
00007e55d47d29d2  vmovaps xmm11, [rsp+0xA0]
00007e55d47d29db  vmovaps xmm12, [rsp+0xB0]
00007e55d47d29e4  vmovaps xmm13, [rsp+0xC0]
00007e55d47d29ed  vmovaps xmm14, [rsp+0xD0]
00007e55d47d29f6  vmovaps xmm15, [rsp+0xE0]
00007e55d47d29ff  add rsp, 0xF0
00007e55d47d2a06  pop r11
00007e55d47d2a08  pop r10
00007e55d47d2a0a  pop r9
00007e55d47d2a0c  pop r8
00007e55d47d2a0e  pop rsi
00007e55d47d2a0f  pop rdi
00007e55d47d2a10  pop rdx
00007e55d47d2a11  pop rcx
00007e55d47d2a12  pop rax
00007e55d47d2a13  add rsp, 0x08
00007e55d47d2a17  jmp 0x00007E55D47CFD98
00007e55d47d2a1c  sub rsp, 0x08
00007e55d47d2a20  push rax
00007e55d47d2a21  push rcx
00007e55d47d2a22  push rdx
00007e55d47d2a23  push rdi
00007e55d47d2a24  push rsi
00007e55d47d2a25  push r8
00007e55d47d2a27  push r9
00007e55d47d2a29  push r10
00007e55d47d2a2b  push r11
00007e55d47d2a2d  sub rsp, 0xF0
00007e55d47d2a34  vmovaps [rsp], xmm0
00007e55d47d2a39  vmovaps [rsp+0x10], xmm2
00007e55d47d2a3f  vmovaps [rsp+0x20], xmm3
00007e55d47d2a45  vmovaps [rsp+0x30], xmm4
00007e55d47d2a4b  vmovaps [rsp+0x40], xmm5
00007e55d47d2a51  vmovaps [rsp+0x50], xmm6
00007e55d47d2a57  vmovaps [rsp+0x60], xmm7
00007e55d47d2a5d  vmovaps [rsp+0x70], xmm8
00007e55d47d2a63  vmovaps [rsp+0x80], xmm9
00007e55d47d2a6c  vmovaps [rsp+0x90], xmm10
00007e55d47d2a75  vmovaps [rsp+0xA0], xmm11
00007e55d47d2a7e  vmovaps [rsp+0xB0], xmm12
00007e55d47d2a87  vmovaps [rsp+0xC0], xmm13
00007e55d47d2a90  vmovaps [rsp+0xD0], xmm14
00007e55d47d2a99  vmovaps [rsp+0xE0], xmm15
00007e55d47d2aa2  sub rsp, 0x30
00007e55d47d2aa6  movaps [rsp], xmm1
00007e55d47d2aaa  movaps [rsp+0x10], xmm5
00007e55d47d2aaf  movaps [rsp+0x20], xmm13
00007e55d47d2ab5  lea rdi, [rsp]
00007e55d47d2ab9  mov esi, 0x00
00007e55d47d2abe  mov rax, 0x55D0734A4530
00007e55d47d2ac8  call rax
00007e55d47d2aca  movaps xmm1, [rsp]
00007e55d47d2ace  add rsp, 0x30
00007e55d47d2ad2  vmovaps xmm0, [rsp]
00007e55d47d2ad7  vmovaps xmm2, [rsp+0x10]
00007e55d47d2add  vmovaps xmm3, [rsp+0x20]
00007e55d47d2ae3  vmovaps xmm4, [rsp+0x30]
00007e55d47d2ae9  vmovaps xmm5, [rsp+0x40]
00007e55d47d2aef  vmovaps xmm6, [rsp+0x50]
00007e55d47d2af5  vmovaps xmm7, [rsp+0x60]
00007e55d47d2afb  vmovaps xmm8, [rsp+0x70]
00007e55d47d2b01  vmovaps xmm9, [rsp+0x80]
00007e55d47d2b0a  vmovaps xmm10, [rsp+0x90]
00007e55d47d2b13  vmovaps xmm11, [rsp+0xA0]
00007e55d47d2b1c  vmovaps xmm12, [rsp+0xB0]
00007e55d47d2b25  vmovaps xmm13, [rsp+0xC0]
00007e55d47d2b2e  vmovaps xmm14, [rsp+0xD0]
00007e55d47d2b37  vmovaps xmm15, [rsp+0xE0]
00007e55d47d2b40  add rsp, 0xF0
00007e55d47d2b47  pop r11
00007e55d47d2b49  pop r10
00007e55d47d2b4b  pop r9
00007e55d47d2b4d  pop r8
00007e55d47d2b4f  pop rsi
00007e55d47d2b50  pop rdi
00007e55d47d2b51  pop rdx
00007e55d47d2b52  pop rcx
00007e55d47d2b53  pop rax
00007e55d47d2b54  add rsp, 0x08
00007e55d47d2b58  jmp 0x00007E55D47CFDB6
00007e55d47d2b5d  sub rsp, 0x08
00007e55d47d2b61  push rax
00007e55d47d2b62  push rcx
00007e55d47d2b63  push rdx
00007e55d47d2b64  push rdi
00007e55d47d2b65  push rsi
00007e55d47d2b66  push r8
00007e55d47d2b68  push r9
00007e55d47d2b6a  push r10
00007e55d47d2b6c  push r11
00007e55d47d2b6e  sub rsp, 0xF0
00007e55d47d2b75  vmovaps [rsp], xmm0
00007e55d47d2b7a  vmovaps [rsp+0x10], xmm1
00007e55d47d2b80  vmovaps [rsp+0x20], xmm2
00007e55d47d2b86  vmovaps [rsp+0x30], xmm3
00007e55d47d2b8c  vmovaps [rsp+0x40], xmm4
00007e55d47d2b92  vmovaps [rsp+0x50], xmm6
00007e55d47d2b98  vmovaps [rsp+0x60], xmm7
00007e55d47d2b9e  vmovaps [rsp+0x70], xmm8
00007e55d47d2ba4  vmovaps [rsp+0x80], xmm9
00007e55d47d2bad  vmovaps [rsp+0x90], xmm10
00007e55d47d2bb6  vmovaps [rsp+0xA0], xmm11
00007e55d47d2bbf  vmovaps [rsp+0xB0], xmm12
00007e55d47d2bc8  vmovaps [rsp+0xC0], xmm13
00007e55d47d2bd1  vmovaps [rsp+0xD0], xmm14
00007e55d47d2bda  vmovaps [rsp+0xE0], xmm15
00007e55d47d2be3  sub rsp, 0x30
00007e55d47d2be7  movaps [rsp], xmm5
00007e55d47d2beb  movaps [rsp+0x10], xmm2
00007e55d47d2bf0  movaps [rsp+0x20], xmm13
00007e55d47d2bf6  lea rdi, [rsp]
00007e55d47d2bfa  mov esi, 0x00
00007e55d47d2bff  mov rax, 0x55D0734A4530
00007e55d47d2c09  call rax
00007e55d47d2c0b  movaps xmm5, [rsp]
00007e55d47d2c0f  add rsp, 0x30
00007e55d47d2c13  vmovaps xmm0, [rsp]
00007e55d47d2c18  vmovaps xmm1, [rsp+0x10]
00007e55d47d2c1e  vmovaps xmm2, [rsp+0x20]
00007e55d47d2c24  vmovaps xmm3, [rsp+0x30]
00007e55d47d2c2a  vmovaps xmm4, [rsp+0x40]
00007e55d47d2c30  vmovaps xmm6, [rsp+0x50]
00007e55d47d2c36  vmovaps xmm7, [rsp+0x60]
00007e55d47d2c3c  vmovaps xmm8, [rsp+0x70]
00007e55d47d2c42  vmovaps xmm9, [rsp+0x80]
00007e55d47d2c4b  vmovaps xmm10, [rsp+0x90]
00007e55d47d2c54  vmovaps xmm11, [rsp+0xA0]
00007e55d47d2c5d  vmovaps xmm12, [rsp+0xB0]
00007e55d47d2c66  vmovaps xmm13, [rsp+0xC0]
00007e55d47d2c6f  vmovaps xmm14, [rsp+0xD0]
00007e55d47d2c78  vmovaps xmm15, [rsp+0xE0]
00007e55d47d2c81  add rsp, 0xF0
00007e55d47d2c88  pop r11
00007e55d47d2c8a  pop r10
00007e55d47d2c8c  pop r9
00007e55d47d2c8e  pop r8
00007e55d47d2c90  pop rsi
00007e55d47d2c91  pop rdi
00007e55d47d2c92  pop rdx
00007e55d47d2c93  pop rcx
00007e55d47d2c94  pop rax
00007e55d47d2c95  add rsp, 0x08
00007e55d47d2c99  jmp 0x00007E55D47CFDEC
00007e55d47d2c9e  sub rsp, 0x08
00007e55d47d2ca2  push rax
00007e55d47d2ca3  push rcx
00007e55d47d2ca4  push rdx
00007e55d47d2ca5  push rdi
00007e55d47d2ca6  push rsi
00007e55d47d2ca7  push r8
00007e55d47d2ca9  push r9
00007e55d47d2cab  push r10
00007e55d47d2cad  push r11
00007e55d47d2caf  sub rsp, 0xF0
00007e55d47d2cb6  vmovaps [rsp], xmm0
00007e55d47d2cbb  vmovaps [rsp+0x10], xmm1
00007e55d47d2cc1  vmovaps [rsp+0x20], xmm2
00007e55d47d2cc7  vmovaps [rsp+0x30], xmm3
00007e55d47d2ccd  vmovaps [rsp+0x40], xmm4
00007e55d47d2cd3  vmovaps [rsp+0x50], xmm5
00007e55d47d2cd9  vmovaps [rsp+0x60], xmm6
00007e55d47d2cdf  vmovaps [rsp+0x70], xmm7
00007e55d47d2ce5  vmovaps [rsp+0x80], xmm8
00007e55d47d2cee  vmovaps [rsp+0x90], xmm9
00007e55d47d2cf7  vmovaps [rsp+0xA0], xmm10
00007e55d47d2d00  vmovaps [rsp+0xB0], xmm11
00007e55d47d2d09  vmovaps [rsp+0xC0], xmm12
00007e55d47d2d12  vmovaps [rsp+0xD0], xmm14
00007e55d47d2d1b  vmovaps [rsp+0xE0], xmm15
00007e55d47d2d24  sub rsp, 0x30
00007e55d47d2d28  movaps [rsp], xmm13
00007e55d47d2d2d  movaps [rsp+0x10], xmm10
00007e55d47d2d33  movaps [rsp+0x20], xmm1
00007e55d47d2d38  lea rdi, [rsp]
00007e55d47d2d3c  mov esi, 0x00
00007e55d47d2d41  mov rax, 0x55D0734A4530
00007e55d47d2d4b  call rax
00007e55d47d2d4d  movaps xmm13, [rsp]
00007e55d47d2d52  add rsp, 0x30
00007e55d47d2d56  vmovaps xmm0, [rsp]
00007e55d47d2d5b  vmovaps xmm1, [rsp+0x10]
00007e55d47d2d61  vmovaps xmm2, [rsp+0x20]
00007e55d47d2d67  vmovaps xmm3, [rsp+0x30]
00007e55d47d2d6d  vmovaps xmm4, [rsp+0x40]
00007e55d47d2d73  vmovaps xmm5, [rsp+0x50]
00007e55d47d2d79  vmovaps xmm6, [rsp+0x60]
00007e55d47d2d7f  vmovaps xmm7, [rsp+0x70]
00007e55d47d2d85  vmovaps xmm8, [rsp+0x80]
00007e55d47d2d8e  vmovaps xmm9, [rsp+0x90]
00007e55d47d2d97  vmovaps xmm10, [rsp+0xA0]
00007e55d47d2da0  vmovaps xmm11, [rsp+0xB0]
00007e55d47d2da9  vmovaps xmm12, [rsp+0xC0]
00007e55d47d2db2  vmovaps xmm14, [rsp+0xD0]
00007e55d47d2dbb  vmovaps xmm15, [rsp+0xE0]
00007e55d47d2dc4  add rsp, 0xF0
00007e55d47d2dcb  pop r11
00007e55d47d2dcd  pop r10
00007e55d47d2dcf  pop r9
00007e55d47d2dd1  pop r8
00007e55d47d2dd3  pop rsi
00007e55d47d2dd4  pop rdi
00007e55d47d2dd5  pop rdx
00007e55d47d2dd6  pop rcx
00007e55d47d2dd7  pop rax
00007e55d47d2dd8  add rsp, 0x08
00007e55d47d2ddc  jmp 0x00007E55D47CFE15
00007e55d47d2de1  sub rsp, 0x08
00007e55d47d2de5  push rax
00007e55d47d2de6  push rcx
00007e55d47d2de7  push rdx
00007e55d47d2de8  push rdi
00007e55d47d2de9  push rsi
00007e55d47d2dea  push r8
00007e55d47d2dec  push r9
00007e55d47d2dee  push r10
00007e55d47d2df0  push r11
00007e55d47d2df2  sub rsp, 0xF0
00007e55d47d2df9  vmovaps [rsp], xmm0
00007e55d47d2dfe  vmovaps [rsp+0x10], xmm2
00007e55d47d2e04  vmovaps [rsp+0x20], xmm3
00007e55d47d2e0a  vmovaps [rsp+0x30], xmm4
00007e55d47d2e10  vmovaps [rsp+0x40], xmm5
00007e55d47d2e16  vmovaps [rsp+0x50], xmm6
00007e55d47d2e1c  vmovaps [rsp+0x60], xmm7
00007e55d47d2e22  vmovaps [rsp+0x70], xmm8
00007e55d47d2e28  vmovaps [rsp+0x80], xmm9
00007e55d47d2e31  vmovaps [rsp+0x90], xmm10
00007e55d47d2e3a  vmovaps [rsp+0xA0], xmm11
00007e55d47d2e43  vmovaps [rsp+0xB0], xmm12
00007e55d47d2e4c  vmovaps [rsp+0xC0], xmm13
00007e55d47d2e55  vmovaps [rsp+0xD0], xmm14
00007e55d47d2e5e  vmovaps [rsp+0xE0], xmm15
00007e55d47d2e67  sub rsp, 0x30
00007e55d47d2e6b  movaps [rsp], xmm1
00007e55d47d2e6f  movaps [rsp+0x10], xmm15
00007e55d47d2e75  movaps [rsp+0x20], xmm10
00007e55d47d2e7b  lea rdi, [rsp]
00007e55d47d2e7f  mov esi, 0x00
00007e55d47d2e84  mov rax, 0x55D0734A4530
00007e55d47d2e8e  call rax
00007e55d47d2e90  movaps xmm1, [rsp]
00007e55d47d2e94  add rsp, 0x30
00007e55d47d2e98  vmovaps xmm0, [rsp]
00007e55d47d2e9d  vmovaps xmm2, [rsp+0x10]
00007e55d47d2ea3  vmovaps xmm3, [rsp+0x20]
00007e55d47d2ea9  vmovaps xmm4, [rsp+0x30]
00007e55d47d2eaf  vmovaps xmm5, [rsp+0x40]
00007e55d47d2eb5  vmovaps xmm6, [rsp+0x50]
00007e55d47d2ebb  vmovaps xmm7, [rsp+0x60]
00007e55d47d2ec1  vmovaps xmm8, [rsp+0x70]
00007e55d47d2ec7  vmovaps xmm9, [rsp+0x80]
00007e55d47d2ed0  vmovaps xmm10, [rsp+0x90]
00007e55d47d2ed9  vmovaps xmm11, [rsp+0xA0]
00007e55d47d2ee2  vmovaps xmm12, [rsp+0xB0]
00007e55d47d2eeb  vmovaps xmm13, [rsp+0xC0]
00007e55d47d2ef4  vmovaps xmm14, [rsp+0xD0]
00007e55d47d2efd  vmovaps xmm15, [rsp+0xE0]
00007e55d47d2f06  add rsp, 0xF0
00007e55d47d2f0d  pop r11
00007e55d47d2f0f  pop r10
00007e55d47d2f11  pop r9
00007e55d47d2f13  pop r8
00007e55d47d2f15  pop rsi
00007e55d47d2f16  pop rdi
00007e55d47d2f17  pop rdx
00007e55d47d2f18  pop rcx
00007e55d47d2f19  pop rax
00007e55d47d2f1a  add rsp, 0x08
00007e55d47d2f1e  jmp 0x00007E55D47CFE34
00007e55d47d2f23  sub rsp, 0x08
00007e55d47d2f27  push rax
00007e55d47d2f28  push rcx
00007e55d47d2f29  push rdx
00007e55d47d2f2a  push rdi
00007e55d47d2f2b  push rsi
00007e55d47d2f2c  push r8
00007e55d47d2f2e  push r9
00007e55d47d2f30  push r10
00007e55d47d2f32  push r11
00007e55d47d2f34  sub rsp, 0xF0
00007e55d47d2f3b  vmovaps [rsp], xmm0
00007e55d47d2f40  vmovaps [rsp+0x10], xmm1
00007e55d47d2f46  vmovaps [rsp+0x20], xmm2
00007e55d47d2f4c  vmovaps [rsp+0x30], xmm3
00007e55d47d2f52  vmovaps [rsp+0x40], xmm4
00007e55d47d2f58  vmovaps [rsp+0x50], xmm5
00007e55d47d2f5e  vmovaps [rsp+0x60], xmm6
00007e55d47d2f64  vmovaps [rsp+0x70], xmm7
00007e55d47d2f6a  vmovaps [rsp+0x80], xmm8
00007e55d47d2f73  vmovaps [rsp+0x90], xmm9
00007e55d47d2f7c  vmovaps [rsp+0xA0], xmm10
00007e55d47d2f85  vmovaps [rsp+0xB0], xmm11
00007e55d47d2f8e  vmovaps [rsp+0xC0], xmm12
00007e55d47d2f97  vmovaps [rsp+0xD0], xmm13
00007e55d47d2fa0  vmovaps [rsp+0xE0], xmm14
00007e55d47d2fa9  sub rsp, 0x30
00007e55d47d2fad  movaps [rsp], xmm15
00007e55d47d2fb2  movaps [rsp+0x10], xmm10
00007e55d47d2fb8  movaps [rsp+0x20], xmm11
00007e55d47d2fbe  lea rdi, [rsp]
00007e55d47d2fc2  mov esi, 0x00
00007e55d47d2fc7  mov rax, 0x55D0734A4530
00007e55d47d2fd1  call rax
00007e55d47d2fd3  movaps xmm15, [rsp]
00007e55d47d2fd8  add rsp, 0x30
00007e55d47d2fdc  vmovaps xmm0, [rsp]
00007e55d47d2fe1  vmovaps xmm1, [rsp+0x10]
00007e55d47d2fe7  vmovaps xmm2, [rsp+0x20]
00007e55d47d2fed  vmovaps xmm3, [rsp+0x30]
00007e55d47d2ff3  vmovaps xmm4, [rsp+0x40]
00007e55d47d2ff9  vmovaps xmm5, [rsp+0x50]
00007e55d47d2fff  vmovaps xmm6, [rsp+0x60]
00007e55d47d3005  vmovaps xmm7, [rsp+0x70]
00007e55d47d300b  vmovaps xmm8, [rsp+0x80]
00007e55d47d3014  vmovaps xmm9, [rsp+0x90]
00007e55d47d301d  vmovaps xmm10, [rsp+0xA0]
00007e55d47d3026  vmovaps xmm11, [rsp+0xB0]
00007e55d47d302f  vmovaps xmm12, [rsp+0xC0]
00007e55d47d3038  vmovaps xmm13, [rsp+0xD0]
00007e55d47d3041  vmovaps xmm14, [rsp+0xE0]
00007e55d47d304a  add rsp, 0xF0
00007e55d47d3051  pop r11
00007e55d47d3053  pop r10
00007e55d47d3055  pop r9
00007e55d47d3057  pop r8
00007e55d47d3059  pop rsi
00007e55d47d305a  pop rdi
00007e55d47d305b  pop rdx
00007e55d47d305c  pop rcx
00007e55d47d305d  pop rax
00007e55d47d305e  add rsp, 0x08
00007e55d47d3062  jmp 0x00007E55D47CFE57
00007e55d47d3067  sub rsp, 0x08
00007e55d47d306b  push rax
00007e55d47d306c  push rcx
00007e55d47d306d  push rdx
00007e55d47d306e  push rdi
00007e55d47d306f  push rsi
00007e55d47d3070  push r8
00007e55d47d3072  push r9
00007e55d47d3074  push r10
00007e55d47d3076  push r11
00007e55d47d3078  sub rsp, 0xF0
00007e55d47d307f  vmovaps [rsp], xmm0
00007e55d47d3084  vmovaps [rsp+0x10], xmm1
00007e55d47d308a  vmovaps [rsp+0x20], xmm2
00007e55d47d3090  vmovaps [rsp+0x30], xmm3
00007e55d47d3096  vmovaps [rsp+0x40], xmm4
00007e55d47d309c  vmovaps [rsp+0x50], xmm5
00007e55d47d30a2  vmovaps [rsp+0x60], xmm6
00007e55d47d30a8  vmovaps [rsp+0x70], xmm7
00007e55d47d30ae  vmovaps [rsp+0x80], xmm8
00007e55d47d30b7  vmovaps [rsp+0x90], xmm9
00007e55d47d30c0  vmovaps [rsp+0xA0], xmm11
00007e55d47d30c9  vmovaps [rsp+0xB0], xmm12
00007e55d47d30d2  vmovaps [rsp+0xC0], xmm13
00007e55d47d30db  vmovaps [rsp+0xD0], xmm14
00007e55d47d30e4  vmovaps [rsp+0xE0], xmm15
00007e55d47d30ed  sub rsp, 0x30
00007e55d47d30f1  movaps [rsp], xmm10
00007e55d47d30f6  movaps [rsp+0x10], xmm12
00007e55d47d30fc  movaps [rsp+0x20], xmm11
00007e55d47d3102  lea rdi, [rsp]
00007e55d47d3106  mov esi, 0x00
00007e55d47d310b  mov rax, 0x55D0734A4530
00007e55d47d3115  call rax
00007e55d47d3117  movaps xmm10, [rsp]
00007e55d47d311c  add rsp, 0x30
00007e55d47d3120  vmovaps xmm0, [rsp]
00007e55d47d3125  vmovaps xmm1, [rsp+0x10]
00007e55d47d312b  vmovaps xmm2, [rsp+0x20]
00007e55d47d3131  vmovaps xmm3, [rsp+0x30]
00007e55d47d3137  vmovaps xmm4, [rsp+0x40]
00007e55d47d313d  vmovaps xmm5, [rsp+0x50]
00007e55d47d3143  vmovaps xmm6, [rsp+0x60]
00007e55d47d3149  vmovaps xmm7, [rsp+0x70]
00007e55d47d314f  vmovaps xmm8, [rsp+0x80]
00007e55d47d3158  vmovaps xmm9, [rsp+0x90]
00007e55d47d3161  vmovaps xmm11, [rsp+0xA0]
00007e55d47d316a  vmovaps xmm12, [rsp+0xB0]
00007e55d47d3173  vmovaps xmm13, [rsp+0xC0]
00007e55d47d317c  vmovaps xmm14, [rsp+0xD0]
00007e55d47d3185  vmovaps xmm15, [rsp+0xE0]
00007e55d47d318e  add rsp, 0xF0
00007e55d47d3195  pop r11
00007e55d47d3197  pop r10
00007e55d47d3199  pop r9
00007e55d47d319b  pop r8
00007e55d47d319d  pop rsi
00007e55d47d319e  pop rdi
00007e55d47d319f  pop rdx
00007e55d47d31a0  pop rcx
00007e55d47d31a1  pop rax
00007e55d47d31a2  add rsp, 0x08
00007e55d47d31a6  jmp 0x00007E55D47CFE80
00007e55d47d31ab  sub rsp, 0x08
00007e55d47d31af  push rax
00007e55d47d31b0  push rcx
00007e55d47d31b1  push rdx
00007e55d47d31b2  push rdi
00007e55d47d31b3  push rsi
00007e55d47d31b4  push r8
00007e55d47d31b6  push r9
00007e55d47d31b8  push r10
00007e55d47d31ba  push r11
00007e55d47d31bc  sub rsp, 0xF0
00007e55d47d31c3  vmovaps [rsp], xmm0
00007e55d47d31c8  vmovaps [rsp+0x10], xmm1
00007e55d47d31ce  vmovaps [rsp+0x20], xmm2
00007e55d47d31d4  vmovaps [rsp+0x30], xmm3
00007e55d47d31da  vmovaps [rsp+0x40], xmm4
00007e55d47d31e0  vmovaps [rsp+0x50], xmm5
00007e55d47d31e6  vmovaps [rsp+0x60], xmm6
00007e55d47d31ec  vmovaps [rsp+0x70], xmm7
00007e55d47d31f2  vmovaps [rsp+0x80], xmm8
00007e55d47d31fb  vmovaps [rsp+0x90], xmm9
00007e55d47d3204  vmovaps [rsp+0xA0], xmm10
00007e55d47d320d  vmovaps [rsp+0xB0], xmm12
00007e55d47d3216  vmovaps [rsp+0xC0], xmm13
00007e55d47d321f  vmovaps [rsp+0xD0], xmm14
00007e55d47d3228  vmovaps [rsp+0xE0], xmm15
00007e55d47d3231  sub rsp, 0x30
00007e55d47d3235  movaps [rsp], xmm11
00007e55d47d323a  movaps [rsp+0x10], xmm2
00007e55d47d323f  movaps [rsp+0x20], xmm12
00007e55d47d3245  lea rdi, [rsp]
00007e55d47d3249  mov esi, 0x00
00007e55d47d324e  mov rax, 0x55D0734A4530
00007e55d47d3258  call rax
00007e55d47d325a  movaps xmm11, [rsp]
00007e55d47d325f  add rsp, 0x30
00007e55d47d3263  vmovaps xmm0, [rsp]
00007e55d47d3268  vmovaps xmm1, [rsp+0x10]
00007e55d47d326e  vmovaps xmm2, [rsp+0x20]
00007e55d47d3274  vmovaps xmm3, [rsp+0x30]
00007e55d47d327a  vmovaps xmm4, [rsp+0x40]
00007e55d47d3280  vmovaps xmm5, [rsp+0x50]
00007e55d47d3286  vmovaps xmm6, [rsp+0x60]
00007e55d47d328c  vmovaps xmm7, [rsp+0x70]
00007e55d47d3292  vmovaps xmm8, [rsp+0x80]
00007e55d47d329b  vmovaps xmm9, [rsp+0x90]
00007e55d47d32a4  vmovaps xmm10, [rsp+0xA0]
00007e55d47d32ad  vmovaps xmm12, [rsp+0xB0]
00007e55d47d32b6  vmovaps xmm13, [rsp+0xC0]
00007e55d47d32bf  vmovaps xmm14, [rsp+0xD0]
00007e55d47d32c8  vmovaps xmm15, [rsp+0xE0]
00007e55d47d32d1  add rsp, 0xF0
00007e55d47d32d8  pop r11
00007e55d47d32da  pop r10
00007e55d47d32dc  pop r9
00007e55d47d32de  pop r8
00007e55d47d32e0  pop rsi
00007e55d47d32e1  pop rdi
00007e55d47d32e2  pop rdx
00007e55d47d32e3  pop rcx
00007e55d47d32e4  pop rax
00007e55d47d32e5  add rsp, 0x08
00007e55d47d32e9  jmp 0x00007E55D47CFEB8
00007e55d47d32ee  sub rsp, 0x08
00007e55d47d32f2  push rax
00007e55d47d32f3  push rcx
00007e55d47d32f4  push rdx
00007e55d47d32f5  push rdi
00007e55d47d32f6  push rsi
00007e55d47d32f7  push r8
00007e55d47d32f9  push r9
00007e55d47d32fb  push r10
00007e55d47d32fd  push r11
00007e55d47d32ff  sub rsp, 0xF0
00007e55d47d3306  vmovaps [rsp], xmm0
00007e55d47d330b  vmovaps [rsp+0x10], xmm2
00007e55d47d3311  vmovaps [rsp+0x20], xmm3
00007e55d47d3317  vmovaps [rsp+0x30], xmm4
00007e55d47d331d  vmovaps [rsp+0x40], xmm5
00007e55d47d3323  vmovaps [rsp+0x50], xmm6
00007e55d47d3329  vmovaps [rsp+0x60], xmm7
00007e55d47d332f  vmovaps [rsp+0x70], xmm8
00007e55d47d3335  vmovaps [rsp+0x80], xmm9
00007e55d47d333e  vmovaps [rsp+0x90], xmm10
00007e55d47d3347  vmovaps [rsp+0xA0], xmm11
00007e55d47d3350  vmovaps [rsp+0xB0], xmm12
00007e55d47d3359  vmovaps [rsp+0xC0], xmm13
00007e55d47d3362  vmovaps [rsp+0xD0], xmm14
00007e55d47d336b  vmovaps [rsp+0xE0], xmm15
00007e55d47d3374  sub rsp, 0x30
00007e55d47d3378  movaps [rsp], xmm1
00007e55d47d337c  movaps [rsp+0x10], xmm14
00007e55d47d3382  movaps [rsp+0x20], xmm6
00007e55d47d3387  lea rdi, [rsp]
00007e55d47d338b  mov esi, 0x00
00007e55d47d3390  mov rax, 0x55D0734A4530
00007e55d47d339a  call rax
00007e55d47d339c  movaps xmm1, [rsp]
00007e55d47d33a0  add rsp, 0x30
00007e55d47d33a4  vmovaps xmm0, [rsp]
00007e55d47d33a9  vmovaps xmm2, [rsp+0x10]
00007e55d47d33af  vmovaps xmm3, [rsp+0x20]
00007e55d47d33b5  vmovaps xmm4, [rsp+0x30]
00007e55d47d33bb  vmovaps xmm5, [rsp+0x40]
00007e55d47d33c1  vmovaps xmm6, [rsp+0x50]
00007e55d47d33c7  vmovaps xmm7, [rsp+0x60]
00007e55d47d33cd  vmovaps xmm8, [rsp+0x70]
00007e55d47d33d3  vmovaps xmm9, [rsp+0x80]
00007e55d47d33dc  vmovaps xmm10, [rsp+0x90]
00007e55d47d33e5  vmovaps xmm11, [rsp+0xA0]
00007e55d47d33ee  vmovaps xmm12, [rsp+0xB0]
00007e55d47d33f7  vmovaps xmm13, [rsp+0xC0]
00007e55d47d3400  vmovaps xmm14, [rsp+0xD0]
00007e55d47d3409  vmovaps xmm15, [rsp+0xE0]
00007e55d47d3412  add rsp, 0xF0
00007e55d47d3419  pop r11
00007e55d47d341b  pop r10
00007e55d47d341d  pop r9
00007e55d47d341f  pop r8
00007e55d47d3421  pop rsi
00007e55d47d3422  pop rdi
00007e55d47d3423  pop rdx
00007e55d47d3424  pop rcx
00007e55d47d3425  pop rax
00007e55d47d3426  add rsp, 0x08
00007e55d47d342a  jmp 0x00007E55D47CFED1
00007e55d47d342f  sub rsp, 0x08
00007e55d47d3433  push rax
00007e55d47d3434  push rcx
00007e55d47d3435  push rdx
00007e55d47d3436  push rdi
00007e55d47d3437  push rsi
00007e55d47d3438  push r8
00007e55d47d343a  push r9
00007e55d47d343c  push r10
00007e55d47d343e  push r11
00007e55d47d3440  sub rsp, 0xF0
00007e55d47d3447  vmovaps [rsp], xmm0
00007e55d47d344c  vmovaps [rsp+0x10], xmm1
00007e55d47d3452  vmovaps [rsp+0x20], xmm2
00007e55d47d3458  vmovaps [rsp+0x30], xmm3
00007e55d47d345e  vmovaps [rsp+0x40], xmm4
00007e55d47d3464  vmovaps [rsp+0x50], xmm5
00007e55d47d346a  vmovaps [rsp+0x60], xmm6
00007e55d47d3470  vmovaps [rsp+0x70], xmm7
00007e55d47d3476  vmovaps [rsp+0x80], xmm8
00007e55d47d347f  vmovaps [rsp+0x90], xmm9
00007e55d47d3488  vmovaps [rsp+0xA0], xmm10
00007e55d47d3491  vmovaps [rsp+0xB0], xmm11
00007e55d47d349a  vmovaps [rsp+0xC0], xmm12
00007e55d47d34a3  vmovaps [rsp+0xD0], xmm13
00007e55d47d34ac  vmovaps [rsp+0xE0], xmm15
00007e55d47d34b5  sub rsp, 0x30
00007e55d47d34b9  movaps [rsp], xmm14
00007e55d47d34be  movaps [rsp+0x10], xmm12
00007e55d47d34c4  movaps [rsp+0x20], xmm5
00007e55d47d34c9  lea rdi, [rsp]
00007e55d47d34cd  mov esi, 0x00
00007e55d47d34d2  mov rax, 0x55D0734A4530
00007e55d47d34dc  call rax
00007e55d47d34de  movaps xmm14, [rsp]
00007e55d47d34e3  add rsp, 0x30
00007e55d47d34e7  vmovaps xmm0, [rsp]
00007e55d47d34ec  vmovaps xmm1, [rsp+0x10]
00007e55d47d34f2  vmovaps xmm2, [rsp+0x20]
00007e55d47d34f8  vmovaps xmm3, [rsp+0x30]
00007e55d47d34fe  vmovaps xmm4, [rsp+0x40]
00007e55d47d3504  vmovaps xmm5, [rsp+0x50]
00007e55d47d350a  vmovaps xmm6, [rsp+0x60]
00007e55d47d3510  vmovaps xmm7, [rsp+0x70]
00007e55d47d3516  vmovaps xmm8, [rsp+0x80]
00007e55d47d351f  vmovaps xmm9, [rsp+0x90]
00007e55d47d3528  vmovaps xmm10, [rsp+0xA0]
00007e55d47d3531  vmovaps xmm11, [rsp+0xB0]
00007e55d47d353a  vmovaps xmm12, [rsp+0xC0]
00007e55d47d3543  vmovaps xmm13, [rsp+0xD0]
00007e55d47d354c  vmovaps xmm15, [rsp+0xE0]
00007e55d47d3555  add rsp, 0xF0
00007e55d47d355c  pop r11
00007e55d47d355e  pop r10
00007e55d47d3560  pop r9
00007e55d47d3562  pop r8
00007e55d47d3564  pop rsi
00007e55d47d3565  pop rdi
00007e55d47d3566  pop rdx
00007e55d47d3567  pop rcx
00007e55d47d3568  pop rax
00007e55d47d3569  add rsp, 0x08
00007e55d47d356d  jmp 0x00007E55D47CFEF1
00007e55d47d3572  sub rsp, 0x08
00007e55d47d3576  push rax
00007e55d47d3577  push rcx
00007e55d47d3578  push rdx
00007e55d47d3579  push rdi
00007e55d47d357a  push rsi
00007e55d47d357b  push r8
00007e55d47d357d  push r9
00007e55d47d357f  push r10
00007e55d47d3581  push r11
00007e55d47d3583  sub rsp, 0xF0
00007e55d47d358a  vmovaps [rsp], xmm0
00007e55d47d358f  vmovaps [rsp+0x10], xmm1
00007e55d47d3595  vmovaps [rsp+0x20], xmm2
00007e55d47d359b  vmovaps [rsp+0x30], xmm3
00007e55d47d35a1  vmovaps [rsp+0x40], xmm4
00007e55d47d35a7  vmovaps [rsp+0x50], xmm5
00007e55d47d35ad  vmovaps [rsp+0x60], xmm7
00007e55d47d35b3  vmovaps [rsp+0x70], xmm8
00007e55d47d35b9  vmovaps [rsp+0x80], xmm9
00007e55d47d35c2  vmovaps [rsp+0x90], xmm10
00007e55d47d35cb  vmovaps [rsp+0xA0], xmm11
00007e55d47d35d4  vmovaps [rsp+0xB0], xmm12
00007e55d47d35dd  vmovaps [rsp+0xC0], xmm13
00007e55d47d35e6  vmovaps [rsp+0xD0], xmm14
00007e55d47d35ef  vmovaps [rsp+0xE0], xmm15
00007e55d47d35f8  sub rsp, 0x30
00007e55d47d35fc  movaps [rsp], xmm6
00007e55d47d3600  movaps [rsp+0x10], xmm9
00007e55d47d3606  movaps [rsp+0x20], xmm12
00007e55d47d360c  lea rdi, [rsp]
00007e55d47d3610  mov esi, 0x00
00007e55d47d3615  mov rax, 0x55D0734A4530
00007e55d47d361f  call rax
00007e55d47d3621  movaps xmm6, [rsp]
00007e55d47d3625  add rsp, 0x30
00007e55d47d3629  vmovaps xmm0, [rsp]
00007e55d47d362e  vmovaps xmm1, [rsp+0x10]
00007e55d47d3634  vmovaps xmm2, [rsp+0x20]
00007e55d47d363a  vmovaps xmm3, [rsp+0x30]
00007e55d47d3640  vmovaps xmm4, [rsp+0x40]
00007e55d47d3646  vmovaps xmm5, [rsp+0x50]
00007e55d47d364c  vmovaps xmm7, [rsp+0x60]
00007e55d47d3652  vmovaps xmm8, [rsp+0x70]
00007e55d47d3658  vmovaps xmm9, [rsp+0x80]
00007e55d47d3661  vmovaps xmm10, [rsp+0x90]
00007e55d47d366a  vmovaps xmm11, [rsp+0xA0]
00007e55d47d3673  vmovaps xmm12, [rsp+0xB0]
00007e55d47d367c  vmovaps xmm13, [rsp+0xC0]
00007e55d47d3685  vmovaps xmm14, [rsp+0xD0]
00007e55d47d368e  vmovaps xmm15, [rsp+0xE0]
00007e55d47d3697  add rsp, 0xF0
00007e55d47d369e  pop r11
00007e55d47d36a0  pop r10
00007e55d47d36a2  pop r9
00007e55d47d36a4  pop r8
00007e55d47d36a6  pop rsi
00007e55d47d36a7  pop rdi
00007e55d47d36a8  pop rdx
00007e55d47d36a9  pop rcx
00007e55d47d36aa  pop rax
00007e55d47d36ab  add rsp, 0x08
00007e55d47d36af  jmp 0x00007E55D47CFF19
00007e55d47d36b4  sub rsp, 0x08
00007e55d47d36b8  push rax
00007e55d47d36b9  push rcx
00007e55d47d36ba  push rdx
00007e55d47d36bb  push rdi
00007e55d47d36bc  push rsi
00007e55d47d36bd  push r8
00007e55d47d36bf  push r9
00007e55d47d36c1  push r10
00007e55d47d36c3  push r11
00007e55d47d36c5  sub rsp, 0xF0
00007e55d47d36cc  vmovaps [rsp], xmm0
00007e55d47d36d1  vmovaps [rsp+0x10], xmm1
00007e55d47d36d7  vmovaps [rsp+0x20], xmm2
00007e55d47d36dd  vmovaps [rsp+0x30], xmm3
00007e55d47d36e3  vmovaps [rsp+0x40], xmm4
00007e55d47d36e9  vmovaps [rsp+0x50], xmm5
00007e55d47d36ef  vmovaps [rsp+0x60], xmm6
00007e55d47d36f5  vmovaps [rsp+0x70], xmm7
00007e55d47d36fb  vmovaps [rsp+0x80], xmm8
00007e55d47d3704  vmovaps [rsp+0x90], xmm9
00007e55d47d370d  vmovaps [rsp+0xA0], xmm10
00007e55d47d3716  vmovaps [rsp+0xB0], xmm11
00007e55d47d371f  vmovaps [rsp+0xC0], xmm13
00007e55d47d3728  vmovaps [rsp+0xD0], xmm14
00007e55d47d3731  vmovaps [rsp+0xE0], xmm15
00007e55d47d373a  sub rsp, 0x30
00007e55d47d373e  movaps [rsp], xmm12
00007e55d47d3743  movaps [rsp+0x10], xmm15
00007e55d47d3749  movaps [rsp+0x20], xmm13
00007e55d47d374f  lea rdi, [rsp]
00007e55d47d3753  mov esi, 0x00
00007e55d47d3758  mov rax, 0x55D0734A4530
00007e55d47d3762  call rax
00007e55d47d3764  movaps xmm12, [rsp]
00007e55d47d3769  add rsp, 0x30
00007e55d47d376d  vmovaps xmm0, [rsp]
00007e55d47d3772  vmovaps xmm1, [rsp+0x10]
00007e55d47d3778  vmovaps xmm2, [rsp+0x20]
00007e55d47d377e  vmovaps xmm3, [rsp+0x30]
00007e55d47d3784  vmovaps xmm4, [rsp+0x40]
00007e55d47d378a  vmovaps xmm5, [rsp+0x50]
00007e55d47d3790  vmovaps xmm6, [rsp+0x60]
00007e55d47d3796  vmovaps xmm7, [rsp+0x70]
00007e55d47d379c  vmovaps xmm8, [rsp+0x80]
00007e55d47d37a5  vmovaps xmm9, [rsp+0x90]
00007e55d47d37ae  vmovaps xmm10, [rsp+0xA0]
00007e55d47d37b7  vmovaps xmm11, [rsp+0xB0]
00007e55d47d37c0  vmovaps xmm13, [rsp+0xC0]
00007e55d47d37c9  vmovaps xmm14, [rsp+0xD0]
00007e55d47d37d2  vmovaps xmm15, [rsp+0xE0]
00007e55d47d37db  add rsp, 0xF0
00007e55d47d37e2  pop r11
00007e55d47d37e4  pop r10
00007e55d47d37e6  pop r9
00007e55d47d37e8  pop r8
00007e55d47d37ea  pop rsi
00007e55d47d37eb  pop rdi
00007e55d47d37ec  pop rdx
00007e55d47d37ed  pop rcx
00007e55d47d37ee  pop rax
00007e55d47d37ef  add rsp, 0x08
00007e55d47d37f3  jmp 0x00007E55D47CFF34
00007e55d47d37f8  sub rsp, 0x08
00007e55d47d37fc  push rax
00007e55d47d37fd  push rcx
00007e55d47d37fe  push rdx
00007e55d47d37ff  push rdi
00007e55d47d3800  push rsi
00007e55d47d3801  push r8
00007e55d47d3803  push r9
00007e55d47d3805  push r10
00007e55d47d3807  push r11
00007e55d47d3809  sub rsp, 0xF0
00007e55d47d3810  vmovaps [rsp], xmm0
00007e55d47d3815  vmovaps [rsp+0x10], xmm1
00007e55d47d381b  vmovaps [rsp+0x20], xmm2
00007e55d47d3821  vmovaps [rsp+0x30], xmm3
00007e55d47d3827  vmovaps [rsp+0x40], xmm4
00007e55d47d382d  vmovaps [rsp+0x50], xmm5
00007e55d47d3833  vmovaps [rsp+0x60], xmm6
00007e55d47d3839  vmovaps [rsp+0x70], xmm7
00007e55d47d383f  vmovaps [rsp+0x80], xmm8
00007e55d47d3848  vmovaps [rsp+0x90], xmm9
00007e55d47d3851  vmovaps [rsp+0xA0], xmm10
00007e55d47d385a  vmovaps [rsp+0xB0], xmm11
00007e55d47d3863  vmovaps [rsp+0xC0], xmm12
00007e55d47d386c  vmovaps [rsp+0xD0], xmm13
00007e55d47d3875  vmovaps [rsp+0xE0], xmm14
00007e55d47d387e  sub rsp, 0x30
00007e55d47d3882  movaps [rsp], xmm15
00007e55d47d3887  movaps [rsp+0x10], xmm13
00007e55d47d388d  movaps [rsp+0x20], xmm10
00007e55d47d3893  lea rdi, [rsp]
00007e55d47d3897  mov esi, 0x00
00007e55d47d389c  mov rax, 0x55D0734A4530
00007e55d47d38a6  call rax
00007e55d47d38a8  movaps xmm15, [rsp]
00007e55d47d38ad  add rsp, 0x30
00007e55d47d38b1  vmovaps xmm0, [rsp]
00007e55d47d38b6  vmovaps xmm1, [rsp+0x10]
00007e55d47d38bc  vmovaps xmm2, [rsp+0x20]
00007e55d47d38c2  vmovaps xmm3, [rsp+0x30]
00007e55d47d38c8  vmovaps xmm4, [rsp+0x40]
00007e55d47d38ce  vmovaps xmm5, [rsp+0x50]
00007e55d47d38d4  vmovaps xmm6, [rsp+0x60]
00007e55d47d38da  vmovaps xmm7, [rsp+0x70]
00007e55d47d38e0  vmovaps xmm8, [rsp+0x80]
00007e55d47d38e9  vmovaps xmm9, [rsp+0x90]
00007e55d47d38f2  vmovaps xmm10, [rsp+0xA0]
00007e55d47d38fb  vmovaps xmm11, [rsp+0xB0]
00007e55d47d3904  vmovaps xmm12, [rsp+0xC0]
00007e55d47d390d  vmovaps xmm13, [rsp+0xD0]
00007e55d47d3916  vmovaps xmm14, [rsp+0xE0]
00007e55d47d391f  add rsp, 0xF0
00007e55d47d3926  pop r11
00007e55d47d3928  pop r10
00007e55d47d392a  pop r9
00007e55d47d392c  pop r8
00007e55d47d392e  pop rsi
00007e55d47d392f  pop rdi
00007e55d47d3930  pop rdx
00007e55d47d3931  pop rcx
00007e55d47d3932  pop rax
00007e55d47d3933  add rsp, 0x08
00007e55d47d3937  jmp 0x00007E55D47CFF55
00007e55d47d393c  call 0x00007E55D460C260
00007e55d47d3941  jmp 0x00007E55D47CFFB0
00007e55d47d3946  sub rsp, 0x08
00007e55d47d394a  push rax
00007e55d47d394b  push rcx
00007e55d47d394c  push rdx
00007e55d47d394d  push rdi
00007e55d47d394e  push rsi
00007e55d47d394f  push r8
00007e55d47d3951  push r9
00007e55d47d3953  push r10
00007e55d47d3955  push r11
00007e55d47d3957  sub rsp, 0xF0
00007e55d47d395e  vmovaps [rsp], xmm0
00007e55d47d3963  vmovaps [rsp+0x10], xmm1
00007e55d47d3969  vmovaps [rsp+0x20], xmm2
00007e55d47d396f  vmovaps [rsp+0x30], xmm3
00007e55d47d3975  vmovaps [rsp+0x40], xmm4
00007e55d47d397b  vmovaps [rsp+0x50], xmm5
00007e55d47d3981  vmovaps [rsp+0x60], xmm6
00007e55d47d3987  vmovaps [rsp+0x70], xmm7
00007e55d47d398d  vmovaps [rsp+0x80], xmm8
00007e55d47d3996  vmovaps [rsp+0x90], xmm10
00007e55d47d399f  vmovaps [rsp+0xA0], xmm11
00007e55d47d39a8  vmovaps [rsp+0xB0], xmm12
00007e55d47d39b1  vmovaps [rsp+0xC0], xmm13
00007e55d47d39ba  vmovaps [rsp+0xD0], xmm14
00007e55d47d39c3  vmovaps [rsp+0xE0], xmm15
00007e55d47d39cc  sub rsp, 0x30
00007e55d47d39d0  movaps [rsp], xmm9
00007e55d47d39d5  movaps [rsp+0x10], xmm8
00007e55d47d39db  movaps [rsp+0x20], xmm10
00007e55d47d39e1  lea rdi, [rsp]
00007e55d47d39e5  mov esi, 0x00
00007e55d47d39ea  mov rax, 0x55D0734A4530
00007e55d47d39f4  call rax
00007e55d47d39f6  movaps xmm9, [rsp]
00007e55d47d39fb  add rsp, 0x30
00007e55d47d39ff  vmovaps xmm0, [rsp]
00007e55d47d3a04  vmovaps xmm1, [rsp+0x10]
00007e55d47d3a0a  vmovaps xmm2, [rsp+0x20]
00007e55d47d3a10  vmovaps xmm3, [rsp+0x30]
00007e55d47d3a16  vmovaps xmm4, [rsp+0x40]
00007e55d47d3a1c  vmovaps xmm5, [rsp+0x50]
00007e55d47d3a22  vmovaps xmm6, [rsp+0x60]
00007e55d47d3a28  vmovaps xmm7, [rsp+0x70]
00007e55d47d3a2e  vmovaps xmm8, [rsp+0x80]
00007e55d47d3a37  vmovaps xmm10, [rsp+0x90]
00007e55d47d3a40  vmovaps xmm11, [rsp+0xA0]
00007e55d47d3a49  vmovaps xmm12, [rsp+0xB0]
00007e55d47d3a52  vmovaps xmm13, [rsp+0xC0]
00007e55d47d3a5b  vmovaps xmm14, [rsp+0xD0]
00007e55d47d3a64  vmovaps xmm15, [rsp+0xE0]
00007e55d47d3a6d  add rsp, 0xF0
00007e55d47d3a74  pop r11
00007e55d47d3a76  pop r10
00007e55d47d3a78  pop r9
00007e55d47d3a7a  pop r8
00007e55d47d3a7c  pop rsi
00007e55d47d3a7d  pop rdi
00007e55d47d3a7e  pop rdx
00007e55d47d3a7f  pop rcx
00007e55d47d3a80  pop rax
00007e55d47d3a81  add rsp, 0x08
00007e55d47d3a85  jmp 0x00007E55D47CFFE1
00007e55d47d3a8a  sub rsp, 0x08
00007e55d47d3a8e  push rax
00007e55d47d3a8f  push rcx
00007e55d47d3a90  push rdx
00007e55d47d3a91  push rdi
00007e55d47d3a92  push rsi
00007e55d47d3a93  push r8
00007e55d47d3a95  push r9
00007e55d47d3a97  push r10
00007e55d47d3a99  push r11
00007e55d47d3a9b  sub rsp, 0xF0
00007e55d47d3aa2  vmovaps [rsp], xmm0
00007e55d47d3aa7  vmovaps [rsp+0x10], xmm1
00007e55d47d3aad  vmovaps [rsp+0x20], xmm2
00007e55d47d3ab3  vmovaps [rsp+0x30], xmm3
00007e55d47d3ab9  vmovaps [rsp+0x40], xmm4
00007e55d47d3abf  vmovaps [rsp+0x50], xmm5
00007e55d47d3ac5  vmovaps [rsp+0x60], xmm6
00007e55d47d3acb  vmovaps [rsp+0x70], xmm7
00007e55d47d3ad1  vmovaps [rsp+0x80], xmm8
00007e55d47d3ada  vmovaps [rsp+0x90], xmm9
00007e55d47d3ae3  vmovaps [rsp+0xA0], xmm11
00007e55d47d3aec  vmovaps [rsp+0xB0], xmm12
00007e55d47d3af5  vmovaps [rsp+0xC0], xmm13
00007e55d47d3afe  vmovaps [rsp+0xD0], xmm14
00007e55d47d3b07  vmovaps [rsp+0xE0], xmm15
00007e55d47d3b10  sub rsp, 0x30
00007e55d47d3b14  movaps [rsp], xmm10
00007e55d47d3b19  movaps [rsp+0x10], xmm1
00007e55d47d3b1e  movaps [rsp+0x20], xmm11
00007e55d47d3b24  lea rdi, [rsp]
00007e55d47d3b28  mov esi, 0x00
00007e55d47d3b2d  mov rax, 0x55D0734A4530
00007e55d47d3b37  call rax
00007e55d47d3b39  movaps xmm10, [rsp]
00007e55d47d3b3e  add rsp, 0x30
00007e55d47d3b42  vmovaps xmm0, [rsp]
00007e55d47d3b47  vmovaps xmm1, [rsp+0x10]
00007e55d47d3b4d  vmovaps xmm2, [rsp+0x20]
00007e55d47d3b53  vmovaps xmm3, [rsp+0x30]
00007e55d47d3b59  vmovaps xmm4, [rsp+0x40]
00007e55d47d3b5f  vmovaps xmm5, [rsp+0x50]
00007e55d47d3b65  vmovaps xmm6, [rsp+0x60]
00007e55d47d3b6b  vmovaps xmm7, [rsp+0x70]
00007e55d47d3b71  vmovaps xmm8, [rsp+0x80]
00007e55d47d3b7a  vmovaps xmm9, [rsp+0x90]
00007e55d47d3b83  vmovaps xmm11, [rsp+0xA0]
00007e55d47d3b8c  vmovaps xmm12, [rsp+0xB0]
00007e55d47d3b95  vmovaps xmm13, [rsp+0xC0]
00007e55d47d3b9e  vmovaps xmm14, [rsp+0xD0]
00007e55d47d3ba7  vmovaps xmm15, [rsp+0xE0]
00007e55d47d3bb0  add rsp, 0xF0
00007e55d47d3bb7  pop r11
00007e55d47d3bb9  pop r10
00007e55d47d3bbb  pop r9
00007e55d47d3bbd  pop r8
00007e55d47d3bbf  pop rsi
00007e55d47d3bc0  pop rdi
00007e55d47d3bc1  pop rdx
00007e55d47d3bc2  pop rcx
00007e55d47d3bc3  pop rax
00007e55d47d3bc4  add rsp, 0x08
00007e55d47d3bc8  jmp 0x00007E55D47CFFFC
00007e55d47d3bcd  sub rsp, 0x08
00007e55d47d3bd1  push rax
00007e55d47d3bd2  push rcx
00007e55d47d3bd3  push rdx
00007e55d47d3bd4  push rdi
00007e55d47d3bd5  push rsi
00007e55d47d3bd6  push r8
00007e55d47d3bd8  push r9
00007e55d47d3bda  push r10
00007e55d47d3bdc  push r11
00007e55d47d3bde  sub rsp, 0xF0
00007e55d47d3be5  vmovaps [rsp], xmm0
00007e55d47d3bea  vmovaps [rsp+0x10], xmm2
00007e55d47d3bf0  vmovaps [rsp+0x20], xmm3
00007e55d47d3bf6  vmovaps [rsp+0x30], xmm4
00007e55d47d3bfc  vmovaps [rsp+0x40], xmm5
00007e55d47d3c02  vmovaps [rsp+0x50], xmm6
00007e55d47d3c08  vmovaps [rsp+0x60], xmm7
00007e55d47d3c0e  vmovaps [rsp+0x70], xmm8
00007e55d47d3c14  vmovaps [rsp+0x80], xmm9
00007e55d47d3c1d  vmovaps [rsp+0x90], xmm10
00007e55d47d3c26  vmovaps [rsp+0xA0], xmm11
00007e55d47d3c2f  vmovaps [rsp+0xB0], xmm12
00007e55d47d3c38  vmovaps [rsp+0xC0], xmm13
00007e55d47d3c41  vmovaps [rsp+0xD0], xmm14
00007e55d47d3c4a  vmovaps [rsp+0xE0], xmm15
00007e55d47d3c53  sub rsp, 0x30
00007e55d47d3c57  movaps [rsp], xmm1
00007e55d47d3c5b  movaps [rsp+0x10], xmm14
00007e55d47d3c61  movaps [rsp+0x20], xmm6
00007e55d47d3c66  lea rdi, [rsp]
00007e55d47d3c6a  mov esi, 0x00
00007e55d47d3c6f  mov rax, 0x55D0734A4530
00007e55d47d3c79  call rax
00007e55d47d3c7b  movaps xmm1, [rsp]
00007e55d47d3c7f  add rsp, 0x30
00007e55d47d3c83  vmovaps xmm0, [rsp]
00007e55d47d3c88  vmovaps xmm2, [rsp+0x10]
00007e55d47d3c8e  vmovaps xmm3, [rsp+0x20]
00007e55d47d3c94  vmovaps xmm4, [rsp+0x30]
00007e55d47d3c9a  vmovaps xmm5, [rsp+0x40]
00007e55d47d3ca0  vmovaps xmm6, [rsp+0x50]
00007e55d47d3ca6  vmovaps xmm7, [rsp+0x60]
00007e55d47d3cac  vmovaps xmm8, [rsp+0x70]
00007e55d47d3cb2  vmovaps xmm9, [rsp+0x80]
00007e55d47d3cbb  vmovaps xmm10, [rsp+0x90]
00007e55d47d3cc4  vmovaps xmm11, [rsp+0xA0]
00007e55d47d3ccd  vmovaps xmm12, [rsp+0xB0]
00007e55d47d3cd6  vmovaps xmm13, [rsp+0xC0]
00007e55d47d3cdf  vmovaps xmm14, [rsp+0xD0]
00007e55d47d3ce8  vmovaps xmm15, [rsp+0xE0]
00007e55d47d3cf1  add rsp, 0xF0
00007e55d47d3cf8  pop r11
00007e55d47d3cfa  pop r10
00007e55d47d3cfc  pop r9
00007e55d47d3cfe  pop r8
00007e55d47d3d00  pop rsi
00007e55d47d3d01  pop rdi
00007e55d47d3d02  pop rdx
00007e55d47d3d03  pop rcx
00007e55d47d3d04  pop rax
00007e55d47d3d05  add rsp, 0x08
00007e55d47d3d09  jmp 0x00007E55D47D0015
00007e55d47d3d0e  sub rsp, 0x08
00007e55d47d3d12  push rax
00007e55d47d3d13  push rcx
00007e55d47d3d14  push rdx
00007e55d47d3d15  push rdi
00007e55d47d3d16  push rsi
00007e55d47d3d17  push r8
00007e55d47d3d19  push r9
00007e55d47d3d1b  push r10
00007e55d47d3d1d  push r11
00007e55d47d3d1f  sub rsp, 0xF0
00007e55d47d3d26  vmovaps [rsp], xmm0
00007e55d47d3d2b  vmovaps [rsp+0x10], xmm1
00007e55d47d3d31  vmovaps [rsp+0x20], xmm2
00007e55d47d3d37  vmovaps [rsp+0x30], xmm3
00007e55d47d3d3d  vmovaps [rsp+0x40], xmm4
00007e55d47d3d43  vmovaps [rsp+0x50], xmm5
00007e55d47d3d49  vmovaps [rsp+0x60], xmm6
00007e55d47d3d4f  vmovaps [rsp+0x70], xmm7
00007e55d47d3d55  vmovaps [rsp+0x80], xmm8
00007e55d47d3d5e  vmovaps [rsp+0x90], xmm9
00007e55d47d3d67  vmovaps [rsp+0xA0], xmm10
00007e55d47d3d70  vmovaps [rsp+0xB0], xmm12
00007e55d47d3d79  vmovaps [rsp+0xC0], xmm13
00007e55d47d3d82  vmovaps [rsp+0xD0], xmm14
00007e55d47d3d8b  vmovaps [rsp+0xE0], xmm15
00007e55d47d3d94  sub rsp, 0x30
00007e55d47d3d98  movaps [rsp], xmm11
00007e55d47d3d9d  movaps [rsp+0x10], xmm13
00007e55d47d3da3  movaps [rsp+0x20], xmm14
00007e55d47d3da9  lea rdi, [rsp]
00007e55d47d3dad  mov esi, 0x00
00007e55d47d3db2  mov rax, 0x55D0734A4530
00007e55d47d3dbc  call rax
00007e55d47d3dbe  movaps xmm11, [rsp]
00007e55d47d3dc3  add rsp, 0x30
00007e55d47d3dc7  vmovaps xmm0, [rsp]
00007e55d47d3dcc  vmovaps xmm1, [rsp+0x10]
00007e55d47d3dd2  vmovaps xmm2, [rsp+0x20]
00007e55d47d3dd8  vmovaps xmm3, [rsp+0x30]
00007e55d47d3dde  vmovaps xmm4, [rsp+0x40]
00007e55d47d3de4  vmovaps xmm5, [rsp+0x50]
00007e55d47d3dea  vmovaps xmm6, [rsp+0x60]
00007e55d47d3df0  vmovaps xmm7, [rsp+0x70]
00007e55d47d3df6  vmovaps xmm8, [rsp+0x80]
00007e55d47d3dff  vmovaps xmm9, [rsp+0x90]
00007e55d47d3e08  vmovaps xmm10, [rsp+0xA0]
00007e55d47d3e11  vmovaps xmm12, [rsp+0xB0]
00007e55d47d3e1a  vmovaps xmm13, [rsp+0xC0]
00007e55d47d3e23  vmovaps xmm14, [rsp+0xD0]
00007e55d47d3e2c  vmovaps xmm15, [rsp+0xE0]
00007e55d47d3e35  add rsp, 0xF0
00007e55d47d3e3c  pop r11
00007e55d47d3e3e  pop r10
00007e55d47d3e40  pop r9
00007e55d47d3e42  pop r8
00007e55d47d3e44  pop rsi
00007e55d47d3e45  pop rdi
00007e55d47d3e46  pop rdx
00007e55d47d3e47  pop rcx
00007e55d47d3e48  pop rax
00007e55d47d3e49  add rsp, 0x08
00007e55d47d3e4d  jmp 0x00007E55D47D003F
00007e55d47d3e52  sub rsp, 0x08
00007e55d47d3e56  push rax
00007e55d47d3e57  push rcx
00007e55d47d3e58  push rdx
00007e55d47d3e59  push rdi
00007e55d47d3e5a  push rsi
00007e55d47d3e5b  push r8
00007e55d47d3e5d  push r9
00007e55d47d3e5f  push r10
00007e55d47d3e61  push r11
00007e55d47d3e63  sub rsp, 0xF0
00007e55d47d3e6a  vmovaps [rsp], xmm0
00007e55d47d3e6f  vmovaps [rsp+0x10], xmm1
00007e55d47d3e75  vmovaps [rsp+0x20], xmm2
00007e55d47d3e7b  vmovaps [rsp+0x30], xmm3
00007e55d47d3e81  vmovaps [rsp+0x40], xmm4
00007e55d47d3e87  vmovaps [rsp+0x50], xmm5
00007e55d47d3e8d  vmovaps [rsp+0x60], xmm6
00007e55d47d3e93  vmovaps [rsp+0x70], xmm7
00007e55d47d3e99  vmovaps [rsp+0x80], xmm8
00007e55d47d3ea2  vmovaps [rsp+0x90], xmm9
00007e55d47d3eab  vmovaps [rsp+0xA0], xmm10
00007e55d47d3eb4  vmovaps [rsp+0xB0], xmm11
00007e55d47d3ebd  vmovaps [rsp+0xC0], xmm12
00007e55d47d3ec6  vmovaps [rsp+0xD0], xmm14
00007e55d47d3ecf  vmovaps [rsp+0xE0], xmm15
00007e55d47d3ed8  sub rsp, 0x30
00007e55d47d3edc  movaps [rsp], xmm13
00007e55d47d3ee1  movaps [rsp+0x10], xmm8
00007e55d47d3ee7  movaps [rsp+0x20], xmm14
00007e55d47d3eed  lea rdi, [rsp]
00007e55d47d3ef1  mov esi, 0x00
00007e55d47d3ef6  mov rax, 0x55D0734A4530
00007e55d47d3f00  call rax
00007e55d47d3f02  movaps xmm13, [rsp]
00007e55d47d3f07  add rsp, 0x30
00007e55d47d3f0b  vmovaps xmm0, [rsp]
00007e55d47d3f10  vmovaps xmm1, [rsp+0x10]
00007e55d47d3f16  vmovaps xmm2, [rsp+0x20]
00007e55d47d3f1c  vmovaps xmm3, [rsp+0x30]
00007e55d47d3f22  vmovaps xmm4, [rsp+0x40]
00007e55d47d3f28  vmovaps xmm5, [rsp+0x50]
00007e55d47d3f2e  vmovaps xmm6, [rsp+0x60]
00007e55d47d3f34  vmovaps xmm7, [rsp+0x70]
00007e55d47d3f3a  vmovaps xmm8, [rsp+0x80]
00007e55d47d3f43  vmovaps xmm9, [rsp+0x90]
00007e55d47d3f4c  vmovaps xmm10, [rsp+0xA0]
00007e55d47d3f55  vmovaps xmm11, [rsp+0xB0]
00007e55d47d3f5e  vmovaps xmm12, [rsp+0xC0]
00007e55d47d3f67  vmovaps xmm14, [rsp+0xD0]
00007e55d47d3f70  vmovaps xmm15, [rsp+0xE0]
00007e55d47d3f79  add rsp, 0xF0
00007e55d47d3f80  pop r11
00007e55d47d3f82  pop r10
00007e55d47d3f84  pop r9
00007e55d47d3f86  pop r8
00007e55d47d3f88  pop rsi
00007e55d47d3f89  pop rdi
00007e55d47d3f8a  pop rdx
00007e55d47d3f8b  pop rcx
00007e55d47d3f8c  pop rax
00007e55d47d3f8d  add rsp, 0x08
00007e55d47d3f91  jmp 0x00007E55D47D006E
00007e55d47d3f96  sub rsp, 0x08
00007e55d47d3f9a  push rax
00007e55d47d3f9b  push rcx
00007e55d47d3f9c  push rdx
00007e55d47d3f9d  push rdi
00007e55d47d3f9e  push rsi
00007e55d47d3f9f  push r8
00007e55d47d3fa1  push r9
00007e55d47d3fa3  push r10
00007e55d47d3fa5  push r11
00007e55d47d3fa7  sub rsp, 0xF0
00007e55d47d3fae  vmovaps [rsp], xmm0
00007e55d47d3fb3  vmovaps [rsp+0x10], xmm1
00007e55d47d3fb9  vmovaps [rsp+0x20], xmm2
00007e55d47d3fbf  vmovaps [rsp+0x30], xmm3
00007e55d47d3fc5  vmovaps [rsp+0x40], xmm4
00007e55d47d3fcb  vmovaps [rsp+0x50], xmm5
00007e55d47d3fd1  vmovaps [rsp+0x60], xmm6
00007e55d47d3fd7  vmovaps [rsp+0x70], xmm7
00007e55d47d3fdd  vmovaps [rsp+0x80], xmm9
00007e55d47d3fe6  vmovaps [rsp+0x90], xmm10
00007e55d47d3fef  vmovaps [rsp+0xA0], xmm11
00007e55d47d3ff8  vmovaps [rsp+0xB0], xmm12
00007e55d47d4001  vmovaps [rsp+0xC0], xmm13
00007e55d47d400a  vmovaps [rsp+0xD0], xmm14
00007e55d47d4013  vmovaps [rsp+0xE0], xmm15
00007e55d47d401c  sub rsp, 0x30
00007e55d47d4020  movaps [rsp], xmm8
00007e55d47d4025  movaps [rsp+0x10], xmm7
00007e55d47d402a  movaps [rsp+0x20], xmm14
00007e55d47d4030  lea rdi, [rsp]
00007e55d47d4034  mov esi, 0x00
00007e55d47d4039  mov rax, 0x55D0734A4530
00007e55d47d4043  call rax
00007e55d47d4045  movaps xmm8, [rsp]
00007e55d47d404a  add rsp, 0x30
00007e55d47d404e  vmovaps xmm0, [rsp]
00007e55d47d4053  vmovaps xmm1, [rsp+0x10]
00007e55d47d4059  vmovaps xmm2, [rsp+0x20]
00007e55d47d405f  vmovaps xmm3, [rsp+0x30]
00007e55d47d4065  vmovaps xmm4, [rsp+0x40]
00007e55d47d406b  vmovaps xmm5, [rsp+0x50]
00007e55d47d4071  vmovaps xmm6, [rsp+0x60]
00007e55d47d4077  vmovaps xmm7, [rsp+0x70]
00007e55d47d407d  vmovaps xmm9, [rsp+0x80]
00007e55d47d4086  vmovaps xmm10, [rsp+0x90]
00007e55d47d408f  vmovaps xmm11, [rsp+0xA0]
00007e55d47d4098  vmovaps xmm12, [rsp+0xB0]
00007e55d47d40a1  vmovaps xmm13, [rsp+0xC0]
00007e55d47d40aa  vmovaps xmm14, [rsp+0xD0]
00007e55d47d40b3  vmovaps xmm15, [rsp+0xE0]
00007e55d47d40bc  add rsp, 0xF0
00007e55d47d40c3  pop r11
00007e55d47d40c5  pop r10
00007e55d47d40c7  pop r9
00007e55d47d40c9  pop r8
00007e55d47d40cb  pop rsi
00007e55d47d40cc  pop rdi
00007e55d47d40cd  pop rdx
00007e55d47d40ce  pop rcx
00007e55d47d40cf  pop rax
00007e55d47d40d0  add rsp, 0x08
00007e55d47d40d4  jmp 0x00007E55D47D0094
00007e55d47d40d9  sub rsp, 0x08
00007e55d47d40dd  push rax
00007e55d47d40de  push rcx
00007e55d47d40df  push rdx
00007e55d47d40e0  push rdi
00007e55d47d40e1  push rsi
00007e55d47d40e2  push r8
00007e55d47d40e4  push r9
00007e55d47d40e6  push r10
00007e55d47d40e8  push r11
00007e55d47d40ea  sub rsp, 0xF0
00007e55d47d40f1  vmovaps [rsp], xmm0
00007e55d47d40f6  vmovaps [rsp+0x10], xmm1
00007e55d47d40fc  vmovaps [rsp+0x20], xmm2
00007e55d47d4102  vmovaps [rsp+0x30], xmm3
00007e55d47d4108  vmovaps [rsp+0x40], xmm4
00007e55d47d410e  vmovaps [rsp+0x50], xmm5
00007e55d47d4114  vmovaps [rsp+0x60], xmm6
00007e55d47d411a  vmovaps [rsp+0x70], xmm7
00007e55d47d4120  vmovaps [rsp+0x80], xmm8
00007e55d47d4129  vmovaps [rsp+0x90], xmm9
00007e55d47d4132  vmovaps [rsp+0xA0], xmm10
00007e55d47d413b  vmovaps [rsp+0xB0], xmm11
00007e55d47d4144  vmovaps [rsp+0xC0], xmm12
00007e55d47d414d  vmovaps [rsp+0xD0], xmm13
00007e55d47d4156  vmovaps [rsp+0xE0], xmm15
00007e55d47d415f  sub rsp, 0x30
00007e55d47d4163  movaps [rsp], xmm14
00007e55d47d4168  movaps [rsp+0x10], xmm12
00007e55d47d416e  movaps [rsp+0x20], xmm9
00007e55d47d4174  lea rdi, [rsp]
00007e55d47d4178  mov esi, 0x00
00007e55d47d417d  mov rax, 0x55D0734A4530
00007e55d47d4187  call rax
00007e55d47d4189  movaps xmm14, [rsp]
00007e55d47d418e  add rsp, 0x30
00007e55d47d4192  vmovaps xmm0, [rsp]
00007e55d47d4197  vmovaps xmm1, [rsp+0x10]
00007e55d47d419d  vmovaps xmm2, [rsp+0x20]
00007e55d47d41a3  vmovaps xmm3, [rsp+0x30]
00007e55d47d41a9  vmovaps xmm4, [rsp+0x40]
00007e55d47d41af  vmovaps xmm5, [rsp+0x50]
00007e55d47d41b5  vmovaps xmm6, [rsp+0x60]
00007e55d47d41bb  vmovaps xmm7, [rsp+0x70]
00007e55d47d41c1  vmovaps xmm8, [rsp+0x80]
00007e55d47d41ca  vmovaps xmm9, [rsp+0x90]
00007e55d47d41d3  vmovaps xmm10, [rsp+0xA0]
00007e55d47d41dc  vmovaps xmm11, [rsp+0xB0]
00007e55d47d41e5  vmovaps xmm12, [rsp+0xC0]
00007e55d47d41ee  vmovaps xmm13, [rsp+0xD0]
00007e55d47d41f7  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4200  add rsp, 0xF0
00007e55d47d4207  pop r11
00007e55d47d4209  pop r10
00007e55d47d420b  pop r9
00007e55d47d420d  pop r8
00007e55d47d420f  pop rsi
00007e55d47d4210  pop rdi
00007e55d47d4211  pop rdx
00007e55d47d4212  pop rcx
00007e55d47d4213  pop rax
00007e55d47d4214  add rsp, 0x08
00007e55d47d4218  jmp 0x00007E55D47D00AE
00007e55d47d421d  sub rsp, 0x08
00007e55d47d4221  push rax
00007e55d47d4222  push rcx
00007e55d47d4223  push rdx
00007e55d47d4224  push rdi
00007e55d47d4225  push rsi
00007e55d47d4226  push r8
00007e55d47d4228  push r9
00007e55d47d422a  push r10
00007e55d47d422c  push r11
00007e55d47d422e  sub rsp, 0xF0
00007e55d47d4235  vmovaps [rsp], xmm0
00007e55d47d423a  vmovaps [rsp+0x10], xmm1
00007e55d47d4240  vmovaps [rsp+0x20], xmm2
00007e55d47d4246  vmovaps [rsp+0x30], xmm3
00007e55d47d424c  vmovaps [rsp+0x40], xmm4
00007e55d47d4252  vmovaps [rsp+0x50], xmm5
00007e55d47d4258  vmovaps [rsp+0x60], xmm6
00007e55d47d425e  vmovaps [rsp+0x70], xmm7
00007e55d47d4264  vmovaps [rsp+0x80], xmm8
00007e55d47d426d  vmovaps [rsp+0x90], xmm10
00007e55d47d4276  vmovaps [rsp+0xA0], xmm11
00007e55d47d427f  vmovaps [rsp+0xB0], xmm12
00007e55d47d4288  vmovaps [rsp+0xC0], xmm13
00007e55d47d4291  vmovaps [rsp+0xD0], xmm14
00007e55d47d429a  vmovaps [rsp+0xE0], xmm15
00007e55d47d42a3  sub rsp, 0x30
00007e55d47d42a7  movaps [rsp], xmm9
00007e55d47d42ac  movaps [rsp+0x10], xmm7
00007e55d47d42b1  movaps [rsp+0x20], xmm12
00007e55d47d42b7  lea rdi, [rsp]
00007e55d47d42bb  mov esi, 0x00
00007e55d47d42c0  mov rax, 0x55D0734A4530
00007e55d47d42ca  call rax
00007e55d47d42cc  movaps xmm9, [rsp]
00007e55d47d42d1  add rsp, 0x30
00007e55d47d42d5  vmovaps xmm0, [rsp]
00007e55d47d42da  vmovaps xmm1, [rsp+0x10]
00007e55d47d42e0  vmovaps xmm2, [rsp+0x20]
00007e55d47d42e6  vmovaps xmm3, [rsp+0x30]
00007e55d47d42ec  vmovaps xmm4, [rsp+0x40]
00007e55d47d42f2  vmovaps xmm5, [rsp+0x50]
00007e55d47d42f8  vmovaps xmm6, [rsp+0x60]
00007e55d47d42fe  vmovaps xmm7, [rsp+0x70]
00007e55d47d4304  vmovaps xmm8, [rsp+0x80]
00007e55d47d430d  vmovaps xmm10, [rsp+0x90]
00007e55d47d4316  vmovaps xmm11, [rsp+0xA0]
00007e55d47d431f  vmovaps xmm12, [rsp+0xB0]
00007e55d47d4328  vmovaps xmm13, [rsp+0xC0]
00007e55d47d4331  vmovaps xmm14, [rsp+0xD0]
00007e55d47d433a  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4343  add rsp, 0xF0
00007e55d47d434a  pop r11
00007e55d47d434c  pop r10
00007e55d47d434e  pop r9
00007e55d47d4350  pop r8
00007e55d47d4352  pop rsi
00007e55d47d4353  pop rdi
00007e55d47d4354  pop rdx
00007e55d47d4355  pop rcx
00007e55d47d4356  pop rax
00007e55d47d4357  add rsp, 0x08
00007e55d47d435b  jmp 0x00007E55D47D00DD
00007e55d47d4360  sub rsp, 0x08
00007e55d47d4364  push rax
00007e55d47d4365  push rcx
00007e55d47d4366  push rdx
00007e55d47d4367  push rdi
00007e55d47d4368  push rsi
00007e55d47d4369  push r8
00007e55d47d436b  push r9
00007e55d47d436d  push r10
00007e55d47d436f  push r11
00007e55d47d4371  sub rsp, 0xF0
00007e55d47d4378  vmovaps [rsp], xmm0
00007e55d47d437d  vmovaps [rsp+0x10], xmm1
00007e55d47d4383  vmovaps [rsp+0x20], xmm2
00007e55d47d4389  vmovaps [rsp+0x30], xmm3
00007e55d47d438f  vmovaps [rsp+0x40], xmm4
00007e55d47d4395  vmovaps [rsp+0x50], xmm5
00007e55d47d439b  vmovaps [rsp+0x60], xmm6
00007e55d47d43a1  vmovaps [rsp+0x70], xmm7
00007e55d47d43a7  vmovaps [rsp+0x80], xmm8
00007e55d47d43b0  vmovaps [rsp+0x90], xmm9
00007e55d47d43b9  vmovaps [rsp+0xA0], xmm10
00007e55d47d43c2  vmovaps [rsp+0xB0], xmm11
00007e55d47d43cb  vmovaps [rsp+0xC0], xmm13
00007e55d47d43d4  vmovaps [rsp+0xD0], xmm14
00007e55d47d43dd  vmovaps [rsp+0xE0], xmm15
00007e55d47d43e6  sub rsp, 0x30
00007e55d47d43ea  movaps [rsp], xmm12
00007e55d47d43ef  movaps [rsp+0x10], xmm15
00007e55d47d43f5  movaps [rsp+0x20], xmm11
00007e55d47d43fb  lea rdi, [rsp]
00007e55d47d43ff  mov esi, 0x00
00007e55d47d4404  mov rax, 0x55D0734A4530
00007e55d47d440e  call rax
00007e55d47d4410  movaps xmm12, [rsp]
00007e55d47d4415  add rsp, 0x30
00007e55d47d4419  vmovaps xmm0, [rsp]
00007e55d47d441e  vmovaps xmm1, [rsp+0x10]
00007e55d47d4424  vmovaps xmm2, [rsp+0x20]
00007e55d47d442a  vmovaps xmm3, [rsp+0x30]
00007e55d47d4430  vmovaps xmm4, [rsp+0x40]
00007e55d47d4436  vmovaps xmm5, [rsp+0x50]
00007e55d47d443c  vmovaps xmm6, [rsp+0x60]
00007e55d47d4442  vmovaps xmm7, [rsp+0x70]
00007e55d47d4448  vmovaps xmm8, [rsp+0x80]
00007e55d47d4451  vmovaps xmm9, [rsp+0x90]
00007e55d47d445a  vmovaps xmm10, [rsp+0xA0]
00007e55d47d4463  vmovaps xmm11, [rsp+0xB0]
00007e55d47d446c  vmovaps xmm13, [rsp+0xC0]
00007e55d47d4475  vmovaps xmm14, [rsp+0xD0]
00007e55d47d447e  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4487  add rsp, 0xF0
00007e55d47d448e  pop r11
00007e55d47d4490  pop r10
00007e55d47d4492  pop r9
00007e55d47d4494  pop r8
00007e55d47d4496  pop rsi
00007e55d47d4497  pop rdi
00007e55d47d4498  pop rdx
00007e55d47d4499  pop rcx
00007e55d47d449a  pop rax
00007e55d47d449b  add rsp, 0x08
00007e55d47d449f  jmp 0x00007E55D47D00F7
00007e55d47d44a4  sub rsp, 0x08
00007e55d47d44a8  push rax
00007e55d47d44a9  push rcx
00007e55d47d44aa  push rdx
00007e55d47d44ab  push rdi
00007e55d47d44ac  push rsi
00007e55d47d44ad  push r8
00007e55d47d44af  push r9
00007e55d47d44b1  push r10
00007e55d47d44b3  push r11
00007e55d47d44b5  sub rsp, 0xF0
00007e55d47d44bc  vmovaps [rsp], xmm0
00007e55d47d44c1  vmovaps [rsp+0x10], xmm1
00007e55d47d44c7  vmovaps [rsp+0x20], xmm2
00007e55d47d44cd  vmovaps [rsp+0x30], xmm3
00007e55d47d44d3  vmovaps [rsp+0x40], xmm4
00007e55d47d44d9  vmovaps [rsp+0x50], xmm5
00007e55d47d44df  vmovaps [rsp+0x60], xmm6
00007e55d47d44e5  vmovaps [rsp+0x70], xmm7
00007e55d47d44eb  vmovaps [rsp+0x80], xmm8
00007e55d47d44f4  vmovaps [rsp+0x90], xmm9
00007e55d47d44fd  vmovaps [rsp+0xA0], xmm10
00007e55d47d4506  vmovaps [rsp+0xB0], xmm12
00007e55d47d450f  vmovaps [rsp+0xC0], xmm13
00007e55d47d4518  vmovaps [rsp+0xD0], xmm14
00007e55d47d4521  vmovaps [rsp+0xE0], xmm15
00007e55d47d452a  sub rsp, 0x30
00007e55d47d452e  movaps [rsp], xmm11
00007e55d47d4533  movaps [rsp+0x10], xmm7
00007e55d47d4538  movaps [rsp+0x20], xmm15
00007e55d47d453e  lea rdi, [rsp]
00007e55d47d4542  mov esi, 0x00
00007e55d47d4547  mov rax, 0x55D0734A4530
00007e55d47d4551  call rax
00007e55d47d4553  movaps xmm11, [rsp]
00007e55d47d4558  add rsp, 0x30
00007e55d47d455c  vmovaps xmm0, [rsp]
00007e55d47d4561  vmovaps xmm1, [rsp+0x10]
00007e55d47d4567  vmovaps xmm2, [rsp+0x20]
00007e55d47d456d  vmovaps xmm3, [rsp+0x30]
00007e55d47d4573  vmovaps xmm4, [rsp+0x40]
00007e55d47d4579  vmovaps xmm5, [rsp+0x50]
00007e55d47d457f  vmovaps xmm6, [rsp+0x60]
00007e55d47d4585  vmovaps xmm7, [rsp+0x70]
00007e55d47d458b  vmovaps xmm8, [rsp+0x80]
00007e55d47d4594  vmovaps xmm9, [rsp+0x90]
00007e55d47d459d  vmovaps xmm10, [rsp+0xA0]
00007e55d47d45a6  vmovaps xmm12, [rsp+0xB0]
00007e55d47d45af  vmovaps xmm13, [rsp+0xC0]
00007e55d47d45b8  vmovaps xmm14, [rsp+0xD0]
00007e55d47d45c1  vmovaps xmm15, [rsp+0xE0]
00007e55d47d45ca  add rsp, 0xF0
00007e55d47d45d1  pop r11
00007e55d47d45d3  pop r10
00007e55d47d45d5  pop r9
00007e55d47d45d7  pop r8
00007e55d47d45d9  pop rsi
00007e55d47d45da  pop rdi
00007e55d47d45db  pop rdx
00007e55d47d45dc  pop rcx
00007e55d47d45dd  pop rax
00007e55d47d45de  add rsp, 0x08
00007e55d47d45e2  jmp 0x00007E55D47D0123
00007e55d47d45e7  sub rsp, 0x08
00007e55d47d45eb  push rax
00007e55d47d45ec  push rcx
00007e55d47d45ed  push rdx
00007e55d47d45ee  push rdi
00007e55d47d45ef  push rsi
00007e55d47d45f0  push r8
00007e55d47d45f2  push r9
00007e55d47d45f4  push r10
00007e55d47d45f6  push r11
00007e55d47d45f8  sub rsp, 0xF0
00007e55d47d45ff  vmovaps [rsp], xmm0
00007e55d47d4604  vmovaps [rsp+0x10], xmm1
00007e55d47d460a  vmovaps [rsp+0x20], xmm2
00007e55d47d4610  vmovaps [rsp+0x30], xmm3
00007e55d47d4616  vmovaps [rsp+0x40], xmm4
00007e55d47d461c  vmovaps [rsp+0x50], xmm5
00007e55d47d4622  vmovaps [rsp+0x60], xmm6
00007e55d47d4628  vmovaps [rsp+0x70], xmm7
00007e55d47d462e  vmovaps [rsp+0x80], xmm8
00007e55d47d4637  vmovaps [rsp+0x90], xmm9
00007e55d47d4640  vmovaps [rsp+0xA0], xmm10
00007e55d47d4649  vmovaps [rsp+0xB0], xmm11
00007e55d47d4652  vmovaps [rsp+0xC0], xmm12
00007e55d47d465b  vmovaps [rsp+0xD0], xmm13
00007e55d47d4664  vmovaps [rsp+0xE0], xmm14
00007e55d47d466d  sub rsp, 0x30
00007e55d47d4671  movaps [rsp], xmm15
00007e55d47d4676  movaps [rsp+0x10], xmm10
00007e55d47d467c  movaps [rsp+0x20], xmm13
00007e55d47d4682  lea rdi, [rsp]
00007e55d47d4686  mov esi, 0x00
00007e55d47d468b  mov rax, 0x55D0734A4530
00007e55d47d4695  call rax
00007e55d47d4697  movaps xmm15, [rsp]
00007e55d47d469c  add rsp, 0x30
00007e55d47d46a0  vmovaps xmm0, [rsp]
00007e55d47d46a5  vmovaps xmm1, [rsp+0x10]
00007e55d47d46ab  vmovaps xmm2, [rsp+0x20]
00007e55d47d46b1  vmovaps xmm3, [rsp+0x30]
00007e55d47d46b7  vmovaps xmm4, [rsp+0x40]
00007e55d47d46bd  vmovaps xmm5, [rsp+0x50]
00007e55d47d46c3  vmovaps xmm6, [rsp+0x60]
00007e55d47d46c9  vmovaps xmm7, [rsp+0x70]
00007e55d47d46cf  vmovaps xmm8, [rsp+0x80]
00007e55d47d46d8  vmovaps xmm9, [rsp+0x90]
00007e55d47d46e1  vmovaps xmm10, [rsp+0xA0]
00007e55d47d46ea  vmovaps xmm11, [rsp+0xB0]
00007e55d47d46f3  vmovaps xmm12, [rsp+0xC0]
00007e55d47d46fc  vmovaps xmm13, [rsp+0xD0]
00007e55d47d4705  vmovaps xmm14, [rsp+0xE0]
00007e55d47d470e  add rsp, 0xF0
00007e55d47d4715  pop r11
00007e55d47d4717  pop r10
00007e55d47d4719  pop r9
00007e55d47d471b  pop r8
00007e55d47d471d  pop rsi
00007e55d47d471e  pop rdi
00007e55d47d471f  pop rdx
00007e55d47d4720  pop rcx
00007e55d47d4721  pop rax
00007e55d47d4722  add rsp, 0x08
00007e55d47d4726  jmp 0x00007E55D47D013D
00007e55d47d472b  sub rsp, 0x08
00007e55d47d472f  push rax
00007e55d47d4730  push rcx
00007e55d47d4731  push rdx
00007e55d47d4732  push rdi
00007e55d47d4733  push rsi
00007e55d47d4734  push r8
00007e55d47d4736  push r9
00007e55d47d4738  push r10
00007e55d47d473a  push r11
00007e55d47d473c  sub rsp, 0xF0
00007e55d47d4743  vmovaps [rsp], xmm0
00007e55d47d4748  vmovaps [rsp+0x10], xmm1
00007e55d47d474e  vmovaps [rsp+0x20], xmm2
00007e55d47d4754  vmovaps [rsp+0x30], xmm3
00007e55d47d475a  vmovaps [rsp+0x40], xmm4
00007e55d47d4760  vmovaps [rsp+0x50], xmm5
00007e55d47d4766  vmovaps [rsp+0x60], xmm6
00007e55d47d476c  vmovaps [rsp+0x70], xmm7
00007e55d47d4772  vmovaps [rsp+0x80], xmm8
00007e55d47d477b  vmovaps [rsp+0x90], xmm9
00007e55d47d4784  vmovaps [rsp+0xA0], xmm11
00007e55d47d478d  vmovaps [rsp+0xB0], xmm12
00007e55d47d4796  vmovaps [rsp+0xC0], xmm13
00007e55d47d479f  vmovaps [rsp+0xD0], xmm14
00007e55d47d47a8  vmovaps [rsp+0xE0], xmm15
00007e55d47d47b1  sub rsp, 0x30
00007e55d47d47b5  movaps [rsp], xmm10
00007e55d47d47ba  movaps [rsp+0x10], xmm7
00007e55d47d47bf  movaps [rsp+0x20], xmm13
00007e55d47d47c5  lea rdi, [rsp]
00007e55d47d47c9  mov esi, 0x00
00007e55d47d47ce  mov rax, 0x55D0734A4530
00007e55d47d47d8  call rax
00007e55d47d47da  movaps xmm10, [rsp]
00007e55d47d47df  add rsp, 0x30
00007e55d47d47e3  vmovaps xmm0, [rsp]
00007e55d47d47e8  vmovaps xmm1, [rsp+0x10]
00007e55d47d47ee  vmovaps xmm2, [rsp+0x20]
00007e55d47d47f4  vmovaps xmm3, [rsp+0x30]
00007e55d47d47fa  vmovaps xmm4, [rsp+0x40]
00007e55d47d4800  vmovaps xmm5, [rsp+0x50]
00007e55d47d4806  vmovaps xmm6, [rsp+0x60]
00007e55d47d480c  vmovaps xmm7, [rsp+0x70]
00007e55d47d4812  vmovaps xmm8, [rsp+0x80]
00007e55d47d481b  vmovaps xmm9, [rsp+0x90]
00007e55d47d4824  vmovaps xmm11, [rsp+0xA0]
00007e55d47d482d  vmovaps xmm12, [rsp+0xB0]
00007e55d47d4836  vmovaps xmm13, [rsp+0xC0]
00007e55d47d483f  vmovaps xmm14, [rsp+0xD0]
00007e55d47d4848  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4851  add rsp, 0xF0
00007e55d47d4858  pop r11
00007e55d47d485a  pop r10
00007e55d47d485c  pop r9
00007e55d47d485e  pop r8
00007e55d47d4860  pop rsi
00007e55d47d4861  pop rdi
00007e55d47d4862  pop rdx
00007e55d47d4863  pop rcx
00007e55d47d4864  pop rax
00007e55d47d4865  add rsp, 0x08
00007e55d47d4869  jmp 0x00007E55D47D0169
00007e55d47d486e  sub rsp, 0x08
00007e55d47d4872  push rax
00007e55d47d4873  push rcx
00007e55d47d4874  push rdx
00007e55d47d4875  push rdi
00007e55d47d4876  push rsi
00007e55d47d4877  push r8
00007e55d47d4879  push r9
00007e55d47d487b  push r10
00007e55d47d487d  push r11
00007e55d47d487f  sub rsp, 0xF0
00007e55d47d4886  vmovaps [rsp], xmm0
00007e55d47d488b  vmovaps [rsp+0x10], xmm1
00007e55d47d4891  vmovaps [rsp+0x20], xmm2
00007e55d47d4897  vmovaps [rsp+0x30], xmm3
00007e55d47d489d  vmovaps [rsp+0x40], xmm4
00007e55d47d48a3  vmovaps [rsp+0x50], xmm5
00007e55d47d48a9  vmovaps [rsp+0x60], xmm6
00007e55d47d48af  vmovaps [rsp+0x70], xmm7
00007e55d47d48b5  vmovaps [rsp+0x80], xmm8
00007e55d47d48be  vmovaps [rsp+0x90], xmm9
00007e55d47d48c7  vmovaps [rsp+0xA0], xmm10
00007e55d47d48d0  vmovaps [rsp+0xB0], xmm11
00007e55d47d48d9  vmovaps [rsp+0xC0], xmm12
00007e55d47d48e2  vmovaps [rsp+0xD0], xmm14
00007e55d47d48eb  vmovaps [rsp+0xE0], xmm15
00007e55d47d48f4  sub rsp, 0x30
00007e55d47d48f8  movaps [rsp], xmm13
00007e55d47d48fd  movaps [rsp+0x10], xmm1
00007e55d47d4902  movaps [rsp+0x20], xmm8
00007e55d47d4908  lea rdi, [rsp]
00007e55d47d490c  mov esi, 0x00
00007e55d47d4911  mov rax, 0x55D0734A4530
00007e55d47d491b  call rax
00007e55d47d491d  movaps xmm13, [rsp]
00007e55d47d4922  add rsp, 0x30
00007e55d47d4926  vmovaps xmm0, [rsp]
00007e55d47d492b  vmovaps xmm1, [rsp+0x10]
00007e55d47d4931  vmovaps xmm2, [rsp+0x20]
00007e55d47d4937  vmovaps xmm3, [rsp+0x30]
00007e55d47d493d  vmovaps xmm4, [rsp+0x40]
00007e55d47d4943  vmovaps xmm5, [rsp+0x50]
00007e55d47d4949  vmovaps xmm6, [rsp+0x60]
00007e55d47d494f  vmovaps xmm7, [rsp+0x70]
00007e55d47d4955  vmovaps xmm8, [rsp+0x80]
00007e55d47d495e  vmovaps xmm9, [rsp+0x90]
00007e55d47d4967  vmovaps xmm10, [rsp+0xA0]
00007e55d47d4970  vmovaps xmm11, [rsp+0xB0]
00007e55d47d4979  vmovaps xmm12, [rsp+0xC0]
00007e55d47d4982  vmovaps xmm14, [rsp+0xD0]
00007e55d47d498b  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4994  add rsp, 0xF0
00007e55d47d499b  pop r11
00007e55d47d499d  pop r10
00007e55d47d499f  pop r9
00007e55d47d49a1  pop r8
00007e55d47d49a3  pop rsi
00007e55d47d49a4  pop rdi
00007e55d47d49a5  pop rdx
00007e55d47d49a6  pop rcx
00007e55d47d49a7  pop rax
00007e55d47d49a8  add rsp, 0x08
00007e55d47d49ac  jmp 0x00007E55D47D0183
00007e55d47d49b1  call 0x00007E55D45FF430
00007e55d47d49b6  jmp 0x00007E55D47D018D
00007e55d47d49bb  sub rsp, 0x08
00007e55d47d49bf  push rax
00007e55d47d49c0  push rcx
00007e55d47d49c1  push rdx
00007e55d47d49c2  push rdi
00007e55d47d49c3  push rsi
00007e55d47d49c4  push r8
00007e55d47d49c6  push r9
00007e55d47d49c8  push r10
00007e55d47d49ca  push r11
00007e55d47d49cc  sub rsp, 0xF0
00007e55d47d49d3  vmovaps [rsp], xmm0
00007e55d47d49d8  vmovaps [rsp+0x10], xmm1
00007e55d47d49de  vmovaps [rsp+0x20], xmm2
00007e55d47d49e4  vmovaps [rsp+0x30], xmm3
00007e55d47d49ea  vmovaps [rsp+0x40], xmm4
00007e55d47d49f0  vmovaps [rsp+0x50], xmm5
00007e55d47d49f6  vmovaps [rsp+0x60], xmm6
00007e55d47d49fc  vmovaps [rsp+0x70], xmm7
00007e55d47d4a02  vmovaps [rsp+0x80], xmm9
00007e55d47d4a0b  vmovaps [rsp+0x90], xmm10
00007e55d47d4a14  vmovaps [rsp+0xA0], xmm11
00007e55d47d4a1d  vmovaps [rsp+0xB0], xmm12
00007e55d47d4a26  vmovaps [rsp+0xC0], xmm13
00007e55d47d4a2f  vmovaps [rsp+0xD0], xmm14
00007e55d47d4a38  vmovaps [rsp+0xE0], xmm15
00007e55d47d4a41  sub rsp, 0x30
00007e55d47d4a45  movaps [rsp], xmm8
00007e55d47d4a4a  movaps [rsp+0x10], xmm14
00007e55d47d4a50  movaps [rsp+0x20], xmm9
00007e55d47d4a56  lea rdi, [rsp]
00007e55d47d4a5a  mov esi, 0x00
00007e55d47d4a5f  mov rax, 0x55D0734A4530
00007e55d47d4a69  call rax
00007e55d47d4a6b  movaps xmm8, [rsp]
00007e55d47d4a70  add rsp, 0x30
00007e55d47d4a74  vmovaps xmm0, [rsp]
00007e55d47d4a79  vmovaps xmm1, [rsp+0x10]
00007e55d47d4a7f  vmovaps xmm2, [rsp+0x20]
00007e55d47d4a85  vmovaps xmm3, [rsp+0x30]
00007e55d47d4a8b  vmovaps xmm4, [rsp+0x40]
00007e55d47d4a91  vmovaps xmm5, [rsp+0x50]
00007e55d47d4a97  vmovaps xmm6, [rsp+0x60]
00007e55d47d4a9d  vmovaps xmm7, [rsp+0x70]
00007e55d47d4aa3  vmovaps xmm9, [rsp+0x80]
00007e55d47d4aac  vmovaps xmm10, [rsp+0x90]
00007e55d47d4ab5  vmovaps xmm11, [rsp+0xA0]
00007e55d47d4abe  vmovaps xmm12, [rsp+0xB0]
00007e55d47d4ac7  vmovaps xmm13, [rsp+0xC0]
00007e55d47d4ad0  vmovaps xmm14, [rsp+0xD0]
00007e55d47d4ad9  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4ae2  add rsp, 0xF0
00007e55d47d4ae9  pop r11
00007e55d47d4aeb  pop r10
00007e55d47d4aed  pop r9
00007e55d47d4aef  pop r8
00007e55d47d4af1  pop rsi
00007e55d47d4af2  pop rdi
00007e55d47d4af3  pop rdx
00007e55d47d4af4  pop rcx
00007e55d47d4af5  pop rax
00007e55d47d4af6  add rsp, 0x08
00007e55d47d4afa  jmp 0x00007E55D47D01AF
00007e55d47d4aff  sub rsp, 0x08
00007e55d47d4b03  push rax
00007e55d47d4b04  push rcx
00007e55d47d4b05  push rdx
00007e55d47d4b06  push rdi
00007e55d47d4b07  push rsi
00007e55d47d4b08  push r8
00007e55d47d4b0a  push r9
00007e55d47d4b0c  push r10
00007e55d47d4b0e  push r11
00007e55d47d4b10  sub rsp, 0xF0
00007e55d47d4b17  vmovaps [rsp], xmm0
00007e55d47d4b1c  vmovaps [rsp+0x10], xmm1
00007e55d47d4b22  vmovaps [rsp+0x20], xmm2
00007e55d47d4b28  vmovaps [rsp+0x30], xmm3
00007e55d47d4b2e  vmovaps [rsp+0x40], xmm4
00007e55d47d4b34  vmovaps [rsp+0x50], xmm5
00007e55d47d4b3a  vmovaps [rsp+0x60], xmm6
00007e55d47d4b40  vmovaps [rsp+0x70], xmm7
00007e55d47d4b46  vmovaps [rsp+0x80], xmm8
00007e55d47d4b4f  vmovaps [rsp+0x90], xmm10
00007e55d47d4b58  vmovaps [rsp+0xA0], xmm11
00007e55d47d4b61  vmovaps [rsp+0xB0], xmm12
00007e55d47d4b6a  vmovaps [rsp+0xC0], xmm13
00007e55d47d4b73  vmovaps [rsp+0xD0], xmm14
00007e55d47d4b7c  vmovaps [rsp+0xE0], xmm15
00007e55d47d4b85  sub rsp, 0x30
00007e55d47d4b89  movaps [rsp], xmm9
00007e55d47d4b8e  movaps [rsp+0x10], xmm1
00007e55d47d4b93  movaps [rsp+0x20], xmm14
00007e55d47d4b99  lea rdi, [rsp]
00007e55d47d4b9d  mov esi, 0x00
00007e55d47d4ba2  mov rax, 0x55D0734A4530
00007e55d47d4bac  call rax
00007e55d47d4bae  movaps xmm9, [rsp]
00007e55d47d4bb3  add rsp, 0x30
00007e55d47d4bb7  vmovaps xmm0, [rsp]
00007e55d47d4bbc  vmovaps xmm1, [rsp+0x10]
00007e55d47d4bc2  vmovaps xmm2, [rsp+0x20]
00007e55d47d4bc8  vmovaps xmm3, [rsp+0x30]
00007e55d47d4bce  vmovaps xmm4, [rsp+0x40]
00007e55d47d4bd4  vmovaps xmm5, [rsp+0x50]
00007e55d47d4bda  vmovaps xmm6, [rsp+0x60]
00007e55d47d4be0  vmovaps xmm7, [rsp+0x70]
00007e55d47d4be6  vmovaps xmm8, [rsp+0x80]
00007e55d47d4bef  vmovaps xmm10, [rsp+0x90]
00007e55d47d4bf8  vmovaps xmm11, [rsp+0xA0]
00007e55d47d4c01  vmovaps xmm12, [rsp+0xB0]
00007e55d47d4c0a  vmovaps xmm13, [rsp+0xC0]
00007e55d47d4c13  vmovaps xmm14, [rsp+0xD0]
00007e55d47d4c1c  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4c25  add rsp, 0xF0
00007e55d47d4c2c  pop r11
00007e55d47d4c2e  pop r10
00007e55d47d4c30  pop r9
00007e55d47d4c32  pop r8
00007e55d47d4c34  pop rsi
00007e55d47d4c35  pop rdi
00007e55d47d4c36  pop rdx
00007e55d47d4c37  pop rcx
00007e55d47d4c38  pop rax
00007e55d47d4c39  add rsp, 0x08
00007e55d47d4c3d  jmp 0x00007E55D47D01DD
00007e55d47d4c42  sub rsp, 0x08
00007e55d47d4c46  push rax
00007e55d47d4c47  push rcx
00007e55d47d4c48  push rdx
00007e55d47d4c49  push rdi
00007e55d47d4c4a  push rsi
00007e55d47d4c4b  push r8
00007e55d47d4c4d  push r9
00007e55d47d4c4f  push r10
00007e55d47d4c51  push r11
00007e55d47d4c53  sub rsp, 0xF0
00007e55d47d4c5a  vmovaps [rsp], xmm0
00007e55d47d4c5f  vmovaps [rsp+0x10], xmm1
00007e55d47d4c65  vmovaps [rsp+0x20], xmm2
00007e55d47d4c6b  vmovaps [rsp+0x30], xmm3
00007e55d47d4c71  vmovaps [rsp+0x40], xmm4
00007e55d47d4c77  vmovaps [rsp+0x50], xmm5
00007e55d47d4c7d  vmovaps [rsp+0x60], xmm6
00007e55d47d4c83  vmovaps [rsp+0x70], xmm7
00007e55d47d4c89  vmovaps [rsp+0x80], xmm8
00007e55d47d4c92  vmovaps [rsp+0x90], xmm9
00007e55d47d4c9b  vmovaps [rsp+0xA0], xmm10
00007e55d47d4ca4  vmovaps [rsp+0xB0], xmm11
00007e55d47d4cad  vmovaps [rsp+0xC0], xmm12
00007e55d47d4cb6  vmovaps [rsp+0xD0], xmm13
00007e55d47d4cbf  vmovaps [rsp+0xE0], xmm15
00007e55d47d4cc8  sub rsp, 0x30
00007e55d47d4ccc  movaps [rsp], xmm14
00007e55d47d4cd1  movaps [rsp+0x10], xmm4
00007e55d47d4cd6  movaps [rsp+0x20], xmm1
00007e55d47d4cdb  lea rdi, [rsp]
00007e55d47d4cdf  mov esi, 0x00
00007e55d47d4ce4  mov rax, 0x55D0734A4530
00007e55d47d4cee  call rax
00007e55d47d4cf0  movaps xmm14, [rsp]
00007e55d47d4cf5  add rsp, 0x30
00007e55d47d4cf9  vmovaps xmm0, [rsp]
00007e55d47d4cfe  vmovaps xmm1, [rsp+0x10]
00007e55d47d4d04  vmovaps xmm2, [rsp+0x20]
00007e55d47d4d0a  vmovaps xmm3, [rsp+0x30]
00007e55d47d4d10  vmovaps xmm4, [rsp+0x40]
00007e55d47d4d16  vmovaps xmm5, [rsp+0x50]
00007e55d47d4d1c  vmovaps xmm6, [rsp+0x60]
00007e55d47d4d22  vmovaps xmm7, [rsp+0x70]
00007e55d47d4d28  vmovaps xmm8, [rsp+0x80]
00007e55d47d4d31  vmovaps xmm9, [rsp+0x90]
00007e55d47d4d3a  vmovaps xmm10, [rsp+0xA0]
00007e55d47d4d43  vmovaps xmm11, [rsp+0xB0]
00007e55d47d4d4c  vmovaps xmm12, [rsp+0xC0]
00007e55d47d4d55  vmovaps xmm13, [rsp+0xD0]
00007e55d47d4d5e  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4d67  add rsp, 0xF0
00007e55d47d4d6e  pop r11
00007e55d47d4d70  pop r10
00007e55d47d4d72  pop r9
00007e55d47d4d74  pop r8
00007e55d47d4d76  pop rsi
00007e55d47d4d77  pop rdi
00007e55d47d4d78  pop rdx
00007e55d47d4d79  pop rcx
00007e55d47d4d7a  pop rax
00007e55d47d4d7b  add rsp, 0x08
00007e55d47d4d7f  jmp 0x00007E55D47D0203
00007e55d47d4d84  sub rsp, 0x08
00007e55d47d4d88  push rax
00007e55d47d4d89  push rcx
00007e55d47d4d8a  push rdx
00007e55d47d4d8b  push rdi
00007e55d47d4d8c  push rsi
00007e55d47d4d8d  push r8
00007e55d47d4d8f  push r9
00007e55d47d4d91  push r10
00007e55d47d4d93  push r11
00007e55d47d4d95  sub rsp, 0xF0
00007e55d47d4d9c  vmovaps [rsp], xmm0
00007e55d47d4da1  vmovaps [rsp+0x10], xmm2
00007e55d47d4da7  vmovaps [rsp+0x20], xmm3
00007e55d47d4dad  vmovaps [rsp+0x30], xmm4
00007e55d47d4db3  vmovaps [rsp+0x40], xmm5
00007e55d47d4db9  vmovaps [rsp+0x50], xmm6
00007e55d47d4dbf  vmovaps [rsp+0x60], xmm7
00007e55d47d4dc5  vmovaps [rsp+0x70], xmm8
00007e55d47d4dcb  vmovaps [rsp+0x80], xmm9
00007e55d47d4dd4  vmovaps [rsp+0x90], xmm10
00007e55d47d4ddd  vmovaps [rsp+0xA0], xmm11
00007e55d47d4de6  vmovaps [rsp+0xB0], xmm12
00007e55d47d4def  vmovaps [rsp+0xC0], xmm13
00007e55d47d4df8  vmovaps [rsp+0xD0], xmm14
00007e55d47d4e01  vmovaps [rsp+0xE0], xmm15
00007e55d47d4e0a  sub rsp, 0x30
00007e55d47d4e0e  movaps [rsp], xmm1
00007e55d47d4e12  movaps [rsp+0x10], xmm12
00007e55d47d4e18  movaps [rsp+0x20], xmm11
00007e55d47d4e1e  lea rdi, [rsp]
00007e55d47d4e22  mov esi, 0x00
00007e55d47d4e27  mov rax, 0x55D0734A4530
00007e55d47d4e31  call rax
00007e55d47d4e33  movaps xmm1, [rsp]
00007e55d47d4e37  add rsp, 0x30
00007e55d47d4e3b  vmovaps xmm0, [rsp]
00007e55d47d4e40  vmovaps xmm2, [rsp+0x10]
00007e55d47d4e46  vmovaps xmm3, [rsp+0x20]
00007e55d47d4e4c  vmovaps xmm4, [rsp+0x30]
00007e55d47d4e52  vmovaps xmm5, [rsp+0x40]
00007e55d47d4e58  vmovaps xmm6, [rsp+0x50]
00007e55d47d4e5e  vmovaps xmm7, [rsp+0x60]
00007e55d47d4e64  vmovaps xmm8, [rsp+0x70]
00007e55d47d4e6a  vmovaps xmm9, [rsp+0x80]
00007e55d47d4e73  vmovaps xmm10, [rsp+0x90]
00007e55d47d4e7c  vmovaps xmm11, [rsp+0xA0]
00007e55d47d4e85  vmovaps xmm12, [rsp+0xB0]
00007e55d47d4e8e  vmovaps xmm13, [rsp+0xC0]
00007e55d47d4e97  vmovaps xmm14, [rsp+0xD0]
00007e55d47d4ea0  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4ea9  add rsp, 0xF0
00007e55d47d4eb0  pop r11
00007e55d47d4eb2  pop r10
00007e55d47d4eb4  pop r9
00007e55d47d4eb6  pop r8
00007e55d47d4eb8  pop rsi
00007e55d47d4eb9  pop rdi
00007e55d47d4eba  pop rdx
00007e55d47d4ebb  pop rcx
00007e55d47d4ebc  pop rax
00007e55d47d4ebd  add rsp, 0x08
00007e55d47d4ec1  jmp 0x00007E55D47D0224
00007e55d47d4ec6  call 0x00007E55D46E20A0
00007e55d47d4ecb  jmp 0x00007E55D47D0232
00007e55d47d4ed0  call 0x00007E55D4609D70
00007e55d47d4ed5  jmp 0x00007E55D47D023C
00007e55d47d4eda  sub rsp, 0x08
00007e55d47d4ede  push rax
00007e55d47d4edf  push rcx
00007e55d47d4ee0  push rdx
00007e55d47d4ee1  push rdi
00007e55d47d4ee2  push rsi
00007e55d47d4ee3  push r8
00007e55d47d4ee5  push r9
00007e55d47d4ee7  push r10
00007e55d47d4ee9  push r11
00007e55d47d4eeb  sub rsp, 0xF0
00007e55d47d4ef2  vmovaps [rsp], xmm0
00007e55d47d4ef7  vmovaps [rsp+0x10], xmm1
00007e55d47d4efd  vmovaps [rsp+0x20], xmm2
00007e55d47d4f03  vmovaps [rsp+0x30], xmm3
00007e55d47d4f09  vmovaps [rsp+0x40], xmm4
00007e55d47d4f0f  vmovaps [rsp+0x50], xmm5
00007e55d47d4f15  vmovaps [rsp+0x60], xmm6
00007e55d47d4f1b  vmovaps [rsp+0x70], xmm8
00007e55d47d4f21  vmovaps [rsp+0x80], xmm9
00007e55d47d4f2a  vmovaps [rsp+0x90], xmm10
00007e55d47d4f33  vmovaps [rsp+0xA0], xmm11
00007e55d47d4f3c  vmovaps [rsp+0xB0], xmm12
00007e55d47d4f45  vmovaps [rsp+0xC0], xmm13
00007e55d47d4f4e  vmovaps [rsp+0xD0], xmm14
00007e55d47d4f57  vmovaps [rsp+0xE0], xmm15
00007e55d47d4f60  sub rsp, 0x30
00007e55d47d4f64  movaps [rsp], xmm7
00007e55d47d4f68  movaps [rsp+0x10], xmm15
00007e55d47d4f6e  movaps [rsp+0x20], xmm10
00007e55d47d4f74  lea rdi, [rsp]
00007e55d47d4f78  mov esi, 0x00
00007e55d47d4f7d  mov rax, 0x55D0734A4530
00007e55d47d4f87  call rax
00007e55d47d4f89  movaps xmm7, [rsp]
00007e55d47d4f8d  add rsp, 0x30
00007e55d47d4f91  vmovaps xmm0, [rsp]
00007e55d47d4f96  vmovaps xmm1, [rsp+0x10]
00007e55d47d4f9c  vmovaps xmm2, [rsp+0x20]
00007e55d47d4fa2  vmovaps xmm3, [rsp+0x30]
00007e55d47d4fa8  vmovaps xmm4, [rsp+0x40]
00007e55d47d4fae  vmovaps xmm5, [rsp+0x50]
00007e55d47d4fb4  vmovaps xmm6, [rsp+0x60]
00007e55d47d4fba  vmovaps xmm8, [rsp+0x70]
00007e55d47d4fc0  vmovaps xmm9, [rsp+0x80]
00007e55d47d4fc9  vmovaps xmm10, [rsp+0x90]
00007e55d47d4fd2  vmovaps xmm11, [rsp+0xA0]
00007e55d47d4fdb  vmovaps xmm12, [rsp+0xB0]
00007e55d47d4fe4  vmovaps xmm13, [rsp+0xC0]
00007e55d47d4fed  vmovaps xmm14, [rsp+0xD0]
00007e55d47d4ff6  vmovaps xmm15, [rsp+0xE0]
00007e55d47d4fff  add rsp, 0xF0
00007e55d47d5006  pop r11
00007e55d47d5008  pop r10
00007e55d47d500a  pop r9
00007e55d47d500c  pop r8
00007e55d47d500e  pop rsi
00007e55d47d500f  pop rdi
00007e55d47d5010  pop rdx
00007e55d47d5011  pop rcx
00007e55d47d5012  pop rax
00007e55d47d5013  add rsp, 0x08
00007e55d47d5017  jmp 0x00007E55D47D025D
00007e55d47d501c  sub rsp, 0x08
00007e55d47d5020  push rax
00007e55d47d5021  push rcx
00007e55d47d5022  push rdx
00007e55d47d5023  push rdi
00007e55d47d5024  push rsi
00007e55d47d5025  push r8
00007e55d47d5027  push r9
00007e55d47d5029  push r10
00007e55d47d502b  push r11
00007e55d47d502d  sub rsp, 0xF0
00007e55d47d5034  vmovaps [rsp], xmm0
00007e55d47d5039  vmovaps [rsp+0x10], xmm1
00007e55d47d503f  vmovaps [rsp+0x20], xmm2
00007e55d47d5045  vmovaps [rsp+0x30], xmm3
00007e55d47d504b  vmovaps [rsp+0x40], xmm4
00007e55d47d5051  vmovaps [rsp+0x50], xmm5
00007e55d47d5057  vmovaps [rsp+0x60], xmm6
00007e55d47d505d  vmovaps [rsp+0x70], xmm7
00007e55d47d5063  vmovaps [rsp+0x80], xmm8
00007e55d47d506c  vmovaps [rsp+0x90], xmm9
00007e55d47d5075  vmovaps [rsp+0xA0], xmm11
00007e55d47d507e  vmovaps [rsp+0xB0], xmm12
00007e55d47d5087  vmovaps [rsp+0xC0], xmm13
00007e55d47d5090  vmovaps [rsp+0xD0], xmm14
00007e55d47d5099  vmovaps [rsp+0xE0], xmm15
00007e55d47d50a2  sub rsp, 0x30
00007e55d47d50a6  movaps [rsp], xmm10
00007e55d47d50ab  movaps [rsp+0x10], xmm11
00007e55d47d50b1  movaps [rsp+0x20], xmm15
00007e55d47d50b7  lea rdi, [rsp]
00007e55d47d50bb  mov esi, 0x00
00007e55d47d50c0  mov rax, 0x55D0734A4530
00007e55d47d50ca  call rax
00007e55d47d50cc  movaps xmm10, [rsp]
00007e55d47d50d1  add rsp, 0x30
00007e55d47d50d5  vmovaps xmm0, [rsp]
00007e55d47d50da  vmovaps xmm1, [rsp+0x10]
00007e55d47d50e0  vmovaps xmm2, [rsp+0x20]
00007e55d47d50e6  vmovaps xmm3, [rsp+0x30]
00007e55d47d50ec  vmovaps xmm4, [rsp+0x40]
00007e55d47d50f2  vmovaps xmm5, [rsp+0x50]
00007e55d47d50f8  vmovaps xmm6, [rsp+0x60]
00007e55d47d50fe  vmovaps xmm7, [rsp+0x70]
00007e55d47d5104  vmovaps xmm8, [rsp+0x80]
00007e55d47d510d  vmovaps xmm9, [rsp+0x90]
00007e55d47d5116  vmovaps xmm11, [rsp+0xA0]
00007e55d47d511f  vmovaps xmm12, [rsp+0xB0]
00007e55d47d5128  vmovaps xmm13, [rsp+0xC0]
00007e55d47d5131  vmovaps xmm14, [rsp+0xD0]
00007e55d47d513a  vmovaps xmm15, [rsp+0xE0]
00007e55d47d5143  add rsp, 0xF0
00007e55d47d514a  pop r11
00007e55d47d514c  pop r10
00007e55d47d514e  pop r9
00007e55d47d5150  pop r8
00007e55d47d5152  pop rsi
00007e55d47d5153  pop rdi
00007e55d47d5154  pop rdx
00007e55d47d5155  pop rcx
00007e55d47d5156  pop rax
00007e55d47d5157  add rsp, 0x08
00007e55d47d515b  jmp 0x00007E55D47D028B
00007e55d47d5160  sub rsp, 0x08
00007e55d47d5164  push rax
00007e55d47d5165  push rcx
00007e55d47d5166  push rdx
00007e55d47d5167  push rdi
00007e55d47d5168  push rsi
00007e55d47d5169  push r8
00007e55d47d516b  push r9
00007e55d47d516d  push r10
00007e55d47d516f  push r11
00007e55d47d5171  sub rsp, 0xF0
00007e55d47d5178  vmovaps [rsp], xmm0
00007e55d47d517d  vmovaps [rsp+0x10], xmm1
00007e55d47d5183  vmovaps [rsp+0x20], xmm2
00007e55d47d5189  vmovaps [rsp+0x30], xmm3
00007e55d47d518f  vmovaps [rsp+0x40], xmm4
00007e55d47d5195  vmovaps [rsp+0x50], xmm5
00007e55d47d519b  vmovaps [rsp+0x60], xmm6
00007e55d47d51a1  vmovaps [rsp+0x70], xmm7
00007e55d47d51a7  vmovaps [rsp+0x80], xmm8
00007e55d47d51b0  vmovaps [rsp+0x90], xmm9
00007e55d47d51b9  vmovaps [rsp+0xA0], xmm10
00007e55d47d51c2  vmovaps [rsp+0xB0], xmm12
00007e55d47d51cb  vmovaps [rsp+0xC0], xmm13
00007e55d47d51d4  vmovaps [rsp+0xD0], xmm14
00007e55d47d51dd  vmovaps [rsp+0xE0], xmm15
00007e55d47d51e6  sub rsp, 0x30
00007e55d47d51ea  movaps [rsp], xmm11
00007e55d47d51ef  movaps [rsp+0x10], xmm12
00007e55d47d51f5  movaps [rsp+0x20], xmm15
00007e55d47d51fb  lea rdi, [rsp]
00007e55d47d51ff  mov esi, 0x00
00007e55d47d5204  mov rax, 0x55D0734A4530
00007e55d47d520e  call rax
00007e55d47d5210  movaps xmm11, [rsp]
00007e55d47d5215  add rsp, 0x30
00007e55d47d5219  vmovaps xmm0, [rsp]
00007e55d47d521e  vmovaps xmm1, [rsp+0x10]
00007e55d47d5224  vmovaps xmm2, [rsp+0x20]
00007e55d47d522a  vmovaps xmm3, [rsp+0x30]
00007e55d47d5230  vmovaps xmm4, [rsp+0x40]
00007e55d47d5236  vmovaps xmm5, [rsp+0x50]
00007e55d47d523c  vmovaps xmm6, [rsp+0x60]
00007e55d47d5242  vmovaps xmm7, [rsp+0x70]
00007e55d47d5248  vmovaps xmm8, [rsp+0x80]
00007e55d47d5251  vmovaps xmm9, [rsp+0x90]
00007e55d47d525a  vmovaps xmm10, [rsp+0xA0]
00007e55d47d5263  vmovaps xmm12, [rsp+0xB0]
00007e55d47d526c  vmovaps xmm13, [rsp+0xC0]
00007e55d47d5275  vmovaps xmm14, [rsp+0xD0]
00007e55d47d527e  vmovaps xmm15, [rsp+0xE0]
00007e55d47d5287  add rsp, 0xF0
00007e55d47d528e  pop r11
00007e55d47d5290  pop r10
00007e55d47d5292  pop r9
00007e55d47d5294  pop r8
00007e55d47d5296  pop rsi
00007e55d47d5297  pop rdi
00007e55d47d5298  pop rdx
00007e55d47d5299  pop rcx
00007e55d47d529a  pop rax
00007e55d47d529b  add rsp, 0x08
00007e55d47d529f  jmp 0x00007E55D47D02B9
00007e55d47d52a4  sub rsp, 0x08
00007e55d47d52a8  push rax
00007e55d47d52a9  push rcx
00007e55d47d52aa  push rdx
00007e55d47d52ab  push rdi
00007e55d47d52ac  push rsi
00007e55d47d52ad  push r8
00007e55d47d52af  push r9
00007e55d47d52b1  push r10
00007e55d47d52b3  push r11
00007e55d47d52b5  sub rsp, 0xF0
00007e55d47d52bc  vmovaps [rsp], xmm0
00007e55d47d52c1  vmovaps [rsp+0x10], xmm1
00007e55d47d52c7  vmovaps [rsp+0x20], xmm2
00007e55d47d52cd  vmovaps [rsp+0x30], xmm3
00007e55d47d52d3  vmovaps [rsp+0x40], xmm4
00007e55d47d52d9  vmovaps [rsp+0x50], xmm5
00007e55d47d52df  vmovaps [rsp+0x60], xmm6
00007e55d47d52e5  vmovaps [rsp+0x70], xmm7
00007e55d47d52eb  vmovaps [rsp+0x80], xmm8
00007e55d47d52f4  vmovaps [rsp+0x90], xmm9
00007e55d47d52fd  vmovaps [rsp+0xA0], xmm10
00007e55d47d5306  vmovaps [rsp+0xB0], xmm11
00007e55d47d530f  vmovaps [rsp+0xC0], xmm12
00007e55d47d5318  vmovaps [rsp+0xD0], xmm13
00007e55d47d5321  vmovaps [rsp+0xE0], xmm14
00007e55d47d532a  sub rsp, 0x30
00007e55d47d532e  movaps [rsp], xmm15
00007e55d47d5333  movaps [rsp+0x10], xmm13
00007e55d47d5339  movaps [rsp+0x20], xmm9
00007e55d47d533f  lea rdi, [rsp]
00007e55d47d5343  mov esi, 0x00
00007e55d47d5348  mov rax, 0x55D0734A4530
00007e55d47d5352  call rax
00007e55d47d5354  movaps xmm15, [rsp]
00007e55d47d5359  add rsp, 0x30
00007e55d47d535d  vmovaps xmm0, [rsp]
00007e55d47d5362  vmovaps xmm1, [rsp+0x10]
00007e55d47d5368  vmovaps xmm2, [rsp+0x20]
00007e55d47d536e  vmovaps xmm3, [rsp+0x30]
00007e55d47d5374  vmovaps xmm4, [rsp+0x40]
00007e55d47d537a  vmovaps xmm5, [rsp+0x50]
00007e55d47d5380  vmovaps xmm6, [rsp+0x60]
00007e55d47d5386  vmovaps xmm7, [rsp+0x70]
00007e55d47d538c  vmovaps xmm8, [rsp+0x80]
00007e55d47d5395  vmovaps xmm9, [rsp+0x90]
00007e55d47d539e  vmovaps xmm10, [rsp+0xA0]
00007e55d47d53a7  vmovaps xmm11, [rsp+0xB0]
00007e55d47d53b0  vmovaps xmm12, [rsp+0xC0]
00007e55d47d53b9  vmovaps xmm13, [rsp+0xD0]
00007e55d47d53c2  vmovaps xmm14, [rsp+0xE0]
00007e55d47d53cb  add rsp, 0xF0
00007e55d47d53d2  pop r11
00007e55d47d53d4  pop r10
00007e55d47d53d6  pop r9
00007e55d47d53d8  pop r8
00007e55d47d53da  pop rsi
00007e55d47d53db  pop rdi
00007e55d47d53dc  pop rdx
00007e55d47d53dd  pop rcx
00007e55d47d53de  pop rax
00007e55d47d53df  add rsp, 0x08
00007e55d47d53e3  jmp 0x00007E55D47D02D4
00007e55d47d53e8  sub rsp, 0x08
00007e55d47d53ec  push rax
00007e55d47d53ed  push rcx
00007e55d47d53ee  push rdx
00007e55d47d53ef  push rdi
00007e55d47d53f0  push rsi
00007e55d47d53f1  push r8
00007e55d47d53f3  push r9
00007e55d47d53f5  push r10
00007e55d47d53f7  push r11
00007e55d47d53f9  sub rsp, 0xF0
00007e55d47d5400  vmovaps [rsp], xmm0
00007e55d47d5405  vmovaps [rsp+0x10], xmm1
00007e55d47d540b  vmovaps [rsp+0x20], xmm2
00007e55d47d5411  vmovaps [rsp+0x30], xmm3
00007e55d47d5417  vmovaps [rsp+0x40], xmm4
00007e55d47d541d  vmovaps [rsp+0x50], xmm5
00007e55d47d5423  vmovaps [rsp+0x60], xmm6
00007e55d47d5429  vmovaps [rsp+0x70], xmm7
00007e55d47d542f  vmovaps [rsp+0x80], xmm8
00007e55d47d5438  vmovaps [rsp+0x90], xmm9
00007e55d47d5441  vmovaps [rsp+0xA0], xmm10
00007e55d47d544a  vmovaps [rsp+0xB0], xmm11
00007e55d47d5453  vmovaps [rsp+0xC0], xmm12
00007e55d47d545c  vmovaps [rsp+0xD0], xmm14
00007e55d47d5465  vmovaps [rsp+0xE0], xmm15
00007e55d47d546e  sub rsp, 0x30
00007e55d47d5472  movaps [rsp], xmm13
00007e55d47d5477  movaps [rsp+0x10], xmm8
00007e55d47d547d  movaps [rsp+0x20], xmm14
00007e55d47d5483  lea rdi, [rsp]
00007e55d47d5487  mov esi, 0x00
00007e55d47d548c  mov rax, 0x55D0734A4530
00007e55d47d5496  call rax
00007e55d47d5498  movaps xmm13, [rsp]
00007e55d47d549d  add rsp, 0x30
00007e55d47d54a1  vmovaps xmm0, [rsp]
00007e55d47d54a6  vmovaps xmm1, [rsp+0x10]
00007e55d47d54ac  vmovaps xmm2, [rsp+0x20]
00007e55d47d54b2  vmovaps xmm3, [rsp+0x30]
00007e55d47d54b8  vmovaps xmm4, [rsp+0x40]
00007e55d47d54be  vmovaps xmm5, [rsp+0x50]
00007e55d47d54c4  vmovaps xmm6, [rsp+0x60]
00007e55d47d54ca  vmovaps xmm7, [rsp+0x70]
00007e55d47d54d0  vmovaps xmm8, [rsp+0x80]
00007e55d47d54d9  vmovaps xmm9, [rsp+0x90]
00007e55d47d54e2  vmovaps xmm10, [rsp+0xA0]
00007e55d47d54eb  vmovaps xmm11, [rsp+0xB0]
00007e55d47d54f4  vmovaps xmm12, [rsp+0xC0]
00007e55d47d54fd  vmovaps xmm14, [rsp+0xD0]
00007e55d47d5506  vmovaps xmm15, [rsp+0xE0]
00007e55d47d550f  add rsp, 0xF0
00007e55d47d5516  pop r11
00007e55d47d5518  pop r10
00007e55d47d551a  pop r9
00007e55d47d551c  pop r8
00007e55d47d551e  pop rsi
00007e55d47d551f  pop rdi
00007e55d47d5520  pop rdx
00007e55d47d5521  pop rcx
00007e55d47d5522  pop rax
00007e55d47d5523  add rsp, 0x08
00007e55d47d5527  jmp 0x00007E55D47D02F7
00007e55d47d552c  sub rsp, 0x08
00007e55d47d5530  push rax
00007e55d47d5531  push rcx
00007e55d47d5532  push rdx
00007e55d47d5533  push rdi
00007e55d47d5534  push rsi
00007e55d47d5535  push r8
00007e55d47d5537  push r9
00007e55d47d5539  push r10
00007e55d47d553b  push r11
00007e55d47d553d  sub rsp, 0xF0
00007e55d47d5544  vmovaps [rsp], xmm0
00007e55d47d5549  vmovaps [rsp+0x10], xmm1
00007e55d47d554f  vmovaps [rsp+0x20], xmm2
00007e55d47d5555  vmovaps [rsp+0x30], xmm3
00007e55d47d555b  vmovaps [rsp+0x40], xmm4
00007e55d47d5561  vmovaps [rsp+0x50], xmm5
00007e55d47d5567  vmovaps [rsp+0x60], xmm6
00007e55d47d556d  vmovaps [rsp+0x70], xmm7
00007e55d47d5573  vmovaps [rsp+0x80], xmm8
00007e55d47d557c  vmovaps [rsp+0x90], xmm9
00007e55d47d5585  vmovaps [rsp+0xA0], xmm10
00007e55d47d558e  vmovaps [rsp+0xB0], xmm11
00007e55d47d5597  vmovaps [rsp+0xC0], xmm12
00007e55d47d55a0  vmovaps [rsp+0xD0], xmm13
00007e55d47d55a9  vmovaps [rsp+0xE0], xmm15
00007e55d47d55b2  sub rsp, 0x30
00007e55d47d55b6  movaps [rsp], xmm14
00007e55d47d55bb  movaps [rsp+0x10], xmm1
00007e55d47d55c0  movaps [rsp+0x20], xmm10
00007e55d47d55c6  lea rdi, [rsp]
00007e55d47d55ca  mov esi, 0x00
00007e55d47d55cf  mov rax, 0x55D0734A4530
00007e55d47d55d9  call rax
00007e55d47d55db  movaps xmm14, [rsp]
00007e55d47d55e0  add rsp, 0x30
00007e55d47d55e4  vmovaps xmm0, [rsp]
00007e55d47d55e9  vmovaps xmm1, [rsp+0x10]
00007e55d47d55ef  vmovaps xmm2, [rsp+0x20]
00007e55d47d55f5  vmovaps xmm3, [rsp+0x30]
00007e55d47d55fb  vmovaps xmm4, [rsp+0x40]
00007e55d47d5601  vmovaps xmm5, [rsp+0x50]
00007e55d47d5607  vmovaps xmm6, [rsp+0x60]
00007e55d47d560d  vmovaps xmm7, [rsp+0x70]
00007e55d47d5613  vmovaps xmm8, [rsp+0x80]
00007e55d47d561c  vmovaps xmm9, [rsp+0x90]
00007e55d47d5625  vmovaps xmm10, [rsp+0xA0]
00007e55d47d562e  vmovaps xmm11, [rsp+0xB0]
00007e55d47d5637  vmovaps xmm12, [rsp+0xC0]
00007e55d47d5640  vmovaps xmm13, [rsp+0xD0]
00007e55d47d5649  vmovaps xmm15, [rsp+0xE0]
00007e55d47d5652  add rsp, 0xF0
00007e55d47d5659  pop r11
00007e55d47d565b  pop r10
00007e55d47d565d  pop r9
00007e55d47d565f  pop r8
00007e55d47d5661  pop rsi
00007e55d47d5662  pop rdi
00007e55d47d5663  pop rdx
00007e55d47d5664  pop rcx
00007e55d47d5665  pop rax
00007e55d47d5666  add rsp, 0x08
00007e55d47d566a  jmp 0x00007E55D47D031A
00007e55d47d566f  sub rsp, 0x08
00007e55d47d5673  push rax
00007e55d47d5674  push rcx
00007e55d47d5675  push rdx
00007e55d47d5676  push rdi
00007e55d47d5677  push rsi
00007e55d47d5678  push r8
00007e55d47d567a  push r9
00007e55d47d567c  push r10
00007e55d47d567e  push r11
00007e55d47d5680  sub rsp, 0xF0
00007e55d47d5687  vmovaps [rsp], xmm0
00007e55d47d568c  vmovaps [rsp+0x10], xmm2
00007e55d47d5692  vmovaps [rsp+0x20], xmm3
00007e55d47d5698  vmovaps [rsp+0x30], xmm4
00007e55d47d569e  vmovaps [rsp+0x40], xmm5
00007e55d47d56a4  vmovaps [rsp+0x50], xmm6
00007e55d47d56aa  vmovaps [rsp+0x60], xmm7
00007e55d47d56b0  vmovaps [rsp+0x70], xmm8
00007e55d47d56b6  vmovaps [rsp+0x80], xmm9
00007e55d47d56bf  vmovaps [rsp+0x90], xmm10
00007e55d47d56c8  vmovaps [rsp+0xA0], xmm11
00007e55d47d56d1  vmovaps [rsp+0xB0], xmm12
00007e55d47d56da  vmovaps [rsp+0xC0], xmm13
00007e55d47d56e3  vmovaps [rsp+0xD0], xmm14
00007e55d47d56ec  vmovaps [rsp+0xE0], xmm15
00007e55d47d56f5  sub rsp, 0x30
00007e55d47d56f9  movaps [rsp], xmm1
00007e55d47d56fd  movaps [rsp+0x10], xmm7
00007e55d47d5702  movaps [rsp+0x20], xmm11
00007e55d47d5708  lea rdi, [rsp]
00007e55d47d570c  mov esi, 0x00
00007e55d47d5711  mov rax, 0x55D0734A4530
00007e55d47d571b  call rax
00007e55d47d571d  movaps xmm1, [rsp]
00007e55d47d5721  add rsp, 0x30
00007e55d47d5725  vmovaps xmm0, [rsp]
00007e55d47d572a  vmovaps xmm2, [rsp+0x10]
00007e55d47d5730  vmovaps xmm3, [rsp+0x20]
00007e55d47d5736  vmovaps xmm4, [rsp+0x30]
00007e55d47d573c  vmovaps xmm5, [rsp+0x40]
00007e55d47d5742  vmovaps xmm6, [rsp+0x50]
00007e55d47d5748  vmovaps xmm7, [rsp+0x60]
00007e55d47d574e  vmovaps xmm8, [rsp+0x70]
00007e55d47d5754  vmovaps xmm9, [rsp+0x80]
00007e55d47d575d  vmovaps xmm10, [rsp+0x90]
00007e55d47d5766  vmovaps xmm11, [rsp+0xA0]
00007e55d47d576f  vmovaps xmm12, [rsp+0xB0]
00007e55d47d5778  vmovaps xmm13, [rsp+0xC0]
00007e55d47d5781  vmovaps xmm14, [rsp+0xD0]
00007e55d47d578a  vmovaps xmm15, [rsp+0xE0]
00007e55d47d5793  add rsp, 0xF0
00007e55d47d579a  pop r11
00007e55d47d579c  pop r10
00007e55d47d579e  pop r9
00007e55d47d57a0  pop r8
00007e55d47d57a2  pop rsi
00007e55d47d57a3  pop rdi
00007e55d47d57a4  pop rdx
00007e55d47d57a5  pop rcx
00007e55d47d57a6  pop rax
00007e55d47d57a7  add rsp, 0x08
00007e55d47d57ab  jmp 0x00007E55D47D033B
00007e55d47d57b0  call 0x00007E55D460E880
00007e55d47d57b5  jmp 0x00007E55D47D034E
00007e55d47d57ba  call 0x00007E55D460C380
00007e55d47d57bf  jmp 0x00007E55D47D0359
00007e55d47d57c4  call 0x00007E55D460D600
00007e55d47d57c9  jmp 0x00007E55D47D0364
00007e55d47d57ce  call 0x00007E55D45FF540
00007e55d47d57d3  jmp 0x00007E55D47D036F
00007e55d47d57d8  int3
00007e55d47d57d9  nop [rax], eax
00007e55d47d57e0  mov rax, [r15+0x40]
00007e55d47d57e4  mov r14, [r15+0x58]
00007e55d47d57e8  lea r12, [rax+r14*1]
00007e55d47d57ec  movaps xmm1, [r15+0x1D0]
00007e55d47d57f4  vmovaps [rsp+0x10], xmm1
00007e55d47d57fa  vmovaps xmm15, [rsp+0x10]
00007e55d47d5800  por xmm1, xmm15
00007e55d47d5805  movaps xmm14, [r15+0x1A0]
00007e55d47d580d  vmovaps [rsp+0x10], xmm14
00007e55d47d5813  vmovaps xmm13, [rsp+0x10]
00007e55d47d5819  por xmm14, xmm13
00007e55d47d581e  lea rax, [r12+0x30]
00007e55d47d5823  mov r11, [r13+rax*1]
00007e55d47d5828  lea rax, [r12+0x38]
00007e55d47d582d  mov r10, [r13+rax*1]
00007e55d47d5832  movq xmm13, r11
00007e55d47d5837  movq xmm12, r10
00007e55d47d583c  movq xmm13, xmm13
00007e55d47d5841  vmovaps [rsp+0x10], xmm13
00007e55d47d5847  movq xmm13, xmm13
00007e55d47d584c  movaps [r15+0x130], xmm13
00007e55d47d5854  movq xmm12, xmm12
00007e55d47d5859  vmovaps [rsp+0x20], xmm12
00007e55d47d585f  movq xmm12, xmm12
00007e55d47d5864  movaps [r15+0x280], xmm12
00007e55d47d586c  movaps xmm13, [r15+0x270]
00007e55d47d5874  vmovaps [rsp+0x30], xmm13
00007e55d47d587a  vmovaps xmm12, [rsp+0x30]
00007e55d47d5880  por xmm13, xmm12
00007e55d47d5885  lea rax, [r12+0x20]
00007e55d47d588a  mov r11, [r13+rax*1]
00007e55d47d588f  lea rax, [r12+0x28]
00007e55d47d5894  mov r10, [r13+rax*1]
00007e55d47d5899  movq xmm12, r11
00007e55d47d589e  movq xmm11, r10
00007e55d47d58a3  movq xmm12, xmm12
00007e55d47d58a8  vmovaps [rsp+0x30], xmm12
00007e55d47d58ae  movq xmm12, xmm12
00007e55d47d58b3  movaps [r15+0x150], xmm12
00007e55d47d58bb  movq xmm11, xmm11
00007e55d47d58c0  vmovaps [rsp+0x40], xmm11
00007e55d47d58c6  movq xmm11, xmm11
00007e55d47d58cb  movaps [r15+0x140], xmm11
00007e55d47d58d3  lea rax, [r12+0x10]
00007e55d47d58d8  mov r11, [r13+rax*1]
00007e55d47d58dd  lea rax, [r12+0x18]
00007e55d47d58e2  mov r10, [r13+rax*1]
00007e55d47d58e7  movq xmm12, r11
00007e55d47d58ec  movq xmm11, r10
00007e55d47d58f1  movq xmm12, xmm12
00007e55d47d58f6  vmovaps [rsp+0x50], xmm12
00007e55d47d58fc  movq xmm12, xmm12
00007e55d47d5901  movaps [r15+0x170], xmm12
00007e55d47d5909  movq xmm11, xmm11
00007e55d47d590e  vmovaps [rsp+0x60], xmm11
00007e55d47d5914  movq xmm11, xmm11
00007e55d47d5919  movaps [r15+0x160], xmm11
00007e55d47d5921  mov rax, [r13+r12*1]
00007e55d47d5926  vmovq xmm12, rax
00007e55d47d592b  vpbroadcastq xmm12, xmm12
00007e55d47d5930  lea rax, [r12+0x08]
00007e55d47d5935  mov r12, [r13+rax*1]
00007e55d47d593a  movq xmm11, r12
00007e55d47d593f  movaps [r15+0x230], xmm11
00007e55d47d5947  mov rax, [r15+0xF8]
00007e55d47d594e  lea r12, [rax+0x50]
00007e55d47d5952  movups xmm11, [r13+r12*1]
00007e55d47d5958  lea r12, [rax+0x60]
00007e55d47d595c  movups xmm10, [r13+r12*1]
00007e55d47d5962  lea r12, [rax+0x30]
00007e55d47d5966  movups xmm9, [r13+r12*1]
00007e55d47d596c  mov r12, [r15+0x50]
00007e55d47d5970  lea r11, [r12+r14*1]
00007e55d47d5974  mov [r15+0x60], r11
00007e55d47d5978  lea r12, [r14+0x40]
00007e55d47d597c  mov [r15+0x58], r12
00007e55d47d5980  movaps xmm8, xmm12
00007e55d47d5984  mulpd xmm8, xmm15
00007e55d47d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007e55d47d598f  ptest xmm7, xmm7
00007e55d47d5994  jnz 0x00007E55D47D67B7
00007e55d47d599a  movq xmm15, qword ptr [r15+0x230]
00007e55d47d59a3  vmovaps [rsp+0x70], xmm15
00007e55d47d59a9  vpermilpd xmm15, xmm15, 0x00
00007e55d47d59af  movaps xmm7, xmm9
00007e55d47d59b3  mulpd xmm7, xmm15
00007e55d47d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007e55d47d59bd  ptest xmm6, xmm6
00007e55d47d59c2  jnz 0x00007E55D47D68FB
00007e55d47d59c8  vxorps xmm15, xmm15, xmm15
00007e55d47d59cd  vpbroadcastq xmm15, xmm15
00007e55d47d59d2  movaps xmm9, xmm12
00007e55d47d59d6  mulpd xmm9, xmm10
00007e55d47d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007e55d47d59e1  ptest xmm6, xmm6
00007e55d47d59e6  jnz 0x00007E55D47D6A3D
00007e55d47d59ec  movaps xmm10, xmm12
00007e55d47d59f0  mulpd xmm10, xmm11
00007e55d47d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007e55d47d59fb  ptest xmm6, xmm6
00007e55d47d5a00  jnz 0x00007E55D47D6B81
00007e55d47d5a06  movaps xmm11, [r15+0x1F0]
00007e55d47d5a0e  movaps xmm6, xmm12
00007e55d47d5a12  mulpd xmm6, xmm11
00007e55d47d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007e55d47d5a1c  ptest xmm5, xmm5
00007e55d47d5a21  jnz 0x00007E55D47D6CC5
00007e55d47d5a27  movaps xmm12, [r15+0x2A0]
00007e55d47d5a2f  vmovaps [rsp+0x80], xmm12
00007e55d47d5a38  vmovaps xmm11, [rsp+0x80]
00007e55d47d5a41  por xmm12, xmm11
00007e55d47d5a46  movaps xmm11, [r15+0x250]
00007e55d47d5a4e  vmovaps [rsp+0x80], xmm11
00007e55d47d5a57  vmovaps xmm5, [rsp+0x80]
00007e55d47d5a60  por xmm11, xmm5
00007e55d47d5a65  vmovaps xmm4, [rsp+0x70]
00007e55d47d5a6b  vpermilpd xmm4, xmm4, 0x00
00007e55d47d5a71  movaps xmm3, xmm5
00007e55d47d5a74  mulpd xmm3, xmm4
00007e55d47d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007e55d47d5a7d  ptest xmm2, xmm2
00007e55d47d5a82  jnz 0x00007E55D47D6E07
00007e55d47d5a88  mov [rsp+0x80], rax
00007e55d47d5a90  xor eax, eax
00007e55d47d5a92  mov r14d, 0x200
00007e55d47d5a98  cmp r12, r14
00007e55d47d5a9b  cmc
00007e55d47d5a9c  lahf
00007e55d47d5a9d  seto al
00007e55d47d5aa0  mov [r15+0x108], eax
00007e55d47d5aa7  movaps xmm5, xmm8
00007e55d47d5aab  addpd xmm5, xmm15
00007e55d47d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007e55d47d5ab5  ptest xmm4, xmm4
00007e55d47d5aba  jnz 0x00007E55D47D6F47
00007e55d47d5ac0  movaps xmm8, [r15+0x1B0]
00007e55d47d5ac8  movaps xmm4, xmm9
00007e55d47d5acc  addpd xmm4, xmm8
00007e55d47d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007e55d47d5ad6  ptest xmm2, xmm2
00007e55d47d5adb  jnz 0x00007E55D47D7089
00007e55d47d5ae1  movaps xmm9, xmm10
00007e55d47d5ae5  addpd xmm9, xmm8
00007e55d47d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007e55d47d5af0  ptest xmm2, xmm2
00007e55d47d5af5  jnz 0x00007E55D47D71CB
00007e55d47d5afb  movaps xmm10, [r15+0x2F0]
00007e55d47d5b03  vmovaps [rsp+0x90], xmm10
00007e55d47d5b0c  vmovaps xmm8, [rsp+0x90]
00007e55d47d5b15  por xmm10, xmm8
00007e55d47d5b1a  movaps xmm8, [r15+0x2E0]
00007e55d47d5b22  vmovaps [rsp+0x90], xmm8
00007e55d47d5b2b  vmovaps xmm2, [rsp+0x90]
00007e55d47d5b34  por xmm8, xmm2
00007e55d47d5b39  movaps xmm2, [r15+0x2D0]
00007e55d47d5b41  vmovaps [rsp+0x90], xmm2
00007e55d47d5b4a  vmovaps [rsp+0xA0], xmm1
00007e55d47d5b53  vmovaps xmm1, [rsp+0x90]
00007e55d47d5b5c  por xmm2, xmm1
00007e55d47d5b60  movaps xmm1, [r15+0x200]
00007e55d47d5b68  vmovaps [rsp+0x90], xmm1
00007e55d47d5b71  vmovaps [rsp+0xB0], xmm15
00007e55d47d5b7a  vmovaps xmm15, [rsp+0x90]
00007e55d47d5b83  por xmm1, xmm15
00007e55d47d5b88  movaps xmm15, [r15+0x1C0]
00007e55d47d5b90  vmovaps [rsp+0x90], xmm15
00007e55d47d5b99  vmovaps [rsp+0xC0], xmm1
00007e55d47d5ba2  vmovaps xmm1, [rsp+0x90]
00007e55d47d5bab  por xmm15, xmm1
00007e55d47d5bb0  movaps xmm1, [r15+0x190]
00007e55d47d5bb8  vmovaps [rsp+0x90], xmm1
00007e55d47d5bc1  vmovaps [rsp+0xD0], xmm15
00007e55d47d5bca  vmovaps xmm15, [rsp+0x90]
00007e55d47d5bd3  por xmm1, xmm15
00007e55d47d5bd8  movaps xmm15, [r15+0x300]
00007e55d47d5be0  vmovaps [rsp+0x90], xmm15
00007e55d47d5be9  vmovaps [rsp+0xE0], xmm1
00007e55d47d5bf2  vmovaps xmm1, [rsp+0x90]
00007e55d47d5bfb  por xmm15, xmm1
00007e55d47d5c00  mov rax, [rsp+0x80]
00007e55d47d5c08  lea r14, [rax+0xA0]
00007e55d47d5c0f  movups xmm1, [r13+r14*1]
00007e55d47d5c15  lea r14, [rax+0xB0]
00007e55d47d5c1c  vmovaps [rsp+0x80], xmm1
00007e55d47d5c25  movups xmm1, [r13+r14*1]
00007e55d47d5c2b  vmovaps [rsp+0x90], xmm1
00007e55d47d5c34  vmovaps [rsp+0xF0], xmm15
00007e55d47d5c3d  vmovaps xmm15, [rsp+0xB0]
00007e55d47d5c46  vmovaps [rsp+0xB0], xmm14
00007e55d47d5c4f  movaps xmm1, xmm6
00007e55d47d5c52  addpd xmm1, xmm15
00007e55d47d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007e55d47d5c5c  ptest xmm14, xmm14
00007e55d47d5c62  jnz 0x00007E55D47D7323
00007e55d47d5c68  lea r14, [rax+0xF0]
00007e55d47d5c6f  movups xmm15, [r13+r14*1]
00007e55d47d5c75  movaps xmm14, xmm4
00007e55d47d5c79  addpd xmm14, xmm3
00007e55d47d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007e55d47d5c84  ptest xmm6, xmm6
00007e55d47d5c89  jnz 0x00007E55D47D746E
00007e55d47d5c8f  movaps xmm6, xmm9
00007e55d47d5c93  addpd xmm6, xmm7
00007e55d47d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007e55d47d5c9c  ptest xmm4, xmm4
00007e55d47d5ca1  jnz 0x00007E55D47D75B0
00007e55d47d5ca7  vmovaps xmm9, [rsp+0x70]
00007e55d47d5cad  vpermilpd xmm9, xmm9, 0x00
00007e55d47d5cb3  vmovaps xmm4, [rsp+0x90]
00007e55d47d5cbc  movaps xmm7, xmm4
00007e55d47d5cbf  mulpd xmm7, xmm9
00007e55d47d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007e55d47d5cc9  ptest xmm3, xmm3
00007e55d47d5cce  jnz 0x00007E55D47D76F1
00007e55d47d5cd4  vmovaps xmm9, [rsp+0x50]
00007e55d47d5cda  vpermilpd xmm9, xmm9, 0x00
00007e55d47d5ce0  movaps xmm4, xmm15
00007e55d47d5ce4  mulpd xmm4, xmm9
00007e55d47d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007e55d47d5cee  ptest xmm3, xmm3
00007e55d47d5cf3  jnz 0x00007E55D47D7832
00007e55d47d5cf9  lea r14, [rax+0xE0]
00007e55d47d5d00  movups xmm15, [r13+r14*1]
00007e55d47d5d06  vmovaps xmm9, [rsp+0x70]
00007e55d47d5d0c  vpermilpd xmm9, xmm9, 0x00
00007e55d47d5d12  vmovaps [rsp+0x70], xmm1
00007e55d47d5d18  vmovaps xmm1, [rsp+0x80]
00007e55d47d5d21  vmovaps [rsp+0x80], xmm15
00007e55d47d5d2a  movaps xmm3, xmm1
00007e55d47d5d2d  mulpd xmm3, xmm9
00007e55d47d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007e55d47d5d37  ptest xmm15, xmm15
00007e55d47d5d3d  jnz 0x00007E55D47D797E
00007e55d47d5d43  vmovaps xmm1, [rsp+0xF0]
00007e55d47d5d4c  vmovaps xmm15, [rsp+0xF0]
00007e55d47d5d55  por xmm1, xmm15
00007e55d47d5d5a  movaps [r15+0x300], xmm1
00007e55d47d5d62  vmovaps xmm15, [rsp+0xE0]
00007e55d47d5d6b  vmovaps xmm9, [rsp+0xE0]
00007e55d47d5d74  por xmm15, xmm9
00007e55d47d5d79  movaps [r15+0x190], xmm15
00007e55d47d5d81  vmovaps xmm9, [rsp+0x50]
00007e55d47d5d87  vpermilpd xmm9, xmm9, 0x00
00007e55d47d5d8d  vmovaps [rsp+0x90], xmm1
00007e55d47d5d96  vmovaps [rsp+0xE0], xmm15
00007e55d47d5d9f  vmovaps xmm15, [rsp+0x80]
00007e55d47d5da8  vmovaps [rsp+0x80], xmm14
00007e55d47d5db1  movaps xmm1, xmm15
00007e55d47d5db5  mulpd xmm1, xmm9
00007e55d47d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007e55d47d5dbf  ptest xmm14, xmm14
00007e55d47d5dc5  jnz 0x00007E55D47D7ABF
00007e55d47d5dcb  lea r14, [rax+0x90]
00007e55d47d5dd2  movups xmm15, [r13+r14*1]
00007e55d47d5dd8  vmovaps xmm14, [rsp+0xD0]
00007e55d47d5de1  vmovaps xmm9, [rsp+0xD0]
00007e55d47d5dea  por xmm14, xmm9
00007e55d47d5def  movaps [r15+0x1C0], xmm14
00007e55d47d5df7  vmovaps xmm9, [rsp+0xC0]
00007e55d47d5e00  vmovaps [rsp+0xD0], xmm1
00007e55d47d5e09  vmovaps xmm1, [rsp+0xC0]
00007e55d47d5e12  por xmm9, xmm1
00007e55d47d5e17  movaps [r15+0x200], xmm9
00007e55d47d5e1f  vmovaps [rsp+0xC0], xmm2
00007e55d47d5e28  vmovaps xmm1, [rsp+0xC0]
00007e55d47d5e31  por xmm2, xmm1
00007e55d47d5e35  movaps [r15+0x2D0], xmm2
00007e55d47d5e3d  vmovaps [rsp+0xC0], xmm8
00007e55d47d5e46  vmovaps xmm1, [rsp+0xC0]
00007e55d47d5e4f  por xmm8, xmm1
00007e55d47d5e54  movaps [r15+0x2E0], xmm8
00007e55d47d5e5c  vmovaps [rsp+0xC0], xmm15
00007e55d47d5e65  movaps xmm1, xmm5
00007e55d47d5e68  addpd xmm1, xmm7
00007e55d47d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007e55d47d5e71  ptest xmm15, xmm15
00007e55d47d5e77  jnz 0x00007E55D47D7C0B
00007e55d47d5e7d  vmovaps xmm15, [rsp+0x50]
00007e55d47d5e83  vpermilpd xmm15, xmm15, 0x00
00007e55d47d5e89  vmovaps xmm5, [rsp+0xC0]
00007e55d47d5e92  vmovaps [rsp+0xC0], xmm1
00007e55d47d5e9b  movaps xmm7, xmm5
00007e55d47d5e9e  mulpd xmm7, xmm15
00007e55d47d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007e55d47d5ea8  ptest xmm1, xmm1
00007e55d47d5ead  jnz 0x00007E55D47D7D4B
00007e55d47d5eb3  lea r14, [rax+0x80]
00007e55d47d5eba  movups xmm1, [r13+r14*1]
00007e55d47d5ec0  vmovaps xmm5, [rsp+0x70]
00007e55d47d5ec6  vmovaps [rsp+0x70], xmm1
00007e55d47d5ecc  movaps xmm15, xmm5
00007e55d47d5ed0  addpd xmm15, xmm3
00007e55d47d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e55d47d5edb  ptest xmm1, xmm1
00007e55d47d5ee0  jnz 0x00007E55D47D7E96
00007e55d47d5ee6  vmovaps xmm5, [rsp+0x80]
00007e55d47d5eef  movaps xmm1, xmm5
00007e55d47d5ef2  addpd xmm1, xmm4
00007e55d47d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007e55d47d5efb  ptest xmm3, xmm3
00007e55d47d5f00  jnz 0x00007E55D47D7FD8
00007e55d47d5f06  vmovaps [rsp+0x80], xmm10
00007e55d47d5f0f  vmovaps xmm5, [rsp+0x80]
00007e55d47d5f18  por xmm10, xmm5
00007e55d47d5f1d  movaps [r15+0x2F0], xmm10
00007e55d47d5f25  vmovaps xmm5, [rsp+0x50]
00007e55d47d5f2b  vpermilpd xmm5, xmm5, 0x00
00007e55d47d5f31  vmovaps xmm3, [rsp+0x70]
00007e55d47d5f37  vmovaps [rsp+0x50], xmm1
00007e55d47d5f3d  movaps xmm4, xmm3
00007e55d47d5f40  mulpd xmm4, xmm5
00007e55d47d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007e55d47d5f49  ptest xmm1, xmm1
00007e55d47d5f4e  jnz 0x00007E55D47D8118
00007e55d47d5f54  lea r14, [rax+0xD0]
00007e55d47d5f5b  movups xmm1, [r13+r14*1]
00007e55d47d5f61  vmovaps xmm3, [rsp+0xD0]
00007e55d47d5f6a  vmovaps [rsp+0x70], xmm1
00007e55d47d5f70  movaps xmm5, xmm6
00007e55d47d5f73  addpd xmm5, xmm3
00007e55d47d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007e55d47d5f7c  ptest xmm1, xmm1
00007e55d47d5f81  jnz 0x00007E55D47D8262
00007e55d47d5f87  vmovaps xmm1, [rsp+0x60]
00007e55d47d5f8d  vpermilpd xmm1, xmm1, 0x00
00007e55d47d5f93  movaps xmm6, xmm9
00007e55d47d5f97  mulpd xmm6, xmm1
00007e55d47d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007e55d47d5fa0  ptest xmm3, xmm3
00007e55d47d5fa5  jnz 0x00007E55D47D83A2
00007e55d47d5fab  movaps [r15+0x260], xmm6
00007e55d47d5fb3  vxorps xmm1, xmm1, xmm1
00007e55d47d5fb7  vpbroadcastq xmm1, xmm1
00007e55d47d5fbc  movaps [r15+0x1B0], xmm1
00007e55d47d5fc4  vmovaps xmm1, [rsp+0x60]
00007e55d47d5fca  vpermilpd xmm1, xmm1, 0x00
00007e55d47d5fd0  vmovaps xmm3, [rsp+0x70]
00007e55d47d5fd6  vmovaps [rsp+0x70], xmm15
00007e55d47d5fdc  movaps xmm9, xmm3
00007e55d47d5fe0  mulpd xmm9, xmm1
00007e55d47d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007e55d47d5feb  ptest xmm15, xmm15
00007e55d47d5ff1  jnz 0x00007E55D47D84E3
00007e55d47d5ff7  lea r14, [rax+0xC0]
00007e55d47d5ffe  movups xmm1, [r13+r14*1]
00007e55d47d6004  vmovaps xmm3, [rsp+0xC0]
00007e55d47d600d  vmovaps [rsp+0x80], xmm1
00007e55d47d6016  movaps xmm15, xmm3
00007e55d47d601a  addpd xmm15, xmm7
00007e55d47d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007e55d47d6025  ptest xmm1, xmm1
00007e55d47d602a  jnz 0x00007E55D47D862F
00007e55d47d6030  vmovaps [rsp+0xC0], xmm13
00007e55d47d6039  vmovaps xmm1, [rsp+0xC0]
00007e55d47d6042  por xmm13, xmm1
00007e55d47d6047  movaps [r15+0x270], xmm13
00007e55d47d604f  vmovaps xmm1, [rsp+0xB0]
00007e55d47d6058  vmovaps xmm7, [rsp+0xB0]
00007e55d47d6061  por xmm1, xmm7
00007e55d47d6065  movaps [r15+0x1A0], xmm1
00007e55d47d606d  vmovaps xmm1, [rsp+0x60]
00007e55d47d6073  vpermilpd xmm1, xmm1, 0x00
00007e55d47d6079  vmovaps [rsp+0xB0], xmm1
00007e55d47d6082  vmovaps xmm1, [rsp+0x80]
00007e55d47d608b  vmovaps [rsp+0x80], xmm15
00007e55d47d6094  vmovaps xmm15, [rsp+0xB0]
00007e55d47d609d  vmovaps [rsp+0xB0], xmm14
00007e55d47d60a6  movaps xmm3, xmm1
00007e55d47d60a9  mulpd xmm3, xmm15
00007e55d47d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007e55d47d60b3  ptest xmm14, xmm14
00007e55d47d60b9  jnz 0x00007E55D47D8771
00007e55d47d60bf  lea r14, [rax+0x20]
00007e55d47d60c3  movups xmm1, [r13+r14*1]
00007e55d47d60c9  movaps [r15+0x110], xmm1
00007e55d47d60d1  vmovaps xmm14, [rsp+0x70]
00007e55d47d60d7  vmovaps [rsp+0x70], xmm1
00007e55d47d60dd  movaps xmm15, xmm14
00007e55d47d60e1  addpd xmm15, xmm4
00007e55d47d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007e55d47d60ec  ptest xmm1, xmm1
00007e55d47d60f1  jnz 0x00007E55D47D88BC
00007e55d47d60f7  vmovaps xmm1, [rsp+0x60]
00007e55d47d60fd  vpermilpd xmm1, xmm1, 0x00
00007e55d47d6103  movaps xmm14, xmm2
00007e55d47d6107  mulpd xmm14, xmm1
00007e55d47d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007e55d47d6112  ptest xmm4, xmm4
00007e55d47d6117  jnz 0x00007E55D47D89FF
00007e55d47d611d  vmovaps xmm4, [rsp+0x50]
00007e55d47d6123  movaps xmm1, xmm4
00007e55d47d6126  addpd xmm1, xmm9
00007e55d47d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007e55d47d6130  ptest xmm2, xmm2
00007e55d47d6135  jnz 0x00007E55D47D8B41
00007e55d47d613b  vmovaps xmm9, [rsp+0x30]
00007e55d47d6141  vpermilpd xmm9, xmm9, 0x00
00007e55d47d6147  vmovaps xmm2, [rsp+0x70]
00007e55d47d614d  vmovaps [rsp+0x50], xmm1
00007e55d47d6153  movaps xmm4, xmm2
00007e55d47d6156  mulpd xmm4, xmm9
00007e55d47d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007e55d47d6160  ptest xmm1, xmm1
00007e55d47d6165  jnz 0x00007E55D47D8C82
00007e55d47d616b  vmovaps xmm1, [rsp+0x30]
00007e55d47d6171  vpermilpd xmm1, xmm1, 0x00
00007e55d47d6177  vmovaps xmm2, [rsp+0x90]
00007e55d47d6180  vmovaps [rsp+0x60], xmm15
00007e55d47d6186  movaps xmm9, xmm2
00007e55d47d618a  mulpd xmm9, xmm1
00007e55d47d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007e55d47d6195  ptest xmm15, xmm15
00007e55d47d619b  jnz 0x00007E55D47D8DC3
00007e55d47d61a1  vmovaps xmm15, [rsp+0x80]
00007e55d47d61aa  movaps xmm1, xmm15
00007e55d47d61ae  addpd xmm1, xmm6
00007e55d47d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007e55d47d61b7  ptest xmm2, xmm2
00007e55d47d61bc  jnz 0x00007E55D47D8F05
00007e55d47d61c2  movaps xmm15, xmm5
00007e55d47d61c6  addpd xmm15, xmm3
00007e55d47d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007e55d47d61d1  ptest xmm6, xmm6
00007e55d47d61d6  jnz 0x00007E55D47D9046
00007e55d47d61dc  vmovaps xmm6, [rsp+0x30]
00007e55d47d61e2  vpermilpd xmm6, xmm6, 0x00
00007e55d47d61e8  movaps xmm5, xmm8
00007e55d47d61ec  mulpd xmm5, xmm6
00007e55d47d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007e55d47d61f5  ptest xmm3, xmm3
00007e55d47d61fa  jnz 0x00007E55D47D9188
00007e55d47d6200  vmovaps xmm8, [rsp+0x30]
00007e55d47d6206  vpermilpd xmm8, xmm8, 0x00
00007e55d47d620c  movaps xmm6, xmm10
00007e55d47d6210  mulpd xmm6, xmm8
00007e55d47d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007e55d47d621a  ptest xmm3, xmm3
00007e55d47d621f  jnz 0x00007E55D47D92C9
00007e55d47d6225  vmovaps xmm8, [rsp+0x60]
00007e55d47d622b  movaps xmm10, xmm8
00007e55d47d622f  addpd xmm10, xmm14
00007e55d47d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007e55d47d623a  ptest xmm3, xmm3
00007e55d47d623f  jnz 0x00007E55D47D940B
00007e55d47d6245  vmovaps xmm8, [rsp+0x50]
00007e55d47d624b  movaps xmm14, xmm8
00007e55d47d624f  addpd xmm14, xmm4
00007e55d47d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007e55d47d625a  ptest xmm3, xmm3
00007e55d47d625f  jnz 0x00007E55D47D954F
00007e55d47d6265  vmovaps xmm8, [rsp+0x40]
00007e55d47d626b  vpermilpd xmm8, xmm8, 0x00
00007e55d47d6271  movaps xmm4, xmm13
00007e55d47d6275  mulpd xmm4, xmm8
00007e55d47d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007e55d47d627f  ptest xmm3, xmm3
00007e55d47d6284  jnz 0x00007E55D47D9692
00007e55d47d628a  movaps xmm13, xmm15
00007e55d47d628e  addpd xmm13, xmm9
00007e55d47d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007e55d47d6299  ptest xmm8, xmm8
00007e55d47d629f  jnz 0x00007E55D47D97D4
00007e55d47d62a5  movaps xmm15, xmm1
00007e55d47d62a9  addpd xmm15, xmm5
00007e55d47d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007e55d47d62b4  ptest xmm9, xmm9
00007e55d47d62ba  jnz 0x00007E55D47D9918
00007e55d47d62c0  vmovaps [rsp+0x30], xmm11
00007e55d47d62c6  vmovaps xmm1, [rsp+0x30]
00007e55d47d62cc  por xmm11, xmm1
00007e55d47d62d1  movaps [r15+0x250], xmm11
00007e55d47d62d9  vmovaps [rsp+0x30], xmm12
00007e55d47d62df  vmovaps xmm1, [rsp+0x30]
00007e55d47d62e5  por xmm12, xmm1
00007e55d47d62ea  movaps [r15+0x2A0], xmm12
00007e55d47d62f2  vmovaps xmm1, [rsp+0xA0]
00007e55d47d62fb  vmovaps xmm11, [rsp+0xA0]
00007e55d47d6304  por xmm1, xmm11
00007e55d47d6309  movaps [r15+0x1D0], xmm1
00007e55d47d6311  lea r14, [rax+0x40]
00007e55d47d6315  movups xmm1, [r13+r14*1]
00007e55d47d631b  movaps [r15+0x2C0], xmm1
00007e55d47d6323  vmovaps xmm11, [rsp+0x40]
00007e55d47d6329  vpermilpd xmm11, xmm11, 0x00
00007e55d47d632f  vmovaps xmm8, [rsp+0xE0]
00007e55d47d6338  movaps xmm9, xmm8
00007e55d47d633c  mulpd xmm9, xmm11
00007e55d47d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007e55d47d6347  ptest xmm5, xmm5
00007e55d47d634c  jnz 0x00007E55D47D9A64
00007e55d47d6352  movaps xmm11, xmm10
00007e55d47d6356  addpd xmm11, xmm6
00007e55d47d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007e55d47d6361  ptest xmm8, xmm8
00007e55d47d6367  jnz 0x00007E55D47D9BA8
00007e55d47d636d  movaps xmm10, xmm14
00007e55d47d6371  addpd xmm10, xmm4
00007e55d47d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007e55d47d637c  ptest xmm8, xmm8
00007e55d47d6382  jnz 0x00007E55D47D9CEB
00007e55d47d6388  vmovaps xmm14, [rsp+0x40]
00007e55d47d638e  vpermilpd xmm14, xmm14, 0x00
00007e55d47d6394  movaps xmm8, xmm1
00007e55d47d6398  mulpd xmm8, xmm14
00007e55d47d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007e55d47d63a3  ptest xmm6, xmm6
00007e55d47d63a8  jnz 0x00007E55D47D9E2E
00007e55d47d63ae  movaps xmm1, [r15+0x2B0]
00007e55d47d63b6  vmovaps xmm14, [rsp+0x40]
00007e55d47d63bc  vpermilpd xmm14, xmm14, 0x00
00007e55d47d63c2  movaps xmm6, xmm1
00007e55d47d63c5  mulpd xmm6, xmm14
00007e55d47d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007e55d47d63cf  ptest xmm5, xmm5
00007e55d47d63d4  jnz 0x00007E55D47D9F71
00007e55d47d63da  vmovaps xmm1, [rsp+0x10]
00007e55d47d63e0  vpermilpd xmm1, xmm1, 0x00
00007e55d47d63e6  movaps xmm14, xmm12
00007e55d47d63ea  mulpd xmm14, xmm1
00007e55d47d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007e55d47d63f5  ptest xmm5, xmm5
00007e55d47d63fa  jnz 0x00007E55D47DA0B2
00007e55d47d6400  movaps xmm1, xmm13
00007e55d47d6404  addpd xmm1, xmm9
00007e55d47d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007e55d47d640e  ptest xmm12, xmm12
00007e55d47d6414  jnz 0x00007E55D47DA1F5
00007e55d47d641a  vmovaps xmm13, [rsp+0x10]
00007e55d47d6420  vpermilpd xmm13, xmm13, 0x00
00007e55d47d6426  movaps xmm12, xmm7
00007e55d47d642a  mulpd xmm12, xmm13
00007e55d47d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007e55d47d6435  ptest xmm9, xmm9
00007e55d47d643b  jnz 0x00007E55D47DA337
00007e55d47d6441  movaps xmm13, xmm15
00007e55d47d6445  addpd xmm13, xmm8
00007e55d47d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007e55d47d6450  ptest xmm9, xmm9
00007e55d47d6456  jnz 0x00007E55D47DA47A
00007e55d47d645c  movaps xmm15, [r15+0x290]
00007e55d47d6464  vmovaps xmm9, [rsp+0x10]
00007e55d47d646a  vpermilpd xmm9, xmm9, 0x00
00007e55d47d6470  movaps xmm8, xmm15
00007e55d47d6474  mulpd xmm8, xmm9
00007e55d47d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007e55d47d647f  ptest xmm7, xmm7
00007e55d47d6484  jnz 0x00007E55D47DA5BE
00007e55d47d648a  movaps xmm15, xmm11
00007e55d47d648e  addpd xmm15, xmm6
00007e55d47d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007e55d47d6499  ptest xmm9, xmm9
00007e55d47d649f  jnz 0x00007E55D47DA702
00007e55d47d64a5  movaps xmm11, [r15+0x1E0]
00007e55d47d64ad  vmovaps xmm9, [rsp+0x10]
00007e55d47d64b3  vpermilpd xmm9, xmm9, 0x00
00007e55d47d64b9  movaps xmm7, xmm11
00007e55d47d64bd  mulpd xmm7, xmm9
00007e55d47d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007e55d47d64c7  ptest xmm6, xmm6
00007e55d47d64cc  jnz 0x00007E55D47DA845
00007e55d47d64d2  movaps xmm11, xmm10
00007e55d47d64d6  addpd xmm11, xmm14
00007e55d47d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007e55d47d64e1  ptest xmm9, xmm9
00007e55d47d64e7  jnz 0x00007E55D47DA987
00007e55d47d64ed  lea r14, [rax+0x70]
00007e55d47d64f1  movups xmm14, [r13+r14*1]
00007e55d47d64f7  movaps [r15+0x240], xmm14
00007e55d47d64ff  movaps xmm10, xmm1
00007e55d47d6503  addpd xmm10, xmm12
00007e55d47d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007e55d47d650e  ptest xmm9, xmm9
00007e55d47d6514  jnz 0x00007E55D47DAAD5
00007e55d47d651a  movaps [r15+0x170], xmm10
00007e55d47d6522  vmovaps xmm1, [rsp+0x20]
00007e55d47d6528  vpermilpd xmm1, xmm1, 0x00
00007e55d47d652e  movaps xmm12, xmm14
00007e55d47d6532  mulpd xmm12, xmm1
00007e55d47d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007e55d47d653d  ptest xmm9, xmm9
00007e55d47d6543  jnz 0x00007E55D47DAC18
00007e55d47d6549  vmovaps xmm1, [rsp+0x20]
00007e55d47d654f  vpermilpd xmm1, xmm1, 0x00
00007e55d47d6555  vmovaps xmm9, [rsp+0xB0]
00007e55d47d655e  movaps xmm14, xmm9
00007e55d47d6562  mulpd xmm14, xmm1
00007e55d47d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007e55d47d656d  ptest xmm6, xmm6
00007e55d47d6572  jnz 0x00007E55D47DAD5B
00007e55d47d6578  movaps [r15+0x180], xmm14
00007e55d47d6580  movaps xmm1, xmm13
00007e55d47d6584  addpd xmm1, xmm8
00007e55d47d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007e55d47d658e  ptest xmm9, xmm9
00007e55d47d6594  jnz 0x00007E55D47DAE9E
00007e55d47d659a  movaps [r15+0x210], xmm1
00007e55d47d65a2  movups xmm13, [r13+rax*1]
00007e55d47d65a8  lea r14, [rax+0x10]
00007e55d47d65ac  movups xmm9, [r13+r14*1]
00007e55d47d65b2  movaps [r15+0x230], xmm9
00007e55d47d65ba  movaps xmm8, xmm15
00007e55d47d65be  addpd xmm8, xmm7
00007e55d47d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007e55d47d65c9  ptest xmm6, xmm6
00007e55d47d65ce  jnz 0x00007E55D47DAFF4
00007e55d47d65d4  movaps [r15+0x130], xmm8
00007e55d47d65dc  vmovaps xmm15, [rsp+0x20]
00007e55d47d65e2  vpermilpd xmm15, xmm15, 0x00
00007e55d47d65e8  movaps xmm7, xmm9
00007e55d47d65ec  mulpd xmm7, xmm15
00007e55d47d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007e55d47d65f6  ptest xmm6, xmm6
00007e55d47d65fb  jnz 0x00007E55D47DB137
00007e55d47d6601  movaps [r15+0x220], xmm7
00007e55d47d6609  vmovaps xmm15, [rsp+0x20]
00007e55d47d660f  vpermilpd xmm15, xmm15, 0x00
00007e55d47d6615  movaps xmm9, xmm13
00007e55d47d6619  mulpd xmm9, xmm15
00007e55d47d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007e55d47d6624  ptest xmm6, xmm6
00007e55d47d6629  jnz 0x00007E55D47DB279
00007e55d47d662f  movaps xmm15, xmm11
00007e55d47d6633  addpd xmm15, xmm12
00007e55d47d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007e55d47d663e  ptest xmm13, xmm13
00007e55d47d6644  jnz 0x00007E55D47DB3BD
00007e55d47d664a  movaps [r15+0x140], xmm15
00007e55d47d6652  movaps xmm13, xmm10
00007e55d47d6656  addpd xmm13, xmm14
00007e55d47d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007e55d47d6661  ptest xmm12, xmm12
00007e55d47d6667  jnz 0x00007E55D47DB501
00007e55d47d666d  movaps [r15+0x150], xmm13
00007e55d47d6675  movaps xmm14, xmm1
00007e55d47d6679  addpd xmm14, xmm7
00007e55d47d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007e55d47d6684  ptest xmm12, xmm12
00007e55d47d668a  jnz 0x00007E55D47DB645
00007e55d47d6690  movaps [r15+0x160], xmm14
00007e55d47d6698  movaps xmm1, xmm8
00007e55d47d669c  addpd xmm1, xmm9
00007e55d47d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007e55d47d66a6  ptest xmm12, xmm12
00007e55d47d66ac  jnz 0x00007E55D47DB787
00007e55d47d66b2  movaps [r15+0x120], xmm1
00007e55d47d66ba  movups [r13+r11*1], xmm15
00007e55d47d66c0  lea rax, [r11+0x10]
00007e55d47d66c4  movups [r13+rax*1], xmm13
00007e55d47d66ca  lea rax, [r11+0x20]
00007e55d47d66ce  movups [r13+rax*1], xmm14
00007e55d47d66d4  lea rax, [r11+0x30]
00007e55d47d66d8  movups [r13+rax*1], xmm1
00007e55d47d66de  mov eax, [r15+0x108]
00007e55d47d66e5  sahf
00007e55d47d66e6  jnz 0x00007E55D47D6718
00007e55d47d66e8  cmp dword ptr [r15+0x318], 0x00
00007e55d47d66f0  jz 0x00007E55D47DB900
00007e55d47d66f6  nop [rax+rax*1], ax
00007e55d47d66ff  nop [rax+rax*1], eax
00007e55d47d6707  mov eax, 0x410444
00007e55d47d670c  mov [r15+0x100], rax
00007e55d47d6713  jmp 0x00007E55D45FE110
00007e55d47d6718  cmp dword ptr [r15+0x318], 0x00
00007e55d47d6720  jz 0x00007E55D47D57E0
00007e55d47d6726  nop [rax+rax*1], ax
00007e55d47d672f  nop [rax+rax*1], eax
00007e55d47d6737  mov eax, 0x410278
00007e55d47d673c  mov [r15+0x100], rax
00007e55d47d6743  jmp 0x00007E55D45FE110
00007e55d47d6748  int3
00007e55d47d6749  call 0x00007E55D460A4B0
00007e55d47d674e  jmp 0x00007E55D47D5828
00007e55d47d6753  call 0x00007E55D4609240
00007e55d47d6758  jmp 0x00007E55D47D5832
00007e55d47d675d  call 0x00007E55D460A4B0
00007e55d47d6762  jmp 0x00007E55D47D588F
00007e55d47d6767  call 0x00007E55D4609240
00007e55d47d676c  jmp 0x00007E55D47D5899
00007e55d47d6771  call 0x00007E55D460A4B0
00007e55d47d6776  jmp 0x00007E55D47D58DD
00007e55d47d677b  call 0x00007E55D4609240
00007e55d47d6780  jmp 0x00007E55D47D58E7
00007e55d47d6785  call 0x00007E55D46B47C0
00007e55d47d678a  jmp 0x00007E55D47D5926
00007e55d47d678f  call 0x00007E55D460B720
00007e55d47d6794  jmp 0x00007E55D47D593A
00007e55d47d6799  call 0x00007E55D46BFC30
00007e55d47d679e  jmp 0x00007E55D47D5958
00007e55d47d67a3  call 0x00007E55D46BE9C0
00007e55d47d67a8  jmp 0x00007E55D47D5962
00007e55d47d67ad  call 0x00007E55D46BD750
00007e55d47d67b2  jmp 0x00007E55D47D596C
00007e55d47d67b7  sub rsp, 0x08
00007e55d47d67bb  push rax
00007e55d47d67bc  push rcx
00007e55d47d67bd  push rdx
00007e55d47d67be  push rdi
00007e55d47d67bf  push rsi
00007e55d47d67c0  push r8
00007e55d47d67c2  push r9
00007e55d47d67c4  push r10
00007e55d47d67c6  push r11
00007e55d47d67c8  sub rsp, 0xF0
00007e55d47d67cf  vmovaps [rsp], xmm0
00007e55d47d67d4  vmovaps [rsp+0x10], xmm1
00007e55d47d67da  vmovaps [rsp+0x20], xmm2
00007e55d47d67e0  vmovaps [rsp+0x30], xmm3
00007e55d47d67e6  vmovaps [rsp+0x40], xmm4
00007e55d47d67ec  vmovaps [rsp+0x50], xmm5
00007e55d47d67f2  vmovaps [rsp+0x60], xmm6
00007e55d47d67f8  vmovaps [rsp+0x70], xmm7
00007e55d47d67fe  vmovaps [rsp+0x80], xmm9
00007e55d47d6807  vmovaps [rsp+0x90], xmm10
00007e55d47d6810  vmovaps [rsp+0xA0], xmm11
00007e55d47d6819  vmovaps [rsp+0xB0], xmm12
00007e55d47d6822  vmovaps [rsp+0xC0], xmm13
00007e55d47d682b  vmovaps [rsp+0xD0], xmm14
00007e55d47d6834  vmovaps [rsp+0xE0], xmm15
00007e55d47d683d  sub rsp, 0x30
00007e55d47d6841  movaps [rsp], xmm8
00007e55d47d6846  movaps [rsp+0x10], xmm12
00007e55d47d684c  movaps [rsp+0x20], xmm15
00007e55d47d6852  lea rdi, [rsp]
00007e55d47d6856  mov esi, 0x00
00007e55d47d685b  mov rax, 0x55D0734A4530
00007e55d47d6865  call rax
00007e55d47d6867  movaps xmm8, [rsp]
00007e55d47d686c  add rsp, 0x30
00007e55d47d6870  vmovaps xmm0, [rsp]
00007e55d47d6875  vmovaps xmm1, [rsp+0x10]
00007e55d47d687b  vmovaps xmm2, [rsp+0x20]
00007e55d47d6881  vmovaps xmm3, [rsp+0x30]
00007e55d47d6887  vmovaps xmm4, [rsp+0x40]
00007e55d47d688d  vmovaps xmm5, [rsp+0x50]
00007e55d47d6893  vmovaps xmm6, [rsp+0x60]
00007e55d47d6899  vmovaps xmm7, [rsp+0x70]
00007e55d47d689f  vmovaps xmm9, [rsp+0x80]
00007e55d47d68a8  vmovaps xmm10, [rsp+0x90]
00007e55d47d68b1  vmovaps xmm11, [rsp+0xA0]
00007e55d47d68ba  vmovaps xmm12, [rsp+0xB0]
00007e55d47d68c3  vmovaps xmm13, [rsp+0xC0]
00007e55d47d68cc  vmovaps xmm14, [rsp+0xD0]
00007e55d47d68d5  vmovaps xmm15, [rsp+0xE0]
00007e55d47d68de  add rsp, 0xF0
00007e55d47d68e5  pop r11
00007e55d47d68e7  pop r10
00007e55d47d68e9  pop r9
00007e55d47d68eb  pop r8
00007e55d47d68ed  pop rsi
00007e55d47d68ee  pop rdi
00007e55d47d68ef  pop rdx
00007e55d47d68f0  pop rcx
00007e55d47d68f1  pop rax
00007e55d47d68f2  add rsp, 0x08
00007e55d47d68f6  jmp 0x00007E55D47D599A
00007e55d47d68fb  sub rsp, 0x08
00007e55d47d68ff  push rax
00007e55d47d6900  push rcx
00007e55d47d6901  push rdx
00007e55d47d6902  push rdi
00007e55d47d6903  push rsi
00007e55d47d6904  push r8
00007e55d47d6906  push r9
00007e55d47d6908  push r10
00007e55d47d690a  push r11
00007e55d47d690c  sub rsp, 0xF0
00007e55d47d6913  vmovaps [rsp], xmm0
00007e55d47d6918  vmovaps [rsp+0x10], xmm1
00007e55d47d691e  vmovaps [rsp+0x20], xmm2
00007e55d47d6924  vmovaps [rsp+0x30], xmm3
00007e55d47d692a  vmovaps [rsp+0x40], xmm4
00007e55d47d6930  vmovaps [rsp+0x50], xmm5
00007e55d47d6936  vmovaps [rsp+0x60], xmm6
00007e55d47d693c  vmovaps [rsp+0x70], xmm8
00007e55d47d6942  vmovaps [rsp+0x80], xmm9
00007e55d47d694b  vmovaps [rsp+0x90], xmm10
00007e55d47d6954  vmovaps [rsp+0xA0], xmm11
00007e55d47d695d  vmovaps [rsp+0xB0], xmm12
00007e55d47d6966  vmovaps [rsp+0xC0], xmm13
00007e55d47d696f  vmovaps [rsp+0xD0], xmm14
00007e55d47d6978  vmovaps [rsp+0xE0], xmm15
00007e55d47d6981  sub rsp, 0x30
00007e55d47d6985  movaps [rsp], xmm7
00007e55d47d6989  movaps [rsp+0x10], xmm9
00007e55d47d698f  movaps [rsp+0x20], xmm15
00007e55d47d6995  lea rdi, [rsp]
00007e55d47d6999  mov esi, 0x00
00007e55d47d699e  mov rax, 0x55D0734A4530
00007e55d47d69a8  call rax
00007e55d47d69aa  movaps xmm7, [rsp]
00007e55d47d69ae  add rsp, 0x30
00007e55d47d69b2  vmovaps xmm0, [rsp]
00007e55d47d69b7  vmovaps xmm1, [rsp+0x10]
00007e55d47d69bd  vmovaps xmm2, [rsp+0x20]
00007e55d47d69c3  vmovaps xmm3, [rsp+0x30]
00007e55d47d69c9  vmovaps xmm4, [rsp+0x40]
00007e55d47d69cf  vmovaps xmm5, [rsp+0x50]
00007e55d47d69d5  vmovaps xmm6, [rsp+0x60]
00007e55d47d69db  vmovaps xmm8, [rsp+0x70]
00007e55d47d69e1  vmovaps xmm9, [rsp+0x80]
00007e55d47d69ea  vmovaps xmm10, [rsp+0x90]
00007e55d47d69f3  vmovaps xmm11, [rsp+0xA0]
00007e55d47d69fc  vmovaps xmm12, [rsp+0xB0]
00007e55d47d6a05  vmovaps xmm13, [rsp+0xC0]
00007e55d47d6a0e  vmovaps xmm14, [rsp+0xD0]
00007e55d47d6a17  vmovaps xmm15, [rsp+0xE0]
00007e55d47d6a20  add rsp, 0xF0
00007e55d47d6a27  pop r11
00007e55d47d6a29  pop r10
00007e55d47d6a2b  pop r9
00007e55d47d6a2d  pop r8
00007e55d47d6a2f  pop rsi
00007e55d47d6a30  pop rdi
00007e55d47d6a31  pop rdx
00007e55d47d6a32  pop rcx
00007e55d47d6a33  pop rax
00007e55d47d6a34  add rsp, 0x08
00007e55d47d6a38  jmp 0x00007E55D47D59C8
00007e55d47d6a3d  sub rsp, 0x08
00007e55d47d6a41  push rax
00007e55d47d6a42  push rcx
00007e55d47d6a43  push rdx
00007e55d47d6a44  push rdi
00007e55d47d6a45  push rsi
00007e55d47d6a46  push r8
00007e55d47d6a48  push r9
00007e55d47d6a4a  push r10
00007e55d47d6a4c  push r11
00007e55d47d6a4e  sub rsp, 0xF0
00007e55d47d6a55  vmovaps [rsp], xmm0
00007e55d47d6a5a  vmovaps [rsp+0x10], xmm1
00007e55d47d6a60  vmovaps [rsp+0x20], xmm2
00007e55d47d6a66  vmovaps [rsp+0x30], xmm3
00007e55d47d6a6c  vmovaps [rsp+0x40], xmm4
00007e55d47d6a72  vmovaps [rsp+0x50], xmm5
00007e55d47d6a78  vmovaps [rsp+0x60], xmm6
00007e55d47d6a7e  vmovaps [rsp+0x70], xmm7
00007e55d47d6a84  vmovaps [rsp+0x80], xmm8
00007e55d47d6a8d  vmovaps [rsp+0x90], xmm10
00007e55d47d6a96  vmovaps [rsp+0xA0], xmm11
00007e55d47d6a9f  vmovaps [rsp+0xB0], xmm12
00007e55d47d6aa8  vmovaps [rsp+0xC0], xmm13
00007e55d47d6ab1  vmovaps [rsp+0xD0], xmm14
00007e55d47d6aba  vmovaps [rsp+0xE0], xmm15
00007e55d47d6ac3  sub rsp, 0x30
00007e55d47d6ac7  movaps [rsp], xmm9
00007e55d47d6acc  movaps [rsp+0x10], xmm12
00007e55d47d6ad2  movaps [rsp+0x20], xmm10
00007e55d47d6ad8  lea rdi, [rsp]
00007e55d47d6adc  mov esi, 0x00
00007e55d47d6ae1  mov rax, 0x55D0734A4530
00007e55d47d6aeb  call rax
00007e55d47d6aed  movaps xmm9, [rsp]
00007e55d47d6af2  add rsp, 0x30
00007e55d47d6af6  vmovaps xmm0, [rsp]
00007e55d47d6afb  vmovaps xmm1, [rsp+0x10]
00007e55d47d6b01  vmovaps xmm2, [rsp+0x20]
00007e55d47d6b07  vmovaps xmm3, [rsp+0x30]
00007e55d47d6b0d  vmovaps xmm4, [rsp+0x40]
00007e55d47d6b13  vmovaps xmm5, [rsp+0x50]
00007e55d47d6b19  vmovaps xmm6, [rsp+0x60]
00007e55d47d6b1f  vmovaps xmm7, [rsp+0x70]
00007e55d47d6b25  vmovaps xmm8, [rsp+0x80]
00007e55d47d6b2e  vmovaps xmm10, [rsp+0x90]
00007e55d47d6b37  vmovaps xmm11, [rsp+0xA0]
00007e55d47d6b40  vmovaps xmm12, [rsp+0xB0]
00007e55d47d6b49  vmovaps xmm13, [rsp+0xC0]
00007e55d47d6b52  vmovaps xmm14, [rsp+0xD0]
00007e55d47d6b5b  vmovaps xmm15, [rsp+0xE0]
00007e55d47d6b64  add rsp, 0xF0
00007e55d47d6b6b  pop r11
00007e55d47d6b6d  pop r10
00007e55d47d6b6f  pop r9
00007e55d47d6b71  pop r8
00007e55d47d6b73  pop rsi
00007e55d47d6b74  pop rdi
00007e55d47d6b75  pop rdx
00007e55d47d6b76  pop rcx
00007e55d47d6b77  pop rax
00007e55d47d6b78  add rsp, 0x08
00007e55d47d6b7c  jmp 0x00007E55D47D59EC
00007e55d47d6b81  sub rsp, 0x08
00007e55d47d6b85  push rax
00007e55d47d6b86  push rcx
00007e55d47d6b87  push rdx
00007e55d47d6b88  push rdi
00007e55d47d6b89  push rsi
00007e55d47d6b8a  push r8
00007e55d47d6b8c  push r9
00007e55d47d6b8e  push r10
00007e55d47d6b90  push r11
00007e55d47d6b92  sub rsp, 0xF0
00007e55d47d6b99  vmovaps [rsp], xmm0
00007e55d47d6b9e  vmovaps [rsp+0x10], xmm1
00007e55d47d6ba4  vmovaps [rsp+0x20], xmm2
00007e55d47d6baa  vmovaps [rsp+0x30], xmm3
00007e55d47d6bb0  vmovaps [rsp+0x40], xmm4
00007e55d47d6bb6  vmovaps [rsp+0x50], xmm5
00007e55d47d6bbc  vmovaps [rsp+0x60], xmm6
00007e55d47d6bc2  vmovaps [rsp+0x70], xmm7
00007e55d47d6bc8  vmovaps [rsp+0x80], xmm8
00007e55d47d6bd1  vmovaps [rsp+0x90], xmm9
00007e55d47d6bda  vmovaps [rsp+0xA0], xmm11
00007e55d47d6be3  vmovaps [rsp+0xB0], xmm12
00007e55d47d6bec  vmovaps [rsp+0xC0], xmm13
00007e55d47d6bf5  vmovaps [rsp+0xD0], xmm14
00007e55d47d6bfe  vmovaps [rsp+0xE0], xmm15
00007e55d47d6c07  sub rsp, 0x30
00007e55d47d6c0b  movaps [rsp], xmm10
00007e55d47d6c10  movaps [rsp+0x10], xmm12
00007e55d47d6c16  movaps [rsp+0x20], xmm11
00007e55d47d6c1c  lea rdi, [rsp]
00007e55d47d6c20  mov esi, 0x00
00007e55d47d6c25  mov rax, 0x55D0734A4530
00007e55d47d6c2f  call rax
00007e55d47d6c31  movaps xmm10, [rsp]
00007e55d47d6c36  add rsp, 0x30
00007e55d47d6c3a  vmovaps xmm0, [rsp]
00007e55d47d6c3f  vmovaps xmm1, [rsp+0x10]
00007e55d47d6c45  vmovaps xmm2, [rsp+0x20]
00007e55d47d6c4b  vmovaps xmm3, [rsp+0x30]
00007e55d47d6c51  vmovaps xmm4, [rsp+0x40]
00007e55d47d6c57  vmovaps xmm5, [rsp+0x50]
00007e55d47d6c5d  vmovaps xmm6, [rsp+0x60]
00007e55d47d6c63  vmovaps xmm7, [rsp+0x70]
00007e55d47d6c69  vmovaps xmm8, [rsp+0x80]
00007e55d47d6c72  vmovaps xmm9, [rsp+0x90]
00007e55d47d6c7b  vmovaps xmm11, [rsp+0xA0]
00007e55d47d6c84  vmovaps xmm12, [rsp+0xB0]
00007e55d47d6c8d  vmovaps xmm13, [rsp+0xC0]
00007e55d47d6c96  vmovaps xmm14, [rsp+0xD0]
00007e55d47d6c9f  vmovaps xmm15, [rsp+0xE0]
00007e55d47d6ca8  add rsp, 0xF0
00007e55d47d6caf  pop r11
00007e55d47d6cb1  pop r10
00007e55d47d6cb3  pop r9
00007e55d47d6cb5  pop r8
00007e55d47d6cb7  pop rsi
00007e55d47d6cb8  pop rdi
00007e55d47d6cb9  pop rdx
00007e55d47d6cba  pop rcx
00007e55d47d6cbb  pop rax
00007e55d47d6cbc  add rsp, 0x08
00007e55d47d6cc0  jmp 0x00007E55D47D5A06
00007e55d47d6cc5  sub rsp, 0x08
00007e55d47d6cc9  push rax
00007e55d47d6cca  push rcx
00007e55d47d6ccb  push rdx
00007e55d47d6ccc  push rdi
00007e55d47d6ccd  push rsi
00007e55d47d6cce  push r8
00007e55d47d6cd0  push r9
00007e55d47d6cd2  push r10
00007e55d47d6cd4  push r11
00007e55d47d6cd6  sub rsp, 0xF0
00007e55d47d6cdd  vmovaps [rsp], xmm0
00007e55d47d6ce2  vmovaps [rsp+0x10], xmm1
00007e55d47d6ce8  vmovaps [rsp+0x20], xmm2
00007e55d47d6cee  vmovaps [rsp+0x30], xmm3
00007e55d47d6cf4  vmovaps [rsp+0x40], xmm4
00007e55d47d6cfa  vmovaps [rsp+0x50], xmm5
00007e55d47d6d00  vmovaps [rsp+0x60], xmm7
00007e55d47d6d06  vmovaps [rsp+0x70], xmm8
00007e55d47d6d0c  vmovaps [rsp+0x80], xmm9
00007e55d47d6d15  vmovaps [rsp+0x90], xmm10
00007e55d47d6d1e  vmovaps [rsp+0xA0], xmm11
00007e55d47d6d27  vmovaps [rsp+0xB0], xmm12
00007e55d47d6d30  vmovaps [rsp+0xC0], xmm13
00007e55d47d6d39  vmovaps [rsp+0xD0], xmm14
00007e55d47d6d42  vmovaps [rsp+0xE0], xmm15
00007e55d47d6d4b  sub rsp, 0x30
00007e55d47d6d4f  movaps [rsp], xmm6
00007e55d47d6d53  movaps [rsp+0x10], xmm12
00007e55d47d6d59  movaps [rsp+0x20], xmm11
00007e55d47d6d5f  lea rdi, [rsp]
00007e55d47d6d63  mov esi, 0x00
00007e55d47d6d68  mov rax, 0x55D0734A4530
00007e55d47d6d72  call rax
00007e55d47d6d74  movaps xmm6, [rsp]
00007e55d47d6d78  add rsp, 0x30
00007e55d47d6d7c  vmovaps xmm0, [rsp]
00007e55d47d6d81  vmovaps xmm1, [rsp+0x10]
00007e55d47d6d87  vmovaps xmm2, [rsp+0x20]
00007e55d47d6d8d  vmovaps xmm3, [rsp+0x30]
00007e55d47d6d93  vmovaps xmm4, [rsp+0x40]
00007e55d47d6d99  vmovaps xmm5, [rsp+0x50]
00007e55d47d6d9f  vmovaps xmm7, [rsp+0x60]
00007e55d47d6da5  vmovaps xmm8, [rsp+0x70]
00007e55d47d6dab  vmovaps xmm9, [rsp+0x80]
00007e55d47d6db4  vmovaps xmm10, [rsp+0x90]
00007e55d47d6dbd  vmovaps xmm11, [rsp+0xA0]
00007e55d47d6dc6  vmovaps xmm12, [rsp+0xB0]
00007e55d47d6dcf  vmovaps xmm13, [rsp+0xC0]
00007e55d47d6dd8  vmovaps xmm14, [rsp+0xD0]
00007e55d47d6de1  vmovaps xmm15, [rsp+0xE0]
00007e55d47d6dea  add rsp, 0xF0
00007e55d47d6df1  pop r11
00007e55d47d6df3  pop r10
00007e55d47d6df5  pop r9
00007e55d47d6df7  pop r8
00007e55d47d6df9  pop rsi
00007e55d47d6dfa  pop rdi
00007e55d47d6dfb  pop rdx
00007e55d47d6dfc  pop rcx
00007e55d47d6dfd  pop rax
00007e55d47d6dfe  add rsp, 0x08
00007e55d47d6e02  jmp 0x00007E55D47D5A27
00007e55d47d6e07  sub rsp, 0x08
00007e55d47d6e0b  push rax
00007e55d47d6e0c  push rcx
00007e55d47d6e0d  push rdx
00007e55d47d6e0e  push rdi
00007e55d47d6e0f  push rsi
00007e55d47d6e10  push r8
00007e55d47d6e12  push r9
00007e55d47d6e14  push r10
00007e55d47d6e16  push r11
00007e55d47d6e18  sub rsp, 0xF0
00007e55d47d6e1f  vmovaps [rsp], xmm0
00007e55d47d6e24  vmovaps [rsp+0x10], xmm1
00007e55d47d6e2a  vmovaps [rsp+0x20], xmm2
00007e55d47d6e30  vmovaps [rsp+0x30], xmm4
00007e55d47d6e36  vmovaps [rsp+0x40], xmm5
00007e55d47d6e3c  vmovaps [rsp+0x50], xmm6
00007e55d47d6e42  vmovaps [rsp+0x60], xmm7
00007e55d47d6e48  vmovaps [rsp+0x70], xmm8
00007e55d47d6e4e  vmovaps [rsp+0x80], xmm9
00007e55d47d6e57  vmovaps [rsp+0x90], xmm10
00007e55d47d6e60  vmovaps [rsp+0xA0], xmm11
00007e55d47d6e69  vmovaps [rsp+0xB0], xmm12
00007e55d47d6e72  vmovaps [rsp+0xC0], xmm13
00007e55d47d6e7b  vmovaps [rsp+0xD0], xmm14
00007e55d47d6e84  vmovaps [rsp+0xE0], xmm15
00007e55d47d6e8d  sub rsp, 0x30
00007e55d47d6e91  movaps [rsp], xmm3
00007e55d47d6e95  movaps [rsp+0x10], xmm5
00007e55d47d6e9a  movaps [rsp+0x20], xmm4
00007e55d47d6e9f  lea rdi, [rsp]
00007e55d47d6ea3  mov esi, 0x00
00007e55d47d6ea8  mov rax, 0x55D0734A4530
00007e55d47d6eb2  call rax
00007e55d47d6eb4  movaps xmm3, [rsp]
00007e55d47d6eb8  add rsp, 0x30
00007e55d47d6ebc  vmovaps xmm0, [rsp]
00007e55d47d6ec1  vmovaps xmm1, [rsp+0x10]
00007e55d47d6ec7  vmovaps xmm2, [rsp+0x20]
00007e55d47d6ecd  vmovaps xmm4, [rsp+0x30]
00007e55d47d6ed3  vmovaps xmm5, [rsp+0x40]
00007e55d47d6ed9  vmovaps xmm6, [rsp+0x50]
00007e55d47d6edf  vmovaps xmm7, [rsp+0x60]
00007e55d47d6ee5  vmovaps xmm8, [rsp+0x70]
00007e55d47d6eeb  vmovaps xmm9, [rsp+0x80]
00007e55d47d6ef4  vmovaps xmm10, [rsp+0x90]
00007e55d47d6efd  vmovaps xmm11, [rsp+0xA0]
00007e55d47d6f06  vmovaps xmm12, [rsp+0xB0]
00007e55d47d6f0f  vmovaps xmm13, [rsp+0xC0]
00007e55d47d6f18  vmovaps xmm14, [rsp+0xD0]
00007e55d47d6f21  vmovaps xmm15, [rsp+0xE0]
00007e55d47d6f2a  add rsp, 0xF0
00007e55d47d6f31  pop r11
00007e55d47d6f33  pop r10
00007e55d47d6f35  pop r9
00007e55d47d6f37  pop r8
00007e55d47d6f39  pop rsi
00007e55d47d6f3a  pop rdi
00007e55d47d6f3b  pop rdx
00007e55d47d6f3c  pop rcx
00007e55d47d6f3d  pop rax
00007e55d47d6f3e  add rsp, 0x08
00007e55d47d6f42  jmp 0x00007E55D47D5A88
00007e55d47d6f47  sub rsp, 0x08
00007e55d47d6f4b  push rax
00007e55d47d6f4c  push rcx
00007e55d47d6f4d  push rdx
00007e55d47d6f4e  push rdi
00007e55d47d6f4f  push rsi
00007e55d47d6f50  push r8
00007e55d47d6f52  push r9
00007e55d47d6f54  push r10
00007e55d47d6f56  push r11
00007e55d47d6f58  sub rsp, 0xF0
00007e55d47d6f5f  vmovaps [rsp], xmm0
00007e55d47d6f64  vmovaps [rsp+0x10], xmm1
00007e55d47d6f6a  vmovaps [rsp+0x20], xmm2
00007e55d47d6f70  vmovaps [rsp+0x30], xmm3
00007e55d47d6f76  vmovaps [rsp+0x40], xmm4
00007e55d47d6f7c  vmovaps [rsp+0x50], xmm6
00007e55d47d6f82  vmovaps [rsp+0x60], xmm7
00007e55d47d6f88  vmovaps [rsp+0x70], xmm8
00007e55d47d6f8e  vmovaps [rsp+0x80], xmm9
00007e55d47d6f97  vmovaps [rsp+0x90], xmm10
00007e55d47d6fa0  vmovaps [rsp+0xA0], xmm11
00007e55d47d6fa9  vmovaps [rsp+0xB0], xmm12
00007e55d47d6fb2  vmovaps [rsp+0xC0], xmm13
00007e55d47d6fbb  vmovaps [rsp+0xD0], xmm14
00007e55d47d6fc4  vmovaps [rsp+0xE0], xmm15
00007e55d47d6fcd  sub rsp, 0x30
00007e55d47d6fd1  movaps [rsp], xmm5
00007e55d47d6fd5  movaps [rsp+0x10], xmm8
00007e55d47d6fdb  movaps [rsp+0x20], xmm15
00007e55d47d6fe1  lea rdi, [rsp]
00007e55d47d6fe5  mov esi, 0x00
00007e55d47d6fea  mov rax, 0x55D0734A4530
00007e55d47d6ff4  call rax
00007e55d47d6ff6  movaps xmm5, [rsp]
00007e55d47d6ffa  add rsp, 0x30
00007e55d47d6ffe  vmovaps xmm0, [rsp]
00007e55d47d7003  vmovaps xmm1, [rsp+0x10]
00007e55d47d7009  vmovaps xmm2, [rsp+0x20]
00007e55d47d700f  vmovaps xmm3, [rsp+0x30]
00007e55d47d7015  vmovaps xmm4, [rsp+0x40]
00007e55d47d701b  vmovaps xmm6, [rsp+0x50]
00007e55d47d7021  vmovaps xmm7, [rsp+0x60]
00007e55d47d7027  vmovaps xmm8, [rsp+0x70]
00007e55d47d702d  vmovaps xmm9, [rsp+0x80]
00007e55d47d7036  vmovaps xmm10, [rsp+0x90]
00007e55d47d703f  vmovaps xmm11, [rsp+0xA0]
00007e55d47d7048  vmovaps xmm12, [rsp+0xB0]
00007e55d47d7051  vmovaps xmm13, [rsp+0xC0]
00007e55d47d705a  vmovaps xmm14, [rsp+0xD0]
00007e55d47d7063  vmovaps xmm15, [rsp+0xE0]
00007e55d47d706c  add rsp, 0xF0
00007e55d47d7073  pop r11
00007e55d47d7075  pop r10
00007e55d47d7077  pop r9
00007e55d47d7079  pop r8
00007e55d47d707b  pop rsi
00007e55d47d707c  pop rdi
00007e55d47d707d  pop rdx
00007e55d47d707e  pop rcx
00007e55d47d707f  pop rax
00007e55d47d7080  add rsp, 0x08
00007e55d47d7084  jmp 0x00007E55D47D5AC0
00007e55d47d7089  sub rsp, 0x08
00007e55d47d708d  push rax
00007e55d47d708e  push rcx
00007e55d47d708f  push rdx
00007e55d47d7090  push rdi
00007e55d47d7091  push rsi
00007e55d47d7092  push r8
00007e55d47d7094  push r9
00007e55d47d7096  push r10
00007e55d47d7098  push r11
00007e55d47d709a  sub rsp, 0xF0
00007e55d47d70a1  vmovaps [rsp], xmm0
00007e55d47d70a6  vmovaps [rsp+0x10], xmm1
00007e55d47d70ac  vmovaps [rsp+0x20], xmm2
00007e55d47d70b2  vmovaps [rsp+0x30], xmm3
00007e55d47d70b8  vmovaps [rsp+0x40], xmm5
00007e55d47d70be  vmovaps [rsp+0x50], xmm6
00007e55d47d70c4  vmovaps [rsp+0x60], xmm7
00007e55d47d70ca  vmovaps [rsp+0x70], xmm8
00007e55d47d70d0  vmovaps [rsp+0x80], xmm9
00007e55d47d70d9  vmovaps [rsp+0x90], xmm10
00007e55d47d70e2  vmovaps [rsp+0xA0], xmm11
00007e55d47d70eb  vmovaps [rsp+0xB0], xmm12
00007e55d47d70f4  vmovaps [rsp+0xC0], xmm13
00007e55d47d70fd  vmovaps [rsp+0xD0], xmm14
00007e55d47d7106  vmovaps [rsp+0xE0], xmm15
00007e55d47d710f  sub rsp, 0x30
00007e55d47d7113  movaps [rsp], xmm4
00007e55d47d7117  movaps [rsp+0x10], xmm9
00007e55d47d711d  movaps [rsp+0x20], xmm8
00007e55d47d7123  lea rdi, [rsp]
00007e55d47d7127  mov esi, 0x00
00007e55d47d712c  mov rax, 0x55D0734A4530
00007e55d47d7136  call rax
00007e55d47d7138  movaps xmm4, [rsp]
00007e55d47d713c  add rsp, 0x30
00007e55d47d7140  vmovaps xmm0, [rsp]
00007e55d47d7145  vmovaps xmm1, [rsp+0x10]
00007e55d47d714b  vmovaps xmm2, [rsp+0x20]
00007e55d47d7151  vmovaps xmm3, [rsp+0x30]
00007e55d47d7157  vmovaps xmm5, [rsp+0x40]
00007e55d47d715d  vmovaps xmm6, [rsp+0x50]
00007e55d47d7163  vmovaps xmm7, [rsp+0x60]
00007e55d47d7169  vmovaps xmm8, [rsp+0x70]
00007e55d47d716f  vmovaps xmm9, [rsp+0x80]
00007e55d47d7178  vmovaps xmm10, [rsp+0x90]
00007e55d47d7181  vmovaps xmm11, [rsp+0xA0]
00007e55d47d718a  vmovaps xmm12, [rsp+0xB0]
00007e55d47d7193  vmovaps xmm13, [rsp+0xC0]
00007e55d47d719c  vmovaps xmm14, [rsp+0xD0]
00007e55d47d71a5  vmovaps xmm15, [rsp+0xE0]
00007e55d47d71ae  add rsp, 0xF0
00007e55d47d71b5  pop r11
00007e55d47d71b7  pop r10
00007e55d47d71b9  pop r9
00007e55d47d71bb  pop r8
00007e55d47d71bd  pop rsi
00007e55d47d71be  pop rdi
00007e55d47d71bf  pop rdx
00007e55d47d71c0  pop rcx
00007e55d47d71c1  pop rax
00007e55d47d71c2  add rsp, 0x08
00007e55d47d71c6  jmp 0x00007E55D47D5AE1
00007e55d47d71cb  sub rsp, 0x08
00007e55d47d71cf  push rax
00007e55d47d71d0  push rcx
00007e55d47d71d1  push rdx
00007e55d47d71d2  push rdi
00007e55d47d71d3  push rsi
00007e55d47d71d4  push r8
00007e55d47d71d6  push r9
00007e55d47d71d8  push r10
00007e55d47d71da  push r11
00007e55d47d71dc  sub rsp, 0xF0
00007e55d47d71e3  vmovaps [rsp], xmm0
00007e55d47d71e8  vmovaps [rsp+0x10], xmm1
00007e55d47d71ee  vmovaps [rsp+0x20], xmm2
00007e55d47d71f4  vmovaps [rsp+0x30], xmm3
00007e55d47d71fa  vmovaps [rsp+0x40], xmm4
00007e55d47d7200  vmovaps [rsp+0x50], xmm5
00007e55d47d7206  vmovaps [rsp+0x60], xmm6
00007e55d47d720c  vmovaps [rsp+0x70], xmm7
00007e55d47d7212  vmovaps [rsp+0x80], xmm8
00007e55d47d721b  vmovaps [rsp+0x90], xmm10
00007e55d47d7224  vmovaps [rsp+0xA0], xmm11
00007e55d47d722d  vmovaps [rsp+0xB0], xmm12
00007e55d47d7236  vmovaps [rsp+0xC0], xmm13
00007e55d47d723f  vmovaps [rsp+0xD0], xmm14
00007e55d47d7248  vmovaps [rsp+0xE0], xmm15
00007e55d47d7251  sub rsp, 0x30
00007e55d47d7255  movaps [rsp], xmm9
00007e55d47d725a  movaps [rsp+0x10], xmm10
00007e55d47d7260  movaps [rsp+0x20], xmm8
00007e55d47d7266  lea rdi, [rsp]
00007e55d47d726a  mov esi, 0x00
00007e55d47d726f  mov rax, 0x55D0734A4530
00007e55d47d7279  call rax
00007e55d47d727b  movaps xmm9, [rsp]
00007e55d47d7280  add rsp, 0x30
00007e55d47d7284  vmovaps xmm0, [rsp]
00007e55d47d7289  vmovaps xmm1, [rsp+0x10]
00007e55d47d728f  vmovaps xmm2, [rsp+0x20]
00007e55d47d7295  vmovaps xmm3, [rsp+0x30]
00007e55d47d729b  vmovaps xmm4, [rsp+0x40]
00007e55d47d72a1  vmovaps xmm5, [rsp+0x50]
00007e55d47d72a7  vmovaps xmm6, [rsp+0x60]
00007e55d47d72ad  vmovaps xmm7, [rsp+0x70]
00007e55d47d72b3  vmovaps xmm8, [rsp+0x80]
00007e55d47d72bc  vmovaps xmm10, [rsp+0x90]
00007e55d47d72c5  vmovaps xmm11, [rsp+0xA0]
00007e55d47d72ce  vmovaps xmm12, [rsp+0xB0]
00007e55d47d72d7  vmovaps xmm13, [rsp+0xC0]
00007e55d47d72e0  vmovaps xmm14, [rsp+0xD0]
00007e55d47d72e9  vmovaps xmm15, [rsp+0xE0]
00007e55d47d72f2  add rsp, 0xF0
00007e55d47d72f9  pop r11
00007e55d47d72fb  pop r10
00007e55d47d72fd  pop r9
00007e55d47d72ff  pop r8
00007e55d47d7301  pop rsi
00007e55d47d7302  pop rdi
00007e55d47d7303  pop rdx
00007e55d47d7304  pop rcx
00007e55d47d7305  pop rax
00007e55d47d7306  add rsp, 0x08
00007e55d47d730a  jmp 0x00007E55D47D5AFB
00007e55d47d730f  call 0x00007E55D46D64F0
00007e55d47d7314  jmp 0x00007E55D47D5C15
00007e55d47d7319  call 0x00007E55D46D64F0
00007e55d47d731e  jmp 0x00007E55D47D5C2B
00007e55d47d7323  sub rsp, 0x08
00007e55d47d7327  push rax
00007e55d47d7328  push rcx
00007e55d47d7329  push rdx
00007e55d47d732a  push rdi
00007e55d47d732b  push rsi
00007e55d47d732c  push r8
00007e55d47d732e  push r9
00007e55d47d7330  push r10
00007e55d47d7332  push r11
00007e55d47d7334  sub rsp, 0xF0
00007e55d47d733b  vmovaps [rsp], xmm0
00007e55d47d7340  vmovaps [rsp+0x10], xmm2
00007e55d47d7346  vmovaps [rsp+0x20], xmm3
00007e55d47d734c  vmovaps [rsp+0x30], xmm4
00007e55d47d7352  vmovaps [rsp+0x40], xmm5
00007e55d47d7358  vmovaps [rsp+0x50], xmm6
00007e55d47d735e  vmovaps [rsp+0x60], xmm7
00007e55d47d7364  vmovaps [rsp+0x70], xmm8
00007e55d47d736a  vmovaps [rsp+0x80], xmm9
00007e55d47d7373  vmovaps [rsp+0x90], xmm10
00007e55d47d737c  vmovaps [rsp+0xA0], xmm11
00007e55d47d7385  vmovaps [rsp+0xB0], xmm12
00007e55d47d738e  vmovaps [rsp+0xC0], xmm13
00007e55d47d7397  vmovaps [rsp+0xD0], xmm14
00007e55d47d73a0  vmovaps [rsp+0xE0], xmm15
00007e55d47d73a9  sub rsp, 0x30
00007e55d47d73ad  movaps [rsp], xmm1
00007e55d47d73b1  movaps [rsp+0x10], xmm6
00007e55d47d73b6  movaps [rsp+0x20], xmm15
00007e55d47d73bc  lea rdi, [rsp]
00007e55d47d73c0  mov esi, 0x00
00007e55d47d73c5  mov rax, 0x55D0734A4530
00007e55d47d73cf  call rax
00007e55d47d73d1  movaps xmm1, [rsp]
00007e55d47d73d5  add rsp, 0x30
00007e55d47d73d9  vmovaps xmm0, [rsp]
00007e55d47d73de  vmovaps xmm2, [rsp+0x10]
00007e55d47d73e4  vmovaps xmm3, [rsp+0x20]
00007e55d47d73ea  vmovaps xmm4, [rsp+0x30]
00007e55d47d73f0  vmovaps xmm5, [rsp+0x40]
00007e55d47d73f6  vmovaps xmm6, [rsp+0x50]
00007e55d47d73fc  vmovaps xmm7, [rsp+0x60]
00007e55d47d7402  vmovaps xmm8, [rsp+0x70]
00007e55d47d7408  vmovaps xmm9, [rsp+0x80]
00007e55d47d7411  vmovaps xmm10, [rsp+0x90]
00007e55d47d741a  vmovaps xmm11, [rsp+0xA0]
00007e55d47d7423  vmovaps xmm12, [rsp+0xB0]
00007e55d47d742c  vmovaps xmm13, [rsp+0xC0]
00007e55d47d7435  vmovaps xmm14, [rsp+0xD0]
00007e55d47d743e  vmovaps xmm15, [rsp+0xE0]
00007e55d47d7447  add rsp, 0xF0
00007e55d47d744e  pop r11
00007e55d47d7450  pop r10
00007e55d47d7452  pop r9
00007e55d47d7454  pop r8
00007e55d47d7456  pop rsi
00007e55d47d7457  pop rdi
00007e55d47d7458  pop rdx
00007e55d47d7459  pop rcx
00007e55d47d745a  pop rax
00007e55d47d745b  add rsp, 0x08
00007e55d47d745f  jmp 0x00007E55D47D5C68
00007e55d47d7464  call 0x00007E55D46E5820
00007e55d47d7469  jmp 0x00007E55D47D5C75
00007e55d47d746e  sub rsp, 0x08
00007e55d47d7472  push rax
00007e55d47d7473  push rcx
00007e55d47d7474  push rdx
00007e55d47d7475  push rdi
00007e55d47d7476  push rsi
00007e55d47d7477  push r8
00007e55d47d7479  push r9
00007e55d47d747b  push r10
00007e55d47d747d  push r11
00007e55d47d747f  sub rsp, 0xF0
00007e55d47d7486  vmovaps [rsp], xmm0
00007e55d47d748b  vmovaps [rsp+0x10], xmm1
00007e55d47d7491  vmovaps [rsp+0x20], xmm2
00007e55d47d7497  vmovaps [rsp+0x30], xmm3
00007e55d47d749d  vmovaps [rsp+0x40], xmm4
00007e55d47d74a3  vmovaps [rsp+0x50], xmm5
00007e55d47d74a9  vmovaps [rsp+0x60], xmm6
00007e55d47d74af  vmovaps [rsp+0x70], xmm7
00007e55d47d74b5  vmovaps [rsp+0x80], xmm8
00007e55d47d74be  vmovaps [rsp+0x90], xmm9
00007e55d47d74c7  vmovaps [rsp+0xA0], xmm10
00007e55d47d74d0  vmovaps [rsp+0xB0], xmm11
00007e55d47d74d9  vmovaps [rsp+0xC0], xmm12
00007e55d47d74e2  vmovaps [rsp+0xD0], xmm13
00007e55d47d74eb  vmovaps [rsp+0xE0], xmm15
00007e55d47d74f4  sub rsp, 0x30
00007e55d47d74f8  movaps [rsp], xmm14
00007e55d47d74fd  movaps [rsp+0x10], xmm4
00007e55d47d7502  movaps [rsp+0x20], xmm3
00007e55d47d7507  lea rdi, [rsp]
00007e55d47d750b  mov esi, 0x00
00007e55d47d7510  mov rax, 0x55D0734A4530
00007e55d47d751a  call rax
00007e55d47d751c  movaps xmm14, [rsp]
00007e55d47d7521  add rsp, 0x30
00007e55d47d7525  vmovaps xmm0, [rsp]
00007e55d47d752a  vmovaps xmm1, [rsp+0x10]
00007e55d47d7530  vmovaps xmm2, [rsp+0x20]
00007e55d47d7536  vmovaps xmm3, [rsp+0x30]
00007e55d47d753c  vmovaps xmm4, [rsp+0x40]
00007e55d47d7542  vmovaps xmm5, [rsp+0x50]
00007e55d47d7548  vmovaps xmm6, [rsp+0x60]
00007e55d47d754e  vmovaps xmm7, [rsp+0x70]
00007e55d47d7554  vmovaps xmm8, [rsp+0x80]
00007e55d47d755d  vmovaps xmm9, [rsp+0x90]
00007e55d47d7566  vmovaps xmm10, [rsp+0xA0]
00007e55d47d756f  vmovaps xmm11, [rsp+0xB0]
00007e55d47d7578  vmovaps xmm12, [rsp+0xC0]
00007e55d47d7581  vmovaps xmm13, [rsp+0xD0]
00007e55d47d758a  vmovaps xmm15, [rsp+0xE0]
00007e55d47d7593  add rsp, 0xF0
00007e55d47d759a  pop r11
00007e55d47d759c  pop r10
00007e55d47d759e  pop r9
00007e55d47d75a0  pop r8
00007e55d47d75a2  pop rsi
00007e55d47d75a3  pop rdi
00007e55d47d75a4  pop rdx
00007e55d47d75a5  pop rcx
00007e55d47d75a6  pop rax
00007e55d47d75a7  add rsp, 0x08
00007e55d47d75ab  jmp 0x00007E55D47D5C8F
00007e55d47d75b0  sub rsp, 0x08
00007e55d47d75b4  push rax
00007e55d47d75b5  push rcx
00007e55d47d75b6  push rdx
00007e55d47d75b7  push rdi
00007e55d47d75b8  push rsi
00007e55d47d75b9  push r8
00007e55d47d75bb  push r9
00007e55d47d75bd  push r10
00007e55d47d75bf  push r11
00007e55d47d75c1  sub rsp, 0xF0
00007e55d47d75c8  vmovaps [rsp], xmm0
00007e55d47d75cd  vmovaps [rsp+0x10], xmm1
00007e55d47d75d3  vmovaps [rsp+0x20], xmm2
00007e55d47d75d9  vmovaps [rsp+0x30], xmm3
00007e55d47d75df  vmovaps [rsp+0x40], xmm4
00007e55d47d75e5  vmovaps [rsp+0x50], xmm5
00007e55d47d75eb  vmovaps [rsp+0x60], xmm7
00007e55d47d75f1  vmovaps [rsp+0x70], xmm8
00007e55d47d75f7  vmovaps [rsp+0x80], xmm9
00007e55d47d7600  vmovaps [rsp+0x90], xmm10
00007e55d47d7609  vmovaps [rsp+0xA0], xmm11
00007e55d47d7612  vmovaps [rsp+0xB0], xmm12
00007e55d47d761b  vmovaps [rsp+0xC0], xmm13
00007e55d47d7624  vmovaps [rsp+0xD0], xmm14
00007e55d47d762d  vmovaps [rsp+0xE0], xmm15
00007e55d47d7636  sub rsp, 0x30
00007e55d47d763a  movaps [rsp], xmm6
00007e55d47d763e  movaps [rsp+0x10], xmm9
00007e55d47d7644  movaps [rsp+0x20], xmm7
00007e55d47d7649  lea rdi, [rsp]
00007e55d47d764d  mov esi, 0x00
00007e55d47d7652  mov rax, 0x55D0734A4530
00007e55d47d765c  call rax
00007e55d47d765e  movaps xmm6, [rsp]
00007e55d47d7662  add rsp, 0x30
00007e55d47d7666  vmovaps xmm0, [rsp]
00007e55d47d766b  vmovaps xmm1, [rsp+0x10]
00007e55d47d7671  vmovaps xmm2, [rsp+0x20]
00007e55d47d7677  vmovaps xmm3, [rsp+0x30]
00007e55d47d767d  vmovaps xmm4, [rsp+0x40]
00007e55d47d7683  vmovaps xmm5, [rsp+0x50]
00007e55d47d7689  vmovaps xmm7, [rsp+0x60]
00007e55d47d768f  vmovaps xmm8, [rsp+0x70]
00007e55d47d7695  vmovaps xmm9, [rsp+0x80]
00007e55d47d769e  vmovaps xmm10, [rsp+0x90]
00007e55d47d76a7  vmovaps xmm11, [rsp+0xA0]
00007e55d47d76b0  vmovaps xmm12, [rsp+0xB0]
00007e55d47d76b9  vmovaps xmm13, [rsp+0xC0]
00007e55d47d76c2  vmovaps xmm14, [rsp+0xD0]
00007e55d47d76cb  vmovaps xmm15, [rsp+0xE0]
00007e55d47d76d4  add rsp, 0xF0
00007e55d47d76db  pop r11
00007e55d47d76dd  pop r10
00007e55d47d76df  pop r9
00007e55d47d76e1  pop r8
00007e55d47d76e3  pop rsi
00007e55d47d76e4  pop rdi
00007e55d47d76e5  pop rdx
00007e55d47d76e6  pop rcx
00007e55d47d76e7  pop rax
00007e55d47d76e8  add rsp, 0x08
00007e55d47d76ec  jmp 0x00007E55D47D5CA7
00007e55d47d76f1  sub rsp, 0x08
00007e55d47d76f5  push rax
00007e55d47d76f6  push rcx
00007e55d47d76f7  push rdx
00007e55d47d76f8  push rdi
00007e55d47d76f9  push rsi
00007e55d47d76fa  push r8
00007e55d47d76fc  push r9
00007e55d47d76fe  push r10
00007e55d47d7700  push r11
00007e55d47d7702  sub rsp, 0xF0
00007e55d47d7709  vmovaps [rsp], xmm0
00007e55d47d770e  vmovaps [rsp+0x10], xmm1
00007e55d47d7714  vmovaps [rsp+0x20], xmm2
00007e55d47d771a  vmovaps [rsp+0x30], xmm3
00007e55d47d7720  vmovaps [rsp+0x40], xmm4
00007e55d47d7726  vmovaps [rsp+0x50], xmm5
00007e55d47d772c  vmovaps [rsp+0x60], xmm6
00007e55d47d7732  vmovaps [rsp+0x70], xmm8
00007e55d47d7738  vmovaps [rsp+0x80], xmm9
00007e55d47d7741  vmovaps [rsp+0x90], xmm10
00007e55d47d774a  vmovaps [rsp+0xA0], xmm11
00007e55d47d7753  vmovaps [rsp+0xB0], xmm12
00007e55d47d775c  vmovaps [rsp+0xC0], xmm13
00007e55d47d7765  vmovaps [rsp+0xD0], xmm14
00007e55d47d776e  vmovaps [rsp+0xE0], xmm15
00007e55d47d7777  sub rsp, 0x30
00007e55d47d777b  movaps [rsp], xmm7
00007e55d47d777f  movaps [rsp+0x10], xmm4
00007e55d47d7784  movaps [rsp+0x20], xmm9
00007e55d47d778a  lea rdi, [rsp]
00007e55d47d778e  mov esi, 0x00
00007e55d47d7793  mov rax, 0x55D0734A4530
00007e55d47d779d  call rax
00007e55d47d779f  movaps xmm7, [rsp]
00007e55d47d77a3  add rsp, 0x30
00007e55d47d77a7  vmovaps xmm0, [rsp]
00007e55d47d77ac  vmovaps xmm1, [rsp+0x10]
00007e55d47d77b2  vmovaps xmm2, [rsp+0x20]
00007e55d47d77b8  vmovaps xmm3, [rsp+0x30]
00007e55d47d77be  vmovaps xmm4, [rsp+0x40]
00007e55d47d77c4  vmovaps xmm5, [rsp+0x50]
00007e55d47d77ca  vmovaps xmm6, [rsp+0x60]
00007e55d47d77d0  vmovaps xmm8, [rsp+0x70]
00007e55d47d77d6  vmovaps xmm9, [rsp+0x80]
00007e55d47d77df  vmovaps xmm10, [rsp+0x90]
00007e55d47d77e8  vmovaps xmm11, [rsp+0xA0]
00007e55d47d77f1  vmovaps xmm12, [rsp+0xB0]
00007e55d47d77fa  vmovaps xmm13, [rsp+0xC0]
00007e55d47d7803  vmovaps xmm14, [rsp+0xD0]
00007e55d47d780c  vmovaps xmm15, [rsp+0xE0]
00007e55d47d7815  add rsp, 0xF0
00007e55d47d781c  pop r11
00007e55d47d781e  pop r10
00007e55d47d7820  pop r9
00007e55d47d7822  pop r8
00007e55d47d7824  pop rsi
00007e55d47d7825  pop rdi
00007e55d47d7826  pop rdx
00007e55d47d7827  pop rcx
00007e55d47d7828  pop rax
00007e55d47d7829  add rsp, 0x08
00007e55d47d782d  jmp 0x00007E55D47D5CD4
00007e55d47d7832  sub rsp, 0x08
00007e55d47d7836  push rax
00007e55d47d7837  push rcx
00007e55d47d7838  push rdx
00007e55d47d7839  push rdi
00007e55d47d783a  push rsi
00007e55d47d783b  push r8
00007e55d47d783d  push r9
00007e55d47d783f  push r10
00007e55d47d7841  push r11
00007e55d47d7843  sub rsp, 0xF0
00007e55d47d784a  vmovaps [rsp], xmm0
00007e55d47d784f  vmovaps [rsp+0x10], xmm1
00007e55d47d7855  vmovaps [rsp+0x20], xmm2
00007e55d47d785b  vmovaps [rsp+0x30], xmm3
00007e55d47d7861  vmovaps [rsp+0x40], xmm5
00007e55d47d7867  vmovaps [rsp+0x50], xmm6
00007e55d47d786d  vmovaps [rsp+0x60], xmm7
00007e55d47d7873  vmovaps [rsp+0x70], xmm8
00007e55d47d7879  vmovaps [rsp+0x80], xmm9
00007e55d47d7882  vmovaps [rsp+0x90], xmm10
00007e55d47d788b  vmovaps [rsp+0xA0], xmm11
00007e55d47d7894  vmovaps [rsp+0xB0], xmm12
00007e55d47d789d  vmovaps [rsp+0xC0], xmm13
00007e55d47d78a6  vmovaps [rsp+0xD0], xmm14
00007e55d47d78af  vmovaps [rsp+0xE0], xmm15
00007e55d47d78b8  sub rsp, 0x30
00007e55d47d78bc  movaps [rsp], xmm4
00007e55d47d78c0  movaps [rsp+0x10], xmm15
00007e55d47d78c6  movaps [rsp+0x20], xmm9
00007e55d47d78cc  lea rdi, [rsp]
00007e55d47d78d0  mov esi, 0x00
00007e55d47d78d5  mov rax, 0x55D0734A4530
00007e55d47d78df  call rax
00007e55d47d78e1  movaps xmm4, [rsp]
00007e55d47d78e5  add rsp, 0x30
00007e55d47d78e9  vmovaps xmm0, [rsp]
00007e55d47d78ee  vmovaps xmm1, [rsp+0x10]
00007e55d47d78f4  vmovaps xmm2, [rsp+0x20]
00007e55d47d78fa  vmovaps xmm3, [rsp+0x30]
00007e55d47d7900  vmovaps xmm5, [rsp+0x40]
00007e55d47d7906  vmovaps xmm6, [rsp+0x50]
00007e55d47d790c  vmovaps xmm7, [rsp+0x60]
00007e55d47d7912  vmovaps xmm8, [rsp+0x70]
00007e55d47d7918  vmovaps xmm9, [rsp+0x80]
00007e55d47d7921  vmovaps xmm10, [rsp+0x90]
00007e55d47d792a  vmovaps xmm11, [rsp+0xA0]
00007e55d47d7933  vmovaps xmm12, [rsp+0xB0]
00007e55d47d793c  vmovaps xmm13, [rsp+0xC0]
00007e55d47d7945  vmovaps xmm14, [rsp+0xD0]
00007e55d47d794e  vmovaps xmm15, [rsp+0xE0]
00007e55d47d7957  add rsp, 0xF0
00007e55d47d795e  pop r11
00007e55d47d7960  pop r10
00007e55d47d7962  pop r9
00007e55d47d7964  pop r8
00007e55d47d7966  pop rsi
00007e55d47d7967  pop rdi
00007e55d47d7968  pop rdx
00007e55d47d7969  pop rcx
00007e55d47d796a  pop rax
00007e55d47d796b  add rsp, 0x08
00007e55d47d796f  jmp 0x00007E55D47D5CF9
00007e55d47d7974  call 0x00007E55D46E5820
00007e55d47d7979  jmp 0x00007E55D47D5D06
00007e55d47d797e  sub rsp, 0x08
00007e55d47d7982  push rax
00007e55d47d7983  push rcx
00007e55d47d7984  push rdx
00007e55d47d7985  push rdi
00007e55d47d7986  push rsi
00007e55d47d7987  push r8
00007e55d47d7989  push r9
00007e55d47d798b  push r10
00007e55d47d798d  push r11
00007e55d47d798f  sub rsp, 0xF0
00007e55d47d7996  vmovaps [rsp], xmm0
00007e55d47d799b  vmovaps [rsp+0x10], xmm1
00007e55d47d79a1  vmovaps [rsp+0x20], xmm2
00007e55d47d79a7  vmovaps [rsp+0x30], xmm4
00007e55d47d79ad  vmovaps [rsp+0x40], xmm5
00007e55d47d79b3  vmovaps [rsp+0x50], xmm6
00007e55d47d79b9  vmovaps [rsp+0x60], xmm7
00007e55d47d79bf  vmovaps [rsp+0x70], xmm8
00007e55d47d79c5  vmovaps [rsp+0x80], xmm9
00007e55d47d79ce  vmovaps [rsp+0x90], xmm10
00007e55d47d79d7  vmovaps [rsp+0xA0], xmm11
00007e55d47d79e0  vmovaps [rsp+0xB0], xmm12
00007e55d47d79e9  vmovaps [rsp+0xC0], xmm13
00007e55d47d79f2  vmovaps [rsp+0xD0], xmm14
00007e55d47d79fb  vmovaps [rsp+0xE0], xmm15
00007e55d47d7a04  sub rsp, 0x30
00007e55d47d7a08  movaps [rsp], xmm3
00007e55d47d7a0c  movaps [rsp+0x10], xmm1
00007e55d47d7a11  movaps [rsp+0x20], xmm9
00007e55d47d7a17  lea rdi, [rsp]
00007e55d47d7a1b  mov esi, 0x00
00007e55d47d7a20  mov rax, 0x55D0734A4530
00007e55d47d7a2a  call rax
00007e55d47d7a2c  movaps xmm3, [rsp]
00007e55d47d7a30  add rsp, 0x30
00007e55d47d7a34  vmovaps xmm0, [rsp]
00007e55d47d7a39  vmovaps xmm1, [rsp+0x10]
00007e55d47d7a3f  vmovaps xmm2, [rsp+0x20]
00007e55d47d7a45  vmovaps xmm4, [rsp+0x30]
00007e55d47d7a4b  vmovaps xmm5, [rsp+0x40]
00007e55d47d7a51  vmovaps xmm6, [rsp+0x50]
00007e55d47d7a57  vmovaps xmm7, [rsp+0x60]
00007e55d47d7a5d  vmovaps xmm8, [rsp+0x70]
00007e55d47d7a63  vmovaps xmm9, [rsp+0x80]
00007e55d47d7a6c  vmovaps xmm10, [rsp+0x90]
00007e55d47d7a75  vmovaps xmm11, [rsp+0xA0]
00007e55d47d7a7e  vmovaps xmm12, [rsp+0xB0]
00007e55d47d7a87  vmovaps xmm13, [rsp+0xC0]
00007e55d47d7a90  vmovaps xmm14, [rsp+0xD0]
00007e55d47d7a99  vmovaps xmm15, [rsp+0xE0]
00007e55d47d7aa2  add rsp, 0xF0
00007e55d47d7aa9  pop r11
00007e55d47d7aab  pop r10
00007e55d47d7aad  pop r9
00007e55d47d7aaf  pop r8
00007e55d47d7ab1  pop rsi
00007e55d47d7ab2  pop rdi
00007e55d47d7ab3  pop rdx
00007e55d47d7ab4  pop rcx
00007e55d47d7ab5  pop rax
00007e55d47d7ab6  add rsp, 0x08
00007e55d47d7aba  jmp 0x00007E55D47D5D43
00007e55d47d7abf  sub rsp, 0x08
00007e55d47d7ac3  push rax
00007e55d47d7ac4  push rcx
00007e55d47d7ac5  push rdx
00007e55d47d7ac6  push rdi
00007e55d47d7ac7  push rsi
00007e55d47d7ac8  push r8
00007e55d47d7aca  push r9
00007e55d47d7acc  push r10
00007e55d47d7ace  push r11
00007e55d47d7ad0  sub rsp, 0xF0
00007e55d47d7ad7  vmovaps [rsp], xmm0
00007e55d47d7adc  vmovaps [rsp+0x10], xmm2
00007e55d47d7ae2  vmovaps [rsp+0x20], xmm3
00007e55d47d7ae8  vmovaps [rsp+0x30], xmm4
00007e55d47d7aee  vmovaps [rsp+0x40], xmm5
00007e55d47d7af4  vmovaps [rsp+0x50], xmm6
00007e55d47d7afa  vmovaps [rsp+0x60], xmm7
00007e55d47d7b00  vmovaps [rsp+0x70], xmm8
00007e55d47d7b06  vmovaps [rsp+0x80], xmm9
00007e55d47d7b0f  vmovaps [rsp+0x90], xmm10
00007e55d47d7b18  vmovaps [rsp+0xA0], xmm11
00007e55d47d7b21  vmovaps [rsp+0xB0], xmm12
00007e55d47d7b2a  vmovaps [rsp+0xC0], xmm13
00007e55d47d7b33  vmovaps [rsp+0xD0], xmm14
00007e55d47d7b3c  vmovaps [rsp+0xE0], xmm15
00007e55d47d7b45  sub rsp, 0x30
00007e55d47d7b49  movaps [rsp], xmm1
00007e55d47d7b4d  movaps [rsp+0x10], xmm15
00007e55d47d7b53  movaps [rsp+0x20], xmm9
00007e55d47d7b59  lea rdi, [rsp]
00007e55d47d7b5d  mov esi, 0x00
00007e55d47d7b62  mov rax, 0x55D0734A4530
00007e55d47d7b6c  call rax
00007e55d47d7b6e  movaps xmm1, [rsp]
00007e55d47d7b72  add rsp, 0x30
00007e55d47d7b76  vmovaps xmm0, [rsp]
00007e55d47d7b7b  vmovaps xmm2, [rsp+0x10]
00007e55d47d7b81  vmovaps xmm3, [rsp+0x20]
00007e55d47d7b87  vmovaps xmm4, [rsp+0x30]
00007e55d47d7b8d  vmovaps xmm5, [rsp+0x40]
00007e55d47d7b93  vmovaps xmm6, [rsp+0x50]
00007e55d47d7b99  vmovaps xmm7, [rsp+0x60]
00007e55d47d7b9f  vmovaps xmm8, [rsp+0x70]
00007e55d47d7ba5  vmovaps xmm9, [rsp+0x80]
00007e55d47d7bae  vmovaps xmm10, [rsp+0x90]
00007e55d47d7bb7  vmovaps xmm11, [rsp+0xA0]
00007e55d47d7bc0  vmovaps xmm12, [rsp+0xB0]
00007e55d47d7bc9  vmovaps xmm13, [rsp+0xC0]
00007e55d47d7bd2  vmovaps xmm14, [rsp+0xD0]
00007e55d47d7bdb  vmovaps xmm15, [rsp+0xE0]
00007e55d47d7be4  add rsp, 0xF0
00007e55d47d7beb  pop r11
00007e55d47d7bed  pop r10
00007e55d47d7bef  pop r9
00007e55d47d7bf1  pop r8
00007e55d47d7bf3  pop rsi
00007e55d47d7bf4  pop rdi
00007e55d47d7bf5  pop rdx
00007e55d47d7bf6  pop rcx
00007e55d47d7bf7  pop rax
00007e55d47d7bf8  add rsp, 0x08
00007e55d47d7bfc  jmp 0x00007E55D47D5DCB
00007e55d47d7c01  call 0x00007E55D46E5820
00007e55d47d7c06  jmp 0x00007E55D47D5DD8
00007e55d47d7c0b  sub rsp, 0x08
00007e55d47d7c0f  push rax
00007e55d47d7c10  push rcx
00007e55d47d7c11  push rdx
00007e55d47d7c12  push rdi
00007e55d47d7c13  push rsi
00007e55d47d7c14  push r8
00007e55d47d7c16  push r9
00007e55d47d7c18  push r10
00007e55d47d7c1a  push r11
00007e55d47d7c1c  sub rsp, 0xF0
00007e55d47d7c23  vmovaps [rsp], xmm0
00007e55d47d7c28  vmovaps [rsp+0x10], xmm2
00007e55d47d7c2e  vmovaps [rsp+0x20], xmm3
00007e55d47d7c34  vmovaps [rsp+0x30], xmm4
00007e55d47d7c3a  vmovaps [rsp+0x40], xmm5
00007e55d47d7c40  vmovaps [rsp+0x50], xmm6
00007e55d47d7c46  vmovaps [rsp+0x60], xmm7
00007e55d47d7c4c  vmovaps [rsp+0x70], xmm8
00007e55d47d7c52  vmovaps [rsp+0x80], xmm9
00007e55d47d7c5b  vmovaps [rsp+0x90], xmm10
00007e55d47d7c64  vmovaps [rsp+0xA0], xmm11
00007e55d47d7c6d  vmovaps [rsp+0xB0], xmm12
00007e55d47d7c76  vmovaps [rsp+0xC0], xmm13
00007e55d47d7c7f  vmovaps [rsp+0xD0], xmm14
00007e55d47d7c88  vmovaps [rsp+0xE0], xmm15
00007e55d47d7c91  sub rsp, 0x30
00007e55d47d7c95  movaps [rsp], xmm1
00007e55d47d7c99  movaps [rsp+0x10], xmm5
00007e55d47d7c9e  movaps [rsp+0x20], xmm7
00007e55d47d7ca3  lea rdi, [rsp]
00007e55d47d7ca7  mov esi, 0x00
00007e55d47d7cac  mov rax, 0x55D0734A4530
00007e55d47d7cb6  call rax
00007e55d47d7cb8  movaps xmm1, [rsp]
00007e55d47d7cbc  add rsp, 0x30
00007e55d47d7cc0  vmovaps xmm0, [rsp]
00007e55d47d7cc5  vmovaps xmm2, [rsp+0x10]
00007e55d47d7ccb  vmovaps xmm3, [rsp+0x20]
00007e55d47d7cd1  vmovaps xmm4, [rsp+0x30]
00007e55d47d7cd7  vmovaps xmm5, [rsp+0x40]
00007e55d47d7cdd  vmovaps xmm6, [rsp+0x50]
00007e55d47d7ce3  vmovaps xmm7, [rsp+0x60]
00007e55d47d7ce9  vmovaps xmm8, [rsp+0x70]
00007e55d47d7cef  vmovaps xmm9, [rsp+0x80]
00007e55d47d7cf8  vmovaps xmm10, [rsp+0x90]
00007e55d47d7d01  vmovaps xmm11, [rsp+0xA0]
00007e55d47d7d0a  vmovaps xmm12, [rsp+0xB0]
00007e55d47d7d13  vmovaps xmm13, [rsp+0xC0]
00007e55d47d7d1c  vmovaps xmm14, [rsp+0xD0]
00007e55d47d7d25  vmovaps xmm15, [rsp+0xE0]
00007e55d47d7d2e  add rsp, 0xF0
00007e55d47d7d35  pop r11
00007e55d47d7d37  pop r10
00007e55d47d7d39  pop r9
00007e55d47d7d3b  pop r8
00007e55d47d7d3d  pop rsi
00007e55d47d7d3e  pop rdi
00007e55d47d7d3f  pop rdx
00007e55d47d7d40  pop rcx
00007e55d47d7d41  pop rax
00007e55d47d7d42  add rsp, 0x08
00007e55d47d7d46  jmp 0x00007E55D47D5E7D
00007e55d47d7d4b  sub rsp, 0x08
00007e55d47d7d4f  push rax
00007e55d47d7d50  push rcx
00007e55d47d7d51  push rdx
00007e55d47d7d52  push rdi
00007e55d47d7d53  push rsi
00007e55d47d7d54  push r8
00007e55d47d7d56  push r9
00007e55d47d7d58  push r10
00007e55d47d7d5a  push r11
00007e55d47d7d5c  sub rsp, 0xF0
00007e55d47d7d63  vmovaps [rsp], xmm0
00007e55d47d7d68  vmovaps [rsp+0x10], xmm1
00007e55d47d7d6e  vmovaps [rsp+0x20], xmm2
00007e55d47d7d74  vmovaps [rsp+0x30], xmm3
00007e55d47d7d7a  vmovaps [rsp+0x40], xmm4
00007e55d47d7d80  vmovaps [rsp+0x50], xmm5
00007e55d47d7d86  vmovaps [rsp+0x60], xmm6
00007e55d47d7d8c  vmovaps [rsp+0x70], xmm8
00007e55d47d7d92  vmovaps [rsp+0x80], xmm9
00007e55d47d7d9b  vmovaps [rsp+0x90], xmm10
00007e55d47d7da4  vmovaps [rsp+0xA0], xmm11
00007e55d47d7dad  vmovaps [rsp+0xB0], xmm12
00007e55d47d7db6  vmovaps [rsp+0xC0], xmm13
00007e55d47d7dbf  vmovaps [rsp+0xD0], xmm14
00007e55d47d7dc8  vmovaps [rsp+0xE0], xmm15
00007e55d47d7dd1  sub rsp, 0x30
00007e55d47d7dd5  movaps [rsp], xmm7
00007e55d47d7dd9  movaps [rsp+0x10], xmm5
00007e55d47d7dde  movaps [rsp+0x20], xmm15
00007e55d47d7de4  lea rdi, [rsp]
00007e55d47d7de8  mov esi, 0x00
00007e55d47d7ded  mov rax, 0x55D0734A4530
00007e55d47d7df7  call rax
00007e55d47d7df9  movaps xmm7, [rsp]
00007e55d47d7dfd  add rsp, 0x30
00007e55d47d7e01  vmovaps xmm0, [rsp]
00007e55d47d7e06  vmovaps xmm1, [rsp+0x10]
00007e55d47d7e0c  vmovaps xmm2, [rsp+0x20]
00007e55d47d7e12  vmovaps xmm3, [rsp+0x30]
00007e55d47d7e18  vmovaps xmm4, [rsp+0x40]
00007e55d47d7e1e  vmovaps xmm5, [rsp+0x50]
00007e55d47d7e24  vmovaps xmm6, [rsp+0x60]
00007e55d47d7e2a  vmovaps xmm8, [rsp+0x70]
00007e55d47d7e30  vmovaps xmm9, [rsp+0x80]
00007e55d47d7e39  vmovaps xmm10, [rsp+0x90]
00007e55d47d7e42  vmovaps xmm11, [rsp+0xA0]
00007e55d47d7e4b  vmovaps xmm12, [rsp+0xB0]
00007e55d47d7e54  vmovaps xmm13, [rsp+0xC0]
00007e55d47d7e5d  vmovaps xmm14, [rsp+0xD0]
00007e55d47d7e66  vmovaps xmm15, [rsp+0xE0]
00007e55d47d7e6f  add rsp, 0xF0
00007e55d47d7e76  pop r11
00007e55d47d7e78  pop r10
00007e55d47d7e7a  pop r9
00007e55d47d7e7c  pop r8
00007e55d47d7e7e  pop rsi
00007e55d47d7e7f  pop rdi
00007e55d47d7e80  pop rdx
00007e55d47d7e81  pop rcx
00007e55d47d7e82  pop rax
00007e55d47d7e83  add rsp, 0x08
00007e55d47d7e87  jmp 0x00007E55D47D5EB3
00007e55d47d7e8c  call 0x00007E55D46D64F0
00007e55d47d7e91  jmp 0x00007E55D47D5EC0
00007e55d47d7e96  sub rsp, 0x08
00007e55d47d7e9a  push rax
00007e55d47d7e9b  push rcx
00007e55d47d7e9c  push rdx
00007e55d47d7e9d  push rdi
00007e55d47d7e9e  push rsi
00007e55d47d7e9f  push r8
00007e55d47d7ea1  push r9
00007e55d47d7ea3  push r10
00007e55d47d7ea5  push r11
00007e55d47d7ea7  sub rsp, 0xF0
00007e55d47d7eae  vmovaps [rsp], xmm0
00007e55d47d7eb3  vmovaps [rsp+0x10], xmm1
00007e55d47d7eb9  vmovaps [rsp+0x20], xmm2
00007e55d47d7ebf  vmovaps [rsp+0x30], xmm3
00007e55d47d7ec5  vmovaps [rsp+0x40], xmm4
00007e55d47d7ecb  vmovaps [rsp+0x50], xmm5
00007e55d47d7ed1  vmovaps [rsp+0x60], xmm6
00007e55d47d7ed7  vmovaps [rsp+0x70], xmm7
00007e55d47d7edd  vmovaps [rsp+0x80], xmm8
00007e55d47d7ee6  vmovaps [rsp+0x90], xmm9
00007e55d47d7eef  vmovaps [rsp+0xA0], xmm10
00007e55d47d7ef8  vmovaps [rsp+0xB0], xmm11
00007e55d47d7f01  vmovaps [rsp+0xC0], xmm12
00007e55d47d7f0a  vmovaps [rsp+0xD0], xmm13
00007e55d47d7f13  vmovaps [rsp+0xE0], xmm14
00007e55d47d7f1c  sub rsp, 0x30
00007e55d47d7f20  movaps [rsp], xmm15
00007e55d47d7f25  movaps [rsp+0x10], xmm5
00007e55d47d7f2a  movaps [rsp+0x20], xmm3
00007e55d47d7f2f  lea rdi, [rsp]
00007e55d47d7f33  mov esi, 0x00
00007e55d47d7f38  mov rax, 0x55D0734A4530
00007e55d47d7f42  call rax
00007e55d47d7f44  movaps xmm15, [rsp]
00007e55d47d7f49  add rsp, 0x30
00007e55d47d7f4d  vmovaps xmm0, [rsp]
00007e55d47d7f52  vmovaps xmm1, [rsp+0x10]
00007e55d47d7f58  vmovaps xmm2, [rsp+0x20]
00007e55d47d7f5e  vmovaps xmm3, [rsp+0x30]
00007e55d47d7f64  vmovaps xmm4, [rsp+0x40]
00007e55d47d7f6a  vmovaps xmm5, [rsp+0x50]
00007e55d47d7f70  vmovaps xmm6, [rsp+0x60]
00007e55d47d7f76  vmovaps xmm7, [rsp+0x70]
00007e55d47d7f7c  vmovaps xmm8, [rsp+0x80]
00007e55d47d7f85  vmovaps xmm9, [rsp+0x90]
00007e55d47d7f8e  vmovaps xmm10, [rsp+0xA0]
00007e55d47d7f97  vmovaps xmm11, [rsp+0xB0]
00007e55d47d7fa0  vmovaps xmm12, [rsp+0xC0]
00007e55d47d7fa9  vmovaps xmm13, [rsp+0xD0]
00007e55d47d7fb2  vmovaps xmm14, [rsp+0xE0]
00007e55d47d7fbb  add rsp, 0xF0
00007e55d47d7fc2  pop r11
00007e55d47d7fc4  pop r10
00007e55d47d7fc6  pop r9
00007e55d47d7fc8  pop r8
00007e55d47d7fca  pop rsi
00007e55d47d7fcb  pop rdi
00007e55d47d7fcc  pop rdx
00007e55d47d7fcd  pop rcx
00007e55d47d7fce  pop rax
00007e55d47d7fcf  add rsp, 0x08
00007e55d47d7fd3  jmp 0x00007E55D47D5EE6
00007e55d47d7fd8  sub rsp, 0x08
00007e55d47d7fdc  push rax
00007e55d47d7fdd  push rcx
00007e55d47d7fde  push rdx
00007e55d47d7fdf  push rdi
00007e55d47d7fe0  push rsi
00007e55d47d7fe1  push r8
00007e55d47d7fe3  push r9
00007e55d47d7fe5  push r10
00007e55d47d7fe7  push r11
00007e55d47d7fe9  sub rsp, 0xF0
00007e55d47d7ff0  vmovaps [rsp], xmm0
00007e55d47d7ff5  vmovaps [rsp+0x10], xmm2
00007e55d47d7ffb  vmovaps [rsp+0x20], xmm3
00007e55d47d8001  vmovaps [rsp+0x30], xmm4
00007e55d47d8007  vmovaps [rsp+0x40], xmm5
00007e55d47d800d  vmovaps [rsp+0x50], xmm6
00007e55d47d8013  vmovaps [rsp+0x60], xmm7
00007e55d47d8019  vmovaps [rsp+0x70], xmm8
00007e55d47d801f  vmovaps [rsp+0x80], xmm9
00007e55d47d8028  vmovaps [rsp+0x90], xmm10
00007e55d47d8031  vmovaps [rsp+0xA0], xmm11
00007e55d47d803a  vmovaps [rsp+0xB0], xmm12
00007e55d47d8043  vmovaps [rsp+0xC0], xmm13
00007e55d47d804c  vmovaps [rsp+0xD0], xmm14
00007e55d47d8055  vmovaps [rsp+0xE0], xmm15
00007e55d47d805e  sub rsp, 0x30
00007e55d47d8062  movaps [rsp], xmm1
00007e55d47d8066  movaps [rsp+0x10], xmm5
00007e55d47d806b  movaps [rsp+0x20], xmm4
00007e55d47d8070  lea rdi, [rsp]
00007e55d47d8074  mov esi, 0x00
00007e55d47d8079  mov rax, 0x55D0734A4530
00007e55d47d8083  call rax
00007e55d47d8085  movaps xmm1, [rsp]
00007e55d47d8089  add rsp, 0x30
00007e55d47d808d  vmovaps xmm0, [rsp]
00007e55d47d8092  vmovaps xmm2, [rsp+0x10]
00007e55d47d8098  vmovaps xmm3, [rsp+0x20]
00007e55d47d809e  vmovaps xmm4, [rsp+0x30]
00007e55d47d80a4  vmovaps xmm5, [rsp+0x40]
00007e55d47d80aa  vmovaps xmm6, [rsp+0x50]
00007e55d47d80b0  vmovaps xmm7, [rsp+0x60]
00007e55d47d80b6  vmovaps xmm8, [rsp+0x70]
00007e55d47d80bc  vmovaps xmm9, [rsp+0x80]
00007e55d47d80c5  vmovaps xmm10, [rsp+0x90]
00007e55d47d80ce  vmovaps xmm11, [rsp+0xA0]
00007e55d47d80d7  vmovaps xmm12, [rsp+0xB0]
00007e55d47d80e0  vmovaps xmm13, [rsp+0xC0]
00007e55d47d80e9  vmovaps xmm14, [rsp+0xD0]
00007e55d47d80f2  vmovaps xmm15, [rsp+0xE0]
00007e55d47d80fb  add rsp, 0xF0
00007e55d47d8102  pop r11
00007e55d47d8104  pop r10
00007e55d47d8106  pop r9
00007e55d47d8108  pop r8
00007e55d47d810a  pop rsi
00007e55d47d810b  pop rdi
00007e55d47d810c  pop rdx
00007e55d47d810d  pop rcx
00007e55d47d810e  pop rax
00007e55d47d810f  add rsp, 0x08
00007e55d47d8113  jmp 0x00007E55D47D5F06
00007e55d47d8118  sub rsp, 0x08
00007e55d47d811c  push rax
00007e55d47d811d  push rcx
00007e55d47d811e  push rdx
00007e55d47d811f  push rdi
00007e55d47d8120  push rsi
00007e55d47d8121  push r8
00007e55d47d8123  push r9
00007e55d47d8125  push r10
00007e55d47d8127  push r11
00007e55d47d8129  sub rsp, 0xF0
00007e55d47d8130  vmovaps [rsp], xmm0
00007e55d47d8135  vmovaps [rsp+0x10], xmm1
00007e55d47d813b  vmovaps [rsp+0x20], xmm2
00007e55d47d8141  vmovaps [rsp+0x30], xmm3
00007e55d47d8147  vmovaps [rsp+0x40], xmm5
00007e55d47d814d  vmovaps [rsp+0x50], xmm6
00007e55d47d8153  vmovaps [rsp+0x60], xmm7
00007e55d47d8159  vmovaps [rsp+0x70], xmm8
00007e55d47d815f  vmovaps [rsp+0x80], xmm9
00007e55d47d8168  vmovaps [rsp+0x90], xmm10
00007e55d47d8171  vmovaps [rsp+0xA0], xmm11
00007e55d47d817a  vmovaps [rsp+0xB0], xmm12
00007e55d47d8183  vmovaps [rsp+0xC0], xmm13
00007e55d47d818c  vmovaps [rsp+0xD0], xmm14
00007e55d47d8195  vmovaps [rsp+0xE0], xmm15
00007e55d47d819e  sub rsp, 0x30
00007e55d47d81a2  movaps [rsp], xmm4
00007e55d47d81a6  movaps [rsp+0x10], xmm3
00007e55d47d81ab  movaps [rsp+0x20], xmm5
00007e55d47d81b0  lea rdi, [rsp]
00007e55d47d81b4  mov esi, 0x00
00007e55d47d81b9  mov rax, 0x55D0734A4530
00007e55d47d81c3  call rax
00007e55d47d81c5  movaps xmm4, [rsp]
00007e55d47d81c9  add rsp, 0x30
00007e55d47d81cd  vmovaps xmm0, [rsp]
00007e55d47d81d2  vmovaps xmm1, [rsp+0x10]
00007e55d47d81d8  vmovaps xmm2, [rsp+0x20]
00007e55d47d81de  vmovaps xmm3, [rsp+0x30]
00007e55d47d81e4  vmovaps xmm5, [rsp+0x40]
00007e55d47d81ea  vmovaps xmm6, [rsp+0x50]
00007e55d47d81f0  vmovaps xmm7, [rsp+0x60]
00007e55d47d81f6  vmovaps xmm8, [rsp+0x70]
00007e55d47d81fc  vmovaps xmm9, [rsp+0x80]
00007e55d47d8205  vmovaps xmm10, [rsp+0x90]
00007e55d47d820e  vmovaps xmm11, [rsp+0xA0]
00007e55d47d8217  vmovaps xmm12, [rsp+0xB0]
00007e55d47d8220  vmovaps xmm13, [rsp+0xC0]
00007e55d47d8229  vmovaps xmm14, [rsp+0xD0]
00007e55d47d8232  vmovaps xmm15, [rsp+0xE0]
00007e55d47d823b  add rsp, 0xF0
00007e55d47d8242  pop r11
00007e55d47d8244  pop r10
00007e55d47d8246  pop r9
00007e55d47d8248  pop r8
00007e55d47d824a  pop rsi
00007e55d47d824b  pop rdi
00007e55d47d824c  pop rdx
00007e55d47d824d  pop rcx
00007e55d47d824e  pop rax
00007e55d47d824f  add rsp, 0x08
00007e55d47d8253  jmp 0x00007E55D47D5F54
00007e55d47d8258  call 0x00007E55D46D64F0
00007e55d47d825d  jmp 0x00007E55D47D5F61
00007e55d47d8262  sub rsp, 0x08
00007e55d47d8266  push rax
00007e55d47d8267  push rcx
00007e55d47d8268  push rdx
00007e55d47d8269  push rdi
00007e55d47d826a  push rsi
00007e55d47d826b  push r8
00007e55d47d826d  push r9
00007e55d47d826f  push r10
00007e55d47d8271  push r11
00007e55d47d8273  sub rsp, 0xF0
00007e55d47d827a  vmovaps [rsp], xmm0
00007e55d47d827f  vmovaps [rsp+0x10], xmm1
00007e55d47d8285  vmovaps [rsp+0x20], xmm2
00007e55d47d828b  vmovaps [rsp+0x30], xmm3
00007e55d47d8291  vmovaps [rsp+0x40], xmm4
00007e55d47d8297  vmovaps [rsp+0x50], xmm6
00007e55d47d829d  vmovaps [rsp+0x60], xmm7
00007e55d47d82a3  vmovaps [rsp+0x70], xmm8
00007e55d47d82a9  vmovaps [rsp+0x80], xmm9
00007e55d47d82b2  vmovaps [rsp+0x90], xmm10
00007e55d47d82bb  vmovaps [rsp+0xA0], xmm11
00007e55d47d82c4  vmovaps [rsp+0xB0], xmm12
00007e55d47d82cd  vmovaps [rsp+0xC0], xmm13
00007e55d47d82d6  vmovaps [rsp+0xD0], xmm14
00007e55d47d82df  vmovaps [rsp+0xE0], xmm15
00007e55d47d82e8  sub rsp, 0x30
00007e55d47d82ec  movaps [rsp], xmm5
00007e55d47d82f0  movaps [rsp+0x10], xmm6
00007e55d47d82f5  movaps [rsp+0x20], xmm3
00007e55d47d82fa  lea rdi, [rsp]
00007e55d47d82fe  mov esi, 0x00
00007e55d47d8303  mov rax, 0x55D0734A4530
00007e55d47d830d  call rax
00007e55d47d830f  movaps xmm5, [rsp]
00007e55d47d8313  add rsp, 0x30
00007e55d47d8317  vmovaps xmm0, [rsp]
00007e55d47d831c  vmovaps xmm1, [rsp+0x10]
00007e55d47d8322  vmovaps xmm2, [rsp+0x20]
00007e55d47d8328  vmovaps xmm3, [rsp+0x30]
00007e55d47d832e  vmovaps xmm4, [rsp+0x40]
00007e55d47d8334  vmovaps xmm6, [rsp+0x50]
00007e55d47d833a  vmovaps xmm7, [rsp+0x60]
00007e55d47d8340  vmovaps xmm8, [rsp+0x70]
00007e55d47d8346  vmovaps xmm9, [rsp+0x80]
00007e55d47d834f  vmovaps xmm10, [rsp+0x90]
00007e55d47d8358  vmovaps xmm11, [rsp+0xA0]
00007e55d47d8361  vmovaps xmm12, [rsp+0xB0]
00007e55d47d836a  vmovaps xmm13, [rsp+0xC0]
00007e55d47d8373  vmovaps xmm14, [rsp+0xD0]
00007e55d47d837c  vmovaps xmm15, [rsp+0xE0]
00007e55d47d8385  add rsp, 0xF0
00007e55d47d838c  pop r11
00007e55d47d838e  pop r10
00007e55d47d8390  pop r9
00007e55d47d8392  pop r8
00007e55d47d8394  pop rsi
00007e55d47d8395  pop rdi
00007e55d47d8396  pop rdx
00007e55d47d8397  pop rcx
00007e55d47d8398  pop rax
00007e55d47d8399  add rsp, 0x08
00007e55d47d839d  jmp 0x00007E55D47D5F87
00007e55d47d83a2  sub rsp, 0x08
00007e55d47d83a6  push rax
00007e55d47d83a7  push rcx
00007e55d47d83a8  push rdx
00007e55d47d83a9  push rdi
00007e55d47d83aa  push rsi
00007e55d47d83ab  push r8
00007e55d47d83ad  push r9
00007e55d47d83af  push r10
00007e55d47d83b1  push r11
00007e55d47d83b3  sub rsp, 0xF0
00007e55d47d83ba  vmovaps [rsp], xmm0
00007e55d47d83bf  vmovaps [rsp+0x10], xmm1
00007e55d47d83c5  vmovaps [rsp+0x20], xmm2
00007e55d47d83cb  vmovaps [rsp+0x30], xmm3
00007e55d47d83d1  vmovaps [rsp+0x40], xmm4
00007e55d47d83d7  vmovaps [rsp+0x50], xmm5
00007e55d47d83dd  vmovaps [rsp+0x60], xmm7
00007e55d47d83e3  vmovaps [rsp+0x70], xmm8
00007e55d47d83e9  vmovaps [rsp+0x80], xmm9
00007e55d47d83f2  vmovaps [rsp+0x90], xmm10
00007e55d47d83fb  vmovaps [rsp+0xA0], xmm11
00007e55d47d8404  vmovaps [rsp+0xB0], xmm12
00007e55d47d840d  vmovaps [rsp+0xC0], xmm13
00007e55d47d8416  vmovaps [rsp+0xD0], xmm14
00007e55d47d841f  vmovaps [rsp+0xE0], xmm15
00007e55d47d8428  sub rsp, 0x30
00007e55d47d842c  movaps [rsp], xmm6
00007e55d47d8430  movaps [rsp+0x10], xmm9
00007e55d47d8436  movaps [rsp+0x20], xmm1
00007e55d47d843b  lea rdi, [rsp]
00007e55d47d843f  mov esi, 0x00
00007e55d47d8444  mov rax, 0x55D0734A4530
00007e55d47d844e  call rax
00007e55d47d8450  movaps xmm6, [rsp]
00007e55d47d8454  add rsp, 0x30
00007e55d47d8458  vmovaps xmm0, [rsp]
00007e55d47d845d  vmovaps xmm1, [rsp+0x10]
00007e55d47d8463  vmovaps xmm2, [rsp+0x20]
00007e55d47d8469  vmovaps xmm3, [rsp+0x30]
00007e55d47d846f  vmovaps xmm4, [rsp+0x40]
00007e55d47d8475  vmovaps xmm5, [rsp+0x50]
00007e55d47d847b  vmovaps xmm7, [rsp+0x60]
00007e55d47d8481  vmovaps xmm8, [rsp+0x70]
00007e55d47d8487  vmovaps xmm9, [rsp+0x80]
00007e55d47d8490  vmovaps xmm10, [rsp+0x90]
00007e55d47d8499  vmovaps xmm11, [rsp+0xA0]
00007e55d47d84a2  vmovaps xmm12, [rsp+0xB0]
00007e55d47d84ab  vmovaps xmm13, [rsp+0xC0]
00007e55d47d84b4  vmovaps xmm14, [rsp+0xD0]
00007e55d47d84bd  vmovaps xmm15, [rsp+0xE0]
00007e55d47d84c6  add rsp, 0xF0
00007e55d47d84cd  pop r11
00007e55d47d84cf  pop r10
00007e55d47d84d1  pop r9
00007e55d47d84d3  pop r8
00007e55d47d84d5  pop rsi
00007e55d47d84d6  pop rdi
00007e55d47d84d7  pop rdx
00007e55d47d84d8  pop rcx
00007e55d47d84d9  pop rax
00007e55d47d84da  add rsp, 0x08
00007e55d47d84de  jmp 0x00007E55D47D5FAB
00007e55d47d84e3  sub rsp, 0x08
00007e55d47d84e7  push rax
00007e55d47d84e8  push rcx
00007e55d47d84e9  push rdx
00007e55d47d84ea  push rdi
00007e55d47d84eb  push rsi
00007e55d47d84ec  push r8
00007e55d47d84ee  push r9
00007e55d47d84f0  push r10
00007e55d47d84f2  push r11
00007e55d47d84f4  sub rsp, 0xF0
00007e55d47d84fb  vmovaps [rsp], xmm0
00007e55d47d8500  vmovaps [rsp+0x10], xmm1
00007e55d47d8506  vmovaps [rsp+0x20], xmm2
00007e55d47d850c  vmovaps [rsp+0x30], xmm3
00007e55d47d8512  vmovaps [rsp+0x40], xmm4
00007e55d47d8518  vmovaps [rsp+0x50], xmm5
00007e55d47d851e  vmovaps [rsp+0x60], xmm6
00007e55d47d8524  vmovaps [rsp+0x70], xmm7
00007e55d47d852a  vmovaps [rsp+0x80], xmm8
00007e55d47d8533  vmovaps [rsp+0x90], xmm10
00007e55d47d853c  vmovaps [rsp+0xA0], xmm11
00007e55d47d8545  vmovaps [rsp+0xB0], xmm12
00007e55d47d854e  vmovaps [rsp+0xC0], xmm13
00007e55d47d8557  vmovaps [rsp+0xD0], xmm14
00007e55d47d8560  vmovaps [rsp+0xE0], xmm15
00007e55d47d8569  sub rsp, 0x30
00007e55d47d856d  movaps [rsp], xmm9
00007e55d47d8572  movaps [rsp+0x10], xmm3
00007e55d47d8577  movaps [rsp+0x20], xmm1
00007e55d47d857c  lea rdi, [rsp]
00007e55d47d8580  mov esi, 0x00
00007e55d47d8585  mov rax, 0x55D0734A4530
00007e55d47d858f  call rax
00007e55d47d8591  movaps xmm9, [rsp]
00007e55d47d8596  add rsp, 0x30
00007e55d47d859a  vmovaps xmm0, [rsp]
00007e55d47d859f  vmovaps xmm1, [rsp+0x10]
00007e55d47d85a5  vmovaps xmm2, [rsp+0x20]
00007e55d47d85ab  vmovaps xmm3, [rsp+0x30]
00007e55d47d85b1  vmovaps xmm4, [rsp+0x40]
00007e55d47d85b7  vmovaps xmm5, [rsp+0x50]
00007e55d47d85bd  vmovaps xmm6, [rsp+0x60]
00007e55d47d85c3  vmovaps xmm7, [rsp+0x70]
00007e55d47d85c9  vmovaps xmm8, [rsp+0x80]
00007e55d47d85d2  vmovaps xmm10, [rsp+0x90]
00007e55d47d85db  vmovaps xmm11, [rsp+0xA0]
00007e55d47d85e4  vmovaps xmm12, [rsp+0xB0]
00007e55d47d85ed  vmovaps xmm13, [rsp+0xC0]
00007e55d47d85f6  vmovaps xmm14, [rsp+0xD0]
00007e55d47d85ff  vmovaps xmm15, [rsp+0xE0]
00007e55d47d8608  add rsp, 0xF0
00007e55d47d860f  pop r11
00007e55d47d8611  pop r10
00007e55d47d8613  pop r9
00007e55d47d8615  pop r8
00007e55d47d8617  pop rsi
00007e55d47d8618  pop rdi
00007e55d47d8619  pop rdx
00007e55d47d861a  pop rcx
00007e55d47d861b  pop rax
00007e55d47d861c  add rsp, 0x08
00007e55d47d8620  jmp 0x00007E55D47D5FF7
00007e55d47d8625  call 0x00007E55D46D64F0
00007e55d47d862a  jmp 0x00007E55D47D6004
00007e55d47d862f  sub rsp, 0x08
00007e55d47d8633  push rax
00007e55d47d8634  push rcx
00007e55d47d8635  push rdx
00007e55d47d8636  push rdi
00007e55d47d8637  push rsi
00007e55d47d8638  push r8
00007e55d47d863a  push r9
00007e55d47d863c  push r10
00007e55d47d863e  push r11
00007e55d47d8640  sub rsp, 0xF0
00007e55d47d8647  vmovaps [rsp], xmm0
00007e55d47d864c  vmovaps [rsp+0x10], xmm1
00007e55d47d8652  vmovaps [rsp+0x20], xmm2
00007e55d47d8658  vmovaps [rsp+0x30], xmm3
00007e55d47d865e  vmovaps [rsp+0x40], xmm4
00007e55d47d8664  vmovaps [rsp+0x50], xmm5
00007e55d47d866a  vmovaps [rsp+0x60], xmm6
00007e55d47d8670  vmovaps [rsp+0x70], xmm7
00007e55d47d8676  vmovaps [rsp+0x80], xmm8
00007e55d47d867f  vmovaps [rsp+0x90], xmm9
00007e55d47d8688  vmovaps [rsp+0xA0], xmm10
00007e55d47d8691  vmovaps [rsp+0xB0], xmm11
00007e55d47d869a  vmovaps [rsp+0xC0], xmm12
00007e55d47d86a3  vmovaps [rsp+0xD0], xmm13
00007e55d47d86ac  vmovaps [rsp+0xE0], xmm14
00007e55d47d86b5  sub rsp, 0x30
00007e55d47d86b9  movaps [rsp], xmm15
00007e55d47d86be  movaps [rsp+0x10], xmm3
00007e55d47d86c3  movaps [rsp+0x20], xmm7
00007e55d47d86c8  lea rdi, [rsp]
00007e55d47d86cc  mov esi, 0x00
00007e55d47d86d1  mov rax, 0x55D0734A4530
00007e55d47d86db  call rax
00007e55d47d86dd  movaps xmm15, [rsp]
00007e55d47d86e2  add rsp, 0x30
00007e55d47d86e6  vmovaps xmm0, [rsp]
00007e55d47d86eb  vmovaps xmm1, [rsp+0x10]
00007e55d47d86f1  vmovaps xmm2, [rsp+0x20]
00007e55d47d86f7  vmovaps xmm3, [rsp+0x30]
00007e55d47d86fd  vmovaps xmm4, [rsp+0x40]
00007e55d47d8703  vmovaps xmm5, [rsp+0x50]
00007e55d47d8709  vmovaps xmm6, [rsp+0x60]
00007e55d47d870f  vmovaps xmm7, [rsp+0x70]
00007e55d47d8715  vmovaps xmm8, [rsp+0x80]
00007e55d47d871e  vmovaps xmm9, [rsp+0x90]
00007e55d47d8727  vmovaps xmm10, [rsp+0xA0]
00007e55d47d8730  vmovaps xmm11, [rsp+0xB0]
00007e55d47d8739  vmovaps xmm12, [rsp+0xC0]
00007e55d47d8742  vmovaps xmm13, [rsp+0xD0]
00007e55d47d874b  vmovaps xmm14, [rsp+0xE0]
00007e55d47d8754  add rsp, 0xF0
00007e55d47d875b  pop r11
00007e55d47d875d  pop r10
00007e55d47d875f  pop r9
00007e55d47d8761  pop r8
00007e55d47d8763  pop rsi
00007e55d47d8764  pop rdi
00007e55d47d8765  pop rdx
00007e55d47d8766  pop rcx
00007e55d47d8767  pop rax
00007e55d47d8768  add rsp, 0x08
00007e55d47d876c  jmp 0x00007E55D47D6030
00007e55d47d8771  sub rsp, 0x08
00007e55d47d8775  push rax
00007e55d47d8776  push rcx
00007e55d47d8777  push rdx
00007e55d47d8778  push rdi
00007e55d47d8779  push rsi
00007e55d47d877a  push r8
00007e55d47d877c  push r9
00007e55d47d877e  push r10
00007e55d47d8780  push r11
00007e55d47d8782  sub rsp, 0xF0
00007e55d47d8789  vmovaps [rsp], xmm0
00007e55d47d878e  vmovaps [rsp+0x10], xmm1
00007e55d47d8794  vmovaps [rsp+0x20], xmm2
00007e55d47d879a  vmovaps [rsp+0x30], xmm4
00007e55d47d87a0  vmovaps [rsp+0x40], xmm5
00007e55d47d87a6  vmovaps [rsp+0x50], xmm6
00007e55d47d87ac  vmovaps [rsp+0x60], xmm7
00007e55d47d87b2  vmovaps [rsp+0x70], xmm8
00007e55d47d87b8  vmovaps [rsp+0x80], xmm9
00007e55d47d87c1  vmovaps [rsp+0x90], xmm10
00007e55d47d87ca  vmovaps [rsp+0xA0], xmm11
00007e55d47d87d3  vmovaps [rsp+0xB0], xmm12
00007e55d47d87dc  vmovaps [rsp+0xC0], xmm13
00007e55d47d87e5  vmovaps [rsp+0xD0], xmm14
00007e55d47d87ee  vmovaps [rsp+0xE0], xmm15
00007e55d47d87f7  sub rsp, 0x30
00007e55d47d87fb  movaps [rsp], xmm3
00007e55d47d87ff  movaps [rsp+0x10], xmm1
00007e55d47d8804  movaps [rsp+0x20], xmm15
00007e55d47d880a  lea rdi, [rsp]
00007e55d47d880e  mov esi, 0x00
00007e55d47d8813  mov rax, 0x55D0734A4530
00007e55d47d881d  call rax
00007e55d47d881f  movaps xmm3, [rsp]
00007e55d47d8823  add rsp, 0x30
00007e55d47d8827  vmovaps xmm0, [rsp]
00007e55d47d882c  vmovaps xmm1, [rsp+0x10]
00007e55d47d8832  vmovaps xmm2, [rsp+0x20]
00007e55d47d8838  vmovaps xmm4, [rsp+0x30]
00007e55d47d883e  vmovaps xmm5, [rsp+0x40]
00007e55d47d8844  vmovaps xmm6, [rsp+0x50]
00007e55d47d884a  vmovaps xmm7, [rsp+0x60]
00007e55d47d8850  vmovaps xmm8, [rsp+0x70]
00007e55d47d8856  vmovaps xmm9, [rsp+0x80]
00007e55d47d885f  vmovaps xmm10, [rsp+0x90]
00007e55d47d8868  vmovaps xmm11, [rsp+0xA0]
00007e55d47d8871  vmovaps xmm12, [rsp+0xB0]
00007e55d47d887a  vmovaps xmm13, [rsp+0xC0]
00007e55d47d8883  vmovaps xmm14, [rsp+0xD0]
00007e55d47d888c  vmovaps xmm15, [rsp+0xE0]
00007e55d47d8895  add rsp, 0xF0
00007e55d47d889c  pop r11
00007e55d47d889e  pop r10
00007e55d47d88a0  pop r9
00007e55d47d88a2  pop r8
00007e55d47d88a4  pop rsi
00007e55d47d88a5  pop rdi
00007e55d47d88a6  pop rdx
00007e55d47d88a7  pop rcx
00007e55d47d88a8  pop rax
00007e55d47d88a9  add rsp, 0x08
00007e55d47d88ad  jmp 0x00007E55D47D60BF
00007e55d47d88b2  call 0x00007E55D46D64F0
00007e55d47d88b7  jmp 0x00007E55D47D60C9
00007e55d47d88bc  sub rsp, 0x08
00007e55d47d88c0  push rax
00007e55d47d88c1  push rcx
00007e55d47d88c2  push rdx
00007e55d47d88c3  push rdi
00007e55d47d88c4  push rsi
00007e55d47d88c5  push r8
00007e55d47d88c7  push r9
00007e55d47d88c9  push r10
00007e55d47d88cb  push r11
00007e55d47d88cd  sub rsp, 0xF0
00007e55d47d88d4  vmovaps [rsp], xmm0
00007e55d47d88d9  vmovaps [rsp+0x10], xmm1
00007e55d47d88df  vmovaps [rsp+0x20], xmm2
00007e55d47d88e5  vmovaps [rsp+0x30], xmm3
00007e55d47d88eb  vmovaps [rsp+0x40], xmm4
00007e55d47d88f1  vmovaps [rsp+0x50], xmm5
00007e55d47d88f7  vmovaps [rsp+0x60], xmm6
00007e55d47d88fd  vmovaps [rsp+0x70], xmm7
00007e55d47d8903  vmovaps [rsp+0x80], xmm8
00007e55d47d890c  vmovaps [rsp+0x90], xmm9
00007e55d47d8915  vmovaps [rsp+0xA0], xmm10
00007e55d47d891e  vmovaps [rsp+0xB0], xmm11
00007e55d47d8927  vmovaps [rsp+0xC0], xmm12
00007e55d47d8930  vmovaps [rsp+0xD0], xmm13
00007e55d47d8939  vmovaps [rsp+0xE0], xmm14
00007e55d47d8942  sub rsp, 0x30
00007e55d47d8946  movaps [rsp], xmm15
00007e55d47d894b  movaps [rsp+0x10], xmm14
00007e55d47d8951  movaps [rsp+0x20], xmm4
00007e55d47d8956  lea rdi, [rsp]
00007e55d47d895a  mov esi, 0x00
00007e55d47d895f  mov rax, 0x55D0734A4530
00007e55d47d8969  call rax
00007e55d47d896b  movaps xmm15, [rsp]
00007e55d47d8970  add rsp, 0x30
00007e55d47d8974  vmovaps xmm0, [rsp]
00007e55d47d8979  vmovaps xmm1, [rsp+0x10]
00007e55d47d897f  vmovaps xmm2, [rsp+0x20]
00007e55d47d8985  vmovaps xmm3, [rsp+0x30]
00007e55d47d898b  vmovaps xmm4, [rsp+0x40]
00007e55d47d8991  vmovaps xmm5, [rsp+0x50]
00007e55d47d8997  vmovaps xmm6, [rsp+0x60]
00007e55d47d899d  vmovaps xmm7, [rsp+0x70]
00007e55d47d89a3  vmovaps xmm8, [rsp+0x80]
00007e55d47d89ac  vmovaps xmm9, [rsp+0x90]
00007e55d47d89b5  vmovaps xmm10, [rsp+0xA0]
00007e55d47d89be  vmovaps xmm11, [rsp+0xB0]
00007e55d47d89c7  vmovaps xmm12, [rsp+0xC0]
00007e55d47d89d0  vmovaps xmm13, [rsp+0xD0]
00007e55d47d89d9  vmovaps xmm14, [rsp+0xE0]
00007e55d47d89e2  add rsp, 0xF0
00007e55d47d89e9  pop r11
00007e55d47d89eb  pop r10
00007e55d47d89ed  pop r9
00007e55d47d89ef  pop r8
00007e55d47d89f1  pop rsi
00007e55d47d89f2  pop rdi
00007e55d47d89f3  pop rdx
00007e55d47d89f4  pop rcx
00007e55d47d89f5  pop rax
00007e55d47d89f6  add rsp, 0x08
00007e55d47d89fa  jmp 0x00007E55D47D60F7
00007e55d47d89ff  sub rsp, 0x08
00007e55d47d8a03  push rax
00007e55d47d8a04  push rcx
00007e55d47d8a05  push rdx
00007e55d47d8a06  push rdi
00007e55d47d8a07  push rsi
00007e55d47d8a08  push r8
00007e55d47d8a0a  push r9
00007e55d47d8a0c  push r10
00007e55d47d8a0e  push r11
00007e55d47d8a10  sub rsp, 0xF0
00007e55d47d8a17  vmovaps [rsp], xmm0
00007e55d47d8a1c  vmovaps [rsp+0x10], xmm1
00007e55d47d8a22  vmovaps [rsp+0x20], xmm2
00007e55d47d8a28  vmovaps [rsp+0x30], xmm3
00007e55d47d8a2e  vmovaps [rsp+0x40], xmm4
00007e55d47d8a34  vmovaps [rsp+0x50], xmm5
00007e55d47d8a3a  vmovaps [rsp+0x60], xmm6
00007e55d47d8a40  vmovaps [rsp+0x70], xmm7
00007e55d47d8a46  vmovaps [rsp+0x80], xmm8
00007e55d47d8a4f  vmovaps [rsp+0x90], xmm9
00007e55d47d8a58  vmovaps [rsp+0xA0], xmm10
00007e55d47d8a61  vmovaps [rsp+0xB0], xmm11
00007e55d47d8a6a  vmovaps [rsp+0xC0], xmm12
00007e55d47d8a73  vmovaps [rsp+0xD0], xmm13
00007e55d47d8a7c  vmovaps [rsp+0xE0], xmm15
00007e55d47d8a85  sub rsp, 0x30
00007e55d47d8a89  movaps [rsp], xmm14
00007e55d47d8a8e  movaps [rsp+0x10], xmm2
00007e55d47d8a93  movaps [rsp+0x20], xmm1
00007e55d47d8a98  lea rdi, [rsp]
00007e55d47d8a9c  mov esi, 0x00
00007e55d47d8aa1  mov rax, 0x55D0734A4530
00007e55d47d8aab  call rax
00007e55d47d8aad  movaps xmm14, [rsp]
00007e55d47d8ab2  add rsp, 0x30
00007e55d47d8ab6  vmovaps xmm0, [rsp]
00007e55d47d8abb  vmovaps xmm1, [rsp+0x10]
00007e55d47d8ac1  vmovaps xmm2, [rsp+0x20]
00007e55d47d8ac7  vmovaps xmm3, [rsp+0x30]
00007e55d47d8acd  vmovaps xmm4, [rsp+0x40]
00007e55d47d8ad3  vmovaps xmm5, [rsp+0x50]
00007e55d47d8ad9  vmovaps xmm6, [rsp+0x60]
00007e55d47d8adf  vmovaps xmm7, [rsp+0x70]
00007e55d47d8ae5  vmovaps xmm8, [rsp+0x80]
00007e55d47d8aee  vmovaps xmm9, [rsp+0x90]
00007e55d47d8af7  vmovaps xmm10, [rsp+0xA0]
00007e55d47d8b00  vmovaps xmm11, [rsp+0xB0]
00007e55d47d8b09  vmovaps xmm12, [rsp+0xC0]
00007e55d47d8b12  vmovaps xmm13, [rsp+0xD0]
00007e55d47d8b1b  vmovaps xmm15, [rsp+0xE0]
00007e55d47d8b24  add rsp, 0xF0
00007e55d47d8b2b  pop r11
00007e55d47d8b2d  pop r10
00007e55d47d8b2f  pop r9
00007e55d47d8b31  pop r8
00007e55d47d8b33  pop rsi
00007e55d47d8b34  pop rdi
00007e55d47d8b35  pop rdx
00007e55d47d8b36  pop rcx
00007e55d47d8b37  pop rax
00007e55d47d8b38  add rsp, 0x08
00007e55d47d8b3c  jmp 0x00007E55D47D611D
00007e55d47d8b41  sub rsp, 0x08
00007e55d47d8b45  push rax
00007e55d47d8b46  push rcx
00007e55d47d8b47  push rdx
00007e55d47d8b48  push rdi
00007e55d47d8b49  push rsi
00007e55d47d8b4a  push r8
00007e55d47d8b4c  push r9
00007e55d47d8b4e  push r10
00007e55d47d8b50  push r11
00007e55d47d8b52  sub rsp, 0xF0
00007e55d47d8b59  vmovaps [rsp], xmm0
00007e55d47d8b5e  vmovaps [rsp+0x10], xmm2
00007e55d47d8b64  vmovaps [rsp+0x20], xmm3
00007e55d47d8b6a  vmovaps [rsp+0x30], xmm4
00007e55d47d8b70  vmovaps [rsp+0x40], xmm5
00007e55d47d8b76  vmovaps [rsp+0x50], xmm6
00007e55d47d8b7c  vmovaps [rsp+0x60], xmm7
00007e55d47d8b82  vmovaps [rsp+0x70], xmm8
00007e55d47d8b88  vmovaps [rsp+0x80], xmm9
00007e55d47d8b91  vmovaps [rsp+0x90], xmm10
00007e55d47d8b9a  vmovaps [rsp+0xA0], xmm11
00007e55d47d8ba3  vmovaps [rsp+0xB0], xmm12
00007e55d47d8bac  vmovaps [rsp+0xC0], xmm13
00007e55d47d8bb5  vmovaps [rsp+0xD0], xmm14
00007e55d47d8bbe  vmovaps [rsp+0xE0], xmm15
00007e55d47d8bc7  sub rsp, 0x30
00007e55d47d8bcb  movaps [rsp], xmm1
00007e55d47d8bcf  movaps [rsp+0x10], xmm4
00007e55d47d8bd4  movaps [rsp+0x20], xmm9
00007e55d47d8bda  lea rdi, [rsp]
00007e55d47d8bde  mov esi, 0x00
00007e55d47d8be3  mov rax, 0x55D0734A4530
00007e55d47d8bed  call rax
00007e55d47d8bef  movaps xmm1, [rsp]
00007e55d47d8bf3  add rsp, 0x30
00007e55d47d8bf7  vmovaps xmm0, [rsp]
00007e55d47d8bfc  vmovaps xmm2, [rsp+0x10]
00007e55d47d8c02  vmovaps xmm3, [rsp+0x20]
00007e55d47d8c08  vmovaps xmm4, [rsp+0x30]
00007e55d47d8c0e  vmovaps xmm5, [rsp+0x40]
00007e55d47d8c14  vmovaps xmm6, [rsp+0x50]
00007e55d47d8c1a  vmovaps xmm7, [rsp+0x60]
00007e55d47d8c20  vmovaps xmm8, [rsp+0x70]
00007e55d47d8c26  vmovaps xmm9, [rsp+0x80]
00007e55d47d8c2f  vmovaps xmm10, [rsp+0x90]
00007e55d47d8c38  vmovaps xmm11, [rsp+0xA0]
00007e55d47d8c41  vmovaps xmm12, [rsp+0xB0]
00007e55d47d8c4a  vmovaps xmm13, [rsp+0xC0]
00007e55d47d8c53  vmovaps xmm14, [rsp+0xD0]
00007e55d47d8c5c  vmovaps xmm15, [rsp+0xE0]
00007e55d47d8c65  add rsp, 0xF0
00007e55d47d8c6c  pop r11
00007e55d47d8c6e  pop r10
00007e55d47d8c70  pop r9
00007e55d47d8c72  pop r8
00007e55d47d8c74  pop rsi
00007e55d47d8c75  pop rdi
00007e55d47d8c76  pop rdx
00007e55d47d8c77  pop rcx
00007e55d47d8c78  pop rax
00007e55d47d8c79  add rsp, 0x08
00007e55d47d8c7d  jmp 0x00007E55D47D613B
00007e55d47d8c82  sub rsp, 0x08
00007e55d47d8c86  push rax
00007e55d47d8c87  push rcx
00007e55d47d8c88  push rdx
00007e55d47d8c89  push rdi
00007e55d47d8c8a  push rsi
00007e55d47d8c8b  push r8
00007e55d47d8c8d  push r9
00007e55d47d8c8f  push r10
00007e55d47d8c91  push r11
00007e55d47d8c93  sub rsp, 0xF0
00007e55d47d8c9a  vmovaps [rsp], xmm0
00007e55d47d8c9f  vmovaps [rsp+0x10], xmm1
00007e55d47d8ca5  vmovaps [rsp+0x20], xmm2
00007e55d47d8cab  vmovaps [rsp+0x30], xmm3
00007e55d47d8cb1  vmovaps [rsp+0x40], xmm5
00007e55d47d8cb7  vmovaps [rsp+0x50], xmm6
00007e55d47d8cbd  vmovaps [rsp+0x60], xmm7
00007e55d47d8cc3  vmovaps [rsp+0x70], xmm8
00007e55d47d8cc9  vmovaps [rsp+0x80], xmm9
00007e55d47d8cd2  vmovaps [rsp+0x90], xmm10
00007e55d47d8cdb  vmovaps [rsp+0xA0], xmm11
00007e55d47d8ce4  vmovaps [rsp+0xB0], xmm12
00007e55d47d8ced  vmovaps [rsp+0xC0], xmm13
00007e55d47d8cf6  vmovaps [rsp+0xD0], xmm14
00007e55d47d8cff  vmovaps [rsp+0xE0], xmm15
00007e55d47d8d08  sub rsp, 0x30
00007e55d47d8d0c  movaps [rsp], xmm4
00007e55d47d8d10  movaps [rsp+0x10], xmm2
00007e55d47d8d15  movaps [rsp+0x20], xmm9
00007e55d47d8d1b  lea rdi, [rsp]
00007e55d47d8d1f  mov esi, 0x00
00007e55d47d8d24  mov rax, 0x55D0734A4530
00007e55d47d8d2e  call rax
00007e55d47d8d30  movaps xmm4, [rsp]
00007e55d47d8d34  add rsp, 0x30
00007e55d47d8d38  vmovaps xmm0, [rsp]
00007e55d47d8d3d  vmovaps xmm1, [rsp+0x10]
00007e55d47d8d43  vmovaps xmm2, [rsp+0x20]
00007e55d47d8d49  vmovaps xmm3, [rsp+0x30]
00007e55d47d8d4f  vmovaps xmm5, [rsp+0x40]
00007e55d47d8d55  vmovaps xmm6, [rsp+0x50]
00007e55d47d8d5b  vmovaps xmm7, [rsp+0x60]
00007e55d47d8d61  vmovaps xmm8, [rsp+0x70]
00007e55d47d8d67  vmovaps xmm9, [rsp+0x80]
00007e55d47d8d70  vmovaps xmm10, [rsp+0x90]
00007e55d47d8d79  vmovaps xmm11, [rsp+0xA0]
00007e55d47d8d82  vmovaps xmm12, [rsp+0xB0]
00007e55d47d8d8b  vmovaps xmm13, [rsp+0xC0]
00007e55d47d8d94  vmovaps xmm14, [rsp+0xD0]
00007e55d47d8d9d  vmovaps xmm15, [rsp+0xE0]
00007e55d47d8da6  add rsp, 0xF0
00007e55d47d8dad  pop r11
00007e55d47d8daf  pop r10
00007e55d47d8db1  pop r9
00007e55d47d8db3  pop r8
00007e55d47d8db5  pop rsi
00007e55d47d8db6  pop rdi
00007e55d47d8db7  pop rdx
00007e55d47d8db8  pop rcx
00007e55d47d8db9  pop rax
00007e55d47d8dba  add rsp, 0x08
00007e55d47d8dbe  jmp 0x00007E55D47D616B
00007e55d47d8dc3  sub rsp, 0x08
00007e55d47d8dc7  push rax
00007e55d47d8dc8  push rcx
00007e55d47d8dc9  push rdx
00007e55d47d8dca  push rdi
00007e55d47d8dcb  push rsi
00007e55d47d8dcc  push r8
00007e55d47d8dce  push r9
00007e55d47d8dd0  push r10
00007e55d47d8dd2  push r11
00007e55d47d8dd4  sub rsp, 0xF0
00007e55d47d8ddb  vmovaps [rsp], xmm0
00007e55d47d8de0  vmovaps [rsp+0x10], xmm1
00007e55d47d8de6  vmovaps [rsp+0x20], xmm2
00007e55d47d8dec  vmovaps [rsp+0x30], xmm3
00007e55d47d8df2  vmovaps [rsp+0x40], xmm4
00007e55d47d8df8  vmovaps [rsp+0x50], xmm5
00007e55d47d8dfe  vmovaps [rsp+0x60], xmm6
00007e55d47d8e04  vmovaps [rsp+0x70], xmm7
00007e55d47d8e0a  vmovaps [rsp+0x80], xmm8
00007e55d47d8e13  vmovaps [rsp+0x90], xmm10
00007e55d47d8e1c  vmovaps [rsp+0xA0], xmm11
00007e55d47d8e25  vmovaps [rsp+0xB0], xmm12
00007e55d47d8e2e  vmovaps [rsp+0xC0], xmm13
00007e55d47d8e37  vmovaps [rsp+0xD0], xmm14
00007e55d47d8e40  vmovaps [rsp+0xE0], xmm15
00007e55d47d8e49  sub rsp, 0x30
00007e55d47d8e4d  movaps [rsp], xmm9
00007e55d47d8e52  movaps [rsp+0x10], xmm2
00007e55d47d8e57  movaps [rsp+0x20], xmm1
00007e55d47d8e5c  lea rdi, [rsp]
00007e55d47d8e60  mov esi, 0x00
00007e55d47d8e65  mov rax, 0x55D0734A4530
00007e55d47d8e6f  call rax
00007e55d47d8e71  movaps xmm9, [rsp]
00007e55d47d8e76  add rsp, 0x30
00007e55d47d8e7a  vmovaps xmm0, [rsp]
00007e55d47d8e7f  vmovaps xmm1, [rsp+0x10]
00007e55d47d8e85  vmovaps xmm2, [rsp+0x20]
00007e55d47d8e8b  vmovaps xmm3, [rsp+0x30]
00007e55d47d8e91  vmovaps xmm4, [rsp+0x40]
00007e55d47d8e97  vmovaps xmm5, [rsp+0x50]
00007e55d47d8e9d  vmovaps xmm6, [rsp+0x60]
00007e55d47d8ea3  vmovaps xmm7, [rsp+0x70]
00007e55d47d8ea9  vmovaps xmm8, [rsp+0x80]
00007e55d47d8eb2  vmovaps xmm10, [rsp+0x90]
00007e55d47d8ebb  vmovaps xmm11, [rsp+0xA0]
00007e55d47d8ec4  vmovaps xmm12, [rsp+0xB0]
00007e55d47d8ecd  vmovaps xmm13, [rsp+0xC0]
00007e55d47d8ed6  vmovaps xmm14, [rsp+0xD0]
00007e55d47d8edf  vmovaps xmm15, [rsp+0xE0]
00007e55d47d8ee8  add rsp, 0xF0
00007e55d47d8eef  pop r11
00007e55d47d8ef1  pop r10
00007e55d47d8ef3  pop r9
00007e55d47d8ef5  pop r8
00007e55d47d8ef7  pop rsi
00007e55d47d8ef8  pop rdi
00007e55d47d8ef9  pop rdx
00007e55d47d8efa  pop rcx
00007e55d47d8efb  pop rax
00007e55d47d8efc  add rsp, 0x08
00007e55d47d8f00  jmp 0x00007E55D47D61A1
00007e55d47d8f05  sub rsp, 0x08
00007e55d47d8f09  push rax
00007e55d47d8f0a  push rcx
00007e55d47d8f0b  push rdx
00007e55d47d8f0c  push rdi
00007e55d47d8f0d  push rsi
00007e55d47d8f0e  push r8
00007e55d47d8f10  push r9
00007e55d47d8f12  push r10
00007e55d47d8f14  push r11
00007e55d47d8f16  sub rsp, 0xF0
00007e55d47d8f1d  vmovaps [rsp], xmm0
00007e55d47d8f22  vmovaps [rsp+0x10], xmm2
00007e55d47d8f28  vmovaps [rsp+0x20], xmm3
00007e55d47d8f2e  vmovaps [rsp+0x30], xmm4
00007e55d47d8f34  vmovaps [rsp+0x40], xmm5
00007e55d47d8f3a  vmovaps [rsp+0x50], xmm6
00007e55d47d8f40  vmovaps [rsp+0x60], xmm7
00007e55d47d8f46  vmovaps [rsp+0x70], xmm8
00007e55d47d8f4c  vmovaps [rsp+0x80], xmm9
00007e55d47d8f55  vmovaps [rsp+0x90], xmm10
00007e55d47d8f5e  vmovaps [rsp+0xA0], xmm11
00007e55d47d8f67  vmovaps [rsp+0xB0], xmm12
00007e55d47d8f70  vmovaps [rsp+0xC0], xmm13
00007e55d47d8f79  vmovaps [rsp+0xD0], xmm14
00007e55d47d8f82  vmovaps [rsp+0xE0], xmm15
00007e55d47d8f8b  sub rsp, 0x30
00007e55d47d8f8f  movaps [rsp], xmm1
00007e55d47d8f93  movaps [rsp+0x10], xmm15
00007e55d47d8f99  movaps [rsp+0x20], xmm6
00007e55d47d8f9e  lea rdi, [rsp]
00007e55d47d8fa2  mov esi, 0x00
00007e55d47d8fa7  mov rax, 0x55D0734A4530
00007e55d47d8fb1  call rax
00007e55d47d8fb3  movaps xmm1, [rsp]
00007e55d47d8fb7  add rsp, 0x30
00007e55d47d8fbb  vmovaps xmm0, [rsp]
00007e55d47d8fc0  vmovaps xmm2, [rsp+0x10]
00007e55d47d8fc6  vmovaps xmm3, [rsp+0x20]
00007e55d47d8fcc  vmovaps xmm4, [rsp+0x30]
00007e55d47d8fd2  vmovaps xmm5, [rsp+0x40]
00007e55d47d8fd8  vmovaps xmm6, [rsp+0x50]
00007e55d47d8fde  vmovaps xmm7, [rsp+0x60]
00007e55d47d8fe4  vmovaps xmm8, [rsp+0x70]
00007e55d47d8fea  vmovaps xmm9, [rsp+0x80]
00007e55d47d8ff3  vmovaps xmm10, [rsp+0x90]
00007e55d47d8ffc  vmovaps xmm11, [rsp+0xA0]
00007e55d47d9005  vmovaps xmm12, [rsp+0xB0]
00007e55d47d900e  vmovaps xmm13, [rsp+0xC0]
00007e55d47d9017  vmovaps xmm14, [rsp+0xD0]
00007e55d47d9020  vmovaps xmm15, [rsp+0xE0]
00007e55d47d9029  add rsp, 0xF0
00007e55d47d9030  pop r11
00007e55d47d9032  pop r10
00007e55d47d9034  pop r9
00007e55d47d9036  pop r8
00007e55d47d9038  pop rsi
00007e55d47d9039  pop rdi
00007e55d47d903a  pop rdx
00007e55d47d903b  pop rcx
00007e55d47d903c  pop rax
00007e55d47d903d  add rsp, 0x08
00007e55d47d9041  jmp 0x00007E55D47D61C2
00007e55d47d9046  sub rsp, 0x08
00007e55d47d904a  push rax
00007e55d47d904b  push rcx
00007e55d47d904c  push rdx
00007e55d47d904d  push rdi
00007e55d47d904e  push rsi
00007e55d47d904f  push r8
00007e55d47d9051  push r9
00007e55d47d9053  push r10
00007e55d47d9055  push r11
00007e55d47d9057  sub rsp, 0xF0
00007e55d47d905e  vmovaps [rsp], xmm0
00007e55d47d9063  vmovaps [rsp+0x10], xmm1
00007e55d47d9069  vmovaps [rsp+0x20], xmm2
00007e55d47d906f  vmovaps [rsp+0x30], xmm3
00007e55d47d9075  vmovaps [rsp+0x40], xmm4
00007e55d47d907b  vmovaps [rsp+0x50], xmm5
00007e55d47d9081  vmovaps [rsp+0x60], xmm6
00007e55d47d9087  vmovaps [rsp+0x70], xmm7
00007e55d47d908d  vmovaps [rsp+0x80], xmm8
00007e55d47d9096  vmovaps [rsp+0x90], xmm9
00007e55d47d909f  vmovaps [rsp+0xA0], xmm10
00007e55d47d90a8  vmovaps [rsp+0xB0], xmm11
00007e55d47d90b1  vmovaps [rsp+0xC0], xmm12
00007e55d47d90ba  vmovaps [rsp+0xD0], xmm13
00007e55d47d90c3  vmovaps [rsp+0xE0], xmm14
00007e55d47d90cc  sub rsp, 0x30
00007e55d47d90d0  movaps [rsp], xmm15
00007e55d47d90d5  movaps [rsp+0x10], xmm5
00007e55d47d90da  movaps [rsp+0x20], xmm3
00007e55d47d90df  lea rdi, [rsp]
00007e55d47d90e3  mov esi, 0x00
00007e55d47d90e8  mov rax, 0x55D0734A4530
00007e55d47d90f2  call rax
00007e55d47d90f4  movaps xmm15, [rsp]
00007e55d47d90f9  add rsp, 0x30
00007e55d47d90fd  vmovaps xmm0, [rsp]
00007e55d47d9102  vmovaps xmm1, [rsp+0x10]
00007e55d47d9108  vmovaps xmm2, [rsp+0x20]
00007e55d47d910e  vmovaps xmm3, [rsp+0x30]
00007e55d47d9114  vmovaps xmm4, [rsp+0x40]
00007e55d47d911a  vmovaps xmm5, [rsp+0x50]
00007e55d47d9120  vmovaps xmm6, [rsp+0x60]
00007e55d47d9126  vmovaps xmm7, [rsp+0x70]
00007e55d47d912c  vmovaps xmm8, [rsp+0x80]
00007e55d47d9135  vmovaps xmm9, [rsp+0x90]
00007e55d47d913e  vmovaps xmm10, [rsp+0xA0]
00007e55d47d9147  vmovaps xmm11, [rsp+0xB0]
00007e55d47d9150  vmovaps xmm12, [rsp+0xC0]
00007e55d47d9159  vmovaps xmm13, [rsp+0xD0]
00007e55d47d9162  vmovaps xmm14, [rsp+0xE0]
00007e55d47d916b  add rsp, 0xF0
00007e55d47d9172  pop r11
00007e55d47d9174  pop r10
00007e55d47d9176  pop r9
00007e55d47d9178  pop r8
00007e55d47d917a  pop rsi
00007e55d47d917b  pop rdi
00007e55d47d917c  pop rdx
00007e55d47d917d  pop rcx
00007e55d47d917e  pop rax
00007e55d47d917f  add rsp, 0x08
00007e55d47d9183  jmp 0x00007E55D47D61DC
00007e55d47d9188  sub rsp, 0x08
00007e55d47d918c  push rax
00007e55d47d918d  push rcx
00007e55d47d918e  push rdx
00007e55d47d918f  push rdi
00007e55d47d9190  push rsi
00007e55d47d9191  push r8
00007e55d47d9193  push r9
00007e55d47d9195  push r10
00007e55d47d9197  push r11
00007e55d47d9199  sub rsp, 0xF0
00007e55d47d91a0  vmovaps [rsp], xmm0
00007e55d47d91a5  vmovaps [rsp+0x10], xmm1
00007e55d47d91ab  vmovaps [rsp+0x20], xmm2
00007e55d47d91b1  vmovaps [rsp+0x30], xmm3
00007e55d47d91b7  vmovaps [rsp+0x40], xmm4
00007e55d47d91bd  vmovaps [rsp+0x50], xmm6
00007e55d47d91c3  vmovaps [rsp+0x60], xmm7
00007e55d47d91c9  vmovaps [rsp+0x70], xmm8
00007e55d47d91cf  vmovaps [rsp+0x80], xmm9
00007e55d47d91d8  vmovaps [rsp+0x90], xmm10
00007e55d47d91e1  vmovaps [rsp+0xA0], xmm11
00007e55d47d91ea  vmovaps [rsp+0xB0], xmm12
00007e55d47d91f3  vmovaps [rsp+0xC0], xmm13
00007e55d47d91fc  vmovaps [rsp+0xD0], xmm14
00007e55d47d9205  vmovaps [rsp+0xE0], xmm15
00007e55d47d920e  sub rsp, 0x30
00007e55d47d9212  movaps [rsp], xmm5
00007e55d47d9216  movaps [rsp+0x10], xmm8
00007e55d47d921c  movaps [rsp+0x20], xmm6
00007e55d47d9221  lea rdi, [rsp]
00007e55d47d9225  mov esi, 0x00
00007e55d47d922a  mov rax, 0x55D0734A4530
00007e55d47d9234  call rax
00007e55d47d9236  movaps xmm5, [rsp]
00007e55d47d923a  add rsp, 0x30
00007e55d47d923e  vmovaps xmm0, [rsp]
00007e55d47d9243  vmovaps xmm1, [rsp+0x10]
00007e55d47d9249  vmovaps xmm2, [rsp+0x20]
00007e55d47d924f  vmovaps xmm3, [rsp+0x30]
00007e55d47d9255  vmovaps xmm4, [rsp+0x40]
00007e55d47d925b  vmovaps xmm6, [rsp+0x50]
00007e55d47d9261  vmovaps xmm7, [rsp+0x60]
00007e55d47d9267  vmovaps xmm8, [rsp+0x70]
00007e55d47d926d  vmovaps xmm9, [rsp+0x80]
00007e55d47d9276  vmovaps xmm10, [rsp+0x90]
00007e55d47d927f  vmovaps xmm11, [rsp+0xA0]
00007e55d47d9288  vmovaps xmm12, [rsp+0xB0]
00007e55d47d9291  vmovaps xmm13, [rsp+0xC0]
00007e55d47d929a  vmovaps xmm14, [rsp+0xD0]
00007e55d47d92a3  vmovaps xmm15, [rsp+0xE0]
00007e55d47d92ac  add rsp, 0xF0
00007e55d47d92b3  pop r11
00007e55d47d92b5  pop r10
00007e55d47d92b7  pop r9
00007e55d47d92b9  pop r8
00007e55d47d92bb  pop rsi
00007e55d47d92bc  pop rdi
00007e55d47d92bd  pop rdx
00007e55d47d92be  pop rcx
00007e55d47d92bf  pop rax
00007e55d47d92c0  add rsp, 0x08
00007e55d47d92c4  jmp 0x00007E55D47D6200
00007e55d47d92c9  sub rsp, 0x08
00007e55d47d92cd  push rax
00007e55d47d92ce  push rcx
00007e55d47d92cf  push rdx
00007e55d47d92d0  push rdi
00007e55d47d92d1  push rsi
00007e55d47d92d2  push r8
00007e55d47d92d4  push r9
00007e55d47d92d6  push r10
00007e55d47d92d8  push r11
00007e55d47d92da  sub rsp, 0xF0
00007e55d47d92e1  vmovaps [rsp], xmm0
00007e55d47d92e6  vmovaps [rsp+0x10], xmm1
00007e55d47d92ec  vmovaps [rsp+0x20], xmm2
00007e55d47d92f2  vmovaps [rsp+0x30], xmm3
00007e55d47d92f8  vmovaps [rsp+0x40], xmm4
00007e55d47d92fe  vmovaps [rsp+0x50], xmm5
00007e55d47d9304  vmovaps [rsp+0x60], xmm7
00007e55d47d930a  vmovaps [rsp+0x70], xmm8
00007e55d47d9310  vmovaps [rsp+0x80], xmm9
00007e55d47d9319  vmovaps [rsp+0x90], xmm10
00007e55d47d9322  vmovaps [rsp+0xA0], xmm11
00007e55d47d932b  vmovaps [rsp+0xB0], xmm12
00007e55d47d9334  vmovaps [rsp+0xC0], xmm13
00007e55d47d933d  vmovaps [rsp+0xD0], xmm14
00007e55d47d9346  vmovaps [rsp+0xE0], xmm15
00007e55d47d934f  sub rsp, 0x30
00007e55d47d9353  movaps [rsp], xmm6
00007e55d47d9357  movaps [rsp+0x10], xmm10
00007e55d47d935d  movaps [rsp+0x20], xmm8
00007e55d47d9363  lea rdi, [rsp]
00007e55d47d9367  mov esi, 0x00
00007e55d47d936c  mov rax, 0x55D0734A4530
00007e55d47d9376  call rax
00007e55d47d9378  movaps xmm6, [rsp]
00007e55d47d937c  add rsp, 0x30
00007e55d47d9380  vmovaps xmm0, [rsp]
00007e55d47d9385  vmovaps xmm1, [rsp+0x10]
00007e55d47d938b  vmovaps xmm2, [rsp+0x20]
00007e55d47d9391  vmovaps xmm3, [rsp+0x30]
00007e55d47d9397  vmovaps xmm4, [rsp+0x40]
00007e55d47d939d  vmovaps xmm5, [rsp+0x50]
00007e55d47d93a3  vmovaps xmm7, [rsp+0x60]
00007e55d47d93a9  vmovaps xmm8, [rsp+0x70]
00007e55d47d93af  vmovaps xmm9, [rsp+0x80]
00007e55d47d93b8  vmovaps xmm10, [rsp+0x90]
00007e55d47d93c1  vmovaps xmm11, [rsp+0xA0]
00007e55d47d93ca  vmovaps xmm12, [rsp+0xB0]
00007e55d47d93d3  vmovaps xmm13, [rsp+0xC0]
00007e55d47d93dc  vmovaps xmm14, [rsp+0xD0]
00007e55d47d93e5  vmovaps xmm15, [rsp+0xE0]
00007e55d47d93ee  add rsp, 0xF0
00007e55d47d93f5  pop r11
00007e55d47d93f7  pop r10
00007e55d47d93f9  pop r9
00007e55d47d93fb  pop r8
00007e55d47d93fd  pop rsi
00007e55d47d93fe  pop rdi
00007e55d47d93ff  pop rdx
00007e55d47d9400  pop rcx
00007e55d47d9401  pop rax
00007e55d47d9402  add rsp, 0x08
00007e55d47d9406  jmp 0x00007E55D47D6225
00007e55d47d940b  sub rsp, 0x08
00007e55d47d940f  push rax
00007e55d47d9410  push rcx
00007e55d47d9411  push rdx
00007e55d47d9412  push rdi
00007e55d47d9413  push rsi
00007e55d47d9414  push r8
00007e55d47d9416  push r9
00007e55d47d9418  push r10
00007e55d47d941a  push r11
00007e55d47d941c  sub rsp, 0xF0
00007e55d47d9423  vmovaps [rsp], xmm0
00007e55d47d9428  vmovaps [rsp+0x10], xmm1
00007e55d47d942e  vmovaps [rsp+0x20], xmm2
00007e55d47d9434  vmovaps [rsp+0x30], xmm3
00007e55d47d943a  vmovaps [rsp+0x40], xmm4
00007e55d47d9440  vmovaps [rsp+0x50], xmm5
00007e55d47d9446  vmovaps [rsp+0x60], xmm6
00007e55d47d944c  vmovaps [rsp+0x70], xmm7
00007e55d47d9452  vmovaps [rsp+0x80], xmm8
00007e55d47d945b  vmovaps [rsp+0x90], xmm9
00007e55d47d9464  vmovaps [rsp+0xA0], xmm11
00007e55d47d946d  vmovaps [rsp+0xB0], xmm12
00007e55d47d9476  vmovaps [rsp+0xC0], xmm13
00007e55d47d947f  vmovaps [rsp+0xD0], xmm14
00007e55d47d9488  vmovaps [rsp+0xE0], xmm15
00007e55d47d9491  sub rsp, 0x30
00007e55d47d9495  movaps [rsp], xmm10
00007e55d47d949a  movaps [rsp+0x10], xmm8
00007e55d47d94a0  movaps [rsp+0x20], xmm14
00007e55d47d94a6  lea rdi, [rsp]
00007e55d47d94aa  mov esi, 0x00
00007e55d47d94af  mov rax, 0x55D0734A4530
00007e55d47d94b9  call rax
00007e55d47d94bb  movaps xmm10, [rsp]
00007e55d47d94c0  add rsp, 0x30
00007e55d47d94c4  vmovaps xmm0, [rsp]
00007e55d47d94c9  vmovaps xmm1, [rsp+0x10]
00007e55d47d94cf  vmovaps xmm2, [rsp+0x20]
00007e55d47d94d5  vmovaps xmm3, [rsp+0x30]
00007e55d47d94db  vmovaps xmm4, [rsp+0x40]
00007e55d47d94e1  vmovaps xmm5, [rsp+0x50]
00007e55d47d94e7  vmovaps xmm6, [rsp+0x60]
00007e55d47d94ed  vmovaps xmm7, [rsp+0x70]
00007e55d47d94f3  vmovaps xmm8, [rsp+0x80]
00007e55d47d94fc  vmovaps xmm9, [rsp+0x90]
00007e55d47d9505  vmovaps xmm11, [rsp+0xA0]
00007e55d47d950e  vmovaps xmm12, [rsp+0xB0]
00007e55d47d9517  vmovaps xmm13, [rsp+0xC0]
00007e55d47d9520  vmovaps xmm14, [rsp+0xD0]
00007e55d47d9529  vmovaps xmm15, [rsp+0xE0]
00007e55d47d9532  add rsp, 0xF0
00007e55d47d9539  pop r11
00007e55d47d953b  pop r10
00007e55d47d953d  pop r9
00007e55d47d953f  pop r8
00007e55d47d9541  pop rsi
00007e55d47d9542  pop rdi
00007e55d47d9543  pop rdx
00007e55d47d9544  pop rcx
00007e55d47d9545  pop rax
00007e55d47d9546  add rsp, 0x08
00007e55d47d954a  jmp 0x00007E55D47D6245
00007e55d47d954f  sub rsp, 0x08
00007e55d47d9553  push rax
00007e55d47d9554  push rcx
00007e55d47d9555  push rdx
00007e55d47d9556  push rdi
00007e55d47d9557  push rsi
00007e55d47d9558  push r8
00007e55d47d955a  push r9
00007e55d47d955c  push r10
00007e55d47d955e  push r11
00007e55d47d9560  sub rsp, 0xF0
00007e55d47d9567  vmovaps [rsp], xmm0
00007e55d47d956c  vmovaps [rsp+0x10], xmm1
00007e55d47d9572  vmovaps [rsp+0x20], xmm2
00007e55d47d9578  vmovaps [rsp+0x30], xmm3
00007e55d47d957e  vmovaps [rsp+0x40], xmm4
00007e55d47d9584  vmovaps [rsp+0x50], xmm5
00007e55d47d958a  vmovaps [rsp+0x60], xmm6
00007e55d47d9590  vmovaps [rsp+0x70], xmm7
00007e55d47d9596  vmovaps [rsp+0x80], xmm8
00007e55d47d959f  vmovaps [rsp+0x90], xmm9
00007e55d47d95a8  vmovaps [rsp+0xA0], xmm10
00007e55d47d95b1  vmovaps [rsp+0xB0], xmm11
00007e55d47d95ba  vmovaps [rsp+0xC0], xmm12
00007e55d47d95c3  vmovaps [rsp+0xD0], xmm13
00007e55d47d95cc  vmovaps [rsp+0xE0], xmm15
00007e55d47d95d5  sub rsp, 0x30
00007e55d47d95d9  movaps [rsp], xmm14
00007e55d47d95de  movaps [rsp+0x10], xmm8
00007e55d47d95e4  movaps [rsp+0x20], xmm4
00007e55d47d95e9  lea rdi, [rsp]
00007e55d47d95ed  mov esi, 0x00
00007e55d47d95f2  mov rax, 0x55D0734A4530
00007e55d47d95fc  call rax
00007e55d47d95fe  movaps xmm14, [rsp]
00007e55d47d9603  add rsp, 0x30
00007e55d47d9607  vmovaps xmm0, [rsp]
00007e55d47d960c  vmovaps xmm1, [rsp+0x10]
00007e55d47d9612  vmovaps xmm2, [rsp+0x20]
00007e55d47d9618  vmovaps xmm3, [rsp+0x30]
00007e55d47d961e  vmovaps xmm4, [rsp+0x40]
00007e55d47d9624  vmovaps xmm5, [rsp+0x50]
00007e55d47d962a  vmovaps xmm6, [rsp+0x60]
00007e55d47d9630  vmovaps xmm7, [rsp+0x70]
00007e55d47d9636  vmovaps xmm8, [rsp+0x80]
00007e55d47d963f  vmovaps xmm9, [rsp+0x90]
00007e55d47d9648  vmovaps xmm10, [rsp+0xA0]
00007e55d47d9651  vmovaps xmm11, [rsp+0xB0]
00007e55d47d965a  vmovaps xmm12, [rsp+0xC0]
00007e55d47d9663  vmovaps xmm13, [rsp+0xD0]
00007e55d47d966c  vmovaps xmm15, [rsp+0xE0]
00007e55d47d9675  add rsp, 0xF0
00007e55d47d967c  pop r11
00007e55d47d967e  pop r10
00007e55d47d9680  pop r9
00007e55d47d9682  pop r8
00007e55d47d9684  pop rsi
00007e55d47d9685  pop rdi
00007e55d47d9686  pop rdx
00007e55d47d9687  pop rcx
00007e55d47d9688  pop rax
00007e55d47d9689  add rsp, 0x08
00007e55d47d968d  jmp 0x00007E55D47D6265
00007e55d47d9692  sub rsp, 0x08
00007e55d47d9696  push rax
00007e55d47d9697  push rcx
00007e55d47d9698  push rdx
00007e55d47d9699  push rdi
00007e55d47d969a  push rsi
00007e55d47d969b  push r8
00007e55d47d969d  push r9
00007e55d47d969f  push r10
00007e55d47d96a1  push r11
00007e55d47d96a3  sub rsp, 0xF0
00007e55d47d96aa  vmovaps [rsp], xmm0
00007e55d47d96af  vmovaps [rsp+0x10], xmm1
00007e55d47d96b5  vmovaps [rsp+0x20], xmm2
00007e55d47d96bb  vmovaps [rsp+0x30], xmm3
00007e55d47d96c1  vmovaps [rsp+0x40], xmm5
00007e55d47d96c7  vmovaps [rsp+0x50], xmm6
00007e55d47d96cd  vmovaps [rsp+0x60], xmm7
00007e55d47d96d3  vmovaps [rsp+0x70], xmm8
00007e55d47d96d9  vmovaps [rsp+0x80], xmm9
00007e55d47d96e2  vmovaps [rsp+0x90], xmm10
00007e55d47d96eb  vmovaps [rsp+0xA0], xmm11
00007e55d47d96f4  vmovaps [rsp+0xB0], xmm12
00007e55d47d96fd  vmovaps [rsp+0xC0], xmm13
00007e55d47d9706  vmovaps [rsp+0xD0], xmm14
00007e55d47d970f  vmovaps [rsp+0xE0], xmm15
00007e55d47d9718  sub rsp, 0x30
00007e55d47d971c  movaps [rsp], xmm4
00007e55d47d9720  movaps [rsp+0x10], xmm13
00007e55d47d9726  movaps [rsp+0x20], xmm8
00007e55d47d972c  lea rdi, [rsp]
00007e55d47d9730  mov esi, 0x00
00007e55d47d9735  mov rax, 0x55D0734A4530
00007e55d47d973f  call rax
00007e55d47d9741  movaps xmm4, [rsp]
00007e55d47d9745  add rsp, 0x30
00007e55d47d9749  vmovaps xmm0, [rsp]
00007e55d47d974e  vmovaps xmm1, [rsp+0x10]
00007e55d47d9754  vmovaps xmm2, [rsp+0x20]
00007e55d47d975a  vmovaps xmm3, [rsp+0x30]
00007e55d47d9760  vmovaps xmm5, [rsp+0x40]
00007e55d47d9766  vmovaps xmm6, [rsp+0x50]
00007e55d47d976c  vmovaps xmm7, [rsp+0x60]
00007e55d47d9772  vmovaps xmm8, [rsp+0x70]
00007e55d47d9778  vmovaps xmm9, [rsp+0x80]
00007e55d47d9781  vmovaps xmm10, [rsp+0x90]
00007e55d47d978a  vmovaps xmm11, [rsp+0xA0]
00007e55d47d9793  vmovaps xmm12, [rsp+0xB0]
00007e55d47d979c  vmovaps xmm13, [rsp+0xC0]
00007e55d47d97a5  vmovaps xmm14, [rsp+0xD0]
00007e55d47d97ae  vmovaps xmm15, [rsp+0xE0]
00007e55d47d97b7  add rsp, 0xF0
00007e55d47d97be  pop r11
00007e55d47d97c0  pop r10
00007e55d47d97c2  pop r9
00007e55d47d97c4  pop r8
00007e55d47d97c6  pop rsi
00007e55d47d97c7  pop rdi
00007e55d47d97c8  pop rdx
00007e55d47d97c9  pop rcx
00007e55d47d97ca  pop rax
00007e55d47d97cb  add rsp, 0x08
00007e55d47d97cf  jmp 0x00007E55D47D628A
00007e55d47d97d4  sub rsp, 0x08
00007e55d47d97d8  push rax
00007e55d47d97d9  push rcx
00007e55d47d97da  push rdx
00007e55d47d97db  push rdi
00007e55d47d97dc  push rsi
00007e55d47d97dd  push r8
00007e55d47d97df  push r9
00007e55d47d97e1  push r10
00007e55d47d97e3  push r11
00007e55d47d97e5  sub rsp, 0xF0
00007e55d47d97ec  vmovaps [rsp], xmm0
00007e55d47d97f1  vmovaps [rsp+0x10], xmm1
00007e55d47d97f7  vmovaps [rsp+0x20], xmm2
00007e55d47d97fd  vmovaps [rsp+0x30], xmm3
00007e55d47d9803  vmovaps [rsp+0x40], xmm4
00007e55d47d9809  vmovaps [rsp+0x50], xmm5
00007e55d47d980f  vmovaps [rsp+0x60], xmm6
00007e55d47d9815  vmovaps [rsp+0x70], xmm7
00007e55d47d981b  vmovaps [rsp+0x80], xmm8
00007e55d47d9824  vmovaps [rsp+0x90], xmm9
00007e55d47d982d  vmovaps [rsp+0xA0], xmm10
00007e55d47d9836  vmovaps [rsp+0xB0], xmm11
00007e55d47d983f  vmovaps [rsp+0xC0], xmm12
00007e55d47d9848  vmovaps [rsp+0xD0], xmm14
00007e55d47d9851  vmovaps [rsp+0xE0], xmm15
00007e55d47d985a  sub rsp, 0x30
00007e55d47d985e  movaps [rsp], xmm13
00007e55d47d9863  movaps [rsp+0x10], xmm15
00007e55d47d9869  movaps [rsp+0x20], xmm9
00007e55d47d986f  lea rdi, [rsp]
00007e55d47d9873  mov esi, 0x00
00007e55d47d9878  mov rax, 0x55D0734A4530
00007e55d47d9882  call rax
00007e55d47d9884  movaps xmm13, [rsp]
00007e55d47d9889  add rsp, 0x30
00007e55d47d988d  vmovaps xmm0, [rsp]
00007e55d47d9892  vmovaps xmm1, [rsp+0x10]
00007e55d47d9898  vmovaps xmm2, [rsp+0x20]
00007e55d47d989e  vmovaps xmm3, [rsp+0x30]
00007e55d47d98a4  vmovaps xmm4, [rsp+0x40]
00007e55d47d98aa  vmovaps xmm5, [rsp+0x50]
00007e55d47d98b0  vmovaps xmm6, [rsp+0x60]
00007e55d47d98b6  vmovaps xmm7, [rsp+0x70]
00007e55d47d98bc  vmovaps xmm8, [rsp+0x80]
00007e55d47d98c5  vmovaps xmm9, [rsp+0x90]
00007e55d47d98ce  vmovaps xmm10, [rsp+0xA0]
00007e55d47d98d7  vmovaps xmm11, [rsp+0xB0]
00007e55d47d98e0  vmovaps xmm12, [rsp+0xC0]
00007e55d47d98e9  vmovaps xmm14, [rsp+0xD0]
00007e55d47d98f2  vmovaps xmm15, [rsp+0xE0]
00007e55d47d98fb  add rsp, 0xF0
00007e55d47d9902  pop r11
00007e55d47d9904  pop r10
00007e55d47d9906  pop r9
00007e55d47d9908  pop r8
00007e55d47d990a  pop rsi
00007e55d47d990b  pop rdi
00007e55d47d990c  pop rdx
00007e55d47d990d  pop rcx
00007e55d47d990e  pop rax
00007e55d47d990f  add rsp, 0x08
00007e55d47d9913  jmp 0x00007E55D47D62A5
00007e55d47d9918  sub rsp, 0x08
00007e55d47d991c  push rax
00007e55d47d991d  push rcx
00007e55d47d991e  push rdx
00007e55d47d991f  push rdi
00007e55d47d9920  push rsi
00007e55d47d9921  push r8
00007e55d47d9923  push r9
00007e55d47d9925  push r10
00007e55d47d9927  push r11
00007e55d47d9929  sub rsp, 0xF0
00007e55d47d9930  vmovaps [rsp], xmm0
00007e55d47d9935  vmovaps [rsp+0x10], xmm1
00007e55d47d993b  vmovaps [rsp+0x20], xmm2
00007e55d47d9941  vmovaps [rsp+0x30], xmm3
00007e55d47d9947  vmovaps [rsp+0x40], xmm4
00007e55d47d994d  vmovaps [rsp+0x50], xmm5
00007e55d47d9953  vmovaps [rsp+0x60], xmm6
00007e55d47d9959  vmovaps [rsp+0x70], xmm7
00007e55d47d995f  vmovaps [rsp+0x80], xmm8
00007e55d47d9968  vmovaps [rsp+0x90], xmm9
00007e55d47d9971  vmovaps [rsp+0xA0], xmm10
00007e55d47d997a  vmovaps [rsp+0xB0], xmm11
00007e55d47d9983  vmovaps [rsp+0xC0], xmm12
00007e55d47d998c  vmovaps [rsp+0xD0], xmm13
00007e55d47d9995  vmovaps [rsp+0xE0], xmm14
00007e55d47d999e  sub rsp, 0x30
00007e55d47d99a2  movaps [rsp], xmm15
00007e55d47d99a7  movaps [rsp+0x10], xmm1
00007e55d47d99ac  movaps [rsp+0x20], xmm5
00007e55d47d99b1  lea rdi, [rsp]
00007e55d47d99b5  mov esi, 0x00
00007e55d47d99ba  mov rax, 0x55D0734A4530
00007e55d47d99c4  call rax
00007e55d47d99c6  movaps xmm15, [rsp]
00007e55d47d99cb  add rsp, 0x30
00007e55d47d99cf  vmovaps xmm0, [rsp]
00007e55d47d99d4  vmovaps xmm1, [rsp+0x10]
00007e55d47d99da  vmovaps xmm2, [rsp+0x20]
00007e55d47d99e0  vmovaps xmm3, [rsp+0x30]
00007e55d47d99e6  vmovaps xmm4, [rsp+0x40]
00007e55d47d99ec  vmovaps xmm5, [rsp+0x50]
00007e55d47d99f2  vmovaps xmm6, [rsp+0x60]
00007e55d47d99f8  vmovaps xmm7, [rsp+0x70]
00007e55d47d99fe  vmovaps xmm8, [rsp+0x80]
00007e55d47d9a07  vmovaps xmm9, [rsp+0x90]
00007e55d47d9a10  vmovaps xmm10, [rsp+0xA0]
00007e55d47d9a19  vmovaps xmm11, [rsp+0xB0]
00007e55d47d9a22  vmovaps xmm12, [rsp+0xC0]
00007e55d47d9a2b  vmovaps xmm13, [rsp+0xD0]
00007e55d47d9a34  vmovaps xmm14, [rsp+0xE0]
00007e55d47d9a3d  add rsp, 0xF0
00007e55d47d9a44  pop r11
00007e55d47d9a46  pop r10
00007e55d47d9a48  pop r9
00007e55d47d9a4a  pop r8
00007e55d47d9a4c  pop rsi
00007e55d47d9a4d  pop rdi
00007e55d47d9a4e  pop rdx
00007e55d47d9a4f  pop rcx
00007e55d47d9a50  pop rax
00007e55d47d9a51  add rsp, 0x08
00007e55d47d9a55  jmp 0x00007E55D47D62C0
00007e55d47d9a5a  call 0x00007E55D46D64F0
00007e55d47d9a5f  jmp 0x00007E55D47D631B
00007e55d47d9a64  sub rsp, 0x08
00007e55d47d9a68  push rax
00007e55d47d9a69  push rcx
00007e55d47d9a6a  push rdx
00007e55d47d9a6b  push rdi
00007e55d47d9a6c  push rsi
00007e55d47d9a6d  push r8
00007e55d47d9a6f  push r9
00007e55d47d9a71  push r10
00007e55d47d9a73  push r11
00007e55d47d9a75  sub rsp, 0xF0
00007e55d47d9a7c  vmovaps [rsp], xmm0
00007e55d47d9a81  vmovaps [rsp+0x10], xmm1
00007e55d47d9a87  vmovaps [rsp+0x20], xmm2
00007e55d47d9a8d  vmovaps [rsp+0x30], xmm3
00007e55d47d9a93  vmovaps [rsp+0x40], xmm4
00007e55d47d9a99  vmovaps [rsp+0x50], xmm5
00007e55d47d9a9f  vmovaps [rsp+0x60], xmm6
00007e55d47d9aa5  vmovaps [rsp+0x70], xmm7
00007e55d47d9aab  vmovaps [rsp+0x80], xmm8
00007e55d47d9ab4  vmovaps [rsp+0x90], xmm10
00007e55d47d9abd  vmovaps [rsp+0xA0], xmm11
00007e55d47d9ac6  vmovaps [rsp+0xB0], xmm12
00007e55d47d9acf  vmovaps [rsp+0xC0], xmm13
00007e55d47d9ad8  vmovaps [rsp+0xD0], xmm14
00007e55d47d9ae1  vmovaps [rsp+0xE0], xmm15
00007e55d47d9aea  sub rsp, 0x30
00007e55d47d9aee  movaps [rsp], xmm9
00007e55d47d9af3  movaps [rsp+0x10], xmm8
00007e55d47d9af9  movaps [rsp+0x20], xmm11
00007e55d47d9aff  lea rdi, [rsp]
00007e55d47d9b03  mov esi, 0x00
00007e55d47d9b08  mov rax, 0x55D0734A4530
00007e55d47d9b12  call rax
00007e55d47d9b14  movaps xmm9, [rsp]
00007e55d47d9b19  add rsp, 0x30
00007e55d47d9b1d  vmovaps xmm0, [rsp]
00007e55d47d9b22  vmovaps xmm1, [rsp+0x10]
00007e55d47d9b28  vmovaps xmm2, [rsp+0x20]
00007e55d47d9b2e  vmovaps xmm3, [rsp+0x30]
00007e55d47d9b34  vmovaps xmm4, [rsp+0x40]
00007e55d47d9b3a  vmovaps xmm5, [rsp+0x50]
00007e55d47d9b40  vmovaps xmm6, [rsp+0x60]
00007e55d47d9b46  vmovaps xmm7, [rsp+0x70]
00007e55d47d9b4c  vmovaps xmm8, [rsp+0x80]
00007e55d47d9b55  vmovaps xmm10, [rsp+0x90]
00007e55d47d9b5e  vmovaps xmm11, [rsp+0xA0]
00007e55d47d9b67  vmovaps xmm12, [rsp+0xB0]
00007e55d47d9b70  vmovaps xmm13, [rsp+0xC0]
00007e55d47d9b79  vmovaps xmm14, [rsp+0xD0]
00007e55d47d9b82  vmovaps xmm15, [rsp+0xE0]
00007e55d47d9b8b  add rsp, 0xF0
00007e55d47d9b92  pop r11
00007e55d47d9b94  pop r10
00007e55d47d9b96  pop r9
00007e55d47d9b98  pop r8
00007e55d47d9b9a  pop rsi
00007e55d47d9b9b  pop rdi
00007e55d47d9b9c  pop rdx
00007e55d47d9b9d  pop rcx
00007e55d47d9b9e  pop rax
00007e55d47d9b9f  add rsp, 0x08
00007e55d47d9ba3  jmp 0x00007E55D47D6352
00007e55d47d9ba8  sub rsp, 0x08
00007e55d47d9bac  push rax
00007e55d47d9bad  push rcx
00007e55d47d9bae  push rdx
00007e55d47d9baf  push rdi
00007e55d47d9bb0  push rsi
00007e55d47d9bb1  push r8
00007e55d47d9bb3  push r9
00007e55d47d9bb5  push r10
00007e55d47d9bb7  push r11
00007e55d47d9bb9  sub rsp, 0xF0
00007e55d47d9bc0  vmovaps [rsp], xmm0
00007e55d47d9bc5  vmovaps [rsp+0x10], xmm1
00007e55d47d9bcb  vmovaps [rsp+0x20], xmm2
00007e55d47d9bd1  vmovaps [rsp+0x30], xmm3
00007e55d47d9bd7  vmovaps [rsp+0x40], xmm4
00007e55d47d9bdd  vmovaps [rsp+0x50], xmm5
00007e55d47d9be3  vmovaps [rsp+0x60], xmm6
00007e55d47d9be9  vmovaps [rsp+0x70], xmm7
00007e55d47d9bef  vmovaps [rsp+0x80], xmm8
00007e55d47d9bf8  vmovaps [rsp+0x90], xmm9
00007e55d47d9c01  vmovaps [rsp+0xA0], xmm10
00007e55d47d9c0a  vmovaps [rsp+0xB0], xmm12
00007e55d47d9c13  vmovaps [rsp+0xC0], xmm13
00007e55d47d9c1c  vmovaps [rsp+0xD0], xmm14
00007e55d47d9c25  vmovaps [rsp+0xE0], xmm15
00007e55d47d9c2e  sub rsp, 0x30
00007e55d47d9c32  movaps [rsp], xmm11
00007e55d47d9c37  movaps [rsp+0x10], xmm10
00007e55d47d9c3d  movaps [rsp+0x20], xmm6
00007e55d47d9c42  lea rdi, [rsp]
00007e55d47d9c46  mov esi, 0x00
00007e55d47d9c4b  mov rax, 0x55D0734A4530
00007e55d47d9c55  call rax
00007e55d47d9c57  movaps xmm11, [rsp]
00007e55d47d9c5c  add rsp, 0x30
00007e55d47d9c60  vmovaps xmm0, [rsp]
00007e55d47d9c65  vmovaps xmm1, [rsp+0x10]
00007e55d47d9c6b  vmovaps xmm2, [rsp+0x20]
00007e55d47d9c71  vmovaps xmm3, [rsp+0x30]
00007e55d47d9c77  vmovaps xmm4, [rsp+0x40]
00007e55d47d9c7d  vmovaps xmm5, [rsp+0x50]
00007e55d47d9c83  vmovaps xmm6, [rsp+0x60]
00007e55d47d9c89  vmovaps xmm7, [rsp+0x70]
00007e55d47d9c8f  vmovaps xmm8, [rsp+0x80]
00007e55d47d9c98  vmovaps xmm9, [rsp+0x90]
00007e55d47d9ca1  vmovaps xmm10, [rsp+0xA0]
00007e55d47d9caa  vmovaps xmm12, [rsp+0xB0]
00007e55d47d9cb3  vmovaps xmm13, [rsp+0xC0]
00007e55d47d9cbc  vmovaps xmm14, [rsp+0xD0]
00007e55d47d9cc5  vmovaps xmm15, [rsp+0xE0]
00007e55d47d9cce  add rsp, 0xF0
00007e55d47d9cd5  pop r11
00007e55d47d9cd7  pop r10
00007e55d47d9cd9  pop r9
00007e55d47d9cdb  pop r8
00007e55d47d9cdd  pop rsi
00007e55d47d9cde  pop rdi
00007e55d47d9cdf  pop rdx
00007e55d47d9ce0  pop rcx
00007e55d47d9ce1  pop rax
00007e55d47d9ce2  add rsp, 0x08
00007e55d47d9ce6  jmp 0x00007E55D47D636D
00007e55d47d9ceb  sub rsp, 0x08
00007e55d47d9cef  push rax
00007e55d47d9cf0  push rcx
00007e55d47d9cf1  push rdx
00007e55d47d9cf2  push rdi
00007e55d47d9cf3  push rsi
00007e55d47d9cf4  push r8
00007e55d47d9cf6  push r9
00007e55d47d9cf8  push r10
00007e55d47d9cfa  push r11
00007e55d47d9cfc  sub rsp, 0xF0
00007e55d47d9d03  vmovaps [rsp], xmm0
00007e55d47d9d08  vmovaps [rsp+0x10], xmm1
00007e55d47d9d0e  vmovaps [rsp+0x20], xmm2
00007e55d47d9d14  vmovaps [rsp+0x30], xmm3
00007e55d47d9d1a  vmovaps [rsp+0x40], xmm4
00007e55d47d9d20  vmovaps [rsp+0x50], xmm5
00007e55d47d9d26  vmovaps [rsp+0x60], xmm6
00007e55d47d9d2c  vmovaps [rsp+0x70], xmm7
00007e55d47d9d32  vmovaps [rsp+0x80], xmm8
00007e55d47d9d3b  vmovaps [rsp+0x90], xmm9
00007e55d47d9d44  vmovaps [rsp+0xA0], xmm11
00007e55d47d9d4d  vmovaps [rsp+0xB0], xmm12
00007e55d47d9d56  vmovaps [rsp+0xC0], xmm13
00007e55d47d9d5f  vmovaps [rsp+0xD0], xmm14
00007e55d47d9d68  vmovaps [rsp+0xE0], xmm15
00007e55d47d9d71  sub rsp, 0x30
00007e55d47d9d75  movaps [rsp], xmm10
00007e55d47d9d7a  movaps [rsp+0x10], xmm14
00007e55d47d9d80  movaps [rsp+0x20], xmm4
00007e55d47d9d85  lea rdi, [rsp]
00007e55d47d9d89  mov esi, 0x00
00007e55d47d9d8e  mov rax, 0x55D0734A4530
00007e55d47d9d98  call rax
00007e55d47d9d9a  movaps xmm10, [rsp]
00007e55d47d9d9f  add rsp, 0x30
00007e55d47d9da3  vmovaps xmm0, [rsp]
00007e55d47d9da8  vmovaps xmm1, [rsp+0x10]
00007e55d47d9dae  vmovaps xmm2, [rsp+0x20]
00007e55d47d9db4  vmovaps xmm3, [rsp+0x30]
00007e55d47d9dba  vmovaps xmm4, [rsp+0x40]
00007e55d47d9dc0  vmovaps xmm5, [rsp+0x50]
00007e55d47d9dc6  vmovaps xmm6, [rsp+0x60]
00007e55d47d9dcc  vmovaps xmm7, [rsp+0x70]
00007e55d47d9dd2  vmovaps xmm8, [rsp+0x80]
00007e55d47d9ddb  vmovaps xmm9, [rsp+0x90]
00007e55d47d9de4  vmovaps xmm11, [rsp+0xA0]
00007e55d47d9ded  vmovaps xmm12, [rsp+0xB0]
00007e55d47d9df6  vmovaps xmm13, [rsp+0xC0]
00007e55d47d9dff  vmovaps xmm14, [rsp+0xD0]
00007e55d47d9e08  vmovaps xmm15, [rsp+0xE0]
00007e55d47d9e11  add rsp, 0xF0
00007e55d47d9e18  pop r11
00007e55d47d9e1a  pop r10
00007e55d47d9e1c  pop r9
00007e55d47d9e1e  pop r8
00007e55d47d9e20  pop rsi
00007e55d47d9e21  pop rdi
00007e55d47d9e22  pop rdx
00007e55d47d9e23  pop rcx
00007e55d47d9e24  pop rax
00007e55d47d9e25  add rsp, 0x08
00007e55d47d9e29  jmp 0x00007E55D47D6388
00007e55d47d9e2e  sub rsp, 0x08
00007e55d47d9e32  push rax
00007e55d47d9e33  push rcx
00007e55d47d9e34  push rdx
00007e55d47d9e35  push rdi
00007e55d47d9e36  push rsi
00007e55d47d9e37  push r8
00007e55d47d9e39  push r9
00007e55d47d9e3b  push r10
00007e55d47d9e3d  push r11
00007e55d47d9e3f  sub rsp, 0xF0
00007e55d47d9e46  vmovaps [rsp], xmm0
00007e55d47d9e4b  vmovaps [rsp+0x10], xmm1
00007e55d47d9e51  vmovaps [rsp+0x20], xmm2
00007e55d47d9e57  vmovaps [rsp+0x30], xmm3
00007e55d47d9e5d  vmovaps [rsp+0x40], xmm4
00007e55d47d9e63  vmovaps [rsp+0x50], xmm5
00007e55d47d9e69  vmovaps [rsp+0x60], xmm6
00007e55d47d9e6f  vmovaps [rsp+0x70], xmm7
00007e55d47d9e75  vmovaps [rsp+0x80], xmm9
00007e55d47d9e7e  vmovaps [rsp+0x90], xmm10
00007e55d47d9e87  vmovaps [rsp+0xA0], xmm11
00007e55d47d9e90  vmovaps [rsp+0xB0], xmm12
00007e55d47d9e99  vmovaps [rsp+0xC0], xmm13
00007e55d47d9ea2  vmovaps [rsp+0xD0], xmm14
00007e55d47d9eab  vmovaps [rsp+0xE0], xmm15
00007e55d47d9eb4  sub rsp, 0x30
00007e55d47d9eb8  movaps [rsp], xmm8
00007e55d47d9ebd  movaps [rsp+0x10], xmm1
00007e55d47d9ec2  movaps [rsp+0x20], xmm14
00007e55d47d9ec8  lea rdi, [rsp]
00007e55d47d9ecc  mov esi, 0x00
00007e55d47d9ed1  mov rax, 0x55D0734A4530
00007e55d47d9edb  call rax
00007e55d47d9edd  movaps xmm8, [rsp]
00007e55d47d9ee2  add rsp, 0x30
00007e55d47d9ee6  vmovaps xmm0, [rsp]
00007e55d47d9eeb  vmovaps xmm1, [rsp+0x10]
00007e55d47d9ef1  vmovaps xmm2, [rsp+0x20]
00007e55d47d9ef7  vmovaps xmm3, [rsp+0x30]
00007e55d47d9efd  vmovaps xmm4, [rsp+0x40]
00007e55d47d9f03  vmovaps xmm5, [rsp+0x50]
00007e55d47d9f09  vmovaps xmm6, [rsp+0x60]
00007e55d47d9f0f  vmovaps xmm7, [rsp+0x70]
00007e55d47d9f15  vmovaps xmm9, [rsp+0x80]
00007e55d47d9f1e  vmovaps xmm10, [rsp+0x90]
00007e55d47d9f27  vmovaps xmm11, [rsp+0xA0]
00007e55d47d9f30  vmovaps xmm12, [rsp+0xB0]
00007e55d47d9f39  vmovaps xmm13, [rsp+0xC0]
00007e55d47d9f42  vmovaps xmm14, [rsp+0xD0]
00007e55d47d9f4b  vmovaps xmm15, [rsp+0xE0]
00007e55d47d9f54  add rsp, 0xF0
00007e55d47d9f5b  pop r11
00007e55d47d9f5d  pop r10
00007e55d47d9f5f  pop r9
00007e55d47d9f61  pop r8
00007e55d47d9f63  pop rsi
00007e55d47d9f64  pop rdi
00007e55d47d9f65  pop rdx
00007e55d47d9f66  pop rcx
00007e55d47d9f67  pop rax
00007e55d47d9f68  add rsp, 0x08
00007e55d47d9f6c  jmp 0x00007E55D47D63AE
00007e55d47d9f71  sub rsp, 0x08
00007e55d47d9f75  push rax
00007e55d47d9f76  push rcx
00007e55d47d9f77  push rdx
00007e55d47d9f78  push rdi
00007e55d47d9f79  push rsi
00007e55d47d9f7a  push r8
00007e55d47d9f7c  push r9
00007e55d47d9f7e  push r10
00007e55d47d9f80  push r11
00007e55d47d9f82  sub rsp, 0xF0
00007e55d47d9f89  vmovaps [rsp], xmm0
00007e55d47d9f8e  vmovaps [rsp+0x10], xmm1
00007e55d47d9f94  vmovaps [rsp+0x20], xmm2
00007e55d47d9f9a  vmovaps [rsp+0x30], xmm3
00007e55d47d9fa0  vmovaps [rsp+0x40], xmm4
00007e55d47d9fa6  vmovaps [rsp+0x50], xmm5
00007e55d47d9fac  vmovaps [rsp+0x60], xmm7
00007e55d47d9fb2  vmovaps [rsp+0x70], xmm8
00007e55d47d9fb8  vmovaps [rsp+0x80], xmm9
00007e55d47d9fc1  vmovaps [rsp+0x90], xmm10
00007e55d47d9fca  vmovaps [rsp+0xA0], xmm11
00007e55d47d9fd3  vmovaps [rsp+0xB0], xmm12
00007e55d47d9fdc  vmovaps [rsp+0xC0], xmm13
00007e55d47d9fe5  vmovaps [rsp+0xD0], xmm14
00007e55d47d9fee  vmovaps [rsp+0xE0], xmm15
00007e55d47d9ff7  sub rsp, 0x30
00007e55d47d9ffb  movaps [rsp], xmm6
00007e55d47d9fff  movaps [rsp+0x10], xmm1
00007e55d47da004  movaps [rsp+0x20], xmm14
00007e55d47da00a  lea rdi, [rsp]
00007e55d47da00e  mov esi, 0x00
00007e55d47da013  mov rax, 0x55D0734A4530
00007e55d47da01d  call rax
00007e55d47da01f  movaps xmm6, [rsp]
00007e55d47da023  add rsp, 0x30
00007e55d47da027  vmovaps xmm0, [rsp]
00007e55d47da02c  vmovaps xmm1, [rsp+0x10]
00007e55d47da032  vmovaps xmm2, [rsp+0x20]
00007e55d47da038  vmovaps xmm3, [rsp+0x30]
00007e55d47da03e  vmovaps xmm4, [rsp+0x40]
00007e55d47da044  vmovaps xmm5, [rsp+0x50]
00007e55d47da04a  vmovaps xmm7, [rsp+0x60]
00007e55d47da050  vmovaps xmm8, [rsp+0x70]
00007e55d47da056  vmovaps xmm9, [rsp+0x80]
00007e55d47da05f  vmovaps xmm10, [rsp+0x90]
00007e55d47da068  vmovaps xmm11, [rsp+0xA0]
00007e55d47da071  vmovaps xmm12, [rsp+0xB0]
00007e55d47da07a  vmovaps xmm13, [rsp+0xC0]
00007e55d47da083  vmovaps xmm14, [rsp+0xD0]
00007e55d47da08c  vmovaps xmm15, [rsp+0xE0]
00007e55d47da095  add rsp, 0xF0
00007e55d47da09c  pop r11
00007e55d47da09e  pop r10
00007e55d47da0a0  pop r9
00007e55d47da0a2  pop r8
00007e55d47da0a4  pop rsi
00007e55d47da0a5  pop rdi
00007e55d47da0a6  pop rdx
00007e55d47da0a7  pop rcx
00007e55d47da0a8  pop rax
00007e55d47da0a9  add rsp, 0x08
00007e55d47da0ad  jmp 0x00007E55D47D63DA
00007e55d47da0b2  sub rsp, 0x08
00007e55d47da0b6  push rax
00007e55d47da0b7  push rcx
00007e55d47da0b8  push rdx
00007e55d47da0b9  push rdi
00007e55d47da0ba  push rsi
00007e55d47da0bb  push r8
00007e55d47da0bd  push r9
00007e55d47da0bf  push r10
00007e55d47da0c1  push r11
00007e55d47da0c3  sub rsp, 0xF0
00007e55d47da0ca  vmovaps [rsp], xmm0
00007e55d47da0cf  vmovaps [rsp+0x10], xmm1
00007e55d47da0d5  vmovaps [rsp+0x20], xmm2
00007e55d47da0db  vmovaps [rsp+0x30], xmm3
00007e55d47da0e1  vmovaps [rsp+0x40], xmm4
00007e55d47da0e7  vmovaps [rsp+0x50], xmm5
00007e55d47da0ed  vmovaps [rsp+0x60], xmm6
00007e55d47da0f3  vmovaps [rsp+0x70], xmm7
00007e55d47da0f9  vmovaps [rsp+0x80], xmm8
00007e55d47da102  vmovaps [rsp+0x90], xmm9
00007e55d47da10b  vmovaps [rsp+0xA0], xmm10
00007e55d47da114  vmovaps [rsp+0xB0], xmm11
00007e55d47da11d  vmovaps [rsp+0xC0], xmm12
00007e55d47da126  vmovaps [rsp+0xD0], xmm13
00007e55d47da12f  vmovaps [rsp+0xE0], xmm15
00007e55d47da138  sub rsp, 0x30
00007e55d47da13c  movaps [rsp], xmm14
00007e55d47da141  movaps [rsp+0x10], xmm12
00007e55d47da147  movaps [rsp+0x20], xmm1
00007e55d47da14c  lea rdi, [rsp]
00007e55d47da150  mov esi, 0x00
00007e55d47da155  mov rax, 0x55D0734A4530
00007e55d47da15f  call rax
00007e55d47da161  movaps xmm14, [rsp]
00007e55d47da166  add rsp, 0x30
00007e55d47da16a  vmovaps xmm0, [rsp]
00007e55d47da16f  vmovaps xmm1, [rsp+0x10]
00007e55d47da175  vmovaps xmm2, [rsp+0x20]
00007e55d47da17b  vmovaps xmm3, [rsp+0x30]
00007e55d47da181  vmovaps xmm4, [rsp+0x40]
00007e55d47da187  vmovaps xmm5, [rsp+0x50]
00007e55d47da18d  vmovaps xmm6, [rsp+0x60]
00007e55d47da193  vmovaps xmm7, [rsp+0x70]
00007e55d47da199  vmovaps xmm8, [rsp+0x80]
00007e55d47da1a2  vmovaps xmm9, [rsp+0x90]
00007e55d47da1ab  vmovaps xmm10, [rsp+0xA0]
00007e55d47da1b4  vmovaps xmm11, [rsp+0xB0]
00007e55d47da1bd  vmovaps xmm12, [rsp+0xC0]
00007e55d47da1c6  vmovaps xmm13, [rsp+0xD0]
00007e55d47da1cf  vmovaps xmm15, [rsp+0xE0]
00007e55d47da1d8  add rsp, 0xF0
00007e55d47da1df  pop r11
00007e55d47da1e1  pop r10
00007e55d47da1e3  pop r9
00007e55d47da1e5  pop r8
00007e55d47da1e7  pop rsi
00007e55d47da1e8  pop rdi
00007e55d47da1e9  pop rdx
00007e55d47da1ea  pop rcx
00007e55d47da1eb  pop rax
00007e55d47da1ec  add rsp, 0x08
00007e55d47da1f0  jmp 0x00007E55D47D6400
00007e55d47da1f5  sub rsp, 0x08
00007e55d47da1f9  push rax
00007e55d47da1fa  push rcx
00007e55d47da1fb  push rdx
00007e55d47da1fc  push rdi
00007e55d47da1fd  push rsi
00007e55d47da1fe  push r8
00007e55d47da200  push r9
00007e55d47da202  push r10
00007e55d47da204  push r11
00007e55d47da206  sub rsp, 0xF0
00007e55d47da20d  vmovaps [rsp], xmm0
00007e55d47da212  vmovaps [rsp+0x10], xmm2
00007e55d47da218  vmovaps [rsp+0x20], xmm3
00007e55d47da21e  vmovaps [rsp+0x30], xmm4
00007e55d47da224  vmovaps [rsp+0x40], xmm5
00007e55d47da22a  vmovaps [rsp+0x50], xmm6
00007e55d47da230  vmovaps [rsp+0x60], xmm7
00007e55d47da236  vmovaps [rsp+0x70], xmm8
00007e55d47da23c  vmovaps [rsp+0x80], xmm9
00007e55d47da245  vmovaps [rsp+0x90], xmm10
00007e55d47da24e  vmovaps [rsp+0xA0], xmm11
00007e55d47da257  vmovaps [rsp+0xB0], xmm12
00007e55d47da260  vmovaps [rsp+0xC0], xmm13
00007e55d47da269  vmovaps [rsp+0xD0], xmm14
00007e55d47da272  vmovaps [rsp+0xE0], xmm15
00007e55d47da27b  sub rsp, 0x30
00007e55d47da27f  movaps [rsp], xmm1
00007e55d47da283  movaps [rsp+0x10], xmm13
00007e55d47da289  movaps [rsp+0x20], xmm9
00007e55d47da28f  lea rdi, [rsp]
00007e55d47da293  mov esi, 0x00
00007e55d47da298  mov rax, 0x55D0734A4530
00007e55d47da2a2  call rax
00007e55d47da2a4  movaps xmm1, [rsp]
00007e55d47da2a8  add rsp, 0x30
00007e55d47da2ac  vmovaps xmm0, [rsp]
00007e55d47da2b1  vmovaps xmm2, [rsp+0x10]
00007e55d47da2b7  vmovaps xmm3, [rsp+0x20]
00007e55d47da2bd  vmovaps xmm4, [rsp+0x30]
00007e55d47da2c3  vmovaps xmm5, [rsp+0x40]
00007e55d47da2c9  vmovaps xmm6, [rsp+0x50]
00007e55d47da2cf  vmovaps xmm7, [rsp+0x60]
00007e55d47da2d5  vmovaps xmm8, [rsp+0x70]
00007e55d47da2db  vmovaps xmm9, [rsp+0x80]
00007e55d47da2e4  vmovaps xmm10, [rsp+0x90]
00007e55d47da2ed  vmovaps xmm11, [rsp+0xA0]
00007e55d47da2f6  vmovaps xmm12, [rsp+0xB0]
00007e55d47da2ff  vmovaps xmm13, [rsp+0xC0]
00007e55d47da308  vmovaps xmm14, [rsp+0xD0]
00007e55d47da311  vmovaps xmm15, [rsp+0xE0]
00007e55d47da31a  add rsp, 0xF0
00007e55d47da321  pop r11
00007e55d47da323  pop r10
00007e55d47da325  pop r9
00007e55d47da327  pop r8
00007e55d47da329  pop rsi
00007e55d47da32a  pop rdi
00007e55d47da32b  pop rdx
00007e55d47da32c  pop rcx
00007e55d47da32d  pop rax
00007e55d47da32e  add rsp, 0x08
00007e55d47da332  jmp 0x00007E55D47D641A
00007e55d47da337  sub rsp, 0x08
00007e55d47da33b  push rax
00007e55d47da33c  push rcx
00007e55d47da33d  push rdx
00007e55d47da33e  push rdi
00007e55d47da33f  push rsi
00007e55d47da340  push r8
00007e55d47da342  push r9
00007e55d47da344  push r10
00007e55d47da346  push r11
00007e55d47da348  sub rsp, 0xF0
00007e55d47da34f  vmovaps [rsp], xmm0
00007e55d47da354  vmovaps [rsp+0x10], xmm1
00007e55d47da35a  vmovaps [rsp+0x20], xmm2
00007e55d47da360  vmovaps [rsp+0x30], xmm3
00007e55d47da366  vmovaps [rsp+0x40], xmm4
00007e55d47da36c  vmovaps [rsp+0x50], xmm5
00007e55d47da372  vmovaps [rsp+0x60], xmm6
00007e55d47da378  vmovaps [rsp+0x70], xmm7
00007e55d47da37e  vmovaps [rsp+0x80], xmm8
00007e55d47da387  vmovaps [rsp+0x90], xmm9
00007e55d47da390  vmovaps [rsp+0xA0], xmm10
00007e55d47da399  vmovaps [rsp+0xB0], xmm11
00007e55d47da3a2  vmovaps [rsp+0xC0], xmm13
00007e55d47da3ab  vmovaps [rsp+0xD0], xmm14
00007e55d47da3b4  vmovaps [rsp+0xE0], xmm15
00007e55d47da3bd  sub rsp, 0x30
00007e55d47da3c1  movaps [rsp], xmm12
00007e55d47da3c6  movaps [rsp+0x10], xmm7
00007e55d47da3cb  movaps [rsp+0x20], xmm13
00007e55d47da3d1  lea rdi, [rsp]
00007e55d47da3d5  mov esi, 0x00
00007e55d47da3da  mov rax, 0x55D0734A4530
00007e55d47da3e4  call rax
00007e55d47da3e6  movaps xmm12, [rsp]
00007e55d47da3eb  add rsp, 0x30
00007e55d47da3ef  vmovaps xmm0, [rsp]
00007e55d47da3f4  vmovaps xmm1, [rsp+0x10]
00007e55d47da3fa  vmovaps xmm2, [rsp+0x20]
00007e55d47da400  vmovaps xmm3, [rsp+0x30]
00007e55d47da406  vmovaps xmm4, [rsp+0x40]
00007e55d47da40c  vmovaps xmm5, [rsp+0x50]
00007e55d47da412  vmovaps xmm6, [rsp+0x60]
00007e55d47da418  vmovaps xmm7, [rsp+0x70]
00007e55d47da41e  vmovaps xmm8, [rsp+0x80]
00007e55d47da427  vmovaps xmm9, [rsp+0x90]
00007e55d47da430  vmovaps xmm10, [rsp+0xA0]
00007e55d47da439  vmovaps xmm11, [rsp+0xB0]
00007e55d47da442  vmovaps xmm13, [rsp+0xC0]
00007e55d47da44b  vmovaps xmm14, [rsp+0xD0]
00007e55d47da454  vmovaps xmm15, [rsp+0xE0]
00007e55d47da45d  add rsp, 0xF0
00007e55d47da464  pop r11
00007e55d47da466  pop r10
00007e55d47da468  pop r9
00007e55d47da46a  pop r8
00007e55d47da46c  pop rsi
00007e55d47da46d  pop rdi
00007e55d47da46e  pop rdx
00007e55d47da46f  pop rcx
00007e55d47da470  pop rax
00007e55d47da471  add rsp, 0x08
00007e55d47da475  jmp 0x00007E55D47D6441
00007e55d47da47a  sub rsp, 0x08
00007e55d47da47e  push rax
00007e55d47da47f  push rcx
00007e55d47da480  push rdx
00007e55d47da481  push rdi
00007e55d47da482  push rsi
00007e55d47da483  push r8
00007e55d47da485  push r9
00007e55d47da487  push r10
00007e55d47da489  push r11
00007e55d47da48b  sub rsp, 0xF0
00007e55d47da492  vmovaps [rsp], xmm0
00007e55d47da497  vmovaps [rsp+0x10], xmm1
00007e55d47da49d  vmovaps [rsp+0x20], xmm2
00007e55d47da4a3  vmovaps [rsp+0x30], xmm3
00007e55d47da4a9  vmovaps [rsp+0x40], xmm4
00007e55d47da4af  vmovaps [rsp+0x50], xmm5
00007e55d47da4b5  vmovaps [rsp+0x60], xmm6
00007e55d47da4bb  vmovaps [rsp+0x70], xmm7
00007e55d47da4c1  vmovaps [rsp+0x80], xmm8
00007e55d47da4ca  vmovaps [rsp+0x90], xmm9
00007e55d47da4d3  vmovaps [rsp+0xA0], xmm10
00007e55d47da4dc  vmovaps [rsp+0xB0], xmm11
00007e55d47da4e5  vmovaps [rsp+0xC0], xmm12
00007e55d47da4ee  vmovaps [rsp+0xD0], xmm14
00007e55d47da4f7  vmovaps [rsp+0xE0], xmm15
00007e55d47da500  sub rsp, 0x30
00007e55d47da504  movaps [rsp], xmm13
00007e55d47da509  movaps [rsp+0x10], xmm15
00007e55d47da50f  movaps [rsp+0x20], xmm8
00007e55d47da515  lea rdi, [rsp]
00007e55d47da519  mov esi, 0x00
00007e55d47da51e  mov rax, 0x55D0734A4530
00007e55d47da528  call rax
00007e55d47da52a  movaps xmm13, [rsp]
00007e55d47da52f  add rsp, 0x30
00007e55d47da533  vmovaps xmm0, [rsp]
00007e55d47da538  vmovaps xmm1, [rsp+0x10]
00007e55d47da53e  vmovaps xmm2, [rsp+0x20]
00007e55d47da544  vmovaps xmm3, [rsp+0x30]
00007e55d47da54a  vmovaps xmm4, [rsp+0x40]
00007e55d47da550  vmovaps xmm5, [rsp+0x50]
00007e55d47da556  vmovaps xmm6, [rsp+0x60]
00007e55d47da55c  vmovaps xmm7, [rsp+0x70]
00007e55d47da562  vmovaps xmm8, [rsp+0x80]
00007e55d47da56b  vmovaps xmm9, [rsp+0x90]
00007e55d47da574  vmovaps xmm10, [rsp+0xA0]
00007e55d47da57d  vmovaps xmm11, [rsp+0xB0]
00007e55d47da586  vmovaps xmm12, [rsp+0xC0]
00007e55d47da58f  vmovaps xmm14, [rsp+0xD0]
00007e55d47da598  vmovaps xmm15, [rsp+0xE0]
00007e55d47da5a1  add rsp, 0xF0
00007e55d47da5a8  pop r11
00007e55d47da5aa  pop r10
00007e55d47da5ac  pop r9
00007e55d47da5ae  pop r8
00007e55d47da5b0  pop rsi
00007e55d47da5b1  pop rdi
00007e55d47da5b2  pop rdx
00007e55d47da5b3  pop rcx
00007e55d47da5b4  pop rax
00007e55d47da5b5  add rsp, 0x08
00007e55d47da5b9  jmp 0x00007E55D47D645C
00007e55d47da5be  sub rsp, 0x08
00007e55d47da5c2  push rax
00007e55d47da5c3  push rcx
00007e55d47da5c4  push rdx
00007e55d47da5c5  push rdi
00007e55d47da5c6  push rsi
00007e55d47da5c7  push r8
00007e55d47da5c9  push r9
00007e55d47da5cb  push r10
00007e55d47da5cd  push r11
00007e55d47da5cf  sub rsp, 0xF0
00007e55d47da5d6  vmovaps [rsp], xmm0
00007e55d47da5db  vmovaps [rsp+0x10], xmm1
00007e55d47da5e1  vmovaps [rsp+0x20], xmm2
00007e55d47da5e7  vmovaps [rsp+0x30], xmm3
00007e55d47da5ed  vmovaps [rsp+0x40], xmm4
00007e55d47da5f3  vmovaps [rsp+0x50], xmm5
00007e55d47da5f9  vmovaps [rsp+0x60], xmm6
00007e55d47da5ff  vmovaps [rsp+0x70], xmm7
00007e55d47da605  vmovaps [rsp+0x80], xmm9
00007e55d47da60e  vmovaps [rsp+0x90], xmm10
00007e55d47da617  vmovaps [rsp+0xA0], xmm11
00007e55d47da620  vmovaps [rsp+0xB0], xmm12
00007e55d47da629  vmovaps [rsp+0xC0], xmm13
00007e55d47da632  vmovaps [rsp+0xD0], xmm14
00007e55d47da63b  vmovaps [rsp+0xE0], xmm15
00007e55d47da644  sub rsp, 0x30
00007e55d47da648  movaps [rsp], xmm8
00007e55d47da64d  movaps [rsp+0x10], xmm15
00007e55d47da653  movaps [rsp+0x20], xmm9
00007e55d47da659  lea rdi, [rsp]
00007e55d47da65d  mov esi, 0x00
00007e55d47da662  mov rax, 0x55D0734A4530
00007e55d47da66c  call rax
00007e55d47da66e  movaps xmm8, [rsp]
00007e55d47da673  add rsp, 0x30
00007e55d47da677  vmovaps xmm0, [rsp]
00007e55d47da67c  vmovaps xmm1, [rsp+0x10]
00007e55d47da682  vmovaps xmm2, [rsp+0x20]
00007e55d47da688  vmovaps xmm3, [rsp+0x30]
00007e55d47da68e  vmovaps xmm4, [rsp+0x40]
00007e55d47da694  vmovaps xmm5, [rsp+0x50]
00007e55d47da69a  vmovaps xmm6, [rsp+0x60]
00007e55d47da6a0  vmovaps xmm7, [rsp+0x70]
00007e55d47da6a6  vmovaps xmm9, [rsp+0x80]
00007e55d47da6af  vmovaps xmm10, [rsp+0x90]
00007e55d47da6b8  vmovaps xmm11, [rsp+0xA0]
00007e55d47da6c1  vmovaps xmm12, [rsp+0xB0]
00007e55d47da6ca  vmovaps xmm13, [rsp+0xC0]
00007e55d47da6d3  vmovaps xmm14, [rsp+0xD0]
00007e55d47da6dc  vmovaps xmm15, [rsp+0xE0]
00007e55d47da6e5  add rsp, 0xF0
00007e55d47da6ec  pop r11
00007e55d47da6ee  pop r10
00007e55d47da6f0  pop r9
00007e55d47da6f2  pop r8
00007e55d47da6f4  pop rsi
00007e55d47da6f5  pop rdi
00007e55d47da6f6  pop rdx
00007e55d47da6f7  pop rcx
00007e55d47da6f8  pop rax
00007e55d47da6f9  add rsp, 0x08
00007e55d47da6fd  jmp 0x00007E55D47D648A
00007e55d47da702  sub rsp, 0x08
00007e55d47da706  push rax
00007e55d47da707  push rcx
00007e55d47da708  push rdx
00007e55d47da709  push rdi
00007e55d47da70a  push rsi
00007e55d47da70b  push r8
00007e55d47da70d  push r9
00007e55d47da70f  push r10
00007e55d47da711  push r11
00007e55d47da713  sub rsp, 0xF0
00007e55d47da71a  vmovaps [rsp], xmm0
00007e55d47da71f  vmovaps [rsp+0x10], xmm1
00007e55d47da725  vmovaps [rsp+0x20], xmm2
00007e55d47da72b  vmovaps [rsp+0x30], xmm3
00007e55d47da731  vmovaps [rsp+0x40], xmm4
00007e55d47da737  vmovaps [rsp+0x50], xmm5
00007e55d47da73d  vmovaps [rsp+0x60], xmm6
00007e55d47da743  vmovaps [rsp+0x70], xmm7
00007e55d47da749  vmovaps [rsp+0x80], xmm8
00007e55d47da752  vmovaps [rsp+0x90], xmm9
00007e55d47da75b  vmovaps [rsp+0xA0], xmm10
00007e55d47da764  vmovaps [rsp+0xB0], xmm11
00007e55d47da76d  vmovaps [rsp+0xC0], xmm12
00007e55d47da776  vmovaps [rsp+0xD0], xmm13
00007e55d47da77f  vmovaps [rsp+0xE0], xmm14
00007e55d47da788  sub rsp, 0x30
00007e55d47da78c  movaps [rsp], xmm15
00007e55d47da791  movaps [rsp+0x10], xmm11
00007e55d47da797  movaps [rsp+0x20], xmm6
00007e55d47da79c  lea rdi, [rsp]
00007e55d47da7a0  mov esi, 0x00
00007e55d47da7a5  mov rax, 0x55D0734A4530
00007e55d47da7af  call rax
00007e55d47da7b1  movaps xmm15, [rsp]
00007e55d47da7b6  add rsp, 0x30
00007e55d47da7ba  vmovaps xmm0, [rsp]
00007e55d47da7bf  vmovaps xmm1, [rsp+0x10]
00007e55d47da7c5  vmovaps xmm2, [rsp+0x20]
00007e55d47da7cb  vmovaps xmm3, [rsp+0x30]
00007e55d47da7d1  vmovaps xmm4, [rsp+0x40]
00007e55d47da7d7  vmovaps xmm5, [rsp+0x50]
00007e55d47da7dd  vmovaps xmm6, [rsp+0x60]
00007e55d47da7e3  vmovaps xmm7, [rsp+0x70]
00007e55d47da7e9  vmovaps xmm8, [rsp+0x80]
00007e55d47da7f2  vmovaps xmm9, [rsp+0x90]
00007e55d47da7fb  vmovaps xmm10, [rsp+0xA0]
00007e55d47da804  vmovaps xmm11, [rsp+0xB0]
00007e55d47da80d  vmovaps xmm12, [rsp+0xC0]
00007e55d47da816  vmovaps xmm13, [rsp+0xD0]
00007e55d47da81f  vmovaps xmm14, [rsp+0xE0]
00007e55d47da828  add rsp, 0xF0
00007e55d47da82f  pop r11
00007e55d47da831  pop r10
00007e55d47da833  pop r9
00007e55d47da835  pop r8
00007e55d47da837  pop rsi
00007e55d47da838  pop rdi
00007e55d47da839  pop rdx
00007e55d47da83a  pop rcx
00007e55d47da83b  pop rax
00007e55d47da83c  add rsp, 0x08
00007e55d47da840  jmp 0x00007E55D47D64A5
00007e55d47da845  sub rsp, 0x08
00007e55d47da849  push rax
00007e55d47da84a  push rcx
00007e55d47da84b  push rdx
00007e55d47da84c  push rdi
00007e55d47da84d  push rsi
00007e55d47da84e  push r8
00007e55d47da850  push r9
00007e55d47da852  push r10
00007e55d47da854  push r11
00007e55d47da856  sub rsp, 0xF0
00007e55d47da85d  vmovaps [rsp], xmm0
00007e55d47da862  vmovaps [rsp+0x10], xmm1
00007e55d47da868  vmovaps [rsp+0x20], xmm2
00007e55d47da86e  vmovaps [rsp+0x30], xmm3
00007e55d47da874  vmovaps [rsp+0x40], xmm4
00007e55d47da87a  vmovaps [rsp+0x50], xmm5
00007e55d47da880  vmovaps [rsp+0x60], xmm6
00007e55d47da886  vmovaps [rsp+0x70], xmm8
00007e55d47da88c  vmovaps [rsp+0x80], xmm9
00007e55d47da895  vmovaps [rsp+0x90], xmm10
00007e55d47da89e  vmovaps [rsp+0xA0], xmm11
00007e55d47da8a7  vmovaps [rsp+0xB0], xmm12
00007e55d47da8b0  vmovaps [rsp+0xC0], xmm13
00007e55d47da8b9  vmovaps [rsp+0xD0], xmm14
00007e55d47da8c2  vmovaps [rsp+0xE0], xmm15
00007e55d47da8cb  sub rsp, 0x30
00007e55d47da8cf  movaps [rsp], xmm7
00007e55d47da8d3  movaps [rsp+0x10], xmm11
00007e55d47da8d9  movaps [rsp+0x20], xmm9
00007e55d47da8df  lea rdi, [rsp]
00007e55d47da8e3  mov esi, 0x00
00007e55d47da8e8  mov rax, 0x55D0734A4530
00007e55d47da8f2  call rax
00007e55d47da8f4  movaps xmm7, [rsp]
00007e55d47da8f8  add rsp, 0x30
00007e55d47da8fc  vmovaps xmm0, [rsp]
00007e55d47da901  vmovaps xmm1, [rsp+0x10]
00007e55d47da907  vmovaps xmm2, [rsp+0x20]
00007e55d47da90d  vmovaps xmm3, [rsp+0x30]
00007e55d47da913  vmovaps xmm4, [rsp+0x40]
00007e55d47da919  vmovaps xmm5, [rsp+0x50]
00007e55d47da91f  vmovaps xmm6, [rsp+0x60]
00007e55d47da925  vmovaps xmm8, [rsp+0x70]
00007e55d47da92b  vmovaps xmm9, [rsp+0x80]
00007e55d47da934  vmovaps xmm10, [rsp+0x90]
00007e55d47da93d  vmovaps xmm11, [rsp+0xA0]
00007e55d47da946  vmovaps xmm12, [rsp+0xB0]
00007e55d47da94f  vmovaps xmm13, [rsp+0xC0]
00007e55d47da958  vmovaps xmm14, [rsp+0xD0]
00007e55d47da961  vmovaps xmm15, [rsp+0xE0]
00007e55d47da96a  add rsp, 0xF0
00007e55d47da971  pop r11
00007e55d47da973  pop r10
00007e55d47da975  pop r9
00007e55d47da977  pop r8
00007e55d47da979  pop rsi
00007e55d47da97a  pop rdi
00007e55d47da97b  pop rdx
00007e55d47da97c  pop rcx
00007e55d47da97d  pop rax
00007e55d47da97e  add rsp, 0x08
00007e55d47da982  jmp 0x00007E55D47D64D2
00007e55d47da987  sub rsp, 0x08
00007e55d47da98b  push rax
00007e55d47da98c  push rcx
00007e55d47da98d  push rdx
00007e55d47da98e  push rdi
00007e55d47da98f  push rsi
00007e55d47da990  push r8
00007e55d47da992  push r9
00007e55d47da994  push r10
00007e55d47da996  push r11
00007e55d47da998  sub rsp, 0xF0
00007e55d47da99f  vmovaps [rsp], xmm0
00007e55d47da9a4  vmovaps [rsp+0x10], xmm1
00007e55d47da9aa  vmovaps [rsp+0x20], xmm2
00007e55d47da9b0  vmovaps [rsp+0x30], xmm3
00007e55d47da9b6  vmovaps [rsp+0x40], xmm4
00007e55d47da9bc  vmovaps [rsp+0x50], xmm5
00007e55d47da9c2  vmovaps [rsp+0x60], xmm6
00007e55d47da9c8  vmovaps [rsp+0x70], xmm7
00007e55d47da9ce  vmovaps [rsp+0x80], xmm8
00007e55d47da9d7  vmovaps [rsp+0x90], xmm9
00007e55d47da9e0  vmovaps [rsp+0xA0], xmm10
00007e55d47da9e9  vmovaps [rsp+0xB0], xmm12
00007e55d47da9f2  vmovaps [rsp+0xC0], xmm13
00007e55d47da9fb  vmovaps [rsp+0xD0], xmm14
00007e55d47daa04  vmovaps [rsp+0xE0], xmm15
00007e55d47daa0d  sub rsp, 0x30
00007e55d47daa11  movaps [rsp], xmm11
00007e55d47daa16  movaps [rsp+0x10], xmm10
00007e55d47daa1c  movaps [rsp+0x20], xmm14
00007e55d47daa22  lea rdi, [rsp]
00007e55d47daa26  mov esi, 0x00
00007e55d47daa2b  mov rax, 0x55D0734A4530
00007e55d47daa35  call rax
00007e55d47daa37  movaps xmm11, [rsp]
00007e55d47daa3c  add rsp, 0x30
00007e55d47daa40  vmovaps xmm0, [rsp]
00007e55d47daa45  vmovaps xmm1, [rsp+0x10]
00007e55d47daa4b  vmovaps xmm2, [rsp+0x20]
00007e55d47daa51  vmovaps xmm3, [rsp+0x30]
00007e55d47daa57  vmovaps xmm4, [rsp+0x40]
00007e55d47daa5d  vmovaps xmm5, [rsp+0x50]
00007e55d47daa63  vmovaps xmm6, [rsp+0x60]
00007e55d47daa69  vmovaps xmm7, [rsp+0x70]
00007e55d47daa6f  vmovaps xmm8, [rsp+0x80]
00007e55d47daa78  vmovaps xmm9, [rsp+0x90]
00007e55d47daa81  vmovaps xmm10, [rsp+0xA0]
00007e55d47daa8a  vmovaps xmm12, [rsp+0xB0]
00007e55d47daa93  vmovaps xmm13, [rsp+0xC0]
00007e55d47daa9c  vmovaps xmm14, [rsp+0xD0]
00007e55d47daaa5  vmovaps xmm15, [rsp+0xE0]
00007e55d47daaae  add rsp, 0xF0
00007e55d47daab5  pop r11
00007e55d47daab7  pop r10
00007e55d47daab9  pop r9
00007e55d47daabb  pop r8
00007e55d47daabd  pop rsi
00007e55d47daabe  pop rdi
00007e55d47daabf  pop rdx
00007e55d47daac0  pop rcx
00007e55d47daac1  pop rax
00007e55d47daac2  add rsp, 0x08
00007e55d47daac6  jmp 0x00007E55D47D64ED
00007e55d47daacb  call 0x00007E55D46E45A0
00007e55d47daad0  jmp 0x00007E55D47D64F7
00007e55d47daad5  sub rsp, 0x08
00007e55d47daad9  push rax
00007e55d47daada  push rcx
00007e55d47daadb  push rdx
00007e55d47daadc  push rdi
00007e55d47daadd  push rsi
00007e55d47daade  push r8
00007e55d47daae0  push r9
00007e55d47daae2  push r10
00007e55d47daae4  push r11
00007e55d47daae6  sub rsp, 0xF0
00007e55d47daaed  vmovaps [rsp], xmm0
00007e55d47daaf2  vmovaps [rsp+0x10], xmm1
00007e55d47daaf8  vmovaps [rsp+0x20], xmm2
00007e55d47daafe  vmovaps [rsp+0x30], xmm3
00007e55d47dab04  vmovaps [rsp+0x40], xmm4
00007e55d47dab0a  vmovaps [rsp+0x50], xmm5
00007e55d47dab10  vmovaps [rsp+0x60], xmm6
00007e55d47dab16  vmovaps [rsp+0x70], xmm7
00007e55d47dab1c  vmovaps [rsp+0x80], xmm8
00007e55d47dab25  vmovaps [rsp+0x90], xmm9
00007e55d47dab2e  vmovaps [rsp+0xA0], xmm11
00007e55d47dab37  vmovaps [rsp+0xB0], xmm12
00007e55d47dab40  vmovaps [rsp+0xC0], xmm13
00007e55d47dab49  vmovaps [rsp+0xD0], xmm14
00007e55d47dab52  vmovaps [rsp+0xE0], xmm15
00007e55d47dab5b  sub rsp, 0x30
00007e55d47dab5f  movaps [rsp], xmm10
00007e55d47dab64  movaps [rsp+0x10], xmm1
00007e55d47dab69  movaps [rsp+0x20], xmm12
00007e55d47dab6f  lea rdi, [rsp]
00007e55d47dab73  mov esi, 0x00
00007e55d47dab78  mov rax, 0x55D0734A4530
00007e55d47dab82  call rax
00007e55d47dab84  movaps xmm10, [rsp]
00007e55d47dab89  add rsp, 0x30
00007e55d47dab8d  vmovaps xmm0, [rsp]
00007e55d47dab92  vmovaps xmm1, [rsp+0x10]
00007e55d47dab98  vmovaps xmm2, [rsp+0x20]
00007e55d47dab9e  vmovaps xmm3, [rsp+0x30]
00007e55d47daba4  vmovaps xmm4, [rsp+0x40]
00007e55d47dabaa  vmovaps xmm5, [rsp+0x50]
00007e55d47dabb0  vmovaps xmm6, [rsp+0x60]
00007e55d47dabb6  vmovaps xmm7, [rsp+0x70]
00007e55d47dabbc  vmovaps xmm8, [rsp+0x80]
00007e55d47dabc5  vmovaps xmm9, [rsp+0x90]
00007e55d47dabce  vmovaps xmm11, [rsp+0xA0]
00007e55d47dabd7  vmovaps xmm12, [rsp+0xB0]
00007e55d47dabe0  vmovaps xmm13, [rsp+0xC0]
00007e55d47dabe9  vmovaps xmm14, [rsp+0xD0]
00007e55d47dabf2  vmovaps xmm15, [rsp+0xE0]
00007e55d47dabfb  add rsp, 0xF0
00007e55d47dac02  pop r11
00007e55d47dac04  pop r10
00007e55d47dac06  pop r9
00007e55d47dac08  pop r8
00007e55d47dac0a  pop rsi
00007e55d47dac0b  pop rdi
00007e55d47dac0c  pop rdx
00007e55d47dac0d  pop rcx
00007e55d47dac0e  pop rax
00007e55d47dac0f  add rsp, 0x08
00007e55d47dac13  jmp 0x00007E55D47D651A
00007e55d47dac18  sub rsp, 0x08
00007e55d47dac1c  push rax
00007e55d47dac1d  push rcx
00007e55d47dac1e  push rdx
00007e55d47dac1f  push rdi
00007e55d47dac20  push rsi
00007e55d47dac21  push r8
00007e55d47dac23  push r9
00007e55d47dac25  push r10
00007e55d47dac27  push r11
00007e55d47dac29  sub rsp, 0xF0
00007e55d47dac30  vmovaps [rsp], xmm0
00007e55d47dac35  vmovaps [rsp+0x10], xmm1
00007e55d47dac3b  vmovaps [rsp+0x20], xmm2
00007e55d47dac41  vmovaps [rsp+0x30], xmm3
00007e55d47dac47  vmovaps [rsp+0x40], xmm4
00007e55d47dac4d  vmovaps [rsp+0x50], xmm5
00007e55d47dac53  vmovaps [rsp+0x60], xmm6
00007e55d47dac59  vmovaps [rsp+0x70], xmm7
00007e55d47dac5f  vmovaps [rsp+0x80], xmm8
00007e55d47dac68  vmovaps [rsp+0x90], xmm9
00007e55d47dac71  vmovaps [rsp+0xA0], xmm10
00007e55d47dac7a  vmovaps [rsp+0xB0], xmm11
00007e55d47dac83  vmovaps [rsp+0xC0], xmm13
00007e55d47dac8c  vmovaps [rsp+0xD0], xmm14
00007e55d47dac95  vmovaps [rsp+0xE0], xmm15
00007e55d47dac9e  sub rsp, 0x30
00007e55d47daca2  movaps [rsp], xmm12
00007e55d47daca7  movaps [rsp+0x10], xmm14
00007e55d47dacad  movaps [rsp+0x20], xmm1
00007e55d47dacb2  lea rdi, [rsp]
00007e55d47dacb6  mov esi, 0x00
00007e55d47dacbb  mov rax, 0x55D0734A4530
00007e55d47dacc5  call rax
00007e55d47dacc7  movaps xmm12, [rsp]
00007e55d47daccc  add rsp, 0x30
00007e55d47dacd0  vmovaps xmm0, [rsp]
00007e55d47dacd5  vmovaps xmm1, [rsp+0x10]
00007e55d47dacdb  vmovaps xmm2, [rsp+0x20]
00007e55d47dace1  vmovaps xmm3, [rsp+0x30]
00007e55d47dace7  vmovaps xmm4, [rsp+0x40]
00007e55d47daced  vmovaps xmm5, [rsp+0x50]
00007e55d47dacf3  vmovaps xmm6, [rsp+0x60]
00007e55d47dacf9  vmovaps xmm7, [rsp+0x70]
00007e55d47dacff  vmovaps xmm8, [rsp+0x80]
00007e55d47dad08  vmovaps xmm9, [rsp+0x90]
00007e55d47dad11  vmovaps xmm10, [rsp+0xA0]
00007e55d47dad1a  vmovaps xmm11, [rsp+0xB0]
00007e55d47dad23  vmovaps xmm13, [rsp+0xC0]
00007e55d47dad2c  vmovaps xmm14, [rsp+0xD0]
00007e55d47dad35  vmovaps xmm15, [rsp+0xE0]
00007e55d47dad3e  add rsp, 0xF0
00007e55d47dad45  pop r11
00007e55d47dad47  pop r10
00007e55d47dad49  pop r9
00007e55d47dad4b  pop r8
00007e55d47dad4d  pop rsi
00007e55d47dad4e  pop rdi
00007e55d47dad4f  pop rdx
00007e55d47dad50  pop rcx
00007e55d47dad51  pop rax
00007e55d47dad52  add rsp, 0x08
00007e55d47dad56  jmp 0x00007E55D47D6549
00007e55d47dad5b  sub rsp, 0x08
00007e55d47dad5f  push rax
00007e55d47dad60  push rcx
00007e55d47dad61  push rdx
00007e55d47dad62  push rdi
00007e55d47dad63  push rsi
00007e55d47dad64  push r8
00007e55d47dad66  push r9
00007e55d47dad68  push r10
00007e55d47dad6a  push r11
00007e55d47dad6c  sub rsp, 0xF0
00007e55d47dad73  vmovaps [rsp], xmm0
00007e55d47dad78  vmovaps [rsp+0x10], xmm1
00007e55d47dad7e  vmovaps [rsp+0x20], xmm2
00007e55d47dad84  vmovaps [rsp+0x30], xmm3
00007e55d47dad8a  vmovaps [rsp+0x40], xmm4
00007e55d47dad90  vmovaps [rsp+0x50], xmm5
00007e55d47dad96  vmovaps [rsp+0x60], xmm6
00007e55d47dad9c  vmovaps [rsp+0x70], xmm7
00007e55d47dada2  vmovaps [rsp+0x80], xmm8
00007e55d47dadab  vmovaps [rsp+0x90], xmm9
00007e55d47dadb4  vmovaps [rsp+0xA0], xmm10
00007e55d47dadbd  vmovaps [rsp+0xB0], xmm11
00007e55d47dadc6  vmovaps [rsp+0xC0], xmm12
00007e55d47dadcf  vmovaps [rsp+0xD0], xmm13
00007e55d47dadd8  vmovaps [rsp+0xE0], xmm15
00007e55d47dade1  sub rsp, 0x30
00007e55d47dade5  movaps [rsp], xmm14
00007e55d47dadea  movaps [rsp+0x10], xmm9
00007e55d47dadf0  movaps [rsp+0x20], xmm1
00007e55d47dadf5  lea rdi, [rsp]
00007e55d47dadf9  mov esi, 0x00
00007e55d47dadfe  mov rax, 0x55D0734A4530
00007e55d47dae08  call rax
00007e55d47dae0a  movaps xmm14, [rsp]
00007e55d47dae0f  add rsp, 0x30
00007e55d47dae13  vmovaps xmm0, [rsp]
00007e55d47dae18  vmovaps xmm1, [rsp+0x10]
00007e55d47dae1e  vmovaps xmm2, [rsp+0x20]
00007e55d47dae24  vmovaps xmm3, [rsp+0x30]
00007e55d47dae2a  vmovaps xmm4, [rsp+0x40]
00007e55d47dae30  vmovaps xmm5, [rsp+0x50]
00007e55d47dae36  vmovaps xmm6, [rsp+0x60]
00007e55d47dae3c  vmovaps xmm7, [rsp+0x70]
00007e55d47dae42  vmovaps xmm8, [rsp+0x80]
00007e55d47dae4b  vmovaps xmm9, [rsp+0x90]
00007e55d47dae54  vmovaps xmm10, [rsp+0xA0]
00007e55d47dae5d  vmovaps xmm11, [rsp+0xB0]
00007e55d47dae66  vmovaps xmm12, [rsp+0xC0]
00007e55d47dae6f  vmovaps xmm13, [rsp+0xD0]
00007e55d47dae78  vmovaps xmm15, [rsp+0xE0]
00007e55d47dae81  add rsp, 0xF0
00007e55d47dae88  pop r11
00007e55d47dae8a  pop r10
00007e55d47dae8c  pop r9
00007e55d47dae8e  pop r8
00007e55d47dae90  pop rsi
00007e55d47dae91  pop rdi
00007e55d47dae92  pop rdx
00007e55d47dae93  pop rcx
00007e55d47dae94  pop rax
00007e55d47dae95  add rsp, 0x08
00007e55d47dae99  jmp 0x00007E55D47D6578
00007e55d47dae9e  sub rsp, 0x08
00007e55d47daea2  push rax
00007e55d47daea3  push rcx
00007e55d47daea4  push rdx
00007e55d47daea5  push rdi
00007e55d47daea6  push rsi
00007e55d47daea7  push r8
00007e55d47daea9  push r9
00007e55d47daeab  push r10
00007e55d47daead  push r11
00007e55d47daeaf  sub rsp, 0xF0
00007e55d47daeb6  vmovaps [rsp], xmm0
00007e55d47daebb  vmovaps [rsp+0x10], xmm2
00007e55d47daec1  vmovaps [rsp+0x20], xmm3
00007e55d47daec7  vmovaps [rsp+0x30], xmm4
00007e55d47daecd  vmovaps [rsp+0x40], xmm5
00007e55d47daed3  vmovaps [rsp+0x50], xmm6
00007e55d47daed9  vmovaps [rsp+0x60], xmm7
00007e55d47daedf  vmovaps [rsp+0x70], xmm8
00007e55d47daee5  vmovaps [rsp+0x80], xmm9
00007e55d47daeee  vmovaps [rsp+0x90], xmm10
00007e55d47daef7  vmovaps [rsp+0xA0], xmm11
00007e55d47daf00  vmovaps [rsp+0xB0], xmm12
00007e55d47daf09  vmovaps [rsp+0xC0], xmm13
00007e55d47daf12  vmovaps [rsp+0xD0], xmm14
00007e55d47daf1b  vmovaps [rsp+0xE0], xmm15
00007e55d47daf24  sub rsp, 0x30
00007e55d47daf28  movaps [rsp], xmm1
00007e55d47daf2c  movaps [rsp+0x10], xmm13
00007e55d47daf32  movaps [rsp+0x20], xmm8
00007e55d47daf38  lea rdi, [rsp]
00007e55d47daf3c  mov esi, 0x00
00007e55d47daf41  mov rax, 0x55D0734A4530
00007e55d47daf4b  call rax
00007e55d47daf4d  movaps xmm1, [rsp]
00007e55d47daf51  add rsp, 0x30
00007e55d47daf55  vmovaps xmm0, [rsp]
00007e55d47daf5a  vmovaps xmm2, [rsp+0x10]
00007e55d47daf60  vmovaps xmm3, [rsp+0x20]
00007e55d47daf66  vmovaps xmm4, [rsp+0x30]
00007e55d47daf6c  vmovaps xmm5, [rsp+0x40]
00007e55d47daf72  vmovaps xmm6, [rsp+0x50]
00007e55d47daf78  vmovaps xmm7, [rsp+0x60]
00007e55d47daf7e  vmovaps xmm8, [rsp+0x70]
00007e55d47daf84  vmovaps xmm9, [rsp+0x80]
00007e55d47daf8d  vmovaps xmm10, [rsp+0x90]
00007e55d47daf96  vmovaps xmm11, [rsp+0xA0]
00007e55d47daf9f  vmovaps xmm12, [rsp+0xB0]
00007e55d47dafa8  vmovaps xmm13, [rsp+0xC0]
00007e55d47dafb1  vmovaps xmm14, [rsp+0xD0]
00007e55d47dafba  vmovaps xmm15, [rsp+0xE0]
00007e55d47dafc3  add rsp, 0xF0
00007e55d47dafca  pop r11
00007e55d47dafcc  pop r10
00007e55d47dafce  pop r9
00007e55d47dafd0  pop r8
00007e55d47dafd2  pop rsi
00007e55d47dafd3  pop rdi
00007e55d47dafd4  pop rdx
00007e55d47dafd5  pop rcx
00007e55d47dafd6  pop rax
00007e55d47dafd7  add rsp, 0x08
00007e55d47dafdb  jmp 0x00007E55D47D659A
00007e55d47dafe0  call 0x00007E55D460C260
00007e55d47dafe5  jmp 0x00007E55D47D65A8
00007e55d47dafea  call 0x00007E55D46DE950
00007e55d47dafef  jmp 0x00007E55D47D65B2
00007e55d47daff4  sub rsp, 0x08
00007e55d47daff8  push rax
00007e55d47daff9  push rcx
00007e55d47daffa  push rdx
00007e55d47daffb  push rdi
00007e55d47daffc  push rsi
00007e55d47daffd  push r8
00007e55d47dafff  push r9
00007e55d47db001  push r10
00007e55d47db003  push r11
00007e55d47db005  sub rsp, 0xF0
00007e55d47db00c  vmovaps [rsp], xmm0
00007e55d47db011  vmovaps [rsp+0x10], xmm1
00007e55d47db017  vmovaps [rsp+0x20], xmm2
00007e55d47db01d  vmovaps [rsp+0x30], xmm3
00007e55d47db023  vmovaps [rsp+0x40], xmm4
00007e55d47db029  vmovaps [rsp+0x50], xmm5
00007e55d47db02f  vmovaps [rsp+0x60], xmm6
00007e55d47db035  vmovaps [rsp+0x70], xmm7
00007e55d47db03b  vmovaps [rsp+0x80], xmm9
00007e55d47db044  vmovaps [rsp+0x90], xmm10
00007e55d47db04d  vmovaps [rsp+0xA0], xmm11
00007e55d47db056  vmovaps [rsp+0xB0], xmm12
00007e55d47db05f  vmovaps [rsp+0xC0], xmm13
00007e55d47db068  vmovaps [rsp+0xD0], xmm14
00007e55d47db071  vmovaps [rsp+0xE0], xmm15
00007e55d47db07a  sub rsp, 0x30
00007e55d47db07e  movaps [rsp], xmm8
00007e55d47db083  movaps [rsp+0x10], xmm15
00007e55d47db089  movaps [rsp+0x20], xmm7
00007e55d47db08e  lea rdi, [rsp]
00007e55d47db092  mov esi, 0x00
00007e55d47db097  mov rax, 0x55D0734A4530
00007e55d47db0a1  call rax
00007e55d47db0a3  movaps xmm8, [rsp]
00007e55d47db0a8  add rsp, 0x30
00007e55d47db0ac  vmovaps xmm0, [rsp]
00007e55d47db0b1  vmovaps xmm1, [rsp+0x10]
00007e55d47db0b7  vmovaps xmm2, [rsp+0x20]
00007e55d47db0bd  vmovaps xmm3, [rsp+0x30]
00007e55d47db0c3  vmovaps xmm4, [rsp+0x40]
00007e55d47db0c9  vmovaps xmm5, [rsp+0x50]
00007e55d47db0cf  vmovaps xmm6, [rsp+0x60]
00007e55d47db0d5  vmovaps xmm7, [rsp+0x70]
00007e55d47db0db  vmovaps xmm9, [rsp+0x80]
00007e55d47db0e4  vmovaps xmm10, [rsp+0x90]
00007e55d47db0ed  vmovaps xmm11, [rsp+0xA0]
00007e55d47db0f6  vmovaps xmm12, [rsp+0xB0]
00007e55d47db0ff  vmovaps xmm13, [rsp+0xC0]
00007e55d47db108  vmovaps xmm14, [rsp+0xD0]
00007e55d47db111  vmovaps xmm15, [rsp+0xE0]
00007e55d47db11a  add rsp, 0xF0
00007e55d47db121  pop r11
00007e55d47db123  pop r10
00007e55d47db125  pop r9
00007e55d47db127  pop r8
00007e55d47db129  pop rsi
00007e55d47db12a  pop rdi
00007e55d47db12b  pop rdx
00007e55d47db12c  pop rcx
00007e55d47db12d  pop rax
00007e55d47db12e  add rsp, 0x08
00007e55d47db132  jmp 0x00007E55D47D65D4
00007e55d47db137  sub rsp, 0x08
00007e55d47db13b  push rax
00007e55d47db13c  push rcx
00007e55d47db13d  push rdx
00007e55d47db13e  push rdi
00007e55d47db13f  push rsi
00007e55d47db140  push r8
00007e55d47db142  push r9
00007e55d47db144  push r10
00007e55d47db146  push r11
00007e55d47db148  sub rsp, 0xF0
00007e55d47db14f  vmovaps [rsp], xmm0
00007e55d47db154  vmovaps [rsp+0x10], xmm1
00007e55d47db15a  vmovaps [rsp+0x20], xmm2
00007e55d47db160  vmovaps [rsp+0x30], xmm3
00007e55d47db166  vmovaps [rsp+0x40], xmm4
00007e55d47db16c  vmovaps [rsp+0x50], xmm5
00007e55d47db172  vmovaps [rsp+0x60], xmm6
00007e55d47db178  vmovaps [rsp+0x70], xmm8
00007e55d47db17e  vmovaps [rsp+0x80], xmm9
00007e55d47db187  vmovaps [rsp+0x90], xmm10
00007e55d47db190  vmovaps [rsp+0xA0], xmm11
00007e55d47db199  vmovaps [rsp+0xB0], xmm12
00007e55d47db1a2  vmovaps [rsp+0xC0], xmm13
00007e55d47db1ab  vmovaps [rsp+0xD0], xmm14
00007e55d47db1b4  vmovaps [rsp+0xE0], xmm15
00007e55d47db1bd  sub rsp, 0x30
00007e55d47db1c1  movaps [rsp], xmm7
00007e55d47db1c5  movaps [rsp+0x10], xmm9
00007e55d47db1cb  movaps [rsp+0x20], xmm15
00007e55d47db1d1  lea rdi, [rsp]
00007e55d47db1d5  mov esi, 0x00
00007e55d47db1da  mov rax, 0x55D0734A4530
00007e55d47db1e4  call rax
00007e55d47db1e6  movaps xmm7, [rsp]
00007e55d47db1ea  add rsp, 0x30
00007e55d47db1ee  vmovaps xmm0, [rsp]
00007e55d47db1f3  vmovaps xmm1, [rsp+0x10]
00007e55d47db1f9  vmovaps xmm2, [rsp+0x20]
00007e55d47db1ff  vmovaps xmm3, [rsp+0x30]
00007e55d47db205  vmovaps xmm4, [rsp+0x40]
00007e55d47db20b  vmovaps xmm5, [rsp+0x50]
00007e55d47db211  vmovaps xmm6, [rsp+0x60]
00007e55d47db217  vmovaps xmm8, [rsp+0x70]
00007e55d47db21d  vmovaps xmm9, [rsp+0x80]
00007e55d47db226  vmovaps xmm10, [rsp+0x90]
00007e55d47db22f  vmovaps xmm11, [rsp+0xA0]
00007e55d47db238  vmovaps xmm12, [rsp+0xB0]
00007e55d47db241  vmovaps xmm13, [rsp+0xC0]
00007e55d47db24a  vmovaps xmm14, [rsp+0xD0]
00007e55d47db253  vmovaps xmm15, [rsp+0xE0]
00007e55d47db25c  add rsp, 0xF0
00007e55d47db263  pop r11
00007e55d47db265  pop r10
00007e55d47db267  pop r9
00007e55d47db269  pop r8
00007e55d47db26b  pop rsi
00007e55d47db26c  pop rdi
00007e55d47db26d  pop rdx
00007e55d47db26e  pop rcx
00007e55d47db26f  pop rax
00007e55d47db270  add rsp, 0x08
00007e55d47db274  jmp 0x00007E55D47D6601
00007e55d47db279  sub rsp, 0x08
00007e55d47db27d  push rax
00007e55d47db27e  push rcx
00007e55d47db27f  push rdx
00007e55d47db280  push rdi
00007e55d47db281  push rsi
00007e55d47db282  push r8
00007e55d47db284  push r9
00007e55d47db286  push r10
00007e55d47db288  push r11
00007e55d47db28a  sub rsp, 0xF0
00007e55d47db291  vmovaps [rsp], xmm0
00007e55d47db296  vmovaps [rsp+0x10], xmm1
00007e55d47db29c  vmovaps [rsp+0x20], xmm2
00007e55d47db2a2  vmovaps [rsp+0x30], xmm3
00007e55d47db2a8  vmovaps [rsp+0x40], xmm4
00007e55d47db2ae  vmovaps [rsp+0x50], xmm5
00007e55d47db2b4  vmovaps [rsp+0x60], xmm6
00007e55d47db2ba  vmovaps [rsp+0x70], xmm7
00007e55d47db2c0  vmovaps [rsp+0x80], xmm8
00007e55d47db2c9  vmovaps [rsp+0x90], xmm10
00007e55d47db2d2  vmovaps [rsp+0xA0], xmm11
00007e55d47db2db  vmovaps [rsp+0xB0], xmm12
00007e55d47db2e4  vmovaps [rsp+0xC0], xmm13
00007e55d47db2ed  vmovaps [rsp+0xD0], xmm14
00007e55d47db2f6  vmovaps [rsp+0xE0], xmm15
00007e55d47db2ff  sub rsp, 0x30
00007e55d47db303  movaps [rsp], xmm9
00007e55d47db308  movaps [rsp+0x10], xmm13
00007e55d47db30e  movaps [rsp+0x20], xmm15
00007e55d47db314  lea rdi, [rsp]
00007e55d47db318  mov esi, 0x00
00007e55d47db31d  mov rax, 0x55D0734A4530
00007e55d47db327  call rax
00007e55d47db329  movaps xmm9, [rsp]
00007e55d47db32e  add rsp, 0x30
00007e55d47db332  vmovaps xmm0, [rsp]
00007e55d47db337  vmovaps xmm1, [rsp+0x10]
00007e55d47db33d  vmovaps xmm2, [rsp+0x20]
00007e55d47db343  vmovaps xmm3, [rsp+0x30]
00007e55d47db349  vmovaps xmm4, [rsp+0x40]
00007e55d47db34f  vmovaps xmm5, [rsp+0x50]
00007e55d47db355  vmovaps xmm6, [rsp+0x60]
00007e55d47db35b  vmovaps xmm7, [rsp+0x70]
00007e55d47db361  vmovaps xmm8, [rsp+0x80]
00007e55d47db36a  vmovaps xmm10, [rsp+0x90]
00007e55d47db373  vmovaps xmm11, [rsp+0xA0]
00007e55d47db37c  vmovaps xmm12, [rsp+0xB0]
00007e55d47db385  vmovaps xmm13, [rsp+0xC0]
00007e55d47db38e  vmovaps xmm14, [rsp+0xD0]
00007e55d47db397  vmovaps xmm15, [rsp+0xE0]
00007e55d47db3a0  add rsp, 0xF0
00007e55d47db3a7  pop r11
00007e55d47db3a9  pop r10
00007e55d47db3ab  pop r9
00007e55d47db3ad  pop r8
00007e55d47db3af  pop rsi
00007e55d47db3b0  pop rdi
00007e55d47db3b1  pop rdx
00007e55d47db3b2  pop rcx
00007e55d47db3b3  pop rax
00007e55d47db3b4  add rsp, 0x08
00007e55d47db3b8  jmp 0x00007E55D47D662F
00007e55d47db3bd  sub rsp, 0x08
00007e55d47db3c1  push rax
00007e55d47db3c2  push rcx
00007e55d47db3c3  push rdx
00007e55d47db3c4  push rdi
00007e55d47db3c5  push rsi
00007e55d47db3c6  push r8
00007e55d47db3c8  push r9
00007e55d47db3ca  push r10
00007e55d47db3cc  push r11
00007e55d47db3ce  sub rsp, 0xF0
00007e55d47db3d5  vmovaps [rsp], xmm0
00007e55d47db3da  vmovaps [rsp+0x10], xmm1
00007e55d47db3e0  vmovaps [rsp+0x20], xmm2
00007e55d47db3e6  vmovaps [rsp+0x30], xmm3
00007e55d47db3ec  vmovaps [rsp+0x40], xmm4
00007e55d47db3f2  vmovaps [rsp+0x50], xmm5
00007e55d47db3f8  vmovaps [rsp+0x60], xmm6
00007e55d47db3fe  vmovaps [rsp+0x70], xmm7
00007e55d47db404  vmovaps [rsp+0x80], xmm8
00007e55d47db40d  vmovaps [rsp+0x90], xmm9
00007e55d47db416  vmovaps [rsp+0xA0], xmm10
00007e55d47db41f  vmovaps [rsp+0xB0], xmm11
00007e55d47db428  vmovaps [rsp+0xC0], xmm12
00007e55d47db431  vmovaps [rsp+0xD0], xmm13
00007e55d47db43a  vmovaps [rsp+0xE0], xmm14
00007e55d47db443  sub rsp, 0x30
00007e55d47db447  movaps [rsp], xmm15
00007e55d47db44c  movaps [rsp+0x10], xmm11
00007e55d47db452  movaps [rsp+0x20], xmm12
00007e55d47db458  lea rdi, [rsp]
00007e55d47db45c  mov esi, 0x00
00007e55d47db461  mov rax, 0x55D0734A4530
00007e55d47db46b  call rax
00007e55d47db46d  movaps xmm15, [rsp]
00007e55d47db472  add rsp, 0x30
00007e55d47db476  vmovaps xmm0, [rsp]
00007e55d47db47b  vmovaps xmm1, [rsp+0x10]
00007e55d47db481  vmovaps xmm2, [rsp+0x20]
00007e55d47db487  vmovaps xmm3, [rsp+0x30]
00007e55d47db48d  vmovaps xmm4, [rsp+0x40]
00007e55d47db493  vmovaps xmm5, [rsp+0x50]
00007e55d47db499  vmovaps xmm6, [rsp+0x60]
00007e55d47db49f  vmovaps xmm7, [rsp+0x70]
00007e55d47db4a5  vmovaps xmm8, [rsp+0x80]
00007e55d47db4ae  vmovaps xmm9, [rsp+0x90]
00007e55d47db4b7  vmovaps xmm10, [rsp+0xA0]
00007e55d47db4c0  vmovaps xmm11, [rsp+0xB0]
00007e55d47db4c9  vmovaps xmm12, [rsp+0xC0]
00007e55d47db4d2  vmovaps xmm13, [rsp+0xD0]
00007e55d47db4db  vmovaps xmm14, [rsp+0xE0]
00007e55d47db4e4  add rsp, 0xF0
00007e55d47db4eb  pop r11
00007e55d47db4ed  pop r10
00007e55d47db4ef  pop r9
00007e55d47db4f1  pop r8
00007e55d47db4f3  pop rsi
00007e55d47db4f4  pop rdi
00007e55d47db4f5  pop rdx
00007e55d47db4f6  pop rcx
00007e55d47db4f7  pop rax
00007e55d47db4f8  add rsp, 0x08
00007e55d47db4fc  jmp 0x00007E55D47D664A
00007e55d47db501  sub rsp, 0x08
00007e55d47db505  push rax
00007e55d47db506  push rcx
00007e55d47db507  push rdx
00007e55d47db508  push rdi
00007e55d47db509  push rsi
00007e55d47db50a  push r8
00007e55d47db50c  push r9
00007e55d47db50e  push r10
00007e55d47db510  push r11
00007e55d47db512  sub rsp, 0xF0
00007e55d47db519  vmovaps [rsp], xmm0
00007e55d47db51e  vmovaps [rsp+0x10], xmm1
00007e55d47db524  vmovaps [rsp+0x20], xmm2
00007e55d47db52a  vmovaps [rsp+0x30], xmm3
00007e55d47db530  vmovaps [rsp+0x40], xmm4
00007e55d47db536  vmovaps [rsp+0x50], xmm5
00007e55d47db53c  vmovaps [rsp+0x60], xmm6
00007e55d47db542  vmovaps [rsp+0x70], xmm7
00007e55d47db548  vmovaps [rsp+0x80], xmm8
00007e55d47db551  vmovaps [rsp+0x90], xmm9
00007e55d47db55a  vmovaps [rsp+0xA0], xmm10
00007e55d47db563  vmovaps [rsp+0xB0], xmm11
00007e55d47db56c  vmovaps [rsp+0xC0], xmm12
00007e55d47db575  vmovaps [rsp+0xD0], xmm14
00007e55d47db57e  vmovaps [rsp+0xE0], xmm15
00007e55d47db587  sub rsp, 0x30
00007e55d47db58b  movaps [rsp], xmm13
00007e55d47db590  movaps [rsp+0x10], xmm10
00007e55d47db596  movaps [rsp+0x20], xmm14
00007e55d47db59c  lea rdi, [rsp]
00007e55d47db5a0  mov esi, 0x00
00007e55d47db5a5  mov rax, 0x55D0734A4530
00007e55d47db5af  call rax
00007e55d47db5b1  movaps xmm13, [rsp]
00007e55d47db5b6  add rsp, 0x30
00007e55d47db5ba  vmovaps xmm0, [rsp]
00007e55d47db5bf  vmovaps xmm1, [rsp+0x10]
00007e55d47db5c5  vmovaps xmm2, [rsp+0x20]
00007e55d47db5cb  vmovaps xmm3, [rsp+0x30]
00007e55d47db5d1  vmovaps xmm4, [rsp+0x40]
00007e55d47db5d7  vmovaps xmm5, [rsp+0x50]
00007e55d47db5dd  vmovaps xmm6, [rsp+0x60]
00007e55d47db5e3  vmovaps xmm7, [rsp+0x70]
00007e55d47db5e9  vmovaps xmm8, [rsp+0x80]
00007e55d47db5f2  vmovaps xmm9, [rsp+0x90]
00007e55d47db5fb  vmovaps xmm10, [rsp+0xA0]
00007e55d47db604  vmovaps xmm11, [rsp+0xB0]
00007e55d47db60d  vmovaps xmm12, [rsp+0xC0]
00007e55d47db616  vmovaps xmm14, [rsp+0xD0]
00007e55d47db61f  vmovaps xmm15, [rsp+0xE0]
00007e55d47db628  add rsp, 0xF0
00007e55d47db62f  pop r11
00007e55d47db631  pop r10
00007e55d47db633  pop r9
00007e55d47db635  pop r8
00007e55d47db637  pop rsi
00007e55d47db638  pop rdi
00007e55d47db639  pop rdx
00007e55d47db63a  pop rcx
00007e55d47db63b  pop rax
00007e55d47db63c  add rsp, 0x08
00007e55d47db640  jmp 0x00007E55D47D666D
00007e55d47db645  sub rsp, 0x08
00007e55d47db649  push rax
00007e55d47db64a  push rcx
00007e55d47db64b  push rdx
00007e55d47db64c  push rdi
00007e55d47db64d  push rsi
00007e55d47db64e  push r8
00007e55d47db650  push r9
00007e55d47db652  push r10
00007e55d47db654  push r11
00007e55d47db656  sub rsp, 0xF0
00007e55d47db65d  vmovaps [rsp], xmm0
00007e55d47db662  vmovaps [rsp+0x10], xmm1
00007e55d47db668  vmovaps [rsp+0x20], xmm2
00007e55d47db66e  vmovaps [rsp+0x30], xmm3
00007e55d47db674  vmovaps [rsp+0x40], xmm4
00007e55d47db67a  vmovaps [rsp+0x50], xmm5
00007e55d47db680  vmovaps [rsp+0x60], xmm6
00007e55d47db686  vmovaps [rsp+0x70], xmm7
00007e55d47db68c  vmovaps [rsp+0x80], xmm8
00007e55d47db695  vmovaps [rsp+0x90], xmm9
00007e55d47db69e  vmovaps [rsp+0xA0], xmm10
00007e55d47db6a7  vmovaps [rsp+0xB0], xmm11
00007e55d47db6b0  vmovaps [rsp+0xC0], xmm12
00007e55d47db6b9  vmovaps [rsp+0xD0], xmm13
00007e55d47db6c2  vmovaps [rsp+0xE0], xmm15
00007e55d47db6cb  sub rsp, 0x30
00007e55d47db6cf  movaps [rsp], xmm14
00007e55d47db6d4  movaps [rsp+0x10], xmm1
00007e55d47db6d9  movaps [rsp+0x20], xmm7
00007e55d47db6de  lea rdi, [rsp]
00007e55d47db6e2  mov esi, 0x00
00007e55d47db6e7  mov rax, 0x55D0734A4530
00007e55d47db6f1  call rax
00007e55d47db6f3  movaps xmm14, [rsp]
00007e55d47db6f8  add rsp, 0x30
00007e55d47db6fc  vmovaps xmm0, [rsp]
00007e55d47db701  vmovaps xmm1, [rsp+0x10]
00007e55d47db707  vmovaps xmm2, [rsp+0x20]
00007e55d47db70d  vmovaps xmm3, [rsp+0x30]
00007e55d47db713  vmovaps xmm4, [rsp+0x40]
00007e55d47db719  vmovaps xmm5, [rsp+0x50]
00007e55d47db71f  vmovaps xmm6, [rsp+0x60]
00007e55d47db725  vmovaps xmm7, [rsp+0x70]
00007e55d47db72b  vmovaps xmm8, [rsp+0x80]
00007e55d47db734  vmovaps xmm9, [rsp+0x90]
00007e55d47db73d  vmovaps xmm10, [rsp+0xA0]
00007e55d47db746  vmovaps xmm11, [rsp+0xB0]
00007e55d47db74f  vmovaps xmm12, [rsp+0xC0]
00007e55d47db758  vmovaps xmm13, [rsp+0xD0]
00007e55d47db761  vmovaps xmm15, [rsp+0xE0]
00007e55d47db76a  add rsp, 0xF0
00007e55d47db771  pop r11
00007e55d47db773  pop r10
00007e55d47db775  pop r9
00007e55d47db777  pop r8
00007e55d47db779  pop rsi
00007e55d47db77a  pop rdi
00007e55d47db77b  pop rdx
00007e55d47db77c  pop rcx
00007e55d47db77d  pop rax
00007e55d47db77e  add rsp, 0x08
00007e55d47db782  jmp 0x00007E55D47D6690
00007e55d47db787  sub rsp, 0x08
00007e55d47db78b  push rax
00007e55d47db78c  push rcx
00007e55d47db78d  push rdx
00007e55d47db78e  push rdi
00007e55d47db78f  push rsi
00007e55d47db790  push r8
00007e55d47db792  push r9
00007e55d47db794  push r10
00007e55d47db796  push r11
00007e55d47db798  sub rsp, 0xF0
00007e55d47db79f  vmovaps [rsp], xmm0
00007e55d47db7a4  vmovaps [rsp+0x10], xmm2
00007e55d47db7aa  vmovaps [rsp+0x20], xmm3
00007e55d47db7b0  vmovaps [rsp+0x30], xmm4
00007e55d47db7b6  vmovaps [rsp+0x40], xmm5
00007e55d47db7bc  vmovaps [rsp+0x50], xmm6
00007e55d47db7c2  vmovaps [rsp+0x60], xmm7
00007e55d47db7c8  vmovaps [rsp+0x70], xmm8
00007e55d47db7ce  vmovaps [rsp+0x80], xmm9
00007e55d47db7d7  vmovaps [rsp+0x90], xmm10
00007e55d47db7e0  vmovaps [rsp+0xA0], xmm11
00007e55d47db7e9  vmovaps [rsp+0xB0], xmm12
00007e55d47db7f2  vmovaps [rsp+0xC0], xmm13
00007e55d47db7fb  vmovaps [rsp+0xD0], xmm14
00007e55d47db804  vmovaps [rsp+0xE0], xmm15
00007e55d47db80d  sub rsp, 0x30
00007e55d47db811  movaps [rsp], xmm1
00007e55d47db815  movaps [rsp+0x10], xmm8
00007e55d47db81b  movaps [rsp+0x20], xmm9
00007e55d47db821  lea rdi, [rsp]
00007e55d47db825  mov esi, 0x00
00007e55d47db82a  mov rax, 0x55D0734A4530
00007e55d47db834  call rax
00007e55d47db836  movaps xmm1, [rsp]
00007e55d47db83a  add rsp, 0x30
00007e55d47db83e  vmovaps xmm0, [rsp]
00007e55d47db843  vmovaps xmm2, [rsp+0x10]
00007e55d47db849  vmovaps xmm3, [rsp+0x20]
00007e55d47db84f  vmovaps xmm4, [rsp+0x30]
00007e55d47db855  vmovaps xmm5, [rsp+0x40]
00007e55d47db85b  vmovaps xmm6, [rsp+0x50]
00007e55d47db861  vmovaps xmm7, [rsp+0x60]
00007e55d47db867  vmovaps xmm8, [rsp+0x70]
00007e55d47db86d  vmovaps xmm9, [rsp+0x80]
00007e55d47db876  vmovaps xmm10, [rsp+0x90]
00007e55d47db87f  vmovaps xmm11, [rsp+0xA0]
00007e55d47db888  vmovaps xmm12, [rsp+0xB0]
00007e55d47db891  vmovaps xmm13, [rsp+0xC0]
00007e55d47db89a  vmovaps xmm14, [rsp+0xD0]
00007e55d47db8a3  vmovaps xmm15, [rsp+0xE0]
00007e55d47db8ac  add rsp, 0xF0
00007e55d47db8b3  pop r11
00007e55d47db8b5  pop r10
00007e55d47db8b7  pop r9
00007e55d47db8b9  pop r8
00007e55d47db8bb  pop rsi
00007e55d47db8bc  pop rdi
00007e55d47db8bd  pop rdx
00007e55d47db8be  pop rcx
00007e55d47db8bf  pop rax
00007e55d47db8c0  add rsp, 0x08
00007e55d47db8c4  jmp 0x00007E55D47D66B2
00007e55d47db8c9  call 0x00007E55D46B3E40
00007e55d47db8ce  jmp 0x00007E55D47D66C0
00007e55d47db8d3  call 0x00007E55D460C380
00007e55d47db8d8  jmp 0x00007E55D47D66CA
00007e55d47db8dd  call 0x00007E55D460D600
00007e55d47db8e2  jmp 0x00007E55D47D66D4
00007e55d47db8e7  call 0x00007E55D45FF540
00007e55d47db8ec  jmp 0x00007E55D47D66DE
00007e55d47db8f1  int3
00007e55d47db8f2  nop [rax+rax*1], ax
00007e55d47db8fb  nop [rax+rax*1], eax
00007e55d47db900  mov eax, [r15+0x48]
00007e55d47db904  lea r14d, [eax+0x01]
00007e55d47db909  mov [rsp+0x10], r14d
00007e55d47db90e  mov r14d, r14d
00007e55d47db911  mov [r15+0x48], r14
00007e55d47db915  xor eax, eax
00007e55d47db917  mov r14d, [rsp+0x10]
00007e55d47db91c  cmp r14d, 0x1F4
00007e55d47db923  cmc
00007e55d47db924  lahf
00007e55d47db925  seto al
00007e55d47db928  mov [r15+0x108], eax
00007e55d47db92f  mov eax, [r15+0x108]
00007e55d47db936  sahf
00007e55d47db937  jnz 0x00007E55D47DB969
00007e55d47db939  cmp dword ptr [r15+0x318], 0x00
00007e55d47db941  jz 0x00007E55D47E1AB0
00007e55d47db947  nop [rax+rax*1], ax
00007e55d47db950  nop [rax+rax*1], eax
00007e55d47db958  mov eax, 0x410450
00007e55d47db95d  mov [r15+0x100], rax
00007e55d47db964  jmp 0x00007E55D45FE110
00007e55d47db969  cmp dword ptr [r15+0x318], 0x00
00007e55d47db971  jz 0x00007E55D47DB9A0
00007e55d47db977  nop [rax+rax*1], ax
00007e55d47db980  nop [rax+rax*1], eax
00007e55d47db988  mov eax, 0x410274
00007e55d47db98d  mov [r15+0x100], rax
00007e55d47db994  jmp 0x00007E55D45FE110
00007e55d47db999  int3
00007e55d47db99a  int3
00007e55d47db99b  nop [rax+rax*1], eax
00007e55d47db9a0  mov rax, [r15+0x40]
00007e55d47db9a4  movaps xmm1, [r15+0x1D0]
00007e55d47db9ac  vmovaps [rsp+0x10], xmm1
00007e55d47db9b2  vmovaps xmm15, [rsp+0x10]
00007e55d47db9b8  por xmm1, xmm15
00007e55d47db9bd  movaps xmm14, [r15+0x1A0]
00007e55d47db9c5  vmovaps [rsp+0x10], xmm14
00007e55d47db9cb  vmovaps xmm13, [rsp+0x10]
00007e55d47db9d1  por xmm14, xmm13
00007e55d47db9d6  lea r14, [rax+0x30]
00007e55d47db9da  mov r12, [r13+r14*1]
00007e55d47db9df  lea r14, [rax+0x38]
00007e55d47db9e3  mov r11, [r13+r14*1]
00007e55d47db9e8  movq xmm13, r12
00007e55d47db9ed  movq xmm12, r11
00007e55d47db9f2  movq xmm13, xmm13
00007e55d47db9f7  vmovaps [rsp+0x10], xmm13
00007e55d47db9fd  movq xmm13, xmm13
00007e55d47dba02  movaps [r15+0x130], xmm13
00007e55d47dba0a  movq xmm12, xmm12
00007e55d47dba0f  vmovaps [rsp+0x20], xmm12
00007e55d47dba15  movq xmm12, xmm12
00007e55d47dba1a  movaps [r15+0x280], xmm12
00007e55d47dba22  movaps xmm13, [r15+0x270]
00007e55d47dba2a  vmovaps [rsp+0x30], xmm13
00007e55d47dba30  vmovaps xmm12, [rsp+0x30]
00007e55d47dba36  por xmm13, xmm12
00007e55d47dba3b  lea r14, [rax+0x20]
00007e55d47dba3f  mov r12, [r13+r14*1]
00007e55d47dba44  lea r14, [rax+0x28]
00007e55d47dba48  mov r11, [r13+r14*1]
00007e55d47dba4d  movq xmm12, r12
00007e55d47dba52  movq xmm11, r11
00007e55d47dba57  movq xmm12, xmm12
00007e55d47dba5c  vmovaps [rsp+0x30], xmm12
00007e55d47dba62  movq xmm12, xmm12
00007e55d47dba67  movaps [r15+0x150], xmm12
00007e55d47dba6f  movq xmm11, xmm11
00007e55d47dba74  vmovaps [rsp+0x40], xmm11
00007e55d47dba7a  movq xmm11, xmm11
00007e55d47dba7f  movaps [r15+0x140], xmm11
00007e55d47dba87  lea r14, [rax+0x10]
00007e55d47dba8b  mov r12, [r13+r14*1]
00007e55d47dba90  lea r14, [rax+0x18]
00007e55d47dba94  mov r11, [r13+r14*1]
00007e55d47dba99  movq xmm12, r12
00007e55d47dba9e  movq xmm11, r11
00007e55d47dbaa3  movq xmm12, xmm12
00007e55d47dbaa8  vmovaps [rsp+0x50], xmm12
00007e55d47dbaae  movq xmm12, xmm12
00007e55d47dbab3  movaps [r15+0x170], xmm12
00007e55d47dbabb  movq xmm11, xmm11
00007e55d47dbac0  vmovaps [rsp+0x60], xmm11
00007e55d47dbac6  movq xmm11, xmm11
00007e55d47dbacb  movaps [r15+0x160], xmm11
00007e55d47dbad3  mov r14, [r13+rax*1]
00007e55d47dbad8  vmovq xmm12, r14
00007e55d47dbadd  vpbroadcastq xmm12, xmm12
00007e55d47dbae2  lea r14, [rax+0x08]
00007e55d47dbae6  mov rax, [r13+r14*1]
00007e55d47dbaeb  movq xmm11, rax
00007e55d47dbaf0  movaps [r15+0x230], xmm11
00007e55d47dbaf8  mov rax, [r15+0xF8]
00007e55d47dbaff  lea r14, [rax+0x50]
00007e55d47dbb03  movups xmm11, [r13+r14*1]
00007e55d47dbb09  lea r14, [rax+0x60]
00007e55d47dbb0d  movups xmm10, [r13+r14*1]
00007e55d47dbb13  lea r14, [rax+0x30]
00007e55d47dbb17  movups xmm9, [r13+r14*1]
00007e55d47dbb1d  mov r14, [r15+0x50]
00007e55d47dbb21  mov [r15+0x60], r14
00007e55d47dbb25  mov qword ptr [r15+0x58], 0x40
00007e55d47dbb2d  movaps xmm8, xmm12
00007e55d47dbb31  mulpd xmm8, xmm15
00007e55d47dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007e55d47dbb3c  ptest xmm7, xmm7
00007e55d47dbb41  jnz 0x00007E55D47DC96A
00007e55d47dbb47  movq xmm15, qword ptr [r15+0x230]
00007e55d47dbb50  vmovaps [rsp+0x70], xmm15
00007e55d47dbb56  vpermilpd xmm15, xmm15, 0x00
00007e55d47dbb5c  movaps xmm7, xmm9
00007e55d47dbb60  mulpd xmm7, xmm15
00007e55d47dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007e55d47dbb6a  ptest xmm6, xmm6
00007e55d47dbb6f  jnz 0x00007E55D47DCAAE
00007e55d47dbb75  vxorps xmm15, xmm15, xmm15
00007e55d47dbb7a  vpbroadcastq xmm15, xmm15
00007e55d47dbb7f  movaps xmm9, xmm12
00007e55d47dbb83  mulpd xmm9, xmm10
00007e55d47dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007e55d47dbb8e  ptest xmm6, xmm6
00007e55d47dbb93  jnz 0x00007E55D47DCBF0
00007e55d47dbb99  movaps xmm10, xmm12
00007e55d47dbb9d  mulpd xmm10, xmm11
00007e55d47dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007e55d47dbba8  ptest xmm6, xmm6
00007e55d47dbbad  jnz 0x00007E55D47DCD34
00007e55d47dbbb3  movaps xmm11, [r15+0x1F0]
00007e55d47dbbbb  movaps xmm6, xmm12
00007e55d47dbbbf  mulpd xmm6, xmm11
00007e55d47dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007e55d47dbbc9  ptest xmm5, xmm5
00007e55d47dbbce  jnz 0x00007E55D47DCE78
00007e55d47dbbd4  movaps xmm12, [r15+0x2A0]
00007e55d47dbbdc  vmovaps [rsp+0x80], xmm12
00007e55d47dbbe5  vmovaps xmm11, [rsp+0x80]
00007e55d47dbbee  por xmm12, xmm11
00007e55d47dbbf3  movaps xmm11, [r15+0x250]
00007e55d47dbbfb  vmovaps [rsp+0x80], xmm11
00007e55d47dbc04  vmovaps xmm5, [rsp+0x80]
00007e55d47dbc0d  por xmm11, xmm5
00007e55d47dbc12  vmovaps xmm4, [rsp+0x70]
00007e55d47dbc18  vpermilpd xmm4, xmm4, 0x00
00007e55d47dbc1e  movaps xmm3, xmm5
00007e55d47dbc21  mulpd xmm3, xmm4
00007e55d47dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007e55d47dbc2a  ptest xmm2, xmm2
00007e55d47dbc2f  jnz 0x00007E55D47DCFBA
00007e55d47dbc35  mov [rsp+0x80], rax
00007e55d47dbc3d  xor eax, eax
00007e55d47dbc3f  mov r12d, 0x40
00007e55d47dbc45  mov r11d, 0x200
00007e55d47dbc4b  cmp r12, r11
00007e55d47dbc4e  cmc
00007e55d47dbc4f  lahf
00007e55d47dbc50  seto al
00007e55d47dbc53  mov [r15+0x108], eax
00007e55d47dbc5a  movaps xmm5, xmm8
00007e55d47dbc5e  addpd xmm5, xmm15
00007e55d47dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007e55d47dbc68  ptest xmm4, xmm4
00007e55d47dbc6d  jnz 0x00007E55D47DD0FA
00007e55d47dbc73  movaps xmm8, [r15+0x1B0]
00007e55d47dbc7b  movaps xmm4, xmm9
00007e55d47dbc7f  addpd xmm4, xmm8
00007e55d47dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007e55d47dbc89  ptest xmm2, xmm2
00007e55d47dbc8e  jnz 0x00007E55D47DD23C
00007e55d47dbc94  movaps xmm9, xmm10
00007e55d47dbc98  addpd xmm9, xmm8
00007e55d47dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007e55d47dbca3  ptest xmm2, xmm2
00007e55d47dbca8  jnz 0x00007E55D47DD37E
00007e55d47dbcae  movaps xmm10, [r15+0x2F0]
00007e55d47dbcb6  vmovaps [rsp+0x90], xmm10
00007e55d47dbcbf  vmovaps xmm8, [rsp+0x90]
00007e55d47dbcc8  por xmm10, xmm8
00007e55d47dbccd  movaps xmm8, [r15+0x2E0]
00007e55d47dbcd5  vmovaps [rsp+0x90], xmm8
00007e55d47dbcde  vmovaps xmm2, [rsp+0x90]
00007e55d47dbce7  por xmm8, xmm2
00007e55d47dbcec  movaps xmm2, [r15+0x2D0]
00007e55d47dbcf4  vmovaps [rsp+0x90], xmm2
00007e55d47dbcfd  vmovaps [rsp+0xA0], xmm1
00007e55d47dbd06  vmovaps xmm1, [rsp+0x90]
00007e55d47dbd0f  por xmm2, xmm1
00007e55d47dbd13  movaps xmm1, [r15+0x200]
00007e55d47dbd1b  vmovaps [rsp+0x90], xmm1
00007e55d47dbd24  vmovaps [rsp+0xB0], xmm15
00007e55d47dbd2d  vmovaps xmm15, [rsp+0x90]
00007e55d47dbd36  por xmm1, xmm15
00007e55d47dbd3b  movaps xmm15, [r15+0x1C0]
00007e55d47dbd43  vmovaps [rsp+0x90], xmm15
00007e55d47dbd4c  vmovaps [rsp+0xC0], xmm1
00007e55d47dbd55  vmovaps xmm1, [rsp+0x90]
00007e55d47dbd5e  por xmm15, xmm1
00007e55d47dbd63  movaps xmm1, [r15+0x190]
00007e55d47dbd6b  vmovaps [rsp+0x90], xmm1
00007e55d47dbd74  vmovaps [rsp+0xD0], xmm15
00007e55d47dbd7d  vmovaps xmm15, [rsp+0x90]
00007e55d47dbd86  por xmm1, xmm15
00007e55d47dbd8b  movaps xmm15, [r15+0x300]
00007e55d47dbd93  vmovaps [rsp+0x90], xmm15
00007e55d47dbd9c  vmovaps [rsp+0xE0], xmm1
00007e55d47dbda5  vmovaps xmm1, [rsp+0x90]
00007e55d47dbdae  por xmm15, xmm1
00007e55d47dbdb3  mov rax, [rsp+0x80]
00007e55d47dbdbb  lea r12, [rax+0xA0]
00007e55d47dbdc2  movups xmm1, [r13+r12*1]
00007e55d47dbdc8  lea r12, [rax+0xB0]
00007e55d47dbdcf  vmovaps [rsp+0x80], xmm1
00007e55d47dbdd8  movups xmm1, [r13+r12*1]
00007e55d47dbdde  vmovaps [rsp+0x90], xmm1
00007e55d47dbde7  vmovaps [rsp+0xF0], xmm15
00007e55d47dbdf0  vmovaps xmm15, [rsp+0xB0]
00007e55d47dbdf9  vmovaps [rsp+0xB0], xmm14
00007e55d47dbe02  movaps xmm1, xmm6
00007e55d47dbe05  addpd xmm1, xmm15
00007e55d47dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007e55d47dbe0f  ptest xmm14, xmm14
00007e55d47dbe15  jnz 0x00007E55D47DD4D6
00007e55d47dbe1b  lea r12, [rax+0xF0]
00007e55d47dbe22  movups xmm15, [r13+r12*1]
00007e55d47dbe28  movaps xmm14, xmm4
00007e55d47dbe2c  addpd xmm14, xmm3
00007e55d47dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007e55d47dbe37  ptest xmm6, xmm6
00007e55d47dbe3c  jnz 0x00007E55D47DD621
00007e55d47dbe42  movaps xmm6, xmm9
00007e55d47dbe46  addpd xmm6, xmm7
00007e55d47dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007e55d47dbe4f  ptest xmm4, xmm4
00007e55d47dbe54  jnz 0x00007E55D47DD763
00007e55d47dbe5a  vmovaps xmm9, [rsp+0x70]
00007e55d47dbe60  vpermilpd xmm9, xmm9, 0x00
00007e55d47dbe66  vmovaps xmm4, [rsp+0x90]
00007e55d47dbe6f  movaps xmm7, xmm4
00007e55d47dbe72  mulpd xmm7, xmm9
00007e55d47dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007e55d47dbe7c  ptest xmm3, xmm3
00007e55d47dbe81  jnz 0x00007E55D47DD8A4
00007e55d47dbe87  vmovaps xmm9, [rsp+0x50]
00007e55d47dbe8d  vpermilpd xmm9, xmm9, 0x00
00007e55d47dbe93  movaps xmm4, xmm15
00007e55d47dbe97  mulpd xmm4, xmm9
00007e55d47dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007e55d47dbea1  ptest xmm3, xmm3
00007e55d47dbea6  jnz 0x00007E55D47DD9E5
00007e55d47dbeac  lea r12, [rax+0xE0]
00007e55d47dbeb3  movups xmm15, [r13+r12*1]
00007e55d47dbeb9  vmovaps xmm9, [rsp+0x70]
00007e55d47dbebf  vpermilpd xmm9, xmm9, 0x00
00007e55d47dbec5  vmovaps [rsp+0x70], xmm1
00007e55d47dbecb  vmovaps xmm1, [rsp+0x80]
00007e55d47dbed4  vmovaps [rsp+0x80], xmm15
00007e55d47dbedd  movaps xmm3, xmm1
00007e55d47dbee0  mulpd xmm3, xmm9
00007e55d47dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007e55d47dbeea  ptest xmm15, xmm15
00007e55d47dbef0  jnz 0x00007E55D47DDB31
00007e55d47dbef6  vmovaps xmm1, [rsp+0xF0]
00007e55d47dbeff  vmovaps xmm15, [rsp+0xF0]
00007e55d47dbf08  por xmm1, xmm15
00007e55d47dbf0d  movaps [r15+0x300], xmm1
00007e55d47dbf15  vmovaps xmm15, [rsp+0xE0]
00007e55d47dbf1e  vmovaps xmm9, [rsp+0xE0]
00007e55d47dbf27  por xmm15, xmm9
00007e55d47dbf2c  movaps [r15+0x190], xmm15
00007e55d47dbf34  vmovaps xmm9, [rsp+0x50]
00007e55d47dbf3a  vpermilpd xmm9, xmm9, 0x00
00007e55d47dbf40  vmovaps [rsp+0x90], xmm1
00007e55d47dbf49  vmovaps [rsp+0xE0], xmm15
00007e55d47dbf52  vmovaps xmm15, [rsp+0x80]
00007e55d47dbf5b  vmovaps [rsp+0x80], xmm14
00007e55d47dbf64  movaps xmm1, xmm15
00007e55d47dbf68  mulpd xmm1, xmm9
00007e55d47dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007e55d47dbf72  ptest xmm14, xmm14
00007e55d47dbf78  jnz 0x00007E55D47DDC72
00007e55d47dbf7e  lea r12, [rax+0x90]
00007e55d47dbf85  movups xmm15, [r13+r12*1]
00007e55d47dbf8b  vmovaps xmm14, [rsp+0xD0]
00007e55d47dbf94  vmovaps xmm9, [rsp+0xD0]
00007e55d47dbf9d  por xmm14, xmm9
00007e55d47dbfa2  movaps [r15+0x1C0], xmm14
00007e55d47dbfaa  vmovaps xmm9, [rsp+0xC0]
00007e55d47dbfb3  vmovaps [rsp+0xD0], xmm1
00007e55d47dbfbc  vmovaps xmm1, [rsp+0xC0]
00007e55d47dbfc5  por xmm9, xmm1
00007e55d47dbfca  movaps [r15+0x200], xmm9
00007e55d47dbfd2  vmovaps [rsp+0xC0], xmm2
00007e55d47dbfdb  vmovaps xmm1, [rsp+0xC0]
00007e55d47dbfe4  por xmm2, xmm1
00007e55d47dbfe8  movaps [r15+0x2D0], xmm2
00007e55d47dbff0  vmovaps [rsp+0xC0], xmm8
00007e55d47dbff9  vmovaps xmm1, [rsp+0xC0]
00007e55d47dc002  por xmm8, xmm1
00007e55d47dc007  movaps [r15+0x2E0], xmm8
00007e55d47dc00f  vmovaps [rsp+0xC0], xmm15
00007e55d47dc018  movaps xmm1, xmm5
00007e55d47dc01b  addpd xmm1, xmm7
00007e55d47dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007e55d47dc024  ptest xmm15, xmm15
00007e55d47dc02a  jnz 0x00007E55D47DDDBE
00007e55d47dc030  vmovaps xmm15, [rsp+0x50]
00007e55d47dc036  vpermilpd xmm15, xmm15, 0x00
00007e55d47dc03c  vmovaps xmm5, [rsp+0xC0]
00007e55d47dc045  vmovaps [rsp+0xC0], xmm1
00007e55d47dc04e  movaps xmm7, xmm5
00007e55d47dc051  mulpd xmm7, xmm15
00007e55d47dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007e55d47dc05b  ptest xmm1, xmm1
00007e55d47dc060  jnz 0x00007E55D47DDEFE
00007e55d47dc066  lea r12, [rax+0x80]
00007e55d47dc06d  movups xmm1, [r13+r12*1]
00007e55d47dc073  vmovaps xmm5, [rsp+0x70]
00007e55d47dc079  vmovaps [rsp+0x70], xmm1
00007e55d47dc07f  movaps xmm15, xmm5
00007e55d47dc083  addpd xmm15, xmm3
00007e55d47dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007e55d47dc08e  ptest xmm1, xmm1
00007e55d47dc093  jnz 0x00007E55D47DE049
00007e55d47dc099  vmovaps xmm5, [rsp+0x80]
00007e55d47dc0a2  movaps xmm1, xmm5
00007e55d47dc0a5  addpd xmm1, xmm4
00007e55d47dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007e55d47dc0ae  ptest xmm3, xmm3
00007e55d47dc0b3  jnz 0x00007E55D47DE18B
00007e55d47dc0b9  vmovaps [rsp+0x80], xmm10
00007e55d47dc0c2  vmovaps xmm5, [rsp+0x80]
00007e55d47dc0cb  por xmm10, xmm5
00007e55d47dc0d0  movaps [r15+0x2F0], xmm10
00007e55d47dc0d8  vmovaps xmm5, [rsp+0x50]
00007e55d47dc0de  vpermilpd xmm5, xmm5, 0x00
00007e55d47dc0e4  vmovaps xmm3, [rsp+0x70]
00007e55d47dc0ea  vmovaps [rsp+0x50], xmm1
00007e55d47dc0f0  movaps xmm4, xmm3
00007e55d47dc0f3  mulpd xmm4, xmm5
00007e55d47dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007e55d47dc0fc  ptest xmm1, xmm1
00007e55d47dc101  jnz 0x00007E55D47DE2CB
00007e55d47dc107  lea r12, [rax+0xD0]
00007e55d47dc10e  movups xmm1, [r13+r12*1]
00007e55d47dc114  vmovaps xmm3, [rsp+0xD0]
00007e55d47dc11d  vmovaps [rsp+0x70], xmm1
00007e55d47dc123  movaps xmm5, xmm6
00007e55d47dc126  addpd xmm5, xmm3
00007e55d47dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007e55d47dc12f  ptest xmm1, xmm1
00007e55d47dc134  jnz 0x00007E55D47DE415
00007e55d47dc13a  vmovaps xmm1, [rsp+0x60]
00007e55d47dc140  vpermilpd xmm1, xmm1, 0x00
00007e55d47dc146  movaps xmm6, xmm9
00007e55d47dc14a  mulpd xmm6, xmm1
00007e55d47dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007e55d47dc153  ptest xmm3, xmm3
00007e55d47dc158  jnz 0x00007E55D47DE555
00007e55d47dc15e  movaps [r15+0x260], xmm6
00007e55d47dc166  vxorps xmm1, xmm1, xmm1
00007e55d47dc16a  vpbroadcastq xmm1, xmm1
00007e55d47dc16f  movaps [r15+0x1B0], xmm1
00007e55d47dc177  vmovaps xmm1, [rsp+0x60]
00007e55d47dc17d  vpermilpd xmm1, xmm1, 0x00
00007e55d47dc183  vmovaps xmm3, [rsp+0x70]
00007e55d47dc189  vmovaps [rsp+0x70], xmm15
00007e55d47dc18f  movaps xmm9, xmm3
00007e55d47dc193  mulpd xmm9, xmm1
00007e55d47dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007e55d47dc19e  ptest xmm15, xmm15
00007e55d47dc1a4  jnz 0x00007E55D47DE696
00007e55d47dc1aa  lea r12, [rax+0xC0]
00007e55d47dc1b1  movups xmm1, [r13+r12*1]
00007e55d47dc1b7  vmovaps xmm3, [rsp+0xC0]
00007e55d47dc1c0  vmovaps [rsp+0x80], xmm1
00007e55d47dc1c9  movaps xmm15, xmm3
00007e55d47dc1cd  addpd xmm15, xmm7
00007e55d47dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007e55d47dc1d8  ptest xmm1, xmm1
00007e55d47dc1dd  jnz 0x00007E55D47DE7E2
00007e55d47dc1e3  vmovaps [rsp+0xC0], xmm13
00007e55d47dc1ec  vmovaps xmm1, [rsp+0xC0]
00007e55d47dc1f5  por xmm13, xmm1
00007e55d47dc1fa  movaps [r15+0x270], xmm13
00007e55d47dc202  vmovaps xmm1, [rsp+0xB0]
00007e55d47dc20b  vmovaps xmm7, [rsp+0xB0]
00007e55d47dc214  por xmm1, xmm7
00007e55d47dc218  movaps [r15+0x1A0], xmm1
00007e55d47dc220  vmovaps xmm1, [rsp+0x60]
00007e55d47dc226  vpermilpd xmm1, xmm1, 0x00
00007e55d47dc22c  vmovaps [rsp+0xB0], xmm1
00007e55d47dc235  vmovaps xmm1, [rsp+0x80]
00007e55d47dc23e  vmovaps [rsp+0x80], xmm15
00007e55d47dc247  vmovaps xmm15, [rsp+0xB0]
00007e55d47dc250  vmovaps [rsp+0xB0], xmm14
00007e55d47dc259  movaps xmm3, xmm1
00007e55d47dc25c  mulpd xmm3, xmm15
00007e55d47dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007e55d47dc266  ptest xmm14, xmm14
00007e55d47dc26c  jnz 0x00007E55D47DE924
00007e55d47dc272  lea r12, [rax+0x20]
00007e55d47dc276  movups xmm1, [r13+r12*1]
00007e55d47dc27c  movaps [r15+0x110], xmm1
00007e55d47dc284  vmovaps xmm14, [rsp+0x70]
00007e55d47dc28a  vmovaps [rsp+0x70], xmm1
00007e55d47dc290  movaps xmm15, xmm14
00007e55d47dc294  addpd xmm15, xmm4
00007e55d47dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007e55d47dc29f  ptest xmm1, xmm1
00007e55d47dc2a4  jnz 0x00007E55D47DEA6F
00007e55d47dc2aa  vmovaps xmm1, [rsp+0x60]
00007e55d47dc2b0  vpermilpd xmm1, xmm1, 0x00
00007e55d47dc2b6  movaps xmm14, xmm2
00007e55d47dc2ba  mulpd xmm14, xmm1
00007e55d47dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007e55d47dc2c5  ptest xmm4, xmm4
00007e55d47dc2ca  jnz 0x00007E55D47DEBB2
00007e55d47dc2d0  vmovaps xmm4, [rsp+0x50]
00007e55d47dc2d6  movaps xmm1, xmm4
00007e55d47dc2d9  addpd xmm1, xmm9
00007e55d47dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007e55d47dc2e3  ptest xmm2, xmm2
00007e55d47dc2e8  jnz 0x00007E55D47DECF4
00007e55d47dc2ee  vmovaps xmm9, [rsp+0x30]
00007e55d47dc2f4  vpermilpd xmm9, xmm9, 0x00
00007e55d47dc2fa  vmovaps xmm2, [rsp+0x70]
00007e55d47dc300  vmovaps [rsp+0x50], xmm1
00007e55d47dc306  movaps xmm4, xmm2
00007e55d47dc309  mulpd xmm4, xmm9
00007e55d47dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007e55d47dc313  ptest xmm1, xmm1
00007e55d47dc318  jnz 0x00007E55D47DEE35
00007e55d47dc31e  vmovaps xmm1, [rsp+0x30]
00007e55d47dc324  vpermilpd xmm1, xmm1, 0x00
00007e55d47dc32a  vmovaps xmm2, [rsp+0x90]
00007e55d47dc333  vmovaps [rsp+0x60], xmm15
00007e55d47dc339  movaps xmm9, xmm2
00007e55d47dc33d  mulpd xmm9, xmm1
00007e55d47dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007e55d47dc348  ptest xmm15, xmm15
00007e55d47dc34e  jnz 0x00007E55D47DEF76
00007e55d47dc354  vmovaps xmm15, [rsp+0x80]
00007e55d47dc35d  movaps xmm1, xmm15
00007e55d47dc361  addpd xmm1, xmm6
00007e55d47dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007e55d47dc36a  ptest xmm2, xmm2
00007e55d47dc36f  jnz 0x00007E55D47DF0B8
00007e55d47dc375  movaps xmm15, xmm5
00007e55d47dc379  addpd xmm15, xmm3
00007e55d47dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007e55d47dc384  ptest xmm6, xmm6
00007e55d47dc389  jnz 0x00007E55D47DF1F9
00007e55d47dc38f  vmovaps xmm6, [rsp+0x30]
00007e55d47dc395  vpermilpd xmm6, xmm6, 0x00
00007e55d47dc39b  movaps xmm5, xmm8
00007e55d47dc39f  mulpd xmm5, xmm6
00007e55d47dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007e55d47dc3a8  ptest xmm3, xmm3
00007e55d47dc3ad  jnz 0x00007E55D47DF33B
00007e55d47dc3b3  vmovaps xmm8, [rsp+0x30]
00007e55d47dc3b9  vpermilpd xmm8, xmm8, 0x00
00007e55d47dc3bf  movaps xmm6, xmm10
00007e55d47dc3c3  mulpd xmm6, xmm8
00007e55d47dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007e55d47dc3cd  ptest xmm3, xmm3
00007e55d47dc3d2  jnz 0x00007E55D47DF47C
00007e55d47dc3d8  vmovaps xmm8, [rsp+0x60]
00007e55d47dc3de  movaps xmm10, xmm8
00007e55d47dc3e2  addpd xmm10, xmm14
00007e55d47dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007e55d47dc3ed  ptest xmm3, xmm3
00007e55d47dc3f2  jnz 0x00007E55D47DF5BE
00007e55d47dc3f8  vmovaps xmm8, [rsp+0x50]
00007e55d47dc3fe  movaps xmm14, xmm8
00007e55d47dc402  addpd xmm14, xmm4
00007e55d47dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007e55d47dc40d  ptest xmm3, xmm3
00007e55d47dc412  jnz 0x00007E55D47DF702
00007e55d47dc418  vmovaps xmm8, [rsp+0x40]
00007e55d47dc41e  vpermilpd xmm8, xmm8, 0x00
00007e55d47dc424  movaps xmm4, xmm13
00007e55d47dc428  mulpd xmm4, xmm8
00007e55d47dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007e55d47dc432  ptest xmm3, xmm3
00007e55d47dc437  jnz 0x00007E55D47DF845
00007e55d47dc43d  movaps xmm13, xmm15
00007e55d47dc441  addpd xmm13, xmm9
00007e55d47dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007e55d47dc44c  ptest xmm8, xmm8
00007e55d47dc452  jnz 0x00007E55D47DF987
00007e55d47dc458  movaps xmm15, xmm1
00007e55d47dc45c  addpd xmm15, xmm5
00007e55d47dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007e55d47dc467  ptest xmm9, xmm9
00007e55d47dc46d  jnz 0x00007E55D47DFACB
00007e55d47dc473  vmovaps [rsp+0x30], xmm11
00007e55d47dc479  vmovaps xmm1, [rsp+0x30]
00007e55d47dc47f  por xmm11, xmm1
00007e55d47dc484  movaps [r15+0x250], xmm11
00007e55d47dc48c  vmovaps [rsp+0x30], xmm12
00007e55d47dc492  vmovaps xmm1, [rsp+0x30]
00007e55d47dc498  por xmm12, xmm1
00007e55d47dc49d  movaps [r15+0x2A0], xmm12
00007e55d47dc4a5  vmovaps xmm1, [rsp+0xA0]
00007e55d47dc4ae  vmovaps xmm11, [rsp+0xA0]
00007e55d47dc4b7  por xmm1, xmm11
00007e55d47dc4bc  movaps [r15+0x1D0], xmm1
00007e55d47dc4c4  lea r12, [rax+0x40]
00007e55d47dc4c8  movups xmm1, [r13+r12*1]
00007e55d47dc4ce  movaps [r15+0x2C0], xmm1
00007e55d47dc4d6  vmovaps xmm11, [rsp+0x40]
00007e55d47dc4dc  vpermilpd xmm11, xmm11, 0x00
00007e55d47dc4e2  vmovaps xmm8, [rsp+0xE0]
00007e55d47dc4eb  movaps xmm9, xmm8
00007e55d47dc4ef  mulpd xmm9, xmm11
00007e55d47dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007e55d47dc4fa  ptest xmm5, xmm5
00007e55d47dc4ff  jnz 0x00007E55D47DFC17
00007e55d47dc505  movaps xmm11, xmm10
00007e55d47dc509  addpd xmm11, xmm6
00007e55d47dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007e55d47dc514  ptest xmm8, xmm8
00007e55d47dc51a  jnz 0x00007E55D47DFD5B
00007e55d47dc520  movaps xmm10, xmm14
00007e55d47dc524  addpd xmm10, xmm4
00007e55d47dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007e55d47dc52f  ptest xmm8, xmm8
00007e55d47dc535  jnz 0x00007E55D47DFE9E
00007e55d47dc53b  vmovaps xmm14, [rsp+0x40]
00007e55d47dc541  vpermilpd xmm14, xmm14, 0x00
00007e55d47dc547  movaps xmm8, xmm1
00007e55d47dc54b  mulpd xmm8, xmm14
00007e55d47dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007e55d47dc556  ptest xmm6, xmm6
00007e55d47dc55b  jnz 0x00007E55D47DFFE1
00007e55d47dc561  movaps xmm1, [r15+0x2B0]
00007e55d47dc569  vmovaps xmm14, [rsp+0x40]
00007e55d47dc56f  vpermilpd xmm14, xmm14, 0x00
00007e55d47dc575  movaps xmm6, xmm1
00007e55d47dc578  mulpd xmm6, xmm14
00007e55d47dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007e55d47dc582  ptest xmm5, xmm5
00007e55d47dc587  jnz 0x00007E55D47E0124
00007e55d47dc58d  vmovaps xmm1, [rsp+0x10]
00007e55d47dc593  vpermilpd xmm1, xmm1, 0x00
00007e55d47dc599  movaps xmm14, xmm12
00007e55d47dc59d  mulpd xmm14, xmm1
00007e55d47dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007e55d47dc5a8  ptest xmm5, xmm5
00007e55d47dc5ad  jnz 0x00007E55D47E0265
00007e55d47dc5b3  movaps xmm1, xmm13
00007e55d47dc5b7  addpd xmm1, xmm9
00007e55d47dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007e55d47dc5c1  ptest xmm12, xmm12
00007e55d47dc5c7  jnz 0x00007E55D47E03A8
00007e55d47dc5cd  vmovaps xmm13, [rsp+0x10]
00007e55d47dc5d3  vpermilpd xmm13, xmm13, 0x00
00007e55d47dc5d9  movaps xmm12, xmm7
00007e55d47dc5dd  mulpd xmm12, xmm13
00007e55d47dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007e55d47dc5e8  ptest xmm9, xmm9
00007e55d47dc5ee  jnz 0x00007E55D47E04EA
00007e55d47dc5f4  movaps xmm13, xmm15
00007e55d47dc5f8  addpd xmm13, xmm8
00007e55d47dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007e55d47dc603  ptest xmm9, xmm9
00007e55d47dc609  jnz 0x00007E55D47E062D
00007e55d47dc60f  movaps xmm15, [r15+0x290]
00007e55d47dc617  vmovaps xmm9, [rsp+0x10]
00007e55d47dc61d  vpermilpd xmm9, xmm9, 0x00
00007e55d47dc623  movaps xmm8, xmm15
00007e55d47dc627  mulpd xmm8, xmm9
00007e55d47dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007e55d47dc632  ptest xmm7, xmm7
00007e55d47dc637  jnz 0x00007E55D47E0771
00007e55d47dc63d  movaps xmm15, xmm11
00007e55d47dc641  addpd xmm15, xmm6
00007e55d47dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007e55d47dc64c  ptest xmm9, xmm9
00007e55d47dc652  jnz 0x00007E55D47E08B5
00007e55d47dc658  movaps xmm11, [r15+0x1E0]
00007e55d47dc660  vmovaps xmm9, [rsp+0x10]
00007e55d47dc666  vpermilpd xmm9, xmm9, 0x00
00007e55d47dc66c  movaps xmm7, xmm11
00007e55d47dc670  mulpd xmm7, xmm9
00007e55d47dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007e55d47dc67a  ptest xmm6, xmm6
00007e55d47dc67f  jnz 0x00007E55D47E09F8
00007e55d47dc685  movaps xmm11, xmm10
00007e55d47dc689  addpd xmm11, xmm14
00007e55d47dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007e55d47dc694  ptest xmm9, xmm9
00007e55d47dc69a  jnz 0x00007E55D47E0B3A
00007e55d47dc6a0  lea r12, [rax+0x70]
00007e55d47dc6a4  movups xmm14, [r13+r12*1]
00007e55d47dc6aa  movaps [r15+0x240], xmm14
00007e55d47dc6b2  movaps xmm10, xmm1
00007e55d47dc6b6  addpd xmm10, xmm12
00007e55d47dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007e55d47dc6c1  ptest xmm9, xmm9
00007e55d47dc6c7  jnz 0x00007E55D47E0C88
00007e55d47dc6cd  movaps [r15+0x170], xmm10
00007e55d47dc6d5  vmovaps xmm1, [rsp+0x20]
00007e55d47dc6db  vpermilpd xmm1, xmm1, 0x00
00007e55d47dc6e1  movaps xmm12, xmm14
00007e55d47dc6e5  mulpd xmm12, xmm1
00007e55d47dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007e55d47dc6f0  ptest xmm9, xmm9
00007e55d47dc6f6  jnz 0x00007E55D47E0DCB
00007e55d47dc6fc  vmovaps xmm1, [rsp+0x20]
00007e55d47dc702  vpermilpd xmm1, xmm1, 0x00
00007e55d47dc708  vmovaps xmm9, [rsp+0xB0]
00007e55d47dc711  movaps xmm14, xmm9
00007e55d47dc715  mulpd xmm14, xmm1
00007e55d47dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007e55d47dc720  ptest xmm6, xmm6
00007e55d47dc725  jnz 0x00007E55D47E0F0E
00007e55d47dc72b  movaps [r15+0x180], xmm14
00007e55d47dc733  movaps xmm1, xmm13
00007e55d47dc737  addpd xmm1, xmm8
00007e55d47dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007e55d47dc741  ptest xmm9, xmm9
00007e55d47dc747  jnz 0x00007E55D47E1051
00007e55d47dc74d  movaps [r15+0x210], xmm1
00007e55d47dc755  movups xmm13, [r13+rax*1]
00007e55d47dc75b  lea r12, [rax+0x10]
00007e55d47dc75f  movups xmm9, [r13+r12*1]
00007e55d47dc765  movaps [r15+0x230], xmm9
00007e55d47dc76d  movaps xmm8, xmm15
00007e55d47dc771  addpd xmm8, xmm7
00007e55d47dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007e55d47dc77c  ptest xmm6, xmm6
00007e55d47dc781  jnz 0x00007E55D47E11A7
00007e55d47dc787  movaps [r15+0x130], xmm8
00007e55d47dc78f  vmovaps xmm15, [rsp+0x20]
00007e55d47dc795  vpermilpd xmm15, xmm15, 0x00
00007e55d47dc79b  movaps xmm7, xmm9
00007e55d47dc79f  mulpd xmm7, xmm15
00007e55d47dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007e55d47dc7a9  ptest xmm6, xmm6
00007e55d47dc7ae  jnz 0x00007E55D47E12EA
00007e55d47dc7b4  movaps [r15+0x220], xmm7
00007e55d47dc7bc  vmovaps xmm15, [rsp+0x20]
00007e55d47dc7c2  vpermilpd xmm15, xmm15, 0x00
00007e55d47dc7c8  movaps xmm9, xmm13
00007e55d47dc7cc  mulpd xmm9, xmm15
00007e55d47dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007e55d47dc7d7  ptest xmm6, xmm6
00007e55d47dc7dc  jnz 0x00007E55D47E142C
00007e55d47dc7e2  movaps xmm15, xmm11
00007e55d47dc7e6  addpd xmm15, xmm12
00007e55d47dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007e55d47dc7f1  ptest xmm13, xmm13
00007e55d47dc7f7  jnz 0x00007E55D47E1570
00007e55d47dc7fd  movaps [r15+0x140], xmm15
00007e55d47dc805  movaps xmm13, xmm10
00007e55d47dc809  addpd xmm13, xmm14
00007e55d47dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007e55d47dc814  ptest xmm12, xmm12
00007e55d47dc81a  jnz 0x00007E55D47E16B4
00007e55d47dc820  movaps [r15+0x150], xmm13
00007e55d47dc828  movaps xmm14, xmm1
00007e55d47dc82c  addpd xmm14, xmm7
00007e55d47dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007e55d47dc837  ptest xmm12, xmm12
00007e55d47dc83d  jnz 0x00007E55D47E17F8
00007e55d47dc843  movaps [r15+0x160], xmm14
00007e55d47dc84b  movaps xmm1, xmm8
00007e55d47dc84f  addpd xmm1, xmm9
00007e55d47dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007e55d47dc859  ptest xmm12, xmm12
00007e55d47dc85f  jnz 0x00007E55D47E193A
00007e55d47dc865  movaps [r15+0x120], xmm1
00007e55d47dc86d  movups [r13+r14*1], xmm15
00007e55d47dc873  lea rax, [r14+0x10]
00007e55d47dc877  movups [r13+rax*1], xmm13
00007e55d47dc87d  lea rax, [r14+0x20]
00007e55d47dc881  movups [r13+rax*1], xmm14
00007e55d47dc887  lea rax, [r14+0x30]
00007e55d47dc88b  movups [r13+rax*1], xmm1
00007e55d47dc891  mov eax, [r15+0x108]
00007e55d47dc898  sahf
00007e55d47dc899  jnz 0x00007E55D47DC8CB
00007e55d47dc89b  cmp dword ptr [r15+0x318], 0x00
00007e55d47dc8a3  jz 0x00007E55D47DB900
00007e55d47dc8a9  nop [rax+rax*1], ax
00007e55d47dc8b2  nop [rax+rax*1], eax
00007e55d47dc8ba  mov eax, 0x410444
00007e55d47dc8bf  mov [r15+0x100], rax
00007e55d47dc8c6  jmp 0x00007E55D45FE110
00007e55d47dc8cb  cmp dword ptr [r15+0x318], 0x00
00007e55d47dc8d3  jz 0x00007E55D47D57E0
00007e55d47dc8d9  nop [rax+rax*1], ax
00007e55d47dc8e2  nop [rax+rax*1], eax
00007e55d47dc8ea  mov eax, 0x410278
00007e55d47dc8ef  mov [r15+0x100], rax
00007e55d47dc8f6  jmp 0x00007E55D45FE110
00007e55d47dc8fb  int3
00007e55d47dc8fc  call 0x00007E55D46E27E0
00007e55d47dc901  jmp 0x00007E55D47DB9DF
00007e55d47dc906  call 0x00007E55D46E1570
00007e55d47dc90b  jmp 0x00007E55D47DB9E8
00007e55d47dc910  call 0x00007E55D46E27E0
00007e55d47dc915  jmp 0x00007E55D47DBA44
00007e55d47dc91a  call 0x00007E55D46E1570
00007e55d47dc91f  jmp 0x00007E55D47DBA4D
00007e55d47dc924  call 0x00007E55D46E27E0
00007e55d47dc929  jmp 0x00007E55D47DBA90
00007e55d47dc92e  call 0x00007E55D46E1570
00007e55d47dc933  jmp 0x00007E55D47DBA99
00007e55d47dc938  call 0x00007E55D460DC20
00007e55d47dc93d  jmp 0x00007E55D47DBAD8
00007e55d47dc942  call 0x00007E55D46D59C0
00007e55d47dc947  jmp 0x00007E55D47DBAEB
00007e55d47dc94c  call 0x00007E55D46E0E30
00007e55d47dc951  jmp 0x00007E55D47DBB09
00007e55d47dc956  call 0x00007E55D46DFBC0
00007e55d47dc95b  jmp 0x00007E55D47DBB13
00007e55d47dc960  call 0x00007E55D46DE950
00007e55d47dc965  jmp 0x00007E55D47DBB1D
00007e55d47dc96a  sub rsp, 0x08
00007e55d47dc96e  push rax
00007e55d47dc96f  push rcx
00007e55d47dc970  push rdx
00007e55d47dc971  push rdi
00007e55d47dc972  push rsi
00007e55d47dc973  push r8
00007e55d47dc975  push r9
00007e55d47dc977  push r10
00007e55d47dc979  push r11
00007e55d47dc97b  sub rsp, 0xF0
00007e55d47dc982  vmovaps [rsp], xmm0
00007e55d47dc987  vmovaps [rsp+0x10], xmm1
00007e55d47dc98d  vmovaps [rsp+0x20], xmm2
00007e55d47dc993  vmovaps [rsp+0x30], xmm3
00007e55d47dc999  vmovaps [rsp+0x40], xmm4
00007e55d47dc99f  vmovaps [rsp+0x50], xmm5
00007e55d47dc9a5  vmovaps [rsp+0x60], xmm6
00007e55d47dc9ab  vmovaps [rsp+0x70], xmm7
00007e55d47dc9b1  vmovaps [rsp+0x80], xmm9
00007e55d47dc9ba  vmovaps [rsp+0x90], xmm10
00007e55d47dc9c3  vmovaps [rsp+0xA0], xmm11
00007e55d47dc9cc  vmovaps [rsp+0xB0], xmm12
00007e55d47dc9d5  vmovaps [rsp+0xC0], xmm13
00007e55d47dc9de  vmovaps [rsp+0xD0], xmm14
00007e55d47dc9e7  vmovaps [rsp+0xE0], xmm15
00007e55d47dc9f0  sub rsp, 0x30
00007e55d47dc9f4  movaps [rsp], xmm8
00007e55d47dc9f9  movaps [rsp+0x10], xmm12
00007e55d47dc9ff  movaps [rsp+0x20], xmm15
00007e55d47dca05  lea rdi, [rsp]
00007e55d47dca09  mov esi, 0x00
00007e55d47dca0e  mov rax, 0x55D0734A4530
00007e55d47dca18  call rax
00007e55d47dca1a  movaps xmm8, [rsp]
00007e55d47dca1f  add rsp, 0x30
00007e55d47dca23  vmovaps xmm0, [rsp]
00007e55d47dca28  vmovaps xmm1, [rsp+0x10]
00007e55d47dca2e  vmovaps xmm2, [rsp+0x20]
00007e55d47dca34  vmovaps xmm3, [rsp+0x30]
00007e55d47dca3a  vmovaps xmm4, [rsp+0x40]
00007e55d47dca40  vmovaps xmm5, [rsp+0x50]
00007e55d47dca46  vmovaps xmm6, [rsp+0x60]
00007e55d47dca4c  vmovaps xmm7, [rsp+0x70]
00007e55d47dca52  vmovaps xmm9, [rsp+0x80]
00007e55d47dca5b  vmovaps xmm10, [rsp+0x90]
00007e55d47dca64  vmovaps xmm11, [rsp+0xA0]
00007e55d47dca6d  vmovaps xmm12, [rsp+0xB0]
00007e55d47dca76  vmovaps xmm13, [rsp+0xC0]
00007e55d47dca7f  vmovaps xmm14, [rsp+0xD0]
00007e55d47dca88  vmovaps xmm15, [rsp+0xE0]
00007e55d47dca91  add rsp, 0xF0
00007e55d47dca98  pop r11
00007e55d47dca9a  pop r10
00007e55d47dca9c  pop r9
00007e55d47dca9e  pop r8
00007e55d47dcaa0  pop rsi
00007e55d47dcaa1  pop rdi
00007e55d47dcaa2  pop rdx
00007e55d47dcaa3  pop rcx
00007e55d47dcaa4  pop rax
00007e55d47dcaa5  add rsp, 0x08
00007e55d47dcaa9  jmp 0x00007E55D47DBB47
00007e55d47dcaae  sub rsp, 0x08
00007e55d47dcab2  push rax
00007e55d47dcab3  push rcx
00007e55d47dcab4  push rdx
00007e55d47dcab5  push rdi
00007e55d47dcab6  push rsi
00007e55d47dcab7  push r8
00007e55d47dcab9  push r9
00007e55d47dcabb  push r10
00007e55d47dcabd  push r11
00007e55d47dcabf  sub rsp, 0xF0
00007e55d47dcac6  vmovaps [rsp], xmm0
00007e55d47dcacb  vmovaps [rsp+0x10], xmm1
00007e55d47dcad1  vmovaps [rsp+0x20], xmm2
00007e55d47dcad7  vmovaps [rsp+0x30], xmm3
00007e55d47dcadd  vmovaps [rsp+0x40], xmm4
00007e55d47dcae3  vmovaps [rsp+0x50], xmm5
00007e55d47dcae9  vmovaps [rsp+0x60], xmm6
00007e55d47dcaef  vmovaps [rsp+0x70], xmm8
00007e55d47dcaf5  vmovaps [rsp+0x80], xmm9
00007e55d47dcafe  vmovaps [rsp+0x90], xmm10
00007e55d47dcb07  vmovaps [rsp+0xA0], xmm11
00007e55d47dcb10  vmovaps [rsp+0xB0], xmm12
00007e55d47dcb19  vmovaps [rsp+0xC0], xmm13
00007e55d47dcb22  vmovaps [rsp+0xD0], xmm14
00007e55d47dcb2b  vmovaps [rsp+0xE0], xmm15
00007e55d47dcb34  sub rsp, 0x30
00007e55d47dcb38  movaps [rsp], xmm7
00007e55d47dcb3c  movaps [rsp+0x10], xmm9
00007e55d47dcb42  movaps [rsp+0x20], xmm15
00007e55d47dcb48  lea rdi, [rsp]
00007e55d47dcb4c  mov esi, 0x00
00007e55d47dcb51  mov rax, 0x55D0734A4530
00007e55d47dcb5b  call rax
00007e55d47dcb5d  movaps xmm7, [rsp]
00007e55d47dcb61  add rsp, 0x30
00007e55d47dcb65  vmovaps xmm0, [rsp]
00007e55d47dcb6a  vmovaps xmm1, [rsp+0x10]
00007e55d47dcb70  vmovaps xmm2, [rsp+0x20]
00007e55d47dcb76  vmovaps xmm3, [rsp+0x30]
00007e55d47dcb7c  vmovaps xmm4, [rsp+0x40]
00007e55d47dcb82  vmovaps xmm5, [rsp+0x50]
00007e55d47dcb88  vmovaps xmm6, [rsp+0x60]
00007e55d47dcb8e  vmovaps xmm8, [rsp+0x70]
00007e55d47dcb94  vmovaps xmm9, [rsp+0x80]
00007e55d47dcb9d  vmovaps xmm10, [rsp+0x90]
00007e55d47dcba6  vmovaps xmm11, [rsp+0xA0]
00007e55d47dcbaf  vmovaps xmm12, [rsp+0xB0]
00007e55d47dcbb8  vmovaps xmm13, [rsp+0xC0]
00007e55d47dcbc1  vmovaps xmm14, [rsp+0xD0]
00007e55d47dcbca  vmovaps xmm15, [rsp+0xE0]
00007e55d47dcbd3  add rsp, 0xF0
00007e55d47dcbda  pop r11
00007e55d47dcbdc  pop r10
00007e55d47dcbde  pop r9
00007e55d47dcbe0  pop r8
00007e55d47dcbe2  pop rsi
00007e55d47dcbe3  pop rdi
00007e55d47dcbe4  pop rdx
00007e55d47dcbe5  pop rcx
00007e55d47dcbe6  pop rax
00007e55d47dcbe7  add rsp, 0x08
00007e55d47dcbeb  jmp 0x00007E55D47DBB75
00007e55d47dcbf0  sub rsp, 0x08
00007e55d47dcbf4  push rax
00007e55d47dcbf5  push rcx
00007e55d47dcbf6  push rdx
00007e55d47dcbf7  push rdi
00007e55d47dcbf8  push rsi
00007e55d47dcbf9  push r8
00007e55d47dcbfb  push r9
00007e55d47dcbfd  push r10
00007e55d47dcbff  push r11
00007e55d47dcc01  sub rsp, 0xF0
00007e55d47dcc08  vmovaps [rsp], xmm0
00007e55d47dcc0d  vmovaps [rsp+0x10], xmm1
00007e55d47dcc13  vmovaps [rsp+0x20], xmm2
00007e55d47dcc19  vmovaps [rsp+0x30], xmm3
00007e55d47dcc1f  vmovaps [rsp+0x40], xmm4
00007e55d47dcc25  vmovaps [rsp+0x50], xmm5
00007e55d47dcc2b  vmovaps [rsp+0x60], xmm6
00007e55d47dcc31  vmovaps [rsp+0x70], xmm7
00007e55d47dcc37  vmovaps [rsp+0x80], xmm8
00007e55d47dcc40  vmovaps [rsp+0x90], xmm10
00007e55d47dcc49  vmovaps [rsp+0xA0], xmm11
00007e55d47dcc52  vmovaps [rsp+0xB0], xmm12
00007e55d47dcc5b  vmovaps [rsp+0xC0], xmm13
00007e55d47dcc64  vmovaps [rsp+0xD0], xmm14
00007e55d47dcc6d  vmovaps [rsp+0xE0], xmm15
00007e55d47dcc76  sub rsp, 0x30
00007e55d47dcc7a  movaps [rsp], xmm9
00007e55d47dcc7f  movaps [rsp+0x10], xmm12
00007e55d47dcc85  movaps [rsp+0x20], xmm10
00007e55d47dcc8b  lea rdi, [rsp]
00007e55d47dcc8f  mov esi, 0x00
00007e55d47dcc94  mov rax, 0x55D0734A4530
00007e55d47dcc9e  call rax
00007e55d47dcca0  movaps xmm9, [rsp]
00007e55d47dcca5  add rsp, 0x30
00007e55d47dcca9  vmovaps xmm0, [rsp]
00007e55d47dccae  vmovaps xmm1, [rsp+0x10]
00007e55d47dccb4  vmovaps xmm2, [rsp+0x20]
00007e55d47dccba  vmovaps xmm3, [rsp+0x30]
00007e55d47dccc0  vmovaps xmm4, [rsp+0x40]
00007e55d47dccc6  vmovaps xmm5, [rsp+0x50]
00007e55d47dcccc  vmovaps xmm6, [rsp+0x60]
00007e55d47dccd2  vmovaps xmm7, [rsp+0x70]
00007e55d47dccd8  vmovaps xmm8, [rsp+0x80]
00007e55d47dcce1  vmovaps xmm10, [rsp+0x90]
00007e55d47dccea  vmovaps xmm11, [rsp+0xA0]
00007e55d47dccf3  vmovaps xmm12, [rsp+0xB0]
00007e55d47dccfc  vmovaps xmm13, [rsp+0xC0]
00007e55d47dcd05  vmovaps xmm14, [rsp+0xD0]
00007e55d47dcd0e  vmovaps xmm15, [rsp+0xE0]
00007e55d47dcd17  add rsp, 0xF0
00007e55d47dcd1e  pop r11
00007e55d47dcd20  pop r10
00007e55d47dcd22  pop r9
00007e55d47dcd24  pop r8
00007e55d47dcd26  pop rsi
00007e55d47dcd27  pop rdi
00007e55d47dcd28  pop rdx
00007e55d47dcd29  pop rcx
00007e55d47dcd2a  pop rax
00007e55d47dcd2b  add rsp, 0x08
00007e55d47dcd2f  jmp 0x00007E55D47DBB99
00007e55d47dcd34  sub rsp, 0x08
00007e55d47dcd38  push rax
00007e55d47dcd39  push rcx
00007e55d47dcd3a  push rdx
00007e55d47dcd3b  push rdi
00007e55d47dcd3c  push rsi
00007e55d47dcd3d  push r8
00007e55d47dcd3f  push r9
00007e55d47dcd41  push r10
00007e55d47dcd43  push r11
00007e55d47dcd45  sub rsp, 0xF0
00007e55d47dcd4c  vmovaps [rsp], xmm0
00007e55d47dcd51  vmovaps [rsp+0x10], xmm1
00007e55d47dcd57  vmovaps [rsp+0x20], xmm2
00007e55d47dcd5d  vmovaps [rsp+0x30], xmm3
00007e55d47dcd63  vmovaps [rsp+0x40], xmm4
00007e55d47dcd69  vmovaps [rsp+0x50], xmm5
00007e55d47dcd6f  vmovaps [rsp+0x60], xmm6
00007e55d47dcd75  vmovaps [rsp+0x70], xmm7
00007e55d47dcd7b  vmovaps [rsp+0x80], xmm8
00007e55d47dcd84  vmovaps [rsp+0x90], xmm9
00007e55d47dcd8d  vmovaps [rsp+0xA0], xmm11
00007e55d47dcd96  vmovaps [rsp+0xB0], xmm12
00007e55d47dcd9f  vmovaps [rsp+0xC0], xmm13
00007e55d47dcda8  vmovaps [rsp+0xD0], xmm14
00007e55d47dcdb1  vmovaps [rsp+0xE0], xmm15
00007e55d47dcdba  sub rsp, 0x30
00007e55d47dcdbe  movaps [rsp], xmm10
00007e55d47dcdc3  movaps [rsp+0x10], xmm12
00007e55d47dcdc9  movaps [rsp+0x20], xmm11
00007e55d47dcdcf  lea rdi, [rsp]
00007e55d47dcdd3  mov esi, 0x00
00007e55d47dcdd8  mov rax, 0x55D0734A4530
00007e55d47dcde2  call rax
00007e55d47dcde4  movaps xmm10, [rsp]
00007e55d47dcde9  add rsp, 0x30
00007e55d47dcded  vmovaps xmm0, [rsp]
00007e55d47dcdf2  vmovaps xmm1, [rsp+0x10]
00007e55d47dcdf8  vmovaps xmm2, [rsp+0x20]
00007e55d47dcdfe  vmovaps xmm3, [rsp+0x30]
00007e55d47dce04  vmovaps xmm4, [rsp+0x40]
00007e55d47dce0a  vmovaps xmm5, [rsp+0x50]
00007e55d47dce10  vmovaps xmm6, [rsp+0x60]
00007e55d47dce16  vmovaps xmm7, [rsp+0x70]
00007e55d47dce1c  vmovaps xmm8, [rsp+0x80]
00007e55d47dce25  vmovaps xmm9, [rsp+0x90]
00007e55d47dce2e  vmovaps xmm11, [rsp+0xA0]
00007e55d47dce37  vmovaps xmm12, [rsp+0xB0]
00007e55d47dce40  vmovaps xmm13, [rsp+0xC0]
00007e55d47dce49  vmovaps xmm14, [rsp+0xD0]
00007e55d47dce52  vmovaps xmm15, [rsp+0xE0]
00007e55d47dce5b  add rsp, 0xF0
00007e55d47dce62  pop r11
00007e55d47dce64  pop r10
00007e55d47dce66  pop r9
00007e55d47dce68  pop r8
00007e55d47dce6a  pop rsi
00007e55d47dce6b  pop rdi
00007e55d47dce6c  pop rdx
00007e55d47dce6d  pop rcx
00007e55d47dce6e  pop rax
00007e55d47dce6f  add rsp, 0x08
00007e55d47dce73  jmp 0x00007E55D47DBBB3
00007e55d47dce78  sub rsp, 0x08
00007e55d47dce7c  push rax
00007e55d47dce7d  push rcx
00007e55d47dce7e  push rdx
00007e55d47dce7f  push rdi
00007e55d47dce80  push rsi
00007e55d47dce81  push r8
00007e55d47dce83  push r9
00007e55d47dce85  push r10
00007e55d47dce87  push r11
00007e55d47dce89  sub rsp, 0xF0
00007e55d47dce90  vmovaps [rsp], xmm0
00007e55d47dce95  vmovaps [rsp+0x10], xmm1
00007e55d47dce9b  vmovaps [rsp+0x20], xmm2
00007e55d47dcea1  vmovaps [rsp+0x30], xmm3
00007e55d47dcea7  vmovaps [rsp+0x40], xmm4
00007e55d47dcead  vmovaps [rsp+0x50], xmm5
00007e55d47dceb3  vmovaps [rsp+0x60], xmm7
00007e55d47dceb9  vmovaps [rsp+0x70], xmm8
00007e55d47dcebf  vmovaps [rsp+0x80], xmm9
00007e55d47dcec8  vmovaps [rsp+0x90], xmm10
00007e55d47dced1  vmovaps [rsp+0xA0], xmm11
00007e55d47dceda  vmovaps [rsp+0xB0], xmm12
00007e55d47dcee3  vmovaps [rsp+0xC0], xmm13
00007e55d47dceec  vmovaps [rsp+0xD0], xmm14
00007e55d47dcef5  vmovaps [rsp+0xE0], xmm15
00007e55d47dcefe  sub rsp, 0x30
00007e55d47dcf02  movaps [rsp], xmm6
00007e55d47dcf06  movaps [rsp+0x10], xmm12
00007e55d47dcf0c  movaps [rsp+0x20], xmm11
00007e55d47dcf12  lea rdi, [rsp]
00007e55d47dcf16  mov esi, 0x00
00007e55d47dcf1b  mov rax, 0x55D0734A4530
00007e55d47dcf25  call rax
00007e55d47dcf27  movaps xmm6, [rsp]
00007e55d47dcf2b  add rsp, 0x30
00007e55d47dcf2f  vmovaps xmm0, [rsp]
00007e55d47dcf34  vmovaps xmm1, [rsp+0x10]
00007e55d47dcf3a  vmovaps xmm2, [rsp+0x20]
00007e55d47dcf40  vmovaps xmm3, [rsp+0x30]
00007e55d47dcf46  vmovaps xmm4, [rsp+0x40]
00007e55d47dcf4c  vmovaps xmm5, [rsp+0x50]
00007e55d47dcf52  vmovaps xmm7, [rsp+0x60]
00007e55d47dcf58  vmovaps xmm8, [rsp+0x70]
00007e55d47dcf5e  vmovaps xmm9, [rsp+0x80]
00007e55d47dcf67  vmovaps xmm10, [rsp+0x90]
00007e55d47dcf70  vmovaps xmm11, [rsp+0xA0]
00007e55d47dcf79  vmovaps xmm12, [rsp+0xB0]
00007e55d47dcf82  vmovaps xmm13, [rsp+0xC0]
00007e55d47dcf8b  vmovaps xmm14, [rsp+0xD0]
00007e55d47dcf94  vmovaps xmm15, [rsp+0xE0]
00007e55d47dcf9d  add rsp, 0xF0
00007e55d47dcfa4  pop r11
00007e55d47dcfa6  pop r10
00007e55d47dcfa8  pop r9
00007e55d47dcfaa  pop r8
00007e55d47dcfac  pop rsi
00007e55d47dcfad  pop rdi
00007e55d47dcfae  pop rdx
00007e55d47dcfaf  pop rcx
00007e55d47dcfb0  pop rax
00007e55d47dcfb1  add rsp, 0x08
00007e55d47dcfb5  jmp 0x00007E55D47DBBD4
00007e55d47dcfba  sub rsp, 0x08
00007e55d47dcfbe  push rax
00007e55d47dcfbf  push rcx
00007e55d47dcfc0  push rdx
00007e55d47dcfc1  push rdi
00007e55d47dcfc2  push rsi
00007e55d47dcfc3  push r8
00007e55d47dcfc5  push r9
00007e55d47dcfc7  push r10
00007e55d47dcfc9  push r11
00007e55d47dcfcb  sub rsp, 0xF0
00007e55d47dcfd2  vmovaps [rsp], xmm0
00007e55d47dcfd7  vmovaps [rsp+0x10], xmm1
00007e55d47dcfdd  vmovaps [rsp+0x20], xmm2
00007e55d47dcfe3  vmovaps [rsp+0x30], xmm4
00007e55d47dcfe9  vmovaps [rsp+0x40], xmm5
00007e55d47dcfef  vmovaps [rsp+0x50], xmm6
00007e55d47dcff5  vmovaps [rsp+0x60], xmm7
00007e55d47dcffb  vmovaps [rsp+0x70], xmm8
00007e55d47dd001  vmovaps [rsp+0x80], xmm9
00007e55d47dd00a  vmovaps [rsp+0x90], xmm10
00007e55d47dd013  vmovaps [rsp+0xA0], xmm11
00007e55d47dd01c  vmovaps [rsp+0xB0], xmm12
00007e55d47dd025  vmovaps [rsp+0xC0], xmm13
00007e55d47dd02e  vmovaps [rsp+0xD0], xmm14
00007e55d47dd037  vmovaps [rsp+0xE0], xmm15
00007e55d47dd040  sub rsp, 0x30
00007e55d47dd044  movaps [rsp], xmm3
00007e55d47dd048  movaps [rsp+0x10], xmm5
00007e55d47dd04d  movaps [rsp+0x20], xmm4
00007e55d47dd052  lea rdi, [rsp]
00007e55d47dd056  mov esi, 0x00
00007e55d47dd05b  mov rax, 0x55D0734A4530
00007e55d47dd065  call rax
00007e55d47dd067  movaps xmm3, [rsp]
00007e55d47dd06b  add rsp, 0x30
00007e55d47dd06f  vmovaps xmm0, [rsp]
00007e55d47dd074  vmovaps xmm1, [rsp+0x10]
00007e55d47dd07a  vmovaps xmm2, [rsp+0x20]
00007e55d47dd080  vmovaps xmm4, [rsp+0x30]
00007e55d47dd086  vmovaps xmm5, [rsp+0x40]
00007e55d47dd08c  vmovaps xmm6, [rsp+0x50]
00007e55d47dd092  vmovaps xmm7, [rsp+0x60]
00007e55d47dd098  vmovaps xmm8, [rsp+0x70]
00007e55d47dd09e  vmovaps xmm9, [rsp+0x80]
00007e55d47dd0a7  vmovaps xmm10, [rsp+0x90]
00007e55d47dd0b0  vmovaps xmm11, [rsp+0xA0]
00007e55d47dd0b9  vmovaps xmm12, [rsp+0xB0]
00007e55d47dd0c2  vmovaps xmm13, [rsp+0xC0]
00007e55d47dd0cb  vmovaps xmm14, [rsp+0xD0]
00007e55d47dd0d4  vmovaps xmm15, [rsp+0xE0]
00007e55d47dd0dd  add rsp, 0xF0
00007e55d47dd0e4  pop r11
00007e55d47dd0e6  pop r10
00007e55d47dd0e8  pop r9
00007e55d47dd0ea  pop r8
00007e55d47dd0ec  pop rsi
00007e55d47dd0ed  pop rdi
00007e55d47dd0ee  pop rdx
00007e55d47dd0ef  pop rcx
00007e55d47dd0f0  pop rax
00007e55d47dd0f1  add rsp, 0x08
00007e55d47dd0f5  jmp 0x00007E55D47DBC35
00007e55d47dd0fa  sub rsp, 0x08
00007e55d47dd0fe  push rax
00007e55d47dd0ff  push rcx
00007e55d47dd100  push rdx
00007e55d47dd101  push rdi
00007e55d47dd102  push rsi
00007e55d47dd103  push r8
00007e55d47dd105  push r9
00007e55d47dd107  push r10
00007e55d47dd109  push r11
00007e55d47dd10b  sub rsp, 0xF0
00007e55d47dd112  vmovaps [rsp], xmm0
00007e55d47dd117  vmovaps [rsp+0x10], xmm1
00007e55d47dd11d  vmovaps [rsp+0x20], xmm2
00007e55d47dd123  vmovaps [rsp+0x30], xmm3
00007e55d47dd129  vmovaps [rsp+0x40], xmm4
00007e55d47dd12f  vmovaps [rsp+0x50], xmm6
00007e55d47dd135  vmovaps [rsp+0x60], xmm7
00007e55d47dd13b  vmovaps [rsp+0x70], xmm8
00007e55d47dd141  vmovaps [rsp+0x80], xmm9
00007e55d47dd14a  vmovaps [rsp+0x90], xmm10
00007e55d47dd153  vmovaps [rsp+0xA0], xmm11
00007e55d47dd15c  vmovaps [rsp+0xB0], xmm12
00007e55d47dd165  vmovaps [rsp+0xC0], xmm13
00007e55d47dd16e  vmovaps [rsp+0xD0], xmm14
00007e55d47dd177  vmovaps [rsp+0xE0], xmm15
00007e55d47dd180  sub rsp, 0x30
00007e55d47dd184  movaps [rsp], xmm5
00007e55d47dd188  movaps [rsp+0x10], xmm8
00007e55d47dd18e  movaps [rsp+0x20], xmm15
00007e55d47dd194  lea rdi, [rsp]
00007e55d47dd198  mov esi, 0x00
00007e55d47dd19d  mov rax, 0x55D0734A4530
00007e55d47dd1a7  call rax
00007e55d47dd1a9  movaps xmm5, [rsp]
00007e55d47dd1ad  add rsp, 0x30
00007e55d47dd1b1  vmovaps xmm0, [rsp]
00007e55d47dd1b6  vmovaps xmm1, [rsp+0x10]
00007e55d47dd1bc  vmovaps xmm2, [rsp+0x20]
00007e55d47dd1c2  vmovaps xmm3, [rsp+0x30]
00007e55d47dd1c8  vmovaps xmm4, [rsp+0x40]
00007e55d47dd1ce  vmovaps xmm6, [rsp+0x50]
00007e55d47dd1d4  vmovaps xmm7, [rsp+0x60]
00007e55d47dd1da  vmovaps xmm8, [rsp+0x70]
00007e55d47dd1e0  vmovaps xmm9, [rsp+0x80]
00007e55d47dd1e9  vmovaps xmm10, [rsp+0x90]
00007e55d47dd1f2  vmovaps xmm11, [rsp+0xA0]
00007e55d47dd1fb  vmovaps xmm12, [rsp+0xB0]
00007e55d47dd204  vmovaps xmm13, [rsp+0xC0]
00007e55d47dd20d  vmovaps xmm14, [rsp+0xD0]
00007e55d47dd216  vmovaps xmm15, [rsp+0xE0]
00007e55d47dd21f  add rsp, 0xF0
00007e55d47dd226  pop r11
00007e55d47dd228  pop r10
00007e55d47dd22a  pop r9
00007e55d47dd22c  pop r8
00007e55d47dd22e  pop rsi
00007e55d47dd22f  pop rdi
00007e55d47dd230  pop rdx
00007e55d47dd231  pop rcx
00007e55d47dd232  pop rax
00007e55d47dd233  add rsp, 0x08
00007e55d47dd237  jmp 0x00007E55D47DBC73
00007e55d47dd23c  sub rsp, 0x08
00007e55d47dd240  push rax
00007e55d47dd241  push rcx
00007e55d47dd242  push rdx
00007e55d47dd243  push rdi
00007e55d47dd244  push rsi
00007e55d47dd245  push r8
00007e55d47dd247  push r9
00007e55d47dd249  push r10
00007e55d47dd24b  push r11
00007e55d47dd24d  sub rsp, 0xF0
00007e55d47dd254  vmovaps [rsp], xmm0
00007e55d47dd259  vmovaps [rsp+0x10], xmm1
00007e55d47dd25f  vmovaps [rsp+0x20], xmm2
00007e55d47dd265  vmovaps [rsp+0x30], xmm3
00007e55d47dd26b  vmovaps [rsp+0x40], xmm5
00007e55d47dd271  vmovaps [rsp+0x50], xmm6
00007e55d47dd277  vmovaps [rsp+0x60], xmm7
00007e55d47dd27d  vmovaps [rsp+0x70], xmm8
00007e55d47dd283  vmovaps [rsp+0x80], xmm9
00007e55d47dd28c  vmovaps [rsp+0x90], xmm10
00007e55d47dd295  vmovaps [rsp+0xA0], xmm11
00007e55d47dd29e  vmovaps [rsp+0xB0], xmm12
00007e55d47dd2a7  vmovaps [rsp+0xC0], xmm13
00007e55d47dd2b0  vmovaps [rsp+0xD0], xmm14
00007e55d47dd2b9  vmovaps [rsp+0xE0], xmm15
00007e55d47dd2c2  sub rsp, 0x30
00007e55d47dd2c6  movaps [rsp], xmm4
00007e55d47dd2ca  movaps [rsp+0x10], xmm9
00007e55d47dd2d0  movaps [rsp+0x20], xmm8
00007e55d47dd2d6  lea rdi, [rsp]
00007e55d47dd2da  mov esi, 0x00
00007e55d47dd2df  mov rax, 0x55D0734A4530
00007e55d47dd2e9  call rax
00007e55d47dd2eb  movaps xmm4, [rsp]
00007e55d47dd2ef  add rsp, 0x30
00007e55d47dd2f3  vmovaps xmm0, [rsp]
00007e55d47dd2f8  vmovaps xmm1, [rsp+0x10]
00007e55d47dd2fe  vmovaps xmm2, [rsp+0x20]
00007e55d47dd304  vmovaps xmm3, [rsp+0x30]
00007e55d47dd30a  vmovaps xmm5, [rsp+0x40]
00007e55d47dd310  vmovaps xmm6, [rsp+0x50]
00007e55d47dd316  vmovaps xmm7, [rsp+0x60]
00007e55d47dd31c  vmovaps xmm8, [rsp+0x70]
00007e55d47dd322  vmovaps xmm9, [rsp+0x80]
00007e55d47dd32b  vmovaps xmm10, [rsp+0x90]
00007e55d47dd334  vmovaps xmm11, [rsp+0xA0]
00007e55d47dd33d  vmovaps xmm12, [rsp+0xB0]
00007e55d47dd346  vmovaps xmm13, [rsp+0xC0]
00007e55d47dd34f  vmovaps xmm14, [rsp+0xD0]
00007e55d47dd358  vmovaps xmm15, [rsp+0xE0]
00007e55d47dd361  add rsp, 0xF0
00007e55d47dd368  pop r11
00007e55d47dd36a  pop r10
00007e55d47dd36c  pop r9
00007e55d47dd36e  pop r8
00007e55d47dd370  pop rsi
00007e55d47dd371  pop rdi
00007e55d47dd372  pop rdx
00007e55d47dd373  pop rcx
00007e55d47dd374  pop rax
00007e55d47dd375  add rsp, 0x08
00007e55d47dd379  jmp 0x00007E55D47DBC94
00007e55d47dd37e  sub rsp, 0x08
00007e55d47dd382  push rax
00007e55d47dd383  push rcx
00007e55d47dd384  push rdx
00007e55d47dd385  push rdi
00007e55d47dd386  push rsi
00007e55d47dd387  push r8
00007e55d47dd389  push r9
00007e55d47dd38b  push r10
00007e55d47dd38d  push r11
00007e55d47dd38f  sub rsp, 0xF0
00007e55d47dd396  vmovaps [rsp], xmm0
00007e55d47dd39b  vmovaps [rsp+0x10], xmm1
00007e55d47dd3a1  vmovaps [rsp+0x20], xmm2
00007e55d47dd3a7  vmovaps [rsp+0x30], xmm3
00007e55d47dd3ad  vmovaps [rsp+0x40], xmm4
00007e55d47dd3b3  vmovaps [rsp+0x50], xmm5
00007e55d47dd3b9  vmovaps [rsp+0x60], xmm6
00007e55d47dd3bf  vmovaps [rsp+0x70], xmm7
00007e55d47dd3c5  vmovaps [rsp+0x80], xmm8
00007e55d47dd3ce  vmovaps [rsp+0x90], xmm10
00007e55d47dd3d7  vmovaps [rsp+0xA0], xmm11
00007e55d47dd3e0  vmovaps [rsp+0xB0], xmm12
00007e55d47dd3e9  vmovaps [rsp+0xC0], xmm13
00007e55d47dd3f2  vmovaps [rsp+0xD0], xmm14
00007e55d47dd3fb  vmovaps [rsp+0xE0], xmm15
00007e55d47dd404  sub rsp, 0x30
00007e55d47dd408  movaps [rsp], xmm9
00007e55d47dd40d  movaps [rsp+0x10], xmm10
00007e55d47dd413  movaps [rsp+0x20], xmm8
00007e55d47dd419  lea rdi, [rsp]
00007e55d47dd41d  mov esi, 0x00
00007e55d47dd422  mov rax, 0x55D0734A4530
00007e55d47dd42c  call rax
00007e55d47dd42e  movaps xmm9, [rsp]
00007e55d47dd433  add rsp, 0x30
00007e55d47dd437  vmovaps xmm0, [rsp]
00007e55d47dd43c  vmovaps xmm1, [rsp+0x10]
00007e55d47dd442  vmovaps xmm2, [rsp+0x20]
00007e55d47dd448  vmovaps xmm3, [rsp+0x30]
00007e55d47dd44e  vmovaps xmm4, [rsp+0x40]
00007e55d47dd454  vmovaps xmm5, [rsp+0x50]
00007e55d47dd45a  vmovaps xmm6, [rsp+0x60]
00007e55d47dd460  vmovaps xmm7, [rsp+0x70]
00007e55d47dd466  vmovaps xmm8, [rsp+0x80]
00007e55d47dd46f  vmovaps xmm10, [rsp+0x90]
00007e55d47dd478  vmovaps xmm11, [rsp+0xA0]
00007e55d47dd481  vmovaps xmm12, [rsp+0xB0]
00007e55d47dd48a  vmovaps xmm13, [rsp+0xC0]
00007e55d47dd493  vmovaps xmm14, [rsp+0xD0]
00007e55d47dd49c  vmovaps xmm15, [rsp+0xE0]
00007e55d47dd4a5  add rsp, 0xF0
00007e55d47dd4ac  pop r11
00007e55d47dd4ae  pop r10
00007e55d47dd4b0  pop r9
00007e55d47dd4b2  pop r8
00007e55d47dd4b4  pop rsi
00007e55d47dd4b5  pop rdi
00007e55d47dd4b6  pop rdx
00007e55d47dd4b7  pop rcx
00007e55d47dd4b8  pop rax
00007e55d47dd4b9  add rsp, 0x08
00007e55d47dd4bd  jmp 0x00007E55D47DBCAE
00007e55d47dd4c2  call 0x00007E55D46B52F0
00007e55d47dd4c7  jmp 0x00007E55D47DBDC8
00007e55d47dd4cc  call 0x00007E55D46B52F0
00007e55d47dd4d1  jmp 0x00007E55D47DBDDE
00007e55d47dd4d6  sub rsp, 0x08
00007e55d47dd4da  push rax
00007e55d47dd4db  push rcx
00007e55d47dd4dc  push rdx
00007e55d47dd4dd  push rdi
00007e55d47dd4de  push rsi
00007e55d47dd4df  push r8
00007e55d47dd4e1  push r9
00007e55d47dd4e3  push r10
00007e55d47dd4e5  push r11
00007e55d47dd4e7  sub rsp, 0xF0
00007e55d47dd4ee  vmovaps [rsp], xmm0
00007e55d47dd4f3  vmovaps [rsp+0x10], xmm2
00007e55d47dd4f9  vmovaps [rsp+0x20], xmm3
00007e55d47dd4ff  vmovaps [rsp+0x30], xmm4
00007e55d47dd505  vmovaps [rsp+0x40], xmm5
00007e55d47dd50b  vmovaps [rsp+0x50], xmm6
00007e55d47dd511  vmovaps [rsp+0x60], xmm7
00007e55d47dd517  vmovaps [rsp+0x70], xmm8
00007e55d47dd51d  vmovaps [rsp+0x80], xmm9
00007e55d47dd526  vmovaps [rsp+0x90], xmm10
00007e55d47dd52f  vmovaps [rsp+0xA0], xmm11
00007e55d47dd538  vmovaps [rsp+0xB0], xmm12
00007e55d47dd541  vmovaps [rsp+0xC0], xmm13
00007e55d47dd54a  vmovaps [rsp+0xD0], xmm14
00007e55d47dd553  vmovaps [rsp+0xE0], xmm15
00007e55d47dd55c  sub rsp, 0x30
00007e55d47dd560  movaps [rsp], xmm1
00007e55d47dd564  movaps [rsp+0x10], xmm6
00007e55d47dd569  movaps [rsp+0x20], xmm15
00007e55d47dd56f  lea rdi, [rsp]
00007e55d47dd573  mov esi, 0x00
00007e55d47dd578  mov rax, 0x55D0734A4530
00007e55d47dd582  call rax
00007e55d47dd584  movaps xmm1, [rsp]
00007e55d47dd588  add rsp, 0x30
00007e55d47dd58c  vmovaps xmm0, [rsp]
00007e55d47dd591  vmovaps xmm2, [rsp+0x10]
00007e55d47dd597  vmovaps xmm3, [rsp+0x20]
00007e55d47dd59d  vmovaps xmm4, [rsp+0x30]
00007e55d47dd5a3  vmovaps xmm5, [rsp+0x40]
00007e55d47dd5a9  vmovaps xmm6, [rsp+0x50]
00007e55d47dd5af  vmovaps xmm7, [rsp+0x60]
00007e55d47dd5b5  vmovaps xmm8, [rsp+0x70]
00007e55d47dd5bb  vmovaps xmm9, [rsp+0x80]
00007e55d47dd5c4  vmovaps xmm10, [rsp+0x90]
00007e55d47dd5cd  vmovaps xmm11, [rsp+0xA0]
00007e55d47dd5d6  vmovaps xmm12, [rsp+0xB0]
00007e55d47dd5df  vmovaps xmm13, [rsp+0xC0]
00007e55d47dd5e8  vmovaps xmm14, [rsp+0xD0]
00007e55d47dd5f1  vmovaps xmm15, [rsp+0xE0]
00007e55d47dd5fa  add rsp, 0xF0
00007e55d47dd601  pop r11
00007e55d47dd603  pop r10
00007e55d47dd605  pop r9
00007e55d47dd607  pop r8
00007e55d47dd609  pop rsi
00007e55d47dd60a  pop rdi
00007e55d47dd60b  pop rdx
00007e55d47dd60c  pop rcx
00007e55d47dd60d  pop rax
00007e55d47dd60e  add rsp, 0x08
00007e55d47dd612  jmp 0x00007E55D47DBE1B
00007e55d47dd617  call 0x00007E55D46C4620
00007e55d47dd61c  jmp 0x00007E55D47DBE28
00007e55d47dd621  sub rsp, 0x08
00007e55d47dd625  push rax
00007e55d47dd626  push rcx
00007e55d47dd627  push rdx
00007e55d47dd628  push rdi
00007e55d47dd629  push rsi
00007e55d47dd62a  push r8
00007e55d47dd62c  push r9
00007e55d47dd62e  push r10
00007e55d47dd630  push r11
00007e55d47dd632  sub rsp, 0xF0
00007e55d47dd639  vmovaps [rsp], xmm0
00007e55d47dd63e  vmovaps [rsp+0x10], xmm1
00007e55d47dd644  vmovaps [rsp+0x20], xmm2
00007e55d47dd64a  vmovaps [rsp+0x30], xmm3
00007e55d47dd650  vmovaps [rsp+0x40], xmm4
00007e55d47dd656  vmovaps [rsp+0x50], xmm5
00007e55d47dd65c  vmovaps [rsp+0x60], xmm6
00007e55d47dd662  vmovaps [rsp+0x70], xmm7
00007e55d47dd668  vmovaps [rsp+0x80], xmm8
00007e55d47dd671  vmovaps [rsp+0x90], xmm9
00007e55d47dd67a  vmovaps [rsp+0xA0], xmm10
00007e55d47dd683  vmovaps [rsp+0xB0], xmm11
00007e55d47dd68c  vmovaps [rsp+0xC0], xmm12
00007e55d47dd695  vmovaps [rsp+0xD0], xmm13
00007e55d47dd69e  vmovaps [rsp+0xE0], xmm15
00007e55d47dd6a7  sub rsp, 0x30
00007e55d47dd6ab  movaps [rsp], xmm14
00007e55d47dd6b0  movaps [rsp+0x10], xmm4
00007e55d47dd6b5  movaps [rsp+0x20], xmm3
00007e55d47dd6ba  lea rdi, [rsp]
00007e55d47dd6be  mov esi, 0x00
00007e55d47dd6c3  mov rax, 0x55D0734A4530
00007e55d47dd6cd  call rax
00007e55d47dd6cf  movaps xmm14, [rsp]
00007e55d47dd6d4  add rsp, 0x30
00007e55d47dd6d8  vmovaps xmm0, [rsp]
00007e55d47dd6dd  vmovaps xmm1, [rsp+0x10]
00007e55d47dd6e3  vmovaps xmm2, [rsp+0x20]
00007e55d47dd6e9  vmovaps xmm3, [rsp+0x30]
00007e55d47dd6ef  vmovaps xmm4, [rsp+0x40]
00007e55d47dd6f5  vmovaps xmm5, [rsp+0x50]
00007e55d47dd6fb  vmovaps xmm6, [rsp+0x60]
00007e55d47dd701  vmovaps xmm7, [rsp+0x70]
00007e55d47dd707  vmovaps xmm8, [rsp+0x80]
00007e55d47dd710  vmovaps xmm9, [rsp+0x90]
00007e55d47dd719  vmovaps xmm10, [rsp+0xA0]
00007e55d47dd722  vmovaps xmm11, [rsp+0xB0]
00007e55d47dd72b  vmovaps xmm12, [rsp+0xC0]
00007e55d47dd734  vmovaps xmm13, [rsp+0xD0]
00007e55d47dd73d  vmovaps xmm15, [rsp+0xE0]
00007e55d47dd746  add rsp, 0xF0
00007e55d47dd74d  pop r11
00007e55d47dd74f  pop r10
00007e55d47dd751  pop r9
00007e55d47dd753  pop r8
00007e55d47dd755  pop rsi
00007e55d47dd756  pop rdi
00007e55d47dd757  pop rdx
00007e55d47dd758  pop rcx
00007e55d47dd759  pop rax
00007e55d47dd75a  add rsp, 0x08
00007e55d47dd75e  jmp 0x00007E55D47DBE42
00007e55d47dd763  sub rsp, 0x08
00007e55d47dd767  push rax
00007e55d47dd768  push rcx
00007e55d47dd769  push rdx
00007e55d47dd76a  push rdi
00007e55d47dd76b  push rsi
00007e55d47dd76c  push r8
00007e55d47dd76e  push r9
00007e55d47dd770  push r10
00007e55d47dd772  push r11
00007e55d47dd774  sub rsp, 0xF0
00007e55d47dd77b  vmovaps [rsp], xmm0
00007e55d47dd780  vmovaps [rsp+0x10], xmm1
00007e55d47dd786  vmovaps [rsp+0x20], xmm2
00007e55d47dd78c  vmovaps [rsp+0x30], xmm3
00007e55d47dd792  vmovaps [rsp+0x40], xmm4
00007e55d47dd798  vmovaps [rsp+0x50], xmm5
00007e55d47dd79e  vmovaps [rsp+0x60], xmm7
00007e55d47dd7a4  vmovaps [rsp+0x70], xmm8
00007e55d47dd7aa  vmovaps [rsp+0x80], xmm9
00007e55d47dd7b3  vmovaps [rsp+0x90], xmm10
00007e55d47dd7bc  vmovaps [rsp+0xA0], xmm11
00007e55d47dd7c5  vmovaps [rsp+0xB0], xmm12
00007e55d47dd7ce  vmovaps [rsp+0xC0], xmm13
00007e55d47dd7d7  vmovaps [rsp+0xD0], xmm14
00007e55d47dd7e0  vmovaps [rsp+0xE0], xmm15
00007e55d47dd7e9  sub rsp, 0x30
00007e55d47dd7ed  movaps [rsp], xmm6
00007e55d47dd7f1  movaps [rsp+0x10], xmm9
00007e55d47dd7f7  movaps [rsp+0x20], xmm7
00007e55d47dd7fc  lea rdi, [rsp]
00007e55d47dd800  mov esi, 0x00
00007e55d47dd805  mov rax, 0x55D0734A4530
00007e55d47dd80f  call rax
00007e55d47dd811  movaps xmm6, [rsp]
00007e55d47dd815  add rsp, 0x30
00007e55d47dd819  vmovaps xmm0, [rsp]
00007e55d47dd81e  vmovaps xmm1, [rsp+0x10]
00007e55d47dd824  vmovaps xmm2, [rsp+0x20]
00007e55d47dd82a  vmovaps xmm3, [rsp+0x30]
00007e55d47dd830  vmovaps xmm4, [rsp+0x40]
00007e55d47dd836  vmovaps xmm5, [rsp+0x50]
00007e55d47dd83c  vmovaps xmm7, [rsp+0x60]
00007e55d47dd842  vmovaps xmm8, [rsp+0x70]
00007e55d47dd848  vmovaps xmm9, [rsp+0x80]
00007e55d47dd851  vmovaps xmm10, [rsp+0x90]
00007e55d47dd85a  vmovaps xmm11, [rsp+0xA0]
00007e55d47dd863  vmovaps xmm12, [rsp+0xB0]
00007e55d47dd86c  vmovaps xmm13, [rsp+0xC0]
00007e55d47dd875  vmovaps xmm14, [rsp+0xD0]
00007e55d47dd87e  vmovaps xmm15, [rsp+0xE0]
00007e55d47dd887  add rsp, 0xF0
00007e55d47dd88e  pop r11
00007e55d47dd890  pop r10
00007e55d47dd892  pop r9
00007e55d47dd894  pop r8
00007e55d47dd896  pop rsi
00007e55d47dd897  pop rdi
00007e55d47dd898  pop rdx
00007e55d47dd899  pop rcx
00007e55d47dd89a  pop rax
00007e55d47dd89b  add rsp, 0x08
00007e55d47dd89f  jmp 0x00007E55D47DBE5A
00007e55d47dd8a4  sub rsp, 0x08
00007e55d47dd8a8  push rax
00007e55d47dd8a9  push rcx
00007e55d47dd8aa  push rdx
00007e55d47dd8ab  push rdi
00007e55d47dd8ac  push rsi
00007e55d47dd8ad  push r8
00007e55d47dd8af  push r9
00007e55d47dd8b1  push r10
00007e55d47dd8b3  push r11
00007e55d47dd8b5  sub rsp, 0xF0
00007e55d47dd8bc  vmovaps [rsp], xmm0
00007e55d47dd8c1  vmovaps [rsp+0x10], xmm1
00007e55d47dd8c7  vmovaps [rsp+0x20], xmm2
00007e55d47dd8cd  vmovaps [rsp+0x30], xmm3
00007e55d47dd8d3  vmovaps [rsp+0x40], xmm4
00007e55d47dd8d9  vmovaps [rsp+0x50], xmm5
00007e55d47dd8df  vmovaps [rsp+0x60], xmm6
00007e55d47dd8e5  vmovaps [rsp+0x70], xmm8
00007e55d47dd8eb  vmovaps [rsp+0x80], xmm9
00007e55d47dd8f4  vmovaps [rsp+0x90], xmm10
00007e55d47dd8fd  vmovaps [rsp+0xA0], xmm11
00007e55d47dd906  vmovaps [rsp+0xB0], xmm12
00007e55d47dd90f  vmovaps [rsp+0xC0], xmm13
00007e55d47dd918  vmovaps [rsp+0xD0], xmm14
00007e55d47dd921  vmovaps [rsp+0xE0], xmm15
00007e55d47dd92a  sub rsp, 0x30
00007e55d47dd92e  movaps [rsp], xmm7
00007e55d47dd932  movaps [rsp+0x10], xmm4
00007e55d47dd937  movaps [rsp+0x20], xmm9
00007e55d47dd93d  lea rdi, [rsp]
00007e55d47dd941  mov esi, 0x00
00007e55d47dd946  mov rax, 0x55D0734A4530
00007e55d47dd950  call rax
00007e55d47dd952  movaps xmm7, [rsp]
00007e55d47dd956  add rsp, 0x30
00007e55d47dd95a  vmovaps xmm0, [rsp]
00007e55d47dd95f  vmovaps xmm1, [rsp+0x10]
00007e55d47dd965  vmovaps xmm2, [rsp+0x20]
00007e55d47dd96b  vmovaps xmm3, [rsp+0x30]
00007e55d47dd971  vmovaps xmm4, [rsp+0x40]
00007e55d47dd977  vmovaps xmm5, [rsp+0x50]
00007e55d47dd97d  vmovaps xmm6, [rsp+0x60]
00007e55d47dd983  vmovaps xmm8, [rsp+0x70]
00007e55d47dd989  vmovaps xmm9, [rsp+0x80]
00007e55d47dd992  vmovaps xmm10, [rsp+0x90]
00007e55d47dd99b  vmovaps xmm11, [rsp+0xA0]
00007e55d47dd9a4  vmovaps xmm12, [rsp+0xB0]
00007e55d47dd9ad  vmovaps xmm13, [rsp+0xC0]
00007e55d47dd9b6  vmovaps xmm14, [rsp+0xD0]
00007e55d47dd9bf  vmovaps xmm15, [rsp+0xE0]
00007e55d47dd9c8  add rsp, 0xF0
00007e55d47dd9cf  pop r11
00007e55d47dd9d1  pop r10
00007e55d47dd9d3  pop r9
00007e55d47dd9d5  pop r8
00007e55d47dd9d7  pop rsi
00007e55d47dd9d8  pop rdi
00007e55d47dd9d9  pop rdx
00007e55d47dd9da  pop rcx
00007e55d47dd9db  pop rax
00007e55d47dd9dc  add rsp, 0x08
00007e55d47dd9e0  jmp 0x00007E55D47DBE87
00007e55d47dd9e5  sub rsp, 0x08
00007e55d47dd9e9  push rax
00007e55d47dd9ea  push rcx
00007e55d47dd9eb  push rdx
00007e55d47dd9ec  push rdi
00007e55d47dd9ed  push rsi
00007e55d47dd9ee  push r8
00007e55d47dd9f0  push r9
00007e55d47dd9f2  push r10
00007e55d47dd9f4  push r11
00007e55d47dd9f6  sub rsp, 0xF0
00007e55d47dd9fd  vmovaps [rsp], xmm0
00007e55d47dda02  vmovaps [rsp+0x10], xmm1
00007e55d47dda08  vmovaps [rsp+0x20], xmm2
00007e55d47dda0e  vmovaps [rsp+0x30], xmm3
00007e55d47dda14  vmovaps [rsp+0x40], xmm5
00007e55d47dda1a  vmovaps [rsp+0x50], xmm6
00007e55d47dda20  vmovaps [rsp+0x60], xmm7
00007e55d47dda26  vmovaps [rsp+0x70], xmm8
00007e55d47dda2c  vmovaps [rsp+0x80], xmm9
00007e55d47dda35  vmovaps [rsp+0x90], xmm10
00007e55d47dda3e  vmovaps [rsp+0xA0], xmm11
00007e55d47dda47  vmovaps [rsp+0xB0], xmm12
00007e55d47dda50  vmovaps [rsp+0xC0], xmm13
00007e55d47dda59  vmovaps [rsp+0xD0], xmm14
00007e55d47dda62  vmovaps [rsp+0xE0], xmm15
00007e55d47dda6b  sub rsp, 0x30
00007e55d47dda6f  movaps [rsp], xmm4
00007e55d47dda73  movaps [rsp+0x10], xmm15
00007e55d47dda79  movaps [rsp+0x20], xmm9
00007e55d47dda7f  lea rdi, [rsp]
00007e55d47dda83  mov esi, 0x00
00007e55d47dda88  mov rax, 0x55D0734A4530
00007e55d47dda92  call rax
00007e55d47dda94  movaps xmm4, [rsp]
00007e55d47dda98  add rsp, 0x30
00007e55d47dda9c  vmovaps xmm0, [rsp]
00007e55d47ddaa1  vmovaps xmm1, [rsp+0x10]
00007e55d47ddaa7  vmovaps xmm2, [rsp+0x20]
00007e55d47ddaad  vmovaps xmm3, [rsp+0x30]
00007e55d47ddab3  vmovaps xmm5, [rsp+0x40]
00007e55d47ddab9  vmovaps xmm6, [rsp+0x50]
00007e55d47ddabf  vmovaps xmm7, [rsp+0x60]
00007e55d47ddac5  vmovaps xmm8, [rsp+0x70]
00007e55d47ddacb  vmovaps xmm9, [rsp+0x80]
00007e55d47ddad4  vmovaps xmm10, [rsp+0x90]
00007e55d47ddadd  vmovaps xmm11, [rsp+0xA0]
00007e55d47ddae6  vmovaps xmm12, [rsp+0xB0]
00007e55d47ddaef  vmovaps xmm13, [rsp+0xC0]
00007e55d47ddaf8  vmovaps xmm14, [rsp+0xD0]
00007e55d47ddb01  vmovaps xmm15, [rsp+0xE0]
00007e55d47ddb0a  add rsp, 0xF0
00007e55d47ddb11  pop r11
00007e55d47ddb13  pop r10
00007e55d47ddb15  pop r9
00007e55d47ddb17  pop r8
00007e55d47ddb19  pop rsi
00007e55d47ddb1a  pop rdi
00007e55d47ddb1b  pop rdx
00007e55d47ddb1c  pop rcx
00007e55d47ddb1d  pop rax
00007e55d47ddb1e  add rsp, 0x08
00007e55d47ddb22  jmp 0x00007E55D47DBEAC
00007e55d47ddb27  call 0x00007E55D46C4620
00007e55d47ddb2c  jmp 0x00007E55D47DBEB9
00007e55d47ddb31  sub rsp, 0x08
00007e55d47ddb35  push rax
00007e55d47ddb36  push rcx
00007e55d47ddb37  push rdx
00007e55d47ddb38  push rdi
00007e55d47ddb39  push rsi
00007e55d47ddb3a  push r8
00007e55d47ddb3c  push r9
00007e55d47ddb3e  push r10
00007e55d47ddb40  push r11
00007e55d47ddb42  sub rsp, 0xF0
00007e55d47ddb49  vmovaps [rsp], xmm0
00007e55d47ddb4e  vmovaps [rsp+0x10], xmm1
00007e55d47ddb54  vmovaps [rsp+0x20], xmm2
00007e55d47ddb5a  vmovaps [rsp+0x30], xmm4
00007e55d47ddb60  vmovaps [rsp+0x40], xmm5
00007e55d47ddb66  vmovaps [rsp+0x50], xmm6
00007e55d47ddb6c  vmovaps [rsp+0x60], xmm7
00007e55d47ddb72  vmovaps [rsp+0x70], xmm8
00007e55d47ddb78  vmovaps [rsp+0x80], xmm9
00007e55d47ddb81  vmovaps [rsp+0x90], xmm10
00007e55d47ddb8a  vmovaps [rsp+0xA0], xmm11
00007e55d47ddb93  vmovaps [rsp+0xB0], xmm12
00007e55d47ddb9c  vmovaps [rsp+0xC0], xmm13
00007e55d47ddba5  vmovaps [rsp+0xD0], xmm14
00007e55d47ddbae  vmovaps [rsp+0xE0], xmm15
00007e55d47ddbb7  sub rsp, 0x30
00007e55d47ddbbb  movaps [rsp], xmm3
00007e55d47ddbbf  movaps [rsp+0x10], xmm1
00007e55d47ddbc4  movaps [rsp+0x20], xmm9
00007e55d47ddbca  lea rdi, [rsp]
00007e55d47ddbce  mov esi, 0x00
00007e55d47ddbd3  mov rax, 0x55D0734A4530
00007e55d47ddbdd  call rax
00007e55d47ddbdf  movaps xmm3, [rsp]
00007e55d47ddbe3  add rsp, 0x30
00007e55d47ddbe7  vmovaps xmm0, [rsp]
00007e55d47ddbec  vmovaps xmm1, [rsp+0x10]
00007e55d47ddbf2  vmovaps xmm2, [rsp+0x20]
00007e55d47ddbf8  vmovaps xmm4, [rsp+0x30]
00007e55d47ddbfe  vmovaps xmm5, [rsp+0x40]
00007e55d47ddc04  vmovaps xmm6, [rsp+0x50]
00007e55d47ddc0a  vmovaps xmm7, [rsp+0x60]
00007e55d47ddc10  vmovaps xmm8, [rsp+0x70]
00007e55d47ddc16  vmovaps xmm9, [rsp+0x80]
00007e55d47ddc1f  vmovaps xmm10, [rsp+0x90]
00007e55d47ddc28  vmovaps xmm11, [rsp+0xA0]
00007e55d47ddc31  vmovaps xmm12, [rsp+0xB0]
00007e55d47ddc3a  vmovaps xmm13, [rsp+0xC0]
00007e55d47ddc43  vmovaps xmm14, [rsp+0xD0]
00007e55d47ddc4c  vmovaps xmm15, [rsp+0xE0]
00007e55d47ddc55  add rsp, 0xF0
00007e55d47ddc5c  pop r11
00007e55d47ddc5e  pop r10
00007e55d47ddc60  pop r9
00007e55d47ddc62  pop r8
00007e55d47ddc64  pop rsi
00007e55d47ddc65  pop rdi
00007e55d47ddc66  pop rdx
00007e55d47ddc67  pop rcx
00007e55d47ddc68  pop rax
00007e55d47ddc69  add rsp, 0x08
00007e55d47ddc6d  jmp 0x00007E55D47DBEF6
00007e55d47ddc72  sub rsp, 0x08
00007e55d47ddc76  push rax
00007e55d47ddc77  push rcx
00007e55d47ddc78  push rdx
00007e55d47ddc79  push rdi
00007e55d47ddc7a  push rsi
00007e55d47ddc7b  push r8
00007e55d47ddc7d  push r9
00007e55d47ddc7f  push r10
00007e55d47ddc81  push r11
00007e55d47ddc83  sub rsp, 0xF0
00007e55d47ddc8a  vmovaps [rsp], xmm0
00007e55d47ddc8f  vmovaps [rsp+0x10], xmm2
00007e55d47ddc95  vmovaps [rsp+0x20], xmm3
00007e55d47ddc9b  vmovaps [rsp+0x30], xmm4
00007e55d47ddca1  vmovaps [rsp+0x40], xmm5
00007e55d47ddca7  vmovaps [rsp+0x50], xmm6
00007e55d47ddcad  vmovaps [rsp+0x60], xmm7
00007e55d47ddcb3  vmovaps [rsp+0x70], xmm8
00007e55d47ddcb9  vmovaps [rsp+0x80], xmm9
00007e55d47ddcc2  vmovaps [rsp+0x90], xmm10
00007e55d47ddccb  vmovaps [rsp+0xA0], xmm11
00007e55d47ddcd4  vmovaps [rsp+0xB0], xmm12
00007e55d47ddcdd  vmovaps [rsp+0xC0], xmm13
00007e55d47ddce6  vmovaps [rsp+0xD0], xmm14
00007e55d47ddcef  vmovaps [rsp+0xE0], xmm15
00007e55d47ddcf8  sub rsp, 0x30
00007e55d47ddcfc  movaps [rsp], xmm1
00007e55d47ddd00  movaps [rsp+0x10], xmm15
00007e55d47ddd06  movaps [rsp+0x20], xmm9
00007e55d47ddd0c  lea rdi, [rsp]
00007e55d47ddd10  mov esi, 0x00
00007e55d47ddd15  mov rax, 0x55D0734A4530
00007e55d47ddd1f  call rax
00007e55d47ddd21  movaps xmm1, [rsp]
00007e55d47ddd25  add rsp, 0x30
00007e55d47ddd29  vmovaps xmm0, [rsp]
00007e55d47ddd2e  vmovaps xmm2, [rsp+0x10]
00007e55d47ddd34  vmovaps xmm3, [rsp+0x20]
00007e55d47ddd3a  vmovaps xmm4, [rsp+0x30]
00007e55d47ddd40  vmovaps xmm5, [rsp+0x40]
00007e55d47ddd46  vmovaps xmm6, [rsp+0x50]
00007e55d47ddd4c  vmovaps xmm7, [rsp+0x60]
00007e55d47ddd52  vmovaps xmm8, [rsp+0x70]
00007e55d47ddd58  vmovaps xmm9, [rsp+0x80]
00007e55d47ddd61  vmovaps xmm10, [rsp+0x90]
00007e55d47ddd6a  vmovaps xmm11, [rsp+0xA0]
00007e55d47ddd73  vmovaps xmm12, [rsp+0xB0]
00007e55d47ddd7c  vmovaps xmm13, [rsp+0xC0]
00007e55d47ddd85  vmovaps xmm14, [rsp+0xD0]
00007e55d47ddd8e  vmovaps xmm15, [rsp+0xE0]
00007e55d47ddd97  add rsp, 0xF0
00007e55d47ddd9e  pop r11
00007e55d47ddda0  pop r10
00007e55d47ddda2  pop r9
00007e55d47ddda4  pop r8
00007e55d47ddda6  pop rsi
00007e55d47ddda7  pop rdi
00007e55d47ddda8  pop rdx
00007e55d47ddda9  pop rcx
00007e55d47dddaa  pop rax
00007e55d47dddab  add rsp, 0x08
00007e55d47dddaf  jmp 0x00007E55D47DBF7E
00007e55d47dddb4  call 0x00007E55D46C4620
00007e55d47dddb9  jmp 0x00007E55D47DBF8B
00007e55d47dddbe  sub rsp, 0x08
00007e55d47dddc2  push rax
00007e55d47dddc3  push rcx
00007e55d47dddc4  push rdx
00007e55d47dddc5  push rdi
00007e55d47dddc6  push rsi
00007e55d47dddc7  push r8
00007e55d47dddc9  push r9
00007e55d47dddcb  push r10
00007e55d47dddcd  push r11
00007e55d47dddcf  sub rsp, 0xF0
00007e55d47dddd6  vmovaps [rsp], xmm0
00007e55d47ddddb  vmovaps [rsp+0x10], xmm2
00007e55d47ddde1  vmovaps [rsp+0x20], xmm3
00007e55d47ddde7  vmovaps [rsp+0x30], xmm4
00007e55d47ddded  vmovaps [rsp+0x40], xmm5
00007e55d47dddf3  vmovaps [rsp+0x50], xmm6
00007e55d47dddf9  vmovaps [rsp+0x60], xmm7
00007e55d47dddff  vmovaps [rsp+0x70], xmm8
00007e55d47dde05  vmovaps [rsp+0x80], xmm9
00007e55d47dde0e  vmovaps [rsp+0x90], xmm10
00007e55d47dde17  vmovaps [rsp+0xA0], xmm11
00007e55d47dde20  vmovaps [rsp+0xB0], xmm12
00007e55d47dde29  vmovaps [rsp+0xC0], xmm13
00007e55d47dde32  vmovaps [rsp+0xD0], xmm14
00007e55d47dde3b  vmovaps [rsp+0xE0], xmm15
00007e55d47dde44  sub rsp, 0x30
00007e55d47dde48  movaps [rsp], xmm1
00007e55d47dde4c  movaps [rsp+0x10], xmm5
00007e55d47dde51  movaps [rsp+0x20], xmm7
00007e55d47dde56  lea rdi, [rsp]
00007e55d47dde5a  mov esi, 0x00
00007e55d47dde5f  mov rax, 0x55D0734A4530
00007e55d47dde69  call rax
00007e55d47dde6b  movaps xmm1, [rsp]
00007e55d47dde6f  add rsp, 0x30
00007e55d47dde73  vmovaps xmm0, [rsp]
00007e55d47dde78  vmovaps xmm2, [rsp+0x10]
00007e55d47dde7e  vmovaps xmm3, [rsp+0x20]
00007e55d47dde84  vmovaps xmm4, [rsp+0x30]
00007e55d47dde8a  vmovaps xmm5, [rsp+0x40]
00007e55d47dde90  vmovaps xmm6, [rsp+0x50]
00007e55d47dde96  vmovaps xmm7, [rsp+0x60]
00007e55d47dde9c  vmovaps xmm8, [rsp+0x70]
00007e55d47ddea2  vmovaps xmm9, [rsp+0x80]
00007e55d47ddeab  vmovaps xmm10, [rsp+0x90]
00007e55d47ddeb4  vmovaps xmm11, [rsp+0xA0]
00007e55d47ddebd  vmovaps xmm12, [rsp+0xB0]
00007e55d47ddec6  vmovaps xmm13, [rsp+0xC0]
00007e55d47ddecf  vmovaps xmm14, [rsp+0xD0]
00007e55d47dded8  vmovaps xmm15, [rsp+0xE0]
00007e55d47ddee1  add rsp, 0xF0
00007e55d47ddee8  pop r11
00007e55d47ddeea  pop r10
00007e55d47ddeec  pop r9
00007e55d47ddeee  pop r8
00007e55d47ddef0  pop rsi
00007e55d47ddef1  pop rdi
00007e55d47ddef2  pop rdx
00007e55d47ddef3  pop rcx
00007e55d47ddef4  pop rax
00007e55d47ddef5  add rsp, 0x08
00007e55d47ddef9  jmp 0x00007E55D47DC030
00007e55d47ddefe  sub rsp, 0x08
00007e55d47ddf02  push rax
00007e55d47ddf03  push rcx
00007e55d47ddf04  push rdx
00007e55d47ddf05  push rdi
00007e55d47ddf06  push rsi
00007e55d47ddf07  push r8
00007e55d47ddf09  push r9
00007e55d47ddf0b  push r10
00007e55d47ddf0d  push r11
00007e55d47ddf0f  sub rsp, 0xF0
00007e55d47ddf16  vmovaps [rsp], xmm0
00007e55d47ddf1b  vmovaps [rsp+0x10], xmm1
00007e55d47ddf21  vmovaps [rsp+0x20], xmm2
00007e55d47ddf27  vmovaps [rsp+0x30], xmm3
00007e55d47ddf2d  vmovaps [rsp+0x40], xmm4
00007e55d47ddf33  vmovaps [rsp+0x50], xmm5
00007e55d47ddf39  vmovaps [rsp+0x60], xmm6
00007e55d47ddf3f  vmovaps [rsp+0x70], xmm8
00007e55d47ddf45  vmovaps [rsp+0x80], xmm9
00007e55d47ddf4e  vmovaps [rsp+0x90], xmm10
00007e55d47ddf57  vmovaps [rsp+0xA0], xmm11
00007e55d47ddf60  vmovaps [rsp+0xB0], xmm12
00007e55d47ddf69  vmovaps [rsp+0xC0], xmm13
00007e55d47ddf72  vmovaps [rsp+0xD0], xmm14
00007e55d47ddf7b  vmovaps [rsp+0xE0], xmm15
00007e55d47ddf84  sub rsp, 0x30
00007e55d47ddf88  movaps [rsp], xmm7
00007e55d47ddf8c  movaps [rsp+0x10], xmm5
00007e55d47ddf91  movaps [rsp+0x20], xmm15
00007e55d47ddf97  lea rdi, [rsp]
00007e55d47ddf9b  mov esi, 0x00
00007e55d47ddfa0  mov rax, 0x55D0734A4530
00007e55d47ddfaa  call rax
00007e55d47ddfac  movaps xmm7, [rsp]
00007e55d47ddfb0  add rsp, 0x30
00007e55d47ddfb4  vmovaps xmm0, [rsp]
00007e55d47ddfb9  vmovaps xmm1, [rsp+0x10]
00007e55d47ddfbf  vmovaps xmm2, [rsp+0x20]
00007e55d47ddfc5  vmovaps xmm3, [rsp+0x30]
00007e55d47ddfcb  vmovaps xmm4, [rsp+0x40]
00007e55d47ddfd1  vmovaps xmm5, [rsp+0x50]
00007e55d47ddfd7  vmovaps xmm6, [rsp+0x60]
00007e55d47ddfdd  vmovaps xmm8, [rsp+0x70]
00007e55d47ddfe3  vmovaps xmm9, [rsp+0x80]
00007e55d47ddfec  vmovaps xmm10, [rsp+0x90]
00007e55d47ddff5  vmovaps xmm11, [rsp+0xA0]
00007e55d47ddffe  vmovaps xmm12, [rsp+0xB0]
00007e55d47de007  vmovaps xmm13, [rsp+0xC0]
00007e55d47de010  vmovaps xmm14, [rsp+0xD0]
00007e55d47de019  vmovaps xmm15, [rsp+0xE0]
00007e55d47de022  add rsp, 0xF0
00007e55d47de029  pop r11
00007e55d47de02b  pop r10
00007e55d47de02d  pop r9
00007e55d47de02f  pop r8
00007e55d47de031  pop rsi
00007e55d47de032  pop rdi
00007e55d47de033  pop rdx
00007e55d47de034  pop rcx
00007e55d47de035  pop rax
00007e55d47de036  add rsp, 0x08
00007e55d47de03a  jmp 0x00007E55D47DC066
00007e55d47de03f  call 0x00007E55D46B52F0
00007e55d47de044  jmp 0x00007E55D47DC073
00007e55d47de049  sub rsp, 0x08
00007e55d47de04d  push rax
00007e55d47de04e  push rcx
00007e55d47de04f  push rdx
00007e55d47de050  push rdi
00007e55d47de051  push rsi
00007e55d47de052  push r8
00007e55d47de054  push r9
00007e55d47de056  push r10
00007e55d47de058  push r11
00007e55d47de05a  sub rsp, 0xF0
00007e55d47de061  vmovaps [rsp], xmm0
00007e55d47de066  vmovaps [rsp+0x10], xmm1
00007e55d47de06c  vmovaps [rsp+0x20], xmm2
00007e55d47de072  vmovaps [rsp+0x30], xmm3
00007e55d47de078  vmovaps [rsp+0x40], xmm4
00007e55d47de07e  vmovaps [rsp+0x50], xmm5
00007e55d47de084  vmovaps [rsp+0x60], xmm6
00007e55d47de08a  vmovaps [rsp+0x70], xmm7
00007e55d47de090  vmovaps [rsp+0x80], xmm8
00007e55d47de099  vmovaps [rsp+0x90], xmm9
00007e55d47de0a2  vmovaps [rsp+0xA0], xmm10
00007e55d47de0ab  vmovaps [rsp+0xB0], xmm11
00007e55d47de0b4  vmovaps [rsp+0xC0], xmm12
00007e55d47de0bd  vmovaps [rsp+0xD0], xmm13
00007e55d47de0c6  vmovaps [rsp+0xE0], xmm14
00007e55d47de0cf  sub rsp, 0x30
00007e55d47de0d3  movaps [rsp], xmm15
00007e55d47de0d8  movaps [rsp+0x10], xmm5
00007e55d47de0dd  movaps [rsp+0x20], xmm3
00007e55d47de0e2  lea rdi, [rsp]
00007e55d47de0e6  mov esi, 0x00
00007e55d47de0eb  mov rax, 0x55D0734A4530
00007e55d47de0f5  call rax
00007e55d47de0f7  movaps xmm15, [rsp]
00007e55d47de0fc  add rsp, 0x30
00007e55d47de100  vmovaps xmm0, [rsp]
00007e55d47de105  vmovaps xmm1, [rsp+0x10]
00007e55d47de10b  vmovaps xmm2, [rsp+0x20]
00007e55d47de111  vmovaps xmm3, [rsp+0x30]
00007e55d47de117  vmovaps xmm4, [rsp+0x40]
00007e55d47de11d  vmovaps xmm5, [rsp+0x50]
00007e55d47de123  vmovaps xmm6, [rsp+0x60]
00007e55d47de129  vmovaps xmm7, [rsp+0x70]
00007e55d47de12f  vmovaps xmm8, [rsp+0x80]
00007e55d47de138  vmovaps xmm9, [rsp+0x90]
00007e55d47de141  vmovaps xmm10, [rsp+0xA0]
00007e55d47de14a  vmovaps xmm11, [rsp+0xB0]
00007e55d47de153  vmovaps xmm12, [rsp+0xC0]
00007e55d47de15c  vmovaps xmm13, [rsp+0xD0]
00007e55d47de165  vmovaps xmm14, [rsp+0xE0]
00007e55d47de16e  add rsp, 0xF0
00007e55d47de175  pop r11
00007e55d47de177  pop r10
00007e55d47de179  pop r9
00007e55d47de17b  pop r8
00007e55d47de17d  pop rsi
00007e55d47de17e  pop rdi
00007e55d47de17f  pop rdx
00007e55d47de180  pop rcx
00007e55d47de181  pop rax
00007e55d47de182  add rsp, 0x08
00007e55d47de186  jmp 0x00007E55D47DC099
00007e55d47de18b  sub rsp, 0x08
00007e55d47de18f  push rax
00007e55d47de190  push rcx
00007e55d47de191  push rdx
00007e55d47de192  push rdi
00007e55d47de193  push rsi
00007e55d47de194  push r8
00007e55d47de196  push r9
00007e55d47de198  push r10
00007e55d47de19a  push r11
00007e55d47de19c  sub rsp, 0xF0
00007e55d47de1a3  vmovaps [rsp], xmm0
00007e55d47de1a8  vmovaps [rsp+0x10], xmm2
00007e55d47de1ae  vmovaps [rsp+0x20], xmm3
00007e55d47de1b4  vmovaps [rsp+0x30], xmm4
00007e55d47de1ba  vmovaps [rsp+0x40], xmm5
00007e55d47de1c0  vmovaps [rsp+0x50], xmm6
00007e55d47de1c6  vmovaps [rsp+0x60], xmm7
00007e55d47de1cc  vmovaps [rsp+0x70], xmm8
00007e55d47de1d2  vmovaps [rsp+0x80], xmm9
00007e55d47de1db  vmovaps [rsp+0x90], xmm10
00007e55d47de1e4  vmovaps [rsp+0xA0], xmm11
00007e55d47de1ed  vmovaps [rsp+0xB0], xmm12
00007e55d47de1f6  vmovaps [rsp+0xC0], xmm13
00007e55d47de1ff  vmovaps [rsp+0xD0], xmm14
00007e55d47de208  vmovaps [rsp+0xE0], xmm15
00007e55d47de211  sub rsp, 0x30
00007e55d47de215  movaps [rsp], xmm1
00007e55d47de219  movaps [rsp+0x10], xmm5
00007e55d47de21e  movaps [rsp+0x20], xmm4
00007e55d47de223  lea rdi, [rsp]
00007e55d47de227  mov esi, 0x00
00007e55d47de22c  mov rax, 0x55D0734A4530
00007e55d47de236  call rax
00007e55d47de238  movaps xmm1, [rsp]
00007e55d47de23c  add rsp, 0x30
00007e55d47de240  vmovaps xmm0, [rsp]
00007e55d47de245  vmovaps xmm2, [rsp+0x10]
00007e55d47de24b  vmovaps xmm3, [rsp+0x20]
00007e55d47de251  vmovaps xmm4, [rsp+0x30]
00007e55d47de257  vmovaps xmm5, [rsp+0x40]
00007e55d47de25d  vmovaps xmm6, [rsp+0x50]
00007e55d47de263  vmovaps xmm7, [rsp+0x60]
00007e55d47de269  vmovaps xmm8, [rsp+0x70]
00007e55d47de26f  vmovaps xmm9, [rsp+0x80]
00007e55d47de278  vmovaps xmm10, [rsp+0x90]
00007e55d47de281  vmovaps xmm11, [rsp+0xA0]
00007e55d47de28a  vmovaps xmm12, [rsp+0xB0]
00007e55d47de293  vmovaps xmm13, [rsp+0xC0]
00007e55d47de29c  vmovaps xmm14, [rsp+0xD0]
00007e55d47de2a5  vmovaps xmm15, [rsp+0xE0]
00007e55d47de2ae  add rsp, 0xF0
00007e55d47de2b5  pop r11
00007e55d47de2b7  pop r10
00007e55d47de2b9  pop r9
00007e55d47de2bb  pop r8
00007e55d47de2bd  pop rsi
00007e55d47de2be  pop rdi
00007e55d47de2bf  pop rdx
00007e55d47de2c0  pop rcx
00007e55d47de2c1  pop rax
00007e55d47de2c2  add rsp, 0x08
00007e55d47de2c6  jmp 0x00007E55D47DC0B9
00007e55d47de2cb  sub rsp, 0x08
00007e55d47de2cf  push rax
00007e55d47de2d0  push rcx
00007e55d47de2d1  push rdx
00007e55d47de2d2  push rdi
00007e55d47de2d3  push rsi
00007e55d47de2d4  push r8
00007e55d47de2d6  push r9
00007e55d47de2d8  push r10
00007e55d47de2da  push r11
00007e55d47de2dc  sub rsp, 0xF0
00007e55d47de2e3  vmovaps [rsp], xmm0
00007e55d47de2e8  vmovaps [rsp+0x10], xmm1
00007e55d47de2ee  vmovaps [rsp+0x20], xmm2
00007e55d47de2f4  vmovaps [rsp+0x30], xmm3
00007e55d47de2fa  vmovaps [rsp+0x40], xmm5
00007e55d47de300  vmovaps [rsp+0x50], xmm6
00007e55d47de306  vmovaps [rsp+0x60], xmm7
00007e55d47de30c  vmovaps [rsp+0x70], xmm8
00007e55d47de312  vmovaps [rsp+0x80], xmm9
00007e55d47de31b  vmovaps [rsp+0x90], xmm10
00007e55d47de324  vmovaps [rsp+0xA0], xmm11
00007e55d47de32d  vmovaps [rsp+0xB0], xmm12
00007e55d47de336  vmovaps [rsp+0xC0], xmm13
00007e55d47de33f  vmovaps [rsp+0xD0], xmm14
00007e55d47de348  vmovaps [rsp+0xE0], xmm15
00007e55d47de351  sub rsp, 0x30
00007e55d47de355  movaps [rsp], xmm4
00007e55d47de359  movaps [rsp+0x10], xmm3
00007e55d47de35e  movaps [rsp+0x20], xmm5
00007e55d47de363  lea rdi, [rsp]
00007e55d47de367  mov esi, 0x00
00007e55d47de36c  mov rax, 0x55D0734A4530
00007e55d47de376  call rax
00007e55d47de378  movaps xmm4, [rsp]
00007e55d47de37c  add rsp, 0x30
00007e55d47de380  vmovaps xmm0, [rsp]
00007e55d47de385  vmovaps xmm1, [rsp+0x10]
00007e55d47de38b  vmovaps xmm2, [rsp+0x20]
00007e55d47de391  vmovaps xmm3, [rsp+0x30]
00007e55d47de397  vmovaps xmm5, [rsp+0x40]
00007e55d47de39d  vmovaps xmm6, [rsp+0x50]
00007e55d47de3a3  vmovaps xmm7, [rsp+0x60]
00007e55d47de3a9  vmovaps xmm8, [rsp+0x70]
00007e55d47de3af  vmovaps xmm9, [rsp+0x80]
00007e55d47de3b8  vmovaps xmm10, [rsp+0x90]
00007e55d47de3c1  vmovaps xmm11, [rsp+0xA0]
00007e55d47de3ca  vmovaps xmm12, [rsp+0xB0]
00007e55d47de3d3  vmovaps xmm13, [rsp+0xC0]
00007e55d47de3dc  vmovaps xmm14, [rsp+0xD0]
00007e55d47de3e5  vmovaps xmm15, [rsp+0xE0]
00007e55d47de3ee  add rsp, 0xF0
00007e55d47de3f5  pop r11
00007e55d47de3f7  pop r10
00007e55d47de3f9  pop r9
00007e55d47de3fb  pop r8
00007e55d47de3fd  pop rsi
00007e55d47de3fe  pop rdi
00007e55d47de3ff  pop rdx
00007e55d47de400  pop rcx
00007e55d47de401  pop rax
00007e55d47de402  add rsp, 0x08
00007e55d47de406  jmp 0x00007E55D47DC107
00007e55d47de40b  call 0x00007E55D46B52F0
00007e55d47de410  jmp 0x00007E55D47DC114
00007e55d47de415  sub rsp, 0x08
00007e55d47de419  push rax
00007e55d47de41a  push rcx
00007e55d47de41b  push rdx
00007e55d47de41c  push rdi
00007e55d47de41d  push rsi
00007e55d47de41e  push r8
00007e55d47de420  push r9
00007e55d47de422  push r10
00007e55d47de424  push r11
00007e55d47de426  sub rsp, 0xF0
00007e55d47de42d  vmovaps [rsp], xmm0
00007e55d47de432  vmovaps [rsp+0x10], xmm1
00007e55d47de438  vmovaps [rsp+0x20], xmm2
00007e55d47de43e  vmovaps [rsp+0x30], xmm3
00007e55d47de444  vmovaps [rsp+0x40], xmm4
00007e55d47de44a  vmovaps [rsp+0x50], xmm6
00007e55d47de450  vmovaps [rsp+0x60], xmm7
00007e55d47de456  vmovaps [rsp+0x70], xmm8
00007e55d47de45c  vmovaps [rsp+0x80], xmm9
00007e55d47de465  vmovaps [rsp+0x90], xmm10
00007e55d47de46e  vmovaps [rsp+0xA0], xmm11
00007e55d47de477  vmovaps [rsp+0xB0], xmm12
00007e55d47de480  vmovaps [rsp+0xC0], xmm13
00007e55d47de489  vmovaps [rsp+0xD0], xmm14
00007e55d47de492  vmovaps [rsp+0xE0], xmm15
00007e55d47de49b  sub rsp, 0x30
00007e55d47de49f  movaps [rsp], xmm5
00007e55d47de4a3  movaps [rsp+0x10], xmm6
00007e55d47de4a8  movaps [rsp+0x20], xmm3
00007e55d47de4ad  lea rdi, [rsp]
00007e55d47de4b1  mov esi, 0x00
00007e55d47de4b6  mov rax, 0x55D0734A4530
00007e55d47de4c0  call rax
00007e55d47de4c2  movaps xmm5, [rsp]
00007e55d47de4c6  add rsp, 0x30
00007e55d47de4ca  vmovaps xmm0, [rsp]
00007e55d47de4cf  vmovaps xmm1, [rsp+0x10]
00007e55d47de4d5  vmovaps xmm2, [rsp+0x20]
00007e55d47de4db  vmovaps xmm3, [rsp+0x30]
00007e55d47de4e1  vmovaps xmm4, [rsp+0x40]
00007e55d47de4e7  vmovaps xmm6, [rsp+0x50]
00007e55d47de4ed  vmovaps xmm7, [rsp+0x60]
00007e55d47de4f3  vmovaps xmm8, [rsp+0x70]
00007e55d47de4f9  vmovaps xmm9, [rsp+0x80]
00007e55d47de502  vmovaps xmm10, [rsp+0x90]
00007e55d47de50b  vmovaps xmm11, [rsp+0xA0]
00007e55d47de514  vmovaps xmm12, [rsp+0xB0]
00007e55d47de51d  vmovaps xmm13, [rsp+0xC0]
00007e55d47de526  vmovaps xmm14, [rsp+0xD0]
00007e55d47de52f  vmovaps xmm15, [rsp+0xE0]
00007e55d47de538  add rsp, 0xF0
00007e55d47de53f  pop r11
00007e55d47de541  pop r10
00007e55d47de543  pop r9
00007e55d47de545  pop r8
00007e55d47de547  pop rsi
00007e55d47de548  pop rdi
00007e55d47de549  pop rdx
00007e55d47de54a  pop rcx
00007e55d47de54b  pop rax
00007e55d47de54c  add rsp, 0x08
00007e55d47de550  jmp 0x00007E55D47DC13A
00007e55d47de555  sub rsp, 0x08
00007e55d47de559  push rax
00007e55d47de55a  push rcx
00007e55d47de55b  push rdx
00007e55d47de55c  push rdi
00007e55d47de55d  push rsi
00007e55d47de55e  push r8
00007e55d47de560  push r9
00007e55d47de562  push r10
00007e55d47de564  push r11
00007e55d47de566  sub rsp, 0xF0
00007e55d47de56d  vmovaps [rsp], xmm0
00007e55d47de572  vmovaps [rsp+0x10], xmm1
00007e55d47de578  vmovaps [rsp+0x20], xmm2
00007e55d47de57e  vmovaps [rsp+0x30], xmm3
00007e55d47de584  vmovaps [rsp+0x40], xmm4
00007e55d47de58a  vmovaps [rsp+0x50], xmm5
00007e55d47de590  vmovaps [rsp+0x60], xmm7
00007e55d47de596  vmovaps [rsp+0x70], xmm8
00007e55d47de59c  vmovaps [rsp+0x80], xmm9
00007e55d47de5a5  vmovaps [rsp+0x90], xmm10
00007e55d47de5ae  vmovaps [rsp+0xA0], xmm11
00007e55d47de5b7  vmovaps [rsp+0xB0], xmm12
00007e55d47de5c0  vmovaps [rsp+0xC0], xmm13
00007e55d47de5c9  vmovaps [rsp+0xD0], xmm14
00007e55d47de5d2  vmovaps [rsp+0xE0], xmm15
00007e55d47de5db  sub rsp, 0x30
00007e55d47de5df  movaps [rsp], xmm6
00007e55d47de5e3  movaps [rsp+0x10], xmm9
00007e55d47de5e9  movaps [rsp+0x20], xmm1
00007e55d47de5ee  lea rdi, [rsp]
00007e55d47de5f2  mov esi, 0x00
00007e55d47de5f7  mov rax, 0x55D0734A4530
00007e55d47de601  call rax
00007e55d47de603  movaps xmm6, [rsp]
00007e55d47de607  add rsp, 0x30
00007e55d47de60b  vmovaps xmm0, [rsp]
00007e55d47de610  vmovaps xmm1, [rsp+0x10]
00007e55d47de616  vmovaps xmm2, [rsp+0x20]
00007e55d47de61c  vmovaps xmm3, [rsp+0x30]
00007e55d47de622  vmovaps xmm4, [rsp+0x40]
00007e55d47de628  vmovaps xmm5, [rsp+0x50]
00007e55d47de62e  vmovaps xmm7, [rsp+0x60]
00007e55d47de634  vmovaps xmm8, [rsp+0x70]
00007e55d47de63a  vmovaps xmm9, [rsp+0x80]
00007e55d47de643  vmovaps xmm10, [rsp+0x90]
00007e55d47de64c  vmovaps xmm11, [rsp+0xA0]
00007e55d47de655  vmovaps xmm12, [rsp+0xB0]
00007e55d47de65e  vmovaps xmm13, [rsp+0xC0]
00007e55d47de667  vmovaps xmm14, [rsp+0xD0]
00007e55d47de670  vmovaps xmm15, [rsp+0xE0]
00007e55d47de679  add rsp, 0xF0
00007e55d47de680  pop r11
00007e55d47de682  pop r10
00007e55d47de684  pop r9
00007e55d47de686  pop r8
00007e55d47de688  pop rsi
00007e55d47de689  pop rdi
00007e55d47de68a  pop rdx
00007e55d47de68b  pop rcx
00007e55d47de68c  pop rax
00007e55d47de68d  add rsp, 0x08
00007e55d47de691  jmp 0x00007E55D47DC15E
00007e55d47de696  sub rsp, 0x08
00007e55d47de69a  push rax
00007e55d47de69b  push rcx
00007e55d47de69c  push rdx
00007e55d47de69d  push rdi
00007e55d47de69e  push rsi
00007e55d47de69f  push r8
00007e55d47de6a1  push r9
00007e55d47de6a3  push r10
00007e55d47de6a5  push r11
00007e55d47de6a7  sub rsp, 0xF0
00007e55d47de6ae  vmovaps [rsp], xmm0
00007e55d47de6b3  vmovaps [rsp+0x10], xmm1
00007e55d47de6b9  vmovaps [rsp+0x20], xmm2
00007e55d47de6bf  vmovaps [rsp+0x30], xmm3
00007e55d47de6c5  vmovaps [rsp+0x40], xmm4
00007e55d47de6cb  vmovaps [rsp+0x50], xmm5
00007e55d47de6d1  vmovaps [rsp+0x60], xmm6
00007e55d47de6d7  vmovaps [rsp+0x70], xmm7
00007e55d47de6dd  vmovaps [rsp+0x80], xmm8
00007e55d47de6e6  vmovaps [rsp+0x90], xmm10
00007e55d47de6ef  vmovaps [rsp+0xA0], xmm11
00007e55d47de6f8  vmovaps [rsp+0xB0], xmm12
00007e55d47de701  vmovaps [rsp+0xC0], xmm13
00007e55d47de70a  vmovaps [rsp+0xD0], xmm14
00007e55d47de713  vmovaps [rsp+0xE0], xmm15
00007e55d47de71c  sub rsp, 0x30
00007e55d47de720  movaps [rsp], xmm9
00007e55d47de725  movaps [rsp+0x10], xmm3
00007e55d47de72a  movaps [rsp+0x20], xmm1
00007e55d47de72f  lea rdi, [rsp]
00007e55d47de733  mov esi, 0x00
00007e55d47de738  mov rax, 0x55D0734A4530
00007e55d47de742  call rax
00007e55d47de744  movaps xmm9, [rsp]
00007e55d47de749  add rsp, 0x30
00007e55d47de74d  vmovaps xmm0, [rsp]
00007e55d47de752  vmovaps xmm1, [rsp+0x10]
00007e55d47de758  vmovaps xmm2, [rsp+0x20]
00007e55d47de75e  vmovaps xmm3, [rsp+0x30]
00007e55d47de764  vmovaps xmm4, [rsp+0x40]
00007e55d47de76a  vmovaps xmm5, [rsp+0x50]
00007e55d47de770  vmovaps xmm6, [rsp+0x60]
00007e55d47de776  vmovaps xmm7, [rsp+0x70]
00007e55d47de77c  vmovaps xmm8, [rsp+0x80]
00007e55d47de785  vmovaps xmm10, [rsp+0x90]
00007e55d47de78e  vmovaps xmm11, [rsp+0xA0]
00007e55d47de797  vmovaps xmm12, [rsp+0xB0]
00007e55d47de7a0  vmovaps xmm13, [rsp+0xC0]
00007e55d47de7a9  vmovaps xmm14, [rsp+0xD0]
00007e55d47de7b2  vmovaps xmm15, [rsp+0xE0]
00007e55d47de7bb  add rsp, 0xF0
00007e55d47de7c2  pop r11
00007e55d47de7c4  pop r10
00007e55d47de7c6  pop r9
00007e55d47de7c8  pop r8
00007e55d47de7ca  pop rsi
00007e55d47de7cb  pop rdi
00007e55d47de7cc  pop rdx
00007e55d47de7cd  pop rcx
00007e55d47de7ce  pop rax
00007e55d47de7cf  add rsp, 0x08
00007e55d47de7d3  jmp 0x00007E55D47DC1AA
00007e55d47de7d8  call 0x00007E55D46B52F0
00007e55d47de7dd  jmp 0x00007E55D47DC1B7
00007e55d47de7e2  sub rsp, 0x08
00007e55d47de7e6  push rax
00007e55d47de7e7  push rcx
00007e55d47de7e8  push rdx
00007e55d47de7e9  push rdi
00007e55d47de7ea  push rsi
00007e55d47de7eb  push r8
00007e55d47de7ed  push r9
00007e55d47de7ef  push r10
00007e55d47de7f1  push r11
00007e55d47de7f3  sub rsp, 0xF0
00007e55d47de7fa  vmovaps [rsp], xmm0
00007e55d47de7ff  vmovaps [rsp+0x10], xmm1
00007e55d47de805  vmovaps [rsp+0x20], xmm2
00007e55d47de80b  vmovaps [rsp+0x30], xmm3
00007e55d47de811  vmovaps [rsp+0x40], xmm4
00007e55d47de817  vmovaps [rsp+0x50], xmm5
00007e55d47de81d  vmovaps [rsp+0x60], xmm6
00007e55d47de823  vmovaps [rsp+0x70], xmm7
00007e55d47de829  vmovaps [rsp+0x80], xmm8
00007e55d47de832  vmovaps [rsp+0x90], xmm9
00007e55d47de83b  vmovaps [rsp+0xA0], xmm10
00007e55d47de844  vmovaps [rsp+0xB0], xmm11
00007e55d47de84d  vmovaps [rsp+0xC0], xmm12
00007e55d47de856  vmovaps [rsp+0xD0], xmm13
00007e55d47de85f  vmovaps [rsp+0xE0], xmm14
00007e55d47de868  sub rsp, 0x30
00007e55d47de86c  movaps [rsp], xmm15
00007e55d47de871  movaps [rsp+0x10], xmm3
00007e55d47de876  movaps [rsp+0x20], xmm7
00007e55d47de87b  lea rdi, [rsp]
00007e55d47de87f  mov esi, 0x00
00007e55d47de884  mov rax, 0x55D0734A4530
00007e55d47de88e  call rax
00007e55d47de890  movaps xmm15, [rsp]
00007e55d47de895  add rsp, 0x30
00007e55d47de899  vmovaps xmm0, [rsp]
00007e55d47de89e  vmovaps xmm1, [rsp+0x10]
00007e55d47de8a4  vmovaps xmm2, [rsp+0x20]
00007e55d47de8aa  vmovaps xmm3, [rsp+0x30]
00007e55d47de8b0  vmovaps xmm4, [rsp+0x40]
00007e55d47de8b6  vmovaps xmm5, [rsp+0x50]
00007e55d47de8bc  vmovaps xmm6, [rsp+0x60]
00007e55d47de8c2  vmovaps xmm7, [rsp+0x70]
00007e55d47de8c8  vmovaps xmm8, [rsp+0x80]
00007e55d47de8d1  vmovaps xmm9, [rsp+0x90]
00007e55d47de8da  vmovaps xmm10, [rsp+0xA0]
00007e55d47de8e3  vmovaps xmm11, [rsp+0xB0]
00007e55d47de8ec  vmovaps xmm12, [rsp+0xC0]
00007e55d47de8f5  vmovaps xmm13, [rsp+0xD0]
00007e55d47de8fe  vmovaps xmm14, [rsp+0xE0]
00007e55d47de907  add rsp, 0xF0
00007e55d47de90e  pop r11
00007e55d47de910  pop r10
00007e55d47de912  pop r9
00007e55d47de914  pop r8
00007e55d47de916  pop rsi
00007e55d47de917  pop rdi
00007e55d47de918  pop rdx
00007e55d47de919  pop rcx
00007e55d47de91a  pop rax
00007e55d47de91b  add rsp, 0x08
00007e55d47de91f  jmp 0x00007E55D47DC1E3
00007e55d47de924  sub rsp, 0x08
00007e55d47de928  push rax
00007e55d47de929  push rcx
00007e55d47de92a  push rdx
00007e55d47de92b  push rdi
00007e55d47de92c  push rsi
00007e55d47de92d  push r8
00007e55d47de92f  push r9
00007e55d47de931  push r10
00007e55d47de933  push r11
00007e55d47de935  sub rsp, 0xF0
00007e55d47de93c  vmovaps [rsp], xmm0
00007e55d47de941  vmovaps [rsp+0x10], xmm1
00007e55d47de947  vmovaps [rsp+0x20], xmm2
00007e55d47de94d  vmovaps [rsp+0x30], xmm4
00007e55d47de953  vmovaps [rsp+0x40], xmm5
00007e55d47de959  vmovaps [rsp+0x50], xmm6
00007e55d47de95f  vmovaps [rsp+0x60], xmm7
00007e55d47de965  vmovaps [rsp+0x70], xmm8
00007e55d47de96b  vmovaps [rsp+0x80], xmm9
00007e55d47de974  vmovaps [rsp+0x90], xmm10
00007e55d47de97d  vmovaps [rsp+0xA0], xmm11
00007e55d47de986  vmovaps [rsp+0xB0], xmm12
00007e55d47de98f  vmovaps [rsp+0xC0], xmm13
00007e55d47de998  vmovaps [rsp+0xD0], xmm14
00007e55d47de9a1  vmovaps [rsp+0xE0], xmm15
00007e55d47de9aa  sub rsp, 0x30
00007e55d47de9ae  movaps [rsp], xmm3
00007e55d47de9b2  movaps [rsp+0x10], xmm1
00007e55d47de9b7  movaps [rsp+0x20], xmm15
00007e55d47de9bd  lea rdi, [rsp]
00007e55d47de9c1  mov esi, 0x00
00007e55d47de9c6  mov rax, 0x55D0734A4530
00007e55d47de9d0  call rax
00007e55d47de9d2  movaps xmm3, [rsp]
00007e55d47de9d6  add rsp, 0x30
00007e55d47de9da  vmovaps xmm0, [rsp]
00007e55d47de9df  vmovaps xmm1, [rsp+0x10]
00007e55d47de9e5  vmovaps xmm2, [rsp+0x20]
00007e55d47de9eb  vmovaps xmm4, [rsp+0x30]
00007e55d47de9f1  vmovaps xmm5, [rsp+0x40]
00007e55d47de9f7  vmovaps xmm6, [rsp+0x50]
00007e55d47de9fd  vmovaps xmm7, [rsp+0x60]
00007e55d47dea03  vmovaps xmm8, [rsp+0x70]
00007e55d47dea09  vmovaps xmm9, [rsp+0x80]
00007e55d47dea12  vmovaps xmm10, [rsp+0x90]
00007e55d47dea1b  vmovaps xmm11, [rsp+0xA0]
00007e55d47dea24  vmovaps xmm12, [rsp+0xB0]
00007e55d47dea2d  vmovaps xmm13, [rsp+0xC0]
00007e55d47dea36  vmovaps xmm14, [rsp+0xD0]
00007e55d47dea3f  vmovaps xmm15, [rsp+0xE0]
00007e55d47dea48  add rsp, 0xF0
00007e55d47dea4f  pop r11
00007e55d47dea51  pop r10
00007e55d47dea53  pop r9
00007e55d47dea55  pop r8
00007e55d47dea57  pop rsi
00007e55d47dea58  pop rdi
00007e55d47dea59  pop rdx
00007e55d47dea5a  pop rcx
00007e55d47dea5b  pop rax
00007e55d47dea5c  add rsp, 0x08
00007e55d47dea60  jmp 0x00007E55D47DC272
00007e55d47dea65  call 0x00007E55D46B52F0
00007e55d47dea6a  jmp 0x00007E55D47DC27C
00007e55d47dea6f  sub rsp, 0x08
00007e55d47dea73  push rax
00007e55d47dea74  push rcx
00007e55d47dea75  push rdx
00007e55d47dea76  push rdi
00007e55d47dea77  push rsi
00007e55d47dea78  push r8
00007e55d47dea7a  push r9
00007e55d47dea7c  push r10
00007e55d47dea7e  push r11
00007e55d47dea80  sub rsp, 0xF0
00007e55d47dea87  vmovaps [rsp], xmm0
00007e55d47dea8c  vmovaps [rsp+0x10], xmm1
00007e55d47dea92  vmovaps [rsp+0x20], xmm2
00007e55d47dea98  vmovaps [rsp+0x30], xmm3
00007e55d47dea9e  vmovaps [rsp+0x40], xmm4
00007e55d47deaa4  vmovaps [rsp+0x50], xmm5
00007e55d47deaaa  vmovaps [rsp+0x60], xmm6
00007e55d47deab0  vmovaps [rsp+0x70], xmm7
00007e55d47deab6  vmovaps [rsp+0x80], xmm8
00007e55d47deabf  vmovaps [rsp+0x90], xmm9
00007e55d47deac8  vmovaps [rsp+0xA0], xmm10
00007e55d47dead1  vmovaps [rsp+0xB0], xmm11
00007e55d47deada  vmovaps [rsp+0xC0], xmm12
00007e55d47deae3  vmovaps [rsp+0xD0], xmm13
00007e55d47deaec  vmovaps [rsp+0xE0], xmm14
00007e55d47deaf5  sub rsp, 0x30
00007e55d47deaf9  movaps [rsp], xmm15
00007e55d47deafe  movaps [rsp+0x10], xmm14
00007e55d47deb04  movaps [rsp+0x20], xmm4
00007e55d47deb09  lea rdi, [rsp]
00007e55d47deb0d  mov esi, 0x00
00007e55d47deb12  mov rax, 0x55D0734A4530
00007e55d47deb1c  call rax
00007e55d47deb1e  movaps xmm15, [rsp]
00007e55d47deb23  add rsp, 0x30
00007e55d47deb27  vmovaps xmm0, [rsp]
00007e55d47deb2c  vmovaps xmm1, [rsp+0x10]
00007e55d47deb32  vmovaps xmm2, [rsp+0x20]
00007e55d47deb38  vmovaps xmm3, [rsp+0x30]
00007e55d47deb3e  vmovaps xmm4, [rsp+0x40]
00007e55d47deb44  vmovaps xmm5, [rsp+0x50]
00007e55d47deb4a  vmovaps xmm6, [rsp+0x60]
00007e55d47deb50  vmovaps xmm7, [rsp+0x70]
00007e55d47deb56  vmovaps xmm8, [rsp+0x80]
00007e55d47deb5f  vmovaps xmm9, [rsp+0x90]
00007e55d47deb68  vmovaps xmm10, [rsp+0xA0]
00007e55d47deb71  vmovaps xmm11, [rsp+0xB0]
00007e55d47deb7a  vmovaps xmm12, [rsp+0xC0]
00007e55d47deb83  vmovaps xmm13, [rsp+0xD0]
00007e55d47deb8c  vmovaps xmm14, [rsp+0xE0]
00007e55d47deb95  add rsp, 0xF0
00007e55d47deb9c  pop r11
00007e55d47deb9e  pop r10
00007e55d47deba0  pop r9
00007e55d47deba2  pop r8
00007e55d47deba4  pop rsi
00007e55d47deba5  pop rdi
00007e55d47deba6  pop rdx
00007e55d47deba7  pop rcx
00007e55d47deba8  pop rax
00007e55d47deba9  add rsp, 0x08
00007e55d47debad  jmp 0x00007E55D47DC2AA
00007e55d47debb2  sub rsp, 0x08
00007e55d47debb6  push rax
00007e55d47debb7  push rcx
00007e55d47debb8  push rdx
00007e55d47debb9  push rdi
00007e55d47debba  push rsi
00007e55d47debbb  push r8
00007e55d47debbd  push r9
00007e55d47debbf  push r10
00007e55d47debc1  push r11
00007e55d47debc3  sub rsp, 0xF0
00007e55d47debca  vmovaps [rsp], xmm0
00007e55d47debcf  vmovaps [rsp+0x10], xmm1
00007e55d47debd5  vmovaps [rsp+0x20], xmm2
00007e55d47debdb  vmovaps [rsp+0x30], xmm3
00007e55d47debe1  vmovaps [rsp+0x40], xmm4
00007e55d47debe7  vmovaps [rsp+0x50], xmm5
00007e55d47debed  vmovaps [rsp+0x60], xmm6
00007e55d47debf3  vmovaps [rsp+0x70], xmm7
00007e55d47debf9  vmovaps [rsp+0x80], xmm8
00007e55d47dec02  vmovaps [rsp+0x90], xmm9
00007e55d47dec0b  vmovaps [rsp+0xA0], xmm10
00007e55d47dec14  vmovaps [rsp+0xB0], xmm11
00007e55d47dec1d  vmovaps [rsp+0xC0], xmm12
00007e55d47dec26  vmovaps [rsp+0xD0], xmm13
00007e55d47dec2f  vmovaps [rsp+0xE0], xmm15
00007e55d47dec38  sub rsp, 0x30
00007e55d47dec3c  movaps [rsp], xmm14
00007e55d47dec41  movaps [rsp+0x10], xmm2
00007e55d47dec46  movaps [rsp+0x20], xmm1
00007e55d47dec4b  lea rdi, [rsp]
00007e55d47dec4f  mov esi, 0x00
00007e55d47dec54  mov rax, 0x55D0734A4530
00007e55d47dec5e  call rax
00007e55d47dec60  movaps xmm14, [rsp]
00007e55d47dec65  add rsp, 0x30
00007e55d47dec69  vmovaps xmm0, [rsp]
00007e55d47dec6e  vmovaps xmm1, [rsp+0x10]
00007e55d47dec74  vmovaps xmm2, [rsp+0x20]
00007e55d47dec7a  vmovaps xmm3, [rsp+0x30]
00007e55d47dec80  vmovaps xmm4, [rsp+0x40]
00007e55d47dec86  vmovaps xmm5, [rsp+0x50]
00007e55d47dec8c  vmovaps xmm6, [rsp+0x60]
00007e55d47dec92  vmovaps xmm7, [rsp+0x70]
00007e55d47dec98  vmovaps xmm8, [rsp+0x80]
00007e55d47deca1  vmovaps xmm9, [rsp+0x90]
00007e55d47decaa  vmovaps xmm10, [rsp+0xA0]
00007e55d47decb3  vmovaps xmm11, [rsp+0xB0]
00007e55d47decbc  vmovaps xmm12, [rsp+0xC0]
00007e55d47decc5  vmovaps xmm13, [rsp+0xD0]
00007e55d47decce  vmovaps xmm15, [rsp+0xE0]
00007e55d47decd7  add rsp, 0xF0
00007e55d47decde  pop r11
00007e55d47dece0  pop r10
00007e55d47dece2  pop r9
00007e55d47dece4  pop r8
00007e55d47dece6  pop rsi
00007e55d47dece7  pop rdi
00007e55d47dece8  pop rdx
00007e55d47dece9  pop rcx
00007e55d47decea  pop rax
00007e55d47deceb  add rsp, 0x08
00007e55d47decef  jmp 0x00007E55D47DC2D0
00007e55d47decf4  sub rsp, 0x08
00007e55d47decf8  push rax
00007e55d47decf9  push rcx
00007e55d47decfa  push rdx
00007e55d47decfb  push rdi
00007e55d47decfc  push rsi
00007e55d47decfd  push r8
00007e55d47decff  push r9
00007e55d47ded01  push r10
00007e55d47ded03  push r11
00007e55d47ded05  sub rsp, 0xF0
00007e55d47ded0c  vmovaps [rsp], xmm0
00007e55d47ded11  vmovaps [rsp+0x10], xmm2
00007e55d47ded17  vmovaps [rsp+0x20], xmm3
00007e55d47ded1d  vmovaps [rsp+0x30], xmm4
00007e55d47ded23  vmovaps [rsp+0x40], xmm5
00007e55d47ded29  vmovaps [rsp+0x50], xmm6
00007e55d47ded2f  vmovaps [rsp+0x60], xmm7
00007e55d47ded35  vmovaps [rsp+0x70], xmm8
00007e55d47ded3b  vmovaps [rsp+0x80], xmm9
00007e55d47ded44  vmovaps [rsp+0x90], xmm10
00007e55d47ded4d  vmovaps [rsp+0xA0], xmm11
00007e55d47ded56  vmovaps [rsp+0xB0], xmm12
00007e55d47ded5f  vmovaps [rsp+0xC0], xmm13
00007e55d47ded68  vmovaps [rsp+0xD0], xmm14
00007e55d47ded71  vmovaps [rsp+0xE0], xmm15
00007e55d47ded7a  sub rsp, 0x30
00007e55d47ded7e  movaps [rsp], xmm1
00007e55d47ded82  movaps [rsp+0x10], xmm4
00007e55d47ded87  movaps [rsp+0x20], xmm9
00007e55d47ded8d  lea rdi, [rsp]
00007e55d47ded91  mov esi, 0x00
00007e55d47ded96  mov rax, 0x55D0734A4530
00007e55d47deda0  call rax
00007e55d47deda2  movaps xmm1, [rsp]
00007e55d47deda6  add rsp, 0x30
00007e55d47dedaa  vmovaps xmm0, [rsp]
00007e55d47dedaf  vmovaps xmm2, [rsp+0x10]
00007e55d47dedb5  vmovaps xmm3, [rsp+0x20]
00007e55d47dedbb  vmovaps xmm4, [rsp+0x30]
00007e55d47dedc1  vmovaps xmm5, [rsp+0x40]
00007e55d47dedc7  vmovaps xmm6, [rsp+0x50]
00007e55d47dedcd  vmovaps xmm7, [rsp+0x60]
00007e55d47dedd3  vmovaps xmm8, [rsp+0x70]
00007e55d47dedd9  vmovaps xmm9, [rsp+0x80]
00007e55d47dede2  vmovaps xmm10, [rsp+0x90]
00007e55d47dedeb  vmovaps xmm11, [rsp+0xA0]
00007e55d47dedf4  vmovaps xmm12, [rsp+0xB0]
00007e55d47dedfd  vmovaps xmm13, [rsp+0xC0]
00007e55d47dee06  vmovaps xmm14, [rsp+0xD0]
00007e55d47dee0f  vmovaps xmm15, [rsp+0xE0]
00007e55d47dee18  add rsp, 0xF0
00007e55d47dee1f  pop r11
00007e55d47dee21  pop r10
00007e55d47dee23  pop r9
00007e55d47dee25  pop r8
00007e55d47dee27  pop rsi
00007e55d47dee28  pop rdi
00007e55d47dee29  pop rdx
00007e55d47dee2a  pop rcx
00007e55d47dee2b  pop rax
00007e55d47dee2c  add rsp, 0x08
00007e55d47dee30  jmp 0x00007E55D47DC2EE
00007e55d47dee35  sub rsp, 0x08
00007e55d47dee39  push rax
00007e55d47dee3a  push rcx
00007e55d47dee3b  push rdx
00007e55d47dee3c  push rdi
00007e55d47dee3d  push rsi
00007e55d47dee3e  push r8
00007e55d47dee40  push r9
00007e55d47dee42  push r10
00007e55d47dee44  push r11
00007e55d47dee46  sub rsp, 0xF0
00007e55d47dee4d  vmovaps [rsp], xmm0
00007e55d47dee52  vmovaps [rsp+0x10], xmm1
00007e55d47dee58  vmovaps [rsp+0x20], xmm2
00007e55d47dee5e  vmovaps [rsp+0x30], xmm3
00007e55d47dee64  vmovaps [rsp+0x40], xmm5
00007e55d47dee6a  vmovaps [rsp+0x50], xmm6
00007e55d47dee70  vmovaps [rsp+0x60], xmm7
00007e55d47dee76  vmovaps [rsp+0x70], xmm8
00007e55d47dee7c  vmovaps [rsp+0x80], xmm9
00007e55d47dee85  vmovaps [rsp+0x90], xmm10
00007e55d47dee8e  vmovaps [rsp+0xA0], xmm11
00007e55d47dee97  vmovaps [rsp+0xB0], xmm12
00007e55d47deea0  vmovaps [rsp+0xC0], xmm13
00007e55d47deea9  vmovaps [rsp+0xD0], xmm14
00007e55d47deeb2  vmovaps [rsp+0xE0], xmm15
00007e55d47deebb  sub rsp, 0x30
00007e55d47deebf  movaps [rsp], xmm4
00007e55d47deec3  movaps [rsp+0x10], xmm2
00007e55d47deec8  movaps [rsp+0x20], xmm9
00007e55d47deece  lea rdi, [rsp]
00007e55d47deed2  mov esi, 0x00
00007e55d47deed7  mov rax, 0x55D0734A4530
00007e55d47deee1  call rax
00007e55d47deee3  movaps xmm4, [rsp]
00007e55d47deee7  add rsp, 0x30
00007e55d47deeeb  vmovaps xmm0, [rsp]
00007e55d47deef0  vmovaps xmm1, [rsp+0x10]
00007e55d47deef6  vmovaps xmm2, [rsp+0x20]
00007e55d47deefc  vmovaps xmm3, [rsp+0x30]
00007e55d47def02  vmovaps xmm5, [rsp+0x40]
00007e55d47def08  vmovaps xmm6, [rsp+0x50]
00007e55d47def0e  vmovaps xmm7, [rsp+0x60]
00007e55d47def14  vmovaps xmm8, [rsp+0x70]
00007e55d47def1a  vmovaps xmm9, [rsp+0x80]
00007e55d47def23  vmovaps xmm10, [rsp+0x90]
00007e55d47def2c  vmovaps xmm11, [rsp+0xA0]
00007e55d47def35  vmovaps xmm12, [rsp+0xB0]
00007e55d47def3e  vmovaps xmm13, [rsp+0xC0]
00007e55d47def47  vmovaps xmm14, [rsp+0xD0]
00007e55d47def50  vmovaps xmm15, [rsp+0xE0]
00007e55d47def59  add rsp, 0xF0
00007e55d47def60  pop r11
00007e55d47def62  pop r10
00007e55d47def64  pop r9
00007e55d47def66  pop r8
00007e55d47def68  pop rsi
00007e55d47def69  pop rdi
00007e55d47def6a  pop rdx
00007e55d47def6b  pop rcx
00007e55d47def6c  pop rax
00007e55d47def6d  add rsp, 0x08
00007e55d47def71  jmp 0x00007E55D47DC31E
00007e55d47def76  sub rsp, 0x08
00007e55d47def7a  push rax
00007e55d47def7b  push rcx
00007e55d47def7c  push rdx
00007e55d47def7d  push rdi
00007e55d47def7e  push rsi
00007e55d47def7f  push r8
00007e55d47def81  push r9
00007e55d47def83  push r10
00007e55d47def85  push r11
00007e55d47def87  sub rsp, 0xF0
00007e55d47def8e  vmovaps [rsp], xmm0
00007e55d47def93  vmovaps [rsp+0x10], xmm1
00007e55d47def99  vmovaps [rsp+0x20], xmm2
00007e55d47def9f  vmovaps [rsp+0x30], xmm3
00007e55d47defa5  vmovaps [rsp+0x40], xmm4
00007e55d47defab  vmovaps [rsp+0x50], xmm5
00007e55d47defb1  vmovaps [rsp+0x60], xmm6
00007e55d47defb7  vmovaps [rsp+0x70], xmm7
00007e55d47defbd  vmovaps [rsp+0x80], xmm8
00007e55d47defc6  vmovaps [rsp+0x90], xmm10
00007e55d47defcf  vmovaps [rsp+0xA0], xmm11
00007e55d47defd8  vmovaps [rsp+0xB0], xmm12
00007e55d47defe1  vmovaps [rsp+0xC0], xmm13
00007e55d47defea  vmovaps [rsp+0xD0], xmm14
00007e55d47deff3  vmovaps [rsp+0xE0], xmm15
00007e55d47deffc  sub rsp, 0x30
00007e55d47df000  movaps [rsp], xmm9
00007e55d47df005  movaps [rsp+0x10], xmm2
00007e55d47df00a  movaps [rsp+0x20], xmm1
00007e55d47df00f  lea rdi, [rsp]
00007e55d47df013  mov esi, 0x00
00007e55d47df018  mov rax, 0x55D0734A4530
00007e55d47df022  call rax
00007e55d47df024  movaps xmm9, [rsp]
00007e55d47df029  add rsp, 0x30
00007e55d47df02d  vmovaps xmm0, [rsp]
00007e55d47df032  vmovaps xmm1, [rsp+0x10]
00007e55d47df038  vmovaps xmm2, [rsp+0x20]
00007e55d47df03e  vmovaps xmm3, [rsp+0x30]
00007e55d47df044  vmovaps xmm4, [rsp+0x40]
00007e55d47df04a  vmovaps xmm5, [rsp+0x50]
00007e55d47df050  vmovaps xmm6, [rsp+0x60]
00007e55d47df056  vmovaps xmm7, [rsp+0x70]
00007e55d47df05c  vmovaps xmm8, [rsp+0x80]
00007e55d47df065  vmovaps xmm10, [rsp+0x90]
00007e55d47df06e  vmovaps xmm11, [rsp+0xA0]
00007e55d47df077  vmovaps xmm12, [rsp+0xB0]
00007e55d47df080  vmovaps xmm13, [rsp+0xC0]
00007e55d47df089  vmovaps xmm14, [rsp+0xD0]
00007e55d47df092  vmovaps xmm15, [rsp+0xE0]
00007e55d47df09b  add rsp, 0xF0
00007e55d47df0a2  pop r11
00007e55d47df0a4  pop r10
00007e55d47df0a6  pop r9
00007e55d47df0a8  pop r8
00007e55d47df0aa  pop rsi
00007e55d47df0ab  pop rdi
00007e55d47df0ac  pop rdx
00007e55d47df0ad  pop rcx
00007e55d47df0ae  pop rax
00007e55d47df0af  add rsp, 0x08
00007e55d47df0b3  jmp 0x00007E55D47DC354
00007e55d47df0b8  sub rsp, 0x08
00007e55d47df0bc  push rax
00007e55d47df0bd  push rcx
00007e55d47df0be  push rdx
00007e55d47df0bf  push rdi
00007e55d47df0c0  push rsi
00007e55d47df0c1  push r8
00007e55d47df0c3  push r9
00007e55d47df0c5  push r10
00007e55d47df0c7  push r11
00007e55d47df0c9  sub rsp, 0xF0
00007e55d47df0d0  vmovaps [rsp], xmm0
00007e55d47df0d5  vmovaps [rsp+0x10], xmm2
00007e55d47df0db  vmovaps [rsp+0x20], xmm3
00007e55d47df0e1  vmovaps [rsp+0x30], xmm4
00007e55d47df0e7  vmovaps [rsp+0x40], xmm5
00007e55d47df0ed  vmovaps [rsp+0x50], xmm6
00007e55d47df0f3  vmovaps [rsp+0x60], xmm7
00007e55d47df0f9  vmovaps [rsp+0x70], xmm8
00007e55d47df0ff  vmovaps [rsp+0x80], xmm9
00007e55d47df108  vmovaps [rsp+0x90], xmm10
00007e55d47df111  vmovaps [rsp+0xA0], xmm11
00007e55d47df11a  vmovaps [rsp+0xB0], xmm12
00007e55d47df123  vmovaps [rsp+0xC0], xmm13
00007e55d47df12c  vmovaps [rsp+0xD0], xmm14
00007e55d47df135  vmovaps [rsp+0xE0], xmm15
00007e55d47df13e  sub rsp, 0x30
00007e55d47df142  movaps [rsp], xmm1
00007e55d47df146  movaps [rsp+0x10], xmm15
00007e55d47df14c  movaps [rsp+0x20], xmm6
00007e55d47df151  lea rdi, [rsp]
00007e55d47df155  mov esi, 0x00
00007e55d47df15a  mov rax, 0x55D0734A4530
00007e55d47df164  call rax
00007e55d47df166  movaps xmm1, [rsp]
00007e55d47df16a  add rsp, 0x30
00007e55d47df16e  vmovaps xmm0, [rsp]
00007e55d47df173  vmovaps xmm2, [rsp+0x10]
00007e55d47df179  vmovaps xmm3, [rsp+0x20]
00007e55d47df17f  vmovaps xmm4, [rsp+0x30]
00007e55d47df185  vmovaps xmm5, [rsp+0x40]
00007e55d47df18b  vmovaps xmm6, [rsp+0x50]
00007e55d47df191  vmovaps xmm7, [rsp+0x60]
00007e55d47df197  vmovaps xmm8, [rsp+0x70]
00007e55d47df19d  vmovaps xmm9, [rsp+0x80]
00007e55d47df1a6  vmovaps xmm10, [rsp+0x90]
00007e55d47df1af  vmovaps xmm11, [rsp+0xA0]
00007e55d47df1b8  vmovaps xmm12, [rsp+0xB0]
00007e55d47df1c1  vmovaps xmm13, [rsp+0xC0]
00007e55d47df1ca  vmovaps xmm14, [rsp+0xD0]
00007e55d47df1d3  vmovaps xmm15, [rsp+0xE0]
00007e55d47df1dc  add rsp, 0xF0
00007e55d47df1e3  pop r11
00007e55d47df1e5  pop r10
00007e55d47df1e7  pop r9
00007e55d47df1e9  pop r8
00007e55d47df1eb  pop rsi
00007e55d47df1ec  pop rdi
00007e55d47df1ed  pop rdx
00007e55d47df1ee  pop rcx
00007e55d47df1ef  pop rax
00007e55d47df1f0  add rsp, 0x08
00007e55d47df1f4  jmp 0x00007E55D47DC375
00007e55d47df1f9  sub rsp, 0x08
00007e55d47df1fd  push rax
00007e55d47df1fe  push rcx
00007e55d47df1ff  push rdx
00007e55d47df200  push rdi
00007e55d47df201  push rsi
00007e55d47df202  push r8
00007e55d47df204  push r9
00007e55d47df206  push r10
00007e55d47df208  push r11
00007e55d47df20a  sub rsp, 0xF0
00007e55d47df211  vmovaps [rsp], xmm0
00007e55d47df216  vmovaps [rsp+0x10], xmm1
00007e55d47df21c  vmovaps [rsp+0x20], xmm2
00007e55d47df222  vmovaps [rsp+0x30], xmm3
00007e55d47df228  vmovaps [rsp+0x40], xmm4
00007e55d47df22e  vmovaps [rsp+0x50], xmm5
00007e55d47df234  vmovaps [rsp+0x60], xmm6
00007e55d47df23a  vmovaps [rsp+0x70], xmm7
00007e55d47df240  vmovaps [rsp+0x80], xmm8
00007e55d47df249  vmovaps [rsp+0x90], xmm9
00007e55d47df252  vmovaps [rsp+0xA0], xmm10
00007e55d47df25b  vmovaps [rsp+0xB0], xmm11
00007e55d47df264  vmovaps [rsp+0xC0], xmm12
00007e55d47df26d  vmovaps [rsp+0xD0], xmm13
00007e55d47df276  vmovaps [rsp+0xE0], xmm14
00007e55d47df27f  sub rsp, 0x30
00007e55d47df283  movaps [rsp], xmm15
00007e55d47df288  movaps [rsp+0x10], xmm5
00007e55d47df28d  movaps [rsp+0x20], xmm3
00007e55d47df292  lea rdi, [rsp]
00007e55d47df296  mov esi, 0x00
00007e55d47df29b  mov rax, 0x55D0734A4530
00007e55d47df2a5  call rax
00007e55d47df2a7  movaps xmm15, [rsp]
00007e55d47df2ac  add rsp, 0x30
00007e55d47df2b0  vmovaps xmm0, [rsp]
00007e55d47df2b5  vmovaps xmm1, [rsp+0x10]
00007e55d47df2bb  vmovaps xmm2, [rsp+0x20]
00007e55d47df2c1  vmovaps xmm3, [rsp+0x30]
00007e55d47df2c7  vmovaps xmm4, [rsp+0x40]
00007e55d47df2cd  vmovaps xmm5, [rsp+0x50]
00007e55d47df2d3  vmovaps xmm6, [rsp+0x60]
00007e55d47df2d9  vmovaps xmm7, [rsp+0x70]
00007e55d47df2df  vmovaps xmm8, [rsp+0x80]
00007e55d47df2e8  vmovaps xmm9, [rsp+0x90]
00007e55d47df2f1  vmovaps xmm10, [rsp+0xA0]
00007e55d47df2fa  vmovaps xmm11, [rsp+0xB0]
00007e55d47df303  vmovaps xmm12, [rsp+0xC0]
00007e55d47df30c  vmovaps xmm13, [rsp+0xD0]
00007e55d47df315  vmovaps xmm14, [rsp+0xE0]
00007e55d47df31e  add rsp, 0xF0
00007e55d47df325  pop r11
00007e55d47df327  pop r10
00007e55d47df329  pop r9
00007e55d47df32b  pop r8
00007e55d47df32d  pop rsi
00007e55d47df32e  pop rdi
00007e55d47df32f  pop rdx
00007e55d47df330  pop rcx
00007e55d47df331  pop rax
00007e55d47df332  add rsp, 0x08
00007e55d47df336  jmp 0x00007E55D47DC38F
00007e55d47df33b  sub rsp, 0x08
00007e55d47df33f  push rax
00007e55d47df340  push rcx
00007e55d47df341  push rdx
00007e55d47df342  push rdi
00007e55d47df343  push rsi
00007e55d47df344  push r8
00007e55d47df346  push r9
00007e55d47df348  push r10
00007e55d47df34a  push r11
00007e55d47df34c  sub rsp, 0xF0
00007e55d47df353  vmovaps [rsp], xmm0
00007e55d47df358  vmovaps [rsp+0x10], xmm1
00007e55d47df35e  vmovaps [rsp+0x20], xmm2
00007e55d47df364  vmovaps [rsp+0x30], xmm3
00007e55d47df36a  vmovaps [rsp+0x40], xmm4
00007e55d47df370  vmovaps [rsp+0x50], xmm6
00007e55d47df376  vmovaps [rsp+0x60], xmm7
00007e55d47df37c  vmovaps [rsp+0x70], xmm8
00007e55d47df382  vmovaps [rsp+0x80], xmm9
00007e55d47df38b  vmovaps [rsp+0x90], xmm10
00007e55d47df394  vmovaps [rsp+0xA0], xmm11
00007e55d47df39d  vmovaps [rsp+0xB0], xmm12
00007e55d47df3a6  vmovaps [rsp+0xC0], xmm13
00007e55d47df3af  vmovaps [rsp+0xD0], xmm14
00007e55d47df3b8  vmovaps [rsp+0xE0], xmm15
00007e55d47df3c1  sub rsp, 0x30
00007e55d47df3c5  movaps [rsp], xmm5
00007e55d47df3c9  movaps [rsp+0x10], xmm8
00007e55d47df3cf  movaps [rsp+0x20], xmm6
00007e55d47df3d4  lea rdi, [rsp]
00007e55d47df3d8  mov esi, 0x00
00007e55d47df3dd  mov rax, 0x55D0734A4530
00007e55d47df3e7  call rax
00007e55d47df3e9  movaps xmm5, [rsp]
00007e55d47df3ed  add rsp, 0x30
00007e55d47df3f1  vmovaps xmm0, [rsp]
00007e55d47df3f6  vmovaps xmm1, [rsp+0x10]
00007e55d47df3fc  vmovaps xmm2, [rsp+0x20]
00007e55d47df402  vmovaps xmm3, [rsp+0x30]
00007e55d47df408  vmovaps xmm4, [rsp+0x40]
00007e55d47df40e  vmovaps xmm6, [rsp+0x50]
00007e55d47df414  vmovaps xmm7, [rsp+0x60]
00007e55d47df41a  vmovaps xmm8, [rsp+0x70]
00007e55d47df420  vmovaps xmm9, [rsp+0x80]
00007e55d47df429  vmovaps xmm10, [rsp+0x90]
00007e55d47df432  vmovaps xmm11, [rsp+0xA0]
00007e55d47df43b  vmovaps xmm12, [rsp+0xB0]
00007e55d47df444  vmovaps xmm13, [rsp+0xC0]
00007e55d47df44d  vmovaps xmm14, [rsp+0xD0]
00007e55d47df456  vmovaps xmm15, [rsp+0xE0]
00007e55d47df45f  add rsp, 0xF0
00007e55d47df466  pop r11
00007e55d47df468  pop r10
00007e55d47df46a  pop r9
00007e55d47df46c  pop r8
00007e55d47df46e  pop rsi
00007e55d47df46f  pop rdi
00007e55d47df470  pop rdx
00007e55d47df471  pop rcx
00007e55d47df472  pop rax
00007e55d47df473  add rsp, 0x08
00007e55d47df477  jmp 0x00007E55D47DC3B3
00007e55d47df47c  sub rsp, 0x08
00007e55d47df480  push rax
00007e55d47df481  push rcx
00007e55d47df482  push rdx
00007e55d47df483  push rdi
00007e55d47df484  push rsi
00007e55d47df485  push r8
00007e55d47df487  push r9
00007e55d47df489  push r10
00007e55d47df48b  push r11
00007e55d47df48d  sub rsp, 0xF0
00007e55d47df494  vmovaps [rsp], xmm0
00007e55d47df499  vmovaps [rsp+0x10], xmm1
00007e55d47df49f  vmovaps [rsp+0x20], xmm2
00007e55d47df4a5  vmovaps [rsp+0x30], xmm3
00007e55d47df4ab  vmovaps [rsp+0x40], xmm4
00007e55d47df4b1  vmovaps [rsp+0x50], xmm5
00007e55d47df4b7  vmovaps [rsp+0x60], xmm7
00007e55d47df4bd  vmovaps [rsp+0x70], xmm8
00007e55d47df4c3  vmovaps [rsp+0x80], xmm9
00007e55d47df4cc  vmovaps [rsp+0x90], xmm10
00007e55d47df4d5  vmovaps [rsp+0xA0], xmm11
00007e55d47df4de  vmovaps [rsp+0xB0], xmm12
00007e55d47df4e7  vmovaps [rsp+0xC0], xmm13
00007e55d47df4f0  vmovaps [rsp+0xD0], xmm14
00007e55d47df4f9  vmovaps [rsp+0xE0], xmm15
00007e55d47df502  sub rsp, 0x30
00007e55d47df506  movaps [rsp], xmm6
00007e55d47df50a  movaps [rsp+0x10], xmm10
00007e55d47df510  movaps [rsp+0x20], xmm8
00007e55d47df516  lea rdi, [rsp]
00007e55d47df51a  mov esi, 0x00
00007e55d47df51f  mov rax, 0x55D0734A4530
00007e55d47df529  call rax
00007e55d47df52b  movaps xmm6, [rsp]
00007e55d47df52f  add rsp, 0x30
00007e55d47df533  vmovaps xmm0, [rsp]
00007e55d47df538  vmovaps xmm1, [rsp+0x10]
00007e55d47df53e  vmovaps xmm2, [rsp+0x20]
00007e55d47df544  vmovaps xmm3, [rsp+0x30]
00007e55d47df54a  vmovaps xmm4, [rsp+0x40]
00007e55d47df550  vmovaps xmm5, [rsp+0x50]
00007e55d47df556  vmovaps xmm7, [rsp+0x60]
00007e55d47df55c  vmovaps xmm8, [rsp+0x70]
00007e55d47df562  vmovaps xmm9, [rsp+0x80]
00007e55d47df56b  vmovaps xmm10, [rsp+0x90]
00007e55d47df574  vmovaps xmm11, [rsp+0xA0]
00007e55d47df57d  vmovaps xmm12, [rsp+0xB0]
00007e55d47df586  vmovaps xmm13, [rsp+0xC0]
00007e55d47df58f  vmovaps xmm14, [rsp+0xD0]
00007e55d47df598  vmovaps xmm15, [rsp+0xE0]
00007e55d47df5a1  add rsp, 0xF0
00007e55d47df5a8  pop r11
00007e55d47df5aa  pop r10
00007e55d47df5ac  pop r9
00007e55d47df5ae  pop r8
00007e55d47df5b0  pop rsi
00007e55d47df5b1  pop rdi
00007e55d47df5b2  pop rdx
00007e55d47df5b3  pop rcx
00007e55d47df5b4  pop rax
00007e55d47df5b5  add rsp, 0x08
00007e55d47df5b9  jmp 0x00007E55D47DC3D8
00007e55d47df5be  sub rsp, 0x08
00007e55d47df5c2  push rax
00007e55d47df5c3  push rcx
00007e55d47df5c4  push rdx
00007e55d47df5c5  push rdi
00007e55d47df5c6  push rsi
00007e55d47df5c7  push r8
00007e55d47df5c9  push r9
00007e55d47df5cb  push r10
00007e55d47df5cd  push r11
00007e55d47df5cf  sub rsp, 0xF0
00007e55d47df5d6  vmovaps [rsp], xmm0
00007e55d47df5db  vmovaps [rsp+0x10], xmm1
00007e55d47df5e1  vmovaps [rsp+0x20], xmm2
00007e55d47df5e7  vmovaps [rsp+0x30], xmm3
00007e55d47df5ed  vmovaps [rsp+0x40], xmm4
00007e55d47df5f3  vmovaps [rsp+0x50], xmm5
00007e55d47df5f9  vmovaps [rsp+0x60], xmm6
00007e55d47df5ff  vmovaps [rsp+0x70], xmm7
00007e55d47df605  vmovaps [rsp+0x80], xmm8
00007e55d47df60e  vmovaps [rsp+0x90], xmm9
00007e55d47df617  vmovaps [rsp+0xA0], xmm11
00007e55d47df620  vmovaps [rsp+0xB0], xmm12
00007e55d47df629  vmovaps [rsp+0xC0], xmm13
00007e55d47df632  vmovaps [rsp+0xD0], xmm14
00007e55d47df63b  vmovaps [rsp+0xE0], xmm15
00007e55d47df644  sub rsp, 0x30
00007e55d47df648  movaps [rsp], xmm10
00007e55d47df64d  movaps [rsp+0x10], xmm8
00007e55d47df653  movaps [rsp+0x20], xmm14
00007e55d47df659  lea rdi, [rsp]
00007e55d47df65d  mov esi, 0x00
00007e55d47df662  mov rax, 0x55D0734A4530
00007e55d47df66c  call rax
00007e55d47df66e  movaps xmm10, [rsp]
00007e55d47df673  add rsp, 0x30
00007e55d47df677  vmovaps xmm0, [rsp]
00007e55d47df67c  vmovaps xmm1, [rsp+0x10]
00007e55d47df682  vmovaps xmm2, [rsp+0x20]
00007e55d47df688  vmovaps xmm3, [rsp+0x30]
00007e55d47df68e  vmovaps xmm4, [rsp+0x40]
00007e55d47df694  vmovaps xmm5, [rsp+0x50]
00007e55d47df69a  vmovaps xmm6, [rsp+0x60]
00007e55d47df6a0  vmovaps xmm7, [rsp+0x70]
00007e55d47df6a6  vmovaps xmm8, [rsp+0x80]
00007e55d47df6af  vmovaps xmm9, [rsp+0x90]
00007e55d47df6b8  vmovaps xmm11, [rsp+0xA0]
00007e55d47df6c1  vmovaps xmm12, [rsp+0xB0]
00007e55d47df6ca  vmovaps xmm13, [rsp+0xC0]
00007e55d47df6d3  vmovaps xmm14, [rsp+0xD0]
00007e55d47df6dc  vmovaps xmm15, [rsp+0xE0]
00007e55d47df6e5  add rsp, 0xF0
00007e55d47df6ec  pop r11
00007e55d47df6ee  pop r10
00007e55d47df6f0  pop r9
00007e55d47df6f2  pop r8
00007e55d47df6f4  pop rsi
00007e55d47df6f5  pop rdi
00007e55d47df6f6  pop rdx
00007e55d47df6f7  pop rcx
00007e55d47df6f8  pop rax
00007e55d47df6f9  add rsp, 0x08
00007e55d47df6fd  jmp 0x00007E55D47DC3F8
00007e55d47df702  sub rsp, 0x08
00007e55d47df706  push rax
00007e55d47df707  push rcx
00007e55d47df708  push rdx
00007e55d47df709  push rdi
00007e55d47df70a  push rsi
00007e55d47df70b  push r8
00007e55d47df70d  push r9
00007e55d47df70f  push r10
00007e55d47df711  push r11
00007e55d47df713  sub rsp, 0xF0
00007e55d47df71a  vmovaps [rsp], xmm0
00007e55d47df71f  vmovaps [rsp+0x10], xmm1
00007e55d47df725  vmovaps [rsp+0x20], xmm2
00007e55d47df72b  vmovaps [rsp+0x30], xmm3
00007e55d47df731  vmovaps [rsp+0x40], xmm4
00007e55d47df737  vmovaps [rsp+0x50], xmm5
00007e55d47df73d  vmovaps [rsp+0x60], xmm6
00007e55d47df743  vmovaps [rsp+0x70], xmm7
00007e55d47df749  vmovaps [rsp+0x80], xmm8
00007e55d47df752  vmovaps [rsp+0x90], xmm9
00007e55d47df75b  vmovaps [rsp+0xA0], xmm10
00007e55d47df764  vmovaps [rsp+0xB0], xmm11
00007e55d47df76d  vmovaps [rsp+0xC0], xmm12
00007e55d47df776  vmovaps [rsp+0xD0], xmm13
00007e55d47df77f  vmovaps [rsp+0xE0], xmm15
00007e55d47df788  sub rsp, 0x30
00007e55d47df78c  movaps [rsp], xmm14
00007e55d47df791  movaps [rsp+0x10], xmm8
00007e55d47df797  movaps [rsp+0x20], xmm4
00007e55d47df79c  lea rdi, [rsp]
00007e55d47df7a0  mov esi, 0x00
00007e55d47df7a5  mov rax, 0x55D0734A4530
00007e55d47df7af  call rax
00007e55d47df7b1  movaps xmm14, [rsp]
00007e55d47df7b6  add rsp, 0x30
00007e55d47df7ba  vmovaps xmm0, [rsp]
00007e55d47df7bf  vmovaps xmm1, [rsp+0x10]
00007e55d47df7c5  vmovaps xmm2, [rsp+0x20]
00007e55d47df7cb  vmovaps xmm3, [rsp+0x30]
00007e55d47df7d1  vmovaps xmm4, [rsp+0x40]
00007e55d47df7d7  vmovaps xmm5, [rsp+0x50]
00007e55d47df7dd  vmovaps xmm6, [rsp+0x60]
00007e55d47df7e3  vmovaps xmm7, [rsp+0x70]
00007e55d47df7e9  vmovaps xmm8, [rsp+0x80]
00007e55d47df7f2  vmovaps xmm9, [rsp+0x90]
00007e55d47df7fb  vmovaps xmm10, [rsp+0xA0]
00007e55d47df804  vmovaps xmm11, [rsp+0xB0]
00007e55d47df80d  vmovaps xmm12, [rsp+0xC0]
00007e55d47df816  vmovaps xmm13, [rsp+0xD0]
00007e55d47df81f  vmovaps xmm15, [rsp+0xE0]
00007e55d47df828  add rsp, 0xF0
00007e55d47df82f  pop r11
00007e55d47df831  pop r10
00007e55d47df833  pop r9
00007e55d47df835  pop r8
00007e55d47df837  pop rsi
00007e55d47df838  pop rdi
00007e55d47df839  pop rdx
00007e55d47df83a  pop rcx
00007e55d47df83b  pop rax
00007e55d47df83c  add rsp, 0x08
00007e55d47df840  jmp 0x00007E55D47DC418
00007e55d47df845  sub rsp, 0x08
00007e55d47df849  push rax
00007e55d47df84a  push rcx
00007e55d47df84b  push rdx
00007e55d47df84c  push rdi
00007e55d47df84d  push rsi
00007e55d47df84e  push r8
00007e55d47df850  push r9
00007e55d47df852  push r10
00007e55d47df854  push r11
00007e55d47df856  sub rsp, 0xF0
00007e55d47df85d  vmovaps [rsp], xmm0
00007e55d47df862  vmovaps [rsp+0x10], xmm1
00007e55d47df868  vmovaps [rsp+0x20], xmm2
00007e55d47df86e  vmovaps [rsp+0x30], xmm3
00007e55d47df874  vmovaps [rsp+0x40], xmm5
00007e55d47df87a  vmovaps [rsp+0x50], xmm6
00007e55d47df880  vmovaps [rsp+0x60], xmm7
00007e55d47df886  vmovaps [rsp+0x70], xmm8
00007e55d47df88c  vmovaps [rsp+0x80], xmm9
00007e55d47df895  vmovaps [rsp+0x90], xmm10
00007e55d47df89e  vmovaps [rsp+0xA0], xmm11
00007e55d47df8a7  vmovaps [rsp+0xB0], xmm12
00007e55d47df8b0  vmovaps [rsp+0xC0], xmm13
00007e55d47df8b9  vmovaps [rsp+0xD0], xmm14
00007e55d47df8c2  vmovaps [rsp+0xE0], xmm15
00007e55d47df8cb  sub rsp, 0x30
00007e55d47df8cf  movaps [rsp], xmm4
00007e55d47df8d3  movaps [rsp+0x10], xmm13
00007e55d47df8d9  movaps [rsp+0x20], xmm8
00007e55d47df8df  lea rdi, [rsp]
00007e55d47df8e3  mov esi, 0x00
00007e55d47df8e8  mov rax, 0x55D0734A4530
00007e55d47df8f2  call rax
00007e55d47df8f4  movaps xmm4, [rsp]
00007e55d47df8f8  add rsp, 0x30
00007e55d47df8fc  vmovaps xmm0, [rsp]
00007e55d47df901  vmovaps xmm1, [rsp+0x10]
00007e55d47df907  vmovaps xmm2, [rsp+0x20]
00007e55d47df90d  vmovaps xmm3, [rsp+0x30]
00007e55d47df913  vmovaps xmm5, [rsp+0x40]
00007e55d47df919  vmovaps xmm6, [rsp+0x50]
00007e55d47df91f  vmovaps xmm7, [rsp+0x60]
00007e55d47df925  vmovaps xmm8, [rsp+0x70]
00007e55d47df92b  vmovaps xmm9, [rsp+0x80]
00007e55d47df934  vmovaps xmm10, [rsp+0x90]
00007e55d47df93d  vmovaps xmm11, [rsp+0xA0]
00007e55d47df946  vmovaps xmm12, [rsp+0xB0]
00007e55d47df94f  vmovaps xmm13, [rsp+0xC0]
00007e55d47df958  vmovaps xmm14, [rsp+0xD0]
00007e55d47df961  vmovaps xmm15, [rsp+0xE0]
00007e55d47df96a  add rsp, 0xF0
00007e55d47df971  pop r11
00007e55d47df973  pop r10
00007e55d47df975  pop r9
00007e55d47df977  pop r8
00007e55d47df979  pop rsi
00007e55d47df97a  pop rdi
00007e55d47df97b  pop rdx
00007e55d47df97c  pop rcx
00007e55d47df97d  pop rax
00007e55d47df97e  add rsp, 0x08
00007e55d47df982  jmp 0x00007E55D47DC43D
00007e55d47df987  sub rsp, 0x08
00007e55d47df98b  push rax
00007e55d47df98c  push rcx
00007e55d47df98d  push rdx
00007e55d47df98e  push rdi
00007e55d47df98f  push rsi
00007e55d47df990  push r8
00007e55d47df992  push r9
00007e55d47df994  push r10
00007e55d47df996  push r11
00007e55d47df998  sub rsp, 0xF0
00007e55d47df99f  vmovaps [rsp], xmm0
00007e55d47df9a4  vmovaps [rsp+0x10], xmm1
00007e55d47df9aa  vmovaps [rsp+0x20], xmm2
00007e55d47df9b0  vmovaps [rsp+0x30], xmm3
00007e55d47df9b6  vmovaps [rsp+0x40], xmm4
00007e55d47df9bc  vmovaps [rsp+0x50], xmm5
00007e55d47df9c2  vmovaps [rsp+0x60], xmm6
00007e55d47df9c8  vmovaps [rsp+0x70], xmm7
00007e55d47df9ce  vmovaps [rsp+0x80], xmm8
00007e55d47df9d7  vmovaps [rsp+0x90], xmm9
00007e55d47df9e0  vmovaps [rsp+0xA0], xmm10
00007e55d47df9e9  vmovaps [rsp+0xB0], xmm11
00007e55d47df9f2  vmovaps [rsp+0xC0], xmm12
00007e55d47df9fb  vmovaps [rsp+0xD0], xmm14
00007e55d47dfa04  vmovaps [rsp+0xE0], xmm15
00007e55d47dfa0d  sub rsp, 0x30
00007e55d47dfa11  movaps [rsp], xmm13
00007e55d47dfa16  movaps [rsp+0x10], xmm15
00007e55d47dfa1c  movaps [rsp+0x20], xmm9
00007e55d47dfa22  lea rdi, [rsp]
00007e55d47dfa26  mov esi, 0x00
00007e55d47dfa2b  mov rax, 0x55D0734A4530
00007e55d47dfa35  call rax
00007e55d47dfa37  movaps xmm13, [rsp]
00007e55d47dfa3c  add rsp, 0x30
00007e55d47dfa40  vmovaps xmm0, [rsp]
00007e55d47dfa45  vmovaps xmm1, [rsp+0x10]
00007e55d47dfa4b  vmovaps xmm2, [rsp+0x20]
00007e55d47dfa51  vmovaps xmm3, [rsp+0x30]
00007e55d47dfa57  vmovaps xmm4, [rsp+0x40]
00007e55d47dfa5d  vmovaps xmm5, [rsp+0x50]
00007e55d47dfa63  vmovaps xmm6, [rsp+0x60]
00007e55d47dfa69  vmovaps xmm7, [rsp+0x70]
00007e55d47dfa6f  vmovaps xmm8, [rsp+0x80]
00007e55d47dfa78  vmovaps xmm9, [rsp+0x90]
00007e55d47dfa81  vmovaps xmm10, [rsp+0xA0]
00007e55d47dfa8a  vmovaps xmm11, [rsp+0xB0]
00007e55d47dfa93  vmovaps xmm12, [rsp+0xC0]
00007e55d47dfa9c  vmovaps xmm14, [rsp+0xD0]
00007e55d47dfaa5  vmovaps xmm15, [rsp+0xE0]
00007e55d47dfaae  add rsp, 0xF0
00007e55d47dfab5  pop r11
00007e55d47dfab7  pop r10
00007e55d47dfab9  pop r9
00007e55d47dfabb  pop r8
00007e55d47dfabd  pop rsi
00007e55d47dfabe  pop rdi
00007e55d47dfabf  pop rdx
00007e55d47dfac0  pop rcx
00007e55d47dfac1  pop rax
00007e55d47dfac2  add rsp, 0x08
00007e55d47dfac6  jmp 0x00007E55D47DC458
00007e55d47dfacb  sub rsp, 0x08
00007e55d47dfacf  push rax
00007e55d47dfad0  push rcx
00007e55d47dfad1  push rdx
00007e55d47dfad2  push rdi
00007e55d47dfad3  push rsi
00007e55d47dfad4  push r8
00007e55d47dfad6  push r9
00007e55d47dfad8  push r10
00007e55d47dfada  push r11
00007e55d47dfadc  sub rsp, 0xF0
00007e55d47dfae3  vmovaps [rsp], xmm0
00007e55d47dfae8  vmovaps [rsp+0x10], xmm1
00007e55d47dfaee  vmovaps [rsp+0x20], xmm2
00007e55d47dfaf4  vmovaps [rsp+0x30], xmm3
00007e55d47dfafa  vmovaps [rsp+0x40], xmm4
00007e55d47dfb00  vmovaps [rsp+0x50], xmm5
00007e55d47dfb06  vmovaps [rsp+0x60], xmm6
00007e55d47dfb0c  vmovaps [rsp+0x70], xmm7
00007e55d47dfb12  vmovaps [rsp+0x80], xmm8
00007e55d47dfb1b  vmovaps [rsp+0x90], xmm9
00007e55d47dfb24  vmovaps [rsp+0xA0], xmm10
00007e55d47dfb2d  vmovaps [rsp+0xB0], xmm11
00007e55d47dfb36  vmovaps [rsp+0xC0], xmm12
00007e55d47dfb3f  vmovaps [rsp+0xD0], xmm13
00007e55d47dfb48  vmovaps [rsp+0xE0], xmm14
00007e55d47dfb51  sub rsp, 0x30
00007e55d47dfb55  movaps [rsp], xmm15
00007e55d47dfb5a  movaps [rsp+0x10], xmm1
00007e55d47dfb5f  movaps [rsp+0x20], xmm5
00007e55d47dfb64  lea rdi, [rsp]
00007e55d47dfb68  mov esi, 0x00
00007e55d47dfb6d  mov rax, 0x55D0734A4530
00007e55d47dfb77  call rax
00007e55d47dfb79  movaps xmm15, [rsp]
00007e55d47dfb7e  add rsp, 0x30
00007e55d47dfb82  vmovaps xmm0, [rsp]
00007e55d47dfb87  vmovaps xmm1, [rsp+0x10]
00007e55d47dfb8d  vmovaps xmm2, [rsp+0x20]
00007e55d47dfb93  vmovaps xmm3, [rsp+0x30]
00007e55d47dfb99  vmovaps xmm4, [rsp+0x40]
00007e55d47dfb9f  vmovaps xmm5, [rsp+0x50]
00007e55d47dfba5  vmovaps xmm6, [rsp+0x60]
00007e55d47dfbab  vmovaps xmm7, [rsp+0x70]
00007e55d47dfbb1  vmovaps xmm8, [rsp+0x80]
00007e55d47dfbba  vmovaps xmm9, [rsp+0x90]
00007e55d47dfbc3  vmovaps xmm10, [rsp+0xA0]
00007e55d47dfbcc  vmovaps xmm11, [rsp+0xB0]
00007e55d47dfbd5  vmovaps xmm12, [rsp+0xC0]
00007e55d47dfbde  vmovaps xmm13, [rsp+0xD0]
00007e55d47dfbe7  vmovaps xmm14, [rsp+0xE0]
00007e55d47dfbf0  add rsp, 0xF0
00007e55d47dfbf7  pop r11
00007e55d47dfbf9  pop r10
00007e55d47dfbfb  pop r9
00007e55d47dfbfd  pop r8
00007e55d47dfbff  pop rsi
00007e55d47dfc00  pop rdi
00007e55d47dfc01  pop rdx
00007e55d47dfc02  pop rcx
00007e55d47dfc03  pop rax
00007e55d47dfc04  add rsp, 0x08
00007e55d47dfc08  jmp 0x00007E55D47DC473
00007e55d47dfc0d  call 0x00007E55D46B52F0
00007e55d47dfc12  jmp 0x00007E55D47DC4CE
00007e55d47dfc17  sub rsp, 0x08
00007e55d47dfc1b  push rax
00007e55d47dfc1c  push rcx
00007e55d47dfc1d  push rdx
00007e55d47dfc1e  push rdi
00007e55d47dfc1f  push rsi
00007e55d47dfc20  push r8
00007e55d47dfc22  push r9
00007e55d47dfc24  push r10
00007e55d47dfc26  push r11
00007e55d47dfc28  sub rsp, 0xF0
00007e55d47dfc2f  vmovaps [rsp], xmm0
00007e55d47dfc34  vmovaps [rsp+0x10], xmm1
00007e55d47dfc3a  vmovaps [rsp+0x20], xmm2
00007e55d47dfc40  vmovaps [rsp+0x30], xmm3
00007e55d47dfc46  vmovaps [rsp+0x40], xmm4
00007e55d47dfc4c  vmovaps [rsp+0x50], xmm5
00007e55d47dfc52  vmovaps [rsp+0x60], xmm6
00007e55d47dfc58  vmovaps [rsp+0x70], xmm7
00007e55d47dfc5e  vmovaps [rsp+0x80], xmm8
00007e55d47dfc67  vmovaps [rsp+0x90], xmm10
00007e55d47dfc70  vmovaps [rsp+0xA0], xmm11
00007e55d47dfc79  vmovaps [rsp+0xB0], xmm12
00007e55d47dfc82  vmovaps [rsp+0xC0], xmm13
00007e55d47dfc8b  vmovaps [rsp+0xD0], xmm14
00007e55d47dfc94  vmovaps [rsp+0xE0], xmm15
00007e55d47dfc9d  sub rsp, 0x30
00007e55d47dfca1  movaps [rsp], xmm9
00007e55d47dfca6  movaps [rsp+0x10], xmm8
00007e55d47dfcac  movaps [rsp+0x20], xmm11
00007e55d47dfcb2  lea rdi, [rsp]
00007e55d47dfcb6  mov esi, 0x00
00007e55d47dfcbb  mov rax, 0x55D0734A4530
00007e55d47dfcc5  call rax
00007e55d47dfcc7  movaps xmm9, [rsp]
00007e55d47dfccc  add rsp, 0x30
00007e55d47dfcd0  vmovaps xmm0, [rsp]
00007e55d47dfcd5  vmovaps xmm1, [rsp+0x10]
00007e55d47dfcdb  vmovaps xmm2, [rsp+0x20]
00007e55d47dfce1  vmovaps xmm3, [rsp+0x30]
00007e55d47dfce7  vmovaps xmm4, [rsp+0x40]
00007e55d47dfced  vmovaps xmm5, [rsp+0x50]
00007e55d47dfcf3  vmovaps xmm6, [rsp+0x60]
00007e55d47dfcf9  vmovaps xmm7, [rsp+0x70]
00007e55d47dfcff  vmovaps xmm8, [rsp+0x80]
00007e55d47dfd08  vmovaps xmm10, [rsp+0x90]
00007e55d47dfd11  vmovaps xmm11, [rsp+0xA0]
00007e55d47dfd1a  vmovaps xmm12, [rsp+0xB0]
00007e55d47dfd23  vmovaps xmm13, [rsp+0xC0]
00007e55d47dfd2c  vmovaps xmm14, [rsp+0xD0]
00007e55d47dfd35  vmovaps xmm15, [rsp+0xE0]
00007e55d47dfd3e  add rsp, 0xF0
00007e55d47dfd45  pop r11
00007e55d47dfd47  pop r10
00007e55d47dfd49  pop r9
00007e55d47dfd4b  pop r8
00007e55d47dfd4d  pop rsi
00007e55d47dfd4e  pop rdi
00007e55d47dfd4f  pop rdx
00007e55d47dfd50  pop rcx
00007e55d47dfd51  pop rax
00007e55d47dfd52  add rsp, 0x08
00007e55d47dfd56  jmp 0x00007E55D47DC505
00007e55d47dfd5b  sub rsp, 0x08
00007e55d47dfd5f  push rax
00007e55d47dfd60  push rcx
00007e55d47dfd61  push rdx
00007e55d47dfd62  push rdi
00007e55d47dfd63  push rsi
00007e55d47dfd64  push r8
00007e55d47dfd66  push r9
00007e55d47dfd68  push r10
00007e55d47dfd6a  push r11
00007e55d47dfd6c  sub rsp, 0xF0
00007e55d47dfd73  vmovaps [rsp], xmm0
00007e55d47dfd78  vmovaps [rsp+0x10], xmm1
00007e55d47dfd7e  vmovaps [rsp+0x20], xmm2
00007e55d47dfd84  vmovaps [rsp+0x30], xmm3
00007e55d47dfd8a  vmovaps [rsp+0x40], xmm4
00007e55d47dfd90  vmovaps [rsp+0x50], xmm5
00007e55d47dfd96  vmovaps [rsp+0x60], xmm6
00007e55d47dfd9c  vmovaps [rsp+0x70], xmm7
00007e55d47dfda2  vmovaps [rsp+0x80], xmm8
00007e55d47dfdab  vmovaps [rsp+0x90], xmm9
00007e55d47dfdb4  vmovaps [rsp+0xA0], xmm10
00007e55d47dfdbd  vmovaps [rsp+0xB0], xmm12
00007e55d47dfdc6  vmovaps [rsp+0xC0], xmm13
00007e55d47dfdcf  vmovaps [rsp+0xD0], xmm14
00007e55d47dfdd8  vmovaps [rsp+0xE0], xmm15
00007e55d47dfde1  sub rsp, 0x30
00007e55d47dfde5  movaps [rsp], xmm11
00007e55d47dfdea  movaps [rsp+0x10], xmm10
00007e55d47dfdf0  movaps [rsp+0x20], xmm6
00007e55d47dfdf5  lea rdi, [rsp]
00007e55d47dfdf9  mov esi, 0x00
00007e55d47dfdfe  mov rax, 0x55D0734A4530
00007e55d47dfe08  call rax
00007e55d47dfe0a  movaps xmm11, [rsp]
00007e55d47dfe0f  add rsp, 0x30
00007e55d47dfe13  vmovaps xmm0, [rsp]
00007e55d47dfe18  vmovaps xmm1, [rsp+0x10]
00007e55d47dfe1e  vmovaps xmm2, [rsp+0x20]
00007e55d47dfe24  vmovaps xmm3, [rsp+0x30]
00007e55d47dfe2a  vmovaps xmm4, [rsp+0x40]
00007e55d47dfe30  vmovaps xmm5, [rsp+0x50]
00007e55d47dfe36  vmovaps xmm6, [rsp+0x60]
00007e55d47dfe3c  vmovaps xmm7, [rsp+0x70]
00007e55d47dfe42  vmovaps xmm8, [rsp+0x80]
00007e55d47dfe4b  vmovaps xmm9, [rsp+0x90]
00007e55d47dfe54  vmovaps xmm10, [rsp+0xA0]
00007e55d47dfe5d  vmovaps xmm12, [rsp+0xB0]
00007e55d47dfe66  vmovaps xmm13, [rsp+0xC0]
00007e55d47dfe6f  vmovaps xmm14, [rsp+0xD0]
00007e55d47dfe78  vmovaps xmm15, [rsp+0xE0]
00007e55d47dfe81  add rsp, 0xF0
00007e55d47dfe88  pop r11
00007e55d47dfe8a  pop r10
00007e55d47dfe8c  pop r9
00007e55d47dfe8e  pop r8
00007e55d47dfe90  pop rsi
00007e55d47dfe91  pop rdi
00007e55d47dfe92  pop rdx
00007e55d47dfe93  pop rcx
00007e55d47dfe94  pop rax
00007e55d47dfe95  add rsp, 0x08
00007e55d47dfe99  jmp 0x00007E55D47DC520
00007e55d47dfe9e  sub rsp, 0x08
00007e55d47dfea2  push rax
00007e55d47dfea3  push rcx
00007e55d47dfea4  push rdx
00007e55d47dfea5  push rdi
00007e55d47dfea6  push rsi
00007e55d47dfea7  push r8
00007e55d47dfea9  push r9
00007e55d47dfeab  push r10
00007e55d47dfead  push r11
00007e55d47dfeaf  sub rsp, 0xF0
00007e55d47dfeb6  vmovaps [rsp], xmm0
00007e55d47dfebb  vmovaps [rsp+0x10], xmm1
00007e55d47dfec1  vmovaps [rsp+0x20], xmm2
00007e55d47dfec7  vmovaps [rsp+0x30], xmm3
00007e55d47dfecd  vmovaps [rsp+0x40], xmm4
00007e55d47dfed3  vmovaps [rsp+0x50], xmm5
00007e55d47dfed9  vmovaps [rsp+0x60], xmm6
00007e55d47dfedf  vmovaps [rsp+0x70], xmm7
00007e55d47dfee5  vmovaps [rsp+0x80], xmm8
00007e55d47dfeee  vmovaps [rsp+0x90], xmm9
00007e55d47dfef7  vmovaps [rsp+0xA0], xmm11
00007e55d47dff00  vmovaps [rsp+0xB0], xmm12
00007e55d47dff09  vmovaps [rsp+0xC0], xmm13
00007e55d47dff12  vmovaps [rsp+0xD0], xmm14
00007e55d47dff1b  vmovaps [rsp+0xE0], xmm15
00007e55d47dff24  sub rsp, 0x30
00007e55d47dff28  movaps [rsp], xmm10
00007e55d47dff2d  movaps [rsp+0x10], xmm14
00007e55d47dff33  movaps [rsp+0x20], xmm4
00007e55d47dff38  lea rdi, [rsp]
00007e55d47dff3c  mov esi, 0x00
00007e55d47dff41  mov rax, 0x55D0734A4530
00007e55d47dff4b  call rax
00007e55d47dff4d  movaps xmm10, [rsp]
00007e55d47dff52  add rsp, 0x30
00007e55d47dff56  vmovaps xmm0, [rsp]
00007e55d47dff5b  vmovaps xmm1, [rsp+0x10]
00007e55d47dff61  vmovaps xmm2, [rsp+0x20]
00007e55d47dff67  vmovaps xmm3, [rsp+0x30]
00007e55d47dff6d  vmovaps xmm4, [rsp+0x40]
00007e55d47dff73  vmovaps xmm5, [rsp+0x50]
00007e55d47dff79  vmovaps xmm6, [rsp+0x60]
00007e55d47dff7f  vmovaps xmm7, [rsp+0x70]
00007e55d47dff85  vmovaps xmm8, [rsp+0x80]
00007e55d47dff8e  vmovaps xmm9, [rsp+0x90]
00007e55d47dff97  vmovaps xmm11, [rsp+0xA0]
00007e55d47dffa0  vmovaps xmm12, [rsp+0xB0]
00007e55d47dffa9  vmovaps xmm13, [rsp+0xC0]
00007e55d47dffb2  vmovaps xmm14, [rsp+0xD0]
00007e55d47dffbb  vmovaps xmm15, [rsp+0xE0]
00007e55d47dffc4  add rsp, 0xF0
00007e55d47dffcb  pop r11
00007e55d47dffcd  pop r10
00007e55d47dffcf  pop r9
00007e55d47dffd1  pop r8
00007e55d47dffd3  pop rsi
00007e55d47dffd4  pop rdi
00007e55d47dffd5  pop rdx
00007e55d47dffd6  pop rcx
00007e55d47dffd7  pop rax
00007e55d47dffd8  add rsp, 0x08
00007e55d47dffdc  jmp 0x00007E55D47DC53B
00007e55d47dffe1  sub rsp, 0x08
00007e55d47dffe5  push rax
00007e55d47dffe6  push rcx
00007e55d47dffe7  push rdx
00007e55d47dffe8  push rdi
00007e55d47dffe9  push rsi
00007e55d47dffea  push r8
00007e55d47dffec  push r9
00007e55d47dffee  push r10
00007e55d47dfff0  push r11
00007e55d47dfff2  sub rsp, 0xF0
00007e55d47dfff9  vmovaps [rsp], xmm0
00007e55d47dfffe  vmovaps [rsp+0x10], xmm1
00007e55d47e0004  vmovaps [rsp+0x20], xmm2
00007e55d47e000a  vmovaps [rsp+0x30], xmm3
00007e55d47e0010  vmovaps [rsp+0x40], xmm4
00007e55d47e0016  vmovaps [rsp+0x50], xmm5
00007e55d47e001c  vmovaps [rsp+0x60], xmm6
00007e55d47e0022  vmovaps [rsp+0x70], xmm7
00007e55d47e0028  vmovaps [rsp+0x80], xmm9
00007e55d47e0031  vmovaps [rsp+0x90], xmm10
00007e55d47e003a  vmovaps [rsp+0xA0], xmm11
00007e55d47e0043  vmovaps [rsp+0xB0], xmm12
00007e55d47e004c  vmovaps [rsp+0xC0], xmm13
00007e55d47e0055  vmovaps [rsp+0xD0], xmm14
00007e55d47e005e  vmovaps [rsp+0xE0], xmm15
00007e55d47e0067  sub rsp, 0x30
00007e55d47e006b  movaps [rsp], xmm8
00007e55d47e0070  movaps [rsp+0x10], xmm1
00007e55d47e0075  movaps [rsp+0x20], xmm14
00007e55d47e007b  lea rdi, [rsp]
00007e55d47e007f  mov esi, 0x00
00007e55d47e0084  mov rax, 0x55D0734A4530
00007e55d47e008e  call rax
00007e55d47e0090  movaps xmm8, [rsp]
00007e55d47e0095  add rsp, 0x30
00007e55d47e0099  vmovaps xmm0, [rsp]
00007e55d47e009e  vmovaps xmm1, [rsp+0x10]
00007e55d47e00a4  vmovaps xmm2, [rsp+0x20]
00007e55d47e00aa  vmovaps xmm3, [rsp+0x30]
00007e55d47e00b0  vmovaps xmm4, [rsp+0x40]
00007e55d47e00b6  vmovaps xmm5, [rsp+0x50]
00007e55d47e00bc  vmovaps xmm6, [rsp+0x60]
00007e55d47e00c2  vmovaps xmm7, [rsp+0x70]
00007e55d47e00c8  vmovaps xmm9, [rsp+0x80]
00007e55d47e00d1  vmovaps xmm10, [rsp+0x90]
00007e55d47e00da  vmovaps xmm11, [rsp+0xA0]
00007e55d47e00e3  vmovaps xmm12, [rsp+0xB0]
00007e55d47e00ec  vmovaps xmm13, [rsp+0xC0]
00007e55d47e00f5  vmovaps xmm14, [rsp+0xD0]
00007e55d47e00fe  vmovaps xmm15, [rsp+0xE0]
00007e55d47e0107  add rsp, 0xF0
00007e55d47e010e  pop r11
00007e55d47e0110  pop r10
00007e55d47e0112  pop r9
00007e55d47e0114  pop r8
00007e55d47e0116  pop rsi
00007e55d47e0117  pop rdi
00007e55d47e0118  pop rdx
00007e55d47e0119  pop rcx
00007e55d47e011a  pop rax
00007e55d47e011b  add rsp, 0x08
00007e55d47e011f  jmp 0x00007E55D47DC561
00007e55d47e0124  sub rsp, 0x08
00007e55d47e0128  push rax
00007e55d47e0129  push rcx
00007e55d47e012a  push rdx
00007e55d47e012b  push rdi
00007e55d47e012c  push rsi
00007e55d47e012d  push r8
00007e55d47e012f  push r9
00007e55d47e0131  push r10
00007e55d47e0133  push r11
00007e55d47e0135  sub rsp, 0xF0
00007e55d47e013c  vmovaps [rsp], xmm0
00007e55d47e0141  vmovaps [rsp+0x10], xmm1
00007e55d47e0147  vmovaps [rsp+0x20], xmm2
00007e55d47e014d  vmovaps [rsp+0x30], xmm3
00007e55d47e0153  vmovaps [rsp+0x40], xmm4
00007e55d47e0159  vmovaps [rsp+0x50], xmm5
00007e55d47e015f  vmovaps [rsp+0x60], xmm7
00007e55d47e0165  vmovaps [rsp+0x70], xmm8
00007e55d47e016b  vmovaps [rsp+0x80], xmm9
00007e55d47e0174  vmovaps [rsp+0x90], xmm10
00007e55d47e017d  vmovaps [rsp+0xA0], xmm11
00007e55d47e0186  vmovaps [rsp+0xB0], xmm12
00007e55d47e018f  vmovaps [rsp+0xC0], xmm13
00007e55d47e0198  vmovaps [rsp+0xD0], xmm14
00007e55d47e01a1  vmovaps [rsp+0xE0], xmm15
00007e55d47e01aa  sub rsp, 0x30
00007e55d47e01ae  movaps [rsp], xmm6
00007e55d47e01b2  movaps [rsp+0x10], xmm1
00007e55d47e01b7  movaps [rsp+0x20], xmm14
00007e55d47e01bd  lea rdi, [rsp]
00007e55d47e01c1  mov esi, 0x00
00007e55d47e01c6  mov rax, 0x55D0734A4530
00007e55d47e01d0  call rax
00007e55d47e01d2  movaps xmm6, [rsp]
00007e55d47e01d6  add rsp, 0x30
00007e55d47e01da  vmovaps xmm0, [rsp]
00007e55d47e01df  vmovaps xmm1, [rsp+0x10]
00007e55d47e01e5  vmovaps xmm2, [rsp+0x20]
00007e55d47e01eb  vmovaps xmm3, [rsp+0x30]
00007e55d47e01f1  vmovaps xmm4, [rsp+0x40]
00007e55d47e01f7  vmovaps xmm5, [rsp+0x50]
00007e55d47e01fd  vmovaps xmm7, [rsp+0x60]
00007e55d47e0203  vmovaps xmm8, [rsp+0x70]
00007e55d47e0209  vmovaps xmm9, [rsp+0x80]
00007e55d47e0212  vmovaps xmm10, [rsp+0x90]
00007e55d47e021b  vmovaps xmm11, [rsp+0xA0]
00007e55d47e0224  vmovaps xmm12, [rsp+0xB0]
00007e55d47e022d  vmovaps xmm13, [rsp+0xC0]
00007e55d47e0236  vmovaps xmm14, [rsp+0xD0]
00007e55d47e023f  vmovaps xmm15, [rsp+0xE0]
00007e55d47e0248  add rsp, 0xF0
00007e55d47e024f  pop r11
00007e55d47e0251  pop r10
00007e55d47e0253  pop r9
00007e55d47e0255  pop r8
00007e55d47e0257  pop rsi
00007e55d47e0258  pop rdi
00007e55d47e0259  pop rdx
00007e55d47e025a  pop rcx
00007e55d47e025b  pop rax
00007e55d47e025c  add rsp, 0x08
00007e55d47e0260  jmp 0x00007E55D47DC58D
00007e55d47e0265  sub rsp, 0x08
00007e55d47e0269  push rax
00007e55d47e026a  push rcx
00007e55d47e026b  push rdx
00007e55d47e026c  push rdi
00007e55d47e026d  push rsi
00007e55d47e026e  push r8
00007e55d47e0270  push r9
00007e55d47e0272  push r10
00007e55d47e0274  push r11
00007e55d47e0276  sub rsp, 0xF0
00007e55d47e027d  vmovaps [rsp], xmm0
00007e55d47e0282  vmovaps [rsp+0x10], xmm1
00007e55d47e0288  vmovaps [rsp+0x20], xmm2
00007e55d47e028e  vmovaps [rsp+0x30], xmm3
00007e55d47e0294  vmovaps [rsp+0x40], xmm4
00007e55d47e029a  vmovaps [rsp+0x50], xmm5
00007e55d47e02a0  vmovaps [rsp+0x60], xmm6
00007e55d47e02a6  vmovaps [rsp+0x70], xmm7
00007e55d47e02ac  vmovaps [rsp+0x80], xmm8
00007e55d47e02b5  vmovaps [rsp+0x90], xmm9
00007e55d47e02be  vmovaps [rsp+0xA0], xmm10
00007e55d47e02c7  vmovaps [rsp+0xB0], xmm11
00007e55d47e02d0  vmovaps [rsp+0xC0], xmm12
00007e55d47e02d9  vmovaps [rsp+0xD0], xmm13
00007e55d47e02e2  vmovaps [rsp+0xE0], xmm15
00007e55d47e02eb  sub rsp, 0x30
00007e55d47e02ef  movaps [rsp], xmm14
00007e55d47e02f4  movaps [rsp+0x10], xmm12
00007e55d47e02fa  movaps [rsp+0x20], xmm1
00007e55d47e02ff  lea rdi, [rsp]
00007e55d47e0303  mov esi, 0x00
00007e55d47e0308  mov rax, 0x55D0734A4530
00007e55d47e0312  call rax
00007e55d47e0314  movaps xmm14, [rsp]
00007e55d47e0319  add rsp, 0x30
00007e55d47e031d  vmovaps xmm0, [rsp]
00007e55d47e0322  vmovaps xmm1, [rsp+0x10]
00007e55d47e0328  vmovaps xmm2, [rsp+0x20]
00007e55d47e032e  vmovaps xmm3, [rsp+0x30]
00007e55d47e0334  vmovaps xmm4, [rsp+0x40]
00007e55d47e033a  vmovaps xmm5, [rsp+0x50]
00007e55d47e0340  vmovaps xmm6, [rsp+0x60]
00007e55d47e0346  vmovaps xmm7, [rsp+0x70]
00007e55d47e034c  vmovaps xmm8, [rsp+0x80]
00007e55d47e0355  vmovaps xmm9, [rsp+0x90]
00007e55d47e035e  vmovaps xmm10, [rsp+0xA0]
00007e55d47e0367  vmovaps xmm11, [rsp+0xB0]
00007e55d47e0370  vmovaps xmm12, [rsp+0xC0]
00007e55d47e0379  vmovaps xmm13, [rsp+0xD0]
00007e55d47e0382  vmovaps xmm15, [rsp+0xE0]
00007e55d47e038b  add rsp, 0xF0
00007e55d47e0392  pop r11
00007e55d47e0394  pop r10
00007e55d47e0396  pop r9
00007e55d47e0398  pop r8
00007e55d47e039a  pop rsi
00007e55d47e039b  pop rdi
00007e55d47e039c  pop rdx
00007e55d47e039d  pop rcx
00007e55d47e039e  pop rax
00007e55d47e039f  add rsp, 0x08
00007e55d47e03a3  jmp 0x00007E55D47DC5B3
00007e55d47e03a8  sub rsp, 0x08
00007e55d47e03ac  push rax
00007e55d47e03ad  push rcx
00007e55d47e03ae  push rdx
00007e55d47e03af  push rdi
00007e55d47e03b0  push rsi
00007e55d47e03b1  push r8
00007e55d47e03b3  push r9
00007e55d47e03b5  push r10
00007e55d47e03b7  push r11
00007e55d47e03b9  sub rsp, 0xF0
00007e55d47e03c0  vmovaps [rsp], xmm0
00007e55d47e03c5  vmovaps [rsp+0x10], xmm2
00007e55d47e03cb  vmovaps [rsp+0x20], xmm3
00007e55d47e03d1  vmovaps [rsp+0x30], xmm4
00007e55d47e03d7  vmovaps [rsp+0x40], xmm5
00007e55d47e03dd  vmovaps [rsp+0x50], xmm6
00007e55d47e03e3  vmovaps [rsp+0x60], xmm7
00007e55d47e03e9  vmovaps [rsp+0x70], xmm8
00007e55d47e03ef  vmovaps [rsp+0x80], xmm9
00007e55d47e03f8  vmovaps [rsp+0x90], xmm10
00007e55d47e0401  vmovaps [rsp+0xA0], xmm11
00007e55d47e040a  vmovaps [rsp+0xB0], xmm12
00007e55d47e0413  vmovaps [rsp+0xC0], xmm13
00007e55d47e041c  vmovaps [rsp+0xD0], xmm14
00007e55d47e0425  vmovaps [rsp+0xE0], xmm15
00007e55d47e042e  sub rsp, 0x30
00007e55d47e0432  movaps [rsp], xmm1
00007e55d47e0436  movaps [rsp+0x10], xmm13
00007e55d47e043c  movaps [rsp+0x20], xmm9
00007e55d47e0442  lea rdi, [rsp]
00007e55d47e0446  mov esi, 0x00
00007e55d47e044b  mov rax, 0x55D0734A4530
00007e55d47e0455  call rax
00007e55d47e0457  movaps xmm1, [rsp]
00007e55d47e045b  add rsp, 0x30
00007e55d47e045f  vmovaps xmm0, [rsp]
00007e55d47e0464  vmovaps xmm2, [rsp+0x10]
00007e55d47e046a  vmovaps xmm3, [rsp+0x20]
00007e55d47e0470  vmovaps xmm4, [rsp+0x30]
00007e55d47e0476  vmovaps xmm5, [rsp+0x40]
00007e55d47e047c  vmovaps xmm6, [rsp+0x50]
00007e55d47e0482  vmovaps xmm7, [rsp+0x60]
00007e55d47e0488  vmovaps xmm8, [rsp+0x70]
00007e55d47e048e  vmovaps xmm9, [rsp+0x80]
00007e55d47e0497  vmovaps xmm10, [rsp+0x90]
00007e55d47e04a0  vmovaps xmm11, [rsp+0xA0]
00007e55d47e04a9  vmovaps xmm12, [rsp+0xB0]
00007e55d47e04b2  vmovaps xmm13, [rsp+0xC0]
00007e55d47e04bb  vmovaps xmm14, [rsp+0xD0]
00007e55d47e04c4  vmovaps xmm15, [rsp+0xE0]
00007e55d47e04cd  add rsp, 0xF0
00007e55d47e04d4  pop r11
00007e55d47e04d6  pop r10
00007e55d47e04d8  pop r9
00007e55d47e04da  pop r8
00007e55d47e04dc  pop rsi
00007e55d47e04dd  pop rdi
00007e55d47e04de  pop rdx
00007e55d47e04df  pop rcx
00007e55d47e04e0  pop rax
00007e55d47e04e1  add rsp, 0x08
00007e55d47e04e5  jmp 0x00007E55D47DC5CD
00007e55d47e04ea  sub rsp, 0x08
00007e55d47e04ee  push rax
00007e55d47e04ef  push rcx
00007e55d47e04f0  push rdx
00007e55d47e04f1  push rdi
00007e55d47e04f2  push rsi
00007e55d47e04f3  push r8
00007e55d47e04f5  push r9
00007e55d47e04f7  push r10
00007e55d47e04f9  push r11
00007e55d47e04fb  sub rsp, 0xF0
00007e55d47e0502  vmovaps [rsp], xmm0
00007e55d47e0507  vmovaps [rsp+0x10], xmm1
00007e55d47e050d  vmovaps [rsp+0x20], xmm2
00007e55d47e0513  vmovaps [rsp+0x30], xmm3
00007e55d47e0519  vmovaps [rsp+0x40], xmm4
00007e55d47e051f  vmovaps [rsp+0x50], xmm5
00007e55d47e0525  vmovaps [rsp+0x60], xmm6
00007e55d47e052b  vmovaps [rsp+0x70], xmm7
00007e55d47e0531  vmovaps [rsp+0x80], xmm8
00007e55d47e053a  vmovaps [rsp+0x90], xmm9
00007e55d47e0543  vmovaps [rsp+0xA0], xmm10
00007e55d47e054c  vmovaps [rsp+0xB0], xmm11
00007e55d47e0555  vmovaps [rsp+0xC0], xmm13
00007e55d47e055e  vmovaps [rsp+0xD0], xmm14
00007e55d47e0567  vmovaps [rsp+0xE0], xmm15
00007e55d47e0570  sub rsp, 0x30
00007e55d47e0574  movaps [rsp], xmm12
00007e55d47e0579  movaps [rsp+0x10], xmm7
00007e55d47e057e  movaps [rsp+0x20], xmm13
00007e55d47e0584  lea rdi, [rsp]
00007e55d47e0588  mov esi, 0x00
00007e55d47e058d  mov rax, 0x55D0734A4530
00007e55d47e0597  call rax
00007e55d47e0599  movaps xmm12, [rsp]
00007e55d47e059e  add rsp, 0x30
00007e55d47e05a2  vmovaps xmm0, [rsp]
00007e55d47e05a7  vmovaps xmm1, [rsp+0x10]
00007e55d47e05ad  vmovaps xmm2, [rsp+0x20]
00007e55d47e05b3  vmovaps xmm3, [rsp+0x30]
00007e55d47e05b9  vmovaps xmm4, [rsp+0x40]
00007e55d47e05bf  vmovaps xmm5, [rsp+0x50]
00007e55d47e05c5  vmovaps xmm6, [rsp+0x60]
00007e55d47e05cb  vmovaps xmm7, [rsp+0x70]
00007e55d47e05d1  vmovaps xmm8, [rsp+0x80]
00007e55d47e05da  vmovaps xmm9, [rsp+0x90]
00007e55d47e05e3  vmovaps xmm10, [rsp+0xA0]
00007e55d47e05ec  vmovaps xmm11, [rsp+0xB0]
00007e55d47e05f5  vmovaps xmm13, [rsp+0xC0]
00007e55d47e05fe  vmovaps xmm14, [rsp+0xD0]
00007e55d47e0607  vmovaps xmm15, [rsp+0xE0]
00007e55d47e0610  add rsp, 0xF0
00007e55d47e0617  pop r11
00007e55d47e0619  pop r10
00007e55d47e061b  pop r9
00007e55d47e061d  pop r8
00007e55d47e061f  pop rsi
00007e55d47e0620  pop rdi
00007e55d47e0621  pop rdx
00007e55d47e0622  pop rcx
00007e55d47e0623  pop rax
00007e55d47e0624  add rsp, 0x08
00007e55d47e0628  jmp 0x00007E55D47DC5F4
00007e55d47e062d  sub rsp, 0x08
00007e55d47e0631  push rax
00007e55d47e0632  push rcx
00007e55d47e0633  push rdx
00007e55d47e0634  push rdi
00007e55d47e0635  push rsi
00007e55d47e0636  push r8
00007e55d47e0638  push r9
00007e55d47e063a  push r10
00007e55d47e063c  push r11
00007e55d47e063e  sub rsp, 0xF0
00007e55d47e0645  vmovaps [rsp], xmm0
00007e55d47e064a  vmovaps [rsp+0x10], xmm1
00007e55d47e0650  vmovaps [rsp+0x20], xmm2
00007e55d47e0656  vmovaps [rsp+0x30], xmm3
00007e55d47e065c  vmovaps [rsp+0x40], xmm4
00007e55d47e0662  vmovaps [rsp+0x50], xmm5
00007e55d47e0668  vmovaps [rsp+0x60], xmm6
00007e55d47e066e  vmovaps [rsp+0x70], xmm7
00007e55d47e0674  vmovaps [rsp+0x80], xmm8
00007e55d47e067d  vmovaps [rsp+0x90], xmm9
00007e55d47e0686  vmovaps [rsp+0xA0], xmm10
00007e55d47e068f  vmovaps [rsp+0xB0], xmm11
00007e55d47e0698  vmovaps [rsp+0xC0], xmm12
00007e55d47e06a1  vmovaps [rsp+0xD0], xmm14
00007e55d47e06aa  vmovaps [rsp+0xE0], xmm15
00007e55d47e06b3  sub rsp, 0x30
00007e55d47e06b7  movaps [rsp], xmm13
00007e55d47e06bc  movaps [rsp+0x10], xmm15
00007e55d47e06c2  movaps [rsp+0x20], xmm8
00007e55d47e06c8  lea rdi, [rsp]
00007e55d47e06cc  mov esi, 0x00
00007e55d47e06d1  mov rax, 0x55D0734A4530
00007e55d47e06db  call rax
00007e55d47e06dd  movaps xmm13, [rsp]
00007e55d47e06e2  add rsp, 0x30
00007e55d47e06e6  vmovaps xmm0, [rsp]
00007e55d47e06eb  vmovaps xmm1, [rsp+0x10]
00007e55d47e06f1  vmovaps xmm2, [rsp+0x20]
00007e55d47e06f7  vmovaps xmm3, [rsp+0x30]
00007e55d47e06fd  vmovaps xmm4, [rsp+0x40]
00007e55d47e0703  vmovaps xmm5, [rsp+0x50]
00007e55d47e0709  vmovaps xmm6, [rsp+0x60]
00007e55d47e070f  vmovaps xmm7, [rsp+0x70]
00007e55d47e0715  vmovaps xmm8, [rsp+0x80]
00007e55d47e071e  vmovaps xmm9, [rsp+0x90]
00007e55d47e0727  vmovaps xmm10, [rsp+0xA0]
00007e55d47e0730  vmovaps xmm11, [rsp+0xB0]
00007e55d47e0739  vmovaps xmm12, [rsp+0xC0]
00007e55d47e0742  vmovaps xmm14, [rsp+0xD0]
00007e55d47e074b  vmovaps xmm15, [rsp+0xE0]
00007e55d47e0754  add rsp, 0xF0
00007e55d47e075b  pop r11
00007e55d47e075d  pop r10
00007e55d47e075f  pop r9
00007e55d47e0761  pop r8
00007e55d47e0763  pop rsi
00007e55d47e0764  pop rdi
00007e55d47e0765  pop rdx
00007e55d47e0766  pop rcx
00007e55d47e0767  pop rax
00007e55d47e0768  add rsp, 0x08
00007e55d47e076c  jmp 0x00007E55D47DC60F
00007e55d47e0771  sub rsp, 0x08
00007e55d47e0775  push rax
00007e55d47e0776  push rcx
00007e55d47e0777  push rdx
00007e55d47e0778  push rdi
00007e55d47e0779  push rsi
00007e55d47e077a  push r8
00007e55d47e077c  push r9
00007e55d47e077e  push r10
00007e55d47e0780  push r11
00007e55d47e0782  sub rsp, 0xF0
00007e55d47e0789  vmovaps [rsp], xmm0
00007e55d47e078e  vmovaps [rsp+0x10], xmm1
00007e55d47e0794  vmovaps [rsp+0x20], xmm2
00007e55d47e079a  vmovaps [rsp+0x30], xmm3
00007e55d47e07a0  vmovaps [rsp+0x40], xmm4
00007e55d47e07a6  vmovaps [rsp+0x50], xmm5
00007e55d47e07ac  vmovaps [rsp+0x60], xmm6
00007e55d47e07b2  vmovaps [rsp+0x70], xmm7
00007e55d47e07b8  vmovaps [rsp+0x80], xmm9
00007e55d47e07c1  vmovaps [rsp+0x90], xmm10
00007e55d47e07ca  vmovaps [rsp+0xA0], xmm11
00007e55d47e07d3  vmovaps [rsp+0xB0], xmm12
00007e55d47e07dc  vmovaps [rsp+0xC0], xmm13
00007e55d47e07e5  vmovaps [rsp+0xD0], xmm14
00007e55d47e07ee  vmovaps [rsp+0xE0], xmm15
00007e55d47e07f7  sub rsp, 0x30
00007e55d47e07fb  movaps [rsp], xmm8
00007e55d47e0800  movaps [rsp+0x10], xmm15
00007e55d47e0806  movaps [rsp+0x20], xmm9
00007e55d47e080c  lea rdi, [rsp]
00007e55d47e0810  mov esi, 0x00
00007e55d47e0815  mov rax, 0x55D0734A4530
00007e55d47e081f  call rax
00007e55d47e0821  movaps xmm8, [rsp]
00007e55d47e0826  add rsp, 0x30
00007e55d47e082a  vmovaps xmm0, [rsp]
00007e55d47e082f  vmovaps xmm1, [rsp+0x10]
00007e55d47e0835  vmovaps xmm2, [rsp+0x20]
00007e55d47e083b  vmovaps xmm3, [rsp+0x30]
00007e55d47e0841  vmovaps xmm4, [rsp+0x40]
00007e55d47e0847  vmovaps xmm5, [rsp+0x50]
00007e55d47e084d  vmovaps xmm6, [rsp+0x60]
00007e55d47e0853  vmovaps xmm7, [rsp+0x70]
00007e55d47e0859  vmovaps xmm9, [rsp+0x80]
00007e55d47e0862  vmovaps xmm10, [rsp+0x90]
00007e55d47e086b  vmovaps xmm11, [rsp+0xA0]
00007e55d47e0874  vmovaps xmm12, [rsp+0xB0]
00007e55d47e087d  vmovaps xmm13, [rsp+0xC0]
00007e55d47e0886  vmovaps xmm14, [rsp+0xD0]
00007e55d47e088f  vmovaps xmm15, [rsp+0xE0]
00007e55d47e0898  add rsp, 0xF0
00007e55d47e089f  pop r11
00007e55d47e08a1  pop r10
00007e55d47e08a3  pop r9
00007e55d47e08a5  pop r8
00007e55d47e08a7  pop rsi
00007e55d47e08a8  pop rdi
00007e55d47e08a9  pop rdx
00007e55d47e08aa  pop rcx
00007e55d47e08ab  pop rax
00007e55d47e08ac  add rsp, 0x08
00007e55d47e08b0  jmp 0x00007E55D47DC63D
00007e55d47e08b5  sub rsp, 0x08
00007e55d47e08b9  push rax
00007e55d47e08ba  push rcx
00007e55d47e08bb  push rdx
00007e55d47e08bc  push rdi
00007e55d47e08bd  push rsi
00007e55d47e08be  push r8
00007e55d47e08c0  push r9
00007e55d47e08c2  push r10
00007e55d47e08c4  push r11
00007e55d47e08c6  sub rsp, 0xF0
00007e55d47e08cd  vmovaps [rsp], xmm0
00007e55d47e08d2  vmovaps [rsp+0x10], xmm1
00007e55d47e08d8  vmovaps [rsp+0x20], xmm2
00007e55d47e08de  vmovaps [rsp+0x30], xmm3
00007e55d47e08e4  vmovaps [rsp+0x40], xmm4
00007e55d47e08ea  vmovaps [rsp+0x50], xmm5
00007e55d47e08f0  vmovaps [rsp+0x60], xmm6
00007e55d47e08f6  vmovaps [rsp+0x70], xmm7
00007e55d47e08fc  vmovaps [rsp+0x80], xmm8
00007e55d47e0905  vmovaps [rsp+0x90], xmm9
00007e55d47e090e  vmovaps [rsp+0xA0], xmm10
00007e55d47e0917  vmovaps [rsp+0xB0], xmm11
00007e55d47e0920  vmovaps [rsp+0xC0], xmm12
00007e55d47e0929  vmovaps [rsp+0xD0], xmm13
00007e55d47e0932  vmovaps [rsp+0xE0], xmm14
00007e55d47e093b  sub rsp, 0x30
00007e55d47e093f  movaps [rsp], xmm15
00007e55d47e0944  movaps [rsp+0x10], xmm11
00007e55d47e094a  movaps [rsp+0x20], xmm6
00007e55d47e094f  lea rdi, [rsp]
00007e55d47e0953  mov esi, 0x00
00007e55d47e0958  mov rax, 0x55D0734A4530
00007e55d47e0962  call rax
00007e55d47e0964  movaps xmm15, [rsp]
00007e55d47e0969  add rsp, 0x30
00007e55d47e096d  vmovaps xmm0, [rsp]
00007e55d47e0972  vmovaps xmm1, [rsp+0x10]
00007e55d47e0978  vmovaps xmm2, [rsp+0x20]
00007e55d47e097e  vmovaps xmm3, [rsp+0x30]
00007e55d47e0984  vmovaps xmm4, [rsp+0x40]
00007e55d47e098a  vmovaps xmm5, [rsp+0x50]
00007e55d47e0990  vmovaps xmm6, [rsp+0x60]
00007e55d47e0996  vmovaps xmm7, [rsp+0x70]
00007e55d47e099c  vmovaps xmm8, [rsp+0x80]
00007e55d47e09a5  vmovaps xmm9, [rsp+0x90]
00007e55d47e09ae  vmovaps xmm10, [rsp+0xA0]
00007e55d47e09b7  vmovaps xmm11, [rsp+0xB0]
00007e55d47e09c0  vmovaps xmm12, [rsp+0xC0]
00007e55d47e09c9  vmovaps xmm13, [rsp+0xD0]
00007e55d47e09d2  vmovaps xmm14, [rsp+0xE0]
00007e55d47e09db  add rsp, 0xF0
00007e55d47e09e2  pop r11
00007e55d47e09e4  pop r10
00007e55d47e09e6  pop r9
00007e55d47e09e8  pop r8
00007e55d47e09ea  pop rsi
00007e55d47e09eb  pop rdi
00007e55d47e09ec  pop rdx
00007e55d47e09ed  pop rcx
00007e55d47e09ee  pop rax
00007e55d47e09ef  add rsp, 0x08
00007e55d47e09f3  jmp 0x00007E55D47DC658
00007e55d47e09f8  sub rsp, 0x08
00007e55d47e09fc  push rax
00007e55d47e09fd  push rcx
00007e55d47e09fe  push rdx
00007e55d47e09ff  push rdi
00007e55d47e0a00  push rsi
00007e55d47e0a01  push r8
00007e55d47e0a03  push r9
00007e55d47e0a05  push r10
00007e55d47e0a07  push r11
00007e55d47e0a09  sub rsp, 0xF0
00007e55d47e0a10  vmovaps [rsp], xmm0
00007e55d47e0a15  vmovaps [rsp+0x10], xmm1
00007e55d47e0a1b  vmovaps [rsp+0x20], xmm2
00007e55d47e0a21  vmovaps [rsp+0x30], xmm3
00007e55d47e0a27  vmovaps [rsp+0x40], xmm4
00007e55d47e0a2d  vmovaps [rsp+0x50], xmm5
00007e55d47e0a33  vmovaps [rsp+0x60], xmm6
00007e55d47e0a39  vmovaps [rsp+0x70], xmm8
00007e55d47e0a3f  vmovaps [rsp+0x80], xmm9
00007e55d47e0a48  vmovaps [rsp+0x90], xmm10
00007e55d47e0a51  vmovaps [rsp+0xA0], xmm11
00007e55d47e0a5a  vmovaps [rsp+0xB0], xmm12
00007e55d47e0a63  vmovaps [rsp+0xC0], xmm13
00007e55d47e0a6c  vmovaps [rsp+0xD0], xmm14
00007e55d47e0a75  vmovaps [rsp+0xE0], xmm15
00007e55d47e0a7e  sub rsp, 0x30
00007e55d47e0a82  movaps [rsp], xmm7
00007e55d47e0a86  movaps [rsp+0x10], xmm11
00007e55d47e0a8c  movaps [rsp+0x20], xmm9
00007e55d47e0a92  lea rdi, [rsp]
00007e55d47e0a96  mov esi, 0x00
00007e55d47e0a9b  mov rax, 0x55D0734A4530
00007e55d47e0aa5  call rax
00007e55d47e0aa7  movaps xmm7, [rsp]
00007e55d47e0aab  add rsp, 0x30
00007e55d47e0aaf  vmovaps xmm0, [rsp]
00007e55d47e0ab4  vmovaps xmm1, [rsp+0x10]
00007e55d47e0aba  vmovaps xmm2, [rsp+0x20]
00007e55d47e0ac0  vmovaps xmm3, [rsp+0x30]
00007e55d47e0ac6  vmovaps xmm4, [rsp+0x40]
00007e55d47e0acc  vmovaps xmm5, [rsp+0x50]
00007e55d47e0ad2  vmovaps xmm6, [rsp+0x60]
00007e55d47e0ad8  vmovaps xmm8, [rsp+0x70]
00007e55d47e0ade  vmovaps xmm9, [rsp+0x80]
00007e55d47e0ae7  vmovaps xmm10, [rsp+0x90]
00007e55d47e0af0  vmovaps xmm11, [rsp+0xA0]
00007e55d47e0af9  vmovaps xmm12, [rsp+0xB0]
00007e55d47e0b02  vmovaps xmm13, [rsp+0xC0]
00007e55d47e0b0b  vmovaps xmm14, [rsp+0xD0]
00007e55d47e0b14  vmovaps xmm15, [rsp+0xE0]
00007e55d47e0b1d  add rsp, 0xF0
00007e55d47e0b24  pop r11
00007e55d47e0b26  pop r10
00007e55d47e0b28  pop r9
00007e55d47e0b2a  pop r8
00007e55d47e0b2c  pop rsi
00007e55d47e0b2d  pop rdi
00007e55d47e0b2e  pop rdx
00007e55d47e0b2f  pop rcx
00007e55d47e0b30  pop rax
00007e55d47e0b31  add rsp, 0x08
00007e55d47e0b35  jmp 0x00007E55D47DC685
00007e55d47e0b3a  sub rsp, 0x08
00007e55d47e0b3e  push rax
00007e55d47e0b3f  push rcx
00007e55d47e0b40  push rdx
00007e55d47e0b41  push rdi
00007e55d47e0b42  push rsi
00007e55d47e0b43  push r8
00007e55d47e0b45  push r9
00007e55d47e0b47  push r10
00007e55d47e0b49  push r11
00007e55d47e0b4b  sub rsp, 0xF0
00007e55d47e0b52  vmovaps [rsp], xmm0
00007e55d47e0b57  vmovaps [rsp+0x10], xmm1
00007e55d47e0b5d  vmovaps [rsp+0x20], xmm2
00007e55d47e0b63  vmovaps [rsp+0x30], xmm3
00007e55d47e0b69  vmovaps [rsp+0x40], xmm4
00007e55d47e0b6f  vmovaps [rsp+0x50], xmm5
00007e55d47e0b75  vmovaps [rsp+0x60], xmm6
00007e55d47e0b7b  vmovaps [rsp+0x70], xmm7
00007e55d47e0b81  vmovaps [rsp+0x80], xmm8
00007e55d47e0b8a  vmovaps [rsp+0x90], xmm9
00007e55d47e0b93  vmovaps [rsp+0xA0], xmm10
00007e55d47e0b9c  vmovaps [rsp+0xB0], xmm12
00007e55d47e0ba5  vmovaps [rsp+0xC0], xmm13
00007e55d47e0bae  vmovaps [rsp+0xD0], xmm14
00007e55d47e0bb7  vmovaps [rsp+0xE0], xmm15
00007e55d47e0bc0  sub rsp, 0x30
00007e55d47e0bc4  movaps [rsp], xmm11
00007e55d47e0bc9  movaps [rsp+0x10], xmm10
00007e55d47e0bcf  movaps [rsp+0x20], xmm14
00007e55d47e0bd5  lea rdi, [rsp]
00007e55d47e0bd9  mov esi, 0x00
00007e55d47e0bde  mov rax, 0x55D0734A4530
00007e55d47e0be8  call rax
00007e55d47e0bea  movaps xmm11, [rsp]
00007e55d47e0bef  add rsp, 0x30
00007e55d47e0bf3  vmovaps xmm0, [rsp]
00007e55d47e0bf8  vmovaps xmm1, [rsp+0x10]
00007e55d47e0bfe  vmovaps xmm2, [rsp+0x20]
00007e55d47e0c04  vmovaps xmm3, [rsp+0x30]
00007e55d47e0c0a  vmovaps xmm4, [rsp+0x40]
00007e55d47e0c10  vmovaps xmm5, [rsp+0x50]
00007e55d47e0c16  vmovaps xmm6, [rsp+0x60]
00007e55d47e0c1c  vmovaps xmm7, [rsp+0x70]
00007e55d47e0c22  vmovaps xmm8, [rsp+0x80]
00007e55d47e0c2b  vmovaps xmm9, [rsp+0x90]
00007e55d47e0c34  vmovaps xmm10, [rsp+0xA0]
00007e55d47e0c3d  vmovaps xmm12, [rsp+0xB0]
00007e55d47e0c46  vmovaps xmm13, [rsp+0xC0]
00007e55d47e0c4f  vmovaps xmm14, [rsp+0xD0]
00007e55d47e0c58  vmovaps xmm15, [rsp+0xE0]
00007e55d47e0c61  add rsp, 0xF0
00007e55d47e0c68  pop r11
00007e55d47e0c6a  pop r10
00007e55d47e0c6c  pop r9
00007e55d47e0c6e  pop r8
00007e55d47e0c70  pop rsi
00007e55d47e0c71  pop rdi
00007e55d47e0c72  pop rdx
00007e55d47e0c73  pop rcx
00007e55d47e0c74  pop rax
00007e55d47e0c75  add rsp, 0x08
00007e55d47e0c79  jmp 0x00007E55D47DC6A0
00007e55d47e0c7e  call 0x00007E55D46C33A0
00007e55d47e0c83  jmp 0x00007E55D47DC6AA
00007e55d47e0c88  sub rsp, 0x08
00007e55d47e0c8c  push rax
00007e55d47e0c8d  push rcx
00007e55d47e0c8e  push rdx
00007e55d47e0c8f  push rdi
00007e55d47e0c90  push rsi
00007e55d47e0c91  push r8
00007e55d47e0c93  push r9
00007e55d47e0c95  push r10
00007e55d47e0c97  push r11
00007e55d47e0c99  sub rsp, 0xF0
00007e55d47e0ca0  vmovaps [rsp], xmm0
00007e55d47e0ca5  vmovaps [rsp+0x10], xmm1
00007e55d47e0cab  vmovaps [rsp+0x20], xmm2
00007e55d47e0cb1  vmovaps [rsp+0x30], xmm3
00007e55d47e0cb7  vmovaps [rsp+0x40], xmm4
00007e55d47e0cbd  vmovaps [rsp+0x50], xmm5
00007e55d47e0cc3  vmovaps [rsp+0x60], xmm6
00007e55d47e0cc9  vmovaps [rsp+0x70], xmm7
00007e55d47e0ccf  vmovaps [rsp+0x80], xmm8
00007e55d47e0cd8  vmovaps [rsp+0x90], xmm9
00007e55d47e0ce1  vmovaps [rsp+0xA0], xmm11
00007e55d47e0cea  vmovaps [rsp+0xB0], xmm12
00007e55d47e0cf3  vmovaps [rsp+0xC0], xmm13
00007e55d47e0cfc  vmovaps [rsp+0xD0], xmm14
00007e55d47e0d05  vmovaps [rsp+0xE0], xmm15
00007e55d47e0d0e  sub rsp, 0x30
00007e55d47e0d12  movaps [rsp], xmm10
00007e55d47e0d17  movaps [rsp+0x10], xmm1
00007e55d47e0d1c  movaps [rsp+0x20], xmm12
00007e55d47e0d22  lea rdi, [rsp]
00007e55d47e0d26  mov esi, 0x00
00007e55d47e0d2b  mov rax, 0x55D0734A4530
00007e55d47e0d35  call rax
00007e55d47e0d37  movaps xmm10, [rsp]
00007e55d47e0d3c  add rsp, 0x30
00007e55d47e0d40  vmovaps xmm0, [rsp]
00007e55d47e0d45  vmovaps xmm1, [rsp+0x10]
00007e55d47e0d4b  vmovaps xmm2, [rsp+0x20]
00007e55d47e0d51  vmovaps xmm3, [rsp+0x30]
00007e55d47e0d57  vmovaps xmm4, [rsp+0x40]
00007e55d47e0d5d  vmovaps xmm5, [rsp+0x50]
00007e55d47e0d63  vmovaps xmm6, [rsp+0x60]
00007e55d47e0d69  vmovaps xmm7, [rsp+0x70]
00007e55d47e0d6f  vmovaps xmm8, [rsp+0x80]
00007e55d47e0d78  vmovaps xmm9, [rsp+0x90]
00007e55d47e0d81  vmovaps xmm11, [rsp+0xA0]
00007e55d47e0d8a  vmovaps xmm12, [rsp+0xB0]
00007e55d47e0d93  vmovaps xmm13, [rsp+0xC0]
00007e55d47e0d9c  vmovaps xmm14, [rsp+0xD0]
00007e55d47e0da5  vmovaps xmm15, [rsp+0xE0]
00007e55d47e0dae  add rsp, 0xF0
00007e55d47e0db5  pop r11
00007e55d47e0db7  pop r10
00007e55d47e0db9  pop r9
00007e55d47e0dbb  pop r8
00007e55d47e0dbd  pop rsi
00007e55d47e0dbe  pop rdi
00007e55d47e0dbf  pop rdx
00007e55d47e0dc0  pop rcx
00007e55d47e0dc1  pop rax
00007e55d47e0dc2  add rsp, 0x08
00007e55d47e0dc6  jmp 0x00007E55D47DC6CD
00007e55d47e0dcb  sub rsp, 0x08
00007e55d47e0dcf  push rax
00007e55d47e0dd0  push rcx
00007e55d47e0dd1  push rdx
00007e55d47e0dd2  push rdi
00007e55d47e0dd3  push rsi
00007e55d47e0dd4  push r8
00007e55d47e0dd6  push r9
00007e55d47e0dd8  push r10
00007e55d47e0dda  push r11
00007e55d47e0ddc  sub rsp, 0xF0
00007e55d47e0de3  vmovaps [rsp], xmm0
00007e55d47e0de8  vmovaps [rsp+0x10], xmm1
00007e55d47e0dee  vmovaps [rsp+0x20], xmm2
00007e55d47e0df4  vmovaps [rsp+0x30], xmm3
00007e55d47e0dfa  vmovaps [rsp+0x40], xmm4
00007e55d47e0e00  vmovaps [rsp+0x50], xmm5
00007e55d47e0e06  vmovaps [rsp+0x60], xmm6
00007e55d47e0e0c  vmovaps [rsp+0x70], xmm7
00007e55d47e0e12  vmovaps [rsp+0x80], xmm8
00007e55d47e0e1b  vmovaps [rsp+0x90], xmm9
00007e55d47e0e24  vmovaps [rsp+0xA0], xmm10
00007e55d47e0e2d  vmovaps [rsp+0xB0], xmm11
00007e55d47e0e36  vmovaps [rsp+0xC0], xmm13
00007e55d47e0e3f  vmovaps [rsp+0xD0], xmm14
00007e55d47e0e48  vmovaps [rsp+0xE0], xmm15
00007e55d47e0e51  sub rsp, 0x30
00007e55d47e0e55  movaps [rsp], xmm12
00007e55d47e0e5a  movaps [rsp+0x10], xmm14
00007e55d47e0e60  movaps [rsp+0x20], xmm1
00007e55d47e0e65  lea rdi, [rsp]
00007e55d47e0e69  mov esi, 0x00
00007e55d47e0e6e  mov rax, 0x55D0734A4530
00007e55d47e0e78  call rax
00007e55d47e0e7a  movaps xmm12, [rsp]
00007e55d47e0e7f  add rsp, 0x30
00007e55d47e0e83  vmovaps xmm0, [rsp]
00007e55d47e0e88  vmovaps xmm1, [rsp+0x10]
00007e55d47e0e8e  vmovaps xmm2, [rsp+0x20]
00007e55d47e0e94  vmovaps xmm3, [rsp+0x30]
00007e55d47e0e9a  vmovaps xmm4, [rsp+0x40]
00007e55d47e0ea0  vmovaps xmm5, [rsp+0x50]
00007e55d47e0ea6  vmovaps xmm6, [rsp+0x60]
00007e55d47e0eac  vmovaps xmm7, [rsp+0x70]
00007e55d47e0eb2  vmovaps xmm8, [rsp+0x80]
00007e55d47e0ebb  vmovaps xmm9, [rsp+0x90]
00007e55d47e0ec4  vmovaps xmm10, [rsp+0xA0]
00007e55d47e0ecd  vmovaps xmm11, [rsp+0xB0]
00007e55d47e0ed6  vmovaps xmm13, [rsp+0xC0]
00007e55d47e0edf  vmovaps xmm14, [rsp+0xD0]
00007e55d47e0ee8  vmovaps xmm15, [rsp+0xE0]
00007e55d47e0ef1  add rsp, 0xF0
00007e55d47e0ef8  pop r11
00007e55d47e0efa  pop r10
00007e55d47e0efc  pop r9
00007e55d47e0efe  pop r8
00007e55d47e0f00  pop rsi
00007e55d47e0f01  pop rdi
00007e55d47e0f02  pop rdx
00007e55d47e0f03  pop rcx
00007e55d47e0f04  pop rax
00007e55d47e0f05  add rsp, 0x08
00007e55d47e0f09  jmp 0x00007E55D47DC6FC
00007e55d47e0f0e  sub rsp, 0x08
00007e55d47e0f12  push rax
00007e55d47e0f13  push rcx
00007e55d47e0f14  push rdx
00007e55d47e0f15  push rdi
00007e55d47e0f16  push rsi
00007e55d47e0f17  push r8
00007e55d47e0f19  push r9
00007e55d47e0f1b  push r10
00007e55d47e0f1d  push r11
00007e55d47e0f1f  sub rsp, 0xF0
00007e55d47e0f26  vmovaps [rsp], xmm0
00007e55d47e0f2b  vmovaps [rsp+0x10], xmm1
00007e55d47e0f31  vmovaps [rsp+0x20], xmm2
00007e55d47e0f37  vmovaps [rsp+0x30], xmm3
00007e55d47e0f3d  vmovaps [rsp+0x40], xmm4
00007e55d47e0f43  vmovaps [rsp+0x50], xmm5
00007e55d47e0f49  vmovaps [rsp+0x60], xmm6
00007e55d47e0f4f  vmovaps [rsp+0x70], xmm7
00007e55d47e0f55  vmovaps [rsp+0x80], xmm8
00007e55d47e0f5e  vmovaps [rsp+0x90], xmm9
00007e55d47e0f67  vmovaps [rsp+0xA0], xmm10
00007e55d47e0f70  vmovaps [rsp+0xB0], xmm11
00007e55d47e0f79  vmovaps [rsp+0xC0], xmm12
00007e55d47e0f82  vmovaps [rsp+0xD0], xmm13
00007e55d47e0f8b  vmovaps [rsp+0xE0], xmm15
00007e55d47e0f94  sub rsp, 0x30
00007e55d47e0f98  movaps [rsp], xmm14
00007e55d47e0f9d  movaps [rsp+0x10], xmm9
00007e55d47e0fa3  movaps [rsp+0x20], xmm1
00007e55d47e0fa8  lea rdi, [rsp]
00007e55d47e0fac  mov esi, 0x00
00007e55d47e0fb1  mov rax, 0x55D0734A4530
00007e55d47e0fbb  call rax
00007e55d47e0fbd  movaps xmm14, [rsp]
00007e55d47e0fc2  add rsp, 0x30
00007e55d47e0fc6  vmovaps xmm0, [rsp]
00007e55d47e0fcb  vmovaps xmm1, [rsp+0x10]
00007e55d47e0fd1  vmovaps xmm2, [rsp+0x20]
00007e55d47e0fd7  vmovaps xmm3, [rsp+0x30]
00007e55d47e0fdd  vmovaps xmm4, [rsp+0x40]
00007e55d47e0fe3  vmovaps xmm5, [rsp+0x50]
00007e55d47e0fe9  vmovaps xmm6, [rsp+0x60]
00007e55d47e0fef  vmovaps xmm7, [rsp+0x70]
00007e55d47e0ff5  vmovaps xmm8, [rsp+0x80]
00007e55d47e0ffe  vmovaps xmm9, [rsp+0x90]
00007e55d47e1007  vmovaps xmm10, [rsp+0xA0]
00007e55d47e1010  vmovaps xmm11, [rsp+0xB0]
00007e55d47e1019  vmovaps xmm12, [rsp+0xC0]
00007e55d47e1022  vmovaps xmm13, [rsp+0xD0]
00007e55d47e102b  vmovaps xmm15, [rsp+0xE0]
00007e55d47e1034  add rsp, 0xF0
00007e55d47e103b  pop r11
00007e55d47e103d  pop r10
00007e55d47e103f  pop r9
00007e55d47e1041  pop r8
00007e55d47e1043  pop rsi
00007e55d47e1044  pop rdi
00007e55d47e1045  pop rdx
00007e55d47e1046  pop rcx
00007e55d47e1047  pop rax
00007e55d47e1048  add rsp, 0x08
00007e55d47e104c  jmp 0x00007E55D47DC72B
00007e55d47e1051  sub rsp, 0x08
00007e55d47e1055  push rax
00007e55d47e1056  push rcx
00007e55d47e1057  push rdx
00007e55d47e1058  push rdi
00007e55d47e1059  push rsi
00007e55d47e105a  push r8
00007e55d47e105c  push r9
00007e55d47e105e  push r10
00007e55d47e1060  push r11
00007e55d47e1062  sub rsp, 0xF0
00007e55d47e1069  vmovaps [rsp], xmm0
00007e55d47e106e  vmovaps [rsp+0x10], xmm2
00007e55d47e1074  vmovaps [rsp+0x20], xmm3
00007e55d47e107a  vmovaps [rsp+0x30], xmm4
00007e55d47e1080  vmovaps [rsp+0x40], xmm5
00007e55d47e1086  vmovaps [rsp+0x50], xmm6
00007e55d47e108c  vmovaps [rsp+0x60], xmm7
00007e55d47e1092  vmovaps [rsp+0x70], xmm8
00007e55d47e1098  vmovaps [rsp+0x80], xmm9
00007e55d47e10a1  vmovaps [rsp+0x90], xmm10
00007e55d47e10aa  vmovaps [rsp+0xA0], xmm11
00007e55d47e10b3  vmovaps [rsp+0xB0], xmm12
00007e55d47e10bc  vmovaps [rsp+0xC0], xmm13
00007e55d47e10c5  vmovaps [rsp+0xD0], xmm14
00007e55d47e10ce  vmovaps [rsp+0xE0], xmm15
00007e55d47e10d7  sub rsp, 0x30
00007e55d47e10db  movaps [rsp], xmm1
00007e55d47e10df  movaps [rsp+0x10], xmm13
00007e55d47e10e5  movaps [rsp+0x20], xmm8
00007e55d47e10eb  lea rdi, [rsp]
00007e55d47e10ef  mov esi, 0x00
00007e55d47e10f4  mov rax, 0x55D0734A4530
00007e55d47e10fe  call rax
00007e55d47e1100  movaps xmm1, [rsp]
00007e55d47e1104  add rsp, 0x30
00007e55d47e1108  vmovaps xmm0, [rsp]
00007e55d47e110d  vmovaps xmm2, [rsp+0x10]
00007e55d47e1113  vmovaps xmm3, [rsp+0x20]
00007e55d47e1119  vmovaps xmm4, [rsp+0x30]
00007e55d47e111f  vmovaps xmm5, [rsp+0x40]
00007e55d47e1125  vmovaps xmm6, [rsp+0x50]
00007e55d47e112b  vmovaps xmm7, [rsp+0x60]
00007e55d47e1131  vmovaps xmm8, [rsp+0x70]
00007e55d47e1137  vmovaps xmm9, [rsp+0x80]
00007e55d47e1140  vmovaps xmm10, [rsp+0x90]
00007e55d47e1149  vmovaps xmm11, [rsp+0xA0]
00007e55d47e1152  vmovaps xmm12, [rsp+0xB0]
00007e55d47e115b  vmovaps xmm13, [rsp+0xC0]
00007e55d47e1164  vmovaps xmm14, [rsp+0xD0]
00007e55d47e116d  vmovaps xmm15, [rsp+0xE0]
00007e55d47e1176  add rsp, 0xF0
00007e55d47e117d  pop r11
00007e55d47e117f  pop r10
00007e55d47e1181  pop r9
00007e55d47e1183  pop r8
00007e55d47e1185  pop rsi
00007e55d47e1186  pop rdi
00007e55d47e1187  pop rdx
00007e55d47e1188  pop rcx
00007e55d47e1189  pop rax
00007e55d47e118a  add rsp, 0x08
00007e55d47e118e  jmp 0x00007E55D47DC74D
00007e55d47e1193  call 0x00007E55D460C260
00007e55d47e1198  jmp 0x00007E55D47DC75B
00007e55d47e119d  call 0x00007E55D46BD750
00007e55d47e11a2  jmp 0x00007E55D47DC765
00007e55d47e11a7  sub rsp, 0x08
00007e55d47e11ab  push rax
00007e55d47e11ac  push rcx
00007e55d47e11ad  push rdx
00007e55d47e11ae  push rdi
00007e55d47e11af  push rsi
00007e55d47e11b0  push r8
00007e55d47e11b2  push r9
00007e55d47e11b4  push r10
00007e55d47e11b6  push r11
00007e55d47e11b8  sub rsp, 0xF0
00007e55d47e11bf  vmovaps [rsp], xmm0
00007e55d47e11c4  vmovaps [rsp+0x10], xmm1
00007e55d47e11ca  vmovaps [rsp+0x20], xmm2
00007e55d47e11d0  vmovaps [rsp+0x30], xmm3
00007e55d47e11d6  vmovaps [rsp+0x40], xmm4
00007e55d47e11dc  vmovaps [rsp+0x50], xmm5
00007e55d47e11e2  vmovaps [rsp+0x60], xmm6
00007e55d47e11e8  vmovaps [rsp+0x70], xmm7
00007e55d47e11ee  vmovaps [rsp+0x80], xmm9
00007e55d47e11f7  vmovaps [rsp+0x90], xmm10
00007e55d47e1200  vmovaps [rsp+0xA0], xmm11
00007e55d47e1209  vmovaps [rsp+0xB0], xmm12
00007e55d47e1212  vmovaps [rsp+0xC0], xmm13
00007e55d47e121b  vmovaps [rsp+0xD0], xmm14
00007e55d47e1224  vmovaps [rsp+0xE0], xmm15
00007e55d47e122d  sub rsp, 0x30
00007e55d47e1231  movaps [rsp], xmm8
00007e55d47e1236  movaps [rsp+0x10], xmm15
00007e55d47e123c  movaps [rsp+0x20], xmm7
00007e55d47e1241  lea rdi, [rsp]
00007e55d47e1245  mov esi, 0x00
00007e55d47e124a  mov rax, 0x55D0734A4530
00007e55d47e1254  call rax
00007e55d47e1256  movaps xmm8, [rsp]
00007e55d47e125b  add rsp, 0x30
00007e55d47e125f  vmovaps xmm0, [rsp]
00007e55d47e1264  vmovaps xmm1, [rsp+0x10]
00007e55d47e126a  vmovaps xmm2, [rsp+0x20]
00007e55d47e1270  vmovaps xmm3, [rsp+0x30]
00007e55d47e1276  vmovaps xmm4, [rsp+0x40]
00007e55d47e127c  vmovaps xmm5, [rsp+0x50]
00007e55d47e1282  vmovaps xmm6, [rsp+0x60]
00007e55d47e1288  vmovaps xmm7, [rsp+0x70]
00007e55d47e128e  vmovaps xmm9, [rsp+0x80]
00007e55d47e1297  vmovaps xmm10, [rsp+0x90]
00007e55d47e12a0  vmovaps xmm11, [rsp+0xA0]
00007e55d47e12a9  vmovaps xmm12, [rsp+0xB0]
00007e55d47e12b2  vmovaps xmm13, [rsp+0xC0]
00007e55d47e12bb  vmovaps xmm14, [rsp+0xD0]
00007e55d47e12c4  vmovaps xmm15, [rsp+0xE0]
00007e55d47e12cd  add rsp, 0xF0
00007e55d47e12d4  pop r11
00007e55d47e12d6  pop r10
00007e55d47e12d8  pop r9
00007e55d47e12da  pop r8
00007e55d47e12dc  pop rsi
00007e55d47e12dd  pop rdi
00007e55d47e12de  pop rdx
00007e55d47e12df  pop rcx
00007e55d47e12e0  pop rax
00007e55d47e12e1  add rsp, 0x08
00007e55d47e12e5  jmp 0x00007E55D47DC787
00007e55d47e12ea  sub rsp, 0x08
00007e55d47e12ee  push rax
00007e55d47e12ef  push rcx
00007e55d47e12f0  push rdx
00007e55d47e12f1  push rdi
00007e55d47e12f2  push rsi
00007e55d47e12f3  push r8
00007e55d47e12f5  push r9
00007e55d47e12f7  push r10
00007e55d47e12f9  push r11
00007e55d47e12fb  sub rsp, 0xF0
00007e55d47e1302  vmovaps [rsp], xmm0
00007e55d47e1307  vmovaps [rsp+0x10], xmm1
00007e55d47e130d  vmovaps [rsp+0x20], xmm2
00007e55d47e1313  vmovaps [rsp+0x30], xmm3
00007e55d47e1319  vmovaps [rsp+0x40], xmm4
00007e55d47e131f  vmovaps [rsp+0x50], xmm5
00007e55d47e1325  vmovaps [rsp+0x60], xmm6
00007e55d47e132b  vmovaps [rsp+0x70], xmm8
00007e55d47e1331  vmovaps [rsp+0x80], xmm9
00007e55d47e133a  vmovaps [rsp+0x90], xmm10
00007e55d47e1343  vmovaps [rsp+0xA0], xmm11
00007e55d47e134c  vmovaps [rsp+0xB0], xmm12
00007e55d47e1355  vmovaps [rsp+0xC0], xmm13
00007e55d47e135e  vmovaps [rsp+0xD0], xmm14
00007e55d47e1367  vmovaps [rsp+0xE0], xmm15
00007e55d47e1370  sub rsp, 0x30
00007e55d47e1374  movaps [rsp], xmm7
00007e55d47e1378  movaps [rsp+0x10], xmm9
00007e55d47e137e  movaps [rsp+0x20], xmm15
00007e55d47e1384  lea rdi, [rsp]
00007e55d47e1388  mov esi, 0x00
00007e55d47e138d  mov rax, 0x55D0734A4530
00007e55d47e1397  call rax
00007e55d47e1399  movaps xmm7, [rsp]
00007e55d47e139d  add rsp, 0x30
00007e55d47e13a1  vmovaps xmm0, [rsp]
00007e55d47e13a6  vmovaps xmm1, [rsp+0x10]
00007e55d47e13ac  vmovaps xmm2, [rsp+0x20]
00007e55d47e13b2  vmovaps xmm3, [rsp+0x30]
00007e55d47e13b8  vmovaps xmm4, [rsp+0x40]
00007e55d47e13be  vmovaps xmm5, [rsp+0x50]
00007e55d47e13c4  vmovaps xmm6, [rsp+0x60]
00007e55d47e13ca  vmovaps xmm8, [rsp+0x70]
00007e55d47e13d0  vmovaps xmm9, [rsp+0x80]
00007e55d47e13d9  vmovaps xmm10, [rsp+0x90]
00007e55d47e13e2  vmovaps xmm11, [rsp+0xA0]
00007e55d47e13eb  vmovaps xmm12, [rsp+0xB0]
00007e55d47e13f4  vmovaps xmm13, [rsp+0xC0]
00007e55d47e13fd  vmovaps xmm14, [rsp+0xD0]
00007e55d47e1406  vmovaps xmm15, [rsp+0xE0]
00007e55d47e140f  add rsp, 0xF0
00007e55d47e1416  pop r11
00007e55d47e1418  pop r10
00007e55d47e141a  pop r9
00007e55d47e141c  pop r8
00007e55d47e141e  pop rsi
00007e55d47e141f  pop rdi
00007e55d47e1420  pop rdx
00007e55d47e1421  pop rcx
00007e55d47e1422  pop rax
00007e55d47e1423  add rsp, 0x08
00007e55d47e1427  jmp 0x00007E55D47DC7B4
00007e55d47e142c  sub rsp, 0x08
00007e55d47e1430  push rax
00007e55d47e1431  push rcx
00007e55d47e1432  push rdx
00007e55d47e1433  push rdi
00007e55d47e1434  push rsi
00007e55d47e1435  push r8
00007e55d47e1437  push r9
00007e55d47e1439  push r10
00007e55d47e143b  push r11
00007e55d47e143d  sub rsp, 0xF0
00007e55d47e1444  vmovaps [rsp], xmm0
00007e55d47e1449  vmovaps [rsp+0x10], xmm1
00007e55d47e144f  vmovaps [rsp+0x20], xmm2
00007e55d47e1455  vmovaps [rsp+0x30], xmm3
00007e55d47e145b  vmovaps [rsp+0x40], xmm4
00007e55d47e1461  vmovaps [rsp+0x50], xmm5
00007e55d47e1467  vmovaps [rsp+0x60], xmm6
00007e55d47e146d  vmovaps [rsp+0x70], xmm7
00007e55d47e1473  vmovaps [rsp+0x80], xmm8
00007e55d47e147c  vmovaps [rsp+0x90], xmm10
00007e55d47e1485  vmovaps [rsp+0xA0], xmm11
00007e55d47e148e  vmovaps [rsp+0xB0], xmm12
00007e55d47e1497  vmovaps [rsp+0xC0], xmm13
00007e55d47e14a0  vmovaps [rsp+0xD0], xmm14
00007e55d47e14a9  vmovaps [rsp+0xE0], xmm15
00007e55d47e14b2  sub rsp, 0x30
00007e55d47e14b6  movaps [rsp], xmm9
00007e55d47e14bb  movaps [rsp+0x10], xmm13
00007e55d47e14c1  movaps [rsp+0x20], xmm15
00007e55d47e14c7  lea rdi, [rsp]
00007e55d47e14cb  mov esi, 0x00
00007e55d47e14d0  mov rax, 0x55D0734A4530
00007e55d47e14da  call rax
00007e55d47e14dc  movaps xmm9, [rsp]
00007e55d47e14e1  add rsp, 0x30
00007e55d47e14e5  vmovaps xmm0, [rsp]
00007e55d47e14ea  vmovaps xmm1, [rsp+0x10]
00007e55d47e14f0  vmovaps xmm2, [rsp+0x20]
00007e55d47e14f6  vmovaps xmm3, [rsp+0x30]
00007e55d47e14fc  vmovaps xmm4, [rsp+0x40]
00007e55d47e1502  vmovaps xmm5, [rsp+0x50]
00007e55d47e1508  vmovaps xmm6, [rsp+0x60]
00007e55d47e150e  vmovaps xmm7, [rsp+0x70]
00007e55d47e1514  vmovaps xmm8, [rsp+0x80]
00007e55d47e151d  vmovaps xmm10, [rsp+0x90]
00007e55d47e1526  vmovaps xmm11, [rsp+0xA0]
00007e55d47e152f  vmovaps xmm12, [rsp+0xB0]
00007e55d47e1538  vmovaps xmm13, [rsp+0xC0]
00007e55d47e1541  vmovaps xmm14, [rsp+0xD0]
00007e55d47e154a  vmovaps xmm15, [rsp+0xE0]
00007e55d47e1553  add rsp, 0xF0
00007e55d47e155a  pop r11
00007e55d47e155c  pop r10
00007e55d47e155e  pop r9
00007e55d47e1560  pop r8
00007e55d47e1562  pop rsi
00007e55d47e1563  pop rdi
00007e55d47e1564  pop rdx
00007e55d47e1565  pop rcx
00007e55d47e1566  pop rax
00007e55d47e1567  add rsp, 0x08
00007e55d47e156b  jmp 0x00007E55D47DC7E2
00007e55d47e1570  sub rsp, 0x08
00007e55d47e1574  push rax
00007e55d47e1575  push rcx
00007e55d47e1576  push rdx
00007e55d47e1577  push rdi
00007e55d47e1578  push rsi
00007e55d47e1579  push r8
00007e55d47e157b  push r9
00007e55d47e157d  push r10
00007e55d47e157f  push r11
00007e55d47e1581  sub rsp, 0xF0
00007e55d47e1588  vmovaps [rsp], xmm0
00007e55d47e158d  vmovaps [rsp+0x10], xmm1
00007e55d47e1593  vmovaps [rsp+0x20], xmm2
00007e55d47e1599  vmovaps [rsp+0x30], xmm3
00007e55d47e159f  vmovaps [rsp+0x40], xmm4
00007e55d47e15a5  vmovaps [rsp+0x50], xmm5
00007e55d47e15ab  vmovaps [rsp+0x60], xmm6
00007e55d47e15b1  vmovaps [rsp+0x70], xmm7
00007e55d47e15b7  vmovaps [rsp+0x80], xmm8
00007e55d47e15c0  vmovaps [rsp+0x90], xmm9
00007e55d47e15c9  vmovaps [rsp+0xA0], xmm10
00007e55d47e15d2  vmovaps [rsp+0xB0], xmm11
00007e55d47e15db  vmovaps [rsp+0xC0], xmm12
00007e55d47e15e4  vmovaps [rsp+0xD0], xmm13
00007e55d47e15ed  vmovaps [rsp+0xE0], xmm14
00007e55d47e15f6  sub rsp, 0x30
00007e55d47e15fa  movaps [rsp], xmm15
00007e55d47e15ff  movaps [rsp+0x10], xmm11
00007e55d47e1605  movaps [rsp+0x20], xmm12
00007e55d47e160b  lea rdi, [rsp]
00007e55d47e160f  mov esi, 0x00
00007e55d47e1614  mov rax, 0x55D0734A4530
00007e55d47e161e  call rax
00007e55d47e1620  movaps xmm15, [rsp]
00007e55d47e1625  add rsp, 0x30
00007e55d47e1629  vmovaps xmm0, [rsp]
00007e55d47e162e  vmovaps xmm1, [rsp+0x10]
00007e55d47e1634  vmovaps xmm2, [rsp+0x20]
00007e55d47e163a  vmovaps xmm3, [rsp+0x30]
00007e55d47e1640  vmovaps xmm4, [rsp+0x40]
00007e55d47e1646  vmovaps xmm5, [rsp+0x50]
00007e55d47e164c  vmovaps xmm6, [rsp+0x60]
00007e55d47e1652  vmovaps xmm7, [rsp+0x70]
00007e55d47e1658  vmovaps xmm8, [rsp+0x80]
00007e55d47e1661  vmovaps xmm9, [rsp+0x90]
00007e55d47e166a  vmovaps xmm10, [rsp+0xA0]
00007e55d47e1673  vmovaps xmm11, [rsp+0xB0]
00007e55d47e167c  vmovaps xmm12, [rsp+0xC0]
00007e55d47e1685  vmovaps xmm13, [rsp+0xD0]
00007e55d47e168e  vmovaps xmm14, [rsp+0xE0]
00007e55d47e1697  add rsp, 0xF0
00007e55d47e169e  pop r11
00007e55d47e16a0  pop r10
00007e55d47e16a2  pop r9
00007e55d47e16a4  pop r8
00007e55d47e16a6  pop rsi
00007e55d47e16a7  pop rdi
00007e55d47e16a8  pop rdx
00007e55d47e16a9  pop rcx
00007e55d47e16aa  pop rax
00007e55d47e16ab  add rsp, 0x08
00007e55d47e16af  jmp 0x00007E55D47DC7FD
00007e55d47e16b4  sub rsp, 0x08
00007e55d47e16b8  push rax
00007e55d47e16b9  push rcx
00007e55d47e16ba  push rdx
00007e55d47e16bb  push rdi
00007e55d47e16bc  push rsi
00007e55d47e16bd  push r8
00007e55d47e16bf  push r9
00007e55d47e16c1  push r10
00007e55d47e16c3  push r11
00007e55d47e16c5  sub rsp, 0xF0
00007e55d47e16cc  vmovaps [rsp], xmm0
00007e55d47e16d1  vmovaps [rsp+0x10], xmm1
00007e55d47e16d7  vmovaps [rsp+0x20], xmm2
00007e55d47e16dd  vmovaps [rsp+0x30], xmm3
00007e55d47e16e3  vmovaps [rsp+0x40], xmm4
00007e55d47e16e9  vmovaps [rsp+0x50], xmm5
00007e55d47e16ef  vmovaps [rsp+0x60], xmm6
00007e55d47e16f5  vmovaps [rsp+0x70], xmm7
00007e55d47e16fb  vmovaps [rsp+0x80], xmm8
00007e55d47e1704  vmovaps [rsp+0x90], xmm9
00007e55d47e170d  vmovaps [rsp+0xA0], xmm10
00007e55d47e1716  vmovaps [rsp+0xB0], xmm11
00007e55d47e171f  vmovaps [rsp+0xC0], xmm12
00007e55d47e1728  vmovaps [rsp+0xD0], xmm14
00007e55d47e1731  vmovaps [rsp+0xE0], xmm15
00007e55d47e173a  sub rsp, 0x30
00007e55d47e173e  movaps [rsp], xmm13
00007e55d47e1743  movaps [rsp+0x10], xmm10
00007e55d47e1749  movaps [rsp+0x20], xmm14
00007e55d47e174f  lea rdi, [rsp]
00007e55d47e1753  mov esi, 0x00
00007e55d47e1758  mov rax, 0x55D0734A4530
00007e55d47e1762  call rax
00007e55d47e1764  movaps xmm13, [rsp]
00007e55d47e1769  add rsp, 0x30
00007e55d47e176d  vmovaps xmm0, [rsp]
00007e55d47e1772  vmovaps xmm1, [rsp+0x10]
00007e55d47e1778  vmovaps xmm2, [rsp+0x20]
00007e55d47e177e  vmovaps xmm3, [rsp+0x30]
00007e55d47e1784  vmovaps xmm4, [rsp+0x40]
00007e55d47e178a  vmovaps xmm5, [rsp+0x50]
00007e55d47e1790  vmovaps xmm6, [rsp+0x60]
00007e55d47e1796  vmovaps xmm7, [rsp+0x70]
00007e55d47e179c  vmovaps xmm8, [rsp+0x80]
00007e55d47e17a5  vmovaps xmm9, [rsp+0x90]
00007e55d47e17ae  vmovaps xmm10, [rsp+0xA0]
00007e55d47e17b7  vmovaps xmm11, [rsp+0xB0]
00007e55d47e17c0  vmovaps xmm12, [rsp+0xC0]
00007e55d47e17c9  vmovaps xmm14, [rsp+0xD0]
00007e55d47e17d2  vmovaps xmm15, [rsp+0xE0]
00007e55d47e17db  add rsp, 0xF0
00007e55d47e17e2  pop r11
00007e55d47e17e4  pop r10
00007e55d47e17e6  pop r9
00007e55d47e17e8  pop r8
00007e55d47e17ea  pop rsi
00007e55d47e17eb  pop rdi
00007e55d47e17ec  pop rdx
00007e55d47e17ed  pop rcx
00007e55d47e17ee  pop rax
00007e55d47e17ef  add rsp, 0x08
00007e55d47e17f3  jmp 0x00007E55D47DC820
00007e55d47e17f8  sub rsp, 0x08
00007e55d47e17fc  push rax
00007e55d47e17fd  push rcx
00007e55d47e17fe  push rdx
00007e55d47e17ff  push rdi
00007e55d47e1800  push rsi
00007e55d47e1801  push r8
00007e55d47e1803  push r9
00007e55d47e1805  push r10
00007e55d47e1807  push r11
00007e55d47e1809  sub rsp, 0xF0
00007e55d47e1810  vmovaps [rsp], xmm0
00007e55d47e1815  vmovaps [rsp+0x10], xmm1
00007e55d47e181b  vmovaps [rsp+0x20], xmm2
00007e55d47e1821  vmovaps [rsp+0x30], xmm3
00007e55d47e1827  vmovaps [rsp+0x40], xmm4
00007e55d47e182d  vmovaps [rsp+0x50], xmm5
00007e55d47e1833  vmovaps [rsp+0x60], xmm6
00007e55d47e1839  vmovaps [rsp+0x70], xmm7
00007e55d47e183f  vmovaps [rsp+0x80], xmm8
00007e55d47e1848  vmovaps [rsp+0x90], xmm9
00007e55d47e1851  vmovaps [rsp+0xA0], xmm10
00007e55d47e185a  vmovaps [rsp+0xB0], xmm11
00007e55d47e1863  vmovaps [rsp+0xC0], xmm12
00007e55d47e186c  vmovaps [rsp+0xD0], xmm13
00007e55d47e1875  vmovaps [rsp+0xE0], xmm15
00007e55d47e187e  sub rsp, 0x30
00007e55d47e1882  movaps [rsp], xmm14
00007e55d47e1887  movaps [rsp+0x10], xmm1
00007e55d47e188c  movaps [rsp+0x20], xmm7
00007e55d47e1891  lea rdi, [rsp]
00007e55d47e1895  mov esi, 0x00
00007e55d47e189a  mov rax, 0x55D0734A4530
00007e55d47e18a4  call rax
00007e55d47e18a6  movaps xmm14, [rsp]
00007e55d47e18ab  add rsp, 0x30
00007e55d47e18af  vmovaps xmm0, [rsp]
00007e55d47e18b4  vmovaps xmm1, [rsp+0x10]
00007e55d47e18ba  vmovaps xmm2, [rsp+0x20]
00007e55d47e18c0  vmovaps xmm3, [rsp+0x30]
00007e55d47e18c6  vmovaps xmm4, [rsp+0x40]
00007e55d47e18cc  vmovaps xmm5, [rsp+0x50]
00007e55d47e18d2  vmovaps xmm6, [rsp+0x60]
00007e55d47e18d8  vmovaps xmm7, [rsp+0x70]
00007e55d47e18de  vmovaps xmm8, [rsp+0x80]
00007e55d47e18e7  vmovaps xmm9, [rsp+0x90]
00007e55d47e18f0  vmovaps xmm10, [rsp+0xA0]
00007e55d47e18f9  vmovaps xmm11, [rsp+0xB0]
00007e55d47e1902  vmovaps xmm12, [rsp+0xC0]
00007e55d47e190b  vmovaps xmm13, [rsp+0xD0]
00007e55d47e1914  vmovaps xmm15, [rsp+0xE0]
00007e55d47e191d  add rsp, 0xF0
00007e55d47e1924  pop r11
00007e55d47e1926  pop r10
00007e55d47e1928  pop r9
00007e55d47e192a  pop r8
00007e55d47e192c  pop rsi
00007e55d47e192d  pop rdi
00007e55d47e192e  pop rdx
00007e55d47e192f  pop rcx
00007e55d47e1930  pop rax
00007e55d47e1931  add rsp, 0x08
00007e55d47e1935  jmp 0x00007E55D47DC843
00007e55d47e193a  sub rsp, 0x08
00007e55d47e193e  push rax
00007e55d47e193f  push rcx
00007e55d47e1940  push rdx
00007e55d47e1941  push rdi
00007e55d47e1942  push rsi
00007e55d47e1943  push r8
00007e55d47e1945  push r9
00007e55d47e1947  push r10
00007e55d47e1949  push r11
00007e55d47e194b  sub rsp, 0xF0
00007e55d47e1952  vmovaps [rsp], xmm0
00007e55d47e1957  vmovaps [rsp+0x10], xmm2
00007e55d47e195d  vmovaps [rsp+0x20], xmm3
00007e55d47e1963  vmovaps [rsp+0x30], xmm4
00007e55d47e1969  vmovaps [rsp+0x40], xmm5
00007e55d47e196f  vmovaps [rsp+0x50], xmm6
00007e55d47e1975  vmovaps [rsp+0x60], xmm7
00007e55d47e197b  vmovaps [rsp+0x70], xmm8
00007e55d47e1981  vmovaps [rsp+0x80], xmm9
00007e55d47e198a  vmovaps [rsp+0x90], xmm10
00007e55d47e1993  vmovaps [rsp+0xA0], xmm11
00007e55d47e199c  vmovaps [rsp+0xB0], xmm12
00007e55d47e19a5  vmovaps [rsp+0xC0], xmm13
00007e55d47e19ae  vmovaps [rsp+0xD0], xmm14
00007e55d47e19b7  vmovaps [rsp+0xE0], xmm15
00007e55d47e19c0  sub rsp, 0x30
00007e55d47e19c4  movaps [rsp], xmm1
00007e55d47e19c8  movaps [rsp+0x10], xmm8
00007e55d47e19ce  movaps [rsp+0x20], xmm9
00007e55d47e19d4  lea rdi, [rsp]
00007e55d47e19d8  mov esi, 0x00
00007e55d47e19dd  mov rax, 0x55D0734A4530
00007e55d47e19e7  call rax
00007e55d47e19e9  movaps xmm1, [rsp]
00007e55d47e19ed  add rsp, 0x30
00007e55d47e19f1  vmovaps xmm0, [rsp]
00007e55d47e19f6  vmovaps xmm2, [rsp+0x10]
00007e55d47e19fc  vmovaps xmm3, [rsp+0x20]
00007e55d47e1a02  vmovaps xmm4, [rsp+0x30]
00007e55d47e1a08  vmovaps xmm5, [rsp+0x40]
00007e55d47e1a0e  vmovaps xmm6, [rsp+0x50]
00007e55d47e1a14  vmovaps xmm7, [rsp+0x60]
00007e55d47e1a1a  vmovaps xmm8, [rsp+0x70]
00007e55d47e1a20  vmovaps xmm9, [rsp+0x80]
00007e55d47e1a29  vmovaps xmm10, [rsp+0x90]
00007e55d47e1a32  vmovaps xmm11, [rsp+0xA0]
00007e55d47e1a3b  vmovaps xmm12, [rsp+0xB0]
00007e55d47e1a44  vmovaps xmm13, [rsp+0xC0]
00007e55d47e1a4d  vmovaps xmm14, [rsp+0xD0]
00007e55d47e1a56  vmovaps xmm15, [rsp+0xE0]
00007e55d47e1a5f  add rsp, 0xF0
00007e55d47e1a66  pop r11
00007e55d47e1a68  pop r10
00007e55d47e1a6a  pop r9
00007e55d47e1a6c  pop r8
00007e55d47e1a6e  pop rsi
00007e55d47e1a6f  pop rdi
00007e55d47e1a70  pop rdx
00007e55d47e1a71  pop rcx
00007e55d47e1a72  pop rax
00007e55d47e1a73  add rsp, 0x08
00007e55d47e1a77  jmp 0x00007E55D47DC865
00007e55d47e1a7c  call 0x00007E55D46E5940
00007e55d47e1a81  jmp 0x00007E55D47DC873
00007e55d47e1a86  call 0x00007E55D460C380
00007e55d47e1a8b  jmp 0x00007E55D47DC87D
00007e55d47e1a90  call 0x00007E55D460D600
00007e55d47e1a95  jmp 0x00007E55D47DC887
00007e55d47e1a9a  call 0x00007E55D45FF540
00007e55d47e1a9f  jmp 0x00007E55D47DC891
00007e55d47e1aa4  int3
00007e55d47e1aa5  nop [rax+rax*1], ax
00007e55d47e1aae  nop
00007e55d47e1ab0  mov rax, [r15+0xF8]
00007e55d47e1ab7  lea r14, [rax+0x140]
00007e55d47e1abe  mov r12, [r13+r14*1]
00007e55d47e1ac3  mov [r15+0xE8], r12
00007e55d47e1aca  lea r14, [rax+0x130]
00007e55d47e1ad1  mov r12, [r13+r14*1]
00007e55d47e1ad6  lea r14, [rax+0x138]
00007e55d47e1add  mov r11, [r13+r14*1]
00007e55d47e1ae2  movq xmm1, r12
00007e55d47e1ae7  movq xmm15, r11
00007e55d47e1aec  movq xmm1, xmm1
00007e55d47e1af0  movq xmm1, xmm1
00007e55d47e1af4  movaps [r15+0x1A0], xmm1
00007e55d47e1afc  movq xmm15, xmm15
00007e55d47e1b01  movq xmm15, xmm15
00007e55d47e1b06  movaps [r15+0x190], xmm15
00007e55d47e1b0e  lea r14, [rax+0x120]
00007e55d47e1b15  mov r12, [r13+r14*1]
00007e55d47e1b1a  lea r14, [rax+0x128]
00007e55d47e1b21  mov r11, [r13+r14*1]
00007e55d47e1b26  movq xmm1, r12
00007e55d47e1b2b  movq xmm15, r11
00007e55d47e1b30  movq xmm1, xmm1
00007e55d47e1b34  movq xmm1, xmm1
00007e55d47e1b38  movaps [r15+0x1C0], xmm1
00007e55d47e1b40  movq xmm15, xmm15
00007e55d47e1b45  movq xmm15, xmm15
00007e55d47e1b4a  movaps [r15+0x1B0], xmm15
00007e55d47e1b52  lea r14, [rax+0x110]
00007e55d47e1b59  mov r12, [r13+r14*1]
00007e55d47e1b5e  lea r14, [rax+0x118]
00007e55d47e1b65  mov r11, [r13+r14*1]
00007e55d47e1b6a  movq xmm1, r12
00007e55d47e1b6f  movq xmm15, r11
00007e55d47e1b74  movq xmm1, xmm1
00007e55d47e1b78  movq xmm1, xmm1
00007e55d47e1b7c  movaps [r15+0x1E0], xmm1
00007e55d47e1b84  movq xmm15, xmm15
00007e55d47e1b89  movq xmm15, xmm15
00007e55d47e1b8e  movaps [r15+0x1D0], xmm15
00007e55d47e1b96  lea r14, [rax+0x100]
00007e55d47e1b9d  mov r12, [r13+r14*1]
00007e55d47e1ba2  lea r14, [rax+0x108]
00007e55d47e1ba9  mov r11, [r13+r14*1]
00007e55d47e1bae  movq xmm1, r12
00007e55d47e1bb3  movq xmm15, r11
00007e55d47e1bb8  movq xmm1, xmm1
00007e55d47e1bbc  movq xmm1, xmm1
00007e55d47e1bc0  movaps [r15+0x200], xmm1
00007e55d47e1bc8  movq xmm15, xmm15
00007e55d47e1bcd  movq xmm15, xmm15
00007e55d47e1bd2  movaps [r15+0x1F0], xmm15
00007e55d47e1bda  mov qword ptr [r15+0x40], 0x430000
00007e55d47e1be2  mov r14d, 0x430510
00007e55d47e1be8  mov r12, [r13+r14*1]
00007e55d47e1bed  movq xmm1, r12
00007e55d47e1bf2  lea r14, [rax+0x150]
00007e55d47e1bf9  mov [r15+0xF8], r14
00007e55d47e1c00  mov rax, [r15+0x50]
00007e55d47e1c04  movups xmm15, [r13+rax*1]
00007e55d47e1c0a  movaps [r15+0x120], xmm15
00007e55d47e1c12  mov qword ptr [r15+0x48], 0x10
00007e55d47e1c1a  xor eax, eax
00007e55d47e1c1c  mov r14d, 0x10
00007e55d47e1c22  mov r12d, 0x200
00007e55d47e1c28  cmp r14, r12
00007e55d47e1c2b  cmc
00007e55d47e1c2c  lahf
00007e55d47e1c2d  seto al
00007e55d47e1c30  mov [r15+0x108], eax
00007e55d47e1c37  pextrq rax, xmm15, 0x01
00007e55d47e1c3e  movq xmm14, rax
00007e55d47e1c43  movaps [r15+0x130], xmm14
00007e55d47e1c4b  movq rax, xmm1
00007e55d47e1c50  movq r14, xmm15
00007e55d47e1c55  vmovq xmm1, rax
00007e55d47e1c5a  vmovq xmm15, r14
00007e55d47e1c5f  movaps xmm13, xmm1
00007e55d47e1c63  addsd xmm13, xmm15
00007e55d47e1c68  ucomisd xmm13, xmm13
00007e55d47e1c6d  jp 0x00007E55D47E1D86
00007e55d47e1c73  movq xmm13, xmm13
00007e55d47e1c78  movq rax, xmm13
00007e55d47e1c7d  movq r14, xmm14
00007e55d47e1c82  vmovq xmm1, rax
00007e55d47e1c87  vmovq xmm15, r14
00007e55d47e1c8c  movaps xmm14, xmm1
00007e55d47e1c90  addsd xmm14, xmm15
00007e55d47e1c95  ucomisd xmm14, xmm14
00007e55d47e1c9a  jp 0x00007E55D47E1DCE
00007e55d47e1ca0  movq xmm14, xmm14
00007e55d47e1ca5  movaps [r15+0x110], xmm14
00007e55d47e1cad  mov eax, [r15+0x108]
00007e55d47e1cb4  sahf
00007e55d47e1cb5  jnz 0x00007E55D47E1CE7
00007e55d47e1cb7  cmp dword ptr [r15+0x318], 0x00
00007e55d47e1cbf  jz 0x00007E55D47E1FE0
00007e55d47e1cc5  nop [rax+rax*1], ax
00007e55d47e1cce  nop [rax+rax*1], eax
00007e55d47e1cd6  mov eax, 0x410490
00007e55d47e1cdb  mov [r15+0x100], rax
00007e55d47e1ce2  jmp 0x00007E55D45FE110
00007e55d47e1ce7  cmp dword ptr [r15+0x318], 0x00
00007e55d47e1cef  jz 0x00007E55D47E1E20
00007e55d47e1cf5  nop [rax+rax*1], ax
00007e55d47e1cfe  nop [rax+rax*1], eax
00007e55d47e1d06  mov eax, 0x410474
00007e55d47e1d0b  mov [r15+0x100], rax
00007e55d47e1d12  jmp 0x00007E55D45FE110
00007e55d47e1d17  int3
00007e55d47e1d18  call 0x00007E55D46E27E0
00007e55d47e1d1d  jmp 0x00007E55D47E1AC3
00007e55d47e1d22  call 0x00007E55D46E27E0
00007e55d47e1d27  jmp 0x00007E55D47E1AD6
00007e55d47e1d2c  call 0x00007E55D46E1570
00007e55d47e1d31  jmp 0x00007E55D47E1AE2
00007e55d47e1d36  call 0x00007E55D46E27E0
00007e55d47e1d3b  jmp 0x00007E55D47E1B1A
00007e55d47e1d40  call 0x00007E55D46E1570
00007e55d47e1d45  jmp 0x00007E55D47E1B26
00007e55d47e1d4a  call 0x00007E55D46E27E0
00007e55d47e1d4f  jmp 0x00007E55D47E1B5E
00007e55d47e1d54  call 0x00007E55D46E1570
00007e55d47e1d59  jmp 0x00007E55D47E1B6A
00007e55d47e1d5e  call 0x00007E55D46E27E0
00007e55d47e1d63  jmp 0x00007E55D47E1BA2
00007e55d47e1d68  call 0x00007E55D46E1570
00007e55d47e1d6d  jmp 0x00007E55D47E1BAE
00007e55d47e1d72  call 0x00007E55D46E27E0
00007e55d47e1d77  jmp 0x00007E55D47E1BED
00007e55d47e1d7c  call 0x00007E55D460E760
00007e55d47e1d81  jmp 0x00007E55D47E1C0A
00007e55d47e1d86  ucomisd xmm1, xmm15
00007e55d47e1d8b  jp 0x00007E55D47E1D9A
00007e55d47e1d8d  movaps xmm13, [0x00007E55D43FE060]
00007e55d47e1d95  jmp 0x00007E55D47E1C73
00007e55d47e1d9a  vxorps xmm0, xmm1, xmm15
00007e55d47e1d9f  pextrw eax, xmm0, 0x03
00007e55d47e1da4  and eax, 0x7FF8
00007e55d47e1da9  cmp eax, 0x08
00007e55d47e1dac  jnz 0x00007E55D47E1C73
00007e55d47e1db2  movq rax, xmm15
00007e55d47e1db7  shl rax, 0x0D
00007e55d47e1dbb  jbe 0x00007E55D47E1C73
00007e55d47e1dc1  vorps xmm13, xmm15, [0x00007E55D43FE070]
00007e55d47e1dc9  jmp 0x00007E55D47E1C73
00007e55d47e1dce  ucomisd xmm1, xmm15
00007e55d47e1dd3  jp 0x00007E55D47E1DE2
00007e55d47e1dd5  movaps xmm14, [0x00007E55D43FE060]
00007e55d47e1ddd  jmp 0x00007E55D47E1CA0
00007e55d47e1de2  vxorps xmm0, xmm1, xmm15
00007e55d47e1de7  pextrw eax, xmm0, 0x03
00007e55d47e1dec  and eax, 0x7FF8
00007e55d47e1df1  cmp eax, 0x08
00007e55d47e1df4  jnz 0x00007E55D47E1CA0
00007e55d47e1dfa  movq rax, xmm15
00007e55d47e1dff  shl rax, 0x0D
00007e55d47e1e03  jbe 0x00007E55D47E1CA0
00007e55d47e1e09  vorps xmm14, xmm15, [0x00007E55D43FE070]
00007e55d47e1e11  jmp 0x00007E55D47E1CA0
00007e55d47e1e16  int3
00007e55d47e1e17  nop [rax+rax*1], ax
00007e55d47e1e20  mov rax, [r15+0x48]
00007e55d47e1e24  mov r14, [r15+0x50]
00007e55d47e1e28  lea r12, [r14+rax*1]
00007e55d47e1e2c  movups xmm1, [r13+r12*1]
00007e55d47e1e32  movaps [r15+0x120], xmm1
00007e55d47e1e3a  lea r14, [rax+0x10]
00007e55d47e1e3e  mov [r15+0x48], r14
00007e55d47e1e42  xor eax, eax
00007e55d47e1e44  mov r12d, 0x200
00007e55d47e1e4a  cmp r14, r12
00007e55d47e1e4d  cmc
00007e55d47e1e4e  lahf
00007e55d47e1e4f  seto al
00007e55d47e1e52  mov [r15+0x108], eax
00007e55d47e1e59  pextrq rax, xmm1, 0x01
00007e55d47e1e60  movq xmm15, rax
00007e55d47e1e65  movaps [r15+0x130], xmm15
00007e55d47e1e6d  movaps xmm14, [r15+0x110]
00007e55d47e1e75  movq rax, xmm14
00007e55d47e1e7a  movq r14, xmm1
00007e55d47e1e7f  vmovq xmm1, rax
00007e55d47e1e84  vmovq xmm14, r14
00007e55d47e1e89  movaps xmm13, xmm1
00007e55d47e1e8d  addsd xmm13, xmm14
00007e55d47e1e92  ucomisd xmm13, xmm13
00007e55d47e1e97  jp 0x00007E55D47E1F4C
00007e55d47e1e9d  movq xmm13, xmm13
00007e55d47e1ea2  movq rax, xmm13
00007e55d47e1ea7  movq r14, xmm15
00007e55d47e1eac  vmovq xmm1, rax
00007e55d47e1eb1  vmovq xmm15, r14
00007e55d47e1eb6  movaps xmm14, xmm1
00007e55d47e1eba  addsd xmm14, xmm15
00007e55d47e1ebf  ucomisd xmm14, xmm14
00007e55d47e1ec4  jp 0x00007E55D47E1F94
00007e55d47e1eca  movq xmm14, xmm14
00007e55d47e1ecf  movaps [r15+0x110], xmm14
00007e55d47e1ed7  mov eax, [r15+0x108]
00007e55d47e1ede  sahf
00007e55d47e1edf  jnz 0x00007E55D47E1F11
00007e55d47e1ee1  cmp dword ptr [r15+0x318], 0x00
00007e55d47e1ee9  jz 0x00007E55D47E1FE0
00007e55d47e1eef  nop [rax+rax*1], ax
00007e55d47e1ef8  nop [rax+rax*1], eax
00007e55d47e1f00  mov eax, 0x410490
00007e55d47e1f05  mov [r15+0x100], rax
00007e55d47e1f0c  jmp 0x00007E55D45FE110
00007e55d47e1f11  cmp dword ptr [r15+0x318], 0x00
00007e55d47e1f19  jz 0x00007E55D47E1E20
00007e55d47e1f1f  nop [rax+rax*1], ax
00007e55d47e1f28  nop [rax+rax*1], eax
00007e55d47e1f30  mov eax, 0x410474
00007e55d47e1f35  mov [r15+0x100], rax
00007e55d47e1f3c  jmp 0x00007E55D45FE110
00007e55d47e1f41  int3
00007e55d47e1f42  call 0x00007E55D46B52F0
00007e55d47e1f47  jmp 0x00007E55D47E1E32
00007e55d47e1f4c  ucomisd xmm1, xmm14
00007e55d47e1f51  jp 0x00007E55D47E1F60
00007e55d47e1f53  movaps xmm13, [0x00007E55D43FE060]
00007e55d47e1f5b  jmp 0x00007E55D47E1E9D
00007e55d47e1f60  vxorps xmm0, xmm1, xmm14
00007e55d47e1f65  pextrw eax, xmm0, 0x03
00007e55d47e1f6a  and eax, 0x7FF8
00007e55d47e1f6f  cmp eax, 0x08
00007e55d47e1f72  jnz 0x00007E55D47E1E9D
00007e55d47e1f78  movq rax, xmm14
00007e55d47e1f7d  shl rax, 0x0D
00007e55d47e1f81  jbe 0x00007E55D47E1E9D
00007e55d47e1f87  vorps xmm13, xmm14, [0x00007E55D43FE070]
00007e55d47e1f8f  jmp 0x00007E55D47E1E9D
00007e55d47e1f94  ucomisd xmm1, xmm15
00007e55d47e1f99  jp 0x00007E55D47E1FA8
00007e55d47e1f9b  movaps xmm14, [0x00007E55D43FE060]
00007e55d47e1fa3  jmp 0x00007E55D47E1ECA
00007e55d47e1fa8  vxorps xmm0, xmm1, xmm15
00007e55d47e1fad  pextrw eax, xmm0, 0x03
00007e55d47e1fb2  and eax, 0x7FF8
00007e55d47e1fb7  cmp eax, 0x08
00007e55d47e1fba  jnz 0x00007E55D47E1ECA
00007e55d47e1fc0  movq rax, xmm15
00007e55d47e1fc5  shl rax, 0x0D
00007e55d47e1fc9  jbe 0x00007E55D47E1ECA
00007e55d47e1fcf  vorps xmm14, xmm15, [0x00007E55D43FE070]
00007e55d47e1fd7  jmp 0x00007E55D47E1ECA
00007e55d47e1fdc  int3
00007e55d47e1fdd  nop [rax], eax
00007e55d47e1fe0  mov rax, [r15+0x40]
00007e55d47e1fe4  lea r14, [rax+0x510]
00007e55d47e1feb  movaps xmm1, [r15+0x110]
00007e55d47e1ff3  movq rax, xmm1
00007e55d47e1ff8  mov [r13+r14*1], rax
00007e55d47e1ffd  mov rax, [r15+0xF0]
00007e55d47e2004  mov [r15+0x100], rax
00007e55d47e200b  jmp 0x00007E55D47CE5C0
00007e55d47e2010  int3
00007e55d47e2011  call 0x00007E55D46D5EB0
00007e55d47e2016  jmp 0x00007E55D47E1FFD
00007e55d47e201b  int3
00007e55d47e201c  nop [rax], eax
00007e55d47e2020  mov qword ptr [r15+0x100], 0x04
00007e55d47e202b  mov esi, 0x00
00007e55d47e2030  mov edx, 0x09
00007e55d47e2035  mov rdi, 0x7FFD7B911990
00007e55d47e203f  mov rax, 0x55D073337970
00007e55d47e2049  call rax
00007e55d47e204b  cmp dword ptr [r15+0x318], 0x00
00007e55d47e2053  jnz 0x00007E55D45FE110
00007e55d47e2059  jmp 0x00007E55D45FE0A0
00007e55d47e205e  int3
00007e55d47e205f  int3
