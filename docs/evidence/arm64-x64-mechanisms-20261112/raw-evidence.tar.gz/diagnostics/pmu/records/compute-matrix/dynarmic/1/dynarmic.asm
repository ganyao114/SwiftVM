000076049b1ce69b  nop [rax+rax*1], eax
000076049b1ce6a0  vmovaps xmm1, [0x000076049ADFE010]
000076049b1ce6a8  movq xmm1, xmm1
000076049b1ce6ac  movaps [r15+0x110], xmm1
000076049b1ce6b4  vmovaps xmm1, [0x000076049ADFE020]
000076049b1ce6bc  movq xmm1, xmm1
000076049b1ce6c0  movaps [r15+0x120], xmm1
000076049b1ce6c8  mov eax, 0x4204C0
000076049b1ce6cd  mov r14, [r13+rax*1]
000076049b1ce6d2  movq xmm1, r14
000076049b1ce6d7  movaps [r15+0x130], xmm1
000076049b1ce6df  vmovaps xmm1, [0x000076049ADFE030]
000076049b1ce6e7  vpbroadcastq xmm1, xmm1
000076049b1ce6ec  movaps [r15+0x140], xmm1
000076049b1ce6f4  mov qword ptr [r15+0x40], 0x02
000076049b1ce6fc  vmovaps xmm15, [0x000076049ADFE040]
000076049b1ce704  movq xmm15, xmm15
000076049b1ce709  movaps [r15+0x150], xmm15
000076049b1ce711  mov qword ptr [r15+0x58], 0x420000
000076049b1ce719  vmovaps xmm15, [0x000076049ADFE050]
000076049b1ce721  vpbroadcastq xmm15, xmm15
000076049b1ce726  movaps [r15+0x160], xmm15
000076049b1ce72e  mov rax, [r15+0x40]
000076049b1ce732  vmovq xmm14, rax
000076049b1ce737  vpbroadcastq xmm14, xmm14
000076049b1ce73c  movaps [r15+0x170], xmm14
000076049b1ce744  mov eax, 0x4204D0
000076049b1ce749  movups xmm13, [r13+rax*1]
000076049b1ce74f  mov qword ptr [r15+0x40], 0x430518
000076049b1ce757  mov qword ptr [r15+0x50], 0x430720
000076049b1ce75f  vpmovqd xmm12, xmm13
000076049b1ce765  pxor xmm11, xmm11
000076049b1ce76a  punpcklqdq xmm12, xmm11
000076049b1ce76f  movaps [r15+0x210], xmm12
000076049b1ce777  movq xmm12, qword ptr [r15+0x120]
000076049b1ce780  movq xmm11, qword ptr [r15+0x130]
000076049b1ce789  psubd xmm12, xmm11
000076049b1ce78e  movq xmm12, xmm12
000076049b1ce793  paddq xmm13, xmm14
000076049b1ce798  movaps [r15+0x180], xmm13
000076049b1ce7a0  movq xmm14, qword ptr [r15+0x150]
000076049b1ce7a9  paddd xmm11, xmm14
000076049b1ce7ae  movq xmm11, xmm11
000076049b1ce7b3  movq xmm11, xmm11
000076049b1ce7b8  movaps [r15+0x130], xmm11
000076049b1ce7c0  pmovzxdq xmm12, xmm12
000076049b1ce7c6  psllq xmm12, 0x00
000076049b1ce7cc  movq xmm14, qword ptr [r15+0x210]
000076049b1ce7d5  movq xmm13, qword ptr [r15+0x110]
000076049b1ce7de  paddd xmm14, xmm13
000076049b1ce7e3  movq xmm14, xmm14
000076049b1ce7e8  vcvtuqq2pd xmm12, xmm12
000076049b1ce7ee  pmovzxdq xmm14, xmm14
000076049b1ce7f4  psllq xmm14, 0x00
000076049b1ce7fa  vcvtuqq2pd xmm14, xmm14
000076049b1ce800  movaps xmm13, xmm12
000076049b1ce804  mulpd xmm13, xmm1
000076049b1ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000076049b1ce80f  ptest xmm11, xmm11
000076049b1ce815  jnz 0x000076049B1CE8FF
000076049b1ce81b  movaps [r15+0x220], xmm13
000076049b1ce823  mov eax, 0x430720
000076049b1ce828  movups [r13+rax*1], xmm13
000076049b1ce82e  movaps xmm1, xmm14
000076049b1ce832  mulpd xmm1, xmm15
000076049b1ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000076049b1ce83c  ptest xmm13, xmm13
000076049b1ce842  jnz 0x000076049B1CEA4C
000076049b1ce848  movaps [r15+0x210], xmm1
000076049b1ce850  mov eax, 0x430518
000076049b1ce855  movups [r13+rax*1], xmm1
000076049b1ce85b  mov qword ptr [r15+0x48], 0x10
000076049b1ce863  xor eax, eax
000076049b1ce865  mov r14d, 0x10
000076049b1ce86b  mov r12d, 0x200
000076049b1ce871  cmp r14, r12
000076049b1ce874  cmc
000076049b1ce875  lahf
000076049b1ce876  seto al
000076049b1ce879  mov [r15+0x108], eax
000076049b1ce880  mov eax, [r15+0x108]
000076049b1ce887  sahf
000076049b1ce888  jnz 0x000076049B1CE8BA
000076049b1ce88a  cmp dword ptr [r15+0x318], 0x00
000076049b1ce892  jz 0x000076049B1CEFF0
000076049b1ce898  nop [rax+rax*1], ax
000076049b1ce8a1  nop [rax+rax*1], eax
000076049b1ce8a9  mov eax, 0x4101EC
000076049b1ce8ae  mov [r15+0x100], rax
000076049b1ce8b5  jmp 0x000076049AFFE110
000076049b1ce8ba  cmp dword ptr [r15+0x318], 0x00
000076049b1ce8c2  jz 0x000076049B1CEBA0
000076049b1ce8c8  nop [rax+rax*1], ax
000076049b1ce8d1  nop [rax+rax*1], eax
000076049b1ce8d9  mov eax, 0x4101AC
000076049b1ce8de  mov [r15+0x100], rax
000076049b1ce8e5  jmp 0x000076049AFFE110
000076049b1ce8ea  int3
000076049b1ce8eb  call 0x000076049B00DC20
000076049b1ce8f0  jmp 0x000076049B1CE6D2
000076049b1ce8f5  call 0x000076049B00C260
000076049b1ce8fa  jmp 0x000076049B1CE74F
000076049b1ce8ff  sub rsp, 0x08
000076049b1ce903  push rax
000076049b1ce904  push rcx
000076049b1ce905  push rdx
000076049b1ce906  push rdi
000076049b1ce907  push rsi
000076049b1ce908  push r8
000076049b1ce90a  push r9
000076049b1ce90c  push r10
000076049b1ce90e  push r11
000076049b1ce910  sub rsp, 0xF0
000076049b1ce917  vmovaps [rsp], xmm0
000076049b1ce91c  vmovaps [rsp+0x10], xmm1
000076049b1ce922  vmovaps [rsp+0x20], xmm2
000076049b1ce928  vmovaps [rsp+0x30], xmm3
000076049b1ce92e  vmovaps [rsp+0x40], xmm4
000076049b1ce934  vmovaps [rsp+0x50], xmm5
000076049b1ce93a  vmovaps [rsp+0x60], xmm6
000076049b1ce940  vmovaps [rsp+0x70], xmm7
000076049b1ce946  vmovaps [rsp+0x80], xmm8
000076049b1ce94f  vmovaps [rsp+0x90], xmm9
000076049b1ce958  vmovaps [rsp+0xA0], xmm10
000076049b1ce961  vmovaps [rsp+0xB0], xmm11
000076049b1ce96a  vmovaps [rsp+0xC0], xmm12
000076049b1ce973  vmovaps [rsp+0xD0], xmm14
000076049b1ce97c  vmovaps [rsp+0xE0], xmm15
000076049b1ce985  sub rsp, 0x30
000076049b1ce989  movaps [rsp], xmm13
000076049b1ce98e  movaps [rsp+0x10], xmm12
000076049b1ce994  movaps [rsp+0x20], xmm1
000076049b1ce999  lea rdi, [rsp]
000076049b1ce99d  mov esi, 0x00
000076049b1ce9a2  mov rax, 0x64C06813C530
000076049b1ce9ac  call rax
000076049b1ce9ae  movaps xmm13, [rsp]
000076049b1ce9b3  add rsp, 0x30
000076049b1ce9b7  vmovaps xmm0, [rsp]
000076049b1ce9bc  vmovaps xmm1, [rsp+0x10]
000076049b1ce9c2  vmovaps xmm2, [rsp+0x20]
000076049b1ce9c8  vmovaps xmm3, [rsp+0x30]
000076049b1ce9ce  vmovaps xmm4, [rsp+0x40]
000076049b1ce9d4  vmovaps xmm5, [rsp+0x50]
000076049b1ce9da  vmovaps xmm6, [rsp+0x60]
000076049b1ce9e0  vmovaps xmm7, [rsp+0x70]
000076049b1ce9e6  vmovaps xmm8, [rsp+0x80]
000076049b1ce9ef  vmovaps xmm9, [rsp+0x90]
000076049b1ce9f8  vmovaps xmm10, [rsp+0xA0]
000076049b1cea01  vmovaps xmm11, [rsp+0xB0]
000076049b1cea0a  vmovaps xmm12, [rsp+0xC0]
000076049b1cea13  vmovaps xmm14, [rsp+0xD0]
000076049b1cea1c  vmovaps xmm15, [rsp+0xE0]
000076049b1cea25  add rsp, 0xF0
000076049b1cea2c  pop r11
000076049b1cea2e  pop r10
000076049b1cea30  pop r9
000076049b1cea32  pop r8
000076049b1cea34  pop rsi
000076049b1cea35  pop rdi
000076049b1cea36  pop rdx
000076049b1cea37  pop rcx
000076049b1cea38  pop rax
000076049b1cea39  add rsp, 0x08
000076049b1cea3d  jmp 0x000076049B1CE81B
000076049b1cea42  call 0x000076049B00C380
000076049b1cea47  jmp 0x000076049B1CE82E
000076049b1cea4c  sub rsp, 0x08
000076049b1cea50  push rax
000076049b1cea51  push rcx
000076049b1cea52  push rdx
000076049b1cea53  push rdi
000076049b1cea54  push rsi
000076049b1cea55  push r8
000076049b1cea57  push r9
000076049b1cea59  push r10
000076049b1cea5b  push r11
000076049b1cea5d  sub rsp, 0xF0
000076049b1cea64  vmovaps [rsp], xmm0
000076049b1cea69  vmovaps [rsp+0x10], xmm2
000076049b1cea6f  vmovaps [rsp+0x20], xmm3
000076049b1cea75  vmovaps [rsp+0x30], xmm4
000076049b1cea7b  vmovaps [rsp+0x40], xmm5
000076049b1cea81  vmovaps [rsp+0x50], xmm6
000076049b1cea87  vmovaps [rsp+0x60], xmm7
000076049b1cea8d  vmovaps [rsp+0x70], xmm8
000076049b1cea93  vmovaps [rsp+0x80], xmm9
000076049b1cea9c  vmovaps [rsp+0x90], xmm10
000076049b1ceaa5  vmovaps [rsp+0xA0], xmm11
000076049b1ceaae  vmovaps [rsp+0xB0], xmm12
000076049b1ceab7  vmovaps [rsp+0xC0], xmm13
000076049b1ceac0  vmovaps [rsp+0xD0], xmm14
000076049b1ceac9  vmovaps [rsp+0xE0], xmm15
000076049b1cead2  sub rsp, 0x30
000076049b1cead6  movaps [rsp], xmm1
000076049b1ceada  movaps [rsp+0x10], xmm14
000076049b1ceae0  movaps [rsp+0x20], xmm15
000076049b1ceae6  lea rdi, [rsp]
000076049b1ceaea  mov esi, 0x00
000076049b1ceaef  mov rax, 0x64C06813C530
000076049b1ceaf9  call rax
000076049b1ceafb  movaps xmm1, [rsp]
000076049b1ceaff  add rsp, 0x30
000076049b1ceb03  vmovaps xmm0, [rsp]
000076049b1ceb08  vmovaps xmm2, [rsp+0x10]
000076049b1ceb0e  vmovaps xmm3, [rsp+0x20]
000076049b1ceb14  vmovaps xmm4, [rsp+0x30]
000076049b1ceb1a  vmovaps xmm5, [rsp+0x40]
000076049b1ceb20  vmovaps xmm6, [rsp+0x50]
000076049b1ceb26  vmovaps xmm7, [rsp+0x60]
000076049b1ceb2c  vmovaps xmm8, [rsp+0x70]
000076049b1ceb32  vmovaps xmm9, [rsp+0x80]
000076049b1ceb3b  vmovaps xmm10, [rsp+0x90]
000076049b1ceb44  vmovaps xmm11, [rsp+0xA0]
000076049b1ceb4d  vmovaps xmm12, [rsp+0xB0]
000076049b1ceb56  vmovaps xmm13, [rsp+0xC0]
000076049b1ceb5f  vmovaps xmm14, [rsp+0xD0]
000076049b1ceb68  vmovaps xmm15, [rsp+0xE0]
000076049b1ceb71  add rsp, 0xF0
000076049b1ceb78  pop r11
000076049b1ceb7a  pop r10
000076049b1ceb7c  pop r9
000076049b1ceb7e  pop r8
000076049b1ceb80  pop rsi
000076049b1ceb81  pop rdi
000076049b1ceb82  pop rdx
000076049b1ceb83  pop rcx
000076049b1ceb84  pop rax
000076049b1ceb85  add rsp, 0x08
000076049b1ceb89  jmp 0x000076049B1CE848
000076049b1ceb8e  call 0x000076049AFFF540
000076049b1ceb93  jmp 0x000076049B1CE85B
000076049b1ceb98  int3
000076049b1ceb99  nop [rax], eax
000076049b1ceba0  movaps xmm1, [r15+0x180]
000076049b1ceba8  vpmovqd xmm15, xmm1
000076049b1cebae  pxor xmm14, xmm14
000076049b1cebb3  punpcklqdq xmm15, xmm14
000076049b1cebb8  movaps [r15+0x210], xmm15
000076049b1cebc0  movq xmm15, qword ptr [r15+0x120]
000076049b1cebc9  movq xmm14, qword ptr [r15+0x130]
000076049b1cebd2  psubd xmm15, xmm14
000076049b1cebd7  movq xmm15, xmm15
000076049b1cebdc  movaps xmm13, [r15+0x170]
000076049b1cebe4  paddq xmm1, xmm13
000076049b1cebe9  movaps [r15+0x180], xmm1
000076049b1cebf1  movq xmm1, qword ptr [r15+0x150]
000076049b1cebfa  paddd xmm14, xmm1
000076049b1cebff  movq xmm14, xmm14
000076049b1cec04  movq xmm14, xmm14
000076049b1cec09  movaps [r15+0x130], xmm14
000076049b1cec11  pmovzxdq xmm15, xmm15
000076049b1cec17  psllq xmm15, 0x00
000076049b1cec1d  movq xmm1, qword ptr [r15+0x210]
000076049b1cec26  movq xmm14, qword ptr [r15+0x110]
000076049b1cec2f  paddd xmm1, xmm14
000076049b1cec34  movq xmm1, xmm1
000076049b1cec38  vcvtuqq2pd xmm15, xmm15
000076049b1cec3e  pmovzxdq xmm1, xmm1
000076049b1cec43  psllq xmm1, 0x00
000076049b1cec48  vcvtuqq2pd xmm1, xmm1
000076049b1cec4e  movaps xmm14, [r15+0x140]
000076049b1cec56  movaps xmm13, xmm15
000076049b1cec5a  mulpd xmm13, xmm14
000076049b1cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000076049b1cec65  ptest xmm12, xmm12
000076049b1cec6b  jnz 0x000076049B1CED4E
000076049b1cec71  movaps [r15+0x220], xmm13
000076049b1cec79  mov rax, [r15+0x48]
000076049b1cec7d  mov r14, [r15+0x50]
000076049b1cec81  lea r12, [r14+rax*1]
000076049b1cec85  movups [r13+r12*1], xmm13
000076049b1cec8b  movaps xmm15, [r15+0x160]
000076049b1cec93  movaps xmm14, xmm1
000076049b1cec97  mulpd xmm14, xmm15
000076049b1cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000076049b1ceca2  ptest xmm13, xmm13
000076049b1ceca8  jnz 0x000076049B1CEE9C
000076049b1cecae  movaps [r15+0x210], xmm14
000076049b1cecb6  mov r14, [r15+0x40]
000076049b1cecba  lea r12, [r14+rax*1]
000076049b1cecbe  movups [r13+r12*1], xmm14
000076049b1cecc4  lea r14, [rax+0x10]
000076049b1cecc8  mov [r15+0x48], r14
000076049b1ceccc  xor eax, eax
000076049b1cecce  mov r12d, 0x200
000076049b1cecd4  cmp r14, r12
000076049b1cecd7  cmc
000076049b1cecd8  lahf
000076049b1cecd9  seto al
000076049b1cecdc  mov [r15+0x108], eax
000076049b1cece3  mov eax, [r15+0x108]
000076049b1cecea  sahf
000076049b1ceceb  jnz 0x000076049B1CED1D
000076049b1ceced  cmp dword ptr [r15+0x318], 0x00
000076049b1cecf5  jz 0x000076049B1CEFF0
000076049b1cecfb  nop [rax+rax*1], ax
000076049b1ced04  nop [rax+rax*1], eax
000076049b1ced0c  mov eax, 0x4101EC
000076049b1ced11  mov [r15+0x100], rax
000076049b1ced18  jmp 0x000076049AFFE110
000076049b1ced1d  cmp dword ptr [r15+0x318], 0x00
000076049b1ced25  jz 0x000076049B1CEBA0
000076049b1ced2b  nop [rax+rax*1], ax
000076049b1ced34  nop [rax+rax*1], eax
000076049b1ced3c  mov eax, 0x4101AC
000076049b1ced41  mov [r15+0x100], rax
000076049b1ced48  jmp 0x000076049AFFE110
000076049b1ced4d  int3
000076049b1ced4e  sub rsp, 0x08
000076049b1ced52  push rax
000076049b1ced53  push rcx
000076049b1ced54  push rdx
000076049b1ced55  push rdi
000076049b1ced56  push rsi
000076049b1ced57  push r8
000076049b1ced59  push r9
000076049b1ced5b  push r10
000076049b1ced5d  push r11
000076049b1ced5f  sub rsp, 0xF0
000076049b1ced66  vmovaps [rsp], xmm0
000076049b1ced6b  vmovaps [rsp+0x10], xmm1
000076049b1ced71  vmovaps [rsp+0x20], xmm2
000076049b1ced77  vmovaps [rsp+0x30], xmm3
000076049b1ced7d  vmovaps [rsp+0x40], xmm4
000076049b1ced83  vmovaps [rsp+0x50], xmm5
000076049b1ced89  vmovaps [rsp+0x60], xmm6
000076049b1ced8f  vmovaps [rsp+0x70], xmm7
000076049b1ced95  vmovaps [rsp+0x80], xmm8
000076049b1ced9e  vmovaps [rsp+0x90], xmm9
000076049b1ceda7  vmovaps [rsp+0xA0], xmm10
000076049b1cedb0  vmovaps [rsp+0xB0], xmm11
000076049b1cedb9  vmovaps [rsp+0xC0], xmm12
000076049b1cedc2  vmovaps [rsp+0xD0], xmm14
000076049b1cedcb  vmovaps [rsp+0xE0], xmm15
000076049b1cedd4  sub rsp, 0x30
000076049b1cedd8  movaps [rsp], xmm13
000076049b1ceddd  movaps [rsp+0x10], xmm15
000076049b1cede3  movaps [rsp+0x20], xmm14
000076049b1cede9  lea rdi, [rsp]
000076049b1ceded  mov esi, 0x00
000076049b1cedf2  mov rax, 0x64C06813C530
000076049b1cedfc  call rax
000076049b1cedfe  movaps xmm13, [rsp]
000076049b1cee03  add rsp, 0x30
000076049b1cee07  vmovaps xmm0, [rsp]
000076049b1cee0c  vmovaps xmm1, [rsp+0x10]
000076049b1cee12  vmovaps xmm2, [rsp+0x20]
000076049b1cee18  vmovaps xmm3, [rsp+0x30]
000076049b1cee1e  vmovaps xmm4, [rsp+0x40]
000076049b1cee24  vmovaps xmm5, [rsp+0x50]
000076049b1cee2a  vmovaps xmm6, [rsp+0x60]
000076049b1cee30  vmovaps xmm7, [rsp+0x70]
000076049b1cee36  vmovaps xmm8, [rsp+0x80]
000076049b1cee3f  vmovaps xmm9, [rsp+0x90]
000076049b1cee48  vmovaps xmm10, [rsp+0xA0]
000076049b1cee51  vmovaps xmm11, [rsp+0xB0]
000076049b1cee5a  vmovaps xmm12, [rsp+0xC0]
000076049b1cee63  vmovaps xmm14, [rsp+0xD0]
000076049b1cee6c  vmovaps xmm15, [rsp+0xE0]
000076049b1cee75  add rsp, 0xF0
000076049b1cee7c  pop r11
000076049b1cee7e  pop r10
000076049b1cee80  pop r9
000076049b1cee82  pop r8
000076049b1cee84  pop rsi
000076049b1cee85  pop rdi
000076049b1cee86  pop rdx
000076049b1cee87  pop rcx
000076049b1cee88  pop rax
000076049b1cee89  add rsp, 0x08
000076049b1cee8d  jmp 0x000076049B1CEC71
000076049b1cee92  call 0x000076049B0C2240
000076049b1cee97  jmp 0x000076049B1CEC8B
000076049b1cee9c  sub rsp, 0x08
000076049b1ceea0  push rax
000076049b1ceea1  push rcx
000076049b1ceea2  push rdx
000076049b1ceea3  push rdi
000076049b1ceea4  push rsi
000076049b1ceea5  push r8
000076049b1ceea7  push r9
000076049b1ceea9  push r10
000076049b1ceeab  push r11
000076049b1ceead  sub rsp, 0xF0
000076049b1ceeb4  vmovaps [rsp], xmm0
000076049b1ceeb9  vmovaps [rsp+0x10], xmm1
000076049b1ceebf  vmovaps [rsp+0x20], xmm2
000076049b1ceec5  vmovaps [rsp+0x30], xmm3
000076049b1ceecb  vmovaps [rsp+0x40], xmm4
000076049b1ceed1  vmovaps [rsp+0x50], xmm5
000076049b1ceed7  vmovaps [rsp+0x60], xmm6
000076049b1ceedd  vmovaps [rsp+0x70], xmm7
000076049b1ceee3  vmovaps [rsp+0x80], xmm8
000076049b1ceeec  vmovaps [rsp+0x90], xmm9
000076049b1ceef5  vmovaps [rsp+0xA0], xmm10
000076049b1ceefe  vmovaps [rsp+0xB0], xmm11
000076049b1cef07  vmovaps [rsp+0xC0], xmm12
000076049b1cef10  vmovaps [rsp+0xD0], xmm13
000076049b1cef19  vmovaps [rsp+0xE0], xmm15
000076049b1cef22  sub rsp, 0x30
000076049b1cef26  movaps [rsp], xmm14
000076049b1cef2b  movaps [rsp+0x10], xmm1
000076049b1cef30  movaps [rsp+0x20], xmm15
000076049b1cef36  lea rdi, [rsp]
000076049b1cef3a  mov esi, 0x00
000076049b1cef3f  mov rax, 0x64C06813C530
000076049b1cef49  call rax
000076049b1cef4b  movaps xmm14, [rsp]
000076049b1cef50  add rsp, 0x30
000076049b1cef54  vmovaps xmm0, [rsp]
000076049b1cef59  vmovaps xmm1, [rsp+0x10]
000076049b1cef5f  vmovaps xmm2, [rsp+0x20]
000076049b1cef65  vmovaps xmm3, [rsp+0x30]
000076049b1cef6b  vmovaps xmm4, [rsp+0x40]
000076049b1cef71  vmovaps xmm5, [rsp+0x50]
000076049b1cef77  vmovaps xmm6, [rsp+0x60]
000076049b1cef7d  vmovaps xmm7, [rsp+0x70]
000076049b1cef83  vmovaps xmm8, [rsp+0x80]
000076049b1cef8c  vmovaps xmm9, [rsp+0x90]
000076049b1cef95  vmovaps xmm10, [rsp+0xA0]
000076049b1cef9e  vmovaps xmm11, [rsp+0xB0]
000076049b1cefa7  vmovaps xmm12, [rsp+0xC0]
000076049b1cefb0  vmovaps xmm13, [rsp+0xD0]
000076049b1cefb9  vmovaps xmm15, [rsp+0xE0]
000076049b1cefc2  add rsp, 0xF0
000076049b1cefc9  pop r11
000076049b1cefcb  pop r10
000076049b1cefcd  pop r9
000076049b1cefcf  pop r8
000076049b1cefd1  pop rsi
000076049b1cefd2  pop rdi
000076049b1cefd3  pop rdx
000076049b1cefd4  pop rcx
000076049b1cefd5  pop rax
000076049b1cefd6  add rsp, 0x08
000076049b1cefda  jmp 0x000076049B1CECAE
000076049b1cefdf  call 0x000076049B0C34C0
000076049b1cefe4  jmp 0x000076049B1CECC4
000076049b1cefe9  int3
000076049b1cefea  nop [rax+rax*1], ax
000076049b1ceff0  mov rax, [r15+0xF8]
000076049b1ceff7  lea r14, [rax-0x150]
000076049b1ceffe  mov [r15+0xF8], r14
000076049b1cf005  mov rax, [r15+0x50]
000076049b1cf009  lea r12, [rax+0x80]
000076049b1cf010  movups xmm1, [r13+r12*1]
000076049b1cf016  lea r12, [rax+0x90]
000076049b1cf01d  movups xmm15, [r13+r12*1]
000076049b1cf023  mov qword ptr [r15+0x48], 0x00
000076049b1cf02b  lea r12, [rax+0x40]
000076049b1cf02f  movups xmm14, [r13+r12*1]
000076049b1cf035  lea r12, [rax+0x50]
000076049b1cf039  movups xmm13, [r13+r12*1]
000076049b1cf03f  lea r12, [r14+0x120]
000076049b1cf046  movq xmm12, qword ptr [r15+0x1C0]
000076049b1cf04f  movq xmm11, qword ptr [r15+0x1B0]
000076049b1cf058  movq r11, xmm12
000076049b1cf05d  movq r10, xmm11
000076049b1cf062  mov [r13+r12*1], r11
000076049b1cf067  lea r12, [r14+0x128]
000076049b1cf06e  mov [r13+r12*1], r10
000076049b1cf073  vxorps xmm12, xmm12, xmm12
000076049b1cf078  vpbroadcastq xmm12, xmm12
000076049b1cf07d  lea r12, [r14+0x100]
000076049b1cf084  movq xmm11, qword ptr [r15+0x200]
000076049b1cf08d  movq xmm10, qword ptr [r15+0x1F0]
000076049b1cf096  movq r11, xmm11
000076049b1cf09b  movq r10, xmm10
000076049b1cf0a0  mov [r13+r12*1], r11
000076049b1cf0a5  lea r12, [r14+0x108]
000076049b1cf0ac  mov [r13+r12*1], r10
000076049b1cf0b1  lea r12, [r14+0xE0]
000076049b1cf0b8  movups [r13+r12*1], xmm15
000076049b1cf0be  lea r12, [r14+0xF0]
000076049b1cf0c5  movups [r13+r12*1], xmm1
000076049b1cf0cb  lea r12, [rax+0xC0]
000076049b1cf0d2  movups xmm1, [r13+r12*1]
000076049b1cf0d8  lea r12, [rax+0xD0]
000076049b1cf0df  movups xmm15, [r13+r12*1]
000076049b1cf0e5  lea r12, [r14+0x110]
000076049b1cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000076049b1cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000076049b1cf0fe  movq r11, xmm11
000076049b1cf103  movq r10, xmm10
000076049b1cf108  mov [r13+r12*1], r11
000076049b1cf10d  lea r12, [r14+0x118]
000076049b1cf114  mov [r13+r12*1], r10
000076049b1cf119  movups xmm11, [r13+rax*1]
000076049b1cf11f  lea r12, [rax+0x10]
000076049b1cf123  movups xmm10, [r13+r12*1]
000076049b1cf129  lea r12, [r14+0x130]
000076049b1cf130  movq xmm9, qword ptr [r15+0x1A0]
000076049b1cf139  movq xmm8, qword ptr [r15+0x190]
000076049b1cf142  movq r11, xmm9
000076049b1cf147  movq r10, xmm8
000076049b1cf14c  mov [r13+r12*1], r11
000076049b1cf151  lea r12, [r14+0x138]
000076049b1cf158  mov [r13+r12*1], r10
000076049b1cf15d  lea r12, [rax+0x140]
000076049b1cf164  movups xmm9, [r13+r12*1]
000076049b1cf16a  lea r12, [rax+0x150]
000076049b1cf171  movups xmm8, [r13+r12*1]
000076049b1cf177  lea r12, [r14+0xC0]
000076049b1cf17e  movups [r13+r12*1], xmm15
000076049b1cf184  lea r12, [r14+0xD0]
000076049b1cf18b  movups [r13+r12*1], xmm1
000076049b1cf191  lea r12, [rax+0x100]
000076049b1cf198  movups xmm1, [r13+r12*1]
000076049b1cf19e  lea r12, [rax+0x110]
000076049b1cf1a5  movups xmm15, [r13+r12*1]
000076049b1cf1ab  lea r12, [r14+0x140]
000076049b1cf1b2  mov r11, [r15+0xE8]
000076049b1cf1b9  mov [r13+r12*1], r11
000076049b1cf1be  lea r12, [rax+0x180]
000076049b1cf1c5  movups xmm7, [r13+r12*1]
000076049b1cf1cb  lea r12, [rax+0x190]
000076049b1cf1d2  movups xmm6, [r13+r12*1]
000076049b1cf1d8  lea r12, [rax+0x1C0]
000076049b1cf1df  movups xmm5, [r13+r12*1]
000076049b1cf1e5  lea r12, [rax+0x1D0]
000076049b1cf1ec  movups xmm4, [r13+r12*1]
000076049b1cf1f2  lea r12, [r14+0x20]
000076049b1cf1f6  movups [r13+r12*1], xmm1
000076049b1cf1fc  lea r12, [r14+0x30]
000076049b1cf200  movups [r13+r12*1], xmm13
000076049b1cf206  lea r12, [rax+0x60]
000076049b1cf20a  movups xmm1, [r13+r12*1]
000076049b1cf210  lea r12, [rax+0x70]
000076049b1cf214  movups xmm13, [r13+r12*1]
000076049b1cf21a  lea r12, [rax+0x20]
000076049b1cf21e  movups xmm3, [r13+r12*1]
000076049b1cf224  lea r12, [rax+0x30]
000076049b1cf228  movups xmm2, [r13+r12*1]
000076049b1cf22e  movaps [r15+0x1F0], xmm2
000076049b1cf236  lea r12, [r14+0x60]
000076049b1cf23a  movups [r13+r12*1], xmm11
000076049b1cf240  lea r12, [r14+0x70]
000076049b1cf244  movups [r13+r12*1], xmm5
000076049b1cf24a  lea r12, [rax+0xE0]
000076049b1cf251  movups xmm11, [r13+r12*1]
000076049b1cf257  lea r12, [rax+0xF0]
000076049b1cf25e  movups xmm5, [r13+r12*1]
000076049b1cf264  lea r12, [r14+0xA0]
000076049b1cf26b  movups [r13+r12*1], xmm13
000076049b1cf271  lea r12, [r14+0xB0]
000076049b1cf278  movups [r13+r12*1], xmm1
000076049b1cf27e  lea r12, [rax+0xA0]
000076049b1cf285  movups xmm1, [r13+r12*1]
000076049b1cf28b  lea r12, [rax+0xB0]
000076049b1cf292  movups xmm13, [r13+r12*1]
000076049b1cf298  lea r12, [rax+0x120]
000076049b1cf29f  vmovaps [rsp+0x10], xmm1
000076049b1cf2a5  movups xmm1, [r13+r12*1]
000076049b1cf2ab  lea r12, [rax+0x130]
000076049b1cf2b2  vmovaps [rsp+0x20], xmm1
000076049b1cf2b8  movups xmm1, [r13+r12*1]
000076049b1cf2be  lea r12, [rax+0x160]
000076049b1cf2c5  vmovaps [rsp+0x30], xmm1
000076049b1cf2cb  movups xmm1, [r13+r12*1]
000076049b1cf2d1  lea r12, [rax+0x170]
000076049b1cf2d8  vmovaps [rsp+0x40], xmm1
000076049b1cf2de  movups xmm1, [r13+r12*1]
000076049b1cf2e4  movaps [r15+0x2B0], xmm1
000076049b1cf2ec  lea r12, [r14+0x80]
000076049b1cf2f3  movups [r13+r12*1], xmm13
000076049b1cf2f9  lea r12, [r14+0x90]
000076049b1cf300  vmovaps xmm13, [rsp+0x10]
000076049b1cf306  movups [r13+r12*1], xmm13
000076049b1cf30c  lea r12, [rax+0x1A0]
000076049b1cf313  movups xmm13, [r13+r12*1]
000076049b1cf319  lea r12, [rax+0x1B0]
000076049b1cf320  vmovaps [rsp+0x10], xmm1
000076049b1cf326  movups xmm1, [r13+r12*1]
000076049b1cf32c  movaps [r15+0x290], xmm13
000076049b1cf334  movaps [r15+0x1E0], xmm1
000076049b1cf33c  lea r12, [rax+0x1E0]
000076049b1cf343  vmovaps [rsp+0x50], xmm1
000076049b1cf349  movups xmm1, [r13+r12*1]
000076049b1cf34f  lea r12, [rax+0x1F0]
000076049b1cf356  vmovaps [rsp+0x60], xmm1
000076049b1cf35c  movups xmm1, [r13+r12*1]
000076049b1cf362  mov qword ptr [r15+0x50], 0x430920
000076049b1cf36a  lea rax, [r14+0x40]
000076049b1cf36e  vmovaps [rsp+0x70], xmm1
000076049b1cf374  vmovaps xmm1, [rsp+0x40]
000076049b1cf37a  movups [r13+rax*1], xmm1
000076049b1cf380  lea rax, [r14+0x50]
000076049b1cf384  movups [r13+rax*1], xmm10
000076049b1cf38a  vmovaps xmm1, [rsp+0x70]
000076049b1cf390  movups [r13+r14*1], xmm1
000076049b1cf396  lea rax, [r14+0x10]
000076049b1cf39a  vmovaps xmm1, [rsp+0x60]
000076049b1cf3a0  movups [r13+rax*1], xmm1
000076049b1cf3a6  mov rax, [r15+0x40]
000076049b1cf3aa  vmovaps [rsp+0x40], xmm3
000076049b1cf3b0  vmovaps xmm1, [rsp+0x40]
000076049b1cf3b6  por xmm3, xmm1
000076049b1cf3ba  vmovaps [rsp+0x40], xmm6
000076049b1cf3c0  vmovaps xmm10, [rsp+0x40]
000076049b1cf3c6  por xmm6, xmm10
000076049b1cf3cb  lea r12, [rax+0x30]
000076049b1cf3cf  mov r11, [r13+r12*1]
000076049b1cf3d4  lea r12, [rax+0x38]
000076049b1cf3d8  mov r10, [r13+r12*1]
000076049b1cf3dd  movq xmm10, r11
000076049b1cf3e2  vmovaps [rsp+0x40], xmm1
000076049b1cf3e8  movq xmm1, r10
000076049b1cf3ed  movq xmm10, xmm10
000076049b1cf3f2  vmovaps [rsp+0x60], xmm10
000076049b1cf3f8  movq xmm10, xmm10
000076049b1cf3fd  movaps [r15+0x130], xmm10
000076049b1cf405  movq xmm1, xmm1
000076049b1cf409  vmovaps [rsp+0x70], xmm1
000076049b1cf40f  movq xmm1, xmm1
000076049b1cf413  movaps [r15+0x280], xmm1
000076049b1cf41b  vmovaps [rsp+0x80], xmm9
000076049b1cf424  vmovaps xmm1, [rsp+0x80]
000076049b1cf42d  por xmm9, xmm1
000076049b1cf432  lea r12, [rax+0x20]
000076049b1cf436  mov r11, [r13+r12*1]
000076049b1cf43b  lea r12, [rax+0x28]
000076049b1cf43f  mov r10, [r13+r12*1]
000076049b1cf444  movq xmm1, r11
000076049b1cf449  movq xmm10, r10
000076049b1cf44e  movq xmm1, xmm1
000076049b1cf452  vmovaps [rsp+0x80], xmm1
000076049b1cf45b  movq xmm1, xmm1
000076049b1cf45f  movaps [r15+0x150], xmm1
000076049b1cf467  movq xmm10, xmm10
000076049b1cf46c  vmovaps [rsp+0x90], xmm10
000076049b1cf475  movq xmm10, xmm10
000076049b1cf47a  movaps [r15+0x140], xmm10
000076049b1cf482  lea r12, [rax+0x10]
000076049b1cf486  mov r11, [r13+r12*1]
000076049b1cf48b  lea r12, [rax+0x18]
000076049b1cf48f  mov r10, [r13+r12*1]
000076049b1cf494  movq xmm1, r11
000076049b1cf499  movq xmm10, r10
000076049b1cf49e  movq xmm1, xmm1
000076049b1cf4a2  vmovaps [rsp+0xA0], xmm1
000076049b1cf4ab  movq xmm1, xmm1
000076049b1cf4af  movaps [r15+0x170], xmm1
000076049b1cf4b7  movq xmm10, xmm10
000076049b1cf4bc  vmovaps [rsp+0xB0], xmm10
000076049b1cf4c5  movq xmm10, xmm10
000076049b1cf4ca  movaps [r15+0x160], xmm10
000076049b1cf4d2  mov r12, [r13+rax*1]
000076049b1cf4d7  vmovq xmm1, r12
000076049b1cf4dc  vpbroadcastq xmm1, xmm1
000076049b1cf4e1  lea r12, [rax+0x08]
000076049b1cf4e5  mov rax, [r13+r12*1]
000076049b1cf4ea  movq xmm10, rax
000076049b1cf4ef  movaps [r15+0x230], xmm10
000076049b1cf4f7  lea rax, [r14+0x50]
000076049b1cf4fb  movups xmm10, [r13+rax*1]
000076049b1cf501  lea rax, [r14+0x60]
000076049b1cf505  vmovaps [rsp+0xC0], xmm1
000076049b1cf50e  movups xmm1, [r13+rax*1]
000076049b1cf514  lea rax, [r14+0x30]
000076049b1cf518  vmovaps [rsp+0xD0], xmm1
000076049b1cf521  movups xmm1, [r13+rax*1]
000076049b1cf527  mov qword ptr [r15+0x60], 0x430920
000076049b1cf52f  mov qword ptr [r15+0x58], 0x40
000076049b1cf537  vmovaps [rsp+0xE0], xmm1
000076049b1cf540  vmovaps [rsp+0xF0], xmm15
000076049b1cf549  vmovaps xmm15, [rsp+0xC0]
000076049b1cf552  vmovaps [rsp+0xC0], xmm14
000076049b1cf55b  vmovaps xmm14, [rsp+0x40]
000076049b1cf561  vmovaps [rsp+0x40], xmm13
000076049b1cf567  movaps xmm1, xmm15
000076049b1cf56b  mulpd xmm1, xmm14
000076049b1cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000076049b1cf575  ptest xmm13, xmm13
000076049b1cf57b  jnz 0x000076049B1D0682
000076049b1cf581  movq xmm14, qword ptr [r15+0x230]
000076049b1cf58a  vmovaps [rsp+0x100], xmm14
000076049b1cf593  vpermilpd xmm14, xmm14, 0x00
000076049b1cf599  vmovaps [rsp+0x110], xmm1
000076049b1cf5a2  vmovaps xmm1, [rsp+0xE0]
000076049b1cf5ab  vmovaps [rsp+0xE0], xmm15
000076049b1cf5b4  movaps xmm13, xmm1
000076049b1cf5b8  mulpd xmm13, xmm14
000076049b1cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000076049b1cf5c3  ptest xmm15, xmm15
000076049b1cf5c9  jnz 0x000076049B1D07C4
000076049b1cf5cf  vxorps xmm1, xmm1, xmm1
000076049b1cf5d3  vpbroadcastq xmm1, xmm1
000076049b1cf5d8  vmovaps xmm14, [rsp+0xE0]
000076049b1cf5e1  vmovaps [rsp+0xE0], xmm1
000076049b1cf5ea  vmovaps xmm1, [rsp+0xD0]
000076049b1cf5f3  vmovaps [rsp+0xD0], xmm13
000076049b1cf5fc  movaps xmm15, xmm14
000076049b1cf600  mulpd xmm15, xmm1
000076049b1cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000076049b1cf60b  ptest xmm13, xmm13
000076049b1cf611  jnz 0x000076049B1D0907
000076049b1cf617  movaps xmm1, xmm14
000076049b1cf61b  mulpd xmm1, xmm10
000076049b1cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000076049b1cf625  ptest xmm13, xmm13
000076049b1cf62b  jnz 0x000076049B1D0A4A
000076049b1cf631  movaps xmm13, xmm14
000076049b1cf635  mulpd xmm13, xmm2
000076049b1cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000076049b1cf640  ptest xmm10, xmm10
000076049b1cf646  jnz 0x000076049B1D0B8C
000076049b1cf64c  vmovaps [rsp+0x120], xmm7
000076049b1cf655  vmovaps xmm14, [rsp+0x120]
000076049b1cf65e  por xmm7, xmm14
000076049b1cf663  vmovaps xmm14, [rsp+0xC0]
000076049b1cf66c  vmovaps xmm10, [rsp+0xC0]
000076049b1cf675  por xmm14, xmm10
000076049b1cf67a  vmovaps xmm2, [rsp+0x100]
000076049b1cf683  vpermilpd xmm2, xmm2, 0x00
000076049b1cf689  vmovaps [rsp+0xC0], xmm1
000076049b1cf692  vmovaps [rsp+0x120], xmm15
000076049b1cf69b  movaps xmm1, xmm10
000076049b1cf69f  mulpd xmm1, xmm2
000076049b1cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000076049b1cf6a8  ptest xmm15, xmm15
000076049b1cf6ae  jnz 0x000076049B1D0CCF
000076049b1cf6b4  xor eax, eax
000076049b1cf6b6  mov r12d, 0x40
000076049b1cf6bc  mov r11d, 0x200
000076049b1cf6c2  cmp r12, r11
000076049b1cf6c5  cmc
000076049b1cf6c6  lahf
000076049b1cf6c7  seto al
000076049b1cf6ca  mov [r15+0x108], eax
000076049b1cf6d1  vmovaps xmm10, [rsp+0x110]
000076049b1cf6da  vmovaps xmm2, [rsp+0xE0]
000076049b1cf6e3  vmovaps [rsp+0xE0], xmm1
000076049b1cf6ec  movaps xmm15, xmm10
000076049b1cf6f0  addpd xmm15, xmm2
000076049b1cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000076049b1cf6fb  ptest xmm1, xmm1
000076049b1cf700  jnz 0x000076049B1D0E10
000076049b1cf706  vmovaps xmm10, [rsp+0x120]
000076049b1cf70f  vmovaps [rsp+0x110], xmm15
000076049b1cf718  movaps xmm1, xmm10
000076049b1cf71c  addpd xmm1, xmm12
000076049b1cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000076049b1cf726  ptest xmm15, xmm15
000076049b1cf72c  jnz 0x000076049B1D0F53
000076049b1cf732  vmovaps xmm10, [rsp+0xC0]
000076049b1cf73b  vmovaps [rsp+0xC0], xmm1
000076049b1cf744  movaps xmm15, xmm10
000076049b1cf748  addpd xmm15, xmm12
000076049b1cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000076049b1cf753  ptest xmm1, xmm1
000076049b1cf758  jnz 0x000076049B1D1095
000076049b1cf75e  vmovaps xmm1, [rsp+0x30]
000076049b1cf764  vmovaps xmm12, [rsp+0x30]
000076049b1cf76a  por xmm1, xmm12
000076049b1cf76f  vmovaps xmm12, [rsp+0x20]
000076049b1cf775  vmovaps xmm10, [rsp+0x20]
000076049b1cf77b  por xmm12, xmm10
000076049b1cf780  vmovaps [rsp+0x20], xmm5
000076049b1cf786  vmovaps xmm10, [rsp+0x20]
000076049b1cf78c  por xmm5, xmm10
000076049b1cf791  vmovaps [rsp+0x20], xmm11
000076049b1cf797  vmovaps xmm10, [rsp+0x20]
000076049b1cf79d  por xmm11, xmm10
000076049b1cf7a2  vmovaps [rsp+0x20], xmm4
000076049b1cf7a8  vmovaps xmm10, [rsp+0x20]
000076049b1cf7ae  por xmm4, xmm10
000076049b1cf7b3  vmovaps [rsp+0x20], xmm8
000076049b1cf7b9  vmovaps xmm10, [rsp+0x20]
000076049b1cf7bf  por xmm8, xmm10
000076049b1cf7c4  vmovaps xmm10, [rsp+0xF0]
000076049b1cf7cd  vmovaps [rsp+0x20], xmm1
000076049b1cf7d3  vmovaps xmm1, [rsp+0xF0]
000076049b1cf7dc  por xmm10, xmm1
000076049b1cf7e1  lea rax, [r14+0xA0]
000076049b1cf7e8  movups xmm1, [r13+rax*1]
000076049b1cf7ee  lea rax, [r14+0xB0]
000076049b1cf7f5  vmovaps [rsp+0x30], xmm1
000076049b1cf7fb  movups xmm1, [r13+rax*1]
000076049b1cf801  vmovaps [rsp+0xF0], xmm1
000076049b1cf80a  vmovaps [rsp+0x120], xmm15
000076049b1cf813  movaps xmm1, xmm13
000076049b1cf817  addpd xmm1, xmm2
000076049b1cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000076049b1cf820  ptest xmm15, xmm15
000076049b1cf826  jnz 0x000076049B1D11ED
000076049b1cf82c  lea rax, [r14+0xF0]
000076049b1cf833  movups xmm15, [r13+rax*1]
000076049b1cf839  vmovaps xmm2, [rsp+0xC0]
000076049b1cf842  vmovaps [rsp+0xC0], xmm1
000076049b1cf84b  vmovaps xmm1, [rsp+0xE0]
000076049b1cf854  vmovaps [rsp+0xE0], xmm15
000076049b1cf85d  movaps xmm13, xmm2
000076049b1cf861  addpd xmm13, xmm1
000076049b1cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000076049b1cf86c  ptest xmm15, xmm15
000076049b1cf872  jnz 0x000076049B1D1338
000076049b1cf878  vmovaps xmm15, [rsp+0x120]
000076049b1cf881  vmovaps xmm2, [rsp+0xD0]
000076049b1cf88a  vmovaps [rsp+0xD0], xmm14
000076049b1cf893  movaps xmm1, xmm15
000076049b1cf897  addpd xmm1, xmm2
000076049b1cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000076049b1cf8a0  ptest xmm14, xmm14
000076049b1cf8a6  jnz 0x000076049B1D147A
000076049b1cf8ac  vmovaps xmm15, [rsp+0x100]
000076049b1cf8b5  vpermilpd xmm15, xmm15, 0x00
000076049b1cf8bb  vmovaps xmm2, [rsp+0xF0]
000076049b1cf8c4  vmovaps [rsp+0xF0], xmm1
000076049b1cf8cd  movaps xmm14, xmm2
000076049b1cf8d1  mulpd xmm14, xmm15
000076049b1cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000076049b1cf8dc  ptest xmm1, xmm1
000076049b1cf8e1  jnz 0x000076049B1D15BB
000076049b1cf8e7  vmovaps xmm1, [rsp+0xA0]
000076049b1cf8f0  vpermilpd xmm1, xmm1, 0x00
000076049b1cf8f6  vmovaps xmm2, [rsp+0xE0]
000076049b1cf8ff  vmovaps [rsp+0xE0], xmm14
000076049b1cf908  movaps xmm15, xmm2
000076049b1cf90c  mulpd xmm15, xmm1
000076049b1cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000076049b1cf917  ptest xmm14, xmm14
000076049b1cf91d  jnz 0x000076049B1D16FE
000076049b1cf923  lea rax, [r14+0xE0]
000076049b1cf92a  movups xmm1, [r13+rax*1]
000076049b1cf930  vmovaps xmm14, [rsp+0x100]
000076049b1cf939  vpermilpd xmm14, xmm14, 0x00
000076049b1cf93f  vmovaps [rsp+0x100], xmm1
000076049b1cf948  vmovaps xmm1, [rsp+0x30]
000076049b1cf94e  vmovaps [rsp+0x30], xmm15
000076049b1cf954  movaps xmm2, xmm1
000076049b1cf957  mulpd xmm2, xmm14
000076049b1cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000076049b1cf961  ptest xmm15, xmm15
000076049b1cf967  jnz 0x000076049B1D184A
000076049b1cf96d  vmovaps [rsp+0x120], xmm10
000076049b1cf976  vmovaps xmm1, [rsp+0x120]
000076049b1cf97f  por xmm10, xmm1
000076049b1cf984  movaps [r15+0x300], xmm10
000076049b1cf98c  vmovaps [rsp+0x120], xmm8
000076049b1cf995  vmovaps xmm1, [rsp+0x120]
000076049b1cf99e  por xmm8, xmm1
000076049b1cf9a3  movaps [r15+0x190], xmm8
000076049b1cf9ab  vmovaps xmm1, [rsp+0xA0]
000076049b1cf9b4  vpermilpd xmm1, xmm1, 0x00
000076049b1cf9ba  vmovaps xmm14, [rsp+0x100]
000076049b1cf9c3  vmovaps [rsp+0x100], xmm13
000076049b1cf9cc  movaps xmm15, xmm14
000076049b1cf9d0  mulpd xmm15, xmm1
000076049b1cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000076049b1cf9db  ptest xmm13, xmm13
000076049b1cf9e1  jnz 0x000076049B1D198B
000076049b1cf9e7  lea rax, [r14+0x90]
000076049b1cf9ee  movups xmm1, [r13+rax*1]
000076049b1cf9f4  vmovaps [rsp+0x120], xmm4
000076049b1cf9fd  vmovaps xmm14, [rsp+0x120]
000076049b1cfa06  por xmm4, xmm14
000076049b1cfa0b  movaps [r15+0x1C0], xmm4
000076049b1cfa13  vmovaps [rsp+0x120], xmm11
000076049b1cfa1c  vmovaps xmm14, [rsp+0x120]
000076049b1cfa25  por xmm11, xmm14
000076049b1cfa2a  movaps [r15+0x200], xmm11
000076049b1cfa32  vmovaps [rsp+0x120], xmm5
000076049b1cfa3b  vmovaps xmm14, [rsp+0x120]
000076049b1cfa44  por xmm5, xmm14
000076049b1cfa49  movaps [r15+0x2D0], xmm5
000076049b1cfa51  vmovaps [rsp+0x120], xmm12
000076049b1cfa5a  vmovaps xmm14, [rsp+0x120]
000076049b1cfa63  por xmm12, xmm14
000076049b1cfa68  movaps [r15+0x2E0], xmm12
000076049b1cfa70  vmovaps xmm13, [rsp+0x110]
000076049b1cfa79  vmovaps [rsp+0x110], xmm1
000076049b1cfa82  vmovaps xmm1, [rsp+0xE0]
000076049b1cfa8b  vmovaps [rsp+0xE0], xmm15
000076049b1cfa94  movaps xmm14, xmm13
000076049b1cfa98  addpd xmm14, xmm1
000076049b1cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000076049b1cfaa3  ptest xmm15, xmm15
000076049b1cfaa9  jnz 0x000076049B1D1AD8
000076049b1cfaaf  vmovaps xmm1, [rsp+0xA0]
000076049b1cfab8  vpermilpd xmm1, xmm1, 0x00
000076049b1cfabe  vmovaps xmm13, [rsp+0x110]
000076049b1cfac7  vmovaps [rsp+0x110], xmm14
000076049b1cfad0  movaps xmm15, xmm13
000076049b1cfad4  mulpd xmm15, xmm1
000076049b1cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000076049b1cfadf  ptest xmm14, xmm14
000076049b1cfae5  jnz 0x000076049B1D1C1B
000076049b1cfaeb  lea rax, [r14+0x80]
000076049b1cfaf2  movups xmm1, [r13+rax*1]
000076049b1cfaf8  vmovaps xmm13, [rsp+0xC0]
000076049b1cfb01  vmovaps [rsp+0xC0], xmm1
000076049b1cfb0a  movaps xmm14, xmm13
000076049b1cfb0e  addpd xmm14, xmm2
000076049b1cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000076049b1cfb19  ptest xmm1, xmm1
000076049b1cfb1e  jnz 0x000076049B1D1D68
000076049b1cfb24  vmovaps xmm13, [rsp+0x100]
000076049b1cfb2d  vmovaps xmm2, [rsp+0x30]
000076049b1cfb33  vmovaps [rsp+0x30], xmm15
000076049b1cfb39  movaps xmm1, xmm13
000076049b1cfb3d  addpd xmm1, xmm2
000076049b1cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000076049b1cfb46  ptest xmm15, xmm15
000076049b1cfb4c  jnz 0x000076049B1D1EAB
000076049b1cfb52  vmovaps xmm15, [rsp+0x20]
000076049b1cfb58  vmovaps xmm13, [rsp+0x20]
000076049b1cfb5e  por xmm15, xmm13
000076049b1cfb63  movaps [r15+0x2F0], xmm15
000076049b1cfb6b  vmovaps xmm13, [rsp+0xA0]
000076049b1cfb74  vpermilpd xmm13, xmm13, 0x00
000076049b1cfb7a  vmovaps [rsp+0x20], xmm1
000076049b1cfb80  vmovaps xmm1, [rsp+0xC0]
000076049b1cfb89  vmovaps [rsp+0xA0], xmm15
000076049b1cfb92  movaps xmm2, xmm1
000076049b1cfb95  mulpd xmm2, xmm13
000076049b1cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000076049b1cfb9f  ptest xmm15, xmm15
000076049b1cfba5  jnz 0x000076049B1D1FEC
000076049b1cfbab  lea rax, [r14+0xD0]
000076049b1cfbb2  movups xmm1, [r13+rax*1]
000076049b1cfbb8  vmovaps xmm13, [rsp+0xF0]
000076049b1cfbc1  vmovaps [rsp+0xC0], xmm1
000076049b1cfbca  vmovaps xmm1, [rsp+0xE0]
000076049b1cfbd3  vmovaps [rsp+0xE0], xmm14
000076049b1cfbdc  movaps xmm15, xmm13
000076049b1cfbe0  addpd xmm15, xmm1
000076049b1cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000076049b1cfbeb  ptest xmm14, xmm14
000076049b1cfbf1  jnz 0x000076049B1D2137
000076049b1cfbf7  vmovaps xmm1, [rsp+0xB0]
000076049b1cfc00  vpermilpd xmm1, xmm1, 0x00
000076049b1cfc06  movaps xmm14, xmm11
000076049b1cfc0a  mulpd xmm14, xmm1
000076049b1cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000076049b1cfc15  ptest xmm13, xmm13
000076049b1cfc1b  jnz 0x000076049B1D227A
000076049b1cfc21  movaps [r15+0x260], xmm14
000076049b1cfc29  vxorps xmm1, xmm1, xmm1
000076049b1cfc2d  vpbroadcastq xmm1, xmm1
000076049b1cfc32  movaps [r15+0x1B0], xmm1
000076049b1cfc3a  vmovaps xmm1, [rsp+0xB0]
000076049b1cfc43  vpermilpd xmm1, xmm1, 0x00
000076049b1cfc49  vmovaps xmm11, [rsp+0xC0]
000076049b1cfc52  vmovaps [rsp+0xC0], xmm15
000076049b1cfc5b  movaps xmm13, xmm11
000076049b1cfc5f  mulpd xmm13, xmm1
000076049b1cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000076049b1cfc6a  ptest xmm15, xmm15
000076049b1cfc70  jnz 0x000076049B1D23BD
000076049b1cfc76  lea rax, [r14+0xC0]
000076049b1cfc7d  movups xmm1, [r13+rax*1]
000076049b1cfc83  vmovaps xmm11, [rsp+0x110]
000076049b1cfc8c  vmovaps [rsp+0xF0], xmm1
000076049b1cfc95  vmovaps xmm1, [rsp+0x30]
000076049b1cfc9b  vmovaps [rsp+0x30], xmm14
000076049b1cfca1  movaps xmm15, xmm11
000076049b1cfca5  addpd xmm15, xmm1
000076049b1cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000076049b1cfcb0  ptest xmm14, xmm14
000076049b1cfcb6  jnz 0x000076049B1D250A
000076049b1cfcbc  vmovaps [rsp+0x100], xmm9
000076049b1cfcc5  vmovaps xmm1, [rsp+0x100]
000076049b1cfcce  por xmm9, xmm1
000076049b1cfcd3  movaps [r15+0x270], xmm9
000076049b1cfcdb  vmovaps [rsp+0x100], xmm6
000076049b1cfce4  vmovaps xmm1, [rsp+0x100]
000076049b1cfced  por xmm6, xmm1
000076049b1cfcf1  movaps [r15+0x1A0], xmm6
000076049b1cfcf9  vmovaps xmm14, [rsp+0xB0]
000076049b1cfd02  vpermilpd xmm14, xmm14, 0x00
000076049b1cfd08  vmovaps xmm6, [rsp+0xF0]
000076049b1cfd11  vmovaps [rsp+0xF0], xmm1
000076049b1cfd1a  movaps xmm11, xmm6
000076049b1cfd1e  mulpd xmm11, xmm14
000076049b1cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000076049b1cfd29  ptest xmm1, xmm1
000076049b1cfd2e  jnz 0x000076049B1D264D
000076049b1cfd34  lea rax, [r14+0x20]
000076049b1cfd38  movups xmm1, [r13+rax*1]
000076049b1cfd3e  movaps [r15+0x110], xmm1
000076049b1cfd46  vmovaps xmm6, [rsp+0xE0]
000076049b1cfd4f  vmovaps [rsp+0xE0], xmm1
000076049b1cfd58  movaps xmm14, xmm6
000076049b1cfd5c  addpd xmm14, xmm2
000076049b1cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000076049b1cfd67  ptest xmm1, xmm1
000076049b1cfd6c  jnz 0x000076049B1D279A
000076049b1cfd72  vmovaps xmm1, [rsp+0xB0]
000076049b1cfd7b  vpermilpd xmm1, xmm1, 0x00
000076049b1cfd81  movaps xmm6, xmm5
000076049b1cfd84  mulpd xmm6, xmm1
000076049b1cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000076049b1cfd8d  ptest xmm2, xmm2
000076049b1cfd92  jnz 0x000076049B1D28DC
000076049b1cfd98  vmovaps xmm5, [rsp+0x20]
000076049b1cfd9e  movaps xmm1, xmm5
000076049b1cfda1  addpd xmm1, xmm13
000076049b1cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000076049b1cfdab  ptest xmm2, xmm2
000076049b1cfdb0  jnz 0x000076049B1D2A1C
000076049b1cfdb6  vmovaps xmm13, [rsp+0x80]
000076049b1cfdbf  vpermilpd xmm13, xmm13, 0x00
000076049b1cfdc5  vmovaps xmm2, [rsp+0xE0]
000076049b1cfdce  vmovaps [rsp+0x20], xmm1
000076049b1cfdd4  movaps xmm5, xmm2
000076049b1cfdd7  mulpd xmm5, xmm13
000076049b1cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000076049b1cfde1  ptest xmm1, xmm1
000076049b1cfde6  jnz 0x000076049B1D2B5D
000076049b1cfdec  vmovaps xmm1, [rsp+0x80]
000076049b1cfdf5  vpermilpd xmm1, xmm1, 0x00
000076049b1cfdfb  movaps xmm13, xmm10
000076049b1cfdff  mulpd xmm13, xmm1
000076049b1cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000076049b1cfe0a  ptest xmm2, xmm2
000076049b1cfe0f  jnz 0x000076049B1D2C9E
000076049b1cfe15  vmovaps xmm10, [rsp+0x30]
000076049b1cfe1b  movaps xmm1, xmm15
000076049b1cfe1f  addpd xmm1, xmm10
000076049b1cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000076049b1cfe29  ptest xmm2, xmm2
000076049b1cfe2e  jnz 0x000076049B1D2DE1
000076049b1cfe34  vmovaps xmm10, [rsp+0xC0]
000076049b1cfe3d  movaps xmm15, xmm10
000076049b1cfe41  addpd xmm15, xmm11
000076049b1cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000076049b1cfe4c  ptest xmm2, xmm2
000076049b1cfe51  jnz 0x000076049B1D2F23
000076049b1cfe57  vmovaps xmm11, [rsp+0x80]
000076049b1cfe60  vpermilpd xmm11, xmm11, 0x00
000076049b1cfe66  movaps xmm10, xmm12
000076049b1cfe6a  mulpd xmm10, xmm11
000076049b1cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000076049b1cfe75  ptest xmm2, xmm2
000076049b1cfe7a  jnz 0x000076049B1D3067
000076049b1cfe80  vmovaps xmm12, [rsp+0x80]
000076049b1cfe89  vpermilpd xmm12, xmm12, 0x00
000076049b1cfe8f  vmovaps xmm2, [rsp+0xA0]
000076049b1cfe98  vmovaps [rsp+0x30], xmm1
000076049b1cfe9e  movaps xmm11, xmm2
000076049b1cfea2  mulpd xmm11, xmm12
000076049b1cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000076049b1cfead  ptest xmm1, xmm1
000076049b1cfeb2  jnz 0x000076049B1D31AB
000076049b1cfeb8  movaps xmm1, xmm14
000076049b1cfebc  addpd xmm1, xmm6
000076049b1cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000076049b1cfec5  ptest xmm12, xmm12
000076049b1cfecb  jnz 0x000076049B1D32EE
000076049b1cfed1  vmovaps xmm12, [rsp+0x20]
000076049b1cfed7  movaps xmm14, xmm12
000076049b1cfedb  addpd xmm14, xmm5
000076049b1cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000076049b1cfee6  ptest xmm6, xmm6
000076049b1cfeeb  jnz 0x000076049B1D342F
000076049b1cfef1  vmovaps xmm12, [rsp+0x90]
000076049b1cfefa  vpermilpd xmm12, xmm12, 0x00
000076049b1cff00  movaps xmm6, xmm9
000076049b1cff04  mulpd xmm6, xmm12
000076049b1cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000076049b1cff0e  ptest xmm5, xmm5
000076049b1cff13  jnz 0x000076049B1D3572
000076049b1cff19  movaps xmm12, xmm15
000076049b1cff1d  addpd xmm12, xmm13
000076049b1cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000076049b1cff28  ptest xmm9, xmm9
000076049b1cff2e  jnz 0x000076049B1D36B4
000076049b1cff34  vmovaps xmm13, [rsp+0x30]
000076049b1cff3a  movaps xmm15, xmm13
000076049b1cff3e  addpd xmm15, xmm10
000076049b1cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000076049b1cff49  ptest xmm9, xmm9
000076049b1cff4f  jnz 0x000076049B1D37F8
000076049b1cff55  vmovaps xmm13, [rsp+0xD0]
000076049b1cff5e  vmovaps xmm10, [rsp+0xD0]
000076049b1cff67  por xmm13, xmm10
000076049b1cff6c  movaps [r15+0x250], xmm13
000076049b1cff74  vmovaps [rsp+0x20], xmm7
000076049b1cff7a  vmovaps xmm13, [rsp+0x20]
000076049b1cff80  por xmm7, xmm13
000076049b1cff85  movaps [r15+0x2A0], xmm7
000076049b1cff8d  vmovaps [rsp+0x20], xmm3
000076049b1cff93  vmovaps xmm13, [rsp+0x20]
000076049b1cff99  por xmm3, xmm13
000076049b1cff9e  movaps [r15+0x1D0], xmm3
000076049b1cffa6  lea rax, [r14+0x40]
000076049b1cffaa  movups xmm13, [r13+rax*1]
000076049b1cffb0  movaps [r15+0x2C0], xmm13
000076049b1cffb8  vmovaps xmm10, [rsp+0x90]
000076049b1cffc1  vpermilpd xmm10, xmm10, 0x00
000076049b1cffc7  movaps xmm9, xmm8
000076049b1cffcb  mulpd xmm9, xmm10
000076049b1cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000076049b1cffd6  ptest xmm5, xmm5
000076049b1cffdb  jnz 0x000076049B1D3946
000076049b1cffe1  movaps xmm10, xmm1
000076049b1cffe5  addpd xmm10, xmm11
000076049b1cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000076049b1cfff0  ptest xmm8, xmm8
000076049b1cfff6  jnz 0x000076049B1D3A8A
000076049b1cfffc  movaps xmm1, xmm14
000076049b1d0000  addpd xmm1, xmm6
000076049b1d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000076049b1d0009  ptest xmm11, xmm11
000076049b1d000f  jnz 0x000076049B1D3BCD
000076049b1d0015  vmovaps xmm14, [rsp+0x90]
000076049b1d001e  vpermilpd xmm14, xmm14, 0x00
000076049b1d0024  movaps xmm11, xmm13
000076049b1d0028  mulpd xmm11, xmm14
000076049b1d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000076049b1d0033  ptest xmm8, xmm8
000076049b1d0039  jnz 0x000076049B1D3D0E
000076049b1d003f  vmovaps xmm14, [rsp+0x90]
000076049b1d0048  vpermilpd xmm14, xmm14, 0x00
000076049b1d004e  vmovaps xmm8, [rsp+0x10]
000076049b1d0054  movaps xmm13, xmm8
000076049b1d0058  mulpd xmm13, xmm14
000076049b1d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000076049b1d0063  ptest xmm6, xmm6
000076049b1d0068  jnz 0x000076049B1D3E52
000076049b1d006e  vmovaps xmm14, [rsp+0x60]
000076049b1d0074  vpermilpd xmm14, xmm14, 0x00
000076049b1d007a  movaps xmm8, xmm7
000076049b1d007e  mulpd xmm8, xmm14
000076049b1d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000076049b1d0089  ptest xmm6, xmm6
000076049b1d008e  jnz 0x000076049B1D3F96
000076049b1d0094  movaps xmm14, xmm12
000076049b1d0098  addpd xmm14, xmm9
000076049b1d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000076049b1d00a3  ptest xmm7, xmm7
000076049b1d00a8  jnz 0x000076049B1D40D9
000076049b1d00ae  vmovaps xmm12, [rsp+0x60]
000076049b1d00b4  vpermilpd xmm12, xmm12, 0x00
000076049b1d00ba  vmovaps xmm7, [rsp+0xF0]
000076049b1d00c3  movaps xmm9, xmm7
000076049b1d00c7  mulpd xmm9, xmm12
000076049b1d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000076049b1d00d2  ptest xmm6, xmm6
000076049b1d00d7  jnz 0x000076049B1D421D
000076049b1d00dd  movaps xmm12, xmm15
000076049b1d00e1  addpd xmm12, xmm11
000076049b1d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000076049b1d00ec  ptest xmm7, xmm7
000076049b1d00f1  jnz 0x000076049B1D4360
000076049b1d00f7  vmovaps xmm15, [rsp+0x60]
000076049b1d00fd  vpermilpd xmm15, xmm15, 0x00
000076049b1d0103  vmovaps xmm7, [rsp+0x40]
000076049b1d0109  movaps xmm11, xmm7
000076049b1d010d  mulpd xmm11, xmm15
000076049b1d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000076049b1d0118  ptest xmm6, xmm6
000076049b1d011d  jnz 0x000076049B1D44A4
000076049b1d0123  movaps xmm15, xmm10
000076049b1d0127  addpd xmm15, xmm13
000076049b1d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000076049b1d0132  ptest xmm7, xmm7
000076049b1d0137  jnz 0x000076049B1D45E7
000076049b1d013d  vmovaps xmm13, [rsp+0x60]
000076049b1d0143  vpermilpd xmm13, xmm13, 0x00
000076049b1d0149  vmovaps xmm7, [rsp+0x50]
000076049b1d014f  movaps xmm10, xmm7
000076049b1d0153  mulpd xmm10, xmm13
000076049b1d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000076049b1d015e  ptest xmm6, xmm6
000076049b1d0163  jnz 0x000076049B1D472B
000076049b1d0169  movaps xmm13, xmm1
000076049b1d016d  addpd xmm13, xmm8
000076049b1d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000076049b1d0178  ptest xmm7, xmm7
000076049b1d017d  jnz 0x000076049B1D486E
000076049b1d0183  lea rax, [r14+0x70]
000076049b1d0187  movups xmm1, [r13+rax*1]
000076049b1d018d  movaps [r15+0x240], xmm1
000076049b1d0195  movaps xmm8, xmm14
000076049b1d0199  addpd xmm8, xmm9
000076049b1d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000076049b1d01a4  ptest xmm7, xmm7
000076049b1d01a9  jnz 0x000076049B1D49BB
000076049b1d01af  movaps [r15+0x170], xmm8
000076049b1d01b7  vmovaps xmm14, [rsp+0x70]
000076049b1d01bd  vpermilpd xmm14, xmm14, 0x00
000076049b1d01c3  movaps xmm9, xmm1
000076049b1d01c7  mulpd xmm9, xmm14
000076049b1d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000076049b1d01d2  ptest xmm7, xmm7
000076049b1d01d7  jnz 0x000076049B1D4AFF
000076049b1d01dd  vmovaps xmm1, [rsp+0x70]
000076049b1d01e3  vpermilpd xmm1, xmm1, 0x00
000076049b1d01e9  movaps xmm14, xmm4
000076049b1d01ed  mulpd xmm14, xmm1
000076049b1d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000076049b1d01f8  ptest xmm7, xmm7
000076049b1d01fd  jnz 0x000076049B1D4C42
000076049b1d0203  movaps [r15+0x180], xmm14
000076049b1d020b  movaps xmm1, xmm12
000076049b1d020f  addpd xmm1, xmm11
000076049b1d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000076049b1d0219  ptest xmm7, xmm7
000076049b1d021e  jnz 0x000076049B1D4D84
000076049b1d0224  movaps [r15+0x210], xmm1
000076049b1d022c  movups xmm12, [r13+r14*1]
000076049b1d0232  lea rax, [r14+0x10]
000076049b1d0236  movups xmm11, [r13+rax*1]
000076049b1d023c  movaps [r15+0x230], xmm11
000076049b1d0244  movaps xmm7, xmm15
000076049b1d0248  addpd xmm7, xmm10
000076049b1d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000076049b1d0252  ptest xmm6, xmm6
000076049b1d0257  jnz 0x000076049B1D4EDA
000076049b1d025d  movaps [r15+0x130], xmm7
000076049b1d0265  vmovaps xmm15, [rsp+0x70]
000076049b1d026b  vpermilpd xmm15, xmm15, 0x00
000076049b1d0271  movaps xmm10, xmm11
000076049b1d0275  mulpd xmm10, xmm15
000076049b1d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000076049b1d0280  ptest xmm6, xmm6
000076049b1d0285  jnz 0x000076049B1D501C
000076049b1d028b  movaps [r15+0x220], xmm10
000076049b1d0293  vmovaps xmm15, [rsp+0x70]
000076049b1d0299  vpermilpd xmm15, xmm15, 0x00
000076049b1d029f  movaps xmm11, xmm12
000076049b1d02a3  mulpd xmm11, xmm15
000076049b1d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000076049b1d02ae  ptest xmm6, xmm6
000076049b1d02b3  jnz 0x000076049B1D5160
000076049b1d02b9  movaps xmm15, xmm13
000076049b1d02bd  addpd xmm15, xmm9
000076049b1d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000076049b1d02c8  ptest xmm12, xmm12
000076049b1d02ce  jnz 0x000076049B1D52A4
000076049b1d02d4  movaps [r15+0x140], xmm15
000076049b1d02dc  movaps xmm13, xmm8
000076049b1d02e0  addpd xmm13, xmm14
000076049b1d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000076049b1d02eb  ptest xmm12, xmm12
000076049b1d02f1  jnz 0x000076049B1D53E8
000076049b1d02f7  movaps [r15+0x150], xmm13
000076049b1d02ff  movaps xmm14, xmm1
000076049b1d0303  addpd xmm14, xmm10
000076049b1d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000076049b1d030e  ptest xmm12, xmm12
000076049b1d0314  jnz 0x000076049B1D552C
000076049b1d031a  movaps [r15+0x160], xmm14
000076049b1d0322  movaps xmm1, xmm7
000076049b1d0325  addpd xmm1, xmm11
000076049b1d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000076049b1d032f  ptest xmm12, xmm12
000076049b1d0335  jnz 0x000076049B1D566F
000076049b1d033b  movaps [r15+0x120], xmm1
000076049b1d0343  mov eax, 0x430920
000076049b1d0348  movups [r13+rax*1], xmm15
000076049b1d034e  mov eax, 0x430930
000076049b1d0353  movups [r13+rax*1], xmm13
000076049b1d0359  mov eax, 0x430940
000076049b1d035e  movups [r13+rax*1], xmm14
000076049b1d0364  mov eax, 0x430950
000076049b1d0369  movups [r13+rax*1], xmm1
000076049b1d036f  mov eax, [r15+0x108]
000076049b1d0376  sahf
000076049b1d0377  jnz 0x000076049B1D03A9
000076049b1d0379  cmp dword ptr [r15+0x318], 0x00
000076049b1d0381  jz 0x000076049B1DB900
000076049b1d0387  nop [rax+rax*1], ax
000076049b1d0390  nop [rax+rax*1], eax
000076049b1d0398  mov eax, 0x410444
000076049b1d039d  mov [r15+0x100], rax
000076049b1d03a4  jmp 0x000076049AFFE110
000076049b1d03a9  cmp dword ptr [r15+0x318], 0x00
000076049b1d03b1  jz 0x000076049B1D57E0
000076049b1d03b7  nop [rax+rax*1], ax
000076049b1d03c0  nop [rax+rax*1], eax
000076049b1d03c8  mov eax, 0x410278
000076049b1d03cd  mov [r15+0x100], rax
000076049b1d03d4  jmp 0x000076049AFFE110
000076049b1d03d9  int3
000076049b1d03da  call 0x000076049B0B52F0
000076049b1d03df  jmp 0x000076049B1CF016
000076049b1d03e4  call 0x000076049B0C4620
000076049b1d03e9  jmp 0x000076049B1CF023
000076049b1d03ee  call 0x000076049B0C33A0
000076049b1d03f3  jmp 0x000076049B1CF035
000076049b1d03f8  call 0x000076049B0C2120
000076049b1d03fd  jmp 0x000076049B1CF03F
000076049b1d0402  call 0x000076049B0C0860
000076049b1d0407  jmp 0x000076049B1CF067
000076049b1d040c  call 0x000076049B0BF5F0
000076049b1d0411  jmp 0x000076049B1CF073
000076049b1d0416  call 0x000076049B0C0860
000076049b1d041b  jmp 0x000076049B1CF0A5
000076049b1d0420  call 0x000076049B0BF5F0
000076049b1d0425  jmp 0x000076049B1CF0B1
000076049b1d042a  call 0x000076049B0C4740
000076049b1d042f  jmp 0x000076049B1CF0BE
000076049b1d0434  call 0x000076049B0B5400
000076049b1d0439  jmp 0x000076049B1CF0CB
000076049b1d043e  call 0x000076049B0B52F0
000076049b1d0443  jmp 0x000076049B1CF0D8
000076049b1d0448  call 0x000076049B0C4620
000076049b1d044d  jmp 0x000076049B1CF0E5
000076049b1d0452  call 0x000076049B0C0860
000076049b1d0457  jmp 0x000076049B1CF10D
000076049b1d045c  call 0x000076049B0BF5F0
000076049b1d0461  jmp 0x000076049B1CF119
000076049b1d0466  call 0x000076049B009D70
000076049b1d046b  jmp 0x000076049B1CF11F
000076049b1d0470  call 0x000076049B0BE9C0
000076049b1d0475  jmp 0x000076049B1CF129
000076049b1d047a  call 0x000076049B0C0860
000076049b1d047f  jmp 0x000076049B1CF151
000076049b1d0484  call 0x000076049B0BF5F0
000076049b1d0489  jmp 0x000076049B1CF15D
000076049b1d048e  call 0x000076049B0BD750
000076049b1d0493  jmp 0x000076049B1CF16A
000076049b1d0498  call 0x000076049B0BC4E0
000076049b1d049d  jmp 0x000076049B1CF177
000076049b1d04a2  call 0x000076049B0C4740
000076049b1d04a7  jmp 0x000076049B1CF184
000076049b1d04ac  call 0x000076049B0B5400
000076049b1d04b1  jmp 0x000076049B1CF191
000076049b1d04b6  call 0x000076049B0B52F0
000076049b1d04bb  jmp 0x000076049B1CF19E
000076049b1d04c0  call 0x000076049B0C4620
000076049b1d04c5  jmp 0x000076049B1CF1AB
000076049b1d04ca  call 0x000076049B0C0860
000076049b1d04cf  jmp 0x000076049B1CF1BE
000076049b1d04d4  call 0x000076049B0BB270
000076049b1d04d9  jmp 0x000076049B1CF1CB
000076049b1d04de  call 0x000076049B0BA000
000076049b1d04e3  jmp 0x000076049B1CF1D8
000076049b1d04e8  call 0x000076049B0B8D90
000076049b1d04ed  jmp 0x000076049B1CF1E5
000076049b1d04f2  call 0x000076049B0B8A20
000076049b1d04f7  jmp 0x000076049B1CF1F2
000076049b1d04fc  call 0x000076049B0B5400
000076049b1d0501  jmp 0x000076049B1CF1FC
000076049b1d0506  call 0x000076049B0C2240
000076049b1d050b  jmp 0x000076049B1CF206
000076049b1d0510  call 0x000076049B0B52F0
000076049b1d0515  jmp 0x000076049B1CF210
000076049b1d051a  call 0x000076049B0C2120
000076049b1d051f  jmp 0x000076049B1CF21A
000076049b1d0524  call 0x000076049B0B77B0
000076049b1d0529  jmp 0x000076049B1CF224
000076049b1d052e  call 0x000076049B0B6550
000076049b1d0533  jmp 0x000076049B1CF22E
000076049b1d0538  call 0x000076049B0BFD50
000076049b1d053d  jmp 0x000076049B1CF240
000076049b1d0542  call 0x000076049B0B8EA0
000076049b1d0547  jmp 0x000076049B1CF24A
000076049b1d054c  call 0x000076049B0BFC30
000076049b1d0551  jmp 0x000076049B1CF257
000076049b1d0556  call 0x000076049B0B8D90
000076049b1d055b  jmp 0x000076049B1CF264
000076049b1d0560  call 0x000076049B0C2240
000076049b1d0565  jmp 0x000076049B1CF271
000076049b1d056a  call 0x000076049B0B5400
000076049b1d056f  jmp 0x000076049B1CF27E
000076049b1d0574  call 0x000076049B0B52F0
000076049b1d0579  jmp 0x000076049B1CF28B
000076049b1d057e  call 0x000076049B0C2120
000076049b1d0583  jmp 0x000076049B1CF298
000076049b1d0588  call 0x000076049B0B52F0
000076049b1d058d  jmp 0x000076049B1CF2AB
000076049b1d0592  call 0x000076049B0B52F0
000076049b1d0597  jmp 0x000076049B1CF2BE
000076049b1d059c  call 0x000076049B0B52F0
000076049b1d05a1  jmp 0x000076049B1CF2D1
000076049b1d05a6  call 0x000076049B0B52F0
000076049b1d05ab  jmp 0x000076049B1CF2E4
000076049b1d05b0  call 0x000076049B0C2240
000076049b1d05b5  jmp 0x000076049B1CF2F9
000076049b1d05ba  call 0x000076049B0C2240
000076049b1d05bf  jmp 0x000076049B1CF30C
000076049b1d05c4  call 0x000076049B0C2120
000076049b1d05c9  jmp 0x000076049B1CF319
000076049b1d05ce  call 0x000076049B0B52F0
000076049b1d05d3  jmp 0x000076049B1CF32C
000076049b1d05d8  call 0x000076049B0B52F0
000076049b1d05dd  jmp 0x000076049B1CF34F
000076049b1d05e2  call 0x000076049B0B52F0
000076049b1d05e7  jmp 0x000076049B1CF362
000076049b1d05ec  call 0x000076049AFFF540
000076049b1d05f1  jmp 0x000076049B1CF380
000076049b1d05f6  call 0x000076049B008C20
000076049b1d05fb  jmp 0x000076049B1CF38A
000076049b1d0600  call 0x000076049B0D6600
000076049b1d0605  jmp 0x000076049B1CF396
000076049b1d060a  call 0x000076049AFFF540
000076049b1d060f  jmp 0x000076049B1CF3A6
000076049b1d0614  call 0x000076049B0C0370
000076049b1d0619  jmp 0x000076049B1CF3D4
000076049b1d061e  call 0x000076049B0BF100
000076049b1d0623  jmp 0x000076049B1CF3DD
000076049b1d0628  call 0x000076049B0C0370
000076049b1d062d  jmp 0x000076049B1CF43B
000076049b1d0632  call 0x000076049B0BF100
000076049b1d0637  jmp 0x000076049B1CF444
000076049b1d063c  call 0x000076049B0C0370
000076049b1d0641  jmp 0x000076049B1CF48B
000076049b1d0646  call 0x000076049B0BF100
000076049b1d064b  jmp 0x000076049B1CF494
000076049b1d0650  call 0x000076049B00B720
000076049b1d0655  jmp 0x000076049B1CF4D7
000076049b1d065a  call 0x000076049B0B47C0
000076049b1d065f  jmp 0x000076049B1CF4EA
000076049b1d0664  call 0x000076049B008B00
000076049b1d0669  jmp 0x000076049B1CF501
000076049b1d066e  call 0x000076049AFFF430
000076049b1d0673  jmp 0x000076049B1CF514
000076049b1d0678  call 0x000076049AFFF430
000076049b1d067d  jmp 0x000076049B1CF527
000076049b1d0682  sub rsp, 0x08
000076049b1d0686  push rax
000076049b1d0687  push rcx
000076049b1d0688  push rdx
000076049b1d0689  push rdi
000076049b1d068a  push rsi
000076049b1d068b  push r8
000076049b1d068d  push r9
000076049b1d068f  push r10
000076049b1d0691  push r11
000076049b1d0693  sub rsp, 0xF0
000076049b1d069a  vmovaps [rsp], xmm0
000076049b1d069f  vmovaps [rsp+0x10], xmm2
000076049b1d06a5  vmovaps [rsp+0x20], xmm3
000076049b1d06ab  vmovaps [rsp+0x30], xmm4
000076049b1d06b1  vmovaps [rsp+0x40], xmm5
000076049b1d06b7  vmovaps [rsp+0x50], xmm6
000076049b1d06bd  vmovaps [rsp+0x60], xmm7
000076049b1d06c3  vmovaps [rsp+0x70], xmm8
000076049b1d06c9  vmovaps [rsp+0x80], xmm9
000076049b1d06d2  vmovaps [rsp+0x90], xmm10
000076049b1d06db  vmovaps [rsp+0xA0], xmm11
000076049b1d06e4  vmovaps [rsp+0xB0], xmm12
000076049b1d06ed  vmovaps [rsp+0xC0], xmm13
000076049b1d06f6  vmovaps [rsp+0xD0], xmm14
000076049b1d06ff  vmovaps [rsp+0xE0], xmm15
000076049b1d0708  sub rsp, 0x30
000076049b1d070c  movaps [rsp], xmm1
000076049b1d0710  movaps [rsp+0x10], xmm15
000076049b1d0716  movaps [rsp+0x20], xmm14
000076049b1d071c  lea rdi, [rsp]
000076049b1d0720  mov esi, 0x00
000076049b1d0725  mov rax, 0x64C06813C530
000076049b1d072f  call rax
000076049b1d0731  movaps xmm1, [rsp]
000076049b1d0735  add rsp, 0x30
000076049b1d0739  vmovaps xmm0, [rsp]
000076049b1d073e  vmovaps xmm2, [rsp+0x10]
000076049b1d0744  vmovaps xmm3, [rsp+0x20]
000076049b1d074a  vmovaps xmm4, [rsp+0x30]
000076049b1d0750  vmovaps xmm5, [rsp+0x40]
000076049b1d0756  vmovaps xmm6, [rsp+0x50]
000076049b1d075c  vmovaps xmm7, [rsp+0x60]
000076049b1d0762  vmovaps xmm8, [rsp+0x70]
000076049b1d0768  vmovaps xmm9, [rsp+0x80]
000076049b1d0771  vmovaps xmm10, [rsp+0x90]
000076049b1d077a  vmovaps xmm11, [rsp+0xA0]
000076049b1d0783  vmovaps xmm12, [rsp+0xB0]
000076049b1d078c  vmovaps xmm13, [rsp+0xC0]
000076049b1d0795  vmovaps xmm14, [rsp+0xD0]
000076049b1d079e  vmovaps xmm15, [rsp+0xE0]
000076049b1d07a7  add rsp, 0xF0
000076049b1d07ae  pop r11
000076049b1d07b0  pop r10
000076049b1d07b2  pop r9
000076049b1d07b4  pop r8
000076049b1d07b6  pop rsi
000076049b1d07b7  pop rdi
000076049b1d07b8  pop rdx
000076049b1d07b9  pop rcx
000076049b1d07ba  pop rax
000076049b1d07bb  add rsp, 0x08
000076049b1d07bf  jmp 0x000076049B1CF581
000076049b1d07c4  sub rsp, 0x08
000076049b1d07c8  push rax
000076049b1d07c9  push rcx
000076049b1d07ca  push rdx
000076049b1d07cb  push rdi
000076049b1d07cc  push rsi
000076049b1d07cd  push r8
000076049b1d07cf  push r9
000076049b1d07d1  push r10
000076049b1d07d3  push r11
000076049b1d07d5  sub rsp, 0xF0
000076049b1d07dc  vmovaps [rsp], xmm0
000076049b1d07e1  vmovaps [rsp+0x10], xmm1
000076049b1d07e7  vmovaps [rsp+0x20], xmm2
000076049b1d07ed  vmovaps [rsp+0x30], xmm3
000076049b1d07f3  vmovaps [rsp+0x40], xmm4
000076049b1d07f9  vmovaps [rsp+0x50], xmm5
000076049b1d07ff  vmovaps [rsp+0x60], xmm6
000076049b1d0805  vmovaps [rsp+0x70], xmm7
000076049b1d080b  vmovaps [rsp+0x80], xmm8
000076049b1d0814  vmovaps [rsp+0x90], xmm9
000076049b1d081d  vmovaps [rsp+0xA0], xmm10
000076049b1d0826  vmovaps [rsp+0xB0], xmm11
000076049b1d082f  vmovaps [rsp+0xC0], xmm12
000076049b1d0838  vmovaps [rsp+0xD0], xmm14
000076049b1d0841  vmovaps [rsp+0xE0], xmm15
000076049b1d084a  sub rsp, 0x30
000076049b1d084e  movaps [rsp], xmm13
000076049b1d0853  movaps [rsp+0x10], xmm1
000076049b1d0858  movaps [rsp+0x20], xmm14
000076049b1d085e  lea rdi, [rsp]
000076049b1d0862  mov esi, 0x00
000076049b1d0867  mov rax, 0x64C06813C530
000076049b1d0871  call rax
000076049b1d0873  movaps xmm13, [rsp]
000076049b1d0878  add rsp, 0x30
000076049b1d087c  vmovaps xmm0, [rsp]
000076049b1d0881  vmovaps xmm1, [rsp+0x10]
000076049b1d0887  vmovaps xmm2, [rsp+0x20]
000076049b1d088d  vmovaps xmm3, [rsp+0x30]
000076049b1d0893  vmovaps xmm4, [rsp+0x40]
000076049b1d0899  vmovaps xmm5, [rsp+0x50]
000076049b1d089f  vmovaps xmm6, [rsp+0x60]
000076049b1d08a5  vmovaps xmm7, [rsp+0x70]
000076049b1d08ab  vmovaps xmm8, [rsp+0x80]
000076049b1d08b4  vmovaps xmm9, [rsp+0x90]
000076049b1d08bd  vmovaps xmm10, [rsp+0xA0]
000076049b1d08c6  vmovaps xmm11, [rsp+0xB0]
000076049b1d08cf  vmovaps xmm12, [rsp+0xC0]
000076049b1d08d8  vmovaps xmm14, [rsp+0xD0]
000076049b1d08e1  vmovaps xmm15, [rsp+0xE0]
000076049b1d08ea  add rsp, 0xF0
000076049b1d08f1  pop r11
000076049b1d08f3  pop r10
000076049b1d08f5  pop r9
000076049b1d08f7  pop r8
000076049b1d08f9  pop rsi
000076049b1d08fa  pop rdi
000076049b1d08fb  pop rdx
000076049b1d08fc  pop rcx
000076049b1d08fd  pop rax
000076049b1d08fe  add rsp, 0x08
000076049b1d0902  jmp 0x000076049B1CF5CF
000076049b1d0907  sub rsp, 0x08
000076049b1d090b  push rax
000076049b1d090c  push rcx
000076049b1d090d  push rdx
000076049b1d090e  push rdi
000076049b1d090f  push rsi
000076049b1d0910  push r8
000076049b1d0912  push r9
000076049b1d0914  push r10
000076049b1d0916  push r11
000076049b1d0918  sub rsp, 0xF0
000076049b1d091f  vmovaps [rsp], xmm0
000076049b1d0924  vmovaps [rsp+0x10], xmm1
000076049b1d092a  vmovaps [rsp+0x20], xmm2
000076049b1d0930  vmovaps [rsp+0x30], xmm3
000076049b1d0936  vmovaps [rsp+0x40], xmm4
000076049b1d093c  vmovaps [rsp+0x50], xmm5
000076049b1d0942  vmovaps [rsp+0x60], xmm6
000076049b1d0948  vmovaps [rsp+0x70], xmm7
000076049b1d094e  vmovaps [rsp+0x80], xmm8
000076049b1d0957  vmovaps [rsp+0x90], xmm9
000076049b1d0960  vmovaps [rsp+0xA0], xmm10
000076049b1d0969  vmovaps [rsp+0xB0], xmm11
000076049b1d0972  vmovaps [rsp+0xC0], xmm12
000076049b1d097b  vmovaps [rsp+0xD0], xmm13
000076049b1d0984  vmovaps [rsp+0xE0], xmm14
000076049b1d098d  sub rsp, 0x30
000076049b1d0991  movaps [rsp], xmm15
000076049b1d0996  movaps [rsp+0x10], xmm14
000076049b1d099c  movaps [rsp+0x20], xmm1
000076049b1d09a1  lea rdi, [rsp]
000076049b1d09a5  mov esi, 0x00
000076049b1d09aa  mov rax, 0x64C06813C530
000076049b1d09b4  call rax
000076049b1d09b6  movaps xmm15, [rsp]
000076049b1d09bb  add rsp, 0x30
000076049b1d09bf  vmovaps xmm0, [rsp]
000076049b1d09c4  vmovaps xmm1, [rsp+0x10]
000076049b1d09ca  vmovaps xmm2, [rsp+0x20]
000076049b1d09d0  vmovaps xmm3, [rsp+0x30]
000076049b1d09d6  vmovaps xmm4, [rsp+0x40]
000076049b1d09dc  vmovaps xmm5, [rsp+0x50]
000076049b1d09e2  vmovaps xmm6, [rsp+0x60]
000076049b1d09e8  vmovaps xmm7, [rsp+0x70]
000076049b1d09ee  vmovaps xmm8, [rsp+0x80]
000076049b1d09f7  vmovaps xmm9, [rsp+0x90]
000076049b1d0a00  vmovaps xmm10, [rsp+0xA0]
000076049b1d0a09  vmovaps xmm11, [rsp+0xB0]
000076049b1d0a12  vmovaps xmm12, [rsp+0xC0]
000076049b1d0a1b  vmovaps xmm13, [rsp+0xD0]
000076049b1d0a24  vmovaps xmm14, [rsp+0xE0]
000076049b1d0a2d  add rsp, 0xF0
000076049b1d0a34  pop r11
000076049b1d0a36  pop r10
000076049b1d0a38  pop r9
000076049b1d0a3a  pop r8
000076049b1d0a3c  pop rsi
000076049b1d0a3d  pop rdi
000076049b1d0a3e  pop rdx
000076049b1d0a3f  pop rcx
000076049b1d0a40  pop rax
000076049b1d0a41  add rsp, 0x08
000076049b1d0a45  jmp 0x000076049B1CF617
000076049b1d0a4a  sub rsp, 0x08
000076049b1d0a4e  push rax
000076049b1d0a4f  push rcx
000076049b1d0a50  push rdx
000076049b1d0a51  push rdi
000076049b1d0a52  push rsi
000076049b1d0a53  push r8
000076049b1d0a55  push r9
000076049b1d0a57  push r10
000076049b1d0a59  push r11
000076049b1d0a5b  sub rsp, 0xF0
000076049b1d0a62  vmovaps [rsp], xmm0
000076049b1d0a67  vmovaps [rsp+0x10], xmm2
000076049b1d0a6d  vmovaps [rsp+0x20], xmm3
000076049b1d0a73  vmovaps [rsp+0x30], xmm4
000076049b1d0a79  vmovaps [rsp+0x40], xmm5
000076049b1d0a7f  vmovaps [rsp+0x50], xmm6
000076049b1d0a85  vmovaps [rsp+0x60], xmm7
000076049b1d0a8b  vmovaps [rsp+0x70], xmm8
000076049b1d0a91  vmovaps [rsp+0x80], xmm9
000076049b1d0a9a  vmovaps [rsp+0x90], xmm10
000076049b1d0aa3  vmovaps [rsp+0xA0], xmm11
000076049b1d0aac  vmovaps [rsp+0xB0], xmm12
000076049b1d0ab5  vmovaps [rsp+0xC0], xmm13
000076049b1d0abe  vmovaps [rsp+0xD0], xmm14
000076049b1d0ac7  vmovaps [rsp+0xE0], xmm15
000076049b1d0ad0  sub rsp, 0x30
000076049b1d0ad4  movaps [rsp], xmm1
000076049b1d0ad8  movaps [rsp+0x10], xmm14
000076049b1d0ade  movaps [rsp+0x20], xmm10
000076049b1d0ae4  lea rdi, [rsp]
000076049b1d0ae8  mov esi, 0x00
000076049b1d0aed  mov rax, 0x64C06813C530
000076049b1d0af7  call rax
000076049b1d0af9  movaps xmm1, [rsp]
000076049b1d0afd  add rsp, 0x30
000076049b1d0b01  vmovaps xmm0, [rsp]
000076049b1d0b06  vmovaps xmm2, [rsp+0x10]
000076049b1d0b0c  vmovaps xmm3, [rsp+0x20]
000076049b1d0b12  vmovaps xmm4, [rsp+0x30]
000076049b1d0b18  vmovaps xmm5, [rsp+0x40]
000076049b1d0b1e  vmovaps xmm6, [rsp+0x50]
000076049b1d0b24  vmovaps xmm7, [rsp+0x60]
000076049b1d0b2a  vmovaps xmm8, [rsp+0x70]
000076049b1d0b30  vmovaps xmm9, [rsp+0x80]
000076049b1d0b39  vmovaps xmm10, [rsp+0x90]
000076049b1d0b42  vmovaps xmm11, [rsp+0xA0]
000076049b1d0b4b  vmovaps xmm12, [rsp+0xB0]
000076049b1d0b54  vmovaps xmm13, [rsp+0xC0]
000076049b1d0b5d  vmovaps xmm14, [rsp+0xD0]
000076049b1d0b66  vmovaps xmm15, [rsp+0xE0]
000076049b1d0b6f  add rsp, 0xF0
000076049b1d0b76  pop r11
000076049b1d0b78  pop r10
000076049b1d0b7a  pop r9
000076049b1d0b7c  pop r8
000076049b1d0b7e  pop rsi
000076049b1d0b7f  pop rdi
000076049b1d0b80  pop rdx
000076049b1d0b81  pop rcx
000076049b1d0b82  pop rax
000076049b1d0b83  add rsp, 0x08
000076049b1d0b87  jmp 0x000076049B1CF631
000076049b1d0b8c  sub rsp, 0x08
000076049b1d0b90  push rax
000076049b1d0b91  push rcx
000076049b1d0b92  push rdx
000076049b1d0b93  push rdi
000076049b1d0b94  push rsi
000076049b1d0b95  push r8
000076049b1d0b97  push r9
000076049b1d0b99  push r10
000076049b1d0b9b  push r11
000076049b1d0b9d  sub rsp, 0xF0
000076049b1d0ba4  vmovaps [rsp], xmm0
000076049b1d0ba9  vmovaps [rsp+0x10], xmm1
000076049b1d0baf  vmovaps [rsp+0x20], xmm2
000076049b1d0bb5  vmovaps [rsp+0x30], xmm3
000076049b1d0bbb  vmovaps [rsp+0x40], xmm4
000076049b1d0bc1  vmovaps [rsp+0x50], xmm5
000076049b1d0bc7  vmovaps [rsp+0x60], xmm6
000076049b1d0bcd  vmovaps [rsp+0x70], xmm7
000076049b1d0bd3  vmovaps [rsp+0x80], xmm8
000076049b1d0bdc  vmovaps [rsp+0x90], xmm9
000076049b1d0be5  vmovaps [rsp+0xA0], xmm10
000076049b1d0bee  vmovaps [rsp+0xB0], xmm11
000076049b1d0bf7  vmovaps [rsp+0xC0], xmm12
000076049b1d0c00  vmovaps [rsp+0xD0], xmm14
000076049b1d0c09  vmovaps [rsp+0xE0], xmm15
000076049b1d0c12  sub rsp, 0x30
000076049b1d0c16  movaps [rsp], xmm13
000076049b1d0c1b  movaps [rsp+0x10], xmm14
000076049b1d0c21  movaps [rsp+0x20], xmm2
000076049b1d0c26  lea rdi, [rsp]
000076049b1d0c2a  mov esi, 0x00
000076049b1d0c2f  mov rax, 0x64C06813C530
000076049b1d0c39  call rax
000076049b1d0c3b  movaps xmm13, [rsp]
000076049b1d0c40  add rsp, 0x30
000076049b1d0c44  vmovaps xmm0, [rsp]
000076049b1d0c49  vmovaps xmm1, [rsp+0x10]
000076049b1d0c4f  vmovaps xmm2, [rsp+0x20]
000076049b1d0c55  vmovaps xmm3, [rsp+0x30]
000076049b1d0c5b  vmovaps xmm4, [rsp+0x40]
000076049b1d0c61  vmovaps xmm5, [rsp+0x50]
000076049b1d0c67  vmovaps xmm6, [rsp+0x60]
000076049b1d0c6d  vmovaps xmm7, [rsp+0x70]
000076049b1d0c73  vmovaps xmm8, [rsp+0x80]
000076049b1d0c7c  vmovaps xmm9, [rsp+0x90]
000076049b1d0c85  vmovaps xmm10, [rsp+0xA0]
000076049b1d0c8e  vmovaps xmm11, [rsp+0xB0]
000076049b1d0c97  vmovaps xmm12, [rsp+0xC0]
000076049b1d0ca0  vmovaps xmm14, [rsp+0xD0]
000076049b1d0ca9  vmovaps xmm15, [rsp+0xE0]
000076049b1d0cb2  add rsp, 0xF0
000076049b1d0cb9  pop r11
000076049b1d0cbb  pop r10
000076049b1d0cbd  pop r9
000076049b1d0cbf  pop r8
000076049b1d0cc1  pop rsi
000076049b1d0cc2  pop rdi
000076049b1d0cc3  pop rdx
000076049b1d0cc4  pop rcx
000076049b1d0cc5  pop rax
000076049b1d0cc6  add rsp, 0x08
000076049b1d0cca  jmp 0x000076049B1CF64C
000076049b1d0ccf  sub rsp, 0x08
000076049b1d0cd3  push rax
000076049b1d0cd4  push rcx
000076049b1d0cd5  push rdx
000076049b1d0cd6  push rdi
000076049b1d0cd7  push rsi
000076049b1d0cd8  push r8
000076049b1d0cda  push r9
000076049b1d0cdc  push r10
000076049b1d0cde  push r11
000076049b1d0ce0  sub rsp, 0xF0
000076049b1d0ce7  vmovaps [rsp], xmm0
000076049b1d0cec  vmovaps [rsp+0x10], xmm2
000076049b1d0cf2  vmovaps [rsp+0x20], xmm3
000076049b1d0cf8  vmovaps [rsp+0x30], xmm4
000076049b1d0cfe  vmovaps [rsp+0x40], xmm5
000076049b1d0d04  vmovaps [rsp+0x50], xmm6
000076049b1d0d0a  vmovaps [rsp+0x60], xmm7
000076049b1d0d10  vmovaps [rsp+0x70], xmm8
000076049b1d0d16  vmovaps [rsp+0x80], xmm9
000076049b1d0d1f  vmovaps [rsp+0x90], xmm10
000076049b1d0d28  vmovaps [rsp+0xA0], xmm11
000076049b1d0d31  vmovaps [rsp+0xB0], xmm12
000076049b1d0d3a  vmovaps [rsp+0xC0], xmm13
000076049b1d0d43  vmovaps [rsp+0xD0], xmm14
000076049b1d0d4c  vmovaps [rsp+0xE0], xmm15
000076049b1d0d55  sub rsp, 0x30
000076049b1d0d59  movaps [rsp], xmm1
000076049b1d0d5d  movaps [rsp+0x10], xmm10
000076049b1d0d63  movaps [rsp+0x20], xmm2
000076049b1d0d68  lea rdi, [rsp]
000076049b1d0d6c  mov esi, 0x00
000076049b1d0d71  mov rax, 0x64C06813C530
000076049b1d0d7b  call rax
000076049b1d0d7d  movaps xmm1, [rsp]
000076049b1d0d81  add rsp, 0x30
000076049b1d0d85  vmovaps xmm0, [rsp]
000076049b1d0d8a  vmovaps xmm2, [rsp+0x10]
000076049b1d0d90  vmovaps xmm3, [rsp+0x20]
000076049b1d0d96  vmovaps xmm4, [rsp+0x30]
000076049b1d0d9c  vmovaps xmm5, [rsp+0x40]
000076049b1d0da2  vmovaps xmm6, [rsp+0x50]
000076049b1d0da8  vmovaps xmm7, [rsp+0x60]
000076049b1d0dae  vmovaps xmm8, [rsp+0x70]
000076049b1d0db4  vmovaps xmm9, [rsp+0x80]
000076049b1d0dbd  vmovaps xmm10, [rsp+0x90]
000076049b1d0dc6  vmovaps xmm11, [rsp+0xA0]
000076049b1d0dcf  vmovaps xmm12, [rsp+0xB0]
000076049b1d0dd8  vmovaps xmm13, [rsp+0xC0]
000076049b1d0de1  vmovaps xmm14, [rsp+0xD0]
000076049b1d0dea  vmovaps xmm15, [rsp+0xE0]
000076049b1d0df3  add rsp, 0xF0
000076049b1d0dfa  pop r11
000076049b1d0dfc  pop r10
000076049b1d0dfe  pop r9
000076049b1d0e00  pop r8
000076049b1d0e02  pop rsi
000076049b1d0e03  pop rdi
000076049b1d0e04  pop rdx
000076049b1d0e05  pop rcx
000076049b1d0e06  pop rax
000076049b1d0e07  add rsp, 0x08
000076049b1d0e0b  jmp 0x000076049B1CF6B4
000076049b1d0e10  sub rsp, 0x08
000076049b1d0e14  push rax
000076049b1d0e15  push rcx
000076049b1d0e16  push rdx
000076049b1d0e17  push rdi
000076049b1d0e18  push rsi
000076049b1d0e19  push r8
000076049b1d0e1b  push r9
000076049b1d0e1d  push r10
000076049b1d0e1f  push r11
000076049b1d0e21  sub rsp, 0xF0
000076049b1d0e28  vmovaps [rsp], xmm0
000076049b1d0e2d  vmovaps [rsp+0x10], xmm1
000076049b1d0e33  vmovaps [rsp+0x20], xmm2
000076049b1d0e39  vmovaps [rsp+0x30], xmm3
000076049b1d0e3f  vmovaps [rsp+0x40], xmm4
000076049b1d0e45  vmovaps [rsp+0x50], xmm5
000076049b1d0e4b  vmovaps [rsp+0x60], xmm6
000076049b1d0e51  vmovaps [rsp+0x70], xmm7
000076049b1d0e57  vmovaps [rsp+0x80], xmm8
000076049b1d0e60  vmovaps [rsp+0x90], xmm9
000076049b1d0e69  vmovaps [rsp+0xA0], xmm10
000076049b1d0e72  vmovaps [rsp+0xB0], xmm11
000076049b1d0e7b  vmovaps [rsp+0xC0], xmm12
000076049b1d0e84  vmovaps [rsp+0xD0], xmm13
000076049b1d0e8d  vmovaps [rsp+0xE0], xmm14
000076049b1d0e96  sub rsp, 0x30
000076049b1d0e9a  movaps [rsp], xmm15
000076049b1d0e9f  movaps [rsp+0x10], xmm10
000076049b1d0ea5  movaps [rsp+0x20], xmm2
000076049b1d0eaa  lea rdi, [rsp]
000076049b1d0eae  mov esi, 0x00
000076049b1d0eb3  mov rax, 0x64C06813C530
000076049b1d0ebd  call rax
000076049b1d0ebf  movaps xmm15, [rsp]
000076049b1d0ec4  add rsp, 0x30
000076049b1d0ec8  vmovaps xmm0, [rsp]
000076049b1d0ecd  vmovaps xmm1, [rsp+0x10]
000076049b1d0ed3  vmovaps xmm2, [rsp+0x20]
000076049b1d0ed9  vmovaps xmm3, [rsp+0x30]
000076049b1d0edf  vmovaps xmm4, [rsp+0x40]
000076049b1d0ee5  vmovaps xmm5, [rsp+0x50]
000076049b1d0eeb  vmovaps xmm6, [rsp+0x60]
000076049b1d0ef1  vmovaps xmm7, [rsp+0x70]
000076049b1d0ef7  vmovaps xmm8, [rsp+0x80]
000076049b1d0f00  vmovaps xmm9, [rsp+0x90]
000076049b1d0f09  vmovaps xmm10, [rsp+0xA0]
000076049b1d0f12  vmovaps xmm11, [rsp+0xB0]
000076049b1d0f1b  vmovaps xmm12, [rsp+0xC0]
000076049b1d0f24  vmovaps xmm13, [rsp+0xD0]
000076049b1d0f2d  vmovaps xmm14, [rsp+0xE0]
000076049b1d0f36  add rsp, 0xF0
000076049b1d0f3d  pop r11
000076049b1d0f3f  pop r10
000076049b1d0f41  pop r9
000076049b1d0f43  pop r8
000076049b1d0f45  pop rsi
000076049b1d0f46  pop rdi
000076049b1d0f47  pop rdx
000076049b1d0f48  pop rcx
000076049b1d0f49  pop rax
000076049b1d0f4a  add rsp, 0x08
000076049b1d0f4e  jmp 0x000076049B1CF706
000076049b1d0f53  sub rsp, 0x08
000076049b1d0f57  push rax
000076049b1d0f58  push rcx
000076049b1d0f59  push rdx
000076049b1d0f5a  push rdi
000076049b1d0f5b  push rsi
000076049b1d0f5c  push r8
000076049b1d0f5e  push r9
000076049b1d0f60  push r10
000076049b1d0f62  push r11
000076049b1d0f64  sub rsp, 0xF0
000076049b1d0f6b  vmovaps [rsp], xmm0
000076049b1d0f70  vmovaps [rsp+0x10], xmm2
000076049b1d0f76  vmovaps [rsp+0x20], xmm3
000076049b1d0f7c  vmovaps [rsp+0x30], xmm4
000076049b1d0f82  vmovaps [rsp+0x40], xmm5
000076049b1d0f88  vmovaps [rsp+0x50], xmm6
000076049b1d0f8e  vmovaps [rsp+0x60], xmm7
000076049b1d0f94  vmovaps [rsp+0x70], xmm8
000076049b1d0f9a  vmovaps [rsp+0x80], xmm9
000076049b1d0fa3  vmovaps [rsp+0x90], xmm10
000076049b1d0fac  vmovaps [rsp+0xA0], xmm11
000076049b1d0fb5  vmovaps [rsp+0xB0], xmm12
000076049b1d0fbe  vmovaps [rsp+0xC0], xmm13
000076049b1d0fc7  vmovaps [rsp+0xD0], xmm14
000076049b1d0fd0  vmovaps [rsp+0xE0], xmm15
000076049b1d0fd9  sub rsp, 0x30
000076049b1d0fdd  movaps [rsp], xmm1
000076049b1d0fe1  movaps [rsp+0x10], xmm10
000076049b1d0fe7  movaps [rsp+0x20], xmm12
000076049b1d0fed  lea rdi, [rsp]
000076049b1d0ff1  mov esi, 0x00
000076049b1d0ff6  mov rax, 0x64C06813C530
000076049b1d1000  call rax
000076049b1d1002  movaps xmm1, [rsp]
000076049b1d1006  add rsp, 0x30
000076049b1d100a  vmovaps xmm0, [rsp]
000076049b1d100f  vmovaps xmm2, [rsp+0x10]
000076049b1d1015  vmovaps xmm3, [rsp+0x20]
000076049b1d101b  vmovaps xmm4, [rsp+0x30]
000076049b1d1021  vmovaps xmm5, [rsp+0x40]
000076049b1d1027  vmovaps xmm6, [rsp+0x50]
000076049b1d102d  vmovaps xmm7, [rsp+0x60]
000076049b1d1033  vmovaps xmm8, [rsp+0x70]
000076049b1d1039  vmovaps xmm9, [rsp+0x80]
000076049b1d1042  vmovaps xmm10, [rsp+0x90]
000076049b1d104b  vmovaps xmm11, [rsp+0xA0]
000076049b1d1054  vmovaps xmm12, [rsp+0xB0]
000076049b1d105d  vmovaps xmm13, [rsp+0xC0]
000076049b1d1066  vmovaps xmm14, [rsp+0xD0]
000076049b1d106f  vmovaps xmm15, [rsp+0xE0]
000076049b1d1078  add rsp, 0xF0
000076049b1d107f  pop r11
000076049b1d1081  pop r10
000076049b1d1083  pop r9
000076049b1d1085  pop r8
000076049b1d1087  pop rsi
000076049b1d1088  pop rdi
000076049b1d1089  pop rdx
000076049b1d108a  pop rcx
000076049b1d108b  pop rax
000076049b1d108c  add rsp, 0x08
000076049b1d1090  jmp 0x000076049B1CF732
000076049b1d1095  sub rsp, 0x08
000076049b1d1099  push rax
000076049b1d109a  push rcx
000076049b1d109b  push rdx
000076049b1d109c  push rdi
000076049b1d109d  push rsi
000076049b1d109e  push r8
000076049b1d10a0  push r9
000076049b1d10a2  push r10
000076049b1d10a4  push r11
000076049b1d10a6  sub rsp, 0xF0
000076049b1d10ad  vmovaps [rsp], xmm0
000076049b1d10b2  vmovaps [rsp+0x10], xmm1
000076049b1d10b8  vmovaps [rsp+0x20], xmm2
000076049b1d10be  vmovaps [rsp+0x30], xmm3
000076049b1d10c4  vmovaps [rsp+0x40], xmm4
000076049b1d10ca  vmovaps [rsp+0x50], xmm5
000076049b1d10d0  vmovaps [rsp+0x60], xmm6
000076049b1d10d6  vmovaps [rsp+0x70], xmm7
000076049b1d10dc  vmovaps [rsp+0x80], xmm8
000076049b1d10e5  vmovaps [rsp+0x90], xmm9
000076049b1d10ee  vmovaps [rsp+0xA0], xmm10
000076049b1d10f7  vmovaps [rsp+0xB0], xmm11
000076049b1d1100  vmovaps [rsp+0xC0], xmm12
000076049b1d1109  vmovaps [rsp+0xD0], xmm13
000076049b1d1112  vmovaps [rsp+0xE0], xmm14
000076049b1d111b  sub rsp, 0x30
000076049b1d111f  movaps [rsp], xmm15
000076049b1d1124  movaps [rsp+0x10], xmm10
000076049b1d112a  movaps [rsp+0x20], xmm12
000076049b1d1130  lea rdi, [rsp]
000076049b1d1134  mov esi, 0x00
000076049b1d1139  mov rax, 0x64C06813C530
000076049b1d1143  call rax
000076049b1d1145  movaps xmm15, [rsp]
000076049b1d114a  add rsp, 0x30
000076049b1d114e  vmovaps xmm0, [rsp]
000076049b1d1153  vmovaps xmm1, [rsp+0x10]
000076049b1d1159  vmovaps xmm2, [rsp+0x20]
000076049b1d115f  vmovaps xmm3, [rsp+0x30]
000076049b1d1165  vmovaps xmm4, [rsp+0x40]
000076049b1d116b  vmovaps xmm5, [rsp+0x50]
000076049b1d1171  vmovaps xmm6, [rsp+0x60]
000076049b1d1177  vmovaps xmm7, [rsp+0x70]
000076049b1d117d  vmovaps xmm8, [rsp+0x80]
000076049b1d1186  vmovaps xmm9, [rsp+0x90]
000076049b1d118f  vmovaps xmm10, [rsp+0xA0]
000076049b1d1198  vmovaps xmm11, [rsp+0xB0]
000076049b1d11a1  vmovaps xmm12, [rsp+0xC0]
000076049b1d11aa  vmovaps xmm13, [rsp+0xD0]
000076049b1d11b3  vmovaps xmm14, [rsp+0xE0]
000076049b1d11bc  add rsp, 0xF0
000076049b1d11c3  pop r11
000076049b1d11c5  pop r10
000076049b1d11c7  pop r9
000076049b1d11c9  pop r8
000076049b1d11cb  pop rsi
000076049b1d11cc  pop rdi
000076049b1d11cd  pop rdx
000076049b1d11ce  pop rcx
000076049b1d11cf  pop rax
000076049b1d11d0  add rsp, 0x08
000076049b1d11d4  jmp 0x000076049B1CF75E
000076049b1d11d9  call 0x000076049AFFF430
000076049b1d11de  jmp 0x000076049B1CF7EE
000076049b1d11e3  call 0x000076049AFFF430
000076049b1d11e8  jmp 0x000076049B1CF801
000076049b1d11ed  sub rsp, 0x08
000076049b1d11f1  push rax
000076049b1d11f2  push rcx
000076049b1d11f3  push rdx
000076049b1d11f4  push rdi
000076049b1d11f5  push rsi
000076049b1d11f6  push r8
000076049b1d11f8  push r9
000076049b1d11fa  push r10
000076049b1d11fc  push r11
000076049b1d11fe  sub rsp, 0xF0
000076049b1d1205  vmovaps [rsp], xmm0
000076049b1d120a  vmovaps [rsp+0x10], xmm2
000076049b1d1210  vmovaps [rsp+0x20], xmm3
000076049b1d1216  vmovaps [rsp+0x30], xmm4
000076049b1d121c  vmovaps [rsp+0x40], xmm5
000076049b1d1222  vmovaps [rsp+0x50], xmm6
000076049b1d1228  vmovaps [rsp+0x60], xmm7
000076049b1d122e  vmovaps [rsp+0x70], xmm8
000076049b1d1234  vmovaps [rsp+0x80], xmm9
000076049b1d123d  vmovaps [rsp+0x90], xmm10
000076049b1d1246  vmovaps [rsp+0xA0], xmm11
000076049b1d124f  vmovaps [rsp+0xB0], xmm12
000076049b1d1258  vmovaps [rsp+0xC0], xmm13
000076049b1d1261  vmovaps [rsp+0xD0], xmm14
000076049b1d126a  vmovaps [rsp+0xE0], xmm15
000076049b1d1273  sub rsp, 0x30
000076049b1d1277  movaps [rsp], xmm1
000076049b1d127b  movaps [rsp+0x10], xmm13
000076049b1d1281  movaps [rsp+0x20], xmm2
000076049b1d1286  lea rdi, [rsp]
000076049b1d128a  mov esi, 0x00
000076049b1d128f  mov rax, 0x64C06813C530
000076049b1d1299  call rax
000076049b1d129b  movaps xmm1, [rsp]
000076049b1d129f  add rsp, 0x30
000076049b1d12a3  vmovaps xmm0, [rsp]
000076049b1d12a8  vmovaps xmm2, [rsp+0x10]
000076049b1d12ae  vmovaps xmm3, [rsp+0x20]
000076049b1d12b4  vmovaps xmm4, [rsp+0x30]
000076049b1d12ba  vmovaps xmm5, [rsp+0x40]
000076049b1d12c0  vmovaps xmm6, [rsp+0x50]
000076049b1d12c6  vmovaps xmm7, [rsp+0x60]
000076049b1d12cc  vmovaps xmm8, [rsp+0x70]
000076049b1d12d2  vmovaps xmm9, [rsp+0x80]
000076049b1d12db  vmovaps xmm10, [rsp+0x90]
000076049b1d12e4  vmovaps xmm11, [rsp+0xA0]
000076049b1d12ed  vmovaps xmm12, [rsp+0xB0]
000076049b1d12f6  vmovaps xmm13, [rsp+0xC0]
000076049b1d12ff  vmovaps xmm14, [rsp+0xD0]
000076049b1d1308  vmovaps xmm15, [rsp+0xE0]
000076049b1d1311  add rsp, 0xF0
000076049b1d1318  pop r11
000076049b1d131a  pop r10
000076049b1d131c  pop r9
000076049b1d131e  pop r8
000076049b1d1320  pop rsi
000076049b1d1321  pop rdi
000076049b1d1322  pop rdx
000076049b1d1323  pop rcx
000076049b1d1324  pop rax
000076049b1d1325  add rsp, 0x08
000076049b1d1329  jmp 0x000076049B1CF82C
000076049b1d132e  call 0x000076049B00E760
000076049b1d1333  jmp 0x000076049B1CF839
000076049b1d1338  sub rsp, 0x08
000076049b1d133c  push rax
000076049b1d133d  push rcx
000076049b1d133e  push rdx
000076049b1d133f  push rdi
000076049b1d1340  push rsi
000076049b1d1341  push r8
000076049b1d1343  push r9
000076049b1d1345  push r10
000076049b1d1347  push r11
000076049b1d1349  sub rsp, 0xF0
000076049b1d1350  vmovaps [rsp], xmm0
000076049b1d1355  vmovaps [rsp+0x10], xmm1
000076049b1d135b  vmovaps [rsp+0x20], xmm2
000076049b1d1361  vmovaps [rsp+0x30], xmm3
000076049b1d1367  vmovaps [rsp+0x40], xmm4
000076049b1d136d  vmovaps [rsp+0x50], xmm5
000076049b1d1373  vmovaps [rsp+0x60], xmm6
000076049b1d1379  vmovaps [rsp+0x70], xmm7
000076049b1d137f  vmovaps [rsp+0x80], xmm8
000076049b1d1388  vmovaps [rsp+0x90], xmm9
000076049b1d1391  vmovaps [rsp+0xA0], xmm10
000076049b1d139a  vmovaps [rsp+0xB0], xmm11
000076049b1d13a3  vmovaps [rsp+0xC0], xmm12
000076049b1d13ac  vmovaps [rsp+0xD0], xmm14
000076049b1d13b5  vmovaps [rsp+0xE0], xmm15
000076049b1d13be  sub rsp, 0x30
000076049b1d13c2  movaps [rsp], xmm13
000076049b1d13c7  movaps [rsp+0x10], xmm2
000076049b1d13cc  movaps [rsp+0x20], xmm1
000076049b1d13d1  lea rdi, [rsp]
000076049b1d13d5  mov esi, 0x00
000076049b1d13da  mov rax, 0x64C06813C530
000076049b1d13e4  call rax
000076049b1d13e6  movaps xmm13, [rsp]
000076049b1d13eb  add rsp, 0x30
000076049b1d13ef  vmovaps xmm0, [rsp]
000076049b1d13f4  vmovaps xmm1, [rsp+0x10]
000076049b1d13fa  vmovaps xmm2, [rsp+0x20]
000076049b1d1400  vmovaps xmm3, [rsp+0x30]
000076049b1d1406  vmovaps xmm4, [rsp+0x40]
000076049b1d140c  vmovaps xmm5, [rsp+0x50]
000076049b1d1412  vmovaps xmm6, [rsp+0x60]
000076049b1d1418  vmovaps xmm7, [rsp+0x70]
000076049b1d141e  vmovaps xmm8, [rsp+0x80]
000076049b1d1427  vmovaps xmm9, [rsp+0x90]
000076049b1d1430  vmovaps xmm10, [rsp+0xA0]
000076049b1d1439  vmovaps xmm11, [rsp+0xB0]
000076049b1d1442  vmovaps xmm12, [rsp+0xC0]
000076049b1d144b  vmovaps xmm14, [rsp+0xD0]
000076049b1d1454  vmovaps xmm15, [rsp+0xE0]
000076049b1d145d  add rsp, 0xF0
000076049b1d1464  pop r11
000076049b1d1466  pop r10
000076049b1d1468  pop r9
000076049b1d146a  pop r8
000076049b1d146c  pop rsi
000076049b1d146d  pop rdi
000076049b1d146e  pop rdx
000076049b1d146f  pop rcx
000076049b1d1470  pop rax
000076049b1d1471  add rsp, 0x08
000076049b1d1475  jmp 0x000076049B1CF878
000076049b1d147a  sub rsp, 0x08
000076049b1d147e  push rax
000076049b1d147f  push rcx
000076049b1d1480  push rdx
000076049b1d1481  push rdi
000076049b1d1482  push rsi
000076049b1d1483  push r8
000076049b1d1485  push r9
000076049b1d1487  push r10
000076049b1d1489  push r11
000076049b1d148b  sub rsp, 0xF0
000076049b1d1492  vmovaps [rsp], xmm0
000076049b1d1497  vmovaps [rsp+0x10], xmm2
000076049b1d149d  vmovaps [rsp+0x20], xmm3
000076049b1d14a3  vmovaps [rsp+0x30], xmm4
000076049b1d14a9  vmovaps [rsp+0x40], xmm5
000076049b1d14af  vmovaps [rsp+0x50], xmm6
000076049b1d14b5  vmovaps [rsp+0x60], xmm7
000076049b1d14bb  vmovaps [rsp+0x70], xmm8
000076049b1d14c1  vmovaps [rsp+0x80], xmm9
000076049b1d14ca  vmovaps [rsp+0x90], xmm10
000076049b1d14d3  vmovaps [rsp+0xA0], xmm11
000076049b1d14dc  vmovaps [rsp+0xB0], xmm12
000076049b1d14e5  vmovaps [rsp+0xC0], xmm13
000076049b1d14ee  vmovaps [rsp+0xD0], xmm14
000076049b1d14f7  vmovaps [rsp+0xE0], xmm15
000076049b1d1500  sub rsp, 0x30
000076049b1d1504  movaps [rsp], xmm1
000076049b1d1508  movaps [rsp+0x10], xmm15
000076049b1d150e  movaps [rsp+0x20], xmm2
000076049b1d1513  lea rdi, [rsp]
000076049b1d1517  mov esi, 0x00
000076049b1d151c  mov rax, 0x64C06813C530
000076049b1d1526  call rax
000076049b1d1528  movaps xmm1, [rsp]
000076049b1d152c  add rsp, 0x30
000076049b1d1530  vmovaps xmm0, [rsp]
000076049b1d1535  vmovaps xmm2, [rsp+0x10]
000076049b1d153b  vmovaps xmm3, [rsp+0x20]
000076049b1d1541  vmovaps xmm4, [rsp+0x30]
000076049b1d1547  vmovaps xmm5, [rsp+0x40]
000076049b1d154d  vmovaps xmm6, [rsp+0x50]
000076049b1d1553  vmovaps xmm7, [rsp+0x60]
000076049b1d1559  vmovaps xmm8, [rsp+0x70]
000076049b1d155f  vmovaps xmm9, [rsp+0x80]
000076049b1d1568  vmovaps xmm10, [rsp+0x90]
000076049b1d1571  vmovaps xmm11, [rsp+0xA0]
000076049b1d157a  vmovaps xmm12, [rsp+0xB0]
000076049b1d1583  vmovaps xmm13, [rsp+0xC0]
000076049b1d158c  vmovaps xmm14, [rsp+0xD0]
000076049b1d1595  vmovaps xmm15, [rsp+0xE0]
000076049b1d159e  add rsp, 0xF0
000076049b1d15a5  pop r11
000076049b1d15a7  pop r10
000076049b1d15a9  pop r9
000076049b1d15ab  pop r8
000076049b1d15ad  pop rsi
000076049b1d15ae  pop rdi
000076049b1d15af  pop rdx
000076049b1d15b0  pop rcx
000076049b1d15b1  pop rax
000076049b1d15b2  add rsp, 0x08
000076049b1d15b6  jmp 0x000076049B1CF8AC
000076049b1d15bb  sub rsp, 0x08
000076049b1d15bf  push rax
000076049b1d15c0  push rcx
000076049b1d15c1  push rdx
000076049b1d15c2  push rdi
000076049b1d15c3  push rsi
000076049b1d15c4  push r8
000076049b1d15c6  push r9
000076049b1d15c8  push r10
000076049b1d15ca  push r11
000076049b1d15cc  sub rsp, 0xF0
000076049b1d15d3  vmovaps [rsp], xmm0
000076049b1d15d8  vmovaps [rsp+0x10], xmm1
000076049b1d15de  vmovaps [rsp+0x20], xmm2
000076049b1d15e4  vmovaps [rsp+0x30], xmm3
000076049b1d15ea  vmovaps [rsp+0x40], xmm4
000076049b1d15f0  vmovaps [rsp+0x50], xmm5
000076049b1d15f6  vmovaps [rsp+0x60], xmm6
000076049b1d15fc  vmovaps [rsp+0x70], xmm7
000076049b1d1602  vmovaps [rsp+0x80], xmm8
000076049b1d160b  vmovaps [rsp+0x90], xmm9
000076049b1d1614  vmovaps [rsp+0xA0], xmm10
000076049b1d161d  vmovaps [rsp+0xB0], xmm11
000076049b1d1626  vmovaps [rsp+0xC0], xmm12
000076049b1d162f  vmovaps [rsp+0xD0], xmm13
000076049b1d1638  vmovaps [rsp+0xE0], xmm15
000076049b1d1641  sub rsp, 0x30
000076049b1d1645  movaps [rsp], xmm14
000076049b1d164a  movaps [rsp+0x10], xmm2
000076049b1d164f  movaps [rsp+0x20], xmm15
000076049b1d1655  lea rdi, [rsp]
000076049b1d1659  mov esi, 0x00
000076049b1d165e  mov rax, 0x64C06813C530
000076049b1d1668  call rax
000076049b1d166a  movaps xmm14, [rsp]
000076049b1d166f  add rsp, 0x30
000076049b1d1673  vmovaps xmm0, [rsp]
000076049b1d1678  vmovaps xmm1, [rsp+0x10]
000076049b1d167e  vmovaps xmm2, [rsp+0x20]
000076049b1d1684  vmovaps xmm3, [rsp+0x30]
000076049b1d168a  vmovaps xmm4, [rsp+0x40]
000076049b1d1690  vmovaps xmm5, [rsp+0x50]
000076049b1d1696  vmovaps xmm6, [rsp+0x60]
000076049b1d169c  vmovaps xmm7, [rsp+0x70]
000076049b1d16a2  vmovaps xmm8, [rsp+0x80]
000076049b1d16ab  vmovaps xmm9, [rsp+0x90]
000076049b1d16b4  vmovaps xmm10, [rsp+0xA0]
000076049b1d16bd  vmovaps xmm11, [rsp+0xB0]
000076049b1d16c6  vmovaps xmm12, [rsp+0xC0]
000076049b1d16cf  vmovaps xmm13, [rsp+0xD0]
000076049b1d16d8  vmovaps xmm15, [rsp+0xE0]
000076049b1d16e1  add rsp, 0xF0
000076049b1d16e8  pop r11
000076049b1d16ea  pop r10
000076049b1d16ec  pop r9
000076049b1d16ee  pop r8
000076049b1d16f0  pop rsi
000076049b1d16f1  pop rdi
000076049b1d16f2  pop rdx
000076049b1d16f3  pop rcx
000076049b1d16f4  pop rax
000076049b1d16f5  add rsp, 0x08
000076049b1d16f9  jmp 0x000076049B1CF8E7
000076049b1d16fe  sub rsp, 0x08
000076049b1d1702  push rax
000076049b1d1703  push rcx
000076049b1d1704  push rdx
000076049b1d1705  push rdi
000076049b1d1706  push rsi
000076049b1d1707  push r8
000076049b1d1709  push r9
000076049b1d170b  push r10
000076049b1d170d  push r11
000076049b1d170f  sub rsp, 0xF0
000076049b1d1716  vmovaps [rsp], xmm0
000076049b1d171b  vmovaps [rsp+0x10], xmm1
000076049b1d1721  vmovaps [rsp+0x20], xmm2
000076049b1d1727  vmovaps [rsp+0x30], xmm3
000076049b1d172d  vmovaps [rsp+0x40], xmm4
000076049b1d1733  vmovaps [rsp+0x50], xmm5
000076049b1d1739  vmovaps [rsp+0x60], xmm6
000076049b1d173f  vmovaps [rsp+0x70], xmm7
000076049b1d1745  vmovaps [rsp+0x80], xmm8
000076049b1d174e  vmovaps [rsp+0x90], xmm9
000076049b1d1757  vmovaps [rsp+0xA0], xmm10
000076049b1d1760  vmovaps [rsp+0xB0], xmm11
000076049b1d1769  vmovaps [rsp+0xC0], xmm12
000076049b1d1772  vmovaps [rsp+0xD0], xmm13
000076049b1d177b  vmovaps [rsp+0xE0], xmm14
000076049b1d1784  sub rsp, 0x30
000076049b1d1788  movaps [rsp], xmm15
000076049b1d178d  movaps [rsp+0x10], xmm2
000076049b1d1792  movaps [rsp+0x20], xmm1
000076049b1d1797  lea rdi, [rsp]
000076049b1d179b  mov esi, 0x00
000076049b1d17a0  mov rax, 0x64C06813C530
000076049b1d17aa  call rax
000076049b1d17ac  movaps xmm15, [rsp]
000076049b1d17b1  add rsp, 0x30
000076049b1d17b5  vmovaps xmm0, [rsp]
000076049b1d17ba  vmovaps xmm1, [rsp+0x10]
000076049b1d17c0  vmovaps xmm2, [rsp+0x20]
000076049b1d17c6  vmovaps xmm3, [rsp+0x30]
000076049b1d17cc  vmovaps xmm4, [rsp+0x40]
000076049b1d17d2  vmovaps xmm5, [rsp+0x50]
000076049b1d17d8  vmovaps xmm6, [rsp+0x60]
000076049b1d17de  vmovaps xmm7, [rsp+0x70]
000076049b1d17e4  vmovaps xmm8, [rsp+0x80]
000076049b1d17ed  vmovaps xmm9, [rsp+0x90]
000076049b1d17f6  vmovaps xmm10, [rsp+0xA0]
000076049b1d17ff  vmovaps xmm11, [rsp+0xB0]
000076049b1d1808  vmovaps xmm12, [rsp+0xC0]
000076049b1d1811  vmovaps xmm13, [rsp+0xD0]
000076049b1d181a  vmovaps xmm14, [rsp+0xE0]
000076049b1d1823  add rsp, 0xF0
000076049b1d182a  pop r11
000076049b1d182c  pop r10
000076049b1d182e  pop r9
000076049b1d1830  pop r8
000076049b1d1832  pop rsi
000076049b1d1833  pop rdi
000076049b1d1834  pop rdx
000076049b1d1835  pop rcx
000076049b1d1836  pop rax
000076049b1d1837  add rsp, 0x08
000076049b1d183b  jmp 0x000076049B1CF923
000076049b1d1840  call 0x000076049AFFF430
000076049b1d1845  jmp 0x000076049B1CF930
000076049b1d184a  sub rsp, 0x08
000076049b1d184e  push rax
000076049b1d184f  push rcx
000076049b1d1850  push rdx
000076049b1d1851  push rdi
000076049b1d1852  push rsi
000076049b1d1853  push r8
000076049b1d1855  push r9
000076049b1d1857  push r10
000076049b1d1859  push r11
000076049b1d185b  sub rsp, 0xF0
000076049b1d1862  vmovaps [rsp], xmm0
000076049b1d1867  vmovaps [rsp+0x10], xmm1
000076049b1d186d  vmovaps [rsp+0x20], xmm3
000076049b1d1873  vmovaps [rsp+0x30], xmm4
000076049b1d1879  vmovaps [rsp+0x40], xmm5
000076049b1d187f  vmovaps [rsp+0x50], xmm6
000076049b1d1885  vmovaps [rsp+0x60], xmm7
000076049b1d188b  vmovaps [rsp+0x70], xmm8
000076049b1d1891  vmovaps [rsp+0x80], xmm9
000076049b1d189a  vmovaps [rsp+0x90], xmm10
000076049b1d18a3  vmovaps [rsp+0xA0], xmm11
000076049b1d18ac  vmovaps [rsp+0xB0], xmm12
000076049b1d18b5  vmovaps [rsp+0xC0], xmm13
000076049b1d18be  vmovaps [rsp+0xD0], xmm14
000076049b1d18c7  vmovaps [rsp+0xE0], xmm15
000076049b1d18d0  sub rsp, 0x30
000076049b1d18d4  movaps [rsp], xmm2
000076049b1d18d8  movaps [rsp+0x10], xmm1
000076049b1d18dd  movaps [rsp+0x20], xmm14
000076049b1d18e3  lea rdi, [rsp]
000076049b1d18e7  mov esi, 0x00
000076049b1d18ec  mov rax, 0x64C06813C530
000076049b1d18f6  call rax
000076049b1d18f8  movaps xmm2, [rsp]
000076049b1d18fc  add rsp, 0x30
000076049b1d1900  vmovaps xmm0, [rsp]
000076049b1d1905  vmovaps xmm1, [rsp+0x10]
000076049b1d190b  vmovaps xmm3, [rsp+0x20]
000076049b1d1911  vmovaps xmm4, [rsp+0x30]
000076049b1d1917  vmovaps xmm5, [rsp+0x40]
000076049b1d191d  vmovaps xmm6, [rsp+0x50]
000076049b1d1923  vmovaps xmm7, [rsp+0x60]
000076049b1d1929  vmovaps xmm8, [rsp+0x70]
000076049b1d192f  vmovaps xmm9, [rsp+0x80]
000076049b1d1938  vmovaps xmm10, [rsp+0x90]
000076049b1d1941  vmovaps xmm11, [rsp+0xA0]
000076049b1d194a  vmovaps xmm12, [rsp+0xB0]
000076049b1d1953  vmovaps xmm13, [rsp+0xC0]
000076049b1d195c  vmovaps xmm14, [rsp+0xD0]
000076049b1d1965  vmovaps xmm15, [rsp+0xE0]
000076049b1d196e  add rsp, 0xF0
000076049b1d1975  pop r11
000076049b1d1977  pop r10
000076049b1d1979  pop r9
000076049b1d197b  pop r8
000076049b1d197d  pop rsi
000076049b1d197e  pop rdi
000076049b1d197f  pop rdx
000076049b1d1980  pop rcx
000076049b1d1981  pop rax
000076049b1d1982  add rsp, 0x08
000076049b1d1986  jmp 0x000076049B1CF96D
000076049b1d198b  sub rsp, 0x08
000076049b1d198f  push rax
000076049b1d1990  push rcx
000076049b1d1991  push rdx
000076049b1d1992  push rdi
000076049b1d1993  push rsi
000076049b1d1994  push r8
000076049b1d1996  push r9
000076049b1d1998  push r10
000076049b1d199a  push r11
000076049b1d199c  sub rsp, 0xF0
000076049b1d19a3  vmovaps [rsp], xmm0
000076049b1d19a8  vmovaps [rsp+0x10], xmm1
000076049b1d19ae  vmovaps [rsp+0x20], xmm2
000076049b1d19b4  vmovaps [rsp+0x30], xmm3
000076049b1d19ba  vmovaps [rsp+0x40], xmm4
000076049b1d19c0  vmovaps [rsp+0x50], xmm5
000076049b1d19c6  vmovaps [rsp+0x60], xmm6
000076049b1d19cc  vmovaps [rsp+0x70], xmm7
000076049b1d19d2  vmovaps [rsp+0x80], xmm8
000076049b1d19db  vmovaps [rsp+0x90], xmm9
000076049b1d19e4  vmovaps [rsp+0xA0], xmm10
000076049b1d19ed  vmovaps [rsp+0xB0], xmm11
000076049b1d19f6  vmovaps [rsp+0xC0], xmm12
000076049b1d19ff  vmovaps [rsp+0xD0], xmm13
000076049b1d1a08  vmovaps [rsp+0xE0], xmm14
000076049b1d1a11  sub rsp, 0x30
000076049b1d1a15  movaps [rsp], xmm15
000076049b1d1a1a  movaps [rsp+0x10], xmm14
000076049b1d1a20  movaps [rsp+0x20], xmm1
000076049b1d1a25  lea rdi, [rsp]
000076049b1d1a29  mov esi, 0x00
000076049b1d1a2e  mov rax, 0x64C06813C530
000076049b1d1a38  call rax
000076049b1d1a3a  movaps xmm15, [rsp]
000076049b1d1a3f  add rsp, 0x30
000076049b1d1a43  vmovaps xmm0, [rsp]
000076049b1d1a48  vmovaps xmm1, [rsp+0x10]
000076049b1d1a4e  vmovaps xmm2, [rsp+0x20]
000076049b1d1a54  vmovaps xmm3, [rsp+0x30]
000076049b1d1a5a  vmovaps xmm4, [rsp+0x40]
000076049b1d1a60  vmovaps xmm5, [rsp+0x50]
000076049b1d1a66  vmovaps xmm6, [rsp+0x60]
000076049b1d1a6c  vmovaps xmm7, [rsp+0x70]
000076049b1d1a72  vmovaps xmm8, [rsp+0x80]
000076049b1d1a7b  vmovaps xmm9, [rsp+0x90]
000076049b1d1a84  vmovaps xmm10, [rsp+0xA0]
000076049b1d1a8d  vmovaps xmm11, [rsp+0xB0]
000076049b1d1a96  vmovaps xmm12, [rsp+0xC0]
000076049b1d1a9f  vmovaps xmm13, [rsp+0xD0]
000076049b1d1aa8  vmovaps xmm14, [rsp+0xE0]
000076049b1d1ab1  add rsp, 0xF0
000076049b1d1ab8  pop r11
000076049b1d1aba  pop r10
000076049b1d1abc  pop r9
000076049b1d1abe  pop r8
000076049b1d1ac0  pop rsi
000076049b1d1ac1  pop rdi
000076049b1d1ac2  pop rdx
000076049b1d1ac3  pop rcx
000076049b1d1ac4  pop rax
000076049b1d1ac5  add rsp, 0x08
000076049b1d1ac9  jmp 0x000076049B1CF9E7
000076049b1d1ace  call 0x000076049AFFF430
000076049b1d1ad3  jmp 0x000076049B1CF9F4
000076049b1d1ad8  sub rsp, 0x08
000076049b1d1adc  push rax
000076049b1d1add  push rcx
000076049b1d1ade  push rdx
000076049b1d1adf  push rdi
000076049b1d1ae0  push rsi
000076049b1d1ae1  push r8
000076049b1d1ae3  push r9
000076049b1d1ae5  push r10
000076049b1d1ae7  push r11
000076049b1d1ae9  sub rsp, 0xF0
000076049b1d1af0  vmovaps [rsp], xmm0
000076049b1d1af5  vmovaps [rsp+0x10], xmm1
000076049b1d1afb  vmovaps [rsp+0x20], xmm2
000076049b1d1b01  vmovaps [rsp+0x30], xmm3
000076049b1d1b07  vmovaps [rsp+0x40], xmm4
000076049b1d1b0d  vmovaps [rsp+0x50], xmm5
000076049b1d1b13  vmovaps [rsp+0x60], xmm6
000076049b1d1b19  vmovaps [rsp+0x70], xmm7
000076049b1d1b1f  vmovaps [rsp+0x80], xmm8
000076049b1d1b28  vmovaps [rsp+0x90], xmm9
000076049b1d1b31  vmovaps [rsp+0xA0], xmm10
000076049b1d1b3a  vmovaps [rsp+0xB0], xmm11
000076049b1d1b43  vmovaps [rsp+0xC0], xmm12
000076049b1d1b4c  vmovaps [rsp+0xD0], xmm13
000076049b1d1b55  vmovaps [rsp+0xE0], xmm15
000076049b1d1b5e  sub rsp, 0x30
000076049b1d1b62  movaps [rsp], xmm14
000076049b1d1b67  movaps [rsp+0x10], xmm13
000076049b1d1b6d  movaps [rsp+0x20], xmm1
000076049b1d1b72  lea rdi, [rsp]
000076049b1d1b76  mov esi, 0x00
000076049b1d1b7b  mov rax, 0x64C06813C530
000076049b1d1b85  call rax
000076049b1d1b87  movaps xmm14, [rsp]
000076049b1d1b8c  add rsp, 0x30
000076049b1d1b90  vmovaps xmm0, [rsp]
000076049b1d1b95  vmovaps xmm1, [rsp+0x10]
000076049b1d1b9b  vmovaps xmm2, [rsp+0x20]
000076049b1d1ba1  vmovaps xmm3, [rsp+0x30]
000076049b1d1ba7  vmovaps xmm4, [rsp+0x40]
000076049b1d1bad  vmovaps xmm5, [rsp+0x50]
000076049b1d1bb3  vmovaps xmm6, [rsp+0x60]
000076049b1d1bb9  vmovaps xmm7, [rsp+0x70]
000076049b1d1bbf  vmovaps xmm8, [rsp+0x80]
000076049b1d1bc8  vmovaps xmm9, [rsp+0x90]
000076049b1d1bd1  vmovaps xmm10, [rsp+0xA0]
000076049b1d1bda  vmovaps xmm11, [rsp+0xB0]
000076049b1d1be3  vmovaps xmm12, [rsp+0xC0]
000076049b1d1bec  vmovaps xmm13, [rsp+0xD0]
000076049b1d1bf5  vmovaps xmm15, [rsp+0xE0]
000076049b1d1bfe  add rsp, 0xF0
000076049b1d1c05  pop r11
000076049b1d1c07  pop r10
000076049b1d1c09  pop r9
000076049b1d1c0b  pop r8
000076049b1d1c0d  pop rsi
000076049b1d1c0e  pop rdi
000076049b1d1c0f  pop rdx
000076049b1d1c10  pop rcx
000076049b1d1c11  pop rax
000076049b1d1c12  add rsp, 0x08
000076049b1d1c16  jmp 0x000076049B1CFAAF
000076049b1d1c1b  sub rsp, 0x08
000076049b1d1c1f  push rax
000076049b1d1c20  push rcx
000076049b1d1c21  push rdx
000076049b1d1c22  push rdi
000076049b1d1c23  push rsi
000076049b1d1c24  push r8
000076049b1d1c26  push r9
000076049b1d1c28  push r10
000076049b1d1c2a  push r11
000076049b1d1c2c  sub rsp, 0xF0
000076049b1d1c33  vmovaps [rsp], xmm0
000076049b1d1c38  vmovaps [rsp+0x10], xmm1
000076049b1d1c3e  vmovaps [rsp+0x20], xmm2
000076049b1d1c44  vmovaps [rsp+0x30], xmm3
000076049b1d1c4a  vmovaps [rsp+0x40], xmm4
000076049b1d1c50  vmovaps [rsp+0x50], xmm5
000076049b1d1c56  vmovaps [rsp+0x60], xmm6
000076049b1d1c5c  vmovaps [rsp+0x70], xmm7
000076049b1d1c62  vmovaps [rsp+0x80], xmm8
000076049b1d1c6b  vmovaps [rsp+0x90], xmm9
000076049b1d1c74  vmovaps [rsp+0xA0], xmm10
000076049b1d1c7d  vmovaps [rsp+0xB0], xmm11
000076049b1d1c86  vmovaps [rsp+0xC0], xmm12
000076049b1d1c8f  vmovaps [rsp+0xD0], xmm13
000076049b1d1c98  vmovaps [rsp+0xE0], xmm14
000076049b1d1ca1  sub rsp, 0x30
000076049b1d1ca5  movaps [rsp], xmm15
000076049b1d1caa  movaps [rsp+0x10], xmm13
000076049b1d1cb0  movaps [rsp+0x20], xmm1
000076049b1d1cb5  lea rdi, [rsp]
000076049b1d1cb9  mov esi, 0x00
000076049b1d1cbe  mov rax, 0x64C06813C530
000076049b1d1cc8  call rax
000076049b1d1cca  movaps xmm15, [rsp]
000076049b1d1ccf  add rsp, 0x30
000076049b1d1cd3  vmovaps xmm0, [rsp]
000076049b1d1cd8  vmovaps xmm1, [rsp+0x10]
000076049b1d1cde  vmovaps xmm2, [rsp+0x20]
000076049b1d1ce4  vmovaps xmm3, [rsp+0x30]
000076049b1d1cea  vmovaps xmm4, [rsp+0x40]
000076049b1d1cf0  vmovaps xmm5, [rsp+0x50]
000076049b1d1cf6  vmovaps xmm6, [rsp+0x60]
000076049b1d1cfc  vmovaps xmm7, [rsp+0x70]
000076049b1d1d02  vmovaps xmm8, [rsp+0x80]
000076049b1d1d0b  vmovaps xmm9, [rsp+0x90]
000076049b1d1d14  vmovaps xmm10, [rsp+0xA0]
000076049b1d1d1d  vmovaps xmm11, [rsp+0xB0]
000076049b1d1d26  vmovaps xmm12, [rsp+0xC0]
000076049b1d1d2f  vmovaps xmm13, [rsp+0xD0]
000076049b1d1d38  vmovaps xmm14, [rsp+0xE0]
000076049b1d1d41  add rsp, 0xF0
000076049b1d1d48  pop r11
000076049b1d1d4a  pop r10
000076049b1d1d4c  pop r9
000076049b1d1d4e  pop r8
000076049b1d1d50  pop rsi
000076049b1d1d51  pop rdi
000076049b1d1d52  pop rdx
000076049b1d1d53  pop rcx
000076049b1d1d54  pop rax
000076049b1d1d55  add rsp, 0x08
000076049b1d1d59  jmp 0x000076049B1CFAEB
000076049b1d1d5e  call 0x000076049AFFF430
000076049b1d1d63  jmp 0x000076049B1CFAF8
000076049b1d1d68  sub rsp, 0x08
000076049b1d1d6c  push rax
000076049b1d1d6d  push rcx
000076049b1d1d6e  push rdx
000076049b1d1d6f  push rdi
000076049b1d1d70  push rsi
000076049b1d1d71  push r8
000076049b1d1d73  push r9
000076049b1d1d75  push r10
000076049b1d1d77  push r11
000076049b1d1d79  sub rsp, 0xF0
000076049b1d1d80  vmovaps [rsp], xmm0
000076049b1d1d85  vmovaps [rsp+0x10], xmm1
000076049b1d1d8b  vmovaps [rsp+0x20], xmm2
000076049b1d1d91  vmovaps [rsp+0x30], xmm3
000076049b1d1d97  vmovaps [rsp+0x40], xmm4
000076049b1d1d9d  vmovaps [rsp+0x50], xmm5
000076049b1d1da3  vmovaps [rsp+0x60], xmm6
000076049b1d1da9  vmovaps [rsp+0x70], xmm7
000076049b1d1daf  vmovaps [rsp+0x80], xmm8
000076049b1d1db8  vmovaps [rsp+0x90], xmm9
000076049b1d1dc1  vmovaps [rsp+0xA0], xmm10
000076049b1d1dca  vmovaps [rsp+0xB0], xmm11
000076049b1d1dd3  vmovaps [rsp+0xC0], xmm12
000076049b1d1ddc  vmovaps [rsp+0xD0], xmm13
000076049b1d1de5  vmovaps [rsp+0xE0], xmm15
000076049b1d1dee  sub rsp, 0x30
000076049b1d1df2  movaps [rsp], xmm14
000076049b1d1df7  movaps [rsp+0x10], xmm13
000076049b1d1dfd  movaps [rsp+0x20], xmm2
000076049b1d1e02  lea rdi, [rsp]
000076049b1d1e06  mov esi, 0x00
000076049b1d1e0b  mov rax, 0x64C06813C530
000076049b1d1e15  call rax
000076049b1d1e17  movaps xmm14, [rsp]
000076049b1d1e1c  add rsp, 0x30
000076049b1d1e20  vmovaps xmm0, [rsp]
000076049b1d1e25  vmovaps xmm1, [rsp+0x10]
000076049b1d1e2b  vmovaps xmm2, [rsp+0x20]
000076049b1d1e31  vmovaps xmm3, [rsp+0x30]
000076049b1d1e37  vmovaps xmm4, [rsp+0x40]
000076049b1d1e3d  vmovaps xmm5, [rsp+0x50]
000076049b1d1e43  vmovaps xmm6, [rsp+0x60]
000076049b1d1e49  vmovaps xmm7, [rsp+0x70]
000076049b1d1e4f  vmovaps xmm8, [rsp+0x80]
000076049b1d1e58  vmovaps xmm9, [rsp+0x90]
000076049b1d1e61  vmovaps xmm10, [rsp+0xA0]
000076049b1d1e6a  vmovaps xmm11, [rsp+0xB0]
000076049b1d1e73  vmovaps xmm12, [rsp+0xC0]
000076049b1d1e7c  vmovaps xmm13, [rsp+0xD0]
000076049b1d1e85  vmovaps xmm15, [rsp+0xE0]
000076049b1d1e8e  add rsp, 0xF0
000076049b1d1e95  pop r11
000076049b1d1e97  pop r10
000076049b1d1e99  pop r9
000076049b1d1e9b  pop r8
000076049b1d1e9d  pop rsi
000076049b1d1e9e  pop rdi
000076049b1d1e9f  pop rdx
000076049b1d1ea0  pop rcx
000076049b1d1ea1  pop rax
000076049b1d1ea2  add rsp, 0x08
000076049b1d1ea6  jmp 0x000076049B1CFB24
000076049b1d1eab  sub rsp, 0x08
000076049b1d1eaf  push rax
000076049b1d1eb0  push rcx
000076049b1d1eb1  push rdx
000076049b1d1eb2  push rdi
000076049b1d1eb3  push rsi
000076049b1d1eb4  push r8
000076049b1d1eb6  push r9
000076049b1d1eb8  push r10
000076049b1d1eba  push r11
000076049b1d1ebc  sub rsp, 0xF0
000076049b1d1ec3  vmovaps [rsp], xmm0
000076049b1d1ec8  vmovaps [rsp+0x10], xmm2
000076049b1d1ece  vmovaps [rsp+0x20], xmm3
000076049b1d1ed4  vmovaps [rsp+0x30], xmm4
000076049b1d1eda  vmovaps [rsp+0x40], xmm5
000076049b1d1ee0  vmovaps [rsp+0x50], xmm6
000076049b1d1ee6  vmovaps [rsp+0x60], xmm7
000076049b1d1eec  vmovaps [rsp+0x70], xmm8
000076049b1d1ef2  vmovaps [rsp+0x80], xmm9
000076049b1d1efb  vmovaps [rsp+0x90], xmm10
000076049b1d1f04  vmovaps [rsp+0xA0], xmm11
000076049b1d1f0d  vmovaps [rsp+0xB0], xmm12
000076049b1d1f16  vmovaps [rsp+0xC0], xmm13
000076049b1d1f1f  vmovaps [rsp+0xD0], xmm14
000076049b1d1f28  vmovaps [rsp+0xE0], xmm15
000076049b1d1f31  sub rsp, 0x30
000076049b1d1f35  movaps [rsp], xmm1
000076049b1d1f39  movaps [rsp+0x10], xmm13
000076049b1d1f3f  movaps [rsp+0x20], xmm2
000076049b1d1f44  lea rdi, [rsp]
000076049b1d1f48  mov esi, 0x00
000076049b1d1f4d  mov rax, 0x64C06813C530
000076049b1d1f57  call rax
000076049b1d1f59  movaps xmm1, [rsp]
000076049b1d1f5d  add rsp, 0x30
000076049b1d1f61  vmovaps xmm0, [rsp]
000076049b1d1f66  vmovaps xmm2, [rsp+0x10]
000076049b1d1f6c  vmovaps xmm3, [rsp+0x20]
000076049b1d1f72  vmovaps xmm4, [rsp+0x30]
000076049b1d1f78  vmovaps xmm5, [rsp+0x40]
000076049b1d1f7e  vmovaps xmm6, [rsp+0x50]
000076049b1d1f84  vmovaps xmm7, [rsp+0x60]
000076049b1d1f8a  vmovaps xmm8, [rsp+0x70]
000076049b1d1f90  vmovaps xmm9, [rsp+0x80]
000076049b1d1f99  vmovaps xmm10, [rsp+0x90]
000076049b1d1fa2  vmovaps xmm11, [rsp+0xA0]
000076049b1d1fab  vmovaps xmm12, [rsp+0xB0]
000076049b1d1fb4  vmovaps xmm13, [rsp+0xC0]
000076049b1d1fbd  vmovaps xmm14, [rsp+0xD0]
000076049b1d1fc6  vmovaps xmm15, [rsp+0xE0]
000076049b1d1fcf  add rsp, 0xF0
000076049b1d1fd6  pop r11
000076049b1d1fd8  pop r10
000076049b1d1fda  pop r9
000076049b1d1fdc  pop r8
000076049b1d1fde  pop rsi
000076049b1d1fdf  pop rdi
000076049b1d1fe0  pop rdx
000076049b1d1fe1  pop rcx
000076049b1d1fe2  pop rax
000076049b1d1fe3  add rsp, 0x08
000076049b1d1fe7  jmp 0x000076049B1CFB52
000076049b1d1fec  sub rsp, 0x08
000076049b1d1ff0  push rax
000076049b1d1ff1  push rcx
000076049b1d1ff2  push rdx
000076049b1d1ff3  push rdi
000076049b1d1ff4  push rsi
000076049b1d1ff5  push r8
000076049b1d1ff7  push r9
000076049b1d1ff9  push r10
000076049b1d1ffb  push r11
000076049b1d1ffd  sub rsp, 0xF0
000076049b1d2004  vmovaps [rsp], xmm0
000076049b1d2009  vmovaps [rsp+0x10], xmm1
000076049b1d200f  vmovaps [rsp+0x20], xmm3
000076049b1d2015  vmovaps [rsp+0x30], xmm4
000076049b1d201b  vmovaps [rsp+0x40], xmm5
000076049b1d2021  vmovaps [rsp+0x50], xmm6
000076049b1d2027  vmovaps [rsp+0x60], xmm7
000076049b1d202d  vmovaps [rsp+0x70], xmm8
000076049b1d2033  vmovaps [rsp+0x80], xmm9
000076049b1d203c  vmovaps [rsp+0x90], xmm10
000076049b1d2045  vmovaps [rsp+0xA0], xmm11
000076049b1d204e  vmovaps [rsp+0xB0], xmm12
000076049b1d2057  vmovaps [rsp+0xC0], xmm13
000076049b1d2060  vmovaps [rsp+0xD0], xmm14
000076049b1d2069  vmovaps [rsp+0xE0], xmm15
000076049b1d2072  sub rsp, 0x30
000076049b1d2076  movaps [rsp], xmm2
000076049b1d207a  movaps [rsp+0x10], xmm1
000076049b1d207f  movaps [rsp+0x20], xmm13
000076049b1d2085  lea rdi, [rsp]
000076049b1d2089  mov esi, 0x00
000076049b1d208e  mov rax, 0x64C06813C530
000076049b1d2098  call rax
000076049b1d209a  movaps xmm2, [rsp]
000076049b1d209e  add rsp, 0x30
000076049b1d20a2  vmovaps xmm0, [rsp]
000076049b1d20a7  vmovaps xmm1, [rsp+0x10]
000076049b1d20ad  vmovaps xmm3, [rsp+0x20]
000076049b1d20b3  vmovaps xmm4, [rsp+0x30]
000076049b1d20b9  vmovaps xmm5, [rsp+0x40]
000076049b1d20bf  vmovaps xmm6, [rsp+0x50]
000076049b1d20c5  vmovaps xmm7, [rsp+0x60]
000076049b1d20cb  vmovaps xmm8, [rsp+0x70]
000076049b1d20d1  vmovaps xmm9, [rsp+0x80]
000076049b1d20da  vmovaps xmm10, [rsp+0x90]
000076049b1d20e3  vmovaps xmm11, [rsp+0xA0]
000076049b1d20ec  vmovaps xmm12, [rsp+0xB0]
000076049b1d20f5  vmovaps xmm13, [rsp+0xC0]
000076049b1d20fe  vmovaps xmm14, [rsp+0xD0]
000076049b1d2107  vmovaps xmm15, [rsp+0xE0]
000076049b1d2110  add rsp, 0xF0
000076049b1d2117  pop r11
000076049b1d2119  pop r10
000076049b1d211b  pop r9
000076049b1d211d  pop r8
000076049b1d211f  pop rsi
000076049b1d2120  pop rdi
000076049b1d2121  pop rdx
000076049b1d2122  pop rcx
000076049b1d2123  pop rax
000076049b1d2124  add rsp, 0x08
000076049b1d2128  jmp 0x000076049B1CFBAB
000076049b1d212d  call 0x000076049AFFF430
000076049b1d2132  jmp 0x000076049B1CFBB8
000076049b1d2137  sub rsp, 0x08
000076049b1d213b  push rax
000076049b1d213c  push rcx
000076049b1d213d  push rdx
000076049b1d213e  push rdi
000076049b1d213f  push rsi
000076049b1d2140  push r8
000076049b1d2142  push r9
000076049b1d2144  push r10
000076049b1d2146  push r11
000076049b1d2148  sub rsp, 0xF0
000076049b1d214f  vmovaps [rsp], xmm0
000076049b1d2154  vmovaps [rsp+0x10], xmm1
000076049b1d215a  vmovaps [rsp+0x20], xmm2
000076049b1d2160  vmovaps [rsp+0x30], xmm3
000076049b1d2166  vmovaps [rsp+0x40], xmm4
000076049b1d216c  vmovaps [rsp+0x50], xmm5
000076049b1d2172  vmovaps [rsp+0x60], xmm6
000076049b1d2178  vmovaps [rsp+0x70], xmm7
000076049b1d217e  vmovaps [rsp+0x80], xmm8
000076049b1d2187  vmovaps [rsp+0x90], xmm9
000076049b1d2190  vmovaps [rsp+0xA0], xmm10
000076049b1d2199  vmovaps [rsp+0xB0], xmm11
000076049b1d21a2  vmovaps [rsp+0xC0], xmm12
000076049b1d21ab  vmovaps [rsp+0xD0], xmm13
000076049b1d21b4  vmovaps [rsp+0xE0], xmm14
000076049b1d21bd  sub rsp, 0x30
000076049b1d21c1  movaps [rsp], xmm15
000076049b1d21c6  movaps [rsp+0x10], xmm13
000076049b1d21cc  movaps [rsp+0x20], xmm1
000076049b1d21d1  lea rdi, [rsp]
000076049b1d21d5  mov esi, 0x00
000076049b1d21da  mov rax, 0x64C06813C530
000076049b1d21e4  call rax
000076049b1d21e6  movaps xmm15, [rsp]
000076049b1d21eb  add rsp, 0x30
000076049b1d21ef  vmovaps xmm0, [rsp]
000076049b1d21f4  vmovaps xmm1, [rsp+0x10]
000076049b1d21fa  vmovaps xmm2, [rsp+0x20]
000076049b1d2200  vmovaps xmm3, [rsp+0x30]
000076049b1d2206  vmovaps xmm4, [rsp+0x40]
000076049b1d220c  vmovaps xmm5, [rsp+0x50]
000076049b1d2212  vmovaps xmm6, [rsp+0x60]
000076049b1d2218  vmovaps xmm7, [rsp+0x70]
000076049b1d221e  vmovaps xmm8, [rsp+0x80]
000076049b1d2227  vmovaps xmm9, [rsp+0x90]
000076049b1d2230  vmovaps xmm10, [rsp+0xA0]
000076049b1d2239  vmovaps xmm11, [rsp+0xB0]
000076049b1d2242  vmovaps xmm12, [rsp+0xC0]
000076049b1d224b  vmovaps xmm13, [rsp+0xD0]
000076049b1d2254  vmovaps xmm14, [rsp+0xE0]
000076049b1d225d  add rsp, 0xF0
000076049b1d2264  pop r11
000076049b1d2266  pop r10
000076049b1d2268  pop r9
000076049b1d226a  pop r8
000076049b1d226c  pop rsi
000076049b1d226d  pop rdi
000076049b1d226e  pop rdx
000076049b1d226f  pop rcx
000076049b1d2270  pop rax
000076049b1d2271  add rsp, 0x08
000076049b1d2275  jmp 0x000076049B1CFBF7
000076049b1d227a  sub rsp, 0x08
000076049b1d227e  push rax
000076049b1d227f  push rcx
000076049b1d2280  push rdx
000076049b1d2281  push rdi
000076049b1d2282  push rsi
000076049b1d2283  push r8
000076049b1d2285  push r9
000076049b1d2287  push r10
000076049b1d2289  push r11
000076049b1d228b  sub rsp, 0xF0
000076049b1d2292  vmovaps [rsp], xmm0
000076049b1d2297  vmovaps [rsp+0x10], xmm1
000076049b1d229d  vmovaps [rsp+0x20], xmm2
000076049b1d22a3  vmovaps [rsp+0x30], xmm3
000076049b1d22a9  vmovaps [rsp+0x40], xmm4
000076049b1d22af  vmovaps [rsp+0x50], xmm5
000076049b1d22b5  vmovaps [rsp+0x60], xmm6
000076049b1d22bb  vmovaps [rsp+0x70], xmm7
000076049b1d22c1  vmovaps [rsp+0x80], xmm8
000076049b1d22ca  vmovaps [rsp+0x90], xmm9
000076049b1d22d3  vmovaps [rsp+0xA0], xmm10
000076049b1d22dc  vmovaps [rsp+0xB0], xmm11
000076049b1d22e5  vmovaps [rsp+0xC0], xmm12
000076049b1d22ee  vmovaps [rsp+0xD0], xmm13
000076049b1d22f7  vmovaps [rsp+0xE0], xmm15
000076049b1d2300  sub rsp, 0x30
000076049b1d2304  movaps [rsp], xmm14
000076049b1d2309  movaps [rsp+0x10], xmm11
000076049b1d230f  movaps [rsp+0x20], xmm1
000076049b1d2314  lea rdi, [rsp]
000076049b1d2318  mov esi, 0x00
000076049b1d231d  mov rax, 0x64C06813C530
000076049b1d2327  call rax
000076049b1d2329  movaps xmm14, [rsp]
000076049b1d232e  add rsp, 0x30
000076049b1d2332  vmovaps xmm0, [rsp]
000076049b1d2337  vmovaps xmm1, [rsp+0x10]
000076049b1d233d  vmovaps xmm2, [rsp+0x20]
000076049b1d2343  vmovaps xmm3, [rsp+0x30]
000076049b1d2349  vmovaps xmm4, [rsp+0x40]
000076049b1d234f  vmovaps xmm5, [rsp+0x50]
000076049b1d2355  vmovaps xmm6, [rsp+0x60]
000076049b1d235b  vmovaps xmm7, [rsp+0x70]
000076049b1d2361  vmovaps xmm8, [rsp+0x80]
000076049b1d236a  vmovaps xmm9, [rsp+0x90]
000076049b1d2373  vmovaps xmm10, [rsp+0xA0]
000076049b1d237c  vmovaps xmm11, [rsp+0xB0]
000076049b1d2385  vmovaps xmm12, [rsp+0xC0]
000076049b1d238e  vmovaps xmm13, [rsp+0xD0]
000076049b1d2397  vmovaps xmm15, [rsp+0xE0]
000076049b1d23a0  add rsp, 0xF0
000076049b1d23a7  pop r11
000076049b1d23a9  pop r10
000076049b1d23ab  pop r9
000076049b1d23ad  pop r8
000076049b1d23af  pop rsi
000076049b1d23b0  pop rdi
000076049b1d23b1  pop rdx
000076049b1d23b2  pop rcx
000076049b1d23b3  pop rax
000076049b1d23b4  add rsp, 0x08
000076049b1d23b8  jmp 0x000076049B1CFC21
000076049b1d23bd  sub rsp, 0x08
000076049b1d23c1  push rax
000076049b1d23c2  push rcx
000076049b1d23c3  push rdx
000076049b1d23c4  push rdi
000076049b1d23c5  push rsi
000076049b1d23c6  push r8
000076049b1d23c8  push r9
000076049b1d23ca  push r10
000076049b1d23cc  push r11
000076049b1d23ce  sub rsp, 0xF0
000076049b1d23d5  vmovaps [rsp], xmm0
000076049b1d23da  vmovaps [rsp+0x10], xmm1
000076049b1d23e0  vmovaps [rsp+0x20], xmm2
000076049b1d23e6  vmovaps [rsp+0x30], xmm3
000076049b1d23ec  vmovaps [rsp+0x40], xmm4
000076049b1d23f2  vmovaps [rsp+0x50], xmm5
000076049b1d23f8  vmovaps [rsp+0x60], xmm6
000076049b1d23fe  vmovaps [rsp+0x70], xmm7
000076049b1d2404  vmovaps [rsp+0x80], xmm8
000076049b1d240d  vmovaps [rsp+0x90], xmm9
000076049b1d2416  vmovaps [rsp+0xA0], xmm10
000076049b1d241f  vmovaps [rsp+0xB0], xmm11
000076049b1d2428  vmovaps [rsp+0xC0], xmm12
000076049b1d2431  vmovaps [rsp+0xD0], xmm14
000076049b1d243a  vmovaps [rsp+0xE0], xmm15
000076049b1d2443  sub rsp, 0x30
000076049b1d2447  movaps [rsp], xmm13
000076049b1d244c  movaps [rsp+0x10], xmm11
000076049b1d2452  movaps [rsp+0x20], xmm1
000076049b1d2457  lea rdi, [rsp]
000076049b1d245b  mov esi, 0x00
000076049b1d2460  mov rax, 0x64C06813C530
000076049b1d246a  call rax
000076049b1d246c  movaps xmm13, [rsp]
000076049b1d2471  add rsp, 0x30
000076049b1d2475  vmovaps xmm0, [rsp]
000076049b1d247a  vmovaps xmm1, [rsp+0x10]
000076049b1d2480  vmovaps xmm2, [rsp+0x20]
000076049b1d2486  vmovaps xmm3, [rsp+0x30]
000076049b1d248c  vmovaps xmm4, [rsp+0x40]
000076049b1d2492  vmovaps xmm5, [rsp+0x50]
000076049b1d2498  vmovaps xmm6, [rsp+0x60]
000076049b1d249e  vmovaps xmm7, [rsp+0x70]
000076049b1d24a4  vmovaps xmm8, [rsp+0x80]
000076049b1d24ad  vmovaps xmm9, [rsp+0x90]
000076049b1d24b6  vmovaps xmm10, [rsp+0xA0]
000076049b1d24bf  vmovaps xmm11, [rsp+0xB0]
000076049b1d24c8  vmovaps xmm12, [rsp+0xC0]
000076049b1d24d1  vmovaps xmm14, [rsp+0xD0]
000076049b1d24da  vmovaps xmm15, [rsp+0xE0]
000076049b1d24e3  add rsp, 0xF0
000076049b1d24ea  pop r11
000076049b1d24ec  pop r10
000076049b1d24ee  pop r9
000076049b1d24f0  pop r8
000076049b1d24f2  pop rsi
000076049b1d24f3  pop rdi
000076049b1d24f4  pop rdx
000076049b1d24f5  pop rcx
000076049b1d24f6  pop rax
000076049b1d24f7  add rsp, 0x08
000076049b1d24fb  jmp 0x000076049B1CFC76
000076049b1d2500  call 0x000076049AFFF430
000076049b1d2505  jmp 0x000076049B1CFC83
000076049b1d250a  sub rsp, 0x08
000076049b1d250e  push rax
000076049b1d250f  push rcx
000076049b1d2510  push rdx
000076049b1d2511  push rdi
000076049b1d2512  push rsi
000076049b1d2513  push r8
000076049b1d2515  push r9
000076049b1d2517  push r10
000076049b1d2519  push r11
000076049b1d251b  sub rsp, 0xF0
000076049b1d2522  vmovaps [rsp], xmm0
000076049b1d2527  vmovaps [rsp+0x10], xmm1
000076049b1d252d  vmovaps [rsp+0x20], xmm2
000076049b1d2533  vmovaps [rsp+0x30], xmm3
000076049b1d2539  vmovaps [rsp+0x40], xmm4
000076049b1d253f  vmovaps [rsp+0x50], xmm5
000076049b1d2545  vmovaps [rsp+0x60], xmm6
000076049b1d254b  vmovaps [rsp+0x70], xmm7
000076049b1d2551  vmovaps [rsp+0x80], xmm8
000076049b1d255a  vmovaps [rsp+0x90], xmm9
000076049b1d2563  vmovaps [rsp+0xA0], xmm10
000076049b1d256c  vmovaps [rsp+0xB0], xmm11
000076049b1d2575  vmovaps [rsp+0xC0], xmm12
000076049b1d257e  vmovaps [rsp+0xD0], xmm13
000076049b1d2587  vmovaps [rsp+0xE0], xmm14
000076049b1d2590  sub rsp, 0x30
000076049b1d2594  movaps [rsp], xmm15
000076049b1d2599  movaps [rsp+0x10], xmm11
000076049b1d259f  movaps [rsp+0x20], xmm1
000076049b1d25a4  lea rdi, [rsp]
000076049b1d25a8  mov esi, 0x00
000076049b1d25ad  mov rax, 0x64C06813C530
000076049b1d25b7  call rax
000076049b1d25b9  movaps xmm15, [rsp]
000076049b1d25be  add rsp, 0x30
000076049b1d25c2  vmovaps xmm0, [rsp]
000076049b1d25c7  vmovaps xmm1, [rsp+0x10]
000076049b1d25cd  vmovaps xmm2, [rsp+0x20]
000076049b1d25d3  vmovaps xmm3, [rsp+0x30]
000076049b1d25d9  vmovaps xmm4, [rsp+0x40]
000076049b1d25df  vmovaps xmm5, [rsp+0x50]
000076049b1d25e5  vmovaps xmm6, [rsp+0x60]
000076049b1d25eb  vmovaps xmm7, [rsp+0x70]
000076049b1d25f1  vmovaps xmm8, [rsp+0x80]
000076049b1d25fa  vmovaps xmm9, [rsp+0x90]
000076049b1d2603  vmovaps xmm10, [rsp+0xA0]
000076049b1d260c  vmovaps xmm11, [rsp+0xB0]
000076049b1d2615  vmovaps xmm12, [rsp+0xC0]
000076049b1d261e  vmovaps xmm13, [rsp+0xD0]
000076049b1d2627  vmovaps xmm14, [rsp+0xE0]
000076049b1d2630  add rsp, 0xF0
000076049b1d2637  pop r11
000076049b1d2639  pop r10
000076049b1d263b  pop r9
000076049b1d263d  pop r8
000076049b1d263f  pop rsi
000076049b1d2640  pop rdi
000076049b1d2641  pop rdx
000076049b1d2642  pop rcx
000076049b1d2643  pop rax
000076049b1d2644  add rsp, 0x08
000076049b1d2648  jmp 0x000076049B1CFCBC
000076049b1d264d  sub rsp, 0x08
000076049b1d2651  push rax
000076049b1d2652  push rcx
000076049b1d2653  push rdx
000076049b1d2654  push rdi
000076049b1d2655  push rsi
000076049b1d2656  push r8
000076049b1d2658  push r9
000076049b1d265a  push r10
000076049b1d265c  push r11
000076049b1d265e  sub rsp, 0xF0
000076049b1d2665  vmovaps [rsp], xmm0
000076049b1d266a  vmovaps [rsp+0x10], xmm1
000076049b1d2670  vmovaps [rsp+0x20], xmm2
000076049b1d2676  vmovaps [rsp+0x30], xmm3
000076049b1d267c  vmovaps [rsp+0x40], xmm4
000076049b1d2682  vmovaps [rsp+0x50], xmm5
000076049b1d2688  vmovaps [rsp+0x60], xmm6
000076049b1d268e  vmovaps [rsp+0x70], xmm7
000076049b1d2694  vmovaps [rsp+0x80], xmm8
000076049b1d269d  vmovaps [rsp+0x90], xmm9
000076049b1d26a6  vmovaps [rsp+0xA0], xmm10
000076049b1d26af  vmovaps [rsp+0xB0], xmm12
000076049b1d26b8  vmovaps [rsp+0xC0], xmm13
000076049b1d26c1  vmovaps [rsp+0xD0], xmm14
000076049b1d26ca  vmovaps [rsp+0xE0], xmm15
000076049b1d26d3  sub rsp, 0x30
000076049b1d26d7  movaps [rsp], xmm11
000076049b1d26dc  movaps [rsp+0x10], xmm6
000076049b1d26e1  movaps [rsp+0x20], xmm14
000076049b1d26e7  lea rdi, [rsp]
000076049b1d26eb  mov esi, 0x00
000076049b1d26f0  mov rax, 0x64C06813C530
000076049b1d26fa  call rax
000076049b1d26fc  movaps xmm11, [rsp]
000076049b1d2701  add rsp, 0x30
000076049b1d2705  vmovaps xmm0, [rsp]
000076049b1d270a  vmovaps xmm1, [rsp+0x10]
000076049b1d2710  vmovaps xmm2, [rsp+0x20]
000076049b1d2716  vmovaps xmm3, [rsp+0x30]
000076049b1d271c  vmovaps xmm4, [rsp+0x40]
000076049b1d2722  vmovaps xmm5, [rsp+0x50]
000076049b1d2728  vmovaps xmm6, [rsp+0x60]
000076049b1d272e  vmovaps xmm7, [rsp+0x70]
000076049b1d2734  vmovaps xmm8, [rsp+0x80]
000076049b1d273d  vmovaps xmm9, [rsp+0x90]
000076049b1d2746  vmovaps xmm10, [rsp+0xA0]
000076049b1d274f  vmovaps xmm12, [rsp+0xB0]
000076049b1d2758  vmovaps xmm13, [rsp+0xC0]
000076049b1d2761  vmovaps xmm14, [rsp+0xD0]
000076049b1d276a  vmovaps xmm15, [rsp+0xE0]
000076049b1d2773  add rsp, 0xF0
000076049b1d277a  pop r11
000076049b1d277c  pop r10
000076049b1d277e  pop r9
000076049b1d2780  pop r8
000076049b1d2782  pop rsi
000076049b1d2783  pop rdi
000076049b1d2784  pop rdx
000076049b1d2785  pop rcx
000076049b1d2786  pop rax
000076049b1d2787  add rsp, 0x08
000076049b1d278b  jmp 0x000076049B1CFD34
000076049b1d2790  call 0x000076049AFFF430
000076049b1d2795  jmp 0x000076049B1CFD3E
000076049b1d279a  sub rsp, 0x08
000076049b1d279e  push rax
000076049b1d279f  push rcx
000076049b1d27a0  push rdx
000076049b1d27a1  push rdi
000076049b1d27a2  push rsi
000076049b1d27a3  push r8
000076049b1d27a5  push r9
000076049b1d27a7  push r10
000076049b1d27a9  push r11
000076049b1d27ab  sub rsp, 0xF0
000076049b1d27b2  vmovaps [rsp], xmm0
000076049b1d27b7  vmovaps [rsp+0x10], xmm1
000076049b1d27bd  vmovaps [rsp+0x20], xmm2
000076049b1d27c3  vmovaps [rsp+0x30], xmm3
000076049b1d27c9  vmovaps [rsp+0x40], xmm4
000076049b1d27cf  vmovaps [rsp+0x50], xmm5
000076049b1d27d5  vmovaps [rsp+0x60], xmm6
000076049b1d27db  vmovaps [rsp+0x70], xmm7
000076049b1d27e1  vmovaps [rsp+0x80], xmm8
000076049b1d27ea  vmovaps [rsp+0x90], xmm9
000076049b1d27f3  vmovaps [rsp+0xA0], xmm10
000076049b1d27fc  vmovaps [rsp+0xB0], xmm11
000076049b1d2805  vmovaps [rsp+0xC0], xmm12
000076049b1d280e  vmovaps [rsp+0xD0], xmm13
000076049b1d2817  vmovaps [rsp+0xE0], xmm15
000076049b1d2820  sub rsp, 0x30
000076049b1d2824  movaps [rsp], xmm14
000076049b1d2829  movaps [rsp+0x10], xmm6
000076049b1d282e  movaps [rsp+0x20], xmm2
000076049b1d2833  lea rdi, [rsp]
000076049b1d2837  mov esi, 0x00
000076049b1d283c  mov rax, 0x64C06813C530
000076049b1d2846  call rax
000076049b1d2848  movaps xmm14, [rsp]
000076049b1d284d  add rsp, 0x30
000076049b1d2851  vmovaps xmm0, [rsp]
000076049b1d2856  vmovaps xmm1, [rsp+0x10]
000076049b1d285c  vmovaps xmm2, [rsp+0x20]
000076049b1d2862  vmovaps xmm3, [rsp+0x30]
000076049b1d2868  vmovaps xmm4, [rsp+0x40]
000076049b1d286e  vmovaps xmm5, [rsp+0x50]
000076049b1d2874  vmovaps xmm6, [rsp+0x60]
000076049b1d287a  vmovaps xmm7, [rsp+0x70]
000076049b1d2880  vmovaps xmm8, [rsp+0x80]
000076049b1d2889  vmovaps xmm9, [rsp+0x90]
000076049b1d2892  vmovaps xmm10, [rsp+0xA0]
000076049b1d289b  vmovaps xmm11, [rsp+0xB0]
000076049b1d28a4  vmovaps xmm12, [rsp+0xC0]
000076049b1d28ad  vmovaps xmm13, [rsp+0xD0]
000076049b1d28b6  vmovaps xmm15, [rsp+0xE0]
000076049b1d28bf  add rsp, 0xF0
000076049b1d28c6  pop r11
000076049b1d28c8  pop r10
000076049b1d28ca  pop r9
000076049b1d28cc  pop r8
000076049b1d28ce  pop rsi
000076049b1d28cf  pop rdi
000076049b1d28d0  pop rdx
000076049b1d28d1  pop rcx
000076049b1d28d2  pop rax
000076049b1d28d3  add rsp, 0x08
000076049b1d28d7  jmp 0x000076049B1CFD72
000076049b1d28dc  sub rsp, 0x08
000076049b1d28e0  push rax
000076049b1d28e1  push rcx
000076049b1d28e2  push rdx
000076049b1d28e3  push rdi
000076049b1d28e4  push rsi
000076049b1d28e5  push r8
000076049b1d28e7  push r9
000076049b1d28e9  push r10
000076049b1d28eb  push r11
000076049b1d28ed  sub rsp, 0xF0
000076049b1d28f4  vmovaps [rsp], xmm0
000076049b1d28f9  vmovaps [rsp+0x10], xmm1
000076049b1d28ff  vmovaps [rsp+0x20], xmm2
000076049b1d2905  vmovaps [rsp+0x30], xmm3
000076049b1d290b  vmovaps [rsp+0x40], xmm4
000076049b1d2911  vmovaps [rsp+0x50], xmm5
000076049b1d2917  vmovaps [rsp+0x60], xmm7
000076049b1d291d  vmovaps [rsp+0x70], xmm8
000076049b1d2923  vmovaps [rsp+0x80], xmm9
000076049b1d292c  vmovaps [rsp+0x90], xmm10
000076049b1d2935  vmovaps [rsp+0xA0], xmm11
000076049b1d293e  vmovaps [rsp+0xB0], xmm12
000076049b1d2947  vmovaps [rsp+0xC0], xmm13
000076049b1d2950  vmovaps [rsp+0xD0], xmm14
000076049b1d2959  vmovaps [rsp+0xE0], xmm15
000076049b1d2962  sub rsp, 0x30
000076049b1d2966  movaps [rsp], xmm6
000076049b1d296a  movaps [rsp+0x10], xmm5
000076049b1d296f  movaps [rsp+0x20], xmm1
000076049b1d2974  lea rdi, [rsp]
000076049b1d2978  mov esi, 0x00
000076049b1d297d  mov rax, 0x64C06813C530
000076049b1d2987  call rax
000076049b1d2989  movaps xmm6, [rsp]
000076049b1d298d  add rsp, 0x30
000076049b1d2991  vmovaps xmm0, [rsp]
000076049b1d2996  vmovaps xmm1, [rsp+0x10]
000076049b1d299c  vmovaps xmm2, [rsp+0x20]
000076049b1d29a2  vmovaps xmm3, [rsp+0x30]
000076049b1d29a8  vmovaps xmm4, [rsp+0x40]
000076049b1d29ae  vmovaps xmm5, [rsp+0x50]
000076049b1d29b4  vmovaps xmm7, [rsp+0x60]
000076049b1d29ba  vmovaps xmm8, [rsp+0x70]
000076049b1d29c0  vmovaps xmm9, [rsp+0x80]
000076049b1d29c9  vmovaps xmm10, [rsp+0x90]
000076049b1d29d2  vmovaps xmm11, [rsp+0xA0]
000076049b1d29db  vmovaps xmm12, [rsp+0xB0]
000076049b1d29e4  vmovaps xmm13, [rsp+0xC0]
000076049b1d29ed  vmovaps xmm14, [rsp+0xD0]
000076049b1d29f6  vmovaps xmm15, [rsp+0xE0]
000076049b1d29ff  add rsp, 0xF0
000076049b1d2a06  pop r11
000076049b1d2a08  pop r10
000076049b1d2a0a  pop r9
000076049b1d2a0c  pop r8
000076049b1d2a0e  pop rsi
000076049b1d2a0f  pop rdi
000076049b1d2a10  pop rdx
000076049b1d2a11  pop rcx
000076049b1d2a12  pop rax
000076049b1d2a13  add rsp, 0x08
000076049b1d2a17  jmp 0x000076049B1CFD98
000076049b1d2a1c  sub rsp, 0x08
000076049b1d2a20  push rax
000076049b1d2a21  push rcx
000076049b1d2a22  push rdx
000076049b1d2a23  push rdi
000076049b1d2a24  push rsi
000076049b1d2a25  push r8
000076049b1d2a27  push r9
000076049b1d2a29  push r10
000076049b1d2a2b  push r11
000076049b1d2a2d  sub rsp, 0xF0
000076049b1d2a34  vmovaps [rsp], xmm0
000076049b1d2a39  vmovaps [rsp+0x10], xmm2
000076049b1d2a3f  vmovaps [rsp+0x20], xmm3
000076049b1d2a45  vmovaps [rsp+0x30], xmm4
000076049b1d2a4b  vmovaps [rsp+0x40], xmm5
000076049b1d2a51  vmovaps [rsp+0x50], xmm6
000076049b1d2a57  vmovaps [rsp+0x60], xmm7
000076049b1d2a5d  vmovaps [rsp+0x70], xmm8
000076049b1d2a63  vmovaps [rsp+0x80], xmm9
000076049b1d2a6c  vmovaps [rsp+0x90], xmm10
000076049b1d2a75  vmovaps [rsp+0xA0], xmm11
000076049b1d2a7e  vmovaps [rsp+0xB0], xmm12
000076049b1d2a87  vmovaps [rsp+0xC0], xmm13
000076049b1d2a90  vmovaps [rsp+0xD0], xmm14
000076049b1d2a99  vmovaps [rsp+0xE0], xmm15
000076049b1d2aa2  sub rsp, 0x30
000076049b1d2aa6  movaps [rsp], xmm1
000076049b1d2aaa  movaps [rsp+0x10], xmm5
000076049b1d2aaf  movaps [rsp+0x20], xmm13
000076049b1d2ab5  lea rdi, [rsp]
000076049b1d2ab9  mov esi, 0x00
000076049b1d2abe  mov rax, 0x64C06813C530
000076049b1d2ac8  call rax
000076049b1d2aca  movaps xmm1, [rsp]
000076049b1d2ace  add rsp, 0x30
000076049b1d2ad2  vmovaps xmm0, [rsp]
000076049b1d2ad7  vmovaps xmm2, [rsp+0x10]
000076049b1d2add  vmovaps xmm3, [rsp+0x20]
000076049b1d2ae3  vmovaps xmm4, [rsp+0x30]
000076049b1d2ae9  vmovaps xmm5, [rsp+0x40]
000076049b1d2aef  vmovaps xmm6, [rsp+0x50]
000076049b1d2af5  vmovaps xmm7, [rsp+0x60]
000076049b1d2afb  vmovaps xmm8, [rsp+0x70]
000076049b1d2b01  vmovaps xmm9, [rsp+0x80]
000076049b1d2b0a  vmovaps xmm10, [rsp+0x90]
000076049b1d2b13  vmovaps xmm11, [rsp+0xA0]
000076049b1d2b1c  vmovaps xmm12, [rsp+0xB0]
000076049b1d2b25  vmovaps xmm13, [rsp+0xC0]
000076049b1d2b2e  vmovaps xmm14, [rsp+0xD0]
000076049b1d2b37  vmovaps xmm15, [rsp+0xE0]
000076049b1d2b40  add rsp, 0xF0
000076049b1d2b47  pop r11
000076049b1d2b49  pop r10
000076049b1d2b4b  pop r9
000076049b1d2b4d  pop r8
000076049b1d2b4f  pop rsi
000076049b1d2b50  pop rdi
000076049b1d2b51  pop rdx
000076049b1d2b52  pop rcx
000076049b1d2b53  pop rax
000076049b1d2b54  add rsp, 0x08
000076049b1d2b58  jmp 0x000076049B1CFDB6
000076049b1d2b5d  sub rsp, 0x08
000076049b1d2b61  push rax
000076049b1d2b62  push rcx
000076049b1d2b63  push rdx
000076049b1d2b64  push rdi
000076049b1d2b65  push rsi
000076049b1d2b66  push r8
000076049b1d2b68  push r9
000076049b1d2b6a  push r10
000076049b1d2b6c  push r11
000076049b1d2b6e  sub rsp, 0xF0
000076049b1d2b75  vmovaps [rsp], xmm0
000076049b1d2b7a  vmovaps [rsp+0x10], xmm1
000076049b1d2b80  vmovaps [rsp+0x20], xmm2
000076049b1d2b86  vmovaps [rsp+0x30], xmm3
000076049b1d2b8c  vmovaps [rsp+0x40], xmm4
000076049b1d2b92  vmovaps [rsp+0x50], xmm6
000076049b1d2b98  vmovaps [rsp+0x60], xmm7
000076049b1d2b9e  vmovaps [rsp+0x70], xmm8
000076049b1d2ba4  vmovaps [rsp+0x80], xmm9
000076049b1d2bad  vmovaps [rsp+0x90], xmm10
000076049b1d2bb6  vmovaps [rsp+0xA0], xmm11
000076049b1d2bbf  vmovaps [rsp+0xB0], xmm12
000076049b1d2bc8  vmovaps [rsp+0xC0], xmm13
000076049b1d2bd1  vmovaps [rsp+0xD0], xmm14
000076049b1d2bda  vmovaps [rsp+0xE0], xmm15
000076049b1d2be3  sub rsp, 0x30
000076049b1d2be7  movaps [rsp], xmm5
000076049b1d2beb  movaps [rsp+0x10], xmm2
000076049b1d2bf0  movaps [rsp+0x20], xmm13
000076049b1d2bf6  lea rdi, [rsp]
000076049b1d2bfa  mov esi, 0x00
000076049b1d2bff  mov rax, 0x64C06813C530
000076049b1d2c09  call rax
000076049b1d2c0b  movaps xmm5, [rsp]
000076049b1d2c0f  add rsp, 0x30
000076049b1d2c13  vmovaps xmm0, [rsp]
000076049b1d2c18  vmovaps xmm1, [rsp+0x10]
000076049b1d2c1e  vmovaps xmm2, [rsp+0x20]
000076049b1d2c24  vmovaps xmm3, [rsp+0x30]
000076049b1d2c2a  vmovaps xmm4, [rsp+0x40]
000076049b1d2c30  vmovaps xmm6, [rsp+0x50]
000076049b1d2c36  vmovaps xmm7, [rsp+0x60]
000076049b1d2c3c  vmovaps xmm8, [rsp+0x70]
000076049b1d2c42  vmovaps xmm9, [rsp+0x80]
000076049b1d2c4b  vmovaps xmm10, [rsp+0x90]
000076049b1d2c54  vmovaps xmm11, [rsp+0xA0]
000076049b1d2c5d  vmovaps xmm12, [rsp+0xB0]
000076049b1d2c66  vmovaps xmm13, [rsp+0xC0]
000076049b1d2c6f  vmovaps xmm14, [rsp+0xD0]
000076049b1d2c78  vmovaps xmm15, [rsp+0xE0]
000076049b1d2c81  add rsp, 0xF0
000076049b1d2c88  pop r11
000076049b1d2c8a  pop r10
000076049b1d2c8c  pop r9
000076049b1d2c8e  pop r8
000076049b1d2c90  pop rsi
000076049b1d2c91  pop rdi
000076049b1d2c92  pop rdx
000076049b1d2c93  pop rcx
000076049b1d2c94  pop rax
000076049b1d2c95  add rsp, 0x08
000076049b1d2c99  jmp 0x000076049B1CFDEC
000076049b1d2c9e  sub rsp, 0x08
000076049b1d2ca2  push rax
000076049b1d2ca3  push rcx
000076049b1d2ca4  push rdx
000076049b1d2ca5  push rdi
000076049b1d2ca6  push rsi
000076049b1d2ca7  push r8
000076049b1d2ca9  push r9
000076049b1d2cab  push r10
000076049b1d2cad  push r11
000076049b1d2caf  sub rsp, 0xF0
000076049b1d2cb6  vmovaps [rsp], xmm0
000076049b1d2cbb  vmovaps [rsp+0x10], xmm1
000076049b1d2cc1  vmovaps [rsp+0x20], xmm2
000076049b1d2cc7  vmovaps [rsp+0x30], xmm3
000076049b1d2ccd  vmovaps [rsp+0x40], xmm4
000076049b1d2cd3  vmovaps [rsp+0x50], xmm5
000076049b1d2cd9  vmovaps [rsp+0x60], xmm6
000076049b1d2cdf  vmovaps [rsp+0x70], xmm7
000076049b1d2ce5  vmovaps [rsp+0x80], xmm8
000076049b1d2cee  vmovaps [rsp+0x90], xmm9
000076049b1d2cf7  vmovaps [rsp+0xA0], xmm10
000076049b1d2d00  vmovaps [rsp+0xB0], xmm11
000076049b1d2d09  vmovaps [rsp+0xC0], xmm12
000076049b1d2d12  vmovaps [rsp+0xD0], xmm14
000076049b1d2d1b  vmovaps [rsp+0xE0], xmm15
000076049b1d2d24  sub rsp, 0x30
000076049b1d2d28  movaps [rsp], xmm13
000076049b1d2d2d  movaps [rsp+0x10], xmm10
000076049b1d2d33  movaps [rsp+0x20], xmm1
000076049b1d2d38  lea rdi, [rsp]
000076049b1d2d3c  mov esi, 0x00
000076049b1d2d41  mov rax, 0x64C06813C530
000076049b1d2d4b  call rax
000076049b1d2d4d  movaps xmm13, [rsp]
000076049b1d2d52  add rsp, 0x30
000076049b1d2d56  vmovaps xmm0, [rsp]
000076049b1d2d5b  vmovaps xmm1, [rsp+0x10]
000076049b1d2d61  vmovaps xmm2, [rsp+0x20]
000076049b1d2d67  vmovaps xmm3, [rsp+0x30]
000076049b1d2d6d  vmovaps xmm4, [rsp+0x40]
000076049b1d2d73  vmovaps xmm5, [rsp+0x50]
000076049b1d2d79  vmovaps xmm6, [rsp+0x60]
000076049b1d2d7f  vmovaps xmm7, [rsp+0x70]
000076049b1d2d85  vmovaps xmm8, [rsp+0x80]
000076049b1d2d8e  vmovaps xmm9, [rsp+0x90]
000076049b1d2d97  vmovaps xmm10, [rsp+0xA0]
000076049b1d2da0  vmovaps xmm11, [rsp+0xB0]
000076049b1d2da9  vmovaps xmm12, [rsp+0xC0]
000076049b1d2db2  vmovaps xmm14, [rsp+0xD0]
000076049b1d2dbb  vmovaps xmm15, [rsp+0xE0]
000076049b1d2dc4  add rsp, 0xF0
000076049b1d2dcb  pop r11
000076049b1d2dcd  pop r10
000076049b1d2dcf  pop r9
000076049b1d2dd1  pop r8
000076049b1d2dd3  pop rsi
000076049b1d2dd4  pop rdi
000076049b1d2dd5  pop rdx
000076049b1d2dd6  pop rcx
000076049b1d2dd7  pop rax
000076049b1d2dd8  add rsp, 0x08
000076049b1d2ddc  jmp 0x000076049B1CFE15
000076049b1d2de1  sub rsp, 0x08
000076049b1d2de5  push rax
000076049b1d2de6  push rcx
000076049b1d2de7  push rdx
000076049b1d2de8  push rdi
000076049b1d2de9  push rsi
000076049b1d2dea  push r8
000076049b1d2dec  push r9
000076049b1d2dee  push r10
000076049b1d2df0  push r11
000076049b1d2df2  sub rsp, 0xF0
000076049b1d2df9  vmovaps [rsp], xmm0
000076049b1d2dfe  vmovaps [rsp+0x10], xmm2
000076049b1d2e04  vmovaps [rsp+0x20], xmm3
000076049b1d2e0a  vmovaps [rsp+0x30], xmm4
000076049b1d2e10  vmovaps [rsp+0x40], xmm5
000076049b1d2e16  vmovaps [rsp+0x50], xmm6
000076049b1d2e1c  vmovaps [rsp+0x60], xmm7
000076049b1d2e22  vmovaps [rsp+0x70], xmm8
000076049b1d2e28  vmovaps [rsp+0x80], xmm9
000076049b1d2e31  vmovaps [rsp+0x90], xmm10
000076049b1d2e3a  vmovaps [rsp+0xA0], xmm11
000076049b1d2e43  vmovaps [rsp+0xB0], xmm12
000076049b1d2e4c  vmovaps [rsp+0xC0], xmm13
000076049b1d2e55  vmovaps [rsp+0xD0], xmm14
000076049b1d2e5e  vmovaps [rsp+0xE0], xmm15
000076049b1d2e67  sub rsp, 0x30
000076049b1d2e6b  movaps [rsp], xmm1
000076049b1d2e6f  movaps [rsp+0x10], xmm15
000076049b1d2e75  movaps [rsp+0x20], xmm10
000076049b1d2e7b  lea rdi, [rsp]
000076049b1d2e7f  mov esi, 0x00
000076049b1d2e84  mov rax, 0x64C06813C530
000076049b1d2e8e  call rax
000076049b1d2e90  movaps xmm1, [rsp]
000076049b1d2e94  add rsp, 0x30
000076049b1d2e98  vmovaps xmm0, [rsp]
000076049b1d2e9d  vmovaps xmm2, [rsp+0x10]
000076049b1d2ea3  vmovaps xmm3, [rsp+0x20]
000076049b1d2ea9  vmovaps xmm4, [rsp+0x30]
000076049b1d2eaf  vmovaps xmm5, [rsp+0x40]
000076049b1d2eb5  vmovaps xmm6, [rsp+0x50]
000076049b1d2ebb  vmovaps xmm7, [rsp+0x60]
000076049b1d2ec1  vmovaps xmm8, [rsp+0x70]
000076049b1d2ec7  vmovaps xmm9, [rsp+0x80]
000076049b1d2ed0  vmovaps xmm10, [rsp+0x90]
000076049b1d2ed9  vmovaps xmm11, [rsp+0xA0]
000076049b1d2ee2  vmovaps xmm12, [rsp+0xB0]
000076049b1d2eeb  vmovaps xmm13, [rsp+0xC0]
000076049b1d2ef4  vmovaps xmm14, [rsp+0xD0]
000076049b1d2efd  vmovaps xmm15, [rsp+0xE0]
000076049b1d2f06  add rsp, 0xF0
000076049b1d2f0d  pop r11
000076049b1d2f0f  pop r10
000076049b1d2f11  pop r9
000076049b1d2f13  pop r8
000076049b1d2f15  pop rsi
000076049b1d2f16  pop rdi
000076049b1d2f17  pop rdx
000076049b1d2f18  pop rcx
000076049b1d2f19  pop rax
000076049b1d2f1a  add rsp, 0x08
000076049b1d2f1e  jmp 0x000076049B1CFE34
000076049b1d2f23  sub rsp, 0x08
000076049b1d2f27  push rax
000076049b1d2f28  push rcx
000076049b1d2f29  push rdx
000076049b1d2f2a  push rdi
000076049b1d2f2b  push rsi
000076049b1d2f2c  push r8
000076049b1d2f2e  push r9
000076049b1d2f30  push r10
000076049b1d2f32  push r11
000076049b1d2f34  sub rsp, 0xF0
000076049b1d2f3b  vmovaps [rsp], xmm0
000076049b1d2f40  vmovaps [rsp+0x10], xmm1
000076049b1d2f46  vmovaps [rsp+0x20], xmm2
000076049b1d2f4c  vmovaps [rsp+0x30], xmm3
000076049b1d2f52  vmovaps [rsp+0x40], xmm4
000076049b1d2f58  vmovaps [rsp+0x50], xmm5
000076049b1d2f5e  vmovaps [rsp+0x60], xmm6
000076049b1d2f64  vmovaps [rsp+0x70], xmm7
000076049b1d2f6a  vmovaps [rsp+0x80], xmm8
000076049b1d2f73  vmovaps [rsp+0x90], xmm9
000076049b1d2f7c  vmovaps [rsp+0xA0], xmm10
000076049b1d2f85  vmovaps [rsp+0xB0], xmm11
000076049b1d2f8e  vmovaps [rsp+0xC0], xmm12
000076049b1d2f97  vmovaps [rsp+0xD0], xmm13
000076049b1d2fa0  vmovaps [rsp+0xE0], xmm14
000076049b1d2fa9  sub rsp, 0x30
000076049b1d2fad  movaps [rsp], xmm15
000076049b1d2fb2  movaps [rsp+0x10], xmm10
000076049b1d2fb8  movaps [rsp+0x20], xmm11
000076049b1d2fbe  lea rdi, [rsp]
000076049b1d2fc2  mov esi, 0x00
000076049b1d2fc7  mov rax, 0x64C06813C530
000076049b1d2fd1  call rax
000076049b1d2fd3  movaps xmm15, [rsp]
000076049b1d2fd8  add rsp, 0x30
000076049b1d2fdc  vmovaps xmm0, [rsp]
000076049b1d2fe1  vmovaps xmm1, [rsp+0x10]
000076049b1d2fe7  vmovaps xmm2, [rsp+0x20]
000076049b1d2fed  vmovaps xmm3, [rsp+0x30]
000076049b1d2ff3  vmovaps xmm4, [rsp+0x40]
000076049b1d2ff9  vmovaps xmm5, [rsp+0x50]
000076049b1d2fff  vmovaps xmm6, [rsp+0x60]
000076049b1d3005  vmovaps xmm7, [rsp+0x70]
000076049b1d300b  vmovaps xmm8, [rsp+0x80]
000076049b1d3014  vmovaps xmm9, [rsp+0x90]
000076049b1d301d  vmovaps xmm10, [rsp+0xA0]
000076049b1d3026  vmovaps xmm11, [rsp+0xB0]
000076049b1d302f  vmovaps xmm12, [rsp+0xC0]
000076049b1d3038  vmovaps xmm13, [rsp+0xD0]
000076049b1d3041  vmovaps xmm14, [rsp+0xE0]
000076049b1d304a  add rsp, 0xF0
000076049b1d3051  pop r11
000076049b1d3053  pop r10
000076049b1d3055  pop r9
000076049b1d3057  pop r8
000076049b1d3059  pop rsi
000076049b1d305a  pop rdi
000076049b1d305b  pop rdx
000076049b1d305c  pop rcx
000076049b1d305d  pop rax
000076049b1d305e  add rsp, 0x08
000076049b1d3062  jmp 0x000076049B1CFE57
000076049b1d3067  sub rsp, 0x08
000076049b1d306b  push rax
000076049b1d306c  push rcx
000076049b1d306d  push rdx
000076049b1d306e  push rdi
000076049b1d306f  push rsi
000076049b1d3070  push r8
000076049b1d3072  push r9
000076049b1d3074  push r10
000076049b1d3076  push r11
000076049b1d3078  sub rsp, 0xF0
000076049b1d307f  vmovaps [rsp], xmm0
000076049b1d3084  vmovaps [rsp+0x10], xmm1
000076049b1d308a  vmovaps [rsp+0x20], xmm2
000076049b1d3090  vmovaps [rsp+0x30], xmm3
000076049b1d3096  vmovaps [rsp+0x40], xmm4
000076049b1d309c  vmovaps [rsp+0x50], xmm5
000076049b1d30a2  vmovaps [rsp+0x60], xmm6
000076049b1d30a8  vmovaps [rsp+0x70], xmm7
000076049b1d30ae  vmovaps [rsp+0x80], xmm8
000076049b1d30b7  vmovaps [rsp+0x90], xmm9
000076049b1d30c0  vmovaps [rsp+0xA0], xmm11
000076049b1d30c9  vmovaps [rsp+0xB0], xmm12
000076049b1d30d2  vmovaps [rsp+0xC0], xmm13
000076049b1d30db  vmovaps [rsp+0xD0], xmm14
000076049b1d30e4  vmovaps [rsp+0xE0], xmm15
000076049b1d30ed  sub rsp, 0x30
000076049b1d30f1  movaps [rsp], xmm10
000076049b1d30f6  movaps [rsp+0x10], xmm12
000076049b1d30fc  movaps [rsp+0x20], xmm11
000076049b1d3102  lea rdi, [rsp]
000076049b1d3106  mov esi, 0x00
000076049b1d310b  mov rax, 0x64C06813C530
000076049b1d3115  call rax
000076049b1d3117  movaps xmm10, [rsp]
000076049b1d311c  add rsp, 0x30
000076049b1d3120  vmovaps xmm0, [rsp]
000076049b1d3125  vmovaps xmm1, [rsp+0x10]
000076049b1d312b  vmovaps xmm2, [rsp+0x20]
000076049b1d3131  vmovaps xmm3, [rsp+0x30]
000076049b1d3137  vmovaps xmm4, [rsp+0x40]
000076049b1d313d  vmovaps xmm5, [rsp+0x50]
000076049b1d3143  vmovaps xmm6, [rsp+0x60]
000076049b1d3149  vmovaps xmm7, [rsp+0x70]
000076049b1d314f  vmovaps xmm8, [rsp+0x80]
000076049b1d3158  vmovaps xmm9, [rsp+0x90]
000076049b1d3161  vmovaps xmm11, [rsp+0xA0]
000076049b1d316a  vmovaps xmm12, [rsp+0xB0]
000076049b1d3173  vmovaps xmm13, [rsp+0xC0]
000076049b1d317c  vmovaps xmm14, [rsp+0xD0]
000076049b1d3185  vmovaps xmm15, [rsp+0xE0]
000076049b1d318e  add rsp, 0xF0
000076049b1d3195  pop r11
000076049b1d3197  pop r10
000076049b1d3199  pop r9
000076049b1d319b  pop r8
000076049b1d319d  pop rsi
000076049b1d319e  pop rdi
000076049b1d319f  pop rdx
000076049b1d31a0  pop rcx
000076049b1d31a1  pop rax
000076049b1d31a2  add rsp, 0x08
000076049b1d31a6  jmp 0x000076049B1CFE80
000076049b1d31ab  sub rsp, 0x08
000076049b1d31af  push rax
000076049b1d31b0  push rcx
000076049b1d31b1  push rdx
000076049b1d31b2  push rdi
000076049b1d31b3  push rsi
000076049b1d31b4  push r8
000076049b1d31b6  push r9
000076049b1d31b8  push r10
000076049b1d31ba  push r11
000076049b1d31bc  sub rsp, 0xF0
000076049b1d31c3  vmovaps [rsp], xmm0
000076049b1d31c8  vmovaps [rsp+0x10], xmm1
000076049b1d31ce  vmovaps [rsp+0x20], xmm2
000076049b1d31d4  vmovaps [rsp+0x30], xmm3
000076049b1d31da  vmovaps [rsp+0x40], xmm4
000076049b1d31e0  vmovaps [rsp+0x50], xmm5
000076049b1d31e6  vmovaps [rsp+0x60], xmm6
000076049b1d31ec  vmovaps [rsp+0x70], xmm7
000076049b1d31f2  vmovaps [rsp+0x80], xmm8
000076049b1d31fb  vmovaps [rsp+0x90], xmm9
000076049b1d3204  vmovaps [rsp+0xA0], xmm10
000076049b1d320d  vmovaps [rsp+0xB0], xmm12
000076049b1d3216  vmovaps [rsp+0xC0], xmm13
000076049b1d321f  vmovaps [rsp+0xD0], xmm14
000076049b1d3228  vmovaps [rsp+0xE0], xmm15
000076049b1d3231  sub rsp, 0x30
000076049b1d3235  movaps [rsp], xmm11
000076049b1d323a  movaps [rsp+0x10], xmm2
000076049b1d323f  movaps [rsp+0x20], xmm12
000076049b1d3245  lea rdi, [rsp]
000076049b1d3249  mov esi, 0x00
000076049b1d324e  mov rax, 0x64C06813C530
000076049b1d3258  call rax
000076049b1d325a  movaps xmm11, [rsp]
000076049b1d325f  add rsp, 0x30
000076049b1d3263  vmovaps xmm0, [rsp]
000076049b1d3268  vmovaps xmm1, [rsp+0x10]
000076049b1d326e  vmovaps xmm2, [rsp+0x20]
000076049b1d3274  vmovaps xmm3, [rsp+0x30]
000076049b1d327a  vmovaps xmm4, [rsp+0x40]
000076049b1d3280  vmovaps xmm5, [rsp+0x50]
000076049b1d3286  vmovaps xmm6, [rsp+0x60]
000076049b1d328c  vmovaps xmm7, [rsp+0x70]
000076049b1d3292  vmovaps xmm8, [rsp+0x80]
000076049b1d329b  vmovaps xmm9, [rsp+0x90]
000076049b1d32a4  vmovaps xmm10, [rsp+0xA0]
000076049b1d32ad  vmovaps xmm12, [rsp+0xB0]
000076049b1d32b6  vmovaps xmm13, [rsp+0xC0]
000076049b1d32bf  vmovaps xmm14, [rsp+0xD0]
000076049b1d32c8  vmovaps xmm15, [rsp+0xE0]
000076049b1d32d1  add rsp, 0xF0
000076049b1d32d8  pop r11
000076049b1d32da  pop r10
000076049b1d32dc  pop r9
000076049b1d32de  pop r8
000076049b1d32e0  pop rsi
000076049b1d32e1  pop rdi
000076049b1d32e2  pop rdx
000076049b1d32e3  pop rcx
000076049b1d32e4  pop rax
000076049b1d32e5  add rsp, 0x08
000076049b1d32e9  jmp 0x000076049B1CFEB8
000076049b1d32ee  sub rsp, 0x08
000076049b1d32f2  push rax
000076049b1d32f3  push rcx
000076049b1d32f4  push rdx
000076049b1d32f5  push rdi
000076049b1d32f6  push rsi
000076049b1d32f7  push r8
000076049b1d32f9  push r9
000076049b1d32fb  push r10
000076049b1d32fd  push r11
000076049b1d32ff  sub rsp, 0xF0
000076049b1d3306  vmovaps [rsp], xmm0
000076049b1d330b  vmovaps [rsp+0x10], xmm2
000076049b1d3311  vmovaps [rsp+0x20], xmm3
000076049b1d3317  vmovaps [rsp+0x30], xmm4
000076049b1d331d  vmovaps [rsp+0x40], xmm5
000076049b1d3323  vmovaps [rsp+0x50], xmm6
000076049b1d3329  vmovaps [rsp+0x60], xmm7
000076049b1d332f  vmovaps [rsp+0x70], xmm8
000076049b1d3335  vmovaps [rsp+0x80], xmm9
000076049b1d333e  vmovaps [rsp+0x90], xmm10
000076049b1d3347  vmovaps [rsp+0xA0], xmm11
000076049b1d3350  vmovaps [rsp+0xB0], xmm12
000076049b1d3359  vmovaps [rsp+0xC0], xmm13
000076049b1d3362  vmovaps [rsp+0xD0], xmm14
000076049b1d336b  vmovaps [rsp+0xE0], xmm15
000076049b1d3374  sub rsp, 0x30
000076049b1d3378  movaps [rsp], xmm1
000076049b1d337c  movaps [rsp+0x10], xmm14
000076049b1d3382  movaps [rsp+0x20], xmm6
000076049b1d3387  lea rdi, [rsp]
000076049b1d338b  mov esi, 0x00
000076049b1d3390  mov rax, 0x64C06813C530
000076049b1d339a  call rax
000076049b1d339c  movaps xmm1, [rsp]
000076049b1d33a0  add rsp, 0x30
000076049b1d33a4  vmovaps xmm0, [rsp]
000076049b1d33a9  vmovaps xmm2, [rsp+0x10]
000076049b1d33af  vmovaps xmm3, [rsp+0x20]
000076049b1d33b5  vmovaps xmm4, [rsp+0x30]
000076049b1d33bb  vmovaps xmm5, [rsp+0x40]
000076049b1d33c1  vmovaps xmm6, [rsp+0x50]
000076049b1d33c7  vmovaps xmm7, [rsp+0x60]
000076049b1d33cd  vmovaps xmm8, [rsp+0x70]
000076049b1d33d3  vmovaps xmm9, [rsp+0x80]
000076049b1d33dc  vmovaps xmm10, [rsp+0x90]
000076049b1d33e5  vmovaps xmm11, [rsp+0xA0]
000076049b1d33ee  vmovaps xmm12, [rsp+0xB0]
000076049b1d33f7  vmovaps xmm13, [rsp+0xC0]
000076049b1d3400  vmovaps xmm14, [rsp+0xD0]
000076049b1d3409  vmovaps xmm15, [rsp+0xE0]
000076049b1d3412  add rsp, 0xF0
000076049b1d3419  pop r11
000076049b1d341b  pop r10
000076049b1d341d  pop r9
000076049b1d341f  pop r8
000076049b1d3421  pop rsi
000076049b1d3422  pop rdi
000076049b1d3423  pop rdx
000076049b1d3424  pop rcx
000076049b1d3425  pop rax
000076049b1d3426  add rsp, 0x08
000076049b1d342a  jmp 0x000076049B1CFED1
000076049b1d342f  sub rsp, 0x08
000076049b1d3433  push rax
000076049b1d3434  push rcx
000076049b1d3435  push rdx
000076049b1d3436  push rdi
000076049b1d3437  push rsi
000076049b1d3438  push r8
000076049b1d343a  push r9
000076049b1d343c  push r10
000076049b1d343e  push r11
000076049b1d3440  sub rsp, 0xF0
000076049b1d3447  vmovaps [rsp], xmm0
000076049b1d344c  vmovaps [rsp+0x10], xmm1
000076049b1d3452  vmovaps [rsp+0x20], xmm2
000076049b1d3458  vmovaps [rsp+0x30], xmm3
000076049b1d345e  vmovaps [rsp+0x40], xmm4
000076049b1d3464  vmovaps [rsp+0x50], xmm5
000076049b1d346a  vmovaps [rsp+0x60], xmm6
000076049b1d3470  vmovaps [rsp+0x70], xmm7
000076049b1d3476  vmovaps [rsp+0x80], xmm8
000076049b1d347f  vmovaps [rsp+0x90], xmm9
000076049b1d3488  vmovaps [rsp+0xA0], xmm10
000076049b1d3491  vmovaps [rsp+0xB0], xmm11
000076049b1d349a  vmovaps [rsp+0xC0], xmm12
000076049b1d34a3  vmovaps [rsp+0xD0], xmm13
000076049b1d34ac  vmovaps [rsp+0xE0], xmm15
000076049b1d34b5  sub rsp, 0x30
000076049b1d34b9  movaps [rsp], xmm14
000076049b1d34be  movaps [rsp+0x10], xmm12
000076049b1d34c4  movaps [rsp+0x20], xmm5
000076049b1d34c9  lea rdi, [rsp]
000076049b1d34cd  mov esi, 0x00
000076049b1d34d2  mov rax, 0x64C06813C530
000076049b1d34dc  call rax
000076049b1d34de  movaps xmm14, [rsp]
000076049b1d34e3  add rsp, 0x30
000076049b1d34e7  vmovaps xmm0, [rsp]
000076049b1d34ec  vmovaps xmm1, [rsp+0x10]
000076049b1d34f2  vmovaps xmm2, [rsp+0x20]
000076049b1d34f8  vmovaps xmm3, [rsp+0x30]
000076049b1d34fe  vmovaps xmm4, [rsp+0x40]
000076049b1d3504  vmovaps xmm5, [rsp+0x50]
000076049b1d350a  vmovaps xmm6, [rsp+0x60]
000076049b1d3510  vmovaps xmm7, [rsp+0x70]
000076049b1d3516  vmovaps xmm8, [rsp+0x80]
000076049b1d351f  vmovaps xmm9, [rsp+0x90]
000076049b1d3528  vmovaps xmm10, [rsp+0xA0]
000076049b1d3531  vmovaps xmm11, [rsp+0xB0]
000076049b1d353a  vmovaps xmm12, [rsp+0xC0]
000076049b1d3543  vmovaps xmm13, [rsp+0xD0]
000076049b1d354c  vmovaps xmm15, [rsp+0xE0]
000076049b1d3555  add rsp, 0xF0
000076049b1d355c  pop r11
000076049b1d355e  pop r10
000076049b1d3560  pop r9
000076049b1d3562  pop r8
000076049b1d3564  pop rsi
000076049b1d3565  pop rdi
000076049b1d3566  pop rdx
000076049b1d3567  pop rcx
000076049b1d3568  pop rax
000076049b1d3569  add rsp, 0x08
000076049b1d356d  jmp 0x000076049B1CFEF1
000076049b1d3572  sub rsp, 0x08
000076049b1d3576  push rax
000076049b1d3577  push rcx
000076049b1d3578  push rdx
000076049b1d3579  push rdi
000076049b1d357a  push rsi
000076049b1d357b  push r8
000076049b1d357d  push r9
000076049b1d357f  push r10
000076049b1d3581  push r11
000076049b1d3583  sub rsp, 0xF0
000076049b1d358a  vmovaps [rsp], xmm0
000076049b1d358f  vmovaps [rsp+0x10], xmm1
000076049b1d3595  vmovaps [rsp+0x20], xmm2
000076049b1d359b  vmovaps [rsp+0x30], xmm3
000076049b1d35a1  vmovaps [rsp+0x40], xmm4
000076049b1d35a7  vmovaps [rsp+0x50], xmm5
000076049b1d35ad  vmovaps [rsp+0x60], xmm7
000076049b1d35b3  vmovaps [rsp+0x70], xmm8
000076049b1d35b9  vmovaps [rsp+0x80], xmm9
000076049b1d35c2  vmovaps [rsp+0x90], xmm10
000076049b1d35cb  vmovaps [rsp+0xA0], xmm11
000076049b1d35d4  vmovaps [rsp+0xB0], xmm12
000076049b1d35dd  vmovaps [rsp+0xC0], xmm13
000076049b1d35e6  vmovaps [rsp+0xD0], xmm14
000076049b1d35ef  vmovaps [rsp+0xE0], xmm15
000076049b1d35f8  sub rsp, 0x30
000076049b1d35fc  movaps [rsp], xmm6
000076049b1d3600  movaps [rsp+0x10], xmm9
000076049b1d3606  movaps [rsp+0x20], xmm12
000076049b1d360c  lea rdi, [rsp]
000076049b1d3610  mov esi, 0x00
000076049b1d3615  mov rax, 0x64C06813C530
000076049b1d361f  call rax
000076049b1d3621  movaps xmm6, [rsp]
000076049b1d3625  add rsp, 0x30
000076049b1d3629  vmovaps xmm0, [rsp]
000076049b1d362e  vmovaps xmm1, [rsp+0x10]
000076049b1d3634  vmovaps xmm2, [rsp+0x20]
000076049b1d363a  vmovaps xmm3, [rsp+0x30]
000076049b1d3640  vmovaps xmm4, [rsp+0x40]
000076049b1d3646  vmovaps xmm5, [rsp+0x50]
000076049b1d364c  vmovaps xmm7, [rsp+0x60]
000076049b1d3652  vmovaps xmm8, [rsp+0x70]
000076049b1d3658  vmovaps xmm9, [rsp+0x80]
000076049b1d3661  vmovaps xmm10, [rsp+0x90]
000076049b1d366a  vmovaps xmm11, [rsp+0xA0]
000076049b1d3673  vmovaps xmm12, [rsp+0xB0]
000076049b1d367c  vmovaps xmm13, [rsp+0xC0]
000076049b1d3685  vmovaps xmm14, [rsp+0xD0]
000076049b1d368e  vmovaps xmm15, [rsp+0xE0]
000076049b1d3697  add rsp, 0xF0
000076049b1d369e  pop r11
000076049b1d36a0  pop r10
000076049b1d36a2  pop r9
000076049b1d36a4  pop r8
000076049b1d36a6  pop rsi
000076049b1d36a7  pop rdi
000076049b1d36a8  pop rdx
000076049b1d36a9  pop rcx
000076049b1d36aa  pop rax
000076049b1d36ab  add rsp, 0x08
000076049b1d36af  jmp 0x000076049B1CFF19
000076049b1d36b4  sub rsp, 0x08
000076049b1d36b8  push rax
000076049b1d36b9  push rcx
000076049b1d36ba  push rdx
000076049b1d36bb  push rdi
000076049b1d36bc  push rsi
000076049b1d36bd  push r8
000076049b1d36bf  push r9
000076049b1d36c1  push r10
000076049b1d36c3  push r11
000076049b1d36c5  sub rsp, 0xF0
000076049b1d36cc  vmovaps [rsp], xmm0
000076049b1d36d1  vmovaps [rsp+0x10], xmm1
000076049b1d36d7  vmovaps [rsp+0x20], xmm2
000076049b1d36dd  vmovaps [rsp+0x30], xmm3
000076049b1d36e3  vmovaps [rsp+0x40], xmm4
000076049b1d36e9  vmovaps [rsp+0x50], xmm5
000076049b1d36ef  vmovaps [rsp+0x60], xmm6
000076049b1d36f5  vmovaps [rsp+0x70], xmm7
000076049b1d36fb  vmovaps [rsp+0x80], xmm8
000076049b1d3704  vmovaps [rsp+0x90], xmm9
000076049b1d370d  vmovaps [rsp+0xA0], xmm10
000076049b1d3716  vmovaps [rsp+0xB0], xmm11
000076049b1d371f  vmovaps [rsp+0xC0], xmm13
000076049b1d3728  vmovaps [rsp+0xD0], xmm14
000076049b1d3731  vmovaps [rsp+0xE0], xmm15
000076049b1d373a  sub rsp, 0x30
000076049b1d373e  movaps [rsp], xmm12
000076049b1d3743  movaps [rsp+0x10], xmm15
000076049b1d3749  movaps [rsp+0x20], xmm13
000076049b1d374f  lea rdi, [rsp]
000076049b1d3753  mov esi, 0x00
000076049b1d3758  mov rax, 0x64C06813C530
000076049b1d3762  call rax
000076049b1d3764  movaps xmm12, [rsp]
000076049b1d3769  add rsp, 0x30
000076049b1d376d  vmovaps xmm0, [rsp]
000076049b1d3772  vmovaps xmm1, [rsp+0x10]
000076049b1d3778  vmovaps xmm2, [rsp+0x20]
000076049b1d377e  vmovaps xmm3, [rsp+0x30]
000076049b1d3784  vmovaps xmm4, [rsp+0x40]
000076049b1d378a  vmovaps xmm5, [rsp+0x50]
000076049b1d3790  vmovaps xmm6, [rsp+0x60]
000076049b1d3796  vmovaps xmm7, [rsp+0x70]
000076049b1d379c  vmovaps xmm8, [rsp+0x80]
000076049b1d37a5  vmovaps xmm9, [rsp+0x90]
000076049b1d37ae  vmovaps xmm10, [rsp+0xA0]
000076049b1d37b7  vmovaps xmm11, [rsp+0xB0]
000076049b1d37c0  vmovaps xmm13, [rsp+0xC0]
000076049b1d37c9  vmovaps xmm14, [rsp+0xD0]
000076049b1d37d2  vmovaps xmm15, [rsp+0xE0]
000076049b1d37db  add rsp, 0xF0
000076049b1d37e2  pop r11
000076049b1d37e4  pop r10
000076049b1d37e6  pop r9
000076049b1d37e8  pop r8
000076049b1d37ea  pop rsi
000076049b1d37eb  pop rdi
000076049b1d37ec  pop rdx
000076049b1d37ed  pop rcx
000076049b1d37ee  pop rax
000076049b1d37ef  add rsp, 0x08
000076049b1d37f3  jmp 0x000076049B1CFF34
000076049b1d37f8  sub rsp, 0x08
000076049b1d37fc  push rax
000076049b1d37fd  push rcx
000076049b1d37fe  push rdx
000076049b1d37ff  push rdi
000076049b1d3800  push rsi
000076049b1d3801  push r8
000076049b1d3803  push r9
000076049b1d3805  push r10
000076049b1d3807  push r11
000076049b1d3809  sub rsp, 0xF0
000076049b1d3810  vmovaps [rsp], xmm0
000076049b1d3815  vmovaps [rsp+0x10], xmm1
000076049b1d381b  vmovaps [rsp+0x20], xmm2
000076049b1d3821  vmovaps [rsp+0x30], xmm3
000076049b1d3827  vmovaps [rsp+0x40], xmm4
000076049b1d382d  vmovaps [rsp+0x50], xmm5
000076049b1d3833  vmovaps [rsp+0x60], xmm6
000076049b1d3839  vmovaps [rsp+0x70], xmm7
000076049b1d383f  vmovaps [rsp+0x80], xmm8
000076049b1d3848  vmovaps [rsp+0x90], xmm9
000076049b1d3851  vmovaps [rsp+0xA0], xmm10
000076049b1d385a  vmovaps [rsp+0xB0], xmm11
000076049b1d3863  vmovaps [rsp+0xC0], xmm12
000076049b1d386c  vmovaps [rsp+0xD0], xmm13
000076049b1d3875  vmovaps [rsp+0xE0], xmm14
000076049b1d387e  sub rsp, 0x30
000076049b1d3882  movaps [rsp], xmm15
000076049b1d3887  movaps [rsp+0x10], xmm13
000076049b1d388d  movaps [rsp+0x20], xmm10
000076049b1d3893  lea rdi, [rsp]
000076049b1d3897  mov esi, 0x00
000076049b1d389c  mov rax, 0x64C06813C530
000076049b1d38a6  call rax
000076049b1d38a8  movaps xmm15, [rsp]
000076049b1d38ad  add rsp, 0x30
000076049b1d38b1  vmovaps xmm0, [rsp]
000076049b1d38b6  vmovaps xmm1, [rsp+0x10]
000076049b1d38bc  vmovaps xmm2, [rsp+0x20]
000076049b1d38c2  vmovaps xmm3, [rsp+0x30]
000076049b1d38c8  vmovaps xmm4, [rsp+0x40]
000076049b1d38ce  vmovaps xmm5, [rsp+0x50]
000076049b1d38d4  vmovaps xmm6, [rsp+0x60]
000076049b1d38da  vmovaps xmm7, [rsp+0x70]
000076049b1d38e0  vmovaps xmm8, [rsp+0x80]
000076049b1d38e9  vmovaps xmm9, [rsp+0x90]
000076049b1d38f2  vmovaps xmm10, [rsp+0xA0]
000076049b1d38fb  vmovaps xmm11, [rsp+0xB0]
000076049b1d3904  vmovaps xmm12, [rsp+0xC0]
000076049b1d390d  vmovaps xmm13, [rsp+0xD0]
000076049b1d3916  vmovaps xmm14, [rsp+0xE0]
000076049b1d391f  add rsp, 0xF0
000076049b1d3926  pop r11
000076049b1d3928  pop r10
000076049b1d392a  pop r9
000076049b1d392c  pop r8
000076049b1d392e  pop rsi
000076049b1d392f  pop rdi
000076049b1d3930  pop rdx
000076049b1d3931  pop rcx
000076049b1d3932  pop rax
000076049b1d3933  add rsp, 0x08
000076049b1d3937  jmp 0x000076049B1CFF55
000076049b1d393c  call 0x000076049B00C260
000076049b1d3941  jmp 0x000076049B1CFFB0
000076049b1d3946  sub rsp, 0x08
000076049b1d394a  push rax
000076049b1d394b  push rcx
000076049b1d394c  push rdx
000076049b1d394d  push rdi
000076049b1d394e  push rsi
000076049b1d394f  push r8
000076049b1d3951  push r9
000076049b1d3953  push r10
000076049b1d3955  push r11
000076049b1d3957  sub rsp, 0xF0
000076049b1d395e  vmovaps [rsp], xmm0
000076049b1d3963  vmovaps [rsp+0x10], xmm1
000076049b1d3969  vmovaps [rsp+0x20], xmm2
000076049b1d396f  vmovaps [rsp+0x30], xmm3
000076049b1d3975  vmovaps [rsp+0x40], xmm4
000076049b1d397b  vmovaps [rsp+0x50], xmm5
000076049b1d3981  vmovaps [rsp+0x60], xmm6
000076049b1d3987  vmovaps [rsp+0x70], xmm7
000076049b1d398d  vmovaps [rsp+0x80], xmm8
000076049b1d3996  vmovaps [rsp+0x90], xmm10
000076049b1d399f  vmovaps [rsp+0xA0], xmm11
000076049b1d39a8  vmovaps [rsp+0xB0], xmm12
000076049b1d39b1  vmovaps [rsp+0xC0], xmm13
000076049b1d39ba  vmovaps [rsp+0xD0], xmm14
000076049b1d39c3  vmovaps [rsp+0xE0], xmm15
000076049b1d39cc  sub rsp, 0x30
000076049b1d39d0  movaps [rsp], xmm9
000076049b1d39d5  movaps [rsp+0x10], xmm8
000076049b1d39db  movaps [rsp+0x20], xmm10
000076049b1d39e1  lea rdi, [rsp]
000076049b1d39e5  mov esi, 0x00
000076049b1d39ea  mov rax, 0x64C06813C530
000076049b1d39f4  call rax
000076049b1d39f6  movaps xmm9, [rsp]
000076049b1d39fb  add rsp, 0x30
000076049b1d39ff  vmovaps xmm0, [rsp]
000076049b1d3a04  vmovaps xmm1, [rsp+0x10]
000076049b1d3a0a  vmovaps xmm2, [rsp+0x20]
000076049b1d3a10  vmovaps xmm3, [rsp+0x30]
000076049b1d3a16  vmovaps xmm4, [rsp+0x40]
000076049b1d3a1c  vmovaps xmm5, [rsp+0x50]
000076049b1d3a22  vmovaps xmm6, [rsp+0x60]
000076049b1d3a28  vmovaps xmm7, [rsp+0x70]
000076049b1d3a2e  vmovaps xmm8, [rsp+0x80]
000076049b1d3a37  vmovaps xmm10, [rsp+0x90]
000076049b1d3a40  vmovaps xmm11, [rsp+0xA0]
000076049b1d3a49  vmovaps xmm12, [rsp+0xB0]
000076049b1d3a52  vmovaps xmm13, [rsp+0xC0]
000076049b1d3a5b  vmovaps xmm14, [rsp+0xD0]
000076049b1d3a64  vmovaps xmm15, [rsp+0xE0]
000076049b1d3a6d  add rsp, 0xF0
000076049b1d3a74  pop r11
000076049b1d3a76  pop r10
000076049b1d3a78  pop r9
000076049b1d3a7a  pop r8
000076049b1d3a7c  pop rsi
000076049b1d3a7d  pop rdi
000076049b1d3a7e  pop rdx
000076049b1d3a7f  pop rcx
000076049b1d3a80  pop rax
000076049b1d3a81  add rsp, 0x08
000076049b1d3a85  jmp 0x000076049B1CFFE1
000076049b1d3a8a  sub rsp, 0x08
000076049b1d3a8e  push rax
000076049b1d3a8f  push rcx
000076049b1d3a90  push rdx
000076049b1d3a91  push rdi
000076049b1d3a92  push rsi
000076049b1d3a93  push r8
000076049b1d3a95  push r9
000076049b1d3a97  push r10
000076049b1d3a99  push r11
000076049b1d3a9b  sub rsp, 0xF0
000076049b1d3aa2  vmovaps [rsp], xmm0
000076049b1d3aa7  vmovaps [rsp+0x10], xmm1
000076049b1d3aad  vmovaps [rsp+0x20], xmm2
000076049b1d3ab3  vmovaps [rsp+0x30], xmm3
000076049b1d3ab9  vmovaps [rsp+0x40], xmm4
000076049b1d3abf  vmovaps [rsp+0x50], xmm5
000076049b1d3ac5  vmovaps [rsp+0x60], xmm6
000076049b1d3acb  vmovaps [rsp+0x70], xmm7
000076049b1d3ad1  vmovaps [rsp+0x80], xmm8
000076049b1d3ada  vmovaps [rsp+0x90], xmm9
000076049b1d3ae3  vmovaps [rsp+0xA0], xmm11
000076049b1d3aec  vmovaps [rsp+0xB0], xmm12
000076049b1d3af5  vmovaps [rsp+0xC0], xmm13
000076049b1d3afe  vmovaps [rsp+0xD0], xmm14
000076049b1d3b07  vmovaps [rsp+0xE0], xmm15
000076049b1d3b10  sub rsp, 0x30
000076049b1d3b14  movaps [rsp], xmm10
000076049b1d3b19  movaps [rsp+0x10], xmm1
000076049b1d3b1e  movaps [rsp+0x20], xmm11
000076049b1d3b24  lea rdi, [rsp]
000076049b1d3b28  mov esi, 0x00
000076049b1d3b2d  mov rax, 0x64C06813C530
000076049b1d3b37  call rax
000076049b1d3b39  movaps xmm10, [rsp]
000076049b1d3b3e  add rsp, 0x30
000076049b1d3b42  vmovaps xmm0, [rsp]
000076049b1d3b47  vmovaps xmm1, [rsp+0x10]
000076049b1d3b4d  vmovaps xmm2, [rsp+0x20]
000076049b1d3b53  vmovaps xmm3, [rsp+0x30]
000076049b1d3b59  vmovaps xmm4, [rsp+0x40]
000076049b1d3b5f  vmovaps xmm5, [rsp+0x50]
000076049b1d3b65  vmovaps xmm6, [rsp+0x60]
000076049b1d3b6b  vmovaps xmm7, [rsp+0x70]
000076049b1d3b71  vmovaps xmm8, [rsp+0x80]
000076049b1d3b7a  vmovaps xmm9, [rsp+0x90]
000076049b1d3b83  vmovaps xmm11, [rsp+0xA0]
000076049b1d3b8c  vmovaps xmm12, [rsp+0xB0]
000076049b1d3b95  vmovaps xmm13, [rsp+0xC0]
000076049b1d3b9e  vmovaps xmm14, [rsp+0xD0]
000076049b1d3ba7  vmovaps xmm15, [rsp+0xE0]
000076049b1d3bb0  add rsp, 0xF0
000076049b1d3bb7  pop r11
000076049b1d3bb9  pop r10
000076049b1d3bbb  pop r9
000076049b1d3bbd  pop r8
000076049b1d3bbf  pop rsi
000076049b1d3bc0  pop rdi
000076049b1d3bc1  pop rdx
000076049b1d3bc2  pop rcx
000076049b1d3bc3  pop rax
000076049b1d3bc4  add rsp, 0x08
000076049b1d3bc8  jmp 0x000076049B1CFFFC
000076049b1d3bcd  sub rsp, 0x08
000076049b1d3bd1  push rax
000076049b1d3bd2  push rcx
000076049b1d3bd3  push rdx
000076049b1d3bd4  push rdi
000076049b1d3bd5  push rsi
000076049b1d3bd6  push r8
000076049b1d3bd8  push r9
000076049b1d3bda  push r10
000076049b1d3bdc  push r11
000076049b1d3bde  sub rsp, 0xF0
000076049b1d3be5  vmovaps [rsp], xmm0
000076049b1d3bea  vmovaps [rsp+0x10], xmm2
000076049b1d3bf0  vmovaps [rsp+0x20], xmm3
000076049b1d3bf6  vmovaps [rsp+0x30], xmm4
000076049b1d3bfc  vmovaps [rsp+0x40], xmm5
000076049b1d3c02  vmovaps [rsp+0x50], xmm6
000076049b1d3c08  vmovaps [rsp+0x60], xmm7
000076049b1d3c0e  vmovaps [rsp+0x70], xmm8
000076049b1d3c14  vmovaps [rsp+0x80], xmm9
000076049b1d3c1d  vmovaps [rsp+0x90], xmm10
000076049b1d3c26  vmovaps [rsp+0xA0], xmm11
000076049b1d3c2f  vmovaps [rsp+0xB0], xmm12
000076049b1d3c38  vmovaps [rsp+0xC0], xmm13
000076049b1d3c41  vmovaps [rsp+0xD0], xmm14
000076049b1d3c4a  vmovaps [rsp+0xE0], xmm15
000076049b1d3c53  sub rsp, 0x30
000076049b1d3c57  movaps [rsp], xmm1
000076049b1d3c5b  movaps [rsp+0x10], xmm14
000076049b1d3c61  movaps [rsp+0x20], xmm6
000076049b1d3c66  lea rdi, [rsp]
000076049b1d3c6a  mov esi, 0x00
000076049b1d3c6f  mov rax, 0x64C06813C530
000076049b1d3c79  call rax
000076049b1d3c7b  movaps xmm1, [rsp]
000076049b1d3c7f  add rsp, 0x30
000076049b1d3c83  vmovaps xmm0, [rsp]
000076049b1d3c88  vmovaps xmm2, [rsp+0x10]
000076049b1d3c8e  vmovaps xmm3, [rsp+0x20]
000076049b1d3c94  vmovaps xmm4, [rsp+0x30]
000076049b1d3c9a  vmovaps xmm5, [rsp+0x40]
000076049b1d3ca0  vmovaps xmm6, [rsp+0x50]
000076049b1d3ca6  vmovaps xmm7, [rsp+0x60]
000076049b1d3cac  vmovaps xmm8, [rsp+0x70]
000076049b1d3cb2  vmovaps xmm9, [rsp+0x80]
000076049b1d3cbb  vmovaps xmm10, [rsp+0x90]
000076049b1d3cc4  vmovaps xmm11, [rsp+0xA0]
000076049b1d3ccd  vmovaps xmm12, [rsp+0xB0]
000076049b1d3cd6  vmovaps xmm13, [rsp+0xC0]
000076049b1d3cdf  vmovaps xmm14, [rsp+0xD0]
000076049b1d3ce8  vmovaps xmm15, [rsp+0xE0]
000076049b1d3cf1  add rsp, 0xF0
000076049b1d3cf8  pop r11
000076049b1d3cfa  pop r10
000076049b1d3cfc  pop r9
000076049b1d3cfe  pop r8
000076049b1d3d00  pop rsi
000076049b1d3d01  pop rdi
000076049b1d3d02  pop rdx
000076049b1d3d03  pop rcx
000076049b1d3d04  pop rax
000076049b1d3d05  add rsp, 0x08
000076049b1d3d09  jmp 0x000076049B1D0015
000076049b1d3d0e  sub rsp, 0x08
000076049b1d3d12  push rax
000076049b1d3d13  push rcx
000076049b1d3d14  push rdx
000076049b1d3d15  push rdi
000076049b1d3d16  push rsi
000076049b1d3d17  push r8
000076049b1d3d19  push r9
000076049b1d3d1b  push r10
000076049b1d3d1d  push r11
000076049b1d3d1f  sub rsp, 0xF0
000076049b1d3d26  vmovaps [rsp], xmm0
000076049b1d3d2b  vmovaps [rsp+0x10], xmm1
000076049b1d3d31  vmovaps [rsp+0x20], xmm2
000076049b1d3d37  vmovaps [rsp+0x30], xmm3
000076049b1d3d3d  vmovaps [rsp+0x40], xmm4
000076049b1d3d43  vmovaps [rsp+0x50], xmm5
000076049b1d3d49  vmovaps [rsp+0x60], xmm6
000076049b1d3d4f  vmovaps [rsp+0x70], xmm7
000076049b1d3d55  vmovaps [rsp+0x80], xmm8
000076049b1d3d5e  vmovaps [rsp+0x90], xmm9
000076049b1d3d67  vmovaps [rsp+0xA0], xmm10
000076049b1d3d70  vmovaps [rsp+0xB0], xmm12
000076049b1d3d79  vmovaps [rsp+0xC0], xmm13
000076049b1d3d82  vmovaps [rsp+0xD0], xmm14
000076049b1d3d8b  vmovaps [rsp+0xE0], xmm15
000076049b1d3d94  sub rsp, 0x30
000076049b1d3d98  movaps [rsp], xmm11
000076049b1d3d9d  movaps [rsp+0x10], xmm13
000076049b1d3da3  movaps [rsp+0x20], xmm14
000076049b1d3da9  lea rdi, [rsp]
000076049b1d3dad  mov esi, 0x00
000076049b1d3db2  mov rax, 0x64C06813C530
000076049b1d3dbc  call rax
000076049b1d3dbe  movaps xmm11, [rsp]
000076049b1d3dc3  add rsp, 0x30
000076049b1d3dc7  vmovaps xmm0, [rsp]
000076049b1d3dcc  vmovaps xmm1, [rsp+0x10]
000076049b1d3dd2  vmovaps xmm2, [rsp+0x20]
000076049b1d3dd8  vmovaps xmm3, [rsp+0x30]
000076049b1d3dde  vmovaps xmm4, [rsp+0x40]
000076049b1d3de4  vmovaps xmm5, [rsp+0x50]
000076049b1d3dea  vmovaps xmm6, [rsp+0x60]
000076049b1d3df0  vmovaps xmm7, [rsp+0x70]
000076049b1d3df6  vmovaps xmm8, [rsp+0x80]
000076049b1d3dff  vmovaps xmm9, [rsp+0x90]
000076049b1d3e08  vmovaps xmm10, [rsp+0xA0]
000076049b1d3e11  vmovaps xmm12, [rsp+0xB0]
000076049b1d3e1a  vmovaps xmm13, [rsp+0xC0]
000076049b1d3e23  vmovaps xmm14, [rsp+0xD0]
000076049b1d3e2c  vmovaps xmm15, [rsp+0xE0]
000076049b1d3e35  add rsp, 0xF0
000076049b1d3e3c  pop r11
000076049b1d3e3e  pop r10
000076049b1d3e40  pop r9
000076049b1d3e42  pop r8
000076049b1d3e44  pop rsi
000076049b1d3e45  pop rdi
000076049b1d3e46  pop rdx
000076049b1d3e47  pop rcx
000076049b1d3e48  pop rax
000076049b1d3e49  add rsp, 0x08
000076049b1d3e4d  jmp 0x000076049B1D003F
000076049b1d3e52  sub rsp, 0x08
000076049b1d3e56  push rax
000076049b1d3e57  push rcx
000076049b1d3e58  push rdx
000076049b1d3e59  push rdi
000076049b1d3e5a  push rsi
000076049b1d3e5b  push r8
000076049b1d3e5d  push r9
000076049b1d3e5f  push r10
000076049b1d3e61  push r11
000076049b1d3e63  sub rsp, 0xF0
000076049b1d3e6a  vmovaps [rsp], xmm0
000076049b1d3e6f  vmovaps [rsp+0x10], xmm1
000076049b1d3e75  vmovaps [rsp+0x20], xmm2
000076049b1d3e7b  vmovaps [rsp+0x30], xmm3
000076049b1d3e81  vmovaps [rsp+0x40], xmm4
000076049b1d3e87  vmovaps [rsp+0x50], xmm5
000076049b1d3e8d  vmovaps [rsp+0x60], xmm6
000076049b1d3e93  vmovaps [rsp+0x70], xmm7
000076049b1d3e99  vmovaps [rsp+0x80], xmm8
000076049b1d3ea2  vmovaps [rsp+0x90], xmm9
000076049b1d3eab  vmovaps [rsp+0xA0], xmm10
000076049b1d3eb4  vmovaps [rsp+0xB0], xmm11
000076049b1d3ebd  vmovaps [rsp+0xC0], xmm12
000076049b1d3ec6  vmovaps [rsp+0xD0], xmm14
000076049b1d3ecf  vmovaps [rsp+0xE0], xmm15
000076049b1d3ed8  sub rsp, 0x30
000076049b1d3edc  movaps [rsp], xmm13
000076049b1d3ee1  movaps [rsp+0x10], xmm8
000076049b1d3ee7  movaps [rsp+0x20], xmm14
000076049b1d3eed  lea rdi, [rsp]
000076049b1d3ef1  mov esi, 0x00
000076049b1d3ef6  mov rax, 0x64C06813C530
000076049b1d3f00  call rax
000076049b1d3f02  movaps xmm13, [rsp]
000076049b1d3f07  add rsp, 0x30
000076049b1d3f0b  vmovaps xmm0, [rsp]
000076049b1d3f10  vmovaps xmm1, [rsp+0x10]
000076049b1d3f16  vmovaps xmm2, [rsp+0x20]
000076049b1d3f1c  vmovaps xmm3, [rsp+0x30]
000076049b1d3f22  vmovaps xmm4, [rsp+0x40]
000076049b1d3f28  vmovaps xmm5, [rsp+0x50]
000076049b1d3f2e  vmovaps xmm6, [rsp+0x60]
000076049b1d3f34  vmovaps xmm7, [rsp+0x70]
000076049b1d3f3a  vmovaps xmm8, [rsp+0x80]
000076049b1d3f43  vmovaps xmm9, [rsp+0x90]
000076049b1d3f4c  vmovaps xmm10, [rsp+0xA0]
000076049b1d3f55  vmovaps xmm11, [rsp+0xB0]
000076049b1d3f5e  vmovaps xmm12, [rsp+0xC0]
000076049b1d3f67  vmovaps xmm14, [rsp+0xD0]
000076049b1d3f70  vmovaps xmm15, [rsp+0xE0]
000076049b1d3f79  add rsp, 0xF0
000076049b1d3f80  pop r11
000076049b1d3f82  pop r10
000076049b1d3f84  pop r9
000076049b1d3f86  pop r8
000076049b1d3f88  pop rsi
000076049b1d3f89  pop rdi
000076049b1d3f8a  pop rdx
000076049b1d3f8b  pop rcx
000076049b1d3f8c  pop rax
000076049b1d3f8d  add rsp, 0x08
000076049b1d3f91  jmp 0x000076049B1D006E
000076049b1d3f96  sub rsp, 0x08
000076049b1d3f9a  push rax
000076049b1d3f9b  push rcx
000076049b1d3f9c  push rdx
000076049b1d3f9d  push rdi
000076049b1d3f9e  push rsi
000076049b1d3f9f  push r8
000076049b1d3fa1  push r9
000076049b1d3fa3  push r10
000076049b1d3fa5  push r11
000076049b1d3fa7  sub rsp, 0xF0
000076049b1d3fae  vmovaps [rsp], xmm0
000076049b1d3fb3  vmovaps [rsp+0x10], xmm1
000076049b1d3fb9  vmovaps [rsp+0x20], xmm2
000076049b1d3fbf  vmovaps [rsp+0x30], xmm3
000076049b1d3fc5  vmovaps [rsp+0x40], xmm4
000076049b1d3fcb  vmovaps [rsp+0x50], xmm5
000076049b1d3fd1  vmovaps [rsp+0x60], xmm6
000076049b1d3fd7  vmovaps [rsp+0x70], xmm7
000076049b1d3fdd  vmovaps [rsp+0x80], xmm9
000076049b1d3fe6  vmovaps [rsp+0x90], xmm10
000076049b1d3fef  vmovaps [rsp+0xA0], xmm11
000076049b1d3ff8  vmovaps [rsp+0xB0], xmm12
000076049b1d4001  vmovaps [rsp+0xC0], xmm13
000076049b1d400a  vmovaps [rsp+0xD0], xmm14
000076049b1d4013  vmovaps [rsp+0xE0], xmm15
000076049b1d401c  sub rsp, 0x30
000076049b1d4020  movaps [rsp], xmm8
000076049b1d4025  movaps [rsp+0x10], xmm7
000076049b1d402a  movaps [rsp+0x20], xmm14
000076049b1d4030  lea rdi, [rsp]
000076049b1d4034  mov esi, 0x00
000076049b1d4039  mov rax, 0x64C06813C530
000076049b1d4043  call rax
000076049b1d4045  movaps xmm8, [rsp]
000076049b1d404a  add rsp, 0x30
000076049b1d404e  vmovaps xmm0, [rsp]
000076049b1d4053  vmovaps xmm1, [rsp+0x10]
000076049b1d4059  vmovaps xmm2, [rsp+0x20]
000076049b1d405f  vmovaps xmm3, [rsp+0x30]
000076049b1d4065  vmovaps xmm4, [rsp+0x40]
000076049b1d406b  vmovaps xmm5, [rsp+0x50]
000076049b1d4071  vmovaps xmm6, [rsp+0x60]
000076049b1d4077  vmovaps xmm7, [rsp+0x70]
000076049b1d407d  vmovaps xmm9, [rsp+0x80]
000076049b1d4086  vmovaps xmm10, [rsp+0x90]
000076049b1d408f  vmovaps xmm11, [rsp+0xA0]
000076049b1d4098  vmovaps xmm12, [rsp+0xB0]
000076049b1d40a1  vmovaps xmm13, [rsp+0xC0]
000076049b1d40aa  vmovaps xmm14, [rsp+0xD0]
000076049b1d40b3  vmovaps xmm15, [rsp+0xE0]
000076049b1d40bc  add rsp, 0xF0
000076049b1d40c3  pop r11
000076049b1d40c5  pop r10
000076049b1d40c7  pop r9
000076049b1d40c9  pop r8
000076049b1d40cb  pop rsi
000076049b1d40cc  pop rdi
000076049b1d40cd  pop rdx
000076049b1d40ce  pop rcx
000076049b1d40cf  pop rax
000076049b1d40d0  add rsp, 0x08
000076049b1d40d4  jmp 0x000076049B1D0094
000076049b1d40d9  sub rsp, 0x08
000076049b1d40dd  push rax
000076049b1d40de  push rcx
000076049b1d40df  push rdx
000076049b1d40e0  push rdi
000076049b1d40e1  push rsi
000076049b1d40e2  push r8
000076049b1d40e4  push r9
000076049b1d40e6  push r10
000076049b1d40e8  push r11
000076049b1d40ea  sub rsp, 0xF0
000076049b1d40f1  vmovaps [rsp], xmm0
000076049b1d40f6  vmovaps [rsp+0x10], xmm1
000076049b1d40fc  vmovaps [rsp+0x20], xmm2
000076049b1d4102  vmovaps [rsp+0x30], xmm3
000076049b1d4108  vmovaps [rsp+0x40], xmm4
000076049b1d410e  vmovaps [rsp+0x50], xmm5
000076049b1d4114  vmovaps [rsp+0x60], xmm6
000076049b1d411a  vmovaps [rsp+0x70], xmm7
000076049b1d4120  vmovaps [rsp+0x80], xmm8
000076049b1d4129  vmovaps [rsp+0x90], xmm9
000076049b1d4132  vmovaps [rsp+0xA0], xmm10
000076049b1d413b  vmovaps [rsp+0xB0], xmm11
000076049b1d4144  vmovaps [rsp+0xC0], xmm12
000076049b1d414d  vmovaps [rsp+0xD0], xmm13
000076049b1d4156  vmovaps [rsp+0xE0], xmm15
000076049b1d415f  sub rsp, 0x30
000076049b1d4163  movaps [rsp], xmm14
000076049b1d4168  movaps [rsp+0x10], xmm12
000076049b1d416e  movaps [rsp+0x20], xmm9
000076049b1d4174  lea rdi, [rsp]
000076049b1d4178  mov esi, 0x00
000076049b1d417d  mov rax, 0x64C06813C530
000076049b1d4187  call rax
000076049b1d4189  movaps xmm14, [rsp]
000076049b1d418e  add rsp, 0x30
000076049b1d4192  vmovaps xmm0, [rsp]
000076049b1d4197  vmovaps xmm1, [rsp+0x10]
000076049b1d419d  vmovaps xmm2, [rsp+0x20]
000076049b1d41a3  vmovaps xmm3, [rsp+0x30]
000076049b1d41a9  vmovaps xmm4, [rsp+0x40]
000076049b1d41af  vmovaps xmm5, [rsp+0x50]
000076049b1d41b5  vmovaps xmm6, [rsp+0x60]
000076049b1d41bb  vmovaps xmm7, [rsp+0x70]
000076049b1d41c1  vmovaps xmm8, [rsp+0x80]
000076049b1d41ca  vmovaps xmm9, [rsp+0x90]
000076049b1d41d3  vmovaps xmm10, [rsp+0xA0]
000076049b1d41dc  vmovaps xmm11, [rsp+0xB0]
000076049b1d41e5  vmovaps xmm12, [rsp+0xC0]
000076049b1d41ee  vmovaps xmm13, [rsp+0xD0]
000076049b1d41f7  vmovaps xmm15, [rsp+0xE0]
000076049b1d4200  add rsp, 0xF0
000076049b1d4207  pop r11
000076049b1d4209  pop r10
000076049b1d420b  pop r9
000076049b1d420d  pop r8
000076049b1d420f  pop rsi
000076049b1d4210  pop rdi
000076049b1d4211  pop rdx
000076049b1d4212  pop rcx
000076049b1d4213  pop rax
000076049b1d4214  add rsp, 0x08
000076049b1d4218  jmp 0x000076049B1D00AE
000076049b1d421d  sub rsp, 0x08
000076049b1d4221  push rax
000076049b1d4222  push rcx
000076049b1d4223  push rdx
000076049b1d4224  push rdi
000076049b1d4225  push rsi
000076049b1d4226  push r8
000076049b1d4228  push r9
000076049b1d422a  push r10
000076049b1d422c  push r11
000076049b1d422e  sub rsp, 0xF0
000076049b1d4235  vmovaps [rsp], xmm0
000076049b1d423a  vmovaps [rsp+0x10], xmm1
000076049b1d4240  vmovaps [rsp+0x20], xmm2
000076049b1d4246  vmovaps [rsp+0x30], xmm3
000076049b1d424c  vmovaps [rsp+0x40], xmm4
000076049b1d4252  vmovaps [rsp+0x50], xmm5
000076049b1d4258  vmovaps [rsp+0x60], xmm6
000076049b1d425e  vmovaps [rsp+0x70], xmm7
000076049b1d4264  vmovaps [rsp+0x80], xmm8
000076049b1d426d  vmovaps [rsp+0x90], xmm10
000076049b1d4276  vmovaps [rsp+0xA0], xmm11
000076049b1d427f  vmovaps [rsp+0xB0], xmm12
000076049b1d4288  vmovaps [rsp+0xC0], xmm13
000076049b1d4291  vmovaps [rsp+0xD0], xmm14
000076049b1d429a  vmovaps [rsp+0xE0], xmm15
000076049b1d42a3  sub rsp, 0x30
000076049b1d42a7  movaps [rsp], xmm9
000076049b1d42ac  movaps [rsp+0x10], xmm7
000076049b1d42b1  movaps [rsp+0x20], xmm12
000076049b1d42b7  lea rdi, [rsp]
000076049b1d42bb  mov esi, 0x00
000076049b1d42c0  mov rax, 0x64C06813C530
000076049b1d42ca  call rax
000076049b1d42cc  movaps xmm9, [rsp]
000076049b1d42d1  add rsp, 0x30
000076049b1d42d5  vmovaps xmm0, [rsp]
000076049b1d42da  vmovaps xmm1, [rsp+0x10]
000076049b1d42e0  vmovaps xmm2, [rsp+0x20]
000076049b1d42e6  vmovaps xmm3, [rsp+0x30]
000076049b1d42ec  vmovaps xmm4, [rsp+0x40]
000076049b1d42f2  vmovaps xmm5, [rsp+0x50]
000076049b1d42f8  vmovaps xmm6, [rsp+0x60]
000076049b1d42fe  vmovaps xmm7, [rsp+0x70]
000076049b1d4304  vmovaps xmm8, [rsp+0x80]
000076049b1d430d  vmovaps xmm10, [rsp+0x90]
000076049b1d4316  vmovaps xmm11, [rsp+0xA0]
000076049b1d431f  vmovaps xmm12, [rsp+0xB0]
000076049b1d4328  vmovaps xmm13, [rsp+0xC0]
000076049b1d4331  vmovaps xmm14, [rsp+0xD0]
000076049b1d433a  vmovaps xmm15, [rsp+0xE0]
000076049b1d4343  add rsp, 0xF0
000076049b1d434a  pop r11
000076049b1d434c  pop r10
000076049b1d434e  pop r9
000076049b1d4350  pop r8
000076049b1d4352  pop rsi
000076049b1d4353  pop rdi
000076049b1d4354  pop rdx
000076049b1d4355  pop rcx
000076049b1d4356  pop rax
000076049b1d4357  add rsp, 0x08
000076049b1d435b  jmp 0x000076049B1D00DD
000076049b1d4360  sub rsp, 0x08
000076049b1d4364  push rax
000076049b1d4365  push rcx
000076049b1d4366  push rdx
000076049b1d4367  push rdi
000076049b1d4368  push rsi
000076049b1d4369  push r8
000076049b1d436b  push r9
000076049b1d436d  push r10
000076049b1d436f  push r11
000076049b1d4371  sub rsp, 0xF0
000076049b1d4378  vmovaps [rsp], xmm0
000076049b1d437d  vmovaps [rsp+0x10], xmm1
000076049b1d4383  vmovaps [rsp+0x20], xmm2
000076049b1d4389  vmovaps [rsp+0x30], xmm3
000076049b1d438f  vmovaps [rsp+0x40], xmm4
000076049b1d4395  vmovaps [rsp+0x50], xmm5
000076049b1d439b  vmovaps [rsp+0x60], xmm6
000076049b1d43a1  vmovaps [rsp+0x70], xmm7
000076049b1d43a7  vmovaps [rsp+0x80], xmm8
000076049b1d43b0  vmovaps [rsp+0x90], xmm9
000076049b1d43b9  vmovaps [rsp+0xA0], xmm10
000076049b1d43c2  vmovaps [rsp+0xB0], xmm11
000076049b1d43cb  vmovaps [rsp+0xC0], xmm13
000076049b1d43d4  vmovaps [rsp+0xD0], xmm14
000076049b1d43dd  vmovaps [rsp+0xE0], xmm15
000076049b1d43e6  sub rsp, 0x30
000076049b1d43ea  movaps [rsp], xmm12
000076049b1d43ef  movaps [rsp+0x10], xmm15
000076049b1d43f5  movaps [rsp+0x20], xmm11
000076049b1d43fb  lea rdi, [rsp]
000076049b1d43ff  mov esi, 0x00
000076049b1d4404  mov rax, 0x64C06813C530
000076049b1d440e  call rax
000076049b1d4410  movaps xmm12, [rsp]
000076049b1d4415  add rsp, 0x30
000076049b1d4419  vmovaps xmm0, [rsp]
000076049b1d441e  vmovaps xmm1, [rsp+0x10]
000076049b1d4424  vmovaps xmm2, [rsp+0x20]
000076049b1d442a  vmovaps xmm3, [rsp+0x30]
000076049b1d4430  vmovaps xmm4, [rsp+0x40]
000076049b1d4436  vmovaps xmm5, [rsp+0x50]
000076049b1d443c  vmovaps xmm6, [rsp+0x60]
000076049b1d4442  vmovaps xmm7, [rsp+0x70]
000076049b1d4448  vmovaps xmm8, [rsp+0x80]
000076049b1d4451  vmovaps xmm9, [rsp+0x90]
000076049b1d445a  vmovaps xmm10, [rsp+0xA0]
000076049b1d4463  vmovaps xmm11, [rsp+0xB0]
000076049b1d446c  vmovaps xmm13, [rsp+0xC0]
000076049b1d4475  vmovaps xmm14, [rsp+0xD0]
000076049b1d447e  vmovaps xmm15, [rsp+0xE0]
000076049b1d4487  add rsp, 0xF0
000076049b1d448e  pop r11
000076049b1d4490  pop r10
000076049b1d4492  pop r9
000076049b1d4494  pop r8
000076049b1d4496  pop rsi
000076049b1d4497  pop rdi
000076049b1d4498  pop rdx
000076049b1d4499  pop rcx
000076049b1d449a  pop rax
000076049b1d449b  add rsp, 0x08
000076049b1d449f  jmp 0x000076049B1D00F7
000076049b1d44a4  sub rsp, 0x08
000076049b1d44a8  push rax
000076049b1d44a9  push rcx
000076049b1d44aa  push rdx
000076049b1d44ab  push rdi
000076049b1d44ac  push rsi
000076049b1d44ad  push r8
000076049b1d44af  push r9
000076049b1d44b1  push r10
000076049b1d44b3  push r11
000076049b1d44b5  sub rsp, 0xF0
000076049b1d44bc  vmovaps [rsp], xmm0
000076049b1d44c1  vmovaps [rsp+0x10], xmm1
000076049b1d44c7  vmovaps [rsp+0x20], xmm2
000076049b1d44cd  vmovaps [rsp+0x30], xmm3
000076049b1d44d3  vmovaps [rsp+0x40], xmm4
000076049b1d44d9  vmovaps [rsp+0x50], xmm5
000076049b1d44df  vmovaps [rsp+0x60], xmm6
000076049b1d44e5  vmovaps [rsp+0x70], xmm7
000076049b1d44eb  vmovaps [rsp+0x80], xmm8
000076049b1d44f4  vmovaps [rsp+0x90], xmm9
000076049b1d44fd  vmovaps [rsp+0xA0], xmm10
000076049b1d4506  vmovaps [rsp+0xB0], xmm12
000076049b1d450f  vmovaps [rsp+0xC0], xmm13
000076049b1d4518  vmovaps [rsp+0xD0], xmm14
000076049b1d4521  vmovaps [rsp+0xE0], xmm15
000076049b1d452a  sub rsp, 0x30
000076049b1d452e  movaps [rsp], xmm11
000076049b1d4533  movaps [rsp+0x10], xmm7
000076049b1d4538  movaps [rsp+0x20], xmm15
000076049b1d453e  lea rdi, [rsp]
000076049b1d4542  mov esi, 0x00
000076049b1d4547  mov rax, 0x64C06813C530
000076049b1d4551  call rax
000076049b1d4553  movaps xmm11, [rsp]
000076049b1d4558  add rsp, 0x30
000076049b1d455c  vmovaps xmm0, [rsp]
000076049b1d4561  vmovaps xmm1, [rsp+0x10]
000076049b1d4567  vmovaps xmm2, [rsp+0x20]
000076049b1d456d  vmovaps xmm3, [rsp+0x30]
000076049b1d4573  vmovaps xmm4, [rsp+0x40]
000076049b1d4579  vmovaps xmm5, [rsp+0x50]
000076049b1d457f  vmovaps xmm6, [rsp+0x60]
000076049b1d4585  vmovaps xmm7, [rsp+0x70]
000076049b1d458b  vmovaps xmm8, [rsp+0x80]
000076049b1d4594  vmovaps xmm9, [rsp+0x90]
000076049b1d459d  vmovaps xmm10, [rsp+0xA0]
000076049b1d45a6  vmovaps xmm12, [rsp+0xB0]
000076049b1d45af  vmovaps xmm13, [rsp+0xC0]
000076049b1d45b8  vmovaps xmm14, [rsp+0xD0]
000076049b1d45c1  vmovaps xmm15, [rsp+0xE0]
000076049b1d45ca  add rsp, 0xF0
000076049b1d45d1  pop r11
000076049b1d45d3  pop r10
000076049b1d45d5  pop r9
000076049b1d45d7  pop r8
000076049b1d45d9  pop rsi
000076049b1d45da  pop rdi
000076049b1d45db  pop rdx
000076049b1d45dc  pop rcx
000076049b1d45dd  pop rax
000076049b1d45de  add rsp, 0x08
000076049b1d45e2  jmp 0x000076049B1D0123
000076049b1d45e7  sub rsp, 0x08
000076049b1d45eb  push rax
000076049b1d45ec  push rcx
000076049b1d45ed  push rdx
000076049b1d45ee  push rdi
000076049b1d45ef  push rsi
000076049b1d45f0  push r8
000076049b1d45f2  push r9
000076049b1d45f4  push r10
000076049b1d45f6  push r11
000076049b1d45f8  sub rsp, 0xF0
000076049b1d45ff  vmovaps [rsp], xmm0
000076049b1d4604  vmovaps [rsp+0x10], xmm1
000076049b1d460a  vmovaps [rsp+0x20], xmm2
000076049b1d4610  vmovaps [rsp+0x30], xmm3
000076049b1d4616  vmovaps [rsp+0x40], xmm4
000076049b1d461c  vmovaps [rsp+0x50], xmm5
000076049b1d4622  vmovaps [rsp+0x60], xmm6
000076049b1d4628  vmovaps [rsp+0x70], xmm7
000076049b1d462e  vmovaps [rsp+0x80], xmm8
000076049b1d4637  vmovaps [rsp+0x90], xmm9
000076049b1d4640  vmovaps [rsp+0xA0], xmm10
000076049b1d4649  vmovaps [rsp+0xB0], xmm11
000076049b1d4652  vmovaps [rsp+0xC0], xmm12
000076049b1d465b  vmovaps [rsp+0xD0], xmm13
000076049b1d4664  vmovaps [rsp+0xE0], xmm14
000076049b1d466d  sub rsp, 0x30
000076049b1d4671  movaps [rsp], xmm15
000076049b1d4676  movaps [rsp+0x10], xmm10
000076049b1d467c  movaps [rsp+0x20], xmm13
000076049b1d4682  lea rdi, [rsp]
000076049b1d4686  mov esi, 0x00
000076049b1d468b  mov rax, 0x64C06813C530
000076049b1d4695  call rax
000076049b1d4697  movaps xmm15, [rsp]
000076049b1d469c  add rsp, 0x30
000076049b1d46a0  vmovaps xmm0, [rsp]
000076049b1d46a5  vmovaps xmm1, [rsp+0x10]
000076049b1d46ab  vmovaps xmm2, [rsp+0x20]
000076049b1d46b1  vmovaps xmm3, [rsp+0x30]
000076049b1d46b7  vmovaps xmm4, [rsp+0x40]
000076049b1d46bd  vmovaps xmm5, [rsp+0x50]
000076049b1d46c3  vmovaps xmm6, [rsp+0x60]
000076049b1d46c9  vmovaps xmm7, [rsp+0x70]
000076049b1d46cf  vmovaps xmm8, [rsp+0x80]
000076049b1d46d8  vmovaps xmm9, [rsp+0x90]
000076049b1d46e1  vmovaps xmm10, [rsp+0xA0]
000076049b1d46ea  vmovaps xmm11, [rsp+0xB0]
000076049b1d46f3  vmovaps xmm12, [rsp+0xC0]
000076049b1d46fc  vmovaps xmm13, [rsp+0xD0]
000076049b1d4705  vmovaps xmm14, [rsp+0xE0]
000076049b1d470e  add rsp, 0xF0
000076049b1d4715  pop r11
000076049b1d4717  pop r10
000076049b1d4719  pop r9
000076049b1d471b  pop r8
000076049b1d471d  pop rsi
000076049b1d471e  pop rdi
000076049b1d471f  pop rdx
000076049b1d4720  pop rcx
000076049b1d4721  pop rax
000076049b1d4722  add rsp, 0x08
000076049b1d4726  jmp 0x000076049B1D013D
000076049b1d472b  sub rsp, 0x08
000076049b1d472f  push rax
000076049b1d4730  push rcx
000076049b1d4731  push rdx
000076049b1d4732  push rdi
000076049b1d4733  push rsi
000076049b1d4734  push r8
000076049b1d4736  push r9
000076049b1d4738  push r10
000076049b1d473a  push r11
000076049b1d473c  sub rsp, 0xF0
000076049b1d4743  vmovaps [rsp], xmm0
000076049b1d4748  vmovaps [rsp+0x10], xmm1
000076049b1d474e  vmovaps [rsp+0x20], xmm2
000076049b1d4754  vmovaps [rsp+0x30], xmm3
000076049b1d475a  vmovaps [rsp+0x40], xmm4
000076049b1d4760  vmovaps [rsp+0x50], xmm5
000076049b1d4766  vmovaps [rsp+0x60], xmm6
000076049b1d476c  vmovaps [rsp+0x70], xmm7
000076049b1d4772  vmovaps [rsp+0x80], xmm8
000076049b1d477b  vmovaps [rsp+0x90], xmm9
000076049b1d4784  vmovaps [rsp+0xA0], xmm11
000076049b1d478d  vmovaps [rsp+0xB0], xmm12
000076049b1d4796  vmovaps [rsp+0xC0], xmm13
000076049b1d479f  vmovaps [rsp+0xD0], xmm14
000076049b1d47a8  vmovaps [rsp+0xE0], xmm15
000076049b1d47b1  sub rsp, 0x30
000076049b1d47b5  movaps [rsp], xmm10
000076049b1d47ba  movaps [rsp+0x10], xmm7
000076049b1d47bf  movaps [rsp+0x20], xmm13
000076049b1d47c5  lea rdi, [rsp]
000076049b1d47c9  mov esi, 0x00
000076049b1d47ce  mov rax, 0x64C06813C530
000076049b1d47d8  call rax
000076049b1d47da  movaps xmm10, [rsp]
000076049b1d47df  add rsp, 0x30
000076049b1d47e3  vmovaps xmm0, [rsp]
000076049b1d47e8  vmovaps xmm1, [rsp+0x10]
000076049b1d47ee  vmovaps xmm2, [rsp+0x20]
000076049b1d47f4  vmovaps xmm3, [rsp+0x30]
000076049b1d47fa  vmovaps xmm4, [rsp+0x40]
000076049b1d4800  vmovaps xmm5, [rsp+0x50]
000076049b1d4806  vmovaps xmm6, [rsp+0x60]
000076049b1d480c  vmovaps xmm7, [rsp+0x70]
000076049b1d4812  vmovaps xmm8, [rsp+0x80]
000076049b1d481b  vmovaps xmm9, [rsp+0x90]
000076049b1d4824  vmovaps xmm11, [rsp+0xA0]
000076049b1d482d  vmovaps xmm12, [rsp+0xB0]
000076049b1d4836  vmovaps xmm13, [rsp+0xC0]
000076049b1d483f  vmovaps xmm14, [rsp+0xD0]
000076049b1d4848  vmovaps xmm15, [rsp+0xE0]
000076049b1d4851  add rsp, 0xF0
000076049b1d4858  pop r11
000076049b1d485a  pop r10
000076049b1d485c  pop r9
000076049b1d485e  pop r8
000076049b1d4860  pop rsi
000076049b1d4861  pop rdi
000076049b1d4862  pop rdx
000076049b1d4863  pop rcx
000076049b1d4864  pop rax
000076049b1d4865  add rsp, 0x08
000076049b1d4869  jmp 0x000076049B1D0169
000076049b1d486e  sub rsp, 0x08
000076049b1d4872  push rax
000076049b1d4873  push rcx
000076049b1d4874  push rdx
000076049b1d4875  push rdi
000076049b1d4876  push rsi
000076049b1d4877  push r8
000076049b1d4879  push r9
000076049b1d487b  push r10
000076049b1d487d  push r11
000076049b1d487f  sub rsp, 0xF0
000076049b1d4886  vmovaps [rsp], xmm0
000076049b1d488b  vmovaps [rsp+0x10], xmm1
000076049b1d4891  vmovaps [rsp+0x20], xmm2
000076049b1d4897  vmovaps [rsp+0x30], xmm3
000076049b1d489d  vmovaps [rsp+0x40], xmm4
000076049b1d48a3  vmovaps [rsp+0x50], xmm5
000076049b1d48a9  vmovaps [rsp+0x60], xmm6
000076049b1d48af  vmovaps [rsp+0x70], xmm7
000076049b1d48b5  vmovaps [rsp+0x80], xmm8
000076049b1d48be  vmovaps [rsp+0x90], xmm9
000076049b1d48c7  vmovaps [rsp+0xA0], xmm10
000076049b1d48d0  vmovaps [rsp+0xB0], xmm11
000076049b1d48d9  vmovaps [rsp+0xC0], xmm12
000076049b1d48e2  vmovaps [rsp+0xD0], xmm14
000076049b1d48eb  vmovaps [rsp+0xE0], xmm15
000076049b1d48f4  sub rsp, 0x30
000076049b1d48f8  movaps [rsp], xmm13
000076049b1d48fd  movaps [rsp+0x10], xmm1
000076049b1d4902  movaps [rsp+0x20], xmm8
000076049b1d4908  lea rdi, [rsp]
000076049b1d490c  mov esi, 0x00
000076049b1d4911  mov rax, 0x64C06813C530
000076049b1d491b  call rax
000076049b1d491d  movaps xmm13, [rsp]
000076049b1d4922  add rsp, 0x30
000076049b1d4926  vmovaps xmm0, [rsp]
000076049b1d492b  vmovaps xmm1, [rsp+0x10]
000076049b1d4931  vmovaps xmm2, [rsp+0x20]
000076049b1d4937  vmovaps xmm3, [rsp+0x30]
000076049b1d493d  vmovaps xmm4, [rsp+0x40]
000076049b1d4943  vmovaps xmm5, [rsp+0x50]
000076049b1d4949  vmovaps xmm6, [rsp+0x60]
000076049b1d494f  vmovaps xmm7, [rsp+0x70]
000076049b1d4955  vmovaps xmm8, [rsp+0x80]
000076049b1d495e  vmovaps xmm9, [rsp+0x90]
000076049b1d4967  vmovaps xmm10, [rsp+0xA0]
000076049b1d4970  vmovaps xmm11, [rsp+0xB0]
000076049b1d4979  vmovaps xmm12, [rsp+0xC0]
000076049b1d4982  vmovaps xmm14, [rsp+0xD0]
000076049b1d498b  vmovaps xmm15, [rsp+0xE0]
000076049b1d4994  add rsp, 0xF0
000076049b1d499b  pop r11
000076049b1d499d  pop r10
000076049b1d499f  pop r9
000076049b1d49a1  pop r8
000076049b1d49a3  pop rsi
000076049b1d49a4  pop rdi
000076049b1d49a5  pop rdx
000076049b1d49a6  pop rcx
000076049b1d49a7  pop rax
000076049b1d49a8  add rsp, 0x08
000076049b1d49ac  jmp 0x000076049B1D0183
000076049b1d49b1  call 0x000076049AFFF430
000076049b1d49b6  jmp 0x000076049B1D018D
000076049b1d49bb  sub rsp, 0x08
000076049b1d49bf  push rax
000076049b1d49c0  push rcx
000076049b1d49c1  push rdx
000076049b1d49c2  push rdi
000076049b1d49c3  push rsi
000076049b1d49c4  push r8
000076049b1d49c6  push r9
000076049b1d49c8  push r10
000076049b1d49ca  push r11
000076049b1d49cc  sub rsp, 0xF0
000076049b1d49d3  vmovaps [rsp], xmm0
000076049b1d49d8  vmovaps [rsp+0x10], xmm1
000076049b1d49de  vmovaps [rsp+0x20], xmm2
000076049b1d49e4  vmovaps [rsp+0x30], xmm3
000076049b1d49ea  vmovaps [rsp+0x40], xmm4
000076049b1d49f0  vmovaps [rsp+0x50], xmm5
000076049b1d49f6  vmovaps [rsp+0x60], xmm6
000076049b1d49fc  vmovaps [rsp+0x70], xmm7
000076049b1d4a02  vmovaps [rsp+0x80], xmm9
000076049b1d4a0b  vmovaps [rsp+0x90], xmm10
000076049b1d4a14  vmovaps [rsp+0xA0], xmm11
000076049b1d4a1d  vmovaps [rsp+0xB0], xmm12
000076049b1d4a26  vmovaps [rsp+0xC0], xmm13
000076049b1d4a2f  vmovaps [rsp+0xD0], xmm14
000076049b1d4a38  vmovaps [rsp+0xE0], xmm15
000076049b1d4a41  sub rsp, 0x30
000076049b1d4a45  movaps [rsp], xmm8
000076049b1d4a4a  movaps [rsp+0x10], xmm14
000076049b1d4a50  movaps [rsp+0x20], xmm9
000076049b1d4a56  lea rdi, [rsp]
000076049b1d4a5a  mov esi, 0x00
000076049b1d4a5f  mov rax, 0x64C06813C530
000076049b1d4a69  call rax
000076049b1d4a6b  movaps xmm8, [rsp]
000076049b1d4a70  add rsp, 0x30
000076049b1d4a74  vmovaps xmm0, [rsp]
000076049b1d4a79  vmovaps xmm1, [rsp+0x10]
000076049b1d4a7f  vmovaps xmm2, [rsp+0x20]
000076049b1d4a85  vmovaps xmm3, [rsp+0x30]
000076049b1d4a8b  vmovaps xmm4, [rsp+0x40]
000076049b1d4a91  vmovaps xmm5, [rsp+0x50]
000076049b1d4a97  vmovaps xmm6, [rsp+0x60]
000076049b1d4a9d  vmovaps xmm7, [rsp+0x70]
000076049b1d4aa3  vmovaps xmm9, [rsp+0x80]
000076049b1d4aac  vmovaps xmm10, [rsp+0x90]
000076049b1d4ab5  vmovaps xmm11, [rsp+0xA0]
000076049b1d4abe  vmovaps xmm12, [rsp+0xB0]
000076049b1d4ac7  vmovaps xmm13, [rsp+0xC0]
000076049b1d4ad0  vmovaps xmm14, [rsp+0xD0]
000076049b1d4ad9  vmovaps xmm15, [rsp+0xE0]
000076049b1d4ae2  add rsp, 0xF0
000076049b1d4ae9  pop r11
000076049b1d4aeb  pop r10
000076049b1d4aed  pop r9
000076049b1d4aef  pop r8
000076049b1d4af1  pop rsi
000076049b1d4af2  pop rdi
000076049b1d4af3  pop rdx
000076049b1d4af4  pop rcx
000076049b1d4af5  pop rax
000076049b1d4af6  add rsp, 0x08
000076049b1d4afa  jmp 0x000076049B1D01AF
000076049b1d4aff  sub rsp, 0x08
000076049b1d4b03  push rax
000076049b1d4b04  push rcx
000076049b1d4b05  push rdx
000076049b1d4b06  push rdi
000076049b1d4b07  push rsi
000076049b1d4b08  push r8
000076049b1d4b0a  push r9
000076049b1d4b0c  push r10
000076049b1d4b0e  push r11
000076049b1d4b10  sub rsp, 0xF0
000076049b1d4b17  vmovaps [rsp], xmm0
000076049b1d4b1c  vmovaps [rsp+0x10], xmm1
000076049b1d4b22  vmovaps [rsp+0x20], xmm2
000076049b1d4b28  vmovaps [rsp+0x30], xmm3
000076049b1d4b2e  vmovaps [rsp+0x40], xmm4
000076049b1d4b34  vmovaps [rsp+0x50], xmm5
000076049b1d4b3a  vmovaps [rsp+0x60], xmm6
000076049b1d4b40  vmovaps [rsp+0x70], xmm7
000076049b1d4b46  vmovaps [rsp+0x80], xmm8
000076049b1d4b4f  vmovaps [rsp+0x90], xmm10
000076049b1d4b58  vmovaps [rsp+0xA0], xmm11
000076049b1d4b61  vmovaps [rsp+0xB0], xmm12
000076049b1d4b6a  vmovaps [rsp+0xC0], xmm13
000076049b1d4b73  vmovaps [rsp+0xD0], xmm14
000076049b1d4b7c  vmovaps [rsp+0xE0], xmm15
000076049b1d4b85  sub rsp, 0x30
000076049b1d4b89  movaps [rsp], xmm9
000076049b1d4b8e  movaps [rsp+0x10], xmm1
000076049b1d4b93  movaps [rsp+0x20], xmm14
000076049b1d4b99  lea rdi, [rsp]
000076049b1d4b9d  mov esi, 0x00
000076049b1d4ba2  mov rax, 0x64C06813C530
000076049b1d4bac  call rax
000076049b1d4bae  movaps xmm9, [rsp]
000076049b1d4bb3  add rsp, 0x30
000076049b1d4bb7  vmovaps xmm0, [rsp]
000076049b1d4bbc  vmovaps xmm1, [rsp+0x10]
000076049b1d4bc2  vmovaps xmm2, [rsp+0x20]
000076049b1d4bc8  vmovaps xmm3, [rsp+0x30]
000076049b1d4bce  vmovaps xmm4, [rsp+0x40]
000076049b1d4bd4  vmovaps xmm5, [rsp+0x50]
000076049b1d4bda  vmovaps xmm6, [rsp+0x60]
000076049b1d4be0  vmovaps xmm7, [rsp+0x70]
000076049b1d4be6  vmovaps xmm8, [rsp+0x80]
000076049b1d4bef  vmovaps xmm10, [rsp+0x90]
000076049b1d4bf8  vmovaps xmm11, [rsp+0xA0]
000076049b1d4c01  vmovaps xmm12, [rsp+0xB0]
000076049b1d4c0a  vmovaps xmm13, [rsp+0xC0]
000076049b1d4c13  vmovaps xmm14, [rsp+0xD0]
000076049b1d4c1c  vmovaps xmm15, [rsp+0xE0]
000076049b1d4c25  add rsp, 0xF0
000076049b1d4c2c  pop r11
000076049b1d4c2e  pop r10
000076049b1d4c30  pop r9
000076049b1d4c32  pop r8
000076049b1d4c34  pop rsi
000076049b1d4c35  pop rdi
000076049b1d4c36  pop rdx
000076049b1d4c37  pop rcx
000076049b1d4c38  pop rax
000076049b1d4c39  add rsp, 0x08
000076049b1d4c3d  jmp 0x000076049B1D01DD
000076049b1d4c42  sub rsp, 0x08
000076049b1d4c46  push rax
000076049b1d4c47  push rcx
000076049b1d4c48  push rdx
000076049b1d4c49  push rdi
000076049b1d4c4a  push rsi
000076049b1d4c4b  push r8
000076049b1d4c4d  push r9
000076049b1d4c4f  push r10
000076049b1d4c51  push r11
000076049b1d4c53  sub rsp, 0xF0
000076049b1d4c5a  vmovaps [rsp], xmm0
000076049b1d4c5f  vmovaps [rsp+0x10], xmm1
000076049b1d4c65  vmovaps [rsp+0x20], xmm2
000076049b1d4c6b  vmovaps [rsp+0x30], xmm3
000076049b1d4c71  vmovaps [rsp+0x40], xmm4
000076049b1d4c77  vmovaps [rsp+0x50], xmm5
000076049b1d4c7d  vmovaps [rsp+0x60], xmm6
000076049b1d4c83  vmovaps [rsp+0x70], xmm7
000076049b1d4c89  vmovaps [rsp+0x80], xmm8
000076049b1d4c92  vmovaps [rsp+0x90], xmm9
000076049b1d4c9b  vmovaps [rsp+0xA0], xmm10
000076049b1d4ca4  vmovaps [rsp+0xB0], xmm11
000076049b1d4cad  vmovaps [rsp+0xC0], xmm12
000076049b1d4cb6  vmovaps [rsp+0xD0], xmm13
000076049b1d4cbf  vmovaps [rsp+0xE0], xmm15
000076049b1d4cc8  sub rsp, 0x30
000076049b1d4ccc  movaps [rsp], xmm14
000076049b1d4cd1  movaps [rsp+0x10], xmm4
000076049b1d4cd6  movaps [rsp+0x20], xmm1
000076049b1d4cdb  lea rdi, [rsp]
000076049b1d4cdf  mov esi, 0x00
000076049b1d4ce4  mov rax, 0x64C06813C530
000076049b1d4cee  call rax
000076049b1d4cf0  movaps xmm14, [rsp]
000076049b1d4cf5  add rsp, 0x30
000076049b1d4cf9  vmovaps xmm0, [rsp]
000076049b1d4cfe  vmovaps xmm1, [rsp+0x10]
000076049b1d4d04  vmovaps xmm2, [rsp+0x20]
000076049b1d4d0a  vmovaps xmm3, [rsp+0x30]
000076049b1d4d10  vmovaps xmm4, [rsp+0x40]
000076049b1d4d16  vmovaps xmm5, [rsp+0x50]
000076049b1d4d1c  vmovaps xmm6, [rsp+0x60]
000076049b1d4d22  vmovaps xmm7, [rsp+0x70]
000076049b1d4d28  vmovaps xmm8, [rsp+0x80]
000076049b1d4d31  vmovaps xmm9, [rsp+0x90]
000076049b1d4d3a  vmovaps xmm10, [rsp+0xA0]
000076049b1d4d43  vmovaps xmm11, [rsp+0xB0]
000076049b1d4d4c  vmovaps xmm12, [rsp+0xC0]
000076049b1d4d55  vmovaps xmm13, [rsp+0xD0]
000076049b1d4d5e  vmovaps xmm15, [rsp+0xE0]
000076049b1d4d67  add rsp, 0xF0
000076049b1d4d6e  pop r11
000076049b1d4d70  pop r10
000076049b1d4d72  pop r9
000076049b1d4d74  pop r8
000076049b1d4d76  pop rsi
000076049b1d4d77  pop rdi
000076049b1d4d78  pop rdx
000076049b1d4d79  pop rcx
000076049b1d4d7a  pop rax
000076049b1d4d7b  add rsp, 0x08
000076049b1d4d7f  jmp 0x000076049B1D0203
000076049b1d4d84  sub rsp, 0x08
000076049b1d4d88  push rax
000076049b1d4d89  push rcx
000076049b1d4d8a  push rdx
000076049b1d4d8b  push rdi
000076049b1d4d8c  push rsi
000076049b1d4d8d  push r8
000076049b1d4d8f  push r9
000076049b1d4d91  push r10
000076049b1d4d93  push r11
000076049b1d4d95  sub rsp, 0xF0
000076049b1d4d9c  vmovaps [rsp], xmm0
000076049b1d4da1  vmovaps [rsp+0x10], xmm2
000076049b1d4da7  vmovaps [rsp+0x20], xmm3
000076049b1d4dad  vmovaps [rsp+0x30], xmm4
000076049b1d4db3  vmovaps [rsp+0x40], xmm5
000076049b1d4db9  vmovaps [rsp+0x50], xmm6
000076049b1d4dbf  vmovaps [rsp+0x60], xmm7
000076049b1d4dc5  vmovaps [rsp+0x70], xmm8
000076049b1d4dcb  vmovaps [rsp+0x80], xmm9
000076049b1d4dd4  vmovaps [rsp+0x90], xmm10
000076049b1d4ddd  vmovaps [rsp+0xA0], xmm11
000076049b1d4de6  vmovaps [rsp+0xB0], xmm12
000076049b1d4def  vmovaps [rsp+0xC0], xmm13
000076049b1d4df8  vmovaps [rsp+0xD0], xmm14
000076049b1d4e01  vmovaps [rsp+0xE0], xmm15
000076049b1d4e0a  sub rsp, 0x30
000076049b1d4e0e  movaps [rsp], xmm1
000076049b1d4e12  movaps [rsp+0x10], xmm12
000076049b1d4e18  movaps [rsp+0x20], xmm11
000076049b1d4e1e  lea rdi, [rsp]
000076049b1d4e22  mov esi, 0x00
000076049b1d4e27  mov rax, 0x64C06813C530
000076049b1d4e31  call rax
000076049b1d4e33  movaps xmm1, [rsp]
000076049b1d4e37  add rsp, 0x30
000076049b1d4e3b  vmovaps xmm0, [rsp]
000076049b1d4e40  vmovaps xmm2, [rsp+0x10]
000076049b1d4e46  vmovaps xmm3, [rsp+0x20]
000076049b1d4e4c  vmovaps xmm4, [rsp+0x30]
000076049b1d4e52  vmovaps xmm5, [rsp+0x40]
000076049b1d4e58  vmovaps xmm6, [rsp+0x50]
000076049b1d4e5e  vmovaps xmm7, [rsp+0x60]
000076049b1d4e64  vmovaps xmm8, [rsp+0x70]
000076049b1d4e6a  vmovaps xmm9, [rsp+0x80]
000076049b1d4e73  vmovaps xmm10, [rsp+0x90]
000076049b1d4e7c  vmovaps xmm11, [rsp+0xA0]
000076049b1d4e85  vmovaps xmm12, [rsp+0xB0]
000076049b1d4e8e  vmovaps xmm13, [rsp+0xC0]
000076049b1d4e97  vmovaps xmm14, [rsp+0xD0]
000076049b1d4ea0  vmovaps xmm15, [rsp+0xE0]
000076049b1d4ea9  add rsp, 0xF0
000076049b1d4eb0  pop r11
000076049b1d4eb2  pop r10
000076049b1d4eb4  pop r9
000076049b1d4eb6  pop r8
000076049b1d4eb8  pop rsi
000076049b1d4eb9  pop rdi
000076049b1d4eba  pop rdx
000076049b1d4ebb  pop rcx
000076049b1d4ebc  pop rax
000076049b1d4ebd  add rsp, 0x08
000076049b1d4ec1  jmp 0x000076049B1D0224
000076049b1d4ec6  call 0x000076049B0E20A0
000076049b1d4ecb  jmp 0x000076049B1D0232
000076049b1d4ed0  call 0x000076049B009D70
000076049b1d4ed5  jmp 0x000076049B1D023C
000076049b1d4eda  sub rsp, 0x08
000076049b1d4ede  push rax
000076049b1d4edf  push rcx
000076049b1d4ee0  push rdx
000076049b1d4ee1  push rdi
000076049b1d4ee2  push rsi
000076049b1d4ee3  push r8
000076049b1d4ee5  push r9
000076049b1d4ee7  push r10
000076049b1d4ee9  push r11
000076049b1d4eeb  sub rsp, 0xF0
000076049b1d4ef2  vmovaps [rsp], xmm0
000076049b1d4ef7  vmovaps [rsp+0x10], xmm1
000076049b1d4efd  vmovaps [rsp+0x20], xmm2
000076049b1d4f03  vmovaps [rsp+0x30], xmm3
000076049b1d4f09  vmovaps [rsp+0x40], xmm4
000076049b1d4f0f  vmovaps [rsp+0x50], xmm5
000076049b1d4f15  vmovaps [rsp+0x60], xmm6
000076049b1d4f1b  vmovaps [rsp+0x70], xmm8
000076049b1d4f21  vmovaps [rsp+0x80], xmm9
000076049b1d4f2a  vmovaps [rsp+0x90], xmm10
000076049b1d4f33  vmovaps [rsp+0xA0], xmm11
000076049b1d4f3c  vmovaps [rsp+0xB0], xmm12
000076049b1d4f45  vmovaps [rsp+0xC0], xmm13
000076049b1d4f4e  vmovaps [rsp+0xD0], xmm14
000076049b1d4f57  vmovaps [rsp+0xE0], xmm15
000076049b1d4f60  sub rsp, 0x30
000076049b1d4f64  movaps [rsp], xmm7
000076049b1d4f68  movaps [rsp+0x10], xmm15
000076049b1d4f6e  movaps [rsp+0x20], xmm10
000076049b1d4f74  lea rdi, [rsp]
000076049b1d4f78  mov esi, 0x00
000076049b1d4f7d  mov rax, 0x64C06813C530
000076049b1d4f87  call rax
000076049b1d4f89  movaps xmm7, [rsp]
000076049b1d4f8d  add rsp, 0x30
000076049b1d4f91  vmovaps xmm0, [rsp]
000076049b1d4f96  vmovaps xmm1, [rsp+0x10]
000076049b1d4f9c  vmovaps xmm2, [rsp+0x20]
000076049b1d4fa2  vmovaps xmm3, [rsp+0x30]
000076049b1d4fa8  vmovaps xmm4, [rsp+0x40]
000076049b1d4fae  vmovaps xmm5, [rsp+0x50]
000076049b1d4fb4  vmovaps xmm6, [rsp+0x60]
000076049b1d4fba  vmovaps xmm8, [rsp+0x70]
000076049b1d4fc0  vmovaps xmm9, [rsp+0x80]
000076049b1d4fc9  vmovaps xmm10, [rsp+0x90]
000076049b1d4fd2  vmovaps xmm11, [rsp+0xA0]
000076049b1d4fdb  vmovaps xmm12, [rsp+0xB0]
000076049b1d4fe4  vmovaps xmm13, [rsp+0xC0]
000076049b1d4fed  vmovaps xmm14, [rsp+0xD0]
000076049b1d4ff6  vmovaps xmm15, [rsp+0xE0]
000076049b1d4fff  add rsp, 0xF0
000076049b1d5006  pop r11
000076049b1d5008  pop r10
000076049b1d500a  pop r9
000076049b1d500c  pop r8
000076049b1d500e  pop rsi
000076049b1d500f  pop rdi
000076049b1d5010  pop rdx
000076049b1d5011  pop rcx
000076049b1d5012  pop rax
000076049b1d5013  add rsp, 0x08
000076049b1d5017  jmp 0x000076049B1D025D
000076049b1d501c  sub rsp, 0x08
000076049b1d5020  push rax
000076049b1d5021  push rcx
000076049b1d5022  push rdx
000076049b1d5023  push rdi
000076049b1d5024  push rsi
000076049b1d5025  push r8
000076049b1d5027  push r9
000076049b1d5029  push r10
000076049b1d502b  push r11
000076049b1d502d  sub rsp, 0xF0
000076049b1d5034  vmovaps [rsp], xmm0
000076049b1d5039  vmovaps [rsp+0x10], xmm1
000076049b1d503f  vmovaps [rsp+0x20], xmm2
000076049b1d5045  vmovaps [rsp+0x30], xmm3
000076049b1d504b  vmovaps [rsp+0x40], xmm4
000076049b1d5051  vmovaps [rsp+0x50], xmm5
000076049b1d5057  vmovaps [rsp+0x60], xmm6
000076049b1d505d  vmovaps [rsp+0x70], xmm7
000076049b1d5063  vmovaps [rsp+0x80], xmm8
000076049b1d506c  vmovaps [rsp+0x90], xmm9
000076049b1d5075  vmovaps [rsp+0xA0], xmm11
000076049b1d507e  vmovaps [rsp+0xB0], xmm12
000076049b1d5087  vmovaps [rsp+0xC0], xmm13
000076049b1d5090  vmovaps [rsp+0xD0], xmm14
000076049b1d5099  vmovaps [rsp+0xE0], xmm15
000076049b1d50a2  sub rsp, 0x30
000076049b1d50a6  movaps [rsp], xmm10
000076049b1d50ab  movaps [rsp+0x10], xmm11
000076049b1d50b1  movaps [rsp+0x20], xmm15
000076049b1d50b7  lea rdi, [rsp]
000076049b1d50bb  mov esi, 0x00
000076049b1d50c0  mov rax, 0x64C06813C530
000076049b1d50ca  call rax
000076049b1d50cc  movaps xmm10, [rsp]
000076049b1d50d1  add rsp, 0x30
000076049b1d50d5  vmovaps xmm0, [rsp]
000076049b1d50da  vmovaps xmm1, [rsp+0x10]
000076049b1d50e0  vmovaps xmm2, [rsp+0x20]
000076049b1d50e6  vmovaps xmm3, [rsp+0x30]
000076049b1d50ec  vmovaps xmm4, [rsp+0x40]
000076049b1d50f2  vmovaps xmm5, [rsp+0x50]
000076049b1d50f8  vmovaps xmm6, [rsp+0x60]
000076049b1d50fe  vmovaps xmm7, [rsp+0x70]
000076049b1d5104  vmovaps xmm8, [rsp+0x80]
000076049b1d510d  vmovaps xmm9, [rsp+0x90]
000076049b1d5116  vmovaps xmm11, [rsp+0xA0]
000076049b1d511f  vmovaps xmm12, [rsp+0xB0]
000076049b1d5128  vmovaps xmm13, [rsp+0xC0]
000076049b1d5131  vmovaps xmm14, [rsp+0xD0]
000076049b1d513a  vmovaps xmm15, [rsp+0xE0]
000076049b1d5143  add rsp, 0xF0
000076049b1d514a  pop r11
000076049b1d514c  pop r10
000076049b1d514e  pop r9
000076049b1d5150  pop r8
000076049b1d5152  pop rsi
000076049b1d5153  pop rdi
000076049b1d5154  pop rdx
000076049b1d5155  pop rcx
000076049b1d5156  pop rax
000076049b1d5157  add rsp, 0x08
000076049b1d515b  jmp 0x000076049B1D028B
000076049b1d5160  sub rsp, 0x08
000076049b1d5164  push rax
000076049b1d5165  push rcx
000076049b1d5166  push rdx
000076049b1d5167  push rdi
000076049b1d5168  push rsi
000076049b1d5169  push r8
000076049b1d516b  push r9
000076049b1d516d  push r10
000076049b1d516f  push r11
000076049b1d5171  sub rsp, 0xF0
000076049b1d5178  vmovaps [rsp], xmm0
000076049b1d517d  vmovaps [rsp+0x10], xmm1
000076049b1d5183  vmovaps [rsp+0x20], xmm2
000076049b1d5189  vmovaps [rsp+0x30], xmm3
000076049b1d518f  vmovaps [rsp+0x40], xmm4
000076049b1d5195  vmovaps [rsp+0x50], xmm5
000076049b1d519b  vmovaps [rsp+0x60], xmm6
000076049b1d51a1  vmovaps [rsp+0x70], xmm7
000076049b1d51a7  vmovaps [rsp+0x80], xmm8
000076049b1d51b0  vmovaps [rsp+0x90], xmm9
000076049b1d51b9  vmovaps [rsp+0xA0], xmm10
000076049b1d51c2  vmovaps [rsp+0xB0], xmm12
000076049b1d51cb  vmovaps [rsp+0xC0], xmm13
000076049b1d51d4  vmovaps [rsp+0xD0], xmm14
000076049b1d51dd  vmovaps [rsp+0xE0], xmm15
000076049b1d51e6  sub rsp, 0x30
000076049b1d51ea  movaps [rsp], xmm11
000076049b1d51ef  movaps [rsp+0x10], xmm12
000076049b1d51f5  movaps [rsp+0x20], xmm15
000076049b1d51fb  lea rdi, [rsp]
000076049b1d51ff  mov esi, 0x00
000076049b1d5204  mov rax, 0x64C06813C530
000076049b1d520e  call rax
000076049b1d5210  movaps xmm11, [rsp]
000076049b1d5215  add rsp, 0x30
000076049b1d5219  vmovaps xmm0, [rsp]
000076049b1d521e  vmovaps xmm1, [rsp+0x10]
000076049b1d5224  vmovaps xmm2, [rsp+0x20]
000076049b1d522a  vmovaps xmm3, [rsp+0x30]
000076049b1d5230  vmovaps xmm4, [rsp+0x40]
000076049b1d5236  vmovaps xmm5, [rsp+0x50]
000076049b1d523c  vmovaps xmm6, [rsp+0x60]
000076049b1d5242  vmovaps xmm7, [rsp+0x70]
000076049b1d5248  vmovaps xmm8, [rsp+0x80]
000076049b1d5251  vmovaps xmm9, [rsp+0x90]
000076049b1d525a  vmovaps xmm10, [rsp+0xA0]
000076049b1d5263  vmovaps xmm12, [rsp+0xB0]
000076049b1d526c  vmovaps xmm13, [rsp+0xC0]
000076049b1d5275  vmovaps xmm14, [rsp+0xD0]
000076049b1d527e  vmovaps xmm15, [rsp+0xE0]
000076049b1d5287  add rsp, 0xF0
000076049b1d528e  pop r11
000076049b1d5290  pop r10
000076049b1d5292  pop r9
000076049b1d5294  pop r8
000076049b1d5296  pop rsi
000076049b1d5297  pop rdi
000076049b1d5298  pop rdx
000076049b1d5299  pop rcx
000076049b1d529a  pop rax
000076049b1d529b  add rsp, 0x08
000076049b1d529f  jmp 0x000076049B1D02B9
000076049b1d52a4  sub rsp, 0x08
000076049b1d52a8  push rax
000076049b1d52a9  push rcx
000076049b1d52aa  push rdx
000076049b1d52ab  push rdi
000076049b1d52ac  push rsi
000076049b1d52ad  push r8
000076049b1d52af  push r9
000076049b1d52b1  push r10
000076049b1d52b3  push r11
000076049b1d52b5  sub rsp, 0xF0
000076049b1d52bc  vmovaps [rsp], xmm0
000076049b1d52c1  vmovaps [rsp+0x10], xmm1
000076049b1d52c7  vmovaps [rsp+0x20], xmm2
000076049b1d52cd  vmovaps [rsp+0x30], xmm3
000076049b1d52d3  vmovaps [rsp+0x40], xmm4
000076049b1d52d9  vmovaps [rsp+0x50], xmm5
000076049b1d52df  vmovaps [rsp+0x60], xmm6
000076049b1d52e5  vmovaps [rsp+0x70], xmm7
000076049b1d52eb  vmovaps [rsp+0x80], xmm8
000076049b1d52f4  vmovaps [rsp+0x90], xmm9
000076049b1d52fd  vmovaps [rsp+0xA0], xmm10
000076049b1d5306  vmovaps [rsp+0xB0], xmm11
000076049b1d530f  vmovaps [rsp+0xC0], xmm12
000076049b1d5318  vmovaps [rsp+0xD0], xmm13
000076049b1d5321  vmovaps [rsp+0xE0], xmm14
000076049b1d532a  sub rsp, 0x30
000076049b1d532e  movaps [rsp], xmm15
000076049b1d5333  movaps [rsp+0x10], xmm13
000076049b1d5339  movaps [rsp+0x20], xmm9
000076049b1d533f  lea rdi, [rsp]
000076049b1d5343  mov esi, 0x00
000076049b1d5348  mov rax, 0x64C06813C530
000076049b1d5352  call rax
000076049b1d5354  movaps xmm15, [rsp]
000076049b1d5359  add rsp, 0x30
000076049b1d535d  vmovaps xmm0, [rsp]
000076049b1d5362  vmovaps xmm1, [rsp+0x10]
000076049b1d5368  vmovaps xmm2, [rsp+0x20]
000076049b1d536e  vmovaps xmm3, [rsp+0x30]
000076049b1d5374  vmovaps xmm4, [rsp+0x40]
000076049b1d537a  vmovaps xmm5, [rsp+0x50]
000076049b1d5380  vmovaps xmm6, [rsp+0x60]
000076049b1d5386  vmovaps xmm7, [rsp+0x70]
000076049b1d538c  vmovaps xmm8, [rsp+0x80]
000076049b1d5395  vmovaps xmm9, [rsp+0x90]
000076049b1d539e  vmovaps xmm10, [rsp+0xA0]
000076049b1d53a7  vmovaps xmm11, [rsp+0xB0]
000076049b1d53b0  vmovaps xmm12, [rsp+0xC0]
000076049b1d53b9  vmovaps xmm13, [rsp+0xD0]
000076049b1d53c2  vmovaps xmm14, [rsp+0xE0]
000076049b1d53cb  add rsp, 0xF0
000076049b1d53d2  pop r11
000076049b1d53d4  pop r10
000076049b1d53d6  pop r9
000076049b1d53d8  pop r8
000076049b1d53da  pop rsi
000076049b1d53db  pop rdi
000076049b1d53dc  pop rdx
000076049b1d53dd  pop rcx
000076049b1d53de  pop rax
000076049b1d53df  add rsp, 0x08
000076049b1d53e3  jmp 0x000076049B1D02D4
000076049b1d53e8  sub rsp, 0x08
000076049b1d53ec  push rax
000076049b1d53ed  push rcx
000076049b1d53ee  push rdx
000076049b1d53ef  push rdi
000076049b1d53f0  push rsi
000076049b1d53f1  push r8
000076049b1d53f3  push r9
000076049b1d53f5  push r10
000076049b1d53f7  push r11
000076049b1d53f9  sub rsp, 0xF0
000076049b1d5400  vmovaps [rsp], xmm0
000076049b1d5405  vmovaps [rsp+0x10], xmm1
000076049b1d540b  vmovaps [rsp+0x20], xmm2
000076049b1d5411  vmovaps [rsp+0x30], xmm3
000076049b1d5417  vmovaps [rsp+0x40], xmm4
000076049b1d541d  vmovaps [rsp+0x50], xmm5
000076049b1d5423  vmovaps [rsp+0x60], xmm6
000076049b1d5429  vmovaps [rsp+0x70], xmm7
000076049b1d542f  vmovaps [rsp+0x80], xmm8
000076049b1d5438  vmovaps [rsp+0x90], xmm9
000076049b1d5441  vmovaps [rsp+0xA0], xmm10
000076049b1d544a  vmovaps [rsp+0xB0], xmm11
000076049b1d5453  vmovaps [rsp+0xC0], xmm12
000076049b1d545c  vmovaps [rsp+0xD0], xmm14
000076049b1d5465  vmovaps [rsp+0xE0], xmm15
000076049b1d546e  sub rsp, 0x30
000076049b1d5472  movaps [rsp], xmm13
000076049b1d5477  movaps [rsp+0x10], xmm8
000076049b1d547d  movaps [rsp+0x20], xmm14
000076049b1d5483  lea rdi, [rsp]
000076049b1d5487  mov esi, 0x00
000076049b1d548c  mov rax, 0x64C06813C530
000076049b1d5496  call rax
000076049b1d5498  movaps xmm13, [rsp]
000076049b1d549d  add rsp, 0x30
000076049b1d54a1  vmovaps xmm0, [rsp]
000076049b1d54a6  vmovaps xmm1, [rsp+0x10]
000076049b1d54ac  vmovaps xmm2, [rsp+0x20]
000076049b1d54b2  vmovaps xmm3, [rsp+0x30]
000076049b1d54b8  vmovaps xmm4, [rsp+0x40]
000076049b1d54be  vmovaps xmm5, [rsp+0x50]
000076049b1d54c4  vmovaps xmm6, [rsp+0x60]
000076049b1d54ca  vmovaps xmm7, [rsp+0x70]
000076049b1d54d0  vmovaps xmm8, [rsp+0x80]
000076049b1d54d9  vmovaps xmm9, [rsp+0x90]
000076049b1d54e2  vmovaps xmm10, [rsp+0xA0]
000076049b1d54eb  vmovaps xmm11, [rsp+0xB0]
000076049b1d54f4  vmovaps xmm12, [rsp+0xC0]
000076049b1d54fd  vmovaps xmm14, [rsp+0xD0]
000076049b1d5506  vmovaps xmm15, [rsp+0xE0]
000076049b1d550f  add rsp, 0xF0
000076049b1d5516  pop r11
000076049b1d5518  pop r10
000076049b1d551a  pop r9
000076049b1d551c  pop r8
000076049b1d551e  pop rsi
000076049b1d551f  pop rdi
000076049b1d5520  pop rdx
000076049b1d5521  pop rcx
000076049b1d5522  pop rax
000076049b1d5523  add rsp, 0x08
000076049b1d5527  jmp 0x000076049B1D02F7
000076049b1d552c  sub rsp, 0x08
000076049b1d5530  push rax
000076049b1d5531  push rcx
000076049b1d5532  push rdx
000076049b1d5533  push rdi
000076049b1d5534  push rsi
000076049b1d5535  push r8
000076049b1d5537  push r9
000076049b1d5539  push r10
000076049b1d553b  push r11
000076049b1d553d  sub rsp, 0xF0
000076049b1d5544  vmovaps [rsp], xmm0
000076049b1d5549  vmovaps [rsp+0x10], xmm1
000076049b1d554f  vmovaps [rsp+0x20], xmm2
000076049b1d5555  vmovaps [rsp+0x30], xmm3
000076049b1d555b  vmovaps [rsp+0x40], xmm4
000076049b1d5561  vmovaps [rsp+0x50], xmm5
000076049b1d5567  vmovaps [rsp+0x60], xmm6
000076049b1d556d  vmovaps [rsp+0x70], xmm7
000076049b1d5573  vmovaps [rsp+0x80], xmm8
000076049b1d557c  vmovaps [rsp+0x90], xmm9
000076049b1d5585  vmovaps [rsp+0xA0], xmm10
000076049b1d558e  vmovaps [rsp+0xB0], xmm11
000076049b1d5597  vmovaps [rsp+0xC0], xmm12
000076049b1d55a0  vmovaps [rsp+0xD0], xmm13
000076049b1d55a9  vmovaps [rsp+0xE0], xmm15
000076049b1d55b2  sub rsp, 0x30
000076049b1d55b6  movaps [rsp], xmm14
000076049b1d55bb  movaps [rsp+0x10], xmm1
000076049b1d55c0  movaps [rsp+0x20], xmm10
000076049b1d55c6  lea rdi, [rsp]
000076049b1d55ca  mov esi, 0x00
000076049b1d55cf  mov rax, 0x64C06813C530
000076049b1d55d9  call rax
000076049b1d55db  movaps xmm14, [rsp]
000076049b1d55e0  add rsp, 0x30
000076049b1d55e4  vmovaps xmm0, [rsp]
000076049b1d55e9  vmovaps xmm1, [rsp+0x10]
000076049b1d55ef  vmovaps xmm2, [rsp+0x20]
000076049b1d55f5  vmovaps xmm3, [rsp+0x30]
000076049b1d55fb  vmovaps xmm4, [rsp+0x40]
000076049b1d5601  vmovaps xmm5, [rsp+0x50]
000076049b1d5607  vmovaps xmm6, [rsp+0x60]
000076049b1d560d  vmovaps xmm7, [rsp+0x70]
000076049b1d5613  vmovaps xmm8, [rsp+0x80]
000076049b1d561c  vmovaps xmm9, [rsp+0x90]
000076049b1d5625  vmovaps xmm10, [rsp+0xA0]
000076049b1d562e  vmovaps xmm11, [rsp+0xB0]
000076049b1d5637  vmovaps xmm12, [rsp+0xC0]
000076049b1d5640  vmovaps xmm13, [rsp+0xD0]
000076049b1d5649  vmovaps xmm15, [rsp+0xE0]
000076049b1d5652  add rsp, 0xF0
000076049b1d5659  pop r11
000076049b1d565b  pop r10
000076049b1d565d  pop r9
000076049b1d565f  pop r8
000076049b1d5661  pop rsi
000076049b1d5662  pop rdi
000076049b1d5663  pop rdx
000076049b1d5664  pop rcx
000076049b1d5665  pop rax
000076049b1d5666  add rsp, 0x08
000076049b1d566a  jmp 0x000076049B1D031A
000076049b1d566f  sub rsp, 0x08
000076049b1d5673  push rax
000076049b1d5674  push rcx
000076049b1d5675  push rdx
000076049b1d5676  push rdi
000076049b1d5677  push rsi
000076049b1d5678  push r8
000076049b1d567a  push r9
000076049b1d567c  push r10
000076049b1d567e  push r11
000076049b1d5680  sub rsp, 0xF0
000076049b1d5687  vmovaps [rsp], xmm0
000076049b1d568c  vmovaps [rsp+0x10], xmm2
000076049b1d5692  vmovaps [rsp+0x20], xmm3
000076049b1d5698  vmovaps [rsp+0x30], xmm4
000076049b1d569e  vmovaps [rsp+0x40], xmm5
000076049b1d56a4  vmovaps [rsp+0x50], xmm6
000076049b1d56aa  vmovaps [rsp+0x60], xmm7
000076049b1d56b0  vmovaps [rsp+0x70], xmm8
000076049b1d56b6  vmovaps [rsp+0x80], xmm9
000076049b1d56bf  vmovaps [rsp+0x90], xmm10
000076049b1d56c8  vmovaps [rsp+0xA0], xmm11
000076049b1d56d1  vmovaps [rsp+0xB0], xmm12
000076049b1d56da  vmovaps [rsp+0xC0], xmm13
000076049b1d56e3  vmovaps [rsp+0xD0], xmm14
000076049b1d56ec  vmovaps [rsp+0xE0], xmm15
000076049b1d56f5  sub rsp, 0x30
000076049b1d56f9  movaps [rsp], xmm1
000076049b1d56fd  movaps [rsp+0x10], xmm7
000076049b1d5702  movaps [rsp+0x20], xmm11
000076049b1d5708  lea rdi, [rsp]
000076049b1d570c  mov esi, 0x00
000076049b1d5711  mov rax, 0x64C06813C530
000076049b1d571b  call rax
000076049b1d571d  movaps xmm1, [rsp]
000076049b1d5721  add rsp, 0x30
000076049b1d5725  vmovaps xmm0, [rsp]
000076049b1d572a  vmovaps xmm2, [rsp+0x10]
000076049b1d5730  vmovaps xmm3, [rsp+0x20]
000076049b1d5736  vmovaps xmm4, [rsp+0x30]
000076049b1d573c  vmovaps xmm5, [rsp+0x40]
000076049b1d5742  vmovaps xmm6, [rsp+0x50]
000076049b1d5748  vmovaps xmm7, [rsp+0x60]
000076049b1d574e  vmovaps xmm8, [rsp+0x70]
000076049b1d5754  vmovaps xmm9, [rsp+0x80]
000076049b1d575d  vmovaps xmm10, [rsp+0x90]
000076049b1d5766  vmovaps xmm11, [rsp+0xA0]
000076049b1d576f  vmovaps xmm12, [rsp+0xB0]
000076049b1d5778  vmovaps xmm13, [rsp+0xC0]
000076049b1d5781  vmovaps xmm14, [rsp+0xD0]
000076049b1d578a  vmovaps xmm15, [rsp+0xE0]
000076049b1d5793  add rsp, 0xF0
000076049b1d579a  pop r11
000076049b1d579c  pop r10
000076049b1d579e  pop r9
000076049b1d57a0  pop r8
000076049b1d57a2  pop rsi
000076049b1d57a3  pop rdi
000076049b1d57a4  pop rdx
000076049b1d57a5  pop rcx
000076049b1d57a6  pop rax
000076049b1d57a7  add rsp, 0x08
000076049b1d57ab  jmp 0x000076049B1D033B
000076049b1d57b0  call 0x000076049B00E880
000076049b1d57b5  jmp 0x000076049B1D034E
000076049b1d57ba  call 0x000076049B00C380
000076049b1d57bf  jmp 0x000076049B1D0359
000076049b1d57c4  call 0x000076049B00D600
000076049b1d57c9  jmp 0x000076049B1D0364
000076049b1d57ce  call 0x000076049AFFF540
000076049b1d57d3  jmp 0x000076049B1D036F
000076049b1d57d8  int3
000076049b1d57d9  nop [rax], eax
000076049b1d57e0  mov rax, [r15+0x40]
000076049b1d57e4  mov r14, [r15+0x58]
000076049b1d57e8  lea r12, [rax+r14*1]
000076049b1d57ec  movaps xmm1, [r15+0x1D0]
000076049b1d57f4  vmovaps [rsp+0x10], xmm1
000076049b1d57fa  vmovaps xmm15, [rsp+0x10]
000076049b1d5800  por xmm1, xmm15
000076049b1d5805  movaps xmm14, [r15+0x1A0]
000076049b1d580d  vmovaps [rsp+0x10], xmm14
000076049b1d5813  vmovaps xmm13, [rsp+0x10]
000076049b1d5819  por xmm14, xmm13
000076049b1d581e  lea rax, [r12+0x30]
000076049b1d5823  mov r11, [r13+rax*1]
000076049b1d5828  lea rax, [r12+0x38]
000076049b1d582d  mov r10, [r13+rax*1]
000076049b1d5832  movq xmm13, r11
000076049b1d5837  movq xmm12, r10
000076049b1d583c  movq xmm13, xmm13
000076049b1d5841  vmovaps [rsp+0x10], xmm13
000076049b1d5847  movq xmm13, xmm13
000076049b1d584c  movaps [r15+0x130], xmm13
000076049b1d5854  movq xmm12, xmm12
000076049b1d5859  vmovaps [rsp+0x20], xmm12
000076049b1d585f  movq xmm12, xmm12
000076049b1d5864  movaps [r15+0x280], xmm12
000076049b1d586c  movaps xmm13, [r15+0x270]
000076049b1d5874  vmovaps [rsp+0x30], xmm13
000076049b1d587a  vmovaps xmm12, [rsp+0x30]
000076049b1d5880  por xmm13, xmm12
000076049b1d5885  lea rax, [r12+0x20]
000076049b1d588a  mov r11, [r13+rax*1]
000076049b1d588f  lea rax, [r12+0x28]
000076049b1d5894  mov r10, [r13+rax*1]
000076049b1d5899  movq xmm12, r11
000076049b1d589e  movq xmm11, r10
000076049b1d58a3  movq xmm12, xmm12
000076049b1d58a8  vmovaps [rsp+0x30], xmm12
000076049b1d58ae  movq xmm12, xmm12
000076049b1d58b3  movaps [r15+0x150], xmm12
000076049b1d58bb  movq xmm11, xmm11
000076049b1d58c0  vmovaps [rsp+0x40], xmm11
000076049b1d58c6  movq xmm11, xmm11
000076049b1d58cb  movaps [r15+0x140], xmm11
000076049b1d58d3  lea rax, [r12+0x10]
000076049b1d58d8  mov r11, [r13+rax*1]
000076049b1d58dd  lea rax, [r12+0x18]
000076049b1d58e2  mov r10, [r13+rax*1]
000076049b1d58e7  movq xmm12, r11
000076049b1d58ec  movq xmm11, r10
000076049b1d58f1  movq xmm12, xmm12
000076049b1d58f6  vmovaps [rsp+0x50], xmm12
000076049b1d58fc  movq xmm12, xmm12
000076049b1d5901  movaps [r15+0x170], xmm12
000076049b1d5909  movq xmm11, xmm11
000076049b1d590e  vmovaps [rsp+0x60], xmm11
000076049b1d5914  movq xmm11, xmm11
000076049b1d5919  movaps [r15+0x160], xmm11
000076049b1d5921  mov rax, [r13+r12*1]
000076049b1d5926  vmovq xmm12, rax
000076049b1d592b  vpbroadcastq xmm12, xmm12
000076049b1d5930  lea rax, [r12+0x08]
000076049b1d5935  mov r12, [r13+rax*1]
000076049b1d593a  movq xmm11, r12
000076049b1d593f  movaps [r15+0x230], xmm11
000076049b1d5947  mov rax, [r15+0xF8]
000076049b1d594e  lea r12, [rax+0x50]
000076049b1d5952  movups xmm11, [r13+r12*1]
000076049b1d5958  lea r12, [rax+0x60]
000076049b1d595c  movups xmm10, [r13+r12*1]
000076049b1d5962  lea r12, [rax+0x30]
000076049b1d5966  movups xmm9, [r13+r12*1]
000076049b1d596c  mov r12, [r15+0x50]
000076049b1d5970  lea r11, [r12+r14*1]
000076049b1d5974  mov [r15+0x60], r11
000076049b1d5978  lea r12, [r14+0x40]
000076049b1d597c  mov [r15+0x58], r12
000076049b1d5980  movaps xmm8, xmm12
000076049b1d5984  mulpd xmm8, xmm15
000076049b1d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000076049b1d598f  ptest xmm7, xmm7
000076049b1d5994  jnz 0x000076049B1D67B7
000076049b1d599a  movq xmm15, qword ptr [r15+0x230]
000076049b1d59a3  vmovaps [rsp+0x70], xmm15
000076049b1d59a9  vpermilpd xmm15, xmm15, 0x00
000076049b1d59af  movaps xmm7, xmm9
000076049b1d59b3  mulpd xmm7, xmm15
000076049b1d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000076049b1d59bd  ptest xmm6, xmm6
000076049b1d59c2  jnz 0x000076049B1D68FB
000076049b1d59c8  vxorps xmm15, xmm15, xmm15
000076049b1d59cd  vpbroadcastq xmm15, xmm15
000076049b1d59d2  movaps xmm9, xmm12
000076049b1d59d6  mulpd xmm9, xmm10
000076049b1d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000076049b1d59e1  ptest xmm6, xmm6
000076049b1d59e6  jnz 0x000076049B1D6A3D
000076049b1d59ec  movaps xmm10, xmm12
000076049b1d59f0  mulpd xmm10, xmm11
000076049b1d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000076049b1d59fb  ptest xmm6, xmm6
000076049b1d5a00  jnz 0x000076049B1D6B81
000076049b1d5a06  movaps xmm11, [r15+0x1F0]
000076049b1d5a0e  movaps xmm6, xmm12
000076049b1d5a12  mulpd xmm6, xmm11
000076049b1d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000076049b1d5a1c  ptest xmm5, xmm5
000076049b1d5a21  jnz 0x000076049B1D6CC5
000076049b1d5a27  movaps xmm12, [r15+0x2A0]
000076049b1d5a2f  vmovaps [rsp+0x80], xmm12
000076049b1d5a38  vmovaps xmm11, [rsp+0x80]
000076049b1d5a41  por xmm12, xmm11
000076049b1d5a46  movaps xmm11, [r15+0x250]
000076049b1d5a4e  vmovaps [rsp+0x80], xmm11
000076049b1d5a57  vmovaps xmm5, [rsp+0x80]
000076049b1d5a60  por xmm11, xmm5
000076049b1d5a65  vmovaps xmm4, [rsp+0x70]
000076049b1d5a6b  vpermilpd xmm4, xmm4, 0x00
000076049b1d5a71  movaps xmm3, xmm5
000076049b1d5a74  mulpd xmm3, xmm4
000076049b1d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000076049b1d5a7d  ptest xmm2, xmm2
000076049b1d5a82  jnz 0x000076049B1D6E07
000076049b1d5a88  mov [rsp+0x80], rax
000076049b1d5a90  xor eax, eax
000076049b1d5a92  mov r14d, 0x200
000076049b1d5a98  cmp r12, r14
000076049b1d5a9b  cmc
000076049b1d5a9c  lahf
000076049b1d5a9d  seto al
000076049b1d5aa0  mov [r15+0x108], eax
000076049b1d5aa7  movaps xmm5, xmm8
000076049b1d5aab  addpd xmm5, xmm15
000076049b1d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000076049b1d5ab5  ptest xmm4, xmm4
000076049b1d5aba  jnz 0x000076049B1D6F47
000076049b1d5ac0  movaps xmm8, [r15+0x1B0]
000076049b1d5ac8  movaps xmm4, xmm9
000076049b1d5acc  addpd xmm4, xmm8
000076049b1d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000076049b1d5ad6  ptest xmm2, xmm2
000076049b1d5adb  jnz 0x000076049B1D7089
000076049b1d5ae1  movaps xmm9, xmm10
000076049b1d5ae5  addpd xmm9, xmm8
000076049b1d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000076049b1d5af0  ptest xmm2, xmm2
000076049b1d5af5  jnz 0x000076049B1D71CB
000076049b1d5afb  movaps xmm10, [r15+0x2F0]
000076049b1d5b03  vmovaps [rsp+0x90], xmm10
000076049b1d5b0c  vmovaps xmm8, [rsp+0x90]
000076049b1d5b15  por xmm10, xmm8
000076049b1d5b1a  movaps xmm8, [r15+0x2E0]
000076049b1d5b22  vmovaps [rsp+0x90], xmm8
000076049b1d5b2b  vmovaps xmm2, [rsp+0x90]
000076049b1d5b34  por xmm8, xmm2
000076049b1d5b39  movaps xmm2, [r15+0x2D0]
000076049b1d5b41  vmovaps [rsp+0x90], xmm2
000076049b1d5b4a  vmovaps [rsp+0xA0], xmm1
000076049b1d5b53  vmovaps xmm1, [rsp+0x90]
000076049b1d5b5c  por xmm2, xmm1
000076049b1d5b60  movaps xmm1, [r15+0x200]
000076049b1d5b68  vmovaps [rsp+0x90], xmm1
000076049b1d5b71  vmovaps [rsp+0xB0], xmm15
000076049b1d5b7a  vmovaps xmm15, [rsp+0x90]
000076049b1d5b83  por xmm1, xmm15
000076049b1d5b88  movaps xmm15, [r15+0x1C0]
000076049b1d5b90  vmovaps [rsp+0x90], xmm15
000076049b1d5b99  vmovaps [rsp+0xC0], xmm1
000076049b1d5ba2  vmovaps xmm1, [rsp+0x90]
000076049b1d5bab  por xmm15, xmm1
000076049b1d5bb0  movaps xmm1, [r15+0x190]
000076049b1d5bb8  vmovaps [rsp+0x90], xmm1
000076049b1d5bc1  vmovaps [rsp+0xD0], xmm15
000076049b1d5bca  vmovaps xmm15, [rsp+0x90]
000076049b1d5bd3  por xmm1, xmm15
000076049b1d5bd8  movaps xmm15, [r15+0x300]
000076049b1d5be0  vmovaps [rsp+0x90], xmm15
000076049b1d5be9  vmovaps [rsp+0xE0], xmm1
000076049b1d5bf2  vmovaps xmm1, [rsp+0x90]
000076049b1d5bfb  por xmm15, xmm1
000076049b1d5c00  mov rax, [rsp+0x80]
000076049b1d5c08  lea r14, [rax+0xA0]
000076049b1d5c0f  movups xmm1, [r13+r14*1]
000076049b1d5c15  lea r14, [rax+0xB0]
000076049b1d5c1c  vmovaps [rsp+0x80], xmm1
000076049b1d5c25  movups xmm1, [r13+r14*1]
000076049b1d5c2b  vmovaps [rsp+0x90], xmm1
000076049b1d5c34  vmovaps [rsp+0xF0], xmm15
000076049b1d5c3d  vmovaps xmm15, [rsp+0xB0]
000076049b1d5c46  vmovaps [rsp+0xB0], xmm14
000076049b1d5c4f  movaps xmm1, xmm6
000076049b1d5c52  addpd xmm1, xmm15
000076049b1d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000076049b1d5c5c  ptest xmm14, xmm14
000076049b1d5c62  jnz 0x000076049B1D7323
000076049b1d5c68  lea r14, [rax+0xF0]
000076049b1d5c6f  movups xmm15, [r13+r14*1]
000076049b1d5c75  movaps xmm14, xmm4
000076049b1d5c79  addpd xmm14, xmm3
000076049b1d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000076049b1d5c84  ptest xmm6, xmm6
000076049b1d5c89  jnz 0x000076049B1D746E
000076049b1d5c8f  movaps xmm6, xmm9
000076049b1d5c93  addpd xmm6, xmm7
000076049b1d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000076049b1d5c9c  ptest xmm4, xmm4
000076049b1d5ca1  jnz 0x000076049B1D75B0
000076049b1d5ca7  vmovaps xmm9, [rsp+0x70]
000076049b1d5cad  vpermilpd xmm9, xmm9, 0x00
000076049b1d5cb3  vmovaps xmm4, [rsp+0x90]
000076049b1d5cbc  movaps xmm7, xmm4
000076049b1d5cbf  mulpd xmm7, xmm9
000076049b1d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000076049b1d5cc9  ptest xmm3, xmm3
000076049b1d5cce  jnz 0x000076049B1D76F1
000076049b1d5cd4  vmovaps xmm9, [rsp+0x50]
000076049b1d5cda  vpermilpd xmm9, xmm9, 0x00
000076049b1d5ce0  movaps xmm4, xmm15
000076049b1d5ce4  mulpd xmm4, xmm9
000076049b1d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000076049b1d5cee  ptest xmm3, xmm3
000076049b1d5cf3  jnz 0x000076049B1D7832
000076049b1d5cf9  lea r14, [rax+0xE0]
000076049b1d5d00  movups xmm15, [r13+r14*1]
000076049b1d5d06  vmovaps xmm9, [rsp+0x70]
000076049b1d5d0c  vpermilpd xmm9, xmm9, 0x00
000076049b1d5d12  vmovaps [rsp+0x70], xmm1
000076049b1d5d18  vmovaps xmm1, [rsp+0x80]
000076049b1d5d21  vmovaps [rsp+0x80], xmm15
000076049b1d5d2a  movaps xmm3, xmm1
000076049b1d5d2d  mulpd xmm3, xmm9
000076049b1d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000076049b1d5d37  ptest xmm15, xmm15
000076049b1d5d3d  jnz 0x000076049B1D797E
000076049b1d5d43  vmovaps xmm1, [rsp+0xF0]
000076049b1d5d4c  vmovaps xmm15, [rsp+0xF0]
000076049b1d5d55  por xmm1, xmm15
000076049b1d5d5a  movaps [r15+0x300], xmm1
000076049b1d5d62  vmovaps xmm15, [rsp+0xE0]
000076049b1d5d6b  vmovaps xmm9, [rsp+0xE0]
000076049b1d5d74  por xmm15, xmm9
000076049b1d5d79  movaps [r15+0x190], xmm15
000076049b1d5d81  vmovaps xmm9, [rsp+0x50]
000076049b1d5d87  vpermilpd xmm9, xmm9, 0x00
000076049b1d5d8d  vmovaps [rsp+0x90], xmm1
000076049b1d5d96  vmovaps [rsp+0xE0], xmm15
000076049b1d5d9f  vmovaps xmm15, [rsp+0x80]
000076049b1d5da8  vmovaps [rsp+0x80], xmm14
000076049b1d5db1  movaps xmm1, xmm15
000076049b1d5db5  mulpd xmm1, xmm9
000076049b1d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000076049b1d5dbf  ptest xmm14, xmm14
000076049b1d5dc5  jnz 0x000076049B1D7ABF
000076049b1d5dcb  lea r14, [rax+0x90]
000076049b1d5dd2  movups xmm15, [r13+r14*1]
000076049b1d5dd8  vmovaps xmm14, [rsp+0xD0]
000076049b1d5de1  vmovaps xmm9, [rsp+0xD0]
000076049b1d5dea  por xmm14, xmm9
000076049b1d5def  movaps [r15+0x1C0], xmm14
000076049b1d5df7  vmovaps xmm9, [rsp+0xC0]
000076049b1d5e00  vmovaps [rsp+0xD0], xmm1
000076049b1d5e09  vmovaps xmm1, [rsp+0xC0]
000076049b1d5e12  por xmm9, xmm1
000076049b1d5e17  movaps [r15+0x200], xmm9
000076049b1d5e1f  vmovaps [rsp+0xC0], xmm2
000076049b1d5e28  vmovaps xmm1, [rsp+0xC0]
000076049b1d5e31  por xmm2, xmm1
000076049b1d5e35  movaps [r15+0x2D0], xmm2
000076049b1d5e3d  vmovaps [rsp+0xC0], xmm8
000076049b1d5e46  vmovaps xmm1, [rsp+0xC0]
000076049b1d5e4f  por xmm8, xmm1
000076049b1d5e54  movaps [r15+0x2E0], xmm8
000076049b1d5e5c  vmovaps [rsp+0xC0], xmm15
000076049b1d5e65  movaps xmm1, xmm5
000076049b1d5e68  addpd xmm1, xmm7
000076049b1d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000076049b1d5e71  ptest xmm15, xmm15
000076049b1d5e77  jnz 0x000076049B1D7C0B
000076049b1d5e7d  vmovaps xmm15, [rsp+0x50]
000076049b1d5e83  vpermilpd xmm15, xmm15, 0x00
000076049b1d5e89  vmovaps xmm5, [rsp+0xC0]
000076049b1d5e92  vmovaps [rsp+0xC0], xmm1
000076049b1d5e9b  movaps xmm7, xmm5
000076049b1d5e9e  mulpd xmm7, xmm15
000076049b1d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000076049b1d5ea8  ptest xmm1, xmm1
000076049b1d5ead  jnz 0x000076049B1D7D4B
000076049b1d5eb3  lea r14, [rax+0x80]
000076049b1d5eba  movups xmm1, [r13+r14*1]
000076049b1d5ec0  vmovaps xmm5, [rsp+0x70]
000076049b1d5ec6  vmovaps [rsp+0x70], xmm1
000076049b1d5ecc  movaps xmm15, xmm5
000076049b1d5ed0  addpd xmm15, xmm3
000076049b1d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000076049b1d5edb  ptest xmm1, xmm1
000076049b1d5ee0  jnz 0x000076049B1D7E96
000076049b1d5ee6  vmovaps xmm5, [rsp+0x80]
000076049b1d5eef  movaps xmm1, xmm5
000076049b1d5ef2  addpd xmm1, xmm4
000076049b1d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000076049b1d5efb  ptest xmm3, xmm3
000076049b1d5f00  jnz 0x000076049B1D7FD8
000076049b1d5f06  vmovaps [rsp+0x80], xmm10
000076049b1d5f0f  vmovaps xmm5, [rsp+0x80]
000076049b1d5f18  por xmm10, xmm5
000076049b1d5f1d  movaps [r15+0x2F0], xmm10
000076049b1d5f25  vmovaps xmm5, [rsp+0x50]
000076049b1d5f2b  vpermilpd xmm5, xmm5, 0x00
000076049b1d5f31  vmovaps xmm3, [rsp+0x70]
000076049b1d5f37  vmovaps [rsp+0x50], xmm1
000076049b1d5f3d  movaps xmm4, xmm3
000076049b1d5f40  mulpd xmm4, xmm5
000076049b1d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000076049b1d5f49  ptest xmm1, xmm1
000076049b1d5f4e  jnz 0x000076049B1D8118
000076049b1d5f54  lea r14, [rax+0xD0]
000076049b1d5f5b  movups xmm1, [r13+r14*1]
000076049b1d5f61  vmovaps xmm3, [rsp+0xD0]
000076049b1d5f6a  vmovaps [rsp+0x70], xmm1
000076049b1d5f70  movaps xmm5, xmm6
000076049b1d5f73  addpd xmm5, xmm3
000076049b1d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000076049b1d5f7c  ptest xmm1, xmm1
000076049b1d5f81  jnz 0x000076049B1D8262
000076049b1d5f87  vmovaps xmm1, [rsp+0x60]
000076049b1d5f8d  vpermilpd xmm1, xmm1, 0x00
000076049b1d5f93  movaps xmm6, xmm9
000076049b1d5f97  mulpd xmm6, xmm1
000076049b1d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000076049b1d5fa0  ptest xmm3, xmm3
000076049b1d5fa5  jnz 0x000076049B1D83A2
000076049b1d5fab  movaps [r15+0x260], xmm6
000076049b1d5fb3  vxorps xmm1, xmm1, xmm1
000076049b1d5fb7  vpbroadcastq xmm1, xmm1
000076049b1d5fbc  movaps [r15+0x1B0], xmm1
000076049b1d5fc4  vmovaps xmm1, [rsp+0x60]
000076049b1d5fca  vpermilpd xmm1, xmm1, 0x00
000076049b1d5fd0  vmovaps xmm3, [rsp+0x70]
000076049b1d5fd6  vmovaps [rsp+0x70], xmm15
000076049b1d5fdc  movaps xmm9, xmm3
000076049b1d5fe0  mulpd xmm9, xmm1
000076049b1d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000076049b1d5feb  ptest xmm15, xmm15
000076049b1d5ff1  jnz 0x000076049B1D84E3
000076049b1d5ff7  lea r14, [rax+0xC0]
000076049b1d5ffe  movups xmm1, [r13+r14*1]
000076049b1d6004  vmovaps xmm3, [rsp+0xC0]
000076049b1d600d  vmovaps [rsp+0x80], xmm1
000076049b1d6016  movaps xmm15, xmm3
000076049b1d601a  addpd xmm15, xmm7
000076049b1d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000076049b1d6025  ptest xmm1, xmm1
000076049b1d602a  jnz 0x000076049B1D862F
000076049b1d6030  vmovaps [rsp+0xC0], xmm13
000076049b1d6039  vmovaps xmm1, [rsp+0xC0]
000076049b1d6042  por xmm13, xmm1
000076049b1d6047  movaps [r15+0x270], xmm13
000076049b1d604f  vmovaps xmm1, [rsp+0xB0]
000076049b1d6058  vmovaps xmm7, [rsp+0xB0]
000076049b1d6061  por xmm1, xmm7
000076049b1d6065  movaps [r15+0x1A0], xmm1
000076049b1d606d  vmovaps xmm1, [rsp+0x60]
000076049b1d6073  vpermilpd xmm1, xmm1, 0x00
000076049b1d6079  vmovaps [rsp+0xB0], xmm1
000076049b1d6082  vmovaps xmm1, [rsp+0x80]
000076049b1d608b  vmovaps [rsp+0x80], xmm15
000076049b1d6094  vmovaps xmm15, [rsp+0xB0]
000076049b1d609d  vmovaps [rsp+0xB0], xmm14
000076049b1d60a6  movaps xmm3, xmm1
000076049b1d60a9  mulpd xmm3, xmm15
000076049b1d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000076049b1d60b3  ptest xmm14, xmm14
000076049b1d60b9  jnz 0x000076049B1D8771
000076049b1d60bf  lea r14, [rax+0x20]
000076049b1d60c3  movups xmm1, [r13+r14*1]
000076049b1d60c9  movaps [r15+0x110], xmm1
000076049b1d60d1  vmovaps xmm14, [rsp+0x70]
000076049b1d60d7  vmovaps [rsp+0x70], xmm1
000076049b1d60dd  movaps xmm15, xmm14
000076049b1d60e1  addpd xmm15, xmm4
000076049b1d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000076049b1d60ec  ptest xmm1, xmm1
000076049b1d60f1  jnz 0x000076049B1D88BC
000076049b1d60f7  vmovaps xmm1, [rsp+0x60]
000076049b1d60fd  vpermilpd xmm1, xmm1, 0x00
000076049b1d6103  movaps xmm14, xmm2
000076049b1d6107  mulpd xmm14, xmm1
000076049b1d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000076049b1d6112  ptest xmm4, xmm4
000076049b1d6117  jnz 0x000076049B1D89FF
000076049b1d611d  vmovaps xmm4, [rsp+0x50]
000076049b1d6123  movaps xmm1, xmm4
000076049b1d6126  addpd xmm1, xmm9
000076049b1d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000076049b1d6130  ptest xmm2, xmm2
000076049b1d6135  jnz 0x000076049B1D8B41
000076049b1d613b  vmovaps xmm9, [rsp+0x30]
000076049b1d6141  vpermilpd xmm9, xmm9, 0x00
000076049b1d6147  vmovaps xmm2, [rsp+0x70]
000076049b1d614d  vmovaps [rsp+0x50], xmm1
000076049b1d6153  movaps xmm4, xmm2
000076049b1d6156  mulpd xmm4, xmm9
000076049b1d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000076049b1d6160  ptest xmm1, xmm1
000076049b1d6165  jnz 0x000076049B1D8C82
000076049b1d616b  vmovaps xmm1, [rsp+0x30]
000076049b1d6171  vpermilpd xmm1, xmm1, 0x00
000076049b1d6177  vmovaps xmm2, [rsp+0x90]
000076049b1d6180  vmovaps [rsp+0x60], xmm15
000076049b1d6186  movaps xmm9, xmm2
000076049b1d618a  mulpd xmm9, xmm1
000076049b1d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000076049b1d6195  ptest xmm15, xmm15
000076049b1d619b  jnz 0x000076049B1D8DC3
000076049b1d61a1  vmovaps xmm15, [rsp+0x80]
000076049b1d61aa  movaps xmm1, xmm15
000076049b1d61ae  addpd xmm1, xmm6
000076049b1d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000076049b1d61b7  ptest xmm2, xmm2
000076049b1d61bc  jnz 0x000076049B1D8F05
000076049b1d61c2  movaps xmm15, xmm5
000076049b1d61c6  addpd xmm15, xmm3
000076049b1d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000076049b1d61d1  ptest xmm6, xmm6
000076049b1d61d6  jnz 0x000076049B1D9046
000076049b1d61dc  vmovaps xmm6, [rsp+0x30]
000076049b1d61e2  vpermilpd xmm6, xmm6, 0x00
000076049b1d61e8  movaps xmm5, xmm8
000076049b1d61ec  mulpd xmm5, xmm6
000076049b1d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000076049b1d61f5  ptest xmm3, xmm3
000076049b1d61fa  jnz 0x000076049B1D9188
000076049b1d6200  vmovaps xmm8, [rsp+0x30]
000076049b1d6206  vpermilpd xmm8, xmm8, 0x00
000076049b1d620c  movaps xmm6, xmm10
000076049b1d6210  mulpd xmm6, xmm8
000076049b1d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000076049b1d621a  ptest xmm3, xmm3
000076049b1d621f  jnz 0x000076049B1D92C9
000076049b1d6225  vmovaps xmm8, [rsp+0x60]
000076049b1d622b  movaps xmm10, xmm8
000076049b1d622f  addpd xmm10, xmm14
000076049b1d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000076049b1d623a  ptest xmm3, xmm3
000076049b1d623f  jnz 0x000076049B1D940B
000076049b1d6245  vmovaps xmm8, [rsp+0x50]
000076049b1d624b  movaps xmm14, xmm8
000076049b1d624f  addpd xmm14, xmm4
000076049b1d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000076049b1d625a  ptest xmm3, xmm3
000076049b1d625f  jnz 0x000076049B1D954F
000076049b1d6265  vmovaps xmm8, [rsp+0x40]
000076049b1d626b  vpermilpd xmm8, xmm8, 0x00
000076049b1d6271  movaps xmm4, xmm13
000076049b1d6275  mulpd xmm4, xmm8
000076049b1d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000076049b1d627f  ptest xmm3, xmm3
000076049b1d6284  jnz 0x000076049B1D9692
000076049b1d628a  movaps xmm13, xmm15
000076049b1d628e  addpd xmm13, xmm9
000076049b1d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000076049b1d6299  ptest xmm8, xmm8
000076049b1d629f  jnz 0x000076049B1D97D4
000076049b1d62a5  movaps xmm15, xmm1
000076049b1d62a9  addpd xmm15, xmm5
000076049b1d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000076049b1d62b4  ptest xmm9, xmm9
000076049b1d62ba  jnz 0x000076049B1D9918
000076049b1d62c0  vmovaps [rsp+0x30], xmm11
000076049b1d62c6  vmovaps xmm1, [rsp+0x30]
000076049b1d62cc  por xmm11, xmm1
000076049b1d62d1  movaps [r15+0x250], xmm11
000076049b1d62d9  vmovaps [rsp+0x30], xmm12
000076049b1d62df  vmovaps xmm1, [rsp+0x30]
000076049b1d62e5  por xmm12, xmm1
000076049b1d62ea  movaps [r15+0x2A0], xmm12
000076049b1d62f2  vmovaps xmm1, [rsp+0xA0]
000076049b1d62fb  vmovaps xmm11, [rsp+0xA0]
000076049b1d6304  por xmm1, xmm11
000076049b1d6309  movaps [r15+0x1D0], xmm1
000076049b1d6311  lea r14, [rax+0x40]
000076049b1d6315  movups xmm1, [r13+r14*1]
000076049b1d631b  movaps [r15+0x2C0], xmm1
000076049b1d6323  vmovaps xmm11, [rsp+0x40]
000076049b1d6329  vpermilpd xmm11, xmm11, 0x00
000076049b1d632f  vmovaps xmm8, [rsp+0xE0]
000076049b1d6338  movaps xmm9, xmm8
000076049b1d633c  mulpd xmm9, xmm11
000076049b1d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000076049b1d6347  ptest xmm5, xmm5
000076049b1d634c  jnz 0x000076049B1D9A64
000076049b1d6352  movaps xmm11, xmm10
000076049b1d6356  addpd xmm11, xmm6
000076049b1d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000076049b1d6361  ptest xmm8, xmm8
000076049b1d6367  jnz 0x000076049B1D9BA8
000076049b1d636d  movaps xmm10, xmm14
000076049b1d6371  addpd xmm10, xmm4
000076049b1d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000076049b1d637c  ptest xmm8, xmm8
000076049b1d6382  jnz 0x000076049B1D9CEB
000076049b1d6388  vmovaps xmm14, [rsp+0x40]
000076049b1d638e  vpermilpd xmm14, xmm14, 0x00
000076049b1d6394  movaps xmm8, xmm1
000076049b1d6398  mulpd xmm8, xmm14
000076049b1d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000076049b1d63a3  ptest xmm6, xmm6
000076049b1d63a8  jnz 0x000076049B1D9E2E
000076049b1d63ae  movaps xmm1, [r15+0x2B0]
000076049b1d63b6  vmovaps xmm14, [rsp+0x40]
000076049b1d63bc  vpermilpd xmm14, xmm14, 0x00
000076049b1d63c2  movaps xmm6, xmm1
000076049b1d63c5  mulpd xmm6, xmm14
000076049b1d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000076049b1d63cf  ptest xmm5, xmm5
000076049b1d63d4  jnz 0x000076049B1D9F71
000076049b1d63da  vmovaps xmm1, [rsp+0x10]
000076049b1d63e0  vpermilpd xmm1, xmm1, 0x00
000076049b1d63e6  movaps xmm14, xmm12
000076049b1d63ea  mulpd xmm14, xmm1
000076049b1d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000076049b1d63f5  ptest xmm5, xmm5
000076049b1d63fa  jnz 0x000076049B1DA0B2
000076049b1d6400  movaps xmm1, xmm13
000076049b1d6404  addpd xmm1, xmm9
000076049b1d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000076049b1d640e  ptest xmm12, xmm12
000076049b1d6414  jnz 0x000076049B1DA1F5
000076049b1d641a  vmovaps xmm13, [rsp+0x10]
000076049b1d6420  vpermilpd xmm13, xmm13, 0x00
000076049b1d6426  movaps xmm12, xmm7
000076049b1d642a  mulpd xmm12, xmm13
000076049b1d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000076049b1d6435  ptest xmm9, xmm9
000076049b1d643b  jnz 0x000076049B1DA337
000076049b1d6441  movaps xmm13, xmm15
000076049b1d6445  addpd xmm13, xmm8
000076049b1d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000076049b1d6450  ptest xmm9, xmm9
000076049b1d6456  jnz 0x000076049B1DA47A
000076049b1d645c  movaps xmm15, [r15+0x290]
000076049b1d6464  vmovaps xmm9, [rsp+0x10]
000076049b1d646a  vpermilpd xmm9, xmm9, 0x00
000076049b1d6470  movaps xmm8, xmm15
000076049b1d6474  mulpd xmm8, xmm9
000076049b1d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000076049b1d647f  ptest xmm7, xmm7
000076049b1d6484  jnz 0x000076049B1DA5BE
000076049b1d648a  movaps xmm15, xmm11
000076049b1d648e  addpd xmm15, xmm6
000076049b1d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000076049b1d6499  ptest xmm9, xmm9
000076049b1d649f  jnz 0x000076049B1DA702
000076049b1d64a5  movaps xmm11, [r15+0x1E0]
000076049b1d64ad  vmovaps xmm9, [rsp+0x10]
000076049b1d64b3  vpermilpd xmm9, xmm9, 0x00
000076049b1d64b9  movaps xmm7, xmm11
000076049b1d64bd  mulpd xmm7, xmm9
000076049b1d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000076049b1d64c7  ptest xmm6, xmm6
000076049b1d64cc  jnz 0x000076049B1DA845
000076049b1d64d2  movaps xmm11, xmm10
000076049b1d64d6  addpd xmm11, xmm14
000076049b1d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000076049b1d64e1  ptest xmm9, xmm9
000076049b1d64e7  jnz 0x000076049B1DA987
000076049b1d64ed  lea r14, [rax+0x70]
000076049b1d64f1  movups xmm14, [r13+r14*1]
000076049b1d64f7  movaps [r15+0x240], xmm14
000076049b1d64ff  movaps xmm10, xmm1
000076049b1d6503  addpd xmm10, xmm12
000076049b1d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000076049b1d650e  ptest xmm9, xmm9
000076049b1d6514  jnz 0x000076049B1DAAD5
000076049b1d651a  movaps [r15+0x170], xmm10
000076049b1d6522  vmovaps xmm1, [rsp+0x20]
000076049b1d6528  vpermilpd xmm1, xmm1, 0x00
000076049b1d652e  movaps xmm12, xmm14
000076049b1d6532  mulpd xmm12, xmm1
000076049b1d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000076049b1d653d  ptest xmm9, xmm9
000076049b1d6543  jnz 0x000076049B1DAC18
000076049b1d6549  vmovaps xmm1, [rsp+0x20]
000076049b1d654f  vpermilpd xmm1, xmm1, 0x00
000076049b1d6555  vmovaps xmm9, [rsp+0xB0]
000076049b1d655e  movaps xmm14, xmm9
000076049b1d6562  mulpd xmm14, xmm1
000076049b1d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000076049b1d656d  ptest xmm6, xmm6
000076049b1d6572  jnz 0x000076049B1DAD5B
000076049b1d6578  movaps [r15+0x180], xmm14
000076049b1d6580  movaps xmm1, xmm13
000076049b1d6584  addpd xmm1, xmm8
000076049b1d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000076049b1d658e  ptest xmm9, xmm9
000076049b1d6594  jnz 0x000076049B1DAE9E
000076049b1d659a  movaps [r15+0x210], xmm1
000076049b1d65a2  movups xmm13, [r13+rax*1]
000076049b1d65a8  lea r14, [rax+0x10]
000076049b1d65ac  movups xmm9, [r13+r14*1]
000076049b1d65b2  movaps [r15+0x230], xmm9
000076049b1d65ba  movaps xmm8, xmm15
000076049b1d65be  addpd xmm8, xmm7
000076049b1d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000076049b1d65c9  ptest xmm6, xmm6
000076049b1d65ce  jnz 0x000076049B1DAFF4
000076049b1d65d4  movaps [r15+0x130], xmm8
000076049b1d65dc  vmovaps xmm15, [rsp+0x20]
000076049b1d65e2  vpermilpd xmm15, xmm15, 0x00
000076049b1d65e8  movaps xmm7, xmm9
000076049b1d65ec  mulpd xmm7, xmm15
000076049b1d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000076049b1d65f6  ptest xmm6, xmm6
000076049b1d65fb  jnz 0x000076049B1DB137
000076049b1d6601  movaps [r15+0x220], xmm7
000076049b1d6609  vmovaps xmm15, [rsp+0x20]
000076049b1d660f  vpermilpd xmm15, xmm15, 0x00
000076049b1d6615  movaps xmm9, xmm13
000076049b1d6619  mulpd xmm9, xmm15
000076049b1d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000076049b1d6624  ptest xmm6, xmm6
000076049b1d6629  jnz 0x000076049B1DB279
000076049b1d662f  movaps xmm15, xmm11
000076049b1d6633  addpd xmm15, xmm12
000076049b1d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000076049b1d663e  ptest xmm13, xmm13
000076049b1d6644  jnz 0x000076049B1DB3BD
000076049b1d664a  movaps [r15+0x140], xmm15
000076049b1d6652  movaps xmm13, xmm10
000076049b1d6656  addpd xmm13, xmm14
000076049b1d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000076049b1d6661  ptest xmm12, xmm12
000076049b1d6667  jnz 0x000076049B1DB501
000076049b1d666d  movaps [r15+0x150], xmm13
000076049b1d6675  movaps xmm14, xmm1
000076049b1d6679  addpd xmm14, xmm7
000076049b1d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000076049b1d6684  ptest xmm12, xmm12
000076049b1d668a  jnz 0x000076049B1DB645
000076049b1d6690  movaps [r15+0x160], xmm14
000076049b1d6698  movaps xmm1, xmm8
000076049b1d669c  addpd xmm1, xmm9
000076049b1d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000076049b1d66a6  ptest xmm12, xmm12
000076049b1d66ac  jnz 0x000076049B1DB787
000076049b1d66b2  movaps [r15+0x120], xmm1
000076049b1d66ba  movups [r13+r11*1], xmm15
000076049b1d66c0  lea rax, [r11+0x10]
000076049b1d66c4  movups [r13+rax*1], xmm13
000076049b1d66ca  lea rax, [r11+0x20]
000076049b1d66ce  movups [r13+rax*1], xmm14
000076049b1d66d4  lea rax, [r11+0x30]
000076049b1d66d8  movups [r13+rax*1], xmm1
000076049b1d66de  mov eax, [r15+0x108]
000076049b1d66e5  sahf
000076049b1d66e6  jnz 0x000076049B1D6718
000076049b1d66e8  cmp dword ptr [r15+0x318], 0x00
000076049b1d66f0  jz 0x000076049B1DB900
000076049b1d66f6  nop [rax+rax*1], ax
000076049b1d66ff  nop [rax+rax*1], eax
000076049b1d6707  mov eax, 0x410444
000076049b1d670c  mov [r15+0x100], rax
000076049b1d6713  jmp 0x000076049AFFE110
000076049b1d6718  cmp dword ptr [r15+0x318], 0x00
000076049b1d6720  jz 0x000076049B1D57E0
000076049b1d6726  nop [rax+rax*1], ax
000076049b1d672f  nop [rax+rax*1], eax
000076049b1d6737  mov eax, 0x410278
000076049b1d673c  mov [r15+0x100], rax
000076049b1d6743  jmp 0x000076049AFFE110
000076049b1d6748  int3
000076049b1d6749  call 0x000076049B00A4B0
000076049b1d674e  jmp 0x000076049B1D5828
000076049b1d6753  call 0x000076049B009240
000076049b1d6758  jmp 0x000076049B1D5832
000076049b1d675d  call 0x000076049B00A4B0
000076049b1d6762  jmp 0x000076049B1D588F
000076049b1d6767  call 0x000076049B009240
000076049b1d676c  jmp 0x000076049B1D5899
000076049b1d6771  call 0x000076049B00A4B0
000076049b1d6776  jmp 0x000076049B1D58DD
000076049b1d677b  call 0x000076049B009240
000076049b1d6780  jmp 0x000076049B1D58E7
000076049b1d6785  call 0x000076049B0B47C0
000076049b1d678a  jmp 0x000076049B1D5926
000076049b1d678f  call 0x000076049B00B720
000076049b1d6794  jmp 0x000076049B1D593A
000076049b1d6799  call 0x000076049B0BFC30
000076049b1d679e  jmp 0x000076049B1D5958
000076049b1d67a3  call 0x000076049B0BE9C0
000076049b1d67a8  jmp 0x000076049B1D5962
000076049b1d67ad  call 0x000076049B0BD750
000076049b1d67b2  jmp 0x000076049B1D596C
000076049b1d67b7  sub rsp, 0x08
000076049b1d67bb  push rax
000076049b1d67bc  push rcx
000076049b1d67bd  push rdx
000076049b1d67be  push rdi
000076049b1d67bf  push rsi
000076049b1d67c0  push r8
000076049b1d67c2  push r9
000076049b1d67c4  push r10
000076049b1d67c6  push r11
000076049b1d67c8  sub rsp, 0xF0
000076049b1d67cf  vmovaps [rsp], xmm0
000076049b1d67d4  vmovaps [rsp+0x10], xmm1
000076049b1d67da  vmovaps [rsp+0x20], xmm2
000076049b1d67e0  vmovaps [rsp+0x30], xmm3
000076049b1d67e6  vmovaps [rsp+0x40], xmm4
000076049b1d67ec  vmovaps [rsp+0x50], xmm5
000076049b1d67f2  vmovaps [rsp+0x60], xmm6
000076049b1d67f8  vmovaps [rsp+0x70], xmm7
000076049b1d67fe  vmovaps [rsp+0x80], xmm9
000076049b1d6807  vmovaps [rsp+0x90], xmm10
000076049b1d6810  vmovaps [rsp+0xA0], xmm11
000076049b1d6819  vmovaps [rsp+0xB0], xmm12
000076049b1d6822  vmovaps [rsp+0xC0], xmm13
000076049b1d682b  vmovaps [rsp+0xD0], xmm14
000076049b1d6834  vmovaps [rsp+0xE0], xmm15
000076049b1d683d  sub rsp, 0x30
000076049b1d6841  movaps [rsp], xmm8
000076049b1d6846  movaps [rsp+0x10], xmm12
000076049b1d684c  movaps [rsp+0x20], xmm15
000076049b1d6852  lea rdi, [rsp]
000076049b1d6856  mov esi, 0x00
000076049b1d685b  mov rax, 0x64C06813C530
000076049b1d6865  call rax
000076049b1d6867  movaps xmm8, [rsp]
000076049b1d686c  add rsp, 0x30
000076049b1d6870  vmovaps xmm0, [rsp]
000076049b1d6875  vmovaps xmm1, [rsp+0x10]
000076049b1d687b  vmovaps xmm2, [rsp+0x20]
000076049b1d6881  vmovaps xmm3, [rsp+0x30]
000076049b1d6887  vmovaps xmm4, [rsp+0x40]
000076049b1d688d  vmovaps xmm5, [rsp+0x50]
000076049b1d6893  vmovaps xmm6, [rsp+0x60]
000076049b1d6899  vmovaps xmm7, [rsp+0x70]
000076049b1d689f  vmovaps xmm9, [rsp+0x80]
000076049b1d68a8  vmovaps xmm10, [rsp+0x90]
000076049b1d68b1  vmovaps xmm11, [rsp+0xA0]
000076049b1d68ba  vmovaps xmm12, [rsp+0xB0]
000076049b1d68c3  vmovaps xmm13, [rsp+0xC0]
000076049b1d68cc  vmovaps xmm14, [rsp+0xD0]
000076049b1d68d5  vmovaps xmm15, [rsp+0xE0]
000076049b1d68de  add rsp, 0xF0
000076049b1d68e5  pop r11
000076049b1d68e7  pop r10
000076049b1d68e9  pop r9
000076049b1d68eb  pop r8
000076049b1d68ed  pop rsi
000076049b1d68ee  pop rdi
000076049b1d68ef  pop rdx
000076049b1d68f0  pop rcx
000076049b1d68f1  pop rax
000076049b1d68f2  add rsp, 0x08
000076049b1d68f6  jmp 0x000076049B1D599A
000076049b1d68fb  sub rsp, 0x08
000076049b1d68ff  push rax
000076049b1d6900  push rcx
000076049b1d6901  push rdx
000076049b1d6902  push rdi
000076049b1d6903  push rsi
000076049b1d6904  push r8
000076049b1d6906  push r9
000076049b1d6908  push r10
000076049b1d690a  push r11
000076049b1d690c  sub rsp, 0xF0
000076049b1d6913  vmovaps [rsp], xmm0
000076049b1d6918  vmovaps [rsp+0x10], xmm1
000076049b1d691e  vmovaps [rsp+0x20], xmm2
000076049b1d6924  vmovaps [rsp+0x30], xmm3
000076049b1d692a  vmovaps [rsp+0x40], xmm4
000076049b1d6930  vmovaps [rsp+0x50], xmm5
000076049b1d6936  vmovaps [rsp+0x60], xmm6
000076049b1d693c  vmovaps [rsp+0x70], xmm8
000076049b1d6942  vmovaps [rsp+0x80], xmm9
000076049b1d694b  vmovaps [rsp+0x90], xmm10
000076049b1d6954  vmovaps [rsp+0xA0], xmm11
000076049b1d695d  vmovaps [rsp+0xB0], xmm12
000076049b1d6966  vmovaps [rsp+0xC0], xmm13
000076049b1d696f  vmovaps [rsp+0xD0], xmm14
000076049b1d6978  vmovaps [rsp+0xE0], xmm15
000076049b1d6981  sub rsp, 0x30
000076049b1d6985  movaps [rsp], xmm7
000076049b1d6989  movaps [rsp+0x10], xmm9
000076049b1d698f  movaps [rsp+0x20], xmm15
000076049b1d6995  lea rdi, [rsp]
000076049b1d6999  mov esi, 0x00
000076049b1d699e  mov rax, 0x64C06813C530
000076049b1d69a8  call rax
000076049b1d69aa  movaps xmm7, [rsp]
000076049b1d69ae  add rsp, 0x30
000076049b1d69b2  vmovaps xmm0, [rsp]
000076049b1d69b7  vmovaps xmm1, [rsp+0x10]
000076049b1d69bd  vmovaps xmm2, [rsp+0x20]
000076049b1d69c3  vmovaps xmm3, [rsp+0x30]
000076049b1d69c9  vmovaps xmm4, [rsp+0x40]
000076049b1d69cf  vmovaps xmm5, [rsp+0x50]
000076049b1d69d5  vmovaps xmm6, [rsp+0x60]
000076049b1d69db  vmovaps xmm8, [rsp+0x70]
000076049b1d69e1  vmovaps xmm9, [rsp+0x80]
000076049b1d69ea  vmovaps xmm10, [rsp+0x90]
000076049b1d69f3  vmovaps xmm11, [rsp+0xA0]
000076049b1d69fc  vmovaps xmm12, [rsp+0xB0]
000076049b1d6a05  vmovaps xmm13, [rsp+0xC0]
000076049b1d6a0e  vmovaps xmm14, [rsp+0xD0]
000076049b1d6a17  vmovaps xmm15, [rsp+0xE0]
000076049b1d6a20  add rsp, 0xF0
000076049b1d6a27  pop r11
000076049b1d6a29  pop r10
000076049b1d6a2b  pop r9
000076049b1d6a2d  pop r8
000076049b1d6a2f  pop rsi
000076049b1d6a30  pop rdi
000076049b1d6a31  pop rdx
000076049b1d6a32  pop rcx
000076049b1d6a33  pop rax
000076049b1d6a34  add rsp, 0x08
000076049b1d6a38  jmp 0x000076049B1D59C8
000076049b1d6a3d  sub rsp, 0x08
000076049b1d6a41  push rax
000076049b1d6a42  push rcx
000076049b1d6a43  push rdx
000076049b1d6a44  push rdi
000076049b1d6a45  push rsi
000076049b1d6a46  push r8
000076049b1d6a48  push r9
000076049b1d6a4a  push r10
000076049b1d6a4c  push r11
000076049b1d6a4e  sub rsp, 0xF0
000076049b1d6a55  vmovaps [rsp], xmm0
000076049b1d6a5a  vmovaps [rsp+0x10], xmm1
000076049b1d6a60  vmovaps [rsp+0x20], xmm2
000076049b1d6a66  vmovaps [rsp+0x30], xmm3
000076049b1d6a6c  vmovaps [rsp+0x40], xmm4
000076049b1d6a72  vmovaps [rsp+0x50], xmm5
000076049b1d6a78  vmovaps [rsp+0x60], xmm6
000076049b1d6a7e  vmovaps [rsp+0x70], xmm7
000076049b1d6a84  vmovaps [rsp+0x80], xmm8
000076049b1d6a8d  vmovaps [rsp+0x90], xmm10
000076049b1d6a96  vmovaps [rsp+0xA0], xmm11
000076049b1d6a9f  vmovaps [rsp+0xB0], xmm12
000076049b1d6aa8  vmovaps [rsp+0xC0], xmm13
000076049b1d6ab1  vmovaps [rsp+0xD0], xmm14
000076049b1d6aba  vmovaps [rsp+0xE0], xmm15
000076049b1d6ac3  sub rsp, 0x30
000076049b1d6ac7  movaps [rsp], xmm9
000076049b1d6acc  movaps [rsp+0x10], xmm12
000076049b1d6ad2  movaps [rsp+0x20], xmm10
000076049b1d6ad8  lea rdi, [rsp]
000076049b1d6adc  mov esi, 0x00
000076049b1d6ae1  mov rax, 0x64C06813C530
000076049b1d6aeb  call rax
000076049b1d6aed  movaps xmm9, [rsp]
000076049b1d6af2  add rsp, 0x30
000076049b1d6af6  vmovaps xmm0, [rsp]
000076049b1d6afb  vmovaps xmm1, [rsp+0x10]
000076049b1d6b01  vmovaps xmm2, [rsp+0x20]
000076049b1d6b07  vmovaps xmm3, [rsp+0x30]
000076049b1d6b0d  vmovaps xmm4, [rsp+0x40]
000076049b1d6b13  vmovaps xmm5, [rsp+0x50]
000076049b1d6b19  vmovaps xmm6, [rsp+0x60]
000076049b1d6b1f  vmovaps xmm7, [rsp+0x70]
000076049b1d6b25  vmovaps xmm8, [rsp+0x80]
000076049b1d6b2e  vmovaps xmm10, [rsp+0x90]
000076049b1d6b37  vmovaps xmm11, [rsp+0xA0]
000076049b1d6b40  vmovaps xmm12, [rsp+0xB0]
000076049b1d6b49  vmovaps xmm13, [rsp+0xC0]
000076049b1d6b52  vmovaps xmm14, [rsp+0xD0]
000076049b1d6b5b  vmovaps xmm15, [rsp+0xE0]
000076049b1d6b64  add rsp, 0xF0
000076049b1d6b6b  pop r11
000076049b1d6b6d  pop r10
000076049b1d6b6f  pop r9
000076049b1d6b71  pop r8
000076049b1d6b73  pop rsi
000076049b1d6b74  pop rdi
000076049b1d6b75  pop rdx
000076049b1d6b76  pop rcx
000076049b1d6b77  pop rax
000076049b1d6b78  add rsp, 0x08
000076049b1d6b7c  jmp 0x000076049B1D59EC
000076049b1d6b81  sub rsp, 0x08
000076049b1d6b85  push rax
000076049b1d6b86  push rcx
000076049b1d6b87  push rdx
000076049b1d6b88  push rdi
000076049b1d6b89  push rsi
000076049b1d6b8a  push r8
000076049b1d6b8c  push r9
000076049b1d6b8e  push r10
000076049b1d6b90  push r11
000076049b1d6b92  sub rsp, 0xF0
000076049b1d6b99  vmovaps [rsp], xmm0
000076049b1d6b9e  vmovaps [rsp+0x10], xmm1
000076049b1d6ba4  vmovaps [rsp+0x20], xmm2
000076049b1d6baa  vmovaps [rsp+0x30], xmm3
000076049b1d6bb0  vmovaps [rsp+0x40], xmm4
000076049b1d6bb6  vmovaps [rsp+0x50], xmm5
000076049b1d6bbc  vmovaps [rsp+0x60], xmm6
000076049b1d6bc2  vmovaps [rsp+0x70], xmm7
000076049b1d6bc8  vmovaps [rsp+0x80], xmm8
000076049b1d6bd1  vmovaps [rsp+0x90], xmm9
000076049b1d6bda  vmovaps [rsp+0xA0], xmm11
000076049b1d6be3  vmovaps [rsp+0xB0], xmm12
000076049b1d6bec  vmovaps [rsp+0xC0], xmm13
000076049b1d6bf5  vmovaps [rsp+0xD0], xmm14
000076049b1d6bfe  vmovaps [rsp+0xE0], xmm15
000076049b1d6c07  sub rsp, 0x30
000076049b1d6c0b  movaps [rsp], xmm10
000076049b1d6c10  movaps [rsp+0x10], xmm12
000076049b1d6c16  movaps [rsp+0x20], xmm11
000076049b1d6c1c  lea rdi, [rsp]
000076049b1d6c20  mov esi, 0x00
000076049b1d6c25  mov rax, 0x64C06813C530
000076049b1d6c2f  call rax
000076049b1d6c31  movaps xmm10, [rsp]
000076049b1d6c36  add rsp, 0x30
000076049b1d6c3a  vmovaps xmm0, [rsp]
000076049b1d6c3f  vmovaps xmm1, [rsp+0x10]
000076049b1d6c45  vmovaps xmm2, [rsp+0x20]
000076049b1d6c4b  vmovaps xmm3, [rsp+0x30]
000076049b1d6c51  vmovaps xmm4, [rsp+0x40]
000076049b1d6c57  vmovaps xmm5, [rsp+0x50]
000076049b1d6c5d  vmovaps xmm6, [rsp+0x60]
000076049b1d6c63  vmovaps xmm7, [rsp+0x70]
000076049b1d6c69  vmovaps xmm8, [rsp+0x80]
000076049b1d6c72  vmovaps xmm9, [rsp+0x90]
000076049b1d6c7b  vmovaps xmm11, [rsp+0xA0]
000076049b1d6c84  vmovaps xmm12, [rsp+0xB0]
000076049b1d6c8d  vmovaps xmm13, [rsp+0xC0]
000076049b1d6c96  vmovaps xmm14, [rsp+0xD0]
000076049b1d6c9f  vmovaps xmm15, [rsp+0xE0]
000076049b1d6ca8  add rsp, 0xF0
000076049b1d6caf  pop r11
000076049b1d6cb1  pop r10
000076049b1d6cb3  pop r9
000076049b1d6cb5  pop r8
000076049b1d6cb7  pop rsi
000076049b1d6cb8  pop rdi
000076049b1d6cb9  pop rdx
000076049b1d6cba  pop rcx
000076049b1d6cbb  pop rax
000076049b1d6cbc  add rsp, 0x08
000076049b1d6cc0  jmp 0x000076049B1D5A06
000076049b1d6cc5  sub rsp, 0x08
000076049b1d6cc9  push rax
000076049b1d6cca  push rcx
000076049b1d6ccb  push rdx
000076049b1d6ccc  push rdi
000076049b1d6ccd  push rsi
000076049b1d6cce  push r8
000076049b1d6cd0  push r9
000076049b1d6cd2  push r10
000076049b1d6cd4  push r11
000076049b1d6cd6  sub rsp, 0xF0
000076049b1d6cdd  vmovaps [rsp], xmm0
000076049b1d6ce2  vmovaps [rsp+0x10], xmm1
000076049b1d6ce8  vmovaps [rsp+0x20], xmm2
000076049b1d6cee  vmovaps [rsp+0x30], xmm3
000076049b1d6cf4  vmovaps [rsp+0x40], xmm4
000076049b1d6cfa  vmovaps [rsp+0x50], xmm5
000076049b1d6d00  vmovaps [rsp+0x60], xmm7
000076049b1d6d06  vmovaps [rsp+0x70], xmm8
000076049b1d6d0c  vmovaps [rsp+0x80], xmm9
000076049b1d6d15  vmovaps [rsp+0x90], xmm10
000076049b1d6d1e  vmovaps [rsp+0xA0], xmm11
000076049b1d6d27  vmovaps [rsp+0xB0], xmm12
000076049b1d6d30  vmovaps [rsp+0xC0], xmm13
000076049b1d6d39  vmovaps [rsp+0xD0], xmm14
000076049b1d6d42  vmovaps [rsp+0xE0], xmm15
000076049b1d6d4b  sub rsp, 0x30
000076049b1d6d4f  movaps [rsp], xmm6
000076049b1d6d53  movaps [rsp+0x10], xmm12
000076049b1d6d59  movaps [rsp+0x20], xmm11
000076049b1d6d5f  lea rdi, [rsp]
000076049b1d6d63  mov esi, 0x00
000076049b1d6d68  mov rax, 0x64C06813C530
000076049b1d6d72  call rax
000076049b1d6d74  movaps xmm6, [rsp]
000076049b1d6d78  add rsp, 0x30
000076049b1d6d7c  vmovaps xmm0, [rsp]
000076049b1d6d81  vmovaps xmm1, [rsp+0x10]
000076049b1d6d87  vmovaps xmm2, [rsp+0x20]
000076049b1d6d8d  vmovaps xmm3, [rsp+0x30]
000076049b1d6d93  vmovaps xmm4, [rsp+0x40]
000076049b1d6d99  vmovaps xmm5, [rsp+0x50]
000076049b1d6d9f  vmovaps xmm7, [rsp+0x60]
000076049b1d6da5  vmovaps xmm8, [rsp+0x70]
000076049b1d6dab  vmovaps xmm9, [rsp+0x80]
000076049b1d6db4  vmovaps xmm10, [rsp+0x90]
000076049b1d6dbd  vmovaps xmm11, [rsp+0xA0]
000076049b1d6dc6  vmovaps xmm12, [rsp+0xB0]
000076049b1d6dcf  vmovaps xmm13, [rsp+0xC0]
000076049b1d6dd8  vmovaps xmm14, [rsp+0xD0]
000076049b1d6de1  vmovaps xmm15, [rsp+0xE0]
000076049b1d6dea  add rsp, 0xF0
000076049b1d6df1  pop r11
000076049b1d6df3  pop r10
000076049b1d6df5  pop r9
000076049b1d6df7  pop r8
000076049b1d6df9  pop rsi
000076049b1d6dfa  pop rdi
000076049b1d6dfb  pop rdx
000076049b1d6dfc  pop rcx
000076049b1d6dfd  pop rax
000076049b1d6dfe  add rsp, 0x08
000076049b1d6e02  jmp 0x000076049B1D5A27
000076049b1d6e07  sub rsp, 0x08
000076049b1d6e0b  push rax
000076049b1d6e0c  push rcx
000076049b1d6e0d  push rdx
000076049b1d6e0e  push rdi
000076049b1d6e0f  push rsi
000076049b1d6e10  push r8
000076049b1d6e12  push r9
000076049b1d6e14  push r10
000076049b1d6e16  push r11
000076049b1d6e18  sub rsp, 0xF0
000076049b1d6e1f  vmovaps [rsp], xmm0
000076049b1d6e24  vmovaps [rsp+0x10], xmm1
000076049b1d6e2a  vmovaps [rsp+0x20], xmm2
000076049b1d6e30  vmovaps [rsp+0x30], xmm4
000076049b1d6e36  vmovaps [rsp+0x40], xmm5
000076049b1d6e3c  vmovaps [rsp+0x50], xmm6
000076049b1d6e42  vmovaps [rsp+0x60], xmm7
000076049b1d6e48  vmovaps [rsp+0x70], xmm8
000076049b1d6e4e  vmovaps [rsp+0x80], xmm9
000076049b1d6e57  vmovaps [rsp+0x90], xmm10
000076049b1d6e60  vmovaps [rsp+0xA0], xmm11
000076049b1d6e69  vmovaps [rsp+0xB0], xmm12
000076049b1d6e72  vmovaps [rsp+0xC0], xmm13
000076049b1d6e7b  vmovaps [rsp+0xD0], xmm14
000076049b1d6e84  vmovaps [rsp+0xE0], xmm15
000076049b1d6e8d  sub rsp, 0x30
000076049b1d6e91  movaps [rsp], xmm3
000076049b1d6e95  movaps [rsp+0x10], xmm5
000076049b1d6e9a  movaps [rsp+0x20], xmm4
000076049b1d6e9f  lea rdi, [rsp]
000076049b1d6ea3  mov esi, 0x00
000076049b1d6ea8  mov rax, 0x64C06813C530
000076049b1d6eb2  call rax
000076049b1d6eb4  movaps xmm3, [rsp]
000076049b1d6eb8  add rsp, 0x30
000076049b1d6ebc  vmovaps xmm0, [rsp]
000076049b1d6ec1  vmovaps xmm1, [rsp+0x10]
000076049b1d6ec7  vmovaps xmm2, [rsp+0x20]
000076049b1d6ecd  vmovaps xmm4, [rsp+0x30]
000076049b1d6ed3  vmovaps xmm5, [rsp+0x40]
000076049b1d6ed9  vmovaps xmm6, [rsp+0x50]
000076049b1d6edf  vmovaps xmm7, [rsp+0x60]
000076049b1d6ee5  vmovaps xmm8, [rsp+0x70]
000076049b1d6eeb  vmovaps xmm9, [rsp+0x80]
000076049b1d6ef4  vmovaps xmm10, [rsp+0x90]
000076049b1d6efd  vmovaps xmm11, [rsp+0xA0]
000076049b1d6f06  vmovaps xmm12, [rsp+0xB0]
000076049b1d6f0f  vmovaps xmm13, [rsp+0xC0]
000076049b1d6f18  vmovaps xmm14, [rsp+0xD0]
000076049b1d6f21  vmovaps xmm15, [rsp+0xE0]
000076049b1d6f2a  add rsp, 0xF0
000076049b1d6f31  pop r11
000076049b1d6f33  pop r10
000076049b1d6f35  pop r9
000076049b1d6f37  pop r8
000076049b1d6f39  pop rsi
000076049b1d6f3a  pop rdi
000076049b1d6f3b  pop rdx
000076049b1d6f3c  pop rcx
000076049b1d6f3d  pop rax
000076049b1d6f3e  add rsp, 0x08
000076049b1d6f42  jmp 0x000076049B1D5A88
000076049b1d6f47  sub rsp, 0x08
000076049b1d6f4b  push rax
000076049b1d6f4c  push rcx
000076049b1d6f4d  push rdx
000076049b1d6f4e  push rdi
000076049b1d6f4f  push rsi
000076049b1d6f50  push r8
000076049b1d6f52  push r9
000076049b1d6f54  push r10
000076049b1d6f56  push r11
000076049b1d6f58  sub rsp, 0xF0
000076049b1d6f5f  vmovaps [rsp], xmm0
000076049b1d6f64  vmovaps [rsp+0x10], xmm1
000076049b1d6f6a  vmovaps [rsp+0x20], xmm2
000076049b1d6f70  vmovaps [rsp+0x30], xmm3
000076049b1d6f76  vmovaps [rsp+0x40], xmm4
000076049b1d6f7c  vmovaps [rsp+0x50], xmm6
000076049b1d6f82  vmovaps [rsp+0x60], xmm7
000076049b1d6f88  vmovaps [rsp+0x70], xmm8
000076049b1d6f8e  vmovaps [rsp+0x80], xmm9
000076049b1d6f97  vmovaps [rsp+0x90], xmm10
000076049b1d6fa0  vmovaps [rsp+0xA0], xmm11
000076049b1d6fa9  vmovaps [rsp+0xB0], xmm12
000076049b1d6fb2  vmovaps [rsp+0xC0], xmm13
000076049b1d6fbb  vmovaps [rsp+0xD0], xmm14
000076049b1d6fc4  vmovaps [rsp+0xE0], xmm15
000076049b1d6fcd  sub rsp, 0x30
000076049b1d6fd1  movaps [rsp], xmm5
000076049b1d6fd5  movaps [rsp+0x10], xmm8
000076049b1d6fdb  movaps [rsp+0x20], xmm15
000076049b1d6fe1  lea rdi, [rsp]
000076049b1d6fe5  mov esi, 0x00
000076049b1d6fea  mov rax, 0x64C06813C530
000076049b1d6ff4  call rax
000076049b1d6ff6  movaps xmm5, [rsp]
000076049b1d6ffa  add rsp, 0x30
000076049b1d6ffe  vmovaps xmm0, [rsp]
000076049b1d7003  vmovaps xmm1, [rsp+0x10]
000076049b1d7009  vmovaps xmm2, [rsp+0x20]
000076049b1d700f  vmovaps xmm3, [rsp+0x30]
000076049b1d7015  vmovaps xmm4, [rsp+0x40]
000076049b1d701b  vmovaps xmm6, [rsp+0x50]
000076049b1d7021  vmovaps xmm7, [rsp+0x60]
000076049b1d7027  vmovaps xmm8, [rsp+0x70]
000076049b1d702d  vmovaps xmm9, [rsp+0x80]
000076049b1d7036  vmovaps xmm10, [rsp+0x90]
000076049b1d703f  vmovaps xmm11, [rsp+0xA0]
000076049b1d7048  vmovaps xmm12, [rsp+0xB0]
000076049b1d7051  vmovaps xmm13, [rsp+0xC0]
000076049b1d705a  vmovaps xmm14, [rsp+0xD0]
000076049b1d7063  vmovaps xmm15, [rsp+0xE0]
000076049b1d706c  add rsp, 0xF0
000076049b1d7073  pop r11
000076049b1d7075  pop r10
000076049b1d7077  pop r9
000076049b1d7079  pop r8
000076049b1d707b  pop rsi
000076049b1d707c  pop rdi
000076049b1d707d  pop rdx
000076049b1d707e  pop rcx
000076049b1d707f  pop rax
000076049b1d7080  add rsp, 0x08
000076049b1d7084  jmp 0x000076049B1D5AC0
000076049b1d7089  sub rsp, 0x08
000076049b1d708d  push rax
000076049b1d708e  push rcx
000076049b1d708f  push rdx
000076049b1d7090  push rdi
000076049b1d7091  push rsi
000076049b1d7092  push r8
000076049b1d7094  push r9
000076049b1d7096  push r10
000076049b1d7098  push r11
000076049b1d709a  sub rsp, 0xF0
000076049b1d70a1  vmovaps [rsp], xmm0
000076049b1d70a6  vmovaps [rsp+0x10], xmm1
000076049b1d70ac  vmovaps [rsp+0x20], xmm2
000076049b1d70b2  vmovaps [rsp+0x30], xmm3
000076049b1d70b8  vmovaps [rsp+0x40], xmm5
000076049b1d70be  vmovaps [rsp+0x50], xmm6
000076049b1d70c4  vmovaps [rsp+0x60], xmm7
000076049b1d70ca  vmovaps [rsp+0x70], xmm8
000076049b1d70d0  vmovaps [rsp+0x80], xmm9
000076049b1d70d9  vmovaps [rsp+0x90], xmm10
000076049b1d70e2  vmovaps [rsp+0xA0], xmm11
000076049b1d70eb  vmovaps [rsp+0xB0], xmm12
000076049b1d70f4  vmovaps [rsp+0xC0], xmm13
000076049b1d70fd  vmovaps [rsp+0xD0], xmm14
000076049b1d7106  vmovaps [rsp+0xE0], xmm15
000076049b1d710f  sub rsp, 0x30
000076049b1d7113  movaps [rsp], xmm4
000076049b1d7117  movaps [rsp+0x10], xmm9
000076049b1d711d  movaps [rsp+0x20], xmm8
000076049b1d7123  lea rdi, [rsp]
000076049b1d7127  mov esi, 0x00
000076049b1d712c  mov rax, 0x64C06813C530
000076049b1d7136  call rax
000076049b1d7138  movaps xmm4, [rsp]
000076049b1d713c  add rsp, 0x30
000076049b1d7140  vmovaps xmm0, [rsp]
000076049b1d7145  vmovaps xmm1, [rsp+0x10]
000076049b1d714b  vmovaps xmm2, [rsp+0x20]
000076049b1d7151  vmovaps xmm3, [rsp+0x30]
000076049b1d7157  vmovaps xmm5, [rsp+0x40]
000076049b1d715d  vmovaps xmm6, [rsp+0x50]
000076049b1d7163  vmovaps xmm7, [rsp+0x60]
000076049b1d7169  vmovaps xmm8, [rsp+0x70]
000076049b1d716f  vmovaps xmm9, [rsp+0x80]
000076049b1d7178  vmovaps xmm10, [rsp+0x90]
000076049b1d7181  vmovaps xmm11, [rsp+0xA0]
000076049b1d718a  vmovaps xmm12, [rsp+0xB0]
000076049b1d7193  vmovaps xmm13, [rsp+0xC0]
000076049b1d719c  vmovaps xmm14, [rsp+0xD0]
000076049b1d71a5  vmovaps xmm15, [rsp+0xE0]
000076049b1d71ae  add rsp, 0xF0
000076049b1d71b5  pop r11
000076049b1d71b7  pop r10
000076049b1d71b9  pop r9
000076049b1d71bb  pop r8
000076049b1d71bd  pop rsi
000076049b1d71be  pop rdi
000076049b1d71bf  pop rdx
000076049b1d71c0  pop rcx
000076049b1d71c1  pop rax
000076049b1d71c2  add rsp, 0x08
000076049b1d71c6  jmp 0x000076049B1D5AE1
000076049b1d71cb  sub rsp, 0x08
000076049b1d71cf  push rax
000076049b1d71d0  push rcx
000076049b1d71d1  push rdx
000076049b1d71d2  push rdi
000076049b1d71d3  push rsi
000076049b1d71d4  push r8
000076049b1d71d6  push r9
000076049b1d71d8  push r10
000076049b1d71da  push r11
000076049b1d71dc  sub rsp, 0xF0
000076049b1d71e3  vmovaps [rsp], xmm0
000076049b1d71e8  vmovaps [rsp+0x10], xmm1
000076049b1d71ee  vmovaps [rsp+0x20], xmm2
000076049b1d71f4  vmovaps [rsp+0x30], xmm3
000076049b1d71fa  vmovaps [rsp+0x40], xmm4
000076049b1d7200  vmovaps [rsp+0x50], xmm5
000076049b1d7206  vmovaps [rsp+0x60], xmm6
000076049b1d720c  vmovaps [rsp+0x70], xmm7
000076049b1d7212  vmovaps [rsp+0x80], xmm8
000076049b1d721b  vmovaps [rsp+0x90], xmm10
000076049b1d7224  vmovaps [rsp+0xA0], xmm11
000076049b1d722d  vmovaps [rsp+0xB0], xmm12
000076049b1d7236  vmovaps [rsp+0xC0], xmm13
000076049b1d723f  vmovaps [rsp+0xD0], xmm14
000076049b1d7248  vmovaps [rsp+0xE0], xmm15
000076049b1d7251  sub rsp, 0x30
000076049b1d7255  movaps [rsp], xmm9
000076049b1d725a  movaps [rsp+0x10], xmm10
000076049b1d7260  movaps [rsp+0x20], xmm8
000076049b1d7266  lea rdi, [rsp]
000076049b1d726a  mov esi, 0x00
000076049b1d726f  mov rax, 0x64C06813C530
000076049b1d7279  call rax
000076049b1d727b  movaps xmm9, [rsp]
000076049b1d7280  add rsp, 0x30
000076049b1d7284  vmovaps xmm0, [rsp]
000076049b1d7289  vmovaps xmm1, [rsp+0x10]
000076049b1d728f  vmovaps xmm2, [rsp+0x20]
000076049b1d7295  vmovaps xmm3, [rsp+0x30]
000076049b1d729b  vmovaps xmm4, [rsp+0x40]
000076049b1d72a1  vmovaps xmm5, [rsp+0x50]
000076049b1d72a7  vmovaps xmm6, [rsp+0x60]
000076049b1d72ad  vmovaps xmm7, [rsp+0x70]
000076049b1d72b3  vmovaps xmm8, [rsp+0x80]
000076049b1d72bc  vmovaps xmm10, [rsp+0x90]
000076049b1d72c5  vmovaps xmm11, [rsp+0xA0]
000076049b1d72ce  vmovaps xmm12, [rsp+0xB0]
000076049b1d72d7  vmovaps xmm13, [rsp+0xC0]
000076049b1d72e0  vmovaps xmm14, [rsp+0xD0]
000076049b1d72e9  vmovaps xmm15, [rsp+0xE0]
000076049b1d72f2  add rsp, 0xF0
000076049b1d72f9  pop r11
000076049b1d72fb  pop r10
000076049b1d72fd  pop r9
000076049b1d72ff  pop r8
000076049b1d7301  pop rsi
000076049b1d7302  pop rdi
000076049b1d7303  pop rdx
000076049b1d7304  pop rcx
000076049b1d7305  pop rax
000076049b1d7306  add rsp, 0x08
000076049b1d730a  jmp 0x000076049B1D5AFB
000076049b1d730f  call 0x000076049B0D64F0
000076049b1d7314  jmp 0x000076049B1D5C15
000076049b1d7319  call 0x000076049B0D64F0
000076049b1d731e  jmp 0x000076049B1D5C2B
000076049b1d7323  sub rsp, 0x08
000076049b1d7327  push rax
000076049b1d7328  push rcx
000076049b1d7329  push rdx
000076049b1d732a  push rdi
000076049b1d732b  push rsi
000076049b1d732c  push r8
000076049b1d732e  push r9
000076049b1d7330  push r10
000076049b1d7332  push r11
000076049b1d7334  sub rsp, 0xF0
000076049b1d733b  vmovaps [rsp], xmm0
000076049b1d7340  vmovaps [rsp+0x10], xmm2
000076049b1d7346  vmovaps [rsp+0x20], xmm3
000076049b1d734c  vmovaps [rsp+0x30], xmm4
000076049b1d7352  vmovaps [rsp+0x40], xmm5
000076049b1d7358  vmovaps [rsp+0x50], xmm6
000076049b1d735e  vmovaps [rsp+0x60], xmm7
000076049b1d7364  vmovaps [rsp+0x70], xmm8
000076049b1d736a  vmovaps [rsp+0x80], xmm9
000076049b1d7373  vmovaps [rsp+0x90], xmm10
000076049b1d737c  vmovaps [rsp+0xA0], xmm11
000076049b1d7385  vmovaps [rsp+0xB0], xmm12
000076049b1d738e  vmovaps [rsp+0xC0], xmm13
000076049b1d7397  vmovaps [rsp+0xD0], xmm14
000076049b1d73a0  vmovaps [rsp+0xE0], xmm15
000076049b1d73a9  sub rsp, 0x30
000076049b1d73ad  movaps [rsp], xmm1
000076049b1d73b1  movaps [rsp+0x10], xmm6
000076049b1d73b6  movaps [rsp+0x20], xmm15
000076049b1d73bc  lea rdi, [rsp]
000076049b1d73c0  mov esi, 0x00
000076049b1d73c5  mov rax, 0x64C06813C530
000076049b1d73cf  call rax
000076049b1d73d1  movaps xmm1, [rsp]
000076049b1d73d5  add rsp, 0x30
000076049b1d73d9  vmovaps xmm0, [rsp]
000076049b1d73de  vmovaps xmm2, [rsp+0x10]
000076049b1d73e4  vmovaps xmm3, [rsp+0x20]
000076049b1d73ea  vmovaps xmm4, [rsp+0x30]
000076049b1d73f0  vmovaps xmm5, [rsp+0x40]
000076049b1d73f6  vmovaps xmm6, [rsp+0x50]
000076049b1d73fc  vmovaps xmm7, [rsp+0x60]
000076049b1d7402  vmovaps xmm8, [rsp+0x70]
000076049b1d7408  vmovaps xmm9, [rsp+0x80]
000076049b1d7411  vmovaps xmm10, [rsp+0x90]
000076049b1d741a  vmovaps xmm11, [rsp+0xA0]
000076049b1d7423  vmovaps xmm12, [rsp+0xB0]
000076049b1d742c  vmovaps xmm13, [rsp+0xC0]
000076049b1d7435  vmovaps xmm14, [rsp+0xD0]
000076049b1d743e  vmovaps xmm15, [rsp+0xE0]
000076049b1d7447  add rsp, 0xF0
000076049b1d744e  pop r11
000076049b1d7450  pop r10
000076049b1d7452  pop r9
000076049b1d7454  pop r8
000076049b1d7456  pop rsi
000076049b1d7457  pop rdi
000076049b1d7458  pop rdx
000076049b1d7459  pop rcx
000076049b1d745a  pop rax
000076049b1d745b  add rsp, 0x08
000076049b1d745f  jmp 0x000076049B1D5C68
000076049b1d7464  call 0x000076049B0E5820
000076049b1d7469  jmp 0x000076049B1D5C75
000076049b1d746e  sub rsp, 0x08
000076049b1d7472  push rax
000076049b1d7473  push rcx
000076049b1d7474  push rdx
000076049b1d7475  push rdi
000076049b1d7476  push rsi
000076049b1d7477  push r8
000076049b1d7479  push r9
000076049b1d747b  push r10
000076049b1d747d  push r11
000076049b1d747f  sub rsp, 0xF0
000076049b1d7486  vmovaps [rsp], xmm0
000076049b1d748b  vmovaps [rsp+0x10], xmm1
000076049b1d7491  vmovaps [rsp+0x20], xmm2
000076049b1d7497  vmovaps [rsp+0x30], xmm3
000076049b1d749d  vmovaps [rsp+0x40], xmm4
000076049b1d74a3  vmovaps [rsp+0x50], xmm5
000076049b1d74a9  vmovaps [rsp+0x60], xmm6
000076049b1d74af  vmovaps [rsp+0x70], xmm7
000076049b1d74b5  vmovaps [rsp+0x80], xmm8
000076049b1d74be  vmovaps [rsp+0x90], xmm9
000076049b1d74c7  vmovaps [rsp+0xA0], xmm10
000076049b1d74d0  vmovaps [rsp+0xB0], xmm11
000076049b1d74d9  vmovaps [rsp+0xC0], xmm12
000076049b1d74e2  vmovaps [rsp+0xD0], xmm13
000076049b1d74eb  vmovaps [rsp+0xE0], xmm15
000076049b1d74f4  sub rsp, 0x30
000076049b1d74f8  movaps [rsp], xmm14
000076049b1d74fd  movaps [rsp+0x10], xmm4
000076049b1d7502  movaps [rsp+0x20], xmm3
000076049b1d7507  lea rdi, [rsp]
000076049b1d750b  mov esi, 0x00
000076049b1d7510  mov rax, 0x64C06813C530
000076049b1d751a  call rax
000076049b1d751c  movaps xmm14, [rsp]
000076049b1d7521  add rsp, 0x30
000076049b1d7525  vmovaps xmm0, [rsp]
000076049b1d752a  vmovaps xmm1, [rsp+0x10]
000076049b1d7530  vmovaps xmm2, [rsp+0x20]
000076049b1d7536  vmovaps xmm3, [rsp+0x30]
000076049b1d753c  vmovaps xmm4, [rsp+0x40]
000076049b1d7542  vmovaps xmm5, [rsp+0x50]
000076049b1d7548  vmovaps xmm6, [rsp+0x60]
000076049b1d754e  vmovaps xmm7, [rsp+0x70]
000076049b1d7554  vmovaps xmm8, [rsp+0x80]
000076049b1d755d  vmovaps xmm9, [rsp+0x90]
000076049b1d7566  vmovaps xmm10, [rsp+0xA0]
000076049b1d756f  vmovaps xmm11, [rsp+0xB0]
000076049b1d7578  vmovaps xmm12, [rsp+0xC0]
000076049b1d7581  vmovaps xmm13, [rsp+0xD0]
000076049b1d758a  vmovaps xmm15, [rsp+0xE0]
000076049b1d7593  add rsp, 0xF0
000076049b1d759a  pop r11
000076049b1d759c  pop r10
000076049b1d759e  pop r9
000076049b1d75a0  pop r8
000076049b1d75a2  pop rsi
000076049b1d75a3  pop rdi
000076049b1d75a4  pop rdx
000076049b1d75a5  pop rcx
000076049b1d75a6  pop rax
000076049b1d75a7  add rsp, 0x08
000076049b1d75ab  jmp 0x000076049B1D5C8F
000076049b1d75b0  sub rsp, 0x08
000076049b1d75b4  push rax
000076049b1d75b5  push rcx
000076049b1d75b6  push rdx
000076049b1d75b7  push rdi
000076049b1d75b8  push rsi
000076049b1d75b9  push r8
000076049b1d75bb  push r9
000076049b1d75bd  push r10
000076049b1d75bf  push r11
000076049b1d75c1  sub rsp, 0xF0
000076049b1d75c8  vmovaps [rsp], xmm0
000076049b1d75cd  vmovaps [rsp+0x10], xmm1
000076049b1d75d3  vmovaps [rsp+0x20], xmm2
000076049b1d75d9  vmovaps [rsp+0x30], xmm3
000076049b1d75df  vmovaps [rsp+0x40], xmm4
000076049b1d75e5  vmovaps [rsp+0x50], xmm5
000076049b1d75eb  vmovaps [rsp+0x60], xmm7
000076049b1d75f1  vmovaps [rsp+0x70], xmm8
000076049b1d75f7  vmovaps [rsp+0x80], xmm9
000076049b1d7600  vmovaps [rsp+0x90], xmm10
000076049b1d7609  vmovaps [rsp+0xA0], xmm11
000076049b1d7612  vmovaps [rsp+0xB0], xmm12
000076049b1d761b  vmovaps [rsp+0xC0], xmm13
000076049b1d7624  vmovaps [rsp+0xD0], xmm14
000076049b1d762d  vmovaps [rsp+0xE0], xmm15
000076049b1d7636  sub rsp, 0x30
000076049b1d763a  movaps [rsp], xmm6
000076049b1d763e  movaps [rsp+0x10], xmm9
000076049b1d7644  movaps [rsp+0x20], xmm7
000076049b1d7649  lea rdi, [rsp]
000076049b1d764d  mov esi, 0x00
000076049b1d7652  mov rax, 0x64C06813C530
000076049b1d765c  call rax
000076049b1d765e  movaps xmm6, [rsp]
000076049b1d7662  add rsp, 0x30
000076049b1d7666  vmovaps xmm0, [rsp]
000076049b1d766b  vmovaps xmm1, [rsp+0x10]
000076049b1d7671  vmovaps xmm2, [rsp+0x20]
000076049b1d7677  vmovaps xmm3, [rsp+0x30]
000076049b1d767d  vmovaps xmm4, [rsp+0x40]
000076049b1d7683  vmovaps xmm5, [rsp+0x50]
000076049b1d7689  vmovaps xmm7, [rsp+0x60]
000076049b1d768f  vmovaps xmm8, [rsp+0x70]
000076049b1d7695  vmovaps xmm9, [rsp+0x80]
000076049b1d769e  vmovaps xmm10, [rsp+0x90]
000076049b1d76a7  vmovaps xmm11, [rsp+0xA0]
000076049b1d76b0  vmovaps xmm12, [rsp+0xB0]
000076049b1d76b9  vmovaps xmm13, [rsp+0xC0]
000076049b1d76c2  vmovaps xmm14, [rsp+0xD0]
000076049b1d76cb  vmovaps xmm15, [rsp+0xE0]
000076049b1d76d4  add rsp, 0xF0
000076049b1d76db  pop r11
000076049b1d76dd  pop r10
000076049b1d76df  pop r9
000076049b1d76e1  pop r8
000076049b1d76e3  pop rsi
000076049b1d76e4  pop rdi
000076049b1d76e5  pop rdx
000076049b1d76e6  pop rcx
000076049b1d76e7  pop rax
000076049b1d76e8  add rsp, 0x08
000076049b1d76ec  jmp 0x000076049B1D5CA7
000076049b1d76f1  sub rsp, 0x08
000076049b1d76f5  push rax
000076049b1d76f6  push rcx
000076049b1d76f7  push rdx
000076049b1d76f8  push rdi
000076049b1d76f9  push rsi
000076049b1d76fa  push r8
000076049b1d76fc  push r9
000076049b1d76fe  push r10
000076049b1d7700  push r11
000076049b1d7702  sub rsp, 0xF0
000076049b1d7709  vmovaps [rsp], xmm0
000076049b1d770e  vmovaps [rsp+0x10], xmm1
000076049b1d7714  vmovaps [rsp+0x20], xmm2
000076049b1d771a  vmovaps [rsp+0x30], xmm3
000076049b1d7720  vmovaps [rsp+0x40], xmm4
000076049b1d7726  vmovaps [rsp+0x50], xmm5
000076049b1d772c  vmovaps [rsp+0x60], xmm6
000076049b1d7732  vmovaps [rsp+0x70], xmm8
000076049b1d7738  vmovaps [rsp+0x80], xmm9
000076049b1d7741  vmovaps [rsp+0x90], xmm10
000076049b1d774a  vmovaps [rsp+0xA0], xmm11
000076049b1d7753  vmovaps [rsp+0xB0], xmm12
000076049b1d775c  vmovaps [rsp+0xC0], xmm13
000076049b1d7765  vmovaps [rsp+0xD0], xmm14
000076049b1d776e  vmovaps [rsp+0xE0], xmm15
000076049b1d7777  sub rsp, 0x30
000076049b1d777b  movaps [rsp], xmm7
000076049b1d777f  movaps [rsp+0x10], xmm4
000076049b1d7784  movaps [rsp+0x20], xmm9
000076049b1d778a  lea rdi, [rsp]
000076049b1d778e  mov esi, 0x00
000076049b1d7793  mov rax, 0x64C06813C530
000076049b1d779d  call rax
000076049b1d779f  movaps xmm7, [rsp]
000076049b1d77a3  add rsp, 0x30
000076049b1d77a7  vmovaps xmm0, [rsp]
000076049b1d77ac  vmovaps xmm1, [rsp+0x10]
000076049b1d77b2  vmovaps xmm2, [rsp+0x20]
000076049b1d77b8  vmovaps xmm3, [rsp+0x30]
000076049b1d77be  vmovaps xmm4, [rsp+0x40]
000076049b1d77c4  vmovaps xmm5, [rsp+0x50]
000076049b1d77ca  vmovaps xmm6, [rsp+0x60]
000076049b1d77d0  vmovaps xmm8, [rsp+0x70]
000076049b1d77d6  vmovaps xmm9, [rsp+0x80]
000076049b1d77df  vmovaps xmm10, [rsp+0x90]
000076049b1d77e8  vmovaps xmm11, [rsp+0xA0]
000076049b1d77f1  vmovaps xmm12, [rsp+0xB0]
000076049b1d77fa  vmovaps xmm13, [rsp+0xC0]
000076049b1d7803  vmovaps xmm14, [rsp+0xD0]
000076049b1d780c  vmovaps xmm15, [rsp+0xE0]
000076049b1d7815  add rsp, 0xF0
000076049b1d781c  pop r11
000076049b1d781e  pop r10
000076049b1d7820  pop r9
000076049b1d7822  pop r8
000076049b1d7824  pop rsi
000076049b1d7825  pop rdi
000076049b1d7826  pop rdx
000076049b1d7827  pop rcx
000076049b1d7828  pop rax
000076049b1d7829  add rsp, 0x08
000076049b1d782d  jmp 0x000076049B1D5CD4
000076049b1d7832  sub rsp, 0x08
000076049b1d7836  push rax
000076049b1d7837  push rcx
000076049b1d7838  push rdx
000076049b1d7839  push rdi
000076049b1d783a  push rsi
000076049b1d783b  push r8
000076049b1d783d  push r9
000076049b1d783f  push r10
000076049b1d7841  push r11
000076049b1d7843  sub rsp, 0xF0
000076049b1d784a  vmovaps [rsp], xmm0
000076049b1d784f  vmovaps [rsp+0x10], xmm1
000076049b1d7855  vmovaps [rsp+0x20], xmm2
000076049b1d785b  vmovaps [rsp+0x30], xmm3
000076049b1d7861  vmovaps [rsp+0x40], xmm5
000076049b1d7867  vmovaps [rsp+0x50], xmm6
000076049b1d786d  vmovaps [rsp+0x60], xmm7
000076049b1d7873  vmovaps [rsp+0x70], xmm8
000076049b1d7879  vmovaps [rsp+0x80], xmm9
000076049b1d7882  vmovaps [rsp+0x90], xmm10
000076049b1d788b  vmovaps [rsp+0xA0], xmm11
000076049b1d7894  vmovaps [rsp+0xB0], xmm12
000076049b1d789d  vmovaps [rsp+0xC0], xmm13
000076049b1d78a6  vmovaps [rsp+0xD0], xmm14
000076049b1d78af  vmovaps [rsp+0xE0], xmm15
000076049b1d78b8  sub rsp, 0x30
000076049b1d78bc  movaps [rsp], xmm4
000076049b1d78c0  movaps [rsp+0x10], xmm15
000076049b1d78c6  movaps [rsp+0x20], xmm9
000076049b1d78cc  lea rdi, [rsp]
000076049b1d78d0  mov esi, 0x00
000076049b1d78d5  mov rax, 0x64C06813C530
000076049b1d78df  call rax
000076049b1d78e1  movaps xmm4, [rsp]
000076049b1d78e5  add rsp, 0x30
000076049b1d78e9  vmovaps xmm0, [rsp]
000076049b1d78ee  vmovaps xmm1, [rsp+0x10]
000076049b1d78f4  vmovaps xmm2, [rsp+0x20]
000076049b1d78fa  vmovaps xmm3, [rsp+0x30]
000076049b1d7900  vmovaps xmm5, [rsp+0x40]
000076049b1d7906  vmovaps xmm6, [rsp+0x50]
000076049b1d790c  vmovaps xmm7, [rsp+0x60]
000076049b1d7912  vmovaps xmm8, [rsp+0x70]
000076049b1d7918  vmovaps xmm9, [rsp+0x80]
000076049b1d7921  vmovaps xmm10, [rsp+0x90]
000076049b1d792a  vmovaps xmm11, [rsp+0xA0]
000076049b1d7933  vmovaps xmm12, [rsp+0xB0]
000076049b1d793c  vmovaps xmm13, [rsp+0xC0]
000076049b1d7945  vmovaps xmm14, [rsp+0xD0]
000076049b1d794e  vmovaps xmm15, [rsp+0xE0]
000076049b1d7957  add rsp, 0xF0
000076049b1d795e  pop r11
000076049b1d7960  pop r10
000076049b1d7962  pop r9
000076049b1d7964  pop r8
000076049b1d7966  pop rsi
000076049b1d7967  pop rdi
000076049b1d7968  pop rdx
000076049b1d7969  pop rcx
000076049b1d796a  pop rax
000076049b1d796b  add rsp, 0x08
000076049b1d796f  jmp 0x000076049B1D5CF9
000076049b1d7974  call 0x000076049B0E5820
000076049b1d7979  jmp 0x000076049B1D5D06
000076049b1d797e  sub rsp, 0x08
000076049b1d7982  push rax
000076049b1d7983  push rcx
000076049b1d7984  push rdx
000076049b1d7985  push rdi
000076049b1d7986  push rsi
000076049b1d7987  push r8
000076049b1d7989  push r9
000076049b1d798b  push r10
000076049b1d798d  push r11
000076049b1d798f  sub rsp, 0xF0
000076049b1d7996  vmovaps [rsp], xmm0
000076049b1d799b  vmovaps [rsp+0x10], xmm1
000076049b1d79a1  vmovaps [rsp+0x20], xmm2
000076049b1d79a7  vmovaps [rsp+0x30], xmm4
000076049b1d79ad  vmovaps [rsp+0x40], xmm5
000076049b1d79b3  vmovaps [rsp+0x50], xmm6
000076049b1d79b9  vmovaps [rsp+0x60], xmm7
000076049b1d79bf  vmovaps [rsp+0x70], xmm8
000076049b1d79c5  vmovaps [rsp+0x80], xmm9
000076049b1d79ce  vmovaps [rsp+0x90], xmm10
000076049b1d79d7  vmovaps [rsp+0xA0], xmm11
000076049b1d79e0  vmovaps [rsp+0xB0], xmm12
000076049b1d79e9  vmovaps [rsp+0xC0], xmm13
000076049b1d79f2  vmovaps [rsp+0xD0], xmm14
000076049b1d79fb  vmovaps [rsp+0xE0], xmm15
000076049b1d7a04  sub rsp, 0x30
000076049b1d7a08  movaps [rsp], xmm3
000076049b1d7a0c  movaps [rsp+0x10], xmm1
000076049b1d7a11  movaps [rsp+0x20], xmm9
000076049b1d7a17  lea rdi, [rsp]
000076049b1d7a1b  mov esi, 0x00
000076049b1d7a20  mov rax, 0x64C06813C530
000076049b1d7a2a  call rax
000076049b1d7a2c  movaps xmm3, [rsp]
000076049b1d7a30  add rsp, 0x30
000076049b1d7a34  vmovaps xmm0, [rsp]
000076049b1d7a39  vmovaps xmm1, [rsp+0x10]
000076049b1d7a3f  vmovaps xmm2, [rsp+0x20]
000076049b1d7a45  vmovaps xmm4, [rsp+0x30]
000076049b1d7a4b  vmovaps xmm5, [rsp+0x40]
000076049b1d7a51  vmovaps xmm6, [rsp+0x50]
000076049b1d7a57  vmovaps xmm7, [rsp+0x60]
000076049b1d7a5d  vmovaps xmm8, [rsp+0x70]
000076049b1d7a63  vmovaps xmm9, [rsp+0x80]
000076049b1d7a6c  vmovaps xmm10, [rsp+0x90]
000076049b1d7a75  vmovaps xmm11, [rsp+0xA0]
000076049b1d7a7e  vmovaps xmm12, [rsp+0xB0]
000076049b1d7a87  vmovaps xmm13, [rsp+0xC0]
000076049b1d7a90  vmovaps xmm14, [rsp+0xD0]
000076049b1d7a99  vmovaps xmm15, [rsp+0xE0]
000076049b1d7aa2  add rsp, 0xF0
000076049b1d7aa9  pop r11
000076049b1d7aab  pop r10
000076049b1d7aad  pop r9
000076049b1d7aaf  pop r8
000076049b1d7ab1  pop rsi
000076049b1d7ab2  pop rdi
000076049b1d7ab3  pop rdx
000076049b1d7ab4  pop rcx
000076049b1d7ab5  pop rax
000076049b1d7ab6  add rsp, 0x08
000076049b1d7aba  jmp 0x000076049B1D5D43
000076049b1d7abf  sub rsp, 0x08
000076049b1d7ac3  push rax
000076049b1d7ac4  push rcx
000076049b1d7ac5  push rdx
000076049b1d7ac6  push rdi
000076049b1d7ac7  push rsi
000076049b1d7ac8  push r8
000076049b1d7aca  push r9
000076049b1d7acc  push r10
000076049b1d7ace  push r11
000076049b1d7ad0  sub rsp, 0xF0
000076049b1d7ad7  vmovaps [rsp], xmm0
000076049b1d7adc  vmovaps [rsp+0x10], xmm2
000076049b1d7ae2  vmovaps [rsp+0x20], xmm3
000076049b1d7ae8  vmovaps [rsp+0x30], xmm4
000076049b1d7aee  vmovaps [rsp+0x40], xmm5
000076049b1d7af4  vmovaps [rsp+0x50], xmm6
000076049b1d7afa  vmovaps [rsp+0x60], xmm7
000076049b1d7b00  vmovaps [rsp+0x70], xmm8
000076049b1d7b06  vmovaps [rsp+0x80], xmm9
000076049b1d7b0f  vmovaps [rsp+0x90], xmm10
000076049b1d7b18  vmovaps [rsp+0xA0], xmm11
000076049b1d7b21  vmovaps [rsp+0xB0], xmm12
000076049b1d7b2a  vmovaps [rsp+0xC0], xmm13
000076049b1d7b33  vmovaps [rsp+0xD0], xmm14
000076049b1d7b3c  vmovaps [rsp+0xE0], xmm15
000076049b1d7b45  sub rsp, 0x30
000076049b1d7b49  movaps [rsp], xmm1
000076049b1d7b4d  movaps [rsp+0x10], xmm15
000076049b1d7b53  movaps [rsp+0x20], xmm9
000076049b1d7b59  lea rdi, [rsp]
000076049b1d7b5d  mov esi, 0x00
000076049b1d7b62  mov rax, 0x64C06813C530
000076049b1d7b6c  call rax
000076049b1d7b6e  movaps xmm1, [rsp]
000076049b1d7b72  add rsp, 0x30
000076049b1d7b76  vmovaps xmm0, [rsp]
000076049b1d7b7b  vmovaps xmm2, [rsp+0x10]
000076049b1d7b81  vmovaps xmm3, [rsp+0x20]
000076049b1d7b87  vmovaps xmm4, [rsp+0x30]
000076049b1d7b8d  vmovaps xmm5, [rsp+0x40]
000076049b1d7b93  vmovaps xmm6, [rsp+0x50]
000076049b1d7b99  vmovaps xmm7, [rsp+0x60]
000076049b1d7b9f  vmovaps xmm8, [rsp+0x70]
000076049b1d7ba5  vmovaps xmm9, [rsp+0x80]
000076049b1d7bae  vmovaps xmm10, [rsp+0x90]
000076049b1d7bb7  vmovaps xmm11, [rsp+0xA0]
000076049b1d7bc0  vmovaps xmm12, [rsp+0xB0]
000076049b1d7bc9  vmovaps xmm13, [rsp+0xC0]
000076049b1d7bd2  vmovaps xmm14, [rsp+0xD0]
000076049b1d7bdb  vmovaps xmm15, [rsp+0xE0]
000076049b1d7be4  add rsp, 0xF0
000076049b1d7beb  pop r11
000076049b1d7bed  pop r10
000076049b1d7bef  pop r9
000076049b1d7bf1  pop r8
000076049b1d7bf3  pop rsi
000076049b1d7bf4  pop rdi
000076049b1d7bf5  pop rdx
000076049b1d7bf6  pop rcx
000076049b1d7bf7  pop rax
000076049b1d7bf8  add rsp, 0x08
000076049b1d7bfc  jmp 0x000076049B1D5DCB
000076049b1d7c01  call 0x000076049B0E5820
000076049b1d7c06  jmp 0x000076049B1D5DD8
000076049b1d7c0b  sub rsp, 0x08
000076049b1d7c0f  push rax
000076049b1d7c10  push rcx
000076049b1d7c11  push rdx
000076049b1d7c12  push rdi
000076049b1d7c13  push rsi
000076049b1d7c14  push r8
000076049b1d7c16  push r9
000076049b1d7c18  push r10
000076049b1d7c1a  push r11
000076049b1d7c1c  sub rsp, 0xF0
000076049b1d7c23  vmovaps [rsp], xmm0
000076049b1d7c28  vmovaps [rsp+0x10], xmm2
000076049b1d7c2e  vmovaps [rsp+0x20], xmm3
000076049b1d7c34  vmovaps [rsp+0x30], xmm4
000076049b1d7c3a  vmovaps [rsp+0x40], xmm5
000076049b1d7c40  vmovaps [rsp+0x50], xmm6
000076049b1d7c46  vmovaps [rsp+0x60], xmm7
000076049b1d7c4c  vmovaps [rsp+0x70], xmm8
000076049b1d7c52  vmovaps [rsp+0x80], xmm9
000076049b1d7c5b  vmovaps [rsp+0x90], xmm10
000076049b1d7c64  vmovaps [rsp+0xA0], xmm11
000076049b1d7c6d  vmovaps [rsp+0xB0], xmm12
000076049b1d7c76  vmovaps [rsp+0xC0], xmm13
000076049b1d7c7f  vmovaps [rsp+0xD0], xmm14
000076049b1d7c88  vmovaps [rsp+0xE0], xmm15
000076049b1d7c91  sub rsp, 0x30
000076049b1d7c95  movaps [rsp], xmm1
000076049b1d7c99  movaps [rsp+0x10], xmm5
000076049b1d7c9e  movaps [rsp+0x20], xmm7
000076049b1d7ca3  lea rdi, [rsp]
000076049b1d7ca7  mov esi, 0x00
000076049b1d7cac  mov rax, 0x64C06813C530
000076049b1d7cb6  call rax
000076049b1d7cb8  movaps xmm1, [rsp]
000076049b1d7cbc  add rsp, 0x30
000076049b1d7cc0  vmovaps xmm0, [rsp]
000076049b1d7cc5  vmovaps xmm2, [rsp+0x10]
000076049b1d7ccb  vmovaps xmm3, [rsp+0x20]
000076049b1d7cd1  vmovaps xmm4, [rsp+0x30]
000076049b1d7cd7  vmovaps xmm5, [rsp+0x40]
000076049b1d7cdd  vmovaps xmm6, [rsp+0x50]
000076049b1d7ce3  vmovaps xmm7, [rsp+0x60]
000076049b1d7ce9  vmovaps xmm8, [rsp+0x70]
000076049b1d7cef  vmovaps xmm9, [rsp+0x80]
000076049b1d7cf8  vmovaps xmm10, [rsp+0x90]
000076049b1d7d01  vmovaps xmm11, [rsp+0xA0]
000076049b1d7d0a  vmovaps xmm12, [rsp+0xB0]
000076049b1d7d13  vmovaps xmm13, [rsp+0xC0]
000076049b1d7d1c  vmovaps xmm14, [rsp+0xD0]
000076049b1d7d25  vmovaps xmm15, [rsp+0xE0]
000076049b1d7d2e  add rsp, 0xF0
000076049b1d7d35  pop r11
000076049b1d7d37  pop r10
000076049b1d7d39  pop r9
000076049b1d7d3b  pop r8
000076049b1d7d3d  pop rsi
000076049b1d7d3e  pop rdi
000076049b1d7d3f  pop rdx
000076049b1d7d40  pop rcx
000076049b1d7d41  pop rax
000076049b1d7d42  add rsp, 0x08
000076049b1d7d46  jmp 0x000076049B1D5E7D
000076049b1d7d4b  sub rsp, 0x08
000076049b1d7d4f  push rax
000076049b1d7d50  push rcx
000076049b1d7d51  push rdx
000076049b1d7d52  push rdi
000076049b1d7d53  push rsi
000076049b1d7d54  push r8
000076049b1d7d56  push r9
000076049b1d7d58  push r10
000076049b1d7d5a  push r11
000076049b1d7d5c  sub rsp, 0xF0
000076049b1d7d63  vmovaps [rsp], xmm0
000076049b1d7d68  vmovaps [rsp+0x10], xmm1
000076049b1d7d6e  vmovaps [rsp+0x20], xmm2
000076049b1d7d74  vmovaps [rsp+0x30], xmm3
000076049b1d7d7a  vmovaps [rsp+0x40], xmm4
000076049b1d7d80  vmovaps [rsp+0x50], xmm5
000076049b1d7d86  vmovaps [rsp+0x60], xmm6
000076049b1d7d8c  vmovaps [rsp+0x70], xmm8
000076049b1d7d92  vmovaps [rsp+0x80], xmm9
000076049b1d7d9b  vmovaps [rsp+0x90], xmm10
000076049b1d7da4  vmovaps [rsp+0xA0], xmm11
000076049b1d7dad  vmovaps [rsp+0xB0], xmm12
000076049b1d7db6  vmovaps [rsp+0xC0], xmm13
000076049b1d7dbf  vmovaps [rsp+0xD0], xmm14
000076049b1d7dc8  vmovaps [rsp+0xE0], xmm15
000076049b1d7dd1  sub rsp, 0x30
000076049b1d7dd5  movaps [rsp], xmm7
000076049b1d7dd9  movaps [rsp+0x10], xmm5
000076049b1d7dde  movaps [rsp+0x20], xmm15
000076049b1d7de4  lea rdi, [rsp]
000076049b1d7de8  mov esi, 0x00
000076049b1d7ded  mov rax, 0x64C06813C530
000076049b1d7df7  call rax
000076049b1d7df9  movaps xmm7, [rsp]
000076049b1d7dfd  add rsp, 0x30
000076049b1d7e01  vmovaps xmm0, [rsp]
000076049b1d7e06  vmovaps xmm1, [rsp+0x10]
000076049b1d7e0c  vmovaps xmm2, [rsp+0x20]
000076049b1d7e12  vmovaps xmm3, [rsp+0x30]
000076049b1d7e18  vmovaps xmm4, [rsp+0x40]
000076049b1d7e1e  vmovaps xmm5, [rsp+0x50]
000076049b1d7e24  vmovaps xmm6, [rsp+0x60]
000076049b1d7e2a  vmovaps xmm8, [rsp+0x70]
000076049b1d7e30  vmovaps xmm9, [rsp+0x80]
000076049b1d7e39  vmovaps xmm10, [rsp+0x90]
000076049b1d7e42  vmovaps xmm11, [rsp+0xA0]
000076049b1d7e4b  vmovaps xmm12, [rsp+0xB0]
000076049b1d7e54  vmovaps xmm13, [rsp+0xC0]
000076049b1d7e5d  vmovaps xmm14, [rsp+0xD0]
000076049b1d7e66  vmovaps xmm15, [rsp+0xE0]
000076049b1d7e6f  add rsp, 0xF0
000076049b1d7e76  pop r11
000076049b1d7e78  pop r10
000076049b1d7e7a  pop r9
000076049b1d7e7c  pop r8
000076049b1d7e7e  pop rsi
000076049b1d7e7f  pop rdi
000076049b1d7e80  pop rdx
000076049b1d7e81  pop rcx
000076049b1d7e82  pop rax
000076049b1d7e83  add rsp, 0x08
000076049b1d7e87  jmp 0x000076049B1D5EB3
000076049b1d7e8c  call 0x000076049B0D64F0
000076049b1d7e91  jmp 0x000076049B1D5EC0
000076049b1d7e96  sub rsp, 0x08
000076049b1d7e9a  push rax
000076049b1d7e9b  push rcx
000076049b1d7e9c  push rdx
000076049b1d7e9d  push rdi
000076049b1d7e9e  push rsi
000076049b1d7e9f  push r8
000076049b1d7ea1  push r9
000076049b1d7ea3  push r10
000076049b1d7ea5  push r11
000076049b1d7ea7  sub rsp, 0xF0
000076049b1d7eae  vmovaps [rsp], xmm0
000076049b1d7eb3  vmovaps [rsp+0x10], xmm1
000076049b1d7eb9  vmovaps [rsp+0x20], xmm2
000076049b1d7ebf  vmovaps [rsp+0x30], xmm3
000076049b1d7ec5  vmovaps [rsp+0x40], xmm4
000076049b1d7ecb  vmovaps [rsp+0x50], xmm5
000076049b1d7ed1  vmovaps [rsp+0x60], xmm6
000076049b1d7ed7  vmovaps [rsp+0x70], xmm7
000076049b1d7edd  vmovaps [rsp+0x80], xmm8
000076049b1d7ee6  vmovaps [rsp+0x90], xmm9
000076049b1d7eef  vmovaps [rsp+0xA0], xmm10
000076049b1d7ef8  vmovaps [rsp+0xB0], xmm11
000076049b1d7f01  vmovaps [rsp+0xC0], xmm12
000076049b1d7f0a  vmovaps [rsp+0xD0], xmm13
000076049b1d7f13  vmovaps [rsp+0xE0], xmm14
000076049b1d7f1c  sub rsp, 0x30
000076049b1d7f20  movaps [rsp], xmm15
000076049b1d7f25  movaps [rsp+0x10], xmm5
000076049b1d7f2a  movaps [rsp+0x20], xmm3
000076049b1d7f2f  lea rdi, [rsp]
000076049b1d7f33  mov esi, 0x00
000076049b1d7f38  mov rax, 0x64C06813C530
000076049b1d7f42  call rax
000076049b1d7f44  movaps xmm15, [rsp]
000076049b1d7f49  add rsp, 0x30
000076049b1d7f4d  vmovaps xmm0, [rsp]
000076049b1d7f52  vmovaps xmm1, [rsp+0x10]
000076049b1d7f58  vmovaps xmm2, [rsp+0x20]
000076049b1d7f5e  vmovaps xmm3, [rsp+0x30]
000076049b1d7f64  vmovaps xmm4, [rsp+0x40]
000076049b1d7f6a  vmovaps xmm5, [rsp+0x50]
000076049b1d7f70  vmovaps xmm6, [rsp+0x60]
000076049b1d7f76  vmovaps xmm7, [rsp+0x70]
000076049b1d7f7c  vmovaps xmm8, [rsp+0x80]
000076049b1d7f85  vmovaps xmm9, [rsp+0x90]
000076049b1d7f8e  vmovaps xmm10, [rsp+0xA0]
000076049b1d7f97  vmovaps xmm11, [rsp+0xB0]
000076049b1d7fa0  vmovaps xmm12, [rsp+0xC0]
000076049b1d7fa9  vmovaps xmm13, [rsp+0xD0]
000076049b1d7fb2  vmovaps xmm14, [rsp+0xE0]
000076049b1d7fbb  add rsp, 0xF0
000076049b1d7fc2  pop r11
000076049b1d7fc4  pop r10
000076049b1d7fc6  pop r9
000076049b1d7fc8  pop r8
000076049b1d7fca  pop rsi
000076049b1d7fcb  pop rdi
000076049b1d7fcc  pop rdx
000076049b1d7fcd  pop rcx
000076049b1d7fce  pop rax
000076049b1d7fcf  add rsp, 0x08
000076049b1d7fd3  jmp 0x000076049B1D5EE6
000076049b1d7fd8  sub rsp, 0x08
000076049b1d7fdc  push rax
000076049b1d7fdd  push rcx
000076049b1d7fde  push rdx
000076049b1d7fdf  push rdi
000076049b1d7fe0  push rsi
000076049b1d7fe1  push r8
000076049b1d7fe3  push r9
000076049b1d7fe5  push r10
000076049b1d7fe7  push r11
000076049b1d7fe9  sub rsp, 0xF0
000076049b1d7ff0  vmovaps [rsp], xmm0
000076049b1d7ff5  vmovaps [rsp+0x10], xmm2
000076049b1d7ffb  vmovaps [rsp+0x20], xmm3
000076049b1d8001  vmovaps [rsp+0x30], xmm4
000076049b1d8007  vmovaps [rsp+0x40], xmm5
000076049b1d800d  vmovaps [rsp+0x50], xmm6
000076049b1d8013  vmovaps [rsp+0x60], xmm7
000076049b1d8019  vmovaps [rsp+0x70], xmm8
000076049b1d801f  vmovaps [rsp+0x80], xmm9
000076049b1d8028  vmovaps [rsp+0x90], xmm10
000076049b1d8031  vmovaps [rsp+0xA0], xmm11
000076049b1d803a  vmovaps [rsp+0xB0], xmm12
000076049b1d8043  vmovaps [rsp+0xC0], xmm13
000076049b1d804c  vmovaps [rsp+0xD0], xmm14
000076049b1d8055  vmovaps [rsp+0xE0], xmm15
000076049b1d805e  sub rsp, 0x30
000076049b1d8062  movaps [rsp], xmm1
000076049b1d8066  movaps [rsp+0x10], xmm5
000076049b1d806b  movaps [rsp+0x20], xmm4
000076049b1d8070  lea rdi, [rsp]
000076049b1d8074  mov esi, 0x00
000076049b1d8079  mov rax, 0x64C06813C530
000076049b1d8083  call rax
000076049b1d8085  movaps xmm1, [rsp]
000076049b1d8089  add rsp, 0x30
000076049b1d808d  vmovaps xmm0, [rsp]
000076049b1d8092  vmovaps xmm2, [rsp+0x10]
000076049b1d8098  vmovaps xmm3, [rsp+0x20]
000076049b1d809e  vmovaps xmm4, [rsp+0x30]
000076049b1d80a4  vmovaps xmm5, [rsp+0x40]
000076049b1d80aa  vmovaps xmm6, [rsp+0x50]
000076049b1d80b0  vmovaps xmm7, [rsp+0x60]
000076049b1d80b6  vmovaps xmm8, [rsp+0x70]
000076049b1d80bc  vmovaps xmm9, [rsp+0x80]
000076049b1d80c5  vmovaps xmm10, [rsp+0x90]
000076049b1d80ce  vmovaps xmm11, [rsp+0xA0]
000076049b1d80d7  vmovaps xmm12, [rsp+0xB0]
000076049b1d80e0  vmovaps xmm13, [rsp+0xC0]
000076049b1d80e9  vmovaps xmm14, [rsp+0xD0]
000076049b1d80f2  vmovaps xmm15, [rsp+0xE0]
000076049b1d80fb  add rsp, 0xF0
000076049b1d8102  pop r11
000076049b1d8104  pop r10
000076049b1d8106  pop r9
000076049b1d8108  pop r8
000076049b1d810a  pop rsi
000076049b1d810b  pop rdi
000076049b1d810c  pop rdx
000076049b1d810d  pop rcx
000076049b1d810e  pop rax
000076049b1d810f  add rsp, 0x08
000076049b1d8113  jmp 0x000076049B1D5F06
000076049b1d8118  sub rsp, 0x08
000076049b1d811c  push rax
000076049b1d811d  push rcx
000076049b1d811e  push rdx
000076049b1d811f  push rdi
000076049b1d8120  push rsi
000076049b1d8121  push r8
000076049b1d8123  push r9
000076049b1d8125  push r10
000076049b1d8127  push r11
000076049b1d8129  sub rsp, 0xF0
000076049b1d8130  vmovaps [rsp], xmm0
000076049b1d8135  vmovaps [rsp+0x10], xmm1
000076049b1d813b  vmovaps [rsp+0x20], xmm2
000076049b1d8141  vmovaps [rsp+0x30], xmm3
000076049b1d8147  vmovaps [rsp+0x40], xmm5
000076049b1d814d  vmovaps [rsp+0x50], xmm6
000076049b1d8153  vmovaps [rsp+0x60], xmm7
000076049b1d8159  vmovaps [rsp+0x70], xmm8
000076049b1d815f  vmovaps [rsp+0x80], xmm9
000076049b1d8168  vmovaps [rsp+0x90], xmm10
000076049b1d8171  vmovaps [rsp+0xA0], xmm11
000076049b1d817a  vmovaps [rsp+0xB0], xmm12
000076049b1d8183  vmovaps [rsp+0xC0], xmm13
000076049b1d818c  vmovaps [rsp+0xD0], xmm14
000076049b1d8195  vmovaps [rsp+0xE0], xmm15
000076049b1d819e  sub rsp, 0x30
000076049b1d81a2  movaps [rsp], xmm4
000076049b1d81a6  movaps [rsp+0x10], xmm3
000076049b1d81ab  movaps [rsp+0x20], xmm5
000076049b1d81b0  lea rdi, [rsp]
000076049b1d81b4  mov esi, 0x00
000076049b1d81b9  mov rax, 0x64C06813C530
000076049b1d81c3  call rax
000076049b1d81c5  movaps xmm4, [rsp]
000076049b1d81c9  add rsp, 0x30
000076049b1d81cd  vmovaps xmm0, [rsp]
000076049b1d81d2  vmovaps xmm1, [rsp+0x10]
000076049b1d81d8  vmovaps xmm2, [rsp+0x20]
000076049b1d81de  vmovaps xmm3, [rsp+0x30]
000076049b1d81e4  vmovaps xmm5, [rsp+0x40]
000076049b1d81ea  vmovaps xmm6, [rsp+0x50]
000076049b1d81f0  vmovaps xmm7, [rsp+0x60]
000076049b1d81f6  vmovaps xmm8, [rsp+0x70]
000076049b1d81fc  vmovaps xmm9, [rsp+0x80]
000076049b1d8205  vmovaps xmm10, [rsp+0x90]
000076049b1d820e  vmovaps xmm11, [rsp+0xA0]
000076049b1d8217  vmovaps xmm12, [rsp+0xB0]
000076049b1d8220  vmovaps xmm13, [rsp+0xC0]
000076049b1d8229  vmovaps xmm14, [rsp+0xD0]
000076049b1d8232  vmovaps xmm15, [rsp+0xE0]
000076049b1d823b  add rsp, 0xF0
000076049b1d8242  pop r11
000076049b1d8244  pop r10
000076049b1d8246  pop r9
000076049b1d8248  pop r8
000076049b1d824a  pop rsi
000076049b1d824b  pop rdi
000076049b1d824c  pop rdx
000076049b1d824d  pop rcx
000076049b1d824e  pop rax
000076049b1d824f  add rsp, 0x08
000076049b1d8253  jmp 0x000076049B1D5F54
000076049b1d8258  call 0x000076049B0D64F0
000076049b1d825d  jmp 0x000076049B1D5F61
000076049b1d8262  sub rsp, 0x08
000076049b1d8266  push rax
000076049b1d8267  push rcx
000076049b1d8268  push rdx
000076049b1d8269  push rdi
000076049b1d826a  push rsi
000076049b1d826b  push r8
000076049b1d826d  push r9
000076049b1d826f  push r10
000076049b1d8271  push r11
000076049b1d8273  sub rsp, 0xF0
000076049b1d827a  vmovaps [rsp], xmm0
000076049b1d827f  vmovaps [rsp+0x10], xmm1
000076049b1d8285  vmovaps [rsp+0x20], xmm2
000076049b1d828b  vmovaps [rsp+0x30], xmm3
000076049b1d8291  vmovaps [rsp+0x40], xmm4
000076049b1d8297  vmovaps [rsp+0x50], xmm6
000076049b1d829d  vmovaps [rsp+0x60], xmm7
000076049b1d82a3  vmovaps [rsp+0x70], xmm8
000076049b1d82a9  vmovaps [rsp+0x80], xmm9
000076049b1d82b2  vmovaps [rsp+0x90], xmm10
000076049b1d82bb  vmovaps [rsp+0xA0], xmm11
000076049b1d82c4  vmovaps [rsp+0xB0], xmm12
000076049b1d82cd  vmovaps [rsp+0xC0], xmm13
000076049b1d82d6  vmovaps [rsp+0xD0], xmm14
000076049b1d82df  vmovaps [rsp+0xE0], xmm15
000076049b1d82e8  sub rsp, 0x30
000076049b1d82ec  movaps [rsp], xmm5
000076049b1d82f0  movaps [rsp+0x10], xmm6
000076049b1d82f5  movaps [rsp+0x20], xmm3
000076049b1d82fa  lea rdi, [rsp]
000076049b1d82fe  mov esi, 0x00
000076049b1d8303  mov rax, 0x64C06813C530
000076049b1d830d  call rax
000076049b1d830f  movaps xmm5, [rsp]
000076049b1d8313  add rsp, 0x30
000076049b1d8317  vmovaps xmm0, [rsp]
000076049b1d831c  vmovaps xmm1, [rsp+0x10]
000076049b1d8322  vmovaps xmm2, [rsp+0x20]
000076049b1d8328  vmovaps xmm3, [rsp+0x30]
000076049b1d832e  vmovaps xmm4, [rsp+0x40]
000076049b1d8334  vmovaps xmm6, [rsp+0x50]
000076049b1d833a  vmovaps xmm7, [rsp+0x60]
000076049b1d8340  vmovaps xmm8, [rsp+0x70]
000076049b1d8346  vmovaps xmm9, [rsp+0x80]
000076049b1d834f  vmovaps xmm10, [rsp+0x90]
000076049b1d8358  vmovaps xmm11, [rsp+0xA0]
000076049b1d8361  vmovaps xmm12, [rsp+0xB0]
000076049b1d836a  vmovaps xmm13, [rsp+0xC0]
000076049b1d8373  vmovaps xmm14, [rsp+0xD0]
000076049b1d837c  vmovaps xmm15, [rsp+0xE0]
000076049b1d8385  add rsp, 0xF0
000076049b1d838c  pop r11
000076049b1d838e  pop r10
000076049b1d8390  pop r9
000076049b1d8392  pop r8
000076049b1d8394  pop rsi
000076049b1d8395  pop rdi
000076049b1d8396  pop rdx
000076049b1d8397  pop rcx
000076049b1d8398  pop rax
000076049b1d8399  add rsp, 0x08
000076049b1d839d  jmp 0x000076049B1D5F87
000076049b1d83a2  sub rsp, 0x08
000076049b1d83a6  push rax
000076049b1d83a7  push rcx
000076049b1d83a8  push rdx
000076049b1d83a9  push rdi
000076049b1d83aa  push rsi
000076049b1d83ab  push r8
000076049b1d83ad  push r9
000076049b1d83af  push r10
000076049b1d83b1  push r11
000076049b1d83b3  sub rsp, 0xF0
000076049b1d83ba  vmovaps [rsp], xmm0
000076049b1d83bf  vmovaps [rsp+0x10], xmm1
000076049b1d83c5  vmovaps [rsp+0x20], xmm2
000076049b1d83cb  vmovaps [rsp+0x30], xmm3
000076049b1d83d1  vmovaps [rsp+0x40], xmm4
000076049b1d83d7  vmovaps [rsp+0x50], xmm5
000076049b1d83dd  vmovaps [rsp+0x60], xmm7
000076049b1d83e3  vmovaps [rsp+0x70], xmm8
000076049b1d83e9  vmovaps [rsp+0x80], xmm9
000076049b1d83f2  vmovaps [rsp+0x90], xmm10
000076049b1d83fb  vmovaps [rsp+0xA0], xmm11
000076049b1d8404  vmovaps [rsp+0xB0], xmm12
000076049b1d840d  vmovaps [rsp+0xC0], xmm13
000076049b1d8416  vmovaps [rsp+0xD0], xmm14
000076049b1d841f  vmovaps [rsp+0xE0], xmm15
000076049b1d8428  sub rsp, 0x30
000076049b1d842c  movaps [rsp], xmm6
000076049b1d8430  movaps [rsp+0x10], xmm9
000076049b1d8436  movaps [rsp+0x20], xmm1
000076049b1d843b  lea rdi, [rsp]
000076049b1d843f  mov esi, 0x00
000076049b1d8444  mov rax, 0x64C06813C530
000076049b1d844e  call rax
000076049b1d8450  movaps xmm6, [rsp]
000076049b1d8454  add rsp, 0x30
000076049b1d8458  vmovaps xmm0, [rsp]
000076049b1d845d  vmovaps xmm1, [rsp+0x10]
000076049b1d8463  vmovaps xmm2, [rsp+0x20]
000076049b1d8469  vmovaps xmm3, [rsp+0x30]
000076049b1d846f  vmovaps xmm4, [rsp+0x40]
000076049b1d8475  vmovaps xmm5, [rsp+0x50]
000076049b1d847b  vmovaps xmm7, [rsp+0x60]
000076049b1d8481  vmovaps xmm8, [rsp+0x70]
000076049b1d8487  vmovaps xmm9, [rsp+0x80]
000076049b1d8490  vmovaps xmm10, [rsp+0x90]
000076049b1d8499  vmovaps xmm11, [rsp+0xA0]
000076049b1d84a2  vmovaps xmm12, [rsp+0xB0]
000076049b1d84ab  vmovaps xmm13, [rsp+0xC0]
000076049b1d84b4  vmovaps xmm14, [rsp+0xD0]
000076049b1d84bd  vmovaps xmm15, [rsp+0xE0]
000076049b1d84c6  add rsp, 0xF0
000076049b1d84cd  pop r11
000076049b1d84cf  pop r10
000076049b1d84d1  pop r9
000076049b1d84d3  pop r8
000076049b1d84d5  pop rsi
000076049b1d84d6  pop rdi
000076049b1d84d7  pop rdx
000076049b1d84d8  pop rcx
000076049b1d84d9  pop rax
000076049b1d84da  add rsp, 0x08
000076049b1d84de  jmp 0x000076049B1D5FAB
000076049b1d84e3  sub rsp, 0x08
000076049b1d84e7  push rax
000076049b1d84e8  push rcx
000076049b1d84e9  push rdx
000076049b1d84ea  push rdi
000076049b1d84eb  push rsi
000076049b1d84ec  push r8
000076049b1d84ee  push r9
000076049b1d84f0  push r10
000076049b1d84f2  push r11
000076049b1d84f4  sub rsp, 0xF0
000076049b1d84fb  vmovaps [rsp], xmm0
000076049b1d8500  vmovaps [rsp+0x10], xmm1
000076049b1d8506  vmovaps [rsp+0x20], xmm2
000076049b1d850c  vmovaps [rsp+0x30], xmm3
000076049b1d8512  vmovaps [rsp+0x40], xmm4
000076049b1d8518  vmovaps [rsp+0x50], xmm5
000076049b1d851e  vmovaps [rsp+0x60], xmm6
000076049b1d8524  vmovaps [rsp+0x70], xmm7
000076049b1d852a  vmovaps [rsp+0x80], xmm8
000076049b1d8533  vmovaps [rsp+0x90], xmm10
000076049b1d853c  vmovaps [rsp+0xA0], xmm11
000076049b1d8545  vmovaps [rsp+0xB0], xmm12
000076049b1d854e  vmovaps [rsp+0xC0], xmm13
000076049b1d8557  vmovaps [rsp+0xD0], xmm14
000076049b1d8560  vmovaps [rsp+0xE0], xmm15
000076049b1d8569  sub rsp, 0x30
000076049b1d856d  movaps [rsp], xmm9
000076049b1d8572  movaps [rsp+0x10], xmm3
000076049b1d8577  movaps [rsp+0x20], xmm1
000076049b1d857c  lea rdi, [rsp]
000076049b1d8580  mov esi, 0x00
000076049b1d8585  mov rax, 0x64C06813C530
000076049b1d858f  call rax
000076049b1d8591  movaps xmm9, [rsp]
000076049b1d8596  add rsp, 0x30
000076049b1d859a  vmovaps xmm0, [rsp]
000076049b1d859f  vmovaps xmm1, [rsp+0x10]
000076049b1d85a5  vmovaps xmm2, [rsp+0x20]
000076049b1d85ab  vmovaps xmm3, [rsp+0x30]
000076049b1d85b1  vmovaps xmm4, [rsp+0x40]
000076049b1d85b7  vmovaps xmm5, [rsp+0x50]
000076049b1d85bd  vmovaps xmm6, [rsp+0x60]
000076049b1d85c3  vmovaps xmm7, [rsp+0x70]
000076049b1d85c9  vmovaps xmm8, [rsp+0x80]
000076049b1d85d2  vmovaps xmm10, [rsp+0x90]
000076049b1d85db  vmovaps xmm11, [rsp+0xA0]
000076049b1d85e4  vmovaps xmm12, [rsp+0xB0]
000076049b1d85ed  vmovaps xmm13, [rsp+0xC0]
000076049b1d85f6  vmovaps xmm14, [rsp+0xD0]
000076049b1d85ff  vmovaps xmm15, [rsp+0xE0]
000076049b1d8608  add rsp, 0xF0
000076049b1d860f  pop r11
000076049b1d8611  pop r10
000076049b1d8613  pop r9
000076049b1d8615  pop r8
000076049b1d8617  pop rsi
000076049b1d8618  pop rdi
000076049b1d8619  pop rdx
000076049b1d861a  pop rcx
000076049b1d861b  pop rax
000076049b1d861c  add rsp, 0x08
000076049b1d8620  jmp 0x000076049B1D5FF7
000076049b1d8625  call 0x000076049B0D64F0
000076049b1d862a  jmp 0x000076049B1D6004
000076049b1d862f  sub rsp, 0x08
000076049b1d8633  push rax
000076049b1d8634  push rcx
000076049b1d8635  push rdx
000076049b1d8636  push rdi
000076049b1d8637  push rsi
000076049b1d8638  push r8
000076049b1d863a  push r9
000076049b1d863c  push r10
000076049b1d863e  push r11
000076049b1d8640  sub rsp, 0xF0
000076049b1d8647  vmovaps [rsp], xmm0
000076049b1d864c  vmovaps [rsp+0x10], xmm1
000076049b1d8652  vmovaps [rsp+0x20], xmm2
000076049b1d8658  vmovaps [rsp+0x30], xmm3
000076049b1d865e  vmovaps [rsp+0x40], xmm4
000076049b1d8664  vmovaps [rsp+0x50], xmm5
000076049b1d866a  vmovaps [rsp+0x60], xmm6
000076049b1d8670  vmovaps [rsp+0x70], xmm7
000076049b1d8676  vmovaps [rsp+0x80], xmm8
000076049b1d867f  vmovaps [rsp+0x90], xmm9
000076049b1d8688  vmovaps [rsp+0xA0], xmm10
000076049b1d8691  vmovaps [rsp+0xB0], xmm11
000076049b1d869a  vmovaps [rsp+0xC0], xmm12
000076049b1d86a3  vmovaps [rsp+0xD0], xmm13
000076049b1d86ac  vmovaps [rsp+0xE0], xmm14
000076049b1d86b5  sub rsp, 0x30
000076049b1d86b9  movaps [rsp], xmm15
000076049b1d86be  movaps [rsp+0x10], xmm3
000076049b1d86c3  movaps [rsp+0x20], xmm7
000076049b1d86c8  lea rdi, [rsp]
000076049b1d86cc  mov esi, 0x00
000076049b1d86d1  mov rax, 0x64C06813C530
000076049b1d86db  call rax
000076049b1d86dd  movaps xmm15, [rsp]
000076049b1d86e2  add rsp, 0x30
000076049b1d86e6  vmovaps xmm0, [rsp]
000076049b1d86eb  vmovaps xmm1, [rsp+0x10]
000076049b1d86f1  vmovaps xmm2, [rsp+0x20]
000076049b1d86f7  vmovaps xmm3, [rsp+0x30]
000076049b1d86fd  vmovaps xmm4, [rsp+0x40]
000076049b1d8703  vmovaps xmm5, [rsp+0x50]
000076049b1d8709  vmovaps xmm6, [rsp+0x60]
000076049b1d870f  vmovaps xmm7, [rsp+0x70]
000076049b1d8715  vmovaps xmm8, [rsp+0x80]
000076049b1d871e  vmovaps xmm9, [rsp+0x90]
000076049b1d8727  vmovaps xmm10, [rsp+0xA0]
000076049b1d8730  vmovaps xmm11, [rsp+0xB0]
000076049b1d8739  vmovaps xmm12, [rsp+0xC0]
000076049b1d8742  vmovaps xmm13, [rsp+0xD0]
000076049b1d874b  vmovaps xmm14, [rsp+0xE0]
000076049b1d8754  add rsp, 0xF0
000076049b1d875b  pop r11
000076049b1d875d  pop r10
000076049b1d875f  pop r9
000076049b1d8761  pop r8
000076049b1d8763  pop rsi
000076049b1d8764  pop rdi
000076049b1d8765  pop rdx
000076049b1d8766  pop rcx
000076049b1d8767  pop rax
000076049b1d8768  add rsp, 0x08
000076049b1d876c  jmp 0x000076049B1D6030
000076049b1d8771  sub rsp, 0x08
000076049b1d8775  push rax
000076049b1d8776  push rcx
000076049b1d8777  push rdx
000076049b1d8778  push rdi
000076049b1d8779  push rsi
000076049b1d877a  push r8
000076049b1d877c  push r9
000076049b1d877e  push r10
000076049b1d8780  push r11
000076049b1d8782  sub rsp, 0xF0
000076049b1d8789  vmovaps [rsp], xmm0
000076049b1d878e  vmovaps [rsp+0x10], xmm1
000076049b1d8794  vmovaps [rsp+0x20], xmm2
000076049b1d879a  vmovaps [rsp+0x30], xmm4
000076049b1d87a0  vmovaps [rsp+0x40], xmm5
000076049b1d87a6  vmovaps [rsp+0x50], xmm6
000076049b1d87ac  vmovaps [rsp+0x60], xmm7
000076049b1d87b2  vmovaps [rsp+0x70], xmm8
000076049b1d87b8  vmovaps [rsp+0x80], xmm9
000076049b1d87c1  vmovaps [rsp+0x90], xmm10
000076049b1d87ca  vmovaps [rsp+0xA0], xmm11
000076049b1d87d3  vmovaps [rsp+0xB0], xmm12
000076049b1d87dc  vmovaps [rsp+0xC0], xmm13
000076049b1d87e5  vmovaps [rsp+0xD0], xmm14
000076049b1d87ee  vmovaps [rsp+0xE0], xmm15
000076049b1d87f7  sub rsp, 0x30
000076049b1d87fb  movaps [rsp], xmm3
000076049b1d87ff  movaps [rsp+0x10], xmm1
000076049b1d8804  movaps [rsp+0x20], xmm15
000076049b1d880a  lea rdi, [rsp]
000076049b1d880e  mov esi, 0x00
000076049b1d8813  mov rax, 0x64C06813C530
000076049b1d881d  call rax
000076049b1d881f  movaps xmm3, [rsp]
000076049b1d8823  add rsp, 0x30
000076049b1d8827  vmovaps xmm0, [rsp]
000076049b1d882c  vmovaps xmm1, [rsp+0x10]
000076049b1d8832  vmovaps xmm2, [rsp+0x20]
000076049b1d8838  vmovaps xmm4, [rsp+0x30]
000076049b1d883e  vmovaps xmm5, [rsp+0x40]
000076049b1d8844  vmovaps xmm6, [rsp+0x50]
000076049b1d884a  vmovaps xmm7, [rsp+0x60]
000076049b1d8850  vmovaps xmm8, [rsp+0x70]
000076049b1d8856  vmovaps xmm9, [rsp+0x80]
000076049b1d885f  vmovaps xmm10, [rsp+0x90]
000076049b1d8868  vmovaps xmm11, [rsp+0xA0]
000076049b1d8871  vmovaps xmm12, [rsp+0xB0]
000076049b1d887a  vmovaps xmm13, [rsp+0xC0]
000076049b1d8883  vmovaps xmm14, [rsp+0xD0]
000076049b1d888c  vmovaps xmm15, [rsp+0xE0]
000076049b1d8895  add rsp, 0xF0
000076049b1d889c  pop r11
000076049b1d889e  pop r10
000076049b1d88a0  pop r9
000076049b1d88a2  pop r8
000076049b1d88a4  pop rsi
000076049b1d88a5  pop rdi
000076049b1d88a6  pop rdx
000076049b1d88a7  pop rcx
000076049b1d88a8  pop rax
000076049b1d88a9  add rsp, 0x08
000076049b1d88ad  jmp 0x000076049B1D60BF
000076049b1d88b2  call 0x000076049B0D64F0
000076049b1d88b7  jmp 0x000076049B1D60C9
000076049b1d88bc  sub rsp, 0x08
000076049b1d88c0  push rax
000076049b1d88c1  push rcx
000076049b1d88c2  push rdx
000076049b1d88c3  push rdi
000076049b1d88c4  push rsi
000076049b1d88c5  push r8
000076049b1d88c7  push r9
000076049b1d88c9  push r10
000076049b1d88cb  push r11
000076049b1d88cd  sub rsp, 0xF0
000076049b1d88d4  vmovaps [rsp], xmm0
000076049b1d88d9  vmovaps [rsp+0x10], xmm1
000076049b1d88df  vmovaps [rsp+0x20], xmm2
000076049b1d88e5  vmovaps [rsp+0x30], xmm3
000076049b1d88eb  vmovaps [rsp+0x40], xmm4
000076049b1d88f1  vmovaps [rsp+0x50], xmm5
000076049b1d88f7  vmovaps [rsp+0x60], xmm6
000076049b1d88fd  vmovaps [rsp+0x70], xmm7
000076049b1d8903  vmovaps [rsp+0x80], xmm8
000076049b1d890c  vmovaps [rsp+0x90], xmm9
000076049b1d8915  vmovaps [rsp+0xA0], xmm10
000076049b1d891e  vmovaps [rsp+0xB0], xmm11
000076049b1d8927  vmovaps [rsp+0xC0], xmm12
000076049b1d8930  vmovaps [rsp+0xD0], xmm13
000076049b1d8939  vmovaps [rsp+0xE0], xmm14
000076049b1d8942  sub rsp, 0x30
000076049b1d8946  movaps [rsp], xmm15
000076049b1d894b  movaps [rsp+0x10], xmm14
000076049b1d8951  movaps [rsp+0x20], xmm4
000076049b1d8956  lea rdi, [rsp]
000076049b1d895a  mov esi, 0x00
000076049b1d895f  mov rax, 0x64C06813C530
000076049b1d8969  call rax
000076049b1d896b  movaps xmm15, [rsp]
000076049b1d8970  add rsp, 0x30
000076049b1d8974  vmovaps xmm0, [rsp]
000076049b1d8979  vmovaps xmm1, [rsp+0x10]
000076049b1d897f  vmovaps xmm2, [rsp+0x20]
000076049b1d8985  vmovaps xmm3, [rsp+0x30]
000076049b1d898b  vmovaps xmm4, [rsp+0x40]
000076049b1d8991  vmovaps xmm5, [rsp+0x50]
000076049b1d8997  vmovaps xmm6, [rsp+0x60]
000076049b1d899d  vmovaps xmm7, [rsp+0x70]
000076049b1d89a3  vmovaps xmm8, [rsp+0x80]
000076049b1d89ac  vmovaps xmm9, [rsp+0x90]
000076049b1d89b5  vmovaps xmm10, [rsp+0xA0]
000076049b1d89be  vmovaps xmm11, [rsp+0xB0]
000076049b1d89c7  vmovaps xmm12, [rsp+0xC0]
000076049b1d89d0  vmovaps xmm13, [rsp+0xD0]
000076049b1d89d9  vmovaps xmm14, [rsp+0xE0]
000076049b1d89e2  add rsp, 0xF0
000076049b1d89e9  pop r11
000076049b1d89eb  pop r10
000076049b1d89ed  pop r9
000076049b1d89ef  pop r8
000076049b1d89f1  pop rsi
000076049b1d89f2  pop rdi
000076049b1d89f3  pop rdx
000076049b1d89f4  pop rcx
000076049b1d89f5  pop rax
000076049b1d89f6  add rsp, 0x08
000076049b1d89fa  jmp 0x000076049B1D60F7
000076049b1d89ff  sub rsp, 0x08
000076049b1d8a03  push rax
000076049b1d8a04  push rcx
000076049b1d8a05  push rdx
000076049b1d8a06  push rdi
000076049b1d8a07  push rsi
000076049b1d8a08  push r8
000076049b1d8a0a  push r9
000076049b1d8a0c  push r10
000076049b1d8a0e  push r11
000076049b1d8a10  sub rsp, 0xF0
000076049b1d8a17  vmovaps [rsp], xmm0
000076049b1d8a1c  vmovaps [rsp+0x10], xmm1
000076049b1d8a22  vmovaps [rsp+0x20], xmm2
000076049b1d8a28  vmovaps [rsp+0x30], xmm3
000076049b1d8a2e  vmovaps [rsp+0x40], xmm4
000076049b1d8a34  vmovaps [rsp+0x50], xmm5
000076049b1d8a3a  vmovaps [rsp+0x60], xmm6
000076049b1d8a40  vmovaps [rsp+0x70], xmm7
000076049b1d8a46  vmovaps [rsp+0x80], xmm8
000076049b1d8a4f  vmovaps [rsp+0x90], xmm9
000076049b1d8a58  vmovaps [rsp+0xA0], xmm10
000076049b1d8a61  vmovaps [rsp+0xB0], xmm11
000076049b1d8a6a  vmovaps [rsp+0xC0], xmm12
000076049b1d8a73  vmovaps [rsp+0xD0], xmm13
000076049b1d8a7c  vmovaps [rsp+0xE0], xmm15
000076049b1d8a85  sub rsp, 0x30
000076049b1d8a89  movaps [rsp], xmm14
000076049b1d8a8e  movaps [rsp+0x10], xmm2
000076049b1d8a93  movaps [rsp+0x20], xmm1
000076049b1d8a98  lea rdi, [rsp]
000076049b1d8a9c  mov esi, 0x00
000076049b1d8aa1  mov rax, 0x64C06813C530
000076049b1d8aab  call rax
000076049b1d8aad  movaps xmm14, [rsp]
000076049b1d8ab2  add rsp, 0x30
000076049b1d8ab6  vmovaps xmm0, [rsp]
000076049b1d8abb  vmovaps xmm1, [rsp+0x10]
000076049b1d8ac1  vmovaps xmm2, [rsp+0x20]
000076049b1d8ac7  vmovaps xmm3, [rsp+0x30]
000076049b1d8acd  vmovaps xmm4, [rsp+0x40]
000076049b1d8ad3  vmovaps xmm5, [rsp+0x50]
000076049b1d8ad9  vmovaps xmm6, [rsp+0x60]
000076049b1d8adf  vmovaps xmm7, [rsp+0x70]
000076049b1d8ae5  vmovaps xmm8, [rsp+0x80]
000076049b1d8aee  vmovaps xmm9, [rsp+0x90]
000076049b1d8af7  vmovaps xmm10, [rsp+0xA0]
000076049b1d8b00  vmovaps xmm11, [rsp+0xB0]
000076049b1d8b09  vmovaps xmm12, [rsp+0xC0]
000076049b1d8b12  vmovaps xmm13, [rsp+0xD0]
000076049b1d8b1b  vmovaps xmm15, [rsp+0xE0]
000076049b1d8b24  add rsp, 0xF0
000076049b1d8b2b  pop r11
000076049b1d8b2d  pop r10
000076049b1d8b2f  pop r9
000076049b1d8b31  pop r8
000076049b1d8b33  pop rsi
000076049b1d8b34  pop rdi
000076049b1d8b35  pop rdx
000076049b1d8b36  pop rcx
000076049b1d8b37  pop rax
000076049b1d8b38  add rsp, 0x08
000076049b1d8b3c  jmp 0x000076049B1D611D
000076049b1d8b41  sub rsp, 0x08
000076049b1d8b45  push rax
000076049b1d8b46  push rcx
000076049b1d8b47  push rdx
000076049b1d8b48  push rdi
000076049b1d8b49  push rsi
000076049b1d8b4a  push r8
000076049b1d8b4c  push r9
000076049b1d8b4e  push r10
000076049b1d8b50  push r11
000076049b1d8b52  sub rsp, 0xF0
000076049b1d8b59  vmovaps [rsp], xmm0
000076049b1d8b5e  vmovaps [rsp+0x10], xmm2
000076049b1d8b64  vmovaps [rsp+0x20], xmm3
000076049b1d8b6a  vmovaps [rsp+0x30], xmm4
000076049b1d8b70  vmovaps [rsp+0x40], xmm5
000076049b1d8b76  vmovaps [rsp+0x50], xmm6
000076049b1d8b7c  vmovaps [rsp+0x60], xmm7
000076049b1d8b82  vmovaps [rsp+0x70], xmm8
000076049b1d8b88  vmovaps [rsp+0x80], xmm9
000076049b1d8b91  vmovaps [rsp+0x90], xmm10
000076049b1d8b9a  vmovaps [rsp+0xA0], xmm11
000076049b1d8ba3  vmovaps [rsp+0xB0], xmm12
000076049b1d8bac  vmovaps [rsp+0xC0], xmm13
000076049b1d8bb5  vmovaps [rsp+0xD0], xmm14
000076049b1d8bbe  vmovaps [rsp+0xE0], xmm15
000076049b1d8bc7  sub rsp, 0x30
000076049b1d8bcb  movaps [rsp], xmm1
000076049b1d8bcf  movaps [rsp+0x10], xmm4
000076049b1d8bd4  movaps [rsp+0x20], xmm9
000076049b1d8bda  lea rdi, [rsp]
000076049b1d8bde  mov esi, 0x00
000076049b1d8be3  mov rax, 0x64C06813C530
000076049b1d8bed  call rax
000076049b1d8bef  movaps xmm1, [rsp]
000076049b1d8bf3  add rsp, 0x30
000076049b1d8bf7  vmovaps xmm0, [rsp]
000076049b1d8bfc  vmovaps xmm2, [rsp+0x10]
000076049b1d8c02  vmovaps xmm3, [rsp+0x20]
000076049b1d8c08  vmovaps xmm4, [rsp+0x30]
000076049b1d8c0e  vmovaps xmm5, [rsp+0x40]
000076049b1d8c14  vmovaps xmm6, [rsp+0x50]
000076049b1d8c1a  vmovaps xmm7, [rsp+0x60]
000076049b1d8c20  vmovaps xmm8, [rsp+0x70]
000076049b1d8c26  vmovaps xmm9, [rsp+0x80]
000076049b1d8c2f  vmovaps xmm10, [rsp+0x90]
000076049b1d8c38  vmovaps xmm11, [rsp+0xA0]
000076049b1d8c41  vmovaps xmm12, [rsp+0xB0]
000076049b1d8c4a  vmovaps xmm13, [rsp+0xC0]
000076049b1d8c53  vmovaps xmm14, [rsp+0xD0]
000076049b1d8c5c  vmovaps xmm15, [rsp+0xE0]
000076049b1d8c65  add rsp, 0xF0
000076049b1d8c6c  pop r11
000076049b1d8c6e  pop r10
000076049b1d8c70  pop r9
000076049b1d8c72  pop r8
000076049b1d8c74  pop rsi
000076049b1d8c75  pop rdi
000076049b1d8c76  pop rdx
000076049b1d8c77  pop rcx
000076049b1d8c78  pop rax
000076049b1d8c79  add rsp, 0x08
000076049b1d8c7d  jmp 0x000076049B1D613B
000076049b1d8c82  sub rsp, 0x08
000076049b1d8c86  push rax
000076049b1d8c87  push rcx
000076049b1d8c88  push rdx
000076049b1d8c89  push rdi
000076049b1d8c8a  push rsi
000076049b1d8c8b  push r8
000076049b1d8c8d  push r9
000076049b1d8c8f  push r10
000076049b1d8c91  push r11
000076049b1d8c93  sub rsp, 0xF0
000076049b1d8c9a  vmovaps [rsp], xmm0
000076049b1d8c9f  vmovaps [rsp+0x10], xmm1
000076049b1d8ca5  vmovaps [rsp+0x20], xmm2
000076049b1d8cab  vmovaps [rsp+0x30], xmm3
000076049b1d8cb1  vmovaps [rsp+0x40], xmm5
000076049b1d8cb7  vmovaps [rsp+0x50], xmm6
000076049b1d8cbd  vmovaps [rsp+0x60], xmm7
000076049b1d8cc3  vmovaps [rsp+0x70], xmm8
000076049b1d8cc9  vmovaps [rsp+0x80], xmm9
000076049b1d8cd2  vmovaps [rsp+0x90], xmm10
000076049b1d8cdb  vmovaps [rsp+0xA0], xmm11
000076049b1d8ce4  vmovaps [rsp+0xB0], xmm12
000076049b1d8ced  vmovaps [rsp+0xC0], xmm13
000076049b1d8cf6  vmovaps [rsp+0xD0], xmm14
000076049b1d8cff  vmovaps [rsp+0xE0], xmm15
000076049b1d8d08  sub rsp, 0x30
000076049b1d8d0c  movaps [rsp], xmm4
000076049b1d8d10  movaps [rsp+0x10], xmm2
000076049b1d8d15  movaps [rsp+0x20], xmm9
000076049b1d8d1b  lea rdi, [rsp]
000076049b1d8d1f  mov esi, 0x00
000076049b1d8d24  mov rax, 0x64C06813C530
000076049b1d8d2e  call rax
000076049b1d8d30  movaps xmm4, [rsp]
000076049b1d8d34  add rsp, 0x30
000076049b1d8d38  vmovaps xmm0, [rsp]
000076049b1d8d3d  vmovaps xmm1, [rsp+0x10]
000076049b1d8d43  vmovaps xmm2, [rsp+0x20]
000076049b1d8d49  vmovaps xmm3, [rsp+0x30]
000076049b1d8d4f  vmovaps xmm5, [rsp+0x40]
000076049b1d8d55  vmovaps xmm6, [rsp+0x50]
000076049b1d8d5b  vmovaps xmm7, [rsp+0x60]
000076049b1d8d61  vmovaps xmm8, [rsp+0x70]
000076049b1d8d67  vmovaps xmm9, [rsp+0x80]
000076049b1d8d70  vmovaps xmm10, [rsp+0x90]
000076049b1d8d79  vmovaps xmm11, [rsp+0xA0]
000076049b1d8d82  vmovaps xmm12, [rsp+0xB0]
000076049b1d8d8b  vmovaps xmm13, [rsp+0xC0]
000076049b1d8d94  vmovaps xmm14, [rsp+0xD0]
000076049b1d8d9d  vmovaps xmm15, [rsp+0xE0]
000076049b1d8da6  add rsp, 0xF0
000076049b1d8dad  pop r11
000076049b1d8daf  pop r10
000076049b1d8db1  pop r9
000076049b1d8db3  pop r8
000076049b1d8db5  pop rsi
000076049b1d8db6  pop rdi
000076049b1d8db7  pop rdx
000076049b1d8db8  pop rcx
000076049b1d8db9  pop rax
000076049b1d8dba  add rsp, 0x08
000076049b1d8dbe  jmp 0x000076049B1D616B
000076049b1d8dc3  sub rsp, 0x08
000076049b1d8dc7  push rax
000076049b1d8dc8  push rcx
000076049b1d8dc9  push rdx
000076049b1d8dca  push rdi
000076049b1d8dcb  push rsi
000076049b1d8dcc  push r8
000076049b1d8dce  push r9
000076049b1d8dd0  push r10
000076049b1d8dd2  push r11
000076049b1d8dd4  sub rsp, 0xF0
000076049b1d8ddb  vmovaps [rsp], xmm0
000076049b1d8de0  vmovaps [rsp+0x10], xmm1
000076049b1d8de6  vmovaps [rsp+0x20], xmm2
000076049b1d8dec  vmovaps [rsp+0x30], xmm3
000076049b1d8df2  vmovaps [rsp+0x40], xmm4
000076049b1d8df8  vmovaps [rsp+0x50], xmm5
000076049b1d8dfe  vmovaps [rsp+0x60], xmm6
000076049b1d8e04  vmovaps [rsp+0x70], xmm7
000076049b1d8e0a  vmovaps [rsp+0x80], xmm8
000076049b1d8e13  vmovaps [rsp+0x90], xmm10
000076049b1d8e1c  vmovaps [rsp+0xA0], xmm11
000076049b1d8e25  vmovaps [rsp+0xB0], xmm12
000076049b1d8e2e  vmovaps [rsp+0xC0], xmm13
000076049b1d8e37  vmovaps [rsp+0xD0], xmm14
000076049b1d8e40  vmovaps [rsp+0xE0], xmm15
000076049b1d8e49  sub rsp, 0x30
000076049b1d8e4d  movaps [rsp], xmm9
000076049b1d8e52  movaps [rsp+0x10], xmm2
000076049b1d8e57  movaps [rsp+0x20], xmm1
000076049b1d8e5c  lea rdi, [rsp]
000076049b1d8e60  mov esi, 0x00
000076049b1d8e65  mov rax, 0x64C06813C530
000076049b1d8e6f  call rax
000076049b1d8e71  movaps xmm9, [rsp]
000076049b1d8e76  add rsp, 0x30
000076049b1d8e7a  vmovaps xmm0, [rsp]
000076049b1d8e7f  vmovaps xmm1, [rsp+0x10]
000076049b1d8e85  vmovaps xmm2, [rsp+0x20]
000076049b1d8e8b  vmovaps xmm3, [rsp+0x30]
000076049b1d8e91  vmovaps xmm4, [rsp+0x40]
000076049b1d8e97  vmovaps xmm5, [rsp+0x50]
000076049b1d8e9d  vmovaps xmm6, [rsp+0x60]
000076049b1d8ea3  vmovaps xmm7, [rsp+0x70]
000076049b1d8ea9  vmovaps xmm8, [rsp+0x80]
000076049b1d8eb2  vmovaps xmm10, [rsp+0x90]
000076049b1d8ebb  vmovaps xmm11, [rsp+0xA0]
000076049b1d8ec4  vmovaps xmm12, [rsp+0xB0]
000076049b1d8ecd  vmovaps xmm13, [rsp+0xC0]
000076049b1d8ed6  vmovaps xmm14, [rsp+0xD0]
000076049b1d8edf  vmovaps xmm15, [rsp+0xE0]
000076049b1d8ee8  add rsp, 0xF0
000076049b1d8eef  pop r11
000076049b1d8ef1  pop r10
000076049b1d8ef3  pop r9
000076049b1d8ef5  pop r8
000076049b1d8ef7  pop rsi
000076049b1d8ef8  pop rdi
000076049b1d8ef9  pop rdx
000076049b1d8efa  pop rcx
000076049b1d8efb  pop rax
000076049b1d8efc  add rsp, 0x08
000076049b1d8f00  jmp 0x000076049B1D61A1
000076049b1d8f05  sub rsp, 0x08
000076049b1d8f09  push rax
000076049b1d8f0a  push rcx
000076049b1d8f0b  push rdx
000076049b1d8f0c  push rdi
000076049b1d8f0d  push rsi
000076049b1d8f0e  push r8
000076049b1d8f10  push r9
000076049b1d8f12  push r10
000076049b1d8f14  push r11
000076049b1d8f16  sub rsp, 0xF0
000076049b1d8f1d  vmovaps [rsp], xmm0
000076049b1d8f22  vmovaps [rsp+0x10], xmm2
000076049b1d8f28  vmovaps [rsp+0x20], xmm3
000076049b1d8f2e  vmovaps [rsp+0x30], xmm4
000076049b1d8f34  vmovaps [rsp+0x40], xmm5
000076049b1d8f3a  vmovaps [rsp+0x50], xmm6
000076049b1d8f40  vmovaps [rsp+0x60], xmm7
000076049b1d8f46  vmovaps [rsp+0x70], xmm8
000076049b1d8f4c  vmovaps [rsp+0x80], xmm9
000076049b1d8f55  vmovaps [rsp+0x90], xmm10
000076049b1d8f5e  vmovaps [rsp+0xA0], xmm11
000076049b1d8f67  vmovaps [rsp+0xB0], xmm12
000076049b1d8f70  vmovaps [rsp+0xC0], xmm13
000076049b1d8f79  vmovaps [rsp+0xD0], xmm14
000076049b1d8f82  vmovaps [rsp+0xE0], xmm15
000076049b1d8f8b  sub rsp, 0x30
000076049b1d8f8f  movaps [rsp], xmm1
000076049b1d8f93  movaps [rsp+0x10], xmm15
000076049b1d8f99  movaps [rsp+0x20], xmm6
000076049b1d8f9e  lea rdi, [rsp]
000076049b1d8fa2  mov esi, 0x00
000076049b1d8fa7  mov rax, 0x64C06813C530
000076049b1d8fb1  call rax
000076049b1d8fb3  movaps xmm1, [rsp]
000076049b1d8fb7  add rsp, 0x30
000076049b1d8fbb  vmovaps xmm0, [rsp]
000076049b1d8fc0  vmovaps xmm2, [rsp+0x10]
000076049b1d8fc6  vmovaps xmm3, [rsp+0x20]
000076049b1d8fcc  vmovaps xmm4, [rsp+0x30]
000076049b1d8fd2  vmovaps xmm5, [rsp+0x40]
000076049b1d8fd8  vmovaps xmm6, [rsp+0x50]
000076049b1d8fde  vmovaps xmm7, [rsp+0x60]
000076049b1d8fe4  vmovaps xmm8, [rsp+0x70]
000076049b1d8fea  vmovaps xmm9, [rsp+0x80]
000076049b1d8ff3  vmovaps xmm10, [rsp+0x90]
000076049b1d8ffc  vmovaps xmm11, [rsp+0xA0]
000076049b1d9005  vmovaps xmm12, [rsp+0xB0]
000076049b1d900e  vmovaps xmm13, [rsp+0xC0]
000076049b1d9017  vmovaps xmm14, [rsp+0xD0]
000076049b1d9020  vmovaps xmm15, [rsp+0xE0]
000076049b1d9029  add rsp, 0xF0
000076049b1d9030  pop r11
000076049b1d9032  pop r10
000076049b1d9034  pop r9
000076049b1d9036  pop r8
000076049b1d9038  pop rsi
000076049b1d9039  pop rdi
000076049b1d903a  pop rdx
000076049b1d903b  pop rcx
000076049b1d903c  pop rax
000076049b1d903d  add rsp, 0x08
000076049b1d9041  jmp 0x000076049B1D61C2
000076049b1d9046  sub rsp, 0x08
000076049b1d904a  push rax
000076049b1d904b  push rcx
000076049b1d904c  push rdx
000076049b1d904d  push rdi
000076049b1d904e  push rsi
000076049b1d904f  push r8
000076049b1d9051  push r9
000076049b1d9053  push r10
000076049b1d9055  push r11
000076049b1d9057  sub rsp, 0xF0
000076049b1d905e  vmovaps [rsp], xmm0
000076049b1d9063  vmovaps [rsp+0x10], xmm1
000076049b1d9069  vmovaps [rsp+0x20], xmm2
000076049b1d906f  vmovaps [rsp+0x30], xmm3
000076049b1d9075  vmovaps [rsp+0x40], xmm4
000076049b1d907b  vmovaps [rsp+0x50], xmm5
000076049b1d9081  vmovaps [rsp+0x60], xmm6
000076049b1d9087  vmovaps [rsp+0x70], xmm7
000076049b1d908d  vmovaps [rsp+0x80], xmm8
000076049b1d9096  vmovaps [rsp+0x90], xmm9
000076049b1d909f  vmovaps [rsp+0xA0], xmm10
000076049b1d90a8  vmovaps [rsp+0xB0], xmm11
000076049b1d90b1  vmovaps [rsp+0xC0], xmm12
000076049b1d90ba  vmovaps [rsp+0xD0], xmm13
000076049b1d90c3  vmovaps [rsp+0xE0], xmm14
000076049b1d90cc  sub rsp, 0x30
000076049b1d90d0  movaps [rsp], xmm15
000076049b1d90d5  movaps [rsp+0x10], xmm5
000076049b1d90da  movaps [rsp+0x20], xmm3
000076049b1d90df  lea rdi, [rsp]
000076049b1d90e3  mov esi, 0x00
000076049b1d90e8  mov rax, 0x64C06813C530
000076049b1d90f2  call rax
000076049b1d90f4  movaps xmm15, [rsp]
000076049b1d90f9  add rsp, 0x30
000076049b1d90fd  vmovaps xmm0, [rsp]
000076049b1d9102  vmovaps xmm1, [rsp+0x10]
000076049b1d9108  vmovaps xmm2, [rsp+0x20]
000076049b1d910e  vmovaps xmm3, [rsp+0x30]
000076049b1d9114  vmovaps xmm4, [rsp+0x40]
000076049b1d911a  vmovaps xmm5, [rsp+0x50]
000076049b1d9120  vmovaps xmm6, [rsp+0x60]
000076049b1d9126  vmovaps xmm7, [rsp+0x70]
000076049b1d912c  vmovaps xmm8, [rsp+0x80]
000076049b1d9135  vmovaps xmm9, [rsp+0x90]
000076049b1d913e  vmovaps xmm10, [rsp+0xA0]
000076049b1d9147  vmovaps xmm11, [rsp+0xB0]
000076049b1d9150  vmovaps xmm12, [rsp+0xC0]
000076049b1d9159  vmovaps xmm13, [rsp+0xD0]
000076049b1d9162  vmovaps xmm14, [rsp+0xE0]
000076049b1d916b  add rsp, 0xF0
000076049b1d9172  pop r11
000076049b1d9174  pop r10
000076049b1d9176  pop r9
000076049b1d9178  pop r8
000076049b1d917a  pop rsi
000076049b1d917b  pop rdi
000076049b1d917c  pop rdx
000076049b1d917d  pop rcx
000076049b1d917e  pop rax
000076049b1d917f  add rsp, 0x08
000076049b1d9183  jmp 0x000076049B1D61DC
000076049b1d9188  sub rsp, 0x08
000076049b1d918c  push rax
000076049b1d918d  push rcx
000076049b1d918e  push rdx
000076049b1d918f  push rdi
000076049b1d9190  push rsi
000076049b1d9191  push r8
000076049b1d9193  push r9
000076049b1d9195  push r10
000076049b1d9197  push r11
000076049b1d9199  sub rsp, 0xF0
000076049b1d91a0  vmovaps [rsp], xmm0
000076049b1d91a5  vmovaps [rsp+0x10], xmm1
000076049b1d91ab  vmovaps [rsp+0x20], xmm2
000076049b1d91b1  vmovaps [rsp+0x30], xmm3
000076049b1d91b7  vmovaps [rsp+0x40], xmm4
000076049b1d91bd  vmovaps [rsp+0x50], xmm6
000076049b1d91c3  vmovaps [rsp+0x60], xmm7
000076049b1d91c9  vmovaps [rsp+0x70], xmm8
000076049b1d91cf  vmovaps [rsp+0x80], xmm9
000076049b1d91d8  vmovaps [rsp+0x90], xmm10
000076049b1d91e1  vmovaps [rsp+0xA0], xmm11
000076049b1d91ea  vmovaps [rsp+0xB0], xmm12
000076049b1d91f3  vmovaps [rsp+0xC0], xmm13
000076049b1d91fc  vmovaps [rsp+0xD0], xmm14
000076049b1d9205  vmovaps [rsp+0xE0], xmm15
000076049b1d920e  sub rsp, 0x30
000076049b1d9212  movaps [rsp], xmm5
000076049b1d9216  movaps [rsp+0x10], xmm8
000076049b1d921c  movaps [rsp+0x20], xmm6
000076049b1d9221  lea rdi, [rsp]
000076049b1d9225  mov esi, 0x00
000076049b1d922a  mov rax, 0x64C06813C530
000076049b1d9234  call rax
000076049b1d9236  movaps xmm5, [rsp]
000076049b1d923a  add rsp, 0x30
000076049b1d923e  vmovaps xmm0, [rsp]
000076049b1d9243  vmovaps xmm1, [rsp+0x10]
000076049b1d9249  vmovaps xmm2, [rsp+0x20]
000076049b1d924f  vmovaps xmm3, [rsp+0x30]
000076049b1d9255  vmovaps xmm4, [rsp+0x40]
000076049b1d925b  vmovaps xmm6, [rsp+0x50]
000076049b1d9261  vmovaps xmm7, [rsp+0x60]
000076049b1d9267  vmovaps xmm8, [rsp+0x70]
000076049b1d926d  vmovaps xmm9, [rsp+0x80]
000076049b1d9276  vmovaps xmm10, [rsp+0x90]
000076049b1d927f  vmovaps xmm11, [rsp+0xA0]
000076049b1d9288  vmovaps xmm12, [rsp+0xB0]
000076049b1d9291  vmovaps xmm13, [rsp+0xC0]
000076049b1d929a  vmovaps xmm14, [rsp+0xD0]
000076049b1d92a3  vmovaps xmm15, [rsp+0xE0]
000076049b1d92ac  add rsp, 0xF0
000076049b1d92b3  pop r11
000076049b1d92b5  pop r10
000076049b1d92b7  pop r9
000076049b1d92b9  pop r8
000076049b1d92bb  pop rsi
000076049b1d92bc  pop rdi
000076049b1d92bd  pop rdx
000076049b1d92be  pop rcx
000076049b1d92bf  pop rax
000076049b1d92c0  add rsp, 0x08
000076049b1d92c4  jmp 0x000076049B1D6200
000076049b1d92c9  sub rsp, 0x08
000076049b1d92cd  push rax
000076049b1d92ce  push rcx
000076049b1d92cf  push rdx
000076049b1d92d0  push rdi
000076049b1d92d1  push rsi
000076049b1d92d2  push r8
000076049b1d92d4  push r9
000076049b1d92d6  push r10
000076049b1d92d8  push r11
000076049b1d92da  sub rsp, 0xF0
000076049b1d92e1  vmovaps [rsp], xmm0
000076049b1d92e6  vmovaps [rsp+0x10], xmm1
000076049b1d92ec  vmovaps [rsp+0x20], xmm2
000076049b1d92f2  vmovaps [rsp+0x30], xmm3
000076049b1d92f8  vmovaps [rsp+0x40], xmm4
000076049b1d92fe  vmovaps [rsp+0x50], xmm5
000076049b1d9304  vmovaps [rsp+0x60], xmm7
000076049b1d930a  vmovaps [rsp+0x70], xmm8
000076049b1d9310  vmovaps [rsp+0x80], xmm9
000076049b1d9319  vmovaps [rsp+0x90], xmm10
000076049b1d9322  vmovaps [rsp+0xA0], xmm11
000076049b1d932b  vmovaps [rsp+0xB0], xmm12
000076049b1d9334  vmovaps [rsp+0xC0], xmm13
000076049b1d933d  vmovaps [rsp+0xD0], xmm14
000076049b1d9346  vmovaps [rsp+0xE0], xmm15
000076049b1d934f  sub rsp, 0x30
000076049b1d9353  movaps [rsp], xmm6
000076049b1d9357  movaps [rsp+0x10], xmm10
000076049b1d935d  movaps [rsp+0x20], xmm8
000076049b1d9363  lea rdi, [rsp]
000076049b1d9367  mov esi, 0x00
000076049b1d936c  mov rax, 0x64C06813C530
000076049b1d9376  call rax
000076049b1d9378  movaps xmm6, [rsp]
000076049b1d937c  add rsp, 0x30
000076049b1d9380  vmovaps xmm0, [rsp]
000076049b1d9385  vmovaps xmm1, [rsp+0x10]
000076049b1d938b  vmovaps xmm2, [rsp+0x20]
000076049b1d9391  vmovaps xmm3, [rsp+0x30]
000076049b1d9397  vmovaps xmm4, [rsp+0x40]
000076049b1d939d  vmovaps xmm5, [rsp+0x50]
000076049b1d93a3  vmovaps xmm7, [rsp+0x60]
000076049b1d93a9  vmovaps xmm8, [rsp+0x70]
000076049b1d93af  vmovaps xmm9, [rsp+0x80]
000076049b1d93b8  vmovaps xmm10, [rsp+0x90]
000076049b1d93c1  vmovaps xmm11, [rsp+0xA0]
000076049b1d93ca  vmovaps xmm12, [rsp+0xB0]
000076049b1d93d3  vmovaps xmm13, [rsp+0xC0]
000076049b1d93dc  vmovaps xmm14, [rsp+0xD0]
000076049b1d93e5  vmovaps xmm15, [rsp+0xE0]
000076049b1d93ee  add rsp, 0xF0
000076049b1d93f5  pop r11
000076049b1d93f7  pop r10
000076049b1d93f9  pop r9
000076049b1d93fb  pop r8
000076049b1d93fd  pop rsi
000076049b1d93fe  pop rdi
000076049b1d93ff  pop rdx
000076049b1d9400  pop rcx
000076049b1d9401  pop rax
000076049b1d9402  add rsp, 0x08
000076049b1d9406  jmp 0x000076049B1D6225
000076049b1d940b  sub rsp, 0x08
000076049b1d940f  push rax
000076049b1d9410  push rcx
000076049b1d9411  push rdx
000076049b1d9412  push rdi
000076049b1d9413  push rsi
000076049b1d9414  push r8
000076049b1d9416  push r9
000076049b1d9418  push r10
000076049b1d941a  push r11
000076049b1d941c  sub rsp, 0xF0
000076049b1d9423  vmovaps [rsp], xmm0
000076049b1d9428  vmovaps [rsp+0x10], xmm1
000076049b1d942e  vmovaps [rsp+0x20], xmm2
000076049b1d9434  vmovaps [rsp+0x30], xmm3
000076049b1d943a  vmovaps [rsp+0x40], xmm4
000076049b1d9440  vmovaps [rsp+0x50], xmm5
000076049b1d9446  vmovaps [rsp+0x60], xmm6
000076049b1d944c  vmovaps [rsp+0x70], xmm7
000076049b1d9452  vmovaps [rsp+0x80], xmm8
000076049b1d945b  vmovaps [rsp+0x90], xmm9
000076049b1d9464  vmovaps [rsp+0xA0], xmm11
000076049b1d946d  vmovaps [rsp+0xB0], xmm12
000076049b1d9476  vmovaps [rsp+0xC0], xmm13
000076049b1d947f  vmovaps [rsp+0xD0], xmm14
000076049b1d9488  vmovaps [rsp+0xE0], xmm15
000076049b1d9491  sub rsp, 0x30
000076049b1d9495  movaps [rsp], xmm10
000076049b1d949a  movaps [rsp+0x10], xmm8
000076049b1d94a0  movaps [rsp+0x20], xmm14
000076049b1d94a6  lea rdi, [rsp]
000076049b1d94aa  mov esi, 0x00
000076049b1d94af  mov rax, 0x64C06813C530
000076049b1d94b9  call rax
000076049b1d94bb  movaps xmm10, [rsp]
000076049b1d94c0  add rsp, 0x30
000076049b1d94c4  vmovaps xmm0, [rsp]
000076049b1d94c9  vmovaps xmm1, [rsp+0x10]
000076049b1d94cf  vmovaps xmm2, [rsp+0x20]
000076049b1d94d5  vmovaps xmm3, [rsp+0x30]
000076049b1d94db  vmovaps xmm4, [rsp+0x40]
000076049b1d94e1  vmovaps xmm5, [rsp+0x50]
000076049b1d94e7  vmovaps xmm6, [rsp+0x60]
000076049b1d94ed  vmovaps xmm7, [rsp+0x70]
000076049b1d94f3  vmovaps xmm8, [rsp+0x80]
000076049b1d94fc  vmovaps xmm9, [rsp+0x90]
000076049b1d9505  vmovaps xmm11, [rsp+0xA0]
000076049b1d950e  vmovaps xmm12, [rsp+0xB0]
000076049b1d9517  vmovaps xmm13, [rsp+0xC0]
000076049b1d9520  vmovaps xmm14, [rsp+0xD0]
000076049b1d9529  vmovaps xmm15, [rsp+0xE0]
000076049b1d9532  add rsp, 0xF0
000076049b1d9539  pop r11
000076049b1d953b  pop r10
000076049b1d953d  pop r9
000076049b1d953f  pop r8
000076049b1d9541  pop rsi
000076049b1d9542  pop rdi
000076049b1d9543  pop rdx
000076049b1d9544  pop rcx
000076049b1d9545  pop rax
000076049b1d9546  add rsp, 0x08
000076049b1d954a  jmp 0x000076049B1D6245
000076049b1d954f  sub rsp, 0x08
000076049b1d9553  push rax
000076049b1d9554  push rcx
000076049b1d9555  push rdx
000076049b1d9556  push rdi
000076049b1d9557  push rsi
000076049b1d9558  push r8
000076049b1d955a  push r9
000076049b1d955c  push r10
000076049b1d955e  push r11
000076049b1d9560  sub rsp, 0xF0
000076049b1d9567  vmovaps [rsp], xmm0
000076049b1d956c  vmovaps [rsp+0x10], xmm1
000076049b1d9572  vmovaps [rsp+0x20], xmm2
000076049b1d9578  vmovaps [rsp+0x30], xmm3
000076049b1d957e  vmovaps [rsp+0x40], xmm4
000076049b1d9584  vmovaps [rsp+0x50], xmm5
000076049b1d958a  vmovaps [rsp+0x60], xmm6
000076049b1d9590  vmovaps [rsp+0x70], xmm7
000076049b1d9596  vmovaps [rsp+0x80], xmm8
000076049b1d959f  vmovaps [rsp+0x90], xmm9
000076049b1d95a8  vmovaps [rsp+0xA0], xmm10
000076049b1d95b1  vmovaps [rsp+0xB0], xmm11
000076049b1d95ba  vmovaps [rsp+0xC0], xmm12
000076049b1d95c3  vmovaps [rsp+0xD0], xmm13
000076049b1d95cc  vmovaps [rsp+0xE0], xmm15
000076049b1d95d5  sub rsp, 0x30
000076049b1d95d9  movaps [rsp], xmm14
000076049b1d95de  movaps [rsp+0x10], xmm8
000076049b1d95e4  movaps [rsp+0x20], xmm4
000076049b1d95e9  lea rdi, [rsp]
000076049b1d95ed  mov esi, 0x00
000076049b1d95f2  mov rax, 0x64C06813C530
000076049b1d95fc  call rax
000076049b1d95fe  movaps xmm14, [rsp]
000076049b1d9603  add rsp, 0x30
000076049b1d9607  vmovaps xmm0, [rsp]
000076049b1d960c  vmovaps xmm1, [rsp+0x10]
000076049b1d9612  vmovaps xmm2, [rsp+0x20]
000076049b1d9618  vmovaps xmm3, [rsp+0x30]
000076049b1d961e  vmovaps xmm4, [rsp+0x40]
000076049b1d9624  vmovaps xmm5, [rsp+0x50]
000076049b1d962a  vmovaps xmm6, [rsp+0x60]
000076049b1d9630  vmovaps xmm7, [rsp+0x70]
000076049b1d9636  vmovaps xmm8, [rsp+0x80]
000076049b1d963f  vmovaps xmm9, [rsp+0x90]
000076049b1d9648  vmovaps xmm10, [rsp+0xA0]
000076049b1d9651  vmovaps xmm11, [rsp+0xB0]
000076049b1d965a  vmovaps xmm12, [rsp+0xC0]
000076049b1d9663  vmovaps xmm13, [rsp+0xD0]
000076049b1d966c  vmovaps xmm15, [rsp+0xE0]
000076049b1d9675  add rsp, 0xF0
000076049b1d967c  pop r11
000076049b1d967e  pop r10
000076049b1d9680  pop r9
000076049b1d9682  pop r8
000076049b1d9684  pop rsi
000076049b1d9685  pop rdi
000076049b1d9686  pop rdx
000076049b1d9687  pop rcx
000076049b1d9688  pop rax
000076049b1d9689  add rsp, 0x08
000076049b1d968d  jmp 0x000076049B1D6265
000076049b1d9692  sub rsp, 0x08
000076049b1d9696  push rax
000076049b1d9697  push rcx
000076049b1d9698  push rdx
000076049b1d9699  push rdi
000076049b1d969a  push rsi
000076049b1d969b  push r8
000076049b1d969d  push r9
000076049b1d969f  push r10
000076049b1d96a1  push r11
000076049b1d96a3  sub rsp, 0xF0
000076049b1d96aa  vmovaps [rsp], xmm0
000076049b1d96af  vmovaps [rsp+0x10], xmm1
000076049b1d96b5  vmovaps [rsp+0x20], xmm2
000076049b1d96bb  vmovaps [rsp+0x30], xmm3
000076049b1d96c1  vmovaps [rsp+0x40], xmm5
000076049b1d96c7  vmovaps [rsp+0x50], xmm6
000076049b1d96cd  vmovaps [rsp+0x60], xmm7
000076049b1d96d3  vmovaps [rsp+0x70], xmm8
000076049b1d96d9  vmovaps [rsp+0x80], xmm9
000076049b1d96e2  vmovaps [rsp+0x90], xmm10
000076049b1d96eb  vmovaps [rsp+0xA0], xmm11
000076049b1d96f4  vmovaps [rsp+0xB0], xmm12
000076049b1d96fd  vmovaps [rsp+0xC0], xmm13
000076049b1d9706  vmovaps [rsp+0xD0], xmm14
000076049b1d970f  vmovaps [rsp+0xE0], xmm15
000076049b1d9718  sub rsp, 0x30
000076049b1d971c  movaps [rsp], xmm4
000076049b1d9720  movaps [rsp+0x10], xmm13
000076049b1d9726  movaps [rsp+0x20], xmm8
000076049b1d972c  lea rdi, [rsp]
000076049b1d9730  mov esi, 0x00
000076049b1d9735  mov rax, 0x64C06813C530
000076049b1d973f  call rax
000076049b1d9741  movaps xmm4, [rsp]
000076049b1d9745  add rsp, 0x30
000076049b1d9749  vmovaps xmm0, [rsp]
000076049b1d974e  vmovaps xmm1, [rsp+0x10]
000076049b1d9754  vmovaps xmm2, [rsp+0x20]
000076049b1d975a  vmovaps xmm3, [rsp+0x30]
000076049b1d9760  vmovaps xmm5, [rsp+0x40]
000076049b1d9766  vmovaps xmm6, [rsp+0x50]
000076049b1d976c  vmovaps xmm7, [rsp+0x60]
000076049b1d9772  vmovaps xmm8, [rsp+0x70]
000076049b1d9778  vmovaps xmm9, [rsp+0x80]
000076049b1d9781  vmovaps xmm10, [rsp+0x90]
000076049b1d978a  vmovaps xmm11, [rsp+0xA0]
000076049b1d9793  vmovaps xmm12, [rsp+0xB0]
000076049b1d979c  vmovaps xmm13, [rsp+0xC0]
000076049b1d97a5  vmovaps xmm14, [rsp+0xD0]
000076049b1d97ae  vmovaps xmm15, [rsp+0xE0]
000076049b1d97b7  add rsp, 0xF0
000076049b1d97be  pop r11
000076049b1d97c0  pop r10
000076049b1d97c2  pop r9
000076049b1d97c4  pop r8
000076049b1d97c6  pop rsi
000076049b1d97c7  pop rdi
000076049b1d97c8  pop rdx
000076049b1d97c9  pop rcx
000076049b1d97ca  pop rax
000076049b1d97cb  add rsp, 0x08
000076049b1d97cf  jmp 0x000076049B1D628A
000076049b1d97d4  sub rsp, 0x08
000076049b1d97d8  push rax
000076049b1d97d9  push rcx
000076049b1d97da  push rdx
000076049b1d97db  push rdi
000076049b1d97dc  push rsi
000076049b1d97dd  push r8
000076049b1d97df  push r9
000076049b1d97e1  push r10
000076049b1d97e3  push r11
000076049b1d97e5  sub rsp, 0xF0
000076049b1d97ec  vmovaps [rsp], xmm0
000076049b1d97f1  vmovaps [rsp+0x10], xmm1
000076049b1d97f7  vmovaps [rsp+0x20], xmm2
000076049b1d97fd  vmovaps [rsp+0x30], xmm3
000076049b1d9803  vmovaps [rsp+0x40], xmm4
000076049b1d9809  vmovaps [rsp+0x50], xmm5
000076049b1d980f  vmovaps [rsp+0x60], xmm6
000076049b1d9815  vmovaps [rsp+0x70], xmm7
000076049b1d981b  vmovaps [rsp+0x80], xmm8
000076049b1d9824  vmovaps [rsp+0x90], xmm9
000076049b1d982d  vmovaps [rsp+0xA0], xmm10
000076049b1d9836  vmovaps [rsp+0xB0], xmm11
000076049b1d983f  vmovaps [rsp+0xC0], xmm12
000076049b1d9848  vmovaps [rsp+0xD0], xmm14
000076049b1d9851  vmovaps [rsp+0xE0], xmm15
000076049b1d985a  sub rsp, 0x30
000076049b1d985e  movaps [rsp], xmm13
000076049b1d9863  movaps [rsp+0x10], xmm15
000076049b1d9869  movaps [rsp+0x20], xmm9
000076049b1d986f  lea rdi, [rsp]
000076049b1d9873  mov esi, 0x00
000076049b1d9878  mov rax, 0x64C06813C530
000076049b1d9882  call rax
000076049b1d9884  movaps xmm13, [rsp]
000076049b1d9889  add rsp, 0x30
000076049b1d988d  vmovaps xmm0, [rsp]
000076049b1d9892  vmovaps xmm1, [rsp+0x10]
000076049b1d9898  vmovaps xmm2, [rsp+0x20]
000076049b1d989e  vmovaps xmm3, [rsp+0x30]
000076049b1d98a4  vmovaps xmm4, [rsp+0x40]
000076049b1d98aa  vmovaps xmm5, [rsp+0x50]
000076049b1d98b0  vmovaps xmm6, [rsp+0x60]
000076049b1d98b6  vmovaps xmm7, [rsp+0x70]
000076049b1d98bc  vmovaps xmm8, [rsp+0x80]
000076049b1d98c5  vmovaps xmm9, [rsp+0x90]
000076049b1d98ce  vmovaps xmm10, [rsp+0xA0]
000076049b1d98d7  vmovaps xmm11, [rsp+0xB0]
000076049b1d98e0  vmovaps xmm12, [rsp+0xC0]
000076049b1d98e9  vmovaps xmm14, [rsp+0xD0]
000076049b1d98f2  vmovaps xmm15, [rsp+0xE0]
000076049b1d98fb  add rsp, 0xF0
000076049b1d9902  pop r11
000076049b1d9904  pop r10
000076049b1d9906  pop r9
000076049b1d9908  pop r8
000076049b1d990a  pop rsi
000076049b1d990b  pop rdi
000076049b1d990c  pop rdx
000076049b1d990d  pop rcx
000076049b1d990e  pop rax
000076049b1d990f  add rsp, 0x08
000076049b1d9913  jmp 0x000076049B1D62A5
000076049b1d9918  sub rsp, 0x08
000076049b1d991c  push rax
000076049b1d991d  push rcx
000076049b1d991e  push rdx
000076049b1d991f  push rdi
000076049b1d9920  push rsi
000076049b1d9921  push r8
000076049b1d9923  push r9
000076049b1d9925  push r10
000076049b1d9927  push r11
000076049b1d9929  sub rsp, 0xF0
000076049b1d9930  vmovaps [rsp], xmm0
000076049b1d9935  vmovaps [rsp+0x10], xmm1
000076049b1d993b  vmovaps [rsp+0x20], xmm2
000076049b1d9941  vmovaps [rsp+0x30], xmm3
000076049b1d9947  vmovaps [rsp+0x40], xmm4
000076049b1d994d  vmovaps [rsp+0x50], xmm5
000076049b1d9953  vmovaps [rsp+0x60], xmm6
000076049b1d9959  vmovaps [rsp+0x70], xmm7
000076049b1d995f  vmovaps [rsp+0x80], xmm8
000076049b1d9968  vmovaps [rsp+0x90], xmm9
000076049b1d9971  vmovaps [rsp+0xA0], xmm10
000076049b1d997a  vmovaps [rsp+0xB0], xmm11
000076049b1d9983  vmovaps [rsp+0xC0], xmm12
000076049b1d998c  vmovaps [rsp+0xD0], xmm13
000076049b1d9995  vmovaps [rsp+0xE0], xmm14
000076049b1d999e  sub rsp, 0x30
000076049b1d99a2  movaps [rsp], xmm15
000076049b1d99a7  movaps [rsp+0x10], xmm1
000076049b1d99ac  movaps [rsp+0x20], xmm5
000076049b1d99b1  lea rdi, [rsp]
000076049b1d99b5  mov esi, 0x00
000076049b1d99ba  mov rax, 0x64C06813C530
000076049b1d99c4  call rax
000076049b1d99c6  movaps xmm15, [rsp]
000076049b1d99cb  add rsp, 0x30
000076049b1d99cf  vmovaps xmm0, [rsp]
000076049b1d99d4  vmovaps xmm1, [rsp+0x10]
000076049b1d99da  vmovaps xmm2, [rsp+0x20]
000076049b1d99e0  vmovaps xmm3, [rsp+0x30]
000076049b1d99e6  vmovaps xmm4, [rsp+0x40]
000076049b1d99ec  vmovaps xmm5, [rsp+0x50]
000076049b1d99f2  vmovaps xmm6, [rsp+0x60]
000076049b1d99f8  vmovaps xmm7, [rsp+0x70]
000076049b1d99fe  vmovaps xmm8, [rsp+0x80]
000076049b1d9a07  vmovaps xmm9, [rsp+0x90]
000076049b1d9a10  vmovaps xmm10, [rsp+0xA0]
000076049b1d9a19  vmovaps xmm11, [rsp+0xB0]
000076049b1d9a22  vmovaps xmm12, [rsp+0xC0]
000076049b1d9a2b  vmovaps xmm13, [rsp+0xD0]
000076049b1d9a34  vmovaps xmm14, [rsp+0xE0]
000076049b1d9a3d  add rsp, 0xF0
000076049b1d9a44  pop r11
000076049b1d9a46  pop r10
000076049b1d9a48  pop r9
000076049b1d9a4a  pop r8
000076049b1d9a4c  pop rsi
000076049b1d9a4d  pop rdi
000076049b1d9a4e  pop rdx
000076049b1d9a4f  pop rcx
000076049b1d9a50  pop rax
000076049b1d9a51  add rsp, 0x08
000076049b1d9a55  jmp 0x000076049B1D62C0
000076049b1d9a5a  call 0x000076049B0D64F0
000076049b1d9a5f  jmp 0x000076049B1D631B
000076049b1d9a64  sub rsp, 0x08
000076049b1d9a68  push rax
000076049b1d9a69  push rcx
000076049b1d9a6a  push rdx
000076049b1d9a6b  push rdi
000076049b1d9a6c  push rsi
000076049b1d9a6d  push r8
000076049b1d9a6f  push r9
000076049b1d9a71  push r10
000076049b1d9a73  push r11
000076049b1d9a75  sub rsp, 0xF0
000076049b1d9a7c  vmovaps [rsp], xmm0
000076049b1d9a81  vmovaps [rsp+0x10], xmm1
000076049b1d9a87  vmovaps [rsp+0x20], xmm2
000076049b1d9a8d  vmovaps [rsp+0x30], xmm3
000076049b1d9a93  vmovaps [rsp+0x40], xmm4
000076049b1d9a99  vmovaps [rsp+0x50], xmm5
000076049b1d9a9f  vmovaps [rsp+0x60], xmm6
000076049b1d9aa5  vmovaps [rsp+0x70], xmm7
000076049b1d9aab  vmovaps [rsp+0x80], xmm8
000076049b1d9ab4  vmovaps [rsp+0x90], xmm10
000076049b1d9abd  vmovaps [rsp+0xA0], xmm11
000076049b1d9ac6  vmovaps [rsp+0xB0], xmm12
000076049b1d9acf  vmovaps [rsp+0xC0], xmm13
000076049b1d9ad8  vmovaps [rsp+0xD0], xmm14
000076049b1d9ae1  vmovaps [rsp+0xE0], xmm15
000076049b1d9aea  sub rsp, 0x30
000076049b1d9aee  movaps [rsp], xmm9
000076049b1d9af3  movaps [rsp+0x10], xmm8
000076049b1d9af9  movaps [rsp+0x20], xmm11
000076049b1d9aff  lea rdi, [rsp]
000076049b1d9b03  mov esi, 0x00
000076049b1d9b08  mov rax, 0x64C06813C530
000076049b1d9b12  call rax
000076049b1d9b14  movaps xmm9, [rsp]
000076049b1d9b19  add rsp, 0x30
000076049b1d9b1d  vmovaps xmm0, [rsp]
000076049b1d9b22  vmovaps xmm1, [rsp+0x10]
000076049b1d9b28  vmovaps xmm2, [rsp+0x20]
000076049b1d9b2e  vmovaps xmm3, [rsp+0x30]
000076049b1d9b34  vmovaps xmm4, [rsp+0x40]
000076049b1d9b3a  vmovaps xmm5, [rsp+0x50]
000076049b1d9b40  vmovaps xmm6, [rsp+0x60]
000076049b1d9b46  vmovaps xmm7, [rsp+0x70]
000076049b1d9b4c  vmovaps xmm8, [rsp+0x80]
000076049b1d9b55  vmovaps xmm10, [rsp+0x90]
000076049b1d9b5e  vmovaps xmm11, [rsp+0xA0]
000076049b1d9b67  vmovaps xmm12, [rsp+0xB0]
000076049b1d9b70  vmovaps xmm13, [rsp+0xC0]
000076049b1d9b79  vmovaps xmm14, [rsp+0xD0]
000076049b1d9b82  vmovaps xmm15, [rsp+0xE0]
000076049b1d9b8b  add rsp, 0xF0
000076049b1d9b92  pop r11
000076049b1d9b94  pop r10
000076049b1d9b96  pop r9
000076049b1d9b98  pop r8
000076049b1d9b9a  pop rsi
000076049b1d9b9b  pop rdi
000076049b1d9b9c  pop rdx
000076049b1d9b9d  pop rcx
000076049b1d9b9e  pop rax
000076049b1d9b9f  add rsp, 0x08
000076049b1d9ba3  jmp 0x000076049B1D6352
000076049b1d9ba8  sub rsp, 0x08
000076049b1d9bac  push rax
000076049b1d9bad  push rcx
000076049b1d9bae  push rdx
000076049b1d9baf  push rdi
000076049b1d9bb0  push rsi
000076049b1d9bb1  push r8
000076049b1d9bb3  push r9
000076049b1d9bb5  push r10
000076049b1d9bb7  push r11
000076049b1d9bb9  sub rsp, 0xF0
000076049b1d9bc0  vmovaps [rsp], xmm0
000076049b1d9bc5  vmovaps [rsp+0x10], xmm1
000076049b1d9bcb  vmovaps [rsp+0x20], xmm2
000076049b1d9bd1  vmovaps [rsp+0x30], xmm3
000076049b1d9bd7  vmovaps [rsp+0x40], xmm4
000076049b1d9bdd  vmovaps [rsp+0x50], xmm5
000076049b1d9be3  vmovaps [rsp+0x60], xmm6
000076049b1d9be9  vmovaps [rsp+0x70], xmm7
000076049b1d9bef  vmovaps [rsp+0x80], xmm8
000076049b1d9bf8  vmovaps [rsp+0x90], xmm9
000076049b1d9c01  vmovaps [rsp+0xA0], xmm10
000076049b1d9c0a  vmovaps [rsp+0xB0], xmm12
000076049b1d9c13  vmovaps [rsp+0xC0], xmm13
000076049b1d9c1c  vmovaps [rsp+0xD0], xmm14
000076049b1d9c25  vmovaps [rsp+0xE0], xmm15
000076049b1d9c2e  sub rsp, 0x30
000076049b1d9c32  movaps [rsp], xmm11
000076049b1d9c37  movaps [rsp+0x10], xmm10
000076049b1d9c3d  movaps [rsp+0x20], xmm6
000076049b1d9c42  lea rdi, [rsp]
000076049b1d9c46  mov esi, 0x00
000076049b1d9c4b  mov rax, 0x64C06813C530
000076049b1d9c55  call rax
000076049b1d9c57  movaps xmm11, [rsp]
000076049b1d9c5c  add rsp, 0x30
000076049b1d9c60  vmovaps xmm0, [rsp]
000076049b1d9c65  vmovaps xmm1, [rsp+0x10]
000076049b1d9c6b  vmovaps xmm2, [rsp+0x20]
000076049b1d9c71  vmovaps xmm3, [rsp+0x30]
000076049b1d9c77  vmovaps xmm4, [rsp+0x40]
000076049b1d9c7d  vmovaps xmm5, [rsp+0x50]
000076049b1d9c83  vmovaps xmm6, [rsp+0x60]
000076049b1d9c89  vmovaps xmm7, [rsp+0x70]
000076049b1d9c8f  vmovaps xmm8, [rsp+0x80]
000076049b1d9c98  vmovaps xmm9, [rsp+0x90]
000076049b1d9ca1  vmovaps xmm10, [rsp+0xA0]
000076049b1d9caa  vmovaps xmm12, [rsp+0xB0]
000076049b1d9cb3  vmovaps xmm13, [rsp+0xC0]
000076049b1d9cbc  vmovaps xmm14, [rsp+0xD0]
000076049b1d9cc5  vmovaps xmm15, [rsp+0xE0]
000076049b1d9cce  add rsp, 0xF0
000076049b1d9cd5  pop r11
000076049b1d9cd7  pop r10
000076049b1d9cd9  pop r9
000076049b1d9cdb  pop r8
000076049b1d9cdd  pop rsi
000076049b1d9cde  pop rdi
000076049b1d9cdf  pop rdx
000076049b1d9ce0  pop rcx
000076049b1d9ce1  pop rax
000076049b1d9ce2  add rsp, 0x08
000076049b1d9ce6  jmp 0x000076049B1D636D
000076049b1d9ceb  sub rsp, 0x08
000076049b1d9cef  push rax
000076049b1d9cf0  push rcx
000076049b1d9cf1  push rdx
000076049b1d9cf2  push rdi
000076049b1d9cf3  push rsi
000076049b1d9cf4  push r8
000076049b1d9cf6  push r9
000076049b1d9cf8  push r10
000076049b1d9cfa  push r11
000076049b1d9cfc  sub rsp, 0xF0
000076049b1d9d03  vmovaps [rsp], xmm0
000076049b1d9d08  vmovaps [rsp+0x10], xmm1
000076049b1d9d0e  vmovaps [rsp+0x20], xmm2
000076049b1d9d14  vmovaps [rsp+0x30], xmm3
000076049b1d9d1a  vmovaps [rsp+0x40], xmm4
000076049b1d9d20  vmovaps [rsp+0x50], xmm5
000076049b1d9d26  vmovaps [rsp+0x60], xmm6
000076049b1d9d2c  vmovaps [rsp+0x70], xmm7
000076049b1d9d32  vmovaps [rsp+0x80], xmm8
000076049b1d9d3b  vmovaps [rsp+0x90], xmm9
000076049b1d9d44  vmovaps [rsp+0xA0], xmm11
000076049b1d9d4d  vmovaps [rsp+0xB0], xmm12
000076049b1d9d56  vmovaps [rsp+0xC0], xmm13
000076049b1d9d5f  vmovaps [rsp+0xD0], xmm14
000076049b1d9d68  vmovaps [rsp+0xE0], xmm15
000076049b1d9d71  sub rsp, 0x30
000076049b1d9d75  movaps [rsp], xmm10
000076049b1d9d7a  movaps [rsp+0x10], xmm14
000076049b1d9d80  movaps [rsp+0x20], xmm4
000076049b1d9d85  lea rdi, [rsp]
000076049b1d9d89  mov esi, 0x00
000076049b1d9d8e  mov rax, 0x64C06813C530
000076049b1d9d98  call rax
000076049b1d9d9a  movaps xmm10, [rsp]
000076049b1d9d9f  add rsp, 0x30
000076049b1d9da3  vmovaps xmm0, [rsp]
000076049b1d9da8  vmovaps xmm1, [rsp+0x10]
000076049b1d9dae  vmovaps xmm2, [rsp+0x20]
000076049b1d9db4  vmovaps xmm3, [rsp+0x30]
000076049b1d9dba  vmovaps xmm4, [rsp+0x40]
000076049b1d9dc0  vmovaps xmm5, [rsp+0x50]
000076049b1d9dc6  vmovaps xmm6, [rsp+0x60]
000076049b1d9dcc  vmovaps xmm7, [rsp+0x70]
000076049b1d9dd2  vmovaps xmm8, [rsp+0x80]
000076049b1d9ddb  vmovaps xmm9, [rsp+0x90]
000076049b1d9de4  vmovaps xmm11, [rsp+0xA0]
000076049b1d9ded  vmovaps xmm12, [rsp+0xB0]
000076049b1d9df6  vmovaps xmm13, [rsp+0xC0]
000076049b1d9dff  vmovaps xmm14, [rsp+0xD0]
000076049b1d9e08  vmovaps xmm15, [rsp+0xE0]
000076049b1d9e11  add rsp, 0xF0
000076049b1d9e18  pop r11
000076049b1d9e1a  pop r10
000076049b1d9e1c  pop r9
000076049b1d9e1e  pop r8
000076049b1d9e20  pop rsi
000076049b1d9e21  pop rdi
000076049b1d9e22  pop rdx
000076049b1d9e23  pop rcx
000076049b1d9e24  pop rax
000076049b1d9e25  add rsp, 0x08
000076049b1d9e29  jmp 0x000076049B1D6388
000076049b1d9e2e  sub rsp, 0x08
000076049b1d9e32  push rax
000076049b1d9e33  push rcx
000076049b1d9e34  push rdx
000076049b1d9e35  push rdi
000076049b1d9e36  push rsi
000076049b1d9e37  push r8
000076049b1d9e39  push r9
000076049b1d9e3b  push r10
000076049b1d9e3d  push r11
000076049b1d9e3f  sub rsp, 0xF0
000076049b1d9e46  vmovaps [rsp], xmm0
000076049b1d9e4b  vmovaps [rsp+0x10], xmm1
000076049b1d9e51  vmovaps [rsp+0x20], xmm2
000076049b1d9e57  vmovaps [rsp+0x30], xmm3
000076049b1d9e5d  vmovaps [rsp+0x40], xmm4
000076049b1d9e63  vmovaps [rsp+0x50], xmm5
000076049b1d9e69  vmovaps [rsp+0x60], xmm6
000076049b1d9e6f  vmovaps [rsp+0x70], xmm7
000076049b1d9e75  vmovaps [rsp+0x80], xmm9
000076049b1d9e7e  vmovaps [rsp+0x90], xmm10
000076049b1d9e87  vmovaps [rsp+0xA0], xmm11
000076049b1d9e90  vmovaps [rsp+0xB0], xmm12
000076049b1d9e99  vmovaps [rsp+0xC0], xmm13
000076049b1d9ea2  vmovaps [rsp+0xD0], xmm14
000076049b1d9eab  vmovaps [rsp+0xE0], xmm15
000076049b1d9eb4  sub rsp, 0x30
000076049b1d9eb8  movaps [rsp], xmm8
000076049b1d9ebd  movaps [rsp+0x10], xmm1
000076049b1d9ec2  movaps [rsp+0x20], xmm14
000076049b1d9ec8  lea rdi, [rsp]
000076049b1d9ecc  mov esi, 0x00
000076049b1d9ed1  mov rax, 0x64C06813C530
000076049b1d9edb  call rax
000076049b1d9edd  movaps xmm8, [rsp]
000076049b1d9ee2  add rsp, 0x30
000076049b1d9ee6  vmovaps xmm0, [rsp]
000076049b1d9eeb  vmovaps xmm1, [rsp+0x10]
000076049b1d9ef1  vmovaps xmm2, [rsp+0x20]
000076049b1d9ef7  vmovaps xmm3, [rsp+0x30]
000076049b1d9efd  vmovaps xmm4, [rsp+0x40]
000076049b1d9f03  vmovaps xmm5, [rsp+0x50]
000076049b1d9f09  vmovaps xmm6, [rsp+0x60]
000076049b1d9f0f  vmovaps xmm7, [rsp+0x70]
000076049b1d9f15  vmovaps xmm9, [rsp+0x80]
000076049b1d9f1e  vmovaps xmm10, [rsp+0x90]
000076049b1d9f27  vmovaps xmm11, [rsp+0xA0]
000076049b1d9f30  vmovaps xmm12, [rsp+0xB0]
000076049b1d9f39  vmovaps xmm13, [rsp+0xC0]
000076049b1d9f42  vmovaps xmm14, [rsp+0xD0]
000076049b1d9f4b  vmovaps xmm15, [rsp+0xE0]
000076049b1d9f54  add rsp, 0xF0
000076049b1d9f5b  pop r11
000076049b1d9f5d  pop r10
000076049b1d9f5f  pop r9
000076049b1d9f61  pop r8
000076049b1d9f63  pop rsi
000076049b1d9f64  pop rdi
000076049b1d9f65  pop rdx
000076049b1d9f66  pop rcx
000076049b1d9f67  pop rax
000076049b1d9f68  add rsp, 0x08
000076049b1d9f6c  jmp 0x000076049B1D63AE
000076049b1d9f71  sub rsp, 0x08
000076049b1d9f75  push rax
000076049b1d9f76  push rcx
000076049b1d9f77  push rdx
000076049b1d9f78  push rdi
000076049b1d9f79  push rsi
000076049b1d9f7a  push r8
000076049b1d9f7c  push r9
000076049b1d9f7e  push r10
000076049b1d9f80  push r11
000076049b1d9f82  sub rsp, 0xF0
000076049b1d9f89  vmovaps [rsp], xmm0
000076049b1d9f8e  vmovaps [rsp+0x10], xmm1
000076049b1d9f94  vmovaps [rsp+0x20], xmm2
000076049b1d9f9a  vmovaps [rsp+0x30], xmm3
000076049b1d9fa0  vmovaps [rsp+0x40], xmm4
000076049b1d9fa6  vmovaps [rsp+0x50], xmm5
000076049b1d9fac  vmovaps [rsp+0x60], xmm7
000076049b1d9fb2  vmovaps [rsp+0x70], xmm8
000076049b1d9fb8  vmovaps [rsp+0x80], xmm9
000076049b1d9fc1  vmovaps [rsp+0x90], xmm10
000076049b1d9fca  vmovaps [rsp+0xA0], xmm11
000076049b1d9fd3  vmovaps [rsp+0xB0], xmm12
000076049b1d9fdc  vmovaps [rsp+0xC0], xmm13
000076049b1d9fe5  vmovaps [rsp+0xD0], xmm14
000076049b1d9fee  vmovaps [rsp+0xE0], xmm15
000076049b1d9ff7  sub rsp, 0x30
000076049b1d9ffb  movaps [rsp], xmm6
000076049b1d9fff  movaps [rsp+0x10], xmm1
000076049b1da004  movaps [rsp+0x20], xmm14
000076049b1da00a  lea rdi, [rsp]
000076049b1da00e  mov esi, 0x00
000076049b1da013  mov rax, 0x64C06813C530
000076049b1da01d  call rax
000076049b1da01f  movaps xmm6, [rsp]
000076049b1da023  add rsp, 0x30
000076049b1da027  vmovaps xmm0, [rsp]
000076049b1da02c  vmovaps xmm1, [rsp+0x10]
000076049b1da032  vmovaps xmm2, [rsp+0x20]
000076049b1da038  vmovaps xmm3, [rsp+0x30]
000076049b1da03e  vmovaps xmm4, [rsp+0x40]
000076049b1da044  vmovaps xmm5, [rsp+0x50]
000076049b1da04a  vmovaps xmm7, [rsp+0x60]
000076049b1da050  vmovaps xmm8, [rsp+0x70]
000076049b1da056  vmovaps xmm9, [rsp+0x80]
000076049b1da05f  vmovaps xmm10, [rsp+0x90]
000076049b1da068  vmovaps xmm11, [rsp+0xA0]
000076049b1da071  vmovaps xmm12, [rsp+0xB0]
000076049b1da07a  vmovaps xmm13, [rsp+0xC0]
000076049b1da083  vmovaps xmm14, [rsp+0xD0]
000076049b1da08c  vmovaps xmm15, [rsp+0xE0]
000076049b1da095  add rsp, 0xF0
000076049b1da09c  pop r11
000076049b1da09e  pop r10
000076049b1da0a0  pop r9
000076049b1da0a2  pop r8
000076049b1da0a4  pop rsi
000076049b1da0a5  pop rdi
000076049b1da0a6  pop rdx
000076049b1da0a7  pop rcx
000076049b1da0a8  pop rax
000076049b1da0a9  add rsp, 0x08
000076049b1da0ad  jmp 0x000076049B1D63DA
000076049b1da0b2  sub rsp, 0x08
000076049b1da0b6  push rax
000076049b1da0b7  push rcx
000076049b1da0b8  push rdx
000076049b1da0b9  push rdi
000076049b1da0ba  push rsi
000076049b1da0bb  push r8
000076049b1da0bd  push r9
000076049b1da0bf  push r10
000076049b1da0c1  push r11
000076049b1da0c3  sub rsp, 0xF0
000076049b1da0ca  vmovaps [rsp], xmm0
000076049b1da0cf  vmovaps [rsp+0x10], xmm1
000076049b1da0d5  vmovaps [rsp+0x20], xmm2
000076049b1da0db  vmovaps [rsp+0x30], xmm3
000076049b1da0e1  vmovaps [rsp+0x40], xmm4
000076049b1da0e7  vmovaps [rsp+0x50], xmm5
000076049b1da0ed  vmovaps [rsp+0x60], xmm6
000076049b1da0f3  vmovaps [rsp+0x70], xmm7
000076049b1da0f9  vmovaps [rsp+0x80], xmm8
000076049b1da102  vmovaps [rsp+0x90], xmm9
000076049b1da10b  vmovaps [rsp+0xA0], xmm10
000076049b1da114  vmovaps [rsp+0xB0], xmm11
000076049b1da11d  vmovaps [rsp+0xC0], xmm12
000076049b1da126  vmovaps [rsp+0xD0], xmm13
000076049b1da12f  vmovaps [rsp+0xE0], xmm15
000076049b1da138  sub rsp, 0x30
000076049b1da13c  movaps [rsp], xmm14
000076049b1da141  movaps [rsp+0x10], xmm12
000076049b1da147  movaps [rsp+0x20], xmm1
000076049b1da14c  lea rdi, [rsp]
000076049b1da150  mov esi, 0x00
000076049b1da155  mov rax, 0x64C06813C530
000076049b1da15f  call rax
000076049b1da161  movaps xmm14, [rsp]
000076049b1da166  add rsp, 0x30
000076049b1da16a  vmovaps xmm0, [rsp]
000076049b1da16f  vmovaps xmm1, [rsp+0x10]
000076049b1da175  vmovaps xmm2, [rsp+0x20]
000076049b1da17b  vmovaps xmm3, [rsp+0x30]
000076049b1da181  vmovaps xmm4, [rsp+0x40]
000076049b1da187  vmovaps xmm5, [rsp+0x50]
000076049b1da18d  vmovaps xmm6, [rsp+0x60]
000076049b1da193  vmovaps xmm7, [rsp+0x70]
000076049b1da199  vmovaps xmm8, [rsp+0x80]
000076049b1da1a2  vmovaps xmm9, [rsp+0x90]
000076049b1da1ab  vmovaps xmm10, [rsp+0xA0]
000076049b1da1b4  vmovaps xmm11, [rsp+0xB0]
000076049b1da1bd  vmovaps xmm12, [rsp+0xC0]
000076049b1da1c6  vmovaps xmm13, [rsp+0xD0]
000076049b1da1cf  vmovaps xmm15, [rsp+0xE0]
000076049b1da1d8  add rsp, 0xF0
000076049b1da1df  pop r11
000076049b1da1e1  pop r10
000076049b1da1e3  pop r9
000076049b1da1e5  pop r8
000076049b1da1e7  pop rsi
000076049b1da1e8  pop rdi
000076049b1da1e9  pop rdx
000076049b1da1ea  pop rcx
000076049b1da1eb  pop rax
000076049b1da1ec  add rsp, 0x08
000076049b1da1f0  jmp 0x000076049B1D6400
000076049b1da1f5  sub rsp, 0x08
000076049b1da1f9  push rax
000076049b1da1fa  push rcx
000076049b1da1fb  push rdx
000076049b1da1fc  push rdi
000076049b1da1fd  push rsi
000076049b1da1fe  push r8
000076049b1da200  push r9
000076049b1da202  push r10
000076049b1da204  push r11
000076049b1da206  sub rsp, 0xF0
000076049b1da20d  vmovaps [rsp], xmm0
000076049b1da212  vmovaps [rsp+0x10], xmm2
000076049b1da218  vmovaps [rsp+0x20], xmm3
000076049b1da21e  vmovaps [rsp+0x30], xmm4
000076049b1da224  vmovaps [rsp+0x40], xmm5
000076049b1da22a  vmovaps [rsp+0x50], xmm6
000076049b1da230  vmovaps [rsp+0x60], xmm7
000076049b1da236  vmovaps [rsp+0x70], xmm8
000076049b1da23c  vmovaps [rsp+0x80], xmm9
000076049b1da245  vmovaps [rsp+0x90], xmm10
000076049b1da24e  vmovaps [rsp+0xA0], xmm11
000076049b1da257  vmovaps [rsp+0xB0], xmm12
000076049b1da260  vmovaps [rsp+0xC0], xmm13
000076049b1da269  vmovaps [rsp+0xD0], xmm14
000076049b1da272  vmovaps [rsp+0xE0], xmm15
000076049b1da27b  sub rsp, 0x30
000076049b1da27f  movaps [rsp], xmm1
000076049b1da283  movaps [rsp+0x10], xmm13
000076049b1da289  movaps [rsp+0x20], xmm9
000076049b1da28f  lea rdi, [rsp]
000076049b1da293  mov esi, 0x00
000076049b1da298  mov rax, 0x64C06813C530
000076049b1da2a2  call rax
000076049b1da2a4  movaps xmm1, [rsp]
000076049b1da2a8  add rsp, 0x30
000076049b1da2ac  vmovaps xmm0, [rsp]
000076049b1da2b1  vmovaps xmm2, [rsp+0x10]
000076049b1da2b7  vmovaps xmm3, [rsp+0x20]
000076049b1da2bd  vmovaps xmm4, [rsp+0x30]
000076049b1da2c3  vmovaps xmm5, [rsp+0x40]
000076049b1da2c9  vmovaps xmm6, [rsp+0x50]
000076049b1da2cf  vmovaps xmm7, [rsp+0x60]
000076049b1da2d5  vmovaps xmm8, [rsp+0x70]
000076049b1da2db  vmovaps xmm9, [rsp+0x80]
000076049b1da2e4  vmovaps xmm10, [rsp+0x90]
000076049b1da2ed  vmovaps xmm11, [rsp+0xA0]
000076049b1da2f6  vmovaps xmm12, [rsp+0xB0]
000076049b1da2ff  vmovaps xmm13, [rsp+0xC0]
000076049b1da308  vmovaps xmm14, [rsp+0xD0]
000076049b1da311  vmovaps xmm15, [rsp+0xE0]
000076049b1da31a  add rsp, 0xF0
000076049b1da321  pop r11
000076049b1da323  pop r10
000076049b1da325  pop r9
000076049b1da327  pop r8
000076049b1da329  pop rsi
000076049b1da32a  pop rdi
000076049b1da32b  pop rdx
000076049b1da32c  pop rcx
000076049b1da32d  pop rax
000076049b1da32e  add rsp, 0x08
000076049b1da332  jmp 0x000076049B1D641A
000076049b1da337  sub rsp, 0x08
000076049b1da33b  push rax
000076049b1da33c  push rcx
000076049b1da33d  push rdx
000076049b1da33e  push rdi
000076049b1da33f  push rsi
000076049b1da340  push r8
000076049b1da342  push r9
000076049b1da344  push r10
000076049b1da346  push r11
000076049b1da348  sub rsp, 0xF0
000076049b1da34f  vmovaps [rsp], xmm0
000076049b1da354  vmovaps [rsp+0x10], xmm1
000076049b1da35a  vmovaps [rsp+0x20], xmm2
000076049b1da360  vmovaps [rsp+0x30], xmm3
000076049b1da366  vmovaps [rsp+0x40], xmm4
000076049b1da36c  vmovaps [rsp+0x50], xmm5
000076049b1da372  vmovaps [rsp+0x60], xmm6
000076049b1da378  vmovaps [rsp+0x70], xmm7
000076049b1da37e  vmovaps [rsp+0x80], xmm8
000076049b1da387  vmovaps [rsp+0x90], xmm9
000076049b1da390  vmovaps [rsp+0xA0], xmm10
000076049b1da399  vmovaps [rsp+0xB0], xmm11
000076049b1da3a2  vmovaps [rsp+0xC0], xmm13
000076049b1da3ab  vmovaps [rsp+0xD0], xmm14
000076049b1da3b4  vmovaps [rsp+0xE0], xmm15
000076049b1da3bd  sub rsp, 0x30
000076049b1da3c1  movaps [rsp], xmm12
000076049b1da3c6  movaps [rsp+0x10], xmm7
000076049b1da3cb  movaps [rsp+0x20], xmm13
000076049b1da3d1  lea rdi, [rsp]
000076049b1da3d5  mov esi, 0x00
000076049b1da3da  mov rax, 0x64C06813C530
000076049b1da3e4  call rax
000076049b1da3e6  movaps xmm12, [rsp]
000076049b1da3eb  add rsp, 0x30
000076049b1da3ef  vmovaps xmm0, [rsp]
000076049b1da3f4  vmovaps xmm1, [rsp+0x10]
000076049b1da3fa  vmovaps xmm2, [rsp+0x20]
000076049b1da400  vmovaps xmm3, [rsp+0x30]
000076049b1da406  vmovaps xmm4, [rsp+0x40]
000076049b1da40c  vmovaps xmm5, [rsp+0x50]
000076049b1da412  vmovaps xmm6, [rsp+0x60]
000076049b1da418  vmovaps xmm7, [rsp+0x70]
000076049b1da41e  vmovaps xmm8, [rsp+0x80]
000076049b1da427  vmovaps xmm9, [rsp+0x90]
000076049b1da430  vmovaps xmm10, [rsp+0xA0]
000076049b1da439  vmovaps xmm11, [rsp+0xB0]
000076049b1da442  vmovaps xmm13, [rsp+0xC0]
000076049b1da44b  vmovaps xmm14, [rsp+0xD0]
000076049b1da454  vmovaps xmm15, [rsp+0xE0]
000076049b1da45d  add rsp, 0xF0
000076049b1da464  pop r11
000076049b1da466  pop r10
000076049b1da468  pop r9
000076049b1da46a  pop r8
000076049b1da46c  pop rsi
000076049b1da46d  pop rdi
000076049b1da46e  pop rdx
000076049b1da46f  pop rcx
000076049b1da470  pop rax
000076049b1da471  add rsp, 0x08
000076049b1da475  jmp 0x000076049B1D6441
000076049b1da47a  sub rsp, 0x08
000076049b1da47e  push rax
000076049b1da47f  push rcx
000076049b1da480  push rdx
000076049b1da481  push rdi
000076049b1da482  push rsi
000076049b1da483  push r8
000076049b1da485  push r9
000076049b1da487  push r10
000076049b1da489  push r11
000076049b1da48b  sub rsp, 0xF0
000076049b1da492  vmovaps [rsp], xmm0
000076049b1da497  vmovaps [rsp+0x10], xmm1
000076049b1da49d  vmovaps [rsp+0x20], xmm2
000076049b1da4a3  vmovaps [rsp+0x30], xmm3
000076049b1da4a9  vmovaps [rsp+0x40], xmm4
000076049b1da4af  vmovaps [rsp+0x50], xmm5
000076049b1da4b5  vmovaps [rsp+0x60], xmm6
000076049b1da4bb  vmovaps [rsp+0x70], xmm7
000076049b1da4c1  vmovaps [rsp+0x80], xmm8
000076049b1da4ca  vmovaps [rsp+0x90], xmm9
000076049b1da4d3  vmovaps [rsp+0xA0], xmm10
000076049b1da4dc  vmovaps [rsp+0xB0], xmm11
000076049b1da4e5  vmovaps [rsp+0xC0], xmm12
000076049b1da4ee  vmovaps [rsp+0xD0], xmm14
000076049b1da4f7  vmovaps [rsp+0xE0], xmm15
000076049b1da500  sub rsp, 0x30
000076049b1da504  movaps [rsp], xmm13
000076049b1da509  movaps [rsp+0x10], xmm15
000076049b1da50f  movaps [rsp+0x20], xmm8
000076049b1da515  lea rdi, [rsp]
000076049b1da519  mov esi, 0x00
000076049b1da51e  mov rax, 0x64C06813C530
000076049b1da528  call rax
000076049b1da52a  movaps xmm13, [rsp]
000076049b1da52f  add rsp, 0x30
000076049b1da533  vmovaps xmm0, [rsp]
000076049b1da538  vmovaps xmm1, [rsp+0x10]
000076049b1da53e  vmovaps xmm2, [rsp+0x20]
000076049b1da544  vmovaps xmm3, [rsp+0x30]
000076049b1da54a  vmovaps xmm4, [rsp+0x40]
000076049b1da550  vmovaps xmm5, [rsp+0x50]
000076049b1da556  vmovaps xmm6, [rsp+0x60]
000076049b1da55c  vmovaps xmm7, [rsp+0x70]
000076049b1da562  vmovaps xmm8, [rsp+0x80]
000076049b1da56b  vmovaps xmm9, [rsp+0x90]
000076049b1da574  vmovaps xmm10, [rsp+0xA0]
000076049b1da57d  vmovaps xmm11, [rsp+0xB0]
000076049b1da586  vmovaps xmm12, [rsp+0xC0]
000076049b1da58f  vmovaps xmm14, [rsp+0xD0]
000076049b1da598  vmovaps xmm15, [rsp+0xE0]
000076049b1da5a1  add rsp, 0xF0
000076049b1da5a8  pop r11
000076049b1da5aa  pop r10
000076049b1da5ac  pop r9
000076049b1da5ae  pop r8
000076049b1da5b0  pop rsi
000076049b1da5b1  pop rdi
000076049b1da5b2  pop rdx
000076049b1da5b3  pop rcx
000076049b1da5b4  pop rax
000076049b1da5b5  add rsp, 0x08
000076049b1da5b9  jmp 0x000076049B1D645C
000076049b1da5be  sub rsp, 0x08
000076049b1da5c2  push rax
000076049b1da5c3  push rcx
000076049b1da5c4  push rdx
000076049b1da5c5  push rdi
000076049b1da5c6  push rsi
000076049b1da5c7  push r8
000076049b1da5c9  push r9
000076049b1da5cb  push r10
000076049b1da5cd  push r11
000076049b1da5cf  sub rsp, 0xF0
000076049b1da5d6  vmovaps [rsp], xmm0
000076049b1da5db  vmovaps [rsp+0x10], xmm1
000076049b1da5e1  vmovaps [rsp+0x20], xmm2
000076049b1da5e7  vmovaps [rsp+0x30], xmm3
000076049b1da5ed  vmovaps [rsp+0x40], xmm4
000076049b1da5f3  vmovaps [rsp+0x50], xmm5
000076049b1da5f9  vmovaps [rsp+0x60], xmm6
000076049b1da5ff  vmovaps [rsp+0x70], xmm7
000076049b1da605  vmovaps [rsp+0x80], xmm9
000076049b1da60e  vmovaps [rsp+0x90], xmm10
000076049b1da617  vmovaps [rsp+0xA0], xmm11
000076049b1da620  vmovaps [rsp+0xB0], xmm12
000076049b1da629  vmovaps [rsp+0xC0], xmm13
000076049b1da632  vmovaps [rsp+0xD0], xmm14
000076049b1da63b  vmovaps [rsp+0xE0], xmm15
000076049b1da644  sub rsp, 0x30
000076049b1da648  movaps [rsp], xmm8
000076049b1da64d  movaps [rsp+0x10], xmm15
000076049b1da653  movaps [rsp+0x20], xmm9
000076049b1da659  lea rdi, [rsp]
000076049b1da65d  mov esi, 0x00
000076049b1da662  mov rax, 0x64C06813C530
000076049b1da66c  call rax
000076049b1da66e  movaps xmm8, [rsp]
000076049b1da673  add rsp, 0x30
000076049b1da677  vmovaps xmm0, [rsp]
000076049b1da67c  vmovaps xmm1, [rsp+0x10]
000076049b1da682  vmovaps xmm2, [rsp+0x20]
000076049b1da688  vmovaps xmm3, [rsp+0x30]
000076049b1da68e  vmovaps xmm4, [rsp+0x40]
000076049b1da694  vmovaps xmm5, [rsp+0x50]
000076049b1da69a  vmovaps xmm6, [rsp+0x60]
000076049b1da6a0  vmovaps xmm7, [rsp+0x70]
000076049b1da6a6  vmovaps xmm9, [rsp+0x80]
000076049b1da6af  vmovaps xmm10, [rsp+0x90]
000076049b1da6b8  vmovaps xmm11, [rsp+0xA0]
000076049b1da6c1  vmovaps xmm12, [rsp+0xB0]
000076049b1da6ca  vmovaps xmm13, [rsp+0xC0]
000076049b1da6d3  vmovaps xmm14, [rsp+0xD0]
000076049b1da6dc  vmovaps xmm15, [rsp+0xE0]
000076049b1da6e5  add rsp, 0xF0
000076049b1da6ec  pop r11
000076049b1da6ee  pop r10
000076049b1da6f0  pop r9
000076049b1da6f2  pop r8
000076049b1da6f4  pop rsi
000076049b1da6f5  pop rdi
000076049b1da6f6  pop rdx
000076049b1da6f7  pop rcx
000076049b1da6f8  pop rax
000076049b1da6f9  add rsp, 0x08
000076049b1da6fd  jmp 0x000076049B1D648A
000076049b1da702  sub rsp, 0x08
000076049b1da706  push rax
000076049b1da707  push rcx
000076049b1da708  push rdx
000076049b1da709  push rdi
000076049b1da70a  push rsi
000076049b1da70b  push r8
000076049b1da70d  push r9
000076049b1da70f  push r10
000076049b1da711  push r11
000076049b1da713  sub rsp, 0xF0
000076049b1da71a  vmovaps [rsp], xmm0
000076049b1da71f  vmovaps [rsp+0x10], xmm1
000076049b1da725  vmovaps [rsp+0x20], xmm2
000076049b1da72b  vmovaps [rsp+0x30], xmm3
000076049b1da731  vmovaps [rsp+0x40], xmm4
000076049b1da737  vmovaps [rsp+0x50], xmm5
000076049b1da73d  vmovaps [rsp+0x60], xmm6
000076049b1da743  vmovaps [rsp+0x70], xmm7
000076049b1da749  vmovaps [rsp+0x80], xmm8
000076049b1da752  vmovaps [rsp+0x90], xmm9
000076049b1da75b  vmovaps [rsp+0xA0], xmm10
000076049b1da764  vmovaps [rsp+0xB0], xmm11
000076049b1da76d  vmovaps [rsp+0xC0], xmm12
000076049b1da776  vmovaps [rsp+0xD0], xmm13
000076049b1da77f  vmovaps [rsp+0xE0], xmm14
000076049b1da788  sub rsp, 0x30
000076049b1da78c  movaps [rsp], xmm15
000076049b1da791  movaps [rsp+0x10], xmm11
000076049b1da797  movaps [rsp+0x20], xmm6
000076049b1da79c  lea rdi, [rsp]
000076049b1da7a0  mov esi, 0x00
000076049b1da7a5  mov rax, 0x64C06813C530
000076049b1da7af  call rax
000076049b1da7b1  movaps xmm15, [rsp]
000076049b1da7b6  add rsp, 0x30
000076049b1da7ba  vmovaps xmm0, [rsp]
000076049b1da7bf  vmovaps xmm1, [rsp+0x10]
000076049b1da7c5  vmovaps xmm2, [rsp+0x20]
000076049b1da7cb  vmovaps xmm3, [rsp+0x30]
000076049b1da7d1  vmovaps xmm4, [rsp+0x40]
000076049b1da7d7  vmovaps xmm5, [rsp+0x50]
000076049b1da7dd  vmovaps xmm6, [rsp+0x60]
000076049b1da7e3  vmovaps xmm7, [rsp+0x70]
000076049b1da7e9  vmovaps xmm8, [rsp+0x80]
000076049b1da7f2  vmovaps xmm9, [rsp+0x90]
000076049b1da7fb  vmovaps xmm10, [rsp+0xA0]
000076049b1da804  vmovaps xmm11, [rsp+0xB0]
000076049b1da80d  vmovaps xmm12, [rsp+0xC0]
000076049b1da816  vmovaps xmm13, [rsp+0xD0]
000076049b1da81f  vmovaps xmm14, [rsp+0xE0]
000076049b1da828  add rsp, 0xF0
000076049b1da82f  pop r11
000076049b1da831  pop r10
000076049b1da833  pop r9
000076049b1da835  pop r8
000076049b1da837  pop rsi
000076049b1da838  pop rdi
000076049b1da839  pop rdx
000076049b1da83a  pop rcx
000076049b1da83b  pop rax
000076049b1da83c  add rsp, 0x08
000076049b1da840  jmp 0x000076049B1D64A5
000076049b1da845  sub rsp, 0x08
000076049b1da849  push rax
000076049b1da84a  push rcx
000076049b1da84b  push rdx
000076049b1da84c  push rdi
000076049b1da84d  push rsi
000076049b1da84e  push r8
000076049b1da850  push r9
000076049b1da852  push r10
000076049b1da854  push r11
000076049b1da856  sub rsp, 0xF0
000076049b1da85d  vmovaps [rsp], xmm0
000076049b1da862  vmovaps [rsp+0x10], xmm1
000076049b1da868  vmovaps [rsp+0x20], xmm2
000076049b1da86e  vmovaps [rsp+0x30], xmm3
000076049b1da874  vmovaps [rsp+0x40], xmm4
000076049b1da87a  vmovaps [rsp+0x50], xmm5
000076049b1da880  vmovaps [rsp+0x60], xmm6
000076049b1da886  vmovaps [rsp+0x70], xmm8
000076049b1da88c  vmovaps [rsp+0x80], xmm9
000076049b1da895  vmovaps [rsp+0x90], xmm10
000076049b1da89e  vmovaps [rsp+0xA0], xmm11
000076049b1da8a7  vmovaps [rsp+0xB0], xmm12
000076049b1da8b0  vmovaps [rsp+0xC0], xmm13
000076049b1da8b9  vmovaps [rsp+0xD0], xmm14
000076049b1da8c2  vmovaps [rsp+0xE0], xmm15
000076049b1da8cb  sub rsp, 0x30
000076049b1da8cf  movaps [rsp], xmm7
000076049b1da8d3  movaps [rsp+0x10], xmm11
000076049b1da8d9  movaps [rsp+0x20], xmm9
000076049b1da8df  lea rdi, [rsp]
000076049b1da8e3  mov esi, 0x00
000076049b1da8e8  mov rax, 0x64C06813C530
000076049b1da8f2  call rax
000076049b1da8f4  movaps xmm7, [rsp]
000076049b1da8f8  add rsp, 0x30
000076049b1da8fc  vmovaps xmm0, [rsp]
000076049b1da901  vmovaps xmm1, [rsp+0x10]
000076049b1da907  vmovaps xmm2, [rsp+0x20]
000076049b1da90d  vmovaps xmm3, [rsp+0x30]
000076049b1da913  vmovaps xmm4, [rsp+0x40]
000076049b1da919  vmovaps xmm5, [rsp+0x50]
000076049b1da91f  vmovaps xmm6, [rsp+0x60]
000076049b1da925  vmovaps xmm8, [rsp+0x70]
000076049b1da92b  vmovaps xmm9, [rsp+0x80]
000076049b1da934  vmovaps xmm10, [rsp+0x90]
000076049b1da93d  vmovaps xmm11, [rsp+0xA0]
000076049b1da946  vmovaps xmm12, [rsp+0xB0]
000076049b1da94f  vmovaps xmm13, [rsp+0xC0]
000076049b1da958  vmovaps xmm14, [rsp+0xD0]
000076049b1da961  vmovaps xmm15, [rsp+0xE0]
000076049b1da96a  add rsp, 0xF0
000076049b1da971  pop r11
000076049b1da973  pop r10
000076049b1da975  pop r9
000076049b1da977  pop r8
000076049b1da979  pop rsi
000076049b1da97a  pop rdi
000076049b1da97b  pop rdx
000076049b1da97c  pop rcx
000076049b1da97d  pop rax
000076049b1da97e  add rsp, 0x08
000076049b1da982  jmp 0x000076049B1D64D2
000076049b1da987  sub rsp, 0x08
000076049b1da98b  push rax
000076049b1da98c  push rcx
000076049b1da98d  push rdx
000076049b1da98e  push rdi
000076049b1da98f  push rsi
000076049b1da990  push r8
000076049b1da992  push r9
000076049b1da994  push r10
000076049b1da996  push r11
000076049b1da998  sub rsp, 0xF0
000076049b1da99f  vmovaps [rsp], xmm0
000076049b1da9a4  vmovaps [rsp+0x10], xmm1
000076049b1da9aa  vmovaps [rsp+0x20], xmm2
000076049b1da9b0  vmovaps [rsp+0x30], xmm3
000076049b1da9b6  vmovaps [rsp+0x40], xmm4
000076049b1da9bc  vmovaps [rsp+0x50], xmm5
000076049b1da9c2  vmovaps [rsp+0x60], xmm6
000076049b1da9c8  vmovaps [rsp+0x70], xmm7
000076049b1da9ce  vmovaps [rsp+0x80], xmm8
000076049b1da9d7  vmovaps [rsp+0x90], xmm9
000076049b1da9e0  vmovaps [rsp+0xA0], xmm10
000076049b1da9e9  vmovaps [rsp+0xB0], xmm12
000076049b1da9f2  vmovaps [rsp+0xC0], xmm13
000076049b1da9fb  vmovaps [rsp+0xD0], xmm14
000076049b1daa04  vmovaps [rsp+0xE0], xmm15
000076049b1daa0d  sub rsp, 0x30
000076049b1daa11  movaps [rsp], xmm11
000076049b1daa16  movaps [rsp+0x10], xmm10
000076049b1daa1c  movaps [rsp+0x20], xmm14
000076049b1daa22  lea rdi, [rsp]
000076049b1daa26  mov esi, 0x00
000076049b1daa2b  mov rax, 0x64C06813C530
000076049b1daa35  call rax
000076049b1daa37  movaps xmm11, [rsp]
000076049b1daa3c  add rsp, 0x30
000076049b1daa40  vmovaps xmm0, [rsp]
000076049b1daa45  vmovaps xmm1, [rsp+0x10]
000076049b1daa4b  vmovaps xmm2, [rsp+0x20]
000076049b1daa51  vmovaps xmm3, [rsp+0x30]
000076049b1daa57  vmovaps xmm4, [rsp+0x40]
000076049b1daa5d  vmovaps xmm5, [rsp+0x50]
000076049b1daa63  vmovaps xmm6, [rsp+0x60]
000076049b1daa69  vmovaps xmm7, [rsp+0x70]
000076049b1daa6f  vmovaps xmm8, [rsp+0x80]
000076049b1daa78  vmovaps xmm9, [rsp+0x90]
000076049b1daa81  vmovaps xmm10, [rsp+0xA0]
000076049b1daa8a  vmovaps xmm12, [rsp+0xB0]
000076049b1daa93  vmovaps xmm13, [rsp+0xC0]
000076049b1daa9c  vmovaps xmm14, [rsp+0xD0]
000076049b1daaa5  vmovaps xmm15, [rsp+0xE0]
000076049b1daaae  add rsp, 0xF0
000076049b1daab5  pop r11
000076049b1daab7  pop r10
000076049b1daab9  pop r9
000076049b1daabb  pop r8
000076049b1daabd  pop rsi
000076049b1daabe  pop rdi
000076049b1daabf  pop rdx
000076049b1daac0  pop rcx
000076049b1daac1  pop rax
000076049b1daac2  add rsp, 0x08
000076049b1daac6  jmp 0x000076049B1D64ED
000076049b1daacb  call 0x000076049B0E45A0
000076049b1daad0  jmp 0x000076049B1D64F7
000076049b1daad5  sub rsp, 0x08
000076049b1daad9  push rax
000076049b1daada  push rcx
000076049b1daadb  push rdx
000076049b1daadc  push rdi
000076049b1daadd  push rsi
000076049b1daade  push r8
000076049b1daae0  push r9
000076049b1daae2  push r10
000076049b1daae4  push r11
000076049b1daae6  sub rsp, 0xF0
000076049b1daaed  vmovaps [rsp], xmm0
000076049b1daaf2  vmovaps [rsp+0x10], xmm1
000076049b1daaf8  vmovaps [rsp+0x20], xmm2
000076049b1daafe  vmovaps [rsp+0x30], xmm3
000076049b1dab04  vmovaps [rsp+0x40], xmm4
000076049b1dab0a  vmovaps [rsp+0x50], xmm5
000076049b1dab10  vmovaps [rsp+0x60], xmm6
000076049b1dab16  vmovaps [rsp+0x70], xmm7
000076049b1dab1c  vmovaps [rsp+0x80], xmm8
000076049b1dab25  vmovaps [rsp+0x90], xmm9
000076049b1dab2e  vmovaps [rsp+0xA0], xmm11
000076049b1dab37  vmovaps [rsp+0xB0], xmm12
000076049b1dab40  vmovaps [rsp+0xC0], xmm13
000076049b1dab49  vmovaps [rsp+0xD0], xmm14
000076049b1dab52  vmovaps [rsp+0xE0], xmm15
000076049b1dab5b  sub rsp, 0x30
000076049b1dab5f  movaps [rsp], xmm10
000076049b1dab64  movaps [rsp+0x10], xmm1
000076049b1dab69  movaps [rsp+0x20], xmm12
000076049b1dab6f  lea rdi, [rsp]
000076049b1dab73  mov esi, 0x00
000076049b1dab78  mov rax, 0x64C06813C530
000076049b1dab82  call rax
000076049b1dab84  movaps xmm10, [rsp]
000076049b1dab89  add rsp, 0x30
000076049b1dab8d  vmovaps xmm0, [rsp]
000076049b1dab92  vmovaps xmm1, [rsp+0x10]
000076049b1dab98  vmovaps xmm2, [rsp+0x20]
000076049b1dab9e  vmovaps xmm3, [rsp+0x30]
000076049b1daba4  vmovaps xmm4, [rsp+0x40]
000076049b1dabaa  vmovaps xmm5, [rsp+0x50]
000076049b1dabb0  vmovaps xmm6, [rsp+0x60]
000076049b1dabb6  vmovaps xmm7, [rsp+0x70]
000076049b1dabbc  vmovaps xmm8, [rsp+0x80]
000076049b1dabc5  vmovaps xmm9, [rsp+0x90]
000076049b1dabce  vmovaps xmm11, [rsp+0xA0]
000076049b1dabd7  vmovaps xmm12, [rsp+0xB0]
000076049b1dabe0  vmovaps xmm13, [rsp+0xC0]
000076049b1dabe9  vmovaps xmm14, [rsp+0xD0]
000076049b1dabf2  vmovaps xmm15, [rsp+0xE0]
000076049b1dabfb  add rsp, 0xF0
000076049b1dac02  pop r11
000076049b1dac04  pop r10
000076049b1dac06  pop r9
000076049b1dac08  pop r8
000076049b1dac0a  pop rsi
000076049b1dac0b  pop rdi
000076049b1dac0c  pop rdx
000076049b1dac0d  pop rcx
000076049b1dac0e  pop rax
000076049b1dac0f  add rsp, 0x08
000076049b1dac13  jmp 0x000076049B1D651A
000076049b1dac18  sub rsp, 0x08
000076049b1dac1c  push rax
000076049b1dac1d  push rcx
000076049b1dac1e  push rdx
000076049b1dac1f  push rdi
000076049b1dac20  push rsi
000076049b1dac21  push r8
000076049b1dac23  push r9
000076049b1dac25  push r10
000076049b1dac27  push r11
000076049b1dac29  sub rsp, 0xF0
000076049b1dac30  vmovaps [rsp], xmm0
000076049b1dac35  vmovaps [rsp+0x10], xmm1
000076049b1dac3b  vmovaps [rsp+0x20], xmm2
000076049b1dac41  vmovaps [rsp+0x30], xmm3
000076049b1dac47  vmovaps [rsp+0x40], xmm4
000076049b1dac4d  vmovaps [rsp+0x50], xmm5
000076049b1dac53  vmovaps [rsp+0x60], xmm6
000076049b1dac59  vmovaps [rsp+0x70], xmm7
000076049b1dac5f  vmovaps [rsp+0x80], xmm8
000076049b1dac68  vmovaps [rsp+0x90], xmm9
000076049b1dac71  vmovaps [rsp+0xA0], xmm10
000076049b1dac7a  vmovaps [rsp+0xB0], xmm11
000076049b1dac83  vmovaps [rsp+0xC0], xmm13
000076049b1dac8c  vmovaps [rsp+0xD0], xmm14
000076049b1dac95  vmovaps [rsp+0xE0], xmm15
000076049b1dac9e  sub rsp, 0x30
000076049b1daca2  movaps [rsp], xmm12
000076049b1daca7  movaps [rsp+0x10], xmm14
000076049b1dacad  movaps [rsp+0x20], xmm1
000076049b1dacb2  lea rdi, [rsp]
000076049b1dacb6  mov esi, 0x00
000076049b1dacbb  mov rax, 0x64C06813C530
000076049b1dacc5  call rax
000076049b1dacc7  movaps xmm12, [rsp]
000076049b1daccc  add rsp, 0x30
000076049b1dacd0  vmovaps xmm0, [rsp]
000076049b1dacd5  vmovaps xmm1, [rsp+0x10]
000076049b1dacdb  vmovaps xmm2, [rsp+0x20]
000076049b1dace1  vmovaps xmm3, [rsp+0x30]
000076049b1dace7  vmovaps xmm4, [rsp+0x40]
000076049b1daced  vmovaps xmm5, [rsp+0x50]
000076049b1dacf3  vmovaps xmm6, [rsp+0x60]
000076049b1dacf9  vmovaps xmm7, [rsp+0x70]
000076049b1dacff  vmovaps xmm8, [rsp+0x80]
000076049b1dad08  vmovaps xmm9, [rsp+0x90]
000076049b1dad11  vmovaps xmm10, [rsp+0xA0]
000076049b1dad1a  vmovaps xmm11, [rsp+0xB0]
000076049b1dad23  vmovaps xmm13, [rsp+0xC0]
000076049b1dad2c  vmovaps xmm14, [rsp+0xD0]
000076049b1dad35  vmovaps xmm15, [rsp+0xE0]
000076049b1dad3e  add rsp, 0xF0
000076049b1dad45  pop r11
000076049b1dad47  pop r10
000076049b1dad49  pop r9
000076049b1dad4b  pop r8
000076049b1dad4d  pop rsi
000076049b1dad4e  pop rdi
000076049b1dad4f  pop rdx
000076049b1dad50  pop rcx
000076049b1dad51  pop rax
000076049b1dad52  add rsp, 0x08
000076049b1dad56  jmp 0x000076049B1D6549
000076049b1dad5b  sub rsp, 0x08
000076049b1dad5f  push rax
000076049b1dad60  push rcx
000076049b1dad61  push rdx
000076049b1dad62  push rdi
000076049b1dad63  push rsi
000076049b1dad64  push r8
000076049b1dad66  push r9
000076049b1dad68  push r10
000076049b1dad6a  push r11
000076049b1dad6c  sub rsp, 0xF0
000076049b1dad73  vmovaps [rsp], xmm0
000076049b1dad78  vmovaps [rsp+0x10], xmm1
000076049b1dad7e  vmovaps [rsp+0x20], xmm2
000076049b1dad84  vmovaps [rsp+0x30], xmm3
000076049b1dad8a  vmovaps [rsp+0x40], xmm4
000076049b1dad90  vmovaps [rsp+0x50], xmm5
000076049b1dad96  vmovaps [rsp+0x60], xmm6
000076049b1dad9c  vmovaps [rsp+0x70], xmm7
000076049b1dada2  vmovaps [rsp+0x80], xmm8
000076049b1dadab  vmovaps [rsp+0x90], xmm9
000076049b1dadb4  vmovaps [rsp+0xA0], xmm10
000076049b1dadbd  vmovaps [rsp+0xB0], xmm11
000076049b1dadc6  vmovaps [rsp+0xC0], xmm12
000076049b1dadcf  vmovaps [rsp+0xD0], xmm13
000076049b1dadd8  vmovaps [rsp+0xE0], xmm15
000076049b1dade1  sub rsp, 0x30
000076049b1dade5  movaps [rsp], xmm14
000076049b1dadea  movaps [rsp+0x10], xmm9
000076049b1dadf0  movaps [rsp+0x20], xmm1
000076049b1dadf5  lea rdi, [rsp]
000076049b1dadf9  mov esi, 0x00
000076049b1dadfe  mov rax, 0x64C06813C530
000076049b1dae08  call rax
000076049b1dae0a  movaps xmm14, [rsp]
000076049b1dae0f  add rsp, 0x30
000076049b1dae13  vmovaps xmm0, [rsp]
000076049b1dae18  vmovaps xmm1, [rsp+0x10]
000076049b1dae1e  vmovaps xmm2, [rsp+0x20]
000076049b1dae24  vmovaps xmm3, [rsp+0x30]
000076049b1dae2a  vmovaps xmm4, [rsp+0x40]
000076049b1dae30  vmovaps xmm5, [rsp+0x50]
000076049b1dae36  vmovaps xmm6, [rsp+0x60]
000076049b1dae3c  vmovaps xmm7, [rsp+0x70]
000076049b1dae42  vmovaps xmm8, [rsp+0x80]
000076049b1dae4b  vmovaps xmm9, [rsp+0x90]
000076049b1dae54  vmovaps xmm10, [rsp+0xA0]
000076049b1dae5d  vmovaps xmm11, [rsp+0xB0]
000076049b1dae66  vmovaps xmm12, [rsp+0xC0]
000076049b1dae6f  vmovaps xmm13, [rsp+0xD0]
000076049b1dae78  vmovaps xmm15, [rsp+0xE0]
000076049b1dae81  add rsp, 0xF0
000076049b1dae88  pop r11
000076049b1dae8a  pop r10
000076049b1dae8c  pop r9
000076049b1dae8e  pop r8
000076049b1dae90  pop rsi
000076049b1dae91  pop rdi
000076049b1dae92  pop rdx
000076049b1dae93  pop rcx
000076049b1dae94  pop rax
000076049b1dae95  add rsp, 0x08
000076049b1dae99  jmp 0x000076049B1D6578
000076049b1dae9e  sub rsp, 0x08
000076049b1daea2  push rax
000076049b1daea3  push rcx
000076049b1daea4  push rdx
000076049b1daea5  push rdi
000076049b1daea6  push rsi
000076049b1daea7  push r8
000076049b1daea9  push r9
000076049b1daeab  push r10
000076049b1daead  push r11
000076049b1daeaf  sub rsp, 0xF0
000076049b1daeb6  vmovaps [rsp], xmm0
000076049b1daebb  vmovaps [rsp+0x10], xmm2
000076049b1daec1  vmovaps [rsp+0x20], xmm3
000076049b1daec7  vmovaps [rsp+0x30], xmm4
000076049b1daecd  vmovaps [rsp+0x40], xmm5
000076049b1daed3  vmovaps [rsp+0x50], xmm6
000076049b1daed9  vmovaps [rsp+0x60], xmm7
000076049b1daedf  vmovaps [rsp+0x70], xmm8
000076049b1daee5  vmovaps [rsp+0x80], xmm9
000076049b1daeee  vmovaps [rsp+0x90], xmm10
000076049b1daef7  vmovaps [rsp+0xA0], xmm11
000076049b1daf00  vmovaps [rsp+0xB0], xmm12
000076049b1daf09  vmovaps [rsp+0xC0], xmm13
000076049b1daf12  vmovaps [rsp+0xD0], xmm14
000076049b1daf1b  vmovaps [rsp+0xE0], xmm15
000076049b1daf24  sub rsp, 0x30
000076049b1daf28  movaps [rsp], xmm1
000076049b1daf2c  movaps [rsp+0x10], xmm13
000076049b1daf32  movaps [rsp+0x20], xmm8
000076049b1daf38  lea rdi, [rsp]
000076049b1daf3c  mov esi, 0x00
000076049b1daf41  mov rax, 0x64C06813C530
000076049b1daf4b  call rax
000076049b1daf4d  movaps xmm1, [rsp]
000076049b1daf51  add rsp, 0x30
000076049b1daf55  vmovaps xmm0, [rsp]
000076049b1daf5a  vmovaps xmm2, [rsp+0x10]
000076049b1daf60  vmovaps xmm3, [rsp+0x20]
000076049b1daf66  vmovaps xmm4, [rsp+0x30]
000076049b1daf6c  vmovaps xmm5, [rsp+0x40]
000076049b1daf72  vmovaps xmm6, [rsp+0x50]
000076049b1daf78  vmovaps xmm7, [rsp+0x60]
000076049b1daf7e  vmovaps xmm8, [rsp+0x70]
000076049b1daf84  vmovaps xmm9, [rsp+0x80]
000076049b1daf8d  vmovaps xmm10, [rsp+0x90]
000076049b1daf96  vmovaps xmm11, [rsp+0xA0]
000076049b1daf9f  vmovaps xmm12, [rsp+0xB0]
000076049b1dafa8  vmovaps xmm13, [rsp+0xC0]
000076049b1dafb1  vmovaps xmm14, [rsp+0xD0]
000076049b1dafba  vmovaps xmm15, [rsp+0xE0]
000076049b1dafc3  add rsp, 0xF0
000076049b1dafca  pop r11
000076049b1dafcc  pop r10
000076049b1dafce  pop r9
000076049b1dafd0  pop r8
000076049b1dafd2  pop rsi
000076049b1dafd3  pop rdi
000076049b1dafd4  pop rdx
000076049b1dafd5  pop rcx
000076049b1dafd6  pop rax
000076049b1dafd7  add rsp, 0x08
000076049b1dafdb  jmp 0x000076049B1D659A
000076049b1dafe0  call 0x000076049B00C260
000076049b1dafe5  jmp 0x000076049B1D65A8
000076049b1dafea  call 0x000076049B0DE950
000076049b1dafef  jmp 0x000076049B1D65B2
000076049b1daff4  sub rsp, 0x08
000076049b1daff8  push rax
000076049b1daff9  push rcx
000076049b1daffa  push rdx
000076049b1daffb  push rdi
000076049b1daffc  push rsi
000076049b1daffd  push r8
000076049b1dafff  push r9
000076049b1db001  push r10
000076049b1db003  push r11
000076049b1db005  sub rsp, 0xF0
000076049b1db00c  vmovaps [rsp], xmm0
000076049b1db011  vmovaps [rsp+0x10], xmm1
000076049b1db017  vmovaps [rsp+0x20], xmm2
000076049b1db01d  vmovaps [rsp+0x30], xmm3
000076049b1db023  vmovaps [rsp+0x40], xmm4
000076049b1db029  vmovaps [rsp+0x50], xmm5
000076049b1db02f  vmovaps [rsp+0x60], xmm6
000076049b1db035  vmovaps [rsp+0x70], xmm7
000076049b1db03b  vmovaps [rsp+0x80], xmm9
000076049b1db044  vmovaps [rsp+0x90], xmm10
000076049b1db04d  vmovaps [rsp+0xA0], xmm11
000076049b1db056  vmovaps [rsp+0xB0], xmm12
000076049b1db05f  vmovaps [rsp+0xC0], xmm13
000076049b1db068  vmovaps [rsp+0xD0], xmm14
000076049b1db071  vmovaps [rsp+0xE0], xmm15
000076049b1db07a  sub rsp, 0x30
000076049b1db07e  movaps [rsp], xmm8
000076049b1db083  movaps [rsp+0x10], xmm15
000076049b1db089  movaps [rsp+0x20], xmm7
000076049b1db08e  lea rdi, [rsp]
000076049b1db092  mov esi, 0x00
000076049b1db097  mov rax, 0x64C06813C530
000076049b1db0a1  call rax
000076049b1db0a3  movaps xmm8, [rsp]
000076049b1db0a8  add rsp, 0x30
000076049b1db0ac  vmovaps xmm0, [rsp]
000076049b1db0b1  vmovaps xmm1, [rsp+0x10]
000076049b1db0b7  vmovaps xmm2, [rsp+0x20]
000076049b1db0bd  vmovaps xmm3, [rsp+0x30]
000076049b1db0c3  vmovaps xmm4, [rsp+0x40]
000076049b1db0c9  vmovaps xmm5, [rsp+0x50]
000076049b1db0cf  vmovaps xmm6, [rsp+0x60]
000076049b1db0d5  vmovaps xmm7, [rsp+0x70]
000076049b1db0db  vmovaps xmm9, [rsp+0x80]
000076049b1db0e4  vmovaps xmm10, [rsp+0x90]
000076049b1db0ed  vmovaps xmm11, [rsp+0xA0]
000076049b1db0f6  vmovaps xmm12, [rsp+0xB0]
000076049b1db0ff  vmovaps xmm13, [rsp+0xC0]
000076049b1db108  vmovaps xmm14, [rsp+0xD0]
000076049b1db111  vmovaps xmm15, [rsp+0xE0]
000076049b1db11a  add rsp, 0xF0
000076049b1db121  pop r11
000076049b1db123  pop r10
000076049b1db125  pop r9
000076049b1db127  pop r8
000076049b1db129  pop rsi
000076049b1db12a  pop rdi
000076049b1db12b  pop rdx
000076049b1db12c  pop rcx
000076049b1db12d  pop rax
000076049b1db12e  add rsp, 0x08
000076049b1db132  jmp 0x000076049B1D65D4
000076049b1db137  sub rsp, 0x08
000076049b1db13b  push rax
000076049b1db13c  push rcx
000076049b1db13d  push rdx
000076049b1db13e  push rdi
000076049b1db13f  push rsi
000076049b1db140  push r8
000076049b1db142  push r9
000076049b1db144  push r10
000076049b1db146  push r11
000076049b1db148  sub rsp, 0xF0
000076049b1db14f  vmovaps [rsp], xmm0
000076049b1db154  vmovaps [rsp+0x10], xmm1
000076049b1db15a  vmovaps [rsp+0x20], xmm2
000076049b1db160  vmovaps [rsp+0x30], xmm3
000076049b1db166  vmovaps [rsp+0x40], xmm4
000076049b1db16c  vmovaps [rsp+0x50], xmm5
000076049b1db172  vmovaps [rsp+0x60], xmm6
000076049b1db178  vmovaps [rsp+0x70], xmm8
000076049b1db17e  vmovaps [rsp+0x80], xmm9
000076049b1db187  vmovaps [rsp+0x90], xmm10
000076049b1db190  vmovaps [rsp+0xA0], xmm11
000076049b1db199  vmovaps [rsp+0xB0], xmm12
000076049b1db1a2  vmovaps [rsp+0xC0], xmm13
000076049b1db1ab  vmovaps [rsp+0xD0], xmm14
000076049b1db1b4  vmovaps [rsp+0xE0], xmm15
000076049b1db1bd  sub rsp, 0x30
000076049b1db1c1  movaps [rsp], xmm7
000076049b1db1c5  movaps [rsp+0x10], xmm9
000076049b1db1cb  movaps [rsp+0x20], xmm15
000076049b1db1d1  lea rdi, [rsp]
000076049b1db1d5  mov esi, 0x00
000076049b1db1da  mov rax, 0x64C06813C530
000076049b1db1e4  call rax
000076049b1db1e6  movaps xmm7, [rsp]
000076049b1db1ea  add rsp, 0x30
000076049b1db1ee  vmovaps xmm0, [rsp]
000076049b1db1f3  vmovaps xmm1, [rsp+0x10]
000076049b1db1f9  vmovaps xmm2, [rsp+0x20]
000076049b1db1ff  vmovaps xmm3, [rsp+0x30]
000076049b1db205  vmovaps xmm4, [rsp+0x40]
000076049b1db20b  vmovaps xmm5, [rsp+0x50]
000076049b1db211  vmovaps xmm6, [rsp+0x60]
000076049b1db217  vmovaps xmm8, [rsp+0x70]
000076049b1db21d  vmovaps xmm9, [rsp+0x80]
000076049b1db226  vmovaps xmm10, [rsp+0x90]
000076049b1db22f  vmovaps xmm11, [rsp+0xA0]
000076049b1db238  vmovaps xmm12, [rsp+0xB0]
000076049b1db241  vmovaps xmm13, [rsp+0xC0]
000076049b1db24a  vmovaps xmm14, [rsp+0xD0]
000076049b1db253  vmovaps xmm15, [rsp+0xE0]
000076049b1db25c  add rsp, 0xF0
000076049b1db263  pop r11
000076049b1db265  pop r10
000076049b1db267  pop r9
000076049b1db269  pop r8
000076049b1db26b  pop rsi
000076049b1db26c  pop rdi
000076049b1db26d  pop rdx
000076049b1db26e  pop rcx
000076049b1db26f  pop rax
000076049b1db270  add rsp, 0x08
000076049b1db274  jmp 0x000076049B1D6601
000076049b1db279  sub rsp, 0x08
000076049b1db27d  push rax
000076049b1db27e  push rcx
000076049b1db27f  push rdx
000076049b1db280  push rdi
000076049b1db281  push rsi
000076049b1db282  push r8
000076049b1db284  push r9
000076049b1db286  push r10
000076049b1db288  push r11
000076049b1db28a  sub rsp, 0xF0
000076049b1db291  vmovaps [rsp], xmm0
000076049b1db296  vmovaps [rsp+0x10], xmm1
000076049b1db29c  vmovaps [rsp+0x20], xmm2
000076049b1db2a2  vmovaps [rsp+0x30], xmm3
000076049b1db2a8  vmovaps [rsp+0x40], xmm4
000076049b1db2ae  vmovaps [rsp+0x50], xmm5
000076049b1db2b4  vmovaps [rsp+0x60], xmm6
000076049b1db2ba  vmovaps [rsp+0x70], xmm7
000076049b1db2c0  vmovaps [rsp+0x80], xmm8
000076049b1db2c9  vmovaps [rsp+0x90], xmm10
000076049b1db2d2  vmovaps [rsp+0xA0], xmm11
000076049b1db2db  vmovaps [rsp+0xB0], xmm12
000076049b1db2e4  vmovaps [rsp+0xC0], xmm13
000076049b1db2ed  vmovaps [rsp+0xD0], xmm14
000076049b1db2f6  vmovaps [rsp+0xE0], xmm15
000076049b1db2ff  sub rsp, 0x30
000076049b1db303  movaps [rsp], xmm9
000076049b1db308  movaps [rsp+0x10], xmm13
000076049b1db30e  movaps [rsp+0x20], xmm15
000076049b1db314  lea rdi, [rsp]
000076049b1db318  mov esi, 0x00
000076049b1db31d  mov rax, 0x64C06813C530
000076049b1db327  call rax
000076049b1db329  movaps xmm9, [rsp]
000076049b1db32e  add rsp, 0x30
000076049b1db332  vmovaps xmm0, [rsp]
000076049b1db337  vmovaps xmm1, [rsp+0x10]
000076049b1db33d  vmovaps xmm2, [rsp+0x20]
000076049b1db343  vmovaps xmm3, [rsp+0x30]
000076049b1db349  vmovaps xmm4, [rsp+0x40]
000076049b1db34f  vmovaps xmm5, [rsp+0x50]
000076049b1db355  vmovaps xmm6, [rsp+0x60]
000076049b1db35b  vmovaps xmm7, [rsp+0x70]
000076049b1db361  vmovaps xmm8, [rsp+0x80]
000076049b1db36a  vmovaps xmm10, [rsp+0x90]
000076049b1db373  vmovaps xmm11, [rsp+0xA0]
000076049b1db37c  vmovaps xmm12, [rsp+0xB0]
000076049b1db385  vmovaps xmm13, [rsp+0xC0]
000076049b1db38e  vmovaps xmm14, [rsp+0xD0]
000076049b1db397  vmovaps xmm15, [rsp+0xE0]
000076049b1db3a0  add rsp, 0xF0
000076049b1db3a7  pop r11
000076049b1db3a9  pop r10
000076049b1db3ab  pop r9
000076049b1db3ad  pop r8
000076049b1db3af  pop rsi
000076049b1db3b0  pop rdi
000076049b1db3b1  pop rdx
000076049b1db3b2  pop rcx
000076049b1db3b3  pop rax
000076049b1db3b4  add rsp, 0x08
000076049b1db3b8  jmp 0x000076049B1D662F
000076049b1db3bd  sub rsp, 0x08
000076049b1db3c1  push rax
000076049b1db3c2  push rcx
000076049b1db3c3  push rdx
000076049b1db3c4  push rdi
000076049b1db3c5  push rsi
000076049b1db3c6  push r8
000076049b1db3c8  push r9
000076049b1db3ca  push r10
000076049b1db3cc  push r11
000076049b1db3ce  sub rsp, 0xF0
000076049b1db3d5  vmovaps [rsp], xmm0
000076049b1db3da  vmovaps [rsp+0x10], xmm1
000076049b1db3e0  vmovaps [rsp+0x20], xmm2
000076049b1db3e6  vmovaps [rsp+0x30], xmm3
000076049b1db3ec  vmovaps [rsp+0x40], xmm4
000076049b1db3f2  vmovaps [rsp+0x50], xmm5
000076049b1db3f8  vmovaps [rsp+0x60], xmm6
000076049b1db3fe  vmovaps [rsp+0x70], xmm7
000076049b1db404  vmovaps [rsp+0x80], xmm8
000076049b1db40d  vmovaps [rsp+0x90], xmm9
000076049b1db416  vmovaps [rsp+0xA0], xmm10
000076049b1db41f  vmovaps [rsp+0xB0], xmm11
000076049b1db428  vmovaps [rsp+0xC0], xmm12
000076049b1db431  vmovaps [rsp+0xD0], xmm13
000076049b1db43a  vmovaps [rsp+0xE0], xmm14
000076049b1db443  sub rsp, 0x30
000076049b1db447  movaps [rsp], xmm15
000076049b1db44c  movaps [rsp+0x10], xmm11
000076049b1db452  movaps [rsp+0x20], xmm12
000076049b1db458  lea rdi, [rsp]
000076049b1db45c  mov esi, 0x00
000076049b1db461  mov rax, 0x64C06813C530
000076049b1db46b  call rax
000076049b1db46d  movaps xmm15, [rsp]
000076049b1db472  add rsp, 0x30
000076049b1db476  vmovaps xmm0, [rsp]
000076049b1db47b  vmovaps xmm1, [rsp+0x10]
000076049b1db481  vmovaps xmm2, [rsp+0x20]
000076049b1db487  vmovaps xmm3, [rsp+0x30]
000076049b1db48d  vmovaps xmm4, [rsp+0x40]
000076049b1db493  vmovaps xmm5, [rsp+0x50]
000076049b1db499  vmovaps xmm6, [rsp+0x60]
000076049b1db49f  vmovaps xmm7, [rsp+0x70]
000076049b1db4a5  vmovaps xmm8, [rsp+0x80]
000076049b1db4ae  vmovaps xmm9, [rsp+0x90]
000076049b1db4b7  vmovaps xmm10, [rsp+0xA0]
000076049b1db4c0  vmovaps xmm11, [rsp+0xB0]
000076049b1db4c9  vmovaps xmm12, [rsp+0xC0]
000076049b1db4d2  vmovaps xmm13, [rsp+0xD0]
000076049b1db4db  vmovaps xmm14, [rsp+0xE0]
000076049b1db4e4  add rsp, 0xF0
000076049b1db4eb  pop r11
000076049b1db4ed  pop r10
000076049b1db4ef  pop r9
000076049b1db4f1  pop r8
000076049b1db4f3  pop rsi
000076049b1db4f4  pop rdi
000076049b1db4f5  pop rdx
000076049b1db4f6  pop rcx
000076049b1db4f7  pop rax
000076049b1db4f8  add rsp, 0x08
000076049b1db4fc  jmp 0x000076049B1D664A
000076049b1db501  sub rsp, 0x08
000076049b1db505  push rax
000076049b1db506  push rcx
000076049b1db507  push rdx
000076049b1db508  push rdi
000076049b1db509  push rsi
000076049b1db50a  push r8
000076049b1db50c  push r9
000076049b1db50e  push r10
000076049b1db510  push r11
000076049b1db512  sub rsp, 0xF0
000076049b1db519  vmovaps [rsp], xmm0
000076049b1db51e  vmovaps [rsp+0x10], xmm1
000076049b1db524  vmovaps [rsp+0x20], xmm2
000076049b1db52a  vmovaps [rsp+0x30], xmm3
000076049b1db530  vmovaps [rsp+0x40], xmm4
000076049b1db536  vmovaps [rsp+0x50], xmm5
000076049b1db53c  vmovaps [rsp+0x60], xmm6
000076049b1db542  vmovaps [rsp+0x70], xmm7
000076049b1db548  vmovaps [rsp+0x80], xmm8
000076049b1db551  vmovaps [rsp+0x90], xmm9
000076049b1db55a  vmovaps [rsp+0xA0], xmm10
000076049b1db563  vmovaps [rsp+0xB0], xmm11
000076049b1db56c  vmovaps [rsp+0xC0], xmm12
000076049b1db575  vmovaps [rsp+0xD0], xmm14
000076049b1db57e  vmovaps [rsp+0xE0], xmm15
000076049b1db587  sub rsp, 0x30
000076049b1db58b  movaps [rsp], xmm13
000076049b1db590  movaps [rsp+0x10], xmm10
000076049b1db596  movaps [rsp+0x20], xmm14
000076049b1db59c  lea rdi, [rsp]
000076049b1db5a0  mov esi, 0x00
000076049b1db5a5  mov rax, 0x64C06813C530
000076049b1db5af  call rax
000076049b1db5b1  movaps xmm13, [rsp]
000076049b1db5b6  add rsp, 0x30
000076049b1db5ba  vmovaps xmm0, [rsp]
000076049b1db5bf  vmovaps xmm1, [rsp+0x10]
000076049b1db5c5  vmovaps xmm2, [rsp+0x20]
000076049b1db5cb  vmovaps xmm3, [rsp+0x30]
000076049b1db5d1  vmovaps xmm4, [rsp+0x40]
000076049b1db5d7  vmovaps xmm5, [rsp+0x50]
000076049b1db5dd  vmovaps xmm6, [rsp+0x60]
000076049b1db5e3  vmovaps xmm7, [rsp+0x70]
000076049b1db5e9  vmovaps xmm8, [rsp+0x80]
000076049b1db5f2  vmovaps xmm9, [rsp+0x90]
000076049b1db5fb  vmovaps xmm10, [rsp+0xA0]
000076049b1db604  vmovaps xmm11, [rsp+0xB0]
000076049b1db60d  vmovaps xmm12, [rsp+0xC0]
000076049b1db616  vmovaps xmm14, [rsp+0xD0]
000076049b1db61f  vmovaps xmm15, [rsp+0xE0]
000076049b1db628  add rsp, 0xF0
000076049b1db62f  pop r11
000076049b1db631  pop r10
000076049b1db633  pop r9
000076049b1db635  pop r8
000076049b1db637  pop rsi
000076049b1db638  pop rdi
000076049b1db639  pop rdx
000076049b1db63a  pop rcx
000076049b1db63b  pop rax
000076049b1db63c  add rsp, 0x08
000076049b1db640  jmp 0x000076049B1D666D
000076049b1db645  sub rsp, 0x08
000076049b1db649  push rax
000076049b1db64a  push rcx
000076049b1db64b  push rdx
000076049b1db64c  push rdi
000076049b1db64d  push rsi
000076049b1db64e  push r8
000076049b1db650  push r9
000076049b1db652  push r10
000076049b1db654  push r11
000076049b1db656  sub rsp, 0xF0
000076049b1db65d  vmovaps [rsp], xmm0
000076049b1db662  vmovaps [rsp+0x10], xmm1
000076049b1db668  vmovaps [rsp+0x20], xmm2
000076049b1db66e  vmovaps [rsp+0x30], xmm3
000076049b1db674  vmovaps [rsp+0x40], xmm4
000076049b1db67a  vmovaps [rsp+0x50], xmm5
000076049b1db680  vmovaps [rsp+0x60], xmm6
000076049b1db686  vmovaps [rsp+0x70], xmm7
000076049b1db68c  vmovaps [rsp+0x80], xmm8
000076049b1db695  vmovaps [rsp+0x90], xmm9
000076049b1db69e  vmovaps [rsp+0xA0], xmm10
000076049b1db6a7  vmovaps [rsp+0xB0], xmm11
000076049b1db6b0  vmovaps [rsp+0xC0], xmm12
000076049b1db6b9  vmovaps [rsp+0xD0], xmm13
000076049b1db6c2  vmovaps [rsp+0xE0], xmm15
000076049b1db6cb  sub rsp, 0x30
000076049b1db6cf  movaps [rsp], xmm14
000076049b1db6d4  movaps [rsp+0x10], xmm1
000076049b1db6d9  movaps [rsp+0x20], xmm7
000076049b1db6de  lea rdi, [rsp]
000076049b1db6e2  mov esi, 0x00
000076049b1db6e7  mov rax, 0x64C06813C530
000076049b1db6f1  call rax
000076049b1db6f3  movaps xmm14, [rsp]
000076049b1db6f8  add rsp, 0x30
000076049b1db6fc  vmovaps xmm0, [rsp]
000076049b1db701  vmovaps xmm1, [rsp+0x10]
000076049b1db707  vmovaps xmm2, [rsp+0x20]
000076049b1db70d  vmovaps xmm3, [rsp+0x30]
000076049b1db713  vmovaps xmm4, [rsp+0x40]
000076049b1db719  vmovaps xmm5, [rsp+0x50]
000076049b1db71f  vmovaps xmm6, [rsp+0x60]
000076049b1db725  vmovaps xmm7, [rsp+0x70]
000076049b1db72b  vmovaps xmm8, [rsp+0x80]
000076049b1db734  vmovaps xmm9, [rsp+0x90]
000076049b1db73d  vmovaps xmm10, [rsp+0xA0]
000076049b1db746  vmovaps xmm11, [rsp+0xB0]
000076049b1db74f  vmovaps xmm12, [rsp+0xC0]
000076049b1db758  vmovaps xmm13, [rsp+0xD0]
000076049b1db761  vmovaps xmm15, [rsp+0xE0]
000076049b1db76a  add rsp, 0xF0
000076049b1db771  pop r11
000076049b1db773  pop r10
000076049b1db775  pop r9
000076049b1db777  pop r8
000076049b1db779  pop rsi
000076049b1db77a  pop rdi
000076049b1db77b  pop rdx
000076049b1db77c  pop rcx
000076049b1db77d  pop rax
000076049b1db77e  add rsp, 0x08
000076049b1db782  jmp 0x000076049B1D6690
000076049b1db787  sub rsp, 0x08
000076049b1db78b  push rax
000076049b1db78c  push rcx
000076049b1db78d  push rdx
000076049b1db78e  push rdi
000076049b1db78f  push rsi
000076049b1db790  push r8
000076049b1db792  push r9
000076049b1db794  push r10
000076049b1db796  push r11
000076049b1db798  sub rsp, 0xF0
000076049b1db79f  vmovaps [rsp], xmm0
000076049b1db7a4  vmovaps [rsp+0x10], xmm2
000076049b1db7aa  vmovaps [rsp+0x20], xmm3
000076049b1db7b0  vmovaps [rsp+0x30], xmm4
000076049b1db7b6  vmovaps [rsp+0x40], xmm5
000076049b1db7bc  vmovaps [rsp+0x50], xmm6
000076049b1db7c2  vmovaps [rsp+0x60], xmm7
000076049b1db7c8  vmovaps [rsp+0x70], xmm8
000076049b1db7ce  vmovaps [rsp+0x80], xmm9
000076049b1db7d7  vmovaps [rsp+0x90], xmm10
000076049b1db7e0  vmovaps [rsp+0xA0], xmm11
000076049b1db7e9  vmovaps [rsp+0xB0], xmm12
000076049b1db7f2  vmovaps [rsp+0xC0], xmm13
000076049b1db7fb  vmovaps [rsp+0xD0], xmm14
000076049b1db804  vmovaps [rsp+0xE0], xmm15
000076049b1db80d  sub rsp, 0x30
000076049b1db811  movaps [rsp], xmm1
000076049b1db815  movaps [rsp+0x10], xmm8
000076049b1db81b  movaps [rsp+0x20], xmm9
000076049b1db821  lea rdi, [rsp]
000076049b1db825  mov esi, 0x00
000076049b1db82a  mov rax, 0x64C06813C530
000076049b1db834  call rax
000076049b1db836  movaps xmm1, [rsp]
000076049b1db83a  add rsp, 0x30
000076049b1db83e  vmovaps xmm0, [rsp]
000076049b1db843  vmovaps xmm2, [rsp+0x10]
000076049b1db849  vmovaps xmm3, [rsp+0x20]
000076049b1db84f  vmovaps xmm4, [rsp+0x30]
000076049b1db855  vmovaps xmm5, [rsp+0x40]
000076049b1db85b  vmovaps xmm6, [rsp+0x50]
000076049b1db861  vmovaps xmm7, [rsp+0x60]
000076049b1db867  vmovaps xmm8, [rsp+0x70]
000076049b1db86d  vmovaps xmm9, [rsp+0x80]
000076049b1db876  vmovaps xmm10, [rsp+0x90]
000076049b1db87f  vmovaps xmm11, [rsp+0xA0]
000076049b1db888  vmovaps xmm12, [rsp+0xB0]
000076049b1db891  vmovaps xmm13, [rsp+0xC0]
000076049b1db89a  vmovaps xmm14, [rsp+0xD0]
000076049b1db8a3  vmovaps xmm15, [rsp+0xE0]
000076049b1db8ac  add rsp, 0xF0
000076049b1db8b3  pop r11
000076049b1db8b5  pop r10
000076049b1db8b7  pop r9
000076049b1db8b9  pop r8
000076049b1db8bb  pop rsi
000076049b1db8bc  pop rdi
000076049b1db8bd  pop rdx
000076049b1db8be  pop rcx
000076049b1db8bf  pop rax
000076049b1db8c0  add rsp, 0x08
000076049b1db8c4  jmp 0x000076049B1D66B2
000076049b1db8c9  call 0x000076049B0B3E40
000076049b1db8ce  jmp 0x000076049B1D66C0
000076049b1db8d3  call 0x000076049B00C380
000076049b1db8d8  jmp 0x000076049B1D66CA
000076049b1db8dd  call 0x000076049B00D600
000076049b1db8e2  jmp 0x000076049B1D66D4
000076049b1db8e7  call 0x000076049AFFF540
000076049b1db8ec  jmp 0x000076049B1D66DE
000076049b1db8f1  int3
000076049b1db8f2  nop [rax+rax*1], ax
000076049b1db8fb  nop [rax+rax*1], eax
000076049b1db900  mov eax, [r15+0x48]
000076049b1db904  lea r14d, [eax+0x01]
000076049b1db909  mov [rsp+0x10], r14d
000076049b1db90e  mov r14d, r14d
000076049b1db911  mov [r15+0x48], r14
000076049b1db915  xor eax, eax
000076049b1db917  mov r14d, [rsp+0x10]
000076049b1db91c  cmp r14d, 0x1F4
000076049b1db923  cmc
000076049b1db924  lahf
000076049b1db925  seto al
000076049b1db928  mov [r15+0x108], eax
000076049b1db92f  mov eax, [r15+0x108]
000076049b1db936  sahf
000076049b1db937  jnz 0x000076049B1DB969
000076049b1db939  cmp dword ptr [r15+0x318], 0x00
000076049b1db941  jz 0x000076049B1E1AB0
000076049b1db947  nop [rax+rax*1], ax
000076049b1db950  nop [rax+rax*1], eax
000076049b1db958  mov eax, 0x410450
000076049b1db95d  mov [r15+0x100], rax
000076049b1db964  jmp 0x000076049AFFE110
000076049b1db969  cmp dword ptr [r15+0x318], 0x00
000076049b1db971  jz 0x000076049B1DB9A0
000076049b1db977  nop [rax+rax*1], ax
000076049b1db980  nop [rax+rax*1], eax
000076049b1db988  mov eax, 0x410274
000076049b1db98d  mov [r15+0x100], rax
000076049b1db994  jmp 0x000076049AFFE110
000076049b1db999  int3
000076049b1db99a  int3
000076049b1db99b  nop [rax+rax*1], eax
000076049b1db9a0  mov rax, [r15+0x40]
000076049b1db9a4  movaps xmm1, [r15+0x1D0]
000076049b1db9ac  vmovaps [rsp+0x10], xmm1
000076049b1db9b2  vmovaps xmm15, [rsp+0x10]
000076049b1db9b8  por xmm1, xmm15
000076049b1db9bd  movaps xmm14, [r15+0x1A0]
000076049b1db9c5  vmovaps [rsp+0x10], xmm14
000076049b1db9cb  vmovaps xmm13, [rsp+0x10]
000076049b1db9d1  por xmm14, xmm13
000076049b1db9d6  lea r14, [rax+0x30]
000076049b1db9da  mov r12, [r13+r14*1]
000076049b1db9df  lea r14, [rax+0x38]
000076049b1db9e3  mov r11, [r13+r14*1]
000076049b1db9e8  movq xmm13, r12
000076049b1db9ed  movq xmm12, r11
000076049b1db9f2  movq xmm13, xmm13
000076049b1db9f7  vmovaps [rsp+0x10], xmm13
000076049b1db9fd  movq xmm13, xmm13
000076049b1dba02  movaps [r15+0x130], xmm13
000076049b1dba0a  movq xmm12, xmm12
000076049b1dba0f  vmovaps [rsp+0x20], xmm12
000076049b1dba15  movq xmm12, xmm12
000076049b1dba1a  movaps [r15+0x280], xmm12
000076049b1dba22  movaps xmm13, [r15+0x270]
000076049b1dba2a  vmovaps [rsp+0x30], xmm13
000076049b1dba30  vmovaps xmm12, [rsp+0x30]
000076049b1dba36  por xmm13, xmm12
000076049b1dba3b  lea r14, [rax+0x20]
000076049b1dba3f  mov r12, [r13+r14*1]
000076049b1dba44  lea r14, [rax+0x28]
000076049b1dba48  mov r11, [r13+r14*1]
000076049b1dba4d  movq xmm12, r12
000076049b1dba52  movq xmm11, r11
000076049b1dba57  movq xmm12, xmm12
000076049b1dba5c  vmovaps [rsp+0x30], xmm12
000076049b1dba62  movq xmm12, xmm12
000076049b1dba67  movaps [r15+0x150], xmm12
000076049b1dba6f  movq xmm11, xmm11
000076049b1dba74  vmovaps [rsp+0x40], xmm11
000076049b1dba7a  movq xmm11, xmm11
000076049b1dba7f  movaps [r15+0x140], xmm11
000076049b1dba87  lea r14, [rax+0x10]
000076049b1dba8b  mov r12, [r13+r14*1]
000076049b1dba90  lea r14, [rax+0x18]
000076049b1dba94  mov r11, [r13+r14*1]
000076049b1dba99  movq xmm12, r12
000076049b1dba9e  movq xmm11, r11
000076049b1dbaa3  movq xmm12, xmm12
000076049b1dbaa8  vmovaps [rsp+0x50], xmm12
000076049b1dbaae  movq xmm12, xmm12
000076049b1dbab3  movaps [r15+0x170], xmm12
000076049b1dbabb  movq xmm11, xmm11
000076049b1dbac0  vmovaps [rsp+0x60], xmm11
000076049b1dbac6  movq xmm11, xmm11
000076049b1dbacb  movaps [r15+0x160], xmm11
000076049b1dbad3  mov r14, [r13+rax*1]
000076049b1dbad8  vmovq xmm12, r14
000076049b1dbadd  vpbroadcastq xmm12, xmm12
000076049b1dbae2  lea r14, [rax+0x08]
000076049b1dbae6  mov rax, [r13+r14*1]
000076049b1dbaeb  movq xmm11, rax
000076049b1dbaf0  movaps [r15+0x230], xmm11
000076049b1dbaf8  mov rax, [r15+0xF8]
000076049b1dbaff  lea r14, [rax+0x50]
000076049b1dbb03  movups xmm11, [r13+r14*1]
000076049b1dbb09  lea r14, [rax+0x60]
000076049b1dbb0d  movups xmm10, [r13+r14*1]
000076049b1dbb13  lea r14, [rax+0x30]
000076049b1dbb17  movups xmm9, [r13+r14*1]
000076049b1dbb1d  mov r14, [r15+0x50]
000076049b1dbb21  mov [r15+0x60], r14
000076049b1dbb25  mov qword ptr [r15+0x58], 0x40
000076049b1dbb2d  movaps xmm8, xmm12
000076049b1dbb31  mulpd xmm8, xmm15
000076049b1dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000076049b1dbb3c  ptest xmm7, xmm7
000076049b1dbb41  jnz 0x000076049B1DC96A
000076049b1dbb47  movq xmm15, qword ptr [r15+0x230]
000076049b1dbb50  vmovaps [rsp+0x70], xmm15
000076049b1dbb56  vpermilpd xmm15, xmm15, 0x00
000076049b1dbb5c  movaps xmm7, xmm9
000076049b1dbb60  mulpd xmm7, xmm15
000076049b1dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000076049b1dbb6a  ptest xmm6, xmm6
000076049b1dbb6f  jnz 0x000076049B1DCAAE
000076049b1dbb75  vxorps xmm15, xmm15, xmm15
000076049b1dbb7a  vpbroadcastq xmm15, xmm15
000076049b1dbb7f  movaps xmm9, xmm12
000076049b1dbb83  mulpd xmm9, xmm10
000076049b1dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000076049b1dbb8e  ptest xmm6, xmm6
000076049b1dbb93  jnz 0x000076049B1DCBF0
000076049b1dbb99  movaps xmm10, xmm12
000076049b1dbb9d  mulpd xmm10, xmm11
000076049b1dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000076049b1dbba8  ptest xmm6, xmm6
000076049b1dbbad  jnz 0x000076049B1DCD34
000076049b1dbbb3  movaps xmm11, [r15+0x1F0]
000076049b1dbbbb  movaps xmm6, xmm12
000076049b1dbbbf  mulpd xmm6, xmm11
000076049b1dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000076049b1dbbc9  ptest xmm5, xmm5
000076049b1dbbce  jnz 0x000076049B1DCE78
000076049b1dbbd4  movaps xmm12, [r15+0x2A0]
000076049b1dbbdc  vmovaps [rsp+0x80], xmm12
000076049b1dbbe5  vmovaps xmm11, [rsp+0x80]
000076049b1dbbee  por xmm12, xmm11
000076049b1dbbf3  movaps xmm11, [r15+0x250]
000076049b1dbbfb  vmovaps [rsp+0x80], xmm11
000076049b1dbc04  vmovaps xmm5, [rsp+0x80]
000076049b1dbc0d  por xmm11, xmm5
000076049b1dbc12  vmovaps xmm4, [rsp+0x70]
000076049b1dbc18  vpermilpd xmm4, xmm4, 0x00
000076049b1dbc1e  movaps xmm3, xmm5
000076049b1dbc21  mulpd xmm3, xmm4
000076049b1dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000076049b1dbc2a  ptest xmm2, xmm2
000076049b1dbc2f  jnz 0x000076049B1DCFBA
000076049b1dbc35  mov [rsp+0x80], rax
000076049b1dbc3d  xor eax, eax
000076049b1dbc3f  mov r12d, 0x40
000076049b1dbc45  mov r11d, 0x200
000076049b1dbc4b  cmp r12, r11
000076049b1dbc4e  cmc
000076049b1dbc4f  lahf
000076049b1dbc50  seto al
000076049b1dbc53  mov [r15+0x108], eax
000076049b1dbc5a  movaps xmm5, xmm8
000076049b1dbc5e  addpd xmm5, xmm15
000076049b1dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000076049b1dbc68  ptest xmm4, xmm4
000076049b1dbc6d  jnz 0x000076049B1DD0FA
000076049b1dbc73  movaps xmm8, [r15+0x1B0]
000076049b1dbc7b  movaps xmm4, xmm9
000076049b1dbc7f  addpd xmm4, xmm8
000076049b1dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000076049b1dbc89  ptest xmm2, xmm2
000076049b1dbc8e  jnz 0x000076049B1DD23C
000076049b1dbc94  movaps xmm9, xmm10
000076049b1dbc98  addpd xmm9, xmm8
000076049b1dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000076049b1dbca3  ptest xmm2, xmm2
000076049b1dbca8  jnz 0x000076049B1DD37E
000076049b1dbcae  movaps xmm10, [r15+0x2F0]
000076049b1dbcb6  vmovaps [rsp+0x90], xmm10
000076049b1dbcbf  vmovaps xmm8, [rsp+0x90]
000076049b1dbcc8  por xmm10, xmm8
000076049b1dbccd  movaps xmm8, [r15+0x2E0]
000076049b1dbcd5  vmovaps [rsp+0x90], xmm8
000076049b1dbcde  vmovaps xmm2, [rsp+0x90]
000076049b1dbce7  por xmm8, xmm2
000076049b1dbcec  movaps xmm2, [r15+0x2D0]
000076049b1dbcf4  vmovaps [rsp+0x90], xmm2
000076049b1dbcfd  vmovaps [rsp+0xA0], xmm1
000076049b1dbd06  vmovaps xmm1, [rsp+0x90]
000076049b1dbd0f  por xmm2, xmm1
000076049b1dbd13  movaps xmm1, [r15+0x200]
000076049b1dbd1b  vmovaps [rsp+0x90], xmm1
000076049b1dbd24  vmovaps [rsp+0xB0], xmm15
000076049b1dbd2d  vmovaps xmm15, [rsp+0x90]
000076049b1dbd36  por xmm1, xmm15
000076049b1dbd3b  movaps xmm15, [r15+0x1C0]
000076049b1dbd43  vmovaps [rsp+0x90], xmm15
000076049b1dbd4c  vmovaps [rsp+0xC0], xmm1
000076049b1dbd55  vmovaps xmm1, [rsp+0x90]
000076049b1dbd5e  por xmm15, xmm1
000076049b1dbd63  movaps xmm1, [r15+0x190]
000076049b1dbd6b  vmovaps [rsp+0x90], xmm1
000076049b1dbd74  vmovaps [rsp+0xD0], xmm15
000076049b1dbd7d  vmovaps xmm15, [rsp+0x90]
000076049b1dbd86  por xmm1, xmm15
000076049b1dbd8b  movaps xmm15, [r15+0x300]
000076049b1dbd93  vmovaps [rsp+0x90], xmm15
000076049b1dbd9c  vmovaps [rsp+0xE0], xmm1
000076049b1dbda5  vmovaps xmm1, [rsp+0x90]
000076049b1dbdae  por xmm15, xmm1
000076049b1dbdb3  mov rax, [rsp+0x80]
000076049b1dbdbb  lea r12, [rax+0xA0]
000076049b1dbdc2  movups xmm1, [r13+r12*1]
000076049b1dbdc8  lea r12, [rax+0xB0]
000076049b1dbdcf  vmovaps [rsp+0x80], xmm1
000076049b1dbdd8  movups xmm1, [r13+r12*1]
000076049b1dbdde  vmovaps [rsp+0x90], xmm1
000076049b1dbde7  vmovaps [rsp+0xF0], xmm15
000076049b1dbdf0  vmovaps xmm15, [rsp+0xB0]
000076049b1dbdf9  vmovaps [rsp+0xB0], xmm14
000076049b1dbe02  movaps xmm1, xmm6
000076049b1dbe05  addpd xmm1, xmm15
000076049b1dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000076049b1dbe0f  ptest xmm14, xmm14
000076049b1dbe15  jnz 0x000076049B1DD4D6
000076049b1dbe1b  lea r12, [rax+0xF0]
000076049b1dbe22  movups xmm15, [r13+r12*1]
000076049b1dbe28  movaps xmm14, xmm4
000076049b1dbe2c  addpd xmm14, xmm3
000076049b1dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000076049b1dbe37  ptest xmm6, xmm6
000076049b1dbe3c  jnz 0x000076049B1DD621
000076049b1dbe42  movaps xmm6, xmm9
000076049b1dbe46  addpd xmm6, xmm7
000076049b1dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000076049b1dbe4f  ptest xmm4, xmm4
000076049b1dbe54  jnz 0x000076049B1DD763
000076049b1dbe5a  vmovaps xmm9, [rsp+0x70]
000076049b1dbe60  vpermilpd xmm9, xmm9, 0x00
000076049b1dbe66  vmovaps xmm4, [rsp+0x90]
000076049b1dbe6f  movaps xmm7, xmm4
000076049b1dbe72  mulpd xmm7, xmm9
000076049b1dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000076049b1dbe7c  ptest xmm3, xmm3
000076049b1dbe81  jnz 0x000076049B1DD8A4
000076049b1dbe87  vmovaps xmm9, [rsp+0x50]
000076049b1dbe8d  vpermilpd xmm9, xmm9, 0x00
000076049b1dbe93  movaps xmm4, xmm15
000076049b1dbe97  mulpd xmm4, xmm9
000076049b1dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000076049b1dbea1  ptest xmm3, xmm3
000076049b1dbea6  jnz 0x000076049B1DD9E5
000076049b1dbeac  lea r12, [rax+0xE0]
000076049b1dbeb3  movups xmm15, [r13+r12*1]
000076049b1dbeb9  vmovaps xmm9, [rsp+0x70]
000076049b1dbebf  vpermilpd xmm9, xmm9, 0x00
000076049b1dbec5  vmovaps [rsp+0x70], xmm1
000076049b1dbecb  vmovaps xmm1, [rsp+0x80]
000076049b1dbed4  vmovaps [rsp+0x80], xmm15
000076049b1dbedd  movaps xmm3, xmm1
000076049b1dbee0  mulpd xmm3, xmm9
000076049b1dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000076049b1dbeea  ptest xmm15, xmm15
000076049b1dbef0  jnz 0x000076049B1DDB31
000076049b1dbef6  vmovaps xmm1, [rsp+0xF0]
000076049b1dbeff  vmovaps xmm15, [rsp+0xF0]
000076049b1dbf08  por xmm1, xmm15
000076049b1dbf0d  movaps [r15+0x300], xmm1
000076049b1dbf15  vmovaps xmm15, [rsp+0xE0]
000076049b1dbf1e  vmovaps xmm9, [rsp+0xE0]
000076049b1dbf27  por xmm15, xmm9
000076049b1dbf2c  movaps [r15+0x190], xmm15
000076049b1dbf34  vmovaps xmm9, [rsp+0x50]
000076049b1dbf3a  vpermilpd xmm9, xmm9, 0x00
000076049b1dbf40  vmovaps [rsp+0x90], xmm1
000076049b1dbf49  vmovaps [rsp+0xE0], xmm15
000076049b1dbf52  vmovaps xmm15, [rsp+0x80]
000076049b1dbf5b  vmovaps [rsp+0x80], xmm14
000076049b1dbf64  movaps xmm1, xmm15
000076049b1dbf68  mulpd xmm1, xmm9
000076049b1dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000076049b1dbf72  ptest xmm14, xmm14
000076049b1dbf78  jnz 0x000076049B1DDC72
000076049b1dbf7e  lea r12, [rax+0x90]
000076049b1dbf85  movups xmm15, [r13+r12*1]
000076049b1dbf8b  vmovaps xmm14, [rsp+0xD0]
000076049b1dbf94  vmovaps xmm9, [rsp+0xD0]
000076049b1dbf9d  por xmm14, xmm9
000076049b1dbfa2  movaps [r15+0x1C0], xmm14
000076049b1dbfaa  vmovaps xmm9, [rsp+0xC0]
000076049b1dbfb3  vmovaps [rsp+0xD0], xmm1
000076049b1dbfbc  vmovaps xmm1, [rsp+0xC0]
000076049b1dbfc5  por xmm9, xmm1
000076049b1dbfca  movaps [r15+0x200], xmm9
000076049b1dbfd2  vmovaps [rsp+0xC0], xmm2
000076049b1dbfdb  vmovaps xmm1, [rsp+0xC0]
000076049b1dbfe4  por xmm2, xmm1
000076049b1dbfe8  movaps [r15+0x2D0], xmm2
000076049b1dbff0  vmovaps [rsp+0xC0], xmm8
000076049b1dbff9  vmovaps xmm1, [rsp+0xC0]
000076049b1dc002  por xmm8, xmm1
000076049b1dc007  movaps [r15+0x2E0], xmm8
000076049b1dc00f  vmovaps [rsp+0xC0], xmm15
000076049b1dc018  movaps xmm1, xmm5
000076049b1dc01b  addpd xmm1, xmm7
000076049b1dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000076049b1dc024  ptest xmm15, xmm15
000076049b1dc02a  jnz 0x000076049B1DDDBE
000076049b1dc030  vmovaps xmm15, [rsp+0x50]
000076049b1dc036  vpermilpd xmm15, xmm15, 0x00
000076049b1dc03c  vmovaps xmm5, [rsp+0xC0]
000076049b1dc045  vmovaps [rsp+0xC0], xmm1
000076049b1dc04e  movaps xmm7, xmm5
000076049b1dc051  mulpd xmm7, xmm15
000076049b1dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000076049b1dc05b  ptest xmm1, xmm1
000076049b1dc060  jnz 0x000076049B1DDEFE
000076049b1dc066  lea r12, [rax+0x80]
000076049b1dc06d  movups xmm1, [r13+r12*1]
000076049b1dc073  vmovaps xmm5, [rsp+0x70]
000076049b1dc079  vmovaps [rsp+0x70], xmm1
000076049b1dc07f  movaps xmm15, xmm5
000076049b1dc083  addpd xmm15, xmm3
000076049b1dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000076049b1dc08e  ptest xmm1, xmm1
000076049b1dc093  jnz 0x000076049B1DE049
000076049b1dc099  vmovaps xmm5, [rsp+0x80]
000076049b1dc0a2  movaps xmm1, xmm5
000076049b1dc0a5  addpd xmm1, xmm4
000076049b1dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000076049b1dc0ae  ptest xmm3, xmm3
000076049b1dc0b3  jnz 0x000076049B1DE18B
000076049b1dc0b9  vmovaps [rsp+0x80], xmm10
000076049b1dc0c2  vmovaps xmm5, [rsp+0x80]
000076049b1dc0cb  por xmm10, xmm5
000076049b1dc0d0  movaps [r15+0x2F0], xmm10
000076049b1dc0d8  vmovaps xmm5, [rsp+0x50]
000076049b1dc0de  vpermilpd xmm5, xmm5, 0x00
000076049b1dc0e4  vmovaps xmm3, [rsp+0x70]
000076049b1dc0ea  vmovaps [rsp+0x50], xmm1
000076049b1dc0f0  movaps xmm4, xmm3
000076049b1dc0f3  mulpd xmm4, xmm5
000076049b1dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000076049b1dc0fc  ptest xmm1, xmm1
000076049b1dc101  jnz 0x000076049B1DE2CB
000076049b1dc107  lea r12, [rax+0xD0]
000076049b1dc10e  movups xmm1, [r13+r12*1]
000076049b1dc114  vmovaps xmm3, [rsp+0xD0]
000076049b1dc11d  vmovaps [rsp+0x70], xmm1
000076049b1dc123  movaps xmm5, xmm6
000076049b1dc126  addpd xmm5, xmm3
000076049b1dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000076049b1dc12f  ptest xmm1, xmm1
000076049b1dc134  jnz 0x000076049B1DE415
000076049b1dc13a  vmovaps xmm1, [rsp+0x60]
000076049b1dc140  vpermilpd xmm1, xmm1, 0x00
000076049b1dc146  movaps xmm6, xmm9
000076049b1dc14a  mulpd xmm6, xmm1
000076049b1dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000076049b1dc153  ptest xmm3, xmm3
000076049b1dc158  jnz 0x000076049B1DE555
000076049b1dc15e  movaps [r15+0x260], xmm6
000076049b1dc166  vxorps xmm1, xmm1, xmm1
000076049b1dc16a  vpbroadcastq xmm1, xmm1
000076049b1dc16f  movaps [r15+0x1B0], xmm1
000076049b1dc177  vmovaps xmm1, [rsp+0x60]
000076049b1dc17d  vpermilpd xmm1, xmm1, 0x00
000076049b1dc183  vmovaps xmm3, [rsp+0x70]
000076049b1dc189  vmovaps [rsp+0x70], xmm15
000076049b1dc18f  movaps xmm9, xmm3
000076049b1dc193  mulpd xmm9, xmm1
000076049b1dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000076049b1dc19e  ptest xmm15, xmm15
000076049b1dc1a4  jnz 0x000076049B1DE696
000076049b1dc1aa  lea r12, [rax+0xC0]
000076049b1dc1b1  movups xmm1, [r13+r12*1]
000076049b1dc1b7  vmovaps xmm3, [rsp+0xC0]
000076049b1dc1c0  vmovaps [rsp+0x80], xmm1
000076049b1dc1c9  movaps xmm15, xmm3
000076049b1dc1cd  addpd xmm15, xmm7
000076049b1dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000076049b1dc1d8  ptest xmm1, xmm1
000076049b1dc1dd  jnz 0x000076049B1DE7E2
000076049b1dc1e3  vmovaps [rsp+0xC0], xmm13
000076049b1dc1ec  vmovaps xmm1, [rsp+0xC0]
000076049b1dc1f5  por xmm13, xmm1
000076049b1dc1fa  movaps [r15+0x270], xmm13
000076049b1dc202  vmovaps xmm1, [rsp+0xB0]
000076049b1dc20b  vmovaps xmm7, [rsp+0xB0]
000076049b1dc214  por xmm1, xmm7
000076049b1dc218  movaps [r15+0x1A0], xmm1
000076049b1dc220  vmovaps xmm1, [rsp+0x60]
000076049b1dc226  vpermilpd xmm1, xmm1, 0x00
000076049b1dc22c  vmovaps [rsp+0xB0], xmm1
000076049b1dc235  vmovaps xmm1, [rsp+0x80]
000076049b1dc23e  vmovaps [rsp+0x80], xmm15
000076049b1dc247  vmovaps xmm15, [rsp+0xB0]
000076049b1dc250  vmovaps [rsp+0xB0], xmm14
000076049b1dc259  movaps xmm3, xmm1
000076049b1dc25c  mulpd xmm3, xmm15
000076049b1dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000076049b1dc266  ptest xmm14, xmm14
000076049b1dc26c  jnz 0x000076049B1DE924
000076049b1dc272  lea r12, [rax+0x20]
000076049b1dc276  movups xmm1, [r13+r12*1]
000076049b1dc27c  movaps [r15+0x110], xmm1
000076049b1dc284  vmovaps xmm14, [rsp+0x70]
000076049b1dc28a  vmovaps [rsp+0x70], xmm1
000076049b1dc290  movaps xmm15, xmm14
000076049b1dc294  addpd xmm15, xmm4
000076049b1dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000076049b1dc29f  ptest xmm1, xmm1
000076049b1dc2a4  jnz 0x000076049B1DEA6F
000076049b1dc2aa  vmovaps xmm1, [rsp+0x60]
000076049b1dc2b0  vpermilpd xmm1, xmm1, 0x00
000076049b1dc2b6  movaps xmm14, xmm2
000076049b1dc2ba  mulpd xmm14, xmm1
000076049b1dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000076049b1dc2c5  ptest xmm4, xmm4
000076049b1dc2ca  jnz 0x000076049B1DEBB2
000076049b1dc2d0  vmovaps xmm4, [rsp+0x50]
000076049b1dc2d6  movaps xmm1, xmm4
000076049b1dc2d9  addpd xmm1, xmm9
000076049b1dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000076049b1dc2e3  ptest xmm2, xmm2
000076049b1dc2e8  jnz 0x000076049B1DECF4
000076049b1dc2ee  vmovaps xmm9, [rsp+0x30]
000076049b1dc2f4  vpermilpd xmm9, xmm9, 0x00
000076049b1dc2fa  vmovaps xmm2, [rsp+0x70]
000076049b1dc300  vmovaps [rsp+0x50], xmm1
000076049b1dc306  movaps xmm4, xmm2
000076049b1dc309  mulpd xmm4, xmm9
000076049b1dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000076049b1dc313  ptest xmm1, xmm1
000076049b1dc318  jnz 0x000076049B1DEE35
000076049b1dc31e  vmovaps xmm1, [rsp+0x30]
000076049b1dc324  vpermilpd xmm1, xmm1, 0x00
000076049b1dc32a  vmovaps xmm2, [rsp+0x90]
000076049b1dc333  vmovaps [rsp+0x60], xmm15
000076049b1dc339  movaps xmm9, xmm2
000076049b1dc33d  mulpd xmm9, xmm1
000076049b1dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000076049b1dc348  ptest xmm15, xmm15
000076049b1dc34e  jnz 0x000076049B1DEF76
000076049b1dc354  vmovaps xmm15, [rsp+0x80]
000076049b1dc35d  movaps xmm1, xmm15
000076049b1dc361  addpd xmm1, xmm6
000076049b1dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000076049b1dc36a  ptest xmm2, xmm2
000076049b1dc36f  jnz 0x000076049B1DF0B8
000076049b1dc375  movaps xmm15, xmm5
000076049b1dc379  addpd xmm15, xmm3
000076049b1dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000076049b1dc384  ptest xmm6, xmm6
000076049b1dc389  jnz 0x000076049B1DF1F9
000076049b1dc38f  vmovaps xmm6, [rsp+0x30]
000076049b1dc395  vpermilpd xmm6, xmm6, 0x00
000076049b1dc39b  movaps xmm5, xmm8
000076049b1dc39f  mulpd xmm5, xmm6
000076049b1dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000076049b1dc3a8  ptest xmm3, xmm3
000076049b1dc3ad  jnz 0x000076049B1DF33B
000076049b1dc3b3  vmovaps xmm8, [rsp+0x30]
000076049b1dc3b9  vpermilpd xmm8, xmm8, 0x00
000076049b1dc3bf  movaps xmm6, xmm10
000076049b1dc3c3  mulpd xmm6, xmm8
000076049b1dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000076049b1dc3cd  ptest xmm3, xmm3
000076049b1dc3d2  jnz 0x000076049B1DF47C
000076049b1dc3d8  vmovaps xmm8, [rsp+0x60]
000076049b1dc3de  movaps xmm10, xmm8
000076049b1dc3e2  addpd xmm10, xmm14
000076049b1dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000076049b1dc3ed  ptest xmm3, xmm3
000076049b1dc3f2  jnz 0x000076049B1DF5BE
000076049b1dc3f8  vmovaps xmm8, [rsp+0x50]
000076049b1dc3fe  movaps xmm14, xmm8
000076049b1dc402  addpd xmm14, xmm4
000076049b1dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000076049b1dc40d  ptest xmm3, xmm3
000076049b1dc412  jnz 0x000076049B1DF702
000076049b1dc418  vmovaps xmm8, [rsp+0x40]
000076049b1dc41e  vpermilpd xmm8, xmm8, 0x00
000076049b1dc424  movaps xmm4, xmm13
000076049b1dc428  mulpd xmm4, xmm8
000076049b1dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000076049b1dc432  ptest xmm3, xmm3
000076049b1dc437  jnz 0x000076049B1DF845
000076049b1dc43d  movaps xmm13, xmm15
000076049b1dc441  addpd xmm13, xmm9
000076049b1dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000076049b1dc44c  ptest xmm8, xmm8
000076049b1dc452  jnz 0x000076049B1DF987
000076049b1dc458  movaps xmm15, xmm1
000076049b1dc45c  addpd xmm15, xmm5
000076049b1dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000076049b1dc467  ptest xmm9, xmm9
000076049b1dc46d  jnz 0x000076049B1DFACB
000076049b1dc473  vmovaps [rsp+0x30], xmm11
000076049b1dc479  vmovaps xmm1, [rsp+0x30]
000076049b1dc47f  por xmm11, xmm1
000076049b1dc484  movaps [r15+0x250], xmm11
000076049b1dc48c  vmovaps [rsp+0x30], xmm12
000076049b1dc492  vmovaps xmm1, [rsp+0x30]
000076049b1dc498  por xmm12, xmm1
000076049b1dc49d  movaps [r15+0x2A0], xmm12
000076049b1dc4a5  vmovaps xmm1, [rsp+0xA0]
000076049b1dc4ae  vmovaps xmm11, [rsp+0xA0]
000076049b1dc4b7  por xmm1, xmm11
000076049b1dc4bc  movaps [r15+0x1D0], xmm1
000076049b1dc4c4  lea r12, [rax+0x40]
000076049b1dc4c8  movups xmm1, [r13+r12*1]
000076049b1dc4ce  movaps [r15+0x2C0], xmm1
000076049b1dc4d6  vmovaps xmm11, [rsp+0x40]
000076049b1dc4dc  vpermilpd xmm11, xmm11, 0x00
000076049b1dc4e2  vmovaps xmm8, [rsp+0xE0]
000076049b1dc4eb  movaps xmm9, xmm8
000076049b1dc4ef  mulpd xmm9, xmm11
000076049b1dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000076049b1dc4fa  ptest xmm5, xmm5
000076049b1dc4ff  jnz 0x000076049B1DFC17
000076049b1dc505  movaps xmm11, xmm10
000076049b1dc509  addpd xmm11, xmm6
000076049b1dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000076049b1dc514  ptest xmm8, xmm8
000076049b1dc51a  jnz 0x000076049B1DFD5B
000076049b1dc520  movaps xmm10, xmm14
000076049b1dc524  addpd xmm10, xmm4
000076049b1dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000076049b1dc52f  ptest xmm8, xmm8
000076049b1dc535  jnz 0x000076049B1DFE9E
000076049b1dc53b  vmovaps xmm14, [rsp+0x40]
000076049b1dc541  vpermilpd xmm14, xmm14, 0x00
000076049b1dc547  movaps xmm8, xmm1
000076049b1dc54b  mulpd xmm8, xmm14
000076049b1dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000076049b1dc556  ptest xmm6, xmm6
000076049b1dc55b  jnz 0x000076049B1DFFE1
000076049b1dc561  movaps xmm1, [r15+0x2B0]
000076049b1dc569  vmovaps xmm14, [rsp+0x40]
000076049b1dc56f  vpermilpd xmm14, xmm14, 0x00
000076049b1dc575  movaps xmm6, xmm1
000076049b1dc578  mulpd xmm6, xmm14
000076049b1dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000076049b1dc582  ptest xmm5, xmm5
000076049b1dc587  jnz 0x000076049B1E0124
000076049b1dc58d  vmovaps xmm1, [rsp+0x10]
000076049b1dc593  vpermilpd xmm1, xmm1, 0x00
000076049b1dc599  movaps xmm14, xmm12
000076049b1dc59d  mulpd xmm14, xmm1
000076049b1dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000076049b1dc5a8  ptest xmm5, xmm5
000076049b1dc5ad  jnz 0x000076049B1E0265
000076049b1dc5b3  movaps xmm1, xmm13
000076049b1dc5b7  addpd xmm1, xmm9
000076049b1dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000076049b1dc5c1  ptest xmm12, xmm12
000076049b1dc5c7  jnz 0x000076049B1E03A8
000076049b1dc5cd  vmovaps xmm13, [rsp+0x10]
000076049b1dc5d3  vpermilpd xmm13, xmm13, 0x00
000076049b1dc5d9  movaps xmm12, xmm7
000076049b1dc5dd  mulpd xmm12, xmm13
000076049b1dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000076049b1dc5e8  ptest xmm9, xmm9
000076049b1dc5ee  jnz 0x000076049B1E04EA
000076049b1dc5f4  movaps xmm13, xmm15
000076049b1dc5f8  addpd xmm13, xmm8
000076049b1dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000076049b1dc603  ptest xmm9, xmm9
000076049b1dc609  jnz 0x000076049B1E062D
000076049b1dc60f  movaps xmm15, [r15+0x290]
000076049b1dc617  vmovaps xmm9, [rsp+0x10]
000076049b1dc61d  vpermilpd xmm9, xmm9, 0x00
000076049b1dc623  movaps xmm8, xmm15
000076049b1dc627  mulpd xmm8, xmm9
000076049b1dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000076049b1dc632  ptest xmm7, xmm7
000076049b1dc637  jnz 0x000076049B1E0771
000076049b1dc63d  movaps xmm15, xmm11
000076049b1dc641  addpd xmm15, xmm6
000076049b1dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000076049b1dc64c  ptest xmm9, xmm9
000076049b1dc652  jnz 0x000076049B1E08B5
000076049b1dc658  movaps xmm11, [r15+0x1E0]
000076049b1dc660  vmovaps xmm9, [rsp+0x10]
000076049b1dc666  vpermilpd xmm9, xmm9, 0x00
000076049b1dc66c  movaps xmm7, xmm11
000076049b1dc670  mulpd xmm7, xmm9
000076049b1dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000076049b1dc67a  ptest xmm6, xmm6
000076049b1dc67f  jnz 0x000076049B1E09F8
000076049b1dc685  movaps xmm11, xmm10
000076049b1dc689  addpd xmm11, xmm14
000076049b1dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000076049b1dc694  ptest xmm9, xmm9
000076049b1dc69a  jnz 0x000076049B1E0B3A
000076049b1dc6a0  lea r12, [rax+0x70]
000076049b1dc6a4  movups xmm14, [r13+r12*1]
000076049b1dc6aa  movaps [r15+0x240], xmm14
000076049b1dc6b2  movaps xmm10, xmm1
000076049b1dc6b6  addpd xmm10, xmm12
000076049b1dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000076049b1dc6c1  ptest xmm9, xmm9
000076049b1dc6c7  jnz 0x000076049B1E0C88
000076049b1dc6cd  movaps [r15+0x170], xmm10
000076049b1dc6d5  vmovaps xmm1, [rsp+0x20]
000076049b1dc6db  vpermilpd xmm1, xmm1, 0x00
000076049b1dc6e1  movaps xmm12, xmm14
000076049b1dc6e5  mulpd xmm12, xmm1
000076049b1dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000076049b1dc6f0  ptest xmm9, xmm9
000076049b1dc6f6  jnz 0x000076049B1E0DCB
000076049b1dc6fc  vmovaps xmm1, [rsp+0x20]
000076049b1dc702  vpermilpd xmm1, xmm1, 0x00
000076049b1dc708  vmovaps xmm9, [rsp+0xB0]
000076049b1dc711  movaps xmm14, xmm9
000076049b1dc715  mulpd xmm14, xmm1
000076049b1dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000076049b1dc720  ptest xmm6, xmm6
000076049b1dc725  jnz 0x000076049B1E0F0E
000076049b1dc72b  movaps [r15+0x180], xmm14
000076049b1dc733  movaps xmm1, xmm13
000076049b1dc737  addpd xmm1, xmm8
000076049b1dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000076049b1dc741  ptest xmm9, xmm9
000076049b1dc747  jnz 0x000076049B1E1051
000076049b1dc74d  movaps [r15+0x210], xmm1
000076049b1dc755  movups xmm13, [r13+rax*1]
000076049b1dc75b  lea r12, [rax+0x10]
000076049b1dc75f  movups xmm9, [r13+r12*1]
000076049b1dc765  movaps [r15+0x230], xmm9
000076049b1dc76d  movaps xmm8, xmm15
000076049b1dc771  addpd xmm8, xmm7
000076049b1dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000076049b1dc77c  ptest xmm6, xmm6
000076049b1dc781  jnz 0x000076049B1E11A7
000076049b1dc787  movaps [r15+0x130], xmm8
000076049b1dc78f  vmovaps xmm15, [rsp+0x20]
000076049b1dc795  vpermilpd xmm15, xmm15, 0x00
000076049b1dc79b  movaps xmm7, xmm9
000076049b1dc79f  mulpd xmm7, xmm15
000076049b1dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000076049b1dc7a9  ptest xmm6, xmm6
000076049b1dc7ae  jnz 0x000076049B1E12EA
000076049b1dc7b4  movaps [r15+0x220], xmm7
000076049b1dc7bc  vmovaps xmm15, [rsp+0x20]
000076049b1dc7c2  vpermilpd xmm15, xmm15, 0x00
000076049b1dc7c8  movaps xmm9, xmm13
000076049b1dc7cc  mulpd xmm9, xmm15
000076049b1dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000076049b1dc7d7  ptest xmm6, xmm6
000076049b1dc7dc  jnz 0x000076049B1E142C
000076049b1dc7e2  movaps xmm15, xmm11
000076049b1dc7e6  addpd xmm15, xmm12
000076049b1dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000076049b1dc7f1  ptest xmm13, xmm13
000076049b1dc7f7  jnz 0x000076049B1E1570
000076049b1dc7fd  movaps [r15+0x140], xmm15
000076049b1dc805  movaps xmm13, xmm10
000076049b1dc809  addpd xmm13, xmm14
000076049b1dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000076049b1dc814  ptest xmm12, xmm12
000076049b1dc81a  jnz 0x000076049B1E16B4
000076049b1dc820  movaps [r15+0x150], xmm13
000076049b1dc828  movaps xmm14, xmm1
000076049b1dc82c  addpd xmm14, xmm7
000076049b1dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000076049b1dc837  ptest xmm12, xmm12
000076049b1dc83d  jnz 0x000076049B1E17F8
000076049b1dc843  movaps [r15+0x160], xmm14
000076049b1dc84b  movaps xmm1, xmm8
000076049b1dc84f  addpd xmm1, xmm9
000076049b1dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000076049b1dc859  ptest xmm12, xmm12
000076049b1dc85f  jnz 0x000076049B1E193A
000076049b1dc865  movaps [r15+0x120], xmm1
000076049b1dc86d  movups [r13+r14*1], xmm15
000076049b1dc873  lea rax, [r14+0x10]
000076049b1dc877  movups [r13+rax*1], xmm13
000076049b1dc87d  lea rax, [r14+0x20]
000076049b1dc881  movups [r13+rax*1], xmm14
000076049b1dc887  lea rax, [r14+0x30]
000076049b1dc88b  movups [r13+rax*1], xmm1
000076049b1dc891  mov eax, [r15+0x108]
000076049b1dc898  sahf
000076049b1dc899  jnz 0x000076049B1DC8CB
000076049b1dc89b  cmp dword ptr [r15+0x318], 0x00
000076049b1dc8a3  jz 0x000076049B1DB900
000076049b1dc8a9  nop [rax+rax*1], ax
000076049b1dc8b2  nop [rax+rax*1], eax
000076049b1dc8ba  mov eax, 0x410444
000076049b1dc8bf  mov [r15+0x100], rax
000076049b1dc8c6  jmp 0x000076049AFFE110
000076049b1dc8cb  cmp dword ptr [r15+0x318], 0x00
000076049b1dc8d3  jz 0x000076049B1D57E0
000076049b1dc8d9  nop [rax+rax*1], ax
000076049b1dc8e2  nop [rax+rax*1], eax
000076049b1dc8ea  mov eax, 0x410278
000076049b1dc8ef  mov [r15+0x100], rax
000076049b1dc8f6  jmp 0x000076049AFFE110
000076049b1dc8fb  int3
000076049b1dc8fc  call 0x000076049B0E27E0
000076049b1dc901  jmp 0x000076049B1DB9DF
000076049b1dc906  call 0x000076049B0E1570
000076049b1dc90b  jmp 0x000076049B1DB9E8
000076049b1dc910  call 0x000076049B0E27E0
000076049b1dc915  jmp 0x000076049B1DBA44
000076049b1dc91a  call 0x000076049B0E1570
000076049b1dc91f  jmp 0x000076049B1DBA4D
000076049b1dc924  call 0x000076049B0E27E0
000076049b1dc929  jmp 0x000076049B1DBA90
000076049b1dc92e  call 0x000076049B0E1570
000076049b1dc933  jmp 0x000076049B1DBA99
000076049b1dc938  call 0x000076049B00DC20
000076049b1dc93d  jmp 0x000076049B1DBAD8
000076049b1dc942  call 0x000076049B0D59C0
000076049b1dc947  jmp 0x000076049B1DBAEB
000076049b1dc94c  call 0x000076049B0E0E30
000076049b1dc951  jmp 0x000076049B1DBB09
000076049b1dc956  call 0x000076049B0DFBC0
000076049b1dc95b  jmp 0x000076049B1DBB13
000076049b1dc960  call 0x000076049B0DE950
000076049b1dc965  jmp 0x000076049B1DBB1D
000076049b1dc96a  sub rsp, 0x08
000076049b1dc96e  push rax
000076049b1dc96f  push rcx
000076049b1dc970  push rdx
000076049b1dc971  push rdi
000076049b1dc972  push rsi
000076049b1dc973  push r8
000076049b1dc975  push r9
000076049b1dc977  push r10
000076049b1dc979  push r11
000076049b1dc97b  sub rsp, 0xF0
000076049b1dc982  vmovaps [rsp], xmm0
000076049b1dc987  vmovaps [rsp+0x10], xmm1
000076049b1dc98d  vmovaps [rsp+0x20], xmm2
000076049b1dc993  vmovaps [rsp+0x30], xmm3
000076049b1dc999  vmovaps [rsp+0x40], xmm4
000076049b1dc99f  vmovaps [rsp+0x50], xmm5
000076049b1dc9a5  vmovaps [rsp+0x60], xmm6
000076049b1dc9ab  vmovaps [rsp+0x70], xmm7
000076049b1dc9b1  vmovaps [rsp+0x80], xmm9
000076049b1dc9ba  vmovaps [rsp+0x90], xmm10
000076049b1dc9c3  vmovaps [rsp+0xA0], xmm11
000076049b1dc9cc  vmovaps [rsp+0xB0], xmm12
000076049b1dc9d5  vmovaps [rsp+0xC0], xmm13
000076049b1dc9de  vmovaps [rsp+0xD0], xmm14
000076049b1dc9e7  vmovaps [rsp+0xE0], xmm15
000076049b1dc9f0  sub rsp, 0x30
000076049b1dc9f4  movaps [rsp], xmm8
000076049b1dc9f9  movaps [rsp+0x10], xmm12
000076049b1dc9ff  movaps [rsp+0x20], xmm15
000076049b1dca05  lea rdi, [rsp]
000076049b1dca09  mov esi, 0x00
000076049b1dca0e  mov rax, 0x64C06813C530
000076049b1dca18  call rax
000076049b1dca1a  movaps xmm8, [rsp]
000076049b1dca1f  add rsp, 0x30
000076049b1dca23  vmovaps xmm0, [rsp]
000076049b1dca28  vmovaps xmm1, [rsp+0x10]
000076049b1dca2e  vmovaps xmm2, [rsp+0x20]
000076049b1dca34  vmovaps xmm3, [rsp+0x30]
000076049b1dca3a  vmovaps xmm4, [rsp+0x40]
000076049b1dca40  vmovaps xmm5, [rsp+0x50]
000076049b1dca46  vmovaps xmm6, [rsp+0x60]
000076049b1dca4c  vmovaps xmm7, [rsp+0x70]
000076049b1dca52  vmovaps xmm9, [rsp+0x80]
000076049b1dca5b  vmovaps xmm10, [rsp+0x90]
000076049b1dca64  vmovaps xmm11, [rsp+0xA0]
000076049b1dca6d  vmovaps xmm12, [rsp+0xB0]
000076049b1dca76  vmovaps xmm13, [rsp+0xC0]
000076049b1dca7f  vmovaps xmm14, [rsp+0xD0]
000076049b1dca88  vmovaps xmm15, [rsp+0xE0]
000076049b1dca91  add rsp, 0xF0
000076049b1dca98  pop r11
000076049b1dca9a  pop r10
000076049b1dca9c  pop r9
000076049b1dca9e  pop r8
000076049b1dcaa0  pop rsi
000076049b1dcaa1  pop rdi
000076049b1dcaa2  pop rdx
000076049b1dcaa3  pop rcx
000076049b1dcaa4  pop rax
000076049b1dcaa5  add rsp, 0x08
000076049b1dcaa9  jmp 0x000076049B1DBB47
000076049b1dcaae  sub rsp, 0x08
000076049b1dcab2  push rax
000076049b1dcab3  push rcx
000076049b1dcab4  push rdx
000076049b1dcab5  push rdi
000076049b1dcab6  push rsi
000076049b1dcab7  push r8
000076049b1dcab9  push r9
000076049b1dcabb  push r10
000076049b1dcabd  push r11
000076049b1dcabf  sub rsp, 0xF0
000076049b1dcac6  vmovaps [rsp], xmm0
000076049b1dcacb  vmovaps [rsp+0x10], xmm1
000076049b1dcad1  vmovaps [rsp+0x20], xmm2
000076049b1dcad7  vmovaps [rsp+0x30], xmm3
000076049b1dcadd  vmovaps [rsp+0x40], xmm4
000076049b1dcae3  vmovaps [rsp+0x50], xmm5
000076049b1dcae9  vmovaps [rsp+0x60], xmm6
000076049b1dcaef  vmovaps [rsp+0x70], xmm8
000076049b1dcaf5  vmovaps [rsp+0x80], xmm9
000076049b1dcafe  vmovaps [rsp+0x90], xmm10
000076049b1dcb07  vmovaps [rsp+0xA0], xmm11
000076049b1dcb10  vmovaps [rsp+0xB0], xmm12
000076049b1dcb19  vmovaps [rsp+0xC0], xmm13
000076049b1dcb22  vmovaps [rsp+0xD0], xmm14
000076049b1dcb2b  vmovaps [rsp+0xE0], xmm15
000076049b1dcb34  sub rsp, 0x30
000076049b1dcb38  movaps [rsp], xmm7
000076049b1dcb3c  movaps [rsp+0x10], xmm9
000076049b1dcb42  movaps [rsp+0x20], xmm15
000076049b1dcb48  lea rdi, [rsp]
000076049b1dcb4c  mov esi, 0x00
000076049b1dcb51  mov rax, 0x64C06813C530
000076049b1dcb5b  call rax
000076049b1dcb5d  movaps xmm7, [rsp]
000076049b1dcb61  add rsp, 0x30
000076049b1dcb65  vmovaps xmm0, [rsp]
000076049b1dcb6a  vmovaps xmm1, [rsp+0x10]
000076049b1dcb70  vmovaps xmm2, [rsp+0x20]
000076049b1dcb76  vmovaps xmm3, [rsp+0x30]
000076049b1dcb7c  vmovaps xmm4, [rsp+0x40]
000076049b1dcb82  vmovaps xmm5, [rsp+0x50]
000076049b1dcb88  vmovaps xmm6, [rsp+0x60]
000076049b1dcb8e  vmovaps xmm8, [rsp+0x70]
000076049b1dcb94  vmovaps xmm9, [rsp+0x80]
000076049b1dcb9d  vmovaps xmm10, [rsp+0x90]
000076049b1dcba6  vmovaps xmm11, [rsp+0xA0]
000076049b1dcbaf  vmovaps xmm12, [rsp+0xB0]
000076049b1dcbb8  vmovaps xmm13, [rsp+0xC0]
000076049b1dcbc1  vmovaps xmm14, [rsp+0xD0]
000076049b1dcbca  vmovaps xmm15, [rsp+0xE0]
000076049b1dcbd3  add rsp, 0xF0
000076049b1dcbda  pop r11
000076049b1dcbdc  pop r10
000076049b1dcbde  pop r9
000076049b1dcbe0  pop r8
000076049b1dcbe2  pop rsi
000076049b1dcbe3  pop rdi
000076049b1dcbe4  pop rdx
000076049b1dcbe5  pop rcx
000076049b1dcbe6  pop rax
000076049b1dcbe7  add rsp, 0x08
000076049b1dcbeb  jmp 0x000076049B1DBB75
000076049b1dcbf0  sub rsp, 0x08
000076049b1dcbf4  push rax
000076049b1dcbf5  push rcx
000076049b1dcbf6  push rdx
000076049b1dcbf7  push rdi
000076049b1dcbf8  push rsi
000076049b1dcbf9  push r8
000076049b1dcbfb  push r9
000076049b1dcbfd  push r10
000076049b1dcbff  push r11
000076049b1dcc01  sub rsp, 0xF0
000076049b1dcc08  vmovaps [rsp], xmm0
000076049b1dcc0d  vmovaps [rsp+0x10], xmm1
000076049b1dcc13  vmovaps [rsp+0x20], xmm2
000076049b1dcc19  vmovaps [rsp+0x30], xmm3
000076049b1dcc1f  vmovaps [rsp+0x40], xmm4
000076049b1dcc25  vmovaps [rsp+0x50], xmm5
000076049b1dcc2b  vmovaps [rsp+0x60], xmm6
000076049b1dcc31  vmovaps [rsp+0x70], xmm7
000076049b1dcc37  vmovaps [rsp+0x80], xmm8
000076049b1dcc40  vmovaps [rsp+0x90], xmm10
000076049b1dcc49  vmovaps [rsp+0xA0], xmm11
000076049b1dcc52  vmovaps [rsp+0xB0], xmm12
000076049b1dcc5b  vmovaps [rsp+0xC0], xmm13
000076049b1dcc64  vmovaps [rsp+0xD0], xmm14
000076049b1dcc6d  vmovaps [rsp+0xE0], xmm15
000076049b1dcc76  sub rsp, 0x30
000076049b1dcc7a  movaps [rsp], xmm9
000076049b1dcc7f  movaps [rsp+0x10], xmm12
000076049b1dcc85  movaps [rsp+0x20], xmm10
000076049b1dcc8b  lea rdi, [rsp]
000076049b1dcc8f  mov esi, 0x00
000076049b1dcc94  mov rax, 0x64C06813C530
000076049b1dcc9e  call rax
000076049b1dcca0  movaps xmm9, [rsp]
000076049b1dcca5  add rsp, 0x30
000076049b1dcca9  vmovaps xmm0, [rsp]
000076049b1dccae  vmovaps xmm1, [rsp+0x10]
000076049b1dccb4  vmovaps xmm2, [rsp+0x20]
000076049b1dccba  vmovaps xmm3, [rsp+0x30]
000076049b1dccc0  vmovaps xmm4, [rsp+0x40]
000076049b1dccc6  vmovaps xmm5, [rsp+0x50]
000076049b1dcccc  vmovaps xmm6, [rsp+0x60]
000076049b1dccd2  vmovaps xmm7, [rsp+0x70]
000076049b1dccd8  vmovaps xmm8, [rsp+0x80]
000076049b1dcce1  vmovaps xmm10, [rsp+0x90]
000076049b1dccea  vmovaps xmm11, [rsp+0xA0]
000076049b1dccf3  vmovaps xmm12, [rsp+0xB0]
000076049b1dccfc  vmovaps xmm13, [rsp+0xC0]
000076049b1dcd05  vmovaps xmm14, [rsp+0xD0]
000076049b1dcd0e  vmovaps xmm15, [rsp+0xE0]
000076049b1dcd17  add rsp, 0xF0
000076049b1dcd1e  pop r11
000076049b1dcd20  pop r10
000076049b1dcd22  pop r9
000076049b1dcd24  pop r8
000076049b1dcd26  pop rsi
000076049b1dcd27  pop rdi
000076049b1dcd28  pop rdx
000076049b1dcd29  pop rcx
000076049b1dcd2a  pop rax
000076049b1dcd2b  add rsp, 0x08
000076049b1dcd2f  jmp 0x000076049B1DBB99
000076049b1dcd34  sub rsp, 0x08
000076049b1dcd38  push rax
000076049b1dcd39  push rcx
000076049b1dcd3a  push rdx
000076049b1dcd3b  push rdi
000076049b1dcd3c  push rsi
000076049b1dcd3d  push r8
000076049b1dcd3f  push r9
000076049b1dcd41  push r10
000076049b1dcd43  push r11
000076049b1dcd45  sub rsp, 0xF0
000076049b1dcd4c  vmovaps [rsp], xmm0
000076049b1dcd51  vmovaps [rsp+0x10], xmm1
000076049b1dcd57  vmovaps [rsp+0x20], xmm2
000076049b1dcd5d  vmovaps [rsp+0x30], xmm3
000076049b1dcd63  vmovaps [rsp+0x40], xmm4
000076049b1dcd69  vmovaps [rsp+0x50], xmm5
000076049b1dcd6f  vmovaps [rsp+0x60], xmm6
000076049b1dcd75  vmovaps [rsp+0x70], xmm7
000076049b1dcd7b  vmovaps [rsp+0x80], xmm8
000076049b1dcd84  vmovaps [rsp+0x90], xmm9
000076049b1dcd8d  vmovaps [rsp+0xA0], xmm11
000076049b1dcd96  vmovaps [rsp+0xB0], xmm12
000076049b1dcd9f  vmovaps [rsp+0xC0], xmm13
000076049b1dcda8  vmovaps [rsp+0xD0], xmm14
000076049b1dcdb1  vmovaps [rsp+0xE0], xmm15
000076049b1dcdba  sub rsp, 0x30
000076049b1dcdbe  movaps [rsp], xmm10
000076049b1dcdc3  movaps [rsp+0x10], xmm12
000076049b1dcdc9  movaps [rsp+0x20], xmm11
000076049b1dcdcf  lea rdi, [rsp]
000076049b1dcdd3  mov esi, 0x00
000076049b1dcdd8  mov rax, 0x64C06813C530
000076049b1dcde2  call rax
000076049b1dcde4  movaps xmm10, [rsp]
000076049b1dcde9  add rsp, 0x30
000076049b1dcded  vmovaps xmm0, [rsp]
000076049b1dcdf2  vmovaps xmm1, [rsp+0x10]
000076049b1dcdf8  vmovaps xmm2, [rsp+0x20]
000076049b1dcdfe  vmovaps xmm3, [rsp+0x30]
000076049b1dce04  vmovaps xmm4, [rsp+0x40]
000076049b1dce0a  vmovaps xmm5, [rsp+0x50]
000076049b1dce10  vmovaps xmm6, [rsp+0x60]
000076049b1dce16  vmovaps xmm7, [rsp+0x70]
000076049b1dce1c  vmovaps xmm8, [rsp+0x80]
000076049b1dce25  vmovaps xmm9, [rsp+0x90]
000076049b1dce2e  vmovaps xmm11, [rsp+0xA0]
000076049b1dce37  vmovaps xmm12, [rsp+0xB0]
000076049b1dce40  vmovaps xmm13, [rsp+0xC0]
000076049b1dce49  vmovaps xmm14, [rsp+0xD0]
000076049b1dce52  vmovaps xmm15, [rsp+0xE0]
000076049b1dce5b  add rsp, 0xF0
000076049b1dce62  pop r11
000076049b1dce64  pop r10
000076049b1dce66  pop r9
000076049b1dce68  pop r8
000076049b1dce6a  pop rsi
000076049b1dce6b  pop rdi
000076049b1dce6c  pop rdx
000076049b1dce6d  pop rcx
000076049b1dce6e  pop rax
000076049b1dce6f  add rsp, 0x08
000076049b1dce73  jmp 0x000076049B1DBBB3
000076049b1dce78  sub rsp, 0x08
000076049b1dce7c  push rax
000076049b1dce7d  push rcx
000076049b1dce7e  push rdx
000076049b1dce7f  push rdi
000076049b1dce80  push rsi
000076049b1dce81  push r8
000076049b1dce83  push r9
000076049b1dce85  push r10
000076049b1dce87  push r11
000076049b1dce89  sub rsp, 0xF0
000076049b1dce90  vmovaps [rsp], xmm0
000076049b1dce95  vmovaps [rsp+0x10], xmm1
000076049b1dce9b  vmovaps [rsp+0x20], xmm2
000076049b1dcea1  vmovaps [rsp+0x30], xmm3
000076049b1dcea7  vmovaps [rsp+0x40], xmm4
000076049b1dcead  vmovaps [rsp+0x50], xmm5
000076049b1dceb3  vmovaps [rsp+0x60], xmm7
000076049b1dceb9  vmovaps [rsp+0x70], xmm8
000076049b1dcebf  vmovaps [rsp+0x80], xmm9
000076049b1dcec8  vmovaps [rsp+0x90], xmm10
000076049b1dced1  vmovaps [rsp+0xA0], xmm11
000076049b1dceda  vmovaps [rsp+0xB0], xmm12
000076049b1dcee3  vmovaps [rsp+0xC0], xmm13
000076049b1dceec  vmovaps [rsp+0xD0], xmm14
000076049b1dcef5  vmovaps [rsp+0xE0], xmm15
000076049b1dcefe  sub rsp, 0x30
000076049b1dcf02  movaps [rsp], xmm6
000076049b1dcf06  movaps [rsp+0x10], xmm12
000076049b1dcf0c  movaps [rsp+0x20], xmm11
000076049b1dcf12  lea rdi, [rsp]
000076049b1dcf16  mov esi, 0x00
000076049b1dcf1b  mov rax, 0x64C06813C530
000076049b1dcf25  call rax
000076049b1dcf27  movaps xmm6, [rsp]
000076049b1dcf2b  add rsp, 0x30
000076049b1dcf2f  vmovaps xmm0, [rsp]
000076049b1dcf34  vmovaps xmm1, [rsp+0x10]
000076049b1dcf3a  vmovaps xmm2, [rsp+0x20]
000076049b1dcf40  vmovaps xmm3, [rsp+0x30]
000076049b1dcf46  vmovaps xmm4, [rsp+0x40]
000076049b1dcf4c  vmovaps xmm5, [rsp+0x50]
000076049b1dcf52  vmovaps xmm7, [rsp+0x60]
000076049b1dcf58  vmovaps xmm8, [rsp+0x70]
000076049b1dcf5e  vmovaps xmm9, [rsp+0x80]
000076049b1dcf67  vmovaps xmm10, [rsp+0x90]
000076049b1dcf70  vmovaps xmm11, [rsp+0xA0]
000076049b1dcf79  vmovaps xmm12, [rsp+0xB0]
000076049b1dcf82  vmovaps xmm13, [rsp+0xC0]
000076049b1dcf8b  vmovaps xmm14, [rsp+0xD0]
000076049b1dcf94  vmovaps xmm15, [rsp+0xE0]
000076049b1dcf9d  add rsp, 0xF0
000076049b1dcfa4  pop r11
000076049b1dcfa6  pop r10
000076049b1dcfa8  pop r9
000076049b1dcfaa  pop r8
000076049b1dcfac  pop rsi
000076049b1dcfad  pop rdi
000076049b1dcfae  pop rdx
000076049b1dcfaf  pop rcx
000076049b1dcfb0  pop rax
000076049b1dcfb1  add rsp, 0x08
000076049b1dcfb5  jmp 0x000076049B1DBBD4
000076049b1dcfba  sub rsp, 0x08
000076049b1dcfbe  push rax
000076049b1dcfbf  push rcx
000076049b1dcfc0  push rdx
000076049b1dcfc1  push rdi
000076049b1dcfc2  push rsi
000076049b1dcfc3  push r8
000076049b1dcfc5  push r9
000076049b1dcfc7  push r10
000076049b1dcfc9  push r11
000076049b1dcfcb  sub rsp, 0xF0
000076049b1dcfd2  vmovaps [rsp], xmm0
000076049b1dcfd7  vmovaps [rsp+0x10], xmm1
000076049b1dcfdd  vmovaps [rsp+0x20], xmm2
000076049b1dcfe3  vmovaps [rsp+0x30], xmm4
000076049b1dcfe9  vmovaps [rsp+0x40], xmm5
000076049b1dcfef  vmovaps [rsp+0x50], xmm6
000076049b1dcff5  vmovaps [rsp+0x60], xmm7
000076049b1dcffb  vmovaps [rsp+0x70], xmm8
000076049b1dd001  vmovaps [rsp+0x80], xmm9
000076049b1dd00a  vmovaps [rsp+0x90], xmm10
000076049b1dd013  vmovaps [rsp+0xA0], xmm11
000076049b1dd01c  vmovaps [rsp+0xB0], xmm12
000076049b1dd025  vmovaps [rsp+0xC0], xmm13
000076049b1dd02e  vmovaps [rsp+0xD0], xmm14
000076049b1dd037  vmovaps [rsp+0xE0], xmm15
000076049b1dd040  sub rsp, 0x30
000076049b1dd044  movaps [rsp], xmm3
000076049b1dd048  movaps [rsp+0x10], xmm5
000076049b1dd04d  movaps [rsp+0x20], xmm4
000076049b1dd052  lea rdi, [rsp]
000076049b1dd056  mov esi, 0x00
000076049b1dd05b  mov rax, 0x64C06813C530
000076049b1dd065  call rax
000076049b1dd067  movaps xmm3, [rsp]
000076049b1dd06b  add rsp, 0x30
000076049b1dd06f  vmovaps xmm0, [rsp]
000076049b1dd074  vmovaps xmm1, [rsp+0x10]
000076049b1dd07a  vmovaps xmm2, [rsp+0x20]
000076049b1dd080  vmovaps xmm4, [rsp+0x30]
000076049b1dd086  vmovaps xmm5, [rsp+0x40]
000076049b1dd08c  vmovaps xmm6, [rsp+0x50]
000076049b1dd092  vmovaps xmm7, [rsp+0x60]
000076049b1dd098  vmovaps xmm8, [rsp+0x70]
000076049b1dd09e  vmovaps xmm9, [rsp+0x80]
000076049b1dd0a7  vmovaps xmm10, [rsp+0x90]
000076049b1dd0b0  vmovaps xmm11, [rsp+0xA0]
000076049b1dd0b9  vmovaps xmm12, [rsp+0xB0]
000076049b1dd0c2  vmovaps xmm13, [rsp+0xC0]
000076049b1dd0cb  vmovaps xmm14, [rsp+0xD0]
000076049b1dd0d4  vmovaps xmm15, [rsp+0xE0]
000076049b1dd0dd  add rsp, 0xF0
000076049b1dd0e4  pop r11
000076049b1dd0e6  pop r10
000076049b1dd0e8  pop r9
000076049b1dd0ea  pop r8
000076049b1dd0ec  pop rsi
000076049b1dd0ed  pop rdi
000076049b1dd0ee  pop rdx
000076049b1dd0ef  pop rcx
000076049b1dd0f0  pop rax
000076049b1dd0f1  add rsp, 0x08
000076049b1dd0f5  jmp 0x000076049B1DBC35
000076049b1dd0fa  sub rsp, 0x08
000076049b1dd0fe  push rax
000076049b1dd0ff  push rcx
000076049b1dd100  push rdx
000076049b1dd101  push rdi
000076049b1dd102  push rsi
000076049b1dd103  push r8
000076049b1dd105  push r9
000076049b1dd107  push r10
000076049b1dd109  push r11
000076049b1dd10b  sub rsp, 0xF0
000076049b1dd112  vmovaps [rsp], xmm0
000076049b1dd117  vmovaps [rsp+0x10], xmm1
000076049b1dd11d  vmovaps [rsp+0x20], xmm2
000076049b1dd123  vmovaps [rsp+0x30], xmm3
000076049b1dd129  vmovaps [rsp+0x40], xmm4
000076049b1dd12f  vmovaps [rsp+0x50], xmm6
000076049b1dd135  vmovaps [rsp+0x60], xmm7
000076049b1dd13b  vmovaps [rsp+0x70], xmm8
000076049b1dd141  vmovaps [rsp+0x80], xmm9
000076049b1dd14a  vmovaps [rsp+0x90], xmm10
000076049b1dd153  vmovaps [rsp+0xA0], xmm11
000076049b1dd15c  vmovaps [rsp+0xB0], xmm12
000076049b1dd165  vmovaps [rsp+0xC0], xmm13
000076049b1dd16e  vmovaps [rsp+0xD0], xmm14
000076049b1dd177  vmovaps [rsp+0xE0], xmm15
000076049b1dd180  sub rsp, 0x30
000076049b1dd184  movaps [rsp], xmm5
000076049b1dd188  movaps [rsp+0x10], xmm8
000076049b1dd18e  movaps [rsp+0x20], xmm15
000076049b1dd194  lea rdi, [rsp]
000076049b1dd198  mov esi, 0x00
000076049b1dd19d  mov rax, 0x64C06813C530
000076049b1dd1a7  call rax
000076049b1dd1a9  movaps xmm5, [rsp]
000076049b1dd1ad  add rsp, 0x30
000076049b1dd1b1  vmovaps xmm0, [rsp]
000076049b1dd1b6  vmovaps xmm1, [rsp+0x10]
000076049b1dd1bc  vmovaps xmm2, [rsp+0x20]
000076049b1dd1c2  vmovaps xmm3, [rsp+0x30]
000076049b1dd1c8  vmovaps xmm4, [rsp+0x40]
000076049b1dd1ce  vmovaps xmm6, [rsp+0x50]
000076049b1dd1d4  vmovaps xmm7, [rsp+0x60]
000076049b1dd1da  vmovaps xmm8, [rsp+0x70]
000076049b1dd1e0  vmovaps xmm9, [rsp+0x80]
000076049b1dd1e9  vmovaps xmm10, [rsp+0x90]
000076049b1dd1f2  vmovaps xmm11, [rsp+0xA0]
000076049b1dd1fb  vmovaps xmm12, [rsp+0xB0]
000076049b1dd204  vmovaps xmm13, [rsp+0xC0]
000076049b1dd20d  vmovaps xmm14, [rsp+0xD0]
000076049b1dd216  vmovaps xmm15, [rsp+0xE0]
000076049b1dd21f  add rsp, 0xF0
000076049b1dd226  pop r11
000076049b1dd228  pop r10
000076049b1dd22a  pop r9
000076049b1dd22c  pop r8
000076049b1dd22e  pop rsi
000076049b1dd22f  pop rdi
000076049b1dd230  pop rdx
000076049b1dd231  pop rcx
000076049b1dd232  pop rax
000076049b1dd233  add rsp, 0x08
000076049b1dd237  jmp 0x000076049B1DBC73
000076049b1dd23c  sub rsp, 0x08
000076049b1dd240  push rax
000076049b1dd241  push rcx
000076049b1dd242  push rdx
000076049b1dd243  push rdi
000076049b1dd244  push rsi
000076049b1dd245  push r8
000076049b1dd247  push r9
000076049b1dd249  push r10
000076049b1dd24b  push r11
000076049b1dd24d  sub rsp, 0xF0
000076049b1dd254  vmovaps [rsp], xmm0
000076049b1dd259  vmovaps [rsp+0x10], xmm1
000076049b1dd25f  vmovaps [rsp+0x20], xmm2
000076049b1dd265  vmovaps [rsp+0x30], xmm3
000076049b1dd26b  vmovaps [rsp+0x40], xmm5
000076049b1dd271  vmovaps [rsp+0x50], xmm6
000076049b1dd277  vmovaps [rsp+0x60], xmm7
000076049b1dd27d  vmovaps [rsp+0x70], xmm8
000076049b1dd283  vmovaps [rsp+0x80], xmm9
000076049b1dd28c  vmovaps [rsp+0x90], xmm10
000076049b1dd295  vmovaps [rsp+0xA0], xmm11
000076049b1dd29e  vmovaps [rsp+0xB0], xmm12
000076049b1dd2a7  vmovaps [rsp+0xC0], xmm13
000076049b1dd2b0  vmovaps [rsp+0xD0], xmm14
000076049b1dd2b9  vmovaps [rsp+0xE0], xmm15
000076049b1dd2c2  sub rsp, 0x30
000076049b1dd2c6  movaps [rsp], xmm4
000076049b1dd2ca  movaps [rsp+0x10], xmm9
000076049b1dd2d0  movaps [rsp+0x20], xmm8
000076049b1dd2d6  lea rdi, [rsp]
000076049b1dd2da  mov esi, 0x00
000076049b1dd2df  mov rax, 0x64C06813C530
000076049b1dd2e9  call rax
000076049b1dd2eb  movaps xmm4, [rsp]
000076049b1dd2ef  add rsp, 0x30
000076049b1dd2f3  vmovaps xmm0, [rsp]
000076049b1dd2f8  vmovaps xmm1, [rsp+0x10]
000076049b1dd2fe  vmovaps xmm2, [rsp+0x20]
000076049b1dd304  vmovaps xmm3, [rsp+0x30]
000076049b1dd30a  vmovaps xmm5, [rsp+0x40]
000076049b1dd310  vmovaps xmm6, [rsp+0x50]
000076049b1dd316  vmovaps xmm7, [rsp+0x60]
000076049b1dd31c  vmovaps xmm8, [rsp+0x70]
000076049b1dd322  vmovaps xmm9, [rsp+0x80]
000076049b1dd32b  vmovaps xmm10, [rsp+0x90]
000076049b1dd334  vmovaps xmm11, [rsp+0xA0]
000076049b1dd33d  vmovaps xmm12, [rsp+0xB0]
000076049b1dd346  vmovaps xmm13, [rsp+0xC0]
000076049b1dd34f  vmovaps xmm14, [rsp+0xD0]
000076049b1dd358  vmovaps xmm15, [rsp+0xE0]
000076049b1dd361  add rsp, 0xF0
000076049b1dd368  pop r11
000076049b1dd36a  pop r10
000076049b1dd36c  pop r9
000076049b1dd36e  pop r8
000076049b1dd370  pop rsi
000076049b1dd371  pop rdi
000076049b1dd372  pop rdx
000076049b1dd373  pop rcx
000076049b1dd374  pop rax
000076049b1dd375  add rsp, 0x08
000076049b1dd379  jmp 0x000076049B1DBC94
000076049b1dd37e  sub rsp, 0x08
000076049b1dd382  push rax
000076049b1dd383  push rcx
000076049b1dd384  push rdx
000076049b1dd385  push rdi
000076049b1dd386  push rsi
000076049b1dd387  push r8
000076049b1dd389  push r9
000076049b1dd38b  push r10
000076049b1dd38d  push r11
000076049b1dd38f  sub rsp, 0xF0
000076049b1dd396  vmovaps [rsp], xmm0
000076049b1dd39b  vmovaps [rsp+0x10], xmm1
000076049b1dd3a1  vmovaps [rsp+0x20], xmm2
000076049b1dd3a7  vmovaps [rsp+0x30], xmm3
000076049b1dd3ad  vmovaps [rsp+0x40], xmm4
000076049b1dd3b3  vmovaps [rsp+0x50], xmm5
000076049b1dd3b9  vmovaps [rsp+0x60], xmm6
000076049b1dd3bf  vmovaps [rsp+0x70], xmm7
000076049b1dd3c5  vmovaps [rsp+0x80], xmm8
000076049b1dd3ce  vmovaps [rsp+0x90], xmm10
000076049b1dd3d7  vmovaps [rsp+0xA0], xmm11
000076049b1dd3e0  vmovaps [rsp+0xB0], xmm12
000076049b1dd3e9  vmovaps [rsp+0xC0], xmm13
000076049b1dd3f2  vmovaps [rsp+0xD0], xmm14
000076049b1dd3fb  vmovaps [rsp+0xE0], xmm15
000076049b1dd404  sub rsp, 0x30
000076049b1dd408  movaps [rsp], xmm9
000076049b1dd40d  movaps [rsp+0x10], xmm10
000076049b1dd413  movaps [rsp+0x20], xmm8
000076049b1dd419  lea rdi, [rsp]
000076049b1dd41d  mov esi, 0x00
000076049b1dd422  mov rax, 0x64C06813C530
000076049b1dd42c  call rax
000076049b1dd42e  movaps xmm9, [rsp]
000076049b1dd433  add rsp, 0x30
000076049b1dd437  vmovaps xmm0, [rsp]
000076049b1dd43c  vmovaps xmm1, [rsp+0x10]
000076049b1dd442  vmovaps xmm2, [rsp+0x20]
000076049b1dd448  vmovaps xmm3, [rsp+0x30]
000076049b1dd44e  vmovaps xmm4, [rsp+0x40]
000076049b1dd454  vmovaps xmm5, [rsp+0x50]
000076049b1dd45a  vmovaps xmm6, [rsp+0x60]
000076049b1dd460  vmovaps xmm7, [rsp+0x70]
000076049b1dd466  vmovaps xmm8, [rsp+0x80]
000076049b1dd46f  vmovaps xmm10, [rsp+0x90]
000076049b1dd478  vmovaps xmm11, [rsp+0xA0]
000076049b1dd481  vmovaps xmm12, [rsp+0xB0]
000076049b1dd48a  vmovaps xmm13, [rsp+0xC0]
000076049b1dd493  vmovaps xmm14, [rsp+0xD0]
000076049b1dd49c  vmovaps xmm15, [rsp+0xE0]
000076049b1dd4a5  add rsp, 0xF0
000076049b1dd4ac  pop r11
000076049b1dd4ae  pop r10
000076049b1dd4b0  pop r9
000076049b1dd4b2  pop r8
000076049b1dd4b4  pop rsi
000076049b1dd4b5  pop rdi
000076049b1dd4b6  pop rdx
000076049b1dd4b7  pop rcx
000076049b1dd4b8  pop rax
000076049b1dd4b9  add rsp, 0x08
000076049b1dd4bd  jmp 0x000076049B1DBCAE
000076049b1dd4c2  call 0x000076049B0B52F0
000076049b1dd4c7  jmp 0x000076049B1DBDC8
000076049b1dd4cc  call 0x000076049B0B52F0
000076049b1dd4d1  jmp 0x000076049B1DBDDE
000076049b1dd4d6  sub rsp, 0x08
000076049b1dd4da  push rax
000076049b1dd4db  push rcx
000076049b1dd4dc  push rdx
000076049b1dd4dd  push rdi
000076049b1dd4de  push rsi
000076049b1dd4df  push r8
000076049b1dd4e1  push r9
000076049b1dd4e3  push r10
000076049b1dd4e5  push r11
000076049b1dd4e7  sub rsp, 0xF0
000076049b1dd4ee  vmovaps [rsp], xmm0
000076049b1dd4f3  vmovaps [rsp+0x10], xmm2
000076049b1dd4f9  vmovaps [rsp+0x20], xmm3
000076049b1dd4ff  vmovaps [rsp+0x30], xmm4
000076049b1dd505  vmovaps [rsp+0x40], xmm5
000076049b1dd50b  vmovaps [rsp+0x50], xmm6
000076049b1dd511  vmovaps [rsp+0x60], xmm7
000076049b1dd517  vmovaps [rsp+0x70], xmm8
000076049b1dd51d  vmovaps [rsp+0x80], xmm9
000076049b1dd526  vmovaps [rsp+0x90], xmm10
000076049b1dd52f  vmovaps [rsp+0xA0], xmm11
000076049b1dd538  vmovaps [rsp+0xB0], xmm12
000076049b1dd541  vmovaps [rsp+0xC0], xmm13
000076049b1dd54a  vmovaps [rsp+0xD0], xmm14
000076049b1dd553  vmovaps [rsp+0xE0], xmm15
000076049b1dd55c  sub rsp, 0x30
000076049b1dd560  movaps [rsp], xmm1
000076049b1dd564  movaps [rsp+0x10], xmm6
000076049b1dd569  movaps [rsp+0x20], xmm15
000076049b1dd56f  lea rdi, [rsp]
000076049b1dd573  mov esi, 0x00
000076049b1dd578  mov rax, 0x64C06813C530
000076049b1dd582  call rax
000076049b1dd584  movaps xmm1, [rsp]
000076049b1dd588  add rsp, 0x30
000076049b1dd58c  vmovaps xmm0, [rsp]
000076049b1dd591  vmovaps xmm2, [rsp+0x10]
000076049b1dd597  vmovaps xmm3, [rsp+0x20]
000076049b1dd59d  vmovaps xmm4, [rsp+0x30]
000076049b1dd5a3  vmovaps xmm5, [rsp+0x40]
000076049b1dd5a9  vmovaps xmm6, [rsp+0x50]
000076049b1dd5af  vmovaps xmm7, [rsp+0x60]
000076049b1dd5b5  vmovaps xmm8, [rsp+0x70]
000076049b1dd5bb  vmovaps xmm9, [rsp+0x80]
000076049b1dd5c4  vmovaps xmm10, [rsp+0x90]
000076049b1dd5cd  vmovaps xmm11, [rsp+0xA0]
000076049b1dd5d6  vmovaps xmm12, [rsp+0xB0]
000076049b1dd5df  vmovaps xmm13, [rsp+0xC0]
000076049b1dd5e8  vmovaps xmm14, [rsp+0xD0]
000076049b1dd5f1  vmovaps xmm15, [rsp+0xE0]
000076049b1dd5fa  add rsp, 0xF0
000076049b1dd601  pop r11
000076049b1dd603  pop r10
000076049b1dd605  pop r9
000076049b1dd607  pop r8
000076049b1dd609  pop rsi
000076049b1dd60a  pop rdi
000076049b1dd60b  pop rdx
000076049b1dd60c  pop rcx
000076049b1dd60d  pop rax
000076049b1dd60e  add rsp, 0x08
000076049b1dd612  jmp 0x000076049B1DBE1B
000076049b1dd617  call 0x000076049B0C4620
000076049b1dd61c  jmp 0x000076049B1DBE28
000076049b1dd621  sub rsp, 0x08
000076049b1dd625  push rax
000076049b1dd626  push rcx
000076049b1dd627  push rdx
000076049b1dd628  push rdi
000076049b1dd629  push rsi
000076049b1dd62a  push r8
000076049b1dd62c  push r9
000076049b1dd62e  push r10
000076049b1dd630  push r11
000076049b1dd632  sub rsp, 0xF0
000076049b1dd639  vmovaps [rsp], xmm0
000076049b1dd63e  vmovaps [rsp+0x10], xmm1
000076049b1dd644  vmovaps [rsp+0x20], xmm2
000076049b1dd64a  vmovaps [rsp+0x30], xmm3
000076049b1dd650  vmovaps [rsp+0x40], xmm4
000076049b1dd656  vmovaps [rsp+0x50], xmm5
000076049b1dd65c  vmovaps [rsp+0x60], xmm6
000076049b1dd662  vmovaps [rsp+0x70], xmm7
000076049b1dd668  vmovaps [rsp+0x80], xmm8
000076049b1dd671  vmovaps [rsp+0x90], xmm9
000076049b1dd67a  vmovaps [rsp+0xA0], xmm10
000076049b1dd683  vmovaps [rsp+0xB0], xmm11
000076049b1dd68c  vmovaps [rsp+0xC0], xmm12
000076049b1dd695  vmovaps [rsp+0xD0], xmm13
000076049b1dd69e  vmovaps [rsp+0xE0], xmm15
000076049b1dd6a7  sub rsp, 0x30
000076049b1dd6ab  movaps [rsp], xmm14
000076049b1dd6b0  movaps [rsp+0x10], xmm4
000076049b1dd6b5  movaps [rsp+0x20], xmm3
000076049b1dd6ba  lea rdi, [rsp]
000076049b1dd6be  mov esi, 0x00
000076049b1dd6c3  mov rax, 0x64C06813C530
000076049b1dd6cd  call rax
000076049b1dd6cf  movaps xmm14, [rsp]
000076049b1dd6d4  add rsp, 0x30
000076049b1dd6d8  vmovaps xmm0, [rsp]
000076049b1dd6dd  vmovaps xmm1, [rsp+0x10]
000076049b1dd6e3  vmovaps xmm2, [rsp+0x20]
000076049b1dd6e9  vmovaps xmm3, [rsp+0x30]
000076049b1dd6ef  vmovaps xmm4, [rsp+0x40]
000076049b1dd6f5  vmovaps xmm5, [rsp+0x50]
000076049b1dd6fb  vmovaps xmm6, [rsp+0x60]
000076049b1dd701  vmovaps xmm7, [rsp+0x70]
000076049b1dd707  vmovaps xmm8, [rsp+0x80]
000076049b1dd710  vmovaps xmm9, [rsp+0x90]
000076049b1dd719  vmovaps xmm10, [rsp+0xA0]
000076049b1dd722  vmovaps xmm11, [rsp+0xB0]
000076049b1dd72b  vmovaps xmm12, [rsp+0xC0]
000076049b1dd734  vmovaps xmm13, [rsp+0xD0]
000076049b1dd73d  vmovaps xmm15, [rsp+0xE0]
000076049b1dd746  add rsp, 0xF0
000076049b1dd74d  pop r11
000076049b1dd74f  pop r10
000076049b1dd751  pop r9
000076049b1dd753  pop r8
000076049b1dd755  pop rsi
000076049b1dd756  pop rdi
000076049b1dd757  pop rdx
000076049b1dd758  pop rcx
000076049b1dd759  pop rax
000076049b1dd75a  add rsp, 0x08
000076049b1dd75e  jmp 0x000076049B1DBE42
000076049b1dd763  sub rsp, 0x08
000076049b1dd767  push rax
000076049b1dd768  push rcx
000076049b1dd769  push rdx
000076049b1dd76a  push rdi
000076049b1dd76b  push rsi
000076049b1dd76c  push r8
000076049b1dd76e  push r9
000076049b1dd770  push r10
000076049b1dd772  push r11
000076049b1dd774  sub rsp, 0xF0
000076049b1dd77b  vmovaps [rsp], xmm0
000076049b1dd780  vmovaps [rsp+0x10], xmm1
000076049b1dd786  vmovaps [rsp+0x20], xmm2
000076049b1dd78c  vmovaps [rsp+0x30], xmm3
000076049b1dd792  vmovaps [rsp+0x40], xmm4
000076049b1dd798  vmovaps [rsp+0x50], xmm5
000076049b1dd79e  vmovaps [rsp+0x60], xmm7
000076049b1dd7a4  vmovaps [rsp+0x70], xmm8
000076049b1dd7aa  vmovaps [rsp+0x80], xmm9
000076049b1dd7b3  vmovaps [rsp+0x90], xmm10
000076049b1dd7bc  vmovaps [rsp+0xA0], xmm11
000076049b1dd7c5  vmovaps [rsp+0xB0], xmm12
000076049b1dd7ce  vmovaps [rsp+0xC0], xmm13
000076049b1dd7d7  vmovaps [rsp+0xD0], xmm14
000076049b1dd7e0  vmovaps [rsp+0xE0], xmm15
000076049b1dd7e9  sub rsp, 0x30
000076049b1dd7ed  movaps [rsp], xmm6
000076049b1dd7f1  movaps [rsp+0x10], xmm9
000076049b1dd7f7  movaps [rsp+0x20], xmm7
000076049b1dd7fc  lea rdi, [rsp]
000076049b1dd800  mov esi, 0x00
000076049b1dd805  mov rax, 0x64C06813C530
000076049b1dd80f  call rax
000076049b1dd811  movaps xmm6, [rsp]
000076049b1dd815  add rsp, 0x30
000076049b1dd819  vmovaps xmm0, [rsp]
000076049b1dd81e  vmovaps xmm1, [rsp+0x10]
000076049b1dd824  vmovaps xmm2, [rsp+0x20]
000076049b1dd82a  vmovaps xmm3, [rsp+0x30]
000076049b1dd830  vmovaps xmm4, [rsp+0x40]
000076049b1dd836  vmovaps xmm5, [rsp+0x50]
000076049b1dd83c  vmovaps xmm7, [rsp+0x60]
000076049b1dd842  vmovaps xmm8, [rsp+0x70]
000076049b1dd848  vmovaps xmm9, [rsp+0x80]
000076049b1dd851  vmovaps xmm10, [rsp+0x90]
000076049b1dd85a  vmovaps xmm11, [rsp+0xA0]
000076049b1dd863  vmovaps xmm12, [rsp+0xB0]
000076049b1dd86c  vmovaps xmm13, [rsp+0xC0]
000076049b1dd875  vmovaps xmm14, [rsp+0xD0]
000076049b1dd87e  vmovaps xmm15, [rsp+0xE0]
000076049b1dd887  add rsp, 0xF0
000076049b1dd88e  pop r11
000076049b1dd890  pop r10
000076049b1dd892  pop r9
000076049b1dd894  pop r8
000076049b1dd896  pop rsi
000076049b1dd897  pop rdi
000076049b1dd898  pop rdx
000076049b1dd899  pop rcx
000076049b1dd89a  pop rax
000076049b1dd89b  add rsp, 0x08
000076049b1dd89f  jmp 0x000076049B1DBE5A
000076049b1dd8a4  sub rsp, 0x08
000076049b1dd8a8  push rax
000076049b1dd8a9  push rcx
000076049b1dd8aa  push rdx
000076049b1dd8ab  push rdi
000076049b1dd8ac  push rsi
000076049b1dd8ad  push r8
000076049b1dd8af  push r9
000076049b1dd8b1  push r10
000076049b1dd8b3  push r11
000076049b1dd8b5  sub rsp, 0xF0
000076049b1dd8bc  vmovaps [rsp], xmm0
000076049b1dd8c1  vmovaps [rsp+0x10], xmm1
000076049b1dd8c7  vmovaps [rsp+0x20], xmm2
000076049b1dd8cd  vmovaps [rsp+0x30], xmm3
000076049b1dd8d3  vmovaps [rsp+0x40], xmm4
000076049b1dd8d9  vmovaps [rsp+0x50], xmm5
000076049b1dd8df  vmovaps [rsp+0x60], xmm6
000076049b1dd8e5  vmovaps [rsp+0x70], xmm8
000076049b1dd8eb  vmovaps [rsp+0x80], xmm9
000076049b1dd8f4  vmovaps [rsp+0x90], xmm10
000076049b1dd8fd  vmovaps [rsp+0xA0], xmm11
000076049b1dd906  vmovaps [rsp+0xB0], xmm12
000076049b1dd90f  vmovaps [rsp+0xC0], xmm13
000076049b1dd918  vmovaps [rsp+0xD0], xmm14
000076049b1dd921  vmovaps [rsp+0xE0], xmm15
000076049b1dd92a  sub rsp, 0x30
000076049b1dd92e  movaps [rsp], xmm7
000076049b1dd932  movaps [rsp+0x10], xmm4
000076049b1dd937  movaps [rsp+0x20], xmm9
000076049b1dd93d  lea rdi, [rsp]
000076049b1dd941  mov esi, 0x00
000076049b1dd946  mov rax, 0x64C06813C530
000076049b1dd950  call rax
000076049b1dd952  movaps xmm7, [rsp]
000076049b1dd956  add rsp, 0x30
000076049b1dd95a  vmovaps xmm0, [rsp]
000076049b1dd95f  vmovaps xmm1, [rsp+0x10]
000076049b1dd965  vmovaps xmm2, [rsp+0x20]
000076049b1dd96b  vmovaps xmm3, [rsp+0x30]
000076049b1dd971  vmovaps xmm4, [rsp+0x40]
000076049b1dd977  vmovaps xmm5, [rsp+0x50]
000076049b1dd97d  vmovaps xmm6, [rsp+0x60]
000076049b1dd983  vmovaps xmm8, [rsp+0x70]
000076049b1dd989  vmovaps xmm9, [rsp+0x80]
000076049b1dd992  vmovaps xmm10, [rsp+0x90]
000076049b1dd99b  vmovaps xmm11, [rsp+0xA0]
000076049b1dd9a4  vmovaps xmm12, [rsp+0xB0]
000076049b1dd9ad  vmovaps xmm13, [rsp+0xC0]
000076049b1dd9b6  vmovaps xmm14, [rsp+0xD0]
000076049b1dd9bf  vmovaps xmm15, [rsp+0xE0]
000076049b1dd9c8  add rsp, 0xF0
000076049b1dd9cf  pop r11
000076049b1dd9d1  pop r10
000076049b1dd9d3  pop r9
000076049b1dd9d5  pop r8
000076049b1dd9d7  pop rsi
000076049b1dd9d8  pop rdi
000076049b1dd9d9  pop rdx
000076049b1dd9da  pop rcx
000076049b1dd9db  pop rax
000076049b1dd9dc  add rsp, 0x08
000076049b1dd9e0  jmp 0x000076049B1DBE87
000076049b1dd9e5  sub rsp, 0x08
000076049b1dd9e9  push rax
000076049b1dd9ea  push rcx
000076049b1dd9eb  push rdx
000076049b1dd9ec  push rdi
000076049b1dd9ed  push rsi
000076049b1dd9ee  push r8
000076049b1dd9f0  push r9
000076049b1dd9f2  push r10
000076049b1dd9f4  push r11
000076049b1dd9f6  sub rsp, 0xF0
000076049b1dd9fd  vmovaps [rsp], xmm0
000076049b1dda02  vmovaps [rsp+0x10], xmm1
000076049b1dda08  vmovaps [rsp+0x20], xmm2
000076049b1dda0e  vmovaps [rsp+0x30], xmm3
000076049b1dda14  vmovaps [rsp+0x40], xmm5
000076049b1dda1a  vmovaps [rsp+0x50], xmm6
000076049b1dda20  vmovaps [rsp+0x60], xmm7
000076049b1dda26  vmovaps [rsp+0x70], xmm8
000076049b1dda2c  vmovaps [rsp+0x80], xmm9
000076049b1dda35  vmovaps [rsp+0x90], xmm10
000076049b1dda3e  vmovaps [rsp+0xA0], xmm11
000076049b1dda47  vmovaps [rsp+0xB0], xmm12
000076049b1dda50  vmovaps [rsp+0xC0], xmm13
000076049b1dda59  vmovaps [rsp+0xD0], xmm14
000076049b1dda62  vmovaps [rsp+0xE0], xmm15
000076049b1dda6b  sub rsp, 0x30
000076049b1dda6f  movaps [rsp], xmm4
000076049b1dda73  movaps [rsp+0x10], xmm15
000076049b1dda79  movaps [rsp+0x20], xmm9
000076049b1dda7f  lea rdi, [rsp]
000076049b1dda83  mov esi, 0x00
000076049b1dda88  mov rax, 0x64C06813C530
000076049b1dda92  call rax
000076049b1dda94  movaps xmm4, [rsp]
000076049b1dda98  add rsp, 0x30
000076049b1dda9c  vmovaps xmm0, [rsp]
000076049b1ddaa1  vmovaps xmm1, [rsp+0x10]
000076049b1ddaa7  vmovaps xmm2, [rsp+0x20]
000076049b1ddaad  vmovaps xmm3, [rsp+0x30]
000076049b1ddab3  vmovaps xmm5, [rsp+0x40]
000076049b1ddab9  vmovaps xmm6, [rsp+0x50]
000076049b1ddabf  vmovaps xmm7, [rsp+0x60]
000076049b1ddac5  vmovaps xmm8, [rsp+0x70]
000076049b1ddacb  vmovaps xmm9, [rsp+0x80]
000076049b1ddad4  vmovaps xmm10, [rsp+0x90]
000076049b1ddadd  vmovaps xmm11, [rsp+0xA0]
000076049b1ddae6  vmovaps xmm12, [rsp+0xB0]
000076049b1ddaef  vmovaps xmm13, [rsp+0xC0]
000076049b1ddaf8  vmovaps xmm14, [rsp+0xD0]
000076049b1ddb01  vmovaps xmm15, [rsp+0xE0]
000076049b1ddb0a  add rsp, 0xF0
000076049b1ddb11  pop r11
000076049b1ddb13  pop r10
000076049b1ddb15  pop r9
000076049b1ddb17  pop r8
000076049b1ddb19  pop rsi
000076049b1ddb1a  pop rdi
000076049b1ddb1b  pop rdx
000076049b1ddb1c  pop rcx
000076049b1ddb1d  pop rax
000076049b1ddb1e  add rsp, 0x08
000076049b1ddb22  jmp 0x000076049B1DBEAC
000076049b1ddb27  call 0x000076049B0C4620
000076049b1ddb2c  jmp 0x000076049B1DBEB9
000076049b1ddb31  sub rsp, 0x08
000076049b1ddb35  push rax
000076049b1ddb36  push rcx
000076049b1ddb37  push rdx
000076049b1ddb38  push rdi
000076049b1ddb39  push rsi
000076049b1ddb3a  push r8
000076049b1ddb3c  push r9
000076049b1ddb3e  push r10
000076049b1ddb40  push r11
000076049b1ddb42  sub rsp, 0xF0
000076049b1ddb49  vmovaps [rsp], xmm0
000076049b1ddb4e  vmovaps [rsp+0x10], xmm1
000076049b1ddb54  vmovaps [rsp+0x20], xmm2
000076049b1ddb5a  vmovaps [rsp+0x30], xmm4
000076049b1ddb60  vmovaps [rsp+0x40], xmm5
000076049b1ddb66  vmovaps [rsp+0x50], xmm6
000076049b1ddb6c  vmovaps [rsp+0x60], xmm7
000076049b1ddb72  vmovaps [rsp+0x70], xmm8
000076049b1ddb78  vmovaps [rsp+0x80], xmm9
000076049b1ddb81  vmovaps [rsp+0x90], xmm10
000076049b1ddb8a  vmovaps [rsp+0xA0], xmm11
000076049b1ddb93  vmovaps [rsp+0xB0], xmm12
000076049b1ddb9c  vmovaps [rsp+0xC0], xmm13
000076049b1ddba5  vmovaps [rsp+0xD0], xmm14
000076049b1ddbae  vmovaps [rsp+0xE0], xmm15
000076049b1ddbb7  sub rsp, 0x30
000076049b1ddbbb  movaps [rsp], xmm3
000076049b1ddbbf  movaps [rsp+0x10], xmm1
000076049b1ddbc4  movaps [rsp+0x20], xmm9
000076049b1ddbca  lea rdi, [rsp]
000076049b1ddbce  mov esi, 0x00
000076049b1ddbd3  mov rax, 0x64C06813C530
000076049b1ddbdd  call rax
000076049b1ddbdf  movaps xmm3, [rsp]
000076049b1ddbe3  add rsp, 0x30
000076049b1ddbe7  vmovaps xmm0, [rsp]
000076049b1ddbec  vmovaps xmm1, [rsp+0x10]
000076049b1ddbf2  vmovaps xmm2, [rsp+0x20]
000076049b1ddbf8  vmovaps xmm4, [rsp+0x30]
000076049b1ddbfe  vmovaps xmm5, [rsp+0x40]
000076049b1ddc04  vmovaps xmm6, [rsp+0x50]
000076049b1ddc0a  vmovaps xmm7, [rsp+0x60]
000076049b1ddc10  vmovaps xmm8, [rsp+0x70]
000076049b1ddc16  vmovaps xmm9, [rsp+0x80]
000076049b1ddc1f  vmovaps xmm10, [rsp+0x90]
000076049b1ddc28  vmovaps xmm11, [rsp+0xA0]
000076049b1ddc31  vmovaps xmm12, [rsp+0xB0]
000076049b1ddc3a  vmovaps xmm13, [rsp+0xC0]
000076049b1ddc43  vmovaps xmm14, [rsp+0xD0]
000076049b1ddc4c  vmovaps xmm15, [rsp+0xE0]
000076049b1ddc55  add rsp, 0xF0
000076049b1ddc5c  pop r11
000076049b1ddc5e  pop r10
000076049b1ddc60  pop r9
000076049b1ddc62  pop r8
000076049b1ddc64  pop rsi
000076049b1ddc65  pop rdi
000076049b1ddc66  pop rdx
000076049b1ddc67  pop rcx
000076049b1ddc68  pop rax
000076049b1ddc69  add rsp, 0x08
000076049b1ddc6d  jmp 0x000076049B1DBEF6
000076049b1ddc72  sub rsp, 0x08
000076049b1ddc76  push rax
000076049b1ddc77  push rcx
000076049b1ddc78  push rdx
000076049b1ddc79  push rdi
000076049b1ddc7a  push rsi
000076049b1ddc7b  push r8
000076049b1ddc7d  push r9
000076049b1ddc7f  push r10
000076049b1ddc81  push r11
000076049b1ddc83  sub rsp, 0xF0
000076049b1ddc8a  vmovaps [rsp], xmm0
000076049b1ddc8f  vmovaps [rsp+0x10], xmm2
000076049b1ddc95  vmovaps [rsp+0x20], xmm3
000076049b1ddc9b  vmovaps [rsp+0x30], xmm4
000076049b1ddca1  vmovaps [rsp+0x40], xmm5
000076049b1ddca7  vmovaps [rsp+0x50], xmm6
000076049b1ddcad  vmovaps [rsp+0x60], xmm7
000076049b1ddcb3  vmovaps [rsp+0x70], xmm8
000076049b1ddcb9  vmovaps [rsp+0x80], xmm9
000076049b1ddcc2  vmovaps [rsp+0x90], xmm10
000076049b1ddccb  vmovaps [rsp+0xA0], xmm11
000076049b1ddcd4  vmovaps [rsp+0xB0], xmm12
000076049b1ddcdd  vmovaps [rsp+0xC0], xmm13
000076049b1ddce6  vmovaps [rsp+0xD0], xmm14
000076049b1ddcef  vmovaps [rsp+0xE0], xmm15
000076049b1ddcf8  sub rsp, 0x30
000076049b1ddcfc  movaps [rsp], xmm1
000076049b1ddd00  movaps [rsp+0x10], xmm15
000076049b1ddd06  movaps [rsp+0x20], xmm9
000076049b1ddd0c  lea rdi, [rsp]
000076049b1ddd10  mov esi, 0x00
000076049b1ddd15  mov rax, 0x64C06813C530
000076049b1ddd1f  call rax
000076049b1ddd21  movaps xmm1, [rsp]
000076049b1ddd25  add rsp, 0x30
000076049b1ddd29  vmovaps xmm0, [rsp]
000076049b1ddd2e  vmovaps xmm2, [rsp+0x10]
000076049b1ddd34  vmovaps xmm3, [rsp+0x20]
000076049b1ddd3a  vmovaps xmm4, [rsp+0x30]
000076049b1ddd40  vmovaps xmm5, [rsp+0x40]
000076049b1ddd46  vmovaps xmm6, [rsp+0x50]
000076049b1ddd4c  vmovaps xmm7, [rsp+0x60]
000076049b1ddd52  vmovaps xmm8, [rsp+0x70]
000076049b1ddd58  vmovaps xmm9, [rsp+0x80]
000076049b1ddd61  vmovaps xmm10, [rsp+0x90]
000076049b1ddd6a  vmovaps xmm11, [rsp+0xA0]
000076049b1ddd73  vmovaps xmm12, [rsp+0xB0]
000076049b1ddd7c  vmovaps xmm13, [rsp+0xC0]
000076049b1ddd85  vmovaps xmm14, [rsp+0xD0]
000076049b1ddd8e  vmovaps xmm15, [rsp+0xE0]
000076049b1ddd97  add rsp, 0xF0
000076049b1ddd9e  pop r11
000076049b1ddda0  pop r10
000076049b1ddda2  pop r9
000076049b1ddda4  pop r8
000076049b1ddda6  pop rsi
000076049b1ddda7  pop rdi
000076049b1ddda8  pop rdx
000076049b1ddda9  pop rcx
000076049b1dddaa  pop rax
000076049b1dddab  add rsp, 0x08
000076049b1dddaf  jmp 0x000076049B1DBF7E
000076049b1dddb4  call 0x000076049B0C4620
000076049b1dddb9  jmp 0x000076049B1DBF8B
000076049b1dddbe  sub rsp, 0x08
000076049b1dddc2  push rax
000076049b1dddc3  push rcx
000076049b1dddc4  push rdx
000076049b1dddc5  push rdi
000076049b1dddc6  push rsi
000076049b1dddc7  push r8
000076049b1dddc9  push r9
000076049b1dddcb  push r10
000076049b1dddcd  push r11
000076049b1dddcf  sub rsp, 0xF0
000076049b1dddd6  vmovaps [rsp], xmm0
000076049b1ddddb  vmovaps [rsp+0x10], xmm2
000076049b1ddde1  vmovaps [rsp+0x20], xmm3
000076049b1ddde7  vmovaps [rsp+0x30], xmm4
000076049b1ddded  vmovaps [rsp+0x40], xmm5
000076049b1dddf3  vmovaps [rsp+0x50], xmm6
000076049b1dddf9  vmovaps [rsp+0x60], xmm7
000076049b1dddff  vmovaps [rsp+0x70], xmm8
000076049b1dde05  vmovaps [rsp+0x80], xmm9
000076049b1dde0e  vmovaps [rsp+0x90], xmm10
000076049b1dde17  vmovaps [rsp+0xA0], xmm11
000076049b1dde20  vmovaps [rsp+0xB0], xmm12
000076049b1dde29  vmovaps [rsp+0xC0], xmm13
000076049b1dde32  vmovaps [rsp+0xD0], xmm14
000076049b1dde3b  vmovaps [rsp+0xE0], xmm15
000076049b1dde44  sub rsp, 0x30
000076049b1dde48  movaps [rsp], xmm1
000076049b1dde4c  movaps [rsp+0x10], xmm5
000076049b1dde51  movaps [rsp+0x20], xmm7
000076049b1dde56  lea rdi, [rsp]
000076049b1dde5a  mov esi, 0x00
000076049b1dde5f  mov rax, 0x64C06813C530
000076049b1dde69  call rax
000076049b1dde6b  movaps xmm1, [rsp]
000076049b1dde6f  add rsp, 0x30
000076049b1dde73  vmovaps xmm0, [rsp]
000076049b1dde78  vmovaps xmm2, [rsp+0x10]
000076049b1dde7e  vmovaps xmm3, [rsp+0x20]
000076049b1dde84  vmovaps xmm4, [rsp+0x30]
000076049b1dde8a  vmovaps xmm5, [rsp+0x40]
000076049b1dde90  vmovaps xmm6, [rsp+0x50]
000076049b1dde96  vmovaps xmm7, [rsp+0x60]
000076049b1dde9c  vmovaps xmm8, [rsp+0x70]
000076049b1ddea2  vmovaps xmm9, [rsp+0x80]
000076049b1ddeab  vmovaps xmm10, [rsp+0x90]
000076049b1ddeb4  vmovaps xmm11, [rsp+0xA0]
000076049b1ddebd  vmovaps xmm12, [rsp+0xB0]
000076049b1ddec6  vmovaps xmm13, [rsp+0xC0]
000076049b1ddecf  vmovaps xmm14, [rsp+0xD0]
000076049b1dded8  vmovaps xmm15, [rsp+0xE0]
000076049b1ddee1  add rsp, 0xF0
000076049b1ddee8  pop r11
000076049b1ddeea  pop r10
000076049b1ddeec  pop r9
000076049b1ddeee  pop r8
000076049b1ddef0  pop rsi
000076049b1ddef1  pop rdi
000076049b1ddef2  pop rdx
000076049b1ddef3  pop rcx
000076049b1ddef4  pop rax
000076049b1ddef5  add rsp, 0x08
000076049b1ddef9  jmp 0x000076049B1DC030
000076049b1ddefe  sub rsp, 0x08
000076049b1ddf02  push rax
000076049b1ddf03  push rcx
000076049b1ddf04  push rdx
000076049b1ddf05  push rdi
000076049b1ddf06  push rsi
000076049b1ddf07  push r8
000076049b1ddf09  push r9
000076049b1ddf0b  push r10
000076049b1ddf0d  push r11
000076049b1ddf0f  sub rsp, 0xF0
000076049b1ddf16  vmovaps [rsp], xmm0
000076049b1ddf1b  vmovaps [rsp+0x10], xmm1
000076049b1ddf21  vmovaps [rsp+0x20], xmm2
000076049b1ddf27  vmovaps [rsp+0x30], xmm3
000076049b1ddf2d  vmovaps [rsp+0x40], xmm4
000076049b1ddf33  vmovaps [rsp+0x50], xmm5
000076049b1ddf39  vmovaps [rsp+0x60], xmm6
000076049b1ddf3f  vmovaps [rsp+0x70], xmm8
000076049b1ddf45  vmovaps [rsp+0x80], xmm9
000076049b1ddf4e  vmovaps [rsp+0x90], xmm10
000076049b1ddf57  vmovaps [rsp+0xA0], xmm11
000076049b1ddf60  vmovaps [rsp+0xB0], xmm12
000076049b1ddf69  vmovaps [rsp+0xC0], xmm13
000076049b1ddf72  vmovaps [rsp+0xD0], xmm14
000076049b1ddf7b  vmovaps [rsp+0xE0], xmm15
000076049b1ddf84  sub rsp, 0x30
000076049b1ddf88  movaps [rsp], xmm7
000076049b1ddf8c  movaps [rsp+0x10], xmm5
000076049b1ddf91  movaps [rsp+0x20], xmm15
000076049b1ddf97  lea rdi, [rsp]
000076049b1ddf9b  mov esi, 0x00
000076049b1ddfa0  mov rax, 0x64C06813C530
000076049b1ddfaa  call rax
000076049b1ddfac  movaps xmm7, [rsp]
000076049b1ddfb0  add rsp, 0x30
000076049b1ddfb4  vmovaps xmm0, [rsp]
000076049b1ddfb9  vmovaps xmm1, [rsp+0x10]
000076049b1ddfbf  vmovaps xmm2, [rsp+0x20]
000076049b1ddfc5  vmovaps xmm3, [rsp+0x30]
000076049b1ddfcb  vmovaps xmm4, [rsp+0x40]
000076049b1ddfd1  vmovaps xmm5, [rsp+0x50]
000076049b1ddfd7  vmovaps xmm6, [rsp+0x60]
000076049b1ddfdd  vmovaps xmm8, [rsp+0x70]
000076049b1ddfe3  vmovaps xmm9, [rsp+0x80]
000076049b1ddfec  vmovaps xmm10, [rsp+0x90]
000076049b1ddff5  vmovaps xmm11, [rsp+0xA0]
000076049b1ddffe  vmovaps xmm12, [rsp+0xB0]
000076049b1de007  vmovaps xmm13, [rsp+0xC0]
000076049b1de010  vmovaps xmm14, [rsp+0xD0]
000076049b1de019  vmovaps xmm15, [rsp+0xE0]
000076049b1de022  add rsp, 0xF0
000076049b1de029  pop r11
000076049b1de02b  pop r10
000076049b1de02d  pop r9
000076049b1de02f  pop r8
000076049b1de031  pop rsi
000076049b1de032  pop rdi
000076049b1de033  pop rdx
000076049b1de034  pop rcx
000076049b1de035  pop rax
000076049b1de036  add rsp, 0x08
000076049b1de03a  jmp 0x000076049B1DC066
000076049b1de03f  call 0x000076049B0B52F0
000076049b1de044  jmp 0x000076049B1DC073
000076049b1de049  sub rsp, 0x08
000076049b1de04d  push rax
000076049b1de04e  push rcx
000076049b1de04f  push rdx
000076049b1de050  push rdi
000076049b1de051  push rsi
000076049b1de052  push r8
000076049b1de054  push r9
000076049b1de056  push r10
000076049b1de058  push r11
000076049b1de05a  sub rsp, 0xF0
000076049b1de061  vmovaps [rsp], xmm0
000076049b1de066  vmovaps [rsp+0x10], xmm1
000076049b1de06c  vmovaps [rsp+0x20], xmm2
000076049b1de072  vmovaps [rsp+0x30], xmm3
000076049b1de078  vmovaps [rsp+0x40], xmm4
000076049b1de07e  vmovaps [rsp+0x50], xmm5
000076049b1de084  vmovaps [rsp+0x60], xmm6
000076049b1de08a  vmovaps [rsp+0x70], xmm7
000076049b1de090  vmovaps [rsp+0x80], xmm8
000076049b1de099  vmovaps [rsp+0x90], xmm9
000076049b1de0a2  vmovaps [rsp+0xA0], xmm10
000076049b1de0ab  vmovaps [rsp+0xB0], xmm11
000076049b1de0b4  vmovaps [rsp+0xC0], xmm12
000076049b1de0bd  vmovaps [rsp+0xD0], xmm13
000076049b1de0c6  vmovaps [rsp+0xE0], xmm14
000076049b1de0cf  sub rsp, 0x30
000076049b1de0d3  movaps [rsp], xmm15
000076049b1de0d8  movaps [rsp+0x10], xmm5
000076049b1de0dd  movaps [rsp+0x20], xmm3
000076049b1de0e2  lea rdi, [rsp]
000076049b1de0e6  mov esi, 0x00
000076049b1de0eb  mov rax, 0x64C06813C530
000076049b1de0f5  call rax
000076049b1de0f7  movaps xmm15, [rsp]
000076049b1de0fc  add rsp, 0x30
000076049b1de100  vmovaps xmm0, [rsp]
000076049b1de105  vmovaps xmm1, [rsp+0x10]
000076049b1de10b  vmovaps xmm2, [rsp+0x20]
000076049b1de111  vmovaps xmm3, [rsp+0x30]
000076049b1de117  vmovaps xmm4, [rsp+0x40]
000076049b1de11d  vmovaps xmm5, [rsp+0x50]
000076049b1de123  vmovaps xmm6, [rsp+0x60]
000076049b1de129  vmovaps xmm7, [rsp+0x70]
000076049b1de12f  vmovaps xmm8, [rsp+0x80]
000076049b1de138  vmovaps xmm9, [rsp+0x90]
000076049b1de141  vmovaps xmm10, [rsp+0xA0]
000076049b1de14a  vmovaps xmm11, [rsp+0xB0]
000076049b1de153  vmovaps xmm12, [rsp+0xC0]
000076049b1de15c  vmovaps xmm13, [rsp+0xD0]
000076049b1de165  vmovaps xmm14, [rsp+0xE0]
000076049b1de16e  add rsp, 0xF0
000076049b1de175  pop r11
000076049b1de177  pop r10
000076049b1de179  pop r9
000076049b1de17b  pop r8
000076049b1de17d  pop rsi
000076049b1de17e  pop rdi
000076049b1de17f  pop rdx
000076049b1de180  pop rcx
000076049b1de181  pop rax
000076049b1de182  add rsp, 0x08
000076049b1de186  jmp 0x000076049B1DC099
000076049b1de18b  sub rsp, 0x08
000076049b1de18f  push rax
000076049b1de190  push rcx
000076049b1de191  push rdx
000076049b1de192  push rdi
000076049b1de193  push rsi
000076049b1de194  push r8
000076049b1de196  push r9
000076049b1de198  push r10
000076049b1de19a  push r11
000076049b1de19c  sub rsp, 0xF0
000076049b1de1a3  vmovaps [rsp], xmm0
000076049b1de1a8  vmovaps [rsp+0x10], xmm2
000076049b1de1ae  vmovaps [rsp+0x20], xmm3
000076049b1de1b4  vmovaps [rsp+0x30], xmm4
000076049b1de1ba  vmovaps [rsp+0x40], xmm5
000076049b1de1c0  vmovaps [rsp+0x50], xmm6
000076049b1de1c6  vmovaps [rsp+0x60], xmm7
000076049b1de1cc  vmovaps [rsp+0x70], xmm8
000076049b1de1d2  vmovaps [rsp+0x80], xmm9
000076049b1de1db  vmovaps [rsp+0x90], xmm10
000076049b1de1e4  vmovaps [rsp+0xA0], xmm11
000076049b1de1ed  vmovaps [rsp+0xB0], xmm12
000076049b1de1f6  vmovaps [rsp+0xC0], xmm13
000076049b1de1ff  vmovaps [rsp+0xD0], xmm14
000076049b1de208  vmovaps [rsp+0xE0], xmm15
000076049b1de211  sub rsp, 0x30
000076049b1de215  movaps [rsp], xmm1
000076049b1de219  movaps [rsp+0x10], xmm5
000076049b1de21e  movaps [rsp+0x20], xmm4
000076049b1de223  lea rdi, [rsp]
000076049b1de227  mov esi, 0x00
000076049b1de22c  mov rax, 0x64C06813C530
000076049b1de236  call rax
000076049b1de238  movaps xmm1, [rsp]
000076049b1de23c  add rsp, 0x30
000076049b1de240  vmovaps xmm0, [rsp]
000076049b1de245  vmovaps xmm2, [rsp+0x10]
000076049b1de24b  vmovaps xmm3, [rsp+0x20]
000076049b1de251  vmovaps xmm4, [rsp+0x30]
000076049b1de257  vmovaps xmm5, [rsp+0x40]
000076049b1de25d  vmovaps xmm6, [rsp+0x50]
000076049b1de263  vmovaps xmm7, [rsp+0x60]
000076049b1de269  vmovaps xmm8, [rsp+0x70]
000076049b1de26f  vmovaps xmm9, [rsp+0x80]
000076049b1de278  vmovaps xmm10, [rsp+0x90]
000076049b1de281  vmovaps xmm11, [rsp+0xA0]
000076049b1de28a  vmovaps xmm12, [rsp+0xB0]
000076049b1de293  vmovaps xmm13, [rsp+0xC0]
000076049b1de29c  vmovaps xmm14, [rsp+0xD0]
000076049b1de2a5  vmovaps xmm15, [rsp+0xE0]
000076049b1de2ae  add rsp, 0xF0
000076049b1de2b5  pop r11
000076049b1de2b7  pop r10
000076049b1de2b9  pop r9
000076049b1de2bb  pop r8
000076049b1de2bd  pop rsi
000076049b1de2be  pop rdi
000076049b1de2bf  pop rdx
000076049b1de2c0  pop rcx
000076049b1de2c1  pop rax
000076049b1de2c2  add rsp, 0x08
000076049b1de2c6  jmp 0x000076049B1DC0B9
000076049b1de2cb  sub rsp, 0x08
000076049b1de2cf  push rax
000076049b1de2d0  push rcx
000076049b1de2d1  push rdx
000076049b1de2d2  push rdi
000076049b1de2d3  push rsi
000076049b1de2d4  push r8
000076049b1de2d6  push r9
000076049b1de2d8  push r10
000076049b1de2da  push r11
000076049b1de2dc  sub rsp, 0xF0
000076049b1de2e3  vmovaps [rsp], xmm0
000076049b1de2e8  vmovaps [rsp+0x10], xmm1
000076049b1de2ee  vmovaps [rsp+0x20], xmm2
000076049b1de2f4  vmovaps [rsp+0x30], xmm3
000076049b1de2fa  vmovaps [rsp+0x40], xmm5
000076049b1de300  vmovaps [rsp+0x50], xmm6
000076049b1de306  vmovaps [rsp+0x60], xmm7
000076049b1de30c  vmovaps [rsp+0x70], xmm8
000076049b1de312  vmovaps [rsp+0x80], xmm9
000076049b1de31b  vmovaps [rsp+0x90], xmm10
000076049b1de324  vmovaps [rsp+0xA0], xmm11
000076049b1de32d  vmovaps [rsp+0xB0], xmm12
000076049b1de336  vmovaps [rsp+0xC0], xmm13
000076049b1de33f  vmovaps [rsp+0xD0], xmm14
000076049b1de348  vmovaps [rsp+0xE0], xmm15
000076049b1de351  sub rsp, 0x30
000076049b1de355  movaps [rsp], xmm4
000076049b1de359  movaps [rsp+0x10], xmm3
000076049b1de35e  movaps [rsp+0x20], xmm5
000076049b1de363  lea rdi, [rsp]
000076049b1de367  mov esi, 0x00
000076049b1de36c  mov rax, 0x64C06813C530
000076049b1de376  call rax
000076049b1de378  movaps xmm4, [rsp]
000076049b1de37c  add rsp, 0x30
000076049b1de380  vmovaps xmm0, [rsp]
000076049b1de385  vmovaps xmm1, [rsp+0x10]
000076049b1de38b  vmovaps xmm2, [rsp+0x20]
000076049b1de391  vmovaps xmm3, [rsp+0x30]
000076049b1de397  vmovaps xmm5, [rsp+0x40]
000076049b1de39d  vmovaps xmm6, [rsp+0x50]
000076049b1de3a3  vmovaps xmm7, [rsp+0x60]
000076049b1de3a9  vmovaps xmm8, [rsp+0x70]
000076049b1de3af  vmovaps xmm9, [rsp+0x80]
000076049b1de3b8  vmovaps xmm10, [rsp+0x90]
000076049b1de3c1  vmovaps xmm11, [rsp+0xA0]
000076049b1de3ca  vmovaps xmm12, [rsp+0xB0]
000076049b1de3d3  vmovaps xmm13, [rsp+0xC0]
000076049b1de3dc  vmovaps xmm14, [rsp+0xD0]
000076049b1de3e5  vmovaps xmm15, [rsp+0xE0]
000076049b1de3ee  add rsp, 0xF0
000076049b1de3f5  pop r11
000076049b1de3f7  pop r10
000076049b1de3f9  pop r9
000076049b1de3fb  pop r8
000076049b1de3fd  pop rsi
000076049b1de3fe  pop rdi
000076049b1de3ff  pop rdx
000076049b1de400  pop rcx
000076049b1de401  pop rax
000076049b1de402  add rsp, 0x08
000076049b1de406  jmp 0x000076049B1DC107
000076049b1de40b  call 0x000076049B0B52F0
000076049b1de410  jmp 0x000076049B1DC114
000076049b1de415  sub rsp, 0x08
000076049b1de419  push rax
000076049b1de41a  push rcx
000076049b1de41b  push rdx
000076049b1de41c  push rdi
000076049b1de41d  push rsi
000076049b1de41e  push r8
000076049b1de420  push r9
000076049b1de422  push r10
000076049b1de424  push r11
000076049b1de426  sub rsp, 0xF0
000076049b1de42d  vmovaps [rsp], xmm0
000076049b1de432  vmovaps [rsp+0x10], xmm1
000076049b1de438  vmovaps [rsp+0x20], xmm2
000076049b1de43e  vmovaps [rsp+0x30], xmm3
000076049b1de444  vmovaps [rsp+0x40], xmm4
000076049b1de44a  vmovaps [rsp+0x50], xmm6
000076049b1de450  vmovaps [rsp+0x60], xmm7
000076049b1de456  vmovaps [rsp+0x70], xmm8
000076049b1de45c  vmovaps [rsp+0x80], xmm9
000076049b1de465  vmovaps [rsp+0x90], xmm10
000076049b1de46e  vmovaps [rsp+0xA0], xmm11
000076049b1de477  vmovaps [rsp+0xB0], xmm12
000076049b1de480  vmovaps [rsp+0xC0], xmm13
000076049b1de489  vmovaps [rsp+0xD0], xmm14
000076049b1de492  vmovaps [rsp+0xE0], xmm15
000076049b1de49b  sub rsp, 0x30
000076049b1de49f  movaps [rsp], xmm5
000076049b1de4a3  movaps [rsp+0x10], xmm6
000076049b1de4a8  movaps [rsp+0x20], xmm3
000076049b1de4ad  lea rdi, [rsp]
000076049b1de4b1  mov esi, 0x00
000076049b1de4b6  mov rax, 0x64C06813C530
000076049b1de4c0  call rax
000076049b1de4c2  movaps xmm5, [rsp]
000076049b1de4c6  add rsp, 0x30
000076049b1de4ca  vmovaps xmm0, [rsp]
000076049b1de4cf  vmovaps xmm1, [rsp+0x10]
000076049b1de4d5  vmovaps xmm2, [rsp+0x20]
000076049b1de4db  vmovaps xmm3, [rsp+0x30]
000076049b1de4e1  vmovaps xmm4, [rsp+0x40]
000076049b1de4e7  vmovaps xmm6, [rsp+0x50]
000076049b1de4ed  vmovaps xmm7, [rsp+0x60]
000076049b1de4f3  vmovaps xmm8, [rsp+0x70]
000076049b1de4f9  vmovaps xmm9, [rsp+0x80]
000076049b1de502  vmovaps xmm10, [rsp+0x90]
000076049b1de50b  vmovaps xmm11, [rsp+0xA0]
000076049b1de514  vmovaps xmm12, [rsp+0xB0]
000076049b1de51d  vmovaps xmm13, [rsp+0xC0]
000076049b1de526  vmovaps xmm14, [rsp+0xD0]
000076049b1de52f  vmovaps xmm15, [rsp+0xE0]
000076049b1de538  add rsp, 0xF0
000076049b1de53f  pop r11
000076049b1de541  pop r10
000076049b1de543  pop r9
000076049b1de545  pop r8
000076049b1de547  pop rsi
000076049b1de548  pop rdi
000076049b1de549  pop rdx
000076049b1de54a  pop rcx
000076049b1de54b  pop rax
000076049b1de54c  add rsp, 0x08
000076049b1de550  jmp 0x000076049B1DC13A
000076049b1de555  sub rsp, 0x08
000076049b1de559  push rax
000076049b1de55a  push rcx
000076049b1de55b  push rdx
000076049b1de55c  push rdi
000076049b1de55d  push rsi
000076049b1de55e  push r8
000076049b1de560  push r9
000076049b1de562  push r10
000076049b1de564  push r11
000076049b1de566  sub rsp, 0xF0
000076049b1de56d  vmovaps [rsp], xmm0
000076049b1de572  vmovaps [rsp+0x10], xmm1
000076049b1de578  vmovaps [rsp+0x20], xmm2
000076049b1de57e  vmovaps [rsp+0x30], xmm3
000076049b1de584  vmovaps [rsp+0x40], xmm4
000076049b1de58a  vmovaps [rsp+0x50], xmm5
000076049b1de590  vmovaps [rsp+0x60], xmm7
000076049b1de596  vmovaps [rsp+0x70], xmm8
000076049b1de59c  vmovaps [rsp+0x80], xmm9
000076049b1de5a5  vmovaps [rsp+0x90], xmm10
000076049b1de5ae  vmovaps [rsp+0xA0], xmm11
000076049b1de5b7  vmovaps [rsp+0xB0], xmm12
000076049b1de5c0  vmovaps [rsp+0xC0], xmm13
000076049b1de5c9  vmovaps [rsp+0xD0], xmm14
000076049b1de5d2  vmovaps [rsp+0xE0], xmm15
000076049b1de5db  sub rsp, 0x30
000076049b1de5df  movaps [rsp], xmm6
000076049b1de5e3  movaps [rsp+0x10], xmm9
000076049b1de5e9  movaps [rsp+0x20], xmm1
000076049b1de5ee  lea rdi, [rsp]
000076049b1de5f2  mov esi, 0x00
000076049b1de5f7  mov rax, 0x64C06813C530
000076049b1de601  call rax
000076049b1de603  movaps xmm6, [rsp]
000076049b1de607  add rsp, 0x30
000076049b1de60b  vmovaps xmm0, [rsp]
000076049b1de610  vmovaps xmm1, [rsp+0x10]
000076049b1de616  vmovaps xmm2, [rsp+0x20]
000076049b1de61c  vmovaps xmm3, [rsp+0x30]
000076049b1de622  vmovaps xmm4, [rsp+0x40]
000076049b1de628  vmovaps xmm5, [rsp+0x50]
000076049b1de62e  vmovaps xmm7, [rsp+0x60]
000076049b1de634  vmovaps xmm8, [rsp+0x70]
000076049b1de63a  vmovaps xmm9, [rsp+0x80]
000076049b1de643  vmovaps xmm10, [rsp+0x90]
000076049b1de64c  vmovaps xmm11, [rsp+0xA0]
000076049b1de655  vmovaps xmm12, [rsp+0xB0]
000076049b1de65e  vmovaps xmm13, [rsp+0xC0]
000076049b1de667  vmovaps xmm14, [rsp+0xD0]
000076049b1de670  vmovaps xmm15, [rsp+0xE0]
000076049b1de679  add rsp, 0xF0
000076049b1de680  pop r11
000076049b1de682  pop r10
000076049b1de684  pop r9
000076049b1de686  pop r8
000076049b1de688  pop rsi
000076049b1de689  pop rdi
000076049b1de68a  pop rdx
000076049b1de68b  pop rcx
000076049b1de68c  pop rax
000076049b1de68d  add rsp, 0x08
000076049b1de691  jmp 0x000076049B1DC15E
000076049b1de696  sub rsp, 0x08
000076049b1de69a  push rax
000076049b1de69b  push rcx
000076049b1de69c  push rdx
000076049b1de69d  push rdi
000076049b1de69e  push rsi
000076049b1de69f  push r8
000076049b1de6a1  push r9
000076049b1de6a3  push r10
000076049b1de6a5  push r11
000076049b1de6a7  sub rsp, 0xF0
000076049b1de6ae  vmovaps [rsp], xmm0
000076049b1de6b3  vmovaps [rsp+0x10], xmm1
000076049b1de6b9  vmovaps [rsp+0x20], xmm2
000076049b1de6bf  vmovaps [rsp+0x30], xmm3
000076049b1de6c5  vmovaps [rsp+0x40], xmm4
000076049b1de6cb  vmovaps [rsp+0x50], xmm5
000076049b1de6d1  vmovaps [rsp+0x60], xmm6
000076049b1de6d7  vmovaps [rsp+0x70], xmm7
000076049b1de6dd  vmovaps [rsp+0x80], xmm8
000076049b1de6e6  vmovaps [rsp+0x90], xmm10
000076049b1de6ef  vmovaps [rsp+0xA0], xmm11
000076049b1de6f8  vmovaps [rsp+0xB0], xmm12
000076049b1de701  vmovaps [rsp+0xC0], xmm13
000076049b1de70a  vmovaps [rsp+0xD0], xmm14
000076049b1de713  vmovaps [rsp+0xE0], xmm15
000076049b1de71c  sub rsp, 0x30
000076049b1de720  movaps [rsp], xmm9
000076049b1de725  movaps [rsp+0x10], xmm3
000076049b1de72a  movaps [rsp+0x20], xmm1
000076049b1de72f  lea rdi, [rsp]
000076049b1de733  mov esi, 0x00
000076049b1de738  mov rax, 0x64C06813C530
000076049b1de742  call rax
000076049b1de744  movaps xmm9, [rsp]
000076049b1de749  add rsp, 0x30
000076049b1de74d  vmovaps xmm0, [rsp]
000076049b1de752  vmovaps xmm1, [rsp+0x10]
000076049b1de758  vmovaps xmm2, [rsp+0x20]
000076049b1de75e  vmovaps xmm3, [rsp+0x30]
000076049b1de764  vmovaps xmm4, [rsp+0x40]
000076049b1de76a  vmovaps xmm5, [rsp+0x50]
000076049b1de770  vmovaps xmm6, [rsp+0x60]
000076049b1de776  vmovaps xmm7, [rsp+0x70]
000076049b1de77c  vmovaps xmm8, [rsp+0x80]
000076049b1de785  vmovaps xmm10, [rsp+0x90]
000076049b1de78e  vmovaps xmm11, [rsp+0xA0]
000076049b1de797  vmovaps xmm12, [rsp+0xB0]
000076049b1de7a0  vmovaps xmm13, [rsp+0xC0]
000076049b1de7a9  vmovaps xmm14, [rsp+0xD0]
000076049b1de7b2  vmovaps xmm15, [rsp+0xE0]
000076049b1de7bb  add rsp, 0xF0
000076049b1de7c2  pop r11
000076049b1de7c4  pop r10
000076049b1de7c6  pop r9
000076049b1de7c8  pop r8
000076049b1de7ca  pop rsi
000076049b1de7cb  pop rdi
000076049b1de7cc  pop rdx
000076049b1de7cd  pop rcx
000076049b1de7ce  pop rax
000076049b1de7cf  add rsp, 0x08
000076049b1de7d3  jmp 0x000076049B1DC1AA
000076049b1de7d8  call 0x000076049B0B52F0
000076049b1de7dd  jmp 0x000076049B1DC1B7
000076049b1de7e2  sub rsp, 0x08
000076049b1de7e6  push rax
000076049b1de7e7  push rcx
000076049b1de7e8  push rdx
000076049b1de7e9  push rdi
000076049b1de7ea  push rsi
000076049b1de7eb  push r8
000076049b1de7ed  push r9
000076049b1de7ef  push r10
000076049b1de7f1  push r11
000076049b1de7f3  sub rsp, 0xF0
000076049b1de7fa  vmovaps [rsp], xmm0
000076049b1de7ff  vmovaps [rsp+0x10], xmm1
000076049b1de805  vmovaps [rsp+0x20], xmm2
000076049b1de80b  vmovaps [rsp+0x30], xmm3
000076049b1de811  vmovaps [rsp+0x40], xmm4
000076049b1de817  vmovaps [rsp+0x50], xmm5
000076049b1de81d  vmovaps [rsp+0x60], xmm6
000076049b1de823  vmovaps [rsp+0x70], xmm7
000076049b1de829  vmovaps [rsp+0x80], xmm8
000076049b1de832  vmovaps [rsp+0x90], xmm9
000076049b1de83b  vmovaps [rsp+0xA0], xmm10
000076049b1de844  vmovaps [rsp+0xB0], xmm11
000076049b1de84d  vmovaps [rsp+0xC0], xmm12
000076049b1de856  vmovaps [rsp+0xD0], xmm13
000076049b1de85f  vmovaps [rsp+0xE0], xmm14
000076049b1de868  sub rsp, 0x30
000076049b1de86c  movaps [rsp], xmm15
000076049b1de871  movaps [rsp+0x10], xmm3
000076049b1de876  movaps [rsp+0x20], xmm7
000076049b1de87b  lea rdi, [rsp]
000076049b1de87f  mov esi, 0x00
000076049b1de884  mov rax, 0x64C06813C530
000076049b1de88e  call rax
000076049b1de890  movaps xmm15, [rsp]
000076049b1de895  add rsp, 0x30
000076049b1de899  vmovaps xmm0, [rsp]
000076049b1de89e  vmovaps xmm1, [rsp+0x10]
000076049b1de8a4  vmovaps xmm2, [rsp+0x20]
000076049b1de8aa  vmovaps xmm3, [rsp+0x30]
000076049b1de8b0  vmovaps xmm4, [rsp+0x40]
000076049b1de8b6  vmovaps xmm5, [rsp+0x50]
000076049b1de8bc  vmovaps xmm6, [rsp+0x60]
000076049b1de8c2  vmovaps xmm7, [rsp+0x70]
000076049b1de8c8  vmovaps xmm8, [rsp+0x80]
000076049b1de8d1  vmovaps xmm9, [rsp+0x90]
000076049b1de8da  vmovaps xmm10, [rsp+0xA0]
000076049b1de8e3  vmovaps xmm11, [rsp+0xB0]
000076049b1de8ec  vmovaps xmm12, [rsp+0xC0]
000076049b1de8f5  vmovaps xmm13, [rsp+0xD0]
000076049b1de8fe  vmovaps xmm14, [rsp+0xE0]
000076049b1de907  add rsp, 0xF0
000076049b1de90e  pop r11
000076049b1de910  pop r10
000076049b1de912  pop r9
000076049b1de914  pop r8
000076049b1de916  pop rsi
000076049b1de917  pop rdi
000076049b1de918  pop rdx
000076049b1de919  pop rcx
000076049b1de91a  pop rax
000076049b1de91b  add rsp, 0x08
000076049b1de91f  jmp 0x000076049B1DC1E3
000076049b1de924  sub rsp, 0x08
000076049b1de928  push rax
000076049b1de929  push rcx
000076049b1de92a  push rdx
000076049b1de92b  push rdi
000076049b1de92c  push rsi
000076049b1de92d  push r8
000076049b1de92f  push r9
000076049b1de931  push r10
000076049b1de933  push r11
000076049b1de935  sub rsp, 0xF0
000076049b1de93c  vmovaps [rsp], xmm0
000076049b1de941  vmovaps [rsp+0x10], xmm1
000076049b1de947  vmovaps [rsp+0x20], xmm2
000076049b1de94d  vmovaps [rsp+0x30], xmm4
000076049b1de953  vmovaps [rsp+0x40], xmm5
000076049b1de959  vmovaps [rsp+0x50], xmm6
000076049b1de95f  vmovaps [rsp+0x60], xmm7
000076049b1de965  vmovaps [rsp+0x70], xmm8
000076049b1de96b  vmovaps [rsp+0x80], xmm9
000076049b1de974  vmovaps [rsp+0x90], xmm10
000076049b1de97d  vmovaps [rsp+0xA0], xmm11
000076049b1de986  vmovaps [rsp+0xB0], xmm12
000076049b1de98f  vmovaps [rsp+0xC0], xmm13
000076049b1de998  vmovaps [rsp+0xD0], xmm14
000076049b1de9a1  vmovaps [rsp+0xE0], xmm15
000076049b1de9aa  sub rsp, 0x30
000076049b1de9ae  movaps [rsp], xmm3
000076049b1de9b2  movaps [rsp+0x10], xmm1
000076049b1de9b7  movaps [rsp+0x20], xmm15
000076049b1de9bd  lea rdi, [rsp]
000076049b1de9c1  mov esi, 0x00
000076049b1de9c6  mov rax, 0x64C06813C530
000076049b1de9d0  call rax
000076049b1de9d2  movaps xmm3, [rsp]
000076049b1de9d6  add rsp, 0x30
000076049b1de9da  vmovaps xmm0, [rsp]
000076049b1de9df  vmovaps xmm1, [rsp+0x10]
000076049b1de9e5  vmovaps xmm2, [rsp+0x20]
000076049b1de9eb  vmovaps xmm4, [rsp+0x30]
000076049b1de9f1  vmovaps xmm5, [rsp+0x40]
000076049b1de9f7  vmovaps xmm6, [rsp+0x50]
000076049b1de9fd  vmovaps xmm7, [rsp+0x60]
000076049b1dea03  vmovaps xmm8, [rsp+0x70]
000076049b1dea09  vmovaps xmm9, [rsp+0x80]
000076049b1dea12  vmovaps xmm10, [rsp+0x90]
000076049b1dea1b  vmovaps xmm11, [rsp+0xA0]
000076049b1dea24  vmovaps xmm12, [rsp+0xB0]
000076049b1dea2d  vmovaps xmm13, [rsp+0xC0]
000076049b1dea36  vmovaps xmm14, [rsp+0xD0]
000076049b1dea3f  vmovaps xmm15, [rsp+0xE0]
000076049b1dea48  add rsp, 0xF0
000076049b1dea4f  pop r11
000076049b1dea51  pop r10
000076049b1dea53  pop r9
000076049b1dea55  pop r8
000076049b1dea57  pop rsi
000076049b1dea58  pop rdi
000076049b1dea59  pop rdx
000076049b1dea5a  pop rcx
000076049b1dea5b  pop rax
000076049b1dea5c  add rsp, 0x08
000076049b1dea60  jmp 0x000076049B1DC272
000076049b1dea65  call 0x000076049B0B52F0
000076049b1dea6a  jmp 0x000076049B1DC27C
000076049b1dea6f  sub rsp, 0x08
000076049b1dea73  push rax
000076049b1dea74  push rcx
000076049b1dea75  push rdx
000076049b1dea76  push rdi
000076049b1dea77  push rsi
000076049b1dea78  push r8
000076049b1dea7a  push r9
000076049b1dea7c  push r10
000076049b1dea7e  push r11
000076049b1dea80  sub rsp, 0xF0
000076049b1dea87  vmovaps [rsp], xmm0
000076049b1dea8c  vmovaps [rsp+0x10], xmm1
000076049b1dea92  vmovaps [rsp+0x20], xmm2
000076049b1dea98  vmovaps [rsp+0x30], xmm3
000076049b1dea9e  vmovaps [rsp+0x40], xmm4
000076049b1deaa4  vmovaps [rsp+0x50], xmm5
000076049b1deaaa  vmovaps [rsp+0x60], xmm6
000076049b1deab0  vmovaps [rsp+0x70], xmm7
000076049b1deab6  vmovaps [rsp+0x80], xmm8
000076049b1deabf  vmovaps [rsp+0x90], xmm9
000076049b1deac8  vmovaps [rsp+0xA0], xmm10
000076049b1dead1  vmovaps [rsp+0xB0], xmm11
000076049b1deada  vmovaps [rsp+0xC0], xmm12
000076049b1deae3  vmovaps [rsp+0xD0], xmm13
000076049b1deaec  vmovaps [rsp+0xE0], xmm14
000076049b1deaf5  sub rsp, 0x30
000076049b1deaf9  movaps [rsp], xmm15
000076049b1deafe  movaps [rsp+0x10], xmm14
000076049b1deb04  movaps [rsp+0x20], xmm4
000076049b1deb09  lea rdi, [rsp]
000076049b1deb0d  mov esi, 0x00
000076049b1deb12  mov rax, 0x64C06813C530
000076049b1deb1c  call rax
000076049b1deb1e  movaps xmm15, [rsp]
000076049b1deb23  add rsp, 0x30
000076049b1deb27  vmovaps xmm0, [rsp]
000076049b1deb2c  vmovaps xmm1, [rsp+0x10]
000076049b1deb32  vmovaps xmm2, [rsp+0x20]
000076049b1deb38  vmovaps xmm3, [rsp+0x30]
000076049b1deb3e  vmovaps xmm4, [rsp+0x40]
000076049b1deb44  vmovaps xmm5, [rsp+0x50]
000076049b1deb4a  vmovaps xmm6, [rsp+0x60]
000076049b1deb50  vmovaps xmm7, [rsp+0x70]
000076049b1deb56  vmovaps xmm8, [rsp+0x80]
000076049b1deb5f  vmovaps xmm9, [rsp+0x90]
000076049b1deb68  vmovaps xmm10, [rsp+0xA0]
000076049b1deb71  vmovaps xmm11, [rsp+0xB0]
000076049b1deb7a  vmovaps xmm12, [rsp+0xC0]
000076049b1deb83  vmovaps xmm13, [rsp+0xD0]
000076049b1deb8c  vmovaps xmm14, [rsp+0xE0]
000076049b1deb95  add rsp, 0xF0
000076049b1deb9c  pop r11
000076049b1deb9e  pop r10
000076049b1deba0  pop r9
000076049b1deba2  pop r8
000076049b1deba4  pop rsi
000076049b1deba5  pop rdi
000076049b1deba6  pop rdx
000076049b1deba7  pop rcx
000076049b1deba8  pop rax
000076049b1deba9  add rsp, 0x08
000076049b1debad  jmp 0x000076049B1DC2AA
000076049b1debb2  sub rsp, 0x08
000076049b1debb6  push rax
000076049b1debb7  push rcx
000076049b1debb8  push rdx
000076049b1debb9  push rdi
000076049b1debba  push rsi
000076049b1debbb  push r8
000076049b1debbd  push r9
000076049b1debbf  push r10
000076049b1debc1  push r11
000076049b1debc3  sub rsp, 0xF0
000076049b1debca  vmovaps [rsp], xmm0
000076049b1debcf  vmovaps [rsp+0x10], xmm1
000076049b1debd5  vmovaps [rsp+0x20], xmm2
000076049b1debdb  vmovaps [rsp+0x30], xmm3
000076049b1debe1  vmovaps [rsp+0x40], xmm4
000076049b1debe7  vmovaps [rsp+0x50], xmm5
000076049b1debed  vmovaps [rsp+0x60], xmm6
000076049b1debf3  vmovaps [rsp+0x70], xmm7
000076049b1debf9  vmovaps [rsp+0x80], xmm8
000076049b1dec02  vmovaps [rsp+0x90], xmm9
000076049b1dec0b  vmovaps [rsp+0xA0], xmm10
000076049b1dec14  vmovaps [rsp+0xB0], xmm11
000076049b1dec1d  vmovaps [rsp+0xC0], xmm12
000076049b1dec26  vmovaps [rsp+0xD0], xmm13
000076049b1dec2f  vmovaps [rsp+0xE0], xmm15
000076049b1dec38  sub rsp, 0x30
000076049b1dec3c  movaps [rsp], xmm14
000076049b1dec41  movaps [rsp+0x10], xmm2
000076049b1dec46  movaps [rsp+0x20], xmm1
000076049b1dec4b  lea rdi, [rsp]
000076049b1dec4f  mov esi, 0x00
000076049b1dec54  mov rax, 0x64C06813C530
000076049b1dec5e  call rax
000076049b1dec60  movaps xmm14, [rsp]
000076049b1dec65  add rsp, 0x30
000076049b1dec69  vmovaps xmm0, [rsp]
000076049b1dec6e  vmovaps xmm1, [rsp+0x10]
000076049b1dec74  vmovaps xmm2, [rsp+0x20]
000076049b1dec7a  vmovaps xmm3, [rsp+0x30]
000076049b1dec80  vmovaps xmm4, [rsp+0x40]
000076049b1dec86  vmovaps xmm5, [rsp+0x50]
000076049b1dec8c  vmovaps xmm6, [rsp+0x60]
000076049b1dec92  vmovaps xmm7, [rsp+0x70]
000076049b1dec98  vmovaps xmm8, [rsp+0x80]
000076049b1deca1  vmovaps xmm9, [rsp+0x90]
000076049b1decaa  vmovaps xmm10, [rsp+0xA0]
000076049b1decb3  vmovaps xmm11, [rsp+0xB0]
000076049b1decbc  vmovaps xmm12, [rsp+0xC0]
000076049b1decc5  vmovaps xmm13, [rsp+0xD0]
000076049b1decce  vmovaps xmm15, [rsp+0xE0]
000076049b1decd7  add rsp, 0xF0
000076049b1decde  pop r11
000076049b1dece0  pop r10
000076049b1dece2  pop r9
000076049b1dece4  pop r8
000076049b1dece6  pop rsi
000076049b1dece7  pop rdi
000076049b1dece8  pop rdx
000076049b1dece9  pop rcx
000076049b1decea  pop rax
000076049b1deceb  add rsp, 0x08
000076049b1decef  jmp 0x000076049B1DC2D0
000076049b1decf4  sub rsp, 0x08
000076049b1decf8  push rax
000076049b1decf9  push rcx
000076049b1decfa  push rdx
000076049b1decfb  push rdi
000076049b1decfc  push rsi
000076049b1decfd  push r8
000076049b1decff  push r9
000076049b1ded01  push r10
000076049b1ded03  push r11
000076049b1ded05  sub rsp, 0xF0
000076049b1ded0c  vmovaps [rsp], xmm0
000076049b1ded11  vmovaps [rsp+0x10], xmm2
000076049b1ded17  vmovaps [rsp+0x20], xmm3
000076049b1ded1d  vmovaps [rsp+0x30], xmm4
000076049b1ded23  vmovaps [rsp+0x40], xmm5
000076049b1ded29  vmovaps [rsp+0x50], xmm6
000076049b1ded2f  vmovaps [rsp+0x60], xmm7
000076049b1ded35  vmovaps [rsp+0x70], xmm8
000076049b1ded3b  vmovaps [rsp+0x80], xmm9
000076049b1ded44  vmovaps [rsp+0x90], xmm10
000076049b1ded4d  vmovaps [rsp+0xA0], xmm11
000076049b1ded56  vmovaps [rsp+0xB0], xmm12
000076049b1ded5f  vmovaps [rsp+0xC0], xmm13
000076049b1ded68  vmovaps [rsp+0xD0], xmm14
000076049b1ded71  vmovaps [rsp+0xE0], xmm15
000076049b1ded7a  sub rsp, 0x30
000076049b1ded7e  movaps [rsp], xmm1
000076049b1ded82  movaps [rsp+0x10], xmm4
000076049b1ded87  movaps [rsp+0x20], xmm9
000076049b1ded8d  lea rdi, [rsp]
000076049b1ded91  mov esi, 0x00
000076049b1ded96  mov rax, 0x64C06813C530
000076049b1deda0  call rax
000076049b1deda2  movaps xmm1, [rsp]
000076049b1deda6  add rsp, 0x30
000076049b1dedaa  vmovaps xmm0, [rsp]
000076049b1dedaf  vmovaps xmm2, [rsp+0x10]
000076049b1dedb5  vmovaps xmm3, [rsp+0x20]
000076049b1dedbb  vmovaps xmm4, [rsp+0x30]
000076049b1dedc1  vmovaps xmm5, [rsp+0x40]
000076049b1dedc7  vmovaps xmm6, [rsp+0x50]
000076049b1dedcd  vmovaps xmm7, [rsp+0x60]
000076049b1dedd3  vmovaps xmm8, [rsp+0x70]
000076049b1dedd9  vmovaps xmm9, [rsp+0x80]
000076049b1dede2  vmovaps xmm10, [rsp+0x90]
000076049b1dedeb  vmovaps xmm11, [rsp+0xA0]
000076049b1dedf4  vmovaps xmm12, [rsp+0xB0]
000076049b1dedfd  vmovaps xmm13, [rsp+0xC0]
000076049b1dee06  vmovaps xmm14, [rsp+0xD0]
000076049b1dee0f  vmovaps xmm15, [rsp+0xE0]
000076049b1dee18  add rsp, 0xF0
000076049b1dee1f  pop r11
000076049b1dee21  pop r10
000076049b1dee23  pop r9
000076049b1dee25  pop r8
000076049b1dee27  pop rsi
000076049b1dee28  pop rdi
000076049b1dee29  pop rdx
000076049b1dee2a  pop rcx
000076049b1dee2b  pop rax
000076049b1dee2c  add rsp, 0x08
000076049b1dee30  jmp 0x000076049B1DC2EE
000076049b1dee35  sub rsp, 0x08
000076049b1dee39  push rax
000076049b1dee3a  push rcx
000076049b1dee3b  push rdx
000076049b1dee3c  push rdi
000076049b1dee3d  push rsi
000076049b1dee3e  push r8
000076049b1dee40  push r9
000076049b1dee42  push r10
000076049b1dee44  push r11
000076049b1dee46  sub rsp, 0xF0
000076049b1dee4d  vmovaps [rsp], xmm0
000076049b1dee52  vmovaps [rsp+0x10], xmm1
000076049b1dee58  vmovaps [rsp+0x20], xmm2
000076049b1dee5e  vmovaps [rsp+0x30], xmm3
000076049b1dee64  vmovaps [rsp+0x40], xmm5
000076049b1dee6a  vmovaps [rsp+0x50], xmm6
000076049b1dee70  vmovaps [rsp+0x60], xmm7
000076049b1dee76  vmovaps [rsp+0x70], xmm8
000076049b1dee7c  vmovaps [rsp+0x80], xmm9
000076049b1dee85  vmovaps [rsp+0x90], xmm10
000076049b1dee8e  vmovaps [rsp+0xA0], xmm11
000076049b1dee97  vmovaps [rsp+0xB0], xmm12
000076049b1deea0  vmovaps [rsp+0xC0], xmm13
000076049b1deea9  vmovaps [rsp+0xD0], xmm14
000076049b1deeb2  vmovaps [rsp+0xE0], xmm15
000076049b1deebb  sub rsp, 0x30
000076049b1deebf  movaps [rsp], xmm4
000076049b1deec3  movaps [rsp+0x10], xmm2
000076049b1deec8  movaps [rsp+0x20], xmm9
000076049b1deece  lea rdi, [rsp]
000076049b1deed2  mov esi, 0x00
000076049b1deed7  mov rax, 0x64C06813C530
000076049b1deee1  call rax
000076049b1deee3  movaps xmm4, [rsp]
000076049b1deee7  add rsp, 0x30
000076049b1deeeb  vmovaps xmm0, [rsp]
000076049b1deef0  vmovaps xmm1, [rsp+0x10]
000076049b1deef6  vmovaps xmm2, [rsp+0x20]
000076049b1deefc  vmovaps xmm3, [rsp+0x30]
000076049b1def02  vmovaps xmm5, [rsp+0x40]
000076049b1def08  vmovaps xmm6, [rsp+0x50]
000076049b1def0e  vmovaps xmm7, [rsp+0x60]
000076049b1def14  vmovaps xmm8, [rsp+0x70]
000076049b1def1a  vmovaps xmm9, [rsp+0x80]
000076049b1def23  vmovaps xmm10, [rsp+0x90]
000076049b1def2c  vmovaps xmm11, [rsp+0xA0]
000076049b1def35  vmovaps xmm12, [rsp+0xB0]
000076049b1def3e  vmovaps xmm13, [rsp+0xC0]
000076049b1def47  vmovaps xmm14, [rsp+0xD0]
000076049b1def50  vmovaps xmm15, [rsp+0xE0]
000076049b1def59  add rsp, 0xF0
000076049b1def60  pop r11
000076049b1def62  pop r10
000076049b1def64  pop r9
000076049b1def66  pop r8
000076049b1def68  pop rsi
000076049b1def69  pop rdi
000076049b1def6a  pop rdx
000076049b1def6b  pop rcx
000076049b1def6c  pop rax
000076049b1def6d  add rsp, 0x08
000076049b1def71  jmp 0x000076049B1DC31E
000076049b1def76  sub rsp, 0x08
000076049b1def7a  push rax
000076049b1def7b  push rcx
000076049b1def7c  push rdx
000076049b1def7d  push rdi
000076049b1def7e  push rsi
000076049b1def7f  push r8
000076049b1def81  push r9
000076049b1def83  push r10
000076049b1def85  push r11
000076049b1def87  sub rsp, 0xF0
000076049b1def8e  vmovaps [rsp], xmm0
000076049b1def93  vmovaps [rsp+0x10], xmm1
000076049b1def99  vmovaps [rsp+0x20], xmm2
000076049b1def9f  vmovaps [rsp+0x30], xmm3
000076049b1defa5  vmovaps [rsp+0x40], xmm4
000076049b1defab  vmovaps [rsp+0x50], xmm5
000076049b1defb1  vmovaps [rsp+0x60], xmm6
000076049b1defb7  vmovaps [rsp+0x70], xmm7
000076049b1defbd  vmovaps [rsp+0x80], xmm8
000076049b1defc6  vmovaps [rsp+0x90], xmm10
000076049b1defcf  vmovaps [rsp+0xA0], xmm11
000076049b1defd8  vmovaps [rsp+0xB0], xmm12
000076049b1defe1  vmovaps [rsp+0xC0], xmm13
000076049b1defea  vmovaps [rsp+0xD0], xmm14
000076049b1deff3  vmovaps [rsp+0xE0], xmm15
000076049b1deffc  sub rsp, 0x30
000076049b1df000  movaps [rsp], xmm9
000076049b1df005  movaps [rsp+0x10], xmm2
000076049b1df00a  movaps [rsp+0x20], xmm1
000076049b1df00f  lea rdi, [rsp]
000076049b1df013  mov esi, 0x00
000076049b1df018  mov rax, 0x64C06813C530
000076049b1df022  call rax
000076049b1df024  movaps xmm9, [rsp]
000076049b1df029  add rsp, 0x30
000076049b1df02d  vmovaps xmm0, [rsp]
000076049b1df032  vmovaps xmm1, [rsp+0x10]
000076049b1df038  vmovaps xmm2, [rsp+0x20]
000076049b1df03e  vmovaps xmm3, [rsp+0x30]
000076049b1df044  vmovaps xmm4, [rsp+0x40]
000076049b1df04a  vmovaps xmm5, [rsp+0x50]
000076049b1df050  vmovaps xmm6, [rsp+0x60]
000076049b1df056  vmovaps xmm7, [rsp+0x70]
000076049b1df05c  vmovaps xmm8, [rsp+0x80]
000076049b1df065  vmovaps xmm10, [rsp+0x90]
000076049b1df06e  vmovaps xmm11, [rsp+0xA0]
000076049b1df077  vmovaps xmm12, [rsp+0xB0]
000076049b1df080  vmovaps xmm13, [rsp+0xC0]
000076049b1df089  vmovaps xmm14, [rsp+0xD0]
000076049b1df092  vmovaps xmm15, [rsp+0xE0]
000076049b1df09b  add rsp, 0xF0
000076049b1df0a2  pop r11
000076049b1df0a4  pop r10
000076049b1df0a6  pop r9
000076049b1df0a8  pop r8
000076049b1df0aa  pop rsi
000076049b1df0ab  pop rdi
000076049b1df0ac  pop rdx
000076049b1df0ad  pop rcx
000076049b1df0ae  pop rax
000076049b1df0af  add rsp, 0x08
000076049b1df0b3  jmp 0x000076049B1DC354
000076049b1df0b8  sub rsp, 0x08
000076049b1df0bc  push rax
000076049b1df0bd  push rcx
000076049b1df0be  push rdx
000076049b1df0bf  push rdi
000076049b1df0c0  push rsi
000076049b1df0c1  push r8
000076049b1df0c3  push r9
000076049b1df0c5  push r10
000076049b1df0c7  push r11
000076049b1df0c9  sub rsp, 0xF0
000076049b1df0d0  vmovaps [rsp], xmm0
000076049b1df0d5  vmovaps [rsp+0x10], xmm2
000076049b1df0db  vmovaps [rsp+0x20], xmm3
000076049b1df0e1  vmovaps [rsp+0x30], xmm4
000076049b1df0e7  vmovaps [rsp+0x40], xmm5
000076049b1df0ed  vmovaps [rsp+0x50], xmm6
000076049b1df0f3  vmovaps [rsp+0x60], xmm7
000076049b1df0f9  vmovaps [rsp+0x70], xmm8
000076049b1df0ff  vmovaps [rsp+0x80], xmm9
000076049b1df108  vmovaps [rsp+0x90], xmm10
000076049b1df111  vmovaps [rsp+0xA0], xmm11
000076049b1df11a  vmovaps [rsp+0xB0], xmm12
000076049b1df123  vmovaps [rsp+0xC0], xmm13
000076049b1df12c  vmovaps [rsp+0xD0], xmm14
000076049b1df135  vmovaps [rsp+0xE0], xmm15
000076049b1df13e  sub rsp, 0x30
000076049b1df142  movaps [rsp], xmm1
000076049b1df146  movaps [rsp+0x10], xmm15
000076049b1df14c  movaps [rsp+0x20], xmm6
000076049b1df151  lea rdi, [rsp]
000076049b1df155  mov esi, 0x00
000076049b1df15a  mov rax, 0x64C06813C530
000076049b1df164  call rax
000076049b1df166  movaps xmm1, [rsp]
000076049b1df16a  add rsp, 0x30
000076049b1df16e  vmovaps xmm0, [rsp]
000076049b1df173  vmovaps xmm2, [rsp+0x10]
000076049b1df179  vmovaps xmm3, [rsp+0x20]
000076049b1df17f  vmovaps xmm4, [rsp+0x30]
000076049b1df185  vmovaps xmm5, [rsp+0x40]
000076049b1df18b  vmovaps xmm6, [rsp+0x50]
000076049b1df191  vmovaps xmm7, [rsp+0x60]
000076049b1df197  vmovaps xmm8, [rsp+0x70]
000076049b1df19d  vmovaps xmm9, [rsp+0x80]
000076049b1df1a6  vmovaps xmm10, [rsp+0x90]
000076049b1df1af  vmovaps xmm11, [rsp+0xA0]
000076049b1df1b8  vmovaps xmm12, [rsp+0xB0]
000076049b1df1c1  vmovaps xmm13, [rsp+0xC0]
000076049b1df1ca  vmovaps xmm14, [rsp+0xD0]
000076049b1df1d3  vmovaps xmm15, [rsp+0xE0]
000076049b1df1dc  add rsp, 0xF0
000076049b1df1e3  pop r11
000076049b1df1e5  pop r10
000076049b1df1e7  pop r9
000076049b1df1e9  pop r8
000076049b1df1eb  pop rsi
000076049b1df1ec  pop rdi
000076049b1df1ed  pop rdx
000076049b1df1ee  pop rcx
000076049b1df1ef  pop rax
000076049b1df1f0  add rsp, 0x08
000076049b1df1f4  jmp 0x000076049B1DC375
000076049b1df1f9  sub rsp, 0x08
000076049b1df1fd  push rax
000076049b1df1fe  push rcx
000076049b1df1ff  push rdx
000076049b1df200  push rdi
000076049b1df201  push rsi
000076049b1df202  push r8
000076049b1df204  push r9
000076049b1df206  push r10
000076049b1df208  push r11
000076049b1df20a  sub rsp, 0xF0
000076049b1df211  vmovaps [rsp], xmm0
000076049b1df216  vmovaps [rsp+0x10], xmm1
000076049b1df21c  vmovaps [rsp+0x20], xmm2
000076049b1df222  vmovaps [rsp+0x30], xmm3
000076049b1df228  vmovaps [rsp+0x40], xmm4
000076049b1df22e  vmovaps [rsp+0x50], xmm5
000076049b1df234  vmovaps [rsp+0x60], xmm6
000076049b1df23a  vmovaps [rsp+0x70], xmm7
000076049b1df240  vmovaps [rsp+0x80], xmm8
000076049b1df249  vmovaps [rsp+0x90], xmm9
000076049b1df252  vmovaps [rsp+0xA0], xmm10
000076049b1df25b  vmovaps [rsp+0xB0], xmm11
000076049b1df264  vmovaps [rsp+0xC0], xmm12
000076049b1df26d  vmovaps [rsp+0xD0], xmm13
000076049b1df276  vmovaps [rsp+0xE0], xmm14
000076049b1df27f  sub rsp, 0x30
000076049b1df283  movaps [rsp], xmm15
000076049b1df288  movaps [rsp+0x10], xmm5
000076049b1df28d  movaps [rsp+0x20], xmm3
000076049b1df292  lea rdi, [rsp]
000076049b1df296  mov esi, 0x00
000076049b1df29b  mov rax, 0x64C06813C530
000076049b1df2a5  call rax
000076049b1df2a7  movaps xmm15, [rsp]
000076049b1df2ac  add rsp, 0x30
000076049b1df2b0  vmovaps xmm0, [rsp]
000076049b1df2b5  vmovaps xmm1, [rsp+0x10]
000076049b1df2bb  vmovaps xmm2, [rsp+0x20]
000076049b1df2c1  vmovaps xmm3, [rsp+0x30]
000076049b1df2c7  vmovaps xmm4, [rsp+0x40]
000076049b1df2cd  vmovaps xmm5, [rsp+0x50]
000076049b1df2d3  vmovaps xmm6, [rsp+0x60]
000076049b1df2d9  vmovaps xmm7, [rsp+0x70]
000076049b1df2df  vmovaps xmm8, [rsp+0x80]
000076049b1df2e8  vmovaps xmm9, [rsp+0x90]
000076049b1df2f1  vmovaps xmm10, [rsp+0xA0]
000076049b1df2fa  vmovaps xmm11, [rsp+0xB0]
000076049b1df303  vmovaps xmm12, [rsp+0xC0]
000076049b1df30c  vmovaps xmm13, [rsp+0xD0]
000076049b1df315  vmovaps xmm14, [rsp+0xE0]
000076049b1df31e  add rsp, 0xF0
000076049b1df325  pop r11
000076049b1df327  pop r10
000076049b1df329  pop r9
000076049b1df32b  pop r8
000076049b1df32d  pop rsi
000076049b1df32e  pop rdi
000076049b1df32f  pop rdx
000076049b1df330  pop rcx
000076049b1df331  pop rax
000076049b1df332  add rsp, 0x08
000076049b1df336  jmp 0x000076049B1DC38F
000076049b1df33b  sub rsp, 0x08
000076049b1df33f  push rax
000076049b1df340  push rcx
000076049b1df341  push rdx
000076049b1df342  push rdi
000076049b1df343  push rsi
000076049b1df344  push r8
000076049b1df346  push r9
000076049b1df348  push r10
000076049b1df34a  push r11
000076049b1df34c  sub rsp, 0xF0
000076049b1df353  vmovaps [rsp], xmm0
000076049b1df358  vmovaps [rsp+0x10], xmm1
000076049b1df35e  vmovaps [rsp+0x20], xmm2
000076049b1df364  vmovaps [rsp+0x30], xmm3
000076049b1df36a  vmovaps [rsp+0x40], xmm4
000076049b1df370  vmovaps [rsp+0x50], xmm6
000076049b1df376  vmovaps [rsp+0x60], xmm7
000076049b1df37c  vmovaps [rsp+0x70], xmm8
000076049b1df382  vmovaps [rsp+0x80], xmm9
000076049b1df38b  vmovaps [rsp+0x90], xmm10
000076049b1df394  vmovaps [rsp+0xA0], xmm11
000076049b1df39d  vmovaps [rsp+0xB0], xmm12
000076049b1df3a6  vmovaps [rsp+0xC0], xmm13
000076049b1df3af  vmovaps [rsp+0xD0], xmm14
000076049b1df3b8  vmovaps [rsp+0xE0], xmm15
000076049b1df3c1  sub rsp, 0x30
000076049b1df3c5  movaps [rsp], xmm5
000076049b1df3c9  movaps [rsp+0x10], xmm8
000076049b1df3cf  movaps [rsp+0x20], xmm6
000076049b1df3d4  lea rdi, [rsp]
000076049b1df3d8  mov esi, 0x00
000076049b1df3dd  mov rax, 0x64C06813C530
000076049b1df3e7  call rax
000076049b1df3e9  movaps xmm5, [rsp]
000076049b1df3ed  add rsp, 0x30
000076049b1df3f1  vmovaps xmm0, [rsp]
000076049b1df3f6  vmovaps xmm1, [rsp+0x10]
000076049b1df3fc  vmovaps xmm2, [rsp+0x20]
000076049b1df402  vmovaps xmm3, [rsp+0x30]
000076049b1df408  vmovaps xmm4, [rsp+0x40]
000076049b1df40e  vmovaps xmm6, [rsp+0x50]
000076049b1df414  vmovaps xmm7, [rsp+0x60]
000076049b1df41a  vmovaps xmm8, [rsp+0x70]
000076049b1df420  vmovaps xmm9, [rsp+0x80]
000076049b1df429  vmovaps xmm10, [rsp+0x90]
000076049b1df432  vmovaps xmm11, [rsp+0xA0]
000076049b1df43b  vmovaps xmm12, [rsp+0xB0]
000076049b1df444  vmovaps xmm13, [rsp+0xC0]
000076049b1df44d  vmovaps xmm14, [rsp+0xD0]
000076049b1df456  vmovaps xmm15, [rsp+0xE0]
000076049b1df45f  add rsp, 0xF0
000076049b1df466  pop r11
000076049b1df468  pop r10
000076049b1df46a  pop r9
000076049b1df46c  pop r8
000076049b1df46e  pop rsi
000076049b1df46f  pop rdi
000076049b1df470  pop rdx
000076049b1df471  pop rcx
000076049b1df472  pop rax
000076049b1df473  add rsp, 0x08
000076049b1df477  jmp 0x000076049B1DC3B3
000076049b1df47c  sub rsp, 0x08
000076049b1df480  push rax
000076049b1df481  push rcx
000076049b1df482  push rdx
000076049b1df483  push rdi
000076049b1df484  push rsi
000076049b1df485  push r8
000076049b1df487  push r9
000076049b1df489  push r10
000076049b1df48b  push r11
000076049b1df48d  sub rsp, 0xF0
000076049b1df494  vmovaps [rsp], xmm0
000076049b1df499  vmovaps [rsp+0x10], xmm1
000076049b1df49f  vmovaps [rsp+0x20], xmm2
000076049b1df4a5  vmovaps [rsp+0x30], xmm3
000076049b1df4ab  vmovaps [rsp+0x40], xmm4
000076049b1df4b1  vmovaps [rsp+0x50], xmm5
000076049b1df4b7  vmovaps [rsp+0x60], xmm7
000076049b1df4bd  vmovaps [rsp+0x70], xmm8
000076049b1df4c3  vmovaps [rsp+0x80], xmm9
000076049b1df4cc  vmovaps [rsp+0x90], xmm10
000076049b1df4d5  vmovaps [rsp+0xA0], xmm11
000076049b1df4de  vmovaps [rsp+0xB0], xmm12
000076049b1df4e7  vmovaps [rsp+0xC0], xmm13
000076049b1df4f0  vmovaps [rsp+0xD0], xmm14
000076049b1df4f9  vmovaps [rsp+0xE0], xmm15
000076049b1df502  sub rsp, 0x30
000076049b1df506  movaps [rsp], xmm6
000076049b1df50a  movaps [rsp+0x10], xmm10
000076049b1df510  movaps [rsp+0x20], xmm8
000076049b1df516  lea rdi, [rsp]
000076049b1df51a  mov esi, 0x00
000076049b1df51f  mov rax, 0x64C06813C530
000076049b1df529  call rax
000076049b1df52b  movaps xmm6, [rsp]
000076049b1df52f  add rsp, 0x30
000076049b1df533  vmovaps xmm0, [rsp]
000076049b1df538  vmovaps xmm1, [rsp+0x10]
000076049b1df53e  vmovaps xmm2, [rsp+0x20]
000076049b1df544  vmovaps xmm3, [rsp+0x30]
000076049b1df54a  vmovaps xmm4, [rsp+0x40]
000076049b1df550  vmovaps xmm5, [rsp+0x50]
000076049b1df556  vmovaps xmm7, [rsp+0x60]
000076049b1df55c  vmovaps xmm8, [rsp+0x70]
000076049b1df562  vmovaps xmm9, [rsp+0x80]
000076049b1df56b  vmovaps xmm10, [rsp+0x90]
000076049b1df574  vmovaps xmm11, [rsp+0xA0]
000076049b1df57d  vmovaps xmm12, [rsp+0xB0]
000076049b1df586  vmovaps xmm13, [rsp+0xC0]
000076049b1df58f  vmovaps xmm14, [rsp+0xD0]
000076049b1df598  vmovaps xmm15, [rsp+0xE0]
000076049b1df5a1  add rsp, 0xF0
000076049b1df5a8  pop r11
000076049b1df5aa  pop r10
000076049b1df5ac  pop r9
000076049b1df5ae  pop r8
000076049b1df5b0  pop rsi
000076049b1df5b1  pop rdi
000076049b1df5b2  pop rdx
000076049b1df5b3  pop rcx
000076049b1df5b4  pop rax
000076049b1df5b5  add rsp, 0x08
000076049b1df5b9  jmp 0x000076049B1DC3D8
000076049b1df5be  sub rsp, 0x08
000076049b1df5c2  push rax
000076049b1df5c3  push rcx
000076049b1df5c4  push rdx
000076049b1df5c5  push rdi
000076049b1df5c6  push rsi
000076049b1df5c7  push r8
000076049b1df5c9  push r9
000076049b1df5cb  push r10
000076049b1df5cd  push r11
000076049b1df5cf  sub rsp, 0xF0
000076049b1df5d6  vmovaps [rsp], xmm0
000076049b1df5db  vmovaps [rsp+0x10], xmm1
000076049b1df5e1  vmovaps [rsp+0x20], xmm2
000076049b1df5e7  vmovaps [rsp+0x30], xmm3
000076049b1df5ed  vmovaps [rsp+0x40], xmm4
000076049b1df5f3  vmovaps [rsp+0x50], xmm5
000076049b1df5f9  vmovaps [rsp+0x60], xmm6
000076049b1df5ff  vmovaps [rsp+0x70], xmm7
000076049b1df605  vmovaps [rsp+0x80], xmm8
000076049b1df60e  vmovaps [rsp+0x90], xmm9
000076049b1df617  vmovaps [rsp+0xA0], xmm11
000076049b1df620  vmovaps [rsp+0xB0], xmm12
000076049b1df629  vmovaps [rsp+0xC0], xmm13
000076049b1df632  vmovaps [rsp+0xD0], xmm14
000076049b1df63b  vmovaps [rsp+0xE0], xmm15
000076049b1df644  sub rsp, 0x30
000076049b1df648  movaps [rsp], xmm10
000076049b1df64d  movaps [rsp+0x10], xmm8
000076049b1df653  movaps [rsp+0x20], xmm14
000076049b1df659  lea rdi, [rsp]
000076049b1df65d  mov esi, 0x00
000076049b1df662  mov rax, 0x64C06813C530
000076049b1df66c  call rax
000076049b1df66e  movaps xmm10, [rsp]
000076049b1df673  add rsp, 0x30
000076049b1df677  vmovaps xmm0, [rsp]
000076049b1df67c  vmovaps xmm1, [rsp+0x10]
000076049b1df682  vmovaps xmm2, [rsp+0x20]
000076049b1df688  vmovaps xmm3, [rsp+0x30]
000076049b1df68e  vmovaps xmm4, [rsp+0x40]
000076049b1df694  vmovaps xmm5, [rsp+0x50]
000076049b1df69a  vmovaps xmm6, [rsp+0x60]
000076049b1df6a0  vmovaps xmm7, [rsp+0x70]
000076049b1df6a6  vmovaps xmm8, [rsp+0x80]
000076049b1df6af  vmovaps xmm9, [rsp+0x90]
000076049b1df6b8  vmovaps xmm11, [rsp+0xA0]
000076049b1df6c1  vmovaps xmm12, [rsp+0xB0]
000076049b1df6ca  vmovaps xmm13, [rsp+0xC0]
000076049b1df6d3  vmovaps xmm14, [rsp+0xD0]
000076049b1df6dc  vmovaps xmm15, [rsp+0xE0]
000076049b1df6e5  add rsp, 0xF0
000076049b1df6ec  pop r11
000076049b1df6ee  pop r10
000076049b1df6f0  pop r9
000076049b1df6f2  pop r8
000076049b1df6f4  pop rsi
000076049b1df6f5  pop rdi
000076049b1df6f6  pop rdx
000076049b1df6f7  pop rcx
000076049b1df6f8  pop rax
000076049b1df6f9  add rsp, 0x08
000076049b1df6fd  jmp 0x000076049B1DC3F8
000076049b1df702  sub rsp, 0x08
000076049b1df706  push rax
000076049b1df707  push rcx
000076049b1df708  push rdx
000076049b1df709  push rdi
000076049b1df70a  push rsi
000076049b1df70b  push r8
000076049b1df70d  push r9
000076049b1df70f  push r10
000076049b1df711  push r11
000076049b1df713  sub rsp, 0xF0
000076049b1df71a  vmovaps [rsp], xmm0
000076049b1df71f  vmovaps [rsp+0x10], xmm1
000076049b1df725  vmovaps [rsp+0x20], xmm2
000076049b1df72b  vmovaps [rsp+0x30], xmm3
000076049b1df731  vmovaps [rsp+0x40], xmm4
000076049b1df737  vmovaps [rsp+0x50], xmm5
000076049b1df73d  vmovaps [rsp+0x60], xmm6
000076049b1df743  vmovaps [rsp+0x70], xmm7
000076049b1df749  vmovaps [rsp+0x80], xmm8
000076049b1df752  vmovaps [rsp+0x90], xmm9
000076049b1df75b  vmovaps [rsp+0xA0], xmm10
000076049b1df764  vmovaps [rsp+0xB0], xmm11
000076049b1df76d  vmovaps [rsp+0xC0], xmm12
000076049b1df776  vmovaps [rsp+0xD0], xmm13
000076049b1df77f  vmovaps [rsp+0xE0], xmm15
000076049b1df788  sub rsp, 0x30
000076049b1df78c  movaps [rsp], xmm14
000076049b1df791  movaps [rsp+0x10], xmm8
000076049b1df797  movaps [rsp+0x20], xmm4
000076049b1df79c  lea rdi, [rsp]
000076049b1df7a0  mov esi, 0x00
000076049b1df7a5  mov rax, 0x64C06813C530
000076049b1df7af  call rax
000076049b1df7b1  movaps xmm14, [rsp]
000076049b1df7b6  add rsp, 0x30
000076049b1df7ba  vmovaps xmm0, [rsp]
000076049b1df7bf  vmovaps xmm1, [rsp+0x10]
000076049b1df7c5  vmovaps xmm2, [rsp+0x20]
000076049b1df7cb  vmovaps xmm3, [rsp+0x30]
000076049b1df7d1  vmovaps xmm4, [rsp+0x40]
000076049b1df7d7  vmovaps xmm5, [rsp+0x50]
000076049b1df7dd  vmovaps xmm6, [rsp+0x60]
000076049b1df7e3  vmovaps xmm7, [rsp+0x70]
000076049b1df7e9  vmovaps xmm8, [rsp+0x80]
000076049b1df7f2  vmovaps xmm9, [rsp+0x90]
000076049b1df7fb  vmovaps xmm10, [rsp+0xA0]
000076049b1df804  vmovaps xmm11, [rsp+0xB0]
000076049b1df80d  vmovaps xmm12, [rsp+0xC0]
000076049b1df816  vmovaps xmm13, [rsp+0xD0]
000076049b1df81f  vmovaps xmm15, [rsp+0xE0]
000076049b1df828  add rsp, 0xF0
000076049b1df82f  pop r11
000076049b1df831  pop r10
000076049b1df833  pop r9
000076049b1df835  pop r8
000076049b1df837  pop rsi
000076049b1df838  pop rdi
000076049b1df839  pop rdx
000076049b1df83a  pop rcx
000076049b1df83b  pop rax
000076049b1df83c  add rsp, 0x08
000076049b1df840  jmp 0x000076049B1DC418
000076049b1df845  sub rsp, 0x08
000076049b1df849  push rax
000076049b1df84a  push rcx
000076049b1df84b  push rdx
000076049b1df84c  push rdi
000076049b1df84d  push rsi
000076049b1df84e  push r8
000076049b1df850  push r9
000076049b1df852  push r10
000076049b1df854  push r11
000076049b1df856  sub rsp, 0xF0
000076049b1df85d  vmovaps [rsp], xmm0
000076049b1df862  vmovaps [rsp+0x10], xmm1
000076049b1df868  vmovaps [rsp+0x20], xmm2
000076049b1df86e  vmovaps [rsp+0x30], xmm3
000076049b1df874  vmovaps [rsp+0x40], xmm5
000076049b1df87a  vmovaps [rsp+0x50], xmm6
000076049b1df880  vmovaps [rsp+0x60], xmm7
000076049b1df886  vmovaps [rsp+0x70], xmm8
000076049b1df88c  vmovaps [rsp+0x80], xmm9
000076049b1df895  vmovaps [rsp+0x90], xmm10
000076049b1df89e  vmovaps [rsp+0xA0], xmm11
000076049b1df8a7  vmovaps [rsp+0xB0], xmm12
000076049b1df8b0  vmovaps [rsp+0xC0], xmm13
000076049b1df8b9  vmovaps [rsp+0xD0], xmm14
000076049b1df8c2  vmovaps [rsp+0xE0], xmm15
000076049b1df8cb  sub rsp, 0x30
000076049b1df8cf  movaps [rsp], xmm4
000076049b1df8d3  movaps [rsp+0x10], xmm13
000076049b1df8d9  movaps [rsp+0x20], xmm8
000076049b1df8df  lea rdi, [rsp]
000076049b1df8e3  mov esi, 0x00
000076049b1df8e8  mov rax, 0x64C06813C530
000076049b1df8f2  call rax
000076049b1df8f4  movaps xmm4, [rsp]
000076049b1df8f8  add rsp, 0x30
000076049b1df8fc  vmovaps xmm0, [rsp]
000076049b1df901  vmovaps xmm1, [rsp+0x10]
000076049b1df907  vmovaps xmm2, [rsp+0x20]
000076049b1df90d  vmovaps xmm3, [rsp+0x30]
000076049b1df913  vmovaps xmm5, [rsp+0x40]
000076049b1df919  vmovaps xmm6, [rsp+0x50]
000076049b1df91f  vmovaps xmm7, [rsp+0x60]
000076049b1df925  vmovaps xmm8, [rsp+0x70]
000076049b1df92b  vmovaps xmm9, [rsp+0x80]
000076049b1df934  vmovaps xmm10, [rsp+0x90]
000076049b1df93d  vmovaps xmm11, [rsp+0xA0]
000076049b1df946  vmovaps xmm12, [rsp+0xB0]
000076049b1df94f  vmovaps xmm13, [rsp+0xC0]
000076049b1df958  vmovaps xmm14, [rsp+0xD0]
000076049b1df961  vmovaps xmm15, [rsp+0xE0]
000076049b1df96a  add rsp, 0xF0
000076049b1df971  pop r11
000076049b1df973  pop r10
000076049b1df975  pop r9
000076049b1df977  pop r8
000076049b1df979  pop rsi
000076049b1df97a  pop rdi
000076049b1df97b  pop rdx
000076049b1df97c  pop rcx
000076049b1df97d  pop rax
000076049b1df97e  add rsp, 0x08
000076049b1df982  jmp 0x000076049B1DC43D
000076049b1df987  sub rsp, 0x08
000076049b1df98b  push rax
000076049b1df98c  push rcx
000076049b1df98d  push rdx
000076049b1df98e  push rdi
000076049b1df98f  push rsi
000076049b1df990  push r8
000076049b1df992  push r9
000076049b1df994  push r10
000076049b1df996  push r11
000076049b1df998  sub rsp, 0xF0
000076049b1df99f  vmovaps [rsp], xmm0
000076049b1df9a4  vmovaps [rsp+0x10], xmm1
000076049b1df9aa  vmovaps [rsp+0x20], xmm2
000076049b1df9b0  vmovaps [rsp+0x30], xmm3
000076049b1df9b6  vmovaps [rsp+0x40], xmm4
000076049b1df9bc  vmovaps [rsp+0x50], xmm5
000076049b1df9c2  vmovaps [rsp+0x60], xmm6
000076049b1df9c8  vmovaps [rsp+0x70], xmm7
000076049b1df9ce  vmovaps [rsp+0x80], xmm8
000076049b1df9d7  vmovaps [rsp+0x90], xmm9
000076049b1df9e0  vmovaps [rsp+0xA0], xmm10
000076049b1df9e9  vmovaps [rsp+0xB0], xmm11
000076049b1df9f2  vmovaps [rsp+0xC0], xmm12
000076049b1df9fb  vmovaps [rsp+0xD0], xmm14
000076049b1dfa04  vmovaps [rsp+0xE0], xmm15
000076049b1dfa0d  sub rsp, 0x30
000076049b1dfa11  movaps [rsp], xmm13
000076049b1dfa16  movaps [rsp+0x10], xmm15
000076049b1dfa1c  movaps [rsp+0x20], xmm9
000076049b1dfa22  lea rdi, [rsp]
000076049b1dfa26  mov esi, 0x00
000076049b1dfa2b  mov rax, 0x64C06813C530
000076049b1dfa35  call rax
000076049b1dfa37  movaps xmm13, [rsp]
000076049b1dfa3c  add rsp, 0x30
000076049b1dfa40  vmovaps xmm0, [rsp]
000076049b1dfa45  vmovaps xmm1, [rsp+0x10]
000076049b1dfa4b  vmovaps xmm2, [rsp+0x20]
000076049b1dfa51  vmovaps xmm3, [rsp+0x30]
000076049b1dfa57  vmovaps xmm4, [rsp+0x40]
000076049b1dfa5d  vmovaps xmm5, [rsp+0x50]
000076049b1dfa63  vmovaps xmm6, [rsp+0x60]
000076049b1dfa69  vmovaps xmm7, [rsp+0x70]
000076049b1dfa6f  vmovaps xmm8, [rsp+0x80]
000076049b1dfa78  vmovaps xmm9, [rsp+0x90]
000076049b1dfa81  vmovaps xmm10, [rsp+0xA0]
000076049b1dfa8a  vmovaps xmm11, [rsp+0xB0]
000076049b1dfa93  vmovaps xmm12, [rsp+0xC0]
000076049b1dfa9c  vmovaps xmm14, [rsp+0xD0]
000076049b1dfaa5  vmovaps xmm15, [rsp+0xE0]
000076049b1dfaae  add rsp, 0xF0
000076049b1dfab5  pop r11
000076049b1dfab7  pop r10
000076049b1dfab9  pop r9
000076049b1dfabb  pop r8
000076049b1dfabd  pop rsi
000076049b1dfabe  pop rdi
000076049b1dfabf  pop rdx
000076049b1dfac0  pop rcx
000076049b1dfac1  pop rax
000076049b1dfac2  add rsp, 0x08
000076049b1dfac6  jmp 0x000076049B1DC458
000076049b1dfacb  sub rsp, 0x08
000076049b1dfacf  push rax
000076049b1dfad0  push rcx
000076049b1dfad1  push rdx
000076049b1dfad2  push rdi
000076049b1dfad3  push rsi
000076049b1dfad4  push r8
000076049b1dfad6  push r9
000076049b1dfad8  push r10
000076049b1dfada  push r11
000076049b1dfadc  sub rsp, 0xF0
000076049b1dfae3  vmovaps [rsp], xmm0
000076049b1dfae8  vmovaps [rsp+0x10], xmm1
000076049b1dfaee  vmovaps [rsp+0x20], xmm2
000076049b1dfaf4  vmovaps [rsp+0x30], xmm3
000076049b1dfafa  vmovaps [rsp+0x40], xmm4
000076049b1dfb00  vmovaps [rsp+0x50], xmm5
000076049b1dfb06  vmovaps [rsp+0x60], xmm6
000076049b1dfb0c  vmovaps [rsp+0x70], xmm7
000076049b1dfb12  vmovaps [rsp+0x80], xmm8
000076049b1dfb1b  vmovaps [rsp+0x90], xmm9
000076049b1dfb24  vmovaps [rsp+0xA0], xmm10
000076049b1dfb2d  vmovaps [rsp+0xB0], xmm11
000076049b1dfb36  vmovaps [rsp+0xC0], xmm12
000076049b1dfb3f  vmovaps [rsp+0xD0], xmm13
000076049b1dfb48  vmovaps [rsp+0xE0], xmm14
000076049b1dfb51  sub rsp, 0x30
000076049b1dfb55  movaps [rsp], xmm15
000076049b1dfb5a  movaps [rsp+0x10], xmm1
000076049b1dfb5f  movaps [rsp+0x20], xmm5
000076049b1dfb64  lea rdi, [rsp]
000076049b1dfb68  mov esi, 0x00
000076049b1dfb6d  mov rax, 0x64C06813C530
000076049b1dfb77  call rax
000076049b1dfb79  movaps xmm15, [rsp]
000076049b1dfb7e  add rsp, 0x30
000076049b1dfb82  vmovaps xmm0, [rsp]
000076049b1dfb87  vmovaps xmm1, [rsp+0x10]
000076049b1dfb8d  vmovaps xmm2, [rsp+0x20]
000076049b1dfb93  vmovaps xmm3, [rsp+0x30]
000076049b1dfb99  vmovaps xmm4, [rsp+0x40]
000076049b1dfb9f  vmovaps xmm5, [rsp+0x50]
000076049b1dfba5  vmovaps xmm6, [rsp+0x60]
000076049b1dfbab  vmovaps xmm7, [rsp+0x70]
000076049b1dfbb1  vmovaps xmm8, [rsp+0x80]
000076049b1dfbba  vmovaps xmm9, [rsp+0x90]
000076049b1dfbc3  vmovaps xmm10, [rsp+0xA0]
000076049b1dfbcc  vmovaps xmm11, [rsp+0xB0]
000076049b1dfbd5  vmovaps xmm12, [rsp+0xC0]
000076049b1dfbde  vmovaps xmm13, [rsp+0xD0]
000076049b1dfbe7  vmovaps xmm14, [rsp+0xE0]
000076049b1dfbf0  add rsp, 0xF0
000076049b1dfbf7  pop r11
000076049b1dfbf9  pop r10
000076049b1dfbfb  pop r9
000076049b1dfbfd  pop r8
000076049b1dfbff  pop rsi
000076049b1dfc00  pop rdi
000076049b1dfc01  pop rdx
000076049b1dfc02  pop rcx
000076049b1dfc03  pop rax
000076049b1dfc04  add rsp, 0x08
000076049b1dfc08  jmp 0x000076049B1DC473
000076049b1dfc0d  call 0x000076049B0B52F0
000076049b1dfc12  jmp 0x000076049B1DC4CE
000076049b1dfc17  sub rsp, 0x08
000076049b1dfc1b  push rax
000076049b1dfc1c  push rcx
000076049b1dfc1d  push rdx
000076049b1dfc1e  push rdi
000076049b1dfc1f  push rsi
000076049b1dfc20  push r8
000076049b1dfc22  push r9
000076049b1dfc24  push r10
000076049b1dfc26  push r11
000076049b1dfc28  sub rsp, 0xF0
000076049b1dfc2f  vmovaps [rsp], xmm0
000076049b1dfc34  vmovaps [rsp+0x10], xmm1
000076049b1dfc3a  vmovaps [rsp+0x20], xmm2
000076049b1dfc40  vmovaps [rsp+0x30], xmm3
000076049b1dfc46  vmovaps [rsp+0x40], xmm4
000076049b1dfc4c  vmovaps [rsp+0x50], xmm5
000076049b1dfc52  vmovaps [rsp+0x60], xmm6
000076049b1dfc58  vmovaps [rsp+0x70], xmm7
000076049b1dfc5e  vmovaps [rsp+0x80], xmm8
000076049b1dfc67  vmovaps [rsp+0x90], xmm10
000076049b1dfc70  vmovaps [rsp+0xA0], xmm11
000076049b1dfc79  vmovaps [rsp+0xB0], xmm12
000076049b1dfc82  vmovaps [rsp+0xC0], xmm13
000076049b1dfc8b  vmovaps [rsp+0xD0], xmm14
000076049b1dfc94  vmovaps [rsp+0xE0], xmm15
000076049b1dfc9d  sub rsp, 0x30
000076049b1dfca1  movaps [rsp], xmm9
000076049b1dfca6  movaps [rsp+0x10], xmm8
000076049b1dfcac  movaps [rsp+0x20], xmm11
000076049b1dfcb2  lea rdi, [rsp]
000076049b1dfcb6  mov esi, 0x00
000076049b1dfcbb  mov rax, 0x64C06813C530
000076049b1dfcc5  call rax
000076049b1dfcc7  movaps xmm9, [rsp]
000076049b1dfccc  add rsp, 0x30
000076049b1dfcd0  vmovaps xmm0, [rsp]
000076049b1dfcd5  vmovaps xmm1, [rsp+0x10]
000076049b1dfcdb  vmovaps xmm2, [rsp+0x20]
000076049b1dfce1  vmovaps xmm3, [rsp+0x30]
000076049b1dfce7  vmovaps xmm4, [rsp+0x40]
000076049b1dfced  vmovaps xmm5, [rsp+0x50]
000076049b1dfcf3  vmovaps xmm6, [rsp+0x60]
000076049b1dfcf9  vmovaps xmm7, [rsp+0x70]
000076049b1dfcff  vmovaps xmm8, [rsp+0x80]
000076049b1dfd08  vmovaps xmm10, [rsp+0x90]
000076049b1dfd11  vmovaps xmm11, [rsp+0xA0]
000076049b1dfd1a  vmovaps xmm12, [rsp+0xB0]
000076049b1dfd23  vmovaps xmm13, [rsp+0xC0]
000076049b1dfd2c  vmovaps xmm14, [rsp+0xD0]
000076049b1dfd35  vmovaps xmm15, [rsp+0xE0]
000076049b1dfd3e  add rsp, 0xF0
000076049b1dfd45  pop r11
000076049b1dfd47  pop r10
000076049b1dfd49  pop r9
000076049b1dfd4b  pop r8
000076049b1dfd4d  pop rsi
000076049b1dfd4e  pop rdi
000076049b1dfd4f  pop rdx
000076049b1dfd50  pop rcx
000076049b1dfd51  pop rax
000076049b1dfd52  add rsp, 0x08
000076049b1dfd56  jmp 0x000076049B1DC505
000076049b1dfd5b  sub rsp, 0x08
000076049b1dfd5f  push rax
000076049b1dfd60  push rcx
000076049b1dfd61  push rdx
000076049b1dfd62  push rdi
000076049b1dfd63  push rsi
000076049b1dfd64  push r8
000076049b1dfd66  push r9
000076049b1dfd68  push r10
000076049b1dfd6a  push r11
000076049b1dfd6c  sub rsp, 0xF0
000076049b1dfd73  vmovaps [rsp], xmm0
000076049b1dfd78  vmovaps [rsp+0x10], xmm1
000076049b1dfd7e  vmovaps [rsp+0x20], xmm2
000076049b1dfd84  vmovaps [rsp+0x30], xmm3
000076049b1dfd8a  vmovaps [rsp+0x40], xmm4
000076049b1dfd90  vmovaps [rsp+0x50], xmm5
000076049b1dfd96  vmovaps [rsp+0x60], xmm6
000076049b1dfd9c  vmovaps [rsp+0x70], xmm7
000076049b1dfda2  vmovaps [rsp+0x80], xmm8
000076049b1dfdab  vmovaps [rsp+0x90], xmm9
000076049b1dfdb4  vmovaps [rsp+0xA0], xmm10
000076049b1dfdbd  vmovaps [rsp+0xB0], xmm12
000076049b1dfdc6  vmovaps [rsp+0xC0], xmm13
000076049b1dfdcf  vmovaps [rsp+0xD0], xmm14
000076049b1dfdd8  vmovaps [rsp+0xE0], xmm15
000076049b1dfde1  sub rsp, 0x30
000076049b1dfde5  movaps [rsp], xmm11
000076049b1dfdea  movaps [rsp+0x10], xmm10
000076049b1dfdf0  movaps [rsp+0x20], xmm6
000076049b1dfdf5  lea rdi, [rsp]
000076049b1dfdf9  mov esi, 0x00
000076049b1dfdfe  mov rax, 0x64C06813C530
000076049b1dfe08  call rax
000076049b1dfe0a  movaps xmm11, [rsp]
000076049b1dfe0f  add rsp, 0x30
000076049b1dfe13  vmovaps xmm0, [rsp]
000076049b1dfe18  vmovaps xmm1, [rsp+0x10]
000076049b1dfe1e  vmovaps xmm2, [rsp+0x20]
000076049b1dfe24  vmovaps xmm3, [rsp+0x30]
000076049b1dfe2a  vmovaps xmm4, [rsp+0x40]
000076049b1dfe30  vmovaps xmm5, [rsp+0x50]
000076049b1dfe36  vmovaps xmm6, [rsp+0x60]
000076049b1dfe3c  vmovaps xmm7, [rsp+0x70]
000076049b1dfe42  vmovaps xmm8, [rsp+0x80]
000076049b1dfe4b  vmovaps xmm9, [rsp+0x90]
000076049b1dfe54  vmovaps xmm10, [rsp+0xA0]
000076049b1dfe5d  vmovaps xmm12, [rsp+0xB0]
000076049b1dfe66  vmovaps xmm13, [rsp+0xC0]
000076049b1dfe6f  vmovaps xmm14, [rsp+0xD0]
000076049b1dfe78  vmovaps xmm15, [rsp+0xE0]
000076049b1dfe81  add rsp, 0xF0
000076049b1dfe88  pop r11
000076049b1dfe8a  pop r10
000076049b1dfe8c  pop r9
000076049b1dfe8e  pop r8
000076049b1dfe90  pop rsi
000076049b1dfe91  pop rdi
000076049b1dfe92  pop rdx
000076049b1dfe93  pop rcx
000076049b1dfe94  pop rax
000076049b1dfe95  add rsp, 0x08
000076049b1dfe99  jmp 0x000076049B1DC520
000076049b1dfe9e  sub rsp, 0x08
000076049b1dfea2  push rax
000076049b1dfea3  push rcx
000076049b1dfea4  push rdx
000076049b1dfea5  push rdi
000076049b1dfea6  push rsi
000076049b1dfea7  push r8
000076049b1dfea9  push r9
000076049b1dfeab  push r10
000076049b1dfead  push r11
000076049b1dfeaf  sub rsp, 0xF0
000076049b1dfeb6  vmovaps [rsp], xmm0
000076049b1dfebb  vmovaps [rsp+0x10], xmm1
000076049b1dfec1  vmovaps [rsp+0x20], xmm2
000076049b1dfec7  vmovaps [rsp+0x30], xmm3
000076049b1dfecd  vmovaps [rsp+0x40], xmm4
000076049b1dfed3  vmovaps [rsp+0x50], xmm5
000076049b1dfed9  vmovaps [rsp+0x60], xmm6
000076049b1dfedf  vmovaps [rsp+0x70], xmm7
000076049b1dfee5  vmovaps [rsp+0x80], xmm8
000076049b1dfeee  vmovaps [rsp+0x90], xmm9
000076049b1dfef7  vmovaps [rsp+0xA0], xmm11
000076049b1dff00  vmovaps [rsp+0xB0], xmm12
000076049b1dff09  vmovaps [rsp+0xC0], xmm13
000076049b1dff12  vmovaps [rsp+0xD0], xmm14
000076049b1dff1b  vmovaps [rsp+0xE0], xmm15
000076049b1dff24  sub rsp, 0x30
000076049b1dff28  movaps [rsp], xmm10
000076049b1dff2d  movaps [rsp+0x10], xmm14
000076049b1dff33  movaps [rsp+0x20], xmm4
000076049b1dff38  lea rdi, [rsp]
000076049b1dff3c  mov esi, 0x00
000076049b1dff41  mov rax, 0x64C06813C530
000076049b1dff4b  call rax
000076049b1dff4d  movaps xmm10, [rsp]
000076049b1dff52  add rsp, 0x30
000076049b1dff56  vmovaps xmm0, [rsp]
000076049b1dff5b  vmovaps xmm1, [rsp+0x10]
000076049b1dff61  vmovaps xmm2, [rsp+0x20]
000076049b1dff67  vmovaps xmm3, [rsp+0x30]
000076049b1dff6d  vmovaps xmm4, [rsp+0x40]
000076049b1dff73  vmovaps xmm5, [rsp+0x50]
000076049b1dff79  vmovaps xmm6, [rsp+0x60]
000076049b1dff7f  vmovaps xmm7, [rsp+0x70]
000076049b1dff85  vmovaps xmm8, [rsp+0x80]
000076049b1dff8e  vmovaps xmm9, [rsp+0x90]
000076049b1dff97  vmovaps xmm11, [rsp+0xA0]
000076049b1dffa0  vmovaps xmm12, [rsp+0xB0]
000076049b1dffa9  vmovaps xmm13, [rsp+0xC0]
000076049b1dffb2  vmovaps xmm14, [rsp+0xD0]
000076049b1dffbb  vmovaps xmm15, [rsp+0xE0]
000076049b1dffc4  add rsp, 0xF0
000076049b1dffcb  pop r11
000076049b1dffcd  pop r10
000076049b1dffcf  pop r9
000076049b1dffd1  pop r8
000076049b1dffd3  pop rsi
000076049b1dffd4  pop rdi
000076049b1dffd5  pop rdx
000076049b1dffd6  pop rcx
000076049b1dffd7  pop rax
000076049b1dffd8  add rsp, 0x08
000076049b1dffdc  jmp 0x000076049B1DC53B
000076049b1dffe1  sub rsp, 0x08
000076049b1dffe5  push rax
000076049b1dffe6  push rcx
000076049b1dffe7  push rdx
000076049b1dffe8  push rdi
000076049b1dffe9  push rsi
000076049b1dffea  push r8
000076049b1dffec  push r9
000076049b1dffee  push r10
000076049b1dfff0  push r11
000076049b1dfff2  sub rsp, 0xF0
000076049b1dfff9  vmovaps [rsp], xmm0
000076049b1dfffe  vmovaps [rsp+0x10], xmm1
000076049b1e0004  vmovaps [rsp+0x20], xmm2
000076049b1e000a  vmovaps [rsp+0x30], xmm3
000076049b1e0010  vmovaps [rsp+0x40], xmm4
000076049b1e0016  vmovaps [rsp+0x50], xmm5
000076049b1e001c  vmovaps [rsp+0x60], xmm6
000076049b1e0022  vmovaps [rsp+0x70], xmm7
000076049b1e0028  vmovaps [rsp+0x80], xmm9
000076049b1e0031  vmovaps [rsp+0x90], xmm10
000076049b1e003a  vmovaps [rsp+0xA0], xmm11
000076049b1e0043  vmovaps [rsp+0xB0], xmm12
000076049b1e004c  vmovaps [rsp+0xC0], xmm13
000076049b1e0055  vmovaps [rsp+0xD0], xmm14
000076049b1e005e  vmovaps [rsp+0xE0], xmm15
000076049b1e0067  sub rsp, 0x30
000076049b1e006b  movaps [rsp], xmm8
000076049b1e0070  movaps [rsp+0x10], xmm1
000076049b1e0075  movaps [rsp+0x20], xmm14
000076049b1e007b  lea rdi, [rsp]
000076049b1e007f  mov esi, 0x00
000076049b1e0084  mov rax, 0x64C06813C530
000076049b1e008e  call rax
000076049b1e0090  movaps xmm8, [rsp]
000076049b1e0095  add rsp, 0x30
000076049b1e0099  vmovaps xmm0, [rsp]
000076049b1e009e  vmovaps xmm1, [rsp+0x10]
000076049b1e00a4  vmovaps xmm2, [rsp+0x20]
000076049b1e00aa  vmovaps xmm3, [rsp+0x30]
000076049b1e00b0  vmovaps xmm4, [rsp+0x40]
000076049b1e00b6  vmovaps xmm5, [rsp+0x50]
000076049b1e00bc  vmovaps xmm6, [rsp+0x60]
000076049b1e00c2  vmovaps xmm7, [rsp+0x70]
000076049b1e00c8  vmovaps xmm9, [rsp+0x80]
000076049b1e00d1  vmovaps xmm10, [rsp+0x90]
000076049b1e00da  vmovaps xmm11, [rsp+0xA0]
000076049b1e00e3  vmovaps xmm12, [rsp+0xB0]
000076049b1e00ec  vmovaps xmm13, [rsp+0xC0]
000076049b1e00f5  vmovaps xmm14, [rsp+0xD0]
000076049b1e00fe  vmovaps xmm15, [rsp+0xE0]
000076049b1e0107  add rsp, 0xF0
000076049b1e010e  pop r11
000076049b1e0110  pop r10
000076049b1e0112  pop r9
000076049b1e0114  pop r8
000076049b1e0116  pop rsi
000076049b1e0117  pop rdi
000076049b1e0118  pop rdx
000076049b1e0119  pop rcx
000076049b1e011a  pop rax
000076049b1e011b  add rsp, 0x08
000076049b1e011f  jmp 0x000076049B1DC561
000076049b1e0124  sub rsp, 0x08
000076049b1e0128  push rax
000076049b1e0129  push rcx
000076049b1e012a  push rdx
000076049b1e012b  push rdi
000076049b1e012c  push rsi
000076049b1e012d  push r8
000076049b1e012f  push r9
000076049b1e0131  push r10
000076049b1e0133  push r11
000076049b1e0135  sub rsp, 0xF0
000076049b1e013c  vmovaps [rsp], xmm0
000076049b1e0141  vmovaps [rsp+0x10], xmm1
000076049b1e0147  vmovaps [rsp+0x20], xmm2
000076049b1e014d  vmovaps [rsp+0x30], xmm3
000076049b1e0153  vmovaps [rsp+0x40], xmm4
000076049b1e0159  vmovaps [rsp+0x50], xmm5
000076049b1e015f  vmovaps [rsp+0x60], xmm7
000076049b1e0165  vmovaps [rsp+0x70], xmm8
000076049b1e016b  vmovaps [rsp+0x80], xmm9
000076049b1e0174  vmovaps [rsp+0x90], xmm10
000076049b1e017d  vmovaps [rsp+0xA0], xmm11
000076049b1e0186  vmovaps [rsp+0xB0], xmm12
000076049b1e018f  vmovaps [rsp+0xC0], xmm13
000076049b1e0198  vmovaps [rsp+0xD0], xmm14
000076049b1e01a1  vmovaps [rsp+0xE0], xmm15
000076049b1e01aa  sub rsp, 0x30
000076049b1e01ae  movaps [rsp], xmm6
000076049b1e01b2  movaps [rsp+0x10], xmm1
000076049b1e01b7  movaps [rsp+0x20], xmm14
000076049b1e01bd  lea rdi, [rsp]
000076049b1e01c1  mov esi, 0x00
000076049b1e01c6  mov rax, 0x64C06813C530
000076049b1e01d0  call rax
000076049b1e01d2  movaps xmm6, [rsp]
000076049b1e01d6  add rsp, 0x30
000076049b1e01da  vmovaps xmm0, [rsp]
000076049b1e01df  vmovaps xmm1, [rsp+0x10]
000076049b1e01e5  vmovaps xmm2, [rsp+0x20]
000076049b1e01eb  vmovaps xmm3, [rsp+0x30]
000076049b1e01f1  vmovaps xmm4, [rsp+0x40]
000076049b1e01f7  vmovaps xmm5, [rsp+0x50]
000076049b1e01fd  vmovaps xmm7, [rsp+0x60]
000076049b1e0203  vmovaps xmm8, [rsp+0x70]
000076049b1e0209  vmovaps xmm9, [rsp+0x80]
000076049b1e0212  vmovaps xmm10, [rsp+0x90]
000076049b1e021b  vmovaps xmm11, [rsp+0xA0]
000076049b1e0224  vmovaps xmm12, [rsp+0xB0]
000076049b1e022d  vmovaps xmm13, [rsp+0xC0]
000076049b1e0236  vmovaps xmm14, [rsp+0xD0]
000076049b1e023f  vmovaps xmm15, [rsp+0xE0]
000076049b1e0248  add rsp, 0xF0
000076049b1e024f  pop r11
000076049b1e0251  pop r10
000076049b1e0253  pop r9
000076049b1e0255  pop r8
000076049b1e0257  pop rsi
000076049b1e0258  pop rdi
000076049b1e0259  pop rdx
000076049b1e025a  pop rcx
000076049b1e025b  pop rax
000076049b1e025c  add rsp, 0x08
000076049b1e0260  jmp 0x000076049B1DC58D
000076049b1e0265  sub rsp, 0x08
000076049b1e0269  push rax
000076049b1e026a  push rcx
000076049b1e026b  push rdx
000076049b1e026c  push rdi
000076049b1e026d  push rsi
000076049b1e026e  push r8
000076049b1e0270  push r9
000076049b1e0272  push r10
000076049b1e0274  push r11
000076049b1e0276  sub rsp, 0xF0
000076049b1e027d  vmovaps [rsp], xmm0
000076049b1e0282  vmovaps [rsp+0x10], xmm1
000076049b1e0288  vmovaps [rsp+0x20], xmm2
000076049b1e028e  vmovaps [rsp+0x30], xmm3
000076049b1e0294  vmovaps [rsp+0x40], xmm4
000076049b1e029a  vmovaps [rsp+0x50], xmm5
000076049b1e02a0  vmovaps [rsp+0x60], xmm6
000076049b1e02a6  vmovaps [rsp+0x70], xmm7
000076049b1e02ac  vmovaps [rsp+0x80], xmm8
000076049b1e02b5  vmovaps [rsp+0x90], xmm9
000076049b1e02be  vmovaps [rsp+0xA0], xmm10
000076049b1e02c7  vmovaps [rsp+0xB0], xmm11
000076049b1e02d0  vmovaps [rsp+0xC0], xmm12
000076049b1e02d9  vmovaps [rsp+0xD0], xmm13
000076049b1e02e2  vmovaps [rsp+0xE0], xmm15
000076049b1e02eb  sub rsp, 0x30
000076049b1e02ef  movaps [rsp], xmm14
000076049b1e02f4  movaps [rsp+0x10], xmm12
000076049b1e02fa  movaps [rsp+0x20], xmm1
000076049b1e02ff  lea rdi, [rsp]
000076049b1e0303  mov esi, 0x00
000076049b1e0308  mov rax, 0x64C06813C530
000076049b1e0312  call rax
000076049b1e0314  movaps xmm14, [rsp]
000076049b1e0319  add rsp, 0x30
000076049b1e031d  vmovaps xmm0, [rsp]
000076049b1e0322  vmovaps xmm1, [rsp+0x10]
000076049b1e0328  vmovaps xmm2, [rsp+0x20]
000076049b1e032e  vmovaps xmm3, [rsp+0x30]
000076049b1e0334  vmovaps xmm4, [rsp+0x40]
000076049b1e033a  vmovaps xmm5, [rsp+0x50]
000076049b1e0340  vmovaps xmm6, [rsp+0x60]
000076049b1e0346  vmovaps xmm7, [rsp+0x70]
000076049b1e034c  vmovaps xmm8, [rsp+0x80]
000076049b1e0355  vmovaps xmm9, [rsp+0x90]
000076049b1e035e  vmovaps xmm10, [rsp+0xA0]
000076049b1e0367  vmovaps xmm11, [rsp+0xB0]
000076049b1e0370  vmovaps xmm12, [rsp+0xC0]
000076049b1e0379  vmovaps xmm13, [rsp+0xD0]
000076049b1e0382  vmovaps xmm15, [rsp+0xE0]
000076049b1e038b  add rsp, 0xF0
000076049b1e0392  pop r11
000076049b1e0394  pop r10
000076049b1e0396  pop r9
000076049b1e0398  pop r8
000076049b1e039a  pop rsi
000076049b1e039b  pop rdi
000076049b1e039c  pop rdx
000076049b1e039d  pop rcx
000076049b1e039e  pop rax
000076049b1e039f  add rsp, 0x08
000076049b1e03a3  jmp 0x000076049B1DC5B3
000076049b1e03a8  sub rsp, 0x08
000076049b1e03ac  push rax
000076049b1e03ad  push rcx
000076049b1e03ae  push rdx
000076049b1e03af  push rdi
000076049b1e03b0  push rsi
000076049b1e03b1  push r8
000076049b1e03b3  push r9
000076049b1e03b5  push r10
000076049b1e03b7  push r11
000076049b1e03b9  sub rsp, 0xF0
000076049b1e03c0  vmovaps [rsp], xmm0
000076049b1e03c5  vmovaps [rsp+0x10], xmm2
000076049b1e03cb  vmovaps [rsp+0x20], xmm3
000076049b1e03d1  vmovaps [rsp+0x30], xmm4
000076049b1e03d7  vmovaps [rsp+0x40], xmm5
000076049b1e03dd  vmovaps [rsp+0x50], xmm6
000076049b1e03e3  vmovaps [rsp+0x60], xmm7
000076049b1e03e9  vmovaps [rsp+0x70], xmm8
000076049b1e03ef  vmovaps [rsp+0x80], xmm9
000076049b1e03f8  vmovaps [rsp+0x90], xmm10
000076049b1e0401  vmovaps [rsp+0xA0], xmm11
000076049b1e040a  vmovaps [rsp+0xB0], xmm12
000076049b1e0413  vmovaps [rsp+0xC0], xmm13
000076049b1e041c  vmovaps [rsp+0xD0], xmm14
000076049b1e0425  vmovaps [rsp+0xE0], xmm15
000076049b1e042e  sub rsp, 0x30
000076049b1e0432  movaps [rsp], xmm1
000076049b1e0436  movaps [rsp+0x10], xmm13
000076049b1e043c  movaps [rsp+0x20], xmm9
000076049b1e0442  lea rdi, [rsp]
000076049b1e0446  mov esi, 0x00
000076049b1e044b  mov rax, 0x64C06813C530
000076049b1e0455  call rax
000076049b1e0457  movaps xmm1, [rsp]
000076049b1e045b  add rsp, 0x30
000076049b1e045f  vmovaps xmm0, [rsp]
000076049b1e0464  vmovaps xmm2, [rsp+0x10]
000076049b1e046a  vmovaps xmm3, [rsp+0x20]
000076049b1e0470  vmovaps xmm4, [rsp+0x30]
000076049b1e0476  vmovaps xmm5, [rsp+0x40]
000076049b1e047c  vmovaps xmm6, [rsp+0x50]
000076049b1e0482  vmovaps xmm7, [rsp+0x60]
000076049b1e0488  vmovaps xmm8, [rsp+0x70]
000076049b1e048e  vmovaps xmm9, [rsp+0x80]
000076049b1e0497  vmovaps xmm10, [rsp+0x90]
000076049b1e04a0  vmovaps xmm11, [rsp+0xA0]
000076049b1e04a9  vmovaps xmm12, [rsp+0xB0]
000076049b1e04b2  vmovaps xmm13, [rsp+0xC0]
000076049b1e04bb  vmovaps xmm14, [rsp+0xD0]
000076049b1e04c4  vmovaps xmm15, [rsp+0xE0]
000076049b1e04cd  add rsp, 0xF0
000076049b1e04d4  pop r11
000076049b1e04d6  pop r10
000076049b1e04d8  pop r9
000076049b1e04da  pop r8
000076049b1e04dc  pop rsi
000076049b1e04dd  pop rdi
000076049b1e04de  pop rdx
000076049b1e04df  pop rcx
000076049b1e04e0  pop rax
000076049b1e04e1  add rsp, 0x08
000076049b1e04e5  jmp 0x000076049B1DC5CD
000076049b1e04ea  sub rsp, 0x08
000076049b1e04ee  push rax
000076049b1e04ef  push rcx
000076049b1e04f0  push rdx
000076049b1e04f1  push rdi
000076049b1e04f2  push rsi
000076049b1e04f3  push r8
000076049b1e04f5  push r9
000076049b1e04f7  push r10
000076049b1e04f9  push r11
000076049b1e04fb  sub rsp, 0xF0
000076049b1e0502  vmovaps [rsp], xmm0
000076049b1e0507  vmovaps [rsp+0x10], xmm1
000076049b1e050d  vmovaps [rsp+0x20], xmm2
000076049b1e0513  vmovaps [rsp+0x30], xmm3
000076049b1e0519  vmovaps [rsp+0x40], xmm4
000076049b1e051f  vmovaps [rsp+0x50], xmm5
000076049b1e0525  vmovaps [rsp+0x60], xmm6
000076049b1e052b  vmovaps [rsp+0x70], xmm7
000076049b1e0531  vmovaps [rsp+0x80], xmm8
000076049b1e053a  vmovaps [rsp+0x90], xmm9
000076049b1e0543  vmovaps [rsp+0xA0], xmm10
000076049b1e054c  vmovaps [rsp+0xB0], xmm11
000076049b1e0555  vmovaps [rsp+0xC0], xmm13
000076049b1e055e  vmovaps [rsp+0xD0], xmm14
000076049b1e0567  vmovaps [rsp+0xE0], xmm15
000076049b1e0570  sub rsp, 0x30
000076049b1e0574  movaps [rsp], xmm12
000076049b1e0579  movaps [rsp+0x10], xmm7
000076049b1e057e  movaps [rsp+0x20], xmm13
000076049b1e0584  lea rdi, [rsp]
000076049b1e0588  mov esi, 0x00
000076049b1e058d  mov rax, 0x64C06813C530
000076049b1e0597  call rax
000076049b1e0599  movaps xmm12, [rsp]
000076049b1e059e  add rsp, 0x30
000076049b1e05a2  vmovaps xmm0, [rsp]
000076049b1e05a7  vmovaps xmm1, [rsp+0x10]
000076049b1e05ad  vmovaps xmm2, [rsp+0x20]
000076049b1e05b3  vmovaps xmm3, [rsp+0x30]
000076049b1e05b9  vmovaps xmm4, [rsp+0x40]
000076049b1e05bf  vmovaps xmm5, [rsp+0x50]
000076049b1e05c5  vmovaps xmm6, [rsp+0x60]
000076049b1e05cb  vmovaps xmm7, [rsp+0x70]
000076049b1e05d1  vmovaps xmm8, [rsp+0x80]
000076049b1e05da  vmovaps xmm9, [rsp+0x90]
000076049b1e05e3  vmovaps xmm10, [rsp+0xA0]
000076049b1e05ec  vmovaps xmm11, [rsp+0xB0]
000076049b1e05f5  vmovaps xmm13, [rsp+0xC0]
000076049b1e05fe  vmovaps xmm14, [rsp+0xD0]
000076049b1e0607  vmovaps xmm15, [rsp+0xE0]
000076049b1e0610  add rsp, 0xF0
000076049b1e0617  pop r11
000076049b1e0619  pop r10
000076049b1e061b  pop r9
000076049b1e061d  pop r8
000076049b1e061f  pop rsi
000076049b1e0620  pop rdi
000076049b1e0621  pop rdx
000076049b1e0622  pop rcx
000076049b1e0623  pop rax
000076049b1e0624  add rsp, 0x08
000076049b1e0628  jmp 0x000076049B1DC5F4
000076049b1e062d  sub rsp, 0x08
000076049b1e0631  push rax
000076049b1e0632  push rcx
000076049b1e0633  push rdx
000076049b1e0634  push rdi
000076049b1e0635  push rsi
000076049b1e0636  push r8
000076049b1e0638  push r9
000076049b1e063a  push r10
000076049b1e063c  push r11
000076049b1e063e  sub rsp, 0xF0
000076049b1e0645  vmovaps [rsp], xmm0
000076049b1e064a  vmovaps [rsp+0x10], xmm1
000076049b1e0650  vmovaps [rsp+0x20], xmm2
000076049b1e0656  vmovaps [rsp+0x30], xmm3
000076049b1e065c  vmovaps [rsp+0x40], xmm4
000076049b1e0662  vmovaps [rsp+0x50], xmm5
000076049b1e0668  vmovaps [rsp+0x60], xmm6
000076049b1e066e  vmovaps [rsp+0x70], xmm7
000076049b1e0674  vmovaps [rsp+0x80], xmm8
000076049b1e067d  vmovaps [rsp+0x90], xmm9
000076049b1e0686  vmovaps [rsp+0xA0], xmm10
000076049b1e068f  vmovaps [rsp+0xB0], xmm11
000076049b1e0698  vmovaps [rsp+0xC0], xmm12
000076049b1e06a1  vmovaps [rsp+0xD0], xmm14
000076049b1e06aa  vmovaps [rsp+0xE0], xmm15
000076049b1e06b3  sub rsp, 0x30
000076049b1e06b7  movaps [rsp], xmm13
000076049b1e06bc  movaps [rsp+0x10], xmm15
000076049b1e06c2  movaps [rsp+0x20], xmm8
000076049b1e06c8  lea rdi, [rsp]
000076049b1e06cc  mov esi, 0x00
000076049b1e06d1  mov rax, 0x64C06813C530
000076049b1e06db  call rax
000076049b1e06dd  movaps xmm13, [rsp]
000076049b1e06e2  add rsp, 0x30
000076049b1e06e6  vmovaps xmm0, [rsp]
000076049b1e06eb  vmovaps xmm1, [rsp+0x10]
000076049b1e06f1  vmovaps xmm2, [rsp+0x20]
000076049b1e06f7  vmovaps xmm3, [rsp+0x30]
000076049b1e06fd  vmovaps xmm4, [rsp+0x40]
000076049b1e0703  vmovaps xmm5, [rsp+0x50]
000076049b1e0709  vmovaps xmm6, [rsp+0x60]
000076049b1e070f  vmovaps xmm7, [rsp+0x70]
000076049b1e0715  vmovaps xmm8, [rsp+0x80]
000076049b1e071e  vmovaps xmm9, [rsp+0x90]
000076049b1e0727  vmovaps xmm10, [rsp+0xA0]
000076049b1e0730  vmovaps xmm11, [rsp+0xB0]
000076049b1e0739  vmovaps xmm12, [rsp+0xC0]
000076049b1e0742  vmovaps xmm14, [rsp+0xD0]
000076049b1e074b  vmovaps xmm15, [rsp+0xE0]
000076049b1e0754  add rsp, 0xF0
000076049b1e075b  pop r11
000076049b1e075d  pop r10
000076049b1e075f  pop r9
000076049b1e0761  pop r8
000076049b1e0763  pop rsi
000076049b1e0764  pop rdi
000076049b1e0765  pop rdx
000076049b1e0766  pop rcx
000076049b1e0767  pop rax
000076049b1e0768  add rsp, 0x08
000076049b1e076c  jmp 0x000076049B1DC60F
000076049b1e0771  sub rsp, 0x08
000076049b1e0775  push rax
000076049b1e0776  push rcx
000076049b1e0777  push rdx
000076049b1e0778  push rdi
000076049b1e0779  push rsi
000076049b1e077a  push r8
000076049b1e077c  push r9
000076049b1e077e  push r10
000076049b1e0780  push r11
000076049b1e0782  sub rsp, 0xF0
000076049b1e0789  vmovaps [rsp], xmm0
000076049b1e078e  vmovaps [rsp+0x10], xmm1
000076049b1e0794  vmovaps [rsp+0x20], xmm2
000076049b1e079a  vmovaps [rsp+0x30], xmm3
000076049b1e07a0  vmovaps [rsp+0x40], xmm4
000076049b1e07a6  vmovaps [rsp+0x50], xmm5
000076049b1e07ac  vmovaps [rsp+0x60], xmm6
000076049b1e07b2  vmovaps [rsp+0x70], xmm7
000076049b1e07b8  vmovaps [rsp+0x80], xmm9
000076049b1e07c1  vmovaps [rsp+0x90], xmm10
000076049b1e07ca  vmovaps [rsp+0xA0], xmm11
000076049b1e07d3  vmovaps [rsp+0xB0], xmm12
000076049b1e07dc  vmovaps [rsp+0xC0], xmm13
000076049b1e07e5  vmovaps [rsp+0xD0], xmm14
000076049b1e07ee  vmovaps [rsp+0xE0], xmm15
000076049b1e07f7  sub rsp, 0x30
000076049b1e07fb  movaps [rsp], xmm8
000076049b1e0800  movaps [rsp+0x10], xmm15
000076049b1e0806  movaps [rsp+0x20], xmm9
000076049b1e080c  lea rdi, [rsp]
000076049b1e0810  mov esi, 0x00
000076049b1e0815  mov rax, 0x64C06813C530
000076049b1e081f  call rax
000076049b1e0821  movaps xmm8, [rsp]
000076049b1e0826  add rsp, 0x30
000076049b1e082a  vmovaps xmm0, [rsp]
000076049b1e082f  vmovaps xmm1, [rsp+0x10]
000076049b1e0835  vmovaps xmm2, [rsp+0x20]
000076049b1e083b  vmovaps xmm3, [rsp+0x30]
000076049b1e0841  vmovaps xmm4, [rsp+0x40]
000076049b1e0847  vmovaps xmm5, [rsp+0x50]
000076049b1e084d  vmovaps xmm6, [rsp+0x60]
000076049b1e0853  vmovaps xmm7, [rsp+0x70]
000076049b1e0859  vmovaps xmm9, [rsp+0x80]
000076049b1e0862  vmovaps xmm10, [rsp+0x90]
000076049b1e086b  vmovaps xmm11, [rsp+0xA0]
000076049b1e0874  vmovaps xmm12, [rsp+0xB0]
000076049b1e087d  vmovaps xmm13, [rsp+0xC0]
000076049b1e0886  vmovaps xmm14, [rsp+0xD0]
000076049b1e088f  vmovaps xmm15, [rsp+0xE0]
000076049b1e0898  add rsp, 0xF0
000076049b1e089f  pop r11
000076049b1e08a1  pop r10
000076049b1e08a3  pop r9
000076049b1e08a5  pop r8
000076049b1e08a7  pop rsi
000076049b1e08a8  pop rdi
000076049b1e08a9  pop rdx
000076049b1e08aa  pop rcx
000076049b1e08ab  pop rax
000076049b1e08ac  add rsp, 0x08
000076049b1e08b0  jmp 0x000076049B1DC63D
000076049b1e08b5  sub rsp, 0x08
000076049b1e08b9  push rax
000076049b1e08ba  push rcx
000076049b1e08bb  push rdx
000076049b1e08bc  push rdi
000076049b1e08bd  push rsi
000076049b1e08be  push r8
000076049b1e08c0  push r9
000076049b1e08c2  push r10
000076049b1e08c4  push r11
000076049b1e08c6  sub rsp, 0xF0
000076049b1e08cd  vmovaps [rsp], xmm0
000076049b1e08d2  vmovaps [rsp+0x10], xmm1
000076049b1e08d8  vmovaps [rsp+0x20], xmm2
000076049b1e08de  vmovaps [rsp+0x30], xmm3
000076049b1e08e4  vmovaps [rsp+0x40], xmm4
000076049b1e08ea  vmovaps [rsp+0x50], xmm5
000076049b1e08f0  vmovaps [rsp+0x60], xmm6
000076049b1e08f6  vmovaps [rsp+0x70], xmm7
000076049b1e08fc  vmovaps [rsp+0x80], xmm8
000076049b1e0905  vmovaps [rsp+0x90], xmm9
000076049b1e090e  vmovaps [rsp+0xA0], xmm10
000076049b1e0917  vmovaps [rsp+0xB0], xmm11
000076049b1e0920  vmovaps [rsp+0xC0], xmm12
000076049b1e0929  vmovaps [rsp+0xD0], xmm13
000076049b1e0932  vmovaps [rsp+0xE0], xmm14
000076049b1e093b  sub rsp, 0x30
000076049b1e093f  movaps [rsp], xmm15
000076049b1e0944  movaps [rsp+0x10], xmm11
000076049b1e094a  movaps [rsp+0x20], xmm6
000076049b1e094f  lea rdi, [rsp]
000076049b1e0953  mov esi, 0x00
000076049b1e0958  mov rax, 0x64C06813C530
000076049b1e0962  call rax
000076049b1e0964  movaps xmm15, [rsp]
000076049b1e0969  add rsp, 0x30
000076049b1e096d  vmovaps xmm0, [rsp]
000076049b1e0972  vmovaps xmm1, [rsp+0x10]
000076049b1e0978  vmovaps xmm2, [rsp+0x20]
000076049b1e097e  vmovaps xmm3, [rsp+0x30]
000076049b1e0984  vmovaps xmm4, [rsp+0x40]
000076049b1e098a  vmovaps xmm5, [rsp+0x50]
000076049b1e0990  vmovaps xmm6, [rsp+0x60]
000076049b1e0996  vmovaps xmm7, [rsp+0x70]
000076049b1e099c  vmovaps xmm8, [rsp+0x80]
000076049b1e09a5  vmovaps xmm9, [rsp+0x90]
000076049b1e09ae  vmovaps xmm10, [rsp+0xA0]
000076049b1e09b7  vmovaps xmm11, [rsp+0xB0]
000076049b1e09c0  vmovaps xmm12, [rsp+0xC0]
000076049b1e09c9  vmovaps xmm13, [rsp+0xD0]
000076049b1e09d2  vmovaps xmm14, [rsp+0xE0]
000076049b1e09db  add rsp, 0xF0
000076049b1e09e2  pop r11
000076049b1e09e4  pop r10
000076049b1e09e6  pop r9
000076049b1e09e8  pop r8
000076049b1e09ea  pop rsi
000076049b1e09eb  pop rdi
000076049b1e09ec  pop rdx
000076049b1e09ed  pop rcx
000076049b1e09ee  pop rax
000076049b1e09ef  add rsp, 0x08
000076049b1e09f3  jmp 0x000076049B1DC658
000076049b1e09f8  sub rsp, 0x08
000076049b1e09fc  push rax
000076049b1e09fd  push rcx
000076049b1e09fe  push rdx
000076049b1e09ff  push rdi
000076049b1e0a00  push rsi
000076049b1e0a01  push r8
000076049b1e0a03  push r9
000076049b1e0a05  push r10
000076049b1e0a07  push r11
000076049b1e0a09  sub rsp, 0xF0
000076049b1e0a10  vmovaps [rsp], xmm0
000076049b1e0a15  vmovaps [rsp+0x10], xmm1
000076049b1e0a1b  vmovaps [rsp+0x20], xmm2
000076049b1e0a21  vmovaps [rsp+0x30], xmm3
000076049b1e0a27  vmovaps [rsp+0x40], xmm4
000076049b1e0a2d  vmovaps [rsp+0x50], xmm5
000076049b1e0a33  vmovaps [rsp+0x60], xmm6
000076049b1e0a39  vmovaps [rsp+0x70], xmm8
000076049b1e0a3f  vmovaps [rsp+0x80], xmm9
000076049b1e0a48  vmovaps [rsp+0x90], xmm10
000076049b1e0a51  vmovaps [rsp+0xA0], xmm11
000076049b1e0a5a  vmovaps [rsp+0xB0], xmm12
000076049b1e0a63  vmovaps [rsp+0xC0], xmm13
000076049b1e0a6c  vmovaps [rsp+0xD0], xmm14
000076049b1e0a75  vmovaps [rsp+0xE0], xmm15
000076049b1e0a7e  sub rsp, 0x30
000076049b1e0a82  movaps [rsp], xmm7
000076049b1e0a86  movaps [rsp+0x10], xmm11
000076049b1e0a8c  movaps [rsp+0x20], xmm9
000076049b1e0a92  lea rdi, [rsp]
000076049b1e0a96  mov esi, 0x00
000076049b1e0a9b  mov rax, 0x64C06813C530
000076049b1e0aa5  call rax
000076049b1e0aa7  movaps xmm7, [rsp]
000076049b1e0aab  add rsp, 0x30
000076049b1e0aaf  vmovaps xmm0, [rsp]
000076049b1e0ab4  vmovaps xmm1, [rsp+0x10]
000076049b1e0aba  vmovaps xmm2, [rsp+0x20]
000076049b1e0ac0  vmovaps xmm3, [rsp+0x30]
000076049b1e0ac6  vmovaps xmm4, [rsp+0x40]
000076049b1e0acc  vmovaps xmm5, [rsp+0x50]
000076049b1e0ad2  vmovaps xmm6, [rsp+0x60]
000076049b1e0ad8  vmovaps xmm8, [rsp+0x70]
000076049b1e0ade  vmovaps xmm9, [rsp+0x80]
000076049b1e0ae7  vmovaps xmm10, [rsp+0x90]
000076049b1e0af0  vmovaps xmm11, [rsp+0xA0]
000076049b1e0af9  vmovaps xmm12, [rsp+0xB0]
000076049b1e0b02  vmovaps xmm13, [rsp+0xC0]
000076049b1e0b0b  vmovaps xmm14, [rsp+0xD0]
000076049b1e0b14  vmovaps xmm15, [rsp+0xE0]
000076049b1e0b1d  add rsp, 0xF0
000076049b1e0b24  pop r11
000076049b1e0b26  pop r10
000076049b1e0b28  pop r9
000076049b1e0b2a  pop r8
000076049b1e0b2c  pop rsi
000076049b1e0b2d  pop rdi
000076049b1e0b2e  pop rdx
000076049b1e0b2f  pop rcx
000076049b1e0b30  pop rax
000076049b1e0b31  add rsp, 0x08
000076049b1e0b35  jmp 0x000076049B1DC685
000076049b1e0b3a  sub rsp, 0x08
000076049b1e0b3e  push rax
000076049b1e0b3f  push rcx
000076049b1e0b40  push rdx
000076049b1e0b41  push rdi
000076049b1e0b42  push rsi
000076049b1e0b43  push r8
000076049b1e0b45  push r9
000076049b1e0b47  push r10
000076049b1e0b49  push r11
000076049b1e0b4b  sub rsp, 0xF0
000076049b1e0b52  vmovaps [rsp], xmm0
000076049b1e0b57  vmovaps [rsp+0x10], xmm1
000076049b1e0b5d  vmovaps [rsp+0x20], xmm2
000076049b1e0b63  vmovaps [rsp+0x30], xmm3
000076049b1e0b69  vmovaps [rsp+0x40], xmm4
000076049b1e0b6f  vmovaps [rsp+0x50], xmm5
000076049b1e0b75  vmovaps [rsp+0x60], xmm6
000076049b1e0b7b  vmovaps [rsp+0x70], xmm7
000076049b1e0b81  vmovaps [rsp+0x80], xmm8
000076049b1e0b8a  vmovaps [rsp+0x90], xmm9
000076049b1e0b93  vmovaps [rsp+0xA0], xmm10
000076049b1e0b9c  vmovaps [rsp+0xB0], xmm12
000076049b1e0ba5  vmovaps [rsp+0xC0], xmm13
000076049b1e0bae  vmovaps [rsp+0xD0], xmm14
000076049b1e0bb7  vmovaps [rsp+0xE0], xmm15
000076049b1e0bc0  sub rsp, 0x30
000076049b1e0bc4  movaps [rsp], xmm11
000076049b1e0bc9  movaps [rsp+0x10], xmm10
000076049b1e0bcf  movaps [rsp+0x20], xmm14
000076049b1e0bd5  lea rdi, [rsp]
000076049b1e0bd9  mov esi, 0x00
000076049b1e0bde  mov rax, 0x64C06813C530
000076049b1e0be8  call rax
000076049b1e0bea  movaps xmm11, [rsp]
000076049b1e0bef  add rsp, 0x30
000076049b1e0bf3  vmovaps xmm0, [rsp]
000076049b1e0bf8  vmovaps xmm1, [rsp+0x10]
000076049b1e0bfe  vmovaps xmm2, [rsp+0x20]
000076049b1e0c04  vmovaps xmm3, [rsp+0x30]
000076049b1e0c0a  vmovaps xmm4, [rsp+0x40]
000076049b1e0c10  vmovaps xmm5, [rsp+0x50]
000076049b1e0c16  vmovaps xmm6, [rsp+0x60]
000076049b1e0c1c  vmovaps xmm7, [rsp+0x70]
000076049b1e0c22  vmovaps xmm8, [rsp+0x80]
000076049b1e0c2b  vmovaps xmm9, [rsp+0x90]
000076049b1e0c34  vmovaps xmm10, [rsp+0xA0]
000076049b1e0c3d  vmovaps xmm12, [rsp+0xB0]
000076049b1e0c46  vmovaps xmm13, [rsp+0xC0]
000076049b1e0c4f  vmovaps xmm14, [rsp+0xD0]
000076049b1e0c58  vmovaps xmm15, [rsp+0xE0]
000076049b1e0c61  add rsp, 0xF0
000076049b1e0c68  pop r11
000076049b1e0c6a  pop r10
000076049b1e0c6c  pop r9
000076049b1e0c6e  pop r8
000076049b1e0c70  pop rsi
000076049b1e0c71  pop rdi
000076049b1e0c72  pop rdx
000076049b1e0c73  pop rcx
000076049b1e0c74  pop rax
000076049b1e0c75  add rsp, 0x08
000076049b1e0c79  jmp 0x000076049B1DC6A0
000076049b1e0c7e  call 0x000076049B0C33A0
000076049b1e0c83  jmp 0x000076049B1DC6AA
000076049b1e0c88  sub rsp, 0x08
000076049b1e0c8c  push rax
000076049b1e0c8d  push rcx
000076049b1e0c8e  push rdx
000076049b1e0c8f  push rdi
000076049b1e0c90  push rsi
000076049b1e0c91  push r8
000076049b1e0c93  push r9
000076049b1e0c95  push r10
000076049b1e0c97  push r11
000076049b1e0c99  sub rsp, 0xF0
000076049b1e0ca0  vmovaps [rsp], xmm0
000076049b1e0ca5  vmovaps [rsp+0x10], xmm1
000076049b1e0cab  vmovaps [rsp+0x20], xmm2
000076049b1e0cb1  vmovaps [rsp+0x30], xmm3
000076049b1e0cb7  vmovaps [rsp+0x40], xmm4
000076049b1e0cbd  vmovaps [rsp+0x50], xmm5
000076049b1e0cc3  vmovaps [rsp+0x60], xmm6
000076049b1e0cc9  vmovaps [rsp+0x70], xmm7
000076049b1e0ccf  vmovaps [rsp+0x80], xmm8
000076049b1e0cd8  vmovaps [rsp+0x90], xmm9
000076049b1e0ce1  vmovaps [rsp+0xA0], xmm11
000076049b1e0cea  vmovaps [rsp+0xB0], xmm12
000076049b1e0cf3  vmovaps [rsp+0xC0], xmm13
000076049b1e0cfc  vmovaps [rsp+0xD0], xmm14
000076049b1e0d05  vmovaps [rsp+0xE0], xmm15
000076049b1e0d0e  sub rsp, 0x30
000076049b1e0d12  movaps [rsp], xmm10
000076049b1e0d17  movaps [rsp+0x10], xmm1
000076049b1e0d1c  movaps [rsp+0x20], xmm12
000076049b1e0d22  lea rdi, [rsp]
000076049b1e0d26  mov esi, 0x00
000076049b1e0d2b  mov rax, 0x64C06813C530
000076049b1e0d35  call rax
000076049b1e0d37  movaps xmm10, [rsp]
000076049b1e0d3c  add rsp, 0x30
000076049b1e0d40  vmovaps xmm0, [rsp]
000076049b1e0d45  vmovaps xmm1, [rsp+0x10]
000076049b1e0d4b  vmovaps xmm2, [rsp+0x20]
000076049b1e0d51  vmovaps xmm3, [rsp+0x30]
000076049b1e0d57  vmovaps xmm4, [rsp+0x40]
000076049b1e0d5d  vmovaps xmm5, [rsp+0x50]
000076049b1e0d63  vmovaps xmm6, [rsp+0x60]
000076049b1e0d69  vmovaps xmm7, [rsp+0x70]
000076049b1e0d6f  vmovaps xmm8, [rsp+0x80]
000076049b1e0d78  vmovaps xmm9, [rsp+0x90]
000076049b1e0d81  vmovaps xmm11, [rsp+0xA0]
000076049b1e0d8a  vmovaps xmm12, [rsp+0xB0]
000076049b1e0d93  vmovaps xmm13, [rsp+0xC0]
000076049b1e0d9c  vmovaps xmm14, [rsp+0xD0]
000076049b1e0da5  vmovaps xmm15, [rsp+0xE0]
000076049b1e0dae  add rsp, 0xF0
000076049b1e0db5  pop r11
000076049b1e0db7  pop r10
000076049b1e0db9  pop r9
000076049b1e0dbb  pop r8
000076049b1e0dbd  pop rsi
000076049b1e0dbe  pop rdi
000076049b1e0dbf  pop rdx
000076049b1e0dc0  pop rcx
000076049b1e0dc1  pop rax
000076049b1e0dc2  add rsp, 0x08
000076049b1e0dc6  jmp 0x000076049B1DC6CD
000076049b1e0dcb  sub rsp, 0x08
000076049b1e0dcf  push rax
000076049b1e0dd0  push rcx
000076049b1e0dd1  push rdx
000076049b1e0dd2  push rdi
000076049b1e0dd3  push rsi
000076049b1e0dd4  push r8
000076049b1e0dd6  push r9
000076049b1e0dd8  push r10
000076049b1e0dda  push r11
000076049b1e0ddc  sub rsp, 0xF0
000076049b1e0de3  vmovaps [rsp], xmm0
000076049b1e0de8  vmovaps [rsp+0x10], xmm1
000076049b1e0dee  vmovaps [rsp+0x20], xmm2
000076049b1e0df4  vmovaps [rsp+0x30], xmm3
000076049b1e0dfa  vmovaps [rsp+0x40], xmm4
000076049b1e0e00  vmovaps [rsp+0x50], xmm5
000076049b1e0e06  vmovaps [rsp+0x60], xmm6
000076049b1e0e0c  vmovaps [rsp+0x70], xmm7
000076049b1e0e12  vmovaps [rsp+0x80], xmm8
000076049b1e0e1b  vmovaps [rsp+0x90], xmm9
000076049b1e0e24  vmovaps [rsp+0xA0], xmm10
000076049b1e0e2d  vmovaps [rsp+0xB0], xmm11
000076049b1e0e36  vmovaps [rsp+0xC0], xmm13
000076049b1e0e3f  vmovaps [rsp+0xD0], xmm14
000076049b1e0e48  vmovaps [rsp+0xE0], xmm15
000076049b1e0e51  sub rsp, 0x30
000076049b1e0e55  movaps [rsp], xmm12
000076049b1e0e5a  movaps [rsp+0x10], xmm14
000076049b1e0e60  movaps [rsp+0x20], xmm1
000076049b1e0e65  lea rdi, [rsp]
000076049b1e0e69  mov esi, 0x00
000076049b1e0e6e  mov rax, 0x64C06813C530
000076049b1e0e78  call rax
000076049b1e0e7a  movaps xmm12, [rsp]
000076049b1e0e7f  add rsp, 0x30
000076049b1e0e83  vmovaps xmm0, [rsp]
000076049b1e0e88  vmovaps xmm1, [rsp+0x10]
000076049b1e0e8e  vmovaps xmm2, [rsp+0x20]
000076049b1e0e94  vmovaps xmm3, [rsp+0x30]
000076049b1e0e9a  vmovaps xmm4, [rsp+0x40]
000076049b1e0ea0  vmovaps xmm5, [rsp+0x50]
000076049b1e0ea6  vmovaps xmm6, [rsp+0x60]
000076049b1e0eac  vmovaps xmm7, [rsp+0x70]
000076049b1e0eb2  vmovaps xmm8, [rsp+0x80]
000076049b1e0ebb  vmovaps xmm9, [rsp+0x90]
000076049b1e0ec4  vmovaps xmm10, [rsp+0xA0]
000076049b1e0ecd  vmovaps xmm11, [rsp+0xB0]
000076049b1e0ed6  vmovaps xmm13, [rsp+0xC0]
000076049b1e0edf  vmovaps xmm14, [rsp+0xD0]
000076049b1e0ee8  vmovaps xmm15, [rsp+0xE0]
000076049b1e0ef1  add rsp, 0xF0
000076049b1e0ef8  pop r11
000076049b1e0efa  pop r10
000076049b1e0efc  pop r9
000076049b1e0efe  pop r8
000076049b1e0f00  pop rsi
000076049b1e0f01  pop rdi
000076049b1e0f02  pop rdx
000076049b1e0f03  pop rcx
000076049b1e0f04  pop rax
000076049b1e0f05  add rsp, 0x08
000076049b1e0f09  jmp 0x000076049B1DC6FC
000076049b1e0f0e  sub rsp, 0x08
000076049b1e0f12  push rax
000076049b1e0f13  push rcx
000076049b1e0f14  push rdx
000076049b1e0f15  push rdi
000076049b1e0f16  push rsi
000076049b1e0f17  push r8
000076049b1e0f19  push r9
000076049b1e0f1b  push r10
000076049b1e0f1d  push r11
000076049b1e0f1f  sub rsp, 0xF0
000076049b1e0f26  vmovaps [rsp], xmm0
000076049b1e0f2b  vmovaps [rsp+0x10], xmm1
000076049b1e0f31  vmovaps [rsp+0x20], xmm2
000076049b1e0f37  vmovaps [rsp+0x30], xmm3
000076049b1e0f3d  vmovaps [rsp+0x40], xmm4
000076049b1e0f43  vmovaps [rsp+0x50], xmm5
000076049b1e0f49  vmovaps [rsp+0x60], xmm6
000076049b1e0f4f  vmovaps [rsp+0x70], xmm7
000076049b1e0f55  vmovaps [rsp+0x80], xmm8
000076049b1e0f5e  vmovaps [rsp+0x90], xmm9
000076049b1e0f67  vmovaps [rsp+0xA0], xmm10
000076049b1e0f70  vmovaps [rsp+0xB0], xmm11
000076049b1e0f79  vmovaps [rsp+0xC0], xmm12
000076049b1e0f82  vmovaps [rsp+0xD0], xmm13
000076049b1e0f8b  vmovaps [rsp+0xE0], xmm15
000076049b1e0f94  sub rsp, 0x30
000076049b1e0f98  movaps [rsp], xmm14
000076049b1e0f9d  movaps [rsp+0x10], xmm9
000076049b1e0fa3  movaps [rsp+0x20], xmm1
000076049b1e0fa8  lea rdi, [rsp]
000076049b1e0fac  mov esi, 0x00
000076049b1e0fb1  mov rax, 0x64C06813C530
000076049b1e0fbb  call rax
000076049b1e0fbd  movaps xmm14, [rsp]
000076049b1e0fc2  add rsp, 0x30
000076049b1e0fc6  vmovaps xmm0, [rsp]
000076049b1e0fcb  vmovaps xmm1, [rsp+0x10]
000076049b1e0fd1  vmovaps xmm2, [rsp+0x20]
000076049b1e0fd7  vmovaps xmm3, [rsp+0x30]
000076049b1e0fdd  vmovaps xmm4, [rsp+0x40]
000076049b1e0fe3  vmovaps xmm5, [rsp+0x50]
000076049b1e0fe9  vmovaps xmm6, [rsp+0x60]
000076049b1e0fef  vmovaps xmm7, [rsp+0x70]
000076049b1e0ff5  vmovaps xmm8, [rsp+0x80]
000076049b1e0ffe  vmovaps xmm9, [rsp+0x90]
000076049b1e1007  vmovaps xmm10, [rsp+0xA0]
000076049b1e1010  vmovaps xmm11, [rsp+0xB0]
000076049b1e1019  vmovaps xmm12, [rsp+0xC0]
000076049b1e1022  vmovaps xmm13, [rsp+0xD0]
000076049b1e102b  vmovaps xmm15, [rsp+0xE0]
000076049b1e1034  add rsp, 0xF0
000076049b1e103b  pop r11
000076049b1e103d  pop r10
000076049b1e103f  pop r9
000076049b1e1041  pop r8
000076049b1e1043  pop rsi
000076049b1e1044  pop rdi
000076049b1e1045  pop rdx
000076049b1e1046  pop rcx
000076049b1e1047  pop rax
000076049b1e1048  add rsp, 0x08
000076049b1e104c  jmp 0x000076049B1DC72B
000076049b1e1051  sub rsp, 0x08
000076049b1e1055  push rax
000076049b1e1056  push rcx
000076049b1e1057  push rdx
000076049b1e1058  push rdi
000076049b1e1059  push rsi
000076049b1e105a  push r8
000076049b1e105c  push r9
000076049b1e105e  push r10
000076049b1e1060  push r11
000076049b1e1062  sub rsp, 0xF0
000076049b1e1069  vmovaps [rsp], xmm0
000076049b1e106e  vmovaps [rsp+0x10], xmm2
000076049b1e1074  vmovaps [rsp+0x20], xmm3
000076049b1e107a  vmovaps [rsp+0x30], xmm4
000076049b1e1080  vmovaps [rsp+0x40], xmm5
000076049b1e1086  vmovaps [rsp+0x50], xmm6
000076049b1e108c  vmovaps [rsp+0x60], xmm7
000076049b1e1092  vmovaps [rsp+0x70], xmm8
000076049b1e1098  vmovaps [rsp+0x80], xmm9
000076049b1e10a1  vmovaps [rsp+0x90], xmm10
000076049b1e10aa  vmovaps [rsp+0xA0], xmm11
000076049b1e10b3  vmovaps [rsp+0xB0], xmm12
000076049b1e10bc  vmovaps [rsp+0xC0], xmm13
000076049b1e10c5  vmovaps [rsp+0xD0], xmm14
000076049b1e10ce  vmovaps [rsp+0xE0], xmm15
000076049b1e10d7  sub rsp, 0x30
000076049b1e10db  movaps [rsp], xmm1
000076049b1e10df  movaps [rsp+0x10], xmm13
000076049b1e10e5  movaps [rsp+0x20], xmm8
000076049b1e10eb  lea rdi, [rsp]
000076049b1e10ef  mov esi, 0x00
000076049b1e10f4  mov rax, 0x64C06813C530
000076049b1e10fe  call rax
000076049b1e1100  movaps xmm1, [rsp]
000076049b1e1104  add rsp, 0x30
000076049b1e1108  vmovaps xmm0, [rsp]
000076049b1e110d  vmovaps xmm2, [rsp+0x10]
000076049b1e1113  vmovaps xmm3, [rsp+0x20]
000076049b1e1119  vmovaps xmm4, [rsp+0x30]
000076049b1e111f  vmovaps xmm5, [rsp+0x40]
000076049b1e1125  vmovaps xmm6, [rsp+0x50]
000076049b1e112b  vmovaps xmm7, [rsp+0x60]
000076049b1e1131  vmovaps xmm8, [rsp+0x70]
000076049b1e1137  vmovaps xmm9, [rsp+0x80]
000076049b1e1140  vmovaps xmm10, [rsp+0x90]
000076049b1e1149  vmovaps xmm11, [rsp+0xA0]
000076049b1e1152  vmovaps xmm12, [rsp+0xB0]
000076049b1e115b  vmovaps xmm13, [rsp+0xC0]
000076049b1e1164  vmovaps xmm14, [rsp+0xD0]
000076049b1e116d  vmovaps xmm15, [rsp+0xE0]
000076049b1e1176  add rsp, 0xF0
000076049b1e117d  pop r11
000076049b1e117f  pop r10
000076049b1e1181  pop r9
000076049b1e1183  pop r8
000076049b1e1185  pop rsi
000076049b1e1186  pop rdi
000076049b1e1187  pop rdx
000076049b1e1188  pop rcx
000076049b1e1189  pop rax
000076049b1e118a  add rsp, 0x08
000076049b1e118e  jmp 0x000076049B1DC74D
000076049b1e1193  call 0x000076049B00C260
000076049b1e1198  jmp 0x000076049B1DC75B
000076049b1e119d  call 0x000076049B0BD750
000076049b1e11a2  jmp 0x000076049B1DC765
000076049b1e11a7  sub rsp, 0x08
000076049b1e11ab  push rax
000076049b1e11ac  push rcx
000076049b1e11ad  push rdx
000076049b1e11ae  push rdi
000076049b1e11af  push rsi
000076049b1e11b0  push r8
000076049b1e11b2  push r9
000076049b1e11b4  push r10
000076049b1e11b6  push r11
000076049b1e11b8  sub rsp, 0xF0
000076049b1e11bf  vmovaps [rsp], xmm0
000076049b1e11c4  vmovaps [rsp+0x10], xmm1
000076049b1e11ca  vmovaps [rsp+0x20], xmm2
000076049b1e11d0  vmovaps [rsp+0x30], xmm3
000076049b1e11d6  vmovaps [rsp+0x40], xmm4
000076049b1e11dc  vmovaps [rsp+0x50], xmm5
000076049b1e11e2  vmovaps [rsp+0x60], xmm6
000076049b1e11e8  vmovaps [rsp+0x70], xmm7
000076049b1e11ee  vmovaps [rsp+0x80], xmm9
000076049b1e11f7  vmovaps [rsp+0x90], xmm10
000076049b1e1200  vmovaps [rsp+0xA0], xmm11
000076049b1e1209  vmovaps [rsp+0xB0], xmm12
000076049b1e1212  vmovaps [rsp+0xC0], xmm13
000076049b1e121b  vmovaps [rsp+0xD0], xmm14
000076049b1e1224  vmovaps [rsp+0xE0], xmm15
000076049b1e122d  sub rsp, 0x30
000076049b1e1231  movaps [rsp], xmm8
000076049b1e1236  movaps [rsp+0x10], xmm15
000076049b1e123c  movaps [rsp+0x20], xmm7
000076049b1e1241  lea rdi, [rsp]
000076049b1e1245  mov esi, 0x00
000076049b1e124a  mov rax, 0x64C06813C530
000076049b1e1254  call rax
000076049b1e1256  movaps xmm8, [rsp]
000076049b1e125b  add rsp, 0x30
000076049b1e125f  vmovaps xmm0, [rsp]
000076049b1e1264  vmovaps xmm1, [rsp+0x10]
000076049b1e126a  vmovaps xmm2, [rsp+0x20]
000076049b1e1270  vmovaps xmm3, [rsp+0x30]
000076049b1e1276  vmovaps xmm4, [rsp+0x40]
000076049b1e127c  vmovaps xmm5, [rsp+0x50]
000076049b1e1282  vmovaps xmm6, [rsp+0x60]
000076049b1e1288  vmovaps xmm7, [rsp+0x70]
000076049b1e128e  vmovaps xmm9, [rsp+0x80]
000076049b1e1297  vmovaps xmm10, [rsp+0x90]
000076049b1e12a0  vmovaps xmm11, [rsp+0xA0]
000076049b1e12a9  vmovaps xmm12, [rsp+0xB0]
000076049b1e12b2  vmovaps xmm13, [rsp+0xC0]
000076049b1e12bb  vmovaps xmm14, [rsp+0xD0]
000076049b1e12c4  vmovaps xmm15, [rsp+0xE0]
000076049b1e12cd  add rsp, 0xF0
000076049b1e12d4  pop r11
000076049b1e12d6  pop r10
000076049b1e12d8  pop r9
000076049b1e12da  pop r8
000076049b1e12dc  pop rsi
000076049b1e12dd  pop rdi
000076049b1e12de  pop rdx
000076049b1e12df  pop rcx
000076049b1e12e0  pop rax
000076049b1e12e1  add rsp, 0x08
000076049b1e12e5  jmp 0x000076049B1DC787
000076049b1e12ea  sub rsp, 0x08
000076049b1e12ee  push rax
000076049b1e12ef  push rcx
000076049b1e12f0  push rdx
000076049b1e12f1  push rdi
000076049b1e12f2  push rsi
000076049b1e12f3  push r8
000076049b1e12f5  push r9
000076049b1e12f7  push r10
000076049b1e12f9  push r11
000076049b1e12fb  sub rsp, 0xF0
000076049b1e1302  vmovaps [rsp], xmm0
000076049b1e1307  vmovaps [rsp+0x10], xmm1
000076049b1e130d  vmovaps [rsp+0x20], xmm2
000076049b1e1313  vmovaps [rsp+0x30], xmm3
000076049b1e1319  vmovaps [rsp+0x40], xmm4
000076049b1e131f  vmovaps [rsp+0x50], xmm5
000076049b1e1325  vmovaps [rsp+0x60], xmm6
000076049b1e132b  vmovaps [rsp+0x70], xmm8
000076049b1e1331  vmovaps [rsp+0x80], xmm9
000076049b1e133a  vmovaps [rsp+0x90], xmm10
000076049b1e1343  vmovaps [rsp+0xA0], xmm11
000076049b1e134c  vmovaps [rsp+0xB0], xmm12
000076049b1e1355  vmovaps [rsp+0xC0], xmm13
000076049b1e135e  vmovaps [rsp+0xD0], xmm14
000076049b1e1367  vmovaps [rsp+0xE0], xmm15
000076049b1e1370  sub rsp, 0x30
000076049b1e1374  movaps [rsp], xmm7
000076049b1e1378  movaps [rsp+0x10], xmm9
000076049b1e137e  movaps [rsp+0x20], xmm15
000076049b1e1384  lea rdi, [rsp]
000076049b1e1388  mov esi, 0x00
000076049b1e138d  mov rax, 0x64C06813C530
000076049b1e1397  call rax
000076049b1e1399  movaps xmm7, [rsp]
000076049b1e139d  add rsp, 0x30
000076049b1e13a1  vmovaps xmm0, [rsp]
000076049b1e13a6  vmovaps xmm1, [rsp+0x10]
000076049b1e13ac  vmovaps xmm2, [rsp+0x20]
000076049b1e13b2  vmovaps xmm3, [rsp+0x30]
000076049b1e13b8  vmovaps xmm4, [rsp+0x40]
000076049b1e13be  vmovaps xmm5, [rsp+0x50]
000076049b1e13c4  vmovaps xmm6, [rsp+0x60]
000076049b1e13ca  vmovaps xmm8, [rsp+0x70]
000076049b1e13d0  vmovaps xmm9, [rsp+0x80]
000076049b1e13d9  vmovaps xmm10, [rsp+0x90]
000076049b1e13e2  vmovaps xmm11, [rsp+0xA0]
000076049b1e13eb  vmovaps xmm12, [rsp+0xB0]
000076049b1e13f4  vmovaps xmm13, [rsp+0xC0]
000076049b1e13fd  vmovaps xmm14, [rsp+0xD0]
000076049b1e1406  vmovaps xmm15, [rsp+0xE0]
000076049b1e140f  add rsp, 0xF0
000076049b1e1416  pop r11
000076049b1e1418  pop r10
000076049b1e141a  pop r9
000076049b1e141c  pop r8
000076049b1e141e  pop rsi
000076049b1e141f  pop rdi
000076049b1e1420  pop rdx
000076049b1e1421  pop rcx
000076049b1e1422  pop rax
000076049b1e1423  add rsp, 0x08
000076049b1e1427  jmp 0x000076049B1DC7B4
000076049b1e142c  sub rsp, 0x08
000076049b1e1430  push rax
000076049b1e1431  push rcx
000076049b1e1432  push rdx
000076049b1e1433  push rdi
000076049b1e1434  push rsi
000076049b1e1435  push r8
000076049b1e1437  push r9
000076049b1e1439  push r10
000076049b1e143b  push r11
000076049b1e143d  sub rsp, 0xF0
000076049b1e1444  vmovaps [rsp], xmm0
000076049b1e1449  vmovaps [rsp+0x10], xmm1
000076049b1e144f  vmovaps [rsp+0x20], xmm2
000076049b1e1455  vmovaps [rsp+0x30], xmm3
000076049b1e145b  vmovaps [rsp+0x40], xmm4
000076049b1e1461  vmovaps [rsp+0x50], xmm5
000076049b1e1467  vmovaps [rsp+0x60], xmm6
000076049b1e146d  vmovaps [rsp+0x70], xmm7
000076049b1e1473  vmovaps [rsp+0x80], xmm8
000076049b1e147c  vmovaps [rsp+0x90], xmm10
000076049b1e1485  vmovaps [rsp+0xA0], xmm11
000076049b1e148e  vmovaps [rsp+0xB0], xmm12
000076049b1e1497  vmovaps [rsp+0xC0], xmm13
000076049b1e14a0  vmovaps [rsp+0xD0], xmm14
000076049b1e14a9  vmovaps [rsp+0xE0], xmm15
000076049b1e14b2  sub rsp, 0x30
000076049b1e14b6  movaps [rsp], xmm9
000076049b1e14bb  movaps [rsp+0x10], xmm13
000076049b1e14c1  movaps [rsp+0x20], xmm15
000076049b1e14c7  lea rdi, [rsp]
000076049b1e14cb  mov esi, 0x00
000076049b1e14d0  mov rax, 0x64C06813C530
000076049b1e14da  call rax
000076049b1e14dc  movaps xmm9, [rsp]
000076049b1e14e1  add rsp, 0x30
000076049b1e14e5  vmovaps xmm0, [rsp]
000076049b1e14ea  vmovaps xmm1, [rsp+0x10]
000076049b1e14f0  vmovaps xmm2, [rsp+0x20]
000076049b1e14f6  vmovaps xmm3, [rsp+0x30]
000076049b1e14fc  vmovaps xmm4, [rsp+0x40]
000076049b1e1502  vmovaps xmm5, [rsp+0x50]
000076049b1e1508  vmovaps xmm6, [rsp+0x60]
000076049b1e150e  vmovaps xmm7, [rsp+0x70]
000076049b1e1514  vmovaps xmm8, [rsp+0x80]
000076049b1e151d  vmovaps xmm10, [rsp+0x90]
000076049b1e1526  vmovaps xmm11, [rsp+0xA0]
000076049b1e152f  vmovaps xmm12, [rsp+0xB0]
000076049b1e1538  vmovaps xmm13, [rsp+0xC0]
000076049b1e1541  vmovaps xmm14, [rsp+0xD0]
000076049b1e154a  vmovaps xmm15, [rsp+0xE0]
000076049b1e1553  add rsp, 0xF0
000076049b1e155a  pop r11
000076049b1e155c  pop r10
000076049b1e155e  pop r9
000076049b1e1560  pop r8
000076049b1e1562  pop rsi
000076049b1e1563  pop rdi
000076049b1e1564  pop rdx
000076049b1e1565  pop rcx
000076049b1e1566  pop rax
000076049b1e1567  add rsp, 0x08
000076049b1e156b  jmp 0x000076049B1DC7E2
000076049b1e1570  sub rsp, 0x08
000076049b1e1574  push rax
000076049b1e1575  push rcx
000076049b1e1576  push rdx
000076049b1e1577  push rdi
000076049b1e1578  push rsi
000076049b1e1579  push r8
000076049b1e157b  push r9
000076049b1e157d  push r10
000076049b1e157f  push r11
000076049b1e1581  sub rsp, 0xF0
000076049b1e1588  vmovaps [rsp], xmm0
000076049b1e158d  vmovaps [rsp+0x10], xmm1
000076049b1e1593  vmovaps [rsp+0x20], xmm2
000076049b1e1599  vmovaps [rsp+0x30], xmm3
000076049b1e159f  vmovaps [rsp+0x40], xmm4
000076049b1e15a5  vmovaps [rsp+0x50], xmm5
000076049b1e15ab  vmovaps [rsp+0x60], xmm6
000076049b1e15b1  vmovaps [rsp+0x70], xmm7
000076049b1e15b7  vmovaps [rsp+0x80], xmm8
000076049b1e15c0  vmovaps [rsp+0x90], xmm9
000076049b1e15c9  vmovaps [rsp+0xA0], xmm10
000076049b1e15d2  vmovaps [rsp+0xB0], xmm11
000076049b1e15db  vmovaps [rsp+0xC0], xmm12
000076049b1e15e4  vmovaps [rsp+0xD0], xmm13
000076049b1e15ed  vmovaps [rsp+0xE0], xmm14
000076049b1e15f6  sub rsp, 0x30
000076049b1e15fa  movaps [rsp], xmm15
000076049b1e15ff  movaps [rsp+0x10], xmm11
000076049b1e1605  movaps [rsp+0x20], xmm12
000076049b1e160b  lea rdi, [rsp]
000076049b1e160f  mov esi, 0x00
000076049b1e1614  mov rax, 0x64C06813C530
000076049b1e161e  call rax
000076049b1e1620  movaps xmm15, [rsp]
000076049b1e1625  add rsp, 0x30
000076049b1e1629  vmovaps xmm0, [rsp]
000076049b1e162e  vmovaps xmm1, [rsp+0x10]
000076049b1e1634  vmovaps xmm2, [rsp+0x20]
000076049b1e163a  vmovaps xmm3, [rsp+0x30]
000076049b1e1640  vmovaps xmm4, [rsp+0x40]
000076049b1e1646  vmovaps xmm5, [rsp+0x50]
000076049b1e164c  vmovaps xmm6, [rsp+0x60]
000076049b1e1652  vmovaps xmm7, [rsp+0x70]
000076049b1e1658  vmovaps xmm8, [rsp+0x80]
000076049b1e1661  vmovaps xmm9, [rsp+0x90]
000076049b1e166a  vmovaps xmm10, [rsp+0xA0]
000076049b1e1673  vmovaps xmm11, [rsp+0xB0]
000076049b1e167c  vmovaps xmm12, [rsp+0xC0]
000076049b1e1685  vmovaps xmm13, [rsp+0xD0]
000076049b1e168e  vmovaps xmm14, [rsp+0xE0]
000076049b1e1697  add rsp, 0xF0
000076049b1e169e  pop r11
000076049b1e16a0  pop r10
000076049b1e16a2  pop r9
000076049b1e16a4  pop r8
000076049b1e16a6  pop rsi
000076049b1e16a7  pop rdi
000076049b1e16a8  pop rdx
000076049b1e16a9  pop rcx
000076049b1e16aa  pop rax
000076049b1e16ab  add rsp, 0x08
000076049b1e16af  jmp 0x000076049B1DC7FD
000076049b1e16b4  sub rsp, 0x08
000076049b1e16b8  push rax
000076049b1e16b9  push rcx
000076049b1e16ba  push rdx
000076049b1e16bb  push rdi
000076049b1e16bc  push rsi
000076049b1e16bd  push r8
000076049b1e16bf  push r9
000076049b1e16c1  push r10
000076049b1e16c3  push r11
000076049b1e16c5  sub rsp, 0xF0
000076049b1e16cc  vmovaps [rsp], xmm0
000076049b1e16d1  vmovaps [rsp+0x10], xmm1
000076049b1e16d7  vmovaps [rsp+0x20], xmm2
000076049b1e16dd  vmovaps [rsp+0x30], xmm3
000076049b1e16e3  vmovaps [rsp+0x40], xmm4
000076049b1e16e9  vmovaps [rsp+0x50], xmm5
000076049b1e16ef  vmovaps [rsp+0x60], xmm6
000076049b1e16f5  vmovaps [rsp+0x70], xmm7
000076049b1e16fb  vmovaps [rsp+0x80], xmm8
000076049b1e1704  vmovaps [rsp+0x90], xmm9
000076049b1e170d  vmovaps [rsp+0xA0], xmm10
000076049b1e1716  vmovaps [rsp+0xB0], xmm11
000076049b1e171f  vmovaps [rsp+0xC0], xmm12
000076049b1e1728  vmovaps [rsp+0xD0], xmm14
000076049b1e1731  vmovaps [rsp+0xE0], xmm15
000076049b1e173a  sub rsp, 0x30
000076049b1e173e  movaps [rsp], xmm13
000076049b1e1743  movaps [rsp+0x10], xmm10
000076049b1e1749  movaps [rsp+0x20], xmm14
000076049b1e174f  lea rdi, [rsp]
000076049b1e1753  mov esi, 0x00
000076049b1e1758  mov rax, 0x64C06813C530
000076049b1e1762  call rax
000076049b1e1764  movaps xmm13, [rsp]
000076049b1e1769  add rsp, 0x30
000076049b1e176d  vmovaps xmm0, [rsp]
000076049b1e1772  vmovaps xmm1, [rsp+0x10]
000076049b1e1778  vmovaps xmm2, [rsp+0x20]
000076049b1e177e  vmovaps xmm3, [rsp+0x30]
000076049b1e1784  vmovaps xmm4, [rsp+0x40]
000076049b1e178a  vmovaps xmm5, [rsp+0x50]
000076049b1e1790  vmovaps xmm6, [rsp+0x60]
000076049b1e1796  vmovaps xmm7, [rsp+0x70]
000076049b1e179c  vmovaps xmm8, [rsp+0x80]
000076049b1e17a5  vmovaps xmm9, [rsp+0x90]
000076049b1e17ae  vmovaps xmm10, [rsp+0xA0]
000076049b1e17b7  vmovaps xmm11, [rsp+0xB0]
000076049b1e17c0  vmovaps xmm12, [rsp+0xC0]
000076049b1e17c9  vmovaps xmm14, [rsp+0xD0]
000076049b1e17d2  vmovaps xmm15, [rsp+0xE0]
000076049b1e17db  add rsp, 0xF0
000076049b1e17e2  pop r11
000076049b1e17e4  pop r10
000076049b1e17e6  pop r9
000076049b1e17e8  pop r8
000076049b1e17ea  pop rsi
000076049b1e17eb  pop rdi
000076049b1e17ec  pop rdx
000076049b1e17ed  pop rcx
000076049b1e17ee  pop rax
000076049b1e17ef  add rsp, 0x08
000076049b1e17f3  jmp 0x000076049B1DC820
000076049b1e17f8  sub rsp, 0x08
000076049b1e17fc  push rax
000076049b1e17fd  push rcx
000076049b1e17fe  push rdx
000076049b1e17ff  push rdi
000076049b1e1800  push rsi
000076049b1e1801  push r8
000076049b1e1803  push r9
000076049b1e1805  push r10
000076049b1e1807  push r11
000076049b1e1809  sub rsp, 0xF0
000076049b1e1810  vmovaps [rsp], xmm0
000076049b1e1815  vmovaps [rsp+0x10], xmm1
000076049b1e181b  vmovaps [rsp+0x20], xmm2
000076049b1e1821  vmovaps [rsp+0x30], xmm3
000076049b1e1827  vmovaps [rsp+0x40], xmm4
000076049b1e182d  vmovaps [rsp+0x50], xmm5
000076049b1e1833  vmovaps [rsp+0x60], xmm6
000076049b1e1839  vmovaps [rsp+0x70], xmm7
000076049b1e183f  vmovaps [rsp+0x80], xmm8
000076049b1e1848  vmovaps [rsp+0x90], xmm9
000076049b1e1851  vmovaps [rsp+0xA0], xmm10
000076049b1e185a  vmovaps [rsp+0xB0], xmm11
000076049b1e1863  vmovaps [rsp+0xC0], xmm12
000076049b1e186c  vmovaps [rsp+0xD0], xmm13
000076049b1e1875  vmovaps [rsp+0xE0], xmm15
000076049b1e187e  sub rsp, 0x30
000076049b1e1882  movaps [rsp], xmm14
000076049b1e1887  movaps [rsp+0x10], xmm1
000076049b1e188c  movaps [rsp+0x20], xmm7
000076049b1e1891  lea rdi, [rsp]
000076049b1e1895  mov esi, 0x00
000076049b1e189a  mov rax, 0x64C06813C530
000076049b1e18a4  call rax
000076049b1e18a6  movaps xmm14, [rsp]
000076049b1e18ab  add rsp, 0x30
000076049b1e18af  vmovaps xmm0, [rsp]
000076049b1e18b4  vmovaps xmm1, [rsp+0x10]
000076049b1e18ba  vmovaps xmm2, [rsp+0x20]
000076049b1e18c0  vmovaps xmm3, [rsp+0x30]
000076049b1e18c6  vmovaps xmm4, [rsp+0x40]
000076049b1e18cc  vmovaps xmm5, [rsp+0x50]
000076049b1e18d2  vmovaps xmm6, [rsp+0x60]
000076049b1e18d8  vmovaps xmm7, [rsp+0x70]
000076049b1e18de  vmovaps xmm8, [rsp+0x80]
000076049b1e18e7  vmovaps xmm9, [rsp+0x90]
000076049b1e18f0  vmovaps xmm10, [rsp+0xA0]
000076049b1e18f9  vmovaps xmm11, [rsp+0xB0]
000076049b1e1902  vmovaps xmm12, [rsp+0xC0]
000076049b1e190b  vmovaps xmm13, [rsp+0xD0]
000076049b1e1914  vmovaps xmm15, [rsp+0xE0]
000076049b1e191d  add rsp, 0xF0
000076049b1e1924  pop r11
000076049b1e1926  pop r10
000076049b1e1928  pop r9
000076049b1e192a  pop r8
000076049b1e192c  pop rsi
000076049b1e192d  pop rdi
000076049b1e192e  pop rdx
000076049b1e192f  pop rcx
000076049b1e1930  pop rax
000076049b1e1931  add rsp, 0x08
000076049b1e1935  jmp 0x000076049B1DC843
000076049b1e193a  sub rsp, 0x08
000076049b1e193e  push rax
000076049b1e193f  push rcx
000076049b1e1940  push rdx
000076049b1e1941  push rdi
000076049b1e1942  push rsi
000076049b1e1943  push r8
000076049b1e1945  push r9
000076049b1e1947  push r10
000076049b1e1949  push r11
000076049b1e194b  sub rsp, 0xF0
000076049b1e1952  vmovaps [rsp], xmm0
000076049b1e1957  vmovaps [rsp+0x10], xmm2
000076049b1e195d  vmovaps [rsp+0x20], xmm3
000076049b1e1963  vmovaps [rsp+0x30], xmm4
000076049b1e1969  vmovaps [rsp+0x40], xmm5
000076049b1e196f  vmovaps [rsp+0x50], xmm6
000076049b1e1975  vmovaps [rsp+0x60], xmm7
000076049b1e197b  vmovaps [rsp+0x70], xmm8
000076049b1e1981  vmovaps [rsp+0x80], xmm9
000076049b1e198a  vmovaps [rsp+0x90], xmm10
000076049b1e1993  vmovaps [rsp+0xA0], xmm11
000076049b1e199c  vmovaps [rsp+0xB0], xmm12
000076049b1e19a5  vmovaps [rsp+0xC0], xmm13
000076049b1e19ae  vmovaps [rsp+0xD0], xmm14
000076049b1e19b7  vmovaps [rsp+0xE0], xmm15
000076049b1e19c0  sub rsp, 0x30
000076049b1e19c4  movaps [rsp], xmm1
000076049b1e19c8  movaps [rsp+0x10], xmm8
000076049b1e19ce  movaps [rsp+0x20], xmm9
000076049b1e19d4  lea rdi, [rsp]
000076049b1e19d8  mov esi, 0x00
000076049b1e19dd  mov rax, 0x64C06813C530
000076049b1e19e7  call rax
000076049b1e19e9  movaps xmm1, [rsp]
000076049b1e19ed  add rsp, 0x30
000076049b1e19f1  vmovaps xmm0, [rsp]
000076049b1e19f6  vmovaps xmm2, [rsp+0x10]
000076049b1e19fc  vmovaps xmm3, [rsp+0x20]
000076049b1e1a02  vmovaps xmm4, [rsp+0x30]
000076049b1e1a08  vmovaps xmm5, [rsp+0x40]
000076049b1e1a0e  vmovaps xmm6, [rsp+0x50]
000076049b1e1a14  vmovaps xmm7, [rsp+0x60]
000076049b1e1a1a  vmovaps xmm8, [rsp+0x70]
000076049b1e1a20  vmovaps xmm9, [rsp+0x80]
000076049b1e1a29  vmovaps xmm10, [rsp+0x90]
000076049b1e1a32  vmovaps xmm11, [rsp+0xA0]
000076049b1e1a3b  vmovaps xmm12, [rsp+0xB0]
000076049b1e1a44  vmovaps xmm13, [rsp+0xC0]
000076049b1e1a4d  vmovaps xmm14, [rsp+0xD0]
000076049b1e1a56  vmovaps xmm15, [rsp+0xE0]
000076049b1e1a5f  add rsp, 0xF0
000076049b1e1a66  pop r11
000076049b1e1a68  pop r10
000076049b1e1a6a  pop r9
000076049b1e1a6c  pop r8
000076049b1e1a6e  pop rsi
000076049b1e1a6f  pop rdi
000076049b1e1a70  pop rdx
000076049b1e1a71  pop rcx
000076049b1e1a72  pop rax
000076049b1e1a73  add rsp, 0x08
000076049b1e1a77  jmp 0x000076049B1DC865
000076049b1e1a7c  call 0x000076049B0E5940
000076049b1e1a81  jmp 0x000076049B1DC873
000076049b1e1a86  call 0x000076049B00C380
000076049b1e1a8b  jmp 0x000076049B1DC87D
000076049b1e1a90  call 0x000076049B00D600
000076049b1e1a95  jmp 0x000076049B1DC887
000076049b1e1a9a  call 0x000076049AFFF540
000076049b1e1a9f  jmp 0x000076049B1DC891
000076049b1e1aa4  int3
000076049b1e1aa5  nop [rax+rax*1], ax
000076049b1e1aae  nop
000076049b1e1ab0  mov rax, [r15+0xF8]
000076049b1e1ab7  lea r14, [rax+0x140]
000076049b1e1abe  mov r12, [r13+r14*1]
000076049b1e1ac3  mov [r15+0xE8], r12
000076049b1e1aca  lea r14, [rax+0x130]
000076049b1e1ad1  mov r12, [r13+r14*1]
000076049b1e1ad6  lea r14, [rax+0x138]
000076049b1e1add  mov r11, [r13+r14*1]
000076049b1e1ae2  movq xmm1, r12
000076049b1e1ae7  movq xmm15, r11
000076049b1e1aec  movq xmm1, xmm1
000076049b1e1af0  movq xmm1, xmm1
000076049b1e1af4  movaps [r15+0x1A0], xmm1
000076049b1e1afc  movq xmm15, xmm15
000076049b1e1b01  movq xmm15, xmm15
000076049b1e1b06  movaps [r15+0x190], xmm15
000076049b1e1b0e  lea r14, [rax+0x120]
000076049b1e1b15  mov r12, [r13+r14*1]
000076049b1e1b1a  lea r14, [rax+0x128]
000076049b1e1b21  mov r11, [r13+r14*1]
000076049b1e1b26  movq xmm1, r12
000076049b1e1b2b  movq xmm15, r11
000076049b1e1b30  movq xmm1, xmm1
000076049b1e1b34  movq xmm1, xmm1
000076049b1e1b38  movaps [r15+0x1C0], xmm1
000076049b1e1b40  movq xmm15, xmm15
000076049b1e1b45  movq xmm15, xmm15
000076049b1e1b4a  movaps [r15+0x1B0], xmm15
000076049b1e1b52  lea r14, [rax+0x110]
000076049b1e1b59  mov r12, [r13+r14*1]
000076049b1e1b5e  lea r14, [rax+0x118]
000076049b1e1b65  mov r11, [r13+r14*1]
000076049b1e1b6a  movq xmm1, r12
000076049b1e1b6f  movq xmm15, r11
000076049b1e1b74  movq xmm1, xmm1
000076049b1e1b78  movq xmm1, xmm1
000076049b1e1b7c  movaps [r15+0x1E0], xmm1
000076049b1e1b84  movq xmm15, xmm15
000076049b1e1b89  movq xmm15, xmm15
000076049b1e1b8e  movaps [r15+0x1D0], xmm15
000076049b1e1b96  lea r14, [rax+0x100]
000076049b1e1b9d  mov r12, [r13+r14*1]
000076049b1e1ba2  lea r14, [rax+0x108]
000076049b1e1ba9  mov r11, [r13+r14*1]
000076049b1e1bae  movq xmm1, r12
000076049b1e1bb3  movq xmm15, r11
000076049b1e1bb8  movq xmm1, xmm1
000076049b1e1bbc  movq xmm1, xmm1
000076049b1e1bc0  movaps [r15+0x200], xmm1
000076049b1e1bc8  movq xmm15, xmm15
000076049b1e1bcd  movq xmm15, xmm15
000076049b1e1bd2  movaps [r15+0x1F0], xmm15
000076049b1e1bda  mov qword ptr [r15+0x40], 0x430000
000076049b1e1be2  mov r14d, 0x430510
000076049b1e1be8  mov r12, [r13+r14*1]
000076049b1e1bed  movq xmm1, r12
000076049b1e1bf2  lea r14, [rax+0x150]
000076049b1e1bf9  mov [r15+0xF8], r14
000076049b1e1c00  mov rax, [r15+0x50]
000076049b1e1c04  movups xmm15, [r13+rax*1]
000076049b1e1c0a  movaps [r15+0x120], xmm15
000076049b1e1c12  mov qword ptr [r15+0x48], 0x10
000076049b1e1c1a  xor eax, eax
000076049b1e1c1c  mov r14d, 0x10
000076049b1e1c22  mov r12d, 0x200
000076049b1e1c28  cmp r14, r12
000076049b1e1c2b  cmc
000076049b1e1c2c  lahf
000076049b1e1c2d  seto al
000076049b1e1c30  mov [r15+0x108], eax
000076049b1e1c37  pextrq rax, xmm15, 0x01
000076049b1e1c3e  movq xmm14, rax
000076049b1e1c43  movaps [r15+0x130], xmm14
000076049b1e1c4b  movq rax, xmm1
000076049b1e1c50  movq r14, xmm15
000076049b1e1c55  vmovq xmm1, rax
000076049b1e1c5a  vmovq xmm15, r14
000076049b1e1c5f  movaps xmm13, xmm1
000076049b1e1c63  addsd xmm13, xmm15
000076049b1e1c68  ucomisd xmm13, xmm13
000076049b1e1c6d  jp 0x000076049B1E1D86
000076049b1e1c73  movq xmm13, xmm13
000076049b1e1c78  movq rax, xmm13
000076049b1e1c7d  movq r14, xmm14
000076049b1e1c82  vmovq xmm1, rax
000076049b1e1c87  vmovq xmm15, r14
000076049b1e1c8c  movaps xmm14, xmm1
000076049b1e1c90  addsd xmm14, xmm15
000076049b1e1c95  ucomisd xmm14, xmm14
000076049b1e1c9a  jp 0x000076049B1E1DCE
000076049b1e1ca0  movq xmm14, xmm14
000076049b1e1ca5  movaps [r15+0x110], xmm14
000076049b1e1cad  mov eax, [r15+0x108]
000076049b1e1cb4  sahf
000076049b1e1cb5  jnz 0x000076049B1E1CE7
000076049b1e1cb7  cmp dword ptr [r15+0x318], 0x00
000076049b1e1cbf  jz 0x000076049B1E1FE0
000076049b1e1cc5  nop [rax+rax*1], ax
000076049b1e1cce  nop [rax+rax*1], eax
000076049b1e1cd6  mov eax, 0x410490
000076049b1e1cdb  mov [r15+0x100], rax
000076049b1e1ce2  jmp 0x000076049AFFE110
000076049b1e1ce7  cmp dword ptr [r15+0x318], 0x00
000076049b1e1cef  jz 0x000076049B1E1E20
000076049b1e1cf5  nop [rax+rax*1], ax
000076049b1e1cfe  nop [rax+rax*1], eax
000076049b1e1d06  mov eax, 0x410474
000076049b1e1d0b  mov [r15+0x100], rax
000076049b1e1d12  jmp 0x000076049AFFE110
000076049b1e1d17  int3
000076049b1e1d18  call 0x000076049B0E27E0
000076049b1e1d1d  jmp 0x000076049B1E1AC3
000076049b1e1d22  call 0x000076049B0E27E0
000076049b1e1d27  jmp 0x000076049B1E1AD6
000076049b1e1d2c  call 0x000076049B0E1570
000076049b1e1d31  jmp 0x000076049B1E1AE2
000076049b1e1d36  call 0x000076049B0E27E0
000076049b1e1d3b  jmp 0x000076049B1E1B1A
000076049b1e1d40  call 0x000076049B0E1570
000076049b1e1d45  jmp 0x000076049B1E1B26
000076049b1e1d4a  call 0x000076049B0E27E0
000076049b1e1d4f  jmp 0x000076049B1E1B5E
000076049b1e1d54  call 0x000076049B0E1570
000076049b1e1d59  jmp 0x000076049B1E1B6A
000076049b1e1d5e  call 0x000076049B0E27E0
000076049b1e1d63  jmp 0x000076049B1E1BA2
000076049b1e1d68  call 0x000076049B0E1570
000076049b1e1d6d  jmp 0x000076049B1E1BAE
000076049b1e1d72  call 0x000076049B0E27E0
000076049b1e1d77  jmp 0x000076049B1E1BED
000076049b1e1d7c  call 0x000076049B00E760
000076049b1e1d81  jmp 0x000076049B1E1C0A
000076049b1e1d86  ucomisd xmm1, xmm15
000076049b1e1d8b  jp 0x000076049B1E1D9A
000076049b1e1d8d  movaps xmm13, [0x000076049ADFE060]
000076049b1e1d95  jmp 0x000076049B1E1C73
000076049b1e1d9a  vxorps xmm0, xmm1, xmm15
000076049b1e1d9f  pextrw eax, xmm0, 0x03
000076049b1e1da4  and eax, 0x7FF8
000076049b1e1da9  cmp eax, 0x08
000076049b1e1dac  jnz 0x000076049B1E1C73
000076049b1e1db2  movq rax, xmm15
000076049b1e1db7  shl rax, 0x0D
000076049b1e1dbb  jbe 0x000076049B1E1C73
000076049b1e1dc1  vorps xmm13, xmm15, [0x000076049ADFE070]
000076049b1e1dc9  jmp 0x000076049B1E1C73
000076049b1e1dce  ucomisd xmm1, xmm15
000076049b1e1dd3  jp 0x000076049B1E1DE2
000076049b1e1dd5  movaps xmm14, [0x000076049ADFE060]
000076049b1e1ddd  jmp 0x000076049B1E1CA0
000076049b1e1de2  vxorps xmm0, xmm1, xmm15
000076049b1e1de7  pextrw eax, xmm0, 0x03
000076049b1e1dec  and eax, 0x7FF8
000076049b1e1df1  cmp eax, 0x08
000076049b1e1df4  jnz 0x000076049B1E1CA0
000076049b1e1dfa  movq rax, xmm15
000076049b1e1dff  shl rax, 0x0D
000076049b1e1e03  jbe 0x000076049B1E1CA0
000076049b1e1e09  vorps xmm14, xmm15, [0x000076049ADFE070]
000076049b1e1e11  jmp 0x000076049B1E1CA0
000076049b1e1e16  int3
000076049b1e1e17  nop [rax+rax*1], ax
000076049b1e1e20  mov rax, [r15+0x48]
000076049b1e1e24  mov r14, [r15+0x50]
000076049b1e1e28  lea r12, [r14+rax*1]
000076049b1e1e2c  movups xmm1, [r13+r12*1]
000076049b1e1e32  movaps [r15+0x120], xmm1
000076049b1e1e3a  lea r14, [rax+0x10]
000076049b1e1e3e  mov [r15+0x48], r14
000076049b1e1e42  xor eax, eax
000076049b1e1e44  mov r12d, 0x200
000076049b1e1e4a  cmp r14, r12
000076049b1e1e4d  cmc
000076049b1e1e4e  lahf
000076049b1e1e4f  seto al
000076049b1e1e52  mov [r15+0x108], eax
000076049b1e1e59  pextrq rax, xmm1, 0x01
000076049b1e1e60  movq xmm15, rax
000076049b1e1e65  movaps [r15+0x130], xmm15
000076049b1e1e6d  movaps xmm14, [r15+0x110]
000076049b1e1e75  movq rax, xmm14
000076049b1e1e7a  movq r14, xmm1
000076049b1e1e7f  vmovq xmm1, rax
000076049b1e1e84  vmovq xmm14, r14
000076049b1e1e89  movaps xmm13, xmm1
000076049b1e1e8d  addsd xmm13, xmm14
000076049b1e1e92  ucomisd xmm13, xmm13
000076049b1e1e97  jp 0x000076049B1E1F4C
000076049b1e1e9d  movq xmm13, xmm13
000076049b1e1ea2  movq rax, xmm13
000076049b1e1ea7  movq r14, xmm15
000076049b1e1eac  vmovq xmm1, rax
000076049b1e1eb1  vmovq xmm15, r14
000076049b1e1eb6  movaps xmm14, xmm1
000076049b1e1eba  addsd xmm14, xmm15
000076049b1e1ebf  ucomisd xmm14, xmm14
000076049b1e1ec4  jp 0x000076049B1E1F94
000076049b1e1eca  movq xmm14, xmm14
000076049b1e1ecf  movaps [r15+0x110], xmm14
000076049b1e1ed7  mov eax, [r15+0x108]
000076049b1e1ede  sahf
000076049b1e1edf  jnz 0x000076049B1E1F11
000076049b1e1ee1  cmp dword ptr [r15+0x318], 0x00
000076049b1e1ee9  jz 0x000076049B1E1FE0
000076049b1e1eef  nop [rax+rax*1], ax
000076049b1e1ef8  nop [rax+rax*1], eax
000076049b1e1f00  mov eax, 0x410490
000076049b1e1f05  mov [r15+0x100], rax
000076049b1e1f0c  jmp 0x000076049AFFE110
000076049b1e1f11  cmp dword ptr [r15+0x318], 0x00
000076049b1e1f19  jz 0x000076049B1E1E20
000076049b1e1f1f  nop [rax+rax*1], ax
000076049b1e1f28  nop [rax+rax*1], eax
000076049b1e1f30  mov eax, 0x410474
000076049b1e1f35  mov [r15+0x100], rax
000076049b1e1f3c  jmp 0x000076049AFFE110
000076049b1e1f41  int3
000076049b1e1f42  call 0x000076049B0B52F0
000076049b1e1f47  jmp 0x000076049B1E1E32
000076049b1e1f4c  ucomisd xmm1, xmm14
000076049b1e1f51  jp 0x000076049B1E1F60
000076049b1e1f53  movaps xmm13, [0x000076049ADFE060]
000076049b1e1f5b  jmp 0x000076049B1E1E9D
000076049b1e1f60  vxorps xmm0, xmm1, xmm14
000076049b1e1f65  pextrw eax, xmm0, 0x03
000076049b1e1f6a  and eax, 0x7FF8
000076049b1e1f6f  cmp eax, 0x08
000076049b1e1f72  jnz 0x000076049B1E1E9D
000076049b1e1f78  movq rax, xmm14
000076049b1e1f7d  shl rax, 0x0D
000076049b1e1f81  jbe 0x000076049B1E1E9D
000076049b1e1f87  vorps xmm13, xmm14, [0x000076049ADFE070]
000076049b1e1f8f  jmp 0x000076049B1E1E9D
000076049b1e1f94  ucomisd xmm1, xmm15
000076049b1e1f99  jp 0x000076049B1E1FA8
000076049b1e1f9b  movaps xmm14, [0x000076049ADFE060]
000076049b1e1fa3  jmp 0x000076049B1E1ECA
000076049b1e1fa8  vxorps xmm0, xmm1, xmm15
000076049b1e1fad  pextrw eax, xmm0, 0x03
000076049b1e1fb2  and eax, 0x7FF8
000076049b1e1fb7  cmp eax, 0x08
000076049b1e1fba  jnz 0x000076049B1E1ECA
000076049b1e1fc0  movq rax, xmm15
000076049b1e1fc5  shl rax, 0x0D
000076049b1e1fc9  jbe 0x000076049B1E1ECA
000076049b1e1fcf  vorps xmm14, xmm15, [0x000076049ADFE070]
000076049b1e1fd7  jmp 0x000076049B1E1ECA
000076049b1e1fdc  int3
000076049b1e1fdd  nop [rax], eax
000076049b1e1fe0  mov rax, [r15+0x40]
000076049b1e1fe4  lea r14, [rax+0x510]
000076049b1e1feb  movaps xmm1, [r15+0x110]
000076049b1e1ff3  movq rax, xmm1
000076049b1e1ff8  mov [r13+r14*1], rax
000076049b1e1ffd  mov rax, [r15+0xF0]
000076049b1e2004  mov [r15+0x100], rax
000076049b1e200b  jmp 0x000076049B1CE5C0
000076049b1e2010  int3
000076049b1e2011  call 0x000076049B0D5EB0
000076049b1e2016  jmp 0x000076049B1E1FFD
000076049b1e201b  int3
000076049b1e201c  nop [rax], eax
000076049b1e2020  mov qword ptr [r15+0x100], 0x04
000076049b1e202b  mov esi, 0x00
000076049b1e2030  mov edx, 0x09
000076049b1e2035  mov rdi, 0x7FFD4A5619E0
000076049b1e203f  mov rax, 0x64C067FCF970
000076049b1e2049  call rax
000076049b1e204b  cmp dword ptr [r15+0x318], 0x00
000076049b1e2053  jnz 0x000076049AFFE110
000076049b1e2059  jmp 0x000076049AFFE0A0
000076049b1e205e  int3
000076049b1e205f  int3
