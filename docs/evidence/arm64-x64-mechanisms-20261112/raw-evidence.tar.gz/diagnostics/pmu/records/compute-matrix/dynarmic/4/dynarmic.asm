00007986e0dce69b  nop [rax+rax*1], eax
00007986e0dce6a0  vmovaps xmm1, [0x00007986E09FE010]
00007986e0dce6a8  movq xmm1, xmm1
00007986e0dce6ac  movaps [r15+0x110], xmm1
00007986e0dce6b4  vmovaps xmm1, [0x00007986E09FE020]
00007986e0dce6bc  movq xmm1, xmm1
00007986e0dce6c0  movaps [r15+0x120], xmm1
00007986e0dce6c8  mov eax, 0x4204C0
00007986e0dce6cd  mov r14, [r13+rax*1]
00007986e0dce6d2  movq xmm1, r14
00007986e0dce6d7  movaps [r15+0x130], xmm1
00007986e0dce6df  vmovaps xmm1, [0x00007986E09FE030]
00007986e0dce6e7  vpbroadcastq xmm1, xmm1
00007986e0dce6ec  movaps [r15+0x140], xmm1
00007986e0dce6f4  mov qword ptr [r15+0x40], 0x02
00007986e0dce6fc  vmovaps xmm15, [0x00007986E09FE040]
00007986e0dce704  movq xmm15, xmm15
00007986e0dce709  movaps [r15+0x150], xmm15
00007986e0dce711  mov qword ptr [r15+0x58], 0x420000
00007986e0dce719  vmovaps xmm15, [0x00007986E09FE050]
00007986e0dce721  vpbroadcastq xmm15, xmm15
00007986e0dce726  movaps [r15+0x160], xmm15
00007986e0dce72e  mov rax, [r15+0x40]
00007986e0dce732  vmovq xmm14, rax
00007986e0dce737  vpbroadcastq xmm14, xmm14
00007986e0dce73c  movaps [r15+0x170], xmm14
00007986e0dce744  mov eax, 0x4204D0
00007986e0dce749  movups xmm13, [r13+rax*1]
00007986e0dce74f  mov qword ptr [r15+0x40], 0x430518
00007986e0dce757  mov qword ptr [r15+0x50], 0x430720
00007986e0dce75f  vpmovqd xmm12, xmm13
00007986e0dce765  pxor xmm11, xmm11
00007986e0dce76a  punpcklqdq xmm12, xmm11
00007986e0dce76f  movaps [r15+0x210], xmm12
00007986e0dce777  movq xmm12, qword ptr [r15+0x120]
00007986e0dce780  movq xmm11, qword ptr [r15+0x130]
00007986e0dce789  psubd xmm12, xmm11
00007986e0dce78e  movq xmm12, xmm12
00007986e0dce793  paddq xmm13, xmm14
00007986e0dce798  movaps [r15+0x180], xmm13
00007986e0dce7a0  movq xmm14, qword ptr [r15+0x150]
00007986e0dce7a9  paddd xmm11, xmm14
00007986e0dce7ae  movq xmm11, xmm11
00007986e0dce7b3  movq xmm11, xmm11
00007986e0dce7b8  movaps [r15+0x130], xmm11
00007986e0dce7c0  pmovzxdq xmm12, xmm12
00007986e0dce7c6  psllq xmm12, 0x00
00007986e0dce7cc  movq xmm14, qword ptr [r15+0x210]
00007986e0dce7d5  movq xmm13, qword ptr [r15+0x110]
00007986e0dce7de  paddd xmm14, xmm13
00007986e0dce7e3  movq xmm14, xmm14
00007986e0dce7e8  vcvtuqq2pd xmm12, xmm12
00007986e0dce7ee  pmovzxdq xmm14, xmm14
00007986e0dce7f4  psllq xmm14, 0x00
00007986e0dce7fa  vcvtuqq2pd xmm14, xmm14
00007986e0dce800  movaps xmm13, xmm12
00007986e0dce804  mulpd xmm13, xmm1
00007986e0dce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007986e0dce80f  ptest xmm11, xmm11
00007986e0dce815  jnz 0x00007986E0DCE8FF
00007986e0dce81b  movaps [r15+0x220], xmm13
00007986e0dce823  mov eax, 0x430720
00007986e0dce828  movups [r13+rax*1], xmm13
00007986e0dce82e  movaps xmm1, xmm14
00007986e0dce832  mulpd xmm1, xmm15
00007986e0dce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007986e0dce83c  ptest xmm13, xmm13
00007986e0dce842  jnz 0x00007986E0DCEA4C
00007986e0dce848  movaps [r15+0x210], xmm1
00007986e0dce850  mov eax, 0x430518
00007986e0dce855  movups [r13+rax*1], xmm1
00007986e0dce85b  mov qword ptr [r15+0x48], 0x10
00007986e0dce863  xor eax, eax
00007986e0dce865  mov r14d, 0x10
00007986e0dce86b  mov r12d, 0x200
00007986e0dce871  cmp r14, r12
00007986e0dce874  cmc
00007986e0dce875  lahf
00007986e0dce876  seto al
00007986e0dce879  mov [r15+0x108], eax
00007986e0dce880  mov eax, [r15+0x108]
00007986e0dce887  sahf
00007986e0dce888  jnz 0x00007986E0DCE8BA
00007986e0dce88a  cmp dword ptr [r15+0x318], 0x00
00007986e0dce892  jz 0x00007986E0DCEFF0
00007986e0dce898  nop [rax+rax*1], ax
00007986e0dce8a1  nop [rax+rax*1], eax
00007986e0dce8a9  mov eax, 0x4101EC
00007986e0dce8ae  mov [r15+0x100], rax
00007986e0dce8b5  jmp 0x00007986E0BFE110
00007986e0dce8ba  cmp dword ptr [r15+0x318], 0x00
00007986e0dce8c2  jz 0x00007986E0DCEBA0
00007986e0dce8c8  nop [rax+rax*1], ax
00007986e0dce8d1  nop [rax+rax*1], eax
00007986e0dce8d9  mov eax, 0x4101AC
00007986e0dce8de  mov [r15+0x100], rax
00007986e0dce8e5  jmp 0x00007986E0BFE110
00007986e0dce8ea  int3
00007986e0dce8eb  call 0x00007986E0C0DC20
00007986e0dce8f0  jmp 0x00007986E0DCE6D2
00007986e0dce8f5  call 0x00007986E0C0C260
00007986e0dce8fa  jmp 0x00007986E0DCE74F
00007986e0dce8ff  sub rsp, 0x08
00007986e0dce903  push rax
00007986e0dce904  push rcx
00007986e0dce905  push rdx
00007986e0dce906  push rdi
00007986e0dce907  push rsi
00007986e0dce908  push r8
00007986e0dce90a  push r9
00007986e0dce90c  push r10
00007986e0dce90e  push r11
00007986e0dce910  sub rsp, 0xF0
00007986e0dce917  vmovaps [rsp], xmm0
00007986e0dce91c  vmovaps [rsp+0x10], xmm1
00007986e0dce922  vmovaps [rsp+0x20], xmm2
00007986e0dce928  vmovaps [rsp+0x30], xmm3
00007986e0dce92e  vmovaps [rsp+0x40], xmm4
00007986e0dce934  vmovaps [rsp+0x50], xmm5
00007986e0dce93a  vmovaps [rsp+0x60], xmm6
00007986e0dce940  vmovaps [rsp+0x70], xmm7
00007986e0dce946  vmovaps [rsp+0x80], xmm8
00007986e0dce94f  vmovaps [rsp+0x90], xmm9
00007986e0dce958  vmovaps [rsp+0xA0], xmm10
00007986e0dce961  vmovaps [rsp+0xB0], xmm11
00007986e0dce96a  vmovaps [rsp+0xC0], xmm12
00007986e0dce973  vmovaps [rsp+0xD0], xmm14
00007986e0dce97c  vmovaps [rsp+0xE0], xmm15
00007986e0dce985  sub rsp, 0x30
00007986e0dce989  movaps [rsp], xmm13
00007986e0dce98e  movaps [rsp+0x10], xmm12
00007986e0dce994  movaps [rsp+0x20], xmm1
00007986e0dce999  lea rdi, [rsp]
00007986e0dce99d  mov esi, 0x00
00007986e0dce9a2  mov rax, 0x5652C689F530
00007986e0dce9ac  call rax
00007986e0dce9ae  movaps xmm13, [rsp]
00007986e0dce9b3  add rsp, 0x30
00007986e0dce9b7  vmovaps xmm0, [rsp]
00007986e0dce9bc  vmovaps xmm1, [rsp+0x10]
00007986e0dce9c2  vmovaps xmm2, [rsp+0x20]
00007986e0dce9c8  vmovaps xmm3, [rsp+0x30]
00007986e0dce9ce  vmovaps xmm4, [rsp+0x40]
00007986e0dce9d4  vmovaps xmm5, [rsp+0x50]
00007986e0dce9da  vmovaps xmm6, [rsp+0x60]
00007986e0dce9e0  vmovaps xmm7, [rsp+0x70]
00007986e0dce9e6  vmovaps xmm8, [rsp+0x80]
00007986e0dce9ef  vmovaps xmm9, [rsp+0x90]
00007986e0dce9f8  vmovaps xmm10, [rsp+0xA0]
00007986e0dcea01  vmovaps xmm11, [rsp+0xB0]
00007986e0dcea0a  vmovaps xmm12, [rsp+0xC0]
00007986e0dcea13  vmovaps xmm14, [rsp+0xD0]
00007986e0dcea1c  vmovaps xmm15, [rsp+0xE0]
00007986e0dcea25  add rsp, 0xF0
00007986e0dcea2c  pop r11
00007986e0dcea2e  pop r10
00007986e0dcea30  pop r9
00007986e0dcea32  pop r8
00007986e0dcea34  pop rsi
00007986e0dcea35  pop rdi
00007986e0dcea36  pop rdx
00007986e0dcea37  pop rcx
00007986e0dcea38  pop rax
00007986e0dcea39  add rsp, 0x08
00007986e0dcea3d  jmp 0x00007986E0DCE81B
00007986e0dcea42  call 0x00007986E0C0C380
00007986e0dcea47  jmp 0x00007986E0DCE82E
00007986e0dcea4c  sub rsp, 0x08
00007986e0dcea50  push rax
00007986e0dcea51  push rcx
00007986e0dcea52  push rdx
00007986e0dcea53  push rdi
00007986e0dcea54  push rsi
00007986e0dcea55  push r8
00007986e0dcea57  push r9
00007986e0dcea59  push r10
00007986e0dcea5b  push r11
00007986e0dcea5d  sub rsp, 0xF0
00007986e0dcea64  vmovaps [rsp], xmm0
00007986e0dcea69  vmovaps [rsp+0x10], xmm2
00007986e0dcea6f  vmovaps [rsp+0x20], xmm3
00007986e0dcea75  vmovaps [rsp+0x30], xmm4
00007986e0dcea7b  vmovaps [rsp+0x40], xmm5
00007986e0dcea81  vmovaps [rsp+0x50], xmm6
00007986e0dcea87  vmovaps [rsp+0x60], xmm7
00007986e0dcea8d  vmovaps [rsp+0x70], xmm8
00007986e0dcea93  vmovaps [rsp+0x80], xmm9
00007986e0dcea9c  vmovaps [rsp+0x90], xmm10
00007986e0dceaa5  vmovaps [rsp+0xA0], xmm11
00007986e0dceaae  vmovaps [rsp+0xB0], xmm12
00007986e0dceab7  vmovaps [rsp+0xC0], xmm13
00007986e0dceac0  vmovaps [rsp+0xD0], xmm14
00007986e0dceac9  vmovaps [rsp+0xE0], xmm15
00007986e0dcead2  sub rsp, 0x30
00007986e0dcead6  movaps [rsp], xmm1
00007986e0dceada  movaps [rsp+0x10], xmm14
00007986e0dceae0  movaps [rsp+0x20], xmm15
00007986e0dceae6  lea rdi, [rsp]
00007986e0dceaea  mov esi, 0x00
00007986e0dceaef  mov rax, 0x5652C689F530
00007986e0dceaf9  call rax
00007986e0dceafb  movaps xmm1, [rsp]
00007986e0dceaff  add rsp, 0x30
00007986e0dceb03  vmovaps xmm0, [rsp]
00007986e0dceb08  vmovaps xmm2, [rsp+0x10]
00007986e0dceb0e  vmovaps xmm3, [rsp+0x20]
00007986e0dceb14  vmovaps xmm4, [rsp+0x30]
00007986e0dceb1a  vmovaps xmm5, [rsp+0x40]
00007986e0dceb20  vmovaps xmm6, [rsp+0x50]
00007986e0dceb26  vmovaps xmm7, [rsp+0x60]
00007986e0dceb2c  vmovaps xmm8, [rsp+0x70]
00007986e0dceb32  vmovaps xmm9, [rsp+0x80]
00007986e0dceb3b  vmovaps xmm10, [rsp+0x90]
00007986e0dceb44  vmovaps xmm11, [rsp+0xA0]
00007986e0dceb4d  vmovaps xmm12, [rsp+0xB0]
00007986e0dceb56  vmovaps xmm13, [rsp+0xC0]
00007986e0dceb5f  vmovaps xmm14, [rsp+0xD0]
00007986e0dceb68  vmovaps xmm15, [rsp+0xE0]
00007986e0dceb71  add rsp, 0xF0
00007986e0dceb78  pop r11
00007986e0dceb7a  pop r10
00007986e0dceb7c  pop r9
00007986e0dceb7e  pop r8
00007986e0dceb80  pop rsi
00007986e0dceb81  pop rdi
00007986e0dceb82  pop rdx
00007986e0dceb83  pop rcx
00007986e0dceb84  pop rax
00007986e0dceb85  add rsp, 0x08
00007986e0dceb89  jmp 0x00007986E0DCE848
00007986e0dceb8e  call 0x00007986E0BFF540
00007986e0dceb93  jmp 0x00007986E0DCE85B
00007986e0dceb98  int3
00007986e0dceb99  nop [rax], eax
00007986e0dceba0  movaps xmm1, [r15+0x180]
00007986e0dceba8  vpmovqd xmm15, xmm1
00007986e0dcebae  pxor xmm14, xmm14
00007986e0dcebb3  punpcklqdq xmm15, xmm14
00007986e0dcebb8  movaps [r15+0x210], xmm15
00007986e0dcebc0  movq xmm15, qword ptr [r15+0x120]
00007986e0dcebc9  movq xmm14, qword ptr [r15+0x130]
00007986e0dcebd2  psubd xmm15, xmm14
00007986e0dcebd7  movq xmm15, xmm15
00007986e0dcebdc  movaps xmm13, [r15+0x170]
00007986e0dcebe4  paddq xmm1, xmm13
00007986e0dcebe9  movaps [r15+0x180], xmm1
00007986e0dcebf1  movq xmm1, qword ptr [r15+0x150]
00007986e0dcebfa  paddd xmm14, xmm1
00007986e0dcebff  movq xmm14, xmm14
00007986e0dcec04  movq xmm14, xmm14
00007986e0dcec09  movaps [r15+0x130], xmm14
00007986e0dcec11  pmovzxdq xmm15, xmm15
00007986e0dcec17  psllq xmm15, 0x00
00007986e0dcec1d  movq xmm1, qword ptr [r15+0x210]
00007986e0dcec26  movq xmm14, qword ptr [r15+0x110]
00007986e0dcec2f  paddd xmm1, xmm14
00007986e0dcec34  movq xmm1, xmm1
00007986e0dcec38  vcvtuqq2pd xmm15, xmm15
00007986e0dcec3e  pmovzxdq xmm1, xmm1
00007986e0dcec43  psllq xmm1, 0x00
00007986e0dcec48  vcvtuqq2pd xmm1, xmm1
00007986e0dcec4e  movaps xmm14, [r15+0x140]
00007986e0dcec56  movaps xmm13, xmm15
00007986e0dcec5a  mulpd xmm13, xmm14
00007986e0dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007986e0dcec65  ptest xmm12, xmm12
00007986e0dcec6b  jnz 0x00007986E0DCED4E
00007986e0dcec71  movaps [r15+0x220], xmm13
00007986e0dcec79  mov rax, [r15+0x48]
00007986e0dcec7d  mov r14, [r15+0x50]
00007986e0dcec81  lea r12, [r14+rax*1]
00007986e0dcec85  movups [r13+r12*1], xmm13
00007986e0dcec8b  movaps xmm15, [r15+0x160]
00007986e0dcec93  movaps xmm14, xmm1
00007986e0dcec97  mulpd xmm14, xmm15
00007986e0dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007986e0dceca2  ptest xmm13, xmm13
00007986e0dceca8  jnz 0x00007986E0DCEE9C
00007986e0dcecae  movaps [r15+0x210], xmm14
00007986e0dcecb6  mov r14, [r15+0x40]
00007986e0dcecba  lea r12, [r14+rax*1]
00007986e0dcecbe  movups [r13+r12*1], xmm14
00007986e0dcecc4  lea r14, [rax+0x10]
00007986e0dcecc8  mov [r15+0x48], r14
00007986e0dceccc  xor eax, eax
00007986e0dcecce  mov r12d, 0x200
00007986e0dcecd4  cmp r14, r12
00007986e0dcecd7  cmc
00007986e0dcecd8  lahf
00007986e0dcecd9  seto al
00007986e0dcecdc  mov [r15+0x108], eax
00007986e0dcece3  mov eax, [r15+0x108]
00007986e0dcecea  sahf
00007986e0dceceb  jnz 0x00007986E0DCED1D
00007986e0dceced  cmp dword ptr [r15+0x318], 0x00
00007986e0dcecf5  jz 0x00007986E0DCEFF0
00007986e0dcecfb  nop [rax+rax*1], ax
00007986e0dced04  nop [rax+rax*1], eax
00007986e0dced0c  mov eax, 0x4101EC
00007986e0dced11  mov [r15+0x100], rax
00007986e0dced18  jmp 0x00007986E0BFE110
00007986e0dced1d  cmp dword ptr [r15+0x318], 0x00
00007986e0dced25  jz 0x00007986E0DCEBA0
00007986e0dced2b  nop [rax+rax*1], ax
00007986e0dced34  nop [rax+rax*1], eax
00007986e0dced3c  mov eax, 0x4101AC
00007986e0dced41  mov [r15+0x100], rax
00007986e0dced48  jmp 0x00007986E0BFE110
00007986e0dced4d  int3
00007986e0dced4e  sub rsp, 0x08
00007986e0dced52  push rax
00007986e0dced53  push rcx
00007986e0dced54  push rdx
00007986e0dced55  push rdi
00007986e0dced56  push rsi
00007986e0dced57  push r8
00007986e0dced59  push r9
00007986e0dced5b  push r10
00007986e0dced5d  push r11
00007986e0dced5f  sub rsp, 0xF0
00007986e0dced66  vmovaps [rsp], xmm0
00007986e0dced6b  vmovaps [rsp+0x10], xmm1
00007986e0dced71  vmovaps [rsp+0x20], xmm2
00007986e0dced77  vmovaps [rsp+0x30], xmm3
00007986e0dced7d  vmovaps [rsp+0x40], xmm4
00007986e0dced83  vmovaps [rsp+0x50], xmm5
00007986e0dced89  vmovaps [rsp+0x60], xmm6
00007986e0dced8f  vmovaps [rsp+0x70], xmm7
00007986e0dced95  vmovaps [rsp+0x80], xmm8
00007986e0dced9e  vmovaps [rsp+0x90], xmm9
00007986e0dceda7  vmovaps [rsp+0xA0], xmm10
00007986e0dcedb0  vmovaps [rsp+0xB0], xmm11
00007986e0dcedb9  vmovaps [rsp+0xC0], xmm12
00007986e0dcedc2  vmovaps [rsp+0xD0], xmm14
00007986e0dcedcb  vmovaps [rsp+0xE0], xmm15
00007986e0dcedd4  sub rsp, 0x30
00007986e0dcedd8  movaps [rsp], xmm13
00007986e0dceddd  movaps [rsp+0x10], xmm15
00007986e0dcede3  movaps [rsp+0x20], xmm14
00007986e0dcede9  lea rdi, [rsp]
00007986e0dceded  mov esi, 0x00
00007986e0dcedf2  mov rax, 0x5652C689F530
00007986e0dcedfc  call rax
00007986e0dcedfe  movaps xmm13, [rsp]
00007986e0dcee03  add rsp, 0x30
00007986e0dcee07  vmovaps xmm0, [rsp]
00007986e0dcee0c  vmovaps xmm1, [rsp+0x10]
00007986e0dcee12  vmovaps xmm2, [rsp+0x20]
00007986e0dcee18  vmovaps xmm3, [rsp+0x30]
00007986e0dcee1e  vmovaps xmm4, [rsp+0x40]
00007986e0dcee24  vmovaps xmm5, [rsp+0x50]
00007986e0dcee2a  vmovaps xmm6, [rsp+0x60]
00007986e0dcee30  vmovaps xmm7, [rsp+0x70]
00007986e0dcee36  vmovaps xmm8, [rsp+0x80]
00007986e0dcee3f  vmovaps xmm9, [rsp+0x90]
00007986e0dcee48  vmovaps xmm10, [rsp+0xA0]
00007986e0dcee51  vmovaps xmm11, [rsp+0xB0]
00007986e0dcee5a  vmovaps xmm12, [rsp+0xC0]
00007986e0dcee63  vmovaps xmm14, [rsp+0xD0]
00007986e0dcee6c  vmovaps xmm15, [rsp+0xE0]
00007986e0dcee75  add rsp, 0xF0
00007986e0dcee7c  pop r11
00007986e0dcee7e  pop r10
00007986e0dcee80  pop r9
00007986e0dcee82  pop r8
00007986e0dcee84  pop rsi
00007986e0dcee85  pop rdi
00007986e0dcee86  pop rdx
00007986e0dcee87  pop rcx
00007986e0dcee88  pop rax
00007986e0dcee89  add rsp, 0x08
00007986e0dcee8d  jmp 0x00007986E0DCEC71
00007986e0dcee92  call 0x00007986E0CC2240
00007986e0dcee97  jmp 0x00007986E0DCEC8B
00007986e0dcee9c  sub rsp, 0x08
00007986e0dceea0  push rax
00007986e0dceea1  push rcx
00007986e0dceea2  push rdx
00007986e0dceea3  push rdi
00007986e0dceea4  push rsi
00007986e0dceea5  push r8
00007986e0dceea7  push r9
00007986e0dceea9  push r10
00007986e0dceeab  push r11
00007986e0dceead  sub rsp, 0xF0
00007986e0dceeb4  vmovaps [rsp], xmm0
00007986e0dceeb9  vmovaps [rsp+0x10], xmm1
00007986e0dceebf  vmovaps [rsp+0x20], xmm2
00007986e0dceec5  vmovaps [rsp+0x30], xmm3
00007986e0dceecb  vmovaps [rsp+0x40], xmm4
00007986e0dceed1  vmovaps [rsp+0x50], xmm5
00007986e0dceed7  vmovaps [rsp+0x60], xmm6
00007986e0dceedd  vmovaps [rsp+0x70], xmm7
00007986e0dceee3  vmovaps [rsp+0x80], xmm8
00007986e0dceeec  vmovaps [rsp+0x90], xmm9
00007986e0dceef5  vmovaps [rsp+0xA0], xmm10
00007986e0dceefe  vmovaps [rsp+0xB0], xmm11
00007986e0dcef07  vmovaps [rsp+0xC0], xmm12
00007986e0dcef10  vmovaps [rsp+0xD0], xmm13
00007986e0dcef19  vmovaps [rsp+0xE0], xmm15
00007986e0dcef22  sub rsp, 0x30
00007986e0dcef26  movaps [rsp], xmm14
00007986e0dcef2b  movaps [rsp+0x10], xmm1
00007986e0dcef30  movaps [rsp+0x20], xmm15
00007986e0dcef36  lea rdi, [rsp]
00007986e0dcef3a  mov esi, 0x00
00007986e0dcef3f  mov rax, 0x5652C689F530
00007986e0dcef49  call rax
00007986e0dcef4b  movaps xmm14, [rsp]
00007986e0dcef50  add rsp, 0x30
00007986e0dcef54  vmovaps xmm0, [rsp]
00007986e0dcef59  vmovaps xmm1, [rsp+0x10]
00007986e0dcef5f  vmovaps xmm2, [rsp+0x20]
00007986e0dcef65  vmovaps xmm3, [rsp+0x30]
00007986e0dcef6b  vmovaps xmm4, [rsp+0x40]
00007986e0dcef71  vmovaps xmm5, [rsp+0x50]
00007986e0dcef77  vmovaps xmm6, [rsp+0x60]
00007986e0dcef7d  vmovaps xmm7, [rsp+0x70]
00007986e0dcef83  vmovaps xmm8, [rsp+0x80]
00007986e0dcef8c  vmovaps xmm9, [rsp+0x90]
00007986e0dcef95  vmovaps xmm10, [rsp+0xA0]
00007986e0dcef9e  vmovaps xmm11, [rsp+0xB0]
00007986e0dcefa7  vmovaps xmm12, [rsp+0xC0]
00007986e0dcefb0  vmovaps xmm13, [rsp+0xD0]
00007986e0dcefb9  vmovaps xmm15, [rsp+0xE0]
00007986e0dcefc2  add rsp, 0xF0
00007986e0dcefc9  pop r11
00007986e0dcefcb  pop r10
00007986e0dcefcd  pop r9
00007986e0dcefcf  pop r8
00007986e0dcefd1  pop rsi
00007986e0dcefd2  pop rdi
00007986e0dcefd3  pop rdx
00007986e0dcefd4  pop rcx
00007986e0dcefd5  pop rax
00007986e0dcefd6  add rsp, 0x08
00007986e0dcefda  jmp 0x00007986E0DCECAE
00007986e0dcefdf  call 0x00007986E0CC34C0
00007986e0dcefe4  jmp 0x00007986E0DCECC4
00007986e0dcefe9  int3
00007986e0dcefea  nop [rax+rax*1], ax
00007986e0dceff0  mov rax, [r15+0xF8]
00007986e0dceff7  lea r14, [rax-0x150]
00007986e0dceffe  mov [r15+0xF8], r14
00007986e0dcf005  mov rax, [r15+0x50]
00007986e0dcf009  lea r12, [rax+0x80]
00007986e0dcf010  movups xmm1, [r13+r12*1]
00007986e0dcf016  lea r12, [rax+0x90]
00007986e0dcf01d  movups xmm15, [r13+r12*1]
00007986e0dcf023  mov qword ptr [r15+0x48], 0x00
00007986e0dcf02b  lea r12, [rax+0x40]
00007986e0dcf02f  movups xmm14, [r13+r12*1]
00007986e0dcf035  lea r12, [rax+0x50]
00007986e0dcf039  movups xmm13, [r13+r12*1]
00007986e0dcf03f  lea r12, [r14+0x120]
00007986e0dcf046  movq xmm12, qword ptr [r15+0x1C0]
00007986e0dcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007986e0dcf058  movq r11, xmm12
00007986e0dcf05d  movq r10, xmm11
00007986e0dcf062  mov [r13+r12*1], r11
00007986e0dcf067  lea r12, [r14+0x128]
00007986e0dcf06e  mov [r13+r12*1], r10
00007986e0dcf073  vxorps xmm12, xmm12, xmm12
00007986e0dcf078  vpbroadcastq xmm12, xmm12
00007986e0dcf07d  lea r12, [r14+0x100]
00007986e0dcf084  movq xmm11, qword ptr [r15+0x200]
00007986e0dcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007986e0dcf096  movq r11, xmm11
00007986e0dcf09b  movq r10, xmm10
00007986e0dcf0a0  mov [r13+r12*1], r11
00007986e0dcf0a5  lea r12, [r14+0x108]
00007986e0dcf0ac  mov [r13+r12*1], r10
00007986e0dcf0b1  lea r12, [r14+0xE0]
00007986e0dcf0b8  movups [r13+r12*1], xmm15
00007986e0dcf0be  lea r12, [r14+0xF0]
00007986e0dcf0c5  movups [r13+r12*1], xmm1
00007986e0dcf0cb  lea r12, [rax+0xC0]
00007986e0dcf0d2  movups xmm1, [r13+r12*1]
00007986e0dcf0d8  lea r12, [rax+0xD0]
00007986e0dcf0df  movups xmm15, [r13+r12*1]
00007986e0dcf0e5  lea r12, [r14+0x110]
00007986e0dcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007986e0dcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007986e0dcf0fe  movq r11, xmm11
00007986e0dcf103  movq r10, xmm10
00007986e0dcf108  mov [r13+r12*1], r11
00007986e0dcf10d  lea r12, [r14+0x118]
00007986e0dcf114  mov [r13+r12*1], r10
00007986e0dcf119  movups xmm11, [r13+rax*1]
00007986e0dcf11f  lea r12, [rax+0x10]
00007986e0dcf123  movups xmm10, [r13+r12*1]
00007986e0dcf129  lea r12, [r14+0x130]
00007986e0dcf130  movq xmm9, qword ptr [r15+0x1A0]
00007986e0dcf139  movq xmm8, qword ptr [r15+0x190]
00007986e0dcf142  movq r11, xmm9
00007986e0dcf147  movq r10, xmm8
00007986e0dcf14c  mov [r13+r12*1], r11
00007986e0dcf151  lea r12, [r14+0x138]
00007986e0dcf158  mov [r13+r12*1], r10
00007986e0dcf15d  lea r12, [rax+0x140]
00007986e0dcf164  movups xmm9, [r13+r12*1]
00007986e0dcf16a  lea r12, [rax+0x150]
00007986e0dcf171  movups xmm8, [r13+r12*1]
00007986e0dcf177  lea r12, [r14+0xC0]
00007986e0dcf17e  movups [r13+r12*1], xmm15
00007986e0dcf184  lea r12, [r14+0xD0]
00007986e0dcf18b  movups [r13+r12*1], xmm1
00007986e0dcf191  lea r12, [rax+0x100]
00007986e0dcf198  movups xmm1, [r13+r12*1]
00007986e0dcf19e  lea r12, [rax+0x110]
00007986e0dcf1a5  movups xmm15, [r13+r12*1]
00007986e0dcf1ab  lea r12, [r14+0x140]
00007986e0dcf1b2  mov r11, [r15+0xE8]
00007986e0dcf1b9  mov [r13+r12*1], r11
00007986e0dcf1be  lea r12, [rax+0x180]
00007986e0dcf1c5  movups xmm7, [r13+r12*1]
00007986e0dcf1cb  lea r12, [rax+0x190]
00007986e0dcf1d2  movups xmm6, [r13+r12*1]
00007986e0dcf1d8  lea r12, [rax+0x1C0]
00007986e0dcf1df  movups xmm5, [r13+r12*1]
00007986e0dcf1e5  lea r12, [rax+0x1D0]
00007986e0dcf1ec  movups xmm4, [r13+r12*1]
00007986e0dcf1f2  lea r12, [r14+0x20]
00007986e0dcf1f6  movups [r13+r12*1], xmm1
00007986e0dcf1fc  lea r12, [r14+0x30]
00007986e0dcf200  movups [r13+r12*1], xmm13
00007986e0dcf206  lea r12, [rax+0x60]
00007986e0dcf20a  movups xmm1, [r13+r12*1]
00007986e0dcf210  lea r12, [rax+0x70]
00007986e0dcf214  movups xmm13, [r13+r12*1]
00007986e0dcf21a  lea r12, [rax+0x20]
00007986e0dcf21e  movups xmm3, [r13+r12*1]
00007986e0dcf224  lea r12, [rax+0x30]
00007986e0dcf228  movups xmm2, [r13+r12*1]
00007986e0dcf22e  movaps [r15+0x1F0], xmm2
00007986e0dcf236  lea r12, [r14+0x60]
00007986e0dcf23a  movups [r13+r12*1], xmm11
00007986e0dcf240  lea r12, [r14+0x70]
00007986e0dcf244  movups [r13+r12*1], xmm5
00007986e0dcf24a  lea r12, [rax+0xE0]
00007986e0dcf251  movups xmm11, [r13+r12*1]
00007986e0dcf257  lea r12, [rax+0xF0]
00007986e0dcf25e  movups xmm5, [r13+r12*1]
00007986e0dcf264  lea r12, [r14+0xA0]
00007986e0dcf26b  movups [r13+r12*1], xmm13
00007986e0dcf271  lea r12, [r14+0xB0]
00007986e0dcf278  movups [r13+r12*1], xmm1
00007986e0dcf27e  lea r12, [rax+0xA0]
00007986e0dcf285  movups xmm1, [r13+r12*1]
00007986e0dcf28b  lea r12, [rax+0xB0]
00007986e0dcf292  movups xmm13, [r13+r12*1]
00007986e0dcf298  lea r12, [rax+0x120]
00007986e0dcf29f  vmovaps [rsp+0x10], xmm1
00007986e0dcf2a5  movups xmm1, [r13+r12*1]
00007986e0dcf2ab  lea r12, [rax+0x130]
00007986e0dcf2b2  vmovaps [rsp+0x20], xmm1
00007986e0dcf2b8  movups xmm1, [r13+r12*1]
00007986e0dcf2be  lea r12, [rax+0x160]
00007986e0dcf2c5  vmovaps [rsp+0x30], xmm1
00007986e0dcf2cb  movups xmm1, [r13+r12*1]
00007986e0dcf2d1  lea r12, [rax+0x170]
00007986e0dcf2d8  vmovaps [rsp+0x40], xmm1
00007986e0dcf2de  movups xmm1, [r13+r12*1]
00007986e0dcf2e4  movaps [r15+0x2B0], xmm1
00007986e0dcf2ec  lea r12, [r14+0x80]
00007986e0dcf2f3  movups [r13+r12*1], xmm13
00007986e0dcf2f9  lea r12, [r14+0x90]
00007986e0dcf300  vmovaps xmm13, [rsp+0x10]
00007986e0dcf306  movups [r13+r12*1], xmm13
00007986e0dcf30c  lea r12, [rax+0x1A0]
00007986e0dcf313  movups xmm13, [r13+r12*1]
00007986e0dcf319  lea r12, [rax+0x1B0]
00007986e0dcf320  vmovaps [rsp+0x10], xmm1
00007986e0dcf326  movups xmm1, [r13+r12*1]
00007986e0dcf32c  movaps [r15+0x290], xmm13
00007986e0dcf334  movaps [r15+0x1E0], xmm1
00007986e0dcf33c  lea r12, [rax+0x1E0]
00007986e0dcf343  vmovaps [rsp+0x50], xmm1
00007986e0dcf349  movups xmm1, [r13+r12*1]
00007986e0dcf34f  lea r12, [rax+0x1F0]
00007986e0dcf356  vmovaps [rsp+0x60], xmm1
00007986e0dcf35c  movups xmm1, [r13+r12*1]
00007986e0dcf362  mov qword ptr [r15+0x50], 0x430920
00007986e0dcf36a  lea rax, [r14+0x40]
00007986e0dcf36e  vmovaps [rsp+0x70], xmm1
00007986e0dcf374  vmovaps xmm1, [rsp+0x40]
00007986e0dcf37a  movups [r13+rax*1], xmm1
00007986e0dcf380  lea rax, [r14+0x50]
00007986e0dcf384  movups [r13+rax*1], xmm10
00007986e0dcf38a  vmovaps xmm1, [rsp+0x70]
00007986e0dcf390  movups [r13+r14*1], xmm1
00007986e0dcf396  lea rax, [r14+0x10]
00007986e0dcf39a  vmovaps xmm1, [rsp+0x60]
00007986e0dcf3a0  movups [r13+rax*1], xmm1
00007986e0dcf3a6  mov rax, [r15+0x40]
00007986e0dcf3aa  vmovaps [rsp+0x40], xmm3
00007986e0dcf3b0  vmovaps xmm1, [rsp+0x40]
00007986e0dcf3b6  por xmm3, xmm1
00007986e0dcf3ba  vmovaps [rsp+0x40], xmm6
00007986e0dcf3c0  vmovaps xmm10, [rsp+0x40]
00007986e0dcf3c6  por xmm6, xmm10
00007986e0dcf3cb  lea r12, [rax+0x30]
00007986e0dcf3cf  mov r11, [r13+r12*1]
00007986e0dcf3d4  lea r12, [rax+0x38]
00007986e0dcf3d8  mov r10, [r13+r12*1]
00007986e0dcf3dd  movq xmm10, r11
00007986e0dcf3e2  vmovaps [rsp+0x40], xmm1
00007986e0dcf3e8  movq xmm1, r10
00007986e0dcf3ed  movq xmm10, xmm10
00007986e0dcf3f2  vmovaps [rsp+0x60], xmm10
00007986e0dcf3f8  movq xmm10, xmm10
00007986e0dcf3fd  movaps [r15+0x130], xmm10
00007986e0dcf405  movq xmm1, xmm1
00007986e0dcf409  vmovaps [rsp+0x70], xmm1
00007986e0dcf40f  movq xmm1, xmm1
00007986e0dcf413  movaps [r15+0x280], xmm1
00007986e0dcf41b  vmovaps [rsp+0x80], xmm9
00007986e0dcf424  vmovaps xmm1, [rsp+0x80]
00007986e0dcf42d  por xmm9, xmm1
00007986e0dcf432  lea r12, [rax+0x20]
00007986e0dcf436  mov r11, [r13+r12*1]
00007986e0dcf43b  lea r12, [rax+0x28]
00007986e0dcf43f  mov r10, [r13+r12*1]
00007986e0dcf444  movq xmm1, r11
00007986e0dcf449  movq xmm10, r10
00007986e0dcf44e  movq xmm1, xmm1
00007986e0dcf452  vmovaps [rsp+0x80], xmm1
00007986e0dcf45b  movq xmm1, xmm1
00007986e0dcf45f  movaps [r15+0x150], xmm1
00007986e0dcf467  movq xmm10, xmm10
00007986e0dcf46c  vmovaps [rsp+0x90], xmm10
00007986e0dcf475  movq xmm10, xmm10
00007986e0dcf47a  movaps [r15+0x140], xmm10
00007986e0dcf482  lea r12, [rax+0x10]
00007986e0dcf486  mov r11, [r13+r12*1]
00007986e0dcf48b  lea r12, [rax+0x18]
00007986e0dcf48f  mov r10, [r13+r12*1]
00007986e0dcf494  movq xmm1, r11
00007986e0dcf499  movq xmm10, r10
00007986e0dcf49e  movq xmm1, xmm1
00007986e0dcf4a2  vmovaps [rsp+0xA0], xmm1
00007986e0dcf4ab  movq xmm1, xmm1
00007986e0dcf4af  movaps [r15+0x170], xmm1
00007986e0dcf4b7  movq xmm10, xmm10
00007986e0dcf4bc  vmovaps [rsp+0xB0], xmm10
00007986e0dcf4c5  movq xmm10, xmm10
00007986e0dcf4ca  movaps [r15+0x160], xmm10
00007986e0dcf4d2  mov r12, [r13+rax*1]
00007986e0dcf4d7  vmovq xmm1, r12
00007986e0dcf4dc  vpbroadcastq xmm1, xmm1
00007986e0dcf4e1  lea r12, [rax+0x08]
00007986e0dcf4e5  mov rax, [r13+r12*1]
00007986e0dcf4ea  movq xmm10, rax
00007986e0dcf4ef  movaps [r15+0x230], xmm10
00007986e0dcf4f7  lea rax, [r14+0x50]
00007986e0dcf4fb  movups xmm10, [r13+rax*1]
00007986e0dcf501  lea rax, [r14+0x60]
00007986e0dcf505  vmovaps [rsp+0xC0], xmm1
00007986e0dcf50e  movups xmm1, [r13+rax*1]
00007986e0dcf514  lea rax, [r14+0x30]
00007986e0dcf518  vmovaps [rsp+0xD0], xmm1
00007986e0dcf521  movups xmm1, [r13+rax*1]
00007986e0dcf527  mov qword ptr [r15+0x60], 0x430920
00007986e0dcf52f  mov qword ptr [r15+0x58], 0x40
00007986e0dcf537  vmovaps [rsp+0xE0], xmm1
00007986e0dcf540  vmovaps [rsp+0xF0], xmm15
00007986e0dcf549  vmovaps xmm15, [rsp+0xC0]
00007986e0dcf552  vmovaps [rsp+0xC0], xmm14
00007986e0dcf55b  vmovaps xmm14, [rsp+0x40]
00007986e0dcf561  vmovaps [rsp+0x40], xmm13
00007986e0dcf567  movaps xmm1, xmm15
00007986e0dcf56b  mulpd xmm1, xmm14
00007986e0dcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007986e0dcf575  ptest xmm13, xmm13
00007986e0dcf57b  jnz 0x00007986E0DD0682
00007986e0dcf581  movq xmm14, qword ptr [r15+0x230]
00007986e0dcf58a  vmovaps [rsp+0x100], xmm14
00007986e0dcf593  vpermilpd xmm14, xmm14, 0x00
00007986e0dcf599  vmovaps [rsp+0x110], xmm1
00007986e0dcf5a2  vmovaps xmm1, [rsp+0xE0]
00007986e0dcf5ab  vmovaps [rsp+0xE0], xmm15
00007986e0dcf5b4  movaps xmm13, xmm1
00007986e0dcf5b8  mulpd xmm13, xmm14
00007986e0dcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007986e0dcf5c3  ptest xmm15, xmm15
00007986e0dcf5c9  jnz 0x00007986E0DD07C4
00007986e0dcf5cf  vxorps xmm1, xmm1, xmm1
00007986e0dcf5d3  vpbroadcastq xmm1, xmm1
00007986e0dcf5d8  vmovaps xmm14, [rsp+0xE0]
00007986e0dcf5e1  vmovaps [rsp+0xE0], xmm1
00007986e0dcf5ea  vmovaps xmm1, [rsp+0xD0]
00007986e0dcf5f3  vmovaps [rsp+0xD0], xmm13
00007986e0dcf5fc  movaps xmm15, xmm14
00007986e0dcf600  mulpd xmm15, xmm1
00007986e0dcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007986e0dcf60b  ptest xmm13, xmm13
00007986e0dcf611  jnz 0x00007986E0DD0907
00007986e0dcf617  movaps xmm1, xmm14
00007986e0dcf61b  mulpd xmm1, xmm10
00007986e0dcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007986e0dcf625  ptest xmm13, xmm13
00007986e0dcf62b  jnz 0x00007986E0DD0A4A
00007986e0dcf631  movaps xmm13, xmm14
00007986e0dcf635  mulpd xmm13, xmm2
00007986e0dcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007986e0dcf640  ptest xmm10, xmm10
00007986e0dcf646  jnz 0x00007986E0DD0B8C
00007986e0dcf64c  vmovaps [rsp+0x120], xmm7
00007986e0dcf655  vmovaps xmm14, [rsp+0x120]
00007986e0dcf65e  por xmm7, xmm14
00007986e0dcf663  vmovaps xmm14, [rsp+0xC0]
00007986e0dcf66c  vmovaps xmm10, [rsp+0xC0]
00007986e0dcf675  por xmm14, xmm10
00007986e0dcf67a  vmovaps xmm2, [rsp+0x100]
00007986e0dcf683  vpermilpd xmm2, xmm2, 0x00
00007986e0dcf689  vmovaps [rsp+0xC0], xmm1
00007986e0dcf692  vmovaps [rsp+0x120], xmm15
00007986e0dcf69b  movaps xmm1, xmm10
00007986e0dcf69f  mulpd xmm1, xmm2
00007986e0dcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007986e0dcf6a8  ptest xmm15, xmm15
00007986e0dcf6ae  jnz 0x00007986E0DD0CCF
00007986e0dcf6b4  xor eax, eax
00007986e0dcf6b6  mov r12d, 0x40
00007986e0dcf6bc  mov r11d, 0x200
00007986e0dcf6c2  cmp r12, r11
00007986e0dcf6c5  cmc
00007986e0dcf6c6  lahf
00007986e0dcf6c7  seto al
00007986e0dcf6ca  mov [r15+0x108], eax
00007986e0dcf6d1  vmovaps xmm10, [rsp+0x110]
00007986e0dcf6da  vmovaps xmm2, [rsp+0xE0]
00007986e0dcf6e3  vmovaps [rsp+0xE0], xmm1
00007986e0dcf6ec  movaps xmm15, xmm10
00007986e0dcf6f0  addpd xmm15, xmm2
00007986e0dcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007986e0dcf6fb  ptest xmm1, xmm1
00007986e0dcf700  jnz 0x00007986E0DD0E10
00007986e0dcf706  vmovaps xmm10, [rsp+0x120]
00007986e0dcf70f  vmovaps [rsp+0x110], xmm15
00007986e0dcf718  movaps xmm1, xmm10
00007986e0dcf71c  addpd xmm1, xmm12
00007986e0dcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007986e0dcf726  ptest xmm15, xmm15
00007986e0dcf72c  jnz 0x00007986E0DD0F53
00007986e0dcf732  vmovaps xmm10, [rsp+0xC0]
00007986e0dcf73b  vmovaps [rsp+0xC0], xmm1
00007986e0dcf744  movaps xmm15, xmm10
00007986e0dcf748  addpd xmm15, xmm12
00007986e0dcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007986e0dcf753  ptest xmm1, xmm1
00007986e0dcf758  jnz 0x00007986E0DD1095
00007986e0dcf75e  vmovaps xmm1, [rsp+0x30]
00007986e0dcf764  vmovaps xmm12, [rsp+0x30]
00007986e0dcf76a  por xmm1, xmm12
00007986e0dcf76f  vmovaps xmm12, [rsp+0x20]
00007986e0dcf775  vmovaps xmm10, [rsp+0x20]
00007986e0dcf77b  por xmm12, xmm10
00007986e0dcf780  vmovaps [rsp+0x20], xmm5
00007986e0dcf786  vmovaps xmm10, [rsp+0x20]
00007986e0dcf78c  por xmm5, xmm10
00007986e0dcf791  vmovaps [rsp+0x20], xmm11
00007986e0dcf797  vmovaps xmm10, [rsp+0x20]
00007986e0dcf79d  por xmm11, xmm10
00007986e0dcf7a2  vmovaps [rsp+0x20], xmm4
00007986e0dcf7a8  vmovaps xmm10, [rsp+0x20]
00007986e0dcf7ae  por xmm4, xmm10
00007986e0dcf7b3  vmovaps [rsp+0x20], xmm8
00007986e0dcf7b9  vmovaps xmm10, [rsp+0x20]
00007986e0dcf7bf  por xmm8, xmm10
00007986e0dcf7c4  vmovaps xmm10, [rsp+0xF0]
00007986e0dcf7cd  vmovaps [rsp+0x20], xmm1
00007986e0dcf7d3  vmovaps xmm1, [rsp+0xF0]
00007986e0dcf7dc  por xmm10, xmm1
00007986e0dcf7e1  lea rax, [r14+0xA0]
00007986e0dcf7e8  movups xmm1, [r13+rax*1]
00007986e0dcf7ee  lea rax, [r14+0xB0]
00007986e0dcf7f5  vmovaps [rsp+0x30], xmm1
00007986e0dcf7fb  movups xmm1, [r13+rax*1]
00007986e0dcf801  vmovaps [rsp+0xF0], xmm1
00007986e0dcf80a  vmovaps [rsp+0x120], xmm15
00007986e0dcf813  movaps xmm1, xmm13
00007986e0dcf817  addpd xmm1, xmm2
00007986e0dcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007986e0dcf820  ptest xmm15, xmm15
00007986e0dcf826  jnz 0x00007986E0DD11ED
00007986e0dcf82c  lea rax, [r14+0xF0]
00007986e0dcf833  movups xmm15, [r13+rax*1]
00007986e0dcf839  vmovaps xmm2, [rsp+0xC0]
00007986e0dcf842  vmovaps [rsp+0xC0], xmm1
00007986e0dcf84b  vmovaps xmm1, [rsp+0xE0]
00007986e0dcf854  vmovaps [rsp+0xE0], xmm15
00007986e0dcf85d  movaps xmm13, xmm2
00007986e0dcf861  addpd xmm13, xmm1
00007986e0dcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007986e0dcf86c  ptest xmm15, xmm15
00007986e0dcf872  jnz 0x00007986E0DD1338
00007986e0dcf878  vmovaps xmm15, [rsp+0x120]
00007986e0dcf881  vmovaps xmm2, [rsp+0xD0]
00007986e0dcf88a  vmovaps [rsp+0xD0], xmm14
00007986e0dcf893  movaps xmm1, xmm15
00007986e0dcf897  addpd xmm1, xmm2
00007986e0dcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007986e0dcf8a0  ptest xmm14, xmm14
00007986e0dcf8a6  jnz 0x00007986E0DD147A
00007986e0dcf8ac  vmovaps xmm15, [rsp+0x100]
00007986e0dcf8b5  vpermilpd xmm15, xmm15, 0x00
00007986e0dcf8bb  vmovaps xmm2, [rsp+0xF0]
00007986e0dcf8c4  vmovaps [rsp+0xF0], xmm1
00007986e0dcf8cd  movaps xmm14, xmm2
00007986e0dcf8d1  mulpd xmm14, xmm15
00007986e0dcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007986e0dcf8dc  ptest xmm1, xmm1
00007986e0dcf8e1  jnz 0x00007986E0DD15BB
00007986e0dcf8e7  vmovaps xmm1, [rsp+0xA0]
00007986e0dcf8f0  vpermilpd xmm1, xmm1, 0x00
00007986e0dcf8f6  vmovaps xmm2, [rsp+0xE0]
00007986e0dcf8ff  vmovaps [rsp+0xE0], xmm14
00007986e0dcf908  movaps xmm15, xmm2
00007986e0dcf90c  mulpd xmm15, xmm1
00007986e0dcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007986e0dcf917  ptest xmm14, xmm14
00007986e0dcf91d  jnz 0x00007986E0DD16FE
00007986e0dcf923  lea rax, [r14+0xE0]
00007986e0dcf92a  movups xmm1, [r13+rax*1]
00007986e0dcf930  vmovaps xmm14, [rsp+0x100]
00007986e0dcf939  vpermilpd xmm14, xmm14, 0x00
00007986e0dcf93f  vmovaps [rsp+0x100], xmm1
00007986e0dcf948  vmovaps xmm1, [rsp+0x30]
00007986e0dcf94e  vmovaps [rsp+0x30], xmm15
00007986e0dcf954  movaps xmm2, xmm1
00007986e0dcf957  mulpd xmm2, xmm14
00007986e0dcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007986e0dcf961  ptest xmm15, xmm15
00007986e0dcf967  jnz 0x00007986E0DD184A
00007986e0dcf96d  vmovaps [rsp+0x120], xmm10
00007986e0dcf976  vmovaps xmm1, [rsp+0x120]
00007986e0dcf97f  por xmm10, xmm1
00007986e0dcf984  movaps [r15+0x300], xmm10
00007986e0dcf98c  vmovaps [rsp+0x120], xmm8
00007986e0dcf995  vmovaps xmm1, [rsp+0x120]
00007986e0dcf99e  por xmm8, xmm1
00007986e0dcf9a3  movaps [r15+0x190], xmm8
00007986e0dcf9ab  vmovaps xmm1, [rsp+0xA0]
00007986e0dcf9b4  vpermilpd xmm1, xmm1, 0x00
00007986e0dcf9ba  vmovaps xmm14, [rsp+0x100]
00007986e0dcf9c3  vmovaps [rsp+0x100], xmm13
00007986e0dcf9cc  movaps xmm15, xmm14
00007986e0dcf9d0  mulpd xmm15, xmm1
00007986e0dcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007986e0dcf9db  ptest xmm13, xmm13
00007986e0dcf9e1  jnz 0x00007986E0DD198B
00007986e0dcf9e7  lea rax, [r14+0x90]
00007986e0dcf9ee  movups xmm1, [r13+rax*1]
00007986e0dcf9f4  vmovaps [rsp+0x120], xmm4
00007986e0dcf9fd  vmovaps xmm14, [rsp+0x120]
00007986e0dcfa06  por xmm4, xmm14
00007986e0dcfa0b  movaps [r15+0x1C0], xmm4
00007986e0dcfa13  vmovaps [rsp+0x120], xmm11
00007986e0dcfa1c  vmovaps xmm14, [rsp+0x120]
00007986e0dcfa25  por xmm11, xmm14
00007986e0dcfa2a  movaps [r15+0x200], xmm11
00007986e0dcfa32  vmovaps [rsp+0x120], xmm5
00007986e0dcfa3b  vmovaps xmm14, [rsp+0x120]
00007986e0dcfa44  por xmm5, xmm14
00007986e0dcfa49  movaps [r15+0x2D0], xmm5
00007986e0dcfa51  vmovaps [rsp+0x120], xmm12
00007986e0dcfa5a  vmovaps xmm14, [rsp+0x120]
00007986e0dcfa63  por xmm12, xmm14
00007986e0dcfa68  movaps [r15+0x2E0], xmm12
00007986e0dcfa70  vmovaps xmm13, [rsp+0x110]
00007986e0dcfa79  vmovaps [rsp+0x110], xmm1
00007986e0dcfa82  vmovaps xmm1, [rsp+0xE0]
00007986e0dcfa8b  vmovaps [rsp+0xE0], xmm15
00007986e0dcfa94  movaps xmm14, xmm13
00007986e0dcfa98  addpd xmm14, xmm1
00007986e0dcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007986e0dcfaa3  ptest xmm15, xmm15
00007986e0dcfaa9  jnz 0x00007986E0DD1AD8
00007986e0dcfaaf  vmovaps xmm1, [rsp+0xA0]
00007986e0dcfab8  vpermilpd xmm1, xmm1, 0x00
00007986e0dcfabe  vmovaps xmm13, [rsp+0x110]
00007986e0dcfac7  vmovaps [rsp+0x110], xmm14
00007986e0dcfad0  movaps xmm15, xmm13
00007986e0dcfad4  mulpd xmm15, xmm1
00007986e0dcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007986e0dcfadf  ptest xmm14, xmm14
00007986e0dcfae5  jnz 0x00007986E0DD1C1B
00007986e0dcfaeb  lea rax, [r14+0x80]
00007986e0dcfaf2  movups xmm1, [r13+rax*1]
00007986e0dcfaf8  vmovaps xmm13, [rsp+0xC0]
00007986e0dcfb01  vmovaps [rsp+0xC0], xmm1
00007986e0dcfb0a  movaps xmm14, xmm13
00007986e0dcfb0e  addpd xmm14, xmm2
00007986e0dcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007986e0dcfb19  ptest xmm1, xmm1
00007986e0dcfb1e  jnz 0x00007986E0DD1D68
00007986e0dcfb24  vmovaps xmm13, [rsp+0x100]
00007986e0dcfb2d  vmovaps xmm2, [rsp+0x30]
00007986e0dcfb33  vmovaps [rsp+0x30], xmm15
00007986e0dcfb39  movaps xmm1, xmm13
00007986e0dcfb3d  addpd xmm1, xmm2
00007986e0dcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007986e0dcfb46  ptest xmm15, xmm15
00007986e0dcfb4c  jnz 0x00007986E0DD1EAB
00007986e0dcfb52  vmovaps xmm15, [rsp+0x20]
00007986e0dcfb58  vmovaps xmm13, [rsp+0x20]
00007986e0dcfb5e  por xmm15, xmm13
00007986e0dcfb63  movaps [r15+0x2F0], xmm15
00007986e0dcfb6b  vmovaps xmm13, [rsp+0xA0]
00007986e0dcfb74  vpermilpd xmm13, xmm13, 0x00
00007986e0dcfb7a  vmovaps [rsp+0x20], xmm1
00007986e0dcfb80  vmovaps xmm1, [rsp+0xC0]
00007986e0dcfb89  vmovaps [rsp+0xA0], xmm15
00007986e0dcfb92  movaps xmm2, xmm1
00007986e0dcfb95  mulpd xmm2, xmm13
00007986e0dcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007986e0dcfb9f  ptest xmm15, xmm15
00007986e0dcfba5  jnz 0x00007986E0DD1FEC
00007986e0dcfbab  lea rax, [r14+0xD0]
00007986e0dcfbb2  movups xmm1, [r13+rax*1]
00007986e0dcfbb8  vmovaps xmm13, [rsp+0xF0]
00007986e0dcfbc1  vmovaps [rsp+0xC0], xmm1
00007986e0dcfbca  vmovaps xmm1, [rsp+0xE0]
00007986e0dcfbd3  vmovaps [rsp+0xE0], xmm14
00007986e0dcfbdc  movaps xmm15, xmm13
00007986e0dcfbe0  addpd xmm15, xmm1
00007986e0dcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007986e0dcfbeb  ptest xmm14, xmm14
00007986e0dcfbf1  jnz 0x00007986E0DD2137
00007986e0dcfbf7  vmovaps xmm1, [rsp+0xB0]
00007986e0dcfc00  vpermilpd xmm1, xmm1, 0x00
00007986e0dcfc06  movaps xmm14, xmm11
00007986e0dcfc0a  mulpd xmm14, xmm1
00007986e0dcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007986e0dcfc15  ptest xmm13, xmm13
00007986e0dcfc1b  jnz 0x00007986E0DD227A
00007986e0dcfc21  movaps [r15+0x260], xmm14
00007986e0dcfc29  vxorps xmm1, xmm1, xmm1
00007986e0dcfc2d  vpbroadcastq xmm1, xmm1
00007986e0dcfc32  movaps [r15+0x1B0], xmm1
00007986e0dcfc3a  vmovaps xmm1, [rsp+0xB0]
00007986e0dcfc43  vpermilpd xmm1, xmm1, 0x00
00007986e0dcfc49  vmovaps xmm11, [rsp+0xC0]
00007986e0dcfc52  vmovaps [rsp+0xC0], xmm15
00007986e0dcfc5b  movaps xmm13, xmm11
00007986e0dcfc5f  mulpd xmm13, xmm1
00007986e0dcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007986e0dcfc6a  ptest xmm15, xmm15
00007986e0dcfc70  jnz 0x00007986E0DD23BD
00007986e0dcfc76  lea rax, [r14+0xC0]
00007986e0dcfc7d  movups xmm1, [r13+rax*1]
00007986e0dcfc83  vmovaps xmm11, [rsp+0x110]
00007986e0dcfc8c  vmovaps [rsp+0xF0], xmm1
00007986e0dcfc95  vmovaps xmm1, [rsp+0x30]
00007986e0dcfc9b  vmovaps [rsp+0x30], xmm14
00007986e0dcfca1  movaps xmm15, xmm11
00007986e0dcfca5  addpd xmm15, xmm1
00007986e0dcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007986e0dcfcb0  ptest xmm14, xmm14
00007986e0dcfcb6  jnz 0x00007986E0DD250A
00007986e0dcfcbc  vmovaps [rsp+0x100], xmm9
00007986e0dcfcc5  vmovaps xmm1, [rsp+0x100]
00007986e0dcfcce  por xmm9, xmm1
00007986e0dcfcd3  movaps [r15+0x270], xmm9
00007986e0dcfcdb  vmovaps [rsp+0x100], xmm6
00007986e0dcfce4  vmovaps xmm1, [rsp+0x100]
00007986e0dcfced  por xmm6, xmm1
00007986e0dcfcf1  movaps [r15+0x1A0], xmm6
00007986e0dcfcf9  vmovaps xmm14, [rsp+0xB0]
00007986e0dcfd02  vpermilpd xmm14, xmm14, 0x00
00007986e0dcfd08  vmovaps xmm6, [rsp+0xF0]
00007986e0dcfd11  vmovaps [rsp+0xF0], xmm1
00007986e0dcfd1a  movaps xmm11, xmm6
00007986e0dcfd1e  mulpd xmm11, xmm14
00007986e0dcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007986e0dcfd29  ptest xmm1, xmm1
00007986e0dcfd2e  jnz 0x00007986E0DD264D
00007986e0dcfd34  lea rax, [r14+0x20]
00007986e0dcfd38  movups xmm1, [r13+rax*1]
00007986e0dcfd3e  movaps [r15+0x110], xmm1
00007986e0dcfd46  vmovaps xmm6, [rsp+0xE0]
00007986e0dcfd4f  vmovaps [rsp+0xE0], xmm1
00007986e0dcfd58  movaps xmm14, xmm6
00007986e0dcfd5c  addpd xmm14, xmm2
00007986e0dcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007986e0dcfd67  ptest xmm1, xmm1
00007986e0dcfd6c  jnz 0x00007986E0DD279A
00007986e0dcfd72  vmovaps xmm1, [rsp+0xB0]
00007986e0dcfd7b  vpermilpd xmm1, xmm1, 0x00
00007986e0dcfd81  movaps xmm6, xmm5
00007986e0dcfd84  mulpd xmm6, xmm1
00007986e0dcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007986e0dcfd8d  ptest xmm2, xmm2
00007986e0dcfd92  jnz 0x00007986E0DD28DC
00007986e0dcfd98  vmovaps xmm5, [rsp+0x20]
00007986e0dcfd9e  movaps xmm1, xmm5
00007986e0dcfda1  addpd xmm1, xmm13
00007986e0dcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007986e0dcfdab  ptest xmm2, xmm2
00007986e0dcfdb0  jnz 0x00007986E0DD2A1C
00007986e0dcfdb6  vmovaps xmm13, [rsp+0x80]
00007986e0dcfdbf  vpermilpd xmm13, xmm13, 0x00
00007986e0dcfdc5  vmovaps xmm2, [rsp+0xE0]
00007986e0dcfdce  vmovaps [rsp+0x20], xmm1
00007986e0dcfdd4  movaps xmm5, xmm2
00007986e0dcfdd7  mulpd xmm5, xmm13
00007986e0dcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007986e0dcfde1  ptest xmm1, xmm1
00007986e0dcfde6  jnz 0x00007986E0DD2B5D
00007986e0dcfdec  vmovaps xmm1, [rsp+0x80]
00007986e0dcfdf5  vpermilpd xmm1, xmm1, 0x00
00007986e0dcfdfb  movaps xmm13, xmm10
00007986e0dcfdff  mulpd xmm13, xmm1
00007986e0dcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007986e0dcfe0a  ptest xmm2, xmm2
00007986e0dcfe0f  jnz 0x00007986E0DD2C9E
00007986e0dcfe15  vmovaps xmm10, [rsp+0x30]
00007986e0dcfe1b  movaps xmm1, xmm15
00007986e0dcfe1f  addpd xmm1, xmm10
00007986e0dcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007986e0dcfe29  ptest xmm2, xmm2
00007986e0dcfe2e  jnz 0x00007986E0DD2DE1
00007986e0dcfe34  vmovaps xmm10, [rsp+0xC0]
00007986e0dcfe3d  movaps xmm15, xmm10
00007986e0dcfe41  addpd xmm15, xmm11
00007986e0dcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007986e0dcfe4c  ptest xmm2, xmm2
00007986e0dcfe51  jnz 0x00007986E0DD2F23
00007986e0dcfe57  vmovaps xmm11, [rsp+0x80]
00007986e0dcfe60  vpermilpd xmm11, xmm11, 0x00
00007986e0dcfe66  movaps xmm10, xmm12
00007986e0dcfe6a  mulpd xmm10, xmm11
00007986e0dcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007986e0dcfe75  ptest xmm2, xmm2
00007986e0dcfe7a  jnz 0x00007986E0DD3067
00007986e0dcfe80  vmovaps xmm12, [rsp+0x80]
00007986e0dcfe89  vpermilpd xmm12, xmm12, 0x00
00007986e0dcfe8f  vmovaps xmm2, [rsp+0xA0]
00007986e0dcfe98  vmovaps [rsp+0x30], xmm1
00007986e0dcfe9e  movaps xmm11, xmm2
00007986e0dcfea2  mulpd xmm11, xmm12
00007986e0dcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007986e0dcfead  ptest xmm1, xmm1
00007986e0dcfeb2  jnz 0x00007986E0DD31AB
00007986e0dcfeb8  movaps xmm1, xmm14
00007986e0dcfebc  addpd xmm1, xmm6
00007986e0dcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007986e0dcfec5  ptest xmm12, xmm12
00007986e0dcfecb  jnz 0x00007986E0DD32EE
00007986e0dcfed1  vmovaps xmm12, [rsp+0x20]
00007986e0dcfed7  movaps xmm14, xmm12
00007986e0dcfedb  addpd xmm14, xmm5
00007986e0dcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007986e0dcfee6  ptest xmm6, xmm6
00007986e0dcfeeb  jnz 0x00007986E0DD342F
00007986e0dcfef1  vmovaps xmm12, [rsp+0x90]
00007986e0dcfefa  vpermilpd xmm12, xmm12, 0x00
00007986e0dcff00  movaps xmm6, xmm9
00007986e0dcff04  mulpd xmm6, xmm12
00007986e0dcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007986e0dcff0e  ptest xmm5, xmm5
00007986e0dcff13  jnz 0x00007986E0DD3572
00007986e0dcff19  movaps xmm12, xmm15
00007986e0dcff1d  addpd xmm12, xmm13
00007986e0dcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007986e0dcff28  ptest xmm9, xmm9
00007986e0dcff2e  jnz 0x00007986E0DD36B4
00007986e0dcff34  vmovaps xmm13, [rsp+0x30]
00007986e0dcff3a  movaps xmm15, xmm13
00007986e0dcff3e  addpd xmm15, xmm10
00007986e0dcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007986e0dcff49  ptest xmm9, xmm9
00007986e0dcff4f  jnz 0x00007986E0DD37F8
00007986e0dcff55  vmovaps xmm13, [rsp+0xD0]
00007986e0dcff5e  vmovaps xmm10, [rsp+0xD0]
00007986e0dcff67  por xmm13, xmm10
00007986e0dcff6c  movaps [r15+0x250], xmm13
00007986e0dcff74  vmovaps [rsp+0x20], xmm7
00007986e0dcff7a  vmovaps xmm13, [rsp+0x20]
00007986e0dcff80  por xmm7, xmm13
00007986e0dcff85  movaps [r15+0x2A0], xmm7
00007986e0dcff8d  vmovaps [rsp+0x20], xmm3
00007986e0dcff93  vmovaps xmm13, [rsp+0x20]
00007986e0dcff99  por xmm3, xmm13
00007986e0dcff9e  movaps [r15+0x1D0], xmm3
00007986e0dcffa6  lea rax, [r14+0x40]
00007986e0dcffaa  movups xmm13, [r13+rax*1]
00007986e0dcffb0  movaps [r15+0x2C0], xmm13
00007986e0dcffb8  vmovaps xmm10, [rsp+0x90]
00007986e0dcffc1  vpermilpd xmm10, xmm10, 0x00
00007986e0dcffc7  movaps xmm9, xmm8
00007986e0dcffcb  mulpd xmm9, xmm10
00007986e0dcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007986e0dcffd6  ptest xmm5, xmm5
00007986e0dcffdb  jnz 0x00007986E0DD3946
00007986e0dcffe1  movaps xmm10, xmm1
00007986e0dcffe5  addpd xmm10, xmm11
00007986e0dcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007986e0dcfff0  ptest xmm8, xmm8
00007986e0dcfff6  jnz 0x00007986E0DD3A8A
00007986e0dcfffc  movaps xmm1, xmm14
00007986e0dd0000  addpd xmm1, xmm6
00007986e0dd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007986e0dd0009  ptest xmm11, xmm11
00007986e0dd000f  jnz 0x00007986E0DD3BCD
00007986e0dd0015  vmovaps xmm14, [rsp+0x90]
00007986e0dd001e  vpermilpd xmm14, xmm14, 0x00
00007986e0dd0024  movaps xmm11, xmm13
00007986e0dd0028  mulpd xmm11, xmm14
00007986e0dd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007986e0dd0033  ptest xmm8, xmm8
00007986e0dd0039  jnz 0x00007986E0DD3D0E
00007986e0dd003f  vmovaps xmm14, [rsp+0x90]
00007986e0dd0048  vpermilpd xmm14, xmm14, 0x00
00007986e0dd004e  vmovaps xmm8, [rsp+0x10]
00007986e0dd0054  movaps xmm13, xmm8
00007986e0dd0058  mulpd xmm13, xmm14
00007986e0dd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007986e0dd0063  ptest xmm6, xmm6
00007986e0dd0068  jnz 0x00007986E0DD3E52
00007986e0dd006e  vmovaps xmm14, [rsp+0x60]
00007986e0dd0074  vpermilpd xmm14, xmm14, 0x00
00007986e0dd007a  movaps xmm8, xmm7
00007986e0dd007e  mulpd xmm8, xmm14
00007986e0dd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007986e0dd0089  ptest xmm6, xmm6
00007986e0dd008e  jnz 0x00007986E0DD3F96
00007986e0dd0094  movaps xmm14, xmm12
00007986e0dd0098  addpd xmm14, xmm9
00007986e0dd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007986e0dd00a3  ptest xmm7, xmm7
00007986e0dd00a8  jnz 0x00007986E0DD40D9
00007986e0dd00ae  vmovaps xmm12, [rsp+0x60]
00007986e0dd00b4  vpermilpd xmm12, xmm12, 0x00
00007986e0dd00ba  vmovaps xmm7, [rsp+0xF0]
00007986e0dd00c3  movaps xmm9, xmm7
00007986e0dd00c7  mulpd xmm9, xmm12
00007986e0dd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007986e0dd00d2  ptest xmm6, xmm6
00007986e0dd00d7  jnz 0x00007986E0DD421D
00007986e0dd00dd  movaps xmm12, xmm15
00007986e0dd00e1  addpd xmm12, xmm11
00007986e0dd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007986e0dd00ec  ptest xmm7, xmm7
00007986e0dd00f1  jnz 0x00007986E0DD4360
00007986e0dd00f7  vmovaps xmm15, [rsp+0x60]
00007986e0dd00fd  vpermilpd xmm15, xmm15, 0x00
00007986e0dd0103  vmovaps xmm7, [rsp+0x40]
00007986e0dd0109  movaps xmm11, xmm7
00007986e0dd010d  mulpd xmm11, xmm15
00007986e0dd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007986e0dd0118  ptest xmm6, xmm6
00007986e0dd011d  jnz 0x00007986E0DD44A4
00007986e0dd0123  movaps xmm15, xmm10
00007986e0dd0127  addpd xmm15, xmm13
00007986e0dd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007986e0dd0132  ptest xmm7, xmm7
00007986e0dd0137  jnz 0x00007986E0DD45E7
00007986e0dd013d  vmovaps xmm13, [rsp+0x60]
00007986e0dd0143  vpermilpd xmm13, xmm13, 0x00
00007986e0dd0149  vmovaps xmm7, [rsp+0x50]
00007986e0dd014f  movaps xmm10, xmm7
00007986e0dd0153  mulpd xmm10, xmm13
00007986e0dd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007986e0dd015e  ptest xmm6, xmm6
00007986e0dd0163  jnz 0x00007986E0DD472B
00007986e0dd0169  movaps xmm13, xmm1
00007986e0dd016d  addpd xmm13, xmm8
00007986e0dd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007986e0dd0178  ptest xmm7, xmm7
00007986e0dd017d  jnz 0x00007986E0DD486E
00007986e0dd0183  lea rax, [r14+0x70]
00007986e0dd0187  movups xmm1, [r13+rax*1]
00007986e0dd018d  movaps [r15+0x240], xmm1
00007986e0dd0195  movaps xmm8, xmm14
00007986e0dd0199  addpd xmm8, xmm9
00007986e0dd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007986e0dd01a4  ptest xmm7, xmm7
00007986e0dd01a9  jnz 0x00007986E0DD49BB
00007986e0dd01af  movaps [r15+0x170], xmm8
00007986e0dd01b7  vmovaps xmm14, [rsp+0x70]
00007986e0dd01bd  vpermilpd xmm14, xmm14, 0x00
00007986e0dd01c3  movaps xmm9, xmm1
00007986e0dd01c7  mulpd xmm9, xmm14
00007986e0dd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007986e0dd01d2  ptest xmm7, xmm7
00007986e0dd01d7  jnz 0x00007986E0DD4AFF
00007986e0dd01dd  vmovaps xmm1, [rsp+0x70]
00007986e0dd01e3  vpermilpd xmm1, xmm1, 0x00
00007986e0dd01e9  movaps xmm14, xmm4
00007986e0dd01ed  mulpd xmm14, xmm1
00007986e0dd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007986e0dd01f8  ptest xmm7, xmm7
00007986e0dd01fd  jnz 0x00007986E0DD4C42
00007986e0dd0203  movaps [r15+0x180], xmm14
00007986e0dd020b  movaps xmm1, xmm12
00007986e0dd020f  addpd xmm1, xmm11
00007986e0dd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007986e0dd0219  ptest xmm7, xmm7
00007986e0dd021e  jnz 0x00007986E0DD4D84
00007986e0dd0224  movaps [r15+0x210], xmm1
00007986e0dd022c  movups xmm12, [r13+r14*1]
00007986e0dd0232  lea rax, [r14+0x10]
00007986e0dd0236  movups xmm11, [r13+rax*1]
00007986e0dd023c  movaps [r15+0x230], xmm11
00007986e0dd0244  movaps xmm7, xmm15
00007986e0dd0248  addpd xmm7, xmm10
00007986e0dd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007986e0dd0252  ptest xmm6, xmm6
00007986e0dd0257  jnz 0x00007986E0DD4EDA
00007986e0dd025d  movaps [r15+0x130], xmm7
00007986e0dd0265  vmovaps xmm15, [rsp+0x70]
00007986e0dd026b  vpermilpd xmm15, xmm15, 0x00
00007986e0dd0271  movaps xmm10, xmm11
00007986e0dd0275  mulpd xmm10, xmm15
00007986e0dd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007986e0dd0280  ptest xmm6, xmm6
00007986e0dd0285  jnz 0x00007986E0DD501C
00007986e0dd028b  movaps [r15+0x220], xmm10
00007986e0dd0293  vmovaps xmm15, [rsp+0x70]
00007986e0dd0299  vpermilpd xmm15, xmm15, 0x00
00007986e0dd029f  movaps xmm11, xmm12
00007986e0dd02a3  mulpd xmm11, xmm15
00007986e0dd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007986e0dd02ae  ptest xmm6, xmm6
00007986e0dd02b3  jnz 0x00007986E0DD5160
00007986e0dd02b9  movaps xmm15, xmm13
00007986e0dd02bd  addpd xmm15, xmm9
00007986e0dd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007986e0dd02c8  ptest xmm12, xmm12
00007986e0dd02ce  jnz 0x00007986E0DD52A4
00007986e0dd02d4  movaps [r15+0x140], xmm15
00007986e0dd02dc  movaps xmm13, xmm8
00007986e0dd02e0  addpd xmm13, xmm14
00007986e0dd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007986e0dd02eb  ptest xmm12, xmm12
00007986e0dd02f1  jnz 0x00007986E0DD53E8
00007986e0dd02f7  movaps [r15+0x150], xmm13
00007986e0dd02ff  movaps xmm14, xmm1
00007986e0dd0303  addpd xmm14, xmm10
00007986e0dd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007986e0dd030e  ptest xmm12, xmm12
00007986e0dd0314  jnz 0x00007986E0DD552C
00007986e0dd031a  movaps [r15+0x160], xmm14
00007986e0dd0322  movaps xmm1, xmm7
00007986e0dd0325  addpd xmm1, xmm11
00007986e0dd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007986e0dd032f  ptest xmm12, xmm12
00007986e0dd0335  jnz 0x00007986E0DD566F
00007986e0dd033b  movaps [r15+0x120], xmm1
00007986e0dd0343  mov eax, 0x430920
00007986e0dd0348  movups [r13+rax*1], xmm15
00007986e0dd034e  mov eax, 0x430930
00007986e0dd0353  movups [r13+rax*1], xmm13
00007986e0dd0359  mov eax, 0x430940
00007986e0dd035e  movups [r13+rax*1], xmm14
00007986e0dd0364  mov eax, 0x430950
00007986e0dd0369  movups [r13+rax*1], xmm1
00007986e0dd036f  mov eax, [r15+0x108]
00007986e0dd0376  sahf
00007986e0dd0377  jnz 0x00007986E0DD03A9
00007986e0dd0379  cmp dword ptr [r15+0x318], 0x00
00007986e0dd0381  jz 0x00007986E0DDB900
00007986e0dd0387  nop [rax+rax*1], ax
00007986e0dd0390  nop [rax+rax*1], eax
00007986e0dd0398  mov eax, 0x410444
00007986e0dd039d  mov [r15+0x100], rax
00007986e0dd03a4  jmp 0x00007986E0BFE110
00007986e0dd03a9  cmp dword ptr [r15+0x318], 0x00
00007986e0dd03b1  jz 0x00007986E0DD57E0
00007986e0dd03b7  nop [rax+rax*1], ax
00007986e0dd03c0  nop [rax+rax*1], eax
00007986e0dd03c8  mov eax, 0x410278
00007986e0dd03cd  mov [r15+0x100], rax
00007986e0dd03d4  jmp 0x00007986E0BFE110
00007986e0dd03d9  int3
00007986e0dd03da  call 0x00007986E0CB52F0
00007986e0dd03df  jmp 0x00007986E0DCF016
00007986e0dd03e4  call 0x00007986E0CC4620
00007986e0dd03e9  jmp 0x00007986E0DCF023
00007986e0dd03ee  call 0x00007986E0CC33A0
00007986e0dd03f3  jmp 0x00007986E0DCF035
00007986e0dd03f8  call 0x00007986E0CC2120
00007986e0dd03fd  jmp 0x00007986E0DCF03F
00007986e0dd0402  call 0x00007986E0CC0860
00007986e0dd0407  jmp 0x00007986E0DCF067
00007986e0dd040c  call 0x00007986E0CBF5F0
00007986e0dd0411  jmp 0x00007986E0DCF073
00007986e0dd0416  call 0x00007986E0CC0860
00007986e0dd041b  jmp 0x00007986E0DCF0A5
00007986e0dd0420  call 0x00007986E0CBF5F0
00007986e0dd0425  jmp 0x00007986E0DCF0B1
00007986e0dd042a  call 0x00007986E0CC4740
00007986e0dd042f  jmp 0x00007986E0DCF0BE
00007986e0dd0434  call 0x00007986E0CB5400
00007986e0dd0439  jmp 0x00007986E0DCF0CB
00007986e0dd043e  call 0x00007986E0CB52F0
00007986e0dd0443  jmp 0x00007986E0DCF0D8
00007986e0dd0448  call 0x00007986E0CC4620
00007986e0dd044d  jmp 0x00007986E0DCF0E5
00007986e0dd0452  call 0x00007986E0CC0860
00007986e0dd0457  jmp 0x00007986E0DCF10D
00007986e0dd045c  call 0x00007986E0CBF5F0
00007986e0dd0461  jmp 0x00007986E0DCF119
00007986e0dd0466  call 0x00007986E0C09D70
00007986e0dd046b  jmp 0x00007986E0DCF11F
00007986e0dd0470  call 0x00007986E0CBE9C0
00007986e0dd0475  jmp 0x00007986E0DCF129
00007986e0dd047a  call 0x00007986E0CC0860
00007986e0dd047f  jmp 0x00007986E0DCF151
00007986e0dd0484  call 0x00007986E0CBF5F0
00007986e0dd0489  jmp 0x00007986E0DCF15D
00007986e0dd048e  call 0x00007986E0CBD750
00007986e0dd0493  jmp 0x00007986E0DCF16A
00007986e0dd0498  call 0x00007986E0CBC4E0
00007986e0dd049d  jmp 0x00007986E0DCF177
00007986e0dd04a2  call 0x00007986E0CC4740
00007986e0dd04a7  jmp 0x00007986E0DCF184
00007986e0dd04ac  call 0x00007986E0CB5400
00007986e0dd04b1  jmp 0x00007986E0DCF191
00007986e0dd04b6  call 0x00007986E0CB52F0
00007986e0dd04bb  jmp 0x00007986E0DCF19E
00007986e0dd04c0  call 0x00007986E0CC4620
00007986e0dd04c5  jmp 0x00007986E0DCF1AB
00007986e0dd04ca  call 0x00007986E0CC0860
00007986e0dd04cf  jmp 0x00007986E0DCF1BE
00007986e0dd04d4  call 0x00007986E0CBB270
00007986e0dd04d9  jmp 0x00007986E0DCF1CB
00007986e0dd04de  call 0x00007986E0CBA000
00007986e0dd04e3  jmp 0x00007986E0DCF1D8
00007986e0dd04e8  call 0x00007986E0CB8D90
00007986e0dd04ed  jmp 0x00007986E0DCF1E5
00007986e0dd04f2  call 0x00007986E0CB8A20
00007986e0dd04f7  jmp 0x00007986E0DCF1F2
00007986e0dd04fc  call 0x00007986E0CB5400
00007986e0dd0501  jmp 0x00007986E0DCF1FC
00007986e0dd0506  call 0x00007986E0CC2240
00007986e0dd050b  jmp 0x00007986E0DCF206
00007986e0dd0510  call 0x00007986E0CB52F0
00007986e0dd0515  jmp 0x00007986E0DCF210
00007986e0dd051a  call 0x00007986E0CC2120
00007986e0dd051f  jmp 0x00007986E0DCF21A
00007986e0dd0524  call 0x00007986E0CB77B0
00007986e0dd0529  jmp 0x00007986E0DCF224
00007986e0dd052e  call 0x00007986E0CB6550
00007986e0dd0533  jmp 0x00007986E0DCF22E
00007986e0dd0538  call 0x00007986E0CBFD50
00007986e0dd053d  jmp 0x00007986E0DCF240
00007986e0dd0542  call 0x00007986E0CB8EA0
00007986e0dd0547  jmp 0x00007986E0DCF24A
00007986e0dd054c  call 0x00007986E0CBFC30
00007986e0dd0551  jmp 0x00007986E0DCF257
00007986e0dd0556  call 0x00007986E0CB8D90
00007986e0dd055b  jmp 0x00007986E0DCF264
00007986e0dd0560  call 0x00007986E0CC2240
00007986e0dd0565  jmp 0x00007986E0DCF271
00007986e0dd056a  call 0x00007986E0CB5400
00007986e0dd056f  jmp 0x00007986E0DCF27E
00007986e0dd0574  call 0x00007986E0CB52F0
00007986e0dd0579  jmp 0x00007986E0DCF28B
00007986e0dd057e  call 0x00007986E0CC2120
00007986e0dd0583  jmp 0x00007986E0DCF298
00007986e0dd0588  call 0x00007986E0CB52F0
00007986e0dd058d  jmp 0x00007986E0DCF2AB
00007986e0dd0592  call 0x00007986E0CB52F0
00007986e0dd0597  jmp 0x00007986E0DCF2BE
00007986e0dd059c  call 0x00007986E0CB52F0
00007986e0dd05a1  jmp 0x00007986E0DCF2D1
00007986e0dd05a6  call 0x00007986E0CB52F0
00007986e0dd05ab  jmp 0x00007986E0DCF2E4
00007986e0dd05b0  call 0x00007986E0CC2240
00007986e0dd05b5  jmp 0x00007986E0DCF2F9
00007986e0dd05ba  call 0x00007986E0CC2240
00007986e0dd05bf  jmp 0x00007986E0DCF30C
00007986e0dd05c4  call 0x00007986E0CC2120
00007986e0dd05c9  jmp 0x00007986E0DCF319
00007986e0dd05ce  call 0x00007986E0CB52F0
00007986e0dd05d3  jmp 0x00007986E0DCF32C
00007986e0dd05d8  call 0x00007986E0CB52F0
00007986e0dd05dd  jmp 0x00007986E0DCF34F
00007986e0dd05e2  call 0x00007986E0CB52F0
00007986e0dd05e7  jmp 0x00007986E0DCF362
00007986e0dd05ec  call 0x00007986E0BFF540
00007986e0dd05f1  jmp 0x00007986E0DCF380
00007986e0dd05f6  call 0x00007986E0C08C20
00007986e0dd05fb  jmp 0x00007986E0DCF38A
00007986e0dd0600  call 0x00007986E0CD6600
00007986e0dd0605  jmp 0x00007986E0DCF396
00007986e0dd060a  call 0x00007986E0BFF540
00007986e0dd060f  jmp 0x00007986E0DCF3A6
00007986e0dd0614  call 0x00007986E0CC0370
00007986e0dd0619  jmp 0x00007986E0DCF3D4
00007986e0dd061e  call 0x00007986E0CBF100
00007986e0dd0623  jmp 0x00007986E0DCF3DD
00007986e0dd0628  call 0x00007986E0CC0370
00007986e0dd062d  jmp 0x00007986E0DCF43B
00007986e0dd0632  call 0x00007986E0CBF100
00007986e0dd0637  jmp 0x00007986E0DCF444
00007986e0dd063c  call 0x00007986E0CC0370
00007986e0dd0641  jmp 0x00007986E0DCF48B
00007986e0dd0646  call 0x00007986E0CBF100
00007986e0dd064b  jmp 0x00007986E0DCF494
00007986e0dd0650  call 0x00007986E0C0B720
00007986e0dd0655  jmp 0x00007986E0DCF4D7
00007986e0dd065a  call 0x00007986E0CB47C0
00007986e0dd065f  jmp 0x00007986E0DCF4EA
00007986e0dd0664  call 0x00007986E0C08B00
00007986e0dd0669  jmp 0x00007986E0DCF501
00007986e0dd066e  call 0x00007986E0BFF430
00007986e0dd0673  jmp 0x00007986E0DCF514
00007986e0dd0678  call 0x00007986E0BFF430
00007986e0dd067d  jmp 0x00007986E0DCF527
00007986e0dd0682  sub rsp, 0x08
00007986e0dd0686  push rax
00007986e0dd0687  push rcx
00007986e0dd0688  push rdx
00007986e0dd0689  push rdi
00007986e0dd068a  push rsi
00007986e0dd068b  push r8
00007986e0dd068d  push r9
00007986e0dd068f  push r10
00007986e0dd0691  push r11
00007986e0dd0693  sub rsp, 0xF0
00007986e0dd069a  vmovaps [rsp], xmm0
00007986e0dd069f  vmovaps [rsp+0x10], xmm2
00007986e0dd06a5  vmovaps [rsp+0x20], xmm3
00007986e0dd06ab  vmovaps [rsp+0x30], xmm4
00007986e0dd06b1  vmovaps [rsp+0x40], xmm5
00007986e0dd06b7  vmovaps [rsp+0x50], xmm6
00007986e0dd06bd  vmovaps [rsp+0x60], xmm7
00007986e0dd06c3  vmovaps [rsp+0x70], xmm8
00007986e0dd06c9  vmovaps [rsp+0x80], xmm9
00007986e0dd06d2  vmovaps [rsp+0x90], xmm10
00007986e0dd06db  vmovaps [rsp+0xA0], xmm11
00007986e0dd06e4  vmovaps [rsp+0xB0], xmm12
00007986e0dd06ed  vmovaps [rsp+0xC0], xmm13
00007986e0dd06f6  vmovaps [rsp+0xD0], xmm14
00007986e0dd06ff  vmovaps [rsp+0xE0], xmm15
00007986e0dd0708  sub rsp, 0x30
00007986e0dd070c  movaps [rsp], xmm1
00007986e0dd0710  movaps [rsp+0x10], xmm15
00007986e0dd0716  movaps [rsp+0x20], xmm14
00007986e0dd071c  lea rdi, [rsp]
00007986e0dd0720  mov esi, 0x00
00007986e0dd0725  mov rax, 0x5652C689F530
00007986e0dd072f  call rax
00007986e0dd0731  movaps xmm1, [rsp]
00007986e0dd0735  add rsp, 0x30
00007986e0dd0739  vmovaps xmm0, [rsp]
00007986e0dd073e  vmovaps xmm2, [rsp+0x10]
00007986e0dd0744  vmovaps xmm3, [rsp+0x20]
00007986e0dd074a  vmovaps xmm4, [rsp+0x30]
00007986e0dd0750  vmovaps xmm5, [rsp+0x40]
00007986e0dd0756  vmovaps xmm6, [rsp+0x50]
00007986e0dd075c  vmovaps xmm7, [rsp+0x60]
00007986e0dd0762  vmovaps xmm8, [rsp+0x70]
00007986e0dd0768  vmovaps xmm9, [rsp+0x80]
00007986e0dd0771  vmovaps xmm10, [rsp+0x90]
00007986e0dd077a  vmovaps xmm11, [rsp+0xA0]
00007986e0dd0783  vmovaps xmm12, [rsp+0xB0]
00007986e0dd078c  vmovaps xmm13, [rsp+0xC0]
00007986e0dd0795  vmovaps xmm14, [rsp+0xD0]
00007986e0dd079e  vmovaps xmm15, [rsp+0xE0]
00007986e0dd07a7  add rsp, 0xF0
00007986e0dd07ae  pop r11
00007986e0dd07b0  pop r10
00007986e0dd07b2  pop r9
00007986e0dd07b4  pop r8
00007986e0dd07b6  pop rsi
00007986e0dd07b7  pop rdi
00007986e0dd07b8  pop rdx
00007986e0dd07b9  pop rcx
00007986e0dd07ba  pop rax
00007986e0dd07bb  add rsp, 0x08
00007986e0dd07bf  jmp 0x00007986E0DCF581
00007986e0dd07c4  sub rsp, 0x08
00007986e0dd07c8  push rax
00007986e0dd07c9  push rcx
00007986e0dd07ca  push rdx
00007986e0dd07cb  push rdi
00007986e0dd07cc  push rsi
00007986e0dd07cd  push r8
00007986e0dd07cf  push r9
00007986e0dd07d1  push r10
00007986e0dd07d3  push r11
00007986e0dd07d5  sub rsp, 0xF0
00007986e0dd07dc  vmovaps [rsp], xmm0
00007986e0dd07e1  vmovaps [rsp+0x10], xmm1
00007986e0dd07e7  vmovaps [rsp+0x20], xmm2
00007986e0dd07ed  vmovaps [rsp+0x30], xmm3
00007986e0dd07f3  vmovaps [rsp+0x40], xmm4
00007986e0dd07f9  vmovaps [rsp+0x50], xmm5
00007986e0dd07ff  vmovaps [rsp+0x60], xmm6
00007986e0dd0805  vmovaps [rsp+0x70], xmm7
00007986e0dd080b  vmovaps [rsp+0x80], xmm8
00007986e0dd0814  vmovaps [rsp+0x90], xmm9
00007986e0dd081d  vmovaps [rsp+0xA0], xmm10
00007986e0dd0826  vmovaps [rsp+0xB0], xmm11
00007986e0dd082f  vmovaps [rsp+0xC0], xmm12
00007986e0dd0838  vmovaps [rsp+0xD0], xmm14
00007986e0dd0841  vmovaps [rsp+0xE0], xmm15
00007986e0dd084a  sub rsp, 0x30
00007986e0dd084e  movaps [rsp], xmm13
00007986e0dd0853  movaps [rsp+0x10], xmm1
00007986e0dd0858  movaps [rsp+0x20], xmm14
00007986e0dd085e  lea rdi, [rsp]
00007986e0dd0862  mov esi, 0x00
00007986e0dd0867  mov rax, 0x5652C689F530
00007986e0dd0871  call rax
00007986e0dd0873  movaps xmm13, [rsp]
00007986e0dd0878  add rsp, 0x30
00007986e0dd087c  vmovaps xmm0, [rsp]
00007986e0dd0881  vmovaps xmm1, [rsp+0x10]
00007986e0dd0887  vmovaps xmm2, [rsp+0x20]
00007986e0dd088d  vmovaps xmm3, [rsp+0x30]
00007986e0dd0893  vmovaps xmm4, [rsp+0x40]
00007986e0dd0899  vmovaps xmm5, [rsp+0x50]
00007986e0dd089f  vmovaps xmm6, [rsp+0x60]
00007986e0dd08a5  vmovaps xmm7, [rsp+0x70]
00007986e0dd08ab  vmovaps xmm8, [rsp+0x80]
00007986e0dd08b4  vmovaps xmm9, [rsp+0x90]
00007986e0dd08bd  vmovaps xmm10, [rsp+0xA0]
00007986e0dd08c6  vmovaps xmm11, [rsp+0xB0]
00007986e0dd08cf  vmovaps xmm12, [rsp+0xC0]
00007986e0dd08d8  vmovaps xmm14, [rsp+0xD0]
00007986e0dd08e1  vmovaps xmm15, [rsp+0xE0]
00007986e0dd08ea  add rsp, 0xF0
00007986e0dd08f1  pop r11
00007986e0dd08f3  pop r10
00007986e0dd08f5  pop r9
00007986e0dd08f7  pop r8
00007986e0dd08f9  pop rsi
00007986e0dd08fa  pop rdi
00007986e0dd08fb  pop rdx
00007986e0dd08fc  pop rcx
00007986e0dd08fd  pop rax
00007986e0dd08fe  add rsp, 0x08
00007986e0dd0902  jmp 0x00007986E0DCF5CF
00007986e0dd0907  sub rsp, 0x08
00007986e0dd090b  push rax
00007986e0dd090c  push rcx
00007986e0dd090d  push rdx
00007986e0dd090e  push rdi
00007986e0dd090f  push rsi
00007986e0dd0910  push r8
00007986e0dd0912  push r9
00007986e0dd0914  push r10
00007986e0dd0916  push r11
00007986e0dd0918  sub rsp, 0xF0
00007986e0dd091f  vmovaps [rsp], xmm0
00007986e0dd0924  vmovaps [rsp+0x10], xmm1
00007986e0dd092a  vmovaps [rsp+0x20], xmm2
00007986e0dd0930  vmovaps [rsp+0x30], xmm3
00007986e0dd0936  vmovaps [rsp+0x40], xmm4
00007986e0dd093c  vmovaps [rsp+0x50], xmm5
00007986e0dd0942  vmovaps [rsp+0x60], xmm6
00007986e0dd0948  vmovaps [rsp+0x70], xmm7
00007986e0dd094e  vmovaps [rsp+0x80], xmm8
00007986e0dd0957  vmovaps [rsp+0x90], xmm9
00007986e0dd0960  vmovaps [rsp+0xA0], xmm10
00007986e0dd0969  vmovaps [rsp+0xB0], xmm11
00007986e0dd0972  vmovaps [rsp+0xC0], xmm12
00007986e0dd097b  vmovaps [rsp+0xD0], xmm13
00007986e0dd0984  vmovaps [rsp+0xE0], xmm14
00007986e0dd098d  sub rsp, 0x30
00007986e0dd0991  movaps [rsp], xmm15
00007986e0dd0996  movaps [rsp+0x10], xmm14
00007986e0dd099c  movaps [rsp+0x20], xmm1
00007986e0dd09a1  lea rdi, [rsp]
00007986e0dd09a5  mov esi, 0x00
00007986e0dd09aa  mov rax, 0x5652C689F530
00007986e0dd09b4  call rax
00007986e0dd09b6  movaps xmm15, [rsp]
00007986e0dd09bb  add rsp, 0x30
00007986e0dd09bf  vmovaps xmm0, [rsp]
00007986e0dd09c4  vmovaps xmm1, [rsp+0x10]
00007986e0dd09ca  vmovaps xmm2, [rsp+0x20]
00007986e0dd09d0  vmovaps xmm3, [rsp+0x30]
00007986e0dd09d6  vmovaps xmm4, [rsp+0x40]
00007986e0dd09dc  vmovaps xmm5, [rsp+0x50]
00007986e0dd09e2  vmovaps xmm6, [rsp+0x60]
00007986e0dd09e8  vmovaps xmm7, [rsp+0x70]
00007986e0dd09ee  vmovaps xmm8, [rsp+0x80]
00007986e0dd09f7  vmovaps xmm9, [rsp+0x90]
00007986e0dd0a00  vmovaps xmm10, [rsp+0xA0]
00007986e0dd0a09  vmovaps xmm11, [rsp+0xB0]
00007986e0dd0a12  vmovaps xmm12, [rsp+0xC0]
00007986e0dd0a1b  vmovaps xmm13, [rsp+0xD0]
00007986e0dd0a24  vmovaps xmm14, [rsp+0xE0]
00007986e0dd0a2d  add rsp, 0xF0
00007986e0dd0a34  pop r11
00007986e0dd0a36  pop r10
00007986e0dd0a38  pop r9
00007986e0dd0a3a  pop r8
00007986e0dd0a3c  pop rsi
00007986e0dd0a3d  pop rdi
00007986e0dd0a3e  pop rdx
00007986e0dd0a3f  pop rcx
00007986e0dd0a40  pop rax
00007986e0dd0a41  add rsp, 0x08
00007986e0dd0a45  jmp 0x00007986E0DCF617
00007986e0dd0a4a  sub rsp, 0x08
00007986e0dd0a4e  push rax
00007986e0dd0a4f  push rcx
00007986e0dd0a50  push rdx
00007986e0dd0a51  push rdi
00007986e0dd0a52  push rsi
00007986e0dd0a53  push r8
00007986e0dd0a55  push r9
00007986e0dd0a57  push r10
00007986e0dd0a59  push r11
00007986e0dd0a5b  sub rsp, 0xF0
00007986e0dd0a62  vmovaps [rsp], xmm0
00007986e0dd0a67  vmovaps [rsp+0x10], xmm2
00007986e0dd0a6d  vmovaps [rsp+0x20], xmm3
00007986e0dd0a73  vmovaps [rsp+0x30], xmm4
00007986e0dd0a79  vmovaps [rsp+0x40], xmm5
00007986e0dd0a7f  vmovaps [rsp+0x50], xmm6
00007986e0dd0a85  vmovaps [rsp+0x60], xmm7
00007986e0dd0a8b  vmovaps [rsp+0x70], xmm8
00007986e0dd0a91  vmovaps [rsp+0x80], xmm9
00007986e0dd0a9a  vmovaps [rsp+0x90], xmm10
00007986e0dd0aa3  vmovaps [rsp+0xA0], xmm11
00007986e0dd0aac  vmovaps [rsp+0xB0], xmm12
00007986e0dd0ab5  vmovaps [rsp+0xC0], xmm13
00007986e0dd0abe  vmovaps [rsp+0xD0], xmm14
00007986e0dd0ac7  vmovaps [rsp+0xE0], xmm15
00007986e0dd0ad0  sub rsp, 0x30
00007986e0dd0ad4  movaps [rsp], xmm1
00007986e0dd0ad8  movaps [rsp+0x10], xmm14
00007986e0dd0ade  movaps [rsp+0x20], xmm10
00007986e0dd0ae4  lea rdi, [rsp]
00007986e0dd0ae8  mov esi, 0x00
00007986e0dd0aed  mov rax, 0x5652C689F530
00007986e0dd0af7  call rax
00007986e0dd0af9  movaps xmm1, [rsp]
00007986e0dd0afd  add rsp, 0x30
00007986e0dd0b01  vmovaps xmm0, [rsp]
00007986e0dd0b06  vmovaps xmm2, [rsp+0x10]
00007986e0dd0b0c  vmovaps xmm3, [rsp+0x20]
00007986e0dd0b12  vmovaps xmm4, [rsp+0x30]
00007986e0dd0b18  vmovaps xmm5, [rsp+0x40]
00007986e0dd0b1e  vmovaps xmm6, [rsp+0x50]
00007986e0dd0b24  vmovaps xmm7, [rsp+0x60]
00007986e0dd0b2a  vmovaps xmm8, [rsp+0x70]
00007986e0dd0b30  vmovaps xmm9, [rsp+0x80]
00007986e0dd0b39  vmovaps xmm10, [rsp+0x90]
00007986e0dd0b42  vmovaps xmm11, [rsp+0xA0]
00007986e0dd0b4b  vmovaps xmm12, [rsp+0xB0]
00007986e0dd0b54  vmovaps xmm13, [rsp+0xC0]
00007986e0dd0b5d  vmovaps xmm14, [rsp+0xD0]
00007986e0dd0b66  vmovaps xmm15, [rsp+0xE0]
00007986e0dd0b6f  add rsp, 0xF0
00007986e0dd0b76  pop r11
00007986e0dd0b78  pop r10
00007986e0dd0b7a  pop r9
00007986e0dd0b7c  pop r8
00007986e0dd0b7e  pop rsi
00007986e0dd0b7f  pop rdi
00007986e0dd0b80  pop rdx
00007986e0dd0b81  pop rcx
00007986e0dd0b82  pop rax
00007986e0dd0b83  add rsp, 0x08
00007986e0dd0b87  jmp 0x00007986E0DCF631
00007986e0dd0b8c  sub rsp, 0x08
00007986e0dd0b90  push rax
00007986e0dd0b91  push rcx
00007986e0dd0b92  push rdx
00007986e0dd0b93  push rdi
00007986e0dd0b94  push rsi
00007986e0dd0b95  push r8
00007986e0dd0b97  push r9
00007986e0dd0b99  push r10
00007986e0dd0b9b  push r11
00007986e0dd0b9d  sub rsp, 0xF0
00007986e0dd0ba4  vmovaps [rsp], xmm0
00007986e0dd0ba9  vmovaps [rsp+0x10], xmm1
00007986e0dd0baf  vmovaps [rsp+0x20], xmm2
00007986e0dd0bb5  vmovaps [rsp+0x30], xmm3
00007986e0dd0bbb  vmovaps [rsp+0x40], xmm4
00007986e0dd0bc1  vmovaps [rsp+0x50], xmm5
00007986e0dd0bc7  vmovaps [rsp+0x60], xmm6
00007986e0dd0bcd  vmovaps [rsp+0x70], xmm7
00007986e0dd0bd3  vmovaps [rsp+0x80], xmm8
00007986e0dd0bdc  vmovaps [rsp+0x90], xmm9
00007986e0dd0be5  vmovaps [rsp+0xA0], xmm10
00007986e0dd0bee  vmovaps [rsp+0xB0], xmm11
00007986e0dd0bf7  vmovaps [rsp+0xC0], xmm12
00007986e0dd0c00  vmovaps [rsp+0xD0], xmm14
00007986e0dd0c09  vmovaps [rsp+0xE0], xmm15
00007986e0dd0c12  sub rsp, 0x30
00007986e0dd0c16  movaps [rsp], xmm13
00007986e0dd0c1b  movaps [rsp+0x10], xmm14
00007986e0dd0c21  movaps [rsp+0x20], xmm2
00007986e0dd0c26  lea rdi, [rsp]
00007986e0dd0c2a  mov esi, 0x00
00007986e0dd0c2f  mov rax, 0x5652C689F530
00007986e0dd0c39  call rax
00007986e0dd0c3b  movaps xmm13, [rsp]
00007986e0dd0c40  add rsp, 0x30
00007986e0dd0c44  vmovaps xmm0, [rsp]
00007986e0dd0c49  vmovaps xmm1, [rsp+0x10]
00007986e0dd0c4f  vmovaps xmm2, [rsp+0x20]
00007986e0dd0c55  vmovaps xmm3, [rsp+0x30]
00007986e0dd0c5b  vmovaps xmm4, [rsp+0x40]
00007986e0dd0c61  vmovaps xmm5, [rsp+0x50]
00007986e0dd0c67  vmovaps xmm6, [rsp+0x60]
00007986e0dd0c6d  vmovaps xmm7, [rsp+0x70]
00007986e0dd0c73  vmovaps xmm8, [rsp+0x80]
00007986e0dd0c7c  vmovaps xmm9, [rsp+0x90]
00007986e0dd0c85  vmovaps xmm10, [rsp+0xA0]
00007986e0dd0c8e  vmovaps xmm11, [rsp+0xB0]
00007986e0dd0c97  vmovaps xmm12, [rsp+0xC0]
00007986e0dd0ca0  vmovaps xmm14, [rsp+0xD0]
00007986e0dd0ca9  vmovaps xmm15, [rsp+0xE0]
00007986e0dd0cb2  add rsp, 0xF0
00007986e0dd0cb9  pop r11
00007986e0dd0cbb  pop r10
00007986e0dd0cbd  pop r9
00007986e0dd0cbf  pop r8
00007986e0dd0cc1  pop rsi
00007986e0dd0cc2  pop rdi
00007986e0dd0cc3  pop rdx
00007986e0dd0cc4  pop rcx
00007986e0dd0cc5  pop rax
00007986e0dd0cc6  add rsp, 0x08
00007986e0dd0cca  jmp 0x00007986E0DCF64C
00007986e0dd0ccf  sub rsp, 0x08
00007986e0dd0cd3  push rax
00007986e0dd0cd4  push rcx
00007986e0dd0cd5  push rdx
00007986e0dd0cd6  push rdi
00007986e0dd0cd7  push rsi
00007986e0dd0cd8  push r8
00007986e0dd0cda  push r9
00007986e0dd0cdc  push r10
00007986e0dd0cde  push r11
00007986e0dd0ce0  sub rsp, 0xF0
00007986e0dd0ce7  vmovaps [rsp], xmm0
00007986e0dd0cec  vmovaps [rsp+0x10], xmm2
00007986e0dd0cf2  vmovaps [rsp+0x20], xmm3
00007986e0dd0cf8  vmovaps [rsp+0x30], xmm4
00007986e0dd0cfe  vmovaps [rsp+0x40], xmm5
00007986e0dd0d04  vmovaps [rsp+0x50], xmm6
00007986e0dd0d0a  vmovaps [rsp+0x60], xmm7
00007986e0dd0d10  vmovaps [rsp+0x70], xmm8
00007986e0dd0d16  vmovaps [rsp+0x80], xmm9
00007986e0dd0d1f  vmovaps [rsp+0x90], xmm10
00007986e0dd0d28  vmovaps [rsp+0xA0], xmm11
00007986e0dd0d31  vmovaps [rsp+0xB0], xmm12
00007986e0dd0d3a  vmovaps [rsp+0xC0], xmm13
00007986e0dd0d43  vmovaps [rsp+0xD0], xmm14
00007986e0dd0d4c  vmovaps [rsp+0xE0], xmm15
00007986e0dd0d55  sub rsp, 0x30
00007986e0dd0d59  movaps [rsp], xmm1
00007986e0dd0d5d  movaps [rsp+0x10], xmm10
00007986e0dd0d63  movaps [rsp+0x20], xmm2
00007986e0dd0d68  lea rdi, [rsp]
00007986e0dd0d6c  mov esi, 0x00
00007986e0dd0d71  mov rax, 0x5652C689F530
00007986e0dd0d7b  call rax
00007986e0dd0d7d  movaps xmm1, [rsp]
00007986e0dd0d81  add rsp, 0x30
00007986e0dd0d85  vmovaps xmm0, [rsp]
00007986e0dd0d8a  vmovaps xmm2, [rsp+0x10]
00007986e0dd0d90  vmovaps xmm3, [rsp+0x20]
00007986e0dd0d96  vmovaps xmm4, [rsp+0x30]
00007986e0dd0d9c  vmovaps xmm5, [rsp+0x40]
00007986e0dd0da2  vmovaps xmm6, [rsp+0x50]
00007986e0dd0da8  vmovaps xmm7, [rsp+0x60]
00007986e0dd0dae  vmovaps xmm8, [rsp+0x70]
00007986e0dd0db4  vmovaps xmm9, [rsp+0x80]
00007986e0dd0dbd  vmovaps xmm10, [rsp+0x90]
00007986e0dd0dc6  vmovaps xmm11, [rsp+0xA0]
00007986e0dd0dcf  vmovaps xmm12, [rsp+0xB0]
00007986e0dd0dd8  vmovaps xmm13, [rsp+0xC0]
00007986e0dd0de1  vmovaps xmm14, [rsp+0xD0]
00007986e0dd0dea  vmovaps xmm15, [rsp+0xE0]
00007986e0dd0df3  add rsp, 0xF0
00007986e0dd0dfa  pop r11
00007986e0dd0dfc  pop r10
00007986e0dd0dfe  pop r9
00007986e0dd0e00  pop r8
00007986e0dd0e02  pop rsi
00007986e0dd0e03  pop rdi
00007986e0dd0e04  pop rdx
00007986e0dd0e05  pop rcx
00007986e0dd0e06  pop rax
00007986e0dd0e07  add rsp, 0x08
00007986e0dd0e0b  jmp 0x00007986E0DCF6B4
00007986e0dd0e10  sub rsp, 0x08
00007986e0dd0e14  push rax
00007986e0dd0e15  push rcx
00007986e0dd0e16  push rdx
00007986e0dd0e17  push rdi
00007986e0dd0e18  push rsi
00007986e0dd0e19  push r8
00007986e0dd0e1b  push r9
00007986e0dd0e1d  push r10
00007986e0dd0e1f  push r11
00007986e0dd0e21  sub rsp, 0xF0
00007986e0dd0e28  vmovaps [rsp], xmm0
00007986e0dd0e2d  vmovaps [rsp+0x10], xmm1
00007986e0dd0e33  vmovaps [rsp+0x20], xmm2
00007986e0dd0e39  vmovaps [rsp+0x30], xmm3
00007986e0dd0e3f  vmovaps [rsp+0x40], xmm4
00007986e0dd0e45  vmovaps [rsp+0x50], xmm5
00007986e0dd0e4b  vmovaps [rsp+0x60], xmm6
00007986e0dd0e51  vmovaps [rsp+0x70], xmm7
00007986e0dd0e57  vmovaps [rsp+0x80], xmm8
00007986e0dd0e60  vmovaps [rsp+0x90], xmm9
00007986e0dd0e69  vmovaps [rsp+0xA0], xmm10
00007986e0dd0e72  vmovaps [rsp+0xB0], xmm11
00007986e0dd0e7b  vmovaps [rsp+0xC0], xmm12
00007986e0dd0e84  vmovaps [rsp+0xD0], xmm13
00007986e0dd0e8d  vmovaps [rsp+0xE0], xmm14
00007986e0dd0e96  sub rsp, 0x30
00007986e0dd0e9a  movaps [rsp], xmm15
00007986e0dd0e9f  movaps [rsp+0x10], xmm10
00007986e0dd0ea5  movaps [rsp+0x20], xmm2
00007986e0dd0eaa  lea rdi, [rsp]
00007986e0dd0eae  mov esi, 0x00
00007986e0dd0eb3  mov rax, 0x5652C689F530
00007986e0dd0ebd  call rax
00007986e0dd0ebf  movaps xmm15, [rsp]
00007986e0dd0ec4  add rsp, 0x30
00007986e0dd0ec8  vmovaps xmm0, [rsp]
00007986e0dd0ecd  vmovaps xmm1, [rsp+0x10]
00007986e0dd0ed3  vmovaps xmm2, [rsp+0x20]
00007986e0dd0ed9  vmovaps xmm3, [rsp+0x30]
00007986e0dd0edf  vmovaps xmm4, [rsp+0x40]
00007986e0dd0ee5  vmovaps xmm5, [rsp+0x50]
00007986e0dd0eeb  vmovaps xmm6, [rsp+0x60]
00007986e0dd0ef1  vmovaps xmm7, [rsp+0x70]
00007986e0dd0ef7  vmovaps xmm8, [rsp+0x80]
00007986e0dd0f00  vmovaps xmm9, [rsp+0x90]
00007986e0dd0f09  vmovaps xmm10, [rsp+0xA0]
00007986e0dd0f12  vmovaps xmm11, [rsp+0xB0]
00007986e0dd0f1b  vmovaps xmm12, [rsp+0xC0]
00007986e0dd0f24  vmovaps xmm13, [rsp+0xD0]
00007986e0dd0f2d  vmovaps xmm14, [rsp+0xE0]
00007986e0dd0f36  add rsp, 0xF0
00007986e0dd0f3d  pop r11
00007986e0dd0f3f  pop r10
00007986e0dd0f41  pop r9
00007986e0dd0f43  pop r8
00007986e0dd0f45  pop rsi
00007986e0dd0f46  pop rdi
00007986e0dd0f47  pop rdx
00007986e0dd0f48  pop rcx
00007986e0dd0f49  pop rax
00007986e0dd0f4a  add rsp, 0x08
00007986e0dd0f4e  jmp 0x00007986E0DCF706
00007986e0dd0f53  sub rsp, 0x08
00007986e0dd0f57  push rax
00007986e0dd0f58  push rcx
00007986e0dd0f59  push rdx
00007986e0dd0f5a  push rdi
00007986e0dd0f5b  push rsi
00007986e0dd0f5c  push r8
00007986e0dd0f5e  push r9
00007986e0dd0f60  push r10
00007986e0dd0f62  push r11
00007986e0dd0f64  sub rsp, 0xF0
00007986e0dd0f6b  vmovaps [rsp], xmm0
00007986e0dd0f70  vmovaps [rsp+0x10], xmm2
00007986e0dd0f76  vmovaps [rsp+0x20], xmm3
00007986e0dd0f7c  vmovaps [rsp+0x30], xmm4
00007986e0dd0f82  vmovaps [rsp+0x40], xmm5
00007986e0dd0f88  vmovaps [rsp+0x50], xmm6
00007986e0dd0f8e  vmovaps [rsp+0x60], xmm7
00007986e0dd0f94  vmovaps [rsp+0x70], xmm8
00007986e0dd0f9a  vmovaps [rsp+0x80], xmm9
00007986e0dd0fa3  vmovaps [rsp+0x90], xmm10
00007986e0dd0fac  vmovaps [rsp+0xA0], xmm11
00007986e0dd0fb5  vmovaps [rsp+0xB0], xmm12
00007986e0dd0fbe  vmovaps [rsp+0xC0], xmm13
00007986e0dd0fc7  vmovaps [rsp+0xD0], xmm14
00007986e0dd0fd0  vmovaps [rsp+0xE0], xmm15
00007986e0dd0fd9  sub rsp, 0x30
00007986e0dd0fdd  movaps [rsp], xmm1
00007986e0dd0fe1  movaps [rsp+0x10], xmm10
00007986e0dd0fe7  movaps [rsp+0x20], xmm12
00007986e0dd0fed  lea rdi, [rsp]
00007986e0dd0ff1  mov esi, 0x00
00007986e0dd0ff6  mov rax, 0x5652C689F530
00007986e0dd1000  call rax
00007986e0dd1002  movaps xmm1, [rsp]
00007986e0dd1006  add rsp, 0x30
00007986e0dd100a  vmovaps xmm0, [rsp]
00007986e0dd100f  vmovaps xmm2, [rsp+0x10]
00007986e0dd1015  vmovaps xmm3, [rsp+0x20]
00007986e0dd101b  vmovaps xmm4, [rsp+0x30]
00007986e0dd1021  vmovaps xmm5, [rsp+0x40]
00007986e0dd1027  vmovaps xmm6, [rsp+0x50]
00007986e0dd102d  vmovaps xmm7, [rsp+0x60]
00007986e0dd1033  vmovaps xmm8, [rsp+0x70]
00007986e0dd1039  vmovaps xmm9, [rsp+0x80]
00007986e0dd1042  vmovaps xmm10, [rsp+0x90]
00007986e0dd104b  vmovaps xmm11, [rsp+0xA0]
00007986e0dd1054  vmovaps xmm12, [rsp+0xB0]
00007986e0dd105d  vmovaps xmm13, [rsp+0xC0]
00007986e0dd1066  vmovaps xmm14, [rsp+0xD0]
00007986e0dd106f  vmovaps xmm15, [rsp+0xE0]
00007986e0dd1078  add rsp, 0xF0
00007986e0dd107f  pop r11
00007986e0dd1081  pop r10
00007986e0dd1083  pop r9
00007986e0dd1085  pop r8
00007986e0dd1087  pop rsi
00007986e0dd1088  pop rdi
00007986e0dd1089  pop rdx
00007986e0dd108a  pop rcx
00007986e0dd108b  pop rax
00007986e0dd108c  add rsp, 0x08
00007986e0dd1090  jmp 0x00007986E0DCF732
00007986e0dd1095  sub rsp, 0x08
00007986e0dd1099  push rax
00007986e0dd109a  push rcx
00007986e0dd109b  push rdx
00007986e0dd109c  push rdi
00007986e0dd109d  push rsi
00007986e0dd109e  push r8
00007986e0dd10a0  push r9
00007986e0dd10a2  push r10
00007986e0dd10a4  push r11
00007986e0dd10a6  sub rsp, 0xF0
00007986e0dd10ad  vmovaps [rsp], xmm0
00007986e0dd10b2  vmovaps [rsp+0x10], xmm1
00007986e0dd10b8  vmovaps [rsp+0x20], xmm2
00007986e0dd10be  vmovaps [rsp+0x30], xmm3
00007986e0dd10c4  vmovaps [rsp+0x40], xmm4
00007986e0dd10ca  vmovaps [rsp+0x50], xmm5
00007986e0dd10d0  vmovaps [rsp+0x60], xmm6
00007986e0dd10d6  vmovaps [rsp+0x70], xmm7
00007986e0dd10dc  vmovaps [rsp+0x80], xmm8
00007986e0dd10e5  vmovaps [rsp+0x90], xmm9
00007986e0dd10ee  vmovaps [rsp+0xA0], xmm10
00007986e0dd10f7  vmovaps [rsp+0xB0], xmm11
00007986e0dd1100  vmovaps [rsp+0xC0], xmm12
00007986e0dd1109  vmovaps [rsp+0xD0], xmm13
00007986e0dd1112  vmovaps [rsp+0xE0], xmm14
00007986e0dd111b  sub rsp, 0x30
00007986e0dd111f  movaps [rsp], xmm15
00007986e0dd1124  movaps [rsp+0x10], xmm10
00007986e0dd112a  movaps [rsp+0x20], xmm12
00007986e0dd1130  lea rdi, [rsp]
00007986e0dd1134  mov esi, 0x00
00007986e0dd1139  mov rax, 0x5652C689F530
00007986e0dd1143  call rax
00007986e0dd1145  movaps xmm15, [rsp]
00007986e0dd114a  add rsp, 0x30
00007986e0dd114e  vmovaps xmm0, [rsp]
00007986e0dd1153  vmovaps xmm1, [rsp+0x10]
00007986e0dd1159  vmovaps xmm2, [rsp+0x20]
00007986e0dd115f  vmovaps xmm3, [rsp+0x30]
00007986e0dd1165  vmovaps xmm4, [rsp+0x40]
00007986e0dd116b  vmovaps xmm5, [rsp+0x50]
00007986e0dd1171  vmovaps xmm6, [rsp+0x60]
00007986e0dd1177  vmovaps xmm7, [rsp+0x70]
00007986e0dd117d  vmovaps xmm8, [rsp+0x80]
00007986e0dd1186  vmovaps xmm9, [rsp+0x90]
00007986e0dd118f  vmovaps xmm10, [rsp+0xA0]
00007986e0dd1198  vmovaps xmm11, [rsp+0xB0]
00007986e0dd11a1  vmovaps xmm12, [rsp+0xC0]
00007986e0dd11aa  vmovaps xmm13, [rsp+0xD0]
00007986e0dd11b3  vmovaps xmm14, [rsp+0xE0]
00007986e0dd11bc  add rsp, 0xF0
00007986e0dd11c3  pop r11
00007986e0dd11c5  pop r10
00007986e0dd11c7  pop r9
00007986e0dd11c9  pop r8
00007986e0dd11cb  pop rsi
00007986e0dd11cc  pop rdi
00007986e0dd11cd  pop rdx
00007986e0dd11ce  pop rcx
00007986e0dd11cf  pop rax
00007986e0dd11d0  add rsp, 0x08
00007986e0dd11d4  jmp 0x00007986E0DCF75E
00007986e0dd11d9  call 0x00007986E0BFF430
00007986e0dd11de  jmp 0x00007986E0DCF7EE
00007986e0dd11e3  call 0x00007986E0BFF430
00007986e0dd11e8  jmp 0x00007986E0DCF801
00007986e0dd11ed  sub rsp, 0x08
00007986e0dd11f1  push rax
00007986e0dd11f2  push rcx
00007986e0dd11f3  push rdx
00007986e0dd11f4  push rdi
00007986e0dd11f5  push rsi
00007986e0dd11f6  push r8
00007986e0dd11f8  push r9
00007986e0dd11fa  push r10
00007986e0dd11fc  push r11
00007986e0dd11fe  sub rsp, 0xF0
00007986e0dd1205  vmovaps [rsp], xmm0
00007986e0dd120a  vmovaps [rsp+0x10], xmm2
00007986e0dd1210  vmovaps [rsp+0x20], xmm3
00007986e0dd1216  vmovaps [rsp+0x30], xmm4
00007986e0dd121c  vmovaps [rsp+0x40], xmm5
00007986e0dd1222  vmovaps [rsp+0x50], xmm6
00007986e0dd1228  vmovaps [rsp+0x60], xmm7
00007986e0dd122e  vmovaps [rsp+0x70], xmm8
00007986e0dd1234  vmovaps [rsp+0x80], xmm9
00007986e0dd123d  vmovaps [rsp+0x90], xmm10
00007986e0dd1246  vmovaps [rsp+0xA0], xmm11
00007986e0dd124f  vmovaps [rsp+0xB0], xmm12
00007986e0dd1258  vmovaps [rsp+0xC0], xmm13
00007986e0dd1261  vmovaps [rsp+0xD0], xmm14
00007986e0dd126a  vmovaps [rsp+0xE0], xmm15
00007986e0dd1273  sub rsp, 0x30
00007986e0dd1277  movaps [rsp], xmm1
00007986e0dd127b  movaps [rsp+0x10], xmm13
00007986e0dd1281  movaps [rsp+0x20], xmm2
00007986e0dd1286  lea rdi, [rsp]
00007986e0dd128a  mov esi, 0x00
00007986e0dd128f  mov rax, 0x5652C689F530
00007986e0dd1299  call rax
00007986e0dd129b  movaps xmm1, [rsp]
00007986e0dd129f  add rsp, 0x30
00007986e0dd12a3  vmovaps xmm0, [rsp]
00007986e0dd12a8  vmovaps xmm2, [rsp+0x10]
00007986e0dd12ae  vmovaps xmm3, [rsp+0x20]
00007986e0dd12b4  vmovaps xmm4, [rsp+0x30]
00007986e0dd12ba  vmovaps xmm5, [rsp+0x40]
00007986e0dd12c0  vmovaps xmm6, [rsp+0x50]
00007986e0dd12c6  vmovaps xmm7, [rsp+0x60]
00007986e0dd12cc  vmovaps xmm8, [rsp+0x70]
00007986e0dd12d2  vmovaps xmm9, [rsp+0x80]
00007986e0dd12db  vmovaps xmm10, [rsp+0x90]
00007986e0dd12e4  vmovaps xmm11, [rsp+0xA0]
00007986e0dd12ed  vmovaps xmm12, [rsp+0xB0]
00007986e0dd12f6  vmovaps xmm13, [rsp+0xC0]
00007986e0dd12ff  vmovaps xmm14, [rsp+0xD0]
00007986e0dd1308  vmovaps xmm15, [rsp+0xE0]
00007986e0dd1311  add rsp, 0xF0
00007986e0dd1318  pop r11
00007986e0dd131a  pop r10
00007986e0dd131c  pop r9
00007986e0dd131e  pop r8
00007986e0dd1320  pop rsi
00007986e0dd1321  pop rdi
00007986e0dd1322  pop rdx
00007986e0dd1323  pop rcx
00007986e0dd1324  pop rax
00007986e0dd1325  add rsp, 0x08
00007986e0dd1329  jmp 0x00007986E0DCF82C
00007986e0dd132e  call 0x00007986E0C0E760
00007986e0dd1333  jmp 0x00007986E0DCF839
00007986e0dd1338  sub rsp, 0x08
00007986e0dd133c  push rax
00007986e0dd133d  push rcx
00007986e0dd133e  push rdx
00007986e0dd133f  push rdi
00007986e0dd1340  push rsi
00007986e0dd1341  push r8
00007986e0dd1343  push r9
00007986e0dd1345  push r10
00007986e0dd1347  push r11
00007986e0dd1349  sub rsp, 0xF0
00007986e0dd1350  vmovaps [rsp], xmm0
00007986e0dd1355  vmovaps [rsp+0x10], xmm1
00007986e0dd135b  vmovaps [rsp+0x20], xmm2
00007986e0dd1361  vmovaps [rsp+0x30], xmm3
00007986e0dd1367  vmovaps [rsp+0x40], xmm4
00007986e0dd136d  vmovaps [rsp+0x50], xmm5
00007986e0dd1373  vmovaps [rsp+0x60], xmm6
00007986e0dd1379  vmovaps [rsp+0x70], xmm7
00007986e0dd137f  vmovaps [rsp+0x80], xmm8
00007986e0dd1388  vmovaps [rsp+0x90], xmm9
00007986e0dd1391  vmovaps [rsp+0xA0], xmm10
00007986e0dd139a  vmovaps [rsp+0xB0], xmm11
00007986e0dd13a3  vmovaps [rsp+0xC0], xmm12
00007986e0dd13ac  vmovaps [rsp+0xD0], xmm14
00007986e0dd13b5  vmovaps [rsp+0xE0], xmm15
00007986e0dd13be  sub rsp, 0x30
00007986e0dd13c2  movaps [rsp], xmm13
00007986e0dd13c7  movaps [rsp+0x10], xmm2
00007986e0dd13cc  movaps [rsp+0x20], xmm1
00007986e0dd13d1  lea rdi, [rsp]
00007986e0dd13d5  mov esi, 0x00
00007986e0dd13da  mov rax, 0x5652C689F530
00007986e0dd13e4  call rax
00007986e0dd13e6  movaps xmm13, [rsp]
00007986e0dd13eb  add rsp, 0x30
00007986e0dd13ef  vmovaps xmm0, [rsp]
00007986e0dd13f4  vmovaps xmm1, [rsp+0x10]
00007986e0dd13fa  vmovaps xmm2, [rsp+0x20]
00007986e0dd1400  vmovaps xmm3, [rsp+0x30]
00007986e0dd1406  vmovaps xmm4, [rsp+0x40]
00007986e0dd140c  vmovaps xmm5, [rsp+0x50]
00007986e0dd1412  vmovaps xmm6, [rsp+0x60]
00007986e0dd1418  vmovaps xmm7, [rsp+0x70]
00007986e0dd141e  vmovaps xmm8, [rsp+0x80]
00007986e0dd1427  vmovaps xmm9, [rsp+0x90]
00007986e0dd1430  vmovaps xmm10, [rsp+0xA0]
00007986e0dd1439  vmovaps xmm11, [rsp+0xB0]
00007986e0dd1442  vmovaps xmm12, [rsp+0xC0]
00007986e0dd144b  vmovaps xmm14, [rsp+0xD0]
00007986e0dd1454  vmovaps xmm15, [rsp+0xE0]
00007986e0dd145d  add rsp, 0xF0
00007986e0dd1464  pop r11
00007986e0dd1466  pop r10
00007986e0dd1468  pop r9
00007986e0dd146a  pop r8
00007986e0dd146c  pop rsi
00007986e0dd146d  pop rdi
00007986e0dd146e  pop rdx
00007986e0dd146f  pop rcx
00007986e0dd1470  pop rax
00007986e0dd1471  add rsp, 0x08
00007986e0dd1475  jmp 0x00007986E0DCF878
00007986e0dd147a  sub rsp, 0x08
00007986e0dd147e  push rax
00007986e0dd147f  push rcx
00007986e0dd1480  push rdx
00007986e0dd1481  push rdi
00007986e0dd1482  push rsi
00007986e0dd1483  push r8
00007986e0dd1485  push r9
00007986e0dd1487  push r10
00007986e0dd1489  push r11
00007986e0dd148b  sub rsp, 0xF0
00007986e0dd1492  vmovaps [rsp], xmm0
00007986e0dd1497  vmovaps [rsp+0x10], xmm2
00007986e0dd149d  vmovaps [rsp+0x20], xmm3
00007986e0dd14a3  vmovaps [rsp+0x30], xmm4
00007986e0dd14a9  vmovaps [rsp+0x40], xmm5
00007986e0dd14af  vmovaps [rsp+0x50], xmm6
00007986e0dd14b5  vmovaps [rsp+0x60], xmm7
00007986e0dd14bb  vmovaps [rsp+0x70], xmm8
00007986e0dd14c1  vmovaps [rsp+0x80], xmm9
00007986e0dd14ca  vmovaps [rsp+0x90], xmm10
00007986e0dd14d3  vmovaps [rsp+0xA0], xmm11
00007986e0dd14dc  vmovaps [rsp+0xB0], xmm12
00007986e0dd14e5  vmovaps [rsp+0xC0], xmm13
00007986e0dd14ee  vmovaps [rsp+0xD0], xmm14
00007986e0dd14f7  vmovaps [rsp+0xE0], xmm15
00007986e0dd1500  sub rsp, 0x30
00007986e0dd1504  movaps [rsp], xmm1
00007986e0dd1508  movaps [rsp+0x10], xmm15
00007986e0dd150e  movaps [rsp+0x20], xmm2
00007986e0dd1513  lea rdi, [rsp]
00007986e0dd1517  mov esi, 0x00
00007986e0dd151c  mov rax, 0x5652C689F530
00007986e0dd1526  call rax
00007986e0dd1528  movaps xmm1, [rsp]
00007986e0dd152c  add rsp, 0x30
00007986e0dd1530  vmovaps xmm0, [rsp]
00007986e0dd1535  vmovaps xmm2, [rsp+0x10]
00007986e0dd153b  vmovaps xmm3, [rsp+0x20]
00007986e0dd1541  vmovaps xmm4, [rsp+0x30]
00007986e0dd1547  vmovaps xmm5, [rsp+0x40]
00007986e0dd154d  vmovaps xmm6, [rsp+0x50]
00007986e0dd1553  vmovaps xmm7, [rsp+0x60]
00007986e0dd1559  vmovaps xmm8, [rsp+0x70]
00007986e0dd155f  vmovaps xmm9, [rsp+0x80]
00007986e0dd1568  vmovaps xmm10, [rsp+0x90]
00007986e0dd1571  vmovaps xmm11, [rsp+0xA0]
00007986e0dd157a  vmovaps xmm12, [rsp+0xB0]
00007986e0dd1583  vmovaps xmm13, [rsp+0xC0]
00007986e0dd158c  vmovaps xmm14, [rsp+0xD0]
00007986e0dd1595  vmovaps xmm15, [rsp+0xE0]
00007986e0dd159e  add rsp, 0xF0
00007986e0dd15a5  pop r11
00007986e0dd15a7  pop r10
00007986e0dd15a9  pop r9
00007986e0dd15ab  pop r8
00007986e0dd15ad  pop rsi
00007986e0dd15ae  pop rdi
00007986e0dd15af  pop rdx
00007986e0dd15b0  pop rcx
00007986e0dd15b1  pop rax
00007986e0dd15b2  add rsp, 0x08
00007986e0dd15b6  jmp 0x00007986E0DCF8AC
00007986e0dd15bb  sub rsp, 0x08
00007986e0dd15bf  push rax
00007986e0dd15c0  push rcx
00007986e0dd15c1  push rdx
00007986e0dd15c2  push rdi
00007986e0dd15c3  push rsi
00007986e0dd15c4  push r8
00007986e0dd15c6  push r9
00007986e0dd15c8  push r10
00007986e0dd15ca  push r11
00007986e0dd15cc  sub rsp, 0xF0
00007986e0dd15d3  vmovaps [rsp], xmm0
00007986e0dd15d8  vmovaps [rsp+0x10], xmm1
00007986e0dd15de  vmovaps [rsp+0x20], xmm2
00007986e0dd15e4  vmovaps [rsp+0x30], xmm3
00007986e0dd15ea  vmovaps [rsp+0x40], xmm4
00007986e0dd15f0  vmovaps [rsp+0x50], xmm5
00007986e0dd15f6  vmovaps [rsp+0x60], xmm6
00007986e0dd15fc  vmovaps [rsp+0x70], xmm7
00007986e0dd1602  vmovaps [rsp+0x80], xmm8
00007986e0dd160b  vmovaps [rsp+0x90], xmm9
00007986e0dd1614  vmovaps [rsp+0xA0], xmm10
00007986e0dd161d  vmovaps [rsp+0xB0], xmm11
00007986e0dd1626  vmovaps [rsp+0xC0], xmm12
00007986e0dd162f  vmovaps [rsp+0xD0], xmm13
00007986e0dd1638  vmovaps [rsp+0xE0], xmm15
00007986e0dd1641  sub rsp, 0x30
00007986e0dd1645  movaps [rsp], xmm14
00007986e0dd164a  movaps [rsp+0x10], xmm2
00007986e0dd164f  movaps [rsp+0x20], xmm15
00007986e0dd1655  lea rdi, [rsp]
00007986e0dd1659  mov esi, 0x00
00007986e0dd165e  mov rax, 0x5652C689F530
00007986e0dd1668  call rax
00007986e0dd166a  movaps xmm14, [rsp]
00007986e0dd166f  add rsp, 0x30
00007986e0dd1673  vmovaps xmm0, [rsp]
00007986e0dd1678  vmovaps xmm1, [rsp+0x10]
00007986e0dd167e  vmovaps xmm2, [rsp+0x20]
00007986e0dd1684  vmovaps xmm3, [rsp+0x30]
00007986e0dd168a  vmovaps xmm4, [rsp+0x40]
00007986e0dd1690  vmovaps xmm5, [rsp+0x50]
00007986e0dd1696  vmovaps xmm6, [rsp+0x60]
00007986e0dd169c  vmovaps xmm7, [rsp+0x70]
00007986e0dd16a2  vmovaps xmm8, [rsp+0x80]
00007986e0dd16ab  vmovaps xmm9, [rsp+0x90]
00007986e0dd16b4  vmovaps xmm10, [rsp+0xA0]
00007986e0dd16bd  vmovaps xmm11, [rsp+0xB0]
00007986e0dd16c6  vmovaps xmm12, [rsp+0xC0]
00007986e0dd16cf  vmovaps xmm13, [rsp+0xD0]
00007986e0dd16d8  vmovaps xmm15, [rsp+0xE0]
00007986e0dd16e1  add rsp, 0xF0
00007986e0dd16e8  pop r11
00007986e0dd16ea  pop r10
00007986e0dd16ec  pop r9
00007986e0dd16ee  pop r8
00007986e0dd16f0  pop rsi
00007986e0dd16f1  pop rdi
00007986e0dd16f2  pop rdx
00007986e0dd16f3  pop rcx
00007986e0dd16f4  pop rax
00007986e0dd16f5  add rsp, 0x08
00007986e0dd16f9  jmp 0x00007986E0DCF8E7
00007986e0dd16fe  sub rsp, 0x08
00007986e0dd1702  push rax
00007986e0dd1703  push rcx
00007986e0dd1704  push rdx
00007986e0dd1705  push rdi
00007986e0dd1706  push rsi
00007986e0dd1707  push r8
00007986e0dd1709  push r9
00007986e0dd170b  push r10
00007986e0dd170d  push r11
00007986e0dd170f  sub rsp, 0xF0
00007986e0dd1716  vmovaps [rsp], xmm0
00007986e0dd171b  vmovaps [rsp+0x10], xmm1
00007986e0dd1721  vmovaps [rsp+0x20], xmm2
00007986e0dd1727  vmovaps [rsp+0x30], xmm3
00007986e0dd172d  vmovaps [rsp+0x40], xmm4
00007986e0dd1733  vmovaps [rsp+0x50], xmm5
00007986e0dd1739  vmovaps [rsp+0x60], xmm6
00007986e0dd173f  vmovaps [rsp+0x70], xmm7
00007986e0dd1745  vmovaps [rsp+0x80], xmm8
00007986e0dd174e  vmovaps [rsp+0x90], xmm9
00007986e0dd1757  vmovaps [rsp+0xA0], xmm10
00007986e0dd1760  vmovaps [rsp+0xB0], xmm11
00007986e0dd1769  vmovaps [rsp+0xC0], xmm12
00007986e0dd1772  vmovaps [rsp+0xD0], xmm13
00007986e0dd177b  vmovaps [rsp+0xE0], xmm14
00007986e0dd1784  sub rsp, 0x30
00007986e0dd1788  movaps [rsp], xmm15
00007986e0dd178d  movaps [rsp+0x10], xmm2
00007986e0dd1792  movaps [rsp+0x20], xmm1
00007986e0dd1797  lea rdi, [rsp]
00007986e0dd179b  mov esi, 0x00
00007986e0dd17a0  mov rax, 0x5652C689F530
00007986e0dd17aa  call rax
00007986e0dd17ac  movaps xmm15, [rsp]
00007986e0dd17b1  add rsp, 0x30
00007986e0dd17b5  vmovaps xmm0, [rsp]
00007986e0dd17ba  vmovaps xmm1, [rsp+0x10]
00007986e0dd17c0  vmovaps xmm2, [rsp+0x20]
00007986e0dd17c6  vmovaps xmm3, [rsp+0x30]
00007986e0dd17cc  vmovaps xmm4, [rsp+0x40]
00007986e0dd17d2  vmovaps xmm5, [rsp+0x50]
00007986e0dd17d8  vmovaps xmm6, [rsp+0x60]
00007986e0dd17de  vmovaps xmm7, [rsp+0x70]
00007986e0dd17e4  vmovaps xmm8, [rsp+0x80]
00007986e0dd17ed  vmovaps xmm9, [rsp+0x90]
00007986e0dd17f6  vmovaps xmm10, [rsp+0xA0]
00007986e0dd17ff  vmovaps xmm11, [rsp+0xB0]
00007986e0dd1808  vmovaps xmm12, [rsp+0xC0]
00007986e0dd1811  vmovaps xmm13, [rsp+0xD0]
00007986e0dd181a  vmovaps xmm14, [rsp+0xE0]
00007986e0dd1823  add rsp, 0xF0
00007986e0dd182a  pop r11
00007986e0dd182c  pop r10
00007986e0dd182e  pop r9
00007986e0dd1830  pop r8
00007986e0dd1832  pop rsi
00007986e0dd1833  pop rdi
00007986e0dd1834  pop rdx
00007986e0dd1835  pop rcx
00007986e0dd1836  pop rax
00007986e0dd1837  add rsp, 0x08
00007986e0dd183b  jmp 0x00007986E0DCF923
00007986e0dd1840  call 0x00007986E0BFF430
00007986e0dd1845  jmp 0x00007986E0DCF930
00007986e0dd184a  sub rsp, 0x08
00007986e0dd184e  push rax
00007986e0dd184f  push rcx
00007986e0dd1850  push rdx
00007986e0dd1851  push rdi
00007986e0dd1852  push rsi
00007986e0dd1853  push r8
00007986e0dd1855  push r9
00007986e0dd1857  push r10
00007986e0dd1859  push r11
00007986e0dd185b  sub rsp, 0xF0
00007986e0dd1862  vmovaps [rsp], xmm0
00007986e0dd1867  vmovaps [rsp+0x10], xmm1
00007986e0dd186d  vmovaps [rsp+0x20], xmm3
00007986e0dd1873  vmovaps [rsp+0x30], xmm4
00007986e0dd1879  vmovaps [rsp+0x40], xmm5
00007986e0dd187f  vmovaps [rsp+0x50], xmm6
00007986e0dd1885  vmovaps [rsp+0x60], xmm7
00007986e0dd188b  vmovaps [rsp+0x70], xmm8
00007986e0dd1891  vmovaps [rsp+0x80], xmm9
00007986e0dd189a  vmovaps [rsp+0x90], xmm10
00007986e0dd18a3  vmovaps [rsp+0xA0], xmm11
00007986e0dd18ac  vmovaps [rsp+0xB0], xmm12
00007986e0dd18b5  vmovaps [rsp+0xC0], xmm13
00007986e0dd18be  vmovaps [rsp+0xD0], xmm14
00007986e0dd18c7  vmovaps [rsp+0xE0], xmm15
00007986e0dd18d0  sub rsp, 0x30
00007986e0dd18d4  movaps [rsp], xmm2
00007986e0dd18d8  movaps [rsp+0x10], xmm1
00007986e0dd18dd  movaps [rsp+0x20], xmm14
00007986e0dd18e3  lea rdi, [rsp]
00007986e0dd18e7  mov esi, 0x00
00007986e0dd18ec  mov rax, 0x5652C689F530
00007986e0dd18f6  call rax
00007986e0dd18f8  movaps xmm2, [rsp]
00007986e0dd18fc  add rsp, 0x30
00007986e0dd1900  vmovaps xmm0, [rsp]
00007986e0dd1905  vmovaps xmm1, [rsp+0x10]
00007986e0dd190b  vmovaps xmm3, [rsp+0x20]
00007986e0dd1911  vmovaps xmm4, [rsp+0x30]
00007986e0dd1917  vmovaps xmm5, [rsp+0x40]
00007986e0dd191d  vmovaps xmm6, [rsp+0x50]
00007986e0dd1923  vmovaps xmm7, [rsp+0x60]
00007986e0dd1929  vmovaps xmm8, [rsp+0x70]
00007986e0dd192f  vmovaps xmm9, [rsp+0x80]
00007986e0dd1938  vmovaps xmm10, [rsp+0x90]
00007986e0dd1941  vmovaps xmm11, [rsp+0xA0]
00007986e0dd194a  vmovaps xmm12, [rsp+0xB0]
00007986e0dd1953  vmovaps xmm13, [rsp+0xC0]
00007986e0dd195c  vmovaps xmm14, [rsp+0xD0]
00007986e0dd1965  vmovaps xmm15, [rsp+0xE0]
00007986e0dd196e  add rsp, 0xF0
00007986e0dd1975  pop r11
00007986e0dd1977  pop r10
00007986e0dd1979  pop r9
00007986e0dd197b  pop r8
00007986e0dd197d  pop rsi
00007986e0dd197e  pop rdi
00007986e0dd197f  pop rdx
00007986e0dd1980  pop rcx
00007986e0dd1981  pop rax
00007986e0dd1982  add rsp, 0x08
00007986e0dd1986  jmp 0x00007986E0DCF96D
00007986e0dd198b  sub rsp, 0x08
00007986e0dd198f  push rax
00007986e0dd1990  push rcx
00007986e0dd1991  push rdx
00007986e0dd1992  push rdi
00007986e0dd1993  push rsi
00007986e0dd1994  push r8
00007986e0dd1996  push r9
00007986e0dd1998  push r10
00007986e0dd199a  push r11
00007986e0dd199c  sub rsp, 0xF0
00007986e0dd19a3  vmovaps [rsp], xmm0
00007986e0dd19a8  vmovaps [rsp+0x10], xmm1
00007986e0dd19ae  vmovaps [rsp+0x20], xmm2
00007986e0dd19b4  vmovaps [rsp+0x30], xmm3
00007986e0dd19ba  vmovaps [rsp+0x40], xmm4
00007986e0dd19c0  vmovaps [rsp+0x50], xmm5
00007986e0dd19c6  vmovaps [rsp+0x60], xmm6
00007986e0dd19cc  vmovaps [rsp+0x70], xmm7
00007986e0dd19d2  vmovaps [rsp+0x80], xmm8
00007986e0dd19db  vmovaps [rsp+0x90], xmm9
00007986e0dd19e4  vmovaps [rsp+0xA0], xmm10
00007986e0dd19ed  vmovaps [rsp+0xB0], xmm11
00007986e0dd19f6  vmovaps [rsp+0xC0], xmm12
00007986e0dd19ff  vmovaps [rsp+0xD0], xmm13
00007986e0dd1a08  vmovaps [rsp+0xE0], xmm14
00007986e0dd1a11  sub rsp, 0x30
00007986e0dd1a15  movaps [rsp], xmm15
00007986e0dd1a1a  movaps [rsp+0x10], xmm14
00007986e0dd1a20  movaps [rsp+0x20], xmm1
00007986e0dd1a25  lea rdi, [rsp]
00007986e0dd1a29  mov esi, 0x00
00007986e0dd1a2e  mov rax, 0x5652C689F530
00007986e0dd1a38  call rax
00007986e0dd1a3a  movaps xmm15, [rsp]
00007986e0dd1a3f  add rsp, 0x30
00007986e0dd1a43  vmovaps xmm0, [rsp]
00007986e0dd1a48  vmovaps xmm1, [rsp+0x10]
00007986e0dd1a4e  vmovaps xmm2, [rsp+0x20]
00007986e0dd1a54  vmovaps xmm3, [rsp+0x30]
00007986e0dd1a5a  vmovaps xmm4, [rsp+0x40]
00007986e0dd1a60  vmovaps xmm5, [rsp+0x50]
00007986e0dd1a66  vmovaps xmm6, [rsp+0x60]
00007986e0dd1a6c  vmovaps xmm7, [rsp+0x70]
00007986e0dd1a72  vmovaps xmm8, [rsp+0x80]
00007986e0dd1a7b  vmovaps xmm9, [rsp+0x90]
00007986e0dd1a84  vmovaps xmm10, [rsp+0xA0]
00007986e0dd1a8d  vmovaps xmm11, [rsp+0xB0]
00007986e0dd1a96  vmovaps xmm12, [rsp+0xC0]
00007986e0dd1a9f  vmovaps xmm13, [rsp+0xD0]
00007986e0dd1aa8  vmovaps xmm14, [rsp+0xE0]
00007986e0dd1ab1  add rsp, 0xF0
00007986e0dd1ab8  pop r11
00007986e0dd1aba  pop r10
00007986e0dd1abc  pop r9
00007986e0dd1abe  pop r8
00007986e0dd1ac0  pop rsi
00007986e0dd1ac1  pop rdi
00007986e0dd1ac2  pop rdx
00007986e0dd1ac3  pop rcx
00007986e0dd1ac4  pop rax
00007986e0dd1ac5  add rsp, 0x08
00007986e0dd1ac9  jmp 0x00007986E0DCF9E7
00007986e0dd1ace  call 0x00007986E0BFF430
00007986e0dd1ad3  jmp 0x00007986E0DCF9F4
00007986e0dd1ad8  sub rsp, 0x08
00007986e0dd1adc  push rax
00007986e0dd1add  push rcx
00007986e0dd1ade  push rdx
00007986e0dd1adf  push rdi
00007986e0dd1ae0  push rsi
00007986e0dd1ae1  push r8
00007986e0dd1ae3  push r9
00007986e0dd1ae5  push r10
00007986e0dd1ae7  push r11
00007986e0dd1ae9  sub rsp, 0xF0
00007986e0dd1af0  vmovaps [rsp], xmm0
00007986e0dd1af5  vmovaps [rsp+0x10], xmm1
00007986e0dd1afb  vmovaps [rsp+0x20], xmm2
00007986e0dd1b01  vmovaps [rsp+0x30], xmm3
00007986e0dd1b07  vmovaps [rsp+0x40], xmm4
00007986e0dd1b0d  vmovaps [rsp+0x50], xmm5
00007986e0dd1b13  vmovaps [rsp+0x60], xmm6
00007986e0dd1b19  vmovaps [rsp+0x70], xmm7
00007986e0dd1b1f  vmovaps [rsp+0x80], xmm8
00007986e0dd1b28  vmovaps [rsp+0x90], xmm9
00007986e0dd1b31  vmovaps [rsp+0xA0], xmm10
00007986e0dd1b3a  vmovaps [rsp+0xB0], xmm11
00007986e0dd1b43  vmovaps [rsp+0xC0], xmm12
00007986e0dd1b4c  vmovaps [rsp+0xD0], xmm13
00007986e0dd1b55  vmovaps [rsp+0xE0], xmm15
00007986e0dd1b5e  sub rsp, 0x30
00007986e0dd1b62  movaps [rsp], xmm14
00007986e0dd1b67  movaps [rsp+0x10], xmm13
00007986e0dd1b6d  movaps [rsp+0x20], xmm1
00007986e0dd1b72  lea rdi, [rsp]
00007986e0dd1b76  mov esi, 0x00
00007986e0dd1b7b  mov rax, 0x5652C689F530
00007986e0dd1b85  call rax
00007986e0dd1b87  movaps xmm14, [rsp]
00007986e0dd1b8c  add rsp, 0x30
00007986e0dd1b90  vmovaps xmm0, [rsp]
00007986e0dd1b95  vmovaps xmm1, [rsp+0x10]
00007986e0dd1b9b  vmovaps xmm2, [rsp+0x20]
00007986e0dd1ba1  vmovaps xmm3, [rsp+0x30]
00007986e0dd1ba7  vmovaps xmm4, [rsp+0x40]
00007986e0dd1bad  vmovaps xmm5, [rsp+0x50]
00007986e0dd1bb3  vmovaps xmm6, [rsp+0x60]
00007986e0dd1bb9  vmovaps xmm7, [rsp+0x70]
00007986e0dd1bbf  vmovaps xmm8, [rsp+0x80]
00007986e0dd1bc8  vmovaps xmm9, [rsp+0x90]
00007986e0dd1bd1  vmovaps xmm10, [rsp+0xA0]
00007986e0dd1bda  vmovaps xmm11, [rsp+0xB0]
00007986e0dd1be3  vmovaps xmm12, [rsp+0xC0]
00007986e0dd1bec  vmovaps xmm13, [rsp+0xD0]
00007986e0dd1bf5  vmovaps xmm15, [rsp+0xE0]
00007986e0dd1bfe  add rsp, 0xF0
00007986e0dd1c05  pop r11
00007986e0dd1c07  pop r10
00007986e0dd1c09  pop r9
00007986e0dd1c0b  pop r8
00007986e0dd1c0d  pop rsi
00007986e0dd1c0e  pop rdi
00007986e0dd1c0f  pop rdx
00007986e0dd1c10  pop rcx
00007986e0dd1c11  pop rax
00007986e0dd1c12  add rsp, 0x08
00007986e0dd1c16  jmp 0x00007986E0DCFAAF
00007986e0dd1c1b  sub rsp, 0x08
00007986e0dd1c1f  push rax
00007986e0dd1c20  push rcx
00007986e0dd1c21  push rdx
00007986e0dd1c22  push rdi
00007986e0dd1c23  push rsi
00007986e0dd1c24  push r8
00007986e0dd1c26  push r9
00007986e0dd1c28  push r10
00007986e0dd1c2a  push r11
00007986e0dd1c2c  sub rsp, 0xF0
00007986e0dd1c33  vmovaps [rsp], xmm0
00007986e0dd1c38  vmovaps [rsp+0x10], xmm1
00007986e0dd1c3e  vmovaps [rsp+0x20], xmm2
00007986e0dd1c44  vmovaps [rsp+0x30], xmm3
00007986e0dd1c4a  vmovaps [rsp+0x40], xmm4
00007986e0dd1c50  vmovaps [rsp+0x50], xmm5
00007986e0dd1c56  vmovaps [rsp+0x60], xmm6
00007986e0dd1c5c  vmovaps [rsp+0x70], xmm7
00007986e0dd1c62  vmovaps [rsp+0x80], xmm8
00007986e0dd1c6b  vmovaps [rsp+0x90], xmm9
00007986e0dd1c74  vmovaps [rsp+0xA0], xmm10
00007986e0dd1c7d  vmovaps [rsp+0xB0], xmm11
00007986e0dd1c86  vmovaps [rsp+0xC0], xmm12
00007986e0dd1c8f  vmovaps [rsp+0xD0], xmm13
00007986e0dd1c98  vmovaps [rsp+0xE0], xmm14
00007986e0dd1ca1  sub rsp, 0x30
00007986e0dd1ca5  movaps [rsp], xmm15
00007986e0dd1caa  movaps [rsp+0x10], xmm13
00007986e0dd1cb0  movaps [rsp+0x20], xmm1
00007986e0dd1cb5  lea rdi, [rsp]
00007986e0dd1cb9  mov esi, 0x00
00007986e0dd1cbe  mov rax, 0x5652C689F530
00007986e0dd1cc8  call rax
00007986e0dd1cca  movaps xmm15, [rsp]
00007986e0dd1ccf  add rsp, 0x30
00007986e0dd1cd3  vmovaps xmm0, [rsp]
00007986e0dd1cd8  vmovaps xmm1, [rsp+0x10]
00007986e0dd1cde  vmovaps xmm2, [rsp+0x20]
00007986e0dd1ce4  vmovaps xmm3, [rsp+0x30]
00007986e0dd1cea  vmovaps xmm4, [rsp+0x40]
00007986e0dd1cf0  vmovaps xmm5, [rsp+0x50]
00007986e0dd1cf6  vmovaps xmm6, [rsp+0x60]
00007986e0dd1cfc  vmovaps xmm7, [rsp+0x70]
00007986e0dd1d02  vmovaps xmm8, [rsp+0x80]
00007986e0dd1d0b  vmovaps xmm9, [rsp+0x90]
00007986e0dd1d14  vmovaps xmm10, [rsp+0xA0]
00007986e0dd1d1d  vmovaps xmm11, [rsp+0xB0]
00007986e0dd1d26  vmovaps xmm12, [rsp+0xC0]
00007986e0dd1d2f  vmovaps xmm13, [rsp+0xD0]
00007986e0dd1d38  vmovaps xmm14, [rsp+0xE0]
00007986e0dd1d41  add rsp, 0xF0
00007986e0dd1d48  pop r11
00007986e0dd1d4a  pop r10
00007986e0dd1d4c  pop r9
00007986e0dd1d4e  pop r8
00007986e0dd1d50  pop rsi
00007986e0dd1d51  pop rdi
00007986e0dd1d52  pop rdx
00007986e0dd1d53  pop rcx
00007986e0dd1d54  pop rax
00007986e0dd1d55  add rsp, 0x08
00007986e0dd1d59  jmp 0x00007986E0DCFAEB
00007986e0dd1d5e  call 0x00007986E0BFF430
00007986e0dd1d63  jmp 0x00007986E0DCFAF8
00007986e0dd1d68  sub rsp, 0x08
00007986e0dd1d6c  push rax
00007986e0dd1d6d  push rcx
00007986e0dd1d6e  push rdx
00007986e0dd1d6f  push rdi
00007986e0dd1d70  push rsi
00007986e0dd1d71  push r8
00007986e0dd1d73  push r9
00007986e0dd1d75  push r10
00007986e0dd1d77  push r11
00007986e0dd1d79  sub rsp, 0xF0
00007986e0dd1d80  vmovaps [rsp], xmm0
00007986e0dd1d85  vmovaps [rsp+0x10], xmm1
00007986e0dd1d8b  vmovaps [rsp+0x20], xmm2
00007986e0dd1d91  vmovaps [rsp+0x30], xmm3
00007986e0dd1d97  vmovaps [rsp+0x40], xmm4
00007986e0dd1d9d  vmovaps [rsp+0x50], xmm5
00007986e0dd1da3  vmovaps [rsp+0x60], xmm6
00007986e0dd1da9  vmovaps [rsp+0x70], xmm7
00007986e0dd1daf  vmovaps [rsp+0x80], xmm8
00007986e0dd1db8  vmovaps [rsp+0x90], xmm9
00007986e0dd1dc1  vmovaps [rsp+0xA0], xmm10
00007986e0dd1dca  vmovaps [rsp+0xB0], xmm11
00007986e0dd1dd3  vmovaps [rsp+0xC0], xmm12
00007986e0dd1ddc  vmovaps [rsp+0xD0], xmm13
00007986e0dd1de5  vmovaps [rsp+0xE0], xmm15
00007986e0dd1dee  sub rsp, 0x30
00007986e0dd1df2  movaps [rsp], xmm14
00007986e0dd1df7  movaps [rsp+0x10], xmm13
00007986e0dd1dfd  movaps [rsp+0x20], xmm2
00007986e0dd1e02  lea rdi, [rsp]
00007986e0dd1e06  mov esi, 0x00
00007986e0dd1e0b  mov rax, 0x5652C689F530
00007986e0dd1e15  call rax
00007986e0dd1e17  movaps xmm14, [rsp]
00007986e0dd1e1c  add rsp, 0x30
00007986e0dd1e20  vmovaps xmm0, [rsp]
00007986e0dd1e25  vmovaps xmm1, [rsp+0x10]
00007986e0dd1e2b  vmovaps xmm2, [rsp+0x20]
00007986e0dd1e31  vmovaps xmm3, [rsp+0x30]
00007986e0dd1e37  vmovaps xmm4, [rsp+0x40]
00007986e0dd1e3d  vmovaps xmm5, [rsp+0x50]
00007986e0dd1e43  vmovaps xmm6, [rsp+0x60]
00007986e0dd1e49  vmovaps xmm7, [rsp+0x70]
00007986e0dd1e4f  vmovaps xmm8, [rsp+0x80]
00007986e0dd1e58  vmovaps xmm9, [rsp+0x90]
00007986e0dd1e61  vmovaps xmm10, [rsp+0xA0]
00007986e0dd1e6a  vmovaps xmm11, [rsp+0xB0]
00007986e0dd1e73  vmovaps xmm12, [rsp+0xC0]
00007986e0dd1e7c  vmovaps xmm13, [rsp+0xD0]
00007986e0dd1e85  vmovaps xmm15, [rsp+0xE0]
00007986e0dd1e8e  add rsp, 0xF0
00007986e0dd1e95  pop r11
00007986e0dd1e97  pop r10
00007986e0dd1e99  pop r9
00007986e0dd1e9b  pop r8
00007986e0dd1e9d  pop rsi
00007986e0dd1e9e  pop rdi
00007986e0dd1e9f  pop rdx
00007986e0dd1ea0  pop rcx
00007986e0dd1ea1  pop rax
00007986e0dd1ea2  add rsp, 0x08
00007986e0dd1ea6  jmp 0x00007986E0DCFB24
00007986e0dd1eab  sub rsp, 0x08
00007986e0dd1eaf  push rax
00007986e0dd1eb0  push rcx
00007986e0dd1eb1  push rdx
00007986e0dd1eb2  push rdi
00007986e0dd1eb3  push rsi
00007986e0dd1eb4  push r8
00007986e0dd1eb6  push r9
00007986e0dd1eb8  push r10
00007986e0dd1eba  push r11
00007986e0dd1ebc  sub rsp, 0xF0
00007986e0dd1ec3  vmovaps [rsp], xmm0
00007986e0dd1ec8  vmovaps [rsp+0x10], xmm2
00007986e0dd1ece  vmovaps [rsp+0x20], xmm3
00007986e0dd1ed4  vmovaps [rsp+0x30], xmm4
00007986e0dd1eda  vmovaps [rsp+0x40], xmm5
00007986e0dd1ee0  vmovaps [rsp+0x50], xmm6
00007986e0dd1ee6  vmovaps [rsp+0x60], xmm7
00007986e0dd1eec  vmovaps [rsp+0x70], xmm8
00007986e0dd1ef2  vmovaps [rsp+0x80], xmm9
00007986e0dd1efb  vmovaps [rsp+0x90], xmm10
00007986e0dd1f04  vmovaps [rsp+0xA0], xmm11
00007986e0dd1f0d  vmovaps [rsp+0xB0], xmm12
00007986e0dd1f16  vmovaps [rsp+0xC0], xmm13
00007986e0dd1f1f  vmovaps [rsp+0xD0], xmm14
00007986e0dd1f28  vmovaps [rsp+0xE0], xmm15
00007986e0dd1f31  sub rsp, 0x30
00007986e0dd1f35  movaps [rsp], xmm1
00007986e0dd1f39  movaps [rsp+0x10], xmm13
00007986e0dd1f3f  movaps [rsp+0x20], xmm2
00007986e0dd1f44  lea rdi, [rsp]
00007986e0dd1f48  mov esi, 0x00
00007986e0dd1f4d  mov rax, 0x5652C689F530
00007986e0dd1f57  call rax
00007986e0dd1f59  movaps xmm1, [rsp]
00007986e0dd1f5d  add rsp, 0x30
00007986e0dd1f61  vmovaps xmm0, [rsp]
00007986e0dd1f66  vmovaps xmm2, [rsp+0x10]
00007986e0dd1f6c  vmovaps xmm3, [rsp+0x20]
00007986e0dd1f72  vmovaps xmm4, [rsp+0x30]
00007986e0dd1f78  vmovaps xmm5, [rsp+0x40]
00007986e0dd1f7e  vmovaps xmm6, [rsp+0x50]
00007986e0dd1f84  vmovaps xmm7, [rsp+0x60]
00007986e0dd1f8a  vmovaps xmm8, [rsp+0x70]
00007986e0dd1f90  vmovaps xmm9, [rsp+0x80]
00007986e0dd1f99  vmovaps xmm10, [rsp+0x90]
00007986e0dd1fa2  vmovaps xmm11, [rsp+0xA0]
00007986e0dd1fab  vmovaps xmm12, [rsp+0xB0]
00007986e0dd1fb4  vmovaps xmm13, [rsp+0xC0]
00007986e0dd1fbd  vmovaps xmm14, [rsp+0xD0]
00007986e0dd1fc6  vmovaps xmm15, [rsp+0xE0]
00007986e0dd1fcf  add rsp, 0xF0
00007986e0dd1fd6  pop r11
00007986e0dd1fd8  pop r10
00007986e0dd1fda  pop r9
00007986e0dd1fdc  pop r8
00007986e0dd1fde  pop rsi
00007986e0dd1fdf  pop rdi
00007986e0dd1fe0  pop rdx
00007986e0dd1fe1  pop rcx
00007986e0dd1fe2  pop rax
00007986e0dd1fe3  add rsp, 0x08
00007986e0dd1fe7  jmp 0x00007986E0DCFB52
00007986e0dd1fec  sub rsp, 0x08
00007986e0dd1ff0  push rax
00007986e0dd1ff1  push rcx
00007986e0dd1ff2  push rdx
00007986e0dd1ff3  push rdi
00007986e0dd1ff4  push rsi
00007986e0dd1ff5  push r8
00007986e0dd1ff7  push r9
00007986e0dd1ff9  push r10
00007986e0dd1ffb  push r11
00007986e0dd1ffd  sub rsp, 0xF0
00007986e0dd2004  vmovaps [rsp], xmm0
00007986e0dd2009  vmovaps [rsp+0x10], xmm1
00007986e0dd200f  vmovaps [rsp+0x20], xmm3
00007986e0dd2015  vmovaps [rsp+0x30], xmm4
00007986e0dd201b  vmovaps [rsp+0x40], xmm5
00007986e0dd2021  vmovaps [rsp+0x50], xmm6
00007986e0dd2027  vmovaps [rsp+0x60], xmm7
00007986e0dd202d  vmovaps [rsp+0x70], xmm8
00007986e0dd2033  vmovaps [rsp+0x80], xmm9
00007986e0dd203c  vmovaps [rsp+0x90], xmm10
00007986e0dd2045  vmovaps [rsp+0xA0], xmm11
00007986e0dd204e  vmovaps [rsp+0xB0], xmm12
00007986e0dd2057  vmovaps [rsp+0xC0], xmm13
00007986e0dd2060  vmovaps [rsp+0xD0], xmm14
00007986e0dd2069  vmovaps [rsp+0xE0], xmm15
00007986e0dd2072  sub rsp, 0x30
00007986e0dd2076  movaps [rsp], xmm2
00007986e0dd207a  movaps [rsp+0x10], xmm1
00007986e0dd207f  movaps [rsp+0x20], xmm13
00007986e0dd2085  lea rdi, [rsp]
00007986e0dd2089  mov esi, 0x00
00007986e0dd208e  mov rax, 0x5652C689F530
00007986e0dd2098  call rax
00007986e0dd209a  movaps xmm2, [rsp]
00007986e0dd209e  add rsp, 0x30
00007986e0dd20a2  vmovaps xmm0, [rsp]
00007986e0dd20a7  vmovaps xmm1, [rsp+0x10]
00007986e0dd20ad  vmovaps xmm3, [rsp+0x20]
00007986e0dd20b3  vmovaps xmm4, [rsp+0x30]
00007986e0dd20b9  vmovaps xmm5, [rsp+0x40]
00007986e0dd20bf  vmovaps xmm6, [rsp+0x50]
00007986e0dd20c5  vmovaps xmm7, [rsp+0x60]
00007986e0dd20cb  vmovaps xmm8, [rsp+0x70]
00007986e0dd20d1  vmovaps xmm9, [rsp+0x80]
00007986e0dd20da  vmovaps xmm10, [rsp+0x90]
00007986e0dd20e3  vmovaps xmm11, [rsp+0xA0]
00007986e0dd20ec  vmovaps xmm12, [rsp+0xB0]
00007986e0dd20f5  vmovaps xmm13, [rsp+0xC0]
00007986e0dd20fe  vmovaps xmm14, [rsp+0xD0]
00007986e0dd2107  vmovaps xmm15, [rsp+0xE0]
00007986e0dd2110  add rsp, 0xF0
00007986e0dd2117  pop r11
00007986e0dd2119  pop r10
00007986e0dd211b  pop r9
00007986e0dd211d  pop r8
00007986e0dd211f  pop rsi
00007986e0dd2120  pop rdi
00007986e0dd2121  pop rdx
00007986e0dd2122  pop rcx
00007986e0dd2123  pop rax
00007986e0dd2124  add rsp, 0x08
00007986e0dd2128  jmp 0x00007986E0DCFBAB
00007986e0dd212d  call 0x00007986E0BFF430
00007986e0dd2132  jmp 0x00007986E0DCFBB8
00007986e0dd2137  sub rsp, 0x08
00007986e0dd213b  push rax
00007986e0dd213c  push rcx
00007986e0dd213d  push rdx
00007986e0dd213e  push rdi
00007986e0dd213f  push rsi
00007986e0dd2140  push r8
00007986e0dd2142  push r9
00007986e0dd2144  push r10
00007986e0dd2146  push r11
00007986e0dd2148  sub rsp, 0xF0
00007986e0dd214f  vmovaps [rsp], xmm0
00007986e0dd2154  vmovaps [rsp+0x10], xmm1
00007986e0dd215a  vmovaps [rsp+0x20], xmm2
00007986e0dd2160  vmovaps [rsp+0x30], xmm3
00007986e0dd2166  vmovaps [rsp+0x40], xmm4
00007986e0dd216c  vmovaps [rsp+0x50], xmm5
00007986e0dd2172  vmovaps [rsp+0x60], xmm6
00007986e0dd2178  vmovaps [rsp+0x70], xmm7
00007986e0dd217e  vmovaps [rsp+0x80], xmm8
00007986e0dd2187  vmovaps [rsp+0x90], xmm9
00007986e0dd2190  vmovaps [rsp+0xA0], xmm10
00007986e0dd2199  vmovaps [rsp+0xB0], xmm11
00007986e0dd21a2  vmovaps [rsp+0xC0], xmm12
00007986e0dd21ab  vmovaps [rsp+0xD0], xmm13
00007986e0dd21b4  vmovaps [rsp+0xE0], xmm14
00007986e0dd21bd  sub rsp, 0x30
00007986e0dd21c1  movaps [rsp], xmm15
00007986e0dd21c6  movaps [rsp+0x10], xmm13
00007986e0dd21cc  movaps [rsp+0x20], xmm1
00007986e0dd21d1  lea rdi, [rsp]
00007986e0dd21d5  mov esi, 0x00
00007986e0dd21da  mov rax, 0x5652C689F530
00007986e0dd21e4  call rax
00007986e0dd21e6  movaps xmm15, [rsp]
00007986e0dd21eb  add rsp, 0x30
00007986e0dd21ef  vmovaps xmm0, [rsp]
00007986e0dd21f4  vmovaps xmm1, [rsp+0x10]
00007986e0dd21fa  vmovaps xmm2, [rsp+0x20]
00007986e0dd2200  vmovaps xmm3, [rsp+0x30]
00007986e0dd2206  vmovaps xmm4, [rsp+0x40]
00007986e0dd220c  vmovaps xmm5, [rsp+0x50]
00007986e0dd2212  vmovaps xmm6, [rsp+0x60]
00007986e0dd2218  vmovaps xmm7, [rsp+0x70]
00007986e0dd221e  vmovaps xmm8, [rsp+0x80]
00007986e0dd2227  vmovaps xmm9, [rsp+0x90]
00007986e0dd2230  vmovaps xmm10, [rsp+0xA0]
00007986e0dd2239  vmovaps xmm11, [rsp+0xB0]
00007986e0dd2242  vmovaps xmm12, [rsp+0xC0]
00007986e0dd224b  vmovaps xmm13, [rsp+0xD0]
00007986e0dd2254  vmovaps xmm14, [rsp+0xE0]
00007986e0dd225d  add rsp, 0xF0
00007986e0dd2264  pop r11
00007986e0dd2266  pop r10
00007986e0dd2268  pop r9
00007986e0dd226a  pop r8
00007986e0dd226c  pop rsi
00007986e0dd226d  pop rdi
00007986e0dd226e  pop rdx
00007986e0dd226f  pop rcx
00007986e0dd2270  pop rax
00007986e0dd2271  add rsp, 0x08
00007986e0dd2275  jmp 0x00007986E0DCFBF7
00007986e0dd227a  sub rsp, 0x08
00007986e0dd227e  push rax
00007986e0dd227f  push rcx
00007986e0dd2280  push rdx
00007986e0dd2281  push rdi
00007986e0dd2282  push rsi
00007986e0dd2283  push r8
00007986e0dd2285  push r9
00007986e0dd2287  push r10
00007986e0dd2289  push r11
00007986e0dd228b  sub rsp, 0xF0
00007986e0dd2292  vmovaps [rsp], xmm0
00007986e0dd2297  vmovaps [rsp+0x10], xmm1
00007986e0dd229d  vmovaps [rsp+0x20], xmm2
00007986e0dd22a3  vmovaps [rsp+0x30], xmm3
00007986e0dd22a9  vmovaps [rsp+0x40], xmm4
00007986e0dd22af  vmovaps [rsp+0x50], xmm5
00007986e0dd22b5  vmovaps [rsp+0x60], xmm6
00007986e0dd22bb  vmovaps [rsp+0x70], xmm7
00007986e0dd22c1  vmovaps [rsp+0x80], xmm8
00007986e0dd22ca  vmovaps [rsp+0x90], xmm9
00007986e0dd22d3  vmovaps [rsp+0xA0], xmm10
00007986e0dd22dc  vmovaps [rsp+0xB0], xmm11
00007986e0dd22e5  vmovaps [rsp+0xC0], xmm12
00007986e0dd22ee  vmovaps [rsp+0xD0], xmm13
00007986e0dd22f7  vmovaps [rsp+0xE0], xmm15
00007986e0dd2300  sub rsp, 0x30
00007986e0dd2304  movaps [rsp], xmm14
00007986e0dd2309  movaps [rsp+0x10], xmm11
00007986e0dd230f  movaps [rsp+0x20], xmm1
00007986e0dd2314  lea rdi, [rsp]
00007986e0dd2318  mov esi, 0x00
00007986e0dd231d  mov rax, 0x5652C689F530
00007986e0dd2327  call rax
00007986e0dd2329  movaps xmm14, [rsp]
00007986e0dd232e  add rsp, 0x30
00007986e0dd2332  vmovaps xmm0, [rsp]
00007986e0dd2337  vmovaps xmm1, [rsp+0x10]
00007986e0dd233d  vmovaps xmm2, [rsp+0x20]
00007986e0dd2343  vmovaps xmm3, [rsp+0x30]
00007986e0dd2349  vmovaps xmm4, [rsp+0x40]
00007986e0dd234f  vmovaps xmm5, [rsp+0x50]
00007986e0dd2355  vmovaps xmm6, [rsp+0x60]
00007986e0dd235b  vmovaps xmm7, [rsp+0x70]
00007986e0dd2361  vmovaps xmm8, [rsp+0x80]
00007986e0dd236a  vmovaps xmm9, [rsp+0x90]
00007986e0dd2373  vmovaps xmm10, [rsp+0xA0]
00007986e0dd237c  vmovaps xmm11, [rsp+0xB0]
00007986e0dd2385  vmovaps xmm12, [rsp+0xC0]
00007986e0dd238e  vmovaps xmm13, [rsp+0xD0]
00007986e0dd2397  vmovaps xmm15, [rsp+0xE0]
00007986e0dd23a0  add rsp, 0xF0
00007986e0dd23a7  pop r11
00007986e0dd23a9  pop r10
00007986e0dd23ab  pop r9
00007986e0dd23ad  pop r8
00007986e0dd23af  pop rsi
00007986e0dd23b0  pop rdi
00007986e0dd23b1  pop rdx
00007986e0dd23b2  pop rcx
00007986e0dd23b3  pop rax
00007986e0dd23b4  add rsp, 0x08
00007986e0dd23b8  jmp 0x00007986E0DCFC21
00007986e0dd23bd  sub rsp, 0x08
00007986e0dd23c1  push rax
00007986e0dd23c2  push rcx
00007986e0dd23c3  push rdx
00007986e0dd23c4  push rdi
00007986e0dd23c5  push rsi
00007986e0dd23c6  push r8
00007986e0dd23c8  push r9
00007986e0dd23ca  push r10
00007986e0dd23cc  push r11
00007986e0dd23ce  sub rsp, 0xF0
00007986e0dd23d5  vmovaps [rsp], xmm0
00007986e0dd23da  vmovaps [rsp+0x10], xmm1
00007986e0dd23e0  vmovaps [rsp+0x20], xmm2
00007986e0dd23e6  vmovaps [rsp+0x30], xmm3
00007986e0dd23ec  vmovaps [rsp+0x40], xmm4
00007986e0dd23f2  vmovaps [rsp+0x50], xmm5
00007986e0dd23f8  vmovaps [rsp+0x60], xmm6
00007986e0dd23fe  vmovaps [rsp+0x70], xmm7
00007986e0dd2404  vmovaps [rsp+0x80], xmm8
00007986e0dd240d  vmovaps [rsp+0x90], xmm9
00007986e0dd2416  vmovaps [rsp+0xA0], xmm10
00007986e0dd241f  vmovaps [rsp+0xB0], xmm11
00007986e0dd2428  vmovaps [rsp+0xC0], xmm12
00007986e0dd2431  vmovaps [rsp+0xD0], xmm14
00007986e0dd243a  vmovaps [rsp+0xE0], xmm15
00007986e0dd2443  sub rsp, 0x30
00007986e0dd2447  movaps [rsp], xmm13
00007986e0dd244c  movaps [rsp+0x10], xmm11
00007986e0dd2452  movaps [rsp+0x20], xmm1
00007986e0dd2457  lea rdi, [rsp]
00007986e0dd245b  mov esi, 0x00
00007986e0dd2460  mov rax, 0x5652C689F530
00007986e0dd246a  call rax
00007986e0dd246c  movaps xmm13, [rsp]
00007986e0dd2471  add rsp, 0x30
00007986e0dd2475  vmovaps xmm0, [rsp]
00007986e0dd247a  vmovaps xmm1, [rsp+0x10]
00007986e0dd2480  vmovaps xmm2, [rsp+0x20]
00007986e0dd2486  vmovaps xmm3, [rsp+0x30]
00007986e0dd248c  vmovaps xmm4, [rsp+0x40]
00007986e0dd2492  vmovaps xmm5, [rsp+0x50]
00007986e0dd2498  vmovaps xmm6, [rsp+0x60]
00007986e0dd249e  vmovaps xmm7, [rsp+0x70]
00007986e0dd24a4  vmovaps xmm8, [rsp+0x80]
00007986e0dd24ad  vmovaps xmm9, [rsp+0x90]
00007986e0dd24b6  vmovaps xmm10, [rsp+0xA0]
00007986e0dd24bf  vmovaps xmm11, [rsp+0xB0]
00007986e0dd24c8  vmovaps xmm12, [rsp+0xC0]
00007986e0dd24d1  vmovaps xmm14, [rsp+0xD0]
00007986e0dd24da  vmovaps xmm15, [rsp+0xE0]
00007986e0dd24e3  add rsp, 0xF0
00007986e0dd24ea  pop r11
00007986e0dd24ec  pop r10
00007986e0dd24ee  pop r9
00007986e0dd24f0  pop r8
00007986e0dd24f2  pop rsi
00007986e0dd24f3  pop rdi
00007986e0dd24f4  pop rdx
00007986e0dd24f5  pop rcx
00007986e0dd24f6  pop rax
00007986e0dd24f7  add rsp, 0x08
00007986e0dd24fb  jmp 0x00007986E0DCFC76
00007986e0dd2500  call 0x00007986E0BFF430
00007986e0dd2505  jmp 0x00007986E0DCFC83
00007986e0dd250a  sub rsp, 0x08
00007986e0dd250e  push rax
00007986e0dd250f  push rcx
00007986e0dd2510  push rdx
00007986e0dd2511  push rdi
00007986e0dd2512  push rsi
00007986e0dd2513  push r8
00007986e0dd2515  push r9
00007986e0dd2517  push r10
00007986e0dd2519  push r11
00007986e0dd251b  sub rsp, 0xF0
00007986e0dd2522  vmovaps [rsp], xmm0
00007986e0dd2527  vmovaps [rsp+0x10], xmm1
00007986e0dd252d  vmovaps [rsp+0x20], xmm2
00007986e0dd2533  vmovaps [rsp+0x30], xmm3
00007986e0dd2539  vmovaps [rsp+0x40], xmm4
00007986e0dd253f  vmovaps [rsp+0x50], xmm5
00007986e0dd2545  vmovaps [rsp+0x60], xmm6
00007986e0dd254b  vmovaps [rsp+0x70], xmm7
00007986e0dd2551  vmovaps [rsp+0x80], xmm8
00007986e0dd255a  vmovaps [rsp+0x90], xmm9
00007986e0dd2563  vmovaps [rsp+0xA0], xmm10
00007986e0dd256c  vmovaps [rsp+0xB0], xmm11
00007986e0dd2575  vmovaps [rsp+0xC0], xmm12
00007986e0dd257e  vmovaps [rsp+0xD0], xmm13
00007986e0dd2587  vmovaps [rsp+0xE0], xmm14
00007986e0dd2590  sub rsp, 0x30
00007986e0dd2594  movaps [rsp], xmm15
00007986e0dd2599  movaps [rsp+0x10], xmm11
00007986e0dd259f  movaps [rsp+0x20], xmm1
00007986e0dd25a4  lea rdi, [rsp]
00007986e0dd25a8  mov esi, 0x00
00007986e0dd25ad  mov rax, 0x5652C689F530
00007986e0dd25b7  call rax
00007986e0dd25b9  movaps xmm15, [rsp]
00007986e0dd25be  add rsp, 0x30
00007986e0dd25c2  vmovaps xmm0, [rsp]
00007986e0dd25c7  vmovaps xmm1, [rsp+0x10]
00007986e0dd25cd  vmovaps xmm2, [rsp+0x20]
00007986e0dd25d3  vmovaps xmm3, [rsp+0x30]
00007986e0dd25d9  vmovaps xmm4, [rsp+0x40]
00007986e0dd25df  vmovaps xmm5, [rsp+0x50]
00007986e0dd25e5  vmovaps xmm6, [rsp+0x60]
00007986e0dd25eb  vmovaps xmm7, [rsp+0x70]
00007986e0dd25f1  vmovaps xmm8, [rsp+0x80]
00007986e0dd25fa  vmovaps xmm9, [rsp+0x90]
00007986e0dd2603  vmovaps xmm10, [rsp+0xA0]
00007986e0dd260c  vmovaps xmm11, [rsp+0xB0]
00007986e0dd2615  vmovaps xmm12, [rsp+0xC0]
00007986e0dd261e  vmovaps xmm13, [rsp+0xD0]
00007986e0dd2627  vmovaps xmm14, [rsp+0xE0]
00007986e0dd2630  add rsp, 0xF0
00007986e0dd2637  pop r11
00007986e0dd2639  pop r10
00007986e0dd263b  pop r9
00007986e0dd263d  pop r8
00007986e0dd263f  pop rsi
00007986e0dd2640  pop rdi
00007986e0dd2641  pop rdx
00007986e0dd2642  pop rcx
00007986e0dd2643  pop rax
00007986e0dd2644  add rsp, 0x08
00007986e0dd2648  jmp 0x00007986E0DCFCBC
00007986e0dd264d  sub rsp, 0x08
00007986e0dd2651  push rax
00007986e0dd2652  push rcx
00007986e0dd2653  push rdx
00007986e0dd2654  push rdi
00007986e0dd2655  push rsi
00007986e0dd2656  push r8
00007986e0dd2658  push r9
00007986e0dd265a  push r10
00007986e0dd265c  push r11
00007986e0dd265e  sub rsp, 0xF0
00007986e0dd2665  vmovaps [rsp], xmm0
00007986e0dd266a  vmovaps [rsp+0x10], xmm1
00007986e0dd2670  vmovaps [rsp+0x20], xmm2
00007986e0dd2676  vmovaps [rsp+0x30], xmm3
00007986e0dd267c  vmovaps [rsp+0x40], xmm4
00007986e0dd2682  vmovaps [rsp+0x50], xmm5
00007986e0dd2688  vmovaps [rsp+0x60], xmm6
00007986e0dd268e  vmovaps [rsp+0x70], xmm7
00007986e0dd2694  vmovaps [rsp+0x80], xmm8
00007986e0dd269d  vmovaps [rsp+0x90], xmm9
00007986e0dd26a6  vmovaps [rsp+0xA0], xmm10
00007986e0dd26af  vmovaps [rsp+0xB0], xmm12
00007986e0dd26b8  vmovaps [rsp+0xC0], xmm13
00007986e0dd26c1  vmovaps [rsp+0xD0], xmm14
00007986e0dd26ca  vmovaps [rsp+0xE0], xmm15
00007986e0dd26d3  sub rsp, 0x30
00007986e0dd26d7  movaps [rsp], xmm11
00007986e0dd26dc  movaps [rsp+0x10], xmm6
00007986e0dd26e1  movaps [rsp+0x20], xmm14
00007986e0dd26e7  lea rdi, [rsp]
00007986e0dd26eb  mov esi, 0x00
00007986e0dd26f0  mov rax, 0x5652C689F530
00007986e0dd26fa  call rax
00007986e0dd26fc  movaps xmm11, [rsp]
00007986e0dd2701  add rsp, 0x30
00007986e0dd2705  vmovaps xmm0, [rsp]
00007986e0dd270a  vmovaps xmm1, [rsp+0x10]
00007986e0dd2710  vmovaps xmm2, [rsp+0x20]
00007986e0dd2716  vmovaps xmm3, [rsp+0x30]
00007986e0dd271c  vmovaps xmm4, [rsp+0x40]
00007986e0dd2722  vmovaps xmm5, [rsp+0x50]
00007986e0dd2728  vmovaps xmm6, [rsp+0x60]
00007986e0dd272e  vmovaps xmm7, [rsp+0x70]
00007986e0dd2734  vmovaps xmm8, [rsp+0x80]
00007986e0dd273d  vmovaps xmm9, [rsp+0x90]
00007986e0dd2746  vmovaps xmm10, [rsp+0xA0]
00007986e0dd274f  vmovaps xmm12, [rsp+0xB0]
00007986e0dd2758  vmovaps xmm13, [rsp+0xC0]
00007986e0dd2761  vmovaps xmm14, [rsp+0xD0]
00007986e0dd276a  vmovaps xmm15, [rsp+0xE0]
00007986e0dd2773  add rsp, 0xF0
00007986e0dd277a  pop r11
00007986e0dd277c  pop r10
00007986e0dd277e  pop r9
00007986e0dd2780  pop r8
00007986e0dd2782  pop rsi
00007986e0dd2783  pop rdi
00007986e0dd2784  pop rdx
00007986e0dd2785  pop rcx
00007986e0dd2786  pop rax
00007986e0dd2787  add rsp, 0x08
00007986e0dd278b  jmp 0x00007986E0DCFD34
00007986e0dd2790  call 0x00007986E0BFF430
00007986e0dd2795  jmp 0x00007986E0DCFD3E
00007986e0dd279a  sub rsp, 0x08
00007986e0dd279e  push rax
00007986e0dd279f  push rcx
00007986e0dd27a0  push rdx
00007986e0dd27a1  push rdi
00007986e0dd27a2  push rsi
00007986e0dd27a3  push r8
00007986e0dd27a5  push r9
00007986e0dd27a7  push r10
00007986e0dd27a9  push r11
00007986e0dd27ab  sub rsp, 0xF0
00007986e0dd27b2  vmovaps [rsp], xmm0
00007986e0dd27b7  vmovaps [rsp+0x10], xmm1
00007986e0dd27bd  vmovaps [rsp+0x20], xmm2
00007986e0dd27c3  vmovaps [rsp+0x30], xmm3
00007986e0dd27c9  vmovaps [rsp+0x40], xmm4
00007986e0dd27cf  vmovaps [rsp+0x50], xmm5
00007986e0dd27d5  vmovaps [rsp+0x60], xmm6
00007986e0dd27db  vmovaps [rsp+0x70], xmm7
00007986e0dd27e1  vmovaps [rsp+0x80], xmm8
00007986e0dd27ea  vmovaps [rsp+0x90], xmm9
00007986e0dd27f3  vmovaps [rsp+0xA0], xmm10
00007986e0dd27fc  vmovaps [rsp+0xB0], xmm11
00007986e0dd2805  vmovaps [rsp+0xC0], xmm12
00007986e0dd280e  vmovaps [rsp+0xD0], xmm13
00007986e0dd2817  vmovaps [rsp+0xE0], xmm15
00007986e0dd2820  sub rsp, 0x30
00007986e0dd2824  movaps [rsp], xmm14
00007986e0dd2829  movaps [rsp+0x10], xmm6
00007986e0dd282e  movaps [rsp+0x20], xmm2
00007986e0dd2833  lea rdi, [rsp]
00007986e0dd2837  mov esi, 0x00
00007986e0dd283c  mov rax, 0x5652C689F530
00007986e0dd2846  call rax
00007986e0dd2848  movaps xmm14, [rsp]
00007986e0dd284d  add rsp, 0x30
00007986e0dd2851  vmovaps xmm0, [rsp]
00007986e0dd2856  vmovaps xmm1, [rsp+0x10]
00007986e0dd285c  vmovaps xmm2, [rsp+0x20]
00007986e0dd2862  vmovaps xmm3, [rsp+0x30]
00007986e0dd2868  vmovaps xmm4, [rsp+0x40]
00007986e0dd286e  vmovaps xmm5, [rsp+0x50]
00007986e0dd2874  vmovaps xmm6, [rsp+0x60]
00007986e0dd287a  vmovaps xmm7, [rsp+0x70]
00007986e0dd2880  vmovaps xmm8, [rsp+0x80]
00007986e0dd2889  vmovaps xmm9, [rsp+0x90]
00007986e0dd2892  vmovaps xmm10, [rsp+0xA0]
00007986e0dd289b  vmovaps xmm11, [rsp+0xB0]
00007986e0dd28a4  vmovaps xmm12, [rsp+0xC0]
00007986e0dd28ad  vmovaps xmm13, [rsp+0xD0]
00007986e0dd28b6  vmovaps xmm15, [rsp+0xE0]
00007986e0dd28bf  add rsp, 0xF0
00007986e0dd28c6  pop r11
00007986e0dd28c8  pop r10
00007986e0dd28ca  pop r9
00007986e0dd28cc  pop r8
00007986e0dd28ce  pop rsi
00007986e0dd28cf  pop rdi
00007986e0dd28d0  pop rdx
00007986e0dd28d1  pop rcx
00007986e0dd28d2  pop rax
00007986e0dd28d3  add rsp, 0x08
00007986e0dd28d7  jmp 0x00007986E0DCFD72
00007986e0dd28dc  sub rsp, 0x08
00007986e0dd28e0  push rax
00007986e0dd28e1  push rcx
00007986e0dd28e2  push rdx
00007986e0dd28e3  push rdi
00007986e0dd28e4  push rsi
00007986e0dd28e5  push r8
00007986e0dd28e7  push r9
00007986e0dd28e9  push r10
00007986e0dd28eb  push r11
00007986e0dd28ed  sub rsp, 0xF0
00007986e0dd28f4  vmovaps [rsp], xmm0
00007986e0dd28f9  vmovaps [rsp+0x10], xmm1
00007986e0dd28ff  vmovaps [rsp+0x20], xmm2
00007986e0dd2905  vmovaps [rsp+0x30], xmm3
00007986e0dd290b  vmovaps [rsp+0x40], xmm4
00007986e0dd2911  vmovaps [rsp+0x50], xmm5
00007986e0dd2917  vmovaps [rsp+0x60], xmm7
00007986e0dd291d  vmovaps [rsp+0x70], xmm8
00007986e0dd2923  vmovaps [rsp+0x80], xmm9
00007986e0dd292c  vmovaps [rsp+0x90], xmm10
00007986e0dd2935  vmovaps [rsp+0xA0], xmm11
00007986e0dd293e  vmovaps [rsp+0xB0], xmm12
00007986e0dd2947  vmovaps [rsp+0xC0], xmm13
00007986e0dd2950  vmovaps [rsp+0xD0], xmm14
00007986e0dd2959  vmovaps [rsp+0xE0], xmm15
00007986e0dd2962  sub rsp, 0x30
00007986e0dd2966  movaps [rsp], xmm6
00007986e0dd296a  movaps [rsp+0x10], xmm5
00007986e0dd296f  movaps [rsp+0x20], xmm1
00007986e0dd2974  lea rdi, [rsp]
00007986e0dd2978  mov esi, 0x00
00007986e0dd297d  mov rax, 0x5652C689F530
00007986e0dd2987  call rax
00007986e0dd2989  movaps xmm6, [rsp]
00007986e0dd298d  add rsp, 0x30
00007986e0dd2991  vmovaps xmm0, [rsp]
00007986e0dd2996  vmovaps xmm1, [rsp+0x10]
00007986e0dd299c  vmovaps xmm2, [rsp+0x20]
00007986e0dd29a2  vmovaps xmm3, [rsp+0x30]
00007986e0dd29a8  vmovaps xmm4, [rsp+0x40]
00007986e0dd29ae  vmovaps xmm5, [rsp+0x50]
00007986e0dd29b4  vmovaps xmm7, [rsp+0x60]
00007986e0dd29ba  vmovaps xmm8, [rsp+0x70]
00007986e0dd29c0  vmovaps xmm9, [rsp+0x80]
00007986e0dd29c9  vmovaps xmm10, [rsp+0x90]
00007986e0dd29d2  vmovaps xmm11, [rsp+0xA0]
00007986e0dd29db  vmovaps xmm12, [rsp+0xB0]
00007986e0dd29e4  vmovaps xmm13, [rsp+0xC0]
00007986e0dd29ed  vmovaps xmm14, [rsp+0xD0]
00007986e0dd29f6  vmovaps xmm15, [rsp+0xE0]
00007986e0dd29ff  add rsp, 0xF0
00007986e0dd2a06  pop r11
00007986e0dd2a08  pop r10
00007986e0dd2a0a  pop r9
00007986e0dd2a0c  pop r8
00007986e0dd2a0e  pop rsi
00007986e0dd2a0f  pop rdi
00007986e0dd2a10  pop rdx
00007986e0dd2a11  pop rcx
00007986e0dd2a12  pop rax
00007986e0dd2a13  add rsp, 0x08
00007986e0dd2a17  jmp 0x00007986E0DCFD98
00007986e0dd2a1c  sub rsp, 0x08
00007986e0dd2a20  push rax
00007986e0dd2a21  push rcx
00007986e0dd2a22  push rdx
00007986e0dd2a23  push rdi
00007986e0dd2a24  push rsi
00007986e0dd2a25  push r8
00007986e0dd2a27  push r9
00007986e0dd2a29  push r10
00007986e0dd2a2b  push r11
00007986e0dd2a2d  sub rsp, 0xF0
00007986e0dd2a34  vmovaps [rsp], xmm0
00007986e0dd2a39  vmovaps [rsp+0x10], xmm2
00007986e0dd2a3f  vmovaps [rsp+0x20], xmm3
00007986e0dd2a45  vmovaps [rsp+0x30], xmm4
00007986e0dd2a4b  vmovaps [rsp+0x40], xmm5
00007986e0dd2a51  vmovaps [rsp+0x50], xmm6
00007986e0dd2a57  vmovaps [rsp+0x60], xmm7
00007986e0dd2a5d  vmovaps [rsp+0x70], xmm8
00007986e0dd2a63  vmovaps [rsp+0x80], xmm9
00007986e0dd2a6c  vmovaps [rsp+0x90], xmm10
00007986e0dd2a75  vmovaps [rsp+0xA0], xmm11
00007986e0dd2a7e  vmovaps [rsp+0xB0], xmm12
00007986e0dd2a87  vmovaps [rsp+0xC0], xmm13
00007986e0dd2a90  vmovaps [rsp+0xD0], xmm14
00007986e0dd2a99  vmovaps [rsp+0xE0], xmm15
00007986e0dd2aa2  sub rsp, 0x30
00007986e0dd2aa6  movaps [rsp], xmm1
00007986e0dd2aaa  movaps [rsp+0x10], xmm5
00007986e0dd2aaf  movaps [rsp+0x20], xmm13
00007986e0dd2ab5  lea rdi, [rsp]
00007986e0dd2ab9  mov esi, 0x00
00007986e0dd2abe  mov rax, 0x5652C689F530
00007986e0dd2ac8  call rax
00007986e0dd2aca  movaps xmm1, [rsp]
00007986e0dd2ace  add rsp, 0x30
00007986e0dd2ad2  vmovaps xmm0, [rsp]
00007986e0dd2ad7  vmovaps xmm2, [rsp+0x10]
00007986e0dd2add  vmovaps xmm3, [rsp+0x20]
00007986e0dd2ae3  vmovaps xmm4, [rsp+0x30]
00007986e0dd2ae9  vmovaps xmm5, [rsp+0x40]
00007986e0dd2aef  vmovaps xmm6, [rsp+0x50]
00007986e0dd2af5  vmovaps xmm7, [rsp+0x60]
00007986e0dd2afb  vmovaps xmm8, [rsp+0x70]
00007986e0dd2b01  vmovaps xmm9, [rsp+0x80]
00007986e0dd2b0a  vmovaps xmm10, [rsp+0x90]
00007986e0dd2b13  vmovaps xmm11, [rsp+0xA0]
00007986e0dd2b1c  vmovaps xmm12, [rsp+0xB0]
00007986e0dd2b25  vmovaps xmm13, [rsp+0xC0]
00007986e0dd2b2e  vmovaps xmm14, [rsp+0xD0]
00007986e0dd2b37  vmovaps xmm15, [rsp+0xE0]
00007986e0dd2b40  add rsp, 0xF0
00007986e0dd2b47  pop r11
00007986e0dd2b49  pop r10
00007986e0dd2b4b  pop r9
00007986e0dd2b4d  pop r8
00007986e0dd2b4f  pop rsi
00007986e0dd2b50  pop rdi
00007986e0dd2b51  pop rdx
00007986e0dd2b52  pop rcx
00007986e0dd2b53  pop rax
00007986e0dd2b54  add rsp, 0x08
00007986e0dd2b58  jmp 0x00007986E0DCFDB6
00007986e0dd2b5d  sub rsp, 0x08
00007986e0dd2b61  push rax
00007986e0dd2b62  push rcx
00007986e0dd2b63  push rdx
00007986e0dd2b64  push rdi
00007986e0dd2b65  push rsi
00007986e0dd2b66  push r8
00007986e0dd2b68  push r9
00007986e0dd2b6a  push r10
00007986e0dd2b6c  push r11
00007986e0dd2b6e  sub rsp, 0xF0
00007986e0dd2b75  vmovaps [rsp], xmm0
00007986e0dd2b7a  vmovaps [rsp+0x10], xmm1
00007986e0dd2b80  vmovaps [rsp+0x20], xmm2
00007986e0dd2b86  vmovaps [rsp+0x30], xmm3
00007986e0dd2b8c  vmovaps [rsp+0x40], xmm4
00007986e0dd2b92  vmovaps [rsp+0x50], xmm6
00007986e0dd2b98  vmovaps [rsp+0x60], xmm7
00007986e0dd2b9e  vmovaps [rsp+0x70], xmm8
00007986e0dd2ba4  vmovaps [rsp+0x80], xmm9
00007986e0dd2bad  vmovaps [rsp+0x90], xmm10
00007986e0dd2bb6  vmovaps [rsp+0xA0], xmm11
00007986e0dd2bbf  vmovaps [rsp+0xB0], xmm12
00007986e0dd2bc8  vmovaps [rsp+0xC0], xmm13
00007986e0dd2bd1  vmovaps [rsp+0xD0], xmm14
00007986e0dd2bda  vmovaps [rsp+0xE0], xmm15
00007986e0dd2be3  sub rsp, 0x30
00007986e0dd2be7  movaps [rsp], xmm5
00007986e0dd2beb  movaps [rsp+0x10], xmm2
00007986e0dd2bf0  movaps [rsp+0x20], xmm13
00007986e0dd2bf6  lea rdi, [rsp]
00007986e0dd2bfa  mov esi, 0x00
00007986e0dd2bff  mov rax, 0x5652C689F530
00007986e0dd2c09  call rax
00007986e0dd2c0b  movaps xmm5, [rsp]
00007986e0dd2c0f  add rsp, 0x30
00007986e0dd2c13  vmovaps xmm0, [rsp]
00007986e0dd2c18  vmovaps xmm1, [rsp+0x10]
00007986e0dd2c1e  vmovaps xmm2, [rsp+0x20]
00007986e0dd2c24  vmovaps xmm3, [rsp+0x30]
00007986e0dd2c2a  vmovaps xmm4, [rsp+0x40]
00007986e0dd2c30  vmovaps xmm6, [rsp+0x50]
00007986e0dd2c36  vmovaps xmm7, [rsp+0x60]
00007986e0dd2c3c  vmovaps xmm8, [rsp+0x70]
00007986e0dd2c42  vmovaps xmm9, [rsp+0x80]
00007986e0dd2c4b  vmovaps xmm10, [rsp+0x90]
00007986e0dd2c54  vmovaps xmm11, [rsp+0xA0]
00007986e0dd2c5d  vmovaps xmm12, [rsp+0xB0]
00007986e0dd2c66  vmovaps xmm13, [rsp+0xC0]
00007986e0dd2c6f  vmovaps xmm14, [rsp+0xD0]
00007986e0dd2c78  vmovaps xmm15, [rsp+0xE0]
00007986e0dd2c81  add rsp, 0xF0
00007986e0dd2c88  pop r11
00007986e0dd2c8a  pop r10
00007986e0dd2c8c  pop r9
00007986e0dd2c8e  pop r8
00007986e0dd2c90  pop rsi
00007986e0dd2c91  pop rdi
00007986e0dd2c92  pop rdx
00007986e0dd2c93  pop rcx
00007986e0dd2c94  pop rax
00007986e0dd2c95  add rsp, 0x08
00007986e0dd2c99  jmp 0x00007986E0DCFDEC
00007986e0dd2c9e  sub rsp, 0x08
00007986e0dd2ca2  push rax
00007986e0dd2ca3  push rcx
00007986e0dd2ca4  push rdx
00007986e0dd2ca5  push rdi
00007986e0dd2ca6  push rsi
00007986e0dd2ca7  push r8
00007986e0dd2ca9  push r9
00007986e0dd2cab  push r10
00007986e0dd2cad  push r11
00007986e0dd2caf  sub rsp, 0xF0
00007986e0dd2cb6  vmovaps [rsp], xmm0
00007986e0dd2cbb  vmovaps [rsp+0x10], xmm1
00007986e0dd2cc1  vmovaps [rsp+0x20], xmm2
00007986e0dd2cc7  vmovaps [rsp+0x30], xmm3
00007986e0dd2ccd  vmovaps [rsp+0x40], xmm4
00007986e0dd2cd3  vmovaps [rsp+0x50], xmm5
00007986e0dd2cd9  vmovaps [rsp+0x60], xmm6
00007986e0dd2cdf  vmovaps [rsp+0x70], xmm7
00007986e0dd2ce5  vmovaps [rsp+0x80], xmm8
00007986e0dd2cee  vmovaps [rsp+0x90], xmm9
00007986e0dd2cf7  vmovaps [rsp+0xA0], xmm10
00007986e0dd2d00  vmovaps [rsp+0xB0], xmm11
00007986e0dd2d09  vmovaps [rsp+0xC0], xmm12
00007986e0dd2d12  vmovaps [rsp+0xD0], xmm14
00007986e0dd2d1b  vmovaps [rsp+0xE0], xmm15
00007986e0dd2d24  sub rsp, 0x30
00007986e0dd2d28  movaps [rsp], xmm13
00007986e0dd2d2d  movaps [rsp+0x10], xmm10
00007986e0dd2d33  movaps [rsp+0x20], xmm1
00007986e0dd2d38  lea rdi, [rsp]
00007986e0dd2d3c  mov esi, 0x00
00007986e0dd2d41  mov rax, 0x5652C689F530
00007986e0dd2d4b  call rax
00007986e0dd2d4d  movaps xmm13, [rsp]
00007986e0dd2d52  add rsp, 0x30
00007986e0dd2d56  vmovaps xmm0, [rsp]
00007986e0dd2d5b  vmovaps xmm1, [rsp+0x10]
00007986e0dd2d61  vmovaps xmm2, [rsp+0x20]
00007986e0dd2d67  vmovaps xmm3, [rsp+0x30]
00007986e0dd2d6d  vmovaps xmm4, [rsp+0x40]
00007986e0dd2d73  vmovaps xmm5, [rsp+0x50]
00007986e0dd2d79  vmovaps xmm6, [rsp+0x60]
00007986e0dd2d7f  vmovaps xmm7, [rsp+0x70]
00007986e0dd2d85  vmovaps xmm8, [rsp+0x80]
00007986e0dd2d8e  vmovaps xmm9, [rsp+0x90]
00007986e0dd2d97  vmovaps xmm10, [rsp+0xA0]
00007986e0dd2da0  vmovaps xmm11, [rsp+0xB0]
00007986e0dd2da9  vmovaps xmm12, [rsp+0xC0]
00007986e0dd2db2  vmovaps xmm14, [rsp+0xD0]
00007986e0dd2dbb  vmovaps xmm15, [rsp+0xE0]
00007986e0dd2dc4  add rsp, 0xF0
00007986e0dd2dcb  pop r11
00007986e0dd2dcd  pop r10
00007986e0dd2dcf  pop r9
00007986e0dd2dd1  pop r8
00007986e0dd2dd3  pop rsi
00007986e0dd2dd4  pop rdi
00007986e0dd2dd5  pop rdx
00007986e0dd2dd6  pop rcx
00007986e0dd2dd7  pop rax
00007986e0dd2dd8  add rsp, 0x08
00007986e0dd2ddc  jmp 0x00007986E0DCFE15
00007986e0dd2de1  sub rsp, 0x08
00007986e0dd2de5  push rax
00007986e0dd2de6  push rcx
00007986e0dd2de7  push rdx
00007986e0dd2de8  push rdi
00007986e0dd2de9  push rsi
00007986e0dd2dea  push r8
00007986e0dd2dec  push r9
00007986e0dd2dee  push r10
00007986e0dd2df0  push r11
00007986e0dd2df2  sub rsp, 0xF0
00007986e0dd2df9  vmovaps [rsp], xmm0
00007986e0dd2dfe  vmovaps [rsp+0x10], xmm2
00007986e0dd2e04  vmovaps [rsp+0x20], xmm3
00007986e0dd2e0a  vmovaps [rsp+0x30], xmm4
00007986e0dd2e10  vmovaps [rsp+0x40], xmm5
00007986e0dd2e16  vmovaps [rsp+0x50], xmm6
00007986e0dd2e1c  vmovaps [rsp+0x60], xmm7
00007986e0dd2e22  vmovaps [rsp+0x70], xmm8
00007986e0dd2e28  vmovaps [rsp+0x80], xmm9
00007986e0dd2e31  vmovaps [rsp+0x90], xmm10
00007986e0dd2e3a  vmovaps [rsp+0xA0], xmm11
00007986e0dd2e43  vmovaps [rsp+0xB0], xmm12
00007986e0dd2e4c  vmovaps [rsp+0xC0], xmm13
00007986e0dd2e55  vmovaps [rsp+0xD0], xmm14
00007986e0dd2e5e  vmovaps [rsp+0xE0], xmm15
00007986e0dd2e67  sub rsp, 0x30
00007986e0dd2e6b  movaps [rsp], xmm1
00007986e0dd2e6f  movaps [rsp+0x10], xmm15
00007986e0dd2e75  movaps [rsp+0x20], xmm10
00007986e0dd2e7b  lea rdi, [rsp]
00007986e0dd2e7f  mov esi, 0x00
00007986e0dd2e84  mov rax, 0x5652C689F530
00007986e0dd2e8e  call rax
00007986e0dd2e90  movaps xmm1, [rsp]
00007986e0dd2e94  add rsp, 0x30
00007986e0dd2e98  vmovaps xmm0, [rsp]
00007986e0dd2e9d  vmovaps xmm2, [rsp+0x10]
00007986e0dd2ea3  vmovaps xmm3, [rsp+0x20]
00007986e0dd2ea9  vmovaps xmm4, [rsp+0x30]
00007986e0dd2eaf  vmovaps xmm5, [rsp+0x40]
00007986e0dd2eb5  vmovaps xmm6, [rsp+0x50]
00007986e0dd2ebb  vmovaps xmm7, [rsp+0x60]
00007986e0dd2ec1  vmovaps xmm8, [rsp+0x70]
00007986e0dd2ec7  vmovaps xmm9, [rsp+0x80]
00007986e0dd2ed0  vmovaps xmm10, [rsp+0x90]
00007986e0dd2ed9  vmovaps xmm11, [rsp+0xA0]
00007986e0dd2ee2  vmovaps xmm12, [rsp+0xB0]
00007986e0dd2eeb  vmovaps xmm13, [rsp+0xC0]
00007986e0dd2ef4  vmovaps xmm14, [rsp+0xD0]
00007986e0dd2efd  vmovaps xmm15, [rsp+0xE0]
00007986e0dd2f06  add rsp, 0xF0
00007986e0dd2f0d  pop r11
00007986e0dd2f0f  pop r10
00007986e0dd2f11  pop r9
00007986e0dd2f13  pop r8
00007986e0dd2f15  pop rsi
00007986e0dd2f16  pop rdi
00007986e0dd2f17  pop rdx
00007986e0dd2f18  pop rcx
00007986e0dd2f19  pop rax
00007986e0dd2f1a  add rsp, 0x08
00007986e0dd2f1e  jmp 0x00007986E0DCFE34
00007986e0dd2f23  sub rsp, 0x08
00007986e0dd2f27  push rax
00007986e0dd2f28  push rcx
00007986e0dd2f29  push rdx
00007986e0dd2f2a  push rdi
00007986e0dd2f2b  push rsi
00007986e0dd2f2c  push r8
00007986e0dd2f2e  push r9
00007986e0dd2f30  push r10
00007986e0dd2f32  push r11
00007986e0dd2f34  sub rsp, 0xF0
00007986e0dd2f3b  vmovaps [rsp], xmm0
00007986e0dd2f40  vmovaps [rsp+0x10], xmm1
00007986e0dd2f46  vmovaps [rsp+0x20], xmm2
00007986e0dd2f4c  vmovaps [rsp+0x30], xmm3
00007986e0dd2f52  vmovaps [rsp+0x40], xmm4
00007986e0dd2f58  vmovaps [rsp+0x50], xmm5
00007986e0dd2f5e  vmovaps [rsp+0x60], xmm6
00007986e0dd2f64  vmovaps [rsp+0x70], xmm7
00007986e0dd2f6a  vmovaps [rsp+0x80], xmm8
00007986e0dd2f73  vmovaps [rsp+0x90], xmm9
00007986e0dd2f7c  vmovaps [rsp+0xA0], xmm10
00007986e0dd2f85  vmovaps [rsp+0xB0], xmm11
00007986e0dd2f8e  vmovaps [rsp+0xC0], xmm12
00007986e0dd2f97  vmovaps [rsp+0xD0], xmm13
00007986e0dd2fa0  vmovaps [rsp+0xE0], xmm14
00007986e0dd2fa9  sub rsp, 0x30
00007986e0dd2fad  movaps [rsp], xmm15
00007986e0dd2fb2  movaps [rsp+0x10], xmm10
00007986e0dd2fb8  movaps [rsp+0x20], xmm11
00007986e0dd2fbe  lea rdi, [rsp]
00007986e0dd2fc2  mov esi, 0x00
00007986e0dd2fc7  mov rax, 0x5652C689F530
00007986e0dd2fd1  call rax
00007986e0dd2fd3  movaps xmm15, [rsp]
00007986e0dd2fd8  add rsp, 0x30
00007986e0dd2fdc  vmovaps xmm0, [rsp]
00007986e0dd2fe1  vmovaps xmm1, [rsp+0x10]
00007986e0dd2fe7  vmovaps xmm2, [rsp+0x20]
00007986e0dd2fed  vmovaps xmm3, [rsp+0x30]
00007986e0dd2ff3  vmovaps xmm4, [rsp+0x40]
00007986e0dd2ff9  vmovaps xmm5, [rsp+0x50]
00007986e0dd2fff  vmovaps xmm6, [rsp+0x60]
00007986e0dd3005  vmovaps xmm7, [rsp+0x70]
00007986e0dd300b  vmovaps xmm8, [rsp+0x80]
00007986e0dd3014  vmovaps xmm9, [rsp+0x90]
00007986e0dd301d  vmovaps xmm10, [rsp+0xA0]
00007986e0dd3026  vmovaps xmm11, [rsp+0xB0]
00007986e0dd302f  vmovaps xmm12, [rsp+0xC0]
00007986e0dd3038  vmovaps xmm13, [rsp+0xD0]
00007986e0dd3041  vmovaps xmm14, [rsp+0xE0]
00007986e0dd304a  add rsp, 0xF0
00007986e0dd3051  pop r11
00007986e0dd3053  pop r10
00007986e0dd3055  pop r9
00007986e0dd3057  pop r8
00007986e0dd3059  pop rsi
00007986e0dd305a  pop rdi
00007986e0dd305b  pop rdx
00007986e0dd305c  pop rcx
00007986e0dd305d  pop rax
00007986e0dd305e  add rsp, 0x08
00007986e0dd3062  jmp 0x00007986E0DCFE57
00007986e0dd3067  sub rsp, 0x08
00007986e0dd306b  push rax
00007986e0dd306c  push rcx
00007986e0dd306d  push rdx
00007986e0dd306e  push rdi
00007986e0dd306f  push rsi
00007986e0dd3070  push r8
00007986e0dd3072  push r9
00007986e0dd3074  push r10
00007986e0dd3076  push r11
00007986e0dd3078  sub rsp, 0xF0
00007986e0dd307f  vmovaps [rsp], xmm0
00007986e0dd3084  vmovaps [rsp+0x10], xmm1
00007986e0dd308a  vmovaps [rsp+0x20], xmm2
00007986e0dd3090  vmovaps [rsp+0x30], xmm3
00007986e0dd3096  vmovaps [rsp+0x40], xmm4
00007986e0dd309c  vmovaps [rsp+0x50], xmm5
00007986e0dd30a2  vmovaps [rsp+0x60], xmm6
00007986e0dd30a8  vmovaps [rsp+0x70], xmm7
00007986e0dd30ae  vmovaps [rsp+0x80], xmm8
00007986e0dd30b7  vmovaps [rsp+0x90], xmm9
00007986e0dd30c0  vmovaps [rsp+0xA0], xmm11
00007986e0dd30c9  vmovaps [rsp+0xB0], xmm12
00007986e0dd30d2  vmovaps [rsp+0xC0], xmm13
00007986e0dd30db  vmovaps [rsp+0xD0], xmm14
00007986e0dd30e4  vmovaps [rsp+0xE0], xmm15
00007986e0dd30ed  sub rsp, 0x30
00007986e0dd30f1  movaps [rsp], xmm10
00007986e0dd30f6  movaps [rsp+0x10], xmm12
00007986e0dd30fc  movaps [rsp+0x20], xmm11
00007986e0dd3102  lea rdi, [rsp]
00007986e0dd3106  mov esi, 0x00
00007986e0dd310b  mov rax, 0x5652C689F530
00007986e0dd3115  call rax
00007986e0dd3117  movaps xmm10, [rsp]
00007986e0dd311c  add rsp, 0x30
00007986e0dd3120  vmovaps xmm0, [rsp]
00007986e0dd3125  vmovaps xmm1, [rsp+0x10]
00007986e0dd312b  vmovaps xmm2, [rsp+0x20]
00007986e0dd3131  vmovaps xmm3, [rsp+0x30]
00007986e0dd3137  vmovaps xmm4, [rsp+0x40]
00007986e0dd313d  vmovaps xmm5, [rsp+0x50]
00007986e0dd3143  vmovaps xmm6, [rsp+0x60]
00007986e0dd3149  vmovaps xmm7, [rsp+0x70]
00007986e0dd314f  vmovaps xmm8, [rsp+0x80]
00007986e0dd3158  vmovaps xmm9, [rsp+0x90]
00007986e0dd3161  vmovaps xmm11, [rsp+0xA0]
00007986e0dd316a  vmovaps xmm12, [rsp+0xB0]
00007986e0dd3173  vmovaps xmm13, [rsp+0xC0]
00007986e0dd317c  vmovaps xmm14, [rsp+0xD0]
00007986e0dd3185  vmovaps xmm15, [rsp+0xE0]
00007986e0dd318e  add rsp, 0xF0
00007986e0dd3195  pop r11
00007986e0dd3197  pop r10
00007986e0dd3199  pop r9
00007986e0dd319b  pop r8
00007986e0dd319d  pop rsi
00007986e0dd319e  pop rdi
00007986e0dd319f  pop rdx
00007986e0dd31a0  pop rcx
00007986e0dd31a1  pop rax
00007986e0dd31a2  add rsp, 0x08
00007986e0dd31a6  jmp 0x00007986E0DCFE80
00007986e0dd31ab  sub rsp, 0x08
00007986e0dd31af  push rax
00007986e0dd31b0  push rcx
00007986e0dd31b1  push rdx
00007986e0dd31b2  push rdi
00007986e0dd31b3  push rsi
00007986e0dd31b4  push r8
00007986e0dd31b6  push r9
00007986e0dd31b8  push r10
00007986e0dd31ba  push r11
00007986e0dd31bc  sub rsp, 0xF0
00007986e0dd31c3  vmovaps [rsp], xmm0
00007986e0dd31c8  vmovaps [rsp+0x10], xmm1
00007986e0dd31ce  vmovaps [rsp+0x20], xmm2
00007986e0dd31d4  vmovaps [rsp+0x30], xmm3
00007986e0dd31da  vmovaps [rsp+0x40], xmm4
00007986e0dd31e0  vmovaps [rsp+0x50], xmm5
00007986e0dd31e6  vmovaps [rsp+0x60], xmm6
00007986e0dd31ec  vmovaps [rsp+0x70], xmm7
00007986e0dd31f2  vmovaps [rsp+0x80], xmm8
00007986e0dd31fb  vmovaps [rsp+0x90], xmm9
00007986e0dd3204  vmovaps [rsp+0xA0], xmm10
00007986e0dd320d  vmovaps [rsp+0xB0], xmm12
00007986e0dd3216  vmovaps [rsp+0xC0], xmm13
00007986e0dd321f  vmovaps [rsp+0xD0], xmm14
00007986e0dd3228  vmovaps [rsp+0xE0], xmm15
00007986e0dd3231  sub rsp, 0x30
00007986e0dd3235  movaps [rsp], xmm11
00007986e0dd323a  movaps [rsp+0x10], xmm2
00007986e0dd323f  movaps [rsp+0x20], xmm12
00007986e0dd3245  lea rdi, [rsp]
00007986e0dd3249  mov esi, 0x00
00007986e0dd324e  mov rax, 0x5652C689F530
00007986e0dd3258  call rax
00007986e0dd325a  movaps xmm11, [rsp]
00007986e0dd325f  add rsp, 0x30
00007986e0dd3263  vmovaps xmm0, [rsp]
00007986e0dd3268  vmovaps xmm1, [rsp+0x10]
00007986e0dd326e  vmovaps xmm2, [rsp+0x20]
00007986e0dd3274  vmovaps xmm3, [rsp+0x30]
00007986e0dd327a  vmovaps xmm4, [rsp+0x40]
00007986e0dd3280  vmovaps xmm5, [rsp+0x50]
00007986e0dd3286  vmovaps xmm6, [rsp+0x60]
00007986e0dd328c  vmovaps xmm7, [rsp+0x70]
00007986e0dd3292  vmovaps xmm8, [rsp+0x80]
00007986e0dd329b  vmovaps xmm9, [rsp+0x90]
00007986e0dd32a4  vmovaps xmm10, [rsp+0xA0]
00007986e0dd32ad  vmovaps xmm12, [rsp+0xB0]
00007986e0dd32b6  vmovaps xmm13, [rsp+0xC0]
00007986e0dd32bf  vmovaps xmm14, [rsp+0xD0]
00007986e0dd32c8  vmovaps xmm15, [rsp+0xE0]
00007986e0dd32d1  add rsp, 0xF0
00007986e0dd32d8  pop r11
00007986e0dd32da  pop r10
00007986e0dd32dc  pop r9
00007986e0dd32de  pop r8
00007986e0dd32e0  pop rsi
00007986e0dd32e1  pop rdi
00007986e0dd32e2  pop rdx
00007986e0dd32e3  pop rcx
00007986e0dd32e4  pop rax
00007986e0dd32e5  add rsp, 0x08
00007986e0dd32e9  jmp 0x00007986E0DCFEB8
00007986e0dd32ee  sub rsp, 0x08
00007986e0dd32f2  push rax
00007986e0dd32f3  push rcx
00007986e0dd32f4  push rdx
00007986e0dd32f5  push rdi
00007986e0dd32f6  push rsi
00007986e0dd32f7  push r8
00007986e0dd32f9  push r9
00007986e0dd32fb  push r10
00007986e0dd32fd  push r11
00007986e0dd32ff  sub rsp, 0xF0
00007986e0dd3306  vmovaps [rsp], xmm0
00007986e0dd330b  vmovaps [rsp+0x10], xmm2
00007986e0dd3311  vmovaps [rsp+0x20], xmm3
00007986e0dd3317  vmovaps [rsp+0x30], xmm4
00007986e0dd331d  vmovaps [rsp+0x40], xmm5
00007986e0dd3323  vmovaps [rsp+0x50], xmm6
00007986e0dd3329  vmovaps [rsp+0x60], xmm7
00007986e0dd332f  vmovaps [rsp+0x70], xmm8
00007986e0dd3335  vmovaps [rsp+0x80], xmm9
00007986e0dd333e  vmovaps [rsp+0x90], xmm10
00007986e0dd3347  vmovaps [rsp+0xA0], xmm11
00007986e0dd3350  vmovaps [rsp+0xB0], xmm12
00007986e0dd3359  vmovaps [rsp+0xC0], xmm13
00007986e0dd3362  vmovaps [rsp+0xD0], xmm14
00007986e0dd336b  vmovaps [rsp+0xE0], xmm15
00007986e0dd3374  sub rsp, 0x30
00007986e0dd3378  movaps [rsp], xmm1
00007986e0dd337c  movaps [rsp+0x10], xmm14
00007986e0dd3382  movaps [rsp+0x20], xmm6
00007986e0dd3387  lea rdi, [rsp]
00007986e0dd338b  mov esi, 0x00
00007986e0dd3390  mov rax, 0x5652C689F530
00007986e0dd339a  call rax
00007986e0dd339c  movaps xmm1, [rsp]
00007986e0dd33a0  add rsp, 0x30
00007986e0dd33a4  vmovaps xmm0, [rsp]
00007986e0dd33a9  vmovaps xmm2, [rsp+0x10]
00007986e0dd33af  vmovaps xmm3, [rsp+0x20]
00007986e0dd33b5  vmovaps xmm4, [rsp+0x30]
00007986e0dd33bb  vmovaps xmm5, [rsp+0x40]
00007986e0dd33c1  vmovaps xmm6, [rsp+0x50]
00007986e0dd33c7  vmovaps xmm7, [rsp+0x60]
00007986e0dd33cd  vmovaps xmm8, [rsp+0x70]
00007986e0dd33d3  vmovaps xmm9, [rsp+0x80]
00007986e0dd33dc  vmovaps xmm10, [rsp+0x90]
00007986e0dd33e5  vmovaps xmm11, [rsp+0xA0]
00007986e0dd33ee  vmovaps xmm12, [rsp+0xB0]
00007986e0dd33f7  vmovaps xmm13, [rsp+0xC0]
00007986e0dd3400  vmovaps xmm14, [rsp+0xD0]
00007986e0dd3409  vmovaps xmm15, [rsp+0xE0]
00007986e0dd3412  add rsp, 0xF0
00007986e0dd3419  pop r11
00007986e0dd341b  pop r10
00007986e0dd341d  pop r9
00007986e0dd341f  pop r8
00007986e0dd3421  pop rsi
00007986e0dd3422  pop rdi
00007986e0dd3423  pop rdx
00007986e0dd3424  pop rcx
00007986e0dd3425  pop rax
00007986e0dd3426  add rsp, 0x08
00007986e0dd342a  jmp 0x00007986E0DCFED1
00007986e0dd342f  sub rsp, 0x08
00007986e0dd3433  push rax
00007986e0dd3434  push rcx
00007986e0dd3435  push rdx
00007986e0dd3436  push rdi
00007986e0dd3437  push rsi
00007986e0dd3438  push r8
00007986e0dd343a  push r9
00007986e0dd343c  push r10
00007986e0dd343e  push r11
00007986e0dd3440  sub rsp, 0xF0
00007986e0dd3447  vmovaps [rsp], xmm0
00007986e0dd344c  vmovaps [rsp+0x10], xmm1
00007986e0dd3452  vmovaps [rsp+0x20], xmm2
00007986e0dd3458  vmovaps [rsp+0x30], xmm3
00007986e0dd345e  vmovaps [rsp+0x40], xmm4
00007986e0dd3464  vmovaps [rsp+0x50], xmm5
00007986e0dd346a  vmovaps [rsp+0x60], xmm6
00007986e0dd3470  vmovaps [rsp+0x70], xmm7
00007986e0dd3476  vmovaps [rsp+0x80], xmm8
00007986e0dd347f  vmovaps [rsp+0x90], xmm9
00007986e0dd3488  vmovaps [rsp+0xA0], xmm10
00007986e0dd3491  vmovaps [rsp+0xB0], xmm11
00007986e0dd349a  vmovaps [rsp+0xC0], xmm12
00007986e0dd34a3  vmovaps [rsp+0xD0], xmm13
00007986e0dd34ac  vmovaps [rsp+0xE0], xmm15
00007986e0dd34b5  sub rsp, 0x30
00007986e0dd34b9  movaps [rsp], xmm14
00007986e0dd34be  movaps [rsp+0x10], xmm12
00007986e0dd34c4  movaps [rsp+0x20], xmm5
00007986e0dd34c9  lea rdi, [rsp]
00007986e0dd34cd  mov esi, 0x00
00007986e0dd34d2  mov rax, 0x5652C689F530
00007986e0dd34dc  call rax
00007986e0dd34de  movaps xmm14, [rsp]
00007986e0dd34e3  add rsp, 0x30
00007986e0dd34e7  vmovaps xmm0, [rsp]
00007986e0dd34ec  vmovaps xmm1, [rsp+0x10]
00007986e0dd34f2  vmovaps xmm2, [rsp+0x20]
00007986e0dd34f8  vmovaps xmm3, [rsp+0x30]
00007986e0dd34fe  vmovaps xmm4, [rsp+0x40]
00007986e0dd3504  vmovaps xmm5, [rsp+0x50]
00007986e0dd350a  vmovaps xmm6, [rsp+0x60]
00007986e0dd3510  vmovaps xmm7, [rsp+0x70]
00007986e0dd3516  vmovaps xmm8, [rsp+0x80]
00007986e0dd351f  vmovaps xmm9, [rsp+0x90]
00007986e0dd3528  vmovaps xmm10, [rsp+0xA0]
00007986e0dd3531  vmovaps xmm11, [rsp+0xB0]
00007986e0dd353a  vmovaps xmm12, [rsp+0xC0]
00007986e0dd3543  vmovaps xmm13, [rsp+0xD0]
00007986e0dd354c  vmovaps xmm15, [rsp+0xE0]
00007986e0dd3555  add rsp, 0xF0
00007986e0dd355c  pop r11
00007986e0dd355e  pop r10
00007986e0dd3560  pop r9
00007986e0dd3562  pop r8
00007986e0dd3564  pop rsi
00007986e0dd3565  pop rdi
00007986e0dd3566  pop rdx
00007986e0dd3567  pop rcx
00007986e0dd3568  pop rax
00007986e0dd3569  add rsp, 0x08
00007986e0dd356d  jmp 0x00007986E0DCFEF1
00007986e0dd3572  sub rsp, 0x08
00007986e0dd3576  push rax
00007986e0dd3577  push rcx
00007986e0dd3578  push rdx
00007986e0dd3579  push rdi
00007986e0dd357a  push rsi
00007986e0dd357b  push r8
00007986e0dd357d  push r9
00007986e0dd357f  push r10
00007986e0dd3581  push r11
00007986e0dd3583  sub rsp, 0xF0
00007986e0dd358a  vmovaps [rsp], xmm0
00007986e0dd358f  vmovaps [rsp+0x10], xmm1
00007986e0dd3595  vmovaps [rsp+0x20], xmm2
00007986e0dd359b  vmovaps [rsp+0x30], xmm3
00007986e0dd35a1  vmovaps [rsp+0x40], xmm4
00007986e0dd35a7  vmovaps [rsp+0x50], xmm5
00007986e0dd35ad  vmovaps [rsp+0x60], xmm7
00007986e0dd35b3  vmovaps [rsp+0x70], xmm8
00007986e0dd35b9  vmovaps [rsp+0x80], xmm9
00007986e0dd35c2  vmovaps [rsp+0x90], xmm10
00007986e0dd35cb  vmovaps [rsp+0xA0], xmm11
00007986e0dd35d4  vmovaps [rsp+0xB0], xmm12
00007986e0dd35dd  vmovaps [rsp+0xC0], xmm13
00007986e0dd35e6  vmovaps [rsp+0xD0], xmm14
00007986e0dd35ef  vmovaps [rsp+0xE0], xmm15
00007986e0dd35f8  sub rsp, 0x30
00007986e0dd35fc  movaps [rsp], xmm6
00007986e0dd3600  movaps [rsp+0x10], xmm9
00007986e0dd3606  movaps [rsp+0x20], xmm12
00007986e0dd360c  lea rdi, [rsp]
00007986e0dd3610  mov esi, 0x00
00007986e0dd3615  mov rax, 0x5652C689F530
00007986e0dd361f  call rax
00007986e0dd3621  movaps xmm6, [rsp]
00007986e0dd3625  add rsp, 0x30
00007986e0dd3629  vmovaps xmm0, [rsp]
00007986e0dd362e  vmovaps xmm1, [rsp+0x10]
00007986e0dd3634  vmovaps xmm2, [rsp+0x20]
00007986e0dd363a  vmovaps xmm3, [rsp+0x30]
00007986e0dd3640  vmovaps xmm4, [rsp+0x40]
00007986e0dd3646  vmovaps xmm5, [rsp+0x50]
00007986e0dd364c  vmovaps xmm7, [rsp+0x60]
00007986e0dd3652  vmovaps xmm8, [rsp+0x70]
00007986e0dd3658  vmovaps xmm9, [rsp+0x80]
00007986e0dd3661  vmovaps xmm10, [rsp+0x90]
00007986e0dd366a  vmovaps xmm11, [rsp+0xA0]
00007986e0dd3673  vmovaps xmm12, [rsp+0xB0]
00007986e0dd367c  vmovaps xmm13, [rsp+0xC0]
00007986e0dd3685  vmovaps xmm14, [rsp+0xD0]
00007986e0dd368e  vmovaps xmm15, [rsp+0xE0]
00007986e0dd3697  add rsp, 0xF0
00007986e0dd369e  pop r11
00007986e0dd36a0  pop r10
00007986e0dd36a2  pop r9
00007986e0dd36a4  pop r8
00007986e0dd36a6  pop rsi
00007986e0dd36a7  pop rdi
00007986e0dd36a8  pop rdx
00007986e0dd36a9  pop rcx
00007986e0dd36aa  pop rax
00007986e0dd36ab  add rsp, 0x08
00007986e0dd36af  jmp 0x00007986E0DCFF19
00007986e0dd36b4  sub rsp, 0x08
00007986e0dd36b8  push rax
00007986e0dd36b9  push rcx
00007986e0dd36ba  push rdx
00007986e0dd36bb  push rdi
00007986e0dd36bc  push rsi
00007986e0dd36bd  push r8
00007986e0dd36bf  push r9
00007986e0dd36c1  push r10
00007986e0dd36c3  push r11
00007986e0dd36c5  sub rsp, 0xF0
00007986e0dd36cc  vmovaps [rsp], xmm0
00007986e0dd36d1  vmovaps [rsp+0x10], xmm1
00007986e0dd36d7  vmovaps [rsp+0x20], xmm2
00007986e0dd36dd  vmovaps [rsp+0x30], xmm3
00007986e0dd36e3  vmovaps [rsp+0x40], xmm4
00007986e0dd36e9  vmovaps [rsp+0x50], xmm5
00007986e0dd36ef  vmovaps [rsp+0x60], xmm6
00007986e0dd36f5  vmovaps [rsp+0x70], xmm7
00007986e0dd36fb  vmovaps [rsp+0x80], xmm8
00007986e0dd3704  vmovaps [rsp+0x90], xmm9
00007986e0dd370d  vmovaps [rsp+0xA0], xmm10
00007986e0dd3716  vmovaps [rsp+0xB0], xmm11
00007986e0dd371f  vmovaps [rsp+0xC0], xmm13
00007986e0dd3728  vmovaps [rsp+0xD0], xmm14
00007986e0dd3731  vmovaps [rsp+0xE0], xmm15
00007986e0dd373a  sub rsp, 0x30
00007986e0dd373e  movaps [rsp], xmm12
00007986e0dd3743  movaps [rsp+0x10], xmm15
00007986e0dd3749  movaps [rsp+0x20], xmm13
00007986e0dd374f  lea rdi, [rsp]
00007986e0dd3753  mov esi, 0x00
00007986e0dd3758  mov rax, 0x5652C689F530
00007986e0dd3762  call rax
00007986e0dd3764  movaps xmm12, [rsp]
00007986e0dd3769  add rsp, 0x30
00007986e0dd376d  vmovaps xmm0, [rsp]
00007986e0dd3772  vmovaps xmm1, [rsp+0x10]
00007986e0dd3778  vmovaps xmm2, [rsp+0x20]
00007986e0dd377e  vmovaps xmm3, [rsp+0x30]
00007986e0dd3784  vmovaps xmm4, [rsp+0x40]
00007986e0dd378a  vmovaps xmm5, [rsp+0x50]
00007986e0dd3790  vmovaps xmm6, [rsp+0x60]
00007986e0dd3796  vmovaps xmm7, [rsp+0x70]
00007986e0dd379c  vmovaps xmm8, [rsp+0x80]
00007986e0dd37a5  vmovaps xmm9, [rsp+0x90]
00007986e0dd37ae  vmovaps xmm10, [rsp+0xA0]
00007986e0dd37b7  vmovaps xmm11, [rsp+0xB0]
00007986e0dd37c0  vmovaps xmm13, [rsp+0xC0]
00007986e0dd37c9  vmovaps xmm14, [rsp+0xD0]
00007986e0dd37d2  vmovaps xmm15, [rsp+0xE0]
00007986e0dd37db  add rsp, 0xF0
00007986e0dd37e2  pop r11
00007986e0dd37e4  pop r10
00007986e0dd37e6  pop r9
00007986e0dd37e8  pop r8
00007986e0dd37ea  pop rsi
00007986e0dd37eb  pop rdi
00007986e0dd37ec  pop rdx
00007986e0dd37ed  pop rcx
00007986e0dd37ee  pop rax
00007986e0dd37ef  add rsp, 0x08
00007986e0dd37f3  jmp 0x00007986E0DCFF34
00007986e0dd37f8  sub rsp, 0x08
00007986e0dd37fc  push rax
00007986e0dd37fd  push rcx
00007986e0dd37fe  push rdx
00007986e0dd37ff  push rdi
00007986e0dd3800  push rsi
00007986e0dd3801  push r8
00007986e0dd3803  push r9
00007986e0dd3805  push r10
00007986e0dd3807  push r11
00007986e0dd3809  sub rsp, 0xF0
00007986e0dd3810  vmovaps [rsp], xmm0
00007986e0dd3815  vmovaps [rsp+0x10], xmm1
00007986e0dd381b  vmovaps [rsp+0x20], xmm2
00007986e0dd3821  vmovaps [rsp+0x30], xmm3
00007986e0dd3827  vmovaps [rsp+0x40], xmm4
00007986e0dd382d  vmovaps [rsp+0x50], xmm5
00007986e0dd3833  vmovaps [rsp+0x60], xmm6
00007986e0dd3839  vmovaps [rsp+0x70], xmm7
00007986e0dd383f  vmovaps [rsp+0x80], xmm8
00007986e0dd3848  vmovaps [rsp+0x90], xmm9
00007986e0dd3851  vmovaps [rsp+0xA0], xmm10
00007986e0dd385a  vmovaps [rsp+0xB0], xmm11
00007986e0dd3863  vmovaps [rsp+0xC0], xmm12
00007986e0dd386c  vmovaps [rsp+0xD0], xmm13
00007986e0dd3875  vmovaps [rsp+0xE0], xmm14
00007986e0dd387e  sub rsp, 0x30
00007986e0dd3882  movaps [rsp], xmm15
00007986e0dd3887  movaps [rsp+0x10], xmm13
00007986e0dd388d  movaps [rsp+0x20], xmm10
00007986e0dd3893  lea rdi, [rsp]
00007986e0dd3897  mov esi, 0x00
00007986e0dd389c  mov rax, 0x5652C689F530
00007986e0dd38a6  call rax
00007986e0dd38a8  movaps xmm15, [rsp]
00007986e0dd38ad  add rsp, 0x30
00007986e0dd38b1  vmovaps xmm0, [rsp]
00007986e0dd38b6  vmovaps xmm1, [rsp+0x10]
00007986e0dd38bc  vmovaps xmm2, [rsp+0x20]
00007986e0dd38c2  vmovaps xmm3, [rsp+0x30]
00007986e0dd38c8  vmovaps xmm4, [rsp+0x40]
00007986e0dd38ce  vmovaps xmm5, [rsp+0x50]
00007986e0dd38d4  vmovaps xmm6, [rsp+0x60]
00007986e0dd38da  vmovaps xmm7, [rsp+0x70]
00007986e0dd38e0  vmovaps xmm8, [rsp+0x80]
00007986e0dd38e9  vmovaps xmm9, [rsp+0x90]
00007986e0dd38f2  vmovaps xmm10, [rsp+0xA0]
00007986e0dd38fb  vmovaps xmm11, [rsp+0xB0]
00007986e0dd3904  vmovaps xmm12, [rsp+0xC0]
00007986e0dd390d  vmovaps xmm13, [rsp+0xD0]
00007986e0dd3916  vmovaps xmm14, [rsp+0xE0]
00007986e0dd391f  add rsp, 0xF0
00007986e0dd3926  pop r11
00007986e0dd3928  pop r10
00007986e0dd392a  pop r9
00007986e0dd392c  pop r8
00007986e0dd392e  pop rsi
00007986e0dd392f  pop rdi
00007986e0dd3930  pop rdx
00007986e0dd3931  pop rcx
00007986e0dd3932  pop rax
00007986e0dd3933  add rsp, 0x08
00007986e0dd3937  jmp 0x00007986E0DCFF55
00007986e0dd393c  call 0x00007986E0C0C260
00007986e0dd3941  jmp 0x00007986E0DCFFB0
00007986e0dd3946  sub rsp, 0x08
00007986e0dd394a  push rax
00007986e0dd394b  push rcx
00007986e0dd394c  push rdx
00007986e0dd394d  push rdi
00007986e0dd394e  push rsi
00007986e0dd394f  push r8
00007986e0dd3951  push r9
00007986e0dd3953  push r10
00007986e0dd3955  push r11
00007986e0dd3957  sub rsp, 0xF0
00007986e0dd395e  vmovaps [rsp], xmm0
00007986e0dd3963  vmovaps [rsp+0x10], xmm1
00007986e0dd3969  vmovaps [rsp+0x20], xmm2
00007986e0dd396f  vmovaps [rsp+0x30], xmm3
00007986e0dd3975  vmovaps [rsp+0x40], xmm4
00007986e0dd397b  vmovaps [rsp+0x50], xmm5
00007986e0dd3981  vmovaps [rsp+0x60], xmm6
00007986e0dd3987  vmovaps [rsp+0x70], xmm7
00007986e0dd398d  vmovaps [rsp+0x80], xmm8
00007986e0dd3996  vmovaps [rsp+0x90], xmm10
00007986e0dd399f  vmovaps [rsp+0xA0], xmm11
00007986e0dd39a8  vmovaps [rsp+0xB0], xmm12
00007986e0dd39b1  vmovaps [rsp+0xC0], xmm13
00007986e0dd39ba  vmovaps [rsp+0xD0], xmm14
00007986e0dd39c3  vmovaps [rsp+0xE0], xmm15
00007986e0dd39cc  sub rsp, 0x30
00007986e0dd39d0  movaps [rsp], xmm9
00007986e0dd39d5  movaps [rsp+0x10], xmm8
00007986e0dd39db  movaps [rsp+0x20], xmm10
00007986e0dd39e1  lea rdi, [rsp]
00007986e0dd39e5  mov esi, 0x00
00007986e0dd39ea  mov rax, 0x5652C689F530
00007986e0dd39f4  call rax
00007986e0dd39f6  movaps xmm9, [rsp]
00007986e0dd39fb  add rsp, 0x30
00007986e0dd39ff  vmovaps xmm0, [rsp]
00007986e0dd3a04  vmovaps xmm1, [rsp+0x10]
00007986e0dd3a0a  vmovaps xmm2, [rsp+0x20]
00007986e0dd3a10  vmovaps xmm3, [rsp+0x30]
00007986e0dd3a16  vmovaps xmm4, [rsp+0x40]
00007986e0dd3a1c  vmovaps xmm5, [rsp+0x50]
00007986e0dd3a22  vmovaps xmm6, [rsp+0x60]
00007986e0dd3a28  vmovaps xmm7, [rsp+0x70]
00007986e0dd3a2e  vmovaps xmm8, [rsp+0x80]
00007986e0dd3a37  vmovaps xmm10, [rsp+0x90]
00007986e0dd3a40  vmovaps xmm11, [rsp+0xA0]
00007986e0dd3a49  vmovaps xmm12, [rsp+0xB0]
00007986e0dd3a52  vmovaps xmm13, [rsp+0xC0]
00007986e0dd3a5b  vmovaps xmm14, [rsp+0xD0]
00007986e0dd3a64  vmovaps xmm15, [rsp+0xE0]
00007986e0dd3a6d  add rsp, 0xF0
00007986e0dd3a74  pop r11
00007986e0dd3a76  pop r10
00007986e0dd3a78  pop r9
00007986e0dd3a7a  pop r8
00007986e0dd3a7c  pop rsi
00007986e0dd3a7d  pop rdi
00007986e0dd3a7e  pop rdx
00007986e0dd3a7f  pop rcx
00007986e0dd3a80  pop rax
00007986e0dd3a81  add rsp, 0x08
00007986e0dd3a85  jmp 0x00007986E0DCFFE1
00007986e0dd3a8a  sub rsp, 0x08
00007986e0dd3a8e  push rax
00007986e0dd3a8f  push rcx
00007986e0dd3a90  push rdx
00007986e0dd3a91  push rdi
00007986e0dd3a92  push rsi
00007986e0dd3a93  push r8
00007986e0dd3a95  push r9
00007986e0dd3a97  push r10
00007986e0dd3a99  push r11
00007986e0dd3a9b  sub rsp, 0xF0
00007986e0dd3aa2  vmovaps [rsp], xmm0
00007986e0dd3aa7  vmovaps [rsp+0x10], xmm1
00007986e0dd3aad  vmovaps [rsp+0x20], xmm2
00007986e0dd3ab3  vmovaps [rsp+0x30], xmm3
00007986e0dd3ab9  vmovaps [rsp+0x40], xmm4
00007986e0dd3abf  vmovaps [rsp+0x50], xmm5
00007986e0dd3ac5  vmovaps [rsp+0x60], xmm6
00007986e0dd3acb  vmovaps [rsp+0x70], xmm7
00007986e0dd3ad1  vmovaps [rsp+0x80], xmm8
00007986e0dd3ada  vmovaps [rsp+0x90], xmm9
00007986e0dd3ae3  vmovaps [rsp+0xA0], xmm11
00007986e0dd3aec  vmovaps [rsp+0xB0], xmm12
00007986e0dd3af5  vmovaps [rsp+0xC0], xmm13
00007986e0dd3afe  vmovaps [rsp+0xD0], xmm14
00007986e0dd3b07  vmovaps [rsp+0xE0], xmm15
00007986e0dd3b10  sub rsp, 0x30
00007986e0dd3b14  movaps [rsp], xmm10
00007986e0dd3b19  movaps [rsp+0x10], xmm1
00007986e0dd3b1e  movaps [rsp+0x20], xmm11
00007986e0dd3b24  lea rdi, [rsp]
00007986e0dd3b28  mov esi, 0x00
00007986e0dd3b2d  mov rax, 0x5652C689F530
00007986e0dd3b37  call rax
00007986e0dd3b39  movaps xmm10, [rsp]
00007986e0dd3b3e  add rsp, 0x30
00007986e0dd3b42  vmovaps xmm0, [rsp]
00007986e0dd3b47  vmovaps xmm1, [rsp+0x10]
00007986e0dd3b4d  vmovaps xmm2, [rsp+0x20]
00007986e0dd3b53  vmovaps xmm3, [rsp+0x30]
00007986e0dd3b59  vmovaps xmm4, [rsp+0x40]
00007986e0dd3b5f  vmovaps xmm5, [rsp+0x50]
00007986e0dd3b65  vmovaps xmm6, [rsp+0x60]
00007986e0dd3b6b  vmovaps xmm7, [rsp+0x70]
00007986e0dd3b71  vmovaps xmm8, [rsp+0x80]
00007986e0dd3b7a  vmovaps xmm9, [rsp+0x90]
00007986e0dd3b83  vmovaps xmm11, [rsp+0xA0]
00007986e0dd3b8c  vmovaps xmm12, [rsp+0xB0]
00007986e0dd3b95  vmovaps xmm13, [rsp+0xC0]
00007986e0dd3b9e  vmovaps xmm14, [rsp+0xD0]
00007986e0dd3ba7  vmovaps xmm15, [rsp+0xE0]
00007986e0dd3bb0  add rsp, 0xF0
00007986e0dd3bb7  pop r11
00007986e0dd3bb9  pop r10
00007986e0dd3bbb  pop r9
00007986e0dd3bbd  pop r8
00007986e0dd3bbf  pop rsi
00007986e0dd3bc0  pop rdi
00007986e0dd3bc1  pop rdx
00007986e0dd3bc2  pop rcx
00007986e0dd3bc3  pop rax
00007986e0dd3bc4  add rsp, 0x08
00007986e0dd3bc8  jmp 0x00007986E0DCFFFC
00007986e0dd3bcd  sub rsp, 0x08
00007986e0dd3bd1  push rax
00007986e0dd3bd2  push rcx
00007986e0dd3bd3  push rdx
00007986e0dd3bd4  push rdi
00007986e0dd3bd5  push rsi
00007986e0dd3bd6  push r8
00007986e0dd3bd8  push r9
00007986e0dd3bda  push r10
00007986e0dd3bdc  push r11
00007986e0dd3bde  sub rsp, 0xF0
00007986e0dd3be5  vmovaps [rsp], xmm0
00007986e0dd3bea  vmovaps [rsp+0x10], xmm2
00007986e0dd3bf0  vmovaps [rsp+0x20], xmm3
00007986e0dd3bf6  vmovaps [rsp+0x30], xmm4
00007986e0dd3bfc  vmovaps [rsp+0x40], xmm5
00007986e0dd3c02  vmovaps [rsp+0x50], xmm6
00007986e0dd3c08  vmovaps [rsp+0x60], xmm7
00007986e0dd3c0e  vmovaps [rsp+0x70], xmm8
00007986e0dd3c14  vmovaps [rsp+0x80], xmm9
00007986e0dd3c1d  vmovaps [rsp+0x90], xmm10
00007986e0dd3c26  vmovaps [rsp+0xA0], xmm11
00007986e0dd3c2f  vmovaps [rsp+0xB0], xmm12
00007986e0dd3c38  vmovaps [rsp+0xC0], xmm13
00007986e0dd3c41  vmovaps [rsp+0xD0], xmm14
00007986e0dd3c4a  vmovaps [rsp+0xE0], xmm15
00007986e0dd3c53  sub rsp, 0x30
00007986e0dd3c57  movaps [rsp], xmm1
00007986e0dd3c5b  movaps [rsp+0x10], xmm14
00007986e0dd3c61  movaps [rsp+0x20], xmm6
00007986e0dd3c66  lea rdi, [rsp]
00007986e0dd3c6a  mov esi, 0x00
00007986e0dd3c6f  mov rax, 0x5652C689F530
00007986e0dd3c79  call rax
00007986e0dd3c7b  movaps xmm1, [rsp]
00007986e0dd3c7f  add rsp, 0x30
00007986e0dd3c83  vmovaps xmm0, [rsp]
00007986e0dd3c88  vmovaps xmm2, [rsp+0x10]
00007986e0dd3c8e  vmovaps xmm3, [rsp+0x20]
00007986e0dd3c94  vmovaps xmm4, [rsp+0x30]
00007986e0dd3c9a  vmovaps xmm5, [rsp+0x40]
00007986e0dd3ca0  vmovaps xmm6, [rsp+0x50]
00007986e0dd3ca6  vmovaps xmm7, [rsp+0x60]
00007986e0dd3cac  vmovaps xmm8, [rsp+0x70]
00007986e0dd3cb2  vmovaps xmm9, [rsp+0x80]
00007986e0dd3cbb  vmovaps xmm10, [rsp+0x90]
00007986e0dd3cc4  vmovaps xmm11, [rsp+0xA0]
00007986e0dd3ccd  vmovaps xmm12, [rsp+0xB0]
00007986e0dd3cd6  vmovaps xmm13, [rsp+0xC0]
00007986e0dd3cdf  vmovaps xmm14, [rsp+0xD0]
00007986e0dd3ce8  vmovaps xmm15, [rsp+0xE0]
00007986e0dd3cf1  add rsp, 0xF0
00007986e0dd3cf8  pop r11
00007986e0dd3cfa  pop r10
00007986e0dd3cfc  pop r9
00007986e0dd3cfe  pop r8
00007986e0dd3d00  pop rsi
00007986e0dd3d01  pop rdi
00007986e0dd3d02  pop rdx
00007986e0dd3d03  pop rcx
00007986e0dd3d04  pop rax
00007986e0dd3d05  add rsp, 0x08
00007986e0dd3d09  jmp 0x00007986E0DD0015
00007986e0dd3d0e  sub rsp, 0x08
00007986e0dd3d12  push rax
00007986e0dd3d13  push rcx
00007986e0dd3d14  push rdx
00007986e0dd3d15  push rdi
00007986e0dd3d16  push rsi
00007986e0dd3d17  push r8
00007986e0dd3d19  push r9
00007986e0dd3d1b  push r10
00007986e0dd3d1d  push r11
00007986e0dd3d1f  sub rsp, 0xF0
00007986e0dd3d26  vmovaps [rsp], xmm0
00007986e0dd3d2b  vmovaps [rsp+0x10], xmm1
00007986e0dd3d31  vmovaps [rsp+0x20], xmm2
00007986e0dd3d37  vmovaps [rsp+0x30], xmm3
00007986e0dd3d3d  vmovaps [rsp+0x40], xmm4
00007986e0dd3d43  vmovaps [rsp+0x50], xmm5
00007986e0dd3d49  vmovaps [rsp+0x60], xmm6
00007986e0dd3d4f  vmovaps [rsp+0x70], xmm7
00007986e0dd3d55  vmovaps [rsp+0x80], xmm8
00007986e0dd3d5e  vmovaps [rsp+0x90], xmm9
00007986e0dd3d67  vmovaps [rsp+0xA0], xmm10
00007986e0dd3d70  vmovaps [rsp+0xB0], xmm12
00007986e0dd3d79  vmovaps [rsp+0xC0], xmm13
00007986e0dd3d82  vmovaps [rsp+0xD0], xmm14
00007986e0dd3d8b  vmovaps [rsp+0xE0], xmm15
00007986e0dd3d94  sub rsp, 0x30
00007986e0dd3d98  movaps [rsp], xmm11
00007986e0dd3d9d  movaps [rsp+0x10], xmm13
00007986e0dd3da3  movaps [rsp+0x20], xmm14
00007986e0dd3da9  lea rdi, [rsp]
00007986e0dd3dad  mov esi, 0x00
00007986e0dd3db2  mov rax, 0x5652C689F530
00007986e0dd3dbc  call rax
00007986e0dd3dbe  movaps xmm11, [rsp]
00007986e0dd3dc3  add rsp, 0x30
00007986e0dd3dc7  vmovaps xmm0, [rsp]
00007986e0dd3dcc  vmovaps xmm1, [rsp+0x10]
00007986e0dd3dd2  vmovaps xmm2, [rsp+0x20]
00007986e0dd3dd8  vmovaps xmm3, [rsp+0x30]
00007986e0dd3dde  vmovaps xmm4, [rsp+0x40]
00007986e0dd3de4  vmovaps xmm5, [rsp+0x50]
00007986e0dd3dea  vmovaps xmm6, [rsp+0x60]
00007986e0dd3df0  vmovaps xmm7, [rsp+0x70]
00007986e0dd3df6  vmovaps xmm8, [rsp+0x80]
00007986e0dd3dff  vmovaps xmm9, [rsp+0x90]
00007986e0dd3e08  vmovaps xmm10, [rsp+0xA0]
00007986e0dd3e11  vmovaps xmm12, [rsp+0xB0]
00007986e0dd3e1a  vmovaps xmm13, [rsp+0xC0]
00007986e0dd3e23  vmovaps xmm14, [rsp+0xD0]
00007986e0dd3e2c  vmovaps xmm15, [rsp+0xE0]
00007986e0dd3e35  add rsp, 0xF0
00007986e0dd3e3c  pop r11
00007986e0dd3e3e  pop r10
00007986e0dd3e40  pop r9
00007986e0dd3e42  pop r8
00007986e0dd3e44  pop rsi
00007986e0dd3e45  pop rdi
00007986e0dd3e46  pop rdx
00007986e0dd3e47  pop rcx
00007986e0dd3e48  pop rax
00007986e0dd3e49  add rsp, 0x08
00007986e0dd3e4d  jmp 0x00007986E0DD003F
00007986e0dd3e52  sub rsp, 0x08
00007986e0dd3e56  push rax
00007986e0dd3e57  push rcx
00007986e0dd3e58  push rdx
00007986e0dd3e59  push rdi
00007986e0dd3e5a  push rsi
00007986e0dd3e5b  push r8
00007986e0dd3e5d  push r9
00007986e0dd3e5f  push r10
00007986e0dd3e61  push r11
00007986e0dd3e63  sub rsp, 0xF0
00007986e0dd3e6a  vmovaps [rsp], xmm0
00007986e0dd3e6f  vmovaps [rsp+0x10], xmm1
00007986e0dd3e75  vmovaps [rsp+0x20], xmm2
00007986e0dd3e7b  vmovaps [rsp+0x30], xmm3
00007986e0dd3e81  vmovaps [rsp+0x40], xmm4
00007986e0dd3e87  vmovaps [rsp+0x50], xmm5
00007986e0dd3e8d  vmovaps [rsp+0x60], xmm6
00007986e0dd3e93  vmovaps [rsp+0x70], xmm7
00007986e0dd3e99  vmovaps [rsp+0x80], xmm8
00007986e0dd3ea2  vmovaps [rsp+0x90], xmm9
00007986e0dd3eab  vmovaps [rsp+0xA0], xmm10
00007986e0dd3eb4  vmovaps [rsp+0xB0], xmm11
00007986e0dd3ebd  vmovaps [rsp+0xC0], xmm12
00007986e0dd3ec6  vmovaps [rsp+0xD0], xmm14
00007986e0dd3ecf  vmovaps [rsp+0xE0], xmm15
00007986e0dd3ed8  sub rsp, 0x30
00007986e0dd3edc  movaps [rsp], xmm13
00007986e0dd3ee1  movaps [rsp+0x10], xmm8
00007986e0dd3ee7  movaps [rsp+0x20], xmm14
00007986e0dd3eed  lea rdi, [rsp]
00007986e0dd3ef1  mov esi, 0x00
00007986e0dd3ef6  mov rax, 0x5652C689F530
00007986e0dd3f00  call rax
00007986e0dd3f02  movaps xmm13, [rsp]
00007986e0dd3f07  add rsp, 0x30
00007986e0dd3f0b  vmovaps xmm0, [rsp]
00007986e0dd3f10  vmovaps xmm1, [rsp+0x10]
00007986e0dd3f16  vmovaps xmm2, [rsp+0x20]
00007986e0dd3f1c  vmovaps xmm3, [rsp+0x30]
00007986e0dd3f22  vmovaps xmm4, [rsp+0x40]
00007986e0dd3f28  vmovaps xmm5, [rsp+0x50]
00007986e0dd3f2e  vmovaps xmm6, [rsp+0x60]
00007986e0dd3f34  vmovaps xmm7, [rsp+0x70]
00007986e0dd3f3a  vmovaps xmm8, [rsp+0x80]
00007986e0dd3f43  vmovaps xmm9, [rsp+0x90]
00007986e0dd3f4c  vmovaps xmm10, [rsp+0xA0]
00007986e0dd3f55  vmovaps xmm11, [rsp+0xB0]
00007986e0dd3f5e  vmovaps xmm12, [rsp+0xC0]
00007986e0dd3f67  vmovaps xmm14, [rsp+0xD0]
00007986e0dd3f70  vmovaps xmm15, [rsp+0xE0]
00007986e0dd3f79  add rsp, 0xF0
00007986e0dd3f80  pop r11
00007986e0dd3f82  pop r10
00007986e0dd3f84  pop r9
00007986e0dd3f86  pop r8
00007986e0dd3f88  pop rsi
00007986e0dd3f89  pop rdi
00007986e0dd3f8a  pop rdx
00007986e0dd3f8b  pop rcx
00007986e0dd3f8c  pop rax
00007986e0dd3f8d  add rsp, 0x08
00007986e0dd3f91  jmp 0x00007986E0DD006E
00007986e0dd3f96  sub rsp, 0x08
00007986e0dd3f9a  push rax
00007986e0dd3f9b  push rcx
00007986e0dd3f9c  push rdx
00007986e0dd3f9d  push rdi
00007986e0dd3f9e  push rsi
00007986e0dd3f9f  push r8
00007986e0dd3fa1  push r9
00007986e0dd3fa3  push r10
00007986e0dd3fa5  push r11
00007986e0dd3fa7  sub rsp, 0xF0
00007986e0dd3fae  vmovaps [rsp], xmm0
00007986e0dd3fb3  vmovaps [rsp+0x10], xmm1
00007986e0dd3fb9  vmovaps [rsp+0x20], xmm2
00007986e0dd3fbf  vmovaps [rsp+0x30], xmm3
00007986e0dd3fc5  vmovaps [rsp+0x40], xmm4
00007986e0dd3fcb  vmovaps [rsp+0x50], xmm5
00007986e0dd3fd1  vmovaps [rsp+0x60], xmm6
00007986e0dd3fd7  vmovaps [rsp+0x70], xmm7
00007986e0dd3fdd  vmovaps [rsp+0x80], xmm9
00007986e0dd3fe6  vmovaps [rsp+0x90], xmm10
00007986e0dd3fef  vmovaps [rsp+0xA0], xmm11
00007986e0dd3ff8  vmovaps [rsp+0xB0], xmm12
00007986e0dd4001  vmovaps [rsp+0xC0], xmm13
00007986e0dd400a  vmovaps [rsp+0xD0], xmm14
00007986e0dd4013  vmovaps [rsp+0xE0], xmm15
00007986e0dd401c  sub rsp, 0x30
00007986e0dd4020  movaps [rsp], xmm8
00007986e0dd4025  movaps [rsp+0x10], xmm7
00007986e0dd402a  movaps [rsp+0x20], xmm14
00007986e0dd4030  lea rdi, [rsp]
00007986e0dd4034  mov esi, 0x00
00007986e0dd4039  mov rax, 0x5652C689F530
00007986e0dd4043  call rax
00007986e0dd4045  movaps xmm8, [rsp]
00007986e0dd404a  add rsp, 0x30
00007986e0dd404e  vmovaps xmm0, [rsp]
00007986e0dd4053  vmovaps xmm1, [rsp+0x10]
00007986e0dd4059  vmovaps xmm2, [rsp+0x20]
00007986e0dd405f  vmovaps xmm3, [rsp+0x30]
00007986e0dd4065  vmovaps xmm4, [rsp+0x40]
00007986e0dd406b  vmovaps xmm5, [rsp+0x50]
00007986e0dd4071  vmovaps xmm6, [rsp+0x60]
00007986e0dd4077  vmovaps xmm7, [rsp+0x70]
00007986e0dd407d  vmovaps xmm9, [rsp+0x80]
00007986e0dd4086  vmovaps xmm10, [rsp+0x90]
00007986e0dd408f  vmovaps xmm11, [rsp+0xA0]
00007986e0dd4098  vmovaps xmm12, [rsp+0xB0]
00007986e0dd40a1  vmovaps xmm13, [rsp+0xC0]
00007986e0dd40aa  vmovaps xmm14, [rsp+0xD0]
00007986e0dd40b3  vmovaps xmm15, [rsp+0xE0]
00007986e0dd40bc  add rsp, 0xF0
00007986e0dd40c3  pop r11
00007986e0dd40c5  pop r10
00007986e0dd40c7  pop r9
00007986e0dd40c9  pop r8
00007986e0dd40cb  pop rsi
00007986e0dd40cc  pop rdi
00007986e0dd40cd  pop rdx
00007986e0dd40ce  pop rcx
00007986e0dd40cf  pop rax
00007986e0dd40d0  add rsp, 0x08
00007986e0dd40d4  jmp 0x00007986E0DD0094
00007986e0dd40d9  sub rsp, 0x08
00007986e0dd40dd  push rax
00007986e0dd40de  push rcx
00007986e0dd40df  push rdx
00007986e0dd40e0  push rdi
00007986e0dd40e1  push rsi
00007986e0dd40e2  push r8
00007986e0dd40e4  push r9
00007986e0dd40e6  push r10
00007986e0dd40e8  push r11
00007986e0dd40ea  sub rsp, 0xF0
00007986e0dd40f1  vmovaps [rsp], xmm0
00007986e0dd40f6  vmovaps [rsp+0x10], xmm1
00007986e0dd40fc  vmovaps [rsp+0x20], xmm2
00007986e0dd4102  vmovaps [rsp+0x30], xmm3
00007986e0dd4108  vmovaps [rsp+0x40], xmm4
00007986e0dd410e  vmovaps [rsp+0x50], xmm5
00007986e0dd4114  vmovaps [rsp+0x60], xmm6
00007986e0dd411a  vmovaps [rsp+0x70], xmm7
00007986e0dd4120  vmovaps [rsp+0x80], xmm8
00007986e0dd4129  vmovaps [rsp+0x90], xmm9
00007986e0dd4132  vmovaps [rsp+0xA0], xmm10
00007986e0dd413b  vmovaps [rsp+0xB0], xmm11
00007986e0dd4144  vmovaps [rsp+0xC0], xmm12
00007986e0dd414d  vmovaps [rsp+0xD0], xmm13
00007986e0dd4156  vmovaps [rsp+0xE0], xmm15
00007986e0dd415f  sub rsp, 0x30
00007986e0dd4163  movaps [rsp], xmm14
00007986e0dd4168  movaps [rsp+0x10], xmm12
00007986e0dd416e  movaps [rsp+0x20], xmm9
00007986e0dd4174  lea rdi, [rsp]
00007986e0dd4178  mov esi, 0x00
00007986e0dd417d  mov rax, 0x5652C689F530
00007986e0dd4187  call rax
00007986e0dd4189  movaps xmm14, [rsp]
00007986e0dd418e  add rsp, 0x30
00007986e0dd4192  vmovaps xmm0, [rsp]
00007986e0dd4197  vmovaps xmm1, [rsp+0x10]
00007986e0dd419d  vmovaps xmm2, [rsp+0x20]
00007986e0dd41a3  vmovaps xmm3, [rsp+0x30]
00007986e0dd41a9  vmovaps xmm4, [rsp+0x40]
00007986e0dd41af  vmovaps xmm5, [rsp+0x50]
00007986e0dd41b5  vmovaps xmm6, [rsp+0x60]
00007986e0dd41bb  vmovaps xmm7, [rsp+0x70]
00007986e0dd41c1  vmovaps xmm8, [rsp+0x80]
00007986e0dd41ca  vmovaps xmm9, [rsp+0x90]
00007986e0dd41d3  vmovaps xmm10, [rsp+0xA0]
00007986e0dd41dc  vmovaps xmm11, [rsp+0xB0]
00007986e0dd41e5  vmovaps xmm12, [rsp+0xC0]
00007986e0dd41ee  vmovaps xmm13, [rsp+0xD0]
00007986e0dd41f7  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4200  add rsp, 0xF0
00007986e0dd4207  pop r11
00007986e0dd4209  pop r10
00007986e0dd420b  pop r9
00007986e0dd420d  pop r8
00007986e0dd420f  pop rsi
00007986e0dd4210  pop rdi
00007986e0dd4211  pop rdx
00007986e0dd4212  pop rcx
00007986e0dd4213  pop rax
00007986e0dd4214  add rsp, 0x08
00007986e0dd4218  jmp 0x00007986E0DD00AE
00007986e0dd421d  sub rsp, 0x08
00007986e0dd4221  push rax
00007986e0dd4222  push rcx
00007986e0dd4223  push rdx
00007986e0dd4224  push rdi
00007986e0dd4225  push rsi
00007986e0dd4226  push r8
00007986e0dd4228  push r9
00007986e0dd422a  push r10
00007986e0dd422c  push r11
00007986e0dd422e  sub rsp, 0xF0
00007986e0dd4235  vmovaps [rsp], xmm0
00007986e0dd423a  vmovaps [rsp+0x10], xmm1
00007986e0dd4240  vmovaps [rsp+0x20], xmm2
00007986e0dd4246  vmovaps [rsp+0x30], xmm3
00007986e0dd424c  vmovaps [rsp+0x40], xmm4
00007986e0dd4252  vmovaps [rsp+0x50], xmm5
00007986e0dd4258  vmovaps [rsp+0x60], xmm6
00007986e0dd425e  vmovaps [rsp+0x70], xmm7
00007986e0dd4264  vmovaps [rsp+0x80], xmm8
00007986e0dd426d  vmovaps [rsp+0x90], xmm10
00007986e0dd4276  vmovaps [rsp+0xA0], xmm11
00007986e0dd427f  vmovaps [rsp+0xB0], xmm12
00007986e0dd4288  vmovaps [rsp+0xC0], xmm13
00007986e0dd4291  vmovaps [rsp+0xD0], xmm14
00007986e0dd429a  vmovaps [rsp+0xE0], xmm15
00007986e0dd42a3  sub rsp, 0x30
00007986e0dd42a7  movaps [rsp], xmm9
00007986e0dd42ac  movaps [rsp+0x10], xmm7
00007986e0dd42b1  movaps [rsp+0x20], xmm12
00007986e0dd42b7  lea rdi, [rsp]
00007986e0dd42bb  mov esi, 0x00
00007986e0dd42c0  mov rax, 0x5652C689F530
00007986e0dd42ca  call rax
00007986e0dd42cc  movaps xmm9, [rsp]
00007986e0dd42d1  add rsp, 0x30
00007986e0dd42d5  vmovaps xmm0, [rsp]
00007986e0dd42da  vmovaps xmm1, [rsp+0x10]
00007986e0dd42e0  vmovaps xmm2, [rsp+0x20]
00007986e0dd42e6  vmovaps xmm3, [rsp+0x30]
00007986e0dd42ec  vmovaps xmm4, [rsp+0x40]
00007986e0dd42f2  vmovaps xmm5, [rsp+0x50]
00007986e0dd42f8  vmovaps xmm6, [rsp+0x60]
00007986e0dd42fe  vmovaps xmm7, [rsp+0x70]
00007986e0dd4304  vmovaps xmm8, [rsp+0x80]
00007986e0dd430d  vmovaps xmm10, [rsp+0x90]
00007986e0dd4316  vmovaps xmm11, [rsp+0xA0]
00007986e0dd431f  vmovaps xmm12, [rsp+0xB0]
00007986e0dd4328  vmovaps xmm13, [rsp+0xC0]
00007986e0dd4331  vmovaps xmm14, [rsp+0xD0]
00007986e0dd433a  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4343  add rsp, 0xF0
00007986e0dd434a  pop r11
00007986e0dd434c  pop r10
00007986e0dd434e  pop r9
00007986e0dd4350  pop r8
00007986e0dd4352  pop rsi
00007986e0dd4353  pop rdi
00007986e0dd4354  pop rdx
00007986e0dd4355  pop rcx
00007986e0dd4356  pop rax
00007986e0dd4357  add rsp, 0x08
00007986e0dd435b  jmp 0x00007986E0DD00DD
00007986e0dd4360  sub rsp, 0x08
00007986e0dd4364  push rax
00007986e0dd4365  push rcx
00007986e0dd4366  push rdx
00007986e0dd4367  push rdi
00007986e0dd4368  push rsi
00007986e0dd4369  push r8
00007986e0dd436b  push r9
00007986e0dd436d  push r10
00007986e0dd436f  push r11
00007986e0dd4371  sub rsp, 0xF0
00007986e0dd4378  vmovaps [rsp], xmm0
00007986e0dd437d  vmovaps [rsp+0x10], xmm1
00007986e0dd4383  vmovaps [rsp+0x20], xmm2
00007986e0dd4389  vmovaps [rsp+0x30], xmm3
00007986e0dd438f  vmovaps [rsp+0x40], xmm4
00007986e0dd4395  vmovaps [rsp+0x50], xmm5
00007986e0dd439b  vmovaps [rsp+0x60], xmm6
00007986e0dd43a1  vmovaps [rsp+0x70], xmm7
00007986e0dd43a7  vmovaps [rsp+0x80], xmm8
00007986e0dd43b0  vmovaps [rsp+0x90], xmm9
00007986e0dd43b9  vmovaps [rsp+0xA0], xmm10
00007986e0dd43c2  vmovaps [rsp+0xB0], xmm11
00007986e0dd43cb  vmovaps [rsp+0xC0], xmm13
00007986e0dd43d4  vmovaps [rsp+0xD0], xmm14
00007986e0dd43dd  vmovaps [rsp+0xE0], xmm15
00007986e0dd43e6  sub rsp, 0x30
00007986e0dd43ea  movaps [rsp], xmm12
00007986e0dd43ef  movaps [rsp+0x10], xmm15
00007986e0dd43f5  movaps [rsp+0x20], xmm11
00007986e0dd43fb  lea rdi, [rsp]
00007986e0dd43ff  mov esi, 0x00
00007986e0dd4404  mov rax, 0x5652C689F530
00007986e0dd440e  call rax
00007986e0dd4410  movaps xmm12, [rsp]
00007986e0dd4415  add rsp, 0x30
00007986e0dd4419  vmovaps xmm0, [rsp]
00007986e0dd441e  vmovaps xmm1, [rsp+0x10]
00007986e0dd4424  vmovaps xmm2, [rsp+0x20]
00007986e0dd442a  vmovaps xmm3, [rsp+0x30]
00007986e0dd4430  vmovaps xmm4, [rsp+0x40]
00007986e0dd4436  vmovaps xmm5, [rsp+0x50]
00007986e0dd443c  vmovaps xmm6, [rsp+0x60]
00007986e0dd4442  vmovaps xmm7, [rsp+0x70]
00007986e0dd4448  vmovaps xmm8, [rsp+0x80]
00007986e0dd4451  vmovaps xmm9, [rsp+0x90]
00007986e0dd445a  vmovaps xmm10, [rsp+0xA0]
00007986e0dd4463  vmovaps xmm11, [rsp+0xB0]
00007986e0dd446c  vmovaps xmm13, [rsp+0xC0]
00007986e0dd4475  vmovaps xmm14, [rsp+0xD0]
00007986e0dd447e  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4487  add rsp, 0xF0
00007986e0dd448e  pop r11
00007986e0dd4490  pop r10
00007986e0dd4492  pop r9
00007986e0dd4494  pop r8
00007986e0dd4496  pop rsi
00007986e0dd4497  pop rdi
00007986e0dd4498  pop rdx
00007986e0dd4499  pop rcx
00007986e0dd449a  pop rax
00007986e0dd449b  add rsp, 0x08
00007986e0dd449f  jmp 0x00007986E0DD00F7
00007986e0dd44a4  sub rsp, 0x08
00007986e0dd44a8  push rax
00007986e0dd44a9  push rcx
00007986e0dd44aa  push rdx
00007986e0dd44ab  push rdi
00007986e0dd44ac  push rsi
00007986e0dd44ad  push r8
00007986e0dd44af  push r9
00007986e0dd44b1  push r10
00007986e0dd44b3  push r11
00007986e0dd44b5  sub rsp, 0xF0
00007986e0dd44bc  vmovaps [rsp], xmm0
00007986e0dd44c1  vmovaps [rsp+0x10], xmm1
00007986e0dd44c7  vmovaps [rsp+0x20], xmm2
00007986e0dd44cd  vmovaps [rsp+0x30], xmm3
00007986e0dd44d3  vmovaps [rsp+0x40], xmm4
00007986e0dd44d9  vmovaps [rsp+0x50], xmm5
00007986e0dd44df  vmovaps [rsp+0x60], xmm6
00007986e0dd44e5  vmovaps [rsp+0x70], xmm7
00007986e0dd44eb  vmovaps [rsp+0x80], xmm8
00007986e0dd44f4  vmovaps [rsp+0x90], xmm9
00007986e0dd44fd  vmovaps [rsp+0xA0], xmm10
00007986e0dd4506  vmovaps [rsp+0xB0], xmm12
00007986e0dd450f  vmovaps [rsp+0xC0], xmm13
00007986e0dd4518  vmovaps [rsp+0xD0], xmm14
00007986e0dd4521  vmovaps [rsp+0xE0], xmm15
00007986e0dd452a  sub rsp, 0x30
00007986e0dd452e  movaps [rsp], xmm11
00007986e0dd4533  movaps [rsp+0x10], xmm7
00007986e0dd4538  movaps [rsp+0x20], xmm15
00007986e0dd453e  lea rdi, [rsp]
00007986e0dd4542  mov esi, 0x00
00007986e0dd4547  mov rax, 0x5652C689F530
00007986e0dd4551  call rax
00007986e0dd4553  movaps xmm11, [rsp]
00007986e0dd4558  add rsp, 0x30
00007986e0dd455c  vmovaps xmm0, [rsp]
00007986e0dd4561  vmovaps xmm1, [rsp+0x10]
00007986e0dd4567  vmovaps xmm2, [rsp+0x20]
00007986e0dd456d  vmovaps xmm3, [rsp+0x30]
00007986e0dd4573  vmovaps xmm4, [rsp+0x40]
00007986e0dd4579  vmovaps xmm5, [rsp+0x50]
00007986e0dd457f  vmovaps xmm6, [rsp+0x60]
00007986e0dd4585  vmovaps xmm7, [rsp+0x70]
00007986e0dd458b  vmovaps xmm8, [rsp+0x80]
00007986e0dd4594  vmovaps xmm9, [rsp+0x90]
00007986e0dd459d  vmovaps xmm10, [rsp+0xA0]
00007986e0dd45a6  vmovaps xmm12, [rsp+0xB0]
00007986e0dd45af  vmovaps xmm13, [rsp+0xC0]
00007986e0dd45b8  vmovaps xmm14, [rsp+0xD0]
00007986e0dd45c1  vmovaps xmm15, [rsp+0xE0]
00007986e0dd45ca  add rsp, 0xF0
00007986e0dd45d1  pop r11
00007986e0dd45d3  pop r10
00007986e0dd45d5  pop r9
00007986e0dd45d7  pop r8
00007986e0dd45d9  pop rsi
00007986e0dd45da  pop rdi
00007986e0dd45db  pop rdx
00007986e0dd45dc  pop rcx
00007986e0dd45dd  pop rax
00007986e0dd45de  add rsp, 0x08
00007986e0dd45e2  jmp 0x00007986E0DD0123
00007986e0dd45e7  sub rsp, 0x08
00007986e0dd45eb  push rax
00007986e0dd45ec  push rcx
00007986e0dd45ed  push rdx
00007986e0dd45ee  push rdi
00007986e0dd45ef  push rsi
00007986e0dd45f0  push r8
00007986e0dd45f2  push r9
00007986e0dd45f4  push r10
00007986e0dd45f6  push r11
00007986e0dd45f8  sub rsp, 0xF0
00007986e0dd45ff  vmovaps [rsp], xmm0
00007986e0dd4604  vmovaps [rsp+0x10], xmm1
00007986e0dd460a  vmovaps [rsp+0x20], xmm2
00007986e0dd4610  vmovaps [rsp+0x30], xmm3
00007986e0dd4616  vmovaps [rsp+0x40], xmm4
00007986e0dd461c  vmovaps [rsp+0x50], xmm5
00007986e0dd4622  vmovaps [rsp+0x60], xmm6
00007986e0dd4628  vmovaps [rsp+0x70], xmm7
00007986e0dd462e  vmovaps [rsp+0x80], xmm8
00007986e0dd4637  vmovaps [rsp+0x90], xmm9
00007986e0dd4640  vmovaps [rsp+0xA0], xmm10
00007986e0dd4649  vmovaps [rsp+0xB0], xmm11
00007986e0dd4652  vmovaps [rsp+0xC0], xmm12
00007986e0dd465b  vmovaps [rsp+0xD0], xmm13
00007986e0dd4664  vmovaps [rsp+0xE0], xmm14
00007986e0dd466d  sub rsp, 0x30
00007986e0dd4671  movaps [rsp], xmm15
00007986e0dd4676  movaps [rsp+0x10], xmm10
00007986e0dd467c  movaps [rsp+0x20], xmm13
00007986e0dd4682  lea rdi, [rsp]
00007986e0dd4686  mov esi, 0x00
00007986e0dd468b  mov rax, 0x5652C689F530
00007986e0dd4695  call rax
00007986e0dd4697  movaps xmm15, [rsp]
00007986e0dd469c  add rsp, 0x30
00007986e0dd46a0  vmovaps xmm0, [rsp]
00007986e0dd46a5  vmovaps xmm1, [rsp+0x10]
00007986e0dd46ab  vmovaps xmm2, [rsp+0x20]
00007986e0dd46b1  vmovaps xmm3, [rsp+0x30]
00007986e0dd46b7  vmovaps xmm4, [rsp+0x40]
00007986e0dd46bd  vmovaps xmm5, [rsp+0x50]
00007986e0dd46c3  vmovaps xmm6, [rsp+0x60]
00007986e0dd46c9  vmovaps xmm7, [rsp+0x70]
00007986e0dd46cf  vmovaps xmm8, [rsp+0x80]
00007986e0dd46d8  vmovaps xmm9, [rsp+0x90]
00007986e0dd46e1  vmovaps xmm10, [rsp+0xA0]
00007986e0dd46ea  vmovaps xmm11, [rsp+0xB0]
00007986e0dd46f3  vmovaps xmm12, [rsp+0xC0]
00007986e0dd46fc  vmovaps xmm13, [rsp+0xD0]
00007986e0dd4705  vmovaps xmm14, [rsp+0xE0]
00007986e0dd470e  add rsp, 0xF0
00007986e0dd4715  pop r11
00007986e0dd4717  pop r10
00007986e0dd4719  pop r9
00007986e0dd471b  pop r8
00007986e0dd471d  pop rsi
00007986e0dd471e  pop rdi
00007986e0dd471f  pop rdx
00007986e0dd4720  pop rcx
00007986e0dd4721  pop rax
00007986e0dd4722  add rsp, 0x08
00007986e0dd4726  jmp 0x00007986E0DD013D
00007986e0dd472b  sub rsp, 0x08
00007986e0dd472f  push rax
00007986e0dd4730  push rcx
00007986e0dd4731  push rdx
00007986e0dd4732  push rdi
00007986e0dd4733  push rsi
00007986e0dd4734  push r8
00007986e0dd4736  push r9
00007986e0dd4738  push r10
00007986e0dd473a  push r11
00007986e0dd473c  sub rsp, 0xF0
00007986e0dd4743  vmovaps [rsp], xmm0
00007986e0dd4748  vmovaps [rsp+0x10], xmm1
00007986e0dd474e  vmovaps [rsp+0x20], xmm2
00007986e0dd4754  vmovaps [rsp+0x30], xmm3
00007986e0dd475a  vmovaps [rsp+0x40], xmm4
00007986e0dd4760  vmovaps [rsp+0x50], xmm5
00007986e0dd4766  vmovaps [rsp+0x60], xmm6
00007986e0dd476c  vmovaps [rsp+0x70], xmm7
00007986e0dd4772  vmovaps [rsp+0x80], xmm8
00007986e0dd477b  vmovaps [rsp+0x90], xmm9
00007986e0dd4784  vmovaps [rsp+0xA0], xmm11
00007986e0dd478d  vmovaps [rsp+0xB0], xmm12
00007986e0dd4796  vmovaps [rsp+0xC0], xmm13
00007986e0dd479f  vmovaps [rsp+0xD0], xmm14
00007986e0dd47a8  vmovaps [rsp+0xE0], xmm15
00007986e0dd47b1  sub rsp, 0x30
00007986e0dd47b5  movaps [rsp], xmm10
00007986e0dd47ba  movaps [rsp+0x10], xmm7
00007986e0dd47bf  movaps [rsp+0x20], xmm13
00007986e0dd47c5  lea rdi, [rsp]
00007986e0dd47c9  mov esi, 0x00
00007986e0dd47ce  mov rax, 0x5652C689F530
00007986e0dd47d8  call rax
00007986e0dd47da  movaps xmm10, [rsp]
00007986e0dd47df  add rsp, 0x30
00007986e0dd47e3  vmovaps xmm0, [rsp]
00007986e0dd47e8  vmovaps xmm1, [rsp+0x10]
00007986e0dd47ee  vmovaps xmm2, [rsp+0x20]
00007986e0dd47f4  vmovaps xmm3, [rsp+0x30]
00007986e0dd47fa  vmovaps xmm4, [rsp+0x40]
00007986e0dd4800  vmovaps xmm5, [rsp+0x50]
00007986e0dd4806  vmovaps xmm6, [rsp+0x60]
00007986e0dd480c  vmovaps xmm7, [rsp+0x70]
00007986e0dd4812  vmovaps xmm8, [rsp+0x80]
00007986e0dd481b  vmovaps xmm9, [rsp+0x90]
00007986e0dd4824  vmovaps xmm11, [rsp+0xA0]
00007986e0dd482d  vmovaps xmm12, [rsp+0xB0]
00007986e0dd4836  vmovaps xmm13, [rsp+0xC0]
00007986e0dd483f  vmovaps xmm14, [rsp+0xD0]
00007986e0dd4848  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4851  add rsp, 0xF0
00007986e0dd4858  pop r11
00007986e0dd485a  pop r10
00007986e0dd485c  pop r9
00007986e0dd485e  pop r8
00007986e0dd4860  pop rsi
00007986e0dd4861  pop rdi
00007986e0dd4862  pop rdx
00007986e0dd4863  pop rcx
00007986e0dd4864  pop rax
00007986e0dd4865  add rsp, 0x08
00007986e0dd4869  jmp 0x00007986E0DD0169
00007986e0dd486e  sub rsp, 0x08
00007986e0dd4872  push rax
00007986e0dd4873  push rcx
00007986e0dd4874  push rdx
00007986e0dd4875  push rdi
00007986e0dd4876  push rsi
00007986e0dd4877  push r8
00007986e0dd4879  push r9
00007986e0dd487b  push r10
00007986e0dd487d  push r11
00007986e0dd487f  sub rsp, 0xF0
00007986e0dd4886  vmovaps [rsp], xmm0
00007986e0dd488b  vmovaps [rsp+0x10], xmm1
00007986e0dd4891  vmovaps [rsp+0x20], xmm2
00007986e0dd4897  vmovaps [rsp+0x30], xmm3
00007986e0dd489d  vmovaps [rsp+0x40], xmm4
00007986e0dd48a3  vmovaps [rsp+0x50], xmm5
00007986e0dd48a9  vmovaps [rsp+0x60], xmm6
00007986e0dd48af  vmovaps [rsp+0x70], xmm7
00007986e0dd48b5  vmovaps [rsp+0x80], xmm8
00007986e0dd48be  vmovaps [rsp+0x90], xmm9
00007986e0dd48c7  vmovaps [rsp+0xA0], xmm10
00007986e0dd48d0  vmovaps [rsp+0xB0], xmm11
00007986e0dd48d9  vmovaps [rsp+0xC0], xmm12
00007986e0dd48e2  vmovaps [rsp+0xD0], xmm14
00007986e0dd48eb  vmovaps [rsp+0xE0], xmm15
00007986e0dd48f4  sub rsp, 0x30
00007986e0dd48f8  movaps [rsp], xmm13
00007986e0dd48fd  movaps [rsp+0x10], xmm1
00007986e0dd4902  movaps [rsp+0x20], xmm8
00007986e0dd4908  lea rdi, [rsp]
00007986e0dd490c  mov esi, 0x00
00007986e0dd4911  mov rax, 0x5652C689F530
00007986e0dd491b  call rax
00007986e0dd491d  movaps xmm13, [rsp]
00007986e0dd4922  add rsp, 0x30
00007986e0dd4926  vmovaps xmm0, [rsp]
00007986e0dd492b  vmovaps xmm1, [rsp+0x10]
00007986e0dd4931  vmovaps xmm2, [rsp+0x20]
00007986e0dd4937  vmovaps xmm3, [rsp+0x30]
00007986e0dd493d  vmovaps xmm4, [rsp+0x40]
00007986e0dd4943  vmovaps xmm5, [rsp+0x50]
00007986e0dd4949  vmovaps xmm6, [rsp+0x60]
00007986e0dd494f  vmovaps xmm7, [rsp+0x70]
00007986e0dd4955  vmovaps xmm8, [rsp+0x80]
00007986e0dd495e  vmovaps xmm9, [rsp+0x90]
00007986e0dd4967  vmovaps xmm10, [rsp+0xA0]
00007986e0dd4970  vmovaps xmm11, [rsp+0xB0]
00007986e0dd4979  vmovaps xmm12, [rsp+0xC0]
00007986e0dd4982  vmovaps xmm14, [rsp+0xD0]
00007986e0dd498b  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4994  add rsp, 0xF0
00007986e0dd499b  pop r11
00007986e0dd499d  pop r10
00007986e0dd499f  pop r9
00007986e0dd49a1  pop r8
00007986e0dd49a3  pop rsi
00007986e0dd49a4  pop rdi
00007986e0dd49a5  pop rdx
00007986e0dd49a6  pop rcx
00007986e0dd49a7  pop rax
00007986e0dd49a8  add rsp, 0x08
00007986e0dd49ac  jmp 0x00007986E0DD0183
00007986e0dd49b1  call 0x00007986E0BFF430
00007986e0dd49b6  jmp 0x00007986E0DD018D
00007986e0dd49bb  sub rsp, 0x08
00007986e0dd49bf  push rax
00007986e0dd49c0  push rcx
00007986e0dd49c1  push rdx
00007986e0dd49c2  push rdi
00007986e0dd49c3  push rsi
00007986e0dd49c4  push r8
00007986e0dd49c6  push r9
00007986e0dd49c8  push r10
00007986e0dd49ca  push r11
00007986e0dd49cc  sub rsp, 0xF0
00007986e0dd49d3  vmovaps [rsp], xmm0
00007986e0dd49d8  vmovaps [rsp+0x10], xmm1
00007986e0dd49de  vmovaps [rsp+0x20], xmm2
00007986e0dd49e4  vmovaps [rsp+0x30], xmm3
00007986e0dd49ea  vmovaps [rsp+0x40], xmm4
00007986e0dd49f0  vmovaps [rsp+0x50], xmm5
00007986e0dd49f6  vmovaps [rsp+0x60], xmm6
00007986e0dd49fc  vmovaps [rsp+0x70], xmm7
00007986e0dd4a02  vmovaps [rsp+0x80], xmm9
00007986e0dd4a0b  vmovaps [rsp+0x90], xmm10
00007986e0dd4a14  vmovaps [rsp+0xA0], xmm11
00007986e0dd4a1d  vmovaps [rsp+0xB0], xmm12
00007986e0dd4a26  vmovaps [rsp+0xC0], xmm13
00007986e0dd4a2f  vmovaps [rsp+0xD0], xmm14
00007986e0dd4a38  vmovaps [rsp+0xE0], xmm15
00007986e0dd4a41  sub rsp, 0x30
00007986e0dd4a45  movaps [rsp], xmm8
00007986e0dd4a4a  movaps [rsp+0x10], xmm14
00007986e0dd4a50  movaps [rsp+0x20], xmm9
00007986e0dd4a56  lea rdi, [rsp]
00007986e0dd4a5a  mov esi, 0x00
00007986e0dd4a5f  mov rax, 0x5652C689F530
00007986e0dd4a69  call rax
00007986e0dd4a6b  movaps xmm8, [rsp]
00007986e0dd4a70  add rsp, 0x30
00007986e0dd4a74  vmovaps xmm0, [rsp]
00007986e0dd4a79  vmovaps xmm1, [rsp+0x10]
00007986e0dd4a7f  vmovaps xmm2, [rsp+0x20]
00007986e0dd4a85  vmovaps xmm3, [rsp+0x30]
00007986e0dd4a8b  vmovaps xmm4, [rsp+0x40]
00007986e0dd4a91  vmovaps xmm5, [rsp+0x50]
00007986e0dd4a97  vmovaps xmm6, [rsp+0x60]
00007986e0dd4a9d  vmovaps xmm7, [rsp+0x70]
00007986e0dd4aa3  vmovaps xmm9, [rsp+0x80]
00007986e0dd4aac  vmovaps xmm10, [rsp+0x90]
00007986e0dd4ab5  vmovaps xmm11, [rsp+0xA0]
00007986e0dd4abe  vmovaps xmm12, [rsp+0xB0]
00007986e0dd4ac7  vmovaps xmm13, [rsp+0xC0]
00007986e0dd4ad0  vmovaps xmm14, [rsp+0xD0]
00007986e0dd4ad9  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4ae2  add rsp, 0xF0
00007986e0dd4ae9  pop r11
00007986e0dd4aeb  pop r10
00007986e0dd4aed  pop r9
00007986e0dd4aef  pop r8
00007986e0dd4af1  pop rsi
00007986e0dd4af2  pop rdi
00007986e0dd4af3  pop rdx
00007986e0dd4af4  pop rcx
00007986e0dd4af5  pop rax
00007986e0dd4af6  add rsp, 0x08
00007986e0dd4afa  jmp 0x00007986E0DD01AF
00007986e0dd4aff  sub rsp, 0x08
00007986e0dd4b03  push rax
00007986e0dd4b04  push rcx
00007986e0dd4b05  push rdx
00007986e0dd4b06  push rdi
00007986e0dd4b07  push rsi
00007986e0dd4b08  push r8
00007986e0dd4b0a  push r9
00007986e0dd4b0c  push r10
00007986e0dd4b0e  push r11
00007986e0dd4b10  sub rsp, 0xF0
00007986e0dd4b17  vmovaps [rsp], xmm0
00007986e0dd4b1c  vmovaps [rsp+0x10], xmm1
00007986e0dd4b22  vmovaps [rsp+0x20], xmm2
00007986e0dd4b28  vmovaps [rsp+0x30], xmm3
00007986e0dd4b2e  vmovaps [rsp+0x40], xmm4
00007986e0dd4b34  vmovaps [rsp+0x50], xmm5
00007986e0dd4b3a  vmovaps [rsp+0x60], xmm6
00007986e0dd4b40  vmovaps [rsp+0x70], xmm7
00007986e0dd4b46  vmovaps [rsp+0x80], xmm8
00007986e0dd4b4f  vmovaps [rsp+0x90], xmm10
00007986e0dd4b58  vmovaps [rsp+0xA0], xmm11
00007986e0dd4b61  vmovaps [rsp+0xB0], xmm12
00007986e0dd4b6a  vmovaps [rsp+0xC0], xmm13
00007986e0dd4b73  vmovaps [rsp+0xD0], xmm14
00007986e0dd4b7c  vmovaps [rsp+0xE0], xmm15
00007986e0dd4b85  sub rsp, 0x30
00007986e0dd4b89  movaps [rsp], xmm9
00007986e0dd4b8e  movaps [rsp+0x10], xmm1
00007986e0dd4b93  movaps [rsp+0x20], xmm14
00007986e0dd4b99  lea rdi, [rsp]
00007986e0dd4b9d  mov esi, 0x00
00007986e0dd4ba2  mov rax, 0x5652C689F530
00007986e0dd4bac  call rax
00007986e0dd4bae  movaps xmm9, [rsp]
00007986e0dd4bb3  add rsp, 0x30
00007986e0dd4bb7  vmovaps xmm0, [rsp]
00007986e0dd4bbc  vmovaps xmm1, [rsp+0x10]
00007986e0dd4bc2  vmovaps xmm2, [rsp+0x20]
00007986e0dd4bc8  vmovaps xmm3, [rsp+0x30]
00007986e0dd4bce  vmovaps xmm4, [rsp+0x40]
00007986e0dd4bd4  vmovaps xmm5, [rsp+0x50]
00007986e0dd4bda  vmovaps xmm6, [rsp+0x60]
00007986e0dd4be0  vmovaps xmm7, [rsp+0x70]
00007986e0dd4be6  vmovaps xmm8, [rsp+0x80]
00007986e0dd4bef  vmovaps xmm10, [rsp+0x90]
00007986e0dd4bf8  vmovaps xmm11, [rsp+0xA0]
00007986e0dd4c01  vmovaps xmm12, [rsp+0xB0]
00007986e0dd4c0a  vmovaps xmm13, [rsp+0xC0]
00007986e0dd4c13  vmovaps xmm14, [rsp+0xD0]
00007986e0dd4c1c  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4c25  add rsp, 0xF0
00007986e0dd4c2c  pop r11
00007986e0dd4c2e  pop r10
00007986e0dd4c30  pop r9
00007986e0dd4c32  pop r8
00007986e0dd4c34  pop rsi
00007986e0dd4c35  pop rdi
00007986e0dd4c36  pop rdx
00007986e0dd4c37  pop rcx
00007986e0dd4c38  pop rax
00007986e0dd4c39  add rsp, 0x08
00007986e0dd4c3d  jmp 0x00007986E0DD01DD
00007986e0dd4c42  sub rsp, 0x08
00007986e0dd4c46  push rax
00007986e0dd4c47  push rcx
00007986e0dd4c48  push rdx
00007986e0dd4c49  push rdi
00007986e0dd4c4a  push rsi
00007986e0dd4c4b  push r8
00007986e0dd4c4d  push r9
00007986e0dd4c4f  push r10
00007986e0dd4c51  push r11
00007986e0dd4c53  sub rsp, 0xF0
00007986e0dd4c5a  vmovaps [rsp], xmm0
00007986e0dd4c5f  vmovaps [rsp+0x10], xmm1
00007986e0dd4c65  vmovaps [rsp+0x20], xmm2
00007986e0dd4c6b  vmovaps [rsp+0x30], xmm3
00007986e0dd4c71  vmovaps [rsp+0x40], xmm4
00007986e0dd4c77  vmovaps [rsp+0x50], xmm5
00007986e0dd4c7d  vmovaps [rsp+0x60], xmm6
00007986e0dd4c83  vmovaps [rsp+0x70], xmm7
00007986e0dd4c89  vmovaps [rsp+0x80], xmm8
00007986e0dd4c92  vmovaps [rsp+0x90], xmm9
00007986e0dd4c9b  vmovaps [rsp+0xA0], xmm10
00007986e0dd4ca4  vmovaps [rsp+0xB0], xmm11
00007986e0dd4cad  vmovaps [rsp+0xC0], xmm12
00007986e0dd4cb6  vmovaps [rsp+0xD0], xmm13
00007986e0dd4cbf  vmovaps [rsp+0xE0], xmm15
00007986e0dd4cc8  sub rsp, 0x30
00007986e0dd4ccc  movaps [rsp], xmm14
00007986e0dd4cd1  movaps [rsp+0x10], xmm4
00007986e0dd4cd6  movaps [rsp+0x20], xmm1
00007986e0dd4cdb  lea rdi, [rsp]
00007986e0dd4cdf  mov esi, 0x00
00007986e0dd4ce4  mov rax, 0x5652C689F530
00007986e0dd4cee  call rax
00007986e0dd4cf0  movaps xmm14, [rsp]
00007986e0dd4cf5  add rsp, 0x30
00007986e0dd4cf9  vmovaps xmm0, [rsp]
00007986e0dd4cfe  vmovaps xmm1, [rsp+0x10]
00007986e0dd4d04  vmovaps xmm2, [rsp+0x20]
00007986e0dd4d0a  vmovaps xmm3, [rsp+0x30]
00007986e0dd4d10  vmovaps xmm4, [rsp+0x40]
00007986e0dd4d16  vmovaps xmm5, [rsp+0x50]
00007986e0dd4d1c  vmovaps xmm6, [rsp+0x60]
00007986e0dd4d22  vmovaps xmm7, [rsp+0x70]
00007986e0dd4d28  vmovaps xmm8, [rsp+0x80]
00007986e0dd4d31  vmovaps xmm9, [rsp+0x90]
00007986e0dd4d3a  vmovaps xmm10, [rsp+0xA0]
00007986e0dd4d43  vmovaps xmm11, [rsp+0xB0]
00007986e0dd4d4c  vmovaps xmm12, [rsp+0xC0]
00007986e0dd4d55  vmovaps xmm13, [rsp+0xD0]
00007986e0dd4d5e  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4d67  add rsp, 0xF0
00007986e0dd4d6e  pop r11
00007986e0dd4d70  pop r10
00007986e0dd4d72  pop r9
00007986e0dd4d74  pop r8
00007986e0dd4d76  pop rsi
00007986e0dd4d77  pop rdi
00007986e0dd4d78  pop rdx
00007986e0dd4d79  pop rcx
00007986e0dd4d7a  pop rax
00007986e0dd4d7b  add rsp, 0x08
00007986e0dd4d7f  jmp 0x00007986E0DD0203
00007986e0dd4d84  sub rsp, 0x08
00007986e0dd4d88  push rax
00007986e0dd4d89  push rcx
00007986e0dd4d8a  push rdx
00007986e0dd4d8b  push rdi
00007986e0dd4d8c  push rsi
00007986e0dd4d8d  push r8
00007986e0dd4d8f  push r9
00007986e0dd4d91  push r10
00007986e0dd4d93  push r11
00007986e0dd4d95  sub rsp, 0xF0
00007986e0dd4d9c  vmovaps [rsp], xmm0
00007986e0dd4da1  vmovaps [rsp+0x10], xmm2
00007986e0dd4da7  vmovaps [rsp+0x20], xmm3
00007986e0dd4dad  vmovaps [rsp+0x30], xmm4
00007986e0dd4db3  vmovaps [rsp+0x40], xmm5
00007986e0dd4db9  vmovaps [rsp+0x50], xmm6
00007986e0dd4dbf  vmovaps [rsp+0x60], xmm7
00007986e0dd4dc5  vmovaps [rsp+0x70], xmm8
00007986e0dd4dcb  vmovaps [rsp+0x80], xmm9
00007986e0dd4dd4  vmovaps [rsp+0x90], xmm10
00007986e0dd4ddd  vmovaps [rsp+0xA0], xmm11
00007986e0dd4de6  vmovaps [rsp+0xB0], xmm12
00007986e0dd4def  vmovaps [rsp+0xC0], xmm13
00007986e0dd4df8  vmovaps [rsp+0xD0], xmm14
00007986e0dd4e01  vmovaps [rsp+0xE0], xmm15
00007986e0dd4e0a  sub rsp, 0x30
00007986e0dd4e0e  movaps [rsp], xmm1
00007986e0dd4e12  movaps [rsp+0x10], xmm12
00007986e0dd4e18  movaps [rsp+0x20], xmm11
00007986e0dd4e1e  lea rdi, [rsp]
00007986e0dd4e22  mov esi, 0x00
00007986e0dd4e27  mov rax, 0x5652C689F530
00007986e0dd4e31  call rax
00007986e0dd4e33  movaps xmm1, [rsp]
00007986e0dd4e37  add rsp, 0x30
00007986e0dd4e3b  vmovaps xmm0, [rsp]
00007986e0dd4e40  vmovaps xmm2, [rsp+0x10]
00007986e0dd4e46  vmovaps xmm3, [rsp+0x20]
00007986e0dd4e4c  vmovaps xmm4, [rsp+0x30]
00007986e0dd4e52  vmovaps xmm5, [rsp+0x40]
00007986e0dd4e58  vmovaps xmm6, [rsp+0x50]
00007986e0dd4e5e  vmovaps xmm7, [rsp+0x60]
00007986e0dd4e64  vmovaps xmm8, [rsp+0x70]
00007986e0dd4e6a  vmovaps xmm9, [rsp+0x80]
00007986e0dd4e73  vmovaps xmm10, [rsp+0x90]
00007986e0dd4e7c  vmovaps xmm11, [rsp+0xA0]
00007986e0dd4e85  vmovaps xmm12, [rsp+0xB0]
00007986e0dd4e8e  vmovaps xmm13, [rsp+0xC0]
00007986e0dd4e97  vmovaps xmm14, [rsp+0xD0]
00007986e0dd4ea0  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4ea9  add rsp, 0xF0
00007986e0dd4eb0  pop r11
00007986e0dd4eb2  pop r10
00007986e0dd4eb4  pop r9
00007986e0dd4eb6  pop r8
00007986e0dd4eb8  pop rsi
00007986e0dd4eb9  pop rdi
00007986e0dd4eba  pop rdx
00007986e0dd4ebb  pop rcx
00007986e0dd4ebc  pop rax
00007986e0dd4ebd  add rsp, 0x08
00007986e0dd4ec1  jmp 0x00007986E0DD0224
00007986e0dd4ec6  call 0x00007986E0CE20A0
00007986e0dd4ecb  jmp 0x00007986E0DD0232
00007986e0dd4ed0  call 0x00007986E0C09D70
00007986e0dd4ed5  jmp 0x00007986E0DD023C
00007986e0dd4eda  sub rsp, 0x08
00007986e0dd4ede  push rax
00007986e0dd4edf  push rcx
00007986e0dd4ee0  push rdx
00007986e0dd4ee1  push rdi
00007986e0dd4ee2  push rsi
00007986e0dd4ee3  push r8
00007986e0dd4ee5  push r9
00007986e0dd4ee7  push r10
00007986e0dd4ee9  push r11
00007986e0dd4eeb  sub rsp, 0xF0
00007986e0dd4ef2  vmovaps [rsp], xmm0
00007986e0dd4ef7  vmovaps [rsp+0x10], xmm1
00007986e0dd4efd  vmovaps [rsp+0x20], xmm2
00007986e0dd4f03  vmovaps [rsp+0x30], xmm3
00007986e0dd4f09  vmovaps [rsp+0x40], xmm4
00007986e0dd4f0f  vmovaps [rsp+0x50], xmm5
00007986e0dd4f15  vmovaps [rsp+0x60], xmm6
00007986e0dd4f1b  vmovaps [rsp+0x70], xmm8
00007986e0dd4f21  vmovaps [rsp+0x80], xmm9
00007986e0dd4f2a  vmovaps [rsp+0x90], xmm10
00007986e0dd4f33  vmovaps [rsp+0xA0], xmm11
00007986e0dd4f3c  vmovaps [rsp+0xB0], xmm12
00007986e0dd4f45  vmovaps [rsp+0xC0], xmm13
00007986e0dd4f4e  vmovaps [rsp+0xD0], xmm14
00007986e0dd4f57  vmovaps [rsp+0xE0], xmm15
00007986e0dd4f60  sub rsp, 0x30
00007986e0dd4f64  movaps [rsp], xmm7
00007986e0dd4f68  movaps [rsp+0x10], xmm15
00007986e0dd4f6e  movaps [rsp+0x20], xmm10
00007986e0dd4f74  lea rdi, [rsp]
00007986e0dd4f78  mov esi, 0x00
00007986e0dd4f7d  mov rax, 0x5652C689F530
00007986e0dd4f87  call rax
00007986e0dd4f89  movaps xmm7, [rsp]
00007986e0dd4f8d  add rsp, 0x30
00007986e0dd4f91  vmovaps xmm0, [rsp]
00007986e0dd4f96  vmovaps xmm1, [rsp+0x10]
00007986e0dd4f9c  vmovaps xmm2, [rsp+0x20]
00007986e0dd4fa2  vmovaps xmm3, [rsp+0x30]
00007986e0dd4fa8  vmovaps xmm4, [rsp+0x40]
00007986e0dd4fae  vmovaps xmm5, [rsp+0x50]
00007986e0dd4fb4  vmovaps xmm6, [rsp+0x60]
00007986e0dd4fba  vmovaps xmm8, [rsp+0x70]
00007986e0dd4fc0  vmovaps xmm9, [rsp+0x80]
00007986e0dd4fc9  vmovaps xmm10, [rsp+0x90]
00007986e0dd4fd2  vmovaps xmm11, [rsp+0xA0]
00007986e0dd4fdb  vmovaps xmm12, [rsp+0xB0]
00007986e0dd4fe4  vmovaps xmm13, [rsp+0xC0]
00007986e0dd4fed  vmovaps xmm14, [rsp+0xD0]
00007986e0dd4ff6  vmovaps xmm15, [rsp+0xE0]
00007986e0dd4fff  add rsp, 0xF0
00007986e0dd5006  pop r11
00007986e0dd5008  pop r10
00007986e0dd500a  pop r9
00007986e0dd500c  pop r8
00007986e0dd500e  pop rsi
00007986e0dd500f  pop rdi
00007986e0dd5010  pop rdx
00007986e0dd5011  pop rcx
00007986e0dd5012  pop rax
00007986e0dd5013  add rsp, 0x08
00007986e0dd5017  jmp 0x00007986E0DD025D
00007986e0dd501c  sub rsp, 0x08
00007986e0dd5020  push rax
00007986e0dd5021  push rcx
00007986e0dd5022  push rdx
00007986e0dd5023  push rdi
00007986e0dd5024  push rsi
00007986e0dd5025  push r8
00007986e0dd5027  push r9
00007986e0dd5029  push r10
00007986e0dd502b  push r11
00007986e0dd502d  sub rsp, 0xF0
00007986e0dd5034  vmovaps [rsp], xmm0
00007986e0dd5039  vmovaps [rsp+0x10], xmm1
00007986e0dd503f  vmovaps [rsp+0x20], xmm2
00007986e0dd5045  vmovaps [rsp+0x30], xmm3
00007986e0dd504b  vmovaps [rsp+0x40], xmm4
00007986e0dd5051  vmovaps [rsp+0x50], xmm5
00007986e0dd5057  vmovaps [rsp+0x60], xmm6
00007986e0dd505d  vmovaps [rsp+0x70], xmm7
00007986e0dd5063  vmovaps [rsp+0x80], xmm8
00007986e0dd506c  vmovaps [rsp+0x90], xmm9
00007986e0dd5075  vmovaps [rsp+0xA0], xmm11
00007986e0dd507e  vmovaps [rsp+0xB0], xmm12
00007986e0dd5087  vmovaps [rsp+0xC0], xmm13
00007986e0dd5090  vmovaps [rsp+0xD0], xmm14
00007986e0dd5099  vmovaps [rsp+0xE0], xmm15
00007986e0dd50a2  sub rsp, 0x30
00007986e0dd50a6  movaps [rsp], xmm10
00007986e0dd50ab  movaps [rsp+0x10], xmm11
00007986e0dd50b1  movaps [rsp+0x20], xmm15
00007986e0dd50b7  lea rdi, [rsp]
00007986e0dd50bb  mov esi, 0x00
00007986e0dd50c0  mov rax, 0x5652C689F530
00007986e0dd50ca  call rax
00007986e0dd50cc  movaps xmm10, [rsp]
00007986e0dd50d1  add rsp, 0x30
00007986e0dd50d5  vmovaps xmm0, [rsp]
00007986e0dd50da  vmovaps xmm1, [rsp+0x10]
00007986e0dd50e0  vmovaps xmm2, [rsp+0x20]
00007986e0dd50e6  vmovaps xmm3, [rsp+0x30]
00007986e0dd50ec  vmovaps xmm4, [rsp+0x40]
00007986e0dd50f2  vmovaps xmm5, [rsp+0x50]
00007986e0dd50f8  vmovaps xmm6, [rsp+0x60]
00007986e0dd50fe  vmovaps xmm7, [rsp+0x70]
00007986e0dd5104  vmovaps xmm8, [rsp+0x80]
00007986e0dd510d  vmovaps xmm9, [rsp+0x90]
00007986e0dd5116  vmovaps xmm11, [rsp+0xA0]
00007986e0dd511f  vmovaps xmm12, [rsp+0xB0]
00007986e0dd5128  vmovaps xmm13, [rsp+0xC0]
00007986e0dd5131  vmovaps xmm14, [rsp+0xD0]
00007986e0dd513a  vmovaps xmm15, [rsp+0xE0]
00007986e0dd5143  add rsp, 0xF0
00007986e0dd514a  pop r11
00007986e0dd514c  pop r10
00007986e0dd514e  pop r9
00007986e0dd5150  pop r8
00007986e0dd5152  pop rsi
00007986e0dd5153  pop rdi
00007986e0dd5154  pop rdx
00007986e0dd5155  pop rcx
00007986e0dd5156  pop rax
00007986e0dd5157  add rsp, 0x08
00007986e0dd515b  jmp 0x00007986E0DD028B
00007986e0dd5160  sub rsp, 0x08
00007986e0dd5164  push rax
00007986e0dd5165  push rcx
00007986e0dd5166  push rdx
00007986e0dd5167  push rdi
00007986e0dd5168  push rsi
00007986e0dd5169  push r8
00007986e0dd516b  push r9
00007986e0dd516d  push r10
00007986e0dd516f  push r11
00007986e0dd5171  sub rsp, 0xF0
00007986e0dd5178  vmovaps [rsp], xmm0
00007986e0dd517d  vmovaps [rsp+0x10], xmm1
00007986e0dd5183  vmovaps [rsp+0x20], xmm2
00007986e0dd5189  vmovaps [rsp+0x30], xmm3
00007986e0dd518f  vmovaps [rsp+0x40], xmm4
00007986e0dd5195  vmovaps [rsp+0x50], xmm5
00007986e0dd519b  vmovaps [rsp+0x60], xmm6
00007986e0dd51a1  vmovaps [rsp+0x70], xmm7
00007986e0dd51a7  vmovaps [rsp+0x80], xmm8
00007986e0dd51b0  vmovaps [rsp+0x90], xmm9
00007986e0dd51b9  vmovaps [rsp+0xA0], xmm10
00007986e0dd51c2  vmovaps [rsp+0xB0], xmm12
00007986e0dd51cb  vmovaps [rsp+0xC0], xmm13
00007986e0dd51d4  vmovaps [rsp+0xD0], xmm14
00007986e0dd51dd  vmovaps [rsp+0xE0], xmm15
00007986e0dd51e6  sub rsp, 0x30
00007986e0dd51ea  movaps [rsp], xmm11
00007986e0dd51ef  movaps [rsp+0x10], xmm12
00007986e0dd51f5  movaps [rsp+0x20], xmm15
00007986e0dd51fb  lea rdi, [rsp]
00007986e0dd51ff  mov esi, 0x00
00007986e0dd5204  mov rax, 0x5652C689F530
00007986e0dd520e  call rax
00007986e0dd5210  movaps xmm11, [rsp]
00007986e0dd5215  add rsp, 0x30
00007986e0dd5219  vmovaps xmm0, [rsp]
00007986e0dd521e  vmovaps xmm1, [rsp+0x10]
00007986e0dd5224  vmovaps xmm2, [rsp+0x20]
00007986e0dd522a  vmovaps xmm3, [rsp+0x30]
00007986e0dd5230  vmovaps xmm4, [rsp+0x40]
00007986e0dd5236  vmovaps xmm5, [rsp+0x50]
00007986e0dd523c  vmovaps xmm6, [rsp+0x60]
00007986e0dd5242  vmovaps xmm7, [rsp+0x70]
00007986e0dd5248  vmovaps xmm8, [rsp+0x80]
00007986e0dd5251  vmovaps xmm9, [rsp+0x90]
00007986e0dd525a  vmovaps xmm10, [rsp+0xA0]
00007986e0dd5263  vmovaps xmm12, [rsp+0xB0]
00007986e0dd526c  vmovaps xmm13, [rsp+0xC0]
00007986e0dd5275  vmovaps xmm14, [rsp+0xD0]
00007986e0dd527e  vmovaps xmm15, [rsp+0xE0]
00007986e0dd5287  add rsp, 0xF0
00007986e0dd528e  pop r11
00007986e0dd5290  pop r10
00007986e0dd5292  pop r9
00007986e0dd5294  pop r8
00007986e0dd5296  pop rsi
00007986e0dd5297  pop rdi
00007986e0dd5298  pop rdx
00007986e0dd5299  pop rcx
00007986e0dd529a  pop rax
00007986e0dd529b  add rsp, 0x08
00007986e0dd529f  jmp 0x00007986E0DD02B9
00007986e0dd52a4  sub rsp, 0x08
00007986e0dd52a8  push rax
00007986e0dd52a9  push rcx
00007986e0dd52aa  push rdx
00007986e0dd52ab  push rdi
00007986e0dd52ac  push rsi
00007986e0dd52ad  push r8
00007986e0dd52af  push r9
00007986e0dd52b1  push r10
00007986e0dd52b3  push r11
00007986e0dd52b5  sub rsp, 0xF0
00007986e0dd52bc  vmovaps [rsp], xmm0
00007986e0dd52c1  vmovaps [rsp+0x10], xmm1
00007986e0dd52c7  vmovaps [rsp+0x20], xmm2
00007986e0dd52cd  vmovaps [rsp+0x30], xmm3
00007986e0dd52d3  vmovaps [rsp+0x40], xmm4
00007986e0dd52d9  vmovaps [rsp+0x50], xmm5
00007986e0dd52df  vmovaps [rsp+0x60], xmm6
00007986e0dd52e5  vmovaps [rsp+0x70], xmm7
00007986e0dd52eb  vmovaps [rsp+0x80], xmm8
00007986e0dd52f4  vmovaps [rsp+0x90], xmm9
00007986e0dd52fd  vmovaps [rsp+0xA0], xmm10
00007986e0dd5306  vmovaps [rsp+0xB0], xmm11
00007986e0dd530f  vmovaps [rsp+0xC0], xmm12
00007986e0dd5318  vmovaps [rsp+0xD0], xmm13
00007986e0dd5321  vmovaps [rsp+0xE0], xmm14
00007986e0dd532a  sub rsp, 0x30
00007986e0dd532e  movaps [rsp], xmm15
00007986e0dd5333  movaps [rsp+0x10], xmm13
00007986e0dd5339  movaps [rsp+0x20], xmm9
00007986e0dd533f  lea rdi, [rsp]
00007986e0dd5343  mov esi, 0x00
00007986e0dd5348  mov rax, 0x5652C689F530
00007986e0dd5352  call rax
00007986e0dd5354  movaps xmm15, [rsp]
00007986e0dd5359  add rsp, 0x30
00007986e0dd535d  vmovaps xmm0, [rsp]
00007986e0dd5362  vmovaps xmm1, [rsp+0x10]
00007986e0dd5368  vmovaps xmm2, [rsp+0x20]
00007986e0dd536e  vmovaps xmm3, [rsp+0x30]
00007986e0dd5374  vmovaps xmm4, [rsp+0x40]
00007986e0dd537a  vmovaps xmm5, [rsp+0x50]
00007986e0dd5380  vmovaps xmm6, [rsp+0x60]
00007986e0dd5386  vmovaps xmm7, [rsp+0x70]
00007986e0dd538c  vmovaps xmm8, [rsp+0x80]
00007986e0dd5395  vmovaps xmm9, [rsp+0x90]
00007986e0dd539e  vmovaps xmm10, [rsp+0xA0]
00007986e0dd53a7  vmovaps xmm11, [rsp+0xB0]
00007986e0dd53b0  vmovaps xmm12, [rsp+0xC0]
00007986e0dd53b9  vmovaps xmm13, [rsp+0xD0]
00007986e0dd53c2  vmovaps xmm14, [rsp+0xE0]
00007986e0dd53cb  add rsp, 0xF0
00007986e0dd53d2  pop r11
00007986e0dd53d4  pop r10
00007986e0dd53d6  pop r9
00007986e0dd53d8  pop r8
00007986e0dd53da  pop rsi
00007986e0dd53db  pop rdi
00007986e0dd53dc  pop rdx
00007986e0dd53dd  pop rcx
00007986e0dd53de  pop rax
00007986e0dd53df  add rsp, 0x08
00007986e0dd53e3  jmp 0x00007986E0DD02D4
00007986e0dd53e8  sub rsp, 0x08
00007986e0dd53ec  push rax
00007986e0dd53ed  push rcx
00007986e0dd53ee  push rdx
00007986e0dd53ef  push rdi
00007986e0dd53f0  push rsi
00007986e0dd53f1  push r8
00007986e0dd53f3  push r9
00007986e0dd53f5  push r10
00007986e0dd53f7  push r11
00007986e0dd53f9  sub rsp, 0xF0
00007986e0dd5400  vmovaps [rsp], xmm0
00007986e0dd5405  vmovaps [rsp+0x10], xmm1
00007986e0dd540b  vmovaps [rsp+0x20], xmm2
00007986e0dd5411  vmovaps [rsp+0x30], xmm3
00007986e0dd5417  vmovaps [rsp+0x40], xmm4
00007986e0dd541d  vmovaps [rsp+0x50], xmm5
00007986e0dd5423  vmovaps [rsp+0x60], xmm6
00007986e0dd5429  vmovaps [rsp+0x70], xmm7
00007986e0dd542f  vmovaps [rsp+0x80], xmm8
00007986e0dd5438  vmovaps [rsp+0x90], xmm9
00007986e0dd5441  vmovaps [rsp+0xA0], xmm10
00007986e0dd544a  vmovaps [rsp+0xB0], xmm11
00007986e0dd5453  vmovaps [rsp+0xC0], xmm12
00007986e0dd545c  vmovaps [rsp+0xD0], xmm14
00007986e0dd5465  vmovaps [rsp+0xE0], xmm15
00007986e0dd546e  sub rsp, 0x30
00007986e0dd5472  movaps [rsp], xmm13
00007986e0dd5477  movaps [rsp+0x10], xmm8
00007986e0dd547d  movaps [rsp+0x20], xmm14
00007986e0dd5483  lea rdi, [rsp]
00007986e0dd5487  mov esi, 0x00
00007986e0dd548c  mov rax, 0x5652C689F530
00007986e0dd5496  call rax
00007986e0dd5498  movaps xmm13, [rsp]
00007986e0dd549d  add rsp, 0x30
00007986e0dd54a1  vmovaps xmm0, [rsp]
00007986e0dd54a6  vmovaps xmm1, [rsp+0x10]
00007986e0dd54ac  vmovaps xmm2, [rsp+0x20]
00007986e0dd54b2  vmovaps xmm3, [rsp+0x30]
00007986e0dd54b8  vmovaps xmm4, [rsp+0x40]
00007986e0dd54be  vmovaps xmm5, [rsp+0x50]
00007986e0dd54c4  vmovaps xmm6, [rsp+0x60]
00007986e0dd54ca  vmovaps xmm7, [rsp+0x70]
00007986e0dd54d0  vmovaps xmm8, [rsp+0x80]
00007986e0dd54d9  vmovaps xmm9, [rsp+0x90]
00007986e0dd54e2  vmovaps xmm10, [rsp+0xA0]
00007986e0dd54eb  vmovaps xmm11, [rsp+0xB0]
00007986e0dd54f4  vmovaps xmm12, [rsp+0xC0]
00007986e0dd54fd  vmovaps xmm14, [rsp+0xD0]
00007986e0dd5506  vmovaps xmm15, [rsp+0xE0]
00007986e0dd550f  add rsp, 0xF0
00007986e0dd5516  pop r11
00007986e0dd5518  pop r10
00007986e0dd551a  pop r9
00007986e0dd551c  pop r8
00007986e0dd551e  pop rsi
00007986e0dd551f  pop rdi
00007986e0dd5520  pop rdx
00007986e0dd5521  pop rcx
00007986e0dd5522  pop rax
00007986e0dd5523  add rsp, 0x08
00007986e0dd5527  jmp 0x00007986E0DD02F7
00007986e0dd552c  sub rsp, 0x08
00007986e0dd5530  push rax
00007986e0dd5531  push rcx
00007986e0dd5532  push rdx
00007986e0dd5533  push rdi
00007986e0dd5534  push rsi
00007986e0dd5535  push r8
00007986e0dd5537  push r9
00007986e0dd5539  push r10
00007986e0dd553b  push r11
00007986e0dd553d  sub rsp, 0xF0
00007986e0dd5544  vmovaps [rsp], xmm0
00007986e0dd5549  vmovaps [rsp+0x10], xmm1
00007986e0dd554f  vmovaps [rsp+0x20], xmm2
00007986e0dd5555  vmovaps [rsp+0x30], xmm3
00007986e0dd555b  vmovaps [rsp+0x40], xmm4
00007986e0dd5561  vmovaps [rsp+0x50], xmm5
00007986e0dd5567  vmovaps [rsp+0x60], xmm6
00007986e0dd556d  vmovaps [rsp+0x70], xmm7
00007986e0dd5573  vmovaps [rsp+0x80], xmm8
00007986e0dd557c  vmovaps [rsp+0x90], xmm9
00007986e0dd5585  vmovaps [rsp+0xA0], xmm10
00007986e0dd558e  vmovaps [rsp+0xB0], xmm11
00007986e0dd5597  vmovaps [rsp+0xC0], xmm12
00007986e0dd55a0  vmovaps [rsp+0xD0], xmm13
00007986e0dd55a9  vmovaps [rsp+0xE0], xmm15
00007986e0dd55b2  sub rsp, 0x30
00007986e0dd55b6  movaps [rsp], xmm14
00007986e0dd55bb  movaps [rsp+0x10], xmm1
00007986e0dd55c0  movaps [rsp+0x20], xmm10
00007986e0dd55c6  lea rdi, [rsp]
00007986e0dd55ca  mov esi, 0x00
00007986e0dd55cf  mov rax, 0x5652C689F530
00007986e0dd55d9  call rax
00007986e0dd55db  movaps xmm14, [rsp]
00007986e0dd55e0  add rsp, 0x30
00007986e0dd55e4  vmovaps xmm0, [rsp]
00007986e0dd55e9  vmovaps xmm1, [rsp+0x10]
00007986e0dd55ef  vmovaps xmm2, [rsp+0x20]
00007986e0dd55f5  vmovaps xmm3, [rsp+0x30]
00007986e0dd55fb  vmovaps xmm4, [rsp+0x40]
00007986e0dd5601  vmovaps xmm5, [rsp+0x50]
00007986e0dd5607  vmovaps xmm6, [rsp+0x60]
00007986e0dd560d  vmovaps xmm7, [rsp+0x70]
00007986e0dd5613  vmovaps xmm8, [rsp+0x80]
00007986e0dd561c  vmovaps xmm9, [rsp+0x90]
00007986e0dd5625  vmovaps xmm10, [rsp+0xA0]
00007986e0dd562e  vmovaps xmm11, [rsp+0xB0]
00007986e0dd5637  vmovaps xmm12, [rsp+0xC0]
00007986e0dd5640  vmovaps xmm13, [rsp+0xD0]
00007986e0dd5649  vmovaps xmm15, [rsp+0xE0]
00007986e0dd5652  add rsp, 0xF0
00007986e0dd5659  pop r11
00007986e0dd565b  pop r10
00007986e0dd565d  pop r9
00007986e0dd565f  pop r8
00007986e0dd5661  pop rsi
00007986e0dd5662  pop rdi
00007986e0dd5663  pop rdx
00007986e0dd5664  pop rcx
00007986e0dd5665  pop rax
00007986e0dd5666  add rsp, 0x08
00007986e0dd566a  jmp 0x00007986E0DD031A
00007986e0dd566f  sub rsp, 0x08
00007986e0dd5673  push rax
00007986e0dd5674  push rcx
00007986e0dd5675  push rdx
00007986e0dd5676  push rdi
00007986e0dd5677  push rsi
00007986e0dd5678  push r8
00007986e0dd567a  push r9
00007986e0dd567c  push r10
00007986e0dd567e  push r11
00007986e0dd5680  sub rsp, 0xF0
00007986e0dd5687  vmovaps [rsp], xmm0
00007986e0dd568c  vmovaps [rsp+0x10], xmm2
00007986e0dd5692  vmovaps [rsp+0x20], xmm3
00007986e0dd5698  vmovaps [rsp+0x30], xmm4
00007986e0dd569e  vmovaps [rsp+0x40], xmm5
00007986e0dd56a4  vmovaps [rsp+0x50], xmm6
00007986e0dd56aa  vmovaps [rsp+0x60], xmm7
00007986e0dd56b0  vmovaps [rsp+0x70], xmm8
00007986e0dd56b6  vmovaps [rsp+0x80], xmm9
00007986e0dd56bf  vmovaps [rsp+0x90], xmm10
00007986e0dd56c8  vmovaps [rsp+0xA0], xmm11
00007986e0dd56d1  vmovaps [rsp+0xB0], xmm12
00007986e0dd56da  vmovaps [rsp+0xC0], xmm13
00007986e0dd56e3  vmovaps [rsp+0xD0], xmm14
00007986e0dd56ec  vmovaps [rsp+0xE0], xmm15
00007986e0dd56f5  sub rsp, 0x30
00007986e0dd56f9  movaps [rsp], xmm1
00007986e0dd56fd  movaps [rsp+0x10], xmm7
00007986e0dd5702  movaps [rsp+0x20], xmm11
00007986e0dd5708  lea rdi, [rsp]
00007986e0dd570c  mov esi, 0x00
00007986e0dd5711  mov rax, 0x5652C689F530
00007986e0dd571b  call rax
00007986e0dd571d  movaps xmm1, [rsp]
00007986e0dd5721  add rsp, 0x30
00007986e0dd5725  vmovaps xmm0, [rsp]
00007986e0dd572a  vmovaps xmm2, [rsp+0x10]
00007986e0dd5730  vmovaps xmm3, [rsp+0x20]
00007986e0dd5736  vmovaps xmm4, [rsp+0x30]
00007986e0dd573c  vmovaps xmm5, [rsp+0x40]
00007986e0dd5742  vmovaps xmm6, [rsp+0x50]
00007986e0dd5748  vmovaps xmm7, [rsp+0x60]
00007986e0dd574e  vmovaps xmm8, [rsp+0x70]
00007986e0dd5754  vmovaps xmm9, [rsp+0x80]
00007986e0dd575d  vmovaps xmm10, [rsp+0x90]
00007986e0dd5766  vmovaps xmm11, [rsp+0xA0]
00007986e0dd576f  vmovaps xmm12, [rsp+0xB0]
00007986e0dd5778  vmovaps xmm13, [rsp+0xC0]
00007986e0dd5781  vmovaps xmm14, [rsp+0xD0]
00007986e0dd578a  vmovaps xmm15, [rsp+0xE0]
00007986e0dd5793  add rsp, 0xF0
00007986e0dd579a  pop r11
00007986e0dd579c  pop r10
00007986e0dd579e  pop r9
00007986e0dd57a0  pop r8
00007986e0dd57a2  pop rsi
00007986e0dd57a3  pop rdi
00007986e0dd57a4  pop rdx
00007986e0dd57a5  pop rcx
00007986e0dd57a6  pop rax
00007986e0dd57a7  add rsp, 0x08
00007986e0dd57ab  jmp 0x00007986E0DD033B
00007986e0dd57b0  call 0x00007986E0C0E880
00007986e0dd57b5  jmp 0x00007986E0DD034E
00007986e0dd57ba  call 0x00007986E0C0C380
00007986e0dd57bf  jmp 0x00007986E0DD0359
00007986e0dd57c4  call 0x00007986E0C0D600
00007986e0dd57c9  jmp 0x00007986E0DD0364
00007986e0dd57ce  call 0x00007986E0BFF540
00007986e0dd57d3  jmp 0x00007986E0DD036F
00007986e0dd57d8  int3
00007986e0dd57d9  nop [rax], eax
00007986e0dd57e0  mov rax, [r15+0x40]
00007986e0dd57e4  mov r14, [r15+0x58]
00007986e0dd57e8  lea r12, [rax+r14*1]
00007986e0dd57ec  movaps xmm1, [r15+0x1D0]
00007986e0dd57f4  vmovaps [rsp+0x10], xmm1
00007986e0dd57fa  vmovaps xmm15, [rsp+0x10]
00007986e0dd5800  por xmm1, xmm15
00007986e0dd5805  movaps xmm14, [r15+0x1A0]
00007986e0dd580d  vmovaps [rsp+0x10], xmm14
00007986e0dd5813  vmovaps xmm13, [rsp+0x10]
00007986e0dd5819  por xmm14, xmm13
00007986e0dd581e  lea rax, [r12+0x30]
00007986e0dd5823  mov r11, [r13+rax*1]
00007986e0dd5828  lea rax, [r12+0x38]
00007986e0dd582d  mov r10, [r13+rax*1]
00007986e0dd5832  movq xmm13, r11
00007986e0dd5837  movq xmm12, r10
00007986e0dd583c  movq xmm13, xmm13
00007986e0dd5841  vmovaps [rsp+0x10], xmm13
00007986e0dd5847  movq xmm13, xmm13
00007986e0dd584c  movaps [r15+0x130], xmm13
00007986e0dd5854  movq xmm12, xmm12
00007986e0dd5859  vmovaps [rsp+0x20], xmm12
00007986e0dd585f  movq xmm12, xmm12
00007986e0dd5864  movaps [r15+0x280], xmm12
00007986e0dd586c  movaps xmm13, [r15+0x270]
00007986e0dd5874  vmovaps [rsp+0x30], xmm13
00007986e0dd587a  vmovaps xmm12, [rsp+0x30]
00007986e0dd5880  por xmm13, xmm12
00007986e0dd5885  lea rax, [r12+0x20]
00007986e0dd588a  mov r11, [r13+rax*1]
00007986e0dd588f  lea rax, [r12+0x28]
00007986e0dd5894  mov r10, [r13+rax*1]
00007986e0dd5899  movq xmm12, r11
00007986e0dd589e  movq xmm11, r10
00007986e0dd58a3  movq xmm12, xmm12
00007986e0dd58a8  vmovaps [rsp+0x30], xmm12
00007986e0dd58ae  movq xmm12, xmm12
00007986e0dd58b3  movaps [r15+0x150], xmm12
00007986e0dd58bb  movq xmm11, xmm11
00007986e0dd58c0  vmovaps [rsp+0x40], xmm11
00007986e0dd58c6  movq xmm11, xmm11
00007986e0dd58cb  movaps [r15+0x140], xmm11
00007986e0dd58d3  lea rax, [r12+0x10]
00007986e0dd58d8  mov r11, [r13+rax*1]
00007986e0dd58dd  lea rax, [r12+0x18]
00007986e0dd58e2  mov r10, [r13+rax*1]
00007986e0dd58e7  movq xmm12, r11
00007986e0dd58ec  movq xmm11, r10
00007986e0dd58f1  movq xmm12, xmm12
00007986e0dd58f6  vmovaps [rsp+0x50], xmm12
00007986e0dd58fc  movq xmm12, xmm12
00007986e0dd5901  movaps [r15+0x170], xmm12
00007986e0dd5909  movq xmm11, xmm11
00007986e0dd590e  vmovaps [rsp+0x60], xmm11
00007986e0dd5914  movq xmm11, xmm11
00007986e0dd5919  movaps [r15+0x160], xmm11
00007986e0dd5921  mov rax, [r13+r12*1]
00007986e0dd5926  vmovq xmm12, rax
00007986e0dd592b  vpbroadcastq xmm12, xmm12
00007986e0dd5930  lea rax, [r12+0x08]
00007986e0dd5935  mov r12, [r13+rax*1]
00007986e0dd593a  movq xmm11, r12
00007986e0dd593f  movaps [r15+0x230], xmm11
00007986e0dd5947  mov rax, [r15+0xF8]
00007986e0dd594e  lea r12, [rax+0x50]
00007986e0dd5952  movups xmm11, [r13+r12*1]
00007986e0dd5958  lea r12, [rax+0x60]
00007986e0dd595c  movups xmm10, [r13+r12*1]
00007986e0dd5962  lea r12, [rax+0x30]
00007986e0dd5966  movups xmm9, [r13+r12*1]
00007986e0dd596c  mov r12, [r15+0x50]
00007986e0dd5970  lea r11, [r12+r14*1]
00007986e0dd5974  mov [r15+0x60], r11
00007986e0dd5978  lea r12, [r14+0x40]
00007986e0dd597c  mov [r15+0x58], r12
00007986e0dd5980  movaps xmm8, xmm12
00007986e0dd5984  mulpd xmm8, xmm15
00007986e0dd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007986e0dd598f  ptest xmm7, xmm7
00007986e0dd5994  jnz 0x00007986E0DD67B7
00007986e0dd599a  movq xmm15, qword ptr [r15+0x230]
00007986e0dd59a3  vmovaps [rsp+0x70], xmm15
00007986e0dd59a9  vpermilpd xmm15, xmm15, 0x00
00007986e0dd59af  movaps xmm7, xmm9
00007986e0dd59b3  mulpd xmm7, xmm15
00007986e0dd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007986e0dd59bd  ptest xmm6, xmm6
00007986e0dd59c2  jnz 0x00007986E0DD68FB
00007986e0dd59c8  vxorps xmm15, xmm15, xmm15
00007986e0dd59cd  vpbroadcastq xmm15, xmm15
00007986e0dd59d2  movaps xmm9, xmm12
00007986e0dd59d6  mulpd xmm9, xmm10
00007986e0dd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007986e0dd59e1  ptest xmm6, xmm6
00007986e0dd59e6  jnz 0x00007986E0DD6A3D
00007986e0dd59ec  movaps xmm10, xmm12
00007986e0dd59f0  mulpd xmm10, xmm11
00007986e0dd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007986e0dd59fb  ptest xmm6, xmm6
00007986e0dd5a00  jnz 0x00007986E0DD6B81
00007986e0dd5a06  movaps xmm11, [r15+0x1F0]
00007986e0dd5a0e  movaps xmm6, xmm12
00007986e0dd5a12  mulpd xmm6, xmm11
00007986e0dd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007986e0dd5a1c  ptest xmm5, xmm5
00007986e0dd5a21  jnz 0x00007986E0DD6CC5
00007986e0dd5a27  movaps xmm12, [r15+0x2A0]
00007986e0dd5a2f  vmovaps [rsp+0x80], xmm12
00007986e0dd5a38  vmovaps xmm11, [rsp+0x80]
00007986e0dd5a41  por xmm12, xmm11
00007986e0dd5a46  movaps xmm11, [r15+0x250]
00007986e0dd5a4e  vmovaps [rsp+0x80], xmm11
00007986e0dd5a57  vmovaps xmm5, [rsp+0x80]
00007986e0dd5a60  por xmm11, xmm5
00007986e0dd5a65  vmovaps xmm4, [rsp+0x70]
00007986e0dd5a6b  vpermilpd xmm4, xmm4, 0x00
00007986e0dd5a71  movaps xmm3, xmm5
00007986e0dd5a74  mulpd xmm3, xmm4
00007986e0dd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007986e0dd5a7d  ptest xmm2, xmm2
00007986e0dd5a82  jnz 0x00007986E0DD6E07
00007986e0dd5a88  mov [rsp+0x80], rax
00007986e0dd5a90  xor eax, eax
00007986e0dd5a92  mov r14d, 0x200
00007986e0dd5a98  cmp r12, r14
00007986e0dd5a9b  cmc
00007986e0dd5a9c  lahf
00007986e0dd5a9d  seto al
00007986e0dd5aa0  mov [r15+0x108], eax
00007986e0dd5aa7  movaps xmm5, xmm8
00007986e0dd5aab  addpd xmm5, xmm15
00007986e0dd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007986e0dd5ab5  ptest xmm4, xmm4
00007986e0dd5aba  jnz 0x00007986E0DD6F47
00007986e0dd5ac0  movaps xmm8, [r15+0x1B0]
00007986e0dd5ac8  movaps xmm4, xmm9
00007986e0dd5acc  addpd xmm4, xmm8
00007986e0dd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007986e0dd5ad6  ptest xmm2, xmm2
00007986e0dd5adb  jnz 0x00007986E0DD7089
00007986e0dd5ae1  movaps xmm9, xmm10
00007986e0dd5ae5  addpd xmm9, xmm8
00007986e0dd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007986e0dd5af0  ptest xmm2, xmm2
00007986e0dd5af5  jnz 0x00007986E0DD71CB
00007986e0dd5afb  movaps xmm10, [r15+0x2F0]
00007986e0dd5b03  vmovaps [rsp+0x90], xmm10
00007986e0dd5b0c  vmovaps xmm8, [rsp+0x90]
00007986e0dd5b15  por xmm10, xmm8
00007986e0dd5b1a  movaps xmm8, [r15+0x2E0]
00007986e0dd5b22  vmovaps [rsp+0x90], xmm8
00007986e0dd5b2b  vmovaps xmm2, [rsp+0x90]
00007986e0dd5b34  por xmm8, xmm2
00007986e0dd5b39  movaps xmm2, [r15+0x2D0]
00007986e0dd5b41  vmovaps [rsp+0x90], xmm2
00007986e0dd5b4a  vmovaps [rsp+0xA0], xmm1
00007986e0dd5b53  vmovaps xmm1, [rsp+0x90]
00007986e0dd5b5c  por xmm2, xmm1
00007986e0dd5b60  movaps xmm1, [r15+0x200]
00007986e0dd5b68  vmovaps [rsp+0x90], xmm1
00007986e0dd5b71  vmovaps [rsp+0xB0], xmm15
00007986e0dd5b7a  vmovaps xmm15, [rsp+0x90]
00007986e0dd5b83  por xmm1, xmm15
00007986e0dd5b88  movaps xmm15, [r15+0x1C0]
00007986e0dd5b90  vmovaps [rsp+0x90], xmm15
00007986e0dd5b99  vmovaps [rsp+0xC0], xmm1
00007986e0dd5ba2  vmovaps xmm1, [rsp+0x90]
00007986e0dd5bab  por xmm15, xmm1
00007986e0dd5bb0  movaps xmm1, [r15+0x190]
00007986e0dd5bb8  vmovaps [rsp+0x90], xmm1
00007986e0dd5bc1  vmovaps [rsp+0xD0], xmm15
00007986e0dd5bca  vmovaps xmm15, [rsp+0x90]
00007986e0dd5bd3  por xmm1, xmm15
00007986e0dd5bd8  movaps xmm15, [r15+0x300]
00007986e0dd5be0  vmovaps [rsp+0x90], xmm15
00007986e0dd5be9  vmovaps [rsp+0xE0], xmm1
00007986e0dd5bf2  vmovaps xmm1, [rsp+0x90]
00007986e0dd5bfb  por xmm15, xmm1
00007986e0dd5c00  mov rax, [rsp+0x80]
00007986e0dd5c08  lea r14, [rax+0xA0]
00007986e0dd5c0f  movups xmm1, [r13+r14*1]
00007986e0dd5c15  lea r14, [rax+0xB0]
00007986e0dd5c1c  vmovaps [rsp+0x80], xmm1
00007986e0dd5c25  movups xmm1, [r13+r14*1]
00007986e0dd5c2b  vmovaps [rsp+0x90], xmm1
00007986e0dd5c34  vmovaps [rsp+0xF0], xmm15
00007986e0dd5c3d  vmovaps xmm15, [rsp+0xB0]
00007986e0dd5c46  vmovaps [rsp+0xB0], xmm14
00007986e0dd5c4f  movaps xmm1, xmm6
00007986e0dd5c52  addpd xmm1, xmm15
00007986e0dd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007986e0dd5c5c  ptest xmm14, xmm14
00007986e0dd5c62  jnz 0x00007986E0DD7323
00007986e0dd5c68  lea r14, [rax+0xF0]
00007986e0dd5c6f  movups xmm15, [r13+r14*1]
00007986e0dd5c75  movaps xmm14, xmm4
00007986e0dd5c79  addpd xmm14, xmm3
00007986e0dd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007986e0dd5c84  ptest xmm6, xmm6
00007986e0dd5c89  jnz 0x00007986E0DD746E
00007986e0dd5c8f  movaps xmm6, xmm9
00007986e0dd5c93  addpd xmm6, xmm7
00007986e0dd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007986e0dd5c9c  ptest xmm4, xmm4
00007986e0dd5ca1  jnz 0x00007986E0DD75B0
00007986e0dd5ca7  vmovaps xmm9, [rsp+0x70]
00007986e0dd5cad  vpermilpd xmm9, xmm9, 0x00
00007986e0dd5cb3  vmovaps xmm4, [rsp+0x90]
00007986e0dd5cbc  movaps xmm7, xmm4
00007986e0dd5cbf  mulpd xmm7, xmm9
00007986e0dd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007986e0dd5cc9  ptest xmm3, xmm3
00007986e0dd5cce  jnz 0x00007986E0DD76F1
00007986e0dd5cd4  vmovaps xmm9, [rsp+0x50]
00007986e0dd5cda  vpermilpd xmm9, xmm9, 0x00
00007986e0dd5ce0  movaps xmm4, xmm15
00007986e0dd5ce4  mulpd xmm4, xmm9
00007986e0dd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007986e0dd5cee  ptest xmm3, xmm3
00007986e0dd5cf3  jnz 0x00007986E0DD7832
00007986e0dd5cf9  lea r14, [rax+0xE0]
00007986e0dd5d00  movups xmm15, [r13+r14*1]
00007986e0dd5d06  vmovaps xmm9, [rsp+0x70]
00007986e0dd5d0c  vpermilpd xmm9, xmm9, 0x00
00007986e0dd5d12  vmovaps [rsp+0x70], xmm1
00007986e0dd5d18  vmovaps xmm1, [rsp+0x80]
00007986e0dd5d21  vmovaps [rsp+0x80], xmm15
00007986e0dd5d2a  movaps xmm3, xmm1
00007986e0dd5d2d  mulpd xmm3, xmm9
00007986e0dd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007986e0dd5d37  ptest xmm15, xmm15
00007986e0dd5d3d  jnz 0x00007986E0DD797E
00007986e0dd5d43  vmovaps xmm1, [rsp+0xF0]
00007986e0dd5d4c  vmovaps xmm15, [rsp+0xF0]
00007986e0dd5d55  por xmm1, xmm15
00007986e0dd5d5a  movaps [r15+0x300], xmm1
00007986e0dd5d62  vmovaps xmm15, [rsp+0xE0]
00007986e0dd5d6b  vmovaps xmm9, [rsp+0xE0]
00007986e0dd5d74  por xmm15, xmm9
00007986e0dd5d79  movaps [r15+0x190], xmm15
00007986e0dd5d81  vmovaps xmm9, [rsp+0x50]
00007986e0dd5d87  vpermilpd xmm9, xmm9, 0x00
00007986e0dd5d8d  vmovaps [rsp+0x90], xmm1
00007986e0dd5d96  vmovaps [rsp+0xE0], xmm15
00007986e0dd5d9f  vmovaps xmm15, [rsp+0x80]
00007986e0dd5da8  vmovaps [rsp+0x80], xmm14
00007986e0dd5db1  movaps xmm1, xmm15
00007986e0dd5db5  mulpd xmm1, xmm9
00007986e0dd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007986e0dd5dbf  ptest xmm14, xmm14
00007986e0dd5dc5  jnz 0x00007986E0DD7ABF
00007986e0dd5dcb  lea r14, [rax+0x90]
00007986e0dd5dd2  movups xmm15, [r13+r14*1]
00007986e0dd5dd8  vmovaps xmm14, [rsp+0xD0]
00007986e0dd5de1  vmovaps xmm9, [rsp+0xD0]
00007986e0dd5dea  por xmm14, xmm9
00007986e0dd5def  movaps [r15+0x1C0], xmm14
00007986e0dd5df7  vmovaps xmm9, [rsp+0xC0]
00007986e0dd5e00  vmovaps [rsp+0xD0], xmm1
00007986e0dd5e09  vmovaps xmm1, [rsp+0xC0]
00007986e0dd5e12  por xmm9, xmm1
00007986e0dd5e17  movaps [r15+0x200], xmm9
00007986e0dd5e1f  vmovaps [rsp+0xC0], xmm2
00007986e0dd5e28  vmovaps xmm1, [rsp+0xC0]
00007986e0dd5e31  por xmm2, xmm1
00007986e0dd5e35  movaps [r15+0x2D0], xmm2
00007986e0dd5e3d  vmovaps [rsp+0xC0], xmm8
00007986e0dd5e46  vmovaps xmm1, [rsp+0xC0]
00007986e0dd5e4f  por xmm8, xmm1
00007986e0dd5e54  movaps [r15+0x2E0], xmm8
00007986e0dd5e5c  vmovaps [rsp+0xC0], xmm15
00007986e0dd5e65  movaps xmm1, xmm5
00007986e0dd5e68  addpd xmm1, xmm7
00007986e0dd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007986e0dd5e71  ptest xmm15, xmm15
00007986e0dd5e77  jnz 0x00007986E0DD7C0B
00007986e0dd5e7d  vmovaps xmm15, [rsp+0x50]
00007986e0dd5e83  vpermilpd xmm15, xmm15, 0x00
00007986e0dd5e89  vmovaps xmm5, [rsp+0xC0]
00007986e0dd5e92  vmovaps [rsp+0xC0], xmm1
00007986e0dd5e9b  movaps xmm7, xmm5
00007986e0dd5e9e  mulpd xmm7, xmm15
00007986e0dd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007986e0dd5ea8  ptest xmm1, xmm1
00007986e0dd5ead  jnz 0x00007986E0DD7D4B
00007986e0dd5eb3  lea r14, [rax+0x80]
00007986e0dd5eba  movups xmm1, [r13+r14*1]
00007986e0dd5ec0  vmovaps xmm5, [rsp+0x70]
00007986e0dd5ec6  vmovaps [rsp+0x70], xmm1
00007986e0dd5ecc  movaps xmm15, xmm5
00007986e0dd5ed0  addpd xmm15, xmm3
00007986e0dd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007986e0dd5edb  ptest xmm1, xmm1
00007986e0dd5ee0  jnz 0x00007986E0DD7E96
00007986e0dd5ee6  vmovaps xmm5, [rsp+0x80]
00007986e0dd5eef  movaps xmm1, xmm5
00007986e0dd5ef2  addpd xmm1, xmm4
00007986e0dd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007986e0dd5efb  ptest xmm3, xmm3
00007986e0dd5f00  jnz 0x00007986E0DD7FD8
00007986e0dd5f06  vmovaps [rsp+0x80], xmm10
00007986e0dd5f0f  vmovaps xmm5, [rsp+0x80]
00007986e0dd5f18  por xmm10, xmm5
00007986e0dd5f1d  movaps [r15+0x2F0], xmm10
00007986e0dd5f25  vmovaps xmm5, [rsp+0x50]
00007986e0dd5f2b  vpermilpd xmm5, xmm5, 0x00
00007986e0dd5f31  vmovaps xmm3, [rsp+0x70]
00007986e0dd5f37  vmovaps [rsp+0x50], xmm1
00007986e0dd5f3d  movaps xmm4, xmm3
00007986e0dd5f40  mulpd xmm4, xmm5
00007986e0dd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007986e0dd5f49  ptest xmm1, xmm1
00007986e0dd5f4e  jnz 0x00007986E0DD8118
00007986e0dd5f54  lea r14, [rax+0xD0]
00007986e0dd5f5b  movups xmm1, [r13+r14*1]
00007986e0dd5f61  vmovaps xmm3, [rsp+0xD0]
00007986e0dd5f6a  vmovaps [rsp+0x70], xmm1
00007986e0dd5f70  movaps xmm5, xmm6
00007986e0dd5f73  addpd xmm5, xmm3
00007986e0dd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007986e0dd5f7c  ptest xmm1, xmm1
00007986e0dd5f81  jnz 0x00007986E0DD8262
00007986e0dd5f87  vmovaps xmm1, [rsp+0x60]
00007986e0dd5f8d  vpermilpd xmm1, xmm1, 0x00
00007986e0dd5f93  movaps xmm6, xmm9
00007986e0dd5f97  mulpd xmm6, xmm1
00007986e0dd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007986e0dd5fa0  ptest xmm3, xmm3
00007986e0dd5fa5  jnz 0x00007986E0DD83A2
00007986e0dd5fab  movaps [r15+0x260], xmm6
00007986e0dd5fb3  vxorps xmm1, xmm1, xmm1
00007986e0dd5fb7  vpbroadcastq xmm1, xmm1
00007986e0dd5fbc  movaps [r15+0x1B0], xmm1
00007986e0dd5fc4  vmovaps xmm1, [rsp+0x60]
00007986e0dd5fca  vpermilpd xmm1, xmm1, 0x00
00007986e0dd5fd0  vmovaps xmm3, [rsp+0x70]
00007986e0dd5fd6  vmovaps [rsp+0x70], xmm15
00007986e0dd5fdc  movaps xmm9, xmm3
00007986e0dd5fe0  mulpd xmm9, xmm1
00007986e0dd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007986e0dd5feb  ptest xmm15, xmm15
00007986e0dd5ff1  jnz 0x00007986E0DD84E3
00007986e0dd5ff7  lea r14, [rax+0xC0]
00007986e0dd5ffe  movups xmm1, [r13+r14*1]
00007986e0dd6004  vmovaps xmm3, [rsp+0xC0]
00007986e0dd600d  vmovaps [rsp+0x80], xmm1
00007986e0dd6016  movaps xmm15, xmm3
00007986e0dd601a  addpd xmm15, xmm7
00007986e0dd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007986e0dd6025  ptest xmm1, xmm1
00007986e0dd602a  jnz 0x00007986E0DD862F
00007986e0dd6030  vmovaps [rsp+0xC0], xmm13
00007986e0dd6039  vmovaps xmm1, [rsp+0xC0]
00007986e0dd6042  por xmm13, xmm1
00007986e0dd6047  movaps [r15+0x270], xmm13
00007986e0dd604f  vmovaps xmm1, [rsp+0xB0]
00007986e0dd6058  vmovaps xmm7, [rsp+0xB0]
00007986e0dd6061  por xmm1, xmm7
00007986e0dd6065  movaps [r15+0x1A0], xmm1
00007986e0dd606d  vmovaps xmm1, [rsp+0x60]
00007986e0dd6073  vpermilpd xmm1, xmm1, 0x00
00007986e0dd6079  vmovaps [rsp+0xB0], xmm1
00007986e0dd6082  vmovaps xmm1, [rsp+0x80]
00007986e0dd608b  vmovaps [rsp+0x80], xmm15
00007986e0dd6094  vmovaps xmm15, [rsp+0xB0]
00007986e0dd609d  vmovaps [rsp+0xB0], xmm14
00007986e0dd60a6  movaps xmm3, xmm1
00007986e0dd60a9  mulpd xmm3, xmm15
00007986e0dd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007986e0dd60b3  ptest xmm14, xmm14
00007986e0dd60b9  jnz 0x00007986E0DD8771
00007986e0dd60bf  lea r14, [rax+0x20]
00007986e0dd60c3  movups xmm1, [r13+r14*1]
00007986e0dd60c9  movaps [r15+0x110], xmm1
00007986e0dd60d1  vmovaps xmm14, [rsp+0x70]
00007986e0dd60d7  vmovaps [rsp+0x70], xmm1
00007986e0dd60dd  movaps xmm15, xmm14
00007986e0dd60e1  addpd xmm15, xmm4
00007986e0dd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007986e0dd60ec  ptest xmm1, xmm1
00007986e0dd60f1  jnz 0x00007986E0DD88BC
00007986e0dd60f7  vmovaps xmm1, [rsp+0x60]
00007986e0dd60fd  vpermilpd xmm1, xmm1, 0x00
00007986e0dd6103  movaps xmm14, xmm2
00007986e0dd6107  mulpd xmm14, xmm1
00007986e0dd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007986e0dd6112  ptest xmm4, xmm4
00007986e0dd6117  jnz 0x00007986E0DD89FF
00007986e0dd611d  vmovaps xmm4, [rsp+0x50]
00007986e0dd6123  movaps xmm1, xmm4
00007986e0dd6126  addpd xmm1, xmm9
00007986e0dd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007986e0dd6130  ptest xmm2, xmm2
00007986e0dd6135  jnz 0x00007986E0DD8B41
00007986e0dd613b  vmovaps xmm9, [rsp+0x30]
00007986e0dd6141  vpermilpd xmm9, xmm9, 0x00
00007986e0dd6147  vmovaps xmm2, [rsp+0x70]
00007986e0dd614d  vmovaps [rsp+0x50], xmm1
00007986e0dd6153  movaps xmm4, xmm2
00007986e0dd6156  mulpd xmm4, xmm9
00007986e0dd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007986e0dd6160  ptest xmm1, xmm1
00007986e0dd6165  jnz 0x00007986E0DD8C82
00007986e0dd616b  vmovaps xmm1, [rsp+0x30]
00007986e0dd6171  vpermilpd xmm1, xmm1, 0x00
00007986e0dd6177  vmovaps xmm2, [rsp+0x90]
00007986e0dd6180  vmovaps [rsp+0x60], xmm15
00007986e0dd6186  movaps xmm9, xmm2
00007986e0dd618a  mulpd xmm9, xmm1
00007986e0dd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007986e0dd6195  ptest xmm15, xmm15
00007986e0dd619b  jnz 0x00007986E0DD8DC3
00007986e0dd61a1  vmovaps xmm15, [rsp+0x80]
00007986e0dd61aa  movaps xmm1, xmm15
00007986e0dd61ae  addpd xmm1, xmm6
00007986e0dd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007986e0dd61b7  ptest xmm2, xmm2
00007986e0dd61bc  jnz 0x00007986E0DD8F05
00007986e0dd61c2  movaps xmm15, xmm5
00007986e0dd61c6  addpd xmm15, xmm3
00007986e0dd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007986e0dd61d1  ptest xmm6, xmm6
00007986e0dd61d6  jnz 0x00007986E0DD9046
00007986e0dd61dc  vmovaps xmm6, [rsp+0x30]
00007986e0dd61e2  vpermilpd xmm6, xmm6, 0x00
00007986e0dd61e8  movaps xmm5, xmm8
00007986e0dd61ec  mulpd xmm5, xmm6
00007986e0dd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007986e0dd61f5  ptest xmm3, xmm3
00007986e0dd61fa  jnz 0x00007986E0DD9188
00007986e0dd6200  vmovaps xmm8, [rsp+0x30]
00007986e0dd6206  vpermilpd xmm8, xmm8, 0x00
00007986e0dd620c  movaps xmm6, xmm10
00007986e0dd6210  mulpd xmm6, xmm8
00007986e0dd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007986e0dd621a  ptest xmm3, xmm3
00007986e0dd621f  jnz 0x00007986E0DD92C9
00007986e0dd6225  vmovaps xmm8, [rsp+0x60]
00007986e0dd622b  movaps xmm10, xmm8
00007986e0dd622f  addpd xmm10, xmm14
00007986e0dd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007986e0dd623a  ptest xmm3, xmm3
00007986e0dd623f  jnz 0x00007986E0DD940B
00007986e0dd6245  vmovaps xmm8, [rsp+0x50]
00007986e0dd624b  movaps xmm14, xmm8
00007986e0dd624f  addpd xmm14, xmm4
00007986e0dd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007986e0dd625a  ptest xmm3, xmm3
00007986e0dd625f  jnz 0x00007986E0DD954F
00007986e0dd6265  vmovaps xmm8, [rsp+0x40]
00007986e0dd626b  vpermilpd xmm8, xmm8, 0x00
00007986e0dd6271  movaps xmm4, xmm13
00007986e0dd6275  mulpd xmm4, xmm8
00007986e0dd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007986e0dd627f  ptest xmm3, xmm3
00007986e0dd6284  jnz 0x00007986E0DD9692
00007986e0dd628a  movaps xmm13, xmm15
00007986e0dd628e  addpd xmm13, xmm9
00007986e0dd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007986e0dd6299  ptest xmm8, xmm8
00007986e0dd629f  jnz 0x00007986E0DD97D4
00007986e0dd62a5  movaps xmm15, xmm1
00007986e0dd62a9  addpd xmm15, xmm5
00007986e0dd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007986e0dd62b4  ptest xmm9, xmm9
00007986e0dd62ba  jnz 0x00007986E0DD9918
00007986e0dd62c0  vmovaps [rsp+0x30], xmm11
00007986e0dd62c6  vmovaps xmm1, [rsp+0x30]
00007986e0dd62cc  por xmm11, xmm1
00007986e0dd62d1  movaps [r15+0x250], xmm11
00007986e0dd62d9  vmovaps [rsp+0x30], xmm12
00007986e0dd62df  vmovaps xmm1, [rsp+0x30]
00007986e0dd62e5  por xmm12, xmm1
00007986e0dd62ea  movaps [r15+0x2A0], xmm12
00007986e0dd62f2  vmovaps xmm1, [rsp+0xA0]
00007986e0dd62fb  vmovaps xmm11, [rsp+0xA0]
00007986e0dd6304  por xmm1, xmm11
00007986e0dd6309  movaps [r15+0x1D0], xmm1
00007986e0dd6311  lea r14, [rax+0x40]
00007986e0dd6315  movups xmm1, [r13+r14*1]
00007986e0dd631b  movaps [r15+0x2C0], xmm1
00007986e0dd6323  vmovaps xmm11, [rsp+0x40]
00007986e0dd6329  vpermilpd xmm11, xmm11, 0x00
00007986e0dd632f  vmovaps xmm8, [rsp+0xE0]
00007986e0dd6338  movaps xmm9, xmm8
00007986e0dd633c  mulpd xmm9, xmm11
00007986e0dd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007986e0dd6347  ptest xmm5, xmm5
00007986e0dd634c  jnz 0x00007986E0DD9A64
00007986e0dd6352  movaps xmm11, xmm10
00007986e0dd6356  addpd xmm11, xmm6
00007986e0dd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007986e0dd6361  ptest xmm8, xmm8
00007986e0dd6367  jnz 0x00007986E0DD9BA8
00007986e0dd636d  movaps xmm10, xmm14
00007986e0dd6371  addpd xmm10, xmm4
00007986e0dd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007986e0dd637c  ptest xmm8, xmm8
00007986e0dd6382  jnz 0x00007986E0DD9CEB
00007986e0dd6388  vmovaps xmm14, [rsp+0x40]
00007986e0dd638e  vpermilpd xmm14, xmm14, 0x00
00007986e0dd6394  movaps xmm8, xmm1
00007986e0dd6398  mulpd xmm8, xmm14
00007986e0dd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007986e0dd63a3  ptest xmm6, xmm6
00007986e0dd63a8  jnz 0x00007986E0DD9E2E
00007986e0dd63ae  movaps xmm1, [r15+0x2B0]
00007986e0dd63b6  vmovaps xmm14, [rsp+0x40]
00007986e0dd63bc  vpermilpd xmm14, xmm14, 0x00
00007986e0dd63c2  movaps xmm6, xmm1
00007986e0dd63c5  mulpd xmm6, xmm14
00007986e0dd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007986e0dd63cf  ptest xmm5, xmm5
00007986e0dd63d4  jnz 0x00007986E0DD9F71
00007986e0dd63da  vmovaps xmm1, [rsp+0x10]
00007986e0dd63e0  vpermilpd xmm1, xmm1, 0x00
00007986e0dd63e6  movaps xmm14, xmm12
00007986e0dd63ea  mulpd xmm14, xmm1
00007986e0dd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007986e0dd63f5  ptest xmm5, xmm5
00007986e0dd63fa  jnz 0x00007986E0DDA0B2
00007986e0dd6400  movaps xmm1, xmm13
00007986e0dd6404  addpd xmm1, xmm9
00007986e0dd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007986e0dd640e  ptest xmm12, xmm12
00007986e0dd6414  jnz 0x00007986E0DDA1F5
00007986e0dd641a  vmovaps xmm13, [rsp+0x10]
00007986e0dd6420  vpermilpd xmm13, xmm13, 0x00
00007986e0dd6426  movaps xmm12, xmm7
00007986e0dd642a  mulpd xmm12, xmm13
00007986e0dd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007986e0dd6435  ptest xmm9, xmm9
00007986e0dd643b  jnz 0x00007986E0DDA337
00007986e0dd6441  movaps xmm13, xmm15
00007986e0dd6445  addpd xmm13, xmm8
00007986e0dd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007986e0dd6450  ptest xmm9, xmm9
00007986e0dd6456  jnz 0x00007986E0DDA47A
00007986e0dd645c  movaps xmm15, [r15+0x290]
00007986e0dd6464  vmovaps xmm9, [rsp+0x10]
00007986e0dd646a  vpermilpd xmm9, xmm9, 0x00
00007986e0dd6470  movaps xmm8, xmm15
00007986e0dd6474  mulpd xmm8, xmm9
00007986e0dd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007986e0dd647f  ptest xmm7, xmm7
00007986e0dd6484  jnz 0x00007986E0DDA5BE
00007986e0dd648a  movaps xmm15, xmm11
00007986e0dd648e  addpd xmm15, xmm6
00007986e0dd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007986e0dd6499  ptest xmm9, xmm9
00007986e0dd649f  jnz 0x00007986E0DDA702
00007986e0dd64a5  movaps xmm11, [r15+0x1E0]
00007986e0dd64ad  vmovaps xmm9, [rsp+0x10]
00007986e0dd64b3  vpermilpd xmm9, xmm9, 0x00
00007986e0dd64b9  movaps xmm7, xmm11
00007986e0dd64bd  mulpd xmm7, xmm9
00007986e0dd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007986e0dd64c7  ptest xmm6, xmm6
00007986e0dd64cc  jnz 0x00007986E0DDA845
00007986e0dd64d2  movaps xmm11, xmm10
00007986e0dd64d6  addpd xmm11, xmm14
00007986e0dd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007986e0dd64e1  ptest xmm9, xmm9
00007986e0dd64e7  jnz 0x00007986E0DDA987
00007986e0dd64ed  lea r14, [rax+0x70]
00007986e0dd64f1  movups xmm14, [r13+r14*1]
00007986e0dd64f7  movaps [r15+0x240], xmm14
00007986e0dd64ff  movaps xmm10, xmm1
00007986e0dd6503  addpd xmm10, xmm12
00007986e0dd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007986e0dd650e  ptest xmm9, xmm9
00007986e0dd6514  jnz 0x00007986E0DDAAD5
00007986e0dd651a  movaps [r15+0x170], xmm10
00007986e0dd6522  vmovaps xmm1, [rsp+0x20]
00007986e0dd6528  vpermilpd xmm1, xmm1, 0x00
00007986e0dd652e  movaps xmm12, xmm14
00007986e0dd6532  mulpd xmm12, xmm1
00007986e0dd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007986e0dd653d  ptest xmm9, xmm9
00007986e0dd6543  jnz 0x00007986E0DDAC18
00007986e0dd6549  vmovaps xmm1, [rsp+0x20]
00007986e0dd654f  vpermilpd xmm1, xmm1, 0x00
00007986e0dd6555  vmovaps xmm9, [rsp+0xB0]
00007986e0dd655e  movaps xmm14, xmm9
00007986e0dd6562  mulpd xmm14, xmm1
00007986e0dd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007986e0dd656d  ptest xmm6, xmm6
00007986e0dd6572  jnz 0x00007986E0DDAD5B
00007986e0dd6578  movaps [r15+0x180], xmm14
00007986e0dd6580  movaps xmm1, xmm13
00007986e0dd6584  addpd xmm1, xmm8
00007986e0dd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007986e0dd658e  ptest xmm9, xmm9
00007986e0dd6594  jnz 0x00007986E0DDAE9E
00007986e0dd659a  movaps [r15+0x210], xmm1
00007986e0dd65a2  movups xmm13, [r13+rax*1]
00007986e0dd65a8  lea r14, [rax+0x10]
00007986e0dd65ac  movups xmm9, [r13+r14*1]
00007986e0dd65b2  movaps [r15+0x230], xmm9
00007986e0dd65ba  movaps xmm8, xmm15
00007986e0dd65be  addpd xmm8, xmm7
00007986e0dd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007986e0dd65c9  ptest xmm6, xmm6
00007986e0dd65ce  jnz 0x00007986E0DDAFF4
00007986e0dd65d4  movaps [r15+0x130], xmm8
00007986e0dd65dc  vmovaps xmm15, [rsp+0x20]
00007986e0dd65e2  vpermilpd xmm15, xmm15, 0x00
00007986e0dd65e8  movaps xmm7, xmm9
00007986e0dd65ec  mulpd xmm7, xmm15
00007986e0dd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007986e0dd65f6  ptest xmm6, xmm6
00007986e0dd65fb  jnz 0x00007986E0DDB137
00007986e0dd6601  movaps [r15+0x220], xmm7
00007986e0dd6609  vmovaps xmm15, [rsp+0x20]
00007986e0dd660f  vpermilpd xmm15, xmm15, 0x00
00007986e0dd6615  movaps xmm9, xmm13
00007986e0dd6619  mulpd xmm9, xmm15
00007986e0dd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007986e0dd6624  ptest xmm6, xmm6
00007986e0dd6629  jnz 0x00007986E0DDB279
00007986e0dd662f  movaps xmm15, xmm11
00007986e0dd6633  addpd xmm15, xmm12
00007986e0dd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007986e0dd663e  ptest xmm13, xmm13
00007986e0dd6644  jnz 0x00007986E0DDB3BD
00007986e0dd664a  movaps [r15+0x140], xmm15
00007986e0dd6652  movaps xmm13, xmm10
00007986e0dd6656  addpd xmm13, xmm14
00007986e0dd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007986e0dd6661  ptest xmm12, xmm12
00007986e0dd6667  jnz 0x00007986E0DDB501
00007986e0dd666d  movaps [r15+0x150], xmm13
00007986e0dd6675  movaps xmm14, xmm1
00007986e0dd6679  addpd xmm14, xmm7
00007986e0dd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007986e0dd6684  ptest xmm12, xmm12
00007986e0dd668a  jnz 0x00007986E0DDB645
00007986e0dd6690  movaps [r15+0x160], xmm14
00007986e0dd6698  movaps xmm1, xmm8
00007986e0dd669c  addpd xmm1, xmm9
00007986e0dd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007986e0dd66a6  ptest xmm12, xmm12
00007986e0dd66ac  jnz 0x00007986E0DDB787
00007986e0dd66b2  movaps [r15+0x120], xmm1
00007986e0dd66ba  movups [r13+r11*1], xmm15
00007986e0dd66c0  lea rax, [r11+0x10]
00007986e0dd66c4  movups [r13+rax*1], xmm13
00007986e0dd66ca  lea rax, [r11+0x20]
00007986e0dd66ce  movups [r13+rax*1], xmm14
00007986e0dd66d4  lea rax, [r11+0x30]
00007986e0dd66d8  movups [r13+rax*1], xmm1
00007986e0dd66de  mov eax, [r15+0x108]
00007986e0dd66e5  sahf
00007986e0dd66e6  jnz 0x00007986E0DD6718
00007986e0dd66e8  cmp dword ptr [r15+0x318], 0x00
00007986e0dd66f0  jz 0x00007986E0DDB900
00007986e0dd66f6  nop [rax+rax*1], ax
00007986e0dd66ff  nop [rax+rax*1], eax
00007986e0dd6707  mov eax, 0x410444
00007986e0dd670c  mov [r15+0x100], rax
00007986e0dd6713  jmp 0x00007986E0BFE110
00007986e0dd6718  cmp dword ptr [r15+0x318], 0x00
00007986e0dd6720  jz 0x00007986E0DD57E0
00007986e0dd6726  nop [rax+rax*1], ax
00007986e0dd672f  nop [rax+rax*1], eax
00007986e0dd6737  mov eax, 0x410278
00007986e0dd673c  mov [r15+0x100], rax
00007986e0dd6743  jmp 0x00007986E0BFE110
00007986e0dd6748  int3
00007986e0dd6749  call 0x00007986E0C0A4B0
00007986e0dd674e  jmp 0x00007986E0DD5828
00007986e0dd6753  call 0x00007986E0C09240
00007986e0dd6758  jmp 0x00007986E0DD5832
00007986e0dd675d  call 0x00007986E0C0A4B0
00007986e0dd6762  jmp 0x00007986E0DD588F
00007986e0dd6767  call 0x00007986E0C09240
00007986e0dd676c  jmp 0x00007986E0DD5899
00007986e0dd6771  call 0x00007986E0C0A4B0
00007986e0dd6776  jmp 0x00007986E0DD58DD
00007986e0dd677b  call 0x00007986E0C09240
00007986e0dd6780  jmp 0x00007986E0DD58E7
00007986e0dd6785  call 0x00007986E0CB47C0
00007986e0dd678a  jmp 0x00007986E0DD5926
00007986e0dd678f  call 0x00007986E0C0B720
00007986e0dd6794  jmp 0x00007986E0DD593A
00007986e0dd6799  call 0x00007986E0CBFC30
00007986e0dd679e  jmp 0x00007986E0DD5958
00007986e0dd67a3  call 0x00007986E0CBE9C0
00007986e0dd67a8  jmp 0x00007986E0DD5962
00007986e0dd67ad  call 0x00007986E0CBD750
00007986e0dd67b2  jmp 0x00007986E0DD596C
00007986e0dd67b7  sub rsp, 0x08
00007986e0dd67bb  push rax
00007986e0dd67bc  push rcx
00007986e0dd67bd  push rdx
00007986e0dd67be  push rdi
00007986e0dd67bf  push rsi
00007986e0dd67c0  push r8
00007986e0dd67c2  push r9
00007986e0dd67c4  push r10
00007986e0dd67c6  push r11
00007986e0dd67c8  sub rsp, 0xF0
00007986e0dd67cf  vmovaps [rsp], xmm0
00007986e0dd67d4  vmovaps [rsp+0x10], xmm1
00007986e0dd67da  vmovaps [rsp+0x20], xmm2
00007986e0dd67e0  vmovaps [rsp+0x30], xmm3
00007986e0dd67e6  vmovaps [rsp+0x40], xmm4
00007986e0dd67ec  vmovaps [rsp+0x50], xmm5
00007986e0dd67f2  vmovaps [rsp+0x60], xmm6
00007986e0dd67f8  vmovaps [rsp+0x70], xmm7
00007986e0dd67fe  vmovaps [rsp+0x80], xmm9
00007986e0dd6807  vmovaps [rsp+0x90], xmm10
00007986e0dd6810  vmovaps [rsp+0xA0], xmm11
00007986e0dd6819  vmovaps [rsp+0xB0], xmm12
00007986e0dd6822  vmovaps [rsp+0xC0], xmm13
00007986e0dd682b  vmovaps [rsp+0xD0], xmm14
00007986e0dd6834  vmovaps [rsp+0xE0], xmm15
00007986e0dd683d  sub rsp, 0x30
00007986e0dd6841  movaps [rsp], xmm8
00007986e0dd6846  movaps [rsp+0x10], xmm12
00007986e0dd684c  movaps [rsp+0x20], xmm15
00007986e0dd6852  lea rdi, [rsp]
00007986e0dd6856  mov esi, 0x00
00007986e0dd685b  mov rax, 0x5652C689F530
00007986e0dd6865  call rax
00007986e0dd6867  movaps xmm8, [rsp]
00007986e0dd686c  add rsp, 0x30
00007986e0dd6870  vmovaps xmm0, [rsp]
00007986e0dd6875  vmovaps xmm1, [rsp+0x10]
00007986e0dd687b  vmovaps xmm2, [rsp+0x20]
00007986e0dd6881  vmovaps xmm3, [rsp+0x30]
00007986e0dd6887  vmovaps xmm4, [rsp+0x40]
00007986e0dd688d  vmovaps xmm5, [rsp+0x50]
00007986e0dd6893  vmovaps xmm6, [rsp+0x60]
00007986e0dd6899  vmovaps xmm7, [rsp+0x70]
00007986e0dd689f  vmovaps xmm9, [rsp+0x80]
00007986e0dd68a8  vmovaps xmm10, [rsp+0x90]
00007986e0dd68b1  vmovaps xmm11, [rsp+0xA0]
00007986e0dd68ba  vmovaps xmm12, [rsp+0xB0]
00007986e0dd68c3  vmovaps xmm13, [rsp+0xC0]
00007986e0dd68cc  vmovaps xmm14, [rsp+0xD0]
00007986e0dd68d5  vmovaps xmm15, [rsp+0xE0]
00007986e0dd68de  add rsp, 0xF0
00007986e0dd68e5  pop r11
00007986e0dd68e7  pop r10
00007986e0dd68e9  pop r9
00007986e0dd68eb  pop r8
00007986e0dd68ed  pop rsi
00007986e0dd68ee  pop rdi
00007986e0dd68ef  pop rdx
00007986e0dd68f0  pop rcx
00007986e0dd68f1  pop rax
00007986e0dd68f2  add rsp, 0x08
00007986e0dd68f6  jmp 0x00007986E0DD599A
00007986e0dd68fb  sub rsp, 0x08
00007986e0dd68ff  push rax
00007986e0dd6900  push rcx
00007986e0dd6901  push rdx
00007986e0dd6902  push rdi
00007986e0dd6903  push rsi
00007986e0dd6904  push r8
00007986e0dd6906  push r9
00007986e0dd6908  push r10
00007986e0dd690a  push r11
00007986e0dd690c  sub rsp, 0xF0
00007986e0dd6913  vmovaps [rsp], xmm0
00007986e0dd6918  vmovaps [rsp+0x10], xmm1
00007986e0dd691e  vmovaps [rsp+0x20], xmm2
00007986e0dd6924  vmovaps [rsp+0x30], xmm3
00007986e0dd692a  vmovaps [rsp+0x40], xmm4
00007986e0dd6930  vmovaps [rsp+0x50], xmm5
00007986e0dd6936  vmovaps [rsp+0x60], xmm6
00007986e0dd693c  vmovaps [rsp+0x70], xmm8
00007986e0dd6942  vmovaps [rsp+0x80], xmm9
00007986e0dd694b  vmovaps [rsp+0x90], xmm10
00007986e0dd6954  vmovaps [rsp+0xA0], xmm11
00007986e0dd695d  vmovaps [rsp+0xB0], xmm12
00007986e0dd6966  vmovaps [rsp+0xC0], xmm13
00007986e0dd696f  vmovaps [rsp+0xD0], xmm14
00007986e0dd6978  vmovaps [rsp+0xE0], xmm15
00007986e0dd6981  sub rsp, 0x30
00007986e0dd6985  movaps [rsp], xmm7
00007986e0dd6989  movaps [rsp+0x10], xmm9
00007986e0dd698f  movaps [rsp+0x20], xmm15
00007986e0dd6995  lea rdi, [rsp]
00007986e0dd6999  mov esi, 0x00
00007986e0dd699e  mov rax, 0x5652C689F530
00007986e0dd69a8  call rax
00007986e0dd69aa  movaps xmm7, [rsp]
00007986e0dd69ae  add rsp, 0x30
00007986e0dd69b2  vmovaps xmm0, [rsp]
00007986e0dd69b7  vmovaps xmm1, [rsp+0x10]
00007986e0dd69bd  vmovaps xmm2, [rsp+0x20]
00007986e0dd69c3  vmovaps xmm3, [rsp+0x30]
00007986e0dd69c9  vmovaps xmm4, [rsp+0x40]
00007986e0dd69cf  vmovaps xmm5, [rsp+0x50]
00007986e0dd69d5  vmovaps xmm6, [rsp+0x60]
00007986e0dd69db  vmovaps xmm8, [rsp+0x70]
00007986e0dd69e1  vmovaps xmm9, [rsp+0x80]
00007986e0dd69ea  vmovaps xmm10, [rsp+0x90]
00007986e0dd69f3  vmovaps xmm11, [rsp+0xA0]
00007986e0dd69fc  vmovaps xmm12, [rsp+0xB0]
00007986e0dd6a05  vmovaps xmm13, [rsp+0xC0]
00007986e0dd6a0e  vmovaps xmm14, [rsp+0xD0]
00007986e0dd6a17  vmovaps xmm15, [rsp+0xE0]
00007986e0dd6a20  add rsp, 0xF0
00007986e0dd6a27  pop r11
00007986e0dd6a29  pop r10
00007986e0dd6a2b  pop r9
00007986e0dd6a2d  pop r8
00007986e0dd6a2f  pop rsi
00007986e0dd6a30  pop rdi
00007986e0dd6a31  pop rdx
00007986e0dd6a32  pop rcx
00007986e0dd6a33  pop rax
00007986e0dd6a34  add rsp, 0x08
00007986e0dd6a38  jmp 0x00007986E0DD59C8
00007986e0dd6a3d  sub rsp, 0x08
00007986e0dd6a41  push rax
00007986e0dd6a42  push rcx
00007986e0dd6a43  push rdx
00007986e0dd6a44  push rdi
00007986e0dd6a45  push rsi
00007986e0dd6a46  push r8
00007986e0dd6a48  push r9
00007986e0dd6a4a  push r10
00007986e0dd6a4c  push r11
00007986e0dd6a4e  sub rsp, 0xF0
00007986e0dd6a55  vmovaps [rsp], xmm0
00007986e0dd6a5a  vmovaps [rsp+0x10], xmm1
00007986e0dd6a60  vmovaps [rsp+0x20], xmm2
00007986e0dd6a66  vmovaps [rsp+0x30], xmm3
00007986e0dd6a6c  vmovaps [rsp+0x40], xmm4
00007986e0dd6a72  vmovaps [rsp+0x50], xmm5
00007986e0dd6a78  vmovaps [rsp+0x60], xmm6
00007986e0dd6a7e  vmovaps [rsp+0x70], xmm7
00007986e0dd6a84  vmovaps [rsp+0x80], xmm8
00007986e0dd6a8d  vmovaps [rsp+0x90], xmm10
00007986e0dd6a96  vmovaps [rsp+0xA0], xmm11
00007986e0dd6a9f  vmovaps [rsp+0xB0], xmm12
00007986e0dd6aa8  vmovaps [rsp+0xC0], xmm13
00007986e0dd6ab1  vmovaps [rsp+0xD0], xmm14
00007986e0dd6aba  vmovaps [rsp+0xE0], xmm15
00007986e0dd6ac3  sub rsp, 0x30
00007986e0dd6ac7  movaps [rsp], xmm9
00007986e0dd6acc  movaps [rsp+0x10], xmm12
00007986e0dd6ad2  movaps [rsp+0x20], xmm10
00007986e0dd6ad8  lea rdi, [rsp]
00007986e0dd6adc  mov esi, 0x00
00007986e0dd6ae1  mov rax, 0x5652C689F530
00007986e0dd6aeb  call rax
00007986e0dd6aed  movaps xmm9, [rsp]
00007986e0dd6af2  add rsp, 0x30
00007986e0dd6af6  vmovaps xmm0, [rsp]
00007986e0dd6afb  vmovaps xmm1, [rsp+0x10]
00007986e0dd6b01  vmovaps xmm2, [rsp+0x20]
00007986e0dd6b07  vmovaps xmm3, [rsp+0x30]
00007986e0dd6b0d  vmovaps xmm4, [rsp+0x40]
00007986e0dd6b13  vmovaps xmm5, [rsp+0x50]
00007986e0dd6b19  vmovaps xmm6, [rsp+0x60]
00007986e0dd6b1f  vmovaps xmm7, [rsp+0x70]
00007986e0dd6b25  vmovaps xmm8, [rsp+0x80]
00007986e0dd6b2e  vmovaps xmm10, [rsp+0x90]
00007986e0dd6b37  vmovaps xmm11, [rsp+0xA0]
00007986e0dd6b40  vmovaps xmm12, [rsp+0xB0]
00007986e0dd6b49  vmovaps xmm13, [rsp+0xC0]
00007986e0dd6b52  vmovaps xmm14, [rsp+0xD0]
00007986e0dd6b5b  vmovaps xmm15, [rsp+0xE0]
00007986e0dd6b64  add rsp, 0xF0
00007986e0dd6b6b  pop r11
00007986e0dd6b6d  pop r10
00007986e0dd6b6f  pop r9
00007986e0dd6b71  pop r8
00007986e0dd6b73  pop rsi
00007986e0dd6b74  pop rdi
00007986e0dd6b75  pop rdx
00007986e0dd6b76  pop rcx
00007986e0dd6b77  pop rax
00007986e0dd6b78  add rsp, 0x08
00007986e0dd6b7c  jmp 0x00007986E0DD59EC
00007986e0dd6b81  sub rsp, 0x08
00007986e0dd6b85  push rax
00007986e0dd6b86  push rcx
00007986e0dd6b87  push rdx
00007986e0dd6b88  push rdi
00007986e0dd6b89  push rsi
00007986e0dd6b8a  push r8
00007986e0dd6b8c  push r9
00007986e0dd6b8e  push r10
00007986e0dd6b90  push r11
00007986e0dd6b92  sub rsp, 0xF0
00007986e0dd6b99  vmovaps [rsp], xmm0
00007986e0dd6b9e  vmovaps [rsp+0x10], xmm1
00007986e0dd6ba4  vmovaps [rsp+0x20], xmm2
00007986e0dd6baa  vmovaps [rsp+0x30], xmm3
00007986e0dd6bb0  vmovaps [rsp+0x40], xmm4
00007986e0dd6bb6  vmovaps [rsp+0x50], xmm5
00007986e0dd6bbc  vmovaps [rsp+0x60], xmm6
00007986e0dd6bc2  vmovaps [rsp+0x70], xmm7
00007986e0dd6bc8  vmovaps [rsp+0x80], xmm8
00007986e0dd6bd1  vmovaps [rsp+0x90], xmm9
00007986e0dd6bda  vmovaps [rsp+0xA0], xmm11
00007986e0dd6be3  vmovaps [rsp+0xB0], xmm12
00007986e0dd6bec  vmovaps [rsp+0xC0], xmm13
00007986e0dd6bf5  vmovaps [rsp+0xD0], xmm14
00007986e0dd6bfe  vmovaps [rsp+0xE0], xmm15
00007986e0dd6c07  sub rsp, 0x30
00007986e0dd6c0b  movaps [rsp], xmm10
00007986e0dd6c10  movaps [rsp+0x10], xmm12
00007986e0dd6c16  movaps [rsp+0x20], xmm11
00007986e0dd6c1c  lea rdi, [rsp]
00007986e0dd6c20  mov esi, 0x00
00007986e0dd6c25  mov rax, 0x5652C689F530
00007986e0dd6c2f  call rax
00007986e0dd6c31  movaps xmm10, [rsp]
00007986e0dd6c36  add rsp, 0x30
00007986e0dd6c3a  vmovaps xmm0, [rsp]
00007986e0dd6c3f  vmovaps xmm1, [rsp+0x10]
00007986e0dd6c45  vmovaps xmm2, [rsp+0x20]
00007986e0dd6c4b  vmovaps xmm3, [rsp+0x30]
00007986e0dd6c51  vmovaps xmm4, [rsp+0x40]
00007986e0dd6c57  vmovaps xmm5, [rsp+0x50]
00007986e0dd6c5d  vmovaps xmm6, [rsp+0x60]
00007986e0dd6c63  vmovaps xmm7, [rsp+0x70]
00007986e0dd6c69  vmovaps xmm8, [rsp+0x80]
00007986e0dd6c72  vmovaps xmm9, [rsp+0x90]
00007986e0dd6c7b  vmovaps xmm11, [rsp+0xA0]
00007986e0dd6c84  vmovaps xmm12, [rsp+0xB0]
00007986e0dd6c8d  vmovaps xmm13, [rsp+0xC0]
00007986e0dd6c96  vmovaps xmm14, [rsp+0xD0]
00007986e0dd6c9f  vmovaps xmm15, [rsp+0xE0]
00007986e0dd6ca8  add rsp, 0xF0
00007986e0dd6caf  pop r11
00007986e0dd6cb1  pop r10
00007986e0dd6cb3  pop r9
00007986e0dd6cb5  pop r8
00007986e0dd6cb7  pop rsi
00007986e0dd6cb8  pop rdi
00007986e0dd6cb9  pop rdx
00007986e0dd6cba  pop rcx
00007986e0dd6cbb  pop rax
00007986e0dd6cbc  add rsp, 0x08
00007986e0dd6cc0  jmp 0x00007986E0DD5A06
00007986e0dd6cc5  sub rsp, 0x08
00007986e0dd6cc9  push rax
00007986e0dd6cca  push rcx
00007986e0dd6ccb  push rdx
00007986e0dd6ccc  push rdi
00007986e0dd6ccd  push rsi
00007986e0dd6cce  push r8
00007986e0dd6cd0  push r9
00007986e0dd6cd2  push r10
00007986e0dd6cd4  push r11
00007986e0dd6cd6  sub rsp, 0xF0
00007986e0dd6cdd  vmovaps [rsp], xmm0
00007986e0dd6ce2  vmovaps [rsp+0x10], xmm1
00007986e0dd6ce8  vmovaps [rsp+0x20], xmm2
00007986e0dd6cee  vmovaps [rsp+0x30], xmm3
00007986e0dd6cf4  vmovaps [rsp+0x40], xmm4
00007986e0dd6cfa  vmovaps [rsp+0x50], xmm5
00007986e0dd6d00  vmovaps [rsp+0x60], xmm7
00007986e0dd6d06  vmovaps [rsp+0x70], xmm8
00007986e0dd6d0c  vmovaps [rsp+0x80], xmm9
00007986e0dd6d15  vmovaps [rsp+0x90], xmm10
00007986e0dd6d1e  vmovaps [rsp+0xA0], xmm11
00007986e0dd6d27  vmovaps [rsp+0xB0], xmm12
00007986e0dd6d30  vmovaps [rsp+0xC0], xmm13
00007986e0dd6d39  vmovaps [rsp+0xD0], xmm14
00007986e0dd6d42  vmovaps [rsp+0xE0], xmm15
00007986e0dd6d4b  sub rsp, 0x30
00007986e0dd6d4f  movaps [rsp], xmm6
00007986e0dd6d53  movaps [rsp+0x10], xmm12
00007986e0dd6d59  movaps [rsp+0x20], xmm11
00007986e0dd6d5f  lea rdi, [rsp]
00007986e0dd6d63  mov esi, 0x00
00007986e0dd6d68  mov rax, 0x5652C689F530
00007986e0dd6d72  call rax
00007986e0dd6d74  movaps xmm6, [rsp]
00007986e0dd6d78  add rsp, 0x30
00007986e0dd6d7c  vmovaps xmm0, [rsp]
00007986e0dd6d81  vmovaps xmm1, [rsp+0x10]
00007986e0dd6d87  vmovaps xmm2, [rsp+0x20]
00007986e0dd6d8d  vmovaps xmm3, [rsp+0x30]
00007986e0dd6d93  vmovaps xmm4, [rsp+0x40]
00007986e0dd6d99  vmovaps xmm5, [rsp+0x50]
00007986e0dd6d9f  vmovaps xmm7, [rsp+0x60]
00007986e0dd6da5  vmovaps xmm8, [rsp+0x70]
00007986e0dd6dab  vmovaps xmm9, [rsp+0x80]
00007986e0dd6db4  vmovaps xmm10, [rsp+0x90]
00007986e0dd6dbd  vmovaps xmm11, [rsp+0xA0]
00007986e0dd6dc6  vmovaps xmm12, [rsp+0xB0]
00007986e0dd6dcf  vmovaps xmm13, [rsp+0xC0]
00007986e0dd6dd8  vmovaps xmm14, [rsp+0xD0]
00007986e0dd6de1  vmovaps xmm15, [rsp+0xE0]
00007986e0dd6dea  add rsp, 0xF0
00007986e0dd6df1  pop r11
00007986e0dd6df3  pop r10
00007986e0dd6df5  pop r9
00007986e0dd6df7  pop r8
00007986e0dd6df9  pop rsi
00007986e0dd6dfa  pop rdi
00007986e0dd6dfb  pop rdx
00007986e0dd6dfc  pop rcx
00007986e0dd6dfd  pop rax
00007986e0dd6dfe  add rsp, 0x08
00007986e0dd6e02  jmp 0x00007986E0DD5A27
00007986e0dd6e07  sub rsp, 0x08
00007986e0dd6e0b  push rax
00007986e0dd6e0c  push rcx
00007986e0dd6e0d  push rdx
00007986e0dd6e0e  push rdi
00007986e0dd6e0f  push rsi
00007986e0dd6e10  push r8
00007986e0dd6e12  push r9
00007986e0dd6e14  push r10
00007986e0dd6e16  push r11
00007986e0dd6e18  sub rsp, 0xF0
00007986e0dd6e1f  vmovaps [rsp], xmm0
00007986e0dd6e24  vmovaps [rsp+0x10], xmm1
00007986e0dd6e2a  vmovaps [rsp+0x20], xmm2
00007986e0dd6e30  vmovaps [rsp+0x30], xmm4
00007986e0dd6e36  vmovaps [rsp+0x40], xmm5
00007986e0dd6e3c  vmovaps [rsp+0x50], xmm6
00007986e0dd6e42  vmovaps [rsp+0x60], xmm7
00007986e0dd6e48  vmovaps [rsp+0x70], xmm8
00007986e0dd6e4e  vmovaps [rsp+0x80], xmm9
00007986e0dd6e57  vmovaps [rsp+0x90], xmm10
00007986e0dd6e60  vmovaps [rsp+0xA0], xmm11
00007986e0dd6e69  vmovaps [rsp+0xB0], xmm12
00007986e0dd6e72  vmovaps [rsp+0xC0], xmm13
00007986e0dd6e7b  vmovaps [rsp+0xD0], xmm14
00007986e0dd6e84  vmovaps [rsp+0xE0], xmm15
00007986e0dd6e8d  sub rsp, 0x30
00007986e0dd6e91  movaps [rsp], xmm3
00007986e0dd6e95  movaps [rsp+0x10], xmm5
00007986e0dd6e9a  movaps [rsp+0x20], xmm4
00007986e0dd6e9f  lea rdi, [rsp]
00007986e0dd6ea3  mov esi, 0x00
00007986e0dd6ea8  mov rax, 0x5652C689F530
00007986e0dd6eb2  call rax
00007986e0dd6eb4  movaps xmm3, [rsp]
00007986e0dd6eb8  add rsp, 0x30
00007986e0dd6ebc  vmovaps xmm0, [rsp]
00007986e0dd6ec1  vmovaps xmm1, [rsp+0x10]
00007986e0dd6ec7  vmovaps xmm2, [rsp+0x20]
00007986e0dd6ecd  vmovaps xmm4, [rsp+0x30]
00007986e0dd6ed3  vmovaps xmm5, [rsp+0x40]
00007986e0dd6ed9  vmovaps xmm6, [rsp+0x50]
00007986e0dd6edf  vmovaps xmm7, [rsp+0x60]
00007986e0dd6ee5  vmovaps xmm8, [rsp+0x70]
00007986e0dd6eeb  vmovaps xmm9, [rsp+0x80]
00007986e0dd6ef4  vmovaps xmm10, [rsp+0x90]
00007986e0dd6efd  vmovaps xmm11, [rsp+0xA0]
00007986e0dd6f06  vmovaps xmm12, [rsp+0xB0]
00007986e0dd6f0f  vmovaps xmm13, [rsp+0xC0]
00007986e0dd6f18  vmovaps xmm14, [rsp+0xD0]
00007986e0dd6f21  vmovaps xmm15, [rsp+0xE0]
00007986e0dd6f2a  add rsp, 0xF0
00007986e0dd6f31  pop r11
00007986e0dd6f33  pop r10
00007986e0dd6f35  pop r9
00007986e0dd6f37  pop r8
00007986e0dd6f39  pop rsi
00007986e0dd6f3a  pop rdi
00007986e0dd6f3b  pop rdx
00007986e0dd6f3c  pop rcx
00007986e0dd6f3d  pop rax
00007986e0dd6f3e  add rsp, 0x08
00007986e0dd6f42  jmp 0x00007986E0DD5A88
00007986e0dd6f47  sub rsp, 0x08
00007986e0dd6f4b  push rax
00007986e0dd6f4c  push rcx
00007986e0dd6f4d  push rdx
00007986e0dd6f4e  push rdi
00007986e0dd6f4f  push rsi
00007986e0dd6f50  push r8
00007986e0dd6f52  push r9
00007986e0dd6f54  push r10
00007986e0dd6f56  push r11
00007986e0dd6f58  sub rsp, 0xF0
00007986e0dd6f5f  vmovaps [rsp], xmm0
00007986e0dd6f64  vmovaps [rsp+0x10], xmm1
00007986e0dd6f6a  vmovaps [rsp+0x20], xmm2
00007986e0dd6f70  vmovaps [rsp+0x30], xmm3
00007986e0dd6f76  vmovaps [rsp+0x40], xmm4
00007986e0dd6f7c  vmovaps [rsp+0x50], xmm6
00007986e0dd6f82  vmovaps [rsp+0x60], xmm7
00007986e0dd6f88  vmovaps [rsp+0x70], xmm8
00007986e0dd6f8e  vmovaps [rsp+0x80], xmm9
00007986e0dd6f97  vmovaps [rsp+0x90], xmm10
00007986e0dd6fa0  vmovaps [rsp+0xA0], xmm11
00007986e0dd6fa9  vmovaps [rsp+0xB0], xmm12
00007986e0dd6fb2  vmovaps [rsp+0xC0], xmm13
00007986e0dd6fbb  vmovaps [rsp+0xD0], xmm14
00007986e0dd6fc4  vmovaps [rsp+0xE0], xmm15
00007986e0dd6fcd  sub rsp, 0x30
00007986e0dd6fd1  movaps [rsp], xmm5
00007986e0dd6fd5  movaps [rsp+0x10], xmm8
00007986e0dd6fdb  movaps [rsp+0x20], xmm15
00007986e0dd6fe1  lea rdi, [rsp]
00007986e0dd6fe5  mov esi, 0x00
00007986e0dd6fea  mov rax, 0x5652C689F530
00007986e0dd6ff4  call rax
00007986e0dd6ff6  movaps xmm5, [rsp]
00007986e0dd6ffa  add rsp, 0x30
00007986e0dd6ffe  vmovaps xmm0, [rsp]
00007986e0dd7003  vmovaps xmm1, [rsp+0x10]
00007986e0dd7009  vmovaps xmm2, [rsp+0x20]
00007986e0dd700f  vmovaps xmm3, [rsp+0x30]
00007986e0dd7015  vmovaps xmm4, [rsp+0x40]
00007986e0dd701b  vmovaps xmm6, [rsp+0x50]
00007986e0dd7021  vmovaps xmm7, [rsp+0x60]
00007986e0dd7027  vmovaps xmm8, [rsp+0x70]
00007986e0dd702d  vmovaps xmm9, [rsp+0x80]
00007986e0dd7036  vmovaps xmm10, [rsp+0x90]
00007986e0dd703f  vmovaps xmm11, [rsp+0xA0]
00007986e0dd7048  vmovaps xmm12, [rsp+0xB0]
00007986e0dd7051  vmovaps xmm13, [rsp+0xC0]
00007986e0dd705a  vmovaps xmm14, [rsp+0xD0]
00007986e0dd7063  vmovaps xmm15, [rsp+0xE0]
00007986e0dd706c  add rsp, 0xF0
00007986e0dd7073  pop r11
00007986e0dd7075  pop r10
00007986e0dd7077  pop r9
00007986e0dd7079  pop r8
00007986e0dd707b  pop rsi
00007986e0dd707c  pop rdi
00007986e0dd707d  pop rdx
00007986e0dd707e  pop rcx
00007986e0dd707f  pop rax
00007986e0dd7080  add rsp, 0x08
00007986e0dd7084  jmp 0x00007986E0DD5AC0
00007986e0dd7089  sub rsp, 0x08
00007986e0dd708d  push rax
00007986e0dd708e  push rcx
00007986e0dd708f  push rdx
00007986e0dd7090  push rdi
00007986e0dd7091  push rsi
00007986e0dd7092  push r8
00007986e0dd7094  push r9
00007986e0dd7096  push r10
00007986e0dd7098  push r11
00007986e0dd709a  sub rsp, 0xF0
00007986e0dd70a1  vmovaps [rsp], xmm0
00007986e0dd70a6  vmovaps [rsp+0x10], xmm1
00007986e0dd70ac  vmovaps [rsp+0x20], xmm2
00007986e0dd70b2  vmovaps [rsp+0x30], xmm3
00007986e0dd70b8  vmovaps [rsp+0x40], xmm5
00007986e0dd70be  vmovaps [rsp+0x50], xmm6
00007986e0dd70c4  vmovaps [rsp+0x60], xmm7
00007986e0dd70ca  vmovaps [rsp+0x70], xmm8
00007986e0dd70d0  vmovaps [rsp+0x80], xmm9
00007986e0dd70d9  vmovaps [rsp+0x90], xmm10
00007986e0dd70e2  vmovaps [rsp+0xA0], xmm11
00007986e0dd70eb  vmovaps [rsp+0xB0], xmm12
00007986e0dd70f4  vmovaps [rsp+0xC0], xmm13
00007986e0dd70fd  vmovaps [rsp+0xD0], xmm14
00007986e0dd7106  vmovaps [rsp+0xE0], xmm15
00007986e0dd710f  sub rsp, 0x30
00007986e0dd7113  movaps [rsp], xmm4
00007986e0dd7117  movaps [rsp+0x10], xmm9
00007986e0dd711d  movaps [rsp+0x20], xmm8
00007986e0dd7123  lea rdi, [rsp]
00007986e0dd7127  mov esi, 0x00
00007986e0dd712c  mov rax, 0x5652C689F530
00007986e0dd7136  call rax
00007986e0dd7138  movaps xmm4, [rsp]
00007986e0dd713c  add rsp, 0x30
00007986e0dd7140  vmovaps xmm0, [rsp]
00007986e0dd7145  vmovaps xmm1, [rsp+0x10]
00007986e0dd714b  vmovaps xmm2, [rsp+0x20]
00007986e0dd7151  vmovaps xmm3, [rsp+0x30]
00007986e0dd7157  vmovaps xmm5, [rsp+0x40]
00007986e0dd715d  vmovaps xmm6, [rsp+0x50]
00007986e0dd7163  vmovaps xmm7, [rsp+0x60]
00007986e0dd7169  vmovaps xmm8, [rsp+0x70]
00007986e0dd716f  vmovaps xmm9, [rsp+0x80]
00007986e0dd7178  vmovaps xmm10, [rsp+0x90]
00007986e0dd7181  vmovaps xmm11, [rsp+0xA0]
00007986e0dd718a  vmovaps xmm12, [rsp+0xB0]
00007986e0dd7193  vmovaps xmm13, [rsp+0xC0]
00007986e0dd719c  vmovaps xmm14, [rsp+0xD0]
00007986e0dd71a5  vmovaps xmm15, [rsp+0xE0]
00007986e0dd71ae  add rsp, 0xF0
00007986e0dd71b5  pop r11
00007986e0dd71b7  pop r10
00007986e0dd71b9  pop r9
00007986e0dd71bb  pop r8
00007986e0dd71bd  pop rsi
00007986e0dd71be  pop rdi
00007986e0dd71bf  pop rdx
00007986e0dd71c0  pop rcx
00007986e0dd71c1  pop rax
00007986e0dd71c2  add rsp, 0x08
00007986e0dd71c6  jmp 0x00007986E0DD5AE1
00007986e0dd71cb  sub rsp, 0x08
00007986e0dd71cf  push rax
00007986e0dd71d0  push rcx
00007986e0dd71d1  push rdx
00007986e0dd71d2  push rdi
00007986e0dd71d3  push rsi
00007986e0dd71d4  push r8
00007986e0dd71d6  push r9
00007986e0dd71d8  push r10
00007986e0dd71da  push r11
00007986e0dd71dc  sub rsp, 0xF0
00007986e0dd71e3  vmovaps [rsp], xmm0
00007986e0dd71e8  vmovaps [rsp+0x10], xmm1
00007986e0dd71ee  vmovaps [rsp+0x20], xmm2
00007986e0dd71f4  vmovaps [rsp+0x30], xmm3
00007986e0dd71fa  vmovaps [rsp+0x40], xmm4
00007986e0dd7200  vmovaps [rsp+0x50], xmm5
00007986e0dd7206  vmovaps [rsp+0x60], xmm6
00007986e0dd720c  vmovaps [rsp+0x70], xmm7
00007986e0dd7212  vmovaps [rsp+0x80], xmm8
00007986e0dd721b  vmovaps [rsp+0x90], xmm10
00007986e0dd7224  vmovaps [rsp+0xA0], xmm11
00007986e0dd722d  vmovaps [rsp+0xB0], xmm12
00007986e0dd7236  vmovaps [rsp+0xC0], xmm13
00007986e0dd723f  vmovaps [rsp+0xD0], xmm14
00007986e0dd7248  vmovaps [rsp+0xE0], xmm15
00007986e0dd7251  sub rsp, 0x30
00007986e0dd7255  movaps [rsp], xmm9
00007986e0dd725a  movaps [rsp+0x10], xmm10
00007986e0dd7260  movaps [rsp+0x20], xmm8
00007986e0dd7266  lea rdi, [rsp]
00007986e0dd726a  mov esi, 0x00
00007986e0dd726f  mov rax, 0x5652C689F530
00007986e0dd7279  call rax
00007986e0dd727b  movaps xmm9, [rsp]
00007986e0dd7280  add rsp, 0x30
00007986e0dd7284  vmovaps xmm0, [rsp]
00007986e0dd7289  vmovaps xmm1, [rsp+0x10]
00007986e0dd728f  vmovaps xmm2, [rsp+0x20]
00007986e0dd7295  vmovaps xmm3, [rsp+0x30]
00007986e0dd729b  vmovaps xmm4, [rsp+0x40]
00007986e0dd72a1  vmovaps xmm5, [rsp+0x50]
00007986e0dd72a7  vmovaps xmm6, [rsp+0x60]
00007986e0dd72ad  vmovaps xmm7, [rsp+0x70]
00007986e0dd72b3  vmovaps xmm8, [rsp+0x80]
00007986e0dd72bc  vmovaps xmm10, [rsp+0x90]
00007986e0dd72c5  vmovaps xmm11, [rsp+0xA0]
00007986e0dd72ce  vmovaps xmm12, [rsp+0xB0]
00007986e0dd72d7  vmovaps xmm13, [rsp+0xC0]
00007986e0dd72e0  vmovaps xmm14, [rsp+0xD0]
00007986e0dd72e9  vmovaps xmm15, [rsp+0xE0]
00007986e0dd72f2  add rsp, 0xF0
00007986e0dd72f9  pop r11
00007986e0dd72fb  pop r10
00007986e0dd72fd  pop r9
00007986e0dd72ff  pop r8
00007986e0dd7301  pop rsi
00007986e0dd7302  pop rdi
00007986e0dd7303  pop rdx
00007986e0dd7304  pop rcx
00007986e0dd7305  pop rax
00007986e0dd7306  add rsp, 0x08
00007986e0dd730a  jmp 0x00007986E0DD5AFB
00007986e0dd730f  call 0x00007986E0CD64F0
00007986e0dd7314  jmp 0x00007986E0DD5C15
00007986e0dd7319  call 0x00007986E0CD64F0
00007986e0dd731e  jmp 0x00007986E0DD5C2B
00007986e0dd7323  sub rsp, 0x08
00007986e0dd7327  push rax
00007986e0dd7328  push rcx
00007986e0dd7329  push rdx
00007986e0dd732a  push rdi
00007986e0dd732b  push rsi
00007986e0dd732c  push r8
00007986e0dd732e  push r9
00007986e0dd7330  push r10
00007986e0dd7332  push r11
00007986e0dd7334  sub rsp, 0xF0
00007986e0dd733b  vmovaps [rsp], xmm0
00007986e0dd7340  vmovaps [rsp+0x10], xmm2
00007986e0dd7346  vmovaps [rsp+0x20], xmm3
00007986e0dd734c  vmovaps [rsp+0x30], xmm4
00007986e0dd7352  vmovaps [rsp+0x40], xmm5
00007986e0dd7358  vmovaps [rsp+0x50], xmm6
00007986e0dd735e  vmovaps [rsp+0x60], xmm7
00007986e0dd7364  vmovaps [rsp+0x70], xmm8
00007986e0dd736a  vmovaps [rsp+0x80], xmm9
00007986e0dd7373  vmovaps [rsp+0x90], xmm10
00007986e0dd737c  vmovaps [rsp+0xA0], xmm11
00007986e0dd7385  vmovaps [rsp+0xB0], xmm12
00007986e0dd738e  vmovaps [rsp+0xC0], xmm13
00007986e0dd7397  vmovaps [rsp+0xD0], xmm14
00007986e0dd73a0  vmovaps [rsp+0xE0], xmm15
00007986e0dd73a9  sub rsp, 0x30
00007986e0dd73ad  movaps [rsp], xmm1
00007986e0dd73b1  movaps [rsp+0x10], xmm6
00007986e0dd73b6  movaps [rsp+0x20], xmm15
00007986e0dd73bc  lea rdi, [rsp]
00007986e0dd73c0  mov esi, 0x00
00007986e0dd73c5  mov rax, 0x5652C689F530
00007986e0dd73cf  call rax
00007986e0dd73d1  movaps xmm1, [rsp]
00007986e0dd73d5  add rsp, 0x30
00007986e0dd73d9  vmovaps xmm0, [rsp]
00007986e0dd73de  vmovaps xmm2, [rsp+0x10]
00007986e0dd73e4  vmovaps xmm3, [rsp+0x20]
00007986e0dd73ea  vmovaps xmm4, [rsp+0x30]
00007986e0dd73f0  vmovaps xmm5, [rsp+0x40]
00007986e0dd73f6  vmovaps xmm6, [rsp+0x50]
00007986e0dd73fc  vmovaps xmm7, [rsp+0x60]
00007986e0dd7402  vmovaps xmm8, [rsp+0x70]
00007986e0dd7408  vmovaps xmm9, [rsp+0x80]
00007986e0dd7411  vmovaps xmm10, [rsp+0x90]
00007986e0dd741a  vmovaps xmm11, [rsp+0xA0]
00007986e0dd7423  vmovaps xmm12, [rsp+0xB0]
00007986e0dd742c  vmovaps xmm13, [rsp+0xC0]
00007986e0dd7435  vmovaps xmm14, [rsp+0xD0]
00007986e0dd743e  vmovaps xmm15, [rsp+0xE0]
00007986e0dd7447  add rsp, 0xF0
00007986e0dd744e  pop r11
00007986e0dd7450  pop r10
00007986e0dd7452  pop r9
00007986e0dd7454  pop r8
00007986e0dd7456  pop rsi
00007986e0dd7457  pop rdi
00007986e0dd7458  pop rdx
00007986e0dd7459  pop rcx
00007986e0dd745a  pop rax
00007986e0dd745b  add rsp, 0x08
00007986e0dd745f  jmp 0x00007986E0DD5C68
00007986e0dd7464  call 0x00007986E0CE5820
00007986e0dd7469  jmp 0x00007986E0DD5C75
00007986e0dd746e  sub rsp, 0x08
00007986e0dd7472  push rax
00007986e0dd7473  push rcx
00007986e0dd7474  push rdx
00007986e0dd7475  push rdi
00007986e0dd7476  push rsi
00007986e0dd7477  push r8
00007986e0dd7479  push r9
00007986e0dd747b  push r10
00007986e0dd747d  push r11
00007986e0dd747f  sub rsp, 0xF0
00007986e0dd7486  vmovaps [rsp], xmm0
00007986e0dd748b  vmovaps [rsp+0x10], xmm1
00007986e0dd7491  vmovaps [rsp+0x20], xmm2
00007986e0dd7497  vmovaps [rsp+0x30], xmm3
00007986e0dd749d  vmovaps [rsp+0x40], xmm4
00007986e0dd74a3  vmovaps [rsp+0x50], xmm5
00007986e0dd74a9  vmovaps [rsp+0x60], xmm6
00007986e0dd74af  vmovaps [rsp+0x70], xmm7
00007986e0dd74b5  vmovaps [rsp+0x80], xmm8
00007986e0dd74be  vmovaps [rsp+0x90], xmm9
00007986e0dd74c7  vmovaps [rsp+0xA0], xmm10
00007986e0dd74d0  vmovaps [rsp+0xB0], xmm11
00007986e0dd74d9  vmovaps [rsp+0xC0], xmm12
00007986e0dd74e2  vmovaps [rsp+0xD0], xmm13
00007986e0dd74eb  vmovaps [rsp+0xE0], xmm15
00007986e0dd74f4  sub rsp, 0x30
00007986e0dd74f8  movaps [rsp], xmm14
00007986e0dd74fd  movaps [rsp+0x10], xmm4
00007986e0dd7502  movaps [rsp+0x20], xmm3
00007986e0dd7507  lea rdi, [rsp]
00007986e0dd750b  mov esi, 0x00
00007986e0dd7510  mov rax, 0x5652C689F530
00007986e0dd751a  call rax
00007986e0dd751c  movaps xmm14, [rsp]
00007986e0dd7521  add rsp, 0x30
00007986e0dd7525  vmovaps xmm0, [rsp]
00007986e0dd752a  vmovaps xmm1, [rsp+0x10]
00007986e0dd7530  vmovaps xmm2, [rsp+0x20]
00007986e0dd7536  vmovaps xmm3, [rsp+0x30]
00007986e0dd753c  vmovaps xmm4, [rsp+0x40]
00007986e0dd7542  vmovaps xmm5, [rsp+0x50]
00007986e0dd7548  vmovaps xmm6, [rsp+0x60]
00007986e0dd754e  vmovaps xmm7, [rsp+0x70]
00007986e0dd7554  vmovaps xmm8, [rsp+0x80]
00007986e0dd755d  vmovaps xmm9, [rsp+0x90]
00007986e0dd7566  vmovaps xmm10, [rsp+0xA0]
00007986e0dd756f  vmovaps xmm11, [rsp+0xB0]
00007986e0dd7578  vmovaps xmm12, [rsp+0xC0]
00007986e0dd7581  vmovaps xmm13, [rsp+0xD0]
00007986e0dd758a  vmovaps xmm15, [rsp+0xE0]
00007986e0dd7593  add rsp, 0xF0
00007986e0dd759a  pop r11
00007986e0dd759c  pop r10
00007986e0dd759e  pop r9
00007986e0dd75a0  pop r8
00007986e0dd75a2  pop rsi
00007986e0dd75a3  pop rdi
00007986e0dd75a4  pop rdx
00007986e0dd75a5  pop rcx
00007986e0dd75a6  pop rax
00007986e0dd75a7  add rsp, 0x08
00007986e0dd75ab  jmp 0x00007986E0DD5C8F
00007986e0dd75b0  sub rsp, 0x08
00007986e0dd75b4  push rax
00007986e0dd75b5  push rcx
00007986e0dd75b6  push rdx
00007986e0dd75b7  push rdi
00007986e0dd75b8  push rsi
00007986e0dd75b9  push r8
00007986e0dd75bb  push r9
00007986e0dd75bd  push r10
00007986e0dd75bf  push r11
00007986e0dd75c1  sub rsp, 0xF0
00007986e0dd75c8  vmovaps [rsp], xmm0
00007986e0dd75cd  vmovaps [rsp+0x10], xmm1
00007986e0dd75d3  vmovaps [rsp+0x20], xmm2
00007986e0dd75d9  vmovaps [rsp+0x30], xmm3
00007986e0dd75df  vmovaps [rsp+0x40], xmm4
00007986e0dd75e5  vmovaps [rsp+0x50], xmm5
00007986e0dd75eb  vmovaps [rsp+0x60], xmm7
00007986e0dd75f1  vmovaps [rsp+0x70], xmm8
00007986e0dd75f7  vmovaps [rsp+0x80], xmm9
00007986e0dd7600  vmovaps [rsp+0x90], xmm10
00007986e0dd7609  vmovaps [rsp+0xA0], xmm11
00007986e0dd7612  vmovaps [rsp+0xB0], xmm12
00007986e0dd761b  vmovaps [rsp+0xC0], xmm13
00007986e0dd7624  vmovaps [rsp+0xD0], xmm14
00007986e0dd762d  vmovaps [rsp+0xE0], xmm15
00007986e0dd7636  sub rsp, 0x30
00007986e0dd763a  movaps [rsp], xmm6
00007986e0dd763e  movaps [rsp+0x10], xmm9
00007986e0dd7644  movaps [rsp+0x20], xmm7
00007986e0dd7649  lea rdi, [rsp]
00007986e0dd764d  mov esi, 0x00
00007986e0dd7652  mov rax, 0x5652C689F530
00007986e0dd765c  call rax
00007986e0dd765e  movaps xmm6, [rsp]
00007986e0dd7662  add rsp, 0x30
00007986e0dd7666  vmovaps xmm0, [rsp]
00007986e0dd766b  vmovaps xmm1, [rsp+0x10]
00007986e0dd7671  vmovaps xmm2, [rsp+0x20]
00007986e0dd7677  vmovaps xmm3, [rsp+0x30]
00007986e0dd767d  vmovaps xmm4, [rsp+0x40]
00007986e0dd7683  vmovaps xmm5, [rsp+0x50]
00007986e0dd7689  vmovaps xmm7, [rsp+0x60]
00007986e0dd768f  vmovaps xmm8, [rsp+0x70]
00007986e0dd7695  vmovaps xmm9, [rsp+0x80]
00007986e0dd769e  vmovaps xmm10, [rsp+0x90]
00007986e0dd76a7  vmovaps xmm11, [rsp+0xA0]
00007986e0dd76b0  vmovaps xmm12, [rsp+0xB0]
00007986e0dd76b9  vmovaps xmm13, [rsp+0xC0]
00007986e0dd76c2  vmovaps xmm14, [rsp+0xD0]
00007986e0dd76cb  vmovaps xmm15, [rsp+0xE0]
00007986e0dd76d4  add rsp, 0xF0
00007986e0dd76db  pop r11
00007986e0dd76dd  pop r10
00007986e0dd76df  pop r9
00007986e0dd76e1  pop r8
00007986e0dd76e3  pop rsi
00007986e0dd76e4  pop rdi
00007986e0dd76e5  pop rdx
00007986e0dd76e6  pop rcx
00007986e0dd76e7  pop rax
00007986e0dd76e8  add rsp, 0x08
00007986e0dd76ec  jmp 0x00007986E0DD5CA7
00007986e0dd76f1  sub rsp, 0x08
00007986e0dd76f5  push rax
00007986e0dd76f6  push rcx
00007986e0dd76f7  push rdx
00007986e0dd76f8  push rdi
00007986e0dd76f9  push rsi
00007986e0dd76fa  push r8
00007986e0dd76fc  push r9
00007986e0dd76fe  push r10
00007986e0dd7700  push r11
00007986e0dd7702  sub rsp, 0xF0
00007986e0dd7709  vmovaps [rsp], xmm0
00007986e0dd770e  vmovaps [rsp+0x10], xmm1
00007986e0dd7714  vmovaps [rsp+0x20], xmm2
00007986e0dd771a  vmovaps [rsp+0x30], xmm3
00007986e0dd7720  vmovaps [rsp+0x40], xmm4
00007986e0dd7726  vmovaps [rsp+0x50], xmm5
00007986e0dd772c  vmovaps [rsp+0x60], xmm6
00007986e0dd7732  vmovaps [rsp+0x70], xmm8
00007986e0dd7738  vmovaps [rsp+0x80], xmm9
00007986e0dd7741  vmovaps [rsp+0x90], xmm10
00007986e0dd774a  vmovaps [rsp+0xA0], xmm11
00007986e0dd7753  vmovaps [rsp+0xB0], xmm12
00007986e0dd775c  vmovaps [rsp+0xC0], xmm13
00007986e0dd7765  vmovaps [rsp+0xD0], xmm14
00007986e0dd776e  vmovaps [rsp+0xE0], xmm15
00007986e0dd7777  sub rsp, 0x30
00007986e0dd777b  movaps [rsp], xmm7
00007986e0dd777f  movaps [rsp+0x10], xmm4
00007986e0dd7784  movaps [rsp+0x20], xmm9
00007986e0dd778a  lea rdi, [rsp]
00007986e0dd778e  mov esi, 0x00
00007986e0dd7793  mov rax, 0x5652C689F530
00007986e0dd779d  call rax
00007986e0dd779f  movaps xmm7, [rsp]
00007986e0dd77a3  add rsp, 0x30
00007986e0dd77a7  vmovaps xmm0, [rsp]
00007986e0dd77ac  vmovaps xmm1, [rsp+0x10]
00007986e0dd77b2  vmovaps xmm2, [rsp+0x20]
00007986e0dd77b8  vmovaps xmm3, [rsp+0x30]
00007986e0dd77be  vmovaps xmm4, [rsp+0x40]
00007986e0dd77c4  vmovaps xmm5, [rsp+0x50]
00007986e0dd77ca  vmovaps xmm6, [rsp+0x60]
00007986e0dd77d0  vmovaps xmm8, [rsp+0x70]
00007986e0dd77d6  vmovaps xmm9, [rsp+0x80]
00007986e0dd77df  vmovaps xmm10, [rsp+0x90]
00007986e0dd77e8  vmovaps xmm11, [rsp+0xA0]
00007986e0dd77f1  vmovaps xmm12, [rsp+0xB0]
00007986e0dd77fa  vmovaps xmm13, [rsp+0xC0]
00007986e0dd7803  vmovaps xmm14, [rsp+0xD0]
00007986e0dd780c  vmovaps xmm15, [rsp+0xE0]
00007986e0dd7815  add rsp, 0xF0
00007986e0dd781c  pop r11
00007986e0dd781e  pop r10
00007986e0dd7820  pop r9
00007986e0dd7822  pop r8
00007986e0dd7824  pop rsi
00007986e0dd7825  pop rdi
00007986e0dd7826  pop rdx
00007986e0dd7827  pop rcx
00007986e0dd7828  pop rax
00007986e0dd7829  add rsp, 0x08
00007986e0dd782d  jmp 0x00007986E0DD5CD4
00007986e0dd7832  sub rsp, 0x08
00007986e0dd7836  push rax
00007986e0dd7837  push rcx
00007986e0dd7838  push rdx
00007986e0dd7839  push rdi
00007986e0dd783a  push rsi
00007986e0dd783b  push r8
00007986e0dd783d  push r9
00007986e0dd783f  push r10
00007986e0dd7841  push r11
00007986e0dd7843  sub rsp, 0xF0
00007986e0dd784a  vmovaps [rsp], xmm0
00007986e0dd784f  vmovaps [rsp+0x10], xmm1
00007986e0dd7855  vmovaps [rsp+0x20], xmm2
00007986e0dd785b  vmovaps [rsp+0x30], xmm3
00007986e0dd7861  vmovaps [rsp+0x40], xmm5
00007986e0dd7867  vmovaps [rsp+0x50], xmm6
00007986e0dd786d  vmovaps [rsp+0x60], xmm7
00007986e0dd7873  vmovaps [rsp+0x70], xmm8
00007986e0dd7879  vmovaps [rsp+0x80], xmm9
00007986e0dd7882  vmovaps [rsp+0x90], xmm10
00007986e0dd788b  vmovaps [rsp+0xA0], xmm11
00007986e0dd7894  vmovaps [rsp+0xB0], xmm12
00007986e0dd789d  vmovaps [rsp+0xC0], xmm13
00007986e0dd78a6  vmovaps [rsp+0xD0], xmm14
00007986e0dd78af  vmovaps [rsp+0xE0], xmm15
00007986e0dd78b8  sub rsp, 0x30
00007986e0dd78bc  movaps [rsp], xmm4
00007986e0dd78c0  movaps [rsp+0x10], xmm15
00007986e0dd78c6  movaps [rsp+0x20], xmm9
00007986e0dd78cc  lea rdi, [rsp]
00007986e0dd78d0  mov esi, 0x00
00007986e0dd78d5  mov rax, 0x5652C689F530
00007986e0dd78df  call rax
00007986e0dd78e1  movaps xmm4, [rsp]
00007986e0dd78e5  add rsp, 0x30
00007986e0dd78e9  vmovaps xmm0, [rsp]
00007986e0dd78ee  vmovaps xmm1, [rsp+0x10]
00007986e0dd78f4  vmovaps xmm2, [rsp+0x20]
00007986e0dd78fa  vmovaps xmm3, [rsp+0x30]
00007986e0dd7900  vmovaps xmm5, [rsp+0x40]
00007986e0dd7906  vmovaps xmm6, [rsp+0x50]
00007986e0dd790c  vmovaps xmm7, [rsp+0x60]
00007986e0dd7912  vmovaps xmm8, [rsp+0x70]
00007986e0dd7918  vmovaps xmm9, [rsp+0x80]
00007986e0dd7921  vmovaps xmm10, [rsp+0x90]
00007986e0dd792a  vmovaps xmm11, [rsp+0xA0]
00007986e0dd7933  vmovaps xmm12, [rsp+0xB0]
00007986e0dd793c  vmovaps xmm13, [rsp+0xC0]
00007986e0dd7945  vmovaps xmm14, [rsp+0xD0]
00007986e0dd794e  vmovaps xmm15, [rsp+0xE0]
00007986e0dd7957  add rsp, 0xF0
00007986e0dd795e  pop r11
00007986e0dd7960  pop r10
00007986e0dd7962  pop r9
00007986e0dd7964  pop r8
00007986e0dd7966  pop rsi
00007986e0dd7967  pop rdi
00007986e0dd7968  pop rdx
00007986e0dd7969  pop rcx
00007986e0dd796a  pop rax
00007986e0dd796b  add rsp, 0x08
00007986e0dd796f  jmp 0x00007986E0DD5CF9
00007986e0dd7974  call 0x00007986E0CE5820
00007986e0dd7979  jmp 0x00007986E0DD5D06
00007986e0dd797e  sub rsp, 0x08
00007986e0dd7982  push rax
00007986e0dd7983  push rcx
00007986e0dd7984  push rdx
00007986e0dd7985  push rdi
00007986e0dd7986  push rsi
00007986e0dd7987  push r8
00007986e0dd7989  push r9
00007986e0dd798b  push r10
00007986e0dd798d  push r11
00007986e0dd798f  sub rsp, 0xF0
00007986e0dd7996  vmovaps [rsp], xmm0
00007986e0dd799b  vmovaps [rsp+0x10], xmm1
00007986e0dd79a1  vmovaps [rsp+0x20], xmm2
00007986e0dd79a7  vmovaps [rsp+0x30], xmm4
00007986e0dd79ad  vmovaps [rsp+0x40], xmm5
00007986e0dd79b3  vmovaps [rsp+0x50], xmm6
00007986e0dd79b9  vmovaps [rsp+0x60], xmm7
00007986e0dd79bf  vmovaps [rsp+0x70], xmm8
00007986e0dd79c5  vmovaps [rsp+0x80], xmm9
00007986e0dd79ce  vmovaps [rsp+0x90], xmm10
00007986e0dd79d7  vmovaps [rsp+0xA0], xmm11
00007986e0dd79e0  vmovaps [rsp+0xB0], xmm12
00007986e0dd79e9  vmovaps [rsp+0xC0], xmm13
00007986e0dd79f2  vmovaps [rsp+0xD0], xmm14
00007986e0dd79fb  vmovaps [rsp+0xE0], xmm15
00007986e0dd7a04  sub rsp, 0x30
00007986e0dd7a08  movaps [rsp], xmm3
00007986e0dd7a0c  movaps [rsp+0x10], xmm1
00007986e0dd7a11  movaps [rsp+0x20], xmm9
00007986e0dd7a17  lea rdi, [rsp]
00007986e0dd7a1b  mov esi, 0x00
00007986e0dd7a20  mov rax, 0x5652C689F530
00007986e0dd7a2a  call rax
00007986e0dd7a2c  movaps xmm3, [rsp]
00007986e0dd7a30  add rsp, 0x30
00007986e0dd7a34  vmovaps xmm0, [rsp]
00007986e0dd7a39  vmovaps xmm1, [rsp+0x10]
00007986e0dd7a3f  vmovaps xmm2, [rsp+0x20]
00007986e0dd7a45  vmovaps xmm4, [rsp+0x30]
00007986e0dd7a4b  vmovaps xmm5, [rsp+0x40]
00007986e0dd7a51  vmovaps xmm6, [rsp+0x50]
00007986e0dd7a57  vmovaps xmm7, [rsp+0x60]
00007986e0dd7a5d  vmovaps xmm8, [rsp+0x70]
00007986e0dd7a63  vmovaps xmm9, [rsp+0x80]
00007986e0dd7a6c  vmovaps xmm10, [rsp+0x90]
00007986e0dd7a75  vmovaps xmm11, [rsp+0xA0]
00007986e0dd7a7e  vmovaps xmm12, [rsp+0xB0]
00007986e0dd7a87  vmovaps xmm13, [rsp+0xC0]
00007986e0dd7a90  vmovaps xmm14, [rsp+0xD0]
00007986e0dd7a99  vmovaps xmm15, [rsp+0xE0]
00007986e0dd7aa2  add rsp, 0xF0
00007986e0dd7aa9  pop r11
00007986e0dd7aab  pop r10
00007986e0dd7aad  pop r9
00007986e0dd7aaf  pop r8
00007986e0dd7ab1  pop rsi
00007986e0dd7ab2  pop rdi
00007986e0dd7ab3  pop rdx
00007986e0dd7ab4  pop rcx
00007986e0dd7ab5  pop rax
00007986e0dd7ab6  add rsp, 0x08
00007986e0dd7aba  jmp 0x00007986E0DD5D43
00007986e0dd7abf  sub rsp, 0x08
00007986e0dd7ac3  push rax
00007986e0dd7ac4  push rcx
00007986e0dd7ac5  push rdx
00007986e0dd7ac6  push rdi
00007986e0dd7ac7  push rsi
00007986e0dd7ac8  push r8
00007986e0dd7aca  push r9
00007986e0dd7acc  push r10
00007986e0dd7ace  push r11
00007986e0dd7ad0  sub rsp, 0xF0
00007986e0dd7ad7  vmovaps [rsp], xmm0
00007986e0dd7adc  vmovaps [rsp+0x10], xmm2
00007986e0dd7ae2  vmovaps [rsp+0x20], xmm3
00007986e0dd7ae8  vmovaps [rsp+0x30], xmm4
00007986e0dd7aee  vmovaps [rsp+0x40], xmm5
00007986e0dd7af4  vmovaps [rsp+0x50], xmm6
00007986e0dd7afa  vmovaps [rsp+0x60], xmm7
00007986e0dd7b00  vmovaps [rsp+0x70], xmm8
00007986e0dd7b06  vmovaps [rsp+0x80], xmm9
00007986e0dd7b0f  vmovaps [rsp+0x90], xmm10
00007986e0dd7b18  vmovaps [rsp+0xA0], xmm11
00007986e0dd7b21  vmovaps [rsp+0xB0], xmm12
00007986e0dd7b2a  vmovaps [rsp+0xC0], xmm13
00007986e0dd7b33  vmovaps [rsp+0xD0], xmm14
00007986e0dd7b3c  vmovaps [rsp+0xE0], xmm15
00007986e0dd7b45  sub rsp, 0x30
00007986e0dd7b49  movaps [rsp], xmm1
00007986e0dd7b4d  movaps [rsp+0x10], xmm15
00007986e0dd7b53  movaps [rsp+0x20], xmm9
00007986e0dd7b59  lea rdi, [rsp]
00007986e0dd7b5d  mov esi, 0x00
00007986e0dd7b62  mov rax, 0x5652C689F530
00007986e0dd7b6c  call rax
00007986e0dd7b6e  movaps xmm1, [rsp]
00007986e0dd7b72  add rsp, 0x30
00007986e0dd7b76  vmovaps xmm0, [rsp]
00007986e0dd7b7b  vmovaps xmm2, [rsp+0x10]
00007986e0dd7b81  vmovaps xmm3, [rsp+0x20]
00007986e0dd7b87  vmovaps xmm4, [rsp+0x30]
00007986e0dd7b8d  vmovaps xmm5, [rsp+0x40]
00007986e0dd7b93  vmovaps xmm6, [rsp+0x50]
00007986e0dd7b99  vmovaps xmm7, [rsp+0x60]
00007986e0dd7b9f  vmovaps xmm8, [rsp+0x70]
00007986e0dd7ba5  vmovaps xmm9, [rsp+0x80]
00007986e0dd7bae  vmovaps xmm10, [rsp+0x90]
00007986e0dd7bb7  vmovaps xmm11, [rsp+0xA0]
00007986e0dd7bc0  vmovaps xmm12, [rsp+0xB0]
00007986e0dd7bc9  vmovaps xmm13, [rsp+0xC0]
00007986e0dd7bd2  vmovaps xmm14, [rsp+0xD0]
00007986e0dd7bdb  vmovaps xmm15, [rsp+0xE0]
00007986e0dd7be4  add rsp, 0xF0
00007986e0dd7beb  pop r11
00007986e0dd7bed  pop r10
00007986e0dd7bef  pop r9
00007986e0dd7bf1  pop r8
00007986e0dd7bf3  pop rsi
00007986e0dd7bf4  pop rdi
00007986e0dd7bf5  pop rdx
00007986e0dd7bf6  pop rcx
00007986e0dd7bf7  pop rax
00007986e0dd7bf8  add rsp, 0x08
00007986e0dd7bfc  jmp 0x00007986E0DD5DCB
00007986e0dd7c01  call 0x00007986E0CE5820
00007986e0dd7c06  jmp 0x00007986E0DD5DD8
00007986e0dd7c0b  sub rsp, 0x08
00007986e0dd7c0f  push rax
00007986e0dd7c10  push rcx
00007986e0dd7c11  push rdx
00007986e0dd7c12  push rdi
00007986e0dd7c13  push rsi
00007986e0dd7c14  push r8
00007986e0dd7c16  push r9
00007986e0dd7c18  push r10
00007986e0dd7c1a  push r11
00007986e0dd7c1c  sub rsp, 0xF0
00007986e0dd7c23  vmovaps [rsp], xmm0
00007986e0dd7c28  vmovaps [rsp+0x10], xmm2
00007986e0dd7c2e  vmovaps [rsp+0x20], xmm3
00007986e0dd7c34  vmovaps [rsp+0x30], xmm4
00007986e0dd7c3a  vmovaps [rsp+0x40], xmm5
00007986e0dd7c40  vmovaps [rsp+0x50], xmm6
00007986e0dd7c46  vmovaps [rsp+0x60], xmm7
00007986e0dd7c4c  vmovaps [rsp+0x70], xmm8
00007986e0dd7c52  vmovaps [rsp+0x80], xmm9
00007986e0dd7c5b  vmovaps [rsp+0x90], xmm10
00007986e0dd7c64  vmovaps [rsp+0xA0], xmm11
00007986e0dd7c6d  vmovaps [rsp+0xB0], xmm12
00007986e0dd7c76  vmovaps [rsp+0xC0], xmm13
00007986e0dd7c7f  vmovaps [rsp+0xD0], xmm14
00007986e0dd7c88  vmovaps [rsp+0xE0], xmm15
00007986e0dd7c91  sub rsp, 0x30
00007986e0dd7c95  movaps [rsp], xmm1
00007986e0dd7c99  movaps [rsp+0x10], xmm5
00007986e0dd7c9e  movaps [rsp+0x20], xmm7
00007986e0dd7ca3  lea rdi, [rsp]
00007986e0dd7ca7  mov esi, 0x00
00007986e0dd7cac  mov rax, 0x5652C689F530
00007986e0dd7cb6  call rax
00007986e0dd7cb8  movaps xmm1, [rsp]
00007986e0dd7cbc  add rsp, 0x30
00007986e0dd7cc0  vmovaps xmm0, [rsp]
00007986e0dd7cc5  vmovaps xmm2, [rsp+0x10]
00007986e0dd7ccb  vmovaps xmm3, [rsp+0x20]
00007986e0dd7cd1  vmovaps xmm4, [rsp+0x30]
00007986e0dd7cd7  vmovaps xmm5, [rsp+0x40]
00007986e0dd7cdd  vmovaps xmm6, [rsp+0x50]
00007986e0dd7ce3  vmovaps xmm7, [rsp+0x60]
00007986e0dd7ce9  vmovaps xmm8, [rsp+0x70]
00007986e0dd7cef  vmovaps xmm9, [rsp+0x80]
00007986e0dd7cf8  vmovaps xmm10, [rsp+0x90]
00007986e0dd7d01  vmovaps xmm11, [rsp+0xA0]
00007986e0dd7d0a  vmovaps xmm12, [rsp+0xB0]
00007986e0dd7d13  vmovaps xmm13, [rsp+0xC0]
00007986e0dd7d1c  vmovaps xmm14, [rsp+0xD0]
00007986e0dd7d25  vmovaps xmm15, [rsp+0xE0]
00007986e0dd7d2e  add rsp, 0xF0
00007986e0dd7d35  pop r11
00007986e0dd7d37  pop r10
00007986e0dd7d39  pop r9
00007986e0dd7d3b  pop r8
00007986e0dd7d3d  pop rsi
00007986e0dd7d3e  pop rdi
00007986e0dd7d3f  pop rdx
00007986e0dd7d40  pop rcx
00007986e0dd7d41  pop rax
00007986e0dd7d42  add rsp, 0x08
00007986e0dd7d46  jmp 0x00007986E0DD5E7D
00007986e0dd7d4b  sub rsp, 0x08
00007986e0dd7d4f  push rax
00007986e0dd7d50  push rcx
00007986e0dd7d51  push rdx
00007986e0dd7d52  push rdi
00007986e0dd7d53  push rsi
00007986e0dd7d54  push r8
00007986e0dd7d56  push r9
00007986e0dd7d58  push r10
00007986e0dd7d5a  push r11
00007986e0dd7d5c  sub rsp, 0xF0
00007986e0dd7d63  vmovaps [rsp], xmm0
00007986e0dd7d68  vmovaps [rsp+0x10], xmm1
00007986e0dd7d6e  vmovaps [rsp+0x20], xmm2
00007986e0dd7d74  vmovaps [rsp+0x30], xmm3
00007986e0dd7d7a  vmovaps [rsp+0x40], xmm4
00007986e0dd7d80  vmovaps [rsp+0x50], xmm5
00007986e0dd7d86  vmovaps [rsp+0x60], xmm6
00007986e0dd7d8c  vmovaps [rsp+0x70], xmm8
00007986e0dd7d92  vmovaps [rsp+0x80], xmm9
00007986e0dd7d9b  vmovaps [rsp+0x90], xmm10
00007986e0dd7da4  vmovaps [rsp+0xA0], xmm11
00007986e0dd7dad  vmovaps [rsp+0xB0], xmm12
00007986e0dd7db6  vmovaps [rsp+0xC0], xmm13
00007986e0dd7dbf  vmovaps [rsp+0xD0], xmm14
00007986e0dd7dc8  vmovaps [rsp+0xE0], xmm15
00007986e0dd7dd1  sub rsp, 0x30
00007986e0dd7dd5  movaps [rsp], xmm7
00007986e0dd7dd9  movaps [rsp+0x10], xmm5
00007986e0dd7dde  movaps [rsp+0x20], xmm15
00007986e0dd7de4  lea rdi, [rsp]
00007986e0dd7de8  mov esi, 0x00
00007986e0dd7ded  mov rax, 0x5652C689F530
00007986e0dd7df7  call rax
00007986e0dd7df9  movaps xmm7, [rsp]
00007986e0dd7dfd  add rsp, 0x30
00007986e0dd7e01  vmovaps xmm0, [rsp]
00007986e0dd7e06  vmovaps xmm1, [rsp+0x10]
00007986e0dd7e0c  vmovaps xmm2, [rsp+0x20]
00007986e0dd7e12  vmovaps xmm3, [rsp+0x30]
00007986e0dd7e18  vmovaps xmm4, [rsp+0x40]
00007986e0dd7e1e  vmovaps xmm5, [rsp+0x50]
00007986e0dd7e24  vmovaps xmm6, [rsp+0x60]
00007986e0dd7e2a  vmovaps xmm8, [rsp+0x70]
00007986e0dd7e30  vmovaps xmm9, [rsp+0x80]
00007986e0dd7e39  vmovaps xmm10, [rsp+0x90]
00007986e0dd7e42  vmovaps xmm11, [rsp+0xA0]
00007986e0dd7e4b  vmovaps xmm12, [rsp+0xB0]
00007986e0dd7e54  vmovaps xmm13, [rsp+0xC0]
00007986e0dd7e5d  vmovaps xmm14, [rsp+0xD0]
00007986e0dd7e66  vmovaps xmm15, [rsp+0xE0]
00007986e0dd7e6f  add rsp, 0xF0
00007986e0dd7e76  pop r11
00007986e0dd7e78  pop r10
00007986e0dd7e7a  pop r9
00007986e0dd7e7c  pop r8
00007986e0dd7e7e  pop rsi
00007986e0dd7e7f  pop rdi
00007986e0dd7e80  pop rdx
00007986e0dd7e81  pop rcx
00007986e0dd7e82  pop rax
00007986e0dd7e83  add rsp, 0x08
00007986e0dd7e87  jmp 0x00007986E0DD5EB3
00007986e0dd7e8c  call 0x00007986E0CD64F0
00007986e0dd7e91  jmp 0x00007986E0DD5EC0
00007986e0dd7e96  sub rsp, 0x08
00007986e0dd7e9a  push rax
00007986e0dd7e9b  push rcx
00007986e0dd7e9c  push rdx
00007986e0dd7e9d  push rdi
00007986e0dd7e9e  push rsi
00007986e0dd7e9f  push r8
00007986e0dd7ea1  push r9
00007986e0dd7ea3  push r10
00007986e0dd7ea5  push r11
00007986e0dd7ea7  sub rsp, 0xF0
00007986e0dd7eae  vmovaps [rsp], xmm0
00007986e0dd7eb3  vmovaps [rsp+0x10], xmm1
00007986e0dd7eb9  vmovaps [rsp+0x20], xmm2
00007986e0dd7ebf  vmovaps [rsp+0x30], xmm3
00007986e0dd7ec5  vmovaps [rsp+0x40], xmm4
00007986e0dd7ecb  vmovaps [rsp+0x50], xmm5
00007986e0dd7ed1  vmovaps [rsp+0x60], xmm6
00007986e0dd7ed7  vmovaps [rsp+0x70], xmm7
00007986e0dd7edd  vmovaps [rsp+0x80], xmm8
00007986e0dd7ee6  vmovaps [rsp+0x90], xmm9
00007986e0dd7eef  vmovaps [rsp+0xA0], xmm10
00007986e0dd7ef8  vmovaps [rsp+0xB0], xmm11
00007986e0dd7f01  vmovaps [rsp+0xC0], xmm12
00007986e0dd7f0a  vmovaps [rsp+0xD0], xmm13
00007986e0dd7f13  vmovaps [rsp+0xE0], xmm14
00007986e0dd7f1c  sub rsp, 0x30
00007986e0dd7f20  movaps [rsp], xmm15
00007986e0dd7f25  movaps [rsp+0x10], xmm5
00007986e0dd7f2a  movaps [rsp+0x20], xmm3
00007986e0dd7f2f  lea rdi, [rsp]
00007986e0dd7f33  mov esi, 0x00
00007986e0dd7f38  mov rax, 0x5652C689F530
00007986e0dd7f42  call rax
00007986e0dd7f44  movaps xmm15, [rsp]
00007986e0dd7f49  add rsp, 0x30
00007986e0dd7f4d  vmovaps xmm0, [rsp]
00007986e0dd7f52  vmovaps xmm1, [rsp+0x10]
00007986e0dd7f58  vmovaps xmm2, [rsp+0x20]
00007986e0dd7f5e  vmovaps xmm3, [rsp+0x30]
00007986e0dd7f64  vmovaps xmm4, [rsp+0x40]
00007986e0dd7f6a  vmovaps xmm5, [rsp+0x50]
00007986e0dd7f70  vmovaps xmm6, [rsp+0x60]
00007986e0dd7f76  vmovaps xmm7, [rsp+0x70]
00007986e0dd7f7c  vmovaps xmm8, [rsp+0x80]
00007986e0dd7f85  vmovaps xmm9, [rsp+0x90]
00007986e0dd7f8e  vmovaps xmm10, [rsp+0xA0]
00007986e0dd7f97  vmovaps xmm11, [rsp+0xB0]
00007986e0dd7fa0  vmovaps xmm12, [rsp+0xC0]
00007986e0dd7fa9  vmovaps xmm13, [rsp+0xD0]
00007986e0dd7fb2  vmovaps xmm14, [rsp+0xE0]
00007986e0dd7fbb  add rsp, 0xF0
00007986e0dd7fc2  pop r11
00007986e0dd7fc4  pop r10
00007986e0dd7fc6  pop r9
00007986e0dd7fc8  pop r8
00007986e0dd7fca  pop rsi
00007986e0dd7fcb  pop rdi
00007986e0dd7fcc  pop rdx
00007986e0dd7fcd  pop rcx
00007986e0dd7fce  pop rax
00007986e0dd7fcf  add rsp, 0x08
00007986e0dd7fd3  jmp 0x00007986E0DD5EE6
00007986e0dd7fd8  sub rsp, 0x08
00007986e0dd7fdc  push rax
00007986e0dd7fdd  push rcx
00007986e0dd7fde  push rdx
00007986e0dd7fdf  push rdi
00007986e0dd7fe0  push rsi
00007986e0dd7fe1  push r8
00007986e0dd7fe3  push r9
00007986e0dd7fe5  push r10
00007986e0dd7fe7  push r11
00007986e0dd7fe9  sub rsp, 0xF0
00007986e0dd7ff0  vmovaps [rsp], xmm0
00007986e0dd7ff5  vmovaps [rsp+0x10], xmm2
00007986e0dd7ffb  vmovaps [rsp+0x20], xmm3
00007986e0dd8001  vmovaps [rsp+0x30], xmm4
00007986e0dd8007  vmovaps [rsp+0x40], xmm5
00007986e0dd800d  vmovaps [rsp+0x50], xmm6
00007986e0dd8013  vmovaps [rsp+0x60], xmm7
00007986e0dd8019  vmovaps [rsp+0x70], xmm8
00007986e0dd801f  vmovaps [rsp+0x80], xmm9
00007986e0dd8028  vmovaps [rsp+0x90], xmm10
00007986e0dd8031  vmovaps [rsp+0xA0], xmm11
00007986e0dd803a  vmovaps [rsp+0xB0], xmm12
00007986e0dd8043  vmovaps [rsp+0xC0], xmm13
00007986e0dd804c  vmovaps [rsp+0xD0], xmm14
00007986e0dd8055  vmovaps [rsp+0xE0], xmm15
00007986e0dd805e  sub rsp, 0x30
00007986e0dd8062  movaps [rsp], xmm1
00007986e0dd8066  movaps [rsp+0x10], xmm5
00007986e0dd806b  movaps [rsp+0x20], xmm4
00007986e0dd8070  lea rdi, [rsp]
00007986e0dd8074  mov esi, 0x00
00007986e0dd8079  mov rax, 0x5652C689F530
00007986e0dd8083  call rax
00007986e0dd8085  movaps xmm1, [rsp]
00007986e0dd8089  add rsp, 0x30
00007986e0dd808d  vmovaps xmm0, [rsp]
00007986e0dd8092  vmovaps xmm2, [rsp+0x10]
00007986e0dd8098  vmovaps xmm3, [rsp+0x20]
00007986e0dd809e  vmovaps xmm4, [rsp+0x30]
00007986e0dd80a4  vmovaps xmm5, [rsp+0x40]
00007986e0dd80aa  vmovaps xmm6, [rsp+0x50]
00007986e0dd80b0  vmovaps xmm7, [rsp+0x60]
00007986e0dd80b6  vmovaps xmm8, [rsp+0x70]
00007986e0dd80bc  vmovaps xmm9, [rsp+0x80]
00007986e0dd80c5  vmovaps xmm10, [rsp+0x90]
00007986e0dd80ce  vmovaps xmm11, [rsp+0xA0]
00007986e0dd80d7  vmovaps xmm12, [rsp+0xB0]
00007986e0dd80e0  vmovaps xmm13, [rsp+0xC0]
00007986e0dd80e9  vmovaps xmm14, [rsp+0xD0]
00007986e0dd80f2  vmovaps xmm15, [rsp+0xE0]
00007986e0dd80fb  add rsp, 0xF0
00007986e0dd8102  pop r11
00007986e0dd8104  pop r10
00007986e0dd8106  pop r9
00007986e0dd8108  pop r8
00007986e0dd810a  pop rsi
00007986e0dd810b  pop rdi
00007986e0dd810c  pop rdx
00007986e0dd810d  pop rcx
00007986e0dd810e  pop rax
00007986e0dd810f  add rsp, 0x08
00007986e0dd8113  jmp 0x00007986E0DD5F06
00007986e0dd8118  sub rsp, 0x08
00007986e0dd811c  push rax
00007986e0dd811d  push rcx
00007986e0dd811e  push rdx
00007986e0dd811f  push rdi
00007986e0dd8120  push rsi
00007986e0dd8121  push r8
00007986e0dd8123  push r9
00007986e0dd8125  push r10
00007986e0dd8127  push r11
00007986e0dd8129  sub rsp, 0xF0
00007986e0dd8130  vmovaps [rsp], xmm0
00007986e0dd8135  vmovaps [rsp+0x10], xmm1
00007986e0dd813b  vmovaps [rsp+0x20], xmm2
00007986e0dd8141  vmovaps [rsp+0x30], xmm3
00007986e0dd8147  vmovaps [rsp+0x40], xmm5
00007986e0dd814d  vmovaps [rsp+0x50], xmm6
00007986e0dd8153  vmovaps [rsp+0x60], xmm7
00007986e0dd8159  vmovaps [rsp+0x70], xmm8
00007986e0dd815f  vmovaps [rsp+0x80], xmm9
00007986e0dd8168  vmovaps [rsp+0x90], xmm10
00007986e0dd8171  vmovaps [rsp+0xA0], xmm11
00007986e0dd817a  vmovaps [rsp+0xB0], xmm12
00007986e0dd8183  vmovaps [rsp+0xC0], xmm13
00007986e0dd818c  vmovaps [rsp+0xD0], xmm14
00007986e0dd8195  vmovaps [rsp+0xE0], xmm15
00007986e0dd819e  sub rsp, 0x30
00007986e0dd81a2  movaps [rsp], xmm4
00007986e0dd81a6  movaps [rsp+0x10], xmm3
00007986e0dd81ab  movaps [rsp+0x20], xmm5
00007986e0dd81b0  lea rdi, [rsp]
00007986e0dd81b4  mov esi, 0x00
00007986e0dd81b9  mov rax, 0x5652C689F530
00007986e0dd81c3  call rax
00007986e0dd81c5  movaps xmm4, [rsp]
00007986e0dd81c9  add rsp, 0x30
00007986e0dd81cd  vmovaps xmm0, [rsp]
00007986e0dd81d2  vmovaps xmm1, [rsp+0x10]
00007986e0dd81d8  vmovaps xmm2, [rsp+0x20]
00007986e0dd81de  vmovaps xmm3, [rsp+0x30]
00007986e0dd81e4  vmovaps xmm5, [rsp+0x40]
00007986e0dd81ea  vmovaps xmm6, [rsp+0x50]
00007986e0dd81f0  vmovaps xmm7, [rsp+0x60]
00007986e0dd81f6  vmovaps xmm8, [rsp+0x70]
00007986e0dd81fc  vmovaps xmm9, [rsp+0x80]
00007986e0dd8205  vmovaps xmm10, [rsp+0x90]
00007986e0dd820e  vmovaps xmm11, [rsp+0xA0]
00007986e0dd8217  vmovaps xmm12, [rsp+0xB0]
00007986e0dd8220  vmovaps xmm13, [rsp+0xC0]
00007986e0dd8229  vmovaps xmm14, [rsp+0xD0]
00007986e0dd8232  vmovaps xmm15, [rsp+0xE0]
00007986e0dd823b  add rsp, 0xF0
00007986e0dd8242  pop r11
00007986e0dd8244  pop r10
00007986e0dd8246  pop r9
00007986e0dd8248  pop r8
00007986e0dd824a  pop rsi
00007986e0dd824b  pop rdi
00007986e0dd824c  pop rdx
00007986e0dd824d  pop rcx
00007986e0dd824e  pop rax
00007986e0dd824f  add rsp, 0x08
00007986e0dd8253  jmp 0x00007986E0DD5F54
00007986e0dd8258  call 0x00007986E0CD64F0
00007986e0dd825d  jmp 0x00007986E0DD5F61
00007986e0dd8262  sub rsp, 0x08
00007986e0dd8266  push rax
00007986e0dd8267  push rcx
00007986e0dd8268  push rdx
00007986e0dd8269  push rdi
00007986e0dd826a  push rsi
00007986e0dd826b  push r8
00007986e0dd826d  push r9
00007986e0dd826f  push r10
00007986e0dd8271  push r11
00007986e0dd8273  sub rsp, 0xF0
00007986e0dd827a  vmovaps [rsp], xmm0
00007986e0dd827f  vmovaps [rsp+0x10], xmm1
00007986e0dd8285  vmovaps [rsp+0x20], xmm2
00007986e0dd828b  vmovaps [rsp+0x30], xmm3
00007986e0dd8291  vmovaps [rsp+0x40], xmm4
00007986e0dd8297  vmovaps [rsp+0x50], xmm6
00007986e0dd829d  vmovaps [rsp+0x60], xmm7
00007986e0dd82a3  vmovaps [rsp+0x70], xmm8
00007986e0dd82a9  vmovaps [rsp+0x80], xmm9
00007986e0dd82b2  vmovaps [rsp+0x90], xmm10
00007986e0dd82bb  vmovaps [rsp+0xA0], xmm11
00007986e0dd82c4  vmovaps [rsp+0xB0], xmm12
00007986e0dd82cd  vmovaps [rsp+0xC0], xmm13
00007986e0dd82d6  vmovaps [rsp+0xD0], xmm14
00007986e0dd82df  vmovaps [rsp+0xE0], xmm15
00007986e0dd82e8  sub rsp, 0x30
00007986e0dd82ec  movaps [rsp], xmm5
00007986e0dd82f0  movaps [rsp+0x10], xmm6
00007986e0dd82f5  movaps [rsp+0x20], xmm3
00007986e0dd82fa  lea rdi, [rsp]
00007986e0dd82fe  mov esi, 0x00
00007986e0dd8303  mov rax, 0x5652C689F530
00007986e0dd830d  call rax
00007986e0dd830f  movaps xmm5, [rsp]
00007986e0dd8313  add rsp, 0x30
00007986e0dd8317  vmovaps xmm0, [rsp]
00007986e0dd831c  vmovaps xmm1, [rsp+0x10]
00007986e0dd8322  vmovaps xmm2, [rsp+0x20]
00007986e0dd8328  vmovaps xmm3, [rsp+0x30]
00007986e0dd832e  vmovaps xmm4, [rsp+0x40]
00007986e0dd8334  vmovaps xmm6, [rsp+0x50]
00007986e0dd833a  vmovaps xmm7, [rsp+0x60]
00007986e0dd8340  vmovaps xmm8, [rsp+0x70]
00007986e0dd8346  vmovaps xmm9, [rsp+0x80]
00007986e0dd834f  vmovaps xmm10, [rsp+0x90]
00007986e0dd8358  vmovaps xmm11, [rsp+0xA0]
00007986e0dd8361  vmovaps xmm12, [rsp+0xB0]
00007986e0dd836a  vmovaps xmm13, [rsp+0xC0]
00007986e0dd8373  vmovaps xmm14, [rsp+0xD0]
00007986e0dd837c  vmovaps xmm15, [rsp+0xE0]
00007986e0dd8385  add rsp, 0xF0
00007986e0dd838c  pop r11
00007986e0dd838e  pop r10
00007986e0dd8390  pop r9
00007986e0dd8392  pop r8
00007986e0dd8394  pop rsi
00007986e0dd8395  pop rdi
00007986e0dd8396  pop rdx
00007986e0dd8397  pop rcx
00007986e0dd8398  pop rax
00007986e0dd8399  add rsp, 0x08
00007986e0dd839d  jmp 0x00007986E0DD5F87
00007986e0dd83a2  sub rsp, 0x08
00007986e0dd83a6  push rax
00007986e0dd83a7  push rcx
00007986e0dd83a8  push rdx
00007986e0dd83a9  push rdi
00007986e0dd83aa  push rsi
00007986e0dd83ab  push r8
00007986e0dd83ad  push r9
00007986e0dd83af  push r10
00007986e0dd83b1  push r11
00007986e0dd83b3  sub rsp, 0xF0
00007986e0dd83ba  vmovaps [rsp], xmm0
00007986e0dd83bf  vmovaps [rsp+0x10], xmm1
00007986e0dd83c5  vmovaps [rsp+0x20], xmm2
00007986e0dd83cb  vmovaps [rsp+0x30], xmm3
00007986e0dd83d1  vmovaps [rsp+0x40], xmm4
00007986e0dd83d7  vmovaps [rsp+0x50], xmm5
00007986e0dd83dd  vmovaps [rsp+0x60], xmm7
00007986e0dd83e3  vmovaps [rsp+0x70], xmm8
00007986e0dd83e9  vmovaps [rsp+0x80], xmm9
00007986e0dd83f2  vmovaps [rsp+0x90], xmm10
00007986e0dd83fb  vmovaps [rsp+0xA0], xmm11
00007986e0dd8404  vmovaps [rsp+0xB0], xmm12
00007986e0dd840d  vmovaps [rsp+0xC0], xmm13
00007986e0dd8416  vmovaps [rsp+0xD0], xmm14
00007986e0dd841f  vmovaps [rsp+0xE0], xmm15
00007986e0dd8428  sub rsp, 0x30
00007986e0dd842c  movaps [rsp], xmm6
00007986e0dd8430  movaps [rsp+0x10], xmm9
00007986e0dd8436  movaps [rsp+0x20], xmm1
00007986e0dd843b  lea rdi, [rsp]
00007986e0dd843f  mov esi, 0x00
00007986e0dd8444  mov rax, 0x5652C689F530
00007986e0dd844e  call rax
00007986e0dd8450  movaps xmm6, [rsp]
00007986e0dd8454  add rsp, 0x30
00007986e0dd8458  vmovaps xmm0, [rsp]
00007986e0dd845d  vmovaps xmm1, [rsp+0x10]
00007986e0dd8463  vmovaps xmm2, [rsp+0x20]
00007986e0dd8469  vmovaps xmm3, [rsp+0x30]
00007986e0dd846f  vmovaps xmm4, [rsp+0x40]
00007986e0dd8475  vmovaps xmm5, [rsp+0x50]
00007986e0dd847b  vmovaps xmm7, [rsp+0x60]
00007986e0dd8481  vmovaps xmm8, [rsp+0x70]
00007986e0dd8487  vmovaps xmm9, [rsp+0x80]
00007986e0dd8490  vmovaps xmm10, [rsp+0x90]
00007986e0dd8499  vmovaps xmm11, [rsp+0xA0]
00007986e0dd84a2  vmovaps xmm12, [rsp+0xB0]
00007986e0dd84ab  vmovaps xmm13, [rsp+0xC0]
00007986e0dd84b4  vmovaps xmm14, [rsp+0xD0]
00007986e0dd84bd  vmovaps xmm15, [rsp+0xE0]
00007986e0dd84c6  add rsp, 0xF0
00007986e0dd84cd  pop r11
00007986e0dd84cf  pop r10
00007986e0dd84d1  pop r9
00007986e0dd84d3  pop r8
00007986e0dd84d5  pop rsi
00007986e0dd84d6  pop rdi
00007986e0dd84d7  pop rdx
00007986e0dd84d8  pop rcx
00007986e0dd84d9  pop rax
00007986e0dd84da  add rsp, 0x08
00007986e0dd84de  jmp 0x00007986E0DD5FAB
00007986e0dd84e3  sub rsp, 0x08
00007986e0dd84e7  push rax
00007986e0dd84e8  push rcx
00007986e0dd84e9  push rdx
00007986e0dd84ea  push rdi
00007986e0dd84eb  push rsi
00007986e0dd84ec  push r8
00007986e0dd84ee  push r9
00007986e0dd84f0  push r10
00007986e0dd84f2  push r11
00007986e0dd84f4  sub rsp, 0xF0
00007986e0dd84fb  vmovaps [rsp], xmm0
00007986e0dd8500  vmovaps [rsp+0x10], xmm1
00007986e0dd8506  vmovaps [rsp+0x20], xmm2
00007986e0dd850c  vmovaps [rsp+0x30], xmm3
00007986e0dd8512  vmovaps [rsp+0x40], xmm4
00007986e0dd8518  vmovaps [rsp+0x50], xmm5
00007986e0dd851e  vmovaps [rsp+0x60], xmm6
00007986e0dd8524  vmovaps [rsp+0x70], xmm7
00007986e0dd852a  vmovaps [rsp+0x80], xmm8
00007986e0dd8533  vmovaps [rsp+0x90], xmm10
00007986e0dd853c  vmovaps [rsp+0xA0], xmm11
00007986e0dd8545  vmovaps [rsp+0xB0], xmm12
00007986e0dd854e  vmovaps [rsp+0xC0], xmm13
00007986e0dd8557  vmovaps [rsp+0xD0], xmm14
00007986e0dd8560  vmovaps [rsp+0xE0], xmm15
00007986e0dd8569  sub rsp, 0x30
00007986e0dd856d  movaps [rsp], xmm9
00007986e0dd8572  movaps [rsp+0x10], xmm3
00007986e0dd8577  movaps [rsp+0x20], xmm1
00007986e0dd857c  lea rdi, [rsp]
00007986e0dd8580  mov esi, 0x00
00007986e0dd8585  mov rax, 0x5652C689F530
00007986e0dd858f  call rax
00007986e0dd8591  movaps xmm9, [rsp]
00007986e0dd8596  add rsp, 0x30
00007986e0dd859a  vmovaps xmm0, [rsp]
00007986e0dd859f  vmovaps xmm1, [rsp+0x10]
00007986e0dd85a5  vmovaps xmm2, [rsp+0x20]
00007986e0dd85ab  vmovaps xmm3, [rsp+0x30]
00007986e0dd85b1  vmovaps xmm4, [rsp+0x40]
00007986e0dd85b7  vmovaps xmm5, [rsp+0x50]
00007986e0dd85bd  vmovaps xmm6, [rsp+0x60]
00007986e0dd85c3  vmovaps xmm7, [rsp+0x70]
00007986e0dd85c9  vmovaps xmm8, [rsp+0x80]
00007986e0dd85d2  vmovaps xmm10, [rsp+0x90]
00007986e0dd85db  vmovaps xmm11, [rsp+0xA0]
00007986e0dd85e4  vmovaps xmm12, [rsp+0xB0]
00007986e0dd85ed  vmovaps xmm13, [rsp+0xC0]
00007986e0dd85f6  vmovaps xmm14, [rsp+0xD0]
00007986e0dd85ff  vmovaps xmm15, [rsp+0xE0]
00007986e0dd8608  add rsp, 0xF0
00007986e0dd860f  pop r11
00007986e0dd8611  pop r10
00007986e0dd8613  pop r9
00007986e0dd8615  pop r8
00007986e0dd8617  pop rsi
00007986e0dd8618  pop rdi
00007986e0dd8619  pop rdx
00007986e0dd861a  pop rcx
00007986e0dd861b  pop rax
00007986e0dd861c  add rsp, 0x08
00007986e0dd8620  jmp 0x00007986E0DD5FF7
00007986e0dd8625  call 0x00007986E0CD64F0
00007986e0dd862a  jmp 0x00007986E0DD6004
00007986e0dd862f  sub rsp, 0x08
00007986e0dd8633  push rax
00007986e0dd8634  push rcx
00007986e0dd8635  push rdx
00007986e0dd8636  push rdi
00007986e0dd8637  push rsi
00007986e0dd8638  push r8
00007986e0dd863a  push r9
00007986e0dd863c  push r10
00007986e0dd863e  push r11
00007986e0dd8640  sub rsp, 0xF0
00007986e0dd8647  vmovaps [rsp], xmm0
00007986e0dd864c  vmovaps [rsp+0x10], xmm1
00007986e0dd8652  vmovaps [rsp+0x20], xmm2
00007986e0dd8658  vmovaps [rsp+0x30], xmm3
00007986e0dd865e  vmovaps [rsp+0x40], xmm4
00007986e0dd8664  vmovaps [rsp+0x50], xmm5
00007986e0dd866a  vmovaps [rsp+0x60], xmm6
00007986e0dd8670  vmovaps [rsp+0x70], xmm7
00007986e0dd8676  vmovaps [rsp+0x80], xmm8
00007986e0dd867f  vmovaps [rsp+0x90], xmm9
00007986e0dd8688  vmovaps [rsp+0xA0], xmm10
00007986e0dd8691  vmovaps [rsp+0xB0], xmm11
00007986e0dd869a  vmovaps [rsp+0xC0], xmm12
00007986e0dd86a3  vmovaps [rsp+0xD0], xmm13
00007986e0dd86ac  vmovaps [rsp+0xE0], xmm14
00007986e0dd86b5  sub rsp, 0x30
00007986e0dd86b9  movaps [rsp], xmm15
00007986e0dd86be  movaps [rsp+0x10], xmm3
00007986e0dd86c3  movaps [rsp+0x20], xmm7
00007986e0dd86c8  lea rdi, [rsp]
00007986e0dd86cc  mov esi, 0x00
00007986e0dd86d1  mov rax, 0x5652C689F530
00007986e0dd86db  call rax
00007986e0dd86dd  movaps xmm15, [rsp]
00007986e0dd86e2  add rsp, 0x30
00007986e0dd86e6  vmovaps xmm0, [rsp]
00007986e0dd86eb  vmovaps xmm1, [rsp+0x10]
00007986e0dd86f1  vmovaps xmm2, [rsp+0x20]
00007986e0dd86f7  vmovaps xmm3, [rsp+0x30]
00007986e0dd86fd  vmovaps xmm4, [rsp+0x40]
00007986e0dd8703  vmovaps xmm5, [rsp+0x50]
00007986e0dd8709  vmovaps xmm6, [rsp+0x60]
00007986e0dd870f  vmovaps xmm7, [rsp+0x70]
00007986e0dd8715  vmovaps xmm8, [rsp+0x80]
00007986e0dd871e  vmovaps xmm9, [rsp+0x90]
00007986e0dd8727  vmovaps xmm10, [rsp+0xA0]
00007986e0dd8730  vmovaps xmm11, [rsp+0xB0]
00007986e0dd8739  vmovaps xmm12, [rsp+0xC0]
00007986e0dd8742  vmovaps xmm13, [rsp+0xD0]
00007986e0dd874b  vmovaps xmm14, [rsp+0xE0]
00007986e0dd8754  add rsp, 0xF0
00007986e0dd875b  pop r11
00007986e0dd875d  pop r10
00007986e0dd875f  pop r9
00007986e0dd8761  pop r8
00007986e0dd8763  pop rsi
00007986e0dd8764  pop rdi
00007986e0dd8765  pop rdx
00007986e0dd8766  pop rcx
00007986e0dd8767  pop rax
00007986e0dd8768  add rsp, 0x08
00007986e0dd876c  jmp 0x00007986E0DD6030
00007986e0dd8771  sub rsp, 0x08
00007986e0dd8775  push rax
00007986e0dd8776  push rcx
00007986e0dd8777  push rdx
00007986e0dd8778  push rdi
00007986e0dd8779  push rsi
00007986e0dd877a  push r8
00007986e0dd877c  push r9
00007986e0dd877e  push r10
00007986e0dd8780  push r11
00007986e0dd8782  sub rsp, 0xF0
00007986e0dd8789  vmovaps [rsp], xmm0
00007986e0dd878e  vmovaps [rsp+0x10], xmm1
00007986e0dd8794  vmovaps [rsp+0x20], xmm2
00007986e0dd879a  vmovaps [rsp+0x30], xmm4
00007986e0dd87a0  vmovaps [rsp+0x40], xmm5
00007986e0dd87a6  vmovaps [rsp+0x50], xmm6
00007986e0dd87ac  vmovaps [rsp+0x60], xmm7
00007986e0dd87b2  vmovaps [rsp+0x70], xmm8
00007986e0dd87b8  vmovaps [rsp+0x80], xmm9
00007986e0dd87c1  vmovaps [rsp+0x90], xmm10
00007986e0dd87ca  vmovaps [rsp+0xA0], xmm11
00007986e0dd87d3  vmovaps [rsp+0xB0], xmm12
00007986e0dd87dc  vmovaps [rsp+0xC0], xmm13
00007986e0dd87e5  vmovaps [rsp+0xD0], xmm14
00007986e0dd87ee  vmovaps [rsp+0xE0], xmm15
00007986e0dd87f7  sub rsp, 0x30
00007986e0dd87fb  movaps [rsp], xmm3
00007986e0dd87ff  movaps [rsp+0x10], xmm1
00007986e0dd8804  movaps [rsp+0x20], xmm15
00007986e0dd880a  lea rdi, [rsp]
00007986e0dd880e  mov esi, 0x00
00007986e0dd8813  mov rax, 0x5652C689F530
00007986e0dd881d  call rax
00007986e0dd881f  movaps xmm3, [rsp]
00007986e0dd8823  add rsp, 0x30
00007986e0dd8827  vmovaps xmm0, [rsp]
00007986e0dd882c  vmovaps xmm1, [rsp+0x10]
00007986e0dd8832  vmovaps xmm2, [rsp+0x20]
00007986e0dd8838  vmovaps xmm4, [rsp+0x30]
00007986e0dd883e  vmovaps xmm5, [rsp+0x40]
00007986e0dd8844  vmovaps xmm6, [rsp+0x50]
00007986e0dd884a  vmovaps xmm7, [rsp+0x60]
00007986e0dd8850  vmovaps xmm8, [rsp+0x70]
00007986e0dd8856  vmovaps xmm9, [rsp+0x80]
00007986e0dd885f  vmovaps xmm10, [rsp+0x90]
00007986e0dd8868  vmovaps xmm11, [rsp+0xA0]
00007986e0dd8871  vmovaps xmm12, [rsp+0xB0]
00007986e0dd887a  vmovaps xmm13, [rsp+0xC0]
00007986e0dd8883  vmovaps xmm14, [rsp+0xD0]
00007986e0dd888c  vmovaps xmm15, [rsp+0xE0]
00007986e0dd8895  add rsp, 0xF0
00007986e0dd889c  pop r11
00007986e0dd889e  pop r10
00007986e0dd88a0  pop r9
00007986e0dd88a2  pop r8
00007986e0dd88a4  pop rsi
00007986e0dd88a5  pop rdi
00007986e0dd88a6  pop rdx
00007986e0dd88a7  pop rcx
00007986e0dd88a8  pop rax
00007986e0dd88a9  add rsp, 0x08
00007986e0dd88ad  jmp 0x00007986E0DD60BF
00007986e0dd88b2  call 0x00007986E0CD64F0
00007986e0dd88b7  jmp 0x00007986E0DD60C9
00007986e0dd88bc  sub rsp, 0x08
00007986e0dd88c0  push rax
00007986e0dd88c1  push rcx
00007986e0dd88c2  push rdx
00007986e0dd88c3  push rdi
00007986e0dd88c4  push rsi
00007986e0dd88c5  push r8
00007986e0dd88c7  push r9
00007986e0dd88c9  push r10
00007986e0dd88cb  push r11
00007986e0dd88cd  sub rsp, 0xF0
00007986e0dd88d4  vmovaps [rsp], xmm0
00007986e0dd88d9  vmovaps [rsp+0x10], xmm1
00007986e0dd88df  vmovaps [rsp+0x20], xmm2
00007986e0dd88e5  vmovaps [rsp+0x30], xmm3
00007986e0dd88eb  vmovaps [rsp+0x40], xmm4
00007986e0dd88f1  vmovaps [rsp+0x50], xmm5
00007986e0dd88f7  vmovaps [rsp+0x60], xmm6
00007986e0dd88fd  vmovaps [rsp+0x70], xmm7
00007986e0dd8903  vmovaps [rsp+0x80], xmm8
00007986e0dd890c  vmovaps [rsp+0x90], xmm9
00007986e0dd8915  vmovaps [rsp+0xA0], xmm10
00007986e0dd891e  vmovaps [rsp+0xB0], xmm11
00007986e0dd8927  vmovaps [rsp+0xC0], xmm12
00007986e0dd8930  vmovaps [rsp+0xD0], xmm13
00007986e0dd8939  vmovaps [rsp+0xE0], xmm14
00007986e0dd8942  sub rsp, 0x30
00007986e0dd8946  movaps [rsp], xmm15
00007986e0dd894b  movaps [rsp+0x10], xmm14
00007986e0dd8951  movaps [rsp+0x20], xmm4
00007986e0dd8956  lea rdi, [rsp]
00007986e0dd895a  mov esi, 0x00
00007986e0dd895f  mov rax, 0x5652C689F530
00007986e0dd8969  call rax
00007986e0dd896b  movaps xmm15, [rsp]
00007986e0dd8970  add rsp, 0x30
00007986e0dd8974  vmovaps xmm0, [rsp]
00007986e0dd8979  vmovaps xmm1, [rsp+0x10]
00007986e0dd897f  vmovaps xmm2, [rsp+0x20]
00007986e0dd8985  vmovaps xmm3, [rsp+0x30]
00007986e0dd898b  vmovaps xmm4, [rsp+0x40]
00007986e0dd8991  vmovaps xmm5, [rsp+0x50]
00007986e0dd8997  vmovaps xmm6, [rsp+0x60]
00007986e0dd899d  vmovaps xmm7, [rsp+0x70]
00007986e0dd89a3  vmovaps xmm8, [rsp+0x80]
00007986e0dd89ac  vmovaps xmm9, [rsp+0x90]
00007986e0dd89b5  vmovaps xmm10, [rsp+0xA0]
00007986e0dd89be  vmovaps xmm11, [rsp+0xB0]
00007986e0dd89c7  vmovaps xmm12, [rsp+0xC0]
00007986e0dd89d0  vmovaps xmm13, [rsp+0xD0]
00007986e0dd89d9  vmovaps xmm14, [rsp+0xE0]
00007986e0dd89e2  add rsp, 0xF0
00007986e0dd89e9  pop r11
00007986e0dd89eb  pop r10
00007986e0dd89ed  pop r9
00007986e0dd89ef  pop r8
00007986e0dd89f1  pop rsi
00007986e0dd89f2  pop rdi
00007986e0dd89f3  pop rdx
00007986e0dd89f4  pop rcx
00007986e0dd89f5  pop rax
00007986e0dd89f6  add rsp, 0x08
00007986e0dd89fa  jmp 0x00007986E0DD60F7
00007986e0dd89ff  sub rsp, 0x08
00007986e0dd8a03  push rax
00007986e0dd8a04  push rcx
00007986e0dd8a05  push rdx
00007986e0dd8a06  push rdi
00007986e0dd8a07  push rsi
00007986e0dd8a08  push r8
00007986e0dd8a0a  push r9
00007986e0dd8a0c  push r10
00007986e0dd8a0e  push r11
00007986e0dd8a10  sub rsp, 0xF0
00007986e0dd8a17  vmovaps [rsp], xmm0
00007986e0dd8a1c  vmovaps [rsp+0x10], xmm1
00007986e0dd8a22  vmovaps [rsp+0x20], xmm2
00007986e0dd8a28  vmovaps [rsp+0x30], xmm3
00007986e0dd8a2e  vmovaps [rsp+0x40], xmm4
00007986e0dd8a34  vmovaps [rsp+0x50], xmm5
00007986e0dd8a3a  vmovaps [rsp+0x60], xmm6
00007986e0dd8a40  vmovaps [rsp+0x70], xmm7
00007986e0dd8a46  vmovaps [rsp+0x80], xmm8
00007986e0dd8a4f  vmovaps [rsp+0x90], xmm9
00007986e0dd8a58  vmovaps [rsp+0xA0], xmm10
00007986e0dd8a61  vmovaps [rsp+0xB0], xmm11
00007986e0dd8a6a  vmovaps [rsp+0xC0], xmm12
00007986e0dd8a73  vmovaps [rsp+0xD0], xmm13
00007986e0dd8a7c  vmovaps [rsp+0xE0], xmm15
00007986e0dd8a85  sub rsp, 0x30
00007986e0dd8a89  movaps [rsp], xmm14
00007986e0dd8a8e  movaps [rsp+0x10], xmm2
00007986e0dd8a93  movaps [rsp+0x20], xmm1
00007986e0dd8a98  lea rdi, [rsp]
00007986e0dd8a9c  mov esi, 0x00
00007986e0dd8aa1  mov rax, 0x5652C689F530
00007986e0dd8aab  call rax
00007986e0dd8aad  movaps xmm14, [rsp]
00007986e0dd8ab2  add rsp, 0x30
00007986e0dd8ab6  vmovaps xmm0, [rsp]
00007986e0dd8abb  vmovaps xmm1, [rsp+0x10]
00007986e0dd8ac1  vmovaps xmm2, [rsp+0x20]
00007986e0dd8ac7  vmovaps xmm3, [rsp+0x30]
00007986e0dd8acd  vmovaps xmm4, [rsp+0x40]
00007986e0dd8ad3  vmovaps xmm5, [rsp+0x50]
00007986e0dd8ad9  vmovaps xmm6, [rsp+0x60]
00007986e0dd8adf  vmovaps xmm7, [rsp+0x70]
00007986e0dd8ae5  vmovaps xmm8, [rsp+0x80]
00007986e0dd8aee  vmovaps xmm9, [rsp+0x90]
00007986e0dd8af7  vmovaps xmm10, [rsp+0xA0]
00007986e0dd8b00  vmovaps xmm11, [rsp+0xB0]
00007986e0dd8b09  vmovaps xmm12, [rsp+0xC0]
00007986e0dd8b12  vmovaps xmm13, [rsp+0xD0]
00007986e0dd8b1b  vmovaps xmm15, [rsp+0xE0]
00007986e0dd8b24  add rsp, 0xF0
00007986e0dd8b2b  pop r11
00007986e0dd8b2d  pop r10
00007986e0dd8b2f  pop r9
00007986e0dd8b31  pop r8
00007986e0dd8b33  pop rsi
00007986e0dd8b34  pop rdi
00007986e0dd8b35  pop rdx
00007986e0dd8b36  pop rcx
00007986e0dd8b37  pop rax
00007986e0dd8b38  add rsp, 0x08
00007986e0dd8b3c  jmp 0x00007986E0DD611D
00007986e0dd8b41  sub rsp, 0x08
00007986e0dd8b45  push rax
00007986e0dd8b46  push rcx
00007986e0dd8b47  push rdx
00007986e0dd8b48  push rdi
00007986e0dd8b49  push rsi
00007986e0dd8b4a  push r8
00007986e0dd8b4c  push r9
00007986e0dd8b4e  push r10
00007986e0dd8b50  push r11
00007986e0dd8b52  sub rsp, 0xF0
00007986e0dd8b59  vmovaps [rsp], xmm0
00007986e0dd8b5e  vmovaps [rsp+0x10], xmm2
00007986e0dd8b64  vmovaps [rsp+0x20], xmm3
00007986e0dd8b6a  vmovaps [rsp+0x30], xmm4
00007986e0dd8b70  vmovaps [rsp+0x40], xmm5
00007986e0dd8b76  vmovaps [rsp+0x50], xmm6
00007986e0dd8b7c  vmovaps [rsp+0x60], xmm7
00007986e0dd8b82  vmovaps [rsp+0x70], xmm8
00007986e0dd8b88  vmovaps [rsp+0x80], xmm9
00007986e0dd8b91  vmovaps [rsp+0x90], xmm10
00007986e0dd8b9a  vmovaps [rsp+0xA0], xmm11
00007986e0dd8ba3  vmovaps [rsp+0xB0], xmm12
00007986e0dd8bac  vmovaps [rsp+0xC0], xmm13
00007986e0dd8bb5  vmovaps [rsp+0xD0], xmm14
00007986e0dd8bbe  vmovaps [rsp+0xE0], xmm15
00007986e0dd8bc7  sub rsp, 0x30
00007986e0dd8bcb  movaps [rsp], xmm1
00007986e0dd8bcf  movaps [rsp+0x10], xmm4
00007986e0dd8bd4  movaps [rsp+0x20], xmm9
00007986e0dd8bda  lea rdi, [rsp]
00007986e0dd8bde  mov esi, 0x00
00007986e0dd8be3  mov rax, 0x5652C689F530
00007986e0dd8bed  call rax
00007986e0dd8bef  movaps xmm1, [rsp]
00007986e0dd8bf3  add rsp, 0x30
00007986e0dd8bf7  vmovaps xmm0, [rsp]
00007986e0dd8bfc  vmovaps xmm2, [rsp+0x10]
00007986e0dd8c02  vmovaps xmm3, [rsp+0x20]
00007986e0dd8c08  vmovaps xmm4, [rsp+0x30]
00007986e0dd8c0e  vmovaps xmm5, [rsp+0x40]
00007986e0dd8c14  vmovaps xmm6, [rsp+0x50]
00007986e0dd8c1a  vmovaps xmm7, [rsp+0x60]
00007986e0dd8c20  vmovaps xmm8, [rsp+0x70]
00007986e0dd8c26  vmovaps xmm9, [rsp+0x80]
00007986e0dd8c2f  vmovaps xmm10, [rsp+0x90]
00007986e0dd8c38  vmovaps xmm11, [rsp+0xA0]
00007986e0dd8c41  vmovaps xmm12, [rsp+0xB0]
00007986e0dd8c4a  vmovaps xmm13, [rsp+0xC0]
00007986e0dd8c53  vmovaps xmm14, [rsp+0xD0]
00007986e0dd8c5c  vmovaps xmm15, [rsp+0xE0]
00007986e0dd8c65  add rsp, 0xF0
00007986e0dd8c6c  pop r11
00007986e0dd8c6e  pop r10
00007986e0dd8c70  pop r9
00007986e0dd8c72  pop r8
00007986e0dd8c74  pop rsi
00007986e0dd8c75  pop rdi
00007986e0dd8c76  pop rdx
00007986e0dd8c77  pop rcx
00007986e0dd8c78  pop rax
00007986e0dd8c79  add rsp, 0x08
00007986e0dd8c7d  jmp 0x00007986E0DD613B
00007986e0dd8c82  sub rsp, 0x08
00007986e0dd8c86  push rax
00007986e0dd8c87  push rcx
00007986e0dd8c88  push rdx
00007986e0dd8c89  push rdi
00007986e0dd8c8a  push rsi
00007986e0dd8c8b  push r8
00007986e0dd8c8d  push r9
00007986e0dd8c8f  push r10
00007986e0dd8c91  push r11
00007986e0dd8c93  sub rsp, 0xF0
00007986e0dd8c9a  vmovaps [rsp], xmm0
00007986e0dd8c9f  vmovaps [rsp+0x10], xmm1
00007986e0dd8ca5  vmovaps [rsp+0x20], xmm2
00007986e0dd8cab  vmovaps [rsp+0x30], xmm3
00007986e0dd8cb1  vmovaps [rsp+0x40], xmm5
00007986e0dd8cb7  vmovaps [rsp+0x50], xmm6
00007986e0dd8cbd  vmovaps [rsp+0x60], xmm7
00007986e0dd8cc3  vmovaps [rsp+0x70], xmm8
00007986e0dd8cc9  vmovaps [rsp+0x80], xmm9
00007986e0dd8cd2  vmovaps [rsp+0x90], xmm10
00007986e0dd8cdb  vmovaps [rsp+0xA0], xmm11
00007986e0dd8ce4  vmovaps [rsp+0xB0], xmm12
00007986e0dd8ced  vmovaps [rsp+0xC0], xmm13
00007986e0dd8cf6  vmovaps [rsp+0xD0], xmm14
00007986e0dd8cff  vmovaps [rsp+0xE0], xmm15
00007986e0dd8d08  sub rsp, 0x30
00007986e0dd8d0c  movaps [rsp], xmm4
00007986e0dd8d10  movaps [rsp+0x10], xmm2
00007986e0dd8d15  movaps [rsp+0x20], xmm9
00007986e0dd8d1b  lea rdi, [rsp]
00007986e0dd8d1f  mov esi, 0x00
00007986e0dd8d24  mov rax, 0x5652C689F530
00007986e0dd8d2e  call rax
00007986e0dd8d30  movaps xmm4, [rsp]
00007986e0dd8d34  add rsp, 0x30
00007986e0dd8d38  vmovaps xmm0, [rsp]
00007986e0dd8d3d  vmovaps xmm1, [rsp+0x10]
00007986e0dd8d43  vmovaps xmm2, [rsp+0x20]
00007986e0dd8d49  vmovaps xmm3, [rsp+0x30]
00007986e0dd8d4f  vmovaps xmm5, [rsp+0x40]
00007986e0dd8d55  vmovaps xmm6, [rsp+0x50]
00007986e0dd8d5b  vmovaps xmm7, [rsp+0x60]
00007986e0dd8d61  vmovaps xmm8, [rsp+0x70]
00007986e0dd8d67  vmovaps xmm9, [rsp+0x80]
00007986e0dd8d70  vmovaps xmm10, [rsp+0x90]
00007986e0dd8d79  vmovaps xmm11, [rsp+0xA0]
00007986e0dd8d82  vmovaps xmm12, [rsp+0xB0]
00007986e0dd8d8b  vmovaps xmm13, [rsp+0xC0]
00007986e0dd8d94  vmovaps xmm14, [rsp+0xD0]
00007986e0dd8d9d  vmovaps xmm15, [rsp+0xE0]
00007986e0dd8da6  add rsp, 0xF0
00007986e0dd8dad  pop r11
00007986e0dd8daf  pop r10
00007986e0dd8db1  pop r9
00007986e0dd8db3  pop r8
00007986e0dd8db5  pop rsi
00007986e0dd8db6  pop rdi
00007986e0dd8db7  pop rdx
00007986e0dd8db8  pop rcx
00007986e0dd8db9  pop rax
00007986e0dd8dba  add rsp, 0x08
00007986e0dd8dbe  jmp 0x00007986E0DD616B
00007986e0dd8dc3  sub rsp, 0x08
00007986e0dd8dc7  push rax
00007986e0dd8dc8  push rcx
00007986e0dd8dc9  push rdx
00007986e0dd8dca  push rdi
00007986e0dd8dcb  push rsi
00007986e0dd8dcc  push r8
00007986e0dd8dce  push r9
00007986e0dd8dd0  push r10
00007986e0dd8dd2  push r11
00007986e0dd8dd4  sub rsp, 0xF0
00007986e0dd8ddb  vmovaps [rsp], xmm0
00007986e0dd8de0  vmovaps [rsp+0x10], xmm1
00007986e0dd8de6  vmovaps [rsp+0x20], xmm2
00007986e0dd8dec  vmovaps [rsp+0x30], xmm3
00007986e0dd8df2  vmovaps [rsp+0x40], xmm4
00007986e0dd8df8  vmovaps [rsp+0x50], xmm5
00007986e0dd8dfe  vmovaps [rsp+0x60], xmm6
00007986e0dd8e04  vmovaps [rsp+0x70], xmm7
00007986e0dd8e0a  vmovaps [rsp+0x80], xmm8
00007986e0dd8e13  vmovaps [rsp+0x90], xmm10
00007986e0dd8e1c  vmovaps [rsp+0xA0], xmm11
00007986e0dd8e25  vmovaps [rsp+0xB0], xmm12
00007986e0dd8e2e  vmovaps [rsp+0xC0], xmm13
00007986e0dd8e37  vmovaps [rsp+0xD0], xmm14
00007986e0dd8e40  vmovaps [rsp+0xE0], xmm15
00007986e0dd8e49  sub rsp, 0x30
00007986e0dd8e4d  movaps [rsp], xmm9
00007986e0dd8e52  movaps [rsp+0x10], xmm2
00007986e0dd8e57  movaps [rsp+0x20], xmm1
00007986e0dd8e5c  lea rdi, [rsp]
00007986e0dd8e60  mov esi, 0x00
00007986e0dd8e65  mov rax, 0x5652C689F530
00007986e0dd8e6f  call rax
00007986e0dd8e71  movaps xmm9, [rsp]
00007986e0dd8e76  add rsp, 0x30
00007986e0dd8e7a  vmovaps xmm0, [rsp]
00007986e0dd8e7f  vmovaps xmm1, [rsp+0x10]
00007986e0dd8e85  vmovaps xmm2, [rsp+0x20]
00007986e0dd8e8b  vmovaps xmm3, [rsp+0x30]
00007986e0dd8e91  vmovaps xmm4, [rsp+0x40]
00007986e0dd8e97  vmovaps xmm5, [rsp+0x50]
00007986e0dd8e9d  vmovaps xmm6, [rsp+0x60]
00007986e0dd8ea3  vmovaps xmm7, [rsp+0x70]
00007986e0dd8ea9  vmovaps xmm8, [rsp+0x80]
00007986e0dd8eb2  vmovaps xmm10, [rsp+0x90]
00007986e0dd8ebb  vmovaps xmm11, [rsp+0xA0]
00007986e0dd8ec4  vmovaps xmm12, [rsp+0xB0]
00007986e0dd8ecd  vmovaps xmm13, [rsp+0xC0]
00007986e0dd8ed6  vmovaps xmm14, [rsp+0xD0]
00007986e0dd8edf  vmovaps xmm15, [rsp+0xE0]
00007986e0dd8ee8  add rsp, 0xF0
00007986e0dd8eef  pop r11
00007986e0dd8ef1  pop r10
00007986e0dd8ef3  pop r9
00007986e0dd8ef5  pop r8
00007986e0dd8ef7  pop rsi
00007986e0dd8ef8  pop rdi
00007986e0dd8ef9  pop rdx
00007986e0dd8efa  pop rcx
00007986e0dd8efb  pop rax
00007986e0dd8efc  add rsp, 0x08
00007986e0dd8f00  jmp 0x00007986E0DD61A1
00007986e0dd8f05  sub rsp, 0x08
00007986e0dd8f09  push rax
00007986e0dd8f0a  push rcx
00007986e0dd8f0b  push rdx
00007986e0dd8f0c  push rdi
00007986e0dd8f0d  push rsi
00007986e0dd8f0e  push r8
00007986e0dd8f10  push r9
00007986e0dd8f12  push r10
00007986e0dd8f14  push r11
00007986e0dd8f16  sub rsp, 0xF0
00007986e0dd8f1d  vmovaps [rsp], xmm0
00007986e0dd8f22  vmovaps [rsp+0x10], xmm2
00007986e0dd8f28  vmovaps [rsp+0x20], xmm3
00007986e0dd8f2e  vmovaps [rsp+0x30], xmm4
00007986e0dd8f34  vmovaps [rsp+0x40], xmm5
00007986e0dd8f3a  vmovaps [rsp+0x50], xmm6
00007986e0dd8f40  vmovaps [rsp+0x60], xmm7
00007986e0dd8f46  vmovaps [rsp+0x70], xmm8
00007986e0dd8f4c  vmovaps [rsp+0x80], xmm9
00007986e0dd8f55  vmovaps [rsp+0x90], xmm10
00007986e0dd8f5e  vmovaps [rsp+0xA0], xmm11
00007986e0dd8f67  vmovaps [rsp+0xB0], xmm12
00007986e0dd8f70  vmovaps [rsp+0xC0], xmm13
00007986e0dd8f79  vmovaps [rsp+0xD0], xmm14
00007986e0dd8f82  vmovaps [rsp+0xE0], xmm15
00007986e0dd8f8b  sub rsp, 0x30
00007986e0dd8f8f  movaps [rsp], xmm1
00007986e0dd8f93  movaps [rsp+0x10], xmm15
00007986e0dd8f99  movaps [rsp+0x20], xmm6
00007986e0dd8f9e  lea rdi, [rsp]
00007986e0dd8fa2  mov esi, 0x00
00007986e0dd8fa7  mov rax, 0x5652C689F530
00007986e0dd8fb1  call rax
00007986e0dd8fb3  movaps xmm1, [rsp]
00007986e0dd8fb7  add rsp, 0x30
00007986e0dd8fbb  vmovaps xmm0, [rsp]
00007986e0dd8fc0  vmovaps xmm2, [rsp+0x10]
00007986e0dd8fc6  vmovaps xmm3, [rsp+0x20]
00007986e0dd8fcc  vmovaps xmm4, [rsp+0x30]
00007986e0dd8fd2  vmovaps xmm5, [rsp+0x40]
00007986e0dd8fd8  vmovaps xmm6, [rsp+0x50]
00007986e0dd8fde  vmovaps xmm7, [rsp+0x60]
00007986e0dd8fe4  vmovaps xmm8, [rsp+0x70]
00007986e0dd8fea  vmovaps xmm9, [rsp+0x80]
00007986e0dd8ff3  vmovaps xmm10, [rsp+0x90]
00007986e0dd8ffc  vmovaps xmm11, [rsp+0xA0]
00007986e0dd9005  vmovaps xmm12, [rsp+0xB0]
00007986e0dd900e  vmovaps xmm13, [rsp+0xC0]
00007986e0dd9017  vmovaps xmm14, [rsp+0xD0]
00007986e0dd9020  vmovaps xmm15, [rsp+0xE0]
00007986e0dd9029  add rsp, 0xF0
00007986e0dd9030  pop r11
00007986e0dd9032  pop r10
00007986e0dd9034  pop r9
00007986e0dd9036  pop r8
00007986e0dd9038  pop rsi
00007986e0dd9039  pop rdi
00007986e0dd903a  pop rdx
00007986e0dd903b  pop rcx
00007986e0dd903c  pop rax
00007986e0dd903d  add rsp, 0x08
00007986e0dd9041  jmp 0x00007986E0DD61C2
00007986e0dd9046  sub rsp, 0x08
00007986e0dd904a  push rax
00007986e0dd904b  push rcx
00007986e0dd904c  push rdx
00007986e0dd904d  push rdi
00007986e0dd904e  push rsi
00007986e0dd904f  push r8
00007986e0dd9051  push r9
00007986e0dd9053  push r10
00007986e0dd9055  push r11
00007986e0dd9057  sub rsp, 0xF0
00007986e0dd905e  vmovaps [rsp], xmm0
00007986e0dd9063  vmovaps [rsp+0x10], xmm1
00007986e0dd9069  vmovaps [rsp+0x20], xmm2
00007986e0dd906f  vmovaps [rsp+0x30], xmm3
00007986e0dd9075  vmovaps [rsp+0x40], xmm4
00007986e0dd907b  vmovaps [rsp+0x50], xmm5
00007986e0dd9081  vmovaps [rsp+0x60], xmm6
00007986e0dd9087  vmovaps [rsp+0x70], xmm7
00007986e0dd908d  vmovaps [rsp+0x80], xmm8
00007986e0dd9096  vmovaps [rsp+0x90], xmm9
00007986e0dd909f  vmovaps [rsp+0xA0], xmm10
00007986e0dd90a8  vmovaps [rsp+0xB0], xmm11
00007986e0dd90b1  vmovaps [rsp+0xC0], xmm12
00007986e0dd90ba  vmovaps [rsp+0xD0], xmm13
00007986e0dd90c3  vmovaps [rsp+0xE0], xmm14
00007986e0dd90cc  sub rsp, 0x30
00007986e0dd90d0  movaps [rsp], xmm15
00007986e0dd90d5  movaps [rsp+0x10], xmm5
00007986e0dd90da  movaps [rsp+0x20], xmm3
00007986e0dd90df  lea rdi, [rsp]
00007986e0dd90e3  mov esi, 0x00
00007986e0dd90e8  mov rax, 0x5652C689F530
00007986e0dd90f2  call rax
00007986e0dd90f4  movaps xmm15, [rsp]
00007986e0dd90f9  add rsp, 0x30
00007986e0dd90fd  vmovaps xmm0, [rsp]
00007986e0dd9102  vmovaps xmm1, [rsp+0x10]
00007986e0dd9108  vmovaps xmm2, [rsp+0x20]
00007986e0dd910e  vmovaps xmm3, [rsp+0x30]
00007986e0dd9114  vmovaps xmm4, [rsp+0x40]
00007986e0dd911a  vmovaps xmm5, [rsp+0x50]
00007986e0dd9120  vmovaps xmm6, [rsp+0x60]
00007986e0dd9126  vmovaps xmm7, [rsp+0x70]
00007986e0dd912c  vmovaps xmm8, [rsp+0x80]
00007986e0dd9135  vmovaps xmm9, [rsp+0x90]
00007986e0dd913e  vmovaps xmm10, [rsp+0xA0]
00007986e0dd9147  vmovaps xmm11, [rsp+0xB0]
00007986e0dd9150  vmovaps xmm12, [rsp+0xC0]
00007986e0dd9159  vmovaps xmm13, [rsp+0xD0]
00007986e0dd9162  vmovaps xmm14, [rsp+0xE0]
00007986e0dd916b  add rsp, 0xF0
00007986e0dd9172  pop r11
00007986e0dd9174  pop r10
00007986e0dd9176  pop r9
00007986e0dd9178  pop r8
00007986e0dd917a  pop rsi
00007986e0dd917b  pop rdi
00007986e0dd917c  pop rdx
00007986e0dd917d  pop rcx
00007986e0dd917e  pop rax
00007986e0dd917f  add rsp, 0x08
00007986e0dd9183  jmp 0x00007986E0DD61DC
00007986e0dd9188  sub rsp, 0x08
00007986e0dd918c  push rax
00007986e0dd918d  push rcx
00007986e0dd918e  push rdx
00007986e0dd918f  push rdi
00007986e0dd9190  push rsi
00007986e0dd9191  push r8
00007986e0dd9193  push r9
00007986e0dd9195  push r10
00007986e0dd9197  push r11
00007986e0dd9199  sub rsp, 0xF0
00007986e0dd91a0  vmovaps [rsp], xmm0
00007986e0dd91a5  vmovaps [rsp+0x10], xmm1
00007986e0dd91ab  vmovaps [rsp+0x20], xmm2
00007986e0dd91b1  vmovaps [rsp+0x30], xmm3
00007986e0dd91b7  vmovaps [rsp+0x40], xmm4
00007986e0dd91bd  vmovaps [rsp+0x50], xmm6
00007986e0dd91c3  vmovaps [rsp+0x60], xmm7
00007986e0dd91c9  vmovaps [rsp+0x70], xmm8
00007986e0dd91cf  vmovaps [rsp+0x80], xmm9
00007986e0dd91d8  vmovaps [rsp+0x90], xmm10
00007986e0dd91e1  vmovaps [rsp+0xA0], xmm11
00007986e0dd91ea  vmovaps [rsp+0xB0], xmm12
00007986e0dd91f3  vmovaps [rsp+0xC0], xmm13
00007986e0dd91fc  vmovaps [rsp+0xD0], xmm14
00007986e0dd9205  vmovaps [rsp+0xE0], xmm15
00007986e0dd920e  sub rsp, 0x30
00007986e0dd9212  movaps [rsp], xmm5
00007986e0dd9216  movaps [rsp+0x10], xmm8
00007986e0dd921c  movaps [rsp+0x20], xmm6
00007986e0dd9221  lea rdi, [rsp]
00007986e0dd9225  mov esi, 0x00
00007986e0dd922a  mov rax, 0x5652C689F530
00007986e0dd9234  call rax
00007986e0dd9236  movaps xmm5, [rsp]
00007986e0dd923a  add rsp, 0x30
00007986e0dd923e  vmovaps xmm0, [rsp]
00007986e0dd9243  vmovaps xmm1, [rsp+0x10]
00007986e0dd9249  vmovaps xmm2, [rsp+0x20]
00007986e0dd924f  vmovaps xmm3, [rsp+0x30]
00007986e0dd9255  vmovaps xmm4, [rsp+0x40]
00007986e0dd925b  vmovaps xmm6, [rsp+0x50]
00007986e0dd9261  vmovaps xmm7, [rsp+0x60]
00007986e0dd9267  vmovaps xmm8, [rsp+0x70]
00007986e0dd926d  vmovaps xmm9, [rsp+0x80]
00007986e0dd9276  vmovaps xmm10, [rsp+0x90]
00007986e0dd927f  vmovaps xmm11, [rsp+0xA0]
00007986e0dd9288  vmovaps xmm12, [rsp+0xB0]
00007986e0dd9291  vmovaps xmm13, [rsp+0xC0]
00007986e0dd929a  vmovaps xmm14, [rsp+0xD0]
00007986e0dd92a3  vmovaps xmm15, [rsp+0xE0]
00007986e0dd92ac  add rsp, 0xF0
00007986e0dd92b3  pop r11
00007986e0dd92b5  pop r10
00007986e0dd92b7  pop r9
00007986e0dd92b9  pop r8
00007986e0dd92bb  pop rsi
00007986e0dd92bc  pop rdi
00007986e0dd92bd  pop rdx
00007986e0dd92be  pop rcx
00007986e0dd92bf  pop rax
00007986e0dd92c0  add rsp, 0x08
00007986e0dd92c4  jmp 0x00007986E0DD6200
00007986e0dd92c9  sub rsp, 0x08
00007986e0dd92cd  push rax
00007986e0dd92ce  push rcx
00007986e0dd92cf  push rdx
00007986e0dd92d0  push rdi
00007986e0dd92d1  push rsi
00007986e0dd92d2  push r8
00007986e0dd92d4  push r9
00007986e0dd92d6  push r10
00007986e0dd92d8  push r11
00007986e0dd92da  sub rsp, 0xF0
00007986e0dd92e1  vmovaps [rsp], xmm0
00007986e0dd92e6  vmovaps [rsp+0x10], xmm1
00007986e0dd92ec  vmovaps [rsp+0x20], xmm2
00007986e0dd92f2  vmovaps [rsp+0x30], xmm3
00007986e0dd92f8  vmovaps [rsp+0x40], xmm4
00007986e0dd92fe  vmovaps [rsp+0x50], xmm5
00007986e0dd9304  vmovaps [rsp+0x60], xmm7
00007986e0dd930a  vmovaps [rsp+0x70], xmm8
00007986e0dd9310  vmovaps [rsp+0x80], xmm9
00007986e0dd9319  vmovaps [rsp+0x90], xmm10
00007986e0dd9322  vmovaps [rsp+0xA0], xmm11
00007986e0dd932b  vmovaps [rsp+0xB0], xmm12
00007986e0dd9334  vmovaps [rsp+0xC0], xmm13
00007986e0dd933d  vmovaps [rsp+0xD0], xmm14
00007986e0dd9346  vmovaps [rsp+0xE0], xmm15
00007986e0dd934f  sub rsp, 0x30
00007986e0dd9353  movaps [rsp], xmm6
00007986e0dd9357  movaps [rsp+0x10], xmm10
00007986e0dd935d  movaps [rsp+0x20], xmm8
00007986e0dd9363  lea rdi, [rsp]
00007986e0dd9367  mov esi, 0x00
00007986e0dd936c  mov rax, 0x5652C689F530
00007986e0dd9376  call rax
00007986e0dd9378  movaps xmm6, [rsp]
00007986e0dd937c  add rsp, 0x30
00007986e0dd9380  vmovaps xmm0, [rsp]
00007986e0dd9385  vmovaps xmm1, [rsp+0x10]
00007986e0dd938b  vmovaps xmm2, [rsp+0x20]
00007986e0dd9391  vmovaps xmm3, [rsp+0x30]
00007986e0dd9397  vmovaps xmm4, [rsp+0x40]
00007986e0dd939d  vmovaps xmm5, [rsp+0x50]
00007986e0dd93a3  vmovaps xmm7, [rsp+0x60]
00007986e0dd93a9  vmovaps xmm8, [rsp+0x70]
00007986e0dd93af  vmovaps xmm9, [rsp+0x80]
00007986e0dd93b8  vmovaps xmm10, [rsp+0x90]
00007986e0dd93c1  vmovaps xmm11, [rsp+0xA0]
00007986e0dd93ca  vmovaps xmm12, [rsp+0xB0]
00007986e0dd93d3  vmovaps xmm13, [rsp+0xC0]
00007986e0dd93dc  vmovaps xmm14, [rsp+0xD0]
00007986e0dd93e5  vmovaps xmm15, [rsp+0xE0]
00007986e0dd93ee  add rsp, 0xF0
00007986e0dd93f5  pop r11
00007986e0dd93f7  pop r10
00007986e0dd93f9  pop r9
00007986e0dd93fb  pop r8
00007986e0dd93fd  pop rsi
00007986e0dd93fe  pop rdi
00007986e0dd93ff  pop rdx
00007986e0dd9400  pop rcx
00007986e0dd9401  pop rax
00007986e0dd9402  add rsp, 0x08
00007986e0dd9406  jmp 0x00007986E0DD6225
00007986e0dd940b  sub rsp, 0x08
00007986e0dd940f  push rax
00007986e0dd9410  push rcx
00007986e0dd9411  push rdx
00007986e0dd9412  push rdi
00007986e0dd9413  push rsi
00007986e0dd9414  push r8
00007986e0dd9416  push r9
00007986e0dd9418  push r10
00007986e0dd941a  push r11
00007986e0dd941c  sub rsp, 0xF0
00007986e0dd9423  vmovaps [rsp], xmm0
00007986e0dd9428  vmovaps [rsp+0x10], xmm1
00007986e0dd942e  vmovaps [rsp+0x20], xmm2
00007986e0dd9434  vmovaps [rsp+0x30], xmm3
00007986e0dd943a  vmovaps [rsp+0x40], xmm4
00007986e0dd9440  vmovaps [rsp+0x50], xmm5
00007986e0dd9446  vmovaps [rsp+0x60], xmm6
00007986e0dd944c  vmovaps [rsp+0x70], xmm7
00007986e0dd9452  vmovaps [rsp+0x80], xmm8
00007986e0dd945b  vmovaps [rsp+0x90], xmm9
00007986e0dd9464  vmovaps [rsp+0xA0], xmm11
00007986e0dd946d  vmovaps [rsp+0xB0], xmm12
00007986e0dd9476  vmovaps [rsp+0xC0], xmm13
00007986e0dd947f  vmovaps [rsp+0xD0], xmm14
00007986e0dd9488  vmovaps [rsp+0xE0], xmm15
00007986e0dd9491  sub rsp, 0x30
00007986e0dd9495  movaps [rsp], xmm10
00007986e0dd949a  movaps [rsp+0x10], xmm8
00007986e0dd94a0  movaps [rsp+0x20], xmm14
00007986e0dd94a6  lea rdi, [rsp]
00007986e0dd94aa  mov esi, 0x00
00007986e0dd94af  mov rax, 0x5652C689F530
00007986e0dd94b9  call rax
00007986e0dd94bb  movaps xmm10, [rsp]
00007986e0dd94c0  add rsp, 0x30
00007986e0dd94c4  vmovaps xmm0, [rsp]
00007986e0dd94c9  vmovaps xmm1, [rsp+0x10]
00007986e0dd94cf  vmovaps xmm2, [rsp+0x20]
00007986e0dd94d5  vmovaps xmm3, [rsp+0x30]
00007986e0dd94db  vmovaps xmm4, [rsp+0x40]
00007986e0dd94e1  vmovaps xmm5, [rsp+0x50]
00007986e0dd94e7  vmovaps xmm6, [rsp+0x60]
00007986e0dd94ed  vmovaps xmm7, [rsp+0x70]
00007986e0dd94f3  vmovaps xmm8, [rsp+0x80]
00007986e0dd94fc  vmovaps xmm9, [rsp+0x90]
00007986e0dd9505  vmovaps xmm11, [rsp+0xA0]
00007986e0dd950e  vmovaps xmm12, [rsp+0xB0]
00007986e0dd9517  vmovaps xmm13, [rsp+0xC0]
00007986e0dd9520  vmovaps xmm14, [rsp+0xD0]
00007986e0dd9529  vmovaps xmm15, [rsp+0xE0]
00007986e0dd9532  add rsp, 0xF0
00007986e0dd9539  pop r11
00007986e0dd953b  pop r10
00007986e0dd953d  pop r9
00007986e0dd953f  pop r8
00007986e0dd9541  pop rsi
00007986e0dd9542  pop rdi
00007986e0dd9543  pop rdx
00007986e0dd9544  pop rcx
00007986e0dd9545  pop rax
00007986e0dd9546  add rsp, 0x08
00007986e0dd954a  jmp 0x00007986E0DD6245
00007986e0dd954f  sub rsp, 0x08
00007986e0dd9553  push rax
00007986e0dd9554  push rcx
00007986e0dd9555  push rdx
00007986e0dd9556  push rdi
00007986e0dd9557  push rsi
00007986e0dd9558  push r8
00007986e0dd955a  push r9
00007986e0dd955c  push r10
00007986e0dd955e  push r11
00007986e0dd9560  sub rsp, 0xF0
00007986e0dd9567  vmovaps [rsp], xmm0
00007986e0dd956c  vmovaps [rsp+0x10], xmm1
00007986e0dd9572  vmovaps [rsp+0x20], xmm2
00007986e0dd9578  vmovaps [rsp+0x30], xmm3
00007986e0dd957e  vmovaps [rsp+0x40], xmm4
00007986e0dd9584  vmovaps [rsp+0x50], xmm5
00007986e0dd958a  vmovaps [rsp+0x60], xmm6
00007986e0dd9590  vmovaps [rsp+0x70], xmm7
00007986e0dd9596  vmovaps [rsp+0x80], xmm8
00007986e0dd959f  vmovaps [rsp+0x90], xmm9
00007986e0dd95a8  vmovaps [rsp+0xA0], xmm10
00007986e0dd95b1  vmovaps [rsp+0xB0], xmm11
00007986e0dd95ba  vmovaps [rsp+0xC0], xmm12
00007986e0dd95c3  vmovaps [rsp+0xD0], xmm13
00007986e0dd95cc  vmovaps [rsp+0xE0], xmm15
00007986e0dd95d5  sub rsp, 0x30
00007986e0dd95d9  movaps [rsp], xmm14
00007986e0dd95de  movaps [rsp+0x10], xmm8
00007986e0dd95e4  movaps [rsp+0x20], xmm4
00007986e0dd95e9  lea rdi, [rsp]
00007986e0dd95ed  mov esi, 0x00
00007986e0dd95f2  mov rax, 0x5652C689F530
00007986e0dd95fc  call rax
00007986e0dd95fe  movaps xmm14, [rsp]
00007986e0dd9603  add rsp, 0x30
00007986e0dd9607  vmovaps xmm0, [rsp]
00007986e0dd960c  vmovaps xmm1, [rsp+0x10]
00007986e0dd9612  vmovaps xmm2, [rsp+0x20]
00007986e0dd9618  vmovaps xmm3, [rsp+0x30]
00007986e0dd961e  vmovaps xmm4, [rsp+0x40]
00007986e0dd9624  vmovaps xmm5, [rsp+0x50]
00007986e0dd962a  vmovaps xmm6, [rsp+0x60]
00007986e0dd9630  vmovaps xmm7, [rsp+0x70]
00007986e0dd9636  vmovaps xmm8, [rsp+0x80]
00007986e0dd963f  vmovaps xmm9, [rsp+0x90]
00007986e0dd9648  vmovaps xmm10, [rsp+0xA0]
00007986e0dd9651  vmovaps xmm11, [rsp+0xB0]
00007986e0dd965a  vmovaps xmm12, [rsp+0xC0]
00007986e0dd9663  vmovaps xmm13, [rsp+0xD0]
00007986e0dd966c  vmovaps xmm15, [rsp+0xE0]
00007986e0dd9675  add rsp, 0xF0
00007986e0dd967c  pop r11
00007986e0dd967e  pop r10
00007986e0dd9680  pop r9
00007986e0dd9682  pop r8
00007986e0dd9684  pop rsi
00007986e0dd9685  pop rdi
00007986e0dd9686  pop rdx
00007986e0dd9687  pop rcx
00007986e0dd9688  pop rax
00007986e0dd9689  add rsp, 0x08
00007986e0dd968d  jmp 0x00007986E0DD6265
00007986e0dd9692  sub rsp, 0x08
00007986e0dd9696  push rax
00007986e0dd9697  push rcx
00007986e0dd9698  push rdx
00007986e0dd9699  push rdi
00007986e0dd969a  push rsi
00007986e0dd969b  push r8
00007986e0dd969d  push r9
00007986e0dd969f  push r10
00007986e0dd96a1  push r11
00007986e0dd96a3  sub rsp, 0xF0
00007986e0dd96aa  vmovaps [rsp], xmm0
00007986e0dd96af  vmovaps [rsp+0x10], xmm1
00007986e0dd96b5  vmovaps [rsp+0x20], xmm2
00007986e0dd96bb  vmovaps [rsp+0x30], xmm3
00007986e0dd96c1  vmovaps [rsp+0x40], xmm5
00007986e0dd96c7  vmovaps [rsp+0x50], xmm6
00007986e0dd96cd  vmovaps [rsp+0x60], xmm7
00007986e0dd96d3  vmovaps [rsp+0x70], xmm8
00007986e0dd96d9  vmovaps [rsp+0x80], xmm9
00007986e0dd96e2  vmovaps [rsp+0x90], xmm10
00007986e0dd96eb  vmovaps [rsp+0xA0], xmm11
00007986e0dd96f4  vmovaps [rsp+0xB0], xmm12
00007986e0dd96fd  vmovaps [rsp+0xC0], xmm13
00007986e0dd9706  vmovaps [rsp+0xD0], xmm14
00007986e0dd970f  vmovaps [rsp+0xE0], xmm15
00007986e0dd9718  sub rsp, 0x30
00007986e0dd971c  movaps [rsp], xmm4
00007986e0dd9720  movaps [rsp+0x10], xmm13
00007986e0dd9726  movaps [rsp+0x20], xmm8
00007986e0dd972c  lea rdi, [rsp]
00007986e0dd9730  mov esi, 0x00
00007986e0dd9735  mov rax, 0x5652C689F530
00007986e0dd973f  call rax
00007986e0dd9741  movaps xmm4, [rsp]
00007986e0dd9745  add rsp, 0x30
00007986e0dd9749  vmovaps xmm0, [rsp]
00007986e0dd974e  vmovaps xmm1, [rsp+0x10]
00007986e0dd9754  vmovaps xmm2, [rsp+0x20]
00007986e0dd975a  vmovaps xmm3, [rsp+0x30]
00007986e0dd9760  vmovaps xmm5, [rsp+0x40]
00007986e0dd9766  vmovaps xmm6, [rsp+0x50]
00007986e0dd976c  vmovaps xmm7, [rsp+0x60]
00007986e0dd9772  vmovaps xmm8, [rsp+0x70]
00007986e0dd9778  vmovaps xmm9, [rsp+0x80]
00007986e0dd9781  vmovaps xmm10, [rsp+0x90]
00007986e0dd978a  vmovaps xmm11, [rsp+0xA0]
00007986e0dd9793  vmovaps xmm12, [rsp+0xB0]
00007986e0dd979c  vmovaps xmm13, [rsp+0xC0]
00007986e0dd97a5  vmovaps xmm14, [rsp+0xD0]
00007986e0dd97ae  vmovaps xmm15, [rsp+0xE0]
00007986e0dd97b7  add rsp, 0xF0
00007986e0dd97be  pop r11
00007986e0dd97c0  pop r10
00007986e0dd97c2  pop r9
00007986e0dd97c4  pop r8
00007986e0dd97c6  pop rsi
00007986e0dd97c7  pop rdi
00007986e0dd97c8  pop rdx
00007986e0dd97c9  pop rcx
00007986e0dd97ca  pop rax
00007986e0dd97cb  add rsp, 0x08
00007986e0dd97cf  jmp 0x00007986E0DD628A
00007986e0dd97d4  sub rsp, 0x08
00007986e0dd97d8  push rax
00007986e0dd97d9  push rcx
00007986e0dd97da  push rdx
00007986e0dd97db  push rdi
00007986e0dd97dc  push rsi
00007986e0dd97dd  push r8
00007986e0dd97df  push r9
00007986e0dd97e1  push r10
00007986e0dd97e3  push r11
00007986e0dd97e5  sub rsp, 0xF0
00007986e0dd97ec  vmovaps [rsp], xmm0
00007986e0dd97f1  vmovaps [rsp+0x10], xmm1
00007986e0dd97f7  vmovaps [rsp+0x20], xmm2
00007986e0dd97fd  vmovaps [rsp+0x30], xmm3
00007986e0dd9803  vmovaps [rsp+0x40], xmm4
00007986e0dd9809  vmovaps [rsp+0x50], xmm5
00007986e0dd980f  vmovaps [rsp+0x60], xmm6
00007986e0dd9815  vmovaps [rsp+0x70], xmm7
00007986e0dd981b  vmovaps [rsp+0x80], xmm8
00007986e0dd9824  vmovaps [rsp+0x90], xmm9
00007986e0dd982d  vmovaps [rsp+0xA0], xmm10
00007986e0dd9836  vmovaps [rsp+0xB0], xmm11
00007986e0dd983f  vmovaps [rsp+0xC0], xmm12
00007986e0dd9848  vmovaps [rsp+0xD0], xmm14
00007986e0dd9851  vmovaps [rsp+0xE0], xmm15
00007986e0dd985a  sub rsp, 0x30
00007986e0dd985e  movaps [rsp], xmm13
00007986e0dd9863  movaps [rsp+0x10], xmm15
00007986e0dd9869  movaps [rsp+0x20], xmm9
00007986e0dd986f  lea rdi, [rsp]
00007986e0dd9873  mov esi, 0x00
00007986e0dd9878  mov rax, 0x5652C689F530
00007986e0dd9882  call rax
00007986e0dd9884  movaps xmm13, [rsp]
00007986e0dd9889  add rsp, 0x30
00007986e0dd988d  vmovaps xmm0, [rsp]
00007986e0dd9892  vmovaps xmm1, [rsp+0x10]
00007986e0dd9898  vmovaps xmm2, [rsp+0x20]
00007986e0dd989e  vmovaps xmm3, [rsp+0x30]
00007986e0dd98a4  vmovaps xmm4, [rsp+0x40]
00007986e0dd98aa  vmovaps xmm5, [rsp+0x50]
00007986e0dd98b0  vmovaps xmm6, [rsp+0x60]
00007986e0dd98b6  vmovaps xmm7, [rsp+0x70]
00007986e0dd98bc  vmovaps xmm8, [rsp+0x80]
00007986e0dd98c5  vmovaps xmm9, [rsp+0x90]
00007986e0dd98ce  vmovaps xmm10, [rsp+0xA0]
00007986e0dd98d7  vmovaps xmm11, [rsp+0xB0]
00007986e0dd98e0  vmovaps xmm12, [rsp+0xC0]
00007986e0dd98e9  vmovaps xmm14, [rsp+0xD0]
00007986e0dd98f2  vmovaps xmm15, [rsp+0xE0]
00007986e0dd98fb  add rsp, 0xF0
00007986e0dd9902  pop r11
00007986e0dd9904  pop r10
00007986e0dd9906  pop r9
00007986e0dd9908  pop r8
00007986e0dd990a  pop rsi
00007986e0dd990b  pop rdi
00007986e0dd990c  pop rdx
00007986e0dd990d  pop rcx
00007986e0dd990e  pop rax
00007986e0dd990f  add rsp, 0x08
00007986e0dd9913  jmp 0x00007986E0DD62A5
00007986e0dd9918  sub rsp, 0x08
00007986e0dd991c  push rax
00007986e0dd991d  push rcx
00007986e0dd991e  push rdx
00007986e0dd991f  push rdi
00007986e0dd9920  push rsi
00007986e0dd9921  push r8
00007986e0dd9923  push r9
00007986e0dd9925  push r10
00007986e0dd9927  push r11
00007986e0dd9929  sub rsp, 0xF0
00007986e0dd9930  vmovaps [rsp], xmm0
00007986e0dd9935  vmovaps [rsp+0x10], xmm1
00007986e0dd993b  vmovaps [rsp+0x20], xmm2
00007986e0dd9941  vmovaps [rsp+0x30], xmm3
00007986e0dd9947  vmovaps [rsp+0x40], xmm4
00007986e0dd994d  vmovaps [rsp+0x50], xmm5
00007986e0dd9953  vmovaps [rsp+0x60], xmm6
00007986e0dd9959  vmovaps [rsp+0x70], xmm7
00007986e0dd995f  vmovaps [rsp+0x80], xmm8
00007986e0dd9968  vmovaps [rsp+0x90], xmm9
00007986e0dd9971  vmovaps [rsp+0xA0], xmm10
00007986e0dd997a  vmovaps [rsp+0xB0], xmm11
00007986e0dd9983  vmovaps [rsp+0xC0], xmm12
00007986e0dd998c  vmovaps [rsp+0xD0], xmm13
00007986e0dd9995  vmovaps [rsp+0xE0], xmm14
00007986e0dd999e  sub rsp, 0x30
00007986e0dd99a2  movaps [rsp], xmm15
00007986e0dd99a7  movaps [rsp+0x10], xmm1
00007986e0dd99ac  movaps [rsp+0x20], xmm5
00007986e0dd99b1  lea rdi, [rsp]
00007986e0dd99b5  mov esi, 0x00
00007986e0dd99ba  mov rax, 0x5652C689F530
00007986e0dd99c4  call rax
00007986e0dd99c6  movaps xmm15, [rsp]
00007986e0dd99cb  add rsp, 0x30
00007986e0dd99cf  vmovaps xmm0, [rsp]
00007986e0dd99d4  vmovaps xmm1, [rsp+0x10]
00007986e0dd99da  vmovaps xmm2, [rsp+0x20]
00007986e0dd99e0  vmovaps xmm3, [rsp+0x30]
00007986e0dd99e6  vmovaps xmm4, [rsp+0x40]
00007986e0dd99ec  vmovaps xmm5, [rsp+0x50]
00007986e0dd99f2  vmovaps xmm6, [rsp+0x60]
00007986e0dd99f8  vmovaps xmm7, [rsp+0x70]
00007986e0dd99fe  vmovaps xmm8, [rsp+0x80]
00007986e0dd9a07  vmovaps xmm9, [rsp+0x90]
00007986e0dd9a10  vmovaps xmm10, [rsp+0xA0]
00007986e0dd9a19  vmovaps xmm11, [rsp+0xB0]
00007986e0dd9a22  vmovaps xmm12, [rsp+0xC0]
00007986e0dd9a2b  vmovaps xmm13, [rsp+0xD0]
00007986e0dd9a34  vmovaps xmm14, [rsp+0xE0]
00007986e0dd9a3d  add rsp, 0xF0
00007986e0dd9a44  pop r11
00007986e0dd9a46  pop r10
00007986e0dd9a48  pop r9
00007986e0dd9a4a  pop r8
00007986e0dd9a4c  pop rsi
00007986e0dd9a4d  pop rdi
00007986e0dd9a4e  pop rdx
00007986e0dd9a4f  pop rcx
00007986e0dd9a50  pop rax
00007986e0dd9a51  add rsp, 0x08
00007986e0dd9a55  jmp 0x00007986E0DD62C0
00007986e0dd9a5a  call 0x00007986E0CD64F0
00007986e0dd9a5f  jmp 0x00007986E0DD631B
00007986e0dd9a64  sub rsp, 0x08
00007986e0dd9a68  push rax
00007986e0dd9a69  push rcx
00007986e0dd9a6a  push rdx
00007986e0dd9a6b  push rdi
00007986e0dd9a6c  push rsi
00007986e0dd9a6d  push r8
00007986e0dd9a6f  push r9
00007986e0dd9a71  push r10
00007986e0dd9a73  push r11
00007986e0dd9a75  sub rsp, 0xF0
00007986e0dd9a7c  vmovaps [rsp], xmm0
00007986e0dd9a81  vmovaps [rsp+0x10], xmm1
00007986e0dd9a87  vmovaps [rsp+0x20], xmm2
00007986e0dd9a8d  vmovaps [rsp+0x30], xmm3
00007986e0dd9a93  vmovaps [rsp+0x40], xmm4
00007986e0dd9a99  vmovaps [rsp+0x50], xmm5
00007986e0dd9a9f  vmovaps [rsp+0x60], xmm6
00007986e0dd9aa5  vmovaps [rsp+0x70], xmm7
00007986e0dd9aab  vmovaps [rsp+0x80], xmm8
00007986e0dd9ab4  vmovaps [rsp+0x90], xmm10
00007986e0dd9abd  vmovaps [rsp+0xA0], xmm11
00007986e0dd9ac6  vmovaps [rsp+0xB0], xmm12
00007986e0dd9acf  vmovaps [rsp+0xC0], xmm13
00007986e0dd9ad8  vmovaps [rsp+0xD0], xmm14
00007986e0dd9ae1  vmovaps [rsp+0xE0], xmm15
00007986e0dd9aea  sub rsp, 0x30
00007986e0dd9aee  movaps [rsp], xmm9
00007986e0dd9af3  movaps [rsp+0x10], xmm8
00007986e0dd9af9  movaps [rsp+0x20], xmm11
00007986e0dd9aff  lea rdi, [rsp]
00007986e0dd9b03  mov esi, 0x00
00007986e0dd9b08  mov rax, 0x5652C689F530
00007986e0dd9b12  call rax
00007986e0dd9b14  movaps xmm9, [rsp]
00007986e0dd9b19  add rsp, 0x30
00007986e0dd9b1d  vmovaps xmm0, [rsp]
00007986e0dd9b22  vmovaps xmm1, [rsp+0x10]
00007986e0dd9b28  vmovaps xmm2, [rsp+0x20]
00007986e0dd9b2e  vmovaps xmm3, [rsp+0x30]
00007986e0dd9b34  vmovaps xmm4, [rsp+0x40]
00007986e0dd9b3a  vmovaps xmm5, [rsp+0x50]
00007986e0dd9b40  vmovaps xmm6, [rsp+0x60]
00007986e0dd9b46  vmovaps xmm7, [rsp+0x70]
00007986e0dd9b4c  vmovaps xmm8, [rsp+0x80]
00007986e0dd9b55  vmovaps xmm10, [rsp+0x90]
00007986e0dd9b5e  vmovaps xmm11, [rsp+0xA0]
00007986e0dd9b67  vmovaps xmm12, [rsp+0xB0]
00007986e0dd9b70  vmovaps xmm13, [rsp+0xC0]
00007986e0dd9b79  vmovaps xmm14, [rsp+0xD0]
00007986e0dd9b82  vmovaps xmm15, [rsp+0xE0]
00007986e0dd9b8b  add rsp, 0xF0
00007986e0dd9b92  pop r11
00007986e0dd9b94  pop r10
00007986e0dd9b96  pop r9
00007986e0dd9b98  pop r8
00007986e0dd9b9a  pop rsi
00007986e0dd9b9b  pop rdi
00007986e0dd9b9c  pop rdx
00007986e0dd9b9d  pop rcx
00007986e0dd9b9e  pop rax
00007986e0dd9b9f  add rsp, 0x08
00007986e0dd9ba3  jmp 0x00007986E0DD6352
00007986e0dd9ba8  sub rsp, 0x08
00007986e0dd9bac  push rax
00007986e0dd9bad  push rcx
00007986e0dd9bae  push rdx
00007986e0dd9baf  push rdi
00007986e0dd9bb0  push rsi
00007986e0dd9bb1  push r8
00007986e0dd9bb3  push r9
00007986e0dd9bb5  push r10
00007986e0dd9bb7  push r11
00007986e0dd9bb9  sub rsp, 0xF0
00007986e0dd9bc0  vmovaps [rsp], xmm0
00007986e0dd9bc5  vmovaps [rsp+0x10], xmm1
00007986e0dd9bcb  vmovaps [rsp+0x20], xmm2
00007986e0dd9bd1  vmovaps [rsp+0x30], xmm3
00007986e0dd9bd7  vmovaps [rsp+0x40], xmm4
00007986e0dd9bdd  vmovaps [rsp+0x50], xmm5
00007986e0dd9be3  vmovaps [rsp+0x60], xmm6
00007986e0dd9be9  vmovaps [rsp+0x70], xmm7
00007986e0dd9bef  vmovaps [rsp+0x80], xmm8
00007986e0dd9bf8  vmovaps [rsp+0x90], xmm9
00007986e0dd9c01  vmovaps [rsp+0xA0], xmm10
00007986e0dd9c0a  vmovaps [rsp+0xB0], xmm12
00007986e0dd9c13  vmovaps [rsp+0xC0], xmm13
00007986e0dd9c1c  vmovaps [rsp+0xD0], xmm14
00007986e0dd9c25  vmovaps [rsp+0xE0], xmm15
00007986e0dd9c2e  sub rsp, 0x30
00007986e0dd9c32  movaps [rsp], xmm11
00007986e0dd9c37  movaps [rsp+0x10], xmm10
00007986e0dd9c3d  movaps [rsp+0x20], xmm6
00007986e0dd9c42  lea rdi, [rsp]
00007986e0dd9c46  mov esi, 0x00
00007986e0dd9c4b  mov rax, 0x5652C689F530
00007986e0dd9c55  call rax
00007986e0dd9c57  movaps xmm11, [rsp]
00007986e0dd9c5c  add rsp, 0x30
00007986e0dd9c60  vmovaps xmm0, [rsp]
00007986e0dd9c65  vmovaps xmm1, [rsp+0x10]
00007986e0dd9c6b  vmovaps xmm2, [rsp+0x20]
00007986e0dd9c71  vmovaps xmm3, [rsp+0x30]
00007986e0dd9c77  vmovaps xmm4, [rsp+0x40]
00007986e0dd9c7d  vmovaps xmm5, [rsp+0x50]
00007986e0dd9c83  vmovaps xmm6, [rsp+0x60]
00007986e0dd9c89  vmovaps xmm7, [rsp+0x70]
00007986e0dd9c8f  vmovaps xmm8, [rsp+0x80]
00007986e0dd9c98  vmovaps xmm9, [rsp+0x90]
00007986e0dd9ca1  vmovaps xmm10, [rsp+0xA0]
00007986e0dd9caa  vmovaps xmm12, [rsp+0xB0]
00007986e0dd9cb3  vmovaps xmm13, [rsp+0xC0]
00007986e0dd9cbc  vmovaps xmm14, [rsp+0xD0]
00007986e0dd9cc5  vmovaps xmm15, [rsp+0xE0]
00007986e0dd9cce  add rsp, 0xF0
00007986e0dd9cd5  pop r11
00007986e0dd9cd7  pop r10
00007986e0dd9cd9  pop r9
00007986e0dd9cdb  pop r8
00007986e0dd9cdd  pop rsi
00007986e0dd9cde  pop rdi
00007986e0dd9cdf  pop rdx
00007986e0dd9ce0  pop rcx
00007986e0dd9ce1  pop rax
00007986e0dd9ce2  add rsp, 0x08
00007986e0dd9ce6  jmp 0x00007986E0DD636D
00007986e0dd9ceb  sub rsp, 0x08
00007986e0dd9cef  push rax
00007986e0dd9cf0  push rcx
00007986e0dd9cf1  push rdx
00007986e0dd9cf2  push rdi
00007986e0dd9cf3  push rsi
00007986e0dd9cf4  push r8
00007986e0dd9cf6  push r9
00007986e0dd9cf8  push r10
00007986e0dd9cfa  push r11
00007986e0dd9cfc  sub rsp, 0xF0
00007986e0dd9d03  vmovaps [rsp], xmm0
00007986e0dd9d08  vmovaps [rsp+0x10], xmm1
00007986e0dd9d0e  vmovaps [rsp+0x20], xmm2
00007986e0dd9d14  vmovaps [rsp+0x30], xmm3
00007986e0dd9d1a  vmovaps [rsp+0x40], xmm4
00007986e0dd9d20  vmovaps [rsp+0x50], xmm5
00007986e0dd9d26  vmovaps [rsp+0x60], xmm6
00007986e0dd9d2c  vmovaps [rsp+0x70], xmm7
00007986e0dd9d32  vmovaps [rsp+0x80], xmm8
00007986e0dd9d3b  vmovaps [rsp+0x90], xmm9
00007986e0dd9d44  vmovaps [rsp+0xA0], xmm11
00007986e0dd9d4d  vmovaps [rsp+0xB0], xmm12
00007986e0dd9d56  vmovaps [rsp+0xC0], xmm13
00007986e0dd9d5f  vmovaps [rsp+0xD0], xmm14
00007986e0dd9d68  vmovaps [rsp+0xE0], xmm15
00007986e0dd9d71  sub rsp, 0x30
00007986e0dd9d75  movaps [rsp], xmm10
00007986e0dd9d7a  movaps [rsp+0x10], xmm14
00007986e0dd9d80  movaps [rsp+0x20], xmm4
00007986e0dd9d85  lea rdi, [rsp]
00007986e0dd9d89  mov esi, 0x00
00007986e0dd9d8e  mov rax, 0x5652C689F530
00007986e0dd9d98  call rax
00007986e0dd9d9a  movaps xmm10, [rsp]
00007986e0dd9d9f  add rsp, 0x30
00007986e0dd9da3  vmovaps xmm0, [rsp]
00007986e0dd9da8  vmovaps xmm1, [rsp+0x10]
00007986e0dd9dae  vmovaps xmm2, [rsp+0x20]
00007986e0dd9db4  vmovaps xmm3, [rsp+0x30]
00007986e0dd9dba  vmovaps xmm4, [rsp+0x40]
00007986e0dd9dc0  vmovaps xmm5, [rsp+0x50]
00007986e0dd9dc6  vmovaps xmm6, [rsp+0x60]
00007986e0dd9dcc  vmovaps xmm7, [rsp+0x70]
00007986e0dd9dd2  vmovaps xmm8, [rsp+0x80]
00007986e0dd9ddb  vmovaps xmm9, [rsp+0x90]
00007986e0dd9de4  vmovaps xmm11, [rsp+0xA0]
00007986e0dd9ded  vmovaps xmm12, [rsp+0xB0]
00007986e0dd9df6  vmovaps xmm13, [rsp+0xC0]
00007986e0dd9dff  vmovaps xmm14, [rsp+0xD0]
00007986e0dd9e08  vmovaps xmm15, [rsp+0xE0]
00007986e0dd9e11  add rsp, 0xF0
00007986e0dd9e18  pop r11
00007986e0dd9e1a  pop r10
00007986e0dd9e1c  pop r9
00007986e0dd9e1e  pop r8
00007986e0dd9e20  pop rsi
00007986e0dd9e21  pop rdi
00007986e0dd9e22  pop rdx
00007986e0dd9e23  pop rcx
00007986e0dd9e24  pop rax
00007986e0dd9e25  add rsp, 0x08
00007986e0dd9e29  jmp 0x00007986E0DD6388
00007986e0dd9e2e  sub rsp, 0x08
00007986e0dd9e32  push rax
00007986e0dd9e33  push rcx
00007986e0dd9e34  push rdx
00007986e0dd9e35  push rdi
00007986e0dd9e36  push rsi
00007986e0dd9e37  push r8
00007986e0dd9e39  push r9
00007986e0dd9e3b  push r10
00007986e0dd9e3d  push r11
00007986e0dd9e3f  sub rsp, 0xF0
00007986e0dd9e46  vmovaps [rsp], xmm0
00007986e0dd9e4b  vmovaps [rsp+0x10], xmm1
00007986e0dd9e51  vmovaps [rsp+0x20], xmm2
00007986e0dd9e57  vmovaps [rsp+0x30], xmm3
00007986e0dd9e5d  vmovaps [rsp+0x40], xmm4
00007986e0dd9e63  vmovaps [rsp+0x50], xmm5
00007986e0dd9e69  vmovaps [rsp+0x60], xmm6
00007986e0dd9e6f  vmovaps [rsp+0x70], xmm7
00007986e0dd9e75  vmovaps [rsp+0x80], xmm9
00007986e0dd9e7e  vmovaps [rsp+0x90], xmm10
00007986e0dd9e87  vmovaps [rsp+0xA0], xmm11
00007986e0dd9e90  vmovaps [rsp+0xB0], xmm12
00007986e0dd9e99  vmovaps [rsp+0xC0], xmm13
00007986e0dd9ea2  vmovaps [rsp+0xD0], xmm14
00007986e0dd9eab  vmovaps [rsp+0xE0], xmm15
00007986e0dd9eb4  sub rsp, 0x30
00007986e0dd9eb8  movaps [rsp], xmm8
00007986e0dd9ebd  movaps [rsp+0x10], xmm1
00007986e0dd9ec2  movaps [rsp+0x20], xmm14
00007986e0dd9ec8  lea rdi, [rsp]
00007986e0dd9ecc  mov esi, 0x00
00007986e0dd9ed1  mov rax, 0x5652C689F530
00007986e0dd9edb  call rax
00007986e0dd9edd  movaps xmm8, [rsp]
00007986e0dd9ee2  add rsp, 0x30
00007986e0dd9ee6  vmovaps xmm0, [rsp]
00007986e0dd9eeb  vmovaps xmm1, [rsp+0x10]
00007986e0dd9ef1  vmovaps xmm2, [rsp+0x20]
00007986e0dd9ef7  vmovaps xmm3, [rsp+0x30]
00007986e0dd9efd  vmovaps xmm4, [rsp+0x40]
00007986e0dd9f03  vmovaps xmm5, [rsp+0x50]
00007986e0dd9f09  vmovaps xmm6, [rsp+0x60]
00007986e0dd9f0f  vmovaps xmm7, [rsp+0x70]
00007986e0dd9f15  vmovaps xmm9, [rsp+0x80]
00007986e0dd9f1e  vmovaps xmm10, [rsp+0x90]
00007986e0dd9f27  vmovaps xmm11, [rsp+0xA0]
00007986e0dd9f30  vmovaps xmm12, [rsp+0xB0]
00007986e0dd9f39  vmovaps xmm13, [rsp+0xC0]
00007986e0dd9f42  vmovaps xmm14, [rsp+0xD0]
00007986e0dd9f4b  vmovaps xmm15, [rsp+0xE0]
00007986e0dd9f54  add rsp, 0xF0
00007986e0dd9f5b  pop r11
00007986e0dd9f5d  pop r10
00007986e0dd9f5f  pop r9
00007986e0dd9f61  pop r8
00007986e0dd9f63  pop rsi
00007986e0dd9f64  pop rdi
00007986e0dd9f65  pop rdx
00007986e0dd9f66  pop rcx
00007986e0dd9f67  pop rax
00007986e0dd9f68  add rsp, 0x08
00007986e0dd9f6c  jmp 0x00007986E0DD63AE
00007986e0dd9f71  sub rsp, 0x08
00007986e0dd9f75  push rax
00007986e0dd9f76  push rcx
00007986e0dd9f77  push rdx
00007986e0dd9f78  push rdi
00007986e0dd9f79  push rsi
00007986e0dd9f7a  push r8
00007986e0dd9f7c  push r9
00007986e0dd9f7e  push r10
00007986e0dd9f80  push r11
00007986e0dd9f82  sub rsp, 0xF0
00007986e0dd9f89  vmovaps [rsp], xmm0
00007986e0dd9f8e  vmovaps [rsp+0x10], xmm1
00007986e0dd9f94  vmovaps [rsp+0x20], xmm2
00007986e0dd9f9a  vmovaps [rsp+0x30], xmm3
00007986e0dd9fa0  vmovaps [rsp+0x40], xmm4
00007986e0dd9fa6  vmovaps [rsp+0x50], xmm5
00007986e0dd9fac  vmovaps [rsp+0x60], xmm7
00007986e0dd9fb2  vmovaps [rsp+0x70], xmm8
00007986e0dd9fb8  vmovaps [rsp+0x80], xmm9
00007986e0dd9fc1  vmovaps [rsp+0x90], xmm10
00007986e0dd9fca  vmovaps [rsp+0xA0], xmm11
00007986e0dd9fd3  vmovaps [rsp+0xB0], xmm12
00007986e0dd9fdc  vmovaps [rsp+0xC0], xmm13
00007986e0dd9fe5  vmovaps [rsp+0xD0], xmm14
00007986e0dd9fee  vmovaps [rsp+0xE0], xmm15
00007986e0dd9ff7  sub rsp, 0x30
00007986e0dd9ffb  movaps [rsp], xmm6
00007986e0dd9fff  movaps [rsp+0x10], xmm1
00007986e0dda004  movaps [rsp+0x20], xmm14
00007986e0dda00a  lea rdi, [rsp]
00007986e0dda00e  mov esi, 0x00
00007986e0dda013  mov rax, 0x5652C689F530
00007986e0dda01d  call rax
00007986e0dda01f  movaps xmm6, [rsp]
00007986e0dda023  add rsp, 0x30
00007986e0dda027  vmovaps xmm0, [rsp]
00007986e0dda02c  vmovaps xmm1, [rsp+0x10]
00007986e0dda032  vmovaps xmm2, [rsp+0x20]
00007986e0dda038  vmovaps xmm3, [rsp+0x30]
00007986e0dda03e  vmovaps xmm4, [rsp+0x40]
00007986e0dda044  vmovaps xmm5, [rsp+0x50]
00007986e0dda04a  vmovaps xmm7, [rsp+0x60]
00007986e0dda050  vmovaps xmm8, [rsp+0x70]
00007986e0dda056  vmovaps xmm9, [rsp+0x80]
00007986e0dda05f  vmovaps xmm10, [rsp+0x90]
00007986e0dda068  vmovaps xmm11, [rsp+0xA0]
00007986e0dda071  vmovaps xmm12, [rsp+0xB0]
00007986e0dda07a  vmovaps xmm13, [rsp+0xC0]
00007986e0dda083  vmovaps xmm14, [rsp+0xD0]
00007986e0dda08c  vmovaps xmm15, [rsp+0xE0]
00007986e0dda095  add rsp, 0xF0
00007986e0dda09c  pop r11
00007986e0dda09e  pop r10
00007986e0dda0a0  pop r9
00007986e0dda0a2  pop r8
00007986e0dda0a4  pop rsi
00007986e0dda0a5  pop rdi
00007986e0dda0a6  pop rdx
00007986e0dda0a7  pop rcx
00007986e0dda0a8  pop rax
00007986e0dda0a9  add rsp, 0x08
00007986e0dda0ad  jmp 0x00007986E0DD63DA
00007986e0dda0b2  sub rsp, 0x08
00007986e0dda0b6  push rax
00007986e0dda0b7  push rcx
00007986e0dda0b8  push rdx
00007986e0dda0b9  push rdi
00007986e0dda0ba  push rsi
00007986e0dda0bb  push r8
00007986e0dda0bd  push r9
00007986e0dda0bf  push r10
00007986e0dda0c1  push r11
00007986e0dda0c3  sub rsp, 0xF0
00007986e0dda0ca  vmovaps [rsp], xmm0
00007986e0dda0cf  vmovaps [rsp+0x10], xmm1
00007986e0dda0d5  vmovaps [rsp+0x20], xmm2
00007986e0dda0db  vmovaps [rsp+0x30], xmm3
00007986e0dda0e1  vmovaps [rsp+0x40], xmm4
00007986e0dda0e7  vmovaps [rsp+0x50], xmm5
00007986e0dda0ed  vmovaps [rsp+0x60], xmm6
00007986e0dda0f3  vmovaps [rsp+0x70], xmm7
00007986e0dda0f9  vmovaps [rsp+0x80], xmm8
00007986e0dda102  vmovaps [rsp+0x90], xmm9
00007986e0dda10b  vmovaps [rsp+0xA0], xmm10
00007986e0dda114  vmovaps [rsp+0xB0], xmm11
00007986e0dda11d  vmovaps [rsp+0xC0], xmm12
00007986e0dda126  vmovaps [rsp+0xD0], xmm13
00007986e0dda12f  vmovaps [rsp+0xE0], xmm15
00007986e0dda138  sub rsp, 0x30
00007986e0dda13c  movaps [rsp], xmm14
00007986e0dda141  movaps [rsp+0x10], xmm12
00007986e0dda147  movaps [rsp+0x20], xmm1
00007986e0dda14c  lea rdi, [rsp]
00007986e0dda150  mov esi, 0x00
00007986e0dda155  mov rax, 0x5652C689F530
00007986e0dda15f  call rax
00007986e0dda161  movaps xmm14, [rsp]
00007986e0dda166  add rsp, 0x30
00007986e0dda16a  vmovaps xmm0, [rsp]
00007986e0dda16f  vmovaps xmm1, [rsp+0x10]
00007986e0dda175  vmovaps xmm2, [rsp+0x20]
00007986e0dda17b  vmovaps xmm3, [rsp+0x30]
00007986e0dda181  vmovaps xmm4, [rsp+0x40]
00007986e0dda187  vmovaps xmm5, [rsp+0x50]
00007986e0dda18d  vmovaps xmm6, [rsp+0x60]
00007986e0dda193  vmovaps xmm7, [rsp+0x70]
00007986e0dda199  vmovaps xmm8, [rsp+0x80]
00007986e0dda1a2  vmovaps xmm9, [rsp+0x90]
00007986e0dda1ab  vmovaps xmm10, [rsp+0xA0]
00007986e0dda1b4  vmovaps xmm11, [rsp+0xB0]
00007986e0dda1bd  vmovaps xmm12, [rsp+0xC0]
00007986e0dda1c6  vmovaps xmm13, [rsp+0xD0]
00007986e0dda1cf  vmovaps xmm15, [rsp+0xE0]
00007986e0dda1d8  add rsp, 0xF0
00007986e0dda1df  pop r11
00007986e0dda1e1  pop r10
00007986e0dda1e3  pop r9
00007986e0dda1e5  pop r8
00007986e0dda1e7  pop rsi
00007986e0dda1e8  pop rdi
00007986e0dda1e9  pop rdx
00007986e0dda1ea  pop rcx
00007986e0dda1eb  pop rax
00007986e0dda1ec  add rsp, 0x08
00007986e0dda1f0  jmp 0x00007986E0DD6400
00007986e0dda1f5  sub rsp, 0x08
00007986e0dda1f9  push rax
00007986e0dda1fa  push rcx
00007986e0dda1fb  push rdx
00007986e0dda1fc  push rdi
00007986e0dda1fd  push rsi
00007986e0dda1fe  push r8
00007986e0dda200  push r9
00007986e0dda202  push r10
00007986e0dda204  push r11
00007986e0dda206  sub rsp, 0xF0
00007986e0dda20d  vmovaps [rsp], xmm0
00007986e0dda212  vmovaps [rsp+0x10], xmm2
00007986e0dda218  vmovaps [rsp+0x20], xmm3
00007986e0dda21e  vmovaps [rsp+0x30], xmm4
00007986e0dda224  vmovaps [rsp+0x40], xmm5
00007986e0dda22a  vmovaps [rsp+0x50], xmm6
00007986e0dda230  vmovaps [rsp+0x60], xmm7
00007986e0dda236  vmovaps [rsp+0x70], xmm8
00007986e0dda23c  vmovaps [rsp+0x80], xmm9
00007986e0dda245  vmovaps [rsp+0x90], xmm10
00007986e0dda24e  vmovaps [rsp+0xA0], xmm11
00007986e0dda257  vmovaps [rsp+0xB0], xmm12
00007986e0dda260  vmovaps [rsp+0xC0], xmm13
00007986e0dda269  vmovaps [rsp+0xD0], xmm14
00007986e0dda272  vmovaps [rsp+0xE0], xmm15
00007986e0dda27b  sub rsp, 0x30
00007986e0dda27f  movaps [rsp], xmm1
00007986e0dda283  movaps [rsp+0x10], xmm13
00007986e0dda289  movaps [rsp+0x20], xmm9
00007986e0dda28f  lea rdi, [rsp]
00007986e0dda293  mov esi, 0x00
00007986e0dda298  mov rax, 0x5652C689F530
00007986e0dda2a2  call rax
00007986e0dda2a4  movaps xmm1, [rsp]
00007986e0dda2a8  add rsp, 0x30
00007986e0dda2ac  vmovaps xmm0, [rsp]
00007986e0dda2b1  vmovaps xmm2, [rsp+0x10]
00007986e0dda2b7  vmovaps xmm3, [rsp+0x20]
00007986e0dda2bd  vmovaps xmm4, [rsp+0x30]
00007986e0dda2c3  vmovaps xmm5, [rsp+0x40]
00007986e0dda2c9  vmovaps xmm6, [rsp+0x50]
00007986e0dda2cf  vmovaps xmm7, [rsp+0x60]
00007986e0dda2d5  vmovaps xmm8, [rsp+0x70]
00007986e0dda2db  vmovaps xmm9, [rsp+0x80]
00007986e0dda2e4  vmovaps xmm10, [rsp+0x90]
00007986e0dda2ed  vmovaps xmm11, [rsp+0xA0]
00007986e0dda2f6  vmovaps xmm12, [rsp+0xB0]
00007986e0dda2ff  vmovaps xmm13, [rsp+0xC0]
00007986e0dda308  vmovaps xmm14, [rsp+0xD0]
00007986e0dda311  vmovaps xmm15, [rsp+0xE0]
00007986e0dda31a  add rsp, 0xF0
00007986e0dda321  pop r11
00007986e0dda323  pop r10
00007986e0dda325  pop r9
00007986e0dda327  pop r8
00007986e0dda329  pop rsi
00007986e0dda32a  pop rdi
00007986e0dda32b  pop rdx
00007986e0dda32c  pop rcx
00007986e0dda32d  pop rax
00007986e0dda32e  add rsp, 0x08
00007986e0dda332  jmp 0x00007986E0DD641A
00007986e0dda337  sub rsp, 0x08
00007986e0dda33b  push rax
00007986e0dda33c  push rcx
00007986e0dda33d  push rdx
00007986e0dda33e  push rdi
00007986e0dda33f  push rsi
00007986e0dda340  push r8
00007986e0dda342  push r9
00007986e0dda344  push r10
00007986e0dda346  push r11
00007986e0dda348  sub rsp, 0xF0
00007986e0dda34f  vmovaps [rsp], xmm0
00007986e0dda354  vmovaps [rsp+0x10], xmm1
00007986e0dda35a  vmovaps [rsp+0x20], xmm2
00007986e0dda360  vmovaps [rsp+0x30], xmm3
00007986e0dda366  vmovaps [rsp+0x40], xmm4
00007986e0dda36c  vmovaps [rsp+0x50], xmm5
00007986e0dda372  vmovaps [rsp+0x60], xmm6
00007986e0dda378  vmovaps [rsp+0x70], xmm7
00007986e0dda37e  vmovaps [rsp+0x80], xmm8
00007986e0dda387  vmovaps [rsp+0x90], xmm9
00007986e0dda390  vmovaps [rsp+0xA0], xmm10
00007986e0dda399  vmovaps [rsp+0xB0], xmm11
00007986e0dda3a2  vmovaps [rsp+0xC0], xmm13
00007986e0dda3ab  vmovaps [rsp+0xD0], xmm14
00007986e0dda3b4  vmovaps [rsp+0xE0], xmm15
00007986e0dda3bd  sub rsp, 0x30
00007986e0dda3c1  movaps [rsp], xmm12
00007986e0dda3c6  movaps [rsp+0x10], xmm7
00007986e0dda3cb  movaps [rsp+0x20], xmm13
00007986e0dda3d1  lea rdi, [rsp]
00007986e0dda3d5  mov esi, 0x00
00007986e0dda3da  mov rax, 0x5652C689F530
00007986e0dda3e4  call rax
00007986e0dda3e6  movaps xmm12, [rsp]
00007986e0dda3eb  add rsp, 0x30
00007986e0dda3ef  vmovaps xmm0, [rsp]
00007986e0dda3f4  vmovaps xmm1, [rsp+0x10]
00007986e0dda3fa  vmovaps xmm2, [rsp+0x20]
00007986e0dda400  vmovaps xmm3, [rsp+0x30]
00007986e0dda406  vmovaps xmm4, [rsp+0x40]
00007986e0dda40c  vmovaps xmm5, [rsp+0x50]
00007986e0dda412  vmovaps xmm6, [rsp+0x60]
00007986e0dda418  vmovaps xmm7, [rsp+0x70]
00007986e0dda41e  vmovaps xmm8, [rsp+0x80]
00007986e0dda427  vmovaps xmm9, [rsp+0x90]
00007986e0dda430  vmovaps xmm10, [rsp+0xA0]
00007986e0dda439  vmovaps xmm11, [rsp+0xB0]
00007986e0dda442  vmovaps xmm13, [rsp+0xC0]
00007986e0dda44b  vmovaps xmm14, [rsp+0xD0]
00007986e0dda454  vmovaps xmm15, [rsp+0xE0]
00007986e0dda45d  add rsp, 0xF0
00007986e0dda464  pop r11
00007986e0dda466  pop r10
00007986e0dda468  pop r9
00007986e0dda46a  pop r8
00007986e0dda46c  pop rsi
00007986e0dda46d  pop rdi
00007986e0dda46e  pop rdx
00007986e0dda46f  pop rcx
00007986e0dda470  pop rax
00007986e0dda471  add rsp, 0x08
00007986e0dda475  jmp 0x00007986E0DD6441
00007986e0dda47a  sub rsp, 0x08
00007986e0dda47e  push rax
00007986e0dda47f  push rcx
00007986e0dda480  push rdx
00007986e0dda481  push rdi
00007986e0dda482  push rsi
00007986e0dda483  push r8
00007986e0dda485  push r9
00007986e0dda487  push r10
00007986e0dda489  push r11
00007986e0dda48b  sub rsp, 0xF0
00007986e0dda492  vmovaps [rsp], xmm0
00007986e0dda497  vmovaps [rsp+0x10], xmm1
00007986e0dda49d  vmovaps [rsp+0x20], xmm2
00007986e0dda4a3  vmovaps [rsp+0x30], xmm3
00007986e0dda4a9  vmovaps [rsp+0x40], xmm4
00007986e0dda4af  vmovaps [rsp+0x50], xmm5
00007986e0dda4b5  vmovaps [rsp+0x60], xmm6
00007986e0dda4bb  vmovaps [rsp+0x70], xmm7
00007986e0dda4c1  vmovaps [rsp+0x80], xmm8
00007986e0dda4ca  vmovaps [rsp+0x90], xmm9
00007986e0dda4d3  vmovaps [rsp+0xA0], xmm10
00007986e0dda4dc  vmovaps [rsp+0xB0], xmm11
00007986e0dda4e5  vmovaps [rsp+0xC0], xmm12
00007986e0dda4ee  vmovaps [rsp+0xD0], xmm14
00007986e0dda4f7  vmovaps [rsp+0xE0], xmm15
00007986e0dda500  sub rsp, 0x30
00007986e0dda504  movaps [rsp], xmm13
00007986e0dda509  movaps [rsp+0x10], xmm15
00007986e0dda50f  movaps [rsp+0x20], xmm8
00007986e0dda515  lea rdi, [rsp]
00007986e0dda519  mov esi, 0x00
00007986e0dda51e  mov rax, 0x5652C689F530
00007986e0dda528  call rax
00007986e0dda52a  movaps xmm13, [rsp]
00007986e0dda52f  add rsp, 0x30
00007986e0dda533  vmovaps xmm0, [rsp]
00007986e0dda538  vmovaps xmm1, [rsp+0x10]
00007986e0dda53e  vmovaps xmm2, [rsp+0x20]
00007986e0dda544  vmovaps xmm3, [rsp+0x30]
00007986e0dda54a  vmovaps xmm4, [rsp+0x40]
00007986e0dda550  vmovaps xmm5, [rsp+0x50]
00007986e0dda556  vmovaps xmm6, [rsp+0x60]
00007986e0dda55c  vmovaps xmm7, [rsp+0x70]
00007986e0dda562  vmovaps xmm8, [rsp+0x80]
00007986e0dda56b  vmovaps xmm9, [rsp+0x90]
00007986e0dda574  vmovaps xmm10, [rsp+0xA0]
00007986e0dda57d  vmovaps xmm11, [rsp+0xB0]
00007986e0dda586  vmovaps xmm12, [rsp+0xC0]
00007986e0dda58f  vmovaps xmm14, [rsp+0xD0]
00007986e0dda598  vmovaps xmm15, [rsp+0xE0]
00007986e0dda5a1  add rsp, 0xF0
00007986e0dda5a8  pop r11
00007986e0dda5aa  pop r10
00007986e0dda5ac  pop r9
00007986e0dda5ae  pop r8
00007986e0dda5b0  pop rsi
00007986e0dda5b1  pop rdi
00007986e0dda5b2  pop rdx
00007986e0dda5b3  pop rcx
00007986e0dda5b4  pop rax
00007986e0dda5b5  add rsp, 0x08
00007986e0dda5b9  jmp 0x00007986E0DD645C
00007986e0dda5be  sub rsp, 0x08
00007986e0dda5c2  push rax
00007986e0dda5c3  push rcx
00007986e0dda5c4  push rdx
00007986e0dda5c5  push rdi
00007986e0dda5c6  push rsi
00007986e0dda5c7  push r8
00007986e0dda5c9  push r9
00007986e0dda5cb  push r10
00007986e0dda5cd  push r11
00007986e0dda5cf  sub rsp, 0xF0
00007986e0dda5d6  vmovaps [rsp], xmm0
00007986e0dda5db  vmovaps [rsp+0x10], xmm1
00007986e0dda5e1  vmovaps [rsp+0x20], xmm2
00007986e0dda5e7  vmovaps [rsp+0x30], xmm3
00007986e0dda5ed  vmovaps [rsp+0x40], xmm4
00007986e0dda5f3  vmovaps [rsp+0x50], xmm5
00007986e0dda5f9  vmovaps [rsp+0x60], xmm6
00007986e0dda5ff  vmovaps [rsp+0x70], xmm7
00007986e0dda605  vmovaps [rsp+0x80], xmm9
00007986e0dda60e  vmovaps [rsp+0x90], xmm10
00007986e0dda617  vmovaps [rsp+0xA0], xmm11
00007986e0dda620  vmovaps [rsp+0xB0], xmm12
00007986e0dda629  vmovaps [rsp+0xC0], xmm13
00007986e0dda632  vmovaps [rsp+0xD0], xmm14
00007986e0dda63b  vmovaps [rsp+0xE0], xmm15
00007986e0dda644  sub rsp, 0x30
00007986e0dda648  movaps [rsp], xmm8
00007986e0dda64d  movaps [rsp+0x10], xmm15
00007986e0dda653  movaps [rsp+0x20], xmm9
00007986e0dda659  lea rdi, [rsp]
00007986e0dda65d  mov esi, 0x00
00007986e0dda662  mov rax, 0x5652C689F530
00007986e0dda66c  call rax
00007986e0dda66e  movaps xmm8, [rsp]
00007986e0dda673  add rsp, 0x30
00007986e0dda677  vmovaps xmm0, [rsp]
00007986e0dda67c  vmovaps xmm1, [rsp+0x10]
00007986e0dda682  vmovaps xmm2, [rsp+0x20]
00007986e0dda688  vmovaps xmm3, [rsp+0x30]
00007986e0dda68e  vmovaps xmm4, [rsp+0x40]
00007986e0dda694  vmovaps xmm5, [rsp+0x50]
00007986e0dda69a  vmovaps xmm6, [rsp+0x60]
00007986e0dda6a0  vmovaps xmm7, [rsp+0x70]
00007986e0dda6a6  vmovaps xmm9, [rsp+0x80]
00007986e0dda6af  vmovaps xmm10, [rsp+0x90]
00007986e0dda6b8  vmovaps xmm11, [rsp+0xA0]
00007986e0dda6c1  vmovaps xmm12, [rsp+0xB0]
00007986e0dda6ca  vmovaps xmm13, [rsp+0xC0]
00007986e0dda6d3  vmovaps xmm14, [rsp+0xD0]
00007986e0dda6dc  vmovaps xmm15, [rsp+0xE0]
00007986e0dda6e5  add rsp, 0xF0
00007986e0dda6ec  pop r11
00007986e0dda6ee  pop r10
00007986e0dda6f0  pop r9
00007986e0dda6f2  pop r8
00007986e0dda6f4  pop rsi
00007986e0dda6f5  pop rdi
00007986e0dda6f6  pop rdx
00007986e0dda6f7  pop rcx
00007986e0dda6f8  pop rax
00007986e0dda6f9  add rsp, 0x08
00007986e0dda6fd  jmp 0x00007986E0DD648A
00007986e0dda702  sub rsp, 0x08
00007986e0dda706  push rax
00007986e0dda707  push rcx
00007986e0dda708  push rdx
00007986e0dda709  push rdi
00007986e0dda70a  push rsi
00007986e0dda70b  push r8
00007986e0dda70d  push r9
00007986e0dda70f  push r10
00007986e0dda711  push r11
00007986e0dda713  sub rsp, 0xF0
00007986e0dda71a  vmovaps [rsp], xmm0
00007986e0dda71f  vmovaps [rsp+0x10], xmm1
00007986e0dda725  vmovaps [rsp+0x20], xmm2
00007986e0dda72b  vmovaps [rsp+0x30], xmm3
00007986e0dda731  vmovaps [rsp+0x40], xmm4
00007986e0dda737  vmovaps [rsp+0x50], xmm5
00007986e0dda73d  vmovaps [rsp+0x60], xmm6
00007986e0dda743  vmovaps [rsp+0x70], xmm7
00007986e0dda749  vmovaps [rsp+0x80], xmm8
00007986e0dda752  vmovaps [rsp+0x90], xmm9
00007986e0dda75b  vmovaps [rsp+0xA0], xmm10
00007986e0dda764  vmovaps [rsp+0xB0], xmm11
00007986e0dda76d  vmovaps [rsp+0xC0], xmm12
00007986e0dda776  vmovaps [rsp+0xD0], xmm13
00007986e0dda77f  vmovaps [rsp+0xE0], xmm14
00007986e0dda788  sub rsp, 0x30
00007986e0dda78c  movaps [rsp], xmm15
00007986e0dda791  movaps [rsp+0x10], xmm11
00007986e0dda797  movaps [rsp+0x20], xmm6
00007986e0dda79c  lea rdi, [rsp]
00007986e0dda7a0  mov esi, 0x00
00007986e0dda7a5  mov rax, 0x5652C689F530
00007986e0dda7af  call rax
00007986e0dda7b1  movaps xmm15, [rsp]
00007986e0dda7b6  add rsp, 0x30
00007986e0dda7ba  vmovaps xmm0, [rsp]
00007986e0dda7bf  vmovaps xmm1, [rsp+0x10]
00007986e0dda7c5  vmovaps xmm2, [rsp+0x20]
00007986e0dda7cb  vmovaps xmm3, [rsp+0x30]
00007986e0dda7d1  vmovaps xmm4, [rsp+0x40]
00007986e0dda7d7  vmovaps xmm5, [rsp+0x50]
00007986e0dda7dd  vmovaps xmm6, [rsp+0x60]
00007986e0dda7e3  vmovaps xmm7, [rsp+0x70]
00007986e0dda7e9  vmovaps xmm8, [rsp+0x80]
00007986e0dda7f2  vmovaps xmm9, [rsp+0x90]
00007986e0dda7fb  vmovaps xmm10, [rsp+0xA0]
00007986e0dda804  vmovaps xmm11, [rsp+0xB0]
00007986e0dda80d  vmovaps xmm12, [rsp+0xC0]
00007986e0dda816  vmovaps xmm13, [rsp+0xD0]
00007986e0dda81f  vmovaps xmm14, [rsp+0xE0]
00007986e0dda828  add rsp, 0xF0
00007986e0dda82f  pop r11
00007986e0dda831  pop r10
00007986e0dda833  pop r9
00007986e0dda835  pop r8
00007986e0dda837  pop rsi
00007986e0dda838  pop rdi
00007986e0dda839  pop rdx
00007986e0dda83a  pop rcx
00007986e0dda83b  pop rax
00007986e0dda83c  add rsp, 0x08
00007986e0dda840  jmp 0x00007986E0DD64A5
00007986e0dda845  sub rsp, 0x08
00007986e0dda849  push rax
00007986e0dda84a  push rcx
00007986e0dda84b  push rdx
00007986e0dda84c  push rdi
00007986e0dda84d  push rsi
00007986e0dda84e  push r8
00007986e0dda850  push r9
00007986e0dda852  push r10
00007986e0dda854  push r11
00007986e0dda856  sub rsp, 0xF0
00007986e0dda85d  vmovaps [rsp], xmm0
00007986e0dda862  vmovaps [rsp+0x10], xmm1
00007986e0dda868  vmovaps [rsp+0x20], xmm2
00007986e0dda86e  vmovaps [rsp+0x30], xmm3
00007986e0dda874  vmovaps [rsp+0x40], xmm4
00007986e0dda87a  vmovaps [rsp+0x50], xmm5
00007986e0dda880  vmovaps [rsp+0x60], xmm6
00007986e0dda886  vmovaps [rsp+0x70], xmm8
00007986e0dda88c  vmovaps [rsp+0x80], xmm9
00007986e0dda895  vmovaps [rsp+0x90], xmm10
00007986e0dda89e  vmovaps [rsp+0xA0], xmm11
00007986e0dda8a7  vmovaps [rsp+0xB0], xmm12
00007986e0dda8b0  vmovaps [rsp+0xC0], xmm13
00007986e0dda8b9  vmovaps [rsp+0xD0], xmm14
00007986e0dda8c2  vmovaps [rsp+0xE0], xmm15
00007986e0dda8cb  sub rsp, 0x30
00007986e0dda8cf  movaps [rsp], xmm7
00007986e0dda8d3  movaps [rsp+0x10], xmm11
00007986e0dda8d9  movaps [rsp+0x20], xmm9
00007986e0dda8df  lea rdi, [rsp]
00007986e0dda8e3  mov esi, 0x00
00007986e0dda8e8  mov rax, 0x5652C689F530
00007986e0dda8f2  call rax
00007986e0dda8f4  movaps xmm7, [rsp]
00007986e0dda8f8  add rsp, 0x30
00007986e0dda8fc  vmovaps xmm0, [rsp]
00007986e0dda901  vmovaps xmm1, [rsp+0x10]
00007986e0dda907  vmovaps xmm2, [rsp+0x20]
00007986e0dda90d  vmovaps xmm3, [rsp+0x30]
00007986e0dda913  vmovaps xmm4, [rsp+0x40]
00007986e0dda919  vmovaps xmm5, [rsp+0x50]
00007986e0dda91f  vmovaps xmm6, [rsp+0x60]
00007986e0dda925  vmovaps xmm8, [rsp+0x70]
00007986e0dda92b  vmovaps xmm9, [rsp+0x80]
00007986e0dda934  vmovaps xmm10, [rsp+0x90]
00007986e0dda93d  vmovaps xmm11, [rsp+0xA0]
00007986e0dda946  vmovaps xmm12, [rsp+0xB0]
00007986e0dda94f  vmovaps xmm13, [rsp+0xC0]
00007986e0dda958  vmovaps xmm14, [rsp+0xD0]
00007986e0dda961  vmovaps xmm15, [rsp+0xE0]
00007986e0dda96a  add rsp, 0xF0
00007986e0dda971  pop r11
00007986e0dda973  pop r10
00007986e0dda975  pop r9
00007986e0dda977  pop r8
00007986e0dda979  pop rsi
00007986e0dda97a  pop rdi
00007986e0dda97b  pop rdx
00007986e0dda97c  pop rcx
00007986e0dda97d  pop rax
00007986e0dda97e  add rsp, 0x08
00007986e0dda982  jmp 0x00007986E0DD64D2
00007986e0dda987  sub rsp, 0x08
00007986e0dda98b  push rax
00007986e0dda98c  push rcx
00007986e0dda98d  push rdx
00007986e0dda98e  push rdi
00007986e0dda98f  push rsi
00007986e0dda990  push r8
00007986e0dda992  push r9
00007986e0dda994  push r10
00007986e0dda996  push r11
00007986e0dda998  sub rsp, 0xF0
00007986e0dda99f  vmovaps [rsp], xmm0
00007986e0dda9a4  vmovaps [rsp+0x10], xmm1
00007986e0dda9aa  vmovaps [rsp+0x20], xmm2
00007986e0dda9b0  vmovaps [rsp+0x30], xmm3
00007986e0dda9b6  vmovaps [rsp+0x40], xmm4
00007986e0dda9bc  vmovaps [rsp+0x50], xmm5
00007986e0dda9c2  vmovaps [rsp+0x60], xmm6
00007986e0dda9c8  vmovaps [rsp+0x70], xmm7
00007986e0dda9ce  vmovaps [rsp+0x80], xmm8
00007986e0dda9d7  vmovaps [rsp+0x90], xmm9
00007986e0dda9e0  vmovaps [rsp+0xA0], xmm10
00007986e0dda9e9  vmovaps [rsp+0xB0], xmm12
00007986e0dda9f2  vmovaps [rsp+0xC0], xmm13
00007986e0dda9fb  vmovaps [rsp+0xD0], xmm14
00007986e0ddaa04  vmovaps [rsp+0xE0], xmm15
00007986e0ddaa0d  sub rsp, 0x30
00007986e0ddaa11  movaps [rsp], xmm11
00007986e0ddaa16  movaps [rsp+0x10], xmm10
00007986e0ddaa1c  movaps [rsp+0x20], xmm14
00007986e0ddaa22  lea rdi, [rsp]
00007986e0ddaa26  mov esi, 0x00
00007986e0ddaa2b  mov rax, 0x5652C689F530
00007986e0ddaa35  call rax
00007986e0ddaa37  movaps xmm11, [rsp]
00007986e0ddaa3c  add rsp, 0x30
00007986e0ddaa40  vmovaps xmm0, [rsp]
00007986e0ddaa45  vmovaps xmm1, [rsp+0x10]
00007986e0ddaa4b  vmovaps xmm2, [rsp+0x20]
00007986e0ddaa51  vmovaps xmm3, [rsp+0x30]
00007986e0ddaa57  vmovaps xmm4, [rsp+0x40]
00007986e0ddaa5d  vmovaps xmm5, [rsp+0x50]
00007986e0ddaa63  vmovaps xmm6, [rsp+0x60]
00007986e0ddaa69  vmovaps xmm7, [rsp+0x70]
00007986e0ddaa6f  vmovaps xmm8, [rsp+0x80]
00007986e0ddaa78  vmovaps xmm9, [rsp+0x90]
00007986e0ddaa81  vmovaps xmm10, [rsp+0xA0]
00007986e0ddaa8a  vmovaps xmm12, [rsp+0xB0]
00007986e0ddaa93  vmovaps xmm13, [rsp+0xC0]
00007986e0ddaa9c  vmovaps xmm14, [rsp+0xD0]
00007986e0ddaaa5  vmovaps xmm15, [rsp+0xE0]
00007986e0ddaaae  add rsp, 0xF0
00007986e0ddaab5  pop r11
00007986e0ddaab7  pop r10
00007986e0ddaab9  pop r9
00007986e0ddaabb  pop r8
00007986e0ddaabd  pop rsi
00007986e0ddaabe  pop rdi
00007986e0ddaabf  pop rdx
00007986e0ddaac0  pop rcx
00007986e0ddaac1  pop rax
00007986e0ddaac2  add rsp, 0x08
00007986e0ddaac6  jmp 0x00007986E0DD64ED
00007986e0ddaacb  call 0x00007986E0CE45A0
00007986e0ddaad0  jmp 0x00007986E0DD64F7
00007986e0ddaad5  sub rsp, 0x08
00007986e0ddaad9  push rax
00007986e0ddaada  push rcx
00007986e0ddaadb  push rdx
00007986e0ddaadc  push rdi
00007986e0ddaadd  push rsi
00007986e0ddaade  push r8
00007986e0ddaae0  push r9
00007986e0ddaae2  push r10
00007986e0ddaae4  push r11
00007986e0ddaae6  sub rsp, 0xF0
00007986e0ddaaed  vmovaps [rsp], xmm0
00007986e0ddaaf2  vmovaps [rsp+0x10], xmm1
00007986e0ddaaf8  vmovaps [rsp+0x20], xmm2
00007986e0ddaafe  vmovaps [rsp+0x30], xmm3
00007986e0ddab04  vmovaps [rsp+0x40], xmm4
00007986e0ddab0a  vmovaps [rsp+0x50], xmm5
00007986e0ddab10  vmovaps [rsp+0x60], xmm6
00007986e0ddab16  vmovaps [rsp+0x70], xmm7
00007986e0ddab1c  vmovaps [rsp+0x80], xmm8
00007986e0ddab25  vmovaps [rsp+0x90], xmm9
00007986e0ddab2e  vmovaps [rsp+0xA0], xmm11
00007986e0ddab37  vmovaps [rsp+0xB0], xmm12
00007986e0ddab40  vmovaps [rsp+0xC0], xmm13
00007986e0ddab49  vmovaps [rsp+0xD0], xmm14
00007986e0ddab52  vmovaps [rsp+0xE0], xmm15
00007986e0ddab5b  sub rsp, 0x30
00007986e0ddab5f  movaps [rsp], xmm10
00007986e0ddab64  movaps [rsp+0x10], xmm1
00007986e0ddab69  movaps [rsp+0x20], xmm12
00007986e0ddab6f  lea rdi, [rsp]
00007986e0ddab73  mov esi, 0x00
00007986e0ddab78  mov rax, 0x5652C689F530
00007986e0ddab82  call rax
00007986e0ddab84  movaps xmm10, [rsp]
00007986e0ddab89  add rsp, 0x30
00007986e0ddab8d  vmovaps xmm0, [rsp]
00007986e0ddab92  vmovaps xmm1, [rsp+0x10]
00007986e0ddab98  vmovaps xmm2, [rsp+0x20]
00007986e0ddab9e  vmovaps xmm3, [rsp+0x30]
00007986e0ddaba4  vmovaps xmm4, [rsp+0x40]
00007986e0ddabaa  vmovaps xmm5, [rsp+0x50]
00007986e0ddabb0  vmovaps xmm6, [rsp+0x60]
00007986e0ddabb6  vmovaps xmm7, [rsp+0x70]
00007986e0ddabbc  vmovaps xmm8, [rsp+0x80]
00007986e0ddabc5  vmovaps xmm9, [rsp+0x90]
00007986e0ddabce  vmovaps xmm11, [rsp+0xA0]
00007986e0ddabd7  vmovaps xmm12, [rsp+0xB0]
00007986e0ddabe0  vmovaps xmm13, [rsp+0xC0]
00007986e0ddabe9  vmovaps xmm14, [rsp+0xD0]
00007986e0ddabf2  vmovaps xmm15, [rsp+0xE0]
00007986e0ddabfb  add rsp, 0xF0
00007986e0ddac02  pop r11
00007986e0ddac04  pop r10
00007986e0ddac06  pop r9
00007986e0ddac08  pop r8
00007986e0ddac0a  pop rsi
00007986e0ddac0b  pop rdi
00007986e0ddac0c  pop rdx
00007986e0ddac0d  pop rcx
00007986e0ddac0e  pop rax
00007986e0ddac0f  add rsp, 0x08
00007986e0ddac13  jmp 0x00007986E0DD651A
00007986e0ddac18  sub rsp, 0x08
00007986e0ddac1c  push rax
00007986e0ddac1d  push rcx
00007986e0ddac1e  push rdx
00007986e0ddac1f  push rdi
00007986e0ddac20  push rsi
00007986e0ddac21  push r8
00007986e0ddac23  push r9
00007986e0ddac25  push r10
00007986e0ddac27  push r11
00007986e0ddac29  sub rsp, 0xF0
00007986e0ddac30  vmovaps [rsp], xmm0
00007986e0ddac35  vmovaps [rsp+0x10], xmm1
00007986e0ddac3b  vmovaps [rsp+0x20], xmm2
00007986e0ddac41  vmovaps [rsp+0x30], xmm3
00007986e0ddac47  vmovaps [rsp+0x40], xmm4
00007986e0ddac4d  vmovaps [rsp+0x50], xmm5
00007986e0ddac53  vmovaps [rsp+0x60], xmm6
00007986e0ddac59  vmovaps [rsp+0x70], xmm7
00007986e0ddac5f  vmovaps [rsp+0x80], xmm8
00007986e0ddac68  vmovaps [rsp+0x90], xmm9
00007986e0ddac71  vmovaps [rsp+0xA0], xmm10
00007986e0ddac7a  vmovaps [rsp+0xB0], xmm11
00007986e0ddac83  vmovaps [rsp+0xC0], xmm13
00007986e0ddac8c  vmovaps [rsp+0xD0], xmm14
00007986e0ddac95  vmovaps [rsp+0xE0], xmm15
00007986e0ddac9e  sub rsp, 0x30
00007986e0ddaca2  movaps [rsp], xmm12
00007986e0ddaca7  movaps [rsp+0x10], xmm14
00007986e0ddacad  movaps [rsp+0x20], xmm1
00007986e0ddacb2  lea rdi, [rsp]
00007986e0ddacb6  mov esi, 0x00
00007986e0ddacbb  mov rax, 0x5652C689F530
00007986e0ddacc5  call rax
00007986e0ddacc7  movaps xmm12, [rsp]
00007986e0ddaccc  add rsp, 0x30
00007986e0ddacd0  vmovaps xmm0, [rsp]
00007986e0ddacd5  vmovaps xmm1, [rsp+0x10]
00007986e0ddacdb  vmovaps xmm2, [rsp+0x20]
00007986e0ddace1  vmovaps xmm3, [rsp+0x30]
00007986e0ddace7  vmovaps xmm4, [rsp+0x40]
00007986e0ddaced  vmovaps xmm5, [rsp+0x50]
00007986e0ddacf3  vmovaps xmm6, [rsp+0x60]
00007986e0ddacf9  vmovaps xmm7, [rsp+0x70]
00007986e0ddacff  vmovaps xmm8, [rsp+0x80]
00007986e0ddad08  vmovaps xmm9, [rsp+0x90]
00007986e0ddad11  vmovaps xmm10, [rsp+0xA0]
00007986e0ddad1a  vmovaps xmm11, [rsp+0xB0]
00007986e0ddad23  vmovaps xmm13, [rsp+0xC0]
00007986e0ddad2c  vmovaps xmm14, [rsp+0xD0]
00007986e0ddad35  vmovaps xmm15, [rsp+0xE0]
00007986e0ddad3e  add rsp, 0xF0
00007986e0ddad45  pop r11
00007986e0ddad47  pop r10
00007986e0ddad49  pop r9
00007986e0ddad4b  pop r8
00007986e0ddad4d  pop rsi
00007986e0ddad4e  pop rdi
00007986e0ddad4f  pop rdx
00007986e0ddad50  pop rcx
00007986e0ddad51  pop rax
00007986e0ddad52  add rsp, 0x08
00007986e0ddad56  jmp 0x00007986E0DD6549
00007986e0ddad5b  sub rsp, 0x08
00007986e0ddad5f  push rax
00007986e0ddad60  push rcx
00007986e0ddad61  push rdx
00007986e0ddad62  push rdi
00007986e0ddad63  push rsi
00007986e0ddad64  push r8
00007986e0ddad66  push r9
00007986e0ddad68  push r10
00007986e0ddad6a  push r11
00007986e0ddad6c  sub rsp, 0xF0
00007986e0ddad73  vmovaps [rsp], xmm0
00007986e0ddad78  vmovaps [rsp+0x10], xmm1
00007986e0ddad7e  vmovaps [rsp+0x20], xmm2
00007986e0ddad84  vmovaps [rsp+0x30], xmm3
00007986e0ddad8a  vmovaps [rsp+0x40], xmm4
00007986e0ddad90  vmovaps [rsp+0x50], xmm5
00007986e0ddad96  vmovaps [rsp+0x60], xmm6
00007986e0ddad9c  vmovaps [rsp+0x70], xmm7
00007986e0ddada2  vmovaps [rsp+0x80], xmm8
00007986e0ddadab  vmovaps [rsp+0x90], xmm9
00007986e0ddadb4  vmovaps [rsp+0xA0], xmm10
00007986e0ddadbd  vmovaps [rsp+0xB0], xmm11
00007986e0ddadc6  vmovaps [rsp+0xC0], xmm12
00007986e0ddadcf  vmovaps [rsp+0xD0], xmm13
00007986e0ddadd8  vmovaps [rsp+0xE0], xmm15
00007986e0ddade1  sub rsp, 0x30
00007986e0ddade5  movaps [rsp], xmm14
00007986e0ddadea  movaps [rsp+0x10], xmm9
00007986e0ddadf0  movaps [rsp+0x20], xmm1
00007986e0ddadf5  lea rdi, [rsp]
00007986e0ddadf9  mov esi, 0x00
00007986e0ddadfe  mov rax, 0x5652C689F530
00007986e0ddae08  call rax
00007986e0ddae0a  movaps xmm14, [rsp]
00007986e0ddae0f  add rsp, 0x30
00007986e0ddae13  vmovaps xmm0, [rsp]
00007986e0ddae18  vmovaps xmm1, [rsp+0x10]
00007986e0ddae1e  vmovaps xmm2, [rsp+0x20]
00007986e0ddae24  vmovaps xmm3, [rsp+0x30]
00007986e0ddae2a  vmovaps xmm4, [rsp+0x40]
00007986e0ddae30  vmovaps xmm5, [rsp+0x50]
00007986e0ddae36  vmovaps xmm6, [rsp+0x60]
00007986e0ddae3c  vmovaps xmm7, [rsp+0x70]
00007986e0ddae42  vmovaps xmm8, [rsp+0x80]
00007986e0ddae4b  vmovaps xmm9, [rsp+0x90]
00007986e0ddae54  vmovaps xmm10, [rsp+0xA0]
00007986e0ddae5d  vmovaps xmm11, [rsp+0xB0]
00007986e0ddae66  vmovaps xmm12, [rsp+0xC0]
00007986e0ddae6f  vmovaps xmm13, [rsp+0xD0]
00007986e0ddae78  vmovaps xmm15, [rsp+0xE0]
00007986e0ddae81  add rsp, 0xF0
00007986e0ddae88  pop r11
00007986e0ddae8a  pop r10
00007986e0ddae8c  pop r9
00007986e0ddae8e  pop r8
00007986e0ddae90  pop rsi
00007986e0ddae91  pop rdi
00007986e0ddae92  pop rdx
00007986e0ddae93  pop rcx
00007986e0ddae94  pop rax
00007986e0ddae95  add rsp, 0x08
00007986e0ddae99  jmp 0x00007986E0DD6578
00007986e0ddae9e  sub rsp, 0x08
00007986e0ddaea2  push rax
00007986e0ddaea3  push rcx
00007986e0ddaea4  push rdx
00007986e0ddaea5  push rdi
00007986e0ddaea6  push rsi
00007986e0ddaea7  push r8
00007986e0ddaea9  push r9
00007986e0ddaeab  push r10
00007986e0ddaead  push r11
00007986e0ddaeaf  sub rsp, 0xF0
00007986e0ddaeb6  vmovaps [rsp], xmm0
00007986e0ddaebb  vmovaps [rsp+0x10], xmm2
00007986e0ddaec1  vmovaps [rsp+0x20], xmm3
00007986e0ddaec7  vmovaps [rsp+0x30], xmm4
00007986e0ddaecd  vmovaps [rsp+0x40], xmm5
00007986e0ddaed3  vmovaps [rsp+0x50], xmm6
00007986e0ddaed9  vmovaps [rsp+0x60], xmm7
00007986e0ddaedf  vmovaps [rsp+0x70], xmm8
00007986e0ddaee5  vmovaps [rsp+0x80], xmm9
00007986e0ddaeee  vmovaps [rsp+0x90], xmm10
00007986e0ddaef7  vmovaps [rsp+0xA0], xmm11
00007986e0ddaf00  vmovaps [rsp+0xB0], xmm12
00007986e0ddaf09  vmovaps [rsp+0xC0], xmm13
00007986e0ddaf12  vmovaps [rsp+0xD0], xmm14
00007986e0ddaf1b  vmovaps [rsp+0xE0], xmm15
00007986e0ddaf24  sub rsp, 0x30
00007986e0ddaf28  movaps [rsp], xmm1
00007986e0ddaf2c  movaps [rsp+0x10], xmm13
00007986e0ddaf32  movaps [rsp+0x20], xmm8
00007986e0ddaf38  lea rdi, [rsp]
00007986e0ddaf3c  mov esi, 0x00
00007986e0ddaf41  mov rax, 0x5652C689F530
00007986e0ddaf4b  call rax
00007986e0ddaf4d  movaps xmm1, [rsp]
00007986e0ddaf51  add rsp, 0x30
00007986e0ddaf55  vmovaps xmm0, [rsp]
00007986e0ddaf5a  vmovaps xmm2, [rsp+0x10]
00007986e0ddaf60  vmovaps xmm3, [rsp+0x20]
00007986e0ddaf66  vmovaps xmm4, [rsp+0x30]
00007986e0ddaf6c  vmovaps xmm5, [rsp+0x40]
00007986e0ddaf72  vmovaps xmm6, [rsp+0x50]
00007986e0ddaf78  vmovaps xmm7, [rsp+0x60]
00007986e0ddaf7e  vmovaps xmm8, [rsp+0x70]
00007986e0ddaf84  vmovaps xmm9, [rsp+0x80]
00007986e0ddaf8d  vmovaps xmm10, [rsp+0x90]
00007986e0ddaf96  vmovaps xmm11, [rsp+0xA0]
00007986e0ddaf9f  vmovaps xmm12, [rsp+0xB0]
00007986e0ddafa8  vmovaps xmm13, [rsp+0xC0]
00007986e0ddafb1  vmovaps xmm14, [rsp+0xD0]
00007986e0ddafba  vmovaps xmm15, [rsp+0xE0]
00007986e0ddafc3  add rsp, 0xF0
00007986e0ddafca  pop r11
00007986e0ddafcc  pop r10
00007986e0ddafce  pop r9
00007986e0ddafd0  pop r8
00007986e0ddafd2  pop rsi
00007986e0ddafd3  pop rdi
00007986e0ddafd4  pop rdx
00007986e0ddafd5  pop rcx
00007986e0ddafd6  pop rax
00007986e0ddafd7  add rsp, 0x08
00007986e0ddafdb  jmp 0x00007986E0DD659A
00007986e0ddafe0  call 0x00007986E0C0C260
00007986e0ddafe5  jmp 0x00007986E0DD65A8
00007986e0ddafea  call 0x00007986E0CDE950
00007986e0ddafef  jmp 0x00007986E0DD65B2
00007986e0ddaff4  sub rsp, 0x08
00007986e0ddaff8  push rax
00007986e0ddaff9  push rcx
00007986e0ddaffa  push rdx
00007986e0ddaffb  push rdi
00007986e0ddaffc  push rsi
00007986e0ddaffd  push r8
00007986e0ddafff  push r9
00007986e0ddb001  push r10
00007986e0ddb003  push r11
00007986e0ddb005  sub rsp, 0xF0
00007986e0ddb00c  vmovaps [rsp], xmm0
00007986e0ddb011  vmovaps [rsp+0x10], xmm1
00007986e0ddb017  vmovaps [rsp+0x20], xmm2
00007986e0ddb01d  vmovaps [rsp+0x30], xmm3
00007986e0ddb023  vmovaps [rsp+0x40], xmm4
00007986e0ddb029  vmovaps [rsp+0x50], xmm5
00007986e0ddb02f  vmovaps [rsp+0x60], xmm6
00007986e0ddb035  vmovaps [rsp+0x70], xmm7
00007986e0ddb03b  vmovaps [rsp+0x80], xmm9
00007986e0ddb044  vmovaps [rsp+0x90], xmm10
00007986e0ddb04d  vmovaps [rsp+0xA0], xmm11
00007986e0ddb056  vmovaps [rsp+0xB0], xmm12
00007986e0ddb05f  vmovaps [rsp+0xC0], xmm13
00007986e0ddb068  vmovaps [rsp+0xD0], xmm14
00007986e0ddb071  vmovaps [rsp+0xE0], xmm15
00007986e0ddb07a  sub rsp, 0x30
00007986e0ddb07e  movaps [rsp], xmm8
00007986e0ddb083  movaps [rsp+0x10], xmm15
00007986e0ddb089  movaps [rsp+0x20], xmm7
00007986e0ddb08e  lea rdi, [rsp]
00007986e0ddb092  mov esi, 0x00
00007986e0ddb097  mov rax, 0x5652C689F530
00007986e0ddb0a1  call rax
00007986e0ddb0a3  movaps xmm8, [rsp]
00007986e0ddb0a8  add rsp, 0x30
00007986e0ddb0ac  vmovaps xmm0, [rsp]
00007986e0ddb0b1  vmovaps xmm1, [rsp+0x10]
00007986e0ddb0b7  vmovaps xmm2, [rsp+0x20]
00007986e0ddb0bd  vmovaps xmm3, [rsp+0x30]
00007986e0ddb0c3  vmovaps xmm4, [rsp+0x40]
00007986e0ddb0c9  vmovaps xmm5, [rsp+0x50]
00007986e0ddb0cf  vmovaps xmm6, [rsp+0x60]
00007986e0ddb0d5  vmovaps xmm7, [rsp+0x70]
00007986e0ddb0db  vmovaps xmm9, [rsp+0x80]
00007986e0ddb0e4  vmovaps xmm10, [rsp+0x90]
00007986e0ddb0ed  vmovaps xmm11, [rsp+0xA0]
00007986e0ddb0f6  vmovaps xmm12, [rsp+0xB0]
00007986e0ddb0ff  vmovaps xmm13, [rsp+0xC0]
00007986e0ddb108  vmovaps xmm14, [rsp+0xD0]
00007986e0ddb111  vmovaps xmm15, [rsp+0xE0]
00007986e0ddb11a  add rsp, 0xF0
00007986e0ddb121  pop r11
00007986e0ddb123  pop r10
00007986e0ddb125  pop r9
00007986e0ddb127  pop r8
00007986e0ddb129  pop rsi
00007986e0ddb12a  pop rdi
00007986e0ddb12b  pop rdx
00007986e0ddb12c  pop rcx
00007986e0ddb12d  pop rax
00007986e0ddb12e  add rsp, 0x08
00007986e0ddb132  jmp 0x00007986E0DD65D4
00007986e0ddb137  sub rsp, 0x08
00007986e0ddb13b  push rax
00007986e0ddb13c  push rcx
00007986e0ddb13d  push rdx
00007986e0ddb13e  push rdi
00007986e0ddb13f  push rsi
00007986e0ddb140  push r8
00007986e0ddb142  push r9
00007986e0ddb144  push r10
00007986e0ddb146  push r11
00007986e0ddb148  sub rsp, 0xF0
00007986e0ddb14f  vmovaps [rsp], xmm0
00007986e0ddb154  vmovaps [rsp+0x10], xmm1
00007986e0ddb15a  vmovaps [rsp+0x20], xmm2
00007986e0ddb160  vmovaps [rsp+0x30], xmm3
00007986e0ddb166  vmovaps [rsp+0x40], xmm4
00007986e0ddb16c  vmovaps [rsp+0x50], xmm5
00007986e0ddb172  vmovaps [rsp+0x60], xmm6
00007986e0ddb178  vmovaps [rsp+0x70], xmm8
00007986e0ddb17e  vmovaps [rsp+0x80], xmm9
00007986e0ddb187  vmovaps [rsp+0x90], xmm10
00007986e0ddb190  vmovaps [rsp+0xA0], xmm11
00007986e0ddb199  vmovaps [rsp+0xB0], xmm12
00007986e0ddb1a2  vmovaps [rsp+0xC0], xmm13
00007986e0ddb1ab  vmovaps [rsp+0xD0], xmm14
00007986e0ddb1b4  vmovaps [rsp+0xE0], xmm15
00007986e0ddb1bd  sub rsp, 0x30
00007986e0ddb1c1  movaps [rsp], xmm7
00007986e0ddb1c5  movaps [rsp+0x10], xmm9
00007986e0ddb1cb  movaps [rsp+0x20], xmm15
00007986e0ddb1d1  lea rdi, [rsp]
00007986e0ddb1d5  mov esi, 0x00
00007986e0ddb1da  mov rax, 0x5652C689F530
00007986e0ddb1e4  call rax
00007986e0ddb1e6  movaps xmm7, [rsp]
00007986e0ddb1ea  add rsp, 0x30
00007986e0ddb1ee  vmovaps xmm0, [rsp]
00007986e0ddb1f3  vmovaps xmm1, [rsp+0x10]
00007986e0ddb1f9  vmovaps xmm2, [rsp+0x20]
00007986e0ddb1ff  vmovaps xmm3, [rsp+0x30]
00007986e0ddb205  vmovaps xmm4, [rsp+0x40]
00007986e0ddb20b  vmovaps xmm5, [rsp+0x50]
00007986e0ddb211  vmovaps xmm6, [rsp+0x60]
00007986e0ddb217  vmovaps xmm8, [rsp+0x70]
00007986e0ddb21d  vmovaps xmm9, [rsp+0x80]
00007986e0ddb226  vmovaps xmm10, [rsp+0x90]
00007986e0ddb22f  vmovaps xmm11, [rsp+0xA0]
00007986e0ddb238  vmovaps xmm12, [rsp+0xB0]
00007986e0ddb241  vmovaps xmm13, [rsp+0xC0]
00007986e0ddb24a  vmovaps xmm14, [rsp+0xD0]
00007986e0ddb253  vmovaps xmm15, [rsp+0xE0]
00007986e0ddb25c  add rsp, 0xF0
00007986e0ddb263  pop r11
00007986e0ddb265  pop r10
00007986e0ddb267  pop r9
00007986e0ddb269  pop r8
00007986e0ddb26b  pop rsi
00007986e0ddb26c  pop rdi
00007986e0ddb26d  pop rdx
00007986e0ddb26e  pop rcx
00007986e0ddb26f  pop rax
00007986e0ddb270  add rsp, 0x08
00007986e0ddb274  jmp 0x00007986E0DD6601
00007986e0ddb279  sub rsp, 0x08
00007986e0ddb27d  push rax
00007986e0ddb27e  push rcx
00007986e0ddb27f  push rdx
00007986e0ddb280  push rdi
00007986e0ddb281  push rsi
00007986e0ddb282  push r8
00007986e0ddb284  push r9
00007986e0ddb286  push r10
00007986e0ddb288  push r11
00007986e0ddb28a  sub rsp, 0xF0
00007986e0ddb291  vmovaps [rsp], xmm0
00007986e0ddb296  vmovaps [rsp+0x10], xmm1
00007986e0ddb29c  vmovaps [rsp+0x20], xmm2
00007986e0ddb2a2  vmovaps [rsp+0x30], xmm3
00007986e0ddb2a8  vmovaps [rsp+0x40], xmm4
00007986e0ddb2ae  vmovaps [rsp+0x50], xmm5
00007986e0ddb2b4  vmovaps [rsp+0x60], xmm6
00007986e0ddb2ba  vmovaps [rsp+0x70], xmm7
00007986e0ddb2c0  vmovaps [rsp+0x80], xmm8
00007986e0ddb2c9  vmovaps [rsp+0x90], xmm10
00007986e0ddb2d2  vmovaps [rsp+0xA0], xmm11
00007986e0ddb2db  vmovaps [rsp+0xB0], xmm12
00007986e0ddb2e4  vmovaps [rsp+0xC0], xmm13
00007986e0ddb2ed  vmovaps [rsp+0xD0], xmm14
00007986e0ddb2f6  vmovaps [rsp+0xE0], xmm15
00007986e0ddb2ff  sub rsp, 0x30
00007986e0ddb303  movaps [rsp], xmm9
00007986e0ddb308  movaps [rsp+0x10], xmm13
00007986e0ddb30e  movaps [rsp+0x20], xmm15
00007986e0ddb314  lea rdi, [rsp]
00007986e0ddb318  mov esi, 0x00
00007986e0ddb31d  mov rax, 0x5652C689F530
00007986e0ddb327  call rax
00007986e0ddb329  movaps xmm9, [rsp]
00007986e0ddb32e  add rsp, 0x30
00007986e0ddb332  vmovaps xmm0, [rsp]
00007986e0ddb337  vmovaps xmm1, [rsp+0x10]
00007986e0ddb33d  vmovaps xmm2, [rsp+0x20]
00007986e0ddb343  vmovaps xmm3, [rsp+0x30]
00007986e0ddb349  vmovaps xmm4, [rsp+0x40]
00007986e0ddb34f  vmovaps xmm5, [rsp+0x50]
00007986e0ddb355  vmovaps xmm6, [rsp+0x60]
00007986e0ddb35b  vmovaps xmm7, [rsp+0x70]
00007986e0ddb361  vmovaps xmm8, [rsp+0x80]
00007986e0ddb36a  vmovaps xmm10, [rsp+0x90]
00007986e0ddb373  vmovaps xmm11, [rsp+0xA0]
00007986e0ddb37c  vmovaps xmm12, [rsp+0xB0]
00007986e0ddb385  vmovaps xmm13, [rsp+0xC0]
00007986e0ddb38e  vmovaps xmm14, [rsp+0xD0]
00007986e0ddb397  vmovaps xmm15, [rsp+0xE0]
00007986e0ddb3a0  add rsp, 0xF0
00007986e0ddb3a7  pop r11
00007986e0ddb3a9  pop r10
00007986e0ddb3ab  pop r9
00007986e0ddb3ad  pop r8
00007986e0ddb3af  pop rsi
00007986e0ddb3b0  pop rdi
00007986e0ddb3b1  pop rdx
00007986e0ddb3b2  pop rcx
00007986e0ddb3b3  pop rax
00007986e0ddb3b4  add rsp, 0x08
00007986e0ddb3b8  jmp 0x00007986E0DD662F
00007986e0ddb3bd  sub rsp, 0x08
00007986e0ddb3c1  push rax
00007986e0ddb3c2  push rcx
00007986e0ddb3c3  push rdx
00007986e0ddb3c4  push rdi
00007986e0ddb3c5  push rsi
00007986e0ddb3c6  push r8
00007986e0ddb3c8  push r9
00007986e0ddb3ca  push r10
00007986e0ddb3cc  push r11
00007986e0ddb3ce  sub rsp, 0xF0
00007986e0ddb3d5  vmovaps [rsp], xmm0
00007986e0ddb3da  vmovaps [rsp+0x10], xmm1
00007986e0ddb3e0  vmovaps [rsp+0x20], xmm2
00007986e0ddb3e6  vmovaps [rsp+0x30], xmm3
00007986e0ddb3ec  vmovaps [rsp+0x40], xmm4
00007986e0ddb3f2  vmovaps [rsp+0x50], xmm5
00007986e0ddb3f8  vmovaps [rsp+0x60], xmm6
00007986e0ddb3fe  vmovaps [rsp+0x70], xmm7
00007986e0ddb404  vmovaps [rsp+0x80], xmm8
00007986e0ddb40d  vmovaps [rsp+0x90], xmm9
00007986e0ddb416  vmovaps [rsp+0xA0], xmm10
00007986e0ddb41f  vmovaps [rsp+0xB0], xmm11
00007986e0ddb428  vmovaps [rsp+0xC0], xmm12
00007986e0ddb431  vmovaps [rsp+0xD0], xmm13
00007986e0ddb43a  vmovaps [rsp+0xE0], xmm14
00007986e0ddb443  sub rsp, 0x30
00007986e0ddb447  movaps [rsp], xmm15
00007986e0ddb44c  movaps [rsp+0x10], xmm11
00007986e0ddb452  movaps [rsp+0x20], xmm12
00007986e0ddb458  lea rdi, [rsp]
00007986e0ddb45c  mov esi, 0x00
00007986e0ddb461  mov rax, 0x5652C689F530
00007986e0ddb46b  call rax
00007986e0ddb46d  movaps xmm15, [rsp]
00007986e0ddb472  add rsp, 0x30
00007986e0ddb476  vmovaps xmm0, [rsp]
00007986e0ddb47b  vmovaps xmm1, [rsp+0x10]
00007986e0ddb481  vmovaps xmm2, [rsp+0x20]
00007986e0ddb487  vmovaps xmm3, [rsp+0x30]
00007986e0ddb48d  vmovaps xmm4, [rsp+0x40]
00007986e0ddb493  vmovaps xmm5, [rsp+0x50]
00007986e0ddb499  vmovaps xmm6, [rsp+0x60]
00007986e0ddb49f  vmovaps xmm7, [rsp+0x70]
00007986e0ddb4a5  vmovaps xmm8, [rsp+0x80]
00007986e0ddb4ae  vmovaps xmm9, [rsp+0x90]
00007986e0ddb4b7  vmovaps xmm10, [rsp+0xA0]
00007986e0ddb4c0  vmovaps xmm11, [rsp+0xB0]
00007986e0ddb4c9  vmovaps xmm12, [rsp+0xC0]
00007986e0ddb4d2  vmovaps xmm13, [rsp+0xD0]
00007986e0ddb4db  vmovaps xmm14, [rsp+0xE0]
00007986e0ddb4e4  add rsp, 0xF0
00007986e0ddb4eb  pop r11
00007986e0ddb4ed  pop r10
00007986e0ddb4ef  pop r9
00007986e0ddb4f1  pop r8
00007986e0ddb4f3  pop rsi
00007986e0ddb4f4  pop rdi
00007986e0ddb4f5  pop rdx
00007986e0ddb4f6  pop rcx
00007986e0ddb4f7  pop rax
00007986e0ddb4f8  add rsp, 0x08
00007986e0ddb4fc  jmp 0x00007986E0DD664A
00007986e0ddb501  sub rsp, 0x08
00007986e0ddb505  push rax
00007986e0ddb506  push rcx
00007986e0ddb507  push rdx
00007986e0ddb508  push rdi
00007986e0ddb509  push rsi
00007986e0ddb50a  push r8
00007986e0ddb50c  push r9
00007986e0ddb50e  push r10
00007986e0ddb510  push r11
00007986e0ddb512  sub rsp, 0xF0
00007986e0ddb519  vmovaps [rsp], xmm0
00007986e0ddb51e  vmovaps [rsp+0x10], xmm1
00007986e0ddb524  vmovaps [rsp+0x20], xmm2
00007986e0ddb52a  vmovaps [rsp+0x30], xmm3
00007986e0ddb530  vmovaps [rsp+0x40], xmm4
00007986e0ddb536  vmovaps [rsp+0x50], xmm5
00007986e0ddb53c  vmovaps [rsp+0x60], xmm6
00007986e0ddb542  vmovaps [rsp+0x70], xmm7
00007986e0ddb548  vmovaps [rsp+0x80], xmm8
00007986e0ddb551  vmovaps [rsp+0x90], xmm9
00007986e0ddb55a  vmovaps [rsp+0xA0], xmm10
00007986e0ddb563  vmovaps [rsp+0xB0], xmm11
00007986e0ddb56c  vmovaps [rsp+0xC0], xmm12
00007986e0ddb575  vmovaps [rsp+0xD0], xmm14
00007986e0ddb57e  vmovaps [rsp+0xE0], xmm15
00007986e0ddb587  sub rsp, 0x30
00007986e0ddb58b  movaps [rsp], xmm13
00007986e0ddb590  movaps [rsp+0x10], xmm10
00007986e0ddb596  movaps [rsp+0x20], xmm14
00007986e0ddb59c  lea rdi, [rsp]
00007986e0ddb5a0  mov esi, 0x00
00007986e0ddb5a5  mov rax, 0x5652C689F530
00007986e0ddb5af  call rax
00007986e0ddb5b1  movaps xmm13, [rsp]
00007986e0ddb5b6  add rsp, 0x30
00007986e0ddb5ba  vmovaps xmm0, [rsp]
00007986e0ddb5bf  vmovaps xmm1, [rsp+0x10]
00007986e0ddb5c5  vmovaps xmm2, [rsp+0x20]
00007986e0ddb5cb  vmovaps xmm3, [rsp+0x30]
00007986e0ddb5d1  vmovaps xmm4, [rsp+0x40]
00007986e0ddb5d7  vmovaps xmm5, [rsp+0x50]
00007986e0ddb5dd  vmovaps xmm6, [rsp+0x60]
00007986e0ddb5e3  vmovaps xmm7, [rsp+0x70]
00007986e0ddb5e9  vmovaps xmm8, [rsp+0x80]
00007986e0ddb5f2  vmovaps xmm9, [rsp+0x90]
00007986e0ddb5fb  vmovaps xmm10, [rsp+0xA0]
00007986e0ddb604  vmovaps xmm11, [rsp+0xB0]
00007986e0ddb60d  vmovaps xmm12, [rsp+0xC0]
00007986e0ddb616  vmovaps xmm14, [rsp+0xD0]
00007986e0ddb61f  vmovaps xmm15, [rsp+0xE0]
00007986e0ddb628  add rsp, 0xF0
00007986e0ddb62f  pop r11
00007986e0ddb631  pop r10
00007986e0ddb633  pop r9
00007986e0ddb635  pop r8
00007986e0ddb637  pop rsi
00007986e0ddb638  pop rdi
00007986e0ddb639  pop rdx
00007986e0ddb63a  pop rcx
00007986e0ddb63b  pop rax
00007986e0ddb63c  add rsp, 0x08
00007986e0ddb640  jmp 0x00007986E0DD666D
00007986e0ddb645  sub rsp, 0x08
00007986e0ddb649  push rax
00007986e0ddb64a  push rcx
00007986e0ddb64b  push rdx
00007986e0ddb64c  push rdi
00007986e0ddb64d  push rsi
00007986e0ddb64e  push r8
00007986e0ddb650  push r9
00007986e0ddb652  push r10
00007986e0ddb654  push r11
00007986e0ddb656  sub rsp, 0xF0
00007986e0ddb65d  vmovaps [rsp], xmm0
00007986e0ddb662  vmovaps [rsp+0x10], xmm1
00007986e0ddb668  vmovaps [rsp+0x20], xmm2
00007986e0ddb66e  vmovaps [rsp+0x30], xmm3
00007986e0ddb674  vmovaps [rsp+0x40], xmm4
00007986e0ddb67a  vmovaps [rsp+0x50], xmm5
00007986e0ddb680  vmovaps [rsp+0x60], xmm6
00007986e0ddb686  vmovaps [rsp+0x70], xmm7
00007986e0ddb68c  vmovaps [rsp+0x80], xmm8
00007986e0ddb695  vmovaps [rsp+0x90], xmm9
00007986e0ddb69e  vmovaps [rsp+0xA0], xmm10
00007986e0ddb6a7  vmovaps [rsp+0xB0], xmm11
00007986e0ddb6b0  vmovaps [rsp+0xC0], xmm12
00007986e0ddb6b9  vmovaps [rsp+0xD0], xmm13
00007986e0ddb6c2  vmovaps [rsp+0xE0], xmm15
00007986e0ddb6cb  sub rsp, 0x30
00007986e0ddb6cf  movaps [rsp], xmm14
00007986e0ddb6d4  movaps [rsp+0x10], xmm1
00007986e0ddb6d9  movaps [rsp+0x20], xmm7
00007986e0ddb6de  lea rdi, [rsp]
00007986e0ddb6e2  mov esi, 0x00
00007986e0ddb6e7  mov rax, 0x5652C689F530
00007986e0ddb6f1  call rax
00007986e0ddb6f3  movaps xmm14, [rsp]
00007986e0ddb6f8  add rsp, 0x30
00007986e0ddb6fc  vmovaps xmm0, [rsp]
00007986e0ddb701  vmovaps xmm1, [rsp+0x10]
00007986e0ddb707  vmovaps xmm2, [rsp+0x20]
00007986e0ddb70d  vmovaps xmm3, [rsp+0x30]
00007986e0ddb713  vmovaps xmm4, [rsp+0x40]
00007986e0ddb719  vmovaps xmm5, [rsp+0x50]
00007986e0ddb71f  vmovaps xmm6, [rsp+0x60]
00007986e0ddb725  vmovaps xmm7, [rsp+0x70]
00007986e0ddb72b  vmovaps xmm8, [rsp+0x80]
00007986e0ddb734  vmovaps xmm9, [rsp+0x90]
00007986e0ddb73d  vmovaps xmm10, [rsp+0xA0]
00007986e0ddb746  vmovaps xmm11, [rsp+0xB0]
00007986e0ddb74f  vmovaps xmm12, [rsp+0xC0]
00007986e0ddb758  vmovaps xmm13, [rsp+0xD0]
00007986e0ddb761  vmovaps xmm15, [rsp+0xE0]
00007986e0ddb76a  add rsp, 0xF0
00007986e0ddb771  pop r11
00007986e0ddb773  pop r10
00007986e0ddb775  pop r9
00007986e0ddb777  pop r8
00007986e0ddb779  pop rsi
00007986e0ddb77a  pop rdi
00007986e0ddb77b  pop rdx
00007986e0ddb77c  pop rcx
00007986e0ddb77d  pop rax
00007986e0ddb77e  add rsp, 0x08
00007986e0ddb782  jmp 0x00007986E0DD6690
00007986e0ddb787  sub rsp, 0x08
00007986e0ddb78b  push rax
00007986e0ddb78c  push rcx
00007986e0ddb78d  push rdx
00007986e0ddb78e  push rdi
00007986e0ddb78f  push rsi
00007986e0ddb790  push r8
00007986e0ddb792  push r9
00007986e0ddb794  push r10
00007986e0ddb796  push r11
00007986e0ddb798  sub rsp, 0xF0
00007986e0ddb79f  vmovaps [rsp], xmm0
00007986e0ddb7a4  vmovaps [rsp+0x10], xmm2
00007986e0ddb7aa  vmovaps [rsp+0x20], xmm3
00007986e0ddb7b0  vmovaps [rsp+0x30], xmm4
00007986e0ddb7b6  vmovaps [rsp+0x40], xmm5
00007986e0ddb7bc  vmovaps [rsp+0x50], xmm6
00007986e0ddb7c2  vmovaps [rsp+0x60], xmm7
00007986e0ddb7c8  vmovaps [rsp+0x70], xmm8
00007986e0ddb7ce  vmovaps [rsp+0x80], xmm9
00007986e0ddb7d7  vmovaps [rsp+0x90], xmm10
00007986e0ddb7e0  vmovaps [rsp+0xA0], xmm11
00007986e0ddb7e9  vmovaps [rsp+0xB0], xmm12
00007986e0ddb7f2  vmovaps [rsp+0xC0], xmm13
00007986e0ddb7fb  vmovaps [rsp+0xD0], xmm14
00007986e0ddb804  vmovaps [rsp+0xE0], xmm15
00007986e0ddb80d  sub rsp, 0x30
00007986e0ddb811  movaps [rsp], xmm1
00007986e0ddb815  movaps [rsp+0x10], xmm8
00007986e0ddb81b  movaps [rsp+0x20], xmm9
00007986e0ddb821  lea rdi, [rsp]
00007986e0ddb825  mov esi, 0x00
00007986e0ddb82a  mov rax, 0x5652C689F530
00007986e0ddb834  call rax
00007986e0ddb836  movaps xmm1, [rsp]
00007986e0ddb83a  add rsp, 0x30
00007986e0ddb83e  vmovaps xmm0, [rsp]
00007986e0ddb843  vmovaps xmm2, [rsp+0x10]
00007986e0ddb849  vmovaps xmm3, [rsp+0x20]
00007986e0ddb84f  vmovaps xmm4, [rsp+0x30]
00007986e0ddb855  vmovaps xmm5, [rsp+0x40]
00007986e0ddb85b  vmovaps xmm6, [rsp+0x50]
00007986e0ddb861  vmovaps xmm7, [rsp+0x60]
00007986e0ddb867  vmovaps xmm8, [rsp+0x70]
00007986e0ddb86d  vmovaps xmm9, [rsp+0x80]
00007986e0ddb876  vmovaps xmm10, [rsp+0x90]
00007986e0ddb87f  vmovaps xmm11, [rsp+0xA0]
00007986e0ddb888  vmovaps xmm12, [rsp+0xB0]
00007986e0ddb891  vmovaps xmm13, [rsp+0xC0]
00007986e0ddb89a  vmovaps xmm14, [rsp+0xD0]
00007986e0ddb8a3  vmovaps xmm15, [rsp+0xE0]
00007986e0ddb8ac  add rsp, 0xF0
00007986e0ddb8b3  pop r11
00007986e0ddb8b5  pop r10
00007986e0ddb8b7  pop r9
00007986e0ddb8b9  pop r8
00007986e0ddb8bb  pop rsi
00007986e0ddb8bc  pop rdi
00007986e0ddb8bd  pop rdx
00007986e0ddb8be  pop rcx
00007986e0ddb8bf  pop rax
00007986e0ddb8c0  add rsp, 0x08
00007986e0ddb8c4  jmp 0x00007986E0DD66B2
00007986e0ddb8c9  call 0x00007986E0CB3E40
00007986e0ddb8ce  jmp 0x00007986E0DD66C0
00007986e0ddb8d3  call 0x00007986E0C0C380
00007986e0ddb8d8  jmp 0x00007986E0DD66CA
00007986e0ddb8dd  call 0x00007986E0C0D600
00007986e0ddb8e2  jmp 0x00007986E0DD66D4
00007986e0ddb8e7  call 0x00007986E0BFF540
00007986e0ddb8ec  jmp 0x00007986E0DD66DE
00007986e0ddb8f1  int3
00007986e0ddb8f2  nop [rax+rax*1], ax
00007986e0ddb8fb  nop [rax+rax*1], eax
00007986e0ddb900  mov eax, [r15+0x48]
00007986e0ddb904  lea r14d, [eax+0x01]
00007986e0ddb909  mov [rsp+0x10], r14d
00007986e0ddb90e  mov r14d, r14d
00007986e0ddb911  mov [r15+0x48], r14
00007986e0ddb915  xor eax, eax
00007986e0ddb917  mov r14d, [rsp+0x10]
00007986e0ddb91c  cmp r14d, 0x1F4
00007986e0ddb923  cmc
00007986e0ddb924  lahf
00007986e0ddb925  seto al
00007986e0ddb928  mov [r15+0x108], eax
00007986e0ddb92f  mov eax, [r15+0x108]
00007986e0ddb936  sahf
00007986e0ddb937  jnz 0x00007986E0DDB969
00007986e0ddb939  cmp dword ptr [r15+0x318], 0x00
00007986e0ddb941  jz 0x00007986E0DE1AB0
00007986e0ddb947  nop [rax+rax*1], ax
00007986e0ddb950  nop [rax+rax*1], eax
00007986e0ddb958  mov eax, 0x410450
00007986e0ddb95d  mov [r15+0x100], rax
00007986e0ddb964  jmp 0x00007986E0BFE110
00007986e0ddb969  cmp dword ptr [r15+0x318], 0x00
00007986e0ddb971  jz 0x00007986E0DDB9A0
00007986e0ddb977  nop [rax+rax*1], ax
00007986e0ddb980  nop [rax+rax*1], eax
00007986e0ddb988  mov eax, 0x410274
00007986e0ddb98d  mov [r15+0x100], rax
00007986e0ddb994  jmp 0x00007986E0BFE110
00007986e0ddb999  int3
00007986e0ddb99a  int3
00007986e0ddb99b  nop [rax+rax*1], eax
00007986e0ddb9a0  mov rax, [r15+0x40]
00007986e0ddb9a4  movaps xmm1, [r15+0x1D0]
00007986e0ddb9ac  vmovaps [rsp+0x10], xmm1
00007986e0ddb9b2  vmovaps xmm15, [rsp+0x10]
00007986e0ddb9b8  por xmm1, xmm15
00007986e0ddb9bd  movaps xmm14, [r15+0x1A0]
00007986e0ddb9c5  vmovaps [rsp+0x10], xmm14
00007986e0ddb9cb  vmovaps xmm13, [rsp+0x10]
00007986e0ddb9d1  por xmm14, xmm13
00007986e0ddb9d6  lea r14, [rax+0x30]
00007986e0ddb9da  mov r12, [r13+r14*1]
00007986e0ddb9df  lea r14, [rax+0x38]
00007986e0ddb9e3  mov r11, [r13+r14*1]
00007986e0ddb9e8  movq xmm13, r12
00007986e0ddb9ed  movq xmm12, r11
00007986e0ddb9f2  movq xmm13, xmm13
00007986e0ddb9f7  vmovaps [rsp+0x10], xmm13
00007986e0ddb9fd  movq xmm13, xmm13
00007986e0ddba02  movaps [r15+0x130], xmm13
00007986e0ddba0a  movq xmm12, xmm12
00007986e0ddba0f  vmovaps [rsp+0x20], xmm12
00007986e0ddba15  movq xmm12, xmm12
00007986e0ddba1a  movaps [r15+0x280], xmm12
00007986e0ddba22  movaps xmm13, [r15+0x270]
00007986e0ddba2a  vmovaps [rsp+0x30], xmm13
00007986e0ddba30  vmovaps xmm12, [rsp+0x30]
00007986e0ddba36  por xmm13, xmm12
00007986e0ddba3b  lea r14, [rax+0x20]
00007986e0ddba3f  mov r12, [r13+r14*1]
00007986e0ddba44  lea r14, [rax+0x28]
00007986e0ddba48  mov r11, [r13+r14*1]
00007986e0ddba4d  movq xmm12, r12
00007986e0ddba52  movq xmm11, r11
00007986e0ddba57  movq xmm12, xmm12
00007986e0ddba5c  vmovaps [rsp+0x30], xmm12
00007986e0ddba62  movq xmm12, xmm12
00007986e0ddba67  movaps [r15+0x150], xmm12
00007986e0ddba6f  movq xmm11, xmm11
00007986e0ddba74  vmovaps [rsp+0x40], xmm11
00007986e0ddba7a  movq xmm11, xmm11
00007986e0ddba7f  movaps [r15+0x140], xmm11
00007986e0ddba87  lea r14, [rax+0x10]
00007986e0ddba8b  mov r12, [r13+r14*1]
00007986e0ddba90  lea r14, [rax+0x18]
00007986e0ddba94  mov r11, [r13+r14*1]
00007986e0ddba99  movq xmm12, r12
00007986e0ddba9e  movq xmm11, r11
00007986e0ddbaa3  movq xmm12, xmm12
00007986e0ddbaa8  vmovaps [rsp+0x50], xmm12
00007986e0ddbaae  movq xmm12, xmm12
00007986e0ddbab3  movaps [r15+0x170], xmm12
00007986e0ddbabb  movq xmm11, xmm11
00007986e0ddbac0  vmovaps [rsp+0x60], xmm11
00007986e0ddbac6  movq xmm11, xmm11
00007986e0ddbacb  movaps [r15+0x160], xmm11
00007986e0ddbad3  mov r14, [r13+rax*1]
00007986e0ddbad8  vmovq xmm12, r14
00007986e0ddbadd  vpbroadcastq xmm12, xmm12
00007986e0ddbae2  lea r14, [rax+0x08]
00007986e0ddbae6  mov rax, [r13+r14*1]
00007986e0ddbaeb  movq xmm11, rax
00007986e0ddbaf0  movaps [r15+0x230], xmm11
00007986e0ddbaf8  mov rax, [r15+0xF8]
00007986e0ddbaff  lea r14, [rax+0x50]
00007986e0ddbb03  movups xmm11, [r13+r14*1]
00007986e0ddbb09  lea r14, [rax+0x60]
00007986e0ddbb0d  movups xmm10, [r13+r14*1]
00007986e0ddbb13  lea r14, [rax+0x30]
00007986e0ddbb17  movups xmm9, [r13+r14*1]
00007986e0ddbb1d  mov r14, [r15+0x50]
00007986e0ddbb21  mov [r15+0x60], r14
00007986e0ddbb25  mov qword ptr [r15+0x58], 0x40
00007986e0ddbb2d  movaps xmm8, xmm12
00007986e0ddbb31  mulpd xmm8, xmm15
00007986e0ddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007986e0ddbb3c  ptest xmm7, xmm7
00007986e0ddbb41  jnz 0x00007986E0DDC96A
00007986e0ddbb47  movq xmm15, qword ptr [r15+0x230]
00007986e0ddbb50  vmovaps [rsp+0x70], xmm15
00007986e0ddbb56  vpermilpd xmm15, xmm15, 0x00
00007986e0ddbb5c  movaps xmm7, xmm9
00007986e0ddbb60  mulpd xmm7, xmm15
00007986e0ddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007986e0ddbb6a  ptest xmm6, xmm6
00007986e0ddbb6f  jnz 0x00007986E0DDCAAE
00007986e0ddbb75  vxorps xmm15, xmm15, xmm15
00007986e0ddbb7a  vpbroadcastq xmm15, xmm15
00007986e0ddbb7f  movaps xmm9, xmm12
00007986e0ddbb83  mulpd xmm9, xmm10
00007986e0ddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007986e0ddbb8e  ptest xmm6, xmm6
00007986e0ddbb93  jnz 0x00007986E0DDCBF0
00007986e0ddbb99  movaps xmm10, xmm12
00007986e0ddbb9d  mulpd xmm10, xmm11
00007986e0ddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007986e0ddbba8  ptest xmm6, xmm6
00007986e0ddbbad  jnz 0x00007986E0DDCD34
00007986e0ddbbb3  movaps xmm11, [r15+0x1F0]
00007986e0ddbbbb  movaps xmm6, xmm12
00007986e0ddbbbf  mulpd xmm6, xmm11
00007986e0ddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007986e0ddbbc9  ptest xmm5, xmm5
00007986e0ddbbce  jnz 0x00007986E0DDCE78
00007986e0ddbbd4  movaps xmm12, [r15+0x2A0]
00007986e0ddbbdc  vmovaps [rsp+0x80], xmm12
00007986e0ddbbe5  vmovaps xmm11, [rsp+0x80]
00007986e0ddbbee  por xmm12, xmm11
00007986e0ddbbf3  movaps xmm11, [r15+0x250]
00007986e0ddbbfb  vmovaps [rsp+0x80], xmm11
00007986e0ddbc04  vmovaps xmm5, [rsp+0x80]
00007986e0ddbc0d  por xmm11, xmm5
00007986e0ddbc12  vmovaps xmm4, [rsp+0x70]
00007986e0ddbc18  vpermilpd xmm4, xmm4, 0x00
00007986e0ddbc1e  movaps xmm3, xmm5
00007986e0ddbc21  mulpd xmm3, xmm4
00007986e0ddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007986e0ddbc2a  ptest xmm2, xmm2
00007986e0ddbc2f  jnz 0x00007986E0DDCFBA
00007986e0ddbc35  mov [rsp+0x80], rax
00007986e0ddbc3d  xor eax, eax
00007986e0ddbc3f  mov r12d, 0x40
00007986e0ddbc45  mov r11d, 0x200
00007986e0ddbc4b  cmp r12, r11
00007986e0ddbc4e  cmc
00007986e0ddbc4f  lahf
00007986e0ddbc50  seto al
00007986e0ddbc53  mov [r15+0x108], eax
00007986e0ddbc5a  movaps xmm5, xmm8
00007986e0ddbc5e  addpd xmm5, xmm15
00007986e0ddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007986e0ddbc68  ptest xmm4, xmm4
00007986e0ddbc6d  jnz 0x00007986E0DDD0FA
00007986e0ddbc73  movaps xmm8, [r15+0x1B0]
00007986e0ddbc7b  movaps xmm4, xmm9
00007986e0ddbc7f  addpd xmm4, xmm8
00007986e0ddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007986e0ddbc89  ptest xmm2, xmm2
00007986e0ddbc8e  jnz 0x00007986E0DDD23C
00007986e0ddbc94  movaps xmm9, xmm10
00007986e0ddbc98  addpd xmm9, xmm8
00007986e0ddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007986e0ddbca3  ptest xmm2, xmm2
00007986e0ddbca8  jnz 0x00007986E0DDD37E
00007986e0ddbcae  movaps xmm10, [r15+0x2F0]
00007986e0ddbcb6  vmovaps [rsp+0x90], xmm10
00007986e0ddbcbf  vmovaps xmm8, [rsp+0x90]
00007986e0ddbcc8  por xmm10, xmm8
00007986e0ddbccd  movaps xmm8, [r15+0x2E0]
00007986e0ddbcd5  vmovaps [rsp+0x90], xmm8
00007986e0ddbcde  vmovaps xmm2, [rsp+0x90]
00007986e0ddbce7  por xmm8, xmm2
00007986e0ddbcec  movaps xmm2, [r15+0x2D0]
00007986e0ddbcf4  vmovaps [rsp+0x90], xmm2
00007986e0ddbcfd  vmovaps [rsp+0xA0], xmm1
00007986e0ddbd06  vmovaps xmm1, [rsp+0x90]
00007986e0ddbd0f  por xmm2, xmm1
00007986e0ddbd13  movaps xmm1, [r15+0x200]
00007986e0ddbd1b  vmovaps [rsp+0x90], xmm1
00007986e0ddbd24  vmovaps [rsp+0xB0], xmm15
00007986e0ddbd2d  vmovaps xmm15, [rsp+0x90]
00007986e0ddbd36  por xmm1, xmm15
00007986e0ddbd3b  movaps xmm15, [r15+0x1C0]
00007986e0ddbd43  vmovaps [rsp+0x90], xmm15
00007986e0ddbd4c  vmovaps [rsp+0xC0], xmm1
00007986e0ddbd55  vmovaps xmm1, [rsp+0x90]
00007986e0ddbd5e  por xmm15, xmm1
00007986e0ddbd63  movaps xmm1, [r15+0x190]
00007986e0ddbd6b  vmovaps [rsp+0x90], xmm1
00007986e0ddbd74  vmovaps [rsp+0xD0], xmm15
00007986e0ddbd7d  vmovaps xmm15, [rsp+0x90]
00007986e0ddbd86  por xmm1, xmm15
00007986e0ddbd8b  movaps xmm15, [r15+0x300]
00007986e0ddbd93  vmovaps [rsp+0x90], xmm15
00007986e0ddbd9c  vmovaps [rsp+0xE0], xmm1
00007986e0ddbda5  vmovaps xmm1, [rsp+0x90]
00007986e0ddbdae  por xmm15, xmm1
00007986e0ddbdb3  mov rax, [rsp+0x80]
00007986e0ddbdbb  lea r12, [rax+0xA0]
00007986e0ddbdc2  movups xmm1, [r13+r12*1]
00007986e0ddbdc8  lea r12, [rax+0xB0]
00007986e0ddbdcf  vmovaps [rsp+0x80], xmm1
00007986e0ddbdd8  movups xmm1, [r13+r12*1]
00007986e0ddbdde  vmovaps [rsp+0x90], xmm1
00007986e0ddbde7  vmovaps [rsp+0xF0], xmm15
00007986e0ddbdf0  vmovaps xmm15, [rsp+0xB0]
00007986e0ddbdf9  vmovaps [rsp+0xB0], xmm14
00007986e0ddbe02  movaps xmm1, xmm6
00007986e0ddbe05  addpd xmm1, xmm15
00007986e0ddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007986e0ddbe0f  ptest xmm14, xmm14
00007986e0ddbe15  jnz 0x00007986E0DDD4D6
00007986e0ddbe1b  lea r12, [rax+0xF0]
00007986e0ddbe22  movups xmm15, [r13+r12*1]
00007986e0ddbe28  movaps xmm14, xmm4
00007986e0ddbe2c  addpd xmm14, xmm3
00007986e0ddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007986e0ddbe37  ptest xmm6, xmm6
00007986e0ddbe3c  jnz 0x00007986E0DDD621
00007986e0ddbe42  movaps xmm6, xmm9
00007986e0ddbe46  addpd xmm6, xmm7
00007986e0ddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007986e0ddbe4f  ptest xmm4, xmm4
00007986e0ddbe54  jnz 0x00007986E0DDD763
00007986e0ddbe5a  vmovaps xmm9, [rsp+0x70]
00007986e0ddbe60  vpermilpd xmm9, xmm9, 0x00
00007986e0ddbe66  vmovaps xmm4, [rsp+0x90]
00007986e0ddbe6f  movaps xmm7, xmm4
00007986e0ddbe72  mulpd xmm7, xmm9
00007986e0ddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007986e0ddbe7c  ptest xmm3, xmm3
00007986e0ddbe81  jnz 0x00007986E0DDD8A4
00007986e0ddbe87  vmovaps xmm9, [rsp+0x50]
00007986e0ddbe8d  vpermilpd xmm9, xmm9, 0x00
00007986e0ddbe93  movaps xmm4, xmm15
00007986e0ddbe97  mulpd xmm4, xmm9
00007986e0ddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007986e0ddbea1  ptest xmm3, xmm3
00007986e0ddbea6  jnz 0x00007986E0DDD9E5
00007986e0ddbeac  lea r12, [rax+0xE0]
00007986e0ddbeb3  movups xmm15, [r13+r12*1]
00007986e0ddbeb9  vmovaps xmm9, [rsp+0x70]
00007986e0ddbebf  vpermilpd xmm9, xmm9, 0x00
00007986e0ddbec5  vmovaps [rsp+0x70], xmm1
00007986e0ddbecb  vmovaps xmm1, [rsp+0x80]
00007986e0ddbed4  vmovaps [rsp+0x80], xmm15
00007986e0ddbedd  movaps xmm3, xmm1
00007986e0ddbee0  mulpd xmm3, xmm9
00007986e0ddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007986e0ddbeea  ptest xmm15, xmm15
00007986e0ddbef0  jnz 0x00007986E0DDDB31
00007986e0ddbef6  vmovaps xmm1, [rsp+0xF0]
00007986e0ddbeff  vmovaps xmm15, [rsp+0xF0]
00007986e0ddbf08  por xmm1, xmm15
00007986e0ddbf0d  movaps [r15+0x300], xmm1
00007986e0ddbf15  vmovaps xmm15, [rsp+0xE0]
00007986e0ddbf1e  vmovaps xmm9, [rsp+0xE0]
00007986e0ddbf27  por xmm15, xmm9
00007986e0ddbf2c  movaps [r15+0x190], xmm15
00007986e0ddbf34  vmovaps xmm9, [rsp+0x50]
00007986e0ddbf3a  vpermilpd xmm9, xmm9, 0x00
00007986e0ddbf40  vmovaps [rsp+0x90], xmm1
00007986e0ddbf49  vmovaps [rsp+0xE0], xmm15
00007986e0ddbf52  vmovaps xmm15, [rsp+0x80]
00007986e0ddbf5b  vmovaps [rsp+0x80], xmm14
00007986e0ddbf64  movaps xmm1, xmm15
00007986e0ddbf68  mulpd xmm1, xmm9
00007986e0ddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007986e0ddbf72  ptest xmm14, xmm14
00007986e0ddbf78  jnz 0x00007986E0DDDC72
00007986e0ddbf7e  lea r12, [rax+0x90]
00007986e0ddbf85  movups xmm15, [r13+r12*1]
00007986e0ddbf8b  vmovaps xmm14, [rsp+0xD0]
00007986e0ddbf94  vmovaps xmm9, [rsp+0xD0]
00007986e0ddbf9d  por xmm14, xmm9
00007986e0ddbfa2  movaps [r15+0x1C0], xmm14
00007986e0ddbfaa  vmovaps xmm9, [rsp+0xC0]
00007986e0ddbfb3  vmovaps [rsp+0xD0], xmm1
00007986e0ddbfbc  vmovaps xmm1, [rsp+0xC0]
00007986e0ddbfc5  por xmm9, xmm1
00007986e0ddbfca  movaps [r15+0x200], xmm9
00007986e0ddbfd2  vmovaps [rsp+0xC0], xmm2
00007986e0ddbfdb  vmovaps xmm1, [rsp+0xC0]
00007986e0ddbfe4  por xmm2, xmm1
00007986e0ddbfe8  movaps [r15+0x2D0], xmm2
00007986e0ddbff0  vmovaps [rsp+0xC0], xmm8
00007986e0ddbff9  vmovaps xmm1, [rsp+0xC0]
00007986e0ddc002  por xmm8, xmm1
00007986e0ddc007  movaps [r15+0x2E0], xmm8
00007986e0ddc00f  vmovaps [rsp+0xC0], xmm15
00007986e0ddc018  movaps xmm1, xmm5
00007986e0ddc01b  addpd xmm1, xmm7
00007986e0ddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007986e0ddc024  ptest xmm15, xmm15
00007986e0ddc02a  jnz 0x00007986E0DDDDBE
00007986e0ddc030  vmovaps xmm15, [rsp+0x50]
00007986e0ddc036  vpermilpd xmm15, xmm15, 0x00
00007986e0ddc03c  vmovaps xmm5, [rsp+0xC0]
00007986e0ddc045  vmovaps [rsp+0xC0], xmm1
00007986e0ddc04e  movaps xmm7, xmm5
00007986e0ddc051  mulpd xmm7, xmm15
00007986e0ddc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007986e0ddc05b  ptest xmm1, xmm1
00007986e0ddc060  jnz 0x00007986E0DDDEFE
00007986e0ddc066  lea r12, [rax+0x80]
00007986e0ddc06d  movups xmm1, [r13+r12*1]
00007986e0ddc073  vmovaps xmm5, [rsp+0x70]
00007986e0ddc079  vmovaps [rsp+0x70], xmm1
00007986e0ddc07f  movaps xmm15, xmm5
00007986e0ddc083  addpd xmm15, xmm3
00007986e0ddc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007986e0ddc08e  ptest xmm1, xmm1
00007986e0ddc093  jnz 0x00007986E0DDE049
00007986e0ddc099  vmovaps xmm5, [rsp+0x80]
00007986e0ddc0a2  movaps xmm1, xmm5
00007986e0ddc0a5  addpd xmm1, xmm4
00007986e0ddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007986e0ddc0ae  ptest xmm3, xmm3
00007986e0ddc0b3  jnz 0x00007986E0DDE18B
00007986e0ddc0b9  vmovaps [rsp+0x80], xmm10
00007986e0ddc0c2  vmovaps xmm5, [rsp+0x80]
00007986e0ddc0cb  por xmm10, xmm5
00007986e0ddc0d0  movaps [r15+0x2F0], xmm10
00007986e0ddc0d8  vmovaps xmm5, [rsp+0x50]
00007986e0ddc0de  vpermilpd xmm5, xmm5, 0x00
00007986e0ddc0e4  vmovaps xmm3, [rsp+0x70]
00007986e0ddc0ea  vmovaps [rsp+0x50], xmm1
00007986e0ddc0f0  movaps xmm4, xmm3
00007986e0ddc0f3  mulpd xmm4, xmm5
00007986e0ddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007986e0ddc0fc  ptest xmm1, xmm1
00007986e0ddc101  jnz 0x00007986E0DDE2CB
00007986e0ddc107  lea r12, [rax+0xD0]
00007986e0ddc10e  movups xmm1, [r13+r12*1]
00007986e0ddc114  vmovaps xmm3, [rsp+0xD0]
00007986e0ddc11d  vmovaps [rsp+0x70], xmm1
00007986e0ddc123  movaps xmm5, xmm6
00007986e0ddc126  addpd xmm5, xmm3
00007986e0ddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007986e0ddc12f  ptest xmm1, xmm1
00007986e0ddc134  jnz 0x00007986E0DDE415
00007986e0ddc13a  vmovaps xmm1, [rsp+0x60]
00007986e0ddc140  vpermilpd xmm1, xmm1, 0x00
00007986e0ddc146  movaps xmm6, xmm9
00007986e0ddc14a  mulpd xmm6, xmm1
00007986e0ddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007986e0ddc153  ptest xmm3, xmm3
00007986e0ddc158  jnz 0x00007986E0DDE555
00007986e0ddc15e  movaps [r15+0x260], xmm6
00007986e0ddc166  vxorps xmm1, xmm1, xmm1
00007986e0ddc16a  vpbroadcastq xmm1, xmm1
00007986e0ddc16f  movaps [r15+0x1B0], xmm1
00007986e0ddc177  vmovaps xmm1, [rsp+0x60]
00007986e0ddc17d  vpermilpd xmm1, xmm1, 0x00
00007986e0ddc183  vmovaps xmm3, [rsp+0x70]
00007986e0ddc189  vmovaps [rsp+0x70], xmm15
00007986e0ddc18f  movaps xmm9, xmm3
00007986e0ddc193  mulpd xmm9, xmm1
00007986e0ddc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007986e0ddc19e  ptest xmm15, xmm15
00007986e0ddc1a4  jnz 0x00007986E0DDE696
00007986e0ddc1aa  lea r12, [rax+0xC0]
00007986e0ddc1b1  movups xmm1, [r13+r12*1]
00007986e0ddc1b7  vmovaps xmm3, [rsp+0xC0]
00007986e0ddc1c0  vmovaps [rsp+0x80], xmm1
00007986e0ddc1c9  movaps xmm15, xmm3
00007986e0ddc1cd  addpd xmm15, xmm7
00007986e0ddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007986e0ddc1d8  ptest xmm1, xmm1
00007986e0ddc1dd  jnz 0x00007986E0DDE7E2
00007986e0ddc1e3  vmovaps [rsp+0xC0], xmm13
00007986e0ddc1ec  vmovaps xmm1, [rsp+0xC0]
00007986e0ddc1f5  por xmm13, xmm1
00007986e0ddc1fa  movaps [r15+0x270], xmm13
00007986e0ddc202  vmovaps xmm1, [rsp+0xB0]
00007986e0ddc20b  vmovaps xmm7, [rsp+0xB0]
00007986e0ddc214  por xmm1, xmm7
00007986e0ddc218  movaps [r15+0x1A0], xmm1
00007986e0ddc220  vmovaps xmm1, [rsp+0x60]
00007986e0ddc226  vpermilpd xmm1, xmm1, 0x00
00007986e0ddc22c  vmovaps [rsp+0xB0], xmm1
00007986e0ddc235  vmovaps xmm1, [rsp+0x80]
00007986e0ddc23e  vmovaps [rsp+0x80], xmm15
00007986e0ddc247  vmovaps xmm15, [rsp+0xB0]
00007986e0ddc250  vmovaps [rsp+0xB0], xmm14
00007986e0ddc259  movaps xmm3, xmm1
00007986e0ddc25c  mulpd xmm3, xmm15
00007986e0ddc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007986e0ddc266  ptest xmm14, xmm14
00007986e0ddc26c  jnz 0x00007986E0DDE924
00007986e0ddc272  lea r12, [rax+0x20]
00007986e0ddc276  movups xmm1, [r13+r12*1]
00007986e0ddc27c  movaps [r15+0x110], xmm1
00007986e0ddc284  vmovaps xmm14, [rsp+0x70]
00007986e0ddc28a  vmovaps [rsp+0x70], xmm1
00007986e0ddc290  movaps xmm15, xmm14
00007986e0ddc294  addpd xmm15, xmm4
00007986e0ddc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007986e0ddc29f  ptest xmm1, xmm1
00007986e0ddc2a4  jnz 0x00007986E0DDEA6F
00007986e0ddc2aa  vmovaps xmm1, [rsp+0x60]
00007986e0ddc2b0  vpermilpd xmm1, xmm1, 0x00
00007986e0ddc2b6  movaps xmm14, xmm2
00007986e0ddc2ba  mulpd xmm14, xmm1
00007986e0ddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007986e0ddc2c5  ptest xmm4, xmm4
00007986e0ddc2ca  jnz 0x00007986E0DDEBB2
00007986e0ddc2d0  vmovaps xmm4, [rsp+0x50]
00007986e0ddc2d6  movaps xmm1, xmm4
00007986e0ddc2d9  addpd xmm1, xmm9
00007986e0ddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007986e0ddc2e3  ptest xmm2, xmm2
00007986e0ddc2e8  jnz 0x00007986E0DDECF4
00007986e0ddc2ee  vmovaps xmm9, [rsp+0x30]
00007986e0ddc2f4  vpermilpd xmm9, xmm9, 0x00
00007986e0ddc2fa  vmovaps xmm2, [rsp+0x70]
00007986e0ddc300  vmovaps [rsp+0x50], xmm1
00007986e0ddc306  movaps xmm4, xmm2
00007986e0ddc309  mulpd xmm4, xmm9
00007986e0ddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007986e0ddc313  ptest xmm1, xmm1
00007986e0ddc318  jnz 0x00007986E0DDEE35
00007986e0ddc31e  vmovaps xmm1, [rsp+0x30]
00007986e0ddc324  vpermilpd xmm1, xmm1, 0x00
00007986e0ddc32a  vmovaps xmm2, [rsp+0x90]
00007986e0ddc333  vmovaps [rsp+0x60], xmm15
00007986e0ddc339  movaps xmm9, xmm2
00007986e0ddc33d  mulpd xmm9, xmm1
00007986e0ddc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007986e0ddc348  ptest xmm15, xmm15
00007986e0ddc34e  jnz 0x00007986E0DDEF76
00007986e0ddc354  vmovaps xmm15, [rsp+0x80]
00007986e0ddc35d  movaps xmm1, xmm15
00007986e0ddc361  addpd xmm1, xmm6
00007986e0ddc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007986e0ddc36a  ptest xmm2, xmm2
00007986e0ddc36f  jnz 0x00007986E0DDF0B8
00007986e0ddc375  movaps xmm15, xmm5
00007986e0ddc379  addpd xmm15, xmm3
00007986e0ddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007986e0ddc384  ptest xmm6, xmm6
00007986e0ddc389  jnz 0x00007986E0DDF1F9
00007986e0ddc38f  vmovaps xmm6, [rsp+0x30]
00007986e0ddc395  vpermilpd xmm6, xmm6, 0x00
00007986e0ddc39b  movaps xmm5, xmm8
00007986e0ddc39f  mulpd xmm5, xmm6
00007986e0ddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007986e0ddc3a8  ptest xmm3, xmm3
00007986e0ddc3ad  jnz 0x00007986E0DDF33B
00007986e0ddc3b3  vmovaps xmm8, [rsp+0x30]
00007986e0ddc3b9  vpermilpd xmm8, xmm8, 0x00
00007986e0ddc3bf  movaps xmm6, xmm10
00007986e0ddc3c3  mulpd xmm6, xmm8
00007986e0ddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007986e0ddc3cd  ptest xmm3, xmm3
00007986e0ddc3d2  jnz 0x00007986E0DDF47C
00007986e0ddc3d8  vmovaps xmm8, [rsp+0x60]
00007986e0ddc3de  movaps xmm10, xmm8
00007986e0ddc3e2  addpd xmm10, xmm14
00007986e0ddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007986e0ddc3ed  ptest xmm3, xmm3
00007986e0ddc3f2  jnz 0x00007986E0DDF5BE
00007986e0ddc3f8  vmovaps xmm8, [rsp+0x50]
00007986e0ddc3fe  movaps xmm14, xmm8
00007986e0ddc402  addpd xmm14, xmm4
00007986e0ddc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007986e0ddc40d  ptest xmm3, xmm3
00007986e0ddc412  jnz 0x00007986E0DDF702
00007986e0ddc418  vmovaps xmm8, [rsp+0x40]
00007986e0ddc41e  vpermilpd xmm8, xmm8, 0x00
00007986e0ddc424  movaps xmm4, xmm13
00007986e0ddc428  mulpd xmm4, xmm8
00007986e0ddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007986e0ddc432  ptest xmm3, xmm3
00007986e0ddc437  jnz 0x00007986E0DDF845
00007986e0ddc43d  movaps xmm13, xmm15
00007986e0ddc441  addpd xmm13, xmm9
00007986e0ddc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007986e0ddc44c  ptest xmm8, xmm8
00007986e0ddc452  jnz 0x00007986E0DDF987
00007986e0ddc458  movaps xmm15, xmm1
00007986e0ddc45c  addpd xmm15, xmm5
00007986e0ddc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007986e0ddc467  ptest xmm9, xmm9
00007986e0ddc46d  jnz 0x00007986E0DDFACB
00007986e0ddc473  vmovaps [rsp+0x30], xmm11
00007986e0ddc479  vmovaps xmm1, [rsp+0x30]
00007986e0ddc47f  por xmm11, xmm1
00007986e0ddc484  movaps [r15+0x250], xmm11
00007986e0ddc48c  vmovaps [rsp+0x30], xmm12
00007986e0ddc492  vmovaps xmm1, [rsp+0x30]
00007986e0ddc498  por xmm12, xmm1
00007986e0ddc49d  movaps [r15+0x2A0], xmm12
00007986e0ddc4a5  vmovaps xmm1, [rsp+0xA0]
00007986e0ddc4ae  vmovaps xmm11, [rsp+0xA0]
00007986e0ddc4b7  por xmm1, xmm11
00007986e0ddc4bc  movaps [r15+0x1D0], xmm1
00007986e0ddc4c4  lea r12, [rax+0x40]
00007986e0ddc4c8  movups xmm1, [r13+r12*1]
00007986e0ddc4ce  movaps [r15+0x2C0], xmm1
00007986e0ddc4d6  vmovaps xmm11, [rsp+0x40]
00007986e0ddc4dc  vpermilpd xmm11, xmm11, 0x00
00007986e0ddc4e2  vmovaps xmm8, [rsp+0xE0]
00007986e0ddc4eb  movaps xmm9, xmm8
00007986e0ddc4ef  mulpd xmm9, xmm11
00007986e0ddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007986e0ddc4fa  ptest xmm5, xmm5
00007986e0ddc4ff  jnz 0x00007986E0DDFC17
00007986e0ddc505  movaps xmm11, xmm10
00007986e0ddc509  addpd xmm11, xmm6
00007986e0ddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007986e0ddc514  ptest xmm8, xmm8
00007986e0ddc51a  jnz 0x00007986E0DDFD5B
00007986e0ddc520  movaps xmm10, xmm14
00007986e0ddc524  addpd xmm10, xmm4
00007986e0ddc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007986e0ddc52f  ptest xmm8, xmm8
00007986e0ddc535  jnz 0x00007986E0DDFE9E
00007986e0ddc53b  vmovaps xmm14, [rsp+0x40]
00007986e0ddc541  vpermilpd xmm14, xmm14, 0x00
00007986e0ddc547  movaps xmm8, xmm1
00007986e0ddc54b  mulpd xmm8, xmm14
00007986e0ddc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007986e0ddc556  ptest xmm6, xmm6
00007986e0ddc55b  jnz 0x00007986E0DDFFE1
00007986e0ddc561  movaps xmm1, [r15+0x2B0]
00007986e0ddc569  vmovaps xmm14, [rsp+0x40]
00007986e0ddc56f  vpermilpd xmm14, xmm14, 0x00
00007986e0ddc575  movaps xmm6, xmm1
00007986e0ddc578  mulpd xmm6, xmm14
00007986e0ddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007986e0ddc582  ptest xmm5, xmm5
00007986e0ddc587  jnz 0x00007986E0DE0124
00007986e0ddc58d  vmovaps xmm1, [rsp+0x10]
00007986e0ddc593  vpermilpd xmm1, xmm1, 0x00
00007986e0ddc599  movaps xmm14, xmm12
00007986e0ddc59d  mulpd xmm14, xmm1
00007986e0ddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007986e0ddc5a8  ptest xmm5, xmm5
00007986e0ddc5ad  jnz 0x00007986E0DE0265
00007986e0ddc5b3  movaps xmm1, xmm13
00007986e0ddc5b7  addpd xmm1, xmm9
00007986e0ddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007986e0ddc5c1  ptest xmm12, xmm12
00007986e0ddc5c7  jnz 0x00007986E0DE03A8
00007986e0ddc5cd  vmovaps xmm13, [rsp+0x10]
00007986e0ddc5d3  vpermilpd xmm13, xmm13, 0x00
00007986e0ddc5d9  movaps xmm12, xmm7
00007986e0ddc5dd  mulpd xmm12, xmm13
00007986e0ddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007986e0ddc5e8  ptest xmm9, xmm9
00007986e0ddc5ee  jnz 0x00007986E0DE04EA
00007986e0ddc5f4  movaps xmm13, xmm15
00007986e0ddc5f8  addpd xmm13, xmm8
00007986e0ddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007986e0ddc603  ptest xmm9, xmm9
00007986e0ddc609  jnz 0x00007986E0DE062D
00007986e0ddc60f  movaps xmm15, [r15+0x290]
00007986e0ddc617  vmovaps xmm9, [rsp+0x10]
00007986e0ddc61d  vpermilpd xmm9, xmm9, 0x00
00007986e0ddc623  movaps xmm8, xmm15
00007986e0ddc627  mulpd xmm8, xmm9
00007986e0ddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007986e0ddc632  ptest xmm7, xmm7
00007986e0ddc637  jnz 0x00007986E0DE0771
00007986e0ddc63d  movaps xmm15, xmm11
00007986e0ddc641  addpd xmm15, xmm6
00007986e0ddc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007986e0ddc64c  ptest xmm9, xmm9
00007986e0ddc652  jnz 0x00007986E0DE08B5
00007986e0ddc658  movaps xmm11, [r15+0x1E0]
00007986e0ddc660  vmovaps xmm9, [rsp+0x10]
00007986e0ddc666  vpermilpd xmm9, xmm9, 0x00
00007986e0ddc66c  movaps xmm7, xmm11
00007986e0ddc670  mulpd xmm7, xmm9
00007986e0ddc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007986e0ddc67a  ptest xmm6, xmm6
00007986e0ddc67f  jnz 0x00007986E0DE09F8
00007986e0ddc685  movaps xmm11, xmm10
00007986e0ddc689  addpd xmm11, xmm14
00007986e0ddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007986e0ddc694  ptest xmm9, xmm9
00007986e0ddc69a  jnz 0x00007986E0DE0B3A
00007986e0ddc6a0  lea r12, [rax+0x70]
00007986e0ddc6a4  movups xmm14, [r13+r12*1]
00007986e0ddc6aa  movaps [r15+0x240], xmm14
00007986e0ddc6b2  movaps xmm10, xmm1
00007986e0ddc6b6  addpd xmm10, xmm12
00007986e0ddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007986e0ddc6c1  ptest xmm9, xmm9
00007986e0ddc6c7  jnz 0x00007986E0DE0C88
00007986e0ddc6cd  movaps [r15+0x170], xmm10
00007986e0ddc6d5  vmovaps xmm1, [rsp+0x20]
00007986e0ddc6db  vpermilpd xmm1, xmm1, 0x00
00007986e0ddc6e1  movaps xmm12, xmm14
00007986e0ddc6e5  mulpd xmm12, xmm1
00007986e0ddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007986e0ddc6f0  ptest xmm9, xmm9
00007986e0ddc6f6  jnz 0x00007986E0DE0DCB
00007986e0ddc6fc  vmovaps xmm1, [rsp+0x20]
00007986e0ddc702  vpermilpd xmm1, xmm1, 0x00
00007986e0ddc708  vmovaps xmm9, [rsp+0xB0]
00007986e0ddc711  movaps xmm14, xmm9
00007986e0ddc715  mulpd xmm14, xmm1
00007986e0ddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007986e0ddc720  ptest xmm6, xmm6
00007986e0ddc725  jnz 0x00007986E0DE0F0E
00007986e0ddc72b  movaps [r15+0x180], xmm14
00007986e0ddc733  movaps xmm1, xmm13
00007986e0ddc737  addpd xmm1, xmm8
00007986e0ddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007986e0ddc741  ptest xmm9, xmm9
00007986e0ddc747  jnz 0x00007986E0DE1051
00007986e0ddc74d  movaps [r15+0x210], xmm1
00007986e0ddc755  movups xmm13, [r13+rax*1]
00007986e0ddc75b  lea r12, [rax+0x10]
00007986e0ddc75f  movups xmm9, [r13+r12*1]
00007986e0ddc765  movaps [r15+0x230], xmm9
00007986e0ddc76d  movaps xmm8, xmm15
00007986e0ddc771  addpd xmm8, xmm7
00007986e0ddc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007986e0ddc77c  ptest xmm6, xmm6
00007986e0ddc781  jnz 0x00007986E0DE11A7
00007986e0ddc787  movaps [r15+0x130], xmm8
00007986e0ddc78f  vmovaps xmm15, [rsp+0x20]
00007986e0ddc795  vpermilpd xmm15, xmm15, 0x00
00007986e0ddc79b  movaps xmm7, xmm9
00007986e0ddc79f  mulpd xmm7, xmm15
00007986e0ddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007986e0ddc7a9  ptest xmm6, xmm6
00007986e0ddc7ae  jnz 0x00007986E0DE12EA
00007986e0ddc7b4  movaps [r15+0x220], xmm7
00007986e0ddc7bc  vmovaps xmm15, [rsp+0x20]
00007986e0ddc7c2  vpermilpd xmm15, xmm15, 0x00
00007986e0ddc7c8  movaps xmm9, xmm13
00007986e0ddc7cc  mulpd xmm9, xmm15
00007986e0ddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007986e0ddc7d7  ptest xmm6, xmm6
00007986e0ddc7dc  jnz 0x00007986E0DE142C
00007986e0ddc7e2  movaps xmm15, xmm11
00007986e0ddc7e6  addpd xmm15, xmm12
00007986e0ddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007986e0ddc7f1  ptest xmm13, xmm13
00007986e0ddc7f7  jnz 0x00007986E0DE1570
00007986e0ddc7fd  movaps [r15+0x140], xmm15
00007986e0ddc805  movaps xmm13, xmm10
00007986e0ddc809  addpd xmm13, xmm14
00007986e0ddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007986e0ddc814  ptest xmm12, xmm12
00007986e0ddc81a  jnz 0x00007986E0DE16B4
00007986e0ddc820  movaps [r15+0x150], xmm13
00007986e0ddc828  movaps xmm14, xmm1
00007986e0ddc82c  addpd xmm14, xmm7
00007986e0ddc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007986e0ddc837  ptest xmm12, xmm12
00007986e0ddc83d  jnz 0x00007986E0DE17F8
00007986e0ddc843  movaps [r15+0x160], xmm14
00007986e0ddc84b  movaps xmm1, xmm8
00007986e0ddc84f  addpd xmm1, xmm9
00007986e0ddc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007986e0ddc859  ptest xmm12, xmm12
00007986e0ddc85f  jnz 0x00007986E0DE193A
00007986e0ddc865  movaps [r15+0x120], xmm1
00007986e0ddc86d  movups [r13+r14*1], xmm15
00007986e0ddc873  lea rax, [r14+0x10]
00007986e0ddc877  movups [r13+rax*1], xmm13
00007986e0ddc87d  lea rax, [r14+0x20]
00007986e0ddc881  movups [r13+rax*1], xmm14
00007986e0ddc887  lea rax, [r14+0x30]
00007986e0ddc88b  movups [r13+rax*1], xmm1
00007986e0ddc891  mov eax, [r15+0x108]
00007986e0ddc898  sahf
00007986e0ddc899  jnz 0x00007986E0DDC8CB
00007986e0ddc89b  cmp dword ptr [r15+0x318], 0x00
00007986e0ddc8a3  jz 0x00007986E0DDB900
00007986e0ddc8a9  nop [rax+rax*1], ax
00007986e0ddc8b2  nop [rax+rax*1], eax
00007986e0ddc8ba  mov eax, 0x410444
00007986e0ddc8bf  mov [r15+0x100], rax
00007986e0ddc8c6  jmp 0x00007986E0BFE110
00007986e0ddc8cb  cmp dword ptr [r15+0x318], 0x00
00007986e0ddc8d3  jz 0x00007986E0DD57E0
00007986e0ddc8d9  nop [rax+rax*1], ax
00007986e0ddc8e2  nop [rax+rax*1], eax
00007986e0ddc8ea  mov eax, 0x410278
00007986e0ddc8ef  mov [r15+0x100], rax
00007986e0ddc8f6  jmp 0x00007986E0BFE110
00007986e0ddc8fb  int3
00007986e0ddc8fc  call 0x00007986E0CE27E0
00007986e0ddc901  jmp 0x00007986E0DDB9DF
00007986e0ddc906  call 0x00007986E0CE1570
00007986e0ddc90b  jmp 0x00007986E0DDB9E8
00007986e0ddc910  call 0x00007986E0CE27E0
00007986e0ddc915  jmp 0x00007986E0DDBA44
00007986e0ddc91a  call 0x00007986E0CE1570
00007986e0ddc91f  jmp 0x00007986E0DDBA4D
00007986e0ddc924  call 0x00007986E0CE27E0
00007986e0ddc929  jmp 0x00007986E0DDBA90
00007986e0ddc92e  call 0x00007986E0CE1570
00007986e0ddc933  jmp 0x00007986E0DDBA99
00007986e0ddc938  call 0x00007986E0C0DC20
00007986e0ddc93d  jmp 0x00007986E0DDBAD8
00007986e0ddc942  call 0x00007986E0CD59C0
00007986e0ddc947  jmp 0x00007986E0DDBAEB
00007986e0ddc94c  call 0x00007986E0CE0E30
00007986e0ddc951  jmp 0x00007986E0DDBB09
00007986e0ddc956  call 0x00007986E0CDFBC0
00007986e0ddc95b  jmp 0x00007986E0DDBB13
00007986e0ddc960  call 0x00007986E0CDE950
00007986e0ddc965  jmp 0x00007986E0DDBB1D
00007986e0ddc96a  sub rsp, 0x08
00007986e0ddc96e  push rax
00007986e0ddc96f  push rcx
00007986e0ddc970  push rdx
00007986e0ddc971  push rdi
00007986e0ddc972  push rsi
00007986e0ddc973  push r8
00007986e0ddc975  push r9
00007986e0ddc977  push r10
00007986e0ddc979  push r11
00007986e0ddc97b  sub rsp, 0xF0
00007986e0ddc982  vmovaps [rsp], xmm0
00007986e0ddc987  vmovaps [rsp+0x10], xmm1
00007986e0ddc98d  vmovaps [rsp+0x20], xmm2
00007986e0ddc993  vmovaps [rsp+0x30], xmm3
00007986e0ddc999  vmovaps [rsp+0x40], xmm4
00007986e0ddc99f  vmovaps [rsp+0x50], xmm5
00007986e0ddc9a5  vmovaps [rsp+0x60], xmm6
00007986e0ddc9ab  vmovaps [rsp+0x70], xmm7
00007986e0ddc9b1  vmovaps [rsp+0x80], xmm9
00007986e0ddc9ba  vmovaps [rsp+0x90], xmm10
00007986e0ddc9c3  vmovaps [rsp+0xA0], xmm11
00007986e0ddc9cc  vmovaps [rsp+0xB0], xmm12
00007986e0ddc9d5  vmovaps [rsp+0xC0], xmm13
00007986e0ddc9de  vmovaps [rsp+0xD0], xmm14
00007986e0ddc9e7  vmovaps [rsp+0xE0], xmm15
00007986e0ddc9f0  sub rsp, 0x30
00007986e0ddc9f4  movaps [rsp], xmm8
00007986e0ddc9f9  movaps [rsp+0x10], xmm12
00007986e0ddc9ff  movaps [rsp+0x20], xmm15
00007986e0ddca05  lea rdi, [rsp]
00007986e0ddca09  mov esi, 0x00
00007986e0ddca0e  mov rax, 0x5652C689F530
00007986e0ddca18  call rax
00007986e0ddca1a  movaps xmm8, [rsp]
00007986e0ddca1f  add rsp, 0x30
00007986e0ddca23  vmovaps xmm0, [rsp]
00007986e0ddca28  vmovaps xmm1, [rsp+0x10]
00007986e0ddca2e  vmovaps xmm2, [rsp+0x20]
00007986e0ddca34  vmovaps xmm3, [rsp+0x30]
00007986e0ddca3a  vmovaps xmm4, [rsp+0x40]
00007986e0ddca40  vmovaps xmm5, [rsp+0x50]
00007986e0ddca46  vmovaps xmm6, [rsp+0x60]
00007986e0ddca4c  vmovaps xmm7, [rsp+0x70]
00007986e0ddca52  vmovaps xmm9, [rsp+0x80]
00007986e0ddca5b  vmovaps xmm10, [rsp+0x90]
00007986e0ddca64  vmovaps xmm11, [rsp+0xA0]
00007986e0ddca6d  vmovaps xmm12, [rsp+0xB0]
00007986e0ddca76  vmovaps xmm13, [rsp+0xC0]
00007986e0ddca7f  vmovaps xmm14, [rsp+0xD0]
00007986e0ddca88  vmovaps xmm15, [rsp+0xE0]
00007986e0ddca91  add rsp, 0xF0
00007986e0ddca98  pop r11
00007986e0ddca9a  pop r10
00007986e0ddca9c  pop r9
00007986e0ddca9e  pop r8
00007986e0ddcaa0  pop rsi
00007986e0ddcaa1  pop rdi
00007986e0ddcaa2  pop rdx
00007986e0ddcaa3  pop rcx
00007986e0ddcaa4  pop rax
00007986e0ddcaa5  add rsp, 0x08
00007986e0ddcaa9  jmp 0x00007986E0DDBB47
00007986e0ddcaae  sub rsp, 0x08
00007986e0ddcab2  push rax
00007986e0ddcab3  push rcx
00007986e0ddcab4  push rdx
00007986e0ddcab5  push rdi
00007986e0ddcab6  push rsi
00007986e0ddcab7  push r8
00007986e0ddcab9  push r9
00007986e0ddcabb  push r10
00007986e0ddcabd  push r11
00007986e0ddcabf  sub rsp, 0xF0
00007986e0ddcac6  vmovaps [rsp], xmm0
00007986e0ddcacb  vmovaps [rsp+0x10], xmm1
00007986e0ddcad1  vmovaps [rsp+0x20], xmm2
00007986e0ddcad7  vmovaps [rsp+0x30], xmm3
00007986e0ddcadd  vmovaps [rsp+0x40], xmm4
00007986e0ddcae3  vmovaps [rsp+0x50], xmm5
00007986e0ddcae9  vmovaps [rsp+0x60], xmm6
00007986e0ddcaef  vmovaps [rsp+0x70], xmm8
00007986e0ddcaf5  vmovaps [rsp+0x80], xmm9
00007986e0ddcafe  vmovaps [rsp+0x90], xmm10
00007986e0ddcb07  vmovaps [rsp+0xA0], xmm11
00007986e0ddcb10  vmovaps [rsp+0xB0], xmm12
00007986e0ddcb19  vmovaps [rsp+0xC0], xmm13
00007986e0ddcb22  vmovaps [rsp+0xD0], xmm14
00007986e0ddcb2b  vmovaps [rsp+0xE0], xmm15
00007986e0ddcb34  sub rsp, 0x30
00007986e0ddcb38  movaps [rsp], xmm7
00007986e0ddcb3c  movaps [rsp+0x10], xmm9
00007986e0ddcb42  movaps [rsp+0x20], xmm15
00007986e0ddcb48  lea rdi, [rsp]
00007986e0ddcb4c  mov esi, 0x00
00007986e0ddcb51  mov rax, 0x5652C689F530
00007986e0ddcb5b  call rax
00007986e0ddcb5d  movaps xmm7, [rsp]
00007986e0ddcb61  add rsp, 0x30
00007986e0ddcb65  vmovaps xmm0, [rsp]
00007986e0ddcb6a  vmovaps xmm1, [rsp+0x10]
00007986e0ddcb70  vmovaps xmm2, [rsp+0x20]
00007986e0ddcb76  vmovaps xmm3, [rsp+0x30]
00007986e0ddcb7c  vmovaps xmm4, [rsp+0x40]
00007986e0ddcb82  vmovaps xmm5, [rsp+0x50]
00007986e0ddcb88  vmovaps xmm6, [rsp+0x60]
00007986e0ddcb8e  vmovaps xmm8, [rsp+0x70]
00007986e0ddcb94  vmovaps xmm9, [rsp+0x80]
00007986e0ddcb9d  vmovaps xmm10, [rsp+0x90]
00007986e0ddcba6  vmovaps xmm11, [rsp+0xA0]
00007986e0ddcbaf  vmovaps xmm12, [rsp+0xB0]
00007986e0ddcbb8  vmovaps xmm13, [rsp+0xC0]
00007986e0ddcbc1  vmovaps xmm14, [rsp+0xD0]
00007986e0ddcbca  vmovaps xmm15, [rsp+0xE0]
00007986e0ddcbd3  add rsp, 0xF0
00007986e0ddcbda  pop r11
00007986e0ddcbdc  pop r10
00007986e0ddcbde  pop r9
00007986e0ddcbe0  pop r8
00007986e0ddcbe2  pop rsi
00007986e0ddcbe3  pop rdi
00007986e0ddcbe4  pop rdx
00007986e0ddcbe5  pop rcx
00007986e0ddcbe6  pop rax
00007986e0ddcbe7  add rsp, 0x08
00007986e0ddcbeb  jmp 0x00007986E0DDBB75
00007986e0ddcbf0  sub rsp, 0x08
00007986e0ddcbf4  push rax
00007986e0ddcbf5  push rcx
00007986e0ddcbf6  push rdx
00007986e0ddcbf7  push rdi
00007986e0ddcbf8  push rsi
00007986e0ddcbf9  push r8
00007986e0ddcbfb  push r9
00007986e0ddcbfd  push r10
00007986e0ddcbff  push r11
00007986e0ddcc01  sub rsp, 0xF0
00007986e0ddcc08  vmovaps [rsp], xmm0
00007986e0ddcc0d  vmovaps [rsp+0x10], xmm1
00007986e0ddcc13  vmovaps [rsp+0x20], xmm2
00007986e0ddcc19  vmovaps [rsp+0x30], xmm3
00007986e0ddcc1f  vmovaps [rsp+0x40], xmm4
00007986e0ddcc25  vmovaps [rsp+0x50], xmm5
00007986e0ddcc2b  vmovaps [rsp+0x60], xmm6
00007986e0ddcc31  vmovaps [rsp+0x70], xmm7
00007986e0ddcc37  vmovaps [rsp+0x80], xmm8
00007986e0ddcc40  vmovaps [rsp+0x90], xmm10
00007986e0ddcc49  vmovaps [rsp+0xA0], xmm11
00007986e0ddcc52  vmovaps [rsp+0xB0], xmm12
00007986e0ddcc5b  vmovaps [rsp+0xC0], xmm13
00007986e0ddcc64  vmovaps [rsp+0xD0], xmm14
00007986e0ddcc6d  vmovaps [rsp+0xE0], xmm15
00007986e0ddcc76  sub rsp, 0x30
00007986e0ddcc7a  movaps [rsp], xmm9
00007986e0ddcc7f  movaps [rsp+0x10], xmm12
00007986e0ddcc85  movaps [rsp+0x20], xmm10
00007986e0ddcc8b  lea rdi, [rsp]
00007986e0ddcc8f  mov esi, 0x00
00007986e0ddcc94  mov rax, 0x5652C689F530
00007986e0ddcc9e  call rax
00007986e0ddcca0  movaps xmm9, [rsp]
00007986e0ddcca5  add rsp, 0x30
00007986e0ddcca9  vmovaps xmm0, [rsp]
00007986e0ddccae  vmovaps xmm1, [rsp+0x10]
00007986e0ddccb4  vmovaps xmm2, [rsp+0x20]
00007986e0ddccba  vmovaps xmm3, [rsp+0x30]
00007986e0ddccc0  vmovaps xmm4, [rsp+0x40]
00007986e0ddccc6  vmovaps xmm5, [rsp+0x50]
00007986e0ddcccc  vmovaps xmm6, [rsp+0x60]
00007986e0ddccd2  vmovaps xmm7, [rsp+0x70]
00007986e0ddccd8  vmovaps xmm8, [rsp+0x80]
00007986e0ddcce1  vmovaps xmm10, [rsp+0x90]
00007986e0ddccea  vmovaps xmm11, [rsp+0xA0]
00007986e0ddccf3  vmovaps xmm12, [rsp+0xB0]
00007986e0ddccfc  vmovaps xmm13, [rsp+0xC0]
00007986e0ddcd05  vmovaps xmm14, [rsp+0xD0]
00007986e0ddcd0e  vmovaps xmm15, [rsp+0xE0]
00007986e0ddcd17  add rsp, 0xF0
00007986e0ddcd1e  pop r11
00007986e0ddcd20  pop r10
00007986e0ddcd22  pop r9
00007986e0ddcd24  pop r8
00007986e0ddcd26  pop rsi
00007986e0ddcd27  pop rdi
00007986e0ddcd28  pop rdx
00007986e0ddcd29  pop rcx
00007986e0ddcd2a  pop rax
00007986e0ddcd2b  add rsp, 0x08
00007986e0ddcd2f  jmp 0x00007986E0DDBB99
00007986e0ddcd34  sub rsp, 0x08
00007986e0ddcd38  push rax
00007986e0ddcd39  push rcx
00007986e0ddcd3a  push rdx
00007986e0ddcd3b  push rdi
00007986e0ddcd3c  push rsi
00007986e0ddcd3d  push r8
00007986e0ddcd3f  push r9
00007986e0ddcd41  push r10
00007986e0ddcd43  push r11
00007986e0ddcd45  sub rsp, 0xF0
00007986e0ddcd4c  vmovaps [rsp], xmm0
00007986e0ddcd51  vmovaps [rsp+0x10], xmm1
00007986e0ddcd57  vmovaps [rsp+0x20], xmm2
00007986e0ddcd5d  vmovaps [rsp+0x30], xmm3
00007986e0ddcd63  vmovaps [rsp+0x40], xmm4
00007986e0ddcd69  vmovaps [rsp+0x50], xmm5
00007986e0ddcd6f  vmovaps [rsp+0x60], xmm6
00007986e0ddcd75  vmovaps [rsp+0x70], xmm7
00007986e0ddcd7b  vmovaps [rsp+0x80], xmm8
00007986e0ddcd84  vmovaps [rsp+0x90], xmm9
00007986e0ddcd8d  vmovaps [rsp+0xA0], xmm11
00007986e0ddcd96  vmovaps [rsp+0xB0], xmm12
00007986e0ddcd9f  vmovaps [rsp+0xC0], xmm13
00007986e0ddcda8  vmovaps [rsp+0xD0], xmm14
00007986e0ddcdb1  vmovaps [rsp+0xE0], xmm15
00007986e0ddcdba  sub rsp, 0x30
00007986e0ddcdbe  movaps [rsp], xmm10
00007986e0ddcdc3  movaps [rsp+0x10], xmm12
00007986e0ddcdc9  movaps [rsp+0x20], xmm11
00007986e0ddcdcf  lea rdi, [rsp]
00007986e0ddcdd3  mov esi, 0x00
00007986e0ddcdd8  mov rax, 0x5652C689F530
00007986e0ddcde2  call rax
00007986e0ddcde4  movaps xmm10, [rsp]
00007986e0ddcde9  add rsp, 0x30
00007986e0ddcded  vmovaps xmm0, [rsp]
00007986e0ddcdf2  vmovaps xmm1, [rsp+0x10]
00007986e0ddcdf8  vmovaps xmm2, [rsp+0x20]
00007986e0ddcdfe  vmovaps xmm3, [rsp+0x30]
00007986e0ddce04  vmovaps xmm4, [rsp+0x40]
00007986e0ddce0a  vmovaps xmm5, [rsp+0x50]
00007986e0ddce10  vmovaps xmm6, [rsp+0x60]
00007986e0ddce16  vmovaps xmm7, [rsp+0x70]
00007986e0ddce1c  vmovaps xmm8, [rsp+0x80]
00007986e0ddce25  vmovaps xmm9, [rsp+0x90]
00007986e0ddce2e  vmovaps xmm11, [rsp+0xA0]
00007986e0ddce37  vmovaps xmm12, [rsp+0xB0]
00007986e0ddce40  vmovaps xmm13, [rsp+0xC0]
00007986e0ddce49  vmovaps xmm14, [rsp+0xD0]
00007986e0ddce52  vmovaps xmm15, [rsp+0xE0]
00007986e0ddce5b  add rsp, 0xF0
00007986e0ddce62  pop r11
00007986e0ddce64  pop r10
00007986e0ddce66  pop r9
00007986e0ddce68  pop r8
00007986e0ddce6a  pop rsi
00007986e0ddce6b  pop rdi
00007986e0ddce6c  pop rdx
00007986e0ddce6d  pop rcx
00007986e0ddce6e  pop rax
00007986e0ddce6f  add rsp, 0x08
00007986e0ddce73  jmp 0x00007986E0DDBBB3
00007986e0ddce78  sub rsp, 0x08
00007986e0ddce7c  push rax
00007986e0ddce7d  push rcx
00007986e0ddce7e  push rdx
00007986e0ddce7f  push rdi
00007986e0ddce80  push rsi
00007986e0ddce81  push r8
00007986e0ddce83  push r9
00007986e0ddce85  push r10
00007986e0ddce87  push r11
00007986e0ddce89  sub rsp, 0xF0
00007986e0ddce90  vmovaps [rsp], xmm0
00007986e0ddce95  vmovaps [rsp+0x10], xmm1
00007986e0ddce9b  vmovaps [rsp+0x20], xmm2
00007986e0ddcea1  vmovaps [rsp+0x30], xmm3
00007986e0ddcea7  vmovaps [rsp+0x40], xmm4
00007986e0ddcead  vmovaps [rsp+0x50], xmm5
00007986e0ddceb3  vmovaps [rsp+0x60], xmm7
00007986e0ddceb9  vmovaps [rsp+0x70], xmm8
00007986e0ddcebf  vmovaps [rsp+0x80], xmm9
00007986e0ddcec8  vmovaps [rsp+0x90], xmm10
00007986e0ddced1  vmovaps [rsp+0xA0], xmm11
00007986e0ddceda  vmovaps [rsp+0xB0], xmm12
00007986e0ddcee3  vmovaps [rsp+0xC0], xmm13
00007986e0ddceec  vmovaps [rsp+0xD0], xmm14
00007986e0ddcef5  vmovaps [rsp+0xE0], xmm15
00007986e0ddcefe  sub rsp, 0x30
00007986e0ddcf02  movaps [rsp], xmm6
00007986e0ddcf06  movaps [rsp+0x10], xmm12
00007986e0ddcf0c  movaps [rsp+0x20], xmm11
00007986e0ddcf12  lea rdi, [rsp]
00007986e0ddcf16  mov esi, 0x00
00007986e0ddcf1b  mov rax, 0x5652C689F530
00007986e0ddcf25  call rax
00007986e0ddcf27  movaps xmm6, [rsp]
00007986e0ddcf2b  add rsp, 0x30
00007986e0ddcf2f  vmovaps xmm0, [rsp]
00007986e0ddcf34  vmovaps xmm1, [rsp+0x10]
00007986e0ddcf3a  vmovaps xmm2, [rsp+0x20]
00007986e0ddcf40  vmovaps xmm3, [rsp+0x30]
00007986e0ddcf46  vmovaps xmm4, [rsp+0x40]
00007986e0ddcf4c  vmovaps xmm5, [rsp+0x50]
00007986e0ddcf52  vmovaps xmm7, [rsp+0x60]
00007986e0ddcf58  vmovaps xmm8, [rsp+0x70]
00007986e0ddcf5e  vmovaps xmm9, [rsp+0x80]
00007986e0ddcf67  vmovaps xmm10, [rsp+0x90]
00007986e0ddcf70  vmovaps xmm11, [rsp+0xA0]
00007986e0ddcf79  vmovaps xmm12, [rsp+0xB0]
00007986e0ddcf82  vmovaps xmm13, [rsp+0xC0]
00007986e0ddcf8b  vmovaps xmm14, [rsp+0xD0]
00007986e0ddcf94  vmovaps xmm15, [rsp+0xE0]
00007986e0ddcf9d  add rsp, 0xF0
00007986e0ddcfa4  pop r11
00007986e0ddcfa6  pop r10
00007986e0ddcfa8  pop r9
00007986e0ddcfaa  pop r8
00007986e0ddcfac  pop rsi
00007986e0ddcfad  pop rdi
00007986e0ddcfae  pop rdx
00007986e0ddcfaf  pop rcx
00007986e0ddcfb0  pop rax
00007986e0ddcfb1  add rsp, 0x08
00007986e0ddcfb5  jmp 0x00007986E0DDBBD4
00007986e0ddcfba  sub rsp, 0x08
00007986e0ddcfbe  push rax
00007986e0ddcfbf  push rcx
00007986e0ddcfc0  push rdx
00007986e0ddcfc1  push rdi
00007986e0ddcfc2  push rsi
00007986e0ddcfc3  push r8
00007986e0ddcfc5  push r9
00007986e0ddcfc7  push r10
00007986e0ddcfc9  push r11
00007986e0ddcfcb  sub rsp, 0xF0
00007986e0ddcfd2  vmovaps [rsp], xmm0
00007986e0ddcfd7  vmovaps [rsp+0x10], xmm1
00007986e0ddcfdd  vmovaps [rsp+0x20], xmm2
00007986e0ddcfe3  vmovaps [rsp+0x30], xmm4
00007986e0ddcfe9  vmovaps [rsp+0x40], xmm5
00007986e0ddcfef  vmovaps [rsp+0x50], xmm6
00007986e0ddcff5  vmovaps [rsp+0x60], xmm7
00007986e0ddcffb  vmovaps [rsp+0x70], xmm8
00007986e0ddd001  vmovaps [rsp+0x80], xmm9
00007986e0ddd00a  vmovaps [rsp+0x90], xmm10
00007986e0ddd013  vmovaps [rsp+0xA0], xmm11
00007986e0ddd01c  vmovaps [rsp+0xB0], xmm12
00007986e0ddd025  vmovaps [rsp+0xC0], xmm13
00007986e0ddd02e  vmovaps [rsp+0xD0], xmm14
00007986e0ddd037  vmovaps [rsp+0xE0], xmm15
00007986e0ddd040  sub rsp, 0x30
00007986e0ddd044  movaps [rsp], xmm3
00007986e0ddd048  movaps [rsp+0x10], xmm5
00007986e0ddd04d  movaps [rsp+0x20], xmm4
00007986e0ddd052  lea rdi, [rsp]
00007986e0ddd056  mov esi, 0x00
00007986e0ddd05b  mov rax, 0x5652C689F530
00007986e0ddd065  call rax
00007986e0ddd067  movaps xmm3, [rsp]
00007986e0ddd06b  add rsp, 0x30
00007986e0ddd06f  vmovaps xmm0, [rsp]
00007986e0ddd074  vmovaps xmm1, [rsp+0x10]
00007986e0ddd07a  vmovaps xmm2, [rsp+0x20]
00007986e0ddd080  vmovaps xmm4, [rsp+0x30]
00007986e0ddd086  vmovaps xmm5, [rsp+0x40]
00007986e0ddd08c  vmovaps xmm6, [rsp+0x50]
00007986e0ddd092  vmovaps xmm7, [rsp+0x60]
00007986e0ddd098  vmovaps xmm8, [rsp+0x70]
00007986e0ddd09e  vmovaps xmm9, [rsp+0x80]
00007986e0ddd0a7  vmovaps xmm10, [rsp+0x90]
00007986e0ddd0b0  vmovaps xmm11, [rsp+0xA0]
00007986e0ddd0b9  vmovaps xmm12, [rsp+0xB0]
00007986e0ddd0c2  vmovaps xmm13, [rsp+0xC0]
00007986e0ddd0cb  vmovaps xmm14, [rsp+0xD0]
00007986e0ddd0d4  vmovaps xmm15, [rsp+0xE0]
00007986e0ddd0dd  add rsp, 0xF0
00007986e0ddd0e4  pop r11
00007986e0ddd0e6  pop r10
00007986e0ddd0e8  pop r9
00007986e0ddd0ea  pop r8
00007986e0ddd0ec  pop rsi
00007986e0ddd0ed  pop rdi
00007986e0ddd0ee  pop rdx
00007986e0ddd0ef  pop rcx
00007986e0ddd0f0  pop rax
00007986e0ddd0f1  add rsp, 0x08
00007986e0ddd0f5  jmp 0x00007986E0DDBC35
00007986e0ddd0fa  sub rsp, 0x08
00007986e0ddd0fe  push rax
00007986e0ddd0ff  push rcx
00007986e0ddd100  push rdx
00007986e0ddd101  push rdi
00007986e0ddd102  push rsi
00007986e0ddd103  push r8
00007986e0ddd105  push r9
00007986e0ddd107  push r10
00007986e0ddd109  push r11
00007986e0ddd10b  sub rsp, 0xF0
00007986e0ddd112  vmovaps [rsp], xmm0
00007986e0ddd117  vmovaps [rsp+0x10], xmm1
00007986e0ddd11d  vmovaps [rsp+0x20], xmm2
00007986e0ddd123  vmovaps [rsp+0x30], xmm3
00007986e0ddd129  vmovaps [rsp+0x40], xmm4
00007986e0ddd12f  vmovaps [rsp+0x50], xmm6
00007986e0ddd135  vmovaps [rsp+0x60], xmm7
00007986e0ddd13b  vmovaps [rsp+0x70], xmm8
00007986e0ddd141  vmovaps [rsp+0x80], xmm9
00007986e0ddd14a  vmovaps [rsp+0x90], xmm10
00007986e0ddd153  vmovaps [rsp+0xA0], xmm11
00007986e0ddd15c  vmovaps [rsp+0xB0], xmm12
00007986e0ddd165  vmovaps [rsp+0xC0], xmm13
00007986e0ddd16e  vmovaps [rsp+0xD0], xmm14
00007986e0ddd177  vmovaps [rsp+0xE0], xmm15
00007986e0ddd180  sub rsp, 0x30
00007986e0ddd184  movaps [rsp], xmm5
00007986e0ddd188  movaps [rsp+0x10], xmm8
00007986e0ddd18e  movaps [rsp+0x20], xmm15
00007986e0ddd194  lea rdi, [rsp]
00007986e0ddd198  mov esi, 0x00
00007986e0ddd19d  mov rax, 0x5652C689F530
00007986e0ddd1a7  call rax
00007986e0ddd1a9  movaps xmm5, [rsp]
00007986e0ddd1ad  add rsp, 0x30
00007986e0ddd1b1  vmovaps xmm0, [rsp]
00007986e0ddd1b6  vmovaps xmm1, [rsp+0x10]
00007986e0ddd1bc  vmovaps xmm2, [rsp+0x20]
00007986e0ddd1c2  vmovaps xmm3, [rsp+0x30]
00007986e0ddd1c8  vmovaps xmm4, [rsp+0x40]
00007986e0ddd1ce  vmovaps xmm6, [rsp+0x50]
00007986e0ddd1d4  vmovaps xmm7, [rsp+0x60]
00007986e0ddd1da  vmovaps xmm8, [rsp+0x70]
00007986e0ddd1e0  vmovaps xmm9, [rsp+0x80]
00007986e0ddd1e9  vmovaps xmm10, [rsp+0x90]
00007986e0ddd1f2  vmovaps xmm11, [rsp+0xA0]
00007986e0ddd1fb  vmovaps xmm12, [rsp+0xB0]
00007986e0ddd204  vmovaps xmm13, [rsp+0xC0]
00007986e0ddd20d  vmovaps xmm14, [rsp+0xD0]
00007986e0ddd216  vmovaps xmm15, [rsp+0xE0]
00007986e0ddd21f  add rsp, 0xF0
00007986e0ddd226  pop r11
00007986e0ddd228  pop r10
00007986e0ddd22a  pop r9
00007986e0ddd22c  pop r8
00007986e0ddd22e  pop rsi
00007986e0ddd22f  pop rdi
00007986e0ddd230  pop rdx
00007986e0ddd231  pop rcx
00007986e0ddd232  pop rax
00007986e0ddd233  add rsp, 0x08
00007986e0ddd237  jmp 0x00007986E0DDBC73
00007986e0ddd23c  sub rsp, 0x08
00007986e0ddd240  push rax
00007986e0ddd241  push rcx
00007986e0ddd242  push rdx
00007986e0ddd243  push rdi
00007986e0ddd244  push rsi
00007986e0ddd245  push r8
00007986e0ddd247  push r9
00007986e0ddd249  push r10
00007986e0ddd24b  push r11
00007986e0ddd24d  sub rsp, 0xF0
00007986e0ddd254  vmovaps [rsp], xmm0
00007986e0ddd259  vmovaps [rsp+0x10], xmm1
00007986e0ddd25f  vmovaps [rsp+0x20], xmm2
00007986e0ddd265  vmovaps [rsp+0x30], xmm3
00007986e0ddd26b  vmovaps [rsp+0x40], xmm5
00007986e0ddd271  vmovaps [rsp+0x50], xmm6
00007986e0ddd277  vmovaps [rsp+0x60], xmm7
00007986e0ddd27d  vmovaps [rsp+0x70], xmm8
00007986e0ddd283  vmovaps [rsp+0x80], xmm9
00007986e0ddd28c  vmovaps [rsp+0x90], xmm10
00007986e0ddd295  vmovaps [rsp+0xA0], xmm11
00007986e0ddd29e  vmovaps [rsp+0xB0], xmm12
00007986e0ddd2a7  vmovaps [rsp+0xC0], xmm13
00007986e0ddd2b0  vmovaps [rsp+0xD0], xmm14
00007986e0ddd2b9  vmovaps [rsp+0xE0], xmm15
00007986e0ddd2c2  sub rsp, 0x30
00007986e0ddd2c6  movaps [rsp], xmm4
00007986e0ddd2ca  movaps [rsp+0x10], xmm9
00007986e0ddd2d0  movaps [rsp+0x20], xmm8
00007986e0ddd2d6  lea rdi, [rsp]
00007986e0ddd2da  mov esi, 0x00
00007986e0ddd2df  mov rax, 0x5652C689F530
00007986e0ddd2e9  call rax
00007986e0ddd2eb  movaps xmm4, [rsp]
00007986e0ddd2ef  add rsp, 0x30
00007986e0ddd2f3  vmovaps xmm0, [rsp]
00007986e0ddd2f8  vmovaps xmm1, [rsp+0x10]
00007986e0ddd2fe  vmovaps xmm2, [rsp+0x20]
00007986e0ddd304  vmovaps xmm3, [rsp+0x30]
00007986e0ddd30a  vmovaps xmm5, [rsp+0x40]
00007986e0ddd310  vmovaps xmm6, [rsp+0x50]
00007986e0ddd316  vmovaps xmm7, [rsp+0x60]
00007986e0ddd31c  vmovaps xmm8, [rsp+0x70]
00007986e0ddd322  vmovaps xmm9, [rsp+0x80]
00007986e0ddd32b  vmovaps xmm10, [rsp+0x90]
00007986e0ddd334  vmovaps xmm11, [rsp+0xA0]
00007986e0ddd33d  vmovaps xmm12, [rsp+0xB0]
00007986e0ddd346  vmovaps xmm13, [rsp+0xC0]
00007986e0ddd34f  vmovaps xmm14, [rsp+0xD0]
00007986e0ddd358  vmovaps xmm15, [rsp+0xE0]
00007986e0ddd361  add rsp, 0xF0
00007986e0ddd368  pop r11
00007986e0ddd36a  pop r10
00007986e0ddd36c  pop r9
00007986e0ddd36e  pop r8
00007986e0ddd370  pop rsi
00007986e0ddd371  pop rdi
00007986e0ddd372  pop rdx
00007986e0ddd373  pop rcx
00007986e0ddd374  pop rax
00007986e0ddd375  add rsp, 0x08
00007986e0ddd379  jmp 0x00007986E0DDBC94
00007986e0ddd37e  sub rsp, 0x08
00007986e0ddd382  push rax
00007986e0ddd383  push rcx
00007986e0ddd384  push rdx
00007986e0ddd385  push rdi
00007986e0ddd386  push rsi
00007986e0ddd387  push r8
00007986e0ddd389  push r9
00007986e0ddd38b  push r10
00007986e0ddd38d  push r11
00007986e0ddd38f  sub rsp, 0xF0
00007986e0ddd396  vmovaps [rsp], xmm0
00007986e0ddd39b  vmovaps [rsp+0x10], xmm1
00007986e0ddd3a1  vmovaps [rsp+0x20], xmm2
00007986e0ddd3a7  vmovaps [rsp+0x30], xmm3
00007986e0ddd3ad  vmovaps [rsp+0x40], xmm4
00007986e0ddd3b3  vmovaps [rsp+0x50], xmm5
00007986e0ddd3b9  vmovaps [rsp+0x60], xmm6
00007986e0ddd3bf  vmovaps [rsp+0x70], xmm7
00007986e0ddd3c5  vmovaps [rsp+0x80], xmm8
00007986e0ddd3ce  vmovaps [rsp+0x90], xmm10
00007986e0ddd3d7  vmovaps [rsp+0xA0], xmm11
00007986e0ddd3e0  vmovaps [rsp+0xB0], xmm12
00007986e0ddd3e9  vmovaps [rsp+0xC0], xmm13
00007986e0ddd3f2  vmovaps [rsp+0xD0], xmm14
00007986e0ddd3fb  vmovaps [rsp+0xE0], xmm15
00007986e0ddd404  sub rsp, 0x30
00007986e0ddd408  movaps [rsp], xmm9
00007986e0ddd40d  movaps [rsp+0x10], xmm10
00007986e0ddd413  movaps [rsp+0x20], xmm8
00007986e0ddd419  lea rdi, [rsp]
00007986e0ddd41d  mov esi, 0x00
00007986e0ddd422  mov rax, 0x5652C689F530
00007986e0ddd42c  call rax
00007986e0ddd42e  movaps xmm9, [rsp]
00007986e0ddd433  add rsp, 0x30
00007986e0ddd437  vmovaps xmm0, [rsp]
00007986e0ddd43c  vmovaps xmm1, [rsp+0x10]
00007986e0ddd442  vmovaps xmm2, [rsp+0x20]
00007986e0ddd448  vmovaps xmm3, [rsp+0x30]
00007986e0ddd44e  vmovaps xmm4, [rsp+0x40]
00007986e0ddd454  vmovaps xmm5, [rsp+0x50]
00007986e0ddd45a  vmovaps xmm6, [rsp+0x60]
00007986e0ddd460  vmovaps xmm7, [rsp+0x70]
00007986e0ddd466  vmovaps xmm8, [rsp+0x80]
00007986e0ddd46f  vmovaps xmm10, [rsp+0x90]
00007986e0ddd478  vmovaps xmm11, [rsp+0xA0]
00007986e0ddd481  vmovaps xmm12, [rsp+0xB0]
00007986e0ddd48a  vmovaps xmm13, [rsp+0xC0]
00007986e0ddd493  vmovaps xmm14, [rsp+0xD0]
00007986e0ddd49c  vmovaps xmm15, [rsp+0xE0]
00007986e0ddd4a5  add rsp, 0xF0
00007986e0ddd4ac  pop r11
00007986e0ddd4ae  pop r10
00007986e0ddd4b0  pop r9
00007986e0ddd4b2  pop r8
00007986e0ddd4b4  pop rsi
00007986e0ddd4b5  pop rdi
00007986e0ddd4b6  pop rdx
00007986e0ddd4b7  pop rcx
00007986e0ddd4b8  pop rax
00007986e0ddd4b9  add rsp, 0x08
00007986e0ddd4bd  jmp 0x00007986E0DDBCAE
00007986e0ddd4c2  call 0x00007986E0CB52F0
00007986e0ddd4c7  jmp 0x00007986E0DDBDC8
00007986e0ddd4cc  call 0x00007986E0CB52F0
00007986e0ddd4d1  jmp 0x00007986E0DDBDDE
00007986e0ddd4d6  sub rsp, 0x08
00007986e0ddd4da  push rax
00007986e0ddd4db  push rcx
00007986e0ddd4dc  push rdx
00007986e0ddd4dd  push rdi
00007986e0ddd4de  push rsi
00007986e0ddd4df  push r8
00007986e0ddd4e1  push r9
00007986e0ddd4e3  push r10
00007986e0ddd4e5  push r11
00007986e0ddd4e7  sub rsp, 0xF0
00007986e0ddd4ee  vmovaps [rsp], xmm0
00007986e0ddd4f3  vmovaps [rsp+0x10], xmm2
00007986e0ddd4f9  vmovaps [rsp+0x20], xmm3
00007986e0ddd4ff  vmovaps [rsp+0x30], xmm4
00007986e0ddd505  vmovaps [rsp+0x40], xmm5
00007986e0ddd50b  vmovaps [rsp+0x50], xmm6
00007986e0ddd511  vmovaps [rsp+0x60], xmm7
00007986e0ddd517  vmovaps [rsp+0x70], xmm8
00007986e0ddd51d  vmovaps [rsp+0x80], xmm9
00007986e0ddd526  vmovaps [rsp+0x90], xmm10
00007986e0ddd52f  vmovaps [rsp+0xA0], xmm11
00007986e0ddd538  vmovaps [rsp+0xB0], xmm12
00007986e0ddd541  vmovaps [rsp+0xC0], xmm13
00007986e0ddd54a  vmovaps [rsp+0xD0], xmm14
00007986e0ddd553  vmovaps [rsp+0xE0], xmm15
00007986e0ddd55c  sub rsp, 0x30
00007986e0ddd560  movaps [rsp], xmm1
00007986e0ddd564  movaps [rsp+0x10], xmm6
00007986e0ddd569  movaps [rsp+0x20], xmm15
00007986e0ddd56f  lea rdi, [rsp]
00007986e0ddd573  mov esi, 0x00
00007986e0ddd578  mov rax, 0x5652C689F530
00007986e0ddd582  call rax
00007986e0ddd584  movaps xmm1, [rsp]
00007986e0ddd588  add rsp, 0x30
00007986e0ddd58c  vmovaps xmm0, [rsp]
00007986e0ddd591  vmovaps xmm2, [rsp+0x10]
00007986e0ddd597  vmovaps xmm3, [rsp+0x20]
00007986e0ddd59d  vmovaps xmm4, [rsp+0x30]
00007986e0ddd5a3  vmovaps xmm5, [rsp+0x40]
00007986e0ddd5a9  vmovaps xmm6, [rsp+0x50]
00007986e0ddd5af  vmovaps xmm7, [rsp+0x60]
00007986e0ddd5b5  vmovaps xmm8, [rsp+0x70]
00007986e0ddd5bb  vmovaps xmm9, [rsp+0x80]
00007986e0ddd5c4  vmovaps xmm10, [rsp+0x90]
00007986e0ddd5cd  vmovaps xmm11, [rsp+0xA0]
00007986e0ddd5d6  vmovaps xmm12, [rsp+0xB0]
00007986e0ddd5df  vmovaps xmm13, [rsp+0xC0]
00007986e0ddd5e8  vmovaps xmm14, [rsp+0xD0]
00007986e0ddd5f1  vmovaps xmm15, [rsp+0xE0]
00007986e0ddd5fa  add rsp, 0xF0
00007986e0ddd601  pop r11
00007986e0ddd603  pop r10
00007986e0ddd605  pop r9
00007986e0ddd607  pop r8
00007986e0ddd609  pop rsi
00007986e0ddd60a  pop rdi
00007986e0ddd60b  pop rdx
00007986e0ddd60c  pop rcx
00007986e0ddd60d  pop rax
00007986e0ddd60e  add rsp, 0x08
00007986e0ddd612  jmp 0x00007986E0DDBE1B
00007986e0ddd617  call 0x00007986E0CC4620
00007986e0ddd61c  jmp 0x00007986E0DDBE28
00007986e0ddd621  sub rsp, 0x08
00007986e0ddd625  push rax
00007986e0ddd626  push rcx
00007986e0ddd627  push rdx
00007986e0ddd628  push rdi
00007986e0ddd629  push rsi
00007986e0ddd62a  push r8
00007986e0ddd62c  push r9
00007986e0ddd62e  push r10
00007986e0ddd630  push r11
00007986e0ddd632  sub rsp, 0xF0
00007986e0ddd639  vmovaps [rsp], xmm0
00007986e0ddd63e  vmovaps [rsp+0x10], xmm1
00007986e0ddd644  vmovaps [rsp+0x20], xmm2
00007986e0ddd64a  vmovaps [rsp+0x30], xmm3
00007986e0ddd650  vmovaps [rsp+0x40], xmm4
00007986e0ddd656  vmovaps [rsp+0x50], xmm5
00007986e0ddd65c  vmovaps [rsp+0x60], xmm6
00007986e0ddd662  vmovaps [rsp+0x70], xmm7
00007986e0ddd668  vmovaps [rsp+0x80], xmm8
00007986e0ddd671  vmovaps [rsp+0x90], xmm9
00007986e0ddd67a  vmovaps [rsp+0xA0], xmm10
00007986e0ddd683  vmovaps [rsp+0xB0], xmm11
00007986e0ddd68c  vmovaps [rsp+0xC0], xmm12
00007986e0ddd695  vmovaps [rsp+0xD0], xmm13
00007986e0ddd69e  vmovaps [rsp+0xE0], xmm15
00007986e0ddd6a7  sub rsp, 0x30
00007986e0ddd6ab  movaps [rsp], xmm14
00007986e0ddd6b0  movaps [rsp+0x10], xmm4
00007986e0ddd6b5  movaps [rsp+0x20], xmm3
00007986e0ddd6ba  lea rdi, [rsp]
00007986e0ddd6be  mov esi, 0x00
00007986e0ddd6c3  mov rax, 0x5652C689F530
00007986e0ddd6cd  call rax
00007986e0ddd6cf  movaps xmm14, [rsp]
00007986e0ddd6d4  add rsp, 0x30
00007986e0ddd6d8  vmovaps xmm0, [rsp]
00007986e0ddd6dd  vmovaps xmm1, [rsp+0x10]
00007986e0ddd6e3  vmovaps xmm2, [rsp+0x20]
00007986e0ddd6e9  vmovaps xmm3, [rsp+0x30]
00007986e0ddd6ef  vmovaps xmm4, [rsp+0x40]
00007986e0ddd6f5  vmovaps xmm5, [rsp+0x50]
00007986e0ddd6fb  vmovaps xmm6, [rsp+0x60]
00007986e0ddd701  vmovaps xmm7, [rsp+0x70]
00007986e0ddd707  vmovaps xmm8, [rsp+0x80]
00007986e0ddd710  vmovaps xmm9, [rsp+0x90]
00007986e0ddd719  vmovaps xmm10, [rsp+0xA0]
00007986e0ddd722  vmovaps xmm11, [rsp+0xB0]
00007986e0ddd72b  vmovaps xmm12, [rsp+0xC0]
00007986e0ddd734  vmovaps xmm13, [rsp+0xD0]
00007986e0ddd73d  vmovaps xmm15, [rsp+0xE0]
00007986e0ddd746  add rsp, 0xF0
00007986e0ddd74d  pop r11
00007986e0ddd74f  pop r10
00007986e0ddd751  pop r9
00007986e0ddd753  pop r8
00007986e0ddd755  pop rsi
00007986e0ddd756  pop rdi
00007986e0ddd757  pop rdx
00007986e0ddd758  pop rcx
00007986e0ddd759  pop rax
00007986e0ddd75a  add rsp, 0x08
00007986e0ddd75e  jmp 0x00007986E0DDBE42
00007986e0ddd763  sub rsp, 0x08
00007986e0ddd767  push rax
00007986e0ddd768  push rcx
00007986e0ddd769  push rdx
00007986e0ddd76a  push rdi
00007986e0ddd76b  push rsi
00007986e0ddd76c  push r8
00007986e0ddd76e  push r9
00007986e0ddd770  push r10
00007986e0ddd772  push r11
00007986e0ddd774  sub rsp, 0xF0
00007986e0ddd77b  vmovaps [rsp], xmm0
00007986e0ddd780  vmovaps [rsp+0x10], xmm1
00007986e0ddd786  vmovaps [rsp+0x20], xmm2
00007986e0ddd78c  vmovaps [rsp+0x30], xmm3
00007986e0ddd792  vmovaps [rsp+0x40], xmm4
00007986e0ddd798  vmovaps [rsp+0x50], xmm5
00007986e0ddd79e  vmovaps [rsp+0x60], xmm7
00007986e0ddd7a4  vmovaps [rsp+0x70], xmm8
00007986e0ddd7aa  vmovaps [rsp+0x80], xmm9
00007986e0ddd7b3  vmovaps [rsp+0x90], xmm10
00007986e0ddd7bc  vmovaps [rsp+0xA0], xmm11
00007986e0ddd7c5  vmovaps [rsp+0xB0], xmm12
00007986e0ddd7ce  vmovaps [rsp+0xC0], xmm13
00007986e0ddd7d7  vmovaps [rsp+0xD0], xmm14
00007986e0ddd7e0  vmovaps [rsp+0xE0], xmm15
00007986e0ddd7e9  sub rsp, 0x30
00007986e0ddd7ed  movaps [rsp], xmm6
00007986e0ddd7f1  movaps [rsp+0x10], xmm9
00007986e0ddd7f7  movaps [rsp+0x20], xmm7
00007986e0ddd7fc  lea rdi, [rsp]
00007986e0ddd800  mov esi, 0x00
00007986e0ddd805  mov rax, 0x5652C689F530
00007986e0ddd80f  call rax
00007986e0ddd811  movaps xmm6, [rsp]
00007986e0ddd815  add rsp, 0x30
00007986e0ddd819  vmovaps xmm0, [rsp]
00007986e0ddd81e  vmovaps xmm1, [rsp+0x10]
00007986e0ddd824  vmovaps xmm2, [rsp+0x20]
00007986e0ddd82a  vmovaps xmm3, [rsp+0x30]
00007986e0ddd830  vmovaps xmm4, [rsp+0x40]
00007986e0ddd836  vmovaps xmm5, [rsp+0x50]
00007986e0ddd83c  vmovaps xmm7, [rsp+0x60]
00007986e0ddd842  vmovaps xmm8, [rsp+0x70]
00007986e0ddd848  vmovaps xmm9, [rsp+0x80]
00007986e0ddd851  vmovaps xmm10, [rsp+0x90]
00007986e0ddd85a  vmovaps xmm11, [rsp+0xA0]
00007986e0ddd863  vmovaps xmm12, [rsp+0xB0]
00007986e0ddd86c  vmovaps xmm13, [rsp+0xC0]
00007986e0ddd875  vmovaps xmm14, [rsp+0xD0]
00007986e0ddd87e  vmovaps xmm15, [rsp+0xE0]
00007986e0ddd887  add rsp, 0xF0
00007986e0ddd88e  pop r11
00007986e0ddd890  pop r10
00007986e0ddd892  pop r9
00007986e0ddd894  pop r8
00007986e0ddd896  pop rsi
00007986e0ddd897  pop rdi
00007986e0ddd898  pop rdx
00007986e0ddd899  pop rcx
00007986e0ddd89a  pop rax
00007986e0ddd89b  add rsp, 0x08
00007986e0ddd89f  jmp 0x00007986E0DDBE5A
00007986e0ddd8a4  sub rsp, 0x08
00007986e0ddd8a8  push rax
00007986e0ddd8a9  push rcx
00007986e0ddd8aa  push rdx
00007986e0ddd8ab  push rdi
00007986e0ddd8ac  push rsi
00007986e0ddd8ad  push r8
00007986e0ddd8af  push r9
00007986e0ddd8b1  push r10
00007986e0ddd8b3  push r11
00007986e0ddd8b5  sub rsp, 0xF0
00007986e0ddd8bc  vmovaps [rsp], xmm0
00007986e0ddd8c1  vmovaps [rsp+0x10], xmm1
00007986e0ddd8c7  vmovaps [rsp+0x20], xmm2
00007986e0ddd8cd  vmovaps [rsp+0x30], xmm3
00007986e0ddd8d3  vmovaps [rsp+0x40], xmm4
00007986e0ddd8d9  vmovaps [rsp+0x50], xmm5
00007986e0ddd8df  vmovaps [rsp+0x60], xmm6
00007986e0ddd8e5  vmovaps [rsp+0x70], xmm8
00007986e0ddd8eb  vmovaps [rsp+0x80], xmm9
00007986e0ddd8f4  vmovaps [rsp+0x90], xmm10
00007986e0ddd8fd  vmovaps [rsp+0xA0], xmm11
00007986e0ddd906  vmovaps [rsp+0xB0], xmm12
00007986e0ddd90f  vmovaps [rsp+0xC0], xmm13
00007986e0ddd918  vmovaps [rsp+0xD0], xmm14
00007986e0ddd921  vmovaps [rsp+0xE0], xmm15
00007986e0ddd92a  sub rsp, 0x30
00007986e0ddd92e  movaps [rsp], xmm7
00007986e0ddd932  movaps [rsp+0x10], xmm4
00007986e0ddd937  movaps [rsp+0x20], xmm9
00007986e0ddd93d  lea rdi, [rsp]
00007986e0ddd941  mov esi, 0x00
00007986e0ddd946  mov rax, 0x5652C689F530
00007986e0ddd950  call rax
00007986e0ddd952  movaps xmm7, [rsp]
00007986e0ddd956  add rsp, 0x30
00007986e0ddd95a  vmovaps xmm0, [rsp]
00007986e0ddd95f  vmovaps xmm1, [rsp+0x10]
00007986e0ddd965  vmovaps xmm2, [rsp+0x20]
00007986e0ddd96b  vmovaps xmm3, [rsp+0x30]
00007986e0ddd971  vmovaps xmm4, [rsp+0x40]
00007986e0ddd977  vmovaps xmm5, [rsp+0x50]
00007986e0ddd97d  vmovaps xmm6, [rsp+0x60]
00007986e0ddd983  vmovaps xmm8, [rsp+0x70]
00007986e0ddd989  vmovaps xmm9, [rsp+0x80]
00007986e0ddd992  vmovaps xmm10, [rsp+0x90]
00007986e0ddd99b  vmovaps xmm11, [rsp+0xA0]
00007986e0ddd9a4  vmovaps xmm12, [rsp+0xB0]
00007986e0ddd9ad  vmovaps xmm13, [rsp+0xC0]
00007986e0ddd9b6  vmovaps xmm14, [rsp+0xD0]
00007986e0ddd9bf  vmovaps xmm15, [rsp+0xE0]
00007986e0ddd9c8  add rsp, 0xF0
00007986e0ddd9cf  pop r11
00007986e0ddd9d1  pop r10
00007986e0ddd9d3  pop r9
00007986e0ddd9d5  pop r8
00007986e0ddd9d7  pop rsi
00007986e0ddd9d8  pop rdi
00007986e0ddd9d9  pop rdx
00007986e0ddd9da  pop rcx
00007986e0ddd9db  pop rax
00007986e0ddd9dc  add rsp, 0x08
00007986e0ddd9e0  jmp 0x00007986E0DDBE87
00007986e0ddd9e5  sub rsp, 0x08
00007986e0ddd9e9  push rax
00007986e0ddd9ea  push rcx
00007986e0ddd9eb  push rdx
00007986e0ddd9ec  push rdi
00007986e0ddd9ed  push rsi
00007986e0ddd9ee  push r8
00007986e0ddd9f0  push r9
00007986e0ddd9f2  push r10
00007986e0ddd9f4  push r11
00007986e0ddd9f6  sub rsp, 0xF0
00007986e0ddd9fd  vmovaps [rsp], xmm0
00007986e0ddda02  vmovaps [rsp+0x10], xmm1
00007986e0ddda08  vmovaps [rsp+0x20], xmm2
00007986e0ddda0e  vmovaps [rsp+0x30], xmm3
00007986e0ddda14  vmovaps [rsp+0x40], xmm5
00007986e0ddda1a  vmovaps [rsp+0x50], xmm6
00007986e0ddda20  vmovaps [rsp+0x60], xmm7
00007986e0ddda26  vmovaps [rsp+0x70], xmm8
00007986e0ddda2c  vmovaps [rsp+0x80], xmm9
00007986e0ddda35  vmovaps [rsp+0x90], xmm10
00007986e0ddda3e  vmovaps [rsp+0xA0], xmm11
00007986e0ddda47  vmovaps [rsp+0xB0], xmm12
00007986e0ddda50  vmovaps [rsp+0xC0], xmm13
00007986e0ddda59  vmovaps [rsp+0xD0], xmm14
00007986e0ddda62  vmovaps [rsp+0xE0], xmm15
00007986e0ddda6b  sub rsp, 0x30
00007986e0ddda6f  movaps [rsp], xmm4
00007986e0ddda73  movaps [rsp+0x10], xmm15
00007986e0ddda79  movaps [rsp+0x20], xmm9
00007986e0ddda7f  lea rdi, [rsp]
00007986e0ddda83  mov esi, 0x00
00007986e0ddda88  mov rax, 0x5652C689F530
00007986e0ddda92  call rax
00007986e0ddda94  movaps xmm4, [rsp]
00007986e0ddda98  add rsp, 0x30
00007986e0ddda9c  vmovaps xmm0, [rsp]
00007986e0dddaa1  vmovaps xmm1, [rsp+0x10]
00007986e0dddaa7  vmovaps xmm2, [rsp+0x20]
00007986e0dddaad  vmovaps xmm3, [rsp+0x30]
00007986e0dddab3  vmovaps xmm5, [rsp+0x40]
00007986e0dddab9  vmovaps xmm6, [rsp+0x50]
00007986e0dddabf  vmovaps xmm7, [rsp+0x60]
00007986e0dddac5  vmovaps xmm8, [rsp+0x70]
00007986e0dddacb  vmovaps xmm9, [rsp+0x80]
00007986e0dddad4  vmovaps xmm10, [rsp+0x90]
00007986e0dddadd  vmovaps xmm11, [rsp+0xA0]
00007986e0dddae6  vmovaps xmm12, [rsp+0xB0]
00007986e0dddaef  vmovaps xmm13, [rsp+0xC0]
00007986e0dddaf8  vmovaps xmm14, [rsp+0xD0]
00007986e0dddb01  vmovaps xmm15, [rsp+0xE0]
00007986e0dddb0a  add rsp, 0xF0
00007986e0dddb11  pop r11
00007986e0dddb13  pop r10
00007986e0dddb15  pop r9
00007986e0dddb17  pop r8
00007986e0dddb19  pop rsi
00007986e0dddb1a  pop rdi
00007986e0dddb1b  pop rdx
00007986e0dddb1c  pop rcx
00007986e0dddb1d  pop rax
00007986e0dddb1e  add rsp, 0x08
00007986e0dddb22  jmp 0x00007986E0DDBEAC
00007986e0dddb27  call 0x00007986E0CC4620
00007986e0dddb2c  jmp 0x00007986E0DDBEB9
00007986e0dddb31  sub rsp, 0x08
00007986e0dddb35  push rax
00007986e0dddb36  push rcx
00007986e0dddb37  push rdx
00007986e0dddb38  push rdi
00007986e0dddb39  push rsi
00007986e0dddb3a  push r8
00007986e0dddb3c  push r9
00007986e0dddb3e  push r10
00007986e0dddb40  push r11
00007986e0dddb42  sub rsp, 0xF0
00007986e0dddb49  vmovaps [rsp], xmm0
00007986e0dddb4e  vmovaps [rsp+0x10], xmm1
00007986e0dddb54  vmovaps [rsp+0x20], xmm2
00007986e0dddb5a  vmovaps [rsp+0x30], xmm4
00007986e0dddb60  vmovaps [rsp+0x40], xmm5
00007986e0dddb66  vmovaps [rsp+0x50], xmm6
00007986e0dddb6c  vmovaps [rsp+0x60], xmm7
00007986e0dddb72  vmovaps [rsp+0x70], xmm8
00007986e0dddb78  vmovaps [rsp+0x80], xmm9
00007986e0dddb81  vmovaps [rsp+0x90], xmm10
00007986e0dddb8a  vmovaps [rsp+0xA0], xmm11
00007986e0dddb93  vmovaps [rsp+0xB0], xmm12
00007986e0dddb9c  vmovaps [rsp+0xC0], xmm13
00007986e0dddba5  vmovaps [rsp+0xD0], xmm14
00007986e0dddbae  vmovaps [rsp+0xE0], xmm15
00007986e0dddbb7  sub rsp, 0x30
00007986e0dddbbb  movaps [rsp], xmm3
00007986e0dddbbf  movaps [rsp+0x10], xmm1
00007986e0dddbc4  movaps [rsp+0x20], xmm9
00007986e0dddbca  lea rdi, [rsp]
00007986e0dddbce  mov esi, 0x00
00007986e0dddbd3  mov rax, 0x5652C689F530
00007986e0dddbdd  call rax
00007986e0dddbdf  movaps xmm3, [rsp]
00007986e0dddbe3  add rsp, 0x30
00007986e0dddbe7  vmovaps xmm0, [rsp]
00007986e0dddbec  vmovaps xmm1, [rsp+0x10]
00007986e0dddbf2  vmovaps xmm2, [rsp+0x20]
00007986e0dddbf8  vmovaps xmm4, [rsp+0x30]
00007986e0dddbfe  vmovaps xmm5, [rsp+0x40]
00007986e0dddc04  vmovaps xmm6, [rsp+0x50]
00007986e0dddc0a  vmovaps xmm7, [rsp+0x60]
00007986e0dddc10  vmovaps xmm8, [rsp+0x70]
00007986e0dddc16  vmovaps xmm9, [rsp+0x80]
00007986e0dddc1f  vmovaps xmm10, [rsp+0x90]
00007986e0dddc28  vmovaps xmm11, [rsp+0xA0]
00007986e0dddc31  vmovaps xmm12, [rsp+0xB0]
00007986e0dddc3a  vmovaps xmm13, [rsp+0xC0]
00007986e0dddc43  vmovaps xmm14, [rsp+0xD0]
00007986e0dddc4c  vmovaps xmm15, [rsp+0xE0]
00007986e0dddc55  add rsp, 0xF0
00007986e0dddc5c  pop r11
00007986e0dddc5e  pop r10
00007986e0dddc60  pop r9
00007986e0dddc62  pop r8
00007986e0dddc64  pop rsi
00007986e0dddc65  pop rdi
00007986e0dddc66  pop rdx
00007986e0dddc67  pop rcx
00007986e0dddc68  pop rax
00007986e0dddc69  add rsp, 0x08
00007986e0dddc6d  jmp 0x00007986E0DDBEF6
00007986e0dddc72  sub rsp, 0x08
00007986e0dddc76  push rax
00007986e0dddc77  push rcx
00007986e0dddc78  push rdx
00007986e0dddc79  push rdi
00007986e0dddc7a  push rsi
00007986e0dddc7b  push r8
00007986e0dddc7d  push r9
00007986e0dddc7f  push r10
00007986e0dddc81  push r11
00007986e0dddc83  sub rsp, 0xF0
00007986e0dddc8a  vmovaps [rsp], xmm0
00007986e0dddc8f  vmovaps [rsp+0x10], xmm2
00007986e0dddc95  vmovaps [rsp+0x20], xmm3
00007986e0dddc9b  vmovaps [rsp+0x30], xmm4
00007986e0dddca1  vmovaps [rsp+0x40], xmm5
00007986e0dddca7  vmovaps [rsp+0x50], xmm6
00007986e0dddcad  vmovaps [rsp+0x60], xmm7
00007986e0dddcb3  vmovaps [rsp+0x70], xmm8
00007986e0dddcb9  vmovaps [rsp+0x80], xmm9
00007986e0dddcc2  vmovaps [rsp+0x90], xmm10
00007986e0dddccb  vmovaps [rsp+0xA0], xmm11
00007986e0dddcd4  vmovaps [rsp+0xB0], xmm12
00007986e0dddcdd  vmovaps [rsp+0xC0], xmm13
00007986e0dddce6  vmovaps [rsp+0xD0], xmm14
00007986e0dddcef  vmovaps [rsp+0xE0], xmm15
00007986e0dddcf8  sub rsp, 0x30
00007986e0dddcfc  movaps [rsp], xmm1
00007986e0dddd00  movaps [rsp+0x10], xmm15
00007986e0dddd06  movaps [rsp+0x20], xmm9
00007986e0dddd0c  lea rdi, [rsp]
00007986e0dddd10  mov esi, 0x00
00007986e0dddd15  mov rax, 0x5652C689F530
00007986e0dddd1f  call rax
00007986e0dddd21  movaps xmm1, [rsp]
00007986e0dddd25  add rsp, 0x30
00007986e0dddd29  vmovaps xmm0, [rsp]
00007986e0dddd2e  vmovaps xmm2, [rsp+0x10]
00007986e0dddd34  vmovaps xmm3, [rsp+0x20]
00007986e0dddd3a  vmovaps xmm4, [rsp+0x30]
00007986e0dddd40  vmovaps xmm5, [rsp+0x40]
00007986e0dddd46  vmovaps xmm6, [rsp+0x50]
00007986e0dddd4c  vmovaps xmm7, [rsp+0x60]
00007986e0dddd52  vmovaps xmm8, [rsp+0x70]
00007986e0dddd58  vmovaps xmm9, [rsp+0x80]
00007986e0dddd61  vmovaps xmm10, [rsp+0x90]
00007986e0dddd6a  vmovaps xmm11, [rsp+0xA0]
00007986e0dddd73  vmovaps xmm12, [rsp+0xB0]
00007986e0dddd7c  vmovaps xmm13, [rsp+0xC0]
00007986e0dddd85  vmovaps xmm14, [rsp+0xD0]
00007986e0dddd8e  vmovaps xmm15, [rsp+0xE0]
00007986e0dddd97  add rsp, 0xF0
00007986e0dddd9e  pop r11
00007986e0dddda0  pop r10
00007986e0dddda2  pop r9
00007986e0dddda4  pop r8
00007986e0dddda6  pop rsi
00007986e0dddda7  pop rdi
00007986e0dddda8  pop rdx
00007986e0dddda9  pop rcx
00007986e0ddddaa  pop rax
00007986e0ddddab  add rsp, 0x08
00007986e0ddddaf  jmp 0x00007986E0DDBF7E
00007986e0ddddb4  call 0x00007986E0CC4620
00007986e0ddddb9  jmp 0x00007986E0DDBF8B
00007986e0ddddbe  sub rsp, 0x08
00007986e0ddddc2  push rax
00007986e0ddddc3  push rcx
00007986e0ddddc4  push rdx
00007986e0ddddc5  push rdi
00007986e0ddddc6  push rsi
00007986e0ddddc7  push r8
00007986e0ddddc9  push r9
00007986e0ddddcb  push r10
00007986e0ddddcd  push r11
00007986e0ddddcf  sub rsp, 0xF0
00007986e0ddddd6  vmovaps [rsp], xmm0
00007986e0dddddb  vmovaps [rsp+0x10], xmm2
00007986e0dddde1  vmovaps [rsp+0x20], xmm3
00007986e0dddde7  vmovaps [rsp+0x30], xmm4
00007986e0dddded  vmovaps [rsp+0x40], xmm5
00007986e0ddddf3  vmovaps [rsp+0x50], xmm6
00007986e0ddddf9  vmovaps [rsp+0x60], xmm7
00007986e0ddddff  vmovaps [rsp+0x70], xmm8
00007986e0ddde05  vmovaps [rsp+0x80], xmm9
00007986e0ddde0e  vmovaps [rsp+0x90], xmm10
00007986e0ddde17  vmovaps [rsp+0xA0], xmm11
00007986e0ddde20  vmovaps [rsp+0xB0], xmm12
00007986e0ddde29  vmovaps [rsp+0xC0], xmm13
00007986e0ddde32  vmovaps [rsp+0xD0], xmm14
00007986e0ddde3b  vmovaps [rsp+0xE0], xmm15
00007986e0ddde44  sub rsp, 0x30
00007986e0ddde48  movaps [rsp], xmm1
00007986e0ddde4c  movaps [rsp+0x10], xmm5
00007986e0ddde51  movaps [rsp+0x20], xmm7
00007986e0ddde56  lea rdi, [rsp]
00007986e0ddde5a  mov esi, 0x00
00007986e0ddde5f  mov rax, 0x5652C689F530
00007986e0ddde69  call rax
00007986e0ddde6b  movaps xmm1, [rsp]
00007986e0ddde6f  add rsp, 0x30
00007986e0ddde73  vmovaps xmm0, [rsp]
00007986e0ddde78  vmovaps xmm2, [rsp+0x10]
00007986e0ddde7e  vmovaps xmm3, [rsp+0x20]
00007986e0ddde84  vmovaps xmm4, [rsp+0x30]
00007986e0ddde8a  vmovaps xmm5, [rsp+0x40]
00007986e0ddde90  vmovaps xmm6, [rsp+0x50]
00007986e0ddde96  vmovaps xmm7, [rsp+0x60]
00007986e0ddde9c  vmovaps xmm8, [rsp+0x70]
00007986e0dddea2  vmovaps xmm9, [rsp+0x80]
00007986e0dddeab  vmovaps xmm10, [rsp+0x90]
00007986e0dddeb4  vmovaps xmm11, [rsp+0xA0]
00007986e0dddebd  vmovaps xmm12, [rsp+0xB0]
00007986e0dddec6  vmovaps xmm13, [rsp+0xC0]
00007986e0dddecf  vmovaps xmm14, [rsp+0xD0]
00007986e0ddded8  vmovaps xmm15, [rsp+0xE0]
00007986e0dddee1  add rsp, 0xF0
00007986e0dddee8  pop r11
00007986e0dddeea  pop r10
00007986e0dddeec  pop r9
00007986e0dddeee  pop r8
00007986e0dddef0  pop rsi
00007986e0dddef1  pop rdi
00007986e0dddef2  pop rdx
00007986e0dddef3  pop rcx
00007986e0dddef4  pop rax
00007986e0dddef5  add rsp, 0x08
00007986e0dddef9  jmp 0x00007986E0DDC030
00007986e0dddefe  sub rsp, 0x08
00007986e0dddf02  push rax
00007986e0dddf03  push rcx
00007986e0dddf04  push rdx
00007986e0dddf05  push rdi
00007986e0dddf06  push rsi
00007986e0dddf07  push r8
00007986e0dddf09  push r9
00007986e0dddf0b  push r10
00007986e0dddf0d  push r11
00007986e0dddf0f  sub rsp, 0xF0
00007986e0dddf16  vmovaps [rsp], xmm0
00007986e0dddf1b  vmovaps [rsp+0x10], xmm1
00007986e0dddf21  vmovaps [rsp+0x20], xmm2
00007986e0dddf27  vmovaps [rsp+0x30], xmm3
00007986e0dddf2d  vmovaps [rsp+0x40], xmm4
00007986e0dddf33  vmovaps [rsp+0x50], xmm5
00007986e0dddf39  vmovaps [rsp+0x60], xmm6
00007986e0dddf3f  vmovaps [rsp+0x70], xmm8
00007986e0dddf45  vmovaps [rsp+0x80], xmm9
00007986e0dddf4e  vmovaps [rsp+0x90], xmm10
00007986e0dddf57  vmovaps [rsp+0xA0], xmm11
00007986e0dddf60  vmovaps [rsp+0xB0], xmm12
00007986e0dddf69  vmovaps [rsp+0xC0], xmm13
00007986e0dddf72  vmovaps [rsp+0xD0], xmm14
00007986e0dddf7b  vmovaps [rsp+0xE0], xmm15
00007986e0dddf84  sub rsp, 0x30
00007986e0dddf88  movaps [rsp], xmm7
00007986e0dddf8c  movaps [rsp+0x10], xmm5
00007986e0dddf91  movaps [rsp+0x20], xmm15
00007986e0dddf97  lea rdi, [rsp]
00007986e0dddf9b  mov esi, 0x00
00007986e0dddfa0  mov rax, 0x5652C689F530
00007986e0dddfaa  call rax
00007986e0dddfac  movaps xmm7, [rsp]
00007986e0dddfb0  add rsp, 0x30
00007986e0dddfb4  vmovaps xmm0, [rsp]
00007986e0dddfb9  vmovaps xmm1, [rsp+0x10]
00007986e0dddfbf  vmovaps xmm2, [rsp+0x20]
00007986e0dddfc5  vmovaps xmm3, [rsp+0x30]
00007986e0dddfcb  vmovaps xmm4, [rsp+0x40]
00007986e0dddfd1  vmovaps xmm5, [rsp+0x50]
00007986e0dddfd7  vmovaps xmm6, [rsp+0x60]
00007986e0dddfdd  vmovaps xmm8, [rsp+0x70]
00007986e0dddfe3  vmovaps xmm9, [rsp+0x80]
00007986e0dddfec  vmovaps xmm10, [rsp+0x90]
00007986e0dddff5  vmovaps xmm11, [rsp+0xA0]
00007986e0dddffe  vmovaps xmm12, [rsp+0xB0]
00007986e0dde007  vmovaps xmm13, [rsp+0xC0]
00007986e0dde010  vmovaps xmm14, [rsp+0xD0]
00007986e0dde019  vmovaps xmm15, [rsp+0xE0]
00007986e0dde022  add rsp, 0xF0
00007986e0dde029  pop r11
00007986e0dde02b  pop r10
00007986e0dde02d  pop r9
00007986e0dde02f  pop r8
00007986e0dde031  pop rsi
00007986e0dde032  pop rdi
00007986e0dde033  pop rdx
00007986e0dde034  pop rcx
00007986e0dde035  pop rax
00007986e0dde036  add rsp, 0x08
00007986e0dde03a  jmp 0x00007986E0DDC066
00007986e0dde03f  call 0x00007986E0CB52F0
00007986e0dde044  jmp 0x00007986E0DDC073
00007986e0dde049  sub rsp, 0x08
00007986e0dde04d  push rax
00007986e0dde04e  push rcx
00007986e0dde04f  push rdx
00007986e0dde050  push rdi
00007986e0dde051  push rsi
00007986e0dde052  push r8
00007986e0dde054  push r9
00007986e0dde056  push r10
00007986e0dde058  push r11
00007986e0dde05a  sub rsp, 0xF0
00007986e0dde061  vmovaps [rsp], xmm0
00007986e0dde066  vmovaps [rsp+0x10], xmm1
00007986e0dde06c  vmovaps [rsp+0x20], xmm2
00007986e0dde072  vmovaps [rsp+0x30], xmm3
00007986e0dde078  vmovaps [rsp+0x40], xmm4
00007986e0dde07e  vmovaps [rsp+0x50], xmm5
00007986e0dde084  vmovaps [rsp+0x60], xmm6
00007986e0dde08a  vmovaps [rsp+0x70], xmm7
00007986e0dde090  vmovaps [rsp+0x80], xmm8
00007986e0dde099  vmovaps [rsp+0x90], xmm9
00007986e0dde0a2  vmovaps [rsp+0xA0], xmm10
00007986e0dde0ab  vmovaps [rsp+0xB0], xmm11
00007986e0dde0b4  vmovaps [rsp+0xC0], xmm12
00007986e0dde0bd  vmovaps [rsp+0xD0], xmm13
00007986e0dde0c6  vmovaps [rsp+0xE0], xmm14
00007986e0dde0cf  sub rsp, 0x30
00007986e0dde0d3  movaps [rsp], xmm15
00007986e0dde0d8  movaps [rsp+0x10], xmm5
00007986e0dde0dd  movaps [rsp+0x20], xmm3
00007986e0dde0e2  lea rdi, [rsp]
00007986e0dde0e6  mov esi, 0x00
00007986e0dde0eb  mov rax, 0x5652C689F530
00007986e0dde0f5  call rax
00007986e0dde0f7  movaps xmm15, [rsp]
00007986e0dde0fc  add rsp, 0x30
00007986e0dde100  vmovaps xmm0, [rsp]
00007986e0dde105  vmovaps xmm1, [rsp+0x10]
00007986e0dde10b  vmovaps xmm2, [rsp+0x20]
00007986e0dde111  vmovaps xmm3, [rsp+0x30]
00007986e0dde117  vmovaps xmm4, [rsp+0x40]
00007986e0dde11d  vmovaps xmm5, [rsp+0x50]
00007986e0dde123  vmovaps xmm6, [rsp+0x60]
00007986e0dde129  vmovaps xmm7, [rsp+0x70]
00007986e0dde12f  vmovaps xmm8, [rsp+0x80]
00007986e0dde138  vmovaps xmm9, [rsp+0x90]
00007986e0dde141  vmovaps xmm10, [rsp+0xA0]
00007986e0dde14a  vmovaps xmm11, [rsp+0xB0]
00007986e0dde153  vmovaps xmm12, [rsp+0xC0]
00007986e0dde15c  vmovaps xmm13, [rsp+0xD0]
00007986e0dde165  vmovaps xmm14, [rsp+0xE0]
00007986e0dde16e  add rsp, 0xF0
00007986e0dde175  pop r11
00007986e0dde177  pop r10
00007986e0dde179  pop r9
00007986e0dde17b  pop r8
00007986e0dde17d  pop rsi
00007986e0dde17e  pop rdi
00007986e0dde17f  pop rdx
00007986e0dde180  pop rcx
00007986e0dde181  pop rax
00007986e0dde182  add rsp, 0x08
00007986e0dde186  jmp 0x00007986E0DDC099
00007986e0dde18b  sub rsp, 0x08
00007986e0dde18f  push rax
00007986e0dde190  push rcx
00007986e0dde191  push rdx
00007986e0dde192  push rdi
00007986e0dde193  push rsi
00007986e0dde194  push r8
00007986e0dde196  push r9
00007986e0dde198  push r10
00007986e0dde19a  push r11
00007986e0dde19c  sub rsp, 0xF0
00007986e0dde1a3  vmovaps [rsp], xmm0
00007986e0dde1a8  vmovaps [rsp+0x10], xmm2
00007986e0dde1ae  vmovaps [rsp+0x20], xmm3
00007986e0dde1b4  vmovaps [rsp+0x30], xmm4
00007986e0dde1ba  vmovaps [rsp+0x40], xmm5
00007986e0dde1c0  vmovaps [rsp+0x50], xmm6
00007986e0dde1c6  vmovaps [rsp+0x60], xmm7
00007986e0dde1cc  vmovaps [rsp+0x70], xmm8
00007986e0dde1d2  vmovaps [rsp+0x80], xmm9
00007986e0dde1db  vmovaps [rsp+0x90], xmm10
00007986e0dde1e4  vmovaps [rsp+0xA0], xmm11
00007986e0dde1ed  vmovaps [rsp+0xB0], xmm12
00007986e0dde1f6  vmovaps [rsp+0xC0], xmm13
00007986e0dde1ff  vmovaps [rsp+0xD0], xmm14
00007986e0dde208  vmovaps [rsp+0xE0], xmm15
00007986e0dde211  sub rsp, 0x30
00007986e0dde215  movaps [rsp], xmm1
00007986e0dde219  movaps [rsp+0x10], xmm5
00007986e0dde21e  movaps [rsp+0x20], xmm4
00007986e0dde223  lea rdi, [rsp]
00007986e0dde227  mov esi, 0x00
00007986e0dde22c  mov rax, 0x5652C689F530
00007986e0dde236  call rax
00007986e0dde238  movaps xmm1, [rsp]
00007986e0dde23c  add rsp, 0x30
00007986e0dde240  vmovaps xmm0, [rsp]
00007986e0dde245  vmovaps xmm2, [rsp+0x10]
00007986e0dde24b  vmovaps xmm3, [rsp+0x20]
00007986e0dde251  vmovaps xmm4, [rsp+0x30]
00007986e0dde257  vmovaps xmm5, [rsp+0x40]
00007986e0dde25d  vmovaps xmm6, [rsp+0x50]
00007986e0dde263  vmovaps xmm7, [rsp+0x60]
00007986e0dde269  vmovaps xmm8, [rsp+0x70]
00007986e0dde26f  vmovaps xmm9, [rsp+0x80]
00007986e0dde278  vmovaps xmm10, [rsp+0x90]
00007986e0dde281  vmovaps xmm11, [rsp+0xA0]
00007986e0dde28a  vmovaps xmm12, [rsp+0xB0]
00007986e0dde293  vmovaps xmm13, [rsp+0xC0]
00007986e0dde29c  vmovaps xmm14, [rsp+0xD0]
00007986e0dde2a5  vmovaps xmm15, [rsp+0xE0]
00007986e0dde2ae  add rsp, 0xF0
00007986e0dde2b5  pop r11
00007986e0dde2b7  pop r10
00007986e0dde2b9  pop r9
00007986e0dde2bb  pop r8
00007986e0dde2bd  pop rsi
00007986e0dde2be  pop rdi
00007986e0dde2bf  pop rdx
00007986e0dde2c0  pop rcx
00007986e0dde2c1  pop rax
00007986e0dde2c2  add rsp, 0x08
00007986e0dde2c6  jmp 0x00007986E0DDC0B9
00007986e0dde2cb  sub rsp, 0x08
00007986e0dde2cf  push rax
00007986e0dde2d0  push rcx
00007986e0dde2d1  push rdx
00007986e0dde2d2  push rdi
00007986e0dde2d3  push rsi
00007986e0dde2d4  push r8
00007986e0dde2d6  push r9
00007986e0dde2d8  push r10
00007986e0dde2da  push r11
00007986e0dde2dc  sub rsp, 0xF0
00007986e0dde2e3  vmovaps [rsp], xmm0
00007986e0dde2e8  vmovaps [rsp+0x10], xmm1
00007986e0dde2ee  vmovaps [rsp+0x20], xmm2
00007986e0dde2f4  vmovaps [rsp+0x30], xmm3
00007986e0dde2fa  vmovaps [rsp+0x40], xmm5
00007986e0dde300  vmovaps [rsp+0x50], xmm6
00007986e0dde306  vmovaps [rsp+0x60], xmm7
00007986e0dde30c  vmovaps [rsp+0x70], xmm8
00007986e0dde312  vmovaps [rsp+0x80], xmm9
00007986e0dde31b  vmovaps [rsp+0x90], xmm10
00007986e0dde324  vmovaps [rsp+0xA0], xmm11
00007986e0dde32d  vmovaps [rsp+0xB0], xmm12
00007986e0dde336  vmovaps [rsp+0xC0], xmm13
00007986e0dde33f  vmovaps [rsp+0xD0], xmm14
00007986e0dde348  vmovaps [rsp+0xE0], xmm15
00007986e0dde351  sub rsp, 0x30
00007986e0dde355  movaps [rsp], xmm4
00007986e0dde359  movaps [rsp+0x10], xmm3
00007986e0dde35e  movaps [rsp+0x20], xmm5
00007986e0dde363  lea rdi, [rsp]
00007986e0dde367  mov esi, 0x00
00007986e0dde36c  mov rax, 0x5652C689F530
00007986e0dde376  call rax
00007986e0dde378  movaps xmm4, [rsp]
00007986e0dde37c  add rsp, 0x30
00007986e0dde380  vmovaps xmm0, [rsp]
00007986e0dde385  vmovaps xmm1, [rsp+0x10]
00007986e0dde38b  vmovaps xmm2, [rsp+0x20]
00007986e0dde391  vmovaps xmm3, [rsp+0x30]
00007986e0dde397  vmovaps xmm5, [rsp+0x40]
00007986e0dde39d  vmovaps xmm6, [rsp+0x50]
00007986e0dde3a3  vmovaps xmm7, [rsp+0x60]
00007986e0dde3a9  vmovaps xmm8, [rsp+0x70]
00007986e0dde3af  vmovaps xmm9, [rsp+0x80]
00007986e0dde3b8  vmovaps xmm10, [rsp+0x90]
00007986e0dde3c1  vmovaps xmm11, [rsp+0xA0]
00007986e0dde3ca  vmovaps xmm12, [rsp+0xB0]
00007986e0dde3d3  vmovaps xmm13, [rsp+0xC0]
00007986e0dde3dc  vmovaps xmm14, [rsp+0xD0]
00007986e0dde3e5  vmovaps xmm15, [rsp+0xE0]
00007986e0dde3ee  add rsp, 0xF0
00007986e0dde3f5  pop r11
00007986e0dde3f7  pop r10
00007986e0dde3f9  pop r9
00007986e0dde3fb  pop r8
00007986e0dde3fd  pop rsi
00007986e0dde3fe  pop rdi
00007986e0dde3ff  pop rdx
00007986e0dde400  pop rcx
00007986e0dde401  pop rax
00007986e0dde402  add rsp, 0x08
00007986e0dde406  jmp 0x00007986E0DDC107
00007986e0dde40b  call 0x00007986E0CB52F0
00007986e0dde410  jmp 0x00007986E0DDC114
00007986e0dde415  sub rsp, 0x08
00007986e0dde419  push rax
00007986e0dde41a  push rcx
00007986e0dde41b  push rdx
00007986e0dde41c  push rdi
00007986e0dde41d  push rsi
00007986e0dde41e  push r8
00007986e0dde420  push r9
00007986e0dde422  push r10
00007986e0dde424  push r11
00007986e0dde426  sub rsp, 0xF0
00007986e0dde42d  vmovaps [rsp], xmm0
00007986e0dde432  vmovaps [rsp+0x10], xmm1
00007986e0dde438  vmovaps [rsp+0x20], xmm2
00007986e0dde43e  vmovaps [rsp+0x30], xmm3
00007986e0dde444  vmovaps [rsp+0x40], xmm4
00007986e0dde44a  vmovaps [rsp+0x50], xmm6
00007986e0dde450  vmovaps [rsp+0x60], xmm7
00007986e0dde456  vmovaps [rsp+0x70], xmm8
00007986e0dde45c  vmovaps [rsp+0x80], xmm9
00007986e0dde465  vmovaps [rsp+0x90], xmm10
00007986e0dde46e  vmovaps [rsp+0xA0], xmm11
00007986e0dde477  vmovaps [rsp+0xB0], xmm12
00007986e0dde480  vmovaps [rsp+0xC0], xmm13
00007986e0dde489  vmovaps [rsp+0xD0], xmm14
00007986e0dde492  vmovaps [rsp+0xE0], xmm15
00007986e0dde49b  sub rsp, 0x30
00007986e0dde49f  movaps [rsp], xmm5
00007986e0dde4a3  movaps [rsp+0x10], xmm6
00007986e0dde4a8  movaps [rsp+0x20], xmm3
00007986e0dde4ad  lea rdi, [rsp]
00007986e0dde4b1  mov esi, 0x00
00007986e0dde4b6  mov rax, 0x5652C689F530
00007986e0dde4c0  call rax
00007986e0dde4c2  movaps xmm5, [rsp]
00007986e0dde4c6  add rsp, 0x30
00007986e0dde4ca  vmovaps xmm0, [rsp]
00007986e0dde4cf  vmovaps xmm1, [rsp+0x10]
00007986e0dde4d5  vmovaps xmm2, [rsp+0x20]
00007986e0dde4db  vmovaps xmm3, [rsp+0x30]
00007986e0dde4e1  vmovaps xmm4, [rsp+0x40]
00007986e0dde4e7  vmovaps xmm6, [rsp+0x50]
00007986e0dde4ed  vmovaps xmm7, [rsp+0x60]
00007986e0dde4f3  vmovaps xmm8, [rsp+0x70]
00007986e0dde4f9  vmovaps xmm9, [rsp+0x80]
00007986e0dde502  vmovaps xmm10, [rsp+0x90]
00007986e0dde50b  vmovaps xmm11, [rsp+0xA0]
00007986e0dde514  vmovaps xmm12, [rsp+0xB0]
00007986e0dde51d  vmovaps xmm13, [rsp+0xC0]
00007986e0dde526  vmovaps xmm14, [rsp+0xD0]
00007986e0dde52f  vmovaps xmm15, [rsp+0xE0]
00007986e0dde538  add rsp, 0xF0
00007986e0dde53f  pop r11
00007986e0dde541  pop r10
00007986e0dde543  pop r9
00007986e0dde545  pop r8
00007986e0dde547  pop rsi
00007986e0dde548  pop rdi
00007986e0dde549  pop rdx
00007986e0dde54a  pop rcx
00007986e0dde54b  pop rax
00007986e0dde54c  add rsp, 0x08
00007986e0dde550  jmp 0x00007986E0DDC13A
00007986e0dde555  sub rsp, 0x08
00007986e0dde559  push rax
00007986e0dde55a  push rcx
00007986e0dde55b  push rdx
00007986e0dde55c  push rdi
00007986e0dde55d  push rsi
00007986e0dde55e  push r8
00007986e0dde560  push r9
00007986e0dde562  push r10
00007986e0dde564  push r11
00007986e0dde566  sub rsp, 0xF0
00007986e0dde56d  vmovaps [rsp], xmm0
00007986e0dde572  vmovaps [rsp+0x10], xmm1
00007986e0dde578  vmovaps [rsp+0x20], xmm2
00007986e0dde57e  vmovaps [rsp+0x30], xmm3
00007986e0dde584  vmovaps [rsp+0x40], xmm4
00007986e0dde58a  vmovaps [rsp+0x50], xmm5
00007986e0dde590  vmovaps [rsp+0x60], xmm7
00007986e0dde596  vmovaps [rsp+0x70], xmm8
00007986e0dde59c  vmovaps [rsp+0x80], xmm9
00007986e0dde5a5  vmovaps [rsp+0x90], xmm10
00007986e0dde5ae  vmovaps [rsp+0xA0], xmm11
00007986e0dde5b7  vmovaps [rsp+0xB0], xmm12
00007986e0dde5c0  vmovaps [rsp+0xC0], xmm13
00007986e0dde5c9  vmovaps [rsp+0xD0], xmm14
00007986e0dde5d2  vmovaps [rsp+0xE0], xmm15
00007986e0dde5db  sub rsp, 0x30
00007986e0dde5df  movaps [rsp], xmm6
00007986e0dde5e3  movaps [rsp+0x10], xmm9
00007986e0dde5e9  movaps [rsp+0x20], xmm1
00007986e0dde5ee  lea rdi, [rsp]
00007986e0dde5f2  mov esi, 0x00
00007986e0dde5f7  mov rax, 0x5652C689F530
00007986e0dde601  call rax
00007986e0dde603  movaps xmm6, [rsp]
00007986e0dde607  add rsp, 0x30
00007986e0dde60b  vmovaps xmm0, [rsp]
00007986e0dde610  vmovaps xmm1, [rsp+0x10]
00007986e0dde616  vmovaps xmm2, [rsp+0x20]
00007986e0dde61c  vmovaps xmm3, [rsp+0x30]
00007986e0dde622  vmovaps xmm4, [rsp+0x40]
00007986e0dde628  vmovaps xmm5, [rsp+0x50]
00007986e0dde62e  vmovaps xmm7, [rsp+0x60]
00007986e0dde634  vmovaps xmm8, [rsp+0x70]
00007986e0dde63a  vmovaps xmm9, [rsp+0x80]
00007986e0dde643  vmovaps xmm10, [rsp+0x90]
00007986e0dde64c  vmovaps xmm11, [rsp+0xA0]
00007986e0dde655  vmovaps xmm12, [rsp+0xB0]
00007986e0dde65e  vmovaps xmm13, [rsp+0xC0]
00007986e0dde667  vmovaps xmm14, [rsp+0xD0]
00007986e0dde670  vmovaps xmm15, [rsp+0xE0]
00007986e0dde679  add rsp, 0xF0
00007986e0dde680  pop r11
00007986e0dde682  pop r10
00007986e0dde684  pop r9
00007986e0dde686  pop r8
00007986e0dde688  pop rsi
00007986e0dde689  pop rdi
00007986e0dde68a  pop rdx
00007986e0dde68b  pop rcx
00007986e0dde68c  pop rax
00007986e0dde68d  add rsp, 0x08
00007986e0dde691  jmp 0x00007986E0DDC15E
00007986e0dde696  sub rsp, 0x08
00007986e0dde69a  push rax
00007986e0dde69b  push rcx
00007986e0dde69c  push rdx
00007986e0dde69d  push rdi
00007986e0dde69e  push rsi
00007986e0dde69f  push r8
00007986e0dde6a1  push r9
00007986e0dde6a3  push r10
00007986e0dde6a5  push r11
00007986e0dde6a7  sub rsp, 0xF0
00007986e0dde6ae  vmovaps [rsp], xmm0
00007986e0dde6b3  vmovaps [rsp+0x10], xmm1
00007986e0dde6b9  vmovaps [rsp+0x20], xmm2
00007986e0dde6bf  vmovaps [rsp+0x30], xmm3
00007986e0dde6c5  vmovaps [rsp+0x40], xmm4
00007986e0dde6cb  vmovaps [rsp+0x50], xmm5
00007986e0dde6d1  vmovaps [rsp+0x60], xmm6
00007986e0dde6d7  vmovaps [rsp+0x70], xmm7
00007986e0dde6dd  vmovaps [rsp+0x80], xmm8
00007986e0dde6e6  vmovaps [rsp+0x90], xmm10
00007986e0dde6ef  vmovaps [rsp+0xA0], xmm11
00007986e0dde6f8  vmovaps [rsp+0xB0], xmm12
00007986e0dde701  vmovaps [rsp+0xC0], xmm13
00007986e0dde70a  vmovaps [rsp+0xD0], xmm14
00007986e0dde713  vmovaps [rsp+0xE0], xmm15
00007986e0dde71c  sub rsp, 0x30
00007986e0dde720  movaps [rsp], xmm9
00007986e0dde725  movaps [rsp+0x10], xmm3
00007986e0dde72a  movaps [rsp+0x20], xmm1
00007986e0dde72f  lea rdi, [rsp]
00007986e0dde733  mov esi, 0x00
00007986e0dde738  mov rax, 0x5652C689F530
00007986e0dde742  call rax
00007986e0dde744  movaps xmm9, [rsp]
00007986e0dde749  add rsp, 0x30
00007986e0dde74d  vmovaps xmm0, [rsp]
00007986e0dde752  vmovaps xmm1, [rsp+0x10]
00007986e0dde758  vmovaps xmm2, [rsp+0x20]
00007986e0dde75e  vmovaps xmm3, [rsp+0x30]
00007986e0dde764  vmovaps xmm4, [rsp+0x40]
00007986e0dde76a  vmovaps xmm5, [rsp+0x50]
00007986e0dde770  vmovaps xmm6, [rsp+0x60]
00007986e0dde776  vmovaps xmm7, [rsp+0x70]
00007986e0dde77c  vmovaps xmm8, [rsp+0x80]
00007986e0dde785  vmovaps xmm10, [rsp+0x90]
00007986e0dde78e  vmovaps xmm11, [rsp+0xA0]
00007986e0dde797  vmovaps xmm12, [rsp+0xB0]
00007986e0dde7a0  vmovaps xmm13, [rsp+0xC0]
00007986e0dde7a9  vmovaps xmm14, [rsp+0xD0]
00007986e0dde7b2  vmovaps xmm15, [rsp+0xE0]
00007986e0dde7bb  add rsp, 0xF0
00007986e0dde7c2  pop r11
00007986e0dde7c4  pop r10
00007986e0dde7c6  pop r9
00007986e0dde7c8  pop r8
00007986e0dde7ca  pop rsi
00007986e0dde7cb  pop rdi
00007986e0dde7cc  pop rdx
00007986e0dde7cd  pop rcx
00007986e0dde7ce  pop rax
00007986e0dde7cf  add rsp, 0x08
00007986e0dde7d3  jmp 0x00007986E0DDC1AA
00007986e0dde7d8  call 0x00007986E0CB52F0
00007986e0dde7dd  jmp 0x00007986E0DDC1B7
00007986e0dde7e2  sub rsp, 0x08
00007986e0dde7e6  push rax
00007986e0dde7e7  push rcx
00007986e0dde7e8  push rdx
00007986e0dde7e9  push rdi
00007986e0dde7ea  push rsi
00007986e0dde7eb  push r8
00007986e0dde7ed  push r9
00007986e0dde7ef  push r10
00007986e0dde7f1  push r11
00007986e0dde7f3  sub rsp, 0xF0
00007986e0dde7fa  vmovaps [rsp], xmm0
00007986e0dde7ff  vmovaps [rsp+0x10], xmm1
00007986e0dde805  vmovaps [rsp+0x20], xmm2
00007986e0dde80b  vmovaps [rsp+0x30], xmm3
00007986e0dde811  vmovaps [rsp+0x40], xmm4
00007986e0dde817  vmovaps [rsp+0x50], xmm5
00007986e0dde81d  vmovaps [rsp+0x60], xmm6
00007986e0dde823  vmovaps [rsp+0x70], xmm7
00007986e0dde829  vmovaps [rsp+0x80], xmm8
00007986e0dde832  vmovaps [rsp+0x90], xmm9
00007986e0dde83b  vmovaps [rsp+0xA0], xmm10
00007986e0dde844  vmovaps [rsp+0xB0], xmm11
00007986e0dde84d  vmovaps [rsp+0xC0], xmm12
00007986e0dde856  vmovaps [rsp+0xD0], xmm13
00007986e0dde85f  vmovaps [rsp+0xE0], xmm14
00007986e0dde868  sub rsp, 0x30
00007986e0dde86c  movaps [rsp], xmm15
00007986e0dde871  movaps [rsp+0x10], xmm3
00007986e0dde876  movaps [rsp+0x20], xmm7
00007986e0dde87b  lea rdi, [rsp]
00007986e0dde87f  mov esi, 0x00
00007986e0dde884  mov rax, 0x5652C689F530
00007986e0dde88e  call rax
00007986e0dde890  movaps xmm15, [rsp]
00007986e0dde895  add rsp, 0x30
00007986e0dde899  vmovaps xmm0, [rsp]
00007986e0dde89e  vmovaps xmm1, [rsp+0x10]
00007986e0dde8a4  vmovaps xmm2, [rsp+0x20]
00007986e0dde8aa  vmovaps xmm3, [rsp+0x30]
00007986e0dde8b0  vmovaps xmm4, [rsp+0x40]
00007986e0dde8b6  vmovaps xmm5, [rsp+0x50]
00007986e0dde8bc  vmovaps xmm6, [rsp+0x60]
00007986e0dde8c2  vmovaps xmm7, [rsp+0x70]
00007986e0dde8c8  vmovaps xmm8, [rsp+0x80]
00007986e0dde8d1  vmovaps xmm9, [rsp+0x90]
00007986e0dde8da  vmovaps xmm10, [rsp+0xA0]
00007986e0dde8e3  vmovaps xmm11, [rsp+0xB0]
00007986e0dde8ec  vmovaps xmm12, [rsp+0xC0]
00007986e0dde8f5  vmovaps xmm13, [rsp+0xD0]
00007986e0dde8fe  vmovaps xmm14, [rsp+0xE0]
00007986e0dde907  add rsp, 0xF0
00007986e0dde90e  pop r11
00007986e0dde910  pop r10
00007986e0dde912  pop r9
00007986e0dde914  pop r8
00007986e0dde916  pop rsi
00007986e0dde917  pop rdi
00007986e0dde918  pop rdx
00007986e0dde919  pop rcx
00007986e0dde91a  pop rax
00007986e0dde91b  add rsp, 0x08
00007986e0dde91f  jmp 0x00007986E0DDC1E3
00007986e0dde924  sub rsp, 0x08
00007986e0dde928  push rax
00007986e0dde929  push rcx
00007986e0dde92a  push rdx
00007986e0dde92b  push rdi
00007986e0dde92c  push rsi
00007986e0dde92d  push r8
00007986e0dde92f  push r9
00007986e0dde931  push r10
00007986e0dde933  push r11
00007986e0dde935  sub rsp, 0xF0
00007986e0dde93c  vmovaps [rsp], xmm0
00007986e0dde941  vmovaps [rsp+0x10], xmm1
00007986e0dde947  vmovaps [rsp+0x20], xmm2
00007986e0dde94d  vmovaps [rsp+0x30], xmm4
00007986e0dde953  vmovaps [rsp+0x40], xmm5
00007986e0dde959  vmovaps [rsp+0x50], xmm6
00007986e0dde95f  vmovaps [rsp+0x60], xmm7
00007986e0dde965  vmovaps [rsp+0x70], xmm8
00007986e0dde96b  vmovaps [rsp+0x80], xmm9
00007986e0dde974  vmovaps [rsp+0x90], xmm10
00007986e0dde97d  vmovaps [rsp+0xA0], xmm11
00007986e0dde986  vmovaps [rsp+0xB0], xmm12
00007986e0dde98f  vmovaps [rsp+0xC0], xmm13
00007986e0dde998  vmovaps [rsp+0xD0], xmm14
00007986e0dde9a1  vmovaps [rsp+0xE0], xmm15
00007986e0dde9aa  sub rsp, 0x30
00007986e0dde9ae  movaps [rsp], xmm3
00007986e0dde9b2  movaps [rsp+0x10], xmm1
00007986e0dde9b7  movaps [rsp+0x20], xmm15
00007986e0dde9bd  lea rdi, [rsp]
00007986e0dde9c1  mov esi, 0x00
00007986e0dde9c6  mov rax, 0x5652C689F530
00007986e0dde9d0  call rax
00007986e0dde9d2  movaps xmm3, [rsp]
00007986e0dde9d6  add rsp, 0x30
00007986e0dde9da  vmovaps xmm0, [rsp]
00007986e0dde9df  vmovaps xmm1, [rsp+0x10]
00007986e0dde9e5  vmovaps xmm2, [rsp+0x20]
00007986e0dde9eb  vmovaps xmm4, [rsp+0x30]
00007986e0dde9f1  vmovaps xmm5, [rsp+0x40]
00007986e0dde9f7  vmovaps xmm6, [rsp+0x50]
00007986e0dde9fd  vmovaps xmm7, [rsp+0x60]
00007986e0ddea03  vmovaps xmm8, [rsp+0x70]
00007986e0ddea09  vmovaps xmm9, [rsp+0x80]
00007986e0ddea12  vmovaps xmm10, [rsp+0x90]
00007986e0ddea1b  vmovaps xmm11, [rsp+0xA0]
00007986e0ddea24  vmovaps xmm12, [rsp+0xB0]
00007986e0ddea2d  vmovaps xmm13, [rsp+0xC0]
00007986e0ddea36  vmovaps xmm14, [rsp+0xD0]
00007986e0ddea3f  vmovaps xmm15, [rsp+0xE0]
00007986e0ddea48  add rsp, 0xF0
00007986e0ddea4f  pop r11
00007986e0ddea51  pop r10
00007986e0ddea53  pop r9
00007986e0ddea55  pop r8
00007986e0ddea57  pop rsi
00007986e0ddea58  pop rdi
00007986e0ddea59  pop rdx
00007986e0ddea5a  pop rcx
00007986e0ddea5b  pop rax
00007986e0ddea5c  add rsp, 0x08
00007986e0ddea60  jmp 0x00007986E0DDC272
00007986e0ddea65  call 0x00007986E0CB52F0
00007986e0ddea6a  jmp 0x00007986E0DDC27C
00007986e0ddea6f  sub rsp, 0x08
00007986e0ddea73  push rax
00007986e0ddea74  push rcx
00007986e0ddea75  push rdx
00007986e0ddea76  push rdi
00007986e0ddea77  push rsi
00007986e0ddea78  push r8
00007986e0ddea7a  push r9
00007986e0ddea7c  push r10
00007986e0ddea7e  push r11
00007986e0ddea80  sub rsp, 0xF0
00007986e0ddea87  vmovaps [rsp], xmm0
00007986e0ddea8c  vmovaps [rsp+0x10], xmm1
00007986e0ddea92  vmovaps [rsp+0x20], xmm2
00007986e0ddea98  vmovaps [rsp+0x30], xmm3
00007986e0ddea9e  vmovaps [rsp+0x40], xmm4
00007986e0ddeaa4  vmovaps [rsp+0x50], xmm5
00007986e0ddeaaa  vmovaps [rsp+0x60], xmm6
00007986e0ddeab0  vmovaps [rsp+0x70], xmm7
00007986e0ddeab6  vmovaps [rsp+0x80], xmm8
00007986e0ddeabf  vmovaps [rsp+0x90], xmm9
00007986e0ddeac8  vmovaps [rsp+0xA0], xmm10
00007986e0ddead1  vmovaps [rsp+0xB0], xmm11
00007986e0ddeada  vmovaps [rsp+0xC0], xmm12
00007986e0ddeae3  vmovaps [rsp+0xD0], xmm13
00007986e0ddeaec  vmovaps [rsp+0xE0], xmm14
00007986e0ddeaf5  sub rsp, 0x30
00007986e0ddeaf9  movaps [rsp], xmm15
00007986e0ddeafe  movaps [rsp+0x10], xmm14
00007986e0ddeb04  movaps [rsp+0x20], xmm4
00007986e0ddeb09  lea rdi, [rsp]
00007986e0ddeb0d  mov esi, 0x00
00007986e0ddeb12  mov rax, 0x5652C689F530
00007986e0ddeb1c  call rax
00007986e0ddeb1e  movaps xmm15, [rsp]
00007986e0ddeb23  add rsp, 0x30
00007986e0ddeb27  vmovaps xmm0, [rsp]
00007986e0ddeb2c  vmovaps xmm1, [rsp+0x10]
00007986e0ddeb32  vmovaps xmm2, [rsp+0x20]
00007986e0ddeb38  vmovaps xmm3, [rsp+0x30]
00007986e0ddeb3e  vmovaps xmm4, [rsp+0x40]
00007986e0ddeb44  vmovaps xmm5, [rsp+0x50]
00007986e0ddeb4a  vmovaps xmm6, [rsp+0x60]
00007986e0ddeb50  vmovaps xmm7, [rsp+0x70]
00007986e0ddeb56  vmovaps xmm8, [rsp+0x80]
00007986e0ddeb5f  vmovaps xmm9, [rsp+0x90]
00007986e0ddeb68  vmovaps xmm10, [rsp+0xA0]
00007986e0ddeb71  vmovaps xmm11, [rsp+0xB0]
00007986e0ddeb7a  vmovaps xmm12, [rsp+0xC0]
00007986e0ddeb83  vmovaps xmm13, [rsp+0xD0]
00007986e0ddeb8c  vmovaps xmm14, [rsp+0xE0]
00007986e0ddeb95  add rsp, 0xF0
00007986e0ddeb9c  pop r11
00007986e0ddeb9e  pop r10
00007986e0ddeba0  pop r9
00007986e0ddeba2  pop r8
00007986e0ddeba4  pop rsi
00007986e0ddeba5  pop rdi
00007986e0ddeba6  pop rdx
00007986e0ddeba7  pop rcx
00007986e0ddeba8  pop rax
00007986e0ddeba9  add rsp, 0x08
00007986e0ddebad  jmp 0x00007986E0DDC2AA
00007986e0ddebb2  sub rsp, 0x08
00007986e0ddebb6  push rax
00007986e0ddebb7  push rcx
00007986e0ddebb8  push rdx
00007986e0ddebb9  push rdi
00007986e0ddebba  push rsi
00007986e0ddebbb  push r8
00007986e0ddebbd  push r9
00007986e0ddebbf  push r10
00007986e0ddebc1  push r11
00007986e0ddebc3  sub rsp, 0xF0
00007986e0ddebca  vmovaps [rsp], xmm0
00007986e0ddebcf  vmovaps [rsp+0x10], xmm1
00007986e0ddebd5  vmovaps [rsp+0x20], xmm2
00007986e0ddebdb  vmovaps [rsp+0x30], xmm3
00007986e0ddebe1  vmovaps [rsp+0x40], xmm4
00007986e0ddebe7  vmovaps [rsp+0x50], xmm5
00007986e0ddebed  vmovaps [rsp+0x60], xmm6
00007986e0ddebf3  vmovaps [rsp+0x70], xmm7
00007986e0ddebf9  vmovaps [rsp+0x80], xmm8
00007986e0ddec02  vmovaps [rsp+0x90], xmm9
00007986e0ddec0b  vmovaps [rsp+0xA0], xmm10
00007986e0ddec14  vmovaps [rsp+0xB0], xmm11
00007986e0ddec1d  vmovaps [rsp+0xC0], xmm12
00007986e0ddec26  vmovaps [rsp+0xD0], xmm13
00007986e0ddec2f  vmovaps [rsp+0xE0], xmm15
00007986e0ddec38  sub rsp, 0x30
00007986e0ddec3c  movaps [rsp], xmm14
00007986e0ddec41  movaps [rsp+0x10], xmm2
00007986e0ddec46  movaps [rsp+0x20], xmm1
00007986e0ddec4b  lea rdi, [rsp]
00007986e0ddec4f  mov esi, 0x00
00007986e0ddec54  mov rax, 0x5652C689F530
00007986e0ddec5e  call rax
00007986e0ddec60  movaps xmm14, [rsp]
00007986e0ddec65  add rsp, 0x30
00007986e0ddec69  vmovaps xmm0, [rsp]
00007986e0ddec6e  vmovaps xmm1, [rsp+0x10]
00007986e0ddec74  vmovaps xmm2, [rsp+0x20]
00007986e0ddec7a  vmovaps xmm3, [rsp+0x30]
00007986e0ddec80  vmovaps xmm4, [rsp+0x40]
00007986e0ddec86  vmovaps xmm5, [rsp+0x50]
00007986e0ddec8c  vmovaps xmm6, [rsp+0x60]
00007986e0ddec92  vmovaps xmm7, [rsp+0x70]
00007986e0ddec98  vmovaps xmm8, [rsp+0x80]
00007986e0ddeca1  vmovaps xmm9, [rsp+0x90]
00007986e0ddecaa  vmovaps xmm10, [rsp+0xA0]
00007986e0ddecb3  vmovaps xmm11, [rsp+0xB0]
00007986e0ddecbc  vmovaps xmm12, [rsp+0xC0]
00007986e0ddecc5  vmovaps xmm13, [rsp+0xD0]
00007986e0ddecce  vmovaps xmm15, [rsp+0xE0]
00007986e0ddecd7  add rsp, 0xF0
00007986e0ddecde  pop r11
00007986e0ddece0  pop r10
00007986e0ddece2  pop r9
00007986e0ddece4  pop r8
00007986e0ddece6  pop rsi
00007986e0ddece7  pop rdi
00007986e0ddece8  pop rdx
00007986e0ddece9  pop rcx
00007986e0ddecea  pop rax
00007986e0ddeceb  add rsp, 0x08
00007986e0ddecef  jmp 0x00007986E0DDC2D0
00007986e0ddecf4  sub rsp, 0x08
00007986e0ddecf8  push rax
00007986e0ddecf9  push rcx
00007986e0ddecfa  push rdx
00007986e0ddecfb  push rdi
00007986e0ddecfc  push rsi
00007986e0ddecfd  push r8
00007986e0ddecff  push r9
00007986e0dded01  push r10
00007986e0dded03  push r11
00007986e0dded05  sub rsp, 0xF0
00007986e0dded0c  vmovaps [rsp], xmm0
00007986e0dded11  vmovaps [rsp+0x10], xmm2
00007986e0dded17  vmovaps [rsp+0x20], xmm3
00007986e0dded1d  vmovaps [rsp+0x30], xmm4
00007986e0dded23  vmovaps [rsp+0x40], xmm5
00007986e0dded29  vmovaps [rsp+0x50], xmm6
00007986e0dded2f  vmovaps [rsp+0x60], xmm7
00007986e0dded35  vmovaps [rsp+0x70], xmm8
00007986e0dded3b  vmovaps [rsp+0x80], xmm9
00007986e0dded44  vmovaps [rsp+0x90], xmm10
00007986e0dded4d  vmovaps [rsp+0xA0], xmm11
00007986e0dded56  vmovaps [rsp+0xB0], xmm12
00007986e0dded5f  vmovaps [rsp+0xC0], xmm13
00007986e0dded68  vmovaps [rsp+0xD0], xmm14
00007986e0dded71  vmovaps [rsp+0xE0], xmm15
00007986e0dded7a  sub rsp, 0x30
00007986e0dded7e  movaps [rsp], xmm1
00007986e0dded82  movaps [rsp+0x10], xmm4
00007986e0dded87  movaps [rsp+0x20], xmm9
00007986e0dded8d  lea rdi, [rsp]
00007986e0dded91  mov esi, 0x00
00007986e0dded96  mov rax, 0x5652C689F530
00007986e0ddeda0  call rax
00007986e0ddeda2  movaps xmm1, [rsp]
00007986e0ddeda6  add rsp, 0x30
00007986e0ddedaa  vmovaps xmm0, [rsp]
00007986e0ddedaf  vmovaps xmm2, [rsp+0x10]
00007986e0ddedb5  vmovaps xmm3, [rsp+0x20]
00007986e0ddedbb  vmovaps xmm4, [rsp+0x30]
00007986e0ddedc1  vmovaps xmm5, [rsp+0x40]
00007986e0ddedc7  vmovaps xmm6, [rsp+0x50]
00007986e0ddedcd  vmovaps xmm7, [rsp+0x60]
00007986e0ddedd3  vmovaps xmm8, [rsp+0x70]
00007986e0ddedd9  vmovaps xmm9, [rsp+0x80]
00007986e0ddede2  vmovaps xmm10, [rsp+0x90]
00007986e0ddedeb  vmovaps xmm11, [rsp+0xA0]
00007986e0ddedf4  vmovaps xmm12, [rsp+0xB0]
00007986e0ddedfd  vmovaps xmm13, [rsp+0xC0]
00007986e0ddee06  vmovaps xmm14, [rsp+0xD0]
00007986e0ddee0f  vmovaps xmm15, [rsp+0xE0]
00007986e0ddee18  add rsp, 0xF0
00007986e0ddee1f  pop r11
00007986e0ddee21  pop r10
00007986e0ddee23  pop r9
00007986e0ddee25  pop r8
00007986e0ddee27  pop rsi
00007986e0ddee28  pop rdi
00007986e0ddee29  pop rdx
00007986e0ddee2a  pop rcx
00007986e0ddee2b  pop rax
00007986e0ddee2c  add rsp, 0x08
00007986e0ddee30  jmp 0x00007986E0DDC2EE
00007986e0ddee35  sub rsp, 0x08
00007986e0ddee39  push rax
00007986e0ddee3a  push rcx
00007986e0ddee3b  push rdx
00007986e0ddee3c  push rdi
00007986e0ddee3d  push rsi
00007986e0ddee3e  push r8
00007986e0ddee40  push r9
00007986e0ddee42  push r10
00007986e0ddee44  push r11
00007986e0ddee46  sub rsp, 0xF0
00007986e0ddee4d  vmovaps [rsp], xmm0
00007986e0ddee52  vmovaps [rsp+0x10], xmm1
00007986e0ddee58  vmovaps [rsp+0x20], xmm2
00007986e0ddee5e  vmovaps [rsp+0x30], xmm3
00007986e0ddee64  vmovaps [rsp+0x40], xmm5
00007986e0ddee6a  vmovaps [rsp+0x50], xmm6
00007986e0ddee70  vmovaps [rsp+0x60], xmm7
00007986e0ddee76  vmovaps [rsp+0x70], xmm8
00007986e0ddee7c  vmovaps [rsp+0x80], xmm9
00007986e0ddee85  vmovaps [rsp+0x90], xmm10
00007986e0ddee8e  vmovaps [rsp+0xA0], xmm11
00007986e0ddee97  vmovaps [rsp+0xB0], xmm12
00007986e0ddeea0  vmovaps [rsp+0xC0], xmm13
00007986e0ddeea9  vmovaps [rsp+0xD0], xmm14
00007986e0ddeeb2  vmovaps [rsp+0xE0], xmm15
00007986e0ddeebb  sub rsp, 0x30
00007986e0ddeebf  movaps [rsp], xmm4
00007986e0ddeec3  movaps [rsp+0x10], xmm2
00007986e0ddeec8  movaps [rsp+0x20], xmm9
00007986e0ddeece  lea rdi, [rsp]
00007986e0ddeed2  mov esi, 0x00
00007986e0ddeed7  mov rax, 0x5652C689F530
00007986e0ddeee1  call rax
00007986e0ddeee3  movaps xmm4, [rsp]
00007986e0ddeee7  add rsp, 0x30
00007986e0ddeeeb  vmovaps xmm0, [rsp]
00007986e0ddeef0  vmovaps xmm1, [rsp+0x10]
00007986e0ddeef6  vmovaps xmm2, [rsp+0x20]
00007986e0ddeefc  vmovaps xmm3, [rsp+0x30]
00007986e0ddef02  vmovaps xmm5, [rsp+0x40]
00007986e0ddef08  vmovaps xmm6, [rsp+0x50]
00007986e0ddef0e  vmovaps xmm7, [rsp+0x60]
00007986e0ddef14  vmovaps xmm8, [rsp+0x70]
00007986e0ddef1a  vmovaps xmm9, [rsp+0x80]
00007986e0ddef23  vmovaps xmm10, [rsp+0x90]
00007986e0ddef2c  vmovaps xmm11, [rsp+0xA0]
00007986e0ddef35  vmovaps xmm12, [rsp+0xB0]
00007986e0ddef3e  vmovaps xmm13, [rsp+0xC0]
00007986e0ddef47  vmovaps xmm14, [rsp+0xD0]
00007986e0ddef50  vmovaps xmm15, [rsp+0xE0]
00007986e0ddef59  add rsp, 0xF0
00007986e0ddef60  pop r11
00007986e0ddef62  pop r10
00007986e0ddef64  pop r9
00007986e0ddef66  pop r8
00007986e0ddef68  pop rsi
00007986e0ddef69  pop rdi
00007986e0ddef6a  pop rdx
00007986e0ddef6b  pop rcx
00007986e0ddef6c  pop rax
00007986e0ddef6d  add rsp, 0x08
00007986e0ddef71  jmp 0x00007986E0DDC31E
00007986e0ddef76  sub rsp, 0x08
00007986e0ddef7a  push rax
00007986e0ddef7b  push rcx
00007986e0ddef7c  push rdx
00007986e0ddef7d  push rdi
00007986e0ddef7e  push rsi
00007986e0ddef7f  push r8
00007986e0ddef81  push r9
00007986e0ddef83  push r10
00007986e0ddef85  push r11
00007986e0ddef87  sub rsp, 0xF0
00007986e0ddef8e  vmovaps [rsp], xmm0
00007986e0ddef93  vmovaps [rsp+0x10], xmm1
00007986e0ddef99  vmovaps [rsp+0x20], xmm2
00007986e0ddef9f  vmovaps [rsp+0x30], xmm3
00007986e0ddefa5  vmovaps [rsp+0x40], xmm4
00007986e0ddefab  vmovaps [rsp+0x50], xmm5
00007986e0ddefb1  vmovaps [rsp+0x60], xmm6
00007986e0ddefb7  vmovaps [rsp+0x70], xmm7
00007986e0ddefbd  vmovaps [rsp+0x80], xmm8
00007986e0ddefc6  vmovaps [rsp+0x90], xmm10
00007986e0ddefcf  vmovaps [rsp+0xA0], xmm11
00007986e0ddefd8  vmovaps [rsp+0xB0], xmm12
00007986e0ddefe1  vmovaps [rsp+0xC0], xmm13
00007986e0ddefea  vmovaps [rsp+0xD0], xmm14
00007986e0ddeff3  vmovaps [rsp+0xE0], xmm15
00007986e0ddeffc  sub rsp, 0x30
00007986e0ddf000  movaps [rsp], xmm9
00007986e0ddf005  movaps [rsp+0x10], xmm2
00007986e0ddf00a  movaps [rsp+0x20], xmm1
00007986e0ddf00f  lea rdi, [rsp]
00007986e0ddf013  mov esi, 0x00
00007986e0ddf018  mov rax, 0x5652C689F530
00007986e0ddf022  call rax
00007986e0ddf024  movaps xmm9, [rsp]
00007986e0ddf029  add rsp, 0x30
00007986e0ddf02d  vmovaps xmm0, [rsp]
00007986e0ddf032  vmovaps xmm1, [rsp+0x10]
00007986e0ddf038  vmovaps xmm2, [rsp+0x20]
00007986e0ddf03e  vmovaps xmm3, [rsp+0x30]
00007986e0ddf044  vmovaps xmm4, [rsp+0x40]
00007986e0ddf04a  vmovaps xmm5, [rsp+0x50]
00007986e0ddf050  vmovaps xmm6, [rsp+0x60]
00007986e0ddf056  vmovaps xmm7, [rsp+0x70]
00007986e0ddf05c  vmovaps xmm8, [rsp+0x80]
00007986e0ddf065  vmovaps xmm10, [rsp+0x90]
00007986e0ddf06e  vmovaps xmm11, [rsp+0xA0]
00007986e0ddf077  vmovaps xmm12, [rsp+0xB0]
00007986e0ddf080  vmovaps xmm13, [rsp+0xC0]
00007986e0ddf089  vmovaps xmm14, [rsp+0xD0]
00007986e0ddf092  vmovaps xmm15, [rsp+0xE0]
00007986e0ddf09b  add rsp, 0xF0
00007986e0ddf0a2  pop r11
00007986e0ddf0a4  pop r10
00007986e0ddf0a6  pop r9
00007986e0ddf0a8  pop r8
00007986e0ddf0aa  pop rsi
00007986e0ddf0ab  pop rdi
00007986e0ddf0ac  pop rdx
00007986e0ddf0ad  pop rcx
00007986e0ddf0ae  pop rax
00007986e0ddf0af  add rsp, 0x08
00007986e0ddf0b3  jmp 0x00007986E0DDC354
00007986e0ddf0b8  sub rsp, 0x08
00007986e0ddf0bc  push rax
00007986e0ddf0bd  push rcx
00007986e0ddf0be  push rdx
00007986e0ddf0bf  push rdi
00007986e0ddf0c0  push rsi
00007986e0ddf0c1  push r8
00007986e0ddf0c3  push r9
00007986e0ddf0c5  push r10
00007986e0ddf0c7  push r11
00007986e0ddf0c9  sub rsp, 0xF0
00007986e0ddf0d0  vmovaps [rsp], xmm0
00007986e0ddf0d5  vmovaps [rsp+0x10], xmm2
00007986e0ddf0db  vmovaps [rsp+0x20], xmm3
00007986e0ddf0e1  vmovaps [rsp+0x30], xmm4
00007986e0ddf0e7  vmovaps [rsp+0x40], xmm5
00007986e0ddf0ed  vmovaps [rsp+0x50], xmm6
00007986e0ddf0f3  vmovaps [rsp+0x60], xmm7
00007986e0ddf0f9  vmovaps [rsp+0x70], xmm8
00007986e0ddf0ff  vmovaps [rsp+0x80], xmm9
00007986e0ddf108  vmovaps [rsp+0x90], xmm10
00007986e0ddf111  vmovaps [rsp+0xA0], xmm11
00007986e0ddf11a  vmovaps [rsp+0xB0], xmm12
00007986e0ddf123  vmovaps [rsp+0xC0], xmm13
00007986e0ddf12c  vmovaps [rsp+0xD0], xmm14
00007986e0ddf135  vmovaps [rsp+0xE0], xmm15
00007986e0ddf13e  sub rsp, 0x30
00007986e0ddf142  movaps [rsp], xmm1
00007986e0ddf146  movaps [rsp+0x10], xmm15
00007986e0ddf14c  movaps [rsp+0x20], xmm6
00007986e0ddf151  lea rdi, [rsp]
00007986e0ddf155  mov esi, 0x00
00007986e0ddf15a  mov rax, 0x5652C689F530
00007986e0ddf164  call rax
00007986e0ddf166  movaps xmm1, [rsp]
00007986e0ddf16a  add rsp, 0x30
00007986e0ddf16e  vmovaps xmm0, [rsp]
00007986e0ddf173  vmovaps xmm2, [rsp+0x10]
00007986e0ddf179  vmovaps xmm3, [rsp+0x20]
00007986e0ddf17f  vmovaps xmm4, [rsp+0x30]
00007986e0ddf185  vmovaps xmm5, [rsp+0x40]
00007986e0ddf18b  vmovaps xmm6, [rsp+0x50]
00007986e0ddf191  vmovaps xmm7, [rsp+0x60]
00007986e0ddf197  vmovaps xmm8, [rsp+0x70]
00007986e0ddf19d  vmovaps xmm9, [rsp+0x80]
00007986e0ddf1a6  vmovaps xmm10, [rsp+0x90]
00007986e0ddf1af  vmovaps xmm11, [rsp+0xA0]
00007986e0ddf1b8  vmovaps xmm12, [rsp+0xB0]
00007986e0ddf1c1  vmovaps xmm13, [rsp+0xC0]
00007986e0ddf1ca  vmovaps xmm14, [rsp+0xD0]
00007986e0ddf1d3  vmovaps xmm15, [rsp+0xE0]
00007986e0ddf1dc  add rsp, 0xF0
00007986e0ddf1e3  pop r11
00007986e0ddf1e5  pop r10
00007986e0ddf1e7  pop r9
00007986e0ddf1e9  pop r8
00007986e0ddf1eb  pop rsi
00007986e0ddf1ec  pop rdi
00007986e0ddf1ed  pop rdx
00007986e0ddf1ee  pop rcx
00007986e0ddf1ef  pop rax
00007986e0ddf1f0  add rsp, 0x08
00007986e0ddf1f4  jmp 0x00007986E0DDC375
00007986e0ddf1f9  sub rsp, 0x08
00007986e0ddf1fd  push rax
00007986e0ddf1fe  push rcx
00007986e0ddf1ff  push rdx
00007986e0ddf200  push rdi
00007986e0ddf201  push rsi
00007986e0ddf202  push r8
00007986e0ddf204  push r9
00007986e0ddf206  push r10
00007986e0ddf208  push r11
00007986e0ddf20a  sub rsp, 0xF0
00007986e0ddf211  vmovaps [rsp], xmm0
00007986e0ddf216  vmovaps [rsp+0x10], xmm1
00007986e0ddf21c  vmovaps [rsp+0x20], xmm2
00007986e0ddf222  vmovaps [rsp+0x30], xmm3
00007986e0ddf228  vmovaps [rsp+0x40], xmm4
00007986e0ddf22e  vmovaps [rsp+0x50], xmm5
00007986e0ddf234  vmovaps [rsp+0x60], xmm6
00007986e0ddf23a  vmovaps [rsp+0x70], xmm7
00007986e0ddf240  vmovaps [rsp+0x80], xmm8
00007986e0ddf249  vmovaps [rsp+0x90], xmm9
00007986e0ddf252  vmovaps [rsp+0xA0], xmm10
00007986e0ddf25b  vmovaps [rsp+0xB0], xmm11
00007986e0ddf264  vmovaps [rsp+0xC0], xmm12
00007986e0ddf26d  vmovaps [rsp+0xD0], xmm13
00007986e0ddf276  vmovaps [rsp+0xE0], xmm14
00007986e0ddf27f  sub rsp, 0x30
00007986e0ddf283  movaps [rsp], xmm15
00007986e0ddf288  movaps [rsp+0x10], xmm5
00007986e0ddf28d  movaps [rsp+0x20], xmm3
00007986e0ddf292  lea rdi, [rsp]
00007986e0ddf296  mov esi, 0x00
00007986e0ddf29b  mov rax, 0x5652C689F530
00007986e0ddf2a5  call rax
00007986e0ddf2a7  movaps xmm15, [rsp]
00007986e0ddf2ac  add rsp, 0x30
00007986e0ddf2b0  vmovaps xmm0, [rsp]
00007986e0ddf2b5  vmovaps xmm1, [rsp+0x10]
00007986e0ddf2bb  vmovaps xmm2, [rsp+0x20]
00007986e0ddf2c1  vmovaps xmm3, [rsp+0x30]
00007986e0ddf2c7  vmovaps xmm4, [rsp+0x40]
00007986e0ddf2cd  vmovaps xmm5, [rsp+0x50]
00007986e0ddf2d3  vmovaps xmm6, [rsp+0x60]
00007986e0ddf2d9  vmovaps xmm7, [rsp+0x70]
00007986e0ddf2df  vmovaps xmm8, [rsp+0x80]
00007986e0ddf2e8  vmovaps xmm9, [rsp+0x90]
00007986e0ddf2f1  vmovaps xmm10, [rsp+0xA0]
00007986e0ddf2fa  vmovaps xmm11, [rsp+0xB0]
00007986e0ddf303  vmovaps xmm12, [rsp+0xC0]
00007986e0ddf30c  vmovaps xmm13, [rsp+0xD0]
00007986e0ddf315  vmovaps xmm14, [rsp+0xE0]
00007986e0ddf31e  add rsp, 0xF0
00007986e0ddf325  pop r11
00007986e0ddf327  pop r10
00007986e0ddf329  pop r9
00007986e0ddf32b  pop r8
00007986e0ddf32d  pop rsi
00007986e0ddf32e  pop rdi
00007986e0ddf32f  pop rdx
00007986e0ddf330  pop rcx
00007986e0ddf331  pop rax
00007986e0ddf332  add rsp, 0x08
00007986e0ddf336  jmp 0x00007986E0DDC38F
00007986e0ddf33b  sub rsp, 0x08
00007986e0ddf33f  push rax
00007986e0ddf340  push rcx
00007986e0ddf341  push rdx
00007986e0ddf342  push rdi
00007986e0ddf343  push rsi
00007986e0ddf344  push r8
00007986e0ddf346  push r9
00007986e0ddf348  push r10
00007986e0ddf34a  push r11
00007986e0ddf34c  sub rsp, 0xF0
00007986e0ddf353  vmovaps [rsp], xmm0
00007986e0ddf358  vmovaps [rsp+0x10], xmm1
00007986e0ddf35e  vmovaps [rsp+0x20], xmm2
00007986e0ddf364  vmovaps [rsp+0x30], xmm3
00007986e0ddf36a  vmovaps [rsp+0x40], xmm4
00007986e0ddf370  vmovaps [rsp+0x50], xmm6
00007986e0ddf376  vmovaps [rsp+0x60], xmm7
00007986e0ddf37c  vmovaps [rsp+0x70], xmm8
00007986e0ddf382  vmovaps [rsp+0x80], xmm9
00007986e0ddf38b  vmovaps [rsp+0x90], xmm10
00007986e0ddf394  vmovaps [rsp+0xA0], xmm11
00007986e0ddf39d  vmovaps [rsp+0xB0], xmm12
00007986e0ddf3a6  vmovaps [rsp+0xC0], xmm13
00007986e0ddf3af  vmovaps [rsp+0xD0], xmm14
00007986e0ddf3b8  vmovaps [rsp+0xE0], xmm15
00007986e0ddf3c1  sub rsp, 0x30
00007986e0ddf3c5  movaps [rsp], xmm5
00007986e0ddf3c9  movaps [rsp+0x10], xmm8
00007986e0ddf3cf  movaps [rsp+0x20], xmm6
00007986e0ddf3d4  lea rdi, [rsp]
00007986e0ddf3d8  mov esi, 0x00
00007986e0ddf3dd  mov rax, 0x5652C689F530
00007986e0ddf3e7  call rax
00007986e0ddf3e9  movaps xmm5, [rsp]
00007986e0ddf3ed  add rsp, 0x30
00007986e0ddf3f1  vmovaps xmm0, [rsp]
00007986e0ddf3f6  vmovaps xmm1, [rsp+0x10]
00007986e0ddf3fc  vmovaps xmm2, [rsp+0x20]
00007986e0ddf402  vmovaps xmm3, [rsp+0x30]
00007986e0ddf408  vmovaps xmm4, [rsp+0x40]
00007986e0ddf40e  vmovaps xmm6, [rsp+0x50]
00007986e0ddf414  vmovaps xmm7, [rsp+0x60]
00007986e0ddf41a  vmovaps xmm8, [rsp+0x70]
00007986e0ddf420  vmovaps xmm9, [rsp+0x80]
00007986e0ddf429  vmovaps xmm10, [rsp+0x90]
00007986e0ddf432  vmovaps xmm11, [rsp+0xA0]
00007986e0ddf43b  vmovaps xmm12, [rsp+0xB0]
00007986e0ddf444  vmovaps xmm13, [rsp+0xC0]
00007986e0ddf44d  vmovaps xmm14, [rsp+0xD0]
00007986e0ddf456  vmovaps xmm15, [rsp+0xE0]
00007986e0ddf45f  add rsp, 0xF0
00007986e0ddf466  pop r11
00007986e0ddf468  pop r10
00007986e0ddf46a  pop r9
00007986e0ddf46c  pop r8
00007986e0ddf46e  pop rsi
00007986e0ddf46f  pop rdi
00007986e0ddf470  pop rdx
00007986e0ddf471  pop rcx
00007986e0ddf472  pop rax
00007986e0ddf473  add rsp, 0x08
00007986e0ddf477  jmp 0x00007986E0DDC3B3
00007986e0ddf47c  sub rsp, 0x08
00007986e0ddf480  push rax
00007986e0ddf481  push rcx
00007986e0ddf482  push rdx
00007986e0ddf483  push rdi
00007986e0ddf484  push rsi
00007986e0ddf485  push r8
00007986e0ddf487  push r9
00007986e0ddf489  push r10
00007986e0ddf48b  push r11
00007986e0ddf48d  sub rsp, 0xF0
00007986e0ddf494  vmovaps [rsp], xmm0
00007986e0ddf499  vmovaps [rsp+0x10], xmm1
00007986e0ddf49f  vmovaps [rsp+0x20], xmm2
00007986e0ddf4a5  vmovaps [rsp+0x30], xmm3
00007986e0ddf4ab  vmovaps [rsp+0x40], xmm4
00007986e0ddf4b1  vmovaps [rsp+0x50], xmm5
00007986e0ddf4b7  vmovaps [rsp+0x60], xmm7
00007986e0ddf4bd  vmovaps [rsp+0x70], xmm8
00007986e0ddf4c3  vmovaps [rsp+0x80], xmm9
00007986e0ddf4cc  vmovaps [rsp+0x90], xmm10
00007986e0ddf4d5  vmovaps [rsp+0xA0], xmm11
00007986e0ddf4de  vmovaps [rsp+0xB0], xmm12
00007986e0ddf4e7  vmovaps [rsp+0xC0], xmm13
00007986e0ddf4f0  vmovaps [rsp+0xD0], xmm14
00007986e0ddf4f9  vmovaps [rsp+0xE0], xmm15
00007986e0ddf502  sub rsp, 0x30
00007986e0ddf506  movaps [rsp], xmm6
00007986e0ddf50a  movaps [rsp+0x10], xmm10
00007986e0ddf510  movaps [rsp+0x20], xmm8
00007986e0ddf516  lea rdi, [rsp]
00007986e0ddf51a  mov esi, 0x00
00007986e0ddf51f  mov rax, 0x5652C689F530
00007986e0ddf529  call rax
00007986e0ddf52b  movaps xmm6, [rsp]
00007986e0ddf52f  add rsp, 0x30
00007986e0ddf533  vmovaps xmm0, [rsp]
00007986e0ddf538  vmovaps xmm1, [rsp+0x10]
00007986e0ddf53e  vmovaps xmm2, [rsp+0x20]
00007986e0ddf544  vmovaps xmm3, [rsp+0x30]
00007986e0ddf54a  vmovaps xmm4, [rsp+0x40]
00007986e0ddf550  vmovaps xmm5, [rsp+0x50]
00007986e0ddf556  vmovaps xmm7, [rsp+0x60]
00007986e0ddf55c  vmovaps xmm8, [rsp+0x70]
00007986e0ddf562  vmovaps xmm9, [rsp+0x80]
00007986e0ddf56b  vmovaps xmm10, [rsp+0x90]
00007986e0ddf574  vmovaps xmm11, [rsp+0xA0]
00007986e0ddf57d  vmovaps xmm12, [rsp+0xB0]
00007986e0ddf586  vmovaps xmm13, [rsp+0xC0]
00007986e0ddf58f  vmovaps xmm14, [rsp+0xD0]
00007986e0ddf598  vmovaps xmm15, [rsp+0xE0]
00007986e0ddf5a1  add rsp, 0xF0
00007986e0ddf5a8  pop r11
00007986e0ddf5aa  pop r10
00007986e0ddf5ac  pop r9
00007986e0ddf5ae  pop r8
00007986e0ddf5b0  pop rsi
00007986e0ddf5b1  pop rdi
00007986e0ddf5b2  pop rdx
00007986e0ddf5b3  pop rcx
00007986e0ddf5b4  pop rax
00007986e0ddf5b5  add rsp, 0x08
00007986e0ddf5b9  jmp 0x00007986E0DDC3D8
00007986e0ddf5be  sub rsp, 0x08
00007986e0ddf5c2  push rax
00007986e0ddf5c3  push rcx
00007986e0ddf5c4  push rdx
00007986e0ddf5c5  push rdi
00007986e0ddf5c6  push rsi
00007986e0ddf5c7  push r8
00007986e0ddf5c9  push r9
00007986e0ddf5cb  push r10
00007986e0ddf5cd  push r11
00007986e0ddf5cf  sub rsp, 0xF0
00007986e0ddf5d6  vmovaps [rsp], xmm0
00007986e0ddf5db  vmovaps [rsp+0x10], xmm1
00007986e0ddf5e1  vmovaps [rsp+0x20], xmm2
00007986e0ddf5e7  vmovaps [rsp+0x30], xmm3
00007986e0ddf5ed  vmovaps [rsp+0x40], xmm4
00007986e0ddf5f3  vmovaps [rsp+0x50], xmm5
00007986e0ddf5f9  vmovaps [rsp+0x60], xmm6
00007986e0ddf5ff  vmovaps [rsp+0x70], xmm7
00007986e0ddf605  vmovaps [rsp+0x80], xmm8
00007986e0ddf60e  vmovaps [rsp+0x90], xmm9
00007986e0ddf617  vmovaps [rsp+0xA0], xmm11
00007986e0ddf620  vmovaps [rsp+0xB0], xmm12
00007986e0ddf629  vmovaps [rsp+0xC0], xmm13
00007986e0ddf632  vmovaps [rsp+0xD0], xmm14
00007986e0ddf63b  vmovaps [rsp+0xE0], xmm15
00007986e0ddf644  sub rsp, 0x30
00007986e0ddf648  movaps [rsp], xmm10
00007986e0ddf64d  movaps [rsp+0x10], xmm8
00007986e0ddf653  movaps [rsp+0x20], xmm14
00007986e0ddf659  lea rdi, [rsp]
00007986e0ddf65d  mov esi, 0x00
00007986e0ddf662  mov rax, 0x5652C689F530
00007986e0ddf66c  call rax
00007986e0ddf66e  movaps xmm10, [rsp]
00007986e0ddf673  add rsp, 0x30
00007986e0ddf677  vmovaps xmm0, [rsp]
00007986e0ddf67c  vmovaps xmm1, [rsp+0x10]
00007986e0ddf682  vmovaps xmm2, [rsp+0x20]
00007986e0ddf688  vmovaps xmm3, [rsp+0x30]
00007986e0ddf68e  vmovaps xmm4, [rsp+0x40]
00007986e0ddf694  vmovaps xmm5, [rsp+0x50]
00007986e0ddf69a  vmovaps xmm6, [rsp+0x60]
00007986e0ddf6a0  vmovaps xmm7, [rsp+0x70]
00007986e0ddf6a6  vmovaps xmm8, [rsp+0x80]
00007986e0ddf6af  vmovaps xmm9, [rsp+0x90]
00007986e0ddf6b8  vmovaps xmm11, [rsp+0xA0]
00007986e0ddf6c1  vmovaps xmm12, [rsp+0xB0]
00007986e0ddf6ca  vmovaps xmm13, [rsp+0xC0]
00007986e0ddf6d3  vmovaps xmm14, [rsp+0xD0]
00007986e0ddf6dc  vmovaps xmm15, [rsp+0xE0]
00007986e0ddf6e5  add rsp, 0xF0
00007986e0ddf6ec  pop r11
00007986e0ddf6ee  pop r10
00007986e0ddf6f0  pop r9
00007986e0ddf6f2  pop r8
00007986e0ddf6f4  pop rsi
00007986e0ddf6f5  pop rdi
00007986e0ddf6f6  pop rdx
00007986e0ddf6f7  pop rcx
00007986e0ddf6f8  pop rax
00007986e0ddf6f9  add rsp, 0x08
00007986e0ddf6fd  jmp 0x00007986E0DDC3F8
00007986e0ddf702  sub rsp, 0x08
00007986e0ddf706  push rax
00007986e0ddf707  push rcx
00007986e0ddf708  push rdx
00007986e0ddf709  push rdi
00007986e0ddf70a  push rsi
00007986e0ddf70b  push r8
00007986e0ddf70d  push r9
00007986e0ddf70f  push r10
00007986e0ddf711  push r11
00007986e0ddf713  sub rsp, 0xF0
00007986e0ddf71a  vmovaps [rsp], xmm0
00007986e0ddf71f  vmovaps [rsp+0x10], xmm1
00007986e0ddf725  vmovaps [rsp+0x20], xmm2
00007986e0ddf72b  vmovaps [rsp+0x30], xmm3
00007986e0ddf731  vmovaps [rsp+0x40], xmm4
00007986e0ddf737  vmovaps [rsp+0x50], xmm5
00007986e0ddf73d  vmovaps [rsp+0x60], xmm6
00007986e0ddf743  vmovaps [rsp+0x70], xmm7
00007986e0ddf749  vmovaps [rsp+0x80], xmm8
00007986e0ddf752  vmovaps [rsp+0x90], xmm9
00007986e0ddf75b  vmovaps [rsp+0xA0], xmm10
00007986e0ddf764  vmovaps [rsp+0xB0], xmm11
00007986e0ddf76d  vmovaps [rsp+0xC0], xmm12
00007986e0ddf776  vmovaps [rsp+0xD0], xmm13
00007986e0ddf77f  vmovaps [rsp+0xE0], xmm15
00007986e0ddf788  sub rsp, 0x30
00007986e0ddf78c  movaps [rsp], xmm14
00007986e0ddf791  movaps [rsp+0x10], xmm8
00007986e0ddf797  movaps [rsp+0x20], xmm4
00007986e0ddf79c  lea rdi, [rsp]
00007986e0ddf7a0  mov esi, 0x00
00007986e0ddf7a5  mov rax, 0x5652C689F530
00007986e0ddf7af  call rax
00007986e0ddf7b1  movaps xmm14, [rsp]
00007986e0ddf7b6  add rsp, 0x30
00007986e0ddf7ba  vmovaps xmm0, [rsp]
00007986e0ddf7bf  vmovaps xmm1, [rsp+0x10]
00007986e0ddf7c5  vmovaps xmm2, [rsp+0x20]
00007986e0ddf7cb  vmovaps xmm3, [rsp+0x30]
00007986e0ddf7d1  vmovaps xmm4, [rsp+0x40]
00007986e0ddf7d7  vmovaps xmm5, [rsp+0x50]
00007986e0ddf7dd  vmovaps xmm6, [rsp+0x60]
00007986e0ddf7e3  vmovaps xmm7, [rsp+0x70]
00007986e0ddf7e9  vmovaps xmm8, [rsp+0x80]
00007986e0ddf7f2  vmovaps xmm9, [rsp+0x90]
00007986e0ddf7fb  vmovaps xmm10, [rsp+0xA0]
00007986e0ddf804  vmovaps xmm11, [rsp+0xB0]
00007986e0ddf80d  vmovaps xmm12, [rsp+0xC0]
00007986e0ddf816  vmovaps xmm13, [rsp+0xD0]
00007986e0ddf81f  vmovaps xmm15, [rsp+0xE0]
00007986e0ddf828  add rsp, 0xF0
00007986e0ddf82f  pop r11
00007986e0ddf831  pop r10
00007986e0ddf833  pop r9
00007986e0ddf835  pop r8
00007986e0ddf837  pop rsi
00007986e0ddf838  pop rdi
00007986e0ddf839  pop rdx
00007986e0ddf83a  pop rcx
00007986e0ddf83b  pop rax
00007986e0ddf83c  add rsp, 0x08
00007986e0ddf840  jmp 0x00007986E0DDC418
00007986e0ddf845  sub rsp, 0x08
00007986e0ddf849  push rax
00007986e0ddf84a  push rcx
00007986e0ddf84b  push rdx
00007986e0ddf84c  push rdi
00007986e0ddf84d  push rsi
00007986e0ddf84e  push r8
00007986e0ddf850  push r9
00007986e0ddf852  push r10
00007986e0ddf854  push r11
00007986e0ddf856  sub rsp, 0xF0
00007986e0ddf85d  vmovaps [rsp], xmm0
00007986e0ddf862  vmovaps [rsp+0x10], xmm1
00007986e0ddf868  vmovaps [rsp+0x20], xmm2
00007986e0ddf86e  vmovaps [rsp+0x30], xmm3
00007986e0ddf874  vmovaps [rsp+0x40], xmm5
00007986e0ddf87a  vmovaps [rsp+0x50], xmm6
00007986e0ddf880  vmovaps [rsp+0x60], xmm7
00007986e0ddf886  vmovaps [rsp+0x70], xmm8
00007986e0ddf88c  vmovaps [rsp+0x80], xmm9
00007986e0ddf895  vmovaps [rsp+0x90], xmm10
00007986e0ddf89e  vmovaps [rsp+0xA0], xmm11
00007986e0ddf8a7  vmovaps [rsp+0xB0], xmm12
00007986e0ddf8b0  vmovaps [rsp+0xC0], xmm13
00007986e0ddf8b9  vmovaps [rsp+0xD0], xmm14
00007986e0ddf8c2  vmovaps [rsp+0xE0], xmm15
00007986e0ddf8cb  sub rsp, 0x30
00007986e0ddf8cf  movaps [rsp], xmm4
00007986e0ddf8d3  movaps [rsp+0x10], xmm13
00007986e0ddf8d9  movaps [rsp+0x20], xmm8
00007986e0ddf8df  lea rdi, [rsp]
00007986e0ddf8e3  mov esi, 0x00
00007986e0ddf8e8  mov rax, 0x5652C689F530
00007986e0ddf8f2  call rax
00007986e0ddf8f4  movaps xmm4, [rsp]
00007986e0ddf8f8  add rsp, 0x30
00007986e0ddf8fc  vmovaps xmm0, [rsp]
00007986e0ddf901  vmovaps xmm1, [rsp+0x10]
00007986e0ddf907  vmovaps xmm2, [rsp+0x20]
00007986e0ddf90d  vmovaps xmm3, [rsp+0x30]
00007986e0ddf913  vmovaps xmm5, [rsp+0x40]
00007986e0ddf919  vmovaps xmm6, [rsp+0x50]
00007986e0ddf91f  vmovaps xmm7, [rsp+0x60]
00007986e0ddf925  vmovaps xmm8, [rsp+0x70]
00007986e0ddf92b  vmovaps xmm9, [rsp+0x80]
00007986e0ddf934  vmovaps xmm10, [rsp+0x90]
00007986e0ddf93d  vmovaps xmm11, [rsp+0xA0]
00007986e0ddf946  vmovaps xmm12, [rsp+0xB0]
00007986e0ddf94f  vmovaps xmm13, [rsp+0xC0]
00007986e0ddf958  vmovaps xmm14, [rsp+0xD0]
00007986e0ddf961  vmovaps xmm15, [rsp+0xE0]
00007986e0ddf96a  add rsp, 0xF0
00007986e0ddf971  pop r11
00007986e0ddf973  pop r10
00007986e0ddf975  pop r9
00007986e0ddf977  pop r8
00007986e0ddf979  pop rsi
00007986e0ddf97a  pop rdi
00007986e0ddf97b  pop rdx
00007986e0ddf97c  pop rcx
00007986e0ddf97d  pop rax
00007986e0ddf97e  add rsp, 0x08
00007986e0ddf982  jmp 0x00007986E0DDC43D
00007986e0ddf987  sub rsp, 0x08
00007986e0ddf98b  push rax
00007986e0ddf98c  push rcx
00007986e0ddf98d  push rdx
00007986e0ddf98e  push rdi
00007986e0ddf98f  push rsi
00007986e0ddf990  push r8
00007986e0ddf992  push r9
00007986e0ddf994  push r10
00007986e0ddf996  push r11
00007986e0ddf998  sub rsp, 0xF0
00007986e0ddf99f  vmovaps [rsp], xmm0
00007986e0ddf9a4  vmovaps [rsp+0x10], xmm1
00007986e0ddf9aa  vmovaps [rsp+0x20], xmm2
00007986e0ddf9b0  vmovaps [rsp+0x30], xmm3
00007986e0ddf9b6  vmovaps [rsp+0x40], xmm4
00007986e0ddf9bc  vmovaps [rsp+0x50], xmm5
00007986e0ddf9c2  vmovaps [rsp+0x60], xmm6
00007986e0ddf9c8  vmovaps [rsp+0x70], xmm7
00007986e0ddf9ce  vmovaps [rsp+0x80], xmm8
00007986e0ddf9d7  vmovaps [rsp+0x90], xmm9
00007986e0ddf9e0  vmovaps [rsp+0xA0], xmm10
00007986e0ddf9e9  vmovaps [rsp+0xB0], xmm11
00007986e0ddf9f2  vmovaps [rsp+0xC0], xmm12
00007986e0ddf9fb  vmovaps [rsp+0xD0], xmm14
00007986e0ddfa04  vmovaps [rsp+0xE0], xmm15
00007986e0ddfa0d  sub rsp, 0x30
00007986e0ddfa11  movaps [rsp], xmm13
00007986e0ddfa16  movaps [rsp+0x10], xmm15
00007986e0ddfa1c  movaps [rsp+0x20], xmm9
00007986e0ddfa22  lea rdi, [rsp]
00007986e0ddfa26  mov esi, 0x00
00007986e0ddfa2b  mov rax, 0x5652C689F530
00007986e0ddfa35  call rax
00007986e0ddfa37  movaps xmm13, [rsp]
00007986e0ddfa3c  add rsp, 0x30
00007986e0ddfa40  vmovaps xmm0, [rsp]
00007986e0ddfa45  vmovaps xmm1, [rsp+0x10]
00007986e0ddfa4b  vmovaps xmm2, [rsp+0x20]
00007986e0ddfa51  vmovaps xmm3, [rsp+0x30]
00007986e0ddfa57  vmovaps xmm4, [rsp+0x40]
00007986e0ddfa5d  vmovaps xmm5, [rsp+0x50]
00007986e0ddfa63  vmovaps xmm6, [rsp+0x60]
00007986e0ddfa69  vmovaps xmm7, [rsp+0x70]
00007986e0ddfa6f  vmovaps xmm8, [rsp+0x80]
00007986e0ddfa78  vmovaps xmm9, [rsp+0x90]
00007986e0ddfa81  vmovaps xmm10, [rsp+0xA0]
00007986e0ddfa8a  vmovaps xmm11, [rsp+0xB0]
00007986e0ddfa93  vmovaps xmm12, [rsp+0xC0]
00007986e0ddfa9c  vmovaps xmm14, [rsp+0xD0]
00007986e0ddfaa5  vmovaps xmm15, [rsp+0xE0]
00007986e0ddfaae  add rsp, 0xF0
00007986e0ddfab5  pop r11
00007986e0ddfab7  pop r10
00007986e0ddfab9  pop r9
00007986e0ddfabb  pop r8
00007986e0ddfabd  pop rsi
00007986e0ddfabe  pop rdi
00007986e0ddfabf  pop rdx
00007986e0ddfac0  pop rcx
00007986e0ddfac1  pop rax
00007986e0ddfac2  add rsp, 0x08
00007986e0ddfac6  jmp 0x00007986E0DDC458
00007986e0ddfacb  sub rsp, 0x08
00007986e0ddfacf  push rax
00007986e0ddfad0  push rcx
00007986e0ddfad1  push rdx
00007986e0ddfad2  push rdi
00007986e0ddfad3  push rsi
00007986e0ddfad4  push r8
00007986e0ddfad6  push r9
00007986e0ddfad8  push r10
00007986e0ddfada  push r11
00007986e0ddfadc  sub rsp, 0xF0
00007986e0ddfae3  vmovaps [rsp], xmm0
00007986e0ddfae8  vmovaps [rsp+0x10], xmm1
00007986e0ddfaee  vmovaps [rsp+0x20], xmm2
00007986e0ddfaf4  vmovaps [rsp+0x30], xmm3
00007986e0ddfafa  vmovaps [rsp+0x40], xmm4
00007986e0ddfb00  vmovaps [rsp+0x50], xmm5
00007986e0ddfb06  vmovaps [rsp+0x60], xmm6
00007986e0ddfb0c  vmovaps [rsp+0x70], xmm7
00007986e0ddfb12  vmovaps [rsp+0x80], xmm8
00007986e0ddfb1b  vmovaps [rsp+0x90], xmm9
00007986e0ddfb24  vmovaps [rsp+0xA0], xmm10
00007986e0ddfb2d  vmovaps [rsp+0xB0], xmm11
00007986e0ddfb36  vmovaps [rsp+0xC0], xmm12
00007986e0ddfb3f  vmovaps [rsp+0xD0], xmm13
00007986e0ddfb48  vmovaps [rsp+0xE0], xmm14
00007986e0ddfb51  sub rsp, 0x30
00007986e0ddfb55  movaps [rsp], xmm15
00007986e0ddfb5a  movaps [rsp+0x10], xmm1
00007986e0ddfb5f  movaps [rsp+0x20], xmm5
00007986e0ddfb64  lea rdi, [rsp]
00007986e0ddfb68  mov esi, 0x00
00007986e0ddfb6d  mov rax, 0x5652C689F530
00007986e0ddfb77  call rax
00007986e0ddfb79  movaps xmm15, [rsp]
00007986e0ddfb7e  add rsp, 0x30
00007986e0ddfb82  vmovaps xmm0, [rsp]
00007986e0ddfb87  vmovaps xmm1, [rsp+0x10]
00007986e0ddfb8d  vmovaps xmm2, [rsp+0x20]
00007986e0ddfb93  vmovaps xmm3, [rsp+0x30]
00007986e0ddfb99  vmovaps xmm4, [rsp+0x40]
00007986e0ddfb9f  vmovaps xmm5, [rsp+0x50]
00007986e0ddfba5  vmovaps xmm6, [rsp+0x60]
00007986e0ddfbab  vmovaps xmm7, [rsp+0x70]
00007986e0ddfbb1  vmovaps xmm8, [rsp+0x80]
00007986e0ddfbba  vmovaps xmm9, [rsp+0x90]
00007986e0ddfbc3  vmovaps xmm10, [rsp+0xA0]
00007986e0ddfbcc  vmovaps xmm11, [rsp+0xB0]
00007986e0ddfbd5  vmovaps xmm12, [rsp+0xC0]
00007986e0ddfbde  vmovaps xmm13, [rsp+0xD0]
00007986e0ddfbe7  vmovaps xmm14, [rsp+0xE0]
00007986e0ddfbf0  add rsp, 0xF0
00007986e0ddfbf7  pop r11
00007986e0ddfbf9  pop r10
00007986e0ddfbfb  pop r9
00007986e0ddfbfd  pop r8
00007986e0ddfbff  pop rsi
00007986e0ddfc00  pop rdi
00007986e0ddfc01  pop rdx
00007986e0ddfc02  pop rcx
00007986e0ddfc03  pop rax
00007986e0ddfc04  add rsp, 0x08
00007986e0ddfc08  jmp 0x00007986E0DDC473
00007986e0ddfc0d  call 0x00007986E0CB52F0
00007986e0ddfc12  jmp 0x00007986E0DDC4CE
00007986e0ddfc17  sub rsp, 0x08
00007986e0ddfc1b  push rax
00007986e0ddfc1c  push rcx
00007986e0ddfc1d  push rdx
00007986e0ddfc1e  push rdi
00007986e0ddfc1f  push rsi
00007986e0ddfc20  push r8
00007986e0ddfc22  push r9
00007986e0ddfc24  push r10
00007986e0ddfc26  push r11
00007986e0ddfc28  sub rsp, 0xF0
00007986e0ddfc2f  vmovaps [rsp], xmm0
00007986e0ddfc34  vmovaps [rsp+0x10], xmm1
00007986e0ddfc3a  vmovaps [rsp+0x20], xmm2
00007986e0ddfc40  vmovaps [rsp+0x30], xmm3
00007986e0ddfc46  vmovaps [rsp+0x40], xmm4
00007986e0ddfc4c  vmovaps [rsp+0x50], xmm5
00007986e0ddfc52  vmovaps [rsp+0x60], xmm6
00007986e0ddfc58  vmovaps [rsp+0x70], xmm7
00007986e0ddfc5e  vmovaps [rsp+0x80], xmm8
00007986e0ddfc67  vmovaps [rsp+0x90], xmm10
00007986e0ddfc70  vmovaps [rsp+0xA0], xmm11
00007986e0ddfc79  vmovaps [rsp+0xB0], xmm12
00007986e0ddfc82  vmovaps [rsp+0xC0], xmm13
00007986e0ddfc8b  vmovaps [rsp+0xD0], xmm14
00007986e0ddfc94  vmovaps [rsp+0xE0], xmm15
00007986e0ddfc9d  sub rsp, 0x30
00007986e0ddfca1  movaps [rsp], xmm9
00007986e0ddfca6  movaps [rsp+0x10], xmm8
00007986e0ddfcac  movaps [rsp+0x20], xmm11
00007986e0ddfcb2  lea rdi, [rsp]
00007986e0ddfcb6  mov esi, 0x00
00007986e0ddfcbb  mov rax, 0x5652C689F530
00007986e0ddfcc5  call rax
00007986e0ddfcc7  movaps xmm9, [rsp]
00007986e0ddfccc  add rsp, 0x30
00007986e0ddfcd0  vmovaps xmm0, [rsp]
00007986e0ddfcd5  vmovaps xmm1, [rsp+0x10]
00007986e0ddfcdb  vmovaps xmm2, [rsp+0x20]
00007986e0ddfce1  vmovaps xmm3, [rsp+0x30]
00007986e0ddfce7  vmovaps xmm4, [rsp+0x40]
00007986e0ddfced  vmovaps xmm5, [rsp+0x50]
00007986e0ddfcf3  vmovaps xmm6, [rsp+0x60]
00007986e0ddfcf9  vmovaps xmm7, [rsp+0x70]
00007986e0ddfcff  vmovaps xmm8, [rsp+0x80]
00007986e0ddfd08  vmovaps xmm10, [rsp+0x90]
00007986e0ddfd11  vmovaps xmm11, [rsp+0xA0]
00007986e0ddfd1a  vmovaps xmm12, [rsp+0xB0]
00007986e0ddfd23  vmovaps xmm13, [rsp+0xC0]
00007986e0ddfd2c  vmovaps xmm14, [rsp+0xD0]
00007986e0ddfd35  vmovaps xmm15, [rsp+0xE0]
00007986e0ddfd3e  add rsp, 0xF0
00007986e0ddfd45  pop r11
00007986e0ddfd47  pop r10
00007986e0ddfd49  pop r9
00007986e0ddfd4b  pop r8
00007986e0ddfd4d  pop rsi
00007986e0ddfd4e  pop rdi
00007986e0ddfd4f  pop rdx
00007986e0ddfd50  pop rcx
00007986e0ddfd51  pop rax
00007986e0ddfd52  add rsp, 0x08
00007986e0ddfd56  jmp 0x00007986E0DDC505
00007986e0ddfd5b  sub rsp, 0x08
00007986e0ddfd5f  push rax
00007986e0ddfd60  push rcx
00007986e0ddfd61  push rdx
00007986e0ddfd62  push rdi
00007986e0ddfd63  push rsi
00007986e0ddfd64  push r8
00007986e0ddfd66  push r9
00007986e0ddfd68  push r10
00007986e0ddfd6a  push r11
00007986e0ddfd6c  sub rsp, 0xF0
00007986e0ddfd73  vmovaps [rsp], xmm0
00007986e0ddfd78  vmovaps [rsp+0x10], xmm1
00007986e0ddfd7e  vmovaps [rsp+0x20], xmm2
00007986e0ddfd84  vmovaps [rsp+0x30], xmm3
00007986e0ddfd8a  vmovaps [rsp+0x40], xmm4
00007986e0ddfd90  vmovaps [rsp+0x50], xmm5
00007986e0ddfd96  vmovaps [rsp+0x60], xmm6
00007986e0ddfd9c  vmovaps [rsp+0x70], xmm7
00007986e0ddfda2  vmovaps [rsp+0x80], xmm8
00007986e0ddfdab  vmovaps [rsp+0x90], xmm9
00007986e0ddfdb4  vmovaps [rsp+0xA0], xmm10
00007986e0ddfdbd  vmovaps [rsp+0xB0], xmm12
00007986e0ddfdc6  vmovaps [rsp+0xC0], xmm13
00007986e0ddfdcf  vmovaps [rsp+0xD0], xmm14
00007986e0ddfdd8  vmovaps [rsp+0xE0], xmm15
00007986e0ddfde1  sub rsp, 0x30
00007986e0ddfde5  movaps [rsp], xmm11
00007986e0ddfdea  movaps [rsp+0x10], xmm10
00007986e0ddfdf0  movaps [rsp+0x20], xmm6
00007986e0ddfdf5  lea rdi, [rsp]
00007986e0ddfdf9  mov esi, 0x00
00007986e0ddfdfe  mov rax, 0x5652C689F530
00007986e0ddfe08  call rax
00007986e0ddfe0a  movaps xmm11, [rsp]
00007986e0ddfe0f  add rsp, 0x30
00007986e0ddfe13  vmovaps xmm0, [rsp]
00007986e0ddfe18  vmovaps xmm1, [rsp+0x10]
00007986e0ddfe1e  vmovaps xmm2, [rsp+0x20]
00007986e0ddfe24  vmovaps xmm3, [rsp+0x30]
00007986e0ddfe2a  vmovaps xmm4, [rsp+0x40]
00007986e0ddfe30  vmovaps xmm5, [rsp+0x50]
00007986e0ddfe36  vmovaps xmm6, [rsp+0x60]
00007986e0ddfe3c  vmovaps xmm7, [rsp+0x70]
00007986e0ddfe42  vmovaps xmm8, [rsp+0x80]
00007986e0ddfe4b  vmovaps xmm9, [rsp+0x90]
00007986e0ddfe54  vmovaps xmm10, [rsp+0xA0]
00007986e0ddfe5d  vmovaps xmm12, [rsp+0xB0]
00007986e0ddfe66  vmovaps xmm13, [rsp+0xC0]
00007986e0ddfe6f  vmovaps xmm14, [rsp+0xD0]
00007986e0ddfe78  vmovaps xmm15, [rsp+0xE0]
00007986e0ddfe81  add rsp, 0xF0
00007986e0ddfe88  pop r11
00007986e0ddfe8a  pop r10
00007986e0ddfe8c  pop r9
00007986e0ddfe8e  pop r8
00007986e0ddfe90  pop rsi
00007986e0ddfe91  pop rdi
00007986e0ddfe92  pop rdx
00007986e0ddfe93  pop rcx
00007986e0ddfe94  pop rax
00007986e0ddfe95  add rsp, 0x08
00007986e0ddfe99  jmp 0x00007986E0DDC520
00007986e0ddfe9e  sub rsp, 0x08
00007986e0ddfea2  push rax
00007986e0ddfea3  push rcx
00007986e0ddfea4  push rdx
00007986e0ddfea5  push rdi
00007986e0ddfea6  push rsi
00007986e0ddfea7  push r8
00007986e0ddfea9  push r9
00007986e0ddfeab  push r10
00007986e0ddfead  push r11
00007986e0ddfeaf  sub rsp, 0xF0
00007986e0ddfeb6  vmovaps [rsp], xmm0
00007986e0ddfebb  vmovaps [rsp+0x10], xmm1
00007986e0ddfec1  vmovaps [rsp+0x20], xmm2
00007986e0ddfec7  vmovaps [rsp+0x30], xmm3
00007986e0ddfecd  vmovaps [rsp+0x40], xmm4
00007986e0ddfed3  vmovaps [rsp+0x50], xmm5
00007986e0ddfed9  vmovaps [rsp+0x60], xmm6
00007986e0ddfedf  vmovaps [rsp+0x70], xmm7
00007986e0ddfee5  vmovaps [rsp+0x80], xmm8
00007986e0ddfeee  vmovaps [rsp+0x90], xmm9
00007986e0ddfef7  vmovaps [rsp+0xA0], xmm11
00007986e0ddff00  vmovaps [rsp+0xB0], xmm12
00007986e0ddff09  vmovaps [rsp+0xC0], xmm13
00007986e0ddff12  vmovaps [rsp+0xD0], xmm14
00007986e0ddff1b  vmovaps [rsp+0xE0], xmm15
00007986e0ddff24  sub rsp, 0x30
00007986e0ddff28  movaps [rsp], xmm10
00007986e0ddff2d  movaps [rsp+0x10], xmm14
00007986e0ddff33  movaps [rsp+0x20], xmm4
00007986e0ddff38  lea rdi, [rsp]
00007986e0ddff3c  mov esi, 0x00
00007986e0ddff41  mov rax, 0x5652C689F530
00007986e0ddff4b  call rax
00007986e0ddff4d  movaps xmm10, [rsp]
00007986e0ddff52  add rsp, 0x30
00007986e0ddff56  vmovaps xmm0, [rsp]
00007986e0ddff5b  vmovaps xmm1, [rsp+0x10]
00007986e0ddff61  vmovaps xmm2, [rsp+0x20]
00007986e0ddff67  vmovaps xmm3, [rsp+0x30]
00007986e0ddff6d  vmovaps xmm4, [rsp+0x40]
00007986e0ddff73  vmovaps xmm5, [rsp+0x50]
00007986e0ddff79  vmovaps xmm6, [rsp+0x60]
00007986e0ddff7f  vmovaps xmm7, [rsp+0x70]
00007986e0ddff85  vmovaps xmm8, [rsp+0x80]
00007986e0ddff8e  vmovaps xmm9, [rsp+0x90]
00007986e0ddff97  vmovaps xmm11, [rsp+0xA0]
00007986e0ddffa0  vmovaps xmm12, [rsp+0xB0]
00007986e0ddffa9  vmovaps xmm13, [rsp+0xC0]
00007986e0ddffb2  vmovaps xmm14, [rsp+0xD0]
00007986e0ddffbb  vmovaps xmm15, [rsp+0xE0]
00007986e0ddffc4  add rsp, 0xF0
00007986e0ddffcb  pop r11
00007986e0ddffcd  pop r10
00007986e0ddffcf  pop r9
00007986e0ddffd1  pop r8
00007986e0ddffd3  pop rsi
00007986e0ddffd4  pop rdi
00007986e0ddffd5  pop rdx
00007986e0ddffd6  pop rcx
00007986e0ddffd7  pop rax
00007986e0ddffd8  add rsp, 0x08
00007986e0ddffdc  jmp 0x00007986E0DDC53B
00007986e0ddffe1  sub rsp, 0x08
00007986e0ddffe5  push rax
00007986e0ddffe6  push rcx
00007986e0ddffe7  push rdx
00007986e0ddffe8  push rdi
00007986e0ddffe9  push rsi
00007986e0ddffea  push r8
00007986e0ddffec  push r9
00007986e0ddffee  push r10
00007986e0ddfff0  push r11
00007986e0ddfff2  sub rsp, 0xF0
00007986e0ddfff9  vmovaps [rsp], xmm0
00007986e0ddfffe  vmovaps [rsp+0x10], xmm1
00007986e0de0004  vmovaps [rsp+0x20], xmm2
00007986e0de000a  vmovaps [rsp+0x30], xmm3
00007986e0de0010  vmovaps [rsp+0x40], xmm4
00007986e0de0016  vmovaps [rsp+0x50], xmm5
00007986e0de001c  vmovaps [rsp+0x60], xmm6
00007986e0de0022  vmovaps [rsp+0x70], xmm7
00007986e0de0028  vmovaps [rsp+0x80], xmm9
00007986e0de0031  vmovaps [rsp+0x90], xmm10
00007986e0de003a  vmovaps [rsp+0xA0], xmm11
00007986e0de0043  vmovaps [rsp+0xB0], xmm12
00007986e0de004c  vmovaps [rsp+0xC0], xmm13
00007986e0de0055  vmovaps [rsp+0xD0], xmm14
00007986e0de005e  vmovaps [rsp+0xE0], xmm15
00007986e0de0067  sub rsp, 0x30
00007986e0de006b  movaps [rsp], xmm8
00007986e0de0070  movaps [rsp+0x10], xmm1
00007986e0de0075  movaps [rsp+0x20], xmm14
00007986e0de007b  lea rdi, [rsp]
00007986e0de007f  mov esi, 0x00
00007986e0de0084  mov rax, 0x5652C689F530
00007986e0de008e  call rax
00007986e0de0090  movaps xmm8, [rsp]
00007986e0de0095  add rsp, 0x30
00007986e0de0099  vmovaps xmm0, [rsp]
00007986e0de009e  vmovaps xmm1, [rsp+0x10]
00007986e0de00a4  vmovaps xmm2, [rsp+0x20]
00007986e0de00aa  vmovaps xmm3, [rsp+0x30]
00007986e0de00b0  vmovaps xmm4, [rsp+0x40]
00007986e0de00b6  vmovaps xmm5, [rsp+0x50]
00007986e0de00bc  vmovaps xmm6, [rsp+0x60]
00007986e0de00c2  vmovaps xmm7, [rsp+0x70]
00007986e0de00c8  vmovaps xmm9, [rsp+0x80]
00007986e0de00d1  vmovaps xmm10, [rsp+0x90]
00007986e0de00da  vmovaps xmm11, [rsp+0xA0]
00007986e0de00e3  vmovaps xmm12, [rsp+0xB0]
00007986e0de00ec  vmovaps xmm13, [rsp+0xC0]
00007986e0de00f5  vmovaps xmm14, [rsp+0xD0]
00007986e0de00fe  vmovaps xmm15, [rsp+0xE0]
00007986e0de0107  add rsp, 0xF0
00007986e0de010e  pop r11
00007986e0de0110  pop r10
00007986e0de0112  pop r9
00007986e0de0114  pop r8
00007986e0de0116  pop rsi
00007986e0de0117  pop rdi
00007986e0de0118  pop rdx
00007986e0de0119  pop rcx
00007986e0de011a  pop rax
00007986e0de011b  add rsp, 0x08
00007986e0de011f  jmp 0x00007986E0DDC561
00007986e0de0124  sub rsp, 0x08
00007986e0de0128  push rax
00007986e0de0129  push rcx
00007986e0de012a  push rdx
00007986e0de012b  push rdi
00007986e0de012c  push rsi
00007986e0de012d  push r8
00007986e0de012f  push r9
00007986e0de0131  push r10
00007986e0de0133  push r11
00007986e0de0135  sub rsp, 0xF0
00007986e0de013c  vmovaps [rsp], xmm0
00007986e0de0141  vmovaps [rsp+0x10], xmm1
00007986e0de0147  vmovaps [rsp+0x20], xmm2
00007986e0de014d  vmovaps [rsp+0x30], xmm3
00007986e0de0153  vmovaps [rsp+0x40], xmm4
00007986e0de0159  vmovaps [rsp+0x50], xmm5
00007986e0de015f  vmovaps [rsp+0x60], xmm7
00007986e0de0165  vmovaps [rsp+0x70], xmm8
00007986e0de016b  vmovaps [rsp+0x80], xmm9
00007986e0de0174  vmovaps [rsp+0x90], xmm10
00007986e0de017d  vmovaps [rsp+0xA0], xmm11
00007986e0de0186  vmovaps [rsp+0xB0], xmm12
00007986e0de018f  vmovaps [rsp+0xC0], xmm13
00007986e0de0198  vmovaps [rsp+0xD0], xmm14
00007986e0de01a1  vmovaps [rsp+0xE0], xmm15
00007986e0de01aa  sub rsp, 0x30
00007986e0de01ae  movaps [rsp], xmm6
00007986e0de01b2  movaps [rsp+0x10], xmm1
00007986e0de01b7  movaps [rsp+0x20], xmm14
00007986e0de01bd  lea rdi, [rsp]
00007986e0de01c1  mov esi, 0x00
00007986e0de01c6  mov rax, 0x5652C689F530
00007986e0de01d0  call rax
00007986e0de01d2  movaps xmm6, [rsp]
00007986e0de01d6  add rsp, 0x30
00007986e0de01da  vmovaps xmm0, [rsp]
00007986e0de01df  vmovaps xmm1, [rsp+0x10]
00007986e0de01e5  vmovaps xmm2, [rsp+0x20]
00007986e0de01eb  vmovaps xmm3, [rsp+0x30]
00007986e0de01f1  vmovaps xmm4, [rsp+0x40]
00007986e0de01f7  vmovaps xmm5, [rsp+0x50]
00007986e0de01fd  vmovaps xmm7, [rsp+0x60]
00007986e0de0203  vmovaps xmm8, [rsp+0x70]
00007986e0de0209  vmovaps xmm9, [rsp+0x80]
00007986e0de0212  vmovaps xmm10, [rsp+0x90]
00007986e0de021b  vmovaps xmm11, [rsp+0xA0]
00007986e0de0224  vmovaps xmm12, [rsp+0xB0]
00007986e0de022d  vmovaps xmm13, [rsp+0xC0]
00007986e0de0236  vmovaps xmm14, [rsp+0xD0]
00007986e0de023f  vmovaps xmm15, [rsp+0xE0]
00007986e0de0248  add rsp, 0xF0
00007986e0de024f  pop r11
00007986e0de0251  pop r10
00007986e0de0253  pop r9
00007986e0de0255  pop r8
00007986e0de0257  pop rsi
00007986e0de0258  pop rdi
00007986e0de0259  pop rdx
00007986e0de025a  pop rcx
00007986e0de025b  pop rax
00007986e0de025c  add rsp, 0x08
00007986e0de0260  jmp 0x00007986E0DDC58D
00007986e0de0265  sub rsp, 0x08
00007986e0de0269  push rax
00007986e0de026a  push rcx
00007986e0de026b  push rdx
00007986e0de026c  push rdi
00007986e0de026d  push rsi
00007986e0de026e  push r8
00007986e0de0270  push r9
00007986e0de0272  push r10
00007986e0de0274  push r11
00007986e0de0276  sub rsp, 0xF0
00007986e0de027d  vmovaps [rsp], xmm0
00007986e0de0282  vmovaps [rsp+0x10], xmm1
00007986e0de0288  vmovaps [rsp+0x20], xmm2
00007986e0de028e  vmovaps [rsp+0x30], xmm3
00007986e0de0294  vmovaps [rsp+0x40], xmm4
00007986e0de029a  vmovaps [rsp+0x50], xmm5
00007986e0de02a0  vmovaps [rsp+0x60], xmm6
00007986e0de02a6  vmovaps [rsp+0x70], xmm7
00007986e0de02ac  vmovaps [rsp+0x80], xmm8
00007986e0de02b5  vmovaps [rsp+0x90], xmm9
00007986e0de02be  vmovaps [rsp+0xA0], xmm10
00007986e0de02c7  vmovaps [rsp+0xB0], xmm11
00007986e0de02d0  vmovaps [rsp+0xC0], xmm12
00007986e0de02d9  vmovaps [rsp+0xD0], xmm13
00007986e0de02e2  vmovaps [rsp+0xE0], xmm15
00007986e0de02eb  sub rsp, 0x30
00007986e0de02ef  movaps [rsp], xmm14
00007986e0de02f4  movaps [rsp+0x10], xmm12
00007986e0de02fa  movaps [rsp+0x20], xmm1
00007986e0de02ff  lea rdi, [rsp]
00007986e0de0303  mov esi, 0x00
00007986e0de0308  mov rax, 0x5652C689F530
00007986e0de0312  call rax
00007986e0de0314  movaps xmm14, [rsp]
00007986e0de0319  add rsp, 0x30
00007986e0de031d  vmovaps xmm0, [rsp]
00007986e0de0322  vmovaps xmm1, [rsp+0x10]
00007986e0de0328  vmovaps xmm2, [rsp+0x20]
00007986e0de032e  vmovaps xmm3, [rsp+0x30]
00007986e0de0334  vmovaps xmm4, [rsp+0x40]
00007986e0de033a  vmovaps xmm5, [rsp+0x50]
00007986e0de0340  vmovaps xmm6, [rsp+0x60]
00007986e0de0346  vmovaps xmm7, [rsp+0x70]
00007986e0de034c  vmovaps xmm8, [rsp+0x80]
00007986e0de0355  vmovaps xmm9, [rsp+0x90]
00007986e0de035e  vmovaps xmm10, [rsp+0xA0]
00007986e0de0367  vmovaps xmm11, [rsp+0xB0]
00007986e0de0370  vmovaps xmm12, [rsp+0xC0]
00007986e0de0379  vmovaps xmm13, [rsp+0xD0]
00007986e0de0382  vmovaps xmm15, [rsp+0xE0]
00007986e0de038b  add rsp, 0xF0
00007986e0de0392  pop r11
00007986e0de0394  pop r10
00007986e0de0396  pop r9
00007986e0de0398  pop r8
00007986e0de039a  pop rsi
00007986e0de039b  pop rdi
00007986e0de039c  pop rdx
00007986e0de039d  pop rcx
00007986e0de039e  pop rax
00007986e0de039f  add rsp, 0x08
00007986e0de03a3  jmp 0x00007986E0DDC5B3
00007986e0de03a8  sub rsp, 0x08
00007986e0de03ac  push rax
00007986e0de03ad  push rcx
00007986e0de03ae  push rdx
00007986e0de03af  push rdi
00007986e0de03b0  push rsi
00007986e0de03b1  push r8
00007986e0de03b3  push r9
00007986e0de03b5  push r10
00007986e0de03b7  push r11
00007986e0de03b9  sub rsp, 0xF0
00007986e0de03c0  vmovaps [rsp], xmm0
00007986e0de03c5  vmovaps [rsp+0x10], xmm2
00007986e0de03cb  vmovaps [rsp+0x20], xmm3
00007986e0de03d1  vmovaps [rsp+0x30], xmm4
00007986e0de03d7  vmovaps [rsp+0x40], xmm5
00007986e0de03dd  vmovaps [rsp+0x50], xmm6
00007986e0de03e3  vmovaps [rsp+0x60], xmm7
00007986e0de03e9  vmovaps [rsp+0x70], xmm8
00007986e0de03ef  vmovaps [rsp+0x80], xmm9
00007986e0de03f8  vmovaps [rsp+0x90], xmm10
00007986e0de0401  vmovaps [rsp+0xA0], xmm11
00007986e0de040a  vmovaps [rsp+0xB0], xmm12
00007986e0de0413  vmovaps [rsp+0xC0], xmm13
00007986e0de041c  vmovaps [rsp+0xD0], xmm14
00007986e0de0425  vmovaps [rsp+0xE0], xmm15
00007986e0de042e  sub rsp, 0x30
00007986e0de0432  movaps [rsp], xmm1
00007986e0de0436  movaps [rsp+0x10], xmm13
00007986e0de043c  movaps [rsp+0x20], xmm9
00007986e0de0442  lea rdi, [rsp]
00007986e0de0446  mov esi, 0x00
00007986e0de044b  mov rax, 0x5652C689F530
00007986e0de0455  call rax
00007986e0de0457  movaps xmm1, [rsp]
00007986e0de045b  add rsp, 0x30
00007986e0de045f  vmovaps xmm0, [rsp]
00007986e0de0464  vmovaps xmm2, [rsp+0x10]
00007986e0de046a  vmovaps xmm3, [rsp+0x20]
00007986e0de0470  vmovaps xmm4, [rsp+0x30]
00007986e0de0476  vmovaps xmm5, [rsp+0x40]
00007986e0de047c  vmovaps xmm6, [rsp+0x50]
00007986e0de0482  vmovaps xmm7, [rsp+0x60]
00007986e0de0488  vmovaps xmm8, [rsp+0x70]
00007986e0de048e  vmovaps xmm9, [rsp+0x80]
00007986e0de0497  vmovaps xmm10, [rsp+0x90]
00007986e0de04a0  vmovaps xmm11, [rsp+0xA0]
00007986e0de04a9  vmovaps xmm12, [rsp+0xB0]
00007986e0de04b2  vmovaps xmm13, [rsp+0xC0]
00007986e0de04bb  vmovaps xmm14, [rsp+0xD0]
00007986e0de04c4  vmovaps xmm15, [rsp+0xE0]
00007986e0de04cd  add rsp, 0xF0
00007986e0de04d4  pop r11
00007986e0de04d6  pop r10
00007986e0de04d8  pop r9
00007986e0de04da  pop r8
00007986e0de04dc  pop rsi
00007986e0de04dd  pop rdi
00007986e0de04de  pop rdx
00007986e0de04df  pop rcx
00007986e0de04e0  pop rax
00007986e0de04e1  add rsp, 0x08
00007986e0de04e5  jmp 0x00007986E0DDC5CD
00007986e0de04ea  sub rsp, 0x08
00007986e0de04ee  push rax
00007986e0de04ef  push rcx
00007986e0de04f0  push rdx
00007986e0de04f1  push rdi
00007986e0de04f2  push rsi
00007986e0de04f3  push r8
00007986e0de04f5  push r9
00007986e0de04f7  push r10
00007986e0de04f9  push r11
00007986e0de04fb  sub rsp, 0xF0
00007986e0de0502  vmovaps [rsp], xmm0
00007986e0de0507  vmovaps [rsp+0x10], xmm1
00007986e0de050d  vmovaps [rsp+0x20], xmm2
00007986e0de0513  vmovaps [rsp+0x30], xmm3
00007986e0de0519  vmovaps [rsp+0x40], xmm4
00007986e0de051f  vmovaps [rsp+0x50], xmm5
00007986e0de0525  vmovaps [rsp+0x60], xmm6
00007986e0de052b  vmovaps [rsp+0x70], xmm7
00007986e0de0531  vmovaps [rsp+0x80], xmm8
00007986e0de053a  vmovaps [rsp+0x90], xmm9
00007986e0de0543  vmovaps [rsp+0xA0], xmm10
00007986e0de054c  vmovaps [rsp+0xB0], xmm11
00007986e0de0555  vmovaps [rsp+0xC0], xmm13
00007986e0de055e  vmovaps [rsp+0xD0], xmm14
00007986e0de0567  vmovaps [rsp+0xE0], xmm15
00007986e0de0570  sub rsp, 0x30
00007986e0de0574  movaps [rsp], xmm12
00007986e0de0579  movaps [rsp+0x10], xmm7
00007986e0de057e  movaps [rsp+0x20], xmm13
00007986e0de0584  lea rdi, [rsp]
00007986e0de0588  mov esi, 0x00
00007986e0de058d  mov rax, 0x5652C689F530
00007986e0de0597  call rax
00007986e0de0599  movaps xmm12, [rsp]
00007986e0de059e  add rsp, 0x30
00007986e0de05a2  vmovaps xmm0, [rsp]
00007986e0de05a7  vmovaps xmm1, [rsp+0x10]
00007986e0de05ad  vmovaps xmm2, [rsp+0x20]
00007986e0de05b3  vmovaps xmm3, [rsp+0x30]
00007986e0de05b9  vmovaps xmm4, [rsp+0x40]
00007986e0de05bf  vmovaps xmm5, [rsp+0x50]
00007986e0de05c5  vmovaps xmm6, [rsp+0x60]
00007986e0de05cb  vmovaps xmm7, [rsp+0x70]
00007986e0de05d1  vmovaps xmm8, [rsp+0x80]
00007986e0de05da  vmovaps xmm9, [rsp+0x90]
00007986e0de05e3  vmovaps xmm10, [rsp+0xA0]
00007986e0de05ec  vmovaps xmm11, [rsp+0xB0]
00007986e0de05f5  vmovaps xmm13, [rsp+0xC0]
00007986e0de05fe  vmovaps xmm14, [rsp+0xD0]
00007986e0de0607  vmovaps xmm15, [rsp+0xE0]
00007986e0de0610  add rsp, 0xF0
00007986e0de0617  pop r11
00007986e0de0619  pop r10
00007986e0de061b  pop r9
00007986e0de061d  pop r8
00007986e0de061f  pop rsi
00007986e0de0620  pop rdi
00007986e0de0621  pop rdx
00007986e0de0622  pop rcx
00007986e0de0623  pop rax
00007986e0de0624  add rsp, 0x08
00007986e0de0628  jmp 0x00007986E0DDC5F4
00007986e0de062d  sub rsp, 0x08
00007986e0de0631  push rax
00007986e0de0632  push rcx
00007986e0de0633  push rdx
00007986e0de0634  push rdi
00007986e0de0635  push rsi
00007986e0de0636  push r8
00007986e0de0638  push r9
00007986e0de063a  push r10
00007986e0de063c  push r11
00007986e0de063e  sub rsp, 0xF0
00007986e0de0645  vmovaps [rsp], xmm0
00007986e0de064a  vmovaps [rsp+0x10], xmm1
00007986e0de0650  vmovaps [rsp+0x20], xmm2
00007986e0de0656  vmovaps [rsp+0x30], xmm3
00007986e0de065c  vmovaps [rsp+0x40], xmm4
00007986e0de0662  vmovaps [rsp+0x50], xmm5
00007986e0de0668  vmovaps [rsp+0x60], xmm6
00007986e0de066e  vmovaps [rsp+0x70], xmm7
00007986e0de0674  vmovaps [rsp+0x80], xmm8
00007986e0de067d  vmovaps [rsp+0x90], xmm9
00007986e0de0686  vmovaps [rsp+0xA0], xmm10
00007986e0de068f  vmovaps [rsp+0xB0], xmm11
00007986e0de0698  vmovaps [rsp+0xC0], xmm12
00007986e0de06a1  vmovaps [rsp+0xD0], xmm14
00007986e0de06aa  vmovaps [rsp+0xE0], xmm15
00007986e0de06b3  sub rsp, 0x30
00007986e0de06b7  movaps [rsp], xmm13
00007986e0de06bc  movaps [rsp+0x10], xmm15
00007986e0de06c2  movaps [rsp+0x20], xmm8
00007986e0de06c8  lea rdi, [rsp]
00007986e0de06cc  mov esi, 0x00
00007986e0de06d1  mov rax, 0x5652C689F530
00007986e0de06db  call rax
00007986e0de06dd  movaps xmm13, [rsp]
00007986e0de06e2  add rsp, 0x30
00007986e0de06e6  vmovaps xmm0, [rsp]
00007986e0de06eb  vmovaps xmm1, [rsp+0x10]
00007986e0de06f1  vmovaps xmm2, [rsp+0x20]
00007986e0de06f7  vmovaps xmm3, [rsp+0x30]
00007986e0de06fd  vmovaps xmm4, [rsp+0x40]
00007986e0de0703  vmovaps xmm5, [rsp+0x50]
00007986e0de0709  vmovaps xmm6, [rsp+0x60]
00007986e0de070f  vmovaps xmm7, [rsp+0x70]
00007986e0de0715  vmovaps xmm8, [rsp+0x80]
00007986e0de071e  vmovaps xmm9, [rsp+0x90]
00007986e0de0727  vmovaps xmm10, [rsp+0xA0]
00007986e0de0730  vmovaps xmm11, [rsp+0xB0]
00007986e0de0739  vmovaps xmm12, [rsp+0xC0]
00007986e0de0742  vmovaps xmm14, [rsp+0xD0]
00007986e0de074b  vmovaps xmm15, [rsp+0xE0]
00007986e0de0754  add rsp, 0xF0
00007986e0de075b  pop r11
00007986e0de075d  pop r10
00007986e0de075f  pop r9
00007986e0de0761  pop r8
00007986e0de0763  pop rsi
00007986e0de0764  pop rdi
00007986e0de0765  pop rdx
00007986e0de0766  pop rcx
00007986e0de0767  pop rax
00007986e0de0768  add rsp, 0x08
00007986e0de076c  jmp 0x00007986E0DDC60F
00007986e0de0771  sub rsp, 0x08
00007986e0de0775  push rax
00007986e0de0776  push rcx
00007986e0de0777  push rdx
00007986e0de0778  push rdi
00007986e0de0779  push rsi
00007986e0de077a  push r8
00007986e0de077c  push r9
00007986e0de077e  push r10
00007986e0de0780  push r11
00007986e0de0782  sub rsp, 0xF0
00007986e0de0789  vmovaps [rsp], xmm0
00007986e0de078e  vmovaps [rsp+0x10], xmm1
00007986e0de0794  vmovaps [rsp+0x20], xmm2
00007986e0de079a  vmovaps [rsp+0x30], xmm3
00007986e0de07a0  vmovaps [rsp+0x40], xmm4
00007986e0de07a6  vmovaps [rsp+0x50], xmm5
00007986e0de07ac  vmovaps [rsp+0x60], xmm6
00007986e0de07b2  vmovaps [rsp+0x70], xmm7
00007986e0de07b8  vmovaps [rsp+0x80], xmm9
00007986e0de07c1  vmovaps [rsp+0x90], xmm10
00007986e0de07ca  vmovaps [rsp+0xA0], xmm11
00007986e0de07d3  vmovaps [rsp+0xB0], xmm12
00007986e0de07dc  vmovaps [rsp+0xC0], xmm13
00007986e0de07e5  vmovaps [rsp+0xD0], xmm14
00007986e0de07ee  vmovaps [rsp+0xE0], xmm15
00007986e0de07f7  sub rsp, 0x30
00007986e0de07fb  movaps [rsp], xmm8
00007986e0de0800  movaps [rsp+0x10], xmm15
00007986e0de0806  movaps [rsp+0x20], xmm9
00007986e0de080c  lea rdi, [rsp]
00007986e0de0810  mov esi, 0x00
00007986e0de0815  mov rax, 0x5652C689F530
00007986e0de081f  call rax
00007986e0de0821  movaps xmm8, [rsp]
00007986e0de0826  add rsp, 0x30
00007986e0de082a  vmovaps xmm0, [rsp]
00007986e0de082f  vmovaps xmm1, [rsp+0x10]
00007986e0de0835  vmovaps xmm2, [rsp+0x20]
00007986e0de083b  vmovaps xmm3, [rsp+0x30]
00007986e0de0841  vmovaps xmm4, [rsp+0x40]
00007986e0de0847  vmovaps xmm5, [rsp+0x50]
00007986e0de084d  vmovaps xmm6, [rsp+0x60]
00007986e0de0853  vmovaps xmm7, [rsp+0x70]
00007986e0de0859  vmovaps xmm9, [rsp+0x80]
00007986e0de0862  vmovaps xmm10, [rsp+0x90]
00007986e0de086b  vmovaps xmm11, [rsp+0xA0]
00007986e0de0874  vmovaps xmm12, [rsp+0xB0]
00007986e0de087d  vmovaps xmm13, [rsp+0xC0]
00007986e0de0886  vmovaps xmm14, [rsp+0xD0]
00007986e0de088f  vmovaps xmm15, [rsp+0xE0]
00007986e0de0898  add rsp, 0xF0
00007986e0de089f  pop r11
00007986e0de08a1  pop r10
00007986e0de08a3  pop r9
00007986e0de08a5  pop r8
00007986e0de08a7  pop rsi
00007986e0de08a8  pop rdi
00007986e0de08a9  pop rdx
00007986e0de08aa  pop rcx
00007986e0de08ab  pop rax
00007986e0de08ac  add rsp, 0x08
00007986e0de08b0  jmp 0x00007986E0DDC63D
00007986e0de08b5  sub rsp, 0x08
00007986e0de08b9  push rax
00007986e0de08ba  push rcx
00007986e0de08bb  push rdx
00007986e0de08bc  push rdi
00007986e0de08bd  push rsi
00007986e0de08be  push r8
00007986e0de08c0  push r9
00007986e0de08c2  push r10
00007986e0de08c4  push r11
00007986e0de08c6  sub rsp, 0xF0
00007986e0de08cd  vmovaps [rsp], xmm0
00007986e0de08d2  vmovaps [rsp+0x10], xmm1
00007986e0de08d8  vmovaps [rsp+0x20], xmm2
00007986e0de08de  vmovaps [rsp+0x30], xmm3
00007986e0de08e4  vmovaps [rsp+0x40], xmm4
00007986e0de08ea  vmovaps [rsp+0x50], xmm5
00007986e0de08f0  vmovaps [rsp+0x60], xmm6
00007986e0de08f6  vmovaps [rsp+0x70], xmm7
00007986e0de08fc  vmovaps [rsp+0x80], xmm8
00007986e0de0905  vmovaps [rsp+0x90], xmm9
00007986e0de090e  vmovaps [rsp+0xA0], xmm10
00007986e0de0917  vmovaps [rsp+0xB0], xmm11
00007986e0de0920  vmovaps [rsp+0xC0], xmm12
00007986e0de0929  vmovaps [rsp+0xD0], xmm13
00007986e0de0932  vmovaps [rsp+0xE0], xmm14
00007986e0de093b  sub rsp, 0x30
00007986e0de093f  movaps [rsp], xmm15
00007986e0de0944  movaps [rsp+0x10], xmm11
00007986e0de094a  movaps [rsp+0x20], xmm6
00007986e0de094f  lea rdi, [rsp]
00007986e0de0953  mov esi, 0x00
00007986e0de0958  mov rax, 0x5652C689F530
00007986e0de0962  call rax
00007986e0de0964  movaps xmm15, [rsp]
00007986e0de0969  add rsp, 0x30
00007986e0de096d  vmovaps xmm0, [rsp]
00007986e0de0972  vmovaps xmm1, [rsp+0x10]
00007986e0de0978  vmovaps xmm2, [rsp+0x20]
00007986e0de097e  vmovaps xmm3, [rsp+0x30]
00007986e0de0984  vmovaps xmm4, [rsp+0x40]
00007986e0de098a  vmovaps xmm5, [rsp+0x50]
00007986e0de0990  vmovaps xmm6, [rsp+0x60]
00007986e0de0996  vmovaps xmm7, [rsp+0x70]
00007986e0de099c  vmovaps xmm8, [rsp+0x80]
00007986e0de09a5  vmovaps xmm9, [rsp+0x90]
00007986e0de09ae  vmovaps xmm10, [rsp+0xA0]
00007986e0de09b7  vmovaps xmm11, [rsp+0xB0]
00007986e0de09c0  vmovaps xmm12, [rsp+0xC0]
00007986e0de09c9  vmovaps xmm13, [rsp+0xD0]
00007986e0de09d2  vmovaps xmm14, [rsp+0xE0]
00007986e0de09db  add rsp, 0xF0
00007986e0de09e2  pop r11
00007986e0de09e4  pop r10
00007986e0de09e6  pop r9
00007986e0de09e8  pop r8
00007986e0de09ea  pop rsi
00007986e0de09eb  pop rdi
00007986e0de09ec  pop rdx
00007986e0de09ed  pop rcx
00007986e0de09ee  pop rax
00007986e0de09ef  add rsp, 0x08
00007986e0de09f3  jmp 0x00007986E0DDC658
00007986e0de09f8  sub rsp, 0x08
00007986e0de09fc  push rax
00007986e0de09fd  push rcx
00007986e0de09fe  push rdx
00007986e0de09ff  push rdi
00007986e0de0a00  push rsi
00007986e0de0a01  push r8
00007986e0de0a03  push r9
00007986e0de0a05  push r10
00007986e0de0a07  push r11
00007986e0de0a09  sub rsp, 0xF0
00007986e0de0a10  vmovaps [rsp], xmm0
00007986e0de0a15  vmovaps [rsp+0x10], xmm1
00007986e0de0a1b  vmovaps [rsp+0x20], xmm2
00007986e0de0a21  vmovaps [rsp+0x30], xmm3
00007986e0de0a27  vmovaps [rsp+0x40], xmm4
00007986e0de0a2d  vmovaps [rsp+0x50], xmm5
00007986e0de0a33  vmovaps [rsp+0x60], xmm6
00007986e0de0a39  vmovaps [rsp+0x70], xmm8
00007986e0de0a3f  vmovaps [rsp+0x80], xmm9
00007986e0de0a48  vmovaps [rsp+0x90], xmm10
00007986e0de0a51  vmovaps [rsp+0xA0], xmm11
00007986e0de0a5a  vmovaps [rsp+0xB0], xmm12
00007986e0de0a63  vmovaps [rsp+0xC0], xmm13
00007986e0de0a6c  vmovaps [rsp+0xD0], xmm14
00007986e0de0a75  vmovaps [rsp+0xE0], xmm15
00007986e0de0a7e  sub rsp, 0x30
00007986e0de0a82  movaps [rsp], xmm7
00007986e0de0a86  movaps [rsp+0x10], xmm11
00007986e0de0a8c  movaps [rsp+0x20], xmm9
00007986e0de0a92  lea rdi, [rsp]
00007986e0de0a96  mov esi, 0x00
00007986e0de0a9b  mov rax, 0x5652C689F530
00007986e0de0aa5  call rax
00007986e0de0aa7  movaps xmm7, [rsp]
00007986e0de0aab  add rsp, 0x30
00007986e0de0aaf  vmovaps xmm0, [rsp]
00007986e0de0ab4  vmovaps xmm1, [rsp+0x10]
00007986e0de0aba  vmovaps xmm2, [rsp+0x20]
00007986e0de0ac0  vmovaps xmm3, [rsp+0x30]
00007986e0de0ac6  vmovaps xmm4, [rsp+0x40]
00007986e0de0acc  vmovaps xmm5, [rsp+0x50]
00007986e0de0ad2  vmovaps xmm6, [rsp+0x60]
00007986e0de0ad8  vmovaps xmm8, [rsp+0x70]
00007986e0de0ade  vmovaps xmm9, [rsp+0x80]
00007986e0de0ae7  vmovaps xmm10, [rsp+0x90]
00007986e0de0af0  vmovaps xmm11, [rsp+0xA0]
00007986e0de0af9  vmovaps xmm12, [rsp+0xB0]
00007986e0de0b02  vmovaps xmm13, [rsp+0xC0]
00007986e0de0b0b  vmovaps xmm14, [rsp+0xD0]
00007986e0de0b14  vmovaps xmm15, [rsp+0xE0]
00007986e0de0b1d  add rsp, 0xF0
00007986e0de0b24  pop r11
00007986e0de0b26  pop r10
00007986e0de0b28  pop r9
00007986e0de0b2a  pop r8
00007986e0de0b2c  pop rsi
00007986e0de0b2d  pop rdi
00007986e0de0b2e  pop rdx
00007986e0de0b2f  pop rcx
00007986e0de0b30  pop rax
00007986e0de0b31  add rsp, 0x08
00007986e0de0b35  jmp 0x00007986E0DDC685
00007986e0de0b3a  sub rsp, 0x08
00007986e0de0b3e  push rax
00007986e0de0b3f  push rcx
00007986e0de0b40  push rdx
00007986e0de0b41  push rdi
00007986e0de0b42  push rsi
00007986e0de0b43  push r8
00007986e0de0b45  push r9
00007986e0de0b47  push r10
00007986e0de0b49  push r11
00007986e0de0b4b  sub rsp, 0xF0
00007986e0de0b52  vmovaps [rsp], xmm0
00007986e0de0b57  vmovaps [rsp+0x10], xmm1
00007986e0de0b5d  vmovaps [rsp+0x20], xmm2
00007986e0de0b63  vmovaps [rsp+0x30], xmm3
00007986e0de0b69  vmovaps [rsp+0x40], xmm4
00007986e0de0b6f  vmovaps [rsp+0x50], xmm5
00007986e0de0b75  vmovaps [rsp+0x60], xmm6
00007986e0de0b7b  vmovaps [rsp+0x70], xmm7
00007986e0de0b81  vmovaps [rsp+0x80], xmm8
00007986e0de0b8a  vmovaps [rsp+0x90], xmm9
00007986e0de0b93  vmovaps [rsp+0xA0], xmm10
00007986e0de0b9c  vmovaps [rsp+0xB0], xmm12
00007986e0de0ba5  vmovaps [rsp+0xC0], xmm13
00007986e0de0bae  vmovaps [rsp+0xD0], xmm14
00007986e0de0bb7  vmovaps [rsp+0xE0], xmm15
00007986e0de0bc0  sub rsp, 0x30
00007986e0de0bc4  movaps [rsp], xmm11
00007986e0de0bc9  movaps [rsp+0x10], xmm10
00007986e0de0bcf  movaps [rsp+0x20], xmm14
00007986e0de0bd5  lea rdi, [rsp]
00007986e0de0bd9  mov esi, 0x00
00007986e0de0bde  mov rax, 0x5652C689F530
00007986e0de0be8  call rax
00007986e0de0bea  movaps xmm11, [rsp]
00007986e0de0bef  add rsp, 0x30
00007986e0de0bf3  vmovaps xmm0, [rsp]
00007986e0de0bf8  vmovaps xmm1, [rsp+0x10]
00007986e0de0bfe  vmovaps xmm2, [rsp+0x20]
00007986e0de0c04  vmovaps xmm3, [rsp+0x30]
00007986e0de0c0a  vmovaps xmm4, [rsp+0x40]
00007986e0de0c10  vmovaps xmm5, [rsp+0x50]
00007986e0de0c16  vmovaps xmm6, [rsp+0x60]
00007986e0de0c1c  vmovaps xmm7, [rsp+0x70]
00007986e0de0c22  vmovaps xmm8, [rsp+0x80]
00007986e0de0c2b  vmovaps xmm9, [rsp+0x90]
00007986e0de0c34  vmovaps xmm10, [rsp+0xA0]
00007986e0de0c3d  vmovaps xmm12, [rsp+0xB0]
00007986e0de0c46  vmovaps xmm13, [rsp+0xC0]
00007986e0de0c4f  vmovaps xmm14, [rsp+0xD0]
00007986e0de0c58  vmovaps xmm15, [rsp+0xE0]
00007986e0de0c61  add rsp, 0xF0
00007986e0de0c68  pop r11
00007986e0de0c6a  pop r10
00007986e0de0c6c  pop r9
00007986e0de0c6e  pop r8
00007986e0de0c70  pop rsi
00007986e0de0c71  pop rdi
00007986e0de0c72  pop rdx
00007986e0de0c73  pop rcx
00007986e0de0c74  pop rax
00007986e0de0c75  add rsp, 0x08
00007986e0de0c79  jmp 0x00007986E0DDC6A0
00007986e0de0c7e  call 0x00007986E0CC33A0
00007986e0de0c83  jmp 0x00007986E0DDC6AA
00007986e0de0c88  sub rsp, 0x08
00007986e0de0c8c  push rax
00007986e0de0c8d  push rcx
00007986e0de0c8e  push rdx
00007986e0de0c8f  push rdi
00007986e0de0c90  push rsi
00007986e0de0c91  push r8
00007986e0de0c93  push r9
00007986e0de0c95  push r10
00007986e0de0c97  push r11
00007986e0de0c99  sub rsp, 0xF0
00007986e0de0ca0  vmovaps [rsp], xmm0
00007986e0de0ca5  vmovaps [rsp+0x10], xmm1
00007986e0de0cab  vmovaps [rsp+0x20], xmm2
00007986e0de0cb1  vmovaps [rsp+0x30], xmm3
00007986e0de0cb7  vmovaps [rsp+0x40], xmm4
00007986e0de0cbd  vmovaps [rsp+0x50], xmm5
00007986e0de0cc3  vmovaps [rsp+0x60], xmm6
00007986e0de0cc9  vmovaps [rsp+0x70], xmm7
00007986e0de0ccf  vmovaps [rsp+0x80], xmm8
00007986e0de0cd8  vmovaps [rsp+0x90], xmm9
00007986e0de0ce1  vmovaps [rsp+0xA0], xmm11
00007986e0de0cea  vmovaps [rsp+0xB0], xmm12
00007986e0de0cf3  vmovaps [rsp+0xC0], xmm13
00007986e0de0cfc  vmovaps [rsp+0xD0], xmm14
00007986e0de0d05  vmovaps [rsp+0xE0], xmm15
00007986e0de0d0e  sub rsp, 0x30
00007986e0de0d12  movaps [rsp], xmm10
00007986e0de0d17  movaps [rsp+0x10], xmm1
00007986e0de0d1c  movaps [rsp+0x20], xmm12
00007986e0de0d22  lea rdi, [rsp]
00007986e0de0d26  mov esi, 0x00
00007986e0de0d2b  mov rax, 0x5652C689F530
00007986e0de0d35  call rax
00007986e0de0d37  movaps xmm10, [rsp]
00007986e0de0d3c  add rsp, 0x30
00007986e0de0d40  vmovaps xmm0, [rsp]
00007986e0de0d45  vmovaps xmm1, [rsp+0x10]
00007986e0de0d4b  vmovaps xmm2, [rsp+0x20]
00007986e0de0d51  vmovaps xmm3, [rsp+0x30]
00007986e0de0d57  vmovaps xmm4, [rsp+0x40]
00007986e0de0d5d  vmovaps xmm5, [rsp+0x50]
00007986e0de0d63  vmovaps xmm6, [rsp+0x60]
00007986e0de0d69  vmovaps xmm7, [rsp+0x70]
00007986e0de0d6f  vmovaps xmm8, [rsp+0x80]
00007986e0de0d78  vmovaps xmm9, [rsp+0x90]
00007986e0de0d81  vmovaps xmm11, [rsp+0xA0]
00007986e0de0d8a  vmovaps xmm12, [rsp+0xB0]
00007986e0de0d93  vmovaps xmm13, [rsp+0xC0]
00007986e0de0d9c  vmovaps xmm14, [rsp+0xD0]
00007986e0de0da5  vmovaps xmm15, [rsp+0xE0]
00007986e0de0dae  add rsp, 0xF0
00007986e0de0db5  pop r11
00007986e0de0db7  pop r10
00007986e0de0db9  pop r9
00007986e0de0dbb  pop r8
00007986e0de0dbd  pop rsi
00007986e0de0dbe  pop rdi
00007986e0de0dbf  pop rdx
00007986e0de0dc0  pop rcx
00007986e0de0dc1  pop rax
00007986e0de0dc2  add rsp, 0x08
00007986e0de0dc6  jmp 0x00007986E0DDC6CD
00007986e0de0dcb  sub rsp, 0x08
00007986e0de0dcf  push rax
00007986e0de0dd0  push rcx
00007986e0de0dd1  push rdx
00007986e0de0dd2  push rdi
00007986e0de0dd3  push rsi
00007986e0de0dd4  push r8
00007986e0de0dd6  push r9
00007986e0de0dd8  push r10
00007986e0de0dda  push r11
00007986e0de0ddc  sub rsp, 0xF0
00007986e0de0de3  vmovaps [rsp], xmm0
00007986e0de0de8  vmovaps [rsp+0x10], xmm1
00007986e0de0dee  vmovaps [rsp+0x20], xmm2
00007986e0de0df4  vmovaps [rsp+0x30], xmm3
00007986e0de0dfa  vmovaps [rsp+0x40], xmm4
00007986e0de0e00  vmovaps [rsp+0x50], xmm5
00007986e0de0e06  vmovaps [rsp+0x60], xmm6
00007986e0de0e0c  vmovaps [rsp+0x70], xmm7
00007986e0de0e12  vmovaps [rsp+0x80], xmm8
00007986e0de0e1b  vmovaps [rsp+0x90], xmm9
00007986e0de0e24  vmovaps [rsp+0xA0], xmm10
00007986e0de0e2d  vmovaps [rsp+0xB0], xmm11
00007986e0de0e36  vmovaps [rsp+0xC0], xmm13
00007986e0de0e3f  vmovaps [rsp+0xD0], xmm14
00007986e0de0e48  vmovaps [rsp+0xE0], xmm15
00007986e0de0e51  sub rsp, 0x30
00007986e0de0e55  movaps [rsp], xmm12
00007986e0de0e5a  movaps [rsp+0x10], xmm14
00007986e0de0e60  movaps [rsp+0x20], xmm1
00007986e0de0e65  lea rdi, [rsp]
00007986e0de0e69  mov esi, 0x00
00007986e0de0e6e  mov rax, 0x5652C689F530
00007986e0de0e78  call rax
00007986e0de0e7a  movaps xmm12, [rsp]
00007986e0de0e7f  add rsp, 0x30
00007986e0de0e83  vmovaps xmm0, [rsp]
00007986e0de0e88  vmovaps xmm1, [rsp+0x10]
00007986e0de0e8e  vmovaps xmm2, [rsp+0x20]
00007986e0de0e94  vmovaps xmm3, [rsp+0x30]
00007986e0de0e9a  vmovaps xmm4, [rsp+0x40]
00007986e0de0ea0  vmovaps xmm5, [rsp+0x50]
00007986e0de0ea6  vmovaps xmm6, [rsp+0x60]
00007986e0de0eac  vmovaps xmm7, [rsp+0x70]
00007986e0de0eb2  vmovaps xmm8, [rsp+0x80]
00007986e0de0ebb  vmovaps xmm9, [rsp+0x90]
00007986e0de0ec4  vmovaps xmm10, [rsp+0xA0]
00007986e0de0ecd  vmovaps xmm11, [rsp+0xB0]
00007986e0de0ed6  vmovaps xmm13, [rsp+0xC0]
00007986e0de0edf  vmovaps xmm14, [rsp+0xD0]
00007986e0de0ee8  vmovaps xmm15, [rsp+0xE0]
00007986e0de0ef1  add rsp, 0xF0
00007986e0de0ef8  pop r11
00007986e0de0efa  pop r10
00007986e0de0efc  pop r9
00007986e0de0efe  pop r8
00007986e0de0f00  pop rsi
00007986e0de0f01  pop rdi
00007986e0de0f02  pop rdx
00007986e0de0f03  pop rcx
00007986e0de0f04  pop rax
00007986e0de0f05  add rsp, 0x08
00007986e0de0f09  jmp 0x00007986E0DDC6FC
00007986e0de0f0e  sub rsp, 0x08
00007986e0de0f12  push rax
00007986e0de0f13  push rcx
00007986e0de0f14  push rdx
00007986e0de0f15  push rdi
00007986e0de0f16  push rsi
00007986e0de0f17  push r8
00007986e0de0f19  push r9
00007986e0de0f1b  push r10
00007986e0de0f1d  push r11
00007986e0de0f1f  sub rsp, 0xF0
00007986e0de0f26  vmovaps [rsp], xmm0
00007986e0de0f2b  vmovaps [rsp+0x10], xmm1
00007986e0de0f31  vmovaps [rsp+0x20], xmm2
00007986e0de0f37  vmovaps [rsp+0x30], xmm3
00007986e0de0f3d  vmovaps [rsp+0x40], xmm4
00007986e0de0f43  vmovaps [rsp+0x50], xmm5
00007986e0de0f49  vmovaps [rsp+0x60], xmm6
00007986e0de0f4f  vmovaps [rsp+0x70], xmm7
00007986e0de0f55  vmovaps [rsp+0x80], xmm8
00007986e0de0f5e  vmovaps [rsp+0x90], xmm9
00007986e0de0f67  vmovaps [rsp+0xA0], xmm10
00007986e0de0f70  vmovaps [rsp+0xB0], xmm11
00007986e0de0f79  vmovaps [rsp+0xC0], xmm12
00007986e0de0f82  vmovaps [rsp+0xD0], xmm13
00007986e0de0f8b  vmovaps [rsp+0xE0], xmm15
00007986e0de0f94  sub rsp, 0x30
00007986e0de0f98  movaps [rsp], xmm14
00007986e0de0f9d  movaps [rsp+0x10], xmm9
00007986e0de0fa3  movaps [rsp+0x20], xmm1
00007986e0de0fa8  lea rdi, [rsp]
00007986e0de0fac  mov esi, 0x00
00007986e0de0fb1  mov rax, 0x5652C689F530
00007986e0de0fbb  call rax
00007986e0de0fbd  movaps xmm14, [rsp]
00007986e0de0fc2  add rsp, 0x30
00007986e0de0fc6  vmovaps xmm0, [rsp]
00007986e0de0fcb  vmovaps xmm1, [rsp+0x10]
00007986e0de0fd1  vmovaps xmm2, [rsp+0x20]
00007986e0de0fd7  vmovaps xmm3, [rsp+0x30]
00007986e0de0fdd  vmovaps xmm4, [rsp+0x40]
00007986e0de0fe3  vmovaps xmm5, [rsp+0x50]
00007986e0de0fe9  vmovaps xmm6, [rsp+0x60]
00007986e0de0fef  vmovaps xmm7, [rsp+0x70]
00007986e0de0ff5  vmovaps xmm8, [rsp+0x80]
00007986e0de0ffe  vmovaps xmm9, [rsp+0x90]
00007986e0de1007  vmovaps xmm10, [rsp+0xA0]
00007986e0de1010  vmovaps xmm11, [rsp+0xB0]
00007986e0de1019  vmovaps xmm12, [rsp+0xC0]
00007986e0de1022  vmovaps xmm13, [rsp+0xD0]
00007986e0de102b  vmovaps xmm15, [rsp+0xE0]
00007986e0de1034  add rsp, 0xF0
00007986e0de103b  pop r11
00007986e0de103d  pop r10
00007986e0de103f  pop r9
00007986e0de1041  pop r8
00007986e0de1043  pop rsi
00007986e0de1044  pop rdi
00007986e0de1045  pop rdx
00007986e0de1046  pop rcx
00007986e0de1047  pop rax
00007986e0de1048  add rsp, 0x08
00007986e0de104c  jmp 0x00007986E0DDC72B
00007986e0de1051  sub rsp, 0x08
00007986e0de1055  push rax
00007986e0de1056  push rcx
00007986e0de1057  push rdx
00007986e0de1058  push rdi
00007986e0de1059  push rsi
00007986e0de105a  push r8
00007986e0de105c  push r9
00007986e0de105e  push r10
00007986e0de1060  push r11
00007986e0de1062  sub rsp, 0xF0
00007986e0de1069  vmovaps [rsp], xmm0
00007986e0de106e  vmovaps [rsp+0x10], xmm2
00007986e0de1074  vmovaps [rsp+0x20], xmm3
00007986e0de107a  vmovaps [rsp+0x30], xmm4
00007986e0de1080  vmovaps [rsp+0x40], xmm5
00007986e0de1086  vmovaps [rsp+0x50], xmm6
00007986e0de108c  vmovaps [rsp+0x60], xmm7
00007986e0de1092  vmovaps [rsp+0x70], xmm8
00007986e0de1098  vmovaps [rsp+0x80], xmm9
00007986e0de10a1  vmovaps [rsp+0x90], xmm10
00007986e0de10aa  vmovaps [rsp+0xA0], xmm11
00007986e0de10b3  vmovaps [rsp+0xB0], xmm12
00007986e0de10bc  vmovaps [rsp+0xC0], xmm13
00007986e0de10c5  vmovaps [rsp+0xD0], xmm14
00007986e0de10ce  vmovaps [rsp+0xE0], xmm15
00007986e0de10d7  sub rsp, 0x30
00007986e0de10db  movaps [rsp], xmm1
00007986e0de10df  movaps [rsp+0x10], xmm13
00007986e0de10e5  movaps [rsp+0x20], xmm8
00007986e0de10eb  lea rdi, [rsp]
00007986e0de10ef  mov esi, 0x00
00007986e0de10f4  mov rax, 0x5652C689F530
00007986e0de10fe  call rax
00007986e0de1100  movaps xmm1, [rsp]
00007986e0de1104  add rsp, 0x30
00007986e0de1108  vmovaps xmm0, [rsp]
00007986e0de110d  vmovaps xmm2, [rsp+0x10]
00007986e0de1113  vmovaps xmm3, [rsp+0x20]
00007986e0de1119  vmovaps xmm4, [rsp+0x30]
00007986e0de111f  vmovaps xmm5, [rsp+0x40]
00007986e0de1125  vmovaps xmm6, [rsp+0x50]
00007986e0de112b  vmovaps xmm7, [rsp+0x60]
00007986e0de1131  vmovaps xmm8, [rsp+0x70]
00007986e0de1137  vmovaps xmm9, [rsp+0x80]
00007986e0de1140  vmovaps xmm10, [rsp+0x90]
00007986e0de1149  vmovaps xmm11, [rsp+0xA0]
00007986e0de1152  vmovaps xmm12, [rsp+0xB0]
00007986e0de115b  vmovaps xmm13, [rsp+0xC0]
00007986e0de1164  vmovaps xmm14, [rsp+0xD0]
00007986e0de116d  vmovaps xmm15, [rsp+0xE0]
00007986e0de1176  add rsp, 0xF0
00007986e0de117d  pop r11
00007986e0de117f  pop r10
00007986e0de1181  pop r9
00007986e0de1183  pop r8
00007986e0de1185  pop rsi
00007986e0de1186  pop rdi
00007986e0de1187  pop rdx
00007986e0de1188  pop rcx
00007986e0de1189  pop rax
00007986e0de118a  add rsp, 0x08
00007986e0de118e  jmp 0x00007986E0DDC74D
00007986e0de1193  call 0x00007986E0C0C260
00007986e0de1198  jmp 0x00007986E0DDC75B
00007986e0de119d  call 0x00007986E0CBD750
00007986e0de11a2  jmp 0x00007986E0DDC765
00007986e0de11a7  sub rsp, 0x08
00007986e0de11ab  push rax
00007986e0de11ac  push rcx
00007986e0de11ad  push rdx
00007986e0de11ae  push rdi
00007986e0de11af  push rsi
00007986e0de11b0  push r8
00007986e0de11b2  push r9
00007986e0de11b4  push r10
00007986e0de11b6  push r11
00007986e0de11b8  sub rsp, 0xF0
00007986e0de11bf  vmovaps [rsp], xmm0
00007986e0de11c4  vmovaps [rsp+0x10], xmm1
00007986e0de11ca  vmovaps [rsp+0x20], xmm2
00007986e0de11d0  vmovaps [rsp+0x30], xmm3
00007986e0de11d6  vmovaps [rsp+0x40], xmm4
00007986e0de11dc  vmovaps [rsp+0x50], xmm5
00007986e0de11e2  vmovaps [rsp+0x60], xmm6
00007986e0de11e8  vmovaps [rsp+0x70], xmm7
00007986e0de11ee  vmovaps [rsp+0x80], xmm9
00007986e0de11f7  vmovaps [rsp+0x90], xmm10
00007986e0de1200  vmovaps [rsp+0xA0], xmm11
00007986e0de1209  vmovaps [rsp+0xB0], xmm12
00007986e0de1212  vmovaps [rsp+0xC0], xmm13
00007986e0de121b  vmovaps [rsp+0xD0], xmm14
00007986e0de1224  vmovaps [rsp+0xE0], xmm15
00007986e0de122d  sub rsp, 0x30
00007986e0de1231  movaps [rsp], xmm8
00007986e0de1236  movaps [rsp+0x10], xmm15
00007986e0de123c  movaps [rsp+0x20], xmm7
00007986e0de1241  lea rdi, [rsp]
00007986e0de1245  mov esi, 0x00
00007986e0de124a  mov rax, 0x5652C689F530
00007986e0de1254  call rax
00007986e0de1256  movaps xmm8, [rsp]
00007986e0de125b  add rsp, 0x30
00007986e0de125f  vmovaps xmm0, [rsp]
00007986e0de1264  vmovaps xmm1, [rsp+0x10]
00007986e0de126a  vmovaps xmm2, [rsp+0x20]
00007986e0de1270  vmovaps xmm3, [rsp+0x30]
00007986e0de1276  vmovaps xmm4, [rsp+0x40]
00007986e0de127c  vmovaps xmm5, [rsp+0x50]
00007986e0de1282  vmovaps xmm6, [rsp+0x60]
00007986e0de1288  vmovaps xmm7, [rsp+0x70]
00007986e0de128e  vmovaps xmm9, [rsp+0x80]
00007986e0de1297  vmovaps xmm10, [rsp+0x90]
00007986e0de12a0  vmovaps xmm11, [rsp+0xA0]
00007986e0de12a9  vmovaps xmm12, [rsp+0xB0]
00007986e0de12b2  vmovaps xmm13, [rsp+0xC0]
00007986e0de12bb  vmovaps xmm14, [rsp+0xD0]
00007986e0de12c4  vmovaps xmm15, [rsp+0xE0]
00007986e0de12cd  add rsp, 0xF0
00007986e0de12d4  pop r11
00007986e0de12d6  pop r10
00007986e0de12d8  pop r9
00007986e0de12da  pop r8
00007986e0de12dc  pop rsi
00007986e0de12dd  pop rdi
00007986e0de12de  pop rdx
00007986e0de12df  pop rcx
00007986e0de12e0  pop rax
00007986e0de12e1  add rsp, 0x08
00007986e0de12e5  jmp 0x00007986E0DDC787
00007986e0de12ea  sub rsp, 0x08
00007986e0de12ee  push rax
00007986e0de12ef  push rcx
00007986e0de12f0  push rdx
00007986e0de12f1  push rdi
00007986e0de12f2  push rsi
00007986e0de12f3  push r8
00007986e0de12f5  push r9
00007986e0de12f7  push r10
00007986e0de12f9  push r11
00007986e0de12fb  sub rsp, 0xF0
00007986e0de1302  vmovaps [rsp], xmm0
00007986e0de1307  vmovaps [rsp+0x10], xmm1
00007986e0de130d  vmovaps [rsp+0x20], xmm2
00007986e0de1313  vmovaps [rsp+0x30], xmm3
00007986e0de1319  vmovaps [rsp+0x40], xmm4
00007986e0de131f  vmovaps [rsp+0x50], xmm5
00007986e0de1325  vmovaps [rsp+0x60], xmm6
00007986e0de132b  vmovaps [rsp+0x70], xmm8
00007986e0de1331  vmovaps [rsp+0x80], xmm9
00007986e0de133a  vmovaps [rsp+0x90], xmm10
00007986e0de1343  vmovaps [rsp+0xA0], xmm11
00007986e0de134c  vmovaps [rsp+0xB0], xmm12
00007986e0de1355  vmovaps [rsp+0xC0], xmm13
00007986e0de135e  vmovaps [rsp+0xD0], xmm14
00007986e0de1367  vmovaps [rsp+0xE0], xmm15
00007986e0de1370  sub rsp, 0x30
00007986e0de1374  movaps [rsp], xmm7
00007986e0de1378  movaps [rsp+0x10], xmm9
00007986e0de137e  movaps [rsp+0x20], xmm15
00007986e0de1384  lea rdi, [rsp]
00007986e0de1388  mov esi, 0x00
00007986e0de138d  mov rax, 0x5652C689F530
00007986e0de1397  call rax
00007986e0de1399  movaps xmm7, [rsp]
00007986e0de139d  add rsp, 0x30
00007986e0de13a1  vmovaps xmm0, [rsp]
00007986e0de13a6  vmovaps xmm1, [rsp+0x10]
00007986e0de13ac  vmovaps xmm2, [rsp+0x20]
00007986e0de13b2  vmovaps xmm3, [rsp+0x30]
00007986e0de13b8  vmovaps xmm4, [rsp+0x40]
00007986e0de13be  vmovaps xmm5, [rsp+0x50]
00007986e0de13c4  vmovaps xmm6, [rsp+0x60]
00007986e0de13ca  vmovaps xmm8, [rsp+0x70]
00007986e0de13d0  vmovaps xmm9, [rsp+0x80]
00007986e0de13d9  vmovaps xmm10, [rsp+0x90]
00007986e0de13e2  vmovaps xmm11, [rsp+0xA0]
00007986e0de13eb  vmovaps xmm12, [rsp+0xB0]
00007986e0de13f4  vmovaps xmm13, [rsp+0xC0]
00007986e0de13fd  vmovaps xmm14, [rsp+0xD0]
00007986e0de1406  vmovaps xmm15, [rsp+0xE0]
00007986e0de140f  add rsp, 0xF0
00007986e0de1416  pop r11
00007986e0de1418  pop r10
00007986e0de141a  pop r9
00007986e0de141c  pop r8
00007986e0de141e  pop rsi
00007986e0de141f  pop rdi
00007986e0de1420  pop rdx
00007986e0de1421  pop rcx
00007986e0de1422  pop rax
00007986e0de1423  add rsp, 0x08
00007986e0de1427  jmp 0x00007986E0DDC7B4
00007986e0de142c  sub rsp, 0x08
00007986e0de1430  push rax
00007986e0de1431  push rcx
00007986e0de1432  push rdx
00007986e0de1433  push rdi
00007986e0de1434  push rsi
00007986e0de1435  push r8
00007986e0de1437  push r9
00007986e0de1439  push r10
00007986e0de143b  push r11
00007986e0de143d  sub rsp, 0xF0
00007986e0de1444  vmovaps [rsp], xmm0
00007986e0de1449  vmovaps [rsp+0x10], xmm1
00007986e0de144f  vmovaps [rsp+0x20], xmm2
00007986e0de1455  vmovaps [rsp+0x30], xmm3
00007986e0de145b  vmovaps [rsp+0x40], xmm4
00007986e0de1461  vmovaps [rsp+0x50], xmm5
00007986e0de1467  vmovaps [rsp+0x60], xmm6
00007986e0de146d  vmovaps [rsp+0x70], xmm7
00007986e0de1473  vmovaps [rsp+0x80], xmm8
00007986e0de147c  vmovaps [rsp+0x90], xmm10
00007986e0de1485  vmovaps [rsp+0xA0], xmm11
00007986e0de148e  vmovaps [rsp+0xB0], xmm12
00007986e0de1497  vmovaps [rsp+0xC0], xmm13
00007986e0de14a0  vmovaps [rsp+0xD0], xmm14
00007986e0de14a9  vmovaps [rsp+0xE0], xmm15
00007986e0de14b2  sub rsp, 0x30
00007986e0de14b6  movaps [rsp], xmm9
00007986e0de14bb  movaps [rsp+0x10], xmm13
00007986e0de14c1  movaps [rsp+0x20], xmm15
00007986e0de14c7  lea rdi, [rsp]
00007986e0de14cb  mov esi, 0x00
00007986e0de14d0  mov rax, 0x5652C689F530
00007986e0de14da  call rax
00007986e0de14dc  movaps xmm9, [rsp]
00007986e0de14e1  add rsp, 0x30
00007986e0de14e5  vmovaps xmm0, [rsp]
00007986e0de14ea  vmovaps xmm1, [rsp+0x10]
00007986e0de14f0  vmovaps xmm2, [rsp+0x20]
00007986e0de14f6  vmovaps xmm3, [rsp+0x30]
00007986e0de14fc  vmovaps xmm4, [rsp+0x40]
00007986e0de1502  vmovaps xmm5, [rsp+0x50]
00007986e0de1508  vmovaps xmm6, [rsp+0x60]
00007986e0de150e  vmovaps xmm7, [rsp+0x70]
00007986e0de1514  vmovaps xmm8, [rsp+0x80]
00007986e0de151d  vmovaps xmm10, [rsp+0x90]
00007986e0de1526  vmovaps xmm11, [rsp+0xA0]
00007986e0de152f  vmovaps xmm12, [rsp+0xB0]
00007986e0de1538  vmovaps xmm13, [rsp+0xC0]
00007986e0de1541  vmovaps xmm14, [rsp+0xD0]
00007986e0de154a  vmovaps xmm15, [rsp+0xE0]
00007986e0de1553  add rsp, 0xF0
00007986e0de155a  pop r11
00007986e0de155c  pop r10
00007986e0de155e  pop r9
00007986e0de1560  pop r8
00007986e0de1562  pop rsi
00007986e0de1563  pop rdi
00007986e0de1564  pop rdx
00007986e0de1565  pop rcx
00007986e0de1566  pop rax
00007986e0de1567  add rsp, 0x08
00007986e0de156b  jmp 0x00007986E0DDC7E2
00007986e0de1570  sub rsp, 0x08
00007986e0de1574  push rax
00007986e0de1575  push rcx
00007986e0de1576  push rdx
00007986e0de1577  push rdi
00007986e0de1578  push rsi
00007986e0de1579  push r8
00007986e0de157b  push r9
00007986e0de157d  push r10
00007986e0de157f  push r11
00007986e0de1581  sub rsp, 0xF0
00007986e0de1588  vmovaps [rsp], xmm0
00007986e0de158d  vmovaps [rsp+0x10], xmm1
00007986e0de1593  vmovaps [rsp+0x20], xmm2
00007986e0de1599  vmovaps [rsp+0x30], xmm3
00007986e0de159f  vmovaps [rsp+0x40], xmm4
00007986e0de15a5  vmovaps [rsp+0x50], xmm5
00007986e0de15ab  vmovaps [rsp+0x60], xmm6
00007986e0de15b1  vmovaps [rsp+0x70], xmm7
00007986e0de15b7  vmovaps [rsp+0x80], xmm8
00007986e0de15c0  vmovaps [rsp+0x90], xmm9
00007986e0de15c9  vmovaps [rsp+0xA0], xmm10
00007986e0de15d2  vmovaps [rsp+0xB0], xmm11
00007986e0de15db  vmovaps [rsp+0xC0], xmm12
00007986e0de15e4  vmovaps [rsp+0xD0], xmm13
00007986e0de15ed  vmovaps [rsp+0xE0], xmm14
00007986e0de15f6  sub rsp, 0x30
00007986e0de15fa  movaps [rsp], xmm15
00007986e0de15ff  movaps [rsp+0x10], xmm11
00007986e0de1605  movaps [rsp+0x20], xmm12
00007986e0de160b  lea rdi, [rsp]
00007986e0de160f  mov esi, 0x00
00007986e0de1614  mov rax, 0x5652C689F530
00007986e0de161e  call rax
00007986e0de1620  movaps xmm15, [rsp]
00007986e0de1625  add rsp, 0x30
00007986e0de1629  vmovaps xmm0, [rsp]
00007986e0de162e  vmovaps xmm1, [rsp+0x10]
00007986e0de1634  vmovaps xmm2, [rsp+0x20]
00007986e0de163a  vmovaps xmm3, [rsp+0x30]
00007986e0de1640  vmovaps xmm4, [rsp+0x40]
00007986e0de1646  vmovaps xmm5, [rsp+0x50]
00007986e0de164c  vmovaps xmm6, [rsp+0x60]
00007986e0de1652  vmovaps xmm7, [rsp+0x70]
00007986e0de1658  vmovaps xmm8, [rsp+0x80]
00007986e0de1661  vmovaps xmm9, [rsp+0x90]
00007986e0de166a  vmovaps xmm10, [rsp+0xA0]
00007986e0de1673  vmovaps xmm11, [rsp+0xB0]
00007986e0de167c  vmovaps xmm12, [rsp+0xC0]
00007986e0de1685  vmovaps xmm13, [rsp+0xD0]
00007986e0de168e  vmovaps xmm14, [rsp+0xE0]
00007986e0de1697  add rsp, 0xF0
00007986e0de169e  pop r11
00007986e0de16a0  pop r10
00007986e0de16a2  pop r9
00007986e0de16a4  pop r8
00007986e0de16a6  pop rsi
00007986e0de16a7  pop rdi
00007986e0de16a8  pop rdx
00007986e0de16a9  pop rcx
00007986e0de16aa  pop rax
00007986e0de16ab  add rsp, 0x08
00007986e0de16af  jmp 0x00007986E0DDC7FD
00007986e0de16b4  sub rsp, 0x08
00007986e0de16b8  push rax
00007986e0de16b9  push rcx
00007986e0de16ba  push rdx
00007986e0de16bb  push rdi
00007986e0de16bc  push rsi
00007986e0de16bd  push r8
00007986e0de16bf  push r9
00007986e0de16c1  push r10
00007986e0de16c3  push r11
00007986e0de16c5  sub rsp, 0xF0
00007986e0de16cc  vmovaps [rsp], xmm0
00007986e0de16d1  vmovaps [rsp+0x10], xmm1
00007986e0de16d7  vmovaps [rsp+0x20], xmm2
00007986e0de16dd  vmovaps [rsp+0x30], xmm3
00007986e0de16e3  vmovaps [rsp+0x40], xmm4
00007986e0de16e9  vmovaps [rsp+0x50], xmm5
00007986e0de16ef  vmovaps [rsp+0x60], xmm6
00007986e0de16f5  vmovaps [rsp+0x70], xmm7
00007986e0de16fb  vmovaps [rsp+0x80], xmm8
00007986e0de1704  vmovaps [rsp+0x90], xmm9
00007986e0de170d  vmovaps [rsp+0xA0], xmm10
00007986e0de1716  vmovaps [rsp+0xB0], xmm11
00007986e0de171f  vmovaps [rsp+0xC0], xmm12
00007986e0de1728  vmovaps [rsp+0xD0], xmm14
00007986e0de1731  vmovaps [rsp+0xE0], xmm15
00007986e0de173a  sub rsp, 0x30
00007986e0de173e  movaps [rsp], xmm13
00007986e0de1743  movaps [rsp+0x10], xmm10
00007986e0de1749  movaps [rsp+0x20], xmm14
00007986e0de174f  lea rdi, [rsp]
00007986e0de1753  mov esi, 0x00
00007986e0de1758  mov rax, 0x5652C689F530
00007986e0de1762  call rax
00007986e0de1764  movaps xmm13, [rsp]
00007986e0de1769  add rsp, 0x30
00007986e0de176d  vmovaps xmm0, [rsp]
00007986e0de1772  vmovaps xmm1, [rsp+0x10]
00007986e0de1778  vmovaps xmm2, [rsp+0x20]
00007986e0de177e  vmovaps xmm3, [rsp+0x30]
00007986e0de1784  vmovaps xmm4, [rsp+0x40]
00007986e0de178a  vmovaps xmm5, [rsp+0x50]
00007986e0de1790  vmovaps xmm6, [rsp+0x60]
00007986e0de1796  vmovaps xmm7, [rsp+0x70]
00007986e0de179c  vmovaps xmm8, [rsp+0x80]
00007986e0de17a5  vmovaps xmm9, [rsp+0x90]
00007986e0de17ae  vmovaps xmm10, [rsp+0xA0]
00007986e0de17b7  vmovaps xmm11, [rsp+0xB0]
00007986e0de17c0  vmovaps xmm12, [rsp+0xC0]
00007986e0de17c9  vmovaps xmm14, [rsp+0xD0]
00007986e0de17d2  vmovaps xmm15, [rsp+0xE0]
00007986e0de17db  add rsp, 0xF0
00007986e0de17e2  pop r11
00007986e0de17e4  pop r10
00007986e0de17e6  pop r9
00007986e0de17e8  pop r8
00007986e0de17ea  pop rsi
00007986e0de17eb  pop rdi
00007986e0de17ec  pop rdx
00007986e0de17ed  pop rcx
00007986e0de17ee  pop rax
00007986e0de17ef  add rsp, 0x08
00007986e0de17f3  jmp 0x00007986E0DDC820
00007986e0de17f8  sub rsp, 0x08
00007986e0de17fc  push rax
00007986e0de17fd  push rcx
00007986e0de17fe  push rdx
00007986e0de17ff  push rdi
00007986e0de1800  push rsi
00007986e0de1801  push r8
00007986e0de1803  push r9
00007986e0de1805  push r10
00007986e0de1807  push r11
00007986e0de1809  sub rsp, 0xF0
00007986e0de1810  vmovaps [rsp], xmm0
00007986e0de1815  vmovaps [rsp+0x10], xmm1
00007986e0de181b  vmovaps [rsp+0x20], xmm2
00007986e0de1821  vmovaps [rsp+0x30], xmm3
00007986e0de1827  vmovaps [rsp+0x40], xmm4
00007986e0de182d  vmovaps [rsp+0x50], xmm5
00007986e0de1833  vmovaps [rsp+0x60], xmm6
00007986e0de1839  vmovaps [rsp+0x70], xmm7
00007986e0de183f  vmovaps [rsp+0x80], xmm8
00007986e0de1848  vmovaps [rsp+0x90], xmm9
00007986e0de1851  vmovaps [rsp+0xA0], xmm10
00007986e0de185a  vmovaps [rsp+0xB0], xmm11
00007986e0de1863  vmovaps [rsp+0xC0], xmm12
00007986e0de186c  vmovaps [rsp+0xD0], xmm13
00007986e0de1875  vmovaps [rsp+0xE0], xmm15
00007986e0de187e  sub rsp, 0x30
00007986e0de1882  movaps [rsp], xmm14
00007986e0de1887  movaps [rsp+0x10], xmm1
00007986e0de188c  movaps [rsp+0x20], xmm7
00007986e0de1891  lea rdi, [rsp]
00007986e0de1895  mov esi, 0x00
00007986e0de189a  mov rax, 0x5652C689F530
00007986e0de18a4  call rax
00007986e0de18a6  movaps xmm14, [rsp]
00007986e0de18ab  add rsp, 0x30
00007986e0de18af  vmovaps xmm0, [rsp]
00007986e0de18b4  vmovaps xmm1, [rsp+0x10]
00007986e0de18ba  vmovaps xmm2, [rsp+0x20]
00007986e0de18c0  vmovaps xmm3, [rsp+0x30]
00007986e0de18c6  vmovaps xmm4, [rsp+0x40]
00007986e0de18cc  vmovaps xmm5, [rsp+0x50]
00007986e0de18d2  vmovaps xmm6, [rsp+0x60]
00007986e0de18d8  vmovaps xmm7, [rsp+0x70]
00007986e0de18de  vmovaps xmm8, [rsp+0x80]
00007986e0de18e7  vmovaps xmm9, [rsp+0x90]
00007986e0de18f0  vmovaps xmm10, [rsp+0xA0]
00007986e0de18f9  vmovaps xmm11, [rsp+0xB0]
00007986e0de1902  vmovaps xmm12, [rsp+0xC0]
00007986e0de190b  vmovaps xmm13, [rsp+0xD0]
00007986e0de1914  vmovaps xmm15, [rsp+0xE0]
00007986e0de191d  add rsp, 0xF0
00007986e0de1924  pop r11
00007986e0de1926  pop r10
00007986e0de1928  pop r9
00007986e0de192a  pop r8
00007986e0de192c  pop rsi
00007986e0de192d  pop rdi
00007986e0de192e  pop rdx
00007986e0de192f  pop rcx
00007986e0de1930  pop rax
00007986e0de1931  add rsp, 0x08
00007986e0de1935  jmp 0x00007986E0DDC843
00007986e0de193a  sub rsp, 0x08
00007986e0de193e  push rax
00007986e0de193f  push rcx
00007986e0de1940  push rdx
00007986e0de1941  push rdi
00007986e0de1942  push rsi
00007986e0de1943  push r8
00007986e0de1945  push r9
00007986e0de1947  push r10
00007986e0de1949  push r11
00007986e0de194b  sub rsp, 0xF0
00007986e0de1952  vmovaps [rsp], xmm0
00007986e0de1957  vmovaps [rsp+0x10], xmm2
00007986e0de195d  vmovaps [rsp+0x20], xmm3
00007986e0de1963  vmovaps [rsp+0x30], xmm4
00007986e0de1969  vmovaps [rsp+0x40], xmm5
00007986e0de196f  vmovaps [rsp+0x50], xmm6
00007986e0de1975  vmovaps [rsp+0x60], xmm7
00007986e0de197b  vmovaps [rsp+0x70], xmm8
00007986e0de1981  vmovaps [rsp+0x80], xmm9
00007986e0de198a  vmovaps [rsp+0x90], xmm10
00007986e0de1993  vmovaps [rsp+0xA0], xmm11
00007986e0de199c  vmovaps [rsp+0xB0], xmm12
00007986e0de19a5  vmovaps [rsp+0xC0], xmm13
00007986e0de19ae  vmovaps [rsp+0xD0], xmm14
00007986e0de19b7  vmovaps [rsp+0xE0], xmm15
00007986e0de19c0  sub rsp, 0x30
00007986e0de19c4  movaps [rsp], xmm1
00007986e0de19c8  movaps [rsp+0x10], xmm8
00007986e0de19ce  movaps [rsp+0x20], xmm9
00007986e0de19d4  lea rdi, [rsp]
00007986e0de19d8  mov esi, 0x00
00007986e0de19dd  mov rax, 0x5652C689F530
00007986e0de19e7  call rax
00007986e0de19e9  movaps xmm1, [rsp]
00007986e0de19ed  add rsp, 0x30
00007986e0de19f1  vmovaps xmm0, [rsp]
00007986e0de19f6  vmovaps xmm2, [rsp+0x10]
00007986e0de19fc  vmovaps xmm3, [rsp+0x20]
00007986e0de1a02  vmovaps xmm4, [rsp+0x30]
00007986e0de1a08  vmovaps xmm5, [rsp+0x40]
00007986e0de1a0e  vmovaps xmm6, [rsp+0x50]
00007986e0de1a14  vmovaps xmm7, [rsp+0x60]
00007986e0de1a1a  vmovaps xmm8, [rsp+0x70]
00007986e0de1a20  vmovaps xmm9, [rsp+0x80]
00007986e0de1a29  vmovaps xmm10, [rsp+0x90]
00007986e0de1a32  vmovaps xmm11, [rsp+0xA0]
00007986e0de1a3b  vmovaps xmm12, [rsp+0xB0]
00007986e0de1a44  vmovaps xmm13, [rsp+0xC0]
00007986e0de1a4d  vmovaps xmm14, [rsp+0xD0]
00007986e0de1a56  vmovaps xmm15, [rsp+0xE0]
00007986e0de1a5f  add rsp, 0xF0
00007986e0de1a66  pop r11
00007986e0de1a68  pop r10
00007986e0de1a6a  pop r9
00007986e0de1a6c  pop r8
00007986e0de1a6e  pop rsi
00007986e0de1a6f  pop rdi
00007986e0de1a70  pop rdx
00007986e0de1a71  pop rcx
00007986e0de1a72  pop rax
00007986e0de1a73  add rsp, 0x08
00007986e0de1a77  jmp 0x00007986E0DDC865
00007986e0de1a7c  call 0x00007986E0CE5940
00007986e0de1a81  jmp 0x00007986E0DDC873
00007986e0de1a86  call 0x00007986E0C0C380
00007986e0de1a8b  jmp 0x00007986E0DDC87D
00007986e0de1a90  call 0x00007986E0C0D600
00007986e0de1a95  jmp 0x00007986E0DDC887
00007986e0de1a9a  call 0x00007986E0BFF540
00007986e0de1a9f  jmp 0x00007986E0DDC891
00007986e0de1aa4  int3
00007986e0de1aa5  nop [rax+rax*1], ax
00007986e0de1aae  nop
00007986e0de1ab0  mov rax, [r15+0xF8]
00007986e0de1ab7  lea r14, [rax+0x140]
00007986e0de1abe  mov r12, [r13+r14*1]
00007986e0de1ac3  mov [r15+0xE8], r12
00007986e0de1aca  lea r14, [rax+0x130]
00007986e0de1ad1  mov r12, [r13+r14*1]
00007986e0de1ad6  lea r14, [rax+0x138]
00007986e0de1add  mov r11, [r13+r14*1]
00007986e0de1ae2  movq xmm1, r12
00007986e0de1ae7  movq xmm15, r11
00007986e0de1aec  movq xmm1, xmm1
00007986e0de1af0  movq xmm1, xmm1
00007986e0de1af4  movaps [r15+0x1A0], xmm1
00007986e0de1afc  movq xmm15, xmm15
00007986e0de1b01  movq xmm15, xmm15
00007986e0de1b06  movaps [r15+0x190], xmm15
00007986e0de1b0e  lea r14, [rax+0x120]
00007986e0de1b15  mov r12, [r13+r14*1]
00007986e0de1b1a  lea r14, [rax+0x128]
00007986e0de1b21  mov r11, [r13+r14*1]
00007986e0de1b26  movq xmm1, r12
00007986e0de1b2b  movq xmm15, r11
00007986e0de1b30  movq xmm1, xmm1
00007986e0de1b34  movq xmm1, xmm1
00007986e0de1b38  movaps [r15+0x1C0], xmm1
00007986e0de1b40  movq xmm15, xmm15
00007986e0de1b45  movq xmm15, xmm15
00007986e0de1b4a  movaps [r15+0x1B0], xmm15
00007986e0de1b52  lea r14, [rax+0x110]
00007986e0de1b59  mov r12, [r13+r14*1]
00007986e0de1b5e  lea r14, [rax+0x118]
00007986e0de1b65  mov r11, [r13+r14*1]
00007986e0de1b6a  movq xmm1, r12
00007986e0de1b6f  movq xmm15, r11
00007986e0de1b74  movq xmm1, xmm1
00007986e0de1b78  movq xmm1, xmm1
00007986e0de1b7c  movaps [r15+0x1E0], xmm1
00007986e0de1b84  movq xmm15, xmm15
00007986e0de1b89  movq xmm15, xmm15
00007986e0de1b8e  movaps [r15+0x1D0], xmm15
00007986e0de1b96  lea r14, [rax+0x100]
00007986e0de1b9d  mov r12, [r13+r14*1]
00007986e0de1ba2  lea r14, [rax+0x108]
00007986e0de1ba9  mov r11, [r13+r14*1]
00007986e0de1bae  movq xmm1, r12
00007986e0de1bb3  movq xmm15, r11
00007986e0de1bb8  movq xmm1, xmm1
00007986e0de1bbc  movq xmm1, xmm1
00007986e0de1bc0  movaps [r15+0x200], xmm1
00007986e0de1bc8  movq xmm15, xmm15
00007986e0de1bcd  movq xmm15, xmm15
00007986e0de1bd2  movaps [r15+0x1F0], xmm15
00007986e0de1bda  mov qword ptr [r15+0x40], 0x430000
00007986e0de1be2  mov r14d, 0x430510
00007986e0de1be8  mov r12, [r13+r14*1]
00007986e0de1bed  movq xmm1, r12
00007986e0de1bf2  lea r14, [rax+0x150]
00007986e0de1bf9  mov [r15+0xF8], r14
00007986e0de1c00  mov rax, [r15+0x50]
00007986e0de1c04  movups xmm15, [r13+rax*1]
00007986e0de1c0a  movaps [r15+0x120], xmm15
00007986e0de1c12  mov qword ptr [r15+0x48], 0x10
00007986e0de1c1a  xor eax, eax
00007986e0de1c1c  mov r14d, 0x10
00007986e0de1c22  mov r12d, 0x200
00007986e0de1c28  cmp r14, r12
00007986e0de1c2b  cmc
00007986e0de1c2c  lahf
00007986e0de1c2d  seto al
00007986e0de1c30  mov [r15+0x108], eax
00007986e0de1c37  pextrq rax, xmm15, 0x01
00007986e0de1c3e  movq xmm14, rax
00007986e0de1c43  movaps [r15+0x130], xmm14
00007986e0de1c4b  movq rax, xmm1
00007986e0de1c50  movq r14, xmm15
00007986e0de1c55  vmovq xmm1, rax
00007986e0de1c5a  vmovq xmm15, r14
00007986e0de1c5f  movaps xmm13, xmm1
00007986e0de1c63  addsd xmm13, xmm15
00007986e0de1c68  ucomisd xmm13, xmm13
00007986e0de1c6d  jp 0x00007986E0DE1D86
00007986e0de1c73  movq xmm13, xmm13
00007986e0de1c78  movq rax, xmm13
00007986e0de1c7d  movq r14, xmm14
00007986e0de1c82  vmovq xmm1, rax
00007986e0de1c87  vmovq xmm15, r14
00007986e0de1c8c  movaps xmm14, xmm1
00007986e0de1c90  addsd xmm14, xmm15
00007986e0de1c95  ucomisd xmm14, xmm14
00007986e0de1c9a  jp 0x00007986E0DE1DCE
00007986e0de1ca0  movq xmm14, xmm14
00007986e0de1ca5  movaps [r15+0x110], xmm14
00007986e0de1cad  mov eax, [r15+0x108]
00007986e0de1cb4  sahf
00007986e0de1cb5  jnz 0x00007986E0DE1CE7
00007986e0de1cb7  cmp dword ptr [r15+0x318], 0x00
00007986e0de1cbf  jz 0x00007986E0DE1FE0
00007986e0de1cc5  nop [rax+rax*1], ax
00007986e0de1cce  nop [rax+rax*1], eax
00007986e0de1cd6  mov eax, 0x410490
00007986e0de1cdb  mov [r15+0x100], rax
00007986e0de1ce2  jmp 0x00007986E0BFE110
00007986e0de1ce7  cmp dword ptr [r15+0x318], 0x00
00007986e0de1cef  jz 0x00007986E0DE1E20
00007986e0de1cf5  nop [rax+rax*1], ax
00007986e0de1cfe  nop [rax+rax*1], eax
00007986e0de1d06  mov eax, 0x410474
00007986e0de1d0b  mov [r15+0x100], rax
00007986e0de1d12  jmp 0x00007986E0BFE110
00007986e0de1d17  int3
00007986e0de1d18  call 0x00007986E0CE27E0
00007986e0de1d1d  jmp 0x00007986E0DE1AC3
00007986e0de1d22  call 0x00007986E0CE27E0
00007986e0de1d27  jmp 0x00007986E0DE1AD6
00007986e0de1d2c  call 0x00007986E0CE1570
00007986e0de1d31  jmp 0x00007986E0DE1AE2
00007986e0de1d36  call 0x00007986E0CE27E0
00007986e0de1d3b  jmp 0x00007986E0DE1B1A
00007986e0de1d40  call 0x00007986E0CE1570
00007986e0de1d45  jmp 0x00007986E0DE1B26
00007986e0de1d4a  call 0x00007986E0CE27E0
00007986e0de1d4f  jmp 0x00007986E0DE1B5E
00007986e0de1d54  call 0x00007986E0CE1570
00007986e0de1d59  jmp 0x00007986E0DE1B6A
00007986e0de1d5e  call 0x00007986E0CE27E0
00007986e0de1d63  jmp 0x00007986E0DE1BA2
00007986e0de1d68  call 0x00007986E0CE1570
00007986e0de1d6d  jmp 0x00007986E0DE1BAE
00007986e0de1d72  call 0x00007986E0CE27E0
00007986e0de1d77  jmp 0x00007986E0DE1BED
00007986e0de1d7c  call 0x00007986E0C0E760
00007986e0de1d81  jmp 0x00007986E0DE1C0A
00007986e0de1d86  ucomisd xmm1, xmm15
00007986e0de1d8b  jp 0x00007986E0DE1D9A
00007986e0de1d8d  movaps xmm13, [0x00007986E09FE060]
00007986e0de1d95  jmp 0x00007986E0DE1C73
00007986e0de1d9a  vxorps xmm0, xmm1, xmm15
00007986e0de1d9f  pextrw eax, xmm0, 0x03
00007986e0de1da4  and eax, 0x7FF8
00007986e0de1da9  cmp eax, 0x08
00007986e0de1dac  jnz 0x00007986E0DE1C73
00007986e0de1db2  movq rax, xmm15
00007986e0de1db7  shl rax, 0x0D
00007986e0de1dbb  jbe 0x00007986E0DE1C73
00007986e0de1dc1  vorps xmm13, xmm15, [0x00007986E09FE070]
00007986e0de1dc9  jmp 0x00007986E0DE1C73
00007986e0de1dce  ucomisd xmm1, xmm15
00007986e0de1dd3  jp 0x00007986E0DE1DE2
00007986e0de1dd5  movaps xmm14, [0x00007986E09FE060]
00007986e0de1ddd  jmp 0x00007986E0DE1CA0
00007986e0de1de2  vxorps xmm0, xmm1, xmm15
00007986e0de1de7  pextrw eax, xmm0, 0x03
00007986e0de1dec  and eax, 0x7FF8
00007986e0de1df1  cmp eax, 0x08
00007986e0de1df4  jnz 0x00007986E0DE1CA0
00007986e0de1dfa  movq rax, xmm15
00007986e0de1dff  shl rax, 0x0D
00007986e0de1e03  jbe 0x00007986E0DE1CA0
00007986e0de1e09  vorps xmm14, xmm15, [0x00007986E09FE070]
00007986e0de1e11  jmp 0x00007986E0DE1CA0
00007986e0de1e16  int3
00007986e0de1e17  nop [rax+rax*1], ax
00007986e0de1e20  mov rax, [r15+0x48]
00007986e0de1e24  mov r14, [r15+0x50]
00007986e0de1e28  lea r12, [r14+rax*1]
00007986e0de1e2c  movups xmm1, [r13+r12*1]
00007986e0de1e32  movaps [r15+0x120], xmm1
00007986e0de1e3a  lea r14, [rax+0x10]
00007986e0de1e3e  mov [r15+0x48], r14
00007986e0de1e42  xor eax, eax
00007986e0de1e44  mov r12d, 0x200
00007986e0de1e4a  cmp r14, r12
00007986e0de1e4d  cmc
00007986e0de1e4e  lahf
00007986e0de1e4f  seto al
00007986e0de1e52  mov [r15+0x108], eax
00007986e0de1e59  pextrq rax, xmm1, 0x01
00007986e0de1e60  movq xmm15, rax
00007986e0de1e65  movaps [r15+0x130], xmm15
00007986e0de1e6d  movaps xmm14, [r15+0x110]
00007986e0de1e75  movq rax, xmm14
00007986e0de1e7a  movq r14, xmm1
00007986e0de1e7f  vmovq xmm1, rax
00007986e0de1e84  vmovq xmm14, r14
00007986e0de1e89  movaps xmm13, xmm1
00007986e0de1e8d  addsd xmm13, xmm14
00007986e0de1e92  ucomisd xmm13, xmm13
00007986e0de1e97  jp 0x00007986E0DE1F4C
00007986e0de1e9d  movq xmm13, xmm13
00007986e0de1ea2  movq rax, xmm13
00007986e0de1ea7  movq r14, xmm15
00007986e0de1eac  vmovq xmm1, rax
00007986e0de1eb1  vmovq xmm15, r14
00007986e0de1eb6  movaps xmm14, xmm1
00007986e0de1eba  addsd xmm14, xmm15
00007986e0de1ebf  ucomisd xmm14, xmm14
00007986e0de1ec4  jp 0x00007986E0DE1F94
00007986e0de1eca  movq xmm14, xmm14
00007986e0de1ecf  movaps [r15+0x110], xmm14
00007986e0de1ed7  mov eax, [r15+0x108]
00007986e0de1ede  sahf
00007986e0de1edf  jnz 0x00007986E0DE1F11
00007986e0de1ee1  cmp dword ptr [r15+0x318], 0x00
00007986e0de1ee9  jz 0x00007986E0DE1FE0
00007986e0de1eef  nop [rax+rax*1], ax
00007986e0de1ef8  nop [rax+rax*1], eax
00007986e0de1f00  mov eax, 0x410490
00007986e0de1f05  mov [r15+0x100], rax
00007986e0de1f0c  jmp 0x00007986E0BFE110
00007986e0de1f11  cmp dword ptr [r15+0x318], 0x00
00007986e0de1f19  jz 0x00007986E0DE1E20
00007986e0de1f1f  nop [rax+rax*1], ax
00007986e0de1f28  nop [rax+rax*1], eax
00007986e0de1f30  mov eax, 0x410474
00007986e0de1f35  mov [r15+0x100], rax
00007986e0de1f3c  jmp 0x00007986E0BFE110
00007986e0de1f41  int3
00007986e0de1f42  call 0x00007986E0CB52F0
00007986e0de1f47  jmp 0x00007986E0DE1E32
00007986e0de1f4c  ucomisd xmm1, xmm14
00007986e0de1f51  jp 0x00007986E0DE1F60
00007986e0de1f53  movaps xmm13, [0x00007986E09FE060]
00007986e0de1f5b  jmp 0x00007986E0DE1E9D
00007986e0de1f60  vxorps xmm0, xmm1, xmm14
00007986e0de1f65  pextrw eax, xmm0, 0x03
00007986e0de1f6a  and eax, 0x7FF8
00007986e0de1f6f  cmp eax, 0x08
00007986e0de1f72  jnz 0x00007986E0DE1E9D
00007986e0de1f78  movq rax, xmm14
00007986e0de1f7d  shl rax, 0x0D
00007986e0de1f81  jbe 0x00007986E0DE1E9D
00007986e0de1f87  vorps xmm13, xmm14, [0x00007986E09FE070]
00007986e0de1f8f  jmp 0x00007986E0DE1E9D
00007986e0de1f94  ucomisd xmm1, xmm15
00007986e0de1f99  jp 0x00007986E0DE1FA8
00007986e0de1f9b  movaps xmm14, [0x00007986E09FE060]
00007986e0de1fa3  jmp 0x00007986E0DE1ECA
00007986e0de1fa8  vxorps xmm0, xmm1, xmm15
00007986e0de1fad  pextrw eax, xmm0, 0x03
00007986e0de1fb2  and eax, 0x7FF8
00007986e0de1fb7  cmp eax, 0x08
00007986e0de1fba  jnz 0x00007986E0DE1ECA
00007986e0de1fc0  movq rax, xmm15
00007986e0de1fc5  shl rax, 0x0D
00007986e0de1fc9  jbe 0x00007986E0DE1ECA
00007986e0de1fcf  vorps xmm14, xmm15, [0x00007986E09FE070]
00007986e0de1fd7  jmp 0x00007986E0DE1ECA
00007986e0de1fdc  int3
00007986e0de1fdd  nop [rax], eax
00007986e0de1fe0  mov rax, [r15+0x40]
00007986e0de1fe4  lea r14, [rax+0x510]
00007986e0de1feb  movaps xmm1, [r15+0x110]
00007986e0de1ff3  movq rax, xmm1
00007986e0de1ff8  mov [r13+r14*1], rax
00007986e0de1ffd  mov rax, [r15+0xF0]
00007986e0de2004  mov [r15+0x100], rax
00007986e0de200b  jmp 0x00007986E0DCE5C0
00007986e0de2010  int3
00007986e0de2011  call 0x00007986E0CD5EB0
00007986e0de2016  jmp 0x00007986E0DE1FFD
00007986e0de201b  int3
00007986e0de201c  nop [rax], eax
00007986e0de2020  mov qword ptr [r15+0x100], 0x04
00007986e0de202b  mov esi, 0x00
00007986e0de2030  mov edx, 0x09
00007986e0de2035  mov rdi, 0x7FFEA7A2EE80
00007986e0de203f  mov rax, 0x5652C6732970
00007986e0de2049  call rax
00007986e0de204b  cmp dword ptr [r15+0x318], 0x00
00007986e0de2053  jnz 0x00007986E0BFE110
00007986e0de2059  jmp 0x00007986E0BFE0A0
00007986e0de205e  int3
00007986e0de205f  int3
