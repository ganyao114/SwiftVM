00007f7c123ce69b  nop [rax+rax*1], eax
00007f7c123ce6a0  vmovaps xmm1, [0x00007F7C11FFE010]
00007f7c123ce6a8  movq xmm1, xmm1
00007f7c123ce6ac  movaps [r15+0x110], xmm1
00007f7c123ce6b4  vmovaps xmm1, [0x00007F7C11FFE020]
00007f7c123ce6bc  movq xmm1, xmm1
00007f7c123ce6c0  movaps [r15+0x120], xmm1
00007f7c123ce6c8  mov eax, 0x4204C0
00007f7c123ce6cd  mov r14, [r13+rax*1]
00007f7c123ce6d2  movq xmm1, r14
00007f7c123ce6d7  movaps [r15+0x130], xmm1
00007f7c123ce6df  vmovaps xmm1, [0x00007F7C11FFE030]
00007f7c123ce6e7  vpbroadcastq xmm1, xmm1
00007f7c123ce6ec  movaps [r15+0x140], xmm1
00007f7c123ce6f4  mov qword ptr [r15+0x40], 0x02
00007f7c123ce6fc  vmovaps xmm15, [0x00007F7C11FFE040]
00007f7c123ce704  movq xmm15, xmm15
00007f7c123ce709  movaps [r15+0x150], xmm15
00007f7c123ce711  mov qword ptr [r15+0x58], 0x420000
00007f7c123ce719  vmovaps xmm15, [0x00007F7C11FFE050]
00007f7c123ce721  vpbroadcastq xmm15, xmm15
00007f7c123ce726  movaps [r15+0x160], xmm15
00007f7c123ce72e  mov rax, [r15+0x40]
00007f7c123ce732  vmovq xmm14, rax
00007f7c123ce737  vpbroadcastq xmm14, xmm14
00007f7c123ce73c  movaps [r15+0x170], xmm14
00007f7c123ce744  mov eax, 0x4204D0
00007f7c123ce749  movups xmm13, [r13+rax*1]
00007f7c123ce74f  mov qword ptr [r15+0x40], 0x430518
00007f7c123ce757  mov qword ptr [r15+0x50], 0x430720
00007f7c123ce75f  vpmovqd xmm12, xmm13
00007f7c123ce765  pxor xmm11, xmm11
00007f7c123ce76a  punpcklqdq xmm12, xmm11
00007f7c123ce76f  movaps [r15+0x210], xmm12
00007f7c123ce777  movq xmm12, qword ptr [r15+0x120]
00007f7c123ce780  movq xmm11, qword ptr [r15+0x130]
00007f7c123ce789  psubd xmm12, xmm11
00007f7c123ce78e  movq xmm12, xmm12
00007f7c123ce793  paddq xmm13, xmm14
00007f7c123ce798  movaps [r15+0x180], xmm13
00007f7c123ce7a0  movq xmm14, qword ptr [r15+0x150]
00007f7c123ce7a9  paddd xmm11, xmm14
00007f7c123ce7ae  movq xmm11, xmm11
00007f7c123ce7b3  movq xmm11, xmm11
00007f7c123ce7b8  movaps [r15+0x130], xmm11
00007f7c123ce7c0  pmovzxdq xmm12, xmm12
00007f7c123ce7c6  psllq xmm12, 0x00
00007f7c123ce7cc  movq xmm14, qword ptr [r15+0x210]
00007f7c123ce7d5  movq xmm13, qword ptr [r15+0x110]
00007f7c123ce7de  paddd xmm14, xmm13
00007f7c123ce7e3  movq xmm14, xmm14
00007f7c123ce7e8  vcvtuqq2pd xmm12, xmm12
00007f7c123ce7ee  pmovzxdq xmm14, xmm14
00007f7c123ce7f4  psllq xmm14, 0x00
00007f7c123ce7fa  vcvtuqq2pd xmm14, xmm14
00007f7c123ce800  movaps xmm13, xmm12
00007f7c123ce804  mulpd xmm13, xmm1
00007f7c123ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007f7c123ce80f  ptest xmm11, xmm11
00007f7c123ce815  jnz 0x00007F7C123CE8FF
00007f7c123ce81b  movaps [r15+0x220], xmm13
00007f7c123ce823  mov eax, 0x430720
00007f7c123ce828  movups [r13+rax*1], xmm13
00007f7c123ce82e  movaps xmm1, xmm14
00007f7c123ce832  mulpd xmm1, xmm15
00007f7c123ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007f7c123ce83c  ptest xmm13, xmm13
00007f7c123ce842  jnz 0x00007F7C123CEA4C
00007f7c123ce848  movaps [r15+0x210], xmm1
00007f7c123ce850  mov eax, 0x430518
00007f7c123ce855  movups [r13+rax*1], xmm1
00007f7c123ce85b  mov qword ptr [r15+0x48], 0x10
00007f7c123ce863  xor eax, eax
00007f7c123ce865  mov r14d, 0x10
00007f7c123ce86b  mov r12d, 0x200
00007f7c123ce871  cmp r14, r12
00007f7c123ce874  cmc
00007f7c123ce875  lahf
00007f7c123ce876  seto al
00007f7c123ce879  mov [r15+0x108], eax
00007f7c123ce880  mov eax, [r15+0x108]
00007f7c123ce887  sahf
00007f7c123ce888  jnz 0x00007F7C123CE8BA
00007f7c123ce88a  cmp dword ptr [r15+0x318], 0x00
00007f7c123ce892  jz 0x00007F7C123CEFF0
00007f7c123ce898  nop [rax+rax*1], ax
00007f7c123ce8a1  nop [rax+rax*1], eax
00007f7c123ce8a9  mov eax, 0x4101EC
00007f7c123ce8ae  mov [r15+0x100], rax
00007f7c123ce8b5  jmp 0x00007F7C121FE110
00007f7c123ce8ba  cmp dword ptr [r15+0x318], 0x00
00007f7c123ce8c2  jz 0x00007F7C123CEBA0
00007f7c123ce8c8  nop [rax+rax*1], ax
00007f7c123ce8d1  nop [rax+rax*1], eax
00007f7c123ce8d9  mov eax, 0x4101AC
00007f7c123ce8de  mov [r15+0x100], rax
00007f7c123ce8e5  jmp 0x00007F7C121FE110
00007f7c123ce8ea  int3
00007f7c123ce8eb  call 0x00007F7C1220DC20
00007f7c123ce8f0  jmp 0x00007F7C123CE6D2
00007f7c123ce8f5  call 0x00007F7C1220C260
00007f7c123ce8fa  jmp 0x00007F7C123CE74F
00007f7c123ce8ff  sub rsp, 0x08
00007f7c123ce903  push rax
00007f7c123ce904  push rcx
00007f7c123ce905  push rdx
00007f7c123ce906  push rdi
00007f7c123ce907  push rsi
00007f7c123ce908  push r8
00007f7c123ce90a  push r9
00007f7c123ce90c  push r10
00007f7c123ce90e  push r11
00007f7c123ce910  sub rsp, 0xF0
00007f7c123ce917  vmovaps [rsp], xmm0
00007f7c123ce91c  vmovaps [rsp+0x10], xmm1
00007f7c123ce922  vmovaps [rsp+0x20], xmm2
00007f7c123ce928  vmovaps [rsp+0x30], xmm3
00007f7c123ce92e  vmovaps [rsp+0x40], xmm4
00007f7c123ce934  vmovaps [rsp+0x50], xmm5
00007f7c123ce93a  vmovaps [rsp+0x60], xmm6
00007f7c123ce940  vmovaps [rsp+0x70], xmm7
00007f7c123ce946  vmovaps [rsp+0x80], xmm8
00007f7c123ce94f  vmovaps [rsp+0x90], xmm9
00007f7c123ce958  vmovaps [rsp+0xA0], xmm10
00007f7c123ce961  vmovaps [rsp+0xB0], xmm11
00007f7c123ce96a  vmovaps [rsp+0xC0], xmm12
00007f7c123ce973  vmovaps [rsp+0xD0], xmm14
00007f7c123ce97c  vmovaps [rsp+0xE0], xmm15
00007f7c123ce985  sub rsp, 0x30
00007f7c123ce989  movaps [rsp], xmm13
00007f7c123ce98e  movaps [rsp+0x10], xmm12
00007f7c123ce994  movaps [rsp+0x20], xmm1
00007f7c123ce999  lea rdi, [rsp]
00007f7c123ce99d  mov esi, 0x00
00007f7c123ce9a2  mov rax, 0x5E723D793530
00007f7c123ce9ac  call rax
00007f7c123ce9ae  movaps xmm13, [rsp]
00007f7c123ce9b3  add rsp, 0x30
00007f7c123ce9b7  vmovaps xmm0, [rsp]
00007f7c123ce9bc  vmovaps xmm1, [rsp+0x10]
00007f7c123ce9c2  vmovaps xmm2, [rsp+0x20]
00007f7c123ce9c8  vmovaps xmm3, [rsp+0x30]
00007f7c123ce9ce  vmovaps xmm4, [rsp+0x40]
00007f7c123ce9d4  vmovaps xmm5, [rsp+0x50]
00007f7c123ce9da  vmovaps xmm6, [rsp+0x60]
00007f7c123ce9e0  vmovaps xmm7, [rsp+0x70]
00007f7c123ce9e6  vmovaps xmm8, [rsp+0x80]
00007f7c123ce9ef  vmovaps xmm9, [rsp+0x90]
00007f7c123ce9f8  vmovaps xmm10, [rsp+0xA0]
00007f7c123cea01  vmovaps xmm11, [rsp+0xB0]
00007f7c123cea0a  vmovaps xmm12, [rsp+0xC0]
00007f7c123cea13  vmovaps xmm14, [rsp+0xD0]
00007f7c123cea1c  vmovaps xmm15, [rsp+0xE0]
00007f7c123cea25  add rsp, 0xF0
00007f7c123cea2c  pop r11
00007f7c123cea2e  pop r10
00007f7c123cea30  pop r9
00007f7c123cea32  pop r8
00007f7c123cea34  pop rsi
00007f7c123cea35  pop rdi
00007f7c123cea36  pop rdx
00007f7c123cea37  pop rcx
00007f7c123cea38  pop rax
00007f7c123cea39  add rsp, 0x08
00007f7c123cea3d  jmp 0x00007F7C123CE81B
00007f7c123cea42  call 0x00007F7C1220C380
00007f7c123cea47  jmp 0x00007F7C123CE82E
00007f7c123cea4c  sub rsp, 0x08
00007f7c123cea50  push rax
00007f7c123cea51  push rcx
00007f7c123cea52  push rdx
00007f7c123cea53  push rdi
00007f7c123cea54  push rsi
00007f7c123cea55  push r8
00007f7c123cea57  push r9
00007f7c123cea59  push r10
00007f7c123cea5b  push r11
00007f7c123cea5d  sub rsp, 0xF0
00007f7c123cea64  vmovaps [rsp], xmm0
00007f7c123cea69  vmovaps [rsp+0x10], xmm2
00007f7c123cea6f  vmovaps [rsp+0x20], xmm3
00007f7c123cea75  vmovaps [rsp+0x30], xmm4
00007f7c123cea7b  vmovaps [rsp+0x40], xmm5
00007f7c123cea81  vmovaps [rsp+0x50], xmm6
00007f7c123cea87  vmovaps [rsp+0x60], xmm7
00007f7c123cea8d  vmovaps [rsp+0x70], xmm8
00007f7c123cea93  vmovaps [rsp+0x80], xmm9
00007f7c123cea9c  vmovaps [rsp+0x90], xmm10
00007f7c123ceaa5  vmovaps [rsp+0xA0], xmm11
00007f7c123ceaae  vmovaps [rsp+0xB0], xmm12
00007f7c123ceab7  vmovaps [rsp+0xC0], xmm13
00007f7c123ceac0  vmovaps [rsp+0xD0], xmm14
00007f7c123ceac9  vmovaps [rsp+0xE0], xmm15
00007f7c123cead2  sub rsp, 0x30
00007f7c123cead6  movaps [rsp], xmm1
00007f7c123ceada  movaps [rsp+0x10], xmm14
00007f7c123ceae0  movaps [rsp+0x20], xmm15
00007f7c123ceae6  lea rdi, [rsp]
00007f7c123ceaea  mov esi, 0x00
00007f7c123ceaef  mov rax, 0x5E723D793530
00007f7c123ceaf9  call rax
00007f7c123ceafb  movaps xmm1, [rsp]
00007f7c123ceaff  add rsp, 0x30
00007f7c123ceb03  vmovaps xmm0, [rsp]
00007f7c123ceb08  vmovaps xmm2, [rsp+0x10]
00007f7c123ceb0e  vmovaps xmm3, [rsp+0x20]
00007f7c123ceb14  vmovaps xmm4, [rsp+0x30]
00007f7c123ceb1a  vmovaps xmm5, [rsp+0x40]
00007f7c123ceb20  vmovaps xmm6, [rsp+0x50]
00007f7c123ceb26  vmovaps xmm7, [rsp+0x60]
00007f7c123ceb2c  vmovaps xmm8, [rsp+0x70]
00007f7c123ceb32  vmovaps xmm9, [rsp+0x80]
00007f7c123ceb3b  vmovaps xmm10, [rsp+0x90]
00007f7c123ceb44  vmovaps xmm11, [rsp+0xA0]
00007f7c123ceb4d  vmovaps xmm12, [rsp+0xB0]
00007f7c123ceb56  vmovaps xmm13, [rsp+0xC0]
00007f7c123ceb5f  vmovaps xmm14, [rsp+0xD0]
00007f7c123ceb68  vmovaps xmm15, [rsp+0xE0]
00007f7c123ceb71  add rsp, 0xF0
00007f7c123ceb78  pop r11
00007f7c123ceb7a  pop r10
00007f7c123ceb7c  pop r9
00007f7c123ceb7e  pop r8
00007f7c123ceb80  pop rsi
00007f7c123ceb81  pop rdi
00007f7c123ceb82  pop rdx
00007f7c123ceb83  pop rcx
00007f7c123ceb84  pop rax
00007f7c123ceb85  add rsp, 0x08
00007f7c123ceb89  jmp 0x00007F7C123CE848
00007f7c123ceb8e  call 0x00007F7C121FF540
00007f7c123ceb93  jmp 0x00007F7C123CE85B
00007f7c123ceb98  int3
00007f7c123ceb99  nop [rax], eax
00007f7c123ceba0  movaps xmm1, [r15+0x180]
00007f7c123ceba8  vpmovqd xmm15, xmm1
00007f7c123cebae  pxor xmm14, xmm14
00007f7c123cebb3  punpcklqdq xmm15, xmm14
00007f7c123cebb8  movaps [r15+0x210], xmm15
00007f7c123cebc0  movq xmm15, qword ptr [r15+0x120]
00007f7c123cebc9  movq xmm14, qword ptr [r15+0x130]
00007f7c123cebd2  psubd xmm15, xmm14
00007f7c123cebd7  movq xmm15, xmm15
00007f7c123cebdc  movaps xmm13, [r15+0x170]
00007f7c123cebe4  paddq xmm1, xmm13
00007f7c123cebe9  movaps [r15+0x180], xmm1
00007f7c123cebf1  movq xmm1, qword ptr [r15+0x150]
00007f7c123cebfa  paddd xmm14, xmm1
00007f7c123cebff  movq xmm14, xmm14
00007f7c123cec04  movq xmm14, xmm14
00007f7c123cec09  movaps [r15+0x130], xmm14
00007f7c123cec11  pmovzxdq xmm15, xmm15
00007f7c123cec17  psllq xmm15, 0x00
00007f7c123cec1d  movq xmm1, qword ptr [r15+0x210]
00007f7c123cec26  movq xmm14, qword ptr [r15+0x110]
00007f7c123cec2f  paddd xmm1, xmm14
00007f7c123cec34  movq xmm1, xmm1
00007f7c123cec38  vcvtuqq2pd xmm15, xmm15
00007f7c123cec3e  pmovzxdq xmm1, xmm1
00007f7c123cec43  psllq xmm1, 0x00
00007f7c123cec48  vcvtuqq2pd xmm1, xmm1
00007f7c123cec4e  movaps xmm14, [r15+0x140]
00007f7c123cec56  movaps xmm13, xmm15
00007f7c123cec5a  mulpd xmm13, xmm14
00007f7c123cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f7c123cec65  ptest xmm12, xmm12
00007f7c123cec6b  jnz 0x00007F7C123CED4E
00007f7c123cec71  movaps [r15+0x220], xmm13
00007f7c123cec79  mov rax, [r15+0x48]
00007f7c123cec7d  mov r14, [r15+0x50]
00007f7c123cec81  lea r12, [r14+rax*1]
00007f7c123cec85  movups [r13+r12*1], xmm13
00007f7c123cec8b  movaps xmm15, [r15+0x160]
00007f7c123cec93  movaps xmm14, xmm1
00007f7c123cec97  mulpd xmm14, xmm15
00007f7c123cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007f7c123ceca2  ptest xmm13, xmm13
00007f7c123ceca8  jnz 0x00007F7C123CEE9C
00007f7c123cecae  movaps [r15+0x210], xmm14
00007f7c123cecb6  mov r14, [r15+0x40]
00007f7c123cecba  lea r12, [r14+rax*1]
00007f7c123cecbe  movups [r13+r12*1], xmm14
00007f7c123cecc4  lea r14, [rax+0x10]
00007f7c123cecc8  mov [r15+0x48], r14
00007f7c123ceccc  xor eax, eax
00007f7c123cecce  mov r12d, 0x200
00007f7c123cecd4  cmp r14, r12
00007f7c123cecd7  cmc
00007f7c123cecd8  lahf
00007f7c123cecd9  seto al
00007f7c123cecdc  mov [r15+0x108], eax
00007f7c123cece3  mov eax, [r15+0x108]
00007f7c123cecea  sahf
00007f7c123ceceb  jnz 0x00007F7C123CED1D
00007f7c123ceced  cmp dword ptr [r15+0x318], 0x00
00007f7c123cecf5  jz 0x00007F7C123CEFF0
00007f7c123cecfb  nop [rax+rax*1], ax
00007f7c123ced04  nop [rax+rax*1], eax
00007f7c123ced0c  mov eax, 0x4101EC
00007f7c123ced11  mov [r15+0x100], rax
00007f7c123ced18  jmp 0x00007F7C121FE110
00007f7c123ced1d  cmp dword ptr [r15+0x318], 0x00
00007f7c123ced25  jz 0x00007F7C123CEBA0
00007f7c123ced2b  nop [rax+rax*1], ax
00007f7c123ced34  nop [rax+rax*1], eax
00007f7c123ced3c  mov eax, 0x4101AC
00007f7c123ced41  mov [r15+0x100], rax
00007f7c123ced48  jmp 0x00007F7C121FE110
00007f7c123ced4d  int3
00007f7c123ced4e  sub rsp, 0x08
00007f7c123ced52  push rax
00007f7c123ced53  push rcx
00007f7c123ced54  push rdx
00007f7c123ced55  push rdi
00007f7c123ced56  push rsi
00007f7c123ced57  push r8
00007f7c123ced59  push r9
00007f7c123ced5b  push r10
00007f7c123ced5d  push r11
00007f7c123ced5f  sub rsp, 0xF0
00007f7c123ced66  vmovaps [rsp], xmm0
00007f7c123ced6b  vmovaps [rsp+0x10], xmm1
00007f7c123ced71  vmovaps [rsp+0x20], xmm2
00007f7c123ced77  vmovaps [rsp+0x30], xmm3
00007f7c123ced7d  vmovaps [rsp+0x40], xmm4
00007f7c123ced83  vmovaps [rsp+0x50], xmm5
00007f7c123ced89  vmovaps [rsp+0x60], xmm6
00007f7c123ced8f  vmovaps [rsp+0x70], xmm7
00007f7c123ced95  vmovaps [rsp+0x80], xmm8
00007f7c123ced9e  vmovaps [rsp+0x90], xmm9
00007f7c123ceda7  vmovaps [rsp+0xA0], xmm10
00007f7c123cedb0  vmovaps [rsp+0xB0], xmm11
00007f7c123cedb9  vmovaps [rsp+0xC0], xmm12
00007f7c123cedc2  vmovaps [rsp+0xD0], xmm14
00007f7c123cedcb  vmovaps [rsp+0xE0], xmm15
00007f7c123cedd4  sub rsp, 0x30
00007f7c123cedd8  movaps [rsp], xmm13
00007f7c123ceddd  movaps [rsp+0x10], xmm15
00007f7c123cede3  movaps [rsp+0x20], xmm14
00007f7c123cede9  lea rdi, [rsp]
00007f7c123ceded  mov esi, 0x00
00007f7c123cedf2  mov rax, 0x5E723D793530
00007f7c123cedfc  call rax
00007f7c123cedfe  movaps xmm13, [rsp]
00007f7c123cee03  add rsp, 0x30
00007f7c123cee07  vmovaps xmm0, [rsp]
00007f7c123cee0c  vmovaps xmm1, [rsp+0x10]
00007f7c123cee12  vmovaps xmm2, [rsp+0x20]
00007f7c123cee18  vmovaps xmm3, [rsp+0x30]
00007f7c123cee1e  vmovaps xmm4, [rsp+0x40]
00007f7c123cee24  vmovaps xmm5, [rsp+0x50]
00007f7c123cee2a  vmovaps xmm6, [rsp+0x60]
00007f7c123cee30  vmovaps xmm7, [rsp+0x70]
00007f7c123cee36  vmovaps xmm8, [rsp+0x80]
00007f7c123cee3f  vmovaps xmm9, [rsp+0x90]
00007f7c123cee48  vmovaps xmm10, [rsp+0xA0]
00007f7c123cee51  vmovaps xmm11, [rsp+0xB0]
00007f7c123cee5a  vmovaps xmm12, [rsp+0xC0]
00007f7c123cee63  vmovaps xmm14, [rsp+0xD0]
00007f7c123cee6c  vmovaps xmm15, [rsp+0xE0]
00007f7c123cee75  add rsp, 0xF0
00007f7c123cee7c  pop r11
00007f7c123cee7e  pop r10
00007f7c123cee80  pop r9
00007f7c123cee82  pop r8
00007f7c123cee84  pop rsi
00007f7c123cee85  pop rdi
00007f7c123cee86  pop rdx
00007f7c123cee87  pop rcx
00007f7c123cee88  pop rax
00007f7c123cee89  add rsp, 0x08
00007f7c123cee8d  jmp 0x00007F7C123CEC71
00007f7c123cee92  call 0x00007F7C122C2240
00007f7c123cee97  jmp 0x00007F7C123CEC8B
00007f7c123cee9c  sub rsp, 0x08
00007f7c123ceea0  push rax
00007f7c123ceea1  push rcx
00007f7c123ceea2  push rdx
00007f7c123ceea3  push rdi
00007f7c123ceea4  push rsi
00007f7c123ceea5  push r8
00007f7c123ceea7  push r9
00007f7c123ceea9  push r10
00007f7c123ceeab  push r11
00007f7c123ceead  sub rsp, 0xF0
00007f7c123ceeb4  vmovaps [rsp], xmm0
00007f7c123ceeb9  vmovaps [rsp+0x10], xmm1
00007f7c123ceebf  vmovaps [rsp+0x20], xmm2
00007f7c123ceec5  vmovaps [rsp+0x30], xmm3
00007f7c123ceecb  vmovaps [rsp+0x40], xmm4
00007f7c123ceed1  vmovaps [rsp+0x50], xmm5
00007f7c123ceed7  vmovaps [rsp+0x60], xmm6
00007f7c123ceedd  vmovaps [rsp+0x70], xmm7
00007f7c123ceee3  vmovaps [rsp+0x80], xmm8
00007f7c123ceeec  vmovaps [rsp+0x90], xmm9
00007f7c123ceef5  vmovaps [rsp+0xA0], xmm10
00007f7c123ceefe  vmovaps [rsp+0xB0], xmm11
00007f7c123cef07  vmovaps [rsp+0xC0], xmm12
00007f7c123cef10  vmovaps [rsp+0xD0], xmm13
00007f7c123cef19  vmovaps [rsp+0xE0], xmm15
00007f7c123cef22  sub rsp, 0x30
00007f7c123cef26  movaps [rsp], xmm14
00007f7c123cef2b  movaps [rsp+0x10], xmm1
00007f7c123cef30  movaps [rsp+0x20], xmm15
00007f7c123cef36  lea rdi, [rsp]
00007f7c123cef3a  mov esi, 0x00
00007f7c123cef3f  mov rax, 0x5E723D793530
00007f7c123cef49  call rax
00007f7c123cef4b  movaps xmm14, [rsp]
00007f7c123cef50  add rsp, 0x30
00007f7c123cef54  vmovaps xmm0, [rsp]
00007f7c123cef59  vmovaps xmm1, [rsp+0x10]
00007f7c123cef5f  vmovaps xmm2, [rsp+0x20]
00007f7c123cef65  vmovaps xmm3, [rsp+0x30]
00007f7c123cef6b  vmovaps xmm4, [rsp+0x40]
00007f7c123cef71  vmovaps xmm5, [rsp+0x50]
00007f7c123cef77  vmovaps xmm6, [rsp+0x60]
00007f7c123cef7d  vmovaps xmm7, [rsp+0x70]
00007f7c123cef83  vmovaps xmm8, [rsp+0x80]
00007f7c123cef8c  vmovaps xmm9, [rsp+0x90]
00007f7c123cef95  vmovaps xmm10, [rsp+0xA0]
00007f7c123cef9e  vmovaps xmm11, [rsp+0xB0]
00007f7c123cefa7  vmovaps xmm12, [rsp+0xC0]
00007f7c123cefb0  vmovaps xmm13, [rsp+0xD0]
00007f7c123cefb9  vmovaps xmm15, [rsp+0xE0]
00007f7c123cefc2  add rsp, 0xF0
00007f7c123cefc9  pop r11
00007f7c123cefcb  pop r10
00007f7c123cefcd  pop r9
00007f7c123cefcf  pop r8
00007f7c123cefd1  pop rsi
00007f7c123cefd2  pop rdi
00007f7c123cefd3  pop rdx
00007f7c123cefd4  pop rcx
00007f7c123cefd5  pop rax
00007f7c123cefd6  add rsp, 0x08
00007f7c123cefda  jmp 0x00007F7C123CECAE
00007f7c123cefdf  call 0x00007F7C122C34C0
00007f7c123cefe4  jmp 0x00007F7C123CECC4
00007f7c123cefe9  int3
00007f7c123cefea  nop [rax+rax*1], ax
00007f7c123ceff0  mov rax, [r15+0xF8]
00007f7c123ceff7  lea r14, [rax-0x150]
00007f7c123ceffe  mov [r15+0xF8], r14
00007f7c123cf005  mov rax, [r15+0x50]
00007f7c123cf009  lea r12, [rax+0x80]
00007f7c123cf010  movups xmm1, [r13+r12*1]
00007f7c123cf016  lea r12, [rax+0x90]
00007f7c123cf01d  movups xmm15, [r13+r12*1]
00007f7c123cf023  mov qword ptr [r15+0x48], 0x00
00007f7c123cf02b  lea r12, [rax+0x40]
00007f7c123cf02f  movups xmm14, [r13+r12*1]
00007f7c123cf035  lea r12, [rax+0x50]
00007f7c123cf039  movups xmm13, [r13+r12*1]
00007f7c123cf03f  lea r12, [r14+0x120]
00007f7c123cf046  movq xmm12, qword ptr [r15+0x1C0]
00007f7c123cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007f7c123cf058  movq r11, xmm12
00007f7c123cf05d  movq r10, xmm11
00007f7c123cf062  mov [r13+r12*1], r11
00007f7c123cf067  lea r12, [r14+0x128]
00007f7c123cf06e  mov [r13+r12*1], r10
00007f7c123cf073  vxorps xmm12, xmm12, xmm12
00007f7c123cf078  vpbroadcastq xmm12, xmm12
00007f7c123cf07d  lea r12, [r14+0x100]
00007f7c123cf084  movq xmm11, qword ptr [r15+0x200]
00007f7c123cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007f7c123cf096  movq r11, xmm11
00007f7c123cf09b  movq r10, xmm10
00007f7c123cf0a0  mov [r13+r12*1], r11
00007f7c123cf0a5  lea r12, [r14+0x108]
00007f7c123cf0ac  mov [r13+r12*1], r10
00007f7c123cf0b1  lea r12, [r14+0xE0]
00007f7c123cf0b8  movups [r13+r12*1], xmm15
00007f7c123cf0be  lea r12, [r14+0xF0]
00007f7c123cf0c5  movups [r13+r12*1], xmm1
00007f7c123cf0cb  lea r12, [rax+0xC0]
00007f7c123cf0d2  movups xmm1, [r13+r12*1]
00007f7c123cf0d8  lea r12, [rax+0xD0]
00007f7c123cf0df  movups xmm15, [r13+r12*1]
00007f7c123cf0e5  lea r12, [r14+0x110]
00007f7c123cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007f7c123cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007f7c123cf0fe  movq r11, xmm11
00007f7c123cf103  movq r10, xmm10
00007f7c123cf108  mov [r13+r12*1], r11
00007f7c123cf10d  lea r12, [r14+0x118]
00007f7c123cf114  mov [r13+r12*1], r10
00007f7c123cf119  movups xmm11, [r13+rax*1]
00007f7c123cf11f  lea r12, [rax+0x10]
00007f7c123cf123  movups xmm10, [r13+r12*1]
00007f7c123cf129  lea r12, [r14+0x130]
00007f7c123cf130  movq xmm9, qword ptr [r15+0x1A0]
00007f7c123cf139  movq xmm8, qword ptr [r15+0x190]
00007f7c123cf142  movq r11, xmm9
00007f7c123cf147  movq r10, xmm8
00007f7c123cf14c  mov [r13+r12*1], r11
00007f7c123cf151  lea r12, [r14+0x138]
00007f7c123cf158  mov [r13+r12*1], r10
00007f7c123cf15d  lea r12, [rax+0x140]
00007f7c123cf164  movups xmm9, [r13+r12*1]
00007f7c123cf16a  lea r12, [rax+0x150]
00007f7c123cf171  movups xmm8, [r13+r12*1]
00007f7c123cf177  lea r12, [r14+0xC0]
00007f7c123cf17e  movups [r13+r12*1], xmm15
00007f7c123cf184  lea r12, [r14+0xD0]
00007f7c123cf18b  movups [r13+r12*1], xmm1
00007f7c123cf191  lea r12, [rax+0x100]
00007f7c123cf198  movups xmm1, [r13+r12*1]
00007f7c123cf19e  lea r12, [rax+0x110]
00007f7c123cf1a5  movups xmm15, [r13+r12*1]
00007f7c123cf1ab  lea r12, [r14+0x140]
00007f7c123cf1b2  mov r11, [r15+0xE8]
00007f7c123cf1b9  mov [r13+r12*1], r11
00007f7c123cf1be  lea r12, [rax+0x180]
00007f7c123cf1c5  movups xmm7, [r13+r12*1]
00007f7c123cf1cb  lea r12, [rax+0x190]
00007f7c123cf1d2  movups xmm6, [r13+r12*1]
00007f7c123cf1d8  lea r12, [rax+0x1C0]
00007f7c123cf1df  movups xmm5, [r13+r12*1]
00007f7c123cf1e5  lea r12, [rax+0x1D0]
00007f7c123cf1ec  movups xmm4, [r13+r12*1]
00007f7c123cf1f2  lea r12, [r14+0x20]
00007f7c123cf1f6  movups [r13+r12*1], xmm1
00007f7c123cf1fc  lea r12, [r14+0x30]
00007f7c123cf200  movups [r13+r12*1], xmm13
00007f7c123cf206  lea r12, [rax+0x60]
00007f7c123cf20a  movups xmm1, [r13+r12*1]
00007f7c123cf210  lea r12, [rax+0x70]
00007f7c123cf214  movups xmm13, [r13+r12*1]
00007f7c123cf21a  lea r12, [rax+0x20]
00007f7c123cf21e  movups xmm3, [r13+r12*1]
00007f7c123cf224  lea r12, [rax+0x30]
00007f7c123cf228  movups xmm2, [r13+r12*1]
00007f7c123cf22e  movaps [r15+0x1F0], xmm2
00007f7c123cf236  lea r12, [r14+0x60]
00007f7c123cf23a  movups [r13+r12*1], xmm11
00007f7c123cf240  lea r12, [r14+0x70]
00007f7c123cf244  movups [r13+r12*1], xmm5
00007f7c123cf24a  lea r12, [rax+0xE0]
00007f7c123cf251  movups xmm11, [r13+r12*1]
00007f7c123cf257  lea r12, [rax+0xF0]
00007f7c123cf25e  movups xmm5, [r13+r12*1]
00007f7c123cf264  lea r12, [r14+0xA0]
00007f7c123cf26b  movups [r13+r12*1], xmm13
00007f7c123cf271  lea r12, [r14+0xB0]
00007f7c123cf278  movups [r13+r12*1], xmm1
00007f7c123cf27e  lea r12, [rax+0xA0]
00007f7c123cf285  movups xmm1, [r13+r12*1]
00007f7c123cf28b  lea r12, [rax+0xB0]
00007f7c123cf292  movups xmm13, [r13+r12*1]
00007f7c123cf298  lea r12, [rax+0x120]
00007f7c123cf29f  vmovaps [rsp+0x10], xmm1
00007f7c123cf2a5  movups xmm1, [r13+r12*1]
00007f7c123cf2ab  lea r12, [rax+0x130]
00007f7c123cf2b2  vmovaps [rsp+0x20], xmm1
00007f7c123cf2b8  movups xmm1, [r13+r12*1]
00007f7c123cf2be  lea r12, [rax+0x160]
00007f7c123cf2c5  vmovaps [rsp+0x30], xmm1
00007f7c123cf2cb  movups xmm1, [r13+r12*1]
00007f7c123cf2d1  lea r12, [rax+0x170]
00007f7c123cf2d8  vmovaps [rsp+0x40], xmm1
00007f7c123cf2de  movups xmm1, [r13+r12*1]
00007f7c123cf2e4  movaps [r15+0x2B0], xmm1
00007f7c123cf2ec  lea r12, [r14+0x80]
00007f7c123cf2f3  movups [r13+r12*1], xmm13
00007f7c123cf2f9  lea r12, [r14+0x90]
00007f7c123cf300  vmovaps xmm13, [rsp+0x10]
00007f7c123cf306  movups [r13+r12*1], xmm13
00007f7c123cf30c  lea r12, [rax+0x1A0]
00007f7c123cf313  movups xmm13, [r13+r12*1]
00007f7c123cf319  lea r12, [rax+0x1B0]
00007f7c123cf320  vmovaps [rsp+0x10], xmm1
00007f7c123cf326  movups xmm1, [r13+r12*1]
00007f7c123cf32c  movaps [r15+0x290], xmm13
00007f7c123cf334  movaps [r15+0x1E0], xmm1
00007f7c123cf33c  lea r12, [rax+0x1E0]
00007f7c123cf343  vmovaps [rsp+0x50], xmm1
00007f7c123cf349  movups xmm1, [r13+r12*1]
00007f7c123cf34f  lea r12, [rax+0x1F0]
00007f7c123cf356  vmovaps [rsp+0x60], xmm1
00007f7c123cf35c  movups xmm1, [r13+r12*1]
00007f7c123cf362  mov qword ptr [r15+0x50], 0x430920
00007f7c123cf36a  lea rax, [r14+0x40]
00007f7c123cf36e  vmovaps [rsp+0x70], xmm1
00007f7c123cf374  vmovaps xmm1, [rsp+0x40]
00007f7c123cf37a  movups [r13+rax*1], xmm1
00007f7c123cf380  lea rax, [r14+0x50]
00007f7c123cf384  movups [r13+rax*1], xmm10
00007f7c123cf38a  vmovaps xmm1, [rsp+0x70]
00007f7c123cf390  movups [r13+r14*1], xmm1
00007f7c123cf396  lea rax, [r14+0x10]
00007f7c123cf39a  vmovaps xmm1, [rsp+0x60]
00007f7c123cf3a0  movups [r13+rax*1], xmm1
00007f7c123cf3a6  mov rax, [r15+0x40]
00007f7c123cf3aa  vmovaps [rsp+0x40], xmm3
00007f7c123cf3b0  vmovaps xmm1, [rsp+0x40]
00007f7c123cf3b6  por xmm3, xmm1
00007f7c123cf3ba  vmovaps [rsp+0x40], xmm6
00007f7c123cf3c0  vmovaps xmm10, [rsp+0x40]
00007f7c123cf3c6  por xmm6, xmm10
00007f7c123cf3cb  lea r12, [rax+0x30]
00007f7c123cf3cf  mov r11, [r13+r12*1]
00007f7c123cf3d4  lea r12, [rax+0x38]
00007f7c123cf3d8  mov r10, [r13+r12*1]
00007f7c123cf3dd  movq xmm10, r11
00007f7c123cf3e2  vmovaps [rsp+0x40], xmm1
00007f7c123cf3e8  movq xmm1, r10
00007f7c123cf3ed  movq xmm10, xmm10
00007f7c123cf3f2  vmovaps [rsp+0x60], xmm10
00007f7c123cf3f8  movq xmm10, xmm10
00007f7c123cf3fd  movaps [r15+0x130], xmm10
00007f7c123cf405  movq xmm1, xmm1
00007f7c123cf409  vmovaps [rsp+0x70], xmm1
00007f7c123cf40f  movq xmm1, xmm1
00007f7c123cf413  movaps [r15+0x280], xmm1
00007f7c123cf41b  vmovaps [rsp+0x80], xmm9
00007f7c123cf424  vmovaps xmm1, [rsp+0x80]
00007f7c123cf42d  por xmm9, xmm1
00007f7c123cf432  lea r12, [rax+0x20]
00007f7c123cf436  mov r11, [r13+r12*1]
00007f7c123cf43b  lea r12, [rax+0x28]
00007f7c123cf43f  mov r10, [r13+r12*1]
00007f7c123cf444  movq xmm1, r11
00007f7c123cf449  movq xmm10, r10
00007f7c123cf44e  movq xmm1, xmm1
00007f7c123cf452  vmovaps [rsp+0x80], xmm1
00007f7c123cf45b  movq xmm1, xmm1
00007f7c123cf45f  movaps [r15+0x150], xmm1
00007f7c123cf467  movq xmm10, xmm10
00007f7c123cf46c  vmovaps [rsp+0x90], xmm10
00007f7c123cf475  movq xmm10, xmm10
00007f7c123cf47a  movaps [r15+0x140], xmm10
00007f7c123cf482  lea r12, [rax+0x10]
00007f7c123cf486  mov r11, [r13+r12*1]
00007f7c123cf48b  lea r12, [rax+0x18]
00007f7c123cf48f  mov r10, [r13+r12*1]
00007f7c123cf494  movq xmm1, r11
00007f7c123cf499  movq xmm10, r10
00007f7c123cf49e  movq xmm1, xmm1
00007f7c123cf4a2  vmovaps [rsp+0xA0], xmm1
00007f7c123cf4ab  movq xmm1, xmm1
00007f7c123cf4af  movaps [r15+0x170], xmm1
00007f7c123cf4b7  movq xmm10, xmm10
00007f7c123cf4bc  vmovaps [rsp+0xB0], xmm10
00007f7c123cf4c5  movq xmm10, xmm10
00007f7c123cf4ca  movaps [r15+0x160], xmm10
00007f7c123cf4d2  mov r12, [r13+rax*1]
00007f7c123cf4d7  vmovq xmm1, r12
00007f7c123cf4dc  vpbroadcastq xmm1, xmm1
00007f7c123cf4e1  lea r12, [rax+0x08]
00007f7c123cf4e5  mov rax, [r13+r12*1]
00007f7c123cf4ea  movq xmm10, rax
00007f7c123cf4ef  movaps [r15+0x230], xmm10
00007f7c123cf4f7  lea rax, [r14+0x50]
00007f7c123cf4fb  movups xmm10, [r13+rax*1]
00007f7c123cf501  lea rax, [r14+0x60]
00007f7c123cf505  vmovaps [rsp+0xC0], xmm1
00007f7c123cf50e  movups xmm1, [r13+rax*1]
00007f7c123cf514  lea rax, [r14+0x30]
00007f7c123cf518  vmovaps [rsp+0xD0], xmm1
00007f7c123cf521  movups xmm1, [r13+rax*1]
00007f7c123cf527  mov qword ptr [r15+0x60], 0x430920
00007f7c123cf52f  mov qword ptr [r15+0x58], 0x40
00007f7c123cf537  vmovaps [rsp+0xE0], xmm1
00007f7c123cf540  vmovaps [rsp+0xF0], xmm15
00007f7c123cf549  vmovaps xmm15, [rsp+0xC0]
00007f7c123cf552  vmovaps [rsp+0xC0], xmm14
00007f7c123cf55b  vmovaps xmm14, [rsp+0x40]
00007f7c123cf561  vmovaps [rsp+0x40], xmm13
00007f7c123cf567  movaps xmm1, xmm15
00007f7c123cf56b  mulpd xmm1, xmm14
00007f7c123cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007f7c123cf575  ptest xmm13, xmm13
00007f7c123cf57b  jnz 0x00007F7C123D0682
00007f7c123cf581  movq xmm14, qword ptr [r15+0x230]
00007f7c123cf58a  vmovaps [rsp+0x100], xmm14
00007f7c123cf593  vpermilpd xmm14, xmm14, 0x00
00007f7c123cf599  vmovaps [rsp+0x110], xmm1
00007f7c123cf5a2  vmovaps xmm1, [rsp+0xE0]
00007f7c123cf5ab  vmovaps [rsp+0xE0], xmm15
00007f7c123cf5b4  movaps xmm13, xmm1
00007f7c123cf5b8  mulpd xmm13, xmm14
00007f7c123cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007f7c123cf5c3  ptest xmm15, xmm15
00007f7c123cf5c9  jnz 0x00007F7C123D07C4
00007f7c123cf5cf  vxorps xmm1, xmm1, xmm1
00007f7c123cf5d3  vpbroadcastq xmm1, xmm1
00007f7c123cf5d8  vmovaps xmm14, [rsp+0xE0]
00007f7c123cf5e1  vmovaps [rsp+0xE0], xmm1
00007f7c123cf5ea  vmovaps xmm1, [rsp+0xD0]
00007f7c123cf5f3  vmovaps [rsp+0xD0], xmm13
00007f7c123cf5fc  movaps xmm15, xmm14
00007f7c123cf600  mulpd xmm15, xmm1
00007f7c123cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007f7c123cf60b  ptest xmm13, xmm13
00007f7c123cf611  jnz 0x00007F7C123D0907
00007f7c123cf617  movaps xmm1, xmm14
00007f7c123cf61b  mulpd xmm1, xmm10
00007f7c123cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007f7c123cf625  ptest xmm13, xmm13
00007f7c123cf62b  jnz 0x00007F7C123D0A4A
00007f7c123cf631  movaps xmm13, xmm14
00007f7c123cf635  mulpd xmm13, xmm2
00007f7c123cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007f7c123cf640  ptest xmm10, xmm10
00007f7c123cf646  jnz 0x00007F7C123D0B8C
00007f7c123cf64c  vmovaps [rsp+0x120], xmm7
00007f7c123cf655  vmovaps xmm14, [rsp+0x120]
00007f7c123cf65e  por xmm7, xmm14
00007f7c123cf663  vmovaps xmm14, [rsp+0xC0]
00007f7c123cf66c  vmovaps xmm10, [rsp+0xC0]
00007f7c123cf675  por xmm14, xmm10
00007f7c123cf67a  vmovaps xmm2, [rsp+0x100]
00007f7c123cf683  vpermilpd xmm2, xmm2, 0x00
00007f7c123cf689  vmovaps [rsp+0xC0], xmm1
00007f7c123cf692  vmovaps [rsp+0x120], xmm15
00007f7c123cf69b  movaps xmm1, xmm10
00007f7c123cf69f  mulpd xmm1, xmm2
00007f7c123cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007f7c123cf6a8  ptest xmm15, xmm15
00007f7c123cf6ae  jnz 0x00007F7C123D0CCF
00007f7c123cf6b4  xor eax, eax
00007f7c123cf6b6  mov r12d, 0x40
00007f7c123cf6bc  mov r11d, 0x200
00007f7c123cf6c2  cmp r12, r11
00007f7c123cf6c5  cmc
00007f7c123cf6c6  lahf
00007f7c123cf6c7  seto al
00007f7c123cf6ca  mov [r15+0x108], eax
00007f7c123cf6d1  vmovaps xmm10, [rsp+0x110]
00007f7c123cf6da  vmovaps xmm2, [rsp+0xE0]
00007f7c123cf6e3  vmovaps [rsp+0xE0], xmm1
00007f7c123cf6ec  movaps xmm15, xmm10
00007f7c123cf6f0  addpd xmm15, xmm2
00007f7c123cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f7c123cf6fb  ptest xmm1, xmm1
00007f7c123cf700  jnz 0x00007F7C123D0E10
00007f7c123cf706  vmovaps xmm10, [rsp+0x120]
00007f7c123cf70f  vmovaps [rsp+0x110], xmm15
00007f7c123cf718  movaps xmm1, xmm10
00007f7c123cf71c  addpd xmm1, xmm12
00007f7c123cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007f7c123cf726  ptest xmm15, xmm15
00007f7c123cf72c  jnz 0x00007F7C123D0F53
00007f7c123cf732  vmovaps xmm10, [rsp+0xC0]
00007f7c123cf73b  vmovaps [rsp+0xC0], xmm1
00007f7c123cf744  movaps xmm15, xmm10
00007f7c123cf748  addpd xmm15, xmm12
00007f7c123cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007f7c123cf753  ptest xmm1, xmm1
00007f7c123cf758  jnz 0x00007F7C123D1095
00007f7c123cf75e  vmovaps xmm1, [rsp+0x30]
00007f7c123cf764  vmovaps xmm12, [rsp+0x30]
00007f7c123cf76a  por xmm1, xmm12
00007f7c123cf76f  vmovaps xmm12, [rsp+0x20]
00007f7c123cf775  vmovaps xmm10, [rsp+0x20]
00007f7c123cf77b  por xmm12, xmm10
00007f7c123cf780  vmovaps [rsp+0x20], xmm5
00007f7c123cf786  vmovaps xmm10, [rsp+0x20]
00007f7c123cf78c  por xmm5, xmm10
00007f7c123cf791  vmovaps [rsp+0x20], xmm11
00007f7c123cf797  vmovaps xmm10, [rsp+0x20]
00007f7c123cf79d  por xmm11, xmm10
00007f7c123cf7a2  vmovaps [rsp+0x20], xmm4
00007f7c123cf7a8  vmovaps xmm10, [rsp+0x20]
00007f7c123cf7ae  por xmm4, xmm10
00007f7c123cf7b3  vmovaps [rsp+0x20], xmm8
00007f7c123cf7b9  vmovaps xmm10, [rsp+0x20]
00007f7c123cf7bf  por xmm8, xmm10
00007f7c123cf7c4  vmovaps xmm10, [rsp+0xF0]
00007f7c123cf7cd  vmovaps [rsp+0x20], xmm1
00007f7c123cf7d3  vmovaps xmm1, [rsp+0xF0]
00007f7c123cf7dc  por xmm10, xmm1
00007f7c123cf7e1  lea rax, [r14+0xA0]
00007f7c123cf7e8  movups xmm1, [r13+rax*1]
00007f7c123cf7ee  lea rax, [r14+0xB0]
00007f7c123cf7f5  vmovaps [rsp+0x30], xmm1
00007f7c123cf7fb  movups xmm1, [r13+rax*1]
00007f7c123cf801  vmovaps [rsp+0xF0], xmm1
00007f7c123cf80a  vmovaps [rsp+0x120], xmm15
00007f7c123cf813  movaps xmm1, xmm13
00007f7c123cf817  addpd xmm1, xmm2
00007f7c123cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007f7c123cf820  ptest xmm15, xmm15
00007f7c123cf826  jnz 0x00007F7C123D11ED
00007f7c123cf82c  lea rax, [r14+0xF0]
00007f7c123cf833  movups xmm15, [r13+rax*1]
00007f7c123cf839  vmovaps xmm2, [rsp+0xC0]
00007f7c123cf842  vmovaps [rsp+0xC0], xmm1
00007f7c123cf84b  vmovaps xmm1, [rsp+0xE0]
00007f7c123cf854  vmovaps [rsp+0xE0], xmm15
00007f7c123cf85d  movaps xmm13, xmm2
00007f7c123cf861  addpd xmm13, xmm1
00007f7c123cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007f7c123cf86c  ptest xmm15, xmm15
00007f7c123cf872  jnz 0x00007F7C123D1338
00007f7c123cf878  vmovaps xmm15, [rsp+0x120]
00007f7c123cf881  vmovaps xmm2, [rsp+0xD0]
00007f7c123cf88a  vmovaps [rsp+0xD0], xmm14
00007f7c123cf893  movaps xmm1, xmm15
00007f7c123cf897  addpd xmm1, xmm2
00007f7c123cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007f7c123cf8a0  ptest xmm14, xmm14
00007f7c123cf8a6  jnz 0x00007F7C123D147A
00007f7c123cf8ac  vmovaps xmm15, [rsp+0x100]
00007f7c123cf8b5  vpermilpd xmm15, xmm15, 0x00
00007f7c123cf8bb  vmovaps xmm2, [rsp+0xF0]
00007f7c123cf8c4  vmovaps [rsp+0xF0], xmm1
00007f7c123cf8cd  movaps xmm14, xmm2
00007f7c123cf8d1  mulpd xmm14, xmm15
00007f7c123cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007f7c123cf8dc  ptest xmm1, xmm1
00007f7c123cf8e1  jnz 0x00007F7C123D15BB
00007f7c123cf8e7  vmovaps xmm1, [rsp+0xA0]
00007f7c123cf8f0  vpermilpd xmm1, xmm1, 0x00
00007f7c123cf8f6  vmovaps xmm2, [rsp+0xE0]
00007f7c123cf8ff  vmovaps [rsp+0xE0], xmm14
00007f7c123cf908  movaps xmm15, xmm2
00007f7c123cf90c  mulpd xmm15, xmm1
00007f7c123cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007f7c123cf917  ptest xmm14, xmm14
00007f7c123cf91d  jnz 0x00007F7C123D16FE
00007f7c123cf923  lea rax, [r14+0xE0]
00007f7c123cf92a  movups xmm1, [r13+rax*1]
00007f7c123cf930  vmovaps xmm14, [rsp+0x100]
00007f7c123cf939  vpermilpd xmm14, xmm14, 0x00
00007f7c123cf93f  vmovaps [rsp+0x100], xmm1
00007f7c123cf948  vmovaps xmm1, [rsp+0x30]
00007f7c123cf94e  vmovaps [rsp+0x30], xmm15
00007f7c123cf954  movaps xmm2, xmm1
00007f7c123cf957  mulpd xmm2, xmm14
00007f7c123cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007f7c123cf961  ptest xmm15, xmm15
00007f7c123cf967  jnz 0x00007F7C123D184A
00007f7c123cf96d  vmovaps [rsp+0x120], xmm10
00007f7c123cf976  vmovaps xmm1, [rsp+0x120]
00007f7c123cf97f  por xmm10, xmm1
00007f7c123cf984  movaps [r15+0x300], xmm10
00007f7c123cf98c  vmovaps [rsp+0x120], xmm8
00007f7c123cf995  vmovaps xmm1, [rsp+0x120]
00007f7c123cf99e  por xmm8, xmm1
00007f7c123cf9a3  movaps [r15+0x190], xmm8
00007f7c123cf9ab  vmovaps xmm1, [rsp+0xA0]
00007f7c123cf9b4  vpermilpd xmm1, xmm1, 0x00
00007f7c123cf9ba  vmovaps xmm14, [rsp+0x100]
00007f7c123cf9c3  vmovaps [rsp+0x100], xmm13
00007f7c123cf9cc  movaps xmm15, xmm14
00007f7c123cf9d0  mulpd xmm15, xmm1
00007f7c123cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007f7c123cf9db  ptest xmm13, xmm13
00007f7c123cf9e1  jnz 0x00007F7C123D198B
00007f7c123cf9e7  lea rax, [r14+0x90]
00007f7c123cf9ee  movups xmm1, [r13+rax*1]
00007f7c123cf9f4  vmovaps [rsp+0x120], xmm4
00007f7c123cf9fd  vmovaps xmm14, [rsp+0x120]
00007f7c123cfa06  por xmm4, xmm14
00007f7c123cfa0b  movaps [r15+0x1C0], xmm4
00007f7c123cfa13  vmovaps [rsp+0x120], xmm11
00007f7c123cfa1c  vmovaps xmm14, [rsp+0x120]
00007f7c123cfa25  por xmm11, xmm14
00007f7c123cfa2a  movaps [r15+0x200], xmm11
00007f7c123cfa32  vmovaps [rsp+0x120], xmm5
00007f7c123cfa3b  vmovaps xmm14, [rsp+0x120]
00007f7c123cfa44  por xmm5, xmm14
00007f7c123cfa49  movaps [r15+0x2D0], xmm5
00007f7c123cfa51  vmovaps [rsp+0x120], xmm12
00007f7c123cfa5a  vmovaps xmm14, [rsp+0x120]
00007f7c123cfa63  por xmm12, xmm14
00007f7c123cfa68  movaps [r15+0x2E0], xmm12
00007f7c123cfa70  vmovaps xmm13, [rsp+0x110]
00007f7c123cfa79  vmovaps [rsp+0x110], xmm1
00007f7c123cfa82  vmovaps xmm1, [rsp+0xE0]
00007f7c123cfa8b  vmovaps [rsp+0xE0], xmm15
00007f7c123cfa94  movaps xmm14, xmm13
00007f7c123cfa98  addpd xmm14, xmm1
00007f7c123cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007f7c123cfaa3  ptest xmm15, xmm15
00007f7c123cfaa9  jnz 0x00007F7C123D1AD8
00007f7c123cfaaf  vmovaps xmm1, [rsp+0xA0]
00007f7c123cfab8  vpermilpd xmm1, xmm1, 0x00
00007f7c123cfabe  vmovaps xmm13, [rsp+0x110]
00007f7c123cfac7  vmovaps [rsp+0x110], xmm14
00007f7c123cfad0  movaps xmm15, xmm13
00007f7c123cfad4  mulpd xmm15, xmm1
00007f7c123cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007f7c123cfadf  ptest xmm14, xmm14
00007f7c123cfae5  jnz 0x00007F7C123D1C1B
00007f7c123cfaeb  lea rax, [r14+0x80]
00007f7c123cfaf2  movups xmm1, [r13+rax*1]
00007f7c123cfaf8  vmovaps xmm13, [rsp+0xC0]
00007f7c123cfb01  vmovaps [rsp+0xC0], xmm1
00007f7c123cfb0a  movaps xmm14, xmm13
00007f7c123cfb0e  addpd xmm14, xmm2
00007f7c123cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007f7c123cfb19  ptest xmm1, xmm1
00007f7c123cfb1e  jnz 0x00007F7C123D1D68
00007f7c123cfb24  vmovaps xmm13, [rsp+0x100]
00007f7c123cfb2d  vmovaps xmm2, [rsp+0x30]
00007f7c123cfb33  vmovaps [rsp+0x30], xmm15
00007f7c123cfb39  movaps xmm1, xmm13
00007f7c123cfb3d  addpd xmm1, xmm2
00007f7c123cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007f7c123cfb46  ptest xmm15, xmm15
00007f7c123cfb4c  jnz 0x00007F7C123D1EAB
00007f7c123cfb52  vmovaps xmm15, [rsp+0x20]
00007f7c123cfb58  vmovaps xmm13, [rsp+0x20]
00007f7c123cfb5e  por xmm15, xmm13
00007f7c123cfb63  movaps [r15+0x2F0], xmm15
00007f7c123cfb6b  vmovaps xmm13, [rsp+0xA0]
00007f7c123cfb74  vpermilpd xmm13, xmm13, 0x00
00007f7c123cfb7a  vmovaps [rsp+0x20], xmm1
00007f7c123cfb80  vmovaps xmm1, [rsp+0xC0]
00007f7c123cfb89  vmovaps [rsp+0xA0], xmm15
00007f7c123cfb92  movaps xmm2, xmm1
00007f7c123cfb95  mulpd xmm2, xmm13
00007f7c123cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007f7c123cfb9f  ptest xmm15, xmm15
00007f7c123cfba5  jnz 0x00007F7C123D1FEC
00007f7c123cfbab  lea rax, [r14+0xD0]
00007f7c123cfbb2  movups xmm1, [r13+rax*1]
00007f7c123cfbb8  vmovaps xmm13, [rsp+0xF0]
00007f7c123cfbc1  vmovaps [rsp+0xC0], xmm1
00007f7c123cfbca  vmovaps xmm1, [rsp+0xE0]
00007f7c123cfbd3  vmovaps [rsp+0xE0], xmm14
00007f7c123cfbdc  movaps xmm15, xmm13
00007f7c123cfbe0  addpd xmm15, xmm1
00007f7c123cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007f7c123cfbeb  ptest xmm14, xmm14
00007f7c123cfbf1  jnz 0x00007F7C123D2137
00007f7c123cfbf7  vmovaps xmm1, [rsp+0xB0]
00007f7c123cfc00  vpermilpd xmm1, xmm1, 0x00
00007f7c123cfc06  movaps xmm14, xmm11
00007f7c123cfc0a  mulpd xmm14, xmm1
00007f7c123cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007f7c123cfc15  ptest xmm13, xmm13
00007f7c123cfc1b  jnz 0x00007F7C123D227A
00007f7c123cfc21  movaps [r15+0x260], xmm14
00007f7c123cfc29  vxorps xmm1, xmm1, xmm1
00007f7c123cfc2d  vpbroadcastq xmm1, xmm1
00007f7c123cfc32  movaps [r15+0x1B0], xmm1
00007f7c123cfc3a  vmovaps xmm1, [rsp+0xB0]
00007f7c123cfc43  vpermilpd xmm1, xmm1, 0x00
00007f7c123cfc49  vmovaps xmm11, [rsp+0xC0]
00007f7c123cfc52  vmovaps [rsp+0xC0], xmm15
00007f7c123cfc5b  movaps xmm13, xmm11
00007f7c123cfc5f  mulpd xmm13, xmm1
00007f7c123cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007f7c123cfc6a  ptest xmm15, xmm15
00007f7c123cfc70  jnz 0x00007F7C123D23BD
00007f7c123cfc76  lea rax, [r14+0xC0]
00007f7c123cfc7d  movups xmm1, [r13+rax*1]
00007f7c123cfc83  vmovaps xmm11, [rsp+0x110]
00007f7c123cfc8c  vmovaps [rsp+0xF0], xmm1
00007f7c123cfc95  vmovaps xmm1, [rsp+0x30]
00007f7c123cfc9b  vmovaps [rsp+0x30], xmm14
00007f7c123cfca1  movaps xmm15, xmm11
00007f7c123cfca5  addpd xmm15, xmm1
00007f7c123cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007f7c123cfcb0  ptest xmm14, xmm14
00007f7c123cfcb6  jnz 0x00007F7C123D250A
00007f7c123cfcbc  vmovaps [rsp+0x100], xmm9
00007f7c123cfcc5  vmovaps xmm1, [rsp+0x100]
00007f7c123cfcce  por xmm9, xmm1
00007f7c123cfcd3  movaps [r15+0x270], xmm9
00007f7c123cfcdb  vmovaps [rsp+0x100], xmm6
00007f7c123cfce4  vmovaps xmm1, [rsp+0x100]
00007f7c123cfced  por xmm6, xmm1
00007f7c123cfcf1  movaps [r15+0x1A0], xmm6
00007f7c123cfcf9  vmovaps xmm14, [rsp+0xB0]
00007f7c123cfd02  vpermilpd xmm14, xmm14, 0x00
00007f7c123cfd08  vmovaps xmm6, [rsp+0xF0]
00007f7c123cfd11  vmovaps [rsp+0xF0], xmm1
00007f7c123cfd1a  movaps xmm11, xmm6
00007f7c123cfd1e  mulpd xmm11, xmm14
00007f7c123cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007f7c123cfd29  ptest xmm1, xmm1
00007f7c123cfd2e  jnz 0x00007F7C123D264D
00007f7c123cfd34  lea rax, [r14+0x20]
00007f7c123cfd38  movups xmm1, [r13+rax*1]
00007f7c123cfd3e  movaps [r15+0x110], xmm1
00007f7c123cfd46  vmovaps xmm6, [rsp+0xE0]
00007f7c123cfd4f  vmovaps [rsp+0xE0], xmm1
00007f7c123cfd58  movaps xmm14, xmm6
00007f7c123cfd5c  addpd xmm14, xmm2
00007f7c123cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007f7c123cfd67  ptest xmm1, xmm1
00007f7c123cfd6c  jnz 0x00007F7C123D279A
00007f7c123cfd72  vmovaps xmm1, [rsp+0xB0]
00007f7c123cfd7b  vpermilpd xmm1, xmm1, 0x00
00007f7c123cfd81  movaps xmm6, xmm5
00007f7c123cfd84  mulpd xmm6, xmm1
00007f7c123cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007f7c123cfd8d  ptest xmm2, xmm2
00007f7c123cfd92  jnz 0x00007F7C123D28DC
00007f7c123cfd98  vmovaps xmm5, [rsp+0x20]
00007f7c123cfd9e  movaps xmm1, xmm5
00007f7c123cfda1  addpd xmm1, xmm13
00007f7c123cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007f7c123cfdab  ptest xmm2, xmm2
00007f7c123cfdb0  jnz 0x00007F7C123D2A1C
00007f7c123cfdb6  vmovaps xmm13, [rsp+0x80]
00007f7c123cfdbf  vpermilpd xmm13, xmm13, 0x00
00007f7c123cfdc5  vmovaps xmm2, [rsp+0xE0]
00007f7c123cfdce  vmovaps [rsp+0x20], xmm1
00007f7c123cfdd4  movaps xmm5, xmm2
00007f7c123cfdd7  mulpd xmm5, xmm13
00007f7c123cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007f7c123cfde1  ptest xmm1, xmm1
00007f7c123cfde6  jnz 0x00007F7C123D2B5D
00007f7c123cfdec  vmovaps xmm1, [rsp+0x80]
00007f7c123cfdf5  vpermilpd xmm1, xmm1, 0x00
00007f7c123cfdfb  movaps xmm13, xmm10
00007f7c123cfdff  mulpd xmm13, xmm1
00007f7c123cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007f7c123cfe0a  ptest xmm2, xmm2
00007f7c123cfe0f  jnz 0x00007F7C123D2C9E
00007f7c123cfe15  vmovaps xmm10, [rsp+0x30]
00007f7c123cfe1b  movaps xmm1, xmm15
00007f7c123cfe1f  addpd xmm1, xmm10
00007f7c123cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007f7c123cfe29  ptest xmm2, xmm2
00007f7c123cfe2e  jnz 0x00007F7C123D2DE1
00007f7c123cfe34  vmovaps xmm10, [rsp+0xC0]
00007f7c123cfe3d  movaps xmm15, xmm10
00007f7c123cfe41  addpd xmm15, xmm11
00007f7c123cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007f7c123cfe4c  ptest xmm2, xmm2
00007f7c123cfe51  jnz 0x00007F7C123D2F23
00007f7c123cfe57  vmovaps xmm11, [rsp+0x80]
00007f7c123cfe60  vpermilpd xmm11, xmm11, 0x00
00007f7c123cfe66  movaps xmm10, xmm12
00007f7c123cfe6a  mulpd xmm10, xmm11
00007f7c123cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007f7c123cfe75  ptest xmm2, xmm2
00007f7c123cfe7a  jnz 0x00007F7C123D3067
00007f7c123cfe80  vmovaps xmm12, [rsp+0x80]
00007f7c123cfe89  vpermilpd xmm12, xmm12, 0x00
00007f7c123cfe8f  vmovaps xmm2, [rsp+0xA0]
00007f7c123cfe98  vmovaps [rsp+0x30], xmm1
00007f7c123cfe9e  movaps xmm11, xmm2
00007f7c123cfea2  mulpd xmm11, xmm12
00007f7c123cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007f7c123cfead  ptest xmm1, xmm1
00007f7c123cfeb2  jnz 0x00007F7C123D31AB
00007f7c123cfeb8  movaps xmm1, xmm14
00007f7c123cfebc  addpd xmm1, xmm6
00007f7c123cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007f7c123cfec5  ptest xmm12, xmm12
00007f7c123cfecb  jnz 0x00007F7C123D32EE
00007f7c123cfed1  vmovaps xmm12, [rsp+0x20]
00007f7c123cfed7  movaps xmm14, xmm12
00007f7c123cfedb  addpd xmm14, xmm5
00007f7c123cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007f7c123cfee6  ptest xmm6, xmm6
00007f7c123cfeeb  jnz 0x00007F7C123D342F
00007f7c123cfef1  vmovaps xmm12, [rsp+0x90]
00007f7c123cfefa  vpermilpd xmm12, xmm12, 0x00
00007f7c123cff00  movaps xmm6, xmm9
00007f7c123cff04  mulpd xmm6, xmm12
00007f7c123cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007f7c123cff0e  ptest xmm5, xmm5
00007f7c123cff13  jnz 0x00007F7C123D3572
00007f7c123cff19  movaps xmm12, xmm15
00007f7c123cff1d  addpd xmm12, xmm13
00007f7c123cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007f7c123cff28  ptest xmm9, xmm9
00007f7c123cff2e  jnz 0x00007F7C123D36B4
00007f7c123cff34  vmovaps xmm13, [rsp+0x30]
00007f7c123cff3a  movaps xmm15, xmm13
00007f7c123cff3e  addpd xmm15, xmm10
00007f7c123cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007f7c123cff49  ptest xmm9, xmm9
00007f7c123cff4f  jnz 0x00007F7C123D37F8
00007f7c123cff55  vmovaps xmm13, [rsp+0xD0]
00007f7c123cff5e  vmovaps xmm10, [rsp+0xD0]
00007f7c123cff67  por xmm13, xmm10
00007f7c123cff6c  movaps [r15+0x250], xmm13
00007f7c123cff74  vmovaps [rsp+0x20], xmm7
00007f7c123cff7a  vmovaps xmm13, [rsp+0x20]
00007f7c123cff80  por xmm7, xmm13
00007f7c123cff85  movaps [r15+0x2A0], xmm7
00007f7c123cff8d  vmovaps [rsp+0x20], xmm3
00007f7c123cff93  vmovaps xmm13, [rsp+0x20]
00007f7c123cff99  por xmm3, xmm13
00007f7c123cff9e  movaps [r15+0x1D0], xmm3
00007f7c123cffa6  lea rax, [r14+0x40]
00007f7c123cffaa  movups xmm13, [r13+rax*1]
00007f7c123cffb0  movaps [r15+0x2C0], xmm13
00007f7c123cffb8  vmovaps xmm10, [rsp+0x90]
00007f7c123cffc1  vpermilpd xmm10, xmm10, 0x00
00007f7c123cffc7  movaps xmm9, xmm8
00007f7c123cffcb  mulpd xmm9, xmm10
00007f7c123cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007f7c123cffd6  ptest xmm5, xmm5
00007f7c123cffdb  jnz 0x00007F7C123D3946
00007f7c123cffe1  movaps xmm10, xmm1
00007f7c123cffe5  addpd xmm10, xmm11
00007f7c123cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007f7c123cfff0  ptest xmm8, xmm8
00007f7c123cfff6  jnz 0x00007F7C123D3A8A
00007f7c123cfffc  movaps xmm1, xmm14
00007f7c123d0000  addpd xmm1, xmm6
00007f7c123d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007f7c123d0009  ptest xmm11, xmm11
00007f7c123d000f  jnz 0x00007F7C123D3BCD
00007f7c123d0015  vmovaps xmm14, [rsp+0x90]
00007f7c123d001e  vpermilpd xmm14, xmm14, 0x00
00007f7c123d0024  movaps xmm11, xmm13
00007f7c123d0028  mulpd xmm11, xmm14
00007f7c123d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007f7c123d0033  ptest xmm8, xmm8
00007f7c123d0039  jnz 0x00007F7C123D3D0E
00007f7c123d003f  vmovaps xmm14, [rsp+0x90]
00007f7c123d0048  vpermilpd xmm14, xmm14, 0x00
00007f7c123d004e  vmovaps xmm8, [rsp+0x10]
00007f7c123d0054  movaps xmm13, xmm8
00007f7c123d0058  mulpd xmm13, xmm14
00007f7c123d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007f7c123d0063  ptest xmm6, xmm6
00007f7c123d0068  jnz 0x00007F7C123D3E52
00007f7c123d006e  vmovaps xmm14, [rsp+0x60]
00007f7c123d0074  vpermilpd xmm14, xmm14, 0x00
00007f7c123d007a  movaps xmm8, xmm7
00007f7c123d007e  mulpd xmm8, xmm14
00007f7c123d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007f7c123d0089  ptest xmm6, xmm6
00007f7c123d008e  jnz 0x00007F7C123D3F96
00007f7c123d0094  movaps xmm14, xmm12
00007f7c123d0098  addpd xmm14, xmm9
00007f7c123d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007f7c123d00a3  ptest xmm7, xmm7
00007f7c123d00a8  jnz 0x00007F7C123D40D9
00007f7c123d00ae  vmovaps xmm12, [rsp+0x60]
00007f7c123d00b4  vpermilpd xmm12, xmm12, 0x00
00007f7c123d00ba  vmovaps xmm7, [rsp+0xF0]
00007f7c123d00c3  movaps xmm9, xmm7
00007f7c123d00c7  mulpd xmm9, xmm12
00007f7c123d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007f7c123d00d2  ptest xmm6, xmm6
00007f7c123d00d7  jnz 0x00007F7C123D421D
00007f7c123d00dd  movaps xmm12, xmm15
00007f7c123d00e1  addpd xmm12, xmm11
00007f7c123d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007f7c123d00ec  ptest xmm7, xmm7
00007f7c123d00f1  jnz 0x00007F7C123D4360
00007f7c123d00f7  vmovaps xmm15, [rsp+0x60]
00007f7c123d00fd  vpermilpd xmm15, xmm15, 0x00
00007f7c123d0103  vmovaps xmm7, [rsp+0x40]
00007f7c123d0109  movaps xmm11, xmm7
00007f7c123d010d  mulpd xmm11, xmm15
00007f7c123d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007f7c123d0118  ptest xmm6, xmm6
00007f7c123d011d  jnz 0x00007F7C123D44A4
00007f7c123d0123  movaps xmm15, xmm10
00007f7c123d0127  addpd xmm15, xmm13
00007f7c123d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007f7c123d0132  ptest xmm7, xmm7
00007f7c123d0137  jnz 0x00007F7C123D45E7
00007f7c123d013d  vmovaps xmm13, [rsp+0x60]
00007f7c123d0143  vpermilpd xmm13, xmm13, 0x00
00007f7c123d0149  vmovaps xmm7, [rsp+0x50]
00007f7c123d014f  movaps xmm10, xmm7
00007f7c123d0153  mulpd xmm10, xmm13
00007f7c123d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007f7c123d015e  ptest xmm6, xmm6
00007f7c123d0163  jnz 0x00007F7C123D472B
00007f7c123d0169  movaps xmm13, xmm1
00007f7c123d016d  addpd xmm13, xmm8
00007f7c123d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007f7c123d0178  ptest xmm7, xmm7
00007f7c123d017d  jnz 0x00007F7C123D486E
00007f7c123d0183  lea rax, [r14+0x70]
00007f7c123d0187  movups xmm1, [r13+rax*1]
00007f7c123d018d  movaps [r15+0x240], xmm1
00007f7c123d0195  movaps xmm8, xmm14
00007f7c123d0199  addpd xmm8, xmm9
00007f7c123d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007f7c123d01a4  ptest xmm7, xmm7
00007f7c123d01a9  jnz 0x00007F7C123D49BB
00007f7c123d01af  movaps [r15+0x170], xmm8
00007f7c123d01b7  vmovaps xmm14, [rsp+0x70]
00007f7c123d01bd  vpermilpd xmm14, xmm14, 0x00
00007f7c123d01c3  movaps xmm9, xmm1
00007f7c123d01c7  mulpd xmm9, xmm14
00007f7c123d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007f7c123d01d2  ptest xmm7, xmm7
00007f7c123d01d7  jnz 0x00007F7C123D4AFF
00007f7c123d01dd  vmovaps xmm1, [rsp+0x70]
00007f7c123d01e3  vpermilpd xmm1, xmm1, 0x00
00007f7c123d01e9  movaps xmm14, xmm4
00007f7c123d01ed  mulpd xmm14, xmm1
00007f7c123d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007f7c123d01f8  ptest xmm7, xmm7
00007f7c123d01fd  jnz 0x00007F7C123D4C42
00007f7c123d0203  movaps [r15+0x180], xmm14
00007f7c123d020b  movaps xmm1, xmm12
00007f7c123d020f  addpd xmm1, xmm11
00007f7c123d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007f7c123d0219  ptest xmm7, xmm7
00007f7c123d021e  jnz 0x00007F7C123D4D84
00007f7c123d0224  movaps [r15+0x210], xmm1
00007f7c123d022c  movups xmm12, [r13+r14*1]
00007f7c123d0232  lea rax, [r14+0x10]
00007f7c123d0236  movups xmm11, [r13+rax*1]
00007f7c123d023c  movaps [r15+0x230], xmm11
00007f7c123d0244  movaps xmm7, xmm15
00007f7c123d0248  addpd xmm7, xmm10
00007f7c123d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007f7c123d0252  ptest xmm6, xmm6
00007f7c123d0257  jnz 0x00007F7C123D4EDA
00007f7c123d025d  movaps [r15+0x130], xmm7
00007f7c123d0265  vmovaps xmm15, [rsp+0x70]
00007f7c123d026b  vpermilpd xmm15, xmm15, 0x00
00007f7c123d0271  movaps xmm10, xmm11
00007f7c123d0275  mulpd xmm10, xmm15
00007f7c123d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007f7c123d0280  ptest xmm6, xmm6
00007f7c123d0285  jnz 0x00007F7C123D501C
00007f7c123d028b  movaps [r15+0x220], xmm10
00007f7c123d0293  vmovaps xmm15, [rsp+0x70]
00007f7c123d0299  vpermilpd xmm15, xmm15, 0x00
00007f7c123d029f  movaps xmm11, xmm12
00007f7c123d02a3  mulpd xmm11, xmm15
00007f7c123d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007f7c123d02ae  ptest xmm6, xmm6
00007f7c123d02b3  jnz 0x00007F7C123D5160
00007f7c123d02b9  movaps xmm15, xmm13
00007f7c123d02bd  addpd xmm15, xmm9
00007f7c123d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007f7c123d02c8  ptest xmm12, xmm12
00007f7c123d02ce  jnz 0x00007F7C123D52A4
00007f7c123d02d4  movaps [r15+0x140], xmm15
00007f7c123d02dc  movaps xmm13, xmm8
00007f7c123d02e0  addpd xmm13, xmm14
00007f7c123d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007f7c123d02eb  ptest xmm12, xmm12
00007f7c123d02f1  jnz 0x00007F7C123D53E8
00007f7c123d02f7  movaps [r15+0x150], xmm13
00007f7c123d02ff  movaps xmm14, xmm1
00007f7c123d0303  addpd xmm14, xmm10
00007f7c123d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007f7c123d030e  ptest xmm12, xmm12
00007f7c123d0314  jnz 0x00007F7C123D552C
00007f7c123d031a  movaps [r15+0x160], xmm14
00007f7c123d0322  movaps xmm1, xmm7
00007f7c123d0325  addpd xmm1, xmm11
00007f7c123d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007f7c123d032f  ptest xmm12, xmm12
00007f7c123d0335  jnz 0x00007F7C123D566F
00007f7c123d033b  movaps [r15+0x120], xmm1
00007f7c123d0343  mov eax, 0x430920
00007f7c123d0348  movups [r13+rax*1], xmm15
00007f7c123d034e  mov eax, 0x430930
00007f7c123d0353  movups [r13+rax*1], xmm13
00007f7c123d0359  mov eax, 0x430940
00007f7c123d035e  movups [r13+rax*1], xmm14
00007f7c123d0364  mov eax, 0x430950
00007f7c123d0369  movups [r13+rax*1], xmm1
00007f7c123d036f  mov eax, [r15+0x108]
00007f7c123d0376  sahf
00007f7c123d0377  jnz 0x00007F7C123D03A9
00007f7c123d0379  cmp dword ptr [r15+0x318], 0x00
00007f7c123d0381  jz 0x00007F7C123DB900
00007f7c123d0387  nop [rax+rax*1], ax
00007f7c123d0390  nop [rax+rax*1], eax
00007f7c123d0398  mov eax, 0x410444
00007f7c123d039d  mov [r15+0x100], rax
00007f7c123d03a4  jmp 0x00007F7C121FE110
00007f7c123d03a9  cmp dword ptr [r15+0x318], 0x00
00007f7c123d03b1  jz 0x00007F7C123D57E0
00007f7c123d03b7  nop [rax+rax*1], ax
00007f7c123d03c0  nop [rax+rax*1], eax
00007f7c123d03c8  mov eax, 0x410278
00007f7c123d03cd  mov [r15+0x100], rax
00007f7c123d03d4  jmp 0x00007F7C121FE110
00007f7c123d03d9  int3
00007f7c123d03da  call 0x00007F7C122B52F0
00007f7c123d03df  jmp 0x00007F7C123CF016
00007f7c123d03e4  call 0x00007F7C122C4620
00007f7c123d03e9  jmp 0x00007F7C123CF023
00007f7c123d03ee  call 0x00007F7C122C33A0
00007f7c123d03f3  jmp 0x00007F7C123CF035
00007f7c123d03f8  call 0x00007F7C122C2120
00007f7c123d03fd  jmp 0x00007F7C123CF03F
00007f7c123d0402  call 0x00007F7C122C0860
00007f7c123d0407  jmp 0x00007F7C123CF067
00007f7c123d040c  call 0x00007F7C122BF5F0
00007f7c123d0411  jmp 0x00007F7C123CF073
00007f7c123d0416  call 0x00007F7C122C0860
00007f7c123d041b  jmp 0x00007F7C123CF0A5
00007f7c123d0420  call 0x00007F7C122BF5F0
00007f7c123d0425  jmp 0x00007F7C123CF0B1
00007f7c123d042a  call 0x00007F7C122C4740
00007f7c123d042f  jmp 0x00007F7C123CF0BE
00007f7c123d0434  call 0x00007F7C122B5400
00007f7c123d0439  jmp 0x00007F7C123CF0CB
00007f7c123d043e  call 0x00007F7C122B52F0
00007f7c123d0443  jmp 0x00007F7C123CF0D8
00007f7c123d0448  call 0x00007F7C122C4620
00007f7c123d044d  jmp 0x00007F7C123CF0E5
00007f7c123d0452  call 0x00007F7C122C0860
00007f7c123d0457  jmp 0x00007F7C123CF10D
00007f7c123d045c  call 0x00007F7C122BF5F0
00007f7c123d0461  jmp 0x00007F7C123CF119
00007f7c123d0466  call 0x00007F7C12209D70
00007f7c123d046b  jmp 0x00007F7C123CF11F
00007f7c123d0470  call 0x00007F7C122BE9C0
00007f7c123d0475  jmp 0x00007F7C123CF129
00007f7c123d047a  call 0x00007F7C122C0860
00007f7c123d047f  jmp 0x00007F7C123CF151
00007f7c123d0484  call 0x00007F7C122BF5F0
00007f7c123d0489  jmp 0x00007F7C123CF15D
00007f7c123d048e  call 0x00007F7C122BD750
00007f7c123d0493  jmp 0x00007F7C123CF16A
00007f7c123d0498  call 0x00007F7C122BC4E0
00007f7c123d049d  jmp 0x00007F7C123CF177
00007f7c123d04a2  call 0x00007F7C122C4740
00007f7c123d04a7  jmp 0x00007F7C123CF184
00007f7c123d04ac  call 0x00007F7C122B5400
00007f7c123d04b1  jmp 0x00007F7C123CF191
00007f7c123d04b6  call 0x00007F7C122B52F0
00007f7c123d04bb  jmp 0x00007F7C123CF19E
00007f7c123d04c0  call 0x00007F7C122C4620
00007f7c123d04c5  jmp 0x00007F7C123CF1AB
00007f7c123d04ca  call 0x00007F7C122C0860
00007f7c123d04cf  jmp 0x00007F7C123CF1BE
00007f7c123d04d4  call 0x00007F7C122BB270
00007f7c123d04d9  jmp 0x00007F7C123CF1CB
00007f7c123d04de  call 0x00007F7C122BA000
00007f7c123d04e3  jmp 0x00007F7C123CF1D8
00007f7c123d04e8  call 0x00007F7C122B8D90
00007f7c123d04ed  jmp 0x00007F7C123CF1E5
00007f7c123d04f2  call 0x00007F7C122B8A20
00007f7c123d04f7  jmp 0x00007F7C123CF1F2
00007f7c123d04fc  call 0x00007F7C122B5400
00007f7c123d0501  jmp 0x00007F7C123CF1FC
00007f7c123d0506  call 0x00007F7C122C2240
00007f7c123d050b  jmp 0x00007F7C123CF206
00007f7c123d0510  call 0x00007F7C122B52F0
00007f7c123d0515  jmp 0x00007F7C123CF210
00007f7c123d051a  call 0x00007F7C122C2120
00007f7c123d051f  jmp 0x00007F7C123CF21A
00007f7c123d0524  call 0x00007F7C122B77B0
00007f7c123d0529  jmp 0x00007F7C123CF224
00007f7c123d052e  call 0x00007F7C122B6550
00007f7c123d0533  jmp 0x00007F7C123CF22E
00007f7c123d0538  call 0x00007F7C122BFD50
00007f7c123d053d  jmp 0x00007F7C123CF240
00007f7c123d0542  call 0x00007F7C122B8EA0
00007f7c123d0547  jmp 0x00007F7C123CF24A
00007f7c123d054c  call 0x00007F7C122BFC30
00007f7c123d0551  jmp 0x00007F7C123CF257
00007f7c123d0556  call 0x00007F7C122B8D90
00007f7c123d055b  jmp 0x00007F7C123CF264
00007f7c123d0560  call 0x00007F7C122C2240
00007f7c123d0565  jmp 0x00007F7C123CF271
00007f7c123d056a  call 0x00007F7C122B5400
00007f7c123d056f  jmp 0x00007F7C123CF27E
00007f7c123d0574  call 0x00007F7C122B52F0
00007f7c123d0579  jmp 0x00007F7C123CF28B
00007f7c123d057e  call 0x00007F7C122C2120
00007f7c123d0583  jmp 0x00007F7C123CF298
00007f7c123d0588  call 0x00007F7C122B52F0
00007f7c123d058d  jmp 0x00007F7C123CF2AB
00007f7c123d0592  call 0x00007F7C122B52F0
00007f7c123d0597  jmp 0x00007F7C123CF2BE
00007f7c123d059c  call 0x00007F7C122B52F0
00007f7c123d05a1  jmp 0x00007F7C123CF2D1
00007f7c123d05a6  call 0x00007F7C122B52F0
00007f7c123d05ab  jmp 0x00007F7C123CF2E4
00007f7c123d05b0  call 0x00007F7C122C2240
00007f7c123d05b5  jmp 0x00007F7C123CF2F9
00007f7c123d05ba  call 0x00007F7C122C2240
00007f7c123d05bf  jmp 0x00007F7C123CF30C
00007f7c123d05c4  call 0x00007F7C122C2120
00007f7c123d05c9  jmp 0x00007F7C123CF319
00007f7c123d05ce  call 0x00007F7C122B52F0
00007f7c123d05d3  jmp 0x00007F7C123CF32C
00007f7c123d05d8  call 0x00007F7C122B52F0
00007f7c123d05dd  jmp 0x00007F7C123CF34F
00007f7c123d05e2  call 0x00007F7C122B52F0
00007f7c123d05e7  jmp 0x00007F7C123CF362
00007f7c123d05ec  call 0x00007F7C121FF540
00007f7c123d05f1  jmp 0x00007F7C123CF380
00007f7c123d05f6  call 0x00007F7C12208C20
00007f7c123d05fb  jmp 0x00007F7C123CF38A
00007f7c123d0600  call 0x00007F7C122D6600
00007f7c123d0605  jmp 0x00007F7C123CF396
00007f7c123d060a  call 0x00007F7C121FF540
00007f7c123d060f  jmp 0x00007F7C123CF3A6
00007f7c123d0614  call 0x00007F7C122C0370
00007f7c123d0619  jmp 0x00007F7C123CF3D4
00007f7c123d061e  call 0x00007F7C122BF100
00007f7c123d0623  jmp 0x00007F7C123CF3DD
00007f7c123d0628  call 0x00007F7C122C0370
00007f7c123d062d  jmp 0x00007F7C123CF43B
00007f7c123d0632  call 0x00007F7C122BF100
00007f7c123d0637  jmp 0x00007F7C123CF444
00007f7c123d063c  call 0x00007F7C122C0370
00007f7c123d0641  jmp 0x00007F7C123CF48B
00007f7c123d0646  call 0x00007F7C122BF100
00007f7c123d064b  jmp 0x00007F7C123CF494
00007f7c123d0650  call 0x00007F7C1220B720
00007f7c123d0655  jmp 0x00007F7C123CF4D7
00007f7c123d065a  call 0x00007F7C122B47C0
00007f7c123d065f  jmp 0x00007F7C123CF4EA
00007f7c123d0664  call 0x00007F7C12208B00
00007f7c123d0669  jmp 0x00007F7C123CF501
00007f7c123d066e  call 0x00007F7C121FF430
00007f7c123d0673  jmp 0x00007F7C123CF514
00007f7c123d0678  call 0x00007F7C121FF430
00007f7c123d067d  jmp 0x00007F7C123CF527
00007f7c123d0682  sub rsp, 0x08
00007f7c123d0686  push rax
00007f7c123d0687  push rcx
00007f7c123d0688  push rdx
00007f7c123d0689  push rdi
00007f7c123d068a  push rsi
00007f7c123d068b  push r8
00007f7c123d068d  push r9
00007f7c123d068f  push r10
00007f7c123d0691  push r11
00007f7c123d0693  sub rsp, 0xF0
00007f7c123d069a  vmovaps [rsp], xmm0
00007f7c123d069f  vmovaps [rsp+0x10], xmm2
00007f7c123d06a5  vmovaps [rsp+0x20], xmm3
00007f7c123d06ab  vmovaps [rsp+0x30], xmm4
00007f7c123d06b1  vmovaps [rsp+0x40], xmm5
00007f7c123d06b7  vmovaps [rsp+0x50], xmm6
00007f7c123d06bd  vmovaps [rsp+0x60], xmm7
00007f7c123d06c3  vmovaps [rsp+0x70], xmm8
00007f7c123d06c9  vmovaps [rsp+0x80], xmm9
00007f7c123d06d2  vmovaps [rsp+0x90], xmm10
00007f7c123d06db  vmovaps [rsp+0xA0], xmm11
00007f7c123d06e4  vmovaps [rsp+0xB0], xmm12
00007f7c123d06ed  vmovaps [rsp+0xC0], xmm13
00007f7c123d06f6  vmovaps [rsp+0xD0], xmm14
00007f7c123d06ff  vmovaps [rsp+0xE0], xmm15
00007f7c123d0708  sub rsp, 0x30
00007f7c123d070c  movaps [rsp], xmm1
00007f7c123d0710  movaps [rsp+0x10], xmm15
00007f7c123d0716  movaps [rsp+0x20], xmm14
00007f7c123d071c  lea rdi, [rsp]
00007f7c123d0720  mov esi, 0x00
00007f7c123d0725  mov rax, 0x5E723D793530
00007f7c123d072f  call rax
00007f7c123d0731  movaps xmm1, [rsp]
00007f7c123d0735  add rsp, 0x30
00007f7c123d0739  vmovaps xmm0, [rsp]
00007f7c123d073e  vmovaps xmm2, [rsp+0x10]
00007f7c123d0744  vmovaps xmm3, [rsp+0x20]
00007f7c123d074a  vmovaps xmm4, [rsp+0x30]
00007f7c123d0750  vmovaps xmm5, [rsp+0x40]
00007f7c123d0756  vmovaps xmm6, [rsp+0x50]
00007f7c123d075c  vmovaps xmm7, [rsp+0x60]
00007f7c123d0762  vmovaps xmm8, [rsp+0x70]
00007f7c123d0768  vmovaps xmm9, [rsp+0x80]
00007f7c123d0771  vmovaps xmm10, [rsp+0x90]
00007f7c123d077a  vmovaps xmm11, [rsp+0xA0]
00007f7c123d0783  vmovaps xmm12, [rsp+0xB0]
00007f7c123d078c  vmovaps xmm13, [rsp+0xC0]
00007f7c123d0795  vmovaps xmm14, [rsp+0xD0]
00007f7c123d079e  vmovaps xmm15, [rsp+0xE0]
00007f7c123d07a7  add rsp, 0xF0
00007f7c123d07ae  pop r11
00007f7c123d07b0  pop r10
00007f7c123d07b2  pop r9
00007f7c123d07b4  pop r8
00007f7c123d07b6  pop rsi
00007f7c123d07b7  pop rdi
00007f7c123d07b8  pop rdx
00007f7c123d07b9  pop rcx
00007f7c123d07ba  pop rax
00007f7c123d07bb  add rsp, 0x08
00007f7c123d07bf  jmp 0x00007F7C123CF581
00007f7c123d07c4  sub rsp, 0x08
00007f7c123d07c8  push rax
00007f7c123d07c9  push rcx
00007f7c123d07ca  push rdx
00007f7c123d07cb  push rdi
00007f7c123d07cc  push rsi
00007f7c123d07cd  push r8
00007f7c123d07cf  push r9
00007f7c123d07d1  push r10
00007f7c123d07d3  push r11
00007f7c123d07d5  sub rsp, 0xF0
00007f7c123d07dc  vmovaps [rsp], xmm0
00007f7c123d07e1  vmovaps [rsp+0x10], xmm1
00007f7c123d07e7  vmovaps [rsp+0x20], xmm2
00007f7c123d07ed  vmovaps [rsp+0x30], xmm3
00007f7c123d07f3  vmovaps [rsp+0x40], xmm4
00007f7c123d07f9  vmovaps [rsp+0x50], xmm5
00007f7c123d07ff  vmovaps [rsp+0x60], xmm6
00007f7c123d0805  vmovaps [rsp+0x70], xmm7
00007f7c123d080b  vmovaps [rsp+0x80], xmm8
00007f7c123d0814  vmovaps [rsp+0x90], xmm9
00007f7c123d081d  vmovaps [rsp+0xA0], xmm10
00007f7c123d0826  vmovaps [rsp+0xB0], xmm11
00007f7c123d082f  vmovaps [rsp+0xC0], xmm12
00007f7c123d0838  vmovaps [rsp+0xD0], xmm14
00007f7c123d0841  vmovaps [rsp+0xE0], xmm15
00007f7c123d084a  sub rsp, 0x30
00007f7c123d084e  movaps [rsp], xmm13
00007f7c123d0853  movaps [rsp+0x10], xmm1
00007f7c123d0858  movaps [rsp+0x20], xmm14
00007f7c123d085e  lea rdi, [rsp]
00007f7c123d0862  mov esi, 0x00
00007f7c123d0867  mov rax, 0x5E723D793530
00007f7c123d0871  call rax
00007f7c123d0873  movaps xmm13, [rsp]
00007f7c123d0878  add rsp, 0x30
00007f7c123d087c  vmovaps xmm0, [rsp]
00007f7c123d0881  vmovaps xmm1, [rsp+0x10]
00007f7c123d0887  vmovaps xmm2, [rsp+0x20]
00007f7c123d088d  vmovaps xmm3, [rsp+0x30]
00007f7c123d0893  vmovaps xmm4, [rsp+0x40]
00007f7c123d0899  vmovaps xmm5, [rsp+0x50]
00007f7c123d089f  vmovaps xmm6, [rsp+0x60]
00007f7c123d08a5  vmovaps xmm7, [rsp+0x70]
00007f7c123d08ab  vmovaps xmm8, [rsp+0x80]
00007f7c123d08b4  vmovaps xmm9, [rsp+0x90]
00007f7c123d08bd  vmovaps xmm10, [rsp+0xA0]
00007f7c123d08c6  vmovaps xmm11, [rsp+0xB0]
00007f7c123d08cf  vmovaps xmm12, [rsp+0xC0]
00007f7c123d08d8  vmovaps xmm14, [rsp+0xD0]
00007f7c123d08e1  vmovaps xmm15, [rsp+0xE0]
00007f7c123d08ea  add rsp, 0xF0
00007f7c123d08f1  pop r11
00007f7c123d08f3  pop r10
00007f7c123d08f5  pop r9
00007f7c123d08f7  pop r8
00007f7c123d08f9  pop rsi
00007f7c123d08fa  pop rdi
00007f7c123d08fb  pop rdx
00007f7c123d08fc  pop rcx
00007f7c123d08fd  pop rax
00007f7c123d08fe  add rsp, 0x08
00007f7c123d0902  jmp 0x00007F7C123CF5CF
00007f7c123d0907  sub rsp, 0x08
00007f7c123d090b  push rax
00007f7c123d090c  push rcx
00007f7c123d090d  push rdx
00007f7c123d090e  push rdi
00007f7c123d090f  push rsi
00007f7c123d0910  push r8
00007f7c123d0912  push r9
00007f7c123d0914  push r10
00007f7c123d0916  push r11
00007f7c123d0918  sub rsp, 0xF0
00007f7c123d091f  vmovaps [rsp], xmm0
00007f7c123d0924  vmovaps [rsp+0x10], xmm1
00007f7c123d092a  vmovaps [rsp+0x20], xmm2
00007f7c123d0930  vmovaps [rsp+0x30], xmm3
00007f7c123d0936  vmovaps [rsp+0x40], xmm4
00007f7c123d093c  vmovaps [rsp+0x50], xmm5
00007f7c123d0942  vmovaps [rsp+0x60], xmm6
00007f7c123d0948  vmovaps [rsp+0x70], xmm7
00007f7c123d094e  vmovaps [rsp+0x80], xmm8
00007f7c123d0957  vmovaps [rsp+0x90], xmm9
00007f7c123d0960  vmovaps [rsp+0xA0], xmm10
00007f7c123d0969  vmovaps [rsp+0xB0], xmm11
00007f7c123d0972  vmovaps [rsp+0xC0], xmm12
00007f7c123d097b  vmovaps [rsp+0xD0], xmm13
00007f7c123d0984  vmovaps [rsp+0xE0], xmm14
00007f7c123d098d  sub rsp, 0x30
00007f7c123d0991  movaps [rsp], xmm15
00007f7c123d0996  movaps [rsp+0x10], xmm14
00007f7c123d099c  movaps [rsp+0x20], xmm1
00007f7c123d09a1  lea rdi, [rsp]
00007f7c123d09a5  mov esi, 0x00
00007f7c123d09aa  mov rax, 0x5E723D793530
00007f7c123d09b4  call rax
00007f7c123d09b6  movaps xmm15, [rsp]
00007f7c123d09bb  add rsp, 0x30
00007f7c123d09bf  vmovaps xmm0, [rsp]
00007f7c123d09c4  vmovaps xmm1, [rsp+0x10]
00007f7c123d09ca  vmovaps xmm2, [rsp+0x20]
00007f7c123d09d0  vmovaps xmm3, [rsp+0x30]
00007f7c123d09d6  vmovaps xmm4, [rsp+0x40]
00007f7c123d09dc  vmovaps xmm5, [rsp+0x50]
00007f7c123d09e2  vmovaps xmm6, [rsp+0x60]
00007f7c123d09e8  vmovaps xmm7, [rsp+0x70]
00007f7c123d09ee  vmovaps xmm8, [rsp+0x80]
00007f7c123d09f7  vmovaps xmm9, [rsp+0x90]
00007f7c123d0a00  vmovaps xmm10, [rsp+0xA0]
00007f7c123d0a09  vmovaps xmm11, [rsp+0xB0]
00007f7c123d0a12  vmovaps xmm12, [rsp+0xC0]
00007f7c123d0a1b  vmovaps xmm13, [rsp+0xD0]
00007f7c123d0a24  vmovaps xmm14, [rsp+0xE0]
00007f7c123d0a2d  add rsp, 0xF0
00007f7c123d0a34  pop r11
00007f7c123d0a36  pop r10
00007f7c123d0a38  pop r9
00007f7c123d0a3a  pop r8
00007f7c123d0a3c  pop rsi
00007f7c123d0a3d  pop rdi
00007f7c123d0a3e  pop rdx
00007f7c123d0a3f  pop rcx
00007f7c123d0a40  pop rax
00007f7c123d0a41  add rsp, 0x08
00007f7c123d0a45  jmp 0x00007F7C123CF617
00007f7c123d0a4a  sub rsp, 0x08
00007f7c123d0a4e  push rax
00007f7c123d0a4f  push rcx
00007f7c123d0a50  push rdx
00007f7c123d0a51  push rdi
00007f7c123d0a52  push rsi
00007f7c123d0a53  push r8
00007f7c123d0a55  push r9
00007f7c123d0a57  push r10
00007f7c123d0a59  push r11
00007f7c123d0a5b  sub rsp, 0xF0
00007f7c123d0a62  vmovaps [rsp], xmm0
00007f7c123d0a67  vmovaps [rsp+0x10], xmm2
00007f7c123d0a6d  vmovaps [rsp+0x20], xmm3
00007f7c123d0a73  vmovaps [rsp+0x30], xmm4
00007f7c123d0a79  vmovaps [rsp+0x40], xmm5
00007f7c123d0a7f  vmovaps [rsp+0x50], xmm6
00007f7c123d0a85  vmovaps [rsp+0x60], xmm7
00007f7c123d0a8b  vmovaps [rsp+0x70], xmm8
00007f7c123d0a91  vmovaps [rsp+0x80], xmm9
00007f7c123d0a9a  vmovaps [rsp+0x90], xmm10
00007f7c123d0aa3  vmovaps [rsp+0xA0], xmm11
00007f7c123d0aac  vmovaps [rsp+0xB0], xmm12
00007f7c123d0ab5  vmovaps [rsp+0xC0], xmm13
00007f7c123d0abe  vmovaps [rsp+0xD0], xmm14
00007f7c123d0ac7  vmovaps [rsp+0xE0], xmm15
00007f7c123d0ad0  sub rsp, 0x30
00007f7c123d0ad4  movaps [rsp], xmm1
00007f7c123d0ad8  movaps [rsp+0x10], xmm14
00007f7c123d0ade  movaps [rsp+0x20], xmm10
00007f7c123d0ae4  lea rdi, [rsp]
00007f7c123d0ae8  mov esi, 0x00
00007f7c123d0aed  mov rax, 0x5E723D793530
00007f7c123d0af7  call rax
00007f7c123d0af9  movaps xmm1, [rsp]
00007f7c123d0afd  add rsp, 0x30
00007f7c123d0b01  vmovaps xmm0, [rsp]
00007f7c123d0b06  vmovaps xmm2, [rsp+0x10]
00007f7c123d0b0c  vmovaps xmm3, [rsp+0x20]
00007f7c123d0b12  vmovaps xmm4, [rsp+0x30]
00007f7c123d0b18  vmovaps xmm5, [rsp+0x40]
00007f7c123d0b1e  vmovaps xmm6, [rsp+0x50]
00007f7c123d0b24  vmovaps xmm7, [rsp+0x60]
00007f7c123d0b2a  vmovaps xmm8, [rsp+0x70]
00007f7c123d0b30  vmovaps xmm9, [rsp+0x80]
00007f7c123d0b39  vmovaps xmm10, [rsp+0x90]
00007f7c123d0b42  vmovaps xmm11, [rsp+0xA0]
00007f7c123d0b4b  vmovaps xmm12, [rsp+0xB0]
00007f7c123d0b54  vmovaps xmm13, [rsp+0xC0]
00007f7c123d0b5d  vmovaps xmm14, [rsp+0xD0]
00007f7c123d0b66  vmovaps xmm15, [rsp+0xE0]
00007f7c123d0b6f  add rsp, 0xF0
00007f7c123d0b76  pop r11
00007f7c123d0b78  pop r10
00007f7c123d0b7a  pop r9
00007f7c123d0b7c  pop r8
00007f7c123d0b7e  pop rsi
00007f7c123d0b7f  pop rdi
00007f7c123d0b80  pop rdx
00007f7c123d0b81  pop rcx
00007f7c123d0b82  pop rax
00007f7c123d0b83  add rsp, 0x08
00007f7c123d0b87  jmp 0x00007F7C123CF631
00007f7c123d0b8c  sub rsp, 0x08
00007f7c123d0b90  push rax
00007f7c123d0b91  push rcx
00007f7c123d0b92  push rdx
00007f7c123d0b93  push rdi
00007f7c123d0b94  push rsi
00007f7c123d0b95  push r8
00007f7c123d0b97  push r9
00007f7c123d0b99  push r10
00007f7c123d0b9b  push r11
00007f7c123d0b9d  sub rsp, 0xF0
00007f7c123d0ba4  vmovaps [rsp], xmm0
00007f7c123d0ba9  vmovaps [rsp+0x10], xmm1
00007f7c123d0baf  vmovaps [rsp+0x20], xmm2
00007f7c123d0bb5  vmovaps [rsp+0x30], xmm3
00007f7c123d0bbb  vmovaps [rsp+0x40], xmm4
00007f7c123d0bc1  vmovaps [rsp+0x50], xmm5
00007f7c123d0bc7  vmovaps [rsp+0x60], xmm6
00007f7c123d0bcd  vmovaps [rsp+0x70], xmm7
00007f7c123d0bd3  vmovaps [rsp+0x80], xmm8
00007f7c123d0bdc  vmovaps [rsp+0x90], xmm9
00007f7c123d0be5  vmovaps [rsp+0xA0], xmm10
00007f7c123d0bee  vmovaps [rsp+0xB0], xmm11
00007f7c123d0bf7  vmovaps [rsp+0xC0], xmm12
00007f7c123d0c00  vmovaps [rsp+0xD0], xmm14
00007f7c123d0c09  vmovaps [rsp+0xE0], xmm15
00007f7c123d0c12  sub rsp, 0x30
00007f7c123d0c16  movaps [rsp], xmm13
00007f7c123d0c1b  movaps [rsp+0x10], xmm14
00007f7c123d0c21  movaps [rsp+0x20], xmm2
00007f7c123d0c26  lea rdi, [rsp]
00007f7c123d0c2a  mov esi, 0x00
00007f7c123d0c2f  mov rax, 0x5E723D793530
00007f7c123d0c39  call rax
00007f7c123d0c3b  movaps xmm13, [rsp]
00007f7c123d0c40  add rsp, 0x30
00007f7c123d0c44  vmovaps xmm0, [rsp]
00007f7c123d0c49  vmovaps xmm1, [rsp+0x10]
00007f7c123d0c4f  vmovaps xmm2, [rsp+0x20]
00007f7c123d0c55  vmovaps xmm3, [rsp+0x30]
00007f7c123d0c5b  vmovaps xmm4, [rsp+0x40]
00007f7c123d0c61  vmovaps xmm5, [rsp+0x50]
00007f7c123d0c67  vmovaps xmm6, [rsp+0x60]
00007f7c123d0c6d  vmovaps xmm7, [rsp+0x70]
00007f7c123d0c73  vmovaps xmm8, [rsp+0x80]
00007f7c123d0c7c  vmovaps xmm9, [rsp+0x90]
00007f7c123d0c85  vmovaps xmm10, [rsp+0xA0]
00007f7c123d0c8e  vmovaps xmm11, [rsp+0xB0]
00007f7c123d0c97  vmovaps xmm12, [rsp+0xC0]
00007f7c123d0ca0  vmovaps xmm14, [rsp+0xD0]
00007f7c123d0ca9  vmovaps xmm15, [rsp+0xE0]
00007f7c123d0cb2  add rsp, 0xF0
00007f7c123d0cb9  pop r11
00007f7c123d0cbb  pop r10
00007f7c123d0cbd  pop r9
00007f7c123d0cbf  pop r8
00007f7c123d0cc1  pop rsi
00007f7c123d0cc2  pop rdi
00007f7c123d0cc3  pop rdx
00007f7c123d0cc4  pop rcx
00007f7c123d0cc5  pop rax
00007f7c123d0cc6  add rsp, 0x08
00007f7c123d0cca  jmp 0x00007F7C123CF64C
00007f7c123d0ccf  sub rsp, 0x08
00007f7c123d0cd3  push rax
00007f7c123d0cd4  push rcx
00007f7c123d0cd5  push rdx
00007f7c123d0cd6  push rdi
00007f7c123d0cd7  push rsi
00007f7c123d0cd8  push r8
00007f7c123d0cda  push r9
00007f7c123d0cdc  push r10
00007f7c123d0cde  push r11
00007f7c123d0ce0  sub rsp, 0xF0
00007f7c123d0ce7  vmovaps [rsp], xmm0
00007f7c123d0cec  vmovaps [rsp+0x10], xmm2
00007f7c123d0cf2  vmovaps [rsp+0x20], xmm3
00007f7c123d0cf8  vmovaps [rsp+0x30], xmm4
00007f7c123d0cfe  vmovaps [rsp+0x40], xmm5
00007f7c123d0d04  vmovaps [rsp+0x50], xmm6
00007f7c123d0d0a  vmovaps [rsp+0x60], xmm7
00007f7c123d0d10  vmovaps [rsp+0x70], xmm8
00007f7c123d0d16  vmovaps [rsp+0x80], xmm9
00007f7c123d0d1f  vmovaps [rsp+0x90], xmm10
00007f7c123d0d28  vmovaps [rsp+0xA0], xmm11
00007f7c123d0d31  vmovaps [rsp+0xB0], xmm12
00007f7c123d0d3a  vmovaps [rsp+0xC0], xmm13
00007f7c123d0d43  vmovaps [rsp+0xD0], xmm14
00007f7c123d0d4c  vmovaps [rsp+0xE0], xmm15
00007f7c123d0d55  sub rsp, 0x30
00007f7c123d0d59  movaps [rsp], xmm1
00007f7c123d0d5d  movaps [rsp+0x10], xmm10
00007f7c123d0d63  movaps [rsp+0x20], xmm2
00007f7c123d0d68  lea rdi, [rsp]
00007f7c123d0d6c  mov esi, 0x00
00007f7c123d0d71  mov rax, 0x5E723D793530
00007f7c123d0d7b  call rax
00007f7c123d0d7d  movaps xmm1, [rsp]
00007f7c123d0d81  add rsp, 0x30
00007f7c123d0d85  vmovaps xmm0, [rsp]
00007f7c123d0d8a  vmovaps xmm2, [rsp+0x10]
00007f7c123d0d90  vmovaps xmm3, [rsp+0x20]
00007f7c123d0d96  vmovaps xmm4, [rsp+0x30]
00007f7c123d0d9c  vmovaps xmm5, [rsp+0x40]
00007f7c123d0da2  vmovaps xmm6, [rsp+0x50]
00007f7c123d0da8  vmovaps xmm7, [rsp+0x60]
00007f7c123d0dae  vmovaps xmm8, [rsp+0x70]
00007f7c123d0db4  vmovaps xmm9, [rsp+0x80]
00007f7c123d0dbd  vmovaps xmm10, [rsp+0x90]
00007f7c123d0dc6  vmovaps xmm11, [rsp+0xA0]
00007f7c123d0dcf  vmovaps xmm12, [rsp+0xB0]
00007f7c123d0dd8  vmovaps xmm13, [rsp+0xC0]
00007f7c123d0de1  vmovaps xmm14, [rsp+0xD0]
00007f7c123d0dea  vmovaps xmm15, [rsp+0xE0]
00007f7c123d0df3  add rsp, 0xF0
00007f7c123d0dfa  pop r11
00007f7c123d0dfc  pop r10
00007f7c123d0dfe  pop r9
00007f7c123d0e00  pop r8
00007f7c123d0e02  pop rsi
00007f7c123d0e03  pop rdi
00007f7c123d0e04  pop rdx
00007f7c123d0e05  pop rcx
00007f7c123d0e06  pop rax
00007f7c123d0e07  add rsp, 0x08
00007f7c123d0e0b  jmp 0x00007F7C123CF6B4
00007f7c123d0e10  sub rsp, 0x08
00007f7c123d0e14  push rax
00007f7c123d0e15  push rcx
00007f7c123d0e16  push rdx
00007f7c123d0e17  push rdi
00007f7c123d0e18  push rsi
00007f7c123d0e19  push r8
00007f7c123d0e1b  push r9
00007f7c123d0e1d  push r10
00007f7c123d0e1f  push r11
00007f7c123d0e21  sub rsp, 0xF0
00007f7c123d0e28  vmovaps [rsp], xmm0
00007f7c123d0e2d  vmovaps [rsp+0x10], xmm1
00007f7c123d0e33  vmovaps [rsp+0x20], xmm2
00007f7c123d0e39  vmovaps [rsp+0x30], xmm3
00007f7c123d0e3f  vmovaps [rsp+0x40], xmm4
00007f7c123d0e45  vmovaps [rsp+0x50], xmm5
00007f7c123d0e4b  vmovaps [rsp+0x60], xmm6
00007f7c123d0e51  vmovaps [rsp+0x70], xmm7
00007f7c123d0e57  vmovaps [rsp+0x80], xmm8
00007f7c123d0e60  vmovaps [rsp+0x90], xmm9
00007f7c123d0e69  vmovaps [rsp+0xA0], xmm10
00007f7c123d0e72  vmovaps [rsp+0xB0], xmm11
00007f7c123d0e7b  vmovaps [rsp+0xC0], xmm12
00007f7c123d0e84  vmovaps [rsp+0xD0], xmm13
00007f7c123d0e8d  vmovaps [rsp+0xE0], xmm14
00007f7c123d0e96  sub rsp, 0x30
00007f7c123d0e9a  movaps [rsp], xmm15
00007f7c123d0e9f  movaps [rsp+0x10], xmm10
00007f7c123d0ea5  movaps [rsp+0x20], xmm2
00007f7c123d0eaa  lea rdi, [rsp]
00007f7c123d0eae  mov esi, 0x00
00007f7c123d0eb3  mov rax, 0x5E723D793530
00007f7c123d0ebd  call rax
00007f7c123d0ebf  movaps xmm15, [rsp]
00007f7c123d0ec4  add rsp, 0x30
00007f7c123d0ec8  vmovaps xmm0, [rsp]
00007f7c123d0ecd  vmovaps xmm1, [rsp+0x10]
00007f7c123d0ed3  vmovaps xmm2, [rsp+0x20]
00007f7c123d0ed9  vmovaps xmm3, [rsp+0x30]
00007f7c123d0edf  vmovaps xmm4, [rsp+0x40]
00007f7c123d0ee5  vmovaps xmm5, [rsp+0x50]
00007f7c123d0eeb  vmovaps xmm6, [rsp+0x60]
00007f7c123d0ef1  vmovaps xmm7, [rsp+0x70]
00007f7c123d0ef7  vmovaps xmm8, [rsp+0x80]
00007f7c123d0f00  vmovaps xmm9, [rsp+0x90]
00007f7c123d0f09  vmovaps xmm10, [rsp+0xA0]
00007f7c123d0f12  vmovaps xmm11, [rsp+0xB0]
00007f7c123d0f1b  vmovaps xmm12, [rsp+0xC0]
00007f7c123d0f24  vmovaps xmm13, [rsp+0xD0]
00007f7c123d0f2d  vmovaps xmm14, [rsp+0xE0]
00007f7c123d0f36  add rsp, 0xF0
00007f7c123d0f3d  pop r11
00007f7c123d0f3f  pop r10
00007f7c123d0f41  pop r9
00007f7c123d0f43  pop r8
00007f7c123d0f45  pop rsi
00007f7c123d0f46  pop rdi
00007f7c123d0f47  pop rdx
00007f7c123d0f48  pop rcx
00007f7c123d0f49  pop rax
00007f7c123d0f4a  add rsp, 0x08
00007f7c123d0f4e  jmp 0x00007F7C123CF706
00007f7c123d0f53  sub rsp, 0x08
00007f7c123d0f57  push rax
00007f7c123d0f58  push rcx
00007f7c123d0f59  push rdx
00007f7c123d0f5a  push rdi
00007f7c123d0f5b  push rsi
00007f7c123d0f5c  push r8
00007f7c123d0f5e  push r9
00007f7c123d0f60  push r10
00007f7c123d0f62  push r11
00007f7c123d0f64  sub rsp, 0xF0
00007f7c123d0f6b  vmovaps [rsp], xmm0
00007f7c123d0f70  vmovaps [rsp+0x10], xmm2
00007f7c123d0f76  vmovaps [rsp+0x20], xmm3
00007f7c123d0f7c  vmovaps [rsp+0x30], xmm4
00007f7c123d0f82  vmovaps [rsp+0x40], xmm5
00007f7c123d0f88  vmovaps [rsp+0x50], xmm6
00007f7c123d0f8e  vmovaps [rsp+0x60], xmm7
00007f7c123d0f94  vmovaps [rsp+0x70], xmm8
00007f7c123d0f9a  vmovaps [rsp+0x80], xmm9
00007f7c123d0fa3  vmovaps [rsp+0x90], xmm10
00007f7c123d0fac  vmovaps [rsp+0xA0], xmm11
00007f7c123d0fb5  vmovaps [rsp+0xB0], xmm12
00007f7c123d0fbe  vmovaps [rsp+0xC0], xmm13
00007f7c123d0fc7  vmovaps [rsp+0xD0], xmm14
00007f7c123d0fd0  vmovaps [rsp+0xE0], xmm15
00007f7c123d0fd9  sub rsp, 0x30
00007f7c123d0fdd  movaps [rsp], xmm1
00007f7c123d0fe1  movaps [rsp+0x10], xmm10
00007f7c123d0fe7  movaps [rsp+0x20], xmm12
00007f7c123d0fed  lea rdi, [rsp]
00007f7c123d0ff1  mov esi, 0x00
00007f7c123d0ff6  mov rax, 0x5E723D793530
00007f7c123d1000  call rax
00007f7c123d1002  movaps xmm1, [rsp]
00007f7c123d1006  add rsp, 0x30
00007f7c123d100a  vmovaps xmm0, [rsp]
00007f7c123d100f  vmovaps xmm2, [rsp+0x10]
00007f7c123d1015  vmovaps xmm3, [rsp+0x20]
00007f7c123d101b  vmovaps xmm4, [rsp+0x30]
00007f7c123d1021  vmovaps xmm5, [rsp+0x40]
00007f7c123d1027  vmovaps xmm6, [rsp+0x50]
00007f7c123d102d  vmovaps xmm7, [rsp+0x60]
00007f7c123d1033  vmovaps xmm8, [rsp+0x70]
00007f7c123d1039  vmovaps xmm9, [rsp+0x80]
00007f7c123d1042  vmovaps xmm10, [rsp+0x90]
00007f7c123d104b  vmovaps xmm11, [rsp+0xA0]
00007f7c123d1054  vmovaps xmm12, [rsp+0xB0]
00007f7c123d105d  vmovaps xmm13, [rsp+0xC0]
00007f7c123d1066  vmovaps xmm14, [rsp+0xD0]
00007f7c123d106f  vmovaps xmm15, [rsp+0xE0]
00007f7c123d1078  add rsp, 0xF0
00007f7c123d107f  pop r11
00007f7c123d1081  pop r10
00007f7c123d1083  pop r9
00007f7c123d1085  pop r8
00007f7c123d1087  pop rsi
00007f7c123d1088  pop rdi
00007f7c123d1089  pop rdx
00007f7c123d108a  pop rcx
00007f7c123d108b  pop rax
00007f7c123d108c  add rsp, 0x08
00007f7c123d1090  jmp 0x00007F7C123CF732
00007f7c123d1095  sub rsp, 0x08
00007f7c123d1099  push rax
00007f7c123d109a  push rcx
00007f7c123d109b  push rdx
00007f7c123d109c  push rdi
00007f7c123d109d  push rsi
00007f7c123d109e  push r8
00007f7c123d10a0  push r9
00007f7c123d10a2  push r10
00007f7c123d10a4  push r11
00007f7c123d10a6  sub rsp, 0xF0
00007f7c123d10ad  vmovaps [rsp], xmm0
00007f7c123d10b2  vmovaps [rsp+0x10], xmm1
00007f7c123d10b8  vmovaps [rsp+0x20], xmm2
00007f7c123d10be  vmovaps [rsp+0x30], xmm3
00007f7c123d10c4  vmovaps [rsp+0x40], xmm4
00007f7c123d10ca  vmovaps [rsp+0x50], xmm5
00007f7c123d10d0  vmovaps [rsp+0x60], xmm6
00007f7c123d10d6  vmovaps [rsp+0x70], xmm7
00007f7c123d10dc  vmovaps [rsp+0x80], xmm8
00007f7c123d10e5  vmovaps [rsp+0x90], xmm9
00007f7c123d10ee  vmovaps [rsp+0xA0], xmm10
00007f7c123d10f7  vmovaps [rsp+0xB0], xmm11
00007f7c123d1100  vmovaps [rsp+0xC0], xmm12
00007f7c123d1109  vmovaps [rsp+0xD0], xmm13
00007f7c123d1112  vmovaps [rsp+0xE0], xmm14
00007f7c123d111b  sub rsp, 0x30
00007f7c123d111f  movaps [rsp], xmm15
00007f7c123d1124  movaps [rsp+0x10], xmm10
00007f7c123d112a  movaps [rsp+0x20], xmm12
00007f7c123d1130  lea rdi, [rsp]
00007f7c123d1134  mov esi, 0x00
00007f7c123d1139  mov rax, 0x5E723D793530
00007f7c123d1143  call rax
00007f7c123d1145  movaps xmm15, [rsp]
00007f7c123d114a  add rsp, 0x30
00007f7c123d114e  vmovaps xmm0, [rsp]
00007f7c123d1153  vmovaps xmm1, [rsp+0x10]
00007f7c123d1159  vmovaps xmm2, [rsp+0x20]
00007f7c123d115f  vmovaps xmm3, [rsp+0x30]
00007f7c123d1165  vmovaps xmm4, [rsp+0x40]
00007f7c123d116b  vmovaps xmm5, [rsp+0x50]
00007f7c123d1171  vmovaps xmm6, [rsp+0x60]
00007f7c123d1177  vmovaps xmm7, [rsp+0x70]
00007f7c123d117d  vmovaps xmm8, [rsp+0x80]
00007f7c123d1186  vmovaps xmm9, [rsp+0x90]
00007f7c123d118f  vmovaps xmm10, [rsp+0xA0]
00007f7c123d1198  vmovaps xmm11, [rsp+0xB0]
00007f7c123d11a1  vmovaps xmm12, [rsp+0xC0]
00007f7c123d11aa  vmovaps xmm13, [rsp+0xD0]
00007f7c123d11b3  vmovaps xmm14, [rsp+0xE0]
00007f7c123d11bc  add rsp, 0xF0
00007f7c123d11c3  pop r11
00007f7c123d11c5  pop r10
00007f7c123d11c7  pop r9
00007f7c123d11c9  pop r8
00007f7c123d11cb  pop rsi
00007f7c123d11cc  pop rdi
00007f7c123d11cd  pop rdx
00007f7c123d11ce  pop rcx
00007f7c123d11cf  pop rax
00007f7c123d11d0  add rsp, 0x08
00007f7c123d11d4  jmp 0x00007F7C123CF75E
00007f7c123d11d9  call 0x00007F7C121FF430
00007f7c123d11de  jmp 0x00007F7C123CF7EE
00007f7c123d11e3  call 0x00007F7C121FF430
00007f7c123d11e8  jmp 0x00007F7C123CF801
00007f7c123d11ed  sub rsp, 0x08
00007f7c123d11f1  push rax
00007f7c123d11f2  push rcx
00007f7c123d11f3  push rdx
00007f7c123d11f4  push rdi
00007f7c123d11f5  push rsi
00007f7c123d11f6  push r8
00007f7c123d11f8  push r9
00007f7c123d11fa  push r10
00007f7c123d11fc  push r11
00007f7c123d11fe  sub rsp, 0xF0
00007f7c123d1205  vmovaps [rsp], xmm0
00007f7c123d120a  vmovaps [rsp+0x10], xmm2
00007f7c123d1210  vmovaps [rsp+0x20], xmm3
00007f7c123d1216  vmovaps [rsp+0x30], xmm4
00007f7c123d121c  vmovaps [rsp+0x40], xmm5
00007f7c123d1222  vmovaps [rsp+0x50], xmm6
00007f7c123d1228  vmovaps [rsp+0x60], xmm7
00007f7c123d122e  vmovaps [rsp+0x70], xmm8
00007f7c123d1234  vmovaps [rsp+0x80], xmm9
00007f7c123d123d  vmovaps [rsp+0x90], xmm10
00007f7c123d1246  vmovaps [rsp+0xA0], xmm11
00007f7c123d124f  vmovaps [rsp+0xB0], xmm12
00007f7c123d1258  vmovaps [rsp+0xC0], xmm13
00007f7c123d1261  vmovaps [rsp+0xD0], xmm14
00007f7c123d126a  vmovaps [rsp+0xE0], xmm15
00007f7c123d1273  sub rsp, 0x30
00007f7c123d1277  movaps [rsp], xmm1
00007f7c123d127b  movaps [rsp+0x10], xmm13
00007f7c123d1281  movaps [rsp+0x20], xmm2
00007f7c123d1286  lea rdi, [rsp]
00007f7c123d128a  mov esi, 0x00
00007f7c123d128f  mov rax, 0x5E723D793530
00007f7c123d1299  call rax
00007f7c123d129b  movaps xmm1, [rsp]
00007f7c123d129f  add rsp, 0x30
00007f7c123d12a3  vmovaps xmm0, [rsp]
00007f7c123d12a8  vmovaps xmm2, [rsp+0x10]
00007f7c123d12ae  vmovaps xmm3, [rsp+0x20]
00007f7c123d12b4  vmovaps xmm4, [rsp+0x30]
00007f7c123d12ba  vmovaps xmm5, [rsp+0x40]
00007f7c123d12c0  vmovaps xmm6, [rsp+0x50]
00007f7c123d12c6  vmovaps xmm7, [rsp+0x60]
00007f7c123d12cc  vmovaps xmm8, [rsp+0x70]
00007f7c123d12d2  vmovaps xmm9, [rsp+0x80]
00007f7c123d12db  vmovaps xmm10, [rsp+0x90]
00007f7c123d12e4  vmovaps xmm11, [rsp+0xA0]
00007f7c123d12ed  vmovaps xmm12, [rsp+0xB0]
00007f7c123d12f6  vmovaps xmm13, [rsp+0xC0]
00007f7c123d12ff  vmovaps xmm14, [rsp+0xD0]
00007f7c123d1308  vmovaps xmm15, [rsp+0xE0]
00007f7c123d1311  add rsp, 0xF0
00007f7c123d1318  pop r11
00007f7c123d131a  pop r10
00007f7c123d131c  pop r9
00007f7c123d131e  pop r8
00007f7c123d1320  pop rsi
00007f7c123d1321  pop rdi
00007f7c123d1322  pop rdx
00007f7c123d1323  pop rcx
00007f7c123d1324  pop rax
00007f7c123d1325  add rsp, 0x08
00007f7c123d1329  jmp 0x00007F7C123CF82C
00007f7c123d132e  call 0x00007F7C1220E760
00007f7c123d1333  jmp 0x00007F7C123CF839
00007f7c123d1338  sub rsp, 0x08
00007f7c123d133c  push rax
00007f7c123d133d  push rcx
00007f7c123d133e  push rdx
00007f7c123d133f  push rdi
00007f7c123d1340  push rsi
00007f7c123d1341  push r8
00007f7c123d1343  push r9
00007f7c123d1345  push r10
00007f7c123d1347  push r11
00007f7c123d1349  sub rsp, 0xF0
00007f7c123d1350  vmovaps [rsp], xmm0
00007f7c123d1355  vmovaps [rsp+0x10], xmm1
00007f7c123d135b  vmovaps [rsp+0x20], xmm2
00007f7c123d1361  vmovaps [rsp+0x30], xmm3
00007f7c123d1367  vmovaps [rsp+0x40], xmm4
00007f7c123d136d  vmovaps [rsp+0x50], xmm5
00007f7c123d1373  vmovaps [rsp+0x60], xmm6
00007f7c123d1379  vmovaps [rsp+0x70], xmm7
00007f7c123d137f  vmovaps [rsp+0x80], xmm8
00007f7c123d1388  vmovaps [rsp+0x90], xmm9
00007f7c123d1391  vmovaps [rsp+0xA0], xmm10
00007f7c123d139a  vmovaps [rsp+0xB0], xmm11
00007f7c123d13a3  vmovaps [rsp+0xC0], xmm12
00007f7c123d13ac  vmovaps [rsp+0xD0], xmm14
00007f7c123d13b5  vmovaps [rsp+0xE0], xmm15
00007f7c123d13be  sub rsp, 0x30
00007f7c123d13c2  movaps [rsp], xmm13
00007f7c123d13c7  movaps [rsp+0x10], xmm2
00007f7c123d13cc  movaps [rsp+0x20], xmm1
00007f7c123d13d1  lea rdi, [rsp]
00007f7c123d13d5  mov esi, 0x00
00007f7c123d13da  mov rax, 0x5E723D793530
00007f7c123d13e4  call rax
00007f7c123d13e6  movaps xmm13, [rsp]
00007f7c123d13eb  add rsp, 0x30
00007f7c123d13ef  vmovaps xmm0, [rsp]
00007f7c123d13f4  vmovaps xmm1, [rsp+0x10]
00007f7c123d13fa  vmovaps xmm2, [rsp+0x20]
00007f7c123d1400  vmovaps xmm3, [rsp+0x30]
00007f7c123d1406  vmovaps xmm4, [rsp+0x40]
00007f7c123d140c  vmovaps xmm5, [rsp+0x50]
00007f7c123d1412  vmovaps xmm6, [rsp+0x60]
00007f7c123d1418  vmovaps xmm7, [rsp+0x70]
00007f7c123d141e  vmovaps xmm8, [rsp+0x80]
00007f7c123d1427  vmovaps xmm9, [rsp+0x90]
00007f7c123d1430  vmovaps xmm10, [rsp+0xA0]
00007f7c123d1439  vmovaps xmm11, [rsp+0xB0]
00007f7c123d1442  vmovaps xmm12, [rsp+0xC0]
00007f7c123d144b  vmovaps xmm14, [rsp+0xD0]
00007f7c123d1454  vmovaps xmm15, [rsp+0xE0]
00007f7c123d145d  add rsp, 0xF0
00007f7c123d1464  pop r11
00007f7c123d1466  pop r10
00007f7c123d1468  pop r9
00007f7c123d146a  pop r8
00007f7c123d146c  pop rsi
00007f7c123d146d  pop rdi
00007f7c123d146e  pop rdx
00007f7c123d146f  pop rcx
00007f7c123d1470  pop rax
00007f7c123d1471  add rsp, 0x08
00007f7c123d1475  jmp 0x00007F7C123CF878
00007f7c123d147a  sub rsp, 0x08
00007f7c123d147e  push rax
00007f7c123d147f  push rcx
00007f7c123d1480  push rdx
00007f7c123d1481  push rdi
00007f7c123d1482  push rsi
00007f7c123d1483  push r8
00007f7c123d1485  push r9
00007f7c123d1487  push r10
00007f7c123d1489  push r11
00007f7c123d148b  sub rsp, 0xF0
00007f7c123d1492  vmovaps [rsp], xmm0
00007f7c123d1497  vmovaps [rsp+0x10], xmm2
00007f7c123d149d  vmovaps [rsp+0x20], xmm3
00007f7c123d14a3  vmovaps [rsp+0x30], xmm4
00007f7c123d14a9  vmovaps [rsp+0x40], xmm5
00007f7c123d14af  vmovaps [rsp+0x50], xmm6
00007f7c123d14b5  vmovaps [rsp+0x60], xmm7
00007f7c123d14bb  vmovaps [rsp+0x70], xmm8
00007f7c123d14c1  vmovaps [rsp+0x80], xmm9
00007f7c123d14ca  vmovaps [rsp+0x90], xmm10
00007f7c123d14d3  vmovaps [rsp+0xA0], xmm11
00007f7c123d14dc  vmovaps [rsp+0xB0], xmm12
00007f7c123d14e5  vmovaps [rsp+0xC0], xmm13
00007f7c123d14ee  vmovaps [rsp+0xD0], xmm14
00007f7c123d14f7  vmovaps [rsp+0xE0], xmm15
00007f7c123d1500  sub rsp, 0x30
00007f7c123d1504  movaps [rsp], xmm1
00007f7c123d1508  movaps [rsp+0x10], xmm15
00007f7c123d150e  movaps [rsp+0x20], xmm2
00007f7c123d1513  lea rdi, [rsp]
00007f7c123d1517  mov esi, 0x00
00007f7c123d151c  mov rax, 0x5E723D793530
00007f7c123d1526  call rax
00007f7c123d1528  movaps xmm1, [rsp]
00007f7c123d152c  add rsp, 0x30
00007f7c123d1530  vmovaps xmm0, [rsp]
00007f7c123d1535  vmovaps xmm2, [rsp+0x10]
00007f7c123d153b  vmovaps xmm3, [rsp+0x20]
00007f7c123d1541  vmovaps xmm4, [rsp+0x30]
00007f7c123d1547  vmovaps xmm5, [rsp+0x40]
00007f7c123d154d  vmovaps xmm6, [rsp+0x50]
00007f7c123d1553  vmovaps xmm7, [rsp+0x60]
00007f7c123d1559  vmovaps xmm8, [rsp+0x70]
00007f7c123d155f  vmovaps xmm9, [rsp+0x80]
00007f7c123d1568  vmovaps xmm10, [rsp+0x90]
00007f7c123d1571  vmovaps xmm11, [rsp+0xA0]
00007f7c123d157a  vmovaps xmm12, [rsp+0xB0]
00007f7c123d1583  vmovaps xmm13, [rsp+0xC0]
00007f7c123d158c  vmovaps xmm14, [rsp+0xD0]
00007f7c123d1595  vmovaps xmm15, [rsp+0xE0]
00007f7c123d159e  add rsp, 0xF0
00007f7c123d15a5  pop r11
00007f7c123d15a7  pop r10
00007f7c123d15a9  pop r9
00007f7c123d15ab  pop r8
00007f7c123d15ad  pop rsi
00007f7c123d15ae  pop rdi
00007f7c123d15af  pop rdx
00007f7c123d15b0  pop rcx
00007f7c123d15b1  pop rax
00007f7c123d15b2  add rsp, 0x08
00007f7c123d15b6  jmp 0x00007F7C123CF8AC
00007f7c123d15bb  sub rsp, 0x08
00007f7c123d15bf  push rax
00007f7c123d15c0  push rcx
00007f7c123d15c1  push rdx
00007f7c123d15c2  push rdi
00007f7c123d15c3  push rsi
00007f7c123d15c4  push r8
00007f7c123d15c6  push r9
00007f7c123d15c8  push r10
00007f7c123d15ca  push r11
00007f7c123d15cc  sub rsp, 0xF0
00007f7c123d15d3  vmovaps [rsp], xmm0
00007f7c123d15d8  vmovaps [rsp+0x10], xmm1
00007f7c123d15de  vmovaps [rsp+0x20], xmm2
00007f7c123d15e4  vmovaps [rsp+0x30], xmm3
00007f7c123d15ea  vmovaps [rsp+0x40], xmm4
00007f7c123d15f0  vmovaps [rsp+0x50], xmm5
00007f7c123d15f6  vmovaps [rsp+0x60], xmm6
00007f7c123d15fc  vmovaps [rsp+0x70], xmm7
00007f7c123d1602  vmovaps [rsp+0x80], xmm8
00007f7c123d160b  vmovaps [rsp+0x90], xmm9
00007f7c123d1614  vmovaps [rsp+0xA0], xmm10
00007f7c123d161d  vmovaps [rsp+0xB0], xmm11
00007f7c123d1626  vmovaps [rsp+0xC0], xmm12
00007f7c123d162f  vmovaps [rsp+0xD0], xmm13
00007f7c123d1638  vmovaps [rsp+0xE0], xmm15
00007f7c123d1641  sub rsp, 0x30
00007f7c123d1645  movaps [rsp], xmm14
00007f7c123d164a  movaps [rsp+0x10], xmm2
00007f7c123d164f  movaps [rsp+0x20], xmm15
00007f7c123d1655  lea rdi, [rsp]
00007f7c123d1659  mov esi, 0x00
00007f7c123d165e  mov rax, 0x5E723D793530
00007f7c123d1668  call rax
00007f7c123d166a  movaps xmm14, [rsp]
00007f7c123d166f  add rsp, 0x30
00007f7c123d1673  vmovaps xmm0, [rsp]
00007f7c123d1678  vmovaps xmm1, [rsp+0x10]
00007f7c123d167e  vmovaps xmm2, [rsp+0x20]
00007f7c123d1684  vmovaps xmm3, [rsp+0x30]
00007f7c123d168a  vmovaps xmm4, [rsp+0x40]
00007f7c123d1690  vmovaps xmm5, [rsp+0x50]
00007f7c123d1696  vmovaps xmm6, [rsp+0x60]
00007f7c123d169c  vmovaps xmm7, [rsp+0x70]
00007f7c123d16a2  vmovaps xmm8, [rsp+0x80]
00007f7c123d16ab  vmovaps xmm9, [rsp+0x90]
00007f7c123d16b4  vmovaps xmm10, [rsp+0xA0]
00007f7c123d16bd  vmovaps xmm11, [rsp+0xB0]
00007f7c123d16c6  vmovaps xmm12, [rsp+0xC0]
00007f7c123d16cf  vmovaps xmm13, [rsp+0xD0]
00007f7c123d16d8  vmovaps xmm15, [rsp+0xE0]
00007f7c123d16e1  add rsp, 0xF0
00007f7c123d16e8  pop r11
00007f7c123d16ea  pop r10
00007f7c123d16ec  pop r9
00007f7c123d16ee  pop r8
00007f7c123d16f0  pop rsi
00007f7c123d16f1  pop rdi
00007f7c123d16f2  pop rdx
00007f7c123d16f3  pop rcx
00007f7c123d16f4  pop rax
00007f7c123d16f5  add rsp, 0x08
00007f7c123d16f9  jmp 0x00007F7C123CF8E7
00007f7c123d16fe  sub rsp, 0x08
00007f7c123d1702  push rax
00007f7c123d1703  push rcx
00007f7c123d1704  push rdx
00007f7c123d1705  push rdi
00007f7c123d1706  push rsi
00007f7c123d1707  push r8
00007f7c123d1709  push r9
00007f7c123d170b  push r10
00007f7c123d170d  push r11
00007f7c123d170f  sub rsp, 0xF0
00007f7c123d1716  vmovaps [rsp], xmm0
00007f7c123d171b  vmovaps [rsp+0x10], xmm1
00007f7c123d1721  vmovaps [rsp+0x20], xmm2
00007f7c123d1727  vmovaps [rsp+0x30], xmm3
00007f7c123d172d  vmovaps [rsp+0x40], xmm4
00007f7c123d1733  vmovaps [rsp+0x50], xmm5
00007f7c123d1739  vmovaps [rsp+0x60], xmm6
00007f7c123d173f  vmovaps [rsp+0x70], xmm7
00007f7c123d1745  vmovaps [rsp+0x80], xmm8
00007f7c123d174e  vmovaps [rsp+0x90], xmm9
00007f7c123d1757  vmovaps [rsp+0xA0], xmm10
00007f7c123d1760  vmovaps [rsp+0xB0], xmm11
00007f7c123d1769  vmovaps [rsp+0xC0], xmm12
00007f7c123d1772  vmovaps [rsp+0xD0], xmm13
00007f7c123d177b  vmovaps [rsp+0xE0], xmm14
00007f7c123d1784  sub rsp, 0x30
00007f7c123d1788  movaps [rsp], xmm15
00007f7c123d178d  movaps [rsp+0x10], xmm2
00007f7c123d1792  movaps [rsp+0x20], xmm1
00007f7c123d1797  lea rdi, [rsp]
00007f7c123d179b  mov esi, 0x00
00007f7c123d17a0  mov rax, 0x5E723D793530
00007f7c123d17aa  call rax
00007f7c123d17ac  movaps xmm15, [rsp]
00007f7c123d17b1  add rsp, 0x30
00007f7c123d17b5  vmovaps xmm0, [rsp]
00007f7c123d17ba  vmovaps xmm1, [rsp+0x10]
00007f7c123d17c0  vmovaps xmm2, [rsp+0x20]
00007f7c123d17c6  vmovaps xmm3, [rsp+0x30]
00007f7c123d17cc  vmovaps xmm4, [rsp+0x40]
00007f7c123d17d2  vmovaps xmm5, [rsp+0x50]
00007f7c123d17d8  vmovaps xmm6, [rsp+0x60]
00007f7c123d17de  vmovaps xmm7, [rsp+0x70]
00007f7c123d17e4  vmovaps xmm8, [rsp+0x80]
00007f7c123d17ed  vmovaps xmm9, [rsp+0x90]
00007f7c123d17f6  vmovaps xmm10, [rsp+0xA0]
00007f7c123d17ff  vmovaps xmm11, [rsp+0xB0]
00007f7c123d1808  vmovaps xmm12, [rsp+0xC0]
00007f7c123d1811  vmovaps xmm13, [rsp+0xD0]
00007f7c123d181a  vmovaps xmm14, [rsp+0xE0]
00007f7c123d1823  add rsp, 0xF0
00007f7c123d182a  pop r11
00007f7c123d182c  pop r10
00007f7c123d182e  pop r9
00007f7c123d1830  pop r8
00007f7c123d1832  pop rsi
00007f7c123d1833  pop rdi
00007f7c123d1834  pop rdx
00007f7c123d1835  pop rcx
00007f7c123d1836  pop rax
00007f7c123d1837  add rsp, 0x08
00007f7c123d183b  jmp 0x00007F7C123CF923
00007f7c123d1840  call 0x00007F7C121FF430
00007f7c123d1845  jmp 0x00007F7C123CF930
00007f7c123d184a  sub rsp, 0x08
00007f7c123d184e  push rax
00007f7c123d184f  push rcx
00007f7c123d1850  push rdx
00007f7c123d1851  push rdi
00007f7c123d1852  push rsi
00007f7c123d1853  push r8
00007f7c123d1855  push r9
00007f7c123d1857  push r10
00007f7c123d1859  push r11
00007f7c123d185b  sub rsp, 0xF0
00007f7c123d1862  vmovaps [rsp], xmm0
00007f7c123d1867  vmovaps [rsp+0x10], xmm1
00007f7c123d186d  vmovaps [rsp+0x20], xmm3
00007f7c123d1873  vmovaps [rsp+0x30], xmm4
00007f7c123d1879  vmovaps [rsp+0x40], xmm5
00007f7c123d187f  vmovaps [rsp+0x50], xmm6
00007f7c123d1885  vmovaps [rsp+0x60], xmm7
00007f7c123d188b  vmovaps [rsp+0x70], xmm8
00007f7c123d1891  vmovaps [rsp+0x80], xmm9
00007f7c123d189a  vmovaps [rsp+0x90], xmm10
00007f7c123d18a3  vmovaps [rsp+0xA0], xmm11
00007f7c123d18ac  vmovaps [rsp+0xB0], xmm12
00007f7c123d18b5  vmovaps [rsp+0xC0], xmm13
00007f7c123d18be  vmovaps [rsp+0xD0], xmm14
00007f7c123d18c7  vmovaps [rsp+0xE0], xmm15
00007f7c123d18d0  sub rsp, 0x30
00007f7c123d18d4  movaps [rsp], xmm2
00007f7c123d18d8  movaps [rsp+0x10], xmm1
00007f7c123d18dd  movaps [rsp+0x20], xmm14
00007f7c123d18e3  lea rdi, [rsp]
00007f7c123d18e7  mov esi, 0x00
00007f7c123d18ec  mov rax, 0x5E723D793530
00007f7c123d18f6  call rax
00007f7c123d18f8  movaps xmm2, [rsp]
00007f7c123d18fc  add rsp, 0x30
00007f7c123d1900  vmovaps xmm0, [rsp]
00007f7c123d1905  vmovaps xmm1, [rsp+0x10]
00007f7c123d190b  vmovaps xmm3, [rsp+0x20]
00007f7c123d1911  vmovaps xmm4, [rsp+0x30]
00007f7c123d1917  vmovaps xmm5, [rsp+0x40]
00007f7c123d191d  vmovaps xmm6, [rsp+0x50]
00007f7c123d1923  vmovaps xmm7, [rsp+0x60]
00007f7c123d1929  vmovaps xmm8, [rsp+0x70]
00007f7c123d192f  vmovaps xmm9, [rsp+0x80]
00007f7c123d1938  vmovaps xmm10, [rsp+0x90]
00007f7c123d1941  vmovaps xmm11, [rsp+0xA0]
00007f7c123d194a  vmovaps xmm12, [rsp+0xB0]
00007f7c123d1953  vmovaps xmm13, [rsp+0xC0]
00007f7c123d195c  vmovaps xmm14, [rsp+0xD0]
00007f7c123d1965  vmovaps xmm15, [rsp+0xE0]
00007f7c123d196e  add rsp, 0xF0
00007f7c123d1975  pop r11
00007f7c123d1977  pop r10
00007f7c123d1979  pop r9
00007f7c123d197b  pop r8
00007f7c123d197d  pop rsi
00007f7c123d197e  pop rdi
00007f7c123d197f  pop rdx
00007f7c123d1980  pop rcx
00007f7c123d1981  pop rax
00007f7c123d1982  add rsp, 0x08
00007f7c123d1986  jmp 0x00007F7C123CF96D
00007f7c123d198b  sub rsp, 0x08
00007f7c123d198f  push rax
00007f7c123d1990  push rcx
00007f7c123d1991  push rdx
00007f7c123d1992  push rdi
00007f7c123d1993  push rsi
00007f7c123d1994  push r8
00007f7c123d1996  push r9
00007f7c123d1998  push r10
00007f7c123d199a  push r11
00007f7c123d199c  sub rsp, 0xF0
00007f7c123d19a3  vmovaps [rsp], xmm0
00007f7c123d19a8  vmovaps [rsp+0x10], xmm1
00007f7c123d19ae  vmovaps [rsp+0x20], xmm2
00007f7c123d19b4  vmovaps [rsp+0x30], xmm3
00007f7c123d19ba  vmovaps [rsp+0x40], xmm4
00007f7c123d19c0  vmovaps [rsp+0x50], xmm5
00007f7c123d19c6  vmovaps [rsp+0x60], xmm6
00007f7c123d19cc  vmovaps [rsp+0x70], xmm7
00007f7c123d19d2  vmovaps [rsp+0x80], xmm8
00007f7c123d19db  vmovaps [rsp+0x90], xmm9
00007f7c123d19e4  vmovaps [rsp+0xA0], xmm10
00007f7c123d19ed  vmovaps [rsp+0xB0], xmm11
00007f7c123d19f6  vmovaps [rsp+0xC0], xmm12
00007f7c123d19ff  vmovaps [rsp+0xD0], xmm13
00007f7c123d1a08  vmovaps [rsp+0xE0], xmm14
00007f7c123d1a11  sub rsp, 0x30
00007f7c123d1a15  movaps [rsp], xmm15
00007f7c123d1a1a  movaps [rsp+0x10], xmm14
00007f7c123d1a20  movaps [rsp+0x20], xmm1
00007f7c123d1a25  lea rdi, [rsp]
00007f7c123d1a29  mov esi, 0x00
00007f7c123d1a2e  mov rax, 0x5E723D793530
00007f7c123d1a38  call rax
00007f7c123d1a3a  movaps xmm15, [rsp]
00007f7c123d1a3f  add rsp, 0x30
00007f7c123d1a43  vmovaps xmm0, [rsp]
00007f7c123d1a48  vmovaps xmm1, [rsp+0x10]
00007f7c123d1a4e  vmovaps xmm2, [rsp+0x20]
00007f7c123d1a54  vmovaps xmm3, [rsp+0x30]
00007f7c123d1a5a  vmovaps xmm4, [rsp+0x40]
00007f7c123d1a60  vmovaps xmm5, [rsp+0x50]
00007f7c123d1a66  vmovaps xmm6, [rsp+0x60]
00007f7c123d1a6c  vmovaps xmm7, [rsp+0x70]
00007f7c123d1a72  vmovaps xmm8, [rsp+0x80]
00007f7c123d1a7b  vmovaps xmm9, [rsp+0x90]
00007f7c123d1a84  vmovaps xmm10, [rsp+0xA0]
00007f7c123d1a8d  vmovaps xmm11, [rsp+0xB0]
00007f7c123d1a96  vmovaps xmm12, [rsp+0xC0]
00007f7c123d1a9f  vmovaps xmm13, [rsp+0xD0]
00007f7c123d1aa8  vmovaps xmm14, [rsp+0xE0]
00007f7c123d1ab1  add rsp, 0xF0
00007f7c123d1ab8  pop r11
00007f7c123d1aba  pop r10
00007f7c123d1abc  pop r9
00007f7c123d1abe  pop r8
00007f7c123d1ac0  pop rsi
00007f7c123d1ac1  pop rdi
00007f7c123d1ac2  pop rdx
00007f7c123d1ac3  pop rcx
00007f7c123d1ac4  pop rax
00007f7c123d1ac5  add rsp, 0x08
00007f7c123d1ac9  jmp 0x00007F7C123CF9E7
00007f7c123d1ace  call 0x00007F7C121FF430
00007f7c123d1ad3  jmp 0x00007F7C123CF9F4
00007f7c123d1ad8  sub rsp, 0x08
00007f7c123d1adc  push rax
00007f7c123d1add  push rcx
00007f7c123d1ade  push rdx
00007f7c123d1adf  push rdi
00007f7c123d1ae0  push rsi
00007f7c123d1ae1  push r8
00007f7c123d1ae3  push r9
00007f7c123d1ae5  push r10
00007f7c123d1ae7  push r11
00007f7c123d1ae9  sub rsp, 0xF0
00007f7c123d1af0  vmovaps [rsp], xmm0
00007f7c123d1af5  vmovaps [rsp+0x10], xmm1
00007f7c123d1afb  vmovaps [rsp+0x20], xmm2
00007f7c123d1b01  vmovaps [rsp+0x30], xmm3
00007f7c123d1b07  vmovaps [rsp+0x40], xmm4
00007f7c123d1b0d  vmovaps [rsp+0x50], xmm5
00007f7c123d1b13  vmovaps [rsp+0x60], xmm6
00007f7c123d1b19  vmovaps [rsp+0x70], xmm7
00007f7c123d1b1f  vmovaps [rsp+0x80], xmm8
00007f7c123d1b28  vmovaps [rsp+0x90], xmm9
00007f7c123d1b31  vmovaps [rsp+0xA0], xmm10
00007f7c123d1b3a  vmovaps [rsp+0xB0], xmm11
00007f7c123d1b43  vmovaps [rsp+0xC0], xmm12
00007f7c123d1b4c  vmovaps [rsp+0xD0], xmm13
00007f7c123d1b55  vmovaps [rsp+0xE0], xmm15
00007f7c123d1b5e  sub rsp, 0x30
00007f7c123d1b62  movaps [rsp], xmm14
00007f7c123d1b67  movaps [rsp+0x10], xmm13
00007f7c123d1b6d  movaps [rsp+0x20], xmm1
00007f7c123d1b72  lea rdi, [rsp]
00007f7c123d1b76  mov esi, 0x00
00007f7c123d1b7b  mov rax, 0x5E723D793530
00007f7c123d1b85  call rax
00007f7c123d1b87  movaps xmm14, [rsp]
00007f7c123d1b8c  add rsp, 0x30
00007f7c123d1b90  vmovaps xmm0, [rsp]
00007f7c123d1b95  vmovaps xmm1, [rsp+0x10]
00007f7c123d1b9b  vmovaps xmm2, [rsp+0x20]
00007f7c123d1ba1  vmovaps xmm3, [rsp+0x30]
00007f7c123d1ba7  vmovaps xmm4, [rsp+0x40]
00007f7c123d1bad  vmovaps xmm5, [rsp+0x50]
00007f7c123d1bb3  vmovaps xmm6, [rsp+0x60]
00007f7c123d1bb9  vmovaps xmm7, [rsp+0x70]
00007f7c123d1bbf  vmovaps xmm8, [rsp+0x80]
00007f7c123d1bc8  vmovaps xmm9, [rsp+0x90]
00007f7c123d1bd1  vmovaps xmm10, [rsp+0xA0]
00007f7c123d1bda  vmovaps xmm11, [rsp+0xB0]
00007f7c123d1be3  vmovaps xmm12, [rsp+0xC0]
00007f7c123d1bec  vmovaps xmm13, [rsp+0xD0]
00007f7c123d1bf5  vmovaps xmm15, [rsp+0xE0]
00007f7c123d1bfe  add rsp, 0xF0
00007f7c123d1c05  pop r11
00007f7c123d1c07  pop r10
00007f7c123d1c09  pop r9
00007f7c123d1c0b  pop r8
00007f7c123d1c0d  pop rsi
00007f7c123d1c0e  pop rdi
00007f7c123d1c0f  pop rdx
00007f7c123d1c10  pop rcx
00007f7c123d1c11  pop rax
00007f7c123d1c12  add rsp, 0x08
00007f7c123d1c16  jmp 0x00007F7C123CFAAF
00007f7c123d1c1b  sub rsp, 0x08
00007f7c123d1c1f  push rax
00007f7c123d1c20  push rcx
00007f7c123d1c21  push rdx
00007f7c123d1c22  push rdi
00007f7c123d1c23  push rsi
00007f7c123d1c24  push r8
00007f7c123d1c26  push r9
00007f7c123d1c28  push r10
00007f7c123d1c2a  push r11
00007f7c123d1c2c  sub rsp, 0xF0
00007f7c123d1c33  vmovaps [rsp], xmm0
00007f7c123d1c38  vmovaps [rsp+0x10], xmm1
00007f7c123d1c3e  vmovaps [rsp+0x20], xmm2
00007f7c123d1c44  vmovaps [rsp+0x30], xmm3
00007f7c123d1c4a  vmovaps [rsp+0x40], xmm4
00007f7c123d1c50  vmovaps [rsp+0x50], xmm5
00007f7c123d1c56  vmovaps [rsp+0x60], xmm6
00007f7c123d1c5c  vmovaps [rsp+0x70], xmm7
00007f7c123d1c62  vmovaps [rsp+0x80], xmm8
00007f7c123d1c6b  vmovaps [rsp+0x90], xmm9
00007f7c123d1c74  vmovaps [rsp+0xA0], xmm10
00007f7c123d1c7d  vmovaps [rsp+0xB0], xmm11
00007f7c123d1c86  vmovaps [rsp+0xC0], xmm12
00007f7c123d1c8f  vmovaps [rsp+0xD0], xmm13
00007f7c123d1c98  vmovaps [rsp+0xE0], xmm14
00007f7c123d1ca1  sub rsp, 0x30
00007f7c123d1ca5  movaps [rsp], xmm15
00007f7c123d1caa  movaps [rsp+0x10], xmm13
00007f7c123d1cb0  movaps [rsp+0x20], xmm1
00007f7c123d1cb5  lea rdi, [rsp]
00007f7c123d1cb9  mov esi, 0x00
00007f7c123d1cbe  mov rax, 0x5E723D793530
00007f7c123d1cc8  call rax
00007f7c123d1cca  movaps xmm15, [rsp]
00007f7c123d1ccf  add rsp, 0x30
00007f7c123d1cd3  vmovaps xmm0, [rsp]
00007f7c123d1cd8  vmovaps xmm1, [rsp+0x10]
00007f7c123d1cde  vmovaps xmm2, [rsp+0x20]
00007f7c123d1ce4  vmovaps xmm3, [rsp+0x30]
00007f7c123d1cea  vmovaps xmm4, [rsp+0x40]
00007f7c123d1cf0  vmovaps xmm5, [rsp+0x50]
00007f7c123d1cf6  vmovaps xmm6, [rsp+0x60]
00007f7c123d1cfc  vmovaps xmm7, [rsp+0x70]
00007f7c123d1d02  vmovaps xmm8, [rsp+0x80]
00007f7c123d1d0b  vmovaps xmm9, [rsp+0x90]
00007f7c123d1d14  vmovaps xmm10, [rsp+0xA0]
00007f7c123d1d1d  vmovaps xmm11, [rsp+0xB0]
00007f7c123d1d26  vmovaps xmm12, [rsp+0xC0]
00007f7c123d1d2f  vmovaps xmm13, [rsp+0xD0]
00007f7c123d1d38  vmovaps xmm14, [rsp+0xE0]
00007f7c123d1d41  add rsp, 0xF0
00007f7c123d1d48  pop r11
00007f7c123d1d4a  pop r10
00007f7c123d1d4c  pop r9
00007f7c123d1d4e  pop r8
00007f7c123d1d50  pop rsi
00007f7c123d1d51  pop rdi
00007f7c123d1d52  pop rdx
00007f7c123d1d53  pop rcx
00007f7c123d1d54  pop rax
00007f7c123d1d55  add rsp, 0x08
00007f7c123d1d59  jmp 0x00007F7C123CFAEB
00007f7c123d1d5e  call 0x00007F7C121FF430
00007f7c123d1d63  jmp 0x00007F7C123CFAF8
00007f7c123d1d68  sub rsp, 0x08
00007f7c123d1d6c  push rax
00007f7c123d1d6d  push rcx
00007f7c123d1d6e  push rdx
00007f7c123d1d6f  push rdi
00007f7c123d1d70  push rsi
00007f7c123d1d71  push r8
00007f7c123d1d73  push r9
00007f7c123d1d75  push r10
00007f7c123d1d77  push r11
00007f7c123d1d79  sub rsp, 0xF0
00007f7c123d1d80  vmovaps [rsp], xmm0
00007f7c123d1d85  vmovaps [rsp+0x10], xmm1
00007f7c123d1d8b  vmovaps [rsp+0x20], xmm2
00007f7c123d1d91  vmovaps [rsp+0x30], xmm3
00007f7c123d1d97  vmovaps [rsp+0x40], xmm4
00007f7c123d1d9d  vmovaps [rsp+0x50], xmm5
00007f7c123d1da3  vmovaps [rsp+0x60], xmm6
00007f7c123d1da9  vmovaps [rsp+0x70], xmm7
00007f7c123d1daf  vmovaps [rsp+0x80], xmm8
00007f7c123d1db8  vmovaps [rsp+0x90], xmm9
00007f7c123d1dc1  vmovaps [rsp+0xA0], xmm10
00007f7c123d1dca  vmovaps [rsp+0xB0], xmm11
00007f7c123d1dd3  vmovaps [rsp+0xC0], xmm12
00007f7c123d1ddc  vmovaps [rsp+0xD0], xmm13
00007f7c123d1de5  vmovaps [rsp+0xE0], xmm15
00007f7c123d1dee  sub rsp, 0x30
00007f7c123d1df2  movaps [rsp], xmm14
00007f7c123d1df7  movaps [rsp+0x10], xmm13
00007f7c123d1dfd  movaps [rsp+0x20], xmm2
00007f7c123d1e02  lea rdi, [rsp]
00007f7c123d1e06  mov esi, 0x00
00007f7c123d1e0b  mov rax, 0x5E723D793530
00007f7c123d1e15  call rax
00007f7c123d1e17  movaps xmm14, [rsp]
00007f7c123d1e1c  add rsp, 0x30
00007f7c123d1e20  vmovaps xmm0, [rsp]
00007f7c123d1e25  vmovaps xmm1, [rsp+0x10]
00007f7c123d1e2b  vmovaps xmm2, [rsp+0x20]
00007f7c123d1e31  vmovaps xmm3, [rsp+0x30]
00007f7c123d1e37  vmovaps xmm4, [rsp+0x40]
00007f7c123d1e3d  vmovaps xmm5, [rsp+0x50]
00007f7c123d1e43  vmovaps xmm6, [rsp+0x60]
00007f7c123d1e49  vmovaps xmm7, [rsp+0x70]
00007f7c123d1e4f  vmovaps xmm8, [rsp+0x80]
00007f7c123d1e58  vmovaps xmm9, [rsp+0x90]
00007f7c123d1e61  vmovaps xmm10, [rsp+0xA0]
00007f7c123d1e6a  vmovaps xmm11, [rsp+0xB0]
00007f7c123d1e73  vmovaps xmm12, [rsp+0xC0]
00007f7c123d1e7c  vmovaps xmm13, [rsp+0xD0]
00007f7c123d1e85  vmovaps xmm15, [rsp+0xE0]
00007f7c123d1e8e  add rsp, 0xF0
00007f7c123d1e95  pop r11
00007f7c123d1e97  pop r10
00007f7c123d1e99  pop r9
00007f7c123d1e9b  pop r8
00007f7c123d1e9d  pop rsi
00007f7c123d1e9e  pop rdi
00007f7c123d1e9f  pop rdx
00007f7c123d1ea0  pop rcx
00007f7c123d1ea1  pop rax
00007f7c123d1ea2  add rsp, 0x08
00007f7c123d1ea6  jmp 0x00007F7C123CFB24
00007f7c123d1eab  sub rsp, 0x08
00007f7c123d1eaf  push rax
00007f7c123d1eb0  push rcx
00007f7c123d1eb1  push rdx
00007f7c123d1eb2  push rdi
00007f7c123d1eb3  push rsi
00007f7c123d1eb4  push r8
00007f7c123d1eb6  push r9
00007f7c123d1eb8  push r10
00007f7c123d1eba  push r11
00007f7c123d1ebc  sub rsp, 0xF0
00007f7c123d1ec3  vmovaps [rsp], xmm0
00007f7c123d1ec8  vmovaps [rsp+0x10], xmm2
00007f7c123d1ece  vmovaps [rsp+0x20], xmm3
00007f7c123d1ed4  vmovaps [rsp+0x30], xmm4
00007f7c123d1eda  vmovaps [rsp+0x40], xmm5
00007f7c123d1ee0  vmovaps [rsp+0x50], xmm6
00007f7c123d1ee6  vmovaps [rsp+0x60], xmm7
00007f7c123d1eec  vmovaps [rsp+0x70], xmm8
00007f7c123d1ef2  vmovaps [rsp+0x80], xmm9
00007f7c123d1efb  vmovaps [rsp+0x90], xmm10
00007f7c123d1f04  vmovaps [rsp+0xA0], xmm11
00007f7c123d1f0d  vmovaps [rsp+0xB0], xmm12
00007f7c123d1f16  vmovaps [rsp+0xC0], xmm13
00007f7c123d1f1f  vmovaps [rsp+0xD0], xmm14
00007f7c123d1f28  vmovaps [rsp+0xE0], xmm15
00007f7c123d1f31  sub rsp, 0x30
00007f7c123d1f35  movaps [rsp], xmm1
00007f7c123d1f39  movaps [rsp+0x10], xmm13
00007f7c123d1f3f  movaps [rsp+0x20], xmm2
00007f7c123d1f44  lea rdi, [rsp]
00007f7c123d1f48  mov esi, 0x00
00007f7c123d1f4d  mov rax, 0x5E723D793530
00007f7c123d1f57  call rax
00007f7c123d1f59  movaps xmm1, [rsp]
00007f7c123d1f5d  add rsp, 0x30
00007f7c123d1f61  vmovaps xmm0, [rsp]
00007f7c123d1f66  vmovaps xmm2, [rsp+0x10]
00007f7c123d1f6c  vmovaps xmm3, [rsp+0x20]
00007f7c123d1f72  vmovaps xmm4, [rsp+0x30]
00007f7c123d1f78  vmovaps xmm5, [rsp+0x40]
00007f7c123d1f7e  vmovaps xmm6, [rsp+0x50]
00007f7c123d1f84  vmovaps xmm7, [rsp+0x60]
00007f7c123d1f8a  vmovaps xmm8, [rsp+0x70]
00007f7c123d1f90  vmovaps xmm9, [rsp+0x80]
00007f7c123d1f99  vmovaps xmm10, [rsp+0x90]
00007f7c123d1fa2  vmovaps xmm11, [rsp+0xA0]
00007f7c123d1fab  vmovaps xmm12, [rsp+0xB0]
00007f7c123d1fb4  vmovaps xmm13, [rsp+0xC0]
00007f7c123d1fbd  vmovaps xmm14, [rsp+0xD0]
00007f7c123d1fc6  vmovaps xmm15, [rsp+0xE0]
00007f7c123d1fcf  add rsp, 0xF0
00007f7c123d1fd6  pop r11
00007f7c123d1fd8  pop r10
00007f7c123d1fda  pop r9
00007f7c123d1fdc  pop r8
00007f7c123d1fde  pop rsi
00007f7c123d1fdf  pop rdi
00007f7c123d1fe0  pop rdx
00007f7c123d1fe1  pop rcx
00007f7c123d1fe2  pop rax
00007f7c123d1fe3  add rsp, 0x08
00007f7c123d1fe7  jmp 0x00007F7C123CFB52
00007f7c123d1fec  sub rsp, 0x08
00007f7c123d1ff0  push rax
00007f7c123d1ff1  push rcx
00007f7c123d1ff2  push rdx
00007f7c123d1ff3  push rdi
00007f7c123d1ff4  push rsi
00007f7c123d1ff5  push r8
00007f7c123d1ff7  push r9
00007f7c123d1ff9  push r10
00007f7c123d1ffb  push r11
00007f7c123d1ffd  sub rsp, 0xF0
00007f7c123d2004  vmovaps [rsp], xmm0
00007f7c123d2009  vmovaps [rsp+0x10], xmm1
00007f7c123d200f  vmovaps [rsp+0x20], xmm3
00007f7c123d2015  vmovaps [rsp+0x30], xmm4
00007f7c123d201b  vmovaps [rsp+0x40], xmm5
00007f7c123d2021  vmovaps [rsp+0x50], xmm6
00007f7c123d2027  vmovaps [rsp+0x60], xmm7
00007f7c123d202d  vmovaps [rsp+0x70], xmm8
00007f7c123d2033  vmovaps [rsp+0x80], xmm9
00007f7c123d203c  vmovaps [rsp+0x90], xmm10
00007f7c123d2045  vmovaps [rsp+0xA0], xmm11
00007f7c123d204e  vmovaps [rsp+0xB0], xmm12
00007f7c123d2057  vmovaps [rsp+0xC0], xmm13
00007f7c123d2060  vmovaps [rsp+0xD0], xmm14
00007f7c123d2069  vmovaps [rsp+0xE0], xmm15
00007f7c123d2072  sub rsp, 0x30
00007f7c123d2076  movaps [rsp], xmm2
00007f7c123d207a  movaps [rsp+0x10], xmm1
00007f7c123d207f  movaps [rsp+0x20], xmm13
00007f7c123d2085  lea rdi, [rsp]
00007f7c123d2089  mov esi, 0x00
00007f7c123d208e  mov rax, 0x5E723D793530
00007f7c123d2098  call rax
00007f7c123d209a  movaps xmm2, [rsp]
00007f7c123d209e  add rsp, 0x30
00007f7c123d20a2  vmovaps xmm0, [rsp]
00007f7c123d20a7  vmovaps xmm1, [rsp+0x10]
00007f7c123d20ad  vmovaps xmm3, [rsp+0x20]
00007f7c123d20b3  vmovaps xmm4, [rsp+0x30]
00007f7c123d20b9  vmovaps xmm5, [rsp+0x40]
00007f7c123d20bf  vmovaps xmm6, [rsp+0x50]
00007f7c123d20c5  vmovaps xmm7, [rsp+0x60]
00007f7c123d20cb  vmovaps xmm8, [rsp+0x70]
00007f7c123d20d1  vmovaps xmm9, [rsp+0x80]
00007f7c123d20da  vmovaps xmm10, [rsp+0x90]
00007f7c123d20e3  vmovaps xmm11, [rsp+0xA0]
00007f7c123d20ec  vmovaps xmm12, [rsp+0xB0]
00007f7c123d20f5  vmovaps xmm13, [rsp+0xC0]
00007f7c123d20fe  vmovaps xmm14, [rsp+0xD0]
00007f7c123d2107  vmovaps xmm15, [rsp+0xE0]
00007f7c123d2110  add rsp, 0xF0
00007f7c123d2117  pop r11
00007f7c123d2119  pop r10
00007f7c123d211b  pop r9
00007f7c123d211d  pop r8
00007f7c123d211f  pop rsi
00007f7c123d2120  pop rdi
00007f7c123d2121  pop rdx
00007f7c123d2122  pop rcx
00007f7c123d2123  pop rax
00007f7c123d2124  add rsp, 0x08
00007f7c123d2128  jmp 0x00007F7C123CFBAB
00007f7c123d212d  call 0x00007F7C121FF430
00007f7c123d2132  jmp 0x00007F7C123CFBB8
00007f7c123d2137  sub rsp, 0x08
00007f7c123d213b  push rax
00007f7c123d213c  push rcx
00007f7c123d213d  push rdx
00007f7c123d213e  push rdi
00007f7c123d213f  push rsi
00007f7c123d2140  push r8
00007f7c123d2142  push r9
00007f7c123d2144  push r10
00007f7c123d2146  push r11
00007f7c123d2148  sub rsp, 0xF0
00007f7c123d214f  vmovaps [rsp], xmm0
00007f7c123d2154  vmovaps [rsp+0x10], xmm1
00007f7c123d215a  vmovaps [rsp+0x20], xmm2
00007f7c123d2160  vmovaps [rsp+0x30], xmm3
00007f7c123d2166  vmovaps [rsp+0x40], xmm4
00007f7c123d216c  vmovaps [rsp+0x50], xmm5
00007f7c123d2172  vmovaps [rsp+0x60], xmm6
00007f7c123d2178  vmovaps [rsp+0x70], xmm7
00007f7c123d217e  vmovaps [rsp+0x80], xmm8
00007f7c123d2187  vmovaps [rsp+0x90], xmm9
00007f7c123d2190  vmovaps [rsp+0xA0], xmm10
00007f7c123d2199  vmovaps [rsp+0xB0], xmm11
00007f7c123d21a2  vmovaps [rsp+0xC0], xmm12
00007f7c123d21ab  vmovaps [rsp+0xD0], xmm13
00007f7c123d21b4  vmovaps [rsp+0xE0], xmm14
00007f7c123d21bd  sub rsp, 0x30
00007f7c123d21c1  movaps [rsp], xmm15
00007f7c123d21c6  movaps [rsp+0x10], xmm13
00007f7c123d21cc  movaps [rsp+0x20], xmm1
00007f7c123d21d1  lea rdi, [rsp]
00007f7c123d21d5  mov esi, 0x00
00007f7c123d21da  mov rax, 0x5E723D793530
00007f7c123d21e4  call rax
00007f7c123d21e6  movaps xmm15, [rsp]
00007f7c123d21eb  add rsp, 0x30
00007f7c123d21ef  vmovaps xmm0, [rsp]
00007f7c123d21f4  vmovaps xmm1, [rsp+0x10]
00007f7c123d21fa  vmovaps xmm2, [rsp+0x20]
00007f7c123d2200  vmovaps xmm3, [rsp+0x30]
00007f7c123d2206  vmovaps xmm4, [rsp+0x40]
00007f7c123d220c  vmovaps xmm5, [rsp+0x50]
00007f7c123d2212  vmovaps xmm6, [rsp+0x60]
00007f7c123d2218  vmovaps xmm7, [rsp+0x70]
00007f7c123d221e  vmovaps xmm8, [rsp+0x80]
00007f7c123d2227  vmovaps xmm9, [rsp+0x90]
00007f7c123d2230  vmovaps xmm10, [rsp+0xA0]
00007f7c123d2239  vmovaps xmm11, [rsp+0xB0]
00007f7c123d2242  vmovaps xmm12, [rsp+0xC0]
00007f7c123d224b  vmovaps xmm13, [rsp+0xD0]
00007f7c123d2254  vmovaps xmm14, [rsp+0xE0]
00007f7c123d225d  add rsp, 0xF0
00007f7c123d2264  pop r11
00007f7c123d2266  pop r10
00007f7c123d2268  pop r9
00007f7c123d226a  pop r8
00007f7c123d226c  pop rsi
00007f7c123d226d  pop rdi
00007f7c123d226e  pop rdx
00007f7c123d226f  pop rcx
00007f7c123d2270  pop rax
00007f7c123d2271  add rsp, 0x08
00007f7c123d2275  jmp 0x00007F7C123CFBF7
00007f7c123d227a  sub rsp, 0x08
00007f7c123d227e  push rax
00007f7c123d227f  push rcx
00007f7c123d2280  push rdx
00007f7c123d2281  push rdi
00007f7c123d2282  push rsi
00007f7c123d2283  push r8
00007f7c123d2285  push r9
00007f7c123d2287  push r10
00007f7c123d2289  push r11
00007f7c123d228b  sub rsp, 0xF0
00007f7c123d2292  vmovaps [rsp], xmm0
00007f7c123d2297  vmovaps [rsp+0x10], xmm1
00007f7c123d229d  vmovaps [rsp+0x20], xmm2
00007f7c123d22a3  vmovaps [rsp+0x30], xmm3
00007f7c123d22a9  vmovaps [rsp+0x40], xmm4
00007f7c123d22af  vmovaps [rsp+0x50], xmm5
00007f7c123d22b5  vmovaps [rsp+0x60], xmm6
00007f7c123d22bb  vmovaps [rsp+0x70], xmm7
00007f7c123d22c1  vmovaps [rsp+0x80], xmm8
00007f7c123d22ca  vmovaps [rsp+0x90], xmm9
00007f7c123d22d3  vmovaps [rsp+0xA0], xmm10
00007f7c123d22dc  vmovaps [rsp+0xB0], xmm11
00007f7c123d22e5  vmovaps [rsp+0xC0], xmm12
00007f7c123d22ee  vmovaps [rsp+0xD0], xmm13
00007f7c123d22f7  vmovaps [rsp+0xE0], xmm15
00007f7c123d2300  sub rsp, 0x30
00007f7c123d2304  movaps [rsp], xmm14
00007f7c123d2309  movaps [rsp+0x10], xmm11
00007f7c123d230f  movaps [rsp+0x20], xmm1
00007f7c123d2314  lea rdi, [rsp]
00007f7c123d2318  mov esi, 0x00
00007f7c123d231d  mov rax, 0x5E723D793530
00007f7c123d2327  call rax
00007f7c123d2329  movaps xmm14, [rsp]
00007f7c123d232e  add rsp, 0x30
00007f7c123d2332  vmovaps xmm0, [rsp]
00007f7c123d2337  vmovaps xmm1, [rsp+0x10]
00007f7c123d233d  vmovaps xmm2, [rsp+0x20]
00007f7c123d2343  vmovaps xmm3, [rsp+0x30]
00007f7c123d2349  vmovaps xmm4, [rsp+0x40]
00007f7c123d234f  vmovaps xmm5, [rsp+0x50]
00007f7c123d2355  vmovaps xmm6, [rsp+0x60]
00007f7c123d235b  vmovaps xmm7, [rsp+0x70]
00007f7c123d2361  vmovaps xmm8, [rsp+0x80]
00007f7c123d236a  vmovaps xmm9, [rsp+0x90]
00007f7c123d2373  vmovaps xmm10, [rsp+0xA0]
00007f7c123d237c  vmovaps xmm11, [rsp+0xB0]
00007f7c123d2385  vmovaps xmm12, [rsp+0xC0]
00007f7c123d238e  vmovaps xmm13, [rsp+0xD0]
00007f7c123d2397  vmovaps xmm15, [rsp+0xE0]
00007f7c123d23a0  add rsp, 0xF0
00007f7c123d23a7  pop r11
00007f7c123d23a9  pop r10
00007f7c123d23ab  pop r9
00007f7c123d23ad  pop r8
00007f7c123d23af  pop rsi
00007f7c123d23b0  pop rdi
00007f7c123d23b1  pop rdx
00007f7c123d23b2  pop rcx
00007f7c123d23b3  pop rax
00007f7c123d23b4  add rsp, 0x08
00007f7c123d23b8  jmp 0x00007F7C123CFC21
00007f7c123d23bd  sub rsp, 0x08
00007f7c123d23c1  push rax
00007f7c123d23c2  push rcx
00007f7c123d23c3  push rdx
00007f7c123d23c4  push rdi
00007f7c123d23c5  push rsi
00007f7c123d23c6  push r8
00007f7c123d23c8  push r9
00007f7c123d23ca  push r10
00007f7c123d23cc  push r11
00007f7c123d23ce  sub rsp, 0xF0
00007f7c123d23d5  vmovaps [rsp], xmm0
00007f7c123d23da  vmovaps [rsp+0x10], xmm1
00007f7c123d23e0  vmovaps [rsp+0x20], xmm2
00007f7c123d23e6  vmovaps [rsp+0x30], xmm3
00007f7c123d23ec  vmovaps [rsp+0x40], xmm4
00007f7c123d23f2  vmovaps [rsp+0x50], xmm5
00007f7c123d23f8  vmovaps [rsp+0x60], xmm6
00007f7c123d23fe  vmovaps [rsp+0x70], xmm7
00007f7c123d2404  vmovaps [rsp+0x80], xmm8
00007f7c123d240d  vmovaps [rsp+0x90], xmm9
00007f7c123d2416  vmovaps [rsp+0xA0], xmm10
00007f7c123d241f  vmovaps [rsp+0xB0], xmm11
00007f7c123d2428  vmovaps [rsp+0xC0], xmm12
00007f7c123d2431  vmovaps [rsp+0xD0], xmm14
00007f7c123d243a  vmovaps [rsp+0xE0], xmm15
00007f7c123d2443  sub rsp, 0x30
00007f7c123d2447  movaps [rsp], xmm13
00007f7c123d244c  movaps [rsp+0x10], xmm11
00007f7c123d2452  movaps [rsp+0x20], xmm1
00007f7c123d2457  lea rdi, [rsp]
00007f7c123d245b  mov esi, 0x00
00007f7c123d2460  mov rax, 0x5E723D793530
00007f7c123d246a  call rax
00007f7c123d246c  movaps xmm13, [rsp]
00007f7c123d2471  add rsp, 0x30
00007f7c123d2475  vmovaps xmm0, [rsp]
00007f7c123d247a  vmovaps xmm1, [rsp+0x10]
00007f7c123d2480  vmovaps xmm2, [rsp+0x20]
00007f7c123d2486  vmovaps xmm3, [rsp+0x30]
00007f7c123d248c  vmovaps xmm4, [rsp+0x40]
00007f7c123d2492  vmovaps xmm5, [rsp+0x50]
00007f7c123d2498  vmovaps xmm6, [rsp+0x60]
00007f7c123d249e  vmovaps xmm7, [rsp+0x70]
00007f7c123d24a4  vmovaps xmm8, [rsp+0x80]
00007f7c123d24ad  vmovaps xmm9, [rsp+0x90]
00007f7c123d24b6  vmovaps xmm10, [rsp+0xA0]
00007f7c123d24bf  vmovaps xmm11, [rsp+0xB0]
00007f7c123d24c8  vmovaps xmm12, [rsp+0xC0]
00007f7c123d24d1  vmovaps xmm14, [rsp+0xD0]
00007f7c123d24da  vmovaps xmm15, [rsp+0xE0]
00007f7c123d24e3  add rsp, 0xF0
00007f7c123d24ea  pop r11
00007f7c123d24ec  pop r10
00007f7c123d24ee  pop r9
00007f7c123d24f0  pop r8
00007f7c123d24f2  pop rsi
00007f7c123d24f3  pop rdi
00007f7c123d24f4  pop rdx
00007f7c123d24f5  pop rcx
00007f7c123d24f6  pop rax
00007f7c123d24f7  add rsp, 0x08
00007f7c123d24fb  jmp 0x00007F7C123CFC76
00007f7c123d2500  call 0x00007F7C121FF430
00007f7c123d2505  jmp 0x00007F7C123CFC83
00007f7c123d250a  sub rsp, 0x08
00007f7c123d250e  push rax
00007f7c123d250f  push rcx
00007f7c123d2510  push rdx
00007f7c123d2511  push rdi
00007f7c123d2512  push rsi
00007f7c123d2513  push r8
00007f7c123d2515  push r9
00007f7c123d2517  push r10
00007f7c123d2519  push r11
00007f7c123d251b  sub rsp, 0xF0
00007f7c123d2522  vmovaps [rsp], xmm0
00007f7c123d2527  vmovaps [rsp+0x10], xmm1
00007f7c123d252d  vmovaps [rsp+0x20], xmm2
00007f7c123d2533  vmovaps [rsp+0x30], xmm3
00007f7c123d2539  vmovaps [rsp+0x40], xmm4
00007f7c123d253f  vmovaps [rsp+0x50], xmm5
00007f7c123d2545  vmovaps [rsp+0x60], xmm6
00007f7c123d254b  vmovaps [rsp+0x70], xmm7
00007f7c123d2551  vmovaps [rsp+0x80], xmm8
00007f7c123d255a  vmovaps [rsp+0x90], xmm9
00007f7c123d2563  vmovaps [rsp+0xA0], xmm10
00007f7c123d256c  vmovaps [rsp+0xB0], xmm11
00007f7c123d2575  vmovaps [rsp+0xC0], xmm12
00007f7c123d257e  vmovaps [rsp+0xD0], xmm13
00007f7c123d2587  vmovaps [rsp+0xE0], xmm14
00007f7c123d2590  sub rsp, 0x30
00007f7c123d2594  movaps [rsp], xmm15
00007f7c123d2599  movaps [rsp+0x10], xmm11
00007f7c123d259f  movaps [rsp+0x20], xmm1
00007f7c123d25a4  lea rdi, [rsp]
00007f7c123d25a8  mov esi, 0x00
00007f7c123d25ad  mov rax, 0x5E723D793530
00007f7c123d25b7  call rax
00007f7c123d25b9  movaps xmm15, [rsp]
00007f7c123d25be  add rsp, 0x30
00007f7c123d25c2  vmovaps xmm0, [rsp]
00007f7c123d25c7  vmovaps xmm1, [rsp+0x10]
00007f7c123d25cd  vmovaps xmm2, [rsp+0x20]
00007f7c123d25d3  vmovaps xmm3, [rsp+0x30]
00007f7c123d25d9  vmovaps xmm4, [rsp+0x40]
00007f7c123d25df  vmovaps xmm5, [rsp+0x50]
00007f7c123d25e5  vmovaps xmm6, [rsp+0x60]
00007f7c123d25eb  vmovaps xmm7, [rsp+0x70]
00007f7c123d25f1  vmovaps xmm8, [rsp+0x80]
00007f7c123d25fa  vmovaps xmm9, [rsp+0x90]
00007f7c123d2603  vmovaps xmm10, [rsp+0xA0]
00007f7c123d260c  vmovaps xmm11, [rsp+0xB0]
00007f7c123d2615  vmovaps xmm12, [rsp+0xC0]
00007f7c123d261e  vmovaps xmm13, [rsp+0xD0]
00007f7c123d2627  vmovaps xmm14, [rsp+0xE0]
00007f7c123d2630  add rsp, 0xF0
00007f7c123d2637  pop r11
00007f7c123d2639  pop r10
00007f7c123d263b  pop r9
00007f7c123d263d  pop r8
00007f7c123d263f  pop rsi
00007f7c123d2640  pop rdi
00007f7c123d2641  pop rdx
00007f7c123d2642  pop rcx
00007f7c123d2643  pop rax
00007f7c123d2644  add rsp, 0x08
00007f7c123d2648  jmp 0x00007F7C123CFCBC
00007f7c123d264d  sub rsp, 0x08
00007f7c123d2651  push rax
00007f7c123d2652  push rcx
00007f7c123d2653  push rdx
00007f7c123d2654  push rdi
00007f7c123d2655  push rsi
00007f7c123d2656  push r8
00007f7c123d2658  push r9
00007f7c123d265a  push r10
00007f7c123d265c  push r11
00007f7c123d265e  sub rsp, 0xF0
00007f7c123d2665  vmovaps [rsp], xmm0
00007f7c123d266a  vmovaps [rsp+0x10], xmm1
00007f7c123d2670  vmovaps [rsp+0x20], xmm2
00007f7c123d2676  vmovaps [rsp+0x30], xmm3
00007f7c123d267c  vmovaps [rsp+0x40], xmm4
00007f7c123d2682  vmovaps [rsp+0x50], xmm5
00007f7c123d2688  vmovaps [rsp+0x60], xmm6
00007f7c123d268e  vmovaps [rsp+0x70], xmm7
00007f7c123d2694  vmovaps [rsp+0x80], xmm8
00007f7c123d269d  vmovaps [rsp+0x90], xmm9
00007f7c123d26a6  vmovaps [rsp+0xA0], xmm10
00007f7c123d26af  vmovaps [rsp+0xB0], xmm12
00007f7c123d26b8  vmovaps [rsp+0xC0], xmm13
00007f7c123d26c1  vmovaps [rsp+0xD0], xmm14
00007f7c123d26ca  vmovaps [rsp+0xE0], xmm15
00007f7c123d26d3  sub rsp, 0x30
00007f7c123d26d7  movaps [rsp], xmm11
00007f7c123d26dc  movaps [rsp+0x10], xmm6
00007f7c123d26e1  movaps [rsp+0x20], xmm14
00007f7c123d26e7  lea rdi, [rsp]
00007f7c123d26eb  mov esi, 0x00
00007f7c123d26f0  mov rax, 0x5E723D793530
00007f7c123d26fa  call rax
00007f7c123d26fc  movaps xmm11, [rsp]
00007f7c123d2701  add rsp, 0x30
00007f7c123d2705  vmovaps xmm0, [rsp]
00007f7c123d270a  vmovaps xmm1, [rsp+0x10]
00007f7c123d2710  vmovaps xmm2, [rsp+0x20]
00007f7c123d2716  vmovaps xmm3, [rsp+0x30]
00007f7c123d271c  vmovaps xmm4, [rsp+0x40]
00007f7c123d2722  vmovaps xmm5, [rsp+0x50]
00007f7c123d2728  vmovaps xmm6, [rsp+0x60]
00007f7c123d272e  vmovaps xmm7, [rsp+0x70]
00007f7c123d2734  vmovaps xmm8, [rsp+0x80]
00007f7c123d273d  vmovaps xmm9, [rsp+0x90]
00007f7c123d2746  vmovaps xmm10, [rsp+0xA0]
00007f7c123d274f  vmovaps xmm12, [rsp+0xB0]
00007f7c123d2758  vmovaps xmm13, [rsp+0xC0]
00007f7c123d2761  vmovaps xmm14, [rsp+0xD0]
00007f7c123d276a  vmovaps xmm15, [rsp+0xE0]
00007f7c123d2773  add rsp, 0xF0
00007f7c123d277a  pop r11
00007f7c123d277c  pop r10
00007f7c123d277e  pop r9
00007f7c123d2780  pop r8
00007f7c123d2782  pop rsi
00007f7c123d2783  pop rdi
00007f7c123d2784  pop rdx
00007f7c123d2785  pop rcx
00007f7c123d2786  pop rax
00007f7c123d2787  add rsp, 0x08
00007f7c123d278b  jmp 0x00007F7C123CFD34
00007f7c123d2790  call 0x00007F7C121FF430
00007f7c123d2795  jmp 0x00007F7C123CFD3E
00007f7c123d279a  sub rsp, 0x08
00007f7c123d279e  push rax
00007f7c123d279f  push rcx
00007f7c123d27a0  push rdx
00007f7c123d27a1  push rdi
00007f7c123d27a2  push rsi
00007f7c123d27a3  push r8
00007f7c123d27a5  push r9
00007f7c123d27a7  push r10
00007f7c123d27a9  push r11
00007f7c123d27ab  sub rsp, 0xF0
00007f7c123d27b2  vmovaps [rsp], xmm0
00007f7c123d27b7  vmovaps [rsp+0x10], xmm1
00007f7c123d27bd  vmovaps [rsp+0x20], xmm2
00007f7c123d27c3  vmovaps [rsp+0x30], xmm3
00007f7c123d27c9  vmovaps [rsp+0x40], xmm4
00007f7c123d27cf  vmovaps [rsp+0x50], xmm5
00007f7c123d27d5  vmovaps [rsp+0x60], xmm6
00007f7c123d27db  vmovaps [rsp+0x70], xmm7
00007f7c123d27e1  vmovaps [rsp+0x80], xmm8
00007f7c123d27ea  vmovaps [rsp+0x90], xmm9
00007f7c123d27f3  vmovaps [rsp+0xA0], xmm10
00007f7c123d27fc  vmovaps [rsp+0xB0], xmm11
00007f7c123d2805  vmovaps [rsp+0xC0], xmm12
00007f7c123d280e  vmovaps [rsp+0xD0], xmm13
00007f7c123d2817  vmovaps [rsp+0xE0], xmm15
00007f7c123d2820  sub rsp, 0x30
00007f7c123d2824  movaps [rsp], xmm14
00007f7c123d2829  movaps [rsp+0x10], xmm6
00007f7c123d282e  movaps [rsp+0x20], xmm2
00007f7c123d2833  lea rdi, [rsp]
00007f7c123d2837  mov esi, 0x00
00007f7c123d283c  mov rax, 0x5E723D793530
00007f7c123d2846  call rax
00007f7c123d2848  movaps xmm14, [rsp]
00007f7c123d284d  add rsp, 0x30
00007f7c123d2851  vmovaps xmm0, [rsp]
00007f7c123d2856  vmovaps xmm1, [rsp+0x10]
00007f7c123d285c  vmovaps xmm2, [rsp+0x20]
00007f7c123d2862  vmovaps xmm3, [rsp+0x30]
00007f7c123d2868  vmovaps xmm4, [rsp+0x40]
00007f7c123d286e  vmovaps xmm5, [rsp+0x50]
00007f7c123d2874  vmovaps xmm6, [rsp+0x60]
00007f7c123d287a  vmovaps xmm7, [rsp+0x70]
00007f7c123d2880  vmovaps xmm8, [rsp+0x80]
00007f7c123d2889  vmovaps xmm9, [rsp+0x90]
00007f7c123d2892  vmovaps xmm10, [rsp+0xA0]
00007f7c123d289b  vmovaps xmm11, [rsp+0xB0]
00007f7c123d28a4  vmovaps xmm12, [rsp+0xC0]
00007f7c123d28ad  vmovaps xmm13, [rsp+0xD0]
00007f7c123d28b6  vmovaps xmm15, [rsp+0xE0]
00007f7c123d28bf  add rsp, 0xF0
00007f7c123d28c6  pop r11
00007f7c123d28c8  pop r10
00007f7c123d28ca  pop r9
00007f7c123d28cc  pop r8
00007f7c123d28ce  pop rsi
00007f7c123d28cf  pop rdi
00007f7c123d28d0  pop rdx
00007f7c123d28d1  pop rcx
00007f7c123d28d2  pop rax
00007f7c123d28d3  add rsp, 0x08
00007f7c123d28d7  jmp 0x00007F7C123CFD72
00007f7c123d28dc  sub rsp, 0x08
00007f7c123d28e0  push rax
00007f7c123d28e1  push rcx
00007f7c123d28e2  push rdx
00007f7c123d28e3  push rdi
00007f7c123d28e4  push rsi
00007f7c123d28e5  push r8
00007f7c123d28e7  push r9
00007f7c123d28e9  push r10
00007f7c123d28eb  push r11
00007f7c123d28ed  sub rsp, 0xF0
00007f7c123d28f4  vmovaps [rsp], xmm0
00007f7c123d28f9  vmovaps [rsp+0x10], xmm1
00007f7c123d28ff  vmovaps [rsp+0x20], xmm2
00007f7c123d2905  vmovaps [rsp+0x30], xmm3
00007f7c123d290b  vmovaps [rsp+0x40], xmm4
00007f7c123d2911  vmovaps [rsp+0x50], xmm5
00007f7c123d2917  vmovaps [rsp+0x60], xmm7
00007f7c123d291d  vmovaps [rsp+0x70], xmm8
00007f7c123d2923  vmovaps [rsp+0x80], xmm9
00007f7c123d292c  vmovaps [rsp+0x90], xmm10
00007f7c123d2935  vmovaps [rsp+0xA0], xmm11
00007f7c123d293e  vmovaps [rsp+0xB0], xmm12
00007f7c123d2947  vmovaps [rsp+0xC0], xmm13
00007f7c123d2950  vmovaps [rsp+0xD0], xmm14
00007f7c123d2959  vmovaps [rsp+0xE0], xmm15
00007f7c123d2962  sub rsp, 0x30
00007f7c123d2966  movaps [rsp], xmm6
00007f7c123d296a  movaps [rsp+0x10], xmm5
00007f7c123d296f  movaps [rsp+0x20], xmm1
00007f7c123d2974  lea rdi, [rsp]
00007f7c123d2978  mov esi, 0x00
00007f7c123d297d  mov rax, 0x5E723D793530
00007f7c123d2987  call rax
00007f7c123d2989  movaps xmm6, [rsp]
00007f7c123d298d  add rsp, 0x30
00007f7c123d2991  vmovaps xmm0, [rsp]
00007f7c123d2996  vmovaps xmm1, [rsp+0x10]
00007f7c123d299c  vmovaps xmm2, [rsp+0x20]
00007f7c123d29a2  vmovaps xmm3, [rsp+0x30]
00007f7c123d29a8  vmovaps xmm4, [rsp+0x40]
00007f7c123d29ae  vmovaps xmm5, [rsp+0x50]
00007f7c123d29b4  vmovaps xmm7, [rsp+0x60]
00007f7c123d29ba  vmovaps xmm8, [rsp+0x70]
00007f7c123d29c0  vmovaps xmm9, [rsp+0x80]
00007f7c123d29c9  vmovaps xmm10, [rsp+0x90]
00007f7c123d29d2  vmovaps xmm11, [rsp+0xA0]
00007f7c123d29db  vmovaps xmm12, [rsp+0xB0]
00007f7c123d29e4  vmovaps xmm13, [rsp+0xC0]
00007f7c123d29ed  vmovaps xmm14, [rsp+0xD0]
00007f7c123d29f6  vmovaps xmm15, [rsp+0xE0]
00007f7c123d29ff  add rsp, 0xF0
00007f7c123d2a06  pop r11
00007f7c123d2a08  pop r10
00007f7c123d2a0a  pop r9
00007f7c123d2a0c  pop r8
00007f7c123d2a0e  pop rsi
00007f7c123d2a0f  pop rdi
00007f7c123d2a10  pop rdx
00007f7c123d2a11  pop rcx
00007f7c123d2a12  pop rax
00007f7c123d2a13  add rsp, 0x08
00007f7c123d2a17  jmp 0x00007F7C123CFD98
00007f7c123d2a1c  sub rsp, 0x08
00007f7c123d2a20  push rax
00007f7c123d2a21  push rcx
00007f7c123d2a22  push rdx
00007f7c123d2a23  push rdi
00007f7c123d2a24  push rsi
00007f7c123d2a25  push r8
00007f7c123d2a27  push r9
00007f7c123d2a29  push r10
00007f7c123d2a2b  push r11
00007f7c123d2a2d  sub rsp, 0xF0
00007f7c123d2a34  vmovaps [rsp], xmm0
00007f7c123d2a39  vmovaps [rsp+0x10], xmm2
00007f7c123d2a3f  vmovaps [rsp+0x20], xmm3
00007f7c123d2a45  vmovaps [rsp+0x30], xmm4
00007f7c123d2a4b  vmovaps [rsp+0x40], xmm5
00007f7c123d2a51  vmovaps [rsp+0x50], xmm6
00007f7c123d2a57  vmovaps [rsp+0x60], xmm7
00007f7c123d2a5d  vmovaps [rsp+0x70], xmm8
00007f7c123d2a63  vmovaps [rsp+0x80], xmm9
00007f7c123d2a6c  vmovaps [rsp+0x90], xmm10
00007f7c123d2a75  vmovaps [rsp+0xA0], xmm11
00007f7c123d2a7e  vmovaps [rsp+0xB0], xmm12
00007f7c123d2a87  vmovaps [rsp+0xC0], xmm13
00007f7c123d2a90  vmovaps [rsp+0xD0], xmm14
00007f7c123d2a99  vmovaps [rsp+0xE0], xmm15
00007f7c123d2aa2  sub rsp, 0x30
00007f7c123d2aa6  movaps [rsp], xmm1
00007f7c123d2aaa  movaps [rsp+0x10], xmm5
00007f7c123d2aaf  movaps [rsp+0x20], xmm13
00007f7c123d2ab5  lea rdi, [rsp]
00007f7c123d2ab9  mov esi, 0x00
00007f7c123d2abe  mov rax, 0x5E723D793530
00007f7c123d2ac8  call rax
00007f7c123d2aca  movaps xmm1, [rsp]
00007f7c123d2ace  add rsp, 0x30
00007f7c123d2ad2  vmovaps xmm0, [rsp]
00007f7c123d2ad7  vmovaps xmm2, [rsp+0x10]
00007f7c123d2add  vmovaps xmm3, [rsp+0x20]
00007f7c123d2ae3  vmovaps xmm4, [rsp+0x30]
00007f7c123d2ae9  vmovaps xmm5, [rsp+0x40]
00007f7c123d2aef  vmovaps xmm6, [rsp+0x50]
00007f7c123d2af5  vmovaps xmm7, [rsp+0x60]
00007f7c123d2afb  vmovaps xmm8, [rsp+0x70]
00007f7c123d2b01  vmovaps xmm9, [rsp+0x80]
00007f7c123d2b0a  vmovaps xmm10, [rsp+0x90]
00007f7c123d2b13  vmovaps xmm11, [rsp+0xA0]
00007f7c123d2b1c  vmovaps xmm12, [rsp+0xB0]
00007f7c123d2b25  vmovaps xmm13, [rsp+0xC0]
00007f7c123d2b2e  vmovaps xmm14, [rsp+0xD0]
00007f7c123d2b37  vmovaps xmm15, [rsp+0xE0]
00007f7c123d2b40  add rsp, 0xF0
00007f7c123d2b47  pop r11
00007f7c123d2b49  pop r10
00007f7c123d2b4b  pop r9
00007f7c123d2b4d  pop r8
00007f7c123d2b4f  pop rsi
00007f7c123d2b50  pop rdi
00007f7c123d2b51  pop rdx
00007f7c123d2b52  pop rcx
00007f7c123d2b53  pop rax
00007f7c123d2b54  add rsp, 0x08
00007f7c123d2b58  jmp 0x00007F7C123CFDB6
00007f7c123d2b5d  sub rsp, 0x08
00007f7c123d2b61  push rax
00007f7c123d2b62  push rcx
00007f7c123d2b63  push rdx
00007f7c123d2b64  push rdi
00007f7c123d2b65  push rsi
00007f7c123d2b66  push r8
00007f7c123d2b68  push r9
00007f7c123d2b6a  push r10
00007f7c123d2b6c  push r11
00007f7c123d2b6e  sub rsp, 0xF0
00007f7c123d2b75  vmovaps [rsp], xmm0
00007f7c123d2b7a  vmovaps [rsp+0x10], xmm1
00007f7c123d2b80  vmovaps [rsp+0x20], xmm2
00007f7c123d2b86  vmovaps [rsp+0x30], xmm3
00007f7c123d2b8c  vmovaps [rsp+0x40], xmm4
00007f7c123d2b92  vmovaps [rsp+0x50], xmm6
00007f7c123d2b98  vmovaps [rsp+0x60], xmm7
00007f7c123d2b9e  vmovaps [rsp+0x70], xmm8
00007f7c123d2ba4  vmovaps [rsp+0x80], xmm9
00007f7c123d2bad  vmovaps [rsp+0x90], xmm10
00007f7c123d2bb6  vmovaps [rsp+0xA0], xmm11
00007f7c123d2bbf  vmovaps [rsp+0xB0], xmm12
00007f7c123d2bc8  vmovaps [rsp+0xC0], xmm13
00007f7c123d2bd1  vmovaps [rsp+0xD0], xmm14
00007f7c123d2bda  vmovaps [rsp+0xE0], xmm15
00007f7c123d2be3  sub rsp, 0x30
00007f7c123d2be7  movaps [rsp], xmm5
00007f7c123d2beb  movaps [rsp+0x10], xmm2
00007f7c123d2bf0  movaps [rsp+0x20], xmm13
00007f7c123d2bf6  lea rdi, [rsp]
00007f7c123d2bfa  mov esi, 0x00
00007f7c123d2bff  mov rax, 0x5E723D793530
00007f7c123d2c09  call rax
00007f7c123d2c0b  movaps xmm5, [rsp]
00007f7c123d2c0f  add rsp, 0x30
00007f7c123d2c13  vmovaps xmm0, [rsp]
00007f7c123d2c18  vmovaps xmm1, [rsp+0x10]
00007f7c123d2c1e  vmovaps xmm2, [rsp+0x20]
00007f7c123d2c24  vmovaps xmm3, [rsp+0x30]
00007f7c123d2c2a  vmovaps xmm4, [rsp+0x40]
00007f7c123d2c30  vmovaps xmm6, [rsp+0x50]
00007f7c123d2c36  vmovaps xmm7, [rsp+0x60]
00007f7c123d2c3c  vmovaps xmm8, [rsp+0x70]
00007f7c123d2c42  vmovaps xmm9, [rsp+0x80]
00007f7c123d2c4b  vmovaps xmm10, [rsp+0x90]
00007f7c123d2c54  vmovaps xmm11, [rsp+0xA0]
00007f7c123d2c5d  vmovaps xmm12, [rsp+0xB0]
00007f7c123d2c66  vmovaps xmm13, [rsp+0xC0]
00007f7c123d2c6f  vmovaps xmm14, [rsp+0xD0]
00007f7c123d2c78  vmovaps xmm15, [rsp+0xE0]
00007f7c123d2c81  add rsp, 0xF0
00007f7c123d2c88  pop r11
00007f7c123d2c8a  pop r10
00007f7c123d2c8c  pop r9
00007f7c123d2c8e  pop r8
00007f7c123d2c90  pop rsi
00007f7c123d2c91  pop rdi
00007f7c123d2c92  pop rdx
00007f7c123d2c93  pop rcx
00007f7c123d2c94  pop rax
00007f7c123d2c95  add rsp, 0x08
00007f7c123d2c99  jmp 0x00007F7C123CFDEC
00007f7c123d2c9e  sub rsp, 0x08
00007f7c123d2ca2  push rax
00007f7c123d2ca3  push rcx
00007f7c123d2ca4  push rdx
00007f7c123d2ca5  push rdi
00007f7c123d2ca6  push rsi
00007f7c123d2ca7  push r8
00007f7c123d2ca9  push r9
00007f7c123d2cab  push r10
00007f7c123d2cad  push r11
00007f7c123d2caf  sub rsp, 0xF0
00007f7c123d2cb6  vmovaps [rsp], xmm0
00007f7c123d2cbb  vmovaps [rsp+0x10], xmm1
00007f7c123d2cc1  vmovaps [rsp+0x20], xmm2
00007f7c123d2cc7  vmovaps [rsp+0x30], xmm3
00007f7c123d2ccd  vmovaps [rsp+0x40], xmm4
00007f7c123d2cd3  vmovaps [rsp+0x50], xmm5
00007f7c123d2cd9  vmovaps [rsp+0x60], xmm6
00007f7c123d2cdf  vmovaps [rsp+0x70], xmm7
00007f7c123d2ce5  vmovaps [rsp+0x80], xmm8
00007f7c123d2cee  vmovaps [rsp+0x90], xmm9
00007f7c123d2cf7  vmovaps [rsp+0xA0], xmm10
00007f7c123d2d00  vmovaps [rsp+0xB0], xmm11
00007f7c123d2d09  vmovaps [rsp+0xC0], xmm12
00007f7c123d2d12  vmovaps [rsp+0xD0], xmm14
00007f7c123d2d1b  vmovaps [rsp+0xE0], xmm15
00007f7c123d2d24  sub rsp, 0x30
00007f7c123d2d28  movaps [rsp], xmm13
00007f7c123d2d2d  movaps [rsp+0x10], xmm10
00007f7c123d2d33  movaps [rsp+0x20], xmm1
00007f7c123d2d38  lea rdi, [rsp]
00007f7c123d2d3c  mov esi, 0x00
00007f7c123d2d41  mov rax, 0x5E723D793530
00007f7c123d2d4b  call rax
00007f7c123d2d4d  movaps xmm13, [rsp]
00007f7c123d2d52  add rsp, 0x30
00007f7c123d2d56  vmovaps xmm0, [rsp]
00007f7c123d2d5b  vmovaps xmm1, [rsp+0x10]
00007f7c123d2d61  vmovaps xmm2, [rsp+0x20]
00007f7c123d2d67  vmovaps xmm3, [rsp+0x30]
00007f7c123d2d6d  vmovaps xmm4, [rsp+0x40]
00007f7c123d2d73  vmovaps xmm5, [rsp+0x50]
00007f7c123d2d79  vmovaps xmm6, [rsp+0x60]
00007f7c123d2d7f  vmovaps xmm7, [rsp+0x70]
00007f7c123d2d85  vmovaps xmm8, [rsp+0x80]
00007f7c123d2d8e  vmovaps xmm9, [rsp+0x90]
00007f7c123d2d97  vmovaps xmm10, [rsp+0xA0]
00007f7c123d2da0  vmovaps xmm11, [rsp+0xB0]
00007f7c123d2da9  vmovaps xmm12, [rsp+0xC0]
00007f7c123d2db2  vmovaps xmm14, [rsp+0xD0]
00007f7c123d2dbb  vmovaps xmm15, [rsp+0xE0]
00007f7c123d2dc4  add rsp, 0xF0
00007f7c123d2dcb  pop r11
00007f7c123d2dcd  pop r10
00007f7c123d2dcf  pop r9
00007f7c123d2dd1  pop r8
00007f7c123d2dd3  pop rsi
00007f7c123d2dd4  pop rdi
00007f7c123d2dd5  pop rdx
00007f7c123d2dd6  pop rcx
00007f7c123d2dd7  pop rax
00007f7c123d2dd8  add rsp, 0x08
00007f7c123d2ddc  jmp 0x00007F7C123CFE15
00007f7c123d2de1  sub rsp, 0x08
00007f7c123d2de5  push rax
00007f7c123d2de6  push rcx
00007f7c123d2de7  push rdx
00007f7c123d2de8  push rdi
00007f7c123d2de9  push rsi
00007f7c123d2dea  push r8
00007f7c123d2dec  push r9
00007f7c123d2dee  push r10
00007f7c123d2df0  push r11
00007f7c123d2df2  sub rsp, 0xF0
00007f7c123d2df9  vmovaps [rsp], xmm0
00007f7c123d2dfe  vmovaps [rsp+0x10], xmm2
00007f7c123d2e04  vmovaps [rsp+0x20], xmm3
00007f7c123d2e0a  vmovaps [rsp+0x30], xmm4
00007f7c123d2e10  vmovaps [rsp+0x40], xmm5
00007f7c123d2e16  vmovaps [rsp+0x50], xmm6
00007f7c123d2e1c  vmovaps [rsp+0x60], xmm7
00007f7c123d2e22  vmovaps [rsp+0x70], xmm8
00007f7c123d2e28  vmovaps [rsp+0x80], xmm9
00007f7c123d2e31  vmovaps [rsp+0x90], xmm10
00007f7c123d2e3a  vmovaps [rsp+0xA0], xmm11
00007f7c123d2e43  vmovaps [rsp+0xB0], xmm12
00007f7c123d2e4c  vmovaps [rsp+0xC0], xmm13
00007f7c123d2e55  vmovaps [rsp+0xD0], xmm14
00007f7c123d2e5e  vmovaps [rsp+0xE0], xmm15
00007f7c123d2e67  sub rsp, 0x30
00007f7c123d2e6b  movaps [rsp], xmm1
00007f7c123d2e6f  movaps [rsp+0x10], xmm15
00007f7c123d2e75  movaps [rsp+0x20], xmm10
00007f7c123d2e7b  lea rdi, [rsp]
00007f7c123d2e7f  mov esi, 0x00
00007f7c123d2e84  mov rax, 0x5E723D793530
00007f7c123d2e8e  call rax
00007f7c123d2e90  movaps xmm1, [rsp]
00007f7c123d2e94  add rsp, 0x30
00007f7c123d2e98  vmovaps xmm0, [rsp]
00007f7c123d2e9d  vmovaps xmm2, [rsp+0x10]
00007f7c123d2ea3  vmovaps xmm3, [rsp+0x20]
00007f7c123d2ea9  vmovaps xmm4, [rsp+0x30]
00007f7c123d2eaf  vmovaps xmm5, [rsp+0x40]
00007f7c123d2eb5  vmovaps xmm6, [rsp+0x50]
00007f7c123d2ebb  vmovaps xmm7, [rsp+0x60]
00007f7c123d2ec1  vmovaps xmm8, [rsp+0x70]
00007f7c123d2ec7  vmovaps xmm9, [rsp+0x80]
00007f7c123d2ed0  vmovaps xmm10, [rsp+0x90]
00007f7c123d2ed9  vmovaps xmm11, [rsp+0xA0]
00007f7c123d2ee2  vmovaps xmm12, [rsp+0xB0]
00007f7c123d2eeb  vmovaps xmm13, [rsp+0xC0]
00007f7c123d2ef4  vmovaps xmm14, [rsp+0xD0]
00007f7c123d2efd  vmovaps xmm15, [rsp+0xE0]
00007f7c123d2f06  add rsp, 0xF0
00007f7c123d2f0d  pop r11
00007f7c123d2f0f  pop r10
00007f7c123d2f11  pop r9
00007f7c123d2f13  pop r8
00007f7c123d2f15  pop rsi
00007f7c123d2f16  pop rdi
00007f7c123d2f17  pop rdx
00007f7c123d2f18  pop rcx
00007f7c123d2f19  pop rax
00007f7c123d2f1a  add rsp, 0x08
00007f7c123d2f1e  jmp 0x00007F7C123CFE34
00007f7c123d2f23  sub rsp, 0x08
00007f7c123d2f27  push rax
00007f7c123d2f28  push rcx
00007f7c123d2f29  push rdx
00007f7c123d2f2a  push rdi
00007f7c123d2f2b  push rsi
00007f7c123d2f2c  push r8
00007f7c123d2f2e  push r9
00007f7c123d2f30  push r10
00007f7c123d2f32  push r11
00007f7c123d2f34  sub rsp, 0xF0
00007f7c123d2f3b  vmovaps [rsp], xmm0
00007f7c123d2f40  vmovaps [rsp+0x10], xmm1
00007f7c123d2f46  vmovaps [rsp+0x20], xmm2
00007f7c123d2f4c  vmovaps [rsp+0x30], xmm3
00007f7c123d2f52  vmovaps [rsp+0x40], xmm4
00007f7c123d2f58  vmovaps [rsp+0x50], xmm5
00007f7c123d2f5e  vmovaps [rsp+0x60], xmm6
00007f7c123d2f64  vmovaps [rsp+0x70], xmm7
00007f7c123d2f6a  vmovaps [rsp+0x80], xmm8
00007f7c123d2f73  vmovaps [rsp+0x90], xmm9
00007f7c123d2f7c  vmovaps [rsp+0xA0], xmm10
00007f7c123d2f85  vmovaps [rsp+0xB0], xmm11
00007f7c123d2f8e  vmovaps [rsp+0xC0], xmm12
00007f7c123d2f97  vmovaps [rsp+0xD0], xmm13
00007f7c123d2fa0  vmovaps [rsp+0xE0], xmm14
00007f7c123d2fa9  sub rsp, 0x30
00007f7c123d2fad  movaps [rsp], xmm15
00007f7c123d2fb2  movaps [rsp+0x10], xmm10
00007f7c123d2fb8  movaps [rsp+0x20], xmm11
00007f7c123d2fbe  lea rdi, [rsp]
00007f7c123d2fc2  mov esi, 0x00
00007f7c123d2fc7  mov rax, 0x5E723D793530
00007f7c123d2fd1  call rax
00007f7c123d2fd3  movaps xmm15, [rsp]
00007f7c123d2fd8  add rsp, 0x30
00007f7c123d2fdc  vmovaps xmm0, [rsp]
00007f7c123d2fe1  vmovaps xmm1, [rsp+0x10]
00007f7c123d2fe7  vmovaps xmm2, [rsp+0x20]
00007f7c123d2fed  vmovaps xmm3, [rsp+0x30]
00007f7c123d2ff3  vmovaps xmm4, [rsp+0x40]
00007f7c123d2ff9  vmovaps xmm5, [rsp+0x50]
00007f7c123d2fff  vmovaps xmm6, [rsp+0x60]
00007f7c123d3005  vmovaps xmm7, [rsp+0x70]
00007f7c123d300b  vmovaps xmm8, [rsp+0x80]
00007f7c123d3014  vmovaps xmm9, [rsp+0x90]
00007f7c123d301d  vmovaps xmm10, [rsp+0xA0]
00007f7c123d3026  vmovaps xmm11, [rsp+0xB0]
00007f7c123d302f  vmovaps xmm12, [rsp+0xC0]
00007f7c123d3038  vmovaps xmm13, [rsp+0xD0]
00007f7c123d3041  vmovaps xmm14, [rsp+0xE0]
00007f7c123d304a  add rsp, 0xF0
00007f7c123d3051  pop r11
00007f7c123d3053  pop r10
00007f7c123d3055  pop r9
00007f7c123d3057  pop r8
00007f7c123d3059  pop rsi
00007f7c123d305a  pop rdi
00007f7c123d305b  pop rdx
00007f7c123d305c  pop rcx
00007f7c123d305d  pop rax
00007f7c123d305e  add rsp, 0x08
00007f7c123d3062  jmp 0x00007F7C123CFE57
00007f7c123d3067  sub rsp, 0x08
00007f7c123d306b  push rax
00007f7c123d306c  push rcx
00007f7c123d306d  push rdx
00007f7c123d306e  push rdi
00007f7c123d306f  push rsi
00007f7c123d3070  push r8
00007f7c123d3072  push r9
00007f7c123d3074  push r10
00007f7c123d3076  push r11
00007f7c123d3078  sub rsp, 0xF0
00007f7c123d307f  vmovaps [rsp], xmm0
00007f7c123d3084  vmovaps [rsp+0x10], xmm1
00007f7c123d308a  vmovaps [rsp+0x20], xmm2
00007f7c123d3090  vmovaps [rsp+0x30], xmm3
00007f7c123d3096  vmovaps [rsp+0x40], xmm4
00007f7c123d309c  vmovaps [rsp+0x50], xmm5
00007f7c123d30a2  vmovaps [rsp+0x60], xmm6
00007f7c123d30a8  vmovaps [rsp+0x70], xmm7
00007f7c123d30ae  vmovaps [rsp+0x80], xmm8
00007f7c123d30b7  vmovaps [rsp+0x90], xmm9
00007f7c123d30c0  vmovaps [rsp+0xA0], xmm11
00007f7c123d30c9  vmovaps [rsp+0xB0], xmm12
00007f7c123d30d2  vmovaps [rsp+0xC0], xmm13
00007f7c123d30db  vmovaps [rsp+0xD0], xmm14
00007f7c123d30e4  vmovaps [rsp+0xE0], xmm15
00007f7c123d30ed  sub rsp, 0x30
00007f7c123d30f1  movaps [rsp], xmm10
00007f7c123d30f6  movaps [rsp+0x10], xmm12
00007f7c123d30fc  movaps [rsp+0x20], xmm11
00007f7c123d3102  lea rdi, [rsp]
00007f7c123d3106  mov esi, 0x00
00007f7c123d310b  mov rax, 0x5E723D793530
00007f7c123d3115  call rax
00007f7c123d3117  movaps xmm10, [rsp]
00007f7c123d311c  add rsp, 0x30
00007f7c123d3120  vmovaps xmm0, [rsp]
00007f7c123d3125  vmovaps xmm1, [rsp+0x10]
00007f7c123d312b  vmovaps xmm2, [rsp+0x20]
00007f7c123d3131  vmovaps xmm3, [rsp+0x30]
00007f7c123d3137  vmovaps xmm4, [rsp+0x40]
00007f7c123d313d  vmovaps xmm5, [rsp+0x50]
00007f7c123d3143  vmovaps xmm6, [rsp+0x60]
00007f7c123d3149  vmovaps xmm7, [rsp+0x70]
00007f7c123d314f  vmovaps xmm8, [rsp+0x80]
00007f7c123d3158  vmovaps xmm9, [rsp+0x90]
00007f7c123d3161  vmovaps xmm11, [rsp+0xA0]
00007f7c123d316a  vmovaps xmm12, [rsp+0xB0]
00007f7c123d3173  vmovaps xmm13, [rsp+0xC0]
00007f7c123d317c  vmovaps xmm14, [rsp+0xD0]
00007f7c123d3185  vmovaps xmm15, [rsp+0xE0]
00007f7c123d318e  add rsp, 0xF0
00007f7c123d3195  pop r11
00007f7c123d3197  pop r10
00007f7c123d3199  pop r9
00007f7c123d319b  pop r8
00007f7c123d319d  pop rsi
00007f7c123d319e  pop rdi
00007f7c123d319f  pop rdx
00007f7c123d31a0  pop rcx
00007f7c123d31a1  pop rax
00007f7c123d31a2  add rsp, 0x08
00007f7c123d31a6  jmp 0x00007F7C123CFE80
00007f7c123d31ab  sub rsp, 0x08
00007f7c123d31af  push rax
00007f7c123d31b0  push rcx
00007f7c123d31b1  push rdx
00007f7c123d31b2  push rdi
00007f7c123d31b3  push rsi
00007f7c123d31b4  push r8
00007f7c123d31b6  push r9
00007f7c123d31b8  push r10
00007f7c123d31ba  push r11
00007f7c123d31bc  sub rsp, 0xF0
00007f7c123d31c3  vmovaps [rsp], xmm0
00007f7c123d31c8  vmovaps [rsp+0x10], xmm1
00007f7c123d31ce  vmovaps [rsp+0x20], xmm2
00007f7c123d31d4  vmovaps [rsp+0x30], xmm3
00007f7c123d31da  vmovaps [rsp+0x40], xmm4
00007f7c123d31e0  vmovaps [rsp+0x50], xmm5
00007f7c123d31e6  vmovaps [rsp+0x60], xmm6
00007f7c123d31ec  vmovaps [rsp+0x70], xmm7
00007f7c123d31f2  vmovaps [rsp+0x80], xmm8
00007f7c123d31fb  vmovaps [rsp+0x90], xmm9
00007f7c123d3204  vmovaps [rsp+0xA0], xmm10
00007f7c123d320d  vmovaps [rsp+0xB0], xmm12
00007f7c123d3216  vmovaps [rsp+0xC0], xmm13
00007f7c123d321f  vmovaps [rsp+0xD0], xmm14
00007f7c123d3228  vmovaps [rsp+0xE0], xmm15
00007f7c123d3231  sub rsp, 0x30
00007f7c123d3235  movaps [rsp], xmm11
00007f7c123d323a  movaps [rsp+0x10], xmm2
00007f7c123d323f  movaps [rsp+0x20], xmm12
00007f7c123d3245  lea rdi, [rsp]
00007f7c123d3249  mov esi, 0x00
00007f7c123d324e  mov rax, 0x5E723D793530
00007f7c123d3258  call rax
00007f7c123d325a  movaps xmm11, [rsp]
00007f7c123d325f  add rsp, 0x30
00007f7c123d3263  vmovaps xmm0, [rsp]
00007f7c123d3268  vmovaps xmm1, [rsp+0x10]
00007f7c123d326e  vmovaps xmm2, [rsp+0x20]
00007f7c123d3274  vmovaps xmm3, [rsp+0x30]
00007f7c123d327a  vmovaps xmm4, [rsp+0x40]
00007f7c123d3280  vmovaps xmm5, [rsp+0x50]
00007f7c123d3286  vmovaps xmm6, [rsp+0x60]
00007f7c123d328c  vmovaps xmm7, [rsp+0x70]
00007f7c123d3292  vmovaps xmm8, [rsp+0x80]
00007f7c123d329b  vmovaps xmm9, [rsp+0x90]
00007f7c123d32a4  vmovaps xmm10, [rsp+0xA0]
00007f7c123d32ad  vmovaps xmm12, [rsp+0xB0]
00007f7c123d32b6  vmovaps xmm13, [rsp+0xC0]
00007f7c123d32bf  vmovaps xmm14, [rsp+0xD0]
00007f7c123d32c8  vmovaps xmm15, [rsp+0xE0]
00007f7c123d32d1  add rsp, 0xF0
00007f7c123d32d8  pop r11
00007f7c123d32da  pop r10
00007f7c123d32dc  pop r9
00007f7c123d32de  pop r8
00007f7c123d32e0  pop rsi
00007f7c123d32e1  pop rdi
00007f7c123d32e2  pop rdx
00007f7c123d32e3  pop rcx
00007f7c123d32e4  pop rax
00007f7c123d32e5  add rsp, 0x08
00007f7c123d32e9  jmp 0x00007F7C123CFEB8
00007f7c123d32ee  sub rsp, 0x08
00007f7c123d32f2  push rax
00007f7c123d32f3  push rcx
00007f7c123d32f4  push rdx
00007f7c123d32f5  push rdi
00007f7c123d32f6  push rsi
00007f7c123d32f7  push r8
00007f7c123d32f9  push r9
00007f7c123d32fb  push r10
00007f7c123d32fd  push r11
00007f7c123d32ff  sub rsp, 0xF0
00007f7c123d3306  vmovaps [rsp], xmm0
00007f7c123d330b  vmovaps [rsp+0x10], xmm2
00007f7c123d3311  vmovaps [rsp+0x20], xmm3
00007f7c123d3317  vmovaps [rsp+0x30], xmm4
00007f7c123d331d  vmovaps [rsp+0x40], xmm5
00007f7c123d3323  vmovaps [rsp+0x50], xmm6
00007f7c123d3329  vmovaps [rsp+0x60], xmm7
00007f7c123d332f  vmovaps [rsp+0x70], xmm8
00007f7c123d3335  vmovaps [rsp+0x80], xmm9
00007f7c123d333e  vmovaps [rsp+0x90], xmm10
00007f7c123d3347  vmovaps [rsp+0xA0], xmm11
00007f7c123d3350  vmovaps [rsp+0xB0], xmm12
00007f7c123d3359  vmovaps [rsp+0xC0], xmm13
00007f7c123d3362  vmovaps [rsp+0xD0], xmm14
00007f7c123d336b  vmovaps [rsp+0xE0], xmm15
00007f7c123d3374  sub rsp, 0x30
00007f7c123d3378  movaps [rsp], xmm1
00007f7c123d337c  movaps [rsp+0x10], xmm14
00007f7c123d3382  movaps [rsp+0x20], xmm6
00007f7c123d3387  lea rdi, [rsp]
00007f7c123d338b  mov esi, 0x00
00007f7c123d3390  mov rax, 0x5E723D793530
00007f7c123d339a  call rax
00007f7c123d339c  movaps xmm1, [rsp]
00007f7c123d33a0  add rsp, 0x30
00007f7c123d33a4  vmovaps xmm0, [rsp]
00007f7c123d33a9  vmovaps xmm2, [rsp+0x10]
00007f7c123d33af  vmovaps xmm3, [rsp+0x20]
00007f7c123d33b5  vmovaps xmm4, [rsp+0x30]
00007f7c123d33bb  vmovaps xmm5, [rsp+0x40]
00007f7c123d33c1  vmovaps xmm6, [rsp+0x50]
00007f7c123d33c7  vmovaps xmm7, [rsp+0x60]
00007f7c123d33cd  vmovaps xmm8, [rsp+0x70]
00007f7c123d33d3  vmovaps xmm9, [rsp+0x80]
00007f7c123d33dc  vmovaps xmm10, [rsp+0x90]
00007f7c123d33e5  vmovaps xmm11, [rsp+0xA0]
00007f7c123d33ee  vmovaps xmm12, [rsp+0xB0]
00007f7c123d33f7  vmovaps xmm13, [rsp+0xC0]
00007f7c123d3400  vmovaps xmm14, [rsp+0xD0]
00007f7c123d3409  vmovaps xmm15, [rsp+0xE0]
00007f7c123d3412  add rsp, 0xF0
00007f7c123d3419  pop r11
00007f7c123d341b  pop r10
00007f7c123d341d  pop r9
00007f7c123d341f  pop r8
00007f7c123d3421  pop rsi
00007f7c123d3422  pop rdi
00007f7c123d3423  pop rdx
00007f7c123d3424  pop rcx
00007f7c123d3425  pop rax
00007f7c123d3426  add rsp, 0x08
00007f7c123d342a  jmp 0x00007F7C123CFED1
00007f7c123d342f  sub rsp, 0x08
00007f7c123d3433  push rax
00007f7c123d3434  push rcx
00007f7c123d3435  push rdx
00007f7c123d3436  push rdi
00007f7c123d3437  push rsi
00007f7c123d3438  push r8
00007f7c123d343a  push r9
00007f7c123d343c  push r10
00007f7c123d343e  push r11
00007f7c123d3440  sub rsp, 0xF0
00007f7c123d3447  vmovaps [rsp], xmm0
00007f7c123d344c  vmovaps [rsp+0x10], xmm1
00007f7c123d3452  vmovaps [rsp+0x20], xmm2
00007f7c123d3458  vmovaps [rsp+0x30], xmm3
00007f7c123d345e  vmovaps [rsp+0x40], xmm4
00007f7c123d3464  vmovaps [rsp+0x50], xmm5
00007f7c123d346a  vmovaps [rsp+0x60], xmm6
00007f7c123d3470  vmovaps [rsp+0x70], xmm7
00007f7c123d3476  vmovaps [rsp+0x80], xmm8
00007f7c123d347f  vmovaps [rsp+0x90], xmm9
00007f7c123d3488  vmovaps [rsp+0xA0], xmm10
00007f7c123d3491  vmovaps [rsp+0xB0], xmm11
00007f7c123d349a  vmovaps [rsp+0xC0], xmm12
00007f7c123d34a3  vmovaps [rsp+0xD0], xmm13
00007f7c123d34ac  vmovaps [rsp+0xE0], xmm15
00007f7c123d34b5  sub rsp, 0x30
00007f7c123d34b9  movaps [rsp], xmm14
00007f7c123d34be  movaps [rsp+0x10], xmm12
00007f7c123d34c4  movaps [rsp+0x20], xmm5
00007f7c123d34c9  lea rdi, [rsp]
00007f7c123d34cd  mov esi, 0x00
00007f7c123d34d2  mov rax, 0x5E723D793530
00007f7c123d34dc  call rax
00007f7c123d34de  movaps xmm14, [rsp]
00007f7c123d34e3  add rsp, 0x30
00007f7c123d34e7  vmovaps xmm0, [rsp]
00007f7c123d34ec  vmovaps xmm1, [rsp+0x10]
00007f7c123d34f2  vmovaps xmm2, [rsp+0x20]
00007f7c123d34f8  vmovaps xmm3, [rsp+0x30]
00007f7c123d34fe  vmovaps xmm4, [rsp+0x40]
00007f7c123d3504  vmovaps xmm5, [rsp+0x50]
00007f7c123d350a  vmovaps xmm6, [rsp+0x60]
00007f7c123d3510  vmovaps xmm7, [rsp+0x70]
00007f7c123d3516  vmovaps xmm8, [rsp+0x80]
00007f7c123d351f  vmovaps xmm9, [rsp+0x90]
00007f7c123d3528  vmovaps xmm10, [rsp+0xA0]
00007f7c123d3531  vmovaps xmm11, [rsp+0xB0]
00007f7c123d353a  vmovaps xmm12, [rsp+0xC0]
00007f7c123d3543  vmovaps xmm13, [rsp+0xD0]
00007f7c123d354c  vmovaps xmm15, [rsp+0xE0]
00007f7c123d3555  add rsp, 0xF0
00007f7c123d355c  pop r11
00007f7c123d355e  pop r10
00007f7c123d3560  pop r9
00007f7c123d3562  pop r8
00007f7c123d3564  pop rsi
00007f7c123d3565  pop rdi
00007f7c123d3566  pop rdx
00007f7c123d3567  pop rcx
00007f7c123d3568  pop rax
00007f7c123d3569  add rsp, 0x08
00007f7c123d356d  jmp 0x00007F7C123CFEF1
00007f7c123d3572  sub rsp, 0x08
00007f7c123d3576  push rax
00007f7c123d3577  push rcx
00007f7c123d3578  push rdx
00007f7c123d3579  push rdi
00007f7c123d357a  push rsi
00007f7c123d357b  push r8
00007f7c123d357d  push r9
00007f7c123d357f  push r10
00007f7c123d3581  push r11
00007f7c123d3583  sub rsp, 0xF0
00007f7c123d358a  vmovaps [rsp], xmm0
00007f7c123d358f  vmovaps [rsp+0x10], xmm1
00007f7c123d3595  vmovaps [rsp+0x20], xmm2
00007f7c123d359b  vmovaps [rsp+0x30], xmm3
00007f7c123d35a1  vmovaps [rsp+0x40], xmm4
00007f7c123d35a7  vmovaps [rsp+0x50], xmm5
00007f7c123d35ad  vmovaps [rsp+0x60], xmm7
00007f7c123d35b3  vmovaps [rsp+0x70], xmm8
00007f7c123d35b9  vmovaps [rsp+0x80], xmm9
00007f7c123d35c2  vmovaps [rsp+0x90], xmm10
00007f7c123d35cb  vmovaps [rsp+0xA0], xmm11
00007f7c123d35d4  vmovaps [rsp+0xB0], xmm12
00007f7c123d35dd  vmovaps [rsp+0xC0], xmm13
00007f7c123d35e6  vmovaps [rsp+0xD0], xmm14
00007f7c123d35ef  vmovaps [rsp+0xE0], xmm15
00007f7c123d35f8  sub rsp, 0x30
00007f7c123d35fc  movaps [rsp], xmm6
00007f7c123d3600  movaps [rsp+0x10], xmm9
00007f7c123d3606  movaps [rsp+0x20], xmm12
00007f7c123d360c  lea rdi, [rsp]
00007f7c123d3610  mov esi, 0x00
00007f7c123d3615  mov rax, 0x5E723D793530
00007f7c123d361f  call rax
00007f7c123d3621  movaps xmm6, [rsp]
00007f7c123d3625  add rsp, 0x30
00007f7c123d3629  vmovaps xmm0, [rsp]
00007f7c123d362e  vmovaps xmm1, [rsp+0x10]
00007f7c123d3634  vmovaps xmm2, [rsp+0x20]
00007f7c123d363a  vmovaps xmm3, [rsp+0x30]
00007f7c123d3640  vmovaps xmm4, [rsp+0x40]
00007f7c123d3646  vmovaps xmm5, [rsp+0x50]
00007f7c123d364c  vmovaps xmm7, [rsp+0x60]
00007f7c123d3652  vmovaps xmm8, [rsp+0x70]
00007f7c123d3658  vmovaps xmm9, [rsp+0x80]
00007f7c123d3661  vmovaps xmm10, [rsp+0x90]
00007f7c123d366a  vmovaps xmm11, [rsp+0xA0]
00007f7c123d3673  vmovaps xmm12, [rsp+0xB0]
00007f7c123d367c  vmovaps xmm13, [rsp+0xC0]
00007f7c123d3685  vmovaps xmm14, [rsp+0xD0]
00007f7c123d368e  vmovaps xmm15, [rsp+0xE0]
00007f7c123d3697  add rsp, 0xF0
00007f7c123d369e  pop r11
00007f7c123d36a0  pop r10
00007f7c123d36a2  pop r9
00007f7c123d36a4  pop r8
00007f7c123d36a6  pop rsi
00007f7c123d36a7  pop rdi
00007f7c123d36a8  pop rdx
00007f7c123d36a9  pop rcx
00007f7c123d36aa  pop rax
00007f7c123d36ab  add rsp, 0x08
00007f7c123d36af  jmp 0x00007F7C123CFF19
00007f7c123d36b4  sub rsp, 0x08
00007f7c123d36b8  push rax
00007f7c123d36b9  push rcx
00007f7c123d36ba  push rdx
00007f7c123d36bb  push rdi
00007f7c123d36bc  push rsi
00007f7c123d36bd  push r8
00007f7c123d36bf  push r9
00007f7c123d36c1  push r10
00007f7c123d36c3  push r11
00007f7c123d36c5  sub rsp, 0xF0
00007f7c123d36cc  vmovaps [rsp], xmm0
00007f7c123d36d1  vmovaps [rsp+0x10], xmm1
00007f7c123d36d7  vmovaps [rsp+0x20], xmm2
00007f7c123d36dd  vmovaps [rsp+0x30], xmm3
00007f7c123d36e3  vmovaps [rsp+0x40], xmm4
00007f7c123d36e9  vmovaps [rsp+0x50], xmm5
00007f7c123d36ef  vmovaps [rsp+0x60], xmm6
00007f7c123d36f5  vmovaps [rsp+0x70], xmm7
00007f7c123d36fb  vmovaps [rsp+0x80], xmm8
00007f7c123d3704  vmovaps [rsp+0x90], xmm9
00007f7c123d370d  vmovaps [rsp+0xA0], xmm10
00007f7c123d3716  vmovaps [rsp+0xB0], xmm11
00007f7c123d371f  vmovaps [rsp+0xC0], xmm13
00007f7c123d3728  vmovaps [rsp+0xD0], xmm14
00007f7c123d3731  vmovaps [rsp+0xE0], xmm15
00007f7c123d373a  sub rsp, 0x30
00007f7c123d373e  movaps [rsp], xmm12
00007f7c123d3743  movaps [rsp+0x10], xmm15
00007f7c123d3749  movaps [rsp+0x20], xmm13
00007f7c123d374f  lea rdi, [rsp]
00007f7c123d3753  mov esi, 0x00
00007f7c123d3758  mov rax, 0x5E723D793530
00007f7c123d3762  call rax
00007f7c123d3764  movaps xmm12, [rsp]
00007f7c123d3769  add rsp, 0x30
00007f7c123d376d  vmovaps xmm0, [rsp]
00007f7c123d3772  vmovaps xmm1, [rsp+0x10]
00007f7c123d3778  vmovaps xmm2, [rsp+0x20]
00007f7c123d377e  vmovaps xmm3, [rsp+0x30]
00007f7c123d3784  vmovaps xmm4, [rsp+0x40]
00007f7c123d378a  vmovaps xmm5, [rsp+0x50]
00007f7c123d3790  vmovaps xmm6, [rsp+0x60]
00007f7c123d3796  vmovaps xmm7, [rsp+0x70]
00007f7c123d379c  vmovaps xmm8, [rsp+0x80]
00007f7c123d37a5  vmovaps xmm9, [rsp+0x90]
00007f7c123d37ae  vmovaps xmm10, [rsp+0xA0]
00007f7c123d37b7  vmovaps xmm11, [rsp+0xB0]
00007f7c123d37c0  vmovaps xmm13, [rsp+0xC0]
00007f7c123d37c9  vmovaps xmm14, [rsp+0xD0]
00007f7c123d37d2  vmovaps xmm15, [rsp+0xE0]
00007f7c123d37db  add rsp, 0xF0
00007f7c123d37e2  pop r11
00007f7c123d37e4  pop r10
00007f7c123d37e6  pop r9
00007f7c123d37e8  pop r8
00007f7c123d37ea  pop rsi
00007f7c123d37eb  pop rdi
00007f7c123d37ec  pop rdx
00007f7c123d37ed  pop rcx
00007f7c123d37ee  pop rax
00007f7c123d37ef  add rsp, 0x08
00007f7c123d37f3  jmp 0x00007F7C123CFF34
00007f7c123d37f8  sub rsp, 0x08
00007f7c123d37fc  push rax
00007f7c123d37fd  push rcx
00007f7c123d37fe  push rdx
00007f7c123d37ff  push rdi
00007f7c123d3800  push rsi
00007f7c123d3801  push r8
00007f7c123d3803  push r9
00007f7c123d3805  push r10
00007f7c123d3807  push r11
00007f7c123d3809  sub rsp, 0xF0
00007f7c123d3810  vmovaps [rsp], xmm0
00007f7c123d3815  vmovaps [rsp+0x10], xmm1
00007f7c123d381b  vmovaps [rsp+0x20], xmm2
00007f7c123d3821  vmovaps [rsp+0x30], xmm3
00007f7c123d3827  vmovaps [rsp+0x40], xmm4
00007f7c123d382d  vmovaps [rsp+0x50], xmm5
00007f7c123d3833  vmovaps [rsp+0x60], xmm6
00007f7c123d3839  vmovaps [rsp+0x70], xmm7
00007f7c123d383f  vmovaps [rsp+0x80], xmm8
00007f7c123d3848  vmovaps [rsp+0x90], xmm9
00007f7c123d3851  vmovaps [rsp+0xA0], xmm10
00007f7c123d385a  vmovaps [rsp+0xB0], xmm11
00007f7c123d3863  vmovaps [rsp+0xC0], xmm12
00007f7c123d386c  vmovaps [rsp+0xD0], xmm13
00007f7c123d3875  vmovaps [rsp+0xE0], xmm14
00007f7c123d387e  sub rsp, 0x30
00007f7c123d3882  movaps [rsp], xmm15
00007f7c123d3887  movaps [rsp+0x10], xmm13
00007f7c123d388d  movaps [rsp+0x20], xmm10
00007f7c123d3893  lea rdi, [rsp]
00007f7c123d3897  mov esi, 0x00
00007f7c123d389c  mov rax, 0x5E723D793530
00007f7c123d38a6  call rax
00007f7c123d38a8  movaps xmm15, [rsp]
00007f7c123d38ad  add rsp, 0x30
00007f7c123d38b1  vmovaps xmm0, [rsp]
00007f7c123d38b6  vmovaps xmm1, [rsp+0x10]
00007f7c123d38bc  vmovaps xmm2, [rsp+0x20]
00007f7c123d38c2  vmovaps xmm3, [rsp+0x30]
00007f7c123d38c8  vmovaps xmm4, [rsp+0x40]
00007f7c123d38ce  vmovaps xmm5, [rsp+0x50]
00007f7c123d38d4  vmovaps xmm6, [rsp+0x60]
00007f7c123d38da  vmovaps xmm7, [rsp+0x70]
00007f7c123d38e0  vmovaps xmm8, [rsp+0x80]
00007f7c123d38e9  vmovaps xmm9, [rsp+0x90]
00007f7c123d38f2  vmovaps xmm10, [rsp+0xA0]
00007f7c123d38fb  vmovaps xmm11, [rsp+0xB0]
00007f7c123d3904  vmovaps xmm12, [rsp+0xC0]
00007f7c123d390d  vmovaps xmm13, [rsp+0xD0]
00007f7c123d3916  vmovaps xmm14, [rsp+0xE0]
00007f7c123d391f  add rsp, 0xF0
00007f7c123d3926  pop r11
00007f7c123d3928  pop r10
00007f7c123d392a  pop r9
00007f7c123d392c  pop r8
00007f7c123d392e  pop rsi
00007f7c123d392f  pop rdi
00007f7c123d3930  pop rdx
00007f7c123d3931  pop rcx
00007f7c123d3932  pop rax
00007f7c123d3933  add rsp, 0x08
00007f7c123d3937  jmp 0x00007F7C123CFF55
00007f7c123d393c  call 0x00007F7C1220C260
00007f7c123d3941  jmp 0x00007F7C123CFFB0
00007f7c123d3946  sub rsp, 0x08
00007f7c123d394a  push rax
00007f7c123d394b  push rcx
00007f7c123d394c  push rdx
00007f7c123d394d  push rdi
00007f7c123d394e  push rsi
00007f7c123d394f  push r8
00007f7c123d3951  push r9
00007f7c123d3953  push r10
00007f7c123d3955  push r11
00007f7c123d3957  sub rsp, 0xF0
00007f7c123d395e  vmovaps [rsp], xmm0
00007f7c123d3963  vmovaps [rsp+0x10], xmm1
00007f7c123d3969  vmovaps [rsp+0x20], xmm2
00007f7c123d396f  vmovaps [rsp+0x30], xmm3
00007f7c123d3975  vmovaps [rsp+0x40], xmm4
00007f7c123d397b  vmovaps [rsp+0x50], xmm5
00007f7c123d3981  vmovaps [rsp+0x60], xmm6
00007f7c123d3987  vmovaps [rsp+0x70], xmm7
00007f7c123d398d  vmovaps [rsp+0x80], xmm8
00007f7c123d3996  vmovaps [rsp+0x90], xmm10
00007f7c123d399f  vmovaps [rsp+0xA0], xmm11
00007f7c123d39a8  vmovaps [rsp+0xB0], xmm12
00007f7c123d39b1  vmovaps [rsp+0xC0], xmm13
00007f7c123d39ba  vmovaps [rsp+0xD0], xmm14
00007f7c123d39c3  vmovaps [rsp+0xE0], xmm15
00007f7c123d39cc  sub rsp, 0x30
00007f7c123d39d0  movaps [rsp], xmm9
00007f7c123d39d5  movaps [rsp+0x10], xmm8
00007f7c123d39db  movaps [rsp+0x20], xmm10
00007f7c123d39e1  lea rdi, [rsp]
00007f7c123d39e5  mov esi, 0x00
00007f7c123d39ea  mov rax, 0x5E723D793530
00007f7c123d39f4  call rax
00007f7c123d39f6  movaps xmm9, [rsp]
00007f7c123d39fb  add rsp, 0x30
00007f7c123d39ff  vmovaps xmm0, [rsp]
00007f7c123d3a04  vmovaps xmm1, [rsp+0x10]
00007f7c123d3a0a  vmovaps xmm2, [rsp+0x20]
00007f7c123d3a10  vmovaps xmm3, [rsp+0x30]
00007f7c123d3a16  vmovaps xmm4, [rsp+0x40]
00007f7c123d3a1c  vmovaps xmm5, [rsp+0x50]
00007f7c123d3a22  vmovaps xmm6, [rsp+0x60]
00007f7c123d3a28  vmovaps xmm7, [rsp+0x70]
00007f7c123d3a2e  vmovaps xmm8, [rsp+0x80]
00007f7c123d3a37  vmovaps xmm10, [rsp+0x90]
00007f7c123d3a40  vmovaps xmm11, [rsp+0xA0]
00007f7c123d3a49  vmovaps xmm12, [rsp+0xB0]
00007f7c123d3a52  vmovaps xmm13, [rsp+0xC0]
00007f7c123d3a5b  vmovaps xmm14, [rsp+0xD0]
00007f7c123d3a64  vmovaps xmm15, [rsp+0xE0]
00007f7c123d3a6d  add rsp, 0xF0
00007f7c123d3a74  pop r11
00007f7c123d3a76  pop r10
00007f7c123d3a78  pop r9
00007f7c123d3a7a  pop r8
00007f7c123d3a7c  pop rsi
00007f7c123d3a7d  pop rdi
00007f7c123d3a7e  pop rdx
00007f7c123d3a7f  pop rcx
00007f7c123d3a80  pop rax
00007f7c123d3a81  add rsp, 0x08
00007f7c123d3a85  jmp 0x00007F7C123CFFE1
00007f7c123d3a8a  sub rsp, 0x08
00007f7c123d3a8e  push rax
00007f7c123d3a8f  push rcx
00007f7c123d3a90  push rdx
00007f7c123d3a91  push rdi
00007f7c123d3a92  push rsi
00007f7c123d3a93  push r8
00007f7c123d3a95  push r9
00007f7c123d3a97  push r10
00007f7c123d3a99  push r11
00007f7c123d3a9b  sub rsp, 0xF0
00007f7c123d3aa2  vmovaps [rsp], xmm0
00007f7c123d3aa7  vmovaps [rsp+0x10], xmm1
00007f7c123d3aad  vmovaps [rsp+0x20], xmm2
00007f7c123d3ab3  vmovaps [rsp+0x30], xmm3
00007f7c123d3ab9  vmovaps [rsp+0x40], xmm4
00007f7c123d3abf  vmovaps [rsp+0x50], xmm5
00007f7c123d3ac5  vmovaps [rsp+0x60], xmm6
00007f7c123d3acb  vmovaps [rsp+0x70], xmm7
00007f7c123d3ad1  vmovaps [rsp+0x80], xmm8
00007f7c123d3ada  vmovaps [rsp+0x90], xmm9
00007f7c123d3ae3  vmovaps [rsp+0xA0], xmm11
00007f7c123d3aec  vmovaps [rsp+0xB0], xmm12
00007f7c123d3af5  vmovaps [rsp+0xC0], xmm13
00007f7c123d3afe  vmovaps [rsp+0xD0], xmm14
00007f7c123d3b07  vmovaps [rsp+0xE0], xmm15
00007f7c123d3b10  sub rsp, 0x30
00007f7c123d3b14  movaps [rsp], xmm10
00007f7c123d3b19  movaps [rsp+0x10], xmm1
00007f7c123d3b1e  movaps [rsp+0x20], xmm11
00007f7c123d3b24  lea rdi, [rsp]
00007f7c123d3b28  mov esi, 0x00
00007f7c123d3b2d  mov rax, 0x5E723D793530
00007f7c123d3b37  call rax
00007f7c123d3b39  movaps xmm10, [rsp]
00007f7c123d3b3e  add rsp, 0x30
00007f7c123d3b42  vmovaps xmm0, [rsp]
00007f7c123d3b47  vmovaps xmm1, [rsp+0x10]
00007f7c123d3b4d  vmovaps xmm2, [rsp+0x20]
00007f7c123d3b53  vmovaps xmm3, [rsp+0x30]
00007f7c123d3b59  vmovaps xmm4, [rsp+0x40]
00007f7c123d3b5f  vmovaps xmm5, [rsp+0x50]
00007f7c123d3b65  vmovaps xmm6, [rsp+0x60]
00007f7c123d3b6b  vmovaps xmm7, [rsp+0x70]
00007f7c123d3b71  vmovaps xmm8, [rsp+0x80]
00007f7c123d3b7a  vmovaps xmm9, [rsp+0x90]
00007f7c123d3b83  vmovaps xmm11, [rsp+0xA0]
00007f7c123d3b8c  vmovaps xmm12, [rsp+0xB0]
00007f7c123d3b95  vmovaps xmm13, [rsp+0xC0]
00007f7c123d3b9e  vmovaps xmm14, [rsp+0xD0]
00007f7c123d3ba7  vmovaps xmm15, [rsp+0xE0]
00007f7c123d3bb0  add rsp, 0xF0
00007f7c123d3bb7  pop r11
00007f7c123d3bb9  pop r10
00007f7c123d3bbb  pop r9
00007f7c123d3bbd  pop r8
00007f7c123d3bbf  pop rsi
00007f7c123d3bc0  pop rdi
00007f7c123d3bc1  pop rdx
00007f7c123d3bc2  pop rcx
00007f7c123d3bc3  pop rax
00007f7c123d3bc4  add rsp, 0x08
00007f7c123d3bc8  jmp 0x00007F7C123CFFFC
00007f7c123d3bcd  sub rsp, 0x08
00007f7c123d3bd1  push rax
00007f7c123d3bd2  push rcx
00007f7c123d3bd3  push rdx
00007f7c123d3bd4  push rdi
00007f7c123d3bd5  push rsi
00007f7c123d3bd6  push r8
00007f7c123d3bd8  push r9
00007f7c123d3bda  push r10
00007f7c123d3bdc  push r11
00007f7c123d3bde  sub rsp, 0xF0
00007f7c123d3be5  vmovaps [rsp], xmm0
00007f7c123d3bea  vmovaps [rsp+0x10], xmm2
00007f7c123d3bf0  vmovaps [rsp+0x20], xmm3
00007f7c123d3bf6  vmovaps [rsp+0x30], xmm4
00007f7c123d3bfc  vmovaps [rsp+0x40], xmm5
00007f7c123d3c02  vmovaps [rsp+0x50], xmm6
00007f7c123d3c08  vmovaps [rsp+0x60], xmm7
00007f7c123d3c0e  vmovaps [rsp+0x70], xmm8
00007f7c123d3c14  vmovaps [rsp+0x80], xmm9
00007f7c123d3c1d  vmovaps [rsp+0x90], xmm10
00007f7c123d3c26  vmovaps [rsp+0xA0], xmm11
00007f7c123d3c2f  vmovaps [rsp+0xB0], xmm12
00007f7c123d3c38  vmovaps [rsp+0xC0], xmm13
00007f7c123d3c41  vmovaps [rsp+0xD0], xmm14
00007f7c123d3c4a  vmovaps [rsp+0xE0], xmm15
00007f7c123d3c53  sub rsp, 0x30
00007f7c123d3c57  movaps [rsp], xmm1
00007f7c123d3c5b  movaps [rsp+0x10], xmm14
00007f7c123d3c61  movaps [rsp+0x20], xmm6
00007f7c123d3c66  lea rdi, [rsp]
00007f7c123d3c6a  mov esi, 0x00
00007f7c123d3c6f  mov rax, 0x5E723D793530
00007f7c123d3c79  call rax
00007f7c123d3c7b  movaps xmm1, [rsp]
00007f7c123d3c7f  add rsp, 0x30
00007f7c123d3c83  vmovaps xmm0, [rsp]
00007f7c123d3c88  vmovaps xmm2, [rsp+0x10]
00007f7c123d3c8e  vmovaps xmm3, [rsp+0x20]
00007f7c123d3c94  vmovaps xmm4, [rsp+0x30]
00007f7c123d3c9a  vmovaps xmm5, [rsp+0x40]
00007f7c123d3ca0  vmovaps xmm6, [rsp+0x50]
00007f7c123d3ca6  vmovaps xmm7, [rsp+0x60]
00007f7c123d3cac  vmovaps xmm8, [rsp+0x70]
00007f7c123d3cb2  vmovaps xmm9, [rsp+0x80]
00007f7c123d3cbb  vmovaps xmm10, [rsp+0x90]
00007f7c123d3cc4  vmovaps xmm11, [rsp+0xA0]
00007f7c123d3ccd  vmovaps xmm12, [rsp+0xB0]
00007f7c123d3cd6  vmovaps xmm13, [rsp+0xC0]
00007f7c123d3cdf  vmovaps xmm14, [rsp+0xD0]
00007f7c123d3ce8  vmovaps xmm15, [rsp+0xE0]
00007f7c123d3cf1  add rsp, 0xF0
00007f7c123d3cf8  pop r11
00007f7c123d3cfa  pop r10
00007f7c123d3cfc  pop r9
00007f7c123d3cfe  pop r8
00007f7c123d3d00  pop rsi
00007f7c123d3d01  pop rdi
00007f7c123d3d02  pop rdx
00007f7c123d3d03  pop rcx
00007f7c123d3d04  pop rax
00007f7c123d3d05  add rsp, 0x08
00007f7c123d3d09  jmp 0x00007F7C123D0015
00007f7c123d3d0e  sub rsp, 0x08
00007f7c123d3d12  push rax
00007f7c123d3d13  push rcx
00007f7c123d3d14  push rdx
00007f7c123d3d15  push rdi
00007f7c123d3d16  push rsi
00007f7c123d3d17  push r8
00007f7c123d3d19  push r9
00007f7c123d3d1b  push r10
00007f7c123d3d1d  push r11
00007f7c123d3d1f  sub rsp, 0xF0
00007f7c123d3d26  vmovaps [rsp], xmm0
00007f7c123d3d2b  vmovaps [rsp+0x10], xmm1
00007f7c123d3d31  vmovaps [rsp+0x20], xmm2
00007f7c123d3d37  vmovaps [rsp+0x30], xmm3
00007f7c123d3d3d  vmovaps [rsp+0x40], xmm4
00007f7c123d3d43  vmovaps [rsp+0x50], xmm5
00007f7c123d3d49  vmovaps [rsp+0x60], xmm6
00007f7c123d3d4f  vmovaps [rsp+0x70], xmm7
00007f7c123d3d55  vmovaps [rsp+0x80], xmm8
00007f7c123d3d5e  vmovaps [rsp+0x90], xmm9
00007f7c123d3d67  vmovaps [rsp+0xA0], xmm10
00007f7c123d3d70  vmovaps [rsp+0xB0], xmm12
00007f7c123d3d79  vmovaps [rsp+0xC0], xmm13
00007f7c123d3d82  vmovaps [rsp+0xD0], xmm14
00007f7c123d3d8b  vmovaps [rsp+0xE0], xmm15
00007f7c123d3d94  sub rsp, 0x30
00007f7c123d3d98  movaps [rsp], xmm11
00007f7c123d3d9d  movaps [rsp+0x10], xmm13
00007f7c123d3da3  movaps [rsp+0x20], xmm14
00007f7c123d3da9  lea rdi, [rsp]
00007f7c123d3dad  mov esi, 0x00
00007f7c123d3db2  mov rax, 0x5E723D793530
00007f7c123d3dbc  call rax
00007f7c123d3dbe  movaps xmm11, [rsp]
00007f7c123d3dc3  add rsp, 0x30
00007f7c123d3dc7  vmovaps xmm0, [rsp]
00007f7c123d3dcc  vmovaps xmm1, [rsp+0x10]
00007f7c123d3dd2  vmovaps xmm2, [rsp+0x20]
00007f7c123d3dd8  vmovaps xmm3, [rsp+0x30]
00007f7c123d3dde  vmovaps xmm4, [rsp+0x40]
00007f7c123d3de4  vmovaps xmm5, [rsp+0x50]
00007f7c123d3dea  vmovaps xmm6, [rsp+0x60]
00007f7c123d3df0  vmovaps xmm7, [rsp+0x70]
00007f7c123d3df6  vmovaps xmm8, [rsp+0x80]
00007f7c123d3dff  vmovaps xmm9, [rsp+0x90]
00007f7c123d3e08  vmovaps xmm10, [rsp+0xA0]
00007f7c123d3e11  vmovaps xmm12, [rsp+0xB0]
00007f7c123d3e1a  vmovaps xmm13, [rsp+0xC0]
00007f7c123d3e23  vmovaps xmm14, [rsp+0xD0]
00007f7c123d3e2c  vmovaps xmm15, [rsp+0xE0]
00007f7c123d3e35  add rsp, 0xF0
00007f7c123d3e3c  pop r11
00007f7c123d3e3e  pop r10
00007f7c123d3e40  pop r9
00007f7c123d3e42  pop r8
00007f7c123d3e44  pop rsi
00007f7c123d3e45  pop rdi
00007f7c123d3e46  pop rdx
00007f7c123d3e47  pop rcx
00007f7c123d3e48  pop rax
00007f7c123d3e49  add rsp, 0x08
00007f7c123d3e4d  jmp 0x00007F7C123D003F
00007f7c123d3e52  sub rsp, 0x08
00007f7c123d3e56  push rax
00007f7c123d3e57  push rcx
00007f7c123d3e58  push rdx
00007f7c123d3e59  push rdi
00007f7c123d3e5a  push rsi
00007f7c123d3e5b  push r8
00007f7c123d3e5d  push r9
00007f7c123d3e5f  push r10
00007f7c123d3e61  push r11
00007f7c123d3e63  sub rsp, 0xF0
00007f7c123d3e6a  vmovaps [rsp], xmm0
00007f7c123d3e6f  vmovaps [rsp+0x10], xmm1
00007f7c123d3e75  vmovaps [rsp+0x20], xmm2
00007f7c123d3e7b  vmovaps [rsp+0x30], xmm3
00007f7c123d3e81  vmovaps [rsp+0x40], xmm4
00007f7c123d3e87  vmovaps [rsp+0x50], xmm5
00007f7c123d3e8d  vmovaps [rsp+0x60], xmm6
00007f7c123d3e93  vmovaps [rsp+0x70], xmm7
00007f7c123d3e99  vmovaps [rsp+0x80], xmm8
00007f7c123d3ea2  vmovaps [rsp+0x90], xmm9
00007f7c123d3eab  vmovaps [rsp+0xA0], xmm10
00007f7c123d3eb4  vmovaps [rsp+0xB0], xmm11
00007f7c123d3ebd  vmovaps [rsp+0xC0], xmm12
00007f7c123d3ec6  vmovaps [rsp+0xD0], xmm14
00007f7c123d3ecf  vmovaps [rsp+0xE0], xmm15
00007f7c123d3ed8  sub rsp, 0x30
00007f7c123d3edc  movaps [rsp], xmm13
00007f7c123d3ee1  movaps [rsp+0x10], xmm8
00007f7c123d3ee7  movaps [rsp+0x20], xmm14
00007f7c123d3eed  lea rdi, [rsp]
00007f7c123d3ef1  mov esi, 0x00
00007f7c123d3ef6  mov rax, 0x5E723D793530
00007f7c123d3f00  call rax
00007f7c123d3f02  movaps xmm13, [rsp]
00007f7c123d3f07  add rsp, 0x30
00007f7c123d3f0b  vmovaps xmm0, [rsp]
00007f7c123d3f10  vmovaps xmm1, [rsp+0x10]
00007f7c123d3f16  vmovaps xmm2, [rsp+0x20]
00007f7c123d3f1c  vmovaps xmm3, [rsp+0x30]
00007f7c123d3f22  vmovaps xmm4, [rsp+0x40]
00007f7c123d3f28  vmovaps xmm5, [rsp+0x50]
00007f7c123d3f2e  vmovaps xmm6, [rsp+0x60]
00007f7c123d3f34  vmovaps xmm7, [rsp+0x70]
00007f7c123d3f3a  vmovaps xmm8, [rsp+0x80]
00007f7c123d3f43  vmovaps xmm9, [rsp+0x90]
00007f7c123d3f4c  vmovaps xmm10, [rsp+0xA0]
00007f7c123d3f55  vmovaps xmm11, [rsp+0xB0]
00007f7c123d3f5e  vmovaps xmm12, [rsp+0xC0]
00007f7c123d3f67  vmovaps xmm14, [rsp+0xD0]
00007f7c123d3f70  vmovaps xmm15, [rsp+0xE0]
00007f7c123d3f79  add rsp, 0xF0
00007f7c123d3f80  pop r11
00007f7c123d3f82  pop r10
00007f7c123d3f84  pop r9
00007f7c123d3f86  pop r8
00007f7c123d3f88  pop rsi
00007f7c123d3f89  pop rdi
00007f7c123d3f8a  pop rdx
00007f7c123d3f8b  pop rcx
00007f7c123d3f8c  pop rax
00007f7c123d3f8d  add rsp, 0x08
00007f7c123d3f91  jmp 0x00007F7C123D006E
00007f7c123d3f96  sub rsp, 0x08
00007f7c123d3f9a  push rax
00007f7c123d3f9b  push rcx
00007f7c123d3f9c  push rdx
00007f7c123d3f9d  push rdi
00007f7c123d3f9e  push rsi
00007f7c123d3f9f  push r8
00007f7c123d3fa1  push r9
00007f7c123d3fa3  push r10
00007f7c123d3fa5  push r11
00007f7c123d3fa7  sub rsp, 0xF0
00007f7c123d3fae  vmovaps [rsp], xmm0
00007f7c123d3fb3  vmovaps [rsp+0x10], xmm1
00007f7c123d3fb9  vmovaps [rsp+0x20], xmm2
00007f7c123d3fbf  vmovaps [rsp+0x30], xmm3
00007f7c123d3fc5  vmovaps [rsp+0x40], xmm4
00007f7c123d3fcb  vmovaps [rsp+0x50], xmm5
00007f7c123d3fd1  vmovaps [rsp+0x60], xmm6
00007f7c123d3fd7  vmovaps [rsp+0x70], xmm7
00007f7c123d3fdd  vmovaps [rsp+0x80], xmm9
00007f7c123d3fe6  vmovaps [rsp+0x90], xmm10
00007f7c123d3fef  vmovaps [rsp+0xA0], xmm11
00007f7c123d3ff8  vmovaps [rsp+0xB0], xmm12
00007f7c123d4001  vmovaps [rsp+0xC0], xmm13
00007f7c123d400a  vmovaps [rsp+0xD0], xmm14
00007f7c123d4013  vmovaps [rsp+0xE0], xmm15
00007f7c123d401c  sub rsp, 0x30
00007f7c123d4020  movaps [rsp], xmm8
00007f7c123d4025  movaps [rsp+0x10], xmm7
00007f7c123d402a  movaps [rsp+0x20], xmm14
00007f7c123d4030  lea rdi, [rsp]
00007f7c123d4034  mov esi, 0x00
00007f7c123d4039  mov rax, 0x5E723D793530
00007f7c123d4043  call rax
00007f7c123d4045  movaps xmm8, [rsp]
00007f7c123d404a  add rsp, 0x30
00007f7c123d404e  vmovaps xmm0, [rsp]
00007f7c123d4053  vmovaps xmm1, [rsp+0x10]
00007f7c123d4059  vmovaps xmm2, [rsp+0x20]
00007f7c123d405f  vmovaps xmm3, [rsp+0x30]
00007f7c123d4065  vmovaps xmm4, [rsp+0x40]
00007f7c123d406b  vmovaps xmm5, [rsp+0x50]
00007f7c123d4071  vmovaps xmm6, [rsp+0x60]
00007f7c123d4077  vmovaps xmm7, [rsp+0x70]
00007f7c123d407d  vmovaps xmm9, [rsp+0x80]
00007f7c123d4086  vmovaps xmm10, [rsp+0x90]
00007f7c123d408f  vmovaps xmm11, [rsp+0xA0]
00007f7c123d4098  vmovaps xmm12, [rsp+0xB0]
00007f7c123d40a1  vmovaps xmm13, [rsp+0xC0]
00007f7c123d40aa  vmovaps xmm14, [rsp+0xD0]
00007f7c123d40b3  vmovaps xmm15, [rsp+0xE0]
00007f7c123d40bc  add rsp, 0xF0
00007f7c123d40c3  pop r11
00007f7c123d40c5  pop r10
00007f7c123d40c7  pop r9
00007f7c123d40c9  pop r8
00007f7c123d40cb  pop rsi
00007f7c123d40cc  pop rdi
00007f7c123d40cd  pop rdx
00007f7c123d40ce  pop rcx
00007f7c123d40cf  pop rax
00007f7c123d40d0  add rsp, 0x08
00007f7c123d40d4  jmp 0x00007F7C123D0094
00007f7c123d40d9  sub rsp, 0x08
00007f7c123d40dd  push rax
00007f7c123d40de  push rcx
00007f7c123d40df  push rdx
00007f7c123d40e0  push rdi
00007f7c123d40e1  push rsi
00007f7c123d40e2  push r8
00007f7c123d40e4  push r9
00007f7c123d40e6  push r10
00007f7c123d40e8  push r11
00007f7c123d40ea  sub rsp, 0xF0
00007f7c123d40f1  vmovaps [rsp], xmm0
00007f7c123d40f6  vmovaps [rsp+0x10], xmm1
00007f7c123d40fc  vmovaps [rsp+0x20], xmm2
00007f7c123d4102  vmovaps [rsp+0x30], xmm3
00007f7c123d4108  vmovaps [rsp+0x40], xmm4
00007f7c123d410e  vmovaps [rsp+0x50], xmm5
00007f7c123d4114  vmovaps [rsp+0x60], xmm6
00007f7c123d411a  vmovaps [rsp+0x70], xmm7
00007f7c123d4120  vmovaps [rsp+0x80], xmm8
00007f7c123d4129  vmovaps [rsp+0x90], xmm9
00007f7c123d4132  vmovaps [rsp+0xA0], xmm10
00007f7c123d413b  vmovaps [rsp+0xB0], xmm11
00007f7c123d4144  vmovaps [rsp+0xC0], xmm12
00007f7c123d414d  vmovaps [rsp+0xD0], xmm13
00007f7c123d4156  vmovaps [rsp+0xE0], xmm15
00007f7c123d415f  sub rsp, 0x30
00007f7c123d4163  movaps [rsp], xmm14
00007f7c123d4168  movaps [rsp+0x10], xmm12
00007f7c123d416e  movaps [rsp+0x20], xmm9
00007f7c123d4174  lea rdi, [rsp]
00007f7c123d4178  mov esi, 0x00
00007f7c123d417d  mov rax, 0x5E723D793530
00007f7c123d4187  call rax
00007f7c123d4189  movaps xmm14, [rsp]
00007f7c123d418e  add rsp, 0x30
00007f7c123d4192  vmovaps xmm0, [rsp]
00007f7c123d4197  vmovaps xmm1, [rsp+0x10]
00007f7c123d419d  vmovaps xmm2, [rsp+0x20]
00007f7c123d41a3  vmovaps xmm3, [rsp+0x30]
00007f7c123d41a9  vmovaps xmm4, [rsp+0x40]
00007f7c123d41af  vmovaps xmm5, [rsp+0x50]
00007f7c123d41b5  vmovaps xmm6, [rsp+0x60]
00007f7c123d41bb  vmovaps xmm7, [rsp+0x70]
00007f7c123d41c1  vmovaps xmm8, [rsp+0x80]
00007f7c123d41ca  vmovaps xmm9, [rsp+0x90]
00007f7c123d41d3  vmovaps xmm10, [rsp+0xA0]
00007f7c123d41dc  vmovaps xmm11, [rsp+0xB0]
00007f7c123d41e5  vmovaps xmm12, [rsp+0xC0]
00007f7c123d41ee  vmovaps xmm13, [rsp+0xD0]
00007f7c123d41f7  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4200  add rsp, 0xF0
00007f7c123d4207  pop r11
00007f7c123d4209  pop r10
00007f7c123d420b  pop r9
00007f7c123d420d  pop r8
00007f7c123d420f  pop rsi
00007f7c123d4210  pop rdi
00007f7c123d4211  pop rdx
00007f7c123d4212  pop rcx
00007f7c123d4213  pop rax
00007f7c123d4214  add rsp, 0x08
00007f7c123d4218  jmp 0x00007F7C123D00AE
00007f7c123d421d  sub rsp, 0x08
00007f7c123d4221  push rax
00007f7c123d4222  push rcx
00007f7c123d4223  push rdx
00007f7c123d4224  push rdi
00007f7c123d4225  push rsi
00007f7c123d4226  push r8
00007f7c123d4228  push r9
00007f7c123d422a  push r10
00007f7c123d422c  push r11
00007f7c123d422e  sub rsp, 0xF0
00007f7c123d4235  vmovaps [rsp], xmm0
00007f7c123d423a  vmovaps [rsp+0x10], xmm1
00007f7c123d4240  vmovaps [rsp+0x20], xmm2
00007f7c123d4246  vmovaps [rsp+0x30], xmm3
00007f7c123d424c  vmovaps [rsp+0x40], xmm4
00007f7c123d4252  vmovaps [rsp+0x50], xmm5
00007f7c123d4258  vmovaps [rsp+0x60], xmm6
00007f7c123d425e  vmovaps [rsp+0x70], xmm7
00007f7c123d4264  vmovaps [rsp+0x80], xmm8
00007f7c123d426d  vmovaps [rsp+0x90], xmm10
00007f7c123d4276  vmovaps [rsp+0xA0], xmm11
00007f7c123d427f  vmovaps [rsp+0xB0], xmm12
00007f7c123d4288  vmovaps [rsp+0xC0], xmm13
00007f7c123d4291  vmovaps [rsp+0xD0], xmm14
00007f7c123d429a  vmovaps [rsp+0xE0], xmm15
00007f7c123d42a3  sub rsp, 0x30
00007f7c123d42a7  movaps [rsp], xmm9
00007f7c123d42ac  movaps [rsp+0x10], xmm7
00007f7c123d42b1  movaps [rsp+0x20], xmm12
00007f7c123d42b7  lea rdi, [rsp]
00007f7c123d42bb  mov esi, 0x00
00007f7c123d42c0  mov rax, 0x5E723D793530
00007f7c123d42ca  call rax
00007f7c123d42cc  movaps xmm9, [rsp]
00007f7c123d42d1  add rsp, 0x30
00007f7c123d42d5  vmovaps xmm0, [rsp]
00007f7c123d42da  vmovaps xmm1, [rsp+0x10]
00007f7c123d42e0  vmovaps xmm2, [rsp+0x20]
00007f7c123d42e6  vmovaps xmm3, [rsp+0x30]
00007f7c123d42ec  vmovaps xmm4, [rsp+0x40]
00007f7c123d42f2  vmovaps xmm5, [rsp+0x50]
00007f7c123d42f8  vmovaps xmm6, [rsp+0x60]
00007f7c123d42fe  vmovaps xmm7, [rsp+0x70]
00007f7c123d4304  vmovaps xmm8, [rsp+0x80]
00007f7c123d430d  vmovaps xmm10, [rsp+0x90]
00007f7c123d4316  vmovaps xmm11, [rsp+0xA0]
00007f7c123d431f  vmovaps xmm12, [rsp+0xB0]
00007f7c123d4328  vmovaps xmm13, [rsp+0xC0]
00007f7c123d4331  vmovaps xmm14, [rsp+0xD0]
00007f7c123d433a  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4343  add rsp, 0xF0
00007f7c123d434a  pop r11
00007f7c123d434c  pop r10
00007f7c123d434e  pop r9
00007f7c123d4350  pop r8
00007f7c123d4352  pop rsi
00007f7c123d4353  pop rdi
00007f7c123d4354  pop rdx
00007f7c123d4355  pop rcx
00007f7c123d4356  pop rax
00007f7c123d4357  add rsp, 0x08
00007f7c123d435b  jmp 0x00007F7C123D00DD
00007f7c123d4360  sub rsp, 0x08
00007f7c123d4364  push rax
00007f7c123d4365  push rcx
00007f7c123d4366  push rdx
00007f7c123d4367  push rdi
00007f7c123d4368  push rsi
00007f7c123d4369  push r8
00007f7c123d436b  push r9
00007f7c123d436d  push r10
00007f7c123d436f  push r11
00007f7c123d4371  sub rsp, 0xF0
00007f7c123d4378  vmovaps [rsp], xmm0
00007f7c123d437d  vmovaps [rsp+0x10], xmm1
00007f7c123d4383  vmovaps [rsp+0x20], xmm2
00007f7c123d4389  vmovaps [rsp+0x30], xmm3
00007f7c123d438f  vmovaps [rsp+0x40], xmm4
00007f7c123d4395  vmovaps [rsp+0x50], xmm5
00007f7c123d439b  vmovaps [rsp+0x60], xmm6
00007f7c123d43a1  vmovaps [rsp+0x70], xmm7
00007f7c123d43a7  vmovaps [rsp+0x80], xmm8
00007f7c123d43b0  vmovaps [rsp+0x90], xmm9
00007f7c123d43b9  vmovaps [rsp+0xA0], xmm10
00007f7c123d43c2  vmovaps [rsp+0xB0], xmm11
00007f7c123d43cb  vmovaps [rsp+0xC0], xmm13
00007f7c123d43d4  vmovaps [rsp+0xD0], xmm14
00007f7c123d43dd  vmovaps [rsp+0xE0], xmm15
00007f7c123d43e6  sub rsp, 0x30
00007f7c123d43ea  movaps [rsp], xmm12
00007f7c123d43ef  movaps [rsp+0x10], xmm15
00007f7c123d43f5  movaps [rsp+0x20], xmm11
00007f7c123d43fb  lea rdi, [rsp]
00007f7c123d43ff  mov esi, 0x00
00007f7c123d4404  mov rax, 0x5E723D793530
00007f7c123d440e  call rax
00007f7c123d4410  movaps xmm12, [rsp]
00007f7c123d4415  add rsp, 0x30
00007f7c123d4419  vmovaps xmm0, [rsp]
00007f7c123d441e  vmovaps xmm1, [rsp+0x10]
00007f7c123d4424  vmovaps xmm2, [rsp+0x20]
00007f7c123d442a  vmovaps xmm3, [rsp+0x30]
00007f7c123d4430  vmovaps xmm4, [rsp+0x40]
00007f7c123d4436  vmovaps xmm5, [rsp+0x50]
00007f7c123d443c  vmovaps xmm6, [rsp+0x60]
00007f7c123d4442  vmovaps xmm7, [rsp+0x70]
00007f7c123d4448  vmovaps xmm8, [rsp+0x80]
00007f7c123d4451  vmovaps xmm9, [rsp+0x90]
00007f7c123d445a  vmovaps xmm10, [rsp+0xA0]
00007f7c123d4463  vmovaps xmm11, [rsp+0xB0]
00007f7c123d446c  vmovaps xmm13, [rsp+0xC0]
00007f7c123d4475  vmovaps xmm14, [rsp+0xD0]
00007f7c123d447e  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4487  add rsp, 0xF0
00007f7c123d448e  pop r11
00007f7c123d4490  pop r10
00007f7c123d4492  pop r9
00007f7c123d4494  pop r8
00007f7c123d4496  pop rsi
00007f7c123d4497  pop rdi
00007f7c123d4498  pop rdx
00007f7c123d4499  pop rcx
00007f7c123d449a  pop rax
00007f7c123d449b  add rsp, 0x08
00007f7c123d449f  jmp 0x00007F7C123D00F7
00007f7c123d44a4  sub rsp, 0x08
00007f7c123d44a8  push rax
00007f7c123d44a9  push rcx
00007f7c123d44aa  push rdx
00007f7c123d44ab  push rdi
00007f7c123d44ac  push rsi
00007f7c123d44ad  push r8
00007f7c123d44af  push r9
00007f7c123d44b1  push r10
00007f7c123d44b3  push r11
00007f7c123d44b5  sub rsp, 0xF0
00007f7c123d44bc  vmovaps [rsp], xmm0
00007f7c123d44c1  vmovaps [rsp+0x10], xmm1
00007f7c123d44c7  vmovaps [rsp+0x20], xmm2
00007f7c123d44cd  vmovaps [rsp+0x30], xmm3
00007f7c123d44d3  vmovaps [rsp+0x40], xmm4
00007f7c123d44d9  vmovaps [rsp+0x50], xmm5
00007f7c123d44df  vmovaps [rsp+0x60], xmm6
00007f7c123d44e5  vmovaps [rsp+0x70], xmm7
00007f7c123d44eb  vmovaps [rsp+0x80], xmm8
00007f7c123d44f4  vmovaps [rsp+0x90], xmm9
00007f7c123d44fd  vmovaps [rsp+0xA0], xmm10
00007f7c123d4506  vmovaps [rsp+0xB0], xmm12
00007f7c123d450f  vmovaps [rsp+0xC0], xmm13
00007f7c123d4518  vmovaps [rsp+0xD0], xmm14
00007f7c123d4521  vmovaps [rsp+0xE0], xmm15
00007f7c123d452a  sub rsp, 0x30
00007f7c123d452e  movaps [rsp], xmm11
00007f7c123d4533  movaps [rsp+0x10], xmm7
00007f7c123d4538  movaps [rsp+0x20], xmm15
00007f7c123d453e  lea rdi, [rsp]
00007f7c123d4542  mov esi, 0x00
00007f7c123d4547  mov rax, 0x5E723D793530
00007f7c123d4551  call rax
00007f7c123d4553  movaps xmm11, [rsp]
00007f7c123d4558  add rsp, 0x30
00007f7c123d455c  vmovaps xmm0, [rsp]
00007f7c123d4561  vmovaps xmm1, [rsp+0x10]
00007f7c123d4567  vmovaps xmm2, [rsp+0x20]
00007f7c123d456d  vmovaps xmm3, [rsp+0x30]
00007f7c123d4573  vmovaps xmm4, [rsp+0x40]
00007f7c123d4579  vmovaps xmm5, [rsp+0x50]
00007f7c123d457f  vmovaps xmm6, [rsp+0x60]
00007f7c123d4585  vmovaps xmm7, [rsp+0x70]
00007f7c123d458b  vmovaps xmm8, [rsp+0x80]
00007f7c123d4594  vmovaps xmm9, [rsp+0x90]
00007f7c123d459d  vmovaps xmm10, [rsp+0xA0]
00007f7c123d45a6  vmovaps xmm12, [rsp+0xB0]
00007f7c123d45af  vmovaps xmm13, [rsp+0xC0]
00007f7c123d45b8  vmovaps xmm14, [rsp+0xD0]
00007f7c123d45c1  vmovaps xmm15, [rsp+0xE0]
00007f7c123d45ca  add rsp, 0xF0
00007f7c123d45d1  pop r11
00007f7c123d45d3  pop r10
00007f7c123d45d5  pop r9
00007f7c123d45d7  pop r8
00007f7c123d45d9  pop rsi
00007f7c123d45da  pop rdi
00007f7c123d45db  pop rdx
00007f7c123d45dc  pop rcx
00007f7c123d45dd  pop rax
00007f7c123d45de  add rsp, 0x08
00007f7c123d45e2  jmp 0x00007F7C123D0123
00007f7c123d45e7  sub rsp, 0x08
00007f7c123d45eb  push rax
00007f7c123d45ec  push rcx
00007f7c123d45ed  push rdx
00007f7c123d45ee  push rdi
00007f7c123d45ef  push rsi
00007f7c123d45f0  push r8
00007f7c123d45f2  push r9
00007f7c123d45f4  push r10
00007f7c123d45f6  push r11
00007f7c123d45f8  sub rsp, 0xF0
00007f7c123d45ff  vmovaps [rsp], xmm0
00007f7c123d4604  vmovaps [rsp+0x10], xmm1
00007f7c123d460a  vmovaps [rsp+0x20], xmm2
00007f7c123d4610  vmovaps [rsp+0x30], xmm3
00007f7c123d4616  vmovaps [rsp+0x40], xmm4
00007f7c123d461c  vmovaps [rsp+0x50], xmm5
00007f7c123d4622  vmovaps [rsp+0x60], xmm6
00007f7c123d4628  vmovaps [rsp+0x70], xmm7
00007f7c123d462e  vmovaps [rsp+0x80], xmm8
00007f7c123d4637  vmovaps [rsp+0x90], xmm9
00007f7c123d4640  vmovaps [rsp+0xA0], xmm10
00007f7c123d4649  vmovaps [rsp+0xB0], xmm11
00007f7c123d4652  vmovaps [rsp+0xC0], xmm12
00007f7c123d465b  vmovaps [rsp+0xD0], xmm13
00007f7c123d4664  vmovaps [rsp+0xE0], xmm14
00007f7c123d466d  sub rsp, 0x30
00007f7c123d4671  movaps [rsp], xmm15
00007f7c123d4676  movaps [rsp+0x10], xmm10
00007f7c123d467c  movaps [rsp+0x20], xmm13
00007f7c123d4682  lea rdi, [rsp]
00007f7c123d4686  mov esi, 0x00
00007f7c123d468b  mov rax, 0x5E723D793530
00007f7c123d4695  call rax
00007f7c123d4697  movaps xmm15, [rsp]
00007f7c123d469c  add rsp, 0x30
00007f7c123d46a0  vmovaps xmm0, [rsp]
00007f7c123d46a5  vmovaps xmm1, [rsp+0x10]
00007f7c123d46ab  vmovaps xmm2, [rsp+0x20]
00007f7c123d46b1  vmovaps xmm3, [rsp+0x30]
00007f7c123d46b7  vmovaps xmm4, [rsp+0x40]
00007f7c123d46bd  vmovaps xmm5, [rsp+0x50]
00007f7c123d46c3  vmovaps xmm6, [rsp+0x60]
00007f7c123d46c9  vmovaps xmm7, [rsp+0x70]
00007f7c123d46cf  vmovaps xmm8, [rsp+0x80]
00007f7c123d46d8  vmovaps xmm9, [rsp+0x90]
00007f7c123d46e1  vmovaps xmm10, [rsp+0xA0]
00007f7c123d46ea  vmovaps xmm11, [rsp+0xB0]
00007f7c123d46f3  vmovaps xmm12, [rsp+0xC0]
00007f7c123d46fc  vmovaps xmm13, [rsp+0xD0]
00007f7c123d4705  vmovaps xmm14, [rsp+0xE0]
00007f7c123d470e  add rsp, 0xF0
00007f7c123d4715  pop r11
00007f7c123d4717  pop r10
00007f7c123d4719  pop r9
00007f7c123d471b  pop r8
00007f7c123d471d  pop rsi
00007f7c123d471e  pop rdi
00007f7c123d471f  pop rdx
00007f7c123d4720  pop rcx
00007f7c123d4721  pop rax
00007f7c123d4722  add rsp, 0x08
00007f7c123d4726  jmp 0x00007F7C123D013D
00007f7c123d472b  sub rsp, 0x08
00007f7c123d472f  push rax
00007f7c123d4730  push rcx
00007f7c123d4731  push rdx
00007f7c123d4732  push rdi
00007f7c123d4733  push rsi
00007f7c123d4734  push r8
00007f7c123d4736  push r9
00007f7c123d4738  push r10
00007f7c123d473a  push r11
00007f7c123d473c  sub rsp, 0xF0
00007f7c123d4743  vmovaps [rsp], xmm0
00007f7c123d4748  vmovaps [rsp+0x10], xmm1
00007f7c123d474e  vmovaps [rsp+0x20], xmm2
00007f7c123d4754  vmovaps [rsp+0x30], xmm3
00007f7c123d475a  vmovaps [rsp+0x40], xmm4
00007f7c123d4760  vmovaps [rsp+0x50], xmm5
00007f7c123d4766  vmovaps [rsp+0x60], xmm6
00007f7c123d476c  vmovaps [rsp+0x70], xmm7
00007f7c123d4772  vmovaps [rsp+0x80], xmm8
00007f7c123d477b  vmovaps [rsp+0x90], xmm9
00007f7c123d4784  vmovaps [rsp+0xA0], xmm11
00007f7c123d478d  vmovaps [rsp+0xB0], xmm12
00007f7c123d4796  vmovaps [rsp+0xC0], xmm13
00007f7c123d479f  vmovaps [rsp+0xD0], xmm14
00007f7c123d47a8  vmovaps [rsp+0xE0], xmm15
00007f7c123d47b1  sub rsp, 0x30
00007f7c123d47b5  movaps [rsp], xmm10
00007f7c123d47ba  movaps [rsp+0x10], xmm7
00007f7c123d47bf  movaps [rsp+0x20], xmm13
00007f7c123d47c5  lea rdi, [rsp]
00007f7c123d47c9  mov esi, 0x00
00007f7c123d47ce  mov rax, 0x5E723D793530
00007f7c123d47d8  call rax
00007f7c123d47da  movaps xmm10, [rsp]
00007f7c123d47df  add rsp, 0x30
00007f7c123d47e3  vmovaps xmm0, [rsp]
00007f7c123d47e8  vmovaps xmm1, [rsp+0x10]
00007f7c123d47ee  vmovaps xmm2, [rsp+0x20]
00007f7c123d47f4  vmovaps xmm3, [rsp+0x30]
00007f7c123d47fa  vmovaps xmm4, [rsp+0x40]
00007f7c123d4800  vmovaps xmm5, [rsp+0x50]
00007f7c123d4806  vmovaps xmm6, [rsp+0x60]
00007f7c123d480c  vmovaps xmm7, [rsp+0x70]
00007f7c123d4812  vmovaps xmm8, [rsp+0x80]
00007f7c123d481b  vmovaps xmm9, [rsp+0x90]
00007f7c123d4824  vmovaps xmm11, [rsp+0xA0]
00007f7c123d482d  vmovaps xmm12, [rsp+0xB0]
00007f7c123d4836  vmovaps xmm13, [rsp+0xC0]
00007f7c123d483f  vmovaps xmm14, [rsp+0xD0]
00007f7c123d4848  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4851  add rsp, 0xF0
00007f7c123d4858  pop r11
00007f7c123d485a  pop r10
00007f7c123d485c  pop r9
00007f7c123d485e  pop r8
00007f7c123d4860  pop rsi
00007f7c123d4861  pop rdi
00007f7c123d4862  pop rdx
00007f7c123d4863  pop rcx
00007f7c123d4864  pop rax
00007f7c123d4865  add rsp, 0x08
00007f7c123d4869  jmp 0x00007F7C123D0169
00007f7c123d486e  sub rsp, 0x08
00007f7c123d4872  push rax
00007f7c123d4873  push rcx
00007f7c123d4874  push rdx
00007f7c123d4875  push rdi
00007f7c123d4876  push rsi
00007f7c123d4877  push r8
00007f7c123d4879  push r9
00007f7c123d487b  push r10
00007f7c123d487d  push r11
00007f7c123d487f  sub rsp, 0xF0
00007f7c123d4886  vmovaps [rsp], xmm0
00007f7c123d488b  vmovaps [rsp+0x10], xmm1
00007f7c123d4891  vmovaps [rsp+0x20], xmm2
00007f7c123d4897  vmovaps [rsp+0x30], xmm3
00007f7c123d489d  vmovaps [rsp+0x40], xmm4
00007f7c123d48a3  vmovaps [rsp+0x50], xmm5
00007f7c123d48a9  vmovaps [rsp+0x60], xmm6
00007f7c123d48af  vmovaps [rsp+0x70], xmm7
00007f7c123d48b5  vmovaps [rsp+0x80], xmm8
00007f7c123d48be  vmovaps [rsp+0x90], xmm9
00007f7c123d48c7  vmovaps [rsp+0xA0], xmm10
00007f7c123d48d0  vmovaps [rsp+0xB0], xmm11
00007f7c123d48d9  vmovaps [rsp+0xC0], xmm12
00007f7c123d48e2  vmovaps [rsp+0xD0], xmm14
00007f7c123d48eb  vmovaps [rsp+0xE0], xmm15
00007f7c123d48f4  sub rsp, 0x30
00007f7c123d48f8  movaps [rsp], xmm13
00007f7c123d48fd  movaps [rsp+0x10], xmm1
00007f7c123d4902  movaps [rsp+0x20], xmm8
00007f7c123d4908  lea rdi, [rsp]
00007f7c123d490c  mov esi, 0x00
00007f7c123d4911  mov rax, 0x5E723D793530
00007f7c123d491b  call rax
00007f7c123d491d  movaps xmm13, [rsp]
00007f7c123d4922  add rsp, 0x30
00007f7c123d4926  vmovaps xmm0, [rsp]
00007f7c123d492b  vmovaps xmm1, [rsp+0x10]
00007f7c123d4931  vmovaps xmm2, [rsp+0x20]
00007f7c123d4937  vmovaps xmm3, [rsp+0x30]
00007f7c123d493d  vmovaps xmm4, [rsp+0x40]
00007f7c123d4943  vmovaps xmm5, [rsp+0x50]
00007f7c123d4949  vmovaps xmm6, [rsp+0x60]
00007f7c123d494f  vmovaps xmm7, [rsp+0x70]
00007f7c123d4955  vmovaps xmm8, [rsp+0x80]
00007f7c123d495e  vmovaps xmm9, [rsp+0x90]
00007f7c123d4967  vmovaps xmm10, [rsp+0xA0]
00007f7c123d4970  vmovaps xmm11, [rsp+0xB0]
00007f7c123d4979  vmovaps xmm12, [rsp+0xC0]
00007f7c123d4982  vmovaps xmm14, [rsp+0xD0]
00007f7c123d498b  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4994  add rsp, 0xF0
00007f7c123d499b  pop r11
00007f7c123d499d  pop r10
00007f7c123d499f  pop r9
00007f7c123d49a1  pop r8
00007f7c123d49a3  pop rsi
00007f7c123d49a4  pop rdi
00007f7c123d49a5  pop rdx
00007f7c123d49a6  pop rcx
00007f7c123d49a7  pop rax
00007f7c123d49a8  add rsp, 0x08
00007f7c123d49ac  jmp 0x00007F7C123D0183
00007f7c123d49b1  call 0x00007F7C121FF430
00007f7c123d49b6  jmp 0x00007F7C123D018D
00007f7c123d49bb  sub rsp, 0x08
00007f7c123d49bf  push rax
00007f7c123d49c0  push rcx
00007f7c123d49c1  push rdx
00007f7c123d49c2  push rdi
00007f7c123d49c3  push rsi
00007f7c123d49c4  push r8
00007f7c123d49c6  push r9
00007f7c123d49c8  push r10
00007f7c123d49ca  push r11
00007f7c123d49cc  sub rsp, 0xF0
00007f7c123d49d3  vmovaps [rsp], xmm0
00007f7c123d49d8  vmovaps [rsp+0x10], xmm1
00007f7c123d49de  vmovaps [rsp+0x20], xmm2
00007f7c123d49e4  vmovaps [rsp+0x30], xmm3
00007f7c123d49ea  vmovaps [rsp+0x40], xmm4
00007f7c123d49f0  vmovaps [rsp+0x50], xmm5
00007f7c123d49f6  vmovaps [rsp+0x60], xmm6
00007f7c123d49fc  vmovaps [rsp+0x70], xmm7
00007f7c123d4a02  vmovaps [rsp+0x80], xmm9
00007f7c123d4a0b  vmovaps [rsp+0x90], xmm10
00007f7c123d4a14  vmovaps [rsp+0xA0], xmm11
00007f7c123d4a1d  vmovaps [rsp+0xB0], xmm12
00007f7c123d4a26  vmovaps [rsp+0xC0], xmm13
00007f7c123d4a2f  vmovaps [rsp+0xD0], xmm14
00007f7c123d4a38  vmovaps [rsp+0xE0], xmm15
00007f7c123d4a41  sub rsp, 0x30
00007f7c123d4a45  movaps [rsp], xmm8
00007f7c123d4a4a  movaps [rsp+0x10], xmm14
00007f7c123d4a50  movaps [rsp+0x20], xmm9
00007f7c123d4a56  lea rdi, [rsp]
00007f7c123d4a5a  mov esi, 0x00
00007f7c123d4a5f  mov rax, 0x5E723D793530
00007f7c123d4a69  call rax
00007f7c123d4a6b  movaps xmm8, [rsp]
00007f7c123d4a70  add rsp, 0x30
00007f7c123d4a74  vmovaps xmm0, [rsp]
00007f7c123d4a79  vmovaps xmm1, [rsp+0x10]
00007f7c123d4a7f  vmovaps xmm2, [rsp+0x20]
00007f7c123d4a85  vmovaps xmm3, [rsp+0x30]
00007f7c123d4a8b  vmovaps xmm4, [rsp+0x40]
00007f7c123d4a91  vmovaps xmm5, [rsp+0x50]
00007f7c123d4a97  vmovaps xmm6, [rsp+0x60]
00007f7c123d4a9d  vmovaps xmm7, [rsp+0x70]
00007f7c123d4aa3  vmovaps xmm9, [rsp+0x80]
00007f7c123d4aac  vmovaps xmm10, [rsp+0x90]
00007f7c123d4ab5  vmovaps xmm11, [rsp+0xA0]
00007f7c123d4abe  vmovaps xmm12, [rsp+0xB0]
00007f7c123d4ac7  vmovaps xmm13, [rsp+0xC0]
00007f7c123d4ad0  vmovaps xmm14, [rsp+0xD0]
00007f7c123d4ad9  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4ae2  add rsp, 0xF0
00007f7c123d4ae9  pop r11
00007f7c123d4aeb  pop r10
00007f7c123d4aed  pop r9
00007f7c123d4aef  pop r8
00007f7c123d4af1  pop rsi
00007f7c123d4af2  pop rdi
00007f7c123d4af3  pop rdx
00007f7c123d4af4  pop rcx
00007f7c123d4af5  pop rax
00007f7c123d4af6  add rsp, 0x08
00007f7c123d4afa  jmp 0x00007F7C123D01AF
00007f7c123d4aff  sub rsp, 0x08
00007f7c123d4b03  push rax
00007f7c123d4b04  push rcx
00007f7c123d4b05  push rdx
00007f7c123d4b06  push rdi
00007f7c123d4b07  push rsi
00007f7c123d4b08  push r8
00007f7c123d4b0a  push r9
00007f7c123d4b0c  push r10
00007f7c123d4b0e  push r11
00007f7c123d4b10  sub rsp, 0xF0
00007f7c123d4b17  vmovaps [rsp], xmm0
00007f7c123d4b1c  vmovaps [rsp+0x10], xmm1
00007f7c123d4b22  vmovaps [rsp+0x20], xmm2
00007f7c123d4b28  vmovaps [rsp+0x30], xmm3
00007f7c123d4b2e  vmovaps [rsp+0x40], xmm4
00007f7c123d4b34  vmovaps [rsp+0x50], xmm5
00007f7c123d4b3a  vmovaps [rsp+0x60], xmm6
00007f7c123d4b40  vmovaps [rsp+0x70], xmm7
00007f7c123d4b46  vmovaps [rsp+0x80], xmm8
00007f7c123d4b4f  vmovaps [rsp+0x90], xmm10
00007f7c123d4b58  vmovaps [rsp+0xA0], xmm11
00007f7c123d4b61  vmovaps [rsp+0xB0], xmm12
00007f7c123d4b6a  vmovaps [rsp+0xC0], xmm13
00007f7c123d4b73  vmovaps [rsp+0xD0], xmm14
00007f7c123d4b7c  vmovaps [rsp+0xE0], xmm15
00007f7c123d4b85  sub rsp, 0x30
00007f7c123d4b89  movaps [rsp], xmm9
00007f7c123d4b8e  movaps [rsp+0x10], xmm1
00007f7c123d4b93  movaps [rsp+0x20], xmm14
00007f7c123d4b99  lea rdi, [rsp]
00007f7c123d4b9d  mov esi, 0x00
00007f7c123d4ba2  mov rax, 0x5E723D793530
00007f7c123d4bac  call rax
00007f7c123d4bae  movaps xmm9, [rsp]
00007f7c123d4bb3  add rsp, 0x30
00007f7c123d4bb7  vmovaps xmm0, [rsp]
00007f7c123d4bbc  vmovaps xmm1, [rsp+0x10]
00007f7c123d4bc2  vmovaps xmm2, [rsp+0x20]
00007f7c123d4bc8  vmovaps xmm3, [rsp+0x30]
00007f7c123d4bce  vmovaps xmm4, [rsp+0x40]
00007f7c123d4bd4  vmovaps xmm5, [rsp+0x50]
00007f7c123d4bda  vmovaps xmm6, [rsp+0x60]
00007f7c123d4be0  vmovaps xmm7, [rsp+0x70]
00007f7c123d4be6  vmovaps xmm8, [rsp+0x80]
00007f7c123d4bef  vmovaps xmm10, [rsp+0x90]
00007f7c123d4bf8  vmovaps xmm11, [rsp+0xA0]
00007f7c123d4c01  vmovaps xmm12, [rsp+0xB0]
00007f7c123d4c0a  vmovaps xmm13, [rsp+0xC0]
00007f7c123d4c13  vmovaps xmm14, [rsp+0xD0]
00007f7c123d4c1c  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4c25  add rsp, 0xF0
00007f7c123d4c2c  pop r11
00007f7c123d4c2e  pop r10
00007f7c123d4c30  pop r9
00007f7c123d4c32  pop r8
00007f7c123d4c34  pop rsi
00007f7c123d4c35  pop rdi
00007f7c123d4c36  pop rdx
00007f7c123d4c37  pop rcx
00007f7c123d4c38  pop rax
00007f7c123d4c39  add rsp, 0x08
00007f7c123d4c3d  jmp 0x00007F7C123D01DD
00007f7c123d4c42  sub rsp, 0x08
00007f7c123d4c46  push rax
00007f7c123d4c47  push rcx
00007f7c123d4c48  push rdx
00007f7c123d4c49  push rdi
00007f7c123d4c4a  push rsi
00007f7c123d4c4b  push r8
00007f7c123d4c4d  push r9
00007f7c123d4c4f  push r10
00007f7c123d4c51  push r11
00007f7c123d4c53  sub rsp, 0xF0
00007f7c123d4c5a  vmovaps [rsp], xmm0
00007f7c123d4c5f  vmovaps [rsp+0x10], xmm1
00007f7c123d4c65  vmovaps [rsp+0x20], xmm2
00007f7c123d4c6b  vmovaps [rsp+0x30], xmm3
00007f7c123d4c71  vmovaps [rsp+0x40], xmm4
00007f7c123d4c77  vmovaps [rsp+0x50], xmm5
00007f7c123d4c7d  vmovaps [rsp+0x60], xmm6
00007f7c123d4c83  vmovaps [rsp+0x70], xmm7
00007f7c123d4c89  vmovaps [rsp+0x80], xmm8
00007f7c123d4c92  vmovaps [rsp+0x90], xmm9
00007f7c123d4c9b  vmovaps [rsp+0xA0], xmm10
00007f7c123d4ca4  vmovaps [rsp+0xB0], xmm11
00007f7c123d4cad  vmovaps [rsp+0xC0], xmm12
00007f7c123d4cb6  vmovaps [rsp+0xD0], xmm13
00007f7c123d4cbf  vmovaps [rsp+0xE0], xmm15
00007f7c123d4cc8  sub rsp, 0x30
00007f7c123d4ccc  movaps [rsp], xmm14
00007f7c123d4cd1  movaps [rsp+0x10], xmm4
00007f7c123d4cd6  movaps [rsp+0x20], xmm1
00007f7c123d4cdb  lea rdi, [rsp]
00007f7c123d4cdf  mov esi, 0x00
00007f7c123d4ce4  mov rax, 0x5E723D793530
00007f7c123d4cee  call rax
00007f7c123d4cf0  movaps xmm14, [rsp]
00007f7c123d4cf5  add rsp, 0x30
00007f7c123d4cf9  vmovaps xmm0, [rsp]
00007f7c123d4cfe  vmovaps xmm1, [rsp+0x10]
00007f7c123d4d04  vmovaps xmm2, [rsp+0x20]
00007f7c123d4d0a  vmovaps xmm3, [rsp+0x30]
00007f7c123d4d10  vmovaps xmm4, [rsp+0x40]
00007f7c123d4d16  vmovaps xmm5, [rsp+0x50]
00007f7c123d4d1c  vmovaps xmm6, [rsp+0x60]
00007f7c123d4d22  vmovaps xmm7, [rsp+0x70]
00007f7c123d4d28  vmovaps xmm8, [rsp+0x80]
00007f7c123d4d31  vmovaps xmm9, [rsp+0x90]
00007f7c123d4d3a  vmovaps xmm10, [rsp+0xA0]
00007f7c123d4d43  vmovaps xmm11, [rsp+0xB0]
00007f7c123d4d4c  vmovaps xmm12, [rsp+0xC0]
00007f7c123d4d55  vmovaps xmm13, [rsp+0xD0]
00007f7c123d4d5e  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4d67  add rsp, 0xF0
00007f7c123d4d6e  pop r11
00007f7c123d4d70  pop r10
00007f7c123d4d72  pop r9
00007f7c123d4d74  pop r8
00007f7c123d4d76  pop rsi
00007f7c123d4d77  pop rdi
00007f7c123d4d78  pop rdx
00007f7c123d4d79  pop rcx
00007f7c123d4d7a  pop rax
00007f7c123d4d7b  add rsp, 0x08
00007f7c123d4d7f  jmp 0x00007F7C123D0203
00007f7c123d4d84  sub rsp, 0x08
00007f7c123d4d88  push rax
00007f7c123d4d89  push rcx
00007f7c123d4d8a  push rdx
00007f7c123d4d8b  push rdi
00007f7c123d4d8c  push rsi
00007f7c123d4d8d  push r8
00007f7c123d4d8f  push r9
00007f7c123d4d91  push r10
00007f7c123d4d93  push r11
00007f7c123d4d95  sub rsp, 0xF0
00007f7c123d4d9c  vmovaps [rsp], xmm0
00007f7c123d4da1  vmovaps [rsp+0x10], xmm2
00007f7c123d4da7  vmovaps [rsp+0x20], xmm3
00007f7c123d4dad  vmovaps [rsp+0x30], xmm4
00007f7c123d4db3  vmovaps [rsp+0x40], xmm5
00007f7c123d4db9  vmovaps [rsp+0x50], xmm6
00007f7c123d4dbf  vmovaps [rsp+0x60], xmm7
00007f7c123d4dc5  vmovaps [rsp+0x70], xmm8
00007f7c123d4dcb  vmovaps [rsp+0x80], xmm9
00007f7c123d4dd4  vmovaps [rsp+0x90], xmm10
00007f7c123d4ddd  vmovaps [rsp+0xA0], xmm11
00007f7c123d4de6  vmovaps [rsp+0xB0], xmm12
00007f7c123d4def  vmovaps [rsp+0xC0], xmm13
00007f7c123d4df8  vmovaps [rsp+0xD0], xmm14
00007f7c123d4e01  vmovaps [rsp+0xE0], xmm15
00007f7c123d4e0a  sub rsp, 0x30
00007f7c123d4e0e  movaps [rsp], xmm1
00007f7c123d4e12  movaps [rsp+0x10], xmm12
00007f7c123d4e18  movaps [rsp+0x20], xmm11
00007f7c123d4e1e  lea rdi, [rsp]
00007f7c123d4e22  mov esi, 0x00
00007f7c123d4e27  mov rax, 0x5E723D793530
00007f7c123d4e31  call rax
00007f7c123d4e33  movaps xmm1, [rsp]
00007f7c123d4e37  add rsp, 0x30
00007f7c123d4e3b  vmovaps xmm0, [rsp]
00007f7c123d4e40  vmovaps xmm2, [rsp+0x10]
00007f7c123d4e46  vmovaps xmm3, [rsp+0x20]
00007f7c123d4e4c  vmovaps xmm4, [rsp+0x30]
00007f7c123d4e52  vmovaps xmm5, [rsp+0x40]
00007f7c123d4e58  vmovaps xmm6, [rsp+0x50]
00007f7c123d4e5e  vmovaps xmm7, [rsp+0x60]
00007f7c123d4e64  vmovaps xmm8, [rsp+0x70]
00007f7c123d4e6a  vmovaps xmm9, [rsp+0x80]
00007f7c123d4e73  vmovaps xmm10, [rsp+0x90]
00007f7c123d4e7c  vmovaps xmm11, [rsp+0xA0]
00007f7c123d4e85  vmovaps xmm12, [rsp+0xB0]
00007f7c123d4e8e  vmovaps xmm13, [rsp+0xC0]
00007f7c123d4e97  vmovaps xmm14, [rsp+0xD0]
00007f7c123d4ea0  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4ea9  add rsp, 0xF0
00007f7c123d4eb0  pop r11
00007f7c123d4eb2  pop r10
00007f7c123d4eb4  pop r9
00007f7c123d4eb6  pop r8
00007f7c123d4eb8  pop rsi
00007f7c123d4eb9  pop rdi
00007f7c123d4eba  pop rdx
00007f7c123d4ebb  pop rcx
00007f7c123d4ebc  pop rax
00007f7c123d4ebd  add rsp, 0x08
00007f7c123d4ec1  jmp 0x00007F7C123D0224
00007f7c123d4ec6  call 0x00007F7C122E20A0
00007f7c123d4ecb  jmp 0x00007F7C123D0232
00007f7c123d4ed0  call 0x00007F7C12209D70
00007f7c123d4ed5  jmp 0x00007F7C123D023C
00007f7c123d4eda  sub rsp, 0x08
00007f7c123d4ede  push rax
00007f7c123d4edf  push rcx
00007f7c123d4ee0  push rdx
00007f7c123d4ee1  push rdi
00007f7c123d4ee2  push rsi
00007f7c123d4ee3  push r8
00007f7c123d4ee5  push r9
00007f7c123d4ee7  push r10
00007f7c123d4ee9  push r11
00007f7c123d4eeb  sub rsp, 0xF0
00007f7c123d4ef2  vmovaps [rsp], xmm0
00007f7c123d4ef7  vmovaps [rsp+0x10], xmm1
00007f7c123d4efd  vmovaps [rsp+0x20], xmm2
00007f7c123d4f03  vmovaps [rsp+0x30], xmm3
00007f7c123d4f09  vmovaps [rsp+0x40], xmm4
00007f7c123d4f0f  vmovaps [rsp+0x50], xmm5
00007f7c123d4f15  vmovaps [rsp+0x60], xmm6
00007f7c123d4f1b  vmovaps [rsp+0x70], xmm8
00007f7c123d4f21  vmovaps [rsp+0x80], xmm9
00007f7c123d4f2a  vmovaps [rsp+0x90], xmm10
00007f7c123d4f33  vmovaps [rsp+0xA0], xmm11
00007f7c123d4f3c  vmovaps [rsp+0xB0], xmm12
00007f7c123d4f45  vmovaps [rsp+0xC0], xmm13
00007f7c123d4f4e  vmovaps [rsp+0xD0], xmm14
00007f7c123d4f57  vmovaps [rsp+0xE0], xmm15
00007f7c123d4f60  sub rsp, 0x30
00007f7c123d4f64  movaps [rsp], xmm7
00007f7c123d4f68  movaps [rsp+0x10], xmm15
00007f7c123d4f6e  movaps [rsp+0x20], xmm10
00007f7c123d4f74  lea rdi, [rsp]
00007f7c123d4f78  mov esi, 0x00
00007f7c123d4f7d  mov rax, 0x5E723D793530
00007f7c123d4f87  call rax
00007f7c123d4f89  movaps xmm7, [rsp]
00007f7c123d4f8d  add rsp, 0x30
00007f7c123d4f91  vmovaps xmm0, [rsp]
00007f7c123d4f96  vmovaps xmm1, [rsp+0x10]
00007f7c123d4f9c  vmovaps xmm2, [rsp+0x20]
00007f7c123d4fa2  vmovaps xmm3, [rsp+0x30]
00007f7c123d4fa8  vmovaps xmm4, [rsp+0x40]
00007f7c123d4fae  vmovaps xmm5, [rsp+0x50]
00007f7c123d4fb4  vmovaps xmm6, [rsp+0x60]
00007f7c123d4fba  vmovaps xmm8, [rsp+0x70]
00007f7c123d4fc0  vmovaps xmm9, [rsp+0x80]
00007f7c123d4fc9  vmovaps xmm10, [rsp+0x90]
00007f7c123d4fd2  vmovaps xmm11, [rsp+0xA0]
00007f7c123d4fdb  vmovaps xmm12, [rsp+0xB0]
00007f7c123d4fe4  vmovaps xmm13, [rsp+0xC0]
00007f7c123d4fed  vmovaps xmm14, [rsp+0xD0]
00007f7c123d4ff6  vmovaps xmm15, [rsp+0xE0]
00007f7c123d4fff  add rsp, 0xF0
00007f7c123d5006  pop r11
00007f7c123d5008  pop r10
00007f7c123d500a  pop r9
00007f7c123d500c  pop r8
00007f7c123d500e  pop rsi
00007f7c123d500f  pop rdi
00007f7c123d5010  pop rdx
00007f7c123d5011  pop rcx
00007f7c123d5012  pop rax
00007f7c123d5013  add rsp, 0x08
00007f7c123d5017  jmp 0x00007F7C123D025D
00007f7c123d501c  sub rsp, 0x08
00007f7c123d5020  push rax
00007f7c123d5021  push rcx
00007f7c123d5022  push rdx
00007f7c123d5023  push rdi
00007f7c123d5024  push rsi
00007f7c123d5025  push r8
00007f7c123d5027  push r9
00007f7c123d5029  push r10
00007f7c123d502b  push r11
00007f7c123d502d  sub rsp, 0xF0
00007f7c123d5034  vmovaps [rsp], xmm0
00007f7c123d5039  vmovaps [rsp+0x10], xmm1
00007f7c123d503f  vmovaps [rsp+0x20], xmm2
00007f7c123d5045  vmovaps [rsp+0x30], xmm3
00007f7c123d504b  vmovaps [rsp+0x40], xmm4
00007f7c123d5051  vmovaps [rsp+0x50], xmm5
00007f7c123d5057  vmovaps [rsp+0x60], xmm6
00007f7c123d505d  vmovaps [rsp+0x70], xmm7
00007f7c123d5063  vmovaps [rsp+0x80], xmm8
00007f7c123d506c  vmovaps [rsp+0x90], xmm9
00007f7c123d5075  vmovaps [rsp+0xA0], xmm11
00007f7c123d507e  vmovaps [rsp+0xB0], xmm12
00007f7c123d5087  vmovaps [rsp+0xC0], xmm13
00007f7c123d5090  vmovaps [rsp+0xD0], xmm14
00007f7c123d5099  vmovaps [rsp+0xE0], xmm15
00007f7c123d50a2  sub rsp, 0x30
00007f7c123d50a6  movaps [rsp], xmm10
00007f7c123d50ab  movaps [rsp+0x10], xmm11
00007f7c123d50b1  movaps [rsp+0x20], xmm15
00007f7c123d50b7  lea rdi, [rsp]
00007f7c123d50bb  mov esi, 0x00
00007f7c123d50c0  mov rax, 0x5E723D793530
00007f7c123d50ca  call rax
00007f7c123d50cc  movaps xmm10, [rsp]
00007f7c123d50d1  add rsp, 0x30
00007f7c123d50d5  vmovaps xmm0, [rsp]
00007f7c123d50da  vmovaps xmm1, [rsp+0x10]
00007f7c123d50e0  vmovaps xmm2, [rsp+0x20]
00007f7c123d50e6  vmovaps xmm3, [rsp+0x30]
00007f7c123d50ec  vmovaps xmm4, [rsp+0x40]
00007f7c123d50f2  vmovaps xmm5, [rsp+0x50]
00007f7c123d50f8  vmovaps xmm6, [rsp+0x60]
00007f7c123d50fe  vmovaps xmm7, [rsp+0x70]
00007f7c123d5104  vmovaps xmm8, [rsp+0x80]
00007f7c123d510d  vmovaps xmm9, [rsp+0x90]
00007f7c123d5116  vmovaps xmm11, [rsp+0xA0]
00007f7c123d511f  vmovaps xmm12, [rsp+0xB0]
00007f7c123d5128  vmovaps xmm13, [rsp+0xC0]
00007f7c123d5131  vmovaps xmm14, [rsp+0xD0]
00007f7c123d513a  vmovaps xmm15, [rsp+0xE0]
00007f7c123d5143  add rsp, 0xF0
00007f7c123d514a  pop r11
00007f7c123d514c  pop r10
00007f7c123d514e  pop r9
00007f7c123d5150  pop r8
00007f7c123d5152  pop rsi
00007f7c123d5153  pop rdi
00007f7c123d5154  pop rdx
00007f7c123d5155  pop rcx
00007f7c123d5156  pop rax
00007f7c123d5157  add rsp, 0x08
00007f7c123d515b  jmp 0x00007F7C123D028B
00007f7c123d5160  sub rsp, 0x08
00007f7c123d5164  push rax
00007f7c123d5165  push rcx
00007f7c123d5166  push rdx
00007f7c123d5167  push rdi
00007f7c123d5168  push rsi
00007f7c123d5169  push r8
00007f7c123d516b  push r9
00007f7c123d516d  push r10
00007f7c123d516f  push r11
00007f7c123d5171  sub rsp, 0xF0
00007f7c123d5178  vmovaps [rsp], xmm0
00007f7c123d517d  vmovaps [rsp+0x10], xmm1
00007f7c123d5183  vmovaps [rsp+0x20], xmm2
00007f7c123d5189  vmovaps [rsp+0x30], xmm3
00007f7c123d518f  vmovaps [rsp+0x40], xmm4
00007f7c123d5195  vmovaps [rsp+0x50], xmm5
00007f7c123d519b  vmovaps [rsp+0x60], xmm6
00007f7c123d51a1  vmovaps [rsp+0x70], xmm7
00007f7c123d51a7  vmovaps [rsp+0x80], xmm8
00007f7c123d51b0  vmovaps [rsp+0x90], xmm9
00007f7c123d51b9  vmovaps [rsp+0xA0], xmm10
00007f7c123d51c2  vmovaps [rsp+0xB0], xmm12
00007f7c123d51cb  vmovaps [rsp+0xC0], xmm13
00007f7c123d51d4  vmovaps [rsp+0xD0], xmm14
00007f7c123d51dd  vmovaps [rsp+0xE0], xmm15
00007f7c123d51e6  sub rsp, 0x30
00007f7c123d51ea  movaps [rsp], xmm11
00007f7c123d51ef  movaps [rsp+0x10], xmm12
00007f7c123d51f5  movaps [rsp+0x20], xmm15
00007f7c123d51fb  lea rdi, [rsp]
00007f7c123d51ff  mov esi, 0x00
00007f7c123d5204  mov rax, 0x5E723D793530
00007f7c123d520e  call rax
00007f7c123d5210  movaps xmm11, [rsp]
00007f7c123d5215  add rsp, 0x30
00007f7c123d5219  vmovaps xmm0, [rsp]
00007f7c123d521e  vmovaps xmm1, [rsp+0x10]
00007f7c123d5224  vmovaps xmm2, [rsp+0x20]
00007f7c123d522a  vmovaps xmm3, [rsp+0x30]
00007f7c123d5230  vmovaps xmm4, [rsp+0x40]
00007f7c123d5236  vmovaps xmm5, [rsp+0x50]
00007f7c123d523c  vmovaps xmm6, [rsp+0x60]
00007f7c123d5242  vmovaps xmm7, [rsp+0x70]
00007f7c123d5248  vmovaps xmm8, [rsp+0x80]
00007f7c123d5251  vmovaps xmm9, [rsp+0x90]
00007f7c123d525a  vmovaps xmm10, [rsp+0xA0]
00007f7c123d5263  vmovaps xmm12, [rsp+0xB0]
00007f7c123d526c  vmovaps xmm13, [rsp+0xC0]
00007f7c123d5275  vmovaps xmm14, [rsp+0xD0]
00007f7c123d527e  vmovaps xmm15, [rsp+0xE0]
00007f7c123d5287  add rsp, 0xF0
00007f7c123d528e  pop r11
00007f7c123d5290  pop r10
00007f7c123d5292  pop r9
00007f7c123d5294  pop r8
00007f7c123d5296  pop rsi
00007f7c123d5297  pop rdi
00007f7c123d5298  pop rdx
00007f7c123d5299  pop rcx
00007f7c123d529a  pop rax
00007f7c123d529b  add rsp, 0x08
00007f7c123d529f  jmp 0x00007F7C123D02B9
00007f7c123d52a4  sub rsp, 0x08
00007f7c123d52a8  push rax
00007f7c123d52a9  push rcx
00007f7c123d52aa  push rdx
00007f7c123d52ab  push rdi
00007f7c123d52ac  push rsi
00007f7c123d52ad  push r8
00007f7c123d52af  push r9
00007f7c123d52b1  push r10
00007f7c123d52b3  push r11
00007f7c123d52b5  sub rsp, 0xF0
00007f7c123d52bc  vmovaps [rsp], xmm0
00007f7c123d52c1  vmovaps [rsp+0x10], xmm1
00007f7c123d52c7  vmovaps [rsp+0x20], xmm2
00007f7c123d52cd  vmovaps [rsp+0x30], xmm3
00007f7c123d52d3  vmovaps [rsp+0x40], xmm4
00007f7c123d52d9  vmovaps [rsp+0x50], xmm5
00007f7c123d52df  vmovaps [rsp+0x60], xmm6
00007f7c123d52e5  vmovaps [rsp+0x70], xmm7
00007f7c123d52eb  vmovaps [rsp+0x80], xmm8
00007f7c123d52f4  vmovaps [rsp+0x90], xmm9
00007f7c123d52fd  vmovaps [rsp+0xA0], xmm10
00007f7c123d5306  vmovaps [rsp+0xB0], xmm11
00007f7c123d530f  vmovaps [rsp+0xC0], xmm12
00007f7c123d5318  vmovaps [rsp+0xD0], xmm13
00007f7c123d5321  vmovaps [rsp+0xE0], xmm14
00007f7c123d532a  sub rsp, 0x30
00007f7c123d532e  movaps [rsp], xmm15
00007f7c123d5333  movaps [rsp+0x10], xmm13
00007f7c123d5339  movaps [rsp+0x20], xmm9
00007f7c123d533f  lea rdi, [rsp]
00007f7c123d5343  mov esi, 0x00
00007f7c123d5348  mov rax, 0x5E723D793530
00007f7c123d5352  call rax
00007f7c123d5354  movaps xmm15, [rsp]
00007f7c123d5359  add rsp, 0x30
00007f7c123d535d  vmovaps xmm0, [rsp]
00007f7c123d5362  vmovaps xmm1, [rsp+0x10]
00007f7c123d5368  vmovaps xmm2, [rsp+0x20]
00007f7c123d536e  vmovaps xmm3, [rsp+0x30]
00007f7c123d5374  vmovaps xmm4, [rsp+0x40]
00007f7c123d537a  vmovaps xmm5, [rsp+0x50]
00007f7c123d5380  vmovaps xmm6, [rsp+0x60]
00007f7c123d5386  vmovaps xmm7, [rsp+0x70]
00007f7c123d538c  vmovaps xmm8, [rsp+0x80]
00007f7c123d5395  vmovaps xmm9, [rsp+0x90]
00007f7c123d539e  vmovaps xmm10, [rsp+0xA0]
00007f7c123d53a7  vmovaps xmm11, [rsp+0xB0]
00007f7c123d53b0  vmovaps xmm12, [rsp+0xC0]
00007f7c123d53b9  vmovaps xmm13, [rsp+0xD0]
00007f7c123d53c2  vmovaps xmm14, [rsp+0xE0]
00007f7c123d53cb  add rsp, 0xF0
00007f7c123d53d2  pop r11
00007f7c123d53d4  pop r10
00007f7c123d53d6  pop r9
00007f7c123d53d8  pop r8
00007f7c123d53da  pop rsi
00007f7c123d53db  pop rdi
00007f7c123d53dc  pop rdx
00007f7c123d53dd  pop rcx
00007f7c123d53de  pop rax
00007f7c123d53df  add rsp, 0x08
00007f7c123d53e3  jmp 0x00007F7C123D02D4
00007f7c123d53e8  sub rsp, 0x08
00007f7c123d53ec  push rax
00007f7c123d53ed  push rcx
00007f7c123d53ee  push rdx
00007f7c123d53ef  push rdi
00007f7c123d53f0  push rsi
00007f7c123d53f1  push r8
00007f7c123d53f3  push r9
00007f7c123d53f5  push r10
00007f7c123d53f7  push r11
00007f7c123d53f9  sub rsp, 0xF0
00007f7c123d5400  vmovaps [rsp], xmm0
00007f7c123d5405  vmovaps [rsp+0x10], xmm1
00007f7c123d540b  vmovaps [rsp+0x20], xmm2
00007f7c123d5411  vmovaps [rsp+0x30], xmm3
00007f7c123d5417  vmovaps [rsp+0x40], xmm4
00007f7c123d541d  vmovaps [rsp+0x50], xmm5
00007f7c123d5423  vmovaps [rsp+0x60], xmm6
00007f7c123d5429  vmovaps [rsp+0x70], xmm7
00007f7c123d542f  vmovaps [rsp+0x80], xmm8
00007f7c123d5438  vmovaps [rsp+0x90], xmm9
00007f7c123d5441  vmovaps [rsp+0xA0], xmm10
00007f7c123d544a  vmovaps [rsp+0xB0], xmm11
00007f7c123d5453  vmovaps [rsp+0xC0], xmm12
00007f7c123d545c  vmovaps [rsp+0xD0], xmm14
00007f7c123d5465  vmovaps [rsp+0xE0], xmm15
00007f7c123d546e  sub rsp, 0x30
00007f7c123d5472  movaps [rsp], xmm13
00007f7c123d5477  movaps [rsp+0x10], xmm8
00007f7c123d547d  movaps [rsp+0x20], xmm14
00007f7c123d5483  lea rdi, [rsp]
00007f7c123d5487  mov esi, 0x00
00007f7c123d548c  mov rax, 0x5E723D793530
00007f7c123d5496  call rax
00007f7c123d5498  movaps xmm13, [rsp]
00007f7c123d549d  add rsp, 0x30
00007f7c123d54a1  vmovaps xmm0, [rsp]
00007f7c123d54a6  vmovaps xmm1, [rsp+0x10]
00007f7c123d54ac  vmovaps xmm2, [rsp+0x20]
00007f7c123d54b2  vmovaps xmm3, [rsp+0x30]
00007f7c123d54b8  vmovaps xmm4, [rsp+0x40]
00007f7c123d54be  vmovaps xmm5, [rsp+0x50]
00007f7c123d54c4  vmovaps xmm6, [rsp+0x60]
00007f7c123d54ca  vmovaps xmm7, [rsp+0x70]
00007f7c123d54d0  vmovaps xmm8, [rsp+0x80]
00007f7c123d54d9  vmovaps xmm9, [rsp+0x90]
00007f7c123d54e2  vmovaps xmm10, [rsp+0xA0]
00007f7c123d54eb  vmovaps xmm11, [rsp+0xB0]
00007f7c123d54f4  vmovaps xmm12, [rsp+0xC0]
00007f7c123d54fd  vmovaps xmm14, [rsp+0xD0]
00007f7c123d5506  vmovaps xmm15, [rsp+0xE0]
00007f7c123d550f  add rsp, 0xF0
00007f7c123d5516  pop r11
00007f7c123d5518  pop r10
00007f7c123d551a  pop r9
00007f7c123d551c  pop r8
00007f7c123d551e  pop rsi
00007f7c123d551f  pop rdi
00007f7c123d5520  pop rdx
00007f7c123d5521  pop rcx
00007f7c123d5522  pop rax
00007f7c123d5523  add rsp, 0x08
00007f7c123d5527  jmp 0x00007F7C123D02F7
00007f7c123d552c  sub rsp, 0x08
00007f7c123d5530  push rax
00007f7c123d5531  push rcx
00007f7c123d5532  push rdx
00007f7c123d5533  push rdi
00007f7c123d5534  push rsi
00007f7c123d5535  push r8
00007f7c123d5537  push r9
00007f7c123d5539  push r10
00007f7c123d553b  push r11
00007f7c123d553d  sub rsp, 0xF0
00007f7c123d5544  vmovaps [rsp], xmm0
00007f7c123d5549  vmovaps [rsp+0x10], xmm1
00007f7c123d554f  vmovaps [rsp+0x20], xmm2
00007f7c123d5555  vmovaps [rsp+0x30], xmm3
00007f7c123d555b  vmovaps [rsp+0x40], xmm4
00007f7c123d5561  vmovaps [rsp+0x50], xmm5
00007f7c123d5567  vmovaps [rsp+0x60], xmm6
00007f7c123d556d  vmovaps [rsp+0x70], xmm7
00007f7c123d5573  vmovaps [rsp+0x80], xmm8
00007f7c123d557c  vmovaps [rsp+0x90], xmm9
00007f7c123d5585  vmovaps [rsp+0xA0], xmm10
00007f7c123d558e  vmovaps [rsp+0xB0], xmm11
00007f7c123d5597  vmovaps [rsp+0xC0], xmm12
00007f7c123d55a0  vmovaps [rsp+0xD0], xmm13
00007f7c123d55a9  vmovaps [rsp+0xE0], xmm15
00007f7c123d55b2  sub rsp, 0x30
00007f7c123d55b6  movaps [rsp], xmm14
00007f7c123d55bb  movaps [rsp+0x10], xmm1
00007f7c123d55c0  movaps [rsp+0x20], xmm10
00007f7c123d55c6  lea rdi, [rsp]
00007f7c123d55ca  mov esi, 0x00
00007f7c123d55cf  mov rax, 0x5E723D793530
00007f7c123d55d9  call rax
00007f7c123d55db  movaps xmm14, [rsp]
00007f7c123d55e0  add rsp, 0x30
00007f7c123d55e4  vmovaps xmm0, [rsp]
00007f7c123d55e9  vmovaps xmm1, [rsp+0x10]
00007f7c123d55ef  vmovaps xmm2, [rsp+0x20]
00007f7c123d55f5  vmovaps xmm3, [rsp+0x30]
00007f7c123d55fb  vmovaps xmm4, [rsp+0x40]
00007f7c123d5601  vmovaps xmm5, [rsp+0x50]
00007f7c123d5607  vmovaps xmm6, [rsp+0x60]
00007f7c123d560d  vmovaps xmm7, [rsp+0x70]
00007f7c123d5613  vmovaps xmm8, [rsp+0x80]
00007f7c123d561c  vmovaps xmm9, [rsp+0x90]
00007f7c123d5625  vmovaps xmm10, [rsp+0xA0]
00007f7c123d562e  vmovaps xmm11, [rsp+0xB0]
00007f7c123d5637  vmovaps xmm12, [rsp+0xC0]
00007f7c123d5640  vmovaps xmm13, [rsp+0xD0]
00007f7c123d5649  vmovaps xmm15, [rsp+0xE0]
00007f7c123d5652  add rsp, 0xF0
00007f7c123d5659  pop r11
00007f7c123d565b  pop r10
00007f7c123d565d  pop r9
00007f7c123d565f  pop r8
00007f7c123d5661  pop rsi
00007f7c123d5662  pop rdi
00007f7c123d5663  pop rdx
00007f7c123d5664  pop rcx
00007f7c123d5665  pop rax
00007f7c123d5666  add rsp, 0x08
00007f7c123d566a  jmp 0x00007F7C123D031A
00007f7c123d566f  sub rsp, 0x08
00007f7c123d5673  push rax
00007f7c123d5674  push rcx
00007f7c123d5675  push rdx
00007f7c123d5676  push rdi
00007f7c123d5677  push rsi
00007f7c123d5678  push r8
00007f7c123d567a  push r9
00007f7c123d567c  push r10
00007f7c123d567e  push r11
00007f7c123d5680  sub rsp, 0xF0
00007f7c123d5687  vmovaps [rsp], xmm0
00007f7c123d568c  vmovaps [rsp+0x10], xmm2
00007f7c123d5692  vmovaps [rsp+0x20], xmm3
00007f7c123d5698  vmovaps [rsp+0x30], xmm4
00007f7c123d569e  vmovaps [rsp+0x40], xmm5
00007f7c123d56a4  vmovaps [rsp+0x50], xmm6
00007f7c123d56aa  vmovaps [rsp+0x60], xmm7
00007f7c123d56b0  vmovaps [rsp+0x70], xmm8
00007f7c123d56b6  vmovaps [rsp+0x80], xmm9
00007f7c123d56bf  vmovaps [rsp+0x90], xmm10
00007f7c123d56c8  vmovaps [rsp+0xA0], xmm11
00007f7c123d56d1  vmovaps [rsp+0xB0], xmm12
00007f7c123d56da  vmovaps [rsp+0xC0], xmm13
00007f7c123d56e3  vmovaps [rsp+0xD0], xmm14
00007f7c123d56ec  vmovaps [rsp+0xE0], xmm15
00007f7c123d56f5  sub rsp, 0x30
00007f7c123d56f9  movaps [rsp], xmm1
00007f7c123d56fd  movaps [rsp+0x10], xmm7
00007f7c123d5702  movaps [rsp+0x20], xmm11
00007f7c123d5708  lea rdi, [rsp]
00007f7c123d570c  mov esi, 0x00
00007f7c123d5711  mov rax, 0x5E723D793530
00007f7c123d571b  call rax
00007f7c123d571d  movaps xmm1, [rsp]
00007f7c123d5721  add rsp, 0x30
00007f7c123d5725  vmovaps xmm0, [rsp]
00007f7c123d572a  vmovaps xmm2, [rsp+0x10]
00007f7c123d5730  vmovaps xmm3, [rsp+0x20]
00007f7c123d5736  vmovaps xmm4, [rsp+0x30]
00007f7c123d573c  vmovaps xmm5, [rsp+0x40]
00007f7c123d5742  vmovaps xmm6, [rsp+0x50]
00007f7c123d5748  vmovaps xmm7, [rsp+0x60]
00007f7c123d574e  vmovaps xmm8, [rsp+0x70]
00007f7c123d5754  vmovaps xmm9, [rsp+0x80]
00007f7c123d575d  vmovaps xmm10, [rsp+0x90]
00007f7c123d5766  vmovaps xmm11, [rsp+0xA0]
00007f7c123d576f  vmovaps xmm12, [rsp+0xB0]
00007f7c123d5778  vmovaps xmm13, [rsp+0xC0]
00007f7c123d5781  vmovaps xmm14, [rsp+0xD0]
00007f7c123d578a  vmovaps xmm15, [rsp+0xE0]
00007f7c123d5793  add rsp, 0xF0
00007f7c123d579a  pop r11
00007f7c123d579c  pop r10
00007f7c123d579e  pop r9
00007f7c123d57a0  pop r8
00007f7c123d57a2  pop rsi
00007f7c123d57a3  pop rdi
00007f7c123d57a4  pop rdx
00007f7c123d57a5  pop rcx
00007f7c123d57a6  pop rax
00007f7c123d57a7  add rsp, 0x08
00007f7c123d57ab  jmp 0x00007F7C123D033B
00007f7c123d57b0  call 0x00007F7C1220E880
00007f7c123d57b5  jmp 0x00007F7C123D034E
00007f7c123d57ba  call 0x00007F7C1220C380
00007f7c123d57bf  jmp 0x00007F7C123D0359
00007f7c123d57c4  call 0x00007F7C1220D600
00007f7c123d57c9  jmp 0x00007F7C123D0364
00007f7c123d57ce  call 0x00007F7C121FF540
00007f7c123d57d3  jmp 0x00007F7C123D036F
00007f7c123d57d8  int3
00007f7c123d57d9  nop [rax], eax
00007f7c123d57e0  mov rax, [r15+0x40]
00007f7c123d57e4  mov r14, [r15+0x58]
00007f7c123d57e8  lea r12, [rax+r14*1]
00007f7c123d57ec  movaps xmm1, [r15+0x1D0]
00007f7c123d57f4  vmovaps [rsp+0x10], xmm1
00007f7c123d57fa  vmovaps xmm15, [rsp+0x10]
00007f7c123d5800  por xmm1, xmm15
00007f7c123d5805  movaps xmm14, [r15+0x1A0]
00007f7c123d580d  vmovaps [rsp+0x10], xmm14
00007f7c123d5813  vmovaps xmm13, [rsp+0x10]
00007f7c123d5819  por xmm14, xmm13
00007f7c123d581e  lea rax, [r12+0x30]
00007f7c123d5823  mov r11, [r13+rax*1]
00007f7c123d5828  lea rax, [r12+0x38]
00007f7c123d582d  mov r10, [r13+rax*1]
00007f7c123d5832  movq xmm13, r11
00007f7c123d5837  movq xmm12, r10
00007f7c123d583c  movq xmm13, xmm13
00007f7c123d5841  vmovaps [rsp+0x10], xmm13
00007f7c123d5847  movq xmm13, xmm13
00007f7c123d584c  movaps [r15+0x130], xmm13
00007f7c123d5854  movq xmm12, xmm12
00007f7c123d5859  vmovaps [rsp+0x20], xmm12
00007f7c123d585f  movq xmm12, xmm12
00007f7c123d5864  movaps [r15+0x280], xmm12
00007f7c123d586c  movaps xmm13, [r15+0x270]
00007f7c123d5874  vmovaps [rsp+0x30], xmm13
00007f7c123d587a  vmovaps xmm12, [rsp+0x30]
00007f7c123d5880  por xmm13, xmm12
00007f7c123d5885  lea rax, [r12+0x20]
00007f7c123d588a  mov r11, [r13+rax*1]
00007f7c123d588f  lea rax, [r12+0x28]
00007f7c123d5894  mov r10, [r13+rax*1]
00007f7c123d5899  movq xmm12, r11
00007f7c123d589e  movq xmm11, r10
00007f7c123d58a3  movq xmm12, xmm12
00007f7c123d58a8  vmovaps [rsp+0x30], xmm12
00007f7c123d58ae  movq xmm12, xmm12
00007f7c123d58b3  movaps [r15+0x150], xmm12
00007f7c123d58bb  movq xmm11, xmm11
00007f7c123d58c0  vmovaps [rsp+0x40], xmm11
00007f7c123d58c6  movq xmm11, xmm11
00007f7c123d58cb  movaps [r15+0x140], xmm11
00007f7c123d58d3  lea rax, [r12+0x10]
00007f7c123d58d8  mov r11, [r13+rax*1]
00007f7c123d58dd  lea rax, [r12+0x18]
00007f7c123d58e2  mov r10, [r13+rax*1]
00007f7c123d58e7  movq xmm12, r11
00007f7c123d58ec  movq xmm11, r10
00007f7c123d58f1  movq xmm12, xmm12
00007f7c123d58f6  vmovaps [rsp+0x50], xmm12
00007f7c123d58fc  movq xmm12, xmm12
00007f7c123d5901  movaps [r15+0x170], xmm12
00007f7c123d5909  movq xmm11, xmm11
00007f7c123d590e  vmovaps [rsp+0x60], xmm11
00007f7c123d5914  movq xmm11, xmm11
00007f7c123d5919  movaps [r15+0x160], xmm11
00007f7c123d5921  mov rax, [r13+r12*1]
00007f7c123d5926  vmovq xmm12, rax
00007f7c123d592b  vpbroadcastq xmm12, xmm12
00007f7c123d5930  lea rax, [r12+0x08]
00007f7c123d5935  mov r12, [r13+rax*1]
00007f7c123d593a  movq xmm11, r12
00007f7c123d593f  movaps [r15+0x230], xmm11
00007f7c123d5947  mov rax, [r15+0xF8]
00007f7c123d594e  lea r12, [rax+0x50]
00007f7c123d5952  movups xmm11, [r13+r12*1]
00007f7c123d5958  lea r12, [rax+0x60]
00007f7c123d595c  movups xmm10, [r13+r12*1]
00007f7c123d5962  lea r12, [rax+0x30]
00007f7c123d5966  movups xmm9, [r13+r12*1]
00007f7c123d596c  mov r12, [r15+0x50]
00007f7c123d5970  lea r11, [r12+r14*1]
00007f7c123d5974  mov [r15+0x60], r11
00007f7c123d5978  lea r12, [r14+0x40]
00007f7c123d597c  mov [r15+0x58], r12
00007f7c123d5980  movaps xmm8, xmm12
00007f7c123d5984  mulpd xmm8, xmm15
00007f7c123d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007f7c123d598f  ptest xmm7, xmm7
00007f7c123d5994  jnz 0x00007F7C123D67B7
00007f7c123d599a  movq xmm15, qword ptr [r15+0x230]
00007f7c123d59a3  vmovaps [rsp+0x70], xmm15
00007f7c123d59a9  vpermilpd xmm15, xmm15, 0x00
00007f7c123d59af  movaps xmm7, xmm9
00007f7c123d59b3  mulpd xmm7, xmm15
00007f7c123d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007f7c123d59bd  ptest xmm6, xmm6
00007f7c123d59c2  jnz 0x00007F7C123D68FB
00007f7c123d59c8  vxorps xmm15, xmm15, xmm15
00007f7c123d59cd  vpbroadcastq xmm15, xmm15
00007f7c123d59d2  movaps xmm9, xmm12
00007f7c123d59d6  mulpd xmm9, xmm10
00007f7c123d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007f7c123d59e1  ptest xmm6, xmm6
00007f7c123d59e6  jnz 0x00007F7C123D6A3D
00007f7c123d59ec  movaps xmm10, xmm12
00007f7c123d59f0  mulpd xmm10, xmm11
00007f7c123d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f7c123d59fb  ptest xmm6, xmm6
00007f7c123d5a00  jnz 0x00007F7C123D6B81
00007f7c123d5a06  movaps xmm11, [r15+0x1F0]
00007f7c123d5a0e  movaps xmm6, xmm12
00007f7c123d5a12  mulpd xmm6, xmm11
00007f7c123d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007f7c123d5a1c  ptest xmm5, xmm5
00007f7c123d5a21  jnz 0x00007F7C123D6CC5
00007f7c123d5a27  movaps xmm12, [r15+0x2A0]
00007f7c123d5a2f  vmovaps [rsp+0x80], xmm12
00007f7c123d5a38  vmovaps xmm11, [rsp+0x80]
00007f7c123d5a41  por xmm12, xmm11
00007f7c123d5a46  movaps xmm11, [r15+0x250]
00007f7c123d5a4e  vmovaps [rsp+0x80], xmm11
00007f7c123d5a57  vmovaps xmm5, [rsp+0x80]
00007f7c123d5a60  por xmm11, xmm5
00007f7c123d5a65  vmovaps xmm4, [rsp+0x70]
00007f7c123d5a6b  vpermilpd xmm4, xmm4, 0x00
00007f7c123d5a71  movaps xmm3, xmm5
00007f7c123d5a74  mulpd xmm3, xmm4
00007f7c123d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007f7c123d5a7d  ptest xmm2, xmm2
00007f7c123d5a82  jnz 0x00007F7C123D6E07
00007f7c123d5a88  mov [rsp+0x80], rax
00007f7c123d5a90  xor eax, eax
00007f7c123d5a92  mov r14d, 0x200
00007f7c123d5a98  cmp r12, r14
00007f7c123d5a9b  cmc
00007f7c123d5a9c  lahf
00007f7c123d5a9d  seto al
00007f7c123d5aa0  mov [r15+0x108], eax
00007f7c123d5aa7  movaps xmm5, xmm8
00007f7c123d5aab  addpd xmm5, xmm15
00007f7c123d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007f7c123d5ab5  ptest xmm4, xmm4
00007f7c123d5aba  jnz 0x00007F7C123D6F47
00007f7c123d5ac0  movaps xmm8, [r15+0x1B0]
00007f7c123d5ac8  movaps xmm4, xmm9
00007f7c123d5acc  addpd xmm4, xmm8
00007f7c123d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007f7c123d5ad6  ptest xmm2, xmm2
00007f7c123d5adb  jnz 0x00007F7C123D7089
00007f7c123d5ae1  movaps xmm9, xmm10
00007f7c123d5ae5  addpd xmm9, xmm8
00007f7c123d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007f7c123d5af0  ptest xmm2, xmm2
00007f7c123d5af5  jnz 0x00007F7C123D71CB
00007f7c123d5afb  movaps xmm10, [r15+0x2F0]
00007f7c123d5b03  vmovaps [rsp+0x90], xmm10
00007f7c123d5b0c  vmovaps xmm8, [rsp+0x90]
00007f7c123d5b15  por xmm10, xmm8
00007f7c123d5b1a  movaps xmm8, [r15+0x2E0]
00007f7c123d5b22  vmovaps [rsp+0x90], xmm8
00007f7c123d5b2b  vmovaps xmm2, [rsp+0x90]
00007f7c123d5b34  por xmm8, xmm2
00007f7c123d5b39  movaps xmm2, [r15+0x2D0]
00007f7c123d5b41  vmovaps [rsp+0x90], xmm2
00007f7c123d5b4a  vmovaps [rsp+0xA0], xmm1
00007f7c123d5b53  vmovaps xmm1, [rsp+0x90]
00007f7c123d5b5c  por xmm2, xmm1
00007f7c123d5b60  movaps xmm1, [r15+0x200]
00007f7c123d5b68  vmovaps [rsp+0x90], xmm1
00007f7c123d5b71  vmovaps [rsp+0xB0], xmm15
00007f7c123d5b7a  vmovaps xmm15, [rsp+0x90]
00007f7c123d5b83  por xmm1, xmm15
00007f7c123d5b88  movaps xmm15, [r15+0x1C0]
00007f7c123d5b90  vmovaps [rsp+0x90], xmm15
00007f7c123d5b99  vmovaps [rsp+0xC0], xmm1
00007f7c123d5ba2  vmovaps xmm1, [rsp+0x90]
00007f7c123d5bab  por xmm15, xmm1
00007f7c123d5bb0  movaps xmm1, [r15+0x190]
00007f7c123d5bb8  vmovaps [rsp+0x90], xmm1
00007f7c123d5bc1  vmovaps [rsp+0xD0], xmm15
00007f7c123d5bca  vmovaps xmm15, [rsp+0x90]
00007f7c123d5bd3  por xmm1, xmm15
00007f7c123d5bd8  movaps xmm15, [r15+0x300]
00007f7c123d5be0  vmovaps [rsp+0x90], xmm15
00007f7c123d5be9  vmovaps [rsp+0xE0], xmm1
00007f7c123d5bf2  vmovaps xmm1, [rsp+0x90]
00007f7c123d5bfb  por xmm15, xmm1
00007f7c123d5c00  mov rax, [rsp+0x80]
00007f7c123d5c08  lea r14, [rax+0xA0]
00007f7c123d5c0f  movups xmm1, [r13+r14*1]
00007f7c123d5c15  lea r14, [rax+0xB0]
00007f7c123d5c1c  vmovaps [rsp+0x80], xmm1
00007f7c123d5c25  movups xmm1, [r13+r14*1]
00007f7c123d5c2b  vmovaps [rsp+0x90], xmm1
00007f7c123d5c34  vmovaps [rsp+0xF0], xmm15
00007f7c123d5c3d  vmovaps xmm15, [rsp+0xB0]
00007f7c123d5c46  vmovaps [rsp+0xB0], xmm14
00007f7c123d5c4f  movaps xmm1, xmm6
00007f7c123d5c52  addpd xmm1, xmm15
00007f7c123d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007f7c123d5c5c  ptest xmm14, xmm14
00007f7c123d5c62  jnz 0x00007F7C123D7323
00007f7c123d5c68  lea r14, [rax+0xF0]
00007f7c123d5c6f  movups xmm15, [r13+r14*1]
00007f7c123d5c75  movaps xmm14, xmm4
00007f7c123d5c79  addpd xmm14, xmm3
00007f7c123d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007f7c123d5c84  ptest xmm6, xmm6
00007f7c123d5c89  jnz 0x00007F7C123D746E
00007f7c123d5c8f  movaps xmm6, xmm9
00007f7c123d5c93  addpd xmm6, xmm7
00007f7c123d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007f7c123d5c9c  ptest xmm4, xmm4
00007f7c123d5ca1  jnz 0x00007F7C123D75B0
00007f7c123d5ca7  vmovaps xmm9, [rsp+0x70]
00007f7c123d5cad  vpermilpd xmm9, xmm9, 0x00
00007f7c123d5cb3  vmovaps xmm4, [rsp+0x90]
00007f7c123d5cbc  movaps xmm7, xmm4
00007f7c123d5cbf  mulpd xmm7, xmm9
00007f7c123d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007f7c123d5cc9  ptest xmm3, xmm3
00007f7c123d5cce  jnz 0x00007F7C123D76F1
00007f7c123d5cd4  vmovaps xmm9, [rsp+0x50]
00007f7c123d5cda  vpermilpd xmm9, xmm9, 0x00
00007f7c123d5ce0  movaps xmm4, xmm15
00007f7c123d5ce4  mulpd xmm4, xmm9
00007f7c123d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007f7c123d5cee  ptest xmm3, xmm3
00007f7c123d5cf3  jnz 0x00007F7C123D7832
00007f7c123d5cf9  lea r14, [rax+0xE0]
00007f7c123d5d00  movups xmm15, [r13+r14*1]
00007f7c123d5d06  vmovaps xmm9, [rsp+0x70]
00007f7c123d5d0c  vpermilpd xmm9, xmm9, 0x00
00007f7c123d5d12  vmovaps [rsp+0x70], xmm1
00007f7c123d5d18  vmovaps xmm1, [rsp+0x80]
00007f7c123d5d21  vmovaps [rsp+0x80], xmm15
00007f7c123d5d2a  movaps xmm3, xmm1
00007f7c123d5d2d  mulpd xmm3, xmm9
00007f7c123d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007f7c123d5d37  ptest xmm15, xmm15
00007f7c123d5d3d  jnz 0x00007F7C123D797E
00007f7c123d5d43  vmovaps xmm1, [rsp+0xF0]
00007f7c123d5d4c  vmovaps xmm15, [rsp+0xF0]
00007f7c123d5d55  por xmm1, xmm15
00007f7c123d5d5a  movaps [r15+0x300], xmm1
00007f7c123d5d62  vmovaps xmm15, [rsp+0xE0]
00007f7c123d5d6b  vmovaps xmm9, [rsp+0xE0]
00007f7c123d5d74  por xmm15, xmm9
00007f7c123d5d79  movaps [r15+0x190], xmm15
00007f7c123d5d81  vmovaps xmm9, [rsp+0x50]
00007f7c123d5d87  vpermilpd xmm9, xmm9, 0x00
00007f7c123d5d8d  vmovaps [rsp+0x90], xmm1
00007f7c123d5d96  vmovaps [rsp+0xE0], xmm15
00007f7c123d5d9f  vmovaps xmm15, [rsp+0x80]
00007f7c123d5da8  vmovaps [rsp+0x80], xmm14
00007f7c123d5db1  movaps xmm1, xmm15
00007f7c123d5db5  mulpd xmm1, xmm9
00007f7c123d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007f7c123d5dbf  ptest xmm14, xmm14
00007f7c123d5dc5  jnz 0x00007F7C123D7ABF
00007f7c123d5dcb  lea r14, [rax+0x90]
00007f7c123d5dd2  movups xmm15, [r13+r14*1]
00007f7c123d5dd8  vmovaps xmm14, [rsp+0xD0]
00007f7c123d5de1  vmovaps xmm9, [rsp+0xD0]
00007f7c123d5dea  por xmm14, xmm9
00007f7c123d5def  movaps [r15+0x1C0], xmm14
00007f7c123d5df7  vmovaps xmm9, [rsp+0xC0]
00007f7c123d5e00  vmovaps [rsp+0xD0], xmm1
00007f7c123d5e09  vmovaps xmm1, [rsp+0xC0]
00007f7c123d5e12  por xmm9, xmm1
00007f7c123d5e17  movaps [r15+0x200], xmm9
00007f7c123d5e1f  vmovaps [rsp+0xC0], xmm2
00007f7c123d5e28  vmovaps xmm1, [rsp+0xC0]
00007f7c123d5e31  por xmm2, xmm1
00007f7c123d5e35  movaps [r15+0x2D0], xmm2
00007f7c123d5e3d  vmovaps [rsp+0xC0], xmm8
00007f7c123d5e46  vmovaps xmm1, [rsp+0xC0]
00007f7c123d5e4f  por xmm8, xmm1
00007f7c123d5e54  movaps [r15+0x2E0], xmm8
00007f7c123d5e5c  vmovaps [rsp+0xC0], xmm15
00007f7c123d5e65  movaps xmm1, xmm5
00007f7c123d5e68  addpd xmm1, xmm7
00007f7c123d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007f7c123d5e71  ptest xmm15, xmm15
00007f7c123d5e77  jnz 0x00007F7C123D7C0B
00007f7c123d5e7d  vmovaps xmm15, [rsp+0x50]
00007f7c123d5e83  vpermilpd xmm15, xmm15, 0x00
00007f7c123d5e89  vmovaps xmm5, [rsp+0xC0]
00007f7c123d5e92  vmovaps [rsp+0xC0], xmm1
00007f7c123d5e9b  movaps xmm7, xmm5
00007f7c123d5e9e  mulpd xmm7, xmm15
00007f7c123d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007f7c123d5ea8  ptest xmm1, xmm1
00007f7c123d5ead  jnz 0x00007F7C123D7D4B
00007f7c123d5eb3  lea r14, [rax+0x80]
00007f7c123d5eba  movups xmm1, [r13+r14*1]
00007f7c123d5ec0  vmovaps xmm5, [rsp+0x70]
00007f7c123d5ec6  vmovaps [rsp+0x70], xmm1
00007f7c123d5ecc  movaps xmm15, xmm5
00007f7c123d5ed0  addpd xmm15, xmm3
00007f7c123d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f7c123d5edb  ptest xmm1, xmm1
00007f7c123d5ee0  jnz 0x00007F7C123D7E96
00007f7c123d5ee6  vmovaps xmm5, [rsp+0x80]
00007f7c123d5eef  movaps xmm1, xmm5
00007f7c123d5ef2  addpd xmm1, xmm4
00007f7c123d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007f7c123d5efb  ptest xmm3, xmm3
00007f7c123d5f00  jnz 0x00007F7C123D7FD8
00007f7c123d5f06  vmovaps [rsp+0x80], xmm10
00007f7c123d5f0f  vmovaps xmm5, [rsp+0x80]
00007f7c123d5f18  por xmm10, xmm5
00007f7c123d5f1d  movaps [r15+0x2F0], xmm10
00007f7c123d5f25  vmovaps xmm5, [rsp+0x50]
00007f7c123d5f2b  vpermilpd xmm5, xmm5, 0x00
00007f7c123d5f31  vmovaps xmm3, [rsp+0x70]
00007f7c123d5f37  vmovaps [rsp+0x50], xmm1
00007f7c123d5f3d  movaps xmm4, xmm3
00007f7c123d5f40  mulpd xmm4, xmm5
00007f7c123d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007f7c123d5f49  ptest xmm1, xmm1
00007f7c123d5f4e  jnz 0x00007F7C123D8118
00007f7c123d5f54  lea r14, [rax+0xD0]
00007f7c123d5f5b  movups xmm1, [r13+r14*1]
00007f7c123d5f61  vmovaps xmm3, [rsp+0xD0]
00007f7c123d5f6a  vmovaps [rsp+0x70], xmm1
00007f7c123d5f70  movaps xmm5, xmm6
00007f7c123d5f73  addpd xmm5, xmm3
00007f7c123d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007f7c123d5f7c  ptest xmm1, xmm1
00007f7c123d5f81  jnz 0x00007F7C123D8262
00007f7c123d5f87  vmovaps xmm1, [rsp+0x60]
00007f7c123d5f8d  vpermilpd xmm1, xmm1, 0x00
00007f7c123d5f93  movaps xmm6, xmm9
00007f7c123d5f97  mulpd xmm6, xmm1
00007f7c123d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007f7c123d5fa0  ptest xmm3, xmm3
00007f7c123d5fa5  jnz 0x00007F7C123D83A2
00007f7c123d5fab  movaps [r15+0x260], xmm6
00007f7c123d5fb3  vxorps xmm1, xmm1, xmm1
00007f7c123d5fb7  vpbroadcastq xmm1, xmm1
00007f7c123d5fbc  movaps [r15+0x1B0], xmm1
00007f7c123d5fc4  vmovaps xmm1, [rsp+0x60]
00007f7c123d5fca  vpermilpd xmm1, xmm1, 0x00
00007f7c123d5fd0  vmovaps xmm3, [rsp+0x70]
00007f7c123d5fd6  vmovaps [rsp+0x70], xmm15
00007f7c123d5fdc  movaps xmm9, xmm3
00007f7c123d5fe0  mulpd xmm9, xmm1
00007f7c123d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007f7c123d5feb  ptest xmm15, xmm15
00007f7c123d5ff1  jnz 0x00007F7C123D84E3
00007f7c123d5ff7  lea r14, [rax+0xC0]
00007f7c123d5ffe  movups xmm1, [r13+r14*1]
00007f7c123d6004  vmovaps xmm3, [rsp+0xC0]
00007f7c123d600d  vmovaps [rsp+0x80], xmm1
00007f7c123d6016  movaps xmm15, xmm3
00007f7c123d601a  addpd xmm15, xmm7
00007f7c123d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007f7c123d6025  ptest xmm1, xmm1
00007f7c123d602a  jnz 0x00007F7C123D862F
00007f7c123d6030  vmovaps [rsp+0xC0], xmm13
00007f7c123d6039  vmovaps xmm1, [rsp+0xC0]
00007f7c123d6042  por xmm13, xmm1
00007f7c123d6047  movaps [r15+0x270], xmm13
00007f7c123d604f  vmovaps xmm1, [rsp+0xB0]
00007f7c123d6058  vmovaps xmm7, [rsp+0xB0]
00007f7c123d6061  por xmm1, xmm7
00007f7c123d6065  movaps [r15+0x1A0], xmm1
00007f7c123d606d  vmovaps xmm1, [rsp+0x60]
00007f7c123d6073  vpermilpd xmm1, xmm1, 0x00
00007f7c123d6079  vmovaps [rsp+0xB0], xmm1
00007f7c123d6082  vmovaps xmm1, [rsp+0x80]
00007f7c123d608b  vmovaps [rsp+0x80], xmm15
00007f7c123d6094  vmovaps xmm15, [rsp+0xB0]
00007f7c123d609d  vmovaps [rsp+0xB0], xmm14
00007f7c123d60a6  movaps xmm3, xmm1
00007f7c123d60a9  mulpd xmm3, xmm15
00007f7c123d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007f7c123d60b3  ptest xmm14, xmm14
00007f7c123d60b9  jnz 0x00007F7C123D8771
00007f7c123d60bf  lea r14, [rax+0x20]
00007f7c123d60c3  movups xmm1, [r13+r14*1]
00007f7c123d60c9  movaps [r15+0x110], xmm1
00007f7c123d60d1  vmovaps xmm14, [rsp+0x70]
00007f7c123d60d7  vmovaps [rsp+0x70], xmm1
00007f7c123d60dd  movaps xmm15, xmm14
00007f7c123d60e1  addpd xmm15, xmm4
00007f7c123d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007f7c123d60ec  ptest xmm1, xmm1
00007f7c123d60f1  jnz 0x00007F7C123D88BC
00007f7c123d60f7  vmovaps xmm1, [rsp+0x60]
00007f7c123d60fd  vpermilpd xmm1, xmm1, 0x00
00007f7c123d6103  movaps xmm14, xmm2
00007f7c123d6107  mulpd xmm14, xmm1
00007f7c123d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007f7c123d6112  ptest xmm4, xmm4
00007f7c123d6117  jnz 0x00007F7C123D89FF
00007f7c123d611d  vmovaps xmm4, [rsp+0x50]
00007f7c123d6123  movaps xmm1, xmm4
00007f7c123d6126  addpd xmm1, xmm9
00007f7c123d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f7c123d6130  ptest xmm2, xmm2
00007f7c123d6135  jnz 0x00007F7C123D8B41
00007f7c123d613b  vmovaps xmm9, [rsp+0x30]
00007f7c123d6141  vpermilpd xmm9, xmm9, 0x00
00007f7c123d6147  vmovaps xmm2, [rsp+0x70]
00007f7c123d614d  vmovaps [rsp+0x50], xmm1
00007f7c123d6153  movaps xmm4, xmm2
00007f7c123d6156  mulpd xmm4, xmm9
00007f7c123d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007f7c123d6160  ptest xmm1, xmm1
00007f7c123d6165  jnz 0x00007F7C123D8C82
00007f7c123d616b  vmovaps xmm1, [rsp+0x30]
00007f7c123d6171  vpermilpd xmm1, xmm1, 0x00
00007f7c123d6177  vmovaps xmm2, [rsp+0x90]
00007f7c123d6180  vmovaps [rsp+0x60], xmm15
00007f7c123d6186  movaps xmm9, xmm2
00007f7c123d618a  mulpd xmm9, xmm1
00007f7c123d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007f7c123d6195  ptest xmm15, xmm15
00007f7c123d619b  jnz 0x00007F7C123D8DC3
00007f7c123d61a1  vmovaps xmm15, [rsp+0x80]
00007f7c123d61aa  movaps xmm1, xmm15
00007f7c123d61ae  addpd xmm1, xmm6
00007f7c123d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007f7c123d61b7  ptest xmm2, xmm2
00007f7c123d61bc  jnz 0x00007F7C123D8F05
00007f7c123d61c2  movaps xmm15, xmm5
00007f7c123d61c6  addpd xmm15, xmm3
00007f7c123d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007f7c123d61d1  ptest xmm6, xmm6
00007f7c123d61d6  jnz 0x00007F7C123D9046
00007f7c123d61dc  vmovaps xmm6, [rsp+0x30]
00007f7c123d61e2  vpermilpd xmm6, xmm6, 0x00
00007f7c123d61e8  movaps xmm5, xmm8
00007f7c123d61ec  mulpd xmm5, xmm6
00007f7c123d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007f7c123d61f5  ptest xmm3, xmm3
00007f7c123d61fa  jnz 0x00007F7C123D9188
00007f7c123d6200  vmovaps xmm8, [rsp+0x30]
00007f7c123d6206  vpermilpd xmm8, xmm8, 0x00
00007f7c123d620c  movaps xmm6, xmm10
00007f7c123d6210  mulpd xmm6, xmm8
00007f7c123d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007f7c123d621a  ptest xmm3, xmm3
00007f7c123d621f  jnz 0x00007F7C123D92C9
00007f7c123d6225  vmovaps xmm8, [rsp+0x60]
00007f7c123d622b  movaps xmm10, xmm8
00007f7c123d622f  addpd xmm10, xmm14
00007f7c123d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007f7c123d623a  ptest xmm3, xmm3
00007f7c123d623f  jnz 0x00007F7C123D940B
00007f7c123d6245  vmovaps xmm8, [rsp+0x50]
00007f7c123d624b  movaps xmm14, xmm8
00007f7c123d624f  addpd xmm14, xmm4
00007f7c123d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007f7c123d625a  ptest xmm3, xmm3
00007f7c123d625f  jnz 0x00007F7C123D954F
00007f7c123d6265  vmovaps xmm8, [rsp+0x40]
00007f7c123d626b  vpermilpd xmm8, xmm8, 0x00
00007f7c123d6271  movaps xmm4, xmm13
00007f7c123d6275  mulpd xmm4, xmm8
00007f7c123d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007f7c123d627f  ptest xmm3, xmm3
00007f7c123d6284  jnz 0x00007F7C123D9692
00007f7c123d628a  movaps xmm13, xmm15
00007f7c123d628e  addpd xmm13, xmm9
00007f7c123d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007f7c123d6299  ptest xmm8, xmm8
00007f7c123d629f  jnz 0x00007F7C123D97D4
00007f7c123d62a5  movaps xmm15, xmm1
00007f7c123d62a9  addpd xmm15, xmm5
00007f7c123d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007f7c123d62b4  ptest xmm9, xmm9
00007f7c123d62ba  jnz 0x00007F7C123D9918
00007f7c123d62c0  vmovaps [rsp+0x30], xmm11
00007f7c123d62c6  vmovaps xmm1, [rsp+0x30]
00007f7c123d62cc  por xmm11, xmm1
00007f7c123d62d1  movaps [r15+0x250], xmm11
00007f7c123d62d9  vmovaps [rsp+0x30], xmm12
00007f7c123d62df  vmovaps xmm1, [rsp+0x30]
00007f7c123d62e5  por xmm12, xmm1
00007f7c123d62ea  movaps [r15+0x2A0], xmm12
00007f7c123d62f2  vmovaps xmm1, [rsp+0xA0]
00007f7c123d62fb  vmovaps xmm11, [rsp+0xA0]
00007f7c123d6304  por xmm1, xmm11
00007f7c123d6309  movaps [r15+0x1D0], xmm1
00007f7c123d6311  lea r14, [rax+0x40]
00007f7c123d6315  movups xmm1, [r13+r14*1]
00007f7c123d631b  movaps [r15+0x2C0], xmm1
00007f7c123d6323  vmovaps xmm11, [rsp+0x40]
00007f7c123d6329  vpermilpd xmm11, xmm11, 0x00
00007f7c123d632f  vmovaps xmm8, [rsp+0xE0]
00007f7c123d6338  movaps xmm9, xmm8
00007f7c123d633c  mulpd xmm9, xmm11
00007f7c123d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007f7c123d6347  ptest xmm5, xmm5
00007f7c123d634c  jnz 0x00007F7C123D9A64
00007f7c123d6352  movaps xmm11, xmm10
00007f7c123d6356  addpd xmm11, xmm6
00007f7c123d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007f7c123d6361  ptest xmm8, xmm8
00007f7c123d6367  jnz 0x00007F7C123D9BA8
00007f7c123d636d  movaps xmm10, xmm14
00007f7c123d6371  addpd xmm10, xmm4
00007f7c123d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007f7c123d637c  ptest xmm8, xmm8
00007f7c123d6382  jnz 0x00007F7C123D9CEB
00007f7c123d6388  vmovaps xmm14, [rsp+0x40]
00007f7c123d638e  vpermilpd xmm14, xmm14, 0x00
00007f7c123d6394  movaps xmm8, xmm1
00007f7c123d6398  mulpd xmm8, xmm14
00007f7c123d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007f7c123d63a3  ptest xmm6, xmm6
00007f7c123d63a8  jnz 0x00007F7C123D9E2E
00007f7c123d63ae  movaps xmm1, [r15+0x2B0]
00007f7c123d63b6  vmovaps xmm14, [rsp+0x40]
00007f7c123d63bc  vpermilpd xmm14, xmm14, 0x00
00007f7c123d63c2  movaps xmm6, xmm1
00007f7c123d63c5  mulpd xmm6, xmm14
00007f7c123d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007f7c123d63cf  ptest xmm5, xmm5
00007f7c123d63d4  jnz 0x00007F7C123D9F71
00007f7c123d63da  vmovaps xmm1, [rsp+0x10]
00007f7c123d63e0  vpermilpd xmm1, xmm1, 0x00
00007f7c123d63e6  movaps xmm14, xmm12
00007f7c123d63ea  mulpd xmm14, xmm1
00007f7c123d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007f7c123d63f5  ptest xmm5, xmm5
00007f7c123d63fa  jnz 0x00007F7C123DA0B2
00007f7c123d6400  movaps xmm1, xmm13
00007f7c123d6404  addpd xmm1, xmm9
00007f7c123d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007f7c123d640e  ptest xmm12, xmm12
00007f7c123d6414  jnz 0x00007F7C123DA1F5
00007f7c123d641a  vmovaps xmm13, [rsp+0x10]
00007f7c123d6420  vpermilpd xmm13, xmm13, 0x00
00007f7c123d6426  movaps xmm12, xmm7
00007f7c123d642a  mulpd xmm12, xmm13
00007f7c123d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007f7c123d6435  ptest xmm9, xmm9
00007f7c123d643b  jnz 0x00007F7C123DA337
00007f7c123d6441  movaps xmm13, xmm15
00007f7c123d6445  addpd xmm13, xmm8
00007f7c123d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007f7c123d6450  ptest xmm9, xmm9
00007f7c123d6456  jnz 0x00007F7C123DA47A
00007f7c123d645c  movaps xmm15, [r15+0x290]
00007f7c123d6464  vmovaps xmm9, [rsp+0x10]
00007f7c123d646a  vpermilpd xmm9, xmm9, 0x00
00007f7c123d6470  movaps xmm8, xmm15
00007f7c123d6474  mulpd xmm8, xmm9
00007f7c123d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007f7c123d647f  ptest xmm7, xmm7
00007f7c123d6484  jnz 0x00007F7C123DA5BE
00007f7c123d648a  movaps xmm15, xmm11
00007f7c123d648e  addpd xmm15, xmm6
00007f7c123d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007f7c123d6499  ptest xmm9, xmm9
00007f7c123d649f  jnz 0x00007F7C123DA702
00007f7c123d64a5  movaps xmm11, [r15+0x1E0]
00007f7c123d64ad  vmovaps xmm9, [rsp+0x10]
00007f7c123d64b3  vpermilpd xmm9, xmm9, 0x00
00007f7c123d64b9  movaps xmm7, xmm11
00007f7c123d64bd  mulpd xmm7, xmm9
00007f7c123d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007f7c123d64c7  ptest xmm6, xmm6
00007f7c123d64cc  jnz 0x00007F7C123DA845
00007f7c123d64d2  movaps xmm11, xmm10
00007f7c123d64d6  addpd xmm11, xmm14
00007f7c123d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007f7c123d64e1  ptest xmm9, xmm9
00007f7c123d64e7  jnz 0x00007F7C123DA987
00007f7c123d64ed  lea r14, [rax+0x70]
00007f7c123d64f1  movups xmm14, [r13+r14*1]
00007f7c123d64f7  movaps [r15+0x240], xmm14
00007f7c123d64ff  movaps xmm10, xmm1
00007f7c123d6503  addpd xmm10, xmm12
00007f7c123d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007f7c123d650e  ptest xmm9, xmm9
00007f7c123d6514  jnz 0x00007F7C123DAAD5
00007f7c123d651a  movaps [r15+0x170], xmm10
00007f7c123d6522  vmovaps xmm1, [rsp+0x20]
00007f7c123d6528  vpermilpd xmm1, xmm1, 0x00
00007f7c123d652e  movaps xmm12, xmm14
00007f7c123d6532  mulpd xmm12, xmm1
00007f7c123d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007f7c123d653d  ptest xmm9, xmm9
00007f7c123d6543  jnz 0x00007F7C123DAC18
00007f7c123d6549  vmovaps xmm1, [rsp+0x20]
00007f7c123d654f  vpermilpd xmm1, xmm1, 0x00
00007f7c123d6555  vmovaps xmm9, [rsp+0xB0]
00007f7c123d655e  movaps xmm14, xmm9
00007f7c123d6562  mulpd xmm14, xmm1
00007f7c123d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007f7c123d656d  ptest xmm6, xmm6
00007f7c123d6572  jnz 0x00007F7C123DAD5B
00007f7c123d6578  movaps [r15+0x180], xmm14
00007f7c123d6580  movaps xmm1, xmm13
00007f7c123d6584  addpd xmm1, xmm8
00007f7c123d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007f7c123d658e  ptest xmm9, xmm9
00007f7c123d6594  jnz 0x00007F7C123DAE9E
00007f7c123d659a  movaps [r15+0x210], xmm1
00007f7c123d65a2  movups xmm13, [r13+rax*1]
00007f7c123d65a8  lea r14, [rax+0x10]
00007f7c123d65ac  movups xmm9, [r13+r14*1]
00007f7c123d65b2  movaps [r15+0x230], xmm9
00007f7c123d65ba  movaps xmm8, xmm15
00007f7c123d65be  addpd xmm8, xmm7
00007f7c123d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007f7c123d65c9  ptest xmm6, xmm6
00007f7c123d65ce  jnz 0x00007F7C123DAFF4
00007f7c123d65d4  movaps [r15+0x130], xmm8
00007f7c123d65dc  vmovaps xmm15, [rsp+0x20]
00007f7c123d65e2  vpermilpd xmm15, xmm15, 0x00
00007f7c123d65e8  movaps xmm7, xmm9
00007f7c123d65ec  mulpd xmm7, xmm15
00007f7c123d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007f7c123d65f6  ptest xmm6, xmm6
00007f7c123d65fb  jnz 0x00007F7C123DB137
00007f7c123d6601  movaps [r15+0x220], xmm7
00007f7c123d6609  vmovaps xmm15, [rsp+0x20]
00007f7c123d660f  vpermilpd xmm15, xmm15, 0x00
00007f7c123d6615  movaps xmm9, xmm13
00007f7c123d6619  mulpd xmm9, xmm15
00007f7c123d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007f7c123d6624  ptest xmm6, xmm6
00007f7c123d6629  jnz 0x00007F7C123DB279
00007f7c123d662f  movaps xmm15, xmm11
00007f7c123d6633  addpd xmm15, xmm12
00007f7c123d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007f7c123d663e  ptest xmm13, xmm13
00007f7c123d6644  jnz 0x00007F7C123DB3BD
00007f7c123d664a  movaps [r15+0x140], xmm15
00007f7c123d6652  movaps xmm13, xmm10
00007f7c123d6656  addpd xmm13, xmm14
00007f7c123d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007f7c123d6661  ptest xmm12, xmm12
00007f7c123d6667  jnz 0x00007F7C123DB501
00007f7c123d666d  movaps [r15+0x150], xmm13
00007f7c123d6675  movaps xmm14, xmm1
00007f7c123d6679  addpd xmm14, xmm7
00007f7c123d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007f7c123d6684  ptest xmm12, xmm12
00007f7c123d668a  jnz 0x00007F7C123DB645
00007f7c123d6690  movaps [r15+0x160], xmm14
00007f7c123d6698  movaps xmm1, xmm8
00007f7c123d669c  addpd xmm1, xmm9
00007f7c123d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007f7c123d66a6  ptest xmm12, xmm12
00007f7c123d66ac  jnz 0x00007F7C123DB787
00007f7c123d66b2  movaps [r15+0x120], xmm1
00007f7c123d66ba  movups [r13+r11*1], xmm15
00007f7c123d66c0  lea rax, [r11+0x10]
00007f7c123d66c4  movups [r13+rax*1], xmm13
00007f7c123d66ca  lea rax, [r11+0x20]
00007f7c123d66ce  movups [r13+rax*1], xmm14
00007f7c123d66d4  lea rax, [r11+0x30]
00007f7c123d66d8  movups [r13+rax*1], xmm1
00007f7c123d66de  mov eax, [r15+0x108]
00007f7c123d66e5  sahf
00007f7c123d66e6  jnz 0x00007F7C123D6718
00007f7c123d66e8  cmp dword ptr [r15+0x318], 0x00
00007f7c123d66f0  jz 0x00007F7C123DB900
00007f7c123d66f6  nop [rax+rax*1], ax
00007f7c123d66ff  nop [rax+rax*1], eax
00007f7c123d6707  mov eax, 0x410444
00007f7c123d670c  mov [r15+0x100], rax
00007f7c123d6713  jmp 0x00007F7C121FE110
00007f7c123d6718  cmp dword ptr [r15+0x318], 0x00
00007f7c123d6720  jz 0x00007F7C123D57E0
00007f7c123d6726  nop [rax+rax*1], ax
00007f7c123d672f  nop [rax+rax*1], eax
00007f7c123d6737  mov eax, 0x410278
00007f7c123d673c  mov [r15+0x100], rax
00007f7c123d6743  jmp 0x00007F7C121FE110
00007f7c123d6748  int3
00007f7c123d6749  call 0x00007F7C1220A4B0
00007f7c123d674e  jmp 0x00007F7C123D5828
00007f7c123d6753  call 0x00007F7C12209240
00007f7c123d6758  jmp 0x00007F7C123D5832
00007f7c123d675d  call 0x00007F7C1220A4B0
00007f7c123d6762  jmp 0x00007F7C123D588F
00007f7c123d6767  call 0x00007F7C12209240
00007f7c123d676c  jmp 0x00007F7C123D5899
00007f7c123d6771  call 0x00007F7C1220A4B0
00007f7c123d6776  jmp 0x00007F7C123D58DD
00007f7c123d677b  call 0x00007F7C12209240
00007f7c123d6780  jmp 0x00007F7C123D58E7
00007f7c123d6785  call 0x00007F7C122B47C0
00007f7c123d678a  jmp 0x00007F7C123D5926
00007f7c123d678f  call 0x00007F7C1220B720
00007f7c123d6794  jmp 0x00007F7C123D593A
00007f7c123d6799  call 0x00007F7C122BFC30
00007f7c123d679e  jmp 0x00007F7C123D5958
00007f7c123d67a3  call 0x00007F7C122BE9C0
00007f7c123d67a8  jmp 0x00007F7C123D5962
00007f7c123d67ad  call 0x00007F7C122BD750
00007f7c123d67b2  jmp 0x00007F7C123D596C
00007f7c123d67b7  sub rsp, 0x08
00007f7c123d67bb  push rax
00007f7c123d67bc  push rcx
00007f7c123d67bd  push rdx
00007f7c123d67be  push rdi
00007f7c123d67bf  push rsi
00007f7c123d67c0  push r8
00007f7c123d67c2  push r9
00007f7c123d67c4  push r10
00007f7c123d67c6  push r11
00007f7c123d67c8  sub rsp, 0xF0
00007f7c123d67cf  vmovaps [rsp], xmm0
00007f7c123d67d4  vmovaps [rsp+0x10], xmm1
00007f7c123d67da  vmovaps [rsp+0x20], xmm2
00007f7c123d67e0  vmovaps [rsp+0x30], xmm3
00007f7c123d67e6  vmovaps [rsp+0x40], xmm4
00007f7c123d67ec  vmovaps [rsp+0x50], xmm5
00007f7c123d67f2  vmovaps [rsp+0x60], xmm6
00007f7c123d67f8  vmovaps [rsp+0x70], xmm7
00007f7c123d67fe  vmovaps [rsp+0x80], xmm9
00007f7c123d6807  vmovaps [rsp+0x90], xmm10
00007f7c123d6810  vmovaps [rsp+0xA0], xmm11
00007f7c123d6819  vmovaps [rsp+0xB0], xmm12
00007f7c123d6822  vmovaps [rsp+0xC0], xmm13
00007f7c123d682b  vmovaps [rsp+0xD0], xmm14
00007f7c123d6834  vmovaps [rsp+0xE0], xmm15
00007f7c123d683d  sub rsp, 0x30
00007f7c123d6841  movaps [rsp], xmm8
00007f7c123d6846  movaps [rsp+0x10], xmm12
00007f7c123d684c  movaps [rsp+0x20], xmm15
00007f7c123d6852  lea rdi, [rsp]
00007f7c123d6856  mov esi, 0x00
00007f7c123d685b  mov rax, 0x5E723D793530
00007f7c123d6865  call rax
00007f7c123d6867  movaps xmm8, [rsp]
00007f7c123d686c  add rsp, 0x30
00007f7c123d6870  vmovaps xmm0, [rsp]
00007f7c123d6875  vmovaps xmm1, [rsp+0x10]
00007f7c123d687b  vmovaps xmm2, [rsp+0x20]
00007f7c123d6881  vmovaps xmm3, [rsp+0x30]
00007f7c123d6887  vmovaps xmm4, [rsp+0x40]
00007f7c123d688d  vmovaps xmm5, [rsp+0x50]
00007f7c123d6893  vmovaps xmm6, [rsp+0x60]
00007f7c123d6899  vmovaps xmm7, [rsp+0x70]
00007f7c123d689f  vmovaps xmm9, [rsp+0x80]
00007f7c123d68a8  vmovaps xmm10, [rsp+0x90]
00007f7c123d68b1  vmovaps xmm11, [rsp+0xA0]
00007f7c123d68ba  vmovaps xmm12, [rsp+0xB0]
00007f7c123d68c3  vmovaps xmm13, [rsp+0xC0]
00007f7c123d68cc  vmovaps xmm14, [rsp+0xD0]
00007f7c123d68d5  vmovaps xmm15, [rsp+0xE0]
00007f7c123d68de  add rsp, 0xF0
00007f7c123d68e5  pop r11
00007f7c123d68e7  pop r10
00007f7c123d68e9  pop r9
00007f7c123d68eb  pop r8
00007f7c123d68ed  pop rsi
00007f7c123d68ee  pop rdi
00007f7c123d68ef  pop rdx
00007f7c123d68f0  pop rcx
00007f7c123d68f1  pop rax
00007f7c123d68f2  add rsp, 0x08
00007f7c123d68f6  jmp 0x00007F7C123D599A
00007f7c123d68fb  sub rsp, 0x08
00007f7c123d68ff  push rax
00007f7c123d6900  push rcx
00007f7c123d6901  push rdx
00007f7c123d6902  push rdi
00007f7c123d6903  push rsi
00007f7c123d6904  push r8
00007f7c123d6906  push r9
00007f7c123d6908  push r10
00007f7c123d690a  push r11
00007f7c123d690c  sub rsp, 0xF0
00007f7c123d6913  vmovaps [rsp], xmm0
00007f7c123d6918  vmovaps [rsp+0x10], xmm1
00007f7c123d691e  vmovaps [rsp+0x20], xmm2
00007f7c123d6924  vmovaps [rsp+0x30], xmm3
00007f7c123d692a  vmovaps [rsp+0x40], xmm4
00007f7c123d6930  vmovaps [rsp+0x50], xmm5
00007f7c123d6936  vmovaps [rsp+0x60], xmm6
00007f7c123d693c  vmovaps [rsp+0x70], xmm8
00007f7c123d6942  vmovaps [rsp+0x80], xmm9
00007f7c123d694b  vmovaps [rsp+0x90], xmm10
00007f7c123d6954  vmovaps [rsp+0xA0], xmm11
00007f7c123d695d  vmovaps [rsp+0xB0], xmm12
00007f7c123d6966  vmovaps [rsp+0xC0], xmm13
00007f7c123d696f  vmovaps [rsp+0xD0], xmm14
00007f7c123d6978  vmovaps [rsp+0xE0], xmm15
00007f7c123d6981  sub rsp, 0x30
00007f7c123d6985  movaps [rsp], xmm7
00007f7c123d6989  movaps [rsp+0x10], xmm9
00007f7c123d698f  movaps [rsp+0x20], xmm15
00007f7c123d6995  lea rdi, [rsp]
00007f7c123d6999  mov esi, 0x00
00007f7c123d699e  mov rax, 0x5E723D793530
00007f7c123d69a8  call rax
00007f7c123d69aa  movaps xmm7, [rsp]
00007f7c123d69ae  add rsp, 0x30
00007f7c123d69b2  vmovaps xmm0, [rsp]
00007f7c123d69b7  vmovaps xmm1, [rsp+0x10]
00007f7c123d69bd  vmovaps xmm2, [rsp+0x20]
00007f7c123d69c3  vmovaps xmm3, [rsp+0x30]
00007f7c123d69c9  vmovaps xmm4, [rsp+0x40]
00007f7c123d69cf  vmovaps xmm5, [rsp+0x50]
00007f7c123d69d5  vmovaps xmm6, [rsp+0x60]
00007f7c123d69db  vmovaps xmm8, [rsp+0x70]
00007f7c123d69e1  vmovaps xmm9, [rsp+0x80]
00007f7c123d69ea  vmovaps xmm10, [rsp+0x90]
00007f7c123d69f3  vmovaps xmm11, [rsp+0xA0]
00007f7c123d69fc  vmovaps xmm12, [rsp+0xB0]
00007f7c123d6a05  vmovaps xmm13, [rsp+0xC0]
00007f7c123d6a0e  vmovaps xmm14, [rsp+0xD0]
00007f7c123d6a17  vmovaps xmm15, [rsp+0xE0]
00007f7c123d6a20  add rsp, 0xF0
00007f7c123d6a27  pop r11
00007f7c123d6a29  pop r10
00007f7c123d6a2b  pop r9
00007f7c123d6a2d  pop r8
00007f7c123d6a2f  pop rsi
00007f7c123d6a30  pop rdi
00007f7c123d6a31  pop rdx
00007f7c123d6a32  pop rcx
00007f7c123d6a33  pop rax
00007f7c123d6a34  add rsp, 0x08
00007f7c123d6a38  jmp 0x00007F7C123D59C8
00007f7c123d6a3d  sub rsp, 0x08
00007f7c123d6a41  push rax
00007f7c123d6a42  push rcx
00007f7c123d6a43  push rdx
00007f7c123d6a44  push rdi
00007f7c123d6a45  push rsi
00007f7c123d6a46  push r8
00007f7c123d6a48  push r9
00007f7c123d6a4a  push r10
00007f7c123d6a4c  push r11
00007f7c123d6a4e  sub rsp, 0xF0
00007f7c123d6a55  vmovaps [rsp], xmm0
00007f7c123d6a5a  vmovaps [rsp+0x10], xmm1
00007f7c123d6a60  vmovaps [rsp+0x20], xmm2
00007f7c123d6a66  vmovaps [rsp+0x30], xmm3
00007f7c123d6a6c  vmovaps [rsp+0x40], xmm4
00007f7c123d6a72  vmovaps [rsp+0x50], xmm5
00007f7c123d6a78  vmovaps [rsp+0x60], xmm6
00007f7c123d6a7e  vmovaps [rsp+0x70], xmm7
00007f7c123d6a84  vmovaps [rsp+0x80], xmm8
00007f7c123d6a8d  vmovaps [rsp+0x90], xmm10
00007f7c123d6a96  vmovaps [rsp+0xA0], xmm11
00007f7c123d6a9f  vmovaps [rsp+0xB0], xmm12
00007f7c123d6aa8  vmovaps [rsp+0xC0], xmm13
00007f7c123d6ab1  vmovaps [rsp+0xD0], xmm14
00007f7c123d6aba  vmovaps [rsp+0xE0], xmm15
00007f7c123d6ac3  sub rsp, 0x30
00007f7c123d6ac7  movaps [rsp], xmm9
00007f7c123d6acc  movaps [rsp+0x10], xmm12
00007f7c123d6ad2  movaps [rsp+0x20], xmm10
00007f7c123d6ad8  lea rdi, [rsp]
00007f7c123d6adc  mov esi, 0x00
00007f7c123d6ae1  mov rax, 0x5E723D793530
00007f7c123d6aeb  call rax
00007f7c123d6aed  movaps xmm9, [rsp]
00007f7c123d6af2  add rsp, 0x30
00007f7c123d6af6  vmovaps xmm0, [rsp]
00007f7c123d6afb  vmovaps xmm1, [rsp+0x10]
00007f7c123d6b01  vmovaps xmm2, [rsp+0x20]
00007f7c123d6b07  vmovaps xmm3, [rsp+0x30]
00007f7c123d6b0d  vmovaps xmm4, [rsp+0x40]
00007f7c123d6b13  vmovaps xmm5, [rsp+0x50]
00007f7c123d6b19  vmovaps xmm6, [rsp+0x60]
00007f7c123d6b1f  vmovaps xmm7, [rsp+0x70]
00007f7c123d6b25  vmovaps xmm8, [rsp+0x80]
00007f7c123d6b2e  vmovaps xmm10, [rsp+0x90]
00007f7c123d6b37  vmovaps xmm11, [rsp+0xA0]
00007f7c123d6b40  vmovaps xmm12, [rsp+0xB0]
00007f7c123d6b49  vmovaps xmm13, [rsp+0xC0]
00007f7c123d6b52  vmovaps xmm14, [rsp+0xD0]
00007f7c123d6b5b  vmovaps xmm15, [rsp+0xE0]
00007f7c123d6b64  add rsp, 0xF0
00007f7c123d6b6b  pop r11
00007f7c123d6b6d  pop r10
00007f7c123d6b6f  pop r9
00007f7c123d6b71  pop r8
00007f7c123d6b73  pop rsi
00007f7c123d6b74  pop rdi
00007f7c123d6b75  pop rdx
00007f7c123d6b76  pop rcx
00007f7c123d6b77  pop rax
00007f7c123d6b78  add rsp, 0x08
00007f7c123d6b7c  jmp 0x00007F7C123D59EC
00007f7c123d6b81  sub rsp, 0x08
00007f7c123d6b85  push rax
00007f7c123d6b86  push rcx
00007f7c123d6b87  push rdx
00007f7c123d6b88  push rdi
00007f7c123d6b89  push rsi
00007f7c123d6b8a  push r8
00007f7c123d6b8c  push r9
00007f7c123d6b8e  push r10
00007f7c123d6b90  push r11
00007f7c123d6b92  sub rsp, 0xF0
00007f7c123d6b99  vmovaps [rsp], xmm0
00007f7c123d6b9e  vmovaps [rsp+0x10], xmm1
00007f7c123d6ba4  vmovaps [rsp+0x20], xmm2
00007f7c123d6baa  vmovaps [rsp+0x30], xmm3
00007f7c123d6bb0  vmovaps [rsp+0x40], xmm4
00007f7c123d6bb6  vmovaps [rsp+0x50], xmm5
00007f7c123d6bbc  vmovaps [rsp+0x60], xmm6
00007f7c123d6bc2  vmovaps [rsp+0x70], xmm7
00007f7c123d6bc8  vmovaps [rsp+0x80], xmm8
00007f7c123d6bd1  vmovaps [rsp+0x90], xmm9
00007f7c123d6bda  vmovaps [rsp+0xA0], xmm11
00007f7c123d6be3  vmovaps [rsp+0xB0], xmm12
00007f7c123d6bec  vmovaps [rsp+0xC0], xmm13
00007f7c123d6bf5  vmovaps [rsp+0xD0], xmm14
00007f7c123d6bfe  vmovaps [rsp+0xE0], xmm15
00007f7c123d6c07  sub rsp, 0x30
00007f7c123d6c0b  movaps [rsp], xmm10
00007f7c123d6c10  movaps [rsp+0x10], xmm12
00007f7c123d6c16  movaps [rsp+0x20], xmm11
00007f7c123d6c1c  lea rdi, [rsp]
00007f7c123d6c20  mov esi, 0x00
00007f7c123d6c25  mov rax, 0x5E723D793530
00007f7c123d6c2f  call rax
00007f7c123d6c31  movaps xmm10, [rsp]
00007f7c123d6c36  add rsp, 0x30
00007f7c123d6c3a  vmovaps xmm0, [rsp]
00007f7c123d6c3f  vmovaps xmm1, [rsp+0x10]
00007f7c123d6c45  vmovaps xmm2, [rsp+0x20]
00007f7c123d6c4b  vmovaps xmm3, [rsp+0x30]
00007f7c123d6c51  vmovaps xmm4, [rsp+0x40]
00007f7c123d6c57  vmovaps xmm5, [rsp+0x50]
00007f7c123d6c5d  vmovaps xmm6, [rsp+0x60]
00007f7c123d6c63  vmovaps xmm7, [rsp+0x70]
00007f7c123d6c69  vmovaps xmm8, [rsp+0x80]
00007f7c123d6c72  vmovaps xmm9, [rsp+0x90]
00007f7c123d6c7b  vmovaps xmm11, [rsp+0xA0]
00007f7c123d6c84  vmovaps xmm12, [rsp+0xB0]
00007f7c123d6c8d  vmovaps xmm13, [rsp+0xC0]
00007f7c123d6c96  vmovaps xmm14, [rsp+0xD0]
00007f7c123d6c9f  vmovaps xmm15, [rsp+0xE0]
00007f7c123d6ca8  add rsp, 0xF0
00007f7c123d6caf  pop r11
00007f7c123d6cb1  pop r10
00007f7c123d6cb3  pop r9
00007f7c123d6cb5  pop r8
00007f7c123d6cb7  pop rsi
00007f7c123d6cb8  pop rdi
00007f7c123d6cb9  pop rdx
00007f7c123d6cba  pop rcx
00007f7c123d6cbb  pop rax
00007f7c123d6cbc  add rsp, 0x08
00007f7c123d6cc0  jmp 0x00007F7C123D5A06
00007f7c123d6cc5  sub rsp, 0x08
00007f7c123d6cc9  push rax
00007f7c123d6cca  push rcx
00007f7c123d6ccb  push rdx
00007f7c123d6ccc  push rdi
00007f7c123d6ccd  push rsi
00007f7c123d6cce  push r8
00007f7c123d6cd0  push r9
00007f7c123d6cd2  push r10
00007f7c123d6cd4  push r11
00007f7c123d6cd6  sub rsp, 0xF0
00007f7c123d6cdd  vmovaps [rsp], xmm0
00007f7c123d6ce2  vmovaps [rsp+0x10], xmm1
00007f7c123d6ce8  vmovaps [rsp+0x20], xmm2
00007f7c123d6cee  vmovaps [rsp+0x30], xmm3
00007f7c123d6cf4  vmovaps [rsp+0x40], xmm4
00007f7c123d6cfa  vmovaps [rsp+0x50], xmm5
00007f7c123d6d00  vmovaps [rsp+0x60], xmm7
00007f7c123d6d06  vmovaps [rsp+0x70], xmm8
00007f7c123d6d0c  vmovaps [rsp+0x80], xmm9
00007f7c123d6d15  vmovaps [rsp+0x90], xmm10
00007f7c123d6d1e  vmovaps [rsp+0xA0], xmm11
00007f7c123d6d27  vmovaps [rsp+0xB0], xmm12
00007f7c123d6d30  vmovaps [rsp+0xC0], xmm13
00007f7c123d6d39  vmovaps [rsp+0xD0], xmm14
00007f7c123d6d42  vmovaps [rsp+0xE0], xmm15
00007f7c123d6d4b  sub rsp, 0x30
00007f7c123d6d4f  movaps [rsp], xmm6
00007f7c123d6d53  movaps [rsp+0x10], xmm12
00007f7c123d6d59  movaps [rsp+0x20], xmm11
00007f7c123d6d5f  lea rdi, [rsp]
00007f7c123d6d63  mov esi, 0x00
00007f7c123d6d68  mov rax, 0x5E723D793530
00007f7c123d6d72  call rax
00007f7c123d6d74  movaps xmm6, [rsp]
00007f7c123d6d78  add rsp, 0x30
00007f7c123d6d7c  vmovaps xmm0, [rsp]
00007f7c123d6d81  vmovaps xmm1, [rsp+0x10]
00007f7c123d6d87  vmovaps xmm2, [rsp+0x20]
00007f7c123d6d8d  vmovaps xmm3, [rsp+0x30]
00007f7c123d6d93  vmovaps xmm4, [rsp+0x40]
00007f7c123d6d99  vmovaps xmm5, [rsp+0x50]
00007f7c123d6d9f  vmovaps xmm7, [rsp+0x60]
00007f7c123d6da5  vmovaps xmm8, [rsp+0x70]
00007f7c123d6dab  vmovaps xmm9, [rsp+0x80]
00007f7c123d6db4  vmovaps xmm10, [rsp+0x90]
00007f7c123d6dbd  vmovaps xmm11, [rsp+0xA0]
00007f7c123d6dc6  vmovaps xmm12, [rsp+0xB0]
00007f7c123d6dcf  vmovaps xmm13, [rsp+0xC0]
00007f7c123d6dd8  vmovaps xmm14, [rsp+0xD0]
00007f7c123d6de1  vmovaps xmm15, [rsp+0xE0]
00007f7c123d6dea  add rsp, 0xF0
00007f7c123d6df1  pop r11
00007f7c123d6df3  pop r10
00007f7c123d6df5  pop r9
00007f7c123d6df7  pop r8
00007f7c123d6df9  pop rsi
00007f7c123d6dfa  pop rdi
00007f7c123d6dfb  pop rdx
00007f7c123d6dfc  pop rcx
00007f7c123d6dfd  pop rax
00007f7c123d6dfe  add rsp, 0x08
00007f7c123d6e02  jmp 0x00007F7C123D5A27
00007f7c123d6e07  sub rsp, 0x08
00007f7c123d6e0b  push rax
00007f7c123d6e0c  push rcx
00007f7c123d6e0d  push rdx
00007f7c123d6e0e  push rdi
00007f7c123d6e0f  push rsi
00007f7c123d6e10  push r8
00007f7c123d6e12  push r9
00007f7c123d6e14  push r10
00007f7c123d6e16  push r11
00007f7c123d6e18  sub rsp, 0xF0
00007f7c123d6e1f  vmovaps [rsp], xmm0
00007f7c123d6e24  vmovaps [rsp+0x10], xmm1
00007f7c123d6e2a  vmovaps [rsp+0x20], xmm2
00007f7c123d6e30  vmovaps [rsp+0x30], xmm4
00007f7c123d6e36  vmovaps [rsp+0x40], xmm5
00007f7c123d6e3c  vmovaps [rsp+0x50], xmm6
00007f7c123d6e42  vmovaps [rsp+0x60], xmm7
00007f7c123d6e48  vmovaps [rsp+0x70], xmm8
00007f7c123d6e4e  vmovaps [rsp+0x80], xmm9
00007f7c123d6e57  vmovaps [rsp+0x90], xmm10
00007f7c123d6e60  vmovaps [rsp+0xA0], xmm11
00007f7c123d6e69  vmovaps [rsp+0xB0], xmm12
00007f7c123d6e72  vmovaps [rsp+0xC0], xmm13
00007f7c123d6e7b  vmovaps [rsp+0xD0], xmm14
00007f7c123d6e84  vmovaps [rsp+0xE0], xmm15
00007f7c123d6e8d  sub rsp, 0x30
00007f7c123d6e91  movaps [rsp], xmm3
00007f7c123d6e95  movaps [rsp+0x10], xmm5
00007f7c123d6e9a  movaps [rsp+0x20], xmm4
00007f7c123d6e9f  lea rdi, [rsp]
00007f7c123d6ea3  mov esi, 0x00
00007f7c123d6ea8  mov rax, 0x5E723D793530
00007f7c123d6eb2  call rax
00007f7c123d6eb4  movaps xmm3, [rsp]
00007f7c123d6eb8  add rsp, 0x30
00007f7c123d6ebc  vmovaps xmm0, [rsp]
00007f7c123d6ec1  vmovaps xmm1, [rsp+0x10]
00007f7c123d6ec7  vmovaps xmm2, [rsp+0x20]
00007f7c123d6ecd  vmovaps xmm4, [rsp+0x30]
00007f7c123d6ed3  vmovaps xmm5, [rsp+0x40]
00007f7c123d6ed9  vmovaps xmm6, [rsp+0x50]
00007f7c123d6edf  vmovaps xmm7, [rsp+0x60]
00007f7c123d6ee5  vmovaps xmm8, [rsp+0x70]
00007f7c123d6eeb  vmovaps xmm9, [rsp+0x80]
00007f7c123d6ef4  vmovaps xmm10, [rsp+0x90]
00007f7c123d6efd  vmovaps xmm11, [rsp+0xA0]
00007f7c123d6f06  vmovaps xmm12, [rsp+0xB0]
00007f7c123d6f0f  vmovaps xmm13, [rsp+0xC0]
00007f7c123d6f18  vmovaps xmm14, [rsp+0xD0]
00007f7c123d6f21  vmovaps xmm15, [rsp+0xE0]
00007f7c123d6f2a  add rsp, 0xF0
00007f7c123d6f31  pop r11
00007f7c123d6f33  pop r10
00007f7c123d6f35  pop r9
00007f7c123d6f37  pop r8
00007f7c123d6f39  pop rsi
00007f7c123d6f3a  pop rdi
00007f7c123d6f3b  pop rdx
00007f7c123d6f3c  pop rcx
00007f7c123d6f3d  pop rax
00007f7c123d6f3e  add rsp, 0x08
00007f7c123d6f42  jmp 0x00007F7C123D5A88
00007f7c123d6f47  sub rsp, 0x08
00007f7c123d6f4b  push rax
00007f7c123d6f4c  push rcx
00007f7c123d6f4d  push rdx
00007f7c123d6f4e  push rdi
00007f7c123d6f4f  push rsi
00007f7c123d6f50  push r8
00007f7c123d6f52  push r9
00007f7c123d6f54  push r10
00007f7c123d6f56  push r11
00007f7c123d6f58  sub rsp, 0xF0
00007f7c123d6f5f  vmovaps [rsp], xmm0
00007f7c123d6f64  vmovaps [rsp+0x10], xmm1
00007f7c123d6f6a  vmovaps [rsp+0x20], xmm2
00007f7c123d6f70  vmovaps [rsp+0x30], xmm3
00007f7c123d6f76  vmovaps [rsp+0x40], xmm4
00007f7c123d6f7c  vmovaps [rsp+0x50], xmm6
00007f7c123d6f82  vmovaps [rsp+0x60], xmm7
00007f7c123d6f88  vmovaps [rsp+0x70], xmm8
00007f7c123d6f8e  vmovaps [rsp+0x80], xmm9
00007f7c123d6f97  vmovaps [rsp+0x90], xmm10
00007f7c123d6fa0  vmovaps [rsp+0xA0], xmm11
00007f7c123d6fa9  vmovaps [rsp+0xB0], xmm12
00007f7c123d6fb2  vmovaps [rsp+0xC0], xmm13
00007f7c123d6fbb  vmovaps [rsp+0xD0], xmm14
00007f7c123d6fc4  vmovaps [rsp+0xE0], xmm15
00007f7c123d6fcd  sub rsp, 0x30
00007f7c123d6fd1  movaps [rsp], xmm5
00007f7c123d6fd5  movaps [rsp+0x10], xmm8
00007f7c123d6fdb  movaps [rsp+0x20], xmm15
00007f7c123d6fe1  lea rdi, [rsp]
00007f7c123d6fe5  mov esi, 0x00
00007f7c123d6fea  mov rax, 0x5E723D793530
00007f7c123d6ff4  call rax
00007f7c123d6ff6  movaps xmm5, [rsp]
00007f7c123d6ffa  add rsp, 0x30
00007f7c123d6ffe  vmovaps xmm0, [rsp]
00007f7c123d7003  vmovaps xmm1, [rsp+0x10]
00007f7c123d7009  vmovaps xmm2, [rsp+0x20]
00007f7c123d700f  vmovaps xmm3, [rsp+0x30]
00007f7c123d7015  vmovaps xmm4, [rsp+0x40]
00007f7c123d701b  vmovaps xmm6, [rsp+0x50]
00007f7c123d7021  vmovaps xmm7, [rsp+0x60]
00007f7c123d7027  vmovaps xmm8, [rsp+0x70]
00007f7c123d702d  vmovaps xmm9, [rsp+0x80]
00007f7c123d7036  vmovaps xmm10, [rsp+0x90]
00007f7c123d703f  vmovaps xmm11, [rsp+0xA0]
00007f7c123d7048  vmovaps xmm12, [rsp+0xB0]
00007f7c123d7051  vmovaps xmm13, [rsp+0xC0]
00007f7c123d705a  vmovaps xmm14, [rsp+0xD0]
00007f7c123d7063  vmovaps xmm15, [rsp+0xE0]
00007f7c123d706c  add rsp, 0xF0
00007f7c123d7073  pop r11
00007f7c123d7075  pop r10
00007f7c123d7077  pop r9
00007f7c123d7079  pop r8
00007f7c123d707b  pop rsi
00007f7c123d707c  pop rdi
00007f7c123d707d  pop rdx
00007f7c123d707e  pop rcx
00007f7c123d707f  pop rax
00007f7c123d7080  add rsp, 0x08
00007f7c123d7084  jmp 0x00007F7C123D5AC0
00007f7c123d7089  sub rsp, 0x08
00007f7c123d708d  push rax
00007f7c123d708e  push rcx
00007f7c123d708f  push rdx
00007f7c123d7090  push rdi
00007f7c123d7091  push rsi
00007f7c123d7092  push r8
00007f7c123d7094  push r9
00007f7c123d7096  push r10
00007f7c123d7098  push r11
00007f7c123d709a  sub rsp, 0xF0
00007f7c123d70a1  vmovaps [rsp], xmm0
00007f7c123d70a6  vmovaps [rsp+0x10], xmm1
00007f7c123d70ac  vmovaps [rsp+0x20], xmm2
00007f7c123d70b2  vmovaps [rsp+0x30], xmm3
00007f7c123d70b8  vmovaps [rsp+0x40], xmm5
00007f7c123d70be  vmovaps [rsp+0x50], xmm6
00007f7c123d70c4  vmovaps [rsp+0x60], xmm7
00007f7c123d70ca  vmovaps [rsp+0x70], xmm8
00007f7c123d70d0  vmovaps [rsp+0x80], xmm9
00007f7c123d70d9  vmovaps [rsp+0x90], xmm10
00007f7c123d70e2  vmovaps [rsp+0xA0], xmm11
00007f7c123d70eb  vmovaps [rsp+0xB0], xmm12
00007f7c123d70f4  vmovaps [rsp+0xC0], xmm13
00007f7c123d70fd  vmovaps [rsp+0xD0], xmm14
00007f7c123d7106  vmovaps [rsp+0xE0], xmm15
00007f7c123d710f  sub rsp, 0x30
00007f7c123d7113  movaps [rsp], xmm4
00007f7c123d7117  movaps [rsp+0x10], xmm9
00007f7c123d711d  movaps [rsp+0x20], xmm8
00007f7c123d7123  lea rdi, [rsp]
00007f7c123d7127  mov esi, 0x00
00007f7c123d712c  mov rax, 0x5E723D793530
00007f7c123d7136  call rax
00007f7c123d7138  movaps xmm4, [rsp]
00007f7c123d713c  add rsp, 0x30
00007f7c123d7140  vmovaps xmm0, [rsp]
00007f7c123d7145  vmovaps xmm1, [rsp+0x10]
00007f7c123d714b  vmovaps xmm2, [rsp+0x20]
00007f7c123d7151  vmovaps xmm3, [rsp+0x30]
00007f7c123d7157  vmovaps xmm5, [rsp+0x40]
00007f7c123d715d  vmovaps xmm6, [rsp+0x50]
00007f7c123d7163  vmovaps xmm7, [rsp+0x60]
00007f7c123d7169  vmovaps xmm8, [rsp+0x70]
00007f7c123d716f  vmovaps xmm9, [rsp+0x80]
00007f7c123d7178  vmovaps xmm10, [rsp+0x90]
00007f7c123d7181  vmovaps xmm11, [rsp+0xA0]
00007f7c123d718a  vmovaps xmm12, [rsp+0xB0]
00007f7c123d7193  vmovaps xmm13, [rsp+0xC0]
00007f7c123d719c  vmovaps xmm14, [rsp+0xD0]
00007f7c123d71a5  vmovaps xmm15, [rsp+0xE0]
00007f7c123d71ae  add rsp, 0xF0
00007f7c123d71b5  pop r11
00007f7c123d71b7  pop r10
00007f7c123d71b9  pop r9
00007f7c123d71bb  pop r8
00007f7c123d71bd  pop rsi
00007f7c123d71be  pop rdi
00007f7c123d71bf  pop rdx
00007f7c123d71c0  pop rcx
00007f7c123d71c1  pop rax
00007f7c123d71c2  add rsp, 0x08
00007f7c123d71c6  jmp 0x00007F7C123D5AE1
00007f7c123d71cb  sub rsp, 0x08
00007f7c123d71cf  push rax
00007f7c123d71d0  push rcx
00007f7c123d71d1  push rdx
00007f7c123d71d2  push rdi
00007f7c123d71d3  push rsi
00007f7c123d71d4  push r8
00007f7c123d71d6  push r9
00007f7c123d71d8  push r10
00007f7c123d71da  push r11
00007f7c123d71dc  sub rsp, 0xF0
00007f7c123d71e3  vmovaps [rsp], xmm0
00007f7c123d71e8  vmovaps [rsp+0x10], xmm1
00007f7c123d71ee  vmovaps [rsp+0x20], xmm2
00007f7c123d71f4  vmovaps [rsp+0x30], xmm3
00007f7c123d71fa  vmovaps [rsp+0x40], xmm4
00007f7c123d7200  vmovaps [rsp+0x50], xmm5
00007f7c123d7206  vmovaps [rsp+0x60], xmm6
00007f7c123d720c  vmovaps [rsp+0x70], xmm7
00007f7c123d7212  vmovaps [rsp+0x80], xmm8
00007f7c123d721b  vmovaps [rsp+0x90], xmm10
00007f7c123d7224  vmovaps [rsp+0xA0], xmm11
00007f7c123d722d  vmovaps [rsp+0xB0], xmm12
00007f7c123d7236  vmovaps [rsp+0xC0], xmm13
00007f7c123d723f  vmovaps [rsp+0xD0], xmm14
00007f7c123d7248  vmovaps [rsp+0xE0], xmm15
00007f7c123d7251  sub rsp, 0x30
00007f7c123d7255  movaps [rsp], xmm9
00007f7c123d725a  movaps [rsp+0x10], xmm10
00007f7c123d7260  movaps [rsp+0x20], xmm8
00007f7c123d7266  lea rdi, [rsp]
00007f7c123d726a  mov esi, 0x00
00007f7c123d726f  mov rax, 0x5E723D793530
00007f7c123d7279  call rax
00007f7c123d727b  movaps xmm9, [rsp]
00007f7c123d7280  add rsp, 0x30
00007f7c123d7284  vmovaps xmm0, [rsp]
00007f7c123d7289  vmovaps xmm1, [rsp+0x10]
00007f7c123d728f  vmovaps xmm2, [rsp+0x20]
00007f7c123d7295  vmovaps xmm3, [rsp+0x30]
00007f7c123d729b  vmovaps xmm4, [rsp+0x40]
00007f7c123d72a1  vmovaps xmm5, [rsp+0x50]
00007f7c123d72a7  vmovaps xmm6, [rsp+0x60]
00007f7c123d72ad  vmovaps xmm7, [rsp+0x70]
00007f7c123d72b3  vmovaps xmm8, [rsp+0x80]
00007f7c123d72bc  vmovaps xmm10, [rsp+0x90]
00007f7c123d72c5  vmovaps xmm11, [rsp+0xA0]
00007f7c123d72ce  vmovaps xmm12, [rsp+0xB0]
00007f7c123d72d7  vmovaps xmm13, [rsp+0xC0]
00007f7c123d72e0  vmovaps xmm14, [rsp+0xD0]
00007f7c123d72e9  vmovaps xmm15, [rsp+0xE0]
00007f7c123d72f2  add rsp, 0xF0
00007f7c123d72f9  pop r11
00007f7c123d72fb  pop r10
00007f7c123d72fd  pop r9
00007f7c123d72ff  pop r8
00007f7c123d7301  pop rsi
00007f7c123d7302  pop rdi
00007f7c123d7303  pop rdx
00007f7c123d7304  pop rcx
00007f7c123d7305  pop rax
00007f7c123d7306  add rsp, 0x08
00007f7c123d730a  jmp 0x00007F7C123D5AFB
00007f7c123d730f  call 0x00007F7C122D64F0
00007f7c123d7314  jmp 0x00007F7C123D5C15
00007f7c123d7319  call 0x00007F7C122D64F0
00007f7c123d731e  jmp 0x00007F7C123D5C2B
00007f7c123d7323  sub rsp, 0x08
00007f7c123d7327  push rax
00007f7c123d7328  push rcx
00007f7c123d7329  push rdx
00007f7c123d732a  push rdi
00007f7c123d732b  push rsi
00007f7c123d732c  push r8
00007f7c123d732e  push r9
00007f7c123d7330  push r10
00007f7c123d7332  push r11
00007f7c123d7334  sub rsp, 0xF0
00007f7c123d733b  vmovaps [rsp], xmm0
00007f7c123d7340  vmovaps [rsp+0x10], xmm2
00007f7c123d7346  vmovaps [rsp+0x20], xmm3
00007f7c123d734c  vmovaps [rsp+0x30], xmm4
00007f7c123d7352  vmovaps [rsp+0x40], xmm5
00007f7c123d7358  vmovaps [rsp+0x50], xmm6
00007f7c123d735e  vmovaps [rsp+0x60], xmm7
00007f7c123d7364  vmovaps [rsp+0x70], xmm8
00007f7c123d736a  vmovaps [rsp+0x80], xmm9
00007f7c123d7373  vmovaps [rsp+0x90], xmm10
00007f7c123d737c  vmovaps [rsp+0xA0], xmm11
00007f7c123d7385  vmovaps [rsp+0xB0], xmm12
00007f7c123d738e  vmovaps [rsp+0xC0], xmm13
00007f7c123d7397  vmovaps [rsp+0xD0], xmm14
00007f7c123d73a0  vmovaps [rsp+0xE0], xmm15
00007f7c123d73a9  sub rsp, 0x30
00007f7c123d73ad  movaps [rsp], xmm1
00007f7c123d73b1  movaps [rsp+0x10], xmm6
00007f7c123d73b6  movaps [rsp+0x20], xmm15
00007f7c123d73bc  lea rdi, [rsp]
00007f7c123d73c0  mov esi, 0x00
00007f7c123d73c5  mov rax, 0x5E723D793530
00007f7c123d73cf  call rax
00007f7c123d73d1  movaps xmm1, [rsp]
00007f7c123d73d5  add rsp, 0x30
00007f7c123d73d9  vmovaps xmm0, [rsp]
00007f7c123d73de  vmovaps xmm2, [rsp+0x10]
00007f7c123d73e4  vmovaps xmm3, [rsp+0x20]
00007f7c123d73ea  vmovaps xmm4, [rsp+0x30]
00007f7c123d73f0  vmovaps xmm5, [rsp+0x40]
00007f7c123d73f6  vmovaps xmm6, [rsp+0x50]
00007f7c123d73fc  vmovaps xmm7, [rsp+0x60]
00007f7c123d7402  vmovaps xmm8, [rsp+0x70]
00007f7c123d7408  vmovaps xmm9, [rsp+0x80]
00007f7c123d7411  vmovaps xmm10, [rsp+0x90]
00007f7c123d741a  vmovaps xmm11, [rsp+0xA0]
00007f7c123d7423  vmovaps xmm12, [rsp+0xB0]
00007f7c123d742c  vmovaps xmm13, [rsp+0xC0]
00007f7c123d7435  vmovaps xmm14, [rsp+0xD0]
00007f7c123d743e  vmovaps xmm15, [rsp+0xE0]
00007f7c123d7447  add rsp, 0xF0
00007f7c123d744e  pop r11
00007f7c123d7450  pop r10
00007f7c123d7452  pop r9
00007f7c123d7454  pop r8
00007f7c123d7456  pop rsi
00007f7c123d7457  pop rdi
00007f7c123d7458  pop rdx
00007f7c123d7459  pop rcx
00007f7c123d745a  pop rax
00007f7c123d745b  add rsp, 0x08
00007f7c123d745f  jmp 0x00007F7C123D5C68
00007f7c123d7464  call 0x00007F7C122E5820
00007f7c123d7469  jmp 0x00007F7C123D5C75
00007f7c123d746e  sub rsp, 0x08
00007f7c123d7472  push rax
00007f7c123d7473  push rcx
00007f7c123d7474  push rdx
00007f7c123d7475  push rdi
00007f7c123d7476  push rsi
00007f7c123d7477  push r8
00007f7c123d7479  push r9
00007f7c123d747b  push r10
00007f7c123d747d  push r11
00007f7c123d747f  sub rsp, 0xF0
00007f7c123d7486  vmovaps [rsp], xmm0
00007f7c123d748b  vmovaps [rsp+0x10], xmm1
00007f7c123d7491  vmovaps [rsp+0x20], xmm2
00007f7c123d7497  vmovaps [rsp+0x30], xmm3
00007f7c123d749d  vmovaps [rsp+0x40], xmm4
00007f7c123d74a3  vmovaps [rsp+0x50], xmm5
00007f7c123d74a9  vmovaps [rsp+0x60], xmm6
00007f7c123d74af  vmovaps [rsp+0x70], xmm7
00007f7c123d74b5  vmovaps [rsp+0x80], xmm8
00007f7c123d74be  vmovaps [rsp+0x90], xmm9
00007f7c123d74c7  vmovaps [rsp+0xA0], xmm10
00007f7c123d74d0  vmovaps [rsp+0xB0], xmm11
00007f7c123d74d9  vmovaps [rsp+0xC0], xmm12
00007f7c123d74e2  vmovaps [rsp+0xD0], xmm13
00007f7c123d74eb  vmovaps [rsp+0xE0], xmm15
00007f7c123d74f4  sub rsp, 0x30
00007f7c123d74f8  movaps [rsp], xmm14
00007f7c123d74fd  movaps [rsp+0x10], xmm4
00007f7c123d7502  movaps [rsp+0x20], xmm3
00007f7c123d7507  lea rdi, [rsp]
00007f7c123d750b  mov esi, 0x00
00007f7c123d7510  mov rax, 0x5E723D793530
00007f7c123d751a  call rax
00007f7c123d751c  movaps xmm14, [rsp]
00007f7c123d7521  add rsp, 0x30
00007f7c123d7525  vmovaps xmm0, [rsp]
00007f7c123d752a  vmovaps xmm1, [rsp+0x10]
00007f7c123d7530  vmovaps xmm2, [rsp+0x20]
00007f7c123d7536  vmovaps xmm3, [rsp+0x30]
00007f7c123d753c  vmovaps xmm4, [rsp+0x40]
00007f7c123d7542  vmovaps xmm5, [rsp+0x50]
00007f7c123d7548  vmovaps xmm6, [rsp+0x60]
00007f7c123d754e  vmovaps xmm7, [rsp+0x70]
00007f7c123d7554  vmovaps xmm8, [rsp+0x80]
00007f7c123d755d  vmovaps xmm9, [rsp+0x90]
00007f7c123d7566  vmovaps xmm10, [rsp+0xA0]
00007f7c123d756f  vmovaps xmm11, [rsp+0xB0]
00007f7c123d7578  vmovaps xmm12, [rsp+0xC0]
00007f7c123d7581  vmovaps xmm13, [rsp+0xD0]
00007f7c123d758a  vmovaps xmm15, [rsp+0xE0]
00007f7c123d7593  add rsp, 0xF0
00007f7c123d759a  pop r11
00007f7c123d759c  pop r10
00007f7c123d759e  pop r9
00007f7c123d75a0  pop r8
00007f7c123d75a2  pop rsi
00007f7c123d75a3  pop rdi
00007f7c123d75a4  pop rdx
00007f7c123d75a5  pop rcx
00007f7c123d75a6  pop rax
00007f7c123d75a7  add rsp, 0x08
00007f7c123d75ab  jmp 0x00007F7C123D5C8F
00007f7c123d75b0  sub rsp, 0x08
00007f7c123d75b4  push rax
00007f7c123d75b5  push rcx
00007f7c123d75b6  push rdx
00007f7c123d75b7  push rdi
00007f7c123d75b8  push rsi
00007f7c123d75b9  push r8
00007f7c123d75bb  push r9
00007f7c123d75bd  push r10
00007f7c123d75bf  push r11
00007f7c123d75c1  sub rsp, 0xF0
00007f7c123d75c8  vmovaps [rsp], xmm0
00007f7c123d75cd  vmovaps [rsp+0x10], xmm1
00007f7c123d75d3  vmovaps [rsp+0x20], xmm2
00007f7c123d75d9  vmovaps [rsp+0x30], xmm3
00007f7c123d75df  vmovaps [rsp+0x40], xmm4
00007f7c123d75e5  vmovaps [rsp+0x50], xmm5
00007f7c123d75eb  vmovaps [rsp+0x60], xmm7
00007f7c123d75f1  vmovaps [rsp+0x70], xmm8
00007f7c123d75f7  vmovaps [rsp+0x80], xmm9
00007f7c123d7600  vmovaps [rsp+0x90], xmm10
00007f7c123d7609  vmovaps [rsp+0xA0], xmm11
00007f7c123d7612  vmovaps [rsp+0xB0], xmm12
00007f7c123d761b  vmovaps [rsp+0xC0], xmm13
00007f7c123d7624  vmovaps [rsp+0xD0], xmm14
00007f7c123d762d  vmovaps [rsp+0xE0], xmm15
00007f7c123d7636  sub rsp, 0x30
00007f7c123d763a  movaps [rsp], xmm6
00007f7c123d763e  movaps [rsp+0x10], xmm9
00007f7c123d7644  movaps [rsp+0x20], xmm7
00007f7c123d7649  lea rdi, [rsp]
00007f7c123d764d  mov esi, 0x00
00007f7c123d7652  mov rax, 0x5E723D793530
00007f7c123d765c  call rax
00007f7c123d765e  movaps xmm6, [rsp]
00007f7c123d7662  add rsp, 0x30
00007f7c123d7666  vmovaps xmm0, [rsp]
00007f7c123d766b  vmovaps xmm1, [rsp+0x10]
00007f7c123d7671  vmovaps xmm2, [rsp+0x20]
00007f7c123d7677  vmovaps xmm3, [rsp+0x30]
00007f7c123d767d  vmovaps xmm4, [rsp+0x40]
00007f7c123d7683  vmovaps xmm5, [rsp+0x50]
00007f7c123d7689  vmovaps xmm7, [rsp+0x60]
00007f7c123d768f  vmovaps xmm8, [rsp+0x70]
00007f7c123d7695  vmovaps xmm9, [rsp+0x80]
00007f7c123d769e  vmovaps xmm10, [rsp+0x90]
00007f7c123d76a7  vmovaps xmm11, [rsp+0xA0]
00007f7c123d76b0  vmovaps xmm12, [rsp+0xB0]
00007f7c123d76b9  vmovaps xmm13, [rsp+0xC0]
00007f7c123d76c2  vmovaps xmm14, [rsp+0xD0]
00007f7c123d76cb  vmovaps xmm15, [rsp+0xE0]
00007f7c123d76d4  add rsp, 0xF0
00007f7c123d76db  pop r11
00007f7c123d76dd  pop r10
00007f7c123d76df  pop r9
00007f7c123d76e1  pop r8
00007f7c123d76e3  pop rsi
00007f7c123d76e4  pop rdi
00007f7c123d76e5  pop rdx
00007f7c123d76e6  pop rcx
00007f7c123d76e7  pop rax
00007f7c123d76e8  add rsp, 0x08
00007f7c123d76ec  jmp 0x00007F7C123D5CA7
00007f7c123d76f1  sub rsp, 0x08
00007f7c123d76f5  push rax
00007f7c123d76f6  push rcx
00007f7c123d76f7  push rdx
00007f7c123d76f8  push rdi
00007f7c123d76f9  push rsi
00007f7c123d76fa  push r8
00007f7c123d76fc  push r9
00007f7c123d76fe  push r10
00007f7c123d7700  push r11
00007f7c123d7702  sub rsp, 0xF0
00007f7c123d7709  vmovaps [rsp], xmm0
00007f7c123d770e  vmovaps [rsp+0x10], xmm1
00007f7c123d7714  vmovaps [rsp+0x20], xmm2
00007f7c123d771a  vmovaps [rsp+0x30], xmm3
00007f7c123d7720  vmovaps [rsp+0x40], xmm4
00007f7c123d7726  vmovaps [rsp+0x50], xmm5
00007f7c123d772c  vmovaps [rsp+0x60], xmm6
00007f7c123d7732  vmovaps [rsp+0x70], xmm8
00007f7c123d7738  vmovaps [rsp+0x80], xmm9
00007f7c123d7741  vmovaps [rsp+0x90], xmm10
00007f7c123d774a  vmovaps [rsp+0xA0], xmm11
00007f7c123d7753  vmovaps [rsp+0xB0], xmm12
00007f7c123d775c  vmovaps [rsp+0xC0], xmm13
00007f7c123d7765  vmovaps [rsp+0xD0], xmm14
00007f7c123d776e  vmovaps [rsp+0xE0], xmm15
00007f7c123d7777  sub rsp, 0x30
00007f7c123d777b  movaps [rsp], xmm7
00007f7c123d777f  movaps [rsp+0x10], xmm4
00007f7c123d7784  movaps [rsp+0x20], xmm9
00007f7c123d778a  lea rdi, [rsp]
00007f7c123d778e  mov esi, 0x00
00007f7c123d7793  mov rax, 0x5E723D793530
00007f7c123d779d  call rax
00007f7c123d779f  movaps xmm7, [rsp]
00007f7c123d77a3  add rsp, 0x30
00007f7c123d77a7  vmovaps xmm0, [rsp]
00007f7c123d77ac  vmovaps xmm1, [rsp+0x10]
00007f7c123d77b2  vmovaps xmm2, [rsp+0x20]
00007f7c123d77b8  vmovaps xmm3, [rsp+0x30]
00007f7c123d77be  vmovaps xmm4, [rsp+0x40]
00007f7c123d77c4  vmovaps xmm5, [rsp+0x50]
00007f7c123d77ca  vmovaps xmm6, [rsp+0x60]
00007f7c123d77d0  vmovaps xmm8, [rsp+0x70]
00007f7c123d77d6  vmovaps xmm9, [rsp+0x80]
00007f7c123d77df  vmovaps xmm10, [rsp+0x90]
00007f7c123d77e8  vmovaps xmm11, [rsp+0xA0]
00007f7c123d77f1  vmovaps xmm12, [rsp+0xB0]
00007f7c123d77fa  vmovaps xmm13, [rsp+0xC0]
00007f7c123d7803  vmovaps xmm14, [rsp+0xD0]
00007f7c123d780c  vmovaps xmm15, [rsp+0xE0]
00007f7c123d7815  add rsp, 0xF0
00007f7c123d781c  pop r11
00007f7c123d781e  pop r10
00007f7c123d7820  pop r9
00007f7c123d7822  pop r8
00007f7c123d7824  pop rsi
00007f7c123d7825  pop rdi
00007f7c123d7826  pop rdx
00007f7c123d7827  pop rcx
00007f7c123d7828  pop rax
00007f7c123d7829  add rsp, 0x08
00007f7c123d782d  jmp 0x00007F7C123D5CD4
00007f7c123d7832  sub rsp, 0x08
00007f7c123d7836  push rax
00007f7c123d7837  push rcx
00007f7c123d7838  push rdx
00007f7c123d7839  push rdi
00007f7c123d783a  push rsi
00007f7c123d783b  push r8
00007f7c123d783d  push r9
00007f7c123d783f  push r10
00007f7c123d7841  push r11
00007f7c123d7843  sub rsp, 0xF0
00007f7c123d784a  vmovaps [rsp], xmm0
00007f7c123d784f  vmovaps [rsp+0x10], xmm1
00007f7c123d7855  vmovaps [rsp+0x20], xmm2
00007f7c123d785b  vmovaps [rsp+0x30], xmm3
00007f7c123d7861  vmovaps [rsp+0x40], xmm5
00007f7c123d7867  vmovaps [rsp+0x50], xmm6
00007f7c123d786d  vmovaps [rsp+0x60], xmm7
00007f7c123d7873  vmovaps [rsp+0x70], xmm8
00007f7c123d7879  vmovaps [rsp+0x80], xmm9
00007f7c123d7882  vmovaps [rsp+0x90], xmm10
00007f7c123d788b  vmovaps [rsp+0xA0], xmm11
00007f7c123d7894  vmovaps [rsp+0xB0], xmm12
00007f7c123d789d  vmovaps [rsp+0xC0], xmm13
00007f7c123d78a6  vmovaps [rsp+0xD0], xmm14
00007f7c123d78af  vmovaps [rsp+0xE0], xmm15
00007f7c123d78b8  sub rsp, 0x30
00007f7c123d78bc  movaps [rsp], xmm4
00007f7c123d78c0  movaps [rsp+0x10], xmm15
00007f7c123d78c6  movaps [rsp+0x20], xmm9
00007f7c123d78cc  lea rdi, [rsp]
00007f7c123d78d0  mov esi, 0x00
00007f7c123d78d5  mov rax, 0x5E723D793530
00007f7c123d78df  call rax
00007f7c123d78e1  movaps xmm4, [rsp]
00007f7c123d78e5  add rsp, 0x30
00007f7c123d78e9  vmovaps xmm0, [rsp]
00007f7c123d78ee  vmovaps xmm1, [rsp+0x10]
00007f7c123d78f4  vmovaps xmm2, [rsp+0x20]
00007f7c123d78fa  vmovaps xmm3, [rsp+0x30]
00007f7c123d7900  vmovaps xmm5, [rsp+0x40]
00007f7c123d7906  vmovaps xmm6, [rsp+0x50]
00007f7c123d790c  vmovaps xmm7, [rsp+0x60]
00007f7c123d7912  vmovaps xmm8, [rsp+0x70]
00007f7c123d7918  vmovaps xmm9, [rsp+0x80]
00007f7c123d7921  vmovaps xmm10, [rsp+0x90]
00007f7c123d792a  vmovaps xmm11, [rsp+0xA0]
00007f7c123d7933  vmovaps xmm12, [rsp+0xB0]
00007f7c123d793c  vmovaps xmm13, [rsp+0xC0]
00007f7c123d7945  vmovaps xmm14, [rsp+0xD0]
00007f7c123d794e  vmovaps xmm15, [rsp+0xE0]
00007f7c123d7957  add rsp, 0xF0
00007f7c123d795e  pop r11
00007f7c123d7960  pop r10
00007f7c123d7962  pop r9
00007f7c123d7964  pop r8
00007f7c123d7966  pop rsi
00007f7c123d7967  pop rdi
00007f7c123d7968  pop rdx
00007f7c123d7969  pop rcx
00007f7c123d796a  pop rax
00007f7c123d796b  add rsp, 0x08
00007f7c123d796f  jmp 0x00007F7C123D5CF9
00007f7c123d7974  call 0x00007F7C122E5820
00007f7c123d7979  jmp 0x00007F7C123D5D06
00007f7c123d797e  sub rsp, 0x08
00007f7c123d7982  push rax
00007f7c123d7983  push rcx
00007f7c123d7984  push rdx
00007f7c123d7985  push rdi
00007f7c123d7986  push rsi
00007f7c123d7987  push r8
00007f7c123d7989  push r9
00007f7c123d798b  push r10
00007f7c123d798d  push r11
00007f7c123d798f  sub rsp, 0xF0
00007f7c123d7996  vmovaps [rsp], xmm0
00007f7c123d799b  vmovaps [rsp+0x10], xmm1
00007f7c123d79a1  vmovaps [rsp+0x20], xmm2
00007f7c123d79a7  vmovaps [rsp+0x30], xmm4
00007f7c123d79ad  vmovaps [rsp+0x40], xmm5
00007f7c123d79b3  vmovaps [rsp+0x50], xmm6
00007f7c123d79b9  vmovaps [rsp+0x60], xmm7
00007f7c123d79bf  vmovaps [rsp+0x70], xmm8
00007f7c123d79c5  vmovaps [rsp+0x80], xmm9
00007f7c123d79ce  vmovaps [rsp+0x90], xmm10
00007f7c123d79d7  vmovaps [rsp+0xA0], xmm11
00007f7c123d79e0  vmovaps [rsp+0xB0], xmm12
00007f7c123d79e9  vmovaps [rsp+0xC0], xmm13
00007f7c123d79f2  vmovaps [rsp+0xD0], xmm14
00007f7c123d79fb  vmovaps [rsp+0xE0], xmm15
00007f7c123d7a04  sub rsp, 0x30
00007f7c123d7a08  movaps [rsp], xmm3
00007f7c123d7a0c  movaps [rsp+0x10], xmm1
00007f7c123d7a11  movaps [rsp+0x20], xmm9
00007f7c123d7a17  lea rdi, [rsp]
00007f7c123d7a1b  mov esi, 0x00
00007f7c123d7a20  mov rax, 0x5E723D793530
00007f7c123d7a2a  call rax
00007f7c123d7a2c  movaps xmm3, [rsp]
00007f7c123d7a30  add rsp, 0x30
00007f7c123d7a34  vmovaps xmm0, [rsp]
00007f7c123d7a39  vmovaps xmm1, [rsp+0x10]
00007f7c123d7a3f  vmovaps xmm2, [rsp+0x20]
00007f7c123d7a45  vmovaps xmm4, [rsp+0x30]
00007f7c123d7a4b  vmovaps xmm5, [rsp+0x40]
00007f7c123d7a51  vmovaps xmm6, [rsp+0x50]
00007f7c123d7a57  vmovaps xmm7, [rsp+0x60]
00007f7c123d7a5d  vmovaps xmm8, [rsp+0x70]
00007f7c123d7a63  vmovaps xmm9, [rsp+0x80]
00007f7c123d7a6c  vmovaps xmm10, [rsp+0x90]
00007f7c123d7a75  vmovaps xmm11, [rsp+0xA0]
00007f7c123d7a7e  vmovaps xmm12, [rsp+0xB0]
00007f7c123d7a87  vmovaps xmm13, [rsp+0xC0]
00007f7c123d7a90  vmovaps xmm14, [rsp+0xD0]
00007f7c123d7a99  vmovaps xmm15, [rsp+0xE0]
00007f7c123d7aa2  add rsp, 0xF0
00007f7c123d7aa9  pop r11
00007f7c123d7aab  pop r10
00007f7c123d7aad  pop r9
00007f7c123d7aaf  pop r8
00007f7c123d7ab1  pop rsi
00007f7c123d7ab2  pop rdi
00007f7c123d7ab3  pop rdx
00007f7c123d7ab4  pop rcx
00007f7c123d7ab5  pop rax
00007f7c123d7ab6  add rsp, 0x08
00007f7c123d7aba  jmp 0x00007F7C123D5D43
00007f7c123d7abf  sub rsp, 0x08
00007f7c123d7ac3  push rax
00007f7c123d7ac4  push rcx
00007f7c123d7ac5  push rdx
00007f7c123d7ac6  push rdi
00007f7c123d7ac7  push rsi
00007f7c123d7ac8  push r8
00007f7c123d7aca  push r9
00007f7c123d7acc  push r10
00007f7c123d7ace  push r11
00007f7c123d7ad0  sub rsp, 0xF0
00007f7c123d7ad7  vmovaps [rsp], xmm0
00007f7c123d7adc  vmovaps [rsp+0x10], xmm2
00007f7c123d7ae2  vmovaps [rsp+0x20], xmm3
00007f7c123d7ae8  vmovaps [rsp+0x30], xmm4
00007f7c123d7aee  vmovaps [rsp+0x40], xmm5
00007f7c123d7af4  vmovaps [rsp+0x50], xmm6
00007f7c123d7afa  vmovaps [rsp+0x60], xmm7
00007f7c123d7b00  vmovaps [rsp+0x70], xmm8
00007f7c123d7b06  vmovaps [rsp+0x80], xmm9
00007f7c123d7b0f  vmovaps [rsp+0x90], xmm10
00007f7c123d7b18  vmovaps [rsp+0xA0], xmm11
00007f7c123d7b21  vmovaps [rsp+0xB0], xmm12
00007f7c123d7b2a  vmovaps [rsp+0xC0], xmm13
00007f7c123d7b33  vmovaps [rsp+0xD0], xmm14
00007f7c123d7b3c  vmovaps [rsp+0xE0], xmm15
00007f7c123d7b45  sub rsp, 0x30
00007f7c123d7b49  movaps [rsp], xmm1
00007f7c123d7b4d  movaps [rsp+0x10], xmm15
00007f7c123d7b53  movaps [rsp+0x20], xmm9
00007f7c123d7b59  lea rdi, [rsp]
00007f7c123d7b5d  mov esi, 0x00
00007f7c123d7b62  mov rax, 0x5E723D793530
00007f7c123d7b6c  call rax
00007f7c123d7b6e  movaps xmm1, [rsp]
00007f7c123d7b72  add rsp, 0x30
00007f7c123d7b76  vmovaps xmm0, [rsp]
00007f7c123d7b7b  vmovaps xmm2, [rsp+0x10]
00007f7c123d7b81  vmovaps xmm3, [rsp+0x20]
00007f7c123d7b87  vmovaps xmm4, [rsp+0x30]
00007f7c123d7b8d  vmovaps xmm5, [rsp+0x40]
00007f7c123d7b93  vmovaps xmm6, [rsp+0x50]
00007f7c123d7b99  vmovaps xmm7, [rsp+0x60]
00007f7c123d7b9f  vmovaps xmm8, [rsp+0x70]
00007f7c123d7ba5  vmovaps xmm9, [rsp+0x80]
00007f7c123d7bae  vmovaps xmm10, [rsp+0x90]
00007f7c123d7bb7  vmovaps xmm11, [rsp+0xA0]
00007f7c123d7bc0  vmovaps xmm12, [rsp+0xB0]
00007f7c123d7bc9  vmovaps xmm13, [rsp+0xC0]
00007f7c123d7bd2  vmovaps xmm14, [rsp+0xD0]
00007f7c123d7bdb  vmovaps xmm15, [rsp+0xE0]
00007f7c123d7be4  add rsp, 0xF0
00007f7c123d7beb  pop r11
00007f7c123d7bed  pop r10
00007f7c123d7bef  pop r9
00007f7c123d7bf1  pop r8
00007f7c123d7bf3  pop rsi
00007f7c123d7bf4  pop rdi
00007f7c123d7bf5  pop rdx
00007f7c123d7bf6  pop rcx
00007f7c123d7bf7  pop rax
00007f7c123d7bf8  add rsp, 0x08
00007f7c123d7bfc  jmp 0x00007F7C123D5DCB
00007f7c123d7c01  call 0x00007F7C122E5820
00007f7c123d7c06  jmp 0x00007F7C123D5DD8
00007f7c123d7c0b  sub rsp, 0x08
00007f7c123d7c0f  push rax
00007f7c123d7c10  push rcx
00007f7c123d7c11  push rdx
00007f7c123d7c12  push rdi
00007f7c123d7c13  push rsi
00007f7c123d7c14  push r8
00007f7c123d7c16  push r9
00007f7c123d7c18  push r10
00007f7c123d7c1a  push r11
00007f7c123d7c1c  sub rsp, 0xF0
00007f7c123d7c23  vmovaps [rsp], xmm0
00007f7c123d7c28  vmovaps [rsp+0x10], xmm2
00007f7c123d7c2e  vmovaps [rsp+0x20], xmm3
00007f7c123d7c34  vmovaps [rsp+0x30], xmm4
00007f7c123d7c3a  vmovaps [rsp+0x40], xmm5
00007f7c123d7c40  vmovaps [rsp+0x50], xmm6
00007f7c123d7c46  vmovaps [rsp+0x60], xmm7
00007f7c123d7c4c  vmovaps [rsp+0x70], xmm8
00007f7c123d7c52  vmovaps [rsp+0x80], xmm9
00007f7c123d7c5b  vmovaps [rsp+0x90], xmm10
00007f7c123d7c64  vmovaps [rsp+0xA0], xmm11
00007f7c123d7c6d  vmovaps [rsp+0xB0], xmm12
00007f7c123d7c76  vmovaps [rsp+0xC0], xmm13
00007f7c123d7c7f  vmovaps [rsp+0xD0], xmm14
00007f7c123d7c88  vmovaps [rsp+0xE0], xmm15
00007f7c123d7c91  sub rsp, 0x30
00007f7c123d7c95  movaps [rsp], xmm1
00007f7c123d7c99  movaps [rsp+0x10], xmm5
00007f7c123d7c9e  movaps [rsp+0x20], xmm7
00007f7c123d7ca3  lea rdi, [rsp]
00007f7c123d7ca7  mov esi, 0x00
00007f7c123d7cac  mov rax, 0x5E723D793530
00007f7c123d7cb6  call rax
00007f7c123d7cb8  movaps xmm1, [rsp]
00007f7c123d7cbc  add rsp, 0x30
00007f7c123d7cc0  vmovaps xmm0, [rsp]
00007f7c123d7cc5  vmovaps xmm2, [rsp+0x10]
00007f7c123d7ccb  vmovaps xmm3, [rsp+0x20]
00007f7c123d7cd1  vmovaps xmm4, [rsp+0x30]
00007f7c123d7cd7  vmovaps xmm5, [rsp+0x40]
00007f7c123d7cdd  vmovaps xmm6, [rsp+0x50]
00007f7c123d7ce3  vmovaps xmm7, [rsp+0x60]
00007f7c123d7ce9  vmovaps xmm8, [rsp+0x70]
00007f7c123d7cef  vmovaps xmm9, [rsp+0x80]
00007f7c123d7cf8  vmovaps xmm10, [rsp+0x90]
00007f7c123d7d01  vmovaps xmm11, [rsp+0xA0]
00007f7c123d7d0a  vmovaps xmm12, [rsp+0xB0]
00007f7c123d7d13  vmovaps xmm13, [rsp+0xC0]
00007f7c123d7d1c  vmovaps xmm14, [rsp+0xD0]
00007f7c123d7d25  vmovaps xmm15, [rsp+0xE0]
00007f7c123d7d2e  add rsp, 0xF0
00007f7c123d7d35  pop r11
00007f7c123d7d37  pop r10
00007f7c123d7d39  pop r9
00007f7c123d7d3b  pop r8
00007f7c123d7d3d  pop rsi
00007f7c123d7d3e  pop rdi
00007f7c123d7d3f  pop rdx
00007f7c123d7d40  pop rcx
00007f7c123d7d41  pop rax
00007f7c123d7d42  add rsp, 0x08
00007f7c123d7d46  jmp 0x00007F7C123D5E7D
00007f7c123d7d4b  sub rsp, 0x08
00007f7c123d7d4f  push rax
00007f7c123d7d50  push rcx
00007f7c123d7d51  push rdx
00007f7c123d7d52  push rdi
00007f7c123d7d53  push rsi
00007f7c123d7d54  push r8
00007f7c123d7d56  push r9
00007f7c123d7d58  push r10
00007f7c123d7d5a  push r11
00007f7c123d7d5c  sub rsp, 0xF0
00007f7c123d7d63  vmovaps [rsp], xmm0
00007f7c123d7d68  vmovaps [rsp+0x10], xmm1
00007f7c123d7d6e  vmovaps [rsp+0x20], xmm2
00007f7c123d7d74  vmovaps [rsp+0x30], xmm3
00007f7c123d7d7a  vmovaps [rsp+0x40], xmm4
00007f7c123d7d80  vmovaps [rsp+0x50], xmm5
00007f7c123d7d86  vmovaps [rsp+0x60], xmm6
00007f7c123d7d8c  vmovaps [rsp+0x70], xmm8
00007f7c123d7d92  vmovaps [rsp+0x80], xmm9
00007f7c123d7d9b  vmovaps [rsp+0x90], xmm10
00007f7c123d7da4  vmovaps [rsp+0xA0], xmm11
00007f7c123d7dad  vmovaps [rsp+0xB0], xmm12
00007f7c123d7db6  vmovaps [rsp+0xC0], xmm13
00007f7c123d7dbf  vmovaps [rsp+0xD0], xmm14
00007f7c123d7dc8  vmovaps [rsp+0xE0], xmm15
00007f7c123d7dd1  sub rsp, 0x30
00007f7c123d7dd5  movaps [rsp], xmm7
00007f7c123d7dd9  movaps [rsp+0x10], xmm5
00007f7c123d7dde  movaps [rsp+0x20], xmm15
00007f7c123d7de4  lea rdi, [rsp]
00007f7c123d7de8  mov esi, 0x00
00007f7c123d7ded  mov rax, 0x5E723D793530
00007f7c123d7df7  call rax
00007f7c123d7df9  movaps xmm7, [rsp]
00007f7c123d7dfd  add rsp, 0x30
00007f7c123d7e01  vmovaps xmm0, [rsp]
00007f7c123d7e06  vmovaps xmm1, [rsp+0x10]
00007f7c123d7e0c  vmovaps xmm2, [rsp+0x20]
00007f7c123d7e12  vmovaps xmm3, [rsp+0x30]
00007f7c123d7e18  vmovaps xmm4, [rsp+0x40]
00007f7c123d7e1e  vmovaps xmm5, [rsp+0x50]
00007f7c123d7e24  vmovaps xmm6, [rsp+0x60]
00007f7c123d7e2a  vmovaps xmm8, [rsp+0x70]
00007f7c123d7e30  vmovaps xmm9, [rsp+0x80]
00007f7c123d7e39  vmovaps xmm10, [rsp+0x90]
00007f7c123d7e42  vmovaps xmm11, [rsp+0xA0]
00007f7c123d7e4b  vmovaps xmm12, [rsp+0xB0]
00007f7c123d7e54  vmovaps xmm13, [rsp+0xC0]
00007f7c123d7e5d  vmovaps xmm14, [rsp+0xD0]
00007f7c123d7e66  vmovaps xmm15, [rsp+0xE0]
00007f7c123d7e6f  add rsp, 0xF0
00007f7c123d7e76  pop r11
00007f7c123d7e78  pop r10
00007f7c123d7e7a  pop r9
00007f7c123d7e7c  pop r8
00007f7c123d7e7e  pop rsi
00007f7c123d7e7f  pop rdi
00007f7c123d7e80  pop rdx
00007f7c123d7e81  pop rcx
00007f7c123d7e82  pop rax
00007f7c123d7e83  add rsp, 0x08
00007f7c123d7e87  jmp 0x00007F7C123D5EB3
00007f7c123d7e8c  call 0x00007F7C122D64F0
00007f7c123d7e91  jmp 0x00007F7C123D5EC0
00007f7c123d7e96  sub rsp, 0x08
00007f7c123d7e9a  push rax
00007f7c123d7e9b  push rcx
00007f7c123d7e9c  push rdx
00007f7c123d7e9d  push rdi
00007f7c123d7e9e  push rsi
00007f7c123d7e9f  push r8
00007f7c123d7ea1  push r9
00007f7c123d7ea3  push r10
00007f7c123d7ea5  push r11
00007f7c123d7ea7  sub rsp, 0xF0
00007f7c123d7eae  vmovaps [rsp], xmm0
00007f7c123d7eb3  vmovaps [rsp+0x10], xmm1
00007f7c123d7eb9  vmovaps [rsp+0x20], xmm2
00007f7c123d7ebf  vmovaps [rsp+0x30], xmm3
00007f7c123d7ec5  vmovaps [rsp+0x40], xmm4
00007f7c123d7ecb  vmovaps [rsp+0x50], xmm5
00007f7c123d7ed1  vmovaps [rsp+0x60], xmm6
00007f7c123d7ed7  vmovaps [rsp+0x70], xmm7
00007f7c123d7edd  vmovaps [rsp+0x80], xmm8
00007f7c123d7ee6  vmovaps [rsp+0x90], xmm9
00007f7c123d7eef  vmovaps [rsp+0xA0], xmm10
00007f7c123d7ef8  vmovaps [rsp+0xB0], xmm11
00007f7c123d7f01  vmovaps [rsp+0xC0], xmm12
00007f7c123d7f0a  vmovaps [rsp+0xD0], xmm13
00007f7c123d7f13  vmovaps [rsp+0xE0], xmm14
00007f7c123d7f1c  sub rsp, 0x30
00007f7c123d7f20  movaps [rsp], xmm15
00007f7c123d7f25  movaps [rsp+0x10], xmm5
00007f7c123d7f2a  movaps [rsp+0x20], xmm3
00007f7c123d7f2f  lea rdi, [rsp]
00007f7c123d7f33  mov esi, 0x00
00007f7c123d7f38  mov rax, 0x5E723D793530
00007f7c123d7f42  call rax
00007f7c123d7f44  movaps xmm15, [rsp]
00007f7c123d7f49  add rsp, 0x30
00007f7c123d7f4d  vmovaps xmm0, [rsp]
00007f7c123d7f52  vmovaps xmm1, [rsp+0x10]
00007f7c123d7f58  vmovaps xmm2, [rsp+0x20]
00007f7c123d7f5e  vmovaps xmm3, [rsp+0x30]
00007f7c123d7f64  vmovaps xmm4, [rsp+0x40]
00007f7c123d7f6a  vmovaps xmm5, [rsp+0x50]
00007f7c123d7f70  vmovaps xmm6, [rsp+0x60]
00007f7c123d7f76  vmovaps xmm7, [rsp+0x70]
00007f7c123d7f7c  vmovaps xmm8, [rsp+0x80]
00007f7c123d7f85  vmovaps xmm9, [rsp+0x90]
00007f7c123d7f8e  vmovaps xmm10, [rsp+0xA0]
00007f7c123d7f97  vmovaps xmm11, [rsp+0xB0]
00007f7c123d7fa0  vmovaps xmm12, [rsp+0xC0]
00007f7c123d7fa9  vmovaps xmm13, [rsp+0xD0]
00007f7c123d7fb2  vmovaps xmm14, [rsp+0xE0]
00007f7c123d7fbb  add rsp, 0xF0
00007f7c123d7fc2  pop r11
00007f7c123d7fc4  pop r10
00007f7c123d7fc6  pop r9
00007f7c123d7fc8  pop r8
00007f7c123d7fca  pop rsi
00007f7c123d7fcb  pop rdi
00007f7c123d7fcc  pop rdx
00007f7c123d7fcd  pop rcx
00007f7c123d7fce  pop rax
00007f7c123d7fcf  add rsp, 0x08
00007f7c123d7fd3  jmp 0x00007F7C123D5EE6
00007f7c123d7fd8  sub rsp, 0x08
00007f7c123d7fdc  push rax
00007f7c123d7fdd  push rcx
00007f7c123d7fde  push rdx
00007f7c123d7fdf  push rdi
00007f7c123d7fe0  push rsi
00007f7c123d7fe1  push r8
00007f7c123d7fe3  push r9
00007f7c123d7fe5  push r10
00007f7c123d7fe7  push r11
00007f7c123d7fe9  sub rsp, 0xF0
00007f7c123d7ff0  vmovaps [rsp], xmm0
00007f7c123d7ff5  vmovaps [rsp+0x10], xmm2
00007f7c123d7ffb  vmovaps [rsp+0x20], xmm3
00007f7c123d8001  vmovaps [rsp+0x30], xmm4
00007f7c123d8007  vmovaps [rsp+0x40], xmm5
00007f7c123d800d  vmovaps [rsp+0x50], xmm6
00007f7c123d8013  vmovaps [rsp+0x60], xmm7
00007f7c123d8019  vmovaps [rsp+0x70], xmm8
00007f7c123d801f  vmovaps [rsp+0x80], xmm9
00007f7c123d8028  vmovaps [rsp+0x90], xmm10
00007f7c123d8031  vmovaps [rsp+0xA0], xmm11
00007f7c123d803a  vmovaps [rsp+0xB0], xmm12
00007f7c123d8043  vmovaps [rsp+0xC0], xmm13
00007f7c123d804c  vmovaps [rsp+0xD0], xmm14
00007f7c123d8055  vmovaps [rsp+0xE0], xmm15
00007f7c123d805e  sub rsp, 0x30
00007f7c123d8062  movaps [rsp], xmm1
00007f7c123d8066  movaps [rsp+0x10], xmm5
00007f7c123d806b  movaps [rsp+0x20], xmm4
00007f7c123d8070  lea rdi, [rsp]
00007f7c123d8074  mov esi, 0x00
00007f7c123d8079  mov rax, 0x5E723D793530
00007f7c123d8083  call rax
00007f7c123d8085  movaps xmm1, [rsp]
00007f7c123d8089  add rsp, 0x30
00007f7c123d808d  vmovaps xmm0, [rsp]
00007f7c123d8092  vmovaps xmm2, [rsp+0x10]
00007f7c123d8098  vmovaps xmm3, [rsp+0x20]
00007f7c123d809e  vmovaps xmm4, [rsp+0x30]
00007f7c123d80a4  vmovaps xmm5, [rsp+0x40]
00007f7c123d80aa  vmovaps xmm6, [rsp+0x50]
00007f7c123d80b0  vmovaps xmm7, [rsp+0x60]
00007f7c123d80b6  vmovaps xmm8, [rsp+0x70]
00007f7c123d80bc  vmovaps xmm9, [rsp+0x80]
00007f7c123d80c5  vmovaps xmm10, [rsp+0x90]
00007f7c123d80ce  vmovaps xmm11, [rsp+0xA0]
00007f7c123d80d7  vmovaps xmm12, [rsp+0xB0]
00007f7c123d80e0  vmovaps xmm13, [rsp+0xC0]
00007f7c123d80e9  vmovaps xmm14, [rsp+0xD0]
00007f7c123d80f2  vmovaps xmm15, [rsp+0xE0]
00007f7c123d80fb  add rsp, 0xF0
00007f7c123d8102  pop r11
00007f7c123d8104  pop r10
00007f7c123d8106  pop r9
00007f7c123d8108  pop r8
00007f7c123d810a  pop rsi
00007f7c123d810b  pop rdi
00007f7c123d810c  pop rdx
00007f7c123d810d  pop rcx
00007f7c123d810e  pop rax
00007f7c123d810f  add rsp, 0x08
00007f7c123d8113  jmp 0x00007F7C123D5F06
00007f7c123d8118  sub rsp, 0x08
00007f7c123d811c  push rax
00007f7c123d811d  push rcx
00007f7c123d811e  push rdx
00007f7c123d811f  push rdi
00007f7c123d8120  push rsi
00007f7c123d8121  push r8
00007f7c123d8123  push r9
00007f7c123d8125  push r10
00007f7c123d8127  push r11
00007f7c123d8129  sub rsp, 0xF0
00007f7c123d8130  vmovaps [rsp], xmm0
00007f7c123d8135  vmovaps [rsp+0x10], xmm1
00007f7c123d813b  vmovaps [rsp+0x20], xmm2
00007f7c123d8141  vmovaps [rsp+0x30], xmm3
00007f7c123d8147  vmovaps [rsp+0x40], xmm5
00007f7c123d814d  vmovaps [rsp+0x50], xmm6
00007f7c123d8153  vmovaps [rsp+0x60], xmm7
00007f7c123d8159  vmovaps [rsp+0x70], xmm8
00007f7c123d815f  vmovaps [rsp+0x80], xmm9
00007f7c123d8168  vmovaps [rsp+0x90], xmm10
00007f7c123d8171  vmovaps [rsp+0xA0], xmm11
00007f7c123d817a  vmovaps [rsp+0xB0], xmm12
00007f7c123d8183  vmovaps [rsp+0xC0], xmm13
00007f7c123d818c  vmovaps [rsp+0xD0], xmm14
00007f7c123d8195  vmovaps [rsp+0xE0], xmm15
00007f7c123d819e  sub rsp, 0x30
00007f7c123d81a2  movaps [rsp], xmm4
00007f7c123d81a6  movaps [rsp+0x10], xmm3
00007f7c123d81ab  movaps [rsp+0x20], xmm5
00007f7c123d81b0  lea rdi, [rsp]
00007f7c123d81b4  mov esi, 0x00
00007f7c123d81b9  mov rax, 0x5E723D793530
00007f7c123d81c3  call rax
00007f7c123d81c5  movaps xmm4, [rsp]
00007f7c123d81c9  add rsp, 0x30
00007f7c123d81cd  vmovaps xmm0, [rsp]
00007f7c123d81d2  vmovaps xmm1, [rsp+0x10]
00007f7c123d81d8  vmovaps xmm2, [rsp+0x20]
00007f7c123d81de  vmovaps xmm3, [rsp+0x30]
00007f7c123d81e4  vmovaps xmm5, [rsp+0x40]
00007f7c123d81ea  vmovaps xmm6, [rsp+0x50]
00007f7c123d81f0  vmovaps xmm7, [rsp+0x60]
00007f7c123d81f6  vmovaps xmm8, [rsp+0x70]
00007f7c123d81fc  vmovaps xmm9, [rsp+0x80]
00007f7c123d8205  vmovaps xmm10, [rsp+0x90]
00007f7c123d820e  vmovaps xmm11, [rsp+0xA0]
00007f7c123d8217  vmovaps xmm12, [rsp+0xB0]
00007f7c123d8220  vmovaps xmm13, [rsp+0xC0]
00007f7c123d8229  vmovaps xmm14, [rsp+0xD0]
00007f7c123d8232  vmovaps xmm15, [rsp+0xE0]
00007f7c123d823b  add rsp, 0xF0
00007f7c123d8242  pop r11
00007f7c123d8244  pop r10
00007f7c123d8246  pop r9
00007f7c123d8248  pop r8
00007f7c123d824a  pop rsi
00007f7c123d824b  pop rdi
00007f7c123d824c  pop rdx
00007f7c123d824d  pop rcx
00007f7c123d824e  pop rax
00007f7c123d824f  add rsp, 0x08
00007f7c123d8253  jmp 0x00007F7C123D5F54
00007f7c123d8258  call 0x00007F7C122D64F0
00007f7c123d825d  jmp 0x00007F7C123D5F61
00007f7c123d8262  sub rsp, 0x08
00007f7c123d8266  push rax
00007f7c123d8267  push rcx
00007f7c123d8268  push rdx
00007f7c123d8269  push rdi
00007f7c123d826a  push rsi
00007f7c123d826b  push r8
00007f7c123d826d  push r9
00007f7c123d826f  push r10
00007f7c123d8271  push r11
00007f7c123d8273  sub rsp, 0xF0
00007f7c123d827a  vmovaps [rsp], xmm0
00007f7c123d827f  vmovaps [rsp+0x10], xmm1
00007f7c123d8285  vmovaps [rsp+0x20], xmm2
00007f7c123d828b  vmovaps [rsp+0x30], xmm3
00007f7c123d8291  vmovaps [rsp+0x40], xmm4
00007f7c123d8297  vmovaps [rsp+0x50], xmm6
00007f7c123d829d  vmovaps [rsp+0x60], xmm7
00007f7c123d82a3  vmovaps [rsp+0x70], xmm8
00007f7c123d82a9  vmovaps [rsp+0x80], xmm9
00007f7c123d82b2  vmovaps [rsp+0x90], xmm10
00007f7c123d82bb  vmovaps [rsp+0xA0], xmm11
00007f7c123d82c4  vmovaps [rsp+0xB0], xmm12
00007f7c123d82cd  vmovaps [rsp+0xC0], xmm13
00007f7c123d82d6  vmovaps [rsp+0xD0], xmm14
00007f7c123d82df  vmovaps [rsp+0xE0], xmm15
00007f7c123d82e8  sub rsp, 0x30
00007f7c123d82ec  movaps [rsp], xmm5
00007f7c123d82f0  movaps [rsp+0x10], xmm6
00007f7c123d82f5  movaps [rsp+0x20], xmm3
00007f7c123d82fa  lea rdi, [rsp]
00007f7c123d82fe  mov esi, 0x00
00007f7c123d8303  mov rax, 0x5E723D793530
00007f7c123d830d  call rax
00007f7c123d830f  movaps xmm5, [rsp]
00007f7c123d8313  add rsp, 0x30
00007f7c123d8317  vmovaps xmm0, [rsp]
00007f7c123d831c  vmovaps xmm1, [rsp+0x10]
00007f7c123d8322  vmovaps xmm2, [rsp+0x20]
00007f7c123d8328  vmovaps xmm3, [rsp+0x30]
00007f7c123d832e  vmovaps xmm4, [rsp+0x40]
00007f7c123d8334  vmovaps xmm6, [rsp+0x50]
00007f7c123d833a  vmovaps xmm7, [rsp+0x60]
00007f7c123d8340  vmovaps xmm8, [rsp+0x70]
00007f7c123d8346  vmovaps xmm9, [rsp+0x80]
00007f7c123d834f  vmovaps xmm10, [rsp+0x90]
00007f7c123d8358  vmovaps xmm11, [rsp+0xA0]
00007f7c123d8361  vmovaps xmm12, [rsp+0xB0]
00007f7c123d836a  vmovaps xmm13, [rsp+0xC0]
00007f7c123d8373  vmovaps xmm14, [rsp+0xD0]
00007f7c123d837c  vmovaps xmm15, [rsp+0xE0]
00007f7c123d8385  add rsp, 0xF0
00007f7c123d838c  pop r11
00007f7c123d838e  pop r10
00007f7c123d8390  pop r9
00007f7c123d8392  pop r8
00007f7c123d8394  pop rsi
00007f7c123d8395  pop rdi
00007f7c123d8396  pop rdx
00007f7c123d8397  pop rcx
00007f7c123d8398  pop rax
00007f7c123d8399  add rsp, 0x08
00007f7c123d839d  jmp 0x00007F7C123D5F87
00007f7c123d83a2  sub rsp, 0x08
00007f7c123d83a6  push rax
00007f7c123d83a7  push rcx
00007f7c123d83a8  push rdx
00007f7c123d83a9  push rdi
00007f7c123d83aa  push rsi
00007f7c123d83ab  push r8
00007f7c123d83ad  push r9
00007f7c123d83af  push r10
00007f7c123d83b1  push r11
00007f7c123d83b3  sub rsp, 0xF0
00007f7c123d83ba  vmovaps [rsp], xmm0
00007f7c123d83bf  vmovaps [rsp+0x10], xmm1
00007f7c123d83c5  vmovaps [rsp+0x20], xmm2
00007f7c123d83cb  vmovaps [rsp+0x30], xmm3
00007f7c123d83d1  vmovaps [rsp+0x40], xmm4
00007f7c123d83d7  vmovaps [rsp+0x50], xmm5
00007f7c123d83dd  vmovaps [rsp+0x60], xmm7
00007f7c123d83e3  vmovaps [rsp+0x70], xmm8
00007f7c123d83e9  vmovaps [rsp+0x80], xmm9
00007f7c123d83f2  vmovaps [rsp+0x90], xmm10
00007f7c123d83fb  vmovaps [rsp+0xA0], xmm11
00007f7c123d8404  vmovaps [rsp+0xB0], xmm12
00007f7c123d840d  vmovaps [rsp+0xC0], xmm13
00007f7c123d8416  vmovaps [rsp+0xD0], xmm14
00007f7c123d841f  vmovaps [rsp+0xE0], xmm15
00007f7c123d8428  sub rsp, 0x30
00007f7c123d842c  movaps [rsp], xmm6
00007f7c123d8430  movaps [rsp+0x10], xmm9
00007f7c123d8436  movaps [rsp+0x20], xmm1
00007f7c123d843b  lea rdi, [rsp]
00007f7c123d843f  mov esi, 0x00
00007f7c123d8444  mov rax, 0x5E723D793530
00007f7c123d844e  call rax
00007f7c123d8450  movaps xmm6, [rsp]
00007f7c123d8454  add rsp, 0x30
00007f7c123d8458  vmovaps xmm0, [rsp]
00007f7c123d845d  vmovaps xmm1, [rsp+0x10]
00007f7c123d8463  vmovaps xmm2, [rsp+0x20]
00007f7c123d8469  vmovaps xmm3, [rsp+0x30]
00007f7c123d846f  vmovaps xmm4, [rsp+0x40]
00007f7c123d8475  vmovaps xmm5, [rsp+0x50]
00007f7c123d847b  vmovaps xmm7, [rsp+0x60]
00007f7c123d8481  vmovaps xmm8, [rsp+0x70]
00007f7c123d8487  vmovaps xmm9, [rsp+0x80]
00007f7c123d8490  vmovaps xmm10, [rsp+0x90]
00007f7c123d8499  vmovaps xmm11, [rsp+0xA0]
00007f7c123d84a2  vmovaps xmm12, [rsp+0xB0]
00007f7c123d84ab  vmovaps xmm13, [rsp+0xC0]
00007f7c123d84b4  vmovaps xmm14, [rsp+0xD0]
00007f7c123d84bd  vmovaps xmm15, [rsp+0xE0]
00007f7c123d84c6  add rsp, 0xF0
00007f7c123d84cd  pop r11
00007f7c123d84cf  pop r10
00007f7c123d84d1  pop r9
00007f7c123d84d3  pop r8
00007f7c123d84d5  pop rsi
00007f7c123d84d6  pop rdi
00007f7c123d84d7  pop rdx
00007f7c123d84d8  pop rcx
00007f7c123d84d9  pop rax
00007f7c123d84da  add rsp, 0x08
00007f7c123d84de  jmp 0x00007F7C123D5FAB
00007f7c123d84e3  sub rsp, 0x08
00007f7c123d84e7  push rax
00007f7c123d84e8  push rcx
00007f7c123d84e9  push rdx
00007f7c123d84ea  push rdi
00007f7c123d84eb  push rsi
00007f7c123d84ec  push r8
00007f7c123d84ee  push r9
00007f7c123d84f0  push r10
00007f7c123d84f2  push r11
00007f7c123d84f4  sub rsp, 0xF0
00007f7c123d84fb  vmovaps [rsp], xmm0
00007f7c123d8500  vmovaps [rsp+0x10], xmm1
00007f7c123d8506  vmovaps [rsp+0x20], xmm2
00007f7c123d850c  vmovaps [rsp+0x30], xmm3
00007f7c123d8512  vmovaps [rsp+0x40], xmm4
00007f7c123d8518  vmovaps [rsp+0x50], xmm5
00007f7c123d851e  vmovaps [rsp+0x60], xmm6
00007f7c123d8524  vmovaps [rsp+0x70], xmm7
00007f7c123d852a  vmovaps [rsp+0x80], xmm8
00007f7c123d8533  vmovaps [rsp+0x90], xmm10
00007f7c123d853c  vmovaps [rsp+0xA0], xmm11
00007f7c123d8545  vmovaps [rsp+0xB0], xmm12
00007f7c123d854e  vmovaps [rsp+0xC0], xmm13
00007f7c123d8557  vmovaps [rsp+0xD0], xmm14
00007f7c123d8560  vmovaps [rsp+0xE0], xmm15
00007f7c123d8569  sub rsp, 0x30
00007f7c123d856d  movaps [rsp], xmm9
00007f7c123d8572  movaps [rsp+0x10], xmm3
00007f7c123d8577  movaps [rsp+0x20], xmm1
00007f7c123d857c  lea rdi, [rsp]
00007f7c123d8580  mov esi, 0x00
00007f7c123d8585  mov rax, 0x5E723D793530
00007f7c123d858f  call rax
00007f7c123d8591  movaps xmm9, [rsp]
00007f7c123d8596  add rsp, 0x30
00007f7c123d859a  vmovaps xmm0, [rsp]
00007f7c123d859f  vmovaps xmm1, [rsp+0x10]
00007f7c123d85a5  vmovaps xmm2, [rsp+0x20]
00007f7c123d85ab  vmovaps xmm3, [rsp+0x30]
00007f7c123d85b1  vmovaps xmm4, [rsp+0x40]
00007f7c123d85b7  vmovaps xmm5, [rsp+0x50]
00007f7c123d85bd  vmovaps xmm6, [rsp+0x60]
00007f7c123d85c3  vmovaps xmm7, [rsp+0x70]
00007f7c123d85c9  vmovaps xmm8, [rsp+0x80]
00007f7c123d85d2  vmovaps xmm10, [rsp+0x90]
00007f7c123d85db  vmovaps xmm11, [rsp+0xA0]
00007f7c123d85e4  vmovaps xmm12, [rsp+0xB0]
00007f7c123d85ed  vmovaps xmm13, [rsp+0xC0]
00007f7c123d85f6  vmovaps xmm14, [rsp+0xD0]
00007f7c123d85ff  vmovaps xmm15, [rsp+0xE0]
00007f7c123d8608  add rsp, 0xF0
00007f7c123d860f  pop r11
00007f7c123d8611  pop r10
00007f7c123d8613  pop r9
00007f7c123d8615  pop r8
00007f7c123d8617  pop rsi
00007f7c123d8618  pop rdi
00007f7c123d8619  pop rdx
00007f7c123d861a  pop rcx
00007f7c123d861b  pop rax
00007f7c123d861c  add rsp, 0x08
00007f7c123d8620  jmp 0x00007F7C123D5FF7
00007f7c123d8625  call 0x00007F7C122D64F0
00007f7c123d862a  jmp 0x00007F7C123D6004
00007f7c123d862f  sub rsp, 0x08
00007f7c123d8633  push rax
00007f7c123d8634  push rcx
00007f7c123d8635  push rdx
00007f7c123d8636  push rdi
00007f7c123d8637  push rsi
00007f7c123d8638  push r8
00007f7c123d863a  push r9
00007f7c123d863c  push r10
00007f7c123d863e  push r11
00007f7c123d8640  sub rsp, 0xF0
00007f7c123d8647  vmovaps [rsp], xmm0
00007f7c123d864c  vmovaps [rsp+0x10], xmm1
00007f7c123d8652  vmovaps [rsp+0x20], xmm2
00007f7c123d8658  vmovaps [rsp+0x30], xmm3
00007f7c123d865e  vmovaps [rsp+0x40], xmm4
00007f7c123d8664  vmovaps [rsp+0x50], xmm5
00007f7c123d866a  vmovaps [rsp+0x60], xmm6
00007f7c123d8670  vmovaps [rsp+0x70], xmm7
00007f7c123d8676  vmovaps [rsp+0x80], xmm8
00007f7c123d867f  vmovaps [rsp+0x90], xmm9
00007f7c123d8688  vmovaps [rsp+0xA0], xmm10
00007f7c123d8691  vmovaps [rsp+0xB0], xmm11
00007f7c123d869a  vmovaps [rsp+0xC0], xmm12
00007f7c123d86a3  vmovaps [rsp+0xD0], xmm13
00007f7c123d86ac  vmovaps [rsp+0xE0], xmm14
00007f7c123d86b5  sub rsp, 0x30
00007f7c123d86b9  movaps [rsp], xmm15
00007f7c123d86be  movaps [rsp+0x10], xmm3
00007f7c123d86c3  movaps [rsp+0x20], xmm7
00007f7c123d86c8  lea rdi, [rsp]
00007f7c123d86cc  mov esi, 0x00
00007f7c123d86d1  mov rax, 0x5E723D793530
00007f7c123d86db  call rax
00007f7c123d86dd  movaps xmm15, [rsp]
00007f7c123d86e2  add rsp, 0x30
00007f7c123d86e6  vmovaps xmm0, [rsp]
00007f7c123d86eb  vmovaps xmm1, [rsp+0x10]
00007f7c123d86f1  vmovaps xmm2, [rsp+0x20]
00007f7c123d86f7  vmovaps xmm3, [rsp+0x30]
00007f7c123d86fd  vmovaps xmm4, [rsp+0x40]
00007f7c123d8703  vmovaps xmm5, [rsp+0x50]
00007f7c123d8709  vmovaps xmm6, [rsp+0x60]
00007f7c123d870f  vmovaps xmm7, [rsp+0x70]
00007f7c123d8715  vmovaps xmm8, [rsp+0x80]
00007f7c123d871e  vmovaps xmm9, [rsp+0x90]
00007f7c123d8727  vmovaps xmm10, [rsp+0xA0]
00007f7c123d8730  vmovaps xmm11, [rsp+0xB0]
00007f7c123d8739  vmovaps xmm12, [rsp+0xC0]
00007f7c123d8742  vmovaps xmm13, [rsp+0xD0]
00007f7c123d874b  vmovaps xmm14, [rsp+0xE0]
00007f7c123d8754  add rsp, 0xF0
00007f7c123d875b  pop r11
00007f7c123d875d  pop r10
00007f7c123d875f  pop r9
00007f7c123d8761  pop r8
00007f7c123d8763  pop rsi
00007f7c123d8764  pop rdi
00007f7c123d8765  pop rdx
00007f7c123d8766  pop rcx
00007f7c123d8767  pop rax
00007f7c123d8768  add rsp, 0x08
00007f7c123d876c  jmp 0x00007F7C123D6030
00007f7c123d8771  sub rsp, 0x08
00007f7c123d8775  push rax
00007f7c123d8776  push rcx
00007f7c123d8777  push rdx
00007f7c123d8778  push rdi
00007f7c123d8779  push rsi
00007f7c123d877a  push r8
00007f7c123d877c  push r9
00007f7c123d877e  push r10
00007f7c123d8780  push r11
00007f7c123d8782  sub rsp, 0xF0
00007f7c123d8789  vmovaps [rsp], xmm0
00007f7c123d878e  vmovaps [rsp+0x10], xmm1
00007f7c123d8794  vmovaps [rsp+0x20], xmm2
00007f7c123d879a  vmovaps [rsp+0x30], xmm4
00007f7c123d87a0  vmovaps [rsp+0x40], xmm5
00007f7c123d87a6  vmovaps [rsp+0x50], xmm6
00007f7c123d87ac  vmovaps [rsp+0x60], xmm7
00007f7c123d87b2  vmovaps [rsp+0x70], xmm8
00007f7c123d87b8  vmovaps [rsp+0x80], xmm9
00007f7c123d87c1  vmovaps [rsp+0x90], xmm10
00007f7c123d87ca  vmovaps [rsp+0xA0], xmm11
00007f7c123d87d3  vmovaps [rsp+0xB0], xmm12
00007f7c123d87dc  vmovaps [rsp+0xC0], xmm13
00007f7c123d87e5  vmovaps [rsp+0xD0], xmm14
00007f7c123d87ee  vmovaps [rsp+0xE0], xmm15
00007f7c123d87f7  sub rsp, 0x30
00007f7c123d87fb  movaps [rsp], xmm3
00007f7c123d87ff  movaps [rsp+0x10], xmm1
00007f7c123d8804  movaps [rsp+0x20], xmm15
00007f7c123d880a  lea rdi, [rsp]
00007f7c123d880e  mov esi, 0x00
00007f7c123d8813  mov rax, 0x5E723D793530
00007f7c123d881d  call rax
00007f7c123d881f  movaps xmm3, [rsp]
00007f7c123d8823  add rsp, 0x30
00007f7c123d8827  vmovaps xmm0, [rsp]
00007f7c123d882c  vmovaps xmm1, [rsp+0x10]
00007f7c123d8832  vmovaps xmm2, [rsp+0x20]
00007f7c123d8838  vmovaps xmm4, [rsp+0x30]
00007f7c123d883e  vmovaps xmm5, [rsp+0x40]
00007f7c123d8844  vmovaps xmm6, [rsp+0x50]
00007f7c123d884a  vmovaps xmm7, [rsp+0x60]
00007f7c123d8850  vmovaps xmm8, [rsp+0x70]
00007f7c123d8856  vmovaps xmm9, [rsp+0x80]
00007f7c123d885f  vmovaps xmm10, [rsp+0x90]
00007f7c123d8868  vmovaps xmm11, [rsp+0xA0]
00007f7c123d8871  vmovaps xmm12, [rsp+0xB0]
00007f7c123d887a  vmovaps xmm13, [rsp+0xC0]
00007f7c123d8883  vmovaps xmm14, [rsp+0xD0]
00007f7c123d888c  vmovaps xmm15, [rsp+0xE0]
00007f7c123d8895  add rsp, 0xF0
00007f7c123d889c  pop r11
00007f7c123d889e  pop r10
00007f7c123d88a0  pop r9
00007f7c123d88a2  pop r8
00007f7c123d88a4  pop rsi
00007f7c123d88a5  pop rdi
00007f7c123d88a6  pop rdx
00007f7c123d88a7  pop rcx
00007f7c123d88a8  pop rax
00007f7c123d88a9  add rsp, 0x08
00007f7c123d88ad  jmp 0x00007F7C123D60BF
00007f7c123d88b2  call 0x00007F7C122D64F0
00007f7c123d88b7  jmp 0x00007F7C123D60C9
00007f7c123d88bc  sub rsp, 0x08
00007f7c123d88c0  push rax
00007f7c123d88c1  push rcx
00007f7c123d88c2  push rdx
00007f7c123d88c3  push rdi
00007f7c123d88c4  push rsi
00007f7c123d88c5  push r8
00007f7c123d88c7  push r9
00007f7c123d88c9  push r10
00007f7c123d88cb  push r11
00007f7c123d88cd  sub rsp, 0xF0
00007f7c123d88d4  vmovaps [rsp], xmm0
00007f7c123d88d9  vmovaps [rsp+0x10], xmm1
00007f7c123d88df  vmovaps [rsp+0x20], xmm2
00007f7c123d88e5  vmovaps [rsp+0x30], xmm3
00007f7c123d88eb  vmovaps [rsp+0x40], xmm4
00007f7c123d88f1  vmovaps [rsp+0x50], xmm5
00007f7c123d88f7  vmovaps [rsp+0x60], xmm6
00007f7c123d88fd  vmovaps [rsp+0x70], xmm7
00007f7c123d8903  vmovaps [rsp+0x80], xmm8
00007f7c123d890c  vmovaps [rsp+0x90], xmm9
00007f7c123d8915  vmovaps [rsp+0xA0], xmm10
00007f7c123d891e  vmovaps [rsp+0xB0], xmm11
00007f7c123d8927  vmovaps [rsp+0xC0], xmm12
00007f7c123d8930  vmovaps [rsp+0xD0], xmm13
00007f7c123d8939  vmovaps [rsp+0xE0], xmm14
00007f7c123d8942  sub rsp, 0x30
00007f7c123d8946  movaps [rsp], xmm15
00007f7c123d894b  movaps [rsp+0x10], xmm14
00007f7c123d8951  movaps [rsp+0x20], xmm4
00007f7c123d8956  lea rdi, [rsp]
00007f7c123d895a  mov esi, 0x00
00007f7c123d895f  mov rax, 0x5E723D793530
00007f7c123d8969  call rax
00007f7c123d896b  movaps xmm15, [rsp]
00007f7c123d8970  add rsp, 0x30
00007f7c123d8974  vmovaps xmm0, [rsp]
00007f7c123d8979  vmovaps xmm1, [rsp+0x10]
00007f7c123d897f  vmovaps xmm2, [rsp+0x20]
00007f7c123d8985  vmovaps xmm3, [rsp+0x30]
00007f7c123d898b  vmovaps xmm4, [rsp+0x40]
00007f7c123d8991  vmovaps xmm5, [rsp+0x50]
00007f7c123d8997  vmovaps xmm6, [rsp+0x60]
00007f7c123d899d  vmovaps xmm7, [rsp+0x70]
00007f7c123d89a3  vmovaps xmm8, [rsp+0x80]
00007f7c123d89ac  vmovaps xmm9, [rsp+0x90]
00007f7c123d89b5  vmovaps xmm10, [rsp+0xA0]
00007f7c123d89be  vmovaps xmm11, [rsp+0xB0]
00007f7c123d89c7  vmovaps xmm12, [rsp+0xC0]
00007f7c123d89d0  vmovaps xmm13, [rsp+0xD0]
00007f7c123d89d9  vmovaps xmm14, [rsp+0xE0]
00007f7c123d89e2  add rsp, 0xF0
00007f7c123d89e9  pop r11
00007f7c123d89eb  pop r10
00007f7c123d89ed  pop r9
00007f7c123d89ef  pop r8
00007f7c123d89f1  pop rsi
00007f7c123d89f2  pop rdi
00007f7c123d89f3  pop rdx
00007f7c123d89f4  pop rcx
00007f7c123d89f5  pop rax
00007f7c123d89f6  add rsp, 0x08
00007f7c123d89fa  jmp 0x00007F7C123D60F7
00007f7c123d89ff  sub rsp, 0x08
00007f7c123d8a03  push rax
00007f7c123d8a04  push rcx
00007f7c123d8a05  push rdx
00007f7c123d8a06  push rdi
00007f7c123d8a07  push rsi
00007f7c123d8a08  push r8
00007f7c123d8a0a  push r9
00007f7c123d8a0c  push r10
00007f7c123d8a0e  push r11
00007f7c123d8a10  sub rsp, 0xF0
00007f7c123d8a17  vmovaps [rsp], xmm0
00007f7c123d8a1c  vmovaps [rsp+0x10], xmm1
00007f7c123d8a22  vmovaps [rsp+0x20], xmm2
00007f7c123d8a28  vmovaps [rsp+0x30], xmm3
00007f7c123d8a2e  vmovaps [rsp+0x40], xmm4
00007f7c123d8a34  vmovaps [rsp+0x50], xmm5
00007f7c123d8a3a  vmovaps [rsp+0x60], xmm6
00007f7c123d8a40  vmovaps [rsp+0x70], xmm7
00007f7c123d8a46  vmovaps [rsp+0x80], xmm8
00007f7c123d8a4f  vmovaps [rsp+0x90], xmm9
00007f7c123d8a58  vmovaps [rsp+0xA0], xmm10
00007f7c123d8a61  vmovaps [rsp+0xB0], xmm11
00007f7c123d8a6a  vmovaps [rsp+0xC0], xmm12
00007f7c123d8a73  vmovaps [rsp+0xD0], xmm13
00007f7c123d8a7c  vmovaps [rsp+0xE0], xmm15
00007f7c123d8a85  sub rsp, 0x30
00007f7c123d8a89  movaps [rsp], xmm14
00007f7c123d8a8e  movaps [rsp+0x10], xmm2
00007f7c123d8a93  movaps [rsp+0x20], xmm1
00007f7c123d8a98  lea rdi, [rsp]
00007f7c123d8a9c  mov esi, 0x00
00007f7c123d8aa1  mov rax, 0x5E723D793530
00007f7c123d8aab  call rax
00007f7c123d8aad  movaps xmm14, [rsp]
00007f7c123d8ab2  add rsp, 0x30
00007f7c123d8ab6  vmovaps xmm0, [rsp]
00007f7c123d8abb  vmovaps xmm1, [rsp+0x10]
00007f7c123d8ac1  vmovaps xmm2, [rsp+0x20]
00007f7c123d8ac7  vmovaps xmm3, [rsp+0x30]
00007f7c123d8acd  vmovaps xmm4, [rsp+0x40]
00007f7c123d8ad3  vmovaps xmm5, [rsp+0x50]
00007f7c123d8ad9  vmovaps xmm6, [rsp+0x60]
00007f7c123d8adf  vmovaps xmm7, [rsp+0x70]
00007f7c123d8ae5  vmovaps xmm8, [rsp+0x80]
00007f7c123d8aee  vmovaps xmm9, [rsp+0x90]
00007f7c123d8af7  vmovaps xmm10, [rsp+0xA0]
00007f7c123d8b00  vmovaps xmm11, [rsp+0xB0]
00007f7c123d8b09  vmovaps xmm12, [rsp+0xC0]
00007f7c123d8b12  vmovaps xmm13, [rsp+0xD0]
00007f7c123d8b1b  vmovaps xmm15, [rsp+0xE0]
00007f7c123d8b24  add rsp, 0xF0
00007f7c123d8b2b  pop r11
00007f7c123d8b2d  pop r10
00007f7c123d8b2f  pop r9
00007f7c123d8b31  pop r8
00007f7c123d8b33  pop rsi
00007f7c123d8b34  pop rdi
00007f7c123d8b35  pop rdx
00007f7c123d8b36  pop rcx
00007f7c123d8b37  pop rax
00007f7c123d8b38  add rsp, 0x08
00007f7c123d8b3c  jmp 0x00007F7C123D611D
00007f7c123d8b41  sub rsp, 0x08
00007f7c123d8b45  push rax
00007f7c123d8b46  push rcx
00007f7c123d8b47  push rdx
00007f7c123d8b48  push rdi
00007f7c123d8b49  push rsi
00007f7c123d8b4a  push r8
00007f7c123d8b4c  push r9
00007f7c123d8b4e  push r10
00007f7c123d8b50  push r11
00007f7c123d8b52  sub rsp, 0xF0
00007f7c123d8b59  vmovaps [rsp], xmm0
00007f7c123d8b5e  vmovaps [rsp+0x10], xmm2
00007f7c123d8b64  vmovaps [rsp+0x20], xmm3
00007f7c123d8b6a  vmovaps [rsp+0x30], xmm4
00007f7c123d8b70  vmovaps [rsp+0x40], xmm5
00007f7c123d8b76  vmovaps [rsp+0x50], xmm6
00007f7c123d8b7c  vmovaps [rsp+0x60], xmm7
00007f7c123d8b82  vmovaps [rsp+0x70], xmm8
00007f7c123d8b88  vmovaps [rsp+0x80], xmm9
00007f7c123d8b91  vmovaps [rsp+0x90], xmm10
00007f7c123d8b9a  vmovaps [rsp+0xA0], xmm11
00007f7c123d8ba3  vmovaps [rsp+0xB0], xmm12
00007f7c123d8bac  vmovaps [rsp+0xC0], xmm13
00007f7c123d8bb5  vmovaps [rsp+0xD0], xmm14
00007f7c123d8bbe  vmovaps [rsp+0xE0], xmm15
00007f7c123d8bc7  sub rsp, 0x30
00007f7c123d8bcb  movaps [rsp], xmm1
00007f7c123d8bcf  movaps [rsp+0x10], xmm4
00007f7c123d8bd4  movaps [rsp+0x20], xmm9
00007f7c123d8bda  lea rdi, [rsp]
00007f7c123d8bde  mov esi, 0x00
00007f7c123d8be3  mov rax, 0x5E723D793530
00007f7c123d8bed  call rax
00007f7c123d8bef  movaps xmm1, [rsp]
00007f7c123d8bf3  add rsp, 0x30
00007f7c123d8bf7  vmovaps xmm0, [rsp]
00007f7c123d8bfc  vmovaps xmm2, [rsp+0x10]
00007f7c123d8c02  vmovaps xmm3, [rsp+0x20]
00007f7c123d8c08  vmovaps xmm4, [rsp+0x30]
00007f7c123d8c0e  vmovaps xmm5, [rsp+0x40]
00007f7c123d8c14  vmovaps xmm6, [rsp+0x50]
00007f7c123d8c1a  vmovaps xmm7, [rsp+0x60]
00007f7c123d8c20  vmovaps xmm8, [rsp+0x70]
00007f7c123d8c26  vmovaps xmm9, [rsp+0x80]
00007f7c123d8c2f  vmovaps xmm10, [rsp+0x90]
00007f7c123d8c38  vmovaps xmm11, [rsp+0xA0]
00007f7c123d8c41  vmovaps xmm12, [rsp+0xB0]
00007f7c123d8c4a  vmovaps xmm13, [rsp+0xC0]
00007f7c123d8c53  vmovaps xmm14, [rsp+0xD0]
00007f7c123d8c5c  vmovaps xmm15, [rsp+0xE0]
00007f7c123d8c65  add rsp, 0xF0
00007f7c123d8c6c  pop r11
00007f7c123d8c6e  pop r10
00007f7c123d8c70  pop r9
00007f7c123d8c72  pop r8
00007f7c123d8c74  pop rsi
00007f7c123d8c75  pop rdi
00007f7c123d8c76  pop rdx
00007f7c123d8c77  pop rcx
00007f7c123d8c78  pop rax
00007f7c123d8c79  add rsp, 0x08
00007f7c123d8c7d  jmp 0x00007F7C123D613B
00007f7c123d8c82  sub rsp, 0x08
00007f7c123d8c86  push rax
00007f7c123d8c87  push rcx
00007f7c123d8c88  push rdx
00007f7c123d8c89  push rdi
00007f7c123d8c8a  push rsi
00007f7c123d8c8b  push r8
00007f7c123d8c8d  push r9
00007f7c123d8c8f  push r10
00007f7c123d8c91  push r11
00007f7c123d8c93  sub rsp, 0xF0
00007f7c123d8c9a  vmovaps [rsp], xmm0
00007f7c123d8c9f  vmovaps [rsp+0x10], xmm1
00007f7c123d8ca5  vmovaps [rsp+0x20], xmm2
00007f7c123d8cab  vmovaps [rsp+0x30], xmm3
00007f7c123d8cb1  vmovaps [rsp+0x40], xmm5
00007f7c123d8cb7  vmovaps [rsp+0x50], xmm6
00007f7c123d8cbd  vmovaps [rsp+0x60], xmm7
00007f7c123d8cc3  vmovaps [rsp+0x70], xmm8
00007f7c123d8cc9  vmovaps [rsp+0x80], xmm9
00007f7c123d8cd2  vmovaps [rsp+0x90], xmm10
00007f7c123d8cdb  vmovaps [rsp+0xA0], xmm11
00007f7c123d8ce4  vmovaps [rsp+0xB0], xmm12
00007f7c123d8ced  vmovaps [rsp+0xC0], xmm13
00007f7c123d8cf6  vmovaps [rsp+0xD0], xmm14
00007f7c123d8cff  vmovaps [rsp+0xE0], xmm15
00007f7c123d8d08  sub rsp, 0x30
00007f7c123d8d0c  movaps [rsp], xmm4
00007f7c123d8d10  movaps [rsp+0x10], xmm2
00007f7c123d8d15  movaps [rsp+0x20], xmm9
00007f7c123d8d1b  lea rdi, [rsp]
00007f7c123d8d1f  mov esi, 0x00
00007f7c123d8d24  mov rax, 0x5E723D793530
00007f7c123d8d2e  call rax
00007f7c123d8d30  movaps xmm4, [rsp]
00007f7c123d8d34  add rsp, 0x30
00007f7c123d8d38  vmovaps xmm0, [rsp]
00007f7c123d8d3d  vmovaps xmm1, [rsp+0x10]
00007f7c123d8d43  vmovaps xmm2, [rsp+0x20]
00007f7c123d8d49  vmovaps xmm3, [rsp+0x30]
00007f7c123d8d4f  vmovaps xmm5, [rsp+0x40]
00007f7c123d8d55  vmovaps xmm6, [rsp+0x50]
00007f7c123d8d5b  vmovaps xmm7, [rsp+0x60]
00007f7c123d8d61  vmovaps xmm8, [rsp+0x70]
00007f7c123d8d67  vmovaps xmm9, [rsp+0x80]
00007f7c123d8d70  vmovaps xmm10, [rsp+0x90]
00007f7c123d8d79  vmovaps xmm11, [rsp+0xA0]
00007f7c123d8d82  vmovaps xmm12, [rsp+0xB0]
00007f7c123d8d8b  vmovaps xmm13, [rsp+0xC0]
00007f7c123d8d94  vmovaps xmm14, [rsp+0xD0]
00007f7c123d8d9d  vmovaps xmm15, [rsp+0xE0]
00007f7c123d8da6  add rsp, 0xF0
00007f7c123d8dad  pop r11
00007f7c123d8daf  pop r10
00007f7c123d8db1  pop r9
00007f7c123d8db3  pop r8
00007f7c123d8db5  pop rsi
00007f7c123d8db6  pop rdi
00007f7c123d8db7  pop rdx
00007f7c123d8db8  pop rcx
00007f7c123d8db9  pop rax
00007f7c123d8dba  add rsp, 0x08
00007f7c123d8dbe  jmp 0x00007F7C123D616B
00007f7c123d8dc3  sub rsp, 0x08
00007f7c123d8dc7  push rax
00007f7c123d8dc8  push rcx
00007f7c123d8dc9  push rdx
00007f7c123d8dca  push rdi
00007f7c123d8dcb  push rsi
00007f7c123d8dcc  push r8
00007f7c123d8dce  push r9
00007f7c123d8dd0  push r10
00007f7c123d8dd2  push r11
00007f7c123d8dd4  sub rsp, 0xF0
00007f7c123d8ddb  vmovaps [rsp], xmm0
00007f7c123d8de0  vmovaps [rsp+0x10], xmm1
00007f7c123d8de6  vmovaps [rsp+0x20], xmm2
00007f7c123d8dec  vmovaps [rsp+0x30], xmm3
00007f7c123d8df2  vmovaps [rsp+0x40], xmm4
00007f7c123d8df8  vmovaps [rsp+0x50], xmm5
00007f7c123d8dfe  vmovaps [rsp+0x60], xmm6
00007f7c123d8e04  vmovaps [rsp+0x70], xmm7
00007f7c123d8e0a  vmovaps [rsp+0x80], xmm8
00007f7c123d8e13  vmovaps [rsp+0x90], xmm10
00007f7c123d8e1c  vmovaps [rsp+0xA0], xmm11
00007f7c123d8e25  vmovaps [rsp+0xB0], xmm12
00007f7c123d8e2e  vmovaps [rsp+0xC0], xmm13
00007f7c123d8e37  vmovaps [rsp+0xD0], xmm14
00007f7c123d8e40  vmovaps [rsp+0xE0], xmm15
00007f7c123d8e49  sub rsp, 0x30
00007f7c123d8e4d  movaps [rsp], xmm9
00007f7c123d8e52  movaps [rsp+0x10], xmm2
00007f7c123d8e57  movaps [rsp+0x20], xmm1
00007f7c123d8e5c  lea rdi, [rsp]
00007f7c123d8e60  mov esi, 0x00
00007f7c123d8e65  mov rax, 0x5E723D793530
00007f7c123d8e6f  call rax
00007f7c123d8e71  movaps xmm9, [rsp]
00007f7c123d8e76  add rsp, 0x30
00007f7c123d8e7a  vmovaps xmm0, [rsp]
00007f7c123d8e7f  vmovaps xmm1, [rsp+0x10]
00007f7c123d8e85  vmovaps xmm2, [rsp+0x20]
00007f7c123d8e8b  vmovaps xmm3, [rsp+0x30]
00007f7c123d8e91  vmovaps xmm4, [rsp+0x40]
00007f7c123d8e97  vmovaps xmm5, [rsp+0x50]
00007f7c123d8e9d  vmovaps xmm6, [rsp+0x60]
00007f7c123d8ea3  vmovaps xmm7, [rsp+0x70]
00007f7c123d8ea9  vmovaps xmm8, [rsp+0x80]
00007f7c123d8eb2  vmovaps xmm10, [rsp+0x90]
00007f7c123d8ebb  vmovaps xmm11, [rsp+0xA0]
00007f7c123d8ec4  vmovaps xmm12, [rsp+0xB0]
00007f7c123d8ecd  vmovaps xmm13, [rsp+0xC0]
00007f7c123d8ed6  vmovaps xmm14, [rsp+0xD0]
00007f7c123d8edf  vmovaps xmm15, [rsp+0xE0]
00007f7c123d8ee8  add rsp, 0xF0
00007f7c123d8eef  pop r11
00007f7c123d8ef1  pop r10
00007f7c123d8ef3  pop r9
00007f7c123d8ef5  pop r8
00007f7c123d8ef7  pop rsi
00007f7c123d8ef8  pop rdi
00007f7c123d8ef9  pop rdx
00007f7c123d8efa  pop rcx
00007f7c123d8efb  pop rax
00007f7c123d8efc  add rsp, 0x08
00007f7c123d8f00  jmp 0x00007F7C123D61A1
00007f7c123d8f05  sub rsp, 0x08
00007f7c123d8f09  push rax
00007f7c123d8f0a  push rcx
00007f7c123d8f0b  push rdx
00007f7c123d8f0c  push rdi
00007f7c123d8f0d  push rsi
00007f7c123d8f0e  push r8
00007f7c123d8f10  push r9
00007f7c123d8f12  push r10
00007f7c123d8f14  push r11
00007f7c123d8f16  sub rsp, 0xF0
00007f7c123d8f1d  vmovaps [rsp], xmm0
00007f7c123d8f22  vmovaps [rsp+0x10], xmm2
00007f7c123d8f28  vmovaps [rsp+0x20], xmm3
00007f7c123d8f2e  vmovaps [rsp+0x30], xmm4
00007f7c123d8f34  vmovaps [rsp+0x40], xmm5
00007f7c123d8f3a  vmovaps [rsp+0x50], xmm6
00007f7c123d8f40  vmovaps [rsp+0x60], xmm7
00007f7c123d8f46  vmovaps [rsp+0x70], xmm8
00007f7c123d8f4c  vmovaps [rsp+0x80], xmm9
00007f7c123d8f55  vmovaps [rsp+0x90], xmm10
00007f7c123d8f5e  vmovaps [rsp+0xA0], xmm11
00007f7c123d8f67  vmovaps [rsp+0xB0], xmm12
00007f7c123d8f70  vmovaps [rsp+0xC0], xmm13
00007f7c123d8f79  vmovaps [rsp+0xD0], xmm14
00007f7c123d8f82  vmovaps [rsp+0xE0], xmm15
00007f7c123d8f8b  sub rsp, 0x30
00007f7c123d8f8f  movaps [rsp], xmm1
00007f7c123d8f93  movaps [rsp+0x10], xmm15
00007f7c123d8f99  movaps [rsp+0x20], xmm6
00007f7c123d8f9e  lea rdi, [rsp]
00007f7c123d8fa2  mov esi, 0x00
00007f7c123d8fa7  mov rax, 0x5E723D793530
00007f7c123d8fb1  call rax
00007f7c123d8fb3  movaps xmm1, [rsp]
00007f7c123d8fb7  add rsp, 0x30
00007f7c123d8fbb  vmovaps xmm0, [rsp]
00007f7c123d8fc0  vmovaps xmm2, [rsp+0x10]
00007f7c123d8fc6  vmovaps xmm3, [rsp+0x20]
00007f7c123d8fcc  vmovaps xmm4, [rsp+0x30]
00007f7c123d8fd2  vmovaps xmm5, [rsp+0x40]
00007f7c123d8fd8  vmovaps xmm6, [rsp+0x50]
00007f7c123d8fde  vmovaps xmm7, [rsp+0x60]
00007f7c123d8fe4  vmovaps xmm8, [rsp+0x70]
00007f7c123d8fea  vmovaps xmm9, [rsp+0x80]
00007f7c123d8ff3  vmovaps xmm10, [rsp+0x90]
00007f7c123d8ffc  vmovaps xmm11, [rsp+0xA0]
00007f7c123d9005  vmovaps xmm12, [rsp+0xB0]
00007f7c123d900e  vmovaps xmm13, [rsp+0xC0]
00007f7c123d9017  vmovaps xmm14, [rsp+0xD0]
00007f7c123d9020  vmovaps xmm15, [rsp+0xE0]
00007f7c123d9029  add rsp, 0xF0
00007f7c123d9030  pop r11
00007f7c123d9032  pop r10
00007f7c123d9034  pop r9
00007f7c123d9036  pop r8
00007f7c123d9038  pop rsi
00007f7c123d9039  pop rdi
00007f7c123d903a  pop rdx
00007f7c123d903b  pop rcx
00007f7c123d903c  pop rax
00007f7c123d903d  add rsp, 0x08
00007f7c123d9041  jmp 0x00007F7C123D61C2
00007f7c123d9046  sub rsp, 0x08
00007f7c123d904a  push rax
00007f7c123d904b  push rcx
00007f7c123d904c  push rdx
00007f7c123d904d  push rdi
00007f7c123d904e  push rsi
00007f7c123d904f  push r8
00007f7c123d9051  push r9
00007f7c123d9053  push r10
00007f7c123d9055  push r11
00007f7c123d9057  sub rsp, 0xF0
00007f7c123d905e  vmovaps [rsp], xmm0
00007f7c123d9063  vmovaps [rsp+0x10], xmm1
00007f7c123d9069  vmovaps [rsp+0x20], xmm2
00007f7c123d906f  vmovaps [rsp+0x30], xmm3
00007f7c123d9075  vmovaps [rsp+0x40], xmm4
00007f7c123d907b  vmovaps [rsp+0x50], xmm5
00007f7c123d9081  vmovaps [rsp+0x60], xmm6
00007f7c123d9087  vmovaps [rsp+0x70], xmm7
00007f7c123d908d  vmovaps [rsp+0x80], xmm8
00007f7c123d9096  vmovaps [rsp+0x90], xmm9
00007f7c123d909f  vmovaps [rsp+0xA0], xmm10
00007f7c123d90a8  vmovaps [rsp+0xB0], xmm11
00007f7c123d90b1  vmovaps [rsp+0xC0], xmm12
00007f7c123d90ba  vmovaps [rsp+0xD0], xmm13
00007f7c123d90c3  vmovaps [rsp+0xE0], xmm14
00007f7c123d90cc  sub rsp, 0x30
00007f7c123d90d0  movaps [rsp], xmm15
00007f7c123d90d5  movaps [rsp+0x10], xmm5
00007f7c123d90da  movaps [rsp+0x20], xmm3
00007f7c123d90df  lea rdi, [rsp]
00007f7c123d90e3  mov esi, 0x00
00007f7c123d90e8  mov rax, 0x5E723D793530
00007f7c123d90f2  call rax
00007f7c123d90f4  movaps xmm15, [rsp]
00007f7c123d90f9  add rsp, 0x30
00007f7c123d90fd  vmovaps xmm0, [rsp]
00007f7c123d9102  vmovaps xmm1, [rsp+0x10]
00007f7c123d9108  vmovaps xmm2, [rsp+0x20]
00007f7c123d910e  vmovaps xmm3, [rsp+0x30]
00007f7c123d9114  vmovaps xmm4, [rsp+0x40]
00007f7c123d911a  vmovaps xmm5, [rsp+0x50]
00007f7c123d9120  vmovaps xmm6, [rsp+0x60]
00007f7c123d9126  vmovaps xmm7, [rsp+0x70]
00007f7c123d912c  vmovaps xmm8, [rsp+0x80]
00007f7c123d9135  vmovaps xmm9, [rsp+0x90]
00007f7c123d913e  vmovaps xmm10, [rsp+0xA0]
00007f7c123d9147  vmovaps xmm11, [rsp+0xB0]
00007f7c123d9150  vmovaps xmm12, [rsp+0xC0]
00007f7c123d9159  vmovaps xmm13, [rsp+0xD0]
00007f7c123d9162  vmovaps xmm14, [rsp+0xE0]
00007f7c123d916b  add rsp, 0xF0
00007f7c123d9172  pop r11
00007f7c123d9174  pop r10
00007f7c123d9176  pop r9
00007f7c123d9178  pop r8
00007f7c123d917a  pop rsi
00007f7c123d917b  pop rdi
00007f7c123d917c  pop rdx
00007f7c123d917d  pop rcx
00007f7c123d917e  pop rax
00007f7c123d917f  add rsp, 0x08
00007f7c123d9183  jmp 0x00007F7C123D61DC
00007f7c123d9188  sub rsp, 0x08
00007f7c123d918c  push rax
00007f7c123d918d  push rcx
00007f7c123d918e  push rdx
00007f7c123d918f  push rdi
00007f7c123d9190  push rsi
00007f7c123d9191  push r8
00007f7c123d9193  push r9
00007f7c123d9195  push r10
00007f7c123d9197  push r11
00007f7c123d9199  sub rsp, 0xF0
00007f7c123d91a0  vmovaps [rsp], xmm0
00007f7c123d91a5  vmovaps [rsp+0x10], xmm1
00007f7c123d91ab  vmovaps [rsp+0x20], xmm2
00007f7c123d91b1  vmovaps [rsp+0x30], xmm3
00007f7c123d91b7  vmovaps [rsp+0x40], xmm4
00007f7c123d91bd  vmovaps [rsp+0x50], xmm6
00007f7c123d91c3  vmovaps [rsp+0x60], xmm7
00007f7c123d91c9  vmovaps [rsp+0x70], xmm8
00007f7c123d91cf  vmovaps [rsp+0x80], xmm9
00007f7c123d91d8  vmovaps [rsp+0x90], xmm10
00007f7c123d91e1  vmovaps [rsp+0xA0], xmm11
00007f7c123d91ea  vmovaps [rsp+0xB0], xmm12
00007f7c123d91f3  vmovaps [rsp+0xC0], xmm13
00007f7c123d91fc  vmovaps [rsp+0xD0], xmm14
00007f7c123d9205  vmovaps [rsp+0xE0], xmm15
00007f7c123d920e  sub rsp, 0x30
00007f7c123d9212  movaps [rsp], xmm5
00007f7c123d9216  movaps [rsp+0x10], xmm8
00007f7c123d921c  movaps [rsp+0x20], xmm6
00007f7c123d9221  lea rdi, [rsp]
00007f7c123d9225  mov esi, 0x00
00007f7c123d922a  mov rax, 0x5E723D793530
00007f7c123d9234  call rax
00007f7c123d9236  movaps xmm5, [rsp]
00007f7c123d923a  add rsp, 0x30
00007f7c123d923e  vmovaps xmm0, [rsp]
00007f7c123d9243  vmovaps xmm1, [rsp+0x10]
00007f7c123d9249  vmovaps xmm2, [rsp+0x20]
00007f7c123d924f  vmovaps xmm3, [rsp+0x30]
00007f7c123d9255  vmovaps xmm4, [rsp+0x40]
00007f7c123d925b  vmovaps xmm6, [rsp+0x50]
00007f7c123d9261  vmovaps xmm7, [rsp+0x60]
00007f7c123d9267  vmovaps xmm8, [rsp+0x70]
00007f7c123d926d  vmovaps xmm9, [rsp+0x80]
00007f7c123d9276  vmovaps xmm10, [rsp+0x90]
00007f7c123d927f  vmovaps xmm11, [rsp+0xA0]
00007f7c123d9288  vmovaps xmm12, [rsp+0xB0]
00007f7c123d9291  vmovaps xmm13, [rsp+0xC0]
00007f7c123d929a  vmovaps xmm14, [rsp+0xD0]
00007f7c123d92a3  vmovaps xmm15, [rsp+0xE0]
00007f7c123d92ac  add rsp, 0xF0
00007f7c123d92b3  pop r11
00007f7c123d92b5  pop r10
00007f7c123d92b7  pop r9
00007f7c123d92b9  pop r8
00007f7c123d92bb  pop rsi
00007f7c123d92bc  pop rdi
00007f7c123d92bd  pop rdx
00007f7c123d92be  pop rcx
00007f7c123d92bf  pop rax
00007f7c123d92c0  add rsp, 0x08
00007f7c123d92c4  jmp 0x00007F7C123D6200
00007f7c123d92c9  sub rsp, 0x08
00007f7c123d92cd  push rax
00007f7c123d92ce  push rcx
00007f7c123d92cf  push rdx
00007f7c123d92d0  push rdi
00007f7c123d92d1  push rsi
00007f7c123d92d2  push r8
00007f7c123d92d4  push r9
00007f7c123d92d6  push r10
00007f7c123d92d8  push r11
00007f7c123d92da  sub rsp, 0xF0
00007f7c123d92e1  vmovaps [rsp], xmm0
00007f7c123d92e6  vmovaps [rsp+0x10], xmm1
00007f7c123d92ec  vmovaps [rsp+0x20], xmm2
00007f7c123d92f2  vmovaps [rsp+0x30], xmm3
00007f7c123d92f8  vmovaps [rsp+0x40], xmm4
00007f7c123d92fe  vmovaps [rsp+0x50], xmm5
00007f7c123d9304  vmovaps [rsp+0x60], xmm7
00007f7c123d930a  vmovaps [rsp+0x70], xmm8
00007f7c123d9310  vmovaps [rsp+0x80], xmm9
00007f7c123d9319  vmovaps [rsp+0x90], xmm10
00007f7c123d9322  vmovaps [rsp+0xA0], xmm11
00007f7c123d932b  vmovaps [rsp+0xB0], xmm12
00007f7c123d9334  vmovaps [rsp+0xC0], xmm13
00007f7c123d933d  vmovaps [rsp+0xD0], xmm14
00007f7c123d9346  vmovaps [rsp+0xE0], xmm15
00007f7c123d934f  sub rsp, 0x30
00007f7c123d9353  movaps [rsp], xmm6
00007f7c123d9357  movaps [rsp+0x10], xmm10
00007f7c123d935d  movaps [rsp+0x20], xmm8
00007f7c123d9363  lea rdi, [rsp]
00007f7c123d9367  mov esi, 0x00
00007f7c123d936c  mov rax, 0x5E723D793530
00007f7c123d9376  call rax
00007f7c123d9378  movaps xmm6, [rsp]
00007f7c123d937c  add rsp, 0x30
00007f7c123d9380  vmovaps xmm0, [rsp]
00007f7c123d9385  vmovaps xmm1, [rsp+0x10]
00007f7c123d938b  vmovaps xmm2, [rsp+0x20]
00007f7c123d9391  vmovaps xmm3, [rsp+0x30]
00007f7c123d9397  vmovaps xmm4, [rsp+0x40]
00007f7c123d939d  vmovaps xmm5, [rsp+0x50]
00007f7c123d93a3  vmovaps xmm7, [rsp+0x60]
00007f7c123d93a9  vmovaps xmm8, [rsp+0x70]
00007f7c123d93af  vmovaps xmm9, [rsp+0x80]
00007f7c123d93b8  vmovaps xmm10, [rsp+0x90]
00007f7c123d93c1  vmovaps xmm11, [rsp+0xA0]
00007f7c123d93ca  vmovaps xmm12, [rsp+0xB0]
00007f7c123d93d3  vmovaps xmm13, [rsp+0xC0]
00007f7c123d93dc  vmovaps xmm14, [rsp+0xD0]
00007f7c123d93e5  vmovaps xmm15, [rsp+0xE0]
00007f7c123d93ee  add rsp, 0xF0
00007f7c123d93f5  pop r11
00007f7c123d93f7  pop r10
00007f7c123d93f9  pop r9
00007f7c123d93fb  pop r8
00007f7c123d93fd  pop rsi
00007f7c123d93fe  pop rdi
00007f7c123d93ff  pop rdx
00007f7c123d9400  pop rcx
00007f7c123d9401  pop rax
00007f7c123d9402  add rsp, 0x08
00007f7c123d9406  jmp 0x00007F7C123D6225
00007f7c123d940b  sub rsp, 0x08
00007f7c123d940f  push rax
00007f7c123d9410  push rcx
00007f7c123d9411  push rdx
00007f7c123d9412  push rdi
00007f7c123d9413  push rsi
00007f7c123d9414  push r8
00007f7c123d9416  push r9
00007f7c123d9418  push r10
00007f7c123d941a  push r11
00007f7c123d941c  sub rsp, 0xF0
00007f7c123d9423  vmovaps [rsp], xmm0
00007f7c123d9428  vmovaps [rsp+0x10], xmm1
00007f7c123d942e  vmovaps [rsp+0x20], xmm2
00007f7c123d9434  vmovaps [rsp+0x30], xmm3
00007f7c123d943a  vmovaps [rsp+0x40], xmm4
00007f7c123d9440  vmovaps [rsp+0x50], xmm5
00007f7c123d9446  vmovaps [rsp+0x60], xmm6
00007f7c123d944c  vmovaps [rsp+0x70], xmm7
00007f7c123d9452  vmovaps [rsp+0x80], xmm8
00007f7c123d945b  vmovaps [rsp+0x90], xmm9
00007f7c123d9464  vmovaps [rsp+0xA0], xmm11
00007f7c123d946d  vmovaps [rsp+0xB0], xmm12
00007f7c123d9476  vmovaps [rsp+0xC0], xmm13
00007f7c123d947f  vmovaps [rsp+0xD0], xmm14
00007f7c123d9488  vmovaps [rsp+0xE0], xmm15
00007f7c123d9491  sub rsp, 0x30
00007f7c123d9495  movaps [rsp], xmm10
00007f7c123d949a  movaps [rsp+0x10], xmm8
00007f7c123d94a0  movaps [rsp+0x20], xmm14
00007f7c123d94a6  lea rdi, [rsp]
00007f7c123d94aa  mov esi, 0x00
00007f7c123d94af  mov rax, 0x5E723D793530
00007f7c123d94b9  call rax
00007f7c123d94bb  movaps xmm10, [rsp]
00007f7c123d94c0  add rsp, 0x30
00007f7c123d94c4  vmovaps xmm0, [rsp]
00007f7c123d94c9  vmovaps xmm1, [rsp+0x10]
00007f7c123d94cf  vmovaps xmm2, [rsp+0x20]
00007f7c123d94d5  vmovaps xmm3, [rsp+0x30]
00007f7c123d94db  vmovaps xmm4, [rsp+0x40]
00007f7c123d94e1  vmovaps xmm5, [rsp+0x50]
00007f7c123d94e7  vmovaps xmm6, [rsp+0x60]
00007f7c123d94ed  vmovaps xmm7, [rsp+0x70]
00007f7c123d94f3  vmovaps xmm8, [rsp+0x80]
00007f7c123d94fc  vmovaps xmm9, [rsp+0x90]
00007f7c123d9505  vmovaps xmm11, [rsp+0xA0]
00007f7c123d950e  vmovaps xmm12, [rsp+0xB0]
00007f7c123d9517  vmovaps xmm13, [rsp+0xC0]
00007f7c123d9520  vmovaps xmm14, [rsp+0xD0]
00007f7c123d9529  vmovaps xmm15, [rsp+0xE0]
00007f7c123d9532  add rsp, 0xF0
00007f7c123d9539  pop r11
00007f7c123d953b  pop r10
00007f7c123d953d  pop r9
00007f7c123d953f  pop r8
00007f7c123d9541  pop rsi
00007f7c123d9542  pop rdi
00007f7c123d9543  pop rdx
00007f7c123d9544  pop rcx
00007f7c123d9545  pop rax
00007f7c123d9546  add rsp, 0x08
00007f7c123d954a  jmp 0x00007F7C123D6245
00007f7c123d954f  sub rsp, 0x08
00007f7c123d9553  push rax
00007f7c123d9554  push rcx
00007f7c123d9555  push rdx
00007f7c123d9556  push rdi
00007f7c123d9557  push rsi
00007f7c123d9558  push r8
00007f7c123d955a  push r9
00007f7c123d955c  push r10
00007f7c123d955e  push r11
00007f7c123d9560  sub rsp, 0xF0
00007f7c123d9567  vmovaps [rsp], xmm0
00007f7c123d956c  vmovaps [rsp+0x10], xmm1
00007f7c123d9572  vmovaps [rsp+0x20], xmm2
00007f7c123d9578  vmovaps [rsp+0x30], xmm3
00007f7c123d957e  vmovaps [rsp+0x40], xmm4
00007f7c123d9584  vmovaps [rsp+0x50], xmm5
00007f7c123d958a  vmovaps [rsp+0x60], xmm6
00007f7c123d9590  vmovaps [rsp+0x70], xmm7
00007f7c123d9596  vmovaps [rsp+0x80], xmm8
00007f7c123d959f  vmovaps [rsp+0x90], xmm9
00007f7c123d95a8  vmovaps [rsp+0xA0], xmm10
00007f7c123d95b1  vmovaps [rsp+0xB0], xmm11
00007f7c123d95ba  vmovaps [rsp+0xC0], xmm12
00007f7c123d95c3  vmovaps [rsp+0xD0], xmm13
00007f7c123d95cc  vmovaps [rsp+0xE0], xmm15
00007f7c123d95d5  sub rsp, 0x30
00007f7c123d95d9  movaps [rsp], xmm14
00007f7c123d95de  movaps [rsp+0x10], xmm8
00007f7c123d95e4  movaps [rsp+0x20], xmm4
00007f7c123d95e9  lea rdi, [rsp]
00007f7c123d95ed  mov esi, 0x00
00007f7c123d95f2  mov rax, 0x5E723D793530
00007f7c123d95fc  call rax
00007f7c123d95fe  movaps xmm14, [rsp]
00007f7c123d9603  add rsp, 0x30
00007f7c123d9607  vmovaps xmm0, [rsp]
00007f7c123d960c  vmovaps xmm1, [rsp+0x10]
00007f7c123d9612  vmovaps xmm2, [rsp+0x20]
00007f7c123d9618  vmovaps xmm3, [rsp+0x30]
00007f7c123d961e  vmovaps xmm4, [rsp+0x40]
00007f7c123d9624  vmovaps xmm5, [rsp+0x50]
00007f7c123d962a  vmovaps xmm6, [rsp+0x60]
00007f7c123d9630  vmovaps xmm7, [rsp+0x70]
00007f7c123d9636  vmovaps xmm8, [rsp+0x80]
00007f7c123d963f  vmovaps xmm9, [rsp+0x90]
00007f7c123d9648  vmovaps xmm10, [rsp+0xA0]
00007f7c123d9651  vmovaps xmm11, [rsp+0xB0]
00007f7c123d965a  vmovaps xmm12, [rsp+0xC0]
00007f7c123d9663  vmovaps xmm13, [rsp+0xD0]
00007f7c123d966c  vmovaps xmm15, [rsp+0xE0]
00007f7c123d9675  add rsp, 0xF0
00007f7c123d967c  pop r11
00007f7c123d967e  pop r10
00007f7c123d9680  pop r9
00007f7c123d9682  pop r8
00007f7c123d9684  pop rsi
00007f7c123d9685  pop rdi
00007f7c123d9686  pop rdx
00007f7c123d9687  pop rcx
00007f7c123d9688  pop rax
00007f7c123d9689  add rsp, 0x08
00007f7c123d968d  jmp 0x00007F7C123D6265
00007f7c123d9692  sub rsp, 0x08
00007f7c123d9696  push rax
00007f7c123d9697  push rcx
00007f7c123d9698  push rdx
00007f7c123d9699  push rdi
00007f7c123d969a  push rsi
00007f7c123d969b  push r8
00007f7c123d969d  push r9
00007f7c123d969f  push r10
00007f7c123d96a1  push r11
00007f7c123d96a3  sub rsp, 0xF0
00007f7c123d96aa  vmovaps [rsp], xmm0
00007f7c123d96af  vmovaps [rsp+0x10], xmm1
00007f7c123d96b5  vmovaps [rsp+0x20], xmm2
00007f7c123d96bb  vmovaps [rsp+0x30], xmm3
00007f7c123d96c1  vmovaps [rsp+0x40], xmm5
00007f7c123d96c7  vmovaps [rsp+0x50], xmm6
00007f7c123d96cd  vmovaps [rsp+0x60], xmm7
00007f7c123d96d3  vmovaps [rsp+0x70], xmm8
00007f7c123d96d9  vmovaps [rsp+0x80], xmm9
00007f7c123d96e2  vmovaps [rsp+0x90], xmm10
00007f7c123d96eb  vmovaps [rsp+0xA0], xmm11
00007f7c123d96f4  vmovaps [rsp+0xB0], xmm12
00007f7c123d96fd  vmovaps [rsp+0xC0], xmm13
00007f7c123d9706  vmovaps [rsp+0xD0], xmm14
00007f7c123d970f  vmovaps [rsp+0xE0], xmm15
00007f7c123d9718  sub rsp, 0x30
00007f7c123d971c  movaps [rsp], xmm4
00007f7c123d9720  movaps [rsp+0x10], xmm13
00007f7c123d9726  movaps [rsp+0x20], xmm8
00007f7c123d972c  lea rdi, [rsp]
00007f7c123d9730  mov esi, 0x00
00007f7c123d9735  mov rax, 0x5E723D793530
00007f7c123d973f  call rax
00007f7c123d9741  movaps xmm4, [rsp]
00007f7c123d9745  add rsp, 0x30
00007f7c123d9749  vmovaps xmm0, [rsp]
00007f7c123d974e  vmovaps xmm1, [rsp+0x10]
00007f7c123d9754  vmovaps xmm2, [rsp+0x20]
00007f7c123d975a  vmovaps xmm3, [rsp+0x30]
00007f7c123d9760  vmovaps xmm5, [rsp+0x40]
00007f7c123d9766  vmovaps xmm6, [rsp+0x50]
00007f7c123d976c  vmovaps xmm7, [rsp+0x60]
00007f7c123d9772  vmovaps xmm8, [rsp+0x70]
00007f7c123d9778  vmovaps xmm9, [rsp+0x80]
00007f7c123d9781  vmovaps xmm10, [rsp+0x90]
00007f7c123d978a  vmovaps xmm11, [rsp+0xA0]
00007f7c123d9793  vmovaps xmm12, [rsp+0xB0]
00007f7c123d979c  vmovaps xmm13, [rsp+0xC0]
00007f7c123d97a5  vmovaps xmm14, [rsp+0xD0]
00007f7c123d97ae  vmovaps xmm15, [rsp+0xE0]
00007f7c123d97b7  add rsp, 0xF0
00007f7c123d97be  pop r11
00007f7c123d97c0  pop r10
00007f7c123d97c2  pop r9
00007f7c123d97c4  pop r8
00007f7c123d97c6  pop rsi
00007f7c123d97c7  pop rdi
00007f7c123d97c8  pop rdx
00007f7c123d97c9  pop rcx
00007f7c123d97ca  pop rax
00007f7c123d97cb  add rsp, 0x08
00007f7c123d97cf  jmp 0x00007F7C123D628A
00007f7c123d97d4  sub rsp, 0x08
00007f7c123d97d8  push rax
00007f7c123d97d9  push rcx
00007f7c123d97da  push rdx
00007f7c123d97db  push rdi
00007f7c123d97dc  push rsi
00007f7c123d97dd  push r8
00007f7c123d97df  push r9
00007f7c123d97e1  push r10
00007f7c123d97e3  push r11
00007f7c123d97e5  sub rsp, 0xF0
00007f7c123d97ec  vmovaps [rsp], xmm0
00007f7c123d97f1  vmovaps [rsp+0x10], xmm1
00007f7c123d97f7  vmovaps [rsp+0x20], xmm2
00007f7c123d97fd  vmovaps [rsp+0x30], xmm3
00007f7c123d9803  vmovaps [rsp+0x40], xmm4
00007f7c123d9809  vmovaps [rsp+0x50], xmm5
00007f7c123d980f  vmovaps [rsp+0x60], xmm6
00007f7c123d9815  vmovaps [rsp+0x70], xmm7
00007f7c123d981b  vmovaps [rsp+0x80], xmm8
00007f7c123d9824  vmovaps [rsp+0x90], xmm9
00007f7c123d982d  vmovaps [rsp+0xA0], xmm10
00007f7c123d9836  vmovaps [rsp+0xB0], xmm11
00007f7c123d983f  vmovaps [rsp+0xC0], xmm12
00007f7c123d9848  vmovaps [rsp+0xD0], xmm14
00007f7c123d9851  vmovaps [rsp+0xE0], xmm15
00007f7c123d985a  sub rsp, 0x30
00007f7c123d985e  movaps [rsp], xmm13
00007f7c123d9863  movaps [rsp+0x10], xmm15
00007f7c123d9869  movaps [rsp+0x20], xmm9
00007f7c123d986f  lea rdi, [rsp]
00007f7c123d9873  mov esi, 0x00
00007f7c123d9878  mov rax, 0x5E723D793530
00007f7c123d9882  call rax
00007f7c123d9884  movaps xmm13, [rsp]
00007f7c123d9889  add rsp, 0x30
00007f7c123d988d  vmovaps xmm0, [rsp]
00007f7c123d9892  vmovaps xmm1, [rsp+0x10]
00007f7c123d9898  vmovaps xmm2, [rsp+0x20]
00007f7c123d989e  vmovaps xmm3, [rsp+0x30]
00007f7c123d98a4  vmovaps xmm4, [rsp+0x40]
00007f7c123d98aa  vmovaps xmm5, [rsp+0x50]
00007f7c123d98b0  vmovaps xmm6, [rsp+0x60]
00007f7c123d98b6  vmovaps xmm7, [rsp+0x70]
00007f7c123d98bc  vmovaps xmm8, [rsp+0x80]
00007f7c123d98c5  vmovaps xmm9, [rsp+0x90]
00007f7c123d98ce  vmovaps xmm10, [rsp+0xA0]
00007f7c123d98d7  vmovaps xmm11, [rsp+0xB0]
00007f7c123d98e0  vmovaps xmm12, [rsp+0xC0]
00007f7c123d98e9  vmovaps xmm14, [rsp+0xD0]
00007f7c123d98f2  vmovaps xmm15, [rsp+0xE0]
00007f7c123d98fb  add rsp, 0xF0
00007f7c123d9902  pop r11
00007f7c123d9904  pop r10
00007f7c123d9906  pop r9
00007f7c123d9908  pop r8
00007f7c123d990a  pop rsi
00007f7c123d990b  pop rdi
00007f7c123d990c  pop rdx
00007f7c123d990d  pop rcx
00007f7c123d990e  pop rax
00007f7c123d990f  add rsp, 0x08
00007f7c123d9913  jmp 0x00007F7C123D62A5
00007f7c123d9918  sub rsp, 0x08
00007f7c123d991c  push rax
00007f7c123d991d  push rcx
00007f7c123d991e  push rdx
00007f7c123d991f  push rdi
00007f7c123d9920  push rsi
00007f7c123d9921  push r8
00007f7c123d9923  push r9
00007f7c123d9925  push r10
00007f7c123d9927  push r11
00007f7c123d9929  sub rsp, 0xF0
00007f7c123d9930  vmovaps [rsp], xmm0
00007f7c123d9935  vmovaps [rsp+0x10], xmm1
00007f7c123d993b  vmovaps [rsp+0x20], xmm2
00007f7c123d9941  vmovaps [rsp+0x30], xmm3
00007f7c123d9947  vmovaps [rsp+0x40], xmm4
00007f7c123d994d  vmovaps [rsp+0x50], xmm5
00007f7c123d9953  vmovaps [rsp+0x60], xmm6
00007f7c123d9959  vmovaps [rsp+0x70], xmm7
00007f7c123d995f  vmovaps [rsp+0x80], xmm8
00007f7c123d9968  vmovaps [rsp+0x90], xmm9
00007f7c123d9971  vmovaps [rsp+0xA0], xmm10
00007f7c123d997a  vmovaps [rsp+0xB0], xmm11
00007f7c123d9983  vmovaps [rsp+0xC0], xmm12
00007f7c123d998c  vmovaps [rsp+0xD0], xmm13
00007f7c123d9995  vmovaps [rsp+0xE0], xmm14
00007f7c123d999e  sub rsp, 0x30
00007f7c123d99a2  movaps [rsp], xmm15
00007f7c123d99a7  movaps [rsp+0x10], xmm1
00007f7c123d99ac  movaps [rsp+0x20], xmm5
00007f7c123d99b1  lea rdi, [rsp]
00007f7c123d99b5  mov esi, 0x00
00007f7c123d99ba  mov rax, 0x5E723D793530
00007f7c123d99c4  call rax
00007f7c123d99c6  movaps xmm15, [rsp]
00007f7c123d99cb  add rsp, 0x30
00007f7c123d99cf  vmovaps xmm0, [rsp]
00007f7c123d99d4  vmovaps xmm1, [rsp+0x10]
00007f7c123d99da  vmovaps xmm2, [rsp+0x20]
00007f7c123d99e0  vmovaps xmm3, [rsp+0x30]
00007f7c123d99e6  vmovaps xmm4, [rsp+0x40]
00007f7c123d99ec  vmovaps xmm5, [rsp+0x50]
00007f7c123d99f2  vmovaps xmm6, [rsp+0x60]
00007f7c123d99f8  vmovaps xmm7, [rsp+0x70]
00007f7c123d99fe  vmovaps xmm8, [rsp+0x80]
00007f7c123d9a07  vmovaps xmm9, [rsp+0x90]
00007f7c123d9a10  vmovaps xmm10, [rsp+0xA0]
00007f7c123d9a19  vmovaps xmm11, [rsp+0xB0]
00007f7c123d9a22  vmovaps xmm12, [rsp+0xC0]
00007f7c123d9a2b  vmovaps xmm13, [rsp+0xD0]
00007f7c123d9a34  vmovaps xmm14, [rsp+0xE0]
00007f7c123d9a3d  add rsp, 0xF0
00007f7c123d9a44  pop r11
00007f7c123d9a46  pop r10
00007f7c123d9a48  pop r9
00007f7c123d9a4a  pop r8
00007f7c123d9a4c  pop rsi
00007f7c123d9a4d  pop rdi
00007f7c123d9a4e  pop rdx
00007f7c123d9a4f  pop rcx
00007f7c123d9a50  pop rax
00007f7c123d9a51  add rsp, 0x08
00007f7c123d9a55  jmp 0x00007F7C123D62C0
00007f7c123d9a5a  call 0x00007F7C122D64F0
00007f7c123d9a5f  jmp 0x00007F7C123D631B
00007f7c123d9a64  sub rsp, 0x08
00007f7c123d9a68  push rax
00007f7c123d9a69  push rcx
00007f7c123d9a6a  push rdx
00007f7c123d9a6b  push rdi
00007f7c123d9a6c  push rsi
00007f7c123d9a6d  push r8
00007f7c123d9a6f  push r9
00007f7c123d9a71  push r10
00007f7c123d9a73  push r11
00007f7c123d9a75  sub rsp, 0xF0
00007f7c123d9a7c  vmovaps [rsp], xmm0
00007f7c123d9a81  vmovaps [rsp+0x10], xmm1
00007f7c123d9a87  vmovaps [rsp+0x20], xmm2
00007f7c123d9a8d  vmovaps [rsp+0x30], xmm3
00007f7c123d9a93  vmovaps [rsp+0x40], xmm4
00007f7c123d9a99  vmovaps [rsp+0x50], xmm5
00007f7c123d9a9f  vmovaps [rsp+0x60], xmm6
00007f7c123d9aa5  vmovaps [rsp+0x70], xmm7
00007f7c123d9aab  vmovaps [rsp+0x80], xmm8
00007f7c123d9ab4  vmovaps [rsp+0x90], xmm10
00007f7c123d9abd  vmovaps [rsp+0xA0], xmm11
00007f7c123d9ac6  vmovaps [rsp+0xB0], xmm12
00007f7c123d9acf  vmovaps [rsp+0xC0], xmm13
00007f7c123d9ad8  vmovaps [rsp+0xD0], xmm14
00007f7c123d9ae1  vmovaps [rsp+0xE0], xmm15
00007f7c123d9aea  sub rsp, 0x30
00007f7c123d9aee  movaps [rsp], xmm9
00007f7c123d9af3  movaps [rsp+0x10], xmm8
00007f7c123d9af9  movaps [rsp+0x20], xmm11
00007f7c123d9aff  lea rdi, [rsp]
00007f7c123d9b03  mov esi, 0x00
00007f7c123d9b08  mov rax, 0x5E723D793530
00007f7c123d9b12  call rax
00007f7c123d9b14  movaps xmm9, [rsp]
00007f7c123d9b19  add rsp, 0x30
00007f7c123d9b1d  vmovaps xmm0, [rsp]
00007f7c123d9b22  vmovaps xmm1, [rsp+0x10]
00007f7c123d9b28  vmovaps xmm2, [rsp+0x20]
00007f7c123d9b2e  vmovaps xmm3, [rsp+0x30]
00007f7c123d9b34  vmovaps xmm4, [rsp+0x40]
00007f7c123d9b3a  vmovaps xmm5, [rsp+0x50]
00007f7c123d9b40  vmovaps xmm6, [rsp+0x60]
00007f7c123d9b46  vmovaps xmm7, [rsp+0x70]
00007f7c123d9b4c  vmovaps xmm8, [rsp+0x80]
00007f7c123d9b55  vmovaps xmm10, [rsp+0x90]
00007f7c123d9b5e  vmovaps xmm11, [rsp+0xA0]
00007f7c123d9b67  vmovaps xmm12, [rsp+0xB0]
00007f7c123d9b70  vmovaps xmm13, [rsp+0xC0]
00007f7c123d9b79  vmovaps xmm14, [rsp+0xD0]
00007f7c123d9b82  vmovaps xmm15, [rsp+0xE0]
00007f7c123d9b8b  add rsp, 0xF0
00007f7c123d9b92  pop r11
00007f7c123d9b94  pop r10
00007f7c123d9b96  pop r9
00007f7c123d9b98  pop r8
00007f7c123d9b9a  pop rsi
00007f7c123d9b9b  pop rdi
00007f7c123d9b9c  pop rdx
00007f7c123d9b9d  pop rcx
00007f7c123d9b9e  pop rax
00007f7c123d9b9f  add rsp, 0x08
00007f7c123d9ba3  jmp 0x00007F7C123D6352
00007f7c123d9ba8  sub rsp, 0x08
00007f7c123d9bac  push rax
00007f7c123d9bad  push rcx
00007f7c123d9bae  push rdx
00007f7c123d9baf  push rdi
00007f7c123d9bb0  push rsi
00007f7c123d9bb1  push r8
00007f7c123d9bb3  push r9
00007f7c123d9bb5  push r10
00007f7c123d9bb7  push r11
00007f7c123d9bb9  sub rsp, 0xF0
00007f7c123d9bc0  vmovaps [rsp], xmm0
00007f7c123d9bc5  vmovaps [rsp+0x10], xmm1
00007f7c123d9bcb  vmovaps [rsp+0x20], xmm2
00007f7c123d9bd1  vmovaps [rsp+0x30], xmm3
00007f7c123d9bd7  vmovaps [rsp+0x40], xmm4
00007f7c123d9bdd  vmovaps [rsp+0x50], xmm5
00007f7c123d9be3  vmovaps [rsp+0x60], xmm6
00007f7c123d9be9  vmovaps [rsp+0x70], xmm7
00007f7c123d9bef  vmovaps [rsp+0x80], xmm8
00007f7c123d9bf8  vmovaps [rsp+0x90], xmm9
00007f7c123d9c01  vmovaps [rsp+0xA0], xmm10
00007f7c123d9c0a  vmovaps [rsp+0xB0], xmm12
00007f7c123d9c13  vmovaps [rsp+0xC0], xmm13
00007f7c123d9c1c  vmovaps [rsp+0xD0], xmm14
00007f7c123d9c25  vmovaps [rsp+0xE0], xmm15
00007f7c123d9c2e  sub rsp, 0x30
00007f7c123d9c32  movaps [rsp], xmm11
00007f7c123d9c37  movaps [rsp+0x10], xmm10
00007f7c123d9c3d  movaps [rsp+0x20], xmm6
00007f7c123d9c42  lea rdi, [rsp]
00007f7c123d9c46  mov esi, 0x00
00007f7c123d9c4b  mov rax, 0x5E723D793530
00007f7c123d9c55  call rax
00007f7c123d9c57  movaps xmm11, [rsp]
00007f7c123d9c5c  add rsp, 0x30
00007f7c123d9c60  vmovaps xmm0, [rsp]
00007f7c123d9c65  vmovaps xmm1, [rsp+0x10]
00007f7c123d9c6b  vmovaps xmm2, [rsp+0x20]
00007f7c123d9c71  vmovaps xmm3, [rsp+0x30]
00007f7c123d9c77  vmovaps xmm4, [rsp+0x40]
00007f7c123d9c7d  vmovaps xmm5, [rsp+0x50]
00007f7c123d9c83  vmovaps xmm6, [rsp+0x60]
00007f7c123d9c89  vmovaps xmm7, [rsp+0x70]
00007f7c123d9c8f  vmovaps xmm8, [rsp+0x80]
00007f7c123d9c98  vmovaps xmm9, [rsp+0x90]
00007f7c123d9ca1  vmovaps xmm10, [rsp+0xA0]
00007f7c123d9caa  vmovaps xmm12, [rsp+0xB0]
00007f7c123d9cb3  vmovaps xmm13, [rsp+0xC0]
00007f7c123d9cbc  vmovaps xmm14, [rsp+0xD0]
00007f7c123d9cc5  vmovaps xmm15, [rsp+0xE0]
00007f7c123d9cce  add rsp, 0xF0
00007f7c123d9cd5  pop r11
00007f7c123d9cd7  pop r10
00007f7c123d9cd9  pop r9
00007f7c123d9cdb  pop r8
00007f7c123d9cdd  pop rsi
00007f7c123d9cde  pop rdi
00007f7c123d9cdf  pop rdx
00007f7c123d9ce0  pop rcx
00007f7c123d9ce1  pop rax
00007f7c123d9ce2  add rsp, 0x08
00007f7c123d9ce6  jmp 0x00007F7C123D636D
00007f7c123d9ceb  sub rsp, 0x08
00007f7c123d9cef  push rax
00007f7c123d9cf0  push rcx
00007f7c123d9cf1  push rdx
00007f7c123d9cf2  push rdi
00007f7c123d9cf3  push rsi
00007f7c123d9cf4  push r8
00007f7c123d9cf6  push r9
00007f7c123d9cf8  push r10
00007f7c123d9cfa  push r11
00007f7c123d9cfc  sub rsp, 0xF0
00007f7c123d9d03  vmovaps [rsp], xmm0
00007f7c123d9d08  vmovaps [rsp+0x10], xmm1
00007f7c123d9d0e  vmovaps [rsp+0x20], xmm2
00007f7c123d9d14  vmovaps [rsp+0x30], xmm3
00007f7c123d9d1a  vmovaps [rsp+0x40], xmm4
00007f7c123d9d20  vmovaps [rsp+0x50], xmm5
00007f7c123d9d26  vmovaps [rsp+0x60], xmm6
00007f7c123d9d2c  vmovaps [rsp+0x70], xmm7
00007f7c123d9d32  vmovaps [rsp+0x80], xmm8
00007f7c123d9d3b  vmovaps [rsp+0x90], xmm9
00007f7c123d9d44  vmovaps [rsp+0xA0], xmm11
00007f7c123d9d4d  vmovaps [rsp+0xB0], xmm12
00007f7c123d9d56  vmovaps [rsp+0xC0], xmm13
00007f7c123d9d5f  vmovaps [rsp+0xD0], xmm14
00007f7c123d9d68  vmovaps [rsp+0xE0], xmm15
00007f7c123d9d71  sub rsp, 0x30
00007f7c123d9d75  movaps [rsp], xmm10
00007f7c123d9d7a  movaps [rsp+0x10], xmm14
00007f7c123d9d80  movaps [rsp+0x20], xmm4
00007f7c123d9d85  lea rdi, [rsp]
00007f7c123d9d89  mov esi, 0x00
00007f7c123d9d8e  mov rax, 0x5E723D793530
00007f7c123d9d98  call rax
00007f7c123d9d9a  movaps xmm10, [rsp]
00007f7c123d9d9f  add rsp, 0x30
00007f7c123d9da3  vmovaps xmm0, [rsp]
00007f7c123d9da8  vmovaps xmm1, [rsp+0x10]
00007f7c123d9dae  vmovaps xmm2, [rsp+0x20]
00007f7c123d9db4  vmovaps xmm3, [rsp+0x30]
00007f7c123d9dba  vmovaps xmm4, [rsp+0x40]
00007f7c123d9dc0  vmovaps xmm5, [rsp+0x50]
00007f7c123d9dc6  vmovaps xmm6, [rsp+0x60]
00007f7c123d9dcc  vmovaps xmm7, [rsp+0x70]
00007f7c123d9dd2  vmovaps xmm8, [rsp+0x80]
00007f7c123d9ddb  vmovaps xmm9, [rsp+0x90]
00007f7c123d9de4  vmovaps xmm11, [rsp+0xA0]
00007f7c123d9ded  vmovaps xmm12, [rsp+0xB0]
00007f7c123d9df6  vmovaps xmm13, [rsp+0xC0]
00007f7c123d9dff  vmovaps xmm14, [rsp+0xD0]
00007f7c123d9e08  vmovaps xmm15, [rsp+0xE0]
00007f7c123d9e11  add rsp, 0xF0
00007f7c123d9e18  pop r11
00007f7c123d9e1a  pop r10
00007f7c123d9e1c  pop r9
00007f7c123d9e1e  pop r8
00007f7c123d9e20  pop rsi
00007f7c123d9e21  pop rdi
00007f7c123d9e22  pop rdx
00007f7c123d9e23  pop rcx
00007f7c123d9e24  pop rax
00007f7c123d9e25  add rsp, 0x08
00007f7c123d9e29  jmp 0x00007F7C123D6388
00007f7c123d9e2e  sub rsp, 0x08
00007f7c123d9e32  push rax
00007f7c123d9e33  push rcx
00007f7c123d9e34  push rdx
00007f7c123d9e35  push rdi
00007f7c123d9e36  push rsi
00007f7c123d9e37  push r8
00007f7c123d9e39  push r9
00007f7c123d9e3b  push r10
00007f7c123d9e3d  push r11
00007f7c123d9e3f  sub rsp, 0xF0
00007f7c123d9e46  vmovaps [rsp], xmm0
00007f7c123d9e4b  vmovaps [rsp+0x10], xmm1
00007f7c123d9e51  vmovaps [rsp+0x20], xmm2
00007f7c123d9e57  vmovaps [rsp+0x30], xmm3
00007f7c123d9e5d  vmovaps [rsp+0x40], xmm4
00007f7c123d9e63  vmovaps [rsp+0x50], xmm5
00007f7c123d9e69  vmovaps [rsp+0x60], xmm6
00007f7c123d9e6f  vmovaps [rsp+0x70], xmm7
00007f7c123d9e75  vmovaps [rsp+0x80], xmm9
00007f7c123d9e7e  vmovaps [rsp+0x90], xmm10
00007f7c123d9e87  vmovaps [rsp+0xA0], xmm11
00007f7c123d9e90  vmovaps [rsp+0xB0], xmm12
00007f7c123d9e99  vmovaps [rsp+0xC0], xmm13
00007f7c123d9ea2  vmovaps [rsp+0xD0], xmm14
00007f7c123d9eab  vmovaps [rsp+0xE0], xmm15
00007f7c123d9eb4  sub rsp, 0x30
00007f7c123d9eb8  movaps [rsp], xmm8
00007f7c123d9ebd  movaps [rsp+0x10], xmm1
00007f7c123d9ec2  movaps [rsp+0x20], xmm14
00007f7c123d9ec8  lea rdi, [rsp]
00007f7c123d9ecc  mov esi, 0x00
00007f7c123d9ed1  mov rax, 0x5E723D793530
00007f7c123d9edb  call rax
00007f7c123d9edd  movaps xmm8, [rsp]
00007f7c123d9ee2  add rsp, 0x30
00007f7c123d9ee6  vmovaps xmm0, [rsp]
00007f7c123d9eeb  vmovaps xmm1, [rsp+0x10]
00007f7c123d9ef1  vmovaps xmm2, [rsp+0x20]
00007f7c123d9ef7  vmovaps xmm3, [rsp+0x30]
00007f7c123d9efd  vmovaps xmm4, [rsp+0x40]
00007f7c123d9f03  vmovaps xmm5, [rsp+0x50]
00007f7c123d9f09  vmovaps xmm6, [rsp+0x60]
00007f7c123d9f0f  vmovaps xmm7, [rsp+0x70]
00007f7c123d9f15  vmovaps xmm9, [rsp+0x80]
00007f7c123d9f1e  vmovaps xmm10, [rsp+0x90]
00007f7c123d9f27  vmovaps xmm11, [rsp+0xA0]
00007f7c123d9f30  vmovaps xmm12, [rsp+0xB0]
00007f7c123d9f39  vmovaps xmm13, [rsp+0xC0]
00007f7c123d9f42  vmovaps xmm14, [rsp+0xD0]
00007f7c123d9f4b  vmovaps xmm15, [rsp+0xE0]
00007f7c123d9f54  add rsp, 0xF0
00007f7c123d9f5b  pop r11
00007f7c123d9f5d  pop r10
00007f7c123d9f5f  pop r9
00007f7c123d9f61  pop r8
00007f7c123d9f63  pop rsi
00007f7c123d9f64  pop rdi
00007f7c123d9f65  pop rdx
00007f7c123d9f66  pop rcx
00007f7c123d9f67  pop rax
00007f7c123d9f68  add rsp, 0x08
00007f7c123d9f6c  jmp 0x00007F7C123D63AE
00007f7c123d9f71  sub rsp, 0x08
00007f7c123d9f75  push rax
00007f7c123d9f76  push rcx
00007f7c123d9f77  push rdx
00007f7c123d9f78  push rdi
00007f7c123d9f79  push rsi
00007f7c123d9f7a  push r8
00007f7c123d9f7c  push r9
00007f7c123d9f7e  push r10
00007f7c123d9f80  push r11
00007f7c123d9f82  sub rsp, 0xF0
00007f7c123d9f89  vmovaps [rsp], xmm0
00007f7c123d9f8e  vmovaps [rsp+0x10], xmm1
00007f7c123d9f94  vmovaps [rsp+0x20], xmm2
00007f7c123d9f9a  vmovaps [rsp+0x30], xmm3
00007f7c123d9fa0  vmovaps [rsp+0x40], xmm4
00007f7c123d9fa6  vmovaps [rsp+0x50], xmm5
00007f7c123d9fac  vmovaps [rsp+0x60], xmm7
00007f7c123d9fb2  vmovaps [rsp+0x70], xmm8
00007f7c123d9fb8  vmovaps [rsp+0x80], xmm9
00007f7c123d9fc1  vmovaps [rsp+0x90], xmm10
00007f7c123d9fca  vmovaps [rsp+0xA0], xmm11
00007f7c123d9fd3  vmovaps [rsp+0xB0], xmm12
00007f7c123d9fdc  vmovaps [rsp+0xC0], xmm13
00007f7c123d9fe5  vmovaps [rsp+0xD0], xmm14
00007f7c123d9fee  vmovaps [rsp+0xE0], xmm15
00007f7c123d9ff7  sub rsp, 0x30
00007f7c123d9ffb  movaps [rsp], xmm6
00007f7c123d9fff  movaps [rsp+0x10], xmm1
00007f7c123da004  movaps [rsp+0x20], xmm14
00007f7c123da00a  lea rdi, [rsp]
00007f7c123da00e  mov esi, 0x00
00007f7c123da013  mov rax, 0x5E723D793530
00007f7c123da01d  call rax
00007f7c123da01f  movaps xmm6, [rsp]
00007f7c123da023  add rsp, 0x30
00007f7c123da027  vmovaps xmm0, [rsp]
00007f7c123da02c  vmovaps xmm1, [rsp+0x10]
00007f7c123da032  vmovaps xmm2, [rsp+0x20]
00007f7c123da038  vmovaps xmm3, [rsp+0x30]
00007f7c123da03e  vmovaps xmm4, [rsp+0x40]
00007f7c123da044  vmovaps xmm5, [rsp+0x50]
00007f7c123da04a  vmovaps xmm7, [rsp+0x60]
00007f7c123da050  vmovaps xmm8, [rsp+0x70]
00007f7c123da056  vmovaps xmm9, [rsp+0x80]
00007f7c123da05f  vmovaps xmm10, [rsp+0x90]
00007f7c123da068  vmovaps xmm11, [rsp+0xA0]
00007f7c123da071  vmovaps xmm12, [rsp+0xB0]
00007f7c123da07a  vmovaps xmm13, [rsp+0xC0]
00007f7c123da083  vmovaps xmm14, [rsp+0xD0]
00007f7c123da08c  vmovaps xmm15, [rsp+0xE0]
00007f7c123da095  add rsp, 0xF0
00007f7c123da09c  pop r11
00007f7c123da09e  pop r10
00007f7c123da0a0  pop r9
00007f7c123da0a2  pop r8
00007f7c123da0a4  pop rsi
00007f7c123da0a5  pop rdi
00007f7c123da0a6  pop rdx
00007f7c123da0a7  pop rcx
00007f7c123da0a8  pop rax
00007f7c123da0a9  add rsp, 0x08
00007f7c123da0ad  jmp 0x00007F7C123D63DA
00007f7c123da0b2  sub rsp, 0x08
00007f7c123da0b6  push rax
00007f7c123da0b7  push rcx
00007f7c123da0b8  push rdx
00007f7c123da0b9  push rdi
00007f7c123da0ba  push rsi
00007f7c123da0bb  push r8
00007f7c123da0bd  push r9
00007f7c123da0bf  push r10
00007f7c123da0c1  push r11
00007f7c123da0c3  sub rsp, 0xF0
00007f7c123da0ca  vmovaps [rsp], xmm0
00007f7c123da0cf  vmovaps [rsp+0x10], xmm1
00007f7c123da0d5  vmovaps [rsp+0x20], xmm2
00007f7c123da0db  vmovaps [rsp+0x30], xmm3
00007f7c123da0e1  vmovaps [rsp+0x40], xmm4
00007f7c123da0e7  vmovaps [rsp+0x50], xmm5
00007f7c123da0ed  vmovaps [rsp+0x60], xmm6
00007f7c123da0f3  vmovaps [rsp+0x70], xmm7
00007f7c123da0f9  vmovaps [rsp+0x80], xmm8
00007f7c123da102  vmovaps [rsp+0x90], xmm9
00007f7c123da10b  vmovaps [rsp+0xA0], xmm10
00007f7c123da114  vmovaps [rsp+0xB0], xmm11
00007f7c123da11d  vmovaps [rsp+0xC0], xmm12
00007f7c123da126  vmovaps [rsp+0xD0], xmm13
00007f7c123da12f  vmovaps [rsp+0xE0], xmm15
00007f7c123da138  sub rsp, 0x30
00007f7c123da13c  movaps [rsp], xmm14
00007f7c123da141  movaps [rsp+0x10], xmm12
00007f7c123da147  movaps [rsp+0x20], xmm1
00007f7c123da14c  lea rdi, [rsp]
00007f7c123da150  mov esi, 0x00
00007f7c123da155  mov rax, 0x5E723D793530
00007f7c123da15f  call rax
00007f7c123da161  movaps xmm14, [rsp]
00007f7c123da166  add rsp, 0x30
00007f7c123da16a  vmovaps xmm0, [rsp]
00007f7c123da16f  vmovaps xmm1, [rsp+0x10]
00007f7c123da175  vmovaps xmm2, [rsp+0x20]
00007f7c123da17b  vmovaps xmm3, [rsp+0x30]
00007f7c123da181  vmovaps xmm4, [rsp+0x40]
00007f7c123da187  vmovaps xmm5, [rsp+0x50]
00007f7c123da18d  vmovaps xmm6, [rsp+0x60]
00007f7c123da193  vmovaps xmm7, [rsp+0x70]
00007f7c123da199  vmovaps xmm8, [rsp+0x80]
00007f7c123da1a2  vmovaps xmm9, [rsp+0x90]
00007f7c123da1ab  vmovaps xmm10, [rsp+0xA0]
00007f7c123da1b4  vmovaps xmm11, [rsp+0xB0]
00007f7c123da1bd  vmovaps xmm12, [rsp+0xC0]
00007f7c123da1c6  vmovaps xmm13, [rsp+0xD0]
00007f7c123da1cf  vmovaps xmm15, [rsp+0xE0]
00007f7c123da1d8  add rsp, 0xF0
00007f7c123da1df  pop r11
00007f7c123da1e1  pop r10
00007f7c123da1e3  pop r9
00007f7c123da1e5  pop r8
00007f7c123da1e7  pop rsi
00007f7c123da1e8  pop rdi
00007f7c123da1e9  pop rdx
00007f7c123da1ea  pop rcx
00007f7c123da1eb  pop rax
00007f7c123da1ec  add rsp, 0x08
00007f7c123da1f0  jmp 0x00007F7C123D6400
00007f7c123da1f5  sub rsp, 0x08
00007f7c123da1f9  push rax
00007f7c123da1fa  push rcx
00007f7c123da1fb  push rdx
00007f7c123da1fc  push rdi
00007f7c123da1fd  push rsi
00007f7c123da1fe  push r8
00007f7c123da200  push r9
00007f7c123da202  push r10
00007f7c123da204  push r11
00007f7c123da206  sub rsp, 0xF0
00007f7c123da20d  vmovaps [rsp], xmm0
00007f7c123da212  vmovaps [rsp+0x10], xmm2
00007f7c123da218  vmovaps [rsp+0x20], xmm3
00007f7c123da21e  vmovaps [rsp+0x30], xmm4
00007f7c123da224  vmovaps [rsp+0x40], xmm5
00007f7c123da22a  vmovaps [rsp+0x50], xmm6
00007f7c123da230  vmovaps [rsp+0x60], xmm7
00007f7c123da236  vmovaps [rsp+0x70], xmm8
00007f7c123da23c  vmovaps [rsp+0x80], xmm9
00007f7c123da245  vmovaps [rsp+0x90], xmm10
00007f7c123da24e  vmovaps [rsp+0xA0], xmm11
00007f7c123da257  vmovaps [rsp+0xB0], xmm12
00007f7c123da260  vmovaps [rsp+0xC0], xmm13
00007f7c123da269  vmovaps [rsp+0xD0], xmm14
00007f7c123da272  vmovaps [rsp+0xE0], xmm15
00007f7c123da27b  sub rsp, 0x30
00007f7c123da27f  movaps [rsp], xmm1
00007f7c123da283  movaps [rsp+0x10], xmm13
00007f7c123da289  movaps [rsp+0x20], xmm9
00007f7c123da28f  lea rdi, [rsp]
00007f7c123da293  mov esi, 0x00
00007f7c123da298  mov rax, 0x5E723D793530
00007f7c123da2a2  call rax
00007f7c123da2a4  movaps xmm1, [rsp]
00007f7c123da2a8  add rsp, 0x30
00007f7c123da2ac  vmovaps xmm0, [rsp]
00007f7c123da2b1  vmovaps xmm2, [rsp+0x10]
00007f7c123da2b7  vmovaps xmm3, [rsp+0x20]
00007f7c123da2bd  vmovaps xmm4, [rsp+0x30]
00007f7c123da2c3  vmovaps xmm5, [rsp+0x40]
00007f7c123da2c9  vmovaps xmm6, [rsp+0x50]
00007f7c123da2cf  vmovaps xmm7, [rsp+0x60]
00007f7c123da2d5  vmovaps xmm8, [rsp+0x70]
00007f7c123da2db  vmovaps xmm9, [rsp+0x80]
00007f7c123da2e4  vmovaps xmm10, [rsp+0x90]
00007f7c123da2ed  vmovaps xmm11, [rsp+0xA0]
00007f7c123da2f6  vmovaps xmm12, [rsp+0xB0]
00007f7c123da2ff  vmovaps xmm13, [rsp+0xC0]
00007f7c123da308  vmovaps xmm14, [rsp+0xD0]
00007f7c123da311  vmovaps xmm15, [rsp+0xE0]
00007f7c123da31a  add rsp, 0xF0
00007f7c123da321  pop r11
00007f7c123da323  pop r10
00007f7c123da325  pop r9
00007f7c123da327  pop r8
00007f7c123da329  pop rsi
00007f7c123da32a  pop rdi
00007f7c123da32b  pop rdx
00007f7c123da32c  pop rcx
00007f7c123da32d  pop rax
00007f7c123da32e  add rsp, 0x08
00007f7c123da332  jmp 0x00007F7C123D641A
00007f7c123da337  sub rsp, 0x08
00007f7c123da33b  push rax
00007f7c123da33c  push rcx
00007f7c123da33d  push rdx
00007f7c123da33e  push rdi
00007f7c123da33f  push rsi
00007f7c123da340  push r8
00007f7c123da342  push r9
00007f7c123da344  push r10
00007f7c123da346  push r11
00007f7c123da348  sub rsp, 0xF0
00007f7c123da34f  vmovaps [rsp], xmm0
00007f7c123da354  vmovaps [rsp+0x10], xmm1
00007f7c123da35a  vmovaps [rsp+0x20], xmm2
00007f7c123da360  vmovaps [rsp+0x30], xmm3
00007f7c123da366  vmovaps [rsp+0x40], xmm4
00007f7c123da36c  vmovaps [rsp+0x50], xmm5
00007f7c123da372  vmovaps [rsp+0x60], xmm6
00007f7c123da378  vmovaps [rsp+0x70], xmm7
00007f7c123da37e  vmovaps [rsp+0x80], xmm8
00007f7c123da387  vmovaps [rsp+0x90], xmm9
00007f7c123da390  vmovaps [rsp+0xA0], xmm10
00007f7c123da399  vmovaps [rsp+0xB0], xmm11
00007f7c123da3a2  vmovaps [rsp+0xC0], xmm13
00007f7c123da3ab  vmovaps [rsp+0xD0], xmm14
00007f7c123da3b4  vmovaps [rsp+0xE0], xmm15
00007f7c123da3bd  sub rsp, 0x30
00007f7c123da3c1  movaps [rsp], xmm12
00007f7c123da3c6  movaps [rsp+0x10], xmm7
00007f7c123da3cb  movaps [rsp+0x20], xmm13
00007f7c123da3d1  lea rdi, [rsp]
00007f7c123da3d5  mov esi, 0x00
00007f7c123da3da  mov rax, 0x5E723D793530
00007f7c123da3e4  call rax
00007f7c123da3e6  movaps xmm12, [rsp]
00007f7c123da3eb  add rsp, 0x30
00007f7c123da3ef  vmovaps xmm0, [rsp]
00007f7c123da3f4  vmovaps xmm1, [rsp+0x10]
00007f7c123da3fa  vmovaps xmm2, [rsp+0x20]
00007f7c123da400  vmovaps xmm3, [rsp+0x30]
00007f7c123da406  vmovaps xmm4, [rsp+0x40]
00007f7c123da40c  vmovaps xmm5, [rsp+0x50]
00007f7c123da412  vmovaps xmm6, [rsp+0x60]
00007f7c123da418  vmovaps xmm7, [rsp+0x70]
00007f7c123da41e  vmovaps xmm8, [rsp+0x80]
00007f7c123da427  vmovaps xmm9, [rsp+0x90]
00007f7c123da430  vmovaps xmm10, [rsp+0xA0]
00007f7c123da439  vmovaps xmm11, [rsp+0xB0]
00007f7c123da442  vmovaps xmm13, [rsp+0xC0]
00007f7c123da44b  vmovaps xmm14, [rsp+0xD0]
00007f7c123da454  vmovaps xmm15, [rsp+0xE0]
00007f7c123da45d  add rsp, 0xF0
00007f7c123da464  pop r11
00007f7c123da466  pop r10
00007f7c123da468  pop r9
00007f7c123da46a  pop r8
00007f7c123da46c  pop rsi
00007f7c123da46d  pop rdi
00007f7c123da46e  pop rdx
00007f7c123da46f  pop rcx
00007f7c123da470  pop rax
00007f7c123da471  add rsp, 0x08
00007f7c123da475  jmp 0x00007F7C123D6441
00007f7c123da47a  sub rsp, 0x08
00007f7c123da47e  push rax
00007f7c123da47f  push rcx
00007f7c123da480  push rdx
00007f7c123da481  push rdi
00007f7c123da482  push rsi
00007f7c123da483  push r8
00007f7c123da485  push r9
00007f7c123da487  push r10
00007f7c123da489  push r11
00007f7c123da48b  sub rsp, 0xF0
00007f7c123da492  vmovaps [rsp], xmm0
00007f7c123da497  vmovaps [rsp+0x10], xmm1
00007f7c123da49d  vmovaps [rsp+0x20], xmm2
00007f7c123da4a3  vmovaps [rsp+0x30], xmm3
00007f7c123da4a9  vmovaps [rsp+0x40], xmm4
00007f7c123da4af  vmovaps [rsp+0x50], xmm5
00007f7c123da4b5  vmovaps [rsp+0x60], xmm6
00007f7c123da4bb  vmovaps [rsp+0x70], xmm7
00007f7c123da4c1  vmovaps [rsp+0x80], xmm8
00007f7c123da4ca  vmovaps [rsp+0x90], xmm9
00007f7c123da4d3  vmovaps [rsp+0xA0], xmm10
00007f7c123da4dc  vmovaps [rsp+0xB0], xmm11
00007f7c123da4e5  vmovaps [rsp+0xC0], xmm12
00007f7c123da4ee  vmovaps [rsp+0xD0], xmm14
00007f7c123da4f7  vmovaps [rsp+0xE0], xmm15
00007f7c123da500  sub rsp, 0x30
00007f7c123da504  movaps [rsp], xmm13
00007f7c123da509  movaps [rsp+0x10], xmm15
00007f7c123da50f  movaps [rsp+0x20], xmm8
00007f7c123da515  lea rdi, [rsp]
00007f7c123da519  mov esi, 0x00
00007f7c123da51e  mov rax, 0x5E723D793530
00007f7c123da528  call rax
00007f7c123da52a  movaps xmm13, [rsp]
00007f7c123da52f  add rsp, 0x30
00007f7c123da533  vmovaps xmm0, [rsp]
00007f7c123da538  vmovaps xmm1, [rsp+0x10]
00007f7c123da53e  vmovaps xmm2, [rsp+0x20]
00007f7c123da544  vmovaps xmm3, [rsp+0x30]
00007f7c123da54a  vmovaps xmm4, [rsp+0x40]
00007f7c123da550  vmovaps xmm5, [rsp+0x50]
00007f7c123da556  vmovaps xmm6, [rsp+0x60]
00007f7c123da55c  vmovaps xmm7, [rsp+0x70]
00007f7c123da562  vmovaps xmm8, [rsp+0x80]
00007f7c123da56b  vmovaps xmm9, [rsp+0x90]
00007f7c123da574  vmovaps xmm10, [rsp+0xA0]
00007f7c123da57d  vmovaps xmm11, [rsp+0xB0]
00007f7c123da586  vmovaps xmm12, [rsp+0xC0]
00007f7c123da58f  vmovaps xmm14, [rsp+0xD0]
00007f7c123da598  vmovaps xmm15, [rsp+0xE0]
00007f7c123da5a1  add rsp, 0xF0
00007f7c123da5a8  pop r11
00007f7c123da5aa  pop r10
00007f7c123da5ac  pop r9
00007f7c123da5ae  pop r8
00007f7c123da5b0  pop rsi
00007f7c123da5b1  pop rdi
00007f7c123da5b2  pop rdx
00007f7c123da5b3  pop rcx
00007f7c123da5b4  pop rax
00007f7c123da5b5  add rsp, 0x08
00007f7c123da5b9  jmp 0x00007F7C123D645C
00007f7c123da5be  sub rsp, 0x08
00007f7c123da5c2  push rax
00007f7c123da5c3  push rcx
00007f7c123da5c4  push rdx
00007f7c123da5c5  push rdi
00007f7c123da5c6  push rsi
00007f7c123da5c7  push r8
00007f7c123da5c9  push r9
00007f7c123da5cb  push r10
00007f7c123da5cd  push r11
00007f7c123da5cf  sub rsp, 0xF0
00007f7c123da5d6  vmovaps [rsp], xmm0
00007f7c123da5db  vmovaps [rsp+0x10], xmm1
00007f7c123da5e1  vmovaps [rsp+0x20], xmm2
00007f7c123da5e7  vmovaps [rsp+0x30], xmm3
00007f7c123da5ed  vmovaps [rsp+0x40], xmm4
00007f7c123da5f3  vmovaps [rsp+0x50], xmm5
00007f7c123da5f9  vmovaps [rsp+0x60], xmm6
00007f7c123da5ff  vmovaps [rsp+0x70], xmm7
00007f7c123da605  vmovaps [rsp+0x80], xmm9
00007f7c123da60e  vmovaps [rsp+0x90], xmm10
00007f7c123da617  vmovaps [rsp+0xA0], xmm11
00007f7c123da620  vmovaps [rsp+0xB0], xmm12
00007f7c123da629  vmovaps [rsp+0xC0], xmm13
00007f7c123da632  vmovaps [rsp+0xD0], xmm14
00007f7c123da63b  vmovaps [rsp+0xE0], xmm15
00007f7c123da644  sub rsp, 0x30
00007f7c123da648  movaps [rsp], xmm8
00007f7c123da64d  movaps [rsp+0x10], xmm15
00007f7c123da653  movaps [rsp+0x20], xmm9
00007f7c123da659  lea rdi, [rsp]
00007f7c123da65d  mov esi, 0x00
00007f7c123da662  mov rax, 0x5E723D793530
00007f7c123da66c  call rax
00007f7c123da66e  movaps xmm8, [rsp]
00007f7c123da673  add rsp, 0x30
00007f7c123da677  vmovaps xmm0, [rsp]
00007f7c123da67c  vmovaps xmm1, [rsp+0x10]
00007f7c123da682  vmovaps xmm2, [rsp+0x20]
00007f7c123da688  vmovaps xmm3, [rsp+0x30]
00007f7c123da68e  vmovaps xmm4, [rsp+0x40]
00007f7c123da694  vmovaps xmm5, [rsp+0x50]
00007f7c123da69a  vmovaps xmm6, [rsp+0x60]
00007f7c123da6a0  vmovaps xmm7, [rsp+0x70]
00007f7c123da6a6  vmovaps xmm9, [rsp+0x80]
00007f7c123da6af  vmovaps xmm10, [rsp+0x90]
00007f7c123da6b8  vmovaps xmm11, [rsp+0xA0]
00007f7c123da6c1  vmovaps xmm12, [rsp+0xB0]
00007f7c123da6ca  vmovaps xmm13, [rsp+0xC0]
00007f7c123da6d3  vmovaps xmm14, [rsp+0xD0]
00007f7c123da6dc  vmovaps xmm15, [rsp+0xE0]
00007f7c123da6e5  add rsp, 0xF0
00007f7c123da6ec  pop r11
00007f7c123da6ee  pop r10
00007f7c123da6f0  pop r9
00007f7c123da6f2  pop r8
00007f7c123da6f4  pop rsi
00007f7c123da6f5  pop rdi
00007f7c123da6f6  pop rdx
00007f7c123da6f7  pop rcx
00007f7c123da6f8  pop rax
00007f7c123da6f9  add rsp, 0x08
00007f7c123da6fd  jmp 0x00007F7C123D648A
00007f7c123da702  sub rsp, 0x08
00007f7c123da706  push rax
00007f7c123da707  push rcx
00007f7c123da708  push rdx
00007f7c123da709  push rdi
00007f7c123da70a  push rsi
00007f7c123da70b  push r8
00007f7c123da70d  push r9
00007f7c123da70f  push r10
00007f7c123da711  push r11
00007f7c123da713  sub rsp, 0xF0
00007f7c123da71a  vmovaps [rsp], xmm0
00007f7c123da71f  vmovaps [rsp+0x10], xmm1
00007f7c123da725  vmovaps [rsp+0x20], xmm2
00007f7c123da72b  vmovaps [rsp+0x30], xmm3
00007f7c123da731  vmovaps [rsp+0x40], xmm4
00007f7c123da737  vmovaps [rsp+0x50], xmm5
00007f7c123da73d  vmovaps [rsp+0x60], xmm6
00007f7c123da743  vmovaps [rsp+0x70], xmm7
00007f7c123da749  vmovaps [rsp+0x80], xmm8
00007f7c123da752  vmovaps [rsp+0x90], xmm9
00007f7c123da75b  vmovaps [rsp+0xA0], xmm10
00007f7c123da764  vmovaps [rsp+0xB0], xmm11
00007f7c123da76d  vmovaps [rsp+0xC0], xmm12
00007f7c123da776  vmovaps [rsp+0xD0], xmm13
00007f7c123da77f  vmovaps [rsp+0xE0], xmm14
00007f7c123da788  sub rsp, 0x30
00007f7c123da78c  movaps [rsp], xmm15
00007f7c123da791  movaps [rsp+0x10], xmm11
00007f7c123da797  movaps [rsp+0x20], xmm6
00007f7c123da79c  lea rdi, [rsp]
00007f7c123da7a0  mov esi, 0x00
00007f7c123da7a5  mov rax, 0x5E723D793530
00007f7c123da7af  call rax
00007f7c123da7b1  movaps xmm15, [rsp]
00007f7c123da7b6  add rsp, 0x30
00007f7c123da7ba  vmovaps xmm0, [rsp]
00007f7c123da7bf  vmovaps xmm1, [rsp+0x10]
00007f7c123da7c5  vmovaps xmm2, [rsp+0x20]
00007f7c123da7cb  vmovaps xmm3, [rsp+0x30]
00007f7c123da7d1  vmovaps xmm4, [rsp+0x40]
00007f7c123da7d7  vmovaps xmm5, [rsp+0x50]
00007f7c123da7dd  vmovaps xmm6, [rsp+0x60]
00007f7c123da7e3  vmovaps xmm7, [rsp+0x70]
00007f7c123da7e9  vmovaps xmm8, [rsp+0x80]
00007f7c123da7f2  vmovaps xmm9, [rsp+0x90]
00007f7c123da7fb  vmovaps xmm10, [rsp+0xA0]
00007f7c123da804  vmovaps xmm11, [rsp+0xB0]
00007f7c123da80d  vmovaps xmm12, [rsp+0xC0]
00007f7c123da816  vmovaps xmm13, [rsp+0xD0]
00007f7c123da81f  vmovaps xmm14, [rsp+0xE0]
00007f7c123da828  add rsp, 0xF0
00007f7c123da82f  pop r11
00007f7c123da831  pop r10
00007f7c123da833  pop r9
00007f7c123da835  pop r8
00007f7c123da837  pop rsi
00007f7c123da838  pop rdi
00007f7c123da839  pop rdx
00007f7c123da83a  pop rcx
00007f7c123da83b  pop rax
00007f7c123da83c  add rsp, 0x08
00007f7c123da840  jmp 0x00007F7C123D64A5
00007f7c123da845  sub rsp, 0x08
00007f7c123da849  push rax
00007f7c123da84a  push rcx
00007f7c123da84b  push rdx
00007f7c123da84c  push rdi
00007f7c123da84d  push rsi
00007f7c123da84e  push r8
00007f7c123da850  push r9
00007f7c123da852  push r10
00007f7c123da854  push r11
00007f7c123da856  sub rsp, 0xF0
00007f7c123da85d  vmovaps [rsp], xmm0
00007f7c123da862  vmovaps [rsp+0x10], xmm1
00007f7c123da868  vmovaps [rsp+0x20], xmm2
00007f7c123da86e  vmovaps [rsp+0x30], xmm3
00007f7c123da874  vmovaps [rsp+0x40], xmm4
00007f7c123da87a  vmovaps [rsp+0x50], xmm5
00007f7c123da880  vmovaps [rsp+0x60], xmm6
00007f7c123da886  vmovaps [rsp+0x70], xmm8
00007f7c123da88c  vmovaps [rsp+0x80], xmm9
00007f7c123da895  vmovaps [rsp+0x90], xmm10
00007f7c123da89e  vmovaps [rsp+0xA0], xmm11
00007f7c123da8a7  vmovaps [rsp+0xB0], xmm12
00007f7c123da8b0  vmovaps [rsp+0xC0], xmm13
00007f7c123da8b9  vmovaps [rsp+0xD0], xmm14
00007f7c123da8c2  vmovaps [rsp+0xE0], xmm15
00007f7c123da8cb  sub rsp, 0x30
00007f7c123da8cf  movaps [rsp], xmm7
00007f7c123da8d3  movaps [rsp+0x10], xmm11
00007f7c123da8d9  movaps [rsp+0x20], xmm9
00007f7c123da8df  lea rdi, [rsp]
00007f7c123da8e3  mov esi, 0x00
00007f7c123da8e8  mov rax, 0x5E723D793530
00007f7c123da8f2  call rax
00007f7c123da8f4  movaps xmm7, [rsp]
00007f7c123da8f8  add rsp, 0x30
00007f7c123da8fc  vmovaps xmm0, [rsp]
00007f7c123da901  vmovaps xmm1, [rsp+0x10]
00007f7c123da907  vmovaps xmm2, [rsp+0x20]
00007f7c123da90d  vmovaps xmm3, [rsp+0x30]
00007f7c123da913  vmovaps xmm4, [rsp+0x40]
00007f7c123da919  vmovaps xmm5, [rsp+0x50]
00007f7c123da91f  vmovaps xmm6, [rsp+0x60]
00007f7c123da925  vmovaps xmm8, [rsp+0x70]
00007f7c123da92b  vmovaps xmm9, [rsp+0x80]
00007f7c123da934  vmovaps xmm10, [rsp+0x90]
00007f7c123da93d  vmovaps xmm11, [rsp+0xA0]
00007f7c123da946  vmovaps xmm12, [rsp+0xB0]
00007f7c123da94f  vmovaps xmm13, [rsp+0xC0]
00007f7c123da958  vmovaps xmm14, [rsp+0xD0]
00007f7c123da961  vmovaps xmm15, [rsp+0xE0]
00007f7c123da96a  add rsp, 0xF0
00007f7c123da971  pop r11
00007f7c123da973  pop r10
00007f7c123da975  pop r9
00007f7c123da977  pop r8
00007f7c123da979  pop rsi
00007f7c123da97a  pop rdi
00007f7c123da97b  pop rdx
00007f7c123da97c  pop rcx
00007f7c123da97d  pop rax
00007f7c123da97e  add rsp, 0x08
00007f7c123da982  jmp 0x00007F7C123D64D2
00007f7c123da987  sub rsp, 0x08
00007f7c123da98b  push rax
00007f7c123da98c  push rcx
00007f7c123da98d  push rdx
00007f7c123da98e  push rdi
00007f7c123da98f  push rsi
00007f7c123da990  push r8
00007f7c123da992  push r9
00007f7c123da994  push r10
00007f7c123da996  push r11
00007f7c123da998  sub rsp, 0xF0
00007f7c123da99f  vmovaps [rsp], xmm0
00007f7c123da9a4  vmovaps [rsp+0x10], xmm1
00007f7c123da9aa  vmovaps [rsp+0x20], xmm2
00007f7c123da9b0  vmovaps [rsp+0x30], xmm3
00007f7c123da9b6  vmovaps [rsp+0x40], xmm4
00007f7c123da9bc  vmovaps [rsp+0x50], xmm5
00007f7c123da9c2  vmovaps [rsp+0x60], xmm6
00007f7c123da9c8  vmovaps [rsp+0x70], xmm7
00007f7c123da9ce  vmovaps [rsp+0x80], xmm8
00007f7c123da9d7  vmovaps [rsp+0x90], xmm9
00007f7c123da9e0  vmovaps [rsp+0xA0], xmm10
00007f7c123da9e9  vmovaps [rsp+0xB0], xmm12
00007f7c123da9f2  vmovaps [rsp+0xC0], xmm13
00007f7c123da9fb  vmovaps [rsp+0xD0], xmm14
00007f7c123daa04  vmovaps [rsp+0xE0], xmm15
00007f7c123daa0d  sub rsp, 0x30
00007f7c123daa11  movaps [rsp], xmm11
00007f7c123daa16  movaps [rsp+0x10], xmm10
00007f7c123daa1c  movaps [rsp+0x20], xmm14
00007f7c123daa22  lea rdi, [rsp]
00007f7c123daa26  mov esi, 0x00
00007f7c123daa2b  mov rax, 0x5E723D793530
00007f7c123daa35  call rax
00007f7c123daa37  movaps xmm11, [rsp]
00007f7c123daa3c  add rsp, 0x30
00007f7c123daa40  vmovaps xmm0, [rsp]
00007f7c123daa45  vmovaps xmm1, [rsp+0x10]
00007f7c123daa4b  vmovaps xmm2, [rsp+0x20]
00007f7c123daa51  vmovaps xmm3, [rsp+0x30]
00007f7c123daa57  vmovaps xmm4, [rsp+0x40]
00007f7c123daa5d  vmovaps xmm5, [rsp+0x50]
00007f7c123daa63  vmovaps xmm6, [rsp+0x60]
00007f7c123daa69  vmovaps xmm7, [rsp+0x70]
00007f7c123daa6f  vmovaps xmm8, [rsp+0x80]
00007f7c123daa78  vmovaps xmm9, [rsp+0x90]
00007f7c123daa81  vmovaps xmm10, [rsp+0xA0]
00007f7c123daa8a  vmovaps xmm12, [rsp+0xB0]
00007f7c123daa93  vmovaps xmm13, [rsp+0xC0]
00007f7c123daa9c  vmovaps xmm14, [rsp+0xD0]
00007f7c123daaa5  vmovaps xmm15, [rsp+0xE0]
00007f7c123daaae  add rsp, 0xF0
00007f7c123daab5  pop r11
00007f7c123daab7  pop r10
00007f7c123daab9  pop r9
00007f7c123daabb  pop r8
00007f7c123daabd  pop rsi
00007f7c123daabe  pop rdi
00007f7c123daabf  pop rdx
00007f7c123daac0  pop rcx
00007f7c123daac1  pop rax
00007f7c123daac2  add rsp, 0x08
00007f7c123daac6  jmp 0x00007F7C123D64ED
00007f7c123daacb  call 0x00007F7C122E45A0
00007f7c123daad0  jmp 0x00007F7C123D64F7
00007f7c123daad5  sub rsp, 0x08
00007f7c123daad9  push rax
00007f7c123daada  push rcx
00007f7c123daadb  push rdx
00007f7c123daadc  push rdi
00007f7c123daadd  push rsi
00007f7c123daade  push r8
00007f7c123daae0  push r9
00007f7c123daae2  push r10
00007f7c123daae4  push r11
00007f7c123daae6  sub rsp, 0xF0
00007f7c123daaed  vmovaps [rsp], xmm0
00007f7c123daaf2  vmovaps [rsp+0x10], xmm1
00007f7c123daaf8  vmovaps [rsp+0x20], xmm2
00007f7c123daafe  vmovaps [rsp+0x30], xmm3
00007f7c123dab04  vmovaps [rsp+0x40], xmm4
00007f7c123dab0a  vmovaps [rsp+0x50], xmm5
00007f7c123dab10  vmovaps [rsp+0x60], xmm6
00007f7c123dab16  vmovaps [rsp+0x70], xmm7
00007f7c123dab1c  vmovaps [rsp+0x80], xmm8
00007f7c123dab25  vmovaps [rsp+0x90], xmm9
00007f7c123dab2e  vmovaps [rsp+0xA0], xmm11
00007f7c123dab37  vmovaps [rsp+0xB0], xmm12
00007f7c123dab40  vmovaps [rsp+0xC0], xmm13
00007f7c123dab49  vmovaps [rsp+0xD0], xmm14
00007f7c123dab52  vmovaps [rsp+0xE0], xmm15
00007f7c123dab5b  sub rsp, 0x30
00007f7c123dab5f  movaps [rsp], xmm10
00007f7c123dab64  movaps [rsp+0x10], xmm1
00007f7c123dab69  movaps [rsp+0x20], xmm12
00007f7c123dab6f  lea rdi, [rsp]
00007f7c123dab73  mov esi, 0x00
00007f7c123dab78  mov rax, 0x5E723D793530
00007f7c123dab82  call rax
00007f7c123dab84  movaps xmm10, [rsp]
00007f7c123dab89  add rsp, 0x30
00007f7c123dab8d  vmovaps xmm0, [rsp]
00007f7c123dab92  vmovaps xmm1, [rsp+0x10]
00007f7c123dab98  vmovaps xmm2, [rsp+0x20]
00007f7c123dab9e  vmovaps xmm3, [rsp+0x30]
00007f7c123daba4  vmovaps xmm4, [rsp+0x40]
00007f7c123dabaa  vmovaps xmm5, [rsp+0x50]
00007f7c123dabb0  vmovaps xmm6, [rsp+0x60]
00007f7c123dabb6  vmovaps xmm7, [rsp+0x70]
00007f7c123dabbc  vmovaps xmm8, [rsp+0x80]
00007f7c123dabc5  vmovaps xmm9, [rsp+0x90]
00007f7c123dabce  vmovaps xmm11, [rsp+0xA0]
00007f7c123dabd7  vmovaps xmm12, [rsp+0xB0]
00007f7c123dabe0  vmovaps xmm13, [rsp+0xC0]
00007f7c123dabe9  vmovaps xmm14, [rsp+0xD0]
00007f7c123dabf2  vmovaps xmm15, [rsp+0xE0]
00007f7c123dabfb  add rsp, 0xF0
00007f7c123dac02  pop r11
00007f7c123dac04  pop r10
00007f7c123dac06  pop r9
00007f7c123dac08  pop r8
00007f7c123dac0a  pop rsi
00007f7c123dac0b  pop rdi
00007f7c123dac0c  pop rdx
00007f7c123dac0d  pop rcx
00007f7c123dac0e  pop rax
00007f7c123dac0f  add rsp, 0x08
00007f7c123dac13  jmp 0x00007F7C123D651A
00007f7c123dac18  sub rsp, 0x08
00007f7c123dac1c  push rax
00007f7c123dac1d  push rcx
00007f7c123dac1e  push rdx
00007f7c123dac1f  push rdi
00007f7c123dac20  push rsi
00007f7c123dac21  push r8
00007f7c123dac23  push r9
00007f7c123dac25  push r10
00007f7c123dac27  push r11
00007f7c123dac29  sub rsp, 0xF0
00007f7c123dac30  vmovaps [rsp], xmm0
00007f7c123dac35  vmovaps [rsp+0x10], xmm1
00007f7c123dac3b  vmovaps [rsp+0x20], xmm2
00007f7c123dac41  vmovaps [rsp+0x30], xmm3
00007f7c123dac47  vmovaps [rsp+0x40], xmm4
00007f7c123dac4d  vmovaps [rsp+0x50], xmm5
00007f7c123dac53  vmovaps [rsp+0x60], xmm6
00007f7c123dac59  vmovaps [rsp+0x70], xmm7
00007f7c123dac5f  vmovaps [rsp+0x80], xmm8
00007f7c123dac68  vmovaps [rsp+0x90], xmm9
00007f7c123dac71  vmovaps [rsp+0xA0], xmm10
00007f7c123dac7a  vmovaps [rsp+0xB0], xmm11
00007f7c123dac83  vmovaps [rsp+0xC0], xmm13
00007f7c123dac8c  vmovaps [rsp+0xD0], xmm14
00007f7c123dac95  vmovaps [rsp+0xE0], xmm15
00007f7c123dac9e  sub rsp, 0x30
00007f7c123daca2  movaps [rsp], xmm12
00007f7c123daca7  movaps [rsp+0x10], xmm14
00007f7c123dacad  movaps [rsp+0x20], xmm1
00007f7c123dacb2  lea rdi, [rsp]
00007f7c123dacb6  mov esi, 0x00
00007f7c123dacbb  mov rax, 0x5E723D793530
00007f7c123dacc5  call rax
00007f7c123dacc7  movaps xmm12, [rsp]
00007f7c123daccc  add rsp, 0x30
00007f7c123dacd0  vmovaps xmm0, [rsp]
00007f7c123dacd5  vmovaps xmm1, [rsp+0x10]
00007f7c123dacdb  vmovaps xmm2, [rsp+0x20]
00007f7c123dace1  vmovaps xmm3, [rsp+0x30]
00007f7c123dace7  vmovaps xmm4, [rsp+0x40]
00007f7c123daced  vmovaps xmm5, [rsp+0x50]
00007f7c123dacf3  vmovaps xmm6, [rsp+0x60]
00007f7c123dacf9  vmovaps xmm7, [rsp+0x70]
00007f7c123dacff  vmovaps xmm8, [rsp+0x80]
00007f7c123dad08  vmovaps xmm9, [rsp+0x90]
00007f7c123dad11  vmovaps xmm10, [rsp+0xA0]
00007f7c123dad1a  vmovaps xmm11, [rsp+0xB0]
00007f7c123dad23  vmovaps xmm13, [rsp+0xC0]
00007f7c123dad2c  vmovaps xmm14, [rsp+0xD0]
00007f7c123dad35  vmovaps xmm15, [rsp+0xE0]
00007f7c123dad3e  add rsp, 0xF0
00007f7c123dad45  pop r11
00007f7c123dad47  pop r10
00007f7c123dad49  pop r9
00007f7c123dad4b  pop r8
00007f7c123dad4d  pop rsi
00007f7c123dad4e  pop rdi
00007f7c123dad4f  pop rdx
00007f7c123dad50  pop rcx
00007f7c123dad51  pop rax
00007f7c123dad52  add rsp, 0x08
00007f7c123dad56  jmp 0x00007F7C123D6549
00007f7c123dad5b  sub rsp, 0x08
00007f7c123dad5f  push rax
00007f7c123dad60  push rcx
00007f7c123dad61  push rdx
00007f7c123dad62  push rdi
00007f7c123dad63  push rsi
00007f7c123dad64  push r8
00007f7c123dad66  push r9
00007f7c123dad68  push r10
00007f7c123dad6a  push r11
00007f7c123dad6c  sub rsp, 0xF0
00007f7c123dad73  vmovaps [rsp], xmm0
00007f7c123dad78  vmovaps [rsp+0x10], xmm1
00007f7c123dad7e  vmovaps [rsp+0x20], xmm2
00007f7c123dad84  vmovaps [rsp+0x30], xmm3
00007f7c123dad8a  vmovaps [rsp+0x40], xmm4
00007f7c123dad90  vmovaps [rsp+0x50], xmm5
00007f7c123dad96  vmovaps [rsp+0x60], xmm6
00007f7c123dad9c  vmovaps [rsp+0x70], xmm7
00007f7c123dada2  vmovaps [rsp+0x80], xmm8
00007f7c123dadab  vmovaps [rsp+0x90], xmm9
00007f7c123dadb4  vmovaps [rsp+0xA0], xmm10
00007f7c123dadbd  vmovaps [rsp+0xB0], xmm11
00007f7c123dadc6  vmovaps [rsp+0xC0], xmm12
00007f7c123dadcf  vmovaps [rsp+0xD0], xmm13
00007f7c123dadd8  vmovaps [rsp+0xE0], xmm15
00007f7c123dade1  sub rsp, 0x30
00007f7c123dade5  movaps [rsp], xmm14
00007f7c123dadea  movaps [rsp+0x10], xmm9
00007f7c123dadf0  movaps [rsp+0x20], xmm1
00007f7c123dadf5  lea rdi, [rsp]
00007f7c123dadf9  mov esi, 0x00
00007f7c123dadfe  mov rax, 0x5E723D793530
00007f7c123dae08  call rax
00007f7c123dae0a  movaps xmm14, [rsp]
00007f7c123dae0f  add rsp, 0x30
00007f7c123dae13  vmovaps xmm0, [rsp]
00007f7c123dae18  vmovaps xmm1, [rsp+0x10]
00007f7c123dae1e  vmovaps xmm2, [rsp+0x20]
00007f7c123dae24  vmovaps xmm3, [rsp+0x30]
00007f7c123dae2a  vmovaps xmm4, [rsp+0x40]
00007f7c123dae30  vmovaps xmm5, [rsp+0x50]
00007f7c123dae36  vmovaps xmm6, [rsp+0x60]
00007f7c123dae3c  vmovaps xmm7, [rsp+0x70]
00007f7c123dae42  vmovaps xmm8, [rsp+0x80]
00007f7c123dae4b  vmovaps xmm9, [rsp+0x90]
00007f7c123dae54  vmovaps xmm10, [rsp+0xA0]
00007f7c123dae5d  vmovaps xmm11, [rsp+0xB0]
00007f7c123dae66  vmovaps xmm12, [rsp+0xC0]
00007f7c123dae6f  vmovaps xmm13, [rsp+0xD0]
00007f7c123dae78  vmovaps xmm15, [rsp+0xE0]
00007f7c123dae81  add rsp, 0xF0
00007f7c123dae88  pop r11
00007f7c123dae8a  pop r10
00007f7c123dae8c  pop r9
00007f7c123dae8e  pop r8
00007f7c123dae90  pop rsi
00007f7c123dae91  pop rdi
00007f7c123dae92  pop rdx
00007f7c123dae93  pop rcx
00007f7c123dae94  pop rax
00007f7c123dae95  add rsp, 0x08
00007f7c123dae99  jmp 0x00007F7C123D6578
00007f7c123dae9e  sub rsp, 0x08
00007f7c123daea2  push rax
00007f7c123daea3  push rcx
00007f7c123daea4  push rdx
00007f7c123daea5  push rdi
00007f7c123daea6  push rsi
00007f7c123daea7  push r8
00007f7c123daea9  push r9
00007f7c123daeab  push r10
00007f7c123daead  push r11
00007f7c123daeaf  sub rsp, 0xF0
00007f7c123daeb6  vmovaps [rsp], xmm0
00007f7c123daebb  vmovaps [rsp+0x10], xmm2
00007f7c123daec1  vmovaps [rsp+0x20], xmm3
00007f7c123daec7  vmovaps [rsp+0x30], xmm4
00007f7c123daecd  vmovaps [rsp+0x40], xmm5
00007f7c123daed3  vmovaps [rsp+0x50], xmm6
00007f7c123daed9  vmovaps [rsp+0x60], xmm7
00007f7c123daedf  vmovaps [rsp+0x70], xmm8
00007f7c123daee5  vmovaps [rsp+0x80], xmm9
00007f7c123daeee  vmovaps [rsp+0x90], xmm10
00007f7c123daef7  vmovaps [rsp+0xA0], xmm11
00007f7c123daf00  vmovaps [rsp+0xB0], xmm12
00007f7c123daf09  vmovaps [rsp+0xC0], xmm13
00007f7c123daf12  vmovaps [rsp+0xD0], xmm14
00007f7c123daf1b  vmovaps [rsp+0xE0], xmm15
00007f7c123daf24  sub rsp, 0x30
00007f7c123daf28  movaps [rsp], xmm1
00007f7c123daf2c  movaps [rsp+0x10], xmm13
00007f7c123daf32  movaps [rsp+0x20], xmm8
00007f7c123daf38  lea rdi, [rsp]
00007f7c123daf3c  mov esi, 0x00
00007f7c123daf41  mov rax, 0x5E723D793530
00007f7c123daf4b  call rax
00007f7c123daf4d  movaps xmm1, [rsp]
00007f7c123daf51  add rsp, 0x30
00007f7c123daf55  vmovaps xmm0, [rsp]
00007f7c123daf5a  vmovaps xmm2, [rsp+0x10]
00007f7c123daf60  vmovaps xmm3, [rsp+0x20]
00007f7c123daf66  vmovaps xmm4, [rsp+0x30]
00007f7c123daf6c  vmovaps xmm5, [rsp+0x40]
00007f7c123daf72  vmovaps xmm6, [rsp+0x50]
00007f7c123daf78  vmovaps xmm7, [rsp+0x60]
00007f7c123daf7e  vmovaps xmm8, [rsp+0x70]
00007f7c123daf84  vmovaps xmm9, [rsp+0x80]
00007f7c123daf8d  vmovaps xmm10, [rsp+0x90]
00007f7c123daf96  vmovaps xmm11, [rsp+0xA0]
00007f7c123daf9f  vmovaps xmm12, [rsp+0xB0]
00007f7c123dafa8  vmovaps xmm13, [rsp+0xC0]
00007f7c123dafb1  vmovaps xmm14, [rsp+0xD0]
00007f7c123dafba  vmovaps xmm15, [rsp+0xE0]
00007f7c123dafc3  add rsp, 0xF0
00007f7c123dafca  pop r11
00007f7c123dafcc  pop r10
00007f7c123dafce  pop r9
00007f7c123dafd0  pop r8
00007f7c123dafd2  pop rsi
00007f7c123dafd3  pop rdi
00007f7c123dafd4  pop rdx
00007f7c123dafd5  pop rcx
00007f7c123dafd6  pop rax
00007f7c123dafd7  add rsp, 0x08
00007f7c123dafdb  jmp 0x00007F7C123D659A
00007f7c123dafe0  call 0x00007F7C1220C260
00007f7c123dafe5  jmp 0x00007F7C123D65A8
00007f7c123dafea  call 0x00007F7C122DE950
00007f7c123dafef  jmp 0x00007F7C123D65B2
00007f7c123daff4  sub rsp, 0x08
00007f7c123daff8  push rax
00007f7c123daff9  push rcx
00007f7c123daffa  push rdx
00007f7c123daffb  push rdi
00007f7c123daffc  push rsi
00007f7c123daffd  push r8
00007f7c123dafff  push r9
00007f7c123db001  push r10
00007f7c123db003  push r11
00007f7c123db005  sub rsp, 0xF0
00007f7c123db00c  vmovaps [rsp], xmm0
00007f7c123db011  vmovaps [rsp+0x10], xmm1
00007f7c123db017  vmovaps [rsp+0x20], xmm2
00007f7c123db01d  vmovaps [rsp+0x30], xmm3
00007f7c123db023  vmovaps [rsp+0x40], xmm4
00007f7c123db029  vmovaps [rsp+0x50], xmm5
00007f7c123db02f  vmovaps [rsp+0x60], xmm6
00007f7c123db035  vmovaps [rsp+0x70], xmm7
00007f7c123db03b  vmovaps [rsp+0x80], xmm9
00007f7c123db044  vmovaps [rsp+0x90], xmm10
00007f7c123db04d  vmovaps [rsp+0xA0], xmm11
00007f7c123db056  vmovaps [rsp+0xB0], xmm12
00007f7c123db05f  vmovaps [rsp+0xC0], xmm13
00007f7c123db068  vmovaps [rsp+0xD0], xmm14
00007f7c123db071  vmovaps [rsp+0xE0], xmm15
00007f7c123db07a  sub rsp, 0x30
00007f7c123db07e  movaps [rsp], xmm8
00007f7c123db083  movaps [rsp+0x10], xmm15
00007f7c123db089  movaps [rsp+0x20], xmm7
00007f7c123db08e  lea rdi, [rsp]
00007f7c123db092  mov esi, 0x00
00007f7c123db097  mov rax, 0x5E723D793530
00007f7c123db0a1  call rax
00007f7c123db0a3  movaps xmm8, [rsp]
00007f7c123db0a8  add rsp, 0x30
00007f7c123db0ac  vmovaps xmm0, [rsp]
00007f7c123db0b1  vmovaps xmm1, [rsp+0x10]
00007f7c123db0b7  vmovaps xmm2, [rsp+0x20]
00007f7c123db0bd  vmovaps xmm3, [rsp+0x30]
00007f7c123db0c3  vmovaps xmm4, [rsp+0x40]
00007f7c123db0c9  vmovaps xmm5, [rsp+0x50]
00007f7c123db0cf  vmovaps xmm6, [rsp+0x60]
00007f7c123db0d5  vmovaps xmm7, [rsp+0x70]
00007f7c123db0db  vmovaps xmm9, [rsp+0x80]
00007f7c123db0e4  vmovaps xmm10, [rsp+0x90]
00007f7c123db0ed  vmovaps xmm11, [rsp+0xA0]
00007f7c123db0f6  vmovaps xmm12, [rsp+0xB0]
00007f7c123db0ff  vmovaps xmm13, [rsp+0xC0]
00007f7c123db108  vmovaps xmm14, [rsp+0xD0]
00007f7c123db111  vmovaps xmm15, [rsp+0xE0]
00007f7c123db11a  add rsp, 0xF0
00007f7c123db121  pop r11
00007f7c123db123  pop r10
00007f7c123db125  pop r9
00007f7c123db127  pop r8
00007f7c123db129  pop rsi
00007f7c123db12a  pop rdi
00007f7c123db12b  pop rdx
00007f7c123db12c  pop rcx
00007f7c123db12d  pop rax
00007f7c123db12e  add rsp, 0x08
00007f7c123db132  jmp 0x00007F7C123D65D4
00007f7c123db137  sub rsp, 0x08
00007f7c123db13b  push rax
00007f7c123db13c  push rcx
00007f7c123db13d  push rdx
00007f7c123db13e  push rdi
00007f7c123db13f  push rsi
00007f7c123db140  push r8
00007f7c123db142  push r9
00007f7c123db144  push r10
00007f7c123db146  push r11
00007f7c123db148  sub rsp, 0xF0
00007f7c123db14f  vmovaps [rsp], xmm0
00007f7c123db154  vmovaps [rsp+0x10], xmm1
00007f7c123db15a  vmovaps [rsp+0x20], xmm2
00007f7c123db160  vmovaps [rsp+0x30], xmm3
00007f7c123db166  vmovaps [rsp+0x40], xmm4
00007f7c123db16c  vmovaps [rsp+0x50], xmm5
00007f7c123db172  vmovaps [rsp+0x60], xmm6
00007f7c123db178  vmovaps [rsp+0x70], xmm8
00007f7c123db17e  vmovaps [rsp+0x80], xmm9
00007f7c123db187  vmovaps [rsp+0x90], xmm10
00007f7c123db190  vmovaps [rsp+0xA0], xmm11
00007f7c123db199  vmovaps [rsp+0xB0], xmm12
00007f7c123db1a2  vmovaps [rsp+0xC0], xmm13
00007f7c123db1ab  vmovaps [rsp+0xD0], xmm14
00007f7c123db1b4  vmovaps [rsp+0xE0], xmm15
00007f7c123db1bd  sub rsp, 0x30
00007f7c123db1c1  movaps [rsp], xmm7
00007f7c123db1c5  movaps [rsp+0x10], xmm9
00007f7c123db1cb  movaps [rsp+0x20], xmm15
00007f7c123db1d1  lea rdi, [rsp]
00007f7c123db1d5  mov esi, 0x00
00007f7c123db1da  mov rax, 0x5E723D793530
00007f7c123db1e4  call rax
00007f7c123db1e6  movaps xmm7, [rsp]
00007f7c123db1ea  add rsp, 0x30
00007f7c123db1ee  vmovaps xmm0, [rsp]
00007f7c123db1f3  vmovaps xmm1, [rsp+0x10]
00007f7c123db1f9  vmovaps xmm2, [rsp+0x20]
00007f7c123db1ff  vmovaps xmm3, [rsp+0x30]
00007f7c123db205  vmovaps xmm4, [rsp+0x40]
00007f7c123db20b  vmovaps xmm5, [rsp+0x50]
00007f7c123db211  vmovaps xmm6, [rsp+0x60]
00007f7c123db217  vmovaps xmm8, [rsp+0x70]
00007f7c123db21d  vmovaps xmm9, [rsp+0x80]
00007f7c123db226  vmovaps xmm10, [rsp+0x90]
00007f7c123db22f  vmovaps xmm11, [rsp+0xA0]
00007f7c123db238  vmovaps xmm12, [rsp+0xB0]
00007f7c123db241  vmovaps xmm13, [rsp+0xC0]
00007f7c123db24a  vmovaps xmm14, [rsp+0xD0]
00007f7c123db253  vmovaps xmm15, [rsp+0xE0]
00007f7c123db25c  add rsp, 0xF0
00007f7c123db263  pop r11
00007f7c123db265  pop r10
00007f7c123db267  pop r9
00007f7c123db269  pop r8
00007f7c123db26b  pop rsi
00007f7c123db26c  pop rdi
00007f7c123db26d  pop rdx
00007f7c123db26e  pop rcx
00007f7c123db26f  pop rax
00007f7c123db270  add rsp, 0x08
00007f7c123db274  jmp 0x00007F7C123D6601
00007f7c123db279  sub rsp, 0x08
00007f7c123db27d  push rax
00007f7c123db27e  push rcx
00007f7c123db27f  push rdx
00007f7c123db280  push rdi
00007f7c123db281  push rsi
00007f7c123db282  push r8
00007f7c123db284  push r9
00007f7c123db286  push r10
00007f7c123db288  push r11
00007f7c123db28a  sub rsp, 0xF0
00007f7c123db291  vmovaps [rsp], xmm0
00007f7c123db296  vmovaps [rsp+0x10], xmm1
00007f7c123db29c  vmovaps [rsp+0x20], xmm2
00007f7c123db2a2  vmovaps [rsp+0x30], xmm3
00007f7c123db2a8  vmovaps [rsp+0x40], xmm4
00007f7c123db2ae  vmovaps [rsp+0x50], xmm5
00007f7c123db2b4  vmovaps [rsp+0x60], xmm6
00007f7c123db2ba  vmovaps [rsp+0x70], xmm7
00007f7c123db2c0  vmovaps [rsp+0x80], xmm8
00007f7c123db2c9  vmovaps [rsp+0x90], xmm10
00007f7c123db2d2  vmovaps [rsp+0xA0], xmm11
00007f7c123db2db  vmovaps [rsp+0xB0], xmm12
00007f7c123db2e4  vmovaps [rsp+0xC0], xmm13
00007f7c123db2ed  vmovaps [rsp+0xD0], xmm14
00007f7c123db2f6  vmovaps [rsp+0xE0], xmm15
00007f7c123db2ff  sub rsp, 0x30
00007f7c123db303  movaps [rsp], xmm9
00007f7c123db308  movaps [rsp+0x10], xmm13
00007f7c123db30e  movaps [rsp+0x20], xmm15
00007f7c123db314  lea rdi, [rsp]
00007f7c123db318  mov esi, 0x00
00007f7c123db31d  mov rax, 0x5E723D793530
00007f7c123db327  call rax
00007f7c123db329  movaps xmm9, [rsp]
00007f7c123db32e  add rsp, 0x30
00007f7c123db332  vmovaps xmm0, [rsp]
00007f7c123db337  vmovaps xmm1, [rsp+0x10]
00007f7c123db33d  vmovaps xmm2, [rsp+0x20]
00007f7c123db343  vmovaps xmm3, [rsp+0x30]
00007f7c123db349  vmovaps xmm4, [rsp+0x40]
00007f7c123db34f  vmovaps xmm5, [rsp+0x50]
00007f7c123db355  vmovaps xmm6, [rsp+0x60]
00007f7c123db35b  vmovaps xmm7, [rsp+0x70]
00007f7c123db361  vmovaps xmm8, [rsp+0x80]
00007f7c123db36a  vmovaps xmm10, [rsp+0x90]
00007f7c123db373  vmovaps xmm11, [rsp+0xA0]
00007f7c123db37c  vmovaps xmm12, [rsp+0xB0]
00007f7c123db385  vmovaps xmm13, [rsp+0xC0]
00007f7c123db38e  vmovaps xmm14, [rsp+0xD0]
00007f7c123db397  vmovaps xmm15, [rsp+0xE0]
00007f7c123db3a0  add rsp, 0xF0
00007f7c123db3a7  pop r11
00007f7c123db3a9  pop r10
00007f7c123db3ab  pop r9
00007f7c123db3ad  pop r8
00007f7c123db3af  pop rsi
00007f7c123db3b0  pop rdi
00007f7c123db3b1  pop rdx
00007f7c123db3b2  pop rcx
00007f7c123db3b3  pop rax
00007f7c123db3b4  add rsp, 0x08
00007f7c123db3b8  jmp 0x00007F7C123D662F
00007f7c123db3bd  sub rsp, 0x08
00007f7c123db3c1  push rax
00007f7c123db3c2  push rcx
00007f7c123db3c3  push rdx
00007f7c123db3c4  push rdi
00007f7c123db3c5  push rsi
00007f7c123db3c6  push r8
00007f7c123db3c8  push r9
00007f7c123db3ca  push r10
00007f7c123db3cc  push r11
00007f7c123db3ce  sub rsp, 0xF0
00007f7c123db3d5  vmovaps [rsp], xmm0
00007f7c123db3da  vmovaps [rsp+0x10], xmm1
00007f7c123db3e0  vmovaps [rsp+0x20], xmm2
00007f7c123db3e6  vmovaps [rsp+0x30], xmm3
00007f7c123db3ec  vmovaps [rsp+0x40], xmm4
00007f7c123db3f2  vmovaps [rsp+0x50], xmm5
00007f7c123db3f8  vmovaps [rsp+0x60], xmm6
00007f7c123db3fe  vmovaps [rsp+0x70], xmm7
00007f7c123db404  vmovaps [rsp+0x80], xmm8
00007f7c123db40d  vmovaps [rsp+0x90], xmm9
00007f7c123db416  vmovaps [rsp+0xA0], xmm10
00007f7c123db41f  vmovaps [rsp+0xB0], xmm11
00007f7c123db428  vmovaps [rsp+0xC0], xmm12
00007f7c123db431  vmovaps [rsp+0xD0], xmm13
00007f7c123db43a  vmovaps [rsp+0xE0], xmm14
00007f7c123db443  sub rsp, 0x30
00007f7c123db447  movaps [rsp], xmm15
00007f7c123db44c  movaps [rsp+0x10], xmm11
00007f7c123db452  movaps [rsp+0x20], xmm12
00007f7c123db458  lea rdi, [rsp]
00007f7c123db45c  mov esi, 0x00
00007f7c123db461  mov rax, 0x5E723D793530
00007f7c123db46b  call rax
00007f7c123db46d  movaps xmm15, [rsp]
00007f7c123db472  add rsp, 0x30
00007f7c123db476  vmovaps xmm0, [rsp]
00007f7c123db47b  vmovaps xmm1, [rsp+0x10]
00007f7c123db481  vmovaps xmm2, [rsp+0x20]
00007f7c123db487  vmovaps xmm3, [rsp+0x30]
00007f7c123db48d  vmovaps xmm4, [rsp+0x40]
00007f7c123db493  vmovaps xmm5, [rsp+0x50]
00007f7c123db499  vmovaps xmm6, [rsp+0x60]
00007f7c123db49f  vmovaps xmm7, [rsp+0x70]
00007f7c123db4a5  vmovaps xmm8, [rsp+0x80]
00007f7c123db4ae  vmovaps xmm9, [rsp+0x90]
00007f7c123db4b7  vmovaps xmm10, [rsp+0xA0]
00007f7c123db4c0  vmovaps xmm11, [rsp+0xB0]
00007f7c123db4c9  vmovaps xmm12, [rsp+0xC0]
00007f7c123db4d2  vmovaps xmm13, [rsp+0xD0]
00007f7c123db4db  vmovaps xmm14, [rsp+0xE0]
00007f7c123db4e4  add rsp, 0xF0
00007f7c123db4eb  pop r11
00007f7c123db4ed  pop r10
00007f7c123db4ef  pop r9
00007f7c123db4f1  pop r8
00007f7c123db4f3  pop rsi
00007f7c123db4f4  pop rdi
00007f7c123db4f5  pop rdx
00007f7c123db4f6  pop rcx
00007f7c123db4f7  pop rax
00007f7c123db4f8  add rsp, 0x08
00007f7c123db4fc  jmp 0x00007F7C123D664A
00007f7c123db501  sub rsp, 0x08
00007f7c123db505  push rax
00007f7c123db506  push rcx
00007f7c123db507  push rdx
00007f7c123db508  push rdi
00007f7c123db509  push rsi
00007f7c123db50a  push r8
00007f7c123db50c  push r9
00007f7c123db50e  push r10
00007f7c123db510  push r11
00007f7c123db512  sub rsp, 0xF0
00007f7c123db519  vmovaps [rsp], xmm0
00007f7c123db51e  vmovaps [rsp+0x10], xmm1
00007f7c123db524  vmovaps [rsp+0x20], xmm2
00007f7c123db52a  vmovaps [rsp+0x30], xmm3
00007f7c123db530  vmovaps [rsp+0x40], xmm4
00007f7c123db536  vmovaps [rsp+0x50], xmm5
00007f7c123db53c  vmovaps [rsp+0x60], xmm6
00007f7c123db542  vmovaps [rsp+0x70], xmm7
00007f7c123db548  vmovaps [rsp+0x80], xmm8
00007f7c123db551  vmovaps [rsp+0x90], xmm9
00007f7c123db55a  vmovaps [rsp+0xA0], xmm10
00007f7c123db563  vmovaps [rsp+0xB0], xmm11
00007f7c123db56c  vmovaps [rsp+0xC0], xmm12
00007f7c123db575  vmovaps [rsp+0xD0], xmm14
00007f7c123db57e  vmovaps [rsp+0xE0], xmm15
00007f7c123db587  sub rsp, 0x30
00007f7c123db58b  movaps [rsp], xmm13
00007f7c123db590  movaps [rsp+0x10], xmm10
00007f7c123db596  movaps [rsp+0x20], xmm14
00007f7c123db59c  lea rdi, [rsp]
00007f7c123db5a0  mov esi, 0x00
00007f7c123db5a5  mov rax, 0x5E723D793530
00007f7c123db5af  call rax
00007f7c123db5b1  movaps xmm13, [rsp]
00007f7c123db5b6  add rsp, 0x30
00007f7c123db5ba  vmovaps xmm0, [rsp]
00007f7c123db5bf  vmovaps xmm1, [rsp+0x10]
00007f7c123db5c5  vmovaps xmm2, [rsp+0x20]
00007f7c123db5cb  vmovaps xmm3, [rsp+0x30]
00007f7c123db5d1  vmovaps xmm4, [rsp+0x40]
00007f7c123db5d7  vmovaps xmm5, [rsp+0x50]
00007f7c123db5dd  vmovaps xmm6, [rsp+0x60]
00007f7c123db5e3  vmovaps xmm7, [rsp+0x70]
00007f7c123db5e9  vmovaps xmm8, [rsp+0x80]
00007f7c123db5f2  vmovaps xmm9, [rsp+0x90]
00007f7c123db5fb  vmovaps xmm10, [rsp+0xA0]
00007f7c123db604  vmovaps xmm11, [rsp+0xB0]
00007f7c123db60d  vmovaps xmm12, [rsp+0xC0]
00007f7c123db616  vmovaps xmm14, [rsp+0xD0]
00007f7c123db61f  vmovaps xmm15, [rsp+0xE0]
00007f7c123db628  add rsp, 0xF0
00007f7c123db62f  pop r11
00007f7c123db631  pop r10
00007f7c123db633  pop r9
00007f7c123db635  pop r8
00007f7c123db637  pop rsi
00007f7c123db638  pop rdi
00007f7c123db639  pop rdx
00007f7c123db63a  pop rcx
00007f7c123db63b  pop rax
00007f7c123db63c  add rsp, 0x08
00007f7c123db640  jmp 0x00007F7C123D666D
00007f7c123db645  sub rsp, 0x08
00007f7c123db649  push rax
00007f7c123db64a  push rcx
00007f7c123db64b  push rdx
00007f7c123db64c  push rdi
00007f7c123db64d  push rsi
00007f7c123db64e  push r8
00007f7c123db650  push r9
00007f7c123db652  push r10
00007f7c123db654  push r11
00007f7c123db656  sub rsp, 0xF0
00007f7c123db65d  vmovaps [rsp], xmm0
00007f7c123db662  vmovaps [rsp+0x10], xmm1
00007f7c123db668  vmovaps [rsp+0x20], xmm2
00007f7c123db66e  vmovaps [rsp+0x30], xmm3
00007f7c123db674  vmovaps [rsp+0x40], xmm4
00007f7c123db67a  vmovaps [rsp+0x50], xmm5
00007f7c123db680  vmovaps [rsp+0x60], xmm6
00007f7c123db686  vmovaps [rsp+0x70], xmm7
00007f7c123db68c  vmovaps [rsp+0x80], xmm8
00007f7c123db695  vmovaps [rsp+0x90], xmm9
00007f7c123db69e  vmovaps [rsp+0xA0], xmm10
00007f7c123db6a7  vmovaps [rsp+0xB0], xmm11
00007f7c123db6b0  vmovaps [rsp+0xC0], xmm12
00007f7c123db6b9  vmovaps [rsp+0xD0], xmm13
00007f7c123db6c2  vmovaps [rsp+0xE0], xmm15
00007f7c123db6cb  sub rsp, 0x30
00007f7c123db6cf  movaps [rsp], xmm14
00007f7c123db6d4  movaps [rsp+0x10], xmm1
00007f7c123db6d9  movaps [rsp+0x20], xmm7
00007f7c123db6de  lea rdi, [rsp]
00007f7c123db6e2  mov esi, 0x00
00007f7c123db6e7  mov rax, 0x5E723D793530
00007f7c123db6f1  call rax
00007f7c123db6f3  movaps xmm14, [rsp]
00007f7c123db6f8  add rsp, 0x30
00007f7c123db6fc  vmovaps xmm0, [rsp]
00007f7c123db701  vmovaps xmm1, [rsp+0x10]
00007f7c123db707  vmovaps xmm2, [rsp+0x20]
00007f7c123db70d  vmovaps xmm3, [rsp+0x30]
00007f7c123db713  vmovaps xmm4, [rsp+0x40]
00007f7c123db719  vmovaps xmm5, [rsp+0x50]
00007f7c123db71f  vmovaps xmm6, [rsp+0x60]
00007f7c123db725  vmovaps xmm7, [rsp+0x70]
00007f7c123db72b  vmovaps xmm8, [rsp+0x80]
00007f7c123db734  vmovaps xmm9, [rsp+0x90]
00007f7c123db73d  vmovaps xmm10, [rsp+0xA0]
00007f7c123db746  vmovaps xmm11, [rsp+0xB0]
00007f7c123db74f  vmovaps xmm12, [rsp+0xC0]
00007f7c123db758  vmovaps xmm13, [rsp+0xD0]
00007f7c123db761  vmovaps xmm15, [rsp+0xE0]
00007f7c123db76a  add rsp, 0xF0
00007f7c123db771  pop r11
00007f7c123db773  pop r10
00007f7c123db775  pop r9
00007f7c123db777  pop r8
00007f7c123db779  pop rsi
00007f7c123db77a  pop rdi
00007f7c123db77b  pop rdx
00007f7c123db77c  pop rcx
00007f7c123db77d  pop rax
00007f7c123db77e  add rsp, 0x08
00007f7c123db782  jmp 0x00007F7C123D6690
00007f7c123db787  sub rsp, 0x08
00007f7c123db78b  push rax
00007f7c123db78c  push rcx
00007f7c123db78d  push rdx
00007f7c123db78e  push rdi
00007f7c123db78f  push rsi
00007f7c123db790  push r8
00007f7c123db792  push r9
00007f7c123db794  push r10
00007f7c123db796  push r11
00007f7c123db798  sub rsp, 0xF0
00007f7c123db79f  vmovaps [rsp], xmm0
00007f7c123db7a4  vmovaps [rsp+0x10], xmm2
00007f7c123db7aa  vmovaps [rsp+0x20], xmm3
00007f7c123db7b0  vmovaps [rsp+0x30], xmm4
00007f7c123db7b6  vmovaps [rsp+0x40], xmm5
00007f7c123db7bc  vmovaps [rsp+0x50], xmm6
00007f7c123db7c2  vmovaps [rsp+0x60], xmm7
00007f7c123db7c8  vmovaps [rsp+0x70], xmm8
00007f7c123db7ce  vmovaps [rsp+0x80], xmm9
00007f7c123db7d7  vmovaps [rsp+0x90], xmm10
00007f7c123db7e0  vmovaps [rsp+0xA0], xmm11
00007f7c123db7e9  vmovaps [rsp+0xB0], xmm12
00007f7c123db7f2  vmovaps [rsp+0xC0], xmm13
00007f7c123db7fb  vmovaps [rsp+0xD0], xmm14
00007f7c123db804  vmovaps [rsp+0xE0], xmm15
00007f7c123db80d  sub rsp, 0x30
00007f7c123db811  movaps [rsp], xmm1
00007f7c123db815  movaps [rsp+0x10], xmm8
00007f7c123db81b  movaps [rsp+0x20], xmm9
00007f7c123db821  lea rdi, [rsp]
00007f7c123db825  mov esi, 0x00
00007f7c123db82a  mov rax, 0x5E723D793530
00007f7c123db834  call rax
00007f7c123db836  movaps xmm1, [rsp]
00007f7c123db83a  add rsp, 0x30
00007f7c123db83e  vmovaps xmm0, [rsp]
00007f7c123db843  vmovaps xmm2, [rsp+0x10]
00007f7c123db849  vmovaps xmm3, [rsp+0x20]
00007f7c123db84f  vmovaps xmm4, [rsp+0x30]
00007f7c123db855  vmovaps xmm5, [rsp+0x40]
00007f7c123db85b  vmovaps xmm6, [rsp+0x50]
00007f7c123db861  vmovaps xmm7, [rsp+0x60]
00007f7c123db867  vmovaps xmm8, [rsp+0x70]
00007f7c123db86d  vmovaps xmm9, [rsp+0x80]
00007f7c123db876  vmovaps xmm10, [rsp+0x90]
00007f7c123db87f  vmovaps xmm11, [rsp+0xA0]
00007f7c123db888  vmovaps xmm12, [rsp+0xB0]
00007f7c123db891  vmovaps xmm13, [rsp+0xC0]
00007f7c123db89a  vmovaps xmm14, [rsp+0xD0]
00007f7c123db8a3  vmovaps xmm15, [rsp+0xE0]
00007f7c123db8ac  add rsp, 0xF0
00007f7c123db8b3  pop r11
00007f7c123db8b5  pop r10
00007f7c123db8b7  pop r9
00007f7c123db8b9  pop r8
00007f7c123db8bb  pop rsi
00007f7c123db8bc  pop rdi
00007f7c123db8bd  pop rdx
00007f7c123db8be  pop rcx
00007f7c123db8bf  pop rax
00007f7c123db8c0  add rsp, 0x08
00007f7c123db8c4  jmp 0x00007F7C123D66B2
00007f7c123db8c9  call 0x00007F7C122B3E40
00007f7c123db8ce  jmp 0x00007F7C123D66C0
00007f7c123db8d3  call 0x00007F7C1220C380
00007f7c123db8d8  jmp 0x00007F7C123D66CA
00007f7c123db8dd  call 0x00007F7C1220D600
00007f7c123db8e2  jmp 0x00007F7C123D66D4
00007f7c123db8e7  call 0x00007F7C121FF540
00007f7c123db8ec  jmp 0x00007F7C123D66DE
00007f7c123db8f1  int3
00007f7c123db8f2  nop [rax+rax*1], ax
00007f7c123db8fb  nop [rax+rax*1], eax
00007f7c123db900  mov eax, [r15+0x48]
00007f7c123db904  lea r14d, [eax+0x01]
00007f7c123db909  mov [rsp+0x10], r14d
00007f7c123db90e  mov r14d, r14d
00007f7c123db911  mov [r15+0x48], r14
00007f7c123db915  xor eax, eax
00007f7c123db917  mov r14d, [rsp+0x10]
00007f7c123db91c  cmp r14d, 0x1F4
00007f7c123db923  cmc
00007f7c123db924  lahf
00007f7c123db925  seto al
00007f7c123db928  mov [r15+0x108], eax
00007f7c123db92f  mov eax, [r15+0x108]
00007f7c123db936  sahf
00007f7c123db937  jnz 0x00007F7C123DB969
00007f7c123db939  cmp dword ptr [r15+0x318], 0x00
00007f7c123db941  jz 0x00007F7C123E1AB0
00007f7c123db947  nop [rax+rax*1], ax
00007f7c123db950  nop [rax+rax*1], eax
00007f7c123db958  mov eax, 0x410450
00007f7c123db95d  mov [r15+0x100], rax
00007f7c123db964  jmp 0x00007F7C121FE110
00007f7c123db969  cmp dword ptr [r15+0x318], 0x00
00007f7c123db971  jz 0x00007F7C123DB9A0
00007f7c123db977  nop [rax+rax*1], ax
00007f7c123db980  nop [rax+rax*1], eax
00007f7c123db988  mov eax, 0x410274
00007f7c123db98d  mov [r15+0x100], rax
00007f7c123db994  jmp 0x00007F7C121FE110
00007f7c123db999  int3
00007f7c123db99a  int3
00007f7c123db99b  nop [rax+rax*1], eax
00007f7c123db9a0  mov rax, [r15+0x40]
00007f7c123db9a4  movaps xmm1, [r15+0x1D0]
00007f7c123db9ac  vmovaps [rsp+0x10], xmm1
00007f7c123db9b2  vmovaps xmm15, [rsp+0x10]
00007f7c123db9b8  por xmm1, xmm15
00007f7c123db9bd  movaps xmm14, [r15+0x1A0]
00007f7c123db9c5  vmovaps [rsp+0x10], xmm14
00007f7c123db9cb  vmovaps xmm13, [rsp+0x10]
00007f7c123db9d1  por xmm14, xmm13
00007f7c123db9d6  lea r14, [rax+0x30]
00007f7c123db9da  mov r12, [r13+r14*1]
00007f7c123db9df  lea r14, [rax+0x38]
00007f7c123db9e3  mov r11, [r13+r14*1]
00007f7c123db9e8  movq xmm13, r12
00007f7c123db9ed  movq xmm12, r11
00007f7c123db9f2  movq xmm13, xmm13
00007f7c123db9f7  vmovaps [rsp+0x10], xmm13
00007f7c123db9fd  movq xmm13, xmm13
00007f7c123dba02  movaps [r15+0x130], xmm13
00007f7c123dba0a  movq xmm12, xmm12
00007f7c123dba0f  vmovaps [rsp+0x20], xmm12
00007f7c123dba15  movq xmm12, xmm12
00007f7c123dba1a  movaps [r15+0x280], xmm12
00007f7c123dba22  movaps xmm13, [r15+0x270]
00007f7c123dba2a  vmovaps [rsp+0x30], xmm13
00007f7c123dba30  vmovaps xmm12, [rsp+0x30]
00007f7c123dba36  por xmm13, xmm12
00007f7c123dba3b  lea r14, [rax+0x20]
00007f7c123dba3f  mov r12, [r13+r14*1]
00007f7c123dba44  lea r14, [rax+0x28]
00007f7c123dba48  mov r11, [r13+r14*1]
00007f7c123dba4d  movq xmm12, r12
00007f7c123dba52  movq xmm11, r11
00007f7c123dba57  movq xmm12, xmm12
00007f7c123dba5c  vmovaps [rsp+0x30], xmm12
00007f7c123dba62  movq xmm12, xmm12
00007f7c123dba67  movaps [r15+0x150], xmm12
00007f7c123dba6f  movq xmm11, xmm11
00007f7c123dba74  vmovaps [rsp+0x40], xmm11
00007f7c123dba7a  movq xmm11, xmm11
00007f7c123dba7f  movaps [r15+0x140], xmm11
00007f7c123dba87  lea r14, [rax+0x10]
00007f7c123dba8b  mov r12, [r13+r14*1]
00007f7c123dba90  lea r14, [rax+0x18]
00007f7c123dba94  mov r11, [r13+r14*1]
00007f7c123dba99  movq xmm12, r12
00007f7c123dba9e  movq xmm11, r11
00007f7c123dbaa3  movq xmm12, xmm12
00007f7c123dbaa8  vmovaps [rsp+0x50], xmm12
00007f7c123dbaae  movq xmm12, xmm12
00007f7c123dbab3  movaps [r15+0x170], xmm12
00007f7c123dbabb  movq xmm11, xmm11
00007f7c123dbac0  vmovaps [rsp+0x60], xmm11
00007f7c123dbac6  movq xmm11, xmm11
00007f7c123dbacb  movaps [r15+0x160], xmm11
00007f7c123dbad3  mov r14, [r13+rax*1]
00007f7c123dbad8  vmovq xmm12, r14
00007f7c123dbadd  vpbroadcastq xmm12, xmm12
00007f7c123dbae2  lea r14, [rax+0x08]
00007f7c123dbae6  mov rax, [r13+r14*1]
00007f7c123dbaeb  movq xmm11, rax
00007f7c123dbaf0  movaps [r15+0x230], xmm11
00007f7c123dbaf8  mov rax, [r15+0xF8]
00007f7c123dbaff  lea r14, [rax+0x50]
00007f7c123dbb03  movups xmm11, [r13+r14*1]
00007f7c123dbb09  lea r14, [rax+0x60]
00007f7c123dbb0d  movups xmm10, [r13+r14*1]
00007f7c123dbb13  lea r14, [rax+0x30]
00007f7c123dbb17  movups xmm9, [r13+r14*1]
00007f7c123dbb1d  mov r14, [r15+0x50]
00007f7c123dbb21  mov [r15+0x60], r14
00007f7c123dbb25  mov qword ptr [r15+0x58], 0x40
00007f7c123dbb2d  movaps xmm8, xmm12
00007f7c123dbb31  mulpd xmm8, xmm15
00007f7c123dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007f7c123dbb3c  ptest xmm7, xmm7
00007f7c123dbb41  jnz 0x00007F7C123DC96A
00007f7c123dbb47  movq xmm15, qword ptr [r15+0x230]
00007f7c123dbb50  vmovaps [rsp+0x70], xmm15
00007f7c123dbb56  vpermilpd xmm15, xmm15, 0x00
00007f7c123dbb5c  movaps xmm7, xmm9
00007f7c123dbb60  mulpd xmm7, xmm15
00007f7c123dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007f7c123dbb6a  ptest xmm6, xmm6
00007f7c123dbb6f  jnz 0x00007F7C123DCAAE
00007f7c123dbb75  vxorps xmm15, xmm15, xmm15
00007f7c123dbb7a  vpbroadcastq xmm15, xmm15
00007f7c123dbb7f  movaps xmm9, xmm12
00007f7c123dbb83  mulpd xmm9, xmm10
00007f7c123dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007f7c123dbb8e  ptest xmm6, xmm6
00007f7c123dbb93  jnz 0x00007F7C123DCBF0
00007f7c123dbb99  movaps xmm10, xmm12
00007f7c123dbb9d  mulpd xmm10, xmm11
00007f7c123dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007f7c123dbba8  ptest xmm6, xmm6
00007f7c123dbbad  jnz 0x00007F7C123DCD34
00007f7c123dbbb3  movaps xmm11, [r15+0x1F0]
00007f7c123dbbbb  movaps xmm6, xmm12
00007f7c123dbbbf  mulpd xmm6, xmm11
00007f7c123dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007f7c123dbbc9  ptest xmm5, xmm5
00007f7c123dbbce  jnz 0x00007F7C123DCE78
00007f7c123dbbd4  movaps xmm12, [r15+0x2A0]
00007f7c123dbbdc  vmovaps [rsp+0x80], xmm12
00007f7c123dbbe5  vmovaps xmm11, [rsp+0x80]
00007f7c123dbbee  por xmm12, xmm11
00007f7c123dbbf3  movaps xmm11, [r15+0x250]
00007f7c123dbbfb  vmovaps [rsp+0x80], xmm11
00007f7c123dbc04  vmovaps xmm5, [rsp+0x80]
00007f7c123dbc0d  por xmm11, xmm5
00007f7c123dbc12  vmovaps xmm4, [rsp+0x70]
00007f7c123dbc18  vpermilpd xmm4, xmm4, 0x00
00007f7c123dbc1e  movaps xmm3, xmm5
00007f7c123dbc21  mulpd xmm3, xmm4
00007f7c123dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007f7c123dbc2a  ptest xmm2, xmm2
00007f7c123dbc2f  jnz 0x00007F7C123DCFBA
00007f7c123dbc35  mov [rsp+0x80], rax
00007f7c123dbc3d  xor eax, eax
00007f7c123dbc3f  mov r12d, 0x40
00007f7c123dbc45  mov r11d, 0x200
00007f7c123dbc4b  cmp r12, r11
00007f7c123dbc4e  cmc
00007f7c123dbc4f  lahf
00007f7c123dbc50  seto al
00007f7c123dbc53  mov [r15+0x108], eax
00007f7c123dbc5a  movaps xmm5, xmm8
00007f7c123dbc5e  addpd xmm5, xmm15
00007f7c123dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007f7c123dbc68  ptest xmm4, xmm4
00007f7c123dbc6d  jnz 0x00007F7C123DD0FA
00007f7c123dbc73  movaps xmm8, [r15+0x1B0]
00007f7c123dbc7b  movaps xmm4, xmm9
00007f7c123dbc7f  addpd xmm4, xmm8
00007f7c123dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007f7c123dbc89  ptest xmm2, xmm2
00007f7c123dbc8e  jnz 0x00007F7C123DD23C
00007f7c123dbc94  movaps xmm9, xmm10
00007f7c123dbc98  addpd xmm9, xmm8
00007f7c123dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007f7c123dbca3  ptest xmm2, xmm2
00007f7c123dbca8  jnz 0x00007F7C123DD37E
00007f7c123dbcae  movaps xmm10, [r15+0x2F0]
00007f7c123dbcb6  vmovaps [rsp+0x90], xmm10
00007f7c123dbcbf  vmovaps xmm8, [rsp+0x90]
00007f7c123dbcc8  por xmm10, xmm8
00007f7c123dbccd  movaps xmm8, [r15+0x2E0]
00007f7c123dbcd5  vmovaps [rsp+0x90], xmm8
00007f7c123dbcde  vmovaps xmm2, [rsp+0x90]
00007f7c123dbce7  por xmm8, xmm2
00007f7c123dbcec  movaps xmm2, [r15+0x2D0]
00007f7c123dbcf4  vmovaps [rsp+0x90], xmm2
00007f7c123dbcfd  vmovaps [rsp+0xA0], xmm1
00007f7c123dbd06  vmovaps xmm1, [rsp+0x90]
00007f7c123dbd0f  por xmm2, xmm1
00007f7c123dbd13  movaps xmm1, [r15+0x200]
00007f7c123dbd1b  vmovaps [rsp+0x90], xmm1
00007f7c123dbd24  vmovaps [rsp+0xB0], xmm15
00007f7c123dbd2d  vmovaps xmm15, [rsp+0x90]
00007f7c123dbd36  por xmm1, xmm15
00007f7c123dbd3b  movaps xmm15, [r15+0x1C0]
00007f7c123dbd43  vmovaps [rsp+0x90], xmm15
00007f7c123dbd4c  vmovaps [rsp+0xC0], xmm1
00007f7c123dbd55  vmovaps xmm1, [rsp+0x90]
00007f7c123dbd5e  por xmm15, xmm1
00007f7c123dbd63  movaps xmm1, [r15+0x190]
00007f7c123dbd6b  vmovaps [rsp+0x90], xmm1
00007f7c123dbd74  vmovaps [rsp+0xD0], xmm15
00007f7c123dbd7d  vmovaps xmm15, [rsp+0x90]
00007f7c123dbd86  por xmm1, xmm15
00007f7c123dbd8b  movaps xmm15, [r15+0x300]
00007f7c123dbd93  vmovaps [rsp+0x90], xmm15
00007f7c123dbd9c  vmovaps [rsp+0xE0], xmm1
00007f7c123dbda5  vmovaps xmm1, [rsp+0x90]
00007f7c123dbdae  por xmm15, xmm1
00007f7c123dbdb3  mov rax, [rsp+0x80]
00007f7c123dbdbb  lea r12, [rax+0xA0]
00007f7c123dbdc2  movups xmm1, [r13+r12*1]
00007f7c123dbdc8  lea r12, [rax+0xB0]
00007f7c123dbdcf  vmovaps [rsp+0x80], xmm1
00007f7c123dbdd8  movups xmm1, [r13+r12*1]
00007f7c123dbdde  vmovaps [rsp+0x90], xmm1
00007f7c123dbde7  vmovaps [rsp+0xF0], xmm15
00007f7c123dbdf0  vmovaps xmm15, [rsp+0xB0]
00007f7c123dbdf9  vmovaps [rsp+0xB0], xmm14
00007f7c123dbe02  movaps xmm1, xmm6
00007f7c123dbe05  addpd xmm1, xmm15
00007f7c123dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007f7c123dbe0f  ptest xmm14, xmm14
00007f7c123dbe15  jnz 0x00007F7C123DD4D6
00007f7c123dbe1b  lea r12, [rax+0xF0]
00007f7c123dbe22  movups xmm15, [r13+r12*1]
00007f7c123dbe28  movaps xmm14, xmm4
00007f7c123dbe2c  addpd xmm14, xmm3
00007f7c123dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007f7c123dbe37  ptest xmm6, xmm6
00007f7c123dbe3c  jnz 0x00007F7C123DD621
00007f7c123dbe42  movaps xmm6, xmm9
00007f7c123dbe46  addpd xmm6, xmm7
00007f7c123dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007f7c123dbe4f  ptest xmm4, xmm4
00007f7c123dbe54  jnz 0x00007F7C123DD763
00007f7c123dbe5a  vmovaps xmm9, [rsp+0x70]
00007f7c123dbe60  vpermilpd xmm9, xmm9, 0x00
00007f7c123dbe66  vmovaps xmm4, [rsp+0x90]
00007f7c123dbe6f  movaps xmm7, xmm4
00007f7c123dbe72  mulpd xmm7, xmm9
00007f7c123dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007f7c123dbe7c  ptest xmm3, xmm3
00007f7c123dbe81  jnz 0x00007F7C123DD8A4
00007f7c123dbe87  vmovaps xmm9, [rsp+0x50]
00007f7c123dbe8d  vpermilpd xmm9, xmm9, 0x00
00007f7c123dbe93  movaps xmm4, xmm15
00007f7c123dbe97  mulpd xmm4, xmm9
00007f7c123dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007f7c123dbea1  ptest xmm3, xmm3
00007f7c123dbea6  jnz 0x00007F7C123DD9E5
00007f7c123dbeac  lea r12, [rax+0xE0]
00007f7c123dbeb3  movups xmm15, [r13+r12*1]
00007f7c123dbeb9  vmovaps xmm9, [rsp+0x70]
00007f7c123dbebf  vpermilpd xmm9, xmm9, 0x00
00007f7c123dbec5  vmovaps [rsp+0x70], xmm1
00007f7c123dbecb  vmovaps xmm1, [rsp+0x80]
00007f7c123dbed4  vmovaps [rsp+0x80], xmm15
00007f7c123dbedd  movaps xmm3, xmm1
00007f7c123dbee0  mulpd xmm3, xmm9
00007f7c123dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007f7c123dbeea  ptest xmm15, xmm15
00007f7c123dbef0  jnz 0x00007F7C123DDB31
00007f7c123dbef6  vmovaps xmm1, [rsp+0xF0]
00007f7c123dbeff  vmovaps xmm15, [rsp+0xF0]
00007f7c123dbf08  por xmm1, xmm15
00007f7c123dbf0d  movaps [r15+0x300], xmm1
00007f7c123dbf15  vmovaps xmm15, [rsp+0xE0]
00007f7c123dbf1e  vmovaps xmm9, [rsp+0xE0]
00007f7c123dbf27  por xmm15, xmm9
00007f7c123dbf2c  movaps [r15+0x190], xmm15
00007f7c123dbf34  vmovaps xmm9, [rsp+0x50]
00007f7c123dbf3a  vpermilpd xmm9, xmm9, 0x00
00007f7c123dbf40  vmovaps [rsp+0x90], xmm1
00007f7c123dbf49  vmovaps [rsp+0xE0], xmm15
00007f7c123dbf52  vmovaps xmm15, [rsp+0x80]
00007f7c123dbf5b  vmovaps [rsp+0x80], xmm14
00007f7c123dbf64  movaps xmm1, xmm15
00007f7c123dbf68  mulpd xmm1, xmm9
00007f7c123dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007f7c123dbf72  ptest xmm14, xmm14
00007f7c123dbf78  jnz 0x00007F7C123DDC72
00007f7c123dbf7e  lea r12, [rax+0x90]
00007f7c123dbf85  movups xmm15, [r13+r12*1]
00007f7c123dbf8b  vmovaps xmm14, [rsp+0xD0]
00007f7c123dbf94  vmovaps xmm9, [rsp+0xD0]
00007f7c123dbf9d  por xmm14, xmm9
00007f7c123dbfa2  movaps [r15+0x1C0], xmm14
00007f7c123dbfaa  vmovaps xmm9, [rsp+0xC0]
00007f7c123dbfb3  vmovaps [rsp+0xD0], xmm1
00007f7c123dbfbc  vmovaps xmm1, [rsp+0xC0]
00007f7c123dbfc5  por xmm9, xmm1
00007f7c123dbfca  movaps [r15+0x200], xmm9
00007f7c123dbfd2  vmovaps [rsp+0xC0], xmm2
00007f7c123dbfdb  vmovaps xmm1, [rsp+0xC0]
00007f7c123dbfe4  por xmm2, xmm1
00007f7c123dbfe8  movaps [r15+0x2D0], xmm2
00007f7c123dbff0  vmovaps [rsp+0xC0], xmm8
00007f7c123dbff9  vmovaps xmm1, [rsp+0xC0]
00007f7c123dc002  por xmm8, xmm1
00007f7c123dc007  movaps [r15+0x2E0], xmm8
00007f7c123dc00f  vmovaps [rsp+0xC0], xmm15
00007f7c123dc018  movaps xmm1, xmm5
00007f7c123dc01b  addpd xmm1, xmm7
00007f7c123dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007f7c123dc024  ptest xmm15, xmm15
00007f7c123dc02a  jnz 0x00007F7C123DDDBE
00007f7c123dc030  vmovaps xmm15, [rsp+0x50]
00007f7c123dc036  vpermilpd xmm15, xmm15, 0x00
00007f7c123dc03c  vmovaps xmm5, [rsp+0xC0]
00007f7c123dc045  vmovaps [rsp+0xC0], xmm1
00007f7c123dc04e  movaps xmm7, xmm5
00007f7c123dc051  mulpd xmm7, xmm15
00007f7c123dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007f7c123dc05b  ptest xmm1, xmm1
00007f7c123dc060  jnz 0x00007F7C123DDEFE
00007f7c123dc066  lea r12, [rax+0x80]
00007f7c123dc06d  movups xmm1, [r13+r12*1]
00007f7c123dc073  vmovaps xmm5, [rsp+0x70]
00007f7c123dc079  vmovaps [rsp+0x70], xmm1
00007f7c123dc07f  movaps xmm15, xmm5
00007f7c123dc083  addpd xmm15, xmm3
00007f7c123dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007f7c123dc08e  ptest xmm1, xmm1
00007f7c123dc093  jnz 0x00007F7C123DE049
00007f7c123dc099  vmovaps xmm5, [rsp+0x80]
00007f7c123dc0a2  movaps xmm1, xmm5
00007f7c123dc0a5  addpd xmm1, xmm4
00007f7c123dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007f7c123dc0ae  ptest xmm3, xmm3
00007f7c123dc0b3  jnz 0x00007F7C123DE18B
00007f7c123dc0b9  vmovaps [rsp+0x80], xmm10
00007f7c123dc0c2  vmovaps xmm5, [rsp+0x80]
00007f7c123dc0cb  por xmm10, xmm5
00007f7c123dc0d0  movaps [r15+0x2F0], xmm10
00007f7c123dc0d8  vmovaps xmm5, [rsp+0x50]
00007f7c123dc0de  vpermilpd xmm5, xmm5, 0x00
00007f7c123dc0e4  vmovaps xmm3, [rsp+0x70]
00007f7c123dc0ea  vmovaps [rsp+0x50], xmm1
00007f7c123dc0f0  movaps xmm4, xmm3
00007f7c123dc0f3  mulpd xmm4, xmm5
00007f7c123dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007f7c123dc0fc  ptest xmm1, xmm1
00007f7c123dc101  jnz 0x00007F7C123DE2CB
00007f7c123dc107  lea r12, [rax+0xD0]
00007f7c123dc10e  movups xmm1, [r13+r12*1]
00007f7c123dc114  vmovaps xmm3, [rsp+0xD0]
00007f7c123dc11d  vmovaps [rsp+0x70], xmm1
00007f7c123dc123  movaps xmm5, xmm6
00007f7c123dc126  addpd xmm5, xmm3
00007f7c123dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007f7c123dc12f  ptest xmm1, xmm1
00007f7c123dc134  jnz 0x00007F7C123DE415
00007f7c123dc13a  vmovaps xmm1, [rsp+0x60]
00007f7c123dc140  vpermilpd xmm1, xmm1, 0x00
00007f7c123dc146  movaps xmm6, xmm9
00007f7c123dc14a  mulpd xmm6, xmm1
00007f7c123dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007f7c123dc153  ptest xmm3, xmm3
00007f7c123dc158  jnz 0x00007F7C123DE555
00007f7c123dc15e  movaps [r15+0x260], xmm6
00007f7c123dc166  vxorps xmm1, xmm1, xmm1
00007f7c123dc16a  vpbroadcastq xmm1, xmm1
00007f7c123dc16f  movaps [r15+0x1B0], xmm1
00007f7c123dc177  vmovaps xmm1, [rsp+0x60]
00007f7c123dc17d  vpermilpd xmm1, xmm1, 0x00
00007f7c123dc183  vmovaps xmm3, [rsp+0x70]
00007f7c123dc189  vmovaps [rsp+0x70], xmm15
00007f7c123dc18f  movaps xmm9, xmm3
00007f7c123dc193  mulpd xmm9, xmm1
00007f7c123dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007f7c123dc19e  ptest xmm15, xmm15
00007f7c123dc1a4  jnz 0x00007F7C123DE696
00007f7c123dc1aa  lea r12, [rax+0xC0]
00007f7c123dc1b1  movups xmm1, [r13+r12*1]
00007f7c123dc1b7  vmovaps xmm3, [rsp+0xC0]
00007f7c123dc1c0  vmovaps [rsp+0x80], xmm1
00007f7c123dc1c9  movaps xmm15, xmm3
00007f7c123dc1cd  addpd xmm15, xmm7
00007f7c123dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007f7c123dc1d8  ptest xmm1, xmm1
00007f7c123dc1dd  jnz 0x00007F7C123DE7E2
00007f7c123dc1e3  vmovaps [rsp+0xC0], xmm13
00007f7c123dc1ec  vmovaps xmm1, [rsp+0xC0]
00007f7c123dc1f5  por xmm13, xmm1
00007f7c123dc1fa  movaps [r15+0x270], xmm13
00007f7c123dc202  vmovaps xmm1, [rsp+0xB0]
00007f7c123dc20b  vmovaps xmm7, [rsp+0xB0]
00007f7c123dc214  por xmm1, xmm7
00007f7c123dc218  movaps [r15+0x1A0], xmm1
00007f7c123dc220  vmovaps xmm1, [rsp+0x60]
00007f7c123dc226  vpermilpd xmm1, xmm1, 0x00
00007f7c123dc22c  vmovaps [rsp+0xB0], xmm1
00007f7c123dc235  vmovaps xmm1, [rsp+0x80]
00007f7c123dc23e  vmovaps [rsp+0x80], xmm15
00007f7c123dc247  vmovaps xmm15, [rsp+0xB0]
00007f7c123dc250  vmovaps [rsp+0xB0], xmm14
00007f7c123dc259  movaps xmm3, xmm1
00007f7c123dc25c  mulpd xmm3, xmm15
00007f7c123dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007f7c123dc266  ptest xmm14, xmm14
00007f7c123dc26c  jnz 0x00007F7C123DE924
00007f7c123dc272  lea r12, [rax+0x20]
00007f7c123dc276  movups xmm1, [r13+r12*1]
00007f7c123dc27c  movaps [r15+0x110], xmm1
00007f7c123dc284  vmovaps xmm14, [rsp+0x70]
00007f7c123dc28a  vmovaps [rsp+0x70], xmm1
00007f7c123dc290  movaps xmm15, xmm14
00007f7c123dc294  addpd xmm15, xmm4
00007f7c123dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007f7c123dc29f  ptest xmm1, xmm1
00007f7c123dc2a4  jnz 0x00007F7C123DEA6F
00007f7c123dc2aa  vmovaps xmm1, [rsp+0x60]
00007f7c123dc2b0  vpermilpd xmm1, xmm1, 0x00
00007f7c123dc2b6  movaps xmm14, xmm2
00007f7c123dc2ba  mulpd xmm14, xmm1
00007f7c123dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007f7c123dc2c5  ptest xmm4, xmm4
00007f7c123dc2ca  jnz 0x00007F7C123DEBB2
00007f7c123dc2d0  vmovaps xmm4, [rsp+0x50]
00007f7c123dc2d6  movaps xmm1, xmm4
00007f7c123dc2d9  addpd xmm1, xmm9
00007f7c123dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007f7c123dc2e3  ptest xmm2, xmm2
00007f7c123dc2e8  jnz 0x00007F7C123DECF4
00007f7c123dc2ee  vmovaps xmm9, [rsp+0x30]
00007f7c123dc2f4  vpermilpd xmm9, xmm9, 0x00
00007f7c123dc2fa  vmovaps xmm2, [rsp+0x70]
00007f7c123dc300  vmovaps [rsp+0x50], xmm1
00007f7c123dc306  movaps xmm4, xmm2
00007f7c123dc309  mulpd xmm4, xmm9
00007f7c123dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007f7c123dc313  ptest xmm1, xmm1
00007f7c123dc318  jnz 0x00007F7C123DEE35
00007f7c123dc31e  vmovaps xmm1, [rsp+0x30]
00007f7c123dc324  vpermilpd xmm1, xmm1, 0x00
00007f7c123dc32a  vmovaps xmm2, [rsp+0x90]
00007f7c123dc333  vmovaps [rsp+0x60], xmm15
00007f7c123dc339  movaps xmm9, xmm2
00007f7c123dc33d  mulpd xmm9, xmm1
00007f7c123dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007f7c123dc348  ptest xmm15, xmm15
00007f7c123dc34e  jnz 0x00007F7C123DEF76
00007f7c123dc354  vmovaps xmm15, [rsp+0x80]
00007f7c123dc35d  movaps xmm1, xmm15
00007f7c123dc361  addpd xmm1, xmm6
00007f7c123dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007f7c123dc36a  ptest xmm2, xmm2
00007f7c123dc36f  jnz 0x00007F7C123DF0B8
00007f7c123dc375  movaps xmm15, xmm5
00007f7c123dc379  addpd xmm15, xmm3
00007f7c123dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007f7c123dc384  ptest xmm6, xmm6
00007f7c123dc389  jnz 0x00007F7C123DF1F9
00007f7c123dc38f  vmovaps xmm6, [rsp+0x30]
00007f7c123dc395  vpermilpd xmm6, xmm6, 0x00
00007f7c123dc39b  movaps xmm5, xmm8
00007f7c123dc39f  mulpd xmm5, xmm6
00007f7c123dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007f7c123dc3a8  ptest xmm3, xmm3
00007f7c123dc3ad  jnz 0x00007F7C123DF33B
00007f7c123dc3b3  vmovaps xmm8, [rsp+0x30]
00007f7c123dc3b9  vpermilpd xmm8, xmm8, 0x00
00007f7c123dc3bf  movaps xmm6, xmm10
00007f7c123dc3c3  mulpd xmm6, xmm8
00007f7c123dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007f7c123dc3cd  ptest xmm3, xmm3
00007f7c123dc3d2  jnz 0x00007F7C123DF47C
00007f7c123dc3d8  vmovaps xmm8, [rsp+0x60]
00007f7c123dc3de  movaps xmm10, xmm8
00007f7c123dc3e2  addpd xmm10, xmm14
00007f7c123dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007f7c123dc3ed  ptest xmm3, xmm3
00007f7c123dc3f2  jnz 0x00007F7C123DF5BE
00007f7c123dc3f8  vmovaps xmm8, [rsp+0x50]
00007f7c123dc3fe  movaps xmm14, xmm8
00007f7c123dc402  addpd xmm14, xmm4
00007f7c123dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007f7c123dc40d  ptest xmm3, xmm3
00007f7c123dc412  jnz 0x00007F7C123DF702
00007f7c123dc418  vmovaps xmm8, [rsp+0x40]
00007f7c123dc41e  vpermilpd xmm8, xmm8, 0x00
00007f7c123dc424  movaps xmm4, xmm13
00007f7c123dc428  mulpd xmm4, xmm8
00007f7c123dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007f7c123dc432  ptest xmm3, xmm3
00007f7c123dc437  jnz 0x00007F7C123DF845
00007f7c123dc43d  movaps xmm13, xmm15
00007f7c123dc441  addpd xmm13, xmm9
00007f7c123dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007f7c123dc44c  ptest xmm8, xmm8
00007f7c123dc452  jnz 0x00007F7C123DF987
00007f7c123dc458  movaps xmm15, xmm1
00007f7c123dc45c  addpd xmm15, xmm5
00007f7c123dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007f7c123dc467  ptest xmm9, xmm9
00007f7c123dc46d  jnz 0x00007F7C123DFACB
00007f7c123dc473  vmovaps [rsp+0x30], xmm11
00007f7c123dc479  vmovaps xmm1, [rsp+0x30]
00007f7c123dc47f  por xmm11, xmm1
00007f7c123dc484  movaps [r15+0x250], xmm11
00007f7c123dc48c  vmovaps [rsp+0x30], xmm12
00007f7c123dc492  vmovaps xmm1, [rsp+0x30]
00007f7c123dc498  por xmm12, xmm1
00007f7c123dc49d  movaps [r15+0x2A0], xmm12
00007f7c123dc4a5  vmovaps xmm1, [rsp+0xA0]
00007f7c123dc4ae  vmovaps xmm11, [rsp+0xA0]
00007f7c123dc4b7  por xmm1, xmm11
00007f7c123dc4bc  movaps [r15+0x1D0], xmm1
00007f7c123dc4c4  lea r12, [rax+0x40]
00007f7c123dc4c8  movups xmm1, [r13+r12*1]
00007f7c123dc4ce  movaps [r15+0x2C0], xmm1
00007f7c123dc4d6  vmovaps xmm11, [rsp+0x40]
00007f7c123dc4dc  vpermilpd xmm11, xmm11, 0x00
00007f7c123dc4e2  vmovaps xmm8, [rsp+0xE0]
00007f7c123dc4eb  movaps xmm9, xmm8
00007f7c123dc4ef  mulpd xmm9, xmm11
00007f7c123dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007f7c123dc4fa  ptest xmm5, xmm5
00007f7c123dc4ff  jnz 0x00007F7C123DFC17
00007f7c123dc505  movaps xmm11, xmm10
00007f7c123dc509  addpd xmm11, xmm6
00007f7c123dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007f7c123dc514  ptest xmm8, xmm8
00007f7c123dc51a  jnz 0x00007F7C123DFD5B
00007f7c123dc520  movaps xmm10, xmm14
00007f7c123dc524  addpd xmm10, xmm4
00007f7c123dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007f7c123dc52f  ptest xmm8, xmm8
00007f7c123dc535  jnz 0x00007F7C123DFE9E
00007f7c123dc53b  vmovaps xmm14, [rsp+0x40]
00007f7c123dc541  vpermilpd xmm14, xmm14, 0x00
00007f7c123dc547  movaps xmm8, xmm1
00007f7c123dc54b  mulpd xmm8, xmm14
00007f7c123dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007f7c123dc556  ptest xmm6, xmm6
00007f7c123dc55b  jnz 0x00007F7C123DFFE1
00007f7c123dc561  movaps xmm1, [r15+0x2B0]
00007f7c123dc569  vmovaps xmm14, [rsp+0x40]
00007f7c123dc56f  vpermilpd xmm14, xmm14, 0x00
00007f7c123dc575  movaps xmm6, xmm1
00007f7c123dc578  mulpd xmm6, xmm14
00007f7c123dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007f7c123dc582  ptest xmm5, xmm5
00007f7c123dc587  jnz 0x00007F7C123E0124
00007f7c123dc58d  vmovaps xmm1, [rsp+0x10]
00007f7c123dc593  vpermilpd xmm1, xmm1, 0x00
00007f7c123dc599  movaps xmm14, xmm12
00007f7c123dc59d  mulpd xmm14, xmm1
00007f7c123dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007f7c123dc5a8  ptest xmm5, xmm5
00007f7c123dc5ad  jnz 0x00007F7C123E0265
00007f7c123dc5b3  movaps xmm1, xmm13
00007f7c123dc5b7  addpd xmm1, xmm9
00007f7c123dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007f7c123dc5c1  ptest xmm12, xmm12
00007f7c123dc5c7  jnz 0x00007F7C123E03A8
00007f7c123dc5cd  vmovaps xmm13, [rsp+0x10]
00007f7c123dc5d3  vpermilpd xmm13, xmm13, 0x00
00007f7c123dc5d9  movaps xmm12, xmm7
00007f7c123dc5dd  mulpd xmm12, xmm13
00007f7c123dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007f7c123dc5e8  ptest xmm9, xmm9
00007f7c123dc5ee  jnz 0x00007F7C123E04EA
00007f7c123dc5f4  movaps xmm13, xmm15
00007f7c123dc5f8  addpd xmm13, xmm8
00007f7c123dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007f7c123dc603  ptest xmm9, xmm9
00007f7c123dc609  jnz 0x00007F7C123E062D
00007f7c123dc60f  movaps xmm15, [r15+0x290]
00007f7c123dc617  vmovaps xmm9, [rsp+0x10]
00007f7c123dc61d  vpermilpd xmm9, xmm9, 0x00
00007f7c123dc623  movaps xmm8, xmm15
00007f7c123dc627  mulpd xmm8, xmm9
00007f7c123dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007f7c123dc632  ptest xmm7, xmm7
00007f7c123dc637  jnz 0x00007F7C123E0771
00007f7c123dc63d  movaps xmm15, xmm11
00007f7c123dc641  addpd xmm15, xmm6
00007f7c123dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007f7c123dc64c  ptest xmm9, xmm9
00007f7c123dc652  jnz 0x00007F7C123E08B5
00007f7c123dc658  movaps xmm11, [r15+0x1E0]
00007f7c123dc660  vmovaps xmm9, [rsp+0x10]
00007f7c123dc666  vpermilpd xmm9, xmm9, 0x00
00007f7c123dc66c  movaps xmm7, xmm11
00007f7c123dc670  mulpd xmm7, xmm9
00007f7c123dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007f7c123dc67a  ptest xmm6, xmm6
00007f7c123dc67f  jnz 0x00007F7C123E09F8
00007f7c123dc685  movaps xmm11, xmm10
00007f7c123dc689  addpd xmm11, xmm14
00007f7c123dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007f7c123dc694  ptest xmm9, xmm9
00007f7c123dc69a  jnz 0x00007F7C123E0B3A
00007f7c123dc6a0  lea r12, [rax+0x70]
00007f7c123dc6a4  movups xmm14, [r13+r12*1]
00007f7c123dc6aa  movaps [r15+0x240], xmm14
00007f7c123dc6b2  movaps xmm10, xmm1
00007f7c123dc6b6  addpd xmm10, xmm12
00007f7c123dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007f7c123dc6c1  ptest xmm9, xmm9
00007f7c123dc6c7  jnz 0x00007F7C123E0C88
00007f7c123dc6cd  movaps [r15+0x170], xmm10
00007f7c123dc6d5  vmovaps xmm1, [rsp+0x20]
00007f7c123dc6db  vpermilpd xmm1, xmm1, 0x00
00007f7c123dc6e1  movaps xmm12, xmm14
00007f7c123dc6e5  mulpd xmm12, xmm1
00007f7c123dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007f7c123dc6f0  ptest xmm9, xmm9
00007f7c123dc6f6  jnz 0x00007F7C123E0DCB
00007f7c123dc6fc  vmovaps xmm1, [rsp+0x20]
00007f7c123dc702  vpermilpd xmm1, xmm1, 0x00
00007f7c123dc708  vmovaps xmm9, [rsp+0xB0]
00007f7c123dc711  movaps xmm14, xmm9
00007f7c123dc715  mulpd xmm14, xmm1
00007f7c123dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007f7c123dc720  ptest xmm6, xmm6
00007f7c123dc725  jnz 0x00007F7C123E0F0E
00007f7c123dc72b  movaps [r15+0x180], xmm14
00007f7c123dc733  movaps xmm1, xmm13
00007f7c123dc737  addpd xmm1, xmm8
00007f7c123dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007f7c123dc741  ptest xmm9, xmm9
00007f7c123dc747  jnz 0x00007F7C123E1051
00007f7c123dc74d  movaps [r15+0x210], xmm1
00007f7c123dc755  movups xmm13, [r13+rax*1]
00007f7c123dc75b  lea r12, [rax+0x10]
00007f7c123dc75f  movups xmm9, [r13+r12*1]
00007f7c123dc765  movaps [r15+0x230], xmm9
00007f7c123dc76d  movaps xmm8, xmm15
00007f7c123dc771  addpd xmm8, xmm7
00007f7c123dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007f7c123dc77c  ptest xmm6, xmm6
00007f7c123dc781  jnz 0x00007F7C123E11A7
00007f7c123dc787  movaps [r15+0x130], xmm8
00007f7c123dc78f  vmovaps xmm15, [rsp+0x20]
00007f7c123dc795  vpermilpd xmm15, xmm15, 0x00
00007f7c123dc79b  movaps xmm7, xmm9
00007f7c123dc79f  mulpd xmm7, xmm15
00007f7c123dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007f7c123dc7a9  ptest xmm6, xmm6
00007f7c123dc7ae  jnz 0x00007F7C123E12EA
00007f7c123dc7b4  movaps [r15+0x220], xmm7
00007f7c123dc7bc  vmovaps xmm15, [rsp+0x20]
00007f7c123dc7c2  vpermilpd xmm15, xmm15, 0x00
00007f7c123dc7c8  movaps xmm9, xmm13
00007f7c123dc7cc  mulpd xmm9, xmm15
00007f7c123dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007f7c123dc7d7  ptest xmm6, xmm6
00007f7c123dc7dc  jnz 0x00007F7C123E142C
00007f7c123dc7e2  movaps xmm15, xmm11
00007f7c123dc7e6  addpd xmm15, xmm12
00007f7c123dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007f7c123dc7f1  ptest xmm13, xmm13
00007f7c123dc7f7  jnz 0x00007F7C123E1570
00007f7c123dc7fd  movaps [r15+0x140], xmm15
00007f7c123dc805  movaps xmm13, xmm10
00007f7c123dc809  addpd xmm13, xmm14
00007f7c123dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007f7c123dc814  ptest xmm12, xmm12
00007f7c123dc81a  jnz 0x00007F7C123E16B4
00007f7c123dc820  movaps [r15+0x150], xmm13
00007f7c123dc828  movaps xmm14, xmm1
00007f7c123dc82c  addpd xmm14, xmm7
00007f7c123dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007f7c123dc837  ptest xmm12, xmm12
00007f7c123dc83d  jnz 0x00007F7C123E17F8
00007f7c123dc843  movaps [r15+0x160], xmm14
00007f7c123dc84b  movaps xmm1, xmm8
00007f7c123dc84f  addpd xmm1, xmm9
00007f7c123dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007f7c123dc859  ptest xmm12, xmm12
00007f7c123dc85f  jnz 0x00007F7C123E193A
00007f7c123dc865  movaps [r15+0x120], xmm1
00007f7c123dc86d  movups [r13+r14*1], xmm15
00007f7c123dc873  lea rax, [r14+0x10]
00007f7c123dc877  movups [r13+rax*1], xmm13
00007f7c123dc87d  lea rax, [r14+0x20]
00007f7c123dc881  movups [r13+rax*1], xmm14
00007f7c123dc887  lea rax, [r14+0x30]
00007f7c123dc88b  movups [r13+rax*1], xmm1
00007f7c123dc891  mov eax, [r15+0x108]
00007f7c123dc898  sahf
00007f7c123dc899  jnz 0x00007F7C123DC8CB
00007f7c123dc89b  cmp dword ptr [r15+0x318], 0x00
00007f7c123dc8a3  jz 0x00007F7C123DB900
00007f7c123dc8a9  nop [rax+rax*1], ax
00007f7c123dc8b2  nop [rax+rax*1], eax
00007f7c123dc8ba  mov eax, 0x410444
00007f7c123dc8bf  mov [r15+0x100], rax
00007f7c123dc8c6  jmp 0x00007F7C121FE110
00007f7c123dc8cb  cmp dword ptr [r15+0x318], 0x00
00007f7c123dc8d3  jz 0x00007F7C123D57E0
00007f7c123dc8d9  nop [rax+rax*1], ax
00007f7c123dc8e2  nop [rax+rax*1], eax
00007f7c123dc8ea  mov eax, 0x410278
00007f7c123dc8ef  mov [r15+0x100], rax
00007f7c123dc8f6  jmp 0x00007F7C121FE110
00007f7c123dc8fb  int3
00007f7c123dc8fc  call 0x00007F7C122E27E0
00007f7c123dc901  jmp 0x00007F7C123DB9DF
00007f7c123dc906  call 0x00007F7C122E1570
00007f7c123dc90b  jmp 0x00007F7C123DB9E8
00007f7c123dc910  call 0x00007F7C122E27E0
00007f7c123dc915  jmp 0x00007F7C123DBA44
00007f7c123dc91a  call 0x00007F7C122E1570
00007f7c123dc91f  jmp 0x00007F7C123DBA4D
00007f7c123dc924  call 0x00007F7C122E27E0
00007f7c123dc929  jmp 0x00007F7C123DBA90
00007f7c123dc92e  call 0x00007F7C122E1570
00007f7c123dc933  jmp 0x00007F7C123DBA99
00007f7c123dc938  call 0x00007F7C1220DC20
00007f7c123dc93d  jmp 0x00007F7C123DBAD8
00007f7c123dc942  call 0x00007F7C122D59C0
00007f7c123dc947  jmp 0x00007F7C123DBAEB
00007f7c123dc94c  call 0x00007F7C122E0E30
00007f7c123dc951  jmp 0x00007F7C123DBB09
00007f7c123dc956  call 0x00007F7C122DFBC0
00007f7c123dc95b  jmp 0x00007F7C123DBB13
00007f7c123dc960  call 0x00007F7C122DE950
00007f7c123dc965  jmp 0x00007F7C123DBB1D
00007f7c123dc96a  sub rsp, 0x08
00007f7c123dc96e  push rax
00007f7c123dc96f  push rcx
00007f7c123dc970  push rdx
00007f7c123dc971  push rdi
00007f7c123dc972  push rsi
00007f7c123dc973  push r8
00007f7c123dc975  push r9
00007f7c123dc977  push r10
00007f7c123dc979  push r11
00007f7c123dc97b  sub rsp, 0xF0
00007f7c123dc982  vmovaps [rsp], xmm0
00007f7c123dc987  vmovaps [rsp+0x10], xmm1
00007f7c123dc98d  vmovaps [rsp+0x20], xmm2
00007f7c123dc993  vmovaps [rsp+0x30], xmm3
00007f7c123dc999  vmovaps [rsp+0x40], xmm4
00007f7c123dc99f  vmovaps [rsp+0x50], xmm5
00007f7c123dc9a5  vmovaps [rsp+0x60], xmm6
00007f7c123dc9ab  vmovaps [rsp+0x70], xmm7
00007f7c123dc9b1  vmovaps [rsp+0x80], xmm9
00007f7c123dc9ba  vmovaps [rsp+0x90], xmm10
00007f7c123dc9c3  vmovaps [rsp+0xA0], xmm11
00007f7c123dc9cc  vmovaps [rsp+0xB0], xmm12
00007f7c123dc9d5  vmovaps [rsp+0xC0], xmm13
00007f7c123dc9de  vmovaps [rsp+0xD0], xmm14
00007f7c123dc9e7  vmovaps [rsp+0xE0], xmm15
00007f7c123dc9f0  sub rsp, 0x30
00007f7c123dc9f4  movaps [rsp], xmm8
00007f7c123dc9f9  movaps [rsp+0x10], xmm12
00007f7c123dc9ff  movaps [rsp+0x20], xmm15
00007f7c123dca05  lea rdi, [rsp]
00007f7c123dca09  mov esi, 0x00
00007f7c123dca0e  mov rax, 0x5E723D793530
00007f7c123dca18  call rax
00007f7c123dca1a  movaps xmm8, [rsp]
00007f7c123dca1f  add rsp, 0x30
00007f7c123dca23  vmovaps xmm0, [rsp]
00007f7c123dca28  vmovaps xmm1, [rsp+0x10]
00007f7c123dca2e  vmovaps xmm2, [rsp+0x20]
00007f7c123dca34  vmovaps xmm3, [rsp+0x30]
00007f7c123dca3a  vmovaps xmm4, [rsp+0x40]
00007f7c123dca40  vmovaps xmm5, [rsp+0x50]
00007f7c123dca46  vmovaps xmm6, [rsp+0x60]
00007f7c123dca4c  vmovaps xmm7, [rsp+0x70]
00007f7c123dca52  vmovaps xmm9, [rsp+0x80]
00007f7c123dca5b  vmovaps xmm10, [rsp+0x90]
00007f7c123dca64  vmovaps xmm11, [rsp+0xA0]
00007f7c123dca6d  vmovaps xmm12, [rsp+0xB0]
00007f7c123dca76  vmovaps xmm13, [rsp+0xC0]
00007f7c123dca7f  vmovaps xmm14, [rsp+0xD0]
00007f7c123dca88  vmovaps xmm15, [rsp+0xE0]
00007f7c123dca91  add rsp, 0xF0
00007f7c123dca98  pop r11
00007f7c123dca9a  pop r10
00007f7c123dca9c  pop r9
00007f7c123dca9e  pop r8
00007f7c123dcaa0  pop rsi
00007f7c123dcaa1  pop rdi
00007f7c123dcaa2  pop rdx
00007f7c123dcaa3  pop rcx
00007f7c123dcaa4  pop rax
00007f7c123dcaa5  add rsp, 0x08
00007f7c123dcaa9  jmp 0x00007F7C123DBB47
00007f7c123dcaae  sub rsp, 0x08
00007f7c123dcab2  push rax
00007f7c123dcab3  push rcx
00007f7c123dcab4  push rdx
00007f7c123dcab5  push rdi
00007f7c123dcab6  push rsi
00007f7c123dcab7  push r8
00007f7c123dcab9  push r9
00007f7c123dcabb  push r10
00007f7c123dcabd  push r11
00007f7c123dcabf  sub rsp, 0xF0
00007f7c123dcac6  vmovaps [rsp], xmm0
00007f7c123dcacb  vmovaps [rsp+0x10], xmm1
00007f7c123dcad1  vmovaps [rsp+0x20], xmm2
00007f7c123dcad7  vmovaps [rsp+0x30], xmm3
00007f7c123dcadd  vmovaps [rsp+0x40], xmm4
00007f7c123dcae3  vmovaps [rsp+0x50], xmm5
00007f7c123dcae9  vmovaps [rsp+0x60], xmm6
00007f7c123dcaef  vmovaps [rsp+0x70], xmm8
00007f7c123dcaf5  vmovaps [rsp+0x80], xmm9
00007f7c123dcafe  vmovaps [rsp+0x90], xmm10
00007f7c123dcb07  vmovaps [rsp+0xA0], xmm11
00007f7c123dcb10  vmovaps [rsp+0xB0], xmm12
00007f7c123dcb19  vmovaps [rsp+0xC0], xmm13
00007f7c123dcb22  vmovaps [rsp+0xD0], xmm14
00007f7c123dcb2b  vmovaps [rsp+0xE0], xmm15
00007f7c123dcb34  sub rsp, 0x30
00007f7c123dcb38  movaps [rsp], xmm7
00007f7c123dcb3c  movaps [rsp+0x10], xmm9
00007f7c123dcb42  movaps [rsp+0x20], xmm15
00007f7c123dcb48  lea rdi, [rsp]
00007f7c123dcb4c  mov esi, 0x00
00007f7c123dcb51  mov rax, 0x5E723D793530
00007f7c123dcb5b  call rax
00007f7c123dcb5d  movaps xmm7, [rsp]
00007f7c123dcb61  add rsp, 0x30
00007f7c123dcb65  vmovaps xmm0, [rsp]
00007f7c123dcb6a  vmovaps xmm1, [rsp+0x10]
00007f7c123dcb70  vmovaps xmm2, [rsp+0x20]
00007f7c123dcb76  vmovaps xmm3, [rsp+0x30]
00007f7c123dcb7c  vmovaps xmm4, [rsp+0x40]
00007f7c123dcb82  vmovaps xmm5, [rsp+0x50]
00007f7c123dcb88  vmovaps xmm6, [rsp+0x60]
00007f7c123dcb8e  vmovaps xmm8, [rsp+0x70]
00007f7c123dcb94  vmovaps xmm9, [rsp+0x80]
00007f7c123dcb9d  vmovaps xmm10, [rsp+0x90]
00007f7c123dcba6  vmovaps xmm11, [rsp+0xA0]
00007f7c123dcbaf  vmovaps xmm12, [rsp+0xB0]
00007f7c123dcbb8  vmovaps xmm13, [rsp+0xC0]
00007f7c123dcbc1  vmovaps xmm14, [rsp+0xD0]
00007f7c123dcbca  vmovaps xmm15, [rsp+0xE0]
00007f7c123dcbd3  add rsp, 0xF0
00007f7c123dcbda  pop r11
00007f7c123dcbdc  pop r10
00007f7c123dcbde  pop r9
00007f7c123dcbe0  pop r8
00007f7c123dcbe2  pop rsi
00007f7c123dcbe3  pop rdi
00007f7c123dcbe4  pop rdx
00007f7c123dcbe5  pop rcx
00007f7c123dcbe6  pop rax
00007f7c123dcbe7  add rsp, 0x08
00007f7c123dcbeb  jmp 0x00007F7C123DBB75
00007f7c123dcbf0  sub rsp, 0x08
00007f7c123dcbf4  push rax
00007f7c123dcbf5  push rcx
00007f7c123dcbf6  push rdx
00007f7c123dcbf7  push rdi
00007f7c123dcbf8  push rsi
00007f7c123dcbf9  push r8
00007f7c123dcbfb  push r9
00007f7c123dcbfd  push r10
00007f7c123dcbff  push r11
00007f7c123dcc01  sub rsp, 0xF0
00007f7c123dcc08  vmovaps [rsp], xmm0
00007f7c123dcc0d  vmovaps [rsp+0x10], xmm1
00007f7c123dcc13  vmovaps [rsp+0x20], xmm2
00007f7c123dcc19  vmovaps [rsp+0x30], xmm3
00007f7c123dcc1f  vmovaps [rsp+0x40], xmm4
00007f7c123dcc25  vmovaps [rsp+0x50], xmm5
00007f7c123dcc2b  vmovaps [rsp+0x60], xmm6
00007f7c123dcc31  vmovaps [rsp+0x70], xmm7
00007f7c123dcc37  vmovaps [rsp+0x80], xmm8
00007f7c123dcc40  vmovaps [rsp+0x90], xmm10
00007f7c123dcc49  vmovaps [rsp+0xA0], xmm11
00007f7c123dcc52  vmovaps [rsp+0xB0], xmm12
00007f7c123dcc5b  vmovaps [rsp+0xC0], xmm13
00007f7c123dcc64  vmovaps [rsp+0xD0], xmm14
00007f7c123dcc6d  vmovaps [rsp+0xE0], xmm15
00007f7c123dcc76  sub rsp, 0x30
00007f7c123dcc7a  movaps [rsp], xmm9
00007f7c123dcc7f  movaps [rsp+0x10], xmm12
00007f7c123dcc85  movaps [rsp+0x20], xmm10
00007f7c123dcc8b  lea rdi, [rsp]
00007f7c123dcc8f  mov esi, 0x00
00007f7c123dcc94  mov rax, 0x5E723D793530
00007f7c123dcc9e  call rax
00007f7c123dcca0  movaps xmm9, [rsp]
00007f7c123dcca5  add rsp, 0x30
00007f7c123dcca9  vmovaps xmm0, [rsp]
00007f7c123dccae  vmovaps xmm1, [rsp+0x10]
00007f7c123dccb4  vmovaps xmm2, [rsp+0x20]
00007f7c123dccba  vmovaps xmm3, [rsp+0x30]
00007f7c123dccc0  vmovaps xmm4, [rsp+0x40]
00007f7c123dccc6  vmovaps xmm5, [rsp+0x50]
00007f7c123dcccc  vmovaps xmm6, [rsp+0x60]
00007f7c123dccd2  vmovaps xmm7, [rsp+0x70]
00007f7c123dccd8  vmovaps xmm8, [rsp+0x80]
00007f7c123dcce1  vmovaps xmm10, [rsp+0x90]
00007f7c123dccea  vmovaps xmm11, [rsp+0xA0]
00007f7c123dccf3  vmovaps xmm12, [rsp+0xB0]
00007f7c123dccfc  vmovaps xmm13, [rsp+0xC0]
00007f7c123dcd05  vmovaps xmm14, [rsp+0xD0]
00007f7c123dcd0e  vmovaps xmm15, [rsp+0xE0]
00007f7c123dcd17  add rsp, 0xF0
00007f7c123dcd1e  pop r11
00007f7c123dcd20  pop r10
00007f7c123dcd22  pop r9
00007f7c123dcd24  pop r8
00007f7c123dcd26  pop rsi
00007f7c123dcd27  pop rdi
00007f7c123dcd28  pop rdx
00007f7c123dcd29  pop rcx
00007f7c123dcd2a  pop rax
00007f7c123dcd2b  add rsp, 0x08
00007f7c123dcd2f  jmp 0x00007F7C123DBB99
00007f7c123dcd34  sub rsp, 0x08
00007f7c123dcd38  push rax
00007f7c123dcd39  push rcx
00007f7c123dcd3a  push rdx
00007f7c123dcd3b  push rdi
00007f7c123dcd3c  push rsi
00007f7c123dcd3d  push r8
00007f7c123dcd3f  push r9
00007f7c123dcd41  push r10
00007f7c123dcd43  push r11
00007f7c123dcd45  sub rsp, 0xF0
00007f7c123dcd4c  vmovaps [rsp], xmm0
00007f7c123dcd51  vmovaps [rsp+0x10], xmm1
00007f7c123dcd57  vmovaps [rsp+0x20], xmm2
00007f7c123dcd5d  vmovaps [rsp+0x30], xmm3
00007f7c123dcd63  vmovaps [rsp+0x40], xmm4
00007f7c123dcd69  vmovaps [rsp+0x50], xmm5
00007f7c123dcd6f  vmovaps [rsp+0x60], xmm6
00007f7c123dcd75  vmovaps [rsp+0x70], xmm7
00007f7c123dcd7b  vmovaps [rsp+0x80], xmm8
00007f7c123dcd84  vmovaps [rsp+0x90], xmm9
00007f7c123dcd8d  vmovaps [rsp+0xA0], xmm11
00007f7c123dcd96  vmovaps [rsp+0xB0], xmm12
00007f7c123dcd9f  vmovaps [rsp+0xC0], xmm13
00007f7c123dcda8  vmovaps [rsp+0xD0], xmm14
00007f7c123dcdb1  vmovaps [rsp+0xE0], xmm15
00007f7c123dcdba  sub rsp, 0x30
00007f7c123dcdbe  movaps [rsp], xmm10
00007f7c123dcdc3  movaps [rsp+0x10], xmm12
00007f7c123dcdc9  movaps [rsp+0x20], xmm11
00007f7c123dcdcf  lea rdi, [rsp]
00007f7c123dcdd3  mov esi, 0x00
00007f7c123dcdd8  mov rax, 0x5E723D793530
00007f7c123dcde2  call rax
00007f7c123dcde4  movaps xmm10, [rsp]
00007f7c123dcde9  add rsp, 0x30
00007f7c123dcded  vmovaps xmm0, [rsp]
00007f7c123dcdf2  vmovaps xmm1, [rsp+0x10]
00007f7c123dcdf8  vmovaps xmm2, [rsp+0x20]
00007f7c123dcdfe  vmovaps xmm3, [rsp+0x30]
00007f7c123dce04  vmovaps xmm4, [rsp+0x40]
00007f7c123dce0a  vmovaps xmm5, [rsp+0x50]
00007f7c123dce10  vmovaps xmm6, [rsp+0x60]
00007f7c123dce16  vmovaps xmm7, [rsp+0x70]
00007f7c123dce1c  vmovaps xmm8, [rsp+0x80]
00007f7c123dce25  vmovaps xmm9, [rsp+0x90]
00007f7c123dce2e  vmovaps xmm11, [rsp+0xA0]
00007f7c123dce37  vmovaps xmm12, [rsp+0xB0]
00007f7c123dce40  vmovaps xmm13, [rsp+0xC0]
00007f7c123dce49  vmovaps xmm14, [rsp+0xD0]
00007f7c123dce52  vmovaps xmm15, [rsp+0xE0]
00007f7c123dce5b  add rsp, 0xF0
00007f7c123dce62  pop r11
00007f7c123dce64  pop r10
00007f7c123dce66  pop r9
00007f7c123dce68  pop r8
00007f7c123dce6a  pop rsi
00007f7c123dce6b  pop rdi
00007f7c123dce6c  pop rdx
00007f7c123dce6d  pop rcx
00007f7c123dce6e  pop rax
00007f7c123dce6f  add rsp, 0x08
00007f7c123dce73  jmp 0x00007F7C123DBBB3
00007f7c123dce78  sub rsp, 0x08
00007f7c123dce7c  push rax
00007f7c123dce7d  push rcx
00007f7c123dce7e  push rdx
00007f7c123dce7f  push rdi
00007f7c123dce80  push rsi
00007f7c123dce81  push r8
00007f7c123dce83  push r9
00007f7c123dce85  push r10
00007f7c123dce87  push r11
00007f7c123dce89  sub rsp, 0xF0
00007f7c123dce90  vmovaps [rsp], xmm0
00007f7c123dce95  vmovaps [rsp+0x10], xmm1
00007f7c123dce9b  vmovaps [rsp+0x20], xmm2
00007f7c123dcea1  vmovaps [rsp+0x30], xmm3
00007f7c123dcea7  vmovaps [rsp+0x40], xmm4
00007f7c123dcead  vmovaps [rsp+0x50], xmm5
00007f7c123dceb3  vmovaps [rsp+0x60], xmm7
00007f7c123dceb9  vmovaps [rsp+0x70], xmm8
00007f7c123dcebf  vmovaps [rsp+0x80], xmm9
00007f7c123dcec8  vmovaps [rsp+0x90], xmm10
00007f7c123dced1  vmovaps [rsp+0xA0], xmm11
00007f7c123dceda  vmovaps [rsp+0xB0], xmm12
00007f7c123dcee3  vmovaps [rsp+0xC0], xmm13
00007f7c123dceec  vmovaps [rsp+0xD0], xmm14
00007f7c123dcef5  vmovaps [rsp+0xE0], xmm15
00007f7c123dcefe  sub rsp, 0x30
00007f7c123dcf02  movaps [rsp], xmm6
00007f7c123dcf06  movaps [rsp+0x10], xmm12
00007f7c123dcf0c  movaps [rsp+0x20], xmm11
00007f7c123dcf12  lea rdi, [rsp]
00007f7c123dcf16  mov esi, 0x00
00007f7c123dcf1b  mov rax, 0x5E723D793530
00007f7c123dcf25  call rax
00007f7c123dcf27  movaps xmm6, [rsp]
00007f7c123dcf2b  add rsp, 0x30
00007f7c123dcf2f  vmovaps xmm0, [rsp]
00007f7c123dcf34  vmovaps xmm1, [rsp+0x10]
00007f7c123dcf3a  vmovaps xmm2, [rsp+0x20]
00007f7c123dcf40  vmovaps xmm3, [rsp+0x30]
00007f7c123dcf46  vmovaps xmm4, [rsp+0x40]
00007f7c123dcf4c  vmovaps xmm5, [rsp+0x50]
00007f7c123dcf52  vmovaps xmm7, [rsp+0x60]
00007f7c123dcf58  vmovaps xmm8, [rsp+0x70]
00007f7c123dcf5e  vmovaps xmm9, [rsp+0x80]
00007f7c123dcf67  vmovaps xmm10, [rsp+0x90]
00007f7c123dcf70  vmovaps xmm11, [rsp+0xA0]
00007f7c123dcf79  vmovaps xmm12, [rsp+0xB0]
00007f7c123dcf82  vmovaps xmm13, [rsp+0xC0]
00007f7c123dcf8b  vmovaps xmm14, [rsp+0xD0]
00007f7c123dcf94  vmovaps xmm15, [rsp+0xE0]
00007f7c123dcf9d  add rsp, 0xF0
00007f7c123dcfa4  pop r11
00007f7c123dcfa6  pop r10
00007f7c123dcfa8  pop r9
00007f7c123dcfaa  pop r8
00007f7c123dcfac  pop rsi
00007f7c123dcfad  pop rdi
00007f7c123dcfae  pop rdx
00007f7c123dcfaf  pop rcx
00007f7c123dcfb0  pop rax
00007f7c123dcfb1  add rsp, 0x08
00007f7c123dcfb5  jmp 0x00007F7C123DBBD4
00007f7c123dcfba  sub rsp, 0x08
00007f7c123dcfbe  push rax
00007f7c123dcfbf  push rcx
00007f7c123dcfc0  push rdx
00007f7c123dcfc1  push rdi
00007f7c123dcfc2  push rsi
00007f7c123dcfc3  push r8
00007f7c123dcfc5  push r9
00007f7c123dcfc7  push r10
00007f7c123dcfc9  push r11
00007f7c123dcfcb  sub rsp, 0xF0
00007f7c123dcfd2  vmovaps [rsp], xmm0
00007f7c123dcfd7  vmovaps [rsp+0x10], xmm1
00007f7c123dcfdd  vmovaps [rsp+0x20], xmm2
00007f7c123dcfe3  vmovaps [rsp+0x30], xmm4
00007f7c123dcfe9  vmovaps [rsp+0x40], xmm5
00007f7c123dcfef  vmovaps [rsp+0x50], xmm6
00007f7c123dcff5  vmovaps [rsp+0x60], xmm7
00007f7c123dcffb  vmovaps [rsp+0x70], xmm8
00007f7c123dd001  vmovaps [rsp+0x80], xmm9
00007f7c123dd00a  vmovaps [rsp+0x90], xmm10
00007f7c123dd013  vmovaps [rsp+0xA0], xmm11
00007f7c123dd01c  vmovaps [rsp+0xB0], xmm12
00007f7c123dd025  vmovaps [rsp+0xC0], xmm13
00007f7c123dd02e  vmovaps [rsp+0xD0], xmm14
00007f7c123dd037  vmovaps [rsp+0xE0], xmm15
00007f7c123dd040  sub rsp, 0x30
00007f7c123dd044  movaps [rsp], xmm3
00007f7c123dd048  movaps [rsp+0x10], xmm5
00007f7c123dd04d  movaps [rsp+0x20], xmm4
00007f7c123dd052  lea rdi, [rsp]
00007f7c123dd056  mov esi, 0x00
00007f7c123dd05b  mov rax, 0x5E723D793530
00007f7c123dd065  call rax
00007f7c123dd067  movaps xmm3, [rsp]
00007f7c123dd06b  add rsp, 0x30
00007f7c123dd06f  vmovaps xmm0, [rsp]
00007f7c123dd074  vmovaps xmm1, [rsp+0x10]
00007f7c123dd07a  vmovaps xmm2, [rsp+0x20]
00007f7c123dd080  vmovaps xmm4, [rsp+0x30]
00007f7c123dd086  vmovaps xmm5, [rsp+0x40]
00007f7c123dd08c  vmovaps xmm6, [rsp+0x50]
00007f7c123dd092  vmovaps xmm7, [rsp+0x60]
00007f7c123dd098  vmovaps xmm8, [rsp+0x70]
00007f7c123dd09e  vmovaps xmm9, [rsp+0x80]
00007f7c123dd0a7  vmovaps xmm10, [rsp+0x90]
00007f7c123dd0b0  vmovaps xmm11, [rsp+0xA0]
00007f7c123dd0b9  vmovaps xmm12, [rsp+0xB0]
00007f7c123dd0c2  vmovaps xmm13, [rsp+0xC0]
00007f7c123dd0cb  vmovaps xmm14, [rsp+0xD0]
00007f7c123dd0d4  vmovaps xmm15, [rsp+0xE0]
00007f7c123dd0dd  add rsp, 0xF0
00007f7c123dd0e4  pop r11
00007f7c123dd0e6  pop r10
00007f7c123dd0e8  pop r9
00007f7c123dd0ea  pop r8
00007f7c123dd0ec  pop rsi
00007f7c123dd0ed  pop rdi
00007f7c123dd0ee  pop rdx
00007f7c123dd0ef  pop rcx
00007f7c123dd0f0  pop rax
00007f7c123dd0f1  add rsp, 0x08
00007f7c123dd0f5  jmp 0x00007F7C123DBC35
00007f7c123dd0fa  sub rsp, 0x08
00007f7c123dd0fe  push rax
00007f7c123dd0ff  push rcx
00007f7c123dd100  push rdx
00007f7c123dd101  push rdi
00007f7c123dd102  push rsi
00007f7c123dd103  push r8
00007f7c123dd105  push r9
00007f7c123dd107  push r10
00007f7c123dd109  push r11
00007f7c123dd10b  sub rsp, 0xF0
00007f7c123dd112  vmovaps [rsp], xmm0
00007f7c123dd117  vmovaps [rsp+0x10], xmm1
00007f7c123dd11d  vmovaps [rsp+0x20], xmm2
00007f7c123dd123  vmovaps [rsp+0x30], xmm3
00007f7c123dd129  vmovaps [rsp+0x40], xmm4
00007f7c123dd12f  vmovaps [rsp+0x50], xmm6
00007f7c123dd135  vmovaps [rsp+0x60], xmm7
00007f7c123dd13b  vmovaps [rsp+0x70], xmm8
00007f7c123dd141  vmovaps [rsp+0x80], xmm9
00007f7c123dd14a  vmovaps [rsp+0x90], xmm10
00007f7c123dd153  vmovaps [rsp+0xA0], xmm11
00007f7c123dd15c  vmovaps [rsp+0xB0], xmm12
00007f7c123dd165  vmovaps [rsp+0xC0], xmm13
00007f7c123dd16e  vmovaps [rsp+0xD0], xmm14
00007f7c123dd177  vmovaps [rsp+0xE0], xmm15
00007f7c123dd180  sub rsp, 0x30
00007f7c123dd184  movaps [rsp], xmm5
00007f7c123dd188  movaps [rsp+0x10], xmm8
00007f7c123dd18e  movaps [rsp+0x20], xmm15
00007f7c123dd194  lea rdi, [rsp]
00007f7c123dd198  mov esi, 0x00
00007f7c123dd19d  mov rax, 0x5E723D793530
00007f7c123dd1a7  call rax
00007f7c123dd1a9  movaps xmm5, [rsp]
00007f7c123dd1ad  add rsp, 0x30
00007f7c123dd1b1  vmovaps xmm0, [rsp]
00007f7c123dd1b6  vmovaps xmm1, [rsp+0x10]
00007f7c123dd1bc  vmovaps xmm2, [rsp+0x20]
00007f7c123dd1c2  vmovaps xmm3, [rsp+0x30]
00007f7c123dd1c8  vmovaps xmm4, [rsp+0x40]
00007f7c123dd1ce  vmovaps xmm6, [rsp+0x50]
00007f7c123dd1d4  vmovaps xmm7, [rsp+0x60]
00007f7c123dd1da  vmovaps xmm8, [rsp+0x70]
00007f7c123dd1e0  vmovaps xmm9, [rsp+0x80]
00007f7c123dd1e9  vmovaps xmm10, [rsp+0x90]
00007f7c123dd1f2  vmovaps xmm11, [rsp+0xA0]
00007f7c123dd1fb  vmovaps xmm12, [rsp+0xB0]
00007f7c123dd204  vmovaps xmm13, [rsp+0xC0]
00007f7c123dd20d  vmovaps xmm14, [rsp+0xD0]
00007f7c123dd216  vmovaps xmm15, [rsp+0xE0]
00007f7c123dd21f  add rsp, 0xF0
00007f7c123dd226  pop r11
00007f7c123dd228  pop r10
00007f7c123dd22a  pop r9
00007f7c123dd22c  pop r8
00007f7c123dd22e  pop rsi
00007f7c123dd22f  pop rdi
00007f7c123dd230  pop rdx
00007f7c123dd231  pop rcx
00007f7c123dd232  pop rax
00007f7c123dd233  add rsp, 0x08
00007f7c123dd237  jmp 0x00007F7C123DBC73
00007f7c123dd23c  sub rsp, 0x08
00007f7c123dd240  push rax
00007f7c123dd241  push rcx
00007f7c123dd242  push rdx
00007f7c123dd243  push rdi
00007f7c123dd244  push rsi
00007f7c123dd245  push r8
00007f7c123dd247  push r9
00007f7c123dd249  push r10
00007f7c123dd24b  push r11
00007f7c123dd24d  sub rsp, 0xF0
00007f7c123dd254  vmovaps [rsp], xmm0
00007f7c123dd259  vmovaps [rsp+0x10], xmm1
00007f7c123dd25f  vmovaps [rsp+0x20], xmm2
00007f7c123dd265  vmovaps [rsp+0x30], xmm3
00007f7c123dd26b  vmovaps [rsp+0x40], xmm5
00007f7c123dd271  vmovaps [rsp+0x50], xmm6
00007f7c123dd277  vmovaps [rsp+0x60], xmm7
00007f7c123dd27d  vmovaps [rsp+0x70], xmm8
00007f7c123dd283  vmovaps [rsp+0x80], xmm9
00007f7c123dd28c  vmovaps [rsp+0x90], xmm10
00007f7c123dd295  vmovaps [rsp+0xA0], xmm11
00007f7c123dd29e  vmovaps [rsp+0xB0], xmm12
00007f7c123dd2a7  vmovaps [rsp+0xC0], xmm13
00007f7c123dd2b0  vmovaps [rsp+0xD0], xmm14
00007f7c123dd2b9  vmovaps [rsp+0xE0], xmm15
00007f7c123dd2c2  sub rsp, 0x30
00007f7c123dd2c6  movaps [rsp], xmm4
00007f7c123dd2ca  movaps [rsp+0x10], xmm9
00007f7c123dd2d0  movaps [rsp+0x20], xmm8
00007f7c123dd2d6  lea rdi, [rsp]
00007f7c123dd2da  mov esi, 0x00
00007f7c123dd2df  mov rax, 0x5E723D793530
00007f7c123dd2e9  call rax
00007f7c123dd2eb  movaps xmm4, [rsp]
00007f7c123dd2ef  add rsp, 0x30
00007f7c123dd2f3  vmovaps xmm0, [rsp]
00007f7c123dd2f8  vmovaps xmm1, [rsp+0x10]
00007f7c123dd2fe  vmovaps xmm2, [rsp+0x20]
00007f7c123dd304  vmovaps xmm3, [rsp+0x30]
00007f7c123dd30a  vmovaps xmm5, [rsp+0x40]
00007f7c123dd310  vmovaps xmm6, [rsp+0x50]
00007f7c123dd316  vmovaps xmm7, [rsp+0x60]
00007f7c123dd31c  vmovaps xmm8, [rsp+0x70]
00007f7c123dd322  vmovaps xmm9, [rsp+0x80]
00007f7c123dd32b  vmovaps xmm10, [rsp+0x90]
00007f7c123dd334  vmovaps xmm11, [rsp+0xA0]
00007f7c123dd33d  vmovaps xmm12, [rsp+0xB0]
00007f7c123dd346  vmovaps xmm13, [rsp+0xC0]
00007f7c123dd34f  vmovaps xmm14, [rsp+0xD0]
00007f7c123dd358  vmovaps xmm15, [rsp+0xE0]
00007f7c123dd361  add rsp, 0xF0
00007f7c123dd368  pop r11
00007f7c123dd36a  pop r10
00007f7c123dd36c  pop r9
00007f7c123dd36e  pop r8
00007f7c123dd370  pop rsi
00007f7c123dd371  pop rdi
00007f7c123dd372  pop rdx
00007f7c123dd373  pop rcx
00007f7c123dd374  pop rax
00007f7c123dd375  add rsp, 0x08
00007f7c123dd379  jmp 0x00007F7C123DBC94
00007f7c123dd37e  sub rsp, 0x08
00007f7c123dd382  push rax
00007f7c123dd383  push rcx
00007f7c123dd384  push rdx
00007f7c123dd385  push rdi
00007f7c123dd386  push rsi
00007f7c123dd387  push r8
00007f7c123dd389  push r9
00007f7c123dd38b  push r10
00007f7c123dd38d  push r11
00007f7c123dd38f  sub rsp, 0xF0
00007f7c123dd396  vmovaps [rsp], xmm0
00007f7c123dd39b  vmovaps [rsp+0x10], xmm1
00007f7c123dd3a1  vmovaps [rsp+0x20], xmm2
00007f7c123dd3a7  vmovaps [rsp+0x30], xmm3
00007f7c123dd3ad  vmovaps [rsp+0x40], xmm4
00007f7c123dd3b3  vmovaps [rsp+0x50], xmm5
00007f7c123dd3b9  vmovaps [rsp+0x60], xmm6
00007f7c123dd3bf  vmovaps [rsp+0x70], xmm7
00007f7c123dd3c5  vmovaps [rsp+0x80], xmm8
00007f7c123dd3ce  vmovaps [rsp+0x90], xmm10
00007f7c123dd3d7  vmovaps [rsp+0xA0], xmm11
00007f7c123dd3e0  vmovaps [rsp+0xB0], xmm12
00007f7c123dd3e9  vmovaps [rsp+0xC0], xmm13
00007f7c123dd3f2  vmovaps [rsp+0xD0], xmm14
00007f7c123dd3fb  vmovaps [rsp+0xE0], xmm15
00007f7c123dd404  sub rsp, 0x30
00007f7c123dd408  movaps [rsp], xmm9
00007f7c123dd40d  movaps [rsp+0x10], xmm10
00007f7c123dd413  movaps [rsp+0x20], xmm8
00007f7c123dd419  lea rdi, [rsp]
00007f7c123dd41d  mov esi, 0x00
00007f7c123dd422  mov rax, 0x5E723D793530
00007f7c123dd42c  call rax
00007f7c123dd42e  movaps xmm9, [rsp]
00007f7c123dd433  add rsp, 0x30
00007f7c123dd437  vmovaps xmm0, [rsp]
00007f7c123dd43c  vmovaps xmm1, [rsp+0x10]
00007f7c123dd442  vmovaps xmm2, [rsp+0x20]
00007f7c123dd448  vmovaps xmm3, [rsp+0x30]
00007f7c123dd44e  vmovaps xmm4, [rsp+0x40]
00007f7c123dd454  vmovaps xmm5, [rsp+0x50]
00007f7c123dd45a  vmovaps xmm6, [rsp+0x60]
00007f7c123dd460  vmovaps xmm7, [rsp+0x70]
00007f7c123dd466  vmovaps xmm8, [rsp+0x80]
00007f7c123dd46f  vmovaps xmm10, [rsp+0x90]
00007f7c123dd478  vmovaps xmm11, [rsp+0xA0]
00007f7c123dd481  vmovaps xmm12, [rsp+0xB0]
00007f7c123dd48a  vmovaps xmm13, [rsp+0xC0]
00007f7c123dd493  vmovaps xmm14, [rsp+0xD0]
00007f7c123dd49c  vmovaps xmm15, [rsp+0xE0]
00007f7c123dd4a5  add rsp, 0xF0
00007f7c123dd4ac  pop r11
00007f7c123dd4ae  pop r10
00007f7c123dd4b0  pop r9
00007f7c123dd4b2  pop r8
00007f7c123dd4b4  pop rsi
00007f7c123dd4b5  pop rdi
00007f7c123dd4b6  pop rdx
00007f7c123dd4b7  pop rcx
00007f7c123dd4b8  pop rax
00007f7c123dd4b9  add rsp, 0x08
00007f7c123dd4bd  jmp 0x00007F7C123DBCAE
00007f7c123dd4c2  call 0x00007F7C122B52F0
00007f7c123dd4c7  jmp 0x00007F7C123DBDC8
00007f7c123dd4cc  call 0x00007F7C122B52F0
00007f7c123dd4d1  jmp 0x00007F7C123DBDDE
00007f7c123dd4d6  sub rsp, 0x08
00007f7c123dd4da  push rax
00007f7c123dd4db  push rcx
00007f7c123dd4dc  push rdx
00007f7c123dd4dd  push rdi
00007f7c123dd4de  push rsi
00007f7c123dd4df  push r8
00007f7c123dd4e1  push r9
00007f7c123dd4e3  push r10
00007f7c123dd4e5  push r11
00007f7c123dd4e7  sub rsp, 0xF0
00007f7c123dd4ee  vmovaps [rsp], xmm0
00007f7c123dd4f3  vmovaps [rsp+0x10], xmm2
00007f7c123dd4f9  vmovaps [rsp+0x20], xmm3
00007f7c123dd4ff  vmovaps [rsp+0x30], xmm4
00007f7c123dd505  vmovaps [rsp+0x40], xmm5
00007f7c123dd50b  vmovaps [rsp+0x50], xmm6
00007f7c123dd511  vmovaps [rsp+0x60], xmm7
00007f7c123dd517  vmovaps [rsp+0x70], xmm8
00007f7c123dd51d  vmovaps [rsp+0x80], xmm9
00007f7c123dd526  vmovaps [rsp+0x90], xmm10
00007f7c123dd52f  vmovaps [rsp+0xA0], xmm11
00007f7c123dd538  vmovaps [rsp+0xB0], xmm12
00007f7c123dd541  vmovaps [rsp+0xC0], xmm13
00007f7c123dd54a  vmovaps [rsp+0xD0], xmm14
00007f7c123dd553  vmovaps [rsp+0xE0], xmm15
00007f7c123dd55c  sub rsp, 0x30
00007f7c123dd560  movaps [rsp], xmm1
00007f7c123dd564  movaps [rsp+0x10], xmm6
00007f7c123dd569  movaps [rsp+0x20], xmm15
00007f7c123dd56f  lea rdi, [rsp]
00007f7c123dd573  mov esi, 0x00
00007f7c123dd578  mov rax, 0x5E723D793530
00007f7c123dd582  call rax
00007f7c123dd584  movaps xmm1, [rsp]
00007f7c123dd588  add rsp, 0x30
00007f7c123dd58c  vmovaps xmm0, [rsp]
00007f7c123dd591  vmovaps xmm2, [rsp+0x10]
00007f7c123dd597  vmovaps xmm3, [rsp+0x20]
00007f7c123dd59d  vmovaps xmm4, [rsp+0x30]
00007f7c123dd5a3  vmovaps xmm5, [rsp+0x40]
00007f7c123dd5a9  vmovaps xmm6, [rsp+0x50]
00007f7c123dd5af  vmovaps xmm7, [rsp+0x60]
00007f7c123dd5b5  vmovaps xmm8, [rsp+0x70]
00007f7c123dd5bb  vmovaps xmm9, [rsp+0x80]
00007f7c123dd5c4  vmovaps xmm10, [rsp+0x90]
00007f7c123dd5cd  vmovaps xmm11, [rsp+0xA0]
00007f7c123dd5d6  vmovaps xmm12, [rsp+0xB0]
00007f7c123dd5df  vmovaps xmm13, [rsp+0xC0]
00007f7c123dd5e8  vmovaps xmm14, [rsp+0xD0]
00007f7c123dd5f1  vmovaps xmm15, [rsp+0xE0]
00007f7c123dd5fa  add rsp, 0xF0
00007f7c123dd601  pop r11
00007f7c123dd603  pop r10
00007f7c123dd605  pop r9
00007f7c123dd607  pop r8
00007f7c123dd609  pop rsi
00007f7c123dd60a  pop rdi
00007f7c123dd60b  pop rdx
00007f7c123dd60c  pop rcx
00007f7c123dd60d  pop rax
00007f7c123dd60e  add rsp, 0x08
00007f7c123dd612  jmp 0x00007F7C123DBE1B
00007f7c123dd617  call 0x00007F7C122C4620
00007f7c123dd61c  jmp 0x00007F7C123DBE28
00007f7c123dd621  sub rsp, 0x08
00007f7c123dd625  push rax
00007f7c123dd626  push rcx
00007f7c123dd627  push rdx
00007f7c123dd628  push rdi
00007f7c123dd629  push rsi
00007f7c123dd62a  push r8
00007f7c123dd62c  push r9
00007f7c123dd62e  push r10
00007f7c123dd630  push r11
00007f7c123dd632  sub rsp, 0xF0
00007f7c123dd639  vmovaps [rsp], xmm0
00007f7c123dd63e  vmovaps [rsp+0x10], xmm1
00007f7c123dd644  vmovaps [rsp+0x20], xmm2
00007f7c123dd64a  vmovaps [rsp+0x30], xmm3
00007f7c123dd650  vmovaps [rsp+0x40], xmm4
00007f7c123dd656  vmovaps [rsp+0x50], xmm5
00007f7c123dd65c  vmovaps [rsp+0x60], xmm6
00007f7c123dd662  vmovaps [rsp+0x70], xmm7
00007f7c123dd668  vmovaps [rsp+0x80], xmm8
00007f7c123dd671  vmovaps [rsp+0x90], xmm9
00007f7c123dd67a  vmovaps [rsp+0xA0], xmm10
00007f7c123dd683  vmovaps [rsp+0xB0], xmm11
00007f7c123dd68c  vmovaps [rsp+0xC0], xmm12
00007f7c123dd695  vmovaps [rsp+0xD0], xmm13
00007f7c123dd69e  vmovaps [rsp+0xE0], xmm15
00007f7c123dd6a7  sub rsp, 0x30
00007f7c123dd6ab  movaps [rsp], xmm14
00007f7c123dd6b0  movaps [rsp+0x10], xmm4
00007f7c123dd6b5  movaps [rsp+0x20], xmm3
00007f7c123dd6ba  lea rdi, [rsp]
00007f7c123dd6be  mov esi, 0x00
00007f7c123dd6c3  mov rax, 0x5E723D793530
00007f7c123dd6cd  call rax
00007f7c123dd6cf  movaps xmm14, [rsp]
00007f7c123dd6d4  add rsp, 0x30
00007f7c123dd6d8  vmovaps xmm0, [rsp]
00007f7c123dd6dd  vmovaps xmm1, [rsp+0x10]
00007f7c123dd6e3  vmovaps xmm2, [rsp+0x20]
00007f7c123dd6e9  vmovaps xmm3, [rsp+0x30]
00007f7c123dd6ef  vmovaps xmm4, [rsp+0x40]
00007f7c123dd6f5  vmovaps xmm5, [rsp+0x50]
00007f7c123dd6fb  vmovaps xmm6, [rsp+0x60]
00007f7c123dd701  vmovaps xmm7, [rsp+0x70]
00007f7c123dd707  vmovaps xmm8, [rsp+0x80]
00007f7c123dd710  vmovaps xmm9, [rsp+0x90]
00007f7c123dd719  vmovaps xmm10, [rsp+0xA0]
00007f7c123dd722  vmovaps xmm11, [rsp+0xB0]
00007f7c123dd72b  vmovaps xmm12, [rsp+0xC0]
00007f7c123dd734  vmovaps xmm13, [rsp+0xD0]
00007f7c123dd73d  vmovaps xmm15, [rsp+0xE0]
00007f7c123dd746  add rsp, 0xF0
00007f7c123dd74d  pop r11
00007f7c123dd74f  pop r10
00007f7c123dd751  pop r9
00007f7c123dd753  pop r8
00007f7c123dd755  pop rsi
00007f7c123dd756  pop rdi
00007f7c123dd757  pop rdx
00007f7c123dd758  pop rcx
00007f7c123dd759  pop rax
00007f7c123dd75a  add rsp, 0x08
00007f7c123dd75e  jmp 0x00007F7C123DBE42
00007f7c123dd763  sub rsp, 0x08
00007f7c123dd767  push rax
00007f7c123dd768  push rcx
00007f7c123dd769  push rdx
00007f7c123dd76a  push rdi
00007f7c123dd76b  push rsi
00007f7c123dd76c  push r8
00007f7c123dd76e  push r9
00007f7c123dd770  push r10
00007f7c123dd772  push r11
00007f7c123dd774  sub rsp, 0xF0
00007f7c123dd77b  vmovaps [rsp], xmm0
00007f7c123dd780  vmovaps [rsp+0x10], xmm1
00007f7c123dd786  vmovaps [rsp+0x20], xmm2
00007f7c123dd78c  vmovaps [rsp+0x30], xmm3
00007f7c123dd792  vmovaps [rsp+0x40], xmm4
00007f7c123dd798  vmovaps [rsp+0x50], xmm5
00007f7c123dd79e  vmovaps [rsp+0x60], xmm7
00007f7c123dd7a4  vmovaps [rsp+0x70], xmm8
00007f7c123dd7aa  vmovaps [rsp+0x80], xmm9
00007f7c123dd7b3  vmovaps [rsp+0x90], xmm10
00007f7c123dd7bc  vmovaps [rsp+0xA0], xmm11
00007f7c123dd7c5  vmovaps [rsp+0xB0], xmm12
00007f7c123dd7ce  vmovaps [rsp+0xC0], xmm13
00007f7c123dd7d7  vmovaps [rsp+0xD0], xmm14
00007f7c123dd7e0  vmovaps [rsp+0xE0], xmm15
00007f7c123dd7e9  sub rsp, 0x30
00007f7c123dd7ed  movaps [rsp], xmm6
00007f7c123dd7f1  movaps [rsp+0x10], xmm9
00007f7c123dd7f7  movaps [rsp+0x20], xmm7
00007f7c123dd7fc  lea rdi, [rsp]
00007f7c123dd800  mov esi, 0x00
00007f7c123dd805  mov rax, 0x5E723D793530
00007f7c123dd80f  call rax
00007f7c123dd811  movaps xmm6, [rsp]
00007f7c123dd815  add rsp, 0x30
00007f7c123dd819  vmovaps xmm0, [rsp]
00007f7c123dd81e  vmovaps xmm1, [rsp+0x10]
00007f7c123dd824  vmovaps xmm2, [rsp+0x20]
00007f7c123dd82a  vmovaps xmm3, [rsp+0x30]
00007f7c123dd830  vmovaps xmm4, [rsp+0x40]
00007f7c123dd836  vmovaps xmm5, [rsp+0x50]
00007f7c123dd83c  vmovaps xmm7, [rsp+0x60]
00007f7c123dd842  vmovaps xmm8, [rsp+0x70]
00007f7c123dd848  vmovaps xmm9, [rsp+0x80]
00007f7c123dd851  vmovaps xmm10, [rsp+0x90]
00007f7c123dd85a  vmovaps xmm11, [rsp+0xA0]
00007f7c123dd863  vmovaps xmm12, [rsp+0xB0]
00007f7c123dd86c  vmovaps xmm13, [rsp+0xC0]
00007f7c123dd875  vmovaps xmm14, [rsp+0xD0]
00007f7c123dd87e  vmovaps xmm15, [rsp+0xE0]
00007f7c123dd887  add rsp, 0xF0
00007f7c123dd88e  pop r11
00007f7c123dd890  pop r10
00007f7c123dd892  pop r9
00007f7c123dd894  pop r8
00007f7c123dd896  pop rsi
00007f7c123dd897  pop rdi
00007f7c123dd898  pop rdx
00007f7c123dd899  pop rcx
00007f7c123dd89a  pop rax
00007f7c123dd89b  add rsp, 0x08
00007f7c123dd89f  jmp 0x00007F7C123DBE5A
00007f7c123dd8a4  sub rsp, 0x08
00007f7c123dd8a8  push rax
00007f7c123dd8a9  push rcx
00007f7c123dd8aa  push rdx
00007f7c123dd8ab  push rdi
00007f7c123dd8ac  push rsi
00007f7c123dd8ad  push r8
00007f7c123dd8af  push r9
00007f7c123dd8b1  push r10
00007f7c123dd8b3  push r11
00007f7c123dd8b5  sub rsp, 0xF0
00007f7c123dd8bc  vmovaps [rsp], xmm0
00007f7c123dd8c1  vmovaps [rsp+0x10], xmm1
00007f7c123dd8c7  vmovaps [rsp+0x20], xmm2
00007f7c123dd8cd  vmovaps [rsp+0x30], xmm3
00007f7c123dd8d3  vmovaps [rsp+0x40], xmm4
00007f7c123dd8d9  vmovaps [rsp+0x50], xmm5
00007f7c123dd8df  vmovaps [rsp+0x60], xmm6
00007f7c123dd8e5  vmovaps [rsp+0x70], xmm8
00007f7c123dd8eb  vmovaps [rsp+0x80], xmm9
00007f7c123dd8f4  vmovaps [rsp+0x90], xmm10
00007f7c123dd8fd  vmovaps [rsp+0xA0], xmm11
00007f7c123dd906  vmovaps [rsp+0xB0], xmm12
00007f7c123dd90f  vmovaps [rsp+0xC0], xmm13
00007f7c123dd918  vmovaps [rsp+0xD0], xmm14
00007f7c123dd921  vmovaps [rsp+0xE0], xmm15
00007f7c123dd92a  sub rsp, 0x30
00007f7c123dd92e  movaps [rsp], xmm7
00007f7c123dd932  movaps [rsp+0x10], xmm4
00007f7c123dd937  movaps [rsp+0x20], xmm9
00007f7c123dd93d  lea rdi, [rsp]
00007f7c123dd941  mov esi, 0x00
00007f7c123dd946  mov rax, 0x5E723D793530
00007f7c123dd950  call rax
00007f7c123dd952  movaps xmm7, [rsp]
00007f7c123dd956  add rsp, 0x30
00007f7c123dd95a  vmovaps xmm0, [rsp]
00007f7c123dd95f  vmovaps xmm1, [rsp+0x10]
00007f7c123dd965  vmovaps xmm2, [rsp+0x20]
00007f7c123dd96b  vmovaps xmm3, [rsp+0x30]
00007f7c123dd971  vmovaps xmm4, [rsp+0x40]
00007f7c123dd977  vmovaps xmm5, [rsp+0x50]
00007f7c123dd97d  vmovaps xmm6, [rsp+0x60]
00007f7c123dd983  vmovaps xmm8, [rsp+0x70]
00007f7c123dd989  vmovaps xmm9, [rsp+0x80]
00007f7c123dd992  vmovaps xmm10, [rsp+0x90]
00007f7c123dd99b  vmovaps xmm11, [rsp+0xA0]
00007f7c123dd9a4  vmovaps xmm12, [rsp+0xB0]
00007f7c123dd9ad  vmovaps xmm13, [rsp+0xC0]
00007f7c123dd9b6  vmovaps xmm14, [rsp+0xD0]
00007f7c123dd9bf  vmovaps xmm15, [rsp+0xE0]
00007f7c123dd9c8  add rsp, 0xF0
00007f7c123dd9cf  pop r11
00007f7c123dd9d1  pop r10
00007f7c123dd9d3  pop r9
00007f7c123dd9d5  pop r8
00007f7c123dd9d7  pop rsi
00007f7c123dd9d8  pop rdi
00007f7c123dd9d9  pop rdx
00007f7c123dd9da  pop rcx
00007f7c123dd9db  pop rax
00007f7c123dd9dc  add rsp, 0x08
00007f7c123dd9e0  jmp 0x00007F7C123DBE87
00007f7c123dd9e5  sub rsp, 0x08
00007f7c123dd9e9  push rax
00007f7c123dd9ea  push rcx
00007f7c123dd9eb  push rdx
00007f7c123dd9ec  push rdi
00007f7c123dd9ed  push rsi
00007f7c123dd9ee  push r8
00007f7c123dd9f0  push r9
00007f7c123dd9f2  push r10
00007f7c123dd9f4  push r11
00007f7c123dd9f6  sub rsp, 0xF0
00007f7c123dd9fd  vmovaps [rsp], xmm0
00007f7c123dda02  vmovaps [rsp+0x10], xmm1
00007f7c123dda08  vmovaps [rsp+0x20], xmm2
00007f7c123dda0e  vmovaps [rsp+0x30], xmm3
00007f7c123dda14  vmovaps [rsp+0x40], xmm5
00007f7c123dda1a  vmovaps [rsp+0x50], xmm6
00007f7c123dda20  vmovaps [rsp+0x60], xmm7
00007f7c123dda26  vmovaps [rsp+0x70], xmm8
00007f7c123dda2c  vmovaps [rsp+0x80], xmm9
00007f7c123dda35  vmovaps [rsp+0x90], xmm10
00007f7c123dda3e  vmovaps [rsp+0xA0], xmm11
00007f7c123dda47  vmovaps [rsp+0xB0], xmm12
00007f7c123dda50  vmovaps [rsp+0xC0], xmm13
00007f7c123dda59  vmovaps [rsp+0xD0], xmm14
00007f7c123dda62  vmovaps [rsp+0xE0], xmm15
00007f7c123dda6b  sub rsp, 0x30
00007f7c123dda6f  movaps [rsp], xmm4
00007f7c123dda73  movaps [rsp+0x10], xmm15
00007f7c123dda79  movaps [rsp+0x20], xmm9
00007f7c123dda7f  lea rdi, [rsp]
00007f7c123dda83  mov esi, 0x00
00007f7c123dda88  mov rax, 0x5E723D793530
00007f7c123dda92  call rax
00007f7c123dda94  movaps xmm4, [rsp]
00007f7c123dda98  add rsp, 0x30
00007f7c123dda9c  vmovaps xmm0, [rsp]
00007f7c123ddaa1  vmovaps xmm1, [rsp+0x10]
00007f7c123ddaa7  vmovaps xmm2, [rsp+0x20]
00007f7c123ddaad  vmovaps xmm3, [rsp+0x30]
00007f7c123ddab3  vmovaps xmm5, [rsp+0x40]
00007f7c123ddab9  vmovaps xmm6, [rsp+0x50]
00007f7c123ddabf  vmovaps xmm7, [rsp+0x60]
00007f7c123ddac5  vmovaps xmm8, [rsp+0x70]
00007f7c123ddacb  vmovaps xmm9, [rsp+0x80]
00007f7c123ddad4  vmovaps xmm10, [rsp+0x90]
00007f7c123ddadd  vmovaps xmm11, [rsp+0xA0]
00007f7c123ddae6  vmovaps xmm12, [rsp+0xB0]
00007f7c123ddaef  vmovaps xmm13, [rsp+0xC0]
00007f7c123ddaf8  vmovaps xmm14, [rsp+0xD0]
00007f7c123ddb01  vmovaps xmm15, [rsp+0xE0]
00007f7c123ddb0a  add rsp, 0xF0
00007f7c123ddb11  pop r11
00007f7c123ddb13  pop r10
00007f7c123ddb15  pop r9
00007f7c123ddb17  pop r8
00007f7c123ddb19  pop rsi
00007f7c123ddb1a  pop rdi
00007f7c123ddb1b  pop rdx
00007f7c123ddb1c  pop rcx
00007f7c123ddb1d  pop rax
00007f7c123ddb1e  add rsp, 0x08
00007f7c123ddb22  jmp 0x00007F7C123DBEAC
00007f7c123ddb27  call 0x00007F7C122C4620
00007f7c123ddb2c  jmp 0x00007F7C123DBEB9
00007f7c123ddb31  sub rsp, 0x08
00007f7c123ddb35  push rax
00007f7c123ddb36  push rcx
00007f7c123ddb37  push rdx
00007f7c123ddb38  push rdi
00007f7c123ddb39  push rsi
00007f7c123ddb3a  push r8
00007f7c123ddb3c  push r9
00007f7c123ddb3e  push r10
00007f7c123ddb40  push r11
00007f7c123ddb42  sub rsp, 0xF0
00007f7c123ddb49  vmovaps [rsp], xmm0
00007f7c123ddb4e  vmovaps [rsp+0x10], xmm1
00007f7c123ddb54  vmovaps [rsp+0x20], xmm2
00007f7c123ddb5a  vmovaps [rsp+0x30], xmm4
00007f7c123ddb60  vmovaps [rsp+0x40], xmm5
00007f7c123ddb66  vmovaps [rsp+0x50], xmm6
00007f7c123ddb6c  vmovaps [rsp+0x60], xmm7
00007f7c123ddb72  vmovaps [rsp+0x70], xmm8
00007f7c123ddb78  vmovaps [rsp+0x80], xmm9
00007f7c123ddb81  vmovaps [rsp+0x90], xmm10
00007f7c123ddb8a  vmovaps [rsp+0xA0], xmm11
00007f7c123ddb93  vmovaps [rsp+0xB0], xmm12
00007f7c123ddb9c  vmovaps [rsp+0xC0], xmm13
00007f7c123ddba5  vmovaps [rsp+0xD0], xmm14
00007f7c123ddbae  vmovaps [rsp+0xE0], xmm15
00007f7c123ddbb7  sub rsp, 0x30
00007f7c123ddbbb  movaps [rsp], xmm3
00007f7c123ddbbf  movaps [rsp+0x10], xmm1
00007f7c123ddbc4  movaps [rsp+0x20], xmm9
00007f7c123ddbca  lea rdi, [rsp]
00007f7c123ddbce  mov esi, 0x00
00007f7c123ddbd3  mov rax, 0x5E723D793530
00007f7c123ddbdd  call rax
00007f7c123ddbdf  movaps xmm3, [rsp]
00007f7c123ddbe3  add rsp, 0x30
00007f7c123ddbe7  vmovaps xmm0, [rsp]
00007f7c123ddbec  vmovaps xmm1, [rsp+0x10]
00007f7c123ddbf2  vmovaps xmm2, [rsp+0x20]
00007f7c123ddbf8  vmovaps xmm4, [rsp+0x30]
00007f7c123ddbfe  vmovaps xmm5, [rsp+0x40]
00007f7c123ddc04  vmovaps xmm6, [rsp+0x50]
00007f7c123ddc0a  vmovaps xmm7, [rsp+0x60]
00007f7c123ddc10  vmovaps xmm8, [rsp+0x70]
00007f7c123ddc16  vmovaps xmm9, [rsp+0x80]
00007f7c123ddc1f  vmovaps xmm10, [rsp+0x90]
00007f7c123ddc28  vmovaps xmm11, [rsp+0xA0]
00007f7c123ddc31  vmovaps xmm12, [rsp+0xB0]
00007f7c123ddc3a  vmovaps xmm13, [rsp+0xC0]
00007f7c123ddc43  vmovaps xmm14, [rsp+0xD0]
00007f7c123ddc4c  vmovaps xmm15, [rsp+0xE0]
00007f7c123ddc55  add rsp, 0xF0
00007f7c123ddc5c  pop r11
00007f7c123ddc5e  pop r10
00007f7c123ddc60  pop r9
00007f7c123ddc62  pop r8
00007f7c123ddc64  pop rsi
00007f7c123ddc65  pop rdi
00007f7c123ddc66  pop rdx
00007f7c123ddc67  pop rcx
00007f7c123ddc68  pop rax
00007f7c123ddc69  add rsp, 0x08
00007f7c123ddc6d  jmp 0x00007F7C123DBEF6
00007f7c123ddc72  sub rsp, 0x08
00007f7c123ddc76  push rax
00007f7c123ddc77  push rcx
00007f7c123ddc78  push rdx
00007f7c123ddc79  push rdi
00007f7c123ddc7a  push rsi
00007f7c123ddc7b  push r8
00007f7c123ddc7d  push r9
00007f7c123ddc7f  push r10
00007f7c123ddc81  push r11
00007f7c123ddc83  sub rsp, 0xF0
00007f7c123ddc8a  vmovaps [rsp], xmm0
00007f7c123ddc8f  vmovaps [rsp+0x10], xmm2
00007f7c123ddc95  vmovaps [rsp+0x20], xmm3
00007f7c123ddc9b  vmovaps [rsp+0x30], xmm4
00007f7c123ddca1  vmovaps [rsp+0x40], xmm5
00007f7c123ddca7  vmovaps [rsp+0x50], xmm6
00007f7c123ddcad  vmovaps [rsp+0x60], xmm7
00007f7c123ddcb3  vmovaps [rsp+0x70], xmm8
00007f7c123ddcb9  vmovaps [rsp+0x80], xmm9
00007f7c123ddcc2  vmovaps [rsp+0x90], xmm10
00007f7c123ddccb  vmovaps [rsp+0xA0], xmm11
00007f7c123ddcd4  vmovaps [rsp+0xB0], xmm12
00007f7c123ddcdd  vmovaps [rsp+0xC0], xmm13
00007f7c123ddce6  vmovaps [rsp+0xD0], xmm14
00007f7c123ddcef  vmovaps [rsp+0xE0], xmm15
00007f7c123ddcf8  sub rsp, 0x30
00007f7c123ddcfc  movaps [rsp], xmm1
00007f7c123ddd00  movaps [rsp+0x10], xmm15
00007f7c123ddd06  movaps [rsp+0x20], xmm9
00007f7c123ddd0c  lea rdi, [rsp]
00007f7c123ddd10  mov esi, 0x00
00007f7c123ddd15  mov rax, 0x5E723D793530
00007f7c123ddd1f  call rax
00007f7c123ddd21  movaps xmm1, [rsp]
00007f7c123ddd25  add rsp, 0x30
00007f7c123ddd29  vmovaps xmm0, [rsp]
00007f7c123ddd2e  vmovaps xmm2, [rsp+0x10]
00007f7c123ddd34  vmovaps xmm3, [rsp+0x20]
00007f7c123ddd3a  vmovaps xmm4, [rsp+0x30]
00007f7c123ddd40  vmovaps xmm5, [rsp+0x40]
00007f7c123ddd46  vmovaps xmm6, [rsp+0x50]
00007f7c123ddd4c  vmovaps xmm7, [rsp+0x60]
00007f7c123ddd52  vmovaps xmm8, [rsp+0x70]
00007f7c123ddd58  vmovaps xmm9, [rsp+0x80]
00007f7c123ddd61  vmovaps xmm10, [rsp+0x90]
00007f7c123ddd6a  vmovaps xmm11, [rsp+0xA0]
00007f7c123ddd73  vmovaps xmm12, [rsp+0xB0]
00007f7c123ddd7c  vmovaps xmm13, [rsp+0xC0]
00007f7c123ddd85  vmovaps xmm14, [rsp+0xD0]
00007f7c123ddd8e  vmovaps xmm15, [rsp+0xE0]
00007f7c123ddd97  add rsp, 0xF0
00007f7c123ddd9e  pop r11
00007f7c123ddda0  pop r10
00007f7c123ddda2  pop r9
00007f7c123ddda4  pop r8
00007f7c123ddda6  pop rsi
00007f7c123ddda7  pop rdi
00007f7c123ddda8  pop rdx
00007f7c123ddda9  pop rcx
00007f7c123dddaa  pop rax
00007f7c123dddab  add rsp, 0x08
00007f7c123dddaf  jmp 0x00007F7C123DBF7E
00007f7c123dddb4  call 0x00007F7C122C4620
00007f7c123dddb9  jmp 0x00007F7C123DBF8B
00007f7c123dddbe  sub rsp, 0x08
00007f7c123dddc2  push rax
00007f7c123dddc3  push rcx
00007f7c123dddc4  push rdx
00007f7c123dddc5  push rdi
00007f7c123dddc6  push rsi
00007f7c123dddc7  push r8
00007f7c123dddc9  push r9
00007f7c123dddcb  push r10
00007f7c123dddcd  push r11
00007f7c123dddcf  sub rsp, 0xF0
00007f7c123dddd6  vmovaps [rsp], xmm0
00007f7c123ddddb  vmovaps [rsp+0x10], xmm2
00007f7c123ddde1  vmovaps [rsp+0x20], xmm3
00007f7c123ddde7  vmovaps [rsp+0x30], xmm4
00007f7c123ddded  vmovaps [rsp+0x40], xmm5
00007f7c123dddf3  vmovaps [rsp+0x50], xmm6
00007f7c123dddf9  vmovaps [rsp+0x60], xmm7
00007f7c123dddff  vmovaps [rsp+0x70], xmm8
00007f7c123dde05  vmovaps [rsp+0x80], xmm9
00007f7c123dde0e  vmovaps [rsp+0x90], xmm10
00007f7c123dde17  vmovaps [rsp+0xA0], xmm11
00007f7c123dde20  vmovaps [rsp+0xB0], xmm12
00007f7c123dde29  vmovaps [rsp+0xC0], xmm13
00007f7c123dde32  vmovaps [rsp+0xD0], xmm14
00007f7c123dde3b  vmovaps [rsp+0xE0], xmm15
00007f7c123dde44  sub rsp, 0x30
00007f7c123dde48  movaps [rsp], xmm1
00007f7c123dde4c  movaps [rsp+0x10], xmm5
00007f7c123dde51  movaps [rsp+0x20], xmm7
00007f7c123dde56  lea rdi, [rsp]
00007f7c123dde5a  mov esi, 0x00
00007f7c123dde5f  mov rax, 0x5E723D793530
00007f7c123dde69  call rax
00007f7c123dde6b  movaps xmm1, [rsp]
00007f7c123dde6f  add rsp, 0x30
00007f7c123dde73  vmovaps xmm0, [rsp]
00007f7c123dde78  vmovaps xmm2, [rsp+0x10]
00007f7c123dde7e  vmovaps xmm3, [rsp+0x20]
00007f7c123dde84  vmovaps xmm4, [rsp+0x30]
00007f7c123dde8a  vmovaps xmm5, [rsp+0x40]
00007f7c123dde90  vmovaps xmm6, [rsp+0x50]
00007f7c123dde96  vmovaps xmm7, [rsp+0x60]
00007f7c123dde9c  vmovaps xmm8, [rsp+0x70]
00007f7c123ddea2  vmovaps xmm9, [rsp+0x80]
00007f7c123ddeab  vmovaps xmm10, [rsp+0x90]
00007f7c123ddeb4  vmovaps xmm11, [rsp+0xA0]
00007f7c123ddebd  vmovaps xmm12, [rsp+0xB0]
00007f7c123ddec6  vmovaps xmm13, [rsp+0xC0]
00007f7c123ddecf  vmovaps xmm14, [rsp+0xD0]
00007f7c123dded8  vmovaps xmm15, [rsp+0xE0]
00007f7c123ddee1  add rsp, 0xF0
00007f7c123ddee8  pop r11
00007f7c123ddeea  pop r10
00007f7c123ddeec  pop r9
00007f7c123ddeee  pop r8
00007f7c123ddef0  pop rsi
00007f7c123ddef1  pop rdi
00007f7c123ddef2  pop rdx
00007f7c123ddef3  pop rcx
00007f7c123ddef4  pop rax
00007f7c123ddef5  add rsp, 0x08
00007f7c123ddef9  jmp 0x00007F7C123DC030
00007f7c123ddefe  sub rsp, 0x08
00007f7c123ddf02  push rax
00007f7c123ddf03  push rcx
00007f7c123ddf04  push rdx
00007f7c123ddf05  push rdi
00007f7c123ddf06  push rsi
00007f7c123ddf07  push r8
00007f7c123ddf09  push r9
00007f7c123ddf0b  push r10
00007f7c123ddf0d  push r11
00007f7c123ddf0f  sub rsp, 0xF0
00007f7c123ddf16  vmovaps [rsp], xmm0
00007f7c123ddf1b  vmovaps [rsp+0x10], xmm1
00007f7c123ddf21  vmovaps [rsp+0x20], xmm2
00007f7c123ddf27  vmovaps [rsp+0x30], xmm3
00007f7c123ddf2d  vmovaps [rsp+0x40], xmm4
00007f7c123ddf33  vmovaps [rsp+0x50], xmm5
00007f7c123ddf39  vmovaps [rsp+0x60], xmm6
00007f7c123ddf3f  vmovaps [rsp+0x70], xmm8
00007f7c123ddf45  vmovaps [rsp+0x80], xmm9
00007f7c123ddf4e  vmovaps [rsp+0x90], xmm10
00007f7c123ddf57  vmovaps [rsp+0xA0], xmm11
00007f7c123ddf60  vmovaps [rsp+0xB0], xmm12
00007f7c123ddf69  vmovaps [rsp+0xC0], xmm13
00007f7c123ddf72  vmovaps [rsp+0xD0], xmm14
00007f7c123ddf7b  vmovaps [rsp+0xE0], xmm15
00007f7c123ddf84  sub rsp, 0x30
00007f7c123ddf88  movaps [rsp], xmm7
00007f7c123ddf8c  movaps [rsp+0x10], xmm5
00007f7c123ddf91  movaps [rsp+0x20], xmm15
00007f7c123ddf97  lea rdi, [rsp]
00007f7c123ddf9b  mov esi, 0x00
00007f7c123ddfa0  mov rax, 0x5E723D793530
00007f7c123ddfaa  call rax
00007f7c123ddfac  movaps xmm7, [rsp]
00007f7c123ddfb0  add rsp, 0x30
00007f7c123ddfb4  vmovaps xmm0, [rsp]
00007f7c123ddfb9  vmovaps xmm1, [rsp+0x10]
00007f7c123ddfbf  vmovaps xmm2, [rsp+0x20]
00007f7c123ddfc5  vmovaps xmm3, [rsp+0x30]
00007f7c123ddfcb  vmovaps xmm4, [rsp+0x40]
00007f7c123ddfd1  vmovaps xmm5, [rsp+0x50]
00007f7c123ddfd7  vmovaps xmm6, [rsp+0x60]
00007f7c123ddfdd  vmovaps xmm8, [rsp+0x70]
00007f7c123ddfe3  vmovaps xmm9, [rsp+0x80]
00007f7c123ddfec  vmovaps xmm10, [rsp+0x90]
00007f7c123ddff5  vmovaps xmm11, [rsp+0xA0]
00007f7c123ddffe  vmovaps xmm12, [rsp+0xB0]
00007f7c123de007  vmovaps xmm13, [rsp+0xC0]
00007f7c123de010  vmovaps xmm14, [rsp+0xD0]
00007f7c123de019  vmovaps xmm15, [rsp+0xE0]
00007f7c123de022  add rsp, 0xF0
00007f7c123de029  pop r11
00007f7c123de02b  pop r10
00007f7c123de02d  pop r9
00007f7c123de02f  pop r8
00007f7c123de031  pop rsi
00007f7c123de032  pop rdi
00007f7c123de033  pop rdx
00007f7c123de034  pop rcx
00007f7c123de035  pop rax
00007f7c123de036  add rsp, 0x08
00007f7c123de03a  jmp 0x00007F7C123DC066
00007f7c123de03f  call 0x00007F7C122B52F0
00007f7c123de044  jmp 0x00007F7C123DC073
00007f7c123de049  sub rsp, 0x08
00007f7c123de04d  push rax
00007f7c123de04e  push rcx
00007f7c123de04f  push rdx
00007f7c123de050  push rdi
00007f7c123de051  push rsi
00007f7c123de052  push r8
00007f7c123de054  push r9
00007f7c123de056  push r10
00007f7c123de058  push r11
00007f7c123de05a  sub rsp, 0xF0
00007f7c123de061  vmovaps [rsp], xmm0
00007f7c123de066  vmovaps [rsp+0x10], xmm1
00007f7c123de06c  vmovaps [rsp+0x20], xmm2
00007f7c123de072  vmovaps [rsp+0x30], xmm3
00007f7c123de078  vmovaps [rsp+0x40], xmm4
00007f7c123de07e  vmovaps [rsp+0x50], xmm5
00007f7c123de084  vmovaps [rsp+0x60], xmm6
00007f7c123de08a  vmovaps [rsp+0x70], xmm7
00007f7c123de090  vmovaps [rsp+0x80], xmm8
00007f7c123de099  vmovaps [rsp+0x90], xmm9
00007f7c123de0a2  vmovaps [rsp+0xA0], xmm10
00007f7c123de0ab  vmovaps [rsp+0xB0], xmm11
00007f7c123de0b4  vmovaps [rsp+0xC0], xmm12
00007f7c123de0bd  vmovaps [rsp+0xD0], xmm13
00007f7c123de0c6  vmovaps [rsp+0xE0], xmm14
00007f7c123de0cf  sub rsp, 0x30
00007f7c123de0d3  movaps [rsp], xmm15
00007f7c123de0d8  movaps [rsp+0x10], xmm5
00007f7c123de0dd  movaps [rsp+0x20], xmm3
00007f7c123de0e2  lea rdi, [rsp]
00007f7c123de0e6  mov esi, 0x00
00007f7c123de0eb  mov rax, 0x5E723D793530
00007f7c123de0f5  call rax
00007f7c123de0f7  movaps xmm15, [rsp]
00007f7c123de0fc  add rsp, 0x30
00007f7c123de100  vmovaps xmm0, [rsp]
00007f7c123de105  vmovaps xmm1, [rsp+0x10]
00007f7c123de10b  vmovaps xmm2, [rsp+0x20]
00007f7c123de111  vmovaps xmm3, [rsp+0x30]
00007f7c123de117  vmovaps xmm4, [rsp+0x40]
00007f7c123de11d  vmovaps xmm5, [rsp+0x50]
00007f7c123de123  vmovaps xmm6, [rsp+0x60]
00007f7c123de129  vmovaps xmm7, [rsp+0x70]
00007f7c123de12f  vmovaps xmm8, [rsp+0x80]
00007f7c123de138  vmovaps xmm9, [rsp+0x90]
00007f7c123de141  vmovaps xmm10, [rsp+0xA0]
00007f7c123de14a  vmovaps xmm11, [rsp+0xB0]
00007f7c123de153  vmovaps xmm12, [rsp+0xC0]
00007f7c123de15c  vmovaps xmm13, [rsp+0xD0]
00007f7c123de165  vmovaps xmm14, [rsp+0xE0]
00007f7c123de16e  add rsp, 0xF0
00007f7c123de175  pop r11
00007f7c123de177  pop r10
00007f7c123de179  pop r9
00007f7c123de17b  pop r8
00007f7c123de17d  pop rsi
00007f7c123de17e  pop rdi
00007f7c123de17f  pop rdx
00007f7c123de180  pop rcx
00007f7c123de181  pop rax
00007f7c123de182  add rsp, 0x08
00007f7c123de186  jmp 0x00007F7C123DC099
00007f7c123de18b  sub rsp, 0x08
00007f7c123de18f  push rax
00007f7c123de190  push rcx
00007f7c123de191  push rdx
00007f7c123de192  push rdi
00007f7c123de193  push rsi
00007f7c123de194  push r8
00007f7c123de196  push r9
00007f7c123de198  push r10
00007f7c123de19a  push r11
00007f7c123de19c  sub rsp, 0xF0
00007f7c123de1a3  vmovaps [rsp], xmm0
00007f7c123de1a8  vmovaps [rsp+0x10], xmm2
00007f7c123de1ae  vmovaps [rsp+0x20], xmm3
00007f7c123de1b4  vmovaps [rsp+0x30], xmm4
00007f7c123de1ba  vmovaps [rsp+0x40], xmm5
00007f7c123de1c0  vmovaps [rsp+0x50], xmm6
00007f7c123de1c6  vmovaps [rsp+0x60], xmm7
00007f7c123de1cc  vmovaps [rsp+0x70], xmm8
00007f7c123de1d2  vmovaps [rsp+0x80], xmm9
00007f7c123de1db  vmovaps [rsp+0x90], xmm10
00007f7c123de1e4  vmovaps [rsp+0xA0], xmm11
00007f7c123de1ed  vmovaps [rsp+0xB0], xmm12
00007f7c123de1f6  vmovaps [rsp+0xC0], xmm13
00007f7c123de1ff  vmovaps [rsp+0xD0], xmm14
00007f7c123de208  vmovaps [rsp+0xE0], xmm15
00007f7c123de211  sub rsp, 0x30
00007f7c123de215  movaps [rsp], xmm1
00007f7c123de219  movaps [rsp+0x10], xmm5
00007f7c123de21e  movaps [rsp+0x20], xmm4
00007f7c123de223  lea rdi, [rsp]
00007f7c123de227  mov esi, 0x00
00007f7c123de22c  mov rax, 0x5E723D793530
00007f7c123de236  call rax
00007f7c123de238  movaps xmm1, [rsp]
00007f7c123de23c  add rsp, 0x30
00007f7c123de240  vmovaps xmm0, [rsp]
00007f7c123de245  vmovaps xmm2, [rsp+0x10]
00007f7c123de24b  vmovaps xmm3, [rsp+0x20]
00007f7c123de251  vmovaps xmm4, [rsp+0x30]
00007f7c123de257  vmovaps xmm5, [rsp+0x40]
00007f7c123de25d  vmovaps xmm6, [rsp+0x50]
00007f7c123de263  vmovaps xmm7, [rsp+0x60]
00007f7c123de269  vmovaps xmm8, [rsp+0x70]
00007f7c123de26f  vmovaps xmm9, [rsp+0x80]
00007f7c123de278  vmovaps xmm10, [rsp+0x90]
00007f7c123de281  vmovaps xmm11, [rsp+0xA0]
00007f7c123de28a  vmovaps xmm12, [rsp+0xB0]
00007f7c123de293  vmovaps xmm13, [rsp+0xC0]
00007f7c123de29c  vmovaps xmm14, [rsp+0xD0]
00007f7c123de2a5  vmovaps xmm15, [rsp+0xE0]
00007f7c123de2ae  add rsp, 0xF0
00007f7c123de2b5  pop r11
00007f7c123de2b7  pop r10
00007f7c123de2b9  pop r9
00007f7c123de2bb  pop r8
00007f7c123de2bd  pop rsi
00007f7c123de2be  pop rdi
00007f7c123de2bf  pop rdx
00007f7c123de2c0  pop rcx
00007f7c123de2c1  pop rax
00007f7c123de2c2  add rsp, 0x08
00007f7c123de2c6  jmp 0x00007F7C123DC0B9
00007f7c123de2cb  sub rsp, 0x08
00007f7c123de2cf  push rax
00007f7c123de2d0  push rcx
00007f7c123de2d1  push rdx
00007f7c123de2d2  push rdi
00007f7c123de2d3  push rsi
00007f7c123de2d4  push r8
00007f7c123de2d6  push r9
00007f7c123de2d8  push r10
00007f7c123de2da  push r11
00007f7c123de2dc  sub rsp, 0xF0
00007f7c123de2e3  vmovaps [rsp], xmm0
00007f7c123de2e8  vmovaps [rsp+0x10], xmm1
00007f7c123de2ee  vmovaps [rsp+0x20], xmm2
00007f7c123de2f4  vmovaps [rsp+0x30], xmm3
00007f7c123de2fa  vmovaps [rsp+0x40], xmm5
00007f7c123de300  vmovaps [rsp+0x50], xmm6
00007f7c123de306  vmovaps [rsp+0x60], xmm7
00007f7c123de30c  vmovaps [rsp+0x70], xmm8
00007f7c123de312  vmovaps [rsp+0x80], xmm9
00007f7c123de31b  vmovaps [rsp+0x90], xmm10
00007f7c123de324  vmovaps [rsp+0xA0], xmm11
00007f7c123de32d  vmovaps [rsp+0xB0], xmm12
00007f7c123de336  vmovaps [rsp+0xC0], xmm13
00007f7c123de33f  vmovaps [rsp+0xD0], xmm14
00007f7c123de348  vmovaps [rsp+0xE0], xmm15
00007f7c123de351  sub rsp, 0x30
00007f7c123de355  movaps [rsp], xmm4
00007f7c123de359  movaps [rsp+0x10], xmm3
00007f7c123de35e  movaps [rsp+0x20], xmm5
00007f7c123de363  lea rdi, [rsp]
00007f7c123de367  mov esi, 0x00
00007f7c123de36c  mov rax, 0x5E723D793530
00007f7c123de376  call rax
00007f7c123de378  movaps xmm4, [rsp]
00007f7c123de37c  add rsp, 0x30
00007f7c123de380  vmovaps xmm0, [rsp]
00007f7c123de385  vmovaps xmm1, [rsp+0x10]
00007f7c123de38b  vmovaps xmm2, [rsp+0x20]
00007f7c123de391  vmovaps xmm3, [rsp+0x30]
00007f7c123de397  vmovaps xmm5, [rsp+0x40]
00007f7c123de39d  vmovaps xmm6, [rsp+0x50]
00007f7c123de3a3  vmovaps xmm7, [rsp+0x60]
00007f7c123de3a9  vmovaps xmm8, [rsp+0x70]
00007f7c123de3af  vmovaps xmm9, [rsp+0x80]
00007f7c123de3b8  vmovaps xmm10, [rsp+0x90]
00007f7c123de3c1  vmovaps xmm11, [rsp+0xA0]
00007f7c123de3ca  vmovaps xmm12, [rsp+0xB0]
00007f7c123de3d3  vmovaps xmm13, [rsp+0xC0]
00007f7c123de3dc  vmovaps xmm14, [rsp+0xD0]
00007f7c123de3e5  vmovaps xmm15, [rsp+0xE0]
00007f7c123de3ee  add rsp, 0xF0
00007f7c123de3f5  pop r11
00007f7c123de3f7  pop r10
00007f7c123de3f9  pop r9
00007f7c123de3fb  pop r8
00007f7c123de3fd  pop rsi
00007f7c123de3fe  pop rdi
00007f7c123de3ff  pop rdx
00007f7c123de400  pop rcx
00007f7c123de401  pop rax
00007f7c123de402  add rsp, 0x08
00007f7c123de406  jmp 0x00007F7C123DC107
00007f7c123de40b  call 0x00007F7C122B52F0
00007f7c123de410  jmp 0x00007F7C123DC114
00007f7c123de415  sub rsp, 0x08
00007f7c123de419  push rax
00007f7c123de41a  push rcx
00007f7c123de41b  push rdx
00007f7c123de41c  push rdi
00007f7c123de41d  push rsi
00007f7c123de41e  push r8
00007f7c123de420  push r9
00007f7c123de422  push r10
00007f7c123de424  push r11
00007f7c123de426  sub rsp, 0xF0
00007f7c123de42d  vmovaps [rsp], xmm0
00007f7c123de432  vmovaps [rsp+0x10], xmm1
00007f7c123de438  vmovaps [rsp+0x20], xmm2
00007f7c123de43e  vmovaps [rsp+0x30], xmm3
00007f7c123de444  vmovaps [rsp+0x40], xmm4
00007f7c123de44a  vmovaps [rsp+0x50], xmm6
00007f7c123de450  vmovaps [rsp+0x60], xmm7
00007f7c123de456  vmovaps [rsp+0x70], xmm8
00007f7c123de45c  vmovaps [rsp+0x80], xmm9
00007f7c123de465  vmovaps [rsp+0x90], xmm10
00007f7c123de46e  vmovaps [rsp+0xA0], xmm11
00007f7c123de477  vmovaps [rsp+0xB0], xmm12
00007f7c123de480  vmovaps [rsp+0xC0], xmm13
00007f7c123de489  vmovaps [rsp+0xD0], xmm14
00007f7c123de492  vmovaps [rsp+0xE0], xmm15
00007f7c123de49b  sub rsp, 0x30
00007f7c123de49f  movaps [rsp], xmm5
00007f7c123de4a3  movaps [rsp+0x10], xmm6
00007f7c123de4a8  movaps [rsp+0x20], xmm3
00007f7c123de4ad  lea rdi, [rsp]
00007f7c123de4b1  mov esi, 0x00
00007f7c123de4b6  mov rax, 0x5E723D793530
00007f7c123de4c0  call rax
00007f7c123de4c2  movaps xmm5, [rsp]
00007f7c123de4c6  add rsp, 0x30
00007f7c123de4ca  vmovaps xmm0, [rsp]
00007f7c123de4cf  vmovaps xmm1, [rsp+0x10]
00007f7c123de4d5  vmovaps xmm2, [rsp+0x20]
00007f7c123de4db  vmovaps xmm3, [rsp+0x30]
00007f7c123de4e1  vmovaps xmm4, [rsp+0x40]
00007f7c123de4e7  vmovaps xmm6, [rsp+0x50]
00007f7c123de4ed  vmovaps xmm7, [rsp+0x60]
00007f7c123de4f3  vmovaps xmm8, [rsp+0x70]
00007f7c123de4f9  vmovaps xmm9, [rsp+0x80]
00007f7c123de502  vmovaps xmm10, [rsp+0x90]
00007f7c123de50b  vmovaps xmm11, [rsp+0xA0]
00007f7c123de514  vmovaps xmm12, [rsp+0xB0]
00007f7c123de51d  vmovaps xmm13, [rsp+0xC0]
00007f7c123de526  vmovaps xmm14, [rsp+0xD0]
00007f7c123de52f  vmovaps xmm15, [rsp+0xE0]
00007f7c123de538  add rsp, 0xF0
00007f7c123de53f  pop r11
00007f7c123de541  pop r10
00007f7c123de543  pop r9
00007f7c123de545  pop r8
00007f7c123de547  pop rsi
00007f7c123de548  pop rdi
00007f7c123de549  pop rdx
00007f7c123de54a  pop rcx
00007f7c123de54b  pop rax
00007f7c123de54c  add rsp, 0x08
00007f7c123de550  jmp 0x00007F7C123DC13A
00007f7c123de555  sub rsp, 0x08
00007f7c123de559  push rax
00007f7c123de55a  push rcx
00007f7c123de55b  push rdx
00007f7c123de55c  push rdi
00007f7c123de55d  push rsi
00007f7c123de55e  push r8
00007f7c123de560  push r9
00007f7c123de562  push r10
00007f7c123de564  push r11
00007f7c123de566  sub rsp, 0xF0
00007f7c123de56d  vmovaps [rsp], xmm0
00007f7c123de572  vmovaps [rsp+0x10], xmm1
00007f7c123de578  vmovaps [rsp+0x20], xmm2
00007f7c123de57e  vmovaps [rsp+0x30], xmm3
00007f7c123de584  vmovaps [rsp+0x40], xmm4
00007f7c123de58a  vmovaps [rsp+0x50], xmm5
00007f7c123de590  vmovaps [rsp+0x60], xmm7
00007f7c123de596  vmovaps [rsp+0x70], xmm8
00007f7c123de59c  vmovaps [rsp+0x80], xmm9
00007f7c123de5a5  vmovaps [rsp+0x90], xmm10
00007f7c123de5ae  vmovaps [rsp+0xA0], xmm11
00007f7c123de5b7  vmovaps [rsp+0xB0], xmm12
00007f7c123de5c0  vmovaps [rsp+0xC0], xmm13
00007f7c123de5c9  vmovaps [rsp+0xD0], xmm14
00007f7c123de5d2  vmovaps [rsp+0xE0], xmm15
00007f7c123de5db  sub rsp, 0x30
00007f7c123de5df  movaps [rsp], xmm6
00007f7c123de5e3  movaps [rsp+0x10], xmm9
00007f7c123de5e9  movaps [rsp+0x20], xmm1
00007f7c123de5ee  lea rdi, [rsp]
00007f7c123de5f2  mov esi, 0x00
00007f7c123de5f7  mov rax, 0x5E723D793530
00007f7c123de601  call rax
00007f7c123de603  movaps xmm6, [rsp]
00007f7c123de607  add rsp, 0x30
00007f7c123de60b  vmovaps xmm0, [rsp]
00007f7c123de610  vmovaps xmm1, [rsp+0x10]
00007f7c123de616  vmovaps xmm2, [rsp+0x20]
00007f7c123de61c  vmovaps xmm3, [rsp+0x30]
00007f7c123de622  vmovaps xmm4, [rsp+0x40]
00007f7c123de628  vmovaps xmm5, [rsp+0x50]
00007f7c123de62e  vmovaps xmm7, [rsp+0x60]
00007f7c123de634  vmovaps xmm8, [rsp+0x70]
00007f7c123de63a  vmovaps xmm9, [rsp+0x80]
00007f7c123de643  vmovaps xmm10, [rsp+0x90]
00007f7c123de64c  vmovaps xmm11, [rsp+0xA0]
00007f7c123de655  vmovaps xmm12, [rsp+0xB0]
00007f7c123de65e  vmovaps xmm13, [rsp+0xC0]
00007f7c123de667  vmovaps xmm14, [rsp+0xD0]
00007f7c123de670  vmovaps xmm15, [rsp+0xE0]
00007f7c123de679  add rsp, 0xF0
00007f7c123de680  pop r11
00007f7c123de682  pop r10
00007f7c123de684  pop r9
00007f7c123de686  pop r8
00007f7c123de688  pop rsi
00007f7c123de689  pop rdi
00007f7c123de68a  pop rdx
00007f7c123de68b  pop rcx
00007f7c123de68c  pop rax
00007f7c123de68d  add rsp, 0x08
00007f7c123de691  jmp 0x00007F7C123DC15E
00007f7c123de696  sub rsp, 0x08
00007f7c123de69a  push rax
00007f7c123de69b  push rcx
00007f7c123de69c  push rdx
00007f7c123de69d  push rdi
00007f7c123de69e  push rsi
00007f7c123de69f  push r8
00007f7c123de6a1  push r9
00007f7c123de6a3  push r10
00007f7c123de6a5  push r11
00007f7c123de6a7  sub rsp, 0xF0
00007f7c123de6ae  vmovaps [rsp], xmm0
00007f7c123de6b3  vmovaps [rsp+0x10], xmm1
00007f7c123de6b9  vmovaps [rsp+0x20], xmm2
00007f7c123de6bf  vmovaps [rsp+0x30], xmm3
00007f7c123de6c5  vmovaps [rsp+0x40], xmm4
00007f7c123de6cb  vmovaps [rsp+0x50], xmm5
00007f7c123de6d1  vmovaps [rsp+0x60], xmm6
00007f7c123de6d7  vmovaps [rsp+0x70], xmm7
00007f7c123de6dd  vmovaps [rsp+0x80], xmm8
00007f7c123de6e6  vmovaps [rsp+0x90], xmm10
00007f7c123de6ef  vmovaps [rsp+0xA0], xmm11
00007f7c123de6f8  vmovaps [rsp+0xB0], xmm12
00007f7c123de701  vmovaps [rsp+0xC0], xmm13
00007f7c123de70a  vmovaps [rsp+0xD0], xmm14
00007f7c123de713  vmovaps [rsp+0xE0], xmm15
00007f7c123de71c  sub rsp, 0x30
00007f7c123de720  movaps [rsp], xmm9
00007f7c123de725  movaps [rsp+0x10], xmm3
00007f7c123de72a  movaps [rsp+0x20], xmm1
00007f7c123de72f  lea rdi, [rsp]
00007f7c123de733  mov esi, 0x00
00007f7c123de738  mov rax, 0x5E723D793530
00007f7c123de742  call rax
00007f7c123de744  movaps xmm9, [rsp]
00007f7c123de749  add rsp, 0x30
00007f7c123de74d  vmovaps xmm0, [rsp]
00007f7c123de752  vmovaps xmm1, [rsp+0x10]
00007f7c123de758  vmovaps xmm2, [rsp+0x20]
00007f7c123de75e  vmovaps xmm3, [rsp+0x30]
00007f7c123de764  vmovaps xmm4, [rsp+0x40]
00007f7c123de76a  vmovaps xmm5, [rsp+0x50]
00007f7c123de770  vmovaps xmm6, [rsp+0x60]
00007f7c123de776  vmovaps xmm7, [rsp+0x70]
00007f7c123de77c  vmovaps xmm8, [rsp+0x80]
00007f7c123de785  vmovaps xmm10, [rsp+0x90]
00007f7c123de78e  vmovaps xmm11, [rsp+0xA0]
00007f7c123de797  vmovaps xmm12, [rsp+0xB0]
00007f7c123de7a0  vmovaps xmm13, [rsp+0xC0]
00007f7c123de7a9  vmovaps xmm14, [rsp+0xD0]
00007f7c123de7b2  vmovaps xmm15, [rsp+0xE0]
00007f7c123de7bb  add rsp, 0xF0
00007f7c123de7c2  pop r11
00007f7c123de7c4  pop r10
00007f7c123de7c6  pop r9
00007f7c123de7c8  pop r8
00007f7c123de7ca  pop rsi
00007f7c123de7cb  pop rdi
00007f7c123de7cc  pop rdx
00007f7c123de7cd  pop rcx
00007f7c123de7ce  pop rax
00007f7c123de7cf  add rsp, 0x08
00007f7c123de7d3  jmp 0x00007F7C123DC1AA
00007f7c123de7d8  call 0x00007F7C122B52F0
00007f7c123de7dd  jmp 0x00007F7C123DC1B7
00007f7c123de7e2  sub rsp, 0x08
00007f7c123de7e6  push rax
00007f7c123de7e7  push rcx
00007f7c123de7e8  push rdx
00007f7c123de7e9  push rdi
00007f7c123de7ea  push rsi
00007f7c123de7eb  push r8
00007f7c123de7ed  push r9
00007f7c123de7ef  push r10
00007f7c123de7f1  push r11
00007f7c123de7f3  sub rsp, 0xF0
00007f7c123de7fa  vmovaps [rsp], xmm0
00007f7c123de7ff  vmovaps [rsp+0x10], xmm1
00007f7c123de805  vmovaps [rsp+0x20], xmm2
00007f7c123de80b  vmovaps [rsp+0x30], xmm3
00007f7c123de811  vmovaps [rsp+0x40], xmm4
00007f7c123de817  vmovaps [rsp+0x50], xmm5
00007f7c123de81d  vmovaps [rsp+0x60], xmm6
00007f7c123de823  vmovaps [rsp+0x70], xmm7
00007f7c123de829  vmovaps [rsp+0x80], xmm8
00007f7c123de832  vmovaps [rsp+0x90], xmm9
00007f7c123de83b  vmovaps [rsp+0xA0], xmm10
00007f7c123de844  vmovaps [rsp+0xB0], xmm11
00007f7c123de84d  vmovaps [rsp+0xC0], xmm12
00007f7c123de856  vmovaps [rsp+0xD0], xmm13
00007f7c123de85f  vmovaps [rsp+0xE0], xmm14
00007f7c123de868  sub rsp, 0x30
00007f7c123de86c  movaps [rsp], xmm15
00007f7c123de871  movaps [rsp+0x10], xmm3
00007f7c123de876  movaps [rsp+0x20], xmm7
00007f7c123de87b  lea rdi, [rsp]
00007f7c123de87f  mov esi, 0x00
00007f7c123de884  mov rax, 0x5E723D793530
00007f7c123de88e  call rax
00007f7c123de890  movaps xmm15, [rsp]
00007f7c123de895  add rsp, 0x30
00007f7c123de899  vmovaps xmm0, [rsp]
00007f7c123de89e  vmovaps xmm1, [rsp+0x10]
00007f7c123de8a4  vmovaps xmm2, [rsp+0x20]
00007f7c123de8aa  vmovaps xmm3, [rsp+0x30]
00007f7c123de8b0  vmovaps xmm4, [rsp+0x40]
00007f7c123de8b6  vmovaps xmm5, [rsp+0x50]
00007f7c123de8bc  vmovaps xmm6, [rsp+0x60]
00007f7c123de8c2  vmovaps xmm7, [rsp+0x70]
00007f7c123de8c8  vmovaps xmm8, [rsp+0x80]
00007f7c123de8d1  vmovaps xmm9, [rsp+0x90]
00007f7c123de8da  vmovaps xmm10, [rsp+0xA0]
00007f7c123de8e3  vmovaps xmm11, [rsp+0xB0]
00007f7c123de8ec  vmovaps xmm12, [rsp+0xC0]
00007f7c123de8f5  vmovaps xmm13, [rsp+0xD0]
00007f7c123de8fe  vmovaps xmm14, [rsp+0xE0]
00007f7c123de907  add rsp, 0xF0
00007f7c123de90e  pop r11
00007f7c123de910  pop r10
00007f7c123de912  pop r9
00007f7c123de914  pop r8
00007f7c123de916  pop rsi
00007f7c123de917  pop rdi
00007f7c123de918  pop rdx
00007f7c123de919  pop rcx
00007f7c123de91a  pop rax
00007f7c123de91b  add rsp, 0x08
00007f7c123de91f  jmp 0x00007F7C123DC1E3
00007f7c123de924  sub rsp, 0x08
00007f7c123de928  push rax
00007f7c123de929  push rcx
00007f7c123de92a  push rdx
00007f7c123de92b  push rdi
00007f7c123de92c  push rsi
00007f7c123de92d  push r8
00007f7c123de92f  push r9
00007f7c123de931  push r10
00007f7c123de933  push r11
00007f7c123de935  sub rsp, 0xF0
00007f7c123de93c  vmovaps [rsp], xmm0
00007f7c123de941  vmovaps [rsp+0x10], xmm1
00007f7c123de947  vmovaps [rsp+0x20], xmm2
00007f7c123de94d  vmovaps [rsp+0x30], xmm4
00007f7c123de953  vmovaps [rsp+0x40], xmm5
00007f7c123de959  vmovaps [rsp+0x50], xmm6
00007f7c123de95f  vmovaps [rsp+0x60], xmm7
00007f7c123de965  vmovaps [rsp+0x70], xmm8
00007f7c123de96b  vmovaps [rsp+0x80], xmm9
00007f7c123de974  vmovaps [rsp+0x90], xmm10
00007f7c123de97d  vmovaps [rsp+0xA0], xmm11
00007f7c123de986  vmovaps [rsp+0xB0], xmm12
00007f7c123de98f  vmovaps [rsp+0xC0], xmm13
00007f7c123de998  vmovaps [rsp+0xD0], xmm14
00007f7c123de9a1  vmovaps [rsp+0xE0], xmm15
00007f7c123de9aa  sub rsp, 0x30
00007f7c123de9ae  movaps [rsp], xmm3
00007f7c123de9b2  movaps [rsp+0x10], xmm1
00007f7c123de9b7  movaps [rsp+0x20], xmm15
00007f7c123de9bd  lea rdi, [rsp]
00007f7c123de9c1  mov esi, 0x00
00007f7c123de9c6  mov rax, 0x5E723D793530
00007f7c123de9d0  call rax
00007f7c123de9d2  movaps xmm3, [rsp]
00007f7c123de9d6  add rsp, 0x30
00007f7c123de9da  vmovaps xmm0, [rsp]
00007f7c123de9df  vmovaps xmm1, [rsp+0x10]
00007f7c123de9e5  vmovaps xmm2, [rsp+0x20]
00007f7c123de9eb  vmovaps xmm4, [rsp+0x30]
00007f7c123de9f1  vmovaps xmm5, [rsp+0x40]
00007f7c123de9f7  vmovaps xmm6, [rsp+0x50]
00007f7c123de9fd  vmovaps xmm7, [rsp+0x60]
00007f7c123dea03  vmovaps xmm8, [rsp+0x70]
00007f7c123dea09  vmovaps xmm9, [rsp+0x80]
00007f7c123dea12  vmovaps xmm10, [rsp+0x90]
00007f7c123dea1b  vmovaps xmm11, [rsp+0xA0]
00007f7c123dea24  vmovaps xmm12, [rsp+0xB0]
00007f7c123dea2d  vmovaps xmm13, [rsp+0xC0]
00007f7c123dea36  vmovaps xmm14, [rsp+0xD0]
00007f7c123dea3f  vmovaps xmm15, [rsp+0xE0]
00007f7c123dea48  add rsp, 0xF0
00007f7c123dea4f  pop r11
00007f7c123dea51  pop r10
00007f7c123dea53  pop r9
00007f7c123dea55  pop r8
00007f7c123dea57  pop rsi
00007f7c123dea58  pop rdi
00007f7c123dea59  pop rdx
00007f7c123dea5a  pop rcx
00007f7c123dea5b  pop rax
00007f7c123dea5c  add rsp, 0x08
00007f7c123dea60  jmp 0x00007F7C123DC272
00007f7c123dea65  call 0x00007F7C122B52F0
00007f7c123dea6a  jmp 0x00007F7C123DC27C
00007f7c123dea6f  sub rsp, 0x08
00007f7c123dea73  push rax
00007f7c123dea74  push rcx
00007f7c123dea75  push rdx
00007f7c123dea76  push rdi
00007f7c123dea77  push rsi
00007f7c123dea78  push r8
00007f7c123dea7a  push r9
00007f7c123dea7c  push r10
00007f7c123dea7e  push r11
00007f7c123dea80  sub rsp, 0xF0
00007f7c123dea87  vmovaps [rsp], xmm0
00007f7c123dea8c  vmovaps [rsp+0x10], xmm1
00007f7c123dea92  vmovaps [rsp+0x20], xmm2
00007f7c123dea98  vmovaps [rsp+0x30], xmm3
00007f7c123dea9e  vmovaps [rsp+0x40], xmm4
00007f7c123deaa4  vmovaps [rsp+0x50], xmm5
00007f7c123deaaa  vmovaps [rsp+0x60], xmm6
00007f7c123deab0  vmovaps [rsp+0x70], xmm7
00007f7c123deab6  vmovaps [rsp+0x80], xmm8
00007f7c123deabf  vmovaps [rsp+0x90], xmm9
00007f7c123deac8  vmovaps [rsp+0xA0], xmm10
00007f7c123dead1  vmovaps [rsp+0xB0], xmm11
00007f7c123deada  vmovaps [rsp+0xC0], xmm12
00007f7c123deae3  vmovaps [rsp+0xD0], xmm13
00007f7c123deaec  vmovaps [rsp+0xE0], xmm14
00007f7c123deaf5  sub rsp, 0x30
00007f7c123deaf9  movaps [rsp], xmm15
00007f7c123deafe  movaps [rsp+0x10], xmm14
00007f7c123deb04  movaps [rsp+0x20], xmm4
00007f7c123deb09  lea rdi, [rsp]
00007f7c123deb0d  mov esi, 0x00
00007f7c123deb12  mov rax, 0x5E723D793530
00007f7c123deb1c  call rax
00007f7c123deb1e  movaps xmm15, [rsp]
00007f7c123deb23  add rsp, 0x30
00007f7c123deb27  vmovaps xmm0, [rsp]
00007f7c123deb2c  vmovaps xmm1, [rsp+0x10]
00007f7c123deb32  vmovaps xmm2, [rsp+0x20]
00007f7c123deb38  vmovaps xmm3, [rsp+0x30]
00007f7c123deb3e  vmovaps xmm4, [rsp+0x40]
00007f7c123deb44  vmovaps xmm5, [rsp+0x50]
00007f7c123deb4a  vmovaps xmm6, [rsp+0x60]
00007f7c123deb50  vmovaps xmm7, [rsp+0x70]
00007f7c123deb56  vmovaps xmm8, [rsp+0x80]
00007f7c123deb5f  vmovaps xmm9, [rsp+0x90]
00007f7c123deb68  vmovaps xmm10, [rsp+0xA0]
00007f7c123deb71  vmovaps xmm11, [rsp+0xB0]
00007f7c123deb7a  vmovaps xmm12, [rsp+0xC0]
00007f7c123deb83  vmovaps xmm13, [rsp+0xD0]
00007f7c123deb8c  vmovaps xmm14, [rsp+0xE0]
00007f7c123deb95  add rsp, 0xF0
00007f7c123deb9c  pop r11
00007f7c123deb9e  pop r10
00007f7c123deba0  pop r9
00007f7c123deba2  pop r8
00007f7c123deba4  pop rsi
00007f7c123deba5  pop rdi
00007f7c123deba6  pop rdx
00007f7c123deba7  pop rcx
00007f7c123deba8  pop rax
00007f7c123deba9  add rsp, 0x08
00007f7c123debad  jmp 0x00007F7C123DC2AA
00007f7c123debb2  sub rsp, 0x08
00007f7c123debb6  push rax
00007f7c123debb7  push rcx
00007f7c123debb8  push rdx
00007f7c123debb9  push rdi
00007f7c123debba  push rsi
00007f7c123debbb  push r8
00007f7c123debbd  push r9
00007f7c123debbf  push r10
00007f7c123debc1  push r11
00007f7c123debc3  sub rsp, 0xF0
00007f7c123debca  vmovaps [rsp], xmm0
00007f7c123debcf  vmovaps [rsp+0x10], xmm1
00007f7c123debd5  vmovaps [rsp+0x20], xmm2
00007f7c123debdb  vmovaps [rsp+0x30], xmm3
00007f7c123debe1  vmovaps [rsp+0x40], xmm4
00007f7c123debe7  vmovaps [rsp+0x50], xmm5
00007f7c123debed  vmovaps [rsp+0x60], xmm6
00007f7c123debf3  vmovaps [rsp+0x70], xmm7
00007f7c123debf9  vmovaps [rsp+0x80], xmm8
00007f7c123dec02  vmovaps [rsp+0x90], xmm9
00007f7c123dec0b  vmovaps [rsp+0xA0], xmm10
00007f7c123dec14  vmovaps [rsp+0xB0], xmm11
00007f7c123dec1d  vmovaps [rsp+0xC0], xmm12
00007f7c123dec26  vmovaps [rsp+0xD0], xmm13
00007f7c123dec2f  vmovaps [rsp+0xE0], xmm15
00007f7c123dec38  sub rsp, 0x30
00007f7c123dec3c  movaps [rsp], xmm14
00007f7c123dec41  movaps [rsp+0x10], xmm2
00007f7c123dec46  movaps [rsp+0x20], xmm1
00007f7c123dec4b  lea rdi, [rsp]
00007f7c123dec4f  mov esi, 0x00
00007f7c123dec54  mov rax, 0x5E723D793530
00007f7c123dec5e  call rax
00007f7c123dec60  movaps xmm14, [rsp]
00007f7c123dec65  add rsp, 0x30
00007f7c123dec69  vmovaps xmm0, [rsp]
00007f7c123dec6e  vmovaps xmm1, [rsp+0x10]
00007f7c123dec74  vmovaps xmm2, [rsp+0x20]
00007f7c123dec7a  vmovaps xmm3, [rsp+0x30]
00007f7c123dec80  vmovaps xmm4, [rsp+0x40]
00007f7c123dec86  vmovaps xmm5, [rsp+0x50]
00007f7c123dec8c  vmovaps xmm6, [rsp+0x60]
00007f7c123dec92  vmovaps xmm7, [rsp+0x70]
00007f7c123dec98  vmovaps xmm8, [rsp+0x80]
00007f7c123deca1  vmovaps xmm9, [rsp+0x90]
00007f7c123decaa  vmovaps xmm10, [rsp+0xA0]
00007f7c123decb3  vmovaps xmm11, [rsp+0xB0]
00007f7c123decbc  vmovaps xmm12, [rsp+0xC0]
00007f7c123decc5  vmovaps xmm13, [rsp+0xD0]
00007f7c123decce  vmovaps xmm15, [rsp+0xE0]
00007f7c123decd7  add rsp, 0xF0
00007f7c123decde  pop r11
00007f7c123dece0  pop r10
00007f7c123dece2  pop r9
00007f7c123dece4  pop r8
00007f7c123dece6  pop rsi
00007f7c123dece7  pop rdi
00007f7c123dece8  pop rdx
00007f7c123dece9  pop rcx
00007f7c123decea  pop rax
00007f7c123deceb  add rsp, 0x08
00007f7c123decef  jmp 0x00007F7C123DC2D0
00007f7c123decf4  sub rsp, 0x08
00007f7c123decf8  push rax
00007f7c123decf9  push rcx
00007f7c123decfa  push rdx
00007f7c123decfb  push rdi
00007f7c123decfc  push rsi
00007f7c123decfd  push r8
00007f7c123decff  push r9
00007f7c123ded01  push r10
00007f7c123ded03  push r11
00007f7c123ded05  sub rsp, 0xF0
00007f7c123ded0c  vmovaps [rsp], xmm0
00007f7c123ded11  vmovaps [rsp+0x10], xmm2
00007f7c123ded17  vmovaps [rsp+0x20], xmm3
00007f7c123ded1d  vmovaps [rsp+0x30], xmm4
00007f7c123ded23  vmovaps [rsp+0x40], xmm5
00007f7c123ded29  vmovaps [rsp+0x50], xmm6
00007f7c123ded2f  vmovaps [rsp+0x60], xmm7
00007f7c123ded35  vmovaps [rsp+0x70], xmm8
00007f7c123ded3b  vmovaps [rsp+0x80], xmm9
00007f7c123ded44  vmovaps [rsp+0x90], xmm10
00007f7c123ded4d  vmovaps [rsp+0xA0], xmm11
00007f7c123ded56  vmovaps [rsp+0xB0], xmm12
00007f7c123ded5f  vmovaps [rsp+0xC0], xmm13
00007f7c123ded68  vmovaps [rsp+0xD0], xmm14
00007f7c123ded71  vmovaps [rsp+0xE0], xmm15
00007f7c123ded7a  sub rsp, 0x30
00007f7c123ded7e  movaps [rsp], xmm1
00007f7c123ded82  movaps [rsp+0x10], xmm4
00007f7c123ded87  movaps [rsp+0x20], xmm9
00007f7c123ded8d  lea rdi, [rsp]
00007f7c123ded91  mov esi, 0x00
00007f7c123ded96  mov rax, 0x5E723D793530
00007f7c123deda0  call rax
00007f7c123deda2  movaps xmm1, [rsp]
00007f7c123deda6  add rsp, 0x30
00007f7c123dedaa  vmovaps xmm0, [rsp]
00007f7c123dedaf  vmovaps xmm2, [rsp+0x10]
00007f7c123dedb5  vmovaps xmm3, [rsp+0x20]
00007f7c123dedbb  vmovaps xmm4, [rsp+0x30]
00007f7c123dedc1  vmovaps xmm5, [rsp+0x40]
00007f7c123dedc7  vmovaps xmm6, [rsp+0x50]
00007f7c123dedcd  vmovaps xmm7, [rsp+0x60]
00007f7c123dedd3  vmovaps xmm8, [rsp+0x70]
00007f7c123dedd9  vmovaps xmm9, [rsp+0x80]
00007f7c123dede2  vmovaps xmm10, [rsp+0x90]
00007f7c123dedeb  vmovaps xmm11, [rsp+0xA0]
00007f7c123dedf4  vmovaps xmm12, [rsp+0xB0]
00007f7c123dedfd  vmovaps xmm13, [rsp+0xC0]
00007f7c123dee06  vmovaps xmm14, [rsp+0xD0]
00007f7c123dee0f  vmovaps xmm15, [rsp+0xE0]
00007f7c123dee18  add rsp, 0xF0
00007f7c123dee1f  pop r11
00007f7c123dee21  pop r10
00007f7c123dee23  pop r9
00007f7c123dee25  pop r8
00007f7c123dee27  pop rsi
00007f7c123dee28  pop rdi
00007f7c123dee29  pop rdx
00007f7c123dee2a  pop rcx
00007f7c123dee2b  pop rax
00007f7c123dee2c  add rsp, 0x08
00007f7c123dee30  jmp 0x00007F7C123DC2EE
00007f7c123dee35  sub rsp, 0x08
00007f7c123dee39  push rax
00007f7c123dee3a  push rcx
00007f7c123dee3b  push rdx
00007f7c123dee3c  push rdi
00007f7c123dee3d  push rsi
00007f7c123dee3e  push r8
00007f7c123dee40  push r9
00007f7c123dee42  push r10
00007f7c123dee44  push r11
00007f7c123dee46  sub rsp, 0xF0
00007f7c123dee4d  vmovaps [rsp], xmm0
00007f7c123dee52  vmovaps [rsp+0x10], xmm1
00007f7c123dee58  vmovaps [rsp+0x20], xmm2
00007f7c123dee5e  vmovaps [rsp+0x30], xmm3
00007f7c123dee64  vmovaps [rsp+0x40], xmm5
00007f7c123dee6a  vmovaps [rsp+0x50], xmm6
00007f7c123dee70  vmovaps [rsp+0x60], xmm7
00007f7c123dee76  vmovaps [rsp+0x70], xmm8
00007f7c123dee7c  vmovaps [rsp+0x80], xmm9
00007f7c123dee85  vmovaps [rsp+0x90], xmm10
00007f7c123dee8e  vmovaps [rsp+0xA0], xmm11
00007f7c123dee97  vmovaps [rsp+0xB0], xmm12
00007f7c123deea0  vmovaps [rsp+0xC0], xmm13
00007f7c123deea9  vmovaps [rsp+0xD0], xmm14
00007f7c123deeb2  vmovaps [rsp+0xE0], xmm15
00007f7c123deebb  sub rsp, 0x30
00007f7c123deebf  movaps [rsp], xmm4
00007f7c123deec3  movaps [rsp+0x10], xmm2
00007f7c123deec8  movaps [rsp+0x20], xmm9
00007f7c123deece  lea rdi, [rsp]
00007f7c123deed2  mov esi, 0x00
00007f7c123deed7  mov rax, 0x5E723D793530
00007f7c123deee1  call rax
00007f7c123deee3  movaps xmm4, [rsp]
00007f7c123deee7  add rsp, 0x30
00007f7c123deeeb  vmovaps xmm0, [rsp]
00007f7c123deef0  vmovaps xmm1, [rsp+0x10]
00007f7c123deef6  vmovaps xmm2, [rsp+0x20]
00007f7c123deefc  vmovaps xmm3, [rsp+0x30]
00007f7c123def02  vmovaps xmm5, [rsp+0x40]
00007f7c123def08  vmovaps xmm6, [rsp+0x50]
00007f7c123def0e  vmovaps xmm7, [rsp+0x60]
00007f7c123def14  vmovaps xmm8, [rsp+0x70]
00007f7c123def1a  vmovaps xmm9, [rsp+0x80]
00007f7c123def23  vmovaps xmm10, [rsp+0x90]
00007f7c123def2c  vmovaps xmm11, [rsp+0xA0]
00007f7c123def35  vmovaps xmm12, [rsp+0xB0]
00007f7c123def3e  vmovaps xmm13, [rsp+0xC0]
00007f7c123def47  vmovaps xmm14, [rsp+0xD0]
00007f7c123def50  vmovaps xmm15, [rsp+0xE0]
00007f7c123def59  add rsp, 0xF0
00007f7c123def60  pop r11
00007f7c123def62  pop r10
00007f7c123def64  pop r9
00007f7c123def66  pop r8
00007f7c123def68  pop rsi
00007f7c123def69  pop rdi
00007f7c123def6a  pop rdx
00007f7c123def6b  pop rcx
00007f7c123def6c  pop rax
00007f7c123def6d  add rsp, 0x08
00007f7c123def71  jmp 0x00007F7C123DC31E
00007f7c123def76  sub rsp, 0x08
00007f7c123def7a  push rax
00007f7c123def7b  push rcx
00007f7c123def7c  push rdx
00007f7c123def7d  push rdi
00007f7c123def7e  push rsi
00007f7c123def7f  push r8
00007f7c123def81  push r9
00007f7c123def83  push r10
00007f7c123def85  push r11
00007f7c123def87  sub rsp, 0xF0
00007f7c123def8e  vmovaps [rsp], xmm0
00007f7c123def93  vmovaps [rsp+0x10], xmm1
00007f7c123def99  vmovaps [rsp+0x20], xmm2
00007f7c123def9f  vmovaps [rsp+0x30], xmm3
00007f7c123defa5  vmovaps [rsp+0x40], xmm4
00007f7c123defab  vmovaps [rsp+0x50], xmm5
00007f7c123defb1  vmovaps [rsp+0x60], xmm6
00007f7c123defb7  vmovaps [rsp+0x70], xmm7
00007f7c123defbd  vmovaps [rsp+0x80], xmm8
00007f7c123defc6  vmovaps [rsp+0x90], xmm10
00007f7c123defcf  vmovaps [rsp+0xA0], xmm11
00007f7c123defd8  vmovaps [rsp+0xB0], xmm12
00007f7c123defe1  vmovaps [rsp+0xC0], xmm13
00007f7c123defea  vmovaps [rsp+0xD0], xmm14
00007f7c123deff3  vmovaps [rsp+0xE0], xmm15
00007f7c123deffc  sub rsp, 0x30
00007f7c123df000  movaps [rsp], xmm9
00007f7c123df005  movaps [rsp+0x10], xmm2
00007f7c123df00a  movaps [rsp+0x20], xmm1
00007f7c123df00f  lea rdi, [rsp]
00007f7c123df013  mov esi, 0x00
00007f7c123df018  mov rax, 0x5E723D793530
00007f7c123df022  call rax
00007f7c123df024  movaps xmm9, [rsp]
00007f7c123df029  add rsp, 0x30
00007f7c123df02d  vmovaps xmm0, [rsp]
00007f7c123df032  vmovaps xmm1, [rsp+0x10]
00007f7c123df038  vmovaps xmm2, [rsp+0x20]
00007f7c123df03e  vmovaps xmm3, [rsp+0x30]
00007f7c123df044  vmovaps xmm4, [rsp+0x40]
00007f7c123df04a  vmovaps xmm5, [rsp+0x50]
00007f7c123df050  vmovaps xmm6, [rsp+0x60]
00007f7c123df056  vmovaps xmm7, [rsp+0x70]
00007f7c123df05c  vmovaps xmm8, [rsp+0x80]
00007f7c123df065  vmovaps xmm10, [rsp+0x90]
00007f7c123df06e  vmovaps xmm11, [rsp+0xA0]
00007f7c123df077  vmovaps xmm12, [rsp+0xB0]
00007f7c123df080  vmovaps xmm13, [rsp+0xC0]
00007f7c123df089  vmovaps xmm14, [rsp+0xD0]
00007f7c123df092  vmovaps xmm15, [rsp+0xE0]
00007f7c123df09b  add rsp, 0xF0
00007f7c123df0a2  pop r11
00007f7c123df0a4  pop r10
00007f7c123df0a6  pop r9
00007f7c123df0a8  pop r8
00007f7c123df0aa  pop rsi
00007f7c123df0ab  pop rdi
00007f7c123df0ac  pop rdx
00007f7c123df0ad  pop rcx
00007f7c123df0ae  pop rax
00007f7c123df0af  add rsp, 0x08
00007f7c123df0b3  jmp 0x00007F7C123DC354
00007f7c123df0b8  sub rsp, 0x08
00007f7c123df0bc  push rax
00007f7c123df0bd  push rcx
00007f7c123df0be  push rdx
00007f7c123df0bf  push rdi
00007f7c123df0c0  push rsi
00007f7c123df0c1  push r8
00007f7c123df0c3  push r9
00007f7c123df0c5  push r10
00007f7c123df0c7  push r11
00007f7c123df0c9  sub rsp, 0xF0
00007f7c123df0d0  vmovaps [rsp], xmm0
00007f7c123df0d5  vmovaps [rsp+0x10], xmm2
00007f7c123df0db  vmovaps [rsp+0x20], xmm3
00007f7c123df0e1  vmovaps [rsp+0x30], xmm4
00007f7c123df0e7  vmovaps [rsp+0x40], xmm5
00007f7c123df0ed  vmovaps [rsp+0x50], xmm6
00007f7c123df0f3  vmovaps [rsp+0x60], xmm7
00007f7c123df0f9  vmovaps [rsp+0x70], xmm8
00007f7c123df0ff  vmovaps [rsp+0x80], xmm9
00007f7c123df108  vmovaps [rsp+0x90], xmm10
00007f7c123df111  vmovaps [rsp+0xA0], xmm11
00007f7c123df11a  vmovaps [rsp+0xB0], xmm12
00007f7c123df123  vmovaps [rsp+0xC0], xmm13
00007f7c123df12c  vmovaps [rsp+0xD0], xmm14
00007f7c123df135  vmovaps [rsp+0xE0], xmm15
00007f7c123df13e  sub rsp, 0x30
00007f7c123df142  movaps [rsp], xmm1
00007f7c123df146  movaps [rsp+0x10], xmm15
00007f7c123df14c  movaps [rsp+0x20], xmm6
00007f7c123df151  lea rdi, [rsp]
00007f7c123df155  mov esi, 0x00
00007f7c123df15a  mov rax, 0x5E723D793530
00007f7c123df164  call rax
00007f7c123df166  movaps xmm1, [rsp]
00007f7c123df16a  add rsp, 0x30
00007f7c123df16e  vmovaps xmm0, [rsp]
00007f7c123df173  vmovaps xmm2, [rsp+0x10]
00007f7c123df179  vmovaps xmm3, [rsp+0x20]
00007f7c123df17f  vmovaps xmm4, [rsp+0x30]
00007f7c123df185  vmovaps xmm5, [rsp+0x40]
00007f7c123df18b  vmovaps xmm6, [rsp+0x50]
00007f7c123df191  vmovaps xmm7, [rsp+0x60]
00007f7c123df197  vmovaps xmm8, [rsp+0x70]
00007f7c123df19d  vmovaps xmm9, [rsp+0x80]
00007f7c123df1a6  vmovaps xmm10, [rsp+0x90]
00007f7c123df1af  vmovaps xmm11, [rsp+0xA0]
00007f7c123df1b8  vmovaps xmm12, [rsp+0xB0]
00007f7c123df1c1  vmovaps xmm13, [rsp+0xC0]
00007f7c123df1ca  vmovaps xmm14, [rsp+0xD0]
00007f7c123df1d3  vmovaps xmm15, [rsp+0xE0]
00007f7c123df1dc  add rsp, 0xF0
00007f7c123df1e3  pop r11
00007f7c123df1e5  pop r10
00007f7c123df1e7  pop r9
00007f7c123df1e9  pop r8
00007f7c123df1eb  pop rsi
00007f7c123df1ec  pop rdi
00007f7c123df1ed  pop rdx
00007f7c123df1ee  pop rcx
00007f7c123df1ef  pop rax
00007f7c123df1f0  add rsp, 0x08
00007f7c123df1f4  jmp 0x00007F7C123DC375
00007f7c123df1f9  sub rsp, 0x08
00007f7c123df1fd  push rax
00007f7c123df1fe  push rcx
00007f7c123df1ff  push rdx
00007f7c123df200  push rdi
00007f7c123df201  push rsi
00007f7c123df202  push r8
00007f7c123df204  push r9
00007f7c123df206  push r10
00007f7c123df208  push r11
00007f7c123df20a  sub rsp, 0xF0
00007f7c123df211  vmovaps [rsp], xmm0
00007f7c123df216  vmovaps [rsp+0x10], xmm1
00007f7c123df21c  vmovaps [rsp+0x20], xmm2
00007f7c123df222  vmovaps [rsp+0x30], xmm3
00007f7c123df228  vmovaps [rsp+0x40], xmm4
00007f7c123df22e  vmovaps [rsp+0x50], xmm5
00007f7c123df234  vmovaps [rsp+0x60], xmm6
00007f7c123df23a  vmovaps [rsp+0x70], xmm7
00007f7c123df240  vmovaps [rsp+0x80], xmm8
00007f7c123df249  vmovaps [rsp+0x90], xmm9
00007f7c123df252  vmovaps [rsp+0xA0], xmm10
00007f7c123df25b  vmovaps [rsp+0xB0], xmm11
00007f7c123df264  vmovaps [rsp+0xC0], xmm12
00007f7c123df26d  vmovaps [rsp+0xD0], xmm13
00007f7c123df276  vmovaps [rsp+0xE0], xmm14
00007f7c123df27f  sub rsp, 0x30
00007f7c123df283  movaps [rsp], xmm15
00007f7c123df288  movaps [rsp+0x10], xmm5
00007f7c123df28d  movaps [rsp+0x20], xmm3
00007f7c123df292  lea rdi, [rsp]
00007f7c123df296  mov esi, 0x00
00007f7c123df29b  mov rax, 0x5E723D793530
00007f7c123df2a5  call rax
00007f7c123df2a7  movaps xmm15, [rsp]
00007f7c123df2ac  add rsp, 0x30
00007f7c123df2b0  vmovaps xmm0, [rsp]
00007f7c123df2b5  vmovaps xmm1, [rsp+0x10]
00007f7c123df2bb  vmovaps xmm2, [rsp+0x20]
00007f7c123df2c1  vmovaps xmm3, [rsp+0x30]
00007f7c123df2c7  vmovaps xmm4, [rsp+0x40]
00007f7c123df2cd  vmovaps xmm5, [rsp+0x50]
00007f7c123df2d3  vmovaps xmm6, [rsp+0x60]
00007f7c123df2d9  vmovaps xmm7, [rsp+0x70]
00007f7c123df2df  vmovaps xmm8, [rsp+0x80]
00007f7c123df2e8  vmovaps xmm9, [rsp+0x90]
00007f7c123df2f1  vmovaps xmm10, [rsp+0xA0]
00007f7c123df2fa  vmovaps xmm11, [rsp+0xB0]
00007f7c123df303  vmovaps xmm12, [rsp+0xC0]
00007f7c123df30c  vmovaps xmm13, [rsp+0xD0]
00007f7c123df315  vmovaps xmm14, [rsp+0xE0]
00007f7c123df31e  add rsp, 0xF0
00007f7c123df325  pop r11
00007f7c123df327  pop r10
00007f7c123df329  pop r9
00007f7c123df32b  pop r8
00007f7c123df32d  pop rsi
00007f7c123df32e  pop rdi
00007f7c123df32f  pop rdx
00007f7c123df330  pop rcx
00007f7c123df331  pop rax
00007f7c123df332  add rsp, 0x08
00007f7c123df336  jmp 0x00007F7C123DC38F
00007f7c123df33b  sub rsp, 0x08
00007f7c123df33f  push rax
00007f7c123df340  push rcx
00007f7c123df341  push rdx
00007f7c123df342  push rdi
00007f7c123df343  push rsi
00007f7c123df344  push r8
00007f7c123df346  push r9
00007f7c123df348  push r10
00007f7c123df34a  push r11
00007f7c123df34c  sub rsp, 0xF0
00007f7c123df353  vmovaps [rsp], xmm0
00007f7c123df358  vmovaps [rsp+0x10], xmm1
00007f7c123df35e  vmovaps [rsp+0x20], xmm2
00007f7c123df364  vmovaps [rsp+0x30], xmm3
00007f7c123df36a  vmovaps [rsp+0x40], xmm4
00007f7c123df370  vmovaps [rsp+0x50], xmm6
00007f7c123df376  vmovaps [rsp+0x60], xmm7
00007f7c123df37c  vmovaps [rsp+0x70], xmm8
00007f7c123df382  vmovaps [rsp+0x80], xmm9
00007f7c123df38b  vmovaps [rsp+0x90], xmm10
00007f7c123df394  vmovaps [rsp+0xA0], xmm11
00007f7c123df39d  vmovaps [rsp+0xB0], xmm12
00007f7c123df3a6  vmovaps [rsp+0xC0], xmm13
00007f7c123df3af  vmovaps [rsp+0xD0], xmm14
00007f7c123df3b8  vmovaps [rsp+0xE0], xmm15
00007f7c123df3c1  sub rsp, 0x30
00007f7c123df3c5  movaps [rsp], xmm5
00007f7c123df3c9  movaps [rsp+0x10], xmm8
00007f7c123df3cf  movaps [rsp+0x20], xmm6
00007f7c123df3d4  lea rdi, [rsp]
00007f7c123df3d8  mov esi, 0x00
00007f7c123df3dd  mov rax, 0x5E723D793530
00007f7c123df3e7  call rax
00007f7c123df3e9  movaps xmm5, [rsp]
00007f7c123df3ed  add rsp, 0x30
00007f7c123df3f1  vmovaps xmm0, [rsp]
00007f7c123df3f6  vmovaps xmm1, [rsp+0x10]
00007f7c123df3fc  vmovaps xmm2, [rsp+0x20]
00007f7c123df402  vmovaps xmm3, [rsp+0x30]
00007f7c123df408  vmovaps xmm4, [rsp+0x40]
00007f7c123df40e  vmovaps xmm6, [rsp+0x50]
00007f7c123df414  vmovaps xmm7, [rsp+0x60]
00007f7c123df41a  vmovaps xmm8, [rsp+0x70]
00007f7c123df420  vmovaps xmm9, [rsp+0x80]
00007f7c123df429  vmovaps xmm10, [rsp+0x90]
00007f7c123df432  vmovaps xmm11, [rsp+0xA0]
00007f7c123df43b  vmovaps xmm12, [rsp+0xB0]
00007f7c123df444  vmovaps xmm13, [rsp+0xC0]
00007f7c123df44d  vmovaps xmm14, [rsp+0xD0]
00007f7c123df456  vmovaps xmm15, [rsp+0xE0]
00007f7c123df45f  add rsp, 0xF0
00007f7c123df466  pop r11
00007f7c123df468  pop r10
00007f7c123df46a  pop r9
00007f7c123df46c  pop r8
00007f7c123df46e  pop rsi
00007f7c123df46f  pop rdi
00007f7c123df470  pop rdx
00007f7c123df471  pop rcx
00007f7c123df472  pop rax
00007f7c123df473  add rsp, 0x08
00007f7c123df477  jmp 0x00007F7C123DC3B3
00007f7c123df47c  sub rsp, 0x08
00007f7c123df480  push rax
00007f7c123df481  push rcx
00007f7c123df482  push rdx
00007f7c123df483  push rdi
00007f7c123df484  push rsi
00007f7c123df485  push r8
00007f7c123df487  push r9
00007f7c123df489  push r10
00007f7c123df48b  push r11
00007f7c123df48d  sub rsp, 0xF0
00007f7c123df494  vmovaps [rsp], xmm0
00007f7c123df499  vmovaps [rsp+0x10], xmm1
00007f7c123df49f  vmovaps [rsp+0x20], xmm2
00007f7c123df4a5  vmovaps [rsp+0x30], xmm3
00007f7c123df4ab  vmovaps [rsp+0x40], xmm4
00007f7c123df4b1  vmovaps [rsp+0x50], xmm5
00007f7c123df4b7  vmovaps [rsp+0x60], xmm7
00007f7c123df4bd  vmovaps [rsp+0x70], xmm8
00007f7c123df4c3  vmovaps [rsp+0x80], xmm9
00007f7c123df4cc  vmovaps [rsp+0x90], xmm10
00007f7c123df4d5  vmovaps [rsp+0xA0], xmm11
00007f7c123df4de  vmovaps [rsp+0xB0], xmm12
00007f7c123df4e7  vmovaps [rsp+0xC0], xmm13
00007f7c123df4f0  vmovaps [rsp+0xD0], xmm14
00007f7c123df4f9  vmovaps [rsp+0xE0], xmm15
00007f7c123df502  sub rsp, 0x30
00007f7c123df506  movaps [rsp], xmm6
00007f7c123df50a  movaps [rsp+0x10], xmm10
00007f7c123df510  movaps [rsp+0x20], xmm8
00007f7c123df516  lea rdi, [rsp]
00007f7c123df51a  mov esi, 0x00
00007f7c123df51f  mov rax, 0x5E723D793530
00007f7c123df529  call rax
00007f7c123df52b  movaps xmm6, [rsp]
00007f7c123df52f  add rsp, 0x30
00007f7c123df533  vmovaps xmm0, [rsp]
00007f7c123df538  vmovaps xmm1, [rsp+0x10]
00007f7c123df53e  vmovaps xmm2, [rsp+0x20]
00007f7c123df544  vmovaps xmm3, [rsp+0x30]
00007f7c123df54a  vmovaps xmm4, [rsp+0x40]
00007f7c123df550  vmovaps xmm5, [rsp+0x50]
00007f7c123df556  vmovaps xmm7, [rsp+0x60]
00007f7c123df55c  vmovaps xmm8, [rsp+0x70]
00007f7c123df562  vmovaps xmm9, [rsp+0x80]
00007f7c123df56b  vmovaps xmm10, [rsp+0x90]
00007f7c123df574  vmovaps xmm11, [rsp+0xA0]
00007f7c123df57d  vmovaps xmm12, [rsp+0xB0]
00007f7c123df586  vmovaps xmm13, [rsp+0xC0]
00007f7c123df58f  vmovaps xmm14, [rsp+0xD0]
00007f7c123df598  vmovaps xmm15, [rsp+0xE0]
00007f7c123df5a1  add rsp, 0xF0
00007f7c123df5a8  pop r11
00007f7c123df5aa  pop r10
00007f7c123df5ac  pop r9
00007f7c123df5ae  pop r8
00007f7c123df5b0  pop rsi
00007f7c123df5b1  pop rdi
00007f7c123df5b2  pop rdx
00007f7c123df5b3  pop rcx
00007f7c123df5b4  pop rax
00007f7c123df5b5  add rsp, 0x08
00007f7c123df5b9  jmp 0x00007F7C123DC3D8
00007f7c123df5be  sub rsp, 0x08
00007f7c123df5c2  push rax
00007f7c123df5c3  push rcx
00007f7c123df5c4  push rdx
00007f7c123df5c5  push rdi
00007f7c123df5c6  push rsi
00007f7c123df5c7  push r8
00007f7c123df5c9  push r9
00007f7c123df5cb  push r10
00007f7c123df5cd  push r11
00007f7c123df5cf  sub rsp, 0xF0
00007f7c123df5d6  vmovaps [rsp], xmm0
00007f7c123df5db  vmovaps [rsp+0x10], xmm1
00007f7c123df5e1  vmovaps [rsp+0x20], xmm2
00007f7c123df5e7  vmovaps [rsp+0x30], xmm3
00007f7c123df5ed  vmovaps [rsp+0x40], xmm4
00007f7c123df5f3  vmovaps [rsp+0x50], xmm5
00007f7c123df5f9  vmovaps [rsp+0x60], xmm6
00007f7c123df5ff  vmovaps [rsp+0x70], xmm7
00007f7c123df605  vmovaps [rsp+0x80], xmm8
00007f7c123df60e  vmovaps [rsp+0x90], xmm9
00007f7c123df617  vmovaps [rsp+0xA0], xmm11
00007f7c123df620  vmovaps [rsp+0xB0], xmm12
00007f7c123df629  vmovaps [rsp+0xC0], xmm13
00007f7c123df632  vmovaps [rsp+0xD0], xmm14
00007f7c123df63b  vmovaps [rsp+0xE0], xmm15
00007f7c123df644  sub rsp, 0x30
00007f7c123df648  movaps [rsp], xmm10
00007f7c123df64d  movaps [rsp+0x10], xmm8
00007f7c123df653  movaps [rsp+0x20], xmm14
00007f7c123df659  lea rdi, [rsp]
00007f7c123df65d  mov esi, 0x00
00007f7c123df662  mov rax, 0x5E723D793530
00007f7c123df66c  call rax
00007f7c123df66e  movaps xmm10, [rsp]
00007f7c123df673  add rsp, 0x30
00007f7c123df677  vmovaps xmm0, [rsp]
00007f7c123df67c  vmovaps xmm1, [rsp+0x10]
00007f7c123df682  vmovaps xmm2, [rsp+0x20]
00007f7c123df688  vmovaps xmm3, [rsp+0x30]
00007f7c123df68e  vmovaps xmm4, [rsp+0x40]
00007f7c123df694  vmovaps xmm5, [rsp+0x50]
00007f7c123df69a  vmovaps xmm6, [rsp+0x60]
00007f7c123df6a0  vmovaps xmm7, [rsp+0x70]
00007f7c123df6a6  vmovaps xmm8, [rsp+0x80]
00007f7c123df6af  vmovaps xmm9, [rsp+0x90]
00007f7c123df6b8  vmovaps xmm11, [rsp+0xA0]
00007f7c123df6c1  vmovaps xmm12, [rsp+0xB0]
00007f7c123df6ca  vmovaps xmm13, [rsp+0xC0]
00007f7c123df6d3  vmovaps xmm14, [rsp+0xD0]
00007f7c123df6dc  vmovaps xmm15, [rsp+0xE0]
00007f7c123df6e5  add rsp, 0xF0
00007f7c123df6ec  pop r11
00007f7c123df6ee  pop r10
00007f7c123df6f0  pop r9
00007f7c123df6f2  pop r8
00007f7c123df6f4  pop rsi
00007f7c123df6f5  pop rdi
00007f7c123df6f6  pop rdx
00007f7c123df6f7  pop rcx
00007f7c123df6f8  pop rax
00007f7c123df6f9  add rsp, 0x08
00007f7c123df6fd  jmp 0x00007F7C123DC3F8
00007f7c123df702  sub rsp, 0x08
00007f7c123df706  push rax
00007f7c123df707  push rcx
00007f7c123df708  push rdx
00007f7c123df709  push rdi
00007f7c123df70a  push rsi
00007f7c123df70b  push r8
00007f7c123df70d  push r9
00007f7c123df70f  push r10
00007f7c123df711  push r11
00007f7c123df713  sub rsp, 0xF0
00007f7c123df71a  vmovaps [rsp], xmm0
00007f7c123df71f  vmovaps [rsp+0x10], xmm1
00007f7c123df725  vmovaps [rsp+0x20], xmm2
00007f7c123df72b  vmovaps [rsp+0x30], xmm3
00007f7c123df731  vmovaps [rsp+0x40], xmm4
00007f7c123df737  vmovaps [rsp+0x50], xmm5
00007f7c123df73d  vmovaps [rsp+0x60], xmm6
00007f7c123df743  vmovaps [rsp+0x70], xmm7
00007f7c123df749  vmovaps [rsp+0x80], xmm8
00007f7c123df752  vmovaps [rsp+0x90], xmm9
00007f7c123df75b  vmovaps [rsp+0xA0], xmm10
00007f7c123df764  vmovaps [rsp+0xB0], xmm11
00007f7c123df76d  vmovaps [rsp+0xC0], xmm12
00007f7c123df776  vmovaps [rsp+0xD0], xmm13
00007f7c123df77f  vmovaps [rsp+0xE0], xmm15
00007f7c123df788  sub rsp, 0x30
00007f7c123df78c  movaps [rsp], xmm14
00007f7c123df791  movaps [rsp+0x10], xmm8
00007f7c123df797  movaps [rsp+0x20], xmm4
00007f7c123df79c  lea rdi, [rsp]
00007f7c123df7a0  mov esi, 0x00
00007f7c123df7a5  mov rax, 0x5E723D793530
00007f7c123df7af  call rax
00007f7c123df7b1  movaps xmm14, [rsp]
00007f7c123df7b6  add rsp, 0x30
00007f7c123df7ba  vmovaps xmm0, [rsp]
00007f7c123df7bf  vmovaps xmm1, [rsp+0x10]
00007f7c123df7c5  vmovaps xmm2, [rsp+0x20]
00007f7c123df7cb  vmovaps xmm3, [rsp+0x30]
00007f7c123df7d1  vmovaps xmm4, [rsp+0x40]
00007f7c123df7d7  vmovaps xmm5, [rsp+0x50]
00007f7c123df7dd  vmovaps xmm6, [rsp+0x60]
00007f7c123df7e3  vmovaps xmm7, [rsp+0x70]
00007f7c123df7e9  vmovaps xmm8, [rsp+0x80]
00007f7c123df7f2  vmovaps xmm9, [rsp+0x90]
00007f7c123df7fb  vmovaps xmm10, [rsp+0xA0]
00007f7c123df804  vmovaps xmm11, [rsp+0xB0]
00007f7c123df80d  vmovaps xmm12, [rsp+0xC0]
00007f7c123df816  vmovaps xmm13, [rsp+0xD0]
00007f7c123df81f  vmovaps xmm15, [rsp+0xE0]
00007f7c123df828  add rsp, 0xF0
00007f7c123df82f  pop r11
00007f7c123df831  pop r10
00007f7c123df833  pop r9
00007f7c123df835  pop r8
00007f7c123df837  pop rsi
00007f7c123df838  pop rdi
00007f7c123df839  pop rdx
00007f7c123df83a  pop rcx
00007f7c123df83b  pop rax
00007f7c123df83c  add rsp, 0x08
00007f7c123df840  jmp 0x00007F7C123DC418
00007f7c123df845  sub rsp, 0x08
00007f7c123df849  push rax
00007f7c123df84a  push rcx
00007f7c123df84b  push rdx
00007f7c123df84c  push rdi
00007f7c123df84d  push rsi
00007f7c123df84e  push r8
00007f7c123df850  push r9
00007f7c123df852  push r10
00007f7c123df854  push r11
00007f7c123df856  sub rsp, 0xF0
00007f7c123df85d  vmovaps [rsp], xmm0
00007f7c123df862  vmovaps [rsp+0x10], xmm1
00007f7c123df868  vmovaps [rsp+0x20], xmm2
00007f7c123df86e  vmovaps [rsp+0x30], xmm3
00007f7c123df874  vmovaps [rsp+0x40], xmm5
00007f7c123df87a  vmovaps [rsp+0x50], xmm6
00007f7c123df880  vmovaps [rsp+0x60], xmm7
00007f7c123df886  vmovaps [rsp+0x70], xmm8
00007f7c123df88c  vmovaps [rsp+0x80], xmm9
00007f7c123df895  vmovaps [rsp+0x90], xmm10
00007f7c123df89e  vmovaps [rsp+0xA0], xmm11
00007f7c123df8a7  vmovaps [rsp+0xB0], xmm12
00007f7c123df8b0  vmovaps [rsp+0xC0], xmm13
00007f7c123df8b9  vmovaps [rsp+0xD0], xmm14
00007f7c123df8c2  vmovaps [rsp+0xE0], xmm15
00007f7c123df8cb  sub rsp, 0x30
00007f7c123df8cf  movaps [rsp], xmm4
00007f7c123df8d3  movaps [rsp+0x10], xmm13
00007f7c123df8d9  movaps [rsp+0x20], xmm8
00007f7c123df8df  lea rdi, [rsp]
00007f7c123df8e3  mov esi, 0x00
00007f7c123df8e8  mov rax, 0x5E723D793530
00007f7c123df8f2  call rax
00007f7c123df8f4  movaps xmm4, [rsp]
00007f7c123df8f8  add rsp, 0x30
00007f7c123df8fc  vmovaps xmm0, [rsp]
00007f7c123df901  vmovaps xmm1, [rsp+0x10]
00007f7c123df907  vmovaps xmm2, [rsp+0x20]
00007f7c123df90d  vmovaps xmm3, [rsp+0x30]
00007f7c123df913  vmovaps xmm5, [rsp+0x40]
00007f7c123df919  vmovaps xmm6, [rsp+0x50]
00007f7c123df91f  vmovaps xmm7, [rsp+0x60]
00007f7c123df925  vmovaps xmm8, [rsp+0x70]
00007f7c123df92b  vmovaps xmm9, [rsp+0x80]
00007f7c123df934  vmovaps xmm10, [rsp+0x90]
00007f7c123df93d  vmovaps xmm11, [rsp+0xA0]
00007f7c123df946  vmovaps xmm12, [rsp+0xB0]
00007f7c123df94f  vmovaps xmm13, [rsp+0xC0]
00007f7c123df958  vmovaps xmm14, [rsp+0xD0]
00007f7c123df961  vmovaps xmm15, [rsp+0xE0]
00007f7c123df96a  add rsp, 0xF0
00007f7c123df971  pop r11
00007f7c123df973  pop r10
00007f7c123df975  pop r9
00007f7c123df977  pop r8
00007f7c123df979  pop rsi
00007f7c123df97a  pop rdi
00007f7c123df97b  pop rdx
00007f7c123df97c  pop rcx
00007f7c123df97d  pop rax
00007f7c123df97e  add rsp, 0x08
00007f7c123df982  jmp 0x00007F7C123DC43D
00007f7c123df987  sub rsp, 0x08
00007f7c123df98b  push rax
00007f7c123df98c  push rcx
00007f7c123df98d  push rdx
00007f7c123df98e  push rdi
00007f7c123df98f  push rsi
00007f7c123df990  push r8
00007f7c123df992  push r9
00007f7c123df994  push r10
00007f7c123df996  push r11
00007f7c123df998  sub rsp, 0xF0
00007f7c123df99f  vmovaps [rsp], xmm0
00007f7c123df9a4  vmovaps [rsp+0x10], xmm1
00007f7c123df9aa  vmovaps [rsp+0x20], xmm2
00007f7c123df9b0  vmovaps [rsp+0x30], xmm3
00007f7c123df9b6  vmovaps [rsp+0x40], xmm4
00007f7c123df9bc  vmovaps [rsp+0x50], xmm5
00007f7c123df9c2  vmovaps [rsp+0x60], xmm6
00007f7c123df9c8  vmovaps [rsp+0x70], xmm7
00007f7c123df9ce  vmovaps [rsp+0x80], xmm8
00007f7c123df9d7  vmovaps [rsp+0x90], xmm9
00007f7c123df9e0  vmovaps [rsp+0xA0], xmm10
00007f7c123df9e9  vmovaps [rsp+0xB0], xmm11
00007f7c123df9f2  vmovaps [rsp+0xC0], xmm12
00007f7c123df9fb  vmovaps [rsp+0xD0], xmm14
00007f7c123dfa04  vmovaps [rsp+0xE0], xmm15
00007f7c123dfa0d  sub rsp, 0x30
00007f7c123dfa11  movaps [rsp], xmm13
00007f7c123dfa16  movaps [rsp+0x10], xmm15
00007f7c123dfa1c  movaps [rsp+0x20], xmm9
00007f7c123dfa22  lea rdi, [rsp]
00007f7c123dfa26  mov esi, 0x00
00007f7c123dfa2b  mov rax, 0x5E723D793530
00007f7c123dfa35  call rax
00007f7c123dfa37  movaps xmm13, [rsp]
00007f7c123dfa3c  add rsp, 0x30
00007f7c123dfa40  vmovaps xmm0, [rsp]
00007f7c123dfa45  vmovaps xmm1, [rsp+0x10]
00007f7c123dfa4b  vmovaps xmm2, [rsp+0x20]
00007f7c123dfa51  vmovaps xmm3, [rsp+0x30]
00007f7c123dfa57  vmovaps xmm4, [rsp+0x40]
00007f7c123dfa5d  vmovaps xmm5, [rsp+0x50]
00007f7c123dfa63  vmovaps xmm6, [rsp+0x60]
00007f7c123dfa69  vmovaps xmm7, [rsp+0x70]
00007f7c123dfa6f  vmovaps xmm8, [rsp+0x80]
00007f7c123dfa78  vmovaps xmm9, [rsp+0x90]
00007f7c123dfa81  vmovaps xmm10, [rsp+0xA0]
00007f7c123dfa8a  vmovaps xmm11, [rsp+0xB0]
00007f7c123dfa93  vmovaps xmm12, [rsp+0xC0]
00007f7c123dfa9c  vmovaps xmm14, [rsp+0xD0]
00007f7c123dfaa5  vmovaps xmm15, [rsp+0xE0]
00007f7c123dfaae  add rsp, 0xF0
00007f7c123dfab5  pop r11
00007f7c123dfab7  pop r10
00007f7c123dfab9  pop r9
00007f7c123dfabb  pop r8
00007f7c123dfabd  pop rsi
00007f7c123dfabe  pop rdi
00007f7c123dfabf  pop rdx
00007f7c123dfac0  pop rcx
00007f7c123dfac1  pop rax
00007f7c123dfac2  add rsp, 0x08
00007f7c123dfac6  jmp 0x00007F7C123DC458
00007f7c123dfacb  sub rsp, 0x08
00007f7c123dfacf  push rax
00007f7c123dfad0  push rcx
00007f7c123dfad1  push rdx
00007f7c123dfad2  push rdi
00007f7c123dfad3  push rsi
00007f7c123dfad4  push r8
00007f7c123dfad6  push r9
00007f7c123dfad8  push r10
00007f7c123dfada  push r11
00007f7c123dfadc  sub rsp, 0xF0
00007f7c123dfae3  vmovaps [rsp], xmm0
00007f7c123dfae8  vmovaps [rsp+0x10], xmm1
00007f7c123dfaee  vmovaps [rsp+0x20], xmm2
00007f7c123dfaf4  vmovaps [rsp+0x30], xmm3
00007f7c123dfafa  vmovaps [rsp+0x40], xmm4
00007f7c123dfb00  vmovaps [rsp+0x50], xmm5
00007f7c123dfb06  vmovaps [rsp+0x60], xmm6
00007f7c123dfb0c  vmovaps [rsp+0x70], xmm7
00007f7c123dfb12  vmovaps [rsp+0x80], xmm8
00007f7c123dfb1b  vmovaps [rsp+0x90], xmm9
00007f7c123dfb24  vmovaps [rsp+0xA0], xmm10
00007f7c123dfb2d  vmovaps [rsp+0xB0], xmm11
00007f7c123dfb36  vmovaps [rsp+0xC0], xmm12
00007f7c123dfb3f  vmovaps [rsp+0xD0], xmm13
00007f7c123dfb48  vmovaps [rsp+0xE0], xmm14
00007f7c123dfb51  sub rsp, 0x30
00007f7c123dfb55  movaps [rsp], xmm15
00007f7c123dfb5a  movaps [rsp+0x10], xmm1
00007f7c123dfb5f  movaps [rsp+0x20], xmm5
00007f7c123dfb64  lea rdi, [rsp]
00007f7c123dfb68  mov esi, 0x00
00007f7c123dfb6d  mov rax, 0x5E723D793530
00007f7c123dfb77  call rax
00007f7c123dfb79  movaps xmm15, [rsp]
00007f7c123dfb7e  add rsp, 0x30
00007f7c123dfb82  vmovaps xmm0, [rsp]
00007f7c123dfb87  vmovaps xmm1, [rsp+0x10]
00007f7c123dfb8d  vmovaps xmm2, [rsp+0x20]
00007f7c123dfb93  vmovaps xmm3, [rsp+0x30]
00007f7c123dfb99  vmovaps xmm4, [rsp+0x40]
00007f7c123dfb9f  vmovaps xmm5, [rsp+0x50]
00007f7c123dfba5  vmovaps xmm6, [rsp+0x60]
00007f7c123dfbab  vmovaps xmm7, [rsp+0x70]
00007f7c123dfbb1  vmovaps xmm8, [rsp+0x80]
00007f7c123dfbba  vmovaps xmm9, [rsp+0x90]
00007f7c123dfbc3  vmovaps xmm10, [rsp+0xA0]
00007f7c123dfbcc  vmovaps xmm11, [rsp+0xB0]
00007f7c123dfbd5  vmovaps xmm12, [rsp+0xC0]
00007f7c123dfbde  vmovaps xmm13, [rsp+0xD0]
00007f7c123dfbe7  vmovaps xmm14, [rsp+0xE0]
00007f7c123dfbf0  add rsp, 0xF0
00007f7c123dfbf7  pop r11
00007f7c123dfbf9  pop r10
00007f7c123dfbfb  pop r9
00007f7c123dfbfd  pop r8
00007f7c123dfbff  pop rsi
00007f7c123dfc00  pop rdi
00007f7c123dfc01  pop rdx
00007f7c123dfc02  pop rcx
00007f7c123dfc03  pop rax
00007f7c123dfc04  add rsp, 0x08
00007f7c123dfc08  jmp 0x00007F7C123DC473
00007f7c123dfc0d  call 0x00007F7C122B52F0
00007f7c123dfc12  jmp 0x00007F7C123DC4CE
00007f7c123dfc17  sub rsp, 0x08
00007f7c123dfc1b  push rax
00007f7c123dfc1c  push rcx
00007f7c123dfc1d  push rdx
00007f7c123dfc1e  push rdi
00007f7c123dfc1f  push rsi
00007f7c123dfc20  push r8
00007f7c123dfc22  push r9
00007f7c123dfc24  push r10
00007f7c123dfc26  push r11
00007f7c123dfc28  sub rsp, 0xF0
00007f7c123dfc2f  vmovaps [rsp], xmm0
00007f7c123dfc34  vmovaps [rsp+0x10], xmm1
00007f7c123dfc3a  vmovaps [rsp+0x20], xmm2
00007f7c123dfc40  vmovaps [rsp+0x30], xmm3
00007f7c123dfc46  vmovaps [rsp+0x40], xmm4
00007f7c123dfc4c  vmovaps [rsp+0x50], xmm5
00007f7c123dfc52  vmovaps [rsp+0x60], xmm6
00007f7c123dfc58  vmovaps [rsp+0x70], xmm7
00007f7c123dfc5e  vmovaps [rsp+0x80], xmm8
00007f7c123dfc67  vmovaps [rsp+0x90], xmm10
00007f7c123dfc70  vmovaps [rsp+0xA0], xmm11
00007f7c123dfc79  vmovaps [rsp+0xB0], xmm12
00007f7c123dfc82  vmovaps [rsp+0xC0], xmm13
00007f7c123dfc8b  vmovaps [rsp+0xD0], xmm14
00007f7c123dfc94  vmovaps [rsp+0xE0], xmm15
00007f7c123dfc9d  sub rsp, 0x30
00007f7c123dfca1  movaps [rsp], xmm9
00007f7c123dfca6  movaps [rsp+0x10], xmm8
00007f7c123dfcac  movaps [rsp+0x20], xmm11
00007f7c123dfcb2  lea rdi, [rsp]
00007f7c123dfcb6  mov esi, 0x00
00007f7c123dfcbb  mov rax, 0x5E723D793530
00007f7c123dfcc5  call rax
00007f7c123dfcc7  movaps xmm9, [rsp]
00007f7c123dfccc  add rsp, 0x30
00007f7c123dfcd0  vmovaps xmm0, [rsp]
00007f7c123dfcd5  vmovaps xmm1, [rsp+0x10]
00007f7c123dfcdb  vmovaps xmm2, [rsp+0x20]
00007f7c123dfce1  vmovaps xmm3, [rsp+0x30]
00007f7c123dfce7  vmovaps xmm4, [rsp+0x40]
00007f7c123dfced  vmovaps xmm5, [rsp+0x50]
00007f7c123dfcf3  vmovaps xmm6, [rsp+0x60]
00007f7c123dfcf9  vmovaps xmm7, [rsp+0x70]
00007f7c123dfcff  vmovaps xmm8, [rsp+0x80]
00007f7c123dfd08  vmovaps xmm10, [rsp+0x90]
00007f7c123dfd11  vmovaps xmm11, [rsp+0xA0]
00007f7c123dfd1a  vmovaps xmm12, [rsp+0xB0]
00007f7c123dfd23  vmovaps xmm13, [rsp+0xC0]
00007f7c123dfd2c  vmovaps xmm14, [rsp+0xD0]
00007f7c123dfd35  vmovaps xmm15, [rsp+0xE0]
00007f7c123dfd3e  add rsp, 0xF0
00007f7c123dfd45  pop r11
00007f7c123dfd47  pop r10
00007f7c123dfd49  pop r9
00007f7c123dfd4b  pop r8
00007f7c123dfd4d  pop rsi
00007f7c123dfd4e  pop rdi
00007f7c123dfd4f  pop rdx
00007f7c123dfd50  pop rcx
00007f7c123dfd51  pop rax
00007f7c123dfd52  add rsp, 0x08
00007f7c123dfd56  jmp 0x00007F7C123DC505
00007f7c123dfd5b  sub rsp, 0x08
00007f7c123dfd5f  push rax
00007f7c123dfd60  push rcx
00007f7c123dfd61  push rdx
00007f7c123dfd62  push rdi
00007f7c123dfd63  push rsi
00007f7c123dfd64  push r8
00007f7c123dfd66  push r9
00007f7c123dfd68  push r10
00007f7c123dfd6a  push r11
00007f7c123dfd6c  sub rsp, 0xF0
00007f7c123dfd73  vmovaps [rsp], xmm0
00007f7c123dfd78  vmovaps [rsp+0x10], xmm1
00007f7c123dfd7e  vmovaps [rsp+0x20], xmm2
00007f7c123dfd84  vmovaps [rsp+0x30], xmm3
00007f7c123dfd8a  vmovaps [rsp+0x40], xmm4
00007f7c123dfd90  vmovaps [rsp+0x50], xmm5
00007f7c123dfd96  vmovaps [rsp+0x60], xmm6
00007f7c123dfd9c  vmovaps [rsp+0x70], xmm7
00007f7c123dfda2  vmovaps [rsp+0x80], xmm8
00007f7c123dfdab  vmovaps [rsp+0x90], xmm9
00007f7c123dfdb4  vmovaps [rsp+0xA0], xmm10
00007f7c123dfdbd  vmovaps [rsp+0xB0], xmm12
00007f7c123dfdc6  vmovaps [rsp+0xC0], xmm13
00007f7c123dfdcf  vmovaps [rsp+0xD0], xmm14
00007f7c123dfdd8  vmovaps [rsp+0xE0], xmm15
00007f7c123dfde1  sub rsp, 0x30
00007f7c123dfde5  movaps [rsp], xmm11
00007f7c123dfdea  movaps [rsp+0x10], xmm10
00007f7c123dfdf0  movaps [rsp+0x20], xmm6
00007f7c123dfdf5  lea rdi, [rsp]
00007f7c123dfdf9  mov esi, 0x00
00007f7c123dfdfe  mov rax, 0x5E723D793530
00007f7c123dfe08  call rax
00007f7c123dfe0a  movaps xmm11, [rsp]
00007f7c123dfe0f  add rsp, 0x30
00007f7c123dfe13  vmovaps xmm0, [rsp]
00007f7c123dfe18  vmovaps xmm1, [rsp+0x10]
00007f7c123dfe1e  vmovaps xmm2, [rsp+0x20]
00007f7c123dfe24  vmovaps xmm3, [rsp+0x30]
00007f7c123dfe2a  vmovaps xmm4, [rsp+0x40]
00007f7c123dfe30  vmovaps xmm5, [rsp+0x50]
00007f7c123dfe36  vmovaps xmm6, [rsp+0x60]
00007f7c123dfe3c  vmovaps xmm7, [rsp+0x70]
00007f7c123dfe42  vmovaps xmm8, [rsp+0x80]
00007f7c123dfe4b  vmovaps xmm9, [rsp+0x90]
00007f7c123dfe54  vmovaps xmm10, [rsp+0xA0]
00007f7c123dfe5d  vmovaps xmm12, [rsp+0xB0]
00007f7c123dfe66  vmovaps xmm13, [rsp+0xC0]
00007f7c123dfe6f  vmovaps xmm14, [rsp+0xD0]
00007f7c123dfe78  vmovaps xmm15, [rsp+0xE0]
00007f7c123dfe81  add rsp, 0xF0
00007f7c123dfe88  pop r11
00007f7c123dfe8a  pop r10
00007f7c123dfe8c  pop r9
00007f7c123dfe8e  pop r8
00007f7c123dfe90  pop rsi
00007f7c123dfe91  pop rdi
00007f7c123dfe92  pop rdx
00007f7c123dfe93  pop rcx
00007f7c123dfe94  pop rax
00007f7c123dfe95  add rsp, 0x08
00007f7c123dfe99  jmp 0x00007F7C123DC520
00007f7c123dfe9e  sub rsp, 0x08
00007f7c123dfea2  push rax
00007f7c123dfea3  push rcx
00007f7c123dfea4  push rdx
00007f7c123dfea5  push rdi
00007f7c123dfea6  push rsi
00007f7c123dfea7  push r8
00007f7c123dfea9  push r9
00007f7c123dfeab  push r10
00007f7c123dfead  push r11
00007f7c123dfeaf  sub rsp, 0xF0
00007f7c123dfeb6  vmovaps [rsp], xmm0
00007f7c123dfebb  vmovaps [rsp+0x10], xmm1
00007f7c123dfec1  vmovaps [rsp+0x20], xmm2
00007f7c123dfec7  vmovaps [rsp+0x30], xmm3
00007f7c123dfecd  vmovaps [rsp+0x40], xmm4
00007f7c123dfed3  vmovaps [rsp+0x50], xmm5
00007f7c123dfed9  vmovaps [rsp+0x60], xmm6
00007f7c123dfedf  vmovaps [rsp+0x70], xmm7
00007f7c123dfee5  vmovaps [rsp+0x80], xmm8
00007f7c123dfeee  vmovaps [rsp+0x90], xmm9
00007f7c123dfef7  vmovaps [rsp+0xA0], xmm11
00007f7c123dff00  vmovaps [rsp+0xB0], xmm12
00007f7c123dff09  vmovaps [rsp+0xC0], xmm13
00007f7c123dff12  vmovaps [rsp+0xD0], xmm14
00007f7c123dff1b  vmovaps [rsp+0xE0], xmm15
00007f7c123dff24  sub rsp, 0x30
00007f7c123dff28  movaps [rsp], xmm10
00007f7c123dff2d  movaps [rsp+0x10], xmm14
00007f7c123dff33  movaps [rsp+0x20], xmm4
00007f7c123dff38  lea rdi, [rsp]
00007f7c123dff3c  mov esi, 0x00
00007f7c123dff41  mov rax, 0x5E723D793530
00007f7c123dff4b  call rax
00007f7c123dff4d  movaps xmm10, [rsp]
00007f7c123dff52  add rsp, 0x30
00007f7c123dff56  vmovaps xmm0, [rsp]
00007f7c123dff5b  vmovaps xmm1, [rsp+0x10]
00007f7c123dff61  vmovaps xmm2, [rsp+0x20]
00007f7c123dff67  vmovaps xmm3, [rsp+0x30]
00007f7c123dff6d  vmovaps xmm4, [rsp+0x40]
00007f7c123dff73  vmovaps xmm5, [rsp+0x50]
00007f7c123dff79  vmovaps xmm6, [rsp+0x60]
00007f7c123dff7f  vmovaps xmm7, [rsp+0x70]
00007f7c123dff85  vmovaps xmm8, [rsp+0x80]
00007f7c123dff8e  vmovaps xmm9, [rsp+0x90]
00007f7c123dff97  vmovaps xmm11, [rsp+0xA0]
00007f7c123dffa0  vmovaps xmm12, [rsp+0xB0]
00007f7c123dffa9  vmovaps xmm13, [rsp+0xC0]
00007f7c123dffb2  vmovaps xmm14, [rsp+0xD0]
00007f7c123dffbb  vmovaps xmm15, [rsp+0xE0]
00007f7c123dffc4  add rsp, 0xF0
00007f7c123dffcb  pop r11
00007f7c123dffcd  pop r10
00007f7c123dffcf  pop r9
00007f7c123dffd1  pop r8
00007f7c123dffd3  pop rsi
00007f7c123dffd4  pop rdi
00007f7c123dffd5  pop rdx
00007f7c123dffd6  pop rcx
00007f7c123dffd7  pop rax
00007f7c123dffd8  add rsp, 0x08
00007f7c123dffdc  jmp 0x00007F7C123DC53B
00007f7c123dffe1  sub rsp, 0x08
00007f7c123dffe5  push rax
00007f7c123dffe6  push rcx
00007f7c123dffe7  push rdx
00007f7c123dffe8  push rdi
00007f7c123dffe9  push rsi
00007f7c123dffea  push r8
00007f7c123dffec  push r9
00007f7c123dffee  push r10
00007f7c123dfff0  push r11
00007f7c123dfff2  sub rsp, 0xF0
00007f7c123dfff9  vmovaps [rsp], xmm0
00007f7c123dfffe  vmovaps [rsp+0x10], xmm1
00007f7c123e0004  vmovaps [rsp+0x20], xmm2
00007f7c123e000a  vmovaps [rsp+0x30], xmm3
00007f7c123e0010  vmovaps [rsp+0x40], xmm4
00007f7c123e0016  vmovaps [rsp+0x50], xmm5
00007f7c123e001c  vmovaps [rsp+0x60], xmm6
00007f7c123e0022  vmovaps [rsp+0x70], xmm7
00007f7c123e0028  vmovaps [rsp+0x80], xmm9
00007f7c123e0031  vmovaps [rsp+0x90], xmm10
00007f7c123e003a  vmovaps [rsp+0xA0], xmm11
00007f7c123e0043  vmovaps [rsp+0xB0], xmm12
00007f7c123e004c  vmovaps [rsp+0xC0], xmm13
00007f7c123e0055  vmovaps [rsp+0xD0], xmm14
00007f7c123e005e  vmovaps [rsp+0xE0], xmm15
00007f7c123e0067  sub rsp, 0x30
00007f7c123e006b  movaps [rsp], xmm8
00007f7c123e0070  movaps [rsp+0x10], xmm1
00007f7c123e0075  movaps [rsp+0x20], xmm14
00007f7c123e007b  lea rdi, [rsp]
00007f7c123e007f  mov esi, 0x00
00007f7c123e0084  mov rax, 0x5E723D793530
00007f7c123e008e  call rax
00007f7c123e0090  movaps xmm8, [rsp]
00007f7c123e0095  add rsp, 0x30
00007f7c123e0099  vmovaps xmm0, [rsp]
00007f7c123e009e  vmovaps xmm1, [rsp+0x10]
00007f7c123e00a4  vmovaps xmm2, [rsp+0x20]
00007f7c123e00aa  vmovaps xmm3, [rsp+0x30]
00007f7c123e00b0  vmovaps xmm4, [rsp+0x40]
00007f7c123e00b6  vmovaps xmm5, [rsp+0x50]
00007f7c123e00bc  vmovaps xmm6, [rsp+0x60]
00007f7c123e00c2  vmovaps xmm7, [rsp+0x70]
00007f7c123e00c8  vmovaps xmm9, [rsp+0x80]
00007f7c123e00d1  vmovaps xmm10, [rsp+0x90]
00007f7c123e00da  vmovaps xmm11, [rsp+0xA0]
00007f7c123e00e3  vmovaps xmm12, [rsp+0xB0]
00007f7c123e00ec  vmovaps xmm13, [rsp+0xC0]
00007f7c123e00f5  vmovaps xmm14, [rsp+0xD0]
00007f7c123e00fe  vmovaps xmm15, [rsp+0xE0]
00007f7c123e0107  add rsp, 0xF0
00007f7c123e010e  pop r11
00007f7c123e0110  pop r10
00007f7c123e0112  pop r9
00007f7c123e0114  pop r8
00007f7c123e0116  pop rsi
00007f7c123e0117  pop rdi
00007f7c123e0118  pop rdx
00007f7c123e0119  pop rcx
00007f7c123e011a  pop rax
00007f7c123e011b  add rsp, 0x08
00007f7c123e011f  jmp 0x00007F7C123DC561
00007f7c123e0124  sub rsp, 0x08
00007f7c123e0128  push rax
00007f7c123e0129  push rcx
00007f7c123e012a  push rdx
00007f7c123e012b  push rdi
00007f7c123e012c  push rsi
00007f7c123e012d  push r8
00007f7c123e012f  push r9
00007f7c123e0131  push r10
00007f7c123e0133  push r11
00007f7c123e0135  sub rsp, 0xF0
00007f7c123e013c  vmovaps [rsp], xmm0
00007f7c123e0141  vmovaps [rsp+0x10], xmm1
00007f7c123e0147  vmovaps [rsp+0x20], xmm2
00007f7c123e014d  vmovaps [rsp+0x30], xmm3
00007f7c123e0153  vmovaps [rsp+0x40], xmm4
00007f7c123e0159  vmovaps [rsp+0x50], xmm5
00007f7c123e015f  vmovaps [rsp+0x60], xmm7
00007f7c123e0165  vmovaps [rsp+0x70], xmm8
00007f7c123e016b  vmovaps [rsp+0x80], xmm9
00007f7c123e0174  vmovaps [rsp+0x90], xmm10
00007f7c123e017d  vmovaps [rsp+0xA0], xmm11
00007f7c123e0186  vmovaps [rsp+0xB0], xmm12
00007f7c123e018f  vmovaps [rsp+0xC0], xmm13
00007f7c123e0198  vmovaps [rsp+0xD0], xmm14
00007f7c123e01a1  vmovaps [rsp+0xE0], xmm15
00007f7c123e01aa  sub rsp, 0x30
00007f7c123e01ae  movaps [rsp], xmm6
00007f7c123e01b2  movaps [rsp+0x10], xmm1
00007f7c123e01b7  movaps [rsp+0x20], xmm14
00007f7c123e01bd  lea rdi, [rsp]
00007f7c123e01c1  mov esi, 0x00
00007f7c123e01c6  mov rax, 0x5E723D793530
00007f7c123e01d0  call rax
00007f7c123e01d2  movaps xmm6, [rsp]
00007f7c123e01d6  add rsp, 0x30
00007f7c123e01da  vmovaps xmm0, [rsp]
00007f7c123e01df  vmovaps xmm1, [rsp+0x10]
00007f7c123e01e5  vmovaps xmm2, [rsp+0x20]
00007f7c123e01eb  vmovaps xmm3, [rsp+0x30]
00007f7c123e01f1  vmovaps xmm4, [rsp+0x40]
00007f7c123e01f7  vmovaps xmm5, [rsp+0x50]
00007f7c123e01fd  vmovaps xmm7, [rsp+0x60]
00007f7c123e0203  vmovaps xmm8, [rsp+0x70]
00007f7c123e0209  vmovaps xmm9, [rsp+0x80]
00007f7c123e0212  vmovaps xmm10, [rsp+0x90]
00007f7c123e021b  vmovaps xmm11, [rsp+0xA0]
00007f7c123e0224  vmovaps xmm12, [rsp+0xB0]
00007f7c123e022d  vmovaps xmm13, [rsp+0xC0]
00007f7c123e0236  vmovaps xmm14, [rsp+0xD0]
00007f7c123e023f  vmovaps xmm15, [rsp+0xE0]
00007f7c123e0248  add rsp, 0xF0
00007f7c123e024f  pop r11
00007f7c123e0251  pop r10
00007f7c123e0253  pop r9
00007f7c123e0255  pop r8
00007f7c123e0257  pop rsi
00007f7c123e0258  pop rdi
00007f7c123e0259  pop rdx
00007f7c123e025a  pop rcx
00007f7c123e025b  pop rax
00007f7c123e025c  add rsp, 0x08
00007f7c123e0260  jmp 0x00007F7C123DC58D
00007f7c123e0265  sub rsp, 0x08
00007f7c123e0269  push rax
00007f7c123e026a  push rcx
00007f7c123e026b  push rdx
00007f7c123e026c  push rdi
00007f7c123e026d  push rsi
00007f7c123e026e  push r8
00007f7c123e0270  push r9
00007f7c123e0272  push r10
00007f7c123e0274  push r11
00007f7c123e0276  sub rsp, 0xF0
00007f7c123e027d  vmovaps [rsp], xmm0
00007f7c123e0282  vmovaps [rsp+0x10], xmm1
00007f7c123e0288  vmovaps [rsp+0x20], xmm2
00007f7c123e028e  vmovaps [rsp+0x30], xmm3
00007f7c123e0294  vmovaps [rsp+0x40], xmm4
00007f7c123e029a  vmovaps [rsp+0x50], xmm5
00007f7c123e02a0  vmovaps [rsp+0x60], xmm6
00007f7c123e02a6  vmovaps [rsp+0x70], xmm7
00007f7c123e02ac  vmovaps [rsp+0x80], xmm8
00007f7c123e02b5  vmovaps [rsp+0x90], xmm9
00007f7c123e02be  vmovaps [rsp+0xA0], xmm10
00007f7c123e02c7  vmovaps [rsp+0xB0], xmm11
00007f7c123e02d0  vmovaps [rsp+0xC0], xmm12
00007f7c123e02d9  vmovaps [rsp+0xD0], xmm13
00007f7c123e02e2  vmovaps [rsp+0xE0], xmm15
00007f7c123e02eb  sub rsp, 0x30
00007f7c123e02ef  movaps [rsp], xmm14
00007f7c123e02f4  movaps [rsp+0x10], xmm12
00007f7c123e02fa  movaps [rsp+0x20], xmm1
00007f7c123e02ff  lea rdi, [rsp]
00007f7c123e0303  mov esi, 0x00
00007f7c123e0308  mov rax, 0x5E723D793530
00007f7c123e0312  call rax
00007f7c123e0314  movaps xmm14, [rsp]
00007f7c123e0319  add rsp, 0x30
00007f7c123e031d  vmovaps xmm0, [rsp]
00007f7c123e0322  vmovaps xmm1, [rsp+0x10]
00007f7c123e0328  vmovaps xmm2, [rsp+0x20]
00007f7c123e032e  vmovaps xmm3, [rsp+0x30]
00007f7c123e0334  vmovaps xmm4, [rsp+0x40]
00007f7c123e033a  vmovaps xmm5, [rsp+0x50]
00007f7c123e0340  vmovaps xmm6, [rsp+0x60]
00007f7c123e0346  vmovaps xmm7, [rsp+0x70]
00007f7c123e034c  vmovaps xmm8, [rsp+0x80]
00007f7c123e0355  vmovaps xmm9, [rsp+0x90]
00007f7c123e035e  vmovaps xmm10, [rsp+0xA0]
00007f7c123e0367  vmovaps xmm11, [rsp+0xB0]
00007f7c123e0370  vmovaps xmm12, [rsp+0xC0]
00007f7c123e0379  vmovaps xmm13, [rsp+0xD0]
00007f7c123e0382  vmovaps xmm15, [rsp+0xE0]
00007f7c123e038b  add rsp, 0xF0
00007f7c123e0392  pop r11
00007f7c123e0394  pop r10
00007f7c123e0396  pop r9
00007f7c123e0398  pop r8
00007f7c123e039a  pop rsi
00007f7c123e039b  pop rdi
00007f7c123e039c  pop rdx
00007f7c123e039d  pop rcx
00007f7c123e039e  pop rax
00007f7c123e039f  add rsp, 0x08
00007f7c123e03a3  jmp 0x00007F7C123DC5B3
00007f7c123e03a8  sub rsp, 0x08
00007f7c123e03ac  push rax
00007f7c123e03ad  push rcx
00007f7c123e03ae  push rdx
00007f7c123e03af  push rdi
00007f7c123e03b0  push rsi
00007f7c123e03b1  push r8
00007f7c123e03b3  push r9
00007f7c123e03b5  push r10
00007f7c123e03b7  push r11
00007f7c123e03b9  sub rsp, 0xF0
00007f7c123e03c0  vmovaps [rsp], xmm0
00007f7c123e03c5  vmovaps [rsp+0x10], xmm2
00007f7c123e03cb  vmovaps [rsp+0x20], xmm3
00007f7c123e03d1  vmovaps [rsp+0x30], xmm4
00007f7c123e03d7  vmovaps [rsp+0x40], xmm5
00007f7c123e03dd  vmovaps [rsp+0x50], xmm6
00007f7c123e03e3  vmovaps [rsp+0x60], xmm7
00007f7c123e03e9  vmovaps [rsp+0x70], xmm8
00007f7c123e03ef  vmovaps [rsp+0x80], xmm9
00007f7c123e03f8  vmovaps [rsp+0x90], xmm10
00007f7c123e0401  vmovaps [rsp+0xA0], xmm11
00007f7c123e040a  vmovaps [rsp+0xB0], xmm12
00007f7c123e0413  vmovaps [rsp+0xC0], xmm13
00007f7c123e041c  vmovaps [rsp+0xD0], xmm14
00007f7c123e0425  vmovaps [rsp+0xE0], xmm15
00007f7c123e042e  sub rsp, 0x30
00007f7c123e0432  movaps [rsp], xmm1
00007f7c123e0436  movaps [rsp+0x10], xmm13
00007f7c123e043c  movaps [rsp+0x20], xmm9
00007f7c123e0442  lea rdi, [rsp]
00007f7c123e0446  mov esi, 0x00
00007f7c123e044b  mov rax, 0x5E723D793530
00007f7c123e0455  call rax
00007f7c123e0457  movaps xmm1, [rsp]
00007f7c123e045b  add rsp, 0x30
00007f7c123e045f  vmovaps xmm0, [rsp]
00007f7c123e0464  vmovaps xmm2, [rsp+0x10]
00007f7c123e046a  vmovaps xmm3, [rsp+0x20]
00007f7c123e0470  vmovaps xmm4, [rsp+0x30]
00007f7c123e0476  vmovaps xmm5, [rsp+0x40]
00007f7c123e047c  vmovaps xmm6, [rsp+0x50]
00007f7c123e0482  vmovaps xmm7, [rsp+0x60]
00007f7c123e0488  vmovaps xmm8, [rsp+0x70]
00007f7c123e048e  vmovaps xmm9, [rsp+0x80]
00007f7c123e0497  vmovaps xmm10, [rsp+0x90]
00007f7c123e04a0  vmovaps xmm11, [rsp+0xA0]
00007f7c123e04a9  vmovaps xmm12, [rsp+0xB0]
00007f7c123e04b2  vmovaps xmm13, [rsp+0xC0]
00007f7c123e04bb  vmovaps xmm14, [rsp+0xD0]
00007f7c123e04c4  vmovaps xmm15, [rsp+0xE0]
00007f7c123e04cd  add rsp, 0xF0
00007f7c123e04d4  pop r11
00007f7c123e04d6  pop r10
00007f7c123e04d8  pop r9
00007f7c123e04da  pop r8
00007f7c123e04dc  pop rsi
00007f7c123e04dd  pop rdi
00007f7c123e04de  pop rdx
00007f7c123e04df  pop rcx
00007f7c123e04e0  pop rax
00007f7c123e04e1  add rsp, 0x08
00007f7c123e04e5  jmp 0x00007F7C123DC5CD
00007f7c123e04ea  sub rsp, 0x08
00007f7c123e04ee  push rax
00007f7c123e04ef  push rcx
00007f7c123e04f0  push rdx
00007f7c123e04f1  push rdi
00007f7c123e04f2  push rsi
00007f7c123e04f3  push r8
00007f7c123e04f5  push r9
00007f7c123e04f7  push r10
00007f7c123e04f9  push r11
00007f7c123e04fb  sub rsp, 0xF0
00007f7c123e0502  vmovaps [rsp], xmm0
00007f7c123e0507  vmovaps [rsp+0x10], xmm1
00007f7c123e050d  vmovaps [rsp+0x20], xmm2
00007f7c123e0513  vmovaps [rsp+0x30], xmm3
00007f7c123e0519  vmovaps [rsp+0x40], xmm4
00007f7c123e051f  vmovaps [rsp+0x50], xmm5
00007f7c123e0525  vmovaps [rsp+0x60], xmm6
00007f7c123e052b  vmovaps [rsp+0x70], xmm7
00007f7c123e0531  vmovaps [rsp+0x80], xmm8
00007f7c123e053a  vmovaps [rsp+0x90], xmm9
00007f7c123e0543  vmovaps [rsp+0xA0], xmm10
00007f7c123e054c  vmovaps [rsp+0xB0], xmm11
00007f7c123e0555  vmovaps [rsp+0xC0], xmm13
00007f7c123e055e  vmovaps [rsp+0xD0], xmm14
00007f7c123e0567  vmovaps [rsp+0xE0], xmm15
00007f7c123e0570  sub rsp, 0x30
00007f7c123e0574  movaps [rsp], xmm12
00007f7c123e0579  movaps [rsp+0x10], xmm7
00007f7c123e057e  movaps [rsp+0x20], xmm13
00007f7c123e0584  lea rdi, [rsp]
00007f7c123e0588  mov esi, 0x00
00007f7c123e058d  mov rax, 0x5E723D793530
00007f7c123e0597  call rax
00007f7c123e0599  movaps xmm12, [rsp]
00007f7c123e059e  add rsp, 0x30
00007f7c123e05a2  vmovaps xmm0, [rsp]
00007f7c123e05a7  vmovaps xmm1, [rsp+0x10]
00007f7c123e05ad  vmovaps xmm2, [rsp+0x20]
00007f7c123e05b3  vmovaps xmm3, [rsp+0x30]
00007f7c123e05b9  vmovaps xmm4, [rsp+0x40]
00007f7c123e05bf  vmovaps xmm5, [rsp+0x50]
00007f7c123e05c5  vmovaps xmm6, [rsp+0x60]
00007f7c123e05cb  vmovaps xmm7, [rsp+0x70]
00007f7c123e05d1  vmovaps xmm8, [rsp+0x80]
00007f7c123e05da  vmovaps xmm9, [rsp+0x90]
00007f7c123e05e3  vmovaps xmm10, [rsp+0xA0]
00007f7c123e05ec  vmovaps xmm11, [rsp+0xB0]
00007f7c123e05f5  vmovaps xmm13, [rsp+0xC0]
00007f7c123e05fe  vmovaps xmm14, [rsp+0xD0]
00007f7c123e0607  vmovaps xmm15, [rsp+0xE0]
00007f7c123e0610  add rsp, 0xF0
00007f7c123e0617  pop r11
00007f7c123e0619  pop r10
00007f7c123e061b  pop r9
00007f7c123e061d  pop r8
00007f7c123e061f  pop rsi
00007f7c123e0620  pop rdi
00007f7c123e0621  pop rdx
00007f7c123e0622  pop rcx
00007f7c123e0623  pop rax
00007f7c123e0624  add rsp, 0x08
00007f7c123e0628  jmp 0x00007F7C123DC5F4
00007f7c123e062d  sub rsp, 0x08
00007f7c123e0631  push rax
00007f7c123e0632  push rcx
00007f7c123e0633  push rdx
00007f7c123e0634  push rdi
00007f7c123e0635  push rsi
00007f7c123e0636  push r8
00007f7c123e0638  push r9
00007f7c123e063a  push r10
00007f7c123e063c  push r11
00007f7c123e063e  sub rsp, 0xF0
00007f7c123e0645  vmovaps [rsp], xmm0
00007f7c123e064a  vmovaps [rsp+0x10], xmm1
00007f7c123e0650  vmovaps [rsp+0x20], xmm2
00007f7c123e0656  vmovaps [rsp+0x30], xmm3
00007f7c123e065c  vmovaps [rsp+0x40], xmm4
00007f7c123e0662  vmovaps [rsp+0x50], xmm5
00007f7c123e0668  vmovaps [rsp+0x60], xmm6
00007f7c123e066e  vmovaps [rsp+0x70], xmm7
00007f7c123e0674  vmovaps [rsp+0x80], xmm8
00007f7c123e067d  vmovaps [rsp+0x90], xmm9
00007f7c123e0686  vmovaps [rsp+0xA0], xmm10
00007f7c123e068f  vmovaps [rsp+0xB0], xmm11
00007f7c123e0698  vmovaps [rsp+0xC0], xmm12
00007f7c123e06a1  vmovaps [rsp+0xD0], xmm14
00007f7c123e06aa  vmovaps [rsp+0xE0], xmm15
00007f7c123e06b3  sub rsp, 0x30
00007f7c123e06b7  movaps [rsp], xmm13
00007f7c123e06bc  movaps [rsp+0x10], xmm15
00007f7c123e06c2  movaps [rsp+0x20], xmm8
00007f7c123e06c8  lea rdi, [rsp]
00007f7c123e06cc  mov esi, 0x00
00007f7c123e06d1  mov rax, 0x5E723D793530
00007f7c123e06db  call rax
00007f7c123e06dd  movaps xmm13, [rsp]
00007f7c123e06e2  add rsp, 0x30
00007f7c123e06e6  vmovaps xmm0, [rsp]
00007f7c123e06eb  vmovaps xmm1, [rsp+0x10]
00007f7c123e06f1  vmovaps xmm2, [rsp+0x20]
00007f7c123e06f7  vmovaps xmm3, [rsp+0x30]
00007f7c123e06fd  vmovaps xmm4, [rsp+0x40]
00007f7c123e0703  vmovaps xmm5, [rsp+0x50]
00007f7c123e0709  vmovaps xmm6, [rsp+0x60]
00007f7c123e070f  vmovaps xmm7, [rsp+0x70]
00007f7c123e0715  vmovaps xmm8, [rsp+0x80]
00007f7c123e071e  vmovaps xmm9, [rsp+0x90]
00007f7c123e0727  vmovaps xmm10, [rsp+0xA0]
00007f7c123e0730  vmovaps xmm11, [rsp+0xB0]
00007f7c123e0739  vmovaps xmm12, [rsp+0xC0]
00007f7c123e0742  vmovaps xmm14, [rsp+0xD0]
00007f7c123e074b  vmovaps xmm15, [rsp+0xE0]
00007f7c123e0754  add rsp, 0xF0
00007f7c123e075b  pop r11
00007f7c123e075d  pop r10
00007f7c123e075f  pop r9
00007f7c123e0761  pop r8
00007f7c123e0763  pop rsi
00007f7c123e0764  pop rdi
00007f7c123e0765  pop rdx
00007f7c123e0766  pop rcx
00007f7c123e0767  pop rax
00007f7c123e0768  add rsp, 0x08
00007f7c123e076c  jmp 0x00007F7C123DC60F
00007f7c123e0771  sub rsp, 0x08
00007f7c123e0775  push rax
00007f7c123e0776  push rcx
00007f7c123e0777  push rdx
00007f7c123e0778  push rdi
00007f7c123e0779  push rsi
00007f7c123e077a  push r8
00007f7c123e077c  push r9
00007f7c123e077e  push r10
00007f7c123e0780  push r11
00007f7c123e0782  sub rsp, 0xF0
00007f7c123e0789  vmovaps [rsp], xmm0
00007f7c123e078e  vmovaps [rsp+0x10], xmm1
00007f7c123e0794  vmovaps [rsp+0x20], xmm2
00007f7c123e079a  vmovaps [rsp+0x30], xmm3
00007f7c123e07a0  vmovaps [rsp+0x40], xmm4
00007f7c123e07a6  vmovaps [rsp+0x50], xmm5
00007f7c123e07ac  vmovaps [rsp+0x60], xmm6
00007f7c123e07b2  vmovaps [rsp+0x70], xmm7
00007f7c123e07b8  vmovaps [rsp+0x80], xmm9
00007f7c123e07c1  vmovaps [rsp+0x90], xmm10
00007f7c123e07ca  vmovaps [rsp+0xA0], xmm11
00007f7c123e07d3  vmovaps [rsp+0xB0], xmm12
00007f7c123e07dc  vmovaps [rsp+0xC0], xmm13
00007f7c123e07e5  vmovaps [rsp+0xD0], xmm14
00007f7c123e07ee  vmovaps [rsp+0xE0], xmm15
00007f7c123e07f7  sub rsp, 0x30
00007f7c123e07fb  movaps [rsp], xmm8
00007f7c123e0800  movaps [rsp+0x10], xmm15
00007f7c123e0806  movaps [rsp+0x20], xmm9
00007f7c123e080c  lea rdi, [rsp]
00007f7c123e0810  mov esi, 0x00
00007f7c123e0815  mov rax, 0x5E723D793530
00007f7c123e081f  call rax
00007f7c123e0821  movaps xmm8, [rsp]
00007f7c123e0826  add rsp, 0x30
00007f7c123e082a  vmovaps xmm0, [rsp]
00007f7c123e082f  vmovaps xmm1, [rsp+0x10]
00007f7c123e0835  vmovaps xmm2, [rsp+0x20]
00007f7c123e083b  vmovaps xmm3, [rsp+0x30]
00007f7c123e0841  vmovaps xmm4, [rsp+0x40]
00007f7c123e0847  vmovaps xmm5, [rsp+0x50]
00007f7c123e084d  vmovaps xmm6, [rsp+0x60]
00007f7c123e0853  vmovaps xmm7, [rsp+0x70]
00007f7c123e0859  vmovaps xmm9, [rsp+0x80]
00007f7c123e0862  vmovaps xmm10, [rsp+0x90]
00007f7c123e086b  vmovaps xmm11, [rsp+0xA0]
00007f7c123e0874  vmovaps xmm12, [rsp+0xB0]
00007f7c123e087d  vmovaps xmm13, [rsp+0xC0]
00007f7c123e0886  vmovaps xmm14, [rsp+0xD0]
00007f7c123e088f  vmovaps xmm15, [rsp+0xE0]
00007f7c123e0898  add rsp, 0xF0
00007f7c123e089f  pop r11
00007f7c123e08a1  pop r10
00007f7c123e08a3  pop r9
00007f7c123e08a5  pop r8
00007f7c123e08a7  pop rsi
00007f7c123e08a8  pop rdi
00007f7c123e08a9  pop rdx
00007f7c123e08aa  pop rcx
00007f7c123e08ab  pop rax
00007f7c123e08ac  add rsp, 0x08
00007f7c123e08b0  jmp 0x00007F7C123DC63D
00007f7c123e08b5  sub rsp, 0x08
00007f7c123e08b9  push rax
00007f7c123e08ba  push rcx
00007f7c123e08bb  push rdx
00007f7c123e08bc  push rdi
00007f7c123e08bd  push rsi
00007f7c123e08be  push r8
00007f7c123e08c0  push r9
00007f7c123e08c2  push r10
00007f7c123e08c4  push r11
00007f7c123e08c6  sub rsp, 0xF0
00007f7c123e08cd  vmovaps [rsp], xmm0
00007f7c123e08d2  vmovaps [rsp+0x10], xmm1
00007f7c123e08d8  vmovaps [rsp+0x20], xmm2
00007f7c123e08de  vmovaps [rsp+0x30], xmm3
00007f7c123e08e4  vmovaps [rsp+0x40], xmm4
00007f7c123e08ea  vmovaps [rsp+0x50], xmm5
00007f7c123e08f0  vmovaps [rsp+0x60], xmm6
00007f7c123e08f6  vmovaps [rsp+0x70], xmm7
00007f7c123e08fc  vmovaps [rsp+0x80], xmm8
00007f7c123e0905  vmovaps [rsp+0x90], xmm9
00007f7c123e090e  vmovaps [rsp+0xA0], xmm10
00007f7c123e0917  vmovaps [rsp+0xB0], xmm11
00007f7c123e0920  vmovaps [rsp+0xC0], xmm12
00007f7c123e0929  vmovaps [rsp+0xD0], xmm13
00007f7c123e0932  vmovaps [rsp+0xE0], xmm14
00007f7c123e093b  sub rsp, 0x30
00007f7c123e093f  movaps [rsp], xmm15
00007f7c123e0944  movaps [rsp+0x10], xmm11
00007f7c123e094a  movaps [rsp+0x20], xmm6
00007f7c123e094f  lea rdi, [rsp]
00007f7c123e0953  mov esi, 0x00
00007f7c123e0958  mov rax, 0x5E723D793530
00007f7c123e0962  call rax
00007f7c123e0964  movaps xmm15, [rsp]
00007f7c123e0969  add rsp, 0x30
00007f7c123e096d  vmovaps xmm0, [rsp]
00007f7c123e0972  vmovaps xmm1, [rsp+0x10]
00007f7c123e0978  vmovaps xmm2, [rsp+0x20]
00007f7c123e097e  vmovaps xmm3, [rsp+0x30]
00007f7c123e0984  vmovaps xmm4, [rsp+0x40]
00007f7c123e098a  vmovaps xmm5, [rsp+0x50]
00007f7c123e0990  vmovaps xmm6, [rsp+0x60]
00007f7c123e0996  vmovaps xmm7, [rsp+0x70]
00007f7c123e099c  vmovaps xmm8, [rsp+0x80]
00007f7c123e09a5  vmovaps xmm9, [rsp+0x90]
00007f7c123e09ae  vmovaps xmm10, [rsp+0xA0]
00007f7c123e09b7  vmovaps xmm11, [rsp+0xB0]
00007f7c123e09c0  vmovaps xmm12, [rsp+0xC0]
00007f7c123e09c9  vmovaps xmm13, [rsp+0xD0]
00007f7c123e09d2  vmovaps xmm14, [rsp+0xE0]
00007f7c123e09db  add rsp, 0xF0
00007f7c123e09e2  pop r11
00007f7c123e09e4  pop r10
00007f7c123e09e6  pop r9
00007f7c123e09e8  pop r8
00007f7c123e09ea  pop rsi
00007f7c123e09eb  pop rdi
00007f7c123e09ec  pop rdx
00007f7c123e09ed  pop rcx
00007f7c123e09ee  pop rax
00007f7c123e09ef  add rsp, 0x08
00007f7c123e09f3  jmp 0x00007F7C123DC658
00007f7c123e09f8  sub rsp, 0x08
00007f7c123e09fc  push rax
00007f7c123e09fd  push rcx
00007f7c123e09fe  push rdx
00007f7c123e09ff  push rdi
00007f7c123e0a00  push rsi
00007f7c123e0a01  push r8
00007f7c123e0a03  push r9
00007f7c123e0a05  push r10
00007f7c123e0a07  push r11
00007f7c123e0a09  sub rsp, 0xF0
00007f7c123e0a10  vmovaps [rsp], xmm0
00007f7c123e0a15  vmovaps [rsp+0x10], xmm1
00007f7c123e0a1b  vmovaps [rsp+0x20], xmm2
00007f7c123e0a21  vmovaps [rsp+0x30], xmm3
00007f7c123e0a27  vmovaps [rsp+0x40], xmm4
00007f7c123e0a2d  vmovaps [rsp+0x50], xmm5
00007f7c123e0a33  vmovaps [rsp+0x60], xmm6
00007f7c123e0a39  vmovaps [rsp+0x70], xmm8
00007f7c123e0a3f  vmovaps [rsp+0x80], xmm9
00007f7c123e0a48  vmovaps [rsp+0x90], xmm10
00007f7c123e0a51  vmovaps [rsp+0xA0], xmm11
00007f7c123e0a5a  vmovaps [rsp+0xB0], xmm12
00007f7c123e0a63  vmovaps [rsp+0xC0], xmm13
00007f7c123e0a6c  vmovaps [rsp+0xD0], xmm14
00007f7c123e0a75  vmovaps [rsp+0xE0], xmm15
00007f7c123e0a7e  sub rsp, 0x30
00007f7c123e0a82  movaps [rsp], xmm7
00007f7c123e0a86  movaps [rsp+0x10], xmm11
00007f7c123e0a8c  movaps [rsp+0x20], xmm9
00007f7c123e0a92  lea rdi, [rsp]
00007f7c123e0a96  mov esi, 0x00
00007f7c123e0a9b  mov rax, 0x5E723D793530
00007f7c123e0aa5  call rax
00007f7c123e0aa7  movaps xmm7, [rsp]
00007f7c123e0aab  add rsp, 0x30
00007f7c123e0aaf  vmovaps xmm0, [rsp]
00007f7c123e0ab4  vmovaps xmm1, [rsp+0x10]
00007f7c123e0aba  vmovaps xmm2, [rsp+0x20]
00007f7c123e0ac0  vmovaps xmm3, [rsp+0x30]
00007f7c123e0ac6  vmovaps xmm4, [rsp+0x40]
00007f7c123e0acc  vmovaps xmm5, [rsp+0x50]
00007f7c123e0ad2  vmovaps xmm6, [rsp+0x60]
00007f7c123e0ad8  vmovaps xmm8, [rsp+0x70]
00007f7c123e0ade  vmovaps xmm9, [rsp+0x80]
00007f7c123e0ae7  vmovaps xmm10, [rsp+0x90]
00007f7c123e0af0  vmovaps xmm11, [rsp+0xA0]
00007f7c123e0af9  vmovaps xmm12, [rsp+0xB0]
00007f7c123e0b02  vmovaps xmm13, [rsp+0xC0]
00007f7c123e0b0b  vmovaps xmm14, [rsp+0xD0]
00007f7c123e0b14  vmovaps xmm15, [rsp+0xE0]
00007f7c123e0b1d  add rsp, 0xF0
00007f7c123e0b24  pop r11
00007f7c123e0b26  pop r10
00007f7c123e0b28  pop r9
00007f7c123e0b2a  pop r8
00007f7c123e0b2c  pop rsi
00007f7c123e0b2d  pop rdi
00007f7c123e0b2e  pop rdx
00007f7c123e0b2f  pop rcx
00007f7c123e0b30  pop rax
00007f7c123e0b31  add rsp, 0x08
00007f7c123e0b35  jmp 0x00007F7C123DC685
00007f7c123e0b3a  sub rsp, 0x08
00007f7c123e0b3e  push rax
00007f7c123e0b3f  push rcx
00007f7c123e0b40  push rdx
00007f7c123e0b41  push rdi
00007f7c123e0b42  push rsi
00007f7c123e0b43  push r8
00007f7c123e0b45  push r9
00007f7c123e0b47  push r10
00007f7c123e0b49  push r11
00007f7c123e0b4b  sub rsp, 0xF0
00007f7c123e0b52  vmovaps [rsp], xmm0
00007f7c123e0b57  vmovaps [rsp+0x10], xmm1
00007f7c123e0b5d  vmovaps [rsp+0x20], xmm2
00007f7c123e0b63  vmovaps [rsp+0x30], xmm3
00007f7c123e0b69  vmovaps [rsp+0x40], xmm4
00007f7c123e0b6f  vmovaps [rsp+0x50], xmm5
00007f7c123e0b75  vmovaps [rsp+0x60], xmm6
00007f7c123e0b7b  vmovaps [rsp+0x70], xmm7
00007f7c123e0b81  vmovaps [rsp+0x80], xmm8
00007f7c123e0b8a  vmovaps [rsp+0x90], xmm9
00007f7c123e0b93  vmovaps [rsp+0xA0], xmm10
00007f7c123e0b9c  vmovaps [rsp+0xB0], xmm12
00007f7c123e0ba5  vmovaps [rsp+0xC0], xmm13
00007f7c123e0bae  vmovaps [rsp+0xD0], xmm14
00007f7c123e0bb7  vmovaps [rsp+0xE0], xmm15
00007f7c123e0bc0  sub rsp, 0x30
00007f7c123e0bc4  movaps [rsp], xmm11
00007f7c123e0bc9  movaps [rsp+0x10], xmm10
00007f7c123e0bcf  movaps [rsp+0x20], xmm14
00007f7c123e0bd5  lea rdi, [rsp]
00007f7c123e0bd9  mov esi, 0x00
00007f7c123e0bde  mov rax, 0x5E723D793530
00007f7c123e0be8  call rax
00007f7c123e0bea  movaps xmm11, [rsp]
00007f7c123e0bef  add rsp, 0x30
00007f7c123e0bf3  vmovaps xmm0, [rsp]
00007f7c123e0bf8  vmovaps xmm1, [rsp+0x10]
00007f7c123e0bfe  vmovaps xmm2, [rsp+0x20]
00007f7c123e0c04  vmovaps xmm3, [rsp+0x30]
00007f7c123e0c0a  vmovaps xmm4, [rsp+0x40]
00007f7c123e0c10  vmovaps xmm5, [rsp+0x50]
00007f7c123e0c16  vmovaps xmm6, [rsp+0x60]
00007f7c123e0c1c  vmovaps xmm7, [rsp+0x70]
00007f7c123e0c22  vmovaps xmm8, [rsp+0x80]
00007f7c123e0c2b  vmovaps xmm9, [rsp+0x90]
00007f7c123e0c34  vmovaps xmm10, [rsp+0xA0]
00007f7c123e0c3d  vmovaps xmm12, [rsp+0xB0]
00007f7c123e0c46  vmovaps xmm13, [rsp+0xC0]
00007f7c123e0c4f  vmovaps xmm14, [rsp+0xD0]
00007f7c123e0c58  vmovaps xmm15, [rsp+0xE0]
00007f7c123e0c61  add rsp, 0xF0
00007f7c123e0c68  pop r11
00007f7c123e0c6a  pop r10
00007f7c123e0c6c  pop r9
00007f7c123e0c6e  pop r8
00007f7c123e0c70  pop rsi
00007f7c123e0c71  pop rdi
00007f7c123e0c72  pop rdx
00007f7c123e0c73  pop rcx
00007f7c123e0c74  pop rax
00007f7c123e0c75  add rsp, 0x08
00007f7c123e0c79  jmp 0x00007F7C123DC6A0
00007f7c123e0c7e  call 0x00007F7C122C33A0
00007f7c123e0c83  jmp 0x00007F7C123DC6AA
00007f7c123e0c88  sub rsp, 0x08
00007f7c123e0c8c  push rax
00007f7c123e0c8d  push rcx
00007f7c123e0c8e  push rdx
00007f7c123e0c8f  push rdi
00007f7c123e0c90  push rsi
00007f7c123e0c91  push r8
00007f7c123e0c93  push r9
00007f7c123e0c95  push r10
00007f7c123e0c97  push r11
00007f7c123e0c99  sub rsp, 0xF0
00007f7c123e0ca0  vmovaps [rsp], xmm0
00007f7c123e0ca5  vmovaps [rsp+0x10], xmm1
00007f7c123e0cab  vmovaps [rsp+0x20], xmm2
00007f7c123e0cb1  vmovaps [rsp+0x30], xmm3
00007f7c123e0cb7  vmovaps [rsp+0x40], xmm4
00007f7c123e0cbd  vmovaps [rsp+0x50], xmm5
00007f7c123e0cc3  vmovaps [rsp+0x60], xmm6
00007f7c123e0cc9  vmovaps [rsp+0x70], xmm7
00007f7c123e0ccf  vmovaps [rsp+0x80], xmm8
00007f7c123e0cd8  vmovaps [rsp+0x90], xmm9
00007f7c123e0ce1  vmovaps [rsp+0xA0], xmm11
00007f7c123e0cea  vmovaps [rsp+0xB0], xmm12
00007f7c123e0cf3  vmovaps [rsp+0xC0], xmm13
00007f7c123e0cfc  vmovaps [rsp+0xD0], xmm14
00007f7c123e0d05  vmovaps [rsp+0xE0], xmm15
00007f7c123e0d0e  sub rsp, 0x30
00007f7c123e0d12  movaps [rsp], xmm10
00007f7c123e0d17  movaps [rsp+0x10], xmm1
00007f7c123e0d1c  movaps [rsp+0x20], xmm12
00007f7c123e0d22  lea rdi, [rsp]
00007f7c123e0d26  mov esi, 0x00
00007f7c123e0d2b  mov rax, 0x5E723D793530
00007f7c123e0d35  call rax
00007f7c123e0d37  movaps xmm10, [rsp]
00007f7c123e0d3c  add rsp, 0x30
00007f7c123e0d40  vmovaps xmm0, [rsp]
00007f7c123e0d45  vmovaps xmm1, [rsp+0x10]
00007f7c123e0d4b  vmovaps xmm2, [rsp+0x20]
00007f7c123e0d51  vmovaps xmm3, [rsp+0x30]
00007f7c123e0d57  vmovaps xmm4, [rsp+0x40]
00007f7c123e0d5d  vmovaps xmm5, [rsp+0x50]
00007f7c123e0d63  vmovaps xmm6, [rsp+0x60]
00007f7c123e0d69  vmovaps xmm7, [rsp+0x70]
00007f7c123e0d6f  vmovaps xmm8, [rsp+0x80]
00007f7c123e0d78  vmovaps xmm9, [rsp+0x90]
00007f7c123e0d81  vmovaps xmm11, [rsp+0xA0]
00007f7c123e0d8a  vmovaps xmm12, [rsp+0xB0]
00007f7c123e0d93  vmovaps xmm13, [rsp+0xC0]
00007f7c123e0d9c  vmovaps xmm14, [rsp+0xD0]
00007f7c123e0da5  vmovaps xmm15, [rsp+0xE0]
00007f7c123e0dae  add rsp, 0xF0
00007f7c123e0db5  pop r11
00007f7c123e0db7  pop r10
00007f7c123e0db9  pop r9
00007f7c123e0dbb  pop r8
00007f7c123e0dbd  pop rsi
00007f7c123e0dbe  pop rdi
00007f7c123e0dbf  pop rdx
00007f7c123e0dc0  pop rcx
00007f7c123e0dc1  pop rax
00007f7c123e0dc2  add rsp, 0x08
00007f7c123e0dc6  jmp 0x00007F7C123DC6CD
00007f7c123e0dcb  sub rsp, 0x08
00007f7c123e0dcf  push rax
00007f7c123e0dd0  push rcx
00007f7c123e0dd1  push rdx
00007f7c123e0dd2  push rdi
00007f7c123e0dd3  push rsi
00007f7c123e0dd4  push r8
00007f7c123e0dd6  push r9
00007f7c123e0dd8  push r10
00007f7c123e0dda  push r11
00007f7c123e0ddc  sub rsp, 0xF0
00007f7c123e0de3  vmovaps [rsp], xmm0
00007f7c123e0de8  vmovaps [rsp+0x10], xmm1
00007f7c123e0dee  vmovaps [rsp+0x20], xmm2
00007f7c123e0df4  vmovaps [rsp+0x30], xmm3
00007f7c123e0dfa  vmovaps [rsp+0x40], xmm4
00007f7c123e0e00  vmovaps [rsp+0x50], xmm5
00007f7c123e0e06  vmovaps [rsp+0x60], xmm6
00007f7c123e0e0c  vmovaps [rsp+0x70], xmm7
00007f7c123e0e12  vmovaps [rsp+0x80], xmm8
00007f7c123e0e1b  vmovaps [rsp+0x90], xmm9
00007f7c123e0e24  vmovaps [rsp+0xA0], xmm10
00007f7c123e0e2d  vmovaps [rsp+0xB0], xmm11
00007f7c123e0e36  vmovaps [rsp+0xC0], xmm13
00007f7c123e0e3f  vmovaps [rsp+0xD0], xmm14
00007f7c123e0e48  vmovaps [rsp+0xE0], xmm15
00007f7c123e0e51  sub rsp, 0x30
00007f7c123e0e55  movaps [rsp], xmm12
00007f7c123e0e5a  movaps [rsp+0x10], xmm14
00007f7c123e0e60  movaps [rsp+0x20], xmm1
00007f7c123e0e65  lea rdi, [rsp]
00007f7c123e0e69  mov esi, 0x00
00007f7c123e0e6e  mov rax, 0x5E723D793530
00007f7c123e0e78  call rax
00007f7c123e0e7a  movaps xmm12, [rsp]
00007f7c123e0e7f  add rsp, 0x30
00007f7c123e0e83  vmovaps xmm0, [rsp]
00007f7c123e0e88  vmovaps xmm1, [rsp+0x10]
00007f7c123e0e8e  vmovaps xmm2, [rsp+0x20]
00007f7c123e0e94  vmovaps xmm3, [rsp+0x30]
00007f7c123e0e9a  vmovaps xmm4, [rsp+0x40]
00007f7c123e0ea0  vmovaps xmm5, [rsp+0x50]
00007f7c123e0ea6  vmovaps xmm6, [rsp+0x60]
00007f7c123e0eac  vmovaps xmm7, [rsp+0x70]
00007f7c123e0eb2  vmovaps xmm8, [rsp+0x80]
00007f7c123e0ebb  vmovaps xmm9, [rsp+0x90]
00007f7c123e0ec4  vmovaps xmm10, [rsp+0xA0]
00007f7c123e0ecd  vmovaps xmm11, [rsp+0xB0]
00007f7c123e0ed6  vmovaps xmm13, [rsp+0xC0]
00007f7c123e0edf  vmovaps xmm14, [rsp+0xD0]
00007f7c123e0ee8  vmovaps xmm15, [rsp+0xE0]
00007f7c123e0ef1  add rsp, 0xF0
00007f7c123e0ef8  pop r11
00007f7c123e0efa  pop r10
00007f7c123e0efc  pop r9
00007f7c123e0efe  pop r8
00007f7c123e0f00  pop rsi
00007f7c123e0f01  pop rdi
00007f7c123e0f02  pop rdx
00007f7c123e0f03  pop rcx
00007f7c123e0f04  pop rax
00007f7c123e0f05  add rsp, 0x08
00007f7c123e0f09  jmp 0x00007F7C123DC6FC
00007f7c123e0f0e  sub rsp, 0x08
00007f7c123e0f12  push rax
00007f7c123e0f13  push rcx
00007f7c123e0f14  push rdx
00007f7c123e0f15  push rdi
00007f7c123e0f16  push rsi
00007f7c123e0f17  push r8
00007f7c123e0f19  push r9
00007f7c123e0f1b  push r10
00007f7c123e0f1d  push r11
00007f7c123e0f1f  sub rsp, 0xF0
00007f7c123e0f26  vmovaps [rsp], xmm0
00007f7c123e0f2b  vmovaps [rsp+0x10], xmm1
00007f7c123e0f31  vmovaps [rsp+0x20], xmm2
00007f7c123e0f37  vmovaps [rsp+0x30], xmm3
00007f7c123e0f3d  vmovaps [rsp+0x40], xmm4
00007f7c123e0f43  vmovaps [rsp+0x50], xmm5
00007f7c123e0f49  vmovaps [rsp+0x60], xmm6
00007f7c123e0f4f  vmovaps [rsp+0x70], xmm7
00007f7c123e0f55  vmovaps [rsp+0x80], xmm8
00007f7c123e0f5e  vmovaps [rsp+0x90], xmm9
00007f7c123e0f67  vmovaps [rsp+0xA0], xmm10
00007f7c123e0f70  vmovaps [rsp+0xB0], xmm11
00007f7c123e0f79  vmovaps [rsp+0xC0], xmm12
00007f7c123e0f82  vmovaps [rsp+0xD0], xmm13
00007f7c123e0f8b  vmovaps [rsp+0xE0], xmm15
00007f7c123e0f94  sub rsp, 0x30
00007f7c123e0f98  movaps [rsp], xmm14
00007f7c123e0f9d  movaps [rsp+0x10], xmm9
00007f7c123e0fa3  movaps [rsp+0x20], xmm1
00007f7c123e0fa8  lea rdi, [rsp]
00007f7c123e0fac  mov esi, 0x00
00007f7c123e0fb1  mov rax, 0x5E723D793530
00007f7c123e0fbb  call rax
00007f7c123e0fbd  movaps xmm14, [rsp]
00007f7c123e0fc2  add rsp, 0x30
00007f7c123e0fc6  vmovaps xmm0, [rsp]
00007f7c123e0fcb  vmovaps xmm1, [rsp+0x10]
00007f7c123e0fd1  vmovaps xmm2, [rsp+0x20]
00007f7c123e0fd7  vmovaps xmm3, [rsp+0x30]
00007f7c123e0fdd  vmovaps xmm4, [rsp+0x40]
00007f7c123e0fe3  vmovaps xmm5, [rsp+0x50]
00007f7c123e0fe9  vmovaps xmm6, [rsp+0x60]
00007f7c123e0fef  vmovaps xmm7, [rsp+0x70]
00007f7c123e0ff5  vmovaps xmm8, [rsp+0x80]
00007f7c123e0ffe  vmovaps xmm9, [rsp+0x90]
00007f7c123e1007  vmovaps xmm10, [rsp+0xA0]
00007f7c123e1010  vmovaps xmm11, [rsp+0xB0]
00007f7c123e1019  vmovaps xmm12, [rsp+0xC0]
00007f7c123e1022  vmovaps xmm13, [rsp+0xD0]
00007f7c123e102b  vmovaps xmm15, [rsp+0xE0]
00007f7c123e1034  add rsp, 0xF0
00007f7c123e103b  pop r11
00007f7c123e103d  pop r10
00007f7c123e103f  pop r9
00007f7c123e1041  pop r8
00007f7c123e1043  pop rsi
00007f7c123e1044  pop rdi
00007f7c123e1045  pop rdx
00007f7c123e1046  pop rcx
00007f7c123e1047  pop rax
00007f7c123e1048  add rsp, 0x08
00007f7c123e104c  jmp 0x00007F7C123DC72B
00007f7c123e1051  sub rsp, 0x08
00007f7c123e1055  push rax
00007f7c123e1056  push rcx
00007f7c123e1057  push rdx
00007f7c123e1058  push rdi
00007f7c123e1059  push rsi
00007f7c123e105a  push r8
00007f7c123e105c  push r9
00007f7c123e105e  push r10
00007f7c123e1060  push r11
00007f7c123e1062  sub rsp, 0xF0
00007f7c123e1069  vmovaps [rsp], xmm0
00007f7c123e106e  vmovaps [rsp+0x10], xmm2
00007f7c123e1074  vmovaps [rsp+0x20], xmm3
00007f7c123e107a  vmovaps [rsp+0x30], xmm4
00007f7c123e1080  vmovaps [rsp+0x40], xmm5
00007f7c123e1086  vmovaps [rsp+0x50], xmm6
00007f7c123e108c  vmovaps [rsp+0x60], xmm7
00007f7c123e1092  vmovaps [rsp+0x70], xmm8
00007f7c123e1098  vmovaps [rsp+0x80], xmm9
00007f7c123e10a1  vmovaps [rsp+0x90], xmm10
00007f7c123e10aa  vmovaps [rsp+0xA0], xmm11
00007f7c123e10b3  vmovaps [rsp+0xB0], xmm12
00007f7c123e10bc  vmovaps [rsp+0xC0], xmm13
00007f7c123e10c5  vmovaps [rsp+0xD0], xmm14
00007f7c123e10ce  vmovaps [rsp+0xE0], xmm15
00007f7c123e10d7  sub rsp, 0x30
00007f7c123e10db  movaps [rsp], xmm1
00007f7c123e10df  movaps [rsp+0x10], xmm13
00007f7c123e10e5  movaps [rsp+0x20], xmm8
00007f7c123e10eb  lea rdi, [rsp]
00007f7c123e10ef  mov esi, 0x00
00007f7c123e10f4  mov rax, 0x5E723D793530
00007f7c123e10fe  call rax
00007f7c123e1100  movaps xmm1, [rsp]
00007f7c123e1104  add rsp, 0x30
00007f7c123e1108  vmovaps xmm0, [rsp]
00007f7c123e110d  vmovaps xmm2, [rsp+0x10]
00007f7c123e1113  vmovaps xmm3, [rsp+0x20]
00007f7c123e1119  vmovaps xmm4, [rsp+0x30]
00007f7c123e111f  vmovaps xmm5, [rsp+0x40]
00007f7c123e1125  vmovaps xmm6, [rsp+0x50]
00007f7c123e112b  vmovaps xmm7, [rsp+0x60]
00007f7c123e1131  vmovaps xmm8, [rsp+0x70]
00007f7c123e1137  vmovaps xmm9, [rsp+0x80]
00007f7c123e1140  vmovaps xmm10, [rsp+0x90]
00007f7c123e1149  vmovaps xmm11, [rsp+0xA0]
00007f7c123e1152  vmovaps xmm12, [rsp+0xB0]
00007f7c123e115b  vmovaps xmm13, [rsp+0xC0]
00007f7c123e1164  vmovaps xmm14, [rsp+0xD0]
00007f7c123e116d  vmovaps xmm15, [rsp+0xE0]
00007f7c123e1176  add rsp, 0xF0
00007f7c123e117d  pop r11
00007f7c123e117f  pop r10
00007f7c123e1181  pop r9
00007f7c123e1183  pop r8
00007f7c123e1185  pop rsi
00007f7c123e1186  pop rdi
00007f7c123e1187  pop rdx
00007f7c123e1188  pop rcx
00007f7c123e1189  pop rax
00007f7c123e118a  add rsp, 0x08
00007f7c123e118e  jmp 0x00007F7C123DC74D
00007f7c123e1193  call 0x00007F7C1220C260
00007f7c123e1198  jmp 0x00007F7C123DC75B
00007f7c123e119d  call 0x00007F7C122BD750
00007f7c123e11a2  jmp 0x00007F7C123DC765
00007f7c123e11a7  sub rsp, 0x08
00007f7c123e11ab  push rax
00007f7c123e11ac  push rcx
00007f7c123e11ad  push rdx
00007f7c123e11ae  push rdi
00007f7c123e11af  push rsi
00007f7c123e11b0  push r8
00007f7c123e11b2  push r9
00007f7c123e11b4  push r10
00007f7c123e11b6  push r11
00007f7c123e11b8  sub rsp, 0xF0
00007f7c123e11bf  vmovaps [rsp], xmm0
00007f7c123e11c4  vmovaps [rsp+0x10], xmm1
00007f7c123e11ca  vmovaps [rsp+0x20], xmm2
00007f7c123e11d0  vmovaps [rsp+0x30], xmm3
00007f7c123e11d6  vmovaps [rsp+0x40], xmm4
00007f7c123e11dc  vmovaps [rsp+0x50], xmm5
00007f7c123e11e2  vmovaps [rsp+0x60], xmm6
00007f7c123e11e8  vmovaps [rsp+0x70], xmm7
00007f7c123e11ee  vmovaps [rsp+0x80], xmm9
00007f7c123e11f7  vmovaps [rsp+0x90], xmm10
00007f7c123e1200  vmovaps [rsp+0xA0], xmm11
00007f7c123e1209  vmovaps [rsp+0xB0], xmm12
00007f7c123e1212  vmovaps [rsp+0xC0], xmm13
00007f7c123e121b  vmovaps [rsp+0xD0], xmm14
00007f7c123e1224  vmovaps [rsp+0xE0], xmm15
00007f7c123e122d  sub rsp, 0x30
00007f7c123e1231  movaps [rsp], xmm8
00007f7c123e1236  movaps [rsp+0x10], xmm15
00007f7c123e123c  movaps [rsp+0x20], xmm7
00007f7c123e1241  lea rdi, [rsp]
00007f7c123e1245  mov esi, 0x00
00007f7c123e124a  mov rax, 0x5E723D793530
00007f7c123e1254  call rax
00007f7c123e1256  movaps xmm8, [rsp]
00007f7c123e125b  add rsp, 0x30
00007f7c123e125f  vmovaps xmm0, [rsp]
00007f7c123e1264  vmovaps xmm1, [rsp+0x10]
00007f7c123e126a  vmovaps xmm2, [rsp+0x20]
00007f7c123e1270  vmovaps xmm3, [rsp+0x30]
00007f7c123e1276  vmovaps xmm4, [rsp+0x40]
00007f7c123e127c  vmovaps xmm5, [rsp+0x50]
00007f7c123e1282  vmovaps xmm6, [rsp+0x60]
00007f7c123e1288  vmovaps xmm7, [rsp+0x70]
00007f7c123e128e  vmovaps xmm9, [rsp+0x80]
00007f7c123e1297  vmovaps xmm10, [rsp+0x90]
00007f7c123e12a0  vmovaps xmm11, [rsp+0xA0]
00007f7c123e12a9  vmovaps xmm12, [rsp+0xB0]
00007f7c123e12b2  vmovaps xmm13, [rsp+0xC0]
00007f7c123e12bb  vmovaps xmm14, [rsp+0xD0]
00007f7c123e12c4  vmovaps xmm15, [rsp+0xE0]
00007f7c123e12cd  add rsp, 0xF0
00007f7c123e12d4  pop r11
00007f7c123e12d6  pop r10
00007f7c123e12d8  pop r9
00007f7c123e12da  pop r8
00007f7c123e12dc  pop rsi
00007f7c123e12dd  pop rdi
00007f7c123e12de  pop rdx
00007f7c123e12df  pop rcx
00007f7c123e12e0  pop rax
00007f7c123e12e1  add rsp, 0x08
00007f7c123e12e5  jmp 0x00007F7C123DC787
00007f7c123e12ea  sub rsp, 0x08
00007f7c123e12ee  push rax
00007f7c123e12ef  push rcx
00007f7c123e12f0  push rdx
00007f7c123e12f1  push rdi
00007f7c123e12f2  push rsi
00007f7c123e12f3  push r8
00007f7c123e12f5  push r9
00007f7c123e12f7  push r10
00007f7c123e12f9  push r11
00007f7c123e12fb  sub rsp, 0xF0
00007f7c123e1302  vmovaps [rsp], xmm0
00007f7c123e1307  vmovaps [rsp+0x10], xmm1
00007f7c123e130d  vmovaps [rsp+0x20], xmm2
00007f7c123e1313  vmovaps [rsp+0x30], xmm3
00007f7c123e1319  vmovaps [rsp+0x40], xmm4
00007f7c123e131f  vmovaps [rsp+0x50], xmm5
00007f7c123e1325  vmovaps [rsp+0x60], xmm6
00007f7c123e132b  vmovaps [rsp+0x70], xmm8
00007f7c123e1331  vmovaps [rsp+0x80], xmm9
00007f7c123e133a  vmovaps [rsp+0x90], xmm10
00007f7c123e1343  vmovaps [rsp+0xA0], xmm11
00007f7c123e134c  vmovaps [rsp+0xB0], xmm12
00007f7c123e1355  vmovaps [rsp+0xC0], xmm13
00007f7c123e135e  vmovaps [rsp+0xD0], xmm14
00007f7c123e1367  vmovaps [rsp+0xE0], xmm15
00007f7c123e1370  sub rsp, 0x30
00007f7c123e1374  movaps [rsp], xmm7
00007f7c123e1378  movaps [rsp+0x10], xmm9
00007f7c123e137e  movaps [rsp+0x20], xmm15
00007f7c123e1384  lea rdi, [rsp]
00007f7c123e1388  mov esi, 0x00
00007f7c123e138d  mov rax, 0x5E723D793530
00007f7c123e1397  call rax
00007f7c123e1399  movaps xmm7, [rsp]
00007f7c123e139d  add rsp, 0x30
00007f7c123e13a1  vmovaps xmm0, [rsp]
00007f7c123e13a6  vmovaps xmm1, [rsp+0x10]
00007f7c123e13ac  vmovaps xmm2, [rsp+0x20]
00007f7c123e13b2  vmovaps xmm3, [rsp+0x30]
00007f7c123e13b8  vmovaps xmm4, [rsp+0x40]
00007f7c123e13be  vmovaps xmm5, [rsp+0x50]
00007f7c123e13c4  vmovaps xmm6, [rsp+0x60]
00007f7c123e13ca  vmovaps xmm8, [rsp+0x70]
00007f7c123e13d0  vmovaps xmm9, [rsp+0x80]
00007f7c123e13d9  vmovaps xmm10, [rsp+0x90]
00007f7c123e13e2  vmovaps xmm11, [rsp+0xA0]
00007f7c123e13eb  vmovaps xmm12, [rsp+0xB0]
00007f7c123e13f4  vmovaps xmm13, [rsp+0xC0]
00007f7c123e13fd  vmovaps xmm14, [rsp+0xD0]
00007f7c123e1406  vmovaps xmm15, [rsp+0xE0]
00007f7c123e140f  add rsp, 0xF0
00007f7c123e1416  pop r11
00007f7c123e1418  pop r10
00007f7c123e141a  pop r9
00007f7c123e141c  pop r8
00007f7c123e141e  pop rsi
00007f7c123e141f  pop rdi
00007f7c123e1420  pop rdx
00007f7c123e1421  pop rcx
00007f7c123e1422  pop rax
00007f7c123e1423  add rsp, 0x08
00007f7c123e1427  jmp 0x00007F7C123DC7B4
00007f7c123e142c  sub rsp, 0x08
00007f7c123e1430  push rax
00007f7c123e1431  push rcx
00007f7c123e1432  push rdx
00007f7c123e1433  push rdi
00007f7c123e1434  push rsi
00007f7c123e1435  push r8
00007f7c123e1437  push r9
00007f7c123e1439  push r10
00007f7c123e143b  push r11
00007f7c123e143d  sub rsp, 0xF0
00007f7c123e1444  vmovaps [rsp], xmm0
00007f7c123e1449  vmovaps [rsp+0x10], xmm1
00007f7c123e144f  vmovaps [rsp+0x20], xmm2
00007f7c123e1455  vmovaps [rsp+0x30], xmm3
00007f7c123e145b  vmovaps [rsp+0x40], xmm4
00007f7c123e1461  vmovaps [rsp+0x50], xmm5
00007f7c123e1467  vmovaps [rsp+0x60], xmm6
00007f7c123e146d  vmovaps [rsp+0x70], xmm7
00007f7c123e1473  vmovaps [rsp+0x80], xmm8
00007f7c123e147c  vmovaps [rsp+0x90], xmm10
00007f7c123e1485  vmovaps [rsp+0xA0], xmm11
00007f7c123e148e  vmovaps [rsp+0xB0], xmm12
00007f7c123e1497  vmovaps [rsp+0xC0], xmm13
00007f7c123e14a0  vmovaps [rsp+0xD0], xmm14
00007f7c123e14a9  vmovaps [rsp+0xE0], xmm15
00007f7c123e14b2  sub rsp, 0x30
00007f7c123e14b6  movaps [rsp], xmm9
00007f7c123e14bb  movaps [rsp+0x10], xmm13
00007f7c123e14c1  movaps [rsp+0x20], xmm15
00007f7c123e14c7  lea rdi, [rsp]
00007f7c123e14cb  mov esi, 0x00
00007f7c123e14d0  mov rax, 0x5E723D793530
00007f7c123e14da  call rax
00007f7c123e14dc  movaps xmm9, [rsp]
00007f7c123e14e1  add rsp, 0x30
00007f7c123e14e5  vmovaps xmm0, [rsp]
00007f7c123e14ea  vmovaps xmm1, [rsp+0x10]
00007f7c123e14f0  vmovaps xmm2, [rsp+0x20]
00007f7c123e14f6  vmovaps xmm3, [rsp+0x30]
00007f7c123e14fc  vmovaps xmm4, [rsp+0x40]
00007f7c123e1502  vmovaps xmm5, [rsp+0x50]
00007f7c123e1508  vmovaps xmm6, [rsp+0x60]
00007f7c123e150e  vmovaps xmm7, [rsp+0x70]
00007f7c123e1514  vmovaps xmm8, [rsp+0x80]
00007f7c123e151d  vmovaps xmm10, [rsp+0x90]
00007f7c123e1526  vmovaps xmm11, [rsp+0xA0]
00007f7c123e152f  vmovaps xmm12, [rsp+0xB0]
00007f7c123e1538  vmovaps xmm13, [rsp+0xC0]
00007f7c123e1541  vmovaps xmm14, [rsp+0xD0]
00007f7c123e154a  vmovaps xmm15, [rsp+0xE0]
00007f7c123e1553  add rsp, 0xF0
00007f7c123e155a  pop r11
00007f7c123e155c  pop r10
00007f7c123e155e  pop r9
00007f7c123e1560  pop r8
00007f7c123e1562  pop rsi
00007f7c123e1563  pop rdi
00007f7c123e1564  pop rdx
00007f7c123e1565  pop rcx
00007f7c123e1566  pop rax
00007f7c123e1567  add rsp, 0x08
00007f7c123e156b  jmp 0x00007F7C123DC7E2
00007f7c123e1570  sub rsp, 0x08
00007f7c123e1574  push rax
00007f7c123e1575  push rcx
00007f7c123e1576  push rdx
00007f7c123e1577  push rdi
00007f7c123e1578  push rsi
00007f7c123e1579  push r8
00007f7c123e157b  push r9
00007f7c123e157d  push r10
00007f7c123e157f  push r11
00007f7c123e1581  sub rsp, 0xF0
00007f7c123e1588  vmovaps [rsp], xmm0
00007f7c123e158d  vmovaps [rsp+0x10], xmm1
00007f7c123e1593  vmovaps [rsp+0x20], xmm2
00007f7c123e1599  vmovaps [rsp+0x30], xmm3
00007f7c123e159f  vmovaps [rsp+0x40], xmm4
00007f7c123e15a5  vmovaps [rsp+0x50], xmm5
00007f7c123e15ab  vmovaps [rsp+0x60], xmm6
00007f7c123e15b1  vmovaps [rsp+0x70], xmm7
00007f7c123e15b7  vmovaps [rsp+0x80], xmm8
00007f7c123e15c0  vmovaps [rsp+0x90], xmm9
00007f7c123e15c9  vmovaps [rsp+0xA0], xmm10
00007f7c123e15d2  vmovaps [rsp+0xB0], xmm11
00007f7c123e15db  vmovaps [rsp+0xC0], xmm12
00007f7c123e15e4  vmovaps [rsp+0xD0], xmm13
00007f7c123e15ed  vmovaps [rsp+0xE0], xmm14
00007f7c123e15f6  sub rsp, 0x30
00007f7c123e15fa  movaps [rsp], xmm15
00007f7c123e15ff  movaps [rsp+0x10], xmm11
00007f7c123e1605  movaps [rsp+0x20], xmm12
00007f7c123e160b  lea rdi, [rsp]
00007f7c123e160f  mov esi, 0x00
00007f7c123e1614  mov rax, 0x5E723D793530
00007f7c123e161e  call rax
00007f7c123e1620  movaps xmm15, [rsp]
00007f7c123e1625  add rsp, 0x30
00007f7c123e1629  vmovaps xmm0, [rsp]
00007f7c123e162e  vmovaps xmm1, [rsp+0x10]
00007f7c123e1634  vmovaps xmm2, [rsp+0x20]
00007f7c123e163a  vmovaps xmm3, [rsp+0x30]
00007f7c123e1640  vmovaps xmm4, [rsp+0x40]
00007f7c123e1646  vmovaps xmm5, [rsp+0x50]
00007f7c123e164c  vmovaps xmm6, [rsp+0x60]
00007f7c123e1652  vmovaps xmm7, [rsp+0x70]
00007f7c123e1658  vmovaps xmm8, [rsp+0x80]
00007f7c123e1661  vmovaps xmm9, [rsp+0x90]
00007f7c123e166a  vmovaps xmm10, [rsp+0xA0]
00007f7c123e1673  vmovaps xmm11, [rsp+0xB0]
00007f7c123e167c  vmovaps xmm12, [rsp+0xC0]
00007f7c123e1685  vmovaps xmm13, [rsp+0xD0]
00007f7c123e168e  vmovaps xmm14, [rsp+0xE0]
00007f7c123e1697  add rsp, 0xF0
00007f7c123e169e  pop r11
00007f7c123e16a0  pop r10
00007f7c123e16a2  pop r9
00007f7c123e16a4  pop r8
00007f7c123e16a6  pop rsi
00007f7c123e16a7  pop rdi
00007f7c123e16a8  pop rdx
00007f7c123e16a9  pop rcx
00007f7c123e16aa  pop rax
00007f7c123e16ab  add rsp, 0x08
00007f7c123e16af  jmp 0x00007F7C123DC7FD
00007f7c123e16b4  sub rsp, 0x08
00007f7c123e16b8  push rax
00007f7c123e16b9  push rcx
00007f7c123e16ba  push rdx
00007f7c123e16bb  push rdi
00007f7c123e16bc  push rsi
00007f7c123e16bd  push r8
00007f7c123e16bf  push r9
00007f7c123e16c1  push r10
00007f7c123e16c3  push r11
00007f7c123e16c5  sub rsp, 0xF0
00007f7c123e16cc  vmovaps [rsp], xmm0
00007f7c123e16d1  vmovaps [rsp+0x10], xmm1
00007f7c123e16d7  vmovaps [rsp+0x20], xmm2
00007f7c123e16dd  vmovaps [rsp+0x30], xmm3
00007f7c123e16e3  vmovaps [rsp+0x40], xmm4
00007f7c123e16e9  vmovaps [rsp+0x50], xmm5
00007f7c123e16ef  vmovaps [rsp+0x60], xmm6
00007f7c123e16f5  vmovaps [rsp+0x70], xmm7
00007f7c123e16fb  vmovaps [rsp+0x80], xmm8
00007f7c123e1704  vmovaps [rsp+0x90], xmm9
00007f7c123e170d  vmovaps [rsp+0xA0], xmm10
00007f7c123e1716  vmovaps [rsp+0xB0], xmm11
00007f7c123e171f  vmovaps [rsp+0xC0], xmm12
00007f7c123e1728  vmovaps [rsp+0xD0], xmm14
00007f7c123e1731  vmovaps [rsp+0xE0], xmm15
00007f7c123e173a  sub rsp, 0x30
00007f7c123e173e  movaps [rsp], xmm13
00007f7c123e1743  movaps [rsp+0x10], xmm10
00007f7c123e1749  movaps [rsp+0x20], xmm14
00007f7c123e174f  lea rdi, [rsp]
00007f7c123e1753  mov esi, 0x00
00007f7c123e1758  mov rax, 0x5E723D793530
00007f7c123e1762  call rax
00007f7c123e1764  movaps xmm13, [rsp]
00007f7c123e1769  add rsp, 0x30
00007f7c123e176d  vmovaps xmm0, [rsp]
00007f7c123e1772  vmovaps xmm1, [rsp+0x10]
00007f7c123e1778  vmovaps xmm2, [rsp+0x20]
00007f7c123e177e  vmovaps xmm3, [rsp+0x30]
00007f7c123e1784  vmovaps xmm4, [rsp+0x40]
00007f7c123e178a  vmovaps xmm5, [rsp+0x50]
00007f7c123e1790  vmovaps xmm6, [rsp+0x60]
00007f7c123e1796  vmovaps xmm7, [rsp+0x70]
00007f7c123e179c  vmovaps xmm8, [rsp+0x80]
00007f7c123e17a5  vmovaps xmm9, [rsp+0x90]
00007f7c123e17ae  vmovaps xmm10, [rsp+0xA0]
00007f7c123e17b7  vmovaps xmm11, [rsp+0xB0]
00007f7c123e17c0  vmovaps xmm12, [rsp+0xC0]
00007f7c123e17c9  vmovaps xmm14, [rsp+0xD0]
00007f7c123e17d2  vmovaps xmm15, [rsp+0xE0]
00007f7c123e17db  add rsp, 0xF0
00007f7c123e17e2  pop r11
00007f7c123e17e4  pop r10
00007f7c123e17e6  pop r9
00007f7c123e17e8  pop r8
00007f7c123e17ea  pop rsi
00007f7c123e17eb  pop rdi
00007f7c123e17ec  pop rdx
00007f7c123e17ed  pop rcx
00007f7c123e17ee  pop rax
00007f7c123e17ef  add rsp, 0x08
00007f7c123e17f3  jmp 0x00007F7C123DC820
00007f7c123e17f8  sub rsp, 0x08
00007f7c123e17fc  push rax
00007f7c123e17fd  push rcx
00007f7c123e17fe  push rdx
00007f7c123e17ff  push rdi
00007f7c123e1800  push rsi
00007f7c123e1801  push r8
00007f7c123e1803  push r9
00007f7c123e1805  push r10
00007f7c123e1807  push r11
00007f7c123e1809  sub rsp, 0xF0
00007f7c123e1810  vmovaps [rsp], xmm0
00007f7c123e1815  vmovaps [rsp+0x10], xmm1
00007f7c123e181b  vmovaps [rsp+0x20], xmm2
00007f7c123e1821  vmovaps [rsp+0x30], xmm3
00007f7c123e1827  vmovaps [rsp+0x40], xmm4
00007f7c123e182d  vmovaps [rsp+0x50], xmm5
00007f7c123e1833  vmovaps [rsp+0x60], xmm6
00007f7c123e1839  vmovaps [rsp+0x70], xmm7
00007f7c123e183f  vmovaps [rsp+0x80], xmm8
00007f7c123e1848  vmovaps [rsp+0x90], xmm9
00007f7c123e1851  vmovaps [rsp+0xA0], xmm10
00007f7c123e185a  vmovaps [rsp+0xB0], xmm11
00007f7c123e1863  vmovaps [rsp+0xC0], xmm12
00007f7c123e186c  vmovaps [rsp+0xD0], xmm13
00007f7c123e1875  vmovaps [rsp+0xE0], xmm15
00007f7c123e187e  sub rsp, 0x30
00007f7c123e1882  movaps [rsp], xmm14
00007f7c123e1887  movaps [rsp+0x10], xmm1
00007f7c123e188c  movaps [rsp+0x20], xmm7
00007f7c123e1891  lea rdi, [rsp]
00007f7c123e1895  mov esi, 0x00
00007f7c123e189a  mov rax, 0x5E723D793530
00007f7c123e18a4  call rax
00007f7c123e18a6  movaps xmm14, [rsp]
00007f7c123e18ab  add rsp, 0x30
00007f7c123e18af  vmovaps xmm0, [rsp]
00007f7c123e18b4  vmovaps xmm1, [rsp+0x10]
00007f7c123e18ba  vmovaps xmm2, [rsp+0x20]
00007f7c123e18c0  vmovaps xmm3, [rsp+0x30]
00007f7c123e18c6  vmovaps xmm4, [rsp+0x40]
00007f7c123e18cc  vmovaps xmm5, [rsp+0x50]
00007f7c123e18d2  vmovaps xmm6, [rsp+0x60]
00007f7c123e18d8  vmovaps xmm7, [rsp+0x70]
00007f7c123e18de  vmovaps xmm8, [rsp+0x80]
00007f7c123e18e7  vmovaps xmm9, [rsp+0x90]
00007f7c123e18f0  vmovaps xmm10, [rsp+0xA0]
00007f7c123e18f9  vmovaps xmm11, [rsp+0xB0]
00007f7c123e1902  vmovaps xmm12, [rsp+0xC0]
00007f7c123e190b  vmovaps xmm13, [rsp+0xD0]
00007f7c123e1914  vmovaps xmm15, [rsp+0xE0]
00007f7c123e191d  add rsp, 0xF0
00007f7c123e1924  pop r11
00007f7c123e1926  pop r10
00007f7c123e1928  pop r9
00007f7c123e192a  pop r8
00007f7c123e192c  pop rsi
00007f7c123e192d  pop rdi
00007f7c123e192e  pop rdx
00007f7c123e192f  pop rcx
00007f7c123e1930  pop rax
00007f7c123e1931  add rsp, 0x08
00007f7c123e1935  jmp 0x00007F7C123DC843
00007f7c123e193a  sub rsp, 0x08
00007f7c123e193e  push rax
00007f7c123e193f  push rcx
00007f7c123e1940  push rdx
00007f7c123e1941  push rdi
00007f7c123e1942  push rsi
00007f7c123e1943  push r8
00007f7c123e1945  push r9
00007f7c123e1947  push r10
00007f7c123e1949  push r11
00007f7c123e194b  sub rsp, 0xF0
00007f7c123e1952  vmovaps [rsp], xmm0
00007f7c123e1957  vmovaps [rsp+0x10], xmm2
00007f7c123e195d  vmovaps [rsp+0x20], xmm3
00007f7c123e1963  vmovaps [rsp+0x30], xmm4
00007f7c123e1969  vmovaps [rsp+0x40], xmm5
00007f7c123e196f  vmovaps [rsp+0x50], xmm6
00007f7c123e1975  vmovaps [rsp+0x60], xmm7
00007f7c123e197b  vmovaps [rsp+0x70], xmm8
00007f7c123e1981  vmovaps [rsp+0x80], xmm9
00007f7c123e198a  vmovaps [rsp+0x90], xmm10
00007f7c123e1993  vmovaps [rsp+0xA0], xmm11
00007f7c123e199c  vmovaps [rsp+0xB0], xmm12
00007f7c123e19a5  vmovaps [rsp+0xC0], xmm13
00007f7c123e19ae  vmovaps [rsp+0xD0], xmm14
00007f7c123e19b7  vmovaps [rsp+0xE0], xmm15
00007f7c123e19c0  sub rsp, 0x30
00007f7c123e19c4  movaps [rsp], xmm1
00007f7c123e19c8  movaps [rsp+0x10], xmm8
00007f7c123e19ce  movaps [rsp+0x20], xmm9
00007f7c123e19d4  lea rdi, [rsp]
00007f7c123e19d8  mov esi, 0x00
00007f7c123e19dd  mov rax, 0x5E723D793530
00007f7c123e19e7  call rax
00007f7c123e19e9  movaps xmm1, [rsp]
00007f7c123e19ed  add rsp, 0x30
00007f7c123e19f1  vmovaps xmm0, [rsp]
00007f7c123e19f6  vmovaps xmm2, [rsp+0x10]
00007f7c123e19fc  vmovaps xmm3, [rsp+0x20]
00007f7c123e1a02  vmovaps xmm4, [rsp+0x30]
00007f7c123e1a08  vmovaps xmm5, [rsp+0x40]
00007f7c123e1a0e  vmovaps xmm6, [rsp+0x50]
00007f7c123e1a14  vmovaps xmm7, [rsp+0x60]
00007f7c123e1a1a  vmovaps xmm8, [rsp+0x70]
00007f7c123e1a20  vmovaps xmm9, [rsp+0x80]
00007f7c123e1a29  vmovaps xmm10, [rsp+0x90]
00007f7c123e1a32  vmovaps xmm11, [rsp+0xA0]
00007f7c123e1a3b  vmovaps xmm12, [rsp+0xB0]
00007f7c123e1a44  vmovaps xmm13, [rsp+0xC0]
00007f7c123e1a4d  vmovaps xmm14, [rsp+0xD0]
00007f7c123e1a56  vmovaps xmm15, [rsp+0xE0]
00007f7c123e1a5f  add rsp, 0xF0
00007f7c123e1a66  pop r11
00007f7c123e1a68  pop r10
00007f7c123e1a6a  pop r9
00007f7c123e1a6c  pop r8
00007f7c123e1a6e  pop rsi
00007f7c123e1a6f  pop rdi
00007f7c123e1a70  pop rdx
00007f7c123e1a71  pop rcx
00007f7c123e1a72  pop rax
00007f7c123e1a73  add rsp, 0x08
00007f7c123e1a77  jmp 0x00007F7C123DC865
00007f7c123e1a7c  call 0x00007F7C122E5940
00007f7c123e1a81  jmp 0x00007F7C123DC873
00007f7c123e1a86  call 0x00007F7C1220C380
00007f7c123e1a8b  jmp 0x00007F7C123DC87D
00007f7c123e1a90  call 0x00007F7C1220D600
00007f7c123e1a95  jmp 0x00007F7C123DC887
00007f7c123e1a9a  call 0x00007F7C121FF540
00007f7c123e1a9f  jmp 0x00007F7C123DC891
00007f7c123e1aa4  int3
00007f7c123e1aa5  nop [rax+rax*1], ax
00007f7c123e1aae  nop
00007f7c123e1ab0  mov rax, [r15+0xF8]
00007f7c123e1ab7  lea r14, [rax+0x140]
00007f7c123e1abe  mov r12, [r13+r14*1]
00007f7c123e1ac3  mov [r15+0xE8], r12
00007f7c123e1aca  lea r14, [rax+0x130]
00007f7c123e1ad1  mov r12, [r13+r14*1]
00007f7c123e1ad6  lea r14, [rax+0x138]
00007f7c123e1add  mov r11, [r13+r14*1]
00007f7c123e1ae2  movq xmm1, r12
00007f7c123e1ae7  movq xmm15, r11
00007f7c123e1aec  movq xmm1, xmm1
00007f7c123e1af0  movq xmm1, xmm1
00007f7c123e1af4  movaps [r15+0x1A0], xmm1
00007f7c123e1afc  movq xmm15, xmm15
00007f7c123e1b01  movq xmm15, xmm15
00007f7c123e1b06  movaps [r15+0x190], xmm15
00007f7c123e1b0e  lea r14, [rax+0x120]
00007f7c123e1b15  mov r12, [r13+r14*1]
00007f7c123e1b1a  lea r14, [rax+0x128]
00007f7c123e1b21  mov r11, [r13+r14*1]
00007f7c123e1b26  movq xmm1, r12
00007f7c123e1b2b  movq xmm15, r11
00007f7c123e1b30  movq xmm1, xmm1
00007f7c123e1b34  movq xmm1, xmm1
00007f7c123e1b38  movaps [r15+0x1C0], xmm1
00007f7c123e1b40  movq xmm15, xmm15
00007f7c123e1b45  movq xmm15, xmm15
00007f7c123e1b4a  movaps [r15+0x1B0], xmm15
00007f7c123e1b52  lea r14, [rax+0x110]
00007f7c123e1b59  mov r12, [r13+r14*1]
00007f7c123e1b5e  lea r14, [rax+0x118]
00007f7c123e1b65  mov r11, [r13+r14*1]
00007f7c123e1b6a  movq xmm1, r12
00007f7c123e1b6f  movq xmm15, r11
00007f7c123e1b74  movq xmm1, xmm1
00007f7c123e1b78  movq xmm1, xmm1
00007f7c123e1b7c  movaps [r15+0x1E0], xmm1
00007f7c123e1b84  movq xmm15, xmm15
00007f7c123e1b89  movq xmm15, xmm15
00007f7c123e1b8e  movaps [r15+0x1D0], xmm15
00007f7c123e1b96  lea r14, [rax+0x100]
00007f7c123e1b9d  mov r12, [r13+r14*1]
00007f7c123e1ba2  lea r14, [rax+0x108]
00007f7c123e1ba9  mov r11, [r13+r14*1]
00007f7c123e1bae  movq xmm1, r12
00007f7c123e1bb3  movq xmm15, r11
00007f7c123e1bb8  movq xmm1, xmm1
00007f7c123e1bbc  movq xmm1, xmm1
00007f7c123e1bc0  movaps [r15+0x200], xmm1
00007f7c123e1bc8  movq xmm15, xmm15
00007f7c123e1bcd  movq xmm15, xmm15
00007f7c123e1bd2  movaps [r15+0x1F0], xmm15
00007f7c123e1bda  mov qword ptr [r15+0x40], 0x430000
00007f7c123e1be2  mov r14d, 0x430510
00007f7c123e1be8  mov r12, [r13+r14*1]
00007f7c123e1bed  movq xmm1, r12
00007f7c123e1bf2  lea r14, [rax+0x150]
00007f7c123e1bf9  mov [r15+0xF8], r14
00007f7c123e1c00  mov rax, [r15+0x50]
00007f7c123e1c04  movups xmm15, [r13+rax*1]
00007f7c123e1c0a  movaps [r15+0x120], xmm15
00007f7c123e1c12  mov qword ptr [r15+0x48], 0x10
00007f7c123e1c1a  xor eax, eax
00007f7c123e1c1c  mov r14d, 0x10
00007f7c123e1c22  mov r12d, 0x200
00007f7c123e1c28  cmp r14, r12
00007f7c123e1c2b  cmc
00007f7c123e1c2c  lahf
00007f7c123e1c2d  seto al
00007f7c123e1c30  mov [r15+0x108], eax
00007f7c123e1c37  pextrq rax, xmm15, 0x01
00007f7c123e1c3e  movq xmm14, rax
00007f7c123e1c43  movaps [r15+0x130], xmm14
00007f7c123e1c4b  movq rax, xmm1
00007f7c123e1c50  movq r14, xmm15
00007f7c123e1c55  vmovq xmm1, rax
00007f7c123e1c5a  vmovq xmm15, r14
00007f7c123e1c5f  movaps xmm13, xmm1
00007f7c123e1c63  addsd xmm13, xmm15
00007f7c123e1c68  ucomisd xmm13, xmm13
00007f7c123e1c6d  jp 0x00007F7C123E1D86
00007f7c123e1c73  movq xmm13, xmm13
00007f7c123e1c78  movq rax, xmm13
00007f7c123e1c7d  movq r14, xmm14
00007f7c123e1c82  vmovq xmm1, rax
00007f7c123e1c87  vmovq xmm15, r14
00007f7c123e1c8c  movaps xmm14, xmm1
00007f7c123e1c90  addsd xmm14, xmm15
00007f7c123e1c95  ucomisd xmm14, xmm14
00007f7c123e1c9a  jp 0x00007F7C123E1DCE
00007f7c123e1ca0  movq xmm14, xmm14
00007f7c123e1ca5  movaps [r15+0x110], xmm14
00007f7c123e1cad  mov eax, [r15+0x108]
00007f7c123e1cb4  sahf
00007f7c123e1cb5  jnz 0x00007F7C123E1CE7
00007f7c123e1cb7  cmp dword ptr [r15+0x318], 0x00
00007f7c123e1cbf  jz 0x00007F7C123E1FE0
00007f7c123e1cc5  nop [rax+rax*1], ax
00007f7c123e1cce  nop [rax+rax*1], eax
00007f7c123e1cd6  mov eax, 0x410490
00007f7c123e1cdb  mov [r15+0x100], rax
00007f7c123e1ce2  jmp 0x00007F7C121FE110
00007f7c123e1ce7  cmp dword ptr [r15+0x318], 0x00
00007f7c123e1cef  jz 0x00007F7C123E1E20
00007f7c123e1cf5  nop [rax+rax*1], ax
00007f7c123e1cfe  nop [rax+rax*1], eax
00007f7c123e1d06  mov eax, 0x410474
00007f7c123e1d0b  mov [r15+0x100], rax
00007f7c123e1d12  jmp 0x00007F7C121FE110
00007f7c123e1d17  int3
00007f7c123e1d18  call 0x00007F7C122E27E0
00007f7c123e1d1d  jmp 0x00007F7C123E1AC3
00007f7c123e1d22  call 0x00007F7C122E27E0
00007f7c123e1d27  jmp 0x00007F7C123E1AD6
00007f7c123e1d2c  call 0x00007F7C122E1570
00007f7c123e1d31  jmp 0x00007F7C123E1AE2
00007f7c123e1d36  call 0x00007F7C122E27E0
00007f7c123e1d3b  jmp 0x00007F7C123E1B1A
00007f7c123e1d40  call 0x00007F7C122E1570
00007f7c123e1d45  jmp 0x00007F7C123E1B26
00007f7c123e1d4a  call 0x00007F7C122E27E0
00007f7c123e1d4f  jmp 0x00007F7C123E1B5E
00007f7c123e1d54  call 0x00007F7C122E1570
00007f7c123e1d59  jmp 0x00007F7C123E1B6A
00007f7c123e1d5e  call 0x00007F7C122E27E0
00007f7c123e1d63  jmp 0x00007F7C123E1BA2
00007f7c123e1d68  call 0x00007F7C122E1570
00007f7c123e1d6d  jmp 0x00007F7C123E1BAE
00007f7c123e1d72  call 0x00007F7C122E27E0
00007f7c123e1d77  jmp 0x00007F7C123E1BED
00007f7c123e1d7c  call 0x00007F7C1220E760
00007f7c123e1d81  jmp 0x00007F7C123E1C0A
00007f7c123e1d86  ucomisd xmm1, xmm15
00007f7c123e1d8b  jp 0x00007F7C123E1D9A
00007f7c123e1d8d  movaps xmm13, [0x00007F7C11FFE060]
00007f7c123e1d95  jmp 0x00007F7C123E1C73
00007f7c123e1d9a  vxorps xmm0, xmm1, xmm15
00007f7c123e1d9f  pextrw eax, xmm0, 0x03
00007f7c123e1da4  and eax, 0x7FF8
00007f7c123e1da9  cmp eax, 0x08
00007f7c123e1dac  jnz 0x00007F7C123E1C73
00007f7c123e1db2  movq rax, xmm15
00007f7c123e1db7  shl rax, 0x0D
00007f7c123e1dbb  jbe 0x00007F7C123E1C73
00007f7c123e1dc1  vorps xmm13, xmm15, [0x00007F7C11FFE070]
00007f7c123e1dc9  jmp 0x00007F7C123E1C73
00007f7c123e1dce  ucomisd xmm1, xmm15
00007f7c123e1dd3  jp 0x00007F7C123E1DE2
00007f7c123e1dd5  movaps xmm14, [0x00007F7C11FFE060]
00007f7c123e1ddd  jmp 0x00007F7C123E1CA0
00007f7c123e1de2  vxorps xmm0, xmm1, xmm15
00007f7c123e1de7  pextrw eax, xmm0, 0x03
00007f7c123e1dec  and eax, 0x7FF8
00007f7c123e1df1  cmp eax, 0x08
00007f7c123e1df4  jnz 0x00007F7C123E1CA0
00007f7c123e1dfa  movq rax, xmm15
00007f7c123e1dff  shl rax, 0x0D
00007f7c123e1e03  jbe 0x00007F7C123E1CA0
00007f7c123e1e09  vorps xmm14, xmm15, [0x00007F7C11FFE070]
00007f7c123e1e11  jmp 0x00007F7C123E1CA0
00007f7c123e1e16  int3
00007f7c123e1e17  nop [rax+rax*1], ax
00007f7c123e1e20  mov rax, [r15+0x48]
00007f7c123e1e24  mov r14, [r15+0x50]
00007f7c123e1e28  lea r12, [r14+rax*1]
00007f7c123e1e2c  movups xmm1, [r13+r12*1]
00007f7c123e1e32  movaps [r15+0x120], xmm1
00007f7c123e1e3a  lea r14, [rax+0x10]
00007f7c123e1e3e  mov [r15+0x48], r14
00007f7c123e1e42  xor eax, eax
00007f7c123e1e44  mov r12d, 0x200
00007f7c123e1e4a  cmp r14, r12
00007f7c123e1e4d  cmc
00007f7c123e1e4e  lahf
00007f7c123e1e4f  seto al
00007f7c123e1e52  mov [r15+0x108], eax
00007f7c123e1e59  pextrq rax, xmm1, 0x01
00007f7c123e1e60  movq xmm15, rax
00007f7c123e1e65  movaps [r15+0x130], xmm15
00007f7c123e1e6d  movaps xmm14, [r15+0x110]
00007f7c123e1e75  movq rax, xmm14
00007f7c123e1e7a  movq r14, xmm1
00007f7c123e1e7f  vmovq xmm1, rax
00007f7c123e1e84  vmovq xmm14, r14
00007f7c123e1e89  movaps xmm13, xmm1
00007f7c123e1e8d  addsd xmm13, xmm14
00007f7c123e1e92  ucomisd xmm13, xmm13
00007f7c123e1e97  jp 0x00007F7C123E1F4C
00007f7c123e1e9d  movq xmm13, xmm13
00007f7c123e1ea2  movq rax, xmm13
00007f7c123e1ea7  movq r14, xmm15
00007f7c123e1eac  vmovq xmm1, rax
00007f7c123e1eb1  vmovq xmm15, r14
00007f7c123e1eb6  movaps xmm14, xmm1
00007f7c123e1eba  addsd xmm14, xmm15
00007f7c123e1ebf  ucomisd xmm14, xmm14
00007f7c123e1ec4  jp 0x00007F7C123E1F94
00007f7c123e1eca  movq xmm14, xmm14
00007f7c123e1ecf  movaps [r15+0x110], xmm14
00007f7c123e1ed7  mov eax, [r15+0x108]
00007f7c123e1ede  sahf
00007f7c123e1edf  jnz 0x00007F7C123E1F11
00007f7c123e1ee1  cmp dword ptr [r15+0x318], 0x00
00007f7c123e1ee9  jz 0x00007F7C123E1FE0
00007f7c123e1eef  nop [rax+rax*1], ax
00007f7c123e1ef8  nop [rax+rax*1], eax
00007f7c123e1f00  mov eax, 0x410490
00007f7c123e1f05  mov [r15+0x100], rax
00007f7c123e1f0c  jmp 0x00007F7C121FE110
00007f7c123e1f11  cmp dword ptr [r15+0x318], 0x00
00007f7c123e1f19  jz 0x00007F7C123E1E20
00007f7c123e1f1f  nop [rax+rax*1], ax
00007f7c123e1f28  nop [rax+rax*1], eax
00007f7c123e1f30  mov eax, 0x410474
00007f7c123e1f35  mov [r15+0x100], rax
00007f7c123e1f3c  jmp 0x00007F7C121FE110
00007f7c123e1f41  int3
00007f7c123e1f42  call 0x00007F7C122B52F0
00007f7c123e1f47  jmp 0x00007F7C123E1E32
00007f7c123e1f4c  ucomisd xmm1, xmm14
00007f7c123e1f51  jp 0x00007F7C123E1F60
00007f7c123e1f53  movaps xmm13, [0x00007F7C11FFE060]
00007f7c123e1f5b  jmp 0x00007F7C123E1E9D
00007f7c123e1f60  vxorps xmm0, xmm1, xmm14
00007f7c123e1f65  pextrw eax, xmm0, 0x03
00007f7c123e1f6a  and eax, 0x7FF8
00007f7c123e1f6f  cmp eax, 0x08
00007f7c123e1f72  jnz 0x00007F7C123E1E9D
00007f7c123e1f78  movq rax, xmm14
00007f7c123e1f7d  shl rax, 0x0D
00007f7c123e1f81  jbe 0x00007F7C123E1E9D
00007f7c123e1f87  vorps xmm13, xmm14, [0x00007F7C11FFE070]
00007f7c123e1f8f  jmp 0x00007F7C123E1E9D
00007f7c123e1f94  ucomisd xmm1, xmm15
00007f7c123e1f99  jp 0x00007F7C123E1FA8
00007f7c123e1f9b  movaps xmm14, [0x00007F7C11FFE060]
00007f7c123e1fa3  jmp 0x00007F7C123E1ECA
00007f7c123e1fa8  vxorps xmm0, xmm1, xmm15
00007f7c123e1fad  pextrw eax, xmm0, 0x03
00007f7c123e1fb2  and eax, 0x7FF8
00007f7c123e1fb7  cmp eax, 0x08
00007f7c123e1fba  jnz 0x00007F7C123E1ECA
00007f7c123e1fc0  movq rax, xmm15
00007f7c123e1fc5  shl rax, 0x0D
00007f7c123e1fc9  jbe 0x00007F7C123E1ECA
00007f7c123e1fcf  vorps xmm14, xmm15, [0x00007F7C11FFE070]
00007f7c123e1fd7  jmp 0x00007F7C123E1ECA
00007f7c123e1fdc  int3
00007f7c123e1fdd  nop [rax], eax
00007f7c123e1fe0  mov rax, [r15+0x40]
00007f7c123e1fe4  lea r14, [rax+0x510]
00007f7c123e1feb  movaps xmm1, [r15+0x110]
00007f7c123e1ff3  movq rax, xmm1
00007f7c123e1ff8  mov [r13+r14*1], rax
00007f7c123e1ffd  mov rax, [r15+0xF0]
00007f7c123e2004  mov [r15+0x100], rax
00007f7c123e200b  jmp 0x00007F7C123CE5C0
00007f7c123e2010  int3
00007f7c123e2011  call 0x00007F7C122D5EB0
00007f7c123e2016  jmp 0x00007F7C123E1FFD
00007f7c123e201b  int3
00007f7c123e201c  nop [rax], eax
00007f7c123e2020  mov qword ptr [r15+0x100], 0x04
00007f7c123e202b  mov esi, 0x00
00007f7c123e2030  mov edx, 0x09
00007f7c123e2035  mov rdi, 0x7FFD5303F130
00007f7c123e203f  mov rax, 0x5E723D626970
00007f7c123e2049  call rax
00007f7c123e204b  cmp dword ptr [r15+0x318], 0x00
00007f7c123e2053  jnz 0x00007F7C121FE110
00007f7c123e2059  jmp 0x00007F7C121FE0A0
00007f7c123e205e  int3
00007f7c123e205f  int3
