
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/shift/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13d,0x1b00
   a:	mov    r14d,0xb7
  10:	and    r14d,0xffff
  17:	mov    rax,r13
  1a:	movabs rcx,0xffffffff0000ffff
  24:	and    rax,rcx
  27:	mov    rdx,r14
  2a:	shl    rdx,0x10
  2e:	mov    ecx,0xffff0000
  33:	and    rdx,rcx
  36:	or     rax,rdx
  39:	mov    r15,rax
  3c:	mov    QWORD PTR [r12+0x8],r15
  41:	mov    r13d,0x420060
  47:	mov    QWORD PTR [r12+0x20],r13
  4c:	mov    r13d,0x0
  52:	mov    QWORD PTR [r12],r13
  56:	jmp    0x5b
  5b:	mov    r13,QWORD PTR [r12]
  5f:	ror    r13,0xd
  63:	mov    r14,r13
  66:	shr    r14,0x7
  6a:	mov    rcx,r14
  6d:	xor    r13,rcx
  70:	add    r13,0x3
  74:	mov    QWORD PTR [r12],r13
  78:	mov    r13,QWORD PTR [r12+0x8]
  7d:	sub    r13,0x1
  81:	mov    QWORD PTR [r12+0x8],r13
  86:	mov    rcx,QWORD PTR [r12+0x380]
  8e:	jrcxz  0x95
  90:	jmp    0x106
  95:	jne    0x5b
  9b:	pushf
  9c:	pop    r11
  9e:	mov    QWORD PTR [rsp],r11
  a2:	jmp    0xa7
  a7:	mov    r13,QWORD PTR [r12+0x20]
  ac:	mov    r14,QWORD PTR [r12]
  b0:	mov    QWORD PTR [r13+0x0],r14
  b4:	mov    r13d,0x0
  ba:	mov    DWORD PTR [r12+0x32c],r13d
  c2:	mov    rcx,QWORD PTR [r12+0x380]
  ca:	jrcxz  0xd1
  cc:	jmp    0x195
  d1:	mov    r13,QWORD PTR [r12+0xf0]
  d9:	mov    QWORD PTR [r12+0x100],r13
  e1:	mov    r11,QWORD PTR [rsp]
  e5:	mov    QWORD PTR [r12+0x398],r11
  ed:	mov    rdi,QWORD PTR [r12+0x100]
  f5:	add    rsp,0x10
  f9:	movabs r11,0x55b82b7590a0
 103:	jmp    r11
 106:	mov    eax,0x41004c
 10b:	mov    QWORD PTR [r12+0x100],rax
 113:	push   rdx
 114:	push   rsi
 115:	push   r10
 117:	push   r11
 119:	pushf
 11a:	pop    r11
 11c:	mov    QWORD PTR [rsp+0x20],r11
 121:	mov    rdx,QWORD PTR [rsp+0x20]
 126:	mov    r10d,edx
 129:	and    r10d,0xc0
 130:	shl    r10d,0x18
 134:	mov    r11d,edx
 137:	and    r11d,0x1
 13b:	shl    r11d,0x1d
 13f:	or     r10d,r11d
 142:	mov    r11d,edx
 145:	and    r11d,0x800
 14c:	shl    r11d,0x11
 150:	or     r10d,r11d
 153:	btc    r10,0x1d
 158:	mov    r11d,0xf0000000
 15e:	and    r11,r10
 161:	movabs rsi,0xffffffff0fffffff
 16b:	and    rbx,rsi
 16e:	or     rbx,r11
 171:	pop    r11
 173:	pop    r10
 175:	pop    rsi
 176:	pop    rdx
 177:	mov    QWORD PTR [r12+0x108],rbx
 17f:	add    rsp,0x10
 183:	mov    eax,0xc
 188:	movabs r11,0x55b82b759390
 192:	jmp    r11
 195:	mov    eax,0x410054
 19a:	mov    QWORD PTR [r12+0x100],rax
 1a2:	push   rdx
 1a3:	push   rsi
 1a4:	push   r10
 1a6:	push   r11
 1a8:	mov    rdx,QWORD PTR [rsp+0x20]
 1ad:	mov    r10d,edx
 1b0:	and    r10d,0xc0
 1b7:	shl    r10d,0x18
 1bb:	mov    r11d,edx
 1be:	and    r11d,0x1
 1c2:	shl    r11d,0x1d
 1c6:	or     r10d,r11d
 1c9:	mov    r11d,edx
 1cc:	and    r11d,0x800
 1d3:	shl    r11d,0x11
 1d7:	or     r10d,r11d
 1da:	btc    r10,0x1d
 1df:	mov    r11d,0xf0000000
 1e5:	and    r11,r10
 1e8:	movabs rsi,0xffffffff0fffffff
 1f2:	and    rbx,rsi
 1f5:	or     rbx,r11
 1f8:	pop    r11
 1fa:	pop    r10
 1fc:	pop    rsi
 1fd:	pop    rdx
 1fe:	mov    QWORD PTR [r12+0x108],rbx
 206:	add    rsp,0x10
 20a:	mov    eax,0xc
 20f:	movabs r11,0x55b82b759390
 219:	jmp    r11
 21c:	nop    DWORD PTR [rax+0x0]
 220:	sub    rsp,0x10
 224:	jmp    0x5b
 229:	nop    DWORD PTR [rax+0x0]
 230:	sub    rsp,0x10
 234:	mov    r11,QWORD PTR [r12+0x398]
 23c:	mov    QWORD PTR [rsp],r11
 240:	jmp    0xa7
 245:	nop
 246:	nop
 247:	nop
