
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/shift/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13d,0x1b00
   6:	mov    QWORD PTR [r12+0x8],r13
   b:	mov    r13d,0x1b00
  11:	mov    r14d,0xb7
  17:	and    r14d,0xffff
  1e:	mov    rax,r13
  21:	movabs rcx,0xffffffff0000ffff
  2b:	and    rax,rcx
  2e:	mov    rdx,r14
  31:	shl    rdx,0x10
  35:	mov    ecx,0xffff0000
  3a:	and    rdx,rcx
  3d:	or     rax,rdx
  40:	mov    r15,rax
  43:	mov    QWORD PTR [r12+0x8],r15
  48:	mov    r13d,0x420060
  4e:	mov    QWORD PTR [r12+0x20],r13
  53:	mov    r13d,0x0
  59:	mov    QWORD PTR [r12],r13
  5d:	jmp    0x62
  62:	mov    r13,QWORD PTR [r12]
  66:	mov    r14,r13
  69:	ror    r14,0xd
  6d:	mov    QWORD PTR [r12],r14
  71:	mov    r13,r14
  74:	shr    r13,0x7
  78:	mov    rcx,r13
  7b:	mov    r15,r14
  7e:	xor    r15,rcx
  81:	mov    QWORD PTR [r12],r15
  85:	mov    r13,r15
  88:	add    r13,0x3
  8c:	mov    QWORD PTR [r12],r13
  90:	mov    r13,QWORD PTR [r12+0x8]
  95:	mov    r14,r13
  98:	sub    r14,0x1
  9c:	pushf
  9d:	pop    rdx
  9e:	mov    r10d,edx
  a1:	and    r10d,0xc0
  a8:	shl    r10d,0x18
  ac:	mov    r11d,edx
  af:	and    r11d,0x1
  b3:	shl    r11d,0x1d
  b7:	or     r10d,r11d
  ba:	mov    r11d,edx
  bd:	and    r11d,0x800
  c4:	shl    r11d,0x11
  c8:	or     r10d,r11d
  cb:	mov    r11d,0xf0000000
  d1:	and    r11,r10
  d4:	movabs rsi,0xffffffff0fffffff
  de:	and    rbx,rsi
  e1:	or     rbx,r11
  e4:	btc    rbx,0x1d
  e9:	mov    QWORD PTR [r12+0x8],r14
  ee:	cmp    QWORD PTR [r12+0x380],0x0
  f7:	je     0x124
  fd:	mov    eax,0x41004c
 102:	mov    QWORD PTR [r12+0x100],rax
 10a:	mov    QWORD PTR [r12+0x108],rbx
 112:	mov    eax,0xc
 117:	movabs r11,0x64f82d0045f0
 121:	jmp    r11
 124:	test   ebx,0x40000000
 12a:	je     0x62
 130:	jmp    0x135
 135:	mov    r13,QWORD PTR [r12+0x20]
 13a:	mov    r14,QWORD PTR [r12]
 13e:	mov    QWORD PTR [r13+0x0],r14
 142:	mov    r13d,0x0
 148:	mov    DWORD PTR [r12+0x32c],r13d
 150:	cmp    QWORD PTR [r12+0x380],0x0
 159:	je     0x186
 15f:	mov    eax,0x410054
 164:	mov    QWORD PTR [r12+0x100],rax
 16c:	mov    QWORD PTR [r12+0x108],rbx
 174:	mov    eax,0xc
 179:	movabs r11,0x64f82d0045f0
 183:	jmp    r11
 186:	mov    r13,QWORD PTR [r12+0xf0]
 18e:	mov    QWORD PTR [r12+0x100],r13
 196:	mov    QWORD PTR [r12+0x108],rbx
 19e:	mov    rdi,QWORD PTR [r12+0x100]
 1a6:	movabs r11,0x64f82d004370
 1b0:	jmp    r11
 1b3:	data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 1c0:	jmp    0x62
 1c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 1d0:	jmp    0x135
 1d5:	nop
 1d6:	nop
 1d7:	nop
