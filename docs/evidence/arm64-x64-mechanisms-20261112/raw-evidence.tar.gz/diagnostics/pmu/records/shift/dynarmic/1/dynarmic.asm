00007c1ddbfce69b  nop [rax+rax*1], eax
00007c1ddbfce6a0  mov qword ptr [r15+0x20], 0x420060
00007c1ddbfce6a8  xor eax, eax
00007c1ddbfce6aa  xor r14d, r14d
00007c1ddbfce6ad  shrd rax, r14, 0x0D
00007c1ddbfce6b2  mov [rsp+0x10], rax
00007c1ddbfce6b7  shr rax, 0x07
00007c1ddbfce6bb  mov r14, [rsp+0x10]
00007c1ddbfce6c0  xor r14, rax
00007c1ddbfce6c3  lea rax, [r14+0x03]
00007c1ddbfce6c7  mov [r15], rax
00007c1ddbfce6ca  xor eax, eax
00007c1ddbfce6cc  mov r14d, 0xB71B00
00007c1ddbfce6d2  mov r12d, 0x01
00007c1ddbfce6d8  sub r14, r12
00007c1ddbfce6db  cmc
00007c1ddbfce6dc  lahf
00007c1ddbfce6dd  seto al
00007c1ddbfce6e0  mov [r15+0x108], eax
00007c1ddbfce6e7  mov [r15+0x08], r14
00007c1ddbfce6eb  mov eax, [r15+0x108]
00007c1ddbfce6f2  sahf
00007c1ddbfce6f3  jnz 0x00007C1DDBFCE725
00007c1ddbfce6f5  cmp dword ptr [r15+0x318], 0x00
00007c1ddbfce6fd  jz 0x00007C1DDBFCE820
00007c1ddbfce703  nop [rax+rax*1], ax
00007c1ddbfce70c  nop [rax+rax*1], eax
00007c1ddbfce714  mov eax, 0x410050
00007c1ddbfce719  mov [r15+0x100], rax
00007c1ddbfce720  jmp 0x00007C1DDBDFE110
00007c1ddbfce725  cmp dword ptr [r15+0x318], 0x00
00007c1ddbfce72d  jz 0x00007C1DDBFCE760
00007c1ddbfce733  nop [rax+rax*1], ax
00007c1ddbfce73c  nop [rax+rax*1], eax
00007c1ddbfce744  mov eax, 0x41003C
00007c1ddbfce749  mov [r15+0x100], rax
00007c1ddbfce750  jmp 0x00007C1DDBDFE110
00007c1ddbfce755  int3
00007c1ddbfce756  int3
00007c1ddbfce757  nop [rax+rax*1], ax
00007c1ddbfce760  mov rax, [r15]
00007c1ddbfce763  mov [rsp+0x10], rax
00007c1ddbfce768  mov r14, [rsp+0x10]
00007c1ddbfce76d  shrd rax, r14, 0x0D
00007c1ddbfce772  mov [rsp+0x10], rax
00007c1ddbfce777  shr rax, 0x07
00007c1ddbfce77b  mov r14, [rsp+0x10]
00007c1ddbfce780  xor r14, rax
00007c1ddbfce783  lea rax, [r14+0x03]
00007c1ddbfce787  mov [r15], rax
00007c1ddbfce78a  mov rax, [r15+0x08]
00007c1ddbfce78e  mov [rsp+0x10], rax
00007c1ddbfce793  xor eax, eax
00007c1ddbfce795  mov r14, [rsp+0x10]
00007c1ddbfce79a  mov r12d, 0x01
00007c1ddbfce7a0  sub r14, r12
00007c1ddbfce7a3  cmc
00007c1ddbfce7a4  lahf
00007c1ddbfce7a5  seto al
00007c1ddbfce7a8  mov [r15+0x108], eax
00007c1ddbfce7af  mov [r15+0x08], r14
00007c1ddbfce7b3  mov eax, [r15+0x108]
00007c1ddbfce7ba  sahf
00007c1ddbfce7bb  jnz 0x00007C1DDBFCE7ED
00007c1ddbfce7bd  cmp dword ptr [r15+0x318], 0x00
00007c1ddbfce7c5  jz 0x00007C1DDBFCE820
00007c1ddbfce7cb  nop [rax+rax*1], ax
00007c1ddbfce7d4  nop [rax+rax*1], eax
00007c1ddbfce7dc  mov eax, 0x410050
00007c1ddbfce7e1  mov [r15+0x100], rax
00007c1ddbfce7e8  jmp 0x00007C1DDBDFE110
00007c1ddbfce7ed  cmp dword ptr [r15+0x318], 0x00
00007c1ddbfce7f5  jz 0x00007C1DDBFCE760
00007c1ddbfce7fb  nop [rax+rax*1], ax
00007c1ddbfce804  nop [rax+rax*1], eax
00007c1ddbfce80c  mov eax, 0x41003C
00007c1ddbfce811  mov [r15+0x100], rax
00007c1ddbfce818  jmp 0x00007C1DDBDFE110
00007c1ddbfce81d  int3
00007c1ddbfce81e  int3
00007c1ddbfce81f  nop
00007c1ddbfce820  mov rax, [r15+0x20]
00007c1ddbfce824  mov r14, [r15]
00007c1ddbfce827  mov [r13+rax*1], r14
00007c1ddbfce82c  mov rax, [r15+0xF0]
00007c1ddbfce833  mov [r15+0x100], rax
00007c1ddbfce83a  jmp 0x00007C1DDBFCE5C0
00007c1ddbfce83f  int3
00007c1ddbfce840  call 0x00007C1DDBE0E120
00007c1ddbfce845  jmp 0x00007C1DDBFCE82C
00007c1ddbfce84a  int3
00007c1ddbfce84b  nop [rax+rax*1], eax
00007c1ddbfce850  mov qword ptr [r15+0x100], 0x04
00007c1ddbfce85b  mov esi, 0x00
00007c1ddbfce860  mov edx, 0x09
00007c1ddbfce865  mov rdi, 0x7FFF7C10FE30
00007c1ddbfce86f  mov rax, 0x5F951F932970
00007c1ddbfce879  call rax
00007c1ddbfce87b  cmp dword ptr [r15+0x318], 0x00
00007c1ddbfce883  jnz 0x00007C1DDBDFE110
00007c1ddbfce889  jmp 0x00007C1DDBDFE0A0
00007c1ddbfce88e  int3
00007c1ddbfce88f  int3
