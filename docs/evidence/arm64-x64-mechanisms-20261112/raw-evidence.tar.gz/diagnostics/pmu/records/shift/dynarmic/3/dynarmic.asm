00007fc78d9ce69b  nop [rax+rax*1], eax
00007fc78d9ce6a0  mov qword ptr [r15+0x20], 0x420060
00007fc78d9ce6a8  xor eax, eax
00007fc78d9ce6aa  xor r14d, r14d
00007fc78d9ce6ad  shrd rax, r14, 0x0D
00007fc78d9ce6b2  mov [rsp+0x10], rax
00007fc78d9ce6b7  shr rax, 0x07
00007fc78d9ce6bb  mov r14, [rsp+0x10]
00007fc78d9ce6c0  xor r14, rax
00007fc78d9ce6c3  lea rax, [r14+0x03]
00007fc78d9ce6c7  mov [r15], rax
00007fc78d9ce6ca  xor eax, eax
00007fc78d9ce6cc  mov r14d, 0xB71B00
00007fc78d9ce6d2  mov r12d, 0x01
00007fc78d9ce6d8  sub r14, r12
00007fc78d9ce6db  cmc
00007fc78d9ce6dc  lahf
00007fc78d9ce6dd  seto al
00007fc78d9ce6e0  mov [r15+0x108], eax
00007fc78d9ce6e7  mov [r15+0x08], r14
00007fc78d9ce6eb  mov eax, [r15+0x108]
00007fc78d9ce6f2  sahf
00007fc78d9ce6f3  jnz 0x00007FC78D9CE725
00007fc78d9ce6f5  cmp dword ptr [r15+0x318], 0x00
00007fc78d9ce6fd  jz 0x00007FC78D9CE820
00007fc78d9ce703  nop [rax+rax*1], ax
00007fc78d9ce70c  nop [rax+rax*1], eax
00007fc78d9ce714  mov eax, 0x410050
00007fc78d9ce719  mov [r15+0x100], rax
00007fc78d9ce720  jmp 0x00007FC78D7FE110
00007fc78d9ce725  cmp dword ptr [r15+0x318], 0x00
00007fc78d9ce72d  jz 0x00007FC78D9CE760
00007fc78d9ce733  nop [rax+rax*1], ax
00007fc78d9ce73c  nop [rax+rax*1], eax
00007fc78d9ce744  mov eax, 0x41003C
00007fc78d9ce749  mov [r15+0x100], rax
00007fc78d9ce750  jmp 0x00007FC78D7FE110
00007fc78d9ce755  int3
00007fc78d9ce756  int3
00007fc78d9ce757  nop [rax+rax*1], ax
00007fc78d9ce760  mov rax, [r15]
00007fc78d9ce763  mov [rsp+0x10], rax
00007fc78d9ce768  mov r14, [rsp+0x10]
00007fc78d9ce76d  shrd rax, r14, 0x0D
00007fc78d9ce772  mov [rsp+0x10], rax
00007fc78d9ce777  shr rax, 0x07
00007fc78d9ce77b  mov r14, [rsp+0x10]
00007fc78d9ce780  xor r14, rax
00007fc78d9ce783  lea rax, [r14+0x03]
00007fc78d9ce787  mov [r15], rax
00007fc78d9ce78a  mov rax, [r15+0x08]
00007fc78d9ce78e  mov [rsp+0x10], rax
00007fc78d9ce793  xor eax, eax
00007fc78d9ce795  mov r14, [rsp+0x10]
00007fc78d9ce79a  mov r12d, 0x01
00007fc78d9ce7a0  sub r14, r12
00007fc78d9ce7a3  cmc
00007fc78d9ce7a4  lahf
00007fc78d9ce7a5  seto al
00007fc78d9ce7a8  mov [r15+0x108], eax
00007fc78d9ce7af  mov [r15+0x08], r14
00007fc78d9ce7b3  mov eax, [r15+0x108]
00007fc78d9ce7ba  sahf
00007fc78d9ce7bb  jnz 0x00007FC78D9CE7ED
00007fc78d9ce7bd  cmp dword ptr [r15+0x318], 0x00
00007fc78d9ce7c5  jz 0x00007FC78D9CE820
00007fc78d9ce7cb  nop [rax+rax*1], ax
00007fc78d9ce7d4  nop [rax+rax*1], eax
00007fc78d9ce7dc  mov eax, 0x410050
00007fc78d9ce7e1  mov [r15+0x100], rax
00007fc78d9ce7e8  jmp 0x00007FC78D7FE110
00007fc78d9ce7ed  cmp dword ptr [r15+0x318], 0x00
00007fc78d9ce7f5  jz 0x00007FC78D9CE760
00007fc78d9ce7fb  nop [rax+rax*1], ax
00007fc78d9ce804  nop [rax+rax*1], eax
00007fc78d9ce80c  mov eax, 0x41003C
00007fc78d9ce811  mov [r15+0x100], rax
00007fc78d9ce818  jmp 0x00007FC78D7FE110
00007fc78d9ce81d  int3
00007fc78d9ce81e  int3
00007fc78d9ce81f  nop
00007fc78d9ce820  mov rax, [r15+0x20]
00007fc78d9ce824  mov r14, [r15]
00007fc78d9ce827  mov [r13+rax*1], r14
00007fc78d9ce82c  mov rax, [r15+0xF0]
00007fc78d9ce833  mov [r15+0x100], rax
00007fc78d9ce83a  jmp 0x00007FC78D9CE5C0
00007fc78d9ce83f  int3
00007fc78d9ce840  call 0x00007FC78D80E120
00007fc78d9ce845  jmp 0x00007FC78D9CE82C
00007fc78d9ce84a  int3
00007fc78d9ce84b  nop [rax+rax*1], eax
00007fc78d9ce850  mov qword ptr [r15+0x100], 0x04
00007fc78d9ce85b  mov esi, 0x00
00007fc78d9ce860  mov edx, 0x09
00007fc78d9ce865  mov rdi, 0x7FFEDA8822E0
00007fc78d9ce86f  mov rax, 0x5E9D02C80970
00007fc78d9ce879  call rax
00007fc78d9ce87b  cmp dword ptr [r15+0x318], 0x00
00007fc78d9ce883  jnz 0x00007FC78D7FE110
00007fc78d9ce889  jmp 0x00007FC78D7FE0A0
00007fc78d9ce88e  int3
00007fc78d9ce88f  int3
