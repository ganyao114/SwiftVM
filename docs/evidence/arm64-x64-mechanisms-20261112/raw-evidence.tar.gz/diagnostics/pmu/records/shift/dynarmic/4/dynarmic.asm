00007daeb03ce69b  nop [rax+rax*1], eax
00007daeb03ce6a0  mov qword ptr [r15+0x20], 0x420060
00007daeb03ce6a8  xor eax, eax
00007daeb03ce6aa  xor r14d, r14d
00007daeb03ce6ad  shrd rax, r14, 0x0D
00007daeb03ce6b2  mov [rsp+0x10], rax
00007daeb03ce6b7  shr rax, 0x07
00007daeb03ce6bb  mov r14, [rsp+0x10]
00007daeb03ce6c0  xor r14, rax
00007daeb03ce6c3  lea rax, [r14+0x03]
00007daeb03ce6c7  mov [r15], rax
00007daeb03ce6ca  xor eax, eax
00007daeb03ce6cc  mov r14d, 0xB71B00
00007daeb03ce6d2  mov r12d, 0x01
00007daeb03ce6d8  sub r14, r12
00007daeb03ce6db  cmc
00007daeb03ce6dc  lahf
00007daeb03ce6dd  seto al
00007daeb03ce6e0  mov [r15+0x108], eax
00007daeb03ce6e7  mov [r15+0x08], r14
00007daeb03ce6eb  mov eax, [r15+0x108]
00007daeb03ce6f2  sahf
00007daeb03ce6f3  jnz 0x00007DAEB03CE725
00007daeb03ce6f5  cmp dword ptr [r15+0x318], 0x00
00007daeb03ce6fd  jz 0x00007DAEB03CE820
00007daeb03ce703  nop [rax+rax*1], ax
00007daeb03ce70c  nop [rax+rax*1], eax
00007daeb03ce714  mov eax, 0x410050
00007daeb03ce719  mov [r15+0x100], rax
00007daeb03ce720  jmp 0x00007DAEB01FE110
00007daeb03ce725  cmp dword ptr [r15+0x318], 0x00
00007daeb03ce72d  jz 0x00007DAEB03CE760
00007daeb03ce733  nop [rax+rax*1], ax
00007daeb03ce73c  nop [rax+rax*1], eax
00007daeb03ce744  mov eax, 0x41003C
00007daeb03ce749  mov [r15+0x100], rax
00007daeb03ce750  jmp 0x00007DAEB01FE110
00007daeb03ce755  int3
00007daeb03ce756  int3
00007daeb03ce757  nop [rax+rax*1], ax
00007daeb03ce760  mov rax, [r15]
00007daeb03ce763  mov [rsp+0x10], rax
00007daeb03ce768  mov r14, [rsp+0x10]
00007daeb03ce76d  shrd rax, r14, 0x0D
00007daeb03ce772  mov [rsp+0x10], rax
00007daeb03ce777  shr rax, 0x07
00007daeb03ce77b  mov r14, [rsp+0x10]
00007daeb03ce780  xor r14, rax
00007daeb03ce783  lea rax, [r14+0x03]
00007daeb03ce787  mov [r15], rax
00007daeb03ce78a  mov rax, [r15+0x08]
00007daeb03ce78e  mov [rsp+0x10], rax
00007daeb03ce793  xor eax, eax
00007daeb03ce795  mov r14, [rsp+0x10]
00007daeb03ce79a  mov r12d, 0x01
00007daeb03ce7a0  sub r14, r12
00007daeb03ce7a3  cmc
00007daeb03ce7a4  lahf
00007daeb03ce7a5  seto al
00007daeb03ce7a8  mov [r15+0x108], eax
00007daeb03ce7af  mov [r15+0x08], r14
00007daeb03ce7b3  mov eax, [r15+0x108]
00007daeb03ce7ba  sahf
00007daeb03ce7bb  jnz 0x00007DAEB03CE7ED
00007daeb03ce7bd  cmp dword ptr [r15+0x318], 0x00
00007daeb03ce7c5  jz 0x00007DAEB03CE820
00007daeb03ce7cb  nop [rax+rax*1], ax
00007daeb03ce7d4  nop [rax+rax*1], eax
00007daeb03ce7dc  mov eax, 0x410050
00007daeb03ce7e1  mov [r15+0x100], rax
00007daeb03ce7e8  jmp 0x00007DAEB01FE110
00007daeb03ce7ed  cmp dword ptr [r15+0x318], 0x00
00007daeb03ce7f5  jz 0x00007DAEB03CE760
00007daeb03ce7fb  nop [rax+rax*1], ax
00007daeb03ce804  nop [rax+rax*1], eax
00007daeb03ce80c  mov eax, 0x41003C
00007daeb03ce811  mov [r15+0x100], rax
00007daeb03ce818  jmp 0x00007DAEB01FE110
00007daeb03ce81d  int3
00007daeb03ce81e  int3
00007daeb03ce81f  nop
00007daeb03ce820  mov rax, [r15+0x20]
00007daeb03ce824  mov r14, [r15]
00007daeb03ce827  mov [r13+rax*1], r14
00007daeb03ce82c  mov rax, [r15+0xF0]
00007daeb03ce833  mov [r15+0x100], rax
00007daeb03ce83a  jmp 0x00007DAEB03CE5C0
00007daeb03ce83f  int3
00007daeb03ce840  call 0x00007DAEB020E120
00007daeb03ce845  jmp 0x00007DAEB03CE82C
00007daeb03ce84a  int3
00007daeb03ce84b  nop [rax+rax*1], eax
00007daeb03ce850  mov qword ptr [r15+0x100], 0x04
00007daeb03ce85b  mov esi, 0x00
00007daeb03ce860  mov edx, 0x09
00007daeb03ce865  mov rdi, 0x7FFCB4E75580
00007daeb03ce86f  mov rax, 0x62EC8ED97970
00007daeb03ce879  call rax
00007daeb03ce87b  cmp dword ptr [r15+0x318], 0x00
00007daeb03ce883  jnz 0x00007DAEB01FE110
00007daeb03ce889  jmp 0x00007DAEB01FE0A0
00007daeb03ce88e  int3
00007daeb03ce88f  int3
