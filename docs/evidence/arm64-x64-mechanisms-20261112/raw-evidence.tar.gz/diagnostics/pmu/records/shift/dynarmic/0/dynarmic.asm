00007e4bc8dce69b  nop [rax+rax*1], eax
00007e4bc8dce6a0  mov qword ptr [r15+0x20], 0x420060
00007e4bc8dce6a8  xor eax, eax
00007e4bc8dce6aa  xor r14d, r14d
00007e4bc8dce6ad  shrd rax, r14, 0x0D
00007e4bc8dce6b2  mov [rsp+0x10], rax
00007e4bc8dce6b7  shr rax, 0x07
00007e4bc8dce6bb  mov r14, [rsp+0x10]
00007e4bc8dce6c0  xor r14, rax
00007e4bc8dce6c3  lea rax, [r14+0x03]
00007e4bc8dce6c7  mov [r15], rax
00007e4bc8dce6ca  xor eax, eax
00007e4bc8dce6cc  mov r14d, 0xB71B00
00007e4bc8dce6d2  mov r12d, 0x01
00007e4bc8dce6d8  sub r14, r12
00007e4bc8dce6db  cmc
00007e4bc8dce6dc  lahf
00007e4bc8dce6dd  seto al
00007e4bc8dce6e0  mov [r15+0x108], eax
00007e4bc8dce6e7  mov [r15+0x08], r14
00007e4bc8dce6eb  mov eax, [r15+0x108]
00007e4bc8dce6f2  sahf
00007e4bc8dce6f3  jnz 0x00007E4BC8DCE725
00007e4bc8dce6f5  cmp dword ptr [r15+0x318], 0x00
00007e4bc8dce6fd  jz 0x00007E4BC8DCE820
00007e4bc8dce703  nop [rax+rax*1], ax
00007e4bc8dce70c  nop [rax+rax*1], eax
00007e4bc8dce714  mov eax, 0x410050
00007e4bc8dce719  mov [r15+0x100], rax
00007e4bc8dce720  jmp 0x00007E4BC8BFE110
00007e4bc8dce725  cmp dword ptr [r15+0x318], 0x00
00007e4bc8dce72d  jz 0x00007E4BC8DCE760
00007e4bc8dce733  nop [rax+rax*1], ax
00007e4bc8dce73c  nop [rax+rax*1], eax
00007e4bc8dce744  mov eax, 0x41003C
00007e4bc8dce749  mov [r15+0x100], rax
00007e4bc8dce750  jmp 0x00007E4BC8BFE110
00007e4bc8dce755  int3
00007e4bc8dce756  int3
00007e4bc8dce757  nop [rax+rax*1], ax
00007e4bc8dce760  mov rax, [r15]
00007e4bc8dce763  mov [rsp+0x10], rax
00007e4bc8dce768  mov r14, [rsp+0x10]
00007e4bc8dce76d  shrd rax, r14, 0x0D
00007e4bc8dce772  mov [rsp+0x10], rax
00007e4bc8dce777  shr rax, 0x07
00007e4bc8dce77b  mov r14, [rsp+0x10]
00007e4bc8dce780  xor r14, rax
00007e4bc8dce783  lea rax, [r14+0x03]
00007e4bc8dce787  mov [r15], rax
00007e4bc8dce78a  mov rax, [r15+0x08]
00007e4bc8dce78e  mov [rsp+0x10], rax
00007e4bc8dce793  xor eax, eax
00007e4bc8dce795  mov r14, [rsp+0x10]
00007e4bc8dce79a  mov r12d, 0x01
00007e4bc8dce7a0  sub r14, r12
00007e4bc8dce7a3  cmc
00007e4bc8dce7a4  lahf
00007e4bc8dce7a5  seto al
00007e4bc8dce7a8  mov [r15+0x108], eax
00007e4bc8dce7af  mov [r15+0x08], r14
00007e4bc8dce7b3  mov eax, [r15+0x108]
00007e4bc8dce7ba  sahf
00007e4bc8dce7bb  jnz 0x00007E4BC8DCE7ED
00007e4bc8dce7bd  cmp dword ptr [r15+0x318], 0x00
00007e4bc8dce7c5  jz 0x00007E4BC8DCE820
00007e4bc8dce7cb  nop [rax+rax*1], ax
00007e4bc8dce7d4  nop [rax+rax*1], eax
00007e4bc8dce7dc  mov eax, 0x410050
00007e4bc8dce7e1  mov [r15+0x100], rax
00007e4bc8dce7e8  jmp 0x00007E4BC8BFE110
00007e4bc8dce7ed  cmp dword ptr [r15+0x318], 0x00
00007e4bc8dce7f5  jz 0x00007E4BC8DCE760
00007e4bc8dce7fb  nop [rax+rax*1], ax
00007e4bc8dce804  nop [rax+rax*1], eax
00007e4bc8dce80c  mov eax, 0x41003C
00007e4bc8dce811  mov [r15+0x100], rax
00007e4bc8dce818  jmp 0x00007E4BC8BFE110
00007e4bc8dce81d  int3
00007e4bc8dce81e  int3
00007e4bc8dce81f  nop
00007e4bc8dce820  mov rax, [r15+0x20]
00007e4bc8dce824  mov r14, [r15]
00007e4bc8dce827  mov [r13+rax*1], r14
00007e4bc8dce82c  mov rax, [r15+0xF0]
00007e4bc8dce833  mov [r15+0x100], rax
00007e4bc8dce83a  jmp 0x00007E4BC8DCE5C0
00007e4bc8dce83f  int3
00007e4bc8dce840  call 0x00007E4BC8C0E120
00007e4bc8dce845  jmp 0x00007E4BC8DCE82C
00007e4bc8dce84a  int3
00007e4bc8dce84b  nop [rax+rax*1], eax
00007e4bc8dce850  mov qword ptr [r15+0x100], 0x04
00007e4bc8dce85b  mov esi, 0x00
00007e4bc8dce860  mov edx, 0x09
00007e4bc8dce865  mov rdi, 0x7FFC8A82A970
00007e4bc8dce86f  mov rax, 0x585037FE9970
00007e4bc8dce879  call rax
00007e4bc8dce87b  cmp dword ptr [r15+0x318], 0x00
00007e4bc8dce883  jnz 0x00007E4BC8BFE110
00007e4bc8dce889  jmp 0x00007E4BC8BFE0A0
00007e4bc8dce88e  int3
00007e4bc8dce88f  int3
