0000763af85ce69b  nop [rax+rax*1], eax
0000763af85ce6a0  mov qword ptr [r15+0x20], 0x420080
0000763af85ce6a8  mov qword ptr [r15], 0x00
0000763af85ce6af  vmovaps xmm1, [0x0000763AF81FE010]
0000763af85ce6b7  movq xmm1, xmm1
0000763af85ce6bb  vmovaps xmm15, [0x0000763AF81FE020]
0000763af85ce6c3  movq xmm15, xmm15
0000763af85ce6c8  movaps [r15+0x120], xmm15
0000763af85ce6d0  movq rax, xmm1
0000763af85ce6d5  movq r14, xmm15
0000763af85ce6da  vmovq xmm1, rax
0000763af85ce6df  vmovq xmm14, r14
0000763af85ce6e4  movaps xmm13, xmm1
0000763af85ce6e8  addsd xmm13, xmm14
0000763af85ce6ed  ucomisd xmm13, xmm13
0000763af85ce6f2  jp 0x0000763AF85CE8CC
0000763af85ce6f8  movq xmm13, xmm13
0000763af85ce6fd  movq rax, xmm13
0000763af85ce702  movq r14, xmm15
0000763af85ce707  vmovq xmm1, rax
0000763af85ce70c  vmovq xmm14, r14
0000763af85ce711  movaps xmm13, xmm1
0000763af85ce715  addsd xmm13, xmm14
0000763af85ce71a  ucomisd xmm13, xmm13
0000763af85ce71f  jp 0x0000763AF85CE914
0000763af85ce725  movq xmm13, xmm13
0000763af85ce72a  movq rax, xmm13
0000763af85ce72f  movq r14, xmm15
0000763af85ce734  vmovq xmm1, rax
0000763af85ce739  vmovq xmm14, r14
0000763af85ce73e  movaps xmm13, xmm1
0000763af85ce742  addsd xmm13, xmm14
0000763af85ce747  ucomisd xmm13, xmm13
0000763af85ce74c  jp 0x0000763AF85CE95C
0000763af85ce752  movq xmm13, xmm13
0000763af85ce757  movq rax, xmm13
0000763af85ce75c  movq r14, xmm15
0000763af85ce761  vmovq xmm1, rax
0000763af85ce766  vmovq xmm14, r14
0000763af85ce76b  movaps xmm13, xmm1
0000763af85ce76f  addsd xmm13, xmm14
0000763af85ce774  ucomisd xmm13, xmm13
0000763af85ce779  jp 0x0000763AF85CE9A4
0000763af85ce77f  movq xmm13, xmm13
0000763af85ce784  movq rax, xmm13
0000763af85ce789  movq r14, xmm15
0000763af85ce78e  vmovq xmm1, rax
0000763af85ce793  vmovq xmm14, r14
0000763af85ce798  movaps xmm13, xmm1
0000763af85ce79c  addsd xmm13, xmm14
0000763af85ce7a1  ucomisd xmm13, xmm13
0000763af85ce7a6  jp 0x0000763AF85CE9EC
0000763af85ce7ac  movq xmm13, xmm13
0000763af85ce7b1  movq rax, xmm13
0000763af85ce7b6  movq r14, xmm15
0000763af85ce7bb  vmovq xmm1, rax
0000763af85ce7c0  vmovq xmm14, r14
0000763af85ce7c5  movaps xmm13, xmm1
0000763af85ce7c9  addsd xmm13, xmm14
0000763af85ce7ce  ucomisd xmm13, xmm13
0000763af85ce7d3  jp 0x0000763AF85CEA34
0000763af85ce7d9  movq xmm13, xmm13
0000763af85ce7de  movq rax, xmm13
0000763af85ce7e3  movq r14, xmm15
0000763af85ce7e8  vmovq xmm1, rax
0000763af85ce7ed  vmovq xmm14, r14
0000763af85ce7f2  movaps xmm13, xmm1
0000763af85ce7f6  addsd xmm13, xmm14
0000763af85ce7fb  ucomisd xmm13, xmm13
0000763af85ce800  jp 0x0000763AF85CEA7C
0000763af85ce806  movq xmm13, xmm13
0000763af85ce80b  movq rax, xmm13
0000763af85ce810  movq r14, xmm15
0000763af85ce815  vmovq xmm1, rax
0000763af85ce81a  vmovq xmm15, r14
0000763af85ce81f  movaps xmm14, xmm1
0000763af85ce823  addsd xmm14, xmm15
0000763af85ce828  ucomisd xmm14, xmm14
0000763af85ce82d  jp 0x0000763AF85CEAC4
0000763af85ce833  movq xmm14, xmm14
0000763af85ce838  movaps [r15+0x110], xmm14
0000763af85ce840  xor eax, eax
0000763af85ce842  mov r14d, 0x1E848
0000763af85ce848  mov r12d, 0x01
0000763af85ce84e  sub r14, r12
0000763af85ce851  cmc
0000763af85ce852  lahf
0000763af85ce853  seto al
0000763af85ce856  mov [r15+0x108], eax
0000763af85ce85d  mov [r15+0x08], r14
0000763af85ce861  mov eax, [r15+0x108]
0000763af85ce868  sahf
0000763af85ce869  jnz 0x0000763AF85CE89B
0000763af85ce86b  cmp dword ptr [r15+0x318], 0x00
0000763af85ce873  jz 0x0000763AF85CEF70
0000763af85ce879  nop [rax+rax*1], ax
0000763af85ce882  nop [rax+rax*1], eax
0000763af85ce88a  mov eax, 0x41006C
0000763af85ce88f  mov [r15+0x100], rax
0000763af85ce896  jmp 0x0000763AF83FE110
0000763af85ce89b  cmp dword ptr [r15+0x318], 0x00
0000763af85ce8a3  jz 0x0000763AF85CEB10
0000763af85ce8a9  nop [rax+rax*1], ax
0000763af85ce8b2  nop [rax+rax*1], eax
0000763af85ce8ba  mov eax, 0x410044
0000763af85ce8bf  mov [r15+0x100], rax
0000763af85ce8c6  jmp 0x0000763AF83FE110
0000763af85ce8cb  int3
0000763af85ce8cc  ucomisd xmm1, xmm14
0000763af85ce8d1  jp 0x0000763AF85CE8E0
0000763af85ce8d3  movaps xmm13, [0x0000763AF81FE030]
0000763af85ce8db  jmp 0x0000763AF85CE6F8
0000763af85ce8e0  vxorps xmm0, xmm1, xmm14
0000763af85ce8e5  pextrw eax, xmm0, 0x03
0000763af85ce8ea  and eax, 0x7FF8
0000763af85ce8ef  cmp eax, 0x08
0000763af85ce8f2  jnz 0x0000763AF85CE6F8
0000763af85ce8f8  movq rax, xmm14
0000763af85ce8fd  shl rax, 0x0D
0000763af85ce901  jbe 0x0000763AF85CE6F8
0000763af85ce907  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85ce90f  jmp 0x0000763AF85CE6F8
0000763af85ce914  ucomisd xmm1, xmm14
0000763af85ce919  jp 0x0000763AF85CE928
0000763af85ce91b  movaps xmm13, [0x0000763AF81FE030]
0000763af85ce923  jmp 0x0000763AF85CE725
0000763af85ce928  vxorps xmm0, xmm1, xmm14
0000763af85ce92d  pextrw eax, xmm0, 0x03
0000763af85ce932  and eax, 0x7FF8
0000763af85ce937  cmp eax, 0x08
0000763af85ce93a  jnz 0x0000763AF85CE725
0000763af85ce940  movq rax, xmm14
0000763af85ce945  shl rax, 0x0D
0000763af85ce949  jbe 0x0000763AF85CE725
0000763af85ce94f  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85ce957  jmp 0x0000763AF85CE725
0000763af85ce95c  ucomisd xmm1, xmm14
0000763af85ce961  jp 0x0000763AF85CE970
0000763af85ce963  movaps xmm13, [0x0000763AF81FE030]
0000763af85ce96b  jmp 0x0000763AF85CE752
0000763af85ce970  vxorps xmm0, xmm1, xmm14
0000763af85ce975  pextrw eax, xmm0, 0x03
0000763af85ce97a  and eax, 0x7FF8
0000763af85ce97f  cmp eax, 0x08
0000763af85ce982  jnz 0x0000763AF85CE752
0000763af85ce988  movq rax, xmm14
0000763af85ce98d  shl rax, 0x0D
0000763af85ce991  jbe 0x0000763AF85CE752
0000763af85ce997  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85ce99f  jmp 0x0000763AF85CE752
0000763af85ce9a4  ucomisd xmm1, xmm14
0000763af85ce9a9  jp 0x0000763AF85CE9B8
0000763af85ce9ab  movaps xmm13, [0x0000763AF81FE030]
0000763af85ce9b3  jmp 0x0000763AF85CE77F
0000763af85ce9b8  vxorps xmm0, xmm1, xmm14
0000763af85ce9bd  pextrw eax, xmm0, 0x03
0000763af85ce9c2  and eax, 0x7FF8
0000763af85ce9c7  cmp eax, 0x08
0000763af85ce9ca  jnz 0x0000763AF85CE77F
0000763af85ce9d0  movq rax, xmm14
0000763af85ce9d5  shl rax, 0x0D
0000763af85ce9d9  jbe 0x0000763AF85CE77F
0000763af85ce9df  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85ce9e7  jmp 0x0000763AF85CE77F
0000763af85ce9ec  ucomisd xmm1, xmm14
0000763af85ce9f1  jp 0x0000763AF85CEA00
0000763af85ce9f3  movaps xmm13, [0x0000763AF81FE030]
0000763af85ce9fb  jmp 0x0000763AF85CE7AC
0000763af85cea00  vxorps xmm0, xmm1, xmm14
0000763af85cea05  pextrw eax, xmm0, 0x03
0000763af85cea0a  and eax, 0x7FF8
0000763af85cea0f  cmp eax, 0x08
0000763af85cea12  jnz 0x0000763AF85CE7AC
0000763af85cea18  movq rax, xmm14
0000763af85cea1d  shl rax, 0x0D
0000763af85cea21  jbe 0x0000763AF85CE7AC
0000763af85cea27  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85cea2f  jmp 0x0000763AF85CE7AC
0000763af85cea34  ucomisd xmm1, xmm14
0000763af85cea39  jp 0x0000763AF85CEA48
0000763af85cea3b  movaps xmm13, [0x0000763AF81FE030]
0000763af85cea43  jmp 0x0000763AF85CE7D9
0000763af85cea48  vxorps xmm0, xmm1, xmm14
0000763af85cea4d  pextrw eax, xmm0, 0x03
0000763af85cea52  and eax, 0x7FF8
0000763af85cea57  cmp eax, 0x08
0000763af85cea5a  jnz 0x0000763AF85CE7D9
0000763af85cea60  movq rax, xmm14
0000763af85cea65  shl rax, 0x0D
0000763af85cea69  jbe 0x0000763AF85CE7D9
0000763af85cea6f  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85cea77  jmp 0x0000763AF85CE7D9
0000763af85cea7c  ucomisd xmm1, xmm14
0000763af85cea81  jp 0x0000763AF85CEA90
0000763af85cea83  movaps xmm13, [0x0000763AF81FE030]
0000763af85cea8b  jmp 0x0000763AF85CE806
0000763af85cea90  vxorps xmm0, xmm1, xmm14
0000763af85cea95  pextrw eax, xmm0, 0x03
0000763af85cea9a  and eax, 0x7FF8
0000763af85cea9f  cmp eax, 0x08
0000763af85ceaa2  jnz 0x0000763AF85CE806
0000763af85ceaa8  movq rax, xmm14
0000763af85ceaad  shl rax, 0x0D
0000763af85ceab1  jbe 0x0000763AF85CE806
0000763af85ceab7  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85ceabf  jmp 0x0000763AF85CE806
0000763af85ceac4  ucomisd xmm1, xmm15
0000763af85ceac9  jp 0x0000763AF85CEAD8
0000763af85ceacb  movaps xmm14, [0x0000763AF81FE030]
0000763af85cead3  jmp 0x0000763AF85CE833
0000763af85cead8  vxorps xmm0, xmm1, xmm15
0000763af85ceadd  pextrw eax, xmm0, 0x03
0000763af85ceae2  and eax, 0x7FF8
0000763af85ceae7  cmp eax, 0x08
0000763af85ceaea  jnz 0x0000763AF85CE833
0000763af85ceaf0  movq rax, xmm15
0000763af85ceaf5  shl rax, 0x0D
0000763af85ceaf9  jbe 0x0000763AF85CE833
0000763af85ceaff  vorps xmm14, xmm15, [0x0000763AF81FE040]
0000763af85ceb07  jmp 0x0000763AF85CE833
0000763af85ceb0c  int3
0000763af85ceb0d  nop [rax], eax
0000763af85ceb10  movaps xmm1, [r15+0x110]
0000763af85ceb18  movq rax, xmm1
0000763af85ceb1d  movaps xmm1, [r15+0x120]
0000763af85ceb25  movq r14, xmm1
0000763af85ceb2a  vmovq xmm15, rax
0000763af85ceb2f  vmovq xmm14, r14
0000763af85ceb34  movaps xmm13, xmm15
0000763af85ceb38  addsd xmm13, xmm14
0000763af85ceb3d  ucomisd xmm13, xmm13
0000763af85ceb42  jp 0x0000763AF85CED24
0000763af85ceb48  movq xmm13, xmm13
0000763af85ceb4d  movq rax, xmm13
0000763af85ceb52  movq r14, xmm1
0000763af85ceb57  vmovq xmm15, rax
0000763af85ceb5c  vmovq xmm14, r14
0000763af85ceb61  movaps xmm13, xmm15
0000763af85ceb65  addsd xmm13, xmm14
0000763af85ceb6a  ucomisd xmm13, xmm13
0000763af85ceb6f  jp 0x0000763AF85CED6C
0000763af85ceb75  movq xmm13, xmm13
0000763af85ceb7a  movq rax, xmm13
0000763af85ceb7f  movq r14, xmm1
0000763af85ceb84  vmovq xmm15, rax
0000763af85ceb89  vmovq xmm14, r14
0000763af85ceb8e  movaps xmm13, xmm15
0000763af85ceb92  addsd xmm13, xmm14
0000763af85ceb97  ucomisd xmm13, xmm13
0000763af85ceb9c  jp 0x0000763AF85CEDB4
0000763af85ceba2  movq xmm13, xmm13
0000763af85ceba7  movq rax, xmm13
0000763af85cebac  movq r14, xmm1
0000763af85cebb1  vmovq xmm15, rax
0000763af85cebb6  vmovq xmm14, r14
0000763af85cebbb  movaps xmm13, xmm15
0000763af85cebbf  addsd xmm13, xmm14
0000763af85cebc4  ucomisd xmm13, xmm13
0000763af85cebc9  jp 0x0000763AF85CEDFC
0000763af85cebcf  movq xmm13, xmm13
0000763af85cebd4  movq rax, xmm13
0000763af85cebd9  movq r14, xmm1
0000763af85cebde  vmovq xmm15, rax
0000763af85cebe3  vmovq xmm14, r14
0000763af85cebe8  movaps xmm13, xmm15
0000763af85cebec  addsd xmm13, xmm14
0000763af85cebf1  ucomisd xmm13, xmm13
0000763af85cebf6  jp 0x0000763AF85CEE44
0000763af85cebfc  movq xmm13, xmm13
0000763af85cec01  movq rax, xmm13
0000763af85cec06  movq r14, xmm1
0000763af85cec0b  vmovq xmm15, rax
0000763af85cec10  vmovq xmm14, r14
0000763af85cec15  movaps xmm13, xmm15
0000763af85cec19  addsd xmm13, xmm14
0000763af85cec1e  ucomisd xmm13, xmm13
0000763af85cec23  jp 0x0000763AF85CEE8C
0000763af85cec29  movq xmm13, xmm13
0000763af85cec2e  movq rax, xmm13
0000763af85cec33  movq r14, xmm1
0000763af85cec38  vmovq xmm15, rax
0000763af85cec3d  vmovq xmm14, r14
0000763af85cec42  movaps xmm13, xmm15
0000763af85cec46  addsd xmm13, xmm14
0000763af85cec4b  ucomisd xmm13, xmm13
0000763af85cec50  jp 0x0000763AF85CEED4
0000763af85cec56  movq xmm13, xmm13
0000763af85cec5b  movq rax, xmm13
0000763af85cec60  movq r14, xmm1
0000763af85cec65  vmovq xmm1, rax
0000763af85cec6a  vmovq xmm15, r14
0000763af85cec6f  movaps xmm14, xmm1
0000763af85cec73  addsd xmm14, xmm15
0000763af85cec78  ucomisd xmm14, xmm14
0000763af85cec7d  jp 0x0000763AF85CEF1C
0000763af85cec83  movq xmm14, xmm14
0000763af85cec88  movaps [r15+0x110], xmm14
0000763af85cec90  mov rax, [r15+0x08]
0000763af85cec94  mov [rsp+0x10], rax
0000763af85cec99  xor eax, eax
0000763af85cec9b  mov r14, [rsp+0x10]
0000763af85ceca0  mov r12d, 0x01
0000763af85ceca6  sub r14, r12
0000763af85ceca9  cmc
0000763af85cecaa  lahf
0000763af85cecab  seto al
0000763af85cecae  mov [r15+0x108], eax
0000763af85cecb5  mov [r15+0x08], r14
0000763af85cecb9  mov eax, [r15+0x108]
0000763af85cecc0  sahf
0000763af85cecc1  jnz 0x0000763AF85CECF3
0000763af85cecc3  cmp dword ptr [r15+0x318], 0x00
0000763af85ceccb  jz 0x0000763AF85CEF70
0000763af85cecd1  nop [rax+rax*1], ax
0000763af85cecda  nop [rax+rax*1], eax
0000763af85cece2  mov eax, 0x41006C
0000763af85cece7  mov [r15+0x100], rax
0000763af85cecee  jmp 0x0000763AF83FE110
0000763af85cecf3  cmp dword ptr [r15+0x318], 0x00
0000763af85cecfb  jz 0x0000763AF85CEB10
0000763af85ced01  nop [rax+rax*1], ax
0000763af85ced0a  nop [rax+rax*1], eax
0000763af85ced12  mov eax, 0x410044
0000763af85ced17  mov [r15+0x100], rax
0000763af85ced1e  jmp 0x0000763AF83FE110
0000763af85ced23  int3
0000763af85ced24  ucomisd xmm15, xmm14
0000763af85ced29  jp 0x0000763AF85CED38
0000763af85ced2b  movaps xmm13, [0x0000763AF81FE030]
0000763af85ced33  jmp 0x0000763AF85CEB48
0000763af85ced38  vxorps xmm0, xmm15, xmm14
0000763af85ced3d  pextrw eax, xmm0, 0x03
0000763af85ced42  and eax, 0x7FF8
0000763af85ced47  cmp eax, 0x08
0000763af85ced4a  jnz 0x0000763AF85CEB48
0000763af85ced50  movq rax, xmm14
0000763af85ced55  shl rax, 0x0D
0000763af85ced59  jbe 0x0000763AF85CEB48
0000763af85ced5f  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85ced67  jmp 0x0000763AF85CEB48
0000763af85ced6c  ucomisd xmm15, xmm14
0000763af85ced71  jp 0x0000763AF85CED80
0000763af85ced73  movaps xmm13, [0x0000763AF81FE030]
0000763af85ced7b  jmp 0x0000763AF85CEB75
0000763af85ced80  vxorps xmm0, xmm15, xmm14
0000763af85ced85  pextrw eax, xmm0, 0x03
0000763af85ced8a  and eax, 0x7FF8
0000763af85ced8f  cmp eax, 0x08
0000763af85ced92  jnz 0x0000763AF85CEB75
0000763af85ced98  movq rax, xmm14
0000763af85ced9d  shl rax, 0x0D
0000763af85ceda1  jbe 0x0000763AF85CEB75
0000763af85ceda7  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85cedaf  jmp 0x0000763AF85CEB75
0000763af85cedb4  ucomisd xmm15, xmm14
0000763af85cedb9  jp 0x0000763AF85CEDC8
0000763af85cedbb  movaps xmm13, [0x0000763AF81FE030]
0000763af85cedc3  jmp 0x0000763AF85CEBA2
0000763af85cedc8  vxorps xmm0, xmm15, xmm14
0000763af85cedcd  pextrw eax, xmm0, 0x03
0000763af85cedd2  and eax, 0x7FF8
0000763af85cedd7  cmp eax, 0x08
0000763af85cedda  jnz 0x0000763AF85CEBA2
0000763af85cede0  movq rax, xmm14
0000763af85cede5  shl rax, 0x0D
0000763af85cede9  jbe 0x0000763AF85CEBA2
0000763af85cedef  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85cedf7  jmp 0x0000763AF85CEBA2
0000763af85cedfc  ucomisd xmm15, xmm14
0000763af85cee01  jp 0x0000763AF85CEE10
0000763af85cee03  movaps xmm13, [0x0000763AF81FE030]
0000763af85cee0b  jmp 0x0000763AF85CEBCF
0000763af85cee10  vxorps xmm0, xmm15, xmm14
0000763af85cee15  pextrw eax, xmm0, 0x03
0000763af85cee1a  and eax, 0x7FF8
0000763af85cee1f  cmp eax, 0x08
0000763af85cee22  jnz 0x0000763AF85CEBCF
0000763af85cee28  movq rax, xmm14
0000763af85cee2d  shl rax, 0x0D
0000763af85cee31  jbe 0x0000763AF85CEBCF
0000763af85cee37  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85cee3f  jmp 0x0000763AF85CEBCF
0000763af85cee44  ucomisd xmm15, xmm14
0000763af85cee49  jp 0x0000763AF85CEE58
0000763af85cee4b  movaps xmm13, [0x0000763AF81FE030]
0000763af85cee53  jmp 0x0000763AF85CEBFC
0000763af85cee58  vxorps xmm0, xmm15, xmm14
0000763af85cee5d  pextrw eax, xmm0, 0x03
0000763af85cee62  and eax, 0x7FF8
0000763af85cee67  cmp eax, 0x08
0000763af85cee6a  jnz 0x0000763AF85CEBFC
0000763af85cee70  movq rax, xmm14
0000763af85cee75  shl rax, 0x0D
0000763af85cee79  jbe 0x0000763AF85CEBFC
0000763af85cee7f  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85cee87  jmp 0x0000763AF85CEBFC
0000763af85cee8c  ucomisd xmm15, xmm14
0000763af85cee91  jp 0x0000763AF85CEEA0
0000763af85cee93  movaps xmm13, [0x0000763AF81FE030]
0000763af85cee9b  jmp 0x0000763AF85CEC29
0000763af85ceea0  vxorps xmm0, xmm15, xmm14
0000763af85ceea5  pextrw eax, xmm0, 0x03
0000763af85ceeaa  and eax, 0x7FF8
0000763af85ceeaf  cmp eax, 0x08
0000763af85ceeb2  jnz 0x0000763AF85CEC29
0000763af85ceeb8  movq rax, xmm14
0000763af85ceebd  shl rax, 0x0D
0000763af85ceec1  jbe 0x0000763AF85CEC29
0000763af85ceec7  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85ceecf  jmp 0x0000763AF85CEC29
0000763af85ceed4  ucomisd xmm15, xmm14
0000763af85ceed9  jp 0x0000763AF85CEEE8
0000763af85ceedb  movaps xmm13, [0x0000763AF81FE030]
0000763af85ceee3  jmp 0x0000763AF85CEC56
0000763af85ceee8  vxorps xmm0, xmm15, xmm14
0000763af85ceeed  pextrw eax, xmm0, 0x03
0000763af85ceef2  and eax, 0x7FF8
0000763af85ceef7  cmp eax, 0x08
0000763af85ceefa  jnz 0x0000763AF85CEC56
0000763af85cef00  movq rax, xmm14
0000763af85cef05  shl rax, 0x0D
0000763af85cef09  jbe 0x0000763AF85CEC56
0000763af85cef0f  vorps xmm13, xmm14, [0x0000763AF81FE040]
0000763af85cef17  jmp 0x0000763AF85CEC56
0000763af85cef1c  ucomisd xmm1, xmm15
0000763af85cef21  jp 0x0000763AF85CEF30
0000763af85cef23  movaps xmm14, [0x0000763AF81FE030]
0000763af85cef2b  jmp 0x0000763AF85CEC83
0000763af85cef30  vxorps xmm0, xmm1, xmm15
0000763af85cef35  pextrw eax, xmm0, 0x03
0000763af85cef3a  and eax, 0x7FF8
0000763af85cef3f  cmp eax, 0x08
0000763af85cef42  jnz 0x0000763AF85CEC83
0000763af85cef48  movq rax, xmm15
0000763af85cef4d  shl rax, 0x0D
0000763af85cef51  jbe 0x0000763AF85CEC83
0000763af85cef57  vorps xmm14, xmm15, [0x0000763AF81FE040]
0000763af85cef5f  jmp 0x0000763AF85CEC83
0000763af85cef64  int3
0000763af85cef65  nop [rax+rax*1], ax
0000763af85cef6e  nop
0000763af85cef70  mov rax, [r15+0x20]
0000763af85cef74  movaps xmm1, [r15+0x110]
0000763af85cef7c  movq r14, xmm1
0000763af85cef81  mov [r13+rax*1], r14
0000763af85cef86  mov rax, [r15+0xF0]
0000763af85cef8d  mov [r15+0x100], rax
0000763af85cef94  jmp 0x0000763AF85CE5C0
0000763af85cef99  int3
0000763af85cef9a  call 0x0000763AF840E120
0000763af85cef9f  jmp 0x0000763AF85CEF86
0000763af85cefa4  int3
0000763af85cefa5  nop [rax+rax*1], ax
0000763af85cefae  nop
0000763af85cefb0  mov qword ptr [r15+0x100], 0x04
0000763af85cefbb  mov esi, 0x00
0000763af85cefc0  mov edx, 0x09
0000763af85cefc5  mov rdi, 0x7FFE74466B20
0000763af85cefcf  mov rax, 0x57087F7F0970
0000763af85cefd9  call rax
0000763af85cefdb  cmp dword ptr [r15+0x318], 0x00
0000763af85cefe3  jnz 0x0000763AF83FE110
0000763af85cefe9  jmp 0x0000763AF83FE0A0
0000763af85cefee  int3
0000763af85cefef  int3
