00007fe746bce69b  nop [rax+rax*1], eax
00007fe746bce6a0  mov qword ptr [r15+0x20], 0x420080
00007fe746bce6a8  mov qword ptr [r15], 0x00
00007fe746bce6af  vmovaps xmm1, [0x00007FE7467FE010]
00007fe746bce6b7  movq xmm1, xmm1
00007fe746bce6bb  vmovaps xmm15, [0x00007FE7467FE020]
00007fe746bce6c3  movq xmm15, xmm15
00007fe746bce6c8  movaps [r15+0x120], xmm15
00007fe746bce6d0  movq rax, xmm1
00007fe746bce6d5  movq r14, xmm15
00007fe746bce6da  vmovq xmm1, rax
00007fe746bce6df  vmovq xmm14, r14
00007fe746bce6e4  movaps xmm13, xmm1
00007fe746bce6e8  addsd xmm13, xmm14
00007fe746bce6ed  ucomisd xmm13, xmm13
00007fe746bce6f2  jp 0x00007FE746BCE8CC
00007fe746bce6f8  movq xmm13, xmm13
00007fe746bce6fd  movq rax, xmm13
00007fe746bce702  movq r14, xmm15
00007fe746bce707  vmovq xmm1, rax
00007fe746bce70c  vmovq xmm14, r14
00007fe746bce711  movaps xmm13, xmm1
00007fe746bce715  addsd xmm13, xmm14
00007fe746bce71a  ucomisd xmm13, xmm13
00007fe746bce71f  jp 0x00007FE746BCE914
00007fe746bce725  movq xmm13, xmm13
00007fe746bce72a  movq rax, xmm13
00007fe746bce72f  movq r14, xmm15
00007fe746bce734  vmovq xmm1, rax
00007fe746bce739  vmovq xmm14, r14
00007fe746bce73e  movaps xmm13, xmm1
00007fe746bce742  addsd xmm13, xmm14
00007fe746bce747  ucomisd xmm13, xmm13
00007fe746bce74c  jp 0x00007FE746BCE95C
00007fe746bce752  movq xmm13, xmm13
00007fe746bce757  movq rax, xmm13
00007fe746bce75c  movq r14, xmm15
00007fe746bce761  vmovq xmm1, rax
00007fe746bce766  vmovq xmm14, r14
00007fe746bce76b  movaps xmm13, xmm1
00007fe746bce76f  addsd xmm13, xmm14
00007fe746bce774  ucomisd xmm13, xmm13
00007fe746bce779  jp 0x00007FE746BCE9A4
00007fe746bce77f  movq xmm13, xmm13
00007fe746bce784  movq rax, xmm13
00007fe746bce789  movq r14, xmm15
00007fe746bce78e  vmovq xmm1, rax
00007fe746bce793  vmovq xmm14, r14
00007fe746bce798  movaps xmm13, xmm1
00007fe746bce79c  addsd xmm13, xmm14
00007fe746bce7a1  ucomisd xmm13, xmm13
00007fe746bce7a6  jp 0x00007FE746BCE9EC
00007fe746bce7ac  movq xmm13, xmm13
00007fe746bce7b1  movq rax, xmm13
00007fe746bce7b6  movq r14, xmm15
00007fe746bce7bb  vmovq xmm1, rax
00007fe746bce7c0  vmovq xmm14, r14
00007fe746bce7c5  movaps xmm13, xmm1
00007fe746bce7c9  addsd xmm13, xmm14
00007fe746bce7ce  ucomisd xmm13, xmm13
00007fe746bce7d3  jp 0x00007FE746BCEA34
00007fe746bce7d9  movq xmm13, xmm13
00007fe746bce7de  movq rax, xmm13
00007fe746bce7e3  movq r14, xmm15
00007fe746bce7e8  vmovq xmm1, rax
00007fe746bce7ed  vmovq xmm14, r14
00007fe746bce7f2  movaps xmm13, xmm1
00007fe746bce7f6  addsd xmm13, xmm14
00007fe746bce7fb  ucomisd xmm13, xmm13
00007fe746bce800  jp 0x00007FE746BCEA7C
00007fe746bce806  movq xmm13, xmm13
00007fe746bce80b  movq rax, xmm13
00007fe746bce810  movq r14, xmm15
00007fe746bce815  vmovq xmm1, rax
00007fe746bce81a  vmovq xmm15, r14
00007fe746bce81f  movaps xmm14, xmm1
00007fe746bce823  addsd xmm14, xmm15
00007fe746bce828  ucomisd xmm14, xmm14
00007fe746bce82d  jp 0x00007FE746BCEAC4
00007fe746bce833  movq xmm14, xmm14
00007fe746bce838  movaps [r15+0x110], xmm14
00007fe746bce840  xor eax, eax
00007fe746bce842  mov r14d, 0x1E848
00007fe746bce848  mov r12d, 0x01
00007fe746bce84e  sub r14, r12
00007fe746bce851  cmc
00007fe746bce852  lahf
00007fe746bce853  seto al
00007fe746bce856  mov [r15+0x108], eax
00007fe746bce85d  mov [r15+0x08], r14
00007fe746bce861  mov eax, [r15+0x108]
00007fe746bce868  sahf
00007fe746bce869  jnz 0x00007FE746BCE89B
00007fe746bce86b  cmp dword ptr [r15+0x318], 0x00
00007fe746bce873  jz 0x00007FE746BCEF70
00007fe746bce879  nop [rax+rax*1], ax
00007fe746bce882  nop [rax+rax*1], eax
00007fe746bce88a  mov eax, 0x41006C
00007fe746bce88f  mov [r15+0x100], rax
00007fe746bce896  jmp 0x00007FE7469FE110
00007fe746bce89b  cmp dword ptr [r15+0x318], 0x00
00007fe746bce8a3  jz 0x00007FE746BCEB10
00007fe746bce8a9  nop [rax+rax*1], ax
00007fe746bce8b2  nop [rax+rax*1], eax
00007fe746bce8ba  mov eax, 0x410044
00007fe746bce8bf  mov [r15+0x100], rax
00007fe746bce8c6  jmp 0x00007FE7469FE110
00007fe746bce8cb  int3
00007fe746bce8cc  ucomisd xmm1, xmm14
00007fe746bce8d1  jp 0x00007FE746BCE8E0
00007fe746bce8d3  movaps xmm13, [0x00007FE7467FE030]
00007fe746bce8db  jmp 0x00007FE746BCE6F8
00007fe746bce8e0  vxorps xmm0, xmm1, xmm14
00007fe746bce8e5  pextrw eax, xmm0, 0x03
00007fe746bce8ea  and eax, 0x7FF8
00007fe746bce8ef  cmp eax, 0x08
00007fe746bce8f2  jnz 0x00007FE746BCE6F8
00007fe746bce8f8  movq rax, xmm14
00007fe746bce8fd  shl rax, 0x0D
00007fe746bce901  jbe 0x00007FE746BCE6F8
00007fe746bce907  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bce90f  jmp 0x00007FE746BCE6F8
00007fe746bce914  ucomisd xmm1, xmm14
00007fe746bce919  jp 0x00007FE746BCE928
00007fe746bce91b  movaps xmm13, [0x00007FE7467FE030]
00007fe746bce923  jmp 0x00007FE746BCE725
00007fe746bce928  vxorps xmm0, xmm1, xmm14
00007fe746bce92d  pextrw eax, xmm0, 0x03
00007fe746bce932  and eax, 0x7FF8
00007fe746bce937  cmp eax, 0x08
00007fe746bce93a  jnz 0x00007FE746BCE725
00007fe746bce940  movq rax, xmm14
00007fe746bce945  shl rax, 0x0D
00007fe746bce949  jbe 0x00007FE746BCE725
00007fe746bce94f  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bce957  jmp 0x00007FE746BCE725
00007fe746bce95c  ucomisd xmm1, xmm14
00007fe746bce961  jp 0x00007FE746BCE970
00007fe746bce963  movaps xmm13, [0x00007FE7467FE030]
00007fe746bce96b  jmp 0x00007FE746BCE752
00007fe746bce970  vxorps xmm0, xmm1, xmm14
00007fe746bce975  pextrw eax, xmm0, 0x03
00007fe746bce97a  and eax, 0x7FF8
00007fe746bce97f  cmp eax, 0x08
00007fe746bce982  jnz 0x00007FE746BCE752
00007fe746bce988  movq rax, xmm14
00007fe746bce98d  shl rax, 0x0D
00007fe746bce991  jbe 0x00007FE746BCE752
00007fe746bce997  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bce99f  jmp 0x00007FE746BCE752
00007fe746bce9a4  ucomisd xmm1, xmm14
00007fe746bce9a9  jp 0x00007FE746BCE9B8
00007fe746bce9ab  movaps xmm13, [0x00007FE7467FE030]
00007fe746bce9b3  jmp 0x00007FE746BCE77F
00007fe746bce9b8  vxorps xmm0, xmm1, xmm14
00007fe746bce9bd  pextrw eax, xmm0, 0x03
00007fe746bce9c2  and eax, 0x7FF8
00007fe746bce9c7  cmp eax, 0x08
00007fe746bce9ca  jnz 0x00007FE746BCE77F
00007fe746bce9d0  movq rax, xmm14
00007fe746bce9d5  shl rax, 0x0D
00007fe746bce9d9  jbe 0x00007FE746BCE77F
00007fe746bce9df  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bce9e7  jmp 0x00007FE746BCE77F
00007fe746bce9ec  ucomisd xmm1, xmm14
00007fe746bce9f1  jp 0x00007FE746BCEA00
00007fe746bce9f3  movaps xmm13, [0x00007FE7467FE030]
00007fe746bce9fb  jmp 0x00007FE746BCE7AC
00007fe746bcea00  vxorps xmm0, xmm1, xmm14
00007fe746bcea05  pextrw eax, xmm0, 0x03
00007fe746bcea0a  and eax, 0x7FF8
00007fe746bcea0f  cmp eax, 0x08
00007fe746bcea12  jnz 0x00007FE746BCE7AC
00007fe746bcea18  movq rax, xmm14
00007fe746bcea1d  shl rax, 0x0D
00007fe746bcea21  jbe 0x00007FE746BCE7AC
00007fe746bcea27  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bcea2f  jmp 0x00007FE746BCE7AC
00007fe746bcea34  ucomisd xmm1, xmm14
00007fe746bcea39  jp 0x00007FE746BCEA48
00007fe746bcea3b  movaps xmm13, [0x00007FE7467FE030]
00007fe746bcea43  jmp 0x00007FE746BCE7D9
00007fe746bcea48  vxorps xmm0, xmm1, xmm14
00007fe746bcea4d  pextrw eax, xmm0, 0x03
00007fe746bcea52  and eax, 0x7FF8
00007fe746bcea57  cmp eax, 0x08
00007fe746bcea5a  jnz 0x00007FE746BCE7D9
00007fe746bcea60  movq rax, xmm14
00007fe746bcea65  shl rax, 0x0D
00007fe746bcea69  jbe 0x00007FE746BCE7D9
00007fe746bcea6f  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bcea77  jmp 0x00007FE746BCE7D9
00007fe746bcea7c  ucomisd xmm1, xmm14
00007fe746bcea81  jp 0x00007FE746BCEA90
00007fe746bcea83  movaps xmm13, [0x00007FE7467FE030]
00007fe746bcea8b  jmp 0x00007FE746BCE806
00007fe746bcea90  vxorps xmm0, xmm1, xmm14
00007fe746bcea95  pextrw eax, xmm0, 0x03
00007fe746bcea9a  and eax, 0x7FF8
00007fe746bcea9f  cmp eax, 0x08
00007fe746bceaa2  jnz 0x00007FE746BCE806
00007fe746bceaa8  movq rax, xmm14
00007fe746bceaad  shl rax, 0x0D
00007fe746bceab1  jbe 0x00007FE746BCE806
00007fe746bceab7  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bceabf  jmp 0x00007FE746BCE806
00007fe746bceac4  ucomisd xmm1, xmm15
00007fe746bceac9  jp 0x00007FE746BCEAD8
00007fe746bceacb  movaps xmm14, [0x00007FE7467FE030]
00007fe746bcead3  jmp 0x00007FE746BCE833
00007fe746bcead8  vxorps xmm0, xmm1, xmm15
00007fe746bceadd  pextrw eax, xmm0, 0x03
00007fe746bceae2  and eax, 0x7FF8
00007fe746bceae7  cmp eax, 0x08
00007fe746bceaea  jnz 0x00007FE746BCE833
00007fe746bceaf0  movq rax, xmm15
00007fe746bceaf5  shl rax, 0x0D
00007fe746bceaf9  jbe 0x00007FE746BCE833
00007fe746bceaff  vorps xmm14, xmm15, [0x00007FE7467FE040]
00007fe746bceb07  jmp 0x00007FE746BCE833
00007fe746bceb0c  int3
00007fe746bceb0d  nop [rax], eax
00007fe746bceb10  movaps xmm1, [r15+0x110]
00007fe746bceb18  movq rax, xmm1
00007fe746bceb1d  movaps xmm1, [r15+0x120]
00007fe746bceb25  movq r14, xmm1
00007fe746bceb2a  vmovq xmm15, rax
00007fe746bceb2f  vmovq xmm14, r14
00007fe746bceb34  movaps xmm13, xmm15
00007fe746bceb38  addsd xmm13, xmm14
00007fe746bceb3d  ucomisd xmm13, xmm13
00007fe746bceb42  jp 0x00007FE746BCED24
00007fe746bceb48  movq xmm13, xmm13
00007fe746bceb4d  movq rax, xmm13
00007fe746bceb52  movq r14, xmm1
00007fe746bceb57  vmovq xmm15, rax
00007fe746bceb5c  vmovq xmm14, r14
00007fe746bceb61  movaps xmm13, xmm15
00007fe746bceb65  addsd xmm13, xmm14
00007fe746bceb6a  ucomisd xmm13, xmm13
00007fe746bceb6f  jp 0x00007FE746BCED6C
00007fe746bceb75  movq xmm13, xmm13
00007fe746bceb7a  movq rax, xmm13
00007fe746bceb7f  movq r14, xmm1
00007fe746bceb84  vmovq xmm15, rax
00007fe746bceb89  vmovq xmm14, r14
00007fe746bceb8e  movaps xmm13, xmm15
00007fe746bceb92  addsd xmm13, xmm14
00007fe746bceb97  ucomisd xmm13, xmm13
00007fe746bceb9c  jp 0x00007FE746BCEDB4
00007fe746bceba2  movq xmm13, xmm13
00007fe746bceba7  movq rax, xmm13
00007fe746bcebac  movq r14, xmm1
00007fe746bcebb1  vmovq xmm15, rax
00007fe746bcebb6  vmovq xmm14, r14
00007fe746bcebbb  movaps xmm13, xmm15
00007fe746bcebbf  addsd xmm13, xmm14
00007fe746bcebc4  ucomisd xmm13, xmm13
00007fe746bcebc9  jp 0x00007FE746BCEDFC
00007fe746bcebcf  movq xmm13, xmm13
00007fe746bcebd4  movq rax, xmm13
00007fe746bcebd9  movq r14, xmm1
00007fe746bcebde  vmovq xmm15, rax
00007fe746bcebe3  vmovq xmm14, r14
00007fe746bcebe8  movaps xmm13, xmm15
00007fe746bcebec  addsd xmm13, xmm14
00007fe746bcebf1  ucomisd xmm13, xmm13
00007fe746bcebf6  jp 0x00007FE746BCEE44
00007fe746bcebfc  movq xmm13, xmm13
00007fe746bcec01  movq rax, xmm13
00007fe746bcec06  movq r14, xmm1
00007fe746bcec0b  vmovq xmm15, rax
00007fe746bcec10  vmovq xmm14, r14
00007fe746bcec15  movaps xmm13, xmm15
00007fe746bcec19  addsd xmm13, xmm14
00007fe746bcec1e  ucomisd xmm13, xmm13
00007fe746bcec23  jp 0x00007FE746BCEE8C
00007fe746bcec29  movq xmm13, xmm13
00007fe746bcec2e  movq rax, xmm13
00007fe746bcec33  movq r14, xmm1
00007fe746bcec38  vmovq xmm15, rax
00007fe746bcec3d  vmovq xmm14, r14
00007fe746bcec42  movaps xmm13, xmm15
00007fe746bcec46  addsd xmm13, xmm14
00007fe746bcec4b  ucomisd xmm13, xmm13
00007fe746bcec50  jp 0x00007FE746BCEED4
00007fe746bcec56  movq xmm13, xmm13
00007fe746bcec5b  movq rax, xmm13
00007fe746bcec60  movq r14, xmm1
00007fe746bcec65  vmovq xmm1, rax
00007fe746bcec6a  vmovq xmm15, r14
00007fe746bcec6f  movaps xmm14, xmm1
00007fe746bcec73  addsd xmm14, xmm15
00007fe746bcec78  ucomisd xmm14, xmm14
00007fe746bcec7d  jp 0x00007FE746BCEF1C
00007fe746bcec83  movq xmm14, xmm14
00007fe746bcec88  movaps [r15+0x110], xmm14
00007fe746bcec90  mov rax, [r15+0x08]
00007fe746bcec94  mov [rsp+0x10], rax
00007fe746bcec99  xor eax, eax
00007fe746bcec9b  mov r14, [rsp+0x10]
00007fe746bceca0  mov r12d, 0x01
00007fe746bceca6  sub r14, r12
00007fe746bceca9  cmc
00007fe746bcecaa  lahf
00007fe746bcecab  seto al
00007fe746bcecae  mov [r15+0x108], eax
00007fe746bcecb5  mov [r15+0x08], r14
00007fe746bcecb9  mov eax, [r15+0x108]
00007fe746bcecc0  sahf
00007fe746bcecc1  jnz 0x00007FE746BCECF3
00007fe746bcecc3  cmp dword ptr [r15+0x318], 0x00
00007fe746bceccb  jz 0x00007FE746BCEF70
00007fe746bcecd1  nop [rax+rax*1], ax
00007fe746bcecda  nop [rax+rax*1], eax
00007fe746bcece2  mov eax, 0x41006C
00007fe746bcece7  mov [r15+0x100], rax
00007fe746bcecee  jmp 0x00007FE7469FE110
00007fe746bcecf3  cmp dword ptr [r15+0x318], 0x00
00007fe746bcecfb  jz 0x00007FE746BCEB10
00007fe746bced01  nop [rax+rax*1], ax
00007fe746bced0a  nop [rax+rax*1], eax
00007fe746bced12  mov eax, 0x410044
00007fe746bced17  mov [r15+0x100], rax
00007fe746bced1e  jmp 0x00007FE7469FE110
00007fe746bced23  int3
00007fe746bced24  ucomisd xmm15, xmm14
00007fe746bced29  jp 0x00007FE746BCED38
00007fe746bced2b  movaps xmm13, [0x00007FE7467FE030]
00007fe746bced33  jmp 0x00007FE746BCEB48
00007fe746bced38  vxorps xmm0, xmm15, xmm14
00007fe746bced3d  pextrw eax, xmm0, 0x03
00007fe746bced42  and eax, 0x7FF8
00007fe746bced47  cmp eax, 0x08
00007fe746bced4a  jnz 0x00007FE746BCEB48
00007fe746bced50  movq rax, xmm14
00007fe746bced55  shl rax, 0x0D
00007fe746bced59  jbe 0x00007FE746BCEB48
00007fe746bced5f  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bced67  jmp 0x00007FE746BCEB48
00007fe746bced6c  ucomisd xmm15, xmm14
00007fe746bced71  jp 0x00007FE746BCED80
00007fe746bced73  movaps xmm13, [0x00007FE7467FE030]
00007fe746bced7b  jmp 0x00007FE746BCEB75
00007fe746bced80  vxorps xmm0, xmm15, xmm14
00007fe746bced85  pextrw eax, xmm0, 0x03
00007fe746bced8a  and eax, 0x7FF8
00007fe746bced8f  cmp eax, 0x08
00007fe746bced92  jnz 0x00007FE746BCEB75
00007fe746bced98  movq rax, xmm14
00007fe746bced9d  shl rax, 0x0D
00007fe746bceda1  jbe 0x00007FE746BCEB75
00007fe746bceda7  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bcedaf  jmp 0x00007FE746BCEB75
00007fe746bcedb4  ucomisd xmm15, xmm14
00007fe746bcedb9  jp 0x00007FE746BCEDC8
00007fe746bcedbb  movaps xmm13, [0x00007FE7467FE030]
00007fe746bcedc3  jmp 0x00007FE746BCEBA2
00007fe746bcedc8  vxorps xmm0, xmm15, xmm14
00007fe746bcedcd  pextrw eax, xmm0, 0x03
00007fe746bcedd2  and eax, 0x7FF8
00007fe746bcedd7  cmp eax, 0x08
00007fe746bcedda  jnz 0x00007FE746BCEBA2
00007fe746bcede0  movq rax, xmm14
00007fe746bcede5  shl rax, 0x0D
00007fe746bcede9  jbe 0x00007FE746BCEBA2
00007fe746bcedef  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bcedf7  jmp 0x00007FE746BCEBA2
00007fe746bcedfc  ucomisd xmm15, xmm14
00007fe746bcee01  jp 0x00007FE746BCEE10
00007fe746bcee03  movaps xmm13, [0x00007FE7467FE030]
00007fe746bcee0b  jmp 0x00007FE746BCEBCF
00007fe746bcee10  vxorps xmm0, xmm15, xmm14
00007fe746bcee15  pextrw eax, xmm0, 0x03
00007fe746bcee1a  and eax, 0x7FF8
00007fe746bcee1f  cmp eax, 0x08
00007fe746bcee22  jnz 0x00007FE746BCEBCF
00007fe746bcee28  movq rax, xmm14
00007fe746bcee2d  shl rax, 0x0D
00007fe746bcee31  jbe 0x00007FE746BCEBCF
00007fe746bcee37  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bcee3f  jmp 0x00007FE746BCEBCF
00007fe746bcee44  ucomisd xmm15, xmm14
00007fe746bcee49  jp 0x00007FE746BCEE58
00007fe746bcee4b  movaps xmm13, [0x00007FE7467FE030]
00007fe746bcee53  jmp 0x00007FE746BCEBFC
00007fe746bcee58  vxorps xmm0, xmm15, xmm14
00007fe746bcee5d  pextrw eax, xmm0, 0x03
00007fe746bcee62  and eax, 0x7FF8
00007fe746bcee67  cmp eax, 0x08
00007fe746bcee6a  jnz 0x00007FE746BCEBFC
00007fe746bcee70  movq rax, xmm14
00007fe746bcee75  shl rax, 0x0D
00007fe746bcee79  jbe 0x00007FE746BCEBFC
00007fe746bcee7f  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bcee87  jmp 0x00007FE746BCEBFC
00007fe746bcee8c  ucomisd xmm15, xmm14
00007fe746bcee91  jp 0x00007FE746BCEEA0
00007fe746bcee93  movaps xmm13, [0x00007FE7467FE030]
00007fe746bcee9b  jmp 0x00007FE746BCEC29
00007fe746bceea0  vxorps xmm0, xmm15, xmm14
00007fe746bceea5  pextrw eax, xmm0, 0x03
00007fe746bceeaa  and eax, 0x7FF8
00007fe746bceeaf  cmp eax, 0x08
00007fe746bceeb2  jnz 0x00007FE746BCEC29
00007fe746bceeb8  movq rax, xmm14
00007fe746bceebd  shl rax, 0x0D
00007fe746bceec1  jbe 0x00007FE746BCEC29
00007fe746bceec7  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bceecf  jmp 0x00007FE746BCEC29
00007fe746bceed4  ucomisd xmm15, xmm14
00007fe746bceed9  jp 0x00007FE746BCEEE8
00007fe746bceedb  movaps xmm13, [0x00007FE7467FE030]
00007fe746bceee3  jmp 0x00007FE746BCEC56
00007fe746bceee8  vxorps xmm0, xmm15, xmm14
00007fe746bceeed  pextrw eax, xmm0, 0x03
00007fe746bceef2  and eax, 0x7FF8
00007fe746bceef7  cmp eax, 0x08
00007fe746bceefa  jnz 0x00007FE746BCEC56
00007fe746bcef00  movq rax, xmm14
00007fe746bcef05  shl rax, 0x0D
00007fe746bcef09  jbe 0x00007FE746BCEC56
00007fe746bcef0f  vorps xmm13, xmm14, [0x00007FE7467FE040]
00007fe746bcef17  jmp 0x00007FE746BCEC56
00007fe746bcef1c  ucomisd xmm1, xmm15
00007fe746bcef21  jp 0x00007FE746BCEF30
00007fe746bcef23  movaps xmm14, [0x00007FE7467FE030]
00007fe746bcef2b  jmp 0x00007FE746BCEC83
00007fe746bcef30  vxorps xmm0, xmm1, xmm15
00007fe746bcef35  pextrw eax, xmm0, 0x03
00007fe746bcef3a  and eax, 0x7FF8
00007fe746bcef3f  cmp eax, 0x08
00007fe746bcef42  jnz 0x00007FE746BCEC83
00007fe746bcef48  movq rax, xmm15
00007fe746bcef4d  shl rax, 0x0D
00007fe746bcef51  jbe 0x00007FE746BCEC83
00007fe746bcef57  vorps xmm14, xmm15, [0x00007FE7467FE040]
00007fe746bcef5f  jmp 0x00007FE746BCEC83
00007fe746bcef64  int3
00007fe746bcef65  nop [rax+rax*1], ax
00007fe746bcef6e  nop
00007fe746bcef70  mov rax, [r15+0x20]
00007fe746bcef74  movaps xmm1, [r15+0x110]
00007fe746bcef7c  movq r14, xmm1
00007fe746bcef81  mov [r13+rax*1], r14
00007fe746bcef86  mov rax, [r15+0xF0]
00007fe746bcef8d  mov [r15+0x100], rax
00007fe746bcef94  jmp 0x00007FE746BCE5C0
00007fe746bcef99  int3
00007fe746bcef9a  call 0x00007FE746A0E120
00007fe746bcef9f  jmp 0x00007FE746BCEF86
00007fe746bcefa4  int3
00007fe746bcefa5  nop [rax+rax*1], ax
00007fe746bcefae  nop
00007fe746bcefb0  mov qword ptr [r15+0x100], 0x04
00007fe746bcefbb  mov esi, 0x00
00007fe746bcefc0  mov edx, 0x09
00007fe746bcefc5  mov rdi, 0x7FFE40D3B520
00007fe746bcefcf  mov rax, 0x64DFC58AD970
00007fe746bcefd9  call rax
00007fe746bcefdb  cmp dword ptr [r15+0x318], 0x00
00007fe746bcefe3  jnz 0x00007FE7469FE110
00007fe746bcefe9  jmp 0x00007FE7469FE0A0
00007fe746bcefee  int3
00007fe746bcefef  int3
