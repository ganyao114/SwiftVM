
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/fp-u8/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x140
   7:	mov    r13d,0xe848
   d:	mov    QWORD PTR [r12+0x8],r13
  12:	mov    r13d,0xe848
  18:	mov    r14d,0x1
  1e:	and    r14d,0xffff
  25:	mov    rax,r13
  28:	movabs rcx,0xffffffff0000ffff
  32:	and    rax,rcx
  35:	mov    rdx,r14
  38:	shl    rdx,0x10
  3c:	mov    ecx,0xffff0000
  41:	and    rdx,rcx
  44:	or     rax,rdx
  47:	mov    r15,rax
  4a:	mov    QWORD PTR [r12+0x8],r15
  4f:	mov    r13d,0x420080
  55:	mov    QWORD PTR [r12+0x20],r13
  5a:	mov    r13d,0x0
  60:	mov    QWORD PTR [r12],r13
  64:	mov    r13d,0x0
  6a:	movabs r14,0x3ff0000000000000
  74:	mov    QWORD PTR [r12+0x110],r14
  7c:	mov    QWORD PTR [r12+0x118],r13
  84:	mov    r13d,0x0
  8a:	movabs r14,0x3ff8000000000000
  94:	mov    QWORD PTR [r12+0x120],r14
  9c:	mov    QWORD PTR [r12+0x128],r13
  a4:	jmp    0xa9
  a9:	movdqu xmm0,XMMWORD PTR [r12+0x110]
  b3:	movdqa xmm2,xmm0
  b7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
  c1:	movdqa xmm3,xmm0
  c5:	cmp    DWORD PTR [r12+0x310],0x0
  ce:	jne    0x168
  d4:	movdqa xmm0,xmm2
  d8:	movdqa xmm1,xmm3
  dc:	movq   rax,xmm0
  e1:	add    rax,rax
  e4:	je     0xfa
  e6:	shr    rax,0x35
  ea:	sub    eax,0x201
  ef:	cmp    eax,0x3fc
  f4:	ja     0x168
  fa:	movq   rax,xmm1
  ff:	add    rax,rax
 102:	je     0x118
 104:	shr    rax,0x35
 108:	sub    eax,0x201
 10d:	cmp    eax,0x3fc
 112:	ja     0x168
 118:	movq   xmm0,xmm0
 11c:	movq   xmm1,xmm1
 120:	stmxcsr DWORD PTR [rsp+0x100]
 128:	mov    DWORD PTR [rsp+0x104],0x1f80
 133:	ldmxcsr DWORD PTR [rsp+0x104]
 13b:	addsd  xmm0,xmm1
 13f:	stmxcsr DWORD PTR [rsp+0x104]
 147:	ldmxcsr DWORD PTR [rsp+0x100]
 14f:	mov    eax,DWORD PTR [rsp+0x104]
 156:	shr    eax,1
 158:	and    eax,0x10
 15b:	or     DWORD PTR [r12+0x314],eax
 163:	jmp    0x215
 168:	movdqa xmm0,xmm2
 16c:	movdqa xmm1,xmm3
 170:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
 179:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
 182:	mov    QWORD PTR [r12+0x378],0x3
 18e:	movdqu XMMWORD PTR [rsp],xmm2
 193:	movdqu XMMWORD PTR [rsp+0x10],xmm3
 199:	mov    QWORD PTR [r12+0x108],rbx
 1a1:	stmxcsr DWORD PTR [r12-0x28]
 1a7:	ldmxcsr DWORD PTR [r12-0x38]
 1ad:	lea    rdi,[rsp+0xf0]
 1b5:	lea    rsi,[rsp+0xd0]
 1bd:	lea    rdx,[rsp+0xe0]
 1c5:	mov    ecx,0xc
 1ca:	mov    r8d,DWORD PTR [r12+0x310]
 1d2:	lea    r9,[r12+0x314]
 1da:	movabs r11,0x5d7bac5c6750
 1e4:	call   r11
 1e7:	ldmxcsr DWORD PTR [r12-0x28]
 1ed:	movdqu xmm2,XMMWORD PTR [rsp]
 1f2:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
 1f8:	mov    rbx,QWORD PTR [r12+0x108]
 200:	mov    QWORD PTR [r12+0x378],0x2
 20c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
 215:	movdqa xmm4,xmm0
 219:	movdqa xmm0,xmm4
 21d:	movdqu XMMWORD PTR [r12+0x110],xmm0
 227:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 231:	movdqa xmm2,xmm0
 235:	cmp    DWORD PTR [r12+0x310],0x0
 23e:	jne    0x2d8
 244:	movdqa xmm0,xmm4
 248:	movdqa xmm1,xmm2
 24c:	movq   rax,xmm0
 251:	add    rax,rax
 254:	je     0x26a
 256:	shr    rax,0x35
 25a:	sub    eax,0x201
 25f:	cmp    eax,0x3fc
 264:	ja     0x2d8
 26a:	movq   rax,xmm1
 26f:	add    rax,rax
 272:	je     0x288
 274:	shr    rax,0x35
 278:	sub    eax,0x201
 27d:	cmp    eax,0x3fc
 282:	ja     0x2d8
 288:	movq   xmm0,xmm0
 28c:	movq   xmm1,xmm1
 290:	stmxcsr DWORD PTR [rsp+0x100]
 298:	mov    DWORD PTR [rsp+0x104],0x1f80
 2a3:	ldmxcsr DWORD PTR [rsp+0x104]
 2ab:	addsd  xmm0,xmm1
 2af:	stmxcsr DWORD PTR [rsp+0x104]
 2b7:	ldmxcsr DWORD PTR [rsp+0x100]
 2bf:	mov    eax,DWORD PTR [rsp+0x104]
 2c6:	shr    eax,1
 2c8:	and    eax,0x10
 2cb:	or     DWORD PTR [r12+0x314],eax
 2d3:	jmp    0x385
 2d8:	movdqa xmm0,xmm4
 2dc:	movdqa xmm1,xmm2
 2e0:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
 2e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
 2f2:	mov    QWORD PTR [r12+0x378],0x3
 2fe:	movdqu XMMWORD PTR [rsp],xmm2
 303:	movdqu XMMWORD PTR [rsp+0x20],xmm4
 309:	mov    QWORD PTR [r12+0x108],rbx
 311:	stmxcsr DWORD PTR [r12-0x28]
 317:	ldmxcsr DWORD PTR [r12-0x38]
 31d:	lea    rdi,[rsp+0xf0]
 325:	lea    rsi,[rsp+0xd0]
 32d:	lea    rdx,[rsp+0xe0]
 335:	mov    ecx,0xc
 33a:	mov    r8d,DWORD PTR [r12+0x310]
 342:	lea    r9,[r12+0x314]
 34a:	movabs r11,0x5d7bac5c6750
 354:	call   r11
 357:	ldmxcsr DWORD PTR [r12-0x28]
 35d:	movdqu xmm2,XMMWORD PTR [rsp]
 362:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
 368:	mov    rbx,QWORD PTR [r12+0x108]
 370:	mov    QWORD PTR [r12+0x378],0x2
 37c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
 385:	movdqa xmm3,xmm0
 389:	movdqa xmm0,xmm3
 38d:	movdqu XMMWORD PTR [r12+0x110],xmm0
 397:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 3a1:	movdqa xmm2,xmm0
 3a5:	cmp    DWORD PTR [r12+0x310],0x0
 3ae:	jne    0x448
 3b4:	movdqa xmm0,xmm3
 3b8:	movdqa xmm1,xmm2
 3bc:	movq   rax,xmm0
 3c1:	add    rax,rax
 3c4:	je     0x3da
 3c6:	shr    rax,0x35
 3ca:	sub    eax,0x201
 3cf:	cmp    eax,0x3fc
 3d4:	ja     0x448
 3da:	movq   rax,xmm1
 3df:	add    rax,rax
 3e2:	je     0x3f8
 3e4:	shr    rax,0x35
 3e8:	sub    eax,0x201
 3ed:	cmp    eax,0x3fc
 3f2:	ja     0x448
 3f8:	movq   xmm0,xmm0
 3fc:	movq   xmm1,xmm1
 400:	stmxcsr DWORD PTR [rsp+0x100]
 408:	mov    DWORD PTR [rsp+0x104],0x1f80
 413:	ldmxcsr DWORD PTR [rsp+0x104]
 41b:	addsd  xmm0,xmm1
 41f:	stmxcsr DWORD PTR [rsp+0x104]
 427:	ldmxcsr DWORD PTR [rsp+0x100]
 42f:	mov    eax,DWORD PTR [rsp+0x104]
 436:	shr    eax,1
 438:	and    eax,0x10
 43b:	or     DWORD PTR [r12+0x314],eax
 443:	jmp    0x4f5
 448:	movdqa xmm0,xmm3
 44c:	movdqa xmm1,xmm2
 450:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
 459:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
 462:	mov    QWORD PTR [r12+0x378],0x3
 46e:	movdqu XMMWORD PTR [rsp],xmm2
 473:	movdqu XMMWORD PTR [rsp+0x10],xmm3
 479:	mov    QWORD PTR [r12+0x108],rbx
 481:	stmxcsr DWORD PTR [r12-0x28]
 487:	ldmxcsr DWORD PTR [r12-0x38]
 48d:	lea    rdi,[rsp+0xf0]
 495:	lea    rsi,[rsp+0xd0]
 49d:	lea    rdx,[rsp+0xe0]
 4a5:	mov    ecx,0xc
 4aa:	mov    r8d,DWORD PTR [r12+0x310]
 4b2:	lea    r9,[r12+0x314]
 4ba:	movabs r11,0x5d7bac5c6750
 4c4:	call   r11
 4c7:	ldmxcsr DWORD PTR [r12-0x28]
 4cd:	movdqu xmm2,XMMWORD PTR [rsp]
 4d2:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
 4d8:	mov    rbx,QWORD PTR [r12+0x108]
 4e0:	mov    QWORD PTR [r12+0x378],0x2
 4ec:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
 4f5:	movdqa xmm4,xmm0
 4f9:	movdqa xmm0,xmm4
 4fd:	movdqu XMMWORD PTR [r12+0x110],xmm0
 507:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 511:	movdqa xmm2,xmm0
 515:	cmp    DWORD PTR [r12+0x310],0x0
 51e:	jne    0x5b8
 524:	movdqa xmm0,xmm4
 528:	movdqa xmm1,xmm2
 52c:	movq   rax,xmm0
 531:	add    rax,rax
 534:	je     0x54a
 536:	shr    rax,0x35
 53a:	sub    eax,0x201
 53f:	cmp    eax,0x3fc
 544:	ja     0x5b8
 54a:	movq   rax,xmm1
 54f:	add    rax,rax
 552:	je     0x568
 554:	shr    rax,0x35
 558:	sub    eax,0x201
 55d:	cmp    eax,0x3fc
 562:	ja     0x5b8
 568:	movq   xmm0,xmm0
 56c:	movq   xmm1,xmm1
 570:	stmxcsr DWORD PTR [rsp+0x100]
 578:	mov    DWORD PTR [rsp+0x104],0x1f80
 583:	ldmxcsr DWORD PTR [rsp+0x104]
 58b:	addsd  xmm0,xmm1
 58f:	stmxcsr DWORD PTR [rsp+0x104]
 597:	ldmxcsr DWORD PTR [rsp+0x100]
 59f:	mov    eax,DWORD PTR [rsp+0x104]
 5a6:	shr    eax,1
 5a8:	and    eax,0x10
 5ab:	or     DWORD PTR [r12+0x314],eax
 5b3:	jmp    0x665
 5b8:	movdqa xmm0,xmm4
 5bc:	movdqa xmm1,xmm2
 5c0:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
 5c9:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
 5d2:	mov    QWORD PTR [r12+0x378],0x3
 5de:	movdqu XMMWORD PTR [rsp],xmm2
 5e3:	movdqu XMMWORD PTR [rsp+0x20],xmm4
 5e9:	mov    QWORD PTR [r12+0x108],rbx
 5f1:	stmxcsr DWORD PTR [r12-0x28]
 5f7:	ldmxcsr DWORD PTR [r12-0x38]
 5fd:	lea    rdi,[rsp+0xf0]
 605:	lea    rsi,[rsp+0xd0]
 60d:	lea    rdx,[rsp+0xe0]
 615:	mov    ecx,0xc
 61a:	mov    r8d,DWORD PTR [r12+0x310]
 622:	lea    r9,[r12+0x314]
 62a:	movabs r11,0x5d7bac5c6750
 634:	call   r11
 637:	ldmxcsr DWORD PTR [r12-0x28]
 63d:	movdqu xmm2,XMMWORD PTR [rsp]
 642:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
 648:	mov    rbx,QWORD PTR [r12+0x108]
 650:	mov    QWORD PTR [r12+0x378],0x2
 65c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
 665:	movdqa xmm3,xmm0
 669:	movdqa xmm0,xmm3
 66d:	movdqu XMMWORD PTR [r12+0x110],xmm0
 677:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 681:	movdqa xmm2,xmm0
 685:	cmp    DWORD PTR [r12+0x310],0x0
 68e:	jne    0x728
 694:	movdqa xmm0,xmm3
 698:	movdqa xmm1,xmm2
 69c:	movq   rax,xmm0
 6a1:	add    rax,rax
 6a4:	je     0x6ba
 6a6:	shr    rax,0x35
 6aa:	sub    eax,0x201
 6af:	cmp    eax,0x3fc
 6b4:	ja     0x728
 6ba:	movq   rax,xmm1
 6bf:	add    rax,rax
 6c2:	je     0x6d8
 6c4:	shr    rax,0x35
 6c8:	sub    eax,0x201
 6cd:	cmp    eax,0x3fc
 6d2:	ja     0x728
 6d8:	movq   xmm0,xmm0
 6dc:	movq   xmm1,xmm1
 6e0:	stmxcsr DWORD PTR [rsp+0x100]
 6e8:	mov    DWORD PTR [rsp+0x104],0x1f80
 6f3:	ldmxcsr DWORD PTR [rsp+0x104]
 6fb:	addsd  xmm0,xmm1
 6ff:	stmxcsr DWORD PTR [rsp+0x104]
 707:	ldmxcsr DWORD PTR [rsp+0x100]
 70f:	mov    eax,DWORD PTR [rsp+0x104]
 716:	shr    eax,1
 718:	and    eax,0x10
 71b:	or     DWORD PTR [r12+0x314],eax
 723:	jmp    0x7d5
 728:	movdqa xmm0,xmm3
 72c:	movdqa xmm1,xmm2
 730:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
 739:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
 742:	mov    QWORD PTR [r12+0x378],0x3
 74e:	movdqu XMMWORD PTR [rsp],xmm2
 753:	movdqu XMMWORD PTR [rsp+0x10],xmm3
 759:	mov    QWORD PTR [r12+0x108],rbx
 761:	stmxcsr DWORD PTR [r12-0x28]
 767:	ldmxcsr DWORD PTR [r12-0x38]
 76d:	lea    rdi,[rsp+0xf0]
 775:	lea    rsi,[rsp+0xd0]
 77d:	lea    rdx,[rsp+0xe0]
 785:	mov    ecx,0xc
 78a:	mov    r8d,DWORD PTR [r12+0x310]
 792:	lea    r9,[r12+0x314]
 79a:	movabs r11,0x5d7bac5c6750
 7a4:	call   r11
 7a7:	ldmxcsr DWORD PTR [r12-0x28]
 7ad:	movdqu xmm2,XMMWORD PTR [rsp]
 7b2:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
 7b8:	mov    rbx,QWORD PTR [r12+0x108]
 7c0:	mov    QWORD PTR [r12+0x378],0x2
 7cc:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
 7d5:	movdqa xmm4,xmm0
 7d9:	movdqa xmm0,xmm4
 7dd:	movdqu XMMWORD PTR [r12+0x110],xmm0
 7e7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 7f1:	movdqa xmm2,xmm0
 7f5:	cmp    DWORD PTR [r12+0x310],0x0
 7fe:	jne    0x898
 804:	movdqa xmm0,xmm4
 808:	movdqa xmm1,xmm2
 80c:	movq   rax,xmm0
 811:	add    rax,rax
 814:	je     0x82a
 816:	shr    rax,0x35
 81a:	sub    eax,0x201
 81f:	cmp    eax,0x3fc
 824:	ja     0x898
 82a:	movq   rax,xmm1
 82f:	add    rax,rax
 832:	je     0x848
 834:	shr    rax,0x35
 838:	sub    eax,0x201
 83d:	cmp    eax,0x3fc
 842:	ja     0x898
 848:	movq   xmm0,xmm0
 84c:	movq   xmm1,xmm1
 850:	stmxcsr DWORD PTR [rsp+0x100]
 858:	mov    DWORD PTR [rsp+0x104],0x1f80
 863:	ldmxcsr DWORD PTR [rsp+0x104]
 86b:	addsd  xmm0,xmm1
 86f:	stmxcsr DWORD PTR [rsp+0x104]
 877:	ldmxcsr DWORD PTR [rsp+0x100]
 87f:	mov    eax,DWORD PTR [rsp+0x104]
 886:	shr    eax,1
 888:	and    eax,0x10
 88b:	or     DWORD PTR [r12+0x314],eax
 893:	jmp    0x945
 898:	movdqa xmm0,xmm4
 89c:	movdqa xmm1,xmm2
 8a0:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
 8a9:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
 8b2:	mov    QWORD PTR [r12+0x378],0x3
 8be:	movdqu XMMWORD PTR [rsp],xmm2
 8c3:	movdqu XMMWORD PTR [rsp+0x20],xmm4
 8c9:	mov    QWORD PTR [r12+0x108],rbx
 8d1:	stmxcsr DWORD PTR [r12-0x28]
 8d7:	ldmxcsr DWORD PTR [r12-0x38]
 8dd:	lea    rdi,[rsp+0xf0]
 8e5:	lea    rsi,[rsp+0xd0]
 8ed:	lea    rdx,[rsp+0xe0]
 8f5:	mov    ecx,0xc
 8fa:	mov    r8d,DWORD PTR [r12+0x310]
 902:	lea    r9,[r12+0x314]
 90a:	movabs r11,0x5d7bac5c6750
 914:	call   r11
 917:	ldmxcsr DWORD PTR [r12-0x28]
 91d:	movdqu xmm2,XMMWORD PTR [rsp]
 922:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
 928:	mov    rbx,QWORD PTR [r12+0x108]
 930:	mov    QWORD PTR [r12+0x378],0x2
 93c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
 945:	movdqa xmm3,xmm0
 949:	movdqa xmm0,xmm3
 94d:	movdqu XMMWORD PTR [r12+0x110],xmm0
 957:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 961:	movdqa xmm2,xmm0
 965:	cmp    DWORD PTR [r12+0x310],0x0
 96e:	jne    0xa08
 974:	movdqa xmm0,xmm3
 978:	movdqa xmm1,xmm2
 97c:	movq   rax,xmm0
 981:	add    rax,rax
 984:	je     0x99a
 986:	shr    rax,0x35
 98a:	sub    eax,0x201
 98f:	cmp    eax,0x3fc
 994:	ja     0xa08
 99a:	movq   rax,xmm1
 99f:	add    rax,rax
 9a2:	je     0x9b8
 9a4:	shr    rax,0x35
 9a8:	sub    eax,0x201
 9ad:	cmp    eax,0x3fc
 9b2:	ja     0xa08
 9b8:	movq   xmm0,xmm0
 9bc:	movq   xmm1,xmm1
 9c0:	stmxcsr DWORD PTR [rsp+0x100]
 9c8:	mov    DWORD PTR [rsp+0x104],0x1f80
 9d3:	ldmxcsr DWORD PTR [rsp+0x104]
 9db:	addsd  xmm0,xmm1
 9df:	stmxcsr DWORD PTR [rsp+0x104]
 9e7:	ldmxcsr DWORD PTR [rsp+0x100]
 9ef:	mov    eax,DWORD PTR [rsp+0x104]
 9f6:	shr    eax,1
 9f8:	and    eax,0x10
 9fb:	or     DWORD PTR [r12+0x314],eax
 a03:	jmp    0xab5
 a08:	movdqa xmm0,xmm3
 a0c:	movdqa xmm1,xmm2
 a10:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
 a19:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
 a22:	mov    QWORD PTR [r12+0x378],0x3
 a2e:	movdqu XMMWORD PTR [rsp],xmm2
 a33:	movdqu XMMWORD PTR [rsp+0x10],xmm3
 a39:	mov    QWORD PTR [r12+0x108],rbx
 a41:	stmxcsr DWORD PTR [r12-0x28]
 a47:	ldmxcsr DWORD PTR [r12-0x38]
 a4d:	lea    rdi,[rsp+0xf0]
 a55:	lea    rsi,[rsp+0xd0]
 a5d:	lea    rdx,[rsp+0xe0]
 a65:	mov    ecx,0xc
 a6a:	mov    r8d,DWORD PTR [r12+0x310]
 a72:	lea    r9,[r12+0x314]
 a7a:	movabs r11,0x5d7bac5c6750
 a84:	call   r11
 a87:	ldmxcsr DWORD PTR [r12-0x28]
 a8d:	movdqu xmm2,XMMWORD PTR [rsp]
 a92:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
 a98:	mov    rbx,QWORD PTR [r12+0x108]
 aa0:	mov    QWORD PTR [r12+0x378],0x2
 aac:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
 ab5:	movdqa xmm4,xmm0
 ab9:	movdqa xmm0,xmm4
 abd:	movdqu XMMWORD PTR [r12+0x110],xmm0
 ac7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 ad1:	movdqa xmm2,xmm0
 ad5:	cmp    DWORD PTR [r12+0x310],0x0
 ade:	jne    0xb78
 ae4:	movdqa xmm0,xmm4
 ae8:	movdqa xmm1,xmm2
 aec:	movq   rax,xmm0
 af1:	add    rax,rax
 af4:	je     0xb0a
 af6:	shr    rax,0x35
 afa:	sub    eax,0x201
 aff:	cmp    eax,0x3fc
 b04:	ja     0xb78
 b0a:	movq   rax,xmm1
 b0f:	add    rax,rax
 b12:	je     0xb28
 b14:	shr    rax,0x35
 b18:	sub    eax,0x201
 b1d:	cmp    eax,0x3fc
 b22:	ja     0xb78
 b28:	movq   xmm0,xmm0
 b2c:	movq   xmm1,xmm1
 b30:	stmxcsr DWORD PTR [rsp+0x100]
 b38:	mov    DWORD PTR [rsp+0x104],0x1f80
 b43:	ldmxcsr DWORD PTR [rsp+0x104]
 b4b:	addsd  xmm0,xmm1
 b4f:	stmxcsr DWORD PTR [rsp+0x104]
 b57:	ldmxcsr DWORD PTR [rsp+0x100]
 b5f:	mov    eax,DWORD PTR [rsp+0x104]
 b66:	shr    eax,1
 b68:	and    eax,0x10
 b6b:	or     DWORD PTR [r12+0x314],eax
 b73:	jmp    0xc25
 b78:	movdqa xmm0,xmm4
 b7c:	movdqa xmm1,xmm2
 b80:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
 b89:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
 b92:	mov    QWORD PTR [r12+0x378],0x3
 b9e:	movdqu XMMWORD PTR [rsp],xmm2
 ba3:	movdqu XMMWORD PTR [rsp+0x20],xmm4
 ba9:	mov    QWORD PTR [r12+0x108],rbx
 bb1:	stmxcsr DWORD PTR [r12-0x28]
 bb7:	ldmxcsr DWORD PTR [r12-0x38]
 bbd:	lea    rdi,[rsp+0xf0]
 bc5:	lea    rsi,[rsp+0xd0]
 bcd:	lea    rdx,[rsp+0xe0]
 bd5:	mov    ecx,0xc
 bda:	mov    r8d,DWORD PTR [r12+0x310]
 be2:	lea    r9,[r12+0x314]
 bea:	movabs r11,0x5d7bac5c6750
 bf4:	call   r11
 bf7:	ldmxcsr DWORD PTR [r12-0x28]
 bfd:	movdqu xmm2,XMMWORD PTR [rsp]
 c02:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
 c08:	mov    rbx,QWORD PTR [r12+0x108]
 c10:	mov    QWORD PTR [r12+0x378],0x2
 c1c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
 c25:	movdqa xmm3,xmm0
 c29:	movdqa xmm0,xmm3
 c2d:	movdqu XMMWORD PTR [r12+0x110],xmm0
 c37:	mov    r13,QWORD PTR [r12+0x8]
 c3c:	mov    r14,r13
 c3f:	sub    r14,0x1
 c43:	pushf
 c44:	pop    rdx
 c45:	mov    r10d,edx
 c48:	and    r10d,0xc0
 c4f:	shl    r10d,0x18
 c53:	mov    r11d,edx
 c56:	and    r11d,0x1
 c5a:	shl    r11d,0x1d
 c5e:	or     r10d,r11d
 c61:	mov    r11d,edx
 c64:	and    r11d,0x800
 c6b:	shl    r11d,0x11
 c6f:	or     r10d,r11d
 c72:	mov    r11d,0xf0000000
 c78:	and    r11,r10
 c7b:	movabs rsi,0xffffffff0fffffff
 c85:	and    rbx,rsi
 c88:	or     rbx,r11
 c8b:	btc    rbx,0x1d
 c90:	mov    QWORD PTR [r12+0x8],r14
 c95:	cmp    QWORD PTR [r12+0x380],0x0
 c9e:	je     0xcd2
 ca4:	mov    eax,0x410068
 ca9:	mov    QWORD PTR [r12+0x100],rax
 cb1:	mov    QWORD PTR [r12+0x108],rbx
 cb9:	add    rsp,0x140
 cc0:	mov    eax,0xc
 cc5:	movabs r11,0x5d7bac75a5f0
 ccf:	jmp    r11
 cd2:	test   ebx,0x40000000
 cd8:	je     0xa9
 cde:	jmp    0xce3
 ce3:	mov    r13,QWORD PTR [r12+0x20]
 ce8:	mov    r14,QWORD PTR [r12+0x110]
 cf0:	mov    QWORD PTR [r13+0x0],r14
 cf4:	mov    r13d,0x0
 cfa:	mov    DWORD PTR [r12+0x32c],r13d
 d02:	cmp    QWORD PTR [r12+0x380],0x0
 d0b:	je     0xd3f
 d11:	mov    eax,0x410070
 d16:	mov    QWORD PTR [r12+0x100],rax
 d1e:	mov    QWORD PTR [r12+0x108],rbx
 d26:	add    rsp,0x140
 d2d:	mov    eax,0xc
 d32:	movabs r11,0x5d7bac75a5f0
 d3c:	jmp    r11
 d3f:	mov    r13,QWORD PTR [r12+0xf0]
 d47:	mov    QWORD PTR [r12+0x100],r13
 d4f:	mov    QWORD PTR [r12+0x108],rbx
 d57:	mov    rdi,QWORD PTR [r12+0x100]
 d5f:	add    rsp,0x140
 d66:	movabs r11,0x5d7bac75a370
 d70:	jmp    r11
 d73:	data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 d80:	sub    rsp,0x140
 d87:	jmp    0xa9
 d8c:	nop    DWORD PTR [rax+0x0]
 d90:	sub    rsp,0x140
 d97:	jmp    0xce3
