000071bd06dce69b  nop [rax+rax*1], eax
000071bd06dce6a0  mov qword ptr [r15+0x20], 0x420080
000071bd06dce6a8  mov qword ptr [r15], 0x00
000071bd06dce6af  vmovaps xmm1, [0x000071BD069FE010]
000071bd06dce6b7  movq xmm1, xmm1
000071bd06dce6bb  vmovaps xmm15, [0x000071BD069FE020]
000071bd06dce6c3  movq xmm15, xmm15
000071bd06dce6c8  movaps [r15+0x120], xmm15
000071bd06dce6d0  movq rax, xmm1
000071bd06dce6d5  movq r14, xmm15
000071bd06dce6da  vmovq xmm1, rax
000071bd06dce6df  vmovq xmm14, r14
000071bd06dce6e4  movaps xmm13, xmm1
000071bd06dce6e8  addsd xmm13, xmm14
000071bd06dce6ed  ucomisd xmm13, xmm13
000071bd06dce6f2  jp 0x000071BD06DCE8CC
000071bd06dce6f8  movq xmm13, xmm13
000071bd06dce6fd  movq rax, xmm13
000071bd06dce702  movq r14, xmm15
000071bd06dce707  vmovq xmm1, rax
000071bd06dce70c  vmovq xmm14, r14
000071bd06dce711  movaps xmm13, xmm1
000071bd06dce715  addsd xmm13, xmm14
000071bd06dce71a  ucomisd xmm13, xmm13
000071bd06dce71f  jp 0x000071BD06DCE914
000071bd06dce725  movq xmm13, xmm13
000071bd06dce72a  movq rax, xmm13
000071bd06dce72f  movq r14, xmm15
000071bd06dce734  vmovq xmm1, rax
000071bd06dce739  vmovq xmm14, r14
000071bd06dce73e  movaps xmm13, xmm1
000071bd06dce742  addsd xmm13, xmm14
000071bd06dce747  ucomisd xmm13, xmm13
000071bd06dce74c  jp 0x000071BD06DCE95C
000071bd06dce752  movq xmm13, xmm13
000071bd06dce757  movq rax, xmm13
000071bd06dce75c  movq r14, xmm15
000071bd06dce761  vmovq xmm1, rax
000071bd06dce766  vmovq xmm14, r14
000071bd06dce76b  movaps xmm13, xmm1
000071bd06dce76f  addsd xmm13, xmm14
000071bd06dce774  ucomisd xmm13, xmm13
000071bd06dce779  jp 0x000071BD06DCE9A4
000071bd06dce77f  movq xmm13, xmm13
000071bd06dce784  movq rax, xmm13
000071bd06dce789  movq r14, xmm15
000071bd06dce78e  vmovq xmm1, rax
000071bd06dce793  vmovq xmm14, r14
000071bd06dce798  movaps xmm13, xmm1
000071bd06dce79c  addsd xmm13, xmm14
000071bd06dce7a1  ucomisd xmm13, xmm13
000071bd06dce7a6  jp 0x000071BD06DCE9EC
000071bd06dce7ac  movq xmm13, xmm13
000071bd06dce7b1  movq rax, xmm13
000071bd06dce7b6  movq r14, xmm15
000071bd06dce7bb  vmovq xmm1, rax
000071bd06dce7c0  vmovq xmm14, r14
000071bd06dce7c5  movaps xmm13, xmm1
000071bd06dce7c9  addsd xmm13, xmm14
000071bd06dce7ce  ucomisd xmm13, xmm13
000071bd06dce7d3  jp 0x000071BD06DCEA34
000071bd06dce7d9  movq xmm13, xmm13
000071bd06dce7de  movq rax, xmm13
000071bd06dce7e3  movq r14, xmm15
000071bd06dce7e8  vmovq xmm1, rax
000071bd06dce7ed  vmovq xmm14, r14
000071bd06dce7f2  movaps xmm13, xmm1
000071bd06dce7f6  addsd xmm13, xmm14
000071bd06dce7fb  ucomisd xmm13, xmm13
000071bd06dce800  jp 0x000071BD06DCEA7C
000071bd06dce806  movq xmm13, xmm13
000071bd06dce80b  movq rax, xmm13
000071bd06dce810  movq r14, xmm15
000071bd06dce815  vmovq xmm1, rax
000071bd06dce81a  vmovq xmm15, r14
000071bd06dce81f  movaps xmm14, xmm1
000071bd06dce823  addsd xmm14, xmm15
000071bd06dce828  ucomisd xmm14, xmm14
000071bd06dce82d  jp 0x000071BD06DCEAC4
000071bd06dce833  movq xmm14, xmm14
000071bd06dce838  movaps [r15+0x110], xmm14
000071bd06dce840  xor eax, eax
000071bd06dce842  mov r14d, 0x1E848
000071bd06dce848  mov r12d, 0x01
000071bd06dce84e  sub r14, r12
000071bd06dce851  cmc
000071bd06dce852  lahf
000071bd06dce853  seto al
000071bd06dce856  mov [r15+0x108], eax
000071bd06dce85d  mov [r15+0x08], r14
000071bd06dce861  mov eax, [r15+0x108]
000071bd06dce868  sahf
000071bd06dce869  jnz 0x000071BD06DCE89B
000071bd06dce86b  cmp dword ptr [r15+0x318], 0x00
000071bd06dce873  jz 0x000071BD06DCEF70
000071bd06dce879  nop [rax+rax*1], ax
000071bd06dce882  nop [rax+rax*1], eax
000071bd06dce88a  mov eax, 0x41006C
000071bd06dce88f  mov [r15+0x100], rax
000071bd06dce896  jmp 0x000071BD06BFE110
000071bd06dce89b  cmp dword ptr [r15+0x318], 0x00
000071bd06dce8a3  jz 0x000071BD06DCEB10
000071bd06dce8a9  nop [rax+rax*1], ax
000071bd06dce8b2  nop [rax+rax*1], eax
000071bd06dce8ba  mov eax, 0x410044
000071bd06dce8bf  mov [r15+0x100], rax
000071bd06dce8c6  jmp 0x000071BD06BFE110
000071bd06dce8cb  int3
000071bd06dce8cc  ucomisd xmm1, xmm14
000071bd06dce8d1  jp 0x000071BD06DCE8E0
000071bd06dce8d3  movaps xmm13, [0x000071BD069FE030]
000071bd06dce8db  jmp 0x000071BD06DCE6F8
000071bd06dce8e0  vxorps xmm0, xmm1, xmm14
000071bd06dce8e5  pextrw eax, xmm0, 0x03
000071bd06dce8ea  and eax, 0x7FF8
000071bd06dce8ef  cmp eax, 0x08
000071bd06dce8f2  jnz 0x000071BD06DCE6F8
000071bd06dce8f8  movq rax, xmm14
000071bd06dce8fd  shl rax, 0x0D
000071bd06dce901  jbe 0x000071BD06DCE6F8
000071bd06dce907  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dce90f  jmp 0x000071BD06DCE6F8
000071bd06dce914  ucomisd xmm1, xmm14
000071bd06dce919  jp 0x000071BD06DCE928
000071bd06dce91b  movaps xmm13, [0x000071BD069FE030]
000071bd06dce923  jmp 0x000071BD06DCE725
000071bd06dce928  vxorps xmm0, xmm1, xmm14
000071bd06dce92d  pextrw eax, xmm0, 0x03
000071bd06dce932  and eax, 0x7FF8
000071bd06dce937  cmp eax, 0x08
000071bd06dce93a  jnz 0x000071BD06DCE725
000071bd06dce940  movq rax, xmm14
000071bd06dce945  shl rax, 0x0D
000071bd06dce949  jbe 0x000071BD06DCE725
000071bd06dce94f  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dce957  jmp 0x000071BD06DCE725
000071bd06dce95c  ucomisd xmm1, xmm14
000071bd06dce961  jp 0x000071BD06DCE970
000071bd06dce963  movaps xmm13, [0x000071BD069FE030]
000071bd06dce96b  jmp 0x000071BD06DCE752
000071bd06dce970  vxorps xmm0, xmm1, xmm14
000071bd06dce975  pextrw eax, xmm0, 0x03
000071bd06dce97a  and eax, 0x7FF8
000071bd06dce97f  cmp eax, 0x08
000071bd06dce982  jnz 0x000071BD06DCE752
000071bd06dce988  movq rax, xmm14
000071bd06dce98d  shl rax, 0x0D
000071bd06dce991  jbe 0x000071BD06DCE752
000071bd06dce997  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dce99f  jmp 0x000071BD06DCE752
000071bd06dce9a4  ucomisd xmm1, xmm14
000071bd06dce9a9  jp 0x000071BD06DCE9B8
000071bd06dce9ab  movaps xmm13, [0x000071BD069FE030]
000071bd06dce9b3  jmp 0x000071BD06DCE77F
000071bd06dce9b8  vxorps xmm0, xmm1, xmm14
000071bd06dce9bd  pextrw eax, xmm0, 0x03
000071bd06dce9c2  and eax, 0x7FF8
000071bd06dce9c7  cmp eax, 0x08
000071bd06dce9ca  jnz 0x000071BD06DCE77F
000071bd06dce9d0  movq rax, xmm14
000071bd06dce9d5  shl rax, 0x0D
000071bd06dce9d9  jbe 0x000071BD06DCE77F
000071bd06dce9df  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dce9e7  jmp 0x000071BD06DCE77F
000071bd06dce9ec  ucomisd xmm1, xmm14
000071bd06dce9f1  jp 0x000071BD06DCEA00
000071bd06dce9f3  movaps xmm13, [0x000071BD069FE030]
000071bd06dce9fb  jmp 0x000071BD06DCE7AC
000071bd06dcea00  vxorps xmm0, xmm1, xmm14
000071bd06dcea05  pextrw eax, xmm0, 0x03
000071bd06dcea0a  and eax, 0x7FF8
000071bd06dcea0f  cmp eax, 0x08
000071bd06dcea12  jnz 0x000071BD06DCE7AC
000071bd06dcea18  movq rax, xmm14
000071bd06dcea1d  shl rax, 0x0D
000071bd06dcea21  jbe 0x000071BD06DCE7AC
000071bd06dcea27  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dcea2f  jmp 0x000071BD06DCE7AC
000071bd06dcea34  ucomisd xmm1, xmm14
000071bd06dcea39  jp 0x000071BD06DCEA48
000071bd06dcea3b  movaps xmm13, [0x000071BD069FE030]
000071bd06dcea43  jmp 0x000071BD06DCE7D9
000071bd06dcea48  vxorps xmm0, xmm1, xmm14
000071bd06dcea4d  pextrw eax, xmm0, 0x03
000071bd06dcea52  and eax, 0x7FF8
000071bd06dcea57  cmp eax, 0x08
000071bd06dcea5a  jnz 0x000071BD06DCE7D9
000071bd06dcea60  movq rax, xmm14
000071bd06dcea65  shl rax, 0x0D
000071bd06dcea69  jbe 0x000071BD06DCE7D9
000071bd06dcea6f  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dcea77  jmp 0x000071BD06DCE7D9
000071bd06dcea7c  ucomisd xmm1, xmm14
000071bd06dcea81  jp 0x000071BD06DCEA90
000071bd06dcea83  movaps xmm13, [0x000071BD069FE030]
000071bd06dcea8b  jmp 0x000071BD06DCE806
000071bd06dcea90  vxorps xmm0, xmm1, xmm14
000071bd06dcea95  pextrw eax, xmm0, 0x03
000071bd06dcea9a  and eax, 0x7FF8
000071bd06dcea9f  cmp eax, 0x08
000071bd06dceaa2  jnz 0x000071BD06DCE806
000071bd06dceaa8  movq rax, xmm14
000071bd06dceaad  shl rax, 0x0D
000071bd06dceab1  jbe 0x000071BD06DCE806
000071bd06dceab7  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dceabf  jmp 0x000071BD06DCE806
000071bd06dceac4  ucomisd xmm1, xmm15
000071bd06dceac9  jp 0x000071BD06DCEAD8
000071bd06dceacb  movaps xmm14, [0x000071BD069FE030]
000071bd06dcead3  jmp 0x000071BD06DCE833
000071bd06dcead8  vxorps xmm0, xmm1, xmm15
000071bd06dceadd  pextrw eax, xmm0, 0x03
000071bd06dceae2  and eax, 0x7FF8
000071bd06dceae7  cmp eax, 0x08
000071bd06dceaea  jnz 0x000071BD06DCE833
000071bd06dceaf0  movq rax, xmm15
000071bd06dceaf5  shl rax, 0x0D
000071bd06dceaf9  jbe 0x000071BD06DCE833
000071bd06dceaff  vorps xmm14, xmm15, [0x000071BD069FE040]
000071bd06dceb07  jmp 0x000071BD06DCE833
000071bd06dceb0c  int3
000071bd06dceb0d  nop [rax], eax
000071bd06dceb10  movaps xmm1, [r15+0x110]
000071bd06dceb18  movq rax, xmm1
000071bd06dceb1d  movaps xmm1, [r15+0x120]
000071bd06dceb25  movq r14, xmm1
000071bd06dceb2a  vmovq xmm15, rax
000071bd06dceb2f  vmovq xmm14, r14
000071bd06dceb34  movaps xmm13, xmm15
000071bd06dceb38  addsd xmm13, xmm14
000071bd06dceb3d  ucomisd xmm13, xmm13
000071bd06dceb42  jp 0x000071BD06DCED24
000071bd06dceb48  movq xmm13, xmm13
000071bd06dceb4d  movq rax, xmm13
000071bd06dceb52  movq r14, xmm1
000071bd06dceb57  vmovq xmm15, rax
000071bd06dceb5c  vmovq xmm14, r14
000071bd06dceb61  movaps xmm13, xmm15
000071bd06dceb65  addsd xmm13, xmm14
000071bd06dceb6a  ucomisd xmm13, xmm13
000071bd06dceb6f  jp 0x000071BD06DCED6C
000071bd06dceb75  movq xmm13, xmm13
000071bd06dceb7a  movq rax, xmm13
000071bd06dceb7f  movq r14, xmm1
000071bd06dceb84  vmovq xmm15, rax
000071bd06dceb89  vmovq xmm14, r14
000071bd06dceb8e  movaps xmm13, xmm15
000071bd06dceb92  addsd xmm13, xmm14
000071bd06dceb97  ucomisd xmm13, xmm13
000071bd06dceb9c  jp 0x000071BD06DCEDB4
000071bd06dceba2  movq xmm13, xmm13
000071bd06dceba7  movq rax, xmm13
000071bd06dcebac  movq r14, xmm1
000071bd06dcebb1  vmovq xmm15, rax
000071bd06dcebb6  vmovq xmm14, r14
000071bd06dcebbb  movaps xmm13, xmm15
000071bd06dcebbf  addsd xmm13, xmm14
000071bd06dcebc4  ucomisd xmm13, xmm13
000071bd06dcebc9  jp 0x000071BD06DCEDFC
000071bd06dcebcf  movq xmm13, xmm13
000071bd06dcebd4  movq rax, xmm13
000071bd06dcebd9  movq r14, xmm1
000071bd06dcebde  vmovq xmm15, rax
000071bd06dcebe3  vmovq xmm14, r14
000071bd06dcebe8  movaps xmm13, xmm15
000071bd06dcebec  addsd xmm13, xmm14
000071bd06dcebf1  ucomisd xmm13, xmm13
000071bd06dcebf6  jp 0x000071BD06DCEE44
000071bd06dcebfc  movq xmm13, xmm13
000071bd06dcec01  movq rax, xmm13
000071bd06dcec06  movq r14, xmm1
000071bd06dcec0b  vmovq xmm15, rax
000071bd06dcec10  vmovq xmm14, r14
000071bd06dcec15  movaps xmm13, xmm15
000071bd06dcec19  addsd xmm13, xmm14
000071bd06dcec1e  ucomisd xmm13, xmm13
000071bd06dcec23  jp 0x000071BD06DCEE8C
000071bd06dcec29  movq xmm13, xmm13
000071bd06dcec2e  movq rax, xmm13
000071bd06dcec33  movq r14, xmm1
000071bd06dcec38  vmovq xmm15, rax
000071bd06dcec3d  vmovq xmm14, r14
000071bd06dcec42  movaps xmm13, xmm15
000071bd06dcec46  addsd xmm13, xmm14
000071bd06dcec4b  ucomisd xmm13, xmm13
000071bd06dcec50  jp 0x000071BD06DCEED4
000071bd06dcec56  movq xmm13, xmm13
000071bd06dcec5b  movq rax, xmm13
000071bd06dcec60  movq r14, xmm1
000071bd06dcec65  vmovq xmm1, rax
000071bd06dcec6a  vmovq xmm15, r14
000071bd06dcec6f  movaps xmm14, xmm1
000071bd06dcec73  addsd xmm14, xmm15
000071bd06dcec78  ucomisd xmm14, xmm14
000071bd06dcec7d  jp 0x000071BD06DCEF1C
000071bd06dcec83  movq xmm14, xmm14
000071bd06dcec88  movaps [r15+0x110], xmm14
000071bd06dcec90  mov rax, [r15+0x08]
000071bd06dcec94  mov [rsp+0x10], rax
000071bd06dcec99  xor eax, eax
000071bd06dcec9b  mov r14, [rsp+0x10]
000071bd06dceca0  mov r12d, 0x01
000071bd06dceca6  sub r14, r12
000071bd06dceca9  cmc
000071bd06dcecaa  lahf
000071bd06dcecab  seto al
000071bd06dcecae  mov [r15+0x108], eax
000071bd06dcecb5  mov [r15+0x08], r14
000071bd06dcecb9  mov eax, [r15+0x108]
000071bd06dcecc0  sahf
000071bd06dcecc1  jnz 0x000071BD06DCECF3
000071bd06dcecc3  cmp dword ptr [r15+0x318], 0x00
000071bd06dceccb  jz 0x000071BD06DCEF70
000071bd06dcecd1  nop [rax+rax*1], ax
000071bd06dcecda  nop [rax+rax*1], eax
000071bd06dcece2  mov eax, 0x41006C
000071bd06dcece7  mov [r15+0x100], rax
000071bd06dcecee  jmp 0x000071BD06BFE110
000071bd06dcecf3  cmp dword ptr [r15+0x318], 0x00
000071bd06dcecfb  jz 0x000071BD06DCEB10
000071bd06dced01  nop [rax+rax*1], ax
000071bd06dced0a  nop [rax+rax*1], eax
000071bd06dced12  mov eax, 0x410044
000071bd06dced17  mov [r15+0x100], rax
000071bd06dced1e  jmp 0x000071BD06BFE110
000071bd06dced23  int3
000071bd06dced24  ucomisd xmm15, xmm14
000071bd06dced29  jp 0x000071BD06DCED38
000071bd06dced2b  movaps xmm13, [0x000071BD069FE030]
000071bd06dced33  jmp 0x000071BD06DCEB48
000071bd06dced38  vxorps xmm0, xmm15, xmm14
000071bd06dced3d  pextrw eax, xmm0, 0x03
000071bd06dced42  and eax, 0x7FF8
000071bd06dced47  cmp eax, 0x08
000071bd06dced4a  jnz 0x000071BD06DCEB48
000071bd06dced50  movq rax, xmm14
000071bd06dced55  shl rax, 0x0D
000071bd06dced59  jbe 0x000071BD06DCEB48
000071bd06dced5f  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dced67  jmp 0x000071BD06DCEB48
000071bd06dced6c  ucomisd xmm15, xmm14
000071bd06dced71  jp 0x000071BD06DCED80
000071bd06dced73  movaps xmm13, [0x000071BD069FE030]
000071bd06dced7b  jmp 0x000071BD06DCEB75
000071bd06dced80  vxorps xmm0, xmm15, xmm14
000071bd06dced85  pextrw eax, xmm0, 0x03
000071bd06dced8a  and eax, 0x7FF8
000071bd06dced8f  cmp eax, 0x08
000071bd06dced92  jnz 0x000071BD06DCEB75
000071bd06dced98  movq rax, xmm14
000071bd06dced9d  shl rax, 0x0D
000071bd06dceda1  jbe 0x000071BD06DCEB75
000071bd06dceda7  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dcedaf  jmp 0x000071BD06DCEB75
000071bd06dcedb4  ucomisd xmm15, xmm14
000071bd06dcedb9  jp 0x000071BD06DCEDC8
000071bd06dcedbb  movaps xmm13, [0x000071BD069FE030]
000071bd06dcedc3  jmp 0x000071BD06DCEBA2
000071bd06dcedc8  vxorps xmm0, xmm15, xmm14
000071bd06dcedcd  pextrw eax, xmm0, 0x03
000071bd06dcedd2  and eax, 0x7FF8
000071bd06dcedd7  cmp eax, 0x08
000071bd06dcedda  jnz 0x000071BD06DCEBA2
000071bd06dcede0  movq rax, xmm14
000071bd06dcede5  shl rax, 0x0D
000071bd06dcede9  jbe 0x000071BD06DCEBA2
000071bd06dcedef  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dcedf7  jmp 0x000071BD06DCEBA2
000071bd06dcedfc  ucomisd xmm15, xmm14
000071bd06dcee01  jp 0x000071BD06DCEE10
000071bd06dcee03  movaps xmm13, [0x000071BD069FE030]
000071bd06dcee0b  jmp 0x000071BD06DCEBCF
000071bd06dcee10  vxorps xmm0, xmm15, xmm14
000071bd06dcee15  pextrw eax, xmm0, 0x03
000071bd06dcee1a  and eax, 0x7FF8
000071bd06dcee1f  cmp eax, 0x08
000071bd06dcee22  jnz 0x000071BD06DCEBCF
000071bd06dcee28  movq rax, xmm14
000071bd06dcee2d  shl rax, 0x0D
000071bd06dcee31  jbe 0x000071BD06DCEBCF
000071bd06dcee37  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dcee3f  jmp 0x000071BD06DCEBCF
000071bd06dcee44  ucomisd xmm15, xmm14
000071bd06dcee49  jp 0x000071BD06DCEE58
000071bd06dcee4b  movaps xmm13, [0x000071BD069FE030]
000071bd06dcee53  jmp 0x000071BD06DCEBFC
000071bd06dcee58  vxorps xmm0, xmm15, xmm14
000071bd06dcee5d  pextrw eax, xmm0, 0x03
000071bd06dcee62  and eax, 0x7FF8
000071bd06dcee67  cmp eax, 0x08
000071bd06dcee6a  jnz 0x000071BD06DCEBFC
000071bd06dcee70  movq rax, xmm14
000071bd06dcee75  shl rax, 0x0D
000071bd06dcee79  jbe 0x000071BD06DCEBFC
000071bd06dcee7f  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dcee87  jmp 0x000071BD06DCEBFC
000071bd06dcee8c  ucomisd xmm15, xmm14
000071bd06dcee91  jp 0x000071BD06DCEEA0
000071bd06dcee93  movaps xmm13, [0x000071BD069FE030]
000071bd06dcee9b  jmp 0x000071BD06DCEC29
000071bd06dceea0  vxorps xmm0, xmm15, xmm14
000071bd06dceea5  pextrw eax, xmm0, 0x03
000071bd06dceeaa  and eax, 0x7FF8
000071bd06dceeaf  cmp eax, 0x08
000071bd06dceeb2  jnz 0x000071BD06DCEC29
000071bd06dceeb8  movq rax, xmm14
000071bd06dceebd  shl rax, 0x0D
000071bd06dceec1  jbe 0x000071BD06DCEC29
000071bd06dceec7  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dceecf  jmp 0x000071BD06DCEC29
000071bd06dceed4  ucomisd xmm15, xmm14
000071bd06dceed9  jp 0x000071BD06DCEEE8
000071bd06dceedb  movaps xmm13, [0x000071BD069FE030]
000071bd06dceee3  jmp 0x000071BD06DCEC56
000071bd06dceee8  vxorps xmm0, xmm15, xmm14
000071bd06dceeed  pextrw eax, xmm0, 0x03
000071bd06dceef2  and eax, 0x7FF8
000071bd06dceef7  cmp eax, 0x08
000071bd06dceefa  jnz 0x000071BD06DCEC56
000071bd06dcef00  movq rax, xmm14
000071bd06dcef05  shl rax, 0x0D
000071bd06dcef09  jbe 0x000071BD06DCEC56
000071bd06dcef0f  vorps xmm13, xmm14, [0x000071BD069FE040]
000071bd06dcef17  jmp 0x000071BD06DCEC56
000071bd06dcef1c  ucomisd xmm1, xmm15
000071bd06dcef21  jp 0x000071BD06DCEF30
000071bd06dcef23  movaps xmm14, [0x000071BD069FE030]
000071bd06dcef2b  jmp 0x000071BD06DCEC83
000071bd06dcef30  vxorps xmm0, xmm1, xmm15
000071bd06dcef35  pextrw eax, xmm0, 0x03
000071bd06dcef3a  and eax, 0x7FF8
000071bd06dcef3f  cmp eax, 0x08
000071bd06dcef42  jnz 0x000071BD06DCEC83
000071bd06dcef48  movq rax, xmm15
000071bd06dcef4d  shl rax, 0x0D
000071bd06dcef51  jbe 0x000071BD06DCEC83
000071bd06dcef57  vorps xmm14, xmm15, [0x000071BD069FE040]
000071bd06dcef5f  jmp 0x000071BD06DCEC83
000071bd06dcef64  int3
000071bd06dcef65  nop [rax+rax*1], ax
000071bd06dcef6e  nop
000071bd06dcef70  mov rax, [r15+0x20]
000071bd06dcef74  movaps xmm1, [r15+0x110]
000071bd06dcef7c  movq r14, xmm1
000071bd06dcef81  mov [r13+rax*1], r14
000071bd06dcef86  mov rax, [r15+0xF0]
000071bd06dcef8d  mov [r15+0x100], rax
000071bd06dcef94  jmp 0x000071BD06DCE5C0
000071bd06dcef99  int3
000071bd06dcef9a  call 0x000071BD06C0E120
000071bd06dcef9f  jmp 0x000071BD06DCEF86
000071bd06dcefa4  int3
000071bd06dcefa5  nop [rax+rax*1], ax
000071bd06dcefae  nop
000071bd06dcefb0  mov qword ptr [r15+0x100], 0x04
000071bd06dcefbb  mov esi, 0x00
000071bd06dcefc0  mov edx, 0x09
000071bd06dcefc5  mov rdi, 0x7FFD9D58BF20
000071bd06dcefcf  mov rax, 0x5C65D3768970
000071bd06dcefd9  call rax
000071bd06dcefdb  cmp dword ptr [r15+0x318], 0x00
000071bd06dcefe3  jnz 0x000071BD06BFE110
000071bd06dcefe9  jmp 0x000071BD06BFE0A0
000071bd06dcefee  int3
000071bd06dcefef  int3
