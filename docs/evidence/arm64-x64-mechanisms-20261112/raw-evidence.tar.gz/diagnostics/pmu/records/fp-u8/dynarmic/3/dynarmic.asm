00007ad7dd5ce69b  nop [rax+rax*1], eax
00007ad7dd5ce6a0  mov qword ptr [r15+0x20], 0x420080
00007ad7dd5ce6a8  mov qword ptr [r15], 0x00
00007ad7dd5ce6af  vmovaps xmm1, [0x00007AD7DD1FE010]
00007ad7dd5ce6b7  movq xmm1, xmm1
00007ad7dd5ce6bb  vmovaps xmm15, [0x00007AD7DD1FE020]
00007ad7dd5ce6c3  movq xmm15, xmm15
00007ad7dd5ce6c8  movaps [r15+0x120], xmm15
00007ad7dd5ce6d0  movq rax, xmm1
00007ad7dd5ce6d5  movq r14, xmm15
00007ad7dd5ce6da  vmovq xmm1, rax
00007ad7dd5ce6df  vmovq xmm14, r14
00007ad7dd5ce6e4  movaps xmm13, xmm1
00007ad7dd5ce6e8  addsd xmm13, xmm14
00007ad7dd5ce6ed  ucomisd xmm13, xmm13
00007ad7dd5ce6f2  jp 0x00007AD7DD5CE8CC
00007ad7dd5ce6f8  movq xmm13, xmm13
00007ad7dd5ce6fd  movq rax, xmm13
00007ad7dd5ce702  movq r14, xmm15
00007ad7dd5ce707  vmovq xmm1, rax
00007ad7dd5ce70c  vmovq xmm14, r14
00007ad7dd5ce711  movaps xmm13, xmm1
00007ad7dd5ce715  addsd xmm13, xmm14
00007ad7dd5ce71a  ucomisd xmm13, xmm13
00007ad7dd5ce71f  jp 0x00007AD7DD5CE914
00007ad7dd5ce725  movq xmm13, xmm13
00007ad7dd5ce72a  movq rax, xmm13
00007ad7dd5ce72f  movq r14, xmm15
00007ad7dd5ce734  vmovq xmm1, rax
00007ad7dd5ce739  vmovq xmm14, r14
00007ad7dd5ce73e  movaps xmm13, xmm1
00007ad7dd5ce742  addsd xmm13, xmm14
00007ad7dd5ce747  ucomisd xmm13, xmm13
00007ad7dd5ce74c  jp 0x00007AD7DD5CE95C
00007ad7dd5ce752  movq xmm13, xmm13
00007ad7dd5ce757  movq rax, xmm13
00007ad7dd5ce75c  movq r14, xmm15
00007ad7dd5ce761  vmovq xmm1, rax
00007ad7dd5ce766  vmovq xmm14, r14
00007ad7dd5ce76b  movaps xmm13, xmm1
00007ad7dd5ce76f  addsd xmm13, xmm14
00007ad7dd5ce774  ucomisd xmm13, xmm13
00007ad7dd5ce779  jp 0x00007AD7DD5CE9A4
00007ad7dd5ce77f  movq xmm13, xmm13
00007ad7dd5ce784  movq rax, xmm13
00007ad7dd5ce789  movq r14, xmm15
00007ad7dd5ce78e  vmovq xmm1, rax
00007ad7dd5ce793  vmovq xmm14, r14
00007ad7dd5ce798  movaps xmm13, xmm1
00007ad7dd5ce79c  addsd xmm13, xmm14
00007ad7dd5ce7a1  ucomisd xmm13, xmm13
00007ad7dd5ce7a6  jp 0x00007AD7DD5CE9EC
00007ad7dd5ce7ac  movq xmm13, xmm13
00007ad7dd5ce7b1  movq rax, xmm13
00007ad7dd5ce7b6  movq r14, xmm15
00007ad7dd5ce7bb  vmovq xmm1, rax
00007ad7dd5ce7c0  vmovq xmm14, r14
00007ad7dd5ce7c5  movaps xmm13, xmm1
00007ad7dd5ce7c9  addsd xmm13, xmm14
00007ad7dd5ce7ce  ucomisd xmm13, xmm13
00007ad7dd5ce7d3  jp 0x00007AD7DD5CEA34
00007ad7dd5ce7d9  movq xmm13, xmm13
00007ad7dd5ce7de  movq rax, xmm13
00007ad7dd5ce7e3  movq r14, xmm15
00007ad7dd5ce7e8  vmovq xmm1, rax
00007ad7dd5ce7ed  vmovq xmm14, r14
00007ad7dd5ce7f2  movaps xmm13, xmm1
00007ad7dd5ce7f6  addsd xmm13, xmm14
00007ad7dd5ce7fb  ucomisd xmm13, xmm13
00007ad7dd5ce800  jp 0x00007AD7DD5CEA7C
00007ad7dd5ce806  movq xmm13, xmm13
00007ad7dd5ce80b  movq rax, xmm13
00007ad7dd5ce810  movq r14, xmm15
00007ad7dd5ce815  vmovq xmm1, rax
00007ad7dd5ce81a  vmovq xmm15, r14
00007ad7dd5ce81f  movaps xmm14, xmm1
00007ad7dd5ce823  addsd xmm14, xmm15
00007ad7dd5ce828  ucomisd xmm14, xmm14
00007ad7dd5ce82d  jp 0x00007AD7DD5CEAC4
00007ad7dd5ce833  movq xmm14, xmm14
00007ad7dd5ce838  movaps [r15+0x110], xmm14
00007ad7dd5ce840  xor eax, eax
00007ad7dd5ce842  mov r14d, 0x1E848
00007ad7dd5ce848  mov r12d, 0x01
00007ad7dd5ce84e  sub r14, r12
00007ad7dd5ce851  cmc
00007ad7dd5ce852  lahf
00007ad7dd5ce853  seto al
00007ad7dd5ce856  mov [r15+0x108], eax
00007ad7dd5ce85d  mov [r15+0x08], r14
00007ad7dd5ce861  mov eax, [r15+0x108]
00007ad7dd5ce868  sahf
00007ad7dd5ce869  jnz 0x00007AD7DD5CE89B
00007ad7dd5ce86b  cmp dword ptr [r15+0x318], 0x00
00007ad7dd5ce873  jz 0x00007AD7DD5CEF70
00007ad7dd5ce879  nop [rax+rax*1], ax
00007ad7dd5ce882  nop [rax+rax*1], eax
00007ad7dd5ce88a  mov eax, 0x41006C
00007ad7dd5ce88f  mov [r15+0x100], rax
00007ad7dd5ce896  jmp 0x00007AD7DD3FE110
00007ad7dd5ce89b  cmp dword ptr [r15+0x318], 0x00
00007ad7dd5ce8a3  jz 0x00007AD7DD5CEB10
00007ad7dd5ce8a9  nop [rax+rax*1], ax
00007ad7dd5ce8b2  nop [rax+rax*1], eax
00007ad7dd5ce8ba  mov eax, 0x410044
00007ad7dd5ce8bf  mov [r15+0x100], rax
00007ad7dd5ce8c6  jmp 0x00007AD7DD3FE110
00007ad7dd5ce8cb  int3
00007ad7dd5ce8cc  ucomisd xmm1, xmm14
00007ad7dd5ce8d1  jp 0x00007AD7DD5CE8E0
00007ad7dd5ce8d3  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5ce8db  jmp 0x00007AD7DD5CE6F8
00007ad7dd5ce8e0  vxorps xmm0, xmm1, xmm14
00007ad7dd5ce8e5  pextrw eax, xmm0, 0x03
00007ad7dd5ce8ea  and eax, 0x7FF8
00007ad7dd5ce8ef  cmp eax, 0x08
00007ad7dd5ce8f2  jnz 0x00007AD7DD5CE6F8
00007ad7dd5ce8f8  movq rax, xmm14
00007ad7dd5ce8fd  shl rax, 0x0D
00007ad7dd5ce901  jbe 0x00007AD7DD5CE6F8
00007ad7dd5ce907  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5ce90f  jmp 0x00007AD7DD5CE6F8
00007ad7dd5ce914  ucomisd xmm1, xmm14
00007ad7dd5ce919  jp 0x00007AD7DD5CE928
00007ad7dd5ce91b  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5ce923  jmp 0x00007AD7DD5CE725
00007ad7dd5ce928  vxorps xmm0, xmm1, xmm14
00007ad7dd5ce92d  pextrw eax, xmm0, 0x03
00007ad7dd5ce932  and eax, 0x7FF8
00007ad7dd5ce937  cmp eax, 0x08
00007ad7dd5ce93a  jnz 0x00007AD7DD5CE725
00007ad7dd5ce940  movq rax, xmm14
00007ad7dd5ce945  shl rax, 0x0D
00007ad7dd5ce949  jbe 0x00007AD7DD5CE725
00007ad7dd5ce94f  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5ce957  jmp 0x00007AD7DD5CE725
00007ad7dd5ce95c  ucomisd xmm1, xmm14
00007ad7dd5ce961  jp 0x00007AD7DD5CE970
00007ad7dd5ce963  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5ce96b  jmp 0x00007AD7DD5CE752
00007ad7dd5ce970  vxorps xmm0, xmm1, xmm14
00007ad7dd5ce975  pextrw eax, xmm0, 0x03
00007ad7dd5ce97a  and eax, 0x7FF8
00007ad7dd5ce97f  cmp eax, 0x08
00007ad7dd5ce982  jnz 0x00007AD7DD5CE752
00007ad7dd5ce988  movq rax, xmm14
00007ad7dd5ce98d  shl rax, 0x0D
00007ad7dd5ce991  jbe 0x00007AD7DD5CE752
00007ad7dd5ce997  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5ce99f  jmp 0x00007AD7DD5CE752
00007ad7dd5ce9a4  ucomisd xmm1, xmm14
00007ad7dd5ce9a9  jp 0x00007AD7DD5CE9B8
00007ad7dd5ce9ab  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5ce9b3  jmp 0x00007AD7DD5CE77F
00007ad7dd5ce9b8  vxorps xmm0, xmm1, xmm14
00007ad7dd5ce9bd  pextrw eax, xmm0, 0x03
00007ad7dd5ce9c2  and eax, 0x7FF8
00007ad7dd5ce9c7  cmp eax, 0x08
00007ad7dd5ce9ca  jnz 0x00007AD7DD5CE77F
00007ad7dd5ce9d0  movq rax, xmm14
00007ad7dd5ce9d5  shl rax, 0x0D
00007ad7dd5ce9d9  jbe 0x00007AD7DD5CE77F
00007ad7dd5ce9df  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5ce9e7  jmp 0x00007AD7DD5CE77F
00007ad7dd5ce9ec  ucomisd xmm1, xmm14
00007ad7dd5ce9f1  jp 0x00007AD7DD5CEA00
00007ad7dd5ce9f3  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5ce9fb  jmp 0x00007AD7DD5CE7AC
00007ad7dd5cea00  vxorps xmm0, xmm1, xmm14
00007ad7dd5cea05  pextrw eax, xmm0, 0x03
00007ad7dd5cea0a  and eax, 0x7FF8
00007ad7dd5cea0f  cmp eax, 0x08
00007ad7dd5cea12  jnz 0x00007AD7DD5CE7AC
00007ad7dd5cea18  movq rax, xmm14
00007ad7dd5cea1d  shl rax, 0x0D
00007ad7dd5cea21  jbe 0x00007AD7DD5CE7AC
00007ad7dd5cea27  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5cea2f  jmp 0x00007AD7DD5CE7AC
00007ad7dd5cea34  ucomisd xmm1, xmm14
00007ad7dd5cea39  jp 0x00007AD7DD5CEA48
00007ad7dd5cea3b  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5cea43  jmp 0x00007AD7DD5CE7D9
00007ad7dd5cea48  vxorps xmm0, xmm1, xmm14
00007ad7dd5cea4d  pextrw eax, xmm0, 0x03
00007ad7dd5cea52  and eax, 0x7FF8
00007ad7dd5cea57  cmp eax, 0x08
00007ad7dd5cea5a  jnz 0x00007AD7DD5CE7D9
00007ad7dd5cea60  movq rax, xmm14
00007ad7dd5cea65  shl rax, 0x0D
00007ad7dd5cea69  jbe 0x00007AD7DD5CE7D9
00007ad7dd5cea6f  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5cea77  jmp 0x00007AD7DD5CE7D9
00007ad7dd5cea7c  ucomisd xmm1, xmm14
00007ad7dd5cea81  jp 0x00007AD7DD5CEA90
00007ad7dd5cea83  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5cea8b  jmp 0x00007AD7DD5CE806
00007ad7dd5cea90  vxorps xmm0, xmm1, xmm14
00007ad7dd5cea95  pextrw eax, xmm0, 0x03
00007ad7dd5cea9a  and eax, 0x7FF8
00007ad7dd5cea9f  cmp eax, 0x08
00007ad7dd5ceaa2  jnz 0x00007AD7DD5CE806
00007ad7dd5ceaa8  movq rax, xmm14
00007ad7dd5ceaad  shl rax, 0x0D
00007ad7dd5ceab1  jbe 0x00007AD7DD5CE806
00007ad7dd5ceab7  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5ceabf  jmp 0x00007AD7DD5CE806
00007ad7dd5ceac4  ucomisd xmm1, xmm15
00007ad7dd5ceac9  jp 0x00007AD7DD5CEAD8
00007ad7dd5ceacb  movaps xmm14, [0x00007AD7DD1FE030]
00007ad7dd5cead3  jmp 0x00007AD7DD5CE833
00007ad7dd5cead8  vxorps xmm0, xmm1, xmm15
00007ad7dd5ceadd  pextrw eax, xmm0, 0x03
00007ad7dd5ceae2  and eax, 0x7FF8
00007ad7dd5ceae7  cmp eax, 0x08
00007ad7dd5ceaea  jnz 0x00007AD7DD5CE833
00007ad7dd5ceaf0  movq rax, xmm15
00007ad7dd5ceaf5  shl rax, 0x0D
00007ad7dd5ceaf9  jbe 0x00007AD7DD5CE833
00007ad7dd5ceaff  vorps xmm14, xmm15, [0x00007AD7DD1FE040]
00007ad7dd5ceb07  jmp 0x00007AD7DD5CE833
00007ad7dd5ceb0c  int3
00007ad7dd5ceb0d  nop [rax], eax
00007ad7dd5ceb10  movaps xmm1, [r15+0x110]
00007ad7dd5ceb18  movq rax, xmm1
00007ad7dd5ceb1d  movaps xmm1, [r15+0x120]
00007ad7dd5ceb25  movq r14, xmm1
00007ad7dd5ceb2a  vmovq xmm15, rax
00007ad7dd5ceb2f  vmovq xmm14, r14
00007ad7dd5ceb34  movaps xmm13, xmm15
00007ad7dd5ceb38  addsd xmm13, xmm14
00007ad7dd5ceb3d  ucomisd xmm13, xmm13
00007ad7dd5ceb42  jp 0x00007AD7DD5CED24
00007ad7dd5ceb48  movq xmm13, xmm13
00007ad7dd5ceb4d  movq rax, xmm13
00007ad7dd5ceb52  movq r14, xmm1
00007ad7dd5ceb57  vmovq xmm15, rax
00007ad7dd5ceb5c  vmovq xmm14, r14
00007ad7dd5ceb61  movaps xmm13, xmm15
00007ad7dd5ceb65  addsd xmm13, xmm14
00007ad7dd5ceb6a  ucomisd xmm13, xmm13
00007ad7dd5ceb6f  jp 0x00007AD7DD5CED6C
00007ad7dd5ceb75  movq xmm13, xmm13
00007ad7dd5ceb7a  movq rax, xmm13
00007ad7dd5ceb7f  movq r14, xmm1
00007ad7dd5ceb84  vmovq xmm15, rax
00007ad7dd5ceb89  vmovq xmm14, r14
00007ad7dd5ceb8e  movaps xmm13, xmm15
00007ad7dd5ceb92  addsd xmm13, xmm14
00007ad7dd5ceb97  ucomisd xmm13, xmm13
00007ad7dd5ceb9c  jp 0x00007AD7DD5CEDB4
00007ad7dd5ceba2  movq xmm13, xmm13
00007ad7dd5ceba7  movq rax, xmm13
00007ad7dd5cebac  movq r14, xmm1
00007ad7dd5cebb1  vmovq xmm15, rax
00007ad7dd5cebb6  vmovq xmm14, r14
00007ad7dd5cebbb  movaps xmm13, xmm15
00007ad7dd5cebbf  addsd xmm13, xmm14
00007ad7dd5cebc4  ucomisd xmm13, xmm13
00007ad7dd5cebc9  jp 0x00007AD7DD5CEDFC
00007ad7dd5cebcf  movq xmm13, xmm13
00007ad7dd5cebd4  movq rax, xmm13
00007ad7dd5cebd9  movq r14, xmm1
00007ad7dd5cebde  vmovq xmm15, rax
00007ad7dd5cebe3  vmovq xmm14, r14
00007ad7dd5cebe8  movaps xmm13, xmm15
00007ad7dd5cebec  addsd xmm13, xmm14
00007ad7dd5cebf1  ucomisd xmm13, xmm13
00007ad7dd5cebf6  jp 0x00007AD7DD5CEE44
00007ad7dd5cebfc  movq xmm13, xmm13
00007ad7dd5cec01  movq rax, xmm13
00007ad7dd5cec06  movq r14, xmm1
00007ad7dd5cec0b  vmovq xmm15, rax
00007ad7dd5cec10  vmovq xmm14, r14
00007ad7dd5cec15  movaps xmm13, xmm15
00007ad7dd5cec19  addsd xmm13, xmm14
00007ad7dd5cec1e  ucomisd xmm13, xmm13
00007ad7dd5cec23  jp 0x00007AD7DD5CEE8C
00007ad7dd5cec29  movq xmm13, xmm13
00007ad7dd5cec2e  movq rax, xmm13
00007ad7dd5cec33  movq r14, xmm1
00007ad7dd5cec38  vmovq xmm15, rax
00007ad7dd5cec3d  vmovq xmm14, r14
00007ad7dd5cec42  movaps xmm13, xmm15
00007ad7dd5cec46  addsd xmm13, xmm14
00007ad7dd5cec4b  ucomisd xmm13, xmm13
00007ad7dd5cec50  jp 0x00007AD7DD5CEED4
00007ad7dd5cec56  movq xmm13, xmm13
00007ad7dd5cec5b  movq rax, xmm13
00007ad7dd5cec60  movq r14, xmm1
00007ad7dd5cec65  vmovq xmm1, rax
00007ad7dd5cec6a  vmovq xmm15, r14
00007ad7dd5cec6f  movaps xmm14, xmm1
00007ad7dd5cec73  addsd xmm14, xmm15
00007ad7dd5cec78  ucomisd xmm14, xmm14
00007ad7dd5cec7d  jp 0x00007AD7DD5CEF1C
00007ad7dd5cec83  movq xmm14, xmm14
00007ad7dd5cec88  movaps [r15+0x110], xmm14
00007ad7dd5cec90  mov rax, [r15+0x08]
00007ad7dd5cec94  mov [rsp+0x10], rax
00007ad7dd5cec99  xor eax, eax
00007ad7dd5cec9b  mov r14, [rsp+0x10]
00007ad7dd5ceca0  mov r12d, 0x01
00007ad7dd5ceca6  sub r14, r12
00007ad7dd5ceca9  cmc
00007ad7dd5cecaa  lahf
00007ad7dd5cecab  seto al
00007ad7dd5cecae  mov [r15+0x108], eax
00007ad7dd5cecb5  mov [r15+0x08], r14
00007ad7dd5cecb9  mov eax, [r15+0x108]
00007ad7dd5cecc0  sahf
00007ad7dd5cecc1  jnz 0x00007AD7DD5CECF3
00007ad7dd5cecc3  cmp dword ptr [r15+0x318], 0x00
00007ad7dd5ceccb  jz 0x00007AD7DD5CEF70
00007ad7dd5cecd1  nop [rax+rax*1], ax
00007ad7dd5cecda  nop [rax+rax*1], eax
00007ad7dd5cece2  mov eax, 0x41006C
00007ad7dd5cece7  mov [r15+0x100], rax
00007ad7dd5cecee  jmp 0x00007AD7DD3FE110
00007ad7dd5cecf3  cmp dword ptr [r15+0x318], 0x00
00007ad7dd5cecfb  jz 0x00007AD7DD5CEB10
00007ad7dd5ced01  nop [rax+rax*1], ax
00007ad7dd5ced0a  nop [rax+rax*1], eax
00007ad7dd5ced12  mov eax, 0x410044
00007ad7dd5ced17  mov [r15+0x100], rax
00007ad7dd5ced1e  jmp 0x00007AD7DD3FE110
00007ad7dd5ced23  int3
00007ad7dd5ced24  ucomisd xmm15, xmm14
00007ad7dd5ced29  jp 0x00007AD7DD5CED38
00007ad7dd5ced2b  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5ced33  jmp 0x00007AD7DD5CEB48
00007ad7dd5ced38  vxorps xmm0, xmm15, xmm14
00007ad7dd5ced3d  pextrw eax, xmm0, 0x03
00007ad7dd5ced42  and eax, 0x7FF8
00007ad7dd5ced47  cmp eax, 0x08
00007ad7dd5ced4a  jnz 0x00007AD7DD5CEB48
00007ad7dd5ced50  movq rax, xmm14
00007ad7dd5ced55  shl rax, 0x0D
00007ad7dd5ced59  jbe 0x00007AD7DD5CEB48
00007ad7dd5ced5f  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5ced67  jmp 0x00007AD7DD5CEB48
00007ad7dd5ced6c  ucomisd xmm15, xmm14
00007ad7dd5ced71  jp 0x00007AD7DD5CED80
00007ad7dd5ced73  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5ced7b  jmp 0x00007AD7DD5CEB75
00007ad7dd5ced80  vxorps xmm0, xmm15, xmm14
00007ad7dd5ced85  pextrw eax, xmm0, 0x03
00007ad7dd5ced8a  and eax, 0x7FF8
00007ad7dd5ced8f  cmp eax, 0x08
00007ad7dd5ced92  jnz 0x00007AD7DD5CEB75
00007ad7dd5ced98  movq rax, xmm14
00007ad7dd5ced9d  shl rax, 0x0D
00007ad7dd5ceda1  jbe 0x00007AD7DD5CEB75
00007ad7dd5ceda7  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5cedaf  jmp 0x00007AD7DD5CEB75
00007ad7dd5cedb4  ucomisd xmm15, xmm14
00007ad7dd5cedb9  jp 0x00007AD7DD5CEDC8
00007ad7dd5cedbb  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5cedc3  jmp 0x00007AD7DD5CEBA2
00007ad7dd5cedc8  vxorps xmm0, xmm15, xmm14
00007ad7dd5cedcd  pextrw eax, xmm0, 0x03
00007ad7dd5cedd2  and eax, 0x7FF8
00007ad7dd5cedd7  cmp eax, 0x08
00007ad7dd5cedda  jnz 0x00007AD7DD5CEBA2
00007ad7dd5cede0  movq rax, xmm14
00007ad7dd5cede5  shl rax, 0x0D
00007ad7dd5cede9  jbe 0x00007AD7DD5CEBA2
00007ad7dd5cedef  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5cedf7  jmp 0x00007AD7DD5CEBA2
00007ad7dd5cedfc  ucomisd xmm15, xmm14
00007ad7dd5cee01  jp 0x00007AD7DD5CEE10
00007ad7dd5cee03  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5cee0b  jmp 0x00007AD7DD5CEBCF
00007ad7dd5cee10  vxorps xmm0, xmm15, xmm14
00007ad7dd5cee15  pextrw eax, xmm0, 0x03
00007ad7dd5cee1a  and eax, 0x7FF8
00007ad7dd5cee1f  cmp eax, 0x08
00007ad7dd5cee22  jnz 0x00007AD7DD5CEBCF
00007ad7dd5cee28  movq rax, xmm14
00007ad7dd5cee2d  shl rax, 0x0D
00007ad7dd5cee31  jbe 0x00007AD7DD5CEBCF
00007ad7dd5cee37  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5cee3f  jmp 0x00007AD7DD5CEBCF
00007ad7dd5cee44  ucomisd xmm15, xmm14
00007ad7dd5cee49  jp 0x00007AD7DD5CEE58
00007ad7dd5cee4b  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5cee53  jmp 0x00007AD7DD5CEBFC
00007ad7dd5cee58  vxorps xmm0, xmm15, xmm14
00007ad7dd5cee5d  pextrw eax, xmm0, 0x03
00007ad7dd5cee62  and eax, 0x7FF8
00007ad7dd5cee67  cmp eax, 0x08
00007ad7dd5cee6a  jnz 0x00007AD7DD5CEBFC
00007ad7dd5cee70  movq rax, xmm14
00007ad7dd5cee75  shl rax, 0x0D
00007ad7dd5cee79  jbe 0x00007AD7DD5CEBFC
00007ad7dd5cee7f  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5cee87  jmp 0x00007AD7DD5CEBFC
00007ad7dd5cee8c  ucomisd xmm15, xmm14
00007ad7dd5cee91  jp 0x00007AD7DD5CEEA0
00007ad7dd5cee93  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5cee9b  jmp 0x00007AD7DD5CEC29
00007ad7dd5ceea0  vxorps xmm0, xmm15, xmm14
00007ad7dd5ceea5  pextrw eax, xmm0, 0x03
00007ad7dd5ceeaa  and eax, 0x7FF8
00007ad7dd5ceeaf  cmp eax, 0x08
00007ad7dd5ceeb2  jnz 0x00007AD7DD5CEC29
00007ad7dd5ceeb8  movq rax, xmm14
00007ad7dd5ceebd  shl rax, 0x0D
00007ad7dd5ceec1  jbe 0x00007AD7DD5CEC29
00007ad7dd5ceec7  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5ceecf  jmp 0x00007AD7DD5CEC29
00007ad7dd5ceed4  ucomisd xmm15, xmm14
00007ad7dd5ceed9  jp 0x00007AD7DD5CEEE8
00007ad7dd5ceedb  movaps xmm13, [0x00007AD7DD1FE030]
00007ad7dd5ceee3  jmp 0x00007AD7DD5CEC56
00007ad7dd5ceee8  vxorps xmm0, xmm15, xmm14
00007ad7dd5ceeed  pextrw eax, xmm0, 0x03
00007ad7dd5ceef2  and eax, 0x7FF8
00007ad7dd5ceef7  cmp eax, 0x08
00007ad7dd5ceefa  jnz 0x00007AD7DD5CEC56
00007ad7dd5cef00  movq rax, xmm14
00007ad7dd5cef05  shl rax, 0x0D
00007ad7dd5cef09  jbe 0x00007AD7DD5CEC56
00007ad7dd5cef0f  vorps xmm13, xmm14, [0x00007AD7DD1FE040]
00007ad7dd5cef17  jmp 0x00007AD7DD5CEC56
00007ad7dd5cef1c  ucomisd xmm1, xmm15
00007ad7dd5cef21  jp 0x00007AD7DD5CEF30
00007ad7dd5cef23  movaps xmm14, [0x00007AD7DD1FE030]
00007ad7dd5cef2b  jmp 0x00007AD7DD5CEC83
00007ad7dd5cef30  vxorps xmm0, xmm1, xmm15
00007ad7dd5cef35  pextrw eax, xmm0, 0x03
00007ad7dd5cef3a  and eax, 0x7FF8
00007ad7dd5cef3f  cmp eax, 0x08
00007ad7dd5cef42  jnz 0x00007AD7DD5CEC83
00007ad7dd5cef48  movq rax, xmm15
00007ad7dd5cef4d  shl rax, 0x0D
00007ad7dd5cef51  jbe 0x00007AD7DD5CEC83
00007ad7dd5cef57  vorps xmm14, xmm15, [0x00007AD7DD1FE040]
00007ad7dd5cef5f  jmp 0x00007AD7DD5CEC83
00007ad7dd5cef64  int3
00007ad7dd5cef65  nop [rax+rax*1], ax
00007ad7dd5cef6e  nop
00007ad7dd5cef70  mov rax, [r15+0x20]
00007ad7dd5cef74  movaps xmm1, [r15+0x110]
00007ad7dd5cef7c  movq r14, xmm1
00007ad7dd5cef81  mov [r13+rax*1], r14
00007ad7dd5cef86  mov rax, [r15+0xF0]
00007ad7dd5cef8d  mov [r15+0x100], rax
00007ad7dd5cef94  jmp 0x00007AD7DD5CE5C0
00007ad7dd5cef99  int3
00007ad7dd5cef9a  call 0x00007AD7DD40E120
00007ad7dd5cef9f  jmp 0x00007AD7DD5CEF86
00007ad7dd5cefa4  int3
00007ad7dd5cefa5  nop [rax+rax*1], ax
00007ad7dd5cefae  nop
00007ad7dd5cefb0  mov qword ptr [r15+0x100], 0x04
00007ad7dd5cefbb  mov esi, 0x00
00007ad7dd5cefc0  mov edx, 0x09
00007ad7dd5cefc5  mov rdi, 0x7FFF16C68660
00007ad7dd5cefcf  mov rax, 0x627049648970
00007ad7dd5cefd9  call rax
00007ad7dd5cefdb  cmp dword ptr [r15+0x318], 0x00
00007ad7dd5cefe3  jnz 0x00007AD7DD3FE110
00007ad7dd5cefe9  jmp 0x00007AD7DD3FE0A0
00007ad7dd5cefee  int3
00007ad7dd5cefef  int3
