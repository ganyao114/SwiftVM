000072f45adce69b  nop [rax+rax*1], eax
000072f45adce6a0  mov qword ptr [r15+0x20], 0x420080
000072f45adce6a8  mov qword ptr [r15], 0x00
000072f45adce6af  vmovaps xmm1, [0x000072F45A9FE010]
000072f45adce6b7  movq xmm1, xmm1
000072f45adce6bb  vmovaps xmm15, [0x000072F45A9FE020]
000072f45adce6c3  movq xmm15, xmm15
000072f45adce6c8  movaps [r15+0x120], xmm15
000072f45adce6d0  movq rax, xmm1
000072f45adce6d5  movq r14, xmm15
000072f45adce6da  vmovq xmm1, rax
000072f45adce6df  vmovq xmm14, r14
000072f45adce6e4  movaps xmm13, xmm1
000072f45adce6e8  addsd xmm13, xmm14
000072f45adce6ed  ucomisd xmm13, xmm13
000072f45adce6f2  jp 0x000072F45ADCE8CC
000072f45adce6f8  movq xmm13, xmm13
000072f45adce6fd  movq rax, xmm13
000072f45adce702  movq r14, xmm15
000072f45adce707  vmovq xmm1, rax
000072f45adce70c  vmovq xmm14, r14
000072f45adce711  movaps xmm13, xmm1
000072f45adce715  addsd xmm13, xmm14
000072f45adce71a  ucomisd xmm13, xmm13
000072f45adce71f  jp 0x000072F45ADCE914
000072f45adce725  movq xmm13, xmm13
000072f45adce72a  movq rax, xmm13
000072f45adce72f  movq r14, xmm15
000072f45adce734  vmovq xmm1, rax
000072f45adce739  vmovq xmm14, r14
000072f45adce73e  movaps xmm13, xmm1
000072f45adce742  addsd xmm13, xmm14
000072f45adce747  ucomisd xmm13, xmm13
000072f45adce74c  jp 0x000072F45ADCE95C
000072f45adce752  movq xmm13, xmm13
000072f45adce757  movq rax, xmm13
000072f45adce75c  movq r14, xmm15
000072f45adce761  vmovq xmm1, rax
000072f45adce766  vmovq xmm14, r14
000072f45adce76b  movaps xmm13, xmm1
000072f45adce76f  addsd xmm13, xmm14
000072f45adce774  ucomisd xmm13, xmm13
000072f45adce779  jp 0x000072F45ADCE9A4
000072f45adce77f  movq xmm13, xmm13
000072f45adce784  movq rax, xmm13
000072f45adce789  movq r14, xmm15
000072f45adce78e  vmovq xmm1, rax
000072f45adce793  vmovq xmm14, r14
000072f45adce798  movaps xmm13, xmm1
000072f45adce79c  addsd xmm13, xmm14
000072f45adce7a1  ucomisd xmm13, xmm13
000072f45adce7a6  jp 0x000072F45ADCE9EC
000072f45adce7ac  movq xmm13, xmm13
000072f45adce7b1  movq rax, xmm13
000072f45adce7b6  movq r14, xmm15
000072f45adce7bb  vmovq xmm1, rax
000072f45adce7c0  vmovq xmm14, r14
000072f45adce7c5  movaps xmm13, xmm1
000072f45adce7c9  addsd xmm13, xmm14
000072f45adce7ce  ucomisd xmm13, xmm13
000072f45adce7d3  jp 0x000072F45ADCEA34
000072f45adce7d9  movq xmm13, xmm13
000072f45adce7de  movq rax, xmm13
000072f45adce7e3  movq r14, xmm15
000072f45adce7e8  vmovq xmm1, rax
000072f45adce7ed  vmovq xmm14, r14
000072f45adce7f2  movaps xmm13, xmm1
000072f45adce7f6  addsd xmm13, xmm14
000072f45adce7fb  ucomisd xmm13, xmm13
000072f45adce800  jp 0x000072F45ADCEA7C
000072f45adce806  movq xmm13, xmm13
000072f45adce80b  movq rax, xmm13
000072f45adce810  movq r14, xmm15
000072f45adce815  vmovq xmm1, rax
000072f45adce81a  vmovq xmm15, r14
000072f45adce81f  movaps xmm14, xmm1
000072f45adce823  addsd xmm14, xmm15
000072f45adce828  ucomisd xmm14, xmm14
000072f45adce82d  jp 0x000072F45ADCEAC4
000072f45adce833  movq xmm14, xmm14
000072f45adce838  movaps [r15+0x110], xmm14
000072f45adce840  xor eax, eax
000072f45adce842  mov r14d, 0x1E848
000072f45adce848  mov r12d, 0x01
000072f45adce84e  sub r14, r12
000072f45adce851  cmc
000072f45adce852  lahf
000072f45adce853  seto al
000072f45adce856  mov [r15+0x108], eax
000072f45adce85d  mov [r15+0x08], r14
000072f45adce861  mov eax, [r15+0x108]
000072f45adce868  sahf
000072f45adce869  jnz 0x000072F45ADCE89B
000072f45adce86b  cmp dword ptr [r15+0x318], 0x00
000072f45adce873  jz 0x000072F45ADCEF70
000072f45adce879  nop [rax+rax*1], ax
000072f45adce882  nop [rax+rax*1], eax
000072f45adce88a  mov eax, 0x41006C
000072f45adce88f  mov [r15+0x100], rax
000072f45adce896  jmp 0x000072F45ABFE110
000072f45adce89b  cmp dword ptr [r15+0x318], 0x00
000072f45adce8a3  jz 0x000072F45ADCEB10
000072f45adce8a9  nop [rax+rax*1], ax
000072f45adce8b2  nop [rax+rax*1], eax
000072f45adce8ba  mov eax, 0x410044
000072f45adce8bf  mov [r15+0x100], rax
000072f45adce8c6  jmp 0x000072F45ABFE110
000072f45adce8cb  int3
000072f45adce8cc  ucomisd xmm1, xmm14
000072f45adce8d1  jp 0x000072F45ADCE8E0
000072f45adce8d3  movaps xmm13, [0x000072F45A9FE030]
000072f45adce8db  jmp 0x000072F45ADCE6F8
000072f45adce8e0  vxorps xmm0, xmm1, xmm14
000072f45adce8e5  pextrw eax, xmm0, 0x03
000072f45adce8ea  and eax, 0x7FF8
000072f45adce8ef  cmp eax, 0x08
000072f45adce8f2  jnz 0x000072F45ADCE6F8
000072f45adce8f8  movq rax, xmm14
000072f45adce8fd  shl rax, 0x0D
000072f45adce901  jbe 0x000072F45ADCE6F8
000072f45adce907  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adce90f  jmp 0x000072F45ADCE6F8
000072f45adce914  ucomisd xmm1, xmm14
000072f45adce919  jp 0x000072F45ADCE928
000072f45adce91b  movaps xmm13, [0x000072F45A9FE030]
000072f45adce923  jmp 0x000072F45ADCE725
000072f45adce928  vxorps xmm0, xmm1, xmm14
000072f45adce92d  pextrw eax, xmm0, 0x03
000072f45adce932  and eax, 0x7FF8
000072f45adce937  cmp eax, 0x08
000072f45adce93a  jnz 0x000072F45ADCE725
000072f45adce940  movq rax, xmm14
000072f45adce945  shl rax, 0x0D
000072f45adce949  jbe 0x000072F45ADCE725
000072f45adce94f  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adce957  jmp 0x000072F45ADCE725
000072f45adce95c  ucomisd xmm1, xmm14
000072f45adce961  jp 0x000072F45ADCE970
000072f45adce963  movaps xmm13, [0x000072F45A9FE030]
000072f45adce96b  jmp 0x000072F45ADCE752
000072f45adce970  vxorps xmm0, xmm1, xmm14
000072f45adce975  pextrw eax, xmm0, 0x03
000072f45adce97a  and eax, 0x7FF8
000072f45adce97f  cmp eax, 0x08
000072f45adce982  jnz 0x000072F45ADCE752
000072f45adce988  movq rax, xmm14
000072f45adce98d  shl rax, 0x0D
000072f45adce991  jbe 0x000072F45ADCE752
000072f45adce997  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adce99f  jmp 0x000072F45ADCE752
000072f45adce9a4  ucomisd xmm1, xmm14
000072f45adce9a9  jp 0x000072F45ADCE9B8
000072f45adce9ab  movaps xmm13, [0x000072F45A9FE030]
000072f45adce9b3  jmp 0x000072F45ADCE77F
000072f45adce9b8  vxorps xmm0, xmm1, xmm14
000072f45adce9bd  pextrw eax, xmm0, 0x03
000072f45adce9c2  and eax, 0x7FF8
000072f45adce9c7  cmp eax, 0x08
000072f45adce9ca  jnz 0x000072F45ADCE77F
000072f45adce9d0  movq rax, xmm14
000072f45adce9d5  shl rax, 0x0D
000072f45adce9d9  jbe 0x000072F45ADCE77F
000072f45adce9df  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adce9e7  jmp 0x000072F45ADCE77F
000072f45adce9ec  ucomisd xmm1, xmm14
000072f45adce9f1  jp 0x000072F45ADCEA00
000072f45adce9f3  movaps xmm13, [0x000072F45A9FE030]
000072f45adce9fb  jmp 0x000072F45ADCE7AC
000072f45adcea00  vxorps xmm0, xmm1, xmm14
000072f45adcea05  pextrw eax, xmm0, 0x03
000072f45adcea0a  and eax, 0x7FF8
000072f45adcea0f  cmp eax, 0x08
000072f45adcea12  jnz 0x000072F45ADCE7AC
000072f45adcea18  movq rax, xmm14
000072f45adcea1d  shl rax, 0x0D
000072f45adcea21  jbe 0x000072F45ADCE7AC
000072f45adcea27  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adcea2f  jmp 0x000072F45ADCE7AC
000072f45adcea34  ucomisd xmm1, xmm14
000072f45adcea39  jp 0x000072F45ADCEA48
000072f45adcea3b  movaps xmm13, [0x000072F45A9FE030]
000072f45adcea43  jmp 0x000072F45ADCE7D9
000072f45adcea48  vxorps xmm0, xmm1, xmm14
000072f45adcea4d  pextrw eax, xmm0, 0x03
000072f45adcea52  and eax, 0x7FF8
000072f45adcea57  cmp eax, 0x08
000072f45adcea5a  jnz 0x000072F45ADCE7D9
000072f45adcea60  movq rax, xmm14
000072f45adcea65  shl rax, 0x0D
000072f45adcea69  jbe 0x000072F45ADCE7D9
000072f45adcea6f  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adcea77  jmp 0x000072F45ADCE7D9
000072f45adcea7c  ucomisd xmm1, xmm14
000072f45adcea81  jp 0x000072F45ADCEA90
000072f45adcea83  movaps xmm13, [0x000072F45A9FE030]
000072f45adcea8b  jmp 0x000072F45ADCE806
000072f45adcea90  vxorps xmm0, xmm1, xmm14
000072f45adcea95  pextrw eax, xmm0, 0x03
000072f45adcea9a  and eax, 0x7FF8
000072f45adcea9f  cmp eax, 0x08
000072f45adceaa2  jnz 0x000072F45ADCE806
000072f45adceaa8  movq rax, xmm14
000072f45adceaad  shl rax, 0x0D
000072f45adceab1  jbe 0x000072F45ADCE806
000072f45adceab7  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adceabf  jmp 0x000072F45ADCE806
000072f45adceac4  ucomisd xmm1, xmm15
000072f45adceac9  jp 0x000072F45ADCEAD8
000072f45adceacb  movaps xmm14, [0x000072F45A9FE030]
000072f45adcead3  jmp 0x000072F45ADCE833
000072f45adcead8  vxorps xmm0, xmm1, xmm15
000072f45adceadd  pextrw eax, xmm0, 0x03
000072f45adceae2  and eax, 0x7FF8
000072f45adceae7  cmp eax, 0x08
000072f45adceaea  jnz 0x000072F45ADCE833
000072f45adceaf0  movq rax, xmm15
000072f45adceaf5  shl rax, 0x0D
000072f45adceaf9  jbe 0x000072F45ADCE833
000072f45adceaff  vorps xmm14, xmm15, [0x000072F45A9FE040]
000072f45adceb07  jmp 0x000072F45ADCE833
000072f45adceb0c  int3
000072f45adceb0d  nop [rax], eax
000072f45adceb10  movaps xmm1, [r15+0x110]
000072f45adceb18  movq rax, xmm1
000072f45adceb1d  movaps xmm1, [r15+0x120]
000072f45adceb25  movq r14, xmm1
000072f45adceb2a  vmovq xmm15, rax
000072f45adceb2f  vmovq xmm14, r14
000072f45adceb34  movaps xmm13, xmm15
000072f45adceb38  addsd xmm13, xmm14
000072f45adceb3d  ucomisd xmm13, xmm13
000072f45adceb42  jp 0x000072F45ADCED24
000072f45adceb48  movq xmm13, xmm13
000072f45adceb4d  movq rax, xmm13
000072f45adceb52  movq r14, xmm1
000072f45adceb57  vmovq xmm15, rax
000072f45adceb5c  vmovq xmm14, r14
000072f45adceb61  movaps xmm13, xmm15
000072f45adceb65  addsd xmm13, xmm14
000072f45adceb6a  ucomisd xmm13, xmm13
000072f45adceb6f  jp 0x000072F45ADCED6C
000072f45adceb75  movq xmm13, xmm13
000072f45adceb7a  movq rax, xmm13
000072f45adceb7f  movq r14, xmm1
000072f45adceb84  vmovq xmm15, rax
000072f45adceb89  vmovq xmm14, r14
000072f45adceb8e  movaps xmm13, xmm15
000072f45adceb92  addsd xmm13, xmm14
000072f45adceb97  ucomisd xmm13, xmm13
000072f45adceb9c  jp 0x000072F45ADCEDB4
000072f45adceba2  movq xmm13, xmm13
000072f45adceba7  movq rax, xmm13
000072f45adcebac  movq r14, xmm1
000072f45adcebb1  vmovq xmm15, rax
000072f45adcebb6  vmovq xmm14, r14
000072f45adcebbb  movaps xmm13, xmm15
000072f45adcebbf  addsd xmm13, xmm14
000072f45adcebc4  ucomisd xmm13, xmm13
000072f45adcebc9  jp 0x000072F45ADCEDFC
000072f45adcebcf  movq xmm13, xmm13
000072f45adcebd4  movq rax, xmm13
000072f45adcebd9  movq r14, xmm1
000072f45adcebde  vmovq xmm15, rax
000072f45adcebe3  vmovq xmm14, r14
000072f45adcebe8  movaps xmm13, xmm15
000072f45adcebec  addsd xmm13, xmm14
000072f45adcebf1  ucomisd xmm13, xmm13
000072f45adcebf6  jp 0x000072F45ADCEE44
000072f45adcebfc  movq xmm13, xmm13
000072f45adcec01  movq rax, xmm13
000072f45adcec06  movq r14, xmm1
000072f45adcec0b  vmovq xmm15, rax
000072f45adcec10  vmovq xmm14, r14
000072f45adcec15  movaps xmm13, xmm15
000072f45adcec19  addsd xmm13, xmm14
000072f45adcec1e  ucomisd xmm13, xmm13
000072f45adcec23  jp 0x000072F45ADCEE8C
000072f45adcec29  movq xmm13, xmm13
000072f45adcec2e  movq rax, xmm13
000072f45adcec33  movq r14, xmm1
000072f45adcec38  vmovq xmm15, rax
000072f45adcec3d  vmovq xmm14, r14
000072f45adcec42  movaps xmm13, xmm15
000072f45adcec46  addsd xmm13, xmm14
000072f45adcec4b  ucomisd xmm13, xmm13
000072f45adcec50  jp 0x000072F45ADCEED4
000072f45adcec56  movq xmm13, xmm13
000072f45adcec5b  movq rax, xmm13
000072f45adcec60  movq r14, xmm1
000072f45adcec65  vmovq xmm1, rax
000072f45adcec6a  vmovq xmm15, r14
000072f45adcec6f  movaps xmm14, xmm1
000072f45adcec73  addsd xmm14, xmm15
000072f45adcec78  ucomisd xmm14, xmm14
000072f45adcec7d  jp 0x000072F45ADCEF1C
000072f45adcec83  movq xmm14, xmm14
000072f45adcec88  movaps [r15+0x110], xmm14
000072f45adcec90  mov rax, [r15+0x08]
000072f45adcec94  mov [rsp+0x10], rax
000072f45adcec99  xor eax, eax
000072f45adcec9b  mov r14, [rsp+0x10]
000072f45adceca0  mov r12d, 0x01
000072f45adceca6  sub r14, r12
000072f45adceca9  cmc
000072f45adcecaa  lahf
000072f45adcecab  seto al
000072f45adcecae  mov [r15+0x108], eax
000072f45adcecb5  mov [r15+0x08], r14
000072f45adcecb9  mov eax, [r15+0x108]
000072f45adcecc0  sahf
000072f45adcecc1  jnz 0x000072F45ADCECF3
000072f45adcecc3  cmp dword ptr [r15+0x318], 0x00
000072f45adceccb  jz 0x000072F45ADCEF70
000072f45adcecd1  nop [rax+rax*1], ax
000072f45adcecda  nop [rax+rax*1], eax
000072f45adcece2  mov eax, 0x41006C
000072f45adcece7  mov [r15+0x100], rax
000072f45adcecee  jmp 0x000072F45ABFE110
000072f45adcecf3  cmp dword ptr [r15+0x318], 0x00
000072f45adcecfb  jz 0x000072F45ADCEB10
000072f45adced01  nop [rax+rax*1], ax
000072f45adced0a  nop [rax+rax*1], eax
000072f45adced12  mov eax, 0x410044
000072f45adced17  mov [r15+0x100], rax
000072f45adced1e  jmp 0x000072F45ABFE110
000072f45adced23  int3
000072f45adced24  ucomisd xmm15, xmm14
000072f45adced29  jp 0x000072F45ADCED38
000072f45adced2b  movaps xmm13, [0x000072F45A9FE030]
000072f45adced33  jmp 0x000072F45ADCEB48
000072f45adced38  vxorps xmm0, xmm15, xmm14
000072f45adced3d  pextrw eax, xmm0, 0x03
000072f45adced42  and eax, 0x7FF8
000072f45adced47  cmp eax, 0x08
000072f45adced4a  jnz 0x000072F45ADCEB48
000072f45adced50  movq rax, xmm14
000072f45adced55  shl rax, 0x0D
000072f45adced59  jbe 0x000072F45ADCEB48
000072f45adced5f  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adced67  jmp 0x000072F45ADCEB48
000072f45adced6c  ucomisd xmm15, xmm14
000072f45adced71  jp 0x000072F45ADCED80
000072f45adced73  movaps xmm13, [0x000072F45A9FE030]
000072f45adced7b  jmp 0x000072F45ADCEB75
000072f45adced80  vxorps xmm0, xmm15, xmm14
000072f45adced85  pextrw eax, xmm0, 0x03
000072f45adced8a  and eax, 0x7FF8
000072f45adced8f  cmp eax, 0x08
000072f45adced92  jnz 0x000072F45ADCEB75
000072f45adced98  movq rax, xmm14
000072f45adced9d  shl rax, 0x0D
000072f45adceda1  jbe 0x000072F45ADCEB75
000072f45adceda7  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adcedaf  jmp 0x000072F45ADCEB75
000072f45adcedb4  ucomisd xmm15, xmm14
000072f45adcedb9  jp 0x000072F45ADCEDC8
000072f45adcedbb  movaps xmm13, [0x000072F45A9FE030]
000072f45adcedc3  jmp 0x000072F45ADCEBA2
000072f45adcedc8  vxorps xmm0, xmm15, xmm14
000072f45adcedcd  pextrw eax, xmm0, 0x03
000072f45adcedd2  and eax, 0x7FF8
000072f45adcedd7  cmp eax, 0x08
000072f45adcedda  jnz 0x000072F45ADCEBA2
000072f45adcede0  movq rax, xmm14
000072f45adcede5  shl rax, 0x0D
000072f45adcede9  jbe 0x000072F45ADCEBA2
000072f45adcedef  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adcedf7  jmp 0x000072F45ADCEBA2
000072f45adcedfc  ucomisd xmm15, xmm14
000072f45adcee01  jp 0x000072F45ADCEE10
000072f45adcee03  movaps xmm13, [0x000072F45A9FE030]
000072f45adcee0b  jmp 0x000072F45ADCEBCF
000072f45adcee10  vxorps xmm0, xmm15, xmm14
000072f45adcee15  pextrw eax, xmm0, 0x03
000072f45adcee1a  and eax, 0x7FF8
000072f45adcee1f  cmp eax, 0x08
000072f45adcee22  jnz 0x000072F45ADCEBCF
000072f45adcee28  movq rax, xmm14
000072f45adcee2d  shl rax, 0x0D
000072f45adcee31  jbe 0x000072F45ADCEBCF
000072f45adcee37  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adcee3f  jmp 0x000072F45ADCEBCF
000072f45adcee44  ucomisd xmm15, xmm14
000072f45adcee49  jp 0x000072F45ADCEE58
000072f45adcee4b  movaps xmm13, [0x000072F45A9FE030]
000072f45adcee53  jmp 0x000072F45ADCEBFC
000072f45adcee58  vxorps xmm0, xmm15, xmm14
000072f45adcee5d  pextrw eax, xmm0, 0x03
000072f45adcee62  and eax, 0x7FF8
000072f45adcee67  cmp eax, 0x08
000072f45adcee6a  jnz 0x000072F45ADCEBFC
000072f45adcee70  movq rax, xmm14
000072f45adcee75  shl rax, 0x0D
000072f45adcee79  jbe 0x000072F45ADCEBFC
000072f45adcee7f  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adcee87  jmp 0x000072F45ADCEBFC
000072f45adcee8c  ucomisd xmm15, xmm14
000072f45adcee91  jp 0x000072F45ADCEEA0
000072f45adcee93  movaps xmm13, [0x000072F45A9FE030]
000072f45adcee9b  jmp 0x000072F45ADCEC29
000072f45adceea0  vxorps xmm0, xmm15, xmm14
000072f45adceea5  pextrw eax, xmm0, 0x03
000072f45adceeaa  and eax, 0x7FF8
000072f45adceeaf  cmp eax, 0x08
000072f45adceeb2  jnz 0x000072F45ADCEC29
000072f45adceeb8  movq rax, xmm14
000072f45adceebd  shl rax, 0x0D
000072f45adceec1  jbe 0x000072F45ADCEC29
000072f45adceec7  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adceecf  jmp 0x000072F45ADCEC29
000072f45adceed4  ucomisd xmm15, xmm14
000072f45adceed9  jp 0x000072F45ADCEEE8
000072f45adceedb  movaps xmm13, [0x000072F45A9FE030]
000072f45adceee3  jmp 0x000072F45ADCEC56
000072f45adceee8  vxorps xmm0, xmm15, xmm14
000072f45adceeed  pextrw eax, xmm0, 0x03
000072f45adceef2  and eax, 0x7FF8
000072f45adceef7  cmp eax, 0x08
000072f45adceefa  jnz 0x000072F45ADCEC56
000072f45adcef00  movq rax, xmm14
000072f45adcef05  shl rax, 0x0D
000072f45adcef09  jbe 0x000072F45ADCEC56
000072f45adcef0f  vorps xmm13, xmm14, [0x000072F45A9FE040]
000072f45adcef17  jmp 0x000072F45ADCEC56
000072f45adcef1c  ucomisd xmm1, xmm15
000072f45adcef21  jp 0x000072F45ADCEF30
000072f45adcef23  movaps xmm14, [0x000072F45A9FE030]
000072f45adcef2b  jmp 0x000072F45ADCEC83
000072f45adcef30  vxorps xmm0, xmm1, xmm15
000072f45adcef35  pextrw eax, xmm0, 0x03
000072f45adcef3a  and eax, 0x7FF8
000072f45adcef3f  cmp eax, 0x08
000072f45adcef42  jnz 0x000072F45ADCEC83
000072f45adcef48  movq rax, xmm15
000072f45adcef4d  shl rax, 0x0D
000072f45adcef51  jbe 0x000072F45ADCEC83
000072f45adcef57  vorps xmm14, xmm15, [0x000072F45A9FE040]
000072f45adcef5f  jmp 0x000072F45ADCEC83
000072f45adcef64  int3
000072f45adcef65  nop [rax+rax*1], ax
000072f45adcef6e  nop
000072f45adcef70  mov rax, [r15+0x20]
000072f45adcef74  movaps xmm1, [r15+0x110]
000072f45adcef7c  movq r14, xmm1
000072f45adcef81  mov [r13+rax*1], r14
000072f45adcef86  mov rax, [r15+0xF0]
000072f45adcef8d  mov [r15+0x100], rax
000072f45adcef94  jmp 0x000072F45ADCE5C0
000072f45adcef99  int3
000072f45adcef9a  call 0x000072F45AC0E120
000072f45adcef9f  jmp 0x000072F45ADCEF86
000072f45adcefa4  int3
000072f45adcefa5  nop [rax+rax*1], ax
000072f45adcefae  nop
000072f45adcefb0  mov qword ptr [r15+0x100], 0x04
000072f45adcefbb  mov esi, 0x00
000072f45adcefc0  mov edx, 0x09
000072f45adcefc5  mov rdi, 0x7FFC57D72D30
000072f45adcefcf  mov rax, 0x5F5BC4403970
000072f45adcefd9  call rax
000072f45adcefdb  cmp dword ptr [r15+0x318], 0x00
000072f45adcefe3  jnz 0x000072F45ABFE110
000072f45adcefe9  jmp 0x000072F45ABFE0A0
000072f45adcefee  int3
000072f45adcefef  int3
