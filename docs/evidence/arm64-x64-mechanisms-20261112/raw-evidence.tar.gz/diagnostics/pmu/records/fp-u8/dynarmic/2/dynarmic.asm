00007717ebdce69b  nop [rax+rax*1], eax
00007717ebdce6a0  mov qword ptr [r15+0x20], 0x420080
00007717ebdce6a8  mov qword ptr [r15], 0x00
00007717ebdce6af  vmovaps xmm1, [0x00007717EB9FE010]
00007717ebdce6b7  movq xmm1, xmm1
00007717ebdce6bb  vmovaps xmm15, [0x00007717EB9FE020]
00007717ebdce6c3  movq xmm15, xmm15
00007717ebdce6c8  movaps [r15+0x120], xmm15
00007717ebdce6d0  movq rax, xmm1
00007717ebdce6d5  movq r14, xmm15
00007717ebdce6da  vmovq xmm1, rax
00007717ebdce6df  vmovq xmm14, r14
00007717ebdce6e4  movaps xmm13, xmm1
00007717ebdce6e8  addsd xmm13, xmm14
00007717ebdce6ed  ucomisd xmm13, xmm13
00007717ebdce6f2  jp 0x00007717EBDCE8CC
00007717ebdce6f8  movq xmm13, xmm13
00007717ebdce6fd  movq rax, xmm13
00007717ebdce702  movq r14, xmm15
00007717ebdce707  vmovq xmm1, rax
00007717ebdce70c  vmovq xmm14, r14
00007717ebdce711  movaps xmm13, xmm1
00007717ebdce715  addsd xmm13, xmm14
00007717ebdce71a  ucomisd xmm13, xmm13
00007717ebdce71f  jp 0x00007717EBDCE914
00007717ebdce725  movq xmm13, xmm13
00007717ebdce72a  movq rax, xmm13
00007717ebdce72f  movq r14, xmm15
00007717ebdce734  vmovq xmm1, rax
00007717ebdce739  vmovq xmm14, r14
00007717ebdce73e  movaps xmm13, xmm1
00007717ebdce742  addsd xmm13, xmm14
00007717ebdce747  ucomisd xmm13, xmm13
00007717ebdce74c  jp 0x00007717EBDCE95C
00007717ebdce752  movq xmm13, xmm13
00007717ebdce757  movq rax, xmm13
00007717ebdce75c  movq r14, xmm15
00007717ebdce761  vmovq xmm1, rax
00007717ebdce766  vmovq xmm14, r14
00007717ebdce76b  movaps xmm13, xmm1
00007717ebdce76f  addsd xmm13, xmm14
00007717ebdce774  ucomisd xmm13, xmm13
00007717ebdce779  jp 0x00007717EBDCE9A4
00007717ebdce77f  movq xmm13, xmm13
00007717ebdce784  movq rax, xmm13
00007717ebdce789  movq r14, xmm15
00007717ebdce78e  vmovq xmm1, rax
00007717ebdce793  vmovq xmm14, r14
00007717ebdce798  movaps xmm13, xmm1
00007717ebdce79c  addsd xmm13, xmm14
00007717ebdce7a1  ucomisd xmm13, xmm13
00007717ebdce7a6  jp 0x00007717EBDCE9EC
00007717ebdce7ac  movq xmm13, xmm13
00007717ebdce7b1  movq rax, xmm13
00007717ebdce7b6  movq r14, xmm15
00007717ebdce7bb  vmovq xmm1, rax
00007717ebdce7c0  vmovq xmm14, r14
00007717ebdce7c5  movaps xmm13, xmm1
00007717ebdce7c9  addsd xmm13, xmm14
00007717ebdce7ce  ucomisd xmm13, xmm13
00007717ebdce7d3  jp 0x00007717EBDCEA34
00007717ebdce7d9  movq xmm13, xmm13
00007717ebdce7de  movq rax, xmm13
00007717ebdce7e3  movq r14, xmm15
00007717ebdce7e8  vmovq xmm1, rax
00007717ebdce7ed  vmovq xmm14, r14
00007717ebdce7f2  movaps xmm13, xmm1
00007717ebdce7f6  addsd xmm13, xmm14
00007717ebdce7fb  ucomisd xmm13, xmm13
00007717ebdce800  jp 0x00007717EBDCEA7C
00007717ebdce806  movq xmm13, xmm13
00007717ebdce80b  movq rax, xmm13
00007717ebdce810  movq r14, xmm15
00007717ebdce815  vmovq xmm1, rax
00007717ebdce81a  vmovq xmm15, r14
00007717ebdce81f  movaps xmm14, xmm1
00007717ebdce823  addsd xmm14, xmm15
00007717ebdce828  ucomisd xmm14, xmm14
00007717ebdce82d  jp 0x00007717EBDCEAC4
00007717ebdce833  movq xmm14, xmm14
00007717ebdce838  movaps [r15+0x110], xmm14
00007717ebdce840  xor eax, eax
00007717ebdce842  mov r14d, 0x1E848
00007717ebdce848  mov r12d, 0x01
00007717ebdce84e  sub r14, r12
00007717ebdce851  cmc
00007717ebdce852  lahf
00007717ebdce853  seto al
00007717ebdce856  mov [r15+0x108], eax
00007717ebdce85d  mov [r15+0x08], r14
00007717ebdce861  mov eax, [r15+0x108]
00007717ebdce868  sahf
00007717ebdce869  jnz 0x00007717EBDCE89B
00007717ebdce86b  cmp dword ptr [r15+0x318], 0x00
00007717ebdce873  jz 0x00007717EBDCEF70
00007717ebdce879  nop [rax+rax*1], ax
00007717ebdce882  nop [rax+rax*1], eax
00007717ebdce88a  mov eax, 0x41006C
00007717ebdce88f  mov [r15+0x100], rax
00007717ebdce896  jmp 0x00007717EBBFE110
00007717ebdce89b  cmp dword ptr [r15+0x318], 0x00
00007717ebdce8a3  jz 0x00007717EBDCEB10
00007717ebdce8a9  nop [rax+rax*1], ax
00007717ebdce8b2  nop [rax+rax*1], eax
00007717ebdce8ba  mov eax, 0x410044
00007717ebdce8bf  mov [r15+0x100], rax
00007717ebdce8c6  jmp 0x00007717EBBFE110
00007717ebdce8cb  int3
00007717ebdce8cc  ucomisd xmm1, xmm14
00007717ebdce8d1  jp 0x00007717EBDCE8E0
00007717ebdce8d3  movaps xmm13, [0x00007717EB9FE030]
00007717ebdce8db  jmp 0x00007717EBDCE6F8
00007717ebdce8e0  vxorps xmm0, xmm1, xmm14
00007717ebdce8e5  pextrw eax, xmm0, 0x03
00007717ebdce8ea  and eax, 0x7FF8
00007717ebdce8ef  cmp eax, 0x08
00007717ebdce8f2  jnz 0x00007717EBDCE6F8
00007717ebdce8f8  movq rax, xmm14
00007717ebdce8fd  shl rax, 0x0D
00007717ebdce901  jbe 0x00007717EBDCE6F8
00007717ebdce907  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdce90f  jmp 0x00007717EBDCE6F8
00007717ebdce914  ucomisd xmm1, xmm14
00007717ebdce919  jp 0x00007717EBDCE928
00007717ebdce91b  movaps xmm13, [0x00007717EB9FE030]
00007717ebdce923  jmp 0x00007717EBDCE725
00007717ebdce928  vxorps xmm0, xmm1, xmm14
00007717ebdce92d  pextrw eax, xmm0, 0x03
00007717ebdce932  and eax, 0x7FF8
00007717ebdce937  cmp eax, 0x08
00007717ebdce93a  jnz 0x00007717EBDCE725
00007717ebdce940  movq rax, xmm14
00007717ebdce945  shl rax, 0x0D
00007717ebdce949  jbe 0x00007717EBDCE725
00007717ebdce94f  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdce957  jmp 0x00007717EBDCE725
00007717ebdce95c  ucomisd xmm1, xmm14
00007717ebdce961  jp 0x00007717EBDCE970
00007717ebdce963  movaps xmm13, [0x00007717EB9FE030]
00007717ebdce96b  jmp 0x00007717EBDCE752
00007717ebdce970  vxorps xmm0, xmm1, xmm14
00007717ebdce975  pextrw eax, xmm0, 0x03
00007717ebdce97a  and eax, 0x7FF8
00007717ebdce97f  cmp eax, 0x08
00007717ebdce982  jnz 0x00007717EBDCE752
00007717ebdce988  movq rax, xmm14
00007717ebdce98d  shl rax, 0x0D
00007717ebdce991  jbe 0x00007717EBDCE752
00007717ebdce997  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdce99f  jmp 0x00007717EBDCE752
00007717ebdce9a4  ucomisd xmm1, xmm14
00007717ebdce9a9  jp 0x00007717EBDCE9B8
00007717ebdce9ab  movaps xmm13, [0x00007717EB9FE030]
00007717ebdce9b3  jmp 0x00007717EBDCE77F
00007717ebdce9b8  vxorps xmm0, xmm1, xmm14
00007717ebdce9bd  pextrw eax, xmm0, 0x03
00007717ebdce9c2  and eax, 0x7FF8
00007717ebdce9c7  cmp eax, 0x08
00007717ebdce9ca  jnz 0x00007717EBDCE77F
00007717ebdce9d0  movq rax, xmm14
00007717ebdce9d5  shl rax, 0x0D
00007717ebdce9d9  jbe 0x00007717EBDCE77F
00007717ebdce9df  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdce9e7  jmp 0x00007717EBDCE77F
00007717ebdce9ec  ucomisd xmm1, xmm14
00007717ebdce9f1  jp 0x00007717EBDCEA00
00007717ebdce9f3  movaps xmm13, [0x00007717EB9FE030]
00007717ebdce9fb  jmp 0x00007717EBDCE7AC
00007717ebdcea00  vxorps xmm0, xmm1, xmm14
00007717ebdcea05  pextrw eax, xmm0, 0x03
00007717ebdcea0a  and eax, 0x7FF8
00007717ebdcea0f  cmp eax, 0x08
00007717ebdcea12  jnz 0x00007717EBDCE7AC
00007717ebdcea18  movq rax, xmm14
00007717ebdcea1d  shl rax, 0x0D
00007717ebdcea21  jbe 0x00007717EBDCE7AC
00007717ebdcea27  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdcea2f  jmp 0x00007717EBDCE7AC
00007717ebdcea34  ucomisd xmm1, xmm14
00007717ebdcea39  jp 0x00007717EBDCEA48
00007717ebdcea3b  movaps xmm13, [0x00007717EB9FE030]
00007717ebdcea43  jmp 0x00007717EBDCE7D9
00007717ebdcea48  vxorps xmm0, xmm1, xmm14
00007717ebdcea4d  pextrw eax, xmm0, 0x03
00007717ebdcea52  and eax, 0x7FF8
00007717ebdcea57  cmp eax, 0x08
00007717ebdcea5a  jnz 0x00007717EBDCE7D9
00007717ebdcea60  movq rax, xmm14
00007717ebdcea65  shl rax, 0x0D
00007717ebdcea69  jbe 0x00007717EBDCE7D9
00007717ebdcea6f  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdcea77  jmp 0x00007717EBDCE7D9
00007717ebdcea7c  ucomisd xmm1, xmm14
00007717ebdcea81  jp 0x00007717EBDCEA90
00007717ebdcea83  movaps xmm13, [0x00007717EB9FE030]
00007717ebdcea8b  jmp 0x00007717EBDCE806
00007717ebdcea90  vxorps xmm0, xmm1, xmm14
00007717ebdcea95  pextrw eax, xmm0, 0x03
00007717ebdcea9a  and eax, 0x7FF8
00007717ebdcea9f  cmp eax, 0x08
00007717ebdceaa2  jnz 0x00007717EBDCE806
00007717ebdceaa8  movq rax, xmm14
00007717ebdceaad  shl rax, 0x0D
00007717ebdceab1  jbe 0x00007717EBDCE806
00007717ebdceab7  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdceabf  jmp 0x00007717EBDCE806
00007717ebdceac4  ucomisd xmm1, xmm15
00007717ebdceac9  jp 0x00007717EBDCEAD8
00007717ebdceacb  movaps xmm14, [0x00007717EB9FE030]
00007717ebdcead3  jmp 0x00007717EBDCE833
00007717ebdcead8  vxorps xmm0, xmm1, xmm15
00007717ebdceadd  pextrw eax, xmm0, 0x03
00007717ebdceae2  and eax, 0x7FF8
00007717ebdceae7  cmp eax, 0x08
00007717ebdceaea  jnz 0x00007717EBDCE833
00007717ebdceaf0  movq rax, xmm15
00007717ebdceaf5  shl rax, 0x0D
00007717ebdceaf9  jbe 0x00007717EBDCE833
00007717ebdceaff  vorps xmm14, xmm15, [0x00007717EB9FE040]
00007717ebdceb07  jmp 0x00007717EBDCE833
00007717ebdceb0c  int3
00007717ebdceb0d  nop [rax], eax
00007717ebdceb10  movaps xmm1, [r15+0x110]
00007717ebdceb18  movq rax, xmm1
00007717ebdceb1d  movaps xmm1, [r15+0x120]
00007717ebdceb25  movq r14, xmm1
00007717ebdceb2a  vmovq xmm15, rax
00007717ebdceb2f  vmovq xmm14, r14
00007717ebdceb34  movaps xmm13, xmm15
00007717ebdceb38  addsd xmm13, xmm14
00007717ebdceb3d  ucomisd xmm13, xmm13
00007717ebdceb42  jp 0x00007717EBDCED24
00007717ebdceb48  movq xmm13, xmm13
00007717ebdceb4d  movq rax, xmm13
00007717ebdceb52  movq r14, xmm1
00007717ebdceb57  vmovq xmm15, rax
00007717ebdceb5c  vmovq xmm14, r14
00007717ebdceb61  movaps xmm13, xmm15
00007717ebdceb65  addsd xmm13, xmm14
00007717ebdceb6a  ucomisd xmm13, xmm13
00007717ebdceb6f  jp 0x00007717EBDCED6C
00007717ebdceb75  movq xmm13, xmm13
00007717ebdceb7a  movq rax, xmm13
00007717ebdceb7f  movq r14, xmm1
00007717ebdceb84  vmovq xmm15, rax
00007717ebdceb89  vmovq xmm14, r14
00007717ebdceb8e  movaps xmm13, xmm15
00007717ebdceb92  addsd xmm13, xmm14
00007717ebdceb97  ucomisd xmm13, xmm13
00007717ebdceb9c  jp 0x00007717EBDCEDB4
00007717ebdceba2  movq xmm13, xmm13
00007717ebdceba7  movq rax, xmm13
00007717ebdcebac  movq r14, xmm1
00007717ebdcebb1  vmovq xmm15, rax
00007717ebdcebb6  vmovq xmm14, r14
00007717ebdcebbb  movaps xmm13, xmm15
00007717ebdcebbf  addsd xmm13, xmm14
00007717ebdcebc4  ucomisd xmm13, xmm13
00007717ebdcebc9  jp 0x00007717EBDCEDFC
00007717ebdcebcf  movq xmm13, xmm13
00007717ebdcebd4  movq rax, xmm13
00007717ebdcebd9  movq r14, xmm1
00007717ebdcebde  vmovq xmm15, rax
00007717ebdcebe3  vmovq xmm14, r14
00007717ebdcebe8  movaps xmm13, xmm15
00007717ebdcebec  addsd xmm13, xmm14
00007717ebdcebf1  ucomisd xmm13, xmm13
00007717ebdcebf6  jp 0x00007717EBDCEE44
00007717ebdcebfc  movq xmm13, xmm13
00007717ebdcec01  movq rax, xmm13
00007717ebdcec06  movq r14, xmm1
00007717ebdcec0b  vmovq xmm15, rax
00007717ebdcec10  vmovq xmm14, r14
00007717ebdcec15  movaps xmm13, xmm15
00007717ebdcec19  addsd xmm13, xmm14
00007717ebdcec1e  ucomisd xmm13, xmm13
00007717ebdcec23  jp 0x00007717EBDCEE8C
00007717ebdcec29  movq xmm13, xmm13
00007717ebdcec2e  movq rax, xmm13
00007717ebdcec33  movq r14, xmm1
00007717ebdcec38  vmovq xmm15, rax
00007717ebdcec3d  vmovq xmm14, r14
00007717ebdcec42  movaps xmm13, xmm15
00007717ebdcec46  addsd xmm13, xmm14
00007717ebdcec4b  ucomisd xmm13, xmm13
00007717ebdcec50  jp 0x00007717EBDCEED4
00007717ebdcec56  movq xmm13, xmm13
00007717ebdcec5b  movq rax, xmm13
00007717ebdcec60  movq r14, xmm1
00007717ebdcec65  vmovq xmm1, rax
00007717ebdcec6a  vmovq xmm15, r14
00007717ebdcec6f  movaps xmm14, xmm1
00007717ebdcec73  addsd xmm14, xmm15
00007717ebdcec78  ucomisd xmm14, xmm14
00007717ebdcec7d  jp 0x00007717EBDCEF1C
00007717ebdcec83  movq xmm14, xmm14
00007717ebdcec88  movaps [r15+0x110], xmm14
00007717ebdcec90  mov rax, [r15+0x08]
00007717ebdcec94  mov [rsp+0x10], rax
00007717ebdcec99  xor eax, eax
00007717ebdcec9b  mov r14, [rsp+0x10]
00007717ebdceca0  mov r12d, 0x01
00007717ebdceca6  sub r14, r12
00007717ebdceca9  cmc
00007717ebdcecaa  lahf
00007717ebdcecab  seto al
00007717ebdcecae  mov [r15+0x108], eax
00007717ebdcecb5  mov [r15+0x08], r14
00007717ebdcecb9  mov eax, [r15+0x108]
00007717ebdcecc0  sahf
00007717ebdcecc1  jnz 0x00007717EBDCECF3
00007717ebdcecc3  cmp dword ptr [r15+0x318], 0x00
00007717ebdceccb  jz 0x00007717EBDCEF70
00007717ebdcecd1  nop [rax+rax*1], ax
00007717ebdcecda  nop [rax+rax*1], eax
00007717ebdcece2  mov eax, 0x41006C
00007717ebdcece7  mov [r15+0x100], rax
00007717ebdcecee  jmp 0x00007717EBBFE110
00007717ebdcecf3  cmp dword ptr [r15+0x318], 0x00
00007717ebdcecfb  jz 0x00007717EBDCEB10
00007717ebdced01  nop [rax+rax*1], ax
00007717ebdced0a  nop [rax+rax*1], eax
00007717ebdced12  mov eax, 0x410044
00007717ebdced17  mov [r15+0x100], rax
00007717ebdced1e  jmp 0x00007717EBBFE110
00007717ebdced23  int3
00007717ebdced24  ucomisd xmm15, xmm14
00007717ebdced29  jp 0x00007717EBDCED38
00007717ebdced2b  movaps xmm13, [0x00007717EB9FE030]
00007717ebdced33  jmp 0x00007717EBDCEB48
00007717ebdced38  vxorps xmm0, xmm15, xmm14
00007717ebdced3d  pextrw eax, xmm0, 0x03
00007717ebdced42  and eax, 0x7FF8
00007717ebdced47  cmp eax, 0x08
00007717ebdced4a  jnz 0x00007717EBDCEB48
00007717ebdced50  movq rax, xmm14
00007717ebdced55  shl rax, 0x0D
00007717ebdced59  jbe 0x00007717EBDCEB48
00007717ebdced5f  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdced67  jmp 0x00007717EBDCEB48
00007717ebdced6c  ucomisd xmm15, xmm14
00007717ebdced71  jp 0x00007717EBDCED80
00007717ebdced73  movaps xmm13, [0x00007717EB9FE030]
00007717ebdced7b  jmp 0x00007717EBDCEB75
00007717ebdced80  vxorps xmm0, xmm15, xmm14
00007717ebdced85  pextrw eax, xmm0, 0x03
00007717ebdced8a  and eax, 0x7FF8
00007717ebdced8f  cmp eax, 0x08
00007717ebdced92  jnz 0x00007717EBDCEB75
00007717ebdced98  movq rax, xmm14
00007717ebdced9d  shl rax, 0x0D
00007717ebdceda1  jbe 0x00007717EBDCEB75
00007717ebdceda7  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdcedaf  jmp 0x00007717EBDCEB75
00007717ebdcedb4  ucomisd xmm15, xmm14
00007717ebdcedb9  jp 0x00007717EBDCEDC8
00007717ebdcedbb  movaps xmm13, [0x00007717EB9FE030]
00007717ebdcedc3  jmp 0x00007717EBDCEBA2
00007717ebdcedc8  vxorps xmm0, xmm15, xmm14
00007717ebdcedcd  pextrw eax, xmm0, 0x03
00007717ebdcedd2  and eax, 0x7FF8
00007717ebdcedd7  cmp eax, 0x08
00007717ebdcedda  jnz 0x00007717EBDCEBA2
00007717ebdcede0  movq rax, xmm14
00007717ebdcede5  shl rax, 0x0D
00007717ebdcede9  jbe 0x00007717EBDCEBA2
00007717ebdcedef  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdcedf7  jmp 0x00007717EBDCEBA2
00007717ebdcedfc  ucomisd xmm15, xmm14
00007717ebdcee01  jp 0x00007717EBDCEE10
00007717ebdcee03  movaps xmm13, [0x00007717EB9FE030]
00007717ebdcee0b  jmp 0x00007717EBDCEBCF
00007717ebdcee10  vxorps xmm0, xmm15, xmm14
00007717ebdcee15  pextrw eax, xmm0, 0x03
00007717ebdcee1a  and eax, 0x7FF8
00007717ebdcee1f  cmp eax, 0x08
00007717ebdcee22  jnz 0x00007717EBDCEBCF
00007717ebdcee28  movq rax, xmm14
00007717ebdcee2d  shl rax, 0x0D
00007717ebdcee31  jbe 0x00007717EBDCEBCF
00007717ebdcee37  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdcee3f  jmp 0x00007717EBDCEBCF
00007717ebdcee44  ucomisd xmm15, xmm14
00007717ebdcee49  jp 0x00007717EBDCEE58
00007717ebdcee4b  movaps xmm13, [0x00007717EB9FE030]
00007717ebdcee53  jmp 0x00007717EBDCEBFC
00007717ebdcee58  vxorps xmm0, xmm15, xmm14
00007717ebdcee5d  pextrw eax, xmm0, 0x03
00007717ebdcee62  and eax, 0x7FF8
00007717ebdcee67  cmp eax, 0x08
00007717ebdcee6a  jnz 0x00007717EBDCEBFC
00007717ebdcee70  movq rax, xmm14
00007717ebdcee75  shl rax, 0x0D
00007717ebdcee79  jbe 0x00007717EBDCEBFC
00007717ebdcee7f  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdcee87  jmp 0x00007717EBDCEBFC
00007717ebdcee8c  ucomisd xmm15, xmm14
00007717ebdcee91  jp 0x00007717EBDCEEA0
00007717ebdcee93  movaps xmm13, [0x00007717EB9FE030]
00007717ebdcee9b  jmp 0x00007717EBDCEC29
00007717ebdceea0  vxorps xmm0, xmm15, xmm14
00007717ebdceea5  pextrw eax, xmm0, 0x03
00007717ebdceeaa  and eax, 0x7FF8
00007717ebdceeaf  cmp eax, 0x08
00007717ebdceeb2  jnz 0x00007717EBDCEC29
00007717ebdceeb8  movq rax, xmm14
00007717ebdceebd  shl rax, 0x0D
00007717ebdceec1  jbe 0x00007717EBDCEC29
00007717ebdceec7  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdceecf  jmp 0x00007717EBDCEC29
00007717ebdceed4  ucomisd xmm15, xmm14
00007717ebdceed9  jp 0x00007717EBDCEEE8
00007717ebdceedb  movaps xmm13, [0x00007717EB9FE030]
00007717ebdceee3  jmp 0x00007717EBDCEC56
00007717ebdceee8  vxorps xmm0, xmm15, xmm14
00007717ebdceeed  pextrw eax, xmm0, 0x03
00007717ebdceef2  and eax, 0x7FF8
00007717ebdceef7  cmp eax, 0x08
00007717ebdceefa  jnz 0x00007717EBDCEC56
00007717ebdcef00  movq rax, xmm14
00007717ebdcef05  shl rax, 0x0D
00007717ebdcef09  jbe 0x00007717EBDCEC56
00007717ebdcef0f  vorps xmm13, xmm14, [0x00007717EB9FE040]
00007717ebdcef17  jmp 0x00007717EBDCEC56
00007717ebdcef1c  ucomisd xmm1, xmm15
00007717ebdcef21  jp 0x00007717EBDCEF30
00007717ebdcef23  movaps xmm14, [0x00007717EB9FE030]
00007717ebdcef2b  jmp 0x00007717EBDCEC83
00007717ebdcef30  vxorps xmm0, xmm1, xmm15
00007717ebdcef35  pextrw eax, xmm0, 0x03
00007717ebdcef3a  and eax, 0x7FF8
00007717ebdcef3f  cmp eax, 0x08
00007717ebdcef42  jnz 0x00007717EBDCEC83
00007717ebdcef48  movq rax, xmm15
00007717ebdcef4d  shl rax, 0x0D
00007717ebdcef51  jbe 0x00007717EBDCEC83
00007717ebdcef57  vorps xmm14, xmm15, [0x00007717EB9FE040]
00007717ebdcef5f  jmp 0x00007717EBDCEC83
00007717ebdcef64  int3
00007717ebdcef65  nop [rax+rax*1], ax
00007717ebdcef6e  nop
00007717ebdcef70  mov rax, [r15+0x20]
00007717ebdcef74  movaps xmm1, [r15+0x110]
00007717ebdcef7c  movq r14, xmm1
00007717ebdcef81  mov [r13+rax*1], r14
00007717ebdcef86  mov rax, [r15+0xF0]
00007717ebdcef8d  mov [r15+0x100], rax
00007717ebdcef94  jmp 0x00007717EBDCE5C0
00007717ebdcef99  int3
00007717ebdcef9a  call 0x00007717EBC0E120
00007717ebdcef9f  jmp 0x00007717EBDCEF86
00007717ebdcefa4  int3
00007717ebdcefa5  nop [rax+rax*1], ax
00007717ebdcefae  nop
00007717ebdcefb0  mov qword ptr [r15+0x100], 0x04
00007717ebdcefbb  mov esi, 0x00
00007717ebdcefc0  mov edx, 0x09
00007717ebdcefc5  mov rdi, 0x7FFE0D9D6710
00007717ebdcefcf  mov rax, 0x5F6E91F79970
00007717ebdcefd9  call rax
00007717ebdcefdb  cmp dword ptr [r15+0x318], 0x00
00007717ebdcefe3  jnz 0x00007717EBBFE110
00007717ebdcefe9  jmp 0x00007717EBBFE0A0
00007717ebdcefee  int3
00007717ebdcefef  int3
