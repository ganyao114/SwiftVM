000072c8a33ce69b  nop [rax+rax*1], eax
000072c8a33ce6a0  mov qword ptr [r15+0x20], 0x420080
000072c8a33ce6a8  mov qword ptr [r15], 0x00
000072c8a33ce6af  vmovaps xmm1, [0x000072C8A2FFE010]
000072c8a33ce6b7  movq xmm1, xmm1
000072c8a33ce6bb  vmovaps xmm15, [0x000072C8A2FFE020]
000072c8a33ce6c3  movq xmm15, xmm15
000072c8a33ce6c8  movaps [r15+0x120], xmm15
000072c8a33ce6d0  movq rax, xmm1
000072c8a33ce6d5  movq r14, xmm15
000072c8a33ce6da  vmovq xmm1, rax
000072c8a33ce6df  vmovq xmm14, r14
000072c8a33ce6e4  movaps xmm13, xmm1
000072c8a33ce6e8  addsd xmm13, xmm14
000072c8a33ce6ed  ucomisd xmm13, xmm13
000072c8a33ce6f2  jp 0x000072C8A33CE8CC
000072c8a33ce6f8  movq xmm13, xmm13
000072c8a33ce6fd  movq rax, xmm13
000072c8a33ce702  movq r14, xmm15
000072c8a33ce707  vmovq xmm1, rax
000072c8a33ce70c  vmovq xmm14, r14
000072c8a33ce711  movaps xmm13, xmm1
000072c8a33ce715  addsd xmm13, xmm14
000072c8a33ce71a  ucomisd xmm13, xmm13
000072c8a33ce71f  jp 0x000072C8A33CE914
000072c8a33ce725  movq xmm13, xmm13
000072c8a33ce72a  movq rax, xmm13
000072c8a33ce72f  movq r14, xmm15
000072c8a33ce734  vmovq xmm1, rax
000072c8a33ce739  vmovq xmm14, r14
000072c8a33ce73e  movaps xmm13, xmm1
000072c8a33ce742  addsd xmm13, xmm14
000072c8a33ce747  ucomisd xmm13, xmm13
000072c8a33ce74c  jp 0x000072C8A33CE95C
000072c8a33ce752  movq xmm13, xmm13
000072c8a33ce757  movq rax, xmm13
000072c8a33ce75c  movq r14, xmm15
000072c8a33ce761  vmovq xmm1, rax
000072c8a33ce766  vmovq xmm14, r14
000072c8a33ce76b  movaps xmm13, xmm1
000072c8a33ce76f  addsd xmm13, xmm14
000072c8a33ce774  ucomisd xmm13, xmm13
000072c8a33ce779  jp 0x000072C8A33CE9A4
000072c8a33ce77f  movq xmm13, xmm13
000072c8a33ce784  movq rax, xmm13
000072c8a33ce789  movq r14, xmm15
000072c8a33ce78e  vmovq xmm1, rax
000072c8a33ce793  vmovq xmm14, r14
000072c8a33ce798  movaps xmm13, xmm1
000072c8a33ce79c  addsd xmm13, xmm14
000072c8a33ce7a1  ucomisd xmm13, xmm13
000072c8a33ce7a6  jp 0x000072C8A33CE9EC
000072c8a33ce7ac  movq xmm13, xmm13
000072c8a33ce7b1  movq rax, xmm13
000072c8a33ce7b6  movq r14, xmm15
000072c8a33ce7bb  vmovq xmm1, rax
000072c8a33ce7c0  vmovq xmm14, r14
000072c8a33ce7c5  movaps xmm13, xmm1
000072c8a33ce7c9  addsd xmm13, xmm14
000072c8a33ce7ce  ucomisd xmm13, xmm13
000072c8a33ce7d3  jp 0x000072C8A33CEA34
000072c8a33ce7d9  movq xmm13, xmm13
000072c8a33ce7de  movq rax, xmm13
000072c8a33ce7e3  movq r14, xmm15
000072c8a33ce7e8  vmovq xmm1, rax
000072c8a33ce7ed  vmovq xmm14, r14
000072c8a33ce7f2  movaps xmm13, xmm1
000072c8a33ce7f6  addsd xmm13, xmm14
000072c8a33ce7fb  ucomisd xmm13, xmm13
000072c8a33ce800  jp 0x000072C8A33CEA7C
000072c8a33ce806  movq xmm13, xmm13
000072c8a33ce80b  movq rax, xmm13
000072c8a33ce810  movq r14, xmm15
000072c8a33ce815  vmovq xmm1, rax
000072c8a33ce81a  vmovq xmm15, r14
000072c8a33ce81f  movaps xmm14, xmm1
000072c8a33ce823  addsd xmm14, xmm15
000072c8a33ce828  ucomisd xmm14, xmm14
000072c8a33ce82d  jp 0x000072C8A33CEAC4
000072c8a33ce833  movq xmm14, xmm14
000072c8a33ce838  movaps [r15+0x110], xmm14
000072c8a33ce840  xor eax, eax
000072c8a33ce842  mov r14d, 0x1E848
000072c8a33ce848  mov r12d, 0x01
000072c8a33ce84e  sub r14, r12
000072c8a33ce851  cmc
000072c8a33ce852  lahf
000072c8a33ce853  seto al
000072c8a33ce856  mov [r15+0x108], eax
000072c8a33ce85d  mov [r15+0x08], r14
000072c8a33ce861  mov eax, [r15+0x108]
000072c8a33ce868  sahf
000072c8a33ce869  jnz 0x000072C8A33CE89B
000072c8a33ce86b  cmp dword ptr [r15+0x318], 0x00
000072c8a33ce873  jz 0x000072C8A33CEF70
000072c8a33ce879  nop [rax+rax*1], ax
000072c8a33ce882  nop [rax+rax*1], eax
000072c8a33ce88a  mov eax, 0x41006C
000072c8a33ce88f  mov [r15+0x100], rax
000072c8a33ce896  jmp 0x000072C8A31FE110
000072c8a33ce89b  cmp dword ptr [r15+0x318], 0x00
000072c8a33ce8a3  jz 0x000072C8A33CEB10
000072c8a33ce8a9  nop [rax+rax*1], ax
000072c8a33ce8b2  nop [rax+rax*1], eax
000072c8a33ce8ba  mov eax, 0x410044
000072c8a33ce8bf  mov [r15+0x100], rax
000072c8a33ce8c6  jmp 0x000072C8A31FE110
000072c8a33ce8cb  int3
000072c8a33ce8cc  ucomisd xmm1, xmm14
000072c8a33ce8d1  jp 0x000072C8A33CE8E0
000072c8a33ce8d3  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33ce8db  jmp 0x000072C8A33CE6F8
000072c8a33ce8e0  vxorps xmm0, xmm1, xmm14
000072c8a33ce8e5  pextrw eax, xmm0, 0x03
000072c8a33ce8ea  and eax, 0x7FF8
000072c8a33ce8ef  cmp eax, 0x08
000072c8a33ce8f2  jnz 0x000072C8A33CE6F8
000072c8a33ce8f8  movq rax, xmm14
000072c8a33ce8fd  shl rax, 0x0D
000072c8a33ce901  jbe 0x000072C8A33CE6F8
000072c8a33ce907  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33ce90f  jmp 0x000072C8A33CE6F8
000072c8a33ce914  ucomisd xmm1, xmm14
000072c8a33ce919  jp 0x000072C8A33CE928
000072c8a33ce91b  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33ce923  jmp 0x000072C8A33CE725
000072c8a33ce928  vxorps xmm0, xmm1, xmm14
000072c8a33ce92d  pextrw eax, xmm0, 0x03
000072c8a33ce932  and eax, 0x7FF8
000072c8a33ce937  cmp eax, 0x08
000072c8a33ce93a  jnz 0x000072C8A33CE725
000072c8a33ce940  movq rax, xmm14
000072c8a33ce945  shl rax, 0x0D
000072c8a33ce949  jbe 0x000072C8A33CE725
000072c8a33ce94f  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33ce957  jmp 0x000072C8A33CE725
000072c8a33ce95c  ucomisd xmm1, xmm14
000072c8a33ce961  jp 0x000072C8A33CE970
000072c8a33ce963  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33ce96b  jmp 0x000072C8A33CE752
000072c8a33ce970  vxorps xmm0, xmm1, xmm14
000072c8a33ce975  pextrw eax, xmm0, 0x03
000072c8a33ce97a  and eax, 0x7FF8
000072c8a33ce97f  cmp eax, 0x08
000072c8a33ce982  jnz 0x000072C8A33CE752
000072c8a33ce988  movq rax, xmm14
000072c8a33ce98d  shl rax, 0x0D
000072c8a33ce991  jbe 0x000072C8A33CE752
000072c8a33ce997  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33ce99f  jmp 0x000072C8A33CE752
000072c8a33ce9a4  ucomisd xmm1, xmm14
000072c8a33ce9a9  jp 0x000072C8A33CE9B8
000072c8a33ce9ab  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33ce9b3  jmp 0x000072C8A33CE77F
000072c8a33ce9b8  vxorps xmm0, xmm1, xmm14
000072c8a33ce9bd  pextrw eax, xmm0, 0x03
000072c8a33ce9c2  and eax, 0x7FF8
000072c8a33ce9c7  cmp eax, 0x08
000072c8a33ce9ca  jnz 0x000072C8A33CE77F
000072c8a33ce9d0  movq rax, xmm14
000072c8a33ce9d5  shl rax, 0x0D
000072c8a33ce9d9  jbe 0x000072C8A33CE77F
000072c8a33ce9df  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33ce9e7  jmp 0x000072C8A33CE77F
000072c8a33ce9ec  ucomisd xmm1, xmm14
000072c8a33ce9f1  jp 0x000072C8A33CEA00
000072c8a33ce9f3  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33ce9fb  jmp 0x000072C8A33CE7AC
000072c8a33cea00  vxorps xmm0, xmm1, xmm14
000072c8a33cea05  pextrw eax, xmm0, 0x03
000072c8a33cea0a  and eax, 0x7FF8
000072c8a33cea0f  cmp eax, 0x08
000072c8a33cea12  jnz 0x000072C8A33CE7AC
000072c8a33cea18  movq rax, xmm14
000072c8a33cea1d  shl rax, 0x0D
000072c8a33cea21  jbe 0x000072C8A33CE7AC
000072c8a33cea27  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33cea2f  jmp 0x000072C8A33CE7AC
000072c8a33cea34  ucomisd xmm1, xmm14
000072c8a33cea39  jp 0x000072C8A33CEA48
000072c8a33cea3b  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33cea43  jmp 0x000072C8A33CE7D9
000072c8a33cea48  vxorps xmm0, xmm1, xmm14
000072c8a33cea4d  pextrw eax, xmm0, 0x03
000072c8a33cea52  and eax, 0x7FF8
000072c8a33cea57  cmp eax, 0x08
000072c8a33cea5a  jnz 0x000072C8A33CE7D9
000072c8a33cea60  movq rax, xmm14
000072c8a33cea65  shl rax, 0x0D
000072c8a33cea69  jbe 0x000072C8A33CE7D9
000072c8a33cea6f  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33cea77  jmp 0x000072C8A33CE7D9
000072c8a33cea7c  ucomisd xmm1, xmm14
000072c8a33cea81  jp 0x000072C8A33CEA90
000072c8a33cea83  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33cea8b  jmp 0x000072C8A33CE806
000072c8a33cea90  vxorps xmm0, xmm1, xmm14
000072c8a33cea95  pextrw eax, xmm0, 0x03
000072c8a33cea9a  and eax, 0x7FF8
000072c8a33cea9f  cmp eax, 0x08
000072c8a33ceaa2  jnz 0x000072C8A33CE806
000072c8a33ceaa8  movq rax, xmm14
000072c8a33ceaad  shl rax, 0x0D
000072c8a33ceab1  jbe 0x000072C8A33CE806
000072c8a33ceab7  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33ceabf  jmp 0x000072C8A33CE806
000072c8a33ceac4  ucomisd xmm1, xmm15
000072c8a33ceac9  jp 0x000072C8A33CEAD8
000072c8a33ceacb  movaps xmm14, [0x000072C8A2FFE030]
000072c8a33cead3  jmp 0x000072C8A33CE833
000072c8a33cead8  vxorps xmm0, xmm1, xmm15
000072c8a33ceadd  pextrw eax, xmm0, 0x03
000072c8a33ceae2  and eax, 0x7FF8
000072c8a33ceae7  cmp eax, 0x08
000072c8a33ceaea  jnz 0x000072C8A33CE833
000072c8a33ceaf0  movq rax, xmm15
000072c8a33ceaf5  shl rax, 0x0D
000072c8a33ceaf9  jbe 0x000072C8A33CE833
000072c8a33ceaff  vorps xmm14, xmm15, [0x000072C8A2FFE040]
000072c8a33ceb07  jmp 0x000072C8A33CE833
000072c8a33ceb0c  int3
000072c8a33ceb0d  nop [rax], eax
000072c8a33ceb10  movaps xmm1, [r15+0x110]
000072c8a33ceb18  movq rax, xmm1
000072c8a33ceb1d  movaps xmm1, [r15+0x120]
000072c8a33ceb25  movq r14, xmm1
000072c8a33ceb2a  vmovq xmm15, rax
000072c8a33ceb2f  vmovq xmm14, r14
000072c8a33ceb34  movaps xmm13, xmm15
000072c8a33ceb38  addsd xmm13, xmm14
000072c8a33ceb3d  ucomisd xmm13, xmm13
000072c8a33ceb42  jp 0x000072C8A33CED24
000072c8a33ceb48  movq xmm13, xmm13
000072c8a33ceb4d  movq rax, xmm13
000072c8a33ceb52  movq r14, xmm1
000072c8a33ceb57  vmovq xmm15, rax
000072c8a33ceb5c  vmovq xmm14, r14
000072c8a33ceb61  movaps xmm13, xmm15
000072c8a33ceb65  addsd xmm13, xmm14
000072c8a33ceb6a  ucomisd xmm13, xmm13
000072c8a33ceb6f  jp 0x000072C8A33CED6C
000072c8a33ceb75  movq xmm13, xmm13
000072c8a33ceb7a  movq rax, xmm13
000072c8a33ceb7f  movq r14, xmm1
000072c8a33ceb84  vmovq xmm15, rax
000072c8a33ceb89  vmovq xmm14, r14
000072c8a33ceb8e  movaps xmm13, xmm15
000072c8a33ceb92  addsd xmm13, xmm14
000072c8a33ceb97  ucomisd xmm13, xmm13
000072c8a33ceb9c  jp 0x000072C8A33CEDB4
000072c8a33ceba2  movq xmm13, xmm13
000072c8a33ceba7  movq rax, xmm13
000072c8a33cebac  movq r14, xmm1
000072c8a33cebb1  vmovq xmm15, rax
000072c8a33cebb6  vmovq xmm14, r14
000072c8a33cebbb  movaps xmm13, xmm15
000072c8a33cebbf  addsd xmm13, xmm14
000072c8a33cebc4  ucomisd xmm13, xmm13
000072c8a33cebc9  jp 0x000072C8A33CEDFC
000072c8a33cebcf  movq xmm13, xmm13
000072c8a33cebd4  movq rax, xmm13
000072c8a33cebd9  movq r14, xmm1
000072c8a33cebde  vmovq xmm15, rax
000072c8a33cebe3  vmovq xmm14, r14
000072c8a33cebe8  movaps xmm13, xmm15
000072c8a33cebec  addsd xmm13, xmm14
000072c8a33cebf1  ucomisd xmm13, xmm13
000072c8a33cebf6  jp 0x000072C8A33CEE44
000072c8a33cebfc  movq xmm13, xmm13
000072c8a33cec01  movq rax, xmm13
000072c8a33cec06  movq r14, xmm1
000072c8a33cec0b  vmovq xmm15, rax
000072c8a33cec10  vmovq xmm14, r14
000072c8a33cec15  movaps xmm13, xmm15
000072c8a33cec19  addsd xmm13, xmm14
000072c8a33cec1e  ucomisd xmm13, xmm13
000072c8a33cec23  jp 0x000072C8A33CEE8C
000072c8a33cec29  movq xmm13, xmm13
000072c8a33cec2e  movq rax, xmm13
000072c8a33cec33  movq r14, xmm1
000072c8a33cec38  vmovq xmm15, rax
000072c8a33cec3d  vmovq xmm14, r14
000072c8a33cec42  movaps xmm13, xmm15
000072c8a33cec46  addsd xmm13, xmm14
000072c8a33cec4b  ucomisd xmm13, xmm13
000072c8a33cec50  jp 0x000072C8A33CEED4
000072c8a33cec56  movq xmm13, xmm13
000072c8a33cec5b  movq rax, xmm13
000072c8a33cec60  movq r14, xmm1
000072c8a33cec65  vmovq xmm1, rax
000072c8a33cec6a  vmovq xmm15, r14
000072c8a33cec6f  movaps xmm14, xmm1
000072c8a33cec73  addsd xmm14, xmm15
000072c8a33cec78  ucomisd xmm14, xmm14
000072c8a33cec7d  jp 0x000072C8A33CEF1C
000072c8a33cec83  movq xmm14, xmm14
000072c8a33cec88  movaps [r15+0x110], xmm14
000072c8a33cec90  mov rax, [r15+0x08]
000072c8a33cec94  mov [rsp+0x10], rax
000072c8a33cec99  xor eax, eax
000072c8a33cec9b  mov r14, [rsp+0x10]
000072c8a33ceca0  mov r12d, 0x01
000072c8a33ceca6  sub r14, r12
000072c8a33ceca9  cmc
000072c8a33cecaa  lahf
000072c8a33cecab  seto al
000072c8a33cecae  mov [r15+0x108], eax
000072c8a33cecb5  mov [r15+0x08], r14
000072c8a33cecb9  mov eax, [r15+0x108]
000072c8a33cecc0  sahf
000072c8a33cecc1  jnz 0x000072C8A33CECF3
000072c8a33cecc3  cmp dword ptr [r15+0x318], 0x00
000072c8a33ceccb  jz 0x000072C8A33CEF70
000072c8a33cecd1  nop [rax+rax*1], ax
000072c8a33cecda  nop [rax+rax*1], eax
000072c8a33cece2  mov eax, 0x41006C
000072c8a33cece7  mov [r15+0x100], rax
000072c8a33cecee  jmp 0x000072C8A31FE110
000072c8a33cecf3  cmp dword ptr [r15+0x318], 0x00
000072c8a33cecfb  jz 0x000072C8A33CEB10
000072c8a33ced01  nop [rax+rax*1], ax
000072c8a33ced0a  nop [rax+rax*1], eax
000072c8a33ced12  mov eax, 0x410044
000072c8a33ced17  mov [r15+0x100], rax
000072c8a33ced1e  jmp 0x000072C8A31FE110
000072c8a33ced23  int3
000072c8a33ced24  ucomisd xmm15, xmm14
000072c8a33ced29  jp 0x000072C8A33CED38
000072c8a33ced2b  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33ced33  jmp 0x000072C8A33CEB48
000072c8a33ced38  vxorps xmm0, xmm15, xmm14
000072c8a33ced3d  pextrw eax, xmm0, 0x03
000072c8a33ced42  and eax, 0x7FF8
000072c8a33ced47  cmp eax, 0x08
000072c8a33ced4a  jnz 0x000072C8A33CEB48
000072c8a33ced50  movq rax, xmm14
000072c8a33ced55  shl rax, 0x0D
000072c8a33ced59  jbe 0x000072C8A33CEB48
000072c8a33ced5f  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33ced67  jmp 0x000072C8A33CEB48
000072c8a33ced6c  ucomisd xmm15, xmm14
000072c8a33ced71  jp 0x000072C8A33CED80
000072c8a33ced73  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33ced7b  jmp 0x000072C8A33CEB75
000072c8a33ced80  vxorps xmm0, xmm15, xmm14
000072c8a33ced85  pextrw eax, xmm0, 0x03
000072c8a33ced8a  and eax, 0x7FF8
000072c8a33ced8f  cmp eax, 0x08
000072c8a33ced92  jnz 0x000072C8A33CEB75
000072c8a33ced98  movq rax, xmm14
000072c8a33ced9d  shl rax, 0x0D
000072c8a33ceda1  jbe 0x000072C8A33CEB75
000072c8a33ceda7  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33cedaf  jmp 0x000072C8A33CEB75
000072c8a33cedb4  ucomisd xmm15, xmm14
000072c8a33cedb9  jp 0x000072C8A33CEDC8
000072c8a33cedbb  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33cedc3  jmp 0x000072C8A33CEBA2
000072c8a33cedc8  vxorps xmm0, xmm15, xmm14
000072c8a33cedcd  pextrw eax, xmm0, 0x03
000072c8a33cedd2  and eax, 0x7FF8
000072c8a33cedd7  cmp eax, 0x08
000072c8a33cedda  jnz 0x000072C8A33CEBA2
000072c8a33cede0  movq rax, xmm14
000072c8a33cede5  shl rax, 0x0D
000072c8a33cede9  jbe 0x000072C8A33CEBA2
000072c8a33cedef  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33cedf7  jmp 0x000072C8A33CEBA2
000072c8a33cedfc  ucomisd xmm15, xmm14
000072c8a33cee01  jp 0x000072C8A33CEE10
000072c8a33cee03  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33cee0b  jmp 0x000072C8A33CEBCF
000072c8a33cee10  vxorps xmm0, xmm15, xmm14
000072c8a33cee15  pextrw eax, xmm0, 0x03
000072c8a33cee1a  and eax, 0x7FF8
000072c8a33cee1f  cmp eax, 0x08
000072c8a33cee22  jnz 0x000072C8A33CEBCF
000072c8a33cee28  movq rax, xmm14
000072c8a33cee2d  shl rax, 0x0D
000072c8a33cee31  jbe 0x000072C8A33CEBCF
000072c8a33cee37  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33cee3f  jmp 0x000072C8A33CEBCF
000072c8a33cee44  ucomisd xmm15, xmm14
000072c8a33cee49  jp 0x000072C8A33CEE58
000072c8a33cee4b  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33cee53  jmp 0x000072C8A33CEBFC
000072c8a33cee58  vxorps xmm0, xmm15, xmm14
000072c8a33cee5d  pextrw eax, xmm0, 0x03
000072c8a33cee62  and eax, 0x7FF8
000072c8a33cee67  cmp eax, 0x08
000072c8a33cee6a  jnz 0x000072C8A33CEBFC
000072c8a33cee70  movq rax, xmm14
000072c8a33cee75  shl rax, 0x0D
000072c8a33cee79  jbe 0x000072C8A33CEBFC
000072c8a33cee7f  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33cee87  jmp 0x000072C8A33CEBFC
000072c8a33cee8c  ucomisd xmm15, xmm14
000072c8a33cee91  jp 0x000072C8A33CEEA0
000072c8a33cee93  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33cee9b  jmp 0x000072C8A33CEC29
000072c8a33ceea0  vxorps xmm0, xmm15, xmm14
000072c8a33ceea5  pextrw eax, xmm0, 0x03
000072c8a33ceeaa  and eax, 0x7FF8
000072c8a33ceeaf  cmp eax, 0x08
000072c8a33ceeb2  jnz 0x000072C8A33CEC29
000072c8a33ceeb8  movq rax, xmm14
000072c8a33ceebd  shl rax, 0x0D
000072c8a33ceec1  jbe 0x000072C8A33CEC29
000072c8a33ceec7  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33ceecf  jmp 0x000072C8A33CEC29
000072c8a33ceed4  ucomisd xmm15, xmm14
000072c8a33ceed9  jp 0x000072C8A33CEEE8
000072c8a33ceedb  movaps xmm13, [0x000072C8A2FFE030]
000072c8a33ceee3  jmp 0x000072C8A33CEC56
000072c8a33ceee8  vxorps xmm0, xmm15, xmm14
000072c8a33ceeed  pextrw eax, xmm0, 0x03
000072c8a33ceef2  and eax, 0x7FF8
000072c8a33ceef7  cmp eax, 0x08
000072c8a33ceefa  jnz 0x000072C8A33CEC56
000072c8a33cef00  movq rax, xmm14
000072c8a33cef05  shl rax, 0x0D
000072c8a33cef09  jbe 0x000072C8A33CEC56
000072c8a33cef0f  vorps xmm13, xmm14, [0x000072C8A2FFE040]
000072c8a33cef17  jmp 0x000072C8A33CEC56
000072c8a33cef1c  ucomisd xmm1, xmm15
000072c8a33cef21  jp 0x000072C8A33CEF30
000072c8a33cef23  movaps xmm14, [0x000072C8A2FFE030]
000072c8a33cef2b  jmp 0x000072C8A33CEC83
000072c8a33cef30  vxorps xmm0, xmm1, xmm15
000072c8a33cef35  pextrw eax, xmm0, 0x03
000072c8a33cef3a  and eax, 0x7FF8
000072c8a33cef3f  cmp eax, 0x08
000072c8a33cef42  jnz 0x000072C8A33CEC83
000072c8a33cef48  movq rax, xmm15
000072c8a33cef4d  shl rax, 0x0D
000072c8a33cef51  jbe 0x000072C8A33CEC83
000072c8a33cef57  vorps xmm14, xmm15, [0x000072C8A2FFE040]
000072c8a33cef5f  jmp 0x000072C8A33CEC83
000072c8a33cef64  int3
000072c8a33cef65  nop [rax+rax*1], ax
000072c8a33cef6e  nop
000072c8a33cef70  mov rax, [r15+0x20]
000072c8a33cef74  movaps xmm1, [r15+0x110]
000072c8a33cef7c  movq r14, xmm1
000072c8a33cef81  mov [r13+rax*1], r14
000072c8a33cef86  mov rax, [r15+0xF0]
000072c8a33cef8d  mov [r15+0x100], rax
000072c8a33cef94  jmp 0x000072C8A33CE5C0
000072c8a33cef99  int3
000072c8a33cef9a  call 0x000072C8A320E120
000072c8a33cef9f  jmp 0x000072C8A33CEF86
000072c8a33cefa4  int3
000072c8a33cefa5  nop [rax+rax*1], ax
000072c8a33cefae  nop
000072c8a33cefb0  mov qword ptr [r15+0x100], 0x04
000072c8a33cefbb  mov esi, 0x00
000072c8a33cefc0  mov edx, 0x09
000072c8a33cefc5  mov rdi, 0x7FFD23EB5A10
000072c8a33cefcf  mov rax, 0x650DD6BCA970
000072c8a33cefd9  call rax
000072c8a33cefdb  cmp dword ptr [r15+0x318], 0x00
000072c8a33cefe3  jnz 0x000072C8A31FE110
000072c8a33cefe9  jmp 0x000072C8A31FE0A0
000072c8a33cefee  int3
000072c8a33cefef  int3
