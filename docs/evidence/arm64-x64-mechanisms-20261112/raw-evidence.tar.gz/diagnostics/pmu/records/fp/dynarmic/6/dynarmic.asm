0000723f4dfce69b  nop [rax+rax*1], eax
0000723f4dfce6a0  mov qword ptr [r15+0x20], 0x420060
0000723f4dfce6a8  mov qword ptr [r15], 0x00
0000723f4dfce6af  vmovaps xmm1, [0x0000723F4DBFE010]
0000723f4dfce6b7  movq xmm1, xmm1
0000723f4dfce6bb  vmovaps xmm15, [0x0000723F4DBFE020]
0000723f4dfce6c3  movq xmm15, xmm15
0000723f4dfce6c8  movaps [r15+0x120], xmm15
0000723f4dfce6d0  movq rax, xmm1
0000723f4dfce6d5  movq r14, xmm15
0000723f4dfce6da  vmovq xmm1, rax
0000723f4dfce6df  vmovq xmm15, r14
0000723f4dfce6e4  movaps xmm14, xmm1
0000723f4dfce6e8  addsd xmm14, xmm15
0000723f4dfce6ed  ucomisd xmm14, xmm14
0000723f4dfce6f2  jp 0x0000723F4DFCE791
0000723f4dfce6f8  movq xmm14, xmm14
0000723f4dfce6fd  movaps [r15+0x110], xmm14
0000723f4dfce705  xor eax, eax
0000723f4dfce707  mov r14d, 0xF4240
0000723f4dfce70d  mov r12d, 0x01
0000723f4dfce713  sub r14, r12
0000723f4dfce716  cmc
0000723f4dfce717  lahf
0000723f4dfce718  seto al
0000723f4dfce71b  mov [r15+0x108], eax
0000723f4dfce722  mov [r15+0x08], r14
0000723f4dfce726  mov eax, [r15+0x108]
0000723f4dfce72d  sahf
0000723f4dfce72e  jnz 0x0000723F4DFCE760
0000723f4dfce730  cmp dword ptr [r15+0x318], 0x00
0000723f4dfce738  jz 0x0000723F4DFCE910
0000723f4dfce73e  nop [rax+rax*1], ax
0000723f4dfce747  nop [rax+rax*1], eax
0000723f4dfce74f  mov eax, 0x410050
0000723f4dfce754  mov [r15+0x100], rax
0000723f4dfce75b  jmp 0x0000723F4DDFE110
0000723f4dfce760  cmp dword ptr [r15+0x318], 0x00
0000723f4dfce768  jz 0x0000723F4DFCE7E0
0000723f4dfce76e  nop [rax+rax*1], ax
0000723f4dfce777  nop [rax+rax*1], eax
0000723f4dfce77f  mov eax, 0x410044
0000723f4dfce784  mov [r15+0x100], rax
0000723f4dfce78b  jmp 0x0000723F4DDFE110
0000723f4dfce790  int3
0000723f4dfce791  ucomisd xmm1, xmm15
0000723f4dfce796  jp 0x0000723F4DFCE7A5
0000723f4dfce798  movaps xmm14, [0x0000723F4DBFE030]
0000723f4dfce7a0  jmp 0x0000723F4DFCE6F8
0000723f4dfce7a5  vxorps xmm0, xmm1, xmm15
0000723f4dfce7aa  pextrw eax, xmm0, 0x03
0000723f4dfce7af  and eax, 0x7FF8
0000723f4dfce7b4  cmp eax, 0x08
0000723f4dfce7b7  jnz 0x0000723F4DFCE6F8
0000723f4dfce7bd  movq rax, xmm15
0000723f4dfce7c2  shl rax, 0x0D
0000723f4dfce7c6  jbe 0x0000723F4DFCE6F8
0000723f4dfce7cc  vorps xmm14, xmm15, [0x0000723F4DBFE040]
0000723f4dfce7d4  jmp 0x0000723F4DFCE6F8
0000723f4dfce7d9  int3
0000723f4dfce7da  nop [rax+rax*1], ax
0000723f4dfce7e0  movaps xmm1, [r15+0x110]
0000723f4dfce7e8  movq rax, xmm1
0000723f4dfce7ed  movaps xmm1, [r15+0x120]
0000723f4dfce7f5  movq r14, xmm1
0000723f4dfce7fa  vmovq xmm1, rax
0000723f4dfce7ff  vmovq xmm15, r14
0000723f4dfce804  movaps xmm14, xmm1
0000723f4dfce808  addsd xmm14, xmm15
0000723f4dfce80d  ucomisd xmm14, xmm14
0000723f4dfce812  jp 0x0000723F4DFCE8B9
0000723f4dfce818  movq xmm14, xmm14
0000723f4dfce81d  movaps [r15+0x110], xmm14
0000723f4dfce825  mov rax, [r15+0x08]
0000723f4dfce829  mov [rsp+0x10], rax
0000723f4dfce82e  xor eax, eax
0000723f4dfce830  mov r14, [rsp+0x10]
0000723f4dfce835  mov r12d, 0x01
0000723f4dfce83b  sub r14, r12
0000723f4dfce83e  cmc
0000723f4dfce83f  lahf
0000723f4dfce840  seto al
0000723f4dfce843  mov [r15+0x108], eax
0000723f4dfce84a  mov [r15+0x08], r14
0000723f4dfce84e  mov eax, [r15+0x108]
0000723f4dfce855  sahf
0000723f4dfce856  jnz 0x0000723F4DFCE888
0000723f4dfce858  cmp dword ptr [r15+0x318], 0x00
0000723f4dfce860  jz 0x0000723F4DFCE910
0000723f4dfce866  nop [rax+rax*1], ax
0000723f4dfce86f  nop [rax+rax*1], eax
0000723f4dfce877  mov eax, 0x410050
0000723f4dfce87c  mov [r15+0x100], rax
0000723f4dfce883  jmp 0x0000723F4DDFE110
0000723f4dfce888  cmp dword ptr [r15+0x318], 0x00
0000723f4dfce890  jz 0x0000723F4DFCE7E0
0000723f4dfce896  nop [rax+rax*1], ax
0000723f4dfce89f  nop [rax+rax*1], eax
0000723f4dfce8a7  mov eax, 0x410044
0000723f4dfce8ac  mov [r15+0x100], rax
0000723f4dfce8b3  jmp 0x0000723F4DDFE110
0000723f4dfce8b8  int3
0000723f4dfce8b9  ucomisd xmm1, xmm15
0000723f4dfce8be  jp 0x0000723F4DFCE8CD
0000723f4dfce8c0  movaps xmm14, [0x0000723F4DBFE030]
0000723f4dfce8c8  jmp 0x0000723F4DFCE818
0000723f4dfce8cd  vxorps xmm0, xmm1, xmm15
0000723f4dfce8d2  pextrw eax, xmm0, 0x03
0000723f4dfce8d7  and eax, 0x7FF8
0000723f4dfce8dc  cmp eax, 0x08
0000723f4dfce8df  jnz 0x0000723F4DFCE818
0000723f4dfce8e5  movq rax, xmm15
0000723f4dfce8ea  shl rax, 0x0D
0000723f4dfce8ee  jbe 0x0000723F4DFCE818
0000723f4dfce8f4  vorps xmm14, xmm15, [0x0000723F4DBFE040]
0000723f4dfce8fc  jmp 0x0000723F4DFCE818
0000723f4dfce901  int3
0000723f4dfce902  nop [rax+rax*1], ax
0000723f4dfce90b  nop [rax+rax*1], eax
0000723f4dfce910  mov rax, [r15+0x20]
0000723f4dfce914  movaps xmm1, [r15+0x110]
0000723f4dfce91c  movq r14, xmm1
0000723f4dfce921  mov [r13+rax*1], r14
0000723f4dfce926  mov rax, [r15+0xF0]
0000723f4dfce92d  mov [r15+0x100], rax
0000723f4dfce934  jmp 0x0000723F4DFCE5C0
0000723f4dfce939  int3
0000723f4dfce93a  call 0x0000723F4DE0E120
0000723f4dfce93f  jmp 0x0000723F4DFCE926
0000723f4dfce944  int3
0000723f4dfce945  nop [rax+rax*1], ax
0000723f4dfce94e  nop
0000723f4dfce950  mov qword ptr [r15+0x100], 0x04
0000723f4dfce95b  mov esi, 0x00
0000723f4dfce960  mov edx, 0x09
0000723f4dfce965  mov rdi, 0x7FFEEA99FA50
0000723f4dfce96f  mov rax, 0x5D3383175970
0000723f4dfce979  call rax
0000723f4dfce97b  cmp dword ptr [r15+0x318], 0x00
0000723f4dfce983  jnz 0x0000723F4DDFE110
0000723f4dfce989  jmp 0x0000723F4DDFE0A0
0000723f4dfce98e  int3
0000723f4dfce98f  int3
