
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/fp/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x140
   7:	mov    r13d,0x4240
   d:	mov    QWORD PTR [r12+0x8],r13
  12:	mov    r13d,0x4240
  18:	mov    r14d,0xf
  1e:	and    r14d,0xffff
  25:	mov    rax,r13
  28:	movabs rcx,0xffffffff0000ffff
  32:	and    rax,rcx
  35:	mov    rdx,r14
  38:	shl    rdx,0x10
  3c:	mov    ecx,0xffff0000
  41:	and    rdx,rcx
  44:	or     rax,rdx
  47:	mov    r15,rax
  4a:	mov    QWORD PTR [r12+0x8],r15
  4f:	mov    r13d,0x420060
  55:	mov    QWORD PTR [r12+0x20],r13
  5a:	mov    r13d,0x0
  60:	mov    QWORD PTR [r12],r13
  64:	mov    r13d,0x0
  6a:	movabs r14,0x3ff0000000000000
  74:	mov    QWORD PTR [r12+0x110],r14
  7c:	mov    QWORD PTR [r12+0x118],r13
  84:	mov    r13d,0x0
  8a:	movabs r14,0x3ff8000000000000
  94:	mov    QWORD PTR [r12+0x120],r14
  9c:	mov    QWORD PTR [r12+0x128],r13
  a4:	jmp    0xa9
  a9:	movdqu xmm0,XMMWORD PTR [r12+0x110]
  b3:	movdqa xmm2,xmm0
  b7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
  c1:	movdqa xmm3,xmm0
  c5:	cmp    DWORD PTR [r12+0x310],0x0
  ce:	jne    0x168
  d4:	movdqa xmm0,xmm2
  d8:	movdqa xmm1,xmm3
  dc:	movq   rax,xmm0
  e1:	add    rax,rax
  e4:	je     0xfa
  e6:	shr    rax,0x35
  ea:	sub    eax,0x201
  ef:	cmp    eax,0x3fc
  f4:	ja     0x168
  fa:	movq   rax,xmm1
  ff:	add    rax,rax
 102:	je     0x118
 104:	shr    rax,0x35
 108:	sub    eax,0x201
 10d:	cmp    eax,0x3fc
 112:	ja     0x168
 118:	movq   xmm0,xmm0
 11c:	movq   xmm1,xmm1
 120:	stmxcsr DWORD PTR [rsp+0x100]
 128:	mov    DWORD PTR [rsp+0x104],0x1f80
 133:	ldmxcsr DWORD PTR [rsp+0x104]
 13b:	addsd  xmm0,xmm1
 13f:	stmxcsr DWORD PTR [rsp+0x104]
 147:	ldmxcsr DWORD PTR [rsp+0x100]
 14f:	mov    eax,DWORD PTR [rsp+0x104]
 156:	shr    eax,1
 158:	and    eax,0x10
 15b:	or     DWORD PTR [r12+0x314],eax
 163:	jmp    0x215
 168:	movdqa xmm0,xmm2
 16c:	movdqa xmm1,xmm3
 170:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
 179:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
 182:	mov    QWORD PTR [r12+0x378],0x3
 18e:	movdqu XMMWORD PTR [rsp],xmm2
 193:	movdqu XMMWORD PTR [rsp+0x10],xmm3
 199:	mov    QWORD PTR [r12+0x108],rbx
 1a1:	stmxcsr DWORD PTR [r12-0x28]
 1a7:	ldmxcsr DWORD PTR [r12-0x38]
 1ad:	lea    rdi,[rsp+0xf0]
 1b5:	lea    rsi,[rsp+0xd0]
 1bd:	lea    rdx,[rsp+0xe0]
 1c5:	mov    ecx,0xc
 1ca:	mov    r8d,DWORD PTR [r12+0x310]
 1d2:	lea    r9,[r12+0x314]
 1da:	movabs r11,0x57c99e7a5750
 1e4:	call   r11
 1e7:	ldmxcsr DWORD PTR [r12-0x28]
 1ed:	movdqu xmm2,XMMWORD PTR [rsp]
 1f2:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
 1f8:	mov    rbx,QWORD PTR [r12+0x108]
 200:	mov    QWORD PTR [r12+0x378],0x2
 20c:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
 215:	movdqa xmm4,xmm0
 219:	movdqa xmm0,xmm4
 21d:	movdqu XMMWORD PTR [r12+0x110],xmm0
 227:	mov    r13,QWORD PTR [r12+0x8]
 22c:	mov    r14,r13
 22f:	sub    r14,0x1
 233:	pushf
 234:	pop    rdx
 235:	mov    r10d,edx
 238:	and    r10d,0xc0
 23f:	shl    r10d,0x18
 243:	mov    r11d,edx
 246:	and    r11d,0x1
 24a:	shl    r11d,0x1d
 24e:	or     r10d,r11d
 251:	mov    r11d,edx
 254:	and    r11d,0x800
 25b:	shl    r11d,0x11
 25f:	or     r10d,r11d
 262:	mov    r11d,0xf0000000
 268:	and    r11,r10
 26b:	movabs rsi,0xffffffff0fffffff
 275:	and    rbx,rsi
 278:	or     rbx,r11
 27b:	btc    rbx,0x1d
 280:	mov    QWORD PTR [r12+0x8],r14
 285:	cmp    QWORD PTR [r12+0x380],0x0
 28e:	je     0x2c2
 294:	mov    eax,0x41004c
 299:	mov    QWORD PTR [r12+0x100],rax
 2a1:	mov    QWORD PTR [r12+0x108],rbx
 2a9:	add    rsp,0x140
 2b0:	mov    eax,0xc
 2b5:	movabs r11,0x57c99e9395f0
 2bf:	jmp    r11
 2c2:	test   ebx,0x40000000
 2c8:	je     0xa9
 2ce:	jmp    0x2d3
 2d3:	mov    r13,QWORD PTR [r12+0x20]
 2d8:	mov    r14,QWORD PTR [r12+0x110]
 2e0:	mov    QWORD PTR [r13+0x0],r14
 2e4:	mov    r13d,0x0
 2ea:	mov    DWORD PTR [r12+0x32c],r13d
 2f2:	cmp    QWORD PTR [r12+0x380],0x0
 2fb:	je     0x32f
 301:	mov    eax,0x410054
 306:	mov    QWORD PTR [r12+0x100],rax
 30e:	mov    QWORD PTR [r12+0x108],rbx
 316:	add    rsp,0x140
 31d:	mov    eax,0xc
 322:	movabs r11,0x57c99e9395f0
 32c:	jmp    r11
 32f:	mov    r13,QWORD PTR [r12+0xf0]
 337:	mov    QWORD PTR [r12+0x100],r13
 33f:	mov    QWORD PTR [r12+0x108],rbx
 347:	mov    rdi,QWORD PTR [r12+0x100]
 34f:	add    rsp,0x140
 356:	movabs r11,0x57c99e939370
 360:	jmp    r11
 363:	data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 370:	sub    rsp,0x140
 377:	jmp    0xa9
 37c:	nop    DWORD PTR [rax+0x0]
 380:	sub    rsp,0x140
 387:	jmp    0x2d3
