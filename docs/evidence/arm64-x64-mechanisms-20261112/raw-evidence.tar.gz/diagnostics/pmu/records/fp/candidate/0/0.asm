
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/fp/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x150
   7:	mov    r11,QWORD PTR [r12+0x398]
   f:	mov    QWORD PTR [rsp],r11
  13:	cmp    DWORD PTR [r12+0x310],0x0
  1c:	je     0xac
  22:	push   rdx
  23:	push   rsi
  24:	push   r10
  26:	push   r11
  28:	mov    rdx,QWORD PTR [rsp+0x20]
  2d:	mov    r10d,edx
  30:	and    r10d,0xc0
  37:	shl    r10d,0x18
  3b:	mov    r11d,edx
  3e:	and    r11d,0x1
  42:	shl    r11d,0x1d
  46:	or     r10d,r11d
  49:	mov    r11d,edx
  4c:	and    r11d,0x800
  53:	shl    r11d,0x11
  57:	or     r10d,r11d
  5a:	btc    r10,0x1d
  5f:	mov    r11d,0xf0000000
  65:	and    r11,r10
  68:	movabs rsi,0xffffffff0fffffff
  72:	and    rbx,rsi
  75:	or     rbx,r11
  78:	pop    r11
  7a:	pop    r10
  7c:	pop    rsi
  7d:	pop    rdx
  7e:	mov    QWORD PTR [r12+0x108],rbx
  86:	mov    eax,0x410028
  8b:	mov    QWORD PTR [r12+0x100],rax
  93:	add    rsp,0x150
  9a:	mov    eax,0x3
  9f:	movabs r11,0x6222fab7e390
  a9:	jmp    r11
  ac:	mov    r13d,0x4240
  b2:	mov    r14d,0xf
  b8:	and    r14d,0xffff
  bf:	mov    rax,r13
  c2:	movabs rcx,0xffffffff0000ffff
  cc:	and    rax,rcx
  cf:	mov    rdx,r14
  d2:	shl    rdx,0x10
  d6:	mov    ecx,0xffff0000
  db:	and    rdx,rcx
  de:	or     rax,rdx
  e1:	mov    r15,rax
  e4:	mov    QWORD PTR [r12+0x8],r15
  e9:	mov    r13d,0x420060
  ef:	mov    QWORD PTR [r12+0x20],r13
  f4:	mov    r13d,0x0
  fa:	mov    QWORD PTR [r12],r13
  fe:	mov    r13d,0x0
 104:	movabs r14,0x3ff0000000000000
 10e:	mov    QWORD PTR [r12+0x110],r14
 116:	mov    QWORD PTR [r12+0x118],r13
 11e:	mov    r13d,0x0
 124:	movabs r14,0x3ff8000000000000
 12e:	mov    QWORD PTR [r12+0x120],r14
 136:	mov    QWORD PTR [r12+0x128],r13
 13e:	jmp    0x143
 143:	movdqu xmm0,XMMWORD PTR [r12+0x110]
 14d:	movdqa xmm2,xmm0
 151:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 15b:	movdqa xmm3,xmm0
 15f:	stmxcsr DWORD PTR [rsp+0x110]
 167:	mov    DWORD PTR [rsp+0x114],0x1f80
 172:	ldmxcsr DWORD PTR [rsp+0x114]
 17a:	movdqa xmm0,xmm2
 17e:	movdqa xmm1,xmm3
 182:	movq   rax,xmm0
 187:	add    rax,rax
 18a:	je     0x1a0
 18c:	shr    rax,0x35
 190:	sub    eax,0x201
 195:	cmp    eax,0x3fc
 19a:	ja     0x298
 1a0:	movq   rax,xmm1
 1a5:	add    rax,rax
 1a8:	je     0x1be
 1aa:	shr    rax,0x35
 1ae:	sub    eax,0x201
 1b3:	cmp    eax,0x3fc
 1b8:	ja     0x298
 1be:	movq   xmm0,xmm0
 1c2:	movq   xmm1,xmm1
 1c6:	addsd  xmm0,xmm1
 1ca:	movdqa xmm4,xmm0
 1ce:	movdqa xmm0,xmm4
 1d2:	movdqu XMMWORD PTR [r12+0x110],xmm0
 1dc:	mov    r13,QWORD PTR [r12+0x8]
 1e1:	stmxcsr DWORD PTR [rsp+0x114]
 1e9:	ldmxcsr DWORD PTR [rsp+0x110]
 1f1:	mov    r11d,DWORD PTR [rsp+0x114]
 1f9:	shr    r11d,1
 1fc:	and    r11d,0x10
 200:	or     DWORD PTR [r12+0x314],r11d
 208:	sub    r13,0x1
 20c:	mov    QWORD PTR [r12+0x8],r13
 211:	mov    rcx,QWORD PTR [r12+0x380]
 219:	jrcxz  0x220
 21b:	jmp    0x39e
 220:	jne    0x143
 226:	pushf
 227:	pop    r11
 229:	mov    QWORD PTR [rsp],r11
 22d:	jmp    0x232
 232:	mov    r13,QWORD PTR [r12+0x20]
 237:	mov    r14,QWORD PTR [r12+0x110]
 23f:	mov    QWORD PTR [r13+0x0],r14
 243:	mov    r13d,0x0
 249:	mov    DWORD PTR [r12+0x32c],r13d
 251:	mov    rcx,QWORD PTR [r12+0x380]
 259:	jrcxz  0x260
 25b:	jmp    0x430
 260:	mov    r13,QWORD PTR [r12+0xf0]
 268:	mov    QWORD PTR [r12+0x100],r13
 270:	mov    r11,QWORD PTR [rsp]
 274:	mov    QWORD PTR [r12+0x398],r11
 27c:	mov    rdi,QWORD PTR [r12+0x100]
 284:	add    rsp,0x150
 28b:	movabs r11,0x6222fab7e0a0
 295:	jmp    r11
 298:	movdqa xmm0,xmm2
 29c:	movdqa xmm1,xmm3
 2a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 2a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 2b2:	call   0x2c0
 2b7:	jmp    0x1ca
 2bc:	nop    DWORD PTR [rax+0x0]
 2c0:	sub    rsp,0x8
 2c4:	stmxcsr DWORD PTR [rsp+0x124]
 2cc:	ldmxcsr DWORD PTR [rsp+0x120]
 2d4:	mov    r11d,DWORD PTR [rsp+0x124]
 2dc:	shr    r11d,1
 2df:	and    r11d,0x10
 2e3:	or     DWORD PTR [r12+0x314],r11d
 2eb:	mov    QWORD PTR [r12+0x378],0x3
 2f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
 2fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
 303:	mov    QWORD PTR [r12+0x108],rbx
 30b:	stmxcsr DWORD PTR [r12-0x28]
 311:	ldmxcsr DWORD PTR [r12-0x38]
 317:	lea    rdi,[rsp+0x110]
 31f:	lea    rsi,[rsp+0xf0]
 327:	lea    rdx,[rsp+0x100]
 32f:	mov    ecx,0xc
 334:	mov    r8d,0x0
 33a:	lea    r9,[r12+0x314]
 342:	movabs r11,0x6222fa9e91b0
 34c:	call   r11
 34f:	ldmxcsr DWORD PTR [r12-0x28]
 355:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
 35b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
 361:	mov    rbx,QWORD PTR [r12+0x108]
 369:	mov    QWORD PTR [r12+0x378],0x2
 375:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
 37e:	stmxcsr DWORD PTR [rsp+0x120]
 386:	mov    DWORD PTR [rsp+0x124],0x1f80
 391:	ldmxcsr DWORD PTR [rsp+0x124]
 399:	add    rsp,0x8
 39d:	ret
 39e:	mov    eax,0x41004c
 3a3:	mov    QWORD PTR [r12+0x100],rax
 3ab:	push   rdx
 3ac:	push   rsi
 3ad:	push   r10
 3af:	push   r11
 3b1:	pushf
 3b2:	pop    r11
 3b4:	mov    QWORD PTR [rsp+0x20],r11
 3b9:	mov    rdx,QWORD PTR [rsp+0x20]
 3be:	mov    r10d,edx
 3c1:	and    r10d,0xc0
 3c8:	shl    r10d,0x18
 3cc:	mov    r11d,edx
 3cf:	and    r11d,0x1
 3d3:	shl    r11d,0x1d
 3d7:	or     r10d,r11d
 3da:	mov    r11d,edx
 3dd:	and    r11d,0x800
 3e4:	shl    r11d,0x11
 3e8:	or     r10d,r11d
 3eb:	btc    r10,0x1d
 3f0:	mov    r11d,0xf0000000
 3f6:	and    r11,r10
 3f9:	movabs rsi,0xffffffff0fffffff
 403:	and    rbx,rsi
 406:	or     rbx,r11
 409:	pop    r11
 40b:	pop    r10
 40d:	pop    rsi
 40e:	pop    rdx
 40f:	mov    QWORD PTR [r12+0x108],rbx
 417:	add    rsp,0x150
 41e:	mov    eax,0xc
 423:	movabs r11,0x6222fab7e390
 42d:	jmp    r11
 430:	mov    eax,0x410054
 435:	mov    QWORD PTR [r12+0x100],rax
 43d:	push   rdx
 43e:	push   rsi
 43f:	push   r10
 441:	push   r11
 443:	mov    rdx,QWORD PTR [rsp+0x20]
 448:	mov    r10d,edx
 44b:	and    r10d,0xc0
 452:	shl    r10d,0x18
 456:	mov    r11d,edx
 459:	and    r11d,0x1
 45d:	shl    r11d,0x1d
 461:	or     r10d,r11d
 464:	mov    r11d,edx
 467:	and    r11d,0x800
 46e:	shl    r11d,0x11
 472:	or     r10d,r11d
 475:	btc    r10,0x1d
 47a:	mov    r11d,0xf0000000
 480:	and    r11,r10
 483:	movabs rsi,0xffffffff0fffffff
 48d:	and    rbx,rsi
 490:	or     rbx,r11
 493:	pop    r11
 495:	pop    r10
 497:	pop    rsi
 498:	pop    rdx
 499:	mov    QWORD PTR [r12+0x108],rbx
 4a1:	add    rsp,0x150
 4a8:	mov    eax,0xc
 4ad:	movabs r11,0x6222fab7e390
 4b7:	jmp    r11
 4ba:	nop    WORD PTR [rax+rax*1+0x0]
 4c0:	sub    rsp,0x150
 4c7:	mov    r11,QWORD PTR [r12+0x398]
 4cf:	mov    QWORD PTR [rsp],r11
 4d3:	cmp    DWORD PTR [r12+0x310],0x0
 4dc:	je     0x56c
 4e2:	push   rdx
 4e3:	push   rsi
 4e4:	push   r10
 4e6:	push   r11
 4e8:	mov    rdx,QWORD PTR [rsp+0x20]
 4ed:	mov    r10d,edx
 4f0:	and    r10d,0xc0
 4f7:	shl    r10d,0x18
 4fb:	mov    r11d,edx
 4fe:	and    r11d,0x1
 502:	shl    r11d,0x1d
 506:	or     r10d,r11d
 509:	mov    r11d,edx
 50c:	and    r11d,0x800
 513:	shl    r11d,0x11
 517:	or     r10d,r11d
 51a:	btc    r10,0x1d
 51f:	mov    r11d,0xf0000000
 525:	and    r11,r10
 528:	movabs rsi,0xffffffff0fffffff
 532:	and    rbx,rsi
 535:	or     rbx,r11
 538:	pop    r11
 53a:	pop    r10
 53c:	pop    rsi
 53d:	pop    rdx
 53e:	mov    QWORD PTR [r12+0x108],rbx
 546:	mov    eax,0x410044
 54b:	mov    QWORD PTR [r12+0x100],rax
 553:	add    rsp,0x150
 55a:	mov    eax,0x3
 55f:	movabs r11,0x6222fab7e390
 569:	jmp    r11
 56c:	jmp    0x143
 571:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 580:	sub    rsp,0x150
 587:	mov    r11,QWORD PTR [r12+0x398]
 58f:	mov    QWORD PTR [rsp],r11
 593:	cmp    DWORD PTR [r12+0x310],0x0
 59c:	je     0x62c
 5a2:	push   rdx
 5a3:	push   rsi
 5a4:	push   r10
 5a6:	push   r11
 5a8:	mov    rdx,QWORD PTR [rsp+0x20]
 5ad:	mov    r10d,edx
 5b0:	and    r10d,0xc0
 5b7:	shl    r10d,0x18
 5bb:	mov    r11d,edx
 5be:	and    r11d,0x1
 5c2:	shl    r11d,0x1d
 5c6:	or     r10d,r11d
 5c9:	mov    r11d,edx
 5cc:	and    r11d,0x800
 5d3:	shl    r11d,0x11
 5d7:	or     r10d,r11d
 5da:	btc    r10,0x1d
 5df:	mov    r11d,0xf0000000
 5e5:	and    r11,r10
 5e8:	movabs rsi,0xffffffff0fffffff
 5f2:	and    rbx,rsi
 5f5:	or     rbx,r11
 5f8:	pop    r11
 5fa:	pop    r10
 5fc:	pop    rsi
 5fd:	pop    rdx
 5fe:	mov    QWORD PTR [r12+0x108],rbx
 606:	mov    eax,0x410050
 60b:	mov    QWORD PTR [r12+0x100],rax
 613:	add    rsp,0x150
 61a:	mov    eax,0x3
 61f:	movabs r11,0x6222fab7e390
 629:	jmp    r11
 62c:	jmp    0x232
 631:	nop
 632:	nop
 633:	nop
