00007263fffce69b  nop [rax+rax*1], eax
00007263fffce6a0  mov qword ptr [r15+0x20], 0x420060
00007263fffce6a8  mov qword ptr [r15], 0x00
00007263fffce6af  vmovaps xmm1, [0x00007263FFBFE010]
00007263fffce6b7  movq xmm1, xmm1
00007263fffce6bb  vmovaps xmm15, [0x00007263FFBFE020]
00007263fffce6c3  movq xmm15, xmm15
00007263fffce6c8  movaps [r15+0x120], xmm15
00007263fffce6d0  movq rax, xmm1
00007263fffce6d5  movq r14, xmm15
00007263fffce6da  vmovq xmm1, rax
00007263fffce6df  vmovq xmm15, r14
00007263fffce6e4  movaps xmm14, xmm1
00007263fffce6e8  addsd xmm14, xmm15
00007263fffce6ed  ucomisd xmm14, xmm14
00007263fffce6f2  jp 0x00007263FFFCE791
00007263fffce6f8  movq xmm14, xmm14
00007263fffce6fd  movaps [r15+0x110], xmm14
00007263fffce705  xor eax, eax
00007263fffce707  mov r14d, 0xF4240
00007263fffce70d  mov r12d, 0x01
00007263fffce713  sub r14, r12
00007263fffce716  cmc
00007263fffce717  lahf
00007263fffce718  seto al
00007263fffce71b  mov [r15+0x108], eax
00007263fffce722  mov [r15+0x08], r14
00007263fffce726  mov eax, [r15+0x108]
00007263fffce72d  sahf
00007263fffce72e  jnz 0x00007263FFFCE760
00007263fffce730  cmp dword ptr [r15+0x318], 0x00
00007263fffce738  jz 0x00007263FFFCE910
00007263fffce73e  nop [rax+rax*1], ax
00007263fffce747  nop [rax+rax*1], eax
00007263fffce74f  mov eax, 0x410050
00007263fffce754  mov [r15+0x100], rax
00007263fffce75b  jmp 0x00007263FFDFE110
00007263fffce760  cmp dword ptr [r15+0x318], 0x00
00007263fffce768  jz 0x00007263FFFCE7E0
00007263fffce76e  nop [rax+rax*1], ax
00007263fffce777  nop [rax+rax*1], eax
00007263fffce77f  mov eax, 0x410044
00007263fffce784  mov [r15+0x100], rax
00007263fffce78b  jmp 0x00007263FFDFE110
00007263fffce790  int3
00007263fffce791  ucomisd xmm1, xmm15
00007263fffce796  jp 0x00007263FFFCE7A5
00007263fffce798  movaps xmm14, [0x00007263FFBFE030]
00007263fffce7a0  jmp 0x00007263FFFCE6F8
00007263fffce7a5  vxorps xmm0, xmm1, xmm15
00007263fffce7aa  pextrw eax, xmm0, 0x03
00007263fffce7af  and eax, 0x7FF8
00007263fffce7b4  cmp eax, 0x08
00007263fffce7b7  jnz 0x00007263FFFCE6F8
00007263fffce7bd  movq rax, xmm15
00007263fffce7c2  shl rax, 0x0D
00007263fffce7c6  jbe 0x00007263FFFCE6F8
00007263fffce7cc  vorps xmm14, xmm15, [0x00007263FFBFE040]
00007263fffce7d4  jmp 0x00007263FFFCE6F8
00007263fffce7d9  int3
00007263fffce7da  nop [rax+rax*1], ax
00007263fffce7e0  movaps xmm1, [r15+0x110]
00007263fffce7e8  movq rax, xmm1
00007263fffce7ed  movaps xmm1, [r15+0x120]
00007263fffce7f5  movq r14, xmm1
00007263fffce7fa  vmovq xmm1, rax
00007263fffce7ff  vmovq xmm15, r14
00007263fffce804  movaps xmm14, xmm1
00007263fffce808  addsd xmm14, xmm15
00007263fffce80d  ucomisd xmm14, xmm14
00007263fffce812  jp 0x00007263FFFCE8B9
00007263fffce818  movq xmm14, xmm14
00007263fffce81d  movaps [r15+0x110], xmm14
00007263fffce825  mov rax, [r15+0x08]
00007263fffce829  mov [rsp+0x10], rax
00007263fffce82e  xor eax, eax
00007263fffce830  mov r14, [rsp+0x10]
00007263fffce835  mov r12d, 0x01
00007263fffce83b  sub r14, r12
00007263fffce83e  cmc
00007263fffce83f  lahf
00007263fffce840  seto al
00007263fffce843  mov [r15+0x108], eax
00007263fffce84a  mov [r15+0x08], r14
00007263fffce84e  mov eax, [r15+0x108]
00007263fffce855  sahf
00007263fffce856  jnz 0x00007263FFFCE888
00007263fffce858  cmp dword ptr [r15+0x318], 0x00
00007263fffce860  jz 0x00007263FFFCE910
00007263fffce866  nop [rax+rax*1], ax
00007263fffce86f  nop [rax+rax*1], eax
00007263fffce877  mov eax, 0x410050
00007263fffce87c  mov [r15+0x100], rax
00007263fffce883  jmp 0x00007263FFDFE110
00007263fffce888  cmp dword ptr [r15+0x318], 0x00
00007263fffce890  jz 0x00007263FFFCE7E0
00007263fffce896  nop [rax+rax*1], ax
00007263fffce89f  nop [rax+rax*1], eax
00007263fffce8a7  mov eax, 0x410044
00007263fffce8ac  mov [r15+0x100], rax
00007263fffce8b3  jmp 0x00007263FFDFE110
00007263fffce8b8  int3
00007263fffce8b9  ucomisd xmm1, xmm15
00007263fffce8be  jp 0x00007263FFFCE8CD
00007263fffce8c0  movaps xmm14, [0x00007263FFBFE030]
00007263fffce8c8  jmp 0x00007263FFFCE818
00007263fffce8cd  vxorps xmm0, xmm1, xmm15
00007263fffce8d2  pextrw eax, xmm0, 0x03
00007263fffce8d7  and eax, 0x7FF8
00007263fffce8dc  cmp eax, 0x08
00007263fffce8df  jnz 0x00007263FFFCE818
00007263fffce8e5  movq rax, xmm15
00007263fffce8ea  shl rax, 0x0D
00007263fffce8ee  jbe 0x00007263FFFCE818
00007263fffce8f4  vorps xmm14, xmm15, [0x00007263FFBFE040]
00007263fffce8fc  jmp 0x00007263FFFCE818
00007263fffce901  int3
00007263fffce902  nop [rax+rax*1], ax
00007263fffce90b  nop [rax+rax*1], eax
00007263fffce910  mov rax, [r15+0x20]
00007263fffce914  movaps xmm1, [r15+0x110]
00007263fffce91c  movq r14, xmm1
00007263fffce921  mov [r13+rax*1], r14
00007263fffce926  mov rax, [r15+0xF0]
00007263fffce92d  mov [r15+0x100], rax
00007263fffce934  jmp 0x00007263FFFCE5C0
00007263fffce939  int3
00007263fffce93a  call 0x00007263FFE0E120
00007263fffce93f  jmp 0x00007263FFFCE926
00007263fffce944  int3
00007263fffce945  nop [rax+rax*1], ax
00007263fffce94e  nop
00007263fffce950  mov qword ptr [r15+0x100], 0x04
00007263fffce95b  mov esi, 0x00
00007263fffce960  mov edx, 0x09
00007263fffce965  mov rdi, 0x7FFEBE0CA090
00007263fffce96f  mov rax, 0x615A5CEE2970
00007263fffce979  call rax
00007263fffce97b  cmp dword ptr [r15+0x318], 0x00
00007263fffce983  jnz 0x00007263FFDFE110
00007263fffce989  jmp 0x00007263FFDFE0A0
00007263fffce98e  int3
00007263fffce98f  int3
