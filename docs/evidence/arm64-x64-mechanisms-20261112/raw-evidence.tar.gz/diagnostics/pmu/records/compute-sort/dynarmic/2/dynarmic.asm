000078dc9a5ce69b  nop [rax+rax*1], eax
000078dc9a5ce6a0  mov rax, [r15+0xF8]
000078dc9a5ce6a7  lea r14, [rax-0x20]
000078dc9a5ce6ab  mov r12, [r15+0xF0]
000078dc9a5ce6b2  mov [r13+r14*1], r12
000078dc9a5ce6b7  mov [r15+0xF8], r14
000078dc9a5ce6be  lea r14, [rax-0x10]
000078dc9a5ce6c2  mov r12, [r15+0xA0]
000078dc9a5ce6c9  mov r11, [r15+0x98]
000078dc9a5ce6d0  mov [r13+r14*1], r12
000078dc9a5ce6d5  lea r14, [rax-0x08]
000078dc9a5ce6d9  mov [r13+r14*1], r11
000078dc9a5ce6de  mov qword ptr [r15+0xA0], 0x00
000078dc9a5ce6e9  mov qword ptr [r15+0x98], 0x4202A0
000078dc9a5ce6f4  mov eax, [r15+0xA0]
000078dc9a5ce6fb  lea r14d, [eax+0x11]
000078dc9a5ce700  mov r14d, r14d
000078dc9a5ce703  mov [r15], r14
000078dc9a5ce706  mov qword ptr [r15+0xF0], 0x410184
000078dc9a5ce711  mov r14d, [r15+0x320]
000078dc9a5ce718  mov eax, 0x410184
000078dc9a5ce71d  mov rcx, 0x78DC9A5CE800
000078dc9a5ce727  mov [r15+r14*8+0x328], rax
000078dc9a5ce72f  mov [r15+r14*8+0x368], rcx
000078dc9a5ce737  add r14d, 0x01
000078dc9a5ce73b  and r14d, 0x07
000078dc9a5ce73f  mov [r15+0x320], r14d
000078dc9a5ce746  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ce74e  jz 0x000078DC9A5CE7A0
000078dc9a5ce754  nop [rax+rax*1], ax
000078dc9a5ce75d  nop [rax+rax*1], eax
000078dc9a5ce765  mov eax, 0x41021C
000078dc9a5ce76a  mov [r15+0x100], rax
000078dc9a5ce771  jmp 0x000078DC9A3FE110
000078dc9a5ce776  int3
000078dc9a5ce777  call 0x000078DC9A4E2CE0
000078dc9a5ce77c  jmp 0x000078DC9A5CE6B7
000078dc9a5ce781  call 0x000078DC9A4E2CE0
000078dc9a5ce786  jmp 0x000078DC9A5CE6D5
000078dc9a5ce78b  call 0x000078DC9A4E1A60
000078dc9a5ce790  jmp 0x000078DC9A5CE6DE
000078dc9a5ce795  int3
000078dc9a5ce796  nop [rax+rax*1], ax
000078dc9a5ce79f  nop
000078dc9a5ce7a0  mov eax, 0x846CA68B
000078dc9a5ce7a5  mov eax, eax
000078dc9a5ce7a7  mov [r15+0x48], rax
000078dc9a5ce7ab  mov eax, [r15]
000078dc9a5ce7ae  imul eax, eax, 0x7FEB352D
000078dc9a5ce7b4  mov [rsp+0x10], eax
000078dc9a5ce7b8  shr eax, 0x0F
000078dc9a5ce7bb  mov r14d, [rsp+0x10]
000078dc9a5ce7c0  xor r14d, eax
000078dc9a5ce7c3  imul r14d, r14d, 0x846CA68B
000078dc9a5ce7ca  mov [rsp+0x10], r14d
000078dc9a5ce7cf  mov r14d, r14d
000078dc9a5ce7d2  mov [r15+0x40], r14
000078dc9a5ce7d6  mov eax, [rsp+0x10]
000078dc9a5ce7da  shr eax, 0x10
000078dc9a5ce7dd  mov r14d, [rsp+0x10]
000078dc9a5ce7e2  xor r14d, eax
000078dc9a5ce7e5  mov r14d, r14d
000078dc9a5ce7e8  mov [r15], r14
000078dc9a5ce7eb  mov rax, [r15+0xF0]
000078dc9a5ce7f2  mov [r15+0x100], rax
000078dc9a5ce7f9  jmp 0x000078DC9A5CE5C0
000078dc9a5ce7fe  int3
000078dc9a5ce7ff  int3
000078dc9a5ce800  mov rax, [r15+0xA0]
000078dc9a5ce807  mov [rsp+0x10], rax
000078dc9a5ce80c  shl rax, 0x02
000078dc9a5ce810  mov r14, [r15+0x98]
000078dc9a5ce817  lea r12, [r14+rax*1]
000078dc9a5ce81b  mov eax, [r15]
000078dc9a5ce81e  mov [r13+r12*1], eax
000078dc9a5ce823  mov rax, [rsp+0x10]
000078dc9a5ce828  lea r14, [rax+0x01]
000078dc9a5ce82c  mov [r15+0xA0], r14
000078dc9a5ce833  xor eax, eax
000078dc9a5ce835  mov r12d, 0x400
000078dc9a5ce83b  cmp r14, r12
000078dc9a5ce83e  cmc
000078dc9a5ce83f  lahf
000078dc9a5ce840  seto al
000078dc9a5ce843  mov [r15+0x108], eax
000078dc9a5ce84a  mov eax, [r15+0x108]
000078dc9a5ce851  sahf
000078dc9a5ce852  jnz 0x000078DC9A5CE884
000078dc9a5ce854  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ce85c  jz 0x000078DC9A5CE950
000078dc9a5ce862  nop [rax+rax*1], ax
000078dc9a5ce86b  nop [rax+rax*1], eax
000078dc9a5ce873  mov eax, 0x410194
000078dc9a5ce878  mov [r15+0x100], rax
000078dc9a5ce87f  jmp 0x000078DC9A3FE110
000078dc9a5ce884  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ce88c  jz 0x000078DC9A5CE8C0
000078dc9a5ce892  nop [rax+rax*1], ax
000078dc9a5ce89b  nop [rax+rax*1], eax
000078dc9a5ce8a3  mov eax, 0x41017C
000078dc9a5ce8a8  mov [r15+0x100], rax
000078dc9a5ce8af  jmp 0x000078DC9A3FE110
000078dc9a5ce8b4  int3
000078dc9a5ce8b5  call 0x000078DC9A4B4B70
000078dc9a5ce8ba  jmp 0x000078DC9A5CE823
000078dc9a5ce8bf  int3
000078dc9a5ce8c0  mov eax, [r15+0xA0]
000078dc9a5ce8c7  lea r14d, [eax+0x11]
000078dc9a5ce8cc  mov r14d, r14d
000078dc9a5ce8cf  mov [r15], r14
000078dc9a5ce8d2  mov qword ptr [r15+0xF0], 0x410184
000078dc9a5ce8dd  mov r14d, [r15+0x320]
000078dc9a5ce8e4  mov eax, 0x410184
000078dc9a5ce8e9  mov rcx, 0x78DC9A5CE800
000078dc9a5ce8f3  mov [r15+r14*8+0x328], rax
000078dc9a5ce8fb  mov [r15+r14*8+0x368], rcx
000078dc9a5ce903  add r14d, 0x01
000078dc9a5ce907  and r14d, 0x07
000078dc9a5ce90b  mov [r15+0x320], r14d
000078dc9a5ce912  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ce91a  jz 0x000078DC9A5CE7A0
000078dc9a5ce920  nop [rax+rax*1], ax
000078dc9a5ce929  nop [rax+rax*1], eax
000078dc9a5ce931  mov eax, 0x41021C
000078dc9a5ce936  mov [r15+0x100], rax
000078dc9a5ce93d  jmp 0x000078DC9A3FE110
000078dc9a5ce942  int3
000078dc9a5ce943  int3
000078dc9a5ce944  nop [rax+rax*1], ax
000078dc9a5ce94d  nop [rax], eax
000078dc9a5ce950  mov qword ptr [r15+0x40], 0x01
000078dc9a5ce958  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ce960  jz 0x000078DC9A5CE990
000078dc9a5ce966  nop [rax+rax*1], ax
000078dc9a5ce96f  nop [rax+rax*1], eax
000078dc9a5ce977  mov eax, 0x4101B0
000078dc9a5ce97c  mov [r15+0x100], rax
000078dc9a5ce983  jmp 0x000078DC9A3FE110
000078dc9a5ce988  int3
000078dc9a5ce989  int3
000078dc9a5ce98a  nop [rax+rax*1], ax
000078dc9a5ce990  mov rax, [r15+0x40]
000078dc9a5ce994  mov [rsp+0x10], rax
000078dc9a5ce999  shl rax, 0x02
000078dc9a5ce99d  mov r14, [r15+0x98]
000078dc9a5ce9a4  lea r12, [r14+rax*1]
000078dc9a5ce9a8  mov eax, [r13+r12*1]
000078dc9a5ce9ad  mov [rsp+0x20], eax
000078dc9a5ce9b1  mov eax, eax
000078dc9a5ce9b3  mov [r15+0x48], rax
000078dc9a5ce9b7  mov rax, [rsp+0x10]
000078dc9a5ce9bc  mov [r15+0x50], rax
000078dc9a5ce9c0  mov eax, [r15+0x50]
000078dc9a5ce9c4  lea r12d, [eax-0x01]
000078dc9a5ce9c9  mov r12d, r12d
000078dc9a5ce9cc  mov [r15+0x58], r12
000078dc9a5ce9d0  mov rax, [r15+0x58]
000078dc9a5ce9d4  mov r12d, eax
000078dc9a5ce9d7  mov r12d, r12d
000078dc9a5ce9da  shl r12, 0x02
000078dc9a5ce9de  lea rax, [r14+r12*1]
000078dc9a5ce9e2  mov r14d, [r13+rax*1]
000078dc9a5ce9e7  mov [rsp+0x10], r14d
000078dc9a5ce9ec  mov r14d, r14d
000078dc9a5ce9ef  mov [r15+0x60], r14
000078dc9a5ce9f3  xor eax, eax
000078dc9a5ce9f5  mov r14d, [rsp+0x10]
000078dc9a5ce9fa  mov r12d, [rsp+0x20]
000078dc9a5ce9ff  cmp r14d, r12d
000078dc9a5cea02  cmc
000078dc9a5cea03  lahf
000078dc9a5cea04  seto al
000078dc9a5cea07  mov [r15+0x108], eax
000078dc9a5cea0e  mov eax, [r15+0x108]
000078dc9a5cea15  sahf
000078dc9a5cea16  cmc
000078dc9a5cea17  jbe 0x000078DC9A5CEA49
000078dc9a5cea19  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cea21  jz 0x000078DC9A5CEA90
000078dc9a5cea27  nop [rax+rax*1], ax
000078dc9a5cea30  nop [rax+rax*1], eax
000078dc9a5cea38  mov eax, 0x4101C8
000078dc9a5cea3d  mov [r15+0x100], rax
000078dc9a5cea44  jmp 0x000078DC9A3FE110
000078dc9a5cea49  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cea51  jz 0x000078DC9A5CED30
000078dc9a5cea57  nop [rax+rax*1], ax
000078dc9a5cea60  nop [rax+rax*1], eax
000078dc9a5cea68  mov eax, 0x4101A0
000078dc9a5cea6d  mov [r15+0x100], rax
000078dc9a5cea74  jmp 0x000078DC9A3FE110
000078dc9a5cea79  int3
000078dc9a5cea7a  call 0x000078DC9A4B4690
000078dc9a5cea7f  jmp 0x000078DC9A5CE9AD
000078dc9a5cea84  call 0x000078DC9A40DAE0
000078dc9a5cea89  jmp 0x000078DC9A5CE9E7
000078dc9a5cea8e  int3
000078dc9a5cea8f  nop
000078dc9a5cea90  mov rax, [r15+0x50]
000078dc9a5cea94  mov [rsp+0x10], rax
000078dc9a5cea99  shl rax, 0x02
000078dc9a5cea9d  mov r14, [r15+0x98]
000078dc9a5ceaa4  lea r12, [r14+rax*1]
000078dc9a5ceaa8  mov eax, [r15+0x60]
000078dc9a5ceaac  mov [r13+r12*1], eax
000078dc9a5ceab1  mov rax, [rsp+0x10]
000078dc9a5ceab6  lea r14, [rax-0x01]
000078dc9a5ceaba  mov [r15+0x50], r14
000078dc9a5ceabe  mov rax, [r15+0x58]
000078dc9a5ceac2  test rax, rax
000078dc9a5ceac5  setz al
000078dc9a5ceac8  movzx rax, al
000078dc9a5ceacc  mov [rsp+0x414], al
000078dc9a5cead3  cmp byte ptr [rsp+0x414], 0x00
000078dc9a5ceadb  jz 0x000078DC9A5CEB0D
000078dc9a5ceadd  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ceae5  jz 0x000078DC9A5CEB50
000078dc9a5ceaeb  nop [rax+rax*1], ax
000078dc9a5ceaf4  nop [rax+rax*1], eax
000078dc9a5ceafc  mov eax, 0x4101D4
000078dc9a5ceb01  mov [r15+0x100], rax
000078dc9a5ceb08  jmp 0x000078DC9A3FE110
000078dc9a5ceb0d  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ceb15  jz 0x000078DC9A5CEC50
000078dc9a5ceb1b  nop [rax+rax*1], ax
000078dc9a5ceb24  nop [rax+rax*1], eax
000078dc9a5ceb2c  mov eax, 0x4101B8
000078dc9a5ceb31  mov [r15+0x100], rax
000078dc9a5ceb38  jmp 0x000078DC9A3FE110
000078dc9a5ceb3d  int3
000078dc9a5ceb3e  call 0x000078DC9A4B4B70
000078dc9a5ceb43  jmp 0x000078DC9A5CEAB1
000078dc9a5ceb48  int3
000078dc9a5ceb49  nop [rax], eax
000078dc9a5ceb50  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ceb58  jz 0x000078DC9A5CEB90
000078dc9a5ceb5e  nop [rax+rax*1], ax
000078dc9a5ceb67  nop [rax+rax*1], eax
000078dc9a5ceb6f  mov eax, 0x41019C
000078dc9a5ceb74  mov [r15+0x100], rax
000078dc9a5ceb7b  jmp 0x000078DC9A3FE110
000078dc9a5ceb80  int3
000078dc9a5ceb81  int3
000078dc9a5ceb82  nop [rax+rax*1], ax
000078dc9a5ceb8b  nop [rax+rax*1], eax
000078dc9a5ceb90  mov qword ptr [r15+0x50], 0x00
000078dc9a5ceb98  mov rax, [r15+0x40]
000078dc9a5ceb9c  lea r14, [rax+0x01]
000078dc9a5ceba0  mov [r15+0x40], r14
000078dc9a5ceba4  mov rax, [r15+0x98]
000078dc9a5cebab  mov r12d, [r15+0x48]
000078dc9a5cebaf  mov [r13+rax*1], r12d
000078dc9a5cebb4  xor eax, eax
000078dc9a5cebb6  mov r12d, 0x400
000078dc9a5cebbc  cmp r14, r12
000078dc9a5cebbf  cmc
000078dc9a5cebc0  lahf
000078dc9a5cebc1  seto al
000078dc9a5cebc4  mov [r15+0x108], eax
000078dc9a5cebcb  mov eax, [r15+0x108]
000078dc9a5cebd2  sahf
000078dc9a5cebd3  jz 0x000078DC9A5CEC05
000078dc9a5cebd5  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cebdd  jz 0x000078DC9A5CE990
000078dc9a5cebe3  nop [rax+rax*1], ax
000078dc9a5cebec  nop [rax+rax*1], eax
000078dc9a5cebf4  mov eax, 0x4101B0
000078dc9a5cebf9  mov [r15+0x100], rax
000078dc9a5cec00  jmp 0x000078DC9A3FE110
000078dc9a5cec05  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cec0d  jz 0x000078DC9A5CEDF0
000078dc9a5cec13  nop [rax+rax*1], ax
000078dc9a5cec1c  nop [rax+rax*1], eax
000078dc9a5cec24  mov eax, 0x4101D8
000078dc9a5cec29  mov [r15+0x100], rax
000078dc9a5cec30  jmp 0x000078DC9A3FE110
000078dc9a5cec35  int3
000078dc9a5cec36  call 0x000078DC9A40BAE0
000078dc9a5cec3b  jmp 0x000078DC9A5CEBB4
000078dc9a5cec40  int3
000078dc9a5cec41  nop [rax+rax*1], ax
000078dc9a5cec4a  nop [rax+rax*1], ax
000078dc9a5cec50  mov eax, [r15+0x50]
000078dc9a5cec54  lea r14d, [eax-0x01]
000078dc9a5cec59  mov r14d, r14d
000078dc9a5cec5c  mov [r15+0x58], r14
000078dc9a5cec60  mov rax, [r15+0x58]
000078dc9a5cec64  mov r14d, eax
000078dc9a5cec67  mov r14d, r14d
000078dc9a5cec6a  shl r14, 0x02
000078dc9a5cec6e  mov rax, [r15+0x98]
000078dc9a5cec75  lea r12, [rax+r14*1]
000078dc9a5cec79  mov eax, [r13+r12*1]
000078dc9a5cec7e  mov [rsp+0x10], eax
000078dc9a5cec82  mov eax, eax
000078dc9a5cec84  mov [r15+0x60], rax
000078dc9a5cec88  mov eax, [r15+0x48]
000078dc9a5cec8c  mov [rsp+0x20], eax
000078dc9a5cec90  xor eax, eax
000078dc9a5cec92  mov r14d, [rsp+0x10]
000078dc9a5cec97  mov r12d, [rsp+0x20]
000078dc9a5cec9c  cmp r14d, r12d
000078dc9a5cec9f  cmc
000078dc9a5ceca0  lahf
000078dc9a5ceca1  seto al
000078dc9a5ceca4  mov [r15+0x108], eax
000078dc9a5cecab  mov eax, [r15+0x108]
000078dc9a5cecb2  sahf
000078dc9a5cecb3  cmc
000078dc9a5cecb4  jbe 0x000078DC9A5CECE6
000078dc9a5cecb6  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cecbe  jz 0x000078DC9A5CEA90
000078dc9a5cecc4  nop [rax+rax*1], ax
000078dc9a5ceccd  nop [rax+rax*1], eax
000078dc9a5cecd5  mov eax, 0x4101C8
000078dc9a5cecda  mov [r15+0x100], rax
000078dc9a5cece1  jmp 0x000078DC9A3FE110
000078dc9a5cece6  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cecee  jz 0x000078DC9A5CED30
000078dc9a5cecf4  nop [rax+rax*1], ax
000078dc9a5cecfd  nop [rax+rax*1], eax
000078dc9a5ced05  mov eax, 0x4101A0
000078dc9a5ced0a  mov [r15+0x100], rax
000078dc9a5ced11  jmp 0x000078DC9A3FE110
000078dc9a5ced16  int3
000078dc9a5ced17  call 0x000078DC9A4B4690
000078dc9a5ced1c  jmp 0x000078DC9A5CEC7E
000078dc9a5ced21  int3
000078dc9a5ced22  nop [rax+rax*1], ax
000078dc9a5ced2b  nop [rax+rax*1], eax
000078dc9a5ced30  mov rax, [r15+0x40]
000078dc9a5ced34  lea r14, [rax+0x01]
000078dc9a5ced38  mov [r15+0x40], r14
000078dc9a5ced3c  mov rax, [r15+0x50]
000078dc9a5ced40  mov r12d, eax
000078dc9a5ced43  mov r12d, r12d
000078dc9a5ced46  shl r12, 0x02
000078dc9a5ced4a  mov rax, [r15+0x98]
000078dc9a5ced51  lea r11, [rax+r12*1]
000078dc9a5ced55  mov eax, [r15+0x48]
000078dc9a5ced59  mov [r13+r11*1], eax
000078dc9a5ced5e  xor eax, eax
000078dc9a5ced60  mov r12d, 0x400
000078dc9a5ced66  cmp r14, r12
000078dc9a5ced69  cmc
000078dc9a5ced6a  lahf
000078dc9a5ced6b  seto al
000078dc9a5ced6e  mov [r15+0x108], eax
000078dc9a5ced75  mov eax, [r15+0x108]
000078dc9a5ced7c  sahf
000078dc9a5ced7d  jz 0x000078DC9A5CEDAF
000078dc9a5ced7f  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ced87  jz 0x000078DC9A5CE990
000078dc9a5ced8d  nop [rax+rax*1], ax
000078dc9a5ced96  nop [rax+rax*1], eax
000078dc9a5ced9e  mov eax, 0x4101B0
000078dc9a5ceda3  mov [r15+0x100], rax
000078dc9a5cedaa  jmp 0x000078DC9A3FE110
000078dc9a5cedaf  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cedb7  jz 0x000078DC9A5CEDF0
000078dc9a5cedbd  nop [rax+rax*1], ax
000078dc9a5cedc6  nop [rax+rax*1], eax
000078dc9a5cedce  mov eax, 0x4101D8
000078dc9a5cedd3  mov [r15+0x100], rax
000078dc9a5cedda  jmp 0x000078DC9A3FE110
000078dc9a5ceddf  int3
000078dc9a5cede0  call 0x000078DC9A4A4270
000078dc9a5cede5  jmp 0x000078DC9A5CED5E
000078dc9a5cedea  int3
000078dc9a5cedeb  nop [rax+rax*1], eax
000078dc9a5cedf0  mov qword ptr [r15+0x40], 0x420000
000078dc9a5cedf8  mov eax, 0x420288
000078dc9a5cedfd  mov r14, [r13+rax*1]
000078dc9a5cee02  mov rax, [r15+0x98]
000078dc9a5cee09  mov r12d, [r13+rax*1]
000078dc9a5cee0e  lea r11, [rax+0x04]
000078dc9a5cee12  mov eax, [r13+r11*1]
000078dc9a5cee17  mov r12d, r12d
000078dc9a5cee1a  mov [r15+0x68], r12
000078dc9a5cee1e  mov eax, eax
000078dc9a5cee20  mov [r15+0x60], rax
000078dc9a5cee24  mov rax, [r15+0x68]
000078dc9a5cee28  mov [r15+0x68], rax
000078dc9a5cee2c  mov qword ptr [r15+0x58], 0x02
000078dc9a5cee34  mov [rsp+0x10], rax
000078dc9a5cee39  xor eax, eax
000078dc9a5cee3b  mov r12d, 0x02
000078dc9a5cee41  mov r11d, 0x400
000078dc9a5cee47  cmp r12, r11
000078dc9a5cee4a  cmc
000078dc9a5cee4b  lahf
000078dc9a5cee4c  seto al
000078dc9a5cee4f  mov [r15+0x108], eax
000078dc9a5cee56  mov rax, [r15+0x60]
000078dc9a5cee5a  mov r12d, 0x02
000078dc9a5cee60  imul rax, r12
000078dc9a5cee64  mov [r15+0x50], rax
000078dc9a5cee68  mov rax, [rsp+0x10]
000078dc9a5cee6d  lea r12, [rax+r14*1]
000078dc9a5cee71  mov [r15+0x48], r12
000078dc9a5cee75  mov eax, [r15+0x108]
000078dc9a5cee7c  sahf
000078dc9a5cee7d  jnz 0x000078DC9A5CEEAF
000078dc9a5cee7f  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cee87  jz 0x000078DC9A5CF020
000078dc9a5cee8d  nop [rax+rax*1], ax
000078dc9a5cee96  nop [rax+rax*1], eax
000078dc9a5cee9e  mov eax, 0x410208
000078dc9a5ceea3  mov [r15+0x100], rax
000078dc9a5ceeaa  jmp 0x000078DC9A3FE110
000078dc9a5ceeaf  cmp dword ptr [r15+0x318], 0x00
000078dc9a5ceeb7  jz 0x000078DC9A5CEF00
000078dc9a5ceebd  nop [rax+rax*1], ax
000078dc9a5ceec6  nop [rax+rax*1], eax
000078dc9a5ceece  mov eax, 0x4101E8
000078dc9a5ceed3  mov [r15+0x100], rax
000078dc9a5ceeda  jmp 0x000078DC9A3FE110
000078dc9a5ceedf  int3
000078dc9a5ceee0  call 0x000078DC9A40DC20
000078dc9a5ceee5  jmp 0x000078DC9A5CEE02
000078dc9a5ceeea  call 0x000078DC9A40B5E0
000078dc9a5ceeef  jmp 0x000078DC9A5CEE0E
000078dc9a5ceef4  call 0x000078DC9A4A3D90
000078dc9a5ceef9  jmp 0x000078DC9A5CEE17
000078dc9a5ceefe  int3
000078dc9a5ceeff  nop
000078dc9a5cef00  mov rax, [r15+0x98]
000078dc9a5cef07  mov r14, [r15+0x58]
000078dc9a5cef0b  mov [rsp+0x10], r14
000078dc9a5cef10  shl r14, 0x02
000078dc9a5cef14  lea r12, [rax+r14*1]
000078dc9a5cef18  mov eax, [r13+r12*1]
000078dc9a5cef1d  lea r14, [r12+0x04]
000078dc9a5cef22  mov r12d, [r13+r14*1]
000078dc9a5cef27  mov eax, eax
000078dc9a5cef29  mov [r15+0x68], rax
000078dc9a5cef2d  mov r12d, r12d
000078dc9a5cef30  mov [r15+0x60], r12
000078dc9a5cef34  mov rax, [r15+0x68]
000078dc9a5cef38  mov [rsp+0x20], rax
000078dc9a5cef3d  mov r14, [rsp+0x10]
000078dc9a5cef42  imul rax, r14
000078dc9a5cef46  mov r12, [rsp+0x20]
000078dc9a5cef4b  lea r11, [r12+rax*1]
000078dc9a5cef4f  mov [r15+0x68], r11
000078dc9a5cef53  lea rax, [r14+0x02]
000078dc9a5cef57  mov [r15+0x58], rax
000078dc9a5cef5b  mov [rsp+0x10], rax
000078dc9a5cef60  xor eax, eax
000078dc9a5cef62  mov r14, [rsp+0x10]
000078dc9a5cef67  mov r12d, 0x400
000078dc9a5cef6d  cmp r14, r12
000078dc9a5cef70  cmc
000078dc9a5cef71  lahf
000078dc9a5cef72  seto al
000078dc9a5cef75  mov [r15+0x108], eax
000078dc9a5cef7c  mov rax, [r15+0x50]
000078dc9a5cef80  mov r12, [r15+0x60]
000078dc9a5cef84  imul r14, r12
000078dc9a5cef88  lea r12, [rax+r14*1]
000078dc9a5cef8c  mov [r15+0x50], r12
000078dc9a5cef90  mov rax, [r15+0x48]
000078dc9a5cef94  lea r14, [r11+rax*1]
000078dc9a5cef98  mov [r15+0x48], r14
000078dc9a5cef9c  mov eax, [r15+0x108]
000078dc9a5cefa3  sahf
000078dc9a5cefa4  jnz 0x000078DC9A5CEFD6
000078dc9a5cefa6  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cefae  jz 0x000078DC9A5CF020
000078dc9a5cefb4  nop [rax+rax*1], ax
000078dc9a5cefbd  nop [rax+rax*1], eax
000078dc9a5cefc5  mov eax, 0x410208
000078dc9a5cefca  mov [r15+0x100], rax
000078dc9a5cefd1  jmp 0x000078DC9A3FE110
000078dc9a5cefd6  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cefde  jz 0x000078DC9A5CEF00
000078dc9a5cefe4  nop [rax+rax*1], ax
000078dc9a5cefed  nop [rax+rax*1], eax
000078dc9a5ceff5  mov eax, 0x4101E8
000078dc9a5ceffa  mov [r15+0x100], rax
000078dc9a5cf001  jmp 0x000078DC9A3FE110
000078dc9a5cf006  int3
000078dc9a5cf007  call 0x000078DC9A4B4690
000078dc9a5cf00c  jmp 0x000078DC9A5CEF1D
000078dc9a5cf011  call 0x000078DC9A4E26A0
000078dc9a5cf016  jmp 0x000078DC9A5CEF27
000078dc9a5cf01b  int3
000078dc9a5cf01c  nop [rax], eax
000078dc9a5cf020  mov rax, [r15+0xF8]
000078dc9a5cf027  lea r14, [rax+0x10]
000078dc9a5cf02b  mov r12, [r13+r14*1]
000078dc9a5cf030  lea r14, [rax+0x18]
000078dc9a5cf034  mov r11, [r13+r14*1]
000078dc9a5cf039  mov [r15+0xA0], r12
000078dc9a5cf040  mov [r15+0x98], r11
000078dc9a5cf047  mov r14, [r15+0x50]
000078dc9a5cf04b  mov r12, [r15+0x48]
000078dc9a5cf04f  lea r11, [r14+r12*1]
000078dc9a5cf053  mov [r15+0x48], r11
000078dc9a5cf057  mov r14, [r15+0x40]
000078dc9a5cf05b  lea r12, [r14+0x288]
000078dc9a5cf062  mov [r13+r12*1], r11
000078dc9a5cf067  mov r14, [r13+rax*1]
000078dc9a5cf06c  mov [r15+0xF0], r14
000078dc9a5cf073  lea r12, [rax+0x20]
000078dc9a5cf077  mov [r15+0xF8], r12
000078dc9a5cf07e  mov [r15+0x100], r14
000078dc9a5cf085  jmp 0x000078DC9A5CE5C0
000078dc9a5cf08a  int3
000078dc9a5cf08b  call 0x000078DC9A4E27E0
000078dc9a5cf090  jmp 0x000078DC9A5CF030
000078dc9a5cf095  call 0x000078DC9A4E1570
000078dc9a5cf09a  jmp 0x000078DC9A5CF039
000078dc9a5cf09f  call 0x000078DC9A4C0860
000078dc9a5cf0a4  jmp 0x000078DC9A5CF067
000078dc9a5cf0a9  call 0x000078DC9A40DC20
000078dc9a5cf0ae  jmp 0x000078DC9A5CF06C
000078dc9a5cf0b3  int3
000078dc9a5cf0b4  nop [rax+rax*1], ax
000078dc9a5cf0bd  nop [rax], eax
000078dc9a5cf0c0  mov qword ptr [r15+0x100], 0x04
000078dc9a5cf0cb  mov esi, 0x00
000078dc9a5cf0d0  mov edx, 0x09
000078dc9a5cf0d5  mov rdi, 0x7FFE396C8560
000078dc9a5cf0df  mov rax, 0x5D914FE5C970
000078dc9a5cf0e9  call rax
000078dc9a5cf0eb  cmp dword ptr [r15+0x318], 0x00
000078dc9a5cf0f3  jnz 0x000078DC9A3FE110
000078dc9a5cf0f9  jmp 0x000078DC9A3FE0A0
000078dc9a5cf0fe  int3
000078dc9a5cf0ff  int3
