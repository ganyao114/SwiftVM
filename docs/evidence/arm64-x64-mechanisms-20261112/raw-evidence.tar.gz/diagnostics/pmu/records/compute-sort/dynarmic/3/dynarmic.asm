000071ff35fce69b  nop [rax+rax*1], eax
000071ff35fce6a0  mov rax, [r15+0xF8]
000071ff35fce6a7  lea r14, [rax-0x20]
000071ff35fce6ab  mov r12, [r15+0xF0]
000071ff35fce6b2  mov [r13+r14*1], r12
000071ff35fce6b7  mov [r15+0xF8], r14
000071ff35fce6be  lea r14, [rax-0x10]
000071ff35fce6c2  mov r12, [r15+0xA0]
000071ff35fce6c9  mov r11, [r15+0x98]
000071ff35fce6d0  mov [r13+r14*1], r12
000071ff35fce6d5  lea r14, [rax-0x08]
000071ff35fce6d9  mov [r13+r14*1], r11
000071ff35fce6de  mov qword ptr [r15+0xA0], 0x00
000071ff35fce6e9  mov qword ptr [r15+0x98], 0x4202A0
000071ff35fce6f4  mov eax, [r15+0xA0]
000071ff35fce6fb  lea r14d, [eax+0x11]
000071ff35fce700  mov r14d, r14d
000071ff35fce703  mov [r15], r14
000071ff35fce706  mov qword ptr [r15+0xF0], 0x410184
000071ff35fce711  mov r14d, [r15+0x320]
000071ff35fce718  mov eax, 0x410184
000071ff35fce71d  mov rcx, 0x71FF35FCE800
000071ff35fce727  mov [r15+r14*8+0x328], rax
000071ff35fce72f  mov [r15+r14*8+0x368], rcx
000071ff35fce737  add r14d, 0x01
000071ff35fce73b  and r14d, 0x07
000071ff35fce73f  mov [r15+0x320], r14d
000071ff35fce746  cmp dword ptr [r15+0x318], 0x00
000071ff35fce74e  jz 0x000071FF35FCE7A0
000071ff35fce754  nop [rax+rax*1], ax
000071ff35fce75d  nop [rax+rax*1], eax
000071ff35fce765  mov eax, 0x41021C
000071ff35fce76a  mov [r15+0x100], rax
000071ff35fce771  jmp 0x000071FF35DFE110
000071ff35fce776  int3
000071ff35fce777  call 0x000071FF35EE2CE0
000071ff35fce77c  jmp 0x000071FF35FCE6B7
000071ff35fce781  call 0x000071FF35EE2CE0
000071ff35fce786  jmp 0x000071FF35FCE6D5
000071ff35fce78b  call 0x000071FF35EE1A60
000071ff35fce790  jmp 0x000071FF35FCE6DE
000071ff35fce795  int3
000071ff35fce796  nop [rax+rax*1], ax
000071ff35fce79f  nop
000071ff35fce7a0  mov eax, 0x846CA68B
000071ff35fce7a5  mov eax, eax
000071ff35fce7a7  mov [r15+0x48], rax
000071ff35fce7ab  mov eax, [r15]
000071ff35fce7ae  imul eax, eax, 0x7FEB352D
000071ff35fce7b4  mov [rsp+0x10], eax
000071ff35fce7b8  shr eax, 0x0F
000071ff35fce7bb  mov r14d, [rsp+0x10]
000071ff35fce7c0  xor r14d, eax
000071ff35fce7c3  imul r14d, r14d, 0x846CA68B
000071ff35fce7ca  mov [rsp+0x10], r14d
000071ff35fce7cf  mov r14d, r14d
000071ff35fce7d2  mov [r15+0x40], r14
000071ff35fce7d6  mov eax, [rsp+0x10]
000071ff35fce7da  shr eax, 0x10
000071ff35fce7dd  mov r14d, [rsp+0x10]
000071ff35fce7e2  xor r14d, eax
000071ff35fce7e5  mov r14d, r14d
000071ff35fce7e8  mov [r15], r14
000071ff35fce7eb  mov rax, [r15+0xF0]
000071ff35fce7f2  mov [r15+0x100], rax
000071ff35fce7f9  jmp 0x000071FF35FCE5C0
000071ff35fce7fe  int3
000071ff35fce7ff  int3
000071ff35fce800  mov rax, [r15+0xA0]
000071ff35fce807  mov [rsp+0x10], rax
000071ff35fce80c  shl rax, 0x02
000071ff35fce810  mov r14, [r15+0x98]
000071ff35fce817  lea r12, [r14+rax*1]
000071ff35fce81b  mov eax, [r15]
000071ff35fce81e  mov [r13+r12*1], eax
000071ff35fce823  mov rax, [rsp+0x10]
000071ff35fce828  lea r14, [rax+0x01]
000071ff35fce82c  mov [r15+0xA0], r14
000071ff35fce833  xor eax, eax
000071ff35fce835  mov r12d, 0x400
000071ff35fce83b  cmp r14, r12
000071ff35fce83e  cmc
000071ff35fce83f  lahf
000071ff35fce840  seto al
000071ff35fce843  mov [r15+0x108], eax
000071ff35fce84a  mov eax, [r15+0x108]
000071ff35fce851  sahf
000071ff35fce852  jnz 0x000071FF35FCE884
000071ff35fce854  cmp dword ptr [r15+0x318], 0x00
000071ff35fce85c  jz 0x000071FF35FCE950
000071ff35fce862  nop [rax+rax*1], ax
000071ff35fce86b  nop [rax+rax*1], eax
000071ff35fce873  mov eax, 0x410194
000071ff35fce878  mov [r15+0x100], rax
000071ff35fce87f  jmp 0x000071FF35DFE110
000071ff35fce884  cmp dword ptr [r15+0x318], 0x00
000071ff35fce88c  jz 0x000071FF35FCE8C0
000071ff35fce892  nop [rax+rax*1], ax
000071ff35fce89b  nop [rax+rax*1], eax
000071ff35fce8a3  mov eax, 0x41017C
000071ff35fce8a8  mov [r15+0x100], rax
000071ff35fce8af  jmp 0x000071FF35DFE110
000071ff35fce8b4  int3
000071ff35fce8b5  call 0x000071FF35EB4B70
000071ff35fce8ba  jmp 0x000071FF35FCE823
000071ff35fce8bf  int3
000071ff35fce8c0  mov eax, [r15+0xA0]
000071ff35fce8c7  lea r14d, [eax+0x11]
000071ff35fce8cc  mov r14d, r14d
000071ff35fce8cf  mov [r15], r14
000071ff35fce8d2  mov qword ptr [r15+0xF0], 0x410184
000071ff35fce8dd  mov r14d, [r15+0x320]
000071ff35fce8e4  mov eax, 0x410184
000071ff35fce8e9  mov rcx, 0x71FF35FCE800
000071ff35fce8f3  mov [r15+r14*8+0x328], rax
000071ff35fce8fb  mov [r15+r14*8+0x368], rcx
000071ff35fce903  add r14d, 0x01
000071ff35fce907  and r14d, 0x07
000071ff35fce90b  mov [r15+0x320], r14d
000071ff35fce912  cmp dword ptr [r15+0x318], 0x00
000071ff35fce91a  jz 0x000071FF35FCE7A0
000071ff35fce920  nop [rax+rax*1], ax
000071ff35fce929  nop [rax+rax*1], eax
000071ff35fce931  mov eax, 0x41021C
000071ff35fce936  mov [r15+0x100], rax
000071ff35fce93d  jmp 0x000071FF35DFE110
000071ff35fce942  int3
000071ff35fce943  int3
000071ff35fce944  nop [rax+rax*1], ax
000071ff35fce94d  nop [rax], eax
000071ff35fce950  mov qword ptr [r15+0x40], 0x01
000071ff35fce958  cmp dword ptr [r15+0x318], 0x00
000071ff35fce960  jz 0x000071FF35FCE990
000071ff35fce966  nop [rax+rax*1], ax
000071ff35fce96f  nop [rax+rax*1], eax
000071ff35fce977  mov eax, 0x4101B0
000071ff35fce97c  mov [r15+0x100], rax
000071ff35fce983  jmp 0x000071FF35DFE110
000071ff35fce988  int3
000071ff35fce989  int3
000071ff35fce98a  nop [rax+rax*1], ax
000071ff35fce990  mov rax, [r15+0x40]
000071ff35fce994  mov [rsp+0x10], rax
000071ff35fce999  shl rax, 0x02
000071ff35fce99d  mov r14, [r15+0x98]
000071ff35fce9a4  lea r12, [r14+rax*1]
000071ff35fce9a8  mov eax, [r13+r12*1]
000071ff35fce9ad  mov [rsp+0x20], eax
000071ff35fce9b1  mov eax, eax
000071ff35fce9b3  mov [r15+0x48], rax
000071ff35fce9b7  mov rax, [rsp+0x10]
000071ff35fce9bc  mov [r15+0x50], rax
000071ff35fce9c0  mov eax, [r15+0x50]
000071ff35fce9c4  lea r12d, [eax-0x01]
000071ff35fce9c9  mov r12d, r12d
000071ff35fce9cc  mov [r15+0x58], r12
000071ff35fce9d0  mov rax, [r15+0x58]
000071ff35fce9d4  mov r12d, eax
000071ff35fce9d7  mov r12d, r12d
000071ff35fce9da  shl r12, 0x02
000071ff35fce9de  lea rax, [r14+r12*1]
000071ff35fce9e2  mov r14d, [r13+rax*1]
000071ff35fce9e7  mov [rsp+0x10], r14d
000071ff35fce9ec  mov r14d, r14d
000071ff35fce9ef  mov [r15+0x60], r14
000071ff35fce9f3  xor eax, eax
000071ff35fce9f5  mov r14d, [rsp+0x10]
000071ff35fce9fa  mov r12d, [rsp+0x20]
000071ff35fce9ff  cmp r14d, r12d
000071ff35fcea02  cmc
000071ff35fcea03  lahf
000071ff35fcea04  seto al
000071ff35fcea07  mov [r15+0x108], eax
000071ff35fcea0e  mov eax, [r15+0x108]
000071ff35fcea15  sahf
000071ff35fcea16  cmc
000071ff35fcea17  jbe 0x000071FF35FCEA49
000071ff35fcea19  cmp dword ptr [r15+0x318], 0x00
000071ff35fcea21  jz 0x000071FF35FCEA90
000071ff35fcea27  nop [rax+rax*1], ax
000071ff35fcea30  nop [rax+rax*1], eax
000071ff35fcea38  mov eax, 0x4101C8
000071ff35fcea3d  mov [r15+0x100], rax
000071ff35fcea44  jmp 0x000071FF35DFE110
000071ff35fcea49  cmp dword ptr [r15+0x318], 0x00
000071ff35fcea51  jz 0x000071FF35FCED30
000071ff35fcea57  nop [rax+rax*1], ax
000071ff35fcea60  nop [rax+rax*1], eax
000071ff35fcea68  mov eax, 0x4101A0
000071ff35fcea6d  mov [r15+0x100], rax
000071ff35fcea74  jmp 0x000071FF35DFE110
000071ff35fcea79  int3
000071ff35fcea7a  call 0x000071FF35EB4690
000071ff35fcea7f  jmp 0x000071FF35FCE9AD
000071ff35fcea84  call 0x000071FF35E0DAE0
000071ff35fcea89  jmp 0x000071FF35FCE9E7
000071ff35fcea8e  int3
000071ff35fcea8f  nop
000071ff35fcea90  mov rax, [r15+0x50]
000071ff35fcea94  mov [rsp+0x10], rax
000071ff35fcea99  shl rax, 0x02
000071ff35fcea9d  mov r14, [r15+0x98]
000071ff35fceaa4  lea r12, [r14+rax*1]
000071ff35fceaa8  mov eax, [r15+0x60]
000071ff35fceaac  mov [r13+r12*1], eax
000071ff35fceab1  mov rax, [rsp+0x10]
000071ff35fceab6  lea r14, [rax-0x01]
000071ff35fceaba  mov [r15+0x50], r14
000071ff35fceabe  mov rax, [r15+0x58]
000071ff35fceac2  test rax, rax
000071ff35fceac5  setz al
000071ff35fceac8  movzx rax, al
000071ff35fceacc  mov [rsp+0x414], al
000071ff35fcead3  cmp byte ptr [rsp+0x414], 0x00
000071ff35fceadb  jz 0x000071FF35FCEB0D
000071ff35fceadd  cmp dword ptr [r15+0x318], 0x00
000071ff35fceae5  jz 0x000071FF35FCEB50
000071ff35fceaeb  nop [rax+rax*1], ax
000071ff35fceaf4  nop [rax+rax*1], eax
000071ff35fceafc  mov eax, 0x4101D4
000071ff35fceb01  mov [r15+0x100], rax
000071ff35fceb08  jmp 0x000071FF35DFE110
000071ff35fceb0d  cmp dword ptr [r15+0x318], 0x00
000071ff35fceb15  jz 0x000071FF35FCEC50
000071ff35fceb1b  nop [rax+rax*1], ax
000071ff35fceb24  nop [rax+rax*1], eax
000071ff35fceb2c  mov eax, 0x4101B8
000071ff35fceb31  mov [r15+0x100], rax
000071ff35fceb38  jmp 0x000071FF35DFE110
000071ff35fceb3d  int3
000071ff35fceb3e  call 0x000071FF35EB4B70
000071ff35fceb43  jmp 0x000071FF35FCEAB1
000071ff35fceb48  int3
000071ff35fceb49  nop [rax], eax
000071ff35fceb50  cmp dword ptr [r15+0x318], 0x00
000071ff35fceb58  jz 0x000071FF35FCEB90
000071ff35fceb5e  nop [rax+rax*1], ax
000071ff35fceb67  nop [rax+rax*1], eax
000071ff35fceb6f  mov eax, 0x41019C
000071ff35fceb74  mov [r15+0x100], rax
000071ff35fceb7b  jmp 0x000071FF35DFE110
000071ff35fceb80  int3
000071ff35fceb81  int3
000071ff35fceb82  nop [rax+rax*1], ax
000071ff35fceb8b  nop [rax+rax*1], eax
000071ff35fceb90  mov qword ptr [r15+0x50], 0x00
000071ff35fceb98  mov rax, [r15+0x40]
000071ff35fceb9c  lea r14, [rax+0x01]
000071ff35fceba0  mov [r15+0x40], r14
000071ff35fceba4  mov rax, [r15+0x98]
000071ff35fcebab  mov r12d, [r15+0x48]
000071ff35fcebaf  mov [r13+rax*1], r12d
000071ff35fcebb4  xor eax, eax
000071ff35fcebb6  mov r12d, 0x400
000071ff35fcebbc  cmp r14, r12
000071ff35fcebbf  cmc
000071ff35fcebc0  lahf
000071ff35fcebc1  seto al
000071ff35fcebc4  mov [r15+0x108], eax
000071ff35fcebcb  mov eax, [r15+0x108]
000071ff35fcebd2  sahf
000071ff35fcebd3  jz 0x000071FF35FCEC05
000071ff35fcebd5  cmp dword ptr [r15+0x318], 0x00
000071ff35fcebdd  jz 0x000071FF35FCE990
000071ff35fcebe3  nop [rax+rax*1], ax
000071ff35fcebec  nop [rax+rax*1], eax
000071ff35fcebf4  mov eax, 0x4101B0
000071ff35fcebf9  mov [r15+0x100], rax
000071ff35fcec00  jmp 0x000071FF35DFE110
000071ff35fcec05  cmp dword ptr [r15+0x318], 0x00
000071ff35fcec0d  jz 0x000071FF35FCEDF0
000071ff35fcec13  nop [rax+rax*1], ax
000071ff35fcec1c  nop [rax+rax*1], eax
000071ff35fcec24  mov eax, 0x4101D8
000071ff35fcec29  mov [r15+0x100], rax
000071ff35fcec30  jmp 0x000071FF35DFE110
000071ff35fcec35  int3
000071ff35fcec36  call 0x000071FF35E0BAE0
000071ff35fcec3b  jmp 0x000071FF35FCEBB4
000071ff35fcec40  int3
000071ff35fcec41  nop [rax+rax*1], ax
000071ff35fcec4a  nop [rax+rax*1], ax
000071ff35fcec50  mov eax, [r15+0x50]
000071ff35fcec54  lea r14d, [eax-0x01]
000071ff35fcec59  mov r14d, r14d
000071ff35fcec5c  mov [r15+0x58], r14
000071ff35fcec60  mov rax, [r15+0x58]
000071ff35fcec64  mov r14d, eax
000071ff35fcec67  mov r14d, r14d
000071ff35fcec6a  shl r14, 0x02
000071ff35fcec6e  mov rax, [r15+0x98]
000071ff35fcec75  lea r12, [rax+r14*1]
000071ff35fcec79  mov eax, [r13+r12*1]
000071ff35fcec7e  mov [rsp+0x10], eax
000071ff35fcec82  mov eax, eax
000071ff35fcec84  mov [r15+0x60], rax
000071ff35fcec88  mov eax, [r15+0x48]
000071ff35fcec8c  mov [rsp+0x20], eax
000071ff35fcec90  xor eax, eax
000071ff35fcec92  mov r14d, [rsp+0x10]
000071ff35fcec97  mov r12d, [rsp+0x20]
000071ff35fcec9c  cmp r14d, r12d
000071ff35fcec9f  cmc
000071ff35fceca0  lahf
000071ff35fceca1  seto al
000071ff35fceca4  mov [r15+0x108], eax
000071ff35fcecab  mov eax, [r15+0x108]
000071ff35fcecb2  sahf
000071ff35fcecb3  cmc
000071ff35fcecb4  jbe 0x000071FF35FCECE6
000071ff35fcecb6  cmp dword ptr [r15+0x318], 0x00
000071ff35fcecbe  jz 0x000071FF35FCEA90
000071ff35fcecc4  nop [rax+rax*1], ax
000071ff35fceccd  nop [rax+rax*1], eax
000071ff35fcecd5  mov eax, 0x4101C8
000071ff35fcecda  mov [r15+0x100], rax
000071ff35fcece1  jmp 0x000071FF35DFE110
000071ff35fcece6  cmp dword ptr [r15+0x318], 0x00
000071ff35fcecee  jz 0x000071FF35FCED30
000071ff35fcecf4  nop [rax+rax*1], ax
000071ff35fcecfd  nop [rax+rax*1], eax
000071ff35fced05  mov eax, 0x4101A0
000071ff35fced0a  mov [r15+0x100], rax
000071ff35fced11  jmp 0x000071FF35DFE110
000071ff35fced16  int3
000071ff35fced17  call 0x000071FF35EB4690
000071ff35fced1c  jmp 0x000071FF35FCEC7E
000071ff35fced21  int3
000071ff35fced22  nop [rax+rax*1], ax
000071ff35fced2b  nop [rax+rax*1], eax
000071ff35fced30  mov rax, [r15+0x40]
000071ff35fced34  lea r14, [rax+0x01]
000071ff35fced38  mov [r15+0x40], r14
000071ff35fced3c  mov rax, [r15+0x50]
000071ff35fced40  mov r12d, eax
000071ff35fced43  mov r12d, r12d
000071ff35fced46  shl r12, 0x02
000071ff35fced4a  mov rax, [r15+0x98]
000071ff35fced51  lea r11, [rax+r12*1]
000071ff35fced55  mov eax, [r15+0x48]
000071ff35fced59  mov [r13+r11*1], eax
000071ff35fced5e  xor eax, eax
000071ff35fced60  mov r12d, 0x400
000071ff35fced66  cmp r14, r12
000071ff35fced69  cmc
000071ff35fced6a  lahf
000071ff35fced6b  seto al
000071ff35fced6e  mov [r15+0x108], eax
000071ff35fced75  mov eax, [r15+0x108]
000071ff35fced7c  sahf
000071ff35fced7d  jz 0x000071FF35FCEDAF
000071ff35fced7f  cmp dword ptr [r15+0x318], 0x00
000071ff35fced87  jz 0x000071FF35FCE990
000071ff35fced8d  nop [rax+rax*1], ax
000071ff35fced96  nop [rax+rax*1], eax
000071ff35fced9e  mov eax, 0x4101B0
000071ff35fceda3  mov [r15+0x100], rax
000071ff35fcedaa  jmp 0x000071FF35DFE110
000071ff35fcedaf  cmp dword ptr [r15+0x318], 0x00
000071ff35fcedb7  jz 0x000071FF35FCEDF0
000071ff35fcedbd  nop [rax+rax*1], ax
000071ff35fcedc6  nop [rax+rax*1], eax
000071ff35fcedce  mov eax, 0x4101D8
000071ff35fcedd3  mov [r15+0x100], rax
000071ff35fcedda  jmp 0x000071FF35DFE110
000071ff35fceddf  int3
000071ff35fcede0  call 0x000071FF35EA4270
000071ff35fcede5  jmp 0x000071FF35FCED5E
000071ff35fcedea  int3
000071ff35fcedeb  nop [rax+rax*1], eax
000071ff35fcedf0  mov qword ptr [r15+0x40], 0x420000
000071ff35fcedf8  mov eax, 0x420288
000071ff35fcedfd  mov r14, [r13+rax*1]
000071ff35fcee02  mov rax, [r15+0x98]
000071ff35fcee09  mov r12d, [r13+rax*1]
000071ff35fcee0e  lea r11, [rax+0x04]
000071ff35fcee12  mov eax, [r13+r11*1]
000071ff35fcee17  mov r12d, r12d
000071ff35fcee1a  mov [r15+0x68], r12
000071ff35fcee1e  mov eax, eax
000071ff35fcee20  mov [r15+0x60], rax
000071ff35fcee24  mov rax, [r15+0x68]
000071ff35fcee28  mov [r15+0x68], rax
000071ff35fcee2c  mov qword ptr [r15+0x58], 0x02
000071ff35fcee34  mov [rsp+0x10], rax
000071ff35fcee39  xor eax, eax
000071ff35fcee3b  mov r12d, 0x02
000071ff35fcee41  mov r11d, 0x400
000071ff35fcee47  cmp r12, r11
000071ff35fcee4a  cmc
000071ff35fcee4b  lahf
000071ff35fcee4c  seto al
000071ff35fcee4f  mov [r15+0x108], eax
000071ff35fcee56  mov rax, [r15+0x60]
000071ff35fcee5a  mov r12d, 0x02
000071ff35fcee60  imul rax, r12
000071ff35fcee64  mov [r15+0x50], rax
000071ff35fcee68  mov rax, [rsp+0x10]
000071ff35fcee6d  lea r12, [rax+r14*1]
000071ff35fcee71  mov [r15+0x48], r12
000071ff35fcee75  mov eax, [r15+0x108]
000071ff35fcee7c  sahf
000071ff35fcee7d  jnz 0x000071FF35FCEEAF
000071ff35fcee7f  cmp dword ptr [r15+0x318], 0x00
000071ff35fcee87  jz 0x000071FF35FCF020
000071ff35fcee8d  nop [rax+rax*1], ax
000071ff35fcee96  nop [rax+rax*1], eax
000071ff35fcee9e  mov eax, 0x410208
000071ff35fceea3  mov [r15+0x100], rax
000071ff35fceeaa  jmp 0x000071FF35DFE110
000071ff35fceeaf  cmp dword ptr [r15+0x318], 0x00
000071ff35fceeb7  jz 0x000071FF35FCEF00
000071ff35fceebd  nop [rax+rax*1], ax
000071ff35fceec6  nop [rax+rax*1], eax
000071ff35fceece  mov eax, 0x4101E8
000071ff35fceed3  mov [r15+0x100], rax
000071ff35fceeda  jmp 0x000071FF35DFE110
000071ff35fceedf  int3
000071ff35fceee0  call 0x000071FF35E0DC20
000071ff35fceee5  jmp 0x000071FF35FCEE02
000071ff35fceeea  call 0x000071FF35E0B5E0
000071ff35fceeef  jmp 0x000071FF35FCEE0E
000071ff35fceef4  call 0x000071FF35EA3D90
000071ff35fceef9  jmp 0x000071FF35FCEE17
000071ff35fceefe  int3
000071ff35fceeff  nop
000071ff35fcef00  mov rax, [r15+0x98]
000071ff35fcef07  mov r14, [r15+0x58]
000071ff35fcef0b  mov [rsp+0x10], r14
000071ff35fcef10  shl r14, 0x02
000071ff35fcef14  lea r12, [rax+r14*1]
000071ff35fcef18  mov eax, [r13+r12*1]
000071ff35fcef1d  lea r14, [r12+0x04]
000071ff35fcef22  mov r12d, [r13+r14*1]
000071ff35fcef27  mov eax, eax
000071ff35fcef29  mov [r15+0x68], rax
000071ff35fcef2d  mov r12d, r12d
000071ff35fcef30  mov [r15+0x60], r12
000071ff35fcef34  mov rax, [r15+0x68]
000071ff35fcef38  mov [rsp+0x20], rax
000071ff35fcef3d  mov r14, [rsp+0x10]
000071ff35fcef42  imul rax, r14
000071ff35fcef46  mov r12, [rsp+0x20]
000071ff35fcef4b  lea r11, [r12+rax*1]
000071ff35fcef4f  mov [r15+0x68], r11
000071ff35fcef53  lea rax, [r14+0x02]
000071ff35fcef57  mov [r15+0x58], rax
000071ff35fcef5b  mov [rsp+0x10], rax
000071ff35fcef60  xor eax, eax
000071ff35fcef62  mov r14, [rsp+0x10]
000071ff35fcef67  mov r12d, 0x400
000071ff35fcef6d  cmp r14, r12
000071ff35fcef70  cmc
000071ff35fcef71  lahf
000071ff35fcef72  seto al
000071ff35fcef75  mov [r15+0x108], eax
000071ff35fcef7c  mov rax, [r15+0x50]
000071ff35fcef80  mov r12, [r15+0x60]
000071ff35fcef84  imul r14, r12
000071ff35fcef88  lea r12, [rax+r14*1]
000071ff35fcef8c  mov [r15+0x50], r12
000071ff35fcef90  mov rax, [r15+0x48]
000071ff35fcef94  lea r14, [r11+rax*1]
000071ff35fcef98  mov [r15+0x48], r14
000071ff35fcef9c  mov eax, [r15+0x108]
000071ff35fcefa3  sahf
000071ff35fcefa4  jnz 0x000071FF35FCEFD6
000071ff35fcefa6  cmp dword ptr [r15+0x318], 0x00
000071ff35fcefae  jz 0x000071FF35FCF020
000071ff35fcefb4  nop [rax+rax*1], ax
000071ff35fcefbd  nop [rax+rax*1], eax
000071ff35fcefc5  mov eax, 0x410208
000071ff35fcefca  mov [r15+0x100], rax
000071ff35fcefd1  jmp 0x000071FF35DFE110
000071ff35fcefd6  cmp dword ptr [r15+0x318], 0x00
000071ff35fcefde  jz 0x000071FF35FCEF00
000071ff35fcefe4  nop [rax+rax*1], ax
000071ff35fcefed  nop [rax+rax*1], eax
000071ff35fceff5  mov eax, 0x4101E8
000071ff35fceffa  mov [r15+0x100], rax
000071ff35fcf001  jmp 0x000071FF35DFE110
000071ff35fcf006  int3
000071ff35fcf007  call 0x000071FF35EB4690
000071ff35fcf00c  jmp 0x000071FF35FCEF1D
000071ff35fcf011  call 0x000071FF35EE26A0
000071ff35fcf016  jmp 0x000071FF35FCEF27
000071ff35fcf01b  int3
000071ff35fcf01c  nop [rax], eax
000071ff35fcf020  mov rax, [r15+0xF8]
000071ff35fcf027  lea r14, [rax+0x10]
000071ff35fcf02b  mov r12, [r13+r14*1]
000071ff35fcf030  lea r14, [rax+0x18]
000071ff35fcf034  mov r11, [r13+r14*1]
000071ff35fcf039  mov [r15+0xA0], r12
000071ff35fcf040  mov [r15+0x98], r11
000071ff35fcf047  mov r14, [r15+0x50]
000071ff35fcf04b  mov r12, [r15+0x48]
000071ff35fcf04f  lea r11, [r14+r12*1]
000071ff35fcf053  mov [r15+0x48], r11
000071ff35fcf057  mov r14, [r15+0x40]
000071ff35fcf05b  lea r12, [r14+0x288]
000071ff35fcf062  mov [r13+r12*1], r11
000071ff35fcf067  mov r14, [r13+rax*1]
000071ff35fcf06c  mov [r15+0xF0], r14
000071ff35fcf073  lea r12, [rax+0x20]
000071ff35fcf077  mov [r15+0xF8], r12
000071ff35fcf07e  mov [r15+0x100], r14
000071ff35fcf085  jmp 0x000071FF35FCE5C0
000071ff35fcf08a  int3
000071ff35fcf08b  call 0x000071FF35EE27E0
000071ff35fcf090  jmp 0x000071FF35FCF030
000071ff35fcf095  call 0x000071FF35EE1570
000071ff35fcf09a  jmp 0x000071FF35FCF039
000071ff35fcf09f  call 0x000071FF35EC0860
000071ff35fcf0a4  jmp 0x000071FF35FCF067
000071ff35fcf0a9  call 0x000071FF35E0DC20
000071ff35fcf0ae  jmp 0x000071FF35FCF06C
000071ff35fcf0b3  int3
000071ff35fcf0b4  nop [rax+rax*1], ax
000071ff35fcf0bd  nop [rax], eax
000071ff35fcf0c0  mov qword ptr [r15+0x100], 0x04
000071ff35fcf0cb  mov esi, 0x00
000071ff35fcf0d0  mov edx, 0x09
000071ff35fcf0d5  mov rdi, 0x7FFE8B2CFA80
000071ff35fcf0df  mov rax, 0x599679A40970
000071ff35fcf0e9  call rax
000071ff35fcf0eb  cmp dword ptr [r15+0x318], 0x00
000071ff35fcf0f3  jnz 0x000071FF35DFE110
000071ff35fcf0f9  jmp 0x000071FF35DFE0A0
000071ff35fcf0fe  int3
000071ff35fcf0ff  int3
