00007b983a9ce69b  nop [rax+rax*1], eax
00007b983a9ce6a0  mov rax, [r15+0xF8]
00007b983a9ce6a7  lea r14, [rax-0x20]
00007b983a9ce6ab  mov r12, [r15+0xF0]
00007b983a9ce6b2  mov [r13+r14*1], r12
00007b983a9ce6b7  mov [r15+0xF8], r14
00007b983a9ce6be  lea r14, [rax-0x10]
00007b983a9ce6c2  mov r12, [r15+0xA0]
00007b983a9ce6c9  mov r11, [r15+0x98]
00007b983a9ce6d0  mov [r13+r14*1], r12
00007b983a9ce6d5  lea r14, [rax-0x08]
00007b983a9ce6d9  mov [r13+r14*1], r11
00007b983a9ce6de  mov qword ptr [r15+0xA0], 0x00
00007b983a9ce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007b983a9ce6f4  mov eax, [r15+0xA0]
00007b983a9ce6fb  lea r14d, [eax+0x11]
00007b983a9ce700  mov r14d, r14d
00007b983a9ce703  mov [r15], r14
00007b983a9ce706  mov qword ptr [r15+0xF0], 0x410184
00007b983a9ce711  mov r14d, [r15+0x320]
00007b983a9ce718  mov eax, 0x410184
00007b983a9ce71d  mov rcx, 0x7B983A9CE800
00007b983a9ce727  mov [r15+r14*8+0x328], rax
00007b983a9ce72f  mov [r15+r14*8+0x368], rcx
00007b983a9ce737  add r14d, 0x01
00007b983a9ce73b  and r14d, 0x07
00007b983a9ce73f  mov [r15+0x320], r14d
00007b983a9ce746  cmp dword ptr [r15+0x318], 0x00
00007b983a9ce74e  jz 0x00007B983A9CE7A0
00007b983a9ce754  nop [rax+rax*1], ax
00007b983a9ce75d  nop [rax+rax*1], eax
00007b983a9ce765  mov eax, 0x41021C
00007b983a9ce76a  mov [r15+0x100], rax
00007b983a9ce771  jmp 0x00007B983A7FE110
00007b983a9ce776  int3
00007b983a9ce777  call 0x00007B983A8E2CE0
00007b983a9ce77c  jmp 0x00007B983A9CE6B7
00007b983a9ce781  call 0x00007B983A8E2CE0
00007b983a9ce786  jmp 0x00007B983A9CE6D5
00007b983a9ce78b  call 0x00007B983A8E1A60
00007b983a9ce790  jmp 0x00007B983A9CE6DE
00007b983a9ce795  int3
00007b983a9ce796  nop [rax+rax*1], ax
00007b983a9ce79f  nop
00007b983a9ce7a0  mov eax, 0x846CA68B
00007b983a9ce7a5  mov eax, eax
00007b983a9ce7a7  mov [r15+0x48], rax
00007b983a9ce7ab  mov eax, [r15]
00007b983a9ce7ae  imul eax, eax, 0x7FEB352D
00007b983a9ce7b4  mov [rsp+0x10], eax
00007b983a9ce7b8  shr eax, 0x0F
00007b983a9ce7bb  mov r14d, [rsp+0x10]
00007b983a9ce7c0  xor r14d, eax
00007b983a9ce7c3  imul r14d, r14d, 0x846CA68B
00007b983a9ce7ca  mov [rsp+0x10], r14d
00007b983a9ce7cf  mov r14d, r14d
00007b983a9ce7d2  mov [r15+0x40], r14
00007b983a9ce7d6  mov eax, [rsp+0x10]
00007b983a9ce7da  shr eax, 0x10
00007b983a9ce7dd  mov r14d, [rsp+0x10]
00007b983a9ce7e2  xor r14d, eax
00007b983a9ce7e5  mov r14d, r14d
00007b983a9ce7e8  mov [r15], r14
00007b983a9ce7eb  mov rax, [r15+0xF0]
00007b983a9ce7f2  mov [r15+0x100], rax
00007b983a9ce7f9  jmp 0x00007B983A9CE5C0
00007b983a9ce7fe  int3
00007b983a9ce7ff  int3
00007b983a9ce800  mov rax, [r15+0xA0]
00007b983a9ce807  mov [rsp+0x10], rax
00007b983a9ce80c  shl rax, 0x02
00007b983a9ce810  mov r14, [r15+0x98]
00007b983a9ce817  lea r12, [r14+rax*1]
00007b983a9ce81b  mov eax, [r15]
00007b983a9ce81e  mov [r13+r12*1], eax
00007b983a9ce823  mov rax, [rsp+0x10]
00007b983a9ce828  lea r14, [rax+0x01]
00007b983a9ce82c  mov [r15+0xA0], r14
00007b983a9ce833  xor eax, eax
00007b983a9ce835  mov r12d, 0x400
00007b983a9ce83b  cmp r14, r12
00007b983a9ce83e  cmc
00007b983a9ce83f  lahf
00007b983a9ce840  seto al
00007b983a9ce843  mov [r15+0x108], eax
00007b983a9ce84a  mov eax, [r15+0x108]
00007b983a9ce851  sahf
00007b983a9ce852  jnz 0x00007B983A9CE884
00007b983a9ce854  cmp dword ptr [r15+0x318], 0x00
00007b983a9ce85c  jz 0x00007B983A9CE950
00007b983a9ce862  nop [rax+rax*1], ax
00007b983a9ce86b  nop [rax+rax*1], eax
00007b983a9ce873  mov eax, 0x410194
00007b983a9ce878  mov [r15+0x100], rax
00007b983a9ce87f  jmp 0x00007B983A7FE110
00007b983a9ce884  cmp dword ptr [r15+0x318], 0x00
00007b983a9ce88c  jz 0x00007B983A9CE8C0
00007b983a9ce892  nop [rax+rax*1], ax
00007b983a9ce89b  nop [rax+rax*1], eax
00007b983a9ce8a3  mov eax, 0x41017C
00007b983a9ce8a8  mov [r15+0x100], rax
00007b983a9ce8af  jmp 0x00007B983A7FE110
00007b983a9ce8b4  int3
00007b983a9ce8b5  call 0x00007B983A8B4B70
00007b983a9ce8ba  jmp 0x00007B983A9CE823
00007b983a9ce8bf  int3
00007b983a9ce8c0  mov eax, [r15+0xA0]
00007b983a9ce8c7  lea r14d, [eax+0x11]
00007b983a9ce8cc  mov r14d, r14d
00007b983a9ce8cf  mov [r15], r14
00007b983a9ce8d2  mov qword ptr [r15+0xF0], 0x410184
00007b983a9ce8dd  mov r14d, [r15+0x320]
00007b983a9ce8e4  mov eax, 0x410184
00007b983a9ce8e9  mov rcx, 0x7B983A9CE800
00007b983a9ce8f3  mov [r15+r14*8+0x328], rax
00007b983a9ce8fb  mov [r15+r14*8+0x368], rcx
00007b983a9ce903  add r14d, 0x01
00007b983a9ce907  and r14d, 0x07
00007b983a9ce90b  mov [r15+0x320], r14d
00007b983a9ce912  cmp dword ptr [r15+0x318], 0x00
00007b983a9ce91a  jz 0x00007B983A9CE7A0
00007b983a9ce920  nop [rax+rax*1], ax
00007b983a9ce929  nop [rax+rax*1], eax
00007b983a9ce931  mov eax, 0x41021C
00007b983a9ce936  mov [r15+0x100], rax
00007b983a9ce93d  jmp 0x00007B983A7FE110
00007b983a9ce942  int3
00007b983a9ce943  int3
00007b983a9ce944  nop [rax+rax*1], ax
00007b983a9ce94d  nop [rax], eax
00007b983a9ce950  mov qword ptr [r15+0x40], 0x01
00007b983a9ce958  cmp dword ptr [r15+0x318], 0x00
00007b983a9ce960  jz 0x00007B983A9CE990
00007b983a9ce966  nop [rax+rax*1], ax
00007b983a9ce96f  nop [rax+rax*1], eax
00007b983a9ce977  mov eax, 0x4101B0
00007b983a9ce97c  mov [r15+0x100], rax
00007b983a9ce983  jmp 0x00007B983A7FE110
00007b983a9ce988  int3
00007b983a9ce989  int3
00007b983a9ce98a  nop [rax+rax*1], ax
00007b983a9ce990  mov rax, [r15+0x40]
00007b983a9ce994  mov [rsp+0x10], rax
00007b983a9ce999  shl rax, 0x02
00007b983a9ce99d  mov r14, [r15+0x98]
00007b983a9ce9a4  lea r12, [r14+rax*1]
00007b983a9ce9a8  mov eax, [r13+r12*1]
00007b983a9ce9ad  mov [rsp+0x20], eax
00007b983a9ce9b1  mov eax, eax
00007b983a9ce9b3  mov [r15+0x48], rax
00007b983a9ce9b7  mov rax, [rsp+0x10]
00007b983a9ce9bc  mov [r15+0x50], rax
00007b983a9ce9c0  mov eax, [r15+0x50]
00007b983a9ce9c4  lea r12d, [eax-0x01]
00007b983a9ce9c9  mov r12d, r12d
00007b983a9ce9cc  mov [r15+0x58], r12
00007b983a9ce9d0  mov rax, [r15+0x58]
00007b983a9ce9d4  mov r12d, eax
00007b983a9ce9d7  mov r12d, r12d
00007b983a9ce9da  shl r12, 0x02
00007b983a9ce9de  lea rax, [r14+r12*1]
00007b983a9ce9e2  mov r14d, [r13+rax*1]
00007b983a9ce9e7  mov [rsp+0x10], r14d
00007b983a9ce9ec  mov r14d, r14d
00007b983a9ce9ef  mov [r15+0x60], r14
00007b983a9ce9f3  xor eax, eax
00007b983a9ce9f5  mov r14d, [rsp+0x10]
00007b983a9ce9fa  mov r12d, [rsp+0x20]
00007b983a9ce9ff  cmp r14d, r12d
00007b983a9cea02  cmc
00007b983a9cea03  lahf
00007b983a9cea04  seto al
00007b983a9cea07  mov [r15+0x108], eax
00007b983a9cea0e  mov eax, [r15+0x108]
00007b983a9cea15  sahf
00007b983a9cea16  cmc
00007b983a9cea17  jbe 0x00007B983A9CEA49
00007b983a9cea19  cmp dword ptr [r15+0x318], 0x00
00007b983a9cea21  jz 0x00007B983A9CEA90
00007b983a9cea27  nop [rax+rax*1], ax
00007b983a9cea30  nop [rax+rax*1], eax
00007b983a9cea38  mov eax, 0x4101C8
00007b983a9cea3d  mov [r15+0x100], rax
00007b983a9cea44  jmp 0x00007B983A7FE110
00007b983a9cea49  cmp dword ptr [r15+0x318], 0x00
00007b983a9cea51  jz 0x00007B983A9CED30
00007b983a9cea57  nop [rax+rax*1], ax
00007b983a9cea60  nop [rax+rax*1], eax
00007b983a9cea68  mov eax, 0x4101A0
00007b983a9cea6d  mov [r15+0x100], rax
00007b983a9cea74  jmp 0x00007B983A7FE110
00007b983a9cea79  int3
00007b983a9cea7a  call 0x00007B983A8B4690
00007b983a9cea7f  jmp 0x00007B983A9CE9AD
00007b983a9cea84  call 0x00007B983A80DAE0
00007b983a9cea89  jmp 0x00007B983A9CE9E7
00007b983a9cea8e  int3
00007b983a9cea8f  nop
00007b983a9cea90  mov rax, [r15+0x50]
00007b983a9cea94  mov [rsp+0x10], rax
00007b983a9cea99  shl rax, 0x02
00007b983a9cea9d  mov r14, [r15+0x98]
00007b983a9ceaa4  lea r12, [r14+rax*1]
00007b983a9ceaa8  mov eax, [r15+0x60]
00007b983a9ceaac  mov [r13+r12*1], eax
00007b983a9ceab1  mov rax, [rsp+0x10]
00007b983a9ceab6  lea r14, [rax-0x01]
00007b983a9ceaba  mov [r15+0x50], r14
00007b983a9ceabe  mov rax, [r15+0x58]
00007b983a9ceac2  test rax, rax
00007b983a9ceac5  setz al
00007b983a9ceac8  movzx rax, al
00007b983a9ceacc  mov [rsp+0x414], al
00007b983a9cead3  cmp byte ptr [rsp+0x414], 0x00
00007b983a9ceadb  jz 0x00007B983A9CEB0D
00007b983a9ceadd  cmp dword ptr [r15+0x318], 0x00
00007b983a9ceae5  jz 0x00007B983A9CEB50
00007b983a9ceaeb  nop [rax+rax*1], ax
00007b983a9ceaf4  nop [rax+rax*1], eax
00007b983a9ceafc  mov eax, 0x4101D4
00007b983a9ceb01  mov [r15+0x100], rax
00007b983a9ceb08  jmp 0x00007B983A7FE110
00007b983a9ceb0d  cmp dword ptr [r15+0x318], 0x00
00007b983a9ceb15  jz 0x00007B983A9CEC50
00007b983a9ceb1b  nop [rax+rax*1], ax
00007b983a9ceb24  nop [rax+rax*1], eax
00007b983a9ceb2c  mov eax, 0x4101B8
00007b983a9ceb31  mov [r15+0x100], rax
00007b983a9ceb38  jmp 0x00007B983A7FE110
00007b983a9ceb3d  int3
00007b983a9ceb3e  call 0x00007B983A8B4B70
00007b983a9ceb43  jmp 0x00007B983A9CEAB1
00007b983a9ceb48  int3
00007b983a9ceb49  nop [rax], eax
00007b983a9ceb50  cmp dword ptr [r15+0x318], 0x00
00007b983a9ceb58  jz 0x00007B983A9CEB90
00007b983a9ceb5e  nop [rax+rax*1], ax
00007b983a9ceb67  nop [rax+rax*1], eax
00007b983a9ceb6f  mov eax, 0x41019C
00007b983a9ceb74  mov [r15+0x100], rax
00007b983a9ceb7b  jmp 0x00007B983A7FE110
00007b983a9ceb80  int3
00007b983a9ceb81  int3
00007b983a9ceb82  nop [rax+rax*1], ax
00007b983a9ceb8b  nop [rax+rax*1], eax
00007b983a9ceb90  mov qword ptr [r15+0x50], 0x00
00007b983a9ceb98  mov rax, [r15+0x40]
00007b983a9ceb9c  lea r14, [rax+0x01]
00007b983a9ceba0  mov [r15+0x40], r14
00007b983a9ceba4  mov rax, [r15+0x98]
00007b983a9cebab  mov r12d, [r15+0x48]
00007b983a9cebaf  mov [r13+rax*1], r12d
00007b983a9cebb4  xor eax, eax
00007b983a9cebb6  mov r12d, 0x400
00007b983a9cebbc  cmp r14, r12
00007b983a9cebbf  cmc
00007b983a9cebc0  lahf
00007b983a9cebc1  seto al
00007b983a9cebc4  mov [r15+0x108], eax
00007b983a9cebcb  mov eax, [r15+0x108]
00007b983a9cebd2  sahf
00007b983a9cebd3  jz 0x00007B983A9CEC05
00007b983a9cebd5  cmp dword ptr [r15+0x318], 0x00
00007b983a9cebdd  jz 0x00007B983A9CE990
00007b983a9cebe3  nop [rax+rax*1], ax
00007b983a9cebec  nop [rax+rax*1], eax
00007b983a9cebf4  mov eax, 0x4101B0
00007b983a9cebf9  mov [r15+0x100], rax
00007b983a9cec00  jmp 0x00007B983A7FE110
00007b983a9cec05  cmp dword ptr [r15+0x318], 0x00
00007b983a9cec0d  jz 0x00007B983A9CEDF0
00007b983a9cec13  nop [rax+rax*1], ax
00007b983a9cec1c  nop [rax+rax*1], eax
00007b983a9cec24  mov eax, 0x4101D8
00007b983a9cec29  mov [r15+0x100], rax
00007b983a9cec30  jmp 0x00007B983A7FE110
00007b983a9cec35  int3
00007b983a9cec36  call 0x00007B983A80BAE0
00007b983a9cec3b  jmp 0x00007B983A9CEBB4
00007b983a9cec40  int3
00007b983a9cec41  nop [rax+rax*1], ax
00007b983a9cec4a  nop [rax+rax*1], ax
00007b983a9cec50  mov eax, [r15+0x50]
00007b983a9cec54  lea r14d, [eax-0x01]
00007b983a9cec59  mov r14d, r14d
00007b983a9cec5c  mov [r15+0x58], r14
00007b983a9cec60  mov rax, [r15+0x58]
00007b983a9cec64  mov r14d, eax
00007b983a9cec67  mov r14d, r14d
00007b983a9cec6a  shl r14, 0x02
00007b983a9cec6e  mov rax, [r15+0x98]
00007b983a9cec75  lea r12, [rax+r14*1]
00007b983a9cec79  mov eax, [r13+r12*1]
00007b983a9cec7e  mov [rsp+0x10], eax
00007b983a9cec82  mov eax, eax
00007b983a9cec84  mov [r15+0x60], rax
00007b983a9cec88  mov eax, [r15+0x48]
00007b983a9cec8c  mov [rsp+0x20], eax
00007b983a9cec90  xor eax, eax
00007b983a9cec92  mov r14d, [rsp+0x10]
00007b983a9cec97  mov r12d, [rsp+0x20]
00007b983a9cec9c  cmp r14d, r12d
00007b983a9cec9f  cmc
00007b983a9ceca0  lahf
00007b983a9ceca1  seto al
00007b983a9ceca4  mov [r15+0x108], eax
00007b983a9cecab  mov eax, [r15+0x108]
00007b983a9cecb2  sahf
00007b983a9cecb3  cmc
00007b983a9cecb4  jbe 0x00007B983A9CECE6
00007b983a9cecb6  cmp dword ptr [r15+0x318], 0x00
00007b983a9cecbe  jz 0x00007B983A9CEA90
00007b983a9cecc4  nop [rax+rax*1], ax
00007b983a9ceccd  nop [rax+rax*1], eax
00007b983a9cecd5  mov eax, 0x4101C8
00007b983a9cecda  mov [r15+0x100], rax
00007b983a9cece1  jmp 0x00007B983A7FE110
00007b983a9cece6  cmp dword ptr [r15+0x318], 0x00
00007b983a9cecee  jz 0x00007B983A9CED30
00007b983a9cecf4  nop [rax+rax*1], ax
00007b983a9cecfd  nop [rax+rax*1], eax
00007b983a9ced05  mov eax, 0x4101A0
00007b983a9ced0a  mov [r15+0x100], rax
00007b983a9ced11  jmp 0x00007B983A7FE110
00007b983a9ced16  int3
00007b983a9ced17  call 0x00007B983A8B4690
00007b983a9ced1c  jmp 0x00007B983A9CEC7E
00007b983a9ced21  int3
00007b983a9ced22  nop [rax+rax*1], ax
00007b983a9ced2b  nop [rax+rax*1], eax
00007b983a9ced30  mov rax, [r15+0x40]
00007b983a9ced34  lea r14, [rax+0x01]
00007b983a9ced38  mov [r15+0x40], r14
00007b983a9ced3c  mov rax, [r15+0x50]
00007b983a9ced40  mov r12d, eax
00007b983a9ced43  mov r12d, r12d
00007b983a9ced46  shl r12, 0x02
00007b983a9ced4a  mov rax, [r15+0x98]
00007b983a9ced51  lea r11, [rax+r12*1]
00007b983a9ced55  mov eax, [r15+0x48]
00007b983a9ced59  mov [r13+r11*1], eax
00007b983a9ced5e  xor eax, eax
00007b983a9ced60  mov r12d, 0x400
00007b983a9ced66  cmp r14, r12
00007b983a9ced69  cmc
00007b983a9ced6a  lahf
00007b983a9ced6b  seto al
00007b983a9ced6e  mov [r15+0x108], eax
00007b983a9ced75  mov eax, [r15+0x108]
00007b983a9ced7c  sahf
00007b983a9ced7d  jz 0x00007B983A9CEDAF
00007b983a9ced7f  cmp dword ptr [r15+0x318], 0x00
00007b983a9ced87  jz 0x00007B983A9CE990
00007b983a9ced8d  nop [rax+rax*1], ax
00007b983a9ced96  nop [rax+rax*1], eax
00007b983a9ced9e  mov eax, 0x4101B0
00007b983a9ceda3  mov [r15+0x100], rax
00007b983a9cedaa  jmp 0x00007B983A7FE110
00007b983a9cedaf  cmp dword ptr [r15+0x318], 0x00
00007b983a9cedb7  jz 0x00007B983A9CEDF0
00007b983a9cedbd  nop [rax+rax*1], ax
00007b983a9cedc6  nop [rax+rax*1], eax
00007b983a9cedce  mov eax, 0x4101D8
00007b983a9cedd3  mov [r15+0x100], rax
00007b983a9cedda  jmp 0x00007B983A7FE110
00007b983a9ceddf  int3
00007b983a9cede0  call 0x00007B983A8A4270
00007b983a9cede5  jmp 0x00007B983A9CED5E
00007b983a9cedea  int3
00007b983a9cedeb  nop [rax+rax*1], eax
00007b983a9cedf0  mov qword ptr [r15+0x40], 0x420000
00007b983a9cedf8  mov eax, 0x420288
00007b983a9cedfd  mov r14, [r13+rax*1]
00007b983a9cee02  mov rax, [r15+0x98]
00007b983a9cee09  mov r12d, [r13+rax*1]
00007b983a9cee0e  lea r11, [rax+0x04]
00007b983a9cee12  mov eax, [r13+r11*1]
00007b983a9cee17  mov r12d, r12d
00007b983a9cee1a  mov [r15+0x68], r12
00007b983a9cee1e  mov eax, eax
00007b983a9cee20  mov [r15+0x60], rax
00007b983a9cee24  mov rax, [r15+0x68]
00007b983a9cee28  mov [r15+0x68], rax
00007b983a9cee2c  mov qword ptr [r15+0x58], 0x02
00007b983a9cee34  mov [rsp+0x10], rax
00007b983a9cee39  xor eax, eax
00007b983a9cee3b  mov r12d, 0x02
00007b983a9cee41  mov r11d, 0x400
00007b983a9cee47  cmp r12, r11
00007b983a9cee4a  cmc
00007b983a9cee4b  lahf
00007b983a9cee4c  seto al
00007b983a9cee4f  mov [r15+0x108], eax
00007b983a9cee56  mov rax, [r15+0x60]
00007b983a9cee5a  mov r12d, 0x02
00007b983a9cee60  imul rax, r12
00007b983a9cee64  mov [r15+0x50], rax
00007b983a9cee68  mov rax, [rsp+0x10]
00007b983a9cee6d  lea r12, [rax+r14*1]
00007b983a9cee71  mov [r15+0x48], r12
00007b983a9cee75  mov eax, [r15+0x108]
00007b983a9cee7c  sahf
00007b983a9cee7d  jnz 0x00007B983A9CEEAF
00007b983a9cee7f  cmp dword ptr [r15+0x318], 0x00
00007b983a9cee87  jz 0x00007B983A9CF020
00007b983a9cee8d  nop [rax+rax*1], ax
00007b983a9cee96  nop [rax+rax*1], eax
00007b983a9cee9e  mov eax, 0x410208
00007b983a9ceea3  mov [r15+0x100], rax
00007b983a9ceeaa  jmp 0x00007B983A7FE110
00007b983a9ceeaf  cmp dword ptr [r15+0x318], 0x00
00007b983a9ceeb7  jz 0x00007B983A9CEF00
00007b983a9ceebd  nop [rax+rax*1], ax
00007b983a9ceec6  nop [rax+rax*1], eax
00007b983a9ceece  mov eax, 0x4101E8
00007b983a9ceed3  mov [r15+0x100], rax
00007b983a9ceeda  jmp 0x00007B983A7FE110
00007b983a9ceedf  int3
00007b983a9ceee0  call 0x00007B983A80DC20
00007b983a9ceee5  jmp 0x00007B983A9CEE02
00007b983a9ceeea  call 0x00007B983A80B5E0
00007b983a9ceeef  jmp 0x00007B983A9CEE0E
00007b983a9ceef4  call 0x00007B983A8A3D90
00007b983a9ceef9  jmp 0x00007B983A9CEE17
00007b983a9ceefe  int3
00007b983a9ceeff  nop
00007b983a9cef00  mov rax, [r15+0x98]
00007b983a9cef07  mov r14, [r15+0x58]
00007b983a9cef0b  mov [rsp+0x10], r14
00007b983a9cef10  shl r14, 0x02
00007b983a9cef14  lea r12, [rax+r14*1]
00007b983a9cef18  mov eax, [r13+r12*1]
00007b983a9cef1d  lea r14, [r12+0x04]
00007b983a9cef22  mov r12d, [r13+r14*1]
00007b983a9cef27  mov eax, eax
00007b983a9cef29  mov [r15+0x68], rax
00007b983a9cef2d  mov r12d, r12d
00007b983a9cef30  mov [r15+0x60], r12
00007b983a9cef34  mov rax, [r15+0x68]
00007b983a9cef38  mov [rsp+0x20], rax
00007b983a9cef3d  mov r14, [rsp+0x10]
00007b983a9cef42  imul rax, r14
00007b983a9cef46  mov r12, [rsp+0x20]
00007b983a9cef4b  lea r11, [r12+rax*1]
00007b983a9cef4f  mov [r15+0x68], r11
00007b983a9cef53  lea rax, [r14+0x02]
00007b983a9cef57  mov [r15+0x58], rax
00007b983a9cef5b  mov [rsp+0x10], rax
00007b983a9cef60  xor eax, eax
00007b983a9cef62  mov r14, [rsp+0x10]
00007b983a9cef67  mov r12d, 0x400
00007b983a9cef6d  cmp r14, r12
00007b983a9cef70  cmc
00007b983a9cef71  lahf
00007b983a9cef72  seto al
00007b983a9cef75  mov [r15+0x108], eax
00007b983a9cef7c  mov rax, [r15+0x50]
00007b983a9cef80  mov r12, [r15+0x60]
00007b983a9cef84  imul r14, r12
00007b983a9cef88  lea r12, [rax+r14*1]
00007b983a9cef8c  mov [r15+0x50], r12
00007b983a9cef90  mov rax, [r15+0x48]
00007b983a9cef94  lea r14, [r11+rax*1]
00007b983a9cef98  mov [r15+0x48], r14
00007b983a9cef9c  mov eax, [r15+0x108]
00007b983a9cefa3  sahf
00007b983a9cefa4  jnz 0x00007B983A9CEFD6
00007b983a9cefa6  cmp dword ptr [r15+0x318], 0x00
00007b983a9cefae  jz 0x00007B983A9CF020
00007b983a9cefb4  nop [rax+rax*1], ax
00007b983a9cefbd  nop [rax+rax*1], eax
00007b983a9cefc5  mov eax, 0x410208
00007b983a9cefca  mov [r15+0x100], rax
00007b983a9cefd1  jmp 0x00007B983A7FE110
00007b983a9cefd6  cmp dword ptr [r15+0x318], 0x00
00007b983a9cefde  jz 0x00007B983A9CEF00
00007b983a9cefe4  nop [rax+rax*1], ax
00007b983a9cefed  nop [rax+rax*1], eax
00007b983a9ceff5  mov eax, 0x4101E8
00007b983a9ceffa  mov [r15+0x100], rax
00007b983a9cf001  jmp 0x00007B983A7FE110
00007b983a9cf006  int3
00007b983a9cf007  call 0x00007B983A8B4690
00007b983a9cf00c  jmp 0x00007B983A9CEF1D
00007b983a9cf011  call 0x00007B983A8E26A0
00007b983a9cf016  jmp 0x00007B983A9CEF27
00007b983a9cf01b  int3
00007b983a9cf01c  nop [rax], eax
00007b983a9cf020  mov rax, [r15+0xF8]
00007b983a9cf027  lea r14, [rax+0x10]
00007b983a9cf02b  mov r12, [r13+r14*1]
00007b983a9cf030  lea r14, [rax+0x18]
00007b983a9cf034  mov r11, [r13+r14*1]
00007b983a9cf039  mov [r15+0xA0], r12
00007b983a9cf040  mov [r15+0x98], r11
00007b983a9cf047  mov r14, [r15+0x50]
00007b983a9cf04b  mov r12, [r15+0x48]
00007b983a9cf04f  lea r11, [r14+r12*1]
00007b983a9cf053  mov [r15+0x48], r11
00007b983a9cf057  mov r14, [r15+0x40]
00007b983a9cf05b  lea r12, [r14+0x288]
00007b983a9cf062  mov [r13+r12*1], r11
00007b983a9cf067  mov r14, [r13+rax*1]
00007b983a9cf06c  mov [r15+0xF0], r14
00007b983a9cf073  lea r12, [rax+0x20]
00007b983a9cf077  mov [r15+0xF8], r12
00007b983a9cf07e  mov [r15+0x100], r14
00007b983a9cf085  jmp 0x00007B983A9CE5C0
00007b983a9cf08a  int3
00007b983a9cf08b  call 0x00007B983A8E27E0
00007b983a9cf090  jmp 0x00007B983A9CF030
00007b983a9cf095  call 0x00007B983A8E1570
00007b983a9cf09a  jmp 0x00007B983A9CF039
00007b983a9cf09f  call 0x00007B983A8C0860
00007b983a9cf0a4  jmp 0x00007B983A9CF067
00007b983a9cf0a9  call 0x00007B983A80DC20
00007b983a9cf0ae  jmp 0x00007B983A9CF06C
00007b983a9cf0b3  int3
00007b983a9cf0b4  nop [rax+rax*1], ax
00007b983a9cf0bd  nop [rax], eax
00007b983a9cf0c0  mov qword ptr [r15+0x100], 0x04
00007b983a9cf0cb  mov esi, 0x00
00007b983a9cf0d0  mov edx, 0x09
00007b983a9cf0d5  mov rdi, 0x7FFC20FC3CF0
00007b983a9cf0df  mov rax, 0x5AAF5653F970
00007b983a9cf0e9  call rax
00007b983a9cf0eb  cmp dword ptr [r15+0x318], 0x00
00007b983a9cf0f3  jnz 0x00007B983A7FE110
00007b983a9cf0f9  jmp 0x00007B983A7FE0A0
00007b983a9cf0fe  int3
00007b983a9cf0ff  int3
