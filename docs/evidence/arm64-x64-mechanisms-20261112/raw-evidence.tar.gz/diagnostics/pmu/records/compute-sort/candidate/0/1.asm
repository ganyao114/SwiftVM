
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sort/candidate/0/1.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13d,0x352d
  16:	mov    QWORD PTR [r12+0x40],r13
  1b:	mov    r13d,0xa68b
  21:	mov    QWORD PTR [r12+0x48],r13
  26:	mov    r13d,0x352d
  2c:	mov    r14d,0x7feb
  32:	and    r14d,0xffff
  39:	mov    rax,r13
  3c:	movabs rcx,0xffffffff0000ffff
  46:	and    rax,rcx
  49:	mov    rdx,r14
  4c:	shl    rdx,0x10
  50:	mov    ecx,0xffff0000
  55:	and    rdx,rcx
  58:	or     rax,rdx
  5b:	mov    r15d,eax
  5e:	mov    QWORD PTR [r12+0x40],r15
  63:	mov    r13d,0xa68b
  69:	mov    r14d,0x846c
  6f:	and    r14d,0xffff
  76:	mov    rax,r13
  79:	movabs rcx,0xffffffff0000ffff
  83:	and    rax,rcx
  86:	mov    rdx,r14
  89:	shl    rdx,0x10
  8d:	mov    ecx,0xffff0000
  92:	and    rdx,rcx
  95:	or     rax,rdx
  98:	mov    ebp,eax
  9a:	mov    QWORD PTR [r12+0x48],rbp
  9f:	mov    r13d,DWORD PTR [r12]
  a3:	mov    r14d,0x0
  a9:	mov    eax,r13d
  ac:	mov    ecx,r15d
  af:	imul   rax,rcx
  b3:	mov    r8d,eax
  b6:	mov    ecx,r8d
  b9:	mov    r13d,r14d
  bc:	add    r13d,ecx
  bf:	mov    QWORD PTR [r12+0x40],r13
  c4:	mov    r14d,r13d
  c7:	mov    r14d,r14d
  ca:	shr    r14d,0xf
  ce:	mov    ecx,r14d
  d1:	xor    r13,rcx
  d4:	mov    r13d,r13d
  d7:	mov    QWORD PTR [r12+0x40],r13
  dc:	mov    r14d,0x0
  e2:	mov    eax,r13d
  e5:	mov    ecx,ebp
  e7:	imul   rax,rcx
  eb:	mov    r15d,eax
  ee:	mov    ecx,r15d
  f1:	mov    r13d,r14d
  f4:	add    r13d,ecx
  f7:	mov    QWORD PTR [r12+0x40],r13
  fc:	mov    r14d,r13d
  ff:	mov    r14d,r14d
 102:	shr    r14d,0x10
 106:	mov    ecx,r14d
 109:	xor    r13,rcx
 10c:	mov    r13d,r13d
 10f:	mov    QWORD PTR [r12],r13
 113:	mov    rcx,QWORD PTR [r12+0x380]
 11b:	jrcxz  0x122
 11d:	jmp    0x157
 122:	mov    r13,QWORD PTR [r12+0xf0]
 12a:	mov    QWORD PTR [r12+0x100],r13
 132:	mov    r11,QWORD PTR [rsp]
 136:	mov    QWORD PTR [r12+0x398],r11
 13e:	mov    rdi,QWORD PTR [r12+0x100]
 146:	add    rsp,0x10
 14a:	movabs r11,0x5b456641c0a0
 154:	jmp    r11
 157:	mov    eax,0x41023c
 15c:	mov    QWORD PTR [r12+0x100],rax
 164:	push   rdx
 165:	push   rsi
 166:	push   r10
 168:	push   r11
 16a:	mov    rdx,QWORD PTR [rsp+0x20]
 16f:	mov    r10d,edx
 172:	and    r10d,0xc0
 179:	shl    r10d,0x18
 17d:	mov    r11d,edx
 180:	and    r11d,0x1
 184:	shl    r11d,0x1d
 188:	or     r10d,r11d
 18b:	mov    r11d,edx
 18e:	and    r11d,0x800
 195:	shl    r11d,0x11
 199:	or     r10d,r11d
 19c:	btc    r10,0x1d
 1a1:	mov    r11d,0xf0000000
 1a7:	and    r11,r10
 1aa:	movabs rsi,0xffffffff0fffffff
 1b4:	and    rbx,rsi
 1b7:	or     rbx,r11
 1ba:	pop    r11
 1bc:	pop    r10
 1be:	pop    rsi
 1bf:	pop    rdx
 1c0:	mov    QWORD PTR [r12+0x108],rbx
 1c8:	add    rsp,0x10
 1cc:	mov    eax,0xc
 1d1:	movabs r11,0x5b456641c390
 1db:	jmp    r11
 1de:	nop
 1df:	nop
