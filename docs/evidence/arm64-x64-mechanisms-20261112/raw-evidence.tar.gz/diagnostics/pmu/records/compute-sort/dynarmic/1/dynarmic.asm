00007dc4a55ce69b  nop [rax+rax*1], eax
00007dc4a55ce6a0  mov rax, [r15+0xF8]
00007dc4a55ce6a7  lea r14, [rax-0x20]
00007dc4a55ce6ab  mov r12, [r15+0xF0]
00007dc4a55ce6b2  mov [r13+r14*1], r12
00007dc4a55ce6b7  mov [r15+0xF8], r14
00007dc4a55ce6be  lea r14, [rax-0x10]
00007dc4a55ce6c2  mov r12, [r15+0xA0]
00007dc4a55ce6c9  mov r11, [r15+0x98]
00007dc4a55ce6d0  mov [r13+r14*1], r12
00007dc4a55ce6d5  lea r14, [rax-0x08]
00007dc4a55ce6d9  mov [r13+r14*1], r11
00007dc4a55ce6de  mov qword ptr [r15+0xA0], 0x00
00007dc4a55ce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007dc4a55ce6f4  mov eax, [r15+0xA0]
00007dc4a55ce6fb  lea r14d, [eax+0x11]
00007dc4a55ce700  mov r14d, r14d
00007dc4a55ce703  mov [r15], r14
00007dc4a55ce706  mov qword ptr [r15+0xF0], 0x410184
00007dc4a55ce711  mov r14d, [r15+0x320]
00007dc4a55ce718  mov eax, 0x410184
00007dc4a55ce71d  mov rcx, 0x7DC4A55CE800
00007dc4a55ce727  mov [r15+r14*8+0x328], rax
00007dc4a55ce72f  mov [r15+r14*8+0x368], rcx
00007dc4a55ce737  add r14d, 0x01
00007dc4a55ce73b  and r14d, 0x07
00007dc4a55ce73f  mov [r15+0x320], r14d
00007dc4a55ce746  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ce74e  jz 0x00007DC4A55CE7A0
00007dc4a55ce754  nop [rax+rax*1], ax
00007dc4a55ce75d  nop [rax+rax*1], eax
00007dc4a55ce765  mov eax, 0x41021C
00007dc4a55ce76a  mov [r15+0x100], rax
00007dc4a55ce771  jmp 0x00007DC4A53FE110
00007dc4a55ce776  int3
00007dc4a55ce777  call 0x00007DC4A54E2CE0
00007dc4a55ce77c  jmp 0x00007DC4A55CE6B7
00007dc4a55ce781  call 0x00007DC4A54E2CE0
00007dc4a55ce786  jmp 0x00007DC4A55CE6D5
00007dc4a55ce78b  call 0x00007DC4A54E1A60
00007dc4a55ce790  jmp 0x00007DC4A55CE6DE
00007dc4a55ce795  int3
00007dc4a55ce796  nop [rax+rax*1], ax
00007dc4a55ce79f  nop
00007dc4a55ce7a0  mov eax, 0x846CA68B
00007dc4a55ce7a5  mov eax, eax
00007dc4a55ce7a7  mov [r15+0x48], rax
00007dc4a55ce7ab  mov eax, [r15]
00007dc4a55ce7ae  imul eax, eax, 0x7FEB352D
00007dc4a55ce7b4  mov [rsp+0x10], eax
00007dc4a55ce7b8  shr eax, 0x0F
00007dc4a55ce7bb  mov r14d, [rsp+0x10]
00007dc4a55ce7c0  xor r14d, eax
00007dc4a55ce7c3  imul r14d, r14d, 0x846CA68B
00007dc4a55ce7ca  mov [rsp+0x10], r14d
00007dc4a55ce7cf  mov r14d, r14d
00007dc4a55ce7d2  mov [r15+0x40], r14
00007dc4a55ce7d6  mov eax, [rsp+0x10]
00007dc4a55ce7da  shr eax, 0x10
00007dc4a55ce7dd  mov r14d, [rsp+0x10]
00007dc4a55ce7e2  xor r14d, eax
00007dc4a55ce7e5  mov r14d, r14d
00007dc4a55ce7e8  mov [r15], r14
00007dc4a55ce7eb  mov rax, [r15+0xF0]
00007dc4a55ce7f2  mov [r15+0x100], rax
00007dc4a55ce7f9  jmp 0x00007DC4A55CE5C0
00007dc4a55ce7fe  int3
00007dc4a55ce7ff  int3
00007dc4a55ce800  mov rax, [r15+0xA0]
00007dc4a55ce807  mov [rsp+0x10], rax
00007dc4a55ce80c  shl rax, 0x02
00007dc4a55ce810  mov r14, [r15+0x98]
00007dc4a55ce817  lea r12, [r14+rax*1]
00007dc4a55ce81b  mov eax, [r15]
00007dc4a55ce81e  mov [r13+r12*1], eax
00007dc4a55ce823  mov rax, [rsp+0x10]
00007dc4a55ce828  lea r14, [rax+0x01]
00007dc4a55ce82c  mov [r15+0xA0], r14
00007dc4a55ce833  xor eax, eax
00007dc4a55ce835  mov r12d, 0x400
00007dc4a55ce83b  cmp r14, r12
00007dc4a55ce83e  cmc
00007dc4a55ce83f  lahf
00007dc4a55ce840  seto al
00007dc4a55ce843  mov [r15+0x108], eax
00007dc4a55ce84a  mov eax, [r15+0x108]
00007dc4a55ce851  sahf
00007dc4a55ce852  jnz 0x00007DC4A55CE884
00007dc4a55ce854  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ce85c  jz 0x00007DC4A55CE950
00007dc4a55ce862  nop [rax+rax*1], ax
00007dc4a55ce86b  nop [rax+rax*1], eax
00007dc4a55ce873  mov eax, 0x410194
00007dc4a55ce878  mov [r15+0x100], rax
00007dc4a55ce87f  jmp 0x00007DC4A53FE110
00007dc4a55ce884  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ce88c  jz 0x00007DC4A55CE8C0
00007dc4a55ce892  nop [rax+rax*1], ax
00007dc4a55ce89b  nop [rax+rax*1], eax
00007dc4a55ce8a3  mov eax, 0x41017C
00007dc4a55ce8a8  mov [r15+0x100], rax
00007dc4a55ce8af  jmp 0x00007DC4A53FE110
00007dc4a55ce8b4  int3
00007dc4a55ce8b5  call 0x00007DC4A54B4B70
00007dc4a55ce8ba  jmp 0x00007DC4A55CE823
00007dc4a55ce8bf  int3
00007dc4a55ce8c0  mov eax, [r15+0xA0]
00007dc4a55ce8c7  lea r14d, [eax+0x11]
00007dc4a55ce8cc  mov r14d, r14d
00007dc4a55ce8cf  mov [r15], r14
00007dc4a55ce8d2  mov qword ptr [r15+0xF0], 0x410184
00007dc4a55ce8dd  mov r14d, [r15+0x320]
00007dc4a55ce8e4  mov eax, 0x410184
00007dc4a55ce8e9  mov rcx, 0x7DC4A55CE800
00007dc4a55ce8f3  mov [r15+r14*8+0x328], rax
00007dc4a55ce8fb  mov [r15+r14*8+0x368], rcx
00007dc4a55ce903  add r14d, 0x01
00007dc4a55ce907  and r14d, 0x07
00007dc4a55ce90b  mov [r15+0x320], r14d
00007dc4a55ce912  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ce91a  jz 0x00007DC4A55CE7A0
00007dc4a55ce920  nop [rax+rax*1], ax
00007dc4a55ce929  nop [rax+rax*1], eax
00007dc4a55ce931  mov eax, 0x41021C
00007dc4a55ce936  mov [r15+0x100], rax
00007dc4a55ce93d  jmp 0x00007DC4A53FE110
00007dc4a55ce942  int3
00007dc4a55ce943  int3
00007dc4a55ce944  nop [rax+rax*1], ax
00007dc4a55ce94d  nop [rax], eax
00007dc4a55ce950  mov qword ptr [r15+0x40], 0x01
00007dc4a55ce958  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ce960  jz 0x00007DC4A55CE990
00007dc4a55ce966  nop [rax+rax*1], ax
00007dc4a55ce96f  nop [rax+rax*1], eax
00007dc4a55ce977  mov eax, 0x4101B0
00007dc4a55ce97c  mov [r15+0x100], rax
00007dc4a55ce983  jmp 0x00007DC4A53FE110
00007dc4a55ce988  int3
00007dc4a55ce989  int3
00007dc4a55ce98a  nop [rax+rax*1], ax
00007dc4a55ce990  mov rax, [r15+0x40]
00007dc4a55ce994  mov [rsp+0x10], rax
00007dc4a55ce999  shl rax, 0x02
00007dc4a55ce99d  mov r14, [r15+0x98]
00007dc4a55ce9a4  lea r12, [r14+rax*1]
00007dc4a55ce9a8  mov eax, [r13+r12*1]
00007dc4a55ce9ad  mov [rsp+0x20], eax
00007dc4a55ce9b1  mov eax, eax
00007dc4a55ce9b3  mov [r15+0x48], rax
00007dc4a55ce9b7  mov rax, [rsp+0x10]
00007dc4a55ce9bc  mov [r15+0x50], rax
00007dc4a55ce9c0  mov eax, [r15+0x50]
00007dc4a55ce9c4  lea r12d, [eax-0x01]
00007dc4a55ce9c9  mov r12d, r12d
00007dc4a55ce9cc  mov [r15+0x58], r12
00007dc4a55ce9d0  mov rax, [r15+0x58]
00007dc4a55ce9d4  mov r12d, eax
00007dc4a55ce9d7  mov r12d, r12d
00007dc4a55ce9da  shl r12, 0x02
00007dc4a55ce9de  lea rax, [r14+r12*1]
00007dc4a55ce9e2  mov r14d, [r13+rax*1]
00007dc4a55ce9e7  mov [rsp+0x10], r14d
00007dc4a55ce9ec  mov r14d, r14d
00007dc4a55ce9ef  mov [r15+0x60], r14
00007dc4a55ce9f3  xor eax, eax
00007dc4a55ce9f5  mov r14d, [rsp+0x10]
00007dc4a55ce9fa  mov r12d, [rsp+0x20]
00007dc4a55ce9ff  cmp r14d, r12d
00007dc4a55cea02  cmc
00007dc4a55cea03  lahf
00007dc4a55cea04  seto al
00007dc4a55cea07  mov [r15+0x108], eax
00007dc4a55cea0e  mov eax, [r15+0x108]
00007dc4a55cea15  sahf
00007dc4a55cea16  cmc
00007dc4a55cea17  jbe 0x00007DC4A55CEA49
00007dc4a55cea19  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cea21  jz 0x00007DC4A55CEA90
00007dc4a55cea27  nop [rax+rax*1], ax
00007dc4a55cea30  nop [rax+rax*1], eax
00007dc4a55cea38  mov eax, 0x4101C8
00007dc4a55cea3d  mov [r15+0x100], rax
00007dc4a55cea44  jmp 0x00007DC4A53FE110
00007dc4a55cea49  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cea51  jz 0x00007DC4A55CED30
00007dc4a55cea57  nop [rax+rax*1], ax
00007dc4a55cea60  nop [rax+rax*1], eax
00007dc4a55cea68  mov eax, 0x4101A0
00007dc4a55cea6d  mov [r15+0x100], rax
00007dc4a55cea74  jmp 0x00007DC4A53FE110
00007dc4a55cea79  int3
00007dc4a55cea7a  call 0x00007DC4A54B4690
00007dc4a55cea7f  jmp 0x00007DC4A55CE9AD
00007dc4a55cea84  call 0x00007DC4A540DAE0
00007dc4a55cea89  jmp 0x00007DC4A55CE9E7
00007dc4a55cea8e  int3
00007dc4a55cea8f  nop
00007dc4a55cea90  mov rax, [r15+0x50]
00007dc4a55cea94  mov [rsp+0x10], rax
00007dc4a55cea99  shl rax, 0x02
00007dc4a55cea9d  mov r14, [r15+0x98]
00007dc4a55ceaa4  lea r12, [r14+rax*1]
00007dc4a55ceaa8  mov eax, [r15+0x60]
00007dc4a55ceaac  mov [r13+r12*1], eax
00007dc4a55ceab1  mov rax, [rsp+0x10]
00007dc4a55ceab6  lea r14, [rax-0x01]
00007dc4a55ceaba  mov [r15+0x50], r14
00007dc4a55ceabe  mov rax, [r15+0x58]
00007dc4a55ceac2  test rax, rax
00007dc4a55ceac5  setz al
00007dc4a55ceac8  movzx rax, al
00007dc4a55ceacc  mov [rsp+0x414], al
00007dc4a55cead3  cmp byte ptr [rsp+0x414], 0x00
00007dc4a55ceadb  jz 0x00007DC4A55CEB0D
00007dc4a55ceadd  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ceae5  jz 0x00007DC4A55CEB50
00007dc4a55ceaeb  nop [rax+rax*1], ax
00007dc4a55ceaf4  nop [rax+rax*1], eax
00007dc4a55ceafc  mov eax, 0x4101D4
00007dc4a55ceb01  mov [r15+0x100], rax
00007dc4a55ceb08  jmp 0x00007DC4A53FE110
00007dc4a55ceb0d  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ceb15  jz 0x00007DC4A55CEC50
00007dc4a55ceb1b  nop [rax+rax*1], ax
00007dc4a55ceb24  nop [rax+rax*1], eax
00007dc4a55ceb2c  mov eax, 0x4101B8
00007dc4a55ceb31  mov [r15+0x100], rax
00007dc4a55ceb38  jmp 0x00007DC4A53FE110
00007dc4a55ceb3d  int3
00007dc4a55ceb3e  call 0x00007DC4A54B4B70
00007dc4a55ceb43  jmp 0x00007DC4A55CEAB1
00007dc4a55ceb48  int3
00007dc4a55ceb49  nop [rax], eax
00007dc4a55ceb50  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ceb58  jz 0x00007DC4A55CEB90
00007dc4a55ceb5e  nop [rax+rax*1], ax
00007dc4a55ceb67  nop [rax+rax*1], eax
00007dc4a55ceb6f  mov eax, 0x41019C
00007dc4a55ceb74  mov [r15+0x100], rax
00007dc4a55ceb7b  jmp 0x00007DC4A53FE110
00007dc4a55ceb80  int3
00007dc4a55ceb81  int3
00007dc4a55ceb82  nop [rax+rax*1], ax
00007dc4a55ceb8b  nop [rax+rax*1], eax
00007dc4a55ceb90  mov qword ptr [r15+0x50], 0x00
00007dc4a55ceb98  mov rax, [r15+0x40]
00007dc4a55ceb9c  lea r14, [rax+0x01]
00007dc4a55ceba0  mov [r15+0x40], r14
00007dc4a55ceba4  mov rax, [r15+0x98]
00007dc4a55cebab  mov r12d, [r15+0x48]
00007dc4a55cebaf  mov [r13+rax*1], r12d
00007dc4a55cebb4  xor eax, eax
00007dc4a55cebb6  mov r12d, 0x400
00007dc4a55cebbc  cmp r14, r12
00007dc4a55cebbf  cmc
00007dc4a55cebc0  lahf
00007dc4a55cebc1  seto al
00007dc4a55cebc4  mov [r15+0x108], eax
00007dc4a55cebcb  mov eax, [r15+0x108]
00007dc4a55cebd2  sahf
00007dc4a55cebd3  jz 0x00007DC4A55CEC05
00007dc4a55cebd5  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cebdd  jz 0x00007DC4A55CE990
00007dc4a55cebe3  nop [rax+rax*1], ax
00007dc4a55cebec  nop [rax+rax*1], eax
00007dc4a55cebf4  mov eax, 0x4101B0
00007dc4a55cebf9  mov [r15+0x100], rax
00007dc4a55cec00  jmp 0x00007DC4A53FE110
00007dc4a55cec05  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cec0d  jz 0x00007DC4A55CEDF0
00007dc4a55cec13  nop [rax+rax*1], ax
00007dc4a55cec1c  nop [rax+rax*1], eax
00007dc4a55cec24  mov eax, 0x4101D8
00007dc4a55cec29  mov [r15+0x100], rax
00007dc4a55cec30  jmp 0x00007DC4A53FE110
00007dc4a55cec35  int3
00007dc4a55cec36  call 0x00007DC4A540BAE0
00007dc4a55cec3b  jmp 0x00007DC4A55CEBB4
00007dc4a55cec40  int3
00007dc4a55cec41  nop [rax+rax*1], ax
00007dc4a55cec4a  nop [rax+rax*1], ax
00007dc4a55cec50  mov eax, [r15+0x50]
00007dc4a55cec54  lea r14d, [eax-0x01]
00007dc4a55cec59  mov r14d, r14d
00007dc4a55cec5c  mov [r15+0x58], r14
00007dc4a55cec60  mov rax, [r15+0x58]
00007dc4a55cec64  mov r14d, eax
00007dc4a55cec67  mov r14d, r14d
00007dc4a55cec6a  shl r14, 0x02
00007dc4a55cec6e  mov rax, [r15+0x98]
00007dc4a55cec75  lea r12, [rax+r14*1]
00007dc4a55cec79  mov eax, [r13+r12*1]
00007dc4a55cec7e  mov [rsp+0x10], eax
00007dc4a55cec82  mov eax, eax
00007dc4a55cec84  mov [r15+0x60], rax
00007dc4a55cec88  mov eax, [r15+0x48]
00007dc4a55cec8c  mov [rsp+0x20], eax
00007dc4a55cec90  xor eax, eax
00007dc4a55cec92  mov r14d, [rsp+0x10]
00007dc4a55cec97  mov r12d, [rsp+0x20]
00007dc4a55cec9c  cmp r14d, r12d
00007dc4a55cec9f  cmc
00007dc4a55ceca0  lahf
00007dc4a55ceca1  seto al
00007dc4a55ceca4  mov [r15+0x108], eax
00007dc4a55cecab  mov eax, [r15+0x108]
00007dc4a55cecb2  sahf
00007dc4a55cecb3  cmc
00007dc4a55cecb4  jbe 0x00007DC4A55CECE6
00007dc4a55cecb6  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cecbe  jz 0x00007DC4A55CEA90
00007dc4a55cecc4  nop [rax+rax*1], ax
00007dc4a55ceccd  nop [rax+rax*1], eax
00007dc4a55cecd5  mov eax, 0x4101C8
00007dc4a55cecda  mov [r15+0x100], rax
00007dc4a55cece1  jmp 0x00007DC4A53FE110
00007dc4a55cece6  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cecee  jz 0x00007DC4A55CED30
00007dc4a55cecf4  nop [rax+rax*1], ax
00007dc4a55cecfd  nop [rax+rax*1], eax
00007dc4a55ced05  mov eax, 0x4101A0
00007dc4a55ced0a  mov [r15+0x100], rax
00007dc4a55ced11  jmp 0x00007DC4A53FE110
00007dc4a55ced16  int3
00007dc4a55ced17  call 0x00007DC4A54B4690
00007dc4a55ced1c  jmp 0x00007DC4A55CEC7E
00007dc4a55ced21  int3
00007dc4a55ced22  nop [rax+rax*1], ax
00007dc4a55ced2b  nop [rax+rax*1], eax
00007dc4a55ced30  mov rax, [r15+0x40]
00007dc4a55ced34  lea r14, [rax+0x01]
00007dc4a55ced38  mov [r15+0x40], r14
00007dc4a55ced3c  mov rax, [r15+0x50]
00007dc4a55ced40  mov r12d, eax
00007dc4a55ced43  mov r12d, r12d
00007dc4a55ced46  shl r12, 0x02
00007dc4a55ced4a  mov rax, [r15+0x98]
00007dc4a55ced51  lea r11, [rax+r12*1]
00007dc4a55ced55  mov eax, [r15+0x48]
00007dc4a55ced59  mov [r13+r11*1], eax
00007dc4a55ced5e  xor eax, eax
00007dc4a55ced60  mov r12d, 0x400
00007dc4a55ced66  cmp r14, r12
00007dc4a55ced69  cmc
00007dc4a55ced6a  lahf
00007dc4a55ced6b  seto al
00007dc4a55ced6e  mov [r15+0x108], eax
00007dc4a55ced75  mov eax, [r15+0x108]
00007dc4a55ced7c  sahf
00007dc4a55ced7d  jz 0x00007DC4A55CEDAF
00007dc4a55ced7f  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ced87  jz 0x00007DC4A55CE990
00007dc4a55ced8d  nop [rax+rax*1], ax
00007dc4a55ced96  nop [rax+rax*1], eax
00007dc4a55ced9e  mov eax, 0x4101B0
00007dc4a55ceda3  mov [r15+0x100], rax
00007dc4a55cedaa  jmp 0x00007DC4A53FE110
00007dc4a55cedaf  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cedb7  jz 0x00007DC4A55CEDF0
00007dc4a55cedbd  nop [rax+rax*1], ax
00007dc4a55cedc6  nop [rax+rax*1], eax
00007dc4a55cedce  mov eax, 0x4101D8
00007dc4a55cedd3  mov [r15+0x100], rax
00007dc4a55cedda  jmp 0x00007DC4A53FE110
00007dc4a55ceddf  int3
00007dc4a55cede0  call 0x00007DC4A54A4270
00007dc4a55cede5  jmp 0x00007DC4A55CED5E
00007dc4a55cedea  int3
00007dc4a55cedeb  nop [rax+rax*1], eax
00007dc4a55cedf0  mov qword ptr [r15+0x40], 0x420000
00007dc4a55cedf8  mov eax, 0x420288
00007dc4a55cedfd  mov r14, [r13+rax*1]
00007dc4a55cee02  mov rax, [r15+0x98]
00007dc4a55cee09  mov r12d, [r13+rax*1]
00007dc4a55cee0e  lea r11, [rax+0x04]
00007dc4a55cee12  mov eax, [r13+r11*1]
00007dc4a55cee17  mov r12d, r12d
00007dc4a55cee1a  mov [r15+0x68], r12
00007dc4a55cee1e  mov eax, eax
00007dc4a55cee20  mov [r15+0x60], rax
00007dc4a55cee24  mov rax, [r15+0x68]
00007dc4a55cee28  mov [r15+0x68], rax
00007dc4a55cee2c  mov qword ptr [r15+0x58], 0x02
00007dc4a55cee34  mov [rsp+0x10], rax
00007dc4a55cee39  xor eax, eax
00007dc4a55cee3b  mov r12d, 0x02
00007dc4a55cee41  mov r11d, 0x400
00007dc4a55cee47  cmp r12, r11
00007dc4a55cee4a  cmc
00007dc4a55cee4b  lahf
00007dc4a55cee4c  seto al
00007dc4a55cee4f  mov [r15+0x108], eax
00007dc4a55cee56  mov rax, [r15+0x60]
00007dc4a55cee5a  mov r12d, 0x02
00007dc4a55cee60  imul rax, r12
00007dc4a55cee64  mov [r15+0x50], rax
00007dc4a55cee68  mov rax, [rsp+0x10]
00007dc4a55cee6d  lea r12, [rax+r14*1]
00007dc4a55cee71  mov [r15+0x48], r12
00007dc4a55cee75  mov eax, [r15+0x108]
00007dc4a55cee7c  sahf
00007dc4a55cee7d  jnz 0x00007DC4A55CEEAF
00007dc4a55cee7f  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cee87  jz 0x00007DC4A55CF020
00007dc4a55cee8d  nop [rax+rax*1], ax
00007dc4a55cee96  nop [rax+rax*1], eax
00007dc4a55cee9e  mov eax, 0x410208
00007dc4a55ceea3  mov [r15+0x100], rax
00007dc4a55ceeaa  jmp 0x00007DC4A53FE110
00007dc4a55ceeaf  cmp dword ptr [r15+0x318], 0x00
00007dc4a55ceeb7  jz 0x00007DC4A55CEF00
00007dc4a55ceebd  nop [rax+rax*1], ax
00007dc4a55ceec6  nop [rax+rax*1], eax
00007dc4a55ceece  mov eax, 0x4101E8
00007dc4a55ceed3  mov [r15+0x100], rax
00007dc4a55ceeda  jmp 0x00007DC4A53FE110
00007dc4a55ceedf  int3
00007dc4a55ceee0  call 0x00007DC4A540DC20
00007dc4a55ceee5  jmp 0x00007DC4A55CEE02
00007dc4a55ceeea  call 0x00007DC4A540B5E0
00007dc4a55ceeef  jmp 0x00007DC4A55CEE0E
00007dc4a55ceef4  call 0x00007DC4A54A3D90
00007dc4a55ceef9  jmp 0x00007DC4A55CEE17
00007dc4a55ceefe  int3
00007dc4a55ceeff  nop
00007dc4a55cef00  mov rax, [r15+0x98]
00007dc4a55cef07  mov r14, [r15+0x58]
00007dc4a55cef0b  mov [rsp+0x10], r14
00007dc4a55cef10  shl r14, 0x02
00007dc4a55cef14  lea r12, [rax+r14*1]
00007dc4a55cef18  mov eax, [r13+r12*1]
00007dc4a55cef1d  lea r14, [r12+0x04]
00007dc4a55cef22  mov r12d, [r13+r14*1]
00007dc4a55cef27  mov eax, eax
00007dc4a55cef29  mov [r15+0x68], rax
00007dc4a55cef2d  mov r12d, r12d
00007dc4a55cef30  mov [r15+0x60], r12
00007dc4a55cef34  mov rax, [r15+0x68]
00007dc4a55cef38  mov [rsp+0x20], rax
00007dc4a55cef3d  mov r14, [rsp+0x10]
00007dc4a55cef42  imul rax, r14
00007dc4a55cef46  mov r12, [rsp+0x20]
00007dc4a55cef4b  lea r11, [r12+rax*1]
00007dc4a55cef4f  mov [r15+0x68], r11
00007dc4a55cef53  lea rax, [r14+0x02]
00007dc4a55cef57  mov [r15+0x58], rax
00007dc4a55cef5b  mov [rsp+0x10], rax
00007dc4a55cef60  xor eax, eax
00007dc4a55cef62  mov r14, [rsp+0x10]
00007dc4a55cef67  mov r12d, 0x400
00007dc4a55cef6d  cmp r14, r12
00007dc4a55cef70  cmc
00007dc4a55cef71  lahf
00007dc4a55cef72  seto al
00007dc4a55cef75  mov [r15+0x108], eax
00007dc4a55cef7c  mov rax, [r15+0x50]
00007dc4a55cef80  mov r12, [r15+0x60]
00007dc4a55cef84  imul r14, r12
00007dc4a55cef88  lea r12, [rax+r14*1]
00007dc4a55cef8c  mov [r15+0x50], r12
00007dc4a55cef90  mov rax, [r15+0x48]
00007dc4a55cef94  lea r14, [r11+rax*1]
00007dc4a55cef98  mov [r15+0x48], r14
00007dc4a55cef9c  mov eax, [r15+0x108]
00007dc4a55cefa3  sahf
00007dc4a55cefa4  jnz 0x00007DC4A55CEFD6
00007dc4a55cefa6  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cefae  jz 0x00007DC4A55CF020
00007dc4a55cefb4  nop [rax+rax*1], ax
00007dc4a55cefbd  nop [rax+rax*1], eax
00007dc4a55cefc5  mov eax, 0x410208
00007dc4a55cefca  mov [r15+0x100], rax
00007dc4a55cefd1  jmp 0x00007DC4A53FE110
00007dc4a55cefd6  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cefde  jz 0x00007DC4A55CEF00
00007dc4a55cefe4  nop [rax+rax*1], ax
00007dc4a55cefed  nop [rax+rax*1], eax
00007dc4a55ceff5  mov eax, 0x4101E8
00007dc4a55ceffa  mov [r15+0x100], rax
00007dc4a55cf001  jmp 0x00007DC4A53FE110
00007dc4a55cf006  int3
00007dc4a55cf007  call 0x00007DC4A54B4690
00007dc4a55cf00c  jmp 0x00007DC4A55CEF1D
00007dc4a55cf011  call 0x00007DC4A54E26A0
00007dc4a55cf016  jmp 0x00007DC4A55CEF27
00007dc4a55cf01b  int3
00007dc4a55cf01c  nop [rax], eax
00007dc4a55cf020  mov rax, [r15+0xF8]
00007dc4a55cf027  lea r14, [rax+0x10]
00007dc4a55cf02b  mov r12, [r13+r14*1]
00007dc4a55cf030  lea r14, [rax+0x18]
00007dc4a55cf034  mov r11, [r13+r14*1]
00007dc4a55cf039  mov [r15+0xA0], r12
00007dc4a55cf040  mov [r15+0x98], r11
00007dc4a55cf047  mov r14, [r15+0x50]
00007dc4a55cf04b  mov r12, [r15+0x48]
00007dc4a55cf04f  lea r11, [r14+r12*1]
00007dc4a55cf053  mov [r15+0x48], r11
00007dc4a55cf057  mov r14, [r15+0x40]
00007dc4a55cf05b  lea r12, [r14+0x288]
00007dc4a55cf062  mov [r13+r12*1], r11
00007dc4a55cf067  mov r14, [r13+rax*1]
00007dc4a55cf06c  mov [r15+0xF0], r14
00007dc4a55cf073  lea r12, [rax+0x20]
00007dc4a55cf077  mov [r15+0xF8], r12
00007dc4a55cf07e  mov [r15+0x100], r14
00007dc4a55cf085  jmp 0x00007DC4A55CE5C0
00007dc4a55cf08a  int3
00007dc4a55cf08b  call 0x00007DC4A54E27E0
00007dc4a55cf090  jmp 0x00007DC4A55CF030
00007dc4a55cf095  call 0x00007DC4A54E1570
00007dc4a55cf09a  jmp 0x00007DC4A55CF039
00007dc4a55cf09f  call 0x00007DC4A54C0860
00007dc4a55cf0a4  jmp 0x00007DC4A55CF067
00007dc4a55cf0a9  call 0x00007DC4A540DC20
00007dc4a55cf0ae  jmp 0x00007DC4A55CF06C
00007dc4a55cf0b3  int3
00007dc4a55cf0b4  nop [rax+rax*1], ax
00007dc4a55cf0bd  nop [rax], eax
00007dc4a55cf0c0  mov qword ptr [r15+0x100], 0x04
00007dc4a55cf0cb  mov esi, 0x00
00007dc4a55cf0d0  mov edx, 0x09
00007dc4a55cf0d5  mov rdi, 0x7FFDA66AEC70
00007dc4a55cf0df  mov rax, 0x5CAAAF6C5970
00007dc4a55cf0e9  call rax
00007dc4a55cf0eb  cmp dword ptr [r15+0x318], 0x00
00007dc4a55cf0f3  jnz 0x00007DC4A53FE110
00007dc4a55cf0f9  jmp 0x00007DC4A53FE0A0
00007dc4a55cf0fe  int3
00007dc4a55cf0ff  int3
