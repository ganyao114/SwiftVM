
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sort/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13,QWORD PTR [r12+0xf8]
   8:	mov    r14,r13
   b:	sub    r14,0x20
   f:	mov    r13,QWORD PTR [r12+0xf0]
  17:	mov    QWORD PTR [r14],r13
  1a:	mov    r13d,0x0
  20:	mov    DWORD PTR [r12+0x32c],r13d
  28:	mov    QWORD PTR [r12+0xf8],r14
  30:	mov    r13,r14
  33:	add    r13,0x10
  37:	mov    r14,r13
  3a:	add    r14,0x8
  3e:	mov    r15,QWORD PTR [r12+0xa0]
  46:	mov    rbp,QWORD PTR [r12+0x98]
  4e:	mov    QWORD PTR [r13+0x0],r15
  52:	mov    r13d,0x0
  58:	mov    DWORD PTR [r12+0x32c],r13d
  60:	mov    QWORD PTR [r14],rbp
  63:	mov    r13d,0x0
  69:	mov    DWORD PTR [r12+0x32c],r13d
  71:	mov    r13d,0x0
  77:	mov    QWORD PTR [r12+0xa0],r13
  7f:	mov    r13d,0x420000
  85:	mov    QWORD PTR [r12+0x98],r13
  8d:	mov    r13d,0x420000
  93:	mov    r14,r13
  96:	add    r14,0x2a0
  9d:	mov    QWORD PTR [r12+0x98],r14
  a5:	mov    r13d,0x11
  ab:	mov    QWORD PTR [r12],r13
  af:	mov    r13d,0x410184
  b5:	mov    QWORD PTR [r12+0xf0],r13
  bd:	mov    r13d,0x41021c
  c3:	mov    QWORD PTR [r12+0x100],r13
  cb:	mov    QWORD PTR [r12+0x108],rbx
  d3:	mov    edi,0x41021c
  d8:	mov    QWORD PTR [r12+0x100],rdi
  e0:	jmp    QWORD PTR [rip+0x2]        # 0xe8
  e6:	xchg   ax,ax
  e8:	adc    cl,ah
  ea:	bt     DWORD PTR [rax],ebx
  ed:	jb     0xef
  ef:	add    al,bh
  f1:	loopne 0x102
  f3:	movabs ds:0x6370bb4900007218,eax
  fc:	xchg   ecx,eax
  fd:	mov    cl,0x21
  ff:	add    BYTE PTR fs:[rax],al
 102:	jmp    r11
 105:	nop
 106:	nop
 107:	nop
