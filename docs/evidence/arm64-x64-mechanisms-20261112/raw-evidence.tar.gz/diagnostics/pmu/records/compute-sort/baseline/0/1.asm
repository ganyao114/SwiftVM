
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sort/baseline/0/1.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13d,0x352d
   6:	mov    QWORD PTR [r12+0x40],r13
   b:	mov    r13d,0xa68b
  11:	mov    QWORD PTR [r12+0x48],r13
  16:	mov    r13d,0x352d
  1c:	mov    r14d,0x7feb
  22:	and    r14d,0xffff
  29:	mov    rax,r13
  2c:	movabs rcx,0xffffffff0000ffff
  36:	and    rax,rcx
  39:	mov    rdx,r14
  3c:	shl    rdx,0x10
  40:	mov    ecx,0xffff0000
  45:	and    rdx,rcx
  48:	or     rax,rdx
  4b:	mov    r15d,eax
  4e:	mov    QWORD PTR [r12+0x40],r15
  53:	mov    r13d,0xa68b
  59:	mov    r14d,0x846c
  5f:	and    r14d,0xffff
  66:	mov    rax,r13
  69:	movabs rcx,0xffffffff0000ffff
  73:	and    rax,rcx
  76:	mov    rdx,r14
  79:	shl    rdx,0x10
  7d:	mov    ecx,0xffff0000
  82:	and    rdx,rcx
  85:	or     rax,rdx
  88:	mov    ebp,eax
  8a:	mov    QWORD PTR [r12+0x48],rbp
  8f:	mov    r13d,DWORD PTR [r12]
  93:	mov    r14d,0x0
  99:	mov    eax,r13d
  9c:	mov    ecx,r15d
  9f:	imul   rax,rcx
  a3:	mov    r8d,eax
  a6:	mov    ecx,r8d
  a9:	mov    r13d,r14d
  ac:	add    r13d,ecx
  af:	mov    QWORD PTR [r12+0x40],r13
  b4:	mov    r14d,r13d
  b7:	mov    r14d,r14d
  ba:	shr    r14d,0xf
  be:	mov    r14d,r14d
  c1:	mov    ecx,r14d
  c4:	mov    r15d,r13d
  c7:	xor    r15,rcx
  ca:	mov    r15d,r15d
  cd:	mov    QWORD PTR [r12+0x40],r15
  d2:	mov    r13d,0x0
  d8:	mov    eax,r15d
  db:	mov    ecx,ebp
  dd:	imul   rax,rcx
  e1:	mov    r14d,eax
  e4:	mov    ecx,r14d
  e7:	mov    r15d,r13d
  ea:	add    r15d,ecx
  ed:	mov    QWORD PTR [r12+0x40],r15
  f2:	mov    r13d,r15d
  f5:	mov    r13d,r13d
  f8:	shr    r13d,0x10
  fc:	mov    r13d,r13d
  ff:	mov    ecx,r13d
 102:	mov    r14d,r15d
 105:	xor    r14,rcx
 108:	mov    r14d,r14d
 10b:	mov    QWORD PTR [r12],r14
 10f:	cmp    QWORD PTR [r12+0x380],0x0
 118:	je     0x145
 11e:	mov    eax,0x41023c
 123:	mov    QWORD PTR [r12+0x100],rax
 12b:	mov    QWORD PTR [r12+0x108],rbx
 133:	mov    eax,0xc
 138:	movabs r11,0x6421b19165f0
 142:	jmp    r11
 145:	mov    r13,QWORD PTR [r12+0xf0]
 14d:	mov    QWORD PTR [r12+0x100],r13
 155:	mov    QWORD PTR [r12+0x108],rbx
 15d:	mov    rdi,QWORD PTR [r12+0x100]
 165:	movabs r11,0x6421b1916370
 16f:	jmp    r11
 172:	nop
 173:	nop
