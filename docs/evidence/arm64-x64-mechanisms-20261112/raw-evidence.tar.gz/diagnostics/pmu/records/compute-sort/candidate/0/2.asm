
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sort/candidate/0/2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xa0]
  18:	mov    r14,r13
  1b:	shl    r14,0x2
  1f:	mov    r15,QWORD PTR [r12+0x98]
  27:	mov    rcx,r14
  2a:	add    r15,rcx
  2d:	mov    r14d,DWORD PTR [r12]
  31:	mov    DWORD PTR [r15],r14d
  34:	mov    r14d,0x0
  3a:	mov    DWORD PTR [r12+0x32c],r14d
  42:	add    r13,0x1
  46:	mov    QWORD PTR [r12+0xa0],r13
  4e:	sub    r13,0x400
  55:	mov    rcx,QWORD PTR [r12+0x380]
  5d:	jrcxz  0x64
  5f:	jmp    0x45d
  64:	pushf
  65:	pop    r11
  67:	mov    QWORD PTR [rsp],r11
  6b:	jne    0x3ee
  71:	jmp    0x76
  76:	mov    r13d,0x1
  7c:	mov    QWORD PTR [r12+0x40],r13
  81:	jmp    0x86
  86:	mov    r13,QWORD PTR [r12+0x40]
  8b:	mov    r14,r13
  8e:	shl    r14,0x2
  92:	mov    r15,QWORD PTR [r12+0x98]
  9a:	mov    rcx,r14
  9d:	add    r15,rcx
  a0:	mov    r14d,DWORD PTR [r15]
  a3:	mov    QWORD PTR [r12+0x48],r14
  a8:	mov    r14d,0x0
  ae:	mov    rcx,r13
  b1:	or     r14,rcx
  b4:	mov    QWORD PTR [r12+0x50],r14
  b9:	jmp    0xbe
  be:	mov    r13d,DWORD PTR [r12+0x50]
  c3:	sub    r13d,0x1
  c7:	mov    QWORD PTR [r12+0x58],r13
  cc:	mov    ecx,0xffffffff
  d1:	mov    r14,r13
  d4:	and    r14,rcx
  d7:	shl    r14,0x2
  db:	mov    r13,QWORD PTR [r12+0x98]
  e3:	mov    rcx,r14
  e6:	add    r13,rcx
  e9:	mov    r14d,DWORD PTR [r13+0x0]
  ed:	mov    QWORD PTR [r12+0x60],r14
  f2:	mov    r13d,DWORD PTR [r12+0x48]
  f7:	mov    ecx,r13d
  fa:	sub    r14d,ecx
  fd:	mov    rcx,QWORD PTR [r12+0x380]
 105:	jrcxz  0x10c
 107:	jmp    0x4ec
 10c:	sete   al
 10f:	movzx  eax,al
 112:	mov    r13,rax
 115:	setb   al
 118:	movzx  eax,al
 11b:	mov    r14,rax
 11e:	pushf
 11f:	pop    r11
 121:	mov    QWORD PTR [rsp],r11
 125:	mov    rcx,r13
 128:	and    ecx,0xff
 12e:	mov    r15,r14
 131:	and    r15d,0xff
 138:	or     r15,rcx
 13b:	and    r15d,0xff
 142:	mov    rax,r15
 145:	and    eax,0xff
 14a:	test   rax,rax
 14d:	jne    0x1ef
 153:	jmp    0x158
 158:	mov    r13,QWORD PTR [r12+0x50]
 15d:	mov    r14,r13
 160:	shl    r14,0x2
 164:	mov    r15,QWORD PTR [r12+0x98]
 16c:	mov    rcx,r14
 16f:	add    r15,rcx
 172:	mov    r14d,DWORD PTR [r12+0x60]
 177:	mov    DWORD PTR [r15],r14d
 17a:	mov    r14d,0x0
 180:	mov    DWORD PTR [r12+0x32c],r14d
 188:	sub    r13,0x1
 18c:	mov    QWORD PTR [r12+0x50],r13
 191:	mov    rcx,QWORD PTR [r12+0x380]
 199:	jrcxz  0x1a0
 19b:	jmp    0x57b
 1a0:	mov    r13,QWORD PTR [r12+0x58]
 1a5:	mov    rax,r13
 1a8:	test   rax,rax
 1ab:	setne  al
 1ae:	movzx  eax,al
 1b1:	and    eax,0x1
 1b4:	mov    r14,rax
 1b7:	mov    rax,r14
 1ba:	and    eax,0x1
 1bd:	test   rax,rax
 1c0:	jne    0xbe
 1c6:	jmp    0x1cb
 1cb:	mov    rcx,QWORD PTR [r12+0x380]
 1d3:	jrcxz  0x1da
 1d5:	jmp    0x602
 1da:	jmp    0x1df
 1df:	mov    r13d,0x0
 1e5:	mov    QWORD PTR [r12+0x50],r13
 1ea:	jmp    0x1ef
 1ef:	mov    r13,QWORD PTR [r12+0x40]
 1f4:	add    r13,0x1
 1f8:	mov    QWORD PTR [r12+0x40],r13
 1fd:	mov    r14,QWORD PTR [r12+0x50]
 202:	mov    ecx,0xffffffff
 207:	and    r14,rcx
 20a:	shl    r14,0x2
 20e:	mov    r15,QWORD PTR [r12+0x98]
 216:	mov    rcx,r14
 219:	add    r15,rcx
 21c:	mov    r14d,DWORD PTR [r12+0x48]
 221:	mov    DWORD PTR [r15],r14d
 224:	mov    r14d,0x0
 22a:	mov    DWORD PTR [r12+0x32c],r14d
 232:	sub    r13,0x400
 239:	pushf
 23a:	pop    r11
 23c:	mov    QWORD PTR [rsp],r11
 240:	je     0x24b
 246:	jmp    0x86
 24b:	mov    r13d,0x420000
 251:	mov    QWORD PTR [r12+0x40],r13
 256:	mov    r13d,0x0
 25c:	mov    QWORD PTR [r12+0x58],r13
 261:	mov    r13d,0x0
 267:	mov    QWORD PTR [r12+0x50],r13
 26c:	mov    r13d,0x420288
 272:	mov    r14,QWORD PTR [r13+0x0]
 276:	mov    QWORD PTR [r12+0x48],r14
 27b:	jmp    0x280
 280:	mov    r13,QWORD PTR [r12+0x58]
 285:	mov    r14,r13
 288:	shl    r14,0x2
 28c:	mov    r15,QWORD PTR [r12+0x98]
 294:	mov    rcx,r14
 297:	add    r15,rcx
 29a:	mov    QWORD PTR [r12+0x60],r15
 29f:	mov    r14,r15
 2a2:	add    r14,0x4
 2a6:	mov    ebp,DWORD PTR [r15]
 2a9:	mov    r15d,DWORD PTR [r14]
 2ac:	mov    QWORD PTR [r12+0x60],r15
 2b1:	mov    rax,rbp
 2b4:	mov    rcx,r13
 2b7:	imul   rax,rcx
 2bb:	mov    r14,rax
 2be:	mov    rcx,r14
 2c1:	mov    r8,rbp
 2c4:	add    r8,rcx
 2c7:	mov    QWORD PTR [r12+0x68],r8
 2cc:	add    r13,0x2
 2d0:	mov    QWORD PTR [r12+0x58],r13
 2d5:	mov    r14,r13
 2d8:	sub    r14,0x400
 2df:	mov    r14,QWORD PTR [r12+0x50]
 2e4:	pushf
 2e5:	pop    r11
 2e7:	mov    QWORD PTR [rsp],r11
 2eb:	mov    rax,r13
 2ee:	mov    rcx,r15
 2f1:	imul   rax,rcx
 2f5:	mov    rbp,rax
 2f8:	mov    rcx,rbp
 2fb:	add    r14,rcx
 2fe:	mov    QWORD PTR [r12+0x50],r14
 303:	mov    r13,QWORD PTR [r12+0x48]
 308:	mov    rcx,r13
 30b:	add    r8,rcx
 30e:	mov    QWORD PTR [r12+0x48],r8
 313:	mov    rcx,QWORD PTR [r12+0x380]
 31b:	jrcxz  0x322
 31d:	jmp    0x689
 322:	push   QWORD PTR [rsp]
 325:	popf
 326:	jne    0x280
 32c:	jmp    0x331
 331:	mov    r13,QWORD PTR [r12+0xf8]
 339:	mov    r14,r13
 33c:	add    r14,0x10
 340:	mov    r15,r14
 343:	add    r15,0x8
 347:	mov    rbp,QWORD PTR [r14]
 34a:	mov    r14,QWORD PTR [r15]
 34d:	mov    QWORD PTR [r12+0xa0],rbp
 355:	mov    QWORD PTR [r12+0x98],r14
 35d:	mov    r14,QWORD PTR [r12+0x48]
 362:	mov    r15,QWORD PTR [r12+0x50]
 367:	mov    rcx,r14
 36a:	add    r15,rcx
 36d:	mov    QWORD PTR [r12+0x48],r15
 372:	mov    r14,QWORD PTR [r12+0x40]
 377:	add    r14,0x288
 37e:	mov    QWORD PTR [r14],r15
 381:	mov    r14d,0x0
 387:	mov    DWORD PTR [r12+0x32c],r14d
 38f:	mov    r14,r13
 392:	add    r14,0x20
 396:	mov    r15,QWORD PTR [r13+0x0]
 39a:	mov    QWORD PTR [r12+0xf0],r15
 3a2:	mov    QWORD PTR [r12+0xf8],r14
 3aa:	mov    rcx,QWORD PTR [r12+0x380]
 3b2:	jrcxz  0x3b9
 3b4:	jmp    0x710
 3b9:	mov    r13,QWORD PTR [r12+0xf0]
 3c1:	mov    QWORD PTR [r12+0x100],r13
 3c9:	mov    r11,QWORD PTR [rsp]
 3cd:	mov    QWORD PTR [r12+0x398],r11
 3d5:	mov    rdi,QWORD PTR [r12+0x100]
 3dd:	add    rsp,0x10
 3e1:	movabs r11,0x5b456641c0a0
 3eb:	jmp    r11
 3ee:	mov    r13d,DWORD PTR [r12+0xa0]
 3f6:	add    r13d,0x11
 3fa:	mov    QWORD PTR [r12],r13
 3fe:	mov    r13d,0x410184
 404:	mov    QWORD PTR [r12+0xf0],r13
 40c:	mov    r13d,0x41021c
 412:	mov    QWORD PTR [r12+0x100],r13
 41a:	mov    r11,QWORD PTR [rsp]
 41e:	mov    QWORD PTR [r12+0x398],r11
 426:	mov    edi,0x41021c
 42b:	mov    QWORD PTR [r12+0x100],rdi
 433:	add    rsp,0x10
 437:	nop
 438:	jmp    QWORD PTR [rip+0x2]        # 0x440
 43e:	xchg   ax,ax
 440:	adc    cl,ah
 442:	packssdw mm2,QWORD PTR [rsi+0x79]
 446:	add    BYTE PTR [rax],al
 448:	rex out 0xf,eax
 44b:	imul   edx,DWORD PTR [rsi+0x79],0x0
 44f:	add    BYTE PTR [rcx-0x45],cl
 452:	movabs al,ds:0x4100005b456641c0
 45b:	jmp    rbx
 45d:	mov    eax,0x410190
 462:	mov    QWORD PTR [r12+0x100],rax
 46a:	push   rdx
 46b:	push   rsi
 46c:	push   r10
 46e:	push   r11
 470:	pushf
 471:	pop    r11
 473:	mov    QWORD PTR [rsp+0x20],r11
 478:	mov    rdx,QWORD PTR [rsp+0x20]
 47d:	mov    r10d,edx
 480:	and    r10d,0xc0
 487:	shl    r10d,0x18
 48b:	mov    r11d,edx
 48e:	and    r11d,0x1
 492:	shl    r11d,0x1d
 496:	or     r10d,r11d
 499:	mov    r11d,edx
 49c:	and    r11d,0x800
 4a3:	shl    r11d,0x11
 4a7:	or     r10d,r11d
 4aa:	btc    r10,0x1d
 4af:	mov    r11d,0xf0000000
 4b5:	and    r11,r10
 4b8:	movabs rsi,0xffffffff0fffffff
 4c2:	and    rbx,rsi
 4c5:	or     rbx,r11
 4c8:	pop    r11
 4ca:	pop    r10
 4cc:	pop    rsi
 4cd:	pop    rdx
 4ce:	mov    QWORD PTR [r12+0x108],rbx
 4d6:	add    rsp,0x10
 4da:	mov    eax,0xc
 4df:	movabs r11,0x5b456641c390
 4e9:	jmp    r11
 4ec:	mov    eax,0x4101c4
 4f1:	mov    QWORD PTR [r12+0x100],rax
 4f9:	push   rdx
 4fa:	push   rsi
 4fb:	push   r10
 4fd:	push   r11
 4ff:	pushf
 500:	pop    r11
 502:	mov    QWORD PTR [rsp+0x20],r11
 507:	mov    rdx,QWORD PTR [rsp+0x20]
 50c:	mov    r10d,edx
 50f:	and    r10d,0xc0
 516:	shl    r10d,0x18
 51a:	mov    r11d,edx
 51d:	and    r11d,0x1
 521:	shl    r11d,0x1d
 525:	or     r10d,r11d
 528:	mov    r11d,edx
 52b:	and    r11d,0x800
 532:	shl    r11d,0x11
 536:	or     r10d,r11d
 539:	btc    r10,0x1d
 53e:	mov    r11d,0xf0000000
 544:	and    r11,r10
 547:	movabs rsi,0xffffffff0fffffff
 551:	and    rbx,rsi
 554:	or     rbx,r11
 557:	pop    r11
 559:	pop    r10
 55b:	pop    rsi
 55c:	pop    rdx
 55d:	mov    QWORD PTR [r12+0x108],rbx
 565:	add    rsp,0x10
 569:	mov    eax,0xc
 56e:	movabs r11,0x5b456641c390
 578:	jmp    r11
 57b:	mov    eax,0x4101d0
 580:	mov    QWORD PTR [r12+0x100],rax
 588:	push   rdx
 589:	push   rsi
 58a:	push   r10
 58c:	push   r11
 58e:	mov    rdx,QWORD PTR [rsp+0x20]
 593:	mov    r10d,edx
 596:	and    r10d,0xc0
 59d:	shl    r10d,0x18
 5a1:	mov    r11d,edx
 5a4:	and    r11d,0x1
 5a8:	shl    r11d,0x1d
 5ac:	or     r10d,r11d
 5af:	mov    r11d,edx
 5b2:	and    r11d,0x800
 5b9:	shl    r11d,0x11
 5bd:	or     r10d,r11d
 5c0:	btc    r10,0x1d
 5c5:	mov    r11d,0xf0000000
 5cb:	and    r11,r10
 5ce:	movabs rsi,0xffffffff0fffffff
 5d8:	and    rbx,rsi
 5db:	or     rbx,r11
 5de:	pop    r11
 5e0:	pop    r10
 5e2:	pop    rsi
 5e3:	pop    rdx
 5e4:	mov    QWORD PTR [r12+0x108],rbx
 5ec:	add    rsp,0x10
 5f0:	mov    eax,0xc
 5f5:	movabs r11,0x5b456641c390
 5ff:	jmp    r11
 602:	mov    eax,0x4101d4
 607:	mov    QWORD PTR [r12+0x100],rax
 60f:	push   rdx
 610:	push   rsi
 611:	push   r10
 613:	push   r11
 615:	mov    rdx,QWORD PTR [rsp+0x20]
 61a:	mov    r10d,edx
 61d:	and    r10d,0xc0
 624:	shl    r10d,0x18
 628:	mov    r11d,edx
 62b:	and    r11d,0x1
 62f:	shl    r11d,0x1d
 633:	or     r10d,r11d
 636:	mov    r11d,edx
 639:	and    r11d,0x800
 640:	shl    r11d,0x11
 644:	or     r10d,r11d
 647:	btc    r10,0x1d
 64c:	mov    r11d,0xf0000000
 652:	and    r11,r10
 655:	movabs rsi,0xffffffff0fffffff
 65f:	and    rbx,rsi
 662:	or     rbx,r11
 665:	pop    r11
 667:	pop    r10
 669:	pop    rsi
 66a:	pop    rdx
 66b:	mov    QWORD PTR [r12+0x108],rbx
 673:	add    rsp,0x10
 677:	mov    eax,0xc
 67c:	movabs r11,0x5b456641c390
 686:	jmp    r11
 689:	mov    eax,0x410204
 68e:	mov    QWORD PTR [r12+0x100],rax
 696:	push   rdx
 697:	push   rsi
 698:	push   r10
 69a:	push   r11
 69c:	mov    rdx,QWORD PTR [rsp+0x20]
 6a1:	mov    r10d,edx
 6a4:	and    r10d,0xc0
 6ab:	shl    r10d,0x18
 6af:	mov    r11d,edx
 6b2:	and    r11d,0x1
 6b6:	shl    r11d,0x1d
 6ba:	or     r10d,r11d
 6bd:	mov    r11d,edx
 6c0:	and    r11d,0x800
 6c7:	shl    r11d,0x11
 6cb:	or     r10d,r11d
 6ce:	btc    r10,0x1d
 6d3:	mov    r11d,0xf0000000
 6d9:	and    r11,r10
 6dc:	movabs rsi,0xffffffff0fffffff
 6e6:	and    rbx,rsi
 6e9:	or     rbx,r11
 6ec:	pop    r11
 6ee:	pop    r10
 6f0:	pop    rsi
 6f1:	pop    rdx
 6f2:	mov    QWORD PTR [r12+0x108],rbx
 6fa:	add    rsp,0x10
 6fe:	mov    eax,0xc
 703:	movabs r11,0x5b456641c390
 70d:	jmp    r11
 710:	mov    eax,0x410218
 715:	mov    QWORD PTR [r12+0x100],rax
 71d:	push   rdx
 71e:	push   rsi
 71f:	push   r10
 721:	push   r11
 723:	mov    rdx,QWORD PTR [rsp+0x20]
 728:	mov    r10d,edx
 72b:	and    r10d,0xc0
 732:	shl    r10d,0x18
 736:	mov    r11d,edx
 739:	and    r11d,0x1
 73d:	shl    r11d,0x1d
 741:	or     r10d,r11d
 744:	mov    r11d,edx
 747:	and    r11d,0x800
 74e:	shl    r11d,0x11
 752:	or     r10d,r11d
 755:	btc    r10,0x1d
 75a:	mov    r11d,0xf0000000
 760:	and    r11,r10
 763:	movabs rsi,0xffffffff0fffffff
 76d:	and    rbx,rsi
 770:	or     rbx,r11
 773:	pop    r11
 775:	pop    r10
 777:	pop    rsi
 778:	pop    rdx
 779:	mov    QWORD PTR [r12+0x108],rbx
 781:	add    rsp,0x10
 785:	mov    eax,0xc
 78a:	movabs r11,0x5b456641c390
 794:	jmp    r11
 797:	nop    WORD PTR [rax+rax*1+0x0]
 7a0:	sub    rsp,0x10
 7a4:	mov    r11,QWORD PTR [r12+0x398]
 7ac:	mov    QWORD PTR [rsp],r11
 7b0:	jmp    0x76
 7b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7c0:	sub    rsp,0x10
 7c4:	mov    r11,QWORD PTR [r12+0x398]
 7cc:	mov    QWORD PTR [rsp],r11
 7d0:	jmp    0x86
 7d5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7e0:	sub    rsp,0x10
 7e4:	mov    r11,QWORD PTR [r12+0x398]
 7ec:	mov    QWORD PTR [rsp],r11
 7f0:	jmp    0xbe
 7f5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 800:	sub    rsp,0x10
 804:	mov    r11,QWORD PTR [r12+0x398]
 80c:	mov    QWORD PTR [rsp],r11
 810:	jmp    0x158
 815:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 820:	sub    rsp,0x10
 824:	mov    r11,QWORD PTR [r12+0x398]
 82c:	mov    QWORD PTR [rsp],r11
 830:	jmp    0x1cb
 835:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 840:	sub    rsp,0x10
 844:	mov    r11,QWORD PTR [r12+0x398]
 84c:	mov    QWORD PTR [rsp],r11
 850:	jmp    0x1df
 855:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 860:	sub    rsp,0x10
 864:	mov    r11,QWORD PTR [r12+0x398]
 86c:	mov    QWORD PTR [rsp],r11
 870:	jmp    0x1ef
 875:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 880:	sub    rsp,0x10
 884:	mov    r11,QWORD PTR [r12+0x398]
 88c:	mov    QWORD PTR [rsp],r11
 890:	jmp    0x24b
 895:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 8a0:	sub    rsp,0x10
 8a4:	mov    r11,QWORD PTR [r12+0x398]
 8ac:	mov    QWORD PTR [rsp],r11
 8b0:	jmp    0x280
 8b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 8c0:	sub    rsp,0x10
 8c4:	mov    r11,QWORD PTR [r12+0x398]
 8cc:	mov    QWORD PTR [rsp],r11
 8d0:	jmp    0x331
 8d5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 8e0:	sub    rsp,0x10
 8e4:	mov    r11,QWORD PTR [r12+0x398]
 8ec:	mov    QWORD PTR [rsp],r11
 8f0:	jmp    0x3ee
 8f5:	nop
 8f6:	nop
 8f7:	nop
