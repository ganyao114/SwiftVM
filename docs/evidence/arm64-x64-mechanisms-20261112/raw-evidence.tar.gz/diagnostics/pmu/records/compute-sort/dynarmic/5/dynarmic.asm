00007c9fd8bce69b  nop [rax+rax*1], eax
00007c9fd8bce6a0  mov rax, [r15+0xF8]
00007c9fd8bce6a7  lea r14, [rax-0x20]
00007c9fd8bce6ab  mov r12, [r15+0xF0]
00007c9fd8bce6b2  mov [r13+r14*1], r12
00007c9fd8bce6b7  mov [r15+0xF8], r14
00007c9fd8bce6be  lea r14, [rax-0x10]
00007c9fd8bce6c2  mov r12, [r15+0xA0]
00007c9fd8bce6c9  mov r11, [r15+0x98]
00007c9fd8bce6d0  mov [r13+r14*1], r12
00007c9fd8bce6d5  lea r14, [rax-0x08]
00007c9fd8bce6d9  mov [r13+r14*1], r11
00007c9fd8bce6de  mov qword ptr [r15+0xA0], 0x00
00007c9fd8bce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007c9fd8bce6f4  mov eax, [r15+0xA0]
00007c9fd8bce6fb  lea r14d, [eax+0x11]
00007c9fd8bce700  mov r14d, r14d
00007c9fd8bce703  mov [r15], r14
00007c9fd8bce706  mov qword ptr [r15+0xF0], 0x410184
00007c9fd8bce711  mov r14d, [r15+0x320]
00007c9fd8bce718  mov eax, 0x410184
00007c9fd8bce71d  mov rcx, 0x7C9FD8BCE800
00007c9fd8bce727  mov [r15+r14*8+0x328], rax
00007c9fd8bce72f  mov [r15+r14*8+0x368], rcx
00007c9fd8bce737  add r14d, 0x01
00007c9fd8bce73b  and r14d, 0x07
00007c9fd8bce73f  mov [r15+0x320], r14d
00007c9fd8bce746  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bce74e  jz 0x00007C9FD8BCE7A0
00007c9fd8bce754  nop [rax+rax*1], ax
00007c9fd8bce75d  nop [rax+rax*1], eax
00007c9fd8bce765  mov eax, 0x41021C
00007c9fd8bce76a  mov [r15+0x100], rax
00007c9fd8bce771  jmp 0x00007C9FD89FE110
00007c9fd8bce776  int3
00007c9fd8bce777  call 0x00007C9FD8AE2CE0
00007c9fd8bce77c  jmp 0x00007C9FD8BCE6B7
00007c9fd8bce781  call 0x00007C9FD8AE2CE0
00007c9fd8bce786  jmp 0x00007C9FD8BCE6D5
00007c9fd8bce78b  call 0x00007C9FD8AE1A60
00007c9fd8bce790  jmp 0x00007C9FD8BCE6DE
00007c9fd8bce795  int3
00007c9fd8bce796  nop [rax+rax*1], ax
00007c9fd8bce79f  nop
00007c9fd8bce7a0  mov eax, 0x846CA68B
00007c9fd8bce7a5  mov eax, eax
00007c9fd8bce7a7  mov [r15+0x48], rax
00007c9fd8bce7ab  mov eax, [r15]
00007c9fd8bce7ae  imul eax, eax, 0x7FEB352D
00007c9fd8bce7b4  mov [rsp+0x10], eax
00007c9fd8bce7b8  shr eax, 0x0F
00007c9fd8bce7bb  mov r14d, [rsp+0x10]
00007c9fd8bce7c0  xor r14d, eax
00007c9fd8bce7c3  imul r14d, r14d, 0x846CA68B
00007c9fd8bce7ca  mov [rsp+0x10], r14d
00007c9fd8bce7cf  mov r14d, r14d
00007c9fd8bce7d2  mov [r15+0x40], r14
00007c9fd8bce7d6  mov eax, [rsp+0x10]
00007c9fd8bce7da  shr eax, 0x10
00007c9fd8bce7dd  mov r14d, [rsp+0x10]
00007c9fd8bce7e2  xor r14d, eax
00007c9fd8bce7e5  mov r14d, r14d
00007c9fd8bce7e8  mov [r15], r14
00007c9fd8bce7eb  mov rax, [r15+0xF0]
00007c9fd8bce7f2  mov [r15+0x100], rax
00007c9fd8bce7f9  jmp 0x00007C9FD8BCE5C0
00007c9fd8bce7fe  int3
00007c9fd8bce7ff  int3
00007c9fd8bce800  mov rax, [r15+0xA0]
00007c9fd8bce807  mov [rsp+0x10], rax
00007c9fd8bce80c  shl rax, 0x02
00007c9fd8bce810  mov r14, [r15+0x98]
00007c9fd8bce817  lea r12, [r14+rax*1]
00007c9fd8bce81b  mov eax, [r15]
00007c9fd8bce81e  mov [r13+r12*1], eax
00007c9fd8bce823  mov rax, [rsp+0x10]
00007c9fd8bce828  lea r14, [rax+0x01]
00007c9fd8bce82c  mov [r15+0xA0], r14
00007c9fd8bce833  xor eax, eax
00007c9fd8bce835  mov r12d, 0x400
00007c9fd8bce83b  cmp r14, r12
00007c9fd8bce83e  cmc
00007c9fd8bce83f  lahf
00007c9fd8bce840  seto al
00007c9fd8bce843  mov [r15+0x108], eax
00007c9fd8bce84a  mov eax, [r15+0x108]
00007c9fd8bce851  sahf
00007c9fd8bce852  jnz 0x00007C9FD8BCE884
00007c9fd8bce854  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bce85c  jz 0x00007C9FD8BCE950
00007c9fd8bce862  nop [rax+rax*1], ax
00007c9fd8bce86b  nop [rax+rax*1], eax
00007c9fd8bce873  mov eax, 0x410194
00007c9fd8bce878  mov [r15+0x100], rax
00007c9fd8bce87f  jmp 0x00007C9FD89FE110
00007c9fd8bce884  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bce88c  jz 0x00007C9FD8BCE8C0
00007c9fd8bce892  nop [rax+rax*1], ax
00007c9fd8bce89b  nop [rax+rax*1], eax
00007c9fd8bce8a3  mov eax, 0x41017C
00007c9fd8bce8a8  mov [r15+0x100], rax
00007c9fd8bce8af  jmp 0x00007C9FD89FE110
00007c9fd8bce8b4  int3
00007c9fd8bce8b5  call 0x00007C9FD8AB4B70
00007c9fd8bce8ba  jmp 0x00007C9FD8BCE823
00007c9fd8bce8bf  int3
00007c9fd8bce8c0  mov eax, [r15+0xA0]
00007c9fd8bce8c7  lea r14d, [eax+0x11]
00007c9fd8bce8cc  mov r14d, r14d
00007c9fd8bce8cf  mov [r15], r14
00007c9fd8bce8d2  mov qword ptr [r15+0xF0], 0x410184
00007c9fd8bce8dd  mov r14d, [r15+0x320]
00007c9fd8bce8e4  mov eax, 0x410184
00007c9fd8bce8e9  mov rcx, 0x7C9FD8BCE800
00007c9fd8bce8f3  mov [r15+r14*8+0x328], rax
00007c9fd8bce8fb  mov [r15+r14*8+0x368], rcx
00007c9fd8bce903  add r14d, 0x01
00007c9fd8bce907  and r14d, 0x07
00007c9fd8bce90b  mov [r15+0x320], r14d
00007c9fd8bce912  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bce91a  jz 0x00007C9FD8BCE7A0
00007c9fd8bce920  nop [rax+rax*1], ax
00007c9fd8bce929  nop [rax+rax*1], eax
00007c9fd8bce931  mov eax, 0x41021C
00007c9fd8bce936  mov [r15+0x100], rax
00007c9fd8bce93d  jmp 0x00007C9FD89FE110
00007c9fd8bce942  int3
00007c9fd8bce943  int3
00007c9fd8bce944  nop [rax+rax*1], ax
00007c9fd8bce94d  nop [rax], eax
00007c9fd8bce950  mov qword ptr [r15+0x40], 0x01
00007c9fd8bce958  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bce960  jz 0x00007C9FD8BCE990
00007c9fd8bce966  nop [rax+rax*1], ax
00007c9fd8bce96f  nop [rax+rax*1], eax
00007c9fd8bce977  mov eax, 0x4101B0
00007c9fd8bce97c  mov [r15+0x100], rax
00007c9fd8bce983  jmp 0x00007C9FD89FE110
00007c9fd8bce988  int3
00007c9fd8bce989  int3
00007c9fd8bce98a  nop [rax+rax*1], ax
00007c9fd8bce990  mov rax, [r15+0x40]
00007c9fd8bce994  mov [rsp+0x10], rax
00007c9fd8bce999  shl rax, 0x02
00007c9fd8bce99d  mov r14, [r15+0x98]
00007c9fd8bce9a4  lea r12, [r14+rax*1]
00007c9fd8bce9a8  mov eax, [r13+r12*1]
00007c9fd8bce9ad  mov [rsp+0x20], eax
00007c9fd8bce9b1  mov eax, eax
00007c9fd8bce9b3  mov [r15+0x48], rax
00007c9fd8bce9b7  mov rax, [rsp+0x10]
00007c9fd8bce9bc  mov [r15+0x50], rax
00007c9fd8bce9c0  mov eax, [r15+0x50]
00007c9fd8bce9c4  lea r12d, [eax-0x01]
00007c9fd8bce9c9  mov r12d, r12d
00007c9fd8bce9cc  mov [r15+0x58], r12
00007c9fd8bce9d0  mov rax, [r15+0x58]
00007c9fd8bce9d4  mov r12d, eax
00007c9fd8bce9d7  mov r12d, r12d
00007c9fd8bce9da  shl r12, 0x02
00007c9fd8bce9de  lea rax, [r14+r12*1]
00007c9fd8bce9e2  mov r14d, [r13+rax*1]
00007c9fd8bce9e7  mov [rsp+0x10], r14d
00007c9fd8bce9ec  mov r14d, r14d
00007c9fd8bce9ef  mov [r15+0x60], r14
00007c9fd8bce9f3  xor eax, eax
00007c9fd8bce9f5  mov r14d, [rsp+0x10]
00007c9fd8bce9fa  mov r12d, [rsp+0x20]
00007c9fd8bce9ff  cmp r14d, r12d
00007c9fd8bcea02  cmc
00007c9fd8bcea03  lahf
00007c9fd8bcea04  seto al
00007c9fd8bcea07  mov [r15+0x108], eax
00007c9fd8bcea0e  mov eax, [r15+0x108]
00007c9fd8bcea15  sahf
00007c9fd8bcea16  cmc
00007c9fd8bcea17  jbe 0x00007C9FD8BCEA49
00007c9fd8bcea19  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcea21  jz 0x00007C9FD8BCEA90
00007c9fd8bcea27  nop [rax+rax*1], ax
00007c9fd8bcea30  nop [rax+rax*1], eax
00007c9fd8bcea38  mov eax, 0x4101C8
00007c9fd8bcea3d  mov [r15+0x100], rax
00007c9fd8bcea44  jmp 0x00007C9FD89FE110
00007c9fd8bcea49  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcea51  jz 0x00007C9FD8BCED30
00007c9fd8bcea57  nop [rax+rax*1], ax
00007c9fd8bcea60  nop [rax+rax*1], eax
00007c9fd8bcea68  mov eax, 0x4101A0
00007c9fd8bcea6d  mov [r15+0x100], rax
00007c9fd8bcea74  jmp 0x00007C9FD89FE110
00007c9fd8bcea79  int3
00007c9fd8bcea7a  call 0x00007C9FD8AB4690
00007c9fd8bcea7f  jmp 0x00007C9FD8BCE9AD
00007c9fd8bcea84  call 0x00007C9FD8A0DAE0
00007c9fd8bcea89  jmp 0x00007C9FD8BCE9E7
00007c9fd8bcea8e  int3
00007c9fd8bcea8f  nop
00007c9fd8bcea90  mov rax, [r15+0x50]
00007c9fd8bcea94  mov [rsp+0x10], rax
00007c9fd8bcea99  shl rax, 0x02
00007c9fd8bcea9d  mov r14, [r15+0x98]
00007c9fd8bceaa4  lea r12, [r14+rax*1]
00007c9fd8bceaa8  mov eax, [r15+0x60]
00007c9fd8bceaac  mov [r13+r12*1], eax
00007c9fd8bceab1  mov rax, [rsp+0x10]
00007c9fd8bceab6  lea r14, [rax-0x01]
00007c9fd8bceaba  mov [r15+0x50], r14
00007c9fd8bceabe  mov rax, [r15+0x58]
00007c9fd8bceac2  test rax, rax
00007c9fd8bceac5  setz al
00007c9fd8bceac8  movzx rax, al
00007c9fd8bceacc  mov [rsp+0x414], al
00007c9fd8bcead3  cmp byte ptr [rsp+0x414], 0x00
00007c9fd8bceadb  jz 0x00007C9FD8BCEB0D
00007c9fd8bceadd  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bceae5  jz 0x00007C9FD8BCEB50
00007c9fd8bceaeb  nop [rax+rax*1], ax
00007c9fd8bceaf4  nop [rax+rax*1], eax
00007c9fd8bceafc  mov eax, 0x4101D4
00007c9fd8bceb01  mov [r15+0x100], rax
00007c9fd8bceb08  jmp 0x00007C9FD89FE110
00007c9fd8bceb0d  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bceb15  jz 0x00007C9FD8BCEC50
00007c9fd8bceb1b  nop [rax+rax*1], ax
00007c9fd8bceb24  nop [rax+rax*1], eax
00007c9fd8bceb2c  mov eax, 0x4101B8
00007c9fd8bceb31  mov [r15+0x100], rax
00007c9fd8bceb38  jmp 0x00007C9FD89FE110
00007c9fd8bceb3d  int3
00007c9fd8bceb3e  call 0x00007C9FD8AB4B70
00007c9fd8bceb43  jmp 0x00007C9FD8BCEAB1
00007c9fd8bceb48  int3
00007c9fd8bceb49  nop [rax], eax
00007c9fd8bceb50  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bceb58  jz 0x00007C9FD8BCEB90
00007c9fd8bceb5e  nop [rax+rax*1], ax
00007c9fd8bceb67  nop [rax+rax*1], eax
00007c9fd8bceb6f  mov eax, 0x41019C
00007c9fd8bceb74  mov [r15+0x100], rax
00007c9fd8bceb7b  jmp 0x00007C9FD89FE110
00007c9fd8bceb80  int3
00007c9fd8bceb81  int3
00007c9fd8bceb82  nop [rax+rax*1], ax
00007c9fd8bceb8b  nop [rax+rax*1], eax
00007c9fd8bceb90  mov qword ptr [r15+0x50], 0x00
00007c9fd8bceb98  mov rax, [r15+0x40]
00007c9fd8bceb9c  lea r14, [rax+0x01]
00007c9fd8bceba0  mov [r15+0x40], r14
00007c9fd8bceba4  mov rax, [r15+0x98]
00007c9fd8bcebab  mov r12d, [r15+0x48]
00007c9fd8bcebaf  mov [r13+rax*1], r12d
00007c9fd8bcebb4  xor eax, eax
00007c9fd8bcebb6  mov r12d, 0x400
00007c9fd8bcebbc  cmp r14, r12
00007c9fd8bcebbf  cmc
00007c9fd8bcebc0  lahf
00007c9fd8bcebc1  seto al
00007c9fd8bcebc4  mov [r15+0x108], eax
00007c9fd8bcebcb  mov eax, [r15+0x108]
00007c9fd8bcebd2  sahf
00007c9fd8bcebd3  jz 0x00007C9FD8BCEC05
00007c9fd8bcebd5  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcebdd  jz 0x00007C9FD8BCE990
00007c9fd8bcebe3  nop [rax+rax*1], ax
00007c9fd8bcebec  nop [rax+rax*1], eax
00007c9fd8bcebf4  mov eax, 0x4101B0
00007c9fd8bcebf9  mov [r15+0x100], rax
00007c9fd8bcec00  jmp 0x00007C9FD89FE110
00007c9fd8bcec05  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcec0d  jz 0x00007C9FD8BCEDF0
00007c9fd8bcec13  nop [rax+rax*1], ax
00007c9fd8bcec1c  nop [rax+rax*1], eax
00007c9fd8bcec24  mov eax, 0x4101D8
00007c9fd8bcec29  mov [r15+0x100], rax
00007c9fd8bcec30  jmp 0x00007C9FD89FE110
00007c9fd8bcec35  int3
00007c9fd8bcec36  call 0x00007C9FD8A0BAE0
00007c9fd8bcec3b  jmp 0x00007C9FD8BCEBB4
00007c9fd8bcec40  int3
00007c9fd8bcec41  nop [rax+rax*1], ax
00007c9fd8bcec4a  nop [rax+rax*1], ax
00007c9fd8bcec50  mov eax, [r15+0x50]
00007c9fd8bcec54  lea r14d, [eax-0x01]
00007c9fd8bcec59  mov r14d, r14d
00007c9fd8bcec5c  mov [r15+0x58], r14
00007c9fd8bcec60  mov rax, [r15+0x58]
00007c9fd8bcec64  mov r14d, eax
00007c9fd8bcec67  mov r14d, r14d
00007c9fd8bcec6a  shl r14, 0x02
00007c9fd8bcec6e  mov rax, [r15+0x98]
00007c9fd8bcec75  lea r12, [rax+r14*1]
00007c9fd8bcec79  mov eax, [r13+r12*1]
00007c9fd8bcec7e  mov [rsp+0x10], eax
00007c9fd8bcec82  mov eax, eax
00007c9fd8bcec84  mov [r15+0x60], rax
00007c9fd8bcec88  mov eax, [r15+0x48]
00007c9fd8bcec8c  mov [rsp+0x20], eax
00007c9fd8bcec90  xor eax, eax
00007c9fd8bcec92  mov r14d, [rsp+0x10]
00007c9fd8bcec97  mov r12d, [rsp+0x20]
00007c9fd8bcec9c  cmp r14d, r12d
00007c9fd8bcec9f  cmc
00007c9fd8bceca0  lahf
00007c9fd8bceca1  seto al
00007c9fd8bceca4  mov [r15+0x108], eax
00007c9fd8bcecab  mov eax, [r15+0x108]
00007c9fd8bcecb2  sahf
00007c9fd8bcecb3  cmc
00007c9fd8bcecb4  jbe 0x00007C9FD8BCECE6
00007c9fd8bcecb6  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcecbe  jz 0x00007C9FD8BCEA90
00007c9fd8bcecc4  nop [rax+rax*1], ax
00007c9fd8bceccd  nop [rax+rax*1], eax
00007c9fd8bcecd5  mov eax, 0x4101C8
00007c9fd8bcecda  mov [r15+0x100], rax
00007c9fd8bcece1  jmp 0x00007C9FD89FE110
00007c9fd8bcece6  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcecee  jz 0x00007C9FD8BCED30
00007c9fd8bcecf4  nop [rax+rax*1], ax
00007c9fd8bcecfd  nop [rax+rax*1], eax
00007c9fd8bced05  mov eax, 0x4101A0
00007c9fd8bced0a  mov [r15+0x100], rax
00007c9fd8bced11  jmp 0x00007C9FD89FE110
00007c9fd8bced16  int3
00007c9fd8bced17  call 0x00007C9FD8AB4690
00007c9fd8bced1c  jmp 0x00007C9FD8BCEC7E
00007c9fd8bced21  int3
00007c9fd8bced22  nop [rax+rax*1], ax
00007c9fd8bced2b  nop [rax+rax*1], eax
00007c9fd8bced30  mov rax, [r15+0x40]
00007c9fd8bced34  lea r14, [rax+0x01]
00007c9fd8bced38  mov [r15+0x40], r14
00007c9fd8bced3c  mov rax, [r15+0x50]
00007c9fd8bced40  mov r12d, eax
00007c9fd8bced43  mov r12d, r12d
00007c9fd8bced46  shl r12, 0x02
00007c9fd8bced4a  mov rax, [r15+0x98]
00007c9fd8bced51  lea r11, [rax+r12*1]
00007c9fd8bced55  mov eax, [r15+0x48]
00007c9fd8bced59  mov [r13+r11*1], eax
00007c9fd8bced5e  xor eax, eax
00007c9fd8bced60  mov r12d, 0x400
00007c9fd8bced66  cmp r14, r12
00007c9fd8bced69  cmc
00007c9fd8bced6a  lahf
00007c9fd8bced6b  seto al
00007c9fd8bced6e  mov [r15+0x108], eax
00007c9fd8bced75  mov eax, [r15+0x108]
00007c9fd8bced7c  sahf
00007c9fd8bced7d  jz 0x00007C9FD8BCEDAF
00007c9fd8bced7f  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bced87  jz 0x00007C9FD8BCE990
00007c9fd8bced8d  nop [rax+rax*1], ax
00007c9fd8bced96  nop [rax+rax*1], eax
00007c9fd8bced9e  mov eax, 0x4101B0
00007c9fd8bceda3  mov [r15+0x100], rax
00007c9fd8bcedaa  jmp 0x00007C9FD89FE110
00007c9fd8bcedaf  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcedb7  jz 0x00007C9FD8BCEDF0
00007c9fd8bcedbd  nop [rax+rax*1], ax
00007c9fd8bcedc6  nop [rax+rax*1], eax
00007c9fd8bcedce  mov eax, 0x4101D8
00007c9fd8bcedd3  mov [r15+0x100], rax
00007c9fd8bcedda  jmp 0x00007C9FD89FE110
00007c9fd8bceddf  int3
00007c9fd8bcede0  call 0x00007C9FD8AA4270
00007c9fd8bcede5  jmp 0x00007C9FD8BCED5E
00007c9fd8bcedea  int3
00007c9fd8bcedeb  nop [rax+rax*1], eax
00007c9fd8bcedf0  mov qword ptr [r15+0x40], 0x420000
00007c9fd8bcedf8  mov eax, 0x420288
00007c9fd8bcedfd  mov r14, [r13+rax*1]
00007c9fd8bcee02  mov rax, [r15+0x98]
00007c9fd8bcee09  mov r12d, [r13+rax*1]
00007c9fd8bcee0e  lea r11, [rax+0x04]
00007c9fd8bcee12  mov eax, [r13+r11*1]
00007c9fd8bcee17  mov r12d, r12d
00007c9fd8bcee1a  mov [r15+0x68], r12
00007c9fd8bcee1e  mov eax, eax
00007c9fd8bcee20  mov [r15+0x60], rax
00007c9fd8bcee24  mov rax, [r15+0x68]
00007c9fd8bcee28  mov [r15+0x68], rax
00007c9fd8bcee2c  mov qword ptr [r15+0x58], 0x02
00007c9fd8bcee34  mov [rsp+0x10], rax
00007c9fd8bcee39  xor eax, eax
00007c9fd8bcee3b  mov r12d, 0x02
00007c9fd8bcee41  mov r11d, 0x400
00007c9fd8bcee47  cmp r12, r11
00007c9fd8bcee4a  cmc
00007c9fd8bcee4b  lahf
00007c9fd8bcee4c  seto al
00007c9fd8bcee4f  mov [r15+0x108], eax
00007c9fd8bcee56  mov rax, [r15+0x60]
00007c9fd8bcee5a  mov r12d, 0x02
00007c9fd8bcee60  imul rax, r12
00007c9fd8bcee64  mov [r15+0x50], rax
00007c9fd8bcee68  mov rax, [rsp+0x10]
00007c9fd8bcee6d  lea r12, [rax+r14*1]
00007c9fd8bcee71  mov [r15+0x48], r12
00007c9fd8bcee75  mov eax, [r15+0x108]
00007c9fd8bcee7c  sahf
00007c9fd8bcee7d  jnz 0x00007C9FD8BCEEAF
00007c9fd8bcee7f  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcee87  jz 0x00007C9FD8BCF020
00007c9fd8bcee8d  nop [rax+rax*1], ax
00007c9fd8bcee96  nop [rax+rax*1], eax
00007c9fd8bcee9e  mov eax, 0x410208
00007c9fd8bceea3  mov [r15+0x100], rax
00007c9fd8bceeaa  jmp 0x00007C9FD89FE110
00007c9fd8bceeaf  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bceeb7  jz 0x00007C9FD8BCEF00
00007c9fd8bceebd  nop [rax+rax*1], ax
00007c9fd8bceec6  nop [rax+rax*1], eax
00007c9fd8bceece  mov eax, 0x4101E8
00007c9fd8bceed3  mov [r15+0x100], rax
00007c9fd8bceeda  jmp 0x00007C9FD89FE110
00007c9fd8bceedf  int3
00007c9fd8bceee0  call 0x00007C9FD8A0DC20
00007c9fd8bceee5  jmp 0x00007C9FD8BCEE02
00007c9fd8bceeea  call 0x00007C9FD8A0B5E0
00007c9fd8bceeef  jmp 0x00007C9FD8BCEE0E
00007c9fd8bceef4  call 0x00007C9FD8AA3D90
00007c9fd8bceef9  jmp 0x00007C9FD8BCEE17
00007c9fd8bceefe  int3
00007c9fd8bceeff  nop
00007c9fd8bcef00  mov rax, [r15+0x98]
00007c9fd8bcef07  mov r14, [r15+0x58]
00007c9fd8bcef0b  mov [rsp+0x10], r14
00007c9fd8bcef10  shl r14, 0x02
00007c9fd8bcef14  lea r12, [rax+r14*1]
00007c9fd8bcef18  mov eax, [r13+r12*1]
00007c9fd8bcef1d  lea r14, [r12+0x04]
00007c9fd8bcef22  mov r12d, [r13+r14*1]
00007c9fd8bcef27  mov eax, eax
00007c9fd8bcef29  mov [r15+0x68], rax
00007c9fd8bcef2d  mov r12d, r12d
00007c9fd8bcef30  mov [r15+0x60], r12
00007c9fd8bcef34  mov rax, [r15+0x68]
00007c9fd8bcef38  mov [rsp+0x20], rax
00007c9fd8bcef3d  mov r14, [rsp+0x10]
00007c9fd8bcef42  imul rax, r14
00007c9fd8bcef46  mov r12, [rsp+0x20]
00007c9fd8bcef4b  lea r11, [r12+rax*1]
00007c9fd8bcef4f  mov [r15+0x68], r11
00007c9fd8bcef53  lea rax, [r14+0x02]
00007c9fd8bcef57  mov [r15+0x58], rax
00007c9fd8bcef5b  mov [rsp+0x10], rax
00007c9fd8bcef60  xor eax, eax
00007c9fd8bcef62  mov r14, [rsp+0x10]
00007c9fd8bcef67  mov r12d, 0x400
00007c9fd8bcef6d  cmp r14, r12
00007c9fd8bcef70  cmc
00007c9fd8bcef71  lahf
00007c9fd8bcef72  seto al
00007c9fd8bcef75  mov [r15+0x108], eax
00007c9fd8bcef7c  mov rax, [r15+0x50]
00007c9fd8bcef80  mov r12, [r15+0x60]
00007c9fd8bcef84  imul r14, r12
00007c9fd8bcef88  lea r12, [rax+r14*1]
00007c9fd8bcef8c  mov [r15+0x50], r12
00007c9fd8bcef90  mov rax, [r15+0x48]
00007c9fd8bcef94  lea r14, [r11+rax*1]
00007c9fd8bcef98  mov [r15+0x48], r14
00007c9fd8bcef9c  mov eax, [r15+0x108]
00007c9fd8bcefa3  sahf
00007c9fd8bcefa4  jnz 0x00007C9FD8BCEFD6
00007c9fd8bcefa6  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcefae  jz 0x00007C9FD8BCF020
00007c9fd8bcefb4  nop [rax+rax*1], ax
00007c9fd8bcefbd  nop [rax+rax*1], eax
00007c9fd8bcefc5  mov eax, 0x410208
00007c9fd8bcefca  mov [r15+0x100], rax
00007c9fd8bcefd1  jmp 0x00007C9FD89FE110
00007c9fd8bcefd6  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcefde  jz 0x00007C9FD8BCEF00
00007c9fd8bcefe4  nop [rax+rax*1], ax
00007c9fd8bcefed  nop [rax+rax*1], eax
00007c9fd8bceff5  mov eax, 0x4101E8
00007c9fd8bceffa  mov [r15+0x100], rax
00007c9fd8bcf001  jmp 0x00007C9FD89FE110
00007c9fd8bcf006  int3
00007c9fd8bcf007  call 0x00007C9FD8AB4690
00007c9fd8bcf00c  jmp 0x00007C9FD8BCEF1D
00007c9fd8bcf011  call 0x00007C9FD8AE26A0
00007c9fd8bcf016  jmp 0x00007C9FD8BCEF27
00007c9fd8bcf01b  int3
00007c9fd8bcf01c  nop [rax], eax
00007c9fd8bcf020  mov rax, [r15+0xF8]
00007c9fd8bcf027  lea r14, [rax+0x10]
00007c9fd8bcf02b  mov r12, [r13+r14*1]
00007c9fd8bcf030  lea r14, [rax+0x18]
00007c9fd8bcf034  mov r11, [r13+r14*1]
00007c9fd8bcf039  mov [r15+0xA0], r12
00007c9fd8bcf040  mov [r15+0x98], r11
00007c9fd8bcf047  mov r14, [r15+0x50]
00007c9fd8bcf04b  mov r12, [r15+0x48]
00007c9fd8bcf04f  lea r11, [r14+r12*1]
00007c9fd8bcf053  mov [r15+0x48], r11
00007c9fd8bcf057  mov r14, [r15+0x40]
00007c9fd8bcf05b  lea r12, [r14+0x288]
00007c9fd8bcf062  mov [r13+r12*1], r11
00007c9fd8bcf067  mov r14, [r13+rax*1]
00007c9fd8bcf06c  mov [r15+0xF0], r14
00007c9fd8bcf073  lea r12, [rax+0x20]
00007c9fd8bcf077  mov [r15+0xF8], r12
00007c9fd8bcf07e  mov [r15+0x100], r14
00007c9fd8bcf085  jmp 0x00007C9FD8BCE5C0
00007c9fd8bcf08a  int3
00007c9fd8bcf08b  call 0x00007C9FD8AE27E0
00007c9fd8bcf090  jmp 0x00007C9FD8BCF030
00007c9fd8bcf095  call 0x00007C9FD8AE1570
00007c9fd8bcf09a  jmp 0x00007C9FD8BCF039
00007c9fd8bcf09f  call 0x00007C9FD8AC0860
00007c9fd8bcf0a4  jmp 0x00007C9FD8BCF067
00007c9fd8bcf0a9  call 0x00007C9FD8A0DC20
00007c9fd8bcf0ae  jmp 0x00007C9FD8BCF06C
00007c9fd8bcf0b3  int3
00007c9fd8bcf0b4  nop [rax+rax*1], ax
00007c9fd8bcf0bd  nop [rax], eax
00007c9fd8bcf0c0  mov qword ptr [r15+0x100], 0x04
00007c9fd8bcf0cb  mov esi, 0x00
00007c9fd8bcf0d0  mov edx, 0x09
00007c9fd8bcf0d5  mov rdi, 0x7FFCFA624900
00007c9fd8bcf0df  mov rax, 0x59D747472970
00007c9fd8bcf0e9  call rax
00007c9fd8bcf0eb  cmp dword ptr [r15+0x318], 0x00
00007c9fd8bcf0f3  jnz 0x00007C9FD89FE110
00007c9fd8bcf0f9  jmp 0x00007C9FD89FE0A0
00007c9fd8bcf0fe  int3
00007c9fd8bcf0ff  int3
