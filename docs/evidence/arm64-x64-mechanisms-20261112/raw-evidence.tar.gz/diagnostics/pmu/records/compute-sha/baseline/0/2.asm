
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sha/baseline/0/2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13d,DWORD PTR [r12+0xa0]
   8:	mov    r14d,r13d
   b:	sub    r14d,0x1
   f:	pushf
  10:	pop    rdx
  11:	mov    r10d,edx
  14:	and    r10d,0xc0
  1b:	shl    r10d,0x18
  1f:	mov    r11d,edx
  22:	and    r11d,0x1
  26:	shl    r11d,0x1d
  2a:	or     r10d,r11d
  2d:	mov    r11d,edx
  30:	and    r11d,0x800
  37:	shl    r11d,0x11
  3b:	or     r10d,r11d
  3e:	mov    r11d,0xf0000000
  44:	and    r11,r10
  47:	movabs rsi,0xffffffff0fffffff
  51:	and    rbx,rsi
  54:	or     rbx,r11
  57:	btc    rbx,0x1d
  5c:	mov    QWORD PTR [r12+0xa0],r14
  64:	cmp    QWORD PTR [r12+0x380],0x0
  6d:	je     0x9a
  73:	mov    eax,0x410278
  78:	mov    QWORD PTR [r12+0x100],rax
  80:	mov    QWORD PTR [r12+0x108],rbx
  88:	mov    eax,0xc
  8d:	movabs r11,0x56b97c5905f0
  97:	jmp    r11
  9a:	test   ebx,0x40000000
  a0:	je     0x16d
  a6:	jmp    0xab
  ab:	mov    r13,QWORD PTR [r12+0xf8]
  b3:	mov    r14,r13
  b6:	add    r14,0x20
  ba:	mov    r15,QWORD PTR [r14]
  bd:	mov    QWORD PTR [r12+0x98],r15
  c5:	mov    r14d,0x80
  cb:	mov    QWORD PTR [r12+0x40],r14
  d0:	mov    r14,r13
  d3:	add    r14,0x0
  d7:	mov    QWORD PTR [r12],r14
  db:	mov    r14,r13
  de:	add    r14,0x8c
  e5:	mov    QWORD PTR [r12+0x8],r14
  ea:	mov    r14d,0x1
  f0:	mov    QWORD PTR [r12+0x10],r14
  f5:	mov    r14,r13
  f8:	add    r14,0x8c
  ff:	movzx  r13d,BYTE PTR [r12+0x40]
 105:	mov    BYTE PTR [r14],r13b
 108:	mov    r13d,0x0
 10e:	mov    DWORD PTR [r12+0x32c],r13d
 116:	mov    r13d,0x410298
 11c:	mov    QWORD PTR [r12+0xf0],r13
 124:	mov    r13d,0x410338
 12a:	mov    QWORD PTR [r12+0x100],r13
 132:	mov    QWORD PTR [r12+0x108],rbx
 13a:	mov    edi,0x410338
 13f:	mov    QWORD PTR [r12+0x100],rdi
 147:	nop
 148:	jmp    QWORD PTR [rip+0x2]        # 0x150
 14e:	xchg   ax,ax
 150:	add    al,ch
 152:	rex.WRXB ret
 154:	add    al,0x79
 156:	add    BYTE PTR [rax],al
 158:	jo     0x176
 15a:	push   rax
 15b:	ret
 15c:	add    al,0x79
 15e:	add    BYTE PTR [rax],al
 160:	movabs r11,0x56b97c590370
 16a:	jmp    r11
 16d:	mov    r13,QWORD PTR [r12+0xf8]
 175:	mov    r14,r13
 178:	add    r14,0x0
 17c:	mov    QWORD PTR [r12],r14
 180:	mov    r13d,0x0
 186:	mov    r14,QWORD PTR [r12+0x98]
 18e:	mov    rcx,r14
 191:	mov    r15,r13
 194:	or     r15,rcx
 197:	mov    QWORD PTR [r12+0x8],r15
 19c:	mov    r13d,0x12c
 1a2:	mov    QWORD PTR [r12+0x10],r13
 1a7:	mov    r13d,0x410274
 1ad:	mov    QWORD PTR [r12+0xf0],r13
 1b5:	mov    r13d,0x410338
 1bb:	mov    QWORD PTR [r12+0x100],r13
 1c3:	mov    QWORD PTR [r12+0x108],rbx
 1cb:	mov    edi,0x410338
 1d0:	mov    QWORD PTR [r12+0x100],rdi
 1d8:	jmp    QWORD PTR [rip+0x2]        # 0x1e0
 1de:	xchg   ax,ax
 1e0:	add    al,ch
 1e2:	rex.WRXB ret
 1e4:	add    al,0x79
 1e6:	add    BYTE PTR [rax],al
 1e8:	add    BYTE PTR [rip+0x7904c350],bl        # 0x7904c53e
 1ee:	add    BYTE PTR [rax],al
 1f0:	movabs r11,0x56b97c590370
 1fa:	jmp    r11
 1fd:	nop    DWORD PTR [rax]
 200:	jmp    0xab
 205:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 210:	jmp    0x16d
 215:	nop
 216:	nop
 217:	nop
