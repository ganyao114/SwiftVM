00007df8f93ce69b  nop [rax+rax*1], eax
00007df8f93ce6a0  mov rax, [r15+0xF8]
00007df8f93ce6a7  lea r14, [rax-0xA0]
00007df8f93ce6ae  mov [r15+0xF8], r14
00007df8f93ce6b5  lea rax, [r14+0x90]
00007df8f93ce6bc  mov r12, [r15+0xA0]
00007df8f93ce6c3  mov r11, [r15+0x98]
00007df8f93ce6ca  mov [r13+rax*1], r12
00007df8f93ce6cf  lea rax, [r14+0x98]
00007df8f93ce6d6  mov [r13+rax*1], r11
00007df8f93ce6db  mov eax, 0x420670
00007df8f93ce6e0  movups xmm1, [r13+rax*1]
00007df8f93ce6e6  mov eax, 0x420610
00007df8f93ce6eb  movups xmm15, [r13+rax*1]
00007df8f93ce6f1  mov eax, 0x420690
00007df8f93ce6f6  movups xmm14, [r13+rax*1]
00007df8f93ce6fc  mov eax, 0x420630
00007df8f93ce701  movups xmm13, [r13+rax*1]
00007df8f93ce707  mov qword ptr [r15+0x98], 0x4308A0
00007df8f93ce712  mov eax, 0x4206A0
00007df8f93ce717  movups xmm12, [r13+rax*1]
00007df8f93ce71d  mov eax, 0x4308A0
00007df8f93ce722  movups [r13+rax*1], xmm1
00007df8f93ce728  mov eax, 0x4308B0
00007df8f93ce72d  movups [r13+rax*1], xmm15
00007df8f93ce733  mov eax, 0x4308C0
00007df8f93ce738  movups [r13+rax*1], xmm14
00007df8f93ce73e  mov eax, 0x4308D0
00007df8f93ce743  movups [r13+rax*1], xmm13
00007df8f93ce749  mov eax, 0x420600
00007df8f93ce74e  movups xmm14, [r13+rax*1]
00007df8f93ce754  mov eax, 0x4205F0
00007df8f93ce759  movups xmm13, [r13+rax*1]
00007df8f93ce75f  mov eax, 0x4309A0
00007df8f93ce764  movups [r13+rax*1], xmm1
00007df8f93ce76a  mov eax, 0x4309B0
00007df8f93ce76f  movups [r13+rax*1], xmm15
00007df8f93ce775  mov eax, 0x4308E0
00007df8f93ce77a  movups [r13+rax*1], xmm12
00007df8f93ce780  mov eax, 0x4308F0
00007df8f93ce785  movups [r13+rax*1], xmm14
00007df8f93ce78b  mov eax, 0x4205E0
00007df8f93ce790  movups xmm1, [r13+rax*1]
00007df8f93ce796  mov eax, 0x420640
00007df8f93ce79b  movups xmm15, [r13+rax*1]
00007df8f93ce7a1  mov eax, 0x430900
00007df8f93ce7a6  movups [r13+rax*1], xmm13
00007df8f93ce7ac  mov eax, 0x430910
00007df8f93ce7b1  movups [r13+rax*1], xmm1
00007df8f93ce7b7  mov eax, 0x420650
00007df8f93ce7bc  movups xmm1, [r13+rax*1]
00007df8f93ce7c2  mov eax, 0x420620
00007df8f93ce7c7  movups xmm14, [r13+rax*1]
00007df8f93ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007df8f93ce7d5  mov eax, 0x430920
00007df8f93ce7da  movups [r13+rax*1], xmm15
00007df8f93ce7e0  mov eax, 0x430930
00007df8f93ce7e5  movups [r13+rax*1], xmm1
00007df8f93ce7eb  mov eax, 0x4206C0
00007df8f93ce7f0  movups xmm1, [r13+rax*1]
00007df8f93ce7f6  mov eax, 0x4206D0
00007df8f93ce7fb  movups xmm15, [r13+rax*1]
00007df8f93ce801  movaps [r15+0x150], xmm15
00007df8f93ce809  mov qword ptr [r15+0xA0], 0x3E8
00007df8f93ce814  mov eax, 0x430940
00007df8f93ce819  movups [r13+rax*1], xmm14
00007df8f93ce81f  mov eax, 0x430950
00007df8f93ce824  movups [r13+rax*1], xmm1
00007df8f93ce82a  mov eax, 0x4206B0
00007df8f93ce82f  movups xmm1, [r13+rax*1]
00007df8f93ce835  mov eax, 0x420660
00007df8f93ce83a  movups xmm14, [r13+rax*1]
00007df8f93ce840  movaps [r15+0x140], xmm14
00007df8f93ce848  lea rax, [r14+0x80]
00007df8f93ce84f  mov r12, [r15+0xF0]
00007df8f93ce856  mov [r13+rax*1], r12
00007df8f93ce85b  mov eax, 0x430960
00007df8f93ce860  movups [r13+rax*1], xmm15
00007df8f93ce866  mov eax, 0x430970
00007df8f93ce86b  movups [r13+rax*1], xmm1
00007df8f93ce871  mov eax, 0x420680
00007df8f93ce876  movups xmm1, [r13+rax*1]
00007df8f93ce87c  mov eax, 0x4206E0
00007df8f93ce881  mov r12, [r13+rax*1]
00007df8f93ce886  movq xmm15, r12
00007df8f93ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007df8f93ce893  mov eax, 0x430980
00007df8f93ce898  movups [r13+rax*1], xmm14
00007df8f93ce89e  mov eax, 0x430990
00007df8f93ce8a3  movups [r13+rax*1], xmm1
00007df8f93ce8a9  mov eax, 0x420748
00007df8f93ce8ae  movups xmm1, [r13+rax*1]
00007df8f93ce8b4  movq rax, xmm15
00007df8f93ce8b9  mov r12d, 0x4309C0
00007df8f93ce8bf  mov [r13+r12*1], rax
00007df8f93ce8c4  mov eax, 0x420728
00007df8f93ce8c9  movups xmm15, [r13+rax*1]
00007df8f93ce8cf  mov eax, 0x420738
00007df8f93ce8d4  movups xmm14, [r13+rax*1]
00007df8f93ce8da  lea rax, [r14+0x60]
00007df8f93ce8de  movups [r13+rax*1], xmm1
00007df8f93ce8e4  mov eax, 0x4309C8
00007df8f93ce8e9  mov r12d, 0x421DF8D3
00007df8f93ce8ef  mov [r13+rax*1], r12d
00007df8f93ce8f4  lea rax, [r14+0x40]
00007df8f93ce8f8  movups [r13+rax*1], xmm15
00007df8f93ce8fe  lea rax, [r14+0x50]
00007df8f93ce902  movups [r13+rax*1], xmm14
00007df8f93ce908  mov eax, 0x4206E8
00007df8f93ce90d  movups xmm1, [r13+rax*1]
00007df8f93ce913  mov eax, 0x4206F8
00007df8f93ce918  movups xmm15, [r13+rax*1]
00007df8f93ce91e  movaps [r15+0x120], xmm15
00007df8f93ce926  movups [r13+r14*1], xmm1
00007df8f93ce92c  lea rax, [r14+0x10]
00007df8f93ce930  movups [r13+rax*1], xmm15
00007df8f93ce936  mov eax, 0x420708
00007df8f93ce93b  movups xmm1, [r13+rax*1]
00007df8f93ce941  mov eax, 0x420718
00007df8f93ce946  movups xmm15, [r13+rax*1]
00007df8f93ce94c  movaps [r15+0x110], xmm1
00007df8f93ce954  movaps [r15+0x130], xmm15
00007df8f93ce95c  lea rax, [r14+0x20]
00007df8f93ce960  movups [r13+rax*1], xmm1
00007df8f93ce966  lea rax, [r14+0x30]
00007df8f93ce96a  movups [r13+rax*1], xmm15
00007df8f93ce970  mov [r15], r14
00007df8f93ce973  mov qword ptr [r15+0x08], 0x4308A0
00007df8f93ce97b  mov qword ptr [r15+0x10], 0x12C
00007df8f93ce983  mov qword ptr [r15+0xF0], 0x410274
00007df8f93ce98e  mov r14d, [r15+0x320]
00007df8f93ce995  mov eax, 0x410274
00007df8f93ce99a  mov rcx, 0x7DF8F93D0670
00007df8f93ce9a4  mov [r15+r14*8+0x328], rax
00007df8f93ce9ac  mov [r15+r14*8+0x368], rcx
00007df8f93ce9b4  add r14d, 0x01
00007df8f93ce9b8  and r14d, 0x07
00007df8f93ce9bc  mov [r15+0x320], r14d
00007df8f93ce9c3  cmp dword ptr [r15+0x318], 0x00
00007df8f93ce9cb  jz 0x00007DF8F93CEC20
00007df8f93ce9d1  nop [rax+rax*1], ax
00007df8f93ce9da  nop [rax+rax*1], eax
00007df8f93ce9e2  mov eax, 0x410338
00007df8f93ce9e7  mov [r15+0x100], rax
00007df8f93ce9ee  jmp 0x00007DF8F91FE110
00007df8f93ce9f3  int3
00007df8f93ce9f4  call 0x00007DF8F920BC20
00007df8f93ce9f9  jmp 0x00007DF8F93CE6CF
00007df8f93ce9fe  call 0x00007DF8F920A9A0
00007df8f93cea03  jmp 0x00007DF8F93CE6DB
00007df8f93cea08  call 0x00007DF8F91FF430
00007df8f93cea0d  jmp 0x00007DF8F93CE6E6
00007df8f93cea12  call 0x00007DF8F920E760
00007df8f93cea17  jmp 0x00007DF8F93CE6F1
00007df8f93cea1c  call 0x00007DF8F920D4E0
00007df8f93cea21  jmp 0x00007DF8F93CE6FC
00007df8f93cea26  call 0x00007DF8F920C260
00007df8f93cea2b  jmp 0x00007DF8F93CE707
00007df8f93cea30  call 0x00007DF8F920AFE0
00007df8f93cea35  jmp 0x00007DF8F93CE71D
00007df8f93cea3a  call 0x00007DF8F91FF540
00007df8f93cea3f  jmp 0x00007DF8F93CE728
00007df8f93cea44  call 0x00007DF8F920E880
00007df8f93cea49  jmp 0x00007DF8F93CE733
00007df8f93cea4e  call 0x00007DF8F920D600
00007df8f93cea53  jmp 0x00007DF8F93CE73E
00007df8f93cea58  call 0x00007DF8F920C380
00007df8f93cea5d  jmp 0x00007DF8F93CE749
00007df8f93cea62  call 0x00007DF8F920D4E0
00007df8f93cea67  jmp 0x00007DF8F93CE754
00007df8f93cea6c  call 0x00007DF8F920C260
00007df8f93cea71  jmp 0x00007DF8F93CE75F
00007df8f93cea76  call 0x00007DF8F91FF540
00007df8f93cea7b  jmp 0x00007DF8F93CE76A
00007df8f93cea80  call 0x00007DF8F920E880
00007df8f93cea85  jmp 0x00007DF8F93CE775
00007df8f93cea8a  call 0x00007DF8F920B100
00007df8f93cea8f  jmp 0x00007DF8F93CE780
00007df8f93cea94  call 0x00007DF8F920D600
00007df8f93cea99  jmp 0x00007DF8F93CE78B
00007df8f93cea9e  call 0x00007DF8F91FF430
00007df8f93ceaa3  jmp 0x00007DF8F93CE796
00007df8f93ceaa8  call 0x00007DF8F920E760
00007df8f93ceaad  jmp 0x00007DF8F93CE7A1
00007df8f93ceab2  call 0x00007DF8F920C380
00007df8f93ceab7  jmp 0x00007DF8F93CE7AC
00007df8f93ceabc  call 0x00007DF8F91FF540
00007df8f93ceac1  jmp 0x00007DF8F93CE7B7
00007df8f93ceac6  call 0x00007DF8F91FF430
00007df8f93ceacb  jmp 0x00007DF8F93CE7C2
00007df8f93cead0  call 0x00007DF8F920D4E0
00007df8f93cead5  jmp 0x00007DF8F93CE7CD
00007df8f93ceada  call 0x00007DF8F920E880
00007df8f93ceadf  jmp 0x00007DF8F93CE7E0
00007df8f93ceae4  call 0x00007DF8F91FF540
00007df8f93ceae9  jmp 0x00007DF8F93CE7EB
00007df8f93ceaee  call 0x00007DF8F91FF430
00007df8f93ceaf3  jmp 0x00007DF8F93CE7F6
00007df8f93ceaf8  call 0x00007DF8F920E760
00007df8f93ceafd  jmp 0x00007DF8F93CE801
00007df8f93ceb02  call 0x00007DF8F920D600
00007df8f93ceb07  jmp 0x00007DF8F93CE81F
00007df8f93ceb0c  call 0x00007DF8F91FF540
00007df8f93ceb11  jmp 0x00007DF8F93CE82A
00007df8f93ceb16  call 0x00007DF8F91FF430
00007df8f93ceb1b  jmp 0x00007DF8F93CE835
00007df8f93ceb20  call 0x00007DF8F920D4E0
00007df8f93ceb25  jmp 0x00007DF8F93CE840
00007df8f93ceb2a  call 0x00007DF8F920BC20
00007df8f93ceb2f  jmp 0x00007DF8F93CE85B
00007df8f93ceb34  call 0x00007DF8F920E880
00007df8f93ceb39  jmp 0x00007DF8F93CE866
00007df8f93ceb3e  call 0x00007DF8F91FF540
00007df8f93ceb43  jmp 0x00007DF8F93CE871
00007df8f93ceb48  call 0x00007DF8F91FF430
00007df8f93ceb4d  jmp 0x00007DF8F93CE87C
00007df8f93ceb52  call 0x00007DF8F920B720
00007df8f93ceb57  jmp 0x00007DF8F93CE886
00007df8f93ceb5c  call 0x00007DF8F920D600
00007df8f93ceb61  jmp 0x00007DF8F93CE89E
00007df8f93ceb66  call 0x00007DF8F91FF540
00007df8f93ceb6b  jmp 0x00007DF8F93CE8A9
00007df8f93ceb70  call 0x00007DF8F91FF430
00007df8f93ceb75  jmp 0x00007DF8F93CE8B4
00007df8f93ceb7a  call 0x00007DF8F92B4CB0
00007df8f93ceb7f  jmp 0x00007DF8F93CE8C4
00007df8f93ceb84  call 0x00007DF8F920E760
00007df8f93ceb89  jmp 0x00007DF8F93CE8CF
00007df8f93ceb8e  call 0x00007DF8F920D4E0
00007df8f93ceb93  jmp 0x00007DF8F93CE8DA
00007df8f93ceb98  call 0x00007DF8F91FF540
00007df8f93ceb9d  jmp 0x00007DF8F93CE8E4
00007df8f93ceba2  call 0x00007DF8F920BAE0
00007df8f93ceba7  jmp 0x00007DF8F93CE8F4
00007df8f93cebac  call 0x00007DF8F920E880
00007df8f93cebb1  jmp 0x00007DF8F93CE8FE
00007df8f93cebb6  call 0x00007DF8F920D600
00007df8f93cebbb  jmp 0x00007DF8F93CE908
00007df8f93cebc0  call 0x00007DF8F91FF430
00007df8f93cebc5  jmp 0x00007DF8F93CE913
00007df8f93cebca  call 0x00007DF8F920E760
00007df8f93cebcf  jmp 0x00007DF8F93CE91E
00007df8f93cebd4  call 0x00007DF8F92D6600
00007df8f93cebd9  jmp 0x00007DF8F93CE92C
00007df8f93cebde  call 0x00007DF8F920E880
00007df8f93cebe3  jmp 0x00007DF8F93CE936
00007df8f93cebe8  call 0x00007DF8F91FF430
00007df8f93cebed  jmp 0x00007DF8F93CE941
00007df8f93cebf2  call 0x00007DF8F920E760
00007df8f93cebf7  jmp 0x00007DF8F93CE94C
00007df8f93cebfc  call 0x00007DF8F91FF540
00007df8f93cec01  jmp 0x00007DF8F93CE966
00007df8f93cec06  call 0x00007DF8F920E880
00007df8f93cec0b  jmp 0x00007DF8F93CE970
00007df8f93cec10  int3
00007df8f93cec11  nop [rax+rax*1], ax
00007df8f93cec1a  nop [rax+rax*1], ax
00007df8f93cec20  mov rax, [r15]
00007df8f93cec23  lea r14, [rax+0x20]
00007df8f93cec27  mov r12, [r13+r14*1]
00007df8f93cec2c  mov r14, [r15+0x10]
00007df8f93cec30  lea r11, [r12+r14*1]
00007df8f93cec34  mov [r15+0x40], r11
00007df8f93cec38  lea r12, [rax+0x20]
00007df8f93cec3c  mov [r13+r12*1], r11
00007df8f93cec41  test r14, r14
00007df8f93cec44  setz r14b
00007df8f93cec48  movzx r14, r14b
00007df8f93cec4c  mov [rsp+0x414], r14b
00007df8f93cec54  cmp byte ptr [rsp+0x414], 0x00
00007df8f93cec5c  jz 0x00007DF8F93CEC8E
00007df8f93cec5e  cmp dword ptr [r15+0x318], 0x00
00007df8f93cec66  mov eax, 0x4105B0
00007df8f93cec6b  mov [r15+0x100], rax
00007df8f93cec72  jz 0x00007DF8F91FE0A0
00007df8f93cec78  nop [rax+rax*1], eax
00007df8f93cec7d  mov eax, 0x4105B0
00007df8f93cec82  mov [r15+0x100], rax
00007df8f93cec89  jmp 0x00007DF8F91FE110
00007df8f93cec8e  cmp dword ptr [r15+0x318], 0x00
00007df8f93cec96  jz 0x00007DF8F93CECE0
00007df8f93cec9c  nop [rax+rax*1], ax
00007df8f93ceca5  nop [rax+rax*1], eax
00007df8f93cecad  mov eax, 0x410348
00007df8f93cecb2  mov [r15+0x100], rax
00007df8f93cecb9  jmp 0x00007DF8F91FE110
00007df8f93cecbe  int3
00007df8f93cecbf  call 0x00007DF8F92E27E0
00007df8f93cecc4  jmp 0x00007DF8F93CEC2C
00007df8f93cecc9  call 0x00007DF8F92C0860
00007df8f93cecce  jmp 0x00007DF8F93CEC41
00007df8f93cecd3  int3
00007df8f93cecd4  nop [rax+rax*1], ax
00007df8f93cecdd  nop [rax], eax
00007df8f93cece0  mov rax, [r15+0xF8]
00007df8f93cece7  lea r14, [rax-0x150]
00007df8f93cecee  mov [r15+0xF8], r14
00007df8f93cecf5  mov rax, [r15]
00007df8f93cecf8  lea r12, [rax+0x68]
00007df8f93cecfc  mov r11, [r13+r12*1]
00007df8f93ced01  mov [r15+0x88], r11
00007df8f93ced08  lea r12, [rax+0x28]
00007df8f93ced0c  mov [r15+0x40], r12
00007df8f93ced10  mov [r15+0x48], r14
00007df8f93ced14  mov qword ptr [r15+0x50], 0x420758
00007df8f93ced1c  lea rax, [r14+0x100]
00007df8f93ced23  mov r12, [r15+0xE8]
00007df8f93ced2a  mov r11, [r15+0xD8]
00007df8f93ced31  mov [r13+rax*1], r12
00007df8f93ced36  lea rax, [r14+0x108]
00007df8f93ced3d  mov [r13+rax*1], r11
00007df8f93ced42  lea rax, [r14+0x110]
00007df8f93ced49  mov r12, [r15+0xD0]
00007df8f93ced50  mov r11, [r15+0xC8]
00007df8f93ced57  mov [r13+rax*1], r12
00007df8f93ced5c  lea rax, [r14+0x118]
00007df8f93ced63  mov [r13+rax*1], r11
00007df8f93ced68  lea rax, [r14+0x120]
00007df8f93ced6f  mov r12, [r15+0xC0]
00007df8f93ced76  mov r11, [r15+0xB8]
00007df8f93ced7d  mov [r13+rax*1], r12
00007df8f93ced82  lea rax, [r14+0x128]
00007df8f93ced89  mov [r13+rax*1], r11
00007df8f93ced8e  lea rax, [r14+0x130]
00007df8f93ced95  mov r12, [r15+0xB0]
00007df8f93ced9c  mov r11, [r15+0xA8]
00007df8f93ceda3  mov [r13+rax*1], r12
00007df8f93ceda8  lea rax, [r14+0x138]
00007df8f93cedaf  mov [r13+rax*1], r11
00007df8f93cedb4  lea rax, [r14+0x140]
00007df8f93cedbb  mov r12, [r15+0xA0]
00007df8f93cedc2  mov r11, [r15+0x98]
00007df8f93cedc9  mov [r13+rax*1], r12
00007df8f93cedce  lea rax, [r14+0x148]
00007df8f93cedd5  mov [r13+rax*1], r11
00007df8f93cedda  cmp dword ptr [r15+0x318], 0x00
00007df8f93cede2  jz 0x00007DF8F93CEE80
00007df8f93cede8  nop [rax+rax*1], ax
00007df8f93cedf1  nop [rax+rax*1], eax
00007df8f93cedf9  mov eax, 0x410380
00007df8f93cedfe  mov [r15+0x100], rax
00007df8f93cee05  jmp 0x00007DF8F91FE110
00007df8f93cee0a  int3
00007df8f93cee0b  call 0x00007DF8F92C0370
00007df8f93cee10  jmp 0x00007DF8F93CED01
00007df8f93cee15  call 0x00007DF8F920BC20
00007df8f93cee1a  jmp 0x00007DF8F93CED36
00007df8f93cee1f  call 0x00007DF8F920A9A0
00007df8f93cee24  jmp 0x00007DF8F93CED42
00007df8f93cee29  call 0x00007DF8F920BC20
00007df8f93cee2e  jmp 0x00007DF8F93CED5C
00007df8f93cee33  call 0x00007DF8F920A9A0
00007df8f93cee38  jmp 0x00007DF8F93CED68
00007df8f93cee3d  call 0x00007DF8F920BC20
00007df8f93cee42  jmp 0x00007DF8F93CED82
00007df8f93cee47  call 0x00007DF8F920A9A0
00007df8f93cee4c  jmp 0x00007DF8F93CED8E
00007df8f93cee51  call 0x00007DF8F920BC20
00007df8f93cee56  jmp 0x00007DF8F93CEDA8
00007df8f93cee5b  call 0x00007DF8F920A9A0
00007df8f93cee60  jmp 0x00007DF8F93CEDB4
00007df8f93cee65  call 0x00007DF8F920BC20
00007df8f93cee6a  jmp 0x00007DF8F93CEDCE
00007df8f93cee6f  call 0x00007DF8F920A9A0
00007df8f93cee74  jmp 0x00007DF8F93CEDDA
00007df8f93cee79  int3
00007df8f93cee7a  nop [rax+rax*1], ax
00007df8f93cee80  mov rax, [r15+0x08]
00007df8f93cee84  movzx r14d, byte ptr [r13+rax*1]
00007df8f93cee8a  movzx r14d, r14b
00007df8f93cee8e  mov [rsp+0x10], r14d
00007df8f93cee93  mov r14d, r14d
00007df8f93cee96  mov [r15+0x58], r14
00007df8f93cee9a  lea r14, [rax+0x01]
00007df8f93cee9e  mov [r15+0x08], r14
00007df8f93ceea2  mov rax, [r15+0x88]
00007df8f93ceea9  lea r14, [rax+0x01]
00007df8f93ceead  mov r12, [r15]
00007df8f93ceeb0  lea r11, [r12+0x68]
00007df8f93ceeb5  mov [r13+r11*1], r14
00007df8f93ceeba  lea r14, [r12+rax*1]
00007df8f93ceebe  mov [r15+0x60], r14
00007df8f93ceec2  lea rax, [r14+0x28]
00007df8f93ceec6  mov r11d, [rsp+0x10]
00007df8f93ceecb  movzx r14d, r11b
00007df8f93ceecf  mov [r13+rax*1], r14b
00007df8f93ceed4  lea rax, [r12+0x68]
00007df8f93ceed9  mov r14, [r13+rax*1]
00007df8f93ceede  mov [r15+0x88], r14
00007df8f93ceee5  xor eax, eax
00007df8f93ceee7  mov r12d, 0x40
00007df8f93ceeed  cmp r14, r12
00007df8f93ceef0  cmc
00007df8f93ceef1  lahf
00007df8f93ceef2  seto al
00007df8f93ceef5  mov [r15+0x108], eax
00007df8f93ceefc  mov eax, [r15+0x108]
00007df8f93cef03  sahf
00007df8f93cef04  jnz 0x00007DF8F93CEF36
00007df8f93cef06  cmp dword ptr [r15+0x318], 0x00
00007df8f93cef0e  jz 0x00007DF8F93CF020
00007df8f93cef14  nop [rax+rax*1], ax
00007df8f93cef1d  nop [rax+rax*1], eax
00007df8f93cef25  mov eax, 0x4103A0
00007df8f93cef2a  mov [r15+0x100], rax
00007df8f93cef31  jmp 0x00007DF8F91FE110
00007df8f93cef36  cmp dword ptr [r15+0x318], 0x00
00007df8f93cef3e  jz 0x00007DF8F93CEF90
00007df8f93cef44  nop [rax+rax*1], ax
00007df8f93cef4d  nop [rax+rax*1], eax
00007df8f93cef55  mov eax, 0x410378
00007df8f93cef5a  mov [r15+0x100], rax
00007df8f93cef61  jmp 0x00007DF8F91FE110
00007df8f93cef66  int3
00007df8f93cef67  call 0x00007DF8F920D860
00007df8f93cef6c  jmp 0x00007DF8F93CEE8A
00007df8f93cef71  call 0x00007DF8F92B36E0
00007df8f93cef76  jmp 0x00007DF8F93CEEBA
00007df8f93cef7b  call 0x00007DF8F920DD60
00007df8f93cef80  jmp 0x00007DF8F93CEED4
00007df8f93cef85  call 0x00007DF8F920DC20
00007df8f93cef8a  jmp 0x00007DF8F93CEEDE
00007df8f93cef8f  int3
00007df8f93cef90  mov rax, [r15+0x10]
00007df8f93cef94  lea r14, [rax-0x01]
00007df8f93cef98  mov [r15+0x10], r14
00007df8f93cef9c  test r14, r14
00007df8f93cef9f  setz r14b
00007df8f93cefa3  movzx r14, r14b
00007df8f93cefa7  mov [rsp+0x414], r14b
00007df8f93cefaf  cmp byte ptr [rsp+0x414], 0x00
00007df8f93cefb7  jz 0x00007DF8F93CEFE9
00007df8f93cefb9  cmp dword ptr [r15+0x318], 0x00
00007df8f93cefc1  jz 0x00007DF8F93D0520
00007df8f93cefc7  nop [rax+rax*1], ax
00007df8f93cefd0  nop [rax+rax*1], eax
00007df8f93cefd8  mov eax, 0x410598
00007df8f93cefdd  mov [r15+0x100], rax
00007df8f93cefe4  jmp 0x00007DF8F91FE110
00007df8f93cefe9  cmp dword ptr [r15+0x318], 0x00
00007df8f93ceff1  jz 0x00007DF8F93CEE80
00007df8f93ceff7  nop [rax+rax*1], ax
00007df8f93cf000  nop [rax+rax*1], eax
00007df8f93cf008  mov eax, 0x410380
00007df8f93cf00d  mov [r15+0x100], rax
00007df8f93cf014  jmp 0x00007DF8F91FE110
00007df8f93cf019  int3
00007df8f93cf01a  int3
00007df8f93cf01b  nop [rax+rax*1], eax
00007df8f93cf020  mov rax, [r15+0x40]
00007df8f93cf024  movzx r14d, byte ptr [r13+rax*1]
00007df8f93cf02a  movaps xmm1, [r15+0x110]
00007df8f93cf032  pinsrb xmm1, r14d, 0x00
00007df8f93cf039  lea r14, [rax+0x01]
00007df8f93cf03d  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf043  movaps xmm15, [r15+0x120]
00007df8f93cf04b  pinsrb xmm15, r12d, 0x00
00007df8f93cf052  lea r14, [rax+0x02]
00007df8f93cf056  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf05c  movaps xmm14, [r15+0x130]
00007df8f93cf064  pinsrb xmm14, r12d, 0x00
00007df8f93cf06b  lea r14, [rax+0x03]
00007df8f93cf06f  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf075  movaps xmm13, [r15+0x140]
00007df8f93cf07d  pinsrb xmm13, r12d, 0x00
00007df8f93cf084  lea r14, [rax+0x04]
00007df8f93cf088  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf08e  pinsrb xmm1, r12d, 0x01
00007df8f93cf095  lea r14, [rax+0x05]
00007df8f93cf099  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf09f  pinsrb xmm15, r12d, 0x01
00007df8f93cf0a6  lea r14, [rax+0x06]
00007df8f93cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf0b0  pinsrb xmm14, r12d, 0x01
00007df8f93cf0b7  lea r14, [rax+0x07]
00007df8f93cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf0c1  pinsrb xmm13, r12d, 0x01
00007df8f93cf0c8  lea r14, [rax+0x08]
00007df8f93cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf0d2  pinsrb xmm1, r12d, 0x02
00007df8f93cf0d9  lea r14, [rax+0x09]
00007df8f93cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf0e3  pinsrb xmm15, r12d, 0x02
00007df8f93cf0ea  lea r14, [rax+0x0A]
00007df8f93cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf0f4  pinsrb xmm14, r12d, 0x02
00007df8f93cf0fb  lea r14, [rax+0x0B]
00007df8f93cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf105  pinsrb xmm13, r12d, 0x02
00007df8f93cf10c  lea r14, [rax+0x0C]
00007df8f93cf110  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf116  pinsrb xmm1, r12d, 0x03
00007df8f93cf11d  lea r14, [rax+0x0D]
00007df8f93cf121  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf127  pinsrb xmm15, r12d, 0x03
00007df8f93cf12e  lea r14, [rax+0x0E]
00007df8f93cf132  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf138  pinsrb xmm14, r12d, 0x03
00007df8f93cf13f  lea r14, [rax+0x0F]
00007df8f93cf143  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf149  pinsrb xmm13, r12d, 0x03
00007df8f93cf150  lea r14, [rax+0x10]
00007df8f93cf154  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf15a  pinsrb xmm1, r12d, 0x04
00007df8f93cf161  lea r14, [rax+0x11]
00007df8f93cf165  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf16b  pinsrb xmm15, r12d, 0x04
00007df8f93cf172  lea r14, [rax+0x12]
00007df8f93cf176  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf17c  pinsrb xmm14, r12d, 0x04
00007df8f93cf183  lea r14, [rax+0x13]
00007df8f93cf187  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf18d  pinsrb xmm13, r12d, 0x04
00007df8f93cf194  lea r14, [rax+0x14]
00007df8f93cf198  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf19e  pinsrb xmm1, r12d, 0x05
00007df8f93cf1a5  lea r14, [rax+0x15]
00007df8f93cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf1af  pinsrb xmm15, r12d, 0x05
00007df8f93cf1b6  lea r14, [rax+0x16]
00007df8f93cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf1c0  pinsrb xmm14, r12d, 0x05
00007df8f93cf1c7  lea r14, [rax+0x17]
00007df8f93cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf1d1  pinsrb xmm13, r12d, 0x05
00007df8f93cf1d8  lea r14, [rax+0x18]
00007df8f93cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf1e2  pinsrb xmm1, r12d, 0x06
00007df8f93cf1e9  lea r14, [rax+0x19]
00007df8f93cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf1f3  pinsrb xmm15, r12d, 0x06
00007df8f93cf1fa  lea r14, [rax+0x1A]
00007df8f93cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf204  pinsrb xmm14, r12d, 0x06
00007df8f93cf20b  lea r14, [rax+0x1B]
00007df8f93cf20f  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf215  pinsrb xmm13, r12d, 0x06
00007df8f93cf21c  lea r14, [rax+0x1C]
00007df8f93cf220  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf226  pinsrb xmm1, r12d, 0x07
00007df8f93cf22d  lea r14, [rax+0x1D]
00007df8f93cf231  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf237  pinsrb xmm15, r12d, 0x07
00007df8f93cf23e  lea r14, [rax+0x1E]
00007df8f93cf242  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf248  pinsrb xmm14, r12d, 0x07
00007df8f93cf24f  lea r14, [rax+0x1F]
00007df8f93cf253  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf259  pinsrb xmm13, r12d, 0x07
00007df8f93cf260  lea r14, [rax+0x20]
00007df8f93cf264  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf26a  pinsrb xmm1, r12d, 0x08
00007df8f93cf271  lea r14, [rax+0x21]
00007df8f93cf275  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf27b  pinsrb xmm15, r12d, 0x08
00007df8f93cf282  lea r14, [rax+0x22]
00007df8f93cf286  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf28c  pinsrb xmm14, r12d, 0x08
00007df8f93cf293  lea r14, [rax+0x23]
00007df8f93cf297  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf29d  pinsrb xmm13, r12d, 0x08
00007df8f93cf2a4  lea r14, [rax+0x24]
00007df8f93cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf2ae  pinsrb xmm1, r12d, 0x09
00007df8f93cf2b5  lea r14, [rax+0x25]
00007df8f93cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf2bf  pinsrb xmm15, r12d, 0x09
00007df8f93cf2c6  lea r14, [rax+0x26]
00007df8f93cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf2d0  pinsrb xmm14, r12d, 0x09
00007df8f93cf2d7  lea r14, [rax+0x27]
00007df8f93cf2db  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf2e1  pinsrb xmm13, r12d, 0x09
00007df8f93cf2e8  lea r14, [rax+0x28]
00007df8f93cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf2f2  pinsrb xmm1, r12d, 0x0A
00007df8f93cf2f9  lea r14, [rax+0x29]
00007df8f93cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf303  pinsrb xmm15, r12d, 0x0A
00007df8f93cf30a  lea r14, [rax+0x2A]
00007df8f93cf30e  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf314  pinsrb xmm14, r12d, 0x0A
00007df8f93cf31b  lea r14, [rax+0x2B]
00007df8f93cf31f  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf325  pinsrb xmm13, r12d, 0x0A
00007df8f93cf32c  lea r14, [rax+0x2C]
00007df8f93cf330  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf336  pinsrb xmm1, r12d, 0x0B
00007df8f93cf33d  lea r14, [rax+0x2D]
00007df8f93cf341  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf347  pinsrb xmm15, r12d, 0x0B
00007df8f93cf34e  lea r14, [rax+0x2E]
00007df8f93cf352  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf358  pinsrb xmm14, r12d, 0x0B
00007df8f93cf35f  lea r14, [rax+0x2F]
00007df8f93cf363  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf369  pinsrb xmm13, r12d, 0x0B
00007df8f93cf370  lea r14, [rax+0x30]
00007df8f93cf374  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf37a  pinsrb xmm1, r12d, 0x0C
00007df8f93cf381  lea r14, [rax+0x31]
00007df8f93cf385  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf38b  pinsrb xmm15, r12d, 0x0C
00007df8f93cf392  lea r14, [rax+0x32]
00007df8f93cf396  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf39c  pinsrb xmm14, r12d, 0x0C
00007df8f93cf3a3  lea r14, [rax+0x33]
00007df8f93cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf3ad  pinsrb xmm13, r12d, 0x0C
00007df8f93cf3b4  lea r14, [rax+0x34]
00007df8f93cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf3be  pinsrb xmm1, r12d, 0x0D
00007df8f93cf3c5  lea r14, [rax+0x35]
00007df8f93cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf3cf  pinsrb xmm15, r12d, 0x0D
00007df8f93cf3d6  lea r14, [rax+0x36]
00007df8f93cf3da  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf3e0  pinsrb xmm14, r12d, 0x0D
00007df8f93cf3e7  lea r14, [rax+0x37]
00007df8f93cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf3f1  pinsrb xmm13, r12d, 0x0D
00007df8f93cf3f8  lea r14, [rax+0x38]
00007df8f93cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf402  pinsrb xmm1, r12d, 0x0E
00007df8f93cf409  lea r14, [rax+0x39]
00007df8f93cf40d  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf413  pinsrb xmm15, r12d, 0x0E
00007df8f93cf41a  lea r14, [rax+0x3A]
00007df8f93cf41e  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf424  pinsrb xmm14, r12d, 0x0E
00007df8f93cf42b  lea r14, [rax+0x3B]
00007df8f93cf42f  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf435  pinsrb xmm13, r12d, 0x0E
00007df8f93cf43c  lea r14, [rax+0x3C]
00007df8f93cf440  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf446  pinsrb xmm1, r12d, 0x0F
00007df8f93cf44d  movaps [r15+0x110], xmm1
00007df8f93cf455  lea r14, [rax+0x3D]
00007df8f93cf459  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf45f  pinsrb xmm15, r12d, 0x0F
00007df8f93cf466  movaps [r15+0x120], xmm15
00007df8f93cf46e  lea r14, [rax+0x3E]
00007df8f93cf472  movzx r12d, byte ptr [r13+r14*1]
00007df8f93cf478  pinsrb xmm14, r12d, 0x0F
00007df8f93cf47f  movaps [r15+0x130], xmm14
00007df8f93cf487  lea r14, [rax+0x3F]
00007df8f93cf48b  movzx eax, byte ptr [r13+r14*1]
00007df8f93cf491  pinsrb xmm13, eax, 0x0F
00007df8f93cf498  movaps [r15+0x140], xmm13
00007df8f93cf4a0  movq xmm1, qword ptr [r15+0x120]
00007df8f93cf4a9  pmovzxbw xmm1, xmm1
00007df8f93cf4ae  psllw xmm1, 0x00
00007df8f93cf4b3  movaps [r15+0x150], xmm1
00007df8f93cf4bb  movq xmm1, qword ptr [r15+0x130]
00007df8f93cf4c4  pmovzxbw xmm1, xmm1
00007df8f93cf4c9  psllw xmm1, 0x00
00007df8f93cf4ce  movaps [r15+0x160], xmm1
00007df8f93cf4d6  movq xmm1, qword ptr [r15+0x110]
00007df8f93cf4df  pmovzxbw xmm1, xmm1
00007df8f93cf4e4  psllw xmm1, 0x00
00007df8f93cf4e9  movaps [r15+0x170], xmm1
00007df8f93cf4f1  movaps xmm15, [r15+0x110]
00007df8f93cf4f9  pextrq rax, xmm15, 0x01
00007df8f93cf500  movq xmm15, rax
00007df8f93cf505  pmovzxbw xmm15, xmm15
00007df8f93cf50b  psllw xmm15, 0x00
00007df8f93cf511  movaps [r15+0x180], xmm15
00007df8f93cf519  movaps xmm14, [r15+0x120]
00007df8f93cf521  pextrq rax, xmm14, 0x01
00007df8f93cf528  movq xmm14, rax
00007df8f93cf52d  pmovzxbw xmm14, xmm14
00007df8f93cf533  psllw xmm14, 0x00
00007df8f93cf539  movaps [r15+0x210], xmm14
00007df8f93cf541  movaps xmm13, [r15+0x130]
00007df8f93cf549  pextrq rax, xmm13, 0x01
00007df8f93cf550  movq xmm13, rax
00007df8f93cf555  pmovzxbw xmm13, xmm13
00007df8f93cf55b  psllw xmm13, 0x00
00007df8f93cf561  movaps [r15+0x220], xmm13
00007df8f93cf569  movq xmm12, qword ptr [r15+0x140]
00007df8f93cf572  pmovzxbw xmm12, xmm12
00007df8f93cf578  psllw xmm12, 0x00
00007df8f93cf57e  movaps [r15+0x250], xmm12
00007df8f93cf586  movaps xmm12, [r15+0x140]
00007df8f93cf58e  pextrq rax, xmm12, 0x01
00007df8f93cf595  movq xmm12, rax
00007df8f93cf59a  pmovzxbw xmm12, xmm12
00007df8f93cf5a0  psllw xmm12, 0x00
00007df8f93cf5a6  movaps [r15+0x110], xmm12
00007df8f93cf5ae  movq xmm11, qword ptr [r15+0x150]
00007df8f93cf5b7  pmovzxwd xmm11, xmm11
00007df8f93cf5bd  pslld xmm11, 0x10
00007df8f93cf5c3  movq xmm10, qword ptr [r15+0x160]
00007df8f93cf5cc  pmovzxwd xmm10, xmm10
00007df8f93cf5d2  pslld xmm10, 0x08
00007df8f93cf5d8  pextrq rax, xmm1, 0x01
00007df8f93cf5df  movq xmm1, rax
00007df8f93cf5e4  pmovzxwd xmm1, xmm1
00007df8f93cf5e9  pslld xmm1, 0x00
00007df8f93cf5ee  movaps [r15+0x260], xmm1
00007df8f93cf5f6  pextrq rax, xmm15, 0x01
00007df8f93cf5fd  movq xmm15, rax
00007df8f93cf602  pmovzxwd xmm15, xmm15
00007df8f93cf608  pslld xmm15, 0x00
00007df8f93cf60e  movaps [r15+0x270], xmm15
00007df8f93cf616  movq xmm9, qword ptr [r15+0x170]
00007df8f93cf61f  pmovzxwd xmm9, xmm9
00007df8f93cf625  pslld xmm9, 0x00
00007df8f93cf62b  pextrq rax, xmm14, 0x01
00007df8f93cf632  movq xmm14, rax
00007df8f93cf637  pmovzxwd xmm14, xmm14
00007df8f93cf63d  pslld xmm14, 0x10
00007df8f93cf643  movaps [r15+0x280], xmm14
00007df8f93cf64b  movq xmm8, qword ptr [r15+0x180]
00007df8f93cf654  pmovzxwd xmm8, xmm8
00007df8f93cf65a  pslld xmm8, 0x00
00007df8f93cf660  movq xmm7, qword ptr [r15+0x210]
00007df8f93cf669  pmovzxwd xmm7, xmm7
00007df8f93cf66e  pslld xmm7, 0x10
00007df8f93cf673  movaps xmm6, [r15+0x150]
00007df8f93cf67b  pextrq rax, xmm6, 0x01
00007df8f93cf682  movq xmm6, rax
00007df8f93cf687  pmovzxwd xmm6, xmm6
00007df8f93cf68c  pslld xmm6, 0x10
00007df8f93cf691  por xmm11, xmm10
00007df8f93cf696  movaps [r15+0x230], xmm11
00007df8f93cf69e  pextrq rax, xmm13, 0x01
00007df8f93cf6a5  movq xmm13, rax
00007df8f93cf6aa  pmovzxwd xmm13, xmm13
00007df8f93cf6b0  pslld xmm13, 0x08
00007df8f93cf6b6  movaps [r15+0x240], xmm13
00007df8f93cf6be  movq xmm10, qword ptr [r15+0x220]
00007df8f93cf6c7  pmovzxwd xmm10, xmm10
00007df8f93cf6cd  pslld xmm10, 0x08
00007df8f93cf6d3  movaps xmm5, [r15+0x160]
00007df8f93cf6db  pextrq rax, xmm5, 0x01
00007df8f93cf6e2  movq xmm5, rax
00007df8f93cf6e7  pmovzxwd xmm5, xmm5
00007df8f93cf6ec  pslld xmm5, 0x08
00007df8f93cf6f1  pslld xmm9, 0x18
00007df8f93cf6f7  pslld xmm15, 0x18
00007df8f93cf6fd  pslld xmm8, 0x18
00007df8f93cf703  movq xmm4, qword ptr [r15+0x250]
00007df8f93cf70c  pmovzxwd xmm4, xmm4
00007df8f93cf711  pslld xmm4, 0x00
00007df8f93cf716  por xmm14, xmm13
00007df8f93cf71b  por xmm7, xmm10
00007df8f93cf720  movaps [r15+0x210], xmm7
00007df8f93cf728  pslld xmm1, 0x18
00007df8f93cf72d  movaps [r15+0x220], xmm1
00007df8f93cf735  por xmm6, xmm5
00007df8f93cf739  por xmm11, xmm9
00007df8f93cf73e  movaps [r15+0x160], xmm11
00007df8f93cf746  pextrq rax, xmm12, 0x01
00007df8f93cf74d  movq xmm13, rax
00007df8f93cf752  pmovzxwd xmm13, xmm13
00007df8f93cf758  pslld xmm13, 0x00
00007df8f93cf75e  movaps [r15+0x170], xmm13
00007df8f93cf766  movq xmm12, qword ptr [r15+0x110]
00007df8f93cf76f  pmovzxwd xmm12, xmm12
00007df8f93cf775  pslld xmm12, 0x00
00007df8f93cf77b  por xmm14, xmm15
00007df8f93cf780  por xmm7, xmm8
00007df8f93cf785  movaps xmm15, [r15+0x250]
00007df8f93cf78d  pextrq rax, xmm15, 0x01
00007df8f93cf794  movq xmm15, rax
00007df8f93cf799  pmovzxwd xmm15, xmm15
00007df8f93cf79f  pslld xmm15, 0x00
00007df8f93cf7a5  movaps [r15+0x180], xmm15
00007df8f93cf7ad  por xmm6, xmm1
00007df8f93cf7b1  movaps [r15+0x150], xmm6
00007df8f93cf7b9  por xmm11, xmm4
00007df8f93cf7be  movaps [r15+0x140], xmm11
00007df8f93cf7c6  por xmm7, xmm12
00007df8f93cf7cb  movaps [r15+0x110], xmm7
00007df8f93cf7d3  por xmm14, xmm13
00007df8f93cf7d8  movaps [r15+0x120], xmm14
00007df8f93cf7e0  por xmm6, xmm15
00007df8f93cf7e5  movaps [r15+0x130], xmm6
00007df8f93cf7ed  mov rax, [r15+0xF8]
00007df8f93cf7f4  lea r14, [rax+0x20]
00007df8f93cf7f8  movups [r13+r14*1], xmm7
00007df8f93cf7fe  lea r14, [rax+0x30]
00007df8f93cf802  movups [r13+r14*1], xmm14
00007df8f93cf808  movups [r13+rax*1], xmm11
00007df8f93cf80e  lea r14, [rax+0x10]
00007df8f93cf812  movups [r13+r14*1], xmm6
00007df8f93cf818  mov r14d, [r13+rax*1]
00007df8f93cf81d  mov rax, [r15+0x48]
00007df8f93cf821  mov [r15+0x68], rax
00007df8f93cf825  mov qword ptr [r15+0x58], 0x04
00007df8f93cf82d  lea r12, [rax+0x04]
00007df8f93cf831  mov r11d, [r13+r12*1]
00007df8f93cf836  mov [rsp+0x10], r11d
00007df8f93cf83b  mov r11d, r11d
00007df8f93cf83e  mov [r15+0x70], r11
00007df8f93cf842  lea r12, [rax+0x38]
00007df8f93cf846  mov r11d, [r13+r12*1]
00007df8f93cf84b  lea r12, [rax+0x24]
00007df8f93cf84f  mov r10d, [r13+r12*1]
00007df8f93cf854  mov [rsp+0x20], r10d
00007df8f93cf859  mov r10d, r10d
00007df8f93cf85c  mov [r15+0x90], r10
00007df8f93cf863  mov [rsp+0x30], rax
00007df8f93cf868  xor eax, eax
00007df8f93cf86a  mov r12d, 0x04
00007df8f93cf870  mov r10d, 0xC0
00007df8f93cf876  cmp r12, r10
00007df8f93cf879  cmc
00007df8f93cf87a  lahf
00007df8f93cf87b  seto al
00007df8f93cf87e  mov [r15+0x108], eax
00007df8f93cf885  mov eax, [rsp+0x10]
00007df8f93cf889  mov r12d, [rsp+0x10]
00007df8f93cf88e  shrd eax, r12d, 0x07
00007df8f93cf893  mov [rsp+0x10], r11d
00007df8f93cf898  mov r10d, [rsp+0x10]
00007df8f93cf89d  shrd r11d, r10d, 0x11
00007df8f93cf8a2  mov r9d, [rsp+0x20]
00007df8f93cf8a7  lea r8d, [r9d+r14d*1]
00007df8f93cf8ac  rorx r14d, r12d, 0x12
00007df8f93cf8b2  xor eax, r14d
00007df8f93cf8b5  rorx r14d, r10d, 0x13
00007df8f93cf8bb  xor r11d, r14d
00007df8f93cf8be  mov [rsp+0x10], r11d
00007df8f93cf8c3  mov r11d, r11d
00007df8f93cf8c6  mov [r15+0x88], r11
00007df8f93cf8cd  mov [rsp+0x20], r12d
00007df8f93cf8d2  shr r12d, 0x03
00007df8f93cf8d6  xor eax, r12d
00007df8f93cf8d9  mov [rsp+0x40], eax
00007df8f93cf8dd  mov eax, eax
00007df8f93cf8df  mov [r15+0x80], rax
00007df8f93cf8e6  shr r10d, 0x0A
00007df8f93cf8ea  mov eax, [rsp+0x10]
00007df8f93cf8ee  xor eax, r10d
00007df8f93cf8f1  mov [rsp+0x10], eax
00007df8f93cf8f5  mov eax, eax
00007df8f93cf8f7  mov [r15+0x78], rax
00007df8f93cf8fb  mov eax, [rsp+0x40]
00007df8f93cf8ff  lea r14d, [r8d+eax*1]
00007df8f93cf904  mov eax, [rsp+0x10]
00007df8f93cf908  lea r12d, [r14d+eax*1]
00007df8f93cf90d  mov rax, [rsp+0x30]
00007df8f93cf912  lea r14, [rax+0x40]
00007df8f93cf916  mov [r13+r14*1], r12d
00007df8f93cf91b  mov eax, [rsp+0x20]
00007df8f93cf91f  mov eax, eax
00007df8f93cf921  mov [r15+0x60], rax
00007df8f93cf925  mov eax, [r15+0x108]
00007df8f93cf92c  sahf
00007df8f93cf92d  jnz 0x00007DF8F93CF95F
00007df8f93cf92f  cmp dword ptr [r15+0x318], 0x00
00007df8f93cf937  jz 0x00007DF8F93CFE20
00007df8f93cf93d  nop [rax+rax*1], ax
00007df8f93cf946  nop [rax+rax*1], eax
00007df8f93cf94e  mov eax, 0x41049C
00007df8f93cf953  mov [r15+0x100], rax
00007df8f93cf95a  jmp 0x00007DF8F91FE110
00007df8f93cf95f  cmp dword ptr [r15+0x318], 0x00
00007df8f93cf967  jz 0x00007DF8F93CFC70
00007df8f93cf96d  nop [rax+rax*1], ax
00007df8f93cf976  nop [rax+rax*1], eax
00007df8f93cf97e  mov eax, 0x410454
00007df8f93cf983  mov [r15+0x100], rax
00007df8f93cf98a  jmp 0x00007DF8F91FE110
00007df8f93cf98f  int3
00007df8f93cf990  call 0x00007DF8F920D860
00007df8f93cf995  jmp 0x00007DF8F93CF02A
00007df8f93cf99a  call 0x00007DF8F92E2420
00007df8f93cf99f  jmp 0x00007DF8F93CF043
00007df8f93cf9a4  call 0x00007DF8F92E2420
00007df8f93cf9a9  jmp 0x00007DF8F93CF05C
00007df8f93cf9ae  call 0x00007DF8F92E2420
00007df8f93cf9b3  jmp 0x00007DF8F93CF075
00007df8f93cf9b8  call 0x00007DF8F92E2420
00007df8f93cf9bd  jmp 0x00007DF8F93CF08E
00007df8f93cf9c2  call 0x00007DF8F92E2420
00007df8f93cf9c7  jmp 0x00007DF8F93CF09F
00007df8f93cf9cc  call 0x00007DF8F92E2420
00007df8f93cf9d1  jmp 0x00007DF8F93CF0B0
00007df8f93cf9d6  call 0x00007DF8F92E2420
00007df8f93cf9db  jmp 0x00007DF8F93CF0C1
00007df8f93cf9e0  call 0x00007DF8F92E2420
00007df8f93cf9e5  jmp 0x00007DF8F93CF0D2
00007df8f93cf9ea  call 0x00007DF8F92E2420
00007df8f93cf9ef  jmp 0x00007DF8F93CF0E3
00007df8f93cf9f4  call 0x00007DF8F92E2420
00007df8f93cf9f9  jmp 0x00007DF8F93CF0F4
00007df8f93cf9fe  call 0x00007DF8F92E2420
00007df8f93cfa03  jmp 0x00007DF8F93CF105
00007df8f93cfa08  call 0x00007DF8F92E2420
00007df8f93cfa0d  jmp 0x00007DF8F93CF116
00007df8f93cfa12  call 0x00007DF8F92E2420
00007df8f93cfa17  jmp 0x00007DF8F93CF127
00007df8f93cfa1c  call 0x00007DF8F92E2420
00007df8f93cfa21  jmp 0x00007DF8F93CF138
00007df8f93cfa26  call 0x00007DF8F92E2420
00007df8f93cfa2b  jmp 0x00007DF8F93CF149
00007df8f93cfa30  call 0x00007DF8F92E2420
00007df8f93cfa35  jmp 0x00007DF8F93CF15A
00007df8f93cfa3a  call 0x00007DF8F92E2420
00007df8f93cfa3f  jmp 0x00007DF8F93CF16B
00007df8f93cfa44  call 0x00007DF8F92E2420
00007df8f93cfa49  jmp 0x00007DF8F93CF17C
00007df8f93cfa4e  call 0x00007DF8F92E2420
00007df8f93cfa53  jmp 0x00007DF8F93CF18D
00007df8f93cfa58  call 0x00007DF8F92E2420
00007df8f93cfa5d  jmp 0x00007DF8F93CF19E
00007df8f93cfa62  call 0x00007DF8F92E2420
00007df8f93cfa67  jmp 0x00007DF8F93CF1AF
00007df8f93cfa6c  call 0x00007DF8F92E2420
00007df8f93cfa71  jmp 0x00007DF8F93CF1C0
00007df8f93cfa76  call 0x00007DF8F92E2420
00007df8f93cfa7b  jmp 0x00007DF8F93CF1D1
00007df8f93cfa80  call 0x00007DF8F92E2420
00007df8f93cfa85  jmp 0x00007DF8F93CF1E2
00007df8f93cfa8a  call 0x00007DF8F92E2420
00007df8f93cfa8f  jmp 0x00007DF8F93CF1F3
00007df8f93cfa94  call 0x00007DF8F92E2420
00007df8f93cfa99  jmp 0x00007DF8F93CF204
00007df8f93cfa9e  call 0x00007DF8F92E2420
00007df8f93cfaa3  jmp 0x00007DF8F93CF215
00007df8f93cfaa8  call 0x00007DF8F92E2420
00007df8f93cfaad  jmp 0x00007DF8F93CF226
00007df8f93cfab2  call 0x00007DF8F92E2420
00007df8f93cfab7  jmp 0x00007DF8F93CF237
00007df8f93cfabc  call 0x00007DF8F92E2420
00007df8f93cfac1  jmp 0x00007DF8F93CF248
00007df8f93cfac6  call 0x00007DF8F92E2420
00007df8f93cfacb  jmp 0x00007DF8F93CF259
00007df8f93cfad0  call 0x00007DF8F92E2420
00007df8f93cfad5  jmp 0x00007DF8F93CF26A
00007df8f93cfada  call 0x00007DF8F92E2420
00007df8f93cfadf  jmp 0x00007DF8F93CF27B
00007df8f93cfae4  call 0x00007DF8F92E2420
00007df8f93cfae9  jmp 0x00007DF8F93CF28C
00007df8f93cfaee  call 0x00007DF8F92E2420
00007df8f93cfaf3  jmp 0x00007DF8F93CF29D
00007df8f93cfaf8  call 0x00007DF8F92E2420
00007df8f93cfafd  jmp 0x00007DF8F93CF2AE
00007df8f93cfb02  call 0x00007DF8F92E2420
00007df8f93cfb07  jmp 0x00007DF8F93CF2BF
00007df8f93cfb0c  call 0x00007DF8F92E2420
00007df8f93cfb11  jmp 0x00007DF8F93CF2D0
00007df8f93cfb16  call 0x00007DF8F92E2420
00007df8f93cfb1b  jmp 0x00007DF8F93CF2E1
00007df8f93cfb20  call 0x00007DF8F92E2420
00007df8f93cfb25  jmp 0x00007DF8F93CF2F2
00007df8f93cfb2a  call 0x00007DF8F92E2420
00007df8f93cfb2f  jmp 0x00007DF8F93CF303
00007df8f93cfb34  call 0x00007DF8F92E2420
00007df8f93cfb39  jmp 0x00007DF8F93CF314
00007df8f93cfb3e  call 0x00007DF8F92E2420
00007df8f93cfb43  jmp 0x00007DF8F93CF325
00007df8f93cfb48  call 0x00007DF8F92E2420
00007df8f93cfb4d  jmp 0x00007DF8F93CF336
00007df8f93cfb52  call 0x00007DF8F92E2420
00007df8f93cfb57  jmp 0x00007DF8F93CF347
00007df8f93cfb5c  call 0x00007DF8F92E2420
00007df8f93cfb61  jmp 0x00007DF8F93CF358
00007df8f93cfb66  call 0x00007DF8F92E2420
00007df8f93cfb6b  jmp 0x00007DF8F93CF369
00007df8f93cfb70  call 0x00007DF8F92E2420
00007df8f93cfb75  jmp 0x00007DF8F93CF37A
00007df8f93cfb7a  call 0x00007DF8F92E2420
00007df8f93cfb7f  jmp 0x00007DF8F93CF38B
00007df8f93cfb84  call 0x00007DF8F92E2420
00007df8f93cfb89  jmp 0x00007DF8F93CF39C
00007df8f93cfb8e  call 0x00007DF8F92E2420
00007df8f93cfb93  jmp 0x00007DF8F93CF3AD
00007df8f93cfb98  call 0x00007DF8F92E2420
00007df8f93cfb9d  jmp 0x00007DF8F93CF3BE
00007df8f93cfba2  call 0x00007DF8F92E2420
00007df8f93cfba7  jmp 0x00007DF8F93CF3CF
00007df8f93cfbac  call 0x00007DF8F92E2420
00007df8f93cfbb1  jmp 0x00007DF8F93CF3E0
00007df8f93cfbb6  call 0x00007DF8F92E2420
00007df8f93cfbbb  jmp 0x00007DF8F93CF3F1
00007df8f93cfbc0  call 0x00007DF8F92E2420
00007df8f93cfbc5  jmp 0x00007DF8F93CF402
00007df8f93cfbca  call 0x00007DF8F92E2420
00007df8f93cfbcf  jmp 0x00007DF8F93CF413
00007df8f93cfbd4  call 0x00007DF8F92E2420
00007df8f93cfbd9  jmp 0x00007DF8F93CF424
00007df8f93cfbde  call 0x00007DF8F92E2420
00007df8f93cfbe3  jmp 0x00007DF8F93CF435
00007df8f93cfbe8  call 0x00007DF8F92E2420
00007df8f93cfbed  jmp 0x00007DF8F93CF446
00007df8f93cfbf2  call 0x00007DF8F92E2420
00007df8f93cfbf7  jmp 0x00007DF8F93CF45F
00007df8f93cfbfc  call 0x00007DF8F92E2420
00007df8f93cfc01  jmp 0x00007DF8F93CF478
00007df8f93cfc06  call 0x00007DF8F92D5610
00007df8f93cfc0b  jmp 0x00007DF8F93CF491
00007df8f93cfc10  call 0x00007DF8F92DC580
00007df8f93cfc15  jmp 0x00007DF8F93CF7FE
00007df8f93cfc1a  call 0x00007DF8F92E46C0
00007df8f93cfc1f  jmp 0x00007DF8F93CF808
00007df8f93cfc24  call 0x00007DF8F9209E90
00007df8f93cfc29  jmp 0x00007DF8F93CF80E
00007df8f93cfc2e  call 0x00007DF8F92DB310
00007df8f93cfc33  jmp 0x00007DF8F93CF818
00007df8f93cfc38  call 0x00007DF8F920DAE0
00007df8f93cfc3d  jmp 0x00007DF8F93CF81D
00007df8f93cfc42  call 0x00007DF8F92C0230
00007df8f93cfc47  jmp 0x00007DF8F93CF836
00007df8f93cfc4c  call 0x00007DF8F92C0230
00007df8f93cfc51  jmp 0x00007DF8F93CF84B
00007df8f93cfc56  call 0x00007DF8F92BEFC0
00007df8f93cfc5b  jmp 0x00007DF8F93CF854
00007df8f93cfc60  call 0x00007DF8F92E2BA0
00007df8f93cfc65  jmp 0x00007DF8F93CF91B
00007df8f93cfc6a  int3
00007df8f93cfc6b  nop [rax+rax*1], eax
00007df8f93cfc70  mov rax, [r15+0x48]
00007df8f93cfc74  mov r14, [r15+0x58]
00007df8f93cfc78  lea r12, [rax+r14*1]
00007df8f93cfc7c  mov [r15+0x68], r12
00007df8f93cfc80  lea rax, [r14+0x04]
00007df8f93cfc84  mov [r15+0x58], rax
00007df8f93cfc88  lea r14, [r12+0x04]
00007df8f93cfc8d  mov r11d, [r13+r14*1]
00007df8f93cfc92  mov [rsp+0x10], r11d
00007df8f93cfc97  mov r11d, r11d
00007df8f93cfc9a  mov [r15+0x70], r11
00007df8f93cfc9e  lea r14, [r12+0x38]
00007df8f93cfca3  mov r11d, [r13+r14*1]
00007df8f93cfca8  lea r14, [r12+0x24]
00007df8f93cfcad  mov r10d, [r13+r14*1]
00007df8f93cfcb2  mov [rsp+0x20], r10d
00007df8f93cfcb7  mov r10d, r10d
00007df8f93cfcba  mov [r15+0x90], r10
00007df8f93cfcc1  mov [rsp+0x30], rax
00007df8f93cfcc6  xor eax, eax
00007df8f93cfcc8  mov r14, [rsp+0x30]
00007df8f93cfccd  mov r10d, 0xC0
00007df8f93cfcd3  cmp r14, r10
00007df8f93cfcd6  cmc
00007df8f93cfcd7  lahf
00007df8f93cfcd8  seto al
00007df8f93cfcdb  mov [r15+0x108], eax
00007df8f93cfce2  mov eax, [rsp+0x10]
00007df8f93cfce6  mov r14d, [rsp+0x10]
00007df8f93cfceb  shrd eax, r14d, 0x07
00007df8f93cfcf0  mov [rsp+0x10], r11d
00007df8f93cfcf5  mov r10d, [rsp+0x10]
00007df8f93cfcfa  shrd r11d, r10d, 0x11
00007df8f93cfcff  mov r9d, [r15+0x60]
00007df8f93cfd03  mov r8d, [rsp+0x20]
00007df8f93cfd08  lea ebp, [r8d+r9d*1]
00007df8f93cfd0d  rorx r9d, r14d, 0x12
00007df8f93cfd13  xor eax, r9d
00007df8f93cfd16  rorx r9d, r10d, 0x13
00007df8f93cfd1c  xor r11d, r9d
00007df8f93cfd1f  mov [rsp+0x10], r11d
00007df8f93cfd24  mov r11d, r11d
00007df8f93cfd27  mov [r15+0x88], r11
00007df8f93cfd2e  mov [rsp+0x20], r14d
00007df8f93cfd33  shr r14d, 0x03
00007df8f93cfd37  xor eax, r14d
00007df8f93cfd3a  mov [rsp+0x30], eax
00007df8f93cfd3e  mov eax, eax
00007df8f93cfd40  mov [r15+0x80], rax
00007df8f93cfd47  shr r10d, 0x0A
00007df8f93cfd4b  mov eax, [rsp+0x10]
00007df8f93cfd4f  xor eax, r10d
00007df8f93cfd52  mov [rsp+0x10], eax
00007df8f93cfd56  mov eax, eax
00007df8f93cfd58  mov [r15+0x78], rax
00007df8f93cfd5c  mov eax, [rsp+0x30]
00007df8f93cfd60  lea r14d, [ebp+eax*1]
00007df8f93cfd66  mov eax, [rsp+0x10]
00007df8f93cfd6a  lea r11d, [r14d+eax*1]
00007df8f93cfd6f  lea rax, [r12+0x40]
00007df8f93cfd74  mov [r13+rax*1], r11d
00007df8f93cfd79  mov eax, [rsp+0x20]
00007df8f93cfd7d  mov eax, eax
00007df8f93cfd7f  mov [r15+0x60], rax
00007df8f93cfd83  mov eax, [r15+0x108]
00007df8f93cfd8a  sahf
00007df8f93cfd8b  jnz 0x00007DF8F93CFDBD
00007df8f93cfd8d  cmp dword ptr [r15+0x318], 0x00
00007df8f93cfd95  jz 0x00007DF8F93CFE20
00007df8f93cfd9b  nop [rax+rax*1], ax
00007df8f93cfda4  nop [rax+rax*1], eax
00007df8f93cfdac  mov eax, 0x41049C
00007df8f93cfdb1  mov [r15+0x100], rax
00007df8f93cfdb8  jmp 0x00007DF8F91FE110
00007df8f93cfdbd  cmp dword ptr [r15+0x318], 0x00
00007df8f93cfdc5  jz 0x00007DF8F93CFC70
00007df8f93cfdcb  nop [rax+rax*1], ax
00007df8f93cfdd4  nop [rax+rax*1], eax
00007df8f93cfddc  mov eax, 0x410454
00007df8f93cfde1  mov [r15+0x100], rax
00007df8f93cfde8  jmp 0x00007DF8F91FE110
00007df8f93cfded  int3
00007df8f93cfdee  call 0x00007DF8F92E1430
00007df8f93cfdf3  jmp 0x00007DF8F93CFC92
00007df8f93cfdf8  call 0x00007DF8F92E1430
00007df8f93cfdfd  jmp 0x00007DF8F93CFCA8
00007df8f93cfe02  call 0x00007DF8F92E01C0
00007df8f93cfe07  jmp 0x00007DF8F93CFCB2
00007df8f93cfe0c  call 0x00007DF8F920A860
00007df8f93cfe11  jmp 0x00007DF8F93CFD79
00007df8f93cfe16  int3
00007df8f93cfe17  nop [rax+rax*1], ax
00007df8f93cfe20  mov rax, [r15]
00007df8f93cfe23  mov r14d, [r13+rax*1]
00007df8f93cfe28  lea r12, [rax+0x04]
00007df8f93cfe2c  mov r11d, [r13+r12*1]
00007df8f93cfe31  mov [rsp+0x10], r14d
00007df8f93cfe36  mov r14d, r14d
00007df8f93cfe39  mov [r15+0x78], r14
00007df8f93cfe3d  mov [rsp+0x20], r11d
00007df8f93cfe42  mov r11d, r11d
00007df8f93cfe45  mov [r15+0x80], r11
00007df8f93cfe4c  lea r14, [rax+0x08]
00007df8f93cfe50  mov r12d, [r13+r14*1]
00007df8f93cfe55  lea r14, [rax+0x0C]
00007df8f93cfe59  mov r11d, [r13+r14*1]
00007df8f93cfe5e  mov [rsp+0x30], r12d
00007df8f93cfe63  mov r12d, r12d
00007df8f93cfe66  mov [r15+0x70], r12
00007df8f93cfe6a  mov [rsp+0x40], r11d
00007df8f93cfe6f  mov r11d, r11d
00007df8f93cfe72  mov [r15+0x68], r11
00007df8f93cfe76  lea r14, [rax+0x18]
00007df8f93cfe7a  mov r12d, [r13+r14*1]
00007df8f93cfe7f  lea r14, [rax+0x1C]
00007df8f93cfe83  mov r11d, [r13+r14*1]
00007df8f93cfe88  mov [rsp+0x50], r12d
00007df8f93cfe8d  mov r12d, r12d
00007df8f93cfe90  mov [r15+0x58], r12
00007df8f93cfe94  mov [rsp+0x60], r11d
00007df8f93cfe99  mov r11d, r11d
00007df8f93cfe9c  mov [r15+0x60], r11
00007df8f93cfea0  lea r14, [rax+0x10]
00007df8f93cfea4  mov r12d, [r13+r14*1]
00007df8f93cfea9  lea r14, [rax+0x14]
00007df8f93cfead  mov eax, [r13+r14*1]
00007df8f93cfeb2  mov [rsp+0x70], r12d
00007df8f93cfeb7  mov r12d, r12d
00007df8f93cfeba  mov [r15+0x18], r12
00007df8f93cfebe  mov [rsp+0x80], eax
00007df8f93cfec5  mov eax, eax
00007df8f93cfec7  mov [r15+0x90], rax
00007df8f93cfece  mov eax, [rsp+0x70]
00007df8f93cfed2  mov eax, eax
00007df8f93cfed4  mov [r15+0x30], rax
00007df8f93cfed8  mov eax, [rsp+0x50]
00007df8f93cfedc  mov eax, eax
00007df8f93cfede  mov [r15+0xA0], rax
00007df8f93cfee5  mov eax, [rsp+0x30]
00007df8f93cfee9  mov eax, eax
00007df8f93cfeeb  mov [r15+0x28], rax
00007df8f93cfeef  mov eax, [rsp+0x20]
00007df8f93cfef3  mov eax, eax
00007df8f93cfef5  mov [r15+0x98], rax
00007df8f93cfefc  mov eax, [rsp+0x10]
00007df8f93cff00  mov eax, eax
00007df8f93cff02  mov [r15+0x38], rax
00007df8f93cff06  mov eax, [rsp+0x70]
00007df8f93cff0a  mov r14d, [rsp+0x70]
00007df8f93cff0f  shrd eax, r14d, 0x06
00007df8f93cff14  mov [rsp+0x70], r14d
00007df8f93cff19  mov r12d, [rsp+0x80]
00007df8f93cff21  and r14d, r12d
00007df8f93cff24  mov r11d, [rsp+0x10]
00007df8f93cff29  mov r10d, [rsp+0x10]
00007df8f93cff2e  shrd r11d, r10d, 0x02
00007df8f93cff33  mov [rsp+0x10], r12d
00007df8f93cff38  mov r12d, r12d
00007df8f93cff3b  mov [r15+0x20], r12
00007df8f93cff3f  mov r12, [r15+0x50]
00007df8f93cff43  mov r9d, [r13+r12*1]
00007df8f93cff48  mov r12d, [rsp+0x50]
00007df8f93cff4d  mov r8d, [rsp+0x70]
00007df8f93cff52  andn ebp, r8d, r12d
00007df8f93cff57  mov edi, [rsp+0x60]
00007df8f93cff5b  lea esi, [r14d+edi*1]
00007df8f93cff60  rorx r14d, r8d, 0x0B
00007df8f93cff66  xor eax, r14d
00007df8f93cff69  rorx r14d, r10d, 0x0D
00007df8f93cff6f  xor r11d, r14d
00007df8f93cff72  lea edi, [esi+ebp*1]
00007df8f93cff76  mov r14, [r15+0x48]
00007df8f93cff7a  mov ebp, [r13+r14*1]
00007df8f93cff7f  mov r14d, [rsp+0x30]
00007df8f93cff84  mov esi, [rsp+0x20]
00007df8f93cff88  and r14d, esi
00007df8f93cff8b  mov [rsp+0x20], r14d
00007df8f93cff90  mov r14d, r14d
00007df8f93cff93  mov [r15+0xD8], r14
00007df8f93cff9a  lea r14d, [edi+r9d*1]
00007df8f93cff9f  mov r9d, [rsp+0x30]
00007df8f93cffa4  xor r9d, esi
00007df8f93cffa7  rorx edi, r8d, 0x19
00007df8f93cffad  xor eax, edi
00007df8f93cffaf  and r9d, r10d
00007df8f93cffb2  rorx edi, r10d, 0x16
00007df8f93cffb8  xor r11d, edi
00007df8f93cffbb  mov [rsp+0x30], r11d
00007df8f93cffc0  mov r11d, r11d
00007df8f93cffc3  mov [r15+0xD0], r11
00007df8f93cffca  lea r11d, [r14d+ebp*1]
00007df8f93cffcf  mov r10d, [rsp+0x20]
00007df8f93cffd4  xor r9d, r10d
00007df8f93cffd7  lea r14d, [r11d+eax*1]
00007df8f93cffdc  mov qword ptr [r15+0x88], 0x04
00007df8f93cffe7  mov eax, [rsp+0x30]
00007df8f93cffeb  lea r11d, [r9d+eax*1]
00007df8f93cfff0  mov eax, [rsp+0x40]
00007df8f93cfff4  lea r10d, [r14d+eax*1]
00007df8f93cfff9  mov r10d, r10d
00007df8f93cfffc  mov [r15+0xB8], r10
00007df8f93d0003  xor eax, eax
00007df8f93d0005  mov r10d, 0x04
00007df8f93d000b  mov r9d, 0x100
00007df8f93d0011  cmp r10, r9
00007df8f93d0014  cmc
00007df8f93d0015  lahf
00007df8f93d0016  seto al
00007df8f93d0019  mov [r15+0x108], eax
00007df8f93d0020  lea eax, [r11d+r14d*1]
00007df8f93d0025  mov eax, eax
00007df8f93d0027  mov [r15+0xA8], rax
00007df8f93d002e  mov r12d, r12d
00007df8f93d0031  mov [r15+0xB0], r12
00007df8f93d0038  mov eax, [rsp+0x10]
00007df8f93d003c  mov eax, eax
00007df8f93d003e  mov [r15+0xC0], rax
00007df8f93d0045  mov r8d, r8d
00007df8f93d0048  mov [r15+0xC8], r8
00007df8f93d004f  mov eax, [r15+0x108]
00007df8f93d0056  sahf
00007df8f93d0057  jnz 0x00007DF8F93D0089
00007df8f93d0059  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0061  jz 0x00007DF8F93D0350
00007df8f93d0067  nop [rax+rax*1], ax
00007df8f93d0070  nop [rax+rax*1], eax
00007df8f93d0078  mov eax, 0x41055C
00007df8f93d007d  mov [r15+0x100], rax
00007df8f93d0084  jmp 0x00007DF8F91FE110
00007df8f93d0089  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0091  jz 0x00007DF8F93D0120
00007df8f93d0097  nop [rax+rax*1], ax
00007df8f93d00a0  nop [rax+rax*1], eax
00007df8f93d00a8  mov eax, 0x4104D0
00007df8f93d00ad  mov [r15+0x100], rax
00007df8f93d00b4  jmp 0x00007DF8F91FE110
00007df8f93d00b9  int3
00007df8f93d00ba  call 0x00007DF8F920DAE0
00007df8f93d00bf  jmp 0x00007DF8F93CFE28
00007df8f93d00c4  call 0x00007DF8F92C0230
00007df8f93d00c9  jmp 0x00007DF8F93CFE31
00007df8f93d00ce  call 0x00007DF8F92E26A0
00007df8f93d00d3  jmp 0x00007DF8F93CFE55
00007df8f93d00d8  call 0x00007DF8F92E1430
00007df8f93d00dd  jmp 0x00007DF8F93CFE5E
00007df8f93d00e2  call 0x00007DF8F92E26A0
00007df8f93d00e7  jmp 0x00007DF8F93CFE7F
00007df8f93d00ec  call 0x00007DF8F92E1430
00007df8f93d00f1  jmp 0x00007DF8F93CFE88
00007df8f93d00f6  call 0x00007DF8F92E26A0
00007df8f93d00fb  jmp 0x00007DF8F93CFEA9
00007df8f93d0100  call 0x00007DF8F92D5890
00007df8f93d0105  jmp 0x00007DF8F93CFEB2
00007df8f93d010a  call 0x00007DF8F92BDD50
00007df8f93d010f  jmp 0x00007DF8F93CFF48
00007df8f93d0114  call 0x00007DF8F92DA580
00007df8f93d0119  jmp 0x00007DF8F93CFF7F
00007df8f93d011e  int3
00007df8f93d011f  nop
00007df8f93d0120  mov eax, [r15+0xB8]
00007df8f93d0127  mov [rsp+0x10], eax
00007df8f93d012b  mov eax, eax
00007df8f93d012d  mov [r15+0x30], rax
00007df8f93d0131  mov eax, [r15+0xC0]
00007df8f93d0138  mov [rsp+0x20], eax
00007df8f93d013c  mov eax, eax
00007df8f93d013e  mov [r15+0xA0], rax
00007df8f93d0145  mov eax, [r15+0x28]
00007df8f93d0149  mov r14d, [r15+0x98]
00007df8f93d0150  mov [rsp+0x30], r14d
00007df8f93d0155  mov r14d, r14d
00007df8f93d0158  mov [r15+0x28], r14
00007df8f93d015c  mov r14d, [r15+0x38]
00007df8f93d0160  mov [rsp+0x40], r14d
00007df8f93d0165  mov r14d, r14d
00007df8f93d0168  mov [r15+0x98], r14
00007df8f93d016f  mov r14d, [r15+0xA8]
00007df8f93d0176  mov [rsp+0x50], r14d
00007df8f93d017b  mov r14d, r14d
00007df8f93d017e  mov [r15+0x38], r14
00007df8f93d0182  mov r14d, [rsp+0x10]
00007df8f93d0187  mov r12d, [rsp+0x10]
00007df8f93d018c  shrd r14d, r12d, 0x06
00007df8f93d0191  mov r11d, [r15+0xC8]
00007df8f93d0198  mov [rsp+0x10], r12d
00007df8f93d019d  and r12d, r11d
00007df8f93d01a0  mov r10d, [rsp+0x50]
00007df8f93d01a5  mov r9d, [rsp+0x50]
00007df8f93d01aa  shrd r10d, r9d, 0x02
00007df8f93d01af  mov [rsp+0x50], r11d
00007df8f93d01b4  mov r11d, r11d
00007df8f93d01b7  mov [r15+0x20], r11
00007df8f93d01bb  mov r11, [r15+0x88]
00007df8f93d01c2  mov r8, [r15+0x50]
00007df8f93d01c6  lea rbp, [r8+r11*1]
00007df8f93d01ca  mov r8d, [r13+rbp*1]
00007df8f93d01cf  mov ebp, [rsp+0x20]
00007df8f93d01d3  mov edi, [rsp+0x10]
00007df8f93d01d7  andn esi, edi, ebp
00007df8f93d01dc  mov edx, [r15+0xB0]
00007df8f93d01e3  lea ecx, [r12d+edx*1]
00007df8f93d01e8  rorx r12d, edi, 0x0B
00007df8f93d01ee  xor r14d, r12d
00007df8f93d01f1  rorx r12d, r9d, 0x0D
00007df8f93d01f7  xor r10d, r12d
00007df8f93d01fa  lea r12d, [ecx+esi*1]
00007df8f93d01ff  mov rsi, [r15+0x48]
00007df8f93d0203  lea rdx, [rsi+r11*1]
00007df8f93d0207  mov esi, [r13+rdx*1]
00007df8f93d020c  mov edx, [rsp+0x30]
00007df8f93d0210  mov ecx, [rsp+0x40]
00007df8f93d0214  and edx, ecx
00007df8f93d0216  mov [rsp+0x10], edx
00007df8f93d021a  mov edx, edx
00007df8f93d021c  mov [r15+0xD8], rdx
00007df8f93d0223  lea edx, [r12d+r8d*1]
00007df8f93d0228  mov r12d, [rsp+0x30]
00007df8f93d022d  xor r12d, ecx
00007df8f93d0230  rorx r8d, edi, 0x19
00007df8f93d0236  xor r14d, r8d
00007df8f93d0239  and r12d, r9d
00007df8f93d023c  rorx r8d, r9d, 0x16
00007df8f93d0242  xor r10d, r8d
00007df8f93d0245  mov [rsp+0x20], r10d
00007df8f93d024a  mov r10d, r10d
00007df8f93d024d  mov [r15+0xD0], r10
00007df8f93d0254  lea r10d, [edx+esi*1]
00007df8f93d0259  mov r9d, [rsp+0x10]
00007df8f93d025e  xor r12d, r9d
00007df8f93d0261  lea r9d, [r10d+r14d*1]
00007df8f93d0266  lea r14, [r11+0x04]
00007df8f93d026a  mov [r15+0x88], r14
00007df8f93d0271  mov r11d, [rsp+0x20]
00007df8f93d0276  lea r10d, [r12d+r11d*1]
00007df8f93d027b  lea r11d, [r9d+eax*1]
00007df8f93d0280  mov r11d, r11d
00007df8f93d0283  mov [r15+0xB8], r11
00007df8f93d028a  xor eax, eax
00007df8f93d028c  mov r12d, 0x100
00007df8f93d0292  cmp r14, r12
00007df8f93d0295  cmc
00007df8f93d0296  lahf
00007df8f93d0297  seto al
00007df8f93d029a  mov [r15+0x108], eax
00007df8f93d02a1  lea eax, [r10d+r9d*1]
00007df8f93d02a6  mov eax, eax
00007df8f93d02a8  mov [r15+0xA8], rax
00007df8f93d02af  mov ebp, ebp
00007df8f93d02b1  mov [r15+0xB0], rbp
00007df8f93d02b8  mov eax, [rsp+0x50]
00007df8f93d02bc  mov eax, eax
00007df8f93d02be  mov [r15+0xC0], rax
00007df8f93d02c5  mov edi, edi
00007df8f93d02c7  mov [r15+0xC8], rdi
00007df8f93d02ce  mov eax, [r15+0x108]
00007df8f93d02d5  sahf
00007df8f93d02d6  jnz 0x00007DF8F93D0308
00007df8f93d02d8  cmp dword ptr [r15+0x318], 0x00
00007df8f93d02e0  jz 0x00007DF8F93D0350
00007df8f93d02e6  nop [rax+rax*1], ax
00007df8f93d02ef  nop [rax+rax*1], eax
00007df8f93d02f7  mov eax, 0x41055C
00007df8f93d02fc  mov [r15+0x100], rax
00007df8f93d0303  jmp 0x00007DF8F91FE110
00007df8f93d0308  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0310  jz 0x00007DF8F93D0120
00007df8f93d0316  nop [rax+rax*1], ax
00007df8f93d031f  nop [rax+rax*1], eax
00007df8f93d0327  mov eax, 0x4104D0
00007df8f93d032c  mov [r15+0x100], rax
00007df8f93d0333  jmp 0x00007DF8F91FE110
00007df8f93d0338  int3
00007df8f93d0339  call 0x00007DF8F9249010
00007df8f93d033e  jmp 0x00007DF8F93D01CF
00007df8f93d0343  call 0x00007DF8F9225930
00007df8f93d0348  jmp 0x00007DF8F93D020C
00007df8f93d034d  int3
00007df8f93d034e  nop
00007df8f93d0350  mov eax, [r15+0x98]
00007df8f93d0357  mov r14d, [r15+0x70]
00007df8f93d035b  lea r12d, [eax+r14d*1]
00007df8f93d0360  mov eax, [r15+0x28]
00007df8f93d0364  mov r14d, [r15+0x68]
00007df8f93d0368  lea r11d, [eax+r14d*1]
00007df8f93d036d  mov qword ptr [r15+0x88], 0x00
00007df8f93d0378  mov eax, [r15+0xA8]
00007df8f93d037f  mov r14d, [r15+0x78]
00007df8f93d0383  lea r10d, [eax+r14d*1]
00007df8f93d0388  mov [rsp+0x10], r10d
00007df8f93d038d  mov r10d, r10d
00007df8f93d0390  mov [r15+0x78], r10
00007df8f93d0394  mov eax, [r15+0x38]
00007df8f93d0398  mov r14d, [r15+0x80]
00007df8f93d039f  lea r10d, [eax+r14d*1]
00007df8f93d03a4  mov [rsp+0x20], r10d
00007df8f93d03a9  mov r10d, r10d
00007df8f93d03ac  mov [r15+0x80], r10
00007df8f93d03b3  mov rax, [r15]
00007df8f93d03b6  lea r14, [rax+0x08]
00007df8f93d03ba  mov [r13+r14*1], r12d
00007df8f93d03bf  lea r14, [rax+0x0C]
00007df8f93d03c3  mov [r13+r14*1], r11d
00007df8f93d03c8  mov r14d, [r15+0xB8]
00007df8f93d03cf  mov r12d, [r15+0x18]
00007df8f93d03d3  lea r11d, [r14d+r12d*1]
00007df8f93d03d8  mov [rsp+0x30], r11d
00007df8f93d03dd  mov r11d, r11d
00007df8f93d03e0  mov [r15+0x68], r11
00007df8f93d03e4  mov r14d, [r15+0x30]
00007df8f93d03e8  mov r12d, [r15+0x90]
00007df8f93d03ef  lea r11d, [r14d+r12d*1]
00007df8f93d03f4  mov [rsp+0x40], r11d
00007df8f93d03f9  mov r11d, r11d
00007df8f93d03fc  mov [r15+0x70], r11
00007df8f93d0400  mov r14d, [r15+0x20]
00007df8f93d0404  mov r12d, [r15+0x58]
00007df8f93d0408  lea r11d, [r14d+r12d*1]
00007df8f93d040d  mov [rsp+0x50], r11d
00007df8f93d0412  mov r11d, r11d
00007df8f93d0415  mov [r15+0x58], r11
00007df8f93d0419  mov r14d, [r15+0xA0]
00007df8f93d0420  mov r12d, [r15+0x60]
00007df8f93d0424  lea r11d, [r14d+r12d*1]
00007df8f93d0429  mov [rsp+0x60], r11d
00007df8f93d042e  mov r11d, r11d
00007df8f93d0431  mov [r15+0x60], r11
00007df8f93d0435  mov r14d, [rsp+0x10]
00007df8f93d043a  mov [r13+rax*1], r14d
00007df8f93d043f  lea r14, [rax+0x04]
00007df8f93d0443  mov r12d, [rsp+0x20]
00007df8f93d0448  mov [r13+r14*1], r12d
00007df8f93d044d  lea r14, [rax+0x10]
00007df8f93d0451  mov r12d, [rsp+0x30]
00007df8f93d0456  mov [r13+r14*1], r12d
00007df8f93d045b  lea r14, [rax+0x14]
00007df8f93d045f  mov r12d, [rsp+0x40]
00007df8f93d0464  mov [r13+r14*1], r12d
00007df8f93d0469  lea r14, [rax+0x18]
00007df8f93d046d  mov r12d, [rsp+0x50]
00007df8f93d0472  mov [r13+r14*1], r12d
00007df8f93d0477  lea r14, [rax+0x1C]
00007df8f93d047b  mov r12d, [rsp+0x60]
00007df8f93d0480  mov [r13+r14*1], r12d
00007df8f93d0485  lea r14, [rax+0x68]
00007df8f93d0489  xor eax, eax
00007df8f93d048b  mov [r13+r14*1], rax
00007df8f93d0490  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0498  jz 0x00007DF8F93CEF90
00007df8f93d049e  nop [rax+rax*1], ax
00007df8f93d04a7  nop [rax+rax*1], eax
00007df8f93d04af  mov eax, 0x410378
00007df8f93d04b4  mov [r15+0x100], rax
00007df8f93d04bb  jmp 0x00007DF8F91FE110
00007df8f93d04c0  int3
00007df8f93d04c1  call 0x00007DF8F92E2BA0
00007df8f93d04c6  jmp 0x00007DF8F93D03BF
00007df8f93d04cb  call 0x00007DF8F92E1920
00007df8f93d04d0  jmp 0x00007DF8F93D03C8
00007df8f93d04d5  call 0x00007DF8F920DFE0
00007df8f93d04da  jmp 0x00007DF8F93D043F
00007df8f93d04df  call 0x00007DF8F92E2BA0
00007df8f93d04e4  jmp 0x00007DF8F93D044D
00007df8f93d04e9  call 0x00007DF8F92E2BA0
00007df8f93d04ee  jmp 0x00007DF8F93D045B
00007df8f93d04f3  call 0x00007DF8F92E2BA0
00007df8f93d04f8  jmp 0x00007DF8F93D0469
00007df8f93d04fd  call 0x00007DF8F92E2BA0
00007df8f93d0502  jmp 0x00007DF8F93D0477
00007df8f93d0507  call 0x00007DF8F92E2BA0
00007df8f93d050c  jmp 0x00007DF8F93D0485
00007df8f93d0511  call 0x00007DF8F92D5EB0
00007df8f93d0516  jmp 0x00007DF8F93D0490
00007df8f93d051b  int3
00007df8f93d051c  nop [rax], eax
00007df8f93d0520  mov rax, [r15+0xF8]
00007df8f93d0527  lea r14, [rax+0x140]
00007df8f93d052e  mov r12, [r13+r14*1]
00007df8f93d0533  lea r14, [rax+0x148]
00007df8f93d053a  mov r11, [r13+r14*1]
00007df8f93d053f  mov [r15+0xA0], r12
00007df8f93d0546  mov [r15+0x98], r11
00007df8f93d054d  lea r14, [rax+0x130]
00007df8f93d0554  mov r12, [r13+r14*1]
00007df8f93d0559  lea r14, [rax+0x138]
00007df8f93d0560  mov r11, [r13+r14*1]
00007df8f93d0565  mov [r15+0xB0], r12
00007df8f93d056c  mov [r15+0xA8], r11
00007df8f93d0573  lea r14, [rax+0x120]
00007df8f93d057a  mov r12, [r13+r14*1]
00007df8f93d057f  lea r14, [rax+0x128]
00007df8f93d0586  mov r11, [r13+r14*1]
00007df8f93d058b  mov [r15+0xC0], r12
00007df8f93d0592  mov [r15+0xB8], r11
00007df8f93d0599  lea r14, [rax+0x110]
00007df8f93d05a0  mov r12, [r13+r14*1]
00007df8f93d05a5  lea r14, [rax+0x118]
00007df8f93d05ac  mov r11, [r13+r14*1]
00007df8f93d05b1  mov [r15+0xD0], r12
00007df8f93d05b8  mov [r15+0xC8], r11
00007df8f93d05bf  lea r14, [rax+0x100]
00007df8f93d05c6  mov r12, [r13+r14*1]
00007df8f93d05cb  lea r14, [rax+0x108]
00007df8f93d05d2  mov r11, [r13+r14*1]
00007df8f93d05d7  mov [r15+0xE8], r12
00007df8f93d05de  mov [r15+0xD8], r11
00007df8f93d05e5  lea r14, [rax+0x150]
00007df8f93d05ec  mov [r15+0xF8], r14
00007df8f93d05f3  mov rax, [r15+0xF0]
00007df8f93d05fa  mov [r15+0x100], rax
00007df8f93d0601  jmp 0x00007DF8F93CE5C0
00007df8f93d0606  int3
00007df8f93d0607  call 0x00007DF8F92E27E0
00007df8f93d060c  jmp 0x00007DF8F93D0533
00007df8f93d0611  call 0x00007DF8F92E1570
00007df8f93d0616  jmp 0x00007DF8F93D053F
00007df8f93d061b  call 0x00007DF8F92E27E0
00007df8f93d0620  jmp 0x00007DF8F93D0559
00007df8f93d0625  call 0x00007DF8F92E1570
00007df8f93d062a  jmp 0x00007DF8F93D0565
00007df8f93d062f  call 0x00007DF8F92E27E0
00007df8f93d0634  jmp 0x00007DF8F93D057F
00007df8f93d0639  call 0x00007DF8F92E1570
00007df8f93d063e  jmp 0x00007DF8F93D058B
00007df8f93d0643  call 0x00007DF8F92E27E0
00007df8f93d0648  jmp 0x00007DF8F93D05A5
00007df8f93d064d  call 0x00007DF8F92E1570
00007df8f93d0652  jmp 0x00007DF8F93D05B1
00007df8f93d0657  call 0x00007DF8F92E27E0
00007df8f93d065c  jmp 0x00007DF8F93D05CB
00007df8f93d0661  call 0x00007DF8F92E1570
00007df8f93d0666  jmp 0x00007DF8F93D05D7
00007df8f93d066b  int3
00007df8f93d066c  nop [rax], eax
00007df8f93d0670  mov eax, [r15+0xA0]
00007df8f93d0677  mov [rsp+0x10], eax
00007df8f93d067b  xor eax, eax
00007df8f93d067d  mov r14d, [rsp+0x10]
00007df8f93d0682  sub r14d, 0x01
00007df8f93d0686  cmc
00007df8f93d0687  lahf
00007df8f93d0688  seto al
00007df8f93d068b  mov [r15+0x108], eax
00007df8f93d0692  mov r14d, r14d
00007df8f93d0695  mov [r15+0xA0], r14
00007df8f93d069c  mov eax, [r15+0x108]
00007df8f93d06a3  sahf
00007df8f93d06a4  jnz 0x00007DF8F93D06D6
00007df8f93d06a6  cmp dword ptr [r15+0x318], 0x00
00007df8f93d06ae  jz 0x00007DF8F93D07A0
00007df8f93d06b4  nop [rax+rax*1], ax
00007df8f93d06bd  nop [rax+rax*1], eax
00007df8f93d06c5  mov eax, 0x41027C
00007df8f93d06ca  mov [r15+0x100], rax
00007df8f93d06d1  jmp 0x00007DF8F91FE110
00007df8f93d06d6  cmp dword ptr [r15+0x318], 0x00
00007df8f93d06de  jz 0x00007DF8F93D0710
00007df8f93d06e4  nop [rax+rax*1], ax
00007df8f93d06ed  nop [rax+rax*1], eax
00007df8f93d06f5  mov eax, 0x410264
00007df8f93d06fa  mov [r15+0x100], rax
00007df8f93d0701  jmp 0x00007DF8F91FE110
00007df8f93d0706  int3
00007df8f93d0707  int3
00007df8f93d0708  nop [rax+rax*1], eax
00007df8f93d0710  mov rax, [r15+0xF8]
00007df8f93d0717  mov [r15], rax
00007df8f93d071a  mov rax, [r15+0x98]
00007df8f93d0721  mov [r15+0x08], rax
00007df8f93d0725  mov qword ptr [r15+0x10], 0x12C
00007df8f93d072d  mov qword ptr [r15+0xF0], 0x410274
00007df8f93d0738  mov r14d, [r15+0x320]
00007df8f93d073f  mov eax, 0x410274
00007df8f93d0744  mov rcx, 0x7DF8F93D0670
00007df8f93d074e  mov [r15+r14*8+0x328], rax
00007df8f93d0756  mov [r15+r14*8+0x368], rcx
00007df8f93d075e  add r14d, 0x01
00007df8f93d0762  and r14d, 0x07
00007df8f93d0766  mov [r15+0x320], r14d
00007df8f93d076d  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0775  jz 0x00007DF8F93CEC20
00007df8f93d077b  nop [rax+rax*1], ax
00007df8f93d0784  nop [rax+rax*1], eax
00007df8f93d078c  mov eax, 0x410338
00007df8f93d0791  mov [r15+0x100], rax
00007df8f93d0798  jmp 0x00007DF8F91FE110
00007df8f93d079d  int3
00007df8f93d079e  int3
00007df8f93d079f  nop
00007df8f93d07a0  mov rax, [r15+0xF8]
00007df8f93d07a7  lea r14, [rax+0x20]
00007df8f93d07ab  mov r12, [r13+r14*1]
00007df8f93d07b0  mov [r15+0x98], r12
00007df8f93d07b7  mov qword ptr [r15+0x40], 0x80
00007df8f93d07bf  mov [r15], rax
00007df8f93d07c2  lea r14, [rax+0x8C]
00007df8f93d07c9  mov [r15+0x08], r14
00007df8f93d07cd  mov qword ptr [r15+0x10], 0x01
00007df8f93d07d5  lea r14, [rax+0x8C]
00007df8f93d07dc  mov eax, 0x80
00007df8f93d07e1  mov [r13+r14*1], al
00007df8f93d07e6  mov qword ptr [r15+0xF0], 0x410298
00007df8f93d07f1  mov r14d, [r15+0x320]
00007df8f93d07f8  mov eax, 0x410298
00007df8f93d07fd  mov rcx, 0x7DF8F93D0870
00007df8f93d0807  mov [r15+r14*8+0x328], rax
00007df8f93d080f  mov [r15+r14*8+0x368], rcx
00007df8f93d0817  add r14d, 0x01
00007df8f93d081b  and r14d, 0x07
00007df8f93d081f  mov [r15+0x320], r14d
00007df8f93d0826  cmp dword ptr [r15+0x318], 0x00
00007df8f93d082e  jz 0x00007DF8F93CEC20
00007df8f93d0834  nop [rax+rax*1], ax
00007df8f93d083d  nop [rax+rax*1], eax
00007df8f93d0845  mov eax, 0x410338
00007df8f93d084a  mov [r15+0x100], rax
00007df8f93d0851  jmp 0x00007DF8F91FE110
00007df8f93d0856  int3
00007df8f93d0857  call 0x00007DF8F92E27E0
00007df8f93d085c  jmp 0x00007DF8F93D07B0
00007df8f93d0861  call 0x00007DF8F92D5AF0
00007df8f93d0866  jmp 0x00007DF8F93D07E6
00007df8f93d086b  int3
00007df8f93d086c  nop [rax], eax
00007df8f93d0870  mov rax, [r15+0xF8]
00007df8f93d0877  lea r14, [rax+0x68]
00007df8f93d087b  mov r12, [r13+r14*1]
00007df8f93d0880  mov [r15+0x40], r12
00007df8f93d0884  lea r14, [rax+0x88]
00007df8f93d088b  xor eax, eax
00007df8f93d088d  mov [r13+r14*1], al
00007df8f93d0892  xor eax, eax
00007df8f93d0894  mov r14d, 0x38
00007df8f93d089a  cmp r12, r14
00007df8f93d089d  cmc
00007df8f93d089e  lahf
00007df8f93d089f  seto al
00007df8f93d08a2  mov [r15+0x108], eax
00007df8f93d08a9  mov eax, [r15+0x108]
00007df8f93d08b0  sahf
00007df8f93d08b1  jz 0x00007DF8F93D08E3
00007df8f93d08b3  cmp dword ptr [r15+0x318], 0x00
00007df8f93d08bb  jz 0x00007DF8F93D0930
00007df8f93d08c1  nop [rax+rax*1], ax
00007df8f93d08ca  nop [rax+rax*1], eax
00007df8f93d08d2  mov eax, 0x4102A8
00007df8f93d08d7  mov [r15+0x100], rax
00007df8f93d08de  jmp 0x00007DF8F91FE110
00007df8f93d08e3  cmp dword ptr [r15+0x318], 0x00
00007df8f93d08eb  jz 0x00007DF8F93D0A70
00007df8f93d08f1  nop [rax+rax*1], ax
00007df8f93d08fa  nop [rax+rax*1], eax
00007df8f93d0902  mov eax, 0x4102C4
00007df8f93d0907  mov [r15+0x100], rax
00007df8f93d090e  jmp 0x00007DF8F91FE110
00007df8f93d0913  int3
00007df8f93d0914  call 0x00007DF8F92E27E0
00007df8f93d0919  jmp 0x00007DF8F93D0880
00007df8f93d091e  call 0x00007DF8F92D5AF0
00007df8f93d0923  jmp 0x00007DF8F93D0892
00007df8f93d0928  int3
00007df8f93d0929  nop [rax], eax
00007df8f93d0930  mov rax, [r15+0xF8]
00007df8f93d0937  mov [r15], rax
00007df8f93d093a  lea r14, [rax+0x88]
00007df8f93d0941  mov [r15+0x08], r14
00007df8f93d0945  mov qword ptr [r15+0x10], 0x01
00007df8f93d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007df8f93d0958  mov r14d, [r15+0x320]
00007df8f93d095f  mov eax, 0x4102B8
00007df8f93d0964  mov rcx, 0x7DF8F93D09C0
00007df8f93d096e  mov [r15+r14*8+0x328], rax
00007df8f93d0976  mov [r15+r14*8+0x368], rcx
00007df8f93d097e  add r14d, 0x01
00007df8f93d0982  and r14d, 0x07
00007df8f93d0986  mov [r15+0x320], r14d
00007df8f93d098d  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0995  jz 0x00007DF8F93CEC20
00007df8f93d099b  nop [rax+rax*1], ax
00007df8f93d09a4  nop [rax+rax*1], eax
00007df8f93d09ac  mov eax, 0x410338
00007df8f93d09b1  mov [r15+0x100], rax
00007df8f93d09b8  jmp 0x00007DF8F91FE110
00007df8f93d09bd  int3
00007df8f93d09be  int3
00007df8f93d09bf  nop
00007df8f93d09c0  mov rax, [r15+0xF8]
00007df8f93d09c7  lea r14, [rax+0x68]
00007df8f93d09cb  mov rax, [r13+r14*1]
00007df8f93d09d0  mov [r15+0x40], rax
00007df8f93d09d4  mov [rsp+0x10], rax
00007df8f93d09d9  xor eax, eax
00007df8f93d09db  mov r14, [rsp+0x10]
00007df8f93d09e0  mov r12d, 0x38
00007df8f93d09e6  cmp r14, r12
00007df8f93d09e9  cmc
00007df8f93d09ea  lahf
00007df8f93d09eb  seto al
00007df8f93d09ee  mov [r15+0x108], eax
00007df8f93d09f5  mov eax, [r15+0x108]
00007df8f93d09fc  sahf
00007df8f93d09fd  jnz 0x00007DF8F93D0A2F
00007df8f93d09ff  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0a07  jz 0x00007DF8F93D0A70
00007df8f93d0a0d  nop [rax+rax*1], ax
00007df8f93d0a16  nop [rax+rax*1], eax
00007df8f93d0a1e  mov eax, 0x4102C4
00007df8f93d0a23  mov [r15+0x100], rax
00007df8f93d0a2a  jmp 0x00007DF8F91FE110
00007df8f93d0a2f  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0a37  jz 0x00007DF8F93D0930
00007df8f93d0a3d  nop [rax+rax*1], ax
00007df8f93d0a46  nop [rax+rax*1], eax
00007df8f93d0a4e  mov eax, 0x4102A8
00007df8f93d0a53  mov [r15+0x100], rax
00007df8f93d0a5a  jmp 0x00007DF8F91FE110
00007df8f93d0a5f  int3
00007df8f93d0a60  call 0x00007DF8F92D59C0
00007df8f93d0a65  jmp 0x00007DF8F93D09D0
00007df8f93d0a6a  int3
00007df8f93d0a6b  nop [rax+rax*1], eax
00007df8f93d0a70  mov rax, [r15+0x98]
00007df8f93d0a77  rorx r14, rax, 0x3D
00007df8f93d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007df8f93d0a81  mov rax, [r15+0xF8]
00007df8f93d0a88  mov [r15], rax
00007df8f93d0a8b  lea r12, [rax+0x78]
00007df8f93d0a8f  mov [r15+0x08], r12
00007df8f93d0a93  mov qword ptr [r15+0x10], 0x08
00007df8f93d0a9b  bswap r14
00007df8f93d0a9e  mov [r15+0x40], r14
00007df8f93d0aa2  lea r12, [rax+0x78]
00007df8f93d0aa6  mov [r13+r12*1], r14
00007df8f93d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007df8f93d0ab6  mov r14d, [r15+0x320]
00007df8f93d0abd  mov eax, 0x4102E0
00007df8f93d0ac2  mov rcx, 0x7DF8F93D0B30
00007df8f93d0acc  mov [r15+r14*8+0x328], rax
00007df8f93d0ad4  mov [r15+r14*8+0x368], rcx
00007df8f93d0adc  add r14d, 0x01
00007df8f93d0ae0  and r14d, 0x07
00007df8f93d0ae4  mov [r15+0x320], r14d
00007df8f93d0aeb  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0af3  jz 0x00007DF8F93CEC20
00007df8f93d0af9  nop [rax+rax*1], ax
00007df8f93d0b02  nop [rax+rax*1], eax
00007df8f93d0b0a  mov eax, 0x410338
00007df8f93d0b0f  mov [r15+0x100], rax
00007df8f93d0b16  jmp 0x00007DF8F91FE110
00007df8f93d0b1b  int3
00007df8f93d0b1c  call 0x00007DF8F92C3FE0
00007df8f93d0b21  jmp 0x00007DF8F93D0AAB
00007df8f93d0b26  int3
00007df8f93d0b27  nop [rax+rax*1], ax
00007df8f93d0b30  mov rax, [r15+0xF8]
00007df8f93d0b37  mov r14d, [r13+rax*1]
00007df8f93d0b3c  lea r12, [rax+0x04]
00007df8f93d0b40  mov r11d, [r13+r12*1]
00007df8f93d0b45  lea r12, [rax+0x08]
00007df8f93d0b49  mov r10d, [r13+r12*1]
00007df8f93d0b4e  lea r12, [rax+0x0C]
00007df8f93d0b52  mov r9d, [r13+r12*1]
00007df8f93d0b57  mov qword ptr [r15+0x48], 0x430860
00007df8f93d0b5f  lea r12, [rax+0x80]
00007df8f93d0b66  mov r8, [r13+r12*1]
00007df8f93d0b6b  mov [r15+0xF0], r8
00007df8f93d0b72  bswap r14d
00007df8f93d0b75  bswap r11d
00007df8f93d0b78  mov r12d, 0x430860
00007df8f93d0b7e  mov [r13+r12*1], r14d
00007df8f93d0b83  mov r14d, 0x430864
00007df8f93d0b89  mov [r13+r14*1], r11d
00007df8f93d0b8e  bswap r10d
00007df8f93d0b91  bswap r9d
00007df8f93d0b94  lea r14, [rax+0x10]
00007df8f93d0b98  mov r12d, [r13+r14*1]
00007df8f93d0b9d  lea r14, [rax+0x14]
00007df8f93d0ba1  mov r11d, [r13+r14*1]
00007df8f93d0ba6  mov r14d, 0x430868
00007df8f93d0bac  mov [r13+r14*1], r10d
00007df8f93d0bb1  mov r14d, 0x43086C
00007df8f93d0bb7  mov [r13+r14*1], r9d
00007df8f93d0bbc  lea r14, [rax+0x90]
00007df8f93d0bc3  mov r10, [r13+r14*1]
00007df8f93d0bc8  lea r14, [rax+0x98]
00007df8f93d0bcf  mov r9, [r13+r14*1]
00007df8f93d0bd4  mov [r15+0xA0], r10
00007df8f93d0bdb  mov [r15+0x98], r9
00007df8f93d0be2  bswap r12d
00007df8f93d0be5  bswap r11d
00007df8f93d0be8  mov [rsp+0x10], r11d
00007df8f93d0bed  mov r11d, r11d
00007df8f93d0bf0  mov [r15+0x58], r11
00007df8f93d0bf4  lea r14, [rax+0x18]
00007df8f93d0bf8  mov r11d, [r13+r14*1]
00007df8f93d0bfd  lea r14, [rax+0x1C]
00007df8f93d0c01  mov r10d, [r13+r14*1]
00007df8f93d0c06  mov [rsp+0x20], r10d
00007df8f93d0c0b  mov r10d, r10d
00007df8f93d0c0e  mov [r15+0x60], r10
00007df8f93d0c12  mov r14d, 0x430870
00007df8f93d0c18  mov [r13+r14*1], r12d
00007df8f93d0c1d  mov r14d, 0x430874
00007df8f93d0c23  mov r12d, [rsp+0x10]
00007df8f93d0c28  mov [r13+r14*1], r12d
00007df8f93d0c2d  bswap r11d
00007df8f93d0c30  mov [rsp+0x10], r11d
00007df8f93d0c35  mov r11d, r11d
00007df8f93d0c38  mov [r15+0x40], r11
00007df8f93d0c3c  mov r14d, [rsp+0x20]
00007df8f93d0c41  bswap r14d
00007df8f93d0c44  mov [rsp+0x20], r14d
00007df8f93d0c49  mov r14d, r14d
00007df8f93d0c4c  mov [r15+0x50], r14
00007df8f93d0c50  mov r14d, 0x430878
00007df8f93d0c56  mov r12d, [rsp+0x10]
00007df8f93d0c5b  mov [r13+r14*1], r12d
00007df8f93d0c60  mov r14d, 0x43087C
00007df8f93d0c66  mov r12d, [rsp+0x20]
00007df8f93d0c6b  mov [r13+r14*1], r12d
00007df8f93d0c70  lea r14, [rax+0xA0]
00007df8f93d0c77  mov [r15+0xF8], r14
00007df8f93d0c7e  mov [r15+0x100], r8
00007df8f93d0c85  jmp 0x00007DF8F93CE5C0
00007df8f93d0c8a  int3
00007df8f93d0c8b  call 0x00007DF8F920DAE0
00007df8f93d0c90  jmp 0x00007DF8F93D0B3C
00007df8f93d0c95  call 0x00007DF8F92C0230
00007df8f93d0c9a  jmp 0x00007DF8F93D0B45
00007df8f93d0c9f  call 0x00007DF8F92BEFC0
00007df8f93d0ca4  jmp 0x00007DF8F93D0B4E
00007df8f93d0ca9  call 0x00007DF8F92BDD50
00007df8f93d0cae  jmp 0x00007DF8F93D0B57
00007df8f93d0cb3  call 0x00007DF8F92BCC20
00007df8f93d0cb8  jmp 0x00007DF8F93D0B6B
00007df8f93d0cbd  call 0x00007DF8F92C3EA0
00007df8f93d0cc2  jmp 0x00007DF8F93D0B83
00007df8f93d0cc7  call 0x00007DF8F92E1920
00007df8f93d0ccc  jmp 0x00007DF8F93D0B8E
00007df8f93d0cd1  call 0x00007DF8F92E26A0
00007df8f93d0cd6  jmp 0x00007DF8F93D0B9D
00007df8f93d0cdb  call 0x00007DF8F92E1430
00007df8f93d0ce0  jmp 0x00007DF8F93D0BA6
00007df8f93d0ce5  call 0x00007DF8F92E06B0
00007df8f93d0cea  jmp 0x00007DF8F93D0BB1
00007df8f93d0cef  call 0x00007DF8F92DF440
00007df8f93d0cf4  jmp 0x00007DF8F93D0BBC
00007df8f93d0cf9  call 0x00007DF8F92E0300
00007df8f93d0cfe  jmp 0x00007DF8F93D0BC8
00007df8f93d0d03  call 0x00007DF8F92DF090
00007df8f93d0d08  jmp 0x00007DF8F93D0BD4
00007df8f93d0d0d  call 0x00007DF8F92E1430
00007df8f93d0d12  jmp 0x00007DF8F93D0BFD
00007df8f93d0d17  call 0x00007DF8F92E01C0
00007df8f93d0d1c  jmp 0x00007DF8F93D0C06
00007df8f93d0d21  call 0x00007DF8F92E2BA0
00007df8f93d0d26  jmp 0x00007DF8F93D0C1D
00007df8f93d0d2b  call 0x00007DF8F92E2BA0
00007df8f93d0d30  jmp 0x00007DF8F93D0C2D
00007df8f93d0d35  call 0x00007DF8F92E2BA0
00007df8f93d0d3a  jmp 0x00007DF8F93D0C60
00007df8f93d0d3f  call 0x00007DF8F92E2BA0
00007df8f93d0d44  jmp 0x00007DF8F93D0C70
00007df8f93d0d49  int3
00007df8f93d0d4a  nop [rax+rax*1], ax
00007df8f93d0d50  mov qword ptr [r15+0x100], 0x04
00007df8f93d0d5b  mov esi, 0x00
00007df8f93d0d60  mov edx, 0x09
00007df8f93d0d65  mov rdi, 0x7FFFF7355450
00007df8f93d0d6f  mov rax, 0x5F14B5F45970
00007df8f93d0d79  call rax
00007df8f93d0d7b  cmp dword ptr [r15+0x318], 0x00
00007df8f93d0d83  jnz 0x00007DF8F91FE110
00007df8f93d0d89  jmp 0x00007DF8F91FE0A0
00007df8f93d0d8e  int3
00007df8f93d0d8f  int3
