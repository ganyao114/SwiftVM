000075da1b7ce69b  nop [rax+rax*1], eax
000075da1b7ce6a0  mov rax, [r15+0xF8]
000075da1b7ce6a7  lea r14, [rax-0xA0]
000075da1b7ce6ae  mov [r15+0xF8], r14
000075da1b7ce6b5  lea rax, [r14+0x90]
000075da1b7ce6bc  mov r12, [r15+0xA0]
000075da1b7ce6c3  mov r11, [r15+0x98]
000075da1b7ce6ca  mov [r13+rax*1], r12
000075da1b7ce6cf  lea rax, [r14+0x98]
000075da1b7ce6d6  mov [r13+rax*1], r11
000075da1b7ce6db  mov eax, 0x420670
000075da1b7ce6e0  movups xmm1, [r13+rax*1]
000075da1b7ce6e6  mov eax, 0x420610
000075da1b7ce6eb  movups xmm15, [r13+rax*1]
000075da1b7ce6f1  mov eax, 0x420690
000075da1b7ce6f6  movups xmm14, [r13+rax*1]
000075da1b7ce6fc  mov eax, 0x420630
000075da1b7ce701  movups xmm13, [r13+rax*1]
000075da1b7ce707  mov qword ptr [r15+0x98], 0x4308A0
000075da1b7ce712  mov eax, 0x4206A0
000075da1b7ce717  movups xmm12, [r13+rax*1]
000075da1b7ce71d  mov eax, 0x4308A0
000075da1b7ce722  movups [r13+rax*1], xmm1
000075da1b7ce728  mov eax, 0x4308B0
000075da1b7ce72d  movups [r13+rax*1], xmm15
000075da1b7ce733  mov eax, 0x4308C0
000075da1b7ce738  movups [r13+rax*1], xmm14
000075da1b7ce73e  mov eax, 0x4308D0
000075da1b7ce743  movups [r13+rax*1], xmm13
000075da1b7ce749  mov eax, 0x420600
000075da1b7ce74e  movups xmm14, [r13+rax*1]
000075da1b7ce754  mov eax, 0x4205F0
000075da1b7ce759  movups xmm13, [r13+rax*1]
000075da1b7ce75f  mov eax, 0x4309A0
000075da1b7ce764  movups [r13+rax*1], xmm1
000075da1b7ce76a  mov eax, 0x4309B0
000075da1b7ce76f  movups [r13+rax*1], xmm15
000075da1b7ce775  mov eax, 0x4308E0
000075da1b7ce77a  movups [r13+rax*1], xmm12
000075da1b7ce780  mov eax, 0x4308F0
000075da1b7ce785  movups [r13+rax*1], xmm14
000075da1b7ce78b  mov eax, 0x4205E0
000075da1b7ce790  movups xmm1, [r13+rax*1]
000075da1b7ce796  mov eax, 0x420640
000075da1b7ce79b  movups xmm15, [r13+rax*1]
000075da1b7ce7a1  mov eax, 0x430900
000075da1b7ce7a6  movups [r13+rax*1], xmm13
000075da1b7ce7ac  mov eax, 0x430910
000075da1b7ce7b1  movups [r13+rax*1], xmm1
000075da1b7ce7b7  mov eax, 0x420650
000075da1b7ce7bc  movups xmm1, [r13+rax*1]
000075da1b7ce7c2  mov eax, 0x420620
000075da1b7ce7c7  movups xmm14, [r13+rax*1]
000075da1b7ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000075da1b7ce7d5  mov eax, 0x430920
000075da1b7ce7da  movups [r13+rax*1], xmm15
000075da1b7ce7e0  mov eax, 0x430930
000075da1b7ce7e5  movups [r13+rax*1], xmm1
000075da1b7ce7eb  mov eax, 0x4206C0
000075da1b7ce7f0  movups xmm1, [r13+rax*1]
000075da1b7ce7f6  mov eax, 0x4206D0
000075da1b7ce7fb  movups xmm15, [r13+rax*1]
000075da1b7ce801  movaps [r15+0x150], xmm15
000075da1b7ce809  mov qword ptr [r15+0xA0], 0x3E8
000075da1b7ce814  mov eax, 0x430940
000075da1b7ce819  movups [r13+rax*1], xmm14
000075da1b7ce81f  mov eax, 0x430950
000075da1b7ce824  movups [r13+rax*1], xmm1
000075da1b7ce82a  mov eax, 0x4206B0
000075da1b7ce82f  movups xmm1, [r13+rax*1]
000075da1b7ce835  mov eax, 0x420660
000075da1b7ce83a  movups xmm14, [r13+rax*1]
000075da1b7ce840  movaps [r15+0x140], xmm14
000075da1b7ce848  lea rax, [r14+0x80]
000075da1b7ce84f  mov r12, [r15+0xF0]
000075da1b7ce856  mov [r13+rax*1], r12
000075da1b7ce85b  mov eax, 0x430960
000075da1b7ce860  movups [r13+rax*1], xmm15
000075da1b7ce866  mov eax, 0x430970
000075da1b7ce86b  movups [r13+rax*1], xmm1
000075da1b7ce871  mov eax, 0x420680
000075da1b7ce876  movups xmm1, [r13+rax*1]
000075da1b7ce87c  mov eax, 0x4206E0
000075da1b7ce881  mov r12, [r13+rax*1]
000075da1b7ce886  movq xmm15, r12
000075da1b7ce88b  mov qword ptr [r15+0x40], 0x4206E8
000075da1b7ce893  mov eax, 0x430980
000075da1b7ce898  movups [r13+rax*1], xmm14
000075da1b7ce89e  mov eax, 0x430990
000075da1b7ce8a3  movups [r13+rax*1], xmm1
000075da1b7ce8a9  mov eax, 0x420748
000075da1b7ce8ae  movups xmm1, [r13+rax*1]
000075da1b7ce8b4  movq rax, xmm15
000075da1b7ce8b9  mov r12d, 0x4309C0
000075da1b7ce8bf  mov [r13+r12*1], rax
000075da1b7ce8c4  mov eax, 0x420728
000075da1b7ce8c9  movups xmm15, [r13+rax*1]
000075da1b7ce8cf  mov eax, 0x420738
000075da1b7ce8d4  movups xmm14, [r13+rax*1]
000075da1b7ce8da  lea rax, [r14+0x60]
000075da1b7ce8de  movups [r13+rax*1], xmm1
000075da1b7ce8e4  mov eax, 0x4309C8
000075da1b7ce8e9  mov r12d, 0x421DF8D3
000075da1b7ce8ef  mov [r13+rax*1], r12d
000075da1b7ce8f4  lea rax, [r14+0x40]
000075da1b7ce8f8  movups [r13+rax*1], xmm15
000075da1b7ce8fe  lea rax, [r14+0x50]
000075da1b7ce902  movups [r13+rax*1], xmm14
000075da1b7ce908  mov eax, 0x4206E8
000075da1b7ce90d  movups xmm1, [r13+rax*1]
000075da1b7ce913  mov eax, 0x4206F8
000075da1b7ce918  movups xmm15, [r13+rax*1]
000075da1b7ce91e  movaps [r15+0x120], xmm15
000075da1b7ce926  movups [r13+r14*1], xmm1
000075da1b7ce92c  lea rax, [r14+0x10]
000075da1b7ce930  movups [r13+rax*1], xmm15
000075da1b7ce936  mov eax, 0x420708
000075da1b7ce93b  movups xmm1, [r13+rax*1]
000075da1b7ce941  mov eax, 0x420718
000075da1b7ce946  movups xmm15, [r13+rax*1]
000075da1b7ce94c  movaps [r15+0x110], xmm1
000075da1b7ce954  movaps [r15+0x130], xmm15
000075da1b7ce95c  lea rax, [r14+0x20]
000075da1b7ce960  movups [r13+rax*1], xmm1
000075da1b7ce966  lea rax, [r14+0x30]
000075da1b7ce96a  movups [r13+rax*1], xmm15
000075da1b7ce970  mov [r15], r14
000075da1b7ce973  mov qword ptr [r15+0x08], 0x4308A0
000075da1b7ce97b  mov qword ptr [r15+0x10], 0x12C
000075da1b7ce983  mov qword ptr [r15+0xF0], 0x410274
000075da1b7ce98e  mov r14d, [r15+0x320]
000075da1b7ce995  mov eax, 0x410274
000075da1b7ce99a  mov rcx, 0x75DA1B7D0670
000075da1b7ce9a4  mov [r15+r14*8+0x328], rax
000075da1b7ce9ac  mov [r15+r14*8+0x368], rcx
000075da1b7ce9b4  add r14d, 0x01
000075da1b7ce9b8  and r14d, 0x07
000075da1b7ce9bc  mov [r15+0x320], r14d
000075da1b7ce9c3  cmp dword ptr [r15+0x318], 0x00
000075da1b7ce9cb  jz 0x000075DA1B7CEC20
000075da1b7ce9d1  nop [rax+rax*1], ax
000075da1b7ce9da  nop [rax+rax*1], eax
000075da1b7ce9e2  mov eax, 0x410338
000075da1b7ce9e7  mov [r15+0x100], rax
000075da1b7ce9ee  jmp 0x000075DA1B5FE110
000075da1b7ce9f3  int3
000075da1b7ce9f4  call 0x000075DA1B60BC20
000075da1b7ce9f9  jmp 0x000075DA1B7CE6CF
000075da1b7ce9fe  call 0x000075DA1B60A9A0
000075da1b7cea03  jmp 0x000075DA1B7CE6DB
000075da1b7cea08  call 0x000075DA1B5FF430
000075da1b7cea0d  jmp 0x000075DA1B7CE6E6
000075da1b7cea12  call 0x000075DA1B60E760
000075da1b7cea17  jmp 0x000075DA1B7CE6F1
000075da1b7cea1c  call 0x000075DA1B60D4E0
000075da1b7cea21  jmp 0x000075DA1B7CE6FC
000075da1b7cea26  call 0x000075DA1B60C260
000075da1b7cea2b  jmp 0x000075DA1B7CE707
000075da1b7cea30  call 0x000075DA1B60AFE0
000075da1b7cea35  jmp 0x000075DA1B7CE71D
000075da1b7cea3a  call 0x000075DA1B5FF540
000075da1b7cea3f  jmp 0x000075DA1B7CE728
000075da1b7cea44  call 0x000075DA1B60E880
000075da1b7cea49  jmp 0x000075DA1B7CE733
000075da1b7cea4e  call 0x000075DA1B60D600
000075da1b7cea53  jmp 0x000075DA1B7CE73E
000075da1b7cea58  call 0x000075DA1B60C380
000075da1b7cea5d  jmp 0x000075DA1B7CE749
000075da1b7cea62  call 0x000075DA1B60D4E0
000075da1b7cea67  jmp 0x000075DA1B7CE754
000075da1b7cea6c  call 0x000075DA1B60C260
000075da1b7cea71  jmp 0x000075DA1B7CE75F
000075da1b7cea76  call 0x000075DA1B5FF540
000075da1b7cea7b  jmp 0x000075DA1B7CE76A
000075da1b7cea80  call 0x000075DA1B60E880
000075da1b7cea85  jmp 0x000075DA1B7CE775
000075da1b7cea8a  call 0x000075DA1B60B100
000075da1b7cea8f  jmp 0x000075DA1B7CE780
000075da1b7cea94  call 0x000075DA1B60D600
000075da1b7cea99  jmp 0x000075DA1B7CE78B
000075da1b7cea9e  call 0x000075DA1B5FF430
000075da1b7ceaa3  jmp 0x000075DA1B7CE796
000075da1b7ceaa8  call 0x000075DA1B60E760
000075da1b7ceaad  jmp 0x000075DA1B7CE7A1
000075da1b7ceab2  call 0x000075DA1B60C380
000075da1b7ceab7  jmp 0x000075DA1B7CE7AC
000075da1b7ceabc  call 0x000075DA1B5FF540
000075da1b7ceac1  jmp 0x000075DA1B7CE7B7
000075da1b7ceac6  call 0x000075DA1B5FF430
000075da1b7ceacb  jmp 0x000075DA1B7CE7C2
000075da1b7cead0  call 0x000075DA1B60D4E0
000075da1b7cead5  jmp 0x000075DA1B7CE7CD
000075da1b7ceada  call 0x000075DA1B60E880
000075da1b7ceadf  jmp 0x000075DA1B7CE7E0
000075da1b7ceae4  call 0x000075DA1B5FF540
000075da1b7ceae9  jmp 0x000075DA1B7CE7EB
000075da1b7ceaee  call 0x000075DA1B5FF430
000075da1b7ceaf3  jmp 0x000075DA1B7CE7F6
000075da1b7ceaf8  call 0x000075DA1B60E760
000075da1b7ceafd  jmp 0x000075DA1B7CE801
000075da1b7ceb02  call 0x000075DA1B60D600
000075da1b7ceb07  jmp 0x000075DA1B7CE81F
000075da1b7ceb0c  call 0x000075DA1B5FF540
000075da1b7ceb11  jmp 0x000075DA1B7CE82A
000075da1b7ceb16  call 0x000075DA1B5FF430
000075da1b7ceb1b  jmp 0x000075DA1B7CE835
000075da1b7ceb20  call 0x000075DA1B60D4E0
000075da1b7ceb25  jmp 0x000075DA1B7CE840
000075da1b7ceb2a  call 0x000075DA1B60BC20
000075da1b7ceb2f  jmp 0x000075DA1B7CE85B
000075da1b7ceb34  call 0x000075DA1B60E880
000075da1b7ceb39  jmp 0x000075DA1B7CE866
000075da1b7ceb3e  call 0x000075DA1B5FF540
000075da1b7ceb43  jmp 0x000075DA1B7CE871
000075da1b7ceb48  call 0x000075DA1B5FF430
000075da1b7ceb4d  jmp 0x000075DA1B7CE87C
000075da1b7ceb52  call 0x000075DA1B60B720
000075da1b7ceb57  jmp 0x000075DA1B7CE886
000075da1b7ceb5c  call 0x000075DA1B60D600
000075da1b7ceb61  jmp 0x000075DA1B7CE89E
000075da1b7ceb66  call 0x000075DA1B5FF540
000075da1b7ceb6b  jmp 0x000075DA1B7CE8A9
000075da1b7ceb70  call 0x000075DA1B5FF430
000075da1b7ceb75  jmp 0x000075DA1B7CE8B4
000075da1b7ceb7a  call 0x000075DA1B6B4CB0
000075da1b7ceb7f  jmp 0x000075DA1B7CE8C4
000075da1b7ceb84  call 0x000075DA1B60E760
000075da1b7ceb89  jmp 0x000075DA1B7CE8CF
000075da1b7ceb8e  call 0x000075DA1B60D4E0
000075da1b7ceb93  jmp 0x000075DA1B7CE8DA
000075da1b7ceb98  call 0x000075DA1B5FF540
000075da1b7ceb9d  jmp 0x000075DA1B7CE8E4
000075da1b7ceba2  call 0x000075DA1B60BAE0
000075da1b7ceba7  jmp 0x000075DA1B7CE8F4
000075da1b7cebac  call 0x000075DA1B60E880
000075da1b7cebb1  jmp 0x000075DA1B7CE8FE
000075da1b7cebb6  call 0x000075DA1B60D600
000075da1b7cebbb  jmp 0x000075DA1B7CE908
000075da1b7cebc0  call 0x000075DA1B5FF430
000075da1b7cebc5  jmp 0x000075DA1B7CE913
000075da1b7cebca  call 0x000075DA1B60E760
000075da1b7cebcf  jmp 0x000075DA1B7CE91E
000075da1b7cebd4  call 0x000075DA1B6D6600
000075da1b7cebd9  jmp 0x000075DA1B7CE92C
000075da1b7cebde  call 0x000075DA1B60E880
000075da1b7cebe3  jmp 0x000075DA1B7CE936
000075da1b7cebe8  call 0x000075DA1B5FF430
000075da1b7cebed  jmp 0x000075DA1B7CE941
000075da1b7cebf2  call 0x000075DA1B60E760
000075da1b7cebf7  jmp 0x000075DA1B7CE94C
000075da1b7cebfc  call 0x000075DA1B5FF540
000075da1b7cec01  jmp 0x000075DA1B7CE966
000075da1b7cec06  call 0x000075DA1B60E880
000075da1b7cec0b  jmp 0x000075DA1B7CE970
000075da1b7cec10  int3
000075da1b7cec11  nop [rax+rax*1], ax
000075da1b7cec1a  nop [rax+rax*1], ax
000075da1b7cec20  mov rax, [r15]
000075da1b7cec23  lea r14, [rax+0x20]
000075da1b7cec27  mov r12, [r13+r14*1]
000075da1b7cec2c  mov r14, [r15+0x10]
000075da1b7cec30  lea r11, [r12+r14*1]
000075da1b7cec34  mov [r15+0x40], r11
000075da1b7cec38  lea r12, [rax+0x20]
000075da1b7cec3c  mov [r13+r12*1], r11
000075da1b7cec41  test r14, r14
000075da1b7cec44  setz r14b
000075da1b7cec48  movzx r14, r14b
000075da1b7cec4c  mov [rsp+0x414], r14b
000075da1b7cec54  cmp byte ptr [rsp+0x414], 0x00
000075da1b7cec5c  jz 0x000075DA1B7CEC8E
000075da1b7cec5e  cmp dword ptr [r15+0x318], 0x00
000075da1b7cec66  mov eax, 0x4105B0
000075da1b7cec6b  mov [r15+0x100], rax
000075da1b7cec72  jz 0x000075DA1B5FE0A0
000075da1b7cec78  nop [rax+rax*1], eax
000075da1b7cec7d  mov eax, 0x4105B0
000075da1b7cec82  mov [r15+0x100], rax
000075da1b7cec89  jmp 0x000075DA1B5FE110
000075da1b7cec8e  cmp dword ptr [r15+0x318], 0x00
000075da1b7cec96  jz 0x000075DA1B7CECE0
000075da1b7cec9c  nop [rax+rax*1], ax
000075da1b7ceca5  nop [rax+rax*1], eax
000075da1b7cecad  mov eax, 0x410348
000075da1b7cecb2  mov [r15+0x100], rax
000075da1b7cecb9  jmp 0x000075DA1B5FE110
000075da1b7cecbe  int3
000075da1b7cecbf  call 0x000075DA1B6E27E0
000075da1b7cecc4  jmp 0x000075DA1B7CEC2C
000075da1b7cecc9  call 0x000075DA1B6C0860
000075da1b7cecce  jmp 0x000075DA1B7CEC41
000075da1b7cecd3  int3
000075da1b7cecd4  nop [rax+rax*1], ax
000075da1b7cecdd  nop [rax], eax
000075da1b7cece0  mov rax, [r15+0xF8]
000075da1b7cece7  lea r14, [rax-0x150]
000075da1b7cecee  mov [r15+0xF8], r14
000075da1b7cecf5  mov rax, [r15]
000075da1b7cecf8  lea r12, [rax+0x68]
000075da1b7cecfc  mov r11, [r13+r12*1]
000075da1b7ced01  mov [r15+0x88], r11
000075da1b7ced08  lea r12, [rax+0x28]
000075da1b7ced0c  mov [r15+0x40], r12
000075da1b7ced10  mov [r15+0x48], r14
000075da1b7ced14  mov qword ptr [r15+0x50], 0x420758
000075da1b7ced1c  lea rax, [r14+0x100]
000075da1b7ced23  mov r12, [r15+0xE8]
000075da1b7ced2a  mov r11, [r15+0xD8]
000075da1b7ced31  mov [r13+rax*1], r12
000075da1b7ced36  lea rax, [r14+0x108]
000075da1b7ced3d  mov [r13+rax*1], r11
000075da1b7ced42  lea rax, [r14+0x110]
000075da1b7ced49  mov r12, [r15+0xD0]
000075da1b7ced50  mov r11, [r15+0xC8]
000075da1b7ced57  mov [r13+rax*1], r12
000075da1b7ced5c  lea rax, [r14+0x118]
000075da1b7ced63  mov [r13+rax*1], r11
000075da1b7ced68  lea rax, [r14+0x120]
000075da1b7ced6f  mov r12, [r15+0xC0]
000075da1b7ced76  mov r11, [r15+0xB8]
000075da1b7ced7d  mov [r13+rax*1], r12
000075da1b7ced82  lea rax, [r14+0x128]
000075da1b7ced89  mov [r13+rax*1], r11
000075da1b7ced8e  lea rax, [r14+0x130]
000075da1b7ced95  mov r12, [r15+0xB0]
000075da1b7ced9c  mov r11, [r15+0xA8]
000075da1b7ceda3  mov [r13+rax*1], r12
000075da1b7ceda8  lea rax, [r14+0x138]
000075da1b7cedaf  mov [r13+rax*1], r11
000075da1b7cedb4  lea rax, [r14+0x140]
000075da1b7cedbb  mov r12, [r15+0xA0]
000075da1b7cedc2  mov r11, [r15+0x98]
000075da1b7cedc9  mov [r13+rax*1], r12
000075da1b7cedce  lea rax, [r14+0x148]
000075da1b7cedd5  mov [r13+rax*1], r11
000075da1b7cedda  cmp dword ptr [r15+0x318], 0x00
000075da1b7cede2  jz 0x000075DA1B7CEE80
000075da1b7cede8  nop [rax+rax*1], ax
000075da1b7cedf1  nop [rax+rax*1], eax
000075da1b7cedf9  mov eax, 0x410380
000075da1b7cedfe  mov [r15+0x100], rax
000075da1b7cee05  jmp 0x000075DA1B5FE110
000075da1b7cee0a  int3
000075da1b7cee0b  call 0x000075DA1B6C0370
000075da1b7cee10  jmp 0x000075DA1B7CED01
000075da1b7cee15  call 0x000075DA1B60BC20
000075da1b7cee1a  jmp 0x000075DA1B7CED36
000075da1b7cee1f  call 0x000075DA1B60A9A0
000075da1b7cee24  jmp 0x000075DA1B7CED42
000075da1b7cee29  call 0x000075DA1B60BC20
000075da1b7cee2e  jmp 0x000075DA1B7CED5C
000075da1b7cee33  call 0x000075DA1B60A9A0
000075da1b7cee38  jmp 0x000075DA1B7CED68
000075da1b7cee3d  call 0x000075DA1B60BC20
000075da1b7cee42  jmp 0x000075DA1B7CED82
000075da1b7cee47  call 0x000075DA1B60A9A0
000075da1b7cee4c  jmp 0x000075DA1B7CED8E
000075da1b7cee51  call 0x000075DA1B60BC20
000075da1b7cee56  jmp 0x000075DA1B7CEDA8
000075da1b7cee5b  call 0x000075DA1B60A9A0
000075da1b7cee60  jmp 0x000075DA1B7CEDB4
000075da1b7cee65  call 0x000075DA1B60BC20
000075da1b7cee6a  jmp 0x000075DA1B7CEDCE
000075da1b7cee6f  call 0x000075DA1B60A9A0
000075da1b7cee74  jmp 0x000075DA1B7CEDDA
000075da1b7cee79  int3
000075da1b7cee7a  nop [rax+rax*1], ax
000075da1b7cee80  mov rax, [r15+0x08]
000075da1b7cee84  movzx r14d, byte ptr [r13+rax*1]
000075da1b7cee8a  movzx r14d, r14b
000075da1b7cee8e  mov [rsp+0x10], r14d
000075da1b7cee93  mov r14d, r14d
000075da1b7cee96  mov [r15+0x58], r14
000075da1b7cee9a  lea r14, [rax+0x01]
000075da1b7cee9e  mov [r15+0x08], r14
000075da1b7ceea2  mov rax, [r15+0x88]
000075da1b7ceea9  lea r14, [rax+0x01]
000075da1b7ceead  mov r12, [r15]
000075da1b7ceeb0  lea r11, [r12+0x68]
000075da1b7ceeb5  mov [r13+r11*1], r14
000075da1b7ceeba  lea r14, [r12+rax*1]
000075da1b7ceebe  mov [r15+0x60], r14
000075da1b7ceec2  lea rax, [r14+0x28]
000075da1b7ceec6  mov r11d, [rsp+0x10]
000075da1b7ceecb  movzx r14d, r11b
000075da1b7ceecf  mov [r13+rax*1], r14b
000075da1b7ceed4  lea rax, [r12+0x68]
000075da1b7ceed9  mov r14, [r13+rax*1]
000075da1b7ceede  mov [r15+0x88], r14
000075da1b7ceee5  xor eax, eax
000075da1b7ceee7  mov r12d, 0x40
000075da1b7ceeed  cmp r14, r12
000075da1b7ceef0  cmc
000075da1b7ceef1  lahf
000075da1b7ceef2  seto al
000075da1b7ceef5  mov [r15+0x108], eax
000075da1b7ceefc  mov eax, [r15+0x108]
000075da1b7cef03  sahf
000075da1b7cef04  jnz 0x000075DA1B7CEF36
000075da1b7cef06  cmp dword ptr [r15+0x318], 0x00
000075da1b7cef0e  jz 0x000075DA1B7CF020
000075da1b7cef14  nop [rax+rax*1], ax
000075da1b7cef1d  nop [rax+rax*1], eax
000075da1b7cef25  mov eax, 0x4103A0
000075da1b7cef2a  mov [r15+0x100], rax
000075da1b7cef31  jmp 0x000075DA1B5FE110
000075da1b7cef36  cmp dword ptr [r15+0x318], 0x00
000075da1b7cef3e  jz 0x000075DA1B7CEF90
000075da1b7cef44  nop [rax+rax*1], ax
000075da1b7cef4d  nop [rax+rax*1], eax
000075da1b7cef55  mov eax, 0x410378
000075da1b7cef5a  mov [r15+0x100], rax
000075da1b7cef61  jmp 0x000075DA1B5FE110
000075da1b7cef66  int3
000075da1b7cef67  call 0x000075DA1B60D860
000075da1b7cef6c  jmp 0x000075DA1B7CEE8A
000075da1b7cef71  call 0x000075DA1B6B36E0
000075da1b7cef76  jmp 0x000075DA1B7CEEBA
000075da1b7cef7b  call 0x000075DA1B60DD60
000075da1b7cef80  jmp 0x000075DA1B7CEED4
000075da1b7cef85  call 0x000075DA1B60DC20
000075da1b7cef8a  jmp 0x000075DA1B7CEEDE
000075da1b7cef8f  int3
000075da1b7cef90  mov rax, [r15+0x10]
000075da1b7cef94  lea r14, [rax-0x01]
000075da1b7cef98  mov [r15+0x10], r14
000075da1b7cef9c  test r14, r14
000075da1b7cef9f  setz r14b
000075da1b7cefa3  movzx r14, r14b
000075da1b7cefa7  mov [rsp+0x414], r14b
000075da1b7cefaf  cmp byte ptr [rsp+0x414], 0x00
000075da1b7cefb7  jz 0x000075DA1B7CEFE9
000075da1b7cefb9  cmp dword ptr [r15+0x318], 0x00
000075da1b7cefc1  jz 0x000075DA1B7D0520
000075da1b7cefc7  nop [rax+rax*1], ax
000075da1b7cefd0  nop [rax+rax*1], eax
000075da1b7cefd8  mov eax, 0x410598
000075da1b7cefdd  mov [r15+0x100], rax
000075da1b7cefe4  jmp 0x000075DA1B5FE110
000075da1b7cefe9  cmp dword ptr [r15+0x318], 0x00
000075da1b7ceff1  jz 0x000075DA1B7CEE80
000075da1b7ceff7  nop [rax+rax*1], ax
000075da1b7cf000  nop [rax+rax*1], eax
000075da1b7cf008  mov eax, 0x410380
000075da1b7cf00d  mov [r15+0x100], rax
000075da1b7cf014  jmp 0x000075DA1B5FE110
000075da1b7cf019  int3
000075da1b7cf01a  int3
000075da1b7cf01b  nop [rax+rax*1], eax
000075da1b7cf020  mov rax, [r15+0x40]
000075da1b7cf024  movzx r14d, byte ptr [r13+rax*1]
000075da1b7cf02a  movaps xmm1, [r15+0x110]
000075da1b7cf032  pinsrb xmm1, r14d, 0x00
000075da1b7cf039  lea r14, [rax+0x01]
000075da1b7cf03d  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf043  movaps xmm15, [r15+0x120]
000075da1b7cf04b  pinsrb xmm15, r12d, 0x00
000075da1b7cf052  lea r14, [rax+0x02]
000075da1b7cf056  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf05c  movaps xmm14, [r15+0x130]
000075da1b7cf064  pinsrb xmm14, r12d, 0x00
000075da1b7cf06b  lea r14, [rax+0x03]
000075da1b7cf06f  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf075  movaps xmm13, [r15+0x140]
000075da1b7cf07d  pinsrb xmm13, r12d, 0x00
000075da1b7cf084  lea r14, [rax+0x04]
000075da1b7cf088  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf08e  pinsrb xmm1, r12d, 0x01
000075da1b7cf095  lea r14, [rax+0x05]
000075da1b7cf099  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf09f  pinsrb xmm15, r12d, 0x01
000075da1b7cf0a6  lea r14, [rax+0x06]
000075da1b7cf0aa  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf0b0  pinsrb xmm14, r12d, 0x01
000075da1b7cf0b7  lea r14, [rax+0x07]
000075da1b7cf0bb  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf0c1  pinsrb xmm13, r12d, 0x01
000075da1b7cf0c8  lea r14, [rax+0x08]
000075da1b7cf0cc  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf0d2  pinsrb xmm1, r12d, 0x02
000075da1b7cf0d9  lea r14, [rax+0x09]
000075da1b7cf0dd  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf0e3  pinsrb xmm15, r12d, 0x02
000075da1b7cf0ea  lea r14, [rax+0x0A]
000075da1b7cf0ee  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf0f4  pinsrb xmm14, r12d, 0x02
000075da1b7cf0fb  lea r14, [rax+0x0B]
000075da1b7cf0ff  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf105  pinsrb xmm13, r12d, 0x02
000075da1b7cf10c  lea r14, [rax+0x0C]
000075da1b7cf110  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf116  pinsrb xmm1, r12d, 0x03
000075da1b7cf11d  lea r14, [rax+0x0D]
000075da1b7cf121  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf127  pinsrb xmm15, r12d, 0x03
000075da1b7cf12e  lea r14, [rax+0x0E]
000075da1b7cf132  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf138  pinsrb xmm14, r12d, 0x03
000075da1b7cf13f  lea r14, [rax+0x0F]
000075da1b7cf143  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf149  pinsrb xmm13, r12d, 0x03
000075da1b7cf150  lea r14, [rax+0x10]
000075da1b7cf154  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf15a  pinsrb xmm1, r12d, 0x04
000075da1b7cf161  lea r14, [rax+0x11]
000075da1b7cf165  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf16b  pinsrb xmm15, r12d, 0x04
000075da1b7cf172  lea r14, [rax+0x12]
000075da1b7cf176  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf17c  pinsrb xmm14, r12d, 0x04
000075da1b7cf183  lea r14, [rax+0x13]
000075da1b7cf187  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf18d  pinsrb xmm13, r12d, 0x04
000075da1b7cf194  lea r14, [rax+0x14]
000075da1b7cf198  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf19e  pinsrb xmm1, r12d, 0x05
000075da1b7cf1a5  lea r14, [rax+0x15]
000075da1b7cf1a9  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf1af  pinsrb xmm15, r12d, 0x05
000075da1b7cf1b6  lea r14, [rax+0x16]
000075da1b7cf1ba  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf1c0  pinsrb xmm14, r12d, 0x05
000075da1b7cf1c7  lea r14, [rax+0x17]
000075da1b7cf1cb  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf1d1  pinsrb xmm13, r12d, 0x05
000075da1b7cf1d8  lea r14, [rax+0x18]
000075da1b7cf1dc  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf1e2  pinsrb xmm1, r12d, 0x06
000075da1b7cf1e9  lea r14, [rax+0x19]
000075da1b7cf1ed  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf1f3  pinsrb xmm15, r12d, 0x06
000075da1b7cf1fa  lea r14, [rax+0x1A]
000075da1b7cf1fe  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf204  pinsrb xmm14, r12d, 0x06
000075da1b7cf20b  lea r14, [rax+0x1B]
000075da1b7cf20f  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf215  pinsrb xmm13, r12d, 0x06
000075da1b7cf21c  lea r14, [rax+0x1C]
000075da1b7cf220  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf226  pinsrb xmm1, r12d, 0x07
000075da1b7cf22d  lea r14, [rax+0x1D]
000075da1b7cf231  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf237  pinsrb xmm15, r12d, 0x07
000075da1b7cf23e  lea r14, [rax+0x1E]
000075da1b7cf242  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf248  pinsrb xmm14, r12d, 0x07
000075da1b7cf24f  lea r14, [rax+0x1F]
000075da1b7cf253  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf259  pinsrb xmm13, r12d, 0x07
000075da1b7cf260  lea r14, [rax+0x20]
000075da1b7cf264  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf26a  pinsrb xmm1, r12d, 0x08
000075da1b7cf271  lea r14, [rax+0x21]
000075da1b7cf275  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf27b  pinsrb xmm15, r12d, 0x08
000075da1b7cf282  lea r14, [rax+0x22]
000075da1b7cf286  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf28c  pinsrb xmm14, r12d, 0x08
000075da1b7cf293  lea r14, [rax+0x23]
000075da1b7cf297  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf29d  pinsrb xmm13, r12d, 0x08
000075da1b7cf2a4  lea r14, [rax+0x24]
000075da1b7cf2a8  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf2ae  pinsrb xmm1, r12d, 0x09
000075da1b7cf2b5  lea r14, [rax+0x25]
000075da1b7cf2b9  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf2bf  pinsrb xmm15, r12d, 0x09
000075da1b7cf2c6  lea r14, [rax+0x26]
000075da1b7cf2ca  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf2d0  pinsrb xmm14, r12d, 0x09
000075da1b7cf2d7  lea r14, [rax+0x27]
000075da1b7cf2db  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf2e1  pinsrb xmm13, r12d, 0x09
000075da1b7cf2e8  lea r14, [rax+0x28]
000075da1b7cf2ec  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf2f2  pinsrb xmm1, r12d, 0x0A
000075da1b7cf2f9  lea r14, [rax+0x29]
000075da1b7cf2fd  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf303  pinsrb xmm15, r12d, 0x0A
000075da1b7cf30a  lea r14, [rax+0x2A]
000075da1b7cf30e  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf314  pinsrb xmm14, r12d, 0x0A
000075da1b7cf31b  lea r14, [rax+0x2B]
000075da1b7cf31f  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf325  pinsrb xmm13, r12d, 0x0A
000075da1b7cf32c  lea r14, [rax+0x2C]
000075da1b7cf330  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf336  pinsrb xmm1, r12d, 0x0B
000075da1b7cf33d  lea r14, [rax+0x2D]
000075da1b7cf341  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf347  pinsrb xmm15, r12d, 0x0B
000075da1b7cf34e  lea r14, [rax+0x2E]
000075da1b7cf352  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf358  pinsrb xmm14, r12d, 0x0B
000075da1b7cf35f  lea r14, [rax+0x2F]
000075da1b7cf363  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf369  pinsrb xmm13, r12d, 0x0B
000075da1b7cf370  lea r14, [rax+0x30]
000075da1b7cf374  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf37a  pinsrb xmm1, r12d, 0x0C
000075da1b7cf381  lea r14, [rax+0x31]
000075da1b7cf385  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf38b  pinsrb xmm15, r12d, 0x0C
000075da1b7cf392  lea r14, [rax+0x32]
000075da1b7cf396  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf39c  pinsrb xmm14, r12d, 0x0C
000075da1b7cf3a3  lea r14, [rax+0x33]
000075da1b7cf3a7  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf3ad  pinsrb xmm13, r12d, 0x0C
000075da1b7cf3b4  lea r14, [rax+0x34]
000075da1b7cf3b8  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf3be  pinsrb xmm1, r12d, 0x0D
000075da1b7cf3c5  lea r14, [rax+0x35]
000075da1b7cf3c9  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf3cf  pinsrb xmm15, r12d, 0x0D
000075da1b7cf3d6  lea r14, [rax+0x36]
000075da1b7cf3da  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf3e0  pinsrb xmm14, r12d, 0x0D
000075da1b7cf3e7  lea r14, [rax+0x37]
000075da1b7cf3eb  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf3f1  pinsrb xmm13, r12d, 0x0D
000075da1b7cf3f8  lea r14, [rax+0x38]
000075da1b7cf3fc  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf402  pinsrb xmm1, r12d, 0x0E
000075da1b7cf409  lea r14, [rax+0x39]
000075da1b7cf40d  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf413  pinsrb xmm15, r12d, 0x0E
000075da1b7cf41a  lea r14, [rax+0x3A]
000075da1b7cf41e  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf424  pinsrb xmm14, r12d, 0x0E
000075da1b7cf42b  lea r14, [rax+0x3B]
000075da1b7cf42f  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf435  pinsrb xmm13, r12d, 0x0E
000075da1b7cf43c  lea r14, [rax+0x3C]
000075da1b7cf440  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf446  pinsrb xmm1, r12d, 0x0F
000075da1b7cf44d  movaps [r15+0x110], xmm1
000075da1b7cf455  lea r14, [rax+0x3D]
000075da1b7cf459  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf45f  pinsrb xmm15, r12d, 0x0F
000075da1b7cf466  movaps [r15+0x120], xmm15
000075da1b7cf46e  lea r14, [rax+0x3E]
000075da1b7cf472  movzx r12d, byte ptr [r13+r14*1]
000075da1b7cf478  pinsrb xmm14, r12d, 0x0F
000075da1b7cf47f  movaps [r15+0x130], xmm14
000075da1b7cf487  lea r14, [rax+0x3F]
000075da1b7cf48b  movzx eax, byte ptr [r13+r14*1]
000075da1b7cf491  pinsrb xmm13, eax, 0x0F
000075da1b7cf498  movaps [r15+0x140], xmm13
000075da1b7cf4a0  movq xmm1, qword ptr [r15+0x120]
000075da1b7cf4a9  pmovzxbw xmm1, xmm1
000075da1b7cf4ae  psllw xmm1, 0x00
000075da1b7cf4b3  movaps [r15+0x150], xmm1
000075da1b7cf4bb  movq xmm1, qword ptr [r15+0x130]
000075da1b7cf4c4  pmovzxbw xmm1, xmm1
000075da1b7cf4c9  psllw xmm1, 0x00
000075da1b7cf4ce  movaps [r15+0x160], xmm1
000075da1b7cf4d6  movq xmm1, qword ptr [r15+0x110]
000075da1b7cf4df  pmovzxbw xmm1, xmm1
000075da1b7cf4e4  psllw xmm1, 0x00
000075da1b7cf4e9  movaps [r15+0x170], xmm1
000075da1b7cf4f1  movaps xmm15, [r15+0x110]
000075da1b7cf4f9  pextrq rax, xmm15, 0x01
000075da1b7cf500  movq xmm15, rax
000075da1b7cf505  pmovzxbw xmm15, xmm15
000075da1b7cf50b  psllw xmm15, 0x00
000075da1b7cf511  movaps [r15+0x180], xmm15
000075da1b7cf519  movaps xmm14, [r15+0x120]
000075da1b7cf521  pextrq rax, xmm14, 0x01
000075da1b7cf528  movq xmm14, rax
000075da1b7cf52d  pmovzxbw xmm14, xmm14
000075da1b7cf533  psllw xmm14, 0x00
000075da1b7cf539  movaps [r15+0x210], xmm14
000075da1b7cf541  movaps xmm13, [r15+0x130]
000075da1b7cf549  pextrq rax, xmm13, 0x01
000075da1b7cf550  movq xmm13, rax
000075da1b7cf555  pmovzxbw xmm13, xmm13
000075da1b7cf55b  psllw xmm13, 0x00
000075da1b7cf561  movaps [r15+0x220], xmm13
000075da1b7cf569  movq xmm12, qword ptr [r15+0x140]
000075da1b7cf572  pmovzxbw xmm12, xmm12
000075da1b7cf578  psllw xmm12, 0x00
000075da1b7cf57e  movaps [r15+0x250], xmm12
000075da1b7cf586  movaps xmm12, [r15+0x140]
000075da1b7cf58e  pextrq rax, xmm12, 0x01
000075da1b7cf595  movq xmm12, rax
000075da1b7cf59a  pmovzxbw xmm12, xmm12
000075da1b7cf5a0  psllw xmm12, 0x00
000075da1b7cf5a6  movaps [r15+0x110], xmm12
000075da1b7cf5ae  movq xmm11, qword ptr [r15+0x150]
000075da1b7cf5b7  pmovzxwd xmm11, xmm11
000075da1b7cf5bd  pslld xmm11, 0x10
000075da1b7cf5c3  movq xmm10, qword ptr [r15+0x160]
000075da1b7cf5cc  pmovzxwd xmm10, xmm10
000075da1b7cf5d2  pslld xmm10, 0x08
000075da1b7cf5d8  pextrq rax, xmm1, 0x01
000075da1b7cf5df  movq xmm1, rax
000075da1b7cf5e4  pmovzxwd xmm1, xmm1
000075da1b7cf5e9  pslld xmm1, 0x00
000075da1b7cf5ee  movaps [r15+0x260], xmm1
000075da1b7cf5f6  pextrq rax, xmm15, 0x01
000075da1b7cf5fd  movq xmm15, rax
000075da1b7cf602  pmovzxwd xmm15, xmm15
000075da1b7cf608  pslld xmm15, 0x00
000075da1b7cf60e  movaps [r15+0x270], xmm15
000075da1b7cf616  movq xmm9, qword ptr [r15+0x170]
000075da1b7cf61f  pmovzxwd xmm9, xmm9
000075da1b7cf625  pslld xmm9, 0x00
000075da1b7cf62b  pextrq rax, xmm14, 0x01
000075da1b7cf632  movq xmm14, rax
000075da1b7cf637  pmovzxwd xmm14, xmm14
000075da1b7cf63d  pslld xmm14, 0x10
000075da1b7cf643  movaps [r15+0x280], xmm14
000075da1b7cf64b  movq xmm8, qword ptr [r15+0x180]
000075da1b7cf654  pmovzxwd xmm8, xmm8
000075da1b7cf65a  pslld xmm8, 0x00
000075da1b7cf660  movq xmm7, qword ptr [r15+0x210]
000075da1b7cf669  pmovzxwd xmm7, xmm7
000075da1b7cf66e  pslld xmm7, 0x10
000075da1b7cf673  movaps xmm6, [r15+0x150]
000075da1b7cf67b  pextrq rax, xmm6, 0x01
000075da1b7cf682  movq xmm6, rax
000075da1b7cf687  pmovzxwd xmm6, xmm6
000075da1b7cf68c  pslld xmm6, 0x10
000075da1b7cf691  por xmm11, xmm10
000075da1b7cf696  movaps [r15+0x230], xmm11
000075da1b7cf69e  pextrq rax, xmm13, 0x01
000075da1b7cf6a5  movq xmm13, rax
000075da1b7cf6aa  pmovzxwd xmm13, xmm13
000075da1b7cf6b0  pslld xmm13, 0x08
000075da1b7cf6b6  movaps [r15+0x240], xmm13
000075da1b7cf6be  movq xmm10, qword ptr [r15+0x220]
000075da1b7cf6c7  pmovzxwd xmm10, xmm10
000075da1b7cf6cd  pslld xmm10, 0x08
000075da1b7cf6d3  movaps xmm5, [r15+0x160]
000075da1b7cf6db  pextrq rax, xmm5, 0x01
000075da1b7cf6e2  movq xmm5, rax
000075da1b7cf6e7  pmovzxwd xmm5, xmm5
000075da1b7cf6ec  pslld xmm5, 0x08
000075da1b7cf6f1  pslld xmm9, 0x18
000075da1b7cf6f7  pslld xmm15, 0x18
000075da1b7cf6fd  pslld xmm8, 0x18
000075da1b7cf703  movq xmm4, qword ptr [r15+0x250]
000075da1b7cf70c  pmovzxwd xmm4, xmm4
000075da1b7cf711  pslld xmm4, 0x00
000075da1b7cf716  por xmm14, xmm13
000075da1b7cf71b  por xmm7, xmm10
000075da1b7cf720  movaps [r15+0x210], xmm7
000075da1b7cf728  pslld xmm1, 0x18
000075da1b7cf72d  movaps [r15+0x220], xmm1
000075da1b7cf735  por xmm6, xmm5
000075da1b7cf739  por xmm11, xmm9
000075da1b7cf73e  movaps [r15+0x160], xmm11
000075da1b7cf746  pextrq rax, xmm12, 0x01
000075da1b7cf74d  movq xmm13, rax
000075da1b7cf752  pmovzxwd xmm13, xmm13
000075da1b7cf758  pslld xmm13, 0x00
000075da1b7cf75e  movaps [r15+0x170], xmm13
000075da1b7cf766  movq xmm12, qword ptr [r15+0x110]
000075da1b7cf76f  pmovzxwd xmm12, xmm12
000075da1b7cf775  pslld xmm12, 0x00
000075da1b7cf77b  por xmm14, xmm15
000075da1b7cf780  por xmm7, xmm8
000075da1b7cf785  movaps xmm15, [r15+0x250]
000075da1b7cf78d  pextrq rax, xmm15, 0x01
000075da1b7cf794  movq xmm15, rax
000075da1b7cf799  pmovzxwd xmm15, xmm15
000075da1b7cf79f  pslld xmm15, 0x00
000075da1b7cf7a5  movaps [r15+0x180], xmm15
000075da1b7cf7ad  por xmm6, xmm1
000075da1b7cf7b1  movaps [r15+0x150], xmm6
000075da1b7cf7b9  por xmm11, xmm4
000075da1b7cf7be  movaps [r15+0x140], xmm11
000075da1b7cf7c6  por xmm7, xmm12
000075da1b7cf7cb  movaps [r15+0x110], xmm7
000075da1b7cf7d3  por xmm14, xmm13
000075da1b7cf7d8  movaps [r15+0x120], xmm14
000075da1b7cf7e0  por xmm6, xmm15
000075da1b7cf7e5  movaps [r15+0x130], xmm6
000075da1b7cf7ed  mov rax, [r15+0xF8]
000075da1b7cf7f4  lea r14, [rax+0x20]
000075da1b7cf7f8  movups [r13+r14*1], xmm7
000075da1b7cf7fe  lea r14, [rax+0x30]
000075da1b7cf802  movups [r13+r14*1], xmm14
000075da1b7cf808  movups [r13+rax*1], xmm11
000075da1b7cf80e  lea r14, [rax+0x10]
000075da1b7cf812  movups [r13+r14*1], xmm6
000075da1b7cf818  mov r14d, [r13+rax*1]
000075da1b7cf81d  mov rax, [r15+0x48]
000075da1b7cf821  mov [r15+0x68], rax
000075da1b7cf825  mov qword ptr [r15+0x58], 0x04
000075da1b7cf82d  lea r12, [rax+0x04]
000075da1b7cf831  mov r11d, [r13+r12*1]
000075da1b7cf836  mov [rsp+0x10], r11d
000075da1b7cf83b  mov r11d, r11d
000075da1b7cf83e  mov [r15+0x70], r11
000075da1b7cf842  lea r12, [rax+0x38]
000075da1b7cf846  mov r11d, [r13+r12*1]
000075da1b7cf84b  lea r12, [rax+0x24]
000075da1b7cf84f  mov r10d, [r13+r12*1]
000075da1b7cf854  mov [rsp+0x20], r10d
000075da1b7cf859  mov r10d, r10d
000075da1b7cf85c  mov [r15+0x90], r10
000075da1b7cf863  mov [rsp+0x30], rax
000075da1b7cf868  xor eax, eax
000075da1b7cf86a  mov r12d, 0x04
000075da1b7cf870  mov r10d, 0xC0
000075da1b7cf876  cmp r12, r10
000075da1b7cf879  cmc
000075da1b7cf87a  lahf
000075da1b7cf87b  seto al
000075da1b7cf87e  mov [r15+0x108], eax
000075da1b7cf885  mov eax, [rsp+0x10]
000075da1b7cf889  mov r12d, [rsp+0x10]
000075da1b7cf88e  shrd eax, r12d, 0x07
000075da1b7cf893  mov [rsp+0x10], r11d
000075da1b7cf898  mov r10d, [rsp+0x10]
000075da1b7cf89d  shrd r11d, r10d, 0x11
000075da1b7cf8a2  mov r9d, [rsp+0x20]
000075da1b7cf8a7  lea r8d, [r9d+r14d*1]
000075da1b7cf8ac  rorx r14d, r12d, 0x12
000075da1b7cf8b2  xor eax, r14d
000075da1b7cf8b5  rorx r14d, r10d, 0x13
000075da1b7cf8bb  xor r11d, r14d
000075da1b7cf8be  mov [rsp+0x10], r11d
000075da1b7cf8c3  mov r11d, r11d
000075da1b7cf8c6  mov [r15+0x88], r11
000075da1b7cf8cd  mov [rsp+0x20], r12d
000075da1b7cf8d2  shr r12d, 0x03
000075da1b7cf8d6  xor eax, r12d
000075da1b7cf8d9  mov [rsp+0x40], eax
000075da1b7cf8dd  mov eax, eax
000075da1b7cf8df  mov [r15+0x80], rax
000075da1b7cf8e6  shr r10d, 0x0A
000075da1b7cf8ea  mov eax, [rsp+0x10]
000075da1b7cf8ee  xor eax, r10d
000075da1b7cf8f1  mov [rsp+0x10], eax
000075da1b7cf8f5  mov eax, eax
000075da1b7cf8f7  mov [r15+0x78], rax
000075da1b7cf8fb  mov eax, [rsp+0x40]
000075da1b7cf8ff  lea r14d, [r8d+eax*1]
000075da1b7cf904  mov eax, [rsp+0x10]
000075da1b7cf908  lea r12d, [r14d+eax*1]
000075da1b7cf90d  mov rax, [rsp+0x30]
000075da1b7cf912  lea r14, [rax+0x40]
000075da1b7cf916  mov [r13+r14*1], r12d
000075da1b7cf91b  mov eax, [rsp+0x20]
000075da1b7cf91f  mov eax, eax
000075da1b7cf921  mov [r15+0x60], rax
000075da1b7cf925  mov eax, [r15+0x108]
000075da1b7cf92c  sahf
000075da1b7cf92d  jnz 0x000075DA1B7CF95F
000075da1b7cf92f  cmp dword ptr [r15+0x318], 0x00
000075da1b7cf937  jz 0x000075DA1B7CFE20
000075da1b7cf93d  nop [rax+rax*1], ax
000075da1b7cf946  nop [rax+rax*1], eax
000075da1b7cf94e  mov eax, 0x41049C
000075da1b7cf953  mov [r15+0x100], rax
000075da1b7cf95a  jmp 0x000075DA1B5FE110
000075da1b7cf95f  cmp dword ptr [r15+0x318], 0x00
000075da1b7cf967  jz 0x000075DA1B7CFC70
000075da1b7cf96d  nop [rax+rax*1], ax
000075da1b7cf976  nop [rax+rax*1], eax
000075da1b7cf97e  mov eax, 0x410454
000075da1b7cf983  mov [r15+0x100], rax
000075da1b7cf98a  jmp 0x000075DA1B5FE110
000075da1b7cf98f  int3
000075da1b7cf990  call 0x000075DA1B60D860
000075da1b7cf995  jmp 0x000075DA1B7CF02A
000075da1b7cf99a  call 0x000075DA1B6E2420
000075da1b7cf99f  jmp 0x000075DA1B7CF043
000075da1b7cf9a4  call 0x000075DA1B6E2420
000075da1b7cf9a9  jmp 0x000075DA1B7CF05C
000075da1b7cf9ae  call 0x000075DA1B6E2420
000075da1b7cf9b3  jmp 0x000075DA1B7CF075
000075da1b7cf9b8  call 0x000075DA1B6E2420
000075da1b7cf9bd  jmp 0x000075DA1B7CF08E
000075da1b7cf9c2  call 0x000075DA1B6E2420
000075da1b7cf9c7  jmp 0x000075DA1B7CF09F
000075da1b7cf9cc  call 0x000075DA1B6E2420
000075da1b7cf9d1  jmp 0x000075DA1B7CF0B0
000075da1b7cf9d6  call 0x000075DA1B6E2420
000075da1b7cf9db  jmp 0x000075DA1B7CF0C1
000075da1b7cf9e0  call 0x000075DA1B6E2420
000075da1b7cf9e5  jmp 0x000075DA1B7CF0D2
000075da1b7cf9ea  call 0x000075DA1B6E2420
000075da1b7cf9ef  jmp 0x000075DA1B7CF0E3
000075da1b7cf9f4  call 0x000075DA1B6E2420
000075da1b7cf9f9  jmp 0x000075DA1B7CF0F4
000075da1b7cf9fe  call 0x000075DA1B6E2420
000075da1b7cfa03  jmp 0x000075DA1B7CF105
000075da1b7cfa08  call 0x000075DA1B6E2420
000075da1b7cfa0d  jmp 0x000075DA1B7CF116
000075da1b7cfa12  call 0x000075DA1B6E2420
000075da1b7cfa17  jmp 0x000075DA1B7CF127
000075da1b7cfa1c  call 0x000075DA1B6E2420
000075da1b7cfa21  jmp 0x000075DA1B7CF138
000075da1b7cfa26  call 0x000075DA1B6E2420
000075da1b7cfa2b  jmp 0x000075DA1B7CF149
000075da1b7cfa30  call 0x000075DA1B6E2420
000075da1b7cfa35  jmp 0x000075DA1B7CF15A
000075da1b7cfa3a  call 0x000075DA1B6E2420
000075da1b7cfa3f  jmp 0x000075DA1B7CF16B
000075da1b7cfa44  call 0x000075DA1B6E2420
000075da1b7cfa49  jmp 0x000075DA1B7CF17C
000075da1b7cfa4e  call 0x000075DA1B6E2420
000075da1b7cfa53  jmp 0x000075DA1B7CF18D
000075da1b7cfa58  call 0x000075DA1B6E2420
000075da1b7cfa5d  jmp 0x000075DA1B7CF19E
000075da1b7cfa62  call 0x000075DA1B6E2420
000075da1b7cfa67  jmp 0x000075DA1B7CF1AF
000075da1b7cfa6c  call 0x000075DA1B6E2420
000075da1b7cfa71  jmp 0x000075DA1B7CF1C0
000075da1b7cfa76  call 0x000075DA1B6E2420
000075da1b7cfa7b  jmp 0x000075DA1B7CF1D1
000075da1b7cfa80  call 0x000075DA1B6E2420
000075da1b7cfa85  jmp 0x000075DA1B7CF1E2
000075da1b7cfa8a  call 0x000075DA1B6E2420
000075da1b7cfa8f  jmp 0x000075DA1B7CF1F3
000075da1b7cfa94  call 0x000075DA1B6E2420
000075da1b7cfa99  jmp 0x000075DA1B7CF204
000075da1b7cfa9e  call 0x000075DA1B6E2420
000075da1b7cfaa3  jmp 0x000075DA1B7CF215
000075da1b7cfaa8  call 0x000075DA1B6E2420
000075da1b7cfaad  jmp 0x000075DA1B7CF226
000075da1b7cfab2  call 0x000075DA1B6E2420
000075da1b7cfab7  jmp 0x000075DA1B7CF237
000075da1b7cfabc  call 0x000075DA1B6E2420
000075da1b7cfac1  jmp 0x000075DA1B7CF248
000075da1b7cfac6  call 0x000075DA1B6E2420
000075da1b7cfacb  jmp 0x000075DA1B7CF259
000075da1b7cfad0  call 0x000075DA1B6E2420
000075da1b7cfad5  jmp 0x000075DA1B7CF26A
000075da1b7cfada  call 0x000075DA1B6E2420
000075da1b7cfadf  jmp 0x000075DA1B7CF27B
000075da1b7cfae4  call 0x000075DA1B6E2420
000075da1b7cfae9  jmp 0x000075DA1B7CF28C
000075da1b7cfaee  call 0x000075DA1B6E2420
000075da1b7cfaf3  jmp 0x000075DA1B7CF29D
000075da1b7cfaf8  call 0x000075DA1B6E2420
000075da1b7cfafd  jmp 0x000075DA1B7CF2AE
000075da1b7cfb02  call 0x000075DA1B6E2420
000075da1b7cfb07  jmp 0x000075DA1B7CF2BF
000075da1b7cfb0c  call 0x000075DA1B6E2420
000075da1b7cfb11  jmp 0x000075DA1B7CF2D0
000075da1b7cfb16  call 0x000075DA1B6E2420
000075da1b7cfb1b  jmp 0x000075DA1B7CF2E1
000075da1b7cfb20  call 0x000075DA1B6E2420
000075da1b7cfb25  jmp 0x000075DA1B7CF2F2
000075da1b7cfb2a  call 0x000075DA1B6E2420
000075da1b7cfb2f  jmp 0x000075DA1B7CF303
000075da1b7cfb34  call 0x000075DA1B6E2420
000075da1b7cfb39  jmp 0x000075DA1B7CF314
000075da1b7cfb3e  call 0x000075DA1B6E2420
000075da1b7cfb43  jmp 0x000075DA1B7CF325
000075da1b7cfb48  call 0x000075DA1B6E2420
000075da1b7cfb4d  jmp 0x000075DA1B7CF336
000075da1b7cfb52  call 0x000075DA1B6E2420
000075da1b7cfb57  jmp 0x000075DA1B7CF347
000075da1b7cfb5c  call 0x000075DA1B6E2420
000075da1b7cfb61  jmp 0x000075DA1B7CF358
000075da1b7cfb66  call 0x000075DA1B6E2420
000075da1b7cfb6b  jmp 0x000075DA1B7CF369
000075da1b7cfb70  call 0x000075DA1B6E2420
000075da1b7cfb75  jmp 0x000075DA1B7CF37A
000075da1b7cfb7a  call 0x000075DA1B6E2420
000075da1b7cfb7f  jmp 0x000075DA1B7CF38B
000075da1b7cfb84  call 0x000075DA1B6E2420
000075da1b7cfb89  jmp 0x000075DA1B7CF39C
000075da1b7cfb8e  call 0x000075DA1B6E2420
000075da1b7cfb93  jmp 0x000075DA1B7CF3AD
000075da1b7cfb98  call 0x000075DA1B6E2420
000075da1b7cfb9d  jmp 0x000075DA1B7CF3BE
000075da1b7cfba2  call 0x000075DA1B6E2420
000075da1b7cfba7  jmp 0x000075DA1B7CF3CF
000075da1b7cfbac  call 0x000075DA1B6E2420
000075da1b7cfbb1  jmp 0x000075DA1B7CF3E0
000075da1b7cfbb6  call 0x000075DA1B6E2420
000075da1b7cfbbb  jmp 0x000075DA1B7CF3F1
000075da1b7cfbc0  call 0x000075DA1B6E2420
000075da1b7cfbc5  jmp 0x000075DA1B7CF402
000075da1b7cfbca  call 0x000075DA1B6E2420
000075da1b7cfbcf  jmp 0x000075DA1B7CF413
000075da1b7cfbd4  call 0x000075DA1B6E2420
000075da1b7cfbd9  jmp 0x000075DA1B7CF424
000075da1b7cfbde  call 0x000075DA1B6E2420
000075da1b7cfbe3  jmp 0x000075DA1B7CF435
000075da1b7cfbe8  call 0x000075DA1B6E2420
000075da1b7cfbed  jmp 0x000075DA1B7CF446
000075da1b7cfbf2  call 0x000075DA1B6E2420
000075da1b7cfbf7  jmp 0x000075DA1B7CF45F
000075da1b7cfbfc  call 0x000075DA1B6E2420
000075da1b7cfc01  jmp 0x000075DA1B7CF478
000075da1b7cfc06  call 0x000075DA1B6D5610
000075da1b7cfc0b  jmp 0x000075DA1B7CF491
000075da1b7cfc10  call 0x000075DA1B6DC580
000075da1b7cfc15  jmp 0x000075DA1B7CF7FE
000075da1b7cfc1a  call 0x000075DA1B6E46C0
000075da1b7cfc1f  jmp 0x000075DA1B7CF808
000075da1b7cfc24  call 0x000075DA1B609E90
000075da1b7cfc29  jmp 0x000075DA1B7CF80E
000075da1b7cfc2e  call 0x000075DA1B6DB310
000075da1b7cfc33  jmp 0x000075DA1B7CF818
000075da1b7cfc38  call 0x000075DA1B60DAE0
000075da1b7cfc3d  jmp 0x000075DA1B7CF81D
000075da1b7cfc42  call 0x000075DA1B6C0230
000075da1b7cfc47  jmp 0x000075DA1B7CF836
000075da1b7cfc4c  call 0x000075DA1B6C0230
000075da1b7cfc51  jmp 0x000075DA1B7CF84B
000075da1b7cfc56  call 0x000075DA1B6BEFC0
000075da1b7cfc5b  jmp 0x000075DA1B7CF854
000075da1b7cfc60  call 0x000075DA1B6E2BA0
000075da1b7cfc65  jmp 0x000075DA1B7CF91B
000075da1b7cfc6a  int3
000075da1b7cfc6b  nop [rax+rax*1], eax
000075da1b7cfc70  mov rax, [r15+0x48]
000075da1b7cfc74  mov r14, [r15+0x58]
000075da1b7cfc78  lea r12, [rax+r14*1]
000075da1b7cfc7c  mov [r15+0x68], r12
000075da1b7cfc80  lea rax, [r14+0x04]
000075da1b7cfc84  mov [r15+0x58], rax
000075da1b7cfc88  lea r14, [r12+0x04]
000075da1b7cfc8d  mov r11d, [r13+r14*1]
000075da1b7cfc92  mov [rsp+0x10], r11d
000075da1b7cfc97  mov r11d, r11d
000075da1b7cfc9a  mov [r15+0x70], r11
000075da1b7cfc9e  lea r14, [r12+0x38]
000075da1b7cfca3  mov r11d, [r13+r14*1]
000075da1b7cfca8  lea r14, [r12+0x24]
000075da1b7cfcad  mov r10d, [r13+r14*1]
000075da1b7cfcb2  mov [rsp+0x20], r10d
000075da1b7cfcb7  mov r10d, r10d
000075da1b7cfcba  mov [r15+0x90], r10
000075da1b7cfcc1  mov [rsp+0x30], rax
000075da1b7cfcc6  xor eax, eax
000075da1b7cfcc8  mov r14, [rsp+0x30]
000075da1b7cfccd  mov r10d, 0xC0
000075da1b7cfcd3  cmp r14, r10
000075da1b7cfcd6  cmc
000075da1b7cfcd7  lahf
000075da1b7cfcd8  seto al
000075da1b7cfcdb  mov [r15+0x108], eax
000075da1b7cfce2  mov eax, [rsp+0x10]
000075da1b7cfce6  mov r14d, [rsp+0x10]
000075da1b7cfceb  shrd eax, r14d, 0x07
000075da1b7cfcf0  mov [rsp+0x10], r11d
000075da1b7cfcf5  mov r10d, [rsp+0x10]
000075da1b7cfcfa  shrd r11d, r10d, 0x11
000075da1b7cfcff  mov r9d, [r15+0x60]
000075da1b7cfd03  mov r8d, [rsp+0x20]
000075da1b7cfd08  lea ebp, [r8d+r9d*1]
000075da1b7cfd0d  rorx r9d, r14d, 0x12
000075da1b7cfd13  xor eax, r9d
000075da1b7cfd16  rorx r9d, r10d, 0x13
000075da1b7cfd1c  xor r11d, r9d
000075da1b7cfd1f  mov [rsp+0x10], r11d
000075da1b7cfd24  mov r11d, r11d
000075da1b7cfd27  mov [r15+0x88], r11
000075da1b7cfd2e  mov [rsp+0x20], r14d
000075da1b7cfd33  shr r14d, 0x03
000075da1b7cfd37  xor eax, r14d
000075da1b7cfd3a  mov [rsp+0x30], eax
000075da1b7cfd3e  mov eax, eax
000075da1b7cfd40  mov [r15+0x80], rax
000075da1b7cfd47  shr r10d, 0x0A
000075da1b7cfd4b  mov eax, [rsp+0x10]
000075da1b7cfd4f  xor eax, r10d
000075da1b7cfd52  mov [rsp+0x10], eax
000075da1b7cfd56  mov eax, eax
000075da1b7cfd58  mov [r15+0x78], rax
000075da1b7cfd5c  mov eax, [rsp+0x30]
000075da1b7cfd60  lea r14d, [ebp+eax*1]
000075da1b7cfd66  mov eax, [rsp+0x10]
000075da1b7cfd6a  lea r11d, [r14d+eax*1]
000075da1b7cfd6f  lea rax, [r12+0x40]
000075da1b7cfd74  mov [r13+rax*1], r11d
000075da1b7cfd79  mov eax, [rsp+0x20]
000075da1b7cfd7d  mov eax, eax
000075da1b7cfd7f  mov [r15+0x60], rax
000075da1b7cfd83  mov eax, [r15+0x108]
000075da1b7cfd8a  sahf
000075da1b7cfd8b  jnz 0x000075DA1B7CFDBD
000075da1b7cfd8d  cmp dword ptr [r15+0x318], 0x00
000075da1b7cfd95  jz 0x000075DA1B7CFE20
000075da1b7cfd9b  nop [rax+rax*1], ax
000075da1b7cfda4  nop [rax+rax*1], eax
000075da1b7cfdac  mov eax, 0x41049C
000075da1b7cfdb1  mov [r15+0x100], rax
000075da1b7cfdb8  jmp 0x000075DA1B5FE110
000075da1b7cfdbd  cmp dword ptr [r15+0x318], 0x00
000075da1b7cfdc5  jz 0x000075DA1B7CFC70
000075da1b7cfdcb  nop [rax+rax*1], ax
000075da1b7cfdd4  nop [rax+rax*1], eax
000075da1b7cfddc  mov eax, 0x410454
000075da1b7cfde1  mov [r15+0x100], rax
000075da1b7cfde8  jmp 0x000075DA1B5FE110
000075da1b7cfded  int3
000075da1b7cfdee  call 0x000075DA1B6E1430
000075da1b7cfdf3  jmp 0x000075DA1B7CFC92
000075da1b7cfdf8  call 0x000075DA1B6E1430
000075da1b7cfdfd  jmp 0x000075DA1B7CFCA8
000075da1b7cfe02  call 0x000075DA1B6E01C0
000075da1b7cfe07  jmp 0x000075DA1B7CFCB2
000075da1b7cfe0c  call 0x000075DA1B60A860
000075da1b7cfe11  jmp 0x000075DA1B7CFD79
000075da1b7cfe16  int3
000075da1b7cfe17  nop [rax+rax*1], ax
000075da1b7cfe20  mov rax, [r15]
000075da1b7cfe23  mov r14d, [r13+rax*1]
000075da1b7cfe28  lea r12, [rax+0x04]
000075da1b7cfe2c  mov r11d, [r13+r12*1]
000075da1b7cfe31  mov [rsp+0x10], r14d
000075da1b7cfe36  mov r14d, r14d
000075da1b7cfe39  mov [r15+0x78], r14
000075da1b7cfe3d  mov [rsp+0x20], r11d
000075da1b7cfe42  mov r11d, r11d
000075da1b7cfe45  mov [r15+0x80], r11
000075da1b7cfe4c  lea r14, [rax+0x08]
000075da1b7cfe50  mov r12d, [r13+r14*1]
000075da1b7cfe55  lea r14, [rax+0x0C]
000075da1b7cfe59  mov r11d, [r13+r14*1]
000075da1b7cfe5e  mov [rsp+0x30], r12d
000075da1b7cfe63  mov r12d, r12d
000075da1b7cfe66  mov [r15+0x70], r12
000075da1b7cfe6a  mov [rsp+0x40], r11d
000075da1b7cfe6f  mov r11d, r11d
000075da1b7cfe72  mov [r15+0x68], r11
000075da1b7cfe76  lea r14, [rax+0x18]
000075da1b7cfe7a  mov r12d, [r13+r14*1]
000075da1b7cfe7f  lea r14, [rax+0x1C]
000075da1b7cfe83  mov r11d, [r13+r14*1]
000075da1b7cfe88  mov [rsp+0x50], r12d
000075da1b7cfe8d  mov r12d, r12d
000075da1b7cfe90  mov [r15+0x58], r12
000075da1b7cfe94  mov [rsp+0x60], r11d
000075da1b7cfe99  mov r11d, r11d
000075da1b7cfe9c  mov [r15+0x60], r11
000075da1b7cfea0  lea r14, [rax+0x10]
000075da1b7cfea4  mov r12d, [r13+r14*1]
000075da1b7cfea9  lea r14, [rax+0x14]
000075da1b7cfead  mov eax, [r13+r14*1]
000075da1b7cfeb2  mov [rsp+0x70], r12d
000075da1b7cfeb7  mov r12d, r12d
000075da1b7cfeba  mov [r15+0x18], r12
000075da1b7cfebe  mov [rsp+0x80], eax
000075da1b7cfec5  mov eax, eax
000075da1b7cfec7  mov [r15+0x90], rax
000075da1b7cfece  mov eax, [rsp+0x70]
000075da1b7cfed2  mov eax, eax
000075da1b7cfed4  mov [r15+0x30], rax
000075da1b7cfed8  mov eax, [rsp+0x50]
000075da1b7cfedc  mov eax, eax
000075da1b7cfede  mov [r15+0xA0], rax
000075da1b7cfee5  mov eax, [rsp+0x30]
000075da1b7cfee9  mov eax, eax
000075da1b7cfeeb  mov [r15+0x28], rax
000075da1b7cfeef  mov eax, [rsp+0x20]
000075da1b7cfef3  mov eax, eax
000075da1b7cfef5  mov [r15+0x98], rax
000075da1b7cfefc  mov eax, [rsp+0x10]
000075da1b7cff00  mov eax, eax
000075da1b7cff02  mov [r15+0x38], rax
000075da1b7cff06  mov eax, [rsp+0x70]
000075da1b7cff0a  mov r14d, [rsp+0x70]
000075da1b7cff0f  shrd eax, r14d, 0x06
000075da1b7cff14  mov [rsp+0x70], r14d
000075da1b7cff19  mov r12d, [rsp+0x80]
000075da1b7cff21  and r14d, r12d
000075da1b7cff24  mov r11d, [rsp+0x10]
000075da1b7cff29  mov r10d, [rsp+0x10]
000075da1b7cff2e  shrd r11d, r10d, 0x02
000075da1b7cff33  mov [rsp+0x10], r12d
000075da1b7cff38  mov r12d, r12d
000075da1b7cff3b  mov [r15+0x20], r12
000075da1b7cff3f  mov r12, [r15+0x50]
000075da1b7cff43  mov r9d, [r13+r12*1]
000075da1b7cff48  mov r12d, [rsp+0x50]
000075da1b7cff4d  mov r8d, [rsp+0x70]
000075da1b7cff52  andn ebp, r8d, r12d
000075da1b7cff57  mov edi, [rsp+0x60]
000075da1b7cff5b  lea esi, [r14d+edi*1]
000075da1b7cff60  rorx r14d, r8d, 0x0B
000075da1b7cff66  xor eax, r14d
000075da1b7cff69  rorx r14d, r10d, 0x0D
000075da1b7cff6f  xor r11d, r14d
000075da1b7cff72  lea edi, [esi+ebp*1]
000075da1b7cff76  mov r14, [r15+0x48]
000075da1b7cff7a  mov ebp, [r13+r14*1]
000075da1b7cff7f  mov r14d, [rsp+0x30]
000075da1b7cff84  mov esi, [rsp+0x20]
000075da1b7cff88  and r14d, esi
000075da1b7cff8b  mov [rsp+0x20], r14d
000075da1b7cff90  mov r14d, r14d
000075da1b7cff93  mov [r15+0xD8], r14
000075da1b7cff9a  lea r14d, [edi+r9d*1]
000075da1b7cff9f  mov r9d, [rsp+0x30]
000075da1b7cffa4  xor r9d, esi
000075da1b7cffa7  rorx edi, r8d, 0x19
000075da1b7cffad  xor eax, edi
000075da1b7cffaf  and r9d, r10d
000075da1b7cffb2  rorx edi, r10d, 0x16
000075da1b7cffb8  xor r11d, edi
000075da1b7cffbb  mov [rsp+0x30], r11d
000075da1b7cffc0  mov r11d, r11d
000075da1b7cffc3  mov [r15+0xD0], r11
000075da1b7cffca  lea r11d, [r14d+ebp*1]
000075da1b7cffcf  mov r10d, [rsp+0x20]
000075da1b7cffd4  xor r9d, r10d
000075da1b7cffd7  lea r14d, [r11d+eax*1]
000075da1b7cffdc  mov qword ptr [r15+0x88], 0x04
000075da1b7cffe7  mov eax, [rsp+0x30]
000075da1b7cffeb  lea r11d, [r9d+eax*1]
000075da1b7cfff0  mov eax, [rsp+0x40]
000075da1b7cfff4  lea r10d, [r14d+eax*1]
000075da1b7cfff9  mov r10d, r10d
000075da1b7cfffc  mov [r15+0xB8], r10
000075da1b7d0003  xor eax, eax
000075da1b7d0005  mov r10d, 0x04
000075da1b7d000b  mov r9d, 0x100
000075da1b7d0011  cmp r10, r9
000075da1b7d0014  cmc
000075da1b7d0015  lahf
000075da1b7d0016  seto al
000075da1b7d0019  mov [r15+0x108], eax
000075da1b7d0020  lea eax, [r11d+r14d*1]
000075da1b7d0025  mov eax, eax
000075da1b7d0027  mov [r15+0xA8], rax
000075da1b7d002e  mov r12d, r12d
000075da1b7d0031  mov [r15+0xB0], r12
000075da1b7d0038  mov eax, [rsp+0x10]
000075da1b7d003c  mov eax, eax
000075da1b7d003e  mov [r15+0xC0], rax
000075da1b7d0045  mov r8d, r8d
000075da1b7d0048  mov [r15+0xC8], r8
000075da1b7d004f  mov eax, [r15+0x108]
000075da1b7d0056  sahf
000075da1b7d0057  jnz 0x000075DA1B7D0089
000075da1b7d0059  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0061  jz 0x000075DA1B7D0350
000075da1b7d0067  nop [rax+rax*1], ax
000075da1b7d0070  nop [rax+rax*1], eax
000075da1b7d0078  mov eax, 0x41055C
000075da1b7d007d  mov [r15+0x100], rax
000075da1b7d0084  jmp 0x000075DA1B5FE110
000075da1b7d0089  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0091  jz 0x000075DA1B7D0120
000075da1b7d0097  nop [rax+rax*1], ax
000075da1b7d00a0  nop [rax+rax*1], eax
000075da1b7d00a8  mov eax, 0x4104D0
000075da1b7d00ad  mov [r15+0x100], rax
000075da1b7d00b4  jmp 0x000075DA1B5FE110
000075da1b7d00b9  int3
000075da1b7d00ba  call 0x000075DA1B60DAE0
000075da1b7d00bf  jmp 0x000075DA1B7CFE28
000075da1b7d00c4  call 0x000075DA1B6C0230
000075da1b7d00c9  jmp 0x000075DA1B7CFE31
000075da1b7d00ce  call 0x000075DA1B6E26A0
000075da1b7d00d3  jmp 0x000075DA1B7CFE55
000075da1b7d00d8  call 0x000075DA1B6E1430
000075da1b7d00dd  jmp 0x000075DA1B7CFE5E
000075da1b7d00e2  call 0x000075DA1B6E26A0
000075da1b7d00e7  jmp 0x000075DA1B7CFE7F
000075da1b7d00ec  call 0x000075DA1B6E1430
000075da1b7d00f1  jmp 0x000075DA1B7CFE88
000075da1b7d00f6  call 0x000075DA1B6E26A0
000075da1b7d00fb  jmp 0x000075DA1B7CFEA9
000075da1b7d0100  call 0x000075DA1B6D5890
000075da1b7d0105  jmp 0x000075DA1B7CFEB2
000075da1b7d010a  call 0x000075DA1B6BDD50
000075da1b7d010f  jmp 0x000075DA1B7CFF48
000075da1b7d0114  call 0x000075DA1B6DA580
000075da1b7d0119  jmp 0x000075DA1B7CFF7F
000075da1b7d011e  int3
000075da1b7d011f  nop
000075da1b7d0120  mov eax, [r15+0xB8]
000075da1b7d0127  mov [rsp+0x10], eax
000075da1b7d012b  mov eax, eax
000075da1b7d012d  mov [r15+0x30], rax
000075da1b7d0131  mov eax, [r15+0xC0]
000075da1b7d0138  mov [rsp+0x20], eax
000075da1b7d013c  mov eax, eax
000075da1b7d013e  mov [r15+0xA0], rax
000075da1b7d0145  mov eax, [r15+0x28]
000075da1b7d0149  mov r14d, [r15+0x98]
000075da1b7d0150  mov [rsp+0x30], r14d
000075da1b7d0155  mov r14d, r14d
000075da1b7d0158  mov [r15+0x28], r14
000075da1b7d015c  mov r14d, [r15+0x38]
000075da1b7d0160  mov [rsp+0x40], r14d
000075da1b7d0165  mov r14d, r14d
000075da1b7d0168  mov [r15+0x98], r14
000075da1b7d016f  mov r14d, [r15+0xA8]
000075da1b7d0176  mov [rsp+0x50], r14d
000075da1b7d017b  mov r14d, r14d
000075da1b7d017e  mov [r15+0x38], r14
000075da1b7d0182  mov r14d, [rsp+0x10]
000075da1b7d0187  mov r12d, [rsp+0x10]
000075da1b7d018c  shrd r14d, r12d, 0x06
000075da1b7d0191  mov r11d, [r15+0xC8]
000075da1b7d0198  mov [rsp+0x10], r12d
000075da1b7d019d  and r12d, r11d
000075da1b7d01a0  mov r10d, [rsp+0x50]
000075da1b7d01a5  mov r9d, [rsp+0x50]
000075da1b7d01aa  shrd r10d, r9d, 0x02
000075da1b7d01af  mov [rsp+0x50], r11d
000075da1b7d01b4  mov r11d, r11d
000075da1b7d01b7  mov [r15+0x20], r11
000075da1b7d01bb  mov r11, [r15+0x88]
000075da1b7d01c2  mov r8, [r15+0x50]
000075da1b7d01c6  lea rbp, [r8+r11*1]
000075da1b7d01ca  mov r8d, [r13+rbp*1]
000075da1b7d01cf  mov ebp, [rsp+0x20]
000075da1b7d01d3  mov edi, [rsp+0x10]
000075da1b7d01d7  andn esi, edi, ebp
000075da1b7d01dc  mov edx, [r15+0xB0]
000075da1b7d01e3  lea ecx, [r12d+edx*1]
000075da1b7d01e8  rorx r12d, edi, 0x0B
000075da1b7d01ee  xor r14d, r12d
000075da1b7d01f1  rorx r12d, r9d, 0x0D
000075da1b7d01f7  xor r10d, r12d
000075da1b7d01fa  lea r12d, [ecx+esi*1]
000075da1b7d01ff  mov rsi, [r15+0x48]
000075da1b7d0203  lea rdx, [rsi+r11*1]
000075da1b7d0207  mov esi, [r13+rdx*1]
000075da1b7d020c  mov edx, [rsp+0x30]
000075da1b7d0210  mov ecx, [rsp+0x40]
000075da1b7d0214  and edx, ecx
000075da1b7d0216  mov [rsp+0x10], edx
000075da1b7d021a  mov edx, edx
000075da1b7d021c  mov [r15+0xD8], rdx
000075da1b7d0223  lea edx, [r12d+r8d*1]
000075da1b7d0228  mov r12d, [rsp+0x30]
000075da1b7d022d  xor r12d, ecx
000075da1b7d0230  rorx r8d, edi, 0x19
000075da1b7d0236  xor r14d, r8d
000075da1b7d0239  and r12d, r9d
000075da1b7d023c  rorx r8d, r9d, 0x16
000075da1b7d0242  xor r10d, r8d
000075da1b7d0245  mov [rsp+0x20], r10d
000075da1b7d024a  mov r10d, r10d
000075da1b7d024d  mov [r15+0xD0], r10
000075da1b7d0254  lea r10d, [edx+esi*1]
000075da1b7d0259  mov r9d, [rsp+0x10]
000075da1b7d025e  xor r12d, r9d
000075da1b7d0261  lea r9d, [r10d+r14d*1]
000075da1b7d0266  lea r14, [r11+0x04]
000075da1b7d026a  mov [r15+0x88], r14
000075da1b7d0271  mov r11d, [rsp+0x20]
000075da1b7d0276  lea r10d, [r12d+r11d*1]
000075da1b7d027b  lea r11d, [r9d+eax*1]
000075da1b7d0280  mov r11d, r11d
000075da1b7d0283  mov [r15+0xB8], r11
000075da1b7d028a  xor eax, eax
000075da1b7d028c  mov r12d, 0x100
000075da1b7d0292  cmp r14, r12
000075da1b7d0295  cmc
000075da1b7d0296  lahf
000075da1b7d0297  seto al
000075da1b7d029a  mov [r15+0x108], eax
000075da1b7d02a1  lea eax, [r10d+r9d*1]
000075da1b7d02a6  mov eax, eax
000075da1b7d02a8  mov [r15+0xA8], rax
000075da1b7d02af  mov ebp, ebp
000075da1b7d02b1  mov [r15+0xB0], rbp
000075da1b7d02b8  mov eax, [rsp+0x50]
000075da1b7d02bc  mov eax, eax
000075da1b7d02be  mov [r15+0xC0], rax
000075da1b7d02c5  mov edi, edi
000075da1b7d02c7  mov [r15+0xC8], rdi
000075da1b7d02ce  mov eax, [r15+0x108]
000075da1b7d02d5  sahf
000075da1b7d02d6  jnz 0x000075DA1B7D0308
000075da1b7d02d8  cmp dword ptr [r15+0x318], 0x00
000075da1b7d02e0  jz 0x000075DA1B7D0350
000075da1b7d02e6  nop [rax+rax*1], ax
000075da1b7d02ef  nop [rax+rax*1], eax
000075da1b7d02f7  mov eax, 0x41055C
000075da1b7d02fc  mov [r15+0x100], rax
000075da1b7d0303  jmp 0x000075DA1B5FE110
000075da1b7d0308  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0310  jz 0x000075DA1B7D0120
000075da1b7d0316  nop [rax+rax*1], ax
000075da1b7d031f  nop [rax+rax*1], eax
000075da1b7d0327  mov eax, 0x4104D0
000075da1b7d032c  mov [r15+0x100], rax
000075da1b7d0333  jmp 0x000075DA1B5FE110
000075da1b7d0338  int3
000075da1b7d0339  call 0x000075DA1B649010
000075da1b7d033e  jmp 0x000075DA1B7D01CF
000075da1b7d0343  call 0x000075DA1B625930
000075da1b7d0348  jmp 0x000075DA1B7D020C
000075da1b7d034d  int3
000075da1b7d034e  nop
000075da1b7d0350  mov eax, [r15+0x98]
000075da1b7d0357  mov r14d, [r15+0x70]
000075da1b7d035b  lea r12d, [eax+r14d*1]
000075da1b7d0360  mov eax, [r15+0x28]
000075da1b7d0364  mov r14d, [r15+0x68]
000075da1b7d0368  lea r11d, [eax+r14d*1]
000075da1b7d036d  mov qword ptr [r15+0x88], 0x00
000075da1b7d0378  mov eax, [r15+0xA8]
000075da1b7d037f  mov r14d, [r15+0x78]
000075da1b7d0383  lea r10d, [eax+r14d*1]
000075da1b7d0388  mov [rsp+0x10], r10d
000075da1b7d038d  mov r10d, r10d
000075da1b7d0390  mov [r15+0x78], r10
000075da1b7d0394  mov eax, [r15+0x38]
000075da1b7d0398  mov r14d, [r15+0x80]
000075da1b7d039f  lea r10d, [eax+r14d*1]
000075da1b7d03a4  mov [rsp+0x20], r10d
000075da1b7d03a9  mov r10d, r10d
000075da1b7d03ac  mov [r15+0x80], r10
000075da1b7d03b3  mov rax, [r15]
000075da1b7d03b6  lea r14, [rax+0x08]
000075da1b7d03ba  mov [r13+r14*1], r12d
000075da1b7d03bf  lea r14, [rax+0x0C]
000075da1b7d03c3  mov [r13+r14*1], r11d
000075da1b7d03c8  mov r14d, [r15+0xB8]
000075da1b7d03cf  mov r12d, [r15+0x18]
000075da1b7d03d3  lea r11d, [r14d+r12d*1]
000075da1b7d03d8  mov [rsp+0x30], r11d
000075da1b7d03dd  mov r11d, r11d
000075da1b7d03e0  mov [r15+0x68], r11
000075da1b7d03e4  mov r14d, [r15+0x30]
000075da1b7d03e8  mov r12d, [r15+0x90]
000075da1b7d03ef  lea r11d, [r14d+r12d*1]
000075da1b7d03f4  mov [rsp+0x40], r11d
000075da1b7d03f9  mov r11d, r11d
000075da1b7d03fc  mov [r15+0x70], r11
000075da1b7d0400  mov r14d, [r15+0x20]
000075da1b7d0404  mov r12d, [r15+0x58]
000075da1b7d0408  lea r11d, [r14d+r12d*1]
000075da1b7d040d  mov [rsp+0x50], r11d
000075da1b7d0412  mov r11d, r11d
000075da1b7d0415  mov [r15+0x58], r11
000075da1b7d0419  mov r14d, [r15+0xA0]
000075da1b7d0420  mov r12d, [r15+0x60]
000075da1b7d0424  lea r11d, [r14d+r12d*1]
000075da1b7d0429  mov [rsp+0x60], r11d
000075da1b7d042e  mov r11d, r11d
000075da1b7d0431  mov [r15+0x60], r11
000075da1b7d0435  mov r14d, [rsp+0x10]
000075da1b7d043a  mov [r13+rax*1], r14d
000075da1b7d043f  lea r14, [rax+0x04]
000075da1b7d0443  mov r12d, [rsp+0x20]
000075da1b7d0448  mov [r13+r14*1], r12d
000075da1b7d044d  lea r14, [rax+0x10]
000075da1b7d0451  mov r12d, [rsp+0x30]
000075da1b7d0456  mov [r13+r14*1], r12d
000075da1b7d045b  lea r14, [rax+0x14]
000075da1b7d045f  mov r12d, [rsp+0x40]
000075da1b7d0464  mov [r13+r14*1], r12d
000075da1b7d0469  lea r14, [rax+0x18]
000075da1b7d046d  mov r12d, [rsp+0x50]
000075da1b7d0472  mov [r13+r14*1], r12d
000075da1b7d0477  lea r14, [rax+0x1C]
000075da1b7d047b  mov r12d, [rsp+0x60]
000075da1b7d0480  mov [r13+r14*1], r12d
000075da1b7d0485  lea r14, [rax+0x68]
000075da1b7d0489  xor eax, eax
000075da1b7d048b  mov [r13+r14*1], rax
000075da1b7d0490  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0498  jz 0x000075DA1B7CEF90
000075da1b7d049e  nop [rax+rax*1], ax
000075da1b7d04a7  nop [rax+rax*1], eax
000075da1b7d04af  mov eax, 0x410378
000075da1b7d04b4  mov [r15+0x100], rax
000075da1b7d04bb  jmp 0x000075DA1B5FE110
000075da1b7d04c0  int3
000075da1b7d04c1  call 0x000075DA1B6E2BA0
000075da1b7d04c6  jmp 0x000075DA1B7D03BF
000075da1b7d04cb  call 0x000075DA1B6E1920
000075da1b7d04d0  jmp 0x000075DA1B7D03C8
000075da1b7d04d5  call 0x000075DA1B60DFE0
000075da1b7d04da  jmp 0x000075DA1B7D043F
000075da1b7d04df  call 0x000075DA1B6E2BA0
000075da1b7d04e4  jmp 0x000075DA1B7D044D
000075da1b7d04e9  call 0x000075DA1B6E2BA0
000075da1b7d04ee  jmp 0x000075DA1B7D045B
000075da1b7d04f3  call 0x000075DA1B6E2BA0
000075da1b7d04f8  jmp 0x000075DA1B7D0469
000075da1b7d04fd  call 0x000075DA1B6E2BA0
000075da1b7d0502  jmp 0x000075DA1B7D0477
000075da1b7d0507  call 0x000075DA1B6E2BA0
000075da1b7d050c  jmp 0x000075DA1B7D0485
000075da1b7d0511  call 0x000075DA1B6D5EB0
000075da1b7d0516  jmp 0x000075DA1B7D0490
000075da1b7d051b  int3
000075da1b7d051c  nop [rax], eax
000075da1b7d0520  mov rax, [r15+0xF8]
000075da1b7d0527  lea r14, [rax+0x140]
000075da1b7d052e  mov r12, [r13+r14*1]
000075da1b7d0533  lea r14, [rax+0x148]
000075da1b7d053a  mov r11, [r13+r14*1]
000075da1b7d053f  mov [r15+0xA0], r12
000075da1b7d0546  mov [r15+0x98], r11
000075da1b7d054d  lea r14, [rax+0x130]
000075da1b7d0554  mov r12, [r13+r14*1]
000075da1b7d0559  lea r14, [rax+0x138]
000075da1b7d0560  mov r11, [r13+r14*1]
000075da1b7d0565  mov [r15+0xB0], r12
000075da1b7d056c  mov [r15+0xA8], r11
000075da1b7d0573  lea r14, [rax+0x120]
000075da1b7d057a  mov r12, [r13+r14*1]
000075da1b7d057f  lea r14, [rax+0x128]
000075da1b7d0586  mov r11, [r13+r14*1]
000075da1b7d058b  mov [r15+0xC0], r12
000075da1b7d0592  mov [r15+0xB8], r11
000075da1b7d0599  lea r14, [rax+0x110]
000075da1b7d05a0  mov r12, [r13+r14*1]
000075da1b7d05a5  lea r14, [rax+0x118]
000075da1b7d05ac  mov r11, [r13+r14*1]
000075da1b7d05b1  mov [r15+0xD0], r12
000075da1b7d05b8  mov [r15+0xC8], r11
000075da1b7d05bf  lea r14, [rax+0x100]
000075da1b7d05c6  mov r12, [r13+r14*1]
000075da1b7d05cb  lea r14, [rax+0x108]
000075da1b7d05d2  mov r11, [r13+r14*1]
000075da1b7d05d7  mov [r15+0xE8], r12
000075da1b7d05de  mov [r15+0xD8], r11
000075da1b7d05e5  lea r14, [rax+0x150]
000075da1b7d05ec  mov [r15+0xF8], r14
000075da1b7d05f3  mov rax, [r15+0xF0]
000075da1b7d05fa  mov [r15+0x100], rax
000075da1b7d0601  jmp 0x000075DA1B7CE5C0
000075da1b7d0606  int3
000075da1b7d0607  call 0x000075DA1B6E27E0
000075da1b7d060c  jmp 0x000075DA1B7D0533
000075da1b7d0611  call 0x000075DA1B6E1570
000075da1b7d0616  jmp 0x000075DA1B7D053F
000075da1b7d061b  call 0x000075DA1B6E27E0
000075da1b7d0620  jmp 0x000075DA1B7D0559
000075da1b7d0625  call 0x000075DA1B6E1570
000075da1b7d062a  jmp 0x000075DA1B7D0565
000075da1b7d062f  call 0x000075DA1B6E27E0
000075da1b7d0634  jmp 0x000075DA1B7D057F
000075da1b7d0639  call 0x000075DA1B6E1570
000075da1b7d063e  jmp 0x000075DA1B7D058B
000075da1b7d0643  call 0x000075DA1B6E27E0
000075da1b7d0648  jmp 0x000075DA1B7D05A5
000075da1b7d064d  call 0x000075DA1B6E1570
000075da1b7d0652  jmp 0x000075DA1B7D05B1
000075da1b7d0657  call 0x000075DA1B6E27E0
000075da1b7d065c  jmp 0x000075DA1B7D05CB
000075da1b7d0661  call 0x000075DA1B6E1570
000075da1b7d0666  jmp 0x000075DA1B7D05D7
000075da1b7d066b  int3
000075da1b7d066c  nop [rax], eax
000075da1b7d0670  mov eax, [r15+0xA0]
000075da1b7d0677  mov [rsp+0x10], eax
000075da1b7d067b  xor eax, eax
000075da1b7d067d  mov r14d, [rsp+0x10]
000075da1b7d0682  sub r14d, 0x01
000075da1b7d0686  cmc
000075da1b7d0687  lahf
000075da1b7d0688  seto al
000075da1b7d068b  mov [r15+0x108], eax
000075da1b7d0692  mov r14d, r14d
000075da1b7d0695  mov [r15+0xA0], r14
000075da1b7d069c  mov eax, [r15+0x108]
000075da1b7d06a3  sahf
000075da1b7d06a4  jnz 0x000075DA1B7D06D6
000075da1b7d06a6  cmp dword ptr [r15+0x318], 0x00
000075da1b7d06ae  jz 0x000075DA1B7D07A0
000075da1b7d06b4  nop [rax+rax*1], ax
000075da1b7d06bd  nop [rax+rax*1], eax
000075da1b7d06c5  mov eax, 0x41027C
000075da1b7d06ca  mov [r15+0x100], rax
000075da1b7d06d1  jmp 0x000075DA1B5FE110
000075da1b7d06d6  cmp dword ptr [r15+0x318], 0x00
000075da1b7d06de  jz 0x000075DA1B7D0710
000075da1b7d06e4  nop [rax+rax*1], ax
000075da1b7d06ed  nop [rax+rax*1], eax
000075da1b7d06f5  mov eax, 0x410264
000075da1b7d06fa  mov [r15+0x100], rax
000075da1b7d0701  jmp 0x000075DA1B5FE110
000075da1b7d0706  int3
000075da1b7d0707  int3
000075da1b7d0708  nop [rax+rax*1], eax
000075da1b7d0710  mov rax, [r15+0xF8]
000075da1b7d0717  mov [r15], rax
000075da1b7d071a  mov rax, [r15+0x98]
000075da1b7d0721  mov [r15+0x08], rax
000075da1b7d0725  mov qword ptr [r15+0x10], 0x12C
000075da1b7d072d  mov qword ptr [r15+0xF0], 0x410274
000075da1b7d0738  mov r14d, [r15+0x320]
000075da1b7d073f  mov eax, 0x410274
000075da1b7d0744  mov rcx, 0x75DA1B7D0670
000075da1b7d074e  mov [r15+r14*8+0x328], rax
000075da1b7d0756  mov [r15+r14*8+0x368], rcx
000075da1b7d075e  add r14d, 0x01
000075da1b7d0762  and r14d, 0x07
000075da1b7d0766  mov [r15+0x320], r14d
000075da1b7d076d  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0775  jz 0x000075DA1B7CEC20
000075da1b7d077b  nop [rax+rax*1], ax
000075da1b7d0784  nop [rax+rax*1], eax
000075da1b7d078c  mov eax, 0x410338
000075da1b7d0791  mov [r15+0x100], rax
000075da1b7d0798  jmp 0x000075DA1B5FE110
000075da1b7d079d  int3
000075da1b7d079e  int3
000075da1b7d079f  nop
000075da1b7d07a0  mov rax, [r15+0xF8]
000075da1b7d07a7  lea r14, [rax+0x20]
000075da1b7d07ab  mov r12, [r13+r14*1]
000075da1b7d07b0  mov [r15+0x98], r12
000075da1b7d07b7  mov qword ptr [r15+0x40], 0x80
000075da1b7d07bf  mov [r15], rax
000075da1b7d07c2  lea r14, [rax+0x8C]
000075da1b7d07c9  mov [r15+0x08], r14
000075da1b7d07cd  mov qword ptr [r15+0x10], 0x01
000075da1b7d07d5  lea r14, [rax+0x8C]
000075da1b7d07dc  mov eax, 0x80
000075da1b7d07e1  mov [r13+r14*1], al
000075da1b7d07e6  mov qword ptr [r15+0xF0], 0x410298
000075da1b7d07f1  mov r14d, [r15+0x320]
000075da1b7d07f8  mov eax, 0x410298
000075da1b7d07fd  mov rcx, 0x75DA1B7D0870
000075da1b7d0807  mov [r15+r14*8+0x328], rax
000075da1b7d080f  mov [r15+r14*8+0x368], rcx
000075da1b7d0817  add r14d, 0x01
000075da1b7d081b  and r14d, 0x07
000075da1b7d081f  mov [r15+0x320], r14d
000075da1b7d0826  cmp dword ptr [r15+0x318], 0x00
000075da1b7d082e  jz 0x000075DA1B7CEC20
000075da1b7d0834  nop [rax+rax*1], ax
000075da1b7d083d  nop [rax+rax*1], eax
000075da1b7d0845  mov eax, 0x410338
000075da1b7d084a  mov [r15+0x100], rax
000075da1b7d0851  jmp 0x000075DA1B5FE110
000075da1b7d0856  int3
000075da1b7d0857  call 0x000075DA1B6E27E0
000075da1b7d085c  jmp 0x000075DA1B7D07B0
000075da1b7d0861  call 0x000075DA1B6D5AF0
000075da1b7d0866  jmp 0x000075DA1B7D07E6
000075da1b7d086b  int3
000075da1b7d086c  nop [rax], eax
000075da1b7d0870  mov rax, [r15+0xF8]
000075da1b7d0877  lea r14, [rax+0x68]
000075da1b7d087b  mov r12, [r13+r14*1]
000075da1b7d0880  mov [r15+0x40], r12
000075da1b7d0884  lea r14, [rax+0x88]
000075da1b7d088b  xor eax, eax
000075da1b7d088d  mov [r13+r14*1], al
000075da1b7d0892  xor eax, eax
000075da1b7d0894  mov r14d, 0x38
000075da1b7d089a  cmp r12, r14
000075da1b7d089d  cmc
000075da1b7d089e  lahf
000075da1b7d089f  seto al
000075da1b7d08a2  mov [r15+0x108], eax
000075da1b7d08a9  mov eax, [r15+0x108]
000075da1b7d08b0  sahf
000075da1b7d08b1  jz 0x000075DA1B7D08E3
000075da1b7d08b3  cmp dword ptr [r15+0x318], 0x00
000075da1b7d08bb  jz 0x000075DA1B7D0930
000075da1b7d08c1  nop [rax+rax*1], ax
000075da1b7d08ca  nop [rax+rax*1], eax
000075da1b7d08d2  mov eax, 0x4102A8
000075da1b7d08d7  mov [r15+0x100], rax
000075da1b7d08de  jmp 0x000075DA1B5FE110
000075da1b7d08e3  cmp dword ptr [r15+0x318], 0x00
000075da1b7d08eb  jz 0x000075DA1B7D0A70
000075da1b7d08f1  nop [rax+rax*1], ax
000075da1b7d08fa  nop [rax+rax*1], eax
000075da1b7d0902  mov eax, 0x4102C4
000075da1b7d0907  mov [r15+0x100], rax
000075da1b7d090e  jmp 0x000075DA1B5FE110
000075da1b7d0913  int3
000075da1b7d0914  call 0x000075DA1B6E27E0
000075da1b7d0919  jmp 0x000075DA1B7D0880
000075da1b7d091e  call 0x000075DA1B6D5AF0
000075da1b7d0923  jmp 0x000075DA1B7D0892
000075da1b7d0928  int3
000075da1b7d0929  nop [rax], eax
000075da1b7d0930  mov rax, [r15+0xF8]
000075da1b7d0937  mov [r15], rax
000075da1b7d093a  lea r14, [rax+0x88]
000075da1b7d0941  mov [r15+0x08], r14
000075da1b7d0945  mov qword ptr [r15+0x10], 0x01
000075da1b7d094d  mov qword ptr [r15+0xF0], 0x4102B8
000075da1b7d0958  mov r14d, [r15+0x320]
000075da1b7d095f  mov eax, 0x4102B8
000075da1b7d0964  mov rcx, 0x75DA1B7D09C0
000075da1b7d096e  mov [r15+r14*8+0x328], rax
000075da1b7d0976  mov [r15+r14*8+0x368], rcx
000075da1b7d097e  add r14d, 0x01
000075da1b7d0982  and r14d, 0x07
000075da1b7d0986  mov [r15+0x320], r14d
000075da1b7d098d  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0995  jz 0x000075DA1B7CEC20
000075da1b7d099b  nop [rax+rax*1], ax
000075da1b7d09a4  nop [rax+rax*1], eax
000075da1b7d09ac  mov eax, 0x410338
000075da1b7d09b1  mov [r15+0x100], rax
000075da1b7d09b8  jmp 0x000075DA1B5FE110
000075da1b7d09bd  int3
000075da1b7d09be  int3
000075da1b7d09bf  nop
000075da1b7d09c0  mov rax, [r15+0xF8]
000075da1b7d09c7  lea r14, [rax+0x68]
000075da1b7d09cb  mov rax, [r13+r14*1]
000075da1b7d09d0  mov [r15+0x40], rax
000075da1b7d09d4  mov [rsp+0x10], rax
000075da1b7d09d9  xor eax, eax
000075da1b7d09db  mov r14, [rsp+0x10]
000075da1b7d09e0  mov r12d, 0x38
000075da1b7d09e6  cmp r14, r12
000075da1b7d09e9  cmc
000075da1b7d09ea  lahf
000075da1b7d09eb  seto al
000075da1b7d09ee  mov [r15+0x108], eax
000075da1b7d09f5  mov eax, [r15+0x108]
000075da1b7d09fc  sahf
000075da1b7d09fd  jnz 0x000075DA1B7D0A2F
000075da1b7d09ff  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0a07  jz 0x000075DA1B7D0A70
000075da1b7d0a0d  nop [rax+rax*1], ax
000075da1b7d0a16  nop [rax+rax*1], eax
000075da1b7d0a1e  mov eax, 0x4102C4
000075da1b7d0a23  mov [r15+0x100], rax
000075da1b7d0a2a  jmp 0x000075DA1B5FE110
000075da1b7d0a2f  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0a37  jz 0x000075DA1B7D0930
000075da1b7d0a3d  nop [rax+rax*1], ax
000075da1b7d0a46  nop [rax+rax*1], eax
000075da1b7d0a4e  mov eax, 0x4102A8
000075da1b7d0a53  mov [r15+0x100], rax
000075da1b7d0a5a  jmp 0x000075DA1B5FE110
000075da1b7d0a5f  int3
000075da1b7d0a60  call 0x000075DA1B6D59C0
000075da1b7d0a65  jmp 0x000075DA1B7D09D0
000075da1b7d0a6a  int3
000075da1b7d0a6b  nop [rax+rax*1], eax
000075da1b7d0a70  mov rax, [r15+0x98]
000075da1b7d0a77  rorx r14, rax, 0x3D
000075da1b7d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
000075da1b7d0a81  mov rax, [r15+0xF8]
000075da1b7d0a88  mov [r15], rax
000075da1b7d0a8b  lea r12, [rax+0x78]
000075da1b7d0a8f  mov [r15+0x08], r12
000075da1b7d0a93  mov qword ptr [r15+0x10], 0x08
000075da1b7d0a9b  bswap r14
000075da1b7d0a9e  mov [r15+0x40], r14
000075da1b7d0aa2  lea r12, [rax+0x78]
000075da1b7d0aa6  mov [r13+r12*1], r14
000075da1b7d0aab  mov qword ptr [r15+0xF0], 0x4102E0
000075da1b7d0ab6  mov r14d, [r15+0x320]
000075da1b7d0abd  mov eax, 0x4102E0
000075da1b7d0ac2  mov rcx, 0x75DA1B7D0B30
000075da1b7d0acc  mov [r15+r14*8+0x328], rax
000075da1b7d0ad4  mov [r15+r14*8+0x368], rcx
000075da1b7d0adc  add r14d, 0x01
000075da1b7d0ae0  and r14d, 0x07
000075da1b7d0ae4  mov [r15+0x320], r14d
000075da1b7d0aeb  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0af3  jz 0x000075DA1B7CEC20
000075da1b7d0af9  nop [rax+rax*1], ax
000075da1b7d0b02  nop [rax+rax*1], eax
000075da1b7d0b0a  mov eax, 0x410338
000075da1b7d0b0f  mov [r15+0x100], rax
000075da1b7d0b16  jmp 0x000075DA1B5FE110
000075da1b7d0b1b  int3
000075da1b7d0b1c  call 0x000075DA1B6C3FE0
000075da1b7d0b21  jmp 0x000075DA1B7D0AAB
000075da1b7d0b26  int3
000075da1b7d0b27  nop [rax+rax*1], ax
000075da1b7d0b30  mov rax, [r15+0xF8]
000075da1b7d0b37  mov r14d, [r13+rax*1]
000075da1b7d0b3c  lea r12, [rax+0x04]
000075da1b7d0b40  mov r11d, [r13+r12*1]
000075da1b7d0b45  lea r12, [rax+0x08]
000075da1b7d0b49  mov r10d, [r13+r12*1]
000075da1b7d0b4e  lea r12, [rax+0x0C]
000075da1b7d0b52  mov r9d, [r13+r12*1]
000075da1b7d0b57  mov qword ptr [r15+0x48], 0x430860
000075da1b7d0b5f  lea r12, [rax+0x80]
000075da1b7d0b66  mov r8, [r13+r12*1]
000075da1b7d0b6b  mov [r15+0xF0], r8
000075da1b7d0b72  bswap r14d
000075da1b7d0b75  bswap r11d
000075da1b7d0b78  mov r12d, 0x430860
000075da1b7d0b7e  mov [r13+r12*1], r14d
000075da1b7d0b83  mov r14d, 0x430864
000075da1b7d0b89  mov [r13+r14*1], r11d
000075da1b7d0b8e  bswap r10d
000075da1b7d0b91  bswap r9d
000075da1b7d0b94  lea r14, [rax+0x10]
000075da1b7d0b98  mov r12d, [r13+r14*1]
000075da1b7d0b9d  lea r14, [rax+0x14]
000075da1b7d0ba1  mov r11d, [r13+r14*1]
000075da1b7d0ba6  mov r14d, 0x430868
000075da1b7d0bac  mov [r13+r14*1], r10d
000075da1b7d0bb1  mov r14d, 0x43086C
000075da1b7d0bb7  mov [r13+r14*1], r9d
000075da1b7d0bbc  lea r14, [rax+0x90]
000075da1b7d0bc3  mov r10, [r13+r14*1]
000075da1b7d0bc8  lea r14, [rax+0x98]
000075da1b7d0bcf  mov r9, [r13+r14*1]
000075da1b7d0bd4  mov [r15+0xA0], r10
000075da1b7d0bdb  mov [r15+0x98], r9
000075da1b7d0be2  bswap r12d
000075da1b7d0be5  bswap r11d
000075da1b7d0be8  mov [rsp+0x10], r11d
000075da1b7d0bed  mov r11d, r11d
000075da1b7d0bf0  mov [r15+0x58], r11
000075da1b7d0bf4  lea r14, [rax+0x18]
000075da1b7d0bf8  mov r11d, [r13+r14*1]
000075da1b7d0bfd  lea r14, [rax+0x1C]
000075da1b7d0c01  mov r10d, [r13+r14*1]
000075da1b7d0c06  mov [rsp+0x20], r10d
000075da1b7d0c0b  mov r10d, r10d
000075da1b7d0c0e  mov [r15+0x60], r10
000075da1b7d0c12  mov r14d, 0x430870
000075da1b7d0c18  mov [r13+r14*1], r12d
000075da1b7d0c1d  mov r14d, 0x430874
000075da1b7d0c23  mov r12d, [rsp+0x10]
000075da1b7d0c28  mov [r13+r14*1], r12d
000075da1b7d0c2d  bswap r11d
000075da1b7d0c30  mov [rsp+0x10], r11d
000075da1b7d0c35  mov r11d, r11d
000075da1b7d0c38  mov [r15+0x40], r11
000075da1b7d0c3c  mov r14d, [rsp+0x20]
000075da1b7d0c41  bswap r14d
000075da1b7d0c44  mov [rsp+0x20], r14d
000075da1b7d0c49  mov r14d, r14d
000075da1b7d0c4c  mov [r15+0x50], r14
000075da1b7d0c50  mov r14d, 0x430878
000075da1b7d0c56  mov r12d, [rsp+0x10]
000075da1b7d0c5b  mov [r13+r14*1], r12d
000075da1b7d0c60  mov r14d, 0x43087C
000075da1b7d0c66  mov r12d, [rsp+0x20]
000075da1b7d0c6b  mov [r13+r14*1], r12d
000075da1b7d0c70  lea r14, [rax+0xA0]
000075da1b7d0c77  mov [r15+0xF8], r14
000075da1b7d0c7e  mov [r15+0x100], r8
000075da1b7d0c85  jmp 0x000075DA1B7CE5C0
000075da1b7d0c8a  int3
000075da1b7d0c8b  call 0x000075DA1B60DAE0
000075da1b7d0c90  jmp 0x000075DA1B7D0B3C
000075da1b7d0c95  call 0x000075DA1B6C0230
000075da1b7d0c9a  jmp 0x000075DA1B7D0B45
000075da1b7d0c9f  call 0x000075DA1B6BEFC0
000075da1b7d0ca4  jmp 0x000075DA1B7D0B4E
000075da1b7d0ca9  call 0x000075DA1B6BDD50
000075da1b7d0cae  jmp 0x000075DA1B7D0B57
000075da1b7d0cb3  call 0x000075DA1B6BCC20
000075da1b7d0cb8  jmp 0x000075DA1B7D0B6B
000075da1b7d0cbd  call 0x000075DA1B6C3EA0
000075da1b7d0cc2  jmp 0x000075DA1B7D0B83
000075da1b7d0cc7  call 0x000075DA1B6E1920
000075da1b7d0ccc  jmp 0x000075DA1B7D0B8E
000075da1b7d0cd1  call 0x000075DA1B6E26A0
000075da1b7d0cd6  jmp 0x000075DA1B7D0B9D
000075da1b7d0cdb  call 0x000075DA1B6E1430
000075da1b7d0ce0  jmp 0x000075DA1B7D0BA6
000075da1b7d0ce5  call 0x000075DA1B6E06B0
000075da1b7d0cea  jmp 0x000075DA1B7D0BB1
000075da1b7d0cef  call 0x000075DA1B6DF440
000075da1b7d0cf4  jmp 0x000075DA1B7D0BBC
000075da1b7d0cf9  call 0x000075DA1B6E0300
000075da1b7d0cfe  jmp 0x000075DA1B7D0BC8
000075da1b7d0d03  call 0x000075DA1B6DF090
000075da1b7d0d08  jmp 0x000075DA1B7D0BD4
000075da1b7d0d0d  call 0x000075DA1B6E1430
000075da1b7d0d12  jmp 0x000075DA1B7D0BFD
000075da1b7d0d17  call 0x000075DA1B6E01C0
000075da1b7d0d1c  jmp 0x000075DA1B7D0C06
000075da1b7d0d21  call 0x000075DA1B6E2BA0
000075da1b7d0d26  jmp 0x000075DA1B7D0C1D
000075da1b7d0d2b  call 0x000075DA1B6E2BA0
000075da1b7d0d30  jmp 0x000075DA1B7D0C2D
000075da1b7d0d35  call 0x000075DA1B6E2BA0
000075da1b7d0d3a  jmp 0x000075DA1B7D0C60
000075da1b7d0d3f  call 0x000075DA1B6E2BA0
000075da1b7d0d44  jmp 0x000075DA1B7D0C70
000075da1b7d0d49  int3
000075da1b7d0d4a  nop [rax+rax*1], ax
000075da1b7d0d50  mov qword ptr [r15+0x100], 0x04
000075da1b7d0d5b  mov esi, 0x00
000075da1b7d0d60  mov edx, 0x09
000075da1b7d0d65  mov rdi, 0x7FFF13E7F100
000075da1b7d0d6f  mov rax, 0x5872DFE89970
000075da1b7d0d79  call rax
000075da1b7d0d7b  cmp dword ptr [r15+0x318], 0x00
000075da1b7d0d83  jnz 0x000075DA1B5FE110
000075da1b7d0d89  jmp 0x000075DA1B5FE0A0
000075da1b7d0d8e  int3
000075da1b7d0d8f  int3
