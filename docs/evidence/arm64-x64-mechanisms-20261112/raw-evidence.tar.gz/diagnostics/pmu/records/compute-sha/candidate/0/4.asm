
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sha/candidate/0/4.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	add    r13,0x68
  1c:	mov    r14,QWORD PTR [r13+0x0]
  20:	mov    QWORD PTR [r12+0x40],r14
  25:	sub    r14,0x38
  29:	mov    rcx,QWORD PTR [r12+0x380]
  31:	jrcxz  0x38
  33:	jmp    0xed
  38:	pushf
  39:	pop    r11
  3b:	mov    QWORD PTR [rsp],r11
  3f:	jne    0x9d
  45:	jmp    0x4a
  4a:	mov    r13d,0x4102c4
  50:	mov    QWORD PTR [r12+0x100],r13
  58:	mov    r11,QWORD PTR [rsp]
  5c:	mov    QWORD PTR [r12+0x398],r11
  64:	mov    edi,0x4102c4
  69:	mov    QWORD PTR [r12+0x100],rdi
  71:	add    rsp,0x10
  75:	nop    DWORD PTR [rax]
  78:	jmp    QWORD PTR [rip+0x2]        # 0x80
  7e:	xchg   ax,ax
  80:	nop
  81:	sbb    al,dh
  83:	(bad)
  88:	rex sbb eax,esi
  8b:	(bad)
  90:	movabs r11,0x58b3990a40a0
  9a:	jmp    r11
  9d:	mov    r13d,0x4102a8
  a3:	mov    QWORD PTR [r12+0x100],r13
  ab:	mov    r11,QWORD PTR [rsp]
  af:	mov    QWORD PTR [r12+0x398],r11
  b7:	mov    edi,0x4102a8
  bc:	mov    QWORD PTR [r12+0x100],rdi
  c4:	add    rsp,0x10
  c8:	jmp    QWORD PTR [rip+0x2]        # 0xd0
  ce:	xchg   ax,ax
  d0:	jo     0xea
  d2:	lock (bad)
  d8:	nop
  d9:	sbb    eax,esi
  db:	(bad)
  e0:	movabs r11,0x58b3990a40a0
  ea:	jmp    r11
  ed:	mov    eax,0x4102c0
  f2:	mov    QWORD PTR [r12+0x100],rax
  fa:	push   rdx
  fb:	push   rsi
  fc:	push   r10
  fe:	push   r11
 100:	pushf
 101:	pop    r11
 103:	mov    QWORD PTR [rsp+0x20],r11
 108:	mov    rdx,QWORD PTR [rsp+0x20]
 10d:	mov    r10d,edx
 110:	and    r10d,0xc0
 117:	shl    r10d,0x18
 11b:	mov    r11d,edx
 11e:	and    r11d,0x1
 122:	shl    r11d,0x1d
 126:	or     r10d,r11d
 129:	mov    r11d,edx
 12c:	and    r11d,0x800
 133:	shl    r11d,0x11
 137:	or     r10d,r11d
 13a:	btc    r10,0x1d
 13f:	mov    r11d,0xf0000000
 145:	and    r11,r10
 148:	movabs rsi,0xffffffff0fffffff
 152:	and    rbx,rsi
 155:	or     rbx,r11
 158:	pop    r11
 15a:	pop    r10
 15c:	pop    rsi
 15d:	pop    rdx
 15e:	mov    QWORD PTR [r12+0x108],rbx
 166:	add    rsp,0x10
 16a:	mov    eax,0xc
 16f:	movabs r11,0x58b3990a4390
 179:	jmp    r11
