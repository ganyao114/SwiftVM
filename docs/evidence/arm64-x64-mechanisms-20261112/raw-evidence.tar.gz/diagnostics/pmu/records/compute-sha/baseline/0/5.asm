
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sha/baseline/0/5.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x20
   4:	mov    r13,QWORD PTR [r12+0xf8]
   c:	mov    r14,r13
   f:	add    r14,0x4
  13:	mov    r15d,DWORD PTR [r13+0x0]
  17:	mov    ebp,DWORD PTR [r14]
  1a:	mov    QWORD PTR [r12+0x40],r15
  1f:	mov    QWORD PTR [r12+0x50],rbp
  24:	mov    r14,r13
  27:	add    r14,0x8
  2b:	mov    r8,r14
  2e:	add    r8,0x4
  32:	mov    r9d,DWORD PTR [r14]
  35:	mov    r14d,DWORD PTR [r8]
  38:	mov    QWORD PTR [r12+0x58],r9
  3d:	mov    QWORD PTR [r12+0x60],r14
  42:	mov    r14d,0x430860
  48:	mov    QWORD PTR [r12+0x48],r14
  4d:	mov    r14,r13
  50:	add    r14,0x80
  57:	mov    r13,QWORD PTR [r14]
  5a:	mov    QWORD PTR [r12+0xf0],r13
  62:	movabs rcx,0xff00ff00ff00ff
  6c:	mov    r13,r15
  6f:	and    r13,rcx
  72:	mov    r14,r13
  75:	shl    r14,0x8
  79:	movabs rcx,0xff00ff00ff00ff00
  83:	mov    r13,r15
  86:	and    r13,rcx
  89:	mov    r15,r13
  8c:	shr    r15,0x8
  90:	mov    rcx,r14
  93:	mov    r13,r15
  96:	or     r13,rcx
  99:	movabs rcx,0xffff0000ffff
  a3:	mov    r14,r13
  a6:	and    r14,rcx
  a9:	mov    r15,r14
  ac:	shl    r15,0x10
  b0:	movabs rcx,0xffff0000ffff0000
  ba:	mov    r14,r13
  bd:	and    r14,rcx
  c0:	mov    r13,r14
  c3:	shr    r13,0x10
  c7:	mov    rcx,r15
  ca:	mov    r14,r13
  cd:	or     r14,rcx
  d0:	mov    ecx,0xffffffff
  d5:	mov    r13,r14
  d8:	and    r13,rcx
  db:	mov    QWORD PTR [r12+0x40],r13
  e0:	movabs rcx,0xff00ff00ff00ff
  ea:	mov    r14,rbp
  ed:	and    r14,rcx
  f0:	mov    r15,r14
  f3:	shl    r15,0x8
  f7:	movabs rcx,0xff00ff00ff00ff00
 101:	mov    r14,rbp
 104:	and    r14,rcx
 107:	mov    rbp,r14
 10a:	shr    rbp,0x8
 10e:	mov    rcx,r15
 111:	mov    r14,rbp
 114:	or     r14,rcx
 117:	movabs rcx,0xffff0000ffff
 121:	mov    r15,r14
 124:	and    r15,rcx
 127:	mov    rbp,r15
 12a:	shl    rbp,0x10
 12e:	movabs rcx,0xffff0000ffff0000
 138:	mov    r15,r14
 13b:	and    r15,rcx
 13e:	mov    r14,r15
 141:	shr    r14,0x10
 145:	mov    rcx,rbp
 148:	mov    r15,r14
 14b:	or     r15,rcx
 14e:	mov    ecx,0xffffffff
 153:	mov    r14,r15
 156:	and    r14,rcx
 159:	mov    QWORD PTR [r12+0x50],r14
 15e:	mov    r15d,0x430860
 164:	mov    ebp,0x430864
 169:	mov    rax,r13
 16c:	mov    eax,eax
 16e:	mov    r8d,eax
 171:	mov    rax,r14
 174:	mov    eax,eax
 176:	mov    r13d,eax
 179:	mov    DWORD PTR [r15],r8d
 17c:	mov    r14d,0x0
 182:	mov    DWORD PTR [r12+0x32c],r14d
 18a:	mov    DWORD PTR [rbp+0x0],r13d
 18e:	mov    r13d,0x0
 194:	mov    DWORD PTR [r12+0x32c],r13d
 19c:	mov    r13d,DWORD PTR [r12+0x58]
 1a1:	movabs rcx,0xff00ff00ff00ff
 1ab:	mov    r14,r13
 1ae:	and    r14,rcx
 1b1:	mov    r15,r14
 1b4:	shl    r15,0x8
 1b8:	movabs rcx,0xff00ff00ff00ff00
 1c2:	mov    r14,r13
 1c5:	and    r14,rcx
 1c8:	mov    r13,r14
 1cb:	shr    r13,0x8
 1cf:	mov    rcx,r15
 1d2:	mov    r14,r13
 1d5:	or     r14,rcx
 1d8:	movabs rcx,0xffff0000ffff
 1e2:	mov    r13,r14
 1e5:	and    r13,rcx
 1e8:	mov    r15,r13
 1eb:	shl    r15,0x10
 1ef:	movabs rcx,0xffff0000ffff0000
 1f9:	mov    r13,r14
 1fc:	and    r13,rcx
 1ff:	mov    r14,r13
 202:	shr    r14,0x10
 206:	mov    rcx,r15
 209:	mov    r13,r14
 20c:	or     r13,rcx
 20f:	mov    ecx,0xffffffff
 214:	mov    r14,r13
 217:	and    r14,rcx
 21a:	mov    QWORD PTR [r12+0x40],r14
 21f:	mov    r13d,DWORD PTR [r12+0x60]
 224:	movabs rcx,0xff00ff00ff00ff
 22e:	mov    r15,r13
 231:	and    r15,rcx
 234:	mov    rbp,r15
 237:	shl    rbp,0x8
 23b:	movabs rcx,0xff00ff00ff00ff00
 245:	mov    r15,r13
 248:	and    r15,rcx
 24b:	mov    r13,r15
 24e:	shr    r13,0x8
 252:	mov    rcx,rbp
 255:	mov    r15,r13
 258:	or     r15,rcx
 25b:	movabs rcx,0xffff0000ffff
 265:	mov    r13,r15
 268:	and    r13,rcx
 26b:	mov    rbp,r13
 26e:	shl    rbp,0x10
 272:	movabs rcx,0xffff0000ffff0000
 27c:	mov    r13,r15
 27f:	and    r13,rcx
 282:	mov    r15,r13
 285:	shr    r15,0x10
 289:	mov    rcx,rbp
 28c:	mov    r13,r15
 28f:	or     r13,rcx
 292:	mov    ecx,0xffffffff
 297:	mov    r15,r13
 29a:	and    r15,rcx
 29d:	mov    QWORD PTR [r12+0x58],r15
 2a2:	mov    r13,QWORD PTR [r12+0xf8]
 2aa:	mov    rbp,r13
 2ad:	add    rbp,0x10
 2b1:	mov    r8,rbp
 2b4:	add    r8,0x4
 2b8:	mov    eax,DWORD PTR [rbp+0x0]
 2bb:	mov    QWORD PTR [rsp],rax
 2bf:	mov    ebp,DWORD PTR [r8]
 2c2:	mov    rax,QWORD PTR [rsp]
 2c6:	mov    QWORD PTR [r12+0x50],rax
 2cb:	mov    QWORD PTR [r12+0x60],rbp
 2d0:	mov    rbp,QWORD PTR [r12+0x48]
 2d5:	mov    r8,rbp
 2d8:	add    r8,0x8
 2dc:	mov    rbp,r8
 2df:	add    rbp,0x4
 2e3:	mov    rax,r14
 2e6:	mov    eax,eax
 2e8:	mov    r9d,eax
 2eb:	mov    rax,r15
 2ee:	mov    eax,eax
 2f0:	mov    r14d,eax
 2f3:	mov    DWORD PTR [r8],r9d
 2f6:	mov    r15d,0x0
 2fc:	mov    DWORD PTR [r12+0x32c],r15d
 304:	mov    DWORD PTR [rbp+0x0],r14d
 308:	mov    r14d,0x0
 30e:	mov    DWORD PTR [r12+0x32c],r14d
 316:	mov    r14,r13
 319:	add    r14,0x90
 320:	mov    r13,r14
 323:	add    r13,0x8
 327:	mov    r15,QWORD PTR [r14]
 32a:	mov    r14,QWORD PTR [r13+0x0]
 32e:	mov    QWORD PTR [r12+0xa0],r15
 336:	mov    QWORD PTR [r12+0x98],r14
 33e:	movabs rcx,0xff00ff00ff00ff
 348:	mov    r13,QWORD PTR [rsp]
 34c:	and    r13,rcx
 34f:	mov    r14,r13
 352:	shl    r14,0x8
 356:	movabs rcx,0xff00ff00ff00ff00
 360:	mov    r13,QWORD PTR [rsp]
 364:	and    r13,rcx
 367:	mov    r15,r13
 36a:	shr    r15,0x8
 36e:	mov    rcx,r14
 371:	mov    r13,r15
 374:	or     r13,rcx
 377:	movabs rcx,0xffff0000ffff
 381:	mov    r14,r13
 384:	and    r14,rcx
 387:	mov    r15,r14
 38a:	shl    r15,0x10
 38e:	movabs rcx,0xffff0000ffff0000
 398:	mov    r14,r13
 39b:	and    r14,rcx
 39e:	mov    r13,r14
 3a1:	shr    r13,0x10
 3a5:	mov    rcx,r15
 3a8:	mov    r14,r13
 3ab:	or     r14,rcx
 3ae:	mov    ecx,0xffffffff
 3b3:	mov    r13,r14
 3b6:	and    r13,rcx
 3b9:	mov    QWORD PTR [r12+0x40],r13
 3be:	mov    r14d,DWORD PTR [r12+0x60]
 3c3:	movabs rcx,0xff00ff00ff00ff
 3cd:	mov    r15,r14
 3d0:	and    r15,rcx
 3d3:	mov    rbp,r15
 3d6:	shl    rbp,0x8
 3da:	movabs rcx,0xff00ff00ff00ff00
 3e4:	mov    r15,r14
 3e7:	and    r15,rcx
 3ea:	mov    r14,r15
 3ed:	shr    r14,0x8
 3f1:	mov    rcx,rbp
 3f4:	mov    r15,r14
 3f7:	or     r15,rcx
 3fa:	movabs rcx,0xffff0000ffff
 404:	mov    r14,r15
 407:	and    r14,rcx
 40a:	mov    rbp,r14
 40d:	shl    rbp,0x10
 411:	movabs rcx,0xffff0000ffff0000
 41b:	mov    r14,r15
 41e:	and    r14,rcx
 421:	mov    r15,r14
 424:	shr    r15,0x10
 428:	mov    rcx,rbp
 42b:	mov    r14,r15
 42e:	or     r14,rcx
 431:	mov    ecx,0xffffffff
 436:	mov    r15,r14
 439:	and    r15,rcx
 43c:	mov    QWORD PTR [r12+0x58],r15
 441:	mov    r14,QWORD PTR [r12+0xf8]
 449:	mov    rbp,r14
 44c:	add    rbp,0x18
 450:	mov    r14,rbp
 453:	add    r14,0x4
 457:	mov    r8d,DWORD PTR [rbp+0x0]
 45b:	mov    eax,DWORD PTR [r14]
 45e:	mov    QWORD PTR [rsp+0x10],rax
 463:	mov    QWORD PTR [r12+0x50],r8
 468:	mov    rax,QWORD PTR [rsp+0x10]
 46d:	mov    QWORD PTR [r12+0x60],rax
 472:	mov    rax,QWORD PTR [r12+0x48]
 477:	mov    QWORD PTR [rsp+0x8],rax
 47c:	mov    r9,QWORD PTR [rsp+0x8]
 481:	add    r9,0x10
 485:	mov    r14,r9
 488:	add    r14,0x4
 48c:	mov    rax,r13
 48f:	mov    eax,eax
 491:	mov    ebp,eax
 493:	mov    rax,r15
 496:	mov    eax,eax
 498:	mov    r13d,eax
 49b:	mov    DWORD PTR [r9],ebp
 49e:	mov    r15d,0x0
 4a4:	mov    DWORD PTR [r12+0x32c],r15d
 4ac:	mov    DWORD PTR [r14],r13d
 4af:	mov    r13d,0x0
 4b5:	mov    DWORD PTR [r12+0x32c],r13d
 4bd:	movabs rcx,0xff00ff00ff00ff
 4c7:	mov    r13,r8
 4ca:	and    r13,rcx
 4cd:	mov    r14,r13
 4d0:	shl    r14,0x8
 4d4:	movabs rcx,0xff00ff00ff00ff00
 4de:	mov    r13,r8
 4e1:	and    r13,rcx
 4e4:	mov    r15,r13
 4e7:	shr    r15,0x8
 4eb:	mov    rcx,r14
 4ee:	mov    r13,r15
 4f1:	or     r13,rcx
 4f4:	movabs rcx,0xffff0000ffff
 4fe:	mov    r14,r13
 501:	and    r14,rcx
 504:	mov    r15,r14
 507:	shl    r15,0x10
 50b:	movabs rcx,0xffff0000ffff0000
 515:	mov    r14,r13
 518:	and    r14,rcx
 51b:	mov    r13,r14
 51e:	shr    r13,0x10
 522:	mov    rcx,r15
 525:	mov    r14,r13
 528:	or     r14,rcx
 52b:	mov    ecx,0xffffffff
 530:	mov    r13,r14
 533:	and    r13,rcx
 536:	mov    QWORD PTR [r12+0x40],r13
 53b:	movabs rcx,0xff00ff00ff00ff
 545:	mov    r14,QWORD PTR [rsp+0x10]
 54a:	and    r14,rcx
 54d:	mov    r15,r14
 550:	shl    r15,0x8
 554:	movabs rcx,0xff00ff00ff00ff00
 55e:	mov    r14,QWORD PTR [rsp+0x10]
 563:	and    r14,rcx
 566:	mov    rbp,r14
 569:	shr    rbp,0x8
 56d:	mov    rcx,r15
 570:	mov    r14,rbp
 573:	or     r14,rcx
 576:	movabs rcx,0xffff0000ffff
 580:	mov    r15,r14
 583:	and    r15,rcx
 586:	mov    rbp,r15
 589:	shl    rbp,0x10
 58d:	movabs rcx,0xffff0000ffff0000
 597:	mov    r15,r14
 59a:	and    r15,rcx
 59d:	mov    r14,r15
 5a0:	shr    r14,0x10
 5a4:	mov    rcx,rbp
 5a7:	mov    r15,r14
 5aa:	or     r15,rcx
 5ad:	mov    ecx,0xffffffff
 5b2:	mov    r14,r15
 5b5:	and    r14,rcx
 5b8:	mov    QWORD PTR [r12+0x50],r14
 5bd:	mov    r15,QWORD PTR [rsp+0x8]
 5c2:	add    r15,0x18
 5c6:	mov    rbp,r15
 5c9:	add    rbp,0x4
 5cd:	mov    rax,r13
 5d0:	mov    eax,eax
 5d2:	mov    r8d,eax
 5d5:	mov    rax,r14
 5d8:	mov    eax,eax
 5da:	mov    r13d,eax
 5dd:	mov    DWORD PTR [r15],r8d
 5e0:	mov    r14d,0x0
 5e6:	mov    DWORD PTR [r12+0x32c],r14d
 5ee:	mov    DWORD PTR [rbp+0x0],r13d
 5f2:	mov    r13d,0x0
 5f8:	mov    DWORD PTR [r12+0x32c],r13d
 600:	mov    r13,QWORD PTR [r12+0xf8]
 608:	mov    r14,r13
 60b:	add    r14,0xa0
 612:	mov    QWORD PTR [r12+0xf8],r14
 61a:	cmp    QWORD PTR [r12+0x380],0x0
 623:	je     0x654
 629:	mov    eax,0x410334
 62e:	mov    QWORD PTR [r12+0x100],rax
 636:	mov    QWORD PTR [r12+0x108],rbx
 63e:	add    rsp,0x20
 642:	mov    eax,0xc
 647:	movabs r11,0x56b97c5905f0
 651:	jmp    r11
 654:	mov    r13,QWORD PTR [r12+0xf0]
 65c:	mov    QWORD PTR [r12+0x100],r13
 664:	mov    QWORD PTR [r12+0x108],rbx
 66c:	mov    rdi,QWORD PTR [r12+0x100]
 674:	add    rsp,0x20
 678:	movabs r11,0x56b97c590370
 682:	jmp    r11
 685:	nop
 686:	nop
 687:	nop
