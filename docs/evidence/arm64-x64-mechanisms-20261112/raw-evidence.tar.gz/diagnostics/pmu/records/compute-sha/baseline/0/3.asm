
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sha/baseline/0/3.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13,QWORD PTR [r12+0xf8]
   8:	mov    r14,r13
   b:	add    r14,0x68
   f:	mov    r15,QWORD PTR [r14]
  12:	mov    QWORD PTR [r12+0x40],r15
  17:	mov    r14,r13
  1a:	add    r14,0x88
  21:	mov    r13d,0x0
  27:	mov    BYTE PTR [r14],r13b
  2a:	mov    r13d,0x0
  30:	mov    DWORD PTR [r12+0x32c],r13d
  38:	mov    r13,r15
  3b:	sub    r13,0x38
  3f:	pushf
  40:	pop    rdx
  41:	mov    r10d,edx
  44:	and    r10d,0xc0
  4b:	shl    r10d,0x18
  4f:	mov    r11d,edx
  52:	and    r11d,0x1
  56:	shl    r11d,0x1d
  5a:	or     r10d,r11d
  5d:	mov    r11d,edx
  60:	and    r11d,0x800
  67:	shl    r11d,0x11
  6b:	or     r10d,r11d
  6e:	mov    r11d,0xf0000000
  74:	and    r11,r10
  77:	movabs rsi,0xffffffff0fffffff
  81:	and    rbx,rsi
  84:	or     rbx,r11
  87:	btc    rbx,0x1d
  8c:	test   ebx,0x40000000
  92:	jne    0x125
  98:	jmp    0x9d
  9d:	mov    r13,QWORD PTR [r12+0xf8]
  a5:	mov    r14,r13
  a8:	add    r14,0x0
  ac:	mov    QWORD PTR [r12],r14
  b0:	mov    r14,r13
  b3:	add    r14,0x88
  ba:	mov    QWORD PTR [r12+0x8],r14
  bf:	mov    r13d,0x1
  c5:	mov    QWORD PTR [r12+0x10],r13
  ca:	mov    r13d,0x4102b8
  d0:	mov    QWORD PTR [r12+0xf0],r13
  d8:	mov    r13d,0x410338
  de:	mov    QWORD PTR [r12+0x100],r13
  e6:	mov    QWORD PTR [r12+0x108],rbx
  ee:	mov    edi,0x410338
  f3:	mov    QWORD PTR [r12+0x100],rdi
  fb:	nop    DWORD PTR [rax+rax*1+0x0]
 100:	jmp    QWORD PTR [rip+0x2]        # 0x108
 106:	xchg   ax,ax
 108:	add    al,ch
 10a:	rex.WRXB ret
 10c:	add    al,0x79
 10e:	add    BYTE PTR [rax],al
 110:	rex.W (bad)
 112:	push   rax
 113:	ret
 114:	add    al,0x79
 116:	add    BYTE PTR [rax],al
 118:	movabs r11,0x56b97c590370
 122:	jmp    r11
 125:	mov    r13,QWORD PTR [r12+0x98]
 12d:	mov    r14,r13
 130:	ror    r14,0x3d
 134:	mov    r13,r14
 137:	and    r13,0xfffffffffffffff8
 13b:	mov    QWORD PTR [r12+0x40],r13
 140:	mov    r14,QWORD PTR [r12+0xf8]
 148:	mov    r15,r14
 14b:	add    r15,0x0
 14f:	mov    QWORD PTR [r12],r15
 153:	mov    r15,r14
 156:	add    r15,0x78
 15a:	mov    QWORD PTR [r12+0x8],r15
 15f:	mov    r15d,0x8
 165:	mov    QWORD PTR [r12+0x10],r15
 16a:	movabs rcx,0xff00ff00ff00ff
 174:	mov    r15,r13
 177:	and    r15,rcx
 17a:	mov    rbp,r15
 17d:	shl    rbp,0x8
 181:	movabs rcx,0xff00ff00ff00ff00
 18b:	mov    r15,r13
 18e:	and    r15,rcx
 191:	mov    r13,r15
 194:	shr    r13,0x8
 198:	mov    rcx,rbp
 19b:	mov    r15,r13
 19e:	or     r15,rcx
 1a1:	movabs rcx,0xffff0000ffff
 1ab:	mov    r13,r15
 1ae:	and    r13,rcx
 1b1:	mov    rbp,r13
 1b4:	shl    rbp,0x10
 1b8:	movabs rcx,0xffff0000ffff0000
 1c2:	mov    r13,r15
 1c5:	and    r13,rcx
 1c8:	mov    r15,r13
 1cb:	shr    r15,0x10
 1cf:	mov    rcx,rbp
 1d2:	mov    r13,r15
 1d5:	or     r13,rcx
 1d8:	mov    r15,r13
 1db:	shl    r15,0x20
 1df:	mov    rbp,r13
 1e2:	shr    rbp,0x20
 1e6:	mov    rcx,r15
 1e9:	mov    r13,rbp
 1ec:	or     r13,rcx
 1ef:	mov    QWORD PTR [r12+0x40],r13
 1f4:	mov    r15,r14
 1f7:	add    r15,0x78
 1fb:	mov    QWORD PTR [r15],r13
 1fe:	mov    r13d,0x0
 204:	mov    DWORD PTR [r12+0x32c],r13d
 20c:	mov    r13d,0x4102e0
 212:	mov    QWORD PTR [r12+0xf0],r13
 21a:	mov    r13d,0x410338
 220:	mov    QWORD PTR [r12+0x100],r13
 228:	mov    QWORD PTR [r12+0x108],rbx
 230:	mov    edi,0x410338
 235:	mov    QWORD PTR [r12+0x100],rdi
 23d:	nop    DWORD PTR [rax]
 240:	jmp    QWORD PTR [rip+0x2]        # 0x248
 246:	xchg   ax,ax
 248:	add    al,ch
 24a:	rex.WRXB ret
 24c:	add    al,0x79
 24e:	add    BYTE PTR [rax],al
 250:	mov    BYTE PTR [rdi],bl
 252:	push   rax
 253:	ret
 254:	add    al,0x79
 256:	add    BYTE PTR [rax],al
 258:	movabs r11,0x56b97c590370
 262:	jmp    r11
 265:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 270:	jmp    0x9d
 275:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 280:	jmp    0x125
 285:	nop
 286:	nop
 287:	nop
