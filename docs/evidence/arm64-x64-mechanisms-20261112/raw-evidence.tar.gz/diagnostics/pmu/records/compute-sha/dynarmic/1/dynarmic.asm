00007d2f61bce69b  nop [rax+rax*1], eax
00007d2f61bce6a0  mov rax, [r15+0xF8]
00007d2f61bce6a7  lea r14, [rax-0xA0]
00007d2f61bce6ae  mov [r15+0xF8], r14
00007d2f61bce6b5  lea rax, [r14+0x90]
00007d2f61bce6bc  mov r12, [r15+0xA0]
00007d2f61bce6c3  mov r11, [r15+0x98]
00007d2f61bce6ca  mov [r13+rax*1], r12
00007d2f61bce6cf  lea rax, [r14+0x98]
00007d2f61bce6d6  mov [r13+rax*1], r11
00007d2f61bce6db  mov eax, 0x420670
00007d2f61bce6e0  movups xmm1, [r13+rax*1]
00007d2f61bce6e6  mov eax, 0x420610
00007d2f61bce6eb  movups xmm15, [r13+rax*1]
00007d2f61bce6f1  mov eax, 0x420690
00007d2f61bce6f6  movups xmm14, [r13+rax*1]
00007d2f61bce6fc  mov eax, 0x420630
00007d2f61bce701  movups xmm13, [r13+rax*1]
00007d2f61bce707  mov qword ptr [r15+0x98], 0x4308A0
00007d2f61bce712  mov eax, 0x4206A0
00007d2f61bce717  movups xmm12, [r13+rax*1]
00007d2f61bce71d  mov eax, 0x4308A0
00007d2f61bce722  movups [r13+rax*1], xmm1
00007d2f61bce728  mov eax, 0x4308B0
00007d2f61bce72d  movups [r13+rax*1], xmm15
00007d2f61bce733  mov eax, 0x4308C0
00007d2f61bce738  movups [r13+rax*1], xmm14
00007d2f61bce73e  mov eax, 0x4308D0
00007d2f61bce743  movups [r13+rax*1], xmm13
00007d2f61bce749  mov eax, 0x420600
00007d2f61bce74e  movups xmm14, [r13+rax*1]
00007d2f61bce754  mov eax, 0x4205F0
00007d2f61bce759  movups xmm13, [r13+rax*1]
00007d2f61bce75f  mov eax, 0x4309A0
00007d2f61bce764  movups [r13+rax*1], xmm1
00007d2f61bce76a  mov eax, 0x4309B0
00007d2f61bce76f  movups [r13+rax*1], xmm15
00007d2f61bce775  mov eax, 0x4308E0
00007d2f61bce77a  movups [r13+rax*1], xmm12
00007d2f61bce780  mov eax, 0x4308F0
00007d2f61bce785  movups [r13+rax*1], xmm14
00007d2f61bce78b  mov eax, 0x4205E0
00007d2f61bce790  movups xmm1, [r13+rax*1]
00007d2f61bce796  mov eax, 0x420640
00007d2f61bce79b  movups xmm15, [r13+rax*1]
00007d2f61bce7a1  mov eax, 0x430900
00007d2f61bce7a6  movups [r13+rax*1], xmm13
00007d2f61bce7ac  mov eax, 0x430910
00007d2f61bce7b1  movups [r13+rax*1], xmm1
00007d2f61bce7b7  mov eax, 0x420650
00007d2f61bce7bc  movups xmm1, [r13+rax*1]
00007d2f61bce7c2  mov eax, 0x420620
00007d2f61bce7c7  movups xmm14, [r13+rax*1]
00007d2f61bce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007d2f61bce7d5  mov eax, 0x430920
00007d2f61bce7da  movups [r13+rax*1], xmm15
00007d2f61bce7e0  mov eax, 0x430930
00007d2f61bce7e5  movups [r13+rax*1], xmm1
00007d2f61bce7eb  mov eax, 0x4206C0
00007d2f61bce7f0  movups xmm1, [r13+rax*1]
00007d2f61bce7f6  mov eax, 0x4206D0
00007d2f61bce7fb  movups xmm15, [r13+rax*1]
00007d2f61bce801  movaps [r15+0x150], xmm15
00007d2f61bce809  mov qword ptr [r15+0xA0], 0x3E8
00007d2f61bce814  mov eax, 0x430940
00007d2f61bce819  movups [r13+rax*1], xmm14
00007d2f61bce81f  mov eax, 0x430950
00007d2f61bce824  movups [r13+rax*1], xmm1
00007d2f61bce82a  mov eax, 0x4206B0
00007d2f61bce82f  movups xmm1, [r13+rax*1]
00007d2f61bce835  mov eax, 0x420660
00007d2f61bce83a  movups xmm14, [r13+rax*1]
00007d2f61bce840  movaps [r15+0x140], xmm14
00007d2f61bce848  lea rax, [r14+0x80]
00007d2f61bce84f  mov r12, [r15+0xF0]
00007d2f61bce856  mov [r13+rax*1], r12
00007d2f61bce85b  mov eax, 0x430960
00007d2f61bce860  movups [r13+rax*1], xmm15
00007d2f61bce866  mov eax, 0x430970
00007d2f61bce86b  movups [r13+rax*1], xmm1
00007d2f61bce871  mov eax, 0x420680
00007d2f61bce876  movups xmm1, [r13+rax*1]
00007d2f61bce87c  mov eax, 0x4206E0
00007d2f61bce881  mov r12, [r13+rax*1]
00007d2f61bce886  movq xmm15, r12
00007d2f61bce88b  mov qword ptr [r15+0x40], 0x4206E8
00007d2f61bce893  mov eax, 0x430980
00007d2f61bce898  movups [r13+rax*1], xmm14
00007d2f61bce89e  mov eax, 0x430990
00007d2f61bce8a3  movups [r13+rax*1], xmm1
00007d2f61bce8a9  mov eax, 0x420748
00007d2f61bce8ae  movups xmm1, [r13+rax*1]
00007d2f61bce8b4  movq rax, xmm15
00007d2f61bce8b9  mov r12d, 0x4309C0
00007d2f61bce8bf  mov [r13+r12*1], rax
00007d2f61bce8c4  mov eax, 0x420728
00007d2f61bce8c9  movups xmm15, [r13+rax*1]
00007d2f61bce8cf  mov eax, 0x420738
00007d2f61bce8d4  movups xmm14, [r13+rax*1]
00007d2f61bce8da  lea rax, [r14+0x60]
00007d2f61bce8de  movups [r13+rax*1], xmm1
00007d2f61bce8e4  mov eax, 0x4309C8
00007d2f61bce8e9  mov r12d, 0x421DF8D3
00007d2f61bce8ef  mov [r13+rax*1], r12d
00007d2f61bce8f4  lea rax, [r14+0x40]
00007d2f61bce8f8  movups [r13+rax*1], xmm15
00007d2f61bce8fe  lea rax, [r14+0x50]
00007d2f61bce902  movups [r13+rax*1], xmm14
00007d2f61bce908  mov eax, 0x4206E8
00007d2f61bce90d  movups xmm1, [r13+rax*1]
00007d2f61bce913  mov eax, 0x4206F8
00007d2f61bce918  movups xmm15, [r13+rax*1]
00007d2f61bce91e  movaps [r15+0x120], xmm15
00007d2f61bce926  movups [r13+r14*1], xmm1
00007d2f61bce92c  lea rax, [r14+0x10]
00007d2f61bce930  movups [r13+rax*1], xmm15
00007d2f61bce936  mov eax, 0x420708
00007d2f61bce93b  movups xmm1, [r13+rax*1]
00007d2f61bce941  mov eax, 0x420718
00007d2f61bce946  movups xmm15, [r13+rax*1]
00007d2f61bce94c  movaps [r15+0x110], xmm1
00007d2f61bce954  movaps [r15+0x130], xmm15
00007d2f61bce95c  lea rax, [r14+0x20]
00007d2f61bce960  movups [r13+rax*1], xmm1
00007d2f61bce966  lea rax, [r14+0x30]
00007d2f61bce96a  movups [r13+rax*1], xmm15
00007d2f61bce970  mov [r15], r14
00007d2f61bce973  mov qword ptr [r15+0x08], 0x4308A0
00007d2f61bce97b  mov qword ptr [r15+0x10], 0x12C
00007d2f61bce983  mov qword ptr [r15+0xF0], 0x410274
00007d2f61bce98e  mov r14d, [r15+0x320]
00007d2f61bce995  mov eax, 0x410274
00007d2f61bce99a  mov rcx, 0x7D2F61BD0670
00007d2f61bce9a4  mov [r15+r14*8+0x328], rax
00007d2f61bce9ac  mov [r15+r14*8+0x368], rcx
00007d2f61bce9b4  add r14d, 0x01
00007d2f61bce9b8  and r14d, 0x07
00007d2f61bce9bc  mov [r15+0x320], r14d
00007d2f61bce9c3  cmp dword ptr [r15+0x318], 0x00
00007d2f61bce9cb  jz 0x00007D2F61BCEC20
00007d2f61bce9d1  nop [rax+rax*1], ax
00007d2f61bce9da  nop [rax+rax*1], eax
00007d2f61bce9e2  mov eax, 0x410338
00007d2f61bce9e7  mov [r15+0x100], rax
00007d2f61bce9ee  jmp 0x00007D2F619FE110
00007d2f61bce9f3  int3
00007d2f61bce9f4  call 0x00007D2F61A0BC20
00007d2f61bce9f9  jmp 0x00007D2F61BCE6CF
00007d2f61bce9fe  call 0x00007D2F61A0A9A0
00007d2f61bcea03  jmp 0x00007D2F61BCE6DB
00007d2f61bcea08  call 0x00007D2F619FF430
00007d2f61bcea0d  jmp 0x00007D2F61BCE6E6
00007d2f61bcea12  call 0x00007D2F61A0E760
00007d2f61bcea17  jmp 0x00007D2F61BCE6F1
00007d2f61bcea1c  call 0x00007D2F61A0D4E0
00007d2f61bcea21  jmp 0x00007D2F61BCE6FC
00007d2f61bcea26  call 0x00007D2F61A0C260
00007d2f61bcea2b  jmp 0x00007D2F61BCE707
00007d2f61bcea30  call 0x00007D2F61A0AFE0
00007d2f61bcea35  jmp 0x00007D2F61BCE71D
00007d2f61bcea3a  call 0x00007D2F619FF540
00007d2f61bcea3f  jmp 0x00007D2F61BCE728
00007d2f61bcea44  call 0x00007D2F61A0E880
00007d2f61bcea49  jmp 0x00007D2F61BCE733
00007d2f61bcea4e  call 0x00007D2F61A0D600
00007d2f61bcea53  jmp 0x00007D2F61BCE73E
00007d2f61bcea58  call 0x00007D2F61A0C380
00007d2f61bcea5d  jmp 0x00007D2F61BCE749
00007d2f61bcea62  call 0x00007D2F61A0D4E0
00007d2f61bcea67  jmp 0x00007D2F61BCE754
00007d2f61bcea6c  call 0x00007D2F61A0C260
00007d2f61bcea71  jmp 0x00007D2F61BCE75F
00007d2f61bcea76  call 0x00007D2F619FF540
00007d2f61bcea7b  jmp 0x00007D2F61BCE76A
00007d2f61bcea80  call 0x00007D2F61A0E880
00007d2f61bcea85  jmp 0x00007D2F61BCE775
00007d2f61bcea8a  call 0x00007D2F61A0B100
00007d2f61bcea8f  jmp 0x00007D2F61BCE780
00007d2f61bcea94  call 0x00007D2F61A0D600
00007d2f61bcea99  jmp 0x00007D2F61BCE78B
00007d2f61bcea9e  call 0x00007D2F619FF430
00007d2f61bceaa3  jmp 0x00007D2F61BCE796
00007d2f61bceaa8  call 0x00007D2F61A0E760
00007d2f61bceaad  jmp 0x00007D2F61BCE7A1
00007d2f61bceab2  call 0x00007D2F61A0C380
00007d2f61bceab7  jmp 0x00007D2F61BCE7AC
00007d2f61bceabc  call 0x00007D2F619FF540
00007d2f61bceac1  jmp 0x00007D2F61BCE7B7
00007d2f61bceac6  call 0x00007D2F619FF430
00007d2f61bceacb  jmp 0x00007D2F61BCE7C2
00007d2f61bcead0  call 0x00007D2F61A0D4E0
00007d2f61bcead5  jmp 0x00007D2F61BCE7CD
00007d2f61bceada  call 0x00007D2F61A0E880
00007d2f61bceadf  jmp 0x00007D2F61BCE7E0
00007d2f61bceae4  call 0x00007D2F619FF540
00007d2f61bceae9  jmp 0x00007D2F61BCE7EB
00007d2f61bceaee  call 0x00007D2F619FF430
00007d2f61bceaf3  jmp 0x00007D2F61BCE7F6
00007d2f61bceaf8  call 0x00007D2F61A0E760
00007d2f61bceafd  jmp 0x00007D2F61BCE801
00007d2f61bceb02  call 0x00007D2F61A0D600
00007d2f61bceb07  jmp 0x00007D2F61BCE81F
00007d2f61bceb0c  call 0x00007D2F619FF540
00007d2f61bceb11  jmp 0x00007D2F61BCE82A
00007d2f61bceb16  call 0x00007D2F619FF430
00007d2f61bceb1b  jmp 0x00007D2F61BCE835
00007d2f61bceb20  call 0x00007D2F61A0D4E0
00007d2f61bceb25  jmp 0x00007D2F61BCE840
00007d2f61bceb2a  call 0x00007D2F61A0BC20
00007d2f61bceb2f  jmp 0x00007D2F61BCE85B
00007d2f61bceb34  call 0x00007D2F61A0E880
00007d2f61bceb39  jmp 0x00007D2F61BCE866
00007d2f61bceb3e  call 0x00007D2F619FF540
00007d2f61bceb43  jmp 0x00007D2F61BCE871
00007d2f61bceb48  call 0x00007D2F619FF430
00007d2f61bceb4d  jmp 0x00007D2F61BCE87C
00007d2f61bceb52  call 0x00007D2F61A0B720
00007d2f61bceb57  jmp 0x00007D2F61BCE886
00007d2f61bceb5c  call 0x00007D2F61A0D600
00007d2f61bceb61  jmp 0x00007D2F61BCE89E
00007d2f61bceb66  call 0x00007D2F619FF540
00007d2f61bceb6b  jmp 0x00007D2F61BCE8A9
00007d2f61bceb70  call 0x00007D2F619FF430
00007d2f61bceb75  jmp 0x00007D2F61BCE8B4
00007d2f61bceb7a  call 0x00007D2F61AB4CB0
00007d2f61bceb7f  jmp 0x00007D2F61BCE8C4
00007d2f61bceb84  call 0x00007D2F61A0E760
00007d2f61bceb89  jmp 0x00007D2F61BCE8CF
00007d2f61bceb8e  call 0x00007D2F61A0D4E0
00007d2f61bceb93  jmp 0x00007D2F61BCE8DA
00007d2f61bceb98  call 0x00007D2F619FF540
00007d2f61bceb9d  jmp 0x00007D2F61BCE8E4
00007d2f61bceba2  call 0x00007D2F61A0BAE0
00007d2f61bceba7  jmp 0x00007D2F61BCE8F4
00007d2f61bcebac  call 0x00007D2F61A0E880
00007d2f61bcebb1  jmp 0x00007D2F61BCE8FE
00007d2f61bcebb6  call 0x00007D2F61A0D600
00007d2f61bcebbb  jmp 0x00007D2F61BCE908
00007d2f61bcebc0  call 0x00007D2F619FF430
00007d2f61bcebc5  jmp 0x00007D2F61BCE913
00007d2f61bcebca  call 0x00007D2F61A0E760
00007d2f61bcebcf  jmp 0x00007D2F61BCE91E
00007d2f61bcebd4  call 0x00007D2F61AD6600
00007d2f61bcebd9  jmp 0x00007D2F61BCE92C
00007d2f61bcebde  call 0x00007D2F61A0E880
00007d2f61bcebe3  jmp 0x00007D2F61BCE936
00007d2f61bcebe8  call 0x00007D2F619FF430
00007d2f61bcebed  jmp 0x00007D2F61BCE941
00007d2f61bcebf2  call 0x00007D2F61A0E760
00007d2f61bcebf7  jmp 0x00007D2F61BCE94C
00007d2f61bcebfc  call 0x00007D2F619FF540
00007d2f61bcec01  jmp 0x00007D2F61BCE966
00007d2f61bcec06  call 0x00007D2F61A0E880
00007d2f61bcec0b  jmp 0x00007D2F61BCE970
00007d2f61bcec10  int3
00007d2f61bcec11  nop [rax+rax*1], ax
00007d2f61bcec1a  nop [rax+rax*1], ax
00007d2f61bcec20  mov rax, [r15]
00007d2f61bcec23  lea r14, [rax+0x20]
00007d2f61bcec27  mov r12, [r13+r14*1]
00007d2f61bcec2c  mov r14, [r15+0x10]
00007d2f61bcec30  lea r11, [r12+r14*1]
00007d2f61bcec34  mov [r15+0x40], r11
00007d2f61bcec38  lea r12, [rax+0x20]
00007d2f61bcec3c  mov [r13+r12*1], r11
00007d2f61bcec41  test r14, r14
00007d2f61bcec44  setz r14b
00007d2f61bcec48  movzx r14, r14b
00007d2f61bcec4c  mov [rsp+0x414], r14b
00007d2f61bcec54  cmp byte ptr [rsp+0x414], 0x00
00007d2f61bcec5c  jz 0x00007D2F61BCEC8E
00007d2f61bcec5e  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcec66  mov eax, 0x4105B0
00007d2f61bcec6b  mov [r15+0x100], rax
00007d2f61bcec72  jz 0x00007D2F619FE0A0
00007d2f61bcec78  nop [rax+rax*1], eax
00007d2f61bcec7d  mov eax, 0x4105B0
00007d2f61bcec82  mov [r15+0x100], rax
00007d2f61bcec89  jmp 0x00007D2F619FE110
00007d2f61bcec8e  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcec96  jz 0x00007D2F61BCECE0
00007d2f61bcec9c  nop [rax+rax*1], ax
00007d2f61bceca5  nop [rax+rax*1], eax
00007d2f61bcecad  mov eax, 0x410348
00007d2f61bcecb2  mov [r15+0x100], rax
00007d2f61bcecb9  jmp 0x00007D2F619FE110
00007d2f61bcecbe  int3
00007d2f61bcecbf  call 0x00007D2F61AE27E0
00007d2f61bcecc4  jmp 0x00007D2F61BCEC2C
00007d2f61bcecc9  call 0x00007D2F61AC0860
00007d2f61bcecce  jmp 0x00007D2F61BCEC41
00007d2f61bcecd3  int3
00007d2f61bcecd4  nop [rax+rax*1], ax
00007d2f61bcecdd  nop [rax], eax
00007d2f61bcece0  mov rax, [r15+0xF8]
00007d2f61bcece7  lea r14, [rax-0x150]
00007d2f61bcecee  mov [r15+0xF8], r14
00007d2f61bcecf5  mov rax, [r15]
00007d2f61bcecf8  lea r12, [rax+0x68]
00007d2f61bcecfc  mov r11, [r13+r12*1]
00007d2f61bced01  mov [r15+0x88], r11
00007d2f61bced08  lea r12, [rax+0x28]
00007d2f61bced0c  mov [r15+0x40], r12
00007d2f61bced10  mov [r15+0x48], r14
00007d2f61bced14  mov qword ptr [r15+0x50], 0x420758
00007d2f61bced1c  lea rax, [r14+0x100]
00007d2f61bced23  mov r12, [r15+0xE8]
00007d2f61bced2a  mov r11, [r15+0xD8]
00007d2f61bced31  mov [r13+rax*1], r12
00007d2f61bced36  lea rax, [r14+0x108]
00007d2f61bced3d  mov [r13+rax*1], r11
00007d2f61bced42  lea rax, [r14+0x110]
00007d2f61bced49  mov r12, [r15+0xD0]
00007d2f61bced50  mov r11, [r15+0xC8]
00007d2f61bced57  mov [r13+rax*1], r12
00007d2f61bced5c  lea rax, [r14+0x118]
00007d2f61bced63  mov [r13+rax*1], r11
00007d2f61bced68  lea rax, [r14+0x120]
00007d2f61bced6f  mov r12, [r15+0xC0]
00007d2f61bced76  mov r11, [r15+0xB8]
00007d2f61bced7d  mov [r13+rax*1], r12
00007d2f61bced82  lea rax, [r14+0x128]
00007d2f61bced89  mov [r13+rax*1], r11
00007d2f61bced8e  lea rax, [r14+0x130]
00007d2f61bced95  mov r12, [r15+0xB0]
00007d2f61bced9c  mov r11, [r15+0xA8]
00007d2f61bceda3  mov [r13+rax*1], r12
00007d2f61bceda8  lea rax, [r14+0x138]
00007d2f61bcedaf  mov [r13+rax*1], r11
00007d2f61bcedb4  lea rax, [r14+0x140]
00007d2f61bcedbb  mov r12, [r15+0xA0]
00007d2f61bcedc2  mov r11, [r15+0x98]
00007d2f61bcedc9  mov [r13+rax*1], r12
00007d2f61bcedce  lea rax, [r14+0x148]
00007d2f61bcedd5  mov [r13+rax*1], r11
00007d2f61bcedda  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcede2  jz 0x00007D2F61BCEE80
00007d2f61bcede8  nop [rax+rax*1], ax
00007d2f61bcedf1  nop [rax+rax*1], eax
00007d2f61bcedf9  mov eax, 0x410380
00007d2f61bcedfe  mov [r15+0x100], rax
00007d2f61bcee05  jmp 0x00007D2F619FE110
00007d2f61bcee0a  int3
00007d2f61bcee0b  call 0x00007D2F61AC0370
00007d2f61bcee10  jmp 0x00007D2F61BCED01
00007d2f61bcee15  call 0x00007D2F61A0BC20
00007d2f61bcee1a  jmp 0x00007D2F61BCED36
00007d2f61bcee1f  call 0x00007D2F61A0A9A0
00007d2f61bcee24  jmp 0x00007D2F61BCED42
00007d2f61bcee29  call 0x00007D2F61A0BC20
00007d2f61bcee2e  jmp 0x00007D2F61BCED5C
00007d2f61bcee33  call 0x00007D2F61A0A9A0
00007d2f61bcee38  jmp 0x00007D2F61BCED68
00007d2f61bcee3d  call 0x00007D2F61A0BC20
00007d2f61bcee42  jmp 0x00007D2F61BCED82
00007d2f61bcee47  call 0x00007D2F61A0A9A0
00007d2f61bcee4c  jmp 0x00007D2F61BCED8E
00007d2f61bcee51  call 0x00007D2F61A0BC20
00007d2f61bcee56  jmp 0x00007D2F61BCEDA8
00007d2f61bcee5b  call 0x00007D2F61A0A9A0
00007d2f61bcee60  jmp 0x00007D2F61BCEDB4
00007d2f61bcee65  call 0x00007D2F61A0BC20
00007d2f61bcee6a  jmp 0x00007D2F61BCEDCE
00007d2f61bcee6f  call 0x00007D2F61A0A9A0
00007d2f61bcee74  jmp 0x00007D2F61BCEDDA
00007d2f61bcee79  int3
00007d2f61bcee7a  nop [rax+rax*1], ax
00007d2f61bcee80  mov rax, [r15+0x08]
00007d2f61bcee84  movzx r14d, byte ptr [r13+rax*1]
00007d2f61bcee8a  movzx r14d, r14b
00007d2f61bcee8e  mov [rsp+0x10], r14d
00007d2f61bcee93  mov r14d, r14d
00007d2f61bcee96  mov [r15+0x58], r14
00007d2f61bcee9a  lea r14, [rax+0x01]
00007d2f61bcee9e  mov [r15+0x08], r14
00007d2f61bceea2  mov rax, [r15+0x88]
00007d2f61bceea9  lea r14, [rax+0x01]
00007d2f61bceead  mov r12, [r15]
00007d2f61bceeb0  lea r11, [r12+0x68]
00007d2f61bceeb5  mov [r13+r11*1], r14
00007d2f61bceeba  lea r14, [r12+rax*1]
00007d2f61bceebe  mov [r15+0x60], r14
00007d2f61bceec2  lea rax, [r14+0x28]
00007d2f61bceec6  mov r11d, [rsp+0x10]
00007d2f61bceecb  movzx r14d, r11b
00007d2f61bceecf  mov [r13+rax*1], r14b
00007d2f61bceed4  lea rax, [r12+0x68]
00007d2f61bceed9  mov r14, [r13+rax*1]
00007d2f61bceede  mov [r15+0x88], r14
00007d2f61bceee5  xor eax, eax
00007d2f61bceee7  mov r12d, 0x40
00007d2f61bceeed  cmp r14, r12
00007d2f61bceef0  cmc
00007d2f61bceef1  lahf
00007d2f61bceef2  seto al
00007d2f61bceef5  mov [r15+0x108], eax
00007d2f61bceefc  mov eax, [r15+0x108]
00007d2f61bcef03  sahf
00007d2f61bcef04  jnz 0x00007D2F61BCEF36
00007d2f61bcef06  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcef0e  jz 0x00007D2F61BCF020
00007d2f61bcef14  nop [rax+rax*1], ax
00007d2f61bcef1d  nop [rax+rax*1], eax
00007d2f61bcef25  mov eax, 0x4103A0
00007d2f61bcef2a  mov [r15+0x100], rax
00007d2f61bcef31  jmp 0x00007D2F619FE110
00007d2f61bcef36  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcef3e  jz 0x00007D2F61BCEF90
00007d2f61bcef44  nop [rax+rax*1], ax
00007d2f61bcef4d  nop [rax+rax*1], eax
00007d2f61bcef55  mov eax, 0x410378
00007d2f61bcef5a  mov [r15+0x100], rax
00007d2f61bcef61  jmp 0x00007D2F619FE110
00007d2f61bcef66  int3
00007d2f61bcef67  call 0x00007D2F61A0D860
00007d2f61bcef6c  jmp 0x00007D2F61BCEE8A
00007d2f61bcef71  call 0x00007D2F61AB36E0
00007d2f61bcef76  jmp 0x00007D2F61BCEEBA
00007d2f61bcef7b  call 0x00007D2F61A0DD60
00007d2f61bcef80  jmp 0x00007D2F61BCEED4
00007d2f61bcef85  call 0x00007D2F61A0DC20
00007d2f61bcef8a  jmp 0x00007D2F61BCEEDE
00007d2f61bcef8f  int3
00007d2f61bcef90  mov rax, [r15+0x10]
00007d2f61bcef94  lea r14, [rax-0x01]
00007d2f61bcef98  mov [r15+0x10], r14
00007d2f61bcef9c  test r14, r14
00007d2f61bcef9f  setz r14b
00007d2f61bcefa3  movzx r14, r14b
00007d2f61bcefa7  mov [rsp+0x414], r14b
00007d2f61bcefaf  cmp byte ptr [rsp+0x414], 0x00
00007d2f61bcefb7  jz 0x00007D2F61BCEFE9
00007d2f61bcefb9  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcefc1  jz 0x00007D2F61BD0520
00007d2f61bcefc7  nop [rax+rax*1], ax
00007d2f61bcefd0  nop [rax+rax*1], eax
00007d2f61bcefd8  mov eax, 0x410598
00007d2f61bcefdd  mov [r15+0x100], rax
00007d2f61bcefe4  jmp 0x00007D2F619FE110
00007d2f61bcefe9  cmp dword ptr [r15+0x318], 0x00
00007d2f61bceff1  jz 0x00007D2F61BCEE80
00007d2f61bceff7  nop [rax+rax*1], ax
00007d2f61bcf000  nop [rax+rax*1], eax
00007d2f61bcf008  mov eax, 0x410380
00007d2f61bcf00d  mov [r15+0x100], rax
00007d2f61bcf014  jmp 0x00007D2F619FE110
00007d2f61bcf019  int3
00007d2f61bcf01a  int3
00007d2f61bcf01b  nop [rax+rax*1], eax
00007d2f61bcf020  mov rax, [r15+0x40]
00007d2f61bcf024  movzx r14d, byte ptr [r13+rax*1]
00007d2f61bcf02a  movaps xmm1, [r15+0x110]
00007d2f61bcf032  pinsrb xmm1, r14d, 0x00
00007d2f61bcf039  lea r14, [rax+0x01]
00007d2f61bcf03d  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf043  movaps xmm15, [r15+0x120]
00007d2f61bcf04b  pinsrb xmm15, r12d, 0x00
00007d2f61bcf052  lea r14, [rax+0x02]
00007d2f61bcf056  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf05c  movaps xmm14, [r15+0x130]
00007d2f61bcf064  pinsrb xmm14, r12d, 0x00
00007d2f61bcf06b  lea r14, [rax+0x03]
00007d2f61bcf06f  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf075  movaps xmm13, [r15+0x140]
00007d2f61bcf07d  pinsrb xmm13, r12d, 0x00
00007d2f61bcf084  lea r14, [rax+0x04]
00007d2f61bcf088  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf08e  pinsrb xmm1, r12d, 0x01
00007d2f61bcf095  lea r14, [rax+0x05]
00007d2f61bcf099  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf09f  pinsrb xmm15, r12d, 0x01
00007d2f61bcf0a6  lea r14, [rax+0x06]
00007d2f61bcf0aa  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf0b0  pinsrb xmm14, r12d, 0x01
00007d2f61bcf0b7  lea r14, [rax+0x07]
00007d2f61bcf0bb  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf0c1  pinsrb xmm13, r12d, 0x01
00007d2f61bcf0c8  lea r14, [rax+0x08]
00007d2f61bcf0cc  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf0d2  pinsrb xmm1, r12d, 0x02
00007d2f61bcf0d9  lea r14, [rax+0x09]
00007d2f61bcf0dd  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf0e3  pinsrb xmm15, r12d, 0x02
00007d2f61bcf0ea  lea r14, [rax+0x0A]
00007d2f61bcf0ee  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf0f4  pinsrb xmm14, r12d, 0x02
00007d2f61bcf0fb  lea r14, [rax+0x0B]
00007d2f61bcf0ff  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf105  pinsrb xmm13, r12d, 0x02
00007d2f61bcf10c  lea r14, [rax+0x0C]
00007d2f61bcf110  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf116  pinsrb xmm1, r12d, 0x03
00007d2f61bcf11d  lea r14, [rax+0x0D]
00007d2f61bcf121  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf127  pinsrb xmm15, r12d, 0x03
00007d2f61bcf12e  lea r14, [rax+0x0E]
00007d2f61bcf132  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf138  pinsrb xmm14, r12d, 0x03
00007d2f61bcf13f  lea r14, [rax+0x0F]
00007d2f61bcf143  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf149  pinsrb xmm13, r12d, 0x03
00007d2f61bcf150  lea r14, [rax+0x10]
00007d2f61bcf154  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf15a  pinsrb xmm1, r12d, 0x04
00007d2f61bcf161  lea r14, [rax+0x11]
00007d2f61bcf165  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf16b  pinsrb xmm15, r12d, 0x04
00007d2f61bcf172  lea r14, [rax+0x12]
00007d2f61bcf176  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf17c  pinsrb xmm14, r12d, 0x04
00007d2f61bcf183  lea r14, [rax+0x13]
00007d2f61bcf187  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf18d  pinsrb xmm13, r12d, 0x04
00007d2f61bcf194  lea r14, [rax+0x14]
00007d2f61bcf198  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf19e  pinsrb xmm1, r12d, 0x05
00007d2f61bcf1a5  lea r14, [rax+0x15]
00007d2f61bcf1a9  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf1af  pinsrb xmm15, r12d, 0x05
00007d2f61bcf1b6  lea r14, [rax+0x16]
00007d2f61bcf1ba  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf1c0  pinsrb xmm14, r12d, 0x05
00007d2f61bcf1c7  lea r14, [rax+0x17]
00007d2f61bcf1cb  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf1d1  pinsrb xmm13, r12d, 0x05
00007d2f61bcf1d8  lea r14, [rax+0x18]
00007d2f61bcf1dc  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf1e2  pinsrb xmm1, r12d, 0x06
00007d2f61bcf1e9  lea r14, [rax+0x19]
00007d2f61bcf1ed  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf1f3  pinsrb xmm15, r12d, 0x06
00007d2f61bcf1fa  lea r14, [rax+0x1A]
00007d2f61bcf1fe  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf204  pinsrb xmm14, r12d, 0x06
00007d2f61bcf20b  lea r14, [rax+0x1B]
00007d2f61bcf20f  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf215  pinsrb xmm13, r12d, 0x06
00007d2f61bcf21c  lea r14, [rax+0x1C]
00007d2f61bcf220  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf226  pinsrb xmm1, r12d, 0x07
00007d2f61bcf22d  lea r14, [rax+0x1D]
00007d2f61bcf231  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf237  pinsrb xmm15, r12d, 0x07
00007d2f61bcf23e  lea r14, [rax+0x1E]
00007d2f61bcf242  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf248  pinsrb xmm14, r12d, 0x07
00007d2f61bcf24f  lea r14, [rax+0x1F]
00007d2f61bcf253  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf259  pinsrb xmm13, r12d, 0x07
00007d2f61bcf260  lea r14, [rax+0x20]
00007d2f61bcf264  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf26a  pinsrb xmm1, r12d, 0x08
00007d2f61bcf271  lea r14, [rax+0x21]
00007d2f61bcf275  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf27b  pinsrb xmm15, r12d, 0x08
00007d2f61bcf282  lea r14, [rax+0x22]
00007d2f61bcf286  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf28c  pinsrb xmm14, r12d, 0x08
00007d2f61bcf293  lea r14, [rax+0x23]
00007d2f61bcf297  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf29d  pinsrb xmm13, r12d, 0x08
00007d2f61bcf2a4  lea r14, [rax+0x24]
00007d2f61bcf2a8  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf2ae  pinsrb xmm1, r12d, 0x09
00007d2f61bcf2b5  lea r14, [rax+0x25]
00007d2f61bcf2b9  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf2bf  pinsrb xmm15, r12d, 0x09
00007d2f61bcf2c6  lea r14, [rax+0x26]
00007d2f61bcf2ca  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf2d0  pinsrb xmm14, r12d, 0x09
00007d2f61bcf2d7  lea r14, [rax+0x27]
00007d2f61bcf2db  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf2e1  pinsrb xmm13, r12d, 0x09
00007d2f61bcf2e8  lea r14, [rax+0x28]
00007d2f61bcf2ec  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf2f2  pinsrb xmm1, r12d, 0x0A
00007d2f61bcf2f9  lea r14, [rax+0x29]
00007d2f61bcf2fd  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf303  pinsrb xmm15, r12d, 0x0A
00007d2f61bcf30a  lea r14, [rax+0x2A]
00007d2f61bcf30e  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf314  pinsrb xmm14, r12d, 0x0A
00007d2f61bcf31b  lea r14, [rax+0x2B]
00007d2f61bcf31f  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf325  pinsrb xmm13, r12d, 0x0A
00007d2f61bcf32c  lea r14, [rax+0x2C]
00007d2f61bcf330  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf336  pinsrb xmm1, r12d, 0x0B
00007d2f61bcf33d  lea r14, [rax+0x2D]
00007d2f61bcf341  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf347  pinsrb xmm15, r12d, 0x0B
00007d2f61bcf34e  lea r14, [rax+0x2E]
00007d2f61bcf352  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf358  pinsrb xmm14, r12d, 0x0B
00007d2f61bcf35f  lea r14, [rax+0x2F]
00007d2f61bcf363  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf369  pinsrb xmm13, r12d, 0x0B
00007d2f61bcf370  lea r14, [rax+0x30]
00007d2f61bcf374  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf37a  pinsrb xmm1, r12d, 0x0C
00007d2f61bcf381  lea r14, [rax+0x31]
00007d2f61bcf385  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf38b  pinsrb xmm15, r12d, 0x0C
00007d2f61bcf392  lea r14, [rax+0x32]
00007d2f61bcf396  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf39c  pinsrb xmm14, r12d, 0x0C
00007d2f61bcf3a3  lea r14, [rax+0x33]
00007d2f61bcf3a7  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf3ad  pinsrb xmm13, r12d, 0x0C
00007d2f61bcf3b4  lea r14, [rax+0x34]
00007d2f61bcf3b8  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf3be  pinsrb xmm1, r12d, 0x0D
00007d2f61bcf3c5  lea r14, [rax+0x35]
00007d2f61bcf3c9  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf3cf  pinsrb xmm15, r12d, 0x0D
00007d2f61bcf3d6  lea r14, [rax+0x36]
00007d2f61bcf3da  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf3e0  pinsrb xmm14, r12d, 0x0D
00007d2f61bcf3e7  lea r14, [rax+0x37]
00007d2f61bcf3eb  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf3f1  pinsrb xmm13, r12d, 0x0D
00007d2f61bcf3f8  lea r14, [rax+0x38]
00007d2f61bcf3fc  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf402  pinsrb xmm1, r12d, 0x0E
00007d2f61bcf409  lea r14, [rax+0x39]
00007d2f61bcf40d  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf413  pinsrb xmm15, r12d, 0x0E
00007d2f61bcf41a  lea r14, [rax+0x3A]
00007d2f61bcf41e  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf424  pinsrb xmm14, r12d, 0x0E
00007d2f61bcf42b  lea r14, [rax+0x3B]
00007d2f61bcf42f  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf435  pinsrb xmm13, r12d, 0x0E
00007d2f61bcf43c  lea r14, [rax+0x3C]
00007d2f61bcf440  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf446  pinsrb xmm1, r12d, 0x0F
00007d2f61bcf44d  movaps [r15+0x110], xmm1
00007d2f61bcf455  lea r14, [rax+0x3D]
00007d2f61bcf459  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf45f  pinsrb xmm15, r12d, 0x0F
00007d2f61bcf466  movaps [r15+0x120], xmm15
00007d2f61bcf46e  lea r14, [rax+0x3E]
00007d2f61bcf472  movzx r12d, byte ptr [r13+r14*1]
00007d2f61bcf478  pinsrb xmm14, r12d, 0x0F
00007d2f61bcf47f  movaps [r15+0x130], xmm14
00007d2f61bcf487  lea r14, [rax+0x3F]
00007d2f61bcf48b  movzx eax, byte ptr [r13+r14*1]
00007d2f61bcf491  pinsrb xmm13, eax, 0x0F
00007d2f61bcf498  movaps [r15+0x140], xmm13
00007d2f61bcf4a0  movq xmm1, qword ptr [r15+0x120]
00007d2f61bcf4a9  pmovzxbw xmm1, xmm1
00007d2f61bcf4ae  psllw xmm1, 0x00
00007d2f61bcf4b3  movaps [r15+0x150], xmm1
00007d2f61bcf4bb  movq xmm1, qword ptr [r15+0x130]
00007d2f61bcf4c4  pmovzxbw xmm1, xmm1
00007d2f61bcf4c9  psllw xmm1, 0x00
00007d2f61bcf4ce  movaps [r15+0x160], xmm1
00007d2f61bcf4d6  movq xmm1, qword ptr [r15+0x110]
00007d2f61bcf4df  pmovzxbw xmm1, xmm1
00007d2f61bcf4e4  psllw xmm1, 0x00
00007d2f61bcf4e9  movaps [r15+0x170], xmm1
00007d2f61bcf4f1  movaps xmm15, [r15+0x110]
00007d2f61bcf4f9  pextrq rax, xmm15, 0x01
00007d2f61bcf500  movq xmm15, rax
00007d2f61bcf505  pmovzxbw xmm15, xmm15
00007d2f61bcf50b  psllw xmm15, 0x00
00007d2f61bcf511  movaps [r15+0x180], xmm15
00007d2f61bcf519  movaps xmm14, [r15+0x120]
00007d2f61bcf521  pextrq rax, xmm14, 0x01
00007d2f61bcf528  movq xmm14, rax
00007d2f61bcf52d  pmovzxbw xmm14, xmm14
00007d2f61bcf533  psllw xmm14, 0x00
00007d2f61bcf539  movaps [r15+0x210], xmm14
00007d2f61bcf541  movaps xmm13, [r15+0x130]
00007d2f61bcf549  pextrq rax, xmm13, 0x01
00007d2f61bcf550  movq xmm13, rax
00007d2f61bcf555  pmovzxbw xmm13, xmm13
00007d2f61bcf55b  psllw xmm13, 0x00
00007d2f61bcf561  movaps [r15+0x220], xmm13
00007d2f61bcf569  movq xmm12, qword ptr [r15+0x140]
00007d2f61bcf572  pmovzxbw xmm12, xmm12
00007d2f61bcf578  psllw xmm12, 0x00
00007d2f61bcf57e  movaps [r15+0x250], xmm12
00007d2f61bcf586  movaps xmm12, [r15+0x140]
00007d2f61bcf58e  pextrq rax, xmm12, 0x01
00007d2f61bcf595  movq xmm12, rax
00007d2f61bcf59a  pmovzxbw xmm12, xmm12
00007d2f61bcf5a0  psllw xmm12, 0x00
00007d2f61bcf5a6  movaps [r15+0x110], xmm12
00007d2f61bcf5ae  movq xmm11, qword ptr [r15+0x150]
00007d2f61bcf5b7  pmovzxwd xmm11, xmm11
00007d2f61bcf5bd  pslld xmm11, 0x10
00007d2f61bcf5c3  movq xmm10, qword ptr [r15+0x160]
00007d2f61bcf5cc  pmovzxwd xmm10, xmm10
00007d2f61bcf5d2  pslld xmm10, 0x08
00007d2f61bcf5d8  pextrq rax, xmm1, 0x01
00007d2f61bcf5df  movq xmm1, rax
00007d2f61bcf5e4  pmovzxwd xmm1, xmm1
00007d2f61bcf5e9  pslld xmm1, 0x00
00007d2f61bcf5ee  movaps [r15+0x260], xmm1
00007d2f61bcf5f6  pextrq rax, xmm15, 0x01
00007d2f61bcf5fd  movq xmm15, rax
00007d2f61bcf602  pmovzxwd xmm15, xmm15
00007d2f61bcf608  pslld xmm15, 0x00
00007d2f61bcf60e  movaps [r15+0x270], xmm15
00007d2f61bcf616  movq xmm9, qword ptr [r15+0x170]
00007d2f61bcf61f  pmovzxwd xmm9, xmm9
00007d2f61bcf625  pslld xmm9, 0x00
00007d2f61bcf62b  pextrq rax, xmm14, 0x01
00007d2f61bcf632  movq xmm14, rax
00007d2f61bcf637  pmovzxwd xmm14, xmm14
00007d2f61bcf63d  pslld xmm14, 0x10
00007d2f61bcf643  movaps [r15+0x280], xmm14
00007d2f61bcf64b  movq xmm8, qword ptr [r15+0x180]
00007d2f61bcf654  pmovzxwd xmm8, xmm8
00007d2f61bcf65a  pslld xmm8, 0x00
00007d2f61bcf660  movq xmm7, qword ptr [r15+0x210]
00007d2f61bcf669  pmovzxwd xmm7, xmm7
00007d2f61bcf66e  pslld xmm7, 0x10
00007d2f61bcf673  movaps xmm6, [r15+0x150]
00007d2f61bcf67b  pextrq rax, xmm6, 0x01
00007d2f61bcf682  movq xmm6, rax
00007d2f61bcf687  pmovzxwd xmm6, xmm6
00007d2f61bcf68c  pslld xmm6, 0x10
00007d2f61bcf691  por xmm11, xmm10
00007d2f61bcf696  movaps [r15+0x230], xmm11
00007d2f61bcf69e  pextrq rax, xmm13, 0x01
00007d2f61bcf6a5  movq xmm13, rax
00007d2f61bcf6aa  pmovzxwd xmm13, xmm13
00007d2f61bcf6b0  pslld xmm13, 0x08
00007d2f61bcf6b6  movaps [r15+0x240], xmm13
00007d2f61bcf6be  movq xmm10, qword ptr [r15+0x220]
00007d2f61bcf6c7  pmovzxwd xmm10, xmm10
00007d2f61bcf6cd  pslld xmm10, 0x08
00007d2f61bcf6d3  movaps xmm5, [r15+0x160]
00007d2f61bcf6db  pextrq rax, xmm5, 0x01
00007d2f61bcf6e2  movq xmm5, rax
00007d2f61bcf6e7  pmovzxwd xmm5, xmm5
00007d2f61bcf6ec  pslld xmm5, 0x08
00007d2f61bcf6f1  pslld xmm9, 0x18
00007d2f61bcf6f7  pslld xmm15, 0x18
00007d2f61bcf6fd  pslld xmm8, 0x18
00007d2f61bcf703  movq xmm4, qword ptr [r15+0x250]
00007d2f61bcf70c  pmovzxwd xmm4, xmm4
00007d2f61bcf711  pslld xmm4, 0x00
00007d2f61bcf716  por xmm14, xmm13
00007d2f61bcf71b  por xmm7, xmm10
00007d2f61bcf720  movaps [r15+0x210], xmm7
00007d2f61bcf728  pslld xmm1, 0x18
00007d2f61bcf72d  movaps [r15+0x220], xmm1
00007d2f61bcf735  por xmm6, xmm5
00007d2f61bcf739  por xmm11, xmm9
00007d2f61bcf73e  movaps [r15+0x160], xmm11
00007d2f61bcf746  pextrq rax, xmm12, 0x01
00007d2f61bcf74d  movq xmm13, rax
00007d2f61bcf752  pmovzxwd xmm13, xmm13
00007d2f61bcf758  pslld xmm13, 0x00
00007d2f61bcf75e  movaps [r15+0x170], xmm13
00007d2f61bcf766  movq xmm12, qword ptr [r15+0x110]
00007d2f61bcf76f  pmovzxwd xmm12, xmm12
00007d2f61bcf775  pslld xmm12, 0x00
00007d2f61bcf77b  por xmm14, xmm15
00007d2f61bcf780  por xmm7, xmm8
00007d2f61bcf785  movaps xmm15, [r15+0x250]
00007d2f61bcf78d  pextrq rax, xmm15, 0x01
00007d2f61bcf794  movq xmm15, rax
00007d2f61bcf799  pmovzxwd xmm15, xmm15
00007d2f61bcf79f  pslld xmm15, 0x00
00007d2f61bcf7a5  movaps [r15+0x180], xmm15
00007d2f61bcf7ad  por xmm6, xmm1
00007d2f61bcf7b1  movaps [r15+0x150], xmm6
00007d2f61bcf7b9  por xmm11, xmm4
00007d2f61bcf7be  movaps [r15+0x140], xmm11
00007d2f61bcf7c6  por xmm7, xmm12
00007d2f61bcf7cb  movaps [r15+0x110], xmm7
00007d2f61bcf7d3  por xmm14, xmm13
00007d2f61bcf7d8  movaps [r15+0x120], xmm14
00007d2f61bcf7e0  por xmm6, xmm15
00007d2f61bcf7e5  movaps [r15+0x130], xmm6
00007d2f61bcf7ed  mov rax, [r15+0xF8]
00007d2f61bcf7f4  lea r14, [rax+0x20]
00007d2f61bcf7f8  movups [r13+r14*1], xmm7
00007d2f61bcf7fe  lea r14, [rax+0x30]
00007d2f61bcf802  movups [r13+r14*1], xmm14
00007d2f61bcf808  movups [r13+rax*1], xmm11
00007d2f61bcf80e  lea r14, [rax+0x10]
00007d2f61bcf812  movups [r13+r14*1], xmm6
00007d2f61bcf818  mov r14d, [r13+rax*1]
00007d2f61bcf81d  mov rax, [r15+0x48]
00007d2f61bcf821  mov [r15+0x68], rax
00007d2f61bcf825  mov qword ptr [r15+0x58], 0x04
00007d2f61bcf82d  lea r12, [rax+0x04]
00007d2f61bcf831  mov r11d, [r13+r12*1]
00007d2f61bcf836  mov [rsp+0x10], r11d
00007d2f61bcf83b  mov r11d, r11d
00007d2f61bcf83e  mov [r15+0x70], r11
00007d2f61bcf842  lea r12, [rax+0x38]
00007d2f61bcf846  mov r11d, [r13+r12*1]
00007d2f61bcf84b  lea r12, [rax+0x24]
00007d2f61bcf84f  mov r10d, [r13+r12*1]
00007d2f61bcf854  mov [rsp+0x20], r10d
00007d2f61bcf859  mov r10d, r10d
00007d2f61bcf85c  mov [r15+0x90], r10
00007d2f61bcf863  mov [rsp+0x30], rax
00007d2f61bcf868  xor eax, eax
00007d2f61bcf86a  mov r12d, 0x04
00007d2f61bcf870  mov r10d, 0xC0
00007d2f61bcf876  cmp r12, r10
00007d2f61bcf879  cmc
00007d2f61bcf87a  lahf
00007d2f61bcf87b  seto al
00007d2f61bcf87e  mov [r15+0x108], eax
00007d2f61bcf885  mov eax, [rsp+0x10]
00007d2f61bcf889  mov r12d, [rsp+0x10]
00007d2f61bcf88e  shrd eax, r12d, 0x07
00007d2f61bcf893  mov [rsp+0x10], r11d
00007d2f61bcf898  mov r10d, [rsp+0x10]
00007d2f61bcf89d  shrd r11d, r10d, 0x11
00007d2f61bcf8a2  mov r9d, [rsp+0x20]
00007d2f61bcf8a7  lea r8d, [r9d+r14d*1]
00007d2f61bcf8ac  rorx r14d, r12d, 0x12
00007d2f61bcf8b2  xor eax, r14d
00007d2f61bcf8b5  rorx r14d, r10d, 0x13
00007d2f61bcf8bb  xor r11d, r14d
00007d2f61bcf8be  mov [rsp+0x10], r11d
00007d2f61bcf8c3  mov r11d, r11d
00007d2f61bcf8c6  mov [r15+0x88], r11
00007d2f61bcf8cd  mov [rsp+0x20], r12d
00007d2f61bcf8d2  shr r12d, 0x03
00007d2f61bcf8d6  xor eax, r12d
00007d2f61bcf8d9  mov [rsp+0x40], eax
00007d2f61bcf8dd  mov eax, eax
00007d2f61bcf8df  mov [r15+0x80], rax
00007d2f61bcf8e6  shr r10d, 0x0A
00007d2f61bcf8ea  mov eax, [rsp+0x10]
00007d2f61bcf8ee  xor eax, r10d
00007d2f61bcf8f1  mov [rsp+0x10], eax
00007d2f61bcf8f5  mov eax, eax
00007d2f61bcf8f7  mov [r15+0x78], rax
00007d2f61bcf8fb  mov eax, [rsp+0x40]
00007d2f61bcf8ff  lea r14d, [r8d+eax*1]
00007d2f61bcf904  mov eax, [rsp+0x10]
00007d2f61bcf908  lea r12d, [r14d+eax*1]
00007d2f61bcf90d  mov rax, [rsp+0x30]
00007d2f61bcf912  lea r14, [rax+0x40]
00007d2f61bcf916  mov [r13+r14*1], r12d
00007d2f61bcf91b  mov eax, [rsp+0x20]
00007d2f61bcf91f  mov eax, eax
00007d2f61bcf921  mov [r15+0x60], rax
00007d2f61bcf925  mov eax, [r15+0x108]
00007d2f61bcf92c  sahf
00007d2f61bcf92d  jnz 0x00007D2F61BCF95F
00007d2f61bcf92f  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcf937  jz 0x00007D2F61BCFE20
00007d2f61bcf93d  nop [rax+rax*1], ax
00007d2f61bcf946  nop [rax+rax*1], eax
00007d2f61bcf94e  mov eax, 0x41049C
00007d2f61bcf953  mov [r15+0x100], rax
00007d2f61bcf95a  jmp 0x00007D2F619FE110
00007d2f61bcf95f  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcf967  jz 0x00007D2F61BCFC70
00007d2f61bcf96d  nop [rax+rax*1], ax
00007d2f61bcf976  nop [rax+rax*1], eax
00007d2f61bcf97e  mov eax, 0x410454
00007d2f61bcf983  mov [r15+0x100], rax
00007d2f61bcf98a  jmp 0x00007D2F619FE110
00007d2f61bcf98f  int3
00007d2f61bcf990  call 0x00007D2F61A0D860
00007d2f61bcf995  jmp 0x00007D2F61BCF02A
00007d2f61bcf99a  call 0x00007D2F61AE2420
00007d2f61bcf99f  jmp 0x00007D2F61BCF043
00007d2f61bcf9a4  call 0x00007D2F61AE2420
00007d2f61bcf9a9  jmp 0x00007D2F61BCF05C
00007d2f61bcf9ae  call 0x00007D2F61AE2420
00007d2f61bcf9b3  jmp 0x00007D2F61BCF075
00007d2f61bcf9b8  call 0x00007D2F61AE2420
00007d2f61bcf9bd  jmp 0x00007D2F61BCF08E
00007d2f61bcf9c2  call 0x00007D2F61AE2420
00007d2f61bcf9c7  jmp 0x00007D2F61BCF09F
00007d2f61bcf9cc  call 0x00007D2F61AE2420
00007d2f61bcf9d1  jmp 0x00007D2F61BCF0B0
00007d2f61bcf9d6  call 0x00007D2F61AE2420
00007d2f61bcf9db  jmp 0x00007D2F61BCF0C1
00007d2f61bcf9e0  call 0x00007D2F61AE2420
00007d2f61bcf9e5  jmp 0x00007D2F61BCF0D2
00007d2f61bcf9ea  call 0x00007D2F61AE2420
00007d2f61bcf9ef  jmp 0x00007D2F61BCF0E3
00007d2f61bcf9f4  call 0x00007D2F61AE2420
00007d2f61bcf9f9  jmp 0x00007D2F61BCF0F4
00007d2f61bcf9fe  call 0x00007D2F61AE2420
00007d2f61bcfa03  jmp 0x00007D2F61BCF105
00007d2f61bcfa08  call 0x00007D2F61AE2420
00007d2f61bcfa0d  jmp 0x00007D2F61BCF116
00007d2f61bcfa12  call 0x00007D2F61AE2420
00007d2f61bcfa17  jmp 0x00007D2F61BCF127
00007d2f61bcfa1c  call 0x00007D2F61AE2420
00007d2f61bcfa21  jmp 0x00007D2F61BCF138
00007d2f61bcfa26  call 0x00007D2F61AE2420
00007d2f61bcfa2b  jmp 0x00007D2F61BCF149
00007d2f61bcfa30  call 0x00007D2F61AE2420
00007d2f61bcfa35  jmp 0x00007D2F61BCF15A
00007d2f61bcfa3a  call 0x00007D2F61AE2420
00007d2f61bcfa3f  jmp 0x00007D2F61BCF16B
00007d2f61bcfa44  call 0x00007D2F61AE2420
00007d2f61bcfa49  jmp 0x00007D2F61BCF17C
00007d2f61bcfa4e  call 0x00007D2F61AE2420
00007d2f61bcfa53  jmp 0x00007D2F61BCF18D
00007d2f61bcfa58  call 0x00007D2F61AE2420
00007d2f61bcfa5d  jmp 0x00007D2F61BCF19E
00007d2f61bcfa62  call 0x00007D2F61AE2420
00007d2f61bcfa67  jmp 0x00007D2F61BCF1AF
00007d2f61bcfa6c  call 0x00007D2F61AE2420
00007d2f61bcfa71  jmp 0x00007D2F61BCF1C0
00007d2f61bcfa76  call 0x00007D2F61AE2420
00007d2f61bcfa7b  jmp 0x00007D2F61BCF1D1
00007d2f61bcfa80  call 0x00007D2F61AE2420
00007d2f61bcfa85  jmp 0x00007D2F61BCF1E2
00007d2f61bcfa8a  call 0x00007D2F61AE2420
00007d2f61bcfa8f  jmp 0x00007D2F61BCF1F3
00007d2f61bcfa94  call 0x00007D2F61AE2420
00007d2f61bcfa99  jmp 0x00007D2F61BCF204
00007d2f61bcfa9e  call 0x00007D2F61AE2420
00007d2f61bcfaa3  jmp 0x00007D2F61BCF215
00007d2f61bcfaa8  call 0x00007D2F61AE2420
00007d2f61bcfaad  jmp 0x00007D2F61BCF226
00007d2f61bcfab2  call 0x00007D2F61AE2420
00007d2f61bcfab7  jmp 0x00007D2F61BCF237
00007d2f61bcfabc  call 0x00007D2F61AE2420
00007d2f61bcfac1  jmp 0x00007D2F61BCF248
00007d2f61bcfac6  call 0x00007D2F61AE2420
00007d2f61bcfacb  jmp 0x00007D2F61BCF259
00007d2f61bcfad0  call 0x00007D2F61AE2420
00007d2f61bcfad5  jmp 0x00007D2F61BCF26A
00007d2f61bcfada  call 0x00007D2F61AE2420
00007d2f61bcfadf  jmp 0x00007D2F61BCF27B
00007d2f61bcfae4  call 0x00007D2F61AE2420
00007d2f61bcfae9  jmp 0x00007D2F61BCF28C
00007d2f61bcfaee  call 0x00007D2F61AE2420
00007d2f61bcfaf3  jmp 0x00007D2F61BCF29D
00007d2f61bcfaf8  call 0x00007D2F61AE2420
00007d2f61bcfafd  jmp 0x00007D2F61BCF2AE
00007d2f61bcfb02  call 0x00007D2F61AE2420
00007d2f61bcfb07  jmp 0x00007D2F61BCF2BF
00007d2f61bcfb0c  call 0x00007D2F61AE2420
00007d2f61bcfb11  jmp 0x00007D2F61BCF2D0
00007d2f61bcfb16  call 0x00007D2F61AE2420
00007d2f61bcfb1b  jmp 0x00007D2F61BCF2E1
00007d2f61bcfb20  call 0x00007D2F61AE2420
00007d2f61bcfb25  jmp 0x00007D2F61BCF2F2
00007d2f61bcfb2a  call 0x00007D2F61AE2420
00007d2f61bcfb2f  jmp 0x00007D2F61BCF303
00007d2f61bcfb34  call 0x00007D2F61AE2420
00007d2f61bcfb39  jmp 0x00007D2F61BCF314
00007d2f61bcfb3e  call 0x00007D2F61AE2420
00007d2f61bcfb43  jmp 0x00007D2F61BCF325
00007d2f61bcfb48  call 0x00007D2F61AE2420
00007d2f61bcfb4d  jmp 0x00007D2F61BCF336
00007d2f61bcfb52  call 0x00007D2F61AE2420
00007d2f61bcfb57  jmp 0x00007D2F61BCF347
00007d2f61bcfb5c  call 0x00007D2F61AE2420
00007d2f61bcfb61  jmp 0x00007D2F61BCF358
00007d2f61bcfb66  call 0x00007D2F61AE2420
00007d2f61bcfb6b  jmp 0x00007D2F61BCF369
00007d2f61bcfb70  call 0x00007D2F61AE2420
00007d2f61bcfb75  jmp 0x00007D2F61BCF37A
00007d2f61bcfb7a  call 0x00007D2F61AE2420
00007d2f61bcfb7f  jmp 0x00007D2F61BCF38B
00007d2f61bcfb84  call 0x00007D2F61AE2420
00007d2f61bcfb89  jmp 0x00007D2F61BCF39C
00007d2f61bcfb8e  call 0x00007D2F61AE2420
00007d2f61bcfb93  jmp 0x00007D2F61BCF3AD
00007d2f61bcfb98  call 0x00007D2F61AE2420
00007d2f61bcfb9d  jmp 0x00007D2F61BCF3BE
00007d2f61bcfba2  call 0x00007D2F61AE2420
00007d2f61bcfba7  jmp 0x00007D2F61BCF3CF
00007d2f61bcfbac  call 0x00007D2F61AE2420
00007d2f61bcfbb1  jmp 0x00007D2F61BCF3E0
00007d2f61bcfbb6  call 0x00007D2F61AE2420
00007d2f61bcfbbb  jmp 0x00007D2F61BCF3F1
00007d2f61bcfbc0  call 0x00007D2F61AE2420
00007d2f61bcfbc5  jmp 0x00007D2F61BCF402
00007d2f61bcfbca  call 0x00007D2F61AE2420
00007d2f61bcfbcf  jmp 0x00007D2F61BCF413
00007d2f61bcfbd4  call 0x00007D2F61AE2420
00007d2f61bcfbd9  jmp 0x00007D2F61BCF424
00007d2f61bcfbde  call 0x00007D2F61AE2420
00007d2f61bcfbe3  jmp 0x00007D2F61BCF435
00007d2f61bcfbe8  call 0x00007D2F61AE2420
00007d2f61bcfbed  jmp 0x00007D2F61BCF446
00007d2f61bcfbf2  call 0x00007D2F61AE2420
00007d2f61bcfbf7  jmp 0x00007D2F61BCF45F
00007d2f61bcfbfc  call 0x00007D2F61AE2420
00007d2f61bcfc01  jmp 0x00007D2F61BCF478
00007d2f61bcfc06  call 0x00007D2F61AD5610
00007d2f61bcfc0b  jmp 0x00007D2F61BCF491
00007d2f61bcfc10  call 0x00007D2F61ADC580
00007d2f61bcfc15  jmp 0x00007D2F61BCF7FE
00007d2f61bcfc1a  call 0x00007D2F61AE46C0
00007d2f61bcfc1f  jmp 0x00007D2F61BCF808
00007d2f61bcfc24  call 0x00007D2F61A09E90
00007d2f61bcfc29  jmp 0x00007D2F61BCF80E
00007d2f61bcfc2e  call 0x00007D2F61ADB310
00007d2f61bcfc33  jmp 0x00007D2F61BCF818
00007d2f61bcfc38  call 0x00007D2F61A0DAE0
00007d2f61bcfc3d  jmp 0x00007D2F61BCF81D
00007d2f61bcfc42  call 0x00007D2F61AC0230
00007d2f61bcfc47  jmp 0x00007D2F61BCF836
00007d2f61bcfc4c  call 0x00007D2F61AC0230
00007d2f61bcfc51  jmp 0x00007D2F61BCF84B
00007d2f61bcfc56  call 0x00007D2F61ABEFC0
00007d2f61bcfc5b  jmp 0x00007D2F61BCF854
00007d2f61bcfc60  call 0x00007D2F61AE2BA0
00007d2f61bcfc65  jmp 0x00007D2F61BCF91B
00007d2f61bcfc6a  int3
00007d2f61bcfc6b  nop [rax+rax*1], eax
00007d2f61bcfc70  mov rax, [r15+0x48]
00007d2f61bcfc74  mov r14, [r15+0x58]
00007d2f61bcfc78  lea r12, [rax+r14*1]
00007d2f61bcfc7c  mov [r15+0x68], r12
00007d2f61bcfc80  lea rax, [r14+0x04]
00007d2f61bcfc84  mov [r15+0x58], rax
00007d2f61bcfc88  lea r14, [r12+0x04]
00007d2f61bcfc8d  mov r11d, [r13+r14*1]
00007d2f61bcfc92  mov [rsp+0x10], r11d
00007d2f61bcfc97  mov r11d, r11d
00007d2f61bcfc9a  mov [r15+0x70], r11
00007d2f61bcfc9e  lea r14, [r12+0x38]
00007d2f61bcfca3  mov r11d, [r13+r14*1]
00007d2f61bcfca8  lea r14, [r12+0x24]
00007d2f61bcfcad  mov r10d, [r13+r14*1]
00007d2f61bcfcb2  mov [rsp+0x20], r10d
00007d2f61bcfcb7  mov r10d, r10d
00007d2f61bcfcba  mov [r15+0x90], r10
00007d2f61bcfcc1  mov [rsp+0x30], rax
00007d2f61bcfcc6  xor eax, eax
00007d2f61bcfcc8  mov r14, [rsp+0x30]
00007d2f61bcfccd  mov r10d, 0xC0
00007d2f61bcfcd3  cmp r14, r10
00007d2f61bcfcd6  cmc
00007d2f61bcfcd7  lahf
00007d2f61bcfcd8  seto al
00007d2f61bcfcdb  mov [r15+0x108], eax
00007d2f61bcfce2  mov eax, [rsp+0x10]
00007d2f61bcfce6  mov r14d, [rsp+0x10]
00007d2f61bcfceb  shrd eax, r14d, 0x07
00007d2f61bcfcf0  mov [rsp+0x10], r11d
00007d2f61bcfcf5  mov r10d, [rsp+0x10]
00007d2f61bcfcfa  shrd r11d, r10d, 0x11
00007d2f61bcfcff  mov r9d, [r15+0x60]
00007d2f61bcfd03  mov r8d, [rsp+0x20]
00007d2f61bcfd08  lea ebp, [r8d+r9d*1]
00007d2f61bcfd0d  rorx r9d, r14d, 0x12
00007d2f61bcfd13  xor eax, r9d
00007d2f61bcfd16  rorx r9d, r10d, 0x13
00007d2f61bcfd1c  xor r11d, r9d
00007d2f61bcfd1f  mov [rsp+0x10], r11d
00007d2f61bcfd24  mov r11d, r11d
00007d2f61bcfd27  mov [r15+0x88], r11
00007d2f61bcfd2e  mov [rsp+0x20], r14d
00007d2f61bcfd33  shr r14d, 0x03
00007d2f61bcfd37  xor eax, r14d
00007d2f61bcfd3a  mov [rsp+0x30], eax
00007d2f61bcfd3e  mov eax, eax
00007d2f61bcfd40  mov [r15+0x80], rax
00007d2f61bcfd47  shr r10d, 0x0A
00007d2f61bcfd4b  mov eax, [rsp+0x10]
00007d2f61bcfd4f  xor eax, r10d
00007d2f61bcfd52  mov [rsp+0x10], eax
00007d2f61bcfd56  mov eax, eax
00007d2f61bcfd58  mov [r15+0x78], rax
00007d2f61bcfd5c  mov eax, [rsp+0x30]
00007d2f61bcfd60  lea r14d, [ebp+eax*1]
00007d2f61bcfd66  mov eax, [rsp+0x10]
00007d2f61bcfd6a  lea r11d, [r14d+eax*1]
00007d2f61bcfd6f  lea rax, [r12+0x40]
00007d2f61bcfd74  mov [r13+rax*1], r11d
00007d2f61bcfd79  mov eax, [rsp+0x20]
00007d2f61bcfd7d  mov eax, eax
00007d2f61bcfd7f  mov [r15+0x60], rax
00007d2f61bcfd83  mov eax, [r15+0x108]
00007d2f61bcfd8a  sahf
00007d2f61bcfd8b  jnz 0x00007D2F61BCFDBD
00007d2f61bcfd8d  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcfd95  jz 0x00007D2F61BCFE20
00007d2f61bcfd9b  nop [rax+rax*1], ax
00007d2f61bcfda4  nop [rax+rax*1], eax
00007d2f61bcfdac  mov eax, 0x41049C
00007d2f61bcfdb1  mov [r15+0x100], rax
00007d2f61bcfdb8  jmp 0x00007D2F619FE110
00007d2f61bcfdbd  cmp dword ptr [r15+0x318], 0x00
00007d2f61bcfdc5  jz 0x00007D2F61BCFC70
00007d2f61bcfdcb  nop [rax+rax*1], ax
00007d2f61bcfdd4  nop [rax+rax*1], eax
00007d2f61bcfddc  mov eax, 0x410454
00007d2f61bcfde1  mov [r15+0x100], rax
00007d2f61bcfde8  jmp 0x00007D2F619FE110
00007d2f61bcfded  int3
00007d2f61bcfdee  call 0x00007D2F61AE1430
00007d2f61bcfdf3  jmp 0x00007D2F61BCFC92
00007d2f61bcfdf8  call 0x00007D2F61AE1430
00007d2f61bcfdfd  jmp 0x00007D2F61BCFCA8
00007d2f61bcfe02  call 0x00007D2F61AE01C0
00007d2f61bcfe07  jmp 0x00007D2F61BCFCB2
00007d2f61bcfe0c  call 0x00007D2F61A0A860
00007d2f61bcfe11  jmp 0x00007D2F61BCFD79
00007d2f61bcfe16  int3
00007d2f61bcfe17  nop [rax+rax*1], ax
00007d2f61bcfe20  mov rax, [r15]
00007d2f61bcfe23  mov r14d, [r13+rax*1]
00007d2f61bcfe28  lea r12, [rax+0x04]
00007d2f61bcfe2c  mov r11d, [r13+r12*1]
00007d2f61bcfe31  mov [rsp+0x10], r14d
00007d2f61bcfe36  mov r14d, r14d
00007d2f61bcfe39  mov [r15+0x78], r14
00007d2f61bcfe3d  mov [rsp+0x20], r11d
00007d2f61bcfe42  mov r11d, r11d
00007d2f61bcfe45  mov [r15+0x80], r11
00007d2f61bcfe4c  lea r14, [rax+0x08]
00007d2f61bcfe50  mov r12d, [r13+r14*1]
00007d2f61bcfe55  lea r14, [rax+0x0C]
00007d2f61bcfe59  mov r11d, [r13+r14*1]
00007d2f61bcfe5e  mov [rsp+0x30], r12d
00007d2f61bcfe63  mov r12d, r12d
00007d2f61bcfe66  mov [r15+0x70], r12
00007d2f61bcfe6a  mov [rsp+0x40], r11d
00007d2f61bcfe6f  mov r11d, r11d
00007d2f61bcfe72  mov [r15+0x68], r11
00007d2f61bcfe76  lea r14, [rax+0x18]
00007d2f61bcfe7a  mov r12d, [r13+r14*1]
00007d2f61bcfe7f  lea r14, [rax+0x1C]
00007d2f61bcfe83  mov r11d, [r13+r14*1]
00007d2f61bcfe88  mov [rsp+0x50], r12d
00007d2f61bcfe8d  mov r12d, r12d
00007d2f61bcfe90  mov [r15+0x58], r12
00007d2f61bcfe94  mov [rsp+0x60], r11d
00007d2f61bcfe99  mov r11d, r11d
00007d2f61bcfe9c  mov [r15+0x60], r11
00007d2f61bcfea0  lea r14, [rax+0x10]
00007d2f61bcfea4  mov r12d, [r13+r14*1]
00007d2f61bcfea9  lea r14, [rax+0x14]
00007d2f61bcfead  mov eax, [r13+r14*1]
00007d2f61bcfeb2  mov [rsp+0x70], r12d
00007d2f61bcfeb7  mov r12d, r12d
00007d2f61bcfeba  mov [r15+0x18], r12
00007d2f61bcfebe  mov [rsp+0x80], eax
00007d2f61bcfec5  mov eax, eax
00007d2f61bcfec7  mov [r15+0x90], rax
00007d2f61bcfece  mov eax, [rsp+0x70]
00007d2f61bcfed2  mov eax, eax
00007d2f61bcfed4  mov [r15+0x30], rax
00007d2f61bcfed8  mov eax, [rsp+0x50]
00007d2f61bcfedc  mov eax, eax
00007d2f61bcfede  mov [r15+0xA0], rax
00007d2f61bcfee5  mov eax, [rsp+0x30]
00007d2f61bcfee9  mov eax, eax
00007d2f61bcfeeb  mov [r15+0x28], rax
00007d2f61bcfeef  mov eax, [rsp+0x20]
00007d2f61bcfef3  mov eax, eax
00007d2f61bcfef5  mov [r15+0x98], rax
00007d2f61bcfefc  mov eax, [rsp+0x10]
00007d2f61bcff00  mov eax, eax
00007d2f61bcff02  mov [r15+0x38], rax
00007d2f61bcff06  mov eax, [rsp+0x70]
00007d2f61bcff0a  mov r14d, [rsp+0x70]
00007d2f61bcff0f  shrd eax, r14d, 0x06
00007d2f61bcff14  mov [rsp+0x70], r14d
00007d2f61bcff19  mov r12d, [rsp+0x80]
00007d2f61bcff21  and r14d, r12d
00007d2f61bcff24  mov r11d, [rsp+0x10]
00007d2f61bcff29  mov r10d, [rsp+0x10]
00007d2f61bcff2e  shrd r11d, r10d, 0x02
00007d2f61bcff33  mov [rsp+0x10], r12d
00007d2f61bcff38  mov r12d, r12d
00007d2f61bcff3b  mov [r15+0x20], r12
00007d2f61bcff3f  mov r12, [r15+0x50]
00007d2f61bcff43  mov r9d, [r13+r12*1]
00007d2f61bcff48  mov r12d, [rsp+0x50]
00007d2f61bcff4d  mov r8d, [rsp+0x70]
00007d2f61bcff52  andn ebp, r8d, r12d
00007d2f61bcff57  mov edi, [rsp+0x60]
00007d2f61bcff5b  lea esi, [r14d+edi*1]
00007d2f61bcff60  rorx r14d, r8d, 0x0B
00007d2f61bcff66  xor eax, r14d
00007d2f61bcff69  rorx r14d, r10d, 0x0D
00007d2f61bcff6f  xor r11d, r14d
00007d2f61bcff72  lea edi, [esi+ebp*1]
00007d2f61bcff76  mov r14, [r15+0x48]
00007d2f61bcff7a  mov ebp, [r13+r14*1]
00007d2f61bcff7f  mov r14d, [rsp+0x30]
00007d2f61bcff84  mov esi, [rsp+0x20]
00007d2f61bcff88  and r14d, esi
00007d2f61bcff8b  mov [rsp+0x20], r14d
00007d2f61bcff90  mov r14d, r14d
00007d2f61bcff93  mov [r15+0xD8], r14
00007d2f61bcff9a  lea r14d, [edi+r9d*1]
00007d2f61bcff9f  mov r9d, [rsp+0x30]
00007d2f61bcffa4  xor r9d, esi
00007d2f61bcffa7  rorx edi, r8d, 0x19
00007d2f61bcffad  xor eax, edi
00007d2f61bcffaf  and r9d, r10d
00007d2f61bcffb2  rorx edi, r10d, 0x16
00007d2f61bcffb8  xor r11d, edi
00007d2f61bcffbb  mov [rsp+0x30], r11d
00007d2f61bcffc0  mov r11d, r11d
00007d2f61bcffc3  mov [r15+0xD0], r11
00007d2f61bcffca  lea r11d, [r14d+ebp*1]
00007d2f61bcffcf  mov r10d, [rsp+0x20]
00007d2f61bcffd4  xor r9d, r10d
00007d2f61bcffd7  lea r14d, [r11d+eax*1]
00007d2f61bcffdc  mov qword ptr [r15+0x88], 0x04
00007d2f61bcffe7  mov eax, [rsp+0x30]
00007d2f61bcffeb  lea r11d, [r9d+eax*1]
00007d2f61bcfff0  mov eax, [rsp+0x40]
00007d2f61bcfff4  lea r10d, [r14d+eax*1]
00007d2f61bcfff9  mov r10d, r10d
00007d2f61bcfffc  mov [r15+0xB8], r10
00007d2f61bd0003  xor eax, eax
00007d2f61bd0005  mov r10d, 0x04
00007d2f61bd000b  mov r9d, 0x100
00007d2f61bd0011  cmp r10, r9
00007d2f61bd0014  cmc
00007d2f61bd0015  lahf
00007d2f61bd0016  seto al
00007d2f61bd0019  mov [r15+0x108], eax
00007d2f61bd0020  lea eax, [r11d+r14d*1]
00007d2f61bd0025  mov eax, eax
00007d2f61bd0027  mov [r15+0xA8], rax
00007d2f61bd002e  mov r12d, r12d
00007d2f61bd0031  mov [r15+0xB0], r12
00007d2f61bd0038  mov eax, [rsp+0x10]
00007d2f61bd003c  mov eax, eax
00007d2f61bd003e  mov [r15+0xC0], rax
00007d2f61bd0045  mov r8d, r8d
00007d2f61bd0048  mov [r15+0xC8], r8
00007d2f61bd004f  mov eax, [r15+0x108]
00007d2f61bd0056  sahf
00007d2f61bd0057  jnz 0x00007D2F61BD0089
00007d2f61bd0059  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0061  jz 0x00007D2F61BD0350
00007d2f61bd0067  nop [rax+rax*1], ax
00007d2f61bd0070  nop [rax+rax*1], eax
00007d2f61bd0078  mov eax, 0x41055C
00007d2f61bd007d  mov [r15+0x100], rax
00007d2f61bd0084  jmp 0x00007D2F619FE110
00007d2f61bd0089  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0091  jz 0x00007D2F61BD0120
00007d2f61bd0097  nop [rax+rax*1], ax
00007d2f61bd00a0  nop [rax+rax*1], eax
00007d2f61bd00a8  mov eax, 0x4104D0
00007d2f61bd00ad  mov [r15+0x100], rax
00007d2f61bd00b4  jmp 0x00007D2F619FE110
00007d2f61bd00b9  int3
00007d2f61bd00ba  call 0x00007D2F61A0DAE0
00007d2f61bd00bf  jmp 0x00007D2F61BCFE28
00007d2f61bd00c4  call 0x00007D2F61AC0230
00007d2f61bd00c9  jmp 0x00007D2F61BCFE31
00007d2f61bd00ce  call 0x00007D2F61AE26A0
00007d2f61bd00d3  jmp 0x00007D2F61BCFE55
00007d2f61bd00d8  call 0x00007D2F61AE1430
00007d2f61bd00dd  jmp 0x00007D2F61BCFE5E
00007d2f61bd00e2  call 0x00007D2F61AE26A0
00007d2f61bd00e7  jmp 0x00007D2F61BCFE7F
00007d2f61bd00ec  call 0x00007D2F61AE1430
00007d2f61bd00f1  jmp 0x00007D2F61BCFE88
00007d2f61bd00f6  call 0x00007D2F61AE26A0
00007d2f61bd00fb  jmp 0x00007D2F61BCFEA9
00007d2f61bd0100  call 0x00007D2F61AD5890
00007d2f61bd0105  jmp 0x00007D2F61BCFEB2
00007d2f61bd010a  call 0x00007D2F61ABDD50
00007d2f61bd010f  jmp 0x00007D2F61BCFF48
00007d2f61bd0114  call 0x00007D2F61ADA580
00007d2f61bd0119  jmp 0x00007D2F61BCFF7F
00007d2f61bd011e  int3
00007d2f61bd011f  nop
00007d2f61bd0120  mov eax, [r15+0xB8]
00007d2f61bd0127  mov [rsp+0x10], eax
00007d2f61bd012b  mov eax, eax
00007d2f61bd012d  mov [r15+0x30], rax
00007d2f61bd0131  mov eax, [r15+0xC0]
00007d2f61bd0138  mov [rsp+0x20], eax
00007d2f61bd013c  mov eax, eax
00007d2f61bd013e  mov [r15+0xA0], rax
00007d2f61bd0145  mov eax, [r15+0x28]
00007d2f61bd0149  mov r14d, [r15+0x98]
00007d2f61bd0150  mov [rsp+0x30], r14d
00007d2f61bd0155  mov r14d, r14d
00007d2f61bd0158  mov [r15+0x28], r14
00007d2f61bd015c  mov r14d, [r15+0x38]
00007d2f61bd0160  mov [rsp+0x40], r14d
00007d2f61bd0165  mov r14d, r14d
00007d2f61bd0168  mov [r15+0x98], r14
00007d2f61bd016f  mov r14d, [r15+0xA8]
00007d2f61bd0176  mov [rsp+0x50], r14d
00007d2f61bd017b  mov r14d, r14d
00007d2f61bd017e  mov [r15+0x38], r14
00007d2f61bd0182  mov r14d, [rsp+0x10]
00007d2f61bd0187  mov r12d, [rsp+0x10]
00007d2f61bd018c  shrd r14d, r12d, 0x06
00007d2f61bd0191  mov r11d, [r15+0xC8]
00007d2f61bd0198  mov [rsp+0x10], r12d
00007d2f61bd019d  and r12d, r11d
00007d2f61bd01a0  mov r10d, [rsp+0x50]
00007d2f61bd01a5  mov r9d, [rsp+0x50]
00007d2f61bd01aa  shrd r10d, r9d, 0x02
00007d2f61bd01af  mov [rsp+0x50], r11d
00007d2f61bd01b4  mov r11d, r11d
00007d2f61bd01b7  mov [r15+0x20], r11
00007d2f61bd01bb  mov r11, [r15+0x88]
00007d2f61bd01c2  mov r8, [r15+0x50]
00007d2f61bd01c6  lea rbp, [r8+r11*1]
00007d2f61bd01ca  mov r8d, [r13+rbp*1]
00007d2f61bd01cf  mov ebp, [rsp+0x20]
00007d2f61bd01d3  mov edi, [rsp+0x10]
00007d2f61bd01d7  andn esi, edi, ebp
00007d2f61bd01dc  mov edx, [r15+0xB0]
00007d2f61bd01e3  lea ecx, [r12d+edx*1]
00007d2f61bd01e8  rorx r12d, edi, 0x0B
00007d2f61bd01ee  xor r14d, r12d
00007d2f61bd01f1  rorx r12d, r9d, 0x0D
00007d2f61bd01f7  xor r10d, r12d
00007d2f61bd01fa  lea r12d, [ecx+esi*1]
00007d2f61bd01ff  mov rsi, [r15+0x48]
00007d2f61bd0203  lea rdx, [rsi+r11*1]
00007d2f61bd0207  mov esi, [r13+rdx*1]
00007d2f61bd020c  mov edx, [rsp+0x30]
00007d2f61bd0210  mov ecx, [rsp+0x40]
00007d2f61bd0214  and edx, ecx
00007d2f61bd0216  mov [rsp+0x10], edx
00007d2f61bd021a  mov edx, edx
00007d2f61bd021c  mov [r15+0xD8], rdx
00007d2f61bd0223  lea edx, [r12d+r8d*1]
00007d2f61bd0228  mov r12d, [rsp+0x30]
00007d2f61bd022d  xor r12d, ecx
00007d2f61bd0230  rorx r8d, edi, 0x19
00007d2f61bd0236  xor r14d, r8d
00007d2f61bd0239  and r12d, r9d
00007d2f61bd023c  rorx r8d, r9d, 0x16
00007d2f61bd0242  xor r10d, r8d
00007d2f61bd0245  mov [rsp+0x20], r10d
00007d2f61bd024a  mov r10d, r10d
00007d2f61bd024d  mov [r15+0xD0], r10
00007d2f61bd0254  lea r10d, [edx+esi*1]
00007d2f61bd0259  mov r9d, [rsp+0x10]
00007d2f61bd025e  xor r12d, r9d
00007d2f61bd0261  lea r9d, [r10d+r14d*1]
00007d2f61bd0266  lea r14, [r11+0x04]
00007d2f61bd026a  mov [r15+0x88], r14
00007d2f61bd0271  mov r11d, [rsp+0x20]
00007d2f61bd0276  lea r10d, [r12d+r11d*1]
00007d2f61bd027b  lea r11d, [r9d+eax*1]
00007d2f61bd0280  mov r11d, r11d
00007d2f61bd0283  mov [r15+0xB8], r11
00007d2f61bd028a  xor eax, eax
00007d2f61bd028c  mov r12d, 0x100
00007d2f61bd0292  cmp r14, r12
00007d2f61bd0295  cmc
00007d2f61bd0296  lahf
00007d2f61bd0297  seto al
00007d2f61bd029a  mov [r15+0x108], eax
00007d2f61bd02a1  lea eax, [r10d+r9d*1]
00007d2f61bd02a6  mov eax, eax
00007d2f61bd02a8  mov [r15+0xA8], rax
00007d2f61bd02af  mov ebp, ebp
00007d2f61bd02b1  mov [r15+0xB0], rbp
00007d2f61bd02b8  mov eax, [rsp+0x50]
00007d2f61bd02bc  mov eax, eax
00007d2f61bd02be  mov [r15+0xC0], rax
00007d2f61bd02c5  mov edi, edi
00007d2f61bd02c7  mov [r15+0xC8], rdi
00007d2f61bd02ce  mov eax, [r15+0x108]
00007d2f61bd02d5  sahf
00007d2f61bd02d6  jnz 0x00007D2F61BD0308
00007d2f61bd02d8  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd02e0  jz 0x00007D2F61BD0350
00007d2f61bd02e6  nop [rax+rax*1], ax
00007d2f61bd02ef  nop [rax+rax*1], eax
00007d2f61bd02f7  mov eax, 0x41055C
00007d2f61bd02fc  mov [r15+0x100], rax
00007d2f61bd0303  jmp 0x00007D2F619FE110
00007d2f61bd0308  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0310  jz 0x00007D2F61BD0120
00007d2f61bd0316  nop [rax+rax*1], ax
00007d2f61bd031f  nop [rax+rax*1], eax
00007d2f61bd0327  mov eax, 0x4104D0
00007d2f61bd032c  mov [r15+0x100], rax
00007d2f61bd0333  jmp 0x00007D2F619FE110
00007d2f61bd0338  int3
00007d2f61bd0339  call 0x00007D2F61A49010
00007d2f61bd033e  jmp 0x00007D2F61BD01CF
00007d2f61bd0343  call 0x00007D2F61A25930
00007d2f61bd0348  jmp 0x00007D2F61BD020C
00007d2f61bd034d  int3
00007d2f61bd034e  nop
00007d2f61bd0350  mov eax, [r15+0x98]
00007d2f61bd0357  mov r14d, [r15+0x70]
00007d2f61bd035b  lea r12d, [eax+r14d*1]
00007d2f61bd0360  mov eax, [r15+0x28]
00007d2f61bd0364  mov r14d, [r15+0x68]
00007d2f61bd0368  lea r11d, [eax+r14d*1]
00007d2f61bd036d  mov qword ptr [r15+0x88], 0x00
00007d2f61bd0378  mov eax, [r15+0xA8]
00007d2f61bd037f  mov r14d, [r15+0x78]
00007d2f61bd0383  lea r10d, [eax+r14d*1]
00007d2f61bd0388  mov [rsp+0x10], r10d
00007d2f61bd038d  mov r10d, r10d
00007d2f61bd0390  mov [r15+0x78], r10
00007d2f61bd0394  mov eax, [r15+0x38]
00007d2f61bd0398  mov r14d, [r15+0x80]
00007d2f61bd039f  lea r10d, [eax+r14d*1]
00007d2f61bd03a4  mov [rsp+0x20], r10d
00007d2f61bd03a9  mov r10d, r10d
00007d2f61bd03ac  mov [r15+0x80], r10
00007d2f61bd03b3  mov rax, [r15]
00007d2f61bd03b6  lea r14, [rax+0x08]
00007d2f61bd03ba  mov [r13+r14*1], r12d
00007d2f61bd03bf  lea r14, [rax+0x0C]
00007d2f61bd03c3  mov [r13+r14*1], r11d
00007d2f61bd03c8  mov r14d, [r15+0xB8]
00007d2f61bd03cf  mov r12d, [r15+0x18]
00007d2f61bd03d3  lea r11d, [r14d+r12d*1]
00007d2f61bd03d8  mov [rsp+0x30], r11d
00007d2f61bd03dd  mov r11d, r11d
00007d2f61bd03e0  mov [r15+0x68], r11
00007d2f61bd03e4  mov r14d, [r15+0x30]
00007d2f61bd03e8  mov r12d, [r15+0x90]
00007d2f61bd03ef  lea r11d, [r14d+r12d*1]
00007d2f61bd03f4  mov [rsp+0x40], r11d
00007d2f61bd03f9  mov r11d, r11d
00007d2f61bd03fc  mov [r15+0x70], r11
00007d2f61bd0400  mov r14d, [r15+0x20]
00007d2f61bd0404  mov r12d, [r15+0x58]
00007d2f61bd0408  lea r11d, [r14d+r12d*1]
00007d2f61bd040d  mov [rsp+0x50], r11d
00007d2f61bd0412  mov r11d, r11d
00007d2f61bd0415  mov [r15+0x58], r11
00007d2f61bd0419  mov r14d, [r15+0xA0]
00007d2f61bd0420  mov r12d, [r15+0x60]
00007d2f61bd0424  lea r11d, [r14d+r12d*1]
00007d2f61bd0429  mov [rsp+0x60], r11d
00007d2f61bd042e  mov r11d, r11d
00007d2f61bd0431  mov [r15+0x60], r11
00007d2f61bd0435  mov r14d, [rsp+0x10]
00007d2f61bd043a  mov [r13+rax*1], r14d
00007d2f61bd043f  lea r14, [rax+0x04]
00007d2f61bd0443  mov r12d, [rsp+0x20]
00007d2f61bd0448  mov [r13+r14*1], r12d
00007d2f61bd044d  lea r14, [rax+0x10]
00007d2f61bd0451  mov r12d, [rsp+0x30]
00007d2f61bd0456  mov [r13+r14*1], r12d
00007d2f61bd045b  lea r14, [rax+0x14]
00007d2f61bd045f  mov r12d, [rsp+0x40]
00007d2f61bd0464  mov [r13+r14*1], r12d
00007d2f61bd0469  lea r14, [rax+0x18]
00007d2f61bd046d  mov r12d, [rsp+0x50]
00007d2f61bd0472  mov [r13+r14*1], r12d
00007d2f61bd0477  lea r14, [rax+0x1C]
00007d2f61bd047b  mov r12d, [rsp+0x60]
00007d2f61bd0480  mov [r13+r14*1], r12d
00007d2f61bd0485  lea r14, [rax+0x68]
00007d2f61bd0489  xor eax, eax
00007d2f61bd048b  mov [r13+r14*1], rax
00007d2f61bd0490  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0498  jz 0x00007D2F61BCEF90
00007d2f61bd049e  nop [rax+rax*1], ax
00007d2f61bd04a7  nop [rax+rax*1], eax
00007d2f61bd04af  mov eax, 0x410378
00007d2f61bd04b4  mov [r15+0x100], rax
00007d2f61bd04bb  jmp 0x00007D2F619FE110
00007d2f61bd04c0  int3
00007d2f61bd04c1  call 0x00007D2F61AE2BA0
00007d2f61bd04c6  jmp 0x00007D2F61BD03BF
00007d2f61bd04cb  call 0x00007D2F61AE1920
00007d2f61bd04d0  jmp 0x00007D2F61BD03C8
00007d2f61bd04d5  call 0x00007D2F61A0DFE0
00007d2f61bd04da  jmp 0x00007D2F61BD043F
00007d2f61bd04df  call 0x00007D2F61AE2BA0
00007d2f61bd04e4  jmp 0x00007D2F61BD044D
00007d2f61bd04e9  call 0x00007D2F61AE2BA0
00007d2f61bd04ee  jmp 0x00007D2F61BD045B
00007d2f61bd04f3  call 0x00007D2F61AE2BA0
00007d2f61bd04f8  jmp 0x00007D2F61BD0469
00007d2f61bd04fd  call 0x00007D2F61AE2BA0
00007d2f61bd0502  jmp 0x00007D2F61BD0477
00007d2f61bd0507  call 0x00007D2F61AE2BA0
00007d2f61bd050c  jmp 0x00007D2F61BD0485
00007d2f61bd0511  call 0x00007D2F61AD5EB0
00007d2f61bd0516  jmp 0x00007D2F61BD0490
00007d2f61bd051b  int3
00007d2f61bd051c  nop [rax], eax
00007d2f61bd0520  mov rax, [r15+0xF8]
00007d2f61bd0527  lea r14, [rax+0x140]
00007d2f61bd052e  mov r12, [r13+r14*1]
00007d2f61bd0533  lea r14, [rax+0x148]
00007d2f61bd053a  mov r11, [r13+r14*1]
00007d2f61bd053f  mov [r15+0xA0], r12
00007d2f61bd0546  mov [r15+0x98], r11
00007d2f61bd054d  lea r14, [rax+0x130]
00007d2f61bd0554  mov r12, [r13+r14*1]
00007d2f61bd0559  lea r14, [rax+0x138]
00007d2f61bd0560  mov r11, [r13+r14*1]
00007d2f61bd0565  mov [r15+0xB0], r12
00007d2f61bd056c  mov [r15+0xA8], r11
00007d2f61bd0573  lea r14, [rax+0x120]
00007d2f61bd057a  mov r12, [r13+r14*1]
00007d2f61bd057f  lea r14, [rax+0x128]
00007d2f61bd0586  mov r11, [r13+r14*1]
00007d2f61bd058b  mov [r15+0xC0], r12
00007d2f61bd0592  mov [r15+0xB8], r11
00007d2f61bd0599  lea r14, [rax+0x110]
00007d2f61bd05a0  mov r12, [r13+r14*1]
00007d2f61bd05a5  lea r14, [rax+0x118]
00007d2f61bd05ac  mov r11, [r13+r14*1]
00007d2f61bd05b1  mov [r15+0xD0], r12
00007d2f61bd05b8  mov [r15+0xC8], r11
00007d2f61bd05bf  lea r14, [rax+0x100]
00007d2f61bd05c6  mov r12, [r13+r14*1]
00007d2f61bd05cb  lea r14, [rax+0x108]
00007d2f61bd05d2  mov r11, [r13+r14*1]
00007d2f61bd05d7  mov [r15+0xE8], r12
00007d2f61bd05de  mov [r15+0xD8], r11
00007d2f61bd05e5  lea r14, [rax+0x150]
00007d2f61bd05ec  mov [r15+0xF8], r14
00007d2f61bd05f3  mov rax, [r15+0xF0]
00007d2f61bd05fa  mov [r15+0x100], rax
00007d2f61bd0601  jmp 0x00007D2F61BCE5C0
00007d2f61bd0606  int3
00007d2f61bd0607  call 0x00007D2F61AE27E0
00007d2f61bd060c  jmp 0x00007D2F61BD0533
00007d2f61bd0611  call 0x00007D2F61AE1570
00007d2f61bd0616  jmp 0x00007D2F61BD053F
00007d2f61bd061b  call 0x00007D2F61AE27E0
00007d2f61bd0620  jmp 0x00007D2F61BD0559
00007d2f61bd0625  call 0x00007D2F61AE1570
00007d2f61bd062a  jmp 0x00007D2F61BD0565
00007d2f61bd062f  call 0x00007D2F61AE27E0
00007d2f61bd0634  jmp 0x00007D2F61BD057F
00007d2f61bd0639  call 0x00007D2F61AE1570
00007d2f61bd063e  jmp 0x00007D2F61BD058B
00007d2f61bd0643  call 0x00007D2F61AE27E0
00007d2f61bd0648  jmp 0x00007D2F61BD05A5
00007d2f61bd064d  call 0x00007D2F61AE1570
00007d2f61bd0652  jmp 0x00007D2F61BD05B1
00007d2f61bd0657  call 0x00007D2F61AE27E0
00007d2f61bd065c  jmp 0x00007D2F61BD05CB
00007d2f61bd0661  call 0x00007D2F61AE1570
00007d2f61bd0666  jmp 0x00007D2F61BD05D7
00007d2f61bd066b  int3
00007d2f61bd066c  nop [rax], eax
00007d2f61bd0670  mov eax, [r15+0xA0]
00007d2f61bd0677  mov [rsp+0x10], eax
00007d2f61bd067b  xor eax, eax
00007d2f61bd067d  mov r14d, [rsp+0x10]
00007d2f61bd0682  sub r14d, 0x01
00007d2f61bd0686  cmc
00007d2f61bd0687  lahf
00007d2f61bd0688  seto al
00007d2f61bd068b  mov [r15+0x108], eax
00007d2f61bd0692  mov r14d, r14d
00007d2f61bd0695  mov [r15+0xA0], r14
00007d2f61bd069c  mov eax, [r15+0x108]
00007d2f61bd06a3  sahf
00007d2f61bd06a4  jnz 0x00007D2F61BD06D6
00007d2f61bd06a6  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd06ae  jz 0x00007D2F61BD07A0
00007d2f61bd06b4  nop [rax+rax*1], ax
00007d2f61bd06bd  nop [rax+rax*1], eax
00007d2f61bd06c5  mov eax, 0x41027C
00007d2f61bd06ca  mov [r15+0x100], rax
00007d2f61bd06d1  jmp 0x00007D2F619FE110
00007d2f61bd06d6  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd06de  jz 0x00007D2F61BD0710
00007d2f61bd06e4  nop [rax+rax*1], ax
00007d2f61bd06ed  nop [rax+rax*1], eax
00007d2f61bd06f5  mov eax, 0x410264
00007d2f61bd06fa  mov [r15+0x100], rax
00007d2f61bd0701  jmp 0x00007D2F619FE110
00007d2f61bd0706  int3
00007d2f61bd0707  int3
00007d2f61bd0708  nop [rax+rax*1], eax
00007d2f61bd0710  mov rax, [r15+0xF8]
00007d2f61bd0717  mov [r15], rax
00007d2f61bd071a  mov rax, [r15+0x98]
00007d2f61bd0721  mov [r15+0x08], rax
00007d2f61bd0725  mov qword ptr [r15+0x10], 0x12C
00007d2f61bd072d  mov qword ptr [r15+0xF0], 0x410274
00007d2f61bd0738  mov r14d, [r15+0x320]
00007d2f61bd073f  mov eax, 0x410274
00007d2f61bd0744  mov rcx, 0x7D2F61BD0670
00007d2f61bd074e  mov [r15+r14*8+0x328], rax
00007d2f61bd0756  mov [r15+r14*8+0x368], rcx
00007d2f61bd075e  add r14d, 0x01
00007d2f61bd0762  and r14d, 0x07
00007d2f61bd0766  mov [r15+0x320], r14d
00007d2f61bd076d  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0775  jz 0x00007D2F61BCEC20
00007d2f61bd077b  nop [rax+rax*1], ax
00007d2f61bd0784  nop [rax+rax*1], eax
00007d2f61bd078c  mov eax, 0x410338
00007d2f61bd0791  mov [r15+0x100], rax
00007d2f61bd0798  jmp 0x00007D2F619FE110
00007d2f61bd079d  int3
00007d2f61bd079e  int3
00007d2f61bd079f  nop
00007d2f61bd07a0  mov rax, [r15+0xF8]
00007d2f61bd07a7  lea r14, [rax+0x20]
00007d2f61bd07ab  mov r12, [r13+r14*1]
00007d2f61bd07b0  mov [r15+0x98], r12
00007d2f61bd07b7  mov qword ptr [r15+0x40], 0x80
00007d2f61bd07bf  mov [r15], rax
00007d2f61bd07c2  lea r14, [rax+0x8C]
00007d2f61bd07c9  mov [r15+0x08], r14
00007d2f61bd07cd  mov qword ptr [r15+0x10], 0x01
00007d2f61bd07d5  lea r14, [rax+0x8C]
00007d2f61bd07dc  mov eax, 0x80
00007d2f61bd07e1  mov [r13+r14*1], al
00007d2f61bd07e6  mov qword ptr [r15+0xF0], 0x410298
00007d2f61bd07f1  mov r14d, [r15+0x320]
00007d2f61bd07f8  mov eax, 0x410298
00007d2f61bd07fd  mov rcx, 0x7D2F61BD0870
00007d2f61bd0807  mov [r15+r14*8+0x328], rax
00007d2f61bd080f  mov [r15+r14*8+0x368], rcx
00007d2f61bd0817  add r14d, 0x01
00007d2f61bd081b  and r14d, 0x07
00007d2f61bd081f  mov [r15+0x320], r14d
00007d2f61bd0826  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd082e  jz 0x00007D2F61BCEC20
00007d2f61bd0834  nop [rax+rax*1], ax
00007d2f61bd083d  nop [rax+rax*1], eax
00007d2f61bd0845  mov eax, 0x410338
00007d2f61bd084a  mov [r15+0x100], rax
00007d2f61bd0851  jmp 0x00007D2F619FE110
00007d2f61bd0856  int3
00007d2f61bd0857  call 0x00007D2F61AE27E0
00007d2f61bd085c  jmp 0x00007D2F61BD07B0
00007d2f61bd0861  call 0x00007D2F61AD5AF0
00007d2f61bd0866  jmp 0x00007D2F61BD07E6
00007d2f61bd086b  int3
00007d2f61bd086c  nop [rax], eax
00007d2f61bd0870  mov rax, [r15+0xF8]
00007d2f61bd0877  lea r14, [rax+0x68]
00007d2f61bd087b  mov r12, [r13+r14*1]
00007d2f61bd0880  mov [r15+0x40], r12
00007d2f61bd0884  lea r14, [rax+0x88]
00007d2f61bd088b  xor eax, eax
00007d2f61bd088d  mov [r13+r14*1], al
00007d2f61bd0892  xor eax, eax
00007d2f61bd0894  mov r14d, 0x38
00007d2f61bd089a  cmp r12, r14
00007d2f61bd089d  cmc
00007d2f61bd089e  lahf
00007d2f61bd089f  seto al
00007d2f61bd08a2  mov [r15+0x108], eax
00007d2f61bd08a9  mov eax, [r15+0x108]
00007d2f61bd08b0  sahf
00007d2f61bd08b1  jz 0x00007D2F61BD08E3
00007d2f61bd08b3  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd08bb  jz 0x00007D2F61BD0930
00007d2f61bd08c1  nop [rax+rax*1], ax
00007d2f61bd08ca  nop [rax+rax*1], eax
00007d2f61bd08d2  mov eax, 0x4102A8
00007d2f61bd08d7  mov [r15+0x100], rax
00007d2f61bd08de  jmp 0x00007D2F619FE110
00007d2f61bd08e3  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd08eb  jz 0x00007D2F61BD0A70
00007d2f61bd08f1  nop [rax+rax*1], ax
00007d2f61bd08fa  nop [rax+rax*1], eax
00007d2f61bd0902  mov eax, 0x4102C4
00007d2f61bd0907  mov [r15+0x100], rax
00007d2f61bd090e  jmp 0x00007D2F619FE110
00007d2f61bd0913  int3
00007d2f61bd0914  call 0x00007D2F61AE27E0
00007d2f61bd0919  jmp 0x00007D2F61BD0880
00007d2f61bd091e  call 0x00007D2F61AD5AF0
00007d2f61bd0923  jmp 0x00007D2F61BD0892
00007d2f61bd0928  int3
00007d2f61bd0929  nop [rax], eax
00007d2f61bd0930  mov rax, [r15+0xF8]
00007d2f61bd0937  mov [r15], rax
00007d2f61bd093a  lea r14, [rax+0x88]
00007d2f61bd0941  mov [r15+0x08], r14
00007d2f61bd0945  mov qword ptr [r15+0x10], 0x01
00007d2f61bd094d  mov qword ptr [r15+0xF0], 0x4102B8
00007d2f61bd0958  mov r14d, [r15+0x320]
00007d2f61bd095f  mov eax, 0x4102B8
00007d2f61bd0964  mov rcx, 0x7D2F61BD09C0
00007d2f61bd096e  mov [r15+r14*8+0x328], rax
00007d2f61bd0976  mov [r15+r14*8+0x368], rcx
00007d2f61bd097e  add r14d, 0x01
00007d2f61bd0982  and r14d, 0x07
00007d2f61bd0986  mov [r15+0x320], r14d
00007d2f61bd098d  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0995  jz 0x00007D2F61BCEC20
00007d2f61bd099b  nop [rax+rax*1], ax
00007d2f61bd09a4  nop [rax+rax*1], eax
00007d2f61bd09ac  mov eax, 0x410338
00007d2f61bd09b1  mov [r15+0x100], rax
00007d2f61bd09b8  jmp 0x00007D2F619FE110
00007d2f61bd09bd  int3
00007d2f61bd09be  int3
00007d2f61bd09bf  nop
00007d2f61bd09c0  mov rax, [r15+0xF8]
00007d2f61bd09c7  lea r14, [rax+0x68]
00007d2f61bd09cb  mov rax, [r13+r14*1]
00007d2f61bd09d0  mov [r15+0x40], rax
00007d2f61bd09d4  mov [rsp+0x10], rax
00007d2f61bd09d9  xor eax, eax
00007d2f61bd09db  mov r14, [rsp+0x10]
00007d2f61bd09e0  mov r12d, 0x38
00007d2f61bd09e6  cmp r14, r12
00007d2f61bd09e9  cmc
00007d2f61bd09ea  lahf
00007d2f61bd09eb  seto al
00007d2f61bd09ee  mov [r15+0x108], eax
00007d2f61bd09f5  mov eax, [r15+0x108]
00007d2f61bd09fc  sahf
00007d2f61bd09fd  jnz 0x00007D2F61BD0A2F
00007d2f61bd09ff  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0a07  jz 0x00007D2F61BD0A70
00007d2f61bd0a0d  nop [rax+rax*1], ax
00007d2f61bd0a16  nop [rax+rax*1], eax
00007d2f61bd0a1e  mov eax, 0x4102C4
00007d2f61bd0a23  mov [r15+0x100], rax
00007d2f61bd0a2a  jmp 0x00007D2F619FE110
00007d2f61bd0a2f  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0a37  jz 0x00007D2F61BD0930
00007d2f61bd0a3d  nop [rax+rax*1], ax
00007d2f61bd0a46  nop [rax+rax*1], eax
00007d2f61bd0a4e  mov eax, 0x4102A8
00007d2f61bd0a53  mov [r15+0x100], rax
00007d2f61bd0a5a  jmp 0x00007D2F619FE110
00007d2f61bd0a5f  int3
00007d2f61bd0a60  call 0x00007D2F61AD59C0
00007d2f61bd0a65  jmp 0x00007D2F61BD09D0
00007d2f61bd0a6a  int3
00007d2f61bd0a6b  nop [rax+rax*1], eax
00007d2f61bd0a70  mov rax, [r15+0x98]
00007d2f61bd0a77  rorx r14, rax, 0x3D
00007d2f61bd0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007d2f61bd0a81  mov rax, [r15+0xF8]
00007d2f61bd0a88  mov [r15], rax
00007d2f61bd0a8b  lea r12, [rax+0x78]
00007d2f61bd0a8f  mov [r15+0x08], r12
00007d2f61bd0a93  mov qword ptr [r15+0x10], 0x08
00007d2f61bd0a9b  bswap r14
00007d2f61bd0a9e  mov [r15+0x40], r14
00007d2f61bd0aa2  lea r12, [rax+0x78]
00007d2f61bd0aa6  mov [r13+r12*1], r14
00007d2f61bd0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007d2f61bd0ab6  mov r14d, [r15+0x320]
00007d2f61bd0abd  mov eax, 0x4102E0
00007d2f61bd0ac2  mov rcx, 0x7D2F61BD0B30
00007d2f61bd0acc  mov [r15+r14*8+0x328], rax
00007d2f61bd0ad4  mov [r15+r14*8+0x368], rcx
00007d2f61bd0adc  add r14d, 0x01
00007d2f61bd0ae0  and r14d, 0x07
00007d2f61bd0ae4  mov [r15+0x320], r14d
00007d2f61bd0aeb  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0af3  jz 0x00007D2F61BCEC20
00007d2f61bd0af9  nop [rax+rax*1], ax
00007d2f61bd0b02  nop [rax+rax*1], eax
00007d2f61bd0b0a  mov eax, 0x410338
00007d2f61bd0b0f  mov [r15+0x100], rax
00007d2f61bd0b16  jmp 0x00007D2F619FE110
00007d2f61bd0b1b  int3
00007d2f61bd0b1c  call 0x00007D2F61AC3FE0
00007d2f61bd0b21  jmp 0x00007D2F61BD0AAB
00007d2f61bd0b26  int3
00007d2f61bd0b27  nop [rax+rax*1], ax
00007d2f61bd0b30  mov rax, [r15+0xF8]
00007d2f61bd0b37  mov r14d, [r13+rax*1]
00007d2f61bd0b3c  lea r12, [rax+0x04]
00007d2f61bd0b40  mov r11d, [r13+r12*1]
00007d2f61bd0b45  lea r12, [rax+0x08]
00007d2f61bd0b49  mov r10d, [r13+r12*1]
00007d2f61bd0b4e  lea r12, [rax+0x0C]
00007d2f61bd0b52  mov r9d, [r13+r12*1]
00007d2f61bd0b57  mov qword ptr [r15+0x48], 0x430860
00007d2f61bd0b5f  lea r12, [rax+0x80]
00007d2f61bd0b66  mov r8, [r13+r12*1]
00007d2f61bd0b6b  mov [r15+0xF0], r8
00007d2f61bd0b72  bswap r14d
00007d2f61bd0b75  bswap r11d
00007d2f61bd0b78  mov r12d, 0x430860
00007d2f61bd0b7e  mov [r13+r12*1], r14d
00007d2f61bd0b83  mov r14d, 0x430864
00007d2f61bd0b89  mov [r13+r14*1], r11d
00007d2f61bd0b8e  bswap r10d
00007d2f61bd0b91  bswap r9d
00007d2f61bd0b94  lea r14, [rax+0x10]
00007d2f61bd0b98  mov r12d, [r13+r14*1]
00007d2f61bd0b9d  lea r14, [rax+0x14]
00007d2f61bd0ba1  mov r11d, [r13+r14*1]
00007d2f61bd0ba6  mov r14d, 0x430868
00007d2f61bd0bac  mov [r13+r14*1], r10d
00007d2f61bd0bb1  mov r14d, 0x43086C
00007d2f61bd0bb7  mov [r13+r14*1], r9d
00007d2f61bd0bbc  lea r14, [rax+0x90]
00007d2f61bd0bc3  mov r10, [r13+r14*1]
00007d2f61bd0bc8  lea r14, [rax+0x98]
00007d2f61bd0bcf  mov r9, [r13+r14*1]
00007d2f61bd0bd4  mov [r15+0xA0], r10
00007d2f61bd0bdb  mov [r15+0x98], r9
00007d2f61bd0be2  bswap r12d
00007d2f61bd0be5  bswap r11d
00007d2f61bd0be8  mov [rsp+0x10], r11d
00007d2f61bd0bed  mov r11d, r11d
00007d2f61bd0bf0  mov [r15+0x58], r11
00007d2f61bd0bf4  lea r14, [rax+0x18]
00007d2f61bd0bf8  mov r11d, [r13+r14*1]
00007d2f61bd0bfd  lea r14, [rax+0x1C]
00007d2f61bd0c01  mov r10d, [r13+r14*1]
00007d2f61bd0c06  mov [rsp+0x20], r10d
00007d2f61bd0c0b  mov r10d, r10d
00007d2f61bd0c0e  mov [r15+0x60], r10
00007d2f61bd0c12  mov r14d, 0x430870
00007d2f61bd0c18  mov [r13+r14*1], r12d
00007d2f61bd0c1d  mov r14d, 0x430874
00007d2f61bd0c23  mov r12d, [rsp+0x10]
00007d2f61bd0c28  mov [r13+r14*1], r12d
00007d2f61bd0c2d  bswap r11d
00007d2f61bd0c30  mov [rsp+0x10], r11d
00007d2f61bd0c35  mov r11d, r11d
00007d2f61bd0c38  mov [r15+0x40], r11
00007d2f61bd0c3c  mov r14d, [rsp+0x20]
00007d2f61bd0c41  bswap r14d
00007d2f61bd0c44  mov [rsp+0x20], r14d
00007d2f61bd0c49  mov r14d, r14d
00007d2f61bd0c4c  mov [r15+0x50], r14
00007d2f61bd0c50  mov r14d, 0x430878
00007d2f61bd0c56  mov r12d, [rsp+0x10]
00007d2f61bd0c5b  mov [r13+r14*1], r12d
00007d2f61bd0c60  mov r14d, 0x43087C
00007d2f61bd0c66  mov r12d, [rsp+0x20]
00007d2f61bd0c6b  mov [r13+r14*1], r12d
00007d2f61bd0c70  lea r14, [rax+0xA0]
00007d2f61bd0c77  mov [r15+0xF8], r14
00007d2f61bd0c7e  mov [r15+0x100], r8
00007d2f61bd0c85  jmp 0x00007D2F61BCE5C0
00007d2f61bd0c8a  int3
00007d2f61bd0c8b  call 0x00007D2F61A0DAE0
00007d2f61bd0c90  jmp 0x00007D2F61BD0B3C
00007d2f61bd0c95  call 0x00007D2F61AC0230
00007d2f61bd0c9a  jmp 0x00007D2F61BD0B45
00007d2f61bd0c9f  call 0x00007D2F61ABEFC0
00007d2f61bd0ca4  jmp 0x00007D2F61BD0B4E
00007d2f61bd0ca9  call 0x00007D2F61ABDD50
00007d2f61bd0cae  jmp 0x00007D2F61BD0B57
00007d2f61bd0cb3  call 0x00007D2F61ABCC20
00007d2f61bd0cb8  jmp 0x00007D2F61BD0B6B
00007d2f61bd0cbd  call 0x00007D2F61AC3EA0
00007d2f61bd0cc2  jmp 0x00007D2F61BD0B83
00007d2f61bd0cc7  call 0x00007D2F61AE1920
00007d2f61bd0ccc  jmp 0x00007D2F61BD0B8E
00007d2f61bd0cd1  call 0x00007D2F61AE26A0
00007d2f61bd0cd6  jmp 0x00007D2F61BD0B9D
00007d2f61bd0cdb  call 0x00007D2F61AE1430
00007d2f61bd0ce0  jmp 0x00007D2F61BD0BA6
00007d2f61bd0ce5  call 0x00007D2F61AE06B0
00007d2f61bd0cea  jmp 0x00007D2F61BD0BB1
00007d2f61bd0cef  call 0x00007D2F61ADF440
00007d2f61bd0cf4  jmp 0x00007D2F61BD0BBC
00007d2f61bd0cf9  call 0x00007D2F61AE0300
00007d2f61bd0cfe  jmp 0x00007D2F61BD0BC8
00007d2f61bd0d03  call 0x00007D2F61ADF090
00007d2f61bd0d08  jmp 0x00007D2F61BD0BD4
00007d2f61bd0d0d  call 0x00007D2F61AE1430
00007d2f61bd0d12  jmp 0x00007D2F61BD0BFD
00007d2f61bd0d17  call 0x00007D2F61AE01C0
00007d2f61bd0d1c  jmp 0x00007D2F61BD0C06
00007d2f61bd0d21  call 0x00007D2F61AE2BA0
00007d2f61bd0d26  jmp 0x00007D2F61BD0C1D
00007d2f61bd0d2b  call 0x00007D2F61AE2BA0
00007d2f61bd0d30  jmp 0x00007D2F61BD0C2D
00007d2f61bd0d35  call 0x00007D2F61AE2BA0
00007d2f61bd0d3a  jmp 0x00007D2F61BD0C60
00007d2f61bd0d3f  call 0x00007D2F61AE2BA0
00007d2f61bd0d44  jmp 0x00007D2F61BD0C70
00007d2f61bd0d49  int3
00007d2f61bd0d4a  nop [rax+rax*1], ax
00007d2f61bd0d50  mov qword ptr [r15+0x100], 0x04
00007d2f61bd0d5b  mov esi, 0x00
00007d2f61bd0d60  mov edx, 0x09
00007d2f61bd0d65  mov rdi, 0x7FFE43A058D0
00007d2f61bd0d6f  mov rax, 0x61332E0DF970
00007d2f61bd0d79  call rax
00007d2f61bd0d7b  cmp dword ptr [r15+0x318], 0x00
00007d2f61bd0d83  jnz 0x00007D2F619FE110
00007d2f61bd0d89  jmp 0x00007D2F619FE0A0
00007d2f61bd0d8e  int3
00007d2f61bd0d8f  int3
