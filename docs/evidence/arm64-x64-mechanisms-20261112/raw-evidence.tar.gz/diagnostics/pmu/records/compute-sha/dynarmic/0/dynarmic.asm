00007eece83ce69b  nop [rax+rax*1], eax
00007eece83ce6a0  mov rax, [r15+0xF8]
00007eece83ce6a7  lea r14, [rax-0xA0]
00007eece83ce6ae  mov [r15+0xF8], r14
00007eece83ce6b5  lea rax, [r14+0x90]
00007eece83ce6bc  mov r12, [r15+0xA0]
00007eece83ce6c3  mov r11, [r15+0x98]
00007eece83ce6ca  mov [r13+rax*1], r12
00007eece83ce6cf  lea rax, [r14+0x98]
00007eece83ce6d6  mov [r13+rax*1], r11
00007eece83ce6db  mov eax, 0x420670
00007eece83ce6e0  movups xmm1, [r13+rax*1]
00007eece83ce6e6  mov eax, 0x420610
00007eece83ce6eb  movups xmm15, [r13+rax*1]
00007eece83ce6f1  mov eax, 0x420690
00007eece83ce6f6  movups xmm14, [r13+rax*1]
00007eece83ce6fc  mov eax, 0x420630
00007eece83ce701  movups xmm13, [r13+rax*1]
00007eece83ce707  mov qword ptr [r15+0x98], 0x4308A0
00007eece83ce712  mov eax, 0x4206A0
00007eece83ce717  movups xmm12, [r13+rax*1]
00007eece83ce71d  mov eax, 0x4308A0
00007eece83ce722  movups [r13+rax*1], xmm1
00007eece83ce728  mov eax, 0x4308B0
00007eece83ce72d  movups [r13+rax*1], xmm15
00007eece83ce733  mov eax, 0x4308C0
00007eece83ce738  movups [r13+rax*1], xmm14
00007eece83ce73e  mov eax, 0x4308D0
00007eece83ce743  movups [r13+rax*1], xmm13
00007eece83ce749  mov eax, 0x420600
00007eece83ce74e  movups xmm14, [r13+rax*1]
00007eece83ce754  mov eax, 0x4205F0
00007eece83ce759  movups xmm13, [r13+rax*1]
00007eece83ce75f  mov eax, 0x4309A0
00007eece83ce764  movups [r13+rax*1], xmm1
00007eece83ce76a  mov eax, 0x4309B0
00007eece83ce76f  movups [r13+rax*1], xmm15
00007eece83ce775  mov eax, 0x4308E0
00007eece83ce77a  movups [r13+rax*1], xmm12
00007eece83ce780  mov eax, 0x4308F0
00007eece83ce785  movups [r13+rax*1], xmm14
00007eece83ce78b  mov eax, 0x4205E0
00007eece83ce790  movups xmm1, [r13+rax*1]
00007eece83ce796  mov eax, 0x420640
00007eece83ce79b  movups xmm15, [r13+rax*1]
00007eece83ce7a1  mov eax, 0x430900
00007eece83ce7a6  movups [r13+rax*1], xmm13
00007eece83ce7ac  mov eax, 0x430910
00007eece83ce7b1  movups [r13+rax*1], xmm1
00007eece83ce7b7  mov eax, 0x420650
00007eece83ce7bc  movups xmm1, [r13+rax*1]
00007eece83ce7c2  mov eax, 0x420620
00007eece83ce7c7  movups xmm14, [r13+rax*1]
00007eece83ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007eece83ce7d5  mov eax, 0x430920
00007eece83ce7da  movups [r13+rax*1], xmm15
00007eece83ce7e0  mov eax, 0x430930
00007eece83ce7e5  movups [r13+rax*1], xmm1
00007eece83ce7eb  mov eax, 0x4206C0
00007eece83ce7f0  movups xmm1, [r13+rax*1]
00007eece83ce7f6  mov eax, 0x4206D0
00007eece83ce7fb  movups xmm15, [r13+rax*1]
00007eece83ce801  movaps [r15+0x150], xmm15
00007eece83ce809  mov qword ptr [r15+0xA0], 0x3E8
00007eece83ce814  mov eax, 0x430940
00007eece83ce819  movups [r13+rax*1], xmm14
00007eece83ce81f  mov eax, 0x430950
00007eece83ce824  movups [r13+rax*1], xmm1
00007eece83ce82a  mov eax, 0x4206B0
00007eece83ce82f  movups xmm1, [r13+rax*1]
00007eece83ce835  mov eax, 0x420660
00007eece83ce83a  movups xmm14, [r13+rax*1]
00007eece83ce840  movaps [r15+0x140], xmm14
00007eece83ce848  lea rax, [r14+0x80]
00007eece83ce84f  mov r12, [r15+0xF0]
00007eece83ce856  mov [r13+rax*1], r12
00007eece83ce85b  mov eax, 0x430960
00007eece83ce860  movups [r13+rax*1], xmm15
00007eece83ce866  mov eax, 0x430970
00007eece83ce86b  movups [r13+rax*1], xmm1
00007eece83ce871  mov eax, 0x420680
00007eece83ce876  movups xmm1, [r13+rax*1]
00007eece83ce87c  mov eax, 0x4206E0
00007eece83ce881  mov r12, [r13+rax*1]
00007eece83ce886  movq xmm15, r12
00007eece83ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007eece83ce893  mov eax, 0x430980
00007eece83ce898  movups [r13+rax*1], xmm14
00007eece83ce89e  mov eax, 0x430990
00007eece83ce8a3  movups [r13+rax*1], xmm1
00007eece83ce8a9  mov eax, 0x420748
00007eece83ce8ae  movups xmm1, [r13+rax*1]
00007eece83ce8b4  movq rax, xmm15
00007eece83ce8b9  mov r12d, 0x4309C0
00007eece83ce8bf  mov [r13+r12*1], rax
00007eece83ce8c4  mov eax, 0x420728
00007eece83ce8c9  movups xmm15, [r13+rax*1]
00007eece83ce8cf  mov eax, 0x420738
00007eece83ce8d4  movups xmm14, [r13+rax*1]
00007eece83ce8da  lea rax, [r14+0x60]
00007eece83ce8de  movups [r13+rax*1], xmm1
00007eece83ce8e4  mov eax, 0x4309C8
00007eece83ce8e9  mov r12d, 0x421DF8D3
00007eece83ce8ef  mov [r13+rax*1], r12d
00007eece83ce8f4  lea rax, [r14+0x40]
00007eece83ce8f8  movups [r13+rax*1], xmm15
00007eece83ce8fe  lea rax, [r14+0x50]
00007eece83ce902  movups [r13+rax*1], xmm14
00007eece83ce908  mov eax, 0x4206E8
00007eece83ce90d  movups xmm1, [r13+rax*1]
00007eece83ce913  mov eax, 0x4206F8
00007eece83ce918  movups xmm15, [r13+rax*1]
00007eece83ce91e  movaps [r15+0x120], xmm15
00007eece83ce926  movups [r13+r14*1], xmm1
00007eece83ce92c  lea rax, [r14+0x10]
00007eece83ce930  movups [r13+rax*1], xmm15
00007eece83ce936  mov eax, 0x420708
00007eece83ce93b  movups xmm1, [r13+rax*1]
00007eece83ce941  mov eax, 0x420718
00007eece83ce946  movups xmm15, [r13+rax*1]
00007eece83ce94c  movaps [r15+0x110], xmm1
00007eece83ce954  movaps [r15+0x130], xmm15
00007eece83ce95c  lea rax, [r14+0x20]
00007eece83ce960  movups [r13+rax*1], xmm1
00007eece83ce966  lea rax, [r14+0x30]
00007eece83ce96a  movups [r13+rax*1], xmm15
00007eece83ce970  mov [r15], r14
00007eece83ce973  mov qword ptr [r15+0x08], 0x4308A0
00007eece83ce97b  mov qword ptr [r15+0x10], 0x12C
00007eece83ce983  mov qword ptr [r15+0xF0], 0x410274
00007eece83ce98e  mov r14d, [r15+0x320]
00007eece83ce995  mov eax, 0x410274
00007eece83ce99a  mov rcx, 0x7EECE83D0670
00007eece83ce9a4  mov [r15+r14*8+0x328], rax
00007eece83ce9ac  mov [r15+r14*8+0x368], rcx
00007eece83ce9b4  add r14d, 0x01
00007eece83ce9b8  and r14d, 0x07
00007eece83ce9bc  mov [r15+0x320], r14d
00007eece83ce9c3  cmp dword ptr [r15+0x318], 0x00
00007eece83ce9cb  jz 0x00007EECE83CEC20
00007eece83ce9d1  nop [rax+rax*1], ax
00007eece83ce9da  nop [rax+rax*1], eax
00007eece83ce9e2  mov eax, 0x410338
00007eece83ce9e7  mov [r15+0x100], rax
00007eece83ce9ee  jmp 0x00007EECE81FE110
00007eece83ce9f3  int3
00007eece83ce9f4  call 0x00007EECE820BC20
00007eece83ce9f9  jmp 0x00007EECE83CE6CF
00007eece83ce9fe  call 0x00007EECE820A9A0
00007eece83cea03  jmp 0x00007EECE83CE6DB
00007eece83cea08  call 0x00007EECE81FF430
00007eece83cea0d  jmp 0x00007EECE83CE6E6
00007eece83cea12  call 0x00007EECE820E760
00007eece83cea17  jmp 0x00007EECE83CE6F1
00007eece83cea1c  call 0x00007EECE820D4E0
00007eece83cea21  jmp 0x00007EECE83CE6FC
00007eece83cea26  call 0x00007EECE820C260
00007eece83cea2b  jmp 0x00007EECE83CE707
00007eece83cea30  call 0x00007EECE820AFE0
00007eece83cea35  jmp 0x00007EECE83CE71D
00007eece83cea3a  call 0x00007EECE81FF540
00007eece83cea3f  jmp 0x00007EECE83CE728
00007eece83cea44  call 0x00007EECE820E880
00007eece83cea49  jmp 0x00007EECE83CE733
00007eece83cea4e  call 0x00007EECE820D600
00007eece83cea53  jmp 0x00007EECE83CE73E
00007eece83cea58  call 0x00007EECE820C380
00007eece83cea5d  jmp 0x00007EECE83CE749
00007eece83cea62  call 0x00007EECE820D4E0
00007eece83cea67  jmp 0x00007EECE83CE754
00007eece83cea6c  call 0x00007EECE820C260
00007eece83cea71  jmp 0x00007EECE83CE75F
00007eece83cea76  call 0x00007EECE81FF540
00007eece83cea7b  jmp 0x00007EECE83CE76A
00007eece83cea80  call 0x00007EECE820E880
00007eece83cea85  jmp 0x00007EECE83CE775
00007eece83cea8a  call 0x00007EECE820B100
00007eece83cea8f  jmp 0x00007EECE83CE780
00007eece83cea94  call 0x00007EECE820D600
00007eece83cea99  jmp 0x00007EECE83CE78B
00007eece83cea9e  call 0x00007EECE81FF430
00007eece83ceaa3  jmp 0x00007EECE83CE796
00007eece83ceaa8  call 0x00007EECE820E760
00007eece83ceaad  jmp 0x00007EECE83CE7A1
00007eece83ceab2  call 0x00007EECE820C380
00007eece83ceab7  jmp 0x00007EECE83CE7AC
00007eece83ceabc  call 0x00007EECE81FF540
00007eece83ceac1  jmp 0x00007EECE83CE7B7
00007eece83ceac6  call 0x00007EECE81FF430
00007eece83ceacb  jmp 0x00007EECE83CE7C2
00007eece83cead0  call 0x00007EECE820D4E0
00007eece83cead5  jmp 0x00007EECE83CE7CD
00007eece83ceada  call 0x00007EECE820E880
00007eece83ceadf  jmp 0x00007EECE83CE7E0
00007eece83ceae4  call 0x00007EECE81FF540
00007eece83ceae9  jmp 0x00007EECE83CE7EB
00007eece83ceaee  call 0x00007EECE81FF430
00007eece83ceaf3  jmp 0x00007EECE83CE7F6
00007eece83ceaf8  call 0x00007EECE820E760
00007eece83ceafd  jmp 0x00007EECE83CE801
00007eece83ceb02  call 0x00007EECE820D600
00007eece83ceb07  jmp 0x00007EECE83CE81F
00007eece83ceb0c  call 0x00007EECE81FF540
00007eece83ceb11  jmp 0x00007EECE83CE82A
00007eece83ceb16  call 0x00007EECE81FF430
00007eece83ceb1b  jmp 0x00007EECE83CE835
00007eece83ceb20  call 0x00007EECE820D4E0
00007eece83ceb25  jmp 0x00007EECE83CE840
00007eece83ceb2a  call 0x00007EECE820BC20
00007eece83ceb2f  jmp 0x00007EECE83CE85B
00007eece83ceb34  call 0x00007EECE820E880
00007eece83ceb39  jmp 0x00007EECE83CE866
00007eece83ceb3e  call 0x00007EECE81FF540
00007eece83ceb43  jmp 0x00007EECE83CE871
00007eece83ceb48  call 0x00007EECE81FF430
00007eece83ceb4d  jmp 0x00007EECE83CE87C
00007eece83ceb52  call 0x00007EECE820B720
00007eece83ceb57  jmp 0x00007EECE83CE886
00007eece83ceb5c  call 0x00007EECE820D600
00007eece83ceb61  jmp 0x00007EECE83CE89E
00007eece83ceb66  call 0x00007EECE81FF540
00007eece83ceb6b  jmp 0x00007EECE83CE8A9
00007eece83ceb70  call 0x00007EECE81FF430
00007eece83ceb75  jmp 0x00007EECE83CE8B4
00007eece83ceb7a  call 0x00007EECE82B4CB0
00007eece83ceb7f  jmp 0x00007EECE83CE8C4
00007eece83ceb84  call 0x00007EECE820E760
00007eece83ceb89  jmp 0x00007EECE83CE8CF
00007eece83ceb8e  call 0x00007EECE820D4E0
00007eece83ceb93  jmp 0x00007EECE83CE8DA
00007eece83ceb98  call 0x00007EECE81FF540
00007eece83ceb9d  jmp 0x00007EECE83CE8E4
00007eece83ceba2  call 0x00007EECE820BAE0
00007eece83ceba7  jmp 0x00007EECE83CE8F4
00007eece83cebac  call 0x00007EECE820E880
00007eece83cebb1  jmp 0x00007EECE83CE8FE
00007eece83cebb6  call 0x00007EECE820D600
00007eece83cebbb  jmp 0x00007EECE83CE908
00007eece83cebc0  call 0x00007EECE81FF430
00007eece83cebc5  jmp 0x00007EECE83CE913
00007eece83cebca  call 0x00007EECE820E760
00007eece83cebcf  jmp 0x00007EECE83CE91E
00007eece83cebd4  call 0x00007EECE82D6600
00007eece83cebd9  jmp 0x00007EECE83CE92C
00007eece83cebde  call 0x00007EECE820E880
00007eece83cebe3  jmp 0x00007EECE83CE936
00007eece83cebe8  call 0x00007EECE81FF430
00007eece83cebed  jmp 0x00007EECE83CE941
00007eece83cebf2  call 0x00007EECE820E760
00007eece83cebf7  jmp 0x00007EECE83CE94C
00007eece83cebfc  call 0x00007EECE81FF540
00007eece83cec01  jmp 0x00007EECE83CE966
00007eece83cec06  call 0x00007EECE820E880
00007eece83cec0b  jmp 0x00007EECE83CE970
00007eece83cec10  int3
00007eece83cec11  nop [rax+rax*1], ax
00007eece83cec1a  nop [rax+rax*1], ax
00007eece83cec20  mov rax, [r15]
00007eece83cec23  lea r14, [rax+0x20]
00007eece83cec27  mov r12, [r13+r14*1]
00007eece83cec2c  mov r14, [r15+0x10]
00007eece83cec30  lea r11, [r12+r14*1]
00007eece83cec34  mov [r15+0x40], r11
00007eece83cec38  lea r12, [rax+0x20]
00007eece83cec3c  mov [r13+r12*1], r11
00007eece83cec41  test r14, r14
00007eece83cec44  setz r14b
00007eece83cec48  movzx r14, r14b
00007eece83cec4c  mov [rsp+0x414], r14b
00007eece83cec54  cmp byte ptr [rsp+0x414], 0x00
00007eece83cec5c  jz 0x00007EECE83CEC8E
00007eece83cec5e  cmp dword ptr [r15+0x318], 0x00
00007eece83cec66  mov eax, 0x4105B0
00007eece83cec6b  mov [r15+0x100], rax
00007eece83cec72  jz 0x00007EECE81FE0A0
00007eece83cec78  nop [rax+rax*1], eax
00007eece83cec7d  mov eax, 0x4105B0
00007eece83cec82  mov [r15+0x100], rax
00007eece83cec89  jmp 0x00007EECE81FE110
00007eece83cec8e  cmp dword ptr [r15+0x318], 0x00
00007eece83cec96  jz 0x00007EECE83CECE0
00007eece83cec9c  nop [rax+rax*1], ax
00007eece83ceca5  nop [rax+rax*1], eax
00007eece83cecad  mov eax, 0x410348
00007eece83cecb2  mov [r15+0x100], rax
00007eece83cecb9  jmp 0x00007EECE81FE110
00007eece83cecbe  int3
00007eece83cecbf  call 0x00007EECE82E27E0
00007eece83cecc4  jmp 0x00007EECE83CEC2C
00007eece83cecc9  call 0x00007EECE82C0860
00007eece83cecce  jmp 0x00007EECE83CEC41
00007eece83cecd3  int3
00007eece83cecd4  nop [rax+rax*1], ax
00007eece83cecdd  nop [rax], eax
00007eece83cece0  mov rax, [r15+0xF8]
00007eece83cece7  lea r14, [rax-0x150]
00007eece83cecee  mov [r15+0xF8], r14
00007eece83cecf5  mov rax, [r15]
00007eece83cecf8  lea r12, [rax+0x68]
00007eece83cecfc  mov r11, [r13+r12*1]
00007eece83ced01  mov [r15+0x88], r11
00007eece83ced08  lea r12, [rax+0x28]
00007eece83ced0c  mov [r15+0x40], r12
00007eece83ced10  mov [r15+0x48], r14
00007eece83ced14  mov qword ptr [r15+0x50], 0x420758
00007eece83ced1c  lea rax, [r14+0x100]
00007eece83ced23  mov r12, [r15+0xE8]
00007eece83ced2a  mov r11, [r15+0xD8]
00007eece83ced31  mov [r13+rax*1], r12
00007eece83ced36  lea rax, [r14+0x108]
00007eece83ced3d  mov [r13+rax*1], r11
00007eece83ced42  lea rax, [r14+0x110]
00007eece83ced49  mov r12, [r15+0xD0]
00007eece83ced50  mov r11, [r15+0xC8]
00007eece83ced57  mov [r13+rax*1], r12
00007eece83ced5c  lea rax, [r14+0x118]
00007eece83ced63  mov [r13+rax*1], r11
00007eece83ced68  lea rax, [r14+0x120]
00007eece83ced6f  mov r12, [r15+0xC0]
00007eece83ced76  mov r11, [r15+0xB8]
00007eece83ced7d  mov [r13+rax*1], r12
00007eece83ced82  lea rax, [r14+0x128]
00007eece83ced89  mov [r13+rax*1], r11
00007eece83ced8e  lea rax, [r14+0x130]
00007eece83ced95  mov r12, [r15+0xB0]
00007eece83ced9c  mov r11, [r15+0xA8]
00007eece83ceda3  mov [r13+rax*1], r12
00007eece83ceda8  lea rax, [r14+0x138]
00007eece83cedaf  mov [r13+rax*1], r11
00007eece83cedb4  lea rax, [r14+0x140]
00007eece83cedbb  mov r12, [r15+0xA0]
00007eece83cedc2  mov r11, [r15+0x98]
00007eece83cedc9  mov [r13+rax*1], r12
00007eece83cedce  lea rax, [r14+0x148]
00007eece83cedd5  mov [r13+rax*1], r11
00007eece83cedda  cmp dword ptr [r15+0x318], 0x00
00007eece83cede2  jz 0x00007EECE83CEE80
00007eece83cede8  nop [rax+rax*1], ax
00007eece83cedf1  nop [rax+rax*1], eax
00007eece83cedf9  mov eax, 0x410380
00007eece83cedfe  mov [r15+0x100], rax
00007eece83cee05  jmp 0x00007EECE81FE110
00007eece83cee0a  int3
00007eece83cee0b  call 0x00007EECE82C0370
00007eece83cee10  jmp 0x00007EECE83CED01
00007eece83cee15  call 0x00007EECE820BC20
00007eece83cee1a  jmp 0x00007EECE83CED36
00007eece83cee1f  call 0x00007EECE820A9A0
00007eece83cee24  jmp 0x00007EECE83CED42
00007eece83cee29  call 0x00007EECE820BC20
00007eece83cee2e  jmp 0x00007EECE83CED5C
00007eece83cee33  call 0x00007EECE820A9A0
00007eece83cee38  jmp 0x00007EECE83CED68
00007eece83cee3d  call 0x00007EECE820BC20
00007eece83cee42  jmp 0x00007EECE83CED82
00007eece83cee47  call 0x00007EECE820A9A0
00007eece83cee4c  jmp 0x00007EECE83CED8E
00007eece83cee51  call 0x00007EECE820BC20
00007eece83cee56  jmp 0x00007EECE83CEDA8
00007eece83cee5b  call 0x00007EECE820A9A0
00007eece83cee60  jmp 0x00007EECE83CEDB4
00007eece83cee65  call 0x00007EECE820BC20
00007eece83cee6a  jmp 0x00007EECE83CEDCE
00007eece83cee6f  call 0x00007EECE820A9A0
00007eece83cee74  jmp 0x00007EECE83CEDDA
00007eece83cee79  int3
00007eece83cee7a  nop [rax+rax*1], ax
00007eece83cee80  mov rax, [r15+0x08]
00007eece83cee84  movzx r14d, byte ptr [r13+rax*1]
00007eece83cee8a  movzx r14d, r14b
00007eece83cee8e  mov [rsp+0x10], r14d
00007eece83cee93  mov r14d, r14d
00007eece83cee96  mov [r15+0x58], r14
00007eece83cee9a  lea r14, [rax+0x01]
00007eece83cee9e  mov [r15+0x08], r14
00007eece83ceea2  mov rax, [r15+0x88]
00007eece83ceea9  lea r14, [rax+0x01]
00007eece83ceead  mov r12, [r15]
00007eece83ceeb0  lea r11, [r12+0x68]
00007eece83ceeb5  mov [r13+r11*1], r14
00007eece83ceeba  lea r14, [r12+rax*1]
00007eece83ceebe  mov [r15+0x60], r14
00007eece83ceec2  lea rax, [r14+0x28]
00007eece83ceec6  mov r11d, [rsp+0x10]
00007eece83ceecb  movzx r14d, r11b
00007eece83ceecf  mov [r13+rax*1], r14b
00007eece83ceed4  lea rax, [r12+0x68]
00007eece83ceed9  mov r14, [r13+rax*1]
00007eece83ceede  mov [r15+0x88], r14
00007eece83ceee5  xor eax, eax
00007eece83ceee7  mov r12d, 0x40
00007eece83ceeed  cmp r14, r12
00007eece83ceef0  cmc
00007eece83ceef1  lahf
00007eece83ceef2  seto al
00007eece83ceef5  mov [r15+0x108], eax
00007eece83ceefc  mov eax, [r15+0x108]
00007eece83cef03  sahf
00007eece83cef04  jnz 0x00007EECE83CEF36
00007eece83cef06  cmp dword ptr [r15+0x318], 0x00
00007eece83cef0e  jz 0x00007EECE83CF020
00007eece83cef14  nop [rax+rax*1], ax
00007eece83cef1d  nop [rax+rax*1], eax
00007eece83cef25  mov eax, 0x4103A0
00007eece83cef2a  mov [r15+0x100], rax
00007eece83cef31  jmp 0x00007EECE81FE110
00007eece83cef36  cmp dword ptr [r15+0x318], 0x00
00007eece83cef3e  jz 0x00007EECE83CEF90
00007eece83cef44  nop [rax+rax*1], ax
00007eece83cef4d  nop [rax+rax*1], eax
00007eece83cef55  mov eax, 0x410378
00007eece83cef5a  mov [r15+0x100], rax
00007eece83cef61  jmp 0x00007EECE81FE110
00007eece83cef66  int3
00007eece83cef67  call 0x00007EECE820D860
00007eece83cef6c  jmp 0x00007EECE83CEE8A
00007eece83cef71  call 0x00007EECE82B36E0
00007eece83cef76  jmp 0x00007EECE83CEEBA
00007eece83cef7b  call 0x00007EECE820DD60
00007eece83cef80  jmp 0x00007EECE83CEED4
00007eece83cef85  call 0x00007EECE820DC20
00007eece83cef8a  jmp 0x00007EECE83CEEDE
00007eece83cef8f  int3
00007eece83cef90  mov rax, [r15+0x10]
00007eece83cef94  lea r14, [rax-0x01]
00007eece83cef98  mov [r15+0x10], r14
00007eece83cef9c  test r14, r14
00007eece83cef9f  setz r14b
00007eece83cefa3  movzx r14, r14b
00007eece83cefa7  mov [rsp+0x414], r14b
00007eece83cefaf  cmp byte ptr [rsp+0x414], 0x00
00007eece83cefb7  jz 0x00007EECE83CEFE9
00007eece83cefb9  cmp dword ptr [r15+0x318], 0x00
00007eece83cefc1  jz 0x00007EECE83D0520
00007eece83cefc7  nop [rax+rax*1], ax
00007eece83cefd0  nop [rax+rax*1], eax
00007eece83cefd8  mov eax, 0x410598
00007eece83cefdd  mov [r15+0x100], rax
00007eece83cefe4  jmp 0x00007EECE81FE110
00007eece83cefe9  cmp dword ptr [r15+0x318], 0x00
00007eece83ceff1  jz 0x00007EECE83CEE80
00007eece83ceff7  nop [rax+rax*1], ax
00007eece83cf000  nop [rax+rax*1], eax
00007eece83cf008  mov eax, 0x410380
00007eece83cf00d  mov [r15+0x100], rax
00007eece83cf014  jmp 0x00007EECE81FE110
00007eece83cf019  int3
00007eece83cf01a  int3
00007eece83cf01b  nop [rax+rax*1], eax
00007eece83cf020  mov rax, [r15+0x40]
00007eece83cf024  movzx r14d, byte ptr [r13+rax*1]
00007eece83cf02a  movaps xmm1, [r15+0x110]
00007eece83cf032  pinsrb xmm1, r14d, 0x00
00007eece83cf039  lea r14, [rax+0x01]
00007eece83cf03d  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf043  movaps xmm15, [r15+0x120]
00007eece83cf04b  pinsrb xmm15, r12d, 0x00
00007eece83cf052  lea r14, [rax+0x02]
00007eece83cf056  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf05c  movaps xmm14, [r15+0x130]
00007eece83cf064  pinsrb xmm14, r12d, 0x00
00007eece83cf06b  lea r14, [rax+0x03]
00007eece83cf06f  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf075  movaps xmm13, [r15+0x140]
00007eece83cf07d  pinsrb xmm13, r12d, 0x00
00007eece83cf084  lea r14, [rax+0x04]
00007eece83cf088  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf08e  pinsrb xmm1, r12d, 0x01
00007eece83cf095  lea r14, [rax+0x05]
00007eece83cf099  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf09f  pinsrb xmm15, r12d, 0x01
00007eece83cf0a6  lea r14, [rax+0x06]
00007eece83cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf0b0  pinsrb xmm14, r12d, 0x01
00007eece83cf0b7  lea r14, [rax+0x07]
00007eece83cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf0c1  pinsrb xmm13, r12d, 0x01
00007eece83cf0c8  lea r14, [rax+0x08]
00007eece83cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf0d2  pinsrb xmm1, r12d, 0x02
00007eece83cf0d9  lea r14, [rax+0x09]
00007eece83cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf0e3  pinsrb xmm15, r12d, 0x02
00007eece83cf0ea  lea r14, [rax+0x0A]
00007eece83cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf0f4  pinsrb xmm14, r12d, 0x02
00007eece83cf0fb  lea r14, [rax+0x0B]
00007eece83cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf105  pinsrb xmm13, r12d, 0x02
00007eece83cf10c  lea r14, [rax+0x0C]
00007eece83cf110  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf116  pinsrb xmm1, r12d, 0x03
00007eece83cf11d  lea r14, [rax+0x0D]
00007eece83cf121  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf127  pinsrb xmm15, r12d, 0x03
00007eece83cf12e  lea r14, [rax+0x0E]
00007eece83cf132  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf138  pinsrb xmm14, r12d, 0x03
00007eece83cf13f  lea r14, [rax+0x0F]
00007eece83cf143  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf149  pinsrb xmm13, r12d, 0x03
00007eece83cf150  lea r14, [rax+0x10]
00007eece83cf154  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf15a  pinsrb xmm1, r12d, 0x04
00007eece83cf161  lea r14, [rax+0x11]
00007eece83cf165  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf16b  pinsrb xmm15, r12d, 0x04
00007eece83cf172  lea r14, [rax+0x12]
00007eece83cf176  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf17c  pinsrb xmm14, r12d, 0x04
00007eece83cf183  lea r14, [rax+0x13]
00007eece83cf187  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf18d  pinsrb xmm13, r12d, 0x04
00007eece83cf194  lea r14, [rax+0x14]
00007eece83cf198  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf19e  pinsrb xmm1, r12d, 0x05
00007eece83cf1a5  lea r14, [rax+0x15]
00007eece83cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf1af  pinsrb xmm15, r12d, 0x05
00007eece83cf1b6  lea r14, [rax+0x16]
00007eece83cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf1c0  pinsrb xmm14, r12d, 0x05
00007eece83cf1c7  lea r14, [rax+0x17]
00007eece83cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf1d1  pinsrb xmm13, r12d, 0x05
00007eece83cf1d8  lea r14, [rax+0x18]
00007eece83cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf1e2  pinsrb xmm1, r12d, 0x06
00007eece83cf1e9  lea r14, [rax+0x19]
00007eece83cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf1f3  pinsrb xmm15, r12d, 0x06
00007eece83cf1fa  lea r14, [rax+0x1A]
00007eece83cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf204  pinsrb xmm14, r12d, 0x06
00007eece83cf20b  lea r14, [rax+0x1B]
00007eece83cf20f  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf215  pinsrb xmm13, r12d, 0x06
00007eece83cf21c  lea r14, [rax+0x1C]
00007eece83cf220  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf226  pinsrb xmm1, r12d, 0x07
00007eece83cf22d  lea r14, [rax+0x1D]
00007eece83cf231  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf237  pinsrb xmm15, r12d, 0x07
00007eece83cf23e  lea r14, [rax+0x1E]
00007eece83cf242  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf248  pinsrb xmm14, r12d, 0x07
00007eece83cf24f  lea r14, [rax+0x1F]
00007eece83cf253  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf259  pinsrb xmm13, r12d, 0x07
00007eece83cf260  lea r14, [rax+0x20]
00007eece83cf264  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf26a  pinsrb xmm1, r12d, 0x08
00007eece83cf271  lea r14, [rax+0x21]
00007eece83cf275  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf27b  pinsrb xmm15, r12d, 0x08
00007eece83cf282  lea r14, [rax+0x22]
00007eece83cf286  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf28c  pinsrb xmm14, r12d, 0x08
00007eece83cf293  lea r14, [rax+0x23]
00007eece83cf297  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf29d  pinsrb xmm13, r12d, 0x08
00007eece83cf2a4  lea r14, [rax+0x24]
00007eece83cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf2ae  pinsrb xmm1, r12d, 0x09
00007eece83cf2b5  lea r14, [rax+0x25]
00007eece83cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf2bf  pinsrb xmm15, r12d, 0x09
00007eece83cf2c6  lea r14, [rax+0x26]
00007eece83cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf2d0  pinsrb xmm14, r12d, 0x09
00007eece83cf2d7  lea r14, [rax+0x27]
00007eece83cf2db  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf2e1  pinsrb xmm13, r12d, 0x09
00007eece83cf2e8  lea r14, [rax+0x28]
00007eece83cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf2f2  pinsrb xmm1, r12d, 0x0A
00007eece83cf2f9  lea r14, [rax+0x29]
00007eece83cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf303  pinsrb xmm15, r12d, 0x0A
00007eece83cf30a  lea r14, [rax+0x2A]
00007eece83cf30e  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf314  pinsrb xmm14, r12d, 0x0A
00007eece83cf31b  lea r14, [rax+0x2B]
00007eece83cf31f  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf325  pinsrb xmm13, r12d, 0x0A
00007eece83cf32c  lea r14, [rax+0x2C]
00007eece83cf330  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf336  pinsrb xmm1, r12d, 0x0B
00007eece83cf33d  lea r14, [rax+0x2D]
00007eece83cf341  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf347  pinsrb xmm15, r12d, 0x0B
00007eece83cf34e  lea r14, [rax+0x2E]
00007eece83cf352  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf358  pinsrb xmm14, r12d, 0x0B
00007eece83cf35f  lea r14, [rax+0x2F]
00007eece83cf363  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf369  pinsrb xmm13, r12d, 0x0B
00007eece83cf370  lea r14, [rax+0x30]
00007eece83cf374  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf37a  pinsrb xmm1, r12d, 0x0C
00007eece83cf381  lea r14, [rax+0x31]
00007eece83cf385  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf38b  pinsrb xmm15, r12d, 0x0C
00007eece83cf392  lea r14, [rax+0x32]
00007eece83cf396  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf39c  pinsrb xmm14, r12d, 0x0C
00007eece83cf3a3  lea r14, [rax+0x33]
00007eece83cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf3ad  pinsrb xmm13, r12d, 0x0C
00007eece83cf3b4  lea r14, [rax+0x34]
00007eece83cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf3be  pinsrb xmm1, r12d, 0x0D
00007eece83cf3c5  lea r14, [rax+0x35]
00007eece83cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf3cf  pinsrb xmm15, r12d, 0x0D
00007eece83cf3d6  lea r14, [rax+0x36]
00007eece83cf3da  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf3e0  pinsrb xmm14, r12d, 0x0D
00007eece83cf3e7  lea r14, [rax+0x37]
00007eece83cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf3f1  pinsrb xmm13, r12d, 0x0D
00007eece83cf3f8  lea r14, [rax+0x38]
00007eece83cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf402  pinsrb xmm1, r12d, 0x0E
00007eece83cf409  lea r14, [rax+0x39]
00007eece83cf40d  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf413  pinsrb xmm15, r12d, 0x0E
00007eece83cf41a  lea r14, [rax+0x3A]
00007eece83cf41e  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf424  pinsrb xmm14, r12d, 0x0E
00007eece83cf42b  lea r14, [rax+0x3B]
00007eece83cf42f  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf435  pinsrb xmm13, r12d, 0x0E
00007eece83cf43c  lea r14, [rax+0x3C]
00007eece83cf440  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf446  pinsrb xmm1, r12d, 0x0F
00007eece83cf44d  movaps [r15+0x110], xmm1
00007eece83cf455  lea r14, [rax+0x3D]
00007eece83cf459  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf45f  pinsrb xmm15, r12d, 0x0F
00007eece83cf466  movaps [r15+0x120], xmm15
00007eece83cf46e  lea r14, [rax+0x3E]
00007eece83cf472  movzx r12d, byte ptr [r13+r14*1]
00007eece83cf478  pinsrb xmm14, r12d, 0x0F
00007eece83cf47f  movaps [r15+0x130], xmm14
00007eece83cf487  lea r14, [rax+0x3F]
00007eece83cf48b  movzx eax, byte ptr [r13+r14*1]
00007eece83cf491  pinsrb xmm13, eax, 0x0F
00007eece83cf498  movaps [r15+0x140], xmm13
00007eece83cf4a0  movq xmm1, qword ptr [r15+0x120]
00007eece83cf4a9  pmovzxbw xmm1, xmm1
00007eece83cf4ae  psllw xmm1, 0x00
00007eece83cf4b3  movaps [r15+0x150], xmm1
00007eece83cf4bb  movq xmm1, qword ptr [r15+0x130]
00007eece83cf4c4  pmovzxbw xmm1, xmm1
00007eece83cf4c9  psllw xmm1, 0x00
00007eece83cf4ce  movaps [r15+0x160], xmm1
00007eece83cf4d6  movq xmm1, qword ptr [r15+0x110]
00007eece83cf4df  pmovzxbw xmm1, xmm1
00007eece83cf4e4  psllw xmm1, 0x00
00007eece83cf4e9  movaps [r15+0x170], xmm1
00007eece83cf4f1  movaps xmm15, [r15+0x110]
00007eece83cf4f9  pextrq rax, xmm15, 0x01
00007eece83cf500  movq xmm15, rax
00007eece83cf505  pmovzxbw xmm15, xmm15
00007eece83cf50b  psllw xmm15, 0x00
00007eece83cf511  movaps [r15+0x180], xmm15
00007eece83cf519  movaps xmm14, [r15+0x120]
00007eece83cf521  pextrq rax, xmm14, 0x01
00007eece83cf528  movq xmm14, rax
00007eece83cf52d  pmovzxbw xmm14, xmm14
00007eece83cf533  psllw xmm14, 0x00
00007eece83cf539  movaps [r15+0x210], xmm14
00007eece83cf541  movaps xmm13, [r15+0x130]
00007eece83cf549  pextrq rax, xmm13, 0x01
00007eece83cf550  movq xmm13, rax
00007eece83cf555  pmovzxbw xmm13, xmm13
00007eece83cf55b  psllw xmm13, 0x00
00007eece83cf561  movaps [r15+0x220], xmm13
00007eece83cf569  movq xmm12, qword ptr [r15+0x140]
00007eece83cf572  pmovzxbw xmm12, xmm12
00007eece83cf578  psllw xmm12, 0x00
00007eece83cf57e  movaps [r15+0x250], xmm12
00007eece83cf586  movaps xmm12, [r15+0x140]
00007eece83cf58e  pextrq rax, xmm12, 0x01
00007eece83cf595  movq xmm12, rax
00007eece83cf59a  pmovzxbw xmm12, xmm12
00007eece83cf5a0  psllw xmm12, 0x00
00007eece83cf5a6  movaps [r15+0x110], xmm12
00007eece83cf5ae  movq xmm11, qword ptr [r15+0x150]
00007eece83cf5b7  pmovzxwd xmm11, xmm11
00007eece83cf5bd  pslld xmm11, 0x10
00007eece83cf5c3  movq xmm10, qword ptr [r15+0x160]
00007eece83cf5cc  pmovzxwd xmm10, xmm10
00007eece83cf5d2  pslld xmm10, 0x08
00007eece83cf5d8  pextrq rax, xmm1, 0x01
00007eece83cf5df  movq xmm1, rax
00007eece83cf5e4  pmovzxwd xmm1, xmm1
00007eece83cf5e9  pslld xmm1, 0x00
00007eece83cf5ee  movaps [r15+0x260], xmm1
00007eece83cf5f6  pextrq rax, xmm15, 0x01
00007eece83cf5fd  movq xmm15, rax
00007eece83cf602  pmovzxwd xmm15, xmm15
00007eece83cf608  pslld xmm15, 0x00
00007eece83cf60e  movaps [r15+0x270], xmm15
00007eece83cf616  movq xmm9, qword ptr [r15+0x170]
00007eece83cf61f  pmovzxwd xmm9, xmm9
00007eece83cf625  pslld xmm9, 0x00
00007eece83cf62b  pextrq rax, xmm14, 0x01
00007eece83cf632  movq xmm14, rax
00007eece83cf637  pmovzxwd xmm14, xmm14
00007eece83cf63d  pslld xmm14, 0x10
00007eece83cf643  movaps [r15+0x280], xmm14
00007eece83cf64b  movq xmm8, qword ptr [r15+0x180]
00007eece83cf654  pmovzxwd xmm8, xmm8
00007eece83cf65a  pslld xmm8, 0x00
00007eece83cf660  movq xmm7, qword ptr [r15+0x210]
00007eece83cf669  pmovzxwd xmm7, xmm7
00007eece83cf66e  pslld xmm7, 0x10
00007eece83cf673  movaps xmm6, [r15+0x150]
00007eece83cf67b  pextrq rax, xmm6, 0x01
00007eece83cf682  movq xmm6, rax
00007eece83cf687  pmovzxwd xmm6, xmm6
00007eece83cf68c  pslld xmm6, 0x10
00007eece83cf691  por xmm11, xmm10
00007eece83cf696  movaps [r15+0x230], xmm11
00007eece83cf69e  pextrq rax, xmm13, 0x01
00007eece83cf6a5  movq xmm13, rax
00007eece83cf6aa  pmovzxwd xmm13, xmm13
00007eece83cf6b0  pslld xmm13, 0x08
00007eece83cf6b6  movaps [r15+0x240], xmm13
00007eece83cf6be  movq xmm10, qword ptr [r15+0x220]
00007eece83cf6c7  pmovzxwd xmm10, xmm10
00007eece83cf6cd  pslld xmm10, 0x08
00007eece83cf6d3  movaps xmm5, [r15+0x160]
00007eece83cf6db  pextrq rax, xmm5, 0x01
00007eece83cf6e2  movq xmm5, rax
00007eece83cf6e7  pmovzxwd xmm5, xmm5
00007eece83cf6ec  pslld xmm5, 0x08
00007eece83cf6f1  pslld xmm9, 0x18
00007eece83cf6f7  pslld xmm15, 0x18
00007eece83cf6fd  pslld xmm8, 0x18
00007eece83cf703  movq xmm4, qword ptr [r15+0x250]
00007eece83cf70c  pmovzxwd xmm4, xmm4
00007eece83cf711  pslld xmm4, 0x00
00007eece83cf716  por xmm14, xmm13
00007eece83cf71b  por xmm7, xmm10
00007eece83cf720  movaps [r15+0x210], xmm7
00007eece83cf728  pslld xmm1, 0x18
00007eece83cf72d  movaps [r15+0x220], xmm1
00007eece83cf735  por xmm6, xmm5
00007eece83cf739  por xmm11, xmm9
00007eece83cf73e  movaps [r15+0x160], xmm11
00007eece83cf746  pextrq rax, xmm12, 0x01
00007eece83cf74d  movq xmm13, rax
00007eece83cf752  pmovzxwd xmm13, xmm13
00007eece83cf758  pslld xmm13, 0x00
00007eece83cf75e  movaps [r15+0x170], xmm13
00007eece83cf766  movq xmm12, qword ptr [r15+0x110]
00007eece83cf76f  pmovzxwd xmm12, xmm12
00007eece83cf775  pslld xmm12, 0x00
00007eece83cf77b  por xmm14, xmm15
00007eece83cf780  por xmm7, xmm8
00007eece83cf785  movaps xmm15, [r15+0x250]
00007eece83cf78d  pextrq rax, xmm15, 0x01
00007eece83cf794  movq xmm15, rax
00007eece83cf799  pmovzxwd xmm15, xmm15
00007eece83cf79f  pslld xmm15, 0x00
00007eece83cf7a5  movaps [r15+0x180], xmm15
00007eece83cf7ad  por xmm6, xmm1
00007eece83cf7b1  movaps [r15+0x150], xmm6
00007eece83cf7b9  por xmm11, xmm4
00007eece83cf7be  movaps [r15+0x140], xmm11
00007eece83cf7c6  por xmm7, xmm12
00007eece83cf7cb  movaps [r15+0x110], xmm7
00007eece83cf7d3  por xmm14, xmm13
00007eece83cf7d8  movaps [r15+0x120], xmm14
00007eece83cf7e0  por xmm6, xmm15
00007eece83cf7e5  movaps [r15+0x130], xmm6
00007eece83cf7ed  mov rax, [r15+0xF8]
00007eece83cf7f4  lea r14, [rax+0x20]
00007eece83cf7f8  movups [r13+r14*1], xmm7
00007eece83cf7fe  lea r14, [rax+0x30]
00007eece83cf802  movups [r13+r14*1], xmm14
00007eece83cf808  movups [r13+rax*1], xmm11
00007eece83cf80e  lea r14, [rax+0x10]
00007eece83cf812  movups [r13+r14*1], xmm6
00007eece83cf818  mov r14d, [r13+rax*1]
00007eece83cf81d  mov rax, [r15+0x48]
00007eece83cf821  mov [r15+0x68], rax
00007eece83cf825  mov qword ptr [r15+0x58], 0x04
00007eece83cf82d  lea r12, [rax+0x04]
00007eece83cf831  mov r11d, [r13+r12*1]
00007eece83cf836  mov [rsp+0x10], r11d
00007eece83cf83b  mov r11d, r11d
00007eece83cf83e  mov [r15+0x70], r11
00007eece83cf842  lea r12, [rax+0x38]
00007eece83cf846  mov r11d, [r13+r12*1]
00007eece83cf84b  lea r12, [rax+0x24]
00007eece83cf84f  mov r10d, [r13+r12*1]
00007eece83cf854  mov [rsp+0x20], r10d
00007eece83cf859  mov r10d, r10d
00007eece83cf85c  mov [r15+0x90], r10
00007eece83cf863  mov [rsp+0x30], rax
00007eece83cf868  xor eax, eax
00007eece83cf86a  mov r12d, 0x04
00007eece83cf870  mov r10d, 0xC0
00007eece83cf876  cmp r12, r10
00007eece83cf879  cmc
00007eece83cf87a  lahf
00007eece83cf87b  seto al
00007eece83cf87e  mov [r15+0x108], eax
00007eece83cf885  mov eax, [rsp+0x10]
00007eece83cf889  mov r12d, [rsp+0x10]
00007eece83cf88e  shrd eax, r12d, 0x07
00007eece83cf893  mov [rsp+0x10], r11d
00007eece83cf898  mov r10d, [rsp+0x10]
00007eece83cf89d  shrd r11d, r10d, 0x11
00007eece83cf8a2  mov r9d, [rsp+0x20]
00007eece83cf8a7  lea r8d, [r9d+r14d*1]
00007eece83cf8ac  rorx r14d, r12d, 0x12
00007eece83cf8b2  xor eax, r14d
00007eece83cf8b5  rorx r14d, r10d, 0x13
00007eece83cf8bb  xor r11d, r14d
00007eece83cf8be  mov [rsp+0x10], r11d
00007eece83cf8c3  mov r11d, r11d
00007eece83cf8c6  mov [r15+0x88], r11
00007eece83cf8cd  mov [rsp+0x20], r12d
00007eece83cf8d2  shr r12d, 0x03
00007eece83cf8d6  xor eax, r12d
00007eece83cf8d9  mov [rsp+0x40], eax
00007eece83cf8dd  mov eax, eax
00007eece83cf8df  mov [r15+0x80], rax
00007eece83cf8e6  shr r10d, 0x0A
00007eece83cf8ea  mov eax, [rsp+0x10]
00007eece83cf8ee  xor eax, r10d
00007eece83cf8f1  mov [rsp+0x10], eax
00007eece83cf8f5  mov eax, eax
00007eece83cf8f7  mov [r15+0x78], rax
00007eece83cf8fb  mov eax, [rsp+0x40]
00007eece83cf8ff  lea r14d, [r8d+eax*1]
00007eece83cf904  mov eax, [rsp+0x10]
00007eece83cf908  lea r12d, [r14d+eax*1]
00007eece83cf90d  mov rax, [rsp+0x30]
00007eece83cf912  lea r14, [rax+0x40]
00007eece83cf916  mov [r13+r14*1], r12d
00007eece83cf91b  mov eax, [rsp+0x20]
00007eece83cf91f  mov eax, eax
00007eece83cf921  mov [r15+0x60], rax
00007eece83cf925  mov eax, [r15+0x108]
00007eece83cf92c  sahf
00007eece83cf92d  jnz 0x00007EECE83CF95F
00007eece83cf92f  cmp dword ptr [r15+0x318], 0x00
00007eece83cf937  jz 0x00007EECE83CFE20
00007eece83cf93d  nop [rax+rax*1], ax
00007eece83cf946  nop [rax+rax*1], eax
00007eece83cf94e  mov eax, 0x41049C
00007eece83cf953  mov [r15+0x100], rax
00007eece83cf95a  jmp 0x00007EECE81FE110
00007eece83cf95f  cmp dword ptr [r15+0x318], 0x00
00007eece83cf967  jz 0x00007EECE83CFC70
00007eece83cf96d  nop [rax+rax*1], ax
00007eece83cf976  nop [rax+rax*1], eax
00007eece83cf97e  mov eax, 0x410454
00007eece83cf983  mov [r15+0x100], rax
00007eece83cf98a  jmp 0x00007EECE81FE110
00007eece83cf98f  int3
00007eece83cf990  call 0x00007EECE820D860
00007eece83cf995  jmp 0x00007EECE83CF02A
00007eece83cf99a  call 0x00007EECE82E2420
00007eece83cf99f  jmp 0x00007EECE83CF043
00007eece83cf9a4  call 0x00007EECE82E2420
00007eece83cf9a9  jmp 0x00007EECE83CF05C
00007eece83cf9ae  call 0x00007EECE82E2420
00007eece83cf9b3  jmp 0x00007EECE83CF075
00007eece83cf9b8  call 0x00007EECE82E2420
00007eece83cf9bd  jmp 0x00007EECE83CF08E
00007eece83cf9c2  call 0x00007EECE82E2420
00007eece83cf9c7  jmp 0x00007EECE83CF09F
00007eece83cf9cc  call 0x00007EECE82E2420
00007eece83cf9d1  jmp 0x00007EECE83CF0B0
00007eece83cf9d6  call 0x00007EECE82E2420
00007eece83cf9db  jmp 0x00007EECE83CF0C1
00007eece83cf9e0  call 0x00007EECE82E2420
00007eece83cf9e5  jmp 0x00007EECE83CF0D2
00007eece83cf9ea  call 0x00007EECE82E2420
00007eece83cf9ef  jmp 0x00007EECE83CF0E3
00007eece83cf9f4  call 0x00007EECE82E2420
00007eece83cf9f9  jmp 0x00007EECE83CF0F4
00007eece83cf9fe  call 0x00007EECE82E2420
00007eece83cfa03  jmp 0x00007EECE83CF105
00007eece83cfa08  call 0x00007EECE82E2420
00007eece83cfa0d  jmp 0x00007EECE83CF116
00007eece83cfa12  call 0x00007EECE82E2420
00007eece83cfa17  jmp 0x00007EECE83CF127
00007eece83cfa1c  call 0x00007EECE82E2420
00007eece83cfa21  jmp 0x00007EECE83CF138
00007eece83cfa26  call 0x00007EECE82E2420
00007eece83cfa2b  jmp 0x00007EECE83CF149
00007eece83cfa30  call 0x00007EECE82E2420
00007eece83cfa35  jmp 0x00007EECE83CF15A
00007eece83cfa3a  call 0x00007EECE82E2420
00007eece83cfa3f  jmp 0x00007EECE83CF16B
00007eece83cfa44  call 0x00007EECE82E2420
00007eece83cfa49  jmp 0x00007EECE83CF17C
00007eece83cfa4e  call 0x00007EECE82E2420
00007eece83cfa53  jmp 0x00007EECE83CF18D
00007eece83cfa58  call 0x00007EECE82E2420
00007eece83cfa5d  jmp 0x00007EECE83CF19E
00007eece83cfa62  call 0x00007EECE82E2420
00007eece83cfa67  jmp 0x00007EECE83CF1AF
00007eece83cfa6c  call 0x00007EECE82E2420
00007eece83cfa71  jmp 0x00007EECE83CF1C0
00007eece83cfa76  call 0x00007EECE82E2420
00007eece83cfa7b  jmp 0x00007EECE83CF1D1
00007eece83cfa80  call 0x00007EECE82E2420
00007eece83cfa85  jmp 0x00007EECE83CF1E2
00007eece83cfa8a  call 0x00007EECE82E2420
00007eece83cfa8f  jmp 0x00007EECE83CF1F3
00007eece83cfa94  call 0x00007EECE82E2420
00007eece83cfa99  jmp 0x00007EECE83CF204
00007eece83cfa9e  call 0x00007EECE82E2420
00007eece83cfaa3  jmp 0x00007EECE83CF215
00007eece83cfaa8  call 0x00007EECE82E2420
00007eece83cfaad  jmp 0x00007EECE83CF226
00007eece83cfab2  call 0x00007EECE82E2420
00007eece83cfab7  jmp 0x00007EECE83CF237
00007eece83cfabc  call 0x00007EECE82E2420
00007eece83cfac1  jmp 0x00007EECE83CF248
00007eece83cfac6  call 0x00007EECE82E2420
00007eece83cfacb  jmp 0x00007EECE83CF259
00007eece83cfad0  call 0x00007EECE82E2420
00007eece83cfad5  jmp 0x00007EECE83CF26A
00007eece83cfada  call 0x00007EECE82E2420
00007eece83cfadf  jmp 0x00007EECE83CF27B
00007eece83cfae4  call 0x00007EECE82E2420
00007eece83cfae9  jmp 0x00007EECE83CF28C
00007eece83cfaee  call 0x00007EECE82E2420
00007eece83cfaf3  jmp 0x00007EECE83CF29D
00007eece83cfaf8  call 0x00007EECE82E2420
00007eece83cfafd  jmp 0x00007EECE83CF2AE
00007eece83cfb02  call 0x00007EECE82E2420
00007eece83cfb07  jmp 0x00007EECE83CF2BF
00007eece83cfb0c  call 0x00007EECE82E2420
00007eece83cfb11  jmp 0x00007EECE83CF2D0
00007eece83cfb16  call 0x00007EECE82E2420
00007eece83cfb1b  jmp 0x00007EECE83CF2E1
00007eece83cfb20  call 0x00007EECE82E2420
00007eece83cfb25  jmp 0x00007EECE83CF2F2
00007eece83cfb2a  call 0x00007EECE82E2420
00007eece83cfb2f  jmp 0x00007EECE83CF303
00007eece83cfb34  call 0x00007EECE82E2420
00007eece83cfb39  jmp 0x00007EECE83CF314
00007eece83cfb3e  call 0x00007EECE82E2420
00007eece83cfb43  jmp 0x00007EECE83CF325
00007eece83cfb48  call 0x00007EECE82E2420
00007eece83cfb4d  jmp 0x00007EECE83CF336
00007eece83cfb52  call 0x00007EECE82E2420
00007eece83cfb57  jmp 0x00007EECE83CF347
00007eece83cfb5c  call 0x00007EECE82E2420
00007eece83cfb61  jmp 0x00007EECE83CF358
00007eece83cfb66  call 0x00007EECE82E2420
00007eece83cfb6b  jmp 0x00007EECE83CF369
00007eece83cfb70  call 0x00007EECE82E2420
00007eece83cfb75  jmp 0x00007EECE83CF37A
00007eece83cfb7a  call 0x00007EECE82E2420
00007eece83cfb7f  jmp 0x00007EECE83CF38B
00007eece83cfb84  call 0x00007EECE82E2420
00007eece83cfb89  jmp 0x00007EECE83CF39C
00007eece83cfb8e  call 0x00007EECE82E2420
00007eece83cfb93  jmp 0x00007EECE83CF3AD
00007eece83cfb98  call 0x00007EECE82E2420
00007eece83cfb9d  jmp 0x00007EECE83CF3BE
00007eece83cfba2  call 0x00007EECE82E2420
00007eece83cfba7  jmp 0x00007EECE83CF3CF
00007eece83cfbac  call 0x00007EECE82E2420
00007eece83cfbb1  jmp 0x00007EECE83CF3E0
00007eece83cfbb6  call 0x00007EECE82E2420
00007eece83cfbbb  jmp 0x00007EECE83CF3F1
00007eece83cfbc0  call 0x00007EECE82E2420
00007eece83cfbc5  jmp 0x00007EECE83CF402
00007eece83cfbca  call 0x00007EECE82E2420
00007eece83cfbcf  jmp 0x00007EECE83CF413
00007eece83cfbd4  call 0x00007EECE82E2420
00007eece83cfbd9  jmp 0x00007EECE83CF424
00007eece83cfbde  call 0x00007EECE82E2420
00007eece83cfbe3  jmp 0x00007EECE83CF435
00007eece83cfbe8  call 0x00007EECE82E2420
00007eece83cfbed  jmp 0x00007EECE83CF446
00007eece83cfbf2  call 0x00007EECE82E2420
00007eece83cfbf7  jmp 0x00007EECE83CF45F
00007eece83cfbfc  call 0x00007EECE82E2420
00007eece83cfc01  jmp 0x00007EECE83CF478
00007eece83cfc06  call 0x00007EECE82D5610
00007eece83cfc0b  jmp 0x00007EECE83CF491
00007eece83cfc10  call 0x00007EECE82DC580
00007eece83cfc15  jmp 0x00007EECE83CF7FE
00007eece83cfc1a  call 0x00007EECE82E46C0
00007eece83cfc1f  jmp 0x00007EECE83CF808
00007eece83cfc24  call 0x00007EECE8209E90
00007eece83cfc29  jmp 0x00007EECE83CF80E
00007eece83cfc2e  call 0x00007EECE82DB310
00007eece83cfc33  jmp 0x00007EECE83CF818
00007eece83cfc38  call 0x00007EECE820DAE0
00007eece83cfc3d  jmp 0x00007EECE83CF81D
00007eece83cfc42  call 0x00007EECE82C0230
00007eece83cfc47  jmp 0x00007EECE83CF836
00007eece83cfc4c  call 0x00007EECE82C0230
00007eece83cfc51  jmp 0x00007EECE83CF84B
00007eece83cfc56  call 0x00007EECE82BEFC0
00007eece83cfc5b  jmp 0x00007EECE83CF854
00007eece83cfc60  call 0x00007EECE82E2BA0
00007eece83cfc65  jmp 0x00007EECE83CF91B
00007eece83cfc6a  int3
00007eece83cfc6b  nop [rax+rax*1], eax
00007eece83cfc70  mov rax, [r15+0x48]
00007eece83cfc74  mov r14, [r15+0x58]
00007eece83cfc78  lea r12, [rax+r14*1]
00007eece83cfc7c  mov [r15+0x68], r12
00007eece83cfc80  lea rax, [r14+0x04]
00007eece83cfc84  mov [r15+0x58], rax
00007eece83cfc88  lea r14, [r12+0x04]
00007eece83cfc8d  mov r11d, [r13+r14*1]
00007eece83cfc92  mov [rsp+0x10], r11d
00007eece83cfc97  mov r11d, r11d
00007eece83cfc9a  mov [r15+0x70], r11
00007eece83cfc9e  lea r14, [r12+0x38]
00007eece83cfca3  mov r11d, [r13+r14*1]
00007eece83cfca8  lea r14, [r12+0x24]
00007eece83cfcad  mov r10d, [r13+r14*1]
00007eece83cfcb2  mov [rsp+0x20], r10d
00007eece83cfcb7  mov r10d, r10d
00007eece83cfcba  mov [r15+0x90], r10
00007eece83cfcc1  mov [rsp+0x30], rax
00007eece83cfcc6  xor eax, eax
00007eece83cfcc8  mov r14, [rsp+0x30]
00007eece83cfccd  mov r10d, 0xC0
00007eece83cfcd3  cmp r14, r10
00007eece83cfcd6  cmc
00007eece83cfcd7  lahf
00007eece83cfcd8  seto al
00007eece83cfcdb  mov [r15+0x108], eax
00007eece83cfce2  mov eax, [rsp+0x10]
00007eece83cfce6  mov r14d, [rsp+0x10]
00007eece83cfceb  shrd eax, r14d, 0x07
00007eece83cfcf0  mov [rsp+0x10], r11d
00007eece83cfcf5  mov r10d, [rsp+0x10]
00007eece83cfcfa  shrd r11d, r10d, 0x11
00007eece83cfcff  mov r9d, [r15+0x60]
00007eece83cfd03  mov r8d, [rsp+0x20]
00007eece83cfd08  lea ebp, [r8d+r9d*1]
00007eece83cfd0d  rorx r9d, r14d, 0x12
00007eece83cfd13  xor eax, r9d
00007eece83cfd16  rorx r9d, r10d, 0x13
00007eece83cfd1c  xor r11d, r9d
00007eece83cfd1f  mov [rsp+0x10], r11d
00007eece83cfd24  mov r11d, r11d
00007eece83cfd27  mov [r15+0x88], r11
00007eece83cfd2e  mov [rsp+0x20], r14d
00007eece83cfd33  shr r14d, 0x03
00007eece83cfd37  xor eax, r14d
00007eece83cfd3a  mov [rsp+0x30], eax
00007eece83cfd3e  mov eax, eax
00007eece83cfd40  mov [r15+0x80], rax
00007eece83cfd47  shr r10d, 0x0A
00007eece83cfd4b  mov eax, [rsp+0x10]
00007eece83cfd4f  xor eax, r10d
00007eece83cfd52  mov [rsp+0x10], eax
00007eece83cfd56  mov eax, eax
00007eece83cfd58  mov [r15+0x78], rax
00007eece83cfd5c  mov eax, [rsp+0x30]
00007eece83cfd60  lea r14d, [ebp+eax*1]
00007eece83cfd66  mov eax, [rsp+0x10]
00007eece83cfd6a  lea r11d, [r14d+eax*1]
00007eece83cfd6f  lea rax, [r12+0x40]
00007eece83cfd74  mov [r13+rax*1], r11d
00007eece83cfd79  mov eax, [rsp+0x20]
00007eece83cfd7d  mov eax, eax
00007eece83cfd7f  mov [r15+0x60], rax
00007eece83cfd83  mov eax, [r15+0x108]
00007eece83cfd8a  sahf
00007eece83cfd8b  jnz 0x00007EECE83CFDBD
00007eece83cfd8d  cmp dword ptr [r15+0x318], 0x00
00007eece83cfd95  jz 0x00007EECE83CFE20
00007eece83cfd9b  nop [rax+rax*1], ax
00007eece83cfda4  nop [rax+rax*1], eax
00007eece83cfdac  mov eax, 0x41049C
00007eece83cfdb1  mov [r15+0x100], rax
00007eece83cfdb8  jmp 0x00007EECE81FE110
00007eece83cfdbd  cmp dword ptr [r15+0x318], 0x00
00007eece83cfdc5  jz 0x00007EECE83CFC70
00007eece83cfdcb  nop [rax+rax*1], ax
00007eece83cfdd4  nop [rax+rax*1], eax
00007eece83cfddc  mov eax, 0x410454
00007eece83cfde1  mov [r15+0x100], rax
00007eece83cfde8  jmp 0x00007EECE81FE110
00007eece83cfded  int3
00007eece83cfdee  call 0x00007EECE82E1430
00007eece83cfdf3  jmp 0x00007EECE83CFC92
00007eece83cfdf8  call 0x00007EECE82E1430
00007eece83cfdfd  jmp 0x00007EECE83CFCA8
00007eece83cfe02  call 0x00007EECE82E01C0
00007eece83cfe07  jmp 0x00007EECE83CFCB2
00007eece83cfe0c  call 0x00007EECE820A860
00007eece83cfe11  jmp 0x00007EECE83CFD79
00007eece83cfe16  int3
00007eece83cfe17  nop [rax+rax*1], ax
00007eece83cfe20  mov rax, [r15]
00007eece83cfe23  mov r14d, [r13+rax*1]
00007eece83cfe28  lea r12, [rax+0x04]
00007eece83cfe2c  mov r11d, [r13+r12*1]
00007eece83cfe31  mov [rsp+0x10], r14d
00007eece83cfe36  mov r14d, r14d
00007eece83cfe39  mov [r15+0x78], r14
00007eece83cfe3d  mov [rsp+0x20], r11d
00007eece83cfe42  mov r11d, r11d
00007eece83cfe45  mov [r15+0x80], r11
00007eece83cfe4c  lea r14, [rax+0x08]
00007eece83cfe50  mov r12d, [r13+r14*1]
00007eece83cfe55  lea r14, [rax+0x0C]
00007eece83cfe59  mov r11d, [r13+r14*1]
00007eece83cfe5e  mov [rsp+0x30], r12d
00007eece83cfe63  mov r12d, r12d
00007eece83cfe66  mov [r15+0x70], r12
00007eece83cfe6a  mov [rsp+0x40], r11d
00007eece83cfe6f  mov r11d, r11d
00007eece83cfe72  mov [r15+0x68], r11
00007eece83cfe76  lea r14, [rax+0x18]
00007eece83cfe7a  mov r12d, [r13+r14*1]
00007eece83cfe7f  lea r14, [rax+0x1C]
00007eece83cfe83  mov r11d, [r13+r14*1]
00007eece83cfe88  mov [rsp+0x50], r12d
00007eece83cfe8d  mov r12d, r12d
00007eece83cfe90  mov [r15+0x58], r12
00007eece83cfe94  mov [rsp+0x60], r11d
00007eece83cfe99  mov r11d, r11d
00007eece83cfe9c  mov [r15+0x60], r11
00007eece83cfea0  lea r14, [rax+0x10]
00007eece83cfea4  mov r12d, [r13+r14*1]
00007eece83cfea9  lea r14, [rax+0x14]
00007eece83cfead  mov eax, [r13+r14*1]
00007eece83cfeb2  mov [rsp+0x70], r12d
00007eece83cfeb7  mov r12d, r12d
00007eece83cfeba  mov [r15+0x18], r12
00007eece83cfebe  mov [rsp+0x80], eax
00007eece83cfec5  mov eax, eax
00007eece83cfec7  mov [r15+0x90], rax
00007eece83cfece  mov eax, [rsp+0x70]
00007eece83cfed2  mov eax, eax
00007eece83cfed4  mov [r15+0x30], rax
00007eece83cfed8  mov eax, [rsp+0x50]
00007eece83cfedc  mov eax, eax
00007eece83cfede  mov [r15+0xA0], rax
00007eece83cfee5  mov eax, [rsp+0x30]
00007eece83cfee9  mov eax, eax
00007eece83cfeeb  mov [r15+0x28], rax
00007eece83cfeef  mov eax, [rsp+0x20]
00007eece83cfef3  mov eax, eax
00007eece83cfef5  mov [r15+0x98], rax
00007eece83cfefc  mov eax, [rsp+0x10]
00007eece83cff00  mov eax, eax
00007eece83cff02  mov [r15+0x38], rax
00007eece83cff06  mov eax, [rsp+0x70]
00007eece83cff0a  mov r14d, [rsp+0x70]
00007eece83cff0f  shrd eax, r14d, 0x06
00007eece83cff14  mov [rsp+0x70], r14d
00007eece83cff19  mov r12d, [rsp+0x80]
00007eece83cff21  and r14d, r12d
00007eece83cff24  mov r11d, [rsp+0x10]
00007eece83cff29  mov r10d, [rsp+0x10]
00007eece83cff2e  shrd r11d, r10d, 0x02
00007eece83cff33  mov [rsp+0x10], r12d
00007eece83cff38  mov r12d, r12d
00007eece83cff3b  mov [r15+0x20], r12
00007eece83cff3f  mov r12, [r15+0x50]
00007eece83cff43  mov r9d, [r13+r12*1]
00007eece83cff48  mov r12d, [rsp+0x50]
00007eece83cff4d  mov r8d, [rsp+0x70]
00007eece83cff52  andn ebp, r8d, r12d
00007eece83cff57  mov edi, [rsp+0x60]
00007eece83cff5b  lea esi, [r14d+edi*1]
00007eece83cff60  rorx r14d, r8d, 0x0B
00007eece83cff66  xor eax, r14d
00007eece83cff69  rorx r14d, r10d, 0x0D
00007eece83cff6f  xor r11d, r14d
00007eece83cff72  lea edi, [esi+ebp*1]
00007eece83cff76  mov r14, [r15+0x48]
00007eece83cff7a  mov ebp, [r13+r14*1]
00007eece83cff7f  mov r14d, [rsp+0x30]
00007eece83cff84  mov esi, [rsp+0x20]
00007eece83cff88  and r14d, esi
00007eece83cff8b  mov [rsp+0x20], r14d
00007eece83cff90  mov r14d, r14d
00007eece83cff93  mov [r15+0xD8], r14
00007eece83cff9a  lea r14d, [edi+r9d*1]
00007eece83cff9f  mov r9d, [rsp+0x30]
00007eece83cffa4  xor r9d, esi
00007eece83cffa7  rorx edi, r8d, 0x19
00007eece83cffad  xor eax, edi
00007eece83cffaf  and r9d, r10d
00007eece83cffb2  rorx edi, r10d, 0x16
00007eece83cffb8  xor r11d, edi
00007eece83cffbb  mov [rsp+0x30], r11d
00007eece83cffc0  mov r11d, r11d
00007eece83cffc3  mov [r15+0xD0], r11
00007eece83cffca  lea r11d, [r14d+ebp*1]
00007eece83cffcf  mov r10d, [rsp+0x20]
00007eece83cffd4  xor r9d, r10d
00007eece83cffd7  lea r14d, [r11d+eax*1]
00007eece83cffdc  mov qword ptr [r15+0x88], 0x04
00007eece83cffe7  mov eax, [rsp+0x30]
00007eece83cffeb  lea r11d, [r9d+eax*1]
00007eece83cfff0  mov eax, [rsp+0x40]
00007eece83cfff4  lea r10d, [r14d+eax*1]
00007eece83cfff9  mov r10d, r10d
00007eece83cfffc  mov [r15+0xB8], r10
00007eece83d0003  xor eax, eax
00007eece83d0005  mov r10d, 0x04
00007eece83d000b  mov r9d, 0x100
00007eece83d0011  cmp r10, r9
00007eece83d0014  cmc
00007eece83d0015  lahf
00007eece83d0016  seto al
00007eece83d0019  mov [r15+0x108], eax
00007eece83d0020  lea eax, [r11d+r14d*1]
00007eece83d0025  mov eax, eax
00007eece83d0027  mov [r15+0xA8], rax
00007eece83d002e  mov r12d, r12d
00007eece83d0031  mov [r15+0xB0], r12
00007eece83d0038  mov eax, [rsp+0x10]
00007eece83d003c  mov eax, eax
00007eece83d003e  mov [r15+0xC0], rax
00007eece83d0045  mov r8d, r8d
00007eece83d0048  mov [r15+0xC8], r8
00007eece83d004f  mov eax, [r15+0x108]
00007eece83d0056  sahf
00007eece83d0057  jnz 0x00007EECE83D0089
00007eece83d0059  cmp dword ptr [r15+0x318], 0x00
00007eece83d0061  jz 0x00007EECE83D0350
00007eece83d0067  nop [rax+rax*1], ax
00007eece83d0070  nop [rax+rax*1], eax
00007eece83d0078  mov eax, 0x41055C
00007eece83d007d  mov [r15+0x100], rax
00007eece83d0084  jmp 0x00007EECE81FE110
00007eece83d0089  cmp dword ptr [r15+0x318], 0x00
00007eece83d0091  jz 0x00007EECE83D0120
00007eece83d0097  nop [rax+rax*1], ax
00007eece83d00a0  nop [rax+rax*1], eax
00007eece83d00a8  mov eax, 0x4104D0
00007eece83d00ad  mov [r15+0x100], rax
00007eece83d00b4  jmp 0x00007EECE81FE110
00007eece83d00b9  int3
00007eece83d00ba  call 0x00007EECE820DAE0
00007eece83d00bf  jmp 0x00007EECE83CFE28
00007eece83d00c4  call 0x00007EECE82C0230
00007eece83d00c9  jmp 0x00007EECE83CFE31
00007eece83d00ce  call 0x00007EECE82E26A0
00007eece83d00d3  jmp 0x00007EECE83CFE55
00007eece83d00d8  call 0x00007EECE82E1430
00007eece83d00dd  jmp 0x00007EECE83CFE5E
00007eece83d00e2  call 0x00007EECE82E26A0
00007eece83d00e7  jmp 0x00007EECE83CFE7F
00007eece83d00ec  call 0x00007EECE82E1430
00007eece83d00f1  jmp 0x00007EECE83CFE88
00007eece83d00f6  call 0x00007EECE82E26A0
00007eece83d00fb  jmp 0x00007EECE83CFEA9
00007eece83d0100  call 0x00007EECE82D5890
00007eece83d0105  jmp 0x00007EECE83CFEB2
00007eece83d010a  call 0x00007EECE82BDD50
00007eece83d010f  jmp 0x00007EECE83CFF48
00007eece83d0114  call 0x00007EECE82DA580
00007eece83d0119  jmp 0x00007EECE83CFF7F
00007eece83d011e  int3
00007eece83d011f  nop
00007eece83d0120  mov eax, [r15+0xB8]
00007eece83d0127  mov [rsp+0x10], eax
00007eece83d012b  mov eax, eax
00007eece83d012d  mov [r15+0x30], rax
00007eece83d0131  mov eax, [r15+0xC0]
00007eece83d0138  mov [rsp+0x20], eax
00007eece83d013c  mov eax, eax
00007eece83d013e  mov [r15+0xA0], rax
00007eece83d0145  mov eax, [r15+0x28]
00007eece83d0149  mov r14d, [r15+0x98]
00007eece83d0150  mov [rsp+0x30], r14d
00007eece83d0155  mov r14d, r14d
00007eece83d0158  mov [r15+0x28], r14
00007eece83d015c  mov r14d, [r15+0x38]
00007eece83d0160  mov [rsp+0x40], r14d
00007eece83d0165  mov r14d, r14d
00007eece83d0168  mov [r15+0x98], r14
00007eece83d016f  mov r14d, [r15+0xA8]
00007eece83d0176  mov [rsp+0x50], r14d
00007eece83d017b  mov r14d, r14d
00007eece83d017e  mov [r15+0x38], r14
00007eece83d0182  mov r14d, [rsp+0x10]
00007eece83d0187  mov r12d, [rsp+0x10]
00007eece83d018c  shrd r14d, r12d, 0x06
00007eece83d0191  mov r11d, [r15+0xC8]
00007eece83d0198  mov [rsp+0x10], r12d
00007eece83d019d  and r12d, r11d
00007eece83d01a0  mov r10d, [rsp+0x50]
00007eece83d01a5  mov r9d, [rsp+0x50]
00007eece83d01aa  shrd r10d, r9d, 0x02
00007eece83d01af  mov [rsp+0x50], r11d
00007eece83d01b4  mov r11d, r11d
00007eece83d01b7  mov [r15+0x20], r11
00007eece83d01bb  mov r11, [r15+0x88]
00007eece83d01c2  mov r8, [r15+0x50]
00007eece83d01c6  lea rbp, [r8+r11*1]
00007eece83d01ca  mov r8d, [r13+rbp*1]
00007eece83d01cf  mov ebp, [rsp+0x20]
00007eece83d01d3  mov edi, [rsp+0x10]
00007eece83d01d7  andn esi, edi, ebp
00007eece83d01dc  mov edx, [r15+0xB0]
00007eece83d01e3  lea ecx, [r12d+edx*1]
00007eece83d01e8  rorx r12d, edi, 0x0B
00007eece83d01ee  xor r14d, r12d
00007eece83d01f1  rorx r12d, r9d, 0x0D
00007eece83d01f7  xor r10d, r12d
00007eece83d01fa  lea r12d, [ecx+esi*1]
00007eece83d01ff  mov rsi, [r15+0x48]
00007eece83d0203  lea rdx, [rsi+r11*1]
00007eece83d0207  mov esi, [r13+rdx*1]
00007eece83d020c  mov edx, [rsp+0x30]
00007eece83d0210  mov ecx, [rsp+0x40]
00007eece83d0214  and edx, ecx
00007eece83d0216  mov [rsp+0x10], edx
00007eece83d021a  mov edx, edx
00007eece83d021c  mov [r15+0xD8], rdx
00007eece83d0223  lea edx, [r12d+r8d*1]
00007eece83d0228  mov r12d, [rsp+0x30]
00007eece83d022d  xor r12d, ecx
00007eece83d0230  rorx r8d, edi, 0x19
00007eece83d0236  xor r14d, r8d
00007eece83d0239  and r12d, r9d
00007eece83d023c  rorx r8d, r9d, 0x16
00007eece83d0242  xor r10d, r8d
00007eece83d0245  mov [rsp+0x20], r10d
00007eece83d024a  mov r10d, r10d
00007eece83d024d  mov [r15+0xD0], r10
00007eece83d0254  lea r10d, [edx+esi*1]
00007eece83d0259  mov r9d, [rsp+0x10]
00007eece83d025e  xor r12d, r9d
00007eece83d0261  lea r9d, [r10d+r14d*1]
00007eece83d0266  lea r14, [r11+0x04]
00007eece83d026a  mov [r15+0x88], r14
00007eece83d0271  mov r11d, [rsp+0x20]
00007eece83d0276  lea r10d, [r12d+r11d*1]
00007eece83d027b  lea r11d, [r9d+eax*1]
00007eece83d0280  mov r11d, r11d
00007eece83d0283  mov [r15+0xB8], r11
00007eece83d028a  xor eax, eax
00007eece83d028c  mov r12d, 0x100
00007eece83d0292  cmp r14, r12
00007eece83d0295  cmc
00007eece83d0296  lahf
00007eece83d0297  seto al
00007eece83d029a  mov [r15+0x108], eax
00007eece83d02a1  lea eax, [r10d+r9d*1]
00007eece83d02a6  mov eax, eax
00007eece83d02a8  mov [r15+0xA8], rax
00007eece83d02af  mov ebp, ebp
00007eece83d02b1  mov [r15+0xB0], rbp
00007eece83d02b8  mov eax, [rsp+0x50]
00007eece83d02bc  mov eax, eax
00007eece83d02be  mov [r15+0xC0], rax
00007eece83d02c5  mov edi, edi
00007eece83d02c7  mov [r15+0xC8], rdi
00007eece83d02ce  mov eax, [r15+0x108]
00007eece83d02d5  sahf
00007eece83d02d6  jnz 0x00007EECE83D0308
00007eece83d02d8  cmp dword ptr [r15+0x318], 0x00
00007eece83d02e0  jz 0x00007EECE83D0350
00007eece83d02e6  nop [rax+rax*1], ax
00007eece83d02ef  nop [rax+rax*1], eax
00007eece83d02f7  mov eax, 0x41055C
00007eece83d02fc  mov [r15+0x100], rax
00007eece83d0303  jmp 0x00007EECE81FE110
00007eece83d0308  cmp dword ptr [r15+0x318], 0x00
00007eece83d0310  jz 0x00007EECE83D0120
00007eece83d0316  nop [rax+rax*1], ax
00007eece83d031f  nop [rax+rax*1], eax
00007eece83d0327  mov eax, 0x4104D0
00007eece83d032c  mov [r15+0x100], rax
00007eece83d0333  jmp 0x00007EECE81FE110
00007eece83d0338  int3
00007eece83d0339  call 0x00007EECE8249010
00007eece83d033e  jmp 0x00007EECE83D01CF
00007eece83d0343  call 0x00007EECE8225930
00007eece83d0348  jmp 0x00007EECE83D020C
00007eece83d034d  int3
00007eece83d034e  nop
00007eece83d0350  mov eax, [r15+0x98]
00007eece83d0357  mov r14d, [r15+0x70]
00007eece83d035b  lea r12d, [eax+r14d*1]
00007eece83d0360  mov eax, [r15+0x28]
00007eece83d0364  mov r14d, [r15+0x68]
00007eece83d0368  lea r11d, [eax+r14d*1]
00007eece83d036d  mov qword ptr [r15+0x88], 0x00
00007eece83d0378  mov eax, [r15+0xA8]
00007eece83d037f  mov r14d, [r15+0x78]
00007eece83d0383  lea r10d, [eax+r14d*1]
00007eece83d0388  mov [rsp+0x10], r10d
00007eece83d038d  mov r10d, r10d
00007eece83d0390  mov [r15+0x78], r10
00007eece83d0394  mov eax, [r15+0x38]
00007eece83d0398  mov r14d, [r15+0x80]
00007eece83d039f  lea r10d, [eax+r14d*1]
00007eece83d03a4  mov [rsp+0x20], r10d
00007eece83d03a9  mov r10d, r10d
00007eece83d03ac  mov [r15+0x80], r10
00007eece83d03b3  mov rax, [r15]
00007eece83d03b6  lea r14, [rax+0x08]
00007eece83d03ba  mov [r13+r14*1], r12d
00007eece83d03bf  lea r14, [rax+0x0C]
00007eece83d03c3  mov [r13+r14*1], r11d
00007eece83d03c8  mov r14d, [r15+0xB8]
00007eece83d03cf  mov r12d, [r15+0x18]
00007eece83d03d3  lea r11d, [r14d+r12d*1]
00007eece83d03d8  mov [rsp+0x30], r11d
00007eece83d03dd  mov r11d, r11d
00007eece83d03e0  mov [r15+0x68], r11
00007eece83d03e4  mov r14d, [r15+0x30]
00007eece83d03e8  mov r12d, [r15+0x90]
00007eece83d03ef  lea r11d, [r14d+r12d*1]
00007eece83d03f4  mov [rsp+0x40], r11d
00007eece83d03f9  mov r11d, r11d
00007eece83d03fc  mov [r15+0x70], r11
00007eece83d0400  mov r14d, [r15+0x20]
00007eece83d0404  mov r12d, [r15+0x58]
00007eece83d0408  lea r11d, [r14d+r12d*1]
00007eece83d040d  mov [rsp+0x50], r11d
00007eece83d0412  mov r11d, r11d
00007eece83d0415  mov [r15+0x58], r11
00007eece83d0419  mov r14d, [r15+0xA0]
00007eece83d0420  mov r12d, [r15+0x60]
00007eece83d0424  lea r11d, [r14d+r12d*1]
00007eece83d0429  mov [rsp+0x60], r11d
00007eece83d042e  mov r11d, r11d
00007eece83d0431  mov [r15+0x60], r11
00007eece83d0435  mov r14d, [rsp+0x10]
00007eece83d043a  mov [r13+rax*1], r14d
00007eece83d043f  lea r14, [rax+0x04]
00007eece83d0443  mov r12d, [rsp+0x20]
00007eece83d0448  mov [r13+r14*1], r12d
00007eece83d044d  lea r14, [rax+0x10]
00007eece83d0451  mov r12d, [rsp+0x30]
00007eece83d0456  mov [r13+r14*1], r12d
00007eece83d045b  lea r14, [rax+0x14]
00007eece83d045f  mov r12d, [rsp+0x40]
00007eece83d0464  mov [r13+r14*1], r12d
00007eece83d0469  lea r14, [rax+0x18]
00007eece83d046d  mov r12d, [rsp+0x50]
00007eece83d0472  mov [r13+r14*1], r12d
00007eece83d0477  lea r14, [rax+0x1C]
00007eece83d047b  mov r12d, [rsp+0x60]
00007eece83d0480  mov [r13+r14*1], r12d
00007eece83d0485  lea r14, [rax+0x68]
00007eece83d0489  xor eax, eax
00007eece83d048b  mov [r13+r14*1], rax
00007eece83d0490  cmp dword ptr [r15+0x318], 0x00
00007eece83d0498  jz 0x00007EECE83CEF90
00007eece83d049e  nop [rax+rax*1], ax
00007eece83d04a7  nop [rax+rax*1], eax
00007eece83d04af  mov eax, 0x410378
00007eece83d04b4  mov [r15+0x100], rax
00007eece83d04bb  jmp 0x00007EECE81FE110
00007eece83d04c0  int3
00007eece83d04c1  call 0x00007EECE82E2BA0
00007eece83d04c6  jmp 0x00007EECE83D03BF
00007eece83d04cb  call 0x00007EECE82E1920
00007eece83d04d0  jmp 0x00007EECE83D03C8
00007eece83d04d5  call 0x00007EECE820DFE0
00007eece83d04da  jmp 0x00007EECE83D043F
00007eece83d04df  call 0x00007EECE82E2BA0
00007eece83d04e4  jmp 0x00007EECE83D044D
00007eece83d04e9  call 0x00007EECE82E2BA0
00007eece83d04ee  jmp 0x00007EECE83D045B
00007eece83d04f3  call 0x00007EECE82E2BA0
00007eece83d04f8  jmp 0x00007EECE83D0469
00007eece83d04fd  call 0x00007EECE82E2BA0
00007eece83d0502  jmp 0x00007EECE83D0477
00007eece83d0507  call 0x00007EECE82E2BA0
00007eece83d050c  jmp 0x00007EECE83D0485
00007eece83d0511  call 0x00007EECE82D5EB0
00007eece83d0516  jmp 0x00007EECE83D0490
00007eece83d051b  int3
00007eece83d051c  nop [rax], eax
00007eece83d0520  mov rax, [r15+0xF8]
00007eece83d0527  lea r14, [rax+0x140]
00007eece83d052e  mov r12, [r13+r14*1]
00007eece83d0533  lea r14, [rax+0x148]
00007eece83d053a  mov r11, [r13+r14*1]
00007eece83d053f  mov [r15+0xA0], r12
00007eece83d0546  mov [r15+0x98], r11
00007eece83d054d  lea r14, [rax+0x130]
00007eece83d0554  mov r12, [r13+r14*1]
00007eece83d0559  lea r14, [rax+0x138]
00007eece83d0560  mov r11, [r13+r14*1]
00007eece83d0565  mov [r15+0xB0], r12
00007eece83d056c  mov [r15+0xA8], r11
00007eece83d0573  lea r14, [rax+0x120]
00007eece83d057a  mov r12, [r13+r14*1]
00007eece83d057f  lea r14, [rax+0x128]
00007eece83d0586  mov r11, [r13+r14*1]
00007eece83d058b  mov [r15+0xC0], r12
00007eece83d0592  mov [r15+0xB8], r11
00007eece83d0599  lea r14, [rax+0x110]
00007eece83d05a0  mov r12, [r13+r14*1]
00007eece83d05a5  lea r14, [rax+0x118]
00007eece83d05ac  mov r11, [r13+r14*1]
00007eece83d05b1  mov [r15+0xD0], r12
00007eece83d05b8  mov [r15+0xC8], r11
00007eece83d05bf  lea r14, [rax+0x100]
00007eece83d05c6  mov r12, [r13+r14*1]
00007eece83d05cb  lea r14, [rax+0x108]
00007eece83d05d2  mov r11, [r13+r14*1]
00007eece83d05d7  mov [r15+0xE8], r12
00007eece83d05de  mov [r15+0xD8], r11
00007eece83d05e5  lea r14, [rax+0x150]
00007eece83d05ec  mov [r15+0xF8], r14
00007eece83d05f3  mov rax, [r15+0xF0]
00007eece83d05fa  mov [r15+0x100], rax
00007eece83d0601  jmp 0x00007EECE83CE5C0
00007eece83d0606  int3
00007eece83d0607  call 0x00007EECE82E27E0
00007eece83d060c  jmp 0x00007EECE83D0533
00007eece83d0611  call 0x00007EECE82E1570
00007eece83d0616  jmp 0x00007EECE83D053F
00007eece83d061b  call 0x00007EECE82E27E0
00007eece83d0620  jmp 0x00007EECE83D0559
00007eece83d0625  call 0x00007EECE82E1570
00007eece83d062a  jmp 0x00007EECE83D0565
00007eece83d062f  call 0x00007EECE82E27E0
00007eece83d0634  jmp 0x00007EECE83D057F
00007eece83d0639  call 0x00007EECE82E1570
00007eece83d063e  jmp 0x00007EECE83D058B
00007eece83d0643  call 0x00007EECE82E27E0
00007eece83d0648  jmp 0x00007EECE83D05A5
00007eece83d064d  call 0x00007EECE82E1570
00007eece83d0652  jmp 0x00007EECE83D05B1
00007eece83d0657  call 0x00007EECE82E27E0
00007eece83d065c  jmp 0x00007EECE83D05CB
00007eece83d0661  call 0x00007EECE82E1570
00007eece83d0666  jmp 0x00007EECE83D05D7
00007eece83d066b  int3
00007eece83d066c  nop [rax], eax
00007eece83d0670  mov eax, [r15+0xA0]
00007eece83d0677  mov [rsp+0x10], eax
00007eece83d067b  xor eax, eax
00007eece83d067d  mov r14d, [rsp+0x10]
00007eece83d0682  sub r14d, 0x01
00007eece83d0686  cmc
00007eece83d0687  lahf
00007eece83d0688  seto al
00007eece83d068b  mov [r15+0x108], eax
00007eece83d0692  mov r14d, r14d
00007eece83d0695  mov [r15+0xA0], r14
00007eece83d069c  mov eax, [r15+0x108]
00007eece83d06a3  sahf
00007eece83d06a4  jnz 0x00007EECE83D06D6
00007eece83d06a6  cmp dword ptr [r15+0x318], 0x00
00007eece83d06ae  jz 0x00007EECE83D07A0
00007eece83d06b4  nop [rax+rax*1], ax
00007eece83d06bd  nop [rax+rax*1], eax
00007eece83d06c5  mov eax, 0x41027C
00007eece83d06ca  mov [r15+0x100], rax
00007eece83d06d1  jmp 0x00007EECE81FE110
00007eece83d06d6  cmp dword ptr [r15+0x318], 0x00
00007eece83d06de  jz 0x00007EECE83D0710
00007eece83d06e4  nop [rax+rax*1], ax
00007eece83d06ed  nop [rax+rax*1], eax
00007eece83d06f5  mov eax, 0x410264
00007eece83d06fa  mov [r15+0x100], rax
00007eece83d0701  jmp 0x00007EECE81FE110
00007eece83d0706  int3
00007eece83d0707  int3
00007eece83d0708  nop [rax+rax*1], eax
00007eece83d0710  mov rax, [r15+0xF8]
00007eece83d0717  mov [r15], rax
00007eece83d071a  mov rax, [r15+0x98]
00007eece83d0721  mov [r15+0x08], rax
00007eece83d0725  mov qword ptr [r15+0x10], 0x12C
00007eece83d072d  mov qword ptr [r15+0xF0], 0x410274
00007eece83d0738  mov r14d, [r15+0x320]
00007eece83d073f  mov eax, 0x410274
00007eece83d0744  mov rcx, 0x7EECE83D0670
00007eece83d074e  mov [r15+r14*8+0x328], rax
00007eece83d0756  mov [r15+r14*8+0x368], rcx
00007eece83d075e  add r14d, 0x01
00007eece83d0762  and r14d, 0x07
00007eece83d0766  mov [r15+0x320], r14d
00007eece83d076d  cmp dword ptr [r15+0x318], 0x00
00007eece83d0775  jz 0x00007EECE83CEC20
00007eece83d077b  nop [rax+rax*1], ax
00007eece83d0784  nop [rax+rax*1], eax
00007eece83d078c  mov eax, 0x410338
00007eece83d0791  mov [r15+0x100], rax
00007eece83d0798  jmp 0x00007EECE81FE110
00007eece83d079d  int3
00007eece83d079e  int3
00007eece83d079f  nop
00007eece83d07a0  mov rax, [r15+0xF8]
00007eece83d07a7  lea r14, [rax+0x20]
00007eece83d07ab  mov r12, [r13+r14*1]
00007eece83d07b0  mov [r15+0x98], r12
00007eece83d07b7  mov qword ptr [r15+0x40], 0x80
00007eece83d07bf  mov [r15], rax
00007eece83d07c2  lea r14, [rax+0x8C]
00007eece83d07c9  mov [r15+0x08], r14
00007eece83d07cd  mov qword ptr [r15+0x10], 0x01
00007eece83d07d5  lea r14, [rax+0x8C]
00007eece83d07dc  mov eax, 0x80
00007eece83d07e1  mov [r13+r14*1], al
00007eece83d07e6  mov qword ptr [r15+0xF0], 0x410298
00007eece83d07f1  mov r14d, [r15+0x320]
00007eece83d07f8  mov eax, 0x410298
00007eece83d07fd  mov rcx, 0x7EECE83D0870
00007eece83d0807  mov [r15+r14*8+0x328], rax
00007eece83d080f  mov [r15+r14*8+0x368], rcx
00007eece83d0817  add r14d, 0x01
00007eece83d081b  and r14d, 0x07
00007eece83d081f  mov [r15+0x320], r14d
00007eece83d0826  cmp dword ptr [r15+0x318], 0x00
00007eece83d082e  jz 0x00007EECE83CEC20
00007eece83d0834  nop [rax+rax*1], ax
00007eece83d083d  nop [rax+rax*1], eax
00007eece83d0845  mov eax, 0x410338
00007eece83d084a  mov [r15+0x100], rax
00007eece83d0851  jmp 0x00007EECE81FE110
00007eece83d0856  int3
00007eece83d0857  call 0x00007EECE82E27E0
00007eece83d085c  jmp 0x00007EECE83D07B0
00007eece83d0861  call 0x00007EECE82D5AF0
00007eece83d0866  jmp 0x00007EECE83D07E6
00007eece83d086b  int3
00007eece83d086c  nop [rax], eax
00007eece83d0870  mov rax, [r15+0xF8]
00007eece83d0877  lea r14, [rax+0x68]
00007eece83d087b  mov r12, [r13+r14*1]
00007eece83d0880  mov [r15+0x40], r12
00007eece83d0884  lea r14, [rax+0x88]
00007eece83d088b  xor eax, eax
00007eece83d088d  mov [r13+r14*1], al
00007eece83d0892  xor eax, eax
00007eece83d0894  mov r14d, 0x38
00007eece83d089a  cmp r12, r14
00007eece83d089d  cmc
00007eece83d089e  lahf
00007eece83d089f  seto al
00007eece83d08a2  mov [r15+0x108], eax
00007eece83d08a9  mov eax, [r15+0x108]
00007eece83d08b0  sahf
00007eece83d08b1  jz 0x00007EECE83D08E3
00007eece83d08b3  cmp dword ptr [r15+0x318], 0x00
00007eece83d08bb  jz 0x00007EECE83D0930
00007eece83d08c1  nop [rax+rax*1], ax
00007eece83d08ca  nop [rax+rax*1], eax
00007eece83d08d2  mov eax, 0x4102A8
00007eece83d08d7  mov [r15+0x100], rax
00007eece83d08de  jmp 0x00007EECE81FE110
00007eece83d08e3  cmp dword ptr [r15+0x318], 0x00
00007eece83d08eb  jz 0x00007EECE83D0A70
00007eece83d08f1  nop [rax+rax*1], ax
00007eece83d08fa  nop [rax+rax*1], eax
00007eece83d0902  mov eax, 0x4102C4
00007eece83d0907  mov [r15+0x100], rax
00007eece83d090e  jmp 0x00007EECE81FE110
00007eece83d0913  int3
00007eece83d0914  call 0x00007EECE82E27E0
00007eece83d0919  jmp 0x00007EECE83D0880
00007eece83d091e  call 0x00007EECE82D5AF0
00007eece83d0923  jmp 0x00007EECE83D0892
00007eece83d0928  int3
00007eece83d0929  nop [rax], eax
00007eece83d0930  mov rax, [r15+0xF8]
00007eece83d0937  mov [r15], rax
00007eece83d093a  lea r14, [rax+0x88]
00007eece83d0941  mov [r15+0x08], r14
00007eece83d0945  mov qword ptr [r15+0x10], 0x01
00007eece83d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007eece83d0958  mov r14d, [r15+0x320]
00007eece83d095f  mov eax, 0x4102B8
00007eece83d0964  mov rcx, 0x7EECE83D09C0
00007eece83d096e  mov [r15+r14*8+0x328], rax
00007eece83d0976  mov [r15+r14*8+0x368], rcx
00007eece83d097e  add r14d, 0x01
00007eece83d0982  and r14d, 0x07
00007eece83d0986  mov [r15+0x320], r14d
00007eece83d098d  cmp dword ptr [r15+0x318], 0x00
00007eece83d0995  jz 0x00007EECE83CEC20
00007eece83d099b  nop [rax+rax*1], ax
00007eece83d09a4  nop [rax+rax*1], eax
00007eece83d09ac  mov eax, 0x410338
00007eece83d09b1  mov [r15+0x100], rax
00007eece83d09b8  jmp 0x00007EECE81FE110
00007eece83d09bd  int3
00007eece83d09be  int3
00007eece83d09bf  nop
00007eece83d09c0  mov rax, [r15+0xF8]
00007eece83d09c7  lea r14, [rax+0x68]
00007eece83d09cb  mov rax, [r13+r14*1]
00007eece83d09d0  mov [r15+0x40], rax
00007eece83d09d4  mov [rsp+0x10], rax
00007eece83d09d9  xor eax, eax
00007eece83d09db  mov r14, [rsp+0x10]
00007eece83d09e0  mov r12d, 0x38
00007eece83d09e6  cmp r14, r12
00007eece83d09e9  cmc
00007eece83d09ea  lahf
00007eece83d09eb  seto al
00007eece83d09ee  mov [r15+0x108], eax
00007eece83d09f5  mov eax, [r15+0x108]
00007eece83d09fc  sahf
00007eece83d09fd  jnz 0x00007EECE83D0A2F
00007eece83d09ff  cmp dword ptr [r15+0x318], 0x00
00007eece83d0a07  jz 0x00007EECE83D0A70
00007eece83d0a0d  nop [rax+rax*1], ax
00007eece83d0a16  nop [rax+rax*1], eax
00007eece83d0a1e  mov eax, 0x4102C4
00007eece83d0a23  mov [r15+0x100], rax
00007eece83d0a2a  jmp 0x00007EECE81FE110
00007eece83d0a2f  cmp dword ptr [r15+0x318], 0x00
00007eece83d0a37  jz 0x00007EECE83D0930
00007eece83d0a3d  nop [rax+rax*1], ax
00007eece83d0a46  nop [rax+rax*1], eax
00007eece83d0a4e  mov eax, 0x4102A8
00007eece83d0a53  mov [r15+0x100], rax
00007eece83d0a5a  jmp 0x00007EECE81FE110
00007eece83d0a5f  int3
00007eece83d0a60  call 0x00007EECE82D59C0
00007eece83d0a65  jmp 0x00007EECE83D09D0
00007eece83d0a6a  int3
00007eece83d0a6b  nop [rax+rax*1], eax
00007eece83d0a70  mov rax, [r15+0x98]
00007eece83d0a77  rorx r14, rax, 0x3D
00007eece83d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007eece83d0a81  mov rax, [r15+0xF8]
00007eece83d0a88  mov [r15], rax
00007eece83d0a8b  lea r12, [rax+0x78]
00007eece83d0a8f  mov [r15+0x08], r12
00007eece83d0a93  mov qword ptr [r15+0x10], 0x08
00007eece83d0a9b  bswap r14
00007eece83d0a9e  mov [r15+0x40], r14
00007eece83d0aa2  lea r12, [rax+0x78]
00007eece83d0aa6  mov [r13+r12*1], r14
00007eece83d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007eece83d0ab6  mov r14d, [r15+0x320]
00007eece83d0abd  mov eax, 0x4102E0
00007eece83d0ac2  mov rcx, 0x7EECE83D0B30
00007eece83d0acc  mov [r15+r14*8+0x328], rax
00007eece83d0ad4  mov [r15+r14*8+0x368], rcx
00007eece83d0adc  add r14d, 0x01
00007eece83d0ae0  and r14d, 0x07
00007eece83d0ae4  mov [r15+0x320], r14d
00007eece83d0aeb  cmp dword ptr [r15+0x318], 0x00
00007eece83d0af3  jz 0x00007EECE83CEC20
00007eece83d0af9  nop [rax+rax*1], ax
00007eece83d0b02  nop [rax+rax*1], eax
00007eece83d0b0a  mov eax, 0x410338
00007eece83d0b0f  mov [r15+0x100], rax
00007eece83d0b16  jmp 0x00007EECE81FE110
00007eece83d0b1b  int3
00007eece83d0b1c  call 0x00007EECE82C3FE0
00007eece83d0b21  jmp 0x00007EECE83D0AAB
00007eece83d0b26  int3
00007eece83d0b27  nop [rax+rax*1], ax
00007eece83d0b30  mov rax, [r15+0xF8]
00007eece83d0b37  mov r14d, [r13+rax*1]
00007eece83d0b3c  lea r12, [rax+0x04]
00007eece83d0b40  mov r11d, [r13+r12*1]
00007eece83d0b45  lea r12, [rax+0x08]
00007eece83d0b49  mov r10d, [r13+r12*1]
00007eece83d0b4e  lea r12, [rax+0x0C]
00007eece83d0b52  mov r9d, [r13+r12*1]
00007eece83d0b57  mov qword ptr [r15+0x48], 0x430860
00007eece83d0b5f  lea r12, [rax+0x80]
00007eece83d0b66  mov r8, [r13+r12*1]
00007eece83d0b6b  mov [r15+0xF0], r8
00007eece83d0b72  bswap r14d
00007eece83d0b75  bswap r11d
00007eece83d0b78  mov r12d, 0x430860
00007eece83d0b7e  mov [r13+r12*1], r14d
00007eece83d0b83  mov r14d, 0x430864
00007eece83d0b89  mov [r13+r14*1], r11d
00007eece83d0b8e  bswap r10d
00007eece83d0b91  bswap r9d
00007eece83d0b94  lea r14, [rax+0x10]
00007eece83d0b98  mov r12d, [r13+r14*1]
00007eece83d0b9d  lea r14, [rax+0x14]
00007eece83d0ba1  mov r11d, [r13+r14*1]
00007eece83d0ba6  mov r14d, 0x430868
00007eece83d0bac  mov [r13+r14*1], r10d
00007eece83d0bb1  mov r14d, 0x43086C
00007eece83d0bb7  mov [r13+r14*1], r9d
00007eece83d0bbc  lea r14, [rax+0x90]
00007eece83d0bc3  mov r10, [r13+r14*1]
00007eece83d0bc8  lea r14, [rax+0x98]
00007eece83d0bcf  mov r9, [r13+r14*1]
00007eece83d0bd4  mov [r15+0xA0], r10
00007eece83d0bdb  mov [r15+0x98], r9
00007eece83d0be2  bswap r12d
00007eece83d0be5  bswap r11d
00007eece83d0be8  mov [rsp+0x10], r11d
00007eece83d0bed  mov r11d, r11d
00007eece83d0bf0  mov [r15+0x58], r11
00007eece83d0bf4  lea r14, [rax+0x18]
00007eece83d0bf8  mov r11d, [r13+r14*1]
00007eece83d0bfd  lea r14, [rax+0x1C]
00007eece83d0c01  mov r10d, [r13+r14*1]
00007eece83d0c06  mov [rsp+0x20], r10d
00007eece83d0c0b  mov r10d, r10d
00007eece83d0c0e  mov [r15+0x60], r10
00007eece83d0c12  mov r14d, 0x430870
00007eece83d0c18  mov [r13+r14*1], r12d
00007eece83d0c1d  mov r14d, 0x430874
00007eece83d0c23  mov r12d, [rsp+0x10]
00007eece83d0c28  mov [r13+r14*1], r12d
00007eece83d0c2d  bswap r11d
00007eece83d0c30  mov [rsp+0x10], r11d
00007eece83d0c35  mov r11d, r11d
00007eece83d0c38  mov [r15+0x40], r11
00007eece83d0c3c  mov r14d, [rsp+0x20]
00007eece83d0c41  bswap r14d
00007eece83d0c44  mov [rsp+0x20], r14d
00007eece83d0c49  mov r14d, r14d
00007eece83d0c4c  mov [r15+0x50], r14
00007eece83d0c50  mov r14d, 0x430878
00007eece83d0c56  mov r12d, [rsp+0x10]
00007eece83d0c5b  mov [r13+r14*1], r12d
00007eece83d0c60  mov r14d, 0x43087C
00007eece83d0c66  mov r12d, [rsp+0x20]
00007eece83d0c6b  mov [r13+r14*1], r12d
00007eece83d0c70  lea r14, [rax+0xA0]
00007eece83d0c77  mov [r15+0xF8], r14
00007eece83d0c7e  mov [r15+0x100], r8
00007eece83d0c85  jmp 0x00007EECE83CE5C0
00007eece83d0c8a  int3
00007eece83d0c8b  call 0x00007EECE820DAE0
00007eece83d0c90  jmp 0x00007EECE83D0B3C
00007eece83d0c95  call 0x00007EECE82C0230
00007eece83d0c9a  jmp 0x00007EECE83D0B45
00007eece83d0c9f  call 0x00007EECE82BEFC0
00007eece83d0ca4  jmp 0x00007EECE83D0B4E
00007eece83d0ca9  call 0x00007EECE82BDD50
00007eece83d0cae  jmp 0x00007EECE83D0B57
00007eece83d0cb3  call 0x00007EECE82BCC20
00007eece83d0cb8  jmp 0x00007EECE83D0B6B
00007eece83d0cbd  call 0x00007EECE82C3EA0
00007eece83d0cc2  jmp 0x00007EECE83D0B83
00007eece83d0cc7  call 0x00007EECE82E1920
00007eece83d0ccc  jmp 0x00007EECE83D0B8E
00007eece83d0cd1  call 0x00007EECE82E26A0
00007eece83d0cd6  jmp 0x00007EECE83D0B9D
00007eece83d0cdb  call 0x00007EECE82E1430
00007eece83d0ce0  jmp 0x00007EECE83D0BA6
00007eece83d0ce5  call 0x00007EECE82E06B0
00007eece83d0cea  jmp 0x00007EECE83D0BB1
00007eece83d0cef  call 0x00007EECE82DF440
00007eece83d0cf4  jmp 0x00007EECE83D0BBC
00007eece83d0cf9  call 0x00007EECE82E0300
00007eece83d0cfe  jmp 0x00007EECE83D0BC8
00007eece83d0d03  call 0x00007EECE82DF090
00007eece83d0d08  jmp 0x00007EECE83D0BD4
00007eece83d0d0d  call 0x00007EECE82E1430
00007eece83d0d12  jmp 0x00007EECE83D0BFD
00007eece83d0d17  call 0x00007EECE82E01C0
00007eece83d0d1c  jmp 0x00007EECE83D0C06
00007eece83d0d21  call 0x00007EECE82E2BA0
00007eece83d0d26  jmp 0x00007EECE83D0C1D
00007eece83d0d2b  call 0x00007EECE82E2BA0
00007eece83d0d30  jmp 0x00007EECE83D0C2D
00007eece83d0d35  call 0x00007EECE82E2BA0
00007eece83d0d3a  jmp 0x00007EECE83D0C60
00007eece83d0d3f  call 0x00007EECE82E2BA0
00007eece83d0d44  jmp 0x00007EECE83D0C70
00007eece83d0d49  int3
00007eece83d0d4a  nop [rax+rax*1], ax
00007eece83d0d50  mov qword ptr [r15+0x100], 0x04
00007eece83d0d5b  mov esi, 0x00
00007eece83d0d60  mov edx, 0x09
00007eece83d0d65  mov rdi, 0x7FFCF7755480
00007eece83d0d6f  mov rax, 0x61EB03F7B970
00007eece83d0d79  call rax
00007eece83d0d7b  cmp dword ptr [r15+0x318], 0x00
00007eece83d0d83  jnz 0x00007EECE81FE110
00007eece83d0d89  jmp 0x00007EECE81FE0A0
00007eece83d0d8e  int3
00007eece83d0d8f  int3
