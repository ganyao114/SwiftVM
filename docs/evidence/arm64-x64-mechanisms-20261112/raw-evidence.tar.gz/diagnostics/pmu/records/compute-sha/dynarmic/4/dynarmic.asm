000070c3ec3ce69b  nop [rax+rax*1], eax
000070c3ec3ce6a0  mov rax, [r15+0xF8]
000070c3ec3ce6a7  lea r14, [rax-0xA0]
000070c3ec3ce6ae  mov [r15+0xF8], r14
000070c3ec3ce6b5  lea rax, [r14+0x90]
000070c3ec3ce6bc  mov r12, [r15+0xA0]
000070c3ec3ce6c3  mov r11, [r15+0x98]
000070c3ec3ce6ca  mov [r13+rax*1], r12
000070c3ec3ce6cf  lea rax, [r14+0x98]
000070c3ec3ce6d6  mov [r13+rax*1], r11
000070c3ec3ce6db  mov eax, 0x420670
000070c3ec3ce6e0  movups xmm1, [r13+rax*1]
000070c3ec3ce6e6  mov eax, 0x420610
000070c3ec3ce6eb  movups xmm15, [r13+rax*1]
000070c3ec3ce6f1  mov eax, 0x420690
000070c3ec3ce6f6  movups xmm14, [r13+rax*1]
000070c3ec3ce6fc  mov eax, 0x420630
000070c3ec3ce701  movups xmm13, [r13+rax*1]
000070c3ec3ce707  mov qword ptr [r15+0x98], 0x4308A0
000070c3ec3ce712  mov eax, 0x4206A0
000070c3ec3ce717  movups xmm12, [r13+rax*1]
000070c3ec3ce71d  mov eax, 0x4308A0
000070c3ec3ce722  movups [r13+rax*1], xmm1
000070c3ec3ce728  mov eax, 0x4308B0
000070c3ec3ce72d  movups [r13+rax*1], xmm15
000070c3ec3ce733  mov eax, 0x4308C0
000070c3ec3ce738  movups [r13+rax*1], xmm14
000070c3ec3ce73e  mov eax, 0x4308D0
000070c3ec3ce743  movups [r13+rax*1], xmm13
000070c3ec3ce749  mov eax, 0x420600
000070c3ec3ce74e  movups xmm14, [r13+rax*1]
000070c3ec3ce754  mov eax, 0x4205F0
000070c3ec3ce759  movups xmm13, [r13+rax*1]
000070c3ec3ce75f  mov eax, 0x4309A0
000070c3ec3ce764  movups [r13+rax*1], xmm1
000070c3ec3ce76a  mov eax, 0x4309B0
000070c3ec3ce76f  movups [r13+rax*1], xmm15
000070c3ec3ce775  mov eax, 0x4308E0
000070c3ec3ce77a  movups [r13+rax*1], xmm12
000070c3ec3ce780  mov eax, 0x4308F0
000070c3ec3ce785  movups [r13+rax*1], xmm14
000070c3ec3ce78b  mov eax, 0x4205E0
000070c3ec3ce790  movups xmm1, [r13+rax*1]
000070c3ec3ce796  mov eax, 0x420640
000070c3ec3ce79b  movups xmm15, [r13+rax*1]
000070c3ec3ce7a1  mov eax, 0x430900
000070c3ec3ce7a6  movups [r13+rax*1], xmm13
000070c3ec3ce7ac  mov eax, 0x430910
000070c3ec3ce7b1  movups [r13+rax*1], xmm1
000070c3ec3ce7b7  mov eax, 0x420650
000070c3ec3ce7bc  movups xmm1, [r13+rax*1]
000070c3ec3ce7c2  mov eax, 0x420620
000070c3ec3ce7c7  movups xmm14, [r13+rax*1]
000070c3ec3ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000070c3ec3ce7d5  mov eax, 0x430920
000070c3ec3ce7da  movups [r13+rax*1], xmm15
000070c3ec3ce7e0  mov eax, 0x430930
000070c3ec3ce7e5  movups [r13+rax*1], xmm1
000070c3ec3ce7eb  mov eax, 0x4206C0
000070c3ec3ce7f0  movups xmm1, [r13+rax*1]
000070c3ec3ce7f6  mov eax, 0x4206D0
000070c3ec3ce7fb  movups xmm15, [r13+rax*1]
000070c3ec3ce801  movaps [r15+0x150], xmm15
000070c3ec3ce809  mov qword ptr [r15+0xA0], 0x3E8
000070c3ec3ce814  mov eax, 0x430940
000070c3ec3ce819  movups [r13+rax*1], xmm14
000070c3ec3ce81f  mov eax, 0x430950
000070c3ec3ce824  movups [r13+rax*1], xmm1
000070c3ec3ce82a  mov eax, 0x4206B0
000070c3ec3ce82f  movups xmm1, [r13+rax*1]
000070c3ec3ce835  mov eax, 0x420660
000070c3ec3ce83a  movups xmm14, [r13+rax*1]
000070c3ec3ce840  movaps [r15+0x140], xmm14
000070c3ec3ce848  lea rax, [r14+0x80]
000070c3ec3ce84f  mov r12, [r15+0xF0]
000070c3ec3ce856  mov [r13+rax*1], r12
000070c3ec3ce85b  mov eax, 0x430960
000070c3ec3ce860  movups [r13+rax*1], xmm15
000070c3ec3ce866  mov eax, 0x430970
000070c3ec3ce86b  movups [r13+rax*1], xmm1
000070c3ec3ce871  mov eax, 0x420680
000070c3ec3ce876  movups xmm1, [r13+rax*1]
000070c3ec3ce87c  mov eax, 0x4206E0
000070c3ec3ce881  mov r12, [r13+rax*1]
000070c3ec3ce886  movq xmm15, r12
000070c3ec3ce88b  mov qword ptr [r15+0x40], 0x4206E8
000070c3ec3ce893  mov eax, 0x430980
000070c3ec3ce898  movups [r13+rax*1], xmm14
000070c3ec3ce89e  mov eax, 0x430990
000070c3ec3ce8a3  movups [r13+rax*1], xmm1
000070c3ec3ce8a9  mov eax, 0x420748
000070c3ec3ce8ae  movups xmm1, [r13+rax*1]
000070c3ec3ce8b4  movq rax, xmm15
000070c3ec3ce8b9  mov r12d, 0x4309C0
000070c3ec3ce8bf  mov [r13+r12*1], rax
000070c3ec3ce8c4  mov eax, 0x420728
000070c3ec3ce8c9  movups xmm15, [r13+rax*1]
000070c3ec3ce8cf  mov eax, 0x420738
000070c3ec3ce8d4  movups xmm14, [r13+rax*1]
000070c3ec3ce8da  lea rax, [r14+0x60]
000070c3ec3ce8de  movups [r13+rax*1], xmm1
000070c3ec3ce8e4  mov eax, 0x4309C8
000070c3ec3ce8e9  mov r12d, 0x421DF8D3
000070c3ec3ce8ef  mov [r13+rax*1], r12d
000070c3ec3ce8f4  lea rax, [r14+0x40]
000070c3ec3ce8f8  movups [r13+rax*1], xmm15
000070c3ec3ce8fe  lea rax, [r14+0x50]
000070c3ec3ce902  movups [r13+rax*1], xmm14
000070c3ec3ce908  mov eax, 0x4206E8
000070c3ec3ce90d  movups xmm1, [r13+rax*1]
000070c3ec3ce913  mov eax, 0x4206F8
000070c3ec3ce918  movups xmm15, [r13+rax*1]
000070c3ec3ce91e  movaps [r15+0x120], xmm15
000070c3ec3ce926  movups [r13+r14*1], xmm1
000070c3ec3ce92c  lea rax, [r14+0x10]
000070c3ec3ce930  movups [r13+rax*1], xmm15
000070c3ec3ce936  mov eax, 0x420708
000070c3ec3ce93b  movups xmm1, [r13+rax*1]
000070c3ec3ce941  mov eax, 0x420718
000070c3ec3ce946  movups xmm15, [r13+rax*1]
000070c3ec3ce94c  movaps [r15+0x110], xmm1
000070c3ec3ce954  movaps [r15+0x130], xmm15
000070c3ec3ce95c  lea rax, [r14+0x20]
000070c3ec3ce960  movups [r13+rax*1], xmm1
000070c3ec3ce966  lea rax, [r14+0x30]
000070c3ec3ce96a  movups [r13+rax*1], xmm15
000070c3ec3ce970  mov [r15], r14
000070c3ec3ce973  mov qword ptr [r15+0x08], 0x4308A0
000070c3ec3ce97b  mov qword ptr [r15+0x10], 0x12C
000070c3ec3ce983  mov qword ptr [r15+0xF0], 0x410274
000070c3ec3ce98e  mov r14d, [r15+0x320]
000070c3ec3ce995  mov eax, 0x410274
000070c3ec3ce99a  mov rcx, 0x70C3EC3D0670
000070c3ec3ce9a4  mov [r15+r14*8+0x328], rax
000070c3ec3ce9ac  mov [r15+r14*8+0x368], rcx
000070c3ec3ce9b4  add r14d, 0x01
000070c3ec3ce9b8  and r14d, 0x07
000070c3ec3ce9bc  mov [r15+0x320], r14d
000070c3ec3ce9c3  cmp dword ptr [r15+0x318], 0x00
000070c3ec3ce9cb  jz 0x000070C3EC3CEC20
000070c3ec3ce9d1  nop [rax+rax*1], ax
000070c3ec3ce9da  nop [rax+rax*1], eax
000070c3ec3ce9e2  mov eax, 0x410338
000070c3ec3ce9e7  mov [r15+0x100], rax
000070c3ec3ce9ee  jmp 0x000070C3EC1FE110
000070c3ec3ce9f3  int3
000070c3ec3ce9f4  call 0x000070C3EC20BC20
000070c3ec3ce9f9  jmp 0x000070C3EC3CE6CF
000070c3ec3ce9fe  call 0x000070C3EC20A9A0
000070c3ec3cea03  jmp 0x000070C3EC3CE6DB
000070c3ec3cea08  call 0x000070C3EC1FF430
000070c3ec3cea0d  jmp 0x000070C3EC3CE6E6
000070c3ec3cea12  call 0x000070C3EC20E760
000070c3ec3cea17  jmp 0x000070C3EC3CE6F1
000070c3ec3cea1c  call 0x000070C3EC20D4E0
000070c3ec3cea21  jmp 0x000070C3EC3CE6FC
000070c3ec3cea26  call 0x000070C3EC20C260
000070c3ec3cea2b  jmp 0x000070C3EC3CE707
000070c3ec3cea30  call 0x000070C3EC20AFE0
000070c3ec3cea35  jmp 0x000070C3EC3CE71D
000070c3ec3cea3a  call 0x000070C3EC1FF540
000070c3ec3cea3f  jmp 0x000070C3EC3CE728
000070c3ec3cea44  call 0x000070C3EC20E880
000070c3ec3cea49  jmp 0x000070C3EC3CE733
000070c3ec3cea4e  call 0x000070C3EC20D600
000070c3ec3cea53  jmp 0x000070C3EC3CE73E
000070c3ec3cea58  call 0x000070C3EC20C380
000070c3ec3cea5d  jmp 0x000070C3EC3CE749
000070c3ec3cea62  call 0x000070C3EC20D4E0
000070c3ec3cea67  jmp 0x000070C3EC3CE754
000070c3ec3cea6c  call 0x000070C3EC20C260
000070c3ec3cea71  jmp 0x000070C3EC3CE75F
000070c3ec3cea76  call 0x000070C3EC1FF540
000070c3ec3cea7b  jmp 0x000070C3EC3CE76A
000070c3ec3cea80  call 0x000070C3EC20E880
000070c3ec3cea85  jmp 0x000070C3EC3CE775
000070c3ec3cea8a  call 0x000070C3EC20B100
000070c3ec3cea8f  jmp 0x000070C3EC3CE780
000070c3ec3cea94  call 0x000070C3EC20D600
000070c3ec3cea99  jmp 0x000070C3EC3CE78B
000070c3ec3cea9e  call 0x000070C3EC1FF430
000070c3ec3ceaa3  jmp 0x000070C3EC3CE796
000070c3ec3ceaa8  call 0x000070C3EC20E760
000070c3ec3ceaad  jmp 0x000070C3EC3CE7A1
000070c3ec3ceab2  call 0x000070C3EC20C380
000070c3ec3ceab7  jmp 0x000070C3EC3CE7AC
000070c3ec3ceabc  call 0x000070C3EC1FF540
000070c3ec3ceac1  jmp 0x000070C3EC3CE7B7
000070c3ec3ceac6  call 0x000070C3EC1FF430
000070c3ec3ceacb  jmp 0x000070C3EC3CE7C2
000070c3ec3cead0  call 0x000070C3EC20D4E0
000070c3ec3cead5  jmp 0x000070C3EC3CE7CD
000070c3ec3ceada  call 0x000070C3EC20E880
000070c3ec3ceadf  jmp 0x000070C3EC3CE7E0
000070c3ec3ceae4  call 0x000070C3EC1FF540
000070c3ec3ceae9  jmp 0x000070C3EC3CE7EB
000070c3ec3ceaee  call 0x000070C3EC1FF430
000070c3ec3ceaf3  jmp 0x000070C3EC3CE7F6
000070c3ec3ceaf8  call 0x000070C3EC20E760
000070c3ec3ceafd  jmp 0x000070C3EC3CE801
000070c3ec3ceb02  call 0x000070C3EC20D600
000070c3ec3ceb07  jmp 0x000070C3EC3CE81F
000070c3ec3ceb0c  call 0x000070C3EC1FF540
000070c3ec3ceb11  jmp 0x000070C3EC3CE82A
000070c3ec3ceb16  call 0x000070C3EC1FF430
000070c3ec3ceb1b  jmp 0x000070C3EC3CE835
000070c3ec3ceb20  call 0x000070C3EC20D4E0
000070c3ec3ceb25  jmp 0x000070C3EC3CE840
000070c3ec3ceb2a  call 0x000070C3EC20BC20
000070c3ec3ceb2f  jmp 0x000070C3EC3CE85B
000070c3ec3ceb34  call 0x000070C3EC20E880
000070c3ec3ceb39  jmp 0x000070C3EC3CE866
000070c3ec3ceb3e  call 0x000070C3EC1FF540
000070c3ec3ceb43  jmp 0x000070C3EC3CE871
000070c3ec3ceb48  call 0x000070C3EC1FF430
000070c3ec3ceb4d  jmp 0x000070C3EC3CE87C
000070c3ec3ceb52  call 0x000070C3EC20B720
000070c3ec3ceb57  jmp 0x000070C3EC3CE886
000070c3ec3ceb5c  call 0x000070C3EC20D600
000070c3ec3ceb61  jmp 0x000070C3EC3CE89E
000070c3ec3ceb66  call 0x000070C3EC1FF540
000070c3ec3ceb6b  jmp 0x000070C3EC3CE8A9
000070c3ec3ceb70  call 0x000070C3EC1FF430
000070c3ec3ceb75  jmp 0x000070C3EC3CE8B4
000070c3ec3ceb7a  call 0x000070C3EC2B4CB0
000070c3ec3ceb7f  jmp 0x000070C3EC3CE8C4
000070c3ec3ceb84  call 0x000070C3EC20E760
000070c3ec3ceb89  jmp 0x000070C3EC3CE8CF
000070c3ec3ceb8e  call 0x000070C3EC20D4E0
000070c3ec3ceb93  jmp 0x000070C3EC3CE8DA
000070c3ec3ceb98  call 0x000070C3EC1FF540
000070c3ec3ceb9d  jmp 0x000070C3EC3CE8E4
000070c3ec3ceba2  call 0x000070C3EC20BAE0
000070c3ec3ceba7  jmp 0x000070C3EC3CE8F4
000070c3ec3cebac  call 0x000070C3EC20E880
000070c3ec3cebb1  jmp 0x000070C3EC3CE8FE
000070c3ec3cebb6  call 0x000070C3EC20D600
000070c3ec3cebbb  jmp 0x000070C3EC3CE908
000070c3ec3cebc0  call 0x000070C3EC1FF430
000070c3ec3cebc5  jmp 0x000070C3EC3CE913
000070c3ec3cebca  call 0x000070C3EC20E760
000070c3ec3cebcf  jmp 0x000070C3EC3CE91E
000070c3ec3cebd4  call 0x000070C3EC2D6600
000070c3ec3cebd9  jmp 0x000070C3EC3CE92C
000070c3ec3cebde  call 0x000070C3EC20E880
000070c3ec3cebe3  jmp 0x000070C3EC3CE936
000070c3ec3cebe8  call 0x000070C3EC1FF430
000070c3ec3cebed  jmp 0x000070C3EC3CE941
000070c3ec3cebf2  call 0x000070C3EC20E760
000070c3ec3cebf7  jmp 0x000070C3EC3CE94C
000070c3ec3cebfc  call 0x000070C3EC1FF540
000070c3ec3cec01  jmp 0x000070C3EC3CE966
000070c3ec3cec06  call 0x000070C3EC20E880
000070c3ec3cec0b  jmp 0x000070C3EC3CE970
000070c3ec3cec10  int3
000070c3ec3cec11  nop [rax+rax*1], ax
000070c3ec3cec1a  nop [rax+rax*1], ax
000070c3ec3cec20  mov rax, [r15]
000070c3ec3cec23  lea r14, [rax+0x20]
000070c3ec3cec27  mov r12, [r13+r14*1]
000070c3ec3cec2c  mov r14, [r15+0x10]
000070c3ec3cec30  lea r11, [r12+r14*1]
000070c3ec3cec34  mov [r15+0x40], r11
000070c3ec3cec38  lea r12, [rax+0x20]
000070c3ec3cec3c  mov [r13+r12*1], r11
000070c3ec3cec41  test r14, r14
000070c3ec3cec44  setz r14b
000070c3ec3cec48  movzx r14, r14b
000070c3ec3cec4c  mov [rsp+0x414], r14b
000070c3ec3cec54  cmp byte ptr [rsp+0x414], 0x00
000070c3ec3cec5c  jz 0x000070C3EC3CEC8E
000070c3ec3cec5e  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cec66  mov eax, 0x4105B0
000070c3ec3cec6b  mov [r15+0x100], rax
000070c3ec3cec72  jz 0x000070C3EC1FE0A0
000070c3ec3cec78  nop [rax+rax*1], eax
000070c3ec3cec7d  mov eax, 0x4105B0
000070c3ec3cec82  mov [r15+0x100], rax
000070c3ec3cec89  jmp 0x000070C3EC1FE110
000070c3ec3cec8e  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cec96  jz 0x000070C3EC3CECE0
000070c3ec3cec9c  nop [rax+rax*1], ax
000070c3ec3ceca5  nop [rax+rax*1], eax
000070c3ec3cecad  mov eax, 0x410348
000070c3ec3cecb2  mov [r15+0x100], rax
000070c3ec3cecb9  jmp 0x000070C3EC1FE110
000070c3ec3cecbe  int3
000070c3ec3cecbf  call 0x000070C3EC2E27E0
000070c3ec3cecc4  jmp 0x000070C3EC3CEC2C
000070c3ec3cecc9  call 0x000070C3EC2C0860
000070c3ec3cecce  jmp 0x000070C3EC3CEC41
000070c3ec3cecd3  int3
000070c3ec3cecd4  nop [rax+rax*1], ax
000070c3ec3cecdd  nop [rax], eax
000070c3ec3cece0  mov rax, [r15+0xF8]
000070c3ec3cece7  lea r14, [rax-0x150]
000070c3ec3cecee  mov [r15+0xF8], r14
000070c3ec3cecf5  mov rax, [r15]
000070c3ec3cecf8  lea r12, [rax+0x68]
000070c3ec3cecfc  mov r11, [r13+r12*1]
000070c3ec3ced01  mov [r15+0x88], r11
000070c3ec3ced08  lea r12, [rax+0x28]
000070c3ec3ced0c  mov [r15+0x40], r12
000070c3ec3ced10  mov [r15+0x48], r14
000070c3ec3ced14  mov qword ptr [r15+0x50], 0x420758
000070c3ec3ced1c  lea rax, [r14+0x100]
000070c3ec3ced23  mov r12, [r15+0xE8]
000070c3ec3ced2a  mov r11, [r15+0xD8]
000070c3ec3ced31  mov [r13+rax*1], r12
000070c3ec3ced36  lea rax, [r14+0x108]
000070c3ec3ced3d  mov [r13+rax*1], r11
000070c3ec3ced42  lea rax, [r14+0x110]
000070c3ec3ced49  mov r12, [r15+0xD0]
000070c3ec3ced50  mov r11, [r15+0xC8]
000070c3ec3ced57  mov [r13+rax*1], r12
000070c3ec3ced5c  lea rax, [r14+0x118]
000070c3ec3ced63  mov [r13+rax*1], r11
000070c3ec3ced68  lea rax, [r14+0x120]
000070c3ec3ced6f  mov r12, [r15+0xC0]
000070c3ec3ced76  mov r11, [r15+0xB8]
000070c3ec3ced7d  mov [r13+rax*1], r12
000070c3ec3ced82  lea rax, [r14+0x128]
000070c3ec3ced89  mov [r13+rax*1], r11
000070c3ec3ced8e  lea rax, [r14+0x130]
000070c3ec3ced95  mov r12, [r15+0xB0]
000070c3ec3ced9c  mov r11, [r15+0xA8]
000070c3ec3ceda3  mov [r13+rax*1], r12
000070c3ec3ceda8  lea rax, [r14+0x138]
000070c3ec3cedaf  mov [r13+rax*1], r11
000070c3ec3cedb4  lea rax, [r14+0x140]
000070c3ec3cedbb  mov r12, [r15+0xA0]
000070c3ec3cedc2  mov r11, [r15+0x98]
000070c3ec3cedc9  mov [r13+rax*1], r12
000070c3ec3cedce  lea rax, [r14+0x148]
000070c3ec3cedd5  mov [r13+rax*1], r11
000070c3ec3cedda  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cede2  jz 0x000070C3EC3CEE80
000070c3ec3cede8  nop [rax+rax*1], ax
000070c3ec3cedf1  nop [rax+rax*1], eax
000070c3ec3cedf9  mov eax, 0x410380
000070c3ec3cedfe  mov [r15+0x100], rax
000070c3ec3cee05  jmp 0x000070C3EC1FE110
000070c3ec3cee0a  int3
000070c3ec3cee0b  call 0x000070C3EC2C0370
000070c3ec3cee10  jmp 0x000070C3EC3CED01
000070c3ec3cee15  call 0x000070C3EC20BC20
000070c3ec3cee1a  jmp 0x000070C3EC3CED36
000070c3ec3cee1f  call 0x000070C3EC20A9A0
000070c3ec3cee24  jmp 0x000070C3EC3CED42
000070c3ec3cee29  call 0x000070C3EC20BC20
000070c3ec3cee2e  jmp 0x000070C3EC3CED5C
000070c3ec3cee33  call 0x000070C3EC20A9A0
000070c3ec3cee38  jmp 0x000070C3EC3CED68
000070c3ec3cee3d  call 0x000070C3EC20BC20
000070c3ec3cee42  jmp 0x000070C3EC3CED82
000070c3ec3cee47  call 0x000070C3EC20A9A0
000070c3ec3cee4c  jmp 0x000070C3EC3CED8E
000070c3ec3cee51  call 0x000070C3EC20BC20
000070c3ec3cee56  jmp 0x000070C3EC3CEDA8
000070c3ec3cee5b  call 0x000070C3EC20A9A0
000070c3ec3cee60  jmp 0x000070C3EC3CEDB4
000070c3ec3cee65  call 0x000070C3EC20BC20
000070c3ec3cee6a  jmp 0x000070C3EC3CEDCE
000070c3ec3cee6f  call 0x000070C3EC20A9A0
000070c3ec3cee74  jmp 0x000070C3EC3CEDDA
000070c3ec3cee79  int3
000070c3ec3cee7a  nop [rax+rax*1], ax
000070c3ec3cee80  mov rax, [r15+0x08]
000070c3ec3cee84  movzx r14d, byte ptr [r13+rax*1]
000070c3ec3cee8a  movzx r14d, r14b
000070c3ec3cee8e  mov [rsp+0x10], r14d
000070c3ec3cee93  mov r14d, r14d
000070c3ec3cee96  mov [r15+0x58], r14
000070c3ec3cee9a  lea r14, [rax+0x01]
000070c3ec3cee9e  mov [r15+0x08], r14
000070c3ec3ceea2  mov rax, [r15+0x88]
000070c3ec3ceea9  lea r14, [rax+0x01]
000070c3ec3ceead  mov r12, [r15]
000070c3ec3ceeb0  lea r11, [r12+0x68]
000070c3ec3ceeb5  mov [r13+r11*1], r14
000070c3ec3ceeba  lea r14, [r12+rax*1]
000070c3ec3ceebe  mov [r15+0x60], r14
000070c3ec3ceec2  lea rax, [r14+0x28]
000070c3ec3ceec6  mov r11d, [rsp+0x10]
000070c3ec3ceecb  movzx r14d, r11b
000070c3ec3ceecf  mov [r13+rax*1], r14b
000070c3ec3ceed4  lea rax, [r12+0x68]
000070c3ec3ceed9  mov r14, [r13+rax*1]
000070c3ec3ceede  mov [r15+0x88], r14
000070c3ec3ceee5  xor eax, eax
000070c3ec3ceee7  mov r12d, 0x40
000070c3ec3ceeed  cmp r14, r12
000070c3ec3ceef0  cmc
000070c3ec3ceef1  lahf
000070c3ec3ceef2  seto al
000070c3ec3ceef5  mov [r15+0x108], eax
000070c3ec3ceefc  mov eax, [r15+0x108]
000070c3ec3cef03  sahf
000070c3ec3cef04  jnz 0x000070C3EC3CEF36
000070c3ec3cef06  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cef0e  jz 0x000070C3EC3CF020
000070c3ec3cef14  nop [rax+rax*1], ax
000070c3ec3cef1d  nop [rax+rax*1], eax
000070c3ec3cef25  mov eax, 0x4103A0
000070c3ec3cef2a  mov [r15+0x100], rax
000070c3ec3cef31  jmp 0x000070C3EC1FE110
000070c3ec3cef36  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cef3e  jz 0x000070C3EC3CEF90
000070c3ec3cef44  nop [rax+rax*1], ax
000070c3ec3cef4d  nop [rax+rax*1], eax
000070c3ec3cef55  mov eax, 0x410378
000070c3ec3cef5a  mov [r15+0x100], rax
000070c3ec3cef61  jmp 0x000070C3EC1FE110
000070c3ec3cef66  int3
000070c3ec3cef67  call 0x000070C3EC20D860
000070c3ec3cef6c  jmp 0x000070C3EC3CEE8A
000070c3ec3cef71  call 0x000070C3EC2B36E0
000070c3ec3cef76  jmp 0x000070C3EC3CEEBA
000070c3ec3cef7b  call 0x000070C3EC20DD60
000070c3ec3cef80  jmp 0x000070C3EC3CEED4
000070c3ec3cef85  call 0x000070C3EC20DC20
000070c3ec3cef8a  jmp 0x000070C3EC3CEEDE
000070c3ec3cef8f  int3
000070c3ec3cef90  mov rax, [r15+0x10]
000070c3ec3cef94  lea r14, [rax-0x01]
000070c3ec3cef98  mov [r15+0x10], r14
000070c3ec3cef9c  test r14, r14
000070c3ec3cef9f  setz r14b
000070c3ec3cefa3  movzx r14, r14b
000070c3ec3cefa7  mov [rsp+0x414], r14b
000070c3ec3cefaf  cmp byte ptr [rsp+0x414], 0x00
000070c3ec3cefb7  jz 0x000070C3EC3CEFE9
000070c3ec3cefb9  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cefc1  jz 0x000070C3EC3D0520
000070c3ec3cefc7  nop [rax+rax*1], ax
000070c3ec3cefd0  nop [rax+rax*1], eax
000070c3ec3cefd8  mov eax, 0x410598
000070c3ec3cefdd  mov [r15+0x100], rax
000070c3ec3cefe4  jmp 0x000070C3EC1FE110
000070c3ec3cefe9  cmp dword ptr [r15+0x318], 0x00
000070c3ec3ceff1  jz 0x000070C3EC3CEE80
000070c3ec3ceff7  nop [rax+rax*1], ax
000070c3ec3cf000  nop [rax+rax*1], eax
000070c3ec3cf008  mov eax, 0x410380
000070c3ec3cf00d  mov [r15+0x100], rax
000070c3ec3cf014  jmp 0x000070C3EC1FE110
000070c3ec3cf019  int3
000070c3ec3cf01a  int3
000070c3ec3cf01b  nop [rax+rax*1], eax
000070c3ec3cf020  mov rax, [r15+0x40]
000070c3ec3cf024  movzx r14d, byte ptr [r13+rax*1]
000070c3ec3cf02a  movaps xmm1, [r15+0x110]
000070c3ec3cf032  pinsrb xmm1, r14d, 0x00
000070c3ec3cf039  lea r14, [rax+0x01]
000070c3ec3cf03d  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf043  movaps xmm15, [r15+0x120]
000070c3ec3cf04b  pinsrb xmm15, r12d, 0x00
000070c3ec3cf052  lea r14, [rax+0x02]
000070c3ec3cf056  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf05c  movaps xmm14, [r15+0x130]
000070c3ec3cf064  pinsrb xmm14, r12d, 0x00
000070c3ec3cf06b  lea r14, [rax+0x03]
000070c3ec3cf06f  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf075  movaps xmm13, [r15+0x140]
000070c3ec3cf07d  pinsrb xmm13, r12d, 0x00
000070c3ec3cf084  lea r14, [rax+0x04]
000070c3ec3cf088  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf08e  pinsrb xmm1, r12d, 0x01
000070c3ec3cf095  lea r14, [rax+0x05]
000070c3ec3cf099  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf09f  pinsrb xmm15, r12d, 0x01
000070c3ec3cf0a6  lea r14, [rax+0x06]
000070c3ec3cf0aa  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf0b0  pinsrb xmm14, r12d, 0x01
000070c3ec3cf0b7  lea r14, [rax+0x07]
000070c3ec3cf0bb  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf0c1  pinsrb xmm13, r12d, 0x01
000070c3ec3cf0c8  lea r14, [rax+0x08]
000070c3ec3cf0cc  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf0d2  pinsrb xmm1, r12d, 0x02
000070c3ec3cf0d9  lea r14, [rax+0x09]
000070c3ec3cf0dd  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf0e3  pinsrb xmm15, r12d, 0x02
000070c3ec3cf0ea  lea r14, [rax+0x0A]
000070c3ec3cf0ee  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf0f4  pinsrb xmm14, r12d, 0x02
000070c3ec3cf0fb  lea r14, [rax+0x0B]
000070c3ec3cf0ff  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf105  pinsrb xmm13, r12d, 0x02
000070c3ec3cf10c  lea r14, [rax+0x0C]
000070c3ec3cf110  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf116  pinsrb xmm1, r12d, 0x03
000070c3ec3cf11d  lea r14, [rax+0x0D]
000070c3ec3cf121  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf127  pinsrb xmm15, r12d, 0x03
000070c3ec3cf12e  lea r14, [rax+0x0E]
000070c3ec3cf132  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf138  pinsrb xmm14, r12d, 0x03
000070c3ec3cf13f  lea r14, [rax+0x0F]
000070c3ec3cf143  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf149  pinsrb xmm13, r12d, 0x03
000070c3ec3cf150  lea r14, [rax+0x10]
000070c3ec3cf154  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf15a  pinsrb xmm1, r12d, 0x04
000070c3ec3cf161  lea r14, [rax+0x11]
000070c3ec3cf165  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf16b  pinsrb xmm15, r12d, 0x04
000070c3ec3cf172  lea r14, [rax+0x12]
000070c3ec3cf176  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf17c  pinsrb xmm14, r12d, 0x04
000070c3ec3cf183  lea r14, [rax+0x13]
000070c3ec3cf187  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf18d  pinsrb xmm13, r12d, 0x04
000070c3ec3cf194  lea r14, [rax+0x14]
000070c3ec3cf198  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf19e  pinsrb xmm1, r12d, 0x05
000070c3ec3cf1a5  lea r14, [rax+0x15]
000070c3ec3cf1a9  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf1af  pinsrb xmm15, r12d, 0x05
000070c3ec3cf1b6  lea r14, [rax+0x16]
000070c3ec3cf1ba  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf1c0  pinsrb xmm14, r12d, 0x05
000070c3ec3cf1c7  lea r14, [rax+0x17]
000070c3ec3cf1cb  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf1d1  pinsrb xmm13, r12d, 0x05
000070c3ec3cf1d8  lea r14, [rax+0x18]
000070c3ec3cf1dc  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf1e2  pinsrb xmm1, r12d, 0x06
000070c3ec3cf1e9  lea r14, [rax+0x19]
000070c3ec3cf1ed  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf1f3  pinsrb xmm15, r12d, 0x06
000070c3ec3cf1fa  lea r14, [rax+0x1A]
000070c3ec3cf1fe  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf204  pinsrb xmm14, r12d, 0x06
000070c3ec3cf20b  lea r14, [rax+0x1B]
000070c3ec3cf20f  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf215  pinsrb xmm13, r12d, 0x06
000070c3ec3cf21c  lea r14, [rax+0x1C]
000070c3ec3cf220  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf226  pinsrb xmm1, r12d, 0x07
000070c3ec3cf22d  lea r14, [rax+0x1D]
000070c3ec3cf231  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf237  pinsrb xmm15, r12d, 0x07
000070c3ec3cf23e  lea r14, [rax+0x1E]
000070c3ec3cf242  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf248  pinsrb xmm14, r12d, 0x07
000070c3ec3cf24f  lea r14, [rax+0x1F]
000070c3ec3cf253  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf259  pinsrb xmm13, r12d, 0x07
000070c3ec3cf260  lea r14, [rax+0x20]
000070c3ec3cf264  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf26a  pinsrb xmm1, r12d, 0x08
000070c3ec3cf271  lea r14, [rax+0x21]
000070c3ec3cf275  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf27b  pinsrb xmm15, r12d, 0x08
000070c3ec3cf282  lea r14, [rax+0x22]
000070c3ec3cf286  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf28c  pinsrb xmm14, r12d, 0x08
000070c3ec3cf293  lea r14, [rax+0x23]
000070c3ec3cf297  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf29d  pinsrb xmm13, r12d, 0x08
000070c3ec3cf2a4  lea r14, [rax+0x24]
000070c3ec3cf2a8  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf2ae  pinsrb xmm1, r12d, 0x09
000070c3ec3cf2b5  lea r14, [rax+0x25]
000070c3ec3cf2b9  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf2bf  pinsrb xmm15, r12d, 0x09
000070c3ec3cf2c6  lea r14, [rax+0x26]
000070c3ec3cf2ca  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf2d0  pinsrb xmm14, r12d, 0x09
000070c3ec3cf2d7  lea r14, [rax+0x27]
000070c3ec3cf2db  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf2e1  pinsrb xmm13, r12d, 0x09
000070c3ec3cf2e8  lea r14, [rax+0x28]
000070c3ec3cf2ec  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf2f2  pinsrb xmm1, r12d, 0x0A
000070c3ec3cf2f9  lea r14, [rax+0x29]
000070c3ec3cf2fd  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf303  pinsrb xmm15, r12d, 0x0A
000070c3ec3cf30a  lea r14, [rax+0x2A]
000070c3ec3cf30e  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf314  pinsrb xmm14, r12d, 0x0A
000070c3ec3cf31b  lea r14, [rax+0x2B]
000070c3ec3cf31f  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf325  pinsrb xmm13, r12d, 0x0A
000070c3ec3cf32c  lea r14, [rax+0x2C]
000070c3ec3cf330  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf336  pinsrb xmm1, r12d, 0x0B
000070c3ec3cf33d  lea r14, [rax+0x2D]
000070c3ec3cf341  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf347  pinsrb xmm15, r12d, 0x0B
000070c3ec3cf34e  lea r14, [rax+0x2E]
000070c3ec3cf352  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf358  pinsrb xmm14, r12d, 0x0B
000070c3ec3cf35f  lea r14, [rax+0x2F]
000070c3ec3cf363  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf369  pinsrb xmm13, r12d, 0x0B
000070c3ec3cf370  lea r14, [rax+0x30]
000070c3ec3cf374  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf37a  pinsrb xmm1, r12d, 0x0C
000070c3ec3cf381  lea r14, [rax+0x31]
000070c3ec3cf385  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf38b  pinsrb xmm15, r12d, 0x0C
000070c3ec3cf392  lea r14, [rax+0x32]
000070c3ec3cf396  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf39c  pinsrb xmm14, r12d, 0x0C
000070c3ec3cf3a3  lea r14, [rax+0x33]
000070c3ec3cf3a7  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf3ad  pinsrb xmm13, r12d, 0x0C
000070c3ec3cf3b4  lea r14, [rax+0x34]
000070c3ec3cf3b8  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf3be  pinsrb xmm1, r12d, 0x0D
000070c3ec3cf3c5  lea r14, [rax+0x35]
000070c3ec3cf3c9  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf3cf  pinsrb xmm15, r12d, 0x0D
000070c3ec3cf3d6  lea r14, [rax+0x36]
000070c3ec3cf3da  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf3e0  pinsrb xmm14, r12d, 0x0D
000070c3ec3cf3e7  lea r14, [rax+0x37]
000070c3ec3cf3eb  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf3f1  pinsrb xmm13, r12d, 0x0D
000070c3ec3cf3f8  lea r14, [rax+0x38]
000070c3ec3cf3fc  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf402  pinsrb xmm1, r12d, 0x0E
000070c3ec3cf409  lea r14, [rax+0x39]
000070c3ec3cf40d  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf413  pinsrb xmm15, r12d, 0x0E
000070c3ec3cf41a  lea r14, [rax+0x3A]
000070c3ec3cf41e  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf424  pinsrb xmm14, r12d, 0x0E
000070c3ec3cf42b  lea r14, [rax+0x3B]
000070c3ec3cf42f  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf435  pinsrb xmm13, r12d, 0x0E
000070c3ec3cf43c  lea r14, [rax+0x3C]
000070c3ec3cf440  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf446  pinsrb xmm1, r12d, 0x0F
000070c3ec3cf44d  movaps [r15+0x110], xmm1
000070c3ec3cf455  lea r14, [rax+0x3D]
000070c3ec3cf459  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf45f  pinsrb xmm15, r12d, 0x0F
000070c3ec3cf466  movaps [r15+0x120], xmm15
000070c3ec3cf46e  lea r14, [rax+0x3E]
000070c3ec3cf472  movzx r12d, byte ptr [r13+r14*1]
000070c3ec3cf478  pinsrb xmm14, r12d, 0x0F
000070c3ec3cf47f  movaps [r15+0x130], xmm14
000070c3ec3cf487  lea r14, [rax+0x3F]
000070c3ec3cf48b  movzx eax, byte ptr [r13+r14*1]
000070c3ec3cf491  pinsrb xmm13, eax, 0x0F
000070c3ec3cf498  movaps [r15+0x140], xmm13
000070c3ec3cf4a0  movq xmm1, qword ptr [r15+0x120]
000070c3ec3cf4a9  pmovzxbw xmm1, xmm1
000070c3ec3cf4ae  psllw xmm1, 0x00
000070c3ec3cf4b3  movaps [r15+0x150], xmm1
000070c3ec3cf4bb  movq xmm1, qword ptr [r15+0x130]
000070c3ec3cf4c4  pmovzxbw xmm1, xmm1
000070c3ec3cf4c9  psllw xmm1, 0x00
000070c3ec3cf4ce  movaps [r15+0x160], xmm1
000070c3ec3cf4d6  movq xmm1, qword ptr [r15+0x110]
000070c3ec3cf4df  pmovzxbw xmm1, xmm1
000070c3ec3cf4e4  psllw xmm1, 0x00
000070c3ec3cf4e9  movaps [r15+0x170], xmm1
000070c3ec3cf4f1  movaps xmm15, [r15+0x110]
000070c3ec3cf4f9  pextrq rax, xmm15, 0x01
000070c3ec3cf500  movq xmm15, rax
000070c3ec3cf505  pmovzxbw xmm15, xmm15
000070c3ec3cf50b  psllw xmm15, 0x00
000070c3ec3cf511  movaps [r15+0x180], xmm15
000070c3ec3cf519  movaps xmm14, [r15+0x120]
000070c3ec3cf521  pextrq rax, xmm14, 0x01
000070c3ec3cf528  movq xmm14, rax
000070c3ec3cf52d  pmovzxbw xmm14, xmm14
000070c3ec3cf533  psllw xmm14, 0x00
000070c3ec3cf539  movaps [r15+0x210], xmm14
000070c3ec3cf541  movaps xmm13, [r15+0x130]
000070c3ec3cf549  pextrq rax, xmm13, 0x01
000070c3ec3cf550  movq xmm13, rax
000070c3ec3cf555  pmovzxbw xmm13, xmm13
000070c3ec3cf55b  psllw xmm13, 0x00
000070c3ec3cf561  movaps [r15+0x220], xmm13
000070c3ec3cf569  movq xmm12, qword ptr [r15+0x140]
000070c3ec3cf572  pmovzxbw xmm12, xmm12
000070c3ec3cf578  psllw xmm12, 0x00
000070c3ec3cf57e  movaps [r15+0x250], xmm12
000070c3ec3cf586  movaps xmm12, [r15+0x140]
000070c3ec3cf58e  pextrq rax, xmm12, 0x01
000070c3ec3cf595  movq xmm12, rax
000070c3ec3cf59a  pmovzxbw xmm12, xmm12
000070c3ec3cf5a0  psllw xmm12, 0x00
000070c3ec3cf5a6  movaps [r15+0x110], xmm12
000070c3ec3cf5ae  movq xmm11, qword ptr [r15+0x150]
000070c3ec3cf5b7  pmovzxwd xmm11, xmm11
000070c3ec3cf5bd  pslld xmm11, 0x10
000070c3ec3cf5c3  movq xmm10, qword ptr [r15+0x160]
000070c3ec3cf5cc  pmovzxwd xmm10, xmm10
000070c3ec3cf5d2  pslld xmm10, 0x08
000070c3ec3cf5d8  pextrq rax, xmm1, 0x01
000070c3ec3cf5df  movq xmm1, rax
000070c3ec3cf5e4  pmovzxwd xmm1, xmm1
000070c3ec3cf5e9  pslld xmm1, 0x00
000070c3ec3cf5ee  movaps [r15+0x260], xmm1
000070c3ec3cf5f6  pextrq rax, xmm15, 0x01
000070c3ec3cf5fd  movq xmm15, rax
000070c3ec3cf602  pmovzxwd xmm15, xmm15
000070c3ec3cf608  pslld xmm15, 0x00
000070c3ec3cf60e  movaps [r15+0x270], xmm15
000070c3ec3cf616  movq xmm9, qword ptr [r15+0x170]
000070c3ec3cf61f  pmovzxwd xmm9, xmm9
000070c3ec3cf625  pslld xmm9, 0x00
000070c3ec3cf62b  pextrq rax, xmm14, 0x01
000070c3ec3cf632  movq xmm14, rax
000070c3ec3cf637  pmovzxwd xmm14, xmm14
000070c3ec3cf63d  pslld xmm14, 0x10
000070c3ec3cf643  movaps [r15+0x280], xmm14
000070c3ec3cf64b  movq xmm8, qword ptr [r15+0x180]
000070c3ec3cf654  pmovzxwd xmm8, xmm8
000070c3ec3cf65a  pslld xmm8, 0x00
000070c3ec3cf660  movq xmm7, qword ptr [r15+0x210]
000070c3ec3cf669  pmovzxwd xmm7, xmm7
000070c3ec3cf66e  pslld xmm7, 0x10
000070c3ec3cf673  movaps xmm6, [r15+0x150]
000070c3ec3cf67b  pextrq rax, xmm6, 0x01
000070c3ec3cf682  movq xmm6, rax
000070c3ec3cf687  pmovzxwd xmm6, xmm6
000070c3ec3cf68c  pslld xmm6, 0x10
000070c3ec3cf691  por xmm11, xmm10
000070c3ec3cf696  movaps [r15+0x230], xmm11
000070c3ec3cf69e  pextrq rax, xmm13, 0x01
000070c3ec3cf6a5  movq xmm13, rax
000070c3ec3cf6aa  pmovzxwd xmm13, xmm13
000070c3ec3cf6b0  pslld xmm13, 0x08
000070c3ec3cf6b6  movaps [r15+0x240], xmm13
000070c3ec3cf6be  movq xmm10, qword ptr [r15+0x220]
000070c3ec3cf6c7  pmovzxwd xmm10, xmm10
000070c3ec3cf6cd  pslld xmm10, 0x08
000070c3ec3cf6d3  movaps xmm5, [r15+0x160]
000070c3ec3cf6db  pextrq rax, xmm5, 0x01
000070c3ec3cf6e2  movq xmm5, rax
000070c3ec3cf6e7  pmovzxwd xmm5, xmm5
000070c3ec3cf6ec  pslld xmm5, 0x08
000070c3ec3cf6f1  pslld xmm9, 0x18
000070c3ec3cf6f7  pslld xmm15, 0x18
000070c3ec3cf6fd  pslld xmm8, 0x18
000070c3ec3cf703  movq xmm4, qword ptr [r15+0x250]
000070c3ec3cf70c  pmovzxwd xmm4, xmm4
000070c3ec3cf711  pslld xmm4, 0x00
000070c3ec3cf716  por xmm14, xmm13
000070c3ec3cf71b  por xmm7, xmm10
000070c3ec3cf720  movaps [r15+0x210], xmm7
000070c3ec3cf728  pslld xmm1, 0x18
000070c3ec3cf72d  movaps [r15+0x220], xmm1
000070c3ec3cf735  por xmm6, xmm5
000070c3ec3cf739  por xmm11, xmm9
000070c3ec3cf73e  movaps [r15+0x160], xmm11
000070c3ec3cf746  pextrq rax, xmm12, 0x01
000070c3ec3cf74d  movq xmm13, rax
000070c3ec3cf752  pmovzxwd xmm13, xmm13
000070c3ec3cf758  pslld xmm13, 0x00
000070c3ec3cf75e  movaps [r15+0x170], xmm13
000070c3ec3cf766  movq xmm12, qword ptr [r15+0x110]
000070c3ec3cf76f  pmovzxwd xmm12, xmm12
000070c3ec3cf775  pslld xmm12, 0x00
000070c3ec3cf77b  por xmm14, xmm15
000070c3ec3cf780  por xmm7, xmm8
000070c3ec3cf785  movaps xmm15, [r15+0x250]
000070c3ec3cf78d  pextrq rax, xmm15, 0x01
000070c3ec3cf794  movq xmm15, rax
000070c3ec3cf799  pmovzxwd xmm15, xmm15
000070c3ec3cf79f  pslld xmm15, 0x00
000070c3ec3cf7a5  movaps [r15+0x180], xmm15
000070c3ec3cf7ad  por xmm6, xmm1
000070c3ec3cf7b1  movaps [r15+0x150], xmm6
000070c3ec3cf7b9  por xmm11, xmm4
000070c3ec3cf7be  movaps [r15+0x140], xmm11
000070c3ec3cf7c6  por xmm7, xmm12
000070c3ec3cf7cb  movaps [r15+0x110], xmm7
000070c3ec3cf7d3  por xmm14, xmm13
000070c3ec3cf7d8  movaps [r15+0x120], xmm14
000070c3ec3cf7e0  por xmm6, xmm15
000070c3ec3cf7e5  movaps [r15+0x130], xmm6
000070c3ec3cf7ed  mov rax, [r15+0xF8]
000070c3ec3cf7f4  lea r14, [rax+0x20]
000070c3ec3cf7f8  movups [r13+r14*1], xmm7
000070c3ec3cf7fe  lea r14, [rax+0x30]
000070c3ec3cf802  movups [r13+r14*1], xmm14
000070c3ec3cf808  movups [r13+rax*1], xmm11
000070c3ec3cf80e  lea r14, [rax+0x10]
000070c3ec3cf812  movups [r13+r14*1], xmm6
000070c3ec3cf818  mov r14d, [r13+rax*1]
000070c3ec3cf81d  mov rax, [r15+0x48]
000070c3ec3cf821  mov [r15+0x68], rax
000070c3ec3cf825  mov qword ptr [r15+0x58], 0x04
000070c3ec3cf82d  lea r12, [rax+0x04]
000070c3ec3cf831  mov r11d, [r13+r12*1]
000070c3ec3cf836  mov [rsp+0x10], r11d
000070c3ec3cf83b  mov r11d, r11d
000070c3ec3cf83e  mov [r15+0x70], r11
000070c3ec3cf842  lea r12, [rax+0x38]
000070c3ec3cf846  mov r11d, [r13+r12*1]
000070c3ec3cf84b  lea r12, [rax+0x24]
000070c3ec3cf84f  mov r10d, [r13+r12*1]
000070c3ec3cf854  mov [rsp+0x20], r10d
000070c3ec3cf859  mov r10d, r10d
000070c3ec3cf85c  mov [r15+0x90], r10
000070c3ec3cf863  mov [rsp+0x30], rax
000070c3ec3cf868  xor eax, eax
000070c3ec3cf86a  mov r12d, 0x04
000070c3ec3cf870  mov r10d, 0xC0
000070c3ec3cf876  cmp r12, r10
000070c3ec3cf879  cmc
000070c3ec3cf87a  lahf
000070c3ec3cf87b  seto al
000070c3ec3cf87e  mov [r15+0x108], eax
000070c3ec3cf885  mov eax, [rsp+0x10]
000070c3ec3cf889  mov r12d, [rsp+0x10]
000070c3ec3cf88e  shrd eax, r12d, 0x07
000070c3ec3cf893  mov [rsp+0x10], r11d
000070c3ec3cf898  mov r10d, [rsp+0x10]
000070c3ec3cf89d  shrd r11d, r10d, 0x11
000070c3ec3cf8a2  mov r9d, [rsp+0x20]
000070c3ec3cf8a7  lea r8d, [r9d+r14d*1]
000070c3ec3cf8ac  rorx r14d, r12d, 0x12
000070c3ec3cf8b2  xor eax, r14d
000070c3ec3cf8b5  rorx r14d, r10d, 0x13
000070c3ec3cf8bb  xor r11d, r14d
000070c3ec3cf8be  mov [rsp+0x10], r11d
000070c3ec3cf8c3  mov r11d, r11d
000070c3ec3cf8c6  mov [r15+0x88], r11
000070c3ec3cf8cd  mov [rsp+0x20], r12d
000070c3ec3cf8d2  shr r12d, 0x03
000070c3ec3cf8d6  xor eax, r12d
000070c3ec3cf8d9  mov [rsp+0x40], eax
000070c3ec3cf8dd  mov eax, eax
000070c3ec3cf8df  mov [r15+0x80], rax
000070c3ec3cf8e6  shr r10d, 0x0A
000070c3ec3cf8ea  mov eax, [rsp+0x10]
000070c3ec3cf8ee  xor eax, r10d
000070c3ec3cf8f1  mov [rsp+0x10], eax
000070c3ec3cf8f5  mov eax, eax
000070c3ec3cf8f7  mov [r15+0x78], rax
000070c3ec3cf8fb  mov eax, [rsp+0x40]
000070c3ec3cf8ff  lea r14d, [r8d+eax*1]
000070c3ec3cf904  mov eax, [rsp+0x10]
000070c3ec3cf908  lea r12d, [r14d+eax*1]
000070c3ec3cf90d  mov rax, [rsp+0x30]
000070c3ec3cf912  lea r14, [rax+0x40]
000070c3ec3cf916  mov [r13+r14*1], r12d
000070c3ec3cf91b  mov eax, [rsp+0x20]
000070c3ec3cf91f  mov eax, eax
000070c3ec3cf921  mov [r15+0x60], rax
000070c3ec3cf925  mov eax, [r15+0x108]
000070c3ec3cf92c  sahf
000070c3ec3cf92d  jnz 0x000070C3EC3CF95F
000070c3ec3cf92f  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cf937  jz 0x000070C3EC3CFE20
000070c3ec3cf93d  nop [rax+rax*1], ax
000070c3ec3cf946  nop [rax+rax*1], eax
000070c3ec3cf94e  mov eax, 0x41049C
000070c3ec3cf953  mov [r15+0x100], rax
000070c3ec3cf95a  jmp 0x000070C3EC1FE110
000070c3ec3cf95f  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cf967  jz 0x000070C3EC3CFC70
000070c3ec3cf96d  nop [rax+rax*1], ax
000070c3ec3cf976  nop [rax+rax*1], eax
000070c3ec3cf97e  mov eax, 0x410454
000070c3ec3cf983  mov [r15+0x100], rax
000070c3ec3cf98a  jmp 0x000070C3EC1FE110
000070c3ec3cf98f  int3
000070c3ec3cf990  call 0x000070C3EC20D860
000070c3ec3cf995  jmp 0x000070C3EC3CF02A
000070c3ec3cf99a  call 0x000070C3EC2E2420
000070c3ec3cf99f  jmp 0x000070C3EC3CF043
000070c3ec3cf9a4  call 0x000070C3EC2E2420
000070c3ec3cf9a9  jmp 0x000070C3EC3CF05C
000070c3ec3cf9ae  call 0x000070C3EC2E2420
000070c3ec3cf9b3  jmp 0x000070C3EC3CF075
000070c3ec3cf9b8  call 0x000070C3EC2E2420
000070c3ec3cf9bd  jmp 0x000070C3EC3CF08E
000070c3ec3cf9c2  call 0x000070C3EC2E2420
000070c3ec3cf9c7  jmp 0x000070C3EC3CF09F
000070c3ec3cf9cc  call 0x000070C3EC2E2420
000070c3ec3cf9d1  jmp 0x000070C3EC3CF0B0
000070c3ec3cf9d6  call 0x000070C3EC2E2420
000070c3ec3cf9db  jmp 0x000070C3EC3CF0C1
000070c3ec3cf9e0  call 0x000070C3EC2E2420
000070c3ec3cf9e5  jmp 0x000070C3EC3CF0D2
000070c3ec3cf9ea  call 0x000070C3EC2E2420
000070c3ec3cf9ef  jmp 0x000070C3EC3CF0E3
000070c3ec3cf9f4  call 0x000070C3EC2E2420
000070c3ec3cf9f9  jmp 0x000070C3EC3CF0F4
000070c3ec3cf9fe  call 0x000070C3EC2E2420
000070c3ec3cfa03  jmp 0x000070C3EC3CF105
000070c3ec3cfa08  call 0x000070C3EC2E2420
000070c3ec3cfa0d  jmp 0x000070C3EC3CF116
000070c3ec3cfa12  call 0x000070C3EC2E2420
000070c3ec3cfa17  jmp 0x000070C3EC3CF127
000070c3ec3cfa1c  call 0x000070C3EC2E2420
000070c3ec3cfa21  jmp 0x000070C3EC3CF138
000070c3ec3cfa26  call 0x000070C3EC2E2420
000070c3ec3cfa2b  jmp 0x000070C3EC3CF149
000070c3ec3cfa30  call 0x000070C3EC2E2420
000070c3ec3cfa35  jmp 0x000070C3EC3CF15A
000070c3ec3cfa3a  call 0x000070C3EC2E2420
000070c3ec3cfa3f  jmp 0x000070C3EC3CF16B
000070c3ec3cfa44  call 0x000070C3EC2E2420
000070c3ec3cfa49  jmp 0x000070C3EC3CF17C
000070c3ec3cfa4e  call 0x000070C3EC2E2420
000070c3ec3cfa53  jmp 0x000070C3EC3CF18D
000070c3ec3cfa58  call 0x000070C3EC2E2420
000070c3ec3cfa5d  jmp 0x000070C3EC3CF19E
000070c3ec3cfa62  call 0x000070C3EC2E2420
000070c3ec3cfa67  jmp 0x000070C3EC3CF1AF
000070c3ec3cfa6c  call 0x000070C3EC2E2420
000070c3ec3cfa71  jmp 0x000070C3EC3CF1C0
000070c3ec3cfa76  call 0x000070C3EC2E2420
000070c3ec3cfa7b  jmp 0x000070C3EC3CF1D1
000070c3ec3cfa80  call 0x000070C3EC2E2420
000070c3ec3cfa85  jmp 0x000070C3EC3CF1E2
000070c3ec3cfa8a  call 0x000070C3EC2E2420
000070c3ec3cfa8f  jmp 0x000070C3EC3CF1F3
000070c3ec3cfa94  call 0x000070C3EC2E2420
000070c3ec3cfa99  jmp 0x000070C3EC3CF204
000070c3ec3cfa9e  call 0x000070C3EC2E2420
000070c3ec3cfaa3  jmp 0x000070C3EC3CF215
000070c3ec3cfaa8  call 0x000070C3EC2E2420
000070c3ec3cfaad  jmp 0x000070C3EC3CF226
000070c3ec3cfab2  call 0x000070C3EC2E2420
000070c3ec3cfab7  jmp 0x000070C3EC3CF237
000070c3ec3cfabc  call 0x000070C3EC2E2420
000070c3ec3cfac1  jmp 0x000070C3EC3CF248
000070c3ec3cfac6  call 0x000070C3EC2E2420
000070c3ec3cfacb  jmp 0x000070C3EC3CF259
000070c3ec3cfad0  call 0x000070C3EC2E2420
000070c3ec3cfad5  jmp 0x000070C3EC3CF26A
000070c3ec3cfada  call 0x000070C3EC2E2420
000070c3ec3cfadf  jmp 0x000070C3EC3CF27B
000070c3ec3cfae4  call 0x000070C3EC2E2420
000070c3ec3cfae9  jmp 0x000070C3EC3CF28C
000070c3ec3cfaee  call 0x000070C3EC2E2420
000070c3ec3cfaf3  jmp 0x000070C3EC3CF29D
000070c3ec3cfaf8  call 0x000070C3EC2E2420
000070c3ec3cfafd  jmp 0x000070C3EC3CF2AE
000070c3ec3cfb02  call 0x000070C3EC2E2420
000070c3ec3cfb07  jmp 0x000070C3EC3CF2BF
000070c3ec3cfb0c  call 0x000070C3EC2E2420
000070c3ec3cfb11  jmp 0x000070C3EC3CF2D0
000070c3ec3cfb16  call 0x000070C3EC2E2420
000070c3ec3cfb1b  jmp 0x000070C3EC3CF2E1
000070c3ec3cfb20  call 0x000070C3EC2E2420
000070c3ec3cfb25  jmp 0x000070C3EC3CF2F2
000070c3ec3cfb2a  call 0x000070C3EC2E2420
000070c3ec3cfb2f  jmp 0x000070C3EC3CF303
000070c3ec3cfb34  call 0x000070C3EC2E2420
000070c3ec3cfb39  jmp 0x000070C3EC3CF314
000070c3ec3cfb3e  call 0x000070C3EC2E2420
000070c3ec3cfb43  jmp 0x000070C3EC3CF325
000070c3ec3cfb48  call 0x000070C3EC2E2420
000070c3ec3cfb4d  jmp 0x000070C3EC3CF336
000070c3ec3cfb52  call 0x000070C3EC2E2420
000070c3ec3cfb57  jmp 0x000070C3EC3CF347
000070c3ec3cfb5c  call 0x000070C3EC2E2420
000070c3ec3cfb61  jmp 0x000070C3EC3CF358
000070c3ec3cfb66  call 0x000070C3EC2E2420
000070c3ec3cfb6b  jmp 0x000070C3EC3CF369
000070c3ec3cfb70  call 0x000070C3EC2E2420
000070c3ec3cfb75  jmp 0x000070C3EC3CF37A
000070c3ec3cfb7a  call 0x000070C3EC2E2420
000070c3ec3cfb7f  jmp 0x000070C3EC3CF38B
000070c3ec3cfb84  call 0x000070C3EC2E2420
000070c3ec3cfb89  jmp 0x000070C3EC3CF39C
000070c3ec3cfb8e  call 0x000070C3EC2E2420
000070c3ec3cfb93  jmp 0x000070C3EC3CF3AD
000070c3ec3cfb98  call 0x000070C3EC2E2420
000070c3ec3cfb9d  jmp 0x000070C3EC3CF3BE
000070c3ec3cfba2  call 0x000070C3EC2E2420
000070c3ec3cfba7  jmp 0x000070C3EC3CF3CF
000070c3ec3cfbac  call 0x000070C3EC2E2420
000070c3ec3cfbb1  jmp 0x000070C3EC3CF3E0
000070c3ec3cfbb6  call 0x000070C3EC2E2420
000070c3ec3cfbbb  jmp 0x000070C3EC3CF3F1
000070c3ec3cfbc0  call 0x000070C3EC2E2420
000070c3ec3cfbc5  jmp 0x000070C3EC3CF402
000070c3ec3cfbca  call 0x000070C3EC2E2420
000070c3ec3cfbcf  jmp 0x000070C3EC3CF413
000070c3ec3cfbd4  call 0x000070C3EC2E2420
000070c3ec3cfbd9  jmp 0x000070C3EC3CF424
000070c3ec3cfbde  call 0x000070C3EC2E2420
000070c3ec3cfbe3  jmp 0x000070C3EC3CF435
000070c3ec3cfbe8  call 0x000070C3EC2E2420
000070c3ec3cfbed  jmp 0x000070C3EC3CF446
000070c3ec3cfbf2  call 0x000070C3EC2E2420
000070c3ec3cfbf7  jmp 0x000070C3EC3CF45F
000070c3ec3cfbfc  call 0x000070C3EC2E2420
000070c3ec3cfc01  jmp 0x000070C3EC3CF478
000070c3ec3cfc06  call 0x000070C3EC2D5610
000070c3ec3cfc0b  jmp 0x000070C3EC3CF491
000070c3ec3cfc10  call 0x000070C3EC2DC580
000070c3ec3cfc15  jmp 0x000070C3EC3CF7FE
000070c3ec3cfc1a  call 0x000070C3EC2E46C0
000070c3ec3cfc1f  jmp 0x000070C3EC3CF808
000070c3ec3cfc24  call 0x000070C3EC209E90
000070c3ec3cfc29  jmp 0x000070C3EC3CF80E
000070c3ec3cfc2e  call 0x000070C3EC2DB310
000070c3ec3cfc33  jmp 0x000070C3EC3CF818
000070c3ec3cfc38  call 0x000070C3EC20DAE0
000070c3ec3cfc3d  jmp 0x000070C3EC3CF81D
000070c3ec3cfc42  call 0x000070C3EC2C0230
000070c3ec3cfc47  jmp 0x000070C3EC3CF836
000070c3ec3cfc4c  call 0x000070C3EC2C0230
000070c3ec3cfc51  jmp 0x000070C3EC3CF84B
000070c3ec3cfc56  call 0x000070C3EC2BEFC0
000070c3ec3cfc5b  jmp 0x000070C3EC3CF854
000070c3ec3cfc60  call 0x000070C3EC2E2BA0
000070c3ec3cfc65  jmp 0x000070C3EC3CF91B
000070c3ec3cfc6a  int3
000070c3ec3cfc6b  nop [rax+rax*1], eax
000070c3ec3cfc70  mov rax, [r15+0x48]
000070c3ec3cfc74  mov r14, [r15+0x58]
000070c3ec3cfc78  lea r12, [rax+r14*1]
000070c3ec3cfc7c  mov [r15+0x68], r12
000070c3ec3cfc80  lea rax, [r14+0x04]
000070c3ec3cfc84  mov [r15+0x58], rax
000070c3ec3cfc88  lea r14, [r12+0x04]
000070c3ec3cfc8d  mov r11d, [r13+r14*1]
000070c3ec3cfc92  mov [rsp+0x10], r11d
000070c3ec3cfc97  mov r11d, r11d
000070c3ec3cfc9a  mov [r15+0x70], r11
000070c3ec3cfc9e  lea r14, [r12+0x38]
000070c3ec3cfca3  mov r11d, [r13+r14*1]
000070c3ec3cfca8  lea r14, [r12+0x24]
000070c3ec3cfcad  mov r10d, [r13+r14*1]
000070c3ec3cfcb2  mov [rsp+0x20], r10d
000070c3ec3cfcb7  mov r10d, r10d
000070c3ec3cfcba  mov [r15+0x90], r10
000070c3ec3cfcc1  mov [rsp+0x30], rax
000070c3ec3cfcc6  xor eax, eax
000070c3ec3cfcc8  mov r14, [rsp+0x30]
000070c3ec3cfccd  mov r10d, 0xC0
000070c3ec3cfcd3  cmp r14, r10
000070c3ec3cfcd6  cmc
000070c3ec3cfcd7  lahf
000070c3ec3cfcd8  seto al
000070c3ec3cfcdb  mov [r15+0x108], eax
000070c3ec3cfce2  mov eax, [rsp+0x10]
000070c3ec3cfce6  mov r14d, [rsp+0x10]
000070c3ec3cfceb  shrd eax, r14d, 0x07
000070c3ec3cfcf0  mov [rsp+0x10], r11d
000070c3ec3cfcf5  mov r10d, [rsp+0x10]
000070c3ec3cfcfa  shrd r11d, r10d, 0x11
000070c3ec3cfcff  mov r9d, [r15+0x60]
000070c3ec3cfd03  mov r8d, [rsp+0x20]
000070c3ec3cfd08  lea ebp, [r8d+r9d*1]
000070c3ec3cfd0d  rorx r9d, r14d, 0x12
000070c3ec3cfd13  xor eax, r9d
000070c3ec3cfd16  rorx r9d, r10d, 0x13
000070c3ec3cfd1c  xor r11d, r9d
000070c3ec3cfd1f  mov [rsp+0x10], r11d
000070c3ec3cfd24  mov r11d, r11d
000070c3ec3cfd27  mov [r15+0x88], r11
000070c3ec3cfd2e  mov [rsp+0x20], r14d
000070c3ec3cfd33  shr r14d, 0x03
000070c3ec3cfd37  xor eax, r14d
000070c3ec3cfd3a  mov [rsp+0x30], eax
000070c3ec3cfd3e  mov eax, eax
000070c3ec3cfd40  mov [r15+0x80], rax
000070c3ec3cfd47  shr r10d, 0x0A
000070c3ec3cfd4b  mov eax, [rsp+0x10]
000070c3ec3cfd4f  xor eax, r10d
000070c3ec3cfd52  mov [rsp+0x10], eax
000070c3ec3cfd56  mov eax, eax
000070c3ec3cfd58  mov [r15+0x78], rax
000070c3ec3cfd5c  mov eax, [rsp+0x30]
000070c3ec3cfd60  lea r14d, [ebp+eax*1]
000070c3ec3cfd66  mov eax, [rsp+0x10]
000070c3ec3cfd6a  lea r11d, [r14d+eax*1]
000070c3ec3cfd6f  lea rax, [r12+0x40]
000070c3ec3cfd74  mov [r13+rax*1], r11d
000070c3ec3cfd79  mov eax, [rsp+0x20]
000070c3ec3cfd7d  mov eax, eax
000070c3ec3cfd7f  mov [r15+0x60], rax
000070c3ec3cfd83  mov eax, [r15+0x108]
000070c3ec3cfd8a  sahf
000070c3ec3cfd8b  jnz 0x000070C3EC3CFDBD
000070c3ec3cfd8d  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cfd95  jz 0x000070C3EC3CFE20
000070c3ec3cfd9b  nop [rax+rax*1], ax
000070c3ec3cfda4  nop [rax+rax*1], eax
000070c3ec3cfdac  mov eax, 0x41049C
000070c3ec3cfdb1  mov [r15+0x100], rax
000070c3ec3cfdb8  jmp 0x000070C3EC1FE110
000070c3ec3cfdbd  cmp dword ptr [r15+0x318], 0x00
000070c3ec3cfdc5  jz 0x000070C3EC3CFC70
000070c3ec3cfdcb  nop [rax+rax*1], ax
000070c3ec3cfdd4  nop [rax+rax*1], eax
000070c3ec3cfddc  mov eax, 0x410454
000070c3ec3cfde1  mov [r15+0x100], rax
000070c3ec3cfde8  jmp 0x000070C3EC1FE110
000070c3ec3cfded  int3
000070c3ec3cfdee  call 0x000070C3EC2E1430
000070c3ec3cfdf3  jmp 0x000070C3EC3CFC92
000070c3ec3cfdf8  call 0x000070C3EC2E1430
000070c3ec3cfdfd  jmp 0x000070C3EC3CFCA8
000070c3ec3cfe02  call 0x000070C3EC2E01C0
000070c3ec3cfe07  jmp 0x000070C3EC3CFCB2
000070c3ec3cfe0c  call 0x000070C3EC20A860
000070c3ec3cfe11  jmp 0x000070C3EC3CFD79
000070c3ec3cfe16  int3
000070c3ec3cfe17  nop [rax+rax*1], ax
000070c3ec3cfe20  mov rax, [r15]
000070c3ec3cfe23  mov r14d, [r13+rax*1]
000070c3ec3cfe28  lea r12, [rax+0x04]
000070c3ec3cfe2c  mov r11d, [r13+r12*1]
000070c3ec3cfe31  mov [rsp+0x10], r14d
000070c3ec3cfe36  mov r14d, r14d
000070c3ec3cfe39  mov [r15+0x78], r14
000070c3ec3cfe3d  mov [rsp+0x20], r11d
000070c3ec3cfe42  mov r11d, r11d
000070c3ec3cfe45  mov [r15+0x80], r11
000070c3ec3cfe4c  lea r14, [rax+0x08]
000070c3ec3cfe50  mov r12d, [r13+r14*1]
000070c3ec3cfe55  lea r14, [rax+0x0C]
000070c3ec3cfe59  mov r11d, [r13+r14*1]
000070c3ec3cfe5e  mov [rsp+0x30], r12d
000070c3ec3cfe63  mov r12d, r12d
000070c3ec3cfe66  mov [r15+0x70], r12
000070c3ec3cfe6a  mov [rsp+0x40], r11d
000070c3ec3cfe6f  mov r11d, r11d
000070c3ec3cfe72  mov [r15+0x68], r11
000070c3ec3cfe76  lea r14, [rax+0x18]
000070c3ec3cfe7a  mov r12d, [r13+r14*1]
000070c3ec3cfe7f  lea r14, [rax+0x1C]
000070c3ec3cfe83  mov r11d, [r13+r14*1]
000070c3ec3cfe88  mov [rsp+0x50], r12d
000070c3ec3cfe8d  mov r12d, r12d
000070c3ec3cfe90  mov [r15+0x58], r12
000070c3ec3cfe94  mov [rsp+0x60], r11d
000070c3ec3cfe99  mov r11d, r11d
000070c3ec3cfe9c  mov [r15+0x60], r11
000070c3ec3cfea0  lea r14, [rax+0x10]
000070c3ec3cfea4  mov r12d, [r13+r14*1]
000070c3ec3cfea9  lea r14, [rax+0x14]
000070c3ec3cfead  mov eax, [r13+r14*1]
000070c3ec3cfeb2  mov [rsp+0x70], r12d
000070c3ec3cfeb7  mov r12d, r12d
000070c3ec3cfeba  mov [r15+0x18], r12
000070c3ec3cfebe  mov [rsp+0x80], eax
000070c3ec3cfec5  mov eax, eax
000070c3ec3cfec7  mov [r15+0x90], rax
000070c3ec3cfece  mov eax, [rsp+0x70]
000070c3ec3cfed2  mov eax, eax
000070c3ec3cfed4  mov [r15+0x30], rax
000070c3ec3cfed8  mov eax, [rsp+0x50]
000070c3ec3cfedc  mov eax, eax
000070c3ec3cfede  mov [r15+0xA0], rax
000070c3ec3cfee5  mov eax, [rsp+0x30]
000070c3ec3cfee9  mov eax, eax
000070c3ec3cfeeb  mov [r15+0x28], rax
000070c3ec3cfeef  mov eax, [rsp+0x20]
000070c3ec3cfef3  mov eax, eax
000070c3ec3cfef5  mov [r15+0x98], rax
000070c3ec3cfefc  mov eax, [rsp+0x10]
000070c3ec3cff00  mov eax, eax
000070c3ec3cff02  mov [r15+0x38], rax
000070c3ec3cff06  mov eax, [rsp+0x70]
000070c3ec3cff0a  mov r14d, [rsp+0x70]
000070c3ec3cff0f  shrd eax, r14d, 0x06
000070c3ec3cff14  mov [rsp+0x70], r14d
000070c3ec3cff19  mov r12d, [rsp+0x80]
000070c3ec3cff21  and r14d, r12d
000070c3ec3cff24  mov r11d, [rsp+0x10]
000070c3ec3cff29  mov r10d, [rsp+0x10]
000070c3ec3cff2e  shrd r11d, r10d, 0x02
000070c3ec3cff33  mov [rsp+0x10], r12d
000070c3ec3cff38  mov r12d, r12d
000070c3ec3cff3b  mov [r15+0x20], r12
000070c3ec3cff3f  mov r12, [r15+0x50]
000070c3ec3cff43  mov r9d, [r13+r12*1]
000070c3ec3cff48  mov r12d, [rsp+0x50]
000070c3ec3cff4d  mov r8d, [rsp+0x70]
000070c3ec3cff52  andn ebp, r8d, r12d
000070c3ec3cff57  mov edi, [rsp+0x60]
000070c3ec3cff5b  lea esi, [r14d+edi*1]
000070c3ec3cff60  rorx r14d, r8d, 0x0B
000070c3ec3cff66  xor eax, r14d
000070c3ec3cff69  rorx r14d, r10d, 0x0D
000070c3ec3cff6f  xor r11d, r14d
000070c3ec3cff72  lea edi, [esi+ebp*1]
000070c3ec3cff76  mov r14, [r15+0x48]
000070c3ec3cff7a  mov ebp, [r13+r14*1]
000070c3ec3cff7f  mov r14d, [rsp+0x30]
000070c3ec3cff84  mov esi, [rsp+0x20]
000070c3ec3cff88  and r14d, esi
000070c3ec3cff8b  mov [rsp+0x20], r14d
000070c3ec3cff90  mov r14d, r14d
000070c3ec3cff93  mov [r15+0xD8], r14
000070c3ec3cff9a  lea r14d, [edi+r9d*1]
000070c3ec3cff9f  mov r9d, [rsp+0x30]
000070c3ec3cffa4  xor r9d, esi
000070c3ec3cffa7  rorx edi, r8d, 0x19
000070c3ec3cffad  xor eax, edi
000070c3ec3cffaf  and r9d, r10d
000070c3ec3cffb2  rorx edi, r10d, 0x16
000070c3ec3cffb8  xor r11d, edi
000070c3ec3cffbb  mov [rsp+0x30], r11d
000070c3ec3cffc0  mov r11d, r11d
000070c3ec3cffc3  mov [r15+0xD0], r11
000070c3ec3cffca  lea r11d, [r14d+ebp*1]
000070c3ec3cffcf  mov r10d, [rsp+0x20]
000070c3ec3cffd4  xor r9d, r10d
000070c3ec3cffd7  lea r14d, [r11d+eax*1]
000070c3ec3cffdc  mov qword ptr [r15+0x88], 0x04
000070c3ec3cffe7  mov eax, [rsp+0x30]
000070c3ec3cffeb  lea r11d, [r9d+eax*1]
000070c3ec3cfff0  mov eax, [rsp+0x40]
000070c3ec3cfff4  lea r10d, [r14d+eax*1]
000070c3ec3cfff9  mov r10d, r10d
000070c3ec3cfffc  mov [r15+0xB8], r10
000070c3ec3d0003  xor eax, eax
000070c3ec3d0005  mov r10d, 0x04
000070c3ec3d000b  mov r9d, 0x100
000070c3ec3d0011  cmp r10, r9
000070c3ec3d0014  cmc
000070c3ec3d0015  lahf
000070c3ec3d0016  seto al
000070c3ec3d0019  mov [r15+0x108], eax
000070c3ec3d0020  lea eax, [r11d+r14d*1]
000070c3ec3d0025  mov eax, eax
000070c3ec3d0027  mov [r15+0xA8], rax
000070c3ec3d002e  mov r12d, r12d
000070c3ec3d0031  mov [r15+0xB0], r12
000070c3ec3d0038  mov eax, [rsp+0x10]
000070c3ec3d003c  mov eax, eax
000070c3ec3d003e  mov [r15+0xC0], rax
000070c3ec3d0045  mov r8d, r8d
000070c3ec3d0048  mov [r15+0xC8], r8
000070c3ec3d004f  mov eax, [r15+0x108]
000070c3ec3d0056  sahf
000070c3ec3d0057  jnz 0x000070C3EC3D0089
000070c3ec3d0059  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0061  jz 0x000070C3EC3D0350
000070c3ec3d0067  nop [rax+rax*1], ax
000070c3ec3d0070  nop [rax+rax*1], eax
000070c3ec3d0078  mov eax, 0x41055C
000070c3ec3d007d  mov [r15+0x100], rax
000070c3ec3d0084  jmp 0x000070C3EC1FE110
000070c3ec3d0089  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0091  jz 0x000070C3EC3D0120
000070c3ec3d0097  nop [rax+rax*1], ax
000070c3ec3d00a0  nop [rax+rax*1], eax
000070c3ec3d00a8  mov eax, 0x4104D0
000070c3ec3d00ad  mov [r15+0x100], rax
000070c3ec3d00b4  jmp 0x000070C3EC1FE110
000070c3ec3d00b9  int3
000070c3ec3d00ba  call 0x000070C3EC20DAE0
000070c3ec3d00bf  jmp 0x000070C3EC3CFE28
000070c3ec3d00c4  call 0x000070C3EC2C0230
000070c3ec3d00c9  jmp 0x000070C3EC3CFE31
000070c3ec3d00ce  call 0x000070C3EC2E26A0
000070c3ec3d00d3  jmp 0x000070C3EC3CFE55
000070c3ec3d00d8  call 0x000070C3EC2E1430
000070c3ec3d00dd  jmp 0x000070C3EC3CFE5E
000070c3ec3d00e2  call 0x000070C3EC2E26A0
000070c3ec3d00e7  jmp 0x000070C3EC3CFE7F
000070c3ec3d00ec  call 0x000070C3EC2E1430
000070c3ec3d00f1  jmp 0x000070C3EC3CFE88
000070c3ec3d00f6  call 0x000070C3EC2E26A0
000070c3ec3d00fb  jmp 0x000070C3EC3CFEA9
000070c3ec3d0100  call 0x000070C3EC2D5890
000070c3ec3d0105  jmp 0x000070C3EC3CFEB2
000070c3ec3d010a  call 0x000070C3EC2BDD50
000070c3ec3d010f  jmp 0x000070C3EC3CFF48
000070c3ec3d0114  call 0x000070C3EC2DA580
000070c3ec3d0119  jmp 0x000070C3EC3CFF7F
000070c3ec3d011e  int3
000070c3ec3d011f  nop
000070c3ec3d0120  mov eax, [r15+0xB8]
000070c3ec3d0127  mov [rsp+0x10], eax
000070c3ec3d012b  mov eax, eax
000070c3ec3d012d  mov [r15+0x30], rax
000070c3ec3d0131  mov eax, [r15+0xC0]
000070c3ec3d0138  mov [rsp+0x20], eax
000070c3ec3d013c  mov eax, eax
000070c3ec3d013e  mov [r15+0xA0], rax
000070c3ec3d0145  mov eax, [r15+0x28]
000070c3ec3d0149  mov r14d, [r15+0x98]
000070c3ec3d0150  mov [rsp+0x30], r14d
000070c3ec3d0155  mov r14d, r14d
000070c3ec3d0158  mov [r15+0x28], r14
000070c3ec3d015c  mov r14d, [r15+0x38]
000070c3ec3d0160  mov [rsp+0x40], r14d
000070c3ec3d0165  mov r14d, r14d
000070c3ec3d0168  mov [r15+0x98], r14
000070c3ec3d016f  mov r14d, [r15+0xA8]
000070c3ec3d0176  mov [rsp+0x50], r14d
000070c3ec3d017b  mov r14d, r14d
000070c3ec3d017e  mov [r15+0x38], r14
000070c3ec3d0182  mov r14d, [rsp+0x10]
000070c3ec3d0187  mov r12d, [rsp+0x10]
000070c3ec3d018c  shrd r14d, r12d, 0x06
000070c3ec3d0191  mov r11d, [r15+0xC8]
000070c3ec3d0198  mov [rsp+0x10], r12d
000070c3ec3d019d  and r12d, r11d
000070c3ec3d01a0  mov r10d, [rsp+0x50]
000070c3ec3d01a5  mov r9d, [rsp+0x50]
000070c3ec3d01aa  shrd r10d, r9d, 0x02
000070c3ec3d01af  mov [rsp+0x50], r11d
000070c3ec3d01b4  mov r11d, r11d
000070c3ec3d01b7  mov [r15+0x20], r11
000070c3ec3d01bb  mov r11, [r15+0x88]
000070c3ec3d01c2  mov r8, [r15+0x50]
000070c3ec3d01c6  lea rbp, [r8+r11*1]
000070c3ec3d01ca  mov r8d, [r13+rbp*1]
000070c3ec3d01cf  mov ebp, [rsp+0x20]
000070c3ec3d01d3  mov edi, [rsp+0x10]
000070c3ec3d01d7  andn esi, edi, ebp
000070c3ec3d01dc  mov edx, [r15+0xB0]
000070c3ec3d01e3  lea ecx, [r12d+edx*1]
000070c3ec3d01e8  rorx r12d, edi, 0x0B
000070c3ec3d01ee  xor r14d, r12d
000070c3ec3d01f1  rorx r12d, r9d, 0x0D
000070c3ec3d01f7  xor r10d, r12d
000070c3ec3d01fa  lea r12d, [ecx+esi*1]
000070c3ec3d01ff  mov rsi, [r15+0x48]
000070c3ec3d0203  lea rdx, [rsi+r11*1]
000070c3ec3d0207  mov esi, [r13+rdx*1]
000070c3ec3d020c  mov edx, [rsp+0x30]
000070c3ec3d0210  mov ecx, [rsp+0x40]
000070c3ec3d0214  and edx, ecx
000070c3ec3d0216  mov [rsp+0x10], edx
000070c3ec3d021a  mov edx, edx
000070c3ec3d021c  mov [r15+0xD8], rdx
000070c3ec3d0223  lea edx, [r12d+r8d*1]
000070c3ec3d0228  mov r12d, [rsp+0x30]
000070c3ec3d022d  xor r12d, ecx
000070c3ec3d0230  rorx r8d, edi, 0x19
000070c3ec3d0236  xor r14d, r8d
000070c3ec3d0239  and r12d, r9d
000070c3ec3d023c  rorx r8d, r9d, 0x16
000070c3ec3d0242  xor r10d, r8d
000070c3ec3d0245  mov [rsp+0x20], r10d
000070c3ec3d024a  mov r10d, r10d
000070c3ec3d024d  mov [r15+0xD0], r10
000070c3ec3d0254  lea r10d, [edx+esi*1]
000070c3ec3d0259  mov r9d, [rsp+0x10]
000070c3ec3d025e  xor r12d, r9d
000070c3ec3d0261  lea r9d, [r10d+r14d*1]
000070c3ec3d0266  lea r14, [r11+0x04]
000070c3ec3d026a  mov [r15+0x88], r14
000070c3ec3d0271  mov r11d, [rsp+0x20]
000070c3ec3d0276  lea r10d, [r12d+r11d*1]
000070c3ec3d027b  lea r11d, [r9d+eax*1]
000070c3ec3d0280  mov r11d, r11d
000070c3ec3d0283  mov [r15+0xB8], r11
000070c3ec3d028a  xor eax, eax
000070c3ec3d028c  mov r12d, 0x100
000070c3ec3d0292  cmp r14, r12
000070c3ec3d0295  cmc
000070c3ec3d0296  lahf
000070c3ec3d0297  seto al
000070c3ec3d029a  mov [r15+0x108], eax
000070c3ec3d02a1  lea eax, [r10d+r9d*1]
000070c3ec3d02a6  mov eax, eax
000070c3ec3d02a8  mov [r15+0xA8], rax
000070c3ec3d02af  mov ebp, ebp
000070c3ec3d02b1  mov [r15+0xB0], rbp
000070c3ec3d02b8  mov eax, [rsp+0x50]
000070c3ec3d02bc  mov eax, eax
000070c3ec3d02be  mov [r15+0xC0], rax
000070c3ec3d02c5  mov edi, edi
000070c3ec3d02c7  mov [r15+0xC8], rdi
000070c3ec3d02ce  mov eax, [r15+0x108]
000070c3ec3d02d5  sahf
000070c3ec3d02d6  jnz 0x000070C3EC3D0308
000070c3ec3d02d8  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d02e0  jz 0x000070C3EC3D0350
000070c3ec3d02e6  nop [rax+rax*1], ax
000070c3ec3d02ef  nop [rax+rax*1], eax
000070c3ec3d02f7  mov eax, 0x41055C
000070c3ec3d02fc  mov [r15+0x100], rax
000070c3ec3d0303  jmp 0x000070C3EC1FE110
000070c3ec3d0308  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0310  jz 0x000070C3EC3D0120
000070c3ec3d0316  nop [rax+rax*1], ax
000070c3ec3d031f  nop [rax+rax*1], eax
000070c3ec3d0327  mov eax, 0x4104D0
000070c3ec3d032c  mov [r15+0x100], rax
000070c3ec3d0333  jmp 0x000070C3EC1FE110
000070c3ec3d0338  int3
000070c3ec3d0339  call 0x000070C3EC249010
000070c3ec3d033e  jmp 0x000070C3EC3D01CF
000070c3ec3d0343  call 0x000070C3EC225930
000070c3ec3d0348  jmp 0x000070C3EC3D020C
000070c3ec3d034d  int3
000070c3ec3d034e  nop
000070c3ec3d0350  mov eax, [r15+0x98]
000070c3ec3d0357  mov r14d, [r15+0x70]
000070c3ec3d035b  lea r12d, [eax+r14d*1]
000070c3ec3d0360  mov eax, [r15+0x28]
000070c3ec3d0364  mov r14d, [r15+0x68]
000070c3ec3d0368  lea r11d, [eax+r14d*1]
000070c3ec3d036d  mov qword ptr [r15+0x88], 0x00
000070c3ec3d0378  mov eax, [r15+0xA8]
000070c3ec3d037f  mov r14d, [r15+0x78]
000070c3ec3d0383  lea r10d, [eax+r14d*1]
000070c3ec3d0388  mov [rsp+0x10], r10d
000070c3ec3d038d  mov r10d, r10d
000070c3ec3d0390  mov [r15+0x78], r10
000070c3ec3d0394  mov eax, [r15+0x38]
000070c3ec3d0398  mov r14d, [r15+0x80]
000070c3ec3d039f  lea r10d, [eax+r14d*1]
000070c3ec3d03a4  mov [rsp+0x20], r10d
000070c3ec3d03a9  mov r10d, r10d
000070c3ec3d03ac  mov [r15+0x80], r10
000070c3ec3d03b3  mov rax, [r15]
000070c3ec3d03b6  lea r14, [rax+0x08]
000070c3ec3d03ba  mov [r13+r14*1], r12d
000070c3ec3d03bf  lea r14, [rax+0x0C]
000070c3ec3d03c3  mov [r13+r14*1], r11d
000070c3ec3d03c8  mov r14d, [r15+0xB8]
000070c3ec3d03cf  mov r12d, [r15+0x18]
000070c3ec3d03d3  lea r11d, [r14d+r12d*1]
000070c3ec3d03d8  mov [rsp+0x30], r11d
000070c3ec3d03dd  mov r11d, r11d
000070c3ec3d03e0  mov [r15+0x68], r11
000070c3ec3d03e4  mov r14d, [r15+0x30]
000070c3ec3d03e8  mov r12d, [r15+0x90]
000070c3ec3d03ef  lea r11d, [r14d+r12d*1]
000070c3ec3d03f4  mov [rsp+0x40], r11d
000070c3ec3d03f9  mov r11d, r11d
000070c3ec3d03fc  mov [r15+0x70], r11
000070c3ec3d0400  mov r14d, [r15+0x20]
000070c3ec3d0404  mov r12d, [r15+0x58]
000070c3ec3d0408  lea r11d, [r14d+r12d*1]
000070c3ec3d040d  mov [rsp+0x50], r11d
000070c3ec3d0412  mov r11d, r11d
000070c3ec3d0415  mov [r15+0x58], r11
000070c3ec3d0419  mov r14d, [r15+0xA0]
000070c3ec3d0420  mov r12d, [r15+0x60]
000070c3ec3d0424  lea r11d, [r14d+r12d*1]
000070c3ec3d0429  mov [rsp+0x60], r11d
000070c3ec3d042e  mov r11d, r11d
000070c3ec3d0431  mov [r15+0x60], r11
000070c3ec3d0435  mov r14d, [rsp+0x10]
000070c3ec3d043a  mov [r13+rax*1], r14d
000070c3ec3d043f  lea r14, [rax+0x04]
000070c3ec3d0443  mov r12d, [rsp+0x20]
000070c3ec3d0448  mov [r13+r14*1], r12d
000070c3ec3d044d  lea r14, [rax+0x10]
000070c3ec3d0451  mov r12d, [rsp+0x30]
000070c3ec3d0456  mov [r13+r14*1], r12d
000070c3ec3d045b  lea r14, [rax+0x14]
000070c3ec3d045f  mov r12d, [rsp+0x40]
000070c3ec3d0464  mov [r13+r14*1], r12d
000070c3ec3d0469  lea r14, [rax+0x18]
000070c3ec3d046d  mov r12d, [rsp+0x50]
000070c3ec3d0472  mov [r13+r14*1], r12d
000070c3ec3d0477  lea r14, [rax+0x1C]
000070c3ec3d047b  mov r12d, [rsp+0x60]
000070c3ec3d0480  mov [r13+r14*1], r12d
000070c3ec3d0485  lea r14, [rax+0x68]
000070c3ec3d0489  xor eax, eax
000070c3ec3d048b  mov [r13+r14*1], rax
000070c3ec3d0490  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0498  jz 0x000070C3EC3CEF90
000070c3ec3d049e  nop [rax+rax*1], ax
000070c3ec3d04a7  nop [rax+rax*1], eax
000070c3ec3d04af  mov eax, 0x410378
000070c3ec3d04b4  mov [r15+0x100], rax
000070c3ec3d04bb  jmp 0x000070C3EC1FE110
000070c3ec3d04c0  int3
000070c3ec3d04c1  call 0x000070C3EC2E2BA0
000070c3ec3d04c6  jmp 0x000070C3EC3D03BF
000070c3ec3d04cb  call 0x000070C3EC2E1920
000070c3ec3d04d0  jmp 0x000070C3EC3D03C8
000070c3ec3d04d5  call 0x000070C3EC20DFE0
000070c3ec3d04da  jmp 0x000070C3EC3D043F
000070c3ec3d04df  call 0x000070C3EC2E2BA0
000070c3ec3d04e4  jmp 0x000070C3EC3D044D
000070c3ec3d04e9  call 0x000070C3EC2E2BA0
000070c3ec3d04ee  jmp 0x000070C3EC3D045B
000070c3ec3d04f3  call 0x000070C3EC2E2BA0
000070c3ec3d04f8  jmp 0x000070C3EC3D0469
000070c3ec3d04fd  call 0x000070C3EC2E2BA0
000070c3ec3d0502  jmp 0x000070C3EC3D0477
000070c3ec3d0507  call 0x000070C3EC2E2BA0
000070c3ec3d050c  jmp 0x000070C3EC3D0485
000070c3ec3d0511  call 0x000070C3EC2D5EB0
000070c3ec3d0516  jmp 0x000070C3EC3D0490
000070c3ec3d051b  int3
000070c3ec3d051c  nop [rax], eax
000070c3ec3d0520  mov rax, [r15+0xF8]
000070c3ec3d0527  lea r14, [rax+0x140]
000070c3ec3d052e  mov r12, [r13+r14*1]
000070c3ec3d0533  lea r14, [rax+0x148]
000070c3ec3d053a  mov r11, [r13+r14*1]
000070c3ec3d053f  mov [r15+0xA0], r12
000070c3ec3d0546  mov [r15+0x98], r11
000070c3ec3d054d  lea r14, [rax+0x130]
000070c3ec3d0554  mov r12, [r13+r14*1]
000070c3ec3d0559  lea r14, [rax+0x138]
000070c3ec3d0560  mov r11, [r13+r14*1]
000070c3ec3d0565  mov [r15+0xB0], r12
000070c3ec3d056c  mov [r15+0xA8], r11
000070c3ec3d0573  lea r14, [rax+0x120]
000070c3ec3d057a  mov r12, [r13+r14*1]
000070c3ec3d057f  lea r14, [rax+0x128]
000070c3ec3d0586  mov r11, [r13+r14*1]
000070c3ec3d058b  mov [r15+0xC0], r12
000070c3ec3d0592  mov [r15+0xB8], r11
000070c3ec3d0599  lea r14, [rax+0x110]
000070c3ec3d05a0  mov r12, [r13+r14*1]
000070c3ec3d05a5  lea r14, [rax+0x118]
000070c3ec3d05ac  mov r11, [r13+r14*1]
000070c3ec3d05b1  mov [r15+0xD0], r12
000070c3ec3d05b8  mov [r15+0xC8], r11
000070c3ec3d05bf  lea r14, [rax+0x100]
000070c3ec3d05c6  mov r12, [r13+r14*1]
000070c3ec3d05cb  lea r14, [rax+0x108]
000070c3ec3d05d2  mov r11, [r13+r14*1]
000070c3ec3d05d7  mov [r15+0xE8], r12
000070c3ec3d05de  mov [r15+0xD8], r11
000070c3ec3d05e5  lea r14, [rax+0x150]
000070c3ec3d05ec  mov [r15+0xF8], r14
000070c3ec3d05f3  mov rax, [r15+0xF0]
000070c3ec3d05fa  mov [r15+0x100], rax
000070c3ec3d0601  jmp 0x000070C3EC3CE5C0
000070c3ec3d0606  int3
000070c3ec3d0607  call 0x000070C3EC2E27E0
000070c3ec3d060c  jmp 0x000070C3EC3D0533
000070c3ec3d0611  call 0x000070C3EC2E1570
000070c3ec3d0616  jmp 0x000070C3EC3D053F
000070c3ec3d061b  call 0x000070C3EC2E27E0
000070c3ec3d0620  jmp 0x000070C3EC3D0559
000070c3ec3d0625  call 0x000070C3EC2E1570
000070c3ec3d062a  jmp 0x000070C3EC3D0565
000070c3ec3d062f  call 0x000070C3EC2E27E0
000070c3ec3d0634  jmp 0x000070C3EC3D057F
000070c3ec3d0639  call 0x000070C3EC2E1570
000070c3ec3d063e  jmp 0x000070C3EC3D058B
000070c3ec3d0643  call 0x000070C3EC2E27E0
000070c3ec3d0648  jmp 0x000070C3EC3D05A5
000070c3ec3d064d  call 0x000070C3EC2E1570
000070c3ec3d0652  jmp 0x000070C3EC3D05B1
000070c3ec3d0657  call 0x000070C3EC2E27E0
000070c3ec3d065c  jmp 0x000070C3EC3D05CB
000070c3ec3d0661  call 0x000070C3EC2E1570
000070c3ec3d0666  jmp 0x000070C3EC3D05D7
000070c3ec3d066b  int3
000070c3ec3d066c  nop [rax], eax
000070c3ec3d0670  mov eax, [r15+0xA0]
000070c3ec3d0677  mov [rsp+0x10], eax
000070c3ec3d067b  xor eax, eax
000070c3ec3d067d  mov r14d, [rsp+0x10]
000070c3ec3d0682  sub r14d, 0x01
000070c3ec3d0686  cmc
000070c3ec3d0687  lahf
000070c3ec3d0688  seto al
000070c3ec3d068b  mov [r15+0x108], eax
000070c3ec3d0692  mov r14d, r14d
000070c3ec3d0695  mov [r15+0xA0], r14
000070c3ec3d069c  mov eax, [r15+0x108]
000070c3ec3d06a3  sahf
000070c3ec3d06a4  jnz 0x000070C3EC3D06D6
000070c3ec3d06a6  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d06ae  jz 0x000070C3EC3D07A0
000070c3ec3d06b4  nop [rax+rax*1], ax
000070c3ec3d06bd  nop [rax+rax*1], eax
000070c3ec3d06c5  mov eax, 0x41027C
000070c3ec3d06ca  mov [r15+0x100], rax
000070c3ec3d06d1  jmp 0x000070C3EC1FE110
000070c3ec3d06d6  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d06de  jz 0x000070C3EC3D0710
000070c3ec3d06e4  nop [rax+rax*1], ax
000070c3ec3d06ed  nop [rax+rax*1], eax
000070c3ec3d06f5  mov eax, 0x410264
000070c3ec3d06fa  mov [r15+0x100], rax
000070c3ec3d0701  jmp 0x000070C3EC1FE110
000070c3ec3d0706  int3
000070c3ec3d0707  int3
000070c3ec3d0708  nop [rax+rax*1], eax
000070c3ec3d0710  mov rax, [r15+0xF8]
000070c3ec3d0717  mov [r15], rax
000070c3ec3d071a  mov rax, [r15+0x98]
000070c3ec3d0721  mov [r15+0x08], rax
000070c3ec3d0725  mov qword ptr [r15+0x10], 0x12C
000070c3ec3d072d  mov qword ptr [r15+0xF0], 0x410274
000070c3ec3d0738  mov r14d, [r15+0x320]
000070c3ec3d073f  mov eax, 0x410274
000070c3ec3d0744  mov rcx, 0x70C3EC3D0670
000070c3ec3d074e  mov [r15+r14*8+0x328], rax
000070c3ec3d0756  mov [r15+r14*8+0x368], rcx
000070c3ec3d075e  add r14d, 0x01
000070c3ec3d0762  and r14d, 0x07
000070c3ec3d0766  mov [r15+0x320], r14d
000070c3ec3d076d  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0775  jz 0x000070C3EC3CEC20
000070c3ec3d077b  nop [rax+rax*1], ax
000070c3ec3d0784  nop [rax+rax*1], eax
000070c3ec3d078c  mov eax, 0x410338
000070c3ec3d0791  mov [r15+0x100], rax
000070c3ec3d0798  jmp 0x000070C3EC1FE110
000070c3ec3d079d  int3
000070c3ec3d079e  int3
000070c3ec3d079f  nop
000070c3ec3d07a0  mov rax, [r15+0xF8]
000070c3ec3d07a7  lea r14, [rax+0x20]
000070c3ec3d07ab  mov r12, [r13+r14*1]
000070c3ec3d07b0  mov [r15+0x98], r12
000070c3ec3d07b7  mov qword ptr [r15+0x40], 0x80
000070c3ec3d07bf  mov [r15], rax
000070c3ec3d07c2  lea r14, [rax+0x8C]
000070c3ec3d07c9  mov [r15+0x08], r14
000070c3ec3d07cd  mov qword ptr [r15+0x10], 0x01
000070c3ec3d07d5  lea r14, [rax+0x8C]
000070c3ec3d07dc  mov eax, 0x80
000070c3ec3d07e1  mov [r13+r14*1], al
000070c3ec3d07e6  mov qword ptr [r15+0xF0], 0x410298
000070c3ec3d07f1  mov r14d, [r15+0x320]
000070c3ec3d07f8  mov eax, 0x410298
000070c3ec3d07fd  mov rcx, 0x70C3EC3D0870
000070c3ec3d0807  mov [r15+r14*8+0x328], rax
000070c3ec3d080f  mov [r15+r14*8+0x368], rcx
000070c3ec3d0817  add r14d, 0x01
000070c3ec3d081b  and r14d, 0x07
000070c3ec3d081f  mov [r15+0x320], r14d
000070c3ec3d0826  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d082e  jz 0x000070C3EC3CEC20
000070c3ec3d0834  nop [rax+rax*1], ax
000070c3ec3d083d  nop [rax+rax*1], eax
000070c3ec3d0845  mov eax, 0x410338
000070c3ec3d084a  mov [r15+0x100], rax
000070c3ec3d0851  jmp 0x000070C3EC1FE110
000070c3ec3d0856  int3
000070c3ec3d0857  call 0x000070C3EC2E27E0
000070c3ec3d085c  jmp 0x000070C3EC3D07B0
000070c3ec3d0861  call 0x000070C3EC2D5AF0
000070c3ec3d0866  jmp 0x000070C3EC3D07E6
000070c3ec3d086b  int3
000070c3ec3d086c  nop [rax], eax
000070c3ec3d0870  mov rax, [r15+0xF8]
000070c3ec3d0877  lea r14, [rax+0x68]
000070c3ec3d087b  mov r12, [r13+r14*1]
000070c3ec3d0880  mov [r15+0x40], r12
000070c3ec3d0884  lea r14, [rax+0x88]
000070c3ec3d088b  xor eax, eax
000070c3ec3d088d  mov [r13+r14*1], al
000070c3ec3d0892  xor eax, eax
000070c3ec3d0894  mov r14d, 0x38
000070c3ec3d089a  cmp r12, r14
000070c3ec3d089d  cmc
000070c3ec3d089e  lahf
000070c3ec3d089f  seto al
000070c3ec3d08a2  mov [r15+0x108], eax
000070c3ec3d08a9  mov eax, [r15+0x108]
000070c3ec3d08b0  sahf
000070c3ec3d08b1  jz 0x000070C3EC3D08E3
000070c3ec3d08b3  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d08bb  jz 0x000070C3EC3D0930
000070c3ec3d08c1  nop [rax+rax*1], ax
000070c3ec3d08ca  nop [rax+rax*1], eax
000070c3ec3d08d2  mov eax, 0x4102A8
000070c3ec3d08d7  mov [r15+0x100], rax
000070c3ec3d08de  jmp 0x000070C3EC1FE110
000070c3ec3d08e3  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d08eb  jz 0x000070C3EC3D0A70
000070c3ec3d08f1  nop [rax+rax*1], ax
000070c3ec3d08fa  nop [rax+rax*1], eax
000070c3ec3d0902  mov eax, 0x4102C4
000070c3ec3d0907  mov [r15+0x100], rax
000070c3ec3d090e  jmp 0x000070C3EC1FE110
000070c3ec3d0913  int3
000070c3ec3d0914  call 0x000070C3EC2E27E0
000070c3ec3d0919  jmp 0x000070C3EC3D0880
000070c3ec3d091e  call 0x000070C3EC2D5AF0
000070c3ec3d0923  jmp 0x000070C3EC3D0892
000070c3ec3d0928  int3
000070c3ec3d0929  nop [rax], eax
000070c3ec3d0930  mov rax, [r15+0xF8]
000070c3ec3d0937  mov [r15], rax
000070c3ec3d093a  lea r14, [rax+0x88]
000070c3ec3d0941  mov [r15+0x08], r14
000070c3ec3d0945  mov qword ptr [r15+0x10], 0x01
000070c3ec3d094d  mov qword ptr [r15+0xF0], 0x4102B8
000070c3ec3d0958  mov r14d, [r15+0x320]
000070c3ec3d095f  mov eax, 0x4102B8
000070c3ec3d0964  mov rcx, 0x70C3EC3D09C0
000070c3ec3d096e  mov [r15+r14*8+0x328], rax
000070c3ec3d0976  mov [r15+r14*8+0x368], rcx
000070c3ec3d097e  add r14d, 0x01
000070c3ec3d0982  and r14d, 0x07
000070c3ec3d0986  mov [r15+0x320], r14d
000070c3ec3d098d  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0995  jz 0x000070C3EC3CEC20
000070c3ec3d099b  nop [rax+rax*1], ax
000070c3ec3d09a4  nop [rax+rax*1], eax
000070c3ec3d09ac  mov eax, 0x410338
000070c3ec3d09b1  mov [r15+0x100], rax
000070c3ec3d09b8  jmp 0x000070C3EC1FE110
000070c3ec3d09bd  int3
000070c3ec3d09be  int3
000070c3ec3d09bf  nop
000070c3ec3d09c0  mov rax, [r15+0xF8]
000070c3ec3d09c7  lea r14, [rax+0x68]
000070c3ec3d09cb  mov rax, [r13+r14*1]
000070c3ec3d09d0  mov [r15+0x40], rax
000070c3ec3d09d4  mov [rsp+0x10], rax
000070c3ec3d09d9  xor eax, eax
000070c3ec3d09db  mov r14, [rsp+0x10]
000070c3ec3d09e0  mov r12d, 0x38
000070c3ec3d09e6  cmp r14, r12
000070c3ec3d09e9  cmc
000070c3ec3d09ea  lahf
000070c3ec3d09eb  seto al
000070c3ec3d09ee  mov [r15+0x108], eax
000070c3ec3d09f5  mov eax, [r15+0x108]
000070c3ec3d09fc  sahf
000070c3ec3d09fd  jnz 0x000070C3EC3D0A2F
000070c3ec3d09ff  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0a07  jz 0x000070C3EC3D0A70
000070c3ec3d0a0d  nop [rax+rax*1], ax
000070c3ec3d0a16  nop [rax+rax*1], eax
000070c3ec3d0a1e  mov eax, 0x4102C4
000070c3ec3d0a23  mov [r15+0x100], rax
000070c3ec3d0a2a  jmp 0x000070C3EC1FE110
000070c3ec3d0a2f  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0a37  jz 0x000070C3EC3D0930
000070c3ec3d0a3d  nop [rax+rax*1], ax
000070c3ec3d0a46  nop [rax+rax*1], eax
000070c3ec3d0a4e  mov eax, 0x4102A8
000070c3ec3d0a53  mov [r15+0x100], rax
000070c3ec3d0a5a  jmp 0x000070C3EC1FE110
000070c3ec3d0a5f  int3
000070c3ec3d0a60  call 0x000070C3EC2D59C0
000070c3ec3d0a65  jmp 0x000070C3EC3D09D0
000070c3ec3d0a6a  int3
000070c3ec3d0a6b  nop [rax+rax*1], eax
000070c3ec3d0a70  mov rax, [r15+0x98]
000070c3ec3d0a77  rorx r14, rax, 0x3D
000070c3ec3d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
000070c3ec3d0a81  mov rax, [r15+0xF8]
000070c3ec3d0a88  mov [r15], rax
000070c3ec3d0a8b  lea r12, [rax+0x78]
000070c3ec3d0a8f  mov [r15+0x08], r12
000070c3ec3d0a93  mov qword ptr [r15+0x10], 0x08
000070c3ec3d0a9b  bswap r14
000070c3ec3d0a9e  mov [r15+0x40], r14
000070c3ec3d0aa2  lea r12, [rax+0x78]
000070c3ec3d0aa6  mov [r13+r12*1], r14
000070c3ec3d0aab  mov qword ptr [r15+0xF0], 0x4102E0
000070c3ec3d0ab6  mov r14d, [r15+0x320]
000070c3ec3d0abd  mov eax, 0x4102E0
000070c3ec3d0ac2  mov rcx, 0x70C3EC3D0B30
000070c3ec3d0acc  mov [r15+r14*8+0x328], rax
000070c3ec3d0ad4  mov [r15+r14*8+0x368], rcx
000070c3ec3d0adc  add r14d, 0x01
000070c3ec3d0ae0  and r14d, 0x07
000070c3ec3d0ae4  mov [r15+0x320], r14d
000070c3ec3d0aeb  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0af3  jz 0x000070C3EC3CEC20
000070c3ec3d0af9  nop [rax+rax*1], ax
000070c3ec3d0b02  nop [rax+rax*1], eax
000070c3ec3d0b0a  mov eax, 0x410338
000070c3ec3d0b0f  mov [r15+0x100], rax
000070c3ec3d0b16  jmp 0x000070C3EC1FE110
000070c3ec3d0b1b  int3
000070c3ec3d0b1c  call 0x000070C3EC2C3FE0
000070c3ec3d0b21  jmp 0x000070C3EC3D0AAB
000070c3ec3d0b26  int3
000070c3ec3d0b27  nop [rax+rax*1], ax
000070c3ec3d0b30  mov rax, [r15+0xF8]
000070c3ec3d0b37  mov r14d, [r13+rax*1]
000070c3ec3d0b3c  lea r12, [rax+0x04]
000070c3ec3d0b40  mov r11d, [r13+r12*1]
000070c3ec3d0b45  lea r12, [rax+0x08]
000070c3ec3d0b49  mov r10d, [r13+r12*1]
000070c3ec3d0b4e  lea r12, [rax+0x0C]
000070c3ec3d0b52  mov r9d, [r13+r12*1]
000070c3ec3d0b57  mov qword ptr [r15+0x48], 0x430860
000070c3ec3d0b5f  lea r12, [rax+0x80]
000070c3ec3d0b66  mov r8, [r13+r12*1]
000070c3ec3d0b6b  mov [r15+0xF0], r8
000070c3ec3d0b72  bswap r14d
000070c3ec3d0b75  bswap r11d
000070c3ec3d0b78  mov r12d, 0x430860
000070c3ec3d0b7e  mov [r13+r12*1], r14d
000070c3ec3d0b83  mov r14d, 0x430864
000070c3ec3d0b89  mov [r13+r14*1], r11d
000070c3ec3d0b8e  bswap r10d
000070c3ec3d0b91  bswap r9d
000070c3ec3d0b94  lea r14, [rax+0x10]
000070c3ec3d0b98  mov r12d, [r13+r14*1]
000070c3ec3d0b9d  lea r14, [rax+0x14]
000070c3ec3d0ba1  mov r11d, [r13+r14*1]
000070c3ec3d0ba6  mov r14d, 0x430868
000070c3ec3d0bac  mov [r13+r14*1], r10d
000070c3ec3d0bb1  mov r14d, 0x43086C
000070c3ec3d0bb7  mov [r13+r14*1], r9d
000070c3ec3d0bbc  lea r14, [rax+0x90]
000070c3ec3d0bc3  mov r10, [r13+r14*1]
000070c3ec3d0bc8  lea r14, [rax+0x98]
000070c3ec3d0bcf  mov r9, [r13+r14*1]
000070c3ec3d0bd4  mov [r15+0xA0], r10
000070c3ec3d0bdb  mov [r15+0x98], r9
000070c3ec3d0be2  bswap r12d
000070c3ec3d0be5  bswap r11d
000070c3ec3d0be8  mov [rsp+0x10], r11d
000070c3ec3d0bed  mov r11d, r11d
000070c3ec3d0bf0  mov [r15+0x58], r11
000070c3ec3d0bf4  lea r14, [rax+0x18]
000070c3ec3d0bf8  mov r11d, [r13+r14*1]
000070c3ec3d0bfd  lea r14, [rax+0x1C]
000070c3ec3d0c01  mov r10d, [r13+r14*1]
000070c3ec3d0c06  mov [rsp+0x20], r10d
000070c3ec3d0c0b  mov r10d, r10d
000070c3ec3d0c0e  mov [r15+0x60], r10
000070c3ec3d0c12  mov r14d, 0x430870
000070c3ec3d0c18  mov [r13+r14*1], r12d
000070c3ec3d0c1d  mov r14d, 0x430874
000070c3ec3d0c23  mov r12d, [rsp+0x10]
000070c3ec3d0c28  mov [r13+r14*1], r12d
000070c3ec3d0c2d  bswap r11d
000070c3ec3d0c30  mov [rsp+0x10], r11d
000070c3ec3d0c35  mov r11d, r11d
000070c3ec3d0c38  mov [r15+0x40], r11
000070c3ec3d0c3c  mov r14d, [rsp+0x20]
000070c3ec3d0c41  bswap r14d
000070c3ec3d0c44  mov [rsp+0x20], r14d
000070c3ec3d0c49  mov r14d, r14d
000070c3ec3d0c4c  mov [r15+0x50], r14
000070c3ec3d0c50  mov r14d, 0x430878
000070c3ec3d0c56  mov r12d, [rsp+0x10]
000070c3ec3d0c5b  mov [r13+r14*1], r12d
000070c3ec3d0c60  mov r14d, 0x43087C
000070c3ec3d0c66  mov r12d, [rsp+0x20]
000070c3ec3d0c6b  mov [r13+r14*1], r12d
000070c3ec3d0c70  lea r14, [rax+0xA0]
000070c3ec3d0c77  mov [r15+0xF8], r14
000070c3ec3d0c7e  mov [r15+0x100], r8
000070c3ec3d0c85  jmp 0x000070C3EC3CE5C0
000070c3ec3d0c8a  int3
000070c3ec3d0c8b  call 0x000070C3EC20DAE0
000070c3ec3d0c90  jmp 0x000070C3EC3D0B3C
000070c3ec3d0c95  call 0x000070C3EC2C0230
000070c3ec3d0c9a  jmp 0x000070C3EC3D0B45
000070c3ec3d0c9f  call 0x000070C3EC2BEFC0
000070c3ec3d0ca4  jmp 0x000070C3EC3D0B4E
000070c3ec3d0ca9  call 0x000070C3EC2BDD50
000070c3ec3d0cae  jmp 0x000070C3EC3D0B57
000070c3ec3d0cb3  call 0x000070C3EC2BCC20
000070c3ec3d0cb8  jmp 0x000070C3EC3D0B6B
000070c3ec3d0cbd  call 0x000070C3EC2C3EA0
000070c3ec3d0cc2  jmp 0x000070C3EC3D0B83
000070c3ec3d0cc7  call 0x000070C3EC2E1920
000070c3ec3d0ccc  jmp 0x000070C3EC3D0B8E
000070c3ec3d0cd1  call 0x000070C3EC2E26A0
000070c3ec3d0cd6  jmp 0x000070C3EC3D0B9D
000070c3ec3d0cdb  call 0x000070C3EC2E1430
000070c3ec3d0ce0  jmp 0x000070C3EC3D0BA6
000070c3ec3d0ce5  call 0x000070C3EC2E06B0
000070c3ec3d0cea  jmp 0x000070C3EC3D0BB1
000070c3ec3d0cef  call 0x000070C3EC2DF440
000070c3ec3d0cf4  jmp 0x000070C3EC3D0BBC
000070c3ec3d0cf9  call 0x000070C3EC2E0300
000070c3ec3d0cfe  jmp 0x000070C3EC3D0BC8
000070c3ec3d0d03  call 0x000070C3EC2DF090
000070c3ec3d0d08  jmp 0x000070C3EC3D0BD4
000070c3ec3d0d0d  call 0x000070C3EC2E1430
000070c3ec3d0d12  jmp 0x000070C3EC3D0BFD
000070c3ec3d0d17  call 0x000070C3EC2E01C0
000070c3ec3d0d1c  jmp 0x000070C3EC3D0C06
000070c3ec3d0d21  call 0x000070C3EC2E2BA0
000070c3ec3d0d26  jmp 0x000070C3EC3D0C1D
000070c3ec3d0d2b  call 0x000070C3EC2E2BA0
000070c3ec3d0d30  jmp 0x000070C3EC3D0C2D
000070c3ec3d0d35  call 0x000070C3EC2E2BA0
000070c3ec3d0d3a  jmp 0x000070C3EC3D0C60
000070c3ec3d0d3f  call 0x000070C3EC2E2BA0
000070c3ec3d0d44  jmp 0x000070C3EC3D0C70
000070c3ec3d0d49  int3
000070c3ec3d0d4a  nop [rax+rax*1], ax
000070c3ec3d0d50  mov qword ptr [r15+0x100], 0x04
000070c3ec3d0d5b  mov esi, 0x00
000070c3ec3d0d60  mov edx, 0x09
000070c3ec3d0d65  mov rdi, 0x7FFF7AA24300
000070c3ec3d0d6f  mov rax, 0x61DFB3F19970
000070c3ec3d0d79  call rax
000070c3ec3d0d7b  cmp dword ptr [r15+0x318], 0x00
000070c3ec3d0d83  jnz 0x000070C3EC1FE110
000070c3ec3d0d89  jmp 0x000070C3EC1FE0A0
000070c3ec3d0d8e  int3
000070c3ec3d0d8f  int3
