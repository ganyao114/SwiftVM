
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sha/candidate/0/1.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x50
       4:	mov    r11,QWORD PTR [r12+0x398]
       c:	mov    QWORD PTR [rsp+0x48],r11
      11:	mov    r13,QWORD PTR [r12]
      15:	mov    r14,r13
      18:	add    r14,0x20
      1c:	mov    r15,QWORD PTR [r14]
      1f:	mov    r14,QWORD PTR [r12+0x10]
      24:	mov    rcx,r14
      27:	add    r15,rcx
      2a:	mov    QWORD PTR [r12+0x40],r15
      2f:	add    r13,0x20
      33:	mov    QWORD PTR [r13+0x0],r15
      37:	mov    r13d,0x0
      3d:	mov    DWORD PTR [r12+0x32c],r13d
      45:	mov    rax,r14
      48:	test   rax,rax
      4b:	sete   al
      4e:	movzx  eax,al
      51:	and    eax,0x1
      54:	mov    r13,rax
      57:	mov    rax,r13
      5a:	and    eax,0x1
      5d:	test   rax,rax
      60:	jne    0x27da
      66:	jmp    0x6b
      6b:	mov    r13,QWORD PTR [r12+0xf8]
      73:	sub    r13,0x150
      7a:	mov    QWORD PTR [r12+0xf8],r13
      82:	mov    r14,QWORD PTR [r12]
      86:	mov    r15,r14
      89:	add    r15,0x68
      8d:	mov    rbp,QWORD PTR [r15]
      90:	mov    QWORD PTR [r12+0x88],rbp
      98:	add    r14,0x28
      9c:	mov    QWORD PTR [r12+0x40],r14
      a1:	mov    r14,r13
      a4:	add    r14,0x0
      a8:	mov    QWORD PTR [r12+0x48],r14
      ad:	mov    r14d,0x420000
      b3:	add    r14,0x758
      ba:	mov    QWORD PTR [r12+0x50],r14
      bf:	add    r13,0x100
      c6:	mov    r14,r13
      c9:	add    r14,0x8
      cd:	mov    r15,QWORD PTR [r12+0xe8]
      d5:	mov    rbp,QWORD PTR [r12+0xd8]
      dd:	mov    QWORD PTR [r13+0x0],r15
      e1:	mov    r13d,0x0
      e7:	mov    DWORD PTR [r12+0x32c],r13d
      ef:	mov    QWORD PTR [r14],rbp
      f2:	mov    r13d,0x0
      f8:	mov    DWORD PTR [r12+0x32c],r13d
     100:	mov    r13,QWORD PTR [r12+0xf8]
     108:	mov    r14,r13
     10b:	add    r14,0x110
     112:	mov    r15,r14
     115:	add    r15,0x8
     119:	mov    rbp,QWORD PTR [r12+0xd0]
     121:	mov    r8,QWORD PTR [r12+0xc8]
     129:	mov    QWORD PTR [r14],rbp
     12c:	mov    r14d,0x0
     132:	mov    DWORD PTR [r12+0x32c],r14d
     13a:	mov    QWORD PTR [r15],r8
     13d:	mov    r14d,0x0
     143:	mov    DWORD PTR [r12+0x32c],r14d
     14b:	mov    r14,r13
     14e:	add    r14,0x120
     155:	mov    r15,r14
     158:	add    r15,0x8
     15c:	mov    rbp,QWORD PTR [r12+0xc0]
     164:	mov    r8,QWORD PTR [r12+0xb8]
     16c:	mov    QWORD PTR [r14],rbp
     16f:	mov    r14d,0x0
     175:	mov    DWORD PTR [r12+0x32c],r14d
     17d:	mov    QWORD PTR [r15],r8
     180:	mov    r14d,0x0
     186:	mov    DWORD PTR [r12+0x32c],r14d
     18e:	mov    r14,r13
     191:	add    r14,0x130
     198:	mov    r15,r14
     19b:	add    r15,0x8
     19f:	mov    rbp,QWORD PTR [r12+0xb0]
     1a7:	mov    r8,QWORD PTR [r12+0xa8]
     1af:	mov    QWORD PTR [r14],rbp
     1b2:	mov    r14d,0x0
     1b8:	mov    DWORD PTR [r12+0x32c],r14d
     1c0:	mov    QWORD PTR [r15],r8
     1c3:	mov    r14d,0x0
     1c9:	mov    DWORD PTR [r12+0x32c],r14d
     1d1:	add    r13,0x140
     1d8:	mov    r14,r13
     1db:	add    r14,0x8
     1df:	mov    r15,QWORD PTR [r12+0xa0]
     1e7:	mov    rbp,QWORD PTR [r12+0x98]
     1ef:	mov    QWORD PTR [r13+0x0],r15
     1f3:	mov    r13d,0x0
     1f9:	mov    DWORD PTR [r12+0x32c],r13d
     201:	mov    QWORD PTR [r14],rbp
     204:	mov    r13d,0x0
     20a:	mov    DWORD PTR [r12+0x32c],r13d
     212:	jmp    0x217
     217:	mov    r13,QWORD PTR [r12+0x8]
     21c:	mov    r14,r13
     21f:	add    r14,0x1
     223:	movzx  r15d,BYTE PTR [r13+0x0]
     228:	mov    QWORD PTR [r12+0x58],r15
     22d:	mov    QWORD PTR [r12+0x8],r14
     232:	mov    r13,QWORD PTR [r12+0x88]
     23a:	mov    r14,r13
     23d:	add    r14,0x1
     241:	mov    QWORD PTR [r12+0x60],r14
     246:	mov    r15,QWORD PTR [r12]
     24a:	mov    rbp,r15
     24d:	add    rbp,0x68
     251:	mov    QWORD PTR [rbp+0x0],r14
     255:	mov    r14d,0x0
     25b:	mov    DWORD PTR [r12+0x32c],r14d
     263:	mov    rcx,r13
     266:	mov    r14,r15
     269:	add    r14,rcx
     26c:	mov    QWORD PTR [r12+0x60],r14
     271:	add    r14,0x28
     275:	movzx  r13d,BYTE PTR [r12+0x58]
     27b:	mov    BYTE PTR [r14],r13b
     27e:	mov    r13d,0x0
     284:	mov    DWORD PTR [r12+0x32c],r13d
     28c:	add    r15,0x68
     290:	mov    r13,QWORD PTR [r15]
     293:	mov    QWORD PTR [r12+0x88],r13
     29b:	sub    r13,0x40
     29f:	mov    rcx,QWORD PTR [r12+0x380]
     2a7:	jrcxz  0x2ae
     2a9:	jmp    0x281f
     2ae:	pushf
     2af:	pop    r11
     2b1:	mov    QWORD PTR [rsp+0x48],r11
     2b6:	jne    0x26c1
     2bc:	jmp    0x2c1
     2c1:	mov    rax,QWORD PTR [r12+0x40]
     2c6:	mov    QWORD PTR [rsp],rax
     2ca:	mov    eax,0x0
     2cf:	mov    QWORD PTR [rsp+0x20],rax
     2d4:	mov    eax,0x0
     2d9:	mov    QWORD PTR [rsp+0x18],rax
     2de:	mov    eax,0x0
     2e3:	mov    QWORD PTR [rsp+0x10],rax
     2e8:	mov    eax,0x0
     2ed:	mov    QWORD PTR [rsp+0x8],rax
     2f2:	mov    rdi,QWORD PTR [rsp]
     2f6:	movzx  r9d,BYTE PTR [rdi]
     2fa:	mov    r13,r9
     2fd:	mov    rcx,r13
     300:	mov    r9,QWORD PTR [rsp+0x20]
     305:	or     r9,rcx
     308:	mov    r13,QWORD PTR [rsp]
     30c:	add    r13,0x1
     310:	movzx  r8d,BYTE PTR [r13+0x0]
     315:	mov    r13,r8
     318:	mov    rcx,r13
     31b:	mov    r8,QWORD PTR [rsp+0x18]
     320:	or     r8,rcx
     323:	mov    r13,QWORD PTR [rsp]
     327:	add    r13,0x2
     32b:	movzx  ebp,BYTE PTR [r13+0x0]
     330:	mov    r13,rbp
     333:	mov    rcx,r13
     336:	mov    rbp,QWORD PTR [rsp+0x10]
     33b:	or     rbp,rcx
     33e:	mov    r13,QWORD PTR [rsp]
     342:	add    r13,0x3
     346:	movzx  r15d,BYTE PTR [r13+0x0]
     34b:	mov    r13,r15
     34e:	mov    rcx,r13
     351:	mov    r15,QWORD PTR [rsp+0x8]
     356:	or     r15,rcx
     359:	mov    r13,QWORD PTR [rsp]
     35d:	add    r13,0x4
     361:	movzx  r14d,BYTE PTR [r13+0x0]
     366:	mov    r13,r14
     369:	shl    r13,0x8
     36d:	mov    rcx,r13
     370:	or     r9,rcx
     373:	mov    r13,QWORD PTR [rsp]
     377:	add    r13,0x5
     37b:	movzx  r14d,BYTE PTR [r13+0x0]
     380:	mov    r13,r14
     383:	shl    r13,0x8
     387:	mov    rcx,r13
     38a:	or     r8,rcx
     38d:	mov    r13,QWORD PTR [rsp]
     391:	add    r13,0x6
     395:	movzx  r14d,BYTE PTR [r13+0x0]
     39a:	mov    r13,r14
     39d:	shl    r13,0x8
     3a1:	mov    rcx,r13
     3a4:	or     rbp,rcx
     3a7:	mov    r13,QWORD PTR [rsp]
     3ab:	add    r13,0x7
     3af:	movzx  r14d,BYTE PTR [r13+0x0]
     3b4:	mov    r13,r14
     3b7:	shl    r13,0x8
     3bb:	mov    rcx,r13
     3be:	or     r15,rcx
     3c1:	mov    r13,QWORD PTR [rsp]
     3c5:	add    r13,0x8
     3c9:	movzx  r14d,BYTE PTR [r13+0x0]
     3ce:	mov    r13,r14
     3d1:	shl    r13,0x10
     3d5:	mov    rcx,r13
     3d8:	or     r9,rcx
     3db:	mov    r13,QWORD PTR [rsp]
     3df:	add    r13,0x9
     3e3:	movzx  r14d,BYTE PTR [r13+0x0]
     3e8:	mov    r13,r14
     3eb:	shl    r13,0x10
     3ef:	mov    rcx,r13
     3f2:	or     r8,rcx
     3f5:	mov    r13,QWORD PTR [rsp]
     3f9:	add    r13,0xa
     3fd:	movzx  r14d,BYTE PTR [r13+0x0]
     402:	mov    r13,r14
     405:	shl    r13,0x10
     409:	mov    rcx,r13
     40c:	or     rbp,rcx
     40f:	mov    r13,QWORD PTR [rsp]
     413:	add    r13,0xb
     417:	movzx  r14d,BYTE PTR [r13+0x0]
     41c:	mov    r13,r14
     41f:	shl    r13,0x10
     423:	mov    rcx,r13
     426:	or     r15,rcx
     429:	mov    r13,QWORD PTR [rsp]
     42d:	add    r13,0xc
     431:	movzx  r14d,BYTE PTR [r13+0x0]
     436:	mov    r13,r14
     439:	shl    r13,0x18
     43d:	mov    rcx,r13
     440:	or     r9,rcx
     443:	mov    r13,QWORD PTR [rsp]
     447:	add    r13,0xd
     44b:	movzx  r14d,BYTE PTR [r13+0x0]
     450:	mov    r13,r14
     453:	shl    r13,0x18
     457:	mov    rcx,r13
     45a:	or     r8,rcx
     45d:	mov    r13,QWORD PTR [rsp]
     461:	add    r13,0xe
     465:	movzx  r14d,BYTE PTR [r13+0x0]
     46a:	mov    r13,r14
     46d:	shl    r13,0x18
     471:	mov    rcx,r13
     474:	or     rbp,rcx
     477:	mov    r13,QWORD PTR [rsp]
     47b:	add    r13,0xf
     47f:	movzx  r14d,BYTE PTR [r13+0x0]
     484:	mov    r13,r14
     487:	shl    r13,0x18
     48b:	mov    rcx,r13
     48e:	or     r15,rcx
     491:	mov    r13,QWORD PTR [rsp]
     495:	add    r13,0x10
     499:	movzx  r14d,BYTE PTR [r13+0x0]
     49e:	mov    r13,r14
     4a1:	shl    r13,0x20
     4a5:	mov    rcx,r13
     4a8:	or     r9,rcx
     4ab:	mov    r13,QWORD PTR [rsp]
     4af:	add    r13,0x11
     4b3:	movzx  r14d,BYTE PTR [r13+0x0]
     4b8:	mov    r13,r14
     4bb:	shl    r13,0x20
     4bf:	mov    rcx,r13
     4c2:	or     r8,rcx
     4c5:	mov    r13,QWORD PTR [rsp]
     4c9:	add    r13,0x12
     4cd:	movzx  r14d,BYTE PTR [r13+0x0]
     4d2:	mov    r13,r14
     4d5:	shl    r13,0x20
     4d9:	mov    rcx,r13
     4dc:	or     rbp,rcx
     4df:	mov    r13,QWORD PTR [rsp]
     4e3:	add    r13,0x13
     4e7:	movzx  r14d,BYTE PTR [r13+0x0]
     4ec:	mov    r13,r14
     4ef:	shl    r13,0x20
     4f3:	mov    rcx,r13
     4f6:	or     r15,rcx
     4f9:	mov    r13,QWORD PTR [rsp]
     4fd:	add    r13,0x14
     501:	movzx  r14d,BYTE PTR [r13+0x0]
     506:	mov    r13,r14
     509:	shl    r13,0x28
     50d:	mov    rcx,r13
     510:	or     r9,rcx
     513:	mov    r13,QWORD PTR [rsp]
     517:	add    r13,0x15
     51b:	movzx  r14d,BYTE PTR [r13+0x0]
     520:	mov    r13,r14
     523:	shl    r13,0x28
     527:	mov    rcx,r13
     52a:	or     r8,rcx
     52d:	mov    r13,QWORD PTR [rsp]
     531:	add    r13,0x16
     535:	movzx  r14d,BYTE PTR [r13+0x0]
     53a:	mov    r13,r14
     53d:	shl    r13,0x28
     541:	mov    rcx,r13
     544:	or     rbp,rcx
     547:	mov    r13,QWORD PTR [rsp]
     54b:	add    r13,0x17
     54f:	movzx  r14d,BYTE PTR [r13+0x0]
     554:	mov    r13,r14
     557:	shl    r13,0x28
     55b:	mov    rcx,r13
     55e:	or     r15,rcx
     561:	mov    r13,QWORD PTR [rsp]
     565:	add    r13,0x18
     569:	movzx  r14d,BYTE PTR [r13+0x0]
     56e:	mov    r13,r14
     571:	shl    r13,0x30
     575:	mov    rcx,r13
     578:	or     r9,rcx
     57b:	mov    r13,QWORD PTR [rsp]
     57f:	add    r13,0x19
     583:	movzx  r14d,BYTE PTR [r13+0x0]
     588:	mov    r13,r14
     58b:	shl    r13,0x30
     58f:	mov    rcx,r13
     592:	or     r8,rcx
     595:	mov    r13,QWORD PTR [rsp]
     599:	add    r13,0x1a
     59d:	movzx  r14d,BYTE PTR [r13+0x0]
     5a2:	mov    r13,r14
     5a5:	shl    r13,0x30
     5a9:	mov    rcx,r13
     5ac:	or     rbp,rcx
     5af:	mov    r13,QWORD PTR [rsp]
     5b3:	add    r13,0x1b
     5b7:	movzx  r14d,BYTE PTR [r13+0x0]
     5bc:	mov    r13,r14
     5bf:	shl    r13,0x30
     5c3:	mov    rcx,r13
     5c6:	or     r15,rcx
     5c9:	mov    r13,QWORD PTR [rsp]
     5cd:	add    r13,0x1c
     5d1:	movzx  r14d,BYTE PTR [r13+0x0]
     5d6:	mov    r13,r14
     5d9:	shl    r13,0x38
     5dd:	mov    rcx,r13
     5e0:	mov    rax,r9
     5e3:	or     rax,rcx
     5e6:	mov    QWORD PTR [rsp+0x40],rax
     5eb:	mov    r13,QWORD PTR [rsp]
     5ef:	add    r13,0x1d
     5f3:	movzx  r14d,BYTE PTR [r13+0x0]
     5f8:	mov    r13,r14
     5fb:	shl    r13,0x38
     5ff:	mov    rcx,r13
     602:	mov    rax,r8
     605:	or     rax,rcx
     608:	mov    QWORD PTR [rsp+0x30],rax
     60d:	mov    r13,QWORD PTR [rsp]
     611:	add    r13,0x1e
     615:	movzx  r14d,BYTE PTR [r13+0x0]
     61a:	mov    r13,r14
     61d:	shl    r13,0x38
     621:	mov    rcx,r13
     624:	mov    rax,rbp
     627:	or     rax,rcx
     62a:	mov    QWORD PTR [rsp+0x28],rax
     62f:	mov    r13,QWORD PTR [rsp]
     633:	add    r13,0x1f
     637:	movzx  r14d,BYTE PTR [r13+0x0]
     63c:	mov    r13,r14
     63f:	shl    r13,0x38
     643:	mov    rcx,r13
     646:	mov    rax,r15
     649:	or     rax,rcx
     64c:	mov    QWORD PTR [rsp+0x38],rax
     651:	mov    r13,QWORD PTR [rsp]
     655:	add    r13,0x20
     659:	movzx  r14d,BYTE PTR [r13+0x0]
     65e:	mov    r13,r14
     661:	mov    rcx,r13
     664:	mov    r14,QWORD PTR [rsp+0x20]
     669:	or     r14,rcx
     66c:	mov    r13,QWORD PTR [rsp]
     670:	add    r13,0x21
     674:	movzx  ebp,BYTE PTR [r13+0x0]
     679:	mov    r13,rbp
     67c:	mov    rcx,r13
     67f:	mov    rbp,QWORD PTR [rsp+0x18]
     684:	or     rbp,rcx
     687:	mov    r13,QWORD PTR [rsp]
     68b:	add    r13,0x22
     68f:	movzx  r8d,BYTE PTR [r13+0x0]
     694:	mov    r13,r8
     697:	mov    rcx,r13
     69a:	mov    r8,QWORD PTR [rsp+0x10]
     69f:	or     r8,rcx
     6a2:	mov    r13,QWORD PTR [rsp]
     6a6:	add    r13,0x23
     6aa:	movzx  r15d,BYTE PTR [r13+0x0]
     6af:	mov    r13,r15
     6b2:	mov    rcx,r13
     6b5:	mov    r15,QWORD PTR [rsp+0x8]
     6ba:	or     r15,rcx
     6bd:	mov    r13,QWORD PTR [rsp]
     6c1:	add    r13,0x24
     6c5:	movzx  r9d,BYTE PTR [r13+0x0]
     6ca:	mov    r13,r9
     6cd:	shl    r13,0x8
     6d1:	mov    rcx,r13
     6d4:	or     r14,rcx
     6d7:	mov    r13,QWORD PTR [rsp]
     6db:	add    r13,0x25
     6df:	movzx  r9d,BYTE PTR [r13+0x0]
     6e4:	mov    r13,r9
     6e7:	shl    r13,0x8
     6eb:	mov    rcx,r13
     6ee:	or     rbp,rcx
     6f1:	mov    r13,QWORD PTR [rsp]
     6f5:	add    r13,0x26
     6f9:	movzx  r9d,BYTE PTR [r13+0x0]
     6fe:	mov    r13,r9
     701:	shl    r13,0x8
     705:	mov    rcx,r13
     708:	or     r8,rcx
     70b:	mov    r13,QWORD PTR [rsp]
     70f:	add    r13,0x27
     713:	movzx  r9d,BYTE PTR [r13+0x0]
     718:	mov    r13,r9
     71b:	shl    r13,0x8
     71f:	mov    rcx,r13
     722:	or     r15,rcx
     725:	mov    r13,QWORD PTR [rsp]
     729:	add    r13,0x28
     72d:	movzx  r9d,BYTE PTR [r13+0x0]
     732:	mov    r13,r9
     735:	shl    r13,0x10
     739:	mov    rcx,r13
     73c:	or     r14,rcx
     73f:	mov    r13,QWORD PTR [rsp]
     743:	add    r13,0x29
     747:	movzx  r9d,BYTE PTR [r13+0x0]
     74c:	mov    r13,r9
     74f:	shl    r13,0x10
     753:	mov    rcx,r13
     756:	or     rbp,rcx
     759:	mov    r13,QWORD PTR [rsp]
     75d:	add    r13,0x2a
     761:	movzx  r9d,BYTE PTR [r13+0x0]
     766:	mov    r13,r9
     769:	shl    r13,0x10
     76d:	mov    rcx,r13
     770:	or     r8,rcx
     773:	mov    r13,QWORD PTR [rsp]
     777:	add    r13,0x2b
     77b:	movzx  r9d,BYTE PTR [r13+0x0]
     780:	mov    r13,r9
     783:	shl    r13,0x10
     787:	mov    rcx,r13
     78a:	or     r15,rcx
     78d:	mov    r13,QWORD PTR [rsp]
     791:	add    r13,0x2c
     795:	movzx  r9d,BYTE PTR [r13+0x0]
     79a:	mov    r13,r9
     79d:	shl    r13,0x18
     7a1:	mov    rcx,r13
     7a4:	or     r14,rcx
     7a7:	mov    r13,QWORD PTR [rsp]
     7ab:	add    r13,0x2d
     7af:	movzx  r9d,BYTE PTR [r13+0x0]
     7b4:	mov    r13,r9
     7b7:	shl    r13,0x18
     7bb:	mov    rcx,r13
     7be:	or     rbp,rcx
     7c1:	mov    r13,QWORD PTR [rsp]
     7c5:	add    r13,0x2e
     7c9:	movzx  r9d,BYTE PTR [r13+0x0]
     7ce:	mov    r13,r9
     7d1:	shl    r13,0x18
     7d5:	mov    rcx,r13
     7d8:	or     r8,rcx
     7db:	mov    r13,QWORD PTR [rsp]
     7df:	add    r13,0x2f
     7e3:	movzx  r9d,BYTE PTR [r13+0x0]
     7e8:	mov    r13,r9
     7eb:	shl    r13,0x18
     7ef:	mov    rcx,r13
     7f2:	or     r15,rcx
     7f5:	mov    r13,QWORD PTR [rsp]
     7f9:	add    r13,0x30
     7fd:	movzx  r9d,BYTE PTR [r13+0x0]
     802:	mov    r13,r9
     805:	shl    r13,0x20
     809:	mov    rcx,r13
     80c:	or     r14,rcx
     80f:	mov    r13,QWORD PTR [rsp]
     813:	add    r13,0x31
     817:	movzx  r9d,BYTE PTR [r13+0x0]
     81c:	mov    r13,r9
     81f:	shl    r13,0x20
     823:	mov    rcx,r13
     826:	or     rbp,rcx
     829:	mov    r13,QWORD PTR [rsp]
     82d:	add    r13,0x32
     831:	movzx  r9d,BYTE PTR [r13+0x0]
     836:	mov    r13,r9
     839:	shl    r13,0x20
     83d:	mov    rcx,r13
     840:	or     r8,rcx
     843:	mov    r13,QWORD PTR [rsp]
     847:	add    r13,0x33
     84b:	movzx  r9d,BYTE PTR [r13+0x0]
     850:	mov    r13,r9
     853:	shl    r13,0x20
     857:	mov    rcx,r13
     85a:	or     r15,rcx
     85d:	mov    r13,QWORD PTR [rsp]
     861:	add    r13,0x34
     865:	movzx  r9d,BYTE PTR [r13+0x0]
     86a:	mov    r13,r9
     86d:	shl    r13,0x28
     871:	mov    rcx,r13
     874:	or     r14,rcx
     877:	mov    r13,QWORD PTR [rsp]
     87b:	add    r13,0x35
     87f:	movzx  r9d,BYTE PTR [r13+0x0]
     884:	mov    r13,r9
     887:	shl    r13,0x28
     88b:	mov    rcx,r13
     88e:	or     rbp,rcx
     891:	mov    r13,QWORD PTR [rsp]
     895:	add    r13,0x36
     899:	movzx  r9d,BYTE PTR [r13+0x0]
     89e:	mov    r13,r9
     8a1:	shl    r13,0x28
     8a5:	mov    rcx,r13
     8a8:	or     r8,rcx
     8ab:	mov    r13,QWORD PTR [rsp]
     8af:	add    r13,0x37
     8b3:	movzx  r9d,BYTE PTR [r13+0x0]
     8b8:	mov    r13,r9
     8bb:	shl    r13,0x28
     8bf:	mov    rcx,r13
     8c2:	or     r15,rcx
     8c5:	mov    r13,QWORD PTR [rsp]
     8c9:	add    r13,0x38
     8cd:	movzx  r9d,BYTE PTR [r13+0x0]
     8d2:	mov    r13,r9
     8d5:	shl    r13,0x30
     8d9:	mov    rcx,r13
     8dc:	or     r14,rcx
     8df:	mov    r13,QWORD PTR [rsp]
     8e3:	add    r13,0x39
     8e7:	movzx  r9d,BYTE PTR [r13+0x0]
     8ec:	mov    r13,r9
     8ef:	shl    r13,0x30
     8f3:	mov    rcx,r13
     8f6:	or     rbp,rcx
     8f9:	mov    r13,QWORD PTR [rsp]
     8fd:	add    r13,0x3a
     901:	movzx  r9d,BYTE PTR [r13+0x0]
     906:	mov    r13,r9
     909:	shl    r13,0x30
     90d:	mov    rcx,r13
     910:	or     r8,rcx
     913:	mov    r13,QWORD PTR [rsp]
     917:	add    r13,0x3b
     91b:	movzx  r9d,BYTE PTR [r13+0x0]
     920:	mov    r13,r9
     923:	shl    r13,0x30
     927:	mov    rcx,r13
     92a:	or     r15,rcx
     92d:	mov    r13,QWORD PTR [rsp]
     931:	add    r13,0x3c
     935:	movzx  r9d,BYTE PTR [r13+0x0]
     93a:	mov    r13,r9
     93d:	shl    r13,0x38
     941:	mov    rcx,r13
     944:	or     r14,rcx
     947:	mov    r13,QWORD PTR [rsp]
     94b:	add    r13,0x3d
     94f:	movzx  r9d,BYTE PTR [r13+0x0]
     954:	mov    r13,r9
     957:	shl    r13,0x38
     95b:	mov    rcx,r13
     95e:	or     rbp,rcx
     961:	mov    r13,QWORD PTR [rsp]
     965:	add    r13,0x3e
     969:	movzx  r9d,BYTE PTR [r13+0x0]
     96e:	mov    r13,r9
     971:	shl    r13,0x38
     975:	mov    rcx,r13
     978:	or     r8,rcx
     97b:	mov    r13,QWORD PTR [rsp]
     97f:	add    r13,0x3f
     983:	movzx  r9d,BYTE PTR [r13+0x0]
     988:	mov    r13,r9
     98b:	shl    r13,0x38
     98f:	mov    rcx,r13
     992:	or     r15,rcx
     995:	mov    rax,QWORD PTR [rsp+0x40]
     99a:	mov    QWORD PTR [r12+0x110],rax
     9a2:	mov    QWORD PTR [r12+0x118],r14
     9aa:	mov    rax,QWORD PTR [rsp+0x30]
     9af:	mov    QWORD PTR [r12+0x120],rax
     9b7:	mov    QWORD PTR [r12+0x128],rbp
     9bf:	mov    rax,QWORD PTR [rsp+0x28]
     9c4:	mov    QWORD PTR [r12+0x130],rax
     9cc:	mov    QWORD PTR [r12+0x138],r8
     9d4:	mov    rax,QWORD PTR [rsp+0x38]
     9d9:	mov    QWORD PTR [r12+0x140],rax
     9e1:	mov    QWORD PTR [r12+0x148],r15
     9e9:	mov    r13d,0x0
     9ef:	mov    QWORD PTR [r12+0x58],r13
     9f4:	mov    r13d,0x0
     9fa:	mov    r14,QWORD PTR [rsp+0x30]
     9ff:	and    r14,0xff
     a06:	and    r14,0xffff
     a0d:	mov    rcx,r14
     a10:	mov    r15,r13
     a13:	or     r15,rcx
     a16:	mov    r14,QWORD PTR [rsp+0x30]
     a1b:	shr    r14,0x8
     a1f:	and    r14,0xff
     a26:	and    r14,0xffff
     a2d:	shl    r14,0x10
     a31:	mov    rcx,r14
     a34:	or     r15,rcx
     a37:	mov    r14,QWORD PTR [rsp+0x30]
     a3c:	shr    r14,0x10
     a40:	and    r14,0xff
     a47:	and    r14,0xffff
     a4e:	shl    r14,0x20
     a52:	mov    rcx,r14
     a55:	or     r15,rcx
     a58:	mov    r14,QWORD PTR [rsp+0x30]
     a5d:	shr    r14,0x18
     a61:	and    r14,0xff
     a68:	and    r14,0xffff
     a6f:	shl    r14,0x30
     a73:	mov    rcx,r14
     a76:	or     r15,rcx
     a79:	mov    r14,QWORD PTR [rsp+0x30]
     a7e:	shr    r14,0x20
     a82:	and    r14,0xff
     a89:	and    r14,0xffff
     a90:	mov    rcx,r14
     a93:	or     r13,rcx
     a96:	mov    r14,QWORD PTR [rsp+0x30]
     a9b:	shr    r14,0x28
     a9f:	and    r14,0xff
     aa6:	and    r14,0xffff
     aad:	shl    r14,0x10
     ab1:	mov    rcx,r14
     ab4:	or     r13,rcx
     ab7:	mov    r14,QWORD PTR [rsp+0x30]
     abc:	shr    r14,0x30
     ac0:	and    r14,0xff
     ac7:	and    r14,0xffff
     ace:	shl    r14,0x20
     ad2:	mov    rcx,r14
     ad5:	or     r13,rcx
     ad8:	mov    r14,QWORD PTR [rsp+0x30]
     add:	shr    r14,0x38
     ae1:	and    r14,0xff
     ae8:	and    r14,0xffff
     aef:	shl    r14,0x30
     af3:	mov    rcx,r14
     af6:	or     r13,rcx
     af9:	mov    QWORD PTR [r12+0x150],r15
     b01:	mov    QWORD PTR [r12+0x158],r13
     b09:	mov    r13d,0x0
     b0f:	mov    r14,QWORD PTR [rsp+0x28]
     b14:	and    r14,0xff
     b1b:	and    r14,0xffff
     b22:	mov    rcx,r14
     b25:	mov    r15,r13
     b28:	or     r15,rcx
     b2b:	mov    r14,QWORD PTR [rsp+0x28]
     b30:	shr    r14,0x8
     b34:	and    r14,0xff
     b3b:	and    r14,0xffff
     b42:	shl    r14,0x10
     b46:	mov    rcx,r14
     b49:	or     r15,rcx
     b4c:	mov    r14,QWORD PTR [rsp+0x28]
     b51:	shr    r14,0x10
     b55:	and    r14,0xff
     b5c:	and    r14,0xffff
     b63:	shl    r14,0x20
     b67:	mov    rcx,r14
     b6a:	or     r15,rcx
     b6d:	mov    r14,QWORD PTR [rsp+0x28]
     b72:	shr    r14,0x18
     b76:	and    r14,0xff
     b7d:	and    r14,0xffff
     b84:	shl    r14,0x30
     b88:	mov    rcx,r14
     b8b:	or     r15,rcx
     b8e:	mov    r14,QWORD PTR [rsp+0x28]
     b93:	shr    r14,0x20
     b97:	and    r14,0xff
     b9e:	and    r14,0xffff
     ba5:	mov    rcx,r14
     ba8:	or     r13,rcx
     bab:	mov    r14,QWORD PTR [rsp+0x28]
     bb0:	shr    r14,0x28
     bb4:	and    r14,0xff
     bbb:	and    r14,0xffff
     bc2:	shl    r14,0x10
     bc6:	mov    rcx,r14
     bc9:	or     r13,rcx
     bcc:	mov    r14,QWORD PTR [rsp+0x28]
     bd1:	shr    r14,0x30
     bd5:	and    r14,0xff
     bdc:	and    r14,0xffff
     be3:	shl    r14,0x20
     be7:	mov    rcx,r14
     bea:	or     r13,rcx
     bed:	mov    r14,QWORD PTR [rsp+0x28]
     bf2:	shr    r14,0x38
     bf6:	and    r14,0xff
     bfd:	and    r14,0xffff
     c04:	shl    r14,0x30
     c08:	mov    rcx,r14
     c0b:	or     r13,rcx
     c0e:	mov    QWORD PTR [r12+0x160],r15
     c16:	mov    QWORD PTR [r12+0x168],r13
     c1e:	mov    r13,QWORD PTR [r12+0x110]
     c26:	mov    r14d,0x0
     c2c:	mov    r15,r13
     c2f:	and    r15,0xff
     c36:	and    r15,0xffff
     c3d:	mov    rcx,r15
     c40:	mov    rbp,r14
     c43:	or     rbp,rcx
     c46:	mov    r15,r13
     c49:	shr    r15,0x8
     c4d:	and    r15,0xff
     c54:	and    r15,0xffff
     c5b:	shl    r15,0x10
     c5f:	mov    rcx,r15
     c62:	or     rbp,rcx
     c65:	mov    r15,r13
     c68:	shr    r15,0x10
     c6c:	and    r15,0xff
     c73:	and    r15,0xffff
     c7a:	shl    r15,0x20
     c7e:	mov    rcx,r15
     c81:	or     rbp,rcx
     c84:	mov    r15,r13
     c87:	shr    r15,0x18
     c8b:	and    r15,0xff
     c92:	and    r15,0xffff
     c99:	shl    r15,0x30
     c9d:	mov    rcx,r15
     ca0:	or     rbp,rcx
     ca3:	mov    r15,r13
     ca6:	shr    r15,0x20
     caa:	and    r15,0xff
     cb1:	and    r15,0xffff
     cb8:	mov    rcx,r15
     cbb:	or     r14,rcx
     cbe:	mov    r15,r13
     cc1:	shr    r15,0x28
     cc5:	and    r15,0xff
     ccc:	and    r15,0xffff
     cd3:	shl    r15,0x10
     cd7:	mov    rcx,r15
     cda:	or     r14,rcx
     cdd:	mov    r15,r13
     ce0:	shr    r15,0x30
     ce4:	and    r15,0xff
     ceb:	and    r15,0xffff
     cf2:	shl    r15,0x20
     cf6:	mov    rcx,r15
     cf9:	or     r14,rcx
     cfc:	shr    r13,0x38
     d00:	and    r13,0xff
     d07:	and    r13,0xffff
     d0e:	shl    r13,0x30
     d12:	mov    rcx,r13
     d15:	or     r14,rcx
     d18:	mov    QWORD PTR [r12+0x170],rbp
     d20:	mov    QWORD PTR [r12+0x178],r14
     d28:	mov    r13,QWORD PTR [r12+0x118]
     d30:	mov    r14d,0x0
     d36:	mov    r15,r13
     d39:	and    r15,0xff
     d40:	and    r15,0xffff
     d47:	mov    rcx,r15
     d4a:	mov    rbp,r14
     d4d:	or     rbp,rcx
     d50:	mov    r15,r13
     d53:	shr    r15,0x8
     d57:	and    r15,0xff
     d5e:	and    r15,0xffff
     d65:	shl    r15,0x10
     d69:	mov    rcx,r15
     d6c:	or     rbp,rcx
     d6f:	mov    r15,r13
     d72:	shr    r15,0x10
     d76:	and    r15,0xff
     d7d:	and    r15,0xffff
     d84:	shl    r15,0x20
     d88:	mov    rcx,r15
     d8b:	or     rbp,rcx
     d8e:	mov    r15,r13
     d91:	shr    r15,0x18
     d95:	and    r15,0xff
     d9c:	and    r15,0xffff
     da3:	shl    r15,0x30
     da7:	mov    rcx,r15
     daa:	or     rbp,rcx
     dad:	mov    r15,r13
     db0:	shr    r15,0x20
     db4:	and    r15,0xff
     dbb:	and    r15,0xffff
     dc2:	mov    rcx,r15
     dc5:	or     r14,rcx
     dc8:	mov    r15,r13
     dcb:	shr    r15,0x28
     dcf:	and    r15,0xff
     dd6:	and    r15,0xffff
     ddd:	shl    r15,0x10
     de1:	mov    rcx,r15
     de4:	or     r14,rcx
     de7:	mov    r15,r13
     dea:	shr    r15,0x30
     dee:	and    r15,0xff
     df5:	and    r15,0xffff
     dfc:	shl    r15,0x20
     e00:	mov    rcx,r15
     e03:	or     r14,rcx
     e06:	shr    r13,0x38
     e0a:	and    r13,0xff
     e11:	and    r13,0xffff
     e18:	shl    r13,0x30
     e1c:	mov    rcx,r13
     e1f:	or     r14,rcx
     e22:	mov    QWORD PTR [r12+0x180],rbp
     e2a:	mov    QWORD PTR [r12+0x188],r14
     e32:	mov    r13,QWORD PTR [r12+0x128]
     e3a:	mov    r14d,0x0
     e40:	mov    r15,r13
     e43:	and    r15,0xff
     e4a:	and    r15,0xffff
     e51:	mov    rcx,r15
     e54:	mov    rbp,r14
     e57:	or     rbp,rcx
     e5a:	mov    r15,r13
     e5d:	shr    r15,0x8
     e61:	and    r15,0xff
     e68:	and    r15,0xffff
     e6f:	shl    r15,0x10
     e73:	mov    rcx,r15
     e76:	or     rbp,rcx
     e79:	mov    r15,r13
     e7c:	shr    r15,0x10
     e80:	and    r15,0xff
     e87:	and    r15,0xffff
     e8e:	shl    r15,0x20
     e92:	mov    rcx,r15
     e95:	or     rbp,rcx
     e98:	mov    r15,r13
     e9b:	shr    r15,0x18
     e9f:	and    r15,0xff
     ea6:	and    r15,0xffff
     ead:	shl    r15,0x30
     eb1:	mov    rcx,r15
     eb4:	or     rbp,rcx
     eb7:	mov    r15,r13
     eba:	shr    r15,0x20
     ebe:	and    r15,0xff
     ec5:	and    r15,0xffff
     ecc:	mov    rcx,r15
     ecf:	or     r14,rcx
     ed2:	mov    r15,r13
     ed5:	shr    r15,0x28
     ed9:	and    r15,0xff
     ee0:	and    r15,0xffff
     ee7:	shl    r15,0x10
     eeb:	mov    rcx,r15
     eee:	or     r14,rcx
     ef1:	mov    r15,r13
     ef4:	shr    r15,0x30
     ef8:	and    r15,0xff
     eff:	and    r15,0xffff
     f06:	shl    r15,0x20
     f0a:	mov    rcx,r15
     f0d:	or     r14,rcx
     f10:	shr    r13,0x38
     f14:	and    r13,0xff
     f1b:	and    r13,0xffff
     f22:	shl    r13,0x30
     f26:	mov    rcx,r13
     f29:	or     r14,rcx
     f2c:	mov    QWORD PTR [r12+0x210],rbp
     f34:	mov    QWORD PTR [r12+0x218],r14
     f3c:	mov    r13,QWORD PTR [r12+0x138]
     f44:	mov    r14d,0x0
     f4a:	mov    r15,r13
     f4d:	and    r15,0xff
     f54:	and    r15,0xffff
     f5b:	mov    rcx,r15
     f5e:	mov    rbp,r14
     f61:	or     rbp,rcx
     f64:	mov    r15,r13
     f67:	shr    r15,0x8
     f6b:	and    r15,0xff
     f72:	and    r15,0xffff
     f79:	shl    r15,0x10
     f7d:	mov    rcx,r15
     f80:	or     rbp,rcx
     f83:	mov    r15,r13
     f86:	shr    r15,0x10
     f8a:	and    r15,0xff
     f91:	and    r15,0xffff
     f98:	shl    r15,0x20
     f9c:	mov    rcx,r15
     f9f:	or     rbp,rcx
     fa2:	mov    r15,r13
     fa5:	shr    r15,0x18
     fa9:	and    r15,0xff
     fb0:	and    r15,0xffff
     fb7:	shl    r15,0x30
     fbb:	mov    rcx,r15
     fbe:	or     rbp,rcx
     fc1:	mov    r15,r13
     fc4:	shr    r15,0x20
     fc8:	and    r15,0xff
     fcf:	and    r15,0xffff
     fd6:	mov    rcx,r15
     fd9:	or     r14,rcx
     fdc:	mov    r15,r13
     fdf:	shr    r15,0x28
     fe3:	and    r15,0xff
     fea:	and    r15,0xffff
     ff1:	shl    r15,0x10
     ff5:	mov    rcx,r15
     ff8:	or     r14,rcx
     ffb:	mov    r15,r13
     ffe:	shr    r15,0x30
    1002:	and    r15,0xff
    1009:	and    r15,0xffff
    1010:	shl    r15,0x20
    1014:	mov    rcx,r15
    1017:	or     r14,rcx
    101a:	shr    r13,0x38
    101e:	and    r13,0xff
    1025:	and    r13,0xffff
    102c:	shl    r13,0x30
    1030:	mov    rcx,r13
    1033:	or     r14,rcx
    1036:	mov    QWORD PTR [r12+0x220],rbp
    103e:	mov    QWORD PTR [r12+0x228],r14
    1046:	mov    r13,QWORD PTR [r12+0x140]
    104e:	mov    r14d,0x0
    1054:	mov    r15,r13
    1057:	and    r15,0xff
    105e:	and    r15,0xffff
    1065:	mov    rcx,r15
    1068:	mov    rbp,r14
    106b:	or     rbp,rcx
    106e:	mov    r15,r13
    1071:	shr    r15,0x8
    1075:	and    r15,0xff
    107c:	and    r15,0xffff
    1083:	shl    r15,0x10
    1087:	mov    rcx,r15
    108a:	or     rbp,rcx
    108d:	mov    r15,r13
    1090:	shr    r15,0x10
    1094:	and    r15,0xff
    109b:	and    r15,0xffff
    10a2:	shl    r15,0x20
    10a6:	mov    rcx,r15
    10a9:	or     rbp,rcx
    10ac:	mov    r15,r13
    10af:	shr    r15,0x18
    10b3:	and    r15,0xff
    10ba:	and    r15,0xffff
    10c1:	shl    r15,0x30
    10c5:	mov    rcx,r15
    10c8:	or     rbp,rcx
    10cb:	mov    r15,r13
    10ce:	shr    r15,0x20
    10d2:	and    r15,0xff
    10d9:	and    r15,0xffff
    10e0:	mov    rcx,r15
    10e3:	or     r14,rcx
    10e6:	mov    r15,r13
    10e9:	shr    r15,0x28
    10ed:	and    r15,0xff
    10f4:	and    r15,0xffff
    10fb:	shl    r15,0x10
    10ff:	mov    rcx,r15
    1102:	or     r14,rcx
    1105:	mov    r15,r13
    1108:	shr    r15,0x30
    110c:	and    r15,0xff
    1113:	and    r15,0xffff
    111a:	shl    r15,0x20
    111e:	mov    rcx,r15
    1121:	or     r14,rcx
    1124:	shr    r13,0x38
    1128:	and    r13,0xff
    112f:	and    r13,0xffff
    1136:	shl    r13,0x30
    113a:	mov    rcx,r13
    113d:	or     r14,rcx
    1140:	mov    QWORD PTR [r12+0x250],rbp
    1148:	mov    QWORD PTR [r12+0x258],r14
    1150:	mov    r13,QWORD PTR [r12+0x148]
    1158:	mov    r14d,0x0
    115e:	mov    r15,r13
    1161:	and    r15,0xff
    1168:	and    r15,0xffff
    116f:	mov    rcx,r15
    1172:	mov    rbp,r14
    1175:	or     rbp,rcx
    1178:	mov    r15,r13
    117b:	shr    r15,0x8
    117f:	and    r15,0xff
    1186:	and    r15,0xffff
    118d:	shl    r15,0x10
    1191:	mov    rcx,r15
    1194:	or     rbp,rcx
    1197:	mov    r15,r13
    119a:	shr    r15,0x10
    119e:	and    r15,0xff
    11a5:	and    r15,0xffff
    11ac:	shl    r15,0x20
    11b0:	mov    rcx,r15
    11b3:	or     rbp,rcx
    11b6:	mov    r15,r13
    11b9:	shr    r15,0x18
    11bd:	and    r15,0xff
    11c4:	and    r15,0xffff
    11cb:	shl    r15,0x30
    11cf:	mov    rcx,r15
    11d2:	or     rbp,rcx
    11d5:	mov    r15,r13
    11d8:	shr    r15,0x20
    11dc:	and    r15,0xff
    11e3:	and    r15,0xffff
    11ea:	mov    rcx,r15
    11ed:	or     r14,rcx
    11f0:	mov    r15,r13
    11f3:	shr    r15,0x28
    11f7:	and    r15,0xff
    11fe:	and    r15,0xffff
    1205:	shl    r15,0x10
    1209:	mov    rcx,r15
    120c:	or     r14,rcx
    120f:	mov    r15,r13
    1212:	shr    r15,0x30
    1216:	and    r15,0xff
    121d:	and    r15,0xffff
    1224:	shl    r15,0x20
    1228:	mov    rcx,r15
    122b:	or     r14,rcx
    122e:	shr    r13,0x38
    1232:	and    r13,0xff
    1239:	and    r13,0xffff
    1240:	shl    r13,0x30
    1244:	mov    rcx,r13
    1247:	or     r14,rcx
    124a:	mov    QWORD PTR [r12+0x110],rbp
    1252:	mov    QWORD PTR [r12+0x118],r14
    125a:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    1264:	movdqa xmm2,xmm0
    1268:	pxor   xmm0,xmm0
    126c:	movdqa xmm3,xmm0
    1270:	movdqa xmm0,xmm2
    1274:	movdqa xmm1,xmm3
    1278:	punpcklwd xmm0,xmm1
    127c:	movdqa xmm4,xmm0
    1280:	movdqa xmm0,xmm4
    1284:	pslld  xmm0,0x10
    1289:	movdqa xmm2,xmm0
    128d:	movdqa xmm0,xmm2
    1291:	movdqu XMMWORD PTR [r12+0x230],xmm0
    129b:	mov    r13,QWORD PTR [r12+0x160]
    12a3:	mov    r14d,0x0
    12a9:	mov    r15,r13
    12ac:	and    r15,0xffff
    12b3:	shl    r15,0x8
    12b7:	mov    ecx,0xffffffff
    12bc:	and    r15,rcx
    12bf:	mov    rcx,r15
    12c2:	mov    rbp,r14
    12c5:	or     rbp,rcx
    12c8:	mov    r15,r13
    12cb:	shr    r15,0x10
    12cf:	and    r15,0xffff
    12d6:	shl    r15,0x8
    12da:	mov    ecx,0xffffffff
    12df:	and    r15,rcx
    12e2:	shl    r15,0x20
    12e6:	mov    rcx,r15
    12e9:	or     rbp,rcx
    12ec:	mov    r15,r13
    12ef:	shr    r15,0x20
    12f3:	and    r15,0xffff
    12fa:	shl    r15,0x8
    12fe:	mov    ecx,0xffffffff
    1303:	and    r15,rcx
    1306:	mov    rcx,r15
    1309:	or     r14,rcx
    130c:	shr    r13,0x30
    1310:	and    r13,0xffff
    1317:	shl    r13,0x8
    131b:	mov    ecx,0xffffffff
    1320:	and    r13,rcx
    1323:	shl    r13,0x20
    1327:	mov    rcx,r13
    132a:	or     r14,rcx
    132d:	mov    QWORD PTR [r12+0x240],rbp
    1335:	mov    QWORD PTR [r12+0x248],r14
    133d:	mov    r13,QWORD PTR [r12+0x178]
    1345:	mov    r14d,0x0
    134b:	mov    r15,r13
    134e:	and    r15,0xffff
    1355:	mov    ecx,0xffffffff
    135a:	and    r15,rcx
    135d:	mov    rcx,r15
    1360:	mov    rbp,r14
    1363:	or     rbp,rcx
    1366:	mov    r15,r13
    1369:	shr    r15,0x10
    136d:	and    r15,0xffff
    1374:	mov    ecx,0xffffffff
    1379:	and    r15,rcx
    137c:	shl    r15,0x20
    1380:	mov    rcx,r15
    1383:	or     rbp,rcx
    1386:	mov    r15,r13
    1389:	shr    r15,0x20
    138d:	and    r15,0xffff
    1394:	mov    ecx,0xffffffff
    1399:	and    r15,rcx
    139c:	mov    rcx,r15
    139f:	or     r14,rcx
    13a2:	shr    r13,0x30
    13a6:	and    r13,0xffff
    13ad:	mov    ecx,0xffffffff
    13b2:	and    r13,rcx
    13b5:	shl    r13,0x20
    13b9:	mov    rcx,r13
    13bc:	or     r14,rcx
    13bf:	mov    QWORD PTR [r12+0x260],rbp
    13c7:	mov    QWORD PTR [r12+0x268],r14
    13cf:	mov    r13,QWORD PTR [r12+0x188]
    13d7:	mov    r14d,0x0
    13dd:	mov    r15,r13
    13e0:	and    r15,0xffff
    13e7:	mov    ecx,0xffffffff
    13ec:	and    r15,rcx
    13ef:	mov    rcx,r15
    13f2:	mov    rbp,r14
    13f5:	or     rbp,rcx
    13f8:	mov    r15,r13
    13fb:	shr    r15,0x10
    13ff:	and    r15,0xffff
    1406:	mov    ecx,0xffffffff
    140b:	and    r15,rcx
    140e:	shl    r15,0x20
    1412:	mov    rcx,r15
    1415:	or     rbp,rcx
    1418:	mov    r15,r13
    141b:	shr    r15,0x20
    141f:	and    r15,0xffff
    1426:	mov    ecx,0xffffffff
    142b:	and    r15,rcx
    142e:	mov    rcx,r15
    1431:	or     r14,rcx
    1434:	shr    r13,0x30
    1438:	and    r13,0xffff
    143f:	mov    ecx,0xffffffff
    1444:	and    r13,rcx
    1447:	shl    r13,0x20
    144b:	mov    rcx,r13
    144e:	or     r14,rcx
    1451:	mov    QWORD PTR [r12+0x270],rbp
    1459:	mov    QWORD PTR [r12+0x278],r14
    1461:	mov    r13,QWORD PTR [r12+0x170]
    1469:	mov    r14d,0x0
    146f:	mov    r15,r13
    1472:	and    r15,0xffff
    1479:	mov    ecx,0xffffffff
    147e:	and    r15,rcx
    1481:	mov    rcx,r15
    1484:	mov    rbp,r14
    1487:	or     rbp,rcx
    148a:	mov    r15,r13
    148d:	shr    r15,0x10
    1491:	and    r15,0xffff
    1498:	mov    ecx,0xffffffff
    149d:	and    r15,rcx
    14a0:	shl    r15,0x20
    14a4:	mov    rcx,r15
    14a7:	or     rbp,rcx
    14aa:	mov    r15,r13
    14ad:	shr    r15,0x20
    14b1:	and    r15,0xffff
    14b8:	mov    ecx,0xffffffff
    14bd:	and    r15,rcx
    14c0:	mov    rcx,r15
    14c3:	or     r14,rcx
    14c6:	shr    r13,0x30
    14ca:	and    r13,0xffff
    14d1:	mov    ecx,0xffffffff
    14d6:	and    r13,rcx
    14d9:	shl    r13,0x20
    14dd:	mov    rcx,r13
    14e0:	or     r14,rcx
    14e3:	mov    QWORD PTR [r12+0x170],rbp
    14eb:	mov    QWORD PTR [r12+0x178],r14
    14f3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    14fd:	movdqa xmm2,xmm0
    1501:	pxor   xmm0,xmm0
    1505:	movdqa xmm3,xmm0
    1509:	movdqa xmm0,xmm2
    150d:	movdqa xmm1,xmm3
    1511:	punpckhwd xmm0,xmm1
    1515:	movdqa xmm4,xmm0
    1519:	movdqa xmm0,xmm4
    151d:	pslld  xmm0,0x10
    1522:	movdqa xmm3,xmm0
    1526:	movdqa xmm0,xmm3
    152a:	movdqu XMMWORD PTR [r12+0x280],xmm0
    1534:	mov    r13,QWORD PTR [r12+0x180]
    153c:	mov    r14d,0x0
    1542:	mov    r15,r13
    1545:	and    r15,0xffff
    154c:	mov    ecx,0xffffffff
    1551:	and    r15,rcx
    1554:	mov    rcx,r15
    1557:	mov    rbp,r14
    155a:	or     rbp,rcx
    155d:	mov    r15,r13
    1560:	shr    r15,0x10
    1564:	and    r15,0xffff
    156b:	mov    ecx,0xffffffff
    1570:	and    r15,rcx
    1573:	shl    r15,0x20
    1577:	mov    rcx,r15
    157a:	or     rbp,rcx
    157d:	mov    r15,r13
    1580:	shr    r15,0x20
    1584:	and    r15,0xffff
    158b:	mov    ecx,0xffffffff
    1590:	and    r15,rcx
    1593:	mov    rcx,r15
    1596:	or     r14,rcx
    1599:	shr    r13,0x30
    159d:	and    r13,0xffff
    15a4:	mov    ecx,0xffffffff
    15a9:	and    r13,rcx
    15ac:	shl    r13,0x20
    15b0:	mov    rcx,r13
    15b3:	or     r14,rcx
    15b6:	mov    QWORD PTR [r12+0x180],rbp
    15be:	mov    QWORD PTR [r12+0x188],r14
    15c6:	pxor   xmm0,xmm0
    15ca:	movdqa xmm3,xmm0
    15ce:	movdqa xmm0,xmm2
    15d2:	movdqa xmm1,xmm3
    15d6:	punpcklwd xmm0,xmm1
    15da:	movdqa xmm4,xmm0
    15de:	movdqa xmm0,xmm4
    15e2:	pslld  xmm0,0x10
    15e7:	movdqa xmm2,xmm0
    15eb:	movdqa xmm0,xmm2
    15ef:	movdqu XMMWORD PTR [r12+0x210],xmm0
    15f9:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    1603:	movdqa xmm2,xmm0
    1607:	pxor   xmm0,xmm0
    160b:	movdqa xmm3,xmm0
    160f:	movdqa xmm0,xmm2
    1613:	movdqa xmm1,xmm3
    1617:	punpckhwd xmm0,xmm1
    161b:	movdqa xmm4,xmm0
    161f:	movdqa xmm0,xmm4
    1623:	pslld  xmm0,0x10
    1628:	movdqa xmm2,xmm0
    162c:	movdqa xmm0,xmm2
    1630:	movdqu XMMWORD PTR [r12+0x150],xmm0
    163a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1644:	movdqa xmm2,xmm0
    1648:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1652:	movdqa xmm3,xmm0
    1656:	movdqa xmm1,xmm2
    165a:	por    xmm3,xmm1
    165e:	movdqa xmm0,xmm3
    1662:	movdqu XMMWORD PTR [r12+0x230],xmm0
    166c:	mov    r13,QWORD PTR [r12+0x228]
    1674:	mov    r14d,0x0
    167a:	mov    r15,r13
    167d:	and    r15,0xffff
    1684:	shl    r15,0x8
    1688:	mov    ecx,0xffffffff
    168d:	and    r15,rcx
    1690:	mov    rcx,r15
    1693:	mov    rbp,r14
    1696:	or     rbp,rcx
    1699:	mov    r15,r13
    169c:	shr    r15,0x10
    16a0:	and    r15,0xffff
    16a7:	shl    r15,0x8
    16ab:	mov    ecx,0xffffffff
    16b0:	and    r15,rcx
    16b3:	shl    r15,0x20
    16b7:	mov    rcx,r15
    16ba:	or     rbp,rcx
    16bd:	mov    r15,r13
    16c0:	shr    r15,0x20
    16c4:	and    r15,0xffff
    16cb:	shl    r15,0x8
    16cf:	mov    ecx,0xffffffff
    16d4:	and    r15,rcx
    16d7:	mov    rcx,r15
    16da:	or     r14,rcx
    16dd:	shr    r13,0x30
    16e1:	and    r13,0xffff
    16e8:	shl    r13,0x8
    16ec:	mov    ecx,0xffffffff
    16f1:	and    r13,rcx
    16f4:	shl    r13,0x20
    16f8:	mov    rcx,r13
    16fb:	or     r14,rcx
    16fe:	mov    QWORD PTR [r12+0x240],rbp
    1706:	mov    QWORD PTR [r12+0x248],r14
    170e:	mov    r13,QWORD PTR [r12+0x220]
    1716:	mov    r14d,0x0
    171c:	mov    r15,r13
    171f:	and    r15,0xffff
    1726:	shl    r15,0x8
    172a:	mov    ecx,0xffffffff
    172f:	and    r15,rcx
    1732:	mov    rcx,r15
    1735:	mov    rbp,r14
    1738:	or     rbp,rcx
    173b:	mov    r15,r13
    173e:	shr    r15,0x10
    1742:	and    r15,0xffff
    1749:	shl    r15,0x8
    174d:	mov    ecx,0xffffffff
    1752:	and    r15,rcx
    1755:	shl    r15,0x20
    1759:	mov    rcx,r15
    175c:	or     rbp,rcx
    175f:	mov    r15,r13
    1762:	shr    r15,0x20
    1766:	and    r15,0xffff
    176d:	shl    r15,0x8
    1771:	mov    ecx,0xffffffff
    1776:	and    r15,rcx
    1779:	mov    rcx,r15
    177c:	or     r14,rcx
    177f:	shr    r13,0x30
    1783:	and    r13,0xffff
    178a:	shl    r13,0x8
    178e:	mov    ecx,0xffffffff
    1793:	and    r13,rcx
    1796:	shl    r13,0x20
    179a:	mov    rcx,r13
    179d:	or     r14,rcx
    17a0:	mov    QWORD PTR [r12+0x220],rbp
    17a8:	mov    QWORD PTR [r12+0x228],r14
    17b0:	mov    r13,QWORD PTR [r12+0x168]
    17b8:	mov    r14d,0x0
    17be:	mov    r15,r13
    17c1:	and    r15,0xffff
    17c8:	shl    r15,0x8
    17cc:	mov    ecx,0xffffffff
    17d1:	and    r15,rcx
    17d4:	mov    rcx,r15
    17d7:	mov    rbp,r14
    17da:	or     rbp,rcx
    17dd:	mov    r15,r13
    17e0:	shr    r15,0x10
    17e4:	and    r15,0xffff
    17eb:	shl    r15,0x8
    17ef:	mov    ecx,0xffffffff
    17f4:	and    r15,rcx
    17f7:	shl    r15,0x20
    17fb:	mov    rcx,r15
    17fe:	or     rbp,rcx
    1801:	mov    r15,r13
    1804:	shr    r15,0x20
    1808:	and    r15,0xffff
    180f:	shl    r15,0x8
    1813:	mov    ecx,0xffffffff
    1818:	and    r15,rcx
    181b:	mov    rcx,r15
    181e:	or     r14,rcx
    1821:	shr    r13,0x30
    1825:	and    r13,0xffff
    182c:	shl    r13,0x8
    1830:	mov    ecx,0xffffffff
    1835:	and    r13,rcx
    1838:	shl    r13,0x20
    183c:	mov    rcx,r13
    183f:	or     r14,rcx
    1842:	mov    QWORD PTR [r12+0x160],rbp
    184a:	mov    QWORD PTR [r12+0x168],r14
    1852:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    185c:	movdqa xmm2,xmm0
    1860:	movdqa xmm0,xmm2
    1864:	pslld  xmm0,0x18
    1869:	movdqa xmm3,xmm0
    186d:	movdqa xmm0,xmm3
    1871:	movdqu XMMWORD PTR [r12+0x170],xmm0
    187b:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    1885:	movdqa xmm2,xmm0
    1889:	movdqa xmm0,xmm2
    188d:	pslld  xmm0,0x18
    1892:	movdqa xmm3,xmm0
    1896:	movdqa xmm0,xmm3
    189a:	movdqu XMMWORD PTR [r12+0x120],xmm0
    18a4:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    18ae:	movdqa xmm2,xmm0
    18b2:	movdqa xmm0,xmm2
    18b6:	pslld  xmm0,0x18
    18bb:	movdqa xmm3,xmm0
    18bf:	movdqa xmm0,xmm3
    18c3:	movdqu XMMWORD PTR [r12+0x180],xmm0
    18cd:	mov    r13,QWORD PTR [r12+0x250]
    18d5:	mov    r14d,0x0
    18db:	mov    r15,r13
    18de:	and    r15,0xffff
    18e5:	mov    ecx,0xffffffff
    18ea:	and    r15,rcx
    18ed:	mov    rcx,r15
    18f0:	mov    rbp,r14
    18f3:	or     rbp,rcx
    18f6:	mov    r15,r13
    18f9:	shr    r15,0x10
    18fd:	and    r15,0xffff
    1904:	mov    ecx,0xffffffff
    1909:	and    r15,rcx
    190c:	shl    r15,0x20
    1910:	mov    rcx,r15
    1913:	or     rbp,rcx
    1916:	mov    r15,r13
    1919:	shr    r15,0x20
    191d:	and    r15,0xffff
    1924:	mov    ecx,0xffffffff
    1929:	and    r15,rcx
    192c:	mov    rcx,r15
    192f:	or     r14,rcx
    1932:	shr    r13,0x30
    1936:	and    r13,0xffff
    193d:	mov    ecx,0xffffffff
    1942:	and    r13,rcx
    1945:	shl    r13,0x20
    1949:	mov    rcx,r13
    194c:	or     r14,rcx
    194f:	mov    QWORD PTR [r12+0x140],rbp
    1957:	mov    QWORD PTR [r12+0x148],r14
    195f:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1969:	movdqa xmm2,xmm0
    196d:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    1977:	movdqa xmm3,xmm0
    197b:	movdqa xmm1,xmm2
    197f:	por    xmm3,xmm1
    1983:	movdqa xmm0,xmm3
    1987:	movdqu XMMWORD PTR [r12+0x130],xmm0
    1991:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    199b:	movdqa xmm2,xmm0
    199f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    19a9:	movdqa xmm3,xmm0
    19ad:	movdqa xmm1,xmm2
    19b1:	por    xmm3,xmm1
    19b5:	movdqa xmm0,xmm3
    19b9:	movdqu XMMWORD PTR [r12+0x210],xmm0
    19c3:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    19cd:	movdqa xmm2,xmm0
    19d1:	movdqa xmm0,xmm2
    19d5:	pslld  xmm0,0x18
    19da:	movdqa xmm3,xmm0
    19de:	movdqa xmm0,xmm3
    19e2:	movdqu XMMWORD PTR [r12+0x220],xmm0
    19ec:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    19f6:	movdqa xmm2,xmm0
    19fa:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    1a04:	movdqa xmm3,xmm0
    1a08:	movdqa xmm1,xmm2
    1a0c:	por    xmm3,xmm1
    1a10:	movdqa xmm0,xmm3
    1a14:	movdqu XMMWORD PTR [r12+0x150],xmm0
    1a1e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    1a28:	movdqa xmm2,xmm0
    1a2c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1a36:	movdqa xmm3,xmm0
    1a3a:	movdqa xmm1,xmm2
    1a3e:	por    xmm3,xmm1
    1a42:	movdqa xmm0,xmm3
    1a46:	movdqu XMMWORD PTR [r12+0x160],xmm0
    1a50:	mov    r13,QWORD PTR [r12+0x118]
    1a58:	mov    r14d,0x0
    1a5e:	mov    r15,r13
    1a61:	and    r15,0xffff
    1a68:	mov    ecx,0xffffffff
    1a6d:	and    r15,rcx
    1a70:	mov    rcx,r15
    1a73:	mov    rbp,r14
    1a76:	or     rbp,rcx
    1a79:	mov    r15,r13
    1a7c:	shr    r15,0x10
    1a80:	and    r15,0xffff
    1a87:	mov    ecx,0xffffffff
    1a8c:	and    r15,rcx
    1a8f:	shl    r15,0x20
    1a93:	mov    rcx,r15
    1a96:	or     rbp,rcx
    1a99:	mov    r15,r13
    1a9c:	shr    r15,0x20
    1aa0:	and    r15,0xffff
    1aa7:	mov    ecx,0xffffffff
    1aac:	and    r15,rcx
    1aaf:	mov    rcx,r15
    1ab2:	or     r14,rcx
    1ab5:	shr    r13,0x30
    1ab9:	and    r13,0xffff
    1ac0:	mov    ecx,0xffffffff
    1ac5:	and    r13,rcx
    1ac8:	shl    r13,0x20
    1acc:	mov    rcx,r13
    1acf:	or     r14,rcx
    1ad2:	mov    QWORD PTR [r12+0x170],rbp
    1ada:	mov    QWORD PTR [r12+0x178],r14
    1ae2:	mov    r13,QWORD PTR [r12+0x110]
    1aea:	mov    r14d,0x0
    1af0:	mov    r15,r13
    1af3:	and    r15,0xffff
    1afa:	mov    ecx,0xffffffff
    1aff:	and    r15,rcx
    1b02:	mov    rcx,r15
    1b05:	mov    rbp,r14
    1b08:	or     rbp,rcx
    1b0b:	mov    r15,r13
    1b0e:	shr    r15,0x10
    1b12:	and    r15,0xffff
    1b19:	mov    ecx,0xffffffff
    1b1e:	and    r15,rcx
    1b21:	shl    r15,0x20
    1b25:	mov    rcx,r15
    1b28:	or     rbp,rcx
    1b2b:	mov    r15,r13
    1b2e:	shr    r15,0x20
    1b32:	and    r15,0xffff
    1b39:	mov    ecx,0xffffffff
    1b3e:	and    r15,rcx
    1b41:	mov    rcx,r15
    1b44:	or     r14,rcx
    1b47:	shr    r13,0x30
    1b4b:	and    r13,0xffff
    1b52:	mov    ecx,0xffffffff
    1b57:	and    r13,rcx
    1b5a:	shl    r13,0x20
    1b5e:	mov    rcx,r13
    1b61:	or     r14,rcx
    1b64:	mov    QWORD PTR [r12+0x110],rbp
    1b6c:	mov    QWORD PTR [r12+0x118],r14
    1b74:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    1b7e:	movdqa xmm2,xmm0
    1b82:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    1b8c:	movdqa xmm3,xmm0
    1b90:	movdqa xmm1,xmm2
    1b94:	por    xmm3,xmm1
    1b98:	movdqa xmm0,xmm3
    1b9c:	movdqu XMMWORD PTR [r12+0x120],xmm0
    1ba6:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    1bb0:	movdqa xmm2,xmm0
    1bb4:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    1bbe:	movdqa xmm3,xmm0
    1bc2:	movdqa xmm1,xmm2
    1bc6:	por    xmm3,xmm1
    1bca:	movdqa xmm0,xmm3
    1bce:	movdqu XMMWORD PTR [r12+0x130],xmm0
    1bd8:	mov    r13,QWORD PTR [r12+0x258]
    1be0:	mov    r14d,0x0
    1be6:	mov    r15,r13
    1be9:	and    r15,0xffff
    1bf0:	mov    ecx,0xffffffff
    1bf5:	and    r15,rcx
    1bf8:	mov    rcx,r15
    1bfb:	mov    rbp,r14
    1bfe:	or     rbp,rcx
    1c01:	mov    r15,r13
    1c04:	shr    r15,0x10
    1c08:	and    r15,0xffff
    1c0f:	mov    ecx,0xffffffff
    1c14:	and    r15,rcx
    1c17:	shl    r15,0x20
    1c1b:	mov    rcx,r15
    1c1e:	or     rbp,rcx
    1c21:	mov    r15,r13
    1c24:	shr    r15,0x20
    1c28:	and    r15,0xffff
    1c2f:	mov    ecx,0xffffffff
    1c34:	and    r15,rcx
    1c37:	mov    rcx,r15
    1c3a:	or     r14,rcx
    1c3d:	shr    r13,0x30
    1c41:	and    r13,0xffff
    1c48:	mov    ecx,0xffffffff
    1c4d:	and    r13,rcx
    1c50:	shl    r13,0x20
    1c54:	mov    rcx,r13
    1c57:	or     r14,rcx
    1c5a:	mov    QWORD PTR [r12+0x180],rbp
    1c62:	mov    QWORD PTR [r12+0x188],r14
    1c6a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1c74:	movdqa xmm2,xmm0
    1c78:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    1c82:	movdqa xmm3,xmm0
    1c86:	movdqa xmm1,xmm2
    1c8a:	por    xmm3,xmm1
    1c8e:	movdqa xmm0,xmm3
    1c92:	movdqu XMMWORD PTR [r12+0x150],xmm0
    1c9c:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    1ca6:	movdqa xmm2,xmm0
    1caa:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    1cb4:	movdqa xmm4,xmm0
    1cb8:	movdqa xmm1,xmm2
    1cbc:	por    xmm4,xmm1
    1cc0:	movdqa xmm0,xmm4
    1cc4:	movdqu XMMWORD PTR [r12+0x140],xmm0
    1cce:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    1cd8:	movdqa xmm2,xmm0
    1cdc:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    1ce6:	movdqa xmm4,xmm0
    1cea:	movdqa xmm1,xmm2
    1cee:	por    xmm4,xmm1
    1cf2:	movdqa xmm0,xmm4
    1cf6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    1d00:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    1d0a:	movdqa xmm2,xmm0
    1d0e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    1d18:	movdqa xmm5,xmm0
    1d1c:	movdqa xmm1,xmm2
    1d20:	por    xmm5,xmm1
    1d24:	movdqa xmm0,xmm5
    1d28:	movdqu XMMWORD PTR [r12+0x120],xmm0
    1d32:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    1d3c:	movdqa xmm2,xmm0
    1d40:	movdqa xmm1,xmm2
    1d44:	por    xmm3,xmm1
    1d48:	movdqa xmm0,xmm3
    1d4c:	movdqu XMMWORD PTR [r12+0x130],xmm0
    1d56:	mov    r13,QWORD PTR [r12+0xf8]
    1d5e:	mov    r14,r13
    1d61:	add    r14,0x20
    1d65:	mov    r15,r14
    1d68:	add    r15,0x10
    1d6c:	movdqu XMMWORD PTR [r14],xmm4
    1d71:	mov    r14d,0x0
    1d77:	mov    DWORD PTR [r12+0x32c],r14d
    1d7f:	movdqu XMMWORD PTR [r15],xmm5
    1d84:	mov    r14d,0x0
    1d8a:	mov    DWORD PTR [r12+0x32c],r14d
    1d92:	mov    r14,r13
    1d95:	add    r14,0x10
    1d99:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    1da3:	movdqa xmm2,xmm0
    1da7:	movdqu XMMWORD PTR [r13+0x0],xmm2
    1dad:	mov    r15d,0x0
    1db3:	mov    DWORD PTR [r12+0x32c],r15d
    1dbb:	movdqu XMMWORD PTR [r14],xmm3
    1dc0:	mov    r14d,0x0
    1dc6:	mov    DWORD PTR [r12+0x32c],r14d
    1dce:	mov    r14d,DWORD PTR [r13+0x0]
    1dd2:	mov    QWORD PTR [r12+0x60],r14
    1dd7:	jmp    0x1ddc
    1ddc:	mov    r13,QWORD PTR [r12+0x58]
    1de1:	mov    r14,QWORD PTR [r12+0x48]
    1de6:	mov    rcx,r13
    1de9:	add    r14,rcx
    1dec:	mov    QWORD PTR [r12+0x68],r14
    1df1:	add    r13,0x4
    1df5:	mov    QWORD PTR [r12+0x58],r13
    1dfa:	mov    r15,r14
    1dfd:	add    r15,0x4
    1e01:	mov    ebp,DWORD PTR [r15]
    1e04:	mov    QWORD PTR [r12+0x70],rbp
    1e09:	mov    r15,r14
    1e0c:	add    r15,0x38
    1e10:	mov    r8d,DWORD PTR [r15]
    1e13:	mov    QWORD PTR [r12+0x78],r8
    1e18:	add    r14,0x24
    1e1c:	mov    r15d,DWORD PTR [r14]
    1e1f:	mov    QWORD PTR [r12+0x90],r15
    1e27:	sub    r13,0xc0
    1e2e:	pushf
    1e2f:	pop    r11
    1e31:	mov    QWORD PTR [rsp+0x48],r11
    1e36:	mov    r13d,ebp
    1e39:	mov    r13d,r13d
    1e3c:	ror    r13d,0x7
    1e40:	mov    QWORD PTR [r12+0x80],r13
    1e48:	mov    r14d,r8d
    1e4b:	mov    r14d,r14d
    1e4e:	ror    r14d,0x11
    1e52:	mov    QWORD PTR [r12+0x88],r14
    1e5a:	mov    r9d,DWORD PTR [r12+0x60]
    1e5f:	mov    ecx,r9d
    1e62:	add    r15d,ecx
    1e65:	mov    QWORD PTR [r12+0x60],r15
    1e6a:	mov    r15d,ebp
    1e6d:	mov    r15d,r15d
    1e70:	shr    r15d,0x12
    1e74:	mov    ebp,ebp
    1e76:	shl    ebp,0xe
    1e79:	mov    ecx,ebp
    1e7b:	or     r15,rcx
    1e7e:	mov    r15d,r15d
    1e81:	mov    ecx,r15d
    1e84:	xor    r13,rcx
    1e87:	mov    r13d,r13d
    1e8a:	mov    QWORD PTR [r12+0x80],r13
    1e92:	mov    r15d,r8d
    1e95:	mov    r15d,r15d
    1e98:	shr    r15d,0x13
    1e9c:	mov    r8d,r8d
    1e9f:	shl    r8d,0xd
    1ea3:	mov    ecx,r8d
    1ea6:	or     r15,rcx
    1ea9:	mov    r15d,r15d
    1eac:	mov    ecx,r15d
    1eaf:	xor    r14,rcx
    1eb2:	mov    r14d,r14d
    1eb5:	mov    QWORD PTR [r12+0x88],r14
    1ebd:	mov    r15d,DWORD PTR [r12+0x70]
    1ec2:	mov    r15d,r15d
    1ec5:	shr    r15d,0x3
    1ec9:	mov    ecx,r15d
    1ecc:	xor    r13,rcx
    1ecf:	mov    r13d,r13d
    1ed2:	mov    QWORD PTR [r12+0x80],r13
    1eda:	mov    r15d,DWORD PTR [r12+0x78]
    1edf:	mov    r15d,r15d
    1ee2:	shr    r15d,0xa
    1ee6:	mov    ecx,r15d
    1ee9:	xor    r14,rcx
    1eec:	mov    r14d,r14d
    1eef:	mov    QWORD PTR [r12+0x78],r14
    1ef4:	mov    r15d,DWORD PTR [r12+0x60]
    1ef9:	mov    ecx,r13d
    1efc:	add    r15d,ecx
    1eff:	mov    QWORD PTR [r12+0x60],r15
    1f04:	mov    ecx,r14d
    1f07:	add    r15d,ecx
    1f0a:	mov    QWORD PTR [r12+0x60],r15
    1f0f:	mov    r13,QWORD PTR [r12+0x68]
    1f14:	add    r13,0x40
    1f18:	mov    DWORD PTR [r13+0x0],r15d
    1f1c:	mov    r13d,0x0
    1f22:	mov    DWORD PTR [r12+0x32c],r13d
    1f2a:	mov    r13d,0x0
    1f30:	mov    r14d,DWORD PTR [r12+0x70]
    1f35:	mov    ecx,r14d
    1f38:	mov    r15d,r13d
    1f3b:	or     r15,rcx
    1f3e:	mov    r15d,r15d
    1f41:	mov    QWORD PTR [r12+0x60],r15
    1f46:	mov    rcx,QWORD PTR [r12+0x380]
    1f4e:	jrcxz  0x1f55
    1f50:	jmp    0x28ae
    1f55:	push   QWORD PTR [rsp+0x48]
    1f59:	popf
    1f5a:	jne    0x1ddc
    1f60:	jmp    0x1f65
    1f65:	mov    r13,QWORD PTR [r12]
    1f69:	mov    r14,r13
    1f6c:	add    r14,0x4
    1f70:	mov    r15d,DWORD PTR [r13+0x0]
    1f74:	mov    ebp,DWORD PTR [r14]
    1f77:	mov    QWORD PTR [r12+0x78],r15
    1f7c:	mov    QWORD PTR [r12+0x80],rbp
    1f84:	mov    r14,r13
    1f87:	add    r14,0x8
    1f8b:	mov    r15,r14
    1f8e:	add    r15,0x4
    1f92:	mov    ebp,DWORD PTR [r14]
    1f95:	mov    r14d,DWORD PTR [r15]
    1f98:	mov    QWORD PTR [r12+0x70],rbp
    1f9d:	mov    QWORD PTR [r12+0x68],r14
    1fa2:	mov    r14,r13
    1fa5:	add    r14,0x18
    1fa9:	mov    r15,r14
    1fac:	add    r15,0x4
    1fb0:	mov    ebp,DWORD PTR [r14]
    1fb3:	mov    r14d,DWORD PTR [r15]
    1fb6:	mov    QWORD PTR [r12+0x58],rbp
    1fbb:	mov    QWORD PTR [r12+0x60],r14
    1fc0:	add    r13,0x10
    1fc4:	mov    r14,r13
    1fc7:	add    r14,0x4
    1fcb:	mov    r15d,DWORD PTR [r13+0x0]
    1fcf:	mov    r13d,DWORD PTR [r14]
    1fd2:	mov    QWORD PTR [r12+0x18],r15
    1fd7:	mov    QWORD PTR [r12+0x90],r13
    1fdf:	mov    r13d,0x0
    1fe5:	mov    QWORD PTR [r12+0x88],r13
    1fed:	mov    r13d,0x0
    1ff3:	mov    r14d,DWORD PTR [r12+0x78]
    1ff8:	mov    ecx,r14d
    1ffb:	mov    r15d,r13d
    1ffe:	or     r15,rcx
    2001:	mov    r15d,r15d
    2004:	mov    QWORD PTR [r12+0xa8],r15
    200c:	mov    r13d,0x0
    2012:	mov    r14d,DWORD PTR [r12+0x80]
    201a:	mov    ecx,r14d
    201d:	mov    r15d,r13d
    2020:	or     r15,rcx
    2023:	mov    r15d,r15d
    2026:	mov    QWORD PTR [r12+0x38],r15
    202b:	mov    r13d,0x0
    2031:	mov    r14d,DWORD PTR [r12+0x70]
    2036:	mov    ecx,r14d
    2039:	mov    r15d,r13d
    203c:	or     r15,rcx
    203f:	mov    r15d,r15d
    2042:	mov    QWORD PTR [r12+0x98],r15
    204a:	mov    r13d,0x0
    2050:	mov    r14d,DWORD PTR [r12+0x68]
    2055:	mov    ecx,r14d
    2058:	mov    r15d,r13d
    205b:	or     r15,rcx
    205e:	mov    r15d,r15d
    2061:	mov    QWORD PTR [r12+0x28],r15
    2066:	mov    r13d,0x0
    206c:	mov    r14d,DWORD PTR [r12+0x60]
    2071:	mov    ecx,r14d
    2074:	mov    r15d,r13d
    2077:	or     r15,rcx
    207a:	mov    r15d,r15d
    207d:	mov    QWORD PTR [r12+0xb0],r15
    2085:	mov    r13d,0x0
    208b:	mov    r14d,DWORD PTR [r12+0x58]
    2090:	mov    ecx,r14d
    2093:	mov    r15d,r13d
    2096:	or     r15,rcx
    2099:	mov    r15d,r15d
    209c:	mov    QWORD PTR [r12+0xc0],r15
    20a4:	mov    r13d,0x0
    20aa:	mov    r14d,DWORD PTR [r12+0x90]
    20b2:	mov    ecx,r14d
    20b5:	mov    r15d,r13d
    20b8:	or     r15,rcx
    20bb:	mov    r15d,r15d
    20be:	mov    QWORD PTR [r12+0xc8],r15
    20c6:	mov    r13d,0x0
    20cc:	mov    r14d,DWORD PTR [r12+0x18]
    20d1:	mov    ecx,r14d
    20d4:	mov    r15d,r13d
    20d7:	or     r15,rcx
    20da:	mov    r15d,r15d
    20dd:	mov    QWORD PTR [r12+0xb8],r15
    20e5:	jmp    0x20ea
    20ea:	mov    r13d,0x0
    20f0:	mov    r14d,DWORD PTR [r12+0xb8]
    20f8:	mov    ecx,r14d
    20fb:	mov    r15d,r13d
    20fe:	or     r15,rcx
    2101:	mov    r15d,r15d
    2104:	mov    QWORD PTR [r12+0x30],r15
    2109:	mov    r13d,0x0
    210f:	mov    r14d,DWORD PTR [r12+0xc0]
    2117:	mov    ecx,r14d
    211a:	mov    r15d,r13d
    211d:	or     r15,rcx
    2120:	mov    r15d,r15d
    2123:	mov    QWORD PTR [r12+0xa0],r15
    212b:	mov    r13d,0x0
    2131:	mov    r14d,DWORD PTR [r12+0x28]
    2136:	mov    ecx,r14d
    2139:	mov    r15d,r13d
    213c:	or     r15,rcx
    213f:	mov    r15d,r15d
    2142:	mov    QWORD PTR [r12+0xc0],r15
    214a:	mov    r13d,0x0
    2150:	mov    r14d,DWORD PTR [r12+0x98]
    2158:	mov    ecx,r14d
    215b:	mov    r15d,r13d
    215e:	or     r15,rcx
    2161:	mov    r15d,r15d
    2164:	mov    QWORD PTR [r12+0x28],r15
    2169:	mov    r13d,0x0
    216f:	mov    r14d,DWORD PTR [r12+0x38]
    2174:	mov    ecx,r14d
    2177:	mov    r15d,r13d
    217a:	or     r15,rcx
    217d:	mov    r15d,r15d
    2180:	mov    QWORD PTR [r12+0x98],r15
    2188:	mov    r13d,0x0
    218e:	mov    r14d,DWORD PTR [r12+0xa8]
    2196:	mov    ecx,r14d
    2199:	mov    r15d,r13d
    219c:	or     r15,rcx
    219f:	mov    r15d,r15d
    21a2:	mov    QWORD PTR [r12+0x38],r15
    21a7:	mov    r13d,DWORD PTR [r12+0xb8]
    21af:	mov    r13d,r13d
    21b2:	ror    r13d,0x6
    21b6:	mov    QWORD PTR [r12+0xb8],r13
    21be:	mov    r13d,DWORD PTR [r12+0x30]
    21c3:	mov    r14d,DWORD PTR [r12+0xc8]
    21cb:	mov    ecx,r14d
    21ce:	and    r13,rcx
    21d1:	mov    r13d,r13d
    21d4:	mov    QWORD PTR [r12+0xa8],r13
    21dc:	mov    r15d,r15d
    21df:	ror    r15d,0x2
    21e3:	mov    QWORD PTR [r12+0xd0],r15
    21eb:	mov    r13d,0x0
    21f1:	mov    ecx,r14d
    21f4:	mov    r15d,r13d
    21f7:	or     r15,rcx
    21fa:	mov    r15d,r15d
    21fd:	mov    QWORD PTR [r12+0x20],r15
    2202:	mov    r13,QWORD PTR [r12+0x88]
    220a:	mov    r14,QWORD PTR [r12+0x50]
    220f:	mov    rcx,r13
    2212:	add    r14,rcx
    2215:	mov    r13d,DWORD PTR [r14]
    2218:	mov    QWORD PTR [r12+0xc8],r13
    2220:	mov    r13d,DWORD PTR [r12+0xa0]
    2228:	mov    r14d,DWORD PTR [r12+0x30]
    222d:	mov    ecx,r14d
    2230:	not    rcx
    2233:	and    r13,rcx
    2236:	mov    r13d,r13d
    2239:	mov    QWORD PTR [r12+0xd8],r13
    2241:	mov    r13d,DWORD PTR [r12+0xb0]
    2249:	mov    r15d,DWORD PTR [r12+0xa8]
    2251:	mov    ecx,r13d
    2254:	add    r15d,ecx
    2257:	mov    QWORD PTR [r12+0xa8],r15
    225f:	mov    r13d,DWORD PTR [r12+0xb8]
    2267:	mov    ebp,r14d
    226a:	mov    ebp,ebp
    226c:	shr    ebp,0xb
    226f:	mov    r14d,r14d
    2272:	shl    r14d,0x15
    2276:	mov    ecx,r14d
    2279:	or     rbp,rcx
    227c:	mov    ebp,ebp
    227e:	mov    ecx,ebp
    2280:	xor    r13,rcx
    2283:	mov    r13d,r13d
    2286:	mov    QWORD PTR [r12+0xb0],r13
    228e:	mov    r13d,DWORD PTR [r12+0xd0]
    2296:	mov    r14d,DWORD PTR [r12+0x38]
    229b:	mov    ebp,r14d
    229e:	mov    ebp,ebp
    22a0:	shr    ebp,0xd
    22a3:	mov    r14d,r14d
    22a6:	shl    r14d,0x13
    22aa:	mov    ecx,r14d
    22ad:	or     rbp,rcx
    22b0:	mov    ebp,ebp
    22b2:	mov    ecx,ebp
    22b4:	xor    r13,rcx
    22b7:	mov    r13d,r13d
    22ba:	mov    QWORD PTR [r12+0xd0],r13
    22c2:	mov    r13d,DWORD PTR [r12+0xd8]
    22ca:	mov    ecx,r13d
    22cd:	add    r15d,ecx
    22d0:	mov    QWORD PTR [r12+0xa8],r15
    22d8:	mov    r13,QWORD PTR [r12+0x88]
    22e0:	mov    r14,QWORD PTR [r12+0x48]
    22e5:	mov    rcx,r13
    22e8:	add    r14,rcx
    22eb:	mov    r13d,DWORD PTR [r14]
    22ee:	mov    QWORD PTR [r12+0xb8],r13
    22f6:	mov    r13d,DWORD PTR [r12+0x28]
    22fb:	mov    r14d,DWORD PTR [r12+0x98]
    2303:	mov    ecx,r14d
    2306:	mov    ebp,r13d
    2309:	and    rbp,rcx
    230c:	mov    ebp,ebp
    230e:	mov    QWORD PTR [r12+0xd8],rbp
    2316:	mov    ebp,DWORD PTR [r12+0xc8]
    231e:	mov    ecx,ebp
    2320:	add    r15d,ecx
    2323:	mov    QWORD PTR [r12+0xa8],r15
    232b:	mov    ecx,r14d
    232e:	xor    r13,rcx
    2331:	mov    r13d,r13d
    2334:	mov    QWORD PTR [r12+0xc8],r13
    233c:	mov    r14d,DWORD PTR [r12+0xb0]
    2344:	mov    r15d,DWORD PTR [r12+0x30]
    2349:	mov    ebp,r15d
    234c:	mov    ebp,ebp
    234e:	shr    ebp,0x19
    2351:	mov    r15d,r15d
    2354:	shl    r15d,0x7
    2358:	mov    ecx,r15d
    235b:	or     rbp,rcx
    235e:	mov    ebp,ebp
    2360:	mov    ecx,ebp
    2362:	xor    r14,rcx
    2365:	mov    r14d,r14d
    2368:	mov    QWORD PTR [r12+0xb0],r14
    2370:	mov    r14d,DWORD PTR [r12+0x38]
    2375:	mov    ecx,r14d
    2378:	and    r13,rcx
    237b:	mov    r13d,r13d
    237e:	mov    QWORD PTR [r12+0xc8],r13
    2386:	mov    r15d,DWORD PTR [r12+0xd0]
    238e:	mov    ebp,r14d
    2391:	mov    ebp,ebp
    2393:	shr    ebp,0x16
    2396:	mov    r14d,r14d
    2399:	shl    r14d,0xa
    239d:	mov    ecx,r14d
    23a0:	or     rbp,rcx
    23a3:	mov    ebp,ebp
    23a5:	mov    ecx,ebp
    23a7:	xor    r15,rcx
    23aa:	mov    r15d,r15d
    23ad:	mov    QWORD PTR [r12+0xd0],r15
    23b5:	mov    r14d,DWORD PTR [r12+0xb8]
    23bd:	mov    r15d,DWORD PTR [r12+0xa8]
    23c5:	mov    ecx,r14d
    23c8:	add    r15d,ecx
    23cb:	mov    QWORD PTR [r12+0xa8],r15
    23d3:	mov    r14d,DWORD PTR [r12+0xd8]
    23db:	mov    ecx,r14d
    23de:	xor    r13,rcx
    23e1:	mov    r13d,r13d
    23e4:	mov    QWORD PTR [r12+0xb8],r13
    23ec:	mov    r14d,DWORD PTR [r12+0xb0]
    23f4:	mov    ecx,r14d
    23f7:	add    r15d,ecx
    23fa:	mov    QWORD PTR [r12+0xa8],r15
    2402:	mov    r14,QWORD PTR [r12+0x88]
    240a:	add    r14,0x4
    240e:	mov    QWORD PTR [r12+0x88],r14
    2416:	mov    ebp,DWORD PTR [r12+0xd0]
    241e:	mov    ecx,ebp
    2420:	add    r13d,ecx
    2423:	mov    QWORD PTR [r12+0xb0],r13
    242b:	mov    ebp,DWORD PTR [r12+0xc0]
    2433:	mov    ecx,ebp
    2435:	mov    r8d,r15d
    2438:	add    r8d,ecx
    243b:	mov    QWORD PTR [r12+0xb8],r8
    2443:	sub    r14,0x100
    244a:	pushf
    244b:	pop    r11
    244d:	mov    QWORD PTR [rsp+0x48],r11
    2452:	mov    ecx,r15d
    2455:	add    r13d,ecx
    2458:	mov    QWORD PTR [r12+0xa8],r13
    2460:	mov    r13d,0x0
    2466:	mov    r14d,DWORD PTR [r12+0xa0]
    246e:	mov    ecx,r14d
    2471:	mov    r15d,r13d
    2474:	or     r15,rcx
    2477:	mov    r15d,r15d
    247a:	mov    QWORD PTR [r12+0xb0],r15
    2482:	mov    r13d,0x0
    2488:	mov    r14d,DWORD PTR [r12+0x20]
    248d:	mov    ecx,r14d
    2490:	mov    r15d,r13d
    2493:	or     r15,rcx
    2496:	mov    r15d,r15d
    2499:	mov    QWORD PTR [r12+0xc0],r15
    24a1:	mov    r13d,0x0
    24a7:	mov    r14d,DWORD PTR [r12+0x30]
    24ac:	mov    ecx,r14d
    24af:	mov    r15d,r13d
    24b2:	or     r15,rcx
    24b5:	mov    r15d,r15d
    24b8:	mov    QWORD PTR [r12+0xc8],r15
    24c0:	mov    rcx,QWORD PTR [r12+0x380]
    24c8:	jrcxz  0x24cf
    24ca:	jmp    0x2935
    24cf:	push   QWORD PTR [rsp+0x48]
    24d3:	popf
    24d4:	jne    0x20ea
    24da:	jmp    0x24df
    24df:	mov    r13d,DWORD PTR [r12+0x70]
    24e4:	mov    r14d,DWORD PTR [r12+0x98]
    24ec:	mov    ecx,r13d
    24ef:	add    r14d,ecx
    24f2:	mov    QWORD PTR [r12+0x70],r14
    24f7:	mov    r13d,DWORD PTR [r12+0x68]
    24fc:	mov    r14d,DWORD PTR [r12+0x28]
    2501:	mov    ecx,r13d
    2504:	add    r14d,ecx
    2507:	mov    QWORD PTR [r12+0x68],r14
    250c:	mov    r13d,0x0
    2512:	mov    QWORD PTR [r12+0x88],r13
    251a:	mov    r13d,DWORD PTR [r12+0x78]
    251f:	mov    r14d,DWORD PTR [r12+0xa8]
    2527:	mov    ecx,r13d
    252a:	add    r14d,ecx
    252d:	mov    QWORD PTR [r12+0x78],r14
    2532:	mov    r13d,DWORD PTR [r12+0x80]
    253a:	mov    r14d,DWORD PTR [r12+0x38]
    253f:	mov    ecx,r13d
    2542:	add    r14d,ecx
    2545:	mov    QWORD PTR [r12+0x80],r14
    254d:	mov    r13,QWORD PTR [r12]
    2551:	add    r13,0x8
    2555:	mov    r14,r13
    2558:	add    r14,0x4
    255c:	mov    r15d,DWORD PTR [r12+0x70]
    2561:	mov    ebp,DWORD PTR [r12+0x68]
    2566:	mov    DWORD PTR [r13+0x0],r15d
    256a:	mov    r13d,0x0
    2570:	mov    DWORD PTR [r12+0x32c],r13d
    2578:	mov    DWORD PTR [r14],ebp
    257b:	mov    r13d,0x0
    2581:	mov    DWORD PTR [r12+0x32c],r13d
    2589:	mov    r13d,DWORD PTR [r12+0x18]
    258e:	mov    r14d,DWORD PTR [r12+0xb8]
    2596:	mov    ecx,r13d
    2599:	add    r14d,ecx
    259c:	mov    QWORD PTR [r12+0x68],r14
    25a1:	mov    r13d,DWORD PTR [r12+0x90]
    25a9:	mov    r14d,DWORD PTR [r12+0x30]
    25ae:	mov    ecx,r13d
    25b1:	add    r14d,ecx
    25b4:	mov    QWORD PTR [r12+0x70],r14
    25b9:	mov    r13d,DWORD PTR [r12+0x58]
    25be:	mov    r14d,DWORD PTR [r12+0x20]
    25c3:	mov    ecx,r13d
    25c6:	add    r14d,ecx
    25c9:	mov    QWORD PTR [r12+0x58],r14
    25ce:	mov    r13d,DWORD PTR [r12+0x60]
    25d3:	mov    r14d,DWORD PTR [r12+0xa0]
    25db:	mov    ecx,r13d
    25de:	add    r14d,ecx
    25e1:	mov    QWORD PTR [r12+0x60],r14
    25e6:	mov    r13,QWORD PTR [r12]
    25ea:	mov    r15,r13
    25ed:	add    r15,0x4
    25f1:	mov    ebp,DWORD PTR [r12+0x78]
    25f6:	mov    r8d,DWORD PTR [r12+0x80]
    25fe:	mov    DWORD PTR [r13+0x0],ebp
    2602:	mov    ebp,0x0
    2607:	mov    DWORD PTR [r12+0x32c],ebp
    260f:	mov    DWORD PTR [r15],r8d
    2612:	mov    r15d,0x0
    2618:	mov    DWORD PTR [r12+0x32c],r15d
    2620:	mov    r15,r13
    2623:	add    r15,0x10
    2627:	mov    rbp,r15
    262a:	add    rbp,0x4
    262e:	mov    r8d,DWORD PTR [r12+0x68]
    2633:	mov    r9d,DWORD PTR [r12+0x70]
    2638:	mov    DWORD PTR [r15],r8d
    263b:	mov    r15d,0x0
    2641:	mov    DWORD PTR [r12+0x32c],r15d
    2649:	mov    DWORD PTR [rbp+0x0],r9d
    264d:	mov    r15d,0x0
    2653:	mov    DWORD PTR [r12+0x32c],r15d
    265b:	mov    r15,r13
    265e:	add    r15,0x18
    2662:	mov    rbp,r15
    2665:	add    rbp,0x4
    2669:	mov    r8d,DWORD PTR [r12+0x58]
    266e:	mov    DWORD PTR [r15],r8d
    2671:	mov    r15d,0x0
    2677:	mov    DWORD PTR [r12+0x32c],r15d
    267f:	mov    DWORD PTR [rbp+0x0],r14d
    2683:	mov    r14d,0x0
    2689:	mov    DWORD PTR [r12+0x32c],r14d
    2691:	add    r13,0x68
    2695:	mov    r14d,0x0
    269b:	mov    QWORD PTR [r13+0x0],r14
    269f:	mov    r13d,0x0
    26a5:	mov    DWORD PTR [r12+0x32c],r13d
    26ad:	mov    rcx,QWORD PTR [r12+0x380]
    26b5:	jrcxz  0x26bc
    26b7:	jmp    0x29bc
    26bc:	jmp    0x26c1
    26c1:	mov    r13,QWORD PTR [r12+0x10]
    26c6:	sub    r13,0x1
    26ca:	mov    QWORD PTR [r12+0x10],r13
    26cf:	mov    rax,r13
    26d2:	test   rax,rax
    26d5:	sete   al
    26d8:	movzx  eax,al
    26db:	and    eax,0x1
    26de:	mov    r14,rax
    26e1:	mov    rax,r14
    26e4:	and    eax,0x1
    26e7:	test   rax,rax
    26ea:	jne    0x26f5
    26f0:	jmp    0x217
    26f5:	mov    r13,QWORD PTR [r12+0xf8]
    26fd:	mov    r14,r13
    2700:	add    r14,0x140
    2707:	mov    r15,r14
    270a:	add    r15,0x8
    270e:	mov    rbp,QWORD PTR [r14]
    2711:	mov    r14,QWORD PTR [r15]
    2714:	mov    QWORD PTR [r12+0xa0],rbp
    271c:	mov    QWORD PTR [r12+0x98],r14
    2724:	mov    r14,r13
    2727:	add    r14,0x130
    272e:	mov    r15,r14
    2731:	add    r15,0x8
    2735:	mov    rbp,QWORD PTR [r14]
    2738:	mov    r14,QWORD PTR [r15]
    273b:	mov    QWORD PTR [r12+0xb0],rbp
    2743:	mov    QWORD PTR [r12+0xa8],r14
    274b:	mov    r14,r13
    274e:	add    r14,0x120
    2755:	mov    r15,r14
    2758:	add    r15,0x8
    275c:	mov    rbp,QWORD PTR [r14]
    275f:	mov    r14,QWORD PTR [r15]
    2762:	mov    QWORD PTR [r12+0xc0],rbp
    276a:	mov    QWORD PTR [r12+0xb8],r14
    2772:	add    r13,0x110
    2779:	mov    r14,r13
    277c:	add    r14,0x8
    2780:	mov    r15,QWORD PTR [r13+0x0]
    2784:	mov    r13,QWORD PTR [r14]
    2787:	mov    QWORD PTR [r12+0xd0],r15
    278f:	mov    QWORD PTR [r12+0xc8],r13
    2797:	mov    r13,QWORD PTR [r12+0xf8]
    279f:	mov    r14,r13
    27a2:	add    r14,0x100
    27a9:	mov    r15,r14
    27ac:	add    r15,0x8
    27b0:	mov    rbp,QWORD PTR [r14]
    27b3:	mov    r14,QWORD PTR [r15]
    27b6:	mov    QWORD PTR [r12+0xe8],rbp
    27be:	mov    QWORD PTR [r12+0xd8],r14
    27c6:	add    r13,0x150
    27cd:	mov    QWORD PTR [r12+0xf8],r13
    27d5:	jmp    0x27da
    27da:	mov    rcx,QWORD PTR [r12+0x380]
    27e2:	jrcxz  0x27e9
    27e4:	jmp    0x2a43
    27e9:	mov    r13,QWORD PTR [r12+0xf0]
    27f1:	mov    QWORD PTR [r12+0x100],r13
    27f9:	mov    r11,QWORD PTR [rsp+0x48]
    27fe:	mov    QWORD PTR [r12+0x398],r11
    2806:	mov    rdi,QWORD PTR [r12+0x100]
    280e:	add    rsp,0x50
    2812:	movabs r11,0x58b3990a40a0
    281c:	jmp    r11
    281f:	mov    eax,0x41039c
    2824:	mov    QWORD PTR [r12+0x100],rax
    282c:	push   rdx
    282d:	push   rsi
    282e:	push   r10
    2830:	push   r11
    2832:	pushf
    2833:	pop    r11
    2835:	mov    QWORD PTR [rsp+0x68],r11
    283a:	mov    rdx,QWORD PTR [rsp+0x68]
    283f:	mov    r10d,edx
    2842:	and    r10d,0xc0
    2849:	shl    r10d,0x18
    284d:	mov    r11d,edx
    2850:	and    r11d,0x1
    2854:	shl    r11d,0x1d
    2858:	or     r10d,r11d
    285b:	mov    r11d,edx
    285e:	and    r11d,0x800
    2865:	shl    r11d,0x11
    2869:	or     r10d,r11d
    286c:	btc    r10,0x1d
    2871:	mov    r11d,0xf0000000
    2877:	and    r11,r10
    287a:	movabs rsi,0xffffffff0fffffff
    2884:	and    rbx,rsi
    2887:	or     rbx,r11
    288a:	pop    r11
    288c:	pop    r10
    288e:	pop    rsi
    288f:	pop    rdx
    2890:	mov    QWORD PTR [r12+0x108],rbx
    2898:	add    rsp,0x50
    289c:	mov    eax,0xc
    28a1:	movabs r11,0x58b3990a4390
    28ab:	jmp    r11
    28ae:	mov    eax,0x410498
    28b3:	mov    QWORD PTR [r12+0x100],rax
    28bb:	push   rdx
    28bc:	push   rsi
    28bd:	push   r10
    28bf:	push   r11
    28c1:	mov    rdx,QWORD PTR [rsp+0x68]
    28c6:	mov    r10d,edx
    28c9:	and    r10d,0xc0
    28d0:	shl    r10d,0x18
    28d4:	mov    r11d,edx
    28d7:	and    r11d,0x1
    28db:	shl    r11d,0x1d
    28df:	or     r10d,r11d
    28e2:	mov    r11d,edx
    28e5:	and    r11d,0x800
    28ec:	shl    r11d,0x11
    28f0:	or     r10d,r11d
    28f3:	btc    r10,0x1d
    28f8:	mov    r11d,0xf0000000
    28fe:	and    r11,r10
    2901:	movabs rsi,0xffffffff0fffffff
    290b:	and    rbx,rsi
    290e:	or     rbx,r11
    2911:	pop    r11
    2913:	pop    r10
    2915:	pop    rsi
    2916:	pop    rdx
    2917:	mov    QWORD PTR [r12+0x108],rbx
    291f:	add    rsp,0x50
    2923:	mov    eax,0xc
    2928:	movabs r11,0x58b3990a4390
    2932:	jmp    r11
    2935:	mov    eax,0x410558
    293a:	mov    QWORD PTR [r12+0x100],rax
    2942:	push   rdx
    2943:	push   rsi
    2944:	push   r10
    2946:	push   r11
    2948:	mov    rdx,QWORD PTR [rsp+0x68]
    294d:	mov    r10d,edx
    2950:	and    r10d,0xc0
    2957:	shl    r10d,0x18
    295b:	mov    r11d,edx
    295e:	and    r11d,0x1
    2962:	shl    r11d,0x1d
    2966:	or     r10d,r11d
    2969:	mov    r11d,edx
    296c:	and    r11d,0x800
    2973:	shl    r11d,0x11
    2977:	or     r10d,r11d
    297a:	btc    r10,0x1d
    297f:	mov    r11d,0xf0000000
    2985:	and    r11,r10
    2988:	movabs rsi,0xffffffff0fffffff
    2992:	and    rbx,rsi
    2995:	or     rbx,r11
    2998:	pop    r11
    299a:	pop    r10
    299c:	pop    rsi
    299d:	pop    rdx
    299e:	mov    QWORD PTR [r12+0x108],rbx
    29a6:	add    rsp,0x50
    29aa:	mov    eax,0xc
    29af:	movabs r11,0x58b3990a4390
    29b9:	jmp    r11
    29bc:	mov    eax,0x410594
    29c1:	mov    QWORD PTR [r12+0x100],rax
    29c9:	push   rdx
    29ca:	push   rsi
    29cb:	push   r10
    29cd:	push   r11
    29cf:	mov    rdx,QWORD PTR [rsp+0x68]
    29d4:	mov    r10d,edx
    29d7:	and    r10d,0xc0
    29de:	shl    r10d,0x18
    29e2:	mov    r11d,edx
    29e5:	and    r11d,0x1
    29e9:	shl    r11d,0x1d
    29ed:	or     r10d,r11d
    29f0:	mov    r11d,edx
    29f3:	and    r11d,0x800
    29fa:	shl    r11d,0x11
    29fe:	or     r10d,r11d
    2a01:	btc    r10,0x1d
    2a06:	mov    r11d,0xf0000000
    2a0c:	and    r11,r10
    2a0f:	movabs rsi,0xffffffff0fffffff
    2a19:	and    rbx,rsi
    2a1c:	or     rbx,r11
    2a1f:	pop    r11
    2a21:	pop    r10
    2a23:	pop    rsi
    2a24:	pop    rdx
    2a25:	mov    QWORD PTR [r12+0x108],rbx
    2a2d:	add    rsp,0x50
    2a31:	mov    eax,0xc
    2a36:	movabs r11,0x58b3990a4390
    2a40:	jmp    r11
    2a43:	mov    eax,0x4105b0
    2a48:	mov    QWORD PTR [r12+0x100],rax
    2a50:	push   rdx
    2a51:	push   rsi
    2a52:	push   r10
    2a54:	push   r11
    2a56:	mov    rdx,QWORD PTR [rsp+0x68]
    2a5b:	mov    r10d,edx
    2a5e:	and    r10d,0xc0
    2a65:	shl    r10d,0x18
    2a69:	mov    r11d,edx
    2a6c:	and    r11d,0x1
    2a70:	shl    r11d,0x1d
    2a74:	or     r10d,r11d
    2a77:	mov    r11d,edx
    2a7a:	and    r11d,0x800
    2a81:	shl    r11d,0x11
    2a85:	or     r10d,r11d
    2a88:	btc    r10,0x1d
    2a8d:	mov    r11d,0xf0000000
    2a93:	and    r11,r10
    2a96:	movabs rsi,0xffffffff0fffffff
    2aa0:	and    rbx,rsi
    2aa3:	or     rbx,r11
    2aa6:	pop    r11
    2aa8:	pop    r10
    2aaa:	pop    rsi
    2aab:	pop    rdx
    2aac:	mov    QWORD PTR [r12+0x108],rbx
    2ab4:	add    rsp,0x50
    2ab8:	mov    eax,0xc
    2abd:	movabs r11,0x58b3990a4390
    2ac7:	jmp    r11
    2aca:	nop    WORD PTR [rax+rax*1+0x0]
    2ad0:	sub    rsp,0x50
    2ad4:	mov    r11,QWORD PTR [r12+0x398]
    2adc:	mov    QWORD PTR [rsp+0x48],r11
    2ae1:	jmp    0x6b
    2ae6:	data16 nop WORD PTR [rax+rax*1+0x0]
    2af0:	sub    rsp,0x50
    2af4:	mov    r11,QWORD PTR [r12+0x398]
    2afc:	mov    QWORD PTR [rsp+0x48],r11
    2b01:	jmp    0x217
    2b06:	data16 nop WORD PTR [rax+rax*1+0x0]
    2b10:	sub    rsp,0x50
    2b14:	mov    r11,QWORD PTR [r12+0x398]
    2b1c:	mov    QWORD PTR [rsp+0x48],r11
    2b21:	jmp    0x2c1
    2b26:	data16 nop WORD PTR [rax+rax*1+0x0]
    2b30:	sub    rsp,0x50
    2b34:	mov    r11,QWORD PTR [r12+0x398]
    2b3c:	mov    QWORD PTR [rsp+0x48],r11
    2b41:	jmp    0x1ddc
    2b46:	data16 nop WORD PTR [rax+rax*1+0x0]
    2b50:	sub    rsp,0x50
    2b54:	mov    r11,QWORD PTR [r12+0x398]
    2b5c:	mov    QWORD PTR [rsp+0x48],r11
    2b61:	jmp    0x1f65
    2b66:	data16 nop WORD PTR [rax+rax*1+0x0]
    2b70:	sub    rsp,0x50
    2b74:	mov    r11,QWORD PTR [r12+0x398]
    2b7c:	mov    QWORD PTR [rsp+0x48],r11
    2b81:	jmp    0x20ea
    2b86:	data16 nop WORD PTR [rax+rax*1+0x0]
    2b90:	sub    rsp,0x50
    2b94:	mov    r11,QWORD PTR [r12+0x398]
    2b9c:	mov    QWORD PTR [rsp+0x48],r11
    2ba1:	jmp    0x24df
    2ba6:	data16 nop WORD PTR [rax+rax*1+0x0]
    2bb0:	sub    rsp,0x50
    2bb4:	mov    r11,QWORD PTR [r12+0x398]
    2bbc:	mov    QWORD PTR [rsp+0x48],r11
    2bc1:	jmp    0x26c1
    2bc6:	data16 nop WORD PTR [rax+rax*1+0x0]
    2bd0:	sub    rsp,0x50
    2bd4:	mov    r11,QWORD PTR [r12+0x398]
    2bdc:	mov    QWORD PTR [rsp+0x48],r11
    2be1:	jmp    0x26f5
    2be6:	data16 nop WORD PTR [rax+rax*1+0x0]
    2bf0:	sub    rsp,0x50
    2bf4:	mov    r11,QWORD PTR [r12+0x398]
    2bfc:	mov    QWORD PTR [rsp+0x48],r11
    2c01:	jmp    0x27da
    2c06:	nop
    2c07:	nop
