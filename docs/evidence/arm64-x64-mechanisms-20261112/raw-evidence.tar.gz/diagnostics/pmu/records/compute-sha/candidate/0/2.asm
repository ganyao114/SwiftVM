
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sha/candidate/0/2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13d,DWORD PTR [r12+0xa0]
   c:	sub    r13d,0x1
  10:	mov    QWORD PTR [r12+0xa0],r13
  18:	mov    rcx,QWORD PTR [r12+0x380]
  20:	jrcxz  0x27
  22:	jmp    0x19d
  27:	pushf
  28:	pop    r11
  2a:	mov    QWORD PTR [rsp],r11
  2e:	jne    0x105
  34:	jmp    0x39
  39:	mov    r13,QWORD PTR [r12+0xf8]
  41:	mov    r14,r13
  44:	add    r14,0x20
  48:	mov    r15,QWORD PTR [r14]
  4b:	mov    QWORD PTR [r12+0x98],r15
  53:	mov    r14d,0x80
  59:	mov    QWORD PTR [r12+0x40],r14
  5e:	mov    r14,r13
  61:	add    r14,0x0
  65:	mov    QWORD PTR [r12],r14
  69:	mov    r14,r13
  6c:	add    r14,0x8c
  73:	mov    QWORD PTR [r12+0x8],r14
  78:	mov    r14d,0x1
  7e:	mov    QWORD PTR [r12+0x10],r14
  83:	add    r13,0x8c
  8a:	movzx  r14d,BYTE PTR [r12+0x40]
  90:	mov    BYTE PTR [r13+0x0],r14b
  94:	mov    r13d,0x0
  9a:	mov    DWORD PTR [r12+0x32c],r13d
  a2:	mov    r13d,0x410298
  a8:	mov    QWORD PTR [r12+0xf0],r13
  b0:	mov    r13d,0x410338
  b6:	mov    QWORD PTR [r12+0x100],r13
  be:	mov    r11,QWORD PTR [rsp]
  c2:	mov    QWORD PTR [r12+0x398],r11
  ca:	mov    edi,0x410338
  cf:	mov    QWORD PTR [r12+0x100],rdi
  d7:	add    rsp,0x10
  db:	nop    DWORD PTR [rax+rax*1+0x0]
  e0:	jmp    QWORD PTR [rip+0x2]        # 0xe8
  e6:	xchg   ax,ax
  e8:	loopne 0xd1
  ea:	out    dx,eax
  eb:	(bad)
  f0:	call   0x1562f109
  f5:	js     0xf7
  f7:	add    BYTE PTR [rcx-0x45],cl
  fa:	movabs al,ds:0x41000058b3990a40
 103:	jmp    rbx
 105:	mov    r13,QWORD PTR [r12+0xf8]
 10d:	add    r13,0x0
 111:	mov    QWORD PTR [r12],r13
 115:	mov    r13d,0x0
 11b:	mov    r14,QWORD PTR [r12+0x98]
 123:	mov    rcx,r14
 126:	or     r13,rcx
 129:	mov    QWORD PTR [r12+0x8],r13
 12e:	mov    r13d,0x12c
 134:	mov    QWORD PTR [r12+0x10],r13
 139:	mov    r13d,0x410274
 13f:	mov    QWORD PTR [r12+0xf0],r13
 147:	mov    r13d,0x410338
 14d:	mov    QWORD PTR [r12+0x100],r13
 155:	mov    r11,QWORD PTR [rsp]
 159:	mov    QWORD PTR [r12+0x398],r11
 161:	mov    edi,0x410338
 166:	mov    QWORD PTR [r12+0x100],rdi
 16e:	add    rsp,0x10
 172:	nop    WORD PTR [rax+rax*1+0x0]
 178:	jmp    QWORD PTR [rip+0x2]        # 0x180
 17e:	xchg   ax,ax
 180:	loopne 0x169
 182:	out    dx,eax
 183:	(bad)
 188:	adc    BYTE PTR [rip+0x781562f0],0x0        # 0x7815647f
 18f:	add    BYTE PTR [rcx-0x45],cl
 192:	movabs al,ds:0x41000058b3990a40
 19b:	jmp    rbx
 19d:	mov    eax,0x410278
 1a2:	mov    QWORD PTR [r12+0x100],rax
 1aa:	push   rdx
 1ab:	push   rsi
 1ac:	push   r10
 1ae:	push   r11
 1b0:	pushf
 1b1:	pop    r11
 1b3:	mov    QWORD PTR [rsp+0x20],r11
 1b8:	mov    rdx,QWORD PTR [rsp+0x20]
 1bd:	mov    r10d,edx
 1c0:	and    r10d,0xc0
 1c7:	shl    r10d,0x18
 1cb:	mov    r11d,edx
 1ce:	and    r11d,0x1
 1d2:	shl    r11d,0x1d
 1d6:	or     r10d,r11d
 1d9:	mov    r11d,edx
 1dc:	and    r11d,0x800
 1e3:	shl    r11d,0x11
 1e7:	or     r10d,r11d
 1ea:	btc    r10,0x1d
 1ef:	mov    r11d,0xf0000000
 1f5:	and    r11,r10
 1f8:	movabs rsi,0xffffffff0fffffff
 202:	and    rbx,rsi
 205:	or     rbx,r11
 208:	pop    r11
 20a:	pop    r10
 20c:	pop    rsi
 20d:	pop    rdx
 20e:	mov    QWORD PTR [r12+0x108],rbx
 216:	add    rsp,0x10
 21a:	mov    eax,0xc
 21f:	movabs r11,0x58b3990a4390
 229:	jmp    r11
 22c:	nop    DWORD PTR [rax+0x0]
 230:	sub    rsp,0x10
 234:	mov    r11,QWORD PTR [r12+0x398]
 23c:	mov    QWORD PTR [rsp],r11
 240:	jmp    0x39
 245:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 250:	sub    rsp,0x10
 254:	mov    r11,QWORD PTR [r12+0x398]
 25c:	mov    QWORD PTR [rsp],r11
 260:	jmp    0x105
 265:	nop
 266:	nop
 267:	nop
