
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sha/baseline/0/4.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13,QWORD PTR [r12+0xf8]
   8:	mov    r14,r13
   b:	add    r14,0x68
   f:	mov    r13,QWORD PTR [r14]
  12:	mov    QWORD PTR [r12+0x40],r13
  17:	mov    r14,r13
  1a:	sub    r14,0x38
  1e:	pushf
  1f:	pop    rdx
  20:	mov    r10d,edx
  23:	and    r10d,0xc0
  2a:	shl    r10d,0x18
  2e:	mov    r11d,edx
  31:	and    r11d,0x1
  35:	shl    r11d,0x1d
  39:	or     r10d,r11d
  3c:	mov    r11d,edx
  3f:	and    r11d,0x800
  46:	shl    r11d,0x11
  4a:	or     r10d,r11d
  4d:	mov    r11d,0xf0000000
  53:	and    r11,r10
  56:	movabs rsi,0xffffffff0fffffff
  60:	and    rbx,rsi
  63:	or     rbx,r11
  66:	btc    rbx,0x1d
  6b:	cmp    QWORD PTR [r12+0x380],0x0
  74:	je     0xa1
  7a:	mov    eax,0x4102c0
  7f:	mov    QWORD PTR [r12+0x100],rax
  87:	mov    QWORD PTR [r12+0x108],rbx
  8f:	mov    eax,0xc
  94:	movabs r11,0x56b97c5905f0
  9e:	jmp    r11
  a1:	test   ebx,0x40000000
  a7:	je     0xfd
  ad:	jmp    0xb2
  b2:	mov    r13d,0x4102c4
  b8:	mov    QWORD PTR [r12+0x100],r13
  c0:	mov    QWORD PTR [r12+0x108],rbx
  c8:	mov    edi,0x4102c4
  cd:	mov    QWORD PTR [r12+0x100],rdi
  d5:	nop    DWORD PTR [rax]
  d8:	jmp    QWORD PTR [rip+0x2]        # 0xe0
  de:	xchg   ax,ax
  e0:	mov    al,0x1f
  e2:	push   rax
  e3:	ret
  e4:	add    al,0x79
  e6:	add    BYTE PTR [rax],al
  e8:	mov    al,0x20
  ea:	push   rax
  eb:	ret
  ec:	add    al,0x79
  ee:	add    BYTE PTR [rax],al
  f0:	movabs r11,0x56b97c590370
  fa:	jmp    r11
  fd:	mov    r13d,0x4102a8
 103:	mov    QWORD PTR [r12+0x100],r13
 10b:	mov    QWORD PTR [r12+0x108],rbx
 113:	mov    edi,0x4102a8
 118:	mov    QWORD PTR [r12+0x100],rdi
 120:	jmp    QWORD PTR [rip+0x2]        # 0x128
 126:	xchg   ax,ax
 128:	movabs al,ds:0xf800007904c3501f
 131:	and    BYTE PTR [rax-0x3d],dl
 134:	add    al,0x79
 136:	add    BYTE PTR [rax],al
 138:	movabs r11,0x56b97c590370
 142:	jmp    r11
 145:	nop
 146:	nop
 147:	nop
