00007aeba69ce69b  nop [rax+rax*1], eax
00007aeba69ce6a0  mov rax, [r15+0xF8]
00007aeba69ce6a7  lea r14, [rax-0xA0]
00007aeba69ce6ae  mov [r15+0xF8], r14
00007aeba69ce6b5  lea rax, [r14+0x90]
00007aeba69ce6bc  mov r12, [r15+0xA0]
00007aeba69ce6c3  mov r11, [r15+0x98]
00007aeba69ce6ca  mov [r13+rax*1], r12
00007aeba69ce6cf  lea rax, [r14+0x98]
00007aeba69ce6d6  mov [r13+rax*1], r11
00007aeba69ce6db  mov eax, 0x420670
00007aeba69ce6e0  movups xmm1, [r13+rax*1]
00007aeba69ce6e6  mov eax, 0x420610
00007aeba69ce6eb  movups xmm15, [r13+rax*1]
00007aeba69ce6f1  mov eax, 0x420690
00007aeba69ce6f6  movups xmm14, [r13+rax*1]
00007aeba69ce6fc  mov eax, 0x420630
00007aeba69ce701  movups xmm13, [r13+rax*1]
00007aeba69ce707  mov qword ptr [r15+0x98], 0x4308A0
00007aeba69ce712  mov eax, 0x4206A0
00007aeba69ce717  movups xmm12, [r13+rax*1]
00007aeba69ce71d  mov eax, 0x4308A0
00007aeba69ce722  movups [r13+rax*1], xmm1
00007aeba69ce728  mov eax, 0x4308B0
00007aeba69ce72d  movups [r13+rax*1], xmm15
00007aeba69ce733  mov eax, 0x4308C0
00007aeba69ce738  movups [r13+rax*1], xmm14
00007aeba69ce73e  mov eax, 0x4308D0
00007aeba69ce743  movups [r13+rax*1], xmm13
00007aeba69ce749  mov eax, 0x420600
00007aeba69ce74e  movups xmm14, [r13+rax*1]
00007aeba69ce754  mov eax, 0x4205F0
00007aeba69ce759  movups xmm13, [r13+rax*1]
00007aeba69ce75f  mov eax, 0x4309A0
00007aeba69ce764  movups [r13+rax*1], xmm1
00007aeba69ce76a  mov eax, 0x4309B0
00007aeba69ce76f  movups [r13+rax*1], xmm15
00007aeba69ce775  mov eax, 0x4308E0
00007aeba69ce77a  movups [r13+rax*1], xmm12
00007aeba69ce780  mov eax, 0x4308F0
00007aeba69ce785  movups [r13+rax*1], xmm14
00007aeba69ce78b  mov eax, 0x4205E0
00007aeba69ce790  movups xmm1, [r13+rax*1]
00007aeba69ce796  mov eax, 0x420640
00007aeba69ce79b  movups xmm15, [r13+rax*1]
00007aeba69ce7a1  mov eax, 0x430900
00007aeba69ce7a6  movups [r13+rax*1], xmm13
00007aeba69ce7ac  mov eax, 0x430910
00007aeba69ce7b1  movups [r13+rax*1], xmm1
00007aeba69ce7b7  mov eax, 0x420650
00007aeba69ce7bc  movups xmm1, [r13+rax*1]
00007aeba69ce7c2  mov eax, 0x420620
00007aeba69ce7c7  movups xmm14, [r13+rax*1]
00007aeba69ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007aeba69ce7d5  mov eax, 0x430920
00007aeba69ce7da  movups [r13+rax*1], xmm15
00007aeba69ce7e0  mov eax, 0x430930
00007aeba69ce7e5  movups [r13+rax*1], xmm1
00007aeba69ce7eb  mov eax, 0x4206C0
00007aeba69ce7f0  movups xmm1, [r13+rax*1]
00007aeba69ce7f6  mov eax, 0x4206D0
00007aeba69ce7fb  movups xmm15, [r13+rax*1]
00007aeba69ce801  movaps [r15+0x150], xmm15
00007aeba69ce809  mov qword ptr [r15+0xA0], 0x3E8
00007aeba69ce814  mov eax, 0x430940
00007aeba69ce819  movups [r13+rax*1], xmm14
00007aeba69ce81f  mov eax, 0x430950
00007aeba69ce824  movups [r13+rax*1], xmm1
00007aeba69ce82a  mov eax, 0x4206B0
00007aeba69ce82f  movups xmm1, [r13+rax*1]
00007aeba69ce835  mov eax, 0x420660
00007aeba69ce83a  movups xmm14, [r13+rax*1]
00007aeba69ce840  movaps [r15+0x140], xmm14
00007aeba69ce848  lea rax, [r14+0x80]
00007aeba69ce84f  mov r12, [r15+0xF0]
00007aeba69ce856  mov [r13+rax*1], r12
00007aeba69ce85b  mov eax, 0x430960
00007aeba69ce860  movups [r13+rax*1], xmm15
00007aeba69ce866  mov eax, 0x430970
00007aeba69ce86b  movups [r13+rax*1], xmm1
00007aeba69ce871  mov eax, 0x420680
00007aeba69ce876  movups xmm1, [r13+rax*1]
00007aeba69ce87c  mov eax, 0x4206E0
00007aeba69ce881  mov r12, [r13+rax*1]
00007aeba69ce886  movq xmm15, r12
00007aeba69ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007aeba69ce893  mov eax, 0x430980
00007aeba69ce898  movups [r13+rax*1], xmm14
00007aeba69ce89e  mov eax, 0x430990
00007aeba69ce8a3  movups [r13+rax*1], xmm1
00007aeba69ce8a9  mov eax, 0x420748
00007aeba69ce8ae  movups xmm1, [r13+rax*1]
00007aeba69ce8b4  movq rax, xmm15
00007aeba69ce8b9  mov r12d, 0x4309C0
00007aeba69ce8bf  mov [r13+r12*1], rax
00007aeba69ce8c4  mov eax, 0x420728
00007aeba69ce8c9  movups xmm15, [r13+rax*1]
00007aeba69ce8cf  mov eax, 0x420738
00007aeba69ce8d4  movups xmm14, [r13+rax*1]
00007aeba69ce8da  lea rax, [r14+0x60]
00007aeba69ce8de  movups [r13+rax*1], xmm1
00007aeba69ce8e4  mov eax, 0x4309C8
00007aeba69ce8e9  mov r12d, 0x421DF8D3
00007aeba69ce8ef  mov [r13+rax*1], r12d
00007aeba69ce8f4  lea rax, [r14+0x40]
00007aeba69ce8f8  movups [r13+rax*1], xmm15
00007aeba69ce8fe  lea rax, [r14+0x50]
00007aeba69ce902  movups [r13+rax*1], xmm14
00007aeba69ce908  mov eax, 0x4206E8
00007aeba69ce90d  movups xmm1, [r13+rax*1]
00007aeba69ce913  mov eax, 0x4206F8
00007aeba69ce918  movups xmm15, [r13+rax*1]
00007aeba69ce91e  movaps [r15+0x120], xmm15
00007aeba69ce926  movups [r13+r14*1], xmm1
00007aeba69ce92c  lea rax, [r14+0x10]
00007aeba69ce930  movups [r13+rax*1], xmm15
00007aeba69ce936  mov eax, 0x420708
00007aeba69ce93b  movups xmm1, [r13+rax*1]
00007aeba69ce941  mov eax, 0x420718
00007aeba69ce946  movups xmm15, [r13+rax*1]
00007aeba69ce94c  movaps [r15+0x110], xmm1
00007aeba69ce954  movaps [r15+0x130], xmm15
00007aeba69ce95c  lea rax, [r14+0x20]
00007aeba69ce960  movups [r13+rax*1], xmm1
00007aeba69ce966  lea rax, [r14+0x30]
00007aeba69ce96a  movups [r13+rax*1], xmm15
00007aeba69ce970  mov [r15], r14
00007aeba69ce973  mov qword ptr [r15+0x08], 0x4308A0
00007aeba69ce97b  mov qword ptr [r15+0x10], 0x12C
00007aeba69ce983  mov qword ptr [r15+0xF0], 0x410274
00007aeba69ce98e  mov r14d, [r15+0x320]
00007aeba69ce995  mov eax, 0x410274
00007aeba69ce99a  mov rcx, 0x7AEBA69D0670
00007aeba69ce9a4  mov [r15+r14*8+0x328], rax
00007aeba69ce9ac  mov [r15+r14*8+0x368], rcx
00007aeba69ce9b4  add r14d, 0x01
00007aeba69ce9b8  and r14d, 0x07
00007aeba69ce9bc  mov [r15+0x320], r14d
00007aeba69ce9c3  cmp dword ptr [r15+0x318], 0x00
00007aeba69ce9cb  jz 0x00007AEBA69CEC20
00007aeba69ce9d1  nop [rax+rax*1], ax
00007aeba69ce9da  nop [rax+rax*1], eax
00007aeba69ce9e2  mov eax, 0x410338
00007aeba69ce9e7  mov [r15+0x100], rax
00007aeba69ce9ee  jmp 0x00007AEBA67FE110
00007aeba69ce9f3  int3
00007aeba69ce9f4  call 0x00007AEBA680BC20
00007aeba69ce9f9  jmp 0x00007AEBA69CE6CF
00007aeba69ce9fe  call 0x00007AEBA680A9A0
00007aeba69cea03  jmp 0x00007AEBA69CE6DB
00007aeba69cea08  call 0x00007AEBA67FF430
00007aeba69cea0d  jmp 0x00007AEBA69CE6E6
00007aeba69cea12  call 0x00007AEBA680E760
00007aeba69cea17  jmp 0x00007AEBA69CE6F1
00007aeba69cea1c  call 0x00007AEBA680D4E0
00007aeba69cea21  jmp 0x00007AEBA69CE6FC
00007aeba69cea26  call 0x00007AEBA680C260
00007aeba69cea2b  jmp 0x00007AEBA69CE707
00007aeba69cea30  call 0x00007AEBA680AFE0
00007aeba69cea35  jmp 0x00007AEBA69CE71D
00007aeba69cea3a  call 0x00007AEBA67FF540
00007aeba69cea3f  jmp 0x00007AEBA69CE728
00007aeba69cea44  call 0x00007AEBA680E880
00007aeba69cea49  jmp 0x00007AEBA69CE733
00007aeba69cea4e  call 0x00007AEBA680D600
00007aeba69cea53  jmp 0x00007AEBA69CE73E
00007aeba69cea58  call 0x00007AEBA680C380
00007aeba69cea5d  jmp 0x00007AEBA69CE749
00007aeba69cea62  call 0x00007AEBA680D4E0
00007aeba69cea67  jmp 0x00007AEBA69CE754
00007aeba69cea6c  call 0x00007AEBA680C260
00007aeba69cea71  jmp 0x00007AEBA69CE75F
00007aeba69cea76  call 0x00007AEBA67FF540
00007aeba69cea7b  jmp 0x00007AEBA69CE76A
00007aeba69cea80  call 0x00007AEBA680E880
00007aeba69cea85  jmp 0x00007AEBA69CE775
00007aeba69cea8a  call 0x00007AEBA680B100
00007aeba69cea8f  jmp 0x00007AEBA69CE780
00007aeba69cea94  call 0x00007AEBA680D600
00007aeba69cea99  jmp 0x00007AEBA69CE78B
00007aeba69cea9e  call 0x00007AEBA67FF430
00007aeba69ceaa3  jmp 0x00007AEBA69CE796
00007aeba69ceaa8  call 0x00007AEBA680E760
00007aeba69ceaad  jmp 0x00007AEBA69CE7A1
00007aeba69ceab2  call 0x00007AEBA680C380
00007aeba69ceab7  jmp 0x00007AEBA69CE7AC
00007aeba69ceabc  call 0x00007AEBA67FF540
00007aeba69ceac1  jmp 0x00007AEBA69CE7B7
00007aeba69ceac6  call 0x00007AEBA67FF430
00007aeba69ceacb  jmp 0x00007AEBA69CE7C2
00007aeba69cead0  call 0x00007AEBA680D4E0
00007aeba69cead5  jmp 0x00007AEBA69CE7CD
00007aeba69ceada  call 0x00007AEBA680E880
00007aeba69ceadf  jmp 0x00007AEBA69CE7E0
00007aeba69ceae4  call 0x00007AEBA67FF540
00007aeba69ceae9  jmp 0x00007AEBA69CE7EB
00007aeba69ceaee  call 0x00007AEBA67FF430
00007aeba69ceaf3  jmp 0x00007AEBA69CE7F6
00007aeba69ceaf8  call 0x00007AEBA680E760
00007aeba69ceafd  jmp 0x00007AEBA69CE801
00007aeba69ceb02  call 0x00007AEBA680D600
00007aeba69ceb07  jmp 0x00007AEBA69CE81F
00007aeba69ceb0c  call 0x00007AEBA67FF540
00007aeba69ceb11  jmp 0x00007AEBA69CE82A
00007aeba69ceb16  call 0x00007AEBA67FF430
00007aeba69ceb1b  jmp 0x00007AEBA69CE835
00007aeba69ceb20  call 0x00007AEBA680D4E0
00007aeba69ceb25  jmp 0x00007AEBA69CE840
00007aeba69ceb2a  call 0x00007AEBA680BC20
00007aeba69ceb2f  jmp 0x00007AEBA69CE85B
00007aeba69ceb34  call 0x00007AEBA680E880
00007aeba69ceb39  jmp 0x00007AEBA69CE866
00007aeba69ceb3e  call 0x00007AEBA67FF540
00007aeba69ceb43  jmp 0x00007AEBA69CE871
00007aeba69ceb48  call 0x00007AEBA67FF430
00007aeba69ceb4d  jmp 0x00007AEBA69CE87C
00007aeba69ceb52  call 0x00007AEBA680B720
00007aeba69ceb57  jmp 0x00007AEBA69CE886
00007aeba69ceb5c  call 0x00007AEBA680D600
00007aeba69ceb61  jmp 0x00007AEBA69CE89E
00007aeba69ceb66  call 0x00007AEBA67FF540
00007aeba69ceb6b  jmp 0x00007AEBA69CE8A9
00007aeba69ceb70  call 0x00007AEBA67FF430
00007aeba69ceb75  jmp 0x00007AEBA69CE8B4
00007aeba69ceb7a  call 0x00007AEBA68B4CB0
00007aeba69ceb7f  jmp 0x00007AEBA69CE8C4
00007aeba69ceb84  call 0x00007AEBA680E760
00007aeba69ceb89  jmp 0x00007AEBA69CE8CF
00007aeba69ceb8e  call 0x00007AEBA680D4E0
00007aeba69ceb93  jmp 0x00007AEBA69CE8DA
00007aeba69ceb98  call 0x00007AEBA67FF540
00007aeba69ceb9d  jmp 0x00007AEBA69CE8E4
00007aeba69ceba2  call 0x00007AEBA680BAE0
00007aeba69ceba7  jmp 0x00007AEBA69CE8F4
00007aeba69cebac  call 0x00007AEBA680E880
00007aeba69cebb1  jmp 0x00007AEBA69CE8FE
00007aeba69cebb6  call 0x00007AEBA680D600
00007aeba69cebbb  jmp 0x00007AEBA69CE908
00007aeba69cebc0  call 0x00007AEBA67FF430
00007aeba69cebc5  jmp 0x00007AEBA69CE913
00007aeba69cebca  call 0x00007AEBA680E760
00007aeba69cebcf  jmp 0x00007AEBA69CE91E
00007aeba69cebd4  call 0x00007AEBA68D6600
00007aeba69cebd9  jmp 0x00007AEBA69CE92C
00007aeba69cebde  call 0x00007AEBA680E880
00007aeba69cebe3  jmp 0x00007AEBA69CE936
00007aeba69cebe8  call 0x00007AEBA67FF430
00007aeba69cebed  jmp 0x00007AEBA69CE941
00007aeba69cebf2  call 0x00007AEBA680E760
00007aeba69cebf7  jmp 0x00007AEBA69CE94C
00007aeba69cebfc  call 0x00007AEBA67FF540
00007aeba69cec01  jmp 0x00007AEBA69CE966
00007aeba69cec06  call 0x00007AEBA680E880
00007aeba69cec0b  jmp 0x00007AEBA69CE970
00007aeba69cec10  int3
00007aeba69cec11  nop [rax+rax*1], ax
00007aeba69cec1a  nop [rax+rax*1], ax
00007aeba69cec20  mov rax, [r15]
00007aeba69cec23  lea r14, [rax+0x20]
00007aeba69cec27  mov r12, [r13+r14*1]
00007aeba69cec2c  mov r14, [r15+0x10]
00007aeba69cec30  lea r11, [r12+r14*1]
00007aeba69cec34  mov [r15+0x40], r11
00007aeba69cec38  lea r12, [rax+0x20]
00007aeba69cec3c  mov [r13+r12*1], r11
00007aeba69cec41  test r14, r14
00007aeba69cec44  setz r14b
00007aeba69cec48  movzx r14, r14b
00007aeba69cec4c  mov [rsp+0x414], r14b
00007aeba69cec54  cmp byte ptr [rsp+0x414], 0x00
00007aeba69cec5c  jz 0x00007AEBA69CEC8E
00007aeba69cec5e  cmp dword ptr [r15+0x318], 0x00
00007aeba69cec66  mov eax, 0x4105B0
00007aeba69cec6b  mov [r15+0x100], rax
00007aeba69cec72  jz 0x00007AEBA67FE0A0
00007aeba69cec78  nop [rax+rax*1], eax
00007aeba69cec7d  mov eax, 0x4105B0
00007aeba69cec82  mov [r15+0x100], rax
00007aeba69cec89  jmp 0x00007AEBA67FE110
00007aeba69cec8e  cmp dword ptr [r15+0x318], 0x00
00007aeba69cec96  jz 0x00007AEBA69CECE0
00007aeba69cec9c  nop [rax+rax*1], ax
00007aeba69ceca5  nop [rax+rax*1], eax
00007aeba69cecad  mov eax, 0x410348
00007aeba69cecb2  mov [r15+0x100], rax
00007aeba69cecb9  jmp 0x00007AEBA67FE110
00007aeba69cecbe  int3
00007aeba69cecbf  call 0x00007AEBA68E27E0
00007aeba69cecc4  jmp 0x00007AEBA69CEC2C
00007aeba69cecc9  call 0x00007AEBA68C0860
00007aeba69cecce  jmp 0x00007AEBA69CEC41
00007aeba69cecd3  int3
00007aeba69cecd4  nop [rax+rax*1], ax
00007aeba69cecdd  nop [rax], eax
00007aeba69cece0  mov rax, [r15+0xF8]
00007aeba69cece7  lea r14, [rax-0x150]
00007aeba69cecee  mov [r15+0xF8], r14
00007aeba69cecf5  mov rax, [r15]
00007aeba69cecf8  lea r12, [rax+0x68]
00007aeba69cecfc  mov r11, [r13+r12*1]
00007aeba69ced01  mov [r15+0x88], r11
00007aeba69ced08  lea r12, [rax+0x28]
00007aeba69ced0c  mov [r15+0x40], r12
00007aeba69ced10  mov [r15+0x48], r14
00007aeba69ced14  mov qword ptr [r15+0x50], 0x420758
00007aeba69ced1c  lea rax, [r14+0x100]
00007aeba69ced23  mov r12, [r15+0xE8]
00007aeba69ced2a  mov r11, [r15+0xD8]
00007aeba69ced31  mov [r13+rax*1], r12
00007aeba69ced36  lea rax, [r14+0x108]
00007aeba69ced3d  mov [r13+rax*1], r11
00007aeba69ced42  lea rax, [r14+0x110]
00007aeba69ced49  mov r12, [r15+0xD0]
00007aeba69ced50  mov r11, [r15+0xC8]
00007aeba69ced57  mov [r13+rax*1], r12
00007aeba69ced5c  lea rax, [r14+0x118]
00007aeba69ced63  mov [r13+rax*1], r11
00007aeba69ced68  lea rax, [r14+0x120]
00007aeba69ced6f  mov r12, [r15+0xC0]
00007aeba69ced76  mov r11, [r15+0xB8]
00007aeba69ced7d  mov [r13+rax*1], r12
00007aeba69ced82  lea rax, [r14+0x128]
00007aeba69ced89  mov [r13+rax*1], r11
00007aeba69ced8e  lea rax, [r14+0x130]
00007aeba69ced95  mov r12, [r15+0xB0]
00007aeba69ced9c  mov r11, [r15+0xA8]
00007aeba69ceda3  mov [r13+rax*1], r12
00007aeba69ceda8  lea rax, [r14+0x138]
00007aeba69cedaf  mov [r13+rax*1], r11
00007aeba69cedb4  lea rax, [r14+0x140]
00007aeba69cedbb  mov r12, [r15+0xA0]
00007aeba69cedc2  mov r11, [r15+0x98]
00007aeba69cedc9  mov [r13+rax*1], r12
00007aeba69cedce  lea rax, [r14+0x148]
00007aeba69cedd5  mov [r13+rax*1], r11
00007aeba69cedda  cmp dword ptr [r15+0x318], 0x00
00007aeba69cede2  jz 0x00007AEBA69CEE80
00007aeba69cede8  nop [rax+rax*1], ax
00007aeba69cedf1  nop [rax+rax*1], eax
00007aeba69cedf9  mov eax, 0x410380
00007aeba69cedfe  mov [r15+0x100], rax
00007aeba69cee05  jmp 0x00007AEBA67FE110
00007aeba69cee0a  int3
00007aeba69cee0b  call 0x00007AEBA68C0370
00007aeba69cee10  jmp 0x00007AEBA69CED01
00007aeba69cee15  call 0x00007AEBA680BC20
00007aeba69cee1a  jmp 0x00007AEBA69CED36
00007aeba69cee1f  call 0x00007AEBA680A9A0
00007aeba69cee24  jmp 0x00007AEBA69CED42
00007aeba69cee29  call 0x00007AEBA680BC20
00007aeba69cee2e  jmp 0x00007AEBA69CED5C
00007aeba69cee33  call 0x00007AEBA680A9A0
00007aeba69cee38  jmp 0x00007AEBA69CED68
00007aeba69cee3d  call 0x00007AEBA680BC20
00007aeba69cee42  jmp 0x00007AEBA69CED82
00007aeba69cee47  call 0x00007AEBA680A9A0
00007aeba69cee4c  jmp 0x00007AEBA69CED8E
00007aeba69cee51  call 0x00007AEBA680BC20
00007aeba69cee56  jmp 0x00007AEBA69CEDA8
00007aeba69cee5b  call 0x00007AEBA680A9A0
00007aeba69cee60  jmp 0x00007AEBA69CEDB4
00007aeba69cee65  call 0x00007AEBA680BC20
00007aeba69cee6a  jmp 0x00007AEBA69CEDCE
00007aeba69cee6f  call 0x00007AEBA680A9A0
00007aeba69cee74  jmp 0x00007AEBA69CEDDA
00007aeba69cee79  int3
00007aeba69cee7a  nop [rax+rax*1], ax
00007aeba69cee80  mov rax, [r15+0x08]
00007aeba69cee84  movzx r14d, byte ptr [r13+rax*1]
00007aeba69cee8a  movzx r14d, r14b
00007aeba69cee8e  mov [rsp+0x10], r14d
00007aeba69cee93  mov r14d, r14d
00007aeba69cee96  mov [r15+0x58], r14
00007aeba69cee9a  lea r14, [rax+0x01]
00007aeba69cee9e  mov [r15+0x08], r14
00007aeba69ceea2  mov rax, [r15+0x88]
00007aeba69ceea9  lea r14, [rax+0x01]
00007aeba69ceead  mov r12, [r15]
00007aeba69ceeb0  lea r11, [r12+0x68]
00007aeba69ceeb5  mov [r13+r11*1], r14
00007aeba69ceeba  lea r14, [r12+rax*1]
00007aeba69ceebe  mov [r15+0x60], r14
00007aeba69ceec2  lea rax, [r14+0x28]
00007aeba69ceec6  mov r11d, [rsp+0x10]
00007aeba69ceecb  movzx r14d, r11b
00007aeba69ceecf  mov [r13+rax*1], r14b
00007aeba69ceed4  lea rax, [r12+0x68]
00007aeba69ceed9  mov r14, [r13+rax*1]
00007aeba69ceede  mov [r15+0x88], r14
00007aeba69ceee5  xor eax, eax
00007aeba69ceee7  mov r12d, 0x40
00007aeba69ceeed  cmp r14, r12
00007aeba69ceef0  cmc
00007aeba69ceef1  lahf
00007aeba69ceef2  seto al
00007aeba69ceef5  mov [r15+0x108], eax
00007aeba69ceefc  mov eax, [r15+0x108]
00007aeba69cef03  sahf
00007aeba69cef04  jnz 0x00007AEBA69CEF36
00007aeba69cef06  cmp dword ptr [r15+0x318], 0x00
00007aeba69cef0e  jz 0x00007AEBA69CF020
00007aeba69cef14  nop [rax+rax*1], ax
00007aeba69cef1d  nop [rax+rax*1], eax
00007aeba69cef25  mov eax, 0x4103A0
00007aeba69cef2a  mov [r15+0x100], rax
00007aeba69cef31  jmp 0x00007AEBA67FE110
00007aeba69cef36  cmp dword ptr [r15+0x318], 0x00
00007aeba69cef3e  jz 0x00007AEBA69CEF90
00007aeba69cef44  nop [rax+rax*1], ax
00007aeba69cef4d  nop [rax+rax*1], eax
00007aeba69cef55  mov eax, 0x410378
00007aeba69cef5a  mov [r15+0x100], rax
00007aeba69cef61  jmp 0x00007AEBA67FE110
00007aeba69cef66  int3
00007aeba69cef67  call 0x00007AEBA680D860
00007aeba69cef6c  jmp 0x00007AEBA69CEE8A
00007aeba69cef71  call 0x00007AEBA68B36E0
00007aeba69cef76  jmp 0x00007AEBA69CEEBA
00007aeba69cef7b  call 0x00007AEBA680DD60
00007aeba69cef80  jmp 0x00007AEBA69CEED4
00007aeba69cef85  call 0x00007AEBA680DC20
00007aeba69cef8a  jmp 0x00007AEBA69CEEDE
00007aeba69cef8f  int3
00007aeba69cef90  mov rax, [r15+0x10]
00007aeba69cef94  lea r14, [rax-0x01]
00007aeba69cef98  mov [r15+0x10], r14
00007aeba69cef9c  test r14, r14
00007aeba69cef9f  setz r14b
00007aeba69cefa3  movzx r14, r14b
00007aeba69cefa7  mov [rsp+0x414], r14b
00007aeba69cefaf  cmp byte ptr [rsp+0x414], 0x00
00007aeba69cefb7  jz 0x00007AEBA69CEFE9
00007aeba69cefb9  cmp dword ptr [r15+0x318], 0x00
00007aeba69cefc1  jz 0x00007AEBA69D0520
00007aeba69cefc7  nop [rax+rax*1], ax
00007aeba69cefd0  nop [rax+rax*1], eax
00007aeba69cefd8  mov eax, 0x410598
00007aeba69cefdd  mov [r15+0x100], rax
00007aeba69cefe4  jmp 0x00007AEBA67FE110
00007aeba69cefe9  cmp dword ptr [r15+0x318], 0x00
00007aeba69ceff1  jz 0x00007AEBA69CEE80
00007aeba69ceff7  nop [rax+rax*1], ax
00007aeba69cf000  nop [rax+rax*1], eax
00007aeba69cf008  mov eax, 0x410380
00007aeba69cf00d  mov [r15+0x100], rax
00007aeba69cf014  jmp 0x00007AEBA67FE110
00007aeba69cf019  int3
00007aeba69cf01a  int3
00007aeba69cf01b  nop [rax+rax*1], eax
00007aeba69cf020  mov rax, [r15+0x40]
00007aeba69cf024  movzx r14d, byte ptr [r13+rax*1]
00007aeba69cf02a  movaps xmm1, [r15+0x110]
00007aeba69cf032  pinsrb xmm1, r14d, 0x00
00007aeba69cf039  lea r14, [rax+0x01]
00007aeba69cf03d  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf043  movaps xmm15, [r15+0x120]
00007aeba69cf04b  pinsrb xmm15, r12d, 0x00
00007aeba69cf052  lea r14, [rax+0x02]
00007aeba69cf056  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf05c  movaps xmm14, [r15+0x130]
00007aeba69cf064  pinsrb xmm14, r12d, 0x00
00007aeba69cf06b  lea r14, [rax+0x03]
00007aeba69cf06f  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf075  movaps xmm13, [r15+0x140]
00007aeba69cf07d  pinsrb xmm13, r12d, 0x00
00007aeba69cf084  lea r14, [rax+0x04]
00007aeba69cf088  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf08e  pinsrb xmm1, r12d, 0x01
00007aeba69cf095  lea r14, [rax+0x05]
00007aeba69cf099  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf09f  pinsrb xmm15, r12d, 0x01
00007aeba69cf0a6  lea r14, [rax+0x06]
00007aeba69cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf0b0  pinsrb xmm14, r12d, 0x01
00007aeba69cf0b7  lea r14, [rax+0x07]
00007aeba69cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf0c1  pinsrb xmm13, r12d, 0x01
00007aeba69cf0c8  lea r14, [rax+0x08]
00007aeba69cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf0d2  pinsrb xmm1, r12d, 0x02
00007aeba69cf0d9  lea r14, [rax+0x09]
00007aeba69cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf0e3  pinsrb xmm15, r12d, 0x02
00007aeba69cf0ea  lea r14, [rax+0x0A]
00007aeba69cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf0f4  pinsrb xmm14, r12d, 0x02
00007aeba69cf0fb  lea r14, [rax+0x0B]
00007aeba69cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf105  pinsrb xmm13, r12d, 0x02
00007aeba69cf10c  lea r14, [rax+0x0C]
00007aeba69cf110  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf116  pinsrb xmm1, r12d, 0x03
00007aeba69cf11d  lea r14, [rax+0x0D]
00007aeba69cf121  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf127  pinsrb xmm15, r12d, 0x03
00007aeba69cf12e  lea r14, [rax+0x0E]
00007aeba69cf132  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf138  pinsrb xmm14, r12d, 0x03
00007aeba69cf13f  lea r14, [rax+0x0F]
00007aeba69cf143  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf149  pinsrb xmm13, r12d, 0x03
00007aeba69cf150  lea r14, [rax+0x10]
00007aeba69cf154  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf15a  pinsrb xmm1, r12d, 0x04
00007aeba69cf161  lea r14, [rax+0x11]
00007aeba69cf165  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf16b  pinsrb xmm15, r12d, 0x04
00007aeba69cf172  lea r14, [rax+0x12]
00007aeba69cf176  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf17c  pinsrb xmm14, r12d, 0x04
00007aeba69cf183  lea r14, [rax+0x13]
00007aeba69cf187  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf18d  pinsrb xmm13, r12d, 0x04
00007aeba69cf194  lea r14, [rax+0x14]
00007aeba69cf198  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf19e  pinsrb xmm1, r12d, 0x05
00007aeba69cf1a5  lea r14, [rax+0x15]
00007aeba69cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf1af  pinsrb xmm15, r12d, 0x05
00007aeba69cf1b6  lea r14, [rax+0x16]
00007aeba69cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf1c0  pinsrb xmm14, r12d, 0x05
00007aeba69cf1c7  lea r14, [rax+0x17]
00007aeba69cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf1d1  pinsrb xmm13, r12d, 0x05
00007aeba69cf1d8  lea r14, [rax+0x18]
00007aeba69cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf1e2  pinsrb xmm1, r12d, 0x06
00007aeba69cf1e9  lea r14, [rax+0x19]
00007aeba69cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf1f3  pinsrb xmm15, r12d, 0x06
00007aeba69cf1fa  lea r14, [rax+0x1A]
00007aeba69cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf204  pinsrb xmm14, r12d, 0x06
00007aeba69cf20b  lea r14, [rax+0x1B]
00007aeba69cf20f  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf215  pinsrb xmm13, r12d, 0x06
00007aeba69cf21c  lea r14, [rax+0x1C]
00007aeba69cf220  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf226  pinsrb xmm1, r12d, 0x07
00007aeba69cf22d  lea r14, [rax+0x1D]
00007aeba69cf231  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf237  pinsrb xmm15, r12d, 0x07
00007aeba69cf23e  lea r14, [rax+0x1E]
00007aeba69cf242  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf248  pinsrb xmm14, r12d, 0x07
00007aeba69cf24f  lea r14, [rax+0x1F]
00007aeba69cf253  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf259  pinsrb xmm13, r12d, 0x07
00007aeba69cf260  lea r14, [rax+0x20]
00007aeba69cf264  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf26a  pinsrb xmm1, r12d, 0x08
00007aeba69cf271  lea r14, [rax+0x21]
00007aeba69cf275  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf27b  pinsrb xmm15, r12d, 0x08
00007aeba69cf282  lea r14, [rax+0x22]
00007aeba69cf286  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf28c  pinsrb xmm14, r12d, 0x08
00007aeba69cf293  lea r14, [rax+0x23]
00007aeba69cf297  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf29d  pinsrb xmm13, r12d, 0x08
00007aeba69cf2a4  lea r14, [rax+0x24]
00007aeba69cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf2ae  pinsrb xmm1, r12d, 0x09
00007aeba69cf2b5  lea r14, [rax+0x25]
00007aeba69cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf2bf  pinsrb xmm15, r12d, 0x09
00007aeba69cf2c6  lea r14, [rax+0x26]
00007aeba69cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf2d0  pinsrb xmm14, r12d, 0x09
00007aeba69cf2d7  lea r14, [rax+0x27]
00007aeba69cf2db  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf2e1  pinsrb xmm13, r12d, 0x09
00007aeba69cf2e8  lea r14, [rax+0x28]
00007aeba69cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf2f2  pinsrb xmm1, r12d, 0x0A
00007aeba69cf2f9  lea r14, [rax+0x29]
00007aeba69cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf303  pinsrb xmm15, r12d, 0x0A
00007aeba69cf30a  lea r14, [rax+0x2A]
00007aeba69cf30e  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf314  pinsrb xmm14, r12d, 0x0A
00007aeba69cf31b  lea r14, [rax+0x2B]
00007aeba69cf31f  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf325  pinsrb xmm13, r12d, 0x0A
00007aeba69cf32c  lea r14, [rax+0x2C]
00007aeba69cf330  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf336  pinsrb xmm1, r12d, 0x0B
00007aeba69cf33d  lea r14, [rax+0x2D]
00007aeba69cf341  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf347  pinsrb xmm15, r12d, 0x0B
00007aeba69cf34e  lea r14, [rax+0x2E]
00007aeba69cf352  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf358  pinsrb xmm14, r12d, 0x0B
00007aeba69cf35f  lea r14, [rax+0x2F]
00007aeba69cf363  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf369  pinsrb xmm13, r12d, 0x0B
00007aeba69cf370  lea r14, [rax+0x30]
00007aeba69cf374  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf37a  pinsrb xmm1, r12d, 0x0C
00007aeba69cf381  lea r14, [rax+0x31]
00007aeba69cf385  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf38b  pinsrb xmm15, r12d, 0x0C
00007aeba69cf392  lea r14, [rax+0x32]
00007aeba69cf396  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf39c  pinsrb xmm14, r12d, 0x0C
00007aeba69cf3a3  lea r14, [rax+0x33]
00007aeba69cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf3ad  pinsrb xmm13, r12d, 0x0C
00007aeba69cf3b4  lea r14, [rax+0x34]
00007aeba69cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf3be  pinsrb xmm1, r12d, 0x0D
00007aeba69cf3c5  lea r14, [rax+0x35]
00007aeba69cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf3cf  pinsrb xmm15, r12d, 0x0D
00007aeba69cf3d6  lea r14, [rax+0x36]
00007aeba69cf3da  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf3e0  pinsrb xmm14, r12d, 0x0D
00007aeba69cf3e7  lea r14, [rax+0x37]
00007aeba69cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf3f1  pinsrb xmm13, r12d, 0x0D
00007aeba69cf3f8  lea r14, [rax+0x38]
00007aeba69cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf402  pinsrb xmm1, r12d, 0x0E
00007aeba69cf409  lea r14, [rax+0x39]
00007aeba69cf40d  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf413  pinsrb xmm15, r12d, 0x0E
00007aeba69cf41a  lea r14, [rax+0x3A]
00007aeba69cf41e  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf424  pinsrb xmm14, r12d, 0x0E
00007aeba69cf42b  lea r14, [rax+0x3B]
00007aeba69cf42f  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf435  pinsrb xmm13, r12d, 0x0E
00007aeba69cf43c  lea r14, [rax+0x3C]
00007aeba69cf440  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf446  pinsrb xmm1, r12d, 0x0F
00007aeba69cf44d  movaps [r15+0x110], xmm1
00007aeba69cf455  lea r14, [rax+0x3D]
00007aeba69cf459  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf45f  pinsrb xmm15, r12d, 0x0F
00007aeba69cf466  movaps [r15+0x120], xmm15
00007aeba69cf46e  lea r14, [rax+0x3E]
00007aeba69cf472  movzx r12d, byte ptr [r13+r14*1]
00007aeba69cf478  pinsrb xmm14, r12d, 0x0F
00007aeba69cf47f  movaps [r15+0x130], xmm14
00007aeba69cf487  lea r14, [rax+0x3F]
00007aeba69cf48b  movzx eax, byte ptr [r13+r14*1]
00007aeba69cf491  pinsrb xmm13, eax, 0x0F
00007aeba69cf498  movaps [r15+0x140], xmm13
00007aeba69cf4a0  movq xmm1, qword ptr [r15+0x120]
00007aeba69cf4a9  pmovzxbw xmm1, xmm1
00007aeba69cf4ae  psllw xmm1, 0x00
00007aeba69cf4b3  movaps [r15+0x150], xmm1
00007aeba69cf4bb  movq xmm1, qword ptr [r15+0x130]
00007aeba69cf4c4  pmovzxbw xmm1, xmm1
00007aeba69cf4c9  psllw xmm1, 0x00
00007aeba69cf4ce  movaps [r15+0x160], xmm1
00007aeba69cf4d6  movq xmm1, qword ptr [r15+0x110]
00007aeba69cf4df  pmovzxbw xmm1, xmm1
00007aeba69cf4e4  psllw xmm1, 0x00
00007aeba69cf4e9  movaps [r15+0x170], xmm1
00007aeba69cf4f1  movaps xmm15, [r15+0x110]
00007aeba69cf4f9  pextrq rax, xmm15, 0x01
00007aeba69cf500  movq xmm15, rax
00007aeba69cf505  pmovzxbw xmm15, xmm15
00007aeba69cf50b  psllw xmm15, 0x00
00007aeba69cf511  movaps [r15+0x180], xmm15
00007aeba69cf519  movaps xmm14, [r15+0x120]
00007aeba69cf521  pextrq rax, xmm14, 0x01
00007aeba69cf528  movq xmm14, rax
00007aeba69cf52d  pmovzxbw xmm14, xmm14
00007aeba69cf533  psllw xmm14, 0x00
00007aeba69cf539  movaps [r15+0x210], xmm14
00007aeba69cf541  movaps xmm13, [r15+0x130]
00007aeba69cf549  pextrq rax, xmm13, 0x01
00007aeba69cf550  movq xmm13, rax
00007aeba69cf555  pmovzxbw xmm13, xmm13
00007aeba69cf55b  psllw xmm13, 0x00
00007aeba69cf561  movaps [r15+0x220], xmm13
00007aeba69cf569  movq xmm12, qword ptr [r15+0x140]
00007aeba69cf572  pmovzxbw xmm12, xmm12
00007aeba69cf578  psllw xmm12, 0x00
00007aeba69cf57e  movaps [r15+0x250], xmm12
00007aeba69cf586  movaps xmm12, [r15+0x140]
00007aeba69cf58e  pextrq rax, xmm12, 0x01
00007aeba69cf595  movq xmm12, rax
00007aeba69cf59a  pmovzxbw xmm12, xmm12
00007aeba69cf5a0  psllw xmm12, 0x00
00007aeba69cf5a6  movaps [r15+0x110], xmm12
00007aeba69cf5ae  movq xmm11, qword ptr [r15+0x150]
00007aeba69cf5b7  pmovzxwd xmm11, xmm11
00007aeba69cf5bd  pslld xmm11, 0x10
00007aeba69cf5c3  movq xmm10, qword ptr [r15+0x160]
00007aeba69cf5cc  pmovzxwd xmm10, xmm10
00007aeba69cf5d2  pslld xmm10, 0x08
00007aeba69cf5d8  pextrq rax, xmm1, 0x01
00007aeba69cf5df  movq xmm1, rax
00007aeba69cf5e4  pmovzxwd xmm1, xmm1
00007aeba69cf5e9  pslld xmm1, 0x00
00007aeba69cf5ee  movaps [r15+0x260], xmm1
00007aeba69cf5f6  pextrq rax, xmm15, 0x01
00007aeba69cf5fd  movq xmm15, rax
00007aeba69cf602  pmovzxwd xmm15, xmm15
00007aeba69cf608  pslld xmm15, 0x00
00007aeba69cf60e  movaps [r15+0x270], xmm15
00007aeba69cf616  movq xmm9, qword ptr [r15+0x170]
00007aeba69cf61f  pmovzxwd xmm9, xmm9
00007aeba69cf625  pslld xmm9, 0x00
00007aeba69cf62b  pextrq rax, xmm14, 0x01
00007aeba69cf632  movq xmm14, rax
00007aeba69cf637  pmovzxwd xmm14, xmm14
00007aeba69cf63d  pslld xmm14, 0x10
00007aeba69cf643  movaps [r15+0x280], xmm14
00007aeba69cf64b  movq xmm8, qword ptr [r15+0x180]
00007aeba69cf654  pmovzxwd xmm8, xmm8
00007aeba69cf65a  pslld xmm8, 0x00
00007aeba69cf660  movq xmm7, qword ptr [r15+0x210]
00007aeba69cf669  pmovzxwd xmm7, xmm7
00007aeba69cf66e  pslld xmm7, 0x10
00007aeba69cf673  movaps xmm6, [r15+0x150]
00007aeba69cf67b  pextrq rax, xmm6, 0x01
00007aeba69cf682  movq xmm6, rax
00007aeba69cf687  pmovzxwd xmm6, xmm6
00007aeba69cf68c  pslld xmm6, 0x10
00007aeba69cf691  por xmm11, xmm10
00007aeba69cf696  movaps [r15+0x230], xmm11
00007aeba69cf69e  pextrq rax, xmm13, 0x01
00007aeba69cf6a5  movq xmm13, rax
00007aeba69cf6aa  pmovzxwd xmm13, xmm13
00007aeba69cf6b0  pslld xmm13, 0x08
00007aeba69cf6b6  movaps [r15+0x240], xmm13
00007aeba69cf6be  movq xmm10, qword ptr [r15+0x220]
00007aeba69cf6c7  pmovzxwd xmm10, xmm10
00007aeba69cf6cd  pslld xmm10, 0x08
00007aeba69cf6d3  movaps xmm5, [r15+0x160]
00007aeba69cf6db  pextrq rax, xmm5, 0x01
00007aeba69cf6e2  movq xmm5, rax
00007aeba69cf6e7  pmovzxwd xmm5, xmm5
00007aeba69cf6ec  pslld xmm5, 0x08
00007aeba69cf6f1  pslld xmm9, 0x18
00007aeba69cf6f7  pslld xmm15, 0x18
00007aeba69cf6fd  pslld xmm8, 0x18
00007aeba69cf703  movq xmm4, qword ptr [r15+0x250]
00007aeba69cf70c  pmovzxwd xmm4, xmm4
00007aeba69cf711  pslld xmm4, 0x00
00007aeba69cf716  por xmm14, xmm13
00007aeba69cf71b  por xmm7, xmm10
00007aeba69cf720  movaps [r15+0x210], xmm7
00007aeba69cf728  pslld xmm1, 0x18
00007aeba69cf72d  movaps [r15+0x220], xmm1
00007aeba69cf735  por xmm6, xmm5
00007aeba69cf739  por xmm11, xmm9
00007aeba69cf73e  movaps [r15+0x160], xmm11
00007aeba69cf746  pextrq rax, xmm12, 0x01
00007aeba69cf74d  movq xmm13, rax
00007aeba69cf752  pmovzxwd xmm13, xmm13
00007aeba69cf758  pslld xmm13, 0x00
00007aeba69cf75e  movaps [r15+0x170], xmm13
00007aeba69cf766  movq xmm12, qword ptr [r15+0x110]
00007aeba69cf76f  pmovzxwd xmm12, xmm12
00007aeba69cf775  pslld xmm12, 0x00
00007aeba69cf77b  por xmm14, xmm15
00007aeba69cf780  por xmm7, xmm8
00007aeba69cf785  movaps xmm15, [r15+0x250]
00007aeba69cf78d  pextrq rax, xmm15, 0x01
00007aeba69cf794  movq xmm15, rax
00007aeba69cf799  pmovzxwd xmm15, xmm15
00007aeba69cf79f  pslld xmm15, 0x00
00007aeba69cf7a5  movaps [r15+0x180], xmm15
00007aeba69cf7ad  por xmm6, xmm1
00007aeba69cf7b1  movaps [r15+0x150], xmm6
00007aeba69cf7b9  por xmm11, xmm4
00007aeba69cf7be  movaps [r15+0x140], xmm11
00007aeba69cf7c6  por xmm7, xmm12
00007aeba69cf7cb  movaps [r15+0x110], xmm7
00007aeba69cf7d3  por xmm14, xmm13
00007aeba69cf7d8  movaps [r15+0x120], xmm14
00007aeba69cf7e0  por xmm6, xmm15
00007aeba69cf7e5  movaps [r15+0x130], xmm6
00007aeba69cf7ed  mov rax, [r15+0xF8]
00007aeba69cf7f4  lea r14, [rax+0x20]
00007aeba69cf7f8  movups [r13+r14*1], xmm7
00007aeba69cf7fe  lea r14, [rax+0x30]
00007aeba69cf802  movups [r13+r14*1], xmm14
00007aeba69cf808  movups [r13+rax*1], xmm11
00007aeba69cf80e  lea r14, [rax+0x10]
00007aeba69cf812  movups [r13+r14*1], xmm6
00007aeba69cf818  mov r14d, [r13+rax*1]
00007aeba69cf81d  mov rax, [r15+0x48]
00007aeba69cf821  mov [r15+0x68], rax
00007aeba69cf825  mov qword ptr [r15+0x58], 0x04
00007aeba69cf82d  lea r12, [rax+0x04]
00007aeba69cf831  mov r11d, [r13+r12*1]
00007aeba69cf836  mov [rsp+0x10], r11d
00007aeba69cf83b  mov r11d, r11d
00007aeba69cf83e  mov [r15+0x70], r11
00007aeba69cf842  lea r12, [rax+0x38]
00007aeba69cf846  mov r11d, [r13+r12*1]
00007aeba69cf84b  lea r12, [rax+0x24]
00007aeba69cf84f  mov r10d, [r13+r12*1]
00007aeba69cf854  mov [rsp+0x20], r10d
00007aeba69cf859  mov r10d, r10d
00007aeba69cf85c  mov [r15+0x90], r10
00007aeba69cf863  mov [rsp+0x30], rax
00007aeba69cf868  xor eax, eax
00007aeba69cf86a  mov r12d, 0x04
00007aeba69cf870  mov r10d, 0xC0
00007aeba69cf876  cmp r12, r10
00007aeba69cf879  cmc
00007aeba69cf87a  lahf
00007aeba69cf87b  seto al
00007aeba69cf87e  mov [r15+0x108], eax
00007aeba69cf885  mov eax, [rsp+0x10]
00007aeba69cf889  mov r12d, [rsp+0x10]
00007aeba69cf88e  shrd eax, r12d, 0x07
00007aeba69cf893  mov [rsp+0x10], r11d
00007aeba69cf898  mov r10d, [rsp+0x10]
00007aeba69cf89d  shrd r11d, r10d, 0x11
00007aeba69cf8a2  mov r9d, [rsp+0x20]
00007aeba69cf8a7  lea r8d, [r9d+r14d*1]
00007aeba69cf8ac  rorx r14d, r12d, 0x12
00007aeba69cf8b2  xor eax, r14d
00007aeba69cf8b5  rorx r14d, r10d, 0x13
00007aeba69cf8bb  xor r11d, r14d
00007aeba69cf8be  mov [rsp+0x10], r11d
00007aeba69cf8c3  mov r11d, r11d
00007aeba69cf8c6  mov [r15+0x88], r11
00007aeba69cf8cd  mov [rsp+0x20], r12d
00007aeba69cf8d2  shr r12d, 0x03
00007aeba69cf8d6  xor eax, r12d
00007aeba69cf8d9  mov [rsp+0x40], eax
00007aeba69cf8dd  mov eax, eax
00007aeba69cf8df  mov [r15+0x80], rax
00007aeba69cf8e6  shr r10d, 0x0A
00007aeba69cf8ea  mov eax, [rsp+0x10]
00007aeba69cf8ee  xor eax, r10d
00007aeba69cf8f1  mov [rsp+0x10], eax
00007aeba69cf8f5  mov eax, eax
00007aeba69cf8f7  mov [r15+0x78], rax
00007aeba69cf8fb  mov eax, [rsp+0x40]
00007aeba69cf8ff  lea r14d, [r8d+eax*1]
00007aeba69cf904  mov eax, [rsp+0x10]
00007aeba69cf908  lea r12d, [r14d+eax*1]
00007aeba69cf90d  mov rax, [rsp+0x30]
00007aeba69cf912  lea r14, [rax+0x40]
00007aeba69cf916  mov [r13+r14*1], r12d
00007aeba69cf91b  mov eax, [rsp+0x20]
00007aeba69cf91f  mov eax, eax
00007aeba69cf921  mov [r15+0x60], rax
00007aeba69cf925  mov eax, [r15+0x108]
00007aeba69cf92c  sahf
00007aeba69cf92d  jnz 0x00007AEBA69CF95F
00007aeba69cf92f  cmp dword ptr [r15+0x318], 0x00
00007aeba69cf937  jz 0x00007AEBA69CFE20
00007aeba69cf93d  nop [rax+rax*1], ax
00007aeba69cf946  nop [rax+rax*1], eax
00007aeba69cf94e  mov eax, 0x41049C
00007aeba69cf953  mov [r15+0x100], rax
00007aeba69cf95a  jmp 0x00007AEBA67FE110
00007aeba69cf95f  cmp dword ptr [r15+0x318], 0x00
00007aeba69cf967  jz 0x00007AEBA69CFC70
00007aeba69cf96d  nop [rax+rax*1], ax
00007aeba69cf976  nop [rax+rax*1], eax
00007aeba69cf97e  mov eax, 0x410454
00007aeba69cf983  mov [r15+0x100], rax
00007aeba69cf98a  jmp 0x00007AEBA67FE110
00007aeba69cf98f  int3
00007aeba69cf990  call 0x00007AEBA680D860
00007aeba69cf995  jmp 0x00007AEBA69CF02A
00007aeba69cf99a  call 0x00007AEBA68E2420
00007aeba69cf99f  jmp 0x00007AEBA69CF043
00007aeba69cf9a4  call 0x00007AEBA68E2420
00007aeba69cf9a9  jmp 0x00007AEBA69CF05C
00007aeba69cf9ae  call 0x00007AEBA68E2420
00007aeba69cf9b3  jmp 0x00007AEBA69CF075
00007aeba69cf9b8  call 0x00007AEBA68E2420
00007aeba69cf9bd  jmp 0x00007AEBA69CF08E
00007aeba69cf9c2  call 0x00007AEBA68E2420
00007aeba69cf9c7  jmp 0x00007AEBA69CF09F
00007aeba69cf9cc  call 0x00007AEBA68E2420
00007aeba69cf9d1  jmp 0x00007AEBA69CF0B0
00007aeba69cf9d6  call 0x00007AEBA68E2420
00007aeba69cf9db  jmp 0x00007AEBA69CF0C1
00007aeba69cf9e0  call 0x00007AEBA68E2420
00007aeba69cf9e5  jmp 0x00007AEBA69CF0D2
00007aeba69cf9ea  call 0x00007AEBA68E2420
00007aeba69cf9ef  jmp 0x00007AEBA69CF0E3
00007aeba69cf9f4  call 0x00007AEBA68E2420
00007aeba69cf9f9  jmp 0x00007AEBA69CF0F4
00007aeba69cf9fe  call 0x00007AEBA68E2420
00007aeba69cfa03  jmp 0x00007AEBA69CF105
00007aeba69cfa08  call 0x00007AEBA68E2420
00007aeba69cfa0d  jmp 0x00007AEBA69CF116
00007aeba69cfa12  call 0x00007AEBA68E2420
00007aeba69cfa17  jmp 0x00007AEBA69CF127
00007aeba69cfa1c  call 0x00007AEBA68E2420
00007aeba69cfa21  jmp 0x00007AEBA69CF138
00007aeba69cfa26  call 0x00007AEBA68E2420
00007aeba69cfa2b  jmp 0x00007AEBA69CF149
00007aeba69cfa30  call 0x00007AEBA68E2420
00007aeba69cfa35  jmp 0x00007AEBA69CF15A
00007aeba69cfa3a  call 0x00007AEBA68E2420
00007aeba69cfa3f  jmp 0x00007AEBA69CF16B
00007aeba69cfa44  call 0x00007AEBA68E2420
00007aeba69cfa49  jmp 0x00007AEBA69CF17C
00007aeba69cfa4e  call 0x00007AEBA68E2420
00007aeba69cfa53  jmp 0x00007AEBA69CF18D
00007aeba69cfa58  call 0x00007AEBA68E2420
00007aeba69cfa5d  jmp 0x00007AEBA69CF19E
00007aeba69cfa62  call 0x00007AEBA68E2420
00007aeba69cfa67  jmp 0x00007AEBA69CF1AF
00007aeba69cfa6c  call 0x00007AEBA68E2420
00007aeba69cfa71  jmp 0x00007AEBA69CF1C0
00007aeba69cfa76  call 0x00007AEBA68E2420
00007aeba69cfa7b  jmp 0x00007AEBA69CF1D1
00007aeba69cfa80  call 0x00007AEBA68E2420
00007aeba69cfa85  jmp 0x00007AEBA69CF1E2
00007aeba69cfa8a  call 0x00007AEBA68E2420
00007aeba69cfa8f  jmp 0x00007AEBA69CF1F3
00007aeba69cfa94  call 0x00007AEBA68E2420
00007aeba69cfa99  jmp 0x00007AEBA69CF204
00007aeba69cfa9e  call 0x00007AEBA68E2420
00007aeba69cfaa3  jmp 0x00007AEBA69CF215
00007aeba69cfaa8  call 0x00007AEBA68E2420
00007aeba69cfaad  jmp 0x00007AEBA69CF226
00007aeba69cfab2  call 0x00007AEBA68E2420
00007aeba69cfab7  jmp 0x00007AEBA69CF237
00007aeba69cfabc  call 0x00007AEBA68E2420
00007aeba69cfac1  jmp 0x00007AEBA69CF248
00007aeba69cfac6  call 0x00007AEBA68E2420
00007aeba69cfacb  jmp 0x00007AEBA69CF259
00007aeba69cfad0  call 0x00007AEBA68E2420
00007aeba69cfad5  jmp 0x00007AEBA69CF26A
00007aeba69cfada  call 0x00007AEBA68E2420
00007aeba69cfadf  jmp 0x00007AEBA69CF27B
00007aeba69cfae4  call 0x00007AEBA68E2420
00007aeba69cfae9  jmp 0x00007AEBA69CF28C
00007aeba69cfaee  call 0x00007AEBA68E2420
00007aeba69cfaf3  jmp 0x00007AEBA69CF29D
00007aeba69cfaf8  call 0x00007AEBA68E2420
00007aeba69cfafd  jmp 0x00007AEBA69CF2AE
00007aeba69cfb02  call 0x00007AEBA68E2420
00007aeba69cfb07  jmp 0x00007AEBA69CF2BF
00007aeba69cfb0c  call 0x00007AEBA68E2420
00007aeba69cfb11  jmp 0x00007AEBA69CF2D0
00007aeba69cfb16  call 0x00007AEBA68E2420
00007aeba69cfb1b  jmp 0x00007AEBA69CF2E1
00007aeba69cfb20  call 0x00007AEBA68E2420
00007aeba69cfb25  jmp 0x00007AEBA69CF2F2
00007aeba69cfb2a  call 0x00007AEBA68E2420
00007aeba69cfb2f  jmp 0x00007AEBA69CF303
00007aeba69cfb34  call 0x00007AEBA68E2420
00007aeba69cfb39  jmp 0x00007AEBA69CF314
00007aeba69cfb3e  call 0x00007AEBA68E2420
00007aeba69cfb43  jmp 0x00007AEBA69CF325
00007aeba69cfb48  call 0x00007AEBA68E2420
00007aeba69cfb4d  jmp 0x00007AEBA69CF336
00007aeba69cfb52  call 0x00007AEBA68E2420
00007aeba69cfb57  jmp 0x00007AEBA69CF347
00007aeba69cfb5c  call 0x00007AEBA68E2420
00007aeba69cfb61  jmp 0x00007AEBA69CF358
00007aeba69cfb66  call 0x00007AEBA68E2420
00007aeba69cfb6b  jmp 0x00007AEBA69CF369
00007aeba69cfb70  call 0x00007AEBA68E2420
00007aeba69cfb75  jmp 0x00007AEBA69CF37A
00007aeba69cfb7a  call 0x00007AEBA68E2420
00007aeba69cfb7f  jmp 0x00007AEBA69CF38B
00007aeba69cfb84  call 0x00007AEBA68E2420
00007aeba69cfb89  jmp 0x00007AEBA69CF39C
00007aeba69cfb8e  call 0x00007AEBA68E2420
00007aeba69cfb93  jmp 0x00007AEBA69CF3AD
00007aeba69cfb98  call 0x00007AEBA68E2420
00007aeba69cfb9d  jmp 0x00007AEBA69CF3BE
00007aeba69cfba2  call 0x00007AEBA68E2420
00007aeba69cfba7  jmp 0x00007AEBA69CF3CF
00007aeba69cfbac  call 0x00007AEBA68E2420
00007aeba69cfbb1  jmp 0x00007AEBA69CF3E0
00007aeba69cfbb6  call 0x00007AEBA68E2420
00007aeba69cfbbb  jmp 0x00007AEBA69CF3F1
00007aeba69cfbc0  call 0x00007AEBA68E2420
00007aeba69cfbc5  jmp 0x00007AEBA69CF402
00007aeba69cfbca  call 0x00007AEBA68E2420
00007aeba69cfbcf  jmp 0x00007AEBA69CF413
00007aeba69cfbd4  call 0x00007AEBA68E2420
00007aeba69cfbd9  jmp 0x00007AEBA69CF424
00007aeba69cfbde  call 0x00007AEBA68E2420
00007aeba69cfbe3  jmp 0x00007AEBA69CF435
00007aeba69cfbe8  call 0x00007AEBA68E2420
00007aeba69cfbed  jmp 0x00007AEBA69CF446
00007aeba69cfbf2  call 0x00007AEBA68E2420
00007aeba69cfbf7  jmp 0x00007AEBA69CF45F
00007aeba69cfbfc  call 0x00007AEBA68E2420
00007aeba69cfc01  jmp 0x00007AEBA69CF478
00007aeba69cfc06  call 0x00007AEBA68D5610
00007aeba69cfc0b  jmp 0x00007AEBA69CF491
00007aeba69cfc10  call 0x00007AEBA68DC580
00007aeba69cfc15  jmp 0x00007AEBA69CF7FE
00007aeba69cfc1a  call 0x00007AEBA68E46C0
00007aeba69cfc1f  jmp 0x00007AEBA69CF808
00007aeba69cfc24  call 0x00007AEBA6809E90
00007aeba69cfc29  jmp 0x00007AEBA69CF80E
00007aeba69cfc2e  call 0x00007AEBA68DB310
00007aeba69cfc33  jmp 0x00007AEBA69CF818
00007aeba69cfc38  call 0x00007AEBA680DAE0
00007aeba69cfc3d  jmp 0x00007AEBA69CF81D
00007aeba69cfc42  call 0x00007AEBA68C0230
00007aeba69cfc47  jmp 0x00007AEBA69CF836
00007aeba69cfc4c  call 0x00007AEBA68C0230
00007aeba69cfc51  jmp 0x00007AEBA69CF84B
00007aeba69cfc56  call 0x00007AEBA68BEFC0
00007aeba69cfc5b  jmp 0x00007AEBA69CF854
00007aeba69cfc60  call 0x00007AEBA68E2BA0
00007aeba69cfc65  jmp 0x00007AEBA69CF91B
00007aeba69cfc6a  int3
00007aeba69cfc6b  nop [rax+rax*1], eax
00007aeba69cfc70  mov rax, [r15+0x48]
00007aeba69cfc74  mov r14, [r15+0x58]
00007aeba69cfc78  lea r12, [rax+r14*1]
00007aeba69cfc7c  mov [r15+0x68], r12
00007aeba69cfc80  lea rax, [r14+0x04]
00007aeba69cfc84  mov [r15+0x58], rax
00007aeba69cfc88  lea r14, [r12+0x04]
00007aeba69cfc8d  mov r11d, [r13+r14*1]
00007aeba69cfc92  mov [rsp+0x10], r11d
00007aeba69cfc97  mov r11d, r11d
00007aeba69cfc9a  mov [r15+0x70], r11
00007aeba69cfc9e  lea r14, [r12+0x38]
00007aeba69cfca3  mov r11d, [r13+r14*1]
00007aeba69cfca8  lea r14, [r12+0x24]
00007aeba69cfcad  mov r10d, [r13+r14*1]
00007aeba69cfcb2  mov [rsp+0x20], r10d
00007aeba69cfcb7  mov r10d, r10d
00007aeba69cfcba  mov [r15+0x90], r10
00007aeba69cfcc1  mov [rsp+0x30], rax
00007aeba69cfcc6  xor eax, eax
00007aeba69cfcc8  mov r14, [rsp+0x30]
00007aeba69cfccd  mov r10d, 0xC0
00007aeba69cfcd3  cmp r14, r10
00007aeba69cfcd6  cmc
00007aeba69cfcd7  lahf
00007aeba69cfcd8  seto al
00007aeba69cfcdb  mov [r15+0x108], eax
00007aeba69cfce2  mov eax, [rsp+0x10]
00007aeba69cfce6  mov r14d, [rsp+0x10]
00007aeba69cfceb  shrd eax, r14d, 0x07
00007aeba69cfcf0  mov [rsp+0x10], r11d
00007aeba69cfcf5  mov r10d, [rsp+0x10]
00007aeba69cfcfa  shrd r11d, r10d, 0x11
00007aeba69cfcff  mov r9d, [r15+0x60]
00007aeba69cfd03  mov r8d, [rsp+0x20]
00007aeba69cfd08  lea ebp, [r8d+r9d*1]
00007aeba69cfd0d  rorx r9d, r14d, 0x12
00007aeba69cfd13  xor eax, r9d
00007aeba69cfd16  rorx r9d, r10d, 0x13
00007aeba69cfd1c  xor r11d, r9d
00007aeba69cfd1f  mov [rsp+0x10], r11d
00007aeba69cfd24  mov r11d, r11d
00007aeba69cfd27  mov [r15+0x88], r11
00007aeba69cfd2e  mov [rsp+0x20], r14d
00007aeba69cfd33  shr r14d, 0x03
00007aeba69cfd37  xor eax, r14d
00007aeba69cfd3a  mov [rsp+0x30], eax
00007aeba69cfd3e  mov eax, eax
00007aeba69cfd40  mov [r15+0x80], rax
00007aeba69cfd47  shr r10d, 0x0A
00007aeba69cfd4b  mov eax, [rsp+0x10]
00007aeba69cfd4f  xor eax, r10d
00007aeba69cfd52  mov [rsp+0x10], eax
00007aeba69cfd56  mov eax, eax
00007aeba69cfd58  mov [r15+0x78], rax
00007aeba69cfd5c  mov eax, [rsp+0x30]
00007aeba69cfd60  lea r14d, [ebp+eax*1]
00007aeba69cfd66  mov eax, [rsp+0x10]
00007aeba69cfd6a  lea r11d, [r14d+eax*1]
00007aeba69cfd6f  lea rax, [r12+0x40]
00007aeba69cfd74  mov [r13+rax*1], r11d
00007aeba69cfd79  mov eax, [rsp+0x20]
00007aeba69cfd7d  mov eax, eax
00007aeba69cfd7f  mov [r15+0x60], rax
00007aeba69cfd83  mov eax, [r15+0x108]
00007aeba69cfd8a  sahf
00007aeba69cfd8b  jnz 0x00007AEBA69CFDBD
00007aeba69cfd8d  cmp dword ptr [r15+0x318], 0x00
00007aeba69cfd95  jz 0x00007AEBA69CFE20
00007aeba69cfd9b  nop [rax+rax*1], ax
00007aeba69cfda4  nop [rax+rax*1], eax
00007aeba69cfdac  mov eax, 0x41049C
00007aeba69cfdb1  mov [r15+0x100], rax
00007aeba69cfdb8  jmp 0x00007AEBA67FE110
00007aeba69cfdbd  cmp dword ptr [r15+0x318], 0x00
00007aeba69cfdc5  jz 0x00007AEBA69CFC70
00007aeba69cfdcb  nop [rax+rax*1], ax
00007aeba69cfdd4  nop [rax+rax*1], eax
00007aeba69cfddc  mov eax, 0x410454
00007aeba69cfde1  mov [r15+0x100], rax
00007aeba69cfde8  jmp 0x00007AEBA67FE110
00007aeba69cfded  int3
00007aeba69cfdee  call 0x00007AEBA68E1430
00007aeba69cfdf3  jmp 0x00007AEBA69CFC92
00007aeba69cfdf8  call 0x00007AEBA68E1430
00007aeba69cfdfd  jmp 0x00007AEBA69CFCA8
00007aeba69cfe02  call 0x00007AEBA68E01C0
00007aeba69cfe07  jmp 0x00007AEBA69CFCB2
00007aeba69cfe0c  call 0x00007AEBA680A860
00007aeba69cfe11  jmp 0x00007AEBA69CFD79
00007aeba69cfe16  int3
00007aeba69cfe17  nop [rax+rax*1], ax
00007aeba69cfe20  mov rax, [r15]
00007aeba69cfe23  mov r14d, [r13+rax*1]
00007aeba69cfe28  lea r12, [rax+0x04]
00007aeba69cfe2c  mov r11d, [r13+r12*1]
00007aeba69cfe31  mov [rsp+0x10], r14d
00007aeba69cfe36  mov r14d, r14d
00007aeba69cfe39  mov [r15+0x78], r14
00007aeba69cfe3d  mov [rsp+0x20], r11d
00007aeba69cfe42  mov r11d, r11d
00007aeba69cfe45  mov [r15+0x80], r11
00007aeba69cfe4c  lea r14, [rax+0x08]
00007aeba69cfe50  mov r12d, [r13+r14*1]
00007aeba69cfe55  lea r14, [rax+0x0C]
00007aeba69cfe59  mov r11d, [r13+r14*1]
00007aeba69cfe5e  mov [rsp+0x30], r12d
00007aeba69cfe63  mov r12d, r12d
00007aeba69cfe66  mov [r15+0x70], r12
00007aeba69cfe6a  mov [rsp+0x40], r11d
00007aeba69cfe6f  mov r11d, r11d
00007aeba69cfe72  mov [r15+0x68], r11
00007aeba69cfe76  lea r14, [rax+0x18]
00007aeba69cfe7a  mov r12d, [r13+r14*1]
00007aeba69cfe7f  lea r14, [rax+0x1C]
00007aeba69cfe83  mov r11d, [r13+r14*1]
00007aeba69cfe88  mov [rsp+0x50], r12d
00007aeba69cfe8d  mov r12d, r12d
00007aeba69cfe90  mov [r15+0x58], r12
00007aeba69cfe94  mov [rsp+0x60], r11d
00007aeba69cfe99  mov r11d, r11d
00007aeba69cfe9c  mov [r15+0x60], r11
00007aeba69cfea0  lea r14, [rax+0x10]
00007aeba69cfea4  mov r12d, [r13+r14*1]
00007aeba69cfea9  lea r14, [rax+0x14]
00007aeba69cfead  mov eax, [r13+r14*1]
00007aeba69cfeb2  mov [rsp+0x70], r12d
00007aeba69cfeb7  mov r12d, r12d
00007aeba69cfeba  mov [r15+0x18], r12
00007aeba69cfebe  mov [rsp+0x80], eax
00007aeba69cfec5  mov eax, eax
00007aeba69cfec7  mov [r15+0x90], rax
00007aeba69cfece  mov eax, [rsp+0x70]
00007aeba69cfed2  mov eax, eax
00007aeba69cfed4  mov [r15+0x30], rax
00007aeba69cfed8  mov eax, [rsp+0x50]
00007aeba69cfedc  mov eax, eax
00007aeba69cfede  mov [r15+0xA0], rax
00007aeba69cfee5  mov eax, [rsp+0x30]
00007aeba69cfee9  mov eax, eax
00007aeba69cfeeb  mov [r15+0x28], rax
00007aeba69cfeef  mov eax, [rsp+0x20]
00007aeba69cfef3  mov eax, eax
00007aeba69cfef5  mov [r15+0x98], rax
00007aeba69cfefc  mov eax, [rsp+0x10]
00007aeba69cff00  mov eax, eax
00007aeba69cff02  mov [r15+0x38], rax
00007aeba69cff06  mov eax, [rsp+0x70]
00007aeba69cff0a  mov r14d, [rsp+0x70]
00007aeba69cff0f  shrd eax, r14d, 0x06
00007aeba69cff14  mov [rsp+0x70], r14d
00007aeba69cff19  mov r12d, [rsp+0x80]
00007aeba69cff21  and r14d, r12d
00007aeba69cff24  mov r11d, [rsp+0x10]
00007aeba69cff29  mov r10d, [rsp+0x10]
00007aeba69cff2e  shrd r11d, r10d, 0x02
00007aeba69cff33  mov [rsp+0x10], r12d
00007aeba69cff38  mov r12d, r12d
00007aeba69cff3b  mov [r15+0x20], r12
00007aeba69cff3f  mov r12, [r15+0x50]
00007aeba69cff43  mov r9d, [r13+r12*1]
00007aeba69cff48  mov r12d, [rsp+0x50]
00007aeba69cff4d  mov r8d, [rsp+0x70]
00007aeba69cff52  andn ebp, r8d, r12d
00007aeba69cff57  mov edi, [rsp+0x60]
00007aeba69cff5b  lea esi, [r14d+edi*1]
00007aeba69cff60  rorx r14d, r8d, 0x0B
00007aeba69cff66  xor eax, r14d
00007aeba69cff69  rorx r14d, r10d, 0x0D
00007aeba69cff6f  xor r11d, r14d
00007aeba69cff72  lea edi, [esi+ebp*1]
00007aeba69cff76  mov r14, [r15+0x48]
00007aeba69cff7a  mov ebp, [r13+r14*1]
00007aeba69cff7f  mov r14d, [rsp+0x30]
00007aeba69cff84  mov esi, [rsp+0x20]
00007aeba69cff88  and r14d, esi
00007aeba69cff8b  mov [rsp+0x20], r14d
00007aeba69cff90  mov r14d, r14d
00007aeba69cff93  mov [r15+0xD8], r14
00007aeba69cff9a  lea r14d, [edi+r9d*1]
00007aeba69cff9f  mov r9d, [rsp+0x30]
00007aeba69cffa4  xor r9d, esi
00007aeba69cffa7  rorx edi, r8d, 0x19
00007aeba69cffad  xor eax, edi
00007aeba69cffaf  and r9d, r10d
00007aeba69cffb2  rorx edi, r10d, 0x16
00007aeba69cffb8  xor r11d, edi
00007aeba69cffbb  mov [rsp+0x30], r11d
00007aeba69cffc0  mov r11d, r11d
00007aeba69cffc3  mov [r15+0xD0], r11
00007aeba69cffca  lea r11d, [r14d+ebp*1]
00007aeba69cffcf  mov r10d, [rsp+0x20]
00007aeba69cffd4  xor r9d, r10d
00007aeba69cffd7  lea r14d, [r11d+eax*1]
00007aeba69cffdc  mov qword ptr [r15+0x88], 0x04
00007aeba69cffe7  mov eax, [rsp+0x30]
00007aeba69cffeb  lea r11d, [r9d+eax*1]
00007aeba69cfff0  mov eax, [rsp+0x40]
00007aeba69cfff4  lea r10d, [r14d+eax*1]
00007aeba69cfff9  mov r10d, r10d
00007aeba69cfffc  mov [r15+0xB8], r10
00007aeba69d0003  xor eax, eax
00007aeba69d0005  mov r10d, 0x04
00007aeba69d000b  mov r9d, 0x100
00007aeba69d0011  cmp r10, r9
00007aeba69d0014  cmc
00007aeba69d0015  lahf
00007aeba69d0016  seto al
00007aeba69d0019  mov [r15+0x108], eax
00007aeba69d0020  lea eax, [r11d+r14d*1]
00007aeba69d0025  mov eax, eax
00007aeba69d0027  mov [r15+0xA8], rax
00007aeba69d002e  mov r12d, r12d
00007aeba69d0031  mov [r15+0xB0], r12
00007aeba69d0038  mov eax, [rsp+0x10]
00007aeba69d003c  mov eax, eax
00007aeba69d003e  mov [r15+0xC0], rax
00007aeba69d0045  mov r8d, r8d
00007aeba69d0048  mov [r15+0xC8], r8
00007aeba69d004f  mov eax, [r15+0x108]
00007aeba69d0056  sahf
00007aeba69d0057  jnz 0x00007AEBA69D0089
00007aeba69d0059  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0061  jz 0x00007AEBA69D0350
00007aeba69d0067  nop [rax+rax*1], ax
00007aeba69d0070  nop [rax+rax*1], eax
00007aeba69d0078  mov eax, 0x41055C
00007aeba69d007d  mov [r15+0x100], rax
00007aeba69d0084  jmp 0x00007AEBA67FE110
00007aeba69d0089  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0091  jz 0x00007AEBA69D0120
00007aeba69d0097  nop [rax+rax*1], ax
00007aeba69d00a0  nop [rax+rax*1], eax
00007aeba69d00a8  mov eax, 0x4104D0
00007aeba69d00ad  mov [r15+0x100], rax
00007aeba69d00b4  jmp 0x00007AEBA67FE110
00007aeba69d00b9  int3
00007aeba69d00ba  call 0x00007AEBA680DAE0
00007aeba69d00bf  jmp 0x00007AEBA69CFE28
00007aeba69d00c4  call 0x00007AEBA68C0230
00007aeba69d00c9  jmp 0x00007AEBA69CFE31
00007aeba69d00ce  call 0x00007AEBA68E26A0
00007aeba69d00d3  jmp 0x00007AEBA69CFE55
00007aeba69d00d8  call 0x00007AEBA68E1430
00007aeba69d00dd  jmp 0x00007AEBA69CFE5E
00007aeba69d00e2  call 0x00007AEBA68E26A0
00007aeba69d00e7  jmp 0x00007AEBA69CFE7F
00007aeba69d00ec  call 0x00007AEBA68E1430
00007aeba69d00f1  jmp 0x00007AEBA69CFE88
00007aeba69d00f6  call 0x00007AEBA68E26A0
00007aeba69d00fb  jmp 0x00007AEBA69CFEA9
00007aeba69d0100  call 0x00007AEBA68D5890
00007aeba69d0105  jmp 0x00007AEBA69CFEB2
00007aeba69d010a  call 0x00007AEBA68BDD50
00007aeba69d010f  jmp 0x00007AEBA69CFF48
00007aeba69d0114  call 0x00007AEBA68DA580
00007aeba69d0119  jmp 0x00007AEBA69CFF7F
00007aeba69d011e  int3
00007aeba69d011f  nop
00007aeba69d0120  mov eax, [r15+0xB8]
00007aeba69d0127  mov [rsp+0x10], eax
00007aeba69d012b  mov eax, eax
00007aeba69d012d  mov [r15+0x30], rax
00007aeba69d0131  mov eax, [r15+0xC0]
00007aeba69d0138  mov [rsp+0x20], eax
00007aeba69d013c  mov eax, eax
00007aeba69d013e  mov [r15+0xA0], rax
00007aeba69d0145  mov eax, [r15+0x28]
00007aeba69d0149  mov r14d, [r15+0x98]
00007aeba69d0150  mov [rsp+0x30], r14d
00007aeba69d0155  mov r14d, r14d
00007aeba69d0158  mov [r15+0x28], r14
00007aeba69d015c  mov r14d, [r15+0x38]
00007aeba69d0160  mov [rsp+0x40], r14d
00007aeba69d0165  mov r14d, r14d
00007aeba69d0168  mov [r15+0x98], r14
00007aeba69d016f  mov r14d, [r15+0xA8]
00007aeba69d0176  mov [rsp+0x50], r14d
00007aeba69d017b  mov r14d, r14d
00007aeba69d017e  mov [r15+0x38], r14
00007aeba69d0182  mov r14d, [rsp+0x10]
00007aeba69d0187  mov r12d, [rsp+0x10]
00007aeba69d018c  shrd r14d, r12d, 0x06
00007aeba69d0191  mov r11d, [r15+0xC8]
00007aeba69d0198  mov [rsp+0x10], r12d
00007aeba69d019d  and r12d, r11d
00007aeba69d01a0  mov r10d, [rsp+0x50]
00007aeba69d01a5  mov r9d, [rsp+0x50]
00007aeba69d01aa  shrd r10d, r9d, 0x02
00007aeba69d01af  mov [rsp+0x50], r11d
00007aeba69d01b4  mov r11d, r11d
00007aeba69d01b7  mov [r15+0x20], r11
00007aeba69d01bb  mov r11, [r15+0x88]
00007aeba69d01c2  mov r8, [r15+0x50]
00007aeba69d01c6  lea rbp, [r8+r11*1]
00007aeba69d01ca  mov r8d, [r13+rbp*1]
00007aeba69d01cf  mov ebp, [rsp+0x20]
00007aeba69d01d3  mov edi, [rsp+0x10]
00007aeba69d01d7  andn esi, edi, ebp
00007aeba69d01dc  mov edx, [r15+0xB0]
00007aeba69d01e3  lea ecx, [r12d+edx*1]
00007aeba69d01e8  rorx r12d, edi, 0x0B
00007aeba69d01ee  xor r14d, r12d
00007aeba69d01f1  rorx r12d, r9d, 0x0D
00007aeba69d01f7  xor r10d, r12d
00007aeba69d01fa  lea r12d, [ecx+esi*1]
00007aeba69d01ff  mov rsi, [r15+0x48]
00007aeba69d0203  lea rdx, [rsi+r11*1]
00007aeba69d0207  mov esi, [r13+rdx*1]
00007aeba69d020c  mov edx, [rsp+0x30]
00007aeba69d0210  mov ecx, [rsp+0x40]
00007aeba69d0214  and edx, ecx
00007aeba69d0216  mov [rsp+0x10], edx
00007aeba69d021a  mov edx, edx
00007aeba69d021c  mov [r15+0xD8], rdx
00007aeba69d0223  lea edx, [r12d+r8d*1]
00007aeba69d0228  mov r12d, [rsp+0x30]
00007aeba69d022d  xor r12d, ecx
00007aeba69d0230  rorx r8d, edi, 0x19
00007aeba69d0236  xor r14d, r8d
00007aeba69d0239  and r12d, r9d
00007aeba69d023c  rorx r8d, r9d, 0x16
00007aeba69d0242  xor r10d, r8d
00007aeba69d0245  mov [rsp+0x20], r10d
00007aeba69d024a  mov r10d, r10d
00007aeba69d024d  mov [r15+0xD0], r10
00007aeba69d0254  lea r10d, [edx+esi*1]
00007aeba69d0259  mov r9d, [rsp+0x10]
00007aeba69d025e  xor r12d, r9d
00007aeba69d0261  lea r9d, [r10d+r14d*1]
00007aeba69d0266  lea r14, [r11+0x04]
00007aeba69d026a  mov [r15+0x88], r14
00007aeba69d0271  mov r11d, [rsp+0x20]
00007aeba69d0276  lea r10d, [r12d+r11d*1]
00007aeba69d027b  lea r11d, [r9d+eax*1]
00007aeba69d0280  mov r11d, r11d
00007aeba69d0283  mov [r15+0xB8], r11
00007aeba69d028a  xor eax, eax
00007aeba69d028c  mov r12d, 0x100
00007aeba69d0292  cmp r14, r12
00007aeba69d0295  cmc
00007aeba69d0296  lahf
00007aeba69d0297  seto al
00007aeba69d029a  mov [r15+0x108], eax
00007aeba69d02a1  lea eax, [r10d+r9d*1]
00007aeba69d02a6  mov eax, eax
00007aeba69d02a8  mov [r15+0xA8], rax
00007aeba69d02af  mov ebp, ebp
00007aeba69d02b1  mov [r15+0xB0], rbp
00007aeba69d02b8  mov eax, [rsp+0x50]
00007aeba69d02bc  mov eax, eax
00007aeba69d02be  mov [r15+0xC0], rax
00007aeba69d02c5  mov edi, edi
00007aeba69d02c7  mov [r15+0xC8], rdi
00007aeba69d02ce  mov eax, [r15+0x108]
00007aeba69d02d5  sahf
00007aeba69d02d6  jnz 0x00007AEBA69D0308
00007aeba69d02d8  cmp dword ptr [r15+0x318], 0x00
00007aeba69d02e0  jz 0x00007AEBA69D0350
00007aeba69d02e6  nop [rax+rax*1], ax
00007aeba69d02ef  nop [rax+rax*1], eax
00007aeba69d02f7  mov eax, 0x41055C
00007aeba69d02fc  mov [r15+0x100], rax
00007aeba69d0303  jmp 0x00007AEBA67FE110
00007aeba69d0308  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0310  jz 0x00007AEBA69D0120
00007aeba69d0316  nop [rax+rax*1], ax
00007aeba69d031f  nop [rax+rax*1], eax
00007aeba69d0327  mov eax, 0x4104D0
00007aeba69d032c  mov [r15+0x100], rax
00007aeba69d0333  jmp 0x00007AEBA67FE110
00007aeba69d0338  int3
00007aeba69d0339  call 0x00007AEBA6849010
00007aeba69d033e  jmp 0x00007AEBA69D01CF
00007aeba69d0343  call 0x00007AEBA6825930
00007aeba69d0348  jmp 0x00007AEBA69D020C
00007aeba69d034d  int3
00007aeba69d034e  nop
00007aeba69d0350  mov eax, [r15+0x98]
00007aeba69d0357  mov r14d, [r15+0x70]
00007aeba69d035b  lea r12d, [eax+r14d*1]
00007aeba69d0360  mov eax, [r15+0x28]
00007aeba69d0364  mov r14d, [r15+0x68]
00007aeba69d0368  lea r11d, [eax+r14d*1]
00007aeba69d036d  mov qword ptr [r15+0x88], 0x00
00007aeba69d0378  mov eax, [r15+0xA8]
00007aeba69d037f  mov r14d, [r15+0x78]
00007aeba69d0383  lea r10d, [eax+r14d*1]
00007aeba69d0388  mov [rsp+0x10], r10d
00007aeba69d038d  mov r10d, r10d
00007aeba69d0390  mov [r15+0x78], r10
00007aeba69d0394  mov eax, [r15+0x38]
00007aeba69d0398  mov r14d, [r15+0x80]
00007aeba69d039f  lea r10d, [eax+r14d*1]
00007aeba69d03a4  mov [rsp+0x20], r10d
00007aeba69d03a9  mov r10d, r10d
00007aeba69d03ac  mov [r15+0x80], r10
00007aeba69d03b3  mov rax, [r15]
00007aeba69d03b6  lea r14, [rax+0x08]
00007aeba69d03ba  mov [r13+r14*1], r12d
00007aeba69d03bf  lea r14, [rax+0x0C]
00007aeba69d03c3  mov [r13+r14*1], r11d
00007aeba69d03c8  mov r14d, [r15+0xB8]
00007aeba69d03cf  mov r12d, [r15+0x18]
00007aeba69d03d3  lea r11d, [r14d+r12d*1]
00007aeba69d03d8  mov [rsp+0x30], r11d
00007aeba69d03dd  mov r11d, r11d
00007aeba69d03e0  mov [r15+0x68], r11
00007aeba69d03e4  mov r14d, [r15+0x30]
00007aeba69d03e8  mov r12d, [r15+0x90]
00007aeba69d03ef  lea r11d, [r14d+r12d*1]
00007aeba69d03f4  mov [rsp+0x40], r11d
00007aeba69d03f9  mov r11d, r11d
00007aeba69d03fc  mov [r15+0x70], r11
00007aeba69d0400  mov r14d, [r15+0x20]
00007aeba69d0404  mov r12d, [r15+0x58]
00007aeba69d0408  lea r11d, [r14d+r12d*1]
00007aeba69d040d  mov [rsp+0x50], r11d
00007aeba69d0412  mov r11d, r11d
00007aeba69d0415  mov [r15+0x58], r11
00007aeba69d0419  mov r14d, [r15+0xA0]
00007aeba69d0420  mov r12d, [r15+0x60]
00007aeba69d0424  lea r11d, [r14d+r12d*1]
00007aeba69d0429  mov [rsp+0x60], r11d
00007aeba69d042e  mov r11d, r11d
00007aeba69d0431  mov [r15+0x60], r11
00007aeba69d0435  mov r14d, [rsp+0x10]
00007aeba69d043a  mov [r13+rax*1], r14d
00007aeba69d043f  lea r14, [rax+0x04]
00007aeba69d0443  mov r12d, [rsp+0x20]
00007aeba69d0448  mov [r13+r14*1], r12d
00007aeba69d044d  lea r14, [rax+0x10]
00007aeba69d0451  mov r12d, [rsp+0x30]
00007aeba69d0456  mov [r13+r14*1], r12d
00007aeba69d045b  lea r14, [rax+0x14]
00007aeba69d045f  mov r12d, [rsp+0x40]
00007aeba69d0464  mov [r13+r14*1], r12d
00007aeba69d0469  lea r14, [rax+0x18]
00007aeba69d046d  mov r12d, [rsp+0x50]
00007aeba69d0472  mov [r13+r14*1], r12d
00007aeba69d0477  lea r14, [rax+0x1C]
00007aeba69d047b  mov r12d, [rsp+0x60]
00007aeba69d0480  mov [r13+r14*1], r12d
00007aeba69d0485  lea r14, [rax+0x68]
00007aeba69d0489  xor eax, eax
00007aeba69d048b  mov [r13+r14*1], rax
00007aeba69d0490  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0498  jz 0x00007AEBA69CEF90
00007aeba69d049e  nop [rax+rax*1], ax
00007aeba69d04a7  nop [rax+rax*1], eax
00007aeba69d04af  mov eax, 0x410378
00007aeba69d04b4  mov [r15+0x100], rax
00007aeba69d04bb  jmp 0x00007AEBA67FE110
00007aeba69d04c0  int3
00007aeba69d04c1  call 0x00007AEBA68E2BA0
00007aeba69d04c6  jmp 0x00007AEBA69D03BF
00007aeba69d04cb  call 0x00007AEBA68E1920
00007aeba69d04d0  jmp 0x00007AEBA69D03C8
00007aeba69d04d5  call 0x00007AEBA680DFE0
00007aeba69d04da  jmp 0x00007AEBA69D043F
00007aeba69d04df  call 0x00007AEBA68E2BA0
00007aeba69d04e4  jmp 0x00007AEBA69D044D
00007aeba69d04e9  call 0x00007AEBA68E2BA0
00007aeba69d04ee  jmp 0x00007AEBA69D045B
00007aeba69d04f3  call 0x00007AEBA68E2BA0
00007aeba69d04f8  jmp 0x00007AEBA69D0469
00007aeba69d04fd  call 0x00007AEBA68E2BA0
00007aeba69d0502  jmp 0x00007AEBA69D0477
00007aeba69d0507  call 0x00007AEBA68E2BA0
00007aeba69d050c  jmp 0x00007AEBA69D0485
00007aeba69d0511  call 0x00007AEBA68D5EB0
00007aeba69d0516  jmp 0x00007AEBA69D0490
00007aeba69d051b  int3
00007aeba69d051c  nop [rax], eax
00007aeba69d0520  mov rax, [r15+0xF8]
00007aeba69d0527  lea r14, [rax+0x140]
00007aeba69d052e  mov r12, [r13+r14*1]
00007aeba69d0533  lea r14, [rax+0x148]
00007aeba69d053a  mov r11, [r13+r14*1]
00007aeba69d053f  mov [r15+0xA0], r12
00007aeba69d0546  mov [r15+0x98], r11
00007aeba69d054d  lea r14, [rax+0x130]
00007aeba69d0554  mov r12, [r13+r14*1]
00007aeba69d0559  lea r14, [rax+0x138]
00007aeba69d0560  mov r11, [r13+r14*1]
00007aeba69d0565  mov [r15+0xB0], r12
00007aeba69d056c  mov [r15+0xA8], r11
00007aeba69d0573  lea r14, [rax+0x120]
00007aeba69d057a  mov r12, [r13+r14*1]
00007aeba69d057f  lea r14, [rax+0x128]
00007aeba69d0586  mov r11, [r13+r14*1]
00007aeba69d058b  mov [r15+0xC0], r12
00007aeba69d0592  mov [r15+0xB8], r11
00007aeba69d0599  lea r14, [rax+0x110]
00007aeba69d05a0  mov r12, [r13+r14*1]
00007aeba69d05a5  lea r14, [rax+0x118]
00007aeba69d05ac  mov r11, [r13+r14*1]
00007aeba69d05b1  mov [r15+0xD0], r12
00007aeba69d05b8  mov [r15+0xC8], r11
00007aeba69d05bf  lea r14, [rax+0x100]
00007aeba69d05c6  mov r12, [r13+r14*1]
00007aeba69d05cb  lea r14, [rax+0x108]
00007aeba69d05d2  mov r11, [r13+r14*1]
00007aeba69d05d7  mov [r15+0xE8], r12
00007aeba69d05de  mov [r15+0xD8], r11
00007aeba69d05e5  lea r14, [rax+0x150]
00007aeba69d05ec  mov [r15+0xF8], r14
00007aeba69d05f3  mov rax, [r15+0xF0]
00007aeba69d05fa  mov [r15+0x100], rax
00007aeba69d0601  jmp 0x00007AEBA69CE5C0
00007aeba69d0606  int3
00007aeba69d0607  call 0x00007AEBA68E27E0
00007aeba69d060c  jmp 0x00007AEBA69D0533
00007aeba69d0611  call 0x00007AEBA68E1570
00007aeba69d0616  jmp 0x00007AEBA69D053F
00007aeba69d061b  call 0x00007AEBA68E27E0
00007aeba69d0620  jmp 0x00007AEBA69D0559
00007aeba69d0625  call 0x00007AEBA68E1570
00007aeba69d062a  jmp 0x00007AEBA69D0565
00007aeba69d062f  call 0x00007AEBA68E27E0
00007aeba69d0634  jmp 0x00007AEBA69D057F
00007aeba69d0639  call 0x00007AEBA68E1570
00007aeba69d063e  jmp 0x00007AEBA69D058B
00007aeba69d0643  call 0x00007AEBA68E27E0
00007aeba69d0648  jmp 0x00007AEBA69D05A5
00007aeba69d064d  call 0x00007AEBA68E1570
00007aeba69d0652  jmp 0x00007AEBA69D05B1
00007aeba69d0657  call 0x00007AEBA68E27E0
00007aeba69d065c  jmp 0x00007AEBA69D05CB
00007aeba69d0661  call 0x00007AEBA68E1570
00007aeba69d0666  jmp 0x00007AEBA69D05D7
00007aeba69d066b  int3
00007aeba69d066c  nop [rax], eax
00007aeba69d0670  mov eax, [r15+0xA0]
00007aeba69d0677  mov [rsp+0x10], eax
00007aeba69d067b  xor eax, eax
00007aeba69d067d  mov r14d, [rsp+0x10]
00007aeba69d0682  sub r14d, 0x01
00007aeba69d0686  cmc
00007aeba69d0687  lahf
00007aeba69d0688  seto al
00007aeba69d068b  mov [r15+0x108], eax
00007aeba69d0692  mov r14d, r14d
00007aeba69d0695  mov [r15+0xA0], r14
00007aeba69d069c  mov eax, [r15+0x108]
00007aeba69d06a3  sahf
00007aeba69d06a4  jnz 0x00007AEBA69D06D6
00007aeba69d06a6  cmp dword ptr [r15+0x318], 0x00
00007aeba69d06ae  jz 0x00007AEBA69D07A0
00007aeba69d06b4  nop [rax+rax*1], ax
00007aeba69d06bd  nop [rax+rax*1], eax
00007aeba69d06c5  mov eax, 0x41027C
00007aeba69d06ca  mov [r15+0x100], rax
00007aeba69d06d1  jmp 0x00007AEBA67FE110
00007aeba69d06d6  cmp dword ptr [r15+0x318], 0x00
00007aeba69d06de  jz 0x00007AEBA69D0710
00007aeba69d06e4  nop [rax+rax*1], ax
00007aeba69d06ed  nop [rax+rax*1], eax
00007aeba69d06f5  mov eax, 0x410264
00007aeba69d06fa  mov [r15+0x100], rax
00007aeba69d0701  jmp 0x00007AEBA67FE110
00007aeba69d0706  int3
00007aeba69d0707  int3
00007aeba69d0708  nop [rax+rax*1], eax
00007aeba69d0710  mov rax, [r15+0xF8]
00007aeba69d0717  mov [r15], rax
00007aeba69d071a  mov rax, [r15+0x98]
00007aeba69d0721  mov [r15+0x08], rax
00007aeba69d0725  mov qword ptr [r15+0x10], 0x12C
00007aeba69d072d  mov qword ptr [r15+0xF0], 0x410274
00007aeba69d0738  mov r14d, [r15+0x320]
00007aeba69d073f  mov eax, 0x410274
00007aeba69d0744  mov rcx, 0x7AEBA69D0670
00007aeba69d074e  mov [r15+r14*8+0x328], rax
00007aeba69d0756  mov [r15+r14*8+0x368], rcx
00007aeba69d075e  add r14d, 0x01
00007aeba69d0762  and r14d, 0x07
00007aeba69d0766  mov [r15+0x320], r14d
00007aeba69d076d  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0775  jz 0x00007AEBA69CEC20
00007aeba69d077b  nop [rax+rax*1], ax
00007aeba69d0784  nop [rax+rax*1], eax
00007aeba69d078c  mov eax, 0x410338
00007aeba69d0791  mov [r15+0x100], rax
00007aeba69d0798  jmp 0x00007AEBA67FE110
00007aeba69d079d  int3
00007aeba69d079e  int3
00007aeba69d079f  nop
00007aeba69d07a0  mov rax, [r15+0xF8]
00007aeba69d07a7  lea r14, [rax+0x20]
00007aeba69d07ab  mov r12, [r13+r14*1]
00007aeba69d07b0  mov [r15+0x98], r12
00007aeba69d07b7  mov qword ptr [r15+0x40], 0x80
00007aeba69d07bf  mov [r15], rax
00007aeba69d07c2  lea r14, [rax+0x8C]
00007aeba69d07c9  mov [r15+0x08], r14
00007aeba69d07cd  mov qword ptr [r15+0x10], 0x01
00007aeba69d07d5  lea r14, [rax+0x8C]
00007aeba69d07dc  mov eax, 0x80
00007aeba69d07e1  mov [r13+r14*1], al
00007aeba69d07e6  mov qword ptr [r15+0xF0], 0x410298
00007aeba69d07f1  mov r14d, [r15+0x320]
00007aeba69d07f8  mov eax, 0x410298
00007aeba69d07fd  mov rcx, 0x7AEBA69D0870
00007aeba69d0807  mov [r15+r14*8+0x328], rax
00007aeba69d080f  mov [r15+r14*8+0x368], rcx
00007aeba69d0817  add r14d, 0x01
00007aeba69d081b  and r14d, 0x07
00007aeba69d081f  mov [r15+0x320], r14d
00007aeba69d0826  cmp dword ptr [r15+0x318], 0x00
00007aeba69d082e  jz 0x00007AEBA69CEC20
00007aeba69d0834  nop [rax+rax*1], ax
00007aeba69d083d  nop [rax+rax*1], eax
00007aeba69d0845  mov eax, 0x410338
00007aeba69d084a  mov [r15+0x100], rax
00007aeba69d0851  jmp 0x00007AEBA67FE110
00007aeba69d0856  int3
00007aeba69d0857  call 0x00007AEBA68E27E0
00007aeba69d085c  jmp 0x00007AEBA69D07B0
00007aeba69d0861  call 0x00007AEBA68D5AF0
00007aeba69d0866  jmp 0x00007AEBA69D07E6
00007aeba69d086b  int3
00007aeba69d086c  nop [rax], eax
00007aeba69d0870  mov rax, [r15+0xF8]
00007aeba69d0877  lea r14, [rax+0x68]
00007aeba69d087b  mov r12, [r13+r14*1]
00007aeba69d0880  mov [r15+0x40], r12
00007aeba69d0884  lea r14, [rax+0x88]
00007aeba69d088b  xor eax, eax
00007aeba69d088d  mov [r13+r14*1], al
00007aeba69d0892  xor eax, eax
00007aeba69d0894  mov r14d, 0x38
00007aeba69d089a  cmp r12, r14
00007aeba69d089d  cmc
00007aeba69d089e  lahf
00007aeba69d089f  seto al
00007aeba69d08a2  mov [r15+0x108], eax
00007aeba69d08a9  mov eax, [r15+0x108]
00007aeba69d08b0  sahf
00007aeba69d08b1  jz 0x00007AEBA69D08E3
00007aeba69d08b3  cmp dword ptr [r15+0x318], 0x00
00007aeba69d08bb  jz 0x00007AEBA69D0930
00007aeba69d08c1  nop [rax+rax*1], ax
00007aeba69d08ca  nop [rax+rax*1], eax
00007aeba69d08d2  mov eax, 0x4102A8
00007aeba69d08d7  mov [r15+0x100], rax
00007aeba69d08de  jmp 0x00007AEBA67FE110
00007aeba69d08e3  cmp dword ptr [r15+0x318], 0x00
00007aeba69d08eb  jz 0x00007AEBA69D0A70
00007aeba69d08f1  nop [rax+rax*1], ax
00007aeba69d08fa  nop [rax+rax*1], eax
00007aeba69d0902  mov eax, 0x4102C4
00007aeba69d0907  mov [r15+0x100], rax
00007aeba69d090e  jmp 0x00007AEBA67FE110
00007aeba69d0913  int3
00007aeba69d0914  call 0x00007AEBA68E27E0
00007aeba69d0919  jmp 0x00007AEBA69D0880
00007aeba69d091e  call 0x00007AEBA68D5AF0
00007aeba69d0923  jmp 0x00007AEBA69D0892
00007aeba69d0928  int3
00007aeba69d0929  nop [rax], eax
00007aeba69d0930  mov rax, [r15+0xF8]
00007aeba69d0937  mov [r15], rax
00007aeba69d093a  lea r14, [rax+0x88]
00007aeba69d0941  mov [r15+0x08], r14
00007aeba69d0945  mov qword ptr [r15+0x10], 0x01
00007aeba69d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007aeba69d0958  mov r14d, [r15+0x320]
00007aeba69d095f  mov eax, 0x4102B8
00007aeba69d0964  mov rcx, 0x7AEBA69D09C0
00007aeba69d096e  mov [r15+r14*8+0x328], rax
00007aeba69d0976  mov [r15+r14*8+0x368], rcx
00007aeba69d097e  add r14d, 0x01
00007aeba69d0982  and r14d, 0x07
00007aeba69d0986  mov [r15+0x320], r14d
00007aeba69d098d  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0995  jz 0x00007AEBA69CEC20
00007aeba69d099b  nop [rax+rax*1], ax
00007aeba69d09a4  nop [rax+rax*1], eax
00007aeba69d09ac  mov eax, 0x410338
00007aeba69d09b1  mov [r15+0x100], rax
00007aeba69d09b8  jmp 0x00007AEBA67FE110
00007aeba69d09bd  int3
00007aeba69d09be  int3
00007aeba69d09bf  nop
00007aeba69d09c0  mov rax, [r15+0xF8]
00007aeba69d09c7  lea r14, [rax+0x68]
00007aeba69d09cb  mov rax, [r13+r14*1]
00007aeba69d09d0  mov [r15+0x40], rax
00007aeba69d09d4  mov [rsp+0x10], rax
00007aeba69d09d9  xor eax, eax
00007aeba69d09db  mov r14, [rsp+0x10]
00007aeba69d09e0  mov r12d, 0x38
00007aeba69d09e6  cmp r14, r12
00007aeba69d09e9  cmc
00007aeba69d09ea  lahf
00007aeba69d09eb  seto al
00007aeba69d09ee  mov [r15+0x108], eax
00007aeba69d09f5  mov eax, [r15+0x108]
00007aeba69d09fc  sahf
00007aeba69d09fd  jnz 0x00007AEBA69D0A2F
00007aeba69d09ff  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0a07  jz 0x00007AEBA69D0A70
00007aeba69d0a0d  nop [rax+rax*1], ax
00007aeba69d0a16  nop [rax+rax*1], eax
00007aeba69d0a1e  mov eax, 0x4102C4
00007aeba69d0a23  mov [r15+0x100], rax
00007aeba69d0a2a  jmp 0x00007AEBA67FE110
00007aeba69d0a2f  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0a37  jz 0x00007AEBA69D0930
00007aeba69d0a3d  nop [rax+rax*1], ax
00007aeba69d0a46  nop [rax+rax*1], eax
00007aeba69d0a4e  mov eax, 0x4102A8
00007aeba69d0a53  mov [r15+0x100], rax
00007aeba69d0a5a  jmp 0x00007AEBA67FE110
00007aeba69d0a5f  int3
00007aeba69d0a60  call 0x00007AEBA68D59C0
00007aeba69d0a65  jmp 0x00007AEBA69D09D0
00007aeba69d0a6a  int3
00007aeba69d0a6b  nop [rax+rax*1], eax
00007aeba69d0a70  mov rax, [r15+0x98]
00007aeba69d0a77  rorx r14, rax, 0x3D
00007aeba69d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007aeba69d0a81  mov rax, [r15+0xF8]
00007aeba69d0a88  mov [r15], rax
00007aeba69d0a8b  lea r12, [rax+0x78]
00007aeba69d0a8f  mov [r15+0x08], r12
00007aeba69d0a93  mov qword ptr [r15+0x10], 0x08
00007aeba69d0a9b  bswap r14
00007aeba69d0a9e  mov [r15+0x40], r14
00007aeba69d0aa2  lea r12, [rax+0x78]
00007aeba69d0aa6  mov [r13+r12*1], r14
00007aeba69d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007aeba69d0ab6  mov r14d, [r15+0x320]
00007aeba69d0abd  mov eax, 0x4102E0
00007aeba69d0ac2  mov rcx, 0x7AEBA69D0B30
00007aeba69d0acc  mov [r15+r14*8+0x328], rax
00007aeba69d0ad4  mov [r15+r14*8+0x368], rcx
00007aeba69d0adc  add r14d, 0x01
00007aeba69d0ae0  and r14d, 0x07
00007aeba69d0ae4  mov [r15+0x320], r14d
00007aeba69d0aeb  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0af3  jz 0x00007AEBA69CEC20
00007aeba69d0af9  nop [rax+rax*1], ax
00007aeba69d0b02  nop [rax+rax*1], eax
00007aeba69d0b0a  mov eax, 0x410338
00007aeba69d0b0f  mov [r15+0x100], rax
00007aeba69d0b16  jmp 0x00007AEBA67FE110
00007aeba69d0b1b  int3
00007aeba69d0b1c  call 0x00007AEBA68C3FE0
00007aeba69d0b21  jmp 0x00007AEBA69D0AAB
00007aeba69d0b26  int3
00007aeba69d0b27  nop [rax+rax*1], ax
00007aeba69d0b30  mov rax, [r15+0xF8]
00007aeba69d0b37  mov r14d, [r13+rax*1]
00007aeba69d0b3c  lea r12, [rax+0x04]
00007aeba69d0b40  mov r11d, [r13+r12*1]
00007aeba69d0b45  lea r12, [rax+0x08]
00007aeba69d0b49  mov r10d, [r13+r12*1]
00007aeba69d0b4e  lea r12, [rax+0x0C]
00007aeba69d0b52  mov r9d, [r13+r12*1]
00007aeba69d0b57  mov qword ptr [r15+0x48], 0x430860
00007aeba69d0b5f  lea r12, [rax+0x80]
00007aeba69d0b66  mov r8, [r13+r12*1]
00007aeba69d0b6b  mov [r15+0xF0], r8
00007aeba69d0b72  bswap r14d
00007aeba69d0b75  bswap r11d
00007aeba69d0b78  mov r12d, 0x430860
00007aeba69d0b7e  mov [r13+r12*1], r14d
00007aeba69d0b83  mov r14d, 0x430864
00007aeba69d0b89  mov [r13+r14*1], r11d
00007aeba69d0b8e  bswap r10d
00007aeba69d0b91  bswap r9d
00007aeba69d0b94  lea r14, [rax+0x10]
00007aeba69d0b98  mov r12d, [r13+r14*1]
00007aeba69d0b9d  lea r14, [rax+0x14]
00007aeba69d0ba1  mov r11d, [r13+r14*1]
00007aeba69d0ba6  mov r14d, 0x430868
00007aeba69d0bac  mov [r13+r14*1], r10d
00007aeba69d0bb1  mov r14d, 0x43086C
00007aeba69d0bb7  mov [r13+r14*1], r9d
00007aeba69d0bbc  lea r14, [rax+0x90]
00007aeba69d0bc3  mov r10, [r13+r14*1]
00007aeba69d0bc8  lea r14, [rax+0x98]
00007aeba69d0bcf  mov r9, [r13+r14*1]
00007aeba69d0bd4  mov [r15+0xA0], r10
00007aeba69d0bdb  mov [r15+0x98], r9
00007aeba69d0be2  bswap r12d
00007aeba69d0be5  bswap r11d
00007aeba69d0be8  mov [rsp+0x10], r11d
00007aeba69d0bed  mov r11d, r11d
00007aeba69d0bf0  mov [r15+0x58], r11
00007aeba69d0bf4  lea r14, [rax+0x18]
00007aeba69d0bf8  mov r11d, [r13+r14*1]
00007aeba69d0bfd  lea r14, [rax+0x1C]
00007aeba69d0c01  mov r10d, [r13+r14*1]
00007aeba69d0c06  mov [rsp+0x20], r10d
00007aeba69d0c0b  mov r10d, r10d
00007aeba69d0c0e  mov [r15+0x60], r10
00007aeba69d0c12  mov r14d, 0x430870
00007aeba69d0c18  mov [r13+r14*1], r12d
00007aeba69d0c1d  mov r14d, 0x430874
00007aeba69d0c23  mov r12d, [rsp+0x10]
00007aeba69d0c28  mov [r13+r14*1], r12d
00007aeba69d0c2d  bswap r11d
00007aeba69d0c30  mov [rsp+0x10], r11d
00007aeba69d0c35  mov r11d, r11d
00007aeba69d0c38  mov [r15+0x40], r11
00007aeba69d0c3c  mov r14d, [rsp+0x20]
00007aeba69d0c41  bswap r14d
00007aeba69d0c44  mov [rsp+0x20], r14d
00007aeba69d0c49  mov r14d, r14d
00007aeba69d0c4c  mov [r15+0x50], r14
00007aeba69d0c50  mov r14d, 0x430878
00007aeba69d0c56  mov r12d, [rsp+0x10]
00007aeba69d0c5b  mov [r13+r14*1], r12d
00007aeba69d0c60  mov r14d, 0x43087C
00007aeba69d0c66  mov r12d, [rsp+0x20]
00007aeba69d0c6b  mov [r13+r14*1], r12d
00007aeba69d0c70  lea r14, [rax+0xA0]
00007aeba69d0c77  mov [r15+0xF8], r14
00007aeba69d0c7e  mov [r15+0x100], r8
00007aeba69d0c85  jmp 0x00007AEBA69CE5C0
00007aeba69d0c8a  int3
00007aeba69d0c8b  call 0x00007AEBA680DAE0
00007aeba69d0c90  jmp 0x00007AEBA69D0B3C
00007aeba69d0c95  call 0x00007AEBA68C0230
00007aeba69d0c9a  jmp 0x00007AEBA69D0B45
00007aeba69d0c9f  call 0x00007AEBA68BEFC0
00007aeba69d0ca4  jmp 0x00007AEBA69D0B4E
00007aeba69d0ca9  call 0x00007AEBA68BDD50
00007aeba69d0cae  jmp 0x00007AEBA69D0B57
00007aeba69d0cb3  call 0x00007AEBA68BCC20
00007aeba69d0cb8  jmp 0x00007AEBA69D0B6B
00007aeba69d0cbd  call 0x00007AEBA68C3EA0
00007aeba69d0cc2  jmp 0x00007AEBA69D0B83
00007aeba69d0cc7  call 0x00007AEBA68E1920
00007aeba69d0ccc  jmp 0x00007AEBA69D0B8E
00007aeba69d0cd1  call 0x00007AEBA68E26A0
00007aeba69d0cd6  jmp 0x00007AEBA69D0B9D
00007aeba69d0cdb  call 0x00007AEBA68E1430
00007aeba69d0ce0  jmp 0x00007AEBA69D0BA6
00007aeba69d0ce5  call 0x00007AEBA68E06B0
00007aeba69d0cea  jmp 0x00007AEBA69D0BB1
00007aeba69d0cef  call 0x00007AEBA68DF440
00007aeba69d0cf4  jmp 0x00007AEBA69D0BBC
00007aeba69d0cf9  call 0x00007AEBA68E0300
00007aeba69d0cfe  jmp 0x00007AEBA69D0BC8
00007aeba69d0d03  call 0x00007AEBA68DF090
00007aeba69d0d08  jmp 0x00007AEBA69D0BD4
00007aeba69d0d0d  call 0x00007AEBA68E1430
00007aeba69d0d12  jmp 0x00007AEBA69D0BFD
00007aeba69d0d17  call 0x00007AEBA68E01C0
00007aeba69d0d1c  jmp 0x00007AEBA69D0C06
00007aeba69d0d21  call 0x00007AEBA68E2BA0
00007aeba69d0d26  jmp 0x00007AEBA69D0C1D
00007aeba69d0d2b  call 0x00007AEBA68E2BA0
00007aeba69d0d30  jmp 0x00007AEBA69D0C2D
00007aeba69d0d35  call 0x00007AEBA68E2BA0
00007aeba69d0d3a  jmp 0x00007AEBA69D0C60
00007aeba69d0d3f  call 0x00007AEBA68E2BA0
00007aeba69d0d44  jmp 0x00007AEBA69D0C70
00007aeba69d0d49  int3
00007aeba69d0d4a  nop [rax+rax*1], ax
00007aeba69d0d50  mov qword ptr [r15+0x100], 0x04
00007aeba69d0d5b  mov esi, 0x00
00007aeba69d0d60  mov edx, 0x09
00007aeba69d0d65  mov rdi, 0x7FFD5D9B09A0
00007aeba69d0d6f  mov rax, 0x557941AF7970
00007aeba69d0d79  call rax
00007aeba69d0d7b  cmp dword ptr [r15+0x318], 0x00
00007aeba69d0d83  jnz 0x00007AEBA67FE110
00007aeba69d0d89  jmp 0x00007AEBA67FE0A0
00007aeba69d0d8e  int3
00007aeba69d0d8f  int3
