
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sha/candidate/0/5.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x20
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp+0x18],r11
  11:	mov    r13,QWORD PTR [r12+0xf8]
  19:	mov    r14,r13
  1c:	add    r14,0x4
  20:	mov    r15d,DWORD PTR [r13+0x0]
  24:	mov    ebp,DWORD PTR [r14]
  27:	mov    QWORD PTR [r12+0x40],r15
  2c:	mov    QWORD PTR [r12+0x50],rbp
  31:	mov    r14,r13
  34:	add    r14,0x8
  38:	mov    r8,r14
  3b:	add    r8,0x4
  3f:	mov    r9d,DWORD PTR [r14]
  42:	mov    r14d,DWORD PTR [r8]
  45:	mov    QWORD PTR [r12+0x58],r9
  4a:	mov    QWORD PTR [r12+0x60],r14
  4f:	mov    r14d,0x430860
  55:	mov    QWORD PTR [r12+0x48],r14
  5a:	add    r13,0x80
  61:	mov    r14,QWORD PTR [r13+0x0]
  65:	mov    QWORD PTR [r12+0xf0],r14
  6d:	movabs rcx,0xff00ff00ff00ff
  77:	mov    r13,r15
  7a:	and    r13,rcx
  7d:	shl    r13,0x8
  81:	movabs rcx,0xff00ff00ff00ff00
  8b:	mov    r14,r15
  8e:	and    r14,rcx
  91:	shr    r14,0x8
  95:	mov    rcx,r13
  98:	or     r14,rcx
  9b:	movabs rcx,0xffff0000ffff
  a5:	mov    r13,r14
  a8:	and    r13,rcx
  ab:	shl    r13,0x10
  af:	movabs rcx,0xffff0000ffff0000
  b9:	and    r14,rcx
  bc:	shr    r14,0x10
  c0:	mov    rcx,r13
  c3:	or     r14,rcx
  c6:	mov    ecx,0xffffffff
  cb:	and    r14,rcx
  ce:	mov    QWORD PTR [r12+0x40],r14
  d3:	movabs rcx,0xff00ff00ff00ff
  dd:	mov    r13,rbp
  e0:	and    r13,rcx
  e3:	shl    r13,0x8
  e7:	movabs rcx,0xff00ff00ff00ff00
  f1:	mov    r15,rbp
  f4:	and    r15,rcx
  f7:	shr    r15,0x8
  fb:	mov    rcx,r13
  fe:	or     r15,rcx
 101:	movabs rcx,0xffff0000ffff
 10b:	mov    r13,r15
 10e:	and    r13,rcx
 111:	shl    r13,0x10
 115:	movabs rcx,0xffff0000ffff0000
 11f:	and    r15,rcx
 122:	shr    r15,0x10
 126:	mov    rcx,r13
 129:	or     r15,rcx
 12c:	mov    ecx,0xffffffff
 131:	and    r15,rcx
 134:	mov    QWORD PTR [r12+0x50],r15
 139:	mov    r13d,0x430860
 13f:	mov    ebp,0x430864
 144:	mov    rax,r14
 147:	mov    eax,eax
 149:	mov    r8d,eax
 14c:	mov    rax,r15
 14f:	mov    eax,eax
 151:	mov    r14d,eax
 154:	mov    DWORD PTR [r13+0x0],r8d
 158:	mov    r13d,0x0
 15e:	mov    DWORD PTR [r12+0x32c],r13d
 166:	mov    DWORD PTR [rbp+0x0],r14d
 16a:	mov    r13d,0x0
 170:	mov    DWORD PTR [r12+0x32c],r13d
 178:	mov    r13d,DWORD PTR [r12+0x58]
 17d:	movabs rcx,0xff00ff00ff00ff
 187:	mov    r14,r13
 18a:	and    r14,rcx
 18d:	shl    r14,0x8
 191:	movabs rcx,0xff00ff00ff00ff00
 19b:	mov    r15,r13
 19e:	and    r15,rcx
 1a1:	shr    r15,0x8
 1a5:	mov    rcx,r14
 1a8:	or     r15,rcx
 1ab:	movabs rcx,0xffff0000ffff
 1b5:	mov    r13,r15
 1b8:	and    r13,rcx
 1bb:	shl    r13,0x10
 1bf:	movabs rcx,0xffff0000ffff0000
 1c9:	and    r15,rcx
 1cc:	shr    r15,0x10
 1d0:	mov    rcx,r13
 1d3:	or     r15,rcx
 1d6:	mov    ecx,0xffffffff
 1db:	and    r15,rcx
 1de:	mov    QWORD PTR [r12+0x40],r15
 1e3:	mov    r13d,DWORD PTR [r12+0x60]
 1e8:	movabs rcx,0xff00ff00ff00ff
 1f2:	mov    r14,r13
 1f5:	and    r14,rcx
 1f8:	shl    r14,0x8
 1fc:	movabs rcx,0xff00ff00ff00ff00
 206:	mov    rbp,r13
 209:	and    rbp,rcx
 20c:	shr    rbp,0x8
 210:	mov    rcx,r14
 213:	or     rbp,rcx
 216:	movabs rcx,0xffff0000ffff
 220:	mov    r13,rbp
 223:	and    r13,rcx
 226:	shl    r13,0x10
 22a:	movabs rcx,0xffff0000ffff0000
 234:	and    rbp,rcx
 237:	shr    rbp,0x10
 23b:	mov    rcx,r13
 23e:	or     rbp,rcx
 241:	mov    ecx,0xffffffff
 246:	and    rbp,rcx
 249:	mov    QWORD PTR [r12+0x58],rbp
 24e:	mov    r13,QWORD PTR [r12+0xf8]
 256:	mov    r14,r13
 259:	add    r14,0x10
 25d:	mov    r8,r14
 260:	add    r8,0x4
 264:	mov    eax,DWORD PTR [r14]
 267:	mov    QWORD PTR [rsp],rax
 26b:	mov    r14d,DWORD PTR [r8]
 26e:	mov    rax,QWORD PTR [rsp]
 272:	mov    QWORD PTR [r12+0x50],rax
 277:	mov    QWORD PTR [r12+0x60],r14
 27c:	mov    r14,QWORD PTR [r12+0x48]
 281:	add    r14,0x8
 285:	mov    r8,r14
 288:	add    r8,0x4
 28c:	mov    rax,r15
 28f:	mov    eax,eax
 291:	mov    r9d,eax
 294:	mov    rax,rbp
 297:	mov    eax,eax
 299:	mov    r15d,eax
 29c:	mov    DWORD PTR [r14],r9d
 29f:	mov    r14d,0x0
 2a5:	mov    DWORD PTR [r12+0x32c],r14d
 2ad:	mov    DWORD PTR [r8],r15d
 2b0:	mov    r14d,0x0
 2b6:	mov    DWORD PTR [r12+0x32c],r14d
 2be:	add    r13,0x90
 2c5:	mov    r14,r13
 2c8:	add    r14,0x8
 2cc:	mov    r15,QWORD PTR [r13+0x0]
 2d0:	mov    r13,QWORD PTR [r14]
 2d3:	mov    QWORD PTR [r12+0xa0],r15
 2db:	mov    QWORD PTR [r12+0x98],r13
 2e3:	movabs rcx,0xff00ff00ff00ff
 2ed:	mov    r13,QWORD PTR [rsp]
 2f1:	and    r13,rcx
 2f4:	shl    r13,0x8
 2f8:	movabs rcx,0xff00ff00ff00ff00
 302:	mov    r14,QWORD PTR [rsp]
 306:	and    r14,rcx
 309:	shr    r14,0x8
 30d:	mov    rcx,r13
 310:	or     r14,rcx
 313:	movabs rcx,0xffff0000ffff
 31d:	mov    r13,r14
 320:	and    r13,rcx
 323:	shl    r13,0x10
 327:	movabs rcx,0xffff0000ffff0000
 331:	and    r14,rcx
 334:	shr    r14,0x10
 338:	mov    rcx,r13
 33b:	or     r14,rcx
 33e:	mov    ecx,0xffffffff
 343:	and    r14,rcx
 346:	mov    QWORD PTR [r12+0x40],r14
 34b:	mov    r13d,DWORD PTR [r12+0x60]
 350:	movabs rcx,0xff00ff00ff00ff
 35a:	mov    r15,r13
 35d:	and    r15,rcx
 360:	shl    r15,0x8
 364:	movabs rcx,0xff00ff00ff00ff00
 36e:	mov    rbp,r13
 371:	and    rbp,rcx
 374:	shr    rbp,0x8
 378:	mov    rcx,r15
 37b:	or     rbp,rcx
 37e:	movabs rcx,0xffff0000ffff
 388:	mov    r13,rbp
 38b:	and    r13,rcx
 38e:	shl    r13,0x10
 392:	movabs rcx,0xffff0000ffff0000
 39c:	and    rbp,rcx
 39f:	shr    rbp,0x10
 3a3:	mov    rcx,r13
 3a6:	or     rbp,rcx
 3a9:	mov    ecx,0xffffffff
 3ae:	and    rbp,rcx
 3b1:	mov    QWORD PTR [r12+0x58],rbp
 3b6:	mov    r13,QWORD PTR [r12+0xf8]
 3be:	add    r13,0x18
 3c2:	mov    r15,r13
 3c5:	add    r15,0x4
 3c9:	mov    r8d,DWORD PTR [r13+0x0]
 3cd:	mov    eax,DWORD PTR [r15]
 3d0:	mov    QWORD PTR [rsp+0x10],rax
 3d5:	mov    QWORD PTR [r12+0x50],r8
 3da:	mov    rax,QWORD PTR [rsp+0x10]
 3df:	mov    QWORD PTR [r12+0x60],rax
 3e4:	mov    rax,QWORD PTR [r12+0x48]
 3e9:	mov    QWORD PTR [rsp+0x8],rax
 3ee:	mov    r9,QWORD PTR [rsp+0x8]
 3f3:	add    r9,0x10
 3f7:	mov    r15,r9
 3fa:	add    r15,0x4
 3fe:	mov    rax,r14
 401:	mov    eax,eax
 403:	mov    r13d,eax
 406:	mov    rax,rbp
 409:	mov    eax,eax
 40b:	mov    r14d,eax
 40e:	mov    DWORD PTR [r9],r13d
 411:	mov    r13d,0x0
 417:	mov    DWORD PTR [r12+0x32c],r13d
 41f:	mov    DWORD PTR [r15],r14d
 422:	mov    r13d,0x0
 428:	mov    DWORD PTR [r12+0x32c],r13d
 430:	movabs rcx,0xff00ff00ff00ff
 43a:	mov    r13,r8
 43d:	and    r13,rcx
 440:	shl    r13,0x8
 444:	movabs rcx,0xff00ff00ff00ff00
 44e:	mov    r14,r8
 451:	and    r14,rcx
 454:	shr    r14,0x8
 458:	mov    rcx,r13
 45b:	or     r14,rcx
 45e:	movabs rcx,0xffff0000ffff
 468:	mov    r13,r14
 46b:	and    r13,rcx
 46e:	shl    r13,0x10
 472:	movabs rcx,0xffff0000ffff0000
 47c:	and    r14,rcx
 47f:	shr    r14,0x10
 483:	mov    rcx,r13
 486:	or     r14,rcx
 489:	mov    ecx,0xffffffff
 48e:	and    r14,rcx
 491:	mov    QWORD PTR [r12+0x40],r14
 496:	movabs rcx,0xff00ff00ff00ff
 4a0:	mov    r13,QWORD PTR [rsp+0x10]
 4a5:	and    r13,rcx
 4a8:	shl    r13,0x8
 4ac:	movabs rcx,0xff00ff00ff00ff00
 4b6:	mov    r15,QWORD PTR [rsp+0x10]
 4bb:	and    r15,rcx
 4be:	shr    r15,0x8
 4c2:	mov    rcx,r13
 4c5:	or     r15,rcx
 4c8:	movabs rcx,0xffff0000ffff
 4d2:	mov    r13,r15
 4d5:	and    r13,rcx
 4d8:	shl    r13,0x10
 4dc:	movabs rcx,0xffff0000ffff0000
 4e6:	and    r15,rcx
 4e9:	shr    r15,0x10
 4ed:	mov    rcx,r13
 4f0:	or     r15,rcx
 4f3:	mov    ecx,0xffffffff
 4f8:	and    r15,rcx
 4fb:	mov    QWORD PTR [r12+0x50],r15
 500:	mov    r13,QWORD PTR [rsp+0x8]
 505:	add    r13,0x18
 509:	mov    rbp,r13
 50c:	add    rbp,0x4
 510:	mov    rax,r14
 513:	mov    eax,eax
 515:	mov    r8d,eax
 518:	mov    rax,r15
 51b:	mov    eax,eax
 51d:	mov    r14d,eax
 520:	mov    DWORD PTR [r13+0x0],r8d
 524:	mov    r13d,0x0
 52a:	mov    DWORD PTR [r12+0x32c],r13d
 532:	mov    DWORD PTR [rbp+0x0],r14d
 536:	mov    r13d,0x0
 53c:	mov    DWORD PTR [r12+0x32c],r13d
 544:	mov    r13,QWORD PTR [r12+0xf8]
 54c:	add    r13,0xa0
 553:	mov    QWORD PTR [r12+0xf8],r13
 55b:	mov    rcx,QWORD PTR [r12+0x380]
 563:	jrcxz  0x56a
 565:	jmp    0x5a0
 56a:	mov    r13,QWORD PTR [r12+0xf0]
 572:	mov    QWORD PTR [r12+0x100],r13
 57a:	mov    r11,QWORD PTR [rsp+0x18]
 57f:	mov    QWORD PTR [r12+0x398],r11
 587:	mov    rdi,QWORD PTR [r12+0x100]
 58f:	add    rsp,0x20
 593:	movabs r11,0x58b3990a40a0
 59d:	jmp    r11
 5a0:	mov    eax,0x410334
 5a5:	mov    QWORD PTR [r12+0x100],rax
 5ad:	push   rdx
 5ae:	push   rsi
 5af:	push   r10
 5b1:	push   r11
 5b3:	mov    rdx,QWORD PTR [rsp+0x38]
 5b8:	mov    r10d,edx
 5bb:	and    r10d,0xc0
 5c2:	shl    r10d,0x18
 5c6:	mov    r11d,edx
 5c9:	and    r11d,0x1
 5cd:	shl    r11d,0x1d
 5d1:	or     r10d,r11d
 5d4:	mov    r11d,edx
 5d7:	and    r11d,0x800
 5de:	shl    r11d,0x11
 5e2:	or     r10d,r11d
 5e5:	btc    r10,0x1d
 5ea:	mov    r11d,0xf0000000
 5f0:	and    r11,r10
 5f3:	movabs rsi,0xffffffff0fffffff
 5fd:	and    rbx,rsi
 600:	or     rbx,r11
 603:	pop    r11
 605:	pop    r10
 607:	pop    rsi
 608:	pop    rdx
 609:	mov    QWORD PTR [r12+0x108],rbx
 611:	add    rsp,0x20
 615:	mov    eax,0xc
 61a:	movabs r11,0x58b3990a4390
 624:	jmp    r11
 627:	nop
