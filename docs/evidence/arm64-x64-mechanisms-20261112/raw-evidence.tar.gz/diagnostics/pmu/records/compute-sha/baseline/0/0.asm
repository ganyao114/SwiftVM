
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-sha/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13,QWORD PTR [r12+0xf8]
   8:	mov    r14,r13
   b:	sub    r14,0xa0
  12:	mov    QWORD PTR [r12+0xf8],r14
  1a:	mov    r13d,0x420000
  20:	mov    QWORD PTR [r12+0x40],r13
  25:	mov    r13d,0x420000
  2b:	mov    QWORD PTR [r12+0x48],r13
  30:	mov    r13,r14
  33:	add    r13,0x90
  3a:	mov    r14,r13
  3d:	add    r14,0x8
  41:	mov    r15,QWORD PTR [r12+0xa0]
  49:	mov    rbp,QWORD PTR [r12+0x98]
  51:	mov    QWORD PTR [r13+0x0],r15
  55:	mov    r13d,0x0
  5b:	mov    DWORD PTR [r12+0x32c],r13d
  63:	mov    QWORD PTR [r14],rbp
  66:	mov    r13d,0x0
  6c:	mov    DWORD PTR [r12+0x32c],r13d
  74:	mov    r13d,0x420670
  7a:	movdqu xmm2,XMMWORD PTR [r13+0x0]
  80:	movdqa xmm0,xmm2
  84:	movdqu XMMWORD PTR [r12+0x110],xmm0
  8e:	mov    r13d,0x420000
  94:	mov    QWORD PTR [r12+0x40],r13
  99:	mov    r13d,0x420610
  9f:	movdqu xmm3,XMMWORD PTR [r13+0x0]
  a5:	movdqa xmm0,xmm3
  a9:	movdqu XMMWORD PTR [r12+0x120],xmm0
  b3:	mov    r13d,0x420000
  b9:	mov    QWORD PTR [r12+0x48],r13
  be:	mov    r13d,0x420690
  c4:	movdqu xmm4,XMMWORD PTR [r13+0x0]
  ca:	movdqa xmm0,xmm4
  ce:	movdqu XMMWORD PTR [r12+0x130],xmm0
  d8:	mov    r13d,0x420000
  de:	mov    QWORD PTR [r12+0x40],r13
  e3:	mov    r13d,0x420630
  e9:	movdqu xmm5,XMMWORD PTR [r13+0x0]
  ef:	movdqa xmm0,xmm5
  f3:	movdqu XMMWORD PTR [r12+0x140],xmm0
  fd:	mov    r13d,0x430000
 103:	mov    QWORD PTR [r12+0x98],r13
 10b:	mov    r13d,0x430000
 111:	mov    r14,r13
 114:	add    r14,0x8a0
 11b:	mov    QWORD PTR [r12+0x98],r14
 123:	mov    r13,QWORD PTR [r12+0x40]
 128:	mov    r15,r13
 12b:	add    r15,0x6a0
 132:	movdqu xmm6,XMMWORD PTR [r15]
 137:	movdqa xmm0,xmm6
 13b:	movdqu XMMWORD PTR [r12+0x150],xmm0
 145:	mov    r13d,0x420000
 14b:	mov    QWORD PTR [r12+0x40],r13
 150:	mov    r13,r14
 153:	add    r13,0x10
 157:	movdqu XMMWORD PTR [r14],xmm2
 15c:	mov    r15d,0x0
 162:	mov    DWORD PTR [r12+0x32c],r15d
 16a:	movdqu XMMWORD PTR [r13+0x0],xmm3
 170:	mov    r13d,0x0
 176:	mov    DWORD PTR [r12+0x32c],r13d
 17e:	mov    r13,r14
 181:	add    r13,0x20
 185:	mov    r15,r13
 188:	add    r15,0x10
 18c:	movdqu XMMWORD PTR [r13+0x0],xmm4
 192:	mov    r13d,0x0
 198:	mov    DWORD PTR [r12+0x32c],r13d
 1a0:	movdqu XMMWORD PTR [r15],xmm5
 1a5:	mov    r13d,0x0
 1ab:	mov    DWORD PTR [r12+0x32c],r13d
 1b3:	mov    r13d,0x420600
 1b9:	movdqu xmm4,XMMWORD PTR [r13+0x0]
 1bf:	movdqa xmm0,xmm4
 1c3:	movdqu XMMWORD PTR [r12+0x130],xmm0
 1cd:	mov    r13d,0x420000
 1d3:	mov    QWORD PTR [r12+0x40],r13
 1d8:	mov    r13d,0x4205f0
 1de:	movdqu xmm5,XMMWORD PTR [r13+0x0]
 1e4:	movdqa xmm0,xmm5
 1e8:	movdqu XMMWORD PTR [r12+0x140],xmm0
 1f2:	mov    r13d,0x420000
 1f8:	mov    QWORD PTR [r12+0x40],r13
 1fd:	mov    r13,r14
 200:	add    r13,0x100
 207:	mov    r15,r13
 20a:	add    r15,0x10
 20e:	movdqu XMMWORD PTR [r13+0x0],xmm2
 214:	mov    r13d,0x0
 21a:	mov    DWORD PTR [r12+0x32c],r13d
 222:	movdqu XMMWORD PTR [r15],xmm3
 227:	mov    r13d,0x0
 22d:	mov    DWORD PTR [r12+0x32c],r13d
 235:	mov    r13,r14
 238:	add    r13,0x40
 23c:	mov    r14,r13
 23f:	add    r14,0x10
 243:	movdqu XMMWORD PTR [r13+0x0],xmm6
 249:	mov    r13d,0x0
 24f:	mov    DWORD PTR [r12+0x32c],r13d
 257:	movdqu XMMWORD PTR [r14],xmm4
 25c:	mov    r13d,0x0
 262:	mov    DWORD PTR [r12+0x32c],r13d
 26a:	mov    r13d,0x4205e0
 270:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 276:	movdqa xmm0,xmm2
 27a:	movdqu XMMWORD PTR [r12+0x130],xmm0
 284:	mov    r13d,0x420000
 28a:	mov    QWORD PTR [r12+0x40],r13
 28f:	mov    r13d,0x420640
 295:	movdqu xmm3,XMMWORD PTR [r13+0x0]
 29b:	movdqa xmm0,xmm3
 29f:	movdqu XMMWORD PTR [r12+0x150],xmm0
 2a9:	mov    r13d,0x420000
 2af:	mov    QWORD PTR [r12+0x40],r13
 2b4:	mov    r13d,0xf8d3
 2ba:	mov    QWORD PTR [r12+0x48],r13
 2bf:	mov    r13,QWORD PTR [r12+0x98]
 2c7:	mov    r14,r13
 2ca:	add    r14,0x60
 2ce:	mov    r15,r14
 2d1:	add    r15,0x10
 2d5:	movdqu XMMWORD PTR [r14],xmm5
 2da:	mov    r14d,0x0
 2e0:	mov    DWORD PTR [r12+0x32c],r14d
 2e8:	movdqu XMMWORD PTR [r15],xmm2
 2ed:	mov    r14d,0x0
 2f3:	mov    DWORD PTR [r12+0x32c],r14d
 2fb:	mov    r14d,0x420650
 301:	movdqu xmm2,XMMWORD PTR [r14]
 306:	movdqa xmm0,xmm2
 30a:	movdqu XMMWORD PTR [r12+0x130],xmm0
 314:	mov    r14d,0x420000
 31a:	mov    QWORD PTR [r12+0x40],r14
 31f:	mov    r14d,0x420620
 325:	movdqu xmm2,XMMWORD PTR [r14]
 32a:	movdqa xmm0,xmm2
 32e:	movdqu XMMWORD PTR [r12+0x140],xmm0
 338:	mov    r14d,0x420000
 33e:	mov    QWORD PTR [r12+0x40],r14
 343:	mov    r14d,0xf8d3
 349:	mov    r15d,0x421d
 34f:	and    r15d,0xffff
 356:	mov    rax,r14
 359:	movabs rcx,0xffffffff0000ffff
 363:	and    rax,rcx
 366:	mov    rdx,r15
 369:	shl    rdx,0x10
 36d:	mov    ecx,0xffff0000
 372:	and    rdx,rcx
 375:	or     rax,rdx
 378:	mov    ebp,eax
 37a:	mov    QWORD PTR [r12+0x48],rbp
 37f:	mov    r14,r13
 382:	add    r14,0x80
 389:	mov    r15,r14
 38c:	add    r15,0x10
 390:	movdqu xmm0,XMMWORD PTR [r12+0x130]
 39a:	movdqa xmm2,xmm0
 39e:	movdqu XMMWORD PTR [r14],xmm3
 3a3:	mov    r14d,0x0
 3a9:	mov    DWORD PTR [r12+0x32c],r14d
 3b1:	movdqu XMMWORD PTR [r15],xmm2
 3b6:	mov    r14d,0x0
 3bc:	mov    DWORD PTR [r12+0x32c],r14d
 3c4:	mov    r14d,0x4206c0
 3ca:	movdqu xmm2,XMMWORD PTR [r14]
 3cf:	movdqa xmm0,xmm2
 3d3:	movdqu XMMWORD PTR [r12+0x130],xmm0
 3dd:	mov    r14d,0x420000
 3e3:	mov    QWORD PTR [r12+0x40],r14
 3e8:	mov    r14d,0x4206d0
 3ee:	movdqu xmm3,XMMWORD PTR [r14]
 3f3:	movdqa xmm0,xmm3
 3f7:	movdqu XMMWORD PTR [r12+0x150],xmm0
 401:	mov    r14d,0x420000
 407:	mov    QWORD PTR [r12+0x40],r14
 40c:	mov    r14d,0x3e8
 412:	mov    QWORD PTR [r12+0xa0],r14
 41a:	mov    r14,r13
 41d:	add    r14,0xa0
 424:	mov    r13,r14
 427:	add    r13,0x10
 42b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
 435:	movdqa xmm3,xmm0
 439:	movdqu XMMWORD PTR [r14],xmm3
 43e:	mov    r14d,0x0
 444:	mov    DWORD PTR [r12+0x32c],r14d
 44c:	movdqu XMMWORD PTR [r13+0x0],xmm2
 452:	mov    r13d,0x0
 458:	mov    DWORD PTR [r12+0x32c],r13d
 460:	mov    r13,QWORD PTR [r12+0x40]
 465:	mov    r14,r13
 468:	add    r14,0x6b0
 46f:	movdqu xmm2,XMMWORD PTR [r14]
 474:	movdqa xmm0,xmm2
 478:	movdqu XMMWORD PTR [r12+0x130],xmm0
 482:	mov    r13d,0x420000
 488:	mov    QWORD PTR [r12+0x40],r13
 48d:	mov    r13d,0x420660
 493:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 499:	movdqa xmm0,xmm2
 49d:	movdqu XMMWORD PTR [r12+0x140],xmm0
 4a7:	mov    r13d,0x420000
 4ad:	mov    QWORD PTR [r12+0x40],r13
 4b2:	mov    r13,QWORD PTR [r12+0xf8]
 4ba:	mov    r14,r13
 4bd:	add    r14,0x80
 4c4:	mov    r13,QWORD PTR [r12+0xf0]
 4cc:	mov    QWORD PTR [r14],r13
 4cf:	mov    r13d,0x0
 4d5:	mov    DWORD PTR [r12+0x32c],r13d
 4dd:	mov    r13,QWORD PTR [r12+0x98]
 4e5:	mov    r14,r13
 4e8:	add    r14,0xc0
 4ef:	mov    r15,r14
 4f2:	add    r15,0x10
 4f6:	movdqu xmm0,XMMWORD PTR [r12+0x150]
 500:	movdqa xmm2,xmm0
 504:	movdqu xmm0,XMMWORD PTR [r12+0x130]
 50e:	movdqa xmm3,xmm0
 512:	movdqu XMMWORD PTR [r14],xmm2
 517:	mov    r14d,0x0
 51d:	mov    DWORD PTR [r12+0x32c],r14d
 525:	movdqu XMMWORD PTR [r15],xmm3
 52a:	mov    r14d,0x0
 530:	mov    DWORD PTR [r12+0x32c],r14d
 538:	mov    r14d,0x420680
 53e:	movdqu xmm2,XMMWORD PTR [r14]
 543:	movdqa xmm0,xmm2
 547:	movdqu XMMWORD PTR [r12+0x130],xmm0
 551:	mov    r14d,0x420000
 557:	mov    QWORD PTR [r12+0x40],r14
 55c:	mov    r14d,0x4206e0
 562:	mov    r15,QWORD PTR [r14]
 565:	mov    r14d,0x0
 56b:	mov    QWORD PTR [r12+0x110],r15
 573:	mov    QWORD PTR [r12+0x118],r14
 57b:	mov    r14d,0x4206e8
 581:	mov    QWORD PTR [r12+0x40],r14
 586:	mov    r14,r13
 589:	add    r14,0xe0
 590:	mov    rbp,r14
 593:	add    rbp,0x10
 597:	movdqu xmm0,XMMWORD PTR [r12+0x140]
 5a1:	movdqa xmm3,xmm0
 5a5:	movdqu XMMWORD PTR [r14],xmm3
 5aa:	mov    r14d,0x0
 5b0:	mov    DWORD PTR [r12+0x32c],r14d
 5b8:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 5bd:	mov    r14d,0x0
 5c3:	mov    DWORD PTR [r12+0x32c],r14d
 5cb:	mov    r14d,0x420748
 5d1:	movdqu xmm2,XMMWORD PTR [r14]
 5d6:	movdqa xmm0,xmm2
 5da:	movdqu XMMWORD PTR [r12+0x130],xmm0
 5e4:	mov    r14,r13
 5e7:	add    r14,0x120
 5ee:	mov    QWORD PTR [r14],r15
 5f1:	mov    r13d,0x0
 5f7:	mov    DWORD PTR [r12+0x32c],r13d
 5ff:	mov    r13d,0x420728
 605:	mov    r14d,0x420738
 60b:	movdqu xmm3,XMMWORD PTR [r13+0x0]
 611:	movdqu xmm4,XMMWORD PTR [r14]
 616:	movdqa xmm0,xmm3
 61a:	movdqu XMMWORD PTR [r12+0x120],xmm0
 624:	movdqa xmm0,xmm4
 628:	movdqu XMMWORD PTR [r12+0x110],xmm0
 632:	mov    r13,QWORD PTR [r12+0xf8]
 63a:	mov    r14,r13
 63d:	add    r14,0x60
 641:	movdqu XMMWORD PTR [r14],xmm2
 646:	mov    r14d,0x0
 64c:	mov    DWORD PTR [r12+0x32c],r14d
 654:	mov    r14,QWORD PTR [r12+0x98]
 65c:	mov    r15,r14
 65f:	add    r15,0x128
 666:	mov    ebp,DWORD PTR [r12+0x48]
 66b:	mov    DWORD PTR [r15],ebp
 66e:	mov    r15d,0x0
 674:	mov    DWORD PTR [r12+0x32c],r15d
 67c:	mov    r15,r13
 67f:	add    r15,0x40
 683:	mov    rbp,r15
 686:	add    rbp,0x10
 68a:	movdqu XMMWORD PTR [r15],xmm3
 68f:	mov    r15d,0x0
 695:	mov    DWORD PTR [r12+0x32c],r15d
 69d:	movdqu XMMWORD PTR [rbp+0x0],xmm4
 6a2:	mov    r15d,0x0
 6a8:	mov    DWORD PTR [r12+0x32c],r15d
 6b0:	mov    r15d,0x4206e8
 6b6:	mov    ebp,0x4206f8
 6bb:	movdqu xmm2,XMMWORD PTR [r15]
 6c0:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
 6c5:	movdqa xmm0,xmm2
 6c9:	movdqu XMMWORD PTR [r12+0x110],xmm0
 6d3:	movdqa xmm0,xmm3
 6d7:	movdqu XMMWORD PTR [r12+0x120],xmm0
 6e1:	mov    r15,r13
 6e4:	add    r15,0x10
 6e8:	movdqu XMMWORD PTR [r13+0x0],xmm2
 6ee:	mov    ebp,0x0
 6f3:	mov    DWORD PTR [r12+0x32c],ebp
 6fb:	movdqu XMMWORD PTR [r15],xmm3
 700:	mov    r15d,0x0
 706:	mov    DWORD PTR [r12+0x32c],r15d
 70e:	mov    r15d,0x420708
 714:	mov    ebp,0x420718
 719:	movdqu xmm2,XMMWORD PTR [r15]
 71e:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
 723:	movdqa xmm0,xmm2
 727:	movdqu XMMWORD PTR [r12+0x110],xmm0
 731:	movdqa xmm0,xmm3
 735:	movdqu XMMWORD PTR [r12+0x130],xmm0
 73f:	mov    r15,r13
 742:	add    r15,0x20
 746:	mov    rbp,r15
 749:	add    rbp,0x10
 74d:	movdqu XMMWORD PTR [r15],xmm2
 752:	mov    r15d,0x0
 758:	mov    DWORD PTR [r12+0x32c],r15d
 760:	movdqu XMMWORD PTR [rbp+0x0],xmm3
 765:	mov    r15d,0x0
 76b:	mov    DWORD PTR [r12+0x32c],r15d
 773:	mov    r15,r13
 776:	add    r15,0x0
 77a:	mov    QWORD PTR [r12],r15
 77e:	mov    r13d,0x0
 784:	mov    rcx,r14
 787:	mov    r15,r13
 78a:	or     r15,rcx
 78d:	mov    QWORD PTR [r12+0x8],r15
 792:	mov    r13d,0x12c
 798:	mov    QWORD PTR [r12+0x10],r13
 79d:	mov    r13d,0x410274
 7a3:	mov    QWORD PTR [r12+0xf0],r13
 7ab:	mov    r13d,0x410338
 7b1:	mov    QWORD PTR [r12+0x100],r13
 7b9:	mov    QWORD PTR [r12+0x108],rbx
 7c1:	mov    edi,0x410338
 7c6:	mov    QWORD PTR [r12+0x100],rdi
 7ce:	xchg   ax,ax
 7d0:	jmp    QWORD PTR [rip+0x2]        # 0x7d8
 7d6:	xchg   ax,ax
 7d8:	add    al,ch
 7da:	rex.WRXB ret
 7dc:	add    al,0x79
 7de:	add    BYTE PTR [rax],al
 7e0:	call   0x4c357cc
 7e5:	jns    0x7e7
 7e7:	add    BYTE PTR [rcx-0x45],cl
 7ea:	jo     0x7ef
 7ec:	pop    rcx
 7ed:	jl     0x7a8
 7ef:	push   rsi
 7f0:	add    BYTE PTR [rax],al
 7f2:	jmp    r11
 7f5:	nop
 7f6:	nop
 7f7:	nop
