
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/memory/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13d,0x1b00
   6:	mov    QWORD PTR [r12+0x8],r13
   b:	mov    r13d,0x1b00
  11:	mov    r14d,0xb7
  17:	and    r14d,0xffff
  1e:	mov    rax,r13
  21:	movabs rcx,0xffffffff0000ffff
  2b:	and    rax,rcx
  2e:	mov    rdx,r14
  31:	shl    rdx,0x10
  35:	mov    ecx,0xffff0000
  3a:	and    rdx,rcx
  3d:	or     rax,rdx
  40:	mov    r15,rax
  43:	mov    QWORD PTR [r12+0x8],r15
  48:	mov    r13d,0x420060
  4e:	mov    QWORD PTR [r12+0x20],r13
  53:	mov    r13d,0x0
  59:	mov    QWORD PTR [r12],r13
  5d:	jmp    0x62
  62:	mov    r13,QWORD PTR [r12+0x20]
  67:	mov    r14,QWORD PTR [r12]
  6b:	mov    QWORD PTR [r13+0x0],r14
  6f:	mov    r14d,0x0
  75:	mov    DWORD PTR [r12+0x32c],r14d
  7d:	mov    r14,QWORD PTR [r13+0x0]
  81:	mov    QWORD PTR [r12+0x18],r14
  86:	mov    r13,r14
  89:	add    r13,0x3
  8d:	mov    QWORD PTR [r12],r13
  91:	mov    r13,QWORD PTR [r12+0x8]
  96:	mov    r14,r13
  99:	sub    r14,0x1
  9d:	pushf
  9e:	pop    rdx
  9f:	mov    r10d,edx
  a2:	and    r10d,0xc0
  a9:	shl    r10d,0x18
  ad:	mov    r11d,edx
  b0:	and    r11d,0x1
  b4:	shl    r11d,0x1d
  b8:	or     r10d,r11d
  bb:	mov    r11d,edx
  be:	and    r11d,0x800
  c5:	shl    r11d,0x11
  c9:	or     r10d,r11d
  cc:	mov    r11d,0xf0000000
  d2:	and    r11,r10
  d5:	movabs rsi,0xffffffff0fffffff
  df:	and    rbx,rsi
  e2:	or     rbx,r11
  e5:	btc    rbx,0x1d
  ea:	mov    QWORD PTR [r12+0x8],r14
  ef:	cmp    QWORD PTR [r12+0x380],0x0
  f8:	je     0x125
  fe:	mov    eax,0x41004c
 103:	mov    QWORD PTR [r12+0x100],rax
 10b:	mov    QWORD PTR [r12+0x108],rbx
 113:	mov    eax,0xc
 118:	movabs r11,0x62f32ff335f0
 122:	jmp    r11
 125:	test   ebx,0x40000000
 12b:	je     0x62
 131:	jmp    0x136
 136:	mov    r13,QWORD PTR [r12+0x20]
 13b:	mov    r14,QWORD PTR [r12]
 13f:	mov    QWORD PTR [r13+0x0],r14
 143:	mov    r13d,0x0
 149:	mov    DWORD PTR [r12+0x32c],r13d
 151:	cmp    QWORD PTR [r12+0x380],0x0
 15a:	je     0x187
 160:	mov    eax,0x410054
 165:	mov    QWORD PTR [r12+0x100],rax
 16d:	mov    QWORD PTR [r12+0x108],rbx
 175:	mov    eax,0xc
 17a:	movabs r11,0x62f32ff335f0
 184:	jmp    r11
 187:	mov    r13,QWORD PTR [r12+0xf0]
 18f:	mov    QWORD PTR [r12+0x100],r13
 197:	mov    QWORD PTR [r12+0x108],rbx
 19f:	mov    rdi,QWORD PTR [r12+0x100]
 1a7:	movabs r11,0x62f32ff33370
 1b1:	jmp    r11
 1b4:	data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 1c0:	jmp    0x62
 1c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 1d0:	jmp    0x136
 1d5:	nop
 1d6:	nop
 1d7:	nop
