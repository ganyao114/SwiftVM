00007ad95fbce69b  nop [rax+rax*1], eax
00007ad95fbce6a0  mov qword ptr [r15+0x20], 0x420060
00007ad95fbce6a8  mov eax, 0x420060
00007ad95fbce6ad  xor r14d, r14d
00007ad95fbce6b0  mov [r13+rax*1], r14
00007ad95fbce6b5  mov eax, 0x420060
00007ad95fbce6ba  mov r14, [r13+rax*1]
00007ad95fbce6bf  mov [r15+0x18], r14
00007ad95fbce6c3  lea rax, [r14+0x03]
00007ad95fbce6c7  mov [r15], rax
00007ad95fbce6ca  xor eax, eax
00007ad95fbce6cc  mov r14d, 0xB71B00
00007ad95fbce6d2  mov r12d, 0x01
00007ad95fbce6d8  sub r14, r12
00007ad95fbce6db  cmc
00007ad95fbce6dc  lahf
00007ad95fbce6dd  seto al
00007ad95fbce6e0  mov [r15+0x108], eax
00007ad95fbce6e7  mov [r15+0x08], r14
00007ad95fbce6eb  mov eax, [r15+0x108]
00007ad95fbce6f2  sahf
00007ad95fbce6f3  jnz 0x00007AD95FBCE725
00007ad95fbce6f5  cmp dword ptr [r15+0x318], 0x00
00007ad95fbce6fd  jz 0x00007AD95FBCE840
00007ad95fbce703  nop [rax+rax*1], ax
00007ad95fbce70c  nop [rax+rax*1], eax
00007ad95fbce714  mov eax, 0x410050
00007ad95fbce719  mov [r15+0x100], rax
00007ad95fbce720  jmp 0x00007AD95F9FE110
00007ad95fbce725  cmp dword ptr [r15+0x318], 0x00
00007ad95fbce72d  jz 0x00007AD95FBCE770
00007ad95fbce733  nop [rax+rax*1], ax
00007ad95fbce73c  nop [rax+rax*1], eax
00007ad95fbce744  mov eax, 0x41003C
00007ad95fbce749  mov [r15+0x100], rax
00007ad95fbce750  jmp 0x00007AD95F9FE110
00007ad95fbce755  int3
00007ad95fbce756  call 0x00007AD95FA0E120
00007ad95fbce75b  jmp 0x00007AD95FBCE6B5
00007ad95fbce760  call 0x00007AD95FA0DC20
00007ad95fbce765  jmp 0x00007AD95FBCE6BF
00007ad95fbce76a  int3
00007ad95fbce76b  nop [rax+rax*1], eax
00007ad95fbce770  mov rax, [r15+0x20]
00007ad95fbce774  mov r14, [r15]
00007ad95fbce777  mov [r13+rax*1], r14
00007ad95fbce77c  mov r14, [r13+rax*1]
00007ad95fbce781  mov [r15+0x18], r14
00007ad95fbce785  lea rax, [r14+0x03]
00007ad95fbce789  mov [r15], rax
00007ad95fbce78c  mov rax, [r15+0x08]
00007ad95fbce790  mov [rsp+0x10], rax
00007ad95fbce795  xor eax, eax
00007ad95fbce797  mov r14, [rsp+0x10]
00007ad95fbce79c  mov r12d, 0x01
00007ad95fbce7a2  sub r14, r12
00007ad95fbce7a5  cmc
00007ad95fbce7a6  lahf
00007ad95fbce7a7  seto al
00007ad95fbce7aa  mov [r15+0x108], eax
00007ad95fbce7b1  mov [r15+0x08], r14
00007ad95fbce7b5  mov eax, [r15+0x108]
00007ad95fbce7bc  sahf
00007ad95fbce7bd  jnz 0x00007AD95FBCE7EF
00007ad95fbce7bf  cmp dword ptr [r15+0x318], 0x00
00007ad95fbce7c7  jz 0x00007AD95FBCE840
00007ad95fbce7cd  nop [rax+rax*1], ax
00007ad95fbce7d6  nop [rax+rax*1], eax
00007ad95fbce7de  mov eax, 0x410050
00007ad95fbce7e3  mov [r15+0x100], rax
00007ad95fbce7ea  jmp 0x00007AD95F9FE110
00007ad95fbce7ef  cmp dword ptr [r15+0x318], 0x00
00007ad95fbce7f7  jz 0x00007AD95FBCE770
00007ad95fbce7fd  nop [rax+rax*1], ax
00007ad95fbce806  nop [rax+rax*1], eax
00007ad95fbce80e  mov eax, 0x41003C
00007ad95fbce813  mov [r15+0x100], rax
00007ad95fbce81a  jmp 0x00007AD95F9FE110
00007ad95fbce81f  int3
00007ad95fbce820  call 0x00007AD95FA0E120
00007ad95fbce825  jmp 0x00007AD95FBCE77C
00007ad95fbce82a  call 0x00007AD95FA0DC20
00007ad95fbce82f  jmp 0x00007AD95FBCE781
00007ad95fbce834  int3
00007ad95fbce835  nop [rax+rax*1], ax
00007ad95fbce83e  nop
00007ad95fbce840  mov rax, [r15+0x20]
00007ad95fbce844  mov r14, [r15]
00007ad95fbce847  mov [r13+rax*1], r14
00007ad95fbce84c  mov rax, [r15+0xF0]
00007ad95fbce853  mov [r15+0x100], rax
00007ad95fbce85a  jmp 0x00007AD95FBCE5C0
00007ad95fbce85f  int3
00007ad95fbce860  call 0x00007AD95FA0E120
00007ad95fbce865  jmp 0x00007AD95FBCE84C
00007ad95fbce86a  int3
00007ad95fbce86b  nop [rax+rax*1], eax
00007ad95fbce870  mov qword ptr [r15+0x100], 0x04
00007ad95fbce87b  mov esi, 0x00
00007ad95fbce880  mov edx, 0x09
00007ad95fbce885  mov rdi, 0x7FFF2EB50510
00007ad95fbce88f  mov rax, 0x59D3FD728970
00007ad95fbce899  call rax
00007ad95fbce89b  cmp dword ptr [r15+0x318], 0x00
00007ad95fbce8a3  jnz 0x00007AD95F9FE110
00007ad95fbce8a9  jmp 0x00007AD95F9FE0A0
00007ad95fbce8ae  int3
00007ad95fbce8af  int3
