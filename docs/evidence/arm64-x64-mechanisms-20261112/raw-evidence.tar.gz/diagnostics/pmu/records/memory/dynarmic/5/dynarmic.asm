00007dc149fce69b  nop [rax+rax*1], eax
00007dc149fce6a0  mov qword ptr [r15+0x20], 0x420060
00007dc149fce6a8  mov eax, 0x420060
00007dc149fce6ad  xor r14d, r14d
00007dc149fce6b0  mov [r13+rax*1], r14
00007dc149fce6b5  mov eax, 0x420060
00007dc149fce6ba  mov r14, [r13+rax*1]
00007dc149fce6bf  mov [r15+0x18], r14
00007dc149fce6c3  lea rax, [r14+0x03]
00007dc149fce6c7  mov [r15], rax
00007dc149fce6ca  xor eax, eax
00007dc149fce6cc  mov r14d, 0xB71B00
00007dc149fce6d2  mov r12d, 0x01
00007dc149fce6d8  sub r14, r12
00007dc149fce6db  cmc
00007dc149fce6dc  lahf
00007dc149fce6dd  seto al
00007dc149fce6e0  mov [r15+0x108], eax
00007dc149fce6e7  mov [r15+0x08], r14
00007dc149fce6eb  mov eax, [r15+0x108]
00007dc149fce6f2  sahf
00007dc149fce6f3  jnz 0x00007DC149FCE725
00007dc149fce6f5  cmp dword ptr [r15+0x318], 0x00
00007dc149fce6fd  jz 0x00007DC149FCE840
00007dc149fce703  nop [rax+rax*1], ax
00007dc149fce70c  nop [rax+rax*1], eax
00007dc149fce714  mov eax, 0x410050
00007dc149fce719  mov [r15+0x100], rax
00007dc149fce720  jmp 0x00007DC149DFE110
00007dc149fce725  cmp dword ptr [r15+0x318], 0x00
00007dc149fce72d  jz 0x00007DC149FCE770
00007dc149fce733  nop [rax+rax*1], ax
00007dc149fce73c  nop [rax+rax*1], eax
00007dc149fce744  mov eax, 0x41003C
00007dc149fce749  mov [r15+0x100], rax
00007dc149fce750  jmp 0x00007DC149DFE110
00007dc149fce755  int3
00007dc149fce756  call 0x00007DC149E0E120
00007dc149fce75b  jmp 0x00007DC149FCE6B5
00007dc149fce760  call 0x00007DC149E0DC20
00007dc149fce765  jmp 0x00007DC149FCE6BF
00007dc149fce76a  int3
00007dc149fce76b  nop [rax+rax*1], eax
00007dc149fce770  mov rax, [r15+0x20]
00007dc149fce774  mov r14, [r15]
00007dc149fce777  mov [r13+rax*1], r14
00007dc149fce77c  mov r14, [r13+rax*1]
00007dc149fce781  mov [r15+0x18], r14
00007dc149fce785  lea rax, [r14+0x03]
00007dc149fce789  mov [r15], rax
00007dc149fce78c  mov rax, [r15+0x08]
00007dc149fce790  mov [rsp+0x10], rax
00007dc149fce795  xor eax, eax
00007dc149fce797  mov r14, [rsp+0x10]
00007dc149fce79c  mov r12d, 0x01
00007dc149fce7a2  sub r14, r12
00007dc149fce7a5  cmc
00007dc149fce7a6  lahf
00007dc149fce7a7  seto al
00007dc149fce7aa  mov [r15+0x108], eax
00007dc149fce7b1  mov [r15+0x08], r14
00007dc149fce7b5  mov eax, [r15+0x108]
00007dc149fce7bc  sahf
00007dc149fce7bd  jnz 0x00007DC149FCE7EF
00007dc149fce7bf  cmp dword ptr [r15+0x318], 0x00
00007dc149fce7c7  jz 0x00007DC149FCE840
00007dc149fce7cd  nop [rax+rax*1], ax
00007dc149fce7d6  nop [rax+rax*1], eax
00007dc149fce7de  mov eax, 0x410050
00007dc149fce7e3  mov [r15+0x100], rax
00007dc149fce7ea  jmp 0x00007DC149DFE110
00007dc149fce7ef  cmp dword ptr [r15+0x318], 0x00
00007dc149fce7f7  jz 0x00007DC149FCE770
00007dc149fce7fd  nop [rax+rax*1], ax
00007dc149fce806  nop [rax+rax*1], eax
00007dc149fce80e  mov eax, 0x41003C
00007dc149fce813  mov [r15+0x100], rax
00007dc149fce81a  jmp 0x00007DC149DFE110
00007dc149fce81f  int3
00007dc149fce820  call 0x00007DC149E0E120
00007dc149fce825  jmp 0x00007DC149FCE77C
00007dc149fce82a  call 0x00007DC149E0DC20
00007dc149fce82f  jmp 0x00007DC149FCE781
00007dc149fce834  int3
00007dc149fce835  nop [rax+rax*1], ax
00007dc149fce83e  nop
00007dc149fce840  mov rax, [r15+0x20]
00007dc149fce844  mov r14, [r15]
00007dc149fce847  mov [r13+rax*1], r14
00007dc149fce84c  mov rax, [r15+0xF0]
00007dc149fce853  mov [r15+0x100], rax
00007dc149fce85a  jmp 0x00007DC149FCE5C0
00007dc149fce85f  int3
00007dc149fce860  call 0x00007DC149E0E120
00007dc149fce865  jmp 0x00007DC149FCE84C
00007dc149fce86a  int3
00007dc149fce86b  nop [rax+rax*1], eax
00007dc149fce870  mov qword ptr [r15+0x100], 0x04
00007dc149fce87b  mov esi, 0x00
00007dc149fce880  mov edx, 0x09
00007dc149fce885  mov rdi, 0x7FFC8BE6BB20
00007dc149fce88f  mov rax, 0x58C80CECB970
00007dc149fce899  call rax
00007dc149fce89b  cmp dword ptr [r15+0x318], 0x00
00007dc149fce8a3  jnz 0x00007DC149DFE110
00007dc149fce8a9  jmp 0x00007DC149DFE0A0
00007dc149fce8ae  int3
00007dc149fce8af  int3
