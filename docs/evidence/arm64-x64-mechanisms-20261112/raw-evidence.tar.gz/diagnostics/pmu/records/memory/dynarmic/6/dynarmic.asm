0000775b2cfce69b  nop [rax+rax*1], eax
0000775b2cfce6a0  mov qword ptr [r15+0x20], 0x420060
0000775b2cfce6a8  mov eax, 0x420060
0000775b2cfce6ad  xor r14d, r14d
0000775b2cfce6b0  mov [r13+rax*1], r14
0000775b2cfce6b5  mov eax, 0x420060
0000775b2cfce6ba  mov r14, [r13+rax*1]
0000775b2cfce6bf  mov [r15+0x18], r14
0000775b2cfce6c3  lea rax, [r14+0x03]
0000775b2cfce6c7  mov [r15], rax
0000775b2cfce6ca  xor eax, eax
0000775b2cfce6cc  mov r14d, 0xB71B00
0000775b2cfce6d2  mov r12d, 0x01
0000775b2cfce6d8  sub r14, r12
0000775b2cfce6db  cmc
0000775b2cfce6dc  lahf
0000775b2cfce6dd  seto al
0000775b2cfce6e0  mov [r15+0x108], eax
0000775b2cfce6e7  mov [r15+0x08], r14
0000775b2cfce6eb  mov eax, [r15+0x108]
0000775b2cfce6f2  sahf
0000775b2cfce6f3  jnz 0x0000775B2CFCE725
0000775b2cfce6f5  cmp dword ptr [r15+0x318], 0x00
0000775b2cfce6fd  jz 0x0000775B2CFCE840
0000775b2cfce703  nop [rax+rax*1], ax
0000775b2cfce70c  nop [rax+rax*1], eax
0000775b2cfce714  mov eax, 0x410050
0000775b2cfce719  mov [r15+0x100], rax
0000775b2cfce720  jmp 0x0000775B2CDFE110
0000775b2cfce725  cmp dword ptr [r15+0x318], 0x00
0000775b2cfce72d  jz 0x0000775B2CFCE770
0000775b2cfce733  nop [rax+rax*1], ax
0000775b2cfce73c  nop [rax+rax*1], eax
0000775b2cfce744  mov eax, 0x41003C
0000775b2cfce749  mov [r15+0x100], rax
0000775b2cfce750  jmp 0x0000775B2CDFE110
0000775b2cfce755  int3
0000775b2cfce756  call 0x0000775B2CE0E120
0000775b2cfce75b  jmp 0x0000775B2CFCE6B5
0000775b2cfce760  call 0x0000775B2CE0DC20
0000775b2cfce765  jmp 0x0000775B2CFCE6BF
0000775b2cfce76a  int3
0000775b2cfce76b  nop [rax+rax*1], eax
0000775b2cfce770  mov rax, [r15+0x20]
0000775b2cfce774  mov r14, [r15]
0000775b2cfce777  mov [r13+rax*1], r14
0000775b2cfce77c  mov r14, [r13+rax*1]
0000775b2cfce781  mov [r15+0x18], r14
0000775b2cfce785  lea rax, [r14+0x03]
0000775b2cfce789  mov [r15], rax
0000775b2cfce78c  mov rax, [r15+0x08]
0000775b2cfce790  mov [rsp+0x10], rax
0000775b2cfce795  xor eax, eax
0000775b2cfce797  mov r14, [rsp+0x10]
0000775b2cfce79c  mov r12d, 0x01
0000775b2cfce7a2  sub r14, r12
0000775b2cfce7a5  cmc
0000775b2cfce7a6  lahf
0000775b2cfce7a7  seto al
0000775b2cfce7aa  mov [r15+0x108], eax
0000775b2cfce7b1  mov [r15+0x08], r14
0000775b2cfce7b5  mov eax, [r15+0x108]
0000775b2cfce7bc  sahf
0000775b2cfce7bd  jnz 0x0000775B2CFCE7EF
0000775b2cfce7bf  cmp dword ptr [r15+0x318], 0x00
0000775b2cfce7c7  jz 0x0000775B2CFCE840
0000775b2cfce7cd  nop [rax+rax*1], ax
0000775b2cfce7d6  nop [rax+rax*1], eax
0000775b2cfce7de  mov eax, 0x410050
0000775b2cfce7e3  mov [r15+0x100], rax
0000775b2cfce7ea  jmp 0x0000775B2CDFE110
0000775b2cfce7ef  cmp dword ptr [r15+0x318], 0x00
0000775b2cfce7f7  jz 0x0000775B2CFCE770
0000775b2cfce7fd  nop [rax+rax*1], ax
0000775b2cfce806  nop [rax+rax*1], eax
0000775b2cfce80e  mov eax, 0x41003C
0000775b2cfce813  mov [r15+0x100], rax
0000775b2cfce81a  jmp 0x0000775B2CDFE110
0000775b2cfce81f  int3
0000775b2cfce820  call 0x0000775B2CE0E120
0000775b2cfce825  jmp 0x0000775B2CFCE77C
0000775b2cfce82a  call 0x0000775B2CE0DC20
0000775b2cfce82f  jmp 0x0000775B2CFCE781
0000775b2cfce834  int3
0000775b2cfce835  nop [rax+rax*1], ax
0000775b2cfce83e  nop
0000775b2cfce840  mov rax, [r15+0x20]
0000775b2cfce844  mov r14, [r15]
0000775b2cfce847  mov [r13+rax*1], r14
0000775b2cfce84c  mov rax, [r15+0xF0]
0000775b2cfce853  mov [r15+0x100], rax
0000775b2cfce85a  jmp 0x0000775B2CFCE5C0
0000775b2cfce85f  int3
0000775b2cfce860  call 0x0000775B2CE0E120
0000775b2cfce865  jmp 0x0000775B2CFCE84C
0000775b2cfce86a  int3
0000775b2cfce86b  nop [rax+rax*1], eax
0000775b2cfce870  mov qword ptr [r15+0x100], 0x04
0000775b2cfce87b  mov esi, 0x00
0000775b2cfce880  mov edx, 0x09
0000775b2cfce885  mov rdi, 0x7FFC51677EE0
0000775b2cfce88f  mov rax, 0x5D05CE2A8970
0000775b2cfce899  call rax
0000775b2cfce89b  cmp dword ptr [r15+0x318], 0x00
0000775b2cfce8a3  jnz 0x0000775B2CDFE110
0000775b2cfce8a9  jmp 0x0000775B2CDFE0A0
0000775b2cfce8ae  int3
0000775b2cfce8af  int3
