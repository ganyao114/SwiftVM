00007b0a20dce69b  nop [rax+rax*1], eax
00007b0a20dce6a0  mov qword ptr [r15+0x20], 0x420060
00007b0a20dce6a8  mov eax, 0x420060
00007b0a20dce6ad  xor r14d, r14d
00007b0a20dce6b0  mov [r13+rax*1], r14
00007b0a20dce6b5  mov eax, 0x420060
00007b0a20dce6ba  mov r14, [r13+rax*1]
00007b0a20dce6bf  mov [r15+0x18], r14
00007b0a20dce6c3  lea rax, [r14+0x03]
00007b0a20dce6c7  mov [r15], rax
00007b0a20dce6ca  xor eax, eax
00007b0a20dce6cc  mov r14d, 0xB71B00
00007b0a20dce6d2  mov r12d, 0x01
00007b0a20dce6d8  sub r14, r12
00007b0a20dce6db  cmc
00007b0a20dce6dc  lahf
00007b0a20dce6dd  seto al
00007b0a20dce6e0  mov [r15+0x108], eax
00007b0a20dce6e7  mov [r15+0x08], r14
00007b0a20dce6eb  mov eax, [r15+0x108]
00007b0a20dce6f2  sahf
00007b0a20dce6f3  jnz 0x00007B0A20DCE725
00007b0a20dce6f5  cmp dword ptr [r15+0x318], 0x00
00007b0a20dce6fd  jz 0x00007B0A20DCE840
00007b0a20dce703  nop [rax+rax*1], ax
00007b0a20dce70c  nop [rax+rax*1], eax
00007b0a20dce714  mov eax, 0x410050
00007b0a20dce719  mov [r15+0x100], rax
00007b0a20dce720  jmp 0x00007B0A20BFE110
00007b0a20dce725  cmp dword ptr [r15+0x318], 0x00
00007b0a20dce72d  jz 0x00007B0A20DCE770
00007b0a20dce733  nop [rax+rax*1], ax
00007b0a20dce73c  nop [rax+rax*1], eax
00007b0a20dce744  mov eax, 0x41003C
00007b0a20dce749  mov [r15+0x100], rax
00007b0a20dce750  jmp 0x00007B0A20BFE110
00007b0a20dce755  int3
00007b0a20dce756  call 0x00007B0A20C0E120
00007b0a20dce75b  jmp 0x00007B0A20DCE6B5
00007b0a20dce760  call 0x00007B0A20C0DC20
00007b0a20dce765  jmp 0x00007B0A20DCE6BF
00007b0a20dce76a  int3
00007b0a20dce76b  nop [rax+rax*1], eax
00007b0a20dce770  mov rax, [r15+0x20]
00007b0a20dce774  mov r14, [r15]
00007b0a20dce777  mov [r13+rax*1], r14
00007b0a20dce77c  mov r14, [r13+rax*1]
00007b0a20dce781  mov [r15+0x18], r14
00007b0a20dce785  lea rax, [r14+0x03]
00007b0a20dce789  mov [r15], rax
00007b0a20dce78c  mov rax, [r15+0x08]
00007b0a20dce790  mov [rsp+0x10], rax
00007b0a20dce795  xor eax, eax
00007b0a20dce797  mov r14, [rsp+0x10]
00007b0a20dce79c  mov r12d, 0x01
00007b0a20dce7a2  sub r14, r12
00007b0a20dce7a5  cmc
00007b0a20dce7a6  lahf
00007b0a20dce7a7  seto al
00007b0a20dce7aa  mov [r15+0x108], eax
00007b0a20dce7b1  mov [r15+0x08], r14
00007b0a20dce7b5  mov eax, [r15+0x108]
00007b0a20dce7bc  sahf
00007b0a20dce7bd  jnz 0x00007B0A20DCE7EF
00007b0a20dce7bf  cmp dword ptr [r15+0x318], 0x00
00007b0a20dce7c7  jz 0x00007B0A20DCE840
00007b0a20dce7cd  nop [rax+rax*1], ax
00007b0a20dce7d6  nop [rax+rax*1], eax
00007b0a20dce7de  mov eax, 0x410050
00007b0a20dce7e3  mov [r15+0x100], rax
00007b0a20dce7ea  jmp 0x00007B0A20BFE110
00007b0a20dce7ef  cmp dword ptr [r15+0x318], 0x00
00007b0a20dce7f7  jz 0x00007B0A20DCE770
00007b0a20dce7fd  nop [rax+rax*1], ax
00007b0a20dce806  nop [rax+rax*1], eax
00007b0a20dce80e  mov eax, 0x41003C
00007b0a20dce813  mov [r15+0x100], rax
00007b0a20dce81a  jmp 0x00007B0A20BFE110
00007b0a20dce81f  int3
00007b0a20dce820  call 0x00007B0A20C0E120
00007b0a20dce825  jmp 0x00007B0A20DCE77C
00007b0a20dce82a  call 0x00007B0A20C0DC20
00007b0a20dce82f  jmp 0x00007B0A20DCE781
00007b0a20dce834  int3
00007b0a20dce835  nop [rax+rax*1], ax
00007b0a20dce83e  nop
00007b0a20dce840  mov rax, [r15+0x20]
00007b0a20dce844  mov r14, [r15]
00007b0a20dce847  mov [r13+rax*1], r14
00007b0a20dce84c  mov rax, [r15+0xF0]
00007b0a20dce853  mov [r15+0x100], rax
00007b0a20dce85a  jmp 0x00007B0A20DCE5C0
00007b0a20dce85f  int3
00007b0a20dce860  call 0x00007B0A20C0E120
00007b0a20dce865  jmp 0x00007B0A20DCE84C
00007b0a20dce86a  int3
00007b0a20dce86b  nop [rax+rax*1], eax
00007b0a20dce870  mov qword ptr [r15+0x100], 0x04
00007b0a20dce87b  mov esi, 0x00
00007b0a20dce880  mov edx, 0x09
00007b0a20dce885  mov rdi, 0x7FFEF8607BD0
00007b0a20dce88f  mov rax, 0x6540C66C3970
00007b0a20dce899  call rax
00007b0a20dce89b  cmp dword ptr [r15+0x318], 0x00
00007b0a20dce8a3  jnz 0x00007B0A20BFE110
00007b0a20dce8a9  jmp 0x00007B0A20BFE0A0
00007b0a20dce8ae  int3
00007b0a20dce8af  int3
