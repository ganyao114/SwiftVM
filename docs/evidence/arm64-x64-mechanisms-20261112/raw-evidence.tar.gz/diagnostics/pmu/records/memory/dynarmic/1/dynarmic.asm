00007339cfbce69b  nop [rax+rax*1], eax
00007339cfbce6a0  mov qword ptr [r15+0x20], 0x420060
00007339cfbce6a8  mov eax, 0x420060
00007339cfbce6ad  xor r14d, r14d
00007339cfbce6b0  mov [r13+rax*1], r14
00007339cfbce6b5  mov eax, 0x420060
00007339cfbce6ba  mov r14, [r13+rax*1]
00007339cfbce6bf  mov [r15+0x18], r14
00007339cfbce6c3  lea rax, [r14+0x03]
00007339cfbce6c7  mov [r15], rax
00007339cfbce6ca  xor eax, eax
00007339cfbce6cc  mov r14d, 0xB71B00
00007339cfbce6d2  mov r12d, 0x01
00007339cfbce6d8  sub r14, r12
00007339cfbce6db  cmc
00007339cfbce6dc  lahf
00007339cfbce6dd  seto al
00007339cfbce6e0  mov [r15+0x108], eax
00007339cfbce6e7  mov [r15+0x08], r14
00007339cfbce6eb  mov eax, [r15+0x108]
00007339cfbce6f2  sahf
00007339cfbce6f3  jnz 0x00007339CFBCE725
00007339cfbce6f5  cmp dword ptr [r15+0x318], 0x00
00007339cfbce6fd  jz 0x00007339CFBCE840
00007339cfbce703  nop [rax+rax*1], ax
00007339cfbce70c  nop [rax+rax*1], eax
00007339cfbce714  mov eax, 0x410050
00007339cfbce719  mov [r15+0x100], rax
00007339cfbce720  jmp 0x00007339CF9FE110
00007339cfbce725  cmp dword ptr [r15+0x318], 0x00
00007339cfbce72d  jz 0x00007339CFBCE770
00007339cfbce733  nop [rax+rax*1], ax
00007339cfbce73c  nop [rax+rax*1], eax
00007339cfbce744  mov eax, 0x41003C
00007339cfbce749  mov [r15+0x100], rax
00007339cfbce750  jmp 0x00007339CF9FE110
00007339cfbce755  int3
00007339cfbce756  call 0x00007339CFA0E120
00007339cfbce75b  jmp 0x00007339CFBCE6B5
00007339cfbce760  call 0x00007339CFA0DC20
00007339cfbce765  jmp 0x00007339CFBCE6BF
00007339cfbce76a  int3
00007339cfbce76b  nop [rax+rax*1], eax
00007339cfbce770  mov rax, [r15+0x20]
00007339cfbce774  mov r14, [r15]
00007339cfbce777  mov [r13+rax*1], r14
00007339cfbce77c  mov r14, [r13+rax*1]
00007339cfbce781  mov [r15+0x18], r14
00007339cfbce785  lea rax, [r14+0x03]
00007339cfbce789  mov [r15], rax
00007339cfbce78c  mov rax, [r15+0x08]
00007339cfbce790  mov [rsp+0x10], rax
00007339cfbce795  xor eax, eax
00007339cfbce797  mov r14, [rsp+0x10]
00007339cfbce79c  mov r12d, 0x01
00007339cfbce7a2  sub r14, r12
00007339cfbce7a5  cmc
00007339cfbce7a6  lahf
00007339cfbce7a7  seto al
00007339cfbce7aa  mov [r15+0x108], eax
00007339cfbce7b1  mov [r15+0x08], r14
00007339cfbce7b5  mov eax, [r15+0x108]
00007339cfbce7bc  sahf
00007339cfbce7bd  jnz 0x00007339CFBCE7EF
00007339cfbce7bf  cmp dword ptr [r15+0x318], 0x00
00007339cfbce7c7  jz 0x00007339CFBCE840
00007339cfbce7cd  nop [rax+rax*1], ax
00007339cfbce7d6  nop [rax+rax*1], eax
00007339cfbce7de  mov eax, 0x410050
00007339cfbce7e3  mov [r15+0x100], rax
00007339cfbce7ea  jmp 0x00007339CF9FE110
00007339cfbce7ef  cmp dword ptr [r15+0x318], 0x00
00007339cfbce7f7  jz 0x00007339CFBCE770
00007339cfbce7fd  nop [rax+rax*1], ax
00007339cfbce806  nop [rax+rax*1], eax
00007339cfbce80e  mov eax, 0x41003C
00007339cfbce813  mov [r15+0x100], rax
00007339cfbce81a  jmp 0x00007339CF9FE110
00007339cfbce81f  int3
00007339cfbce820  call 0x00007339CFA0E120
00007339cfbce825  jmp 0x00007339CFBCE77C
00007339cfbce82a  call 0x00007339CFA0DC20
00007339cfbce82f  jmp 0x00007339CFBCE781
00007339cfbce834  int3
00007339cfbce835  nop [rax+rax*1], ax
00007339cfbce83e  nop
00007339cfbce840  mov rax, [r15+0x20]
00007339cfbce844  mov r14, [r15]
00007339cfbce847  mov [r13+rax*1], r14
00007339cfbce84c  mov rax, [r15+0xF0]
00007339cfbce853  mov [r15+0x100], rax
00007339cfbce85a  jmp 0x00007339CFBCE5C0
00007339cfbce85f  int3
00007339cfbce860  call 0x00007339CFA0E120
00007339cfbce865  jmp 0x00007339CFBCE84C
00007339cfbce86a  int3
00007339cfbce86b  nop [rax+rax*1], eax
00007339cfbce870  mov qword ptr [r15+0x100], 0x04
00007339cfbce87b  mov esi, 0x00
00007339cfbce880  mov edx, 0x09
00007339cfbce885  mov rdi, 0x7FFFB42A8EA0
00007339cfbce88f  mov rax, 0x5C9518FE3970
00007339cfbce899  call rax
00007339cfbce89b  cmp dword ptr [r15+0x318], 0x00
00007339cfbce8a3  jnz 0x00007339CF9FE110
00007339cfbce8a9  jmp 0x00007339CF9FE0A0
00007339cfbce8ae  int3
00007339cfbce8af  int3
