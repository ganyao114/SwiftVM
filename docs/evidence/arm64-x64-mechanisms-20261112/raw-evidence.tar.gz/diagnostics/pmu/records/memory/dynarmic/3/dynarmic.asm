00007af1ba5ce69b  nop [rax+rax*1], eax
00007af1ba5ce6a0  mov qword ptr [r15+0x20], 0x420060
00007af1ba5ce6a8  mov eax, 0x420060
00007af1ba5ce6ad  xor r14d, r14d
00007af1ba5ce6b0  mov [r13+rax*1], r14
00007af1ba5ce6b5  mov eax, 0x420060
00007af1ba5ce6ba  mov r14, [r13+rax*1]
00007af1ba5ce6bf  mov [r15+0x18], r14
00007af1ba5ce6c3  lea rax, [r14+0x03]
00007af1ba5ce6c7  mov [r15], rax
00007af1ba5ce6ca  xor eax, eax
00007af1ba5ce6cc  mov r14d, 0xB71B00
00007af1ba5ce6d2  mov r12d, 0x01
00007af1ba5ce6d8  sub r14, r12
00007af1ba5ce6db  cmc
00007af1ba5ce6dc  lahf
00007af1ba5ce6dd  seto al
00007af1ba5ce6e0  mov [r15+0x108], eax
00007af1ba5ce6e7  mov [r15+0x08], r14
00007af1ba5ce6eb  mov eax, [r15+0x108]
00007af1ba5ce6f2  sahf
00007af1ba5ce6f3  jnz 0x00007AF1BA5CE725
00007af1ba5ce6f5  cmp dword ptr [r15+0x318], 0x00
00007af1ba5ce6fd  jz 0x00007AF1BA5CE840
00007af1ba5ce703  nop [rax+rax*1], ax
00007af1ba5ce70c  nop [rax+rax*1], eax
00007af1ba5ce714  mov eax, 0x410050
00007af1ba5ce719  mov [r15+0x100], rax
00007af1ba5ce720  jmp 0x00007AF1BA3FE110
00007af1ba5ce725  cmp dword ptr [r15+0x318], 0x00
00007af1ba5ce72d  jz 0x00007AF1BA5CE770
00007af1ba5ce733  nop [rax+rax*1], ax
00007af1ba5ce73c  nop [rax+rax*1], eax
00007af1ba5ce744  mov eax, 0x41003C
00007af1ba5ce749  mov [r15+0x100], rax
00007af1ba5ce750  jmp 0x00007AF1BA3FE110
00007af1ba5ce755  int3
00007af1ba5ce756  call 0x00007AF1BA40E120
00007af1ba5ce75b  jmp 0x00007AF1BA5CE6B5
00007af1ba5ce760  call 0x00007AF1BA40DC20
00007af1ba5ce765  jmp 0x00007AF1BA5CE6BF
00007af1ba5ce76a  int3
00007af1ba5ce76b  nop [rax+rax*1], eax
00007af1ba5ce770  mov rax, [r15+0x20]
00007af1ba5ce774  mov r14, [r15]
00007af1ba5ce777  mov [r13+rax*1], r14
00007af1ba5ce77c  mov r14, [r13+rax*1]
00007af1ba5ce781  mov [r15+0x18], r14
00007af1ba5ce785  lea rax, [r14+0x03]
00007af1ba5ce789  mov [r15], rax
00007af1ba5ce78c  mov rax, [r15+0x08]
00007af1ba5ce790  mov [rsp+0x10], rax
00007af1ba5ce795  xor eax, eax
00007af1ba5ce797  mov r14, [rsp+0x10]
00007af1ba5ce79c  mov r12d, 0x01
00007af1ba5ce7a2  sub r14, r12
00007af1ba5ce7a5  cmc
00007af1ba5ce7a6  lahf
00007af1ba5ce7a7  seto al
00007af1ba5ce7aa  mov [r15+0x108], eax
00007af1ba5ce7b1  mov [r15+0x08], r14
00007af1ba5ce7b5  mov eax, [r15+0x108]
00007af1ba5ce7bc  sahf
00007af1ba5ce7bd  jnz 0x00007AF1BA5CE7EF
00007af1ba5ce7bf  cmp dword ptr [r15+0x318], 0x00
00007af1ba5ce7c7  jz 0x00007AF1BA5CE840
00007af1ba5ce7cd  nop [rax+rax*1], ax
00007af1ba5ce7d6  nop [rax+rax*1], eax
00007af1ba5ce7de  mov eax, 0x410050
00007af1ba5ce7e3  mov [r15+0x100], rax
00007af1ba5ce7ea  jmp 0x00007AF1BA3FE110
00007af1ba5ce7ef  cmp dword ptr [r15+0x318], 0x00
00007af1ba5ce7f7  jz 0x00007AF1BA5CE770
00007af1ba5ce7fd  nop [rax+rax*1], ax
00007af1ba5ce806  nop [rax+rax*1], eax
00007af1ba5ce80e  mov eax, 0x41003C
00007af1ba5ce813  mov [r15+0x100], rax
00007af1ba5ce81a  jmp 0x00007AF1BA3FE110
00007af1ba5ce81f  int3
00007af1ba5ce820  call 0x00007AF1BA40E120
00007af1ba5ce825  jmp 0x00007AF1BA5CE77C
00007af1ba5ce82a  call 0x00007AF1BA40DC20
00007af1ba5ce82f  jmp 0x00007AF1BA5CE781
00007af1ba5ce834  int3
00007af1ba5ce835  nop [rax+rax*1], ax
00007af1ba5ce83e  nop
00007af1ba5ce840  mov rax, [r15+0x20]
00007af1ba5ce844  mov r14, [r15]
00007af1ba5ce847  mov [r13+rax*1], r14
00007af1ba5ce84c  mov rax, [r15+0xF0]
00007af1ba5ce853  mov [r15+0x100], rax
00007af1ba5ce85a  jmp 0x00007AF1BA5CE5C0
00007af1ba5ce85f  int3
00007af1ba5ce860  call 0x00007AF1BA40E120
00007af1ba5ce865  jmp 0x00007AF1BA5CE84C
00007af1ba5ce86a  int3
00007af1ba5ce86b  nop [rax+rax*1], eax
00007af1ba5ce870  mov qword ptr [r15+0x100], 0x04
00007af1ba5ce87b  mov esi, 0x00
00007af1ba5ce880  mov edx, 0x09
00007af1ba5ce885  mov rdi, 0x7FFCF8848EC0
00007af1ba5ce88f  mov rax, 0x5734C9C60970
00007af1ba5ce899  call rax
00007af1ba5ce89b  cmp dword ptr [r15+0x318], 0x00
00007af1ba5ce8a3  jnz 0x00007AF1BA3FE110
00007af1ba5ce8a9  jmp 0x00007AF1BA3FE0A0
00007af1ba5ce8ae  int3
00007af1ba5ce8af  int3
