00007ce5f5bce69b  nop [rax+rax*1], eax
00007ce5f5bce6a0  mov qword ptr [r15+0x40], 0x4201C0
00007ce5f5bce6a8  mov qword ptr [r15+0x48], 0x4203C0
00007ce5f5bce6b0  mov qword ptr [r15+0x60], 0x01
00007ce5f5bce6b8  xorps xmm1, xmm1
00007ce5f5bce6bb  mov eax, 0x41
00007ce5f5bce6c0  vcvtusi2sd xmm1, xmm1, eax
00007ce5f5bce6c6  mulsd xmm1, [0x00007CE5F57FE010]
00007ce5f5bce6ce  movq xmm1, xmm1
00007ce5f5bce6d2  movaps [r15+0x120], xmm1
00007ce5f5bce6da  mov eax, [r15+0x60]
00007ce5f5bce6de  xorps xmm15, xmm15
00007ce5f5bce6e2  vcvtusi2sd xmm15, xmm15, eax
00007ce5f5bce6e8  mulsd xmm15, [0x00007CE5F57FE020]
00007ce5f5bce6f1  movq xmm15, xmm15
00007ce5f5bce6f6  movaps [r15+0x110], xmm15
00007ce5f5bce6fe  mov rax, [r15+0x60]
00007ce5f5bce702  mov [rsp+0x10], rax
00007ce5f5bce707  xor eax, eax
00007ce5f5bce709  mov r14, [rsp+0x10]
00007ce5f5bce70e  mov r12d, 0x40
00007ce5f5bce714  cmp r14, r12
00007ce5f5bce717  cmc
00007ce5f5bce718  lahf
00007ce5f5bce719  seto al
00007ce5f5bce71c  mov [r15+0x108], eax
00007ce5f5bce723  mov qword ptr [r15+0x50], 0x40
00007ce5f5bce72b  movq rax, xmm1
00007ce5f5bce730  mov r12d, 0x4203C0
00007ce5f5bce736  mov [r13+r12*1], rax
00007ce5f5bce73b  movq rax, xmm15
00007ce5f5bce740  mov r12d, 0x4201C0
00007ce5f5bce746  mov [r13+r12*1], rax
00007ce5f5bce74b  mov [r15+0x58], r14
00007ce5f5bce74f  mov eax, [r15+0x108]
00007ce5f5bce756  sahf
00007ce5f5bce757  jnz 0x00007CE5F5BCE789
00007ce5f5bce759  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bce761  jz 0x00007CE5F5BCE910
00007ce5f5bce767  nop [rax+rax*1], ax
00007ce5f5bce770  nop [rax+rax*1], eax
00007ce5f5bce778  mov eax, 0x410074
00007ce5f5bce77d  mov [r15+0x100], rax
00007ce5f5bce784  jmp 0x00007CE5F59FE110
00007ce5f5bce789  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bce791  jz 0x00007CE5F5BCE7D0
00007ce5f5bce797  nop [rax+rax*1], ax
00007ce5f5bce7a0  nop [rax+rax*1], eax
00007ce5f5bce7a8  mov eax, 0x41004C
00007ce5f5bce7ad  mov [r15+0x100], rax
00007ce5f5bce7b4  jmp 0x00007CE5F59FE110
00007ce5f5bce7b9  int3
00007ce5f5bce7ba  call 0x00007CE5F5AB4CB0
00007ce5f5bce7bf  jmp 0x00007CE5F5BCE73B
00007ce5f5bce7c4  call 0x00007CE5F5AB4CB0
00007ce5f5bce7c9  jmp 0x00007CE5F5BCE74B
00007ce5f5bce7ce  int3
00007ce5f5bce7cf  nop
00007ce5f5bce7d0  mov rax, [r15+0x58]
00007ce5f5bce7d4  lea r14, [rax+0x01]
00007ce5f5bce7d8  mov [r15+0x60], r14
00007ce5f5bce7dc  mov r14d, [r15+0x50]
00007ce5f5bce7e0  xorps xmm1, xmm1
00007ce5f5bce7e3  vcvtusi2sd xmm1, xmm1, r14d
00007ce5f5bce7e9  mulsd xmm1, [0x00007CE5F57FE010]
00007ce5f5bce7f1  movq xmm1, xmm1
00007ce5f5bce7f5  movaps [r15+0x120], xmm1
00007ce5f5bce7fd  rorx r12, rax, 0x3D
00007ce5f5bce803  and r12, 0xFFFFFFFFFFFFFFF8
00007ce5f5bce807  mov eax, [r15+0x60]
00007ce5f5bce80b  xorps xmm15, xmm15
00007ce5f5bce80f  vcvtusi2sd xmm15, xmm15, eax
00007ce5f5bce815  mulsd xmm15, [0x00007CE5F57FE020]
00007ce5f5bce81e  movq xmm15, xmm15
00007ce5f5bce823  movaps [r15+0x110], xmm15
00007ce5f5bce82b  mov rax, [r15+0x60]
00007ce5f5bce82f  mov [rsp+0x10], rax
00007ce5f5bce834  xor eax, eax
00007ce5f5bce836  mov r11, [rsp+0x10]
00007ce5f5bce83b  mov r10d, 0x40
00007ce5f5bce841  cmp r11, r10
00007ce5f5bce844  cmc
00007ce5f5bce845  lahf
00007ce5f5bce846  seto al
00007ce5f5bce849  mov [r15+0x108], eax
00007ce5f5bce850  lea eax, [r14d-0x01]
00007ce5f5bce855  mov eax, eax
00007ce5f5bce857  mov [r15+0x50], rax
00007ce5f5bce85b  mov rax, [r15+0x48]
00007ce5f5bce85f  lea r14, [rax+r12*1]
00007ce5f5bce863  movq rax, xmm1
00007ce5f5bce868  mov [r13+r14*1], rax
00007ce5f5bce86d  mov rax, [r15+0x40]
00007ce5f5bce871  lea r14, [rax+r12*1]
00007ce5f5bce875  movq rax, xmm15
00007ce5f5bce87a  mov [r13+r14*1], rax
00007ce5f5bce87f  mov [r15+0x58], r11
00007ce5f5bce883  mov eax, [r15+0x108]
00007ce5f5bce88a  sahf
00007ce5f5bce88b  jnz 0x00007CE5F5BCE8BD
00007ce5f5bce88d  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bce895  jz 0x00007CE5F5BCE910
00007ce5f5bce89b  nop [rax+rax*1], ax
00007ce5f5bce8a4  nop [rax+rax*1], eax
00007ce5f5bce8ac  mov eax, 0x410074
00007ce5f5bce8b1  mov [r15+0x100], rax
00007ce5f5bce8b8  jmp 0x00007CE5F59FE110
00007ce5f5bce8bd  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bce8c5  jz 0x00007CE5F5BCE7D0
00007ce5f5bce8cb  nop [rax+rax*1], ax
00007ce5f5bce8d4  nop [rax+rax*1], eax
00007ce5f5bce8dc  mov eax, 0x41004C
00007ce5f5bce8e1  mov [r15+0x100], rax
00007ce5f5bce8e8  jmp 0x00007CE5F59FE110
00007ce5f5bce8ed  int3
00007ce5f5bce8ee  call 0x00007CE5F5AD5EB0
00007ce5f5bce8f3  jmp 0x00007CE5F5BCE86D
00007ce5f5bce8f8  call 0x00007CE5F5AD5EB0
00007ce5f5bce8fd  jmp 0x00007CE5F5BCE87F
00007ce5f5bce902  int3
00007ce5f5bce903  nop [rax+rax*1], ax
00007ce5f5bce90c  nop [rax], eax
00007ce5f5bce910  vxorps xmm1, xmm1, xmm1
00007ce5f5bce914  movq xmm1, xmm1
00007ce5f5bce918  movaps [r15+0x110], xmm1
00007ce5f5bce920  mov qword ptr [r15+0x58], 0x00
00007ce5f5bce928  mov qword ptr [r15+0x50], 0x4205C0
00007ce5f5bce930  mov qword ptr [r15+0x60], 0x00
00007ce5f5bce938  mov qword ptr [r15+0x68], 0x4205C0
00007ce5f5bce940  mov rax, [r15+0x40]
00007ce5f5bce944  mov r14, [r13+rax*1]
00007ce5f5bce949  lea r12, [rax+0x08]
00007ce5f5bce94d  mov r11, [r13+r12*1]
00007ce5f5bce952  movq xmm15, r14
00007ce5f5bce957  movq xmm14, r11
00007ce5f5bce95c  movq xmm15, xmm15
00007ce5f5bce961  movq xmm15, xmm15
00007ce5f5bce966  movaps [r15+0x120], xmm15
00007ce5f5bce96e  movq xmm14, xmm14
00007ce5f5bce973  movq xmm14, xmm14
00007ce5f5bce978  movaps [r15+0x130], xmm14
00007ce5f5bce980  lea r14, [rax+0x10]
00007ce5f5bce984  mov r12, [r13+r14*1]
00007ce5f5bce989  lea r14, [rax+0x18]
00007ce5f5bce98d  mov r11, [r13+r14*1]
00007ce5f5bce992  movq xmm15, r12
00007ce5f5bce997  movq xmm14, r11
00007ce5f5bce99c  movq xmm15, xmm15
00007ce5f5bce9a1  movq xmm15, xmm15
00007ce5f5bce9a6  movaps [r15+0x140], xmm15
00007ce5f5bce9ae  movq xmm14, xmm14
00007ce5f5bce9b3  movq xmm14, xmm14
00007ce5f5bce9b8  movaps [r15+0x150], xmm14
00007ce5f5bce9c0  lea r14, [rax+0x20]
00007ce5f5bce9c4  mov r12, [r13+r14*1]
00007ce5f5bce9c9  lea r14, [rax+0x28]
00007ce5f5bce9cd  mov r11, [r13+r14*1]
00007ce5f5bce9d2  movq xmm15, r12
00007ce5f5bce9d7  movq xmm14, r11
00007ce5f5bce9dc  movq xmm15, xmm15
00007ce5f5bce9e1  movq xmm15, xmm15
00007ce5f5bce9e6  movaps [r15+0x160], xmm15
00007ce5f5bce9ee  movq xmm14, xmm14
00007ce5f5bce9f3  movq xmm14, xmm14
00007ce5f5bce9f8  movaps [r15+0x170], xmm14
00007ce5f5bcea00  lea r14, [rax+0x30]
00007ce5f5bcea04  mov r12, [r13+r14*1]
00007ce5f5bcea09  lea r14, [rax+0x38]
00007ce5f5bcea0d  mov rax, [r13+r14*1]
00007ce5f5bcea12  movq xmm15, r12
00007ce5f5bcea17  movq xmm14, rax
00007ce5f5bcea1c  movq xmm15, xmm15
00007ce5f5bcea21  movq xmm15, xmm15
00007ce5f5bcea26  movaps [r15+0x180], xmm15
00007ce5f5bcea2e  movq xmm14, xmm14
00007ce5f5bcea33  movq xmm14, xmm14
00007ce5f5bcea38  movaps [r15+0x210], xmm14
00007ce5f5bcea40  mov rax, [r15+0x48]
00007ce5f5bcea44  mov [r15+0x78], rax
00007ce5f5bcea48  mov r14, [r13+rax*1]
00007ce5f5bcea4d  movq xmm15, r14
00007ce5f5bcea52  lea r14, [rax+0x40]
00007ce5f5bcea56  mov r12, [r13+r14*1]
00007ce5f5bcea5b  movq xmm14, r12
00007ce5f5bcea60  lea r14, [rax+0x80]
00007ce5f5bcea67  mov r12, [r13+r14*1]
00007ce5f5bcea6c  movq xmm13, r12
00007ce5f5bcea71  movaps xmm12, [r15+0x120]
00007ce5f5bcea79  movq r14, xmm12
00007ce5f5bcea7e  movq r12, xmm15
00007ce5f5bcea83  vmovq xmm15, r14
00007ce5f5bcea88  vmovq xmm12, r12
00007ce5f5bcea8d  movaps xmm11, xmm15
00007ce5f5bcea91  mulsd xmm11, xmm12
00007ce5f5bcea96  ucomisd xmm11, xmm11
00007ce5f5bcea9b  jp 0x00007CE5F5BCEEFC
00007ce5f5bceaa1  movq xmm11, xmm11
00007ce5f5bceaa6  movaps xmm15, [r15+0x130]
00007ce5f5bceaae  movq r14, xmm15
00007ce5f5bceab3  movq r12, xmm14
00007ce5f5bceab8  vmovq xmm15, r14
00007ce5f5bceabd  vmovq xmm14, r12
00007ce5f5bceac2  movaps xmm12, xmm15
00007ce5f5bceac6  mulsd xmm12, xmm14
00007ce5f5bceacb  ucomisd xmm12, xmm12
00007ce5f5bcead0  jp 0x00007CE5F5BCEF48
00007ce5f5bcead6  movq xmm12, xmm12
00007ce5f5bceadb  movq r14, xmm11
00007ce5f5bceae0  movq r12, xmm1
00007ce5f5bceae5  vmovq xmm1, r14
00007ce5f5bceaea  vmovq xmm15, r12
00007ce5f5bceaef  movaps xmm14, xmm1
00007ce5f5bceaf3  addsd xmm14, xmm15
00007ce5f5bceaf8  ucomisd xmm14, xmm14
00007ce5f5bceafd  jp 0x00007CE5F5BCEF94
00007ce5f5bceb03  movq xmm14, xmm14
00007ce5f5bceb08  movq r14, xmm14
00007ce5f5bceb0d  movq r12, xmm12
00007ce5f5bceb12  vmovq xmm1, r14
00007ce5f5bceb17  vmovq xmm15, r12
00007ce5f5bceb1c  movaps xmm14, xmm1
00007ce5f5bceb20  addsd xmm14, xmm15
00007ce5f5bceb25  ucomisd xmm14, xmm14
00007ce5f5bceb2a  jp 0x00007CE5F5BCEFE0
00007ce5f5bceb30  movq xmm14, xmm14
00007ce5f5bceb35  movaps xmm1, [r15+0x140]
00007ce5f5bceb3d  movq r14, xmm1
00007ce5f5bceb42  movq r12, xmm13
00007ce5f5bceb47  vmovq xmm1, r14
00007ce5f5bceb4c  vmovq xmm15, r12
00007ce5f5bceb51  movaps xmm13, xmm1
00007ce5f5bceb55  mulsd xmm13, xmm15
00007ce5f5bceb5a  ucomisd xmm13, xmm13
00007ce5f5bceb5f  jp 0x00007CE5F5BCF02C
00007ce5f5bceb65  movq xmm13, xmm13
00007ce5f5bceb6a  lea r14, [rax+0xC0]
00007ce5f5bceb71  mov r12, [r13+r14*1]
00007ce5f5bceb76  movq xmm1, r12
00007ce5f5bceb7b  movq r14, xmm14
00007ce5f5bceb80  movq r12, xmm13
00007ce5f5bceb85  vmovq xmm15, r14
00007ce5f5bceb8a  vmovq xmm14, r12
00007ce5f5bceb8f  movaps xmm13, xmm15
00007ce5f5bceb93  addsd xmm13, xmm14
00007ce5f5bceb98  ucomisd xmm13, xmm13
00007ce5f5bceb9d  jp 0x00007CE5F5BCF082
00007ce5f5bceba3  movq xmm13, xmm13
00007ce5f5bceba8  movaps xmm15, [r15+0x150]
00007ce5f5bcebb0  movq r14, xmm15
00007ce5f5bcebb5  movq r12, xmm1
00007ce5f5bcebba  vmovq xmm1, r14
00007ce5f5bcebbf  vmovq xmm15, r12
00007ce5f5bcebc4  movaps xmm14, xmm1
00007ce5f5bcebc8  mulsd xmm14, xmm15
00007ce5f5bcebcd  ucomisd xmm14, xmm14
00007ce5f5bcebd2  jp 0x00007CE5F5BCF0CE
00007ce5f5bcebd8  movq xmm14, xmm14
00007ce5f5bcebdd  lea r14, [rax+0x100]
00007ce5f5bcebe4  mov r12, [r13+r14*1]
00007ce5f5bcebe9  movq xmm1, r12
00007ce5f5bcebee  movq r14, xmm13
00007ce5f5bcebf3  movq r12, xmm14
00007ce5f5bcebf8  vmovq xmm15, r14
00007ce5f5bcebfd  vmovq xmm14, r12
00007ce5f5bcec02  movaps xmm13, xmm15
00007ce5f5bcec06  addsd xmm13, xmm14
00007ce5f5bcec0b  ucomisd xmm13, xmm13
00007ce5f5bcec10  jp 0x00007CE5F5BCF124
00007ce5f5bcec16  movq xmm13, xmm13
00007ce5f5bcec1b  movaps xmm15, [r15+0x160]
00007ce5f5bcec23  movq r14, xmm15
00007ce5f5bcec28  movq r12, xmm1
00007ce5f5bcec2d  vmovq xmm1, r14
00007ce5f5bcec32  vmovq xmm15, r12
00007ce5f5bcec37  movaps xmm14, xmm1
00007ce5f5bcec3b  mulsd xmm14, xmm15
00007ce5f5bcec40  ucomisd xmm14, xmm14
00007ce5f5bcec45  jp 0x00007CE5F5BCF170
00007ce5f5bcec4b  movq xmm14, xmm14
00007ce5f5bcec50  lea r14, [rax+0x140]
00007ce5f5bcec57  mov r12, [r13+r14*1]
00007ce5f5bcec5c  movq xmm1, r12
00007ce5f5bcec61  movq r14, xmm13
00007ce5f5bcec66  movq r12, xmm14
00007ce5f5bcec6b  vmovq xmm15, r14
00007ce5f5bcec70  vmovq xmm14, r12
00007ce5f5bcec75  movaps xmm13, xmm15
00007ce5f5bcec79  addsd xmm13, xmm14
00007ce5f5bcec7e  ucomisd xmm13, xmm13
00007ce5f5bcec83  jp 0x00007CE5F5BCF1C6
00007ce5f5bcec89  movq xmm13, xmm13
00007ce5f5bcec8e  movaps xmm15, [r15+0x170]
00007ce5f5bcec96  movq r14, xmm15
00007ce5f5bcec9b  movq r12, xmm1
00007ce5f5bceca0  vmovq xmm1, r14
00007ce5f5bceca5  vmovq xmm15, r12
00007ce5f5bcecaa  movaps xmm14, xmm1
00007ce5f5bcecae  mulsd xmm14, xmm15
00007ce5f5bcecb3  ucomisd xmm14, xmm14
00007ce5f5bcecb8  jp 0x00007CE5F5BCF212
00007ce5f5bcecbe  movq xmm14, xmm14
00007ce5f5bcecc3  lea r14, [rax+0x180]
00007ce5f5bcecca  mov r12, [r13+r14*1]
00007ce5f5bceccf  movq xmm1, r12
00007ce5f5bcecd4  movq r14, xmm13
00007ce5f5bcecd9  movq r12, xmm14
00007ce5f5bcecde  vmovq xmm15, r14
00007ce5f5bcece3  vmovq xmm14, r12
00007ce5f5bcece8  movaps xmm13, xmm15
00007ce5f5bcecec  addsd xmm13, xmm14
00007ce5f5bcecf1  ucomisd xmm13, xmm13
00007ce5f5bcecf6  jp 0x00007CE5F5BCF268
00007ce5f5bcecfc  movq xmm13, xmm13
00007ce5f5bced01  movaps xmm15, [r15+0x180]
00007ce5f5bced09  movq r14, xmm15
00007ce5f5bced0e  movq r12, xmm1
00007ce5f5bced13  vmovq xmm1, r14
00007ce5f5bced18  vmovq xmm15, r12
00007ce5f5bced1d  movaps xmm14, xmm1
00007ce5f5bced21  mulsd xmm14, xmm15
00007ce5f5bced26  ucomisd xmm14, xmm14
00007ce5f5bced2b  jp 0x00007CE5F5BCF2B4
00007ce5f5bced31  movq xmm14, xmm14
00007ce5f5bced36  lea r14, [rax+0x1C0]
00007ce5f5bced3d  mov rax, [r13+r14*1]
00007ce5f5bced42  movq xmm1, rax
00007ce5f5bced47  movaps [r15+0x240], xmm1
00007ce5f5bced4f  movq rax, xmm13
00007ce5f5bced54  movq r14, xmm14
00007ce5f5bced59  vmovq xmm15, rax
00007ce5f5bced5e  vmovq xmm14, r14
00007ce5f5bced63  movaps xmm13, xmm15
00007ce5f5bced67  addsd xmm13, xmm14
00007ce5f5bced6c  ucomisd xmm13, xmm13
00007ce5f5bced71  jp 0x00007CE5F5BCF30A
00007ce5f5bced77  movq xmm13, xmm13
00007ce5f5bced7c  movaps xmm15, [r15+0x210]
00007ce5f5bced84  movq rax, xmm15
00007ce5f5bced89  movq r14, xmm1
00007ce5f5bced8e  vmovq xmm1, rax
00007ce5f5bced93  vmovq xmm15, r14
00007ce5f5bced98  movaps xmm14, xmm1
00007ce5f5bced9c  mulsd xmm14, xmm15
00007ce5f5bceda1  ucomisd xmm14, xmm14
00007ce5f5bceda6  jp 0x00007CE5F5BCF352
00007ce5f5bcedac  movq xmm14, xmm14
00007ce5f5bcedb1  movaps [r15+0x230], xmm14
00007ce5f5bcedb9  movq rax, xmm13
00007ce5f5bcedbe  movq r14, xmm14
00007ce5f5bcedc3  vmovq xmm1, rax
00007ce5f5bcedc8  vmovq xmm15, r14
00007ce5f5bcedcd  movaps xmm14, xmm1
00007ce5f5bcedd1  addsd xmm14, xmm15
00007ce5f5bcedd6  ucomisd xmm14, xmm14
00007ce5f5bceddb  jp 0x00007CE5F5BCF39A
00007ce5f5bcede1  movq xmm14, xmm14
00007ce5f5bcede6  movaps [r15+0x220], xmm14
00007ce5f5bcedee  movq rax, xmm14
00007ce5f5bcedf3  mov r14d, 0x4205C0
00007ce5f5bcedf9  mov [r13+r14*1], rax
00007ce5f5bcedfe  mov qword ptr [r15+0x70], 0x08
00007ce5f5bcee06  xor eax, eax
00007ce5f5bcee08  mov r14d, 0x08
00007ce5f5bcee0e  mov r12d, 0x40
00007ce5f5bcee14  cmp r14, r12
00007ce5f5bcee17  cmc
00007ce5f5bcee18  lahf
00007ce5f5bcee19  seto al
00007ce5f5bcee1c  mov [r15+0x108], eax
00007ce5f5bcee23  mov eax, [r15+0x108]
00007ce5f5bcee2a  sahf
00007ce5f5bcee2b  jnz 0x00007CE5F5BCEE5D
00007ce5f5bcee2d  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bcee35  jz 0x00007CE5F5BCFD40
00007ce5f5bcee3b  nop [rax+rax*1], ax
00007ce5f5bcee44  nop [rax+rax*1], eax
00007ce5f5bcee4c  mov eax, 0x410118
00007ce5f5bcee51  mov [r15+0x100], rax
00007ce5f5bcee58  jmp 0x00007CE5F59FE110
00007ce5f5bcee5d  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bcee65  jz 0x00007CE5F5BCF3F0
00007ce5f5bcee6b  nop [rax+rax*1], ax
00007ce5f5bcee74  nop [rax+rax*1], eax
00007ce5f5bcee7c  mov eax, 0x4100A4
00007ce5f5bcee81  mov [r15+0x100], rax
00007ce5f5bcee88  jmp 0x00007CE5F59FE110
00007ce5f5bcee8d  int3
00007ce5f5bcee8e  call 0x00007CE5F5A0DC20
00007ce5f5bcee93  jmp 0x00007CE5F5BCE949
00007ce5f5bcee98  call 0x00007CE5F5AC0370
00007ce5f5bcee9d  jmp 0x00007CE5F5BCE952
00007ce5f5bceea2  call 0x00007CE5F5AE27E0
00007ce5f5bceea7  jmp 0x00007CE5F5BCE989
00007ce5f5bceeac  call 0x00007CE5F5AE1570
00007ce5f5bceeb1  jmp 0x00007CE5F5BCE992
00007ce5f5bceeb6  call 0x00007CE5F5AE27E0
00007ce5f5bceebb  jmp 0x00007CE5F5BCE9C9
00007ce5f5bceec0  call 0x00007CE5F5AE1570
00007ce5f5bceec5  jmp 0x00007CE5F5BCE9D2
00007ce5f5bceeca  call 0x00007CE5F5AE27E0
00007ce5f5bceecf  jmp 0x00007CE5F5BCEA09
00007ce5f5bceed4  call 0x00007CE5F5AD59C0
00007ce5f5bceed9  jmp 0x00007CE5F5BCEA12
00007ce5f5bceede  call 0x00007CE5F5A0DC20
00007ce5f5bceee3  jmp 0x00007CE5F5BCEA4D
00007ce5f5bceee8  call 0x00007CE5F5AE27E0
00007ce5f5bceeed  jmp 0x00007CE5F5BCEA5B
00007ce5f5bceef2  call 0x00007CE5F5AE27E0
00007ce5f5bceef7  jmp 0x00007CE5F5BCEA6C
00007ce5f5bceefc  ucomisd xmm15, xmm12
00007ce5f5bcef01  jp 0x00007CE5F5BCEF10
00007ce5f5bcef03  movaps xmm11, [0x00007CE5F57FE030]
00007ce5f5bcef0b  jmp 0x00007CE5F5BCEAA1
00007ce5f5bcef10  vxorps xmm0, xmm15, xmm12
00007ce5f5bcef15  pextrw r14d, xmm0, 0x03
00007ce5f5bcef1b  and r14d, 0x7FF8
00007ce5f5bcef22  cmp r14d, 0x08
00007ce5f5bcef26  jnz 0x00007CE5F5BCEAA1
00007ce5f5bcef2c  movq r14, xmm12
00007ce5f5bcef31  shl r14, 0x0D
00007ce5f5bcef35  jbe 0x00007CE5F5BCEAA1
00007ce5f5bcef3b  vorps xmm11, xmm12, [0x00007CE5F57FE040]
00007ce5f5bcef43  jmp 0x00007CE5F5BCEAA1
00007ce5f5bcef48  ucomisd xmm15, xmm14
00007ce5f5bcef4d  jp 0x00007CE5F5BCEF5C
00007ce5f5bcef4f  movaps xmm12, [0x00007CE5F57FE030]
00007ce5f5bcef57  jmp 0x00007CE5F5BCEAD6
00007ce5f5bcef5c  vxorps xmm0, xmm15, xmm14
00007ce5f5bcef61  pextrw r14d, xmm0, 0x03
00007ce5f5bcef67  and r14d, 0x7FF8
00007ce5f5bcef6e  cmp r14d, 0x08
00007ce5f5bcef72  jnz 0x00007CE5F5BCEAD6
00007ce5f5bcef78  movq r14, xmm14
00007ce5f5bcef7d  shl r14, 0x0D
00007ce5f5bcef81  jbe 0x00007CE5F5BCEAD6
00007ce5f5bcef87  vorps xmm12, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcef8f  jmp 0x00007CE5F5BCEAD6
00007ce5f5bcef94  ucomisd xmm1, xmm15
00007ce5f5bcef99  jp 0x00007CE5F5BCEFA8
00007ce5f5bcef9b  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcefa3  jmp 0x00007CE5F5BCEB03
00007ce5f5bcefa8  vxorps xmm0, xmm1, xmm15
00007ce5f5bcefad  pextrw r14d, xmm0, 0x03
00007ce5f5bcefb3  and r14d, 0x7FF8
00007ce5f5bcefba  cmp r14d, 0x08
00007ce5f5bcefbe  jnz 0x00007CE5F5BCEB03
00007ce5f5bcefc4  movq r14, xmm15
00007ce5f5bcefc9  shl r14, 0x0D
00007ce5f5bcefcd  jbe 0x00007CE5F5BCEB03
00007ce5f5bcefd3  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcefdb  jmp 0x00007CE5F5BCEB03
00007ce5f5bcefe0  ucomisd xmm1, xmm15
00007ce5f5bcefe5  jp 0x00007CE5F5BCEFF4
00007ce5f5bcefe7  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcefef  jmp 0x00007CE5F5BCEB30
00007ce5f5bceff4  vxorps xmm0, xmm1, xmm15
00007ce5f5bceff9  pextrw r14d, xmm0, 0x03
00007ce5f5bcefff  and r14d, 0x7FF8
00007ce5f5bcf006  cmp r14d, 0x08
00007ce5f5bcf00a  jnz 0x00007CE5F5BCEB30
00007ce5f5bcf010  movq r14, xmm15
00007ce5f5bcf015  shl r14, 0x0D
00007ce5f5bcf019  jbe 0x00007CE5F5BCEB30
00007ce5f5bcf01f  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf027  jmp 0x00007CE5F5BCEB30
00007ce5f5bcf02c  ucomisd xmm1, xmm15
00007ce5f5bcf031  jp 0x00007CE5F5BCF040
00007ce5f5bcf033  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcf03b  jmp 0x00007CE5F5BCEB65
00007ce5f5bcf040  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf045  pextrw r14d, xmm0, 0x03
00007ce5f5bcf04b  and r14d, 0x7FF8
00007ce5f5bcf052  cmp r14d, 0x08
00007ce5f5bcf056  jnz 0x00007CE5F5BCEB65
00007ce5f5bcf05c  movq r14, xmm15
00007ce5f5bcf061  shl r14, 0x0D
00007ce5f5bcf065  jbe 0x00007CE5F5BCEB65
00007ce5f5bcf06b  vorps xmm13, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf073  jmp 0x00007CE5F5BCEB65
00007ce5f5bcf078  call 0x00007CE5F5AE27E0
00007ce5f5bcf07d  jmp 0x00007CE5F5BCEB76
00007ce5f5bcf082  ucomisd xmm15, xmm14
00007ce5f5bcf087  jp 0x00007CE5F5BCF096
00007ce5f5bcf089  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcf091  jmp 0x00007CE5F5BCEBA3
00007ce5f5bcf096  vxorps xmm0, xmm15, xmm14
00007ce5f5bcf09b  pextrw r14d, xmm0, 0x03
00007ce5f5bcf0a1  and r14d, 0x7FF8
00007ce5f5bcf0a8  cmp r14d, 0x08
00007ce5f5bcf0ac  jnz 0x00007CE5F5BCEBA3
00007ce5f5bcf0b2  movq r14, xmm14
00007ce5f5bcf0b7  shl r14, 0x0D
00007ce5f5bcf0bb  jbe 0x00007CE5F5BCEBA3
00007ce5f5bcf0c1  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcf0c9  jmp 0x00007CE5F5BCEBA3
00007ce5f5bcf0ce  ucomisd xmm1, xmm15
00007ce5f5bcf0d3  jp 0x00007CE5F5BCF0E2
00007ce5f5bcf0d5  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcf0dd  jmp 0x00007CE5F5BCEBD8
00007ce5f5bcf0e2  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf0e7  pextrw r14d, xmm0, 0x03
00007ce5f5bcf0ed  and r14d, 0x7FF8
00007ce5f5bcf0f4  cmp r14d, 0x08
00007ce5f5bcf0f8  jnz 0x00007CE5F5BCEBD8
00007ce5f5bcf0fe  movq r14, xmm15
00007ce5f5bcf103  shl r14, 0x0D
00007ce5f5bcf107  jbe 0x00007CE5F5BCEBD8
00007ce5f5bcf10d  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf115  jmp 0x00007CE5F5BCEBD8
00007ce5f5bcf11a  call 0x00007CE5F5AE27E0
00007ce5f5bcf11f  jmp 0x00007CE5F5BCEBE9
00007ce5f5bcf124  ucomisd xmm15, xmm14
00007ce5f5bcf129  jp 0x00007CE5F5BCF138
00007ce5f5bcf12b  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcf133  jmp 0x00007CE5F5BCEC16
00007ce5f5bcf138  vxorps xmm0, xmm15, xmm14
00007ce5f5bcf13d  pextrw r14d, xmm0, 0x03
00007ce5f5bcf143  and r14d, 0x7FF8
00007ce5f5bcf14a  cmp r14d, 0x08
00007ce5f5bcf14e  jnz 0x00007CE5F5BCEC16
00007ce5f5bcf154  movq r14, xmm14
00007ce5f5bcf159  shl r14, 0x0D
00007ce5f5bcf15d  jbe 0x00007CE5F5BCEC16
00007ce5f5bcf163  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcf16b  jmp 0x00007CE5F5BCEC16
00007ce5f5bcf170  ucomisd xmm1, xmm15
00007ce5f5bcf175  jp 0x00007CE5F5BCF184
00007ce5f5bcf177  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcf17f  jmp 0x00007CE5F5BCEC4B
00007ce5f5bcf184  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf189  pextrw r14d, xmm0, 0x03
00007ce5f5bcf18f  and r14d, 0x7FF8
00007ce5f5bcf196  cmp r14d, 0x08
00007ce5f5bcf19a  jnz 0x00007CE5F5BCEC4B
00007ce5f5bcf1a0  movq r14, xmm15
00007ce5f5bcf1a5  shl r14, 0x0D
00007ce5f5bcf1a9  jbe 0x00007CE5F5BCEC4B
00007ce5f5bcf1af  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf1b7  jmp 0x00007CE5F5BCEC4B
00007ce5f5bcf1bc  call 0x00007CE5F5AE27E0
00007ce5f5bcf1c1  jmp 0x00007CE5F5BCEC5C
00007ce5f5bcf1c6  ucomisd xmm15, xmm14
00007ce5f5bcf1cb  jp 0x00007CE5F5BCF1DA
00007ce5f5bcf1cd  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcf1d5  jmp 0x00007CE5F5BCEC89
00007ce5f5bcf1da  vxorps xmm0, xmm15, xmm14
00007ce5f5bcf1df  pextrw r14d, xmm0, 0x03
00007ce5f5bcf1e5  and r14d, 0x7FF8
00007ce5f5bcf1ec  cmp r14d, 0x08
00007ce5f5bcf1f0  jnz 0x00007CE5F5BCEC89
00007ce5f5bcf1f6  movq r14, xmm14
00007ce5f5bcf1fb  shl r14, 0x0D
00007ce5f5bcf1ff  jbe 0x00007CE5F5BCEC89
00007ce5f5bcf205  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcf20d  jmp 0x00007CE5F5BCEC89
00007ce5f5bcf212  ucomisd xmm1, xmm15
00007ce5f5bcf217  jp 0x00007CE5F5BCF226
00007ce5f5bcf219  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcf221  jmp 0x00007CE5F5BCECBE
00007ce5f5bcf226  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf22b  pextrw r14d, xmm0, 0x03
00007ce5f5bcf231  and r14d, 0x7FF8
00007ce5f5bcf238  cmp r14d, 0x08
00007ce5f5bcf23c  jnz 0x00007CE5F5BCECBE
00007ce5f5bcf242  movq r14, xmm15
00007ce5f5bcf247  shl r14, 0x0D
00007ce5f5bcf24b  jbe 0x00007CE5F5BCECBE
00007ce5f5bcf251  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf259  jmp 0x00007CE5F5BCECBE
00007ce5f5bcf25e  call 0x00007CE5F5AE27E0
00007ce5f5bcf263  jmp 0x00007CE5F5BCECCF
00007ce5f5bcf268  ucomisd xmm15, xmm14
00007ce5f5bcf26d  jp 0x00007CE5F5BCF27C
00007ce5f5bcf26f  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcf277  jmp 0x00007CE5F5BCECFC
00007ce5f5bcf27c  vxorps xmm0, xmm15, xmm14
00007ce5f5bcf281  pextrw r14d, xmm0, 0x03
00007ce5f5bcf287  and r14d, 0x7FF8
00007ce5f5bcf28e  cmp r14d, 0x08
00007ce5f5bcf292  jnz 0x00007CE5F5BCECFC
00007ce5f5bcf298  movq r14, xmm14
00007ce5f5bcf29d  shl r14, 0x0D
00007ce5f5bcf2a1  jbe 0x00007CE5F5BCECFC
00007ce5f5bcf2a7  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcf2af  jmp 0x00007CE5F5BCECFC
00007ce5f5bcf2b4  ucomisd xmm1, xmm15
00007ce5f5bcf2b9  jp 0x00007CE5F5BCF2C8
00007ce5f5bcf2bb  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcf2c3  jmp 0x00007CE5F5BCED31
00007ce5f5bcf2c8  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf2cd  pextrw r14d, xmm0, 0x03
00007ce5f5bcf2d3  and r14d, 0x7FF8
00007ce5f5bcf2da  cmp r14d, 0x08
00007ce5f5bcf2de  jnz 0x00007CE5F5BCED31
00007ce5f5bcf2e4  movq r14, xmm15
00007ce5f5bcf2e9  shl r14, 0x0D
00007ce5f5bcf2ed  jbe 0x00007CE5F5BCED31
00007ce5f5bcf2f3  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf2fb  jmp 0x00007CE5F5BCED31
00007ce5f5bcf300  call 0x00007CE5F5AD59C0
00007ce5f5bcf305  jmp 0x00007CE5F5BCED42
00007ce5f5bcf30a  ucomisd xmm15, xmm14
00007ce5f5bcf30f  jp 0x00007CE5F5BCF31E
00007ce5f5bcf311  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcf319  jmp 0x00007CE5F5BCED77
00007ce5f5bcf31e  vxorps xmm0, xmm15, xmm14
00007ce5f5bcf323  pextrw eax, xmm0, 0x03
00007ce5f5bcf328  and eax, 0x7FF8
00007ce5f5bcf32d  cmp eax, 0x08
00007ce5f5bcf330  jnz 0x00007CE5F5BCED77
00007ce5f5bcf336  movq rax, xmm14
00007ce5f5bcf33b  shl rax, 0x0D
00007ce5f5bcf33f  jbe 0x00007CE5F5BCED77
00007ce5f5bcf345  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcf34d  jmp 0x00007CE5F5BCED77
00007ce5f5bcf352  ucomisd xmm1, xmm15
00007ce5f5bcf357  jp 0x00007CE5F5BCF366
00007ce5f5bcf359  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcf361  jmp 0x00007CE5F5BCEDAC
00007ce5f5bcf366  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf36b  pextrw eax, xmm0, 0x03
00007ce5f5bcf370  and eax, 0x7FF8
00007ce5f5bcf375  cmp eax, 0x08
00007ce5f5bcf378  jnz 0x00007CE5F5BCEDAC
00007ce5f5bcf37e  movq rax, xmm15
00007ce5f5bcf383  shl rax, 0x0D
00007ce5f5bcf387  jbe 0x00007CE5F5BCEDAC
00007ce5f5bcf38d  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf395  jmp 0x00007CE5F5BCEDAC
00007ce5f5bcf39a  ucomisd xmm1, xmm15
00007ce5f5bcf39f  jp 0x00007CE5F5BCF3AE
00007ce5f5bcf3a1  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcf3a9  jmp 0x00007CE5F5BCEDE1
00007ce5f5bcf3ae  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf3b3  pextrw eax, xmm0, 0x03
00007ce5f5bcf3b8  and eax, 0x7FF8
00007ce5f5bcf3bd  cmp eax, 0x08
00007ce5f5bcf3c0  jnz 0x00007CE5F5BCEDE1
00007ce5f5bcf3c6  movq rax, xmm15
00007ce5f5bcf3cb  shl rax, 0x0D
00007ce5f5bcf3cf  jbe 0x00007CE5F5BCEDE1
00007ce5f5bcf3d5  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf3dd  jmp 0x00007CE5F5BCEDE1
00007ce5f5bcf3e2  call 0x00007CE5F5AD5EB0
00007ce5f5bcf3e7  jmp 0x00007CE5F5BCEDFE
00007ce5f5bcf3ec  int3
00007ce5f5bcf3ed  nop [rax], eax
00007ce5f5bcf3f0  mov rax, [r15+0x48]
00007ce5f5bcf3f4  mov r14, [r15+0x70]
00007ce5f5bcf3f8  lea r12, [rax+r14*1]
00007ce5f5bcf3fc  mov [r15+0x78], r12
00007ce5f5bcf400  mov rax, [r13+r12*1]
00007ce5f5bcf405  movq xmm1, rax
00007ce5f5bcf40a  lea rax, [r12+0x40]
00007ce5f5bcf40f  mov r11, [r13+rax*1]
00007ce5f5bcf414  movq xmm15, r11
00007ce5f5bcf419  lea rax, [r12+0x80]
00007ce5f5bcf421  mov r11, [r13+rax*1]
00007ce5f5bcf426  movq xmm14, r11
00007ce5f5bcf42b  movaps xmm13, [r15+0x120]
00007ce5f5bcf433  movq rax, xmm13
00007ce5f5bcf438  movq r11, xmm1
00007ce5f5bcf43d  vmovq xmm1, rax
00007ce5f5bcf442  vmovq xmm13, r11
00007ce5f5bcf447  movaps xmm12, xmm1
00007ce5f5bcf44b  mulsd xmm12, xmm13
00007ce5f5bcf450  ucomisd xmm12, xmm12
00007ce5f5bcf455  jp 0x00007CE5F5BCF879
00007ce5f5bcf45b  movq xmm12, xmm12
00007ce5f5bcf460  movaps xmm1, [r15+0x130]
00007ce5f5bcf468  movq rax, xmm1
00007ce5f5bcf46d  movq r11, xmm15
00007ce5f5bcf472  vmovq xmm1, rax
00007ce5f5bcf477  vmovq xmm15, r11
00007ce5f5bcf47c  movaps xmm13, xmm1
00007ce5f5bcf480  mulsd xmm13, xmm15
00007ce5f5bcf485  ucomisd xmm13, xmm13
00007ce5f5bcf48a  jp 0x00007CE5F5BCF8C1
00007ce5f5bcf490  movq xmm13, xmm13
00007ce5f5bcf495  movq rax, xmm12
00007ce5f5bcf49a  movaps xmm1, [r15+0x110]
00007ce5f5bcf4a2  movq r11, xmm1
00007ce5f5bcf4a7  vmovq xmm1, rax
00007ce5f5bcf4ac  vmovq xmm15, r11
00007ce5f5bcf4b1  movaps xmm12, xmm1
00007ce5f5bcf4b5  addsd xmm12, xmm15
00007ce5f5bcf4ba  ucomisd xmm12, xmm12
00007ce5f5bcf4bf  jp 0x00007CE5F5BCF909
00007ce5f5bcf4c5  movq xmm12, xmm12
00007ce5f5bcf4ca  movq rax, xmm12
00007ce5f5bcf4cf  movq r11, xmm13
00007ce5f5bcf4d4  vmovq xmm1, rax
00007ce5f5bcf4d9  vmovq xmm15, r11
00007ce5f5bcf4de  movaps xmm13, xmm1
00007ce5f5bcf4e2  addsd xmm13, xmm15
00007ce5f5bcf4e7  ucomisd xmm13, xmm13
00007ce5f5bcf4ec  jp 0x00007CE5F5BCF951
00007ce5f5bcf4f2  movq xmm13, xmm13
00007ce5f5bcf4f7  movaps xmm1, [r15+0x140]
00007ce5f5bcf4ff  movq rax, xmm1
00007ce5f5bcf504  movq r11, xmm14
00007ce5f5bcf509  vmovq xmm1, rax
00007ce5f5bcf50e  vmovq xmm15, r11
00007ce5f5bcf513  movaps xmm14, xmm1
00007ce5f5bcf517  mulsd xmm14, xmm15
00007ce5f5bcf51c  ucomisd xmm14, xmm14
00007ce5f5bcf521  jp 0x00007CE5F5BCF999
00007ce5f5bcf527  movq xmm14, xmm14
00007ce5f5bcf52c  lea rax, [r12+0xC0]
00007ce5f5bcf534  mov r11, [r13+rax*1]
00007ce5f5bcf539  movq xmm1, r11
00007ce5f5bcf53e  movq rax, xmm13
00007ce5f5bcf543  movq r11, xmm14
00007ce5f5bcf548  vmovq xmm15, rax
00007ce5f5bcf54d  vmovq xmm14, r11
00007ce5f5bcf552  movaps xmm13, xmm15
00007ce5f5bcf556  addsd xmm13, xmm14
00007ce5f5bcf55b  ucomisd xmm13, xmm13
00007ce5f5bcf560  jp 0x00007CE5F5BCF9EB
00007ce5f5bcf566  movq xmm13, xmm13
00007ce5f5bcf56b  movaps xmm15, [r15+0x150]
00007ce5f5bcf573  movq rax, xmm15
00007ce5f5bcf578  movq r11, xmm1
00007ce5f5bcf57d  vmovq xmm1, rax
00007ce5f5bcf582  vmovq xmm15, r11
00007ce5f5bcf587  movaps xmm14, xmm1
00007ce5f5bcf58b  mulsd xmm14, xmm15
00007ce5f5bcf590  ucomisd xmm14, xmm14
00007ce5f5bcf595  jp 0x00007CE5F5BCFA33
00007ce5f5bcf59b  movq xmm14, xmm14
00007ce5f5bcf5a0  lea rax, [r12+0x100]
00007ce5f5bcf5a8  mov r11, [r13+rax*1]
00007ce5f5bcf5ad  movq xmm1, r11
00007ce5f5bcf5b2  movq rax, xmm13
00007ce5f5bcf5b7  movq r11, xmm14
00007ce5f5bcf5bc  vmovq xmm15, rax
00007ce5f5bcf5c1  vmovq xmm14, r11
00007ce5f5bcf5c6  movaps xmm13, xmm15
00007ce5f5bcf5ca  addsd xmm13, xmm14
00007ce5f5bcf5cf  ucomisd xmm13, xmm13
00007ce5f5bcf5d4  jp 0x00007CE5F5BCFA85
00007ce5f5bcf5da  movq xmm13, xmm13
00007ce5f5bcf5df  movaps xmm15, [r15+0x160]
00007ce5f5bcf5e7  movq rax, xmm15
00007ce5f5bcf5ec  movq r11, xmm1
00007ce5f5bcf5f1  vmovq xmm1, rax
00007ce5f5bcf5f6  vmovq xmm15, r11
00007ce5f5bcf5fb  movaps xmm14, xmm1
00007ce5f5bcf5ff  mulsd xmm14, xmm15
00007ce5f5bcf604  ucomisd xmm14, xmm14
00007ce5f5bcf609  jp 0x00007CE5F5BCFACD
00007ce5f5bcf60f  movq xmm14, xmm14
00007ce5f5bcf614  lea rax, [r12+0x140]
00007ce5f5bcf61c  mov r11, [r13+rax*1]
00007ce5f5bcf621  movq xmm1, r11
00007ce5f5bcf626  movq rax, xmm13
00007ce5f5bcf62b  movq r11, xmm14
00007ce5f5bcf630  vmovq xmm15, rax
00007ce5f5bcf635  vmovq xmm14, r11
00007ce5f5bcf63a  movaps xmm13, xmm15
00007ce5f5bcf63e  addsd xmm13, xmm14
00007ce5f5bcf643  ucomisd xmm13, xmm13
00007ce5f5bcf648  jp 0x00007CE5F5BCFB1F
00007ce5f5bcf64e  movq xmm13, xmm13
00007ce5f5bcf653  movaps xmm15, [r15+0x170]
00007ce5f5bcf65b  movq rax, xmm15
00007ce5f5bcf660  movq r11, xmm1
00007ce5f5bcf665  vmovq xmm1, rax
00007ce5f5bcf66a  vmovq xmm15, r11
00007ce5f5bcf66f  movaps xmm14, xmm1
00007ce5f5bcf673  mulsd xmm14, xmm15
00007ce5f5bcf678  ucomisd xmm14, xmm14
00007ce5f5bcf67d  jp 0x00007CE5F5BCFB67
00007ce5f5bcf683  movq xmm14, xmm14
00007ce5f5bcf688  lea rax, [r12+0x180]
00007ce5f5bcf690  mov r11, [r13+rax*1]
00007ce5f5bcf695  movq xmm1, r11
00007ce5f5bcf69a  movq rax, xmm13
00007ce5f5bcf69f  movq r11, xmm14
00007ce5f5bcf6a4  vmovq xmm15, rax
00007ce5f5bcf6a9  vmovq xmm14, r11
00007ce5f5bcf6ae  movaps xmm13, xmm15
00007ce5f5bcf6b2  addsd xmm13, xmm14
00007ce5f5bcf6b7  ucomisd xmm13, xmm13
00007ce5f5bcf6bc  jp 0x00007CE5F5BCFBB9
00007ce5f5bcf6c2  movq xmm13, xmm13
00007ce5f5bcf6c7  movaps xmm15, [r15+0x180]
00007ce5f5bcf6cf  movq rax, xmm15
00007ce5f5bcf6d4  movq r11, xmm1
00007ce5f5bcf6d9  vmovq xmm1, rax
00007ce5f5bcf6de  vmovq xmm15, r11
00007ce5f5bcf6e3  movaps xmm14, xmm1
00007ce5f5bcf6e7  mulsd xmm14, xmm15
00007ce5f5bcf6ec  ucomisd xmm14, xmm14
00007ce5f5bcf6f1  jp 0x00007CE5F5BCFC01
00007ce5f5bcf6f7  movq xmm14, xmm14
00007ce5f5bcf6fc  lea rax, [r12+0x1C0]
00007ce5f5bcf704  mov r12, [r13+rax*1]
00007ce5f5bcf709  movq xmm1, r12
00007ce5f5bcf70e  movaps [r15+0x240], xmm1
00007ce5f5bcf716  movq rax, xmm13
00007ce5f5bcf71b  movq r12, xmm14
00007ce5f5bcf720  vmovq xmm15, rax
00007ce5f5bcf725  vmovq xmm14, r12
00007ce5f5bcf72a  movaps xmm13, xmm15
00007ce5f5bcf72e  addsd xmm13, xmm14
00007ce5f5bcf733  ucomisd xmm13, xmm13
00007ce5f5bcf738  jp 0x00007CE5F5BCFC53
00007ce5f5bcf73e  movq xmm13, xmm13
00007ce5f5bcf743  movaps xmm15, [r15+0x210]
00007ce5f5bcf74b  movq rax, xmm15
00007ce5f5bcf750  movq r12, xmm1
00007ce5f5bcf755  vmovq xmm1, rax
00007ce5f5bcf75a  vmovq xmm15, r12
00007ce5f5bcf75f  movaps xmm14, xmm1
00007ce5f5bcf763  mulsd xmm14, xmm15
00007ce5f5bcf768  ucomisd xmm14, xmm14
00007ce5f5bcf76d  jp 0x00007CE5F5BCFC9B
00007ce5f5bcf773  movq xmm14, xmm14
00007ce5f5bcf778  movaps [r15+0x230], xmm14
00007ce5f5bcf780  movq rax, xmm13
00007ce5f5bcf785  movq r12, xmm14
00007ce5f5bcf78a  vmovq xmm1, rax
00007ce5f5bcf78f  vmovq xmm15, r12
00007ce5f5bcf794  movaps xmm14, xmm1
00007ce5f5bcf798  addsd xmm14, xmm15
00007ce5f5bcf79d  ucomisd xmm14, xmm14
00007ce5f5bcf7a2  jp 0x00007CE5F5BCFCE3
00007ce5f5bcf7a8  movq xmm14, xmm14
00007ce5f5bcf7ad  movaps [r15+0x220], xmm14
00007ce5f5bcf7b5  mov rax, [r15+0x68]
00007ce5f5bcf7b9  lea r12, [rax+r14*1]
00007ce5f5bcf7bd  movq rax, xmm14
00007ce5f5bcf7c2  mov [r13+r12*1], rax
00007ce5f5bcf7c7  lea rax, [r14+0x08]
00007ce5f5bcf7cb  mov [r15+0x70], rax
00007ce5f5bcf7cf  mov [rsp+0x10], rax
00007ce5f5bcf7d4  xor eax, eax
00007ce5f5bcf7d6  mov r14, [rsp+0x10]
00007ce5f5bcf7db  mov r12d, 0x40
00007ce5f5bcf7e1  cmp r14, r12
00007ce5f5bcf7e4  cmc
00007ce5f5bcf7e5  lahf
00007ce5f5bcf7e6  seto al
00007ce5f5bcf7e9  mov [r15+0x108], eax
00007ce5f5bcf7f0  mov eax, [r15+0x108]
00007ce5f5bcf7f7  sahf
00007ce5f5bcf7f8  jnz 0x00007CE5F5BCF82A
00007ce5f5bcf7fa  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bcf802  jz 0x00007CE5F5BCFD40
00007ce5f5bcf808  nop [rax+rax*1], ax
00007ce5f5bcf811  nop [rax+rax*1], eax
00007ce5f5bcf819  mov eax, 0x410118
00007ce5f5bcf81e  mov [r15+0x100], rax
00007ce5f5bcf825  jmp 0x00007CE5F59FE110
00007ce5f5bcf82a  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bcf832  jz 0x00007CE5F5BCF3F0
00007ce5f5bcf838  nop [rax+rax*1], ax
00007ce5f5bcf841  nop [rax+rax*1], eax
00007ce5f5bcf849  mov eax, 0x4100A4
00007ce5f5bcf84e  mov [r15+0x100], rax
00007ce5f5bcf855  jmp 0x00007CE5F59FE110
00007ce5f5bcf85a  int3
00007ce5f5bcf85b  call 0x00007CE5F5AB47C0
00007ce5f5bcf860  jmp 0x00007CE5F5BCF405
00007ce5f5bcf865  call 0x00007CE5F5A0A4B0
00007ce5f5bcf86a  jmp 0x00007CE5F5BCF414
00007ce5f5bcf86f  call 0x00007CE5F5A0A4B0
00007ce5f5bcf874  jmp 0x00007CE5F5BCF426
00007ce5f5bcf879  ucomisd xmm1, xmm13
00007ce5f5bcf87e  jp 0x00007CE5F5BCF88D
00007ce5f5bcf880  movaps xmm12, [0x00007CE5F57FE030]
00007ce5f5bcf888  jmp 0x00007CE5F5BCF45B
00007ce5f5bcf88d  vxorps xmm0, xmm1, xmm13
00007ce5f5bcf892  pextrw eax, xmm0, 0x03
00007ce5f5bcf897  and eax, 0x7FF8
00007ce5f5bcf89c  cmp eax, 0x08
00007ce5f5bcf89f  jnz 0x00007CE5F5BCF45B
00007ce5f5bcf8a5  movq rax, xmm13
00007ce5f5bcf8aa  shl rax, 0x0D
00007ce5f5bcf8ae  jbe 0x00007CE5F5BCF45B
00007ce5f5bcf8b4  vorps xmm12, xmm13, [0x00007CE5F57FE040]
00007ce5f5bcf8bc  jmp 0x00007CE5F5BCF45B
00007ce5f5bcf8c1  ucomisd xmm1, xmm15
00007ce5f5bcf8c6  jp 0x00007CE5F5BCF8D5
00007ce5f5bcf8c8  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcf8d0  jmp 0x00007CE5F5BCF490
00007ce5f5bcf8d5  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf8da  pextrw eax, xmm0, 0x03
00007ce5f5bcf8df  and eax, 0x7FF8
00007ce5f5bcf8e4  cmp eax, 0x08
00007ce5f5bcf8e7  jnz 0x00007CE5F5BCF490
00007ce5f5bcf8ed  movq rax, xmm15
00007ce5f5bcf8f2  shl rax, 0x0D
00007ce5f5bcf8f6  jbe 0x00007CE5F5BCF490
00007ce5f5bcf8fc  vorps xmm13, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf904  jmp 0x00007CE5F5BCF490
00007ce5f5bcf909  ucomisd xmm1, xmm15
00007ce5f5bcf90e  jp 0x00007CE5F5BCF91D
00007ce5f5bcf910  movaps xmm12, [0x00007CE5F57FE030]
00007ce5f5bcf918  jmp 0x00007CE5F5BCF4C5
00007ce5f5bcf91d  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf922  pextrw eax, xmm0, 0x03
00007ce5f5bcf927  and eax, 0x7FF8
00007ce5f5bcf92c  cmp eax, 0x08
00007ce5f5bcf92f  jnz 0x00007CE5F5BCF4C5
00007ce5f5bcf935  movq rax, xmm15
00007ce5f5bcf93a  shl rax, 0x0D
00007ce5f5bcf93e  jbe 0x00007CE5F5BCF4C5
00007ce5f5bcf944  vorps xmm12, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf94c  jmp 0x00007CE5F5BCF4C5
00007ce5f5bcf951  ucomisd xmm1, xmm15
00007ce5f5bcf956  jp 0x00007CE5F5BCF965
00007ce5f5bcf958  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcf960  jmp 0x00007CE5F5BCF4F2
00007ce5f5bcf965  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf96a  pextrw eax, xmm0, 0x03
00007ce5f5bcf96f  and eax, 0x7FF8
00007ce5f5bcf974  cmp eax, 0x08
00007ce5f5bcf977  jnz 0x00007CE5F5BCF4F2
00007ce5f5bcf97d  movq rax, xmm15
00007ce5f5bcf982  shl rax, 0x0D
00007ce5f5bcf986  jbe 0x00007CE5F5BCF4F2
00007ce5f5bcf98c  vorps xmm13, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf994  jmp 0x00007CE5F5BCF4F2
00007ce5f5bcf999  ucomisd xmm1, xmm15
00007ce5f5bcf99e  jp 0x00007CE5F5BCF9AD
00007ce5f5bcf9a0  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcf9a8  jmp 0x00007CE5F5BCF527
00007ce5f5bcf9ad  vxorps xmm0, xmm1, xmm15
00007ce5f5bcf9b2  pextrw eax, xmm0, 0x03
00007ce5f5bcf9b7  and eax, 0x7FF8
00007ce5f5bcf9bc  cmp eax, 0x08
00007ce5f5bcf9bf  jnz 0x00007CE5F5BCF527
00007ce5f5bcf9c5  movq rax, xmm15
00007ce5f5bcf9ca  shl rax, 0x0D
00007ce5f5bcf9ce  jbe 0x00007CE5F5BCF527
00007ce5f5bcf9d4  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcf9dc  jmp 0x00007CE5F5BCF527
00007ce5f5bcf9e1  call 0x00007CE5F5A0A4B0
00007ce5f5bcf9e6  jmp 0x00007CE5F5BCF539
00007ce5f5bcf9eb  ucomisd xmm15, xmm14
00007ce5f5bcf9f0  jp 0x00007CE5F5BCF9FF
00007ce5f5bcf9f2  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcf9fa  jmp 0x00007CE5F5BCF566
00007ce5f5bcf9ff  vxorps xmm0, xmm15, xmm14
00007ce5f5bcfa04  pextrw eax, xmm0, 0x03
00007ce5f5bcfa09  and eax, 0x7FF8
00007ce5f5bcfa0e  cmp eax, 0x08
00007ce5f5bcfa11  jnz 0x00007CE5F5BCF566
00007ce5f5bcfa17  movq rax, xmm14
00007ce5f5bcfa1c  shl rax, 0x0D
00007ce5f5bcfa20  jbe 0x00007CE5F5BCF566
00007ce5f5bcfa26  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcfa2e  jmp 0x00007CE5F5BCF566
00007ce5f5bcfa33  ucomisd xmm1, xmm15
00007ce5f5bcfa38  jp 0x00007CE5F5BCFA47
00007ce5f5bcfa3a  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcfa42  jmp 0x00007CE5F5BCF59B
00007ce5f5bcfa47  vxorps xmm0, xmm1, xmm15
00007ce5f5bcfa4c  pextrw eax, xmm0, 0x03
00007ce5f5bcfa51  and eax, 0x7FF8
00007ce5f5bcfa56  cmp eax, 0x08
00007ce5f5bcfa59  jnz 0x00007CE5F5BCF59B
00007ce5f5bcfa5f  movq rax, xmm15
00007ce5f5bcfa64  shl rax, 0x0D
00007ce5f5bcfa68  jbe 0x00007CE5F5BCF59B
00007ce5f5bcfa6e  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcfa76  jmp 0x00007CE5F5BCF59B
00007ce5f5bcfa7b  call 0x00007CE5F5A0A4B0
00007ce5f5bcfa80  jmp 0x00007CE5F5BCF5AD
00007ce5f5bcfa85  ucomisd xmm15, xmm14
00007ce5f5bcfa8a  jp 0x00007CE5F5BCFA99
00007ce5f5bcfa8c  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcfa94  jmp 0x00007CE5F5BCF5DA
00007ce5f5bcfa99  vxorps xmm0, xmm15, xmm14
00007ce5f5bcfa9e  pextrw eax, xmm0, 0x03
00007ce5f5bcfaa3  and eax, 0x7FF8
00007ce5f5bcfaa8  cmp eax, 0x08
00007ce5f5bcfaab  jnz 0x00007CE5F5BCF5DA
00007ce5f5bcfab1  movq rax, xmm14
00007ce5f5bcfab6  shl rax, 0x0D
00007ce5f5bcfaba  jbe 0x00007CE5F5BCF5DA
00007ce5f5bcfac0  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcfac8  jmp 0x00007CE5F5BCF5DA
00007ce5f5bcfacd  ucomisd xmm1, xmm15
00007ce5f5bcfad2  jp 0x00007CE5F5BCFAE1
00007ce5f5bcfad4  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcfadc  jmp 0x00007CE5F5BCF60F
00007ce5f5bcfae1  vxorps xmm0, xmm1, xmm15
00007ce5f5bcfae6  pextrw eax, xmm0, 0x03
00007ce5f5bcfaeb  and eax, 0x7FF8
00007ce5f5bcfaf0  cmp eax, 0x08
00007ce5f5bcfaf3  jnz 0x00007CE5F5BCF60F
00007ce5f5bcfaf9  movq rax, xmm15
00007ce5f5bcfafe  shl rax, 0x0D
00007ce5f5bcfb02  jbe 0x00007CE5F5BCF60F
00007ce5f5bcfb08  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcfb10  jmp 0x00007CE5F5BCF60F
00007ce5f5bcfb15  call 0x00007CE5F5A0A4B0
00007ce5f5bcfb1a  jmp 0x00007CE5F5BCF621
00007ce5f5bcfb1f  ucomisd xmm15, xmm14
00007ce5f5bcfb24  jp 0x00007CE5F5BCFB33
00007ce5f5bcfb26  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcfb2e  jmp 0x00007CE5F5BCF64E
00007ce5f5bcfb33  vxorps xmm0, xmm15, xmm14
00007ce5f5bcfb38  pextrw eax, xmm0, 0x03
00007ce5f5bcfb3d  and eax, 0x7FF8
00007ce5f5bcfb42  cmp eax, 0x08
00007ce5f5bcfb45  jnz 0x00007CE5F5BCF64E
00007ce5f5bcfb4b  movq rax, xmm14
00007ce5f5bcfb50  shl rax, 0x0D
00007ce5f5bcfb54  jbe 0x00007CE5F5BCF64E
00007ce5f5bcfb5a  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcfb62  jmp 0x00007CE5F5BCF64E
00007ce5f5bcfb67  ucomisd xmm1, xmm15
00007ce5f5bcfb6c  jp 0x00007CE5F5BCFB7B
00007ce5f5bcfb6e  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcfb76  jmp 0x00007CE5F5BCF683
00007ce5f5bcfb7b  vxorps xmm0, xmm1, xmm15
00007ce5f5bcfb80  pextrw eax, xmm0, 0x03
00007ce5f5bcfb85  and eax, 0x7FF8
00007ce5f5bcfb8a  cmp eax, 0x08
00007ce5f5bcfb8d  jnz 0x00007CE5F5BCF683
00007ce5f5bcfb93  movq rax, xmm15
00007ce5f5bcfb98  shl rax, 0x0D
00007ce5f5bcfb9c  jbe 0x00007CE5F5BCF683
00007ce5f5bcfba2  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcfbaa  jmp 0x00007CE5F5BCF683
00007ce5f5bcfbaf  call 0x00007CE5F5A0A4B0
00007ce5f5bcfbb4  jmp 0x00007CE5F5BCF695
00007ce5f5bcfbb9  ucomisd xmm15, xmm14
00007ce5f5bcfbbe  jp 0x00007CE5F5BCFBCD
00007ce5f5bcfbc0  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcfbc8  jmp 0x00007CE5F5BCF6C2
00007ce5f5bcfbcd  vxorps xmm0, xmm15, xmm14
00007ce5f5bcfbd2  pextrw eax, xmm0, 0x03
00007ce5f5bcfbd7  and eax, 0x7FF8
00007ce5f5bcfbdc  cmp eax, 0x08
00007ce5f5bcfbdf  jnz 0x00007CE5F5BCF6C2
00007ce5f5bcfbe5  movq rax, xmm14
00007ce5f5bcfbea  shl rax, 0x0D
00007ce5f5bcfbee  jbe 0x00007CE5F5BCF6C2
00007ce5f5bcfbf4  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcfbfc  jmp 0x00007CE5F5BCF6C2
00007ce5f5bcfc01  ucomisd xmm1, xmm15
00007ce5f5bcfc06  jp 0x00007CE5F5BCFC15
00007ce5f5bcfc08  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcfc10  jmp 0x00007CE5F5BCF6F7
00007ce5f5bcfc15  vxorps xmm0, xmm1, xmm15
00007ce5f5bcfc1a  pextrw eax, xmm0, 0x03
00007ce5f5bcfc1f  and eax, 0x7FF8
00007ce5f5bcfc24  cmp eax, 0x08
00007ce5f5bcfc27  jnz 0x00007CE5F5BCF6F7
00007ce5f5bcfc2d  movq rax, xmm15
00007ce5f5bcfc32  shl rax, 0x0D
00007ce5f5bcfc36  jbe 0x00007CE5F5BCF6F7
00007ce5f5bcfc3c  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcfc44  jmp 0x00007CE5F5BCF6F7
00007ce5f5bcfc49  call 0x00007CE5F5A0B720
00007ce5f5bcfc4e  jmp 0x00007CE5F5BCF709
00007ce5f5bcfc53  ucomisd xmm15, xmm14
00007ce5f5bcfc58  jp 0x00007CE5F5BCFC67
00007ce5f5bcfc5a  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bcfc62  jmp 0x00007CE5F5BCF73E
00007ce5f5bcfc67  vxorps xmm0, xmm15, xmm14
00007ce5f5bcfc6c  pextrw eax, xmm0, 0x03
00007ce5f5bcfc71  and eax, 0x7FF8
00007ce5f5bcfc76  cmp eax, 0x08
00007ce5f5bcfc79  jnz 0x00007CE5F5BCF73E
00007ce5f5bcfc7f  movq rax, xmm14
00007ce5f5bcfc84  shl rax, 0x0D
00007ce5f5bcfc88  jbe 0x00007CE5F5BCF73E
00007ce5f5bcfc8e  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bcfc96  jmp 0x00007CE5F5BCF73E
00007ce5f5bcfc9b  ucomisd xmm1, xmm15
00007ce5f5bcfca0  jp 0x00007CE5F5BCFCAF
00007ce5f5bcfca2  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcfcaa  jmp 0x00007CE5F5BCF773
00007ce5f5bcfcaf  vxorps xmm0, xmm1, xmm15
00007ce5f5bcfcb4  pextrw eax, xmm0, 0x03
00007ce5f5bcfcb9  and eax, 0x7FF8
00007ce5f5bcfcbe  cmp eax, 0x08
00007ce5f5bcfcc1  jnz 0x00007CE5F5BCF773
00007ce5f5bcfcc7  movq rax, xmm15
00007ce5f5bcfccc  shl rax, 0x0D
00007ce5f5bcfcd0  jbe 0x00007CE5F5BCF773
00007ce5f5bcfcd6  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcfcde  jmp 0x00007CE5F5BCF773
00007ce5f5bcfce3  ucomisd xmm1, xmm15
00007ce5f5bcfce8  jp 0x00007CE5F5BCFCF7
00007ce5f5bcfcea  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bcfcf2  jmp 0x00007CE5F5BCF7A8
00007ce5f5bcfcf7  vxorps xmm0, xmm1, xmm15
00007ce5f5bcfcfc  pextrw eax, xmm0, 0x03
00007ce5f5bcfd01  and eax, 0x7FF8
00007ce5f5bcfd06  cmp eax, 0x08
00007ce5f5bcfd09  jnz 0x00007CE5F5BCF7A8
00007ce5f5bcfd0f  movq rax, xmm15
00007ce5f5bcfd14  shl rax, 0x0D
00007ce5f5bcfd18  jbe 0x00007CE5F5BCF7A8
00007ce5f5bcfd1e  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bcfd26  jmp 0x00007CE5F5BCF7A8
00007ce5f5bcfd2b  call 0x00007CE5F5AB4CB0
00007ce5f5bcfd30  jmp 0x00007CE5F5BCF7C7
00007ce5f5bcfd35  int3
00007ce5f5bcfd36  nop [rax+rax*1], ax
00007ce5f5bcfd3f  nop
00007ce5f5bcfd40  mov rax, [r15+0x60]
00007ce5f5bcfd44  lea r14, [rax+0x01]
00007ce5f5bcfd48  mov [r15+0x60], r14
00007ce5f5bcfd4c  mov rax, [r15+0x68]
00007ce5f5bcfd50  lea r12, [rax+0x40]
00007ce5f5bcfd54  mov [r15+0x68], r12
00007ce5f5bcfd58  xor eax, eax
00007ce5f5bcfd5a  mov r12d, 0x08
00007ce5f5bcfd60  cmp r14, r12
00007ce5f5bcfd63  cmc
00007ce5f5bcfd64  lahf
00007ce5f5bcfd65  seto al
00007ce5f5bcfd68  mov [r15+0x108], eax
00007ce5f5bcfd6f  mov eax, [r15+0x108]
00007ce5f5bcfd76  sahf
00007ce5f5bcfd77  jnz 0x00007CE5F5BCFDA9
00007ce5f5bcfd79  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bcfd81  jz 0x00007CE5F5BD08A0
00007ce5f5bcfd87  nop [rax+rax*1], ax
00007ce5f5bcfd90  nop [rax+rax*1], eax
00007ce5f5bcfd98  mov eax, 0x410128
00007ce5f5bcfd9d  mov [r15+0x100], rax
00007ce5f5bcfda4  jmp 0x00007CE5F59FE110
00007ce5f5bcfda9  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bcfdb1  jz 0x00007CE5F5BCFDE0
00007ce5f5bcfdb7  nop [rax+rax*1], ax
00007ce5f5bcfdc0  nop [rax+rax*1], eax
00007ce5f5bcfdc8  mov eax, 0x41008C
00007ce5f5bcfdcd  mov [r15+0x100], rax
00007ce5f5bcfdd4  jmp 0x00007CE5F59FE110
00007ce5f5bcfdd9  int3
00007ce5f5bcfdda  int3
00007ce5f5bcfddb  nop [rax+rax*1], eax
00007ce5f5bcfde0  mov rax, [r15+0x40]
00007ce5f5bcfde4  mov r14, [r15+0x60]
00007ce5f5bcfde8  shl r14, 0x06
00007ce5f5bcfdec  lea r12, [rax+r14*1]
00007ce5f5bcfdf0  mov rax, [r13+r12*1]
00007ce5f5bcfdf5  lea r14, [r12+0x08]
00007ce5f5bcfdfa  mov r11, [r13+r14*1]
00007ce5f5bcfdff  movq xmm1, rax
00007ce5f5bcfe04  movq xmm15, r11
00007ce5f5bcfe09  movq xmm1, xmm1
00007ce5f5bcfe0d  movq xmm1, xmm1
00007ce5f5bcfe11  movaps [r15+0x120], xmm1
00007ce5f5bcfe19  movq xmm15, xmm15
00007ce5f5bcfe1e  movq xmm15, xmm15
00007ce5f5bcfe23  movaps [r15+0x130], xmm15
00007ce5f5bcfe2b  lea rax, [r12+0x10]
00007ce5f5bcfe30  mov r14, [r13+rax*1]
00007ce5f5bcfe35  lea rax, [r12+0x18]
00007ce5f5bcfe3a  mov r11, [r13+rax*1]
00007ce5f5bcfe3f  movq xmm1, r14
00007ce5f5bcfe44  movq xmm15, r11
00007ce5f5bcfe49  movq xmm1, xmm1
00007ce5f5bcfe4d  movq xmm1, xmm1
00007ce5f5bcfe51  movaps [r15+0x140], xmm1
00007ce5f5bcfe59  movq xmm15, xmm15
00007ce5f5bcfe5e  movq xmm15, xmm15
00007ce5f5bcfe63  movaps [r15+0x150], xmm15
00007ce5f5bcfe6b  lea rax, [r12+0x20]
00007ce5f5bcfe70  mov r14, [r13+rax*1]
00007ce5f5bcfe75  lea rax, [r12+0x28]
00007ce5f5bcfe7a  mov r11, [r13+rax*1]
00007ce5f5bcfe7f  movq xmm1, r14
00007ce5f5bcfe84  movq xmm15, r11
00007ce5f5bcfe89  movq xmm1, xmm1
00007ce5f5bcfe8d  movq xmm1, xmm1
00007ce5f5bcfe91  movaps [r15+0x160], xmm1
00007ce5f5bcfe99  movq xmm15, xmm15
00007ce5f5bcfe9e  movq xmm15, xmm15
00007ce5f5bcfea3  movaps [r15+0x170], xmm15
00007ce5f5bcfeab  lea rax, [r12+0x30]
00007ce5f5bcfeb0  mov r14, [r13+rax*1]
00007ce5f5bcfeb5  lea rax, [r12+0x38]
00007ce5f5bcfeba  mov r12, [r13+rax*1]
00007ce5f5bcfebf  movq xmm1, r14
00007ce5f5bcfec4  movq xmm15, r12
00007ce5f5bcfec9  movq xmm1, xmm1
00007ce5f5bcfecd  movq xmm1, xmm1
00007ce5f5bcfed1  movaps [r15+0x180], xmm1
00007ce5f5bcfed9  movq xmm15, xmm15
00007ce5f5bcfede  movq xmm15, xmm15
00007ce5f5bcfee3  movaps [r15+0x210], xmm15
00007ce5f5bcfeeb  mov rax, [r15+0x48]
00007ce5f5bcfeef  mov [r15+0x78], rax
00007ce5f5bcfef3  mov r14, [r13+rax*1]
00007ce5f5bcfef8  movq xmm1, r14
00007ce5f5bcfefd  lea r14, [rax+0x40]
00007ce5f5bcff01  mov r12, [r13+r14*1]
00007ce5f5bcff06  movq xmm15, r12
00007ce5f5bcff0b  lea r14, [rax+0x80]
00007ce5f5bcff12  mov r12, [r13+r14*1]
00007ce5f5bcff17  movq xmm14, r12
00007ce5f5bcff1c  movaps xmm13, [r15+0x120]
00007ce5f5bcff24  movq r14, xmm13
00007ce5f5bcff29  movq r12, xmm1
00007ce5f5bcff2e  vmovq xmm1, r14
00007ce5f5bcff33  vmovq xmm13, r12
00007ce5f5bcff38  movaps xmm12, xmm1
00007ce5f5bcff3c  mulsd xmm12, xmm13
00007ce5f5bcff41  ucomisd xmm12, xmm12
00007ce5f5bcff46  jp 0x00007CE5F5BD03AD
00007ce5f5bcff4c  movq xmm12, xmm12
00007ce5f5bcff51  movaps xmm1, [r15+0x130]
00007ce5f5bcff59  movq r14, xmm1
00007ce5f5bcff5e  movq r12, xmm15
00007ce5f5bcff63  vmovq xmm1, r14
00007ce5f5bcff68  vmovq xmm15, r12
00007ce5f5bcff6d  movaps xmm13, xmm1
00007ce5f5bcff71  mulsd xmm13, xmm15
00007ce5f5bcff76  ucomisd xmm13, xmm13
00007ce5f5bcff7b  jp 0x00007CE5F5BD03F9
00007ce5f5bcff81  movq xmm13, xmm13
00007ce5f5bcff86  movq r14, xmm12
00007ce5f5bcff8b  movaps xmm1, [r15+0x110]
00007ce5f5bcff93  movq r12, xmm1
00007ce5f5bcff98  vmovq xmm1, r14
00007ce5f5bcff9d  vmovq xmm15, r12
00007ce5f5bcffa2  movaps xmm12, xmm1
00007ce5f5bcffa6  addsd xmm12, xmm15
00007ce5f5bcffab  ucomisd xmm12, xmm12
00007ce5f5bcffb0  jp 0x00007CE5F5BD0445
00007ce5f5bcffb6  movq xmm12, xmm12
00007ce5f5bcffbb  movq r14, xmm12
00007ce5f5bcffc0  movq r12, xmm13
00007ce5f5bcffc5  vmovq xmm1, r14
00007ce5f5bcffca  vmovq xmm15, r12
00007ce5f5bcffcf  movaps xmm13, xmm1
00007ce5f5bcffd3  addsd xmm13, xmm15
00007ce5f5bcffd8  ucomisd xmm13, xmm13
00007ce5f5bcffdd  jp 0x00007CE5F5BD0491
00007ce5f5bcffe3  movq xmm13, xmm13
00007ce5f5bcffe8  movaps xmm1, [r15+0x140]
00007ce5f5bcfff0  movq r14, xmm1
00007ce5f5bcfff5  movq r12, xmm14
00007ce5f5bcfffa  vmovq xmm1, r14
00007ce5f5bcffff  vmovq xmm15, r12
00007ce5f5bd0004  movaps xmm14, xmm1
00007ce5f5bd0008  mulsd xmm14, xmm15
00007ce5f5bd000d  ucomisd xmm14, xmm14
00007ce5f5bd0012  jp 0x00007CE5F5BD04DD
00007ce5f5bd0018  movq xmm14, xmm14
00007ce5f5bd001d  lea r14, [rax+0xC0]
00007ce5f5bd0024  mov r12, [r13+r14*1]
00007ce5f5bd0029  movq xmm1, r12
00007ce5f5bd002e  movq r14, xmm13
00007ce5f5bd0033  movq r12, xmm14
00007ce5f5bd0038  vmovq xmm15, r14
00007ce5f5bd003d  vmovq xmm14, r12
00007ce5f5bd0042  movaps xmm13, xmm15
00007ce5f5bd0046  addsd xmm13, xmm14
00007ce5f5bd004b  ucomisd xmm13, xmm13
00007ce5f5bd0050  jp 0x00007CE5F5BD0533
00007ce5f5bd0056  movq xmm13, xmm13
00007ce5f5bd005b  movaps xmm15, [r15+0x150]
00007ce5f5bd0063  movq r14, xmm15
00007ce5f5bd0068  movq r12, xmm1
00007ce5f5bd006d  vmovq xmm1, r14
00007ce5f5bd0072  vmovq xmm15, r12
00007ce5f5bd0077  movaps xmm14, xmm1
00007ce5f5bd007b  mulsd xmm14, xmm15
00007ce5f5bd0080  ucomisd xmm14, xmm14
00007ce5f5bd0085  jp 0x00007CE5F5BD057F
00007ce5f5bd008b  movq xmm14, xmm14
00007ce5f5bd0090  lea r14, [rax+0x100]
00007ce5f5bd0097  mov r12, [r13+r14*1]
00007ce5f5bd009c  movq xmm1, r12
00007ce5f5bd00a1  movq r14, xmm13
00007ce5f5bd00a6  movq r12, xmm14
00007ce5f5bd00ab  vmovq xmm15, r14
00007ce5f5bd00b0  vmovq xmm14, r12
00007ce5f5bd00b5  movaps xmm13, xmm15
00007ce5f5bd00b9  addsd xmm13, xmm14
00007ce5f5bd00be  ucomisd xmm13, xmm13
00007ce5f5bd00c3  jp 0x00007CE5F5BD05D5
00007ce5f5bd00c9  movq xmm13, xmm13
00007ce5f5bd00ce  movaps xmm15, [r15+0x160]
00007ce5f5bd00d6  movq r14, xmm15
00007ce5f5bd00db  movq r12, xmm1
00007ce5f5bd00e0  vmovq xmm1, r14
00007ce5f5bd00e5  vmovq xmm15, r12
00007ce5f5bd00ea  movaps xmm14, xmm1
00007ce5f5bd00ee  mulsd xmm14, xmm15
00007ce5f5bd00f3  ucomisd xmm14, xmm14
00007ce5f5bd00f8  jp 0x00007CE5F5BD0621
00007ce5f5bd00fe  movq xmm14, xmm14
00007ce5f5bd0103  lea r14, [rax+0x140]
00007ce5f5bd010a  mov r12, [r13+r14*1]
00007ce5f5bd010f  movq xmm1, r12
00007ce5f5bd0114  movq r14, xmm13
00007ce5f5bd0119  movq r12, xmm14
00007ce5f5bd011e  vmovq xmm15, r14
00007ce5f5bd0123  vmovq xmm14, r12
00007ce5f5bd0128  movaps xmm13, xmm15
00007ce5f5bd012c  addsd xmm13, xmm14
00007ce5f5bd0131  ucomisd xmm13, xmm13
00007ce5f5bd0136  jp 0x00007CE5F5BD0677
00007ce5f5bd013c  movq xmm13, xmm13
00007ce5f5bd0141  movaps xmm15, [r15+0x170]
00007ce5f5bd0149  movq r14, xmm15
00007ce5f5bd014e  movq r12, xmm1
00007ce5f5bd0153  vmovq xmm1, r14
00007ce5f5bd0158  vmovq xmm15, r12
00007ce5f5bd015d  movaps xmm14, xmm1
00007ce5f5bd0161  mulsd xmm14, xmm15
00007ce5f5bd0166  ucomisd xmm14, xmm14
00007ce5f5bd016b  jp 0x00007CE5F5BD06C3
00007ce5f5bd0171  movq xmm14, xmm14
00007ce5f5bd0176  lea r14, [rax+0x180]
00007ce5f5bd017d  mov r12, [r13+r14*1]
00007ce5f5bd0182  movq xmm1, r12
00007ce5f5bd0187  movq r14, xmm13
00007ce5f5bd018c  movq r12, xmm14
00007ce5f5bd0191  vmovq xmm15, r14
00007ce5f5bd0196  vmovq xmm14, r12
00007ce5f5bd019b  movaps xmm13, xmm15
00007ce5f5bd019f  addsd xmm13, xmm14
00007ce5f5bd01a4  ucomisd xmm13, xmm13
00007ce5f5bd01a9  jp 0x00007CE5F5BD0719
00007ce5f5bd01af  movq xmm13, xmm13
00007ce5f5bd01b4  movaps xmm15, [r15+0x180]
00007ce5f5bd01bc  movq r14, xmm15
00007ce5f5bd01c1  movq r12, xmm1
00007ce5f5bd01c6  vmovq xmm1, r14
00007ce5f5bd01cb  vmovq xmm15, r12
00007ce5f5bd01d0  movaps xmm14, xmm1
00007ce5f5bd01d4  mulsd xmm14, xmm15
00007ce5f5bd01d9  ucomisd xmm14, xmm14
00007ce5f5bd01de  jp 0x00007CE5F5BD0765
00007ce5f5bd01e4  movq xmm14, xmm14
00007ce5f5bd01e9  lea r14, [rax+0x1C0]
00007ce5f5bd01f0  mov rax, [r13+r14*1]
00007ce5f5bd01f5  movq xmm1, rax
00007ce5f5bd01fa  movaps [r15+0x240], xmm1
00007ce5f5bd0202  movq rax, xmm13
00007ce5f5bd0207  movq r14, xmm14
00007ce5f5bd020c  vmovq xmm15, rax
00007ce5f5bd0211  vmovq xmm14, r14
00007ce5f5bd0216  movaps xmm13, xmm15
00007ce5f5bd021a  addsd xmm13, xmm14
00007ce5f5bd021f  ucomisd xmm13, xmm13
00007ce5f5bd0224  jp 0x00007CE5F5BD07BB
00007ce5f5bd022a  movq xmm13, xmm13
00007ce5f5bd022f  movaps xmm15, [r15+0x210]
00007ce5f5bd0237  movq rax, xmm15
00007ce5f5bd023c  movq r14, xmm1
00007ce5f5bd0241  vmovq xmm1, rax
00007ce5f5bd0246  vmovq xmm15, r14
00007ce5f5bd024b  movaps xmm14, xmm1
00007ce5f5bd024f  mulsd xmm14, xmm15
00007ce5f5bd0254  ucomisd xmm14, xmm14
00007ce5f5bd0259  jp 0x00007CE5F5BD0803
00007ce5f5bd025f  movq xmm14, xmm14
00007ce5f5bd0264  movaps [r15+0x230], xmm14
00007ce5f5bd026c  movq rax, xmm13
00007ce5f5bd0271  movq r14, xmm14
00007ce5f5bd0276  vmovq xmm1, rax
00007ce5f5bd027b  vmovq xmm15, r14
00007ce5f5bd0280  movaps xmm14, xmm1
00007ce5f5bd0284  addsd xmm14, xmm15
00007ce5f5bd0289  ucomisd xmm14, xmm14
00007ce5f5bd028e  jp 0x00007CE5F5BD084B
00007ce5f5bd0294  movq xmm14, xmm14
00007ce5f5bd0299  movaps [r15+0x220], xmm14
00007ce5f5bd02a1  mov rax, [r15+0x68]
00007ce5f5bd02a5  movq r14, xmm14
00007ce5f5bd02aa  mov [r13+rax*1], r14
00007ce5f5bd02af  mov qword ptr [r15+0x70], 0x08
00007ce5f5bd02b7  xor eax, eax
00007ce5f5bd02b9  mov r14d, 0x08
00007ce5f5bd02bf  mov r12d, 0x40
00007ce5f5bd02c5  cmp r14, r12
00007ce5f5bd02c8  cmc
00007ce5f5bd02c9  lahf
00007ce5f5bd02ca  seto al
00007ce5f5bd02cd  mov [r15+0x108], eax
00007ce5f5bd02d4  mov eax, [r15+0x108]
00007ce5f5bd02db  sahf
00007ce5f5bd02dc  jnz 0x00007CE5F5BD030E
00007ce5f5bd02de  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd02e6  jz 0x00007CE5F5BCFD40
00007ce5f5bd02ec  nop [rax+rax*1], ax
00007ce5f5bd02f5  nop [rax+rax*1], eax
00007ce5f5bd02fd  mov eax, 0x410118
00007ce5f5bd0302  mov [r15+0x100], rax
00007ce5f5bd0309  jmp 0x00007CE5F59FE110
00007ce5f5bd030e  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd0316  jz 0x00007CE5F5BCF3F0
00007ce5f5bd031c  nop [rax+rax*1], ax
00007ce5f5bd0325  nop [rax+rax*1], eax
00007ce5f5bd032d  mov eax, 0x4100A4
00007ce5f5bd0332  mov [r15+0x100], rax
00007ce5f5bd0339  jmp 0x00007CE5F59FE110
00007ce5f5bd033e  int3
00007ce5f5bd033f  call 0x00007CE5F5AB47C0
00007ce5f5bd0344  jmp 0x00007CE5F5BCFDF5
00007ce5f5bd0349  call 0x00007CE5F5AE1570
00007ce5f5bd034e  jmp 0x00007CE5F5BCFDFF
00007ce5f5bd0353  call 0x00007CE5F5A0DC20
00007ce5f5bd0358  jmp 0x00007CE5F5BCFE35
00007ce5f5bd035d  call 0x00007CE5F5A0A4B0
00007ce5f5bd0362  jmp 0x00007CE5F5BCFE3F
00007ce5f5bd0367  call 0x00007CE5F5A0DC20
00007ce5f5bd036c  jmp 0x00007CE5F5BCFE75
00007ce5f5bd0371  call 0x00007CE5F5A0A4B0
00007ce5f5bd0376  jmp 0x00007CE5F5BCFE7F
00007ce5f5bd037b  call 0x00007CE5F5A0DC20
00007ce5f5bd0380  jmp 0x00007CE5F5BCFEB5
00007ce5f5bd0385  call 0x00007CE5F5A0B720
00007ce5f5bd038a  jmp 0x00007CE5F5BCFEBF
00007ce5f5bd038f  call 0x00007CE5F5A0DC20
00007ce5f5bd0394  jmp 0x00007CE5F5BCFEF8
00007ce5f5bd0399  call 0x00007CE5F5AE27E0
00007ce5f5bd039e  jmp 0x00007CE5F5BCFF06
00007ce5f5bd03a3  call 0x00007CE5F5AE27E0
00007ce5f5bd03a8  jmp 0x00007CE5F5BCFF17
00007ce5f5bd03ad  ucomisd xmm1, xmm13
00007ce5f5bd03b2  jp 0x00007CE5F5BD03C1
00007ce5f5bd03b4  movaps xmm12, [0x00007CE5F57FE030]
00007ce5f5bd03bc  jmp 0x00007CE5F5BCFF4C
00007ce5f5bd03c1  vxorps xmm0, xmm1, xmm13
00007ce5f5bd03c6  pextrw r14d, xmm0, 0x03
00007ce5f5bd03cc  and r14d, 0x7FF8
00007ce5f5bd03d3  cmp r14d, 0x08
00007ce5f5bd03d7  jnz 0x00007CE5F5BCFF4C
00007ce5f5bd03dd  movq r14, xmm13
00007ce5f5bd03e2  shl r14, 0x0D
00007ce5f5bd03e6  jbe 0x00007CE5F5BCFF4C
00007ce5f5bd03ec  vorps xmm12, xmm13, [0x00007CE5F57FE040]
00007ce5f5bd03f4  jmp 0x00007CE5F5BCFF4C
00007ce5f5bd03f9  ucomisd xmm1, xmm15
00007ce5f5bd03fe  jp 0x00007CE5F5BD040D
00007ce5f5bd0400  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd0408  jmp 0x00007CE5F5BCFF81
00007ce5f5bd040d  vxorps xmm0, xmm1, xmm15
00007ce5f5bd0412  pextrw r14d, xmm0, 0x03
00007ce5f5bd0418  and r14d, 0x7FF8
00007ce5f5bd041f  cmp r14d, 0x08
00007ce5f5bd0423  jnz 0x00007CE5F5BCFF81
00007ce5f5bd0429  movq r14, xmm15
00007ce5f5bd042e  shl r14, 0x0D
00007ce5f5bd0432  jbe 0x00007CE5F5BCFF81
00007ce5f5bd0438  vorps xmm13, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd0440  jmp 0x00007CE5F5BCFF81
00007ce5f5bd0445  ucomisd xmm1, xmm15
00007ce5f5bd044a  jp 0x00007CE5F5BD0459
00007ce5f5bd044c  movaps xmm12, [0x00007CE5F57FE030]
00007ce5f5bd0454  jmp 0x00007CE5F5BCFFB6
00007ce5f5bd0459  vxorps xmm0, xmm1, xmm15
00007ce5f5bd045e  pextrw r14d, xmm0, 0x03
00007ce5f5bd0464  and r14d, 0x7FF8
00007ce5f5bd046b  cmp r14d, 0x08
00007ce5f5bd046f  jnz 0x00007CE5F5BCFFB6
00007ce5f5bd0475  movq r14, xmm15
00007ce5f5bd047a  shl r14, 0x0D
00007ce5f5bd047e  jbe 0x00007CE5F5BCFFB6
00007ce5f5bd0484  vorps xmm12, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd048c  jmp 0x00007CE5F5BCFFB6
00007ce5f5bd0491  ucomisd xmm1, xmm15
00007ce5f5bd0496  jp 0x00007CE5F5BD04A5
00007ce5f5bd0498  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd04a0  jmp 0x00007CE5F5BCFFE3
00007ce5f5bd04a5  vxorps xmm0, xmm1, xmm15
00007ce5f5bd04aa  pextrw r14d, xmm0, 0x03
00007ce5f5bd04b0  and r14d, 0x7FF8
00007ce5f5bd04b7  cmp r14d, 0x08
00007ce5f5bd04bb  jnz 0x00007CE5F5BCFFE3
00007ce5f5bd04c1  movq r14, xmm15
00007ce5f5bd04c6  shl r14, 0x0D
00007ce5f5bd04ca  jbe 0x00007CE5F5BCFFE3
00007ce5f5bd04d0  vorps xmm13, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd04d8  jmp 0x00007CE5F5BCFFE3
00007ce5f5bd04dd  ucomisd xmm1, xmm15
00007ce5f5bd04e2  jp 0x00007CE5F5BD04F1
00007ce5f5bd04e4  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd04ec  jmp 0x00007CE5F5BD0018
00007ce5f5bd04f1  vxorps xmm0, xmm1, xmm15
00007ce5f5bd04f6  pextrw r14d, xmm0, 0x03
00007ce5f5bd04fc  and r14d, 0x7FF8
00007ce5f5bd0503  cmp r14d, 0x08
00007ce5f5bd0507  jnz 0x00007CE5F5BD0018
00007ce5f5bd050d  movq r14, xmm15
00007ce5f5bd0512  shl r14, 0x0D
00007ce5f5bd0516  jbe 0x00007CE5F5BD0018
00007ce5f5bd051c  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd0524  jmp 0x00007CE5F5BD0018
00007ce5f5bd0529  call 0x00007CE5F5AE27E0
00007ce5f5bd052e  jmp 0x00007CE5F5BD0029
00007ce5f5bd0533  ucomisd xmm15, xmm14
00007ce5f5bd0538  jp 0x00007CE5F5BD0547
00007ce5f5bd053a  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd0542  jmp 0x00007CE5F5BD0056
00007ce5f5bd0547  vxorps xmm0, xmm15, xmm14
00007ce5f5bd054c  pextrw r14d, xmm0, 0x03
00007ce5f5bd0552  and r14d, 0x7FF8
00007ce5f5bd0559  cmp r14d, 0x08
00007ce5f5bd055d  jnz 0x00007CE5F5BD0056
00007ce5f5bd0563  movq r14, xmm14
00007ce5f5bd0568  shl r14, 0x0D
00007ce5f5bd056c  jbe 0x00007CE5F5BD0056
00007ce5f5bd0572  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd057a  jmp 0x00007CE5F5BD0056
00007ce5f5bd057f  ucomisd xmm1, xmm15
00007ce5f5bd0584  jp 0x00007CE5F5BD0593
00007ce5f5bd0586  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd058e  jmp 0x00007CE5F5BD008B
00007ce5f5bd0593  vxorps xmm0, xmm1, xmm15
00007ce5f5bd0598  pextrw r14d, xmm0, 0x03
00007ce5f5bd059e  and r14d, 0x7FF8
00007ce5f5bd05a5  cmp r14d, 0x08
00007ce5f5bd05a9  jnz 0x00007CE5F5BD008B
00007ce5f5bd05af  movq r14, xmm15
00007ce5f5bd05b4  shl r14, 0x0D
00007ce5f5bd05b8  jbe 0x00007CE5F5BD008B
00007ce5f5bd05be  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd05c6  jmp 0x00007CE5F5BD008B
00007ce5f5bd05cb  call 0x00007CE5F5AE27E0
00007ce5f5bd05d0  jmp 0x00007CE5F5BD009C
00007ce5f5bd05d5  ucomisd xmm15, xmm14
00007ce5f5bd05da  jp 0x00007CE5F5BD05E9
00007ce5f5bd05dc  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd05e4  jmp 0x00007CE5F5BD00C9
00007ce5f5bd05e9  vxorps xmm0, xmm15, xmm14
00007ce5f5bd05ee  pextrw r14d, xmm0, 0x03
00007ce5f5bd05f4  and r14d, 0x7FF8
00007ce5f5bd05fb  cmp r14d, 0x08
00007ce5f5bd05ff  jnz 0x00007CE5F5BD00C9
00007ce5f5bd0605  movq r14, xmm14
00007ce5f5bd060a  shl r14, 0x0D
00007ce5f5bd060e  jbe 0x00007CE5F5BD00C9
00007ce5f5bd0614  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd061c  jmp 0x00007CE5F5BD00C9
00007ce5f5bd0621  ucomisd xmm1, xmm15
00007ce5f5bd0626  jp 0x00007CE5F5BD0635
00007ce5f5bd0628  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd0630  jmp 0x00007CE5F5BD00FE
00007ce5f5bd0635  vxorps xmm0, xmm1, xmm15
00007ce5f5bd063a  pextrw r14d, xmm0, 0x03
00007ce5f5bd0640  and r14d, 0x7FF8
00007ce5f5bd0647  cmp r14d, 0x08
00007ce5f5bd064b  jnz 0x00007CE5F5BD00FE
00007ce5f5bd0651  movq r14, xmm15
00007ce5f5bd0656  shl r14, 0x0D
00007ce5f5bd065a  jbe 0x00007CE5F5BD00FE
00007ce5f5bd0660  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd0668  jmp 0x00007CE5F5BD00FE
00007ce5f5bd066d  call 0x00007CE5F5AE27E0
00007ce5f5bd0672  jmp 0x00007CE5F5BD010F
00007ce5f5bd0677  ucomisd xmm15, xmm14
00007ce5f5bd067c  jp 0x00007CE5F5BD068B
00007ce5f5bd067e  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd0686  jmp 0x00007CE5F5BD013C
00007ce5f5bd068b  vxorps xmm0, xmm15, xmm14
00007ce5f5bd0690  pextrw r14d, xmm0, 0x03
00007ce5f5bd0696  and r14d, 0x7FF8
00007ce5f5bd069d  cmp r14d, 0x08
00007ce5f5bd06a1  jnz 0x00007CE5F5BD013C
00007ce5f5bd06a7  movq r14, xmm14
00007ce5f5bd06ac  shl r14, 0x0D
00007ce5f5bd06b0  jbe 0x00007CE5F5BD013C
00007ce5f5bd06b6  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd06be  jmp 0x00007CE5F5BD013C
00007ce5f5bd06c3  ucomisd xmm1, xmm15
00007ce5f5bd06c8  jp 0x00007CE5F5BD06D7
00007ce5f5bd06ca  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd06d2  jmp 0x00007CE5F5BD0171
00007ce5f5bd06d7  vxorps xmm0, xmm1, xmm15
00007ce5f5bd06dc  pextrw r14d, xmm0, 0x03
00007ce5f5bd06e2  and r14d, 0x7FF8
00007ce5f5bd06e9  cmp r14d, 0x08
00007ce5f5bd06ed  jnz 0x00007CE5F5BD0171
00007ce5f5bd06f3  movq r14, xmm15
00007ce5f5bd06f8  shl r14, 0x0D
00007ce5f5bd06fc  jbe 0x00007CE5F5BD0171
00007ce5f5bd0702  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd070a  jmp 0x00007CE5F5BD0171
00007ce5f5bd070f  call 0x00007CE5F5AE27E0
00007ce5f5bd0714  jmp 0x00007CE5F5BD0182
00007ce5f5bd0719  ucomisd xmm15, xmm14
00007ce5f5bd071e  jp 0x00007CE5F5BD072D
00007ce5f5bd0720  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd0728  jmp 0x00007CE5F5BD01AF
00007ce5f5bd072d  vxorps xmm0, xmm15, xmm14
00007ce5f5bd0732  pextrw r14d, xmm0, 0x03
00007ce5f5bd0738  and r14d, 0x7FF8
00007ce5f5bd073f  cmp r14d, 0x08
00007ce5f5bd0743  jnz 0x00007CE5F5BD01AF
00007ce5f5bd0749  movq r14, xmm14
00007ce5f5bd074e  shl r14, 0x0D
00007ce5f5bd0752  jbe 0x00007CE5F5BD01AF
00007ce5f5bd0758  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd0760  jmp 0x00007CE5F5BD01AF
00007ce5f5bd0765  ucomisd xmm1, xmm15
00007ce5f5bd076a  jp 0x00007CE5F5BD0779
00007ce5f5bd076c  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd0774  jmp 0x00007CE5F5BD01E4
00007ce5f5bd0779  vxorps xmm0, xmm1, xmm15
00007ce5f5bd077e  pextrw r14d, xmm0, 0x03
00007ce5f5bd0784  and r14d, 0x7FF8
00007ce5f5bd078b  cmp r14d, 0x08
00007ce5f5bd078f  jnz 0x00007CE5F5BD01E4
00007ce5f5bd0795  movq r14, xmm15
00007ce5f5bd079a  shl r14, 0x0D
00007ce5f5bd079e  jbe 0x00007CE5F5BD01E4
00007ce5f5bd07a4  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd07ac  jmp 0x00007CE5F5BD01E4
00007ce5f5bd07b1  call 0x00007CE5F5AD59C0
00007ce5f5bd07b6  jmp 0x00007CE5F5BD01F5
00007ce5f5bd07bb  ucomisd xmm15, xmm14
00007ce5f5bd07c0  jp 0x00007CE5F5BD07CF
00007ce5f5bd07c2  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd07ca  jmp 0x00007CE5F5BD022A
00007ce5f5bd07cf  vxorps xmm0, xmm15, xmm14
00007ce5f5bd07d4  pextrw eax, xmm0, 0x03
00007ce5f5bd07d9  and eax, 0x7FF8
00007ce5f5bd07de  cmp eax, 0x08
00007ce5f5bd07e1  jnz 0x00007CE5F5BD022A
00007ce5f5bd07e7  movq rax, xmm14
00007ce5f5bd07ec  shl rax, 0x0D
00007ce5f5bd07f0  jbe 0x00007CE5F5BD022A
00007ce5f5bd07f6  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd07fe  jmp 0x00007CE5F5BD022A
00007ce5f5bd0803  ucomisd xmm1, xmm15
00007ce5f5bd0808  jp 0x00007CE5F5BD0817
00007ce5f5bd080a  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd0812  jmp 0x00007CE5F5BD025F
00007ce5f5bd0817  vxorps xmm0, xmm1, xmm15
00007ce5f5bd081c  pextrw eax, xmm0, 0x03
00007ce5f5bd0821  and eax, 0x7FF8
00007ce5f5bd0826  cmp eax, 0x08
00007ce5f5bd0829  jnz 0x00007CE5F5BD025F
00007ce5f5bd082f  movq rax, xmm15
00007ce5f5bd0834  shl rax, 0x0D
00007ce5f5bd0838  jbe 0x00007CE5F5BD025F
00007ce5f5bd083e  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd0846  jmp 0x00007CE5F5BD025F
00007ce5f5bd084b  ucomisd xmm1, xmm15
00007ce5f5bd0850  jp 0x00007CE5F5BD085F
00007ce5f5bd0852  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd085a  jmp 0x00007CE5F5BD0294
00007ce5f5bd085f  vxorps xmm0, xmm1, xmm15
00007ce5f5bd0864  pextrw eax, xmm0, 0x03
00007ce5f5bd0869  and eax, 0x7FF8
00007ce5f5bd086e  cmp eax, 0x08
00007ce5f5bd0871  jnz 0x00007CE5F5BD0294
00007ce5f5bd0877  movq rax, xmm15
00007ce5f5bd087c  shl rax, 0x0D
00007ce5f5bd0880  jbe 0x00007CE5F5BD0294
00007ce5f5bd0886  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd088e  jmp 0x00007CE5F5BD0294
00007ce5f5bd0893  call 0x00007CE5F5A0E120
00007ce5f5bd0898  jmp 0x00007CE5F5BD02AF
00007ce5f5bd089d  int3
00007ce5f5bd089e  nop
00007ce5f5bd08a0  mov eax, [r15+0x58]
00007ce5f5bd08a4  lea r14d, [eax+0x01]
00007ce5f5bd08a9  mov [rsp+0x10], r14d
00007ce5f5bd08ae  mov r14d, r14d
00007ce5f5bd08b1  mov [r15+0x58], r14
00007ce5f5bd08b5  xor eax, eax
00007ce5f5bd08b7  mov r14d, [rsp+0x10]
00007ce5f5bd08bc  cmp r14d, 0x1F4
00007ce5f5bd08c3  cmc
00007ce5f5bd08c4  lahf
00007ce5f5bd08c5  seto al
00007ce5f5bd08c8  mov [r15+0x108], eax
00007ce5f5bd08cf  mov eax, [r15+0x108]
00007ce5f5bd08d6  sahf
00007ce5f5bd08d7  jnz 0x00007CE5F5BD0909
00007ce5f5bd08d9  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd08e1  jz 0x00007CE5F5BD1410
00007ce5f5bd08e7  nop [rax+rax*1], ax
00007ce5f5bd08f0  nop [rax+rax*1], eax
00007ce5f5bd08f8  mov eax, 0x410134
00007ce5f5bd08fd  mov [r15+0x100], rax
00007ce5f5bd0904  jmp 0x00007CE5F59FE110
00007ce5f5bd0909  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd0911  jz 0x00007CE5F5BD0940
00007ce5f5bd0917  nop [rax+rax*1], ax
00007ce5f5bd0920  nop [rax+rax*1], eax
00007ce5f5bd0928  mov eax, 0x410084
00007ce5f5bd092d  mov [r15+0x100], rax
00007ce5f5bd0934  jmp 0x00007CE5F59FE110
00007ce5f5bd0939  int3
00007ce5f5bd093a  int3
00007ce5f5bd093b  nop [rax+rax*1], eax
00007ce5f5bd0940  mov qword ptr [r15+0x60], 0x00
00007ce5f5bd0948  mov rax, [r15+0x50]
00007ce5f5bd094c  mov [r15+0x68], rax
00007ce5f5bd0950  mov r14, [r15+0x40]
00007ce5f5bd0954  mov r12, [r13+r14*1]
00007ce5f5bd0959  lea r11, [r14+0x08]
00007ce5f5bd095d  mov r10, [r13+r11*1]
00007ce5f5bd0962  movq xmm1, r12
00007ce5f5bd0967  movq xmm15, r10
00007ce5f5bd096c  movq xmm1, xmm1
00007ce5f5bd0970  movq xmm1, xmm1
00007ce5f5bd0974  movaps [r15+0x120], xmm1
00007ce5f5bd097c  movq xmm15, xmm15
00007ce5f5bd0981  movq xmm15, xmm15
00007ce5f5bd0986  movaps [r15+0x130], xmm15
00007ce5f5bd098e  lea r12, [r14+0x10]
00007ce5f5bd0992  mov r11, [r13+r12*1]
00007ce5f5bd0997  lea r12, [r14+0x18]
00007ce5f5bd099b  mov r10, [r13+r12*1]
00007ce5f5bd09a0  movq xmm1, r11
00007ce5f5bd09a5  movq xmm15, r10
00007ce5f5bd09aa  movq xmm1, xmm1
00007ce5f5bd09ae  movq xmm1, xmm1
00007ce5f5bd09b2  movaps [r15+0x140], xmm1
00007ce5f5bd09ba  movq xmm15, xmm15
00007ce5f5bd09bf  movq xmm15, xmm15
00007ce5f5bd09c4  movaps [r15+0x150], xmm15
00007ce5f5bd09cc  lea r12, [r14+0x20]
00007ce5f5bd09d0  mov r11, [r13+r12*1]
00007ce5f5bd09d5  lea r12, [r14+0x28]
00007ce5f5bd09d9  mov r10, [r13+r12*1]
00007ce5f5bd09de  movq xmm1, r11
00007ce5f5bd09e3  movq xmm15, r10
00007ce5f5bd09e8  movq xmm1, xmm1
00007ce5f5bd09ec  movq xmm1, xmm1
00007ce5f5bd09f0  movaps [r15+0x160], xmm1
00007ce5f5bd09f8  movq xmm15, xmm15
00007ce5f5bd09fd  movq xmm15, xmm15
00007ce5f5bd0a02  movaps [r15+0x170], xmm15
00007ce5f5bd0a0a  lea r12, [r14+0x30]
00007ce5f5bd0a0e  mov r11, [r13+r12*1]
00007ce5f5bd0a13  lea r12, [r14+0x38]
00007ce5f5bd0a17  mov r14, [r13+r12*1]
00007ce5f5bd0a1c  movq xmm1, r11
00007ce5f5bd0a21  movq xmm15, r14
00007ce5f5bd0a26  movq xmm1, xmm1
00007ce5f5bd0a2a  movq xmm1, xmm1
00007ce5f5bd0a2e  movaps [r15+0x180], xmm1
00007ce5f5bd0a36  movq xmm15, xmm15
00007ce5f5bd0a3b  movq xmm15, xmm15
00007ce5f5bd0a40  movaps [r15+0x210], xmm15
00007ce5f5bd0a48  mov r14, [r15+0x48]
00007ce5f5bd0a4c  mov [r15+0x78], r14
00007ce5f5bd0a50  mov r12, [r13+r14*1]
00007ce5f5bd0a55  movq xmm1, r12
00007ce5f5bd0a5a  lea r12, [r14+0x40]
00007ce5f5bd0a5e  mov r11, [r13+r12*1]
00007ce5f5bd0a63  movq xmm15, r11
00007ce5f5bd0a68  lea r12, [r14+0x80]
00007ce5f5bd0a6f  mov r11, [r13+r12*1]
00007ce5f5bd0a74  movq xmm14, r11
00007ce5f5bd0a79  movaps xmm13, [r15+0x120]
00007ce5f5bd0a81  movq r12, xmm13
00007ce5f5bd0a86  movq r11, xmm1
00007ce5f5bd0a8b  vmovq xmm1, r12
00007ce5f5bd0a90  vmovq xmm13, r11
00007ce5f5bd0a95  movaps xmm12, xmm1
00007ce5f5bd0a99  mulsd xmm12, xmm13
00007ce5f5bd0a9e  ucomisd xmm12, xmm12
00007ce5f5bd0aa3  jp 0x00007CE5F5BD0F06
00007ce5f5bd0aa9  movq xmm12, xmm12
00007ce5f5bd0aae  movaps xmm1, [r15+0x130]
00007ce5f5bd0ab6  movq r12, xmm1
00007ce5f5bd0abb  movq r11, xmm15
00007ce5f5bd0ac0  vmovq xmm1, r12
00007ce5f5bd0ac5  vmovq xmm15, r11
00007ce5f5bd0aca  movaps xmm13, xmm1
00007ce5f5bd0ace  mulsd xmm13, xmm15
00007ce5f5bd0ad3  ucomisd xmm13, xmm13
00007ce5f5bd0ad8  jp 0x00007CE5F5BD0F52
00007ce5f5bd0ade  movq xmm13, xmm13
00007ce5f5bd0ae3  movq r12, xmm12
00007ce5f5bd0ae8  movaps xmm1, [r15+0x110]
00007ce5f5bd0af0  movq r11, xmm1
00007ce5f5bd0af5  vmovq xmm1, r12
00007ce5f5bd0afa  vmovq xmm15, r11
00007ce5f5bd0aff  movaps xmm12, xmm1
00007ce5f5bd0b03  addsd xmm12, xmm15
00007ce5f5bd0b08  ucomisd xmm12, xmm12
00007ce5f5bd0b0d  jp 0x00007CE5F5BD0F9E
00007ce5f5bd0b13  movq xmm12, xmm12
00007ce5f5bd0b18  movq r12, xmm12
00007ce5f5bd0b1d  movq r11, xmm13
00007ce5f5bd0b22  vmovq xmm1, r12
00007ce5f5bd0b27  vmovq xmm15, r11
00007ce5f5bd0b2c  movaps xmm13, xmm1
00007ce5f5bd0b30  addsd xmm13, xmm15
00007ce5f5bd0b35  ucomisd xmm13, xmm13
00007ce5f5bd0b3a  jp 0x00007CE5F5BD0FEA
00007ce5f5bd0b40  movq xmm13, xmm13
00007ce5f5bd0b45  movaps xmm1, [r15+0x140]
00007ce5f5bd0b4d  movq r12, xmm1
00007ce5f5bd0b52  movq r11, xmm14
00007ce5f5bd0b57  vmovq xmm1, r12
00007ce5f5bd0b5c  vmovq xmm15, r11
00007ce5f5bd0b61  movaps xmm14, xmm1
00007ce5f5bd0b65  mulsd xmm14, xmm15
00007ce5f5bd0b6a  ucomisd xmm14, xmm14
00007ce5f5bd0b6f  jp 0x00007CE5F5BD1036
00007ce5f5bd0b75  movq xmm14, xmm14
00007ce5f5bd0b7a  lea r12, [r14+0xC0]
00007ce5f5bd0b81  mov r11, [r13+r12*1]
00007ce5f5bd0b86  movq xmm1, r11
00007ce5f5bd0b8b  movq r12, xmm13
00007ce5f5bd0b90  movq r11, xmm14
00007ce5f5bd0b95  vmovq xmm15, r12
00007ce5f5bd0b9a  vmovq xmm14, r11
00007ce5f5bd0b9f  movaps xmm13, xmm15
00007ce5f5bd0ba3  addsd xmm13, xmm14
00007ce5f5bd0ba8  ucomisd xmm13, xmm13
00007ce5f5bd0bad  jp 0x00007CE5F5BD108C
00007ce5f5bd0bb3  movq xmm13, xmm13
00007ce5f5bd0bb8  movaps xmm15, [r15+0x150]
00007ce5f5bd0bc0  movq r12, xmm15
00007ce5f5bd0bc5  movq r11, xmm1
00007ce5f5bd0bca  vmovq xmm1, r12
00007ce5f5bd0bcf  vmovq xmm15, r11
00007ce5f5bd0bd4  movaps xmm14, xmm1
00007ce5f5bd0bd8  mulsd xmm14, xmm15
00007ce5f5bd0bdd  ucomisd xmm14, xmm14
00007ce5f5bd0be2  jp 0x00007CE5F5BD10D8
00007ce5f5bd0be8  movq xmm14, xmm14
00007ce5f5bd0bed  lea r12, [r14+0x100]
00007ce5f5bd0bf4  mov r11, [r13+r12*1]
00007ce5f5bd0bf9  movq xmm1, r11
00007ce5f5bd0bfe  movq r12, xmm13
00007ce5f5bd0c03  movq r11, xmm14
00007ce5f5bd0c08  vmovq xmm15, r12
00007ce5f5bd0c0d  vmovq xmm14, r11
00007ce5f5bd0c12  movaps xmm13, xmm15
00007ce5f5bd0c16  addsd xmm13, xmm14
00007ce5f5bd0c1b  ucomisd xmm13, xmm13
00007ce5f5bd0c20  jp 0x00007CE5F5BD112E
00007ce5f5bd0c26  movq xmm13, xmm13
00007ce5f5bd0c2b  movaps xmm15, [r15+0x160]
00007ce5f5bd0c33  movq r12, xmm15
00007ce5f5bd0c38  movq r11, xmm1
00007ce5f5bd0c3d  vmovq xmm1, r12
00007ce5f5bd0c42  vmovq xmm15, r11
00007ce5f5bd0c47  movaps xmm14, xmm1
00007ce5f5bd0c4b  mulsd xmm14, xmm15
00007ce5f5bd0c50  ucomisd xmm14, xmm14
00007ce5f5bd0c55  jp 0x00007CE5F5BD117A
00007ce5f5bd0c5b  movq xmm14, xmm14
00007ce5f5bd0c60  lea r12, [r14+0x140]
00007ce5f5bd0c67  mov r11, [r13+r12*1]
00007ce5f5bd0c6c  movq xmm1, r11
00007ce5f5bd0c71  movq r12, xmm13
00007ce5f5bd0c76  movq r11, xmm14
00007ce5f5bd0c7b  vmovq xmm15, r12
00007ce5f5bd0c80  vmovq xmm14, r11
00007ce5f5bd0c85  movaps xmm13, xmm15
00007ce5f5bd0c89  addsd xmm13, xmm14
00007ce5f5bd0c8e  ucomisd xmm13, xmm13
00007ce5f5bd0c93  jp 0x00007CE5F5BD11D0
00007ce5f5bd0c99  movq xmm13, xmm13
00007ce5f5bd0c9e  movaps xmm15, [r15+0x170]
00007ce5f5bd0ca6  movq r12, xmm15
00007ce5f5bd0cab  movq r11, xmm1
00007ce5f5bd0cb0  vmovq xmm1, r12
00007ce5f5bd0cb5  vmovq xmm15, r11
00007ce5f5bd0cba  movaps xmm14, xmm1
00007ce5f5bd0cbe  mulsd xmm14, xmm15
00007ce5f5bd0cc3  ucomisd xmm14, xmm14
00007ce5f5bd0cc8  jp 0x00007CE5F5BD121C
00007ce5f5bd0cce  movq xmm14, xmm14
00007ce5f5bd0cd3  lea r12, [r14+0x180]
00007ce5f5bd0cda  mov r11, [r13+r12*1]
00007ce5f5bd0cdf  movq xmm1, r11
00007ce5f5bd0ce4  movq r12, xmm13
00007ce5f5bd0ce9  movq r11, xmm14
00007ce5f5bd0cee  vmovq xmm15, r12
00007ce5f5bd0cf3  vmovq xmm14, r11
00007ce5f5bd0cf8  movaps xmm13, xmm15
00007ce5f5bd0cfc  addsd xmm13, xmm14
00007ce5f5bd0d01  ucomisd xmm13, xmm13
00007ce5f5bd0d06  jp 0x00007CE5F5BD1272
00007ce5f5bd0d0c  movq xmm13, xmm13
00007ce5f5bd0d11  movaps xmm15, [r15+0x180]
00007ce5f5bd0d19  movq r12, xmm15
00007ce5f5bd0d1e  movq r11, xmm1
00007ce5f5bd0d23  vmovq xmm1, r12
00007ce5f5bd0d28  vmovq xmm15, r11
00007ce5f5bd0d2d  movaps xmm14, xmm1
00007ce5f5bd0d31  mulsd xmm14, xmm15
00007ce5f5bd0d36  ucomisd xmm14, xmm14
00007ce5f5bd0d3b  jp 0x00007CE5F5BD12BE
00007ce5f5bd0d41  movq xmm14, xmm14
00007ce5f5bd0d46  lea r12, [r14+0x1C0]
00007ce5f5bd0d4d  mov r14, [r13+r12*1]
00007ce5f5bd0d52  movq xmm1, r14
00007ce5f5bd0d57  movaps [r15+0x240], xmm1
00007ce5f5bd0d5f  movq r14, xmm13
00007ce5f5bd0d64  movq r12, xmm14
00007ce5f5bd0d69  vmovq xmm15, r14
00007ce5f5bd0d6e  vmovq xmm14, r12
00007ce5f5bd0d73  movaps xmm13, xmm15
00007ce5f5bd0d77  addsd xmm13, xmm14
00007ce5f5bd0d7c  ucomisd xmm13, xmm13
00007ce5f5bd0d81  jp 0x00007CE5F5BD1314
00007ce5f5bd0d87  movq xmm13, xmm13
00007ce5f5bd0d8c  movaps xmm15, [r15+0x210]
00007ce5f5bd0d94  movq r14, xmm15
00007ce5f5bd0d99  movq r12, xmm1
00007ce5f5bd0d9e  vmovq xmm1, r14
00007ce5f5bd0da3  vmovq xmm15, r12
00007ce5f5bd0da8  movaps xmm14, xmm1
00007ce5f5bd0dac  mulsd xmm14, xmm15
00007ce5f5bd0db1  ucomisd xmm14, xmm14
00007ce5f5bd0db6  jp 0x00007CE5F5BD1360
00007ce5f5bd0dbc  movq xmm14, xmm14
00007ce5f5bd0dc1  movaps [r15+0x230], xmm14
00007ce5f5bd0dc9  movq r14, xmm13
00007ce5f5bd0dce  movq r12, xmm14
00007ce5f5bd0dd3  vmovq xmm1, r14
00007ce5f5bd0dd8  vmovq xmm15, r12
00007ce5f5bd0ddd  movaps xmm14, xmm1
00007ce5f5bd0de1  addsd xmm14, xmm15
00007ce5f5bd0de6  ucomisd xmm14, xmm14
00007ce5f5bd0deb  jp 0x00007CE5F5BD13AC
00007ce5f5bd0df1  movq xmm14, xmm14
00007ce5f5bd0df6  movaps [r15+0x220], xmm14
00007ce5f5bd0dfe  movq r14, xmm14
00007ce5f5bd0e03  mov [r13+rax*1], r14
00007ce5f5bd0e08  mov qword ptr [r15+0x70], 0x08
00007ce5f5bd0e10  xor eax, eax
00007ce5f5bd0e12  mov r14d, 0x08
00007ce5f5bd0e18  mov r12d, 0x40
00007ce5f5bd0e1e  cmp r14, r12
00007ce5f5bd0e21  cmc
00007ce5f5bd0e22  lahf
00007ce5f5bd0e23  seto al
00007ce5f5bd0e26  mov [r15+0x108], eax
00007ce5f5bd0e2d  mov eax, [r15+0x108]
00007ce5f5bd0e34  sahf
00007ce5f5bd0e35  jnz 0x00007CE5F5BD0E67
00007ce5f5bd0e37  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd0e3f  jz 0x00007CE5F5BCFD40
00007ce5f5bd0e45  nop [rax+rax*1], ax
00007ce5f5bd0e4e  nop [rax+rax*1], eax
00007ce5f5bd0e56  mov eax, 0x410118
00007ce5f5bd0e5b  mov [r15+0x100], rax
00007ce5f5bd0e62  jmp 0x00007CE5F59FE110
00007ce5f5bd0e67  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd0e6f  jz 0x00007CE5F5BCF3F0
00007ce5f5bd0e75  nop [rax+rax*1], ax
00007ce5f5bd0e7e  nop [rax+rax*1], eax
00007ce5f5bd0e86  mov eax, 0x4100A4
00007ce5f5bd0e8b  mov [r15+0x100], rax
00007ce5f5bd0e92  jmp 0x00007CE5F59FE110
00007ce5f5bd0e97  int3
00007ce5f5bd0e98  call 0x00007CE5F5AE27E0
00007ce5f5bd0e9d  jmp 0x00007CE5F5BD0959
00007ce5f5bd0ea2  call 0x00007CE5F5AAE800
00007ce5f5bd0ea7  jmp 0x00007CE5F5BD0962
00007ce5f5bd0eac  call 0x00007CE5F5AC0370
00007ce5f5bd0eb1  jmp 0x00007CE5F5BD0997
00007ce5f5bd0eb6  call 0x00007CE5F5ABF100
00007ce5f5bd0ebb  jmp 0x00007CE5F5BD09A0
00007ce5f5bd0ec0  call 0x00007CE5F5AC0370
00007ce5f5bd0ec5  jmp 0x00007CE5F5BD09D5
00007ce5f5bd0eca  call 0x00007CE5F5ABF100
00007ce5f5bd0ecf  jmp 0x00007CE5F5BD09DE
00007ce5f5bd0ed4  call 0x00007CE5F5AC0370
00007ce5f5bd0ed9  jmp 0x00007CE5F5BD0A13
00007ce5f5bd0ede  call 0x00007CE5F5AC3AE0
00007ce5f5bd0ee3  jmp 0x00007CE5F5BD0A1C
00007ce5f5bd0ee8  call 0x00007CE5F5AE27E0
00007ce5f5bd0eed  jmp 0x00007CE5F5BD0A55
00007ce5f5bd0ef2  call 0x00007CE5F5AC0370
00007ce5f5bd0ef7  jmp 0x00007CE5F5BD0A63
00007ce5f5bd0efc  call 0x00007CE5F5AC0370
00007ce5f5bd0f01  jmp 0x00007CE5F5BD0A74
00007ce5f5bd0f06  ucomisd xmm1, xmm13
00007ce5f5bd0f0b  jp 0x00007CE5F5BD0F1A
00007ce5f5bd0f0d  movaps xmm12, [0x00007CE5F57FE030]
00007ce5f5bd0f15  jmp 0x00007CE5F5BD0AA9
00007ce5f5bd0f1a  vxorps xmm0, xmm1, xmm13
00007ce5f5bd0f1f  pextrw r12d, xmm0, 0x03
00007ce5f5bd0f25  and r12d, 0x7FF8
00007ce5f5bd0f2c  cmp r12d, 0x08
00007ce5f5bd0f30  jnz 0x00007CE5F5BD0AA9
00007ce5f5bd0f36  movq r12, xmm13
00007ce5f5bd0f3b  shl r12, 0x0D
00007ce5f5bd0f3f  jbe 0x00007CE5F5BD0AA9
00007ce5f5bd0f45  vorps xmm12, xmm13, [0x00007CE5F57FE040]
00007ce5f5bd0f4d  jmp 0x00007CE5F5BD0AA9
00007ce5f5bd0f52  ucomisd xmm1, xmm15
00007ce5f5bd0f57  jp 0x00007CE5F5BD0F66
00007ce5f5bd0f59  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd0f61  jmp 0x00007CE5F5BD0ADE
00007ce5f5bd0f66  vxorps xmm0, xmm1, xmm15
00007ce5f5bd0f6b  pextrw r12d, xmm0, 0x03
00007ce5f5bd0f71  and r12d, 0x7FF8
00007ce5f5bd0f78  cmp r12d, 0x08
00007ce5f5bd0f7c  jnz 0x00007CE5F5BD0ADE
00007ce5f5bd0f82  movq r12, xmm15
00007ce5f5bd0f87  shl r12, 0x0D
00007ce5f5bd0f8b  jbe 0x00007CE5F5BD0ADE
00007ce5f5bd0f91  vorps xmm13, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd0f99  jmp 0x00007CE5F5BD0ADE
00007ce5f5bd0f9e  ucomisd xmm1, xmm15
00007ce5f5bd0fa3  jp 0x00007CE5F5BD0FB2
00007ce5f5bd0fa5  movaps xmm12, [0x00007CE5F57FE030]
00007ce5f5bd0fad  jmp 0x00007CE5F5BD0B13
00007ce5f5bd0fb2  vxorps xmm0, xmm1, xmm15
00007ce5f5bd0fb7  pextrw r12d, xmm0, 0x03
00007ce5f5bd0fbd  and r12d, 0x7FF8
00007ce5f5bd0fc4  cmp r12d, 0x08
00007ce5f5bd0fc8  jnz 0x00007CE5F5BD0B13
00007ce5f5bd0fce  movq r12, xmm15
00007ce5f5bd0fd3  shl r12, 0x0D
00007ce5f5bd0fd7  jbe 0x00007CE5F5BD0B13
00007ce5f5bd0fdd  vorps xmm12, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd0fe5  jmp 0x00007CE5F5BD0B13
00007ce5f5bd0fea  ucomisd xmm1, xmm15
00007ce5f5bd0fef  jp 0x00007CE5F5BD0FFE
00007ce5f5bd0ff1  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd0ff9  jmp 0x00007CE5F5BD0B40
00007ce5f5bd0ffe  vxorps xmm0, xmm1, xmm15
00007ce5f5bd1003  pextrw r12d, xmm0, 0x03
00007ce5f5bd1009  and r12d, 0x7FF8
00007ce5f5bd1010  cmp r12d, 0x08
00007ce5f5bd1014  jnz 0x00007CE5F5BD0B40
00007ce5f5bd101a  movq r12, xmm15
00007ce5f5bd101f  shl r12, 0x0D
00007ce5f5bd1023  jbe 0x00007CE5F5BD0B40
00007ce5f5bd1029  vorps xmm13, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd1031  jmp 0x00007CE5F5BD0B40
00007ce5f5bd1036  ucomisd xmm1, xmm15
00007ce5f5bd103b  jp 0x00007CE5F5BD104A
00007ce5f5bd103d  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd1045  jmp 0x00007CE5F5BD0B75
00007ce5f5bd104a  vxorps xmm0, xmm1, xmm15
00007ce5f5bd104f  pextrw r12d, xmm0, 0x03
00007ce5f5bd1055  and r12d, 0x7FF8
00007ce5f5bd105c  cmp r12d, 0x08
00007ce5f5bd1060  jnz 0x00007CE5F5BD0B75
00007ce5f5bd1066  movq r12, xmm15
00007ce5f5bd106b  shl r12, 0x0D
00007ce5f5bd106f  jbe 0x00007CE5F5BD0B75
00007ce5f5bd1075  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd107d  jmp 0x00007CE5F5BD0B75
00007ce5f5bd1082  call 0x00007CE5F5AC0370
00007ce5f5bd1087  jmp 0x00007CE5F5BD0B86
00007ce5f5bd108c  ucomisd xmm15, xmm14
00007ce5f5bd1091  jp 0x00007CE5F5BD10A0
00007ce5f5bd1093  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd109b  jmp 0x00007CE5F5BD0BB3
00007ce5f5bd10a0  vxorps xmm0, xmm15, xmm14
00007ce5f5bd10a5  pextrw r12d, xmm0, 0x03
00007ce5f5bd10ab  and r12d, 0x7FF8
00007ce5f5bd10b2  cmp r12d, 0x08
00007ce5f5bd10b6  jnz 0x00007CE5F5BD0BB3
00007ce5f5bd10bc  movq r12, xmm14
00007ce5f5bd10c1  shl r12, 0x0D
00007ce5f5bd10c5  jbe 0x00007CE5F5BD0BB3
00007ce5f5bd10cb  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd10d3  jmp 0x00007CE5F5BD0BB3
00007ce5f5bd10d8  ucomisd xmm1, xmm15
00007ce5f5bd10dd  jp 0x00007CE5F5BD10EC
00007ce5f5bd10df  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd10e7  jmp 0x00007CE5F5BD0BE8
00007ce5f5bd10ec  vxorps xmm0, xmm1, xmm15
00007ce5f5bd10f1  pextrw r12d, xmm0, 0x03
00007ce5f5bd10f7  and r12d, 0x7FF8
00007ce5f5bd10fe  cmp r12d, 0x08
00007ce5f5bd1102  jnz 0x00007CE5F5BD0BE8
00007ce5f5bd1108  movq r12, xmm15
00007ce5f5bd110d  shl r12, 0x0D
00007ce5f5bd1111  jbe 0x00007CE5F5BD0BE8
00007ce5f5bd1117  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd111f  jmp 0x00007CE5F5BD0BE8
00007ce5f5bd1124  call 0x00007CE5F5AC0370
00007ce5f5bd1129  jmp 0x00007CE5F5BD0BF9
00007ce5f5bd112e  ucomisd xmm15, xmm14
00007ce5f5bd1133  jp 0x00007CE5F5BD1142
00007ce5f5bd1135  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd113d  jmp 0x00007CE5F5BD0C26
00007ce5f5bd1142  vxorps xmm0, xmm15, xmm14
00007ce5f5bd1147  pextrw r12d, xmm0, 0x03
00007ce5f5bd114d  and r12d, 0x7FF8
00007ce5f5bd1154  cmp r12d, 0x08
00007ce5f5bd1158  jnz 0x00007CE5F5BD0C26
00007ce5f5bd115e  movq r12, xmm14
00007ce5f5bd1163  shl r12, 0x0D
00007ce5f5bd1167  jbe 0x00007CE5F5BD0C26
00007ce5f5bd116d  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd1175  jmp 0x00007CE5F5BD0C26
00007ce5f5bd117a  ucomisd xmm1, xmm15
00007ce5f5bd117f  jp 0x00007CE5F5BD118E
00007ce5f5bd1181  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd1189  jmp 0x00007CE5F5BD0C5B
00007ce5f5bd118e  vxorps xmm0, xmm1, xmm15
00007ce5f5bd1193  pextrw r12d, xmm0, 0x03
00007ce5f5bd1199  and r12d, 0x7FF8
00007ce5f5bd11a0  cmp r12d, 0x08
00007ce5f5bd11a4  jnz 0x00007CE5F5BD0C5B
00007ce5f5bd11aa  movq r12, xmm15
00007ce5f5bd11af  shl r12, 0x0D
00007ce5f5bd11b3  jbe 0x00007CE5F5BD0C5B
00007ce5f5bd11b9  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd11c1  jmp 0x00007CE5F5BD0C5B
00007ce5f5bd11c6  call 0x00007CE5F5AC0370
00007ce5f5bd11cb  jmp 0x00007CE5F5BD0C6C
00007ce5f5bd11d0  ucomisd xmm15, xmm14
00007ce5f5bd11d5  jp 0x00007CE5F5BD11E4
00007ce5f5bd11d7  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd11df  jmp 0x00007CE5F5BD0C99
00007ce5f5bd11e4  vxorps xmm0, xmm15, xmm14
00007ce5f5bd11e9  pextrw r12d, xmm0, 0x03
00007ce5f5bd11ef  and r12d, 0x7FF8
00007ce5f5bd11f6  cmp r12d, 0x08
00007ce5f5bd11fa  jnz 0x00007CE5F5BD0C99
00007ce5f5bd1200  movq r12, xmm14
00007ce5f5bd1205  shl r12, 0x0D
00007ce5f5bd1209  jbe 0x00007CE5F5BD0C99
00007ce5f5bd120f  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd1217  jmp 0x00007CE5F5BD0C99
00007ce5f5bd121c  ucomisd xmm1, xmm15
00007ce5f5bd1221  jp 0x00007CE5F5BD1230
00007ce5f5bd1223  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd122b  jmp 0x00007CE5F5BD0CCE
00007ce5f5bd1230  vxorps xmm0, xmm1, xmm15
00007ce5f5bd1235  pextrw r12d, xmm0, 0x03
00007ce5f5bd123b  and r12d, 0x7FF8
00007ce5f5bd1242  cmp r12d, 0x08
00007ce5f5bd1246  jnz 0x00007CE5F5BD0CCE
00007ce5f5bd124c  movq r12, xmm15
00007ce5f5bd1251  shl r12, 0x0D
00007ce5f5bd1255  jbe 0x00007CE5F5BD0CCE
00007ce5f5bd125b  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd1263  jmp 0x00007CE5F5BD0CCE
00007ce5f5bd1268  call 0x00007CE5F5AC0370
00007ce5f5bd126d  jmp 0x00007CE5F5BD0CDF
00007ce5f5bd1272  ucomisd xmm15, xmm14
00007ce5f5bd1277  jp 0x00007CE5F5BD1286
00007ce5f5bd1279  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd1281  jmp 0x00007CE5F5BD0D0C
00007ce5f5bd1286  vxorps xmm0, xmm15, xmm14
00007ce5f5bd128b  pextrw r12d, xmm0, 0x03
00007ce5f5bd1291  and r12d, 0x7FF8
00007ce5f5bd1298  cmp r12d, 0x08
00007ce5f5bd129c  jnz 0x00007CE5F5BD0D0C
00007ce5f5bd12a2  movq r12, xmm14
00007ce5f5bd12a7  shl r12, 0x0D
00007ce5f5bd12ab  jbe 0x00007CE5F5BD0D0C
00007ce5f5bd12b1  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd12b9  jmp 0x00007CE5F5BD0D0C
00007ce5f5bd12be  ucomisd xmm1, xmm15
00007ce5f5bd12c3  jp 0x00007CE5F5BD12D2
00007ce5f5bd12c5  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd12cd  jmp 0x00007CE5F5BD0D41
00007ce5f5bd12d2  vxorps xmm0, xmm1, xmm15
00007ce5f5bd12d7  pextrw r12d, xmm0, 0x03
00007ce5f5bd12dd  and r12d, 0x7FF8
00007ce5f5bd12e4  cmp r12d, 0x08
00007ce5f5bd12e8  jnz 0x00007CE5F5BD0D41
00007ce5f5bd12ee  movq r12, xmm15
00007ce5f5bd12f3  shl r12, 0x0D
00007ce5f5bd12f7  jbe 0x00007CE5F5BD0D41
00007ce5f5bd12fd  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd1305  jmp 0x00007CE5F5BD0D41
00007ce5f5bd130a  call 0x00007CE5F5AC3AE0
00007ce5f5bd130f  jmp 0x00007CE5F5BD0D52
00007ce5f5bd1314  ucomisd xmm15, xmm14
00007ce5f5bd1319  jp 0x00007CE5F5BD1328
00007ce5f5bd131b  movaps xmm13, [0x00007CE5F57FE030]
00007ce5f5bd1323  jmp 0x00007CE5F5BD0D87
00007ce5f5bd1328  vxorps xmm0, xmm15, xmm14
00007ce5f5bd132d  pextrw r14d, xmm0, 0x03
00007ce5f5bd1333  and r14d, 0x7FF8
00007ce5f5bd133a  cmp r14d, 0x08
00007ce5f5bd133e  jnz 0x00007CE5F5BD0D87
00007ce5f5bd1344  movq r14, xmm14
00007ce5f5bd1349  shl r14, 0x0D
00007ce5f5bd134d  jbe 0x00007CE5F5BD0D87
00007ce5f5bd1353  vorps xmm13, xmm14, [0x00007CE5F57FE040]
00007ce5f5bd135b  jmp 0x00007CE5F5BD0D87
00007ce5f5bd1360  ucomisd xmm1, xmm15
00007ce5f5bd1365  jp 0x00007CE5F5BD1374
00007ce5f5bd1367  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd136f  jmp 0x00007CE5F5BD0DBC
00007ce5f5bd1374  vxorps xmm0, xmm1, xmm15
00007ce5f5bd1379  pextrw r14d, xmm0, 0x03
00007ce5f5bd137f  and r14d, 0x7FF8
00007ce5f5bd1386  cmp r14d, 0x08
00007ce5f5bd138a  jnz 0x00007CE5F5BD0DBC
00007ce5f5bd1390  movq r14, xmm15
00007ce5f5bd1395  shl r14, 0x0D
00007ce5f5bd1399  jbe 0x00007CE5F5BD0DBC
00007ce5f5bd139f  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd13a7  jmp 0x00007CE5F5BD0DBC
00007ce5f5bd13ac  ucomisd xmm1, xmm15
00007ce5f5bd13b1  jp 0x00007CE5F5BD13C0
00007ce5f5bd13b3  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd13bb  jmp 0x00007CE5F5BD0DF1
00007ce5f5bd13c0  vxorps xmm0, xmm1, xmm15
00007ce5f5bd13c5  pextrw r14d, xmm0, 0x03
00007ce5f5bd13cb  and r14d, 0x7FF8
00007ce5f5bd13d2  cmp r14d, 0x08
00007ce5f5bd13d6  jnz 0x00007CE5F5BD0DF1
00007ce5f5bd13dc  movq r14, xmm15
00007ce5f5bd13e1  shl r14, 0x0D
00007ce5f5bd13e5  jbe 0x00007CE5F5BD0DF1
00007ce5f5bd13eb  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd13f3  jmp 0x00007CE5F5BD0DF1
00007ce5f5bd13f8  call 0x00007CE5F5A0E120
00007ce5f5bd13fd  jmp 0x00007CE5F5BD0E08
00007ce5f5bd1402  int3
00007ce5f5bd1403  nop [rax+rax*1], ax
00007ce5f5bd140c  nop [rax], eax
00007ce5f5bd1410  mov qword ptr [r15+0x40], 0x420000
00007ce5f5bd1418  mov eax, 0x4201B8
00007ce5f5bd141d  mov r14, [r13+rax*1]
00007ce5f5bd1422  movq xmm1, r14
00007ce5f5bd1427  mov rax, [r15+0x50]
00007ce5f5bd142b  mov r14, [r13+rax*1]
00007ce5f5bd1430  movq xmm15, r14
00007ce5f5bd1435  movaps [r15+0x120], xmm15
00007ce5f5bd143d  mov qword ptr [r15+0x48], 0x08
00007ce5f5bd1445  xor eax, eax
00007ce5f5bd1447  mov r14d, 0x08
00007ce5f5bd144d  mov r12d, 0x200
00007ce5f5bd1453  cmp r14, r12
00007ce5f5bd1456  cmc
00007ce5f5bd1457  lahf
00007ce5f5bd1458  seto al
00007ce5f5bd145b  mov [r15+0x108], eax
00007ce5f5bd1462  movq rax, xmm1
00007ce5f5bd1467  movq r14, xmm15
00007ce5f5bd146c  vmovq xmm1, rax
00007ce5f5bd1471  vmovq xmm15, r14
00007ce5f5bd1476  movaps xmm14, xmm1
00007ce5f5bd147a  addsd xmm14, xmm15
00007ce5f5bd147f  ucomisd xmm14, xmm14
00007ce5f5bd1484  jp 0x00007CE5F5BD1516
00007ce5f5bd148a  movq xmm14, xmm14
00007ce5f5bd148f  movaps [r15+0x110], xmm14
00007ce5f5bd1497  mov eax, [r15+0x108]
00007ce5f5bd149e  sahf
00007ce5f5bd149f  jnz 0x00007CE5F5BD14D1
00007ce5f5bd14a1  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd14a9  jz 0x00007CE5F5BD16A0
00007ce5f5bd14af  nop [rax+rax*1], ax
00007ce5f5bd14b8  nop [rax+rax*1], eax
00007ce5f5bd14c0  mov eax, 0x410154
00007ce5f5bd14c5  mov [r15+0x100], rax
00007ce5f5bd14cc  jmp 0x00007CE5F59FE110
00007ce5f5bd14d1  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd14d9  jz 0x00007CE5F5BD1560
00007ce5f5bd14df  nop [rax+rax*1], ax
00007ce5f5bd14e8  nop [rax+rax*1], eax
00007ce5f5bd14f0  mov eax, 0x410140
00007ce5f5bd14f5  mov [r15+0x100], rax
00007ce5f5bd14fc  jmp 0x00007CE5F59FE110
00007ce5f5bd1501  int3
00007ce5f5bd1502  call 0x00007CE5F5A0DC20
00007ce5f5bd1507  jmp 0x00007CE5F5BD1422
00007ce5f5bd150c  call 0x00007CE5F5A0DC20
00007ce5f5bd1511  jmp 0x00007CE5F5BD1430
00007ce5f5bd1516  ucomisd xmm1, xmm15
00007ce5f5bd151b  jp 0x00007CE5F5BD152A
00007ce5f5bd151d  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd1525  jmp 0x00007CE5F5BD148A
00007ce5f5bd152a  vxorps xmm0, xmm1, xmm15
00007ce5f5bd152f  pextrw eax, xmm0, 0x03
00007ce5f5bd1534  and eax, 0x7FF8
00007ce5f5bd1539  cmp eax, 0x08
00007ce5f5bd153c  jnz 0x00007CE5F5BD148A
00007ce5f5bd1542  movq rax, xmm15
00007ce5f5bd1547  shl rax, 0x0D
00007ce5f5bd154b  jbe 0x00007CE5F5BD148A
00007ce5f5bd1551  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd1559  jmp 0x00007CE5F5BD148A
00007ce5f5bd155e  int3
00007ce5f5bd155f  nop
00007ce5f5bd1560  mov rax, [r15+0x48]
00007ce5f5bd1564  mov r14, [r15+0x50]
00007ce5f5bd1568  lea r12, [r14+rax*1]
00007ce5f5bd156c  mov r14, [r13+r12*1]
00007ce5f5bd1571  movq xmm1, r14
00007ce5f5bd1576  movaps [r15+0x120], xmm1
00007ce5f5bd157e  lea r14, [rax+0x08]
00007ce5f5bd1582  mov [r15+0x48], r14
00007ce5f5bd1586  xor eax, eax
00007ce5f5bd1588  mov r12d, 0x200
00007ce5f5bd158e  cmp r14, r12
00007ce5f5bd1591  cmc
00007ce5f5bd1592  lahf
00007ce5f5bd1593  seto al
00007ce5f5bd1596  mov [r15+0x108], eax
00007ce5f5bd159d  movaps xmm15, [r15+0x110]
00007ce5f5bd15a5  movq rax, xmm15
00007ce5f5bd15aa  movq r14, xmm1
00007ce5f5bd15af  vmovq xmm1, rax
00007ce5f5bd15b4  vmovq xmm15, r14
00007ce5f5bd15b9  movaps xmm14, xmm1
00007ce5f5bd15bd  addsd xmm14, xmm15
00007ce5f5bd15c2  ucomisd xmm14, xmm14
00007ce5f5bd15c7  jp 0x00007CE5F5BD164F
00007ce5f5bd15cd  movq xmm14, xmm14
00007ce5f5bd15d2  movaps [r15+0x110], xmm14
00007ce5f5bd15da  mov eax, [r15+0x108]
00007ce5f5bd15e1  sahf
00007ce5f5bd15e2  jnz 0x00007CE5F5BD1614
00007ce5f5bd15e4  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd15ec  jz 0x00007CE5F5BD16A0
00007ce5f5bd15f2  nop [rax+rax*1], ax
00007ce5f5bd15fb  nop [rax+rax*1], eax
00007ce5f5bd1603  mov eax, 0x410154
00007ce5f5bd1608  mov [r15+0x100], rax
00007ce5f5bd160f  jmp 0x00007CE5F59FE110
00007ce5f5bd1614  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd161c  jz 0x00007CE5F5BD1560
00007ce5f5bd1622  nop [rax+rax*1], ax
00007ce5f5bd162b  nop [rax+rax*1], eax
00007ce5f5bd1633  mov eax, 0x410140
00007ce5f5bd1638  mov [r15+0x100], rax
00007ce5f5bd163f  jmp 0x00007CE5F59FE110
00007ce5f5bd1644  int3
00007ce5f5bd1645  call 0x00007CE5F5AC3AE0
00007ce5f5bd164a  jmp 0x00007CE5F5BD1571
00007ce5f5bd164f  ucomisd xmm1, xmm15
00007ce5f5bd1654  jp 0x00007CE5F5BD1663
00007ce5f5bd1656  movaps xmm14, [0x00007CE5F57FE030]
00007ce5f5bd165e  jmp 0x00007CE5F5BD15CD
00007ce5f5bd1663  vxorps xmm0, xmm1, xmm15
00007ce5f5bd1668  pextrw eax, xmm0, 0x03
00007ce5f5bd166d  and eax, 0x7FF8
00007ce5f5bd1672  cmp eax, 0x08
00007ce5f5bd1675  jnz 0x00007CE5F5BD15CD
00007ce5f5bd167b  movq rax, xmm15
00007ce5f5bd1680  shl rax, 0x0D
00007ce5f5bd1684  jbe 0x00007CE5F5BD15CD
00007ce5f5bd168a  vorps xmm14, xmm15, [0x00007CE5F57FE040]
00007ce5f5bd1692  jmp 0x00007CE5F5BD15CD
00007ce5f5bd1697  int3
00007ce5f5bd1698  nop [rax+rax*1], eax
00007ce5f5bd16a0  mov rax, [r15+0x40]
00007ce5f5bd16a4  lea r14, [rax+0x1B8]
00007ce5f5bd16ab  movaps xmm1, [r15+0x110]
00007ce5f5bd16b3  movq rax, xmm1
00007ce5f5bd16b8  mov [r13+r14*1], rax
00007ce5f5bd16bd  mov rax, [r15+0xF0]
00007ce5f5bd16c4  mov [r15+0x100], rax
00007ce5f5bd16cb  jmp 0x00007CE5F5BCE5C0
00007ce5f5bd16d0  int3
00007ce5f5bd16d1  call 0x00007CE5F5AD5EB0
00007ce5f5bd16d6  jmp 0x00007CE5F5BD16BD
00007ce5f5bd16db  int3
00007ce5f5bd16dc  nop [rax], eax
00007ce5f5bd16e0  mov qword ptr [r15+0x100], 0x04
00007ce5f5bd16eb  mov esi, 0x00
00007ce5f5bd16f0  mov edx, 0x09
00007ce5f5bd16f5  mov rdi, 0x7FFC43A9E750
00007ce5f5bd16ff  mov rax, 0x5AE582FBD970
00007ce5f5bd1709  call rax
00007ce5f5bd170b  cmp dword ptr [r15+0x318], 0x00
00007ce5f5bd1713  jnz 0x00007CE5F59FE110
00007ce5f5bd1719  jmp 0x00007CE5F59FE0A0
00007ce5f5bd171e  int3
00007ce5f5bd171f  int3
