
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute-matrix-scalar/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x140
       7:	mov    r13d,0x0
       d:	mov    QWORD PTR [r12+0x58],r13
      12:	mov    r13d,0x420000
      18:	mov    QWORD PTR [r12+0x40],r13
      1d:	mov    r13d,0x420000
      23:	mov    r14,r13
      26:	add    r14,0x1c0
      2d:	mov    QWORD PTR [r12+0x40],r14
      32:	mov    r13d,0x41
      38:	mov    QWORD PTR [r12+0x50],r13
      3d:	mov    r13d,0x420000
      43:	mov    QWORD PTR [r12+0x48],r13
      48:	mov    r13d,0x420000
      4e:	mov    r14,r13
      51:	add    r14,0x3c0
      58:	mov    QWORD PTR [r12+0x48],r14
      5d:	jmp    0x62
      62:	mov    r13,QWORD PTR [r12+0x58]
      67:	mov    r14,r13
      6a:	add    r14,0x1
      6e:	mov    QWORD PTR [r12+0x60],r14
      73:	lea    r13,[r12]
      77:	mov    r14d,0x1e43f541
      7d:	mov    r15d,0x410050
      83:	mov    QWORD PTR [r12+0x378],0x3
      8f:	mov    QWORD PTR [r12+0x108],rbx
      97:	stmxcsr DWORD PTR [r12-0x28]
      9d:	ldmxcsr DWORD PTR [r12-0x38]
      a3:	movabs r11,0x62fb535e14c0
      ad:	mov    rdi,r13
      b0:	mov    rsi,r14
      b3:	mov    rdx,r15
      b6:	call   r11
      b9:	ldmxcsr DWORD PTR [r12-0x28]
      bf:	mov    rbx,QWORD PTR [r12+0x108]
      c7:	mov    QWORD PTR [r12+0x378],0x2
      d3:	mov    rbp,rax
      d6:	mov    r13,QWORD PTR [r12+0x58]
      db:	mov    r14,r13
      de:	ror    r14,0x3d
      e2:	mov    r13,r14
      e5:	and    r13,0xfffffffffffffff8
      e9:	mov    QWORD PTR [r12+0x58],r13
      ee:	lea    r13,[r12]
      f2:	mov    r14d,0x1e43ed80
      f8:	mov    r15d,0x410058
      fe:	mov    QWORD PTR [r12+0x378],0x3
     10a:	mov    QWORD PTR [r12+0x108],rbx
     112:	stmxcsr DWORD PTR [r12-0x28]
     118:	ldmxcsr DWORD PTR [r12-0x38]
     11e:	movabs r11,0x62fb535e14c0
     128:	mov    rdi,r13
     12b:	mov    rsi,r14
     12e:	mov    rdx,r15
     131:	call   r11
     134:	ldmxcsr DWORD PTR [r12-0x28]
     13a:	mov    rbx,QWORD PTR [r12+0x108]
     142:	mov    QWORD PTR [r12+0x378],0x2
     14e:	mov    rbp,rax
     151:	mov    r13,QWORD PTR [r12+0x60]
     156:	mov    r14,r13
     159:	sub    r14,0x40
     15d:	pushf
     15e:	pop    rdx
     15f:	mov    r10d,edx
     162:	and    r10d,0xc0
     169:	shl    r10d,0x18
     16d:	mov    r11d,edx
     170:	and    r11d,0x1
     174:	shl    r11d,0x1d
     178:	or     r10d,r11d
     17b:	mov    r11d,edx
     17e:	and    r11d,0x800
     185:	shl    r11d,0x11
     189:	or     r10d,r11d
     18c:	mov    r11d,0xf0000000
     192:	and    r11,r10
     195:	movabs rsi,0xffffffff0fffffff
     19f:	and    rbx,rsi
     1a2:	or     rbx,r11
     1a5:	btc    rbx,0x1d
     1aa:	mov    r13d,DWORD PTR [r12+0x50]
     1af:	mov    r14d,r13d
     1b2:	sub    r14d,0x1
     1b6:	mov    QWORD PTR [r12+0x50],r14
     1bb:	mov    r13,QWORD PTR [r12+0x58]
     1c0:	mov    r14,QWORD PTR [r12+0x48]
     1c5:	mov    rcx,r13
     1c8:	mov    r15,r14
     1cb:	add    r15,rcx
     1ce:	mov    r14,QWORD PTR [r12+0x120]
     1d6:	mov    QWORD PTR [r15],r14
     1d9:	mov    r14d,0x0
     1df:	mov    DWORD PTR [r12+0x32c],r14d
     1e7:	mov    r14,QWORD PTR [r12+0x40]
     1ec:	mov    rcx,r13
     1ef:	mov    r15,r14
     1f2:	add    r15,rcx
     1f5:	mov    r13,QWORD PTR [r12+0x110]
     1fd:	mov    QWORD PTR [r15],r13
     200:	mov    r13d,0x0
     206:	mov    DWORD PTR [r12+0x32c],r13d
     20e:	mov    r13d,0x0
     214:	mov    r14,QWORD PTR [r12+0x60]
     219:	mov    rcx,r14
     21c:	mov    r15,r13
     21f:	or     r15,rcx
     222:	mov    QWORD PTR [r12+0x58],r15
     227:	cmp    QWORD PTR [r12+0x380],0x0
     230:	je     0x264
     236:	mov    eax,0x410070
     23b:	mov    QWORD PTR [r12+0x100],rax
     243:	mov    QWORD PTR [r12+0x108],rbx
     24b:	add    rsp,0x140
     252:	mov    eax,0xc
     257:	movabs r11,0x62fb5377c5f0
     261:	jmp    r11
     264:	test   ebx,0x40000000
     26a:	je     0x62
     270:	jmp    0x275
     275:	mov    r13d,0x0
     27b:	mov    r14d,0x0
     281:	mov    QWORD PTR [r12+0x110],r13
     289:	mov    QWORD PTR [r12+0x118],r14
     291:	mov    r13d,0x0
     297:	mov    QWORD PTR [r12+0x58],r13
     29c:	mov    r13d,0x420000
     2a2:	mov    QWORD PTR [r12+0x50],r13
     2a7:	mov    r13d,0x420000
     2ad:	mov    r14,r13
     2b0:	add    r14,0x5c0
     2b7:	mov    QWORD PTR [r12+0x50],r14
     2bc:	jmp    0x2c1
     2c1:	mov    r13d,0x0
     2c7:	mov    QWORD PTR [r12+0x60],r13
     2cc:	mov    r13d,0x0
     2d2:	mov    r14,QWORD PTR [r12+0x50]
     2d7:	mov    rcx,r14
     2da:	mov    r15,r13
     2dd:	or     r15,rcx
     2e0:	mov    QWORD PTR [r12+0x68],r15
     2e5:	jmp    0x2ea
     2ea:	mov    r13,QWORD PTR [r12+0x60]
     2ef:	mov    r14,r13
     2f2:	shl    r14,0x6
     2f6:	mov    r13,QWORD PTR [r12+0x40]
     2fb:	mov    rcx,r14
     2fe:	mov    r15,r13
     301:	add    r15,rcx
     304:	mov    QWORD PTR [r12+0x70],r15
     309:	mov    r13,r15
     30c:	add    r13,0x8
     310:	mov    r14,QWORD PTR [r15]
     313:	mov    rbp,QWORD PTR [r13+0x0]
     317:	mov    r13d,0x0
     31d:	mov    QWORD PTR [r12+0x120],r14
     325:	mov    QWORD PTR [r12+0x128],r13
     32d:	mov    r13d,0x0
     333:	mov    QWORD PTR [r12+0x130],rbp
     33b:	mov    QWORD PTR [r12+0x138],r13
     343:	mov    r13,r15
     346:	add    r13,0x10
     34a:	mov    r14,r13
     34d:	add    r14,0x8
     351:	mov    r15,QWORD PTR [r13+0x0]
     355:	mov    r13,QWORD PTR [r14]
     358:	mov    r14d,0x0
     35e:	mov    QWORD PTR [r12+0x140],r15
     366:	mov    QWORD PTR [r12+0x148],r14
     36e:	mov    r14d,0x0
     374:	mov    QWORD PTR [r12+0x150],r13
     37c:	mov    QWORD PTR [r12+0x158],r14
     384:	mov    r13,QWORD PTR [r12+0x70]
     389:	mov    r14,r13
     38c:	add    r14,0x20
     390:	mov    r15,r14
     393:	add    r15,0x8
     397:	mov    rbp,QWORD PTR [r14]
     39a:	mov    r14,QWORD PTR [r15]
     39d:	mov    r15d,0x0
     3a3:	mov    QWORD PTR [r12+0x160],rbp
     3ab:	mov    QWORD PTR [r12+0x168],r15
     3b3:	mov    r15d,0x0
     3b9:	mov    QWORD PTR [r12+0x170],r14
     3c1:	mov    QWORD PTR [r12+0x178],r15
     3c9:	mov    r14,r13
     3cc:	add    r14,0x30
     3d0:	mov    r13,r14
     3d3:	add    r13,0x8
     3d7:	mov    r15,QWORD PTR [r14]
     3da:	mov    r14,QWORD PTR [r13+0x0]
     3de:	mov    r13d,0x0
     3e4:	mov    QWORD PTR [r12+0x180],r15
     3ec:	mov    QWORD PTR [r12+0x188],r13
     3f4:	mov    r13d,0x0
     3fa:	mov    QWORD PTR [r12+0x210],r14
     402:	mov    QWORD PTR [r12+0x218],r13
     40a:	mov    r13d,0x0
     410:	mov    QWORD PTR [r12+0x70],r13
     415:	jmp    0x41a
     41a:	mov    r13,QWORD PTR [r12+0x70]
     41f:	mov    r14,QWORD PTR [r12+0x48]
     424:	mov    rcx,r13
     427:	mov    r15,r14
     42a:	add    r15,rcx
     42d:	mov    QWORD PTR [r12+0x78],r15
     432:	mov    r13,QWORD PTR [r15]
     435:	mov    r14d,0x0
     43b:	mov    QWORD PTR [r12+0x220],r13
     443:	mov    QWORD PTR [r12+0x228],r14
     44b:	mov    r13,r15
     44e:	add    r13,0x40
     452:	mov    r14,QWORD PTR [r13+0x0]
     456:	mov    r13d,0x0
     45c:	mov    QWORD PTR [r12+0x230],r14
     464:	mov    QWORD PTR [r12+0x238],r13
     46c:	mov    r13,r15
     46f:	add    r13,0x80
     476:	mov    r14,QWORD PTR [r13+0x0]
     47a:	mov    r13d,0x0
     480:	mov    QWORD PTR [r12+0x240],r14
     488:	mov    QWORD PTR [r12+0x248],r13
     490:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     49a:	movdqa xmm2,xmm0
     49e:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     4a8:	movdqa xmm3,xmm0
     4ac:	cmp    DWORD PTR [r12+0x310],0x0
     4b5:	jne    0x54f
     4bb:	movdqa xmm0,xmm2
     4bf:	movdqa xmm1,xmm3
     4c3:	movq   rax,xmm0
     4c8:	add    rax,rax
     4cb:	je     0x4e1
     4cd:	shr    rax,0x35
     4d1:	sub    eax,0x201
     4d6:	cmp    eax,0x3fc
     4db:	ja     0x54f
     4e1:	movq   rax,xmm1
     4e6:	add    rax,rax
     4e9:	je     0x4ff
     4eb:	shr    rax,0x35
     4ef:	sub    eax,0x201
     4f4:	cmp    eax,0x3fc
     4f9:	ja     0x54f
     4ff:	movq   xmm0,xmm0
     503:	movq   xmm1,xmm1
     507:	stmxcsr DWORD PTR [rsp+0x100]
     50f:	mov    DWORD PTR [rsp+0x104],0x1f80
     51a:	ldmxcsr DWORD PTR [rsp+0x104]
     522:	mulsd  xmm0,xmm1
     526:	stmxcsr DWORD PTR [rsp+0x104]
     52e:	ldmxcsr DWORD PTR [rsp+0x100]
     536:	mov    eax,DWORD PTR [rsp+0x104]
     53d:	shr    eax,1
     53f:	and    eax,0x10
     542:	or     DWORD PTR [r12+0x314],eax
     54a:	jmp    0x5fc
     54f:	movdqa xmm0,xmm2
     553:	movdqa xmm1,xmm3
     557:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     560:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     569:	mov    QWORD PTR [r12+0x378],0x3
     575:	movdqu XMMWORD PTR [rsp],xmm2
     57a:	movdqu XMMWORD PTR [rsp+0x10],xmm3
     580:	mov    QWORD PTR [r12+0x108],rbx
     588:	stmxcsr DWORD PTR [r12-0x28]
     58e:	ldmxcsr DWORD PTR [r12-0x38]
     594:	lea    rdi,[rsp+0xf0]
     59c:	lea    rsi,[rsp+0xd0]
     5a4:	lea    rdx,[rsp+0xe0]
     5ac:	mov    ecx,0xe
     5b1:	mov    r8d,DWORD PTR [r12+0x310]
     5b9:	lea    r9,[r12+0x314]
     5c1:	movabs r11,0x62fb535e8750
     5cb:	call   r11
     5ce:	ldmxcsr DWORD PTR [r12-0x28]
     5d4:	movdqu xmm2,XMMWORD PTR [rsp]
     5d9:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
     5df:	mov    rbx,QWORD PTR [r12+0x108]
     5e7:	mov    QWORD PTR [r12+0x378],0x2
     5f3:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     5fc:	movdqa xmm4,xmm0
     600:	movdqa xmm0,xmm4
     604:	movdqu XMMWORD PTR [r12+0x220],xmm0
     60e:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     618:	movdqa xmm2,xmm0
     61c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
     626:	movdqa xmm3,xmm0
     62a:	cmp    DWORD PTR [r12+0x310],0x0
     633:	jne    0x6cd
     639:	movdqa xmm0,xmm2
     63d:	movdqa xmm1,xmm3
     641:	movq   rax,xmm0
     646:	add    rax,rax
     649:	je     0x65f
     64b:	shr    rax,0x35
     64f:	sub    eax,0x201
     654:	cmp    eax,0x3fc
     659:	ja     0x6cd
     65f:	movq   rax,xmm1
     664:	add    rax,rax
     667:	je     0x67d
     669:	shr    rax,0x35
     66d:	sub    eax,0x201
     672:	cmp    eax,0x3fc
     677:	ja     0x6cd
     67d:	movq   xmm0,xmm0
     681:	movq   xmm1,xmm1
     685:	stmxcsr DWORD PTR [rsp+0x100]
     68d:	mov    DWORD PTR [rsp+0x104],0x1f80
     698:	ldmxcsr DWORD PTR [rsp+0x104]
     6a0:	mulsd  xmm0,xmm1
     6a4:	stmxcsr DWORD PTR [rsp+0x104]
     6ac:	ldmxcsr DWORD PTR [rsp+0x100]
     6b4:	mov    eax,DWORD PTR [rsp+0x104]
     6bb:	shr    eax,1
     6bd:	and    eax,0x10
     6c0:	or     DWORD PTR [r12+0x314],eax
     6c8:	jmp    0x77a
     6cd:	movdqa xmm0,xmm2
     6d1:	movdqa xmm1,xmm3
     6d5:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     6de:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     6e7:	mov    QWORD PTR [r12+0x378],0x3
     6f3:	movdqu XMMWORD PTR [rsp],xmm2
     6f8:	movdqu XMMWORD PTR [rsp+0x10],xmm3
     6fe:	mov    QWORD PTR [r12+0x108],rbx
     706:	stmxcsr DWORD PTR [r12-0x28]
     70c:	ldmxcsr DWORD PTR [r12-0x38]
     712:	lea    rdi,[rsp+0xf0]
     71a:	lea    rsi,[rsp+0xd0]
     722:	lea    rdx,[rsp+0xe0]
     72a:	mov    ecx,0xe
     72f:	mov    r8d,DWORD PTR [r12+0x310]
     737:	lea    r9,[r12+0x314]
     73f:	movabs r11,0x62fb535e8750
     749:	call   r11
     74c:	ldmxcsr DWORD PTR [r12-0x28]
     752:	movdqu xmm2,XMMWORD PTR [rsp]
     757:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
     75d:	mov    rbx,QWORD PTR [r12+0x108]
     765:	mov    QWORD PTR [r12+0x378],0x2
     771:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     77a:	movdqa xmm4,xmm0
     77e:	movdqa xmm0,xmm4
     782:	movdqu XMMWORD PTR [r12+0x230],xmm0
     78c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     796:	movdqa xmm2,xmm0
     79a:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     7a4:	movdqa xmm3,xmm0
     7a8:	cmp    DWORD PTR [r12+0x310],0x0
     7b1:	jne    0x84b
     7b7:	movdqa xmm0,xmm2
     7bb:	movdqa xmm1,xmm3
     7bf:	movq   rax,xmm0
     7c4:	add    rax,rax
     7c7:	je     0x7dd
     7c9:	shr    rax,0x35
     7cd:	sub    eax,0x201
     7d2:	cmp    eax,0x3fc
     7d7:	ja     0x84b
     7dd:	movq   rax,xmm1
     7e2:	add    rax,rax
     7e5:	je     0x7fb
     7e7:	shr    rax,0x35
     7eb:	sub    eax,0x201
     7f0:	cmp    eax,0x3fc
     7f5:	ja     0x84b
     7fb:	movq   xmm0,xmm0
     7ff:	movq   xmm1,xmm1
     803:	stmxcsr DWORD PTR [rsp+0x100]
     80b:	mov    DWORD PTR [rsp+0x104],0x1f80
     816:	ldmxcsr DWORD PTR [rsp+0x104]
     81e:	addsd  xmm0,xmm1
     822:	stmxcsr DWORD PTR [rsp+0x104]
     82a:	ldmxcsr DWORD PTR [rsp+0x100]
     832:	mov    eax,DWORD PTR [rsp+0x104]
     839:	shr    eax,1
     83b:	and    eax,0x10
     83e:	or     DWORD PTR [r12+0x314],eax
     846:	jmp    0x8f8
     84b:	movdqa xmm0,xmm2
     84f:	movdqa xmm1,xmm3
     853:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     85c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     865:	mov    QWORD PTR [r12+0x378],0x3
     871:	movdqu XMMWORD PTR [rsp],xmm2
     876:	movdqu XMMWORD PTR [rsp+0x10],xmm3
     87c:	mov    QWORD PTR [r12+0x108],rbx
     884:	stmxcsr DWORD PTR [r12-0x28]
     88a:	ldmxcsr DWORD PTR [r12-0x38]
     890:	lea    rdi,[rsp+0xf0]
     898:	lea    rsi,[rsp+0xd0]
     8a0:	lea    rdx,[rsp+0xe0]
     8a8:	mov    ecx,0xc
     8ad:	mov    r8d,DWORD PTR [r12+0x310]
     8b5:	lea    r9,[r12+0x314]
     8bd:	movabs r11,0x62fb535e8750
     8c7:	call   r11
     8ca:	ldmxcsr DWORD PTR [r12-0x28]
     8d0:	movdqu xmm2,XMMWORD PTR [rsp]
     8d5:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
     8db:	mov    rbx,QWORD PTR [r12+0x108]
     8e3:	mov    QWORD PTR [r12+0x378],0x2
     8ef:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     8f8:	movdqa xmm4,xmm0
     8fc:	movdqa xmm0,xmm4
     900:	movdqu XMMWORD PTR [r12+0x220],xmm0
     90a:	movdqu xmm0,XMMWORD PTR [r12+0x230]
     914:	movdqa xmm2,xmm0
     918:	cmp    DWORD PTR [r12+0x310],0x0
     921:	jne    0x9bb
     927:	movdqa xmm0,xmm4
     92b:	movdqa xmm1,xmm2
     92f:	movq   rax,xmm0
     934:	add    rax,rax
     937:	je     0x94d
     939:	shr    rax,0x35
     93d:	sub    eax,0x201
     942:	cmp    eax,0x3fc
     947:	ja     0x9bb
     94d:	movq   rax,xmm1
     952:	add    rax,rax
     955:	je     0x96b
     957:	shr    rax,0x35
     95b:	sub    eax,0x201
     960:	cmp    eax,0x3fc
     965:	ja     0x9bb
     96b:	movq   xmm0,xmm0
     96f:	movq   xmm1,xmm1
     973:	stmxcsr DWORD PTR [rsp+0x100]
     97b:	mov    DWORD PTR [rsp+0x104],0x1f80
     986:	ldmxcsr DWORD PTR [rsp+0x104]
     98e:	addsd  xmm0,xmm1
     992:	stmxcsr DWORD PTR [rsp+0x104]
     99a:	ldmxcsr DWORD PTR [rsp+0x100]
     9a2:	mov    eax,DWORD PTR [rsp+0x104]
     9a9:	shr    eax,1
     9ab:	and    eax,0x10
     9ae:	or     DWORD PTR [r12+0x314],eax
     9b6:	jmp    0xa68
     9bb:	movdqa xmm0,xmm4
     9bf:	movdqa xmm1,xmm2
     9c3:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     9cc:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     9d5:	mov    QWORD PTR [r12+0x378],0x3
     9e1:	movdqu XMMWORD PTR [rsp],xmm2
     9e6:	movdqu XMMWORD PTR [rsp+0x20],xmm4
     9ec:	mov    QWORD PTR [r12+0x108],rbx
     9f4:	stmxcsr DWORD PTR [r12-0x28]
     9fa:	ldmxcsr DWORD PTR [r12-0x38]
     a00:	lea    rdi,[rsp+0xf0]
     a08:	lea    rsi,[rsp+0xd0]
     a10:	lea    rdx,[rsp+0xe0]
     a18:	mov    ecx,0xc
     a1d:	mov    r8d,DWORD PTR [r12+0x310]
     a25:	lea    r9,[r12+0x314]
     a2d:	movabs r11,0x62fb535e8750
     a37:	call   r11
     a3a:	ldmxcsr DWORD PTR [r12-0x28]
     a40:	movdqu xmm2,XMMWORD PTR [rsp]
     a45:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
     a4b:	mov    rbx,QWORD PTR [r12+0x108]
     a53:	mov    QWORD PTR [r12+0x378],0x2
     a5f:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     a68:	movdqa xmm3,xmm0
     a6c:	movdqa xmm0,xmm3
     a70:	movdqu XMMWORD PTR [r12+0x220],xmm0
     a7a:	movdqu xmm0,XMMWORD PTR [r12+0x140]
     a84:	movdqa xmm2,xmm0
     a88:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     a92:	movdqa xmm3,xmm0
     a96:	cmp    DWORD PTR [r12+0x310],0x0
     a9f:	jne    0xb39
     aa5:	movdqa xmm0,xmm2
     aa9:	movdqa xmm1,xmm3
     aad:	movq   rax,xmm0
     ab2:	add    rax,rax
     ab5:	je     0xacb
     ab7:	shr    rax,0x35
     abb:	sub    eax,0x201
     ac0:	cmp    eax,0x3fc
     ac5:	ja     0xb39
     acb:	movq   rax,xmm1
     ad0:	add    rax,rax
     ad3:	je     0xae9
     ad5:	shr    rax,0x35
     ad9:	sub    eax,0x201
     ade:	cmp    eax,0x3fc
     ae3:	ja     0xb39
     ae9:	movq   xmm0,xmm0
     aed:	movq   xmm1,xmm1
     af1:	stmxcsr DWORD PTR [rsp+0x100]
     af9:	mov    DWORD PTR [rsp+0x104],0x1f80
     b04:	ldmxcsr DWORD PTR [rsp+0x104]
     b0c:	mulsd  xmm0,xmm1
     b10:	stmxcsr DWORD PTR [rsp+0x104]
     b18:	ldmxcsr DWORD PTR [rsp+0x100]
     b20:	mov    eax,DWORD PTR [rsp+0x104]
     b27:	shr    eax,1
     b29:	and    eax,0x10
     b2c:	or     DWORD PTR [r12+0x314],eax
     b34:	jmp    0xbe6
     b39:	movdqa xmm0,xmm2
     b3d:	movdqa xmm1,xmm3
     b41:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     b4a:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     b53:	mov    QWORD PTR [r12+0x378],0x3
     b5f:	movdqu XMMWORD PTR [rsp],xmm2
     b64:	movdqu XMMWORD PTR [rsp+0x10],xmm3
     b6a:	mov    QWORD PTR [r12+0x108],rbx
     b72:	stmxcsr DWORD PTR [r12-0x28]
     b78:	ldmxcsr DWORD PTR [r12-0x38]
     b7e:	lea    rdi,[rsp+0xf0]
     b86:	lea    rsi,[rsp+0xd0]
     b8e:	lea    rdx,[rsp+0xe0]
     b96:	mov    ecx,0xe
     b9b:	mov    r8d,DWORD PTR [r12+0x310]
     ba3:	lea    r9,[r12+0x314]
     bab:	movabs r11,0x62fb535e8750
     bb5:	call   r11
     bb8:	ldmxcsr DWORD PTR [r12-0x28]
     bbe:	movdqu xmm2,XMMWORD PTR [rsp]
     bc3:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
     bc9:	mov    rbx,QWORD PTR [r12+0x108]
     bd1:	mov    QWORD PTR [r12+0x378],0x2
     bdd:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     be6:	movdqa xmm4,xmm0
     bea:	movdqa xmm0,xmm4
     bee:	movdqu XMMWORD PTR [r12+0x230],xmm0
     bf8:	mov    r13,QWORD PTR [r12+0x78]
     bfd:	mov    r14,r13
     c00:	add    r14,0xc0
     c07:	mov    r13,QWORD PTR [r14]
     c0a:	mov    r14d,0x0
     c10:	mov    QWORD PTR [r12+0x240],r13
     c18:	mov    QWORD PTR [r12+0x248],r14
     c20:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     c2a:	movdqa xmm2,xmm0
     c2e:	cmp    DWORD PTR [r12+0x310],0x0
     c37:	jne    0xcd1
     c3d:	movdqa xmm0,xmm2
     c41:	movdqa xmm1,xmm4
     c45:	movq   rax,xmm0
     c4a:	add    rax,rax
     c4d:	je     0xc63
     c4f:	shr    rax,0x35
     c53:	sub    eax,0x201
     c58:	cmp    eax,0x3fc
     c5d:	ja     0xcd1
     c63:	movq   rax,xmm1
     c68:	add    rax,rax
     c6b:	je     0xc81
     c6d:	shr    rax,0x35
     c71:	sub    eax,0x201
     c76:	cmp    eax,0x3fc
     c7b:	ja     0xcd1
     c81:	movq   xmm0,xmm0
     c85:	movq   xmm1,xmm1
     c89:	stmxcsr DWORD PTR [rsp+0x100]
     c91:	mov    DWORD PTR [rsp+0x104],0x1f80
     c9c:	ldmxcsr DWORD PTR [rsp+0x104]
     ca4:	addsd  xmm0,xmm1
     ca8:	stmxcsr DWORD PTR [rsp+0x104]
     cb0:	ldmxcsr DWORD PTR [rsp+0x100]
     cb8:	mov    eax,DWORD PTR [rsp+0x104]
     cbf:	shr    eax,1
     cc1:	and    eax,0x10
     cc4:	or     DWORD PTR [r12+0x314],eax
     ccc:	jmp    0xd7e
     cd1:	movdqa xmm0,xmm2
     cd5:	movdqa xmm1,xmm4
     cd9:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     ce2:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     ceb:	mov    QWORD PTR [r12+0x378],0x3
     cf7:	movdqu XMMWORD PTR [rsp],xmm2
     cfc:	movdqu XMMWORD PTR [rsp+0x20],xmm4
     d02:	mov    QWORD PTR [r12+0x108],rbx
     d0a:	stmxcsr DWORD PTR [r12-0x28]
     d10:	ldmxcsr DWORD PTR [r12-0x38]
     d16:	lea    rdi,[rsp+0xf0]
     d1e:	lea    rsi,[rsp+0xd0]
     d26:	lea    rdx,[rsp+0xe0]
     d2e:	mov    ecx,0xc
     d33:	mov    r8d,DWORD PTR [r12+0x310]
     d3b:	lea    r9,[r12+0x314]
     d43:	movabs r11,0x62fb535e8750
     d4d:	call   r11
     d50:	ldmxcsr DWORD PTR [r12-0x28]
     d56:	movdqu xmm2,XMMWORD PTR [rsp]
     d5b:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
     d61:	mov    rbx,QWORD PTR [r12+0x108]
     d69:	mov    QWORD PTR [r12+0x378],0x2
     d75:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     d7e:	movdqa xmm3,xmm0
     d82:	movdqa xmm0,xmm3
     d86:	movdqu XMMWORD PTR [r12+0x220],xmm0
     d90:	movdqu xmm0,XMMWORD PTR [r12+0x150]
     d9a:	movdqa xmm2,xmm0
     d9e:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     da8:	movdqa xmm3,xmm0
     dac:	cmp    DWORD PTR [r12+0x310],0x0
     db5:	jne    0xe4f
     dbb:	movdqa xmm0,xmm2
     dbf:	movdqa xmm1,xmm3
     dc3:	movq   rax,xmm0
     dc8:	add    rax,rax
     dcb:	je     0xde1
     dcd:	shr    rax,0x35
     dd1:	sub    eax,0x201
     dd6:	cmp    eax,0x3fc
     ddb:	ja     0xe4f
     de1:	movq   rax,xmm1
     de6:	add    rax,rax
     de9:	je     0xdff
     deb:	shr    rax,0x35
     def:	sub    eax,0x201
     df4:	cmp    eax,0x3fc
     df9:	ja     0xe4f
     dff:	movq   xmm0,xmm0
     e03:	movq   xmm1,xmm1
     e07:	stmxcsr DWORD PTR [rsp+0x100]
     e0f:	mov    DWORD PTR [rsp+0x104],0x1f80
     e1a:	ldmxcsr DWORD PTR [rsp+0x104]
     e22:	mulsd  xmm0,xmm1
     e26:	stmxcsr DWORD PTR [rsp+0x104]
     e2e:	ldmxcsr DWORD PTR [rsp+0x100]
     e36:	mov    eax,DWORD PTR [rsp+0x104]
     e3d:	shr    eax,1
     e3f:	and    eax,0x10
     e42:	or     DWORD PTR [r12+0x314],eax
     e4a:	jmp    0xefc
     e4f:	movdqa xmm0,xmm2
     e53:	movdqa xmm1,xmm3
     e57:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     e60:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
     e69:	mov    QWORD PTR [r12+0x378],0x3
     e75:	movdqu XMMWORD PTR [rsp],xmm2
     e7a:	movdqu XMMWORD PTR [rsp+0x10],xmm3
     e80:	mov    QWORD PTR [r12+0x108],rbx
     e88:	stmxcsr DWORD PTR [r12-0x28]
     e8e:	ldmxcsr DWORD PTR [r12-0x38]
     e94:	lea    rdi,[rsp+0xf0]
     e9c:	lea    rsi,[rsp+0xd0]
     ea4:	lea    rdx,[rsp+0xe0]
     eac:	mov    ecx,0xe
     eb1:	mov    r8d,DWORD PTR [r12+0x310]
     eb9:	lea    r9,[r12+0x314]
     ec1:	movabs r11,0x62fb535e8750
     ecb:	call   r11
     ece:	ldmxcsr DWORD PTR [r12-0x28]
     ed4:	movdqu xmm2,XMMWORD PTR [rsp]
     ed9:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
     edf:	mov    rbx,QWORD PTR [r12+0x108]
     ee7:	mov    QWORD PTR [r12+0x378],0x2
     ef3:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
     efc:	movdqa xmm4,xmm0
     f00:	movdqa xmm0,xmm4
     f04:	movdqu XMMWORD PTR [r12+0x230],xmm0
     f0e:	mov    r13,QWORD PTR [r12+0x78]
     f13:	mov    r14,r13
     f16:	add    r14,0x100
     f1d:	mov    r13,QWORD PTR [r14]
     f20:	mov    r14d,0x0
     f26:	mov    QWORD PTR [r12+0x240],r13
     f2e:	mov    QWORD PTR [r12+0x248],r14
     f36:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     f40:	movdqa xmm2,xmm0
     f44:	cmp    DWORD PTR [r12+0x310],0x0
     f4d:	jne    0xfe7
     f53:	movdqa xmm0,xmm2
     f57:	movdqa xmm1,xmm4
     f5b:	movq   rax,xmm0
     f60:	add    rax,rax
     f63:	je     0xf79
     f65:	shr    rax,0x35
     f69:	sub    eax,0x201
     f6e:	cmp    eax,0x3fc
     f73:	ja     0xfe7
     f79:	movq   rax,xmm1
     f7e:	add    rax,rax
     f81:	je     0xf97
     f83:	shr    rax,0x35
     f87:	sub    eax,0x201
     f8c:	cmp    eax,0x3fc
     f91:	ja     0xfe7
     f97:	movq   xmm0,xmm0
     f9b:	movq   xmm1,xmm1
     f9f:	stmxcsr DWORD PTR [rsp+0x100]
     fa7:	mov    DWORD PTR [rsp+0x104],0x1f80
     fb2:	ldmxcsr DWORD PTR [rsp+0x104]
     fba:	addsd  xmm0,xmm1
     fbe:	stmxcsr DWORD PTR [rsp+0x104]
     fc6:	ldmxcsr DWORD PTR [rsp+0x100]
     fce:	mov    eax,DWORD PTR [rsp+0x104]
     fd5:	shr    eax,1
     fd7:	and    eax,0x10
     fda:	or     DWORD PTR [r12+0x314],eax
     fe2:	jmp    0x1094
     fe7:	movdqa xmm0,xmm2
     feb:	movdqa xmm1,xmm4
     fef:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
     ff8:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1001:	mov    QWORD PTR [r12+0x378],0x3
    100d:	movdqu XMMWORD PTR [rsp],xmm2
    1012:	movdqu XMMWORD PTR [rsp+0x20],xmm4
    1018:	mov    QWORD PTR [r12+0x108],rbx
    1020:	stmxcsr DWORD PTR [r12-0x28]
    1026:	ldmxcsr DWORD PTR [r12-0x38]
    102c:	lea    rdi,[rsp+0xf0]
    1034:	lea    rsi,[rsp+0xd0]
    103c:	lea    rdx,[rsp+0xe0]
    1044:	mov    ecx,0xc
    1049:	mov    r8d,DWORD PTR [r12+0x310]
    1051:	lea    r9,[r12+0x314]
    1059:	movabs r11,0x62fb535e8750
    1063:	call   r11
    1066:	ldmxcsr DWORD PTR [r12-0x28]
    106c:	movdqu xmm2,XMMWORD PTR [rsp]
    1071:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
    1077:	mov    rbx,QWORD PTR [r12+0x108]
    107f:	mov    QWORD PTR [r12+0x378],0x2
    108b:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1094:	movdqa xmm3,xmm0
    1098:	movdqa xmm0,xmm3
    109c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    10a6:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    10b0:	movdqa xmm2,xmm0
    10b4:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    10be:	movdqa xmm3,xmm0
    10c2:	cmp    DWORD PTR [r12+0x310],0x0
    10cb:	jne    0x1165
    10d1:	movdqa xmm0,xmm2
    10d5:	movdqa xmm1,xmm3
    10d9:	movq   rax,xmm0
    10de:	add    rax,rax
    10e1:	je     0x10f7
    10e3:	shr    rax,0x35
    10e7:	sub    eax,0x201
    10ec:	cmp    eax,0x3fc
    10f1:	ja     0x1165
    10f7:	movq   rax,xmm1
    10fc:	add    rax,rax
    10ff:	je     0x1115
    1101:	shr    rax,0x35
    1105:	sub    eax,0x201
    110a:	cmp    eax,0x3fc
    110f:	ja     0x1165
    1115:	movq   xmm0,xmm0
    1119:	movq   xmm1,xmm1
    111d:	stmxcsr DWORD PTR [rsp+0x100]
    1125:	mov    DWORD PTR [rsp+0x104],0x1f80
    1130:	ldmxcsr DWORD PTR [rsp+0x104]
    1138:	mulsd  xmm0,xmm1
    113c:	stmxcsr DWORD PTR [rsp+0x104]
    1144:	ldmxcsr DWORD PTR [rsp+0x100]
    114c:	mov    eax,DWORD PTR [rsp+0x104]
    1153:	shr    eax,1
    1155:	and    eax,0x10
    1158:	or     DWORD PTR [r12+0x314],eax
    1160:	jmp    0x1212
    1165:	movdqa xmm0,xmm2
    1169:	movdqa xmm1,xmm3
    116d:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1176:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    117f:	mov    QWORD PTR [r12+0x378],0x3
    118b:	movdqu XMMWORD PTR [rsp],xmm2
    1190:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1196:	mov    QWORD PTR [r12+0x108],rbx
    119e:	stmxcsr DWORD PTR [r12-0x28]
    11a4:	ldmxcsr DWORD PTR [r12-0x38]
    11aa:	lea    rdi,[rsp+0xf0]
    11b2:	lea    rsi,[rsp+0xd0]
    11ba:	lea    rdx,[rsp+0xe0]
    11c2:	mov    ecx,0xe
    11c7:	mov    r8d,DWORD PTR [r12+0x310]
    11cf:	lea    r9,[r12+0x314]
    11d7:	movabs r11,0x62fb535e8750
    11e1:	call   r11
    11e4:	ldmxcsr DWORD PTR [r12-0x28]
    11ea:	movdqu xmm2,XMMWORD PTR [rsp]
    11ef:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    11f5:	mov    rbx,QWORD PTR [r12+0x108]
    11fd:	mov    QWORD PTR [r12+0x378],0x2
    1209:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1212:	movdqa xmm4,xmm0
    1216:	movdqa xmm0,xmm4
    121a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    1224:	mov    r13,QWORD PTR [r12+0x78]
    1229:	mov    r14,r13
    122c:	add    r14,0x140
    1233:	mov    r13,QWORD PTR [r14]
    1236:	mov    r14d,0x0
    123c:	mov    QWORD PTR [r12+0x240],r13
    1244:	mov    QWORD PTR [r12+0x248],r14
    124c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1256:	movdqa xmm2,xmm0
    125a:	cmp    DWORD PTR [r12+0x310],0x0
    1263:	jne    0x12fd
    1269:	movdqa xmm0,xmm2
    126d:	movdqa xmm1,xmm4
    1271:	movq   rax,xmm0
    1276:	add    rax,rax
    1279:	je     0x128f
    127b:	shr    rax,0x35
    127f:	sub    eax,0x201
    1284:	cmp    eax,0x3fc
    1289:	ja     0x12fd
    128f:	movq   rax,xmm1
    1294:	add    rax,rax
    1297:	je     0x12ad
    1299:	shr    rax,0x35
    129d:	sub    eax,0x201
    12a2:	cmp    eax,0x3fc
    12a7:	ja     0x12fd
    12ad:	movq   xmm0,xmm0
    12b1:	movq   xmm1,xmm1
    12b5:	stmxcsr DWORD PTR [rsp+0x100]
    12bd:	mov    DWORD PTR [rsp+0x104],0x1f80
    12c8:	ldmxcsr DWORD PTR [rsp+0x104]
    12d0:	addsd  xmm0,xmm1
    12d4:	stmxcsr DWORD PTR [rsp+0x104]
    12dc:	ldmxcsr DWORD PTR [rsp+0x100]
    12e4:	mov    eax,DWORD PTR [rsp+0x104]
    12eb:	shr    eax,1
    12ed:	and    eax,0x10
    12f0:	or     DWORD PTR [r12+0x314],eax
    12f8:	jmp    0x13aa
    12fd:	movdqa xmm0,xmm2
    1301:	movdqa xmm1,xmm4
    1305:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    130e:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1317:	mov    QWORD PTR [r12+0x378],0x3
    1323:	movdqu XMMWORD PTR [rsp],xmm2
    1328:	movdqu XMMWORD PTR [rsp+0x20],xmm4
    132e:	mov    QWORD PTR [r12+0x108],rbx
    1336:	stmxcsr DWORD PTR [r12-0x28]
    133c:	ldmxcsr DWORD PTR [r12-0x38]
    1342:	lea    rdi,[rsp+0xf0]
    134a:	lea    rsi,[rsp+0xd0]
    1352:	lea    rdx,[rsp+0xe0]
    135a:	mov    ecx,0xc
    135f:	mov    r8d,DWORD PTR [r12+0x310]
    1367:	lea    r9,[r12+0x314]
    136f:	movabs r11,0x62fb535e8750
    1379:	call   r11
    137c:	ldmxcsr DWORD PTR [r12-0x28]
    1382:	movdqu xmm2,XMMWORD PTR [rsp]
    1387:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
    138d:	mov    rbx,QWORD PTR [r12+0x108]
    1395:	mov    QWORD PTR [r12+0x378],0x2
    13a1:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    13aa:	movdqa xmm3,xmm0
    13ae:	movdqa xmm0,xmm3
    13b2:	movdqu XMMWORD PTR [r12+0x220],xmm0
    13bc:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    13c6:	movdqa xmm2,xmm0
    13ca:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    13d4:	movdqa xmm3,xmm0
    13d8:	cmp    DWORD PTR [r12+0x310],0x0
    13e1:	jne    0x147b
    13e7:	movdqa xmm0,xmm2
    13eb:	movdqa xmm1,xmm3
    13ef:	movq   rax,xmm0
    13f4:	add    rax,rax
    13f7:	je     0x140d
    13f9:	shr    rax,0x35
    13fd:	sub    eax,0x201
    1402:	cmp    eax,0x3fc
    1407:	ja     0x147b
    140d:	movq   rax,xmm1
    1412:	add    rax,rax
    1415:	je     0x142b
    1417:	shr    rax,0x35
    141b:	sub    eax,0x201
    1420:	cmp    eax,0x3fc
    1425:	ja     0x147b
    142b:	movq   xmm0,xmm0
    142f:	movq   xmm1,xmm1
    1433:	stmxcsr DWORD PTR [rsp+0x100]
    143b:	mov    DWORD PTR [rsp+0x104],0x1f80
    1446:	ldmxcsr DWORD PTR [rsp+0x104]
    144e:	mulsd  xmm0,xmm1
    1452:	stmxcsr DWORD PTR [rsp+0x104]
    145a:	ldmxcsr DWORD PTR [rsp+0x100]
    1462:	mov    eax,DWORD PTR [rsp+0x104]
    1469:	shr    eax,1
    146b:	and    eax,0x10
    146e:	or     DWORD PTR [r12+0x314],eax
    1476:	jmp    0x1528
    147b:	movdqa xmm0,xmm2
    147f:	movdqa xmm1,xmm3
    1483:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    148c:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1495:	mov    QWORD PTR [r12+0x378],0x3
    14a1:	movdqu XMMWORD PTR [rsp],xmm2
    14a6:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    14ac:	mov    QWORD PTR [r12+0x108],rbx
    14b4:	stmxcsr DWORD PTR [r12-0x28]
    14ba:	ldmxcsr DWORD PTR [r12-0x38]
    14c0:	lea    rdi,[rsp+0xf0]
    14c8:	lea    rsi,[rsp+0xd0]
    14d0:	lea    rdx,[rsp+0xe0]
    14d8:	mov    ecx,0xe
    14dd:	mov    r8d,DWORD PTR [r12+0x310]
    14e5:	lea    r9,[r12+0x314]
    14ed:	movabs r11,0x62fb535e8750
    14f7:	call   r11
    14fa:	ldmxcsr DWORD PTR [r12-0x28]
    1500:	movdqu xmm2,XMMWORD PTR [rsp]
    1505:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    150b:	mov    rbx,QWORD PTR [r12+0x108]
    1513:	mov    QWORD PTR [r12+0x378],0x2
    151f:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1528:	movdqa xmm4,xmm0
    152c:	movdqa xmm0,xmm4
    1530:	movdqu XMMWORD PTR [r12+0x230],xmm0
    153a:	mov    r13,QWORD PTR [r12+0x78]
    153f:	mov    r14,r13
    1542:	add    r14,0x180
    1549:	mov    r13,QWORD PTR [r14]
    154c:	mov    r14d,0x0
    1552:	mov    QWORD PTR [r12+0x240],r13
    155a:	mov    QWORD PTR [r12+0x248],r14
    1562:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    156c:	movdqa xmm2,xmm0
    1570:	cmp    DWORD PTR [r12+0x310],0x0
    1579:	jne    0x1613
    157f:	movdqa xmm0,xmm2
    1583:	movdqa xmm1,xmm4
    1587:	movq   rax,xmm0
    158c:	add    rax,rax
    158f:	je     0x15a5
    1591:	shr    rax,0x35
    1595:	sub    eax,0x201
    159a:	cmp    eax,0x3fc
    159f:	ja     0x1613
    15a5:	movq   rax,xmm1
    15aa:	add    rax,rax
    15ad:	je     0x15c3
    15af:	shr    rax,0x35
    15b3:	sub    eax,0x201
    15b8:	cmp    eax,0x3fc
    15bd:	ja     0x1613
    15c3:	movq   xmm0,xmm0
    15c7:	movq   xmm1,xmm1
    15cb:	stmxcsr DWORD PTR [rsp+0x100]
    15d3:	mov    DWORD PTR [rsp+0x104],0x1f80
    15de:	ldmxcsr DWORD PTR [rsp+0x104]
    15e6:	addsd  xmm0,xmm1
    15ea:	stmxcsr DWORD PTR [rsp+0x104]
    15f2:	ldmxcsr DWORD PTR [rsp+0x100]
    15fa:	mov    eax,DWORD PTR [rsp+0x104]
    1601:	shr    eax,1
    1603:	and    eax,0x10
    1606:	or     DWORD PTR [r12+0x314],eax
    160e:	jmp    0x16c0
    1613:	movdqa xmm0,xmm2
    1617:	movdqa xmm1,xmm4
    161b:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1624:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    162d:	mov    QWORD PTR [r12+0x378],0x3
    1639:	movdqu XMMWORD PTR [rsp],xmm2
    163e:	movdqu XMMWORD PTR [rsp+0x20],xmm4
    1644:	mov    QWORD PTR [r12+0x108],rbx
    164c:	stmxcsr DWORD PTR [r12-0x28]
    1652:	ldmxcsr DWORD PTR [r12-0x38]
    1658:	lea    rdi,[rsp+0xf0]
    1660:	lea    rsi,[rsp+0xd0]
    1668:	lea    rdx,[rsp+0xe0]
    1670:	mov    ecx,0xc
    1675:	mov    r8d,DWORD PTR [r12+0x310]
    167d:	lea    r9,[r12+0x314]
    1685:	movabs r11,0x62fb535e8750
    168f:	call   r11
    1692:	ldmxcsr DWORD PTR [r12-0x28]
    1698:	movdqu xmm2,XMMWORD PTR [rsp]
    169d:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
    16a3:	mov    rbx,QWORD PTR [r12+0x108]
    16ab:	mov    QWORD PTR [r12+0x378],0x2
    16b7:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    16c0:	movdqa xmm3,xmm0
    16c4:	movdqa xmm0,xmm3
    16c8:	movdqu XMMWORD PTR [r12+0x220],xmm0
    16d2:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    16dc:	movdqa xmm2,xmm0
    16e0:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    16ea:	movdqa xmm3,xmm0
    16ee:	cmp    DWORD PTR [r12+0x310],0x0
    16f7:	jne    0x1791
    16fd:	movdqa xmm0,xmm2
    1701:	movdqa xmm1,xmm3
    1705:	movq   rax,xmm0
    170a:	add    rax,rax
    170d:	je     0x1723
    170f:	shr    rax,0x35
    1713:	sub    eax,0x201
    1718:	cmp    eax,0x3fc
    171d:	ja     0x1791
    1723:	movq   rax,xmm1
    1728:	add    rax,rax
    172b:	je     0x1741
    172d:	shr    rax,0x35
    1731:	sub    eax,0x201
    1736:	cmp    eax,0x3fc
    173b:	ja     0x1791
    1741:	movq   xmm0,xmm0
    1745:	movq   xmm1,xmm1
    1749:	stmxcsr DWORD PTR [rsp+0x100]
    1751:	mov    DWORD PTR [rsp+0x104],0x1f80
    175c:	ldmxcsr DWORD PTR [rsp+0x104]
    1764:	mulsd  xmm0,xmm1
    1768:	stmxcsr DWORD PTR [rsp+0x104]
    1770:	ldmxcsr DWORD PTR [rsp+0x100]
    1778:	mov    eax,DWORD PTR [rsp+0x104]
    177f:	shr    eax,1
    1781:	and    eax,0x10
    1784:	or     DWORD PTR [r12+0x314],eax
    178c:	jmp    0x183e
    1791:	movdqa xmm0,xmm2
    1795:	movdqa xmm1,xmm3
    1799:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    17a2:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    17ab:	mov    QWORD PTR [r12+0x378],0x3
    17b7:	movdqu XMMWORD PTR [rsp],xmm2
    17bc:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    17c2:	mov    QWORD PTR [r12+0x108],rbx
    17ca:	stmxcsr DWORD PTR [r12-0x28]
    17d0:	ldmxcsr DWORD PTR [r12-0x38]
    17d6:	lea    rdi,[rsp+0xf0]
    17de:	lea    rsi,[rsp+0xd0]
    17e6:	lea    rdx,[rsp+0xe0]
    17ee:	mov    ecx,0xe
    17f3:	mov    r8d,DWORD PTR [r12+0x310]
    17fb:	lea    r9,[r12+0x314]
    1803:	movabs r11,0x62fb535e8750
    180d:	call   r11
    1810:	ldmxcsr DWORD PTR [r12-0x28]
    1816:	movdqu xmm2,XMMWORD PTR [rsp]
    181b:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1821:	mov    rbx,QWORD PTR [r12+0x108]
    1829:	mov    QWORD PTR [r12+0x378],0x2
    1835:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    183e:	movdqa xmm4,xmm0
    1842:	movdqa xmm0,xmm4
    1846:	movdqu XMMWORD PTR [r12+0x230],xmm0
    1850:	mov    r13,QWORD PTR [r12+0x78]
    1855:	mov    r14,r13
    1858:	add    r14,0x1c0
    185f:	mov    r13,QWORD PTR [r14]
    1862:	mov    r14d,0x0
    1868:	mov    QWORD PTR [r12+0x240],r13
    1870:	mov    QWORD PTR [r12+0x248],r14
    1878:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1882:	movdqa xmm2,xmm0
    1886:	cmp    DWORD PTR [r12+0x310],0x0
    188f:	jne    0x1929
    1895:	movdqa xmm0,xmm2
    1899:	movdqa xmm1,xmm4
    189d:	movq   rax,xmm0
    18a2:	add    rax,rax
    18a5:	je     0x18bb
    18a7:	shr    rax,0x35
    18ab:	sub    eax,0x201
    18b0:	cmp    eax,0x3fc
    18b5:	ja     0x1929
    18bb:	movq   rax,xmm1
    18c0:	add    rax,rax
    18c3:	je     0x18d9
    18c5:	shr    rax,0x35
    18c9:	sub    eax,0x201
    18ce:	cmp    eax,0x3fc
    18d3:	ja     0x1929
    18d9:	movq   xmm0,xmm0
    18dd:	movq   xmm1,xmm1
    18e1:	stmxcsr DWORD PTR [rsp+0x100]
    18e9:	mov    DWORD PTR [rsp+0x104],0x1f80
    18f4:	ldmxcsr DWORD PTR [rsp+0x104]
    18fc:	addsd  xmm0,xmm1
    1900:	stmxcsr DWORD PTR [rsp+0x104]
    1908:	ldmxcsr DWORD PTR [rsp+0x100]
    1910:	mov    eax,DWORD PTR [rsp+0x104]
    1917:	shr    eax,1
    1919:	and    eax,0x10
    191c:	or     DWORD PTR [r12+0x314],eax
    1924:	jmp    0x19d6
    1929:	movdqa xmm0,xmm2
    192d:	movdqa xmm1,xmm4
    1931:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    193a:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1943:	mov    QWORD PTR [r12+0x378],0x3
    194f:	movdqu XMMWORD PTR [rsp],xmm2
    1954:	movdqu XMMWORD PTR [rsp+0x20],xmm4
    195a:	mov    QWORD PTR [r12+0x108],rbx
    1962:	stmxcsr DWORD PTR [r12-0x28]
    1968:	ldmxcsr DWORD PTR [r12-0x38]
    196e:	lea    rdi,[rsp+0xf0]
    1976:	lea    rsi,[rsp+0xd0]
    197e:	lea    rdx,[rsp+0xe0]
    1986:	mov    ecx,0xc
    198b:	mov    r8d,DWORD PTR [r12+0x310]
    1993:	lea    r9,[r12+0x314]
    199b:	movabs r11,0x62fb535e8750
    19a5:	call   r11
    19a8:	ldmxcsr DWORD PTR [r12-0x28]
    19ae:	movdqu xmm2,XMMWORD PTR [rsp]
    19b3:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
    19b9:	mov    rbx,QWORD PTR [r12+0x108]
    19c1:	mov    QWORD PTR [r12+0x378],0x2
    19cd:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    19d6:	movdqa xmm3,xmm0
    19da:	movdqa xmm0,xmm3
    19de:	movdqu XMMWORD PTR [r12+0x220],xmm0
    19e8:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    19f2:	movdqa xmm2,xmm0
    19f6:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1a00:	movdqa xmm3,xmm0
    1a04:	cmp    DWORD PTR [r12+0x310],0x0
    1a0d:	jne    0x1aa7
    1a13:	movdqa xmm0,xmm2
    1a17:	movdqa xmm1,xmm3
    1a1b:	movq   rax,xmm0
    1a20:	add    rax,rax
    1a23:	je     0x1a39
    1a25:	shr    rax,0x35
    1a29:	sub    eax,0x201
    1a2e:	cmp    eax,0x3fc
    1a33:	ja     0x1aa7
    1a39:	movq   rax,xmm1
    1a3e:	add    rax,rax
    1a41:	je     0x1a57
    1a43:	shr    rax,0x35
    1a47:	sub    eax,0x201
    1a4c:	cmp    eax,0x3fc
    1a51:	ja     0x1aa7
    1a57:	movq   xmm0,xmm0
    1a5b:	movq   xmm1,xmm1
    1a5f:	stmxcsr DWORD PTR [rsp+0x100]
    1a67:	mov    DWORD PTR [rsp+0x104],0x1f80
    1a72:	ldmxcsr DWORD PTR [rsp+0x104]
    1a7a:	mulsd  xmm0,xmm1
    1a7e:	stmxcsr DWORD PTR [rsp+0x104]
    1a86:	ldmxcsr DWORD PTR [rsp+0x100]
    1a8e:	mov    eax,DWORD PTR [rsp+0x104]
    1a95:	shr    eax,1
    1a97:	and    eax,0x10
    1a9a:	or     DWORD PTR [r12+0x314],eax
    1aa2:	jmp    0x1b54
    1aa7:	movdqa xmm0,xmm2
    1aab:	movdqa xmm1,xmm3
    1aaf:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1ab8:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1ac1:	mov    QWORD PTR [r12+0x378],0x3
    1acd:	movdqu XMMWORD PTR [rsp],xmm2
    1ad2:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    1ad8:	mov    QWORD PTR [r12+0x108],rbx
    1ae0:	stmxcsr DWORD PTR [r12-0x28]
    1ae6:	ldmxcsr DWORD PTR [r12-0x38]
    1aec:	lea    rdi,[rsp+0xf0]
    1af4:	lea    rsi,[rsp+0xd0]
    1afc:	lea    rdx,[rsp+0xe0]
    1b04:	mov    ecx,0xe
    1b09:	mov    r8d,DWORD PTR [r12+0x310]
    1b11:	lea    r9,[r12+0x314]
    1b19:	movabs r11,0x62fb535e8750
    1b23:	call   r11
    1b26:	ldmxcsr DWORD PTR [r12-0x28]
    1b2c:	movdqu xmm2,XMMWORD PTR [rsp]
    1b31:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    1b37:	mov    rbx,QWORD PTR [r12+0x108]
    1b3f:	mov    QWORD PTR [r12+0x378],0x2
    1b4b:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1b54:	movdqa xmm4,xmm0
    1b58:	movdqa xmm0,xmm4
    1b5c:	movdqu XMMWORD PTR [r12+0x230],xmm0
    1b66:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1b70:	movdqa xmm2,xmm0
    1b74:	cmp    DWORD PTR [r12+0x310],0x0
    1b7d:	jne    0x1c17
    1b83:	movdqa xmm0,xmm2
    1b87:	movdqa xmm1,xmm4
    1b8b:	movq   rax,xmm0
    1b90:	add    rax,rax
    1b93:	je     0x1ba9
    1b95:	shr    rax,0x35
    1b99:	sub    eax,0x201
    1b9e:	cmp    eax,0x3fc
    1ba3:	ja     0x1c17
    1ba9:	movq   rax,xmm1
    1bae:	add    rax,rax
    1bb1:	je     0x1bc7
    1bb3:	shr    rax,0x35
    1bb7:	sub    eax,0x201
    1bbc:	cmp    eax,0x3fc
    1bc1:	ja     0x1c17
    1bc7:	movq   xmm0,xmm0
    1bcb:	movq   xmm1,xmm1
    1bcf:	stmxcsr DWORD PTR [rsp+0x100]
    1bd7:	mov    DWORD PTR [rsp+0x104],0x1f80
    1be2:	ldmxcsr DWORD PTR [rsp+0x104]
    1bea:	addsd  xmm0,xmm1
    1bee:	stmxcsr DWORD PTR [rsp+0x104]
    1bf6:	ldmxcsr DWORD PTR [rsp+0x100]
    1bfe:	mov    eax,DWORD PTR [rsp+0x104]
    1c05:	shr    eax,1
    1c07:	and    eax,0x10
    1c0a:	or     DWORD PTR [r12+0x314],eax
    1c12:	jmp    0x1cc4
    1c17:	movdqa xmm0,xmm2
    1c1b:	movdqa xmm1,xmm4
    1c1f:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    1c28:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    1c31:	mov    QWORD PTR [r12+0x378],0x3
    1c3d:	movdqu XMMWORD PTR [rsp],xmm2
    1c42:	movdqu XMMWORD PTR [rsp+0x20],xmm4
    1c48:	mov    QWORD PTR [r12+0x108],rbx
    1c50:	stmxcsr DWORD PTR [r12-0x28]
    1c56:	ldmxcsr DWORD PTR [r12-0x38]
    1c5c:	lea    rdi,[rsp+0xf0]
    1c64:	lea    rsi,[rsp+0xd0]
    1c6c:	lea    rdx,[rsp+0xe0]
    1c74:	mov    ecx,0xc
    1c79:	mov    r8d,DWORD PTR [r12+0x310]
    1c81:	lea    r9,[r12+0x314]
    1c89:	movabs r11,0x62fb535e8750
    1c93:	call   r11
    1c96:	ldmxcsr DWORD PTR [r12-0x28]
    1c9c:	movdqu xmm2,XMMWORD PTR [rsp]
    1ca1:	movdqu xmm4,XMMWORD PTR [rsp+0x20]
    1ca7:	mov    rbx,QWORD PTR [r12+0x108]
    1caf:	mov    QWORD PTR [r12+0x378],0x2
    1cbb:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    1cc4:	movdqa xmm3,xmm0
    1cc8:	movdqa xmm0,xmm3
    1ccc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    1cd6:	mov    r13,QWORD PTR [r12+0x70]
    1cdb:	mov    r14,QWORD PTR [r12+0x68]
    1ce0:	mov    rcx,r13
    1ce3:	mov    r15,r14
    1ce6:	add    r15,rcx
    1ce9:	mov    r14,QWORD PTR [r12+0x220]
    1cf1:	mov    QWORD PTR [r15],r14
    1cf4:	mov    r14d,0x0
    1cfa:	mov    DWORD PTR [r12+0x32c],r14d
    1d02:	mov    r14,r13
    1d05:	add    r14,0x8
    1d09:	mov    QWORD PTR [r12+0x70],r14
    1d0e:	mov    r13,r14
    1d11:	sub    r13,0x40
    1d15:	pushf
    1d16:	pop    rdx
    1d17:	mov    r10d,edx
    1d1a:	and    r10d,0xc0
    1d21:	shl    r10d,0x18
    1d25:	mov    r11d,edx
    1d28:	and    r11d,0x1
    1d2c:	shl    r11d,0x1d
    1d30:	or     r10d,r11d
    1d33:	mov    r11d,edx
    1d36:	and    r11d,0x800
    1d3d:	shl    r11d,0x11
    1d41:	or     r10d,r11d
    1d44:	mov    r11d,0xf0000000
    1d4a:	and    r11,r10
    1d4d:	movabs rsi,0xffffffff0fffffff
    1d57:	and    rbx,rsi
    1d5a:	or     rbx,r11
    1d5d:	btc    rbx,0x1d
    1d62:	cmp    QWORD PTR [r12+0x380],0x0
    1d6b:	je     0x1d9f
    1d71:	mov    eax,0x410114
    1d76:	mov    QWORD PTR [r12+0x100],rax
    1d7e:	mov    QWORD PTR [r12+0x108],rbx
    1d86:	add    rsp,0x140
    1d8d:	mov    eax,0xc
    1d92:	movabs r11,0x62fb5377c5f0
    1d9c:	jmp    r11
    1d9f:	test   ebx,0x40000000
    1da5:	je     0x41a
    1dab:	jmp    0x1db0
    1db0:	mov    r13,QWORD PTR [r12+0x60]
    1db5:	mov    r14,r13
    1db8:	add    r14,0x1
    1dbc:	mov    QWORD PTR [r12+0x60],r14
    1dc1:	mov    r13,QWORD PTR [r12+0x68]
    1dc6:	mov    r15,r13
    1dc9:	add    r15,0x40
    1dcd:	mov    QWORD PTR [r12+0x68],r15
    1dd2:	mov    r13,r14
    1dd5:	sub    r13,0x8
    1dd9:	pushf
    1dda:	pop    rdx
    1ddb:	mov    r10d,edx
    1dde:	and    r10d,0xc0
    1de5:	shl    r10d,0x18
    1de9:	mov    r11d,edx
    1dec:	and    r11d,0x1
    1df0:	shl    r11d,0x1d
    1df4:	or     r10d,r11d
    1df7:	mov    r11d,edx
    1dfa:	and    r11d,0x800
    1e01:	shl    r11d,0x11
    1e05:	or     r10d,r11d
    1e08:	mov    r11d,0xf0000000
    1e0e:	and    r11,r10
    1e11:	movabs rsi,0xffffffff0fffffff
    1e1b:	and    rbx,rsi
    1e1e:	or     rbx,r11
    1e21:	btc    rbx,0x1d
    1e26:	cmp    QWORD PTR [r12+0x380],0x0
    1e2f:	je     0x1e63
    1e35:	mov    eax,0x410124
    1e3a:	mov    QWORD PTR [r12+0x100],rax
    1e42:	mov    QWORD PTR [r12+0x108],rbx
    1e4a:	add    rsp,0x140
    1e51:	mov    eax,0xc
    1e56:	movabs r11,0x62fb5377c5f0
    1e60:	jmp    r11
    1e63:	test   ebx,0x40000000
    1e69:	je     0x2ea
    1e6f:	jmp    0x1e74
    1e74:	mov    r13d,DWORD PTR [r12+0x58]
    1e79:	mov    r14d,r13d
    1e7c:	add    r14d,0x1
    1e80:	mov    QWORD PTR [r12+0x58],r14
    1e85:	mov    r13d,r14d
    1e88:	sub    r13d,0x1f4
    1e8f:	pushf
    1e90:	pop    rdx
    1e91:	mov    r10d,edx
    1e94:	and    r10d,0xc0
    1e9b:	shl    r10d,0x18
    1e9f:	mov    r11d,edx
    1ea2:	and    r11d,0x1
    1ea6:	shl    r11d,0x1d
    1eaa:	or     r10d,r11d
    1ead:	mov    r11d,edx
    1eb0:	and    r11d,0x800
    1eb7:	shl    r11d,0x11
    1ebb:	or     r10d,r11d
    1ebe:	mov    r11d,0xf0000000
    1ec4:	and    r11,r10
    1ec7:	movabs rsi,0xffffffff0fffffff
    1ed1:	and    rbx,rsi
    1ed4:	or     rbx,r11
    1ed7:	btc    rbx,0x1d
    1edc:	cmp    QWORD PTR [r12+0x380],0x0
    1ee5:	je     0x1f19
    1eeb:	mov    eax,0x410130
    1ef0:	mov    QWORD PTR [r12+0x100],rax
    1ef8:	mov    QWORD PTR [r12+0x108],rbx
    1f00:	add    rsp,0x140
    1f07:	mov    eax,0xc
    1f0c:	movabs r11,0x62fb5377c5f0
    1f16:	jmp    r11
    1f19:	test   ebx,0x40000000
    1f1f:	je     0x2c1
    1f25:	jmp    0x1f2a
    1f2a:	mov    r13d,0x420000
    1f30:	mov    QWORD PTR [r12+0x40],r13
    1f35:	mov    r13d,0x0
    1f3b:	mov    QWORD PTR [r12+0x48],r13
    1f40:	mov    r13d,0x4201b8
    1f46:	mov    r14,QWORD PTR [r13+0x0]
    1f4a:	mov    r13d,0x0
    1f50:	mov    QWORD PTR [r12+0x110],r14
    1f58:	mov    QWORD PTR [r12+0x118],r13
    1f60:	jmp    0x1f65
    1f65:	mov    r13,QWORD PTR [r12+0x48]
    1f6a:	mov    r14,QWORD PTR [r12+0x50]
    1f6f:	mov    rcx,r13
    1f72:	mov    r15,r14
    1f75:	add    r15,rcx
    1f78:	mov    r14,QWORD PTR [r15]
    1f7b:	mov    r15d,0x0
    1f81:	mov    QWORD PTR [r12+0x120],r14
    1f89:	mov    QWORD PTR [r12+0x128],r15
    1f91:	mov    r14,r13
    1f94:	add    r14,0x8
    1f98:	mov    QWORD PTR [r12+0x48],r14
    1f9d:	mov    r13,r14
    1fa0:	sub    r13,0x200
    1fa7:	pushf
    1fa8:	pop    rdx
    1fa9:	mov    r10d,edx
    1fac:	and    r10d,0xc0
    1fb3:	shl    r10d,0x18
    1fb7:	mov    r11d,edx
    1fba:	and    r11d,0x1
    1fbe:	shl    r11d,0x1d
    1fc2:	or     r10d,r11d
    1fc5:	mov    r11d,edx
    1fc8:	and    r11d,0x800
    1fcf:	shl    r11d,0x11
    1fd3:	or     r10d,r11d
    1fd6:	mov    r11d,0xf0000000
    1fdc:	and    r11,r10
    1fdf:	movabs rsi,0xffffffff0fffffff
    1fe9:	and    rbx,rsi
    1fec:	or     rbx,r11
    1fef:	btc    rbx,0x1d
    1ff4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    1ffe:	movdqa xmm2,xmm0
    2002:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    200c:	movdqa xmm3,xmm0
    2010:	cmp    DWORD PTR [r12+0x310],0x0
    2019:	jne    0x20b3
    201f:	movdqa xmm0,xmm2
    2023:	movdqa xmm1,xmm3
    2027:	movq   rax,xmm0
    202c:	add    rax,rax
    202f:	je     0x2045
    2031:	shr    rax,0x35
    2035:	sub    eax,0x201
    203a:	cmp    eax,0x3fc
    203f:	ja     0x20b3
    2045:	movq   rax,xmm1
    204a:	add    rax,rax
    204d:	je     0x2063
    204f:	shr    rax,0x35
    2053:	sub    eax,0x201
    2058:	cmp    eax,0x3fc
    205d:	ja     0x20b3
    2063:	movq   xmm0,xmm0
    2067:	movq   xmm1,xmm1
    206b:	stmxcsr DWORD PTR [rsp+0x100]
    2073:	mov    DWORD PTR [rsp+0x104],0x1f80
    207e:	ldmxcsr DWORD PTR [rsp+0x104]
    2086:	addsd  xmm0,xmm1
    208a:	stmxcsr DWORD PTR [rsp+0x104]
    2092:	ldmxcsr DWORD PTR [rsp+0x100]
    209a:	mov    eax,DWORD PTR [rsp+0x104]
    20a1:	shr    eax,1
    20a3:	and    eax,0x10
    20a6:	or     DWORD PTR [r12+0x314],eax
    20ae:	jmp    0x2160
    20b3:	movdqa xmm0,xmm2
    20b7:	movdqa xmm1,xmm3
    20bb:	movdqu XMMWORD PTR [rsp+0xd0],xmm0
    20c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm1
    20cd:	mov    QWORD PTR [r12+0x378],0x3
    20d9:	movdqu XMMWORD PTR [rsp],xmm2
    20de:	movdqu XMMWORD PTR [rsp+0x10],xmm3
    20e4:	mov    QWORD PTR [r12+0x108],rbx
    20ec:	stmxcsr DWORD PTR [r12-0x28]
    20f2:	ldmxcsr DWORD PTR [r12-0x38]
    20f8:	lea    rdi,[rsp+0xf0]
    2100:	lea    rsi,[rsp+0xd0]
    2108:	lea    rdx,[rsp+0xe0]
    2110:	mov    ecx,0xc
    2115:	mov    r8d,DWORD PTR [r12+0x310]
    211d:	lea    r9,[r12+0x314]
    2125:	movabs r11,0x62fb535e8750
    212f:	call   r11
    2132:	ldmxcsr DWORD PTR [r12-0x28]
    2138:	movdqu xmm2,XMMWORD PTR [rsp]
    213d:	movdqu xmm3,XMMWORD PTR [rsp+0x10]
    2143:	mov    rbx,QWORD PTR [r12+0x108]
    214b:	mov    QWORD PTR [r12+0x378],0x2
    2157:	movdqu xmm0,XMMWORD PTR [rsp+0xf0]
    2160:	movdqa xmm4,xmm0
    2164:	movdqa xmm0,xmm4
    2168:	movdqu XMMWORD PTR [r12+0x110],xmm0
    2172:	cmp    QWORD PTR [r12+0x380],0x0
    217b:	je     0x21af
    2181:	mov    eax,0x410150
    2186:	mov    QWORD PTR [r12+0x100],rax
    218e:	mov    QWORD PTR [r12+0x108],rbx
    2196:	add    rsp,0x140
    219d:	mov    eax,0xc
    21a2:	movabs r11,0x62fb5377c5f0
    21ac:	jmp    r11
    21af:	test   ebx,0x40000000
    21b5:	je     0x1f65
    21bb:	jmp    0x21c0
    21c0:	mov    r13,QWORD PTR [r12+0x40]
    21c5:	mov    r14,r13
    21c8:	add    r14,0x1b8
    21cf:	mov    r13,QWORD PTR [r12+0x110]
    21d7:	mov    QWORD PTR [r14],r13
    21da:	mov    r13d,0x0
    21e0:	mov    DWORD PTR [r12+0x32c],r13d
    21e8:	cmp    QWORD PTR [r12+0x380],0x0
    21f1:	je     0x2225
    21f7:	mov    eax,0x410158
    21fc:	mov    QWORD PTR [r12+0x100],rax
    2204:	mov    QWORD PTR [r12+0x108],rbx
    220c:	add    rsp,0x140
    2213:	mov    eax,0xc
    2218:	movabs r11,0x62fb5377c5f0
    2222:	jmp    r11
    2225:	mov    r13,QWORD PTR [r12+0xf0]
    222d:	mov    QWORD PTR [r12+0x100],r13
    2235:	mov    QWORD PTR [r12+0x108],rbx
    223d:	mov    rdi,QWORD PTR [r12+0x100]
    2245:	add    rsp,0x140
    224c:	movabs r11,0x62fb5377c370
    2256:	jmp    r11
    2259:	nop    DWORD PTR [rax+0x0]
    2260:	sub    rsp,0x140
    2267:	jmp    0x62
    226c:	nop    DWORD PTR [rax+0x0]
    2270:	sub    rsp,0x140
    2277:	jmp    0x275
    227c:	nop    DWORD PTR [rax+0x0]
    2280:	sub    rsp,0x140
    2287:	jmp    0x2c1
    228c:	nop    DWORD PTR [rax+0x0]
    2290:	sub    rsp,0x140
    2297:	jmp    0x2ea
    229c:	nop    DWORD PTR [rax+0x0]
    22a0:	sub    rsp,0x140
    22a7:	jmp    0x41a
    22ac:	nop    DWORD PTR [rax+0x0]
    22b0:	sub    rsp,0x140
    22b7:	jmp    0x1db0
    22bc:	nop    DWORD PTR [rax+0x0]
    22c0:	sub    rsp,0x140
    22c7:	jmp    0x1e74
    22cc:	nop    DWORD PTR [rax+0x0]
    22d0:	sub    rsp,0x140
    22d7:	jmp    0x1f2a
    22dc:	nop    DWORD PTR [rax+0x0]
    22e0:	sub    rsp,0x140
    22e7:	jmp    0x1f65
    22ec:	nop    DWORD PTR [rax+0x0]
    22f0:	sub    rsp,0x140
    22f7:	jmp    0x21c0
