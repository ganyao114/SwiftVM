00007b6e1c3ce69b  nop [rax+rax*1], eax
00007b6e1c3ce6a0  mov qword ptr [r15+0x40], 0x4201C0
00007b6e1c3ce6a8  mov qword ptr [r15+0x48], 0x4203C0
00007b6e1c3ce6b0  mov qword ptr [r15+0x60], 0x01
00007b6e1c3ce6b8  xorps xmm1, xmm1
00007b6e1c3ce6bb  mov eax, 0x41
00007b6e1c3ce6c0  vcvtusi2sd xmm1, xmm1, eax
00007b6e1c3ce6c6  mulsd xmm1, [0x00007B6E1BFFE010]
00007b6e1c3ce6ce  movq xmm1, xmm1
00007b6e1c3ce6d2  movaps [r15+0x120], xmm1
00007b6e1c3ce6da  mov eax, [r15+0x60]
00007b6e1c3ce6de  xorps xmm15, xmm15
00007b6e1c3ce6e2  vcvtusi2sd xmm15, xmm15, eax
00007b6e1c3ce6e8  mulsd xmm15, [0x00007B6E1BFFE020]
00007b6e1c3ce6f1  movq xmm15, xmm15
00007b6e1c3ce6f6  movaps [r15+0x110], xmm15
00007b6e1c3ce6fe  mov rax, [r15+0x60]
00007b6e1c3ce702  mov [rsp+0x10], rax
00007b6e1c3ce707  xor eax, eax
00007b6e1c3ce709  mov r14, [rsp+0x10]
00007b6e1c3ce70e  mov r12d, 0x40
00007b6e1c3ce714  cmp r14, r12
00007b6e1c3ce717  cmc
00007b6e1c3ce718  lahf
00007b6e1c3ce719  seto al
00007b6e1c3ce71c  mov [r15+0x108], eax
00007b6e1c3ce723  mov qword ptr [r15+0x50], 0x40
00007b6e1c3ce72b  movq rax, xmm1
00007b6e1c3ce730  mov r12d, 0x4203C0
00007b6e1c3ce736  mov [r13+r12*1], rax
00007b6e1c3ce73b  movq rax, xmm15
00007b6e1c3ce740  mov r12d, 0x4201C0
00007b6e1c3ce746  mov [r13+r12*1], rax
00007b6e1c3ce74b  mov [r15+0x58], r14
00007b6e1c3ce74f  mov eax, [r15+0x108]
00007b6e1c3ce756  sahf
00007b6e1c3ce757  jnz 0x00007B6E1C3CE789
00007b6e1c3ce759  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3ce761  jz 0x00007B6E1C3CE910
00007b6e1c3ce767  nop [rax+rax*1], ax
00007b6e1c3ce770  nop [rax+rax*1], eax
00007b6e1c3ce778  mov eax, 0x410074
00007b6e1c3ce77d  mov [r15+0x100], rax
00007b6e1c3ce784  jmp 0x00007B6E1C1FE110
00007b6e1c3ce789  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3ce791  jz 0x00007B6E1C3CE7D0
00007b6e1c3ce797  nop [rax+rax*1], ax
00007b6e1c3ce7a0  nop [rax+rax*1], eax
00007b6e1c3ce7a8  mov eax, 0x41004C
00007b6e1c3ce7ad  mov [r15+0x100], rax
00007b6e1c3ce7b4  jmp 0x00007B6E1C1FE110
00007b6e1c3ce7b9  int3
00007b6e1c3ce7ba  call 0x00007B6E1C2B4CB0
00007b6e1c3ce7bf  jmp 0x00007B6E1C3CE73B
00007b6e1c3ce7c4  call 0x00007B6E1C2B4CB0
00007b6e1c3ce7c9  jmp 0x00007B6E1C3CE74B
00007b6e1c3ce7ce  int3
00007b6e1c3ce7cf  nop
00007b6e1c3ce7d0  mov rax, [r15+0x58]
00007b6e1c3ce7d4  lea r14, [rax+0x01]
00007b6e1c3ce7d8  mov [r15+0x60], r14
00007b6e1c3ce7dc  mov r14d, [r15+0x50]
00007b6e1c3ce7e0  xorps xmm1, xmm1
00007b6e1c3ce7e3  vcvtusi2sd xmm1, xmm1, r14d
00007b6e1c3ce7e9  mulsd xmm1, [0x00007B6E1BFFE010]
00007b6e1c3ce7f1  movq xmm1, xmm1
00007b6e1c3ce7f5  movaps [r15+0x120], xmm1
00007b6e1c3ce7fd  rorx r12, rax, 0x3D
00007b6e1c3ce803  and r12, 0xFFFFFFFFFFFFFFF8
00007b6e1c3ce807  mov eax, [r15+0x60]
00007b6e1c3ce80b  xorps xmm15, xmm15
00007b6e1c3ce80f  vcvtusi2sd xmm15, xmm15, eax
00007b6e1c3ce815  mulsd xmm15, [0x00007B6E1BFFE020]
00007b6e1c3ce81e  movq xmm15, xmm15
00007b6e1c3ce823  movaps [r15+0x110], xmm15
00007b6e1c3ce82b  mov rax, [r15+0x60]
00007b6e1c3ce82f  mov [rsp+0x10], rax
00007b6e1c3ce834  xor eax, eax
00007b6e1c3ce836  mov r11, [rsp+0x10]
00007b6e1c3ce83b  mov r10d, 0x40
00007b6e1c3ce841  cmp r11, r10
00007b6e1c3ce844  cmc
00007b6e1c3ce845  lahf
00007b6e1c3ce846  seto al
00007b6e1c3ce849  mov [r15+0x108], eax
00007b6e1c3ce850  lea eax, [r14d-0x01]
00007b6e1c3ce855  mov eax, eax
00007b6e1c3ce857  mov [r15+0x50], rax
00007b6e1c3ce85b  mov rax, [r15+0x48]
00007b6e1c3ce85f  lea r14, [rax+r12*1]
00007b6e1c3ce863  movq rax, xmm1
00007b6e1c3ce868  mov [r13+r14*1], rax
00007b6e1c3ce86d  mov rax, [r15+0x40]
00007b6e1c3ce871  lea r14, [rax+r12*1]
00007b6e1c3ce875  movq rax, xmm15
00007b6e1c3ce87a  mov [r13+r14*1], rax
00007b6e1c3ce87f  mov [r15+0x58], r11
00007b6e1c3ce883  mov eax, [r15+0x108]
00007b6e1c3ce88a  sahf
00007b6e1c3ce88b  jnz 0x00007B6E1C3CE8BD
00007b6e1c3ce88d  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3ce895  jz 0x00007B6E1C3CE910
00007b6e1c3ce89b  nop [rax+rax*1], ax
00007b6e1c3ce8a4  nop [rax+rax*1], eax
00007b6e1c3ce8ac  mov eax, 0x410074
00007b6e1c3ce8b1  mov [r15+0x100], rax
00007b6e1c3ce8b8  jmp 0x00007B6E1C1FE110
00007b6e1c3ce8bd  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3ce8c5  jz 0x00007B6E1C3CE7D0
00007b6e1c3ce8cb  nop [rax+rax*1], ax
00007b6e1c3ce8d4  nop [rax+rax*1], eax
00007b6e1c3ce8dc  mov eax, 0x41004C
00007b6e1c3ce8e1  mov [r15+0x100], rax
00007b6e1c3ce8e8  jmp 0x00007B6E1C1FE110
00007b6e1c3ce8ed  int3
00007b6e1c3ce8ee  call 0x00007B6E1C2D5EB0
00007b6e1c3ce8f3  jmp 0x00007B6E1C3CE86D
00007b6e1c3ce8f8  call 0x00007B6E1C2D5EB0
00007b6e1c3ce8fd  jmp 0x00007B6E1C3CE87F
00007b6e1c3ce902  int3
00007b6e1c3ce903  nop [rax+rax*1], ax
00007b6e1c3ce90c  nop [rax], eax
00007b6e1c3ce910  vxorps xmm1, xmm1, xmm1
00007b6e1c3ce914  movq xmm1, xmm1
00007b6e1c3ce918  movaps [r15+0x110], xmm1
00007b6e1c3ce920  mov qword ptr [r15+0x58], 0x00
00007b6e1c3ce928  mov qword ptr [r15+0x50], 0x4205C0
00007b6e1c3ce930  mov qword ptr [r15+0x60], 0x00
00007b6e1c3ce938  mov qword ptr [r15+0x68], 0x4205C0
00007b6e1c3ce940  mov rax, [r15+0x40]
00007b6e1c3ce944  mov r14, [r13+rax*1]
00007b6e1c3ce949  lea r12, [rax+0x08]
00007b6e1c3ce94d  mov r11, [r13+r12*1]
00007b6e1c3ce952  movq xmm15, r14
00007b6e1c3ce957  movq xmm14, r11
00007b6e1c3ce95c  movq xmm15, xmm15
00007b6e1c3ce961  movq xmm15, xmm15
00007b6e1c3ce966  movaps [r15+0x120], xmm15
00007b6e1c3ce96e  movq xmm14, xmm14
00007b6e1c3ce973  movq xmm14, xmm14
00007b6e1c3ce978  movaps [r15+0x130], xmm14
00007b6e1c3ce980  lea r14, [rax+0x10]
00007b6e1c3ce984  mov r12, [r13+r14*1]
00007b6e1c3ce989  lea r14, [rax+0x18]
00007b6e1c3ce98d  mov r11, [r13+r14*1]
00007b6e1c3ce992  movq xmm15, r12
00007b6e1c3ce997  movq xmm14, r11
00007b6e1c3ce99c  movq xmm15, xmm15
00007b6e1c3ce9a1  movq xmm15, xmm15
00007b6e1c3ce9a6  movaps [r15+0x140], xmm15
00007b6e1c3ce9ae  movq xmm14, xmm14
00007b6e1c3ce9b3  movq xmm14, xmm14
00007b6e1c3ce9b8  movaps [r15+0x150], xmm14
00007b6e1c3ce9c0  lea r14, [rax+0x20]
00007b6e1c3ce9c4  mov r12, [r13+r14*1]
00007b6e1c3ce9c9  lea r14, [rax+0x28]
00007b6e1c3ce9cd  mov r11, [r13+r14*1]
00007b6e1c3ce9d2  movq xmm15, r12
00007b6e1c3ce9d7  movq xmm14, r11
00007b6e1c3ce9dc  movq xmm15, xmm15
00007b6e1c3ce9e1  movq xmm15, xmm15
00007b6e1c3ce9e6  movaps [r15+0x160], xmm15
00007b6e1c3ce9ee  movq xmm14, xmm14
00007b6e1c3ce9f3  movq xmm14, xmm14
00007b6e1c3ce9f8  movaps [r15+0x170], xmm14
00007b6e1c3cea00  lea r14, [rax+0x30]
00007b6e1c3cea04  mov r12, [r13+r14*1]
00007b6e1c3cea09  lea r14, [rax+0x38]
00007b6e1c3cea0d  mov rax, [r13+r14*1]
00007b6e1c3cea12  movq xmm15, r12
00007b6e1c3cea17  movq xmm14, rax
00007b6e1c3cea1c  movq xmm15, xmm15
00007b6e1c3cea21  movq xmm15, xmm15
00007b6e1c3cea26  movaps [r15+0x180], xmm15
00007b6e1c3cea2e  movq xmm14, xmm14
00007b6e1c3cea33  movq xmm14, xmm14
00007b6e1c3cea38  movaps [r15+0x210], xmm14
00007b6e1c3cea40  mov rax, [r15+0x48]
00007b6e1c3cea44  mov [r15+0x78], rax
00007b6e1c3cea48  mov r14, [r13+rax*1]
00007b6e1c3cea4d  movq xmm15, r14
00007b6e1c3cea52  lea r14, [rax+0x40]
00007b6e1c3cea56  mov r12, [r13+r14*1]
00007b6e1c3cea5b  movq xmm14, r12
00007b6e1c3cea60  lea r14, [rax+0x80]
00007b6e1c3cea67  mov r12, [r13+r14*1]
00007b6e1c3cea6c  movq xmm13, r12
00007b6e1c3cea71  movaps xmm12, [r15+0x120]
00007b6e1c3cea79  movq r14, xmm12
00007b6e1c3cea7e  movq r12, xmm15
00007b6e1c3cea83  vmovq xmm15, r14
00007b6e1c3cea88  vmovq xmm12, r12
00007b6e1c3cea8d  movaps xmm11, xmm15
00007b6e1c3cea91  mulsd xmm11, xmm12
00007b6e1c3cea96  ucomisd xmm11, xmm11
00007b6e1c3cea9b  jp 0x00007B6E1C3CEEFC
00007b6e1c3ceaa1  movq xmm11, xmm11
00007b6e1c3ceaa6  movaps xmm15, [r15+0x130]
00007b6e1c3ceaae  movq r14, xmm15
00007b6e1c3ceab3  movq r12, xmm14
00007b6e1c3ceab8  vmovq xmm15, r14
00007b6e1c3ceabd  vmovq xmm14, r12
00007b6e1c3ceac2  movaps xmm12, xmm15
00007b6e1c3ceac6  mulsd xmm12, xmm14
00007b6e1c3ceacb  ucomisd xmm12, xmm12
00007b6e1c3cead0  jp 0x00007B6E1C3CEF48
00007b6e1c3cead6  movq xmm12, xmm12
00007b6e1c3ceadb  movq r14, xmm11
00007b6e1c3ceae0  movq r12, xmm1
00007b6e1c3ceae5  vmovq xmm1, r14
00007b6e1c3ceaea  vmovq xmm15, r12
00007b6e1c3ceaef  movaps xmm14, xmm1
00007b6e1c3ceaf3  addsd xmm14, xmm15
00007b6e1c3ceaf8  ucomisd xmm14, xmm14
00007b6e1c3ceafd  jp 0x00007B6E1C3CEF94
00007b6e1c3ceb03  movq xmm14, xmm14
00007b6e1c3ceb08  movq r14, xmm14
00007b6e1c3ceb0d  movq r12, xmm12
00007b6e1c3ceb12  vmovq xmm1, r14
00007b6e1c3ceb17  vmovq xmm15, r12
00007b6e1c3ceb1c  movaps xmm14, xmm1
00007b6e1c3ceb20  addsd xmm14, xmm15
00007b6e1c3ceb25  ucomisd xmm14, xmm14
00007b6e1c3ceb2a  jp 0x00007B6E1C3CEFE0
00007b6e1c3ceb30  movq xmm14, xmm14
00007b6e1c3ceb35  movaps xmm1, [r15+0x140]
00007b6e1c3ceb3d  movq r14, xmm1
00007b6e1c3ceb42  movq r12, xmm13
00007b6e1c3ceb47  vmovq xmm1, r14
00007b6e1c3ceb4c  vmovq xmm15, r12
00007b6e1c3ceb51  movaps xmm13, xmm1
00007b6e1c3ceb55  mulsd xmm13, xmm15
00007b6e1c3ceb5a  ucomisd xmm13, xmm13
00007b6e1c3ceb5f  jp 0x00007B6E1C3CF02C
00007b6e1c3ceb65  movq xmm13, xmm13
00007b6e1c3ceb6a  lea r14, [rax+0xC0]
00007b6e1c3ceb71  mov r12, [r13+r14*1]
00007b6e1c3ceb76  movq xmm1, r12
00007b6e1c3ceb7b  movq r14, xmm14
00007b6e1c3ceb80  movq r12, xmm13
00007b6e1c3ceb85  vmovq xmm15, r14
00007b6e1c3ceb8a  vmovq xmm14, r12
00007b6e1c3ceb8f  movaps xmm13, xmm15
00007b6e1c3ceb93  addsd xmm13, xmm14
00007b6e1c3ceb98  ucomisd xmm13, xmm13
00007b6e1c3ceb9d  jp 0x00007B6E1C3CF082
00007b6e1c3ceba3  movq xmm13, xmm13
00007b6e1c3ceba8  movaps xmm15, [r15+0x150]
00007b6e1c3cebb0  movq r14, xmm15
00007b6e1c3cebb5  movq r12, xmm1
00007b6e1c3cebba  vmovq xmm1, r14
00007b6e1c3cebbf  vmovq xmm15, r12
00007b6e1c3cebc4  movaps xmm14, xmm1
00007b6e1c3cebc8  mulsd xmm14, xmm15
00007b6e1c3cebcd  ucomisd xmm14, xmm14
00007b6e1c3cebd2  jp 0x00007B6E1C3CF0CE
00007b6e1c3cebd8  movq xmm14, xmm14
00007b6e1c3cebdd  lea r14, [rax+0x100]
00007b6e1c3cebe4  mov r12, [r13+r14*1]
00007b6e1c3cebe9  movq xmm1, r12
00007b6e1c3cebee  movq r14, xmm13
00007b6e1c3cebf3  movq r12, xmm14
00007b6e1c3cebf8  vmovq xmm15, r14
00007b6e1c3cebfd  vmovq xmm14, r12
00007b6e1c3cec02  movaps xmm13, xmm15
00007b6e1c3cec06  addsd xmm13, xmm14
00007b6e1c3cec0b  ucomisd xmm13, xmm13
00007b6e1c3cec10  jp 0x00007B6E1C3CF124
00007b6e1c3cec16  movq xmm13, xmm13
00007b6e1c3cec1b  movaps xmm15, [r15+0x160]
00007b6e1c3cec23  movq r14, xmm15
00007b6e1c3cec28  movq r12, xmm1
00007b6e1c3cec2d  vmovq xmm1, r14
00007b6e1c3cec32  vmovq xmm15, r12
00007b6e1c3cec37  movaps xmm14, xmm1
00007b6e1c3cec3b  mulsd xmm14, xmm15
00007b6e1c3cec40  ucomisd xmm14, xmm14
00007b6e1c3cec45  jp 0x00007B6E1C3CF170
00007b6e1c3cec4b  movq xmm14, xmm14
00007b6e1c3cec50  lea r14, [rax+0x140]
00007b6e1c3cec57  mov r12, [r13+r14*1]
00007b6e1c3cec5c  movq xmm1, r12
00007b6e1c3cec61  movq r14, xmm13
00007b6e1c3cec66  movq r12, xmm14
00007b6e1c3cec6b  vmovq xmm15, r14
00007b6e1c3cec70  vmovq xmm14, r12
00007b6e1c3cec75  movaps xmm13, xmm15
00007b6e1c3cec79  addsd xmm13, xmm14
00007b6e1c3cec7e  ucomisd xmm13, xmm13
00007b6e1c3cec83  jp 0x00007B6E1C3CF1C6
00007b6e1c3cec89  movq xmm13, xmm13
00007b6e1c3cec8e  movaps xmm15, [r15+0x170]
00007b6e1c3cec96  movq r14, xmm15
00007b6e1c3cec9b  movq r12, xmm1
00007b6e1c3ceca0  vmovq xmm1, r14
00007b6e1c3ceca5  vmovq xmm15, r12
00007b6e1c3cecaa  movaps xmm14, xmm1
00007b6e1c3cecae  mulsd xmm14, xmm15
00007b6e1c3cecb3  ucomisd xmm14, xmm14
00007b6e1c3cecb8  jp 0x00007B6E1C3CF212
00007b6e1c3cecbe  movq xmm14, xmm14
00007b6e1c3cecc3  lea r14, [rax+0x180]
00007b6e1c3cecca  mov r12, [r13+r14*1]
00007b6e1c3ceccf  movq xmm1, r12
00007b6e1c3cecd4  movq r14, xmm13
00007b6e1c3cecd9  movq r12, xmm14
00007b6e1c3cecde  vmovq xmm15, r14
00007b6e1c3cece3  vmovq xmm14, r12
00007b6e1c3cece8  movaps xmm13, xmm15
00007b6e1c3cecec  addsd xmm13, xmm14
00007b6e1c3cecf1  ucomisd xmm13, xmm13
00007b6e1c3cecf6  jp 0x00007B6E1C3CF268
00007b6e1c3cecfc  movq xmm13, xmm13
00007b6e1c3ced01  movaps xmm15, [r15+0x180]
00007b6e1c3ced09  movq r14, xmm15
00007b6e1c3ced0e  movq r12, xmm1
00007b6e1c3ced13  vmovq xmm1, r14
00007b6e1c3ced18  vmovq xmm15, r12
00007b6e1c3ced1d  movaps xmm14, xmm1
00007b6e1c3ced21  mulsd xmm14, xmm15
00007b6e1c3ced26  ucomisd xmm14, xmm14
00007b6e1c3ced2b  jp 0x00007B6E1C3CF2B4
00007b6e1c3ced31  movq xmm14, xmm14
00007b6e1c3ced36  lea r14, [rax+0x1C0]
00007b6e1c3ced3d  mov rax, [r13+r14*1]
00007b6e1c3ced42  movq xmm1, rax
00007b6e1c3ced47  movaps [r15+0x240], xmm1
00007b6e1c3ced4f  movq rax, xmm13
00007b6e1c3ced54  movq r14, xmm14
00007b6e1c3ced59  vmovq xmm15, rax
00007b6e1c3ced5e  vmovq xmm14, r14
00007b6e1c3ced63  movaps xmm13, xmm15
00007b6e1c3ced67  addsd xmm13, xmm14
00007b6e1c3ced6c  ucomisd xmm13, xmm13
00007b6e1c3ced71  jp 0x00007B6E1C3CF30A
00007b6e1c3ced77  movq xmm13, xmm13
00007b6e1c3ced7c  movaps xmm15, [r15+0x210]
00007b6e1c3ced84  movq rax, xmm15
00007b6e1c3ced89  movq r14, xmm1
00007b6e1c3ced8e  vmovq xmm1, rax
00007b6e1c3ced93  vmovq xmm15, r14
00007b6e1c3ced98  movaps xmm14, xmm1
00007b6e1c3ced9c  mulsd xmm14, xmm15
00007b6e1c3ceda1  ucomisd xmm14, xmm14
00007b6e1c3ceda6  jp 0x00007B6E1C3CF352
00007b6e1c3cedac  movq xmm14, xmm14
00007b6e1c3cedb1  movaps [r15+0x230], xmm14
00007b6e1c3cedb9  movq rax, xmm13
00007b6e1c3cedbe  movq r14, xmm14
00007b6e1c3cedc3  vmovq xmm1, rax
00007b6e1c3cedc8  vmovq xmm15, r14
00007b6e1c3cedcd  movaps xmm14, xmm1
00007b6e1c3cedd1  addsd xmm14, xmm15
00007b6e1c3cedd6  ucomisd xmm14, xmm14
00007b6e1c3ceddb  jp 0x00007B6E1C3CF39A
00007b6e1c3cede1  movq xmm14, xmm14
00007b6e1c3cede6  movaps [r15+0x220], xmm14
00007b6e1c3cedee  movq rax, xmm14
00007b6e1c3cedf3  mov r14d, 0x4205C0
00007b6e1c3cedf9  mov [r13+r14*1], rax
00007b6e1c3cedfe  mov qword ptr [r15+0x70], 0x08
00007b6e1c3cee06  xor eax, eax
00007b6e1c3cee08  mov r14d, 0x08
00007b6e1c3cee0e  mov r12d, 0x40
00007b6e1c3cee14  cmp r14, r12
00007b6e1c3cee17  cmc
00007b6e1c3cee18  lahf
00007b6e1c3cee19  seto al
00007b6e1c3cee1c  mov [r15+0x108], eax
00007b6e1c3cee23  mov eax, [r15+0x108]
00007b6e1c3cee2a  sahf
00007b6e1c3cee2b  jnz 0x00007B6E1C3CEE5D
00007b6e1c3cee2d  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3cee35  jz 0x00007B6E1C3CFD40
00007b6e1c3cee3b  nop [rax+rax*1], ax
00007b6e1c3cee44  nop [rax+rax*1], eax
00007b6e1c3cee4c  mov eax, 0x410118
00007b6e1c3cee51  mov [r15+0x100], rax
00007b6e1c3cee58  jmp 0x00007B6E1C1FE110
00007b6e1c3cee5d  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3cee65  jz 0x00007B6E1C3CF3F0
00007b6e1c3cee6b  nop [rax+rax*1], ax
00007b6e1c3cee74  nop [rax+rax*1], eax
00007b6e1c3cee7c  mov eax, 0x4100A4
00007b6e1c3cee81  mov [r15+0x100], rax
00007b6e1c3cee88  jmp 0x00007B6E1C1FE110
00007b6e1c3cee8d  int3
00007b6e1c3cee8e  call 0x00007B6E1C20DC20
00007b6e1c3cee93  jmp 0x00007B6E1C3CE949
00007b6e1c3cee98  call 0x00007B6E1C2C0370
00007b6e1c3cee9d  jmp 0x00007B6E1C3CE952
00007b6e1c3ceea2  call 0x00007B6E1C2E27E0
00007b6e1c3ceea7  jmp 0x00007B6E1C3CE989
00007b6e1c3ceeac  call 0x00007B6E1C2E1570
00007b6e1c3ceeb1  jmp 0x00007B6E1C3CE992
00007b6e1c3ceeb6  call 0x00007B6E1C2E27E0
00007b6e1c3ceebb  jmp 0x00007B6E1C3CE9C9
00007b6e1c3ceec0  call 0x00007B6E1C2E1570
00007b6e1c3ceec5  jmp 0x00007B6E1C3CE9D2
00007b6e1c3ceeca  call 0x00007B6E1C2E27E0
00007b6e1c3ceecf  jmp 0x00007B6E1C3CEA09
00007b6e1c3ceed4  call 0x00007B6E1C2D59C0
00007b6e1c3ceed9  jmp 0x00007B6E1C3CEA12
00007b6e1c3ceede  call 0x00007B6E1C20DC20
00007b6e1c3ceee3  jmp 0x00007B6E1C3CEA4D
00007b6e1c3ceee8  call 0x00007B6E1C2E27E0
00007b6e1c3ceeed  jmp 0x00007B6E1C3CEA5B
00007b6e1c3ceef2  call 0x00007B6E1C2E27E0
00007b6e1c3ceef7  jmp 0x00007B6E1C3CEA6C
00007b6e1c3ceefc  ucomisd xmm15, xmm12
00007b6e1c3cef01  jp 0x00007B6E1C3CEF10
00007b6e1c3cef03  movaps xmm11, [0x00007B6E1BFFE030]
00007b6e1c3cef0b  jmp 0x00007B6E1C3CEAA1
00007b6e1c3cef10  vxorps xmm0, xmm15, xmm12
00007b6e1c3cef15  pextrw r14d, xmm0, 0x03
00007b6e1c3cef1b  and r14d, 0x7FF8
00007b6e1c3cef22  cmp r14d, 0x08
00007b6e1c3cef26  jnz 0x00007B6E1C3CEAA1
00007b6e1c3cef2c  movq r14, xmm12
00007b6e1c3cef31  shl r14, 0x0D
00007b6e1c3cef35  jbe 0x00007B6E1C3CEAA1
00007b6e1c3cef3b  vorps xmm11, xmm12, [0x00007B6E1BFFE040]
00007b6e1c3cef43  jmp 0x00007B6E1C3CEAA1
00007b6e1c3cef48  ucomisd xmm15, xmm14
00007b6e1c3cef4d  jp 0x00007B6E1C3CEF5C
00007b6e1c3cef4f  movaps xmm12, [0x00007B6E1BFFE030]
00007b6e1c3cef57  jmp 0x00007B6E1C3CEAD6
00007b6e1c3cef5c  vxorps xmm0, xmm15, xmm14
00007b6e1c3cef61  pextrw r14d, xmm0, 0x03
00007b6e1c3cef67  and r14d, 0x7FF8
00007b6e1c3cef6e  cmp r14d, 0x08
00007b6e1c3cef72  jnz 0x00007B6E1C3CEAD6
00007b6e1c3cef78  movq r14, xmm14
00007b6e1c3cef7d  shl r14, 0x0D
00007b6e1c3cef81  jbe 0x00007B6E1C3CEAD6
00007b6e1c3cef87  vorps xmm12, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cef8f  jmp 0x00007B6E1C3CEAD6
00007b6e1c3cef94  ucomisd xmm1, xmm15
00007b6e1c3cef99  jp 0x00007B6E1C3CEFA8
00007b6e1c3cef9b  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cefa3  jmp 0x00007B6E1C3CEB03
00007b6e1c3cefa8  vxorps xmm0, xmm1, xmm15
00007b6e1c3cefad  pextrw r14d, xmm0, 0x03
00007b6e1c3cefb3  and r14d, 0x7FF8
00007b6e1c3cefba  cmp r14d, 0x08
00007b6e1c3cefbe  jnz 0x00007B6E1C3CEB03
00007b6e1c3cefc4  movq r14, xmm15
00007b6e1c3cefc9  shl r14, 0x0D
00007b6e1c3cefcd  jbe 0x00007B6E1C3CEB03
00007b6e1c3cefd3  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cefdb  jmp 0x00007B6E1C3CEB03
00007b6e1c3cefe0  ucomisd xmm1, xmm15
00007b6e1c3cefe5  jp 0x00007B6E1C3CEFF4
00007b6e1c3cefe7  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cefef  jmp 0x00007B6E1C3CEB30
00007b6e1c3ceff4  vxorps xmm0, xmm1, xmm15
00007b6e1c3ceff9  pextrw r14d, xmm0, 0x03
00007b6e1c3cefff  and r14d, 0x7FF8
00007b6e1c3cf006  cmp r14d, 0x08
00007b6e1c3cf00a  jnz 0x00007B6E1C3CEB30
00007b6e1c3cf010  movq r14, xmm15
00007b6e1c3cf015  shl r14, 0x0D
00007b6e1c3cf019  jbe 0x00007B6E1C3CEB30
00007b6e1c3cf01f  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf027  jmp 0x00007B6E1C3CEB30
00007b6e1c3cf02c  ucomisd xmm1, xmm15
00007b6e1c3cf031  jp 0x00007B6E1C3CF040
00007b6e1c3cf033  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cf03b  jmp 0x00007B6E1C3CEB65
00007b6e1c3cf040  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf045  pextrw r14d, xmm0, 0x03
00007b6e1c3cf04b  and r14d, 0x7FF8
00007b6e1c3cf052  cmp r14d, 0x08
00007b6e1c3cf056  jnz 0x00007B6E1C3CEB65
00007b6e1c3cf05c  movq r14, xmm15
00007b6e1c3cf061  shl r14, 0x0D
00007b6e1c3cf065  jbe 0x00007B6E1C3CEB65
00007b6e1c3cf06b  vorps xmm13, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf073  jmp 0x00007B6E1C3CEB65
00007b6e1c3cf078  call 0x00007B6E1C2E27E0
00007b6e1c3cf07d  jmp 0x00007B6E1C3CEB76
00007b6e1c3cf082  ucomisd xmm15, xmm14
00007b6e1c3cf087  jp 0x00007B6E1C3CF096
00007b6e1c3cf089  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cf091  jmp 0x00007B6E1C3CEBA3
00007b6e1c3cf096  vxorps xmm0, xmm15, xmm14
00007b6e1c3cf09b  pextrw r14d, xmm0, 0x03
00007b6e1c3cf0a1  and r14d, 0x7FF8
00007b6e1c3cf0a8  cmp r14d, 0x08
00007b6e1c3cf0ac  jnz 0x00007B6E1C3CEBA3
00007b6e1c3cf0b2  movq r14, xmm14
00007b6e1c3cf0b7  shl r14, 0x0D
00007b6e1c3cf0bb  jbe 0x00007B6E1C3CEBA3
00007b6e1c3cf0c1  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cf0c9  jmp 0x00007B6E1C3CEBA3
00007b6e1c3cf0ce  ucomisd xmm1, xmm15
00007b6e1c3cf0d3  jp 0x00007B6E1C3CF0E2
00007b6e1c3cf0d5  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cf0dd  jmp 0x00007B6E1C3CEBD8
00007b6e1c3cf0e2  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf0e7  pextrw r14d, xmm0, 0x03
00007b6e1c3cf0ed  and r14d, 0x7FF8
00007b6e1c3cf0f4  cmp r14d, 0x08
00007b6e1c3cf0f8  jnz 0x00007B6E1C3CEBD8
00007b6e1c3cf0fe  movq r14, xmm15
00007b6e1c3cf103  shl r14, 0x0D
00007b6e1c3cf107  jbe 0x00007B6E1C3CEBD8
00007b6e1c3cf10d  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf115  jmp 0x00007B6E1C3CEBD8
00007b6e1c3cf11a  call 0x00007B6E1C2E27E0
00007b6e1c3cf11f  jmp 0x00007B6E1C3CEBE9
00007b6e1c3cf124  ucomisd xmm15, xmm14
00007b6e1c3cf129  jp 0x00007B6E1C3CF138
00007b6e1c3cf12b  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cf133  jmp 0x00007B6E1C3CEC16
00007b6e1c3cf138  vxorps xmm0, xmm15, xmm14
00007b6e1c3cf13d  pextrw r14d, xmm0, 0x03
00007b6e1c3cf143  and r14d, 0x7FF8
00007b6e1c3cf14a  cmp r14d, 0x08
00007b6e1c3cf14e  jnz 0x00007B6E1C3CEC16
00007b6e1c3cf154  movq r14, xmm14
00007b6e1c3cf159  shl r14, 0x0D
00007b6e1c3cf15d  jbe 0x00007B6E1C3CEC16
00007b6e1c3cf163  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cf16b  jmp 0x00007B6E1C3CEC16
00007b6e1c3cf170  ucomisd xmm1, xmm15
00007b6e1c3cf175  jp 0x00007B6E1C3CF184
00007b6e1c3cf177  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cf17f  jmp 0x00007B6E1C3CEC4B
00007b6e1c3cf184  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf189  pextrw r14d, xmm0, 0x03
00007b6e1c3cf18f  and r14d, 0x7FF8
00007b6e1c3cf196  cmp r14d, 0x08
00007b6e1c3cf19a  jnz 0x00007B6E1C3CEC4B
00007b6e1c3cf1a0  movq r14, xmm15
00007b6e1c3cf1a5  shl r14, 0x0D
00007b6e1c3cf1a9  jbe 0x00007B6E1C3CEC4B
00007b6e1c3cf1af  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf1b7  jmp 0x00007B6E1C3CEC4B
00007b6e1c3cf1bc  call 0x00007B6E1C2E27E0
00007b6e1c3cf1c1  jmp 0x00007B6E1C3CEC5C
00007b6e1c3cf1c6  ucomisd xmm15, xmm14
00007b6e1c3cf1cb  jp 0x00007B6E1C3CF1DA
00007b6e1c3cf1cd  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cf1d5  jmp 0x00007B6E1C3CEC89
00007b6e1c3cf1da  vxorps xmm0, xmm15, xmm14
00007b6e1c3cf1df  pextrw r14d, xmm0, 0x03
00007b6e1c3cf1e5  and r14d, 0x7FF8
00007b6e1c3cf1ec  cmp r14d, 0x08
00007b6e1c3cf1f0  jnz 0x00007B6E1C3CEC89
00007b6e1c3cf1f6  movq r14, xmm14
00007b6e1c3cf1fb  shl r14, 0x0D
00007b6e1c3cf1ff  jbe 0x00007B6E1C3CEC89
00007b6e1c3cf205  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cf20d  jmp 0x00007B6E1C3CEC89
00007b6e1c3cf212  ucomisd xmm1, xmm15
00007b6e1c3cf217  jp 0x00007B6E1C3CF226
00007b6e1c3cf219  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cf221  jmp 0x00007B6E1C3CECBE
00007b6e1c3cf226  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf22b  pextrw r14d, xmm0, 0x03
00007b6e1c3cf231  and r14d, 0x7FF8
00007b6e1c3cf238  cmp r14d, 0x08
00007b6e1c3cf23c  jnz 0x00007B6E1C3CECBE
00007b6e1c3cf242  movq r14, xmm15
00007b6e1c3cf247  shl r14, 0x0D
00007b6e1c3cf24b  jbe 0x00007B6E1C3CECBE
00007b6e1c3cf251  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf259  jmp 0x00007B6E1C3CECBE
00007b6e1c3cf25e  call 0x00007B6E1C2E27E0
00007b6e1c3cf263  jmp 0x00007B6E1C3CECCF
00007b6e1c3cf268  ucomisd xmm15, xmm14
00007b6e1c3cf26d  jp 0x00007B6E1C3CF27C
00007b6e1c3cf26f  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cf277  jmp 0x00007B6E1C3CECFC
00007b6e1c3cf27c  vxorps xmm0, xmm15, xmm14
00007b6e1c3cf281  pextrw r14d, xmm0, 0x03
00007b6e1c3cf287  and r14d, 0x7FF8
00007b6e1c3cf28e  cmp r14d, 0x08
00007b6e1c3cf292  jnz 0x00007B6E1C3CECFC
00007b6e1c3cf298  movq r14, xmm14
00007b6e1c3cf29d  shl r14, 0x0D
00007b6e1c3cf2a1  jbe 0x00007B6E1C3CECFC
00007b6e1c3cf2a7  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cf2af  jmp 0x00007B6E1C3CECFC
00007b6e1c3cf2b4  ucomisd xmm1, xmm15
00007b6e1c3cf2b9  jp 0x00007B6E1C3CF2C8
00007b6e1c3cf2bb  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cf2c3  jmp 0x00007B6E1C3CED31
00007b6e1c3cf2c8  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf2cd  pextrw r14d, xmm0, 0x03
00007b6e1c3cf2d3  and r14d, 0x7FF8
00007b6e1c3cf2da  cmp r14d, 0x08
00007b6e1c3cf2de  jnz 0x00007B6E1C3CED31
00007b6e1c3cf2e4  movq r14, xmm15
00007b6e1c3cf2e9  shl r14, 0x0D
00007b6e1c3cf2ed  jbe 0x00007B6E1C3CED31
00007b6e1c3cf2f3  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf2fb  jmp 0x00007B6E1C3CED31
00007b6e1c3cf300  call 0x00007B6E1C2D59C0
00007b6e1c3cf305  jmp 0x00007B6E1C3CED42
00007b6e1c3cf30a  ucomisd xmm15, xmm14
00007b6e1c3cf30f  jp 0x00007B6E1C3CF31E
00007b6e1c3cf311  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cf319  jmp 0x00007B6E1C3CED77
00007b6e1c3cf31e  vxorps xmm0, xmm15, xmm14
00007b6e1c3cf323  pextrw eax, xmm0, 0x03
00007b6e1c3cf328  and eax, 0x7FF8
00007b6e1c3cf32d  cmp eax, 0x08
00007b6e1c3cf330  jnz 0x00007B6E1C3CED77
00007b6e1c3cf336  movq rax, xmm14
00007b6e1c3cf33b  shl rax, 0x0D
00007b6e1c3cf33f  jbe 0x00007B6E1C3CED77
00007b6e1c3cf345  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cf34d  jmp 0x00007B6E1C3CED77
00007b6e1c3cf352  ucomisd xmm1, xmm15
00007b6e1c3cf357  jp 0x00007B6E1C3CF366
00007b6e1c3cf359  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cf361  jmp 0x00007B6E1C3CEDAC
00007b6e1c3cf366  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf36b  pextrw eax, xmm0, 0x03
00007b6e1c3cf370  and eax, 0x7FF8
00007b6e1c3cf375  cmp eax, 0x08
00007b6e1c3cf378  jnz 0x00007B6E1C3CEDAC
00007b6e1c3cf37e  movq rax, xmm15
00007b6e1c3cf383  shl rax, 0x0D
00007b6e1c3cf387  jbe 0x00007B6E1C3CEDAC
00007b6e1c3cf38d  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf395  jmp 0x00007B6E1C3CEDAC
00007b6e1c3cf39a  ucomisd xmm1, xmm15
00007b6e1c3cf39f  jp 0x00007B6E1C3CF3AE
00007b6e1c3cf3a1  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cf3a9  jmp 0x00007B6E1C3CEDE1
00007b6e1c3cf3ae  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf3b3  pextrw eax, xmm0, 0x03
00007b6e1c3cf3b8  and eax, 0x7FF8
00007b6e1c3cf3bd  cmp eax, 0x08
00007b6e1c3cf3c0  jnz 0x00007B6E1C3CEDE1
00007b6e1c3cf3c6  movq rax, xmm15
00007b6e1c3cf3cb  shl rax, 0x0D
00007b6e1c3cf3cf  jbe 0x00007B6E1C3CEDE1
00007b6e1c3cf3d5  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf3dd  jmp 0x00007B6E1C3CEDE1
00007b6e1c3cf3e2  call 0x00007B6E1C2D5EB0
00007b6e1c3cf3e7  jmp 0x00007B6E1C3CEDFE
00007b6e1c3cf3ec  int3
00007b6e1c3cf3ed  nop [rax], eax
00007b6e1c3cf3f0  mov rax, [r15+0x48]
00007b6e1c3cf3f4  mov r14, [r15+0x70]
00007b6e1c3cf3f8  lea r12, [rax+r14*1]
00007b6e1c3cf3fc  mov [r15+0x78], r12
00007b6e1c3cf400  mov rax, [r13+r12*1]
00007b6e1c3cf405  movq xmm1, rax
00007b6e1c3cf40a  lea rax, [r12+0x40]
00007b6e1c3cf40f  mov r11, [r13+rax*1]
00007b6e1c3cf414  movq xmm15, r11
00007b6e1c3cf419  lea rax, [r12+0x80]
00007b6e1c3cf421  mov r11, [r13+rax*1]
00007b6e1c3cf426  movq xmm14, r11
00007b6e1c3cf42b  movaps xmm13, [r15+0x120]
00007b6e1c3cf433  movq rax, xmm13
00007b6e1c3cf438  movq r11, xmm1
00007b6e1c3cf43d  vmovq xmm1, rax
00007b6e1c3cf442  vmovq xmm13, r11
00007b6e1c3cf447  movaps xmm12, xmm1
00007b6e1c3cf44b  mulsd xmm12, xmm13
00007b6e1c3cf450  ucomisd xmm12, xmm12
00007b6e1c3cf455  jp 0x00007B6E1C3CF879
00007b6e1c3cf45b  movq xmm12, xmm12
00007b6e1c3cf460  movaps xmm1, [r15+0x130]
00007b6e1c3cf468  movq rax, xmm1
00007b6e1c3cf46d  movq r11, xmm15
00007b6e1c3cf472  vmovq xmm1, rax
00007b6e1c3cf477  vmovq xmm15, r11
00007b6e1c3cf47c  movaps xmm13, xmm1
00007b6e1c3cf480  mulsd xmm13, xmm15
00007b6e1c3cf485  ucomisd xmm13, xmm13
00007b6e1c3cf48a  jp 0x00007B6E1C3CF8C1
00007b6e1c3cf490  movq xmm13, xmm13
00007b6e1c3cf495  movq rax, xmm12
00007b6e1c3cf49a  movaps xmm1, [r15+0x110]
00007b6e1c3cf4a2  movq r11, xmm1
00007b6e1c3cf4a7  vmovq xmm1, rax
00007b6e1c3cf4ac  vmovq xmm15, r11
00007b6e1c3cf4b1  movaps xmm12, xmm1
00007b6e1c3cf4b5  addsd xmm12, xmm15
00007b6e1c3cf4ba  ucomisd xmm12, xmm12
00007b6e1c3cf4bf  jp 0x00007B6E1C3CF909
00007b6e1c3cf4c5  movq xmm12, xmm12
00007b6e1c3cf4ca  movq rax, xmm12
00007b6e1c3cf4cf  movq r11, xmm13
00007b6e1c3cf4d4  vmovq xmm1, rax
00007b6e1c3cf4d9  vmovq xmm15, r11
00007b6e1c3cf4de  movaps xmm13, xmm1
00007b6e1c3cf4e2  addsd xmm13, xmm15
00007b6e1c3cf4e7  ucomisd xmm13, xmm13
00007b6e1c3cf4ec  jp 0x00007B6E1C3CF951
00007b6e1c3cf4f2  movq xmm13, xmm13
00007b6e1c3cf4f7  movaps xmm1, [r15+0x140]
00007b6e1c3cf4ff  movq rax, xmm1
00007b6e1c3cf504  movq r11, xmm14
00007b6e1c3cf509  vmovq xmm1, rax
00007b6e1c3cf50e  vmovq xmm15, r11
00007b6e1c3cf513  movaps xmm14, xmm1
00007b6e1c3cf517  mulsd xmm14, xmm15
00007b6e1c3cf51c  ucomisd xmm14, xmm14
00007b6e1c3cf521  jp 0x00007B6E1C3CF999
00007b6e1c3cf527  movq xmm14, xmm14
00007b6e1c3cf52c  lea rax, [r12+0xC0]
00007b6e1c3cf534  mov r11, [r13+rax*1]
00007b6e1c3cf539  movq xmm1, r11
00007b6e1c3cf53e  movq rax, xmm13
00007b6e1c3cf543  movq r11, xmm14
00007b6e1c3cf548  vmovq xmm15, rax
00007b6e1c3cf54d  vmovq xmm14, r11
00007b6e1c3cf552  movaps xmm13, xmm15
00007b6e1c3cf556  addsd xmm13, xmm14
00007b6e1c3cf55b  ucomisd xmm13, xmm13
00007b6e1c3cf560  jp 0x00007B6E1C3CF9EB
00007b6e1c3cf566  movq xmm13, xmm13
00007b6e1c3cf56b  movaps xmm15, [r15+0x150]
00007b6e1c3cf573  movq rax, xmm15
00007b6e1c3cf578  movq r11, xmm1
00007b6e1c3cf57d  vmovq xmm1, rax
00007b6e1c3cf582  vmovq xmm15, r11
00007b6e1c3cf587  movaps xmm14, xmm1
00007b6e1c3cf58b  mulsd xmm14, xmm15
00007b6e1c3cf590  ucomisd xmm14, xmm14
00007b6e1c3cf595  jp 0x00007B6E1C3CFA33
00007b6e1c3cf59b  movq xmm14, xmm14
00007b6e1c3cf5a0  lea rax, [r12+0x100]
00007b6e1c3cf5a8  mov r11, [r13+rax*1]
00007b6e1c3cf5ad  movq xmm1, r11
00007b6e1c3cf5b2  movq rax, xmm13
00007b6e1c3cf5b7  movq r11, xmm14
00007b6e1c3cf5bc  vmovq xmm15, rax
00007b6e1c3cf5c1  vmovq xmm14, r11
00007b6e1c3cf5c6  movaps xmm13, xmm15
00007b6e1c3cf5ca  addsd xmm13, xmm14
00007b6e1c3cf5cf  ucomisd xmm13, xmm13
00007b6e1c3cf5d4  jp 0x00007B6E1C3CFA85
00007b6e1c3cf5da  movq xmm13, xmm13
00007b6e1c3cf5df  movaps xmm15, [r15+0x160]
00007b6e1c3cf5e7  movq rax, xmm15
00007b6e1c3cf5ec  movq r11, xmm1
00007b6e1c3cf5f1  vmovq xmm1, rax
00007b6e1c3cf5f6  vmovq xmm15, r11
00007b6e1c3cf5fb  movaps xmm14, xmm1
00007b6e1c3cf5ff  mulsd xmm14, xmm15
00007b6e1c3cf604  ucomisd xmm14, xmm14
00007b6e1c3cf609  jp 0x00007B6E1C3CFACD
00007b6e1c3cf60f  movq xmm14, xmm14
00007b6e1c3cf614  lea rax, [r12+0x140]
00007b6e1c3cf61c  mov r11, [r13+rax*1]
00007b6e1c3cf621  movq xmm1, r11
00007b6e1c3cf626  movq rax, xmm13
00007b6e1c3cf62b  movq r11, xmm14
00007b6e1c3cf630  vmovq xmm15, rax
00007b6e1c3cf635  vmovq xmm14, r11
00007b6e1c3cf63a  movaps xmm13, xmm15
00007b6e1c3cf63e  addsd xmm13, xmm14
00007b6e1c3cf643  ucomisd xmm13, xmm13
00007b6e1c3cf648  jp 0x00007B6E1C3CFB1F
00007b6e1c3cf64e  movq xmm13, xmm13
00007b6e1c3cf653  movaps xmm15, [r15+0x170]
00007b6e1c3cf65b  movq rax, xmm15
00007b6e1c3cf660  movq r11, xmm1
00007b6e1c3cf665  vmovq xmm1, rax
00007b6e1c3cf66a  vmovq xmm15, r11
00007b6e1c3cf66f  movaps xmm14, xmm1
00007b6e1c3cf673  mulsd xmm14, xmm15
00007b6e1c3cf678  ucomisd xmm14, xmm14
00007b6e1c3cf67d  jp 0x00007B6E1C3CFB67
00007b6e1c3cf683  movq xmm14, xmm14
00007b6e1c3cf688  lea rax, [r12+0x180]
00007b6e1c3cf690  mov r11, [r13+rax*1]
00007b6e1c3cf695  movq xmm1, r11
00007b6e1c3cf69a  movq rax, xmm13
00007b6e1c3cf69f  movq r11, xmm14
00007b6e1c3cf6a4  vmovq xmm15, rax
00007b6e1c3cf6a9  vmovq xmm14, r11
00007b6e1c3cf6ae  movaps xmm13, xmm15
00007b6e1c3cf6b2  addsd xmm13, xmm14
00007b6e1c3cf6b7  ucomisd xmm13, xmm13
00007b6e1c3cf6bc  jp 0x00007B6E1C3CFBB9
00007b6e1c3cf6c2  movq xmm13, xmm13
00007b6e1c3cf6c7  movaps xmm15, [r15+0x180]
00007b6e1c3cf6cf  movq rax, xmm15
00007b6e1c3cf6d4  movq r11, xmm1
00007b6e1c3cf6d9  vmovq xmm1, rax
00007b6e1c3cf6de  vmovq xmm15, r11
00007b6e1c3cf6e3  movaps xmm14, xmm1
00007b6e1c3cf6e7  mulsd xmm14, xmm15
00007b6e1c3cf6ec  ucomisd xmm14, xmm14
00007b6e1c3cf6f1  jp 0x00007B6E1C3CFC01
00007b6e1c3cf6f7  movq xmm14, xmm14
00007b6e1c3cf6fc  lea rax, [r12+0x1C0]
00007b6e1c3cf704  mov r12, [r13+rax*1]
00007b6e1c3cf709  movq xmm1, r12
00007b6e1c3cf70e  movaps [r15+0x240], xmm1
00007b6e1c3cf716  movq rax, xmm13
00007b6e1c3cf71b  movq r12, xmm14
00007b6e1c3cf720  vmovq xmm15, rax
00007b6e1c3cf725  vmovq xmm14, r12
00007b6e1c3cf72a  movaps xmm13, xmm15
00007b6e1c3cf72e  addsd xmm13, xmm14
00007b6e1c3cf733  ucomisd xmm13, xmm13
00007b6e1c3cf738  jp 0x00007B6E1C3CFC53
00007b6e1c3cf73e  movq xmm13, xmm13
00007b6e1c3cf743  movaps xmm15, [r15+0x210]
00007b6e1c3cf74b  movq rax, xmm15
00007b6e1c3cf750  movq r12, xmm1
00007b6e1c3cf755  vmovq xmm1, rax
00007b6e1c3cf75a  vmovq xmm15, r12
00007b6e1c3cf75f  movaps xmm14, xmm1
00007b6e1c3cf763  mulsd xmm14, xmm15
00007b6e1c3cf768  ucomisd xmm14, xmm14
00007b6e1c3cf76d  jp 0x00007B6E1C3CFC9B
00007b6e1c3cf773  movq xmm14, xmm14
00007b6e1c3cf778  movaps [r15+0x230], xmm14
00007b6e1c3cf780  movq rax, xmm13
00007b6e1c3cf785  movq r12, xmm14
00007b6e1c3cf78a  vmovq xmm1, rax
00007b6e1c3cf78f  vmovq xmm15, r12
00007b6e1c3cf794  movaps xmm14, xmm1
00007b6e1c3cf798  addsd xmm14, xmm15
00007b6e1c3cf79d  ucomisd xmm14, xmm14
00007b6e1c3cf7a2  jp 0x00007B6E1C3CFCE3
00007b6e1c3cf7a8  movq xmm14, xmm14
00007b6e1c3cf7ad  movaps [r15+0x220], xmm14
00007b6e1c3cf7b5  mov rax, [r15+0x68]
00007b6e1c3cf7b9  lea r12, [rax+r14*1]
00007b6e1c3cf7bd  movq rax, xmm14
00007b6e1c3cf7c2  mov [r13+r12*1], rax
00007b6e1c3cf7c7  lea rax, [r14+0x08]
00007b6e1c3cf7cb  mov [r15+0x70], rax
00007b6e1c3cf7cf  mov [rsp+0x10], rax
00007b6e1c3cf7d4  xor eax, eax
00007b6e1c3cf7d6  mov r14, [rsp+0x10]
00007b6e1c3cf7db  mov r12d, 0x40
00007b6e1c3cf7e1  cmp r14, r12
00007b6e1c3cf7e4  cmc
00007b6e1c3cf7e5  lahf
00007b6e1c3cf7e6  seto al
00007b6e1c3cf7e9  mov [r15+0x108], eax
00007b6e1c3cf7f0  mov eax, [r15+0x108]
00007b6e1c3cf7f7  sahf
00007b6e1c3cf7f8  jnz 0x00007B6E1C3CF82A
00007b6e1c3cf7fa  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3cf802  jz 0x00007B6E1C3CFD40
00007b6e1c3cf808  nop [rax+rax*1], ax
00007b6e1c3cf811  nop [rax+rax*1], eax
00007b6e1c3cf819  mov eax, 0x410118
00007b6e1c3cf81e  mov [r15+0x100], rax
00007b6e1c3cf825  jmp 0x00007B6E1C1FE110
00007b6e1c3cf82a  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3cf832  jz 0x00007B6E1C3CF3F0
00007b6e1c3cf838  nop [rax+rax*1], ax
00007b6e1c3cf841  nop [rax+rax*1], eax
00007b6e1c3cf849  mov eax, 0x4100A4
00007b6e1c3cf84e  mov [r15+0x100], rax
00007b6e1c3cf855  jmp 0x00007B6E1C1FE110
00007b6e1c3cf85a  int3
00007b6e1c3cf85b  call 0x00007B6E1C2B47C0
00007b6e1c3cf860  jmp 0x00007B6E1C3CF405
00007b6e1c3cf865  call 0x00007B6E1C20A4B0
00007b6e1c3cf86a  jmp 0x00007B6E1C3CF414
00007b6e1c3cf86f  call 0x00007B6E1C20A4B0
00007b6e1c3cf874  jmp 0x00007B6E1C3CF426
00007b6e1c3cf879  ucomisd xmm1, xmm13
00007b6e1c3cf87e  jp 0x00007B6E1C3CF88D
00007b6e1c3cf880  movaps xmm12, [0x00007B6E1BFFE030]
00007b6e1c3cf888  jmp 0x00007B6E1C3CF45B
00007b6e1c3cf88d  vxorps xmm0, xmm1, xmm13
00007b6e1c3cf892  pextrw eax, xmm0, 0x03
00007b6e1c3cf897  and eax, 0x7FF8
00007b6e1c3cf89c  cmp eax, 0x08
00007b6e1c3cf89f  jnz 0x00007B6E1C3CF45B
00007b6e1c3cf8a5  movq rax, xmm13
00007b6e1c3cf8aa  shl rax, 0x0D
00007b6e1c3cf8ae  jbe 0x00007B6E1C3CF45B
00007b6e1c3cf8b4  vorps xmm12, xmm13, [0x00007B6E1BFFE040]
00007b6e1c3cf8bc  jmp 0x00007B6E1C3CF45B
00007b6e1c3cf8c1  ucomisd xmm1, xmm15
00007b6e1c3cf8c6  jp 0x00007B6E1C3CF8D5
00007b6e1c3cf8c8  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cf8d0  jmp 0x00007B6E1C3CF490
00007b6e1c3cf8d5  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf8da  pextrw eax, xmm0, 0x03
00007b6e1c3cf8df  and eax, 0x7FF8
00007b6e1c3cf8e4  cmp eax, 0x08
00007b6e1c3cf8e7  jnz 0x00007B6E1C3CF490
00007b6e1c3cf8ed  movq rax, xmm15
00007b6e1c3cf8f2  shl rax, 0x0D
00007b6e1c3cf8f6  jbe 0x00007B6E1C3CF490
00007b6e1c3cf8fc  vorps xmm13, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf904  jmp 0x00007B6E1C3CF490
00007b6e1c3cf909  ucomisd xmm1, xmm15
00007b6e1c3cf90e  jp 0x00007B6E1C3CF91D
00007b6e1c3cf910  movaps xmm12, [0x00007B6E1BFFE030]
00007b6e1c3cf918  jmp 0x00007B6E1C3CF4C5
00007b6e1c3cf91d  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf922  pextrw eax, xmm0, 0x03
00007b6e1c3cf927  and eax, 0x7FF8
00007b6e1c3cf92c  cmp eax, 0x08
00007b6e1c3cf92f  jnz 0x00007B6E1C3CF4C5
00007b6e1c3cf935  movq rax, xmm15
00007b6e1c3cf93a  shl rax, 0x0D
00007b6e1c3cf93e  jbe 0x00007B6E1C3CF4C5
00007b6e1c3cf944  vorps xmm12, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf94c  jmp 0x00007B6E1C3CF4C5
00007b6e1c3cf951  ucomisd xmm1, xmm15
00007b6e1c3cf956  jp 0x00007B6E1C3CF965
00007b6e1c3cf958  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cf960  jmp 0x00007B6E1C3CF4F2
00007b6e1c3cf965  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf96a  pextrw eax, xmm0, 0x03
00007b6e1c3cf96f  and eax, 0x7FF8
00007b6e1c3cf974  cmp eax, 0x08
00007b6e1c3cf977  jnz 0x00007B6E1C3CF4F2
00007b6e1c3cf97d  movq rax, xmm15
00007b6e1c3cf982  shl rax, 0x0D
00007b6e1c3cf986  jbe 0x00007B6E1C3CF4F2
00007b6e1c3cf98c  vorps xmm13, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf994  jmp 0x00007B6E1C3CF4F2
00007b6e1c3cf999  ucomisd xmm1, xmm15
00007b6e1c3cf99e  jp 0x00007B6E1C3CF9AD
00007b6e1c3cf9a0  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cf9a8  jmp 0x00007B6E1C3CF527
00007b6e1c3cf9ad  vxorps xmm0, xmm1, xmm15
00007b6e1c3cf9b2  pextrw eax, xmm0, 0x03
00007b6e1c3cf9b7  and eax, 0x7FF8
00007b6e1c3cf9bc  cmp eax, 0x08
00007b6e1c3cf9bf  jnz 0x00007B6E1C3CF527
00007b6e1c3cf9c5  movq rax, xmm15
00007b6e1c3cf9ca  shl rax, 0x0D
00007b6e1c3cf9ce  jbe 0x00007B6E1C3CF527
00007b6e1c3cf9d4  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cf9dc  jmp 0x00007B6E1C3CF527
00007b6e1c3cf9e1  call 0x00007B6E1C20A4B0
00007b6e1c3cf9e6  jmp 0x00007B6E1C3CF539
00007b6e1c3cf9eb  ucomisd xmm15, xmm14
00007b6e1c3cf9f0  jp 0x00007B6E1C3CF9FF
00007b6e1c3cf9f2  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cf9fa  jmp 0x00007B6E1C3CF566
00007b6e1c3cf9ff  vxorps xmm0, xmm15, xmm14
00007b6e1c3cfa04  pextrw eax, xmm0, 0x03
00007b6e1c3cfa09  and eax, 0x7FF8
00007b6e1c3cfa0e  cmp eax, 0x08
00007b6e1c3cfa11  jnz 0x00007B6E1C3CF566
00007b6e1c3cfa17  movq rax, xmm14
00007b6e1c3cfa1c  shl rax, 0x0D
00007b6e1c3cfa20  jbe 0x00007B6E1C3CF566
00007b6e1c3cfa26  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cfa2e  jmp 0x00007B6E1C3CF566
00007b6e1c3cfa33  ucomisd xmm1, xmm15
00007b6e1c3cfa38  jp 0x00007B6E1C3CFA47
00007b6e1c3cfa3a  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cfa42  jmp 0x00007B6E1C3CF59B
00007b6e1c3cfa47  vxorps xmm0, xmm1, xmm15
00007b6e1c3cfa4c  pextrw eax, xmm0, 0x03
00007b6e1c3cfa51  and eax, 0x7FF8
00007b6e1c3cfa56  cmp eax, 0x08
00007b6e1c3cfa59  jnz 0x00007B6E1C3CF59B
00007b6e1c3cfa5f  movq rax, xmm15
00007b6e1c3cfa64  shl rax, 0x0D
00007b6e1c3cfa68  jbe 0x00007B6E1C3CF59B
00007b6e1c3cfa6e  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cfa76  jmp 0x00007B6E1C3CF59B
00007b6e1c3cfa7b  call 0x00007B6E1C20A4B0
00007b6e1c3cfa80  jmp 0x00007B6E1C3CF5AD
00007b6e1c3cfa85  ucomisd xmm15, xmm14
00007b6e1c3cfa8a  jp 0x00007B6E1C3CFA99
00007b6e1c3cfa8c  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cfa94  jmp 0x00007B6E1C3CF5DA
00007b6e1c3cfa99  vxorps xmm0, xmm15, xmm14
00007b6e1c3cfa9e  pextrw eax, xmm0, 0x03
00007b6e1c3cfaa3  and eax, 0x7FF8
00007b6e1c3cfaa8  cmp eax, 0x08
00007b6e1c3cfaab  jnz 0x00007B6E1C3CF5DA
00007b6e1c3cfab1  movq rax, xmm14
00007b6e1c3cfab6  shl rax, 0x0D
00007b6e1c3cfaba  jbe 0x00007B6E1C3CF5DA
00007b6e1c3cfac0  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cfac8  jmp 0x00007B6E1C3CF5DA
00007b6e1c3cfacd  ucomisd xmm1, xmm15
00007b6e1c3cfad2  jp 0x00007B6E1C3CFAE1
00007b6e1c3cfad4  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cfadc  jmp 0x00007B6E1C3CF60F
00007b6e1c3cfae1  vxorps xmm0, xmm1, xmm15
00007b6e1c3cfae6  pextrw eax, xmm0, 0x03
00007b6e1c3cfaeb  and eax, 0x7FF8
00007b6e1c3cfaf0  cmp eax, 0x08
00007b6e1c3cfaf3  jnz 0x00007B6E1C3CF60F
00007b6e1c3cfaf9  movq rax, xmm15
00007b6e1c3cfafe  shl rax, 0x0D
00007b6e1c3cfb02  jbe 0x00007B6E1C3CF60F
00007b6e1c3cfb08  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cfb10  jmp 0x00007B6E1C3CF60F
00007b6e1c3cfb15  call 0x00007B6E1C20A4B0
00007b6e1c3cfb1a  jmp 0x00007B6E1C3CF621
00007b6e1c3cfb1f  ucomisd xmm15, xmm14
00007b6e1c3cfb24  jp 0x00007B6E1C3CFB33
00007b6e1c3cfb26  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cfb2e  jmp 0x00007B6E1C3CF64E
00007b6e1c3cfb33  vxorps xmm0, xmm15, xmm14
00007b6e1c3cfb38  pextrw eax, xmm0, 0x03
00007b6e1c3cfb3d  and eax, 0x7FF8
00007b6e1c3cfb42  cmp eax, 0x08
00007b6e1c3cfb45  jnz 0x00007B6E1C3CF64E
00007b6e1c3cfb4b  movq rax, xmm14
00007b6e1c3cfb50  shl rax, 0x0D
00007b6e1c3cfb54  jbe 0x00007B6E1C3CF64E
00007b6e1c3cfb5a  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cfb62  jmp 0x00007B6E1C3CF64E
00007b6e1c3cfb67  ucomisd xmm1, xmm15
00007b6e1c3cfb6c  jp 0x00007B6E1C3CFB7B
00007b6e1c3cfb6e  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cfb76  jmp 0x00007B6E1C3CF683
00007b6e1c3cfb7b  vxorps xmm0, xmm1, xmm15
00007b6e1c3cfb80  pextrw eax, xmm0, 0x03
00007b6e1c3cfb85  and eax, 0x7FF8
00007b6e1c3cfb8a  cmp eax, 0x08
00007b6e1c3cfb8d  jnz 0x00007B6E1C3CF683
00007b6e1c3cfb93  movq rax, xmm15
00007b6e1c3cfb98  shl rax, 0x0D
00007b6e1c3cfb9c  jbe 0x00007B6E1C3CF683
00007b6e1c3cfba2  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cfbaa  jmp 0x00007B6E1C3CF683
00007b6e1c3cfbaf  call 0x00007B6E1C20A4B0
00007b6e1c3cfbb4  jmp 0x00007B6E1C3CF695
00007b6e1c3cfbb9  ucomisd xmm15, xmm14
00007b6e1c3cfbbe  jp 0x00007B6E1C3CFBCD
00007b6e1c3cfbc0  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cfbc8  jmp 0x00007B6E1C3CF6C2
00007b6e1c3cfbcd  vxorps xmm0, xmm15, xmm14
00007b6e1c3cfbd2  pextrw eax, xmm0, 0x03
00007b6e1c3cfbd7  and eax, 0x7FF8
00007b6e1c3cfbdc  cmp eax, 0x08
00007b6e1c3cfbdf  jnz 0x00007B6E1C3CF6C2
00007b6e1c3cfbe5  movq rax, xmm14
00007b6e1c3cfbea  shl rax, 0x0D
00007b6e1c3cfbee  jbe 0x00007B6E1C3CF6C2
00007b6e1c3cfbf4  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cfbfc  jmp 0x00007B6E1C3CF6C2
00007b6e1c3cfc01  ucomisd xmm1, xmm15
00007b6e1c3cfc06  jp 0x00007B6E1C3CFC15
00007b6e1c3cfc08  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cfc10  jmp 0x00007B6E1C3CF6F7
00007b6e1c3cfc15  vxorps xmm0, xmm1, xmm15
00007b6e1c3cfc1a  pextrw eax, xmm0, 0x03
00007b6e1c3cfc1f  and eax, 0x7FF8
00007b6e1c3cfc24  cmp eax, 0x08
00007b6e1c3cfc27  jnz 0x00007B6E1C3CF6F7
00007b6e1c3cfc2d  movq rax, xmm15
00007b6e1c3cfc32  shl rax, 0x0D
00007b6e1c3cfc36  jbe 0x00007B6E1C3CF6F7
00007b6e1c3cfc3c  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cfc44  jmp 0x00007B6E1C3CF6F7
00007b6e1c3cfc49  call 0x00007B6E1C20B720
00007b6e1c3cfc4e  jmp 0x00007B6E1C3CF709
00007b6e1c3cfc53  ucomisd xmm15, xmm14
00007b6e1c3cfc58  jp 0x00007B6E1C3CFC67
00007b6e1c3cfc5a  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3cfc62  jmp 0x00007B6E1C3CF73E
00007b6e1c3cfc67  vxorps xmm0, xmm15, xmm14
00007b6e1c3cfc6c  pextrw eax, xmm0, 0x03
00007b6e1c3cfc71  and eax, 0x7FF8
00007b6e1c3cfc76  cmp eax, 0x08
00007b6e1c3cfc79  jnz 0x00007B6E1C3CF73E
00007b6e1c3cfc7f  movq rax, xmm14
00007b6e1c3cfc84  shl rax, 0x0D
00007b6e1c3cfc88  jbe 0x00007B6E1C3CF73E
00007b6e1c3cfc8e  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3cfc96  jmp 0x00007B6E1C3CF73E
00007b6e1c3cfc9b  ucomisd xmm1, xmm15
00007b6e1c3cfca0  jp 0x00007B6E1C3CFCAF
00007b6e1c3cfca2  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cfcaa  jmp 0x00007B6E1C3CF773
00007b6e1c3cfcaf  vxorps xmm0, xmm1, xmm15
00007b6e1c3cfcb4  pextrw eax, xmm0, 0x03
00007b6e1c3cfcb9  and eax, 0x7FF8
00007b6e1c3cfcbe  cmp eax, 0x08
00007b6e1c3cfcc1  jnz 0x00007B6E1C3CF773
00007b6e1c3cfcc7  movq rax, xmm15
00007b6e1c3cfccc  shl rax, 0x0D
00007b6e1c3cfcd0  jbe 0x00007B6E1C3CF773
00007b6e1c3cfcd6  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cfcde  jmp 0x00007B6E1C3CF773
00007b6e1c3cfce3  ucomisd xmm1, xmm15
00007b6e1c3cfce8  jp 0x00007B6E1C3CFCF7
00007b6e1c3cfcea  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3cfcf2  jmp 0x00007B6E1C3CF7A8
00007b6e1c3cfcf7  vxorps xmm0, xmm1, xmm15
00007b6e1c3cfcfc  pextrw eax, xmm0, 0x03
00007b6e1c3cfd01  and eax, 0x7FF8
00007b6e1c3cfd06  cmp eax, 0x08
00007b6e1c3cfd09  jnz 0x00007B6E1C3CF7A8
00007b6e1c3cfd0f  movq rax, xmm15
00007b6e1c3cfd14  shl rax, 0x0D
00007b6e1c3cfd18  jbe 0x00007B6E1C3CF7A8
00007b6e1c3cfd1e  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3cfd26  jmp 0x00007B6E1C3CF7A8
00007b6e1c3cfd2b  call 0x00007B6E1C2B4CB0
00007b6e1c3cfd30  jmp 0x00007B6E1C3CF7C7
00007b6e1c3cfd35  int3
00007b6e1c3cfd36  nop [rax+rax*1], ax
00007b6e1c3cfd3f  nop
00007b6e1c3cfd40  mov rax, [r15+0x60]
00007b6e1c3cfd44  lea r14, [rax+0x01]
00007b6e1c3cfd48  mov [r15+0x60], r14
00007b6e1c3cfd4c  mov rax, [r15+0x68]
00007b6e1c3cfd50  lea r12, [rax+0x40]
00007b6e1c3cfd54  mov [r15+0x68], r12
00007b6e1c3cfd58  xor eax, eax
00007b6e1c3cfd5a  mov r12d, 0x08
00007b6e1c3cfd60  cmp r14, r12
00007b6e1c3cfd63  cmc
00007b6e1c3cfd64  lahf
00007b6e1c3cfd65  seto al
00007b6e1c3cfd68  mov [r15+0x108], eax
00007b6e1c3cfd6f  mov eax, [r15+0x108]
00007b6e1c3cfd76  sahf
00007b6e1c3cfd77  jnz 0x00007B6E1C3CFDA9
00007b6e1c3cfd79  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3cfd81  jz 0x00007B6E1C3D08A0
00007b6e1c3cfd87  nop [rax+rax*1], ax
00007b6e1c3cfd90  nop [rax+rax*1], eax
00007b6e1c3cfd98  mov eax, 0x410128
00007b6e1c3cfd9d  mov [r15+0x100], rax
00007b6e1c3cfda4  jmp 0x00007B6E1C1FE110
00007b6e1c3cfda9  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3cfdb1  jz 0x00007B6E1C3CFDE0
00007b6e1c3cfdb7  nop [rax+rax*1], ax
00007b6e1c3cfdc0  nop [rax+rax*1], eax
00007b6e1c3cfdc8  mov eax, 0x41008C
00007b6e1c3cfdcd  mov [r15+0x100], rax
00007b6e1c3cfdd4  jmp 0x00007B6E1C1FE110
00007b6e1c3cfdd9  int3
00007b6e1c3cfdda  int3
00007b6e1c3cfddb  nop [rax+rax*1], eax
00007b6e1c3cfde0  mov rax, [r15+0x40]
00007b6e1c3cfde4  mov r14, [r15+0x60]
00007b6e1c3cfde8  shl r14, 0x06
00007b6e1c3cfdec  lea r12, [rax+r14*1]
00007b6e1c3cfdf0  mov rax, [r13+r12*1]
00007b6e1c3cfdf5  lea r14, [r12+0x08]
00007b6e1c3cfdfa  mov r11, [r13+r14*1]
00007b6e1c3cfdff  movq xmm1, rax
00007b6e1c3cfe04  movq xmm15, r11
00007b6e1c3cfe09  movq xmm1, xmm1
00007b6e1c3cfe0d  movq xmm1, xmm1
00007b6e1c3cfe11  movaps [r15+0x120], xmm1
00007b6e1c3cfe19  movq xmm15, xmm15
00007b6e1c3cfe1e  movq xmm15, xmm15
00007b6e1c3cfe23  movaps [r15+0x130], xmm15
00007b6e1c3cfe2b  lea rax, [r12+0x10]
00007b6e1c3cfe30  mov r14, [r13+rax*1]
00007b6e1c3cfe35  lea rax, [r12+0x18]
00007b6e1c3cfe3a  mov r11, [r13+rax*1]
00007b6e1c3cfe3f  movq xmm1, r14
00007b6e1c3cfe44  movq xmm15, r11
00007b6e1c3cfe49  movq xmm1, xmm1
00007b6e1c3cfe4d  movq xmm1, xmm1
00007b6e1c3cfe51  movaps [r15+0x140], xmm1
00007b6e1c3cfe59  movq xmm15, xmm15
00007b6e1c3cfe5e  movq xmm15, xmm15
00007b6e1c3cfe63  movaps [r15+0x150], xmm15
00007b6e1c3cfe6b  lea rax, [r12+0x20]
00007b6e1c3cfe70  mov r14, [r13+rax*1]
00007b6e1c3cfe75  lea rax, [r12+0x28]
00007b6e1c3cfe7a  mov r11, [r13+rax*1]
00007b6e1c3cfe7f  movq xmm1, r14
00007b6e1c3cfe84  movq xmm15, r11
00007b6e1c3cfe89  movq xmm1, xmm1
00007b6e1c3cfe8d  movq xmm1, xmm1
00007b6e1c3cfe91  movaps [r15+0x160], xmm1
00007b6e1c3cfe99  movq xmm15, xmm15
00007b6e1c3cfe9e  movq xmm15, xmm15
00007b6e1c3cfea3  movaps [r15+0x170], xmm15
00007b6e1c3cfeab  lea rax, [r12+0x30]
00007b6e1c3cfeb0  mov r14, [r13+rax*1]
00007b6e1c3cfeb5  lea rax, [r12+0x38]
00007b6e1c3cfeba  mov r12, [r13+rax*1]
00007b6e1c3cfebf  movq xmm1, r14
00007b6e1c3cfec4  movq xmm15, r12
00007b6e1c3cfec9  movq xmm1, xmm1
00007b6e1c3cfecd  movq xmm1, xmm1
00007b6e1c3cfed1  movaps [r15+0x180], xmm1
00007b6e1c3cfed9  movq xmm15, xmm15
00007b6e1c3cfede  movq xmm15, xmm15
00007b6e1c3cfee3  movaps [r15+0x210], xmm15
00007b6e1c3cfeeb  mov rax, [r15+0x48]
00007b6e1c3cfeef  mov [r15+0x78], rax
00007b6e1c3cfef3  mov r14, [r13+rax*1]
00007b6e1c3cfef8  movq xmm1, r14
00007b6e1c3cfefd  lea r14, [rax+0x40]
00007b6e1c3cff01  mov r12, [r13+r14*1]
00007b6e1c3cff06  movq xmm15, r12
00007b6e1c3cff0b  lea r14, [rax+0x80]
00007b6e1c3cff12  mov r12, [r13+r14*1]
00007b6e1c3cff17  movq xmm14, r12
00007b6e1c3cff1c  movaps xmm13, [r15+0x120]
00007b6e1c3cff24  movq r14, xmm13
00007b6e1c3cff29  movq r12, xmm1
00007b6e1c3cff2e  vmovq xmm1, r14
00007b6e1c3cff33  vmovq xmm13, r12
00007b6e1c3cff38  movaps xmm12, xmm1
00007b6e1c3cff3c  mulsd xmm12, xmm13
00007b6e1c3cff41  ucomisd xmm12, xmm12
00007b6e1c3cff46  jp 0x00007B6E1C3D03AD
00007b6e1c3cff4c  movq xmm12, xmm12
00007b6e1c3cff51  movaps xmm1, [r15+0x130]
00007b6e1c3cff59  movq r14, xmm1
00007b6e1c3cff5e  movq r12, xmm15
00007b6e1c3cff63  vmovq xmm1, r14
00007b6e1c3cff68  vmovq xmm15, r12
00007b6e1c3cff6d  movaps xmm13, xmm1
00007b6e1c3cff71  mulsd xmm13, xmm15
00007b6e1c3cff76  ucomisd xmm13, xmm13
00007b6e1c3cff7b  jp 0x00007B6E1C3D03F9
00007b6e1c3cff81  movq xmm13, xmm13
00007b6e1c3cff86  movq r14, xmm12
00007b6e1c3cff8b  movaps xmm1, [r15+0x110]
00007b6e1c3cff93  movq r12, xmm1
00007b6e1c3cff98  vmovq xmm1, r14
00007b6e1c3cff9d  vmovq xmm15, r12
00007b6e1c3cffa2  movaps xmm12, xmm1
00007b6e1c3cffa6  addsd xmm12, xmm15
00007b6e1c3cffab  ucomisd xmm12, xmm12
00007b6e1c3cffb0  jp 0x00007B6E1C3D0445
00007b6e1c3cffb6  movq xmm12, xmm12
00007b6e1c3cffbb  movq r14, xmm12
00007b6e1c3cffc0  movq r12, xmm13
00007b6e1c3cffc5  vmovq xmm1, r14
00007b6e1c3cffca  vmovq xmm15, r12
00007b6e1c3cffcf  movaps xmm13, xmm1
00007b6e1c3cffd3  addsd xmm13, xmm15
00007b6e1c3cffd8  ucomisd xmm13, xmm13
00007b6e1c3cffdd  jp 0x00007B6E1C3D0491
00007b6e1c3cffe3  movq xmm13, xmm13
00007b6e1c3cffe8  movaps xmm1, [r15+0x140]
00007b6e1c3cfff0  movq r14, xmm1
00007b6e1c3cfff5  movq r12, xmm14
00007b6e1c3cfffa  vmovq xmm1, r14
00007b6e1c3cffff  vmovq xmm15, r12
00007b6e1c3d0004  movaps xmm14, xmm1
00007b6e1c3d0008  mulsd xmm14, xmm15
00007b6e1c3d000d  ucomisd xmm14, xmm14
00007b6e1c3d0012  jp 0x00007B6E1C3D04DD
00007b6e1c3d0018  movq xmm14, xmm14
00007b6e1c3d001d  lea r14, [rax+0xC0]
00007b6e1c3d0024  mov r12, [r13+r14*1]
00007b6e1c3d0029  movq xmm1, r12
00007b6e1c3d002e  movq r14, xmm13
00007b6e1c3d0033  movq r12, xmm14
00007b6e1c3d0038  vmovq xmm15, r14
00007b6e1c3d003d  vmovq xmm14, r12
00007b6e1c3d0042  movaps xmm13, xmm15
00007b6e1c3d0046  addsd xmm13, xmm14
00007b6e1c3d004b  ucomisd xmm13, xmm13
00007b6e1c3d0050  jp 0x00007B6E1C3D0533
00007b6e1c3d0056  movq xmm13, xmm13
00007b6e1c3d005b  movaps xmm15, [r15+0x150]
00007b6e1c3d0063  movq r14, xmm15
00007b6e1c3d0068  movq r12, xmm1
00007b6e1c3d006d  vmovq xmm1, r14
00007b6e1c3d0072  vmovq xmm15, r12
00007b6e1c3d0077  movaps xmm14, xmm1
00007b6e1c3d007b  mulsd xmm14, xmm15
00007b6e1c3d0080  ucomisd xmm14, xmm14
00007b6e1c3d0085  jp 0x00007B6E1C3D057F
00007b6e1c3d008b  movq xmm14, xmm14
00007b6e1c3d0090  lea r14, [rax+0x100]
00007b6e1c3d0097  mov r12, [r13+r14*1]
00007b6e1c3d009c  movq xmm1, r12
00007b6e1c3d00a1  movq r14, xmm13
00007b6e1c3d00a6  movq r12, xmm14
00007b6e1c3d00ab  vmovq xmm15, r14
00007b6e1c3d00b0  vmovq xmm14, r12
00007b6e1c3d00b5  movaps xmm13, xmm15
00007b6e1c3d00b9  addsd xmm13, xmm14
00007b6e1c3d00be  ucomisd xmm13, xmm13
00007b6e1c3d00c3  jp 0x00007B6E1C3D05D5
00007b6e1c3d00c9  movq xmm13, xmm13
00007b6e1c3d00ce  movaps xmm15, [r15+0x160]
00007b6e1c3d00d6  movq r14, xmm15
00007b6e1c3d00db  movq r12, xmm1
00007b6e1c3d00e0  vmovq xmm1, r14
00007b6e1c3d00e5  vmovq xmm15, r12
00007b6e1c3d00ea  movaps xmm14, xmm1
00007b6e1c3d00ee  mulsd xmm14, xmm15
00007b6e1c3d00f3  ucomisd xmm14, xmm14
00007b6e1c3d00f8  jp 0x00007B6E1C3D0621
00007b6e1c3d00fe  movq xmm14, xmm14
00007b6e1c3d0103  lea r14, [rax+0x140]
00007b6e1c3d010a  mov r12, [r13+r14*1]
00007b6e1c3d010f  movq xmm1, r12
00007b6e1c3d0114  movq r14, xmm13
00007b6e1c3d0119  movq r12, xmm14
00007b6e1c3d011e  vmovq xmm15, r14
00007b6e1c3d0123  vmovq xmm14, r12
00007b6e1c3d0128  movaps xmm13, xmm15
00007b6e1c3d012c  addsd xmm13, xmm14
00007b6e1c3d0131  ucomisd xmm13, xmm13
00007b6e1c3d0136  jp 0x00007B6E1C3D0677
00007b6e1c3d013c  movq xmm13, xmm13
00007b6e1c3d0141  movaps xmm15, [r15+0x170]
00007b6e1c3d0149  movq r14, xmm15
00007b6e1c3d014e  movq r12, xmm1
00007b6e1c3d0153  vmovq xmm1, r14
00007b6e1c3d0158  vmovq xmm15, r12
00007b6e1c3d015d  movaps xmm14, xmm1
00007b6e1c3d0161  mulsd xmm14, xmm15
00007b6e1c3d0166  ucomisd xmm14, xmm14
00007b6e1c3d016b  jp 0x00007B6E1C3D06C3
00007b6e1c3d0171  movq xmm14, xmm14
00007b6e1c3d0176  lea r14, [rax+0x180]
00007b6e1c3d017d  mov r12, [r13+r14*1]
00007b6e1c3d0182  movq xmm1, r12
00007b6e1c3d0187  movq r14, xmm13
00007b6e1c3d018c  movq r12, xmm14
00007b6e1c3d0191  vmovq xmm15, r14
00007b6e1c3d0196  vmovq xmm14, r12
00007b6e1c3d019b  movaps xmm13, xmm15
00007b6e1c3d019f  addsd xmm13, xmm14
00007b6e1c3d01a4  ucomisd xmm13, xmm13
00007b6e1c3d01a9  jp 0x00007B6E1C3D0719
00007b6e1c3d01af  movq xmm13, xmm13
00007b6e1c3d01b4  movaps xmm15, [r15+0x180]
00007b6e1c3d01bc  movq r14, xmm15
00007b6e1c3d01c1  movq r12, xmm1
00007b6e1c3d01c6  vmovq xmm1, r14
00007b6e1c3d01cb  vmovq xmm15, r12
00007b6e1c3d01d0  movaps xmm14, xmm1
00007b6e1c3d01d4  mulsd xmm14, xmm15
00007b6e1c3d01d9  ucomisd xmm14, xmm14
00007b6e1c3d01de  jp 0x00007B6E1C3D0765
00007b6e1c3d01e4  movq xmm14, xmm14
00007b6e1c3d01e9  lea r14, [rax+0x1C0]
00007b6e1c3d01f0  mov rax, [r13+r14*1]
00007b6e1c3d01f5  movq xmm1, rax
00007b6e1c3d01fa  movaps [r15+0x240], xmm1
00007b6e1c3d0202  movq rax, xmm13
00007b6e1c3d0207  movq r14, xmm14
00007b6e1c3d020c  vmovq xmm15, rax
00007b6e1c3d0211  vmovq xmm14, r14
00007b6e1c3d0216  movaps xmm13, xmm15
00007b6e1c3d021a  addsd xmm13, xmm14
00007b6e1c3d021f  ucomisd xmm13, xmm13
00007b6e1c3d0224  jp 0x00007B6E1C3D07BB
00007b6e1c3d022a  movq xmm13, xmm13
00007b6e1c3d022f  movaps xmm15, [r15+0x210]
00007b6e1c3d0237  movq rax, xmm15
00007b6e1c3d023c  movq r14, xmm1
00007b6e1c3d0241  vmovq xmm1, rax
00007b6e1c3d0246  vmovq xmm15, r14
00007b6e1c3d024b  movaps xmm14, xmm1
00007b6e1c3d024f  mulsd xmm14, xmm15
00007b6e1c3d0254  ucomisd xmm14, xmm14
00007b6e1c3d0259  jp 0x00007B6E1C3D0803
00007b6e1c3d025f  movq xmm14, xmm14
00007b6e1c3d0264  movaps [r15+0x230], xmm14
00007b6e1c3d026c  movq rax, xmm13
00007b6e1c3d0271  movq r14, xmm14
00007b6e1c3d0276  vmovq xmm1, rax
00007b6e1c3d027b  vmovq xmm15, r14
00007b6e1c3d0280  movaps xmm14, xmm1
00007b6e1c3d0284  addsd xmm14, xmm15
00007b6e1c3d0289  ucomisd xmm14, xmm14
00007b6e1c3d028e  jp 0x00007B6E1C3D084B
00007b6e1c3d0294  movq xmm14, xmm14
00007b6e1c3d0299  movaps [r15+0x220], xmm14
00007b6e1c3d02a1  mov rax, [r15+0x68]
00007b6e1c3d02a5  movq r14, xmm14
00007b6e1c3d02aa  mov [r13+rax*1], r14
00007b6e1c3d02af  mov qword ptr [r15+0x70], 0x08
00007b6e1c3d02b7  xor eax, eax
00007b6e1c3d02b9  mov r14d, 0x08
00007b6e1c3d02bf  mov r12d, 0x40
00007b6e1c3d02c5  cmp r14, r12
00007b6e1c3d02c8  cmc
00007b6e1c3d02c9  lahf
00007b6e1c3d02ca  seto al
00007b6e1c3d02cd  mov [r15+0x108], eax
00007b6e1c3d02d4  mov eax, [r15+0x108]
00007b6e1c3d02db  sahf
00007b6e1c3d02dc  jnz 0x00007B6E1C3D030E
00007b6e1c3d02de  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d02e6  jz 0x00007B6E1C3CFD40
00007b6e1c3d02ec  nop [rax+rax*1], ax
00007b6e1c3d02f5  nop [rax+rax*1], eax
00007b6e1c3d02fd  mov eax, 0x410118
00007b6e1c3d0302  mov [r15+0x100], rax
00007b6e1c3d0309  jmp 0x00007B6E1C1FE110
00007b6e1c3d030e  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d0316  jz 0x00007B6E1C3CF3F0
00007b6e1c3d031c  nop [rax+rax*1], ax
00007b6e1c3d0325  nop [rax+rax*1], eax
00007b6e1c3d032d  mov eax, 0x4100A4
00007b6e1c3d0332  mov [r15+0x100], rax
00007b6e1c3d0339  jmp 0x00007B6E1C1FE110
00007b6e1c3d033e  int3
00007b6e1c3d033f  call 0x00007B6E1C2B47C0
00007b6e1c3d0344  jmp 0x00007B6E1C3CFDF5
00007b6e1c3d0349  call 0x00007B6E1C2E1570
00007b6e1c3d034e  jmp 0x00007B6E1C3CFDFF
00007b6e1c3d0353  call 0x00007B6E1C20DC20
00007b6e1c3d0358  jmp 0x00007B6E1C3CFE35
00007b6e1c3d035d  call 0x00007B6E1C20A4B0
00007b6e1c3d0362  jmp 0x00007B6E1C3CFE3F
00007b6e1c3d0367  call 0x00007B6E1C20DC20
00007b6e1c3d036c  jmp 0x00007B6E1C3CFE75
00007b6e1c3d0371  call 0x00007B6E1C20A4B0
00007b6e1c3d0376  jmp 0x00007B6E1C3CFE7F
00007b6e1c3d037b  call 0x00007B6E1C20DC20
00007b6e1c3d0380  jmp 0x00007B6E1C3CFEB5
00007b6e1c3d0385  call 0x00007B6E1C20B720
00007b6e1c3d038a  jmp 0x00007B6E1C3CFEBF
00007b6e1c3d038f  call 0x00007B6E1C20DC20
00007b6e1c3d0394  jmp 0x00007B6E1C3CFEF8
00007b6e1c3d0399  call 0x00007B6E1C2E27E0
00007b6e1c3d039e  jmp 0x00007B6E1C3CFF06
00007b6e1c3d03a3  call 0x00007B6E1C2E27E0
00007b6e1c3d03a8  jmp 0x00007B6E1C3CFF17
00007b6e1c3d03ad  ucomisd xmm1, xmm13
00007b6e1c3d03b2  jp 0x00007B6E1C3D03C1
00007b6e1c3d03b4  movaps xmm12, [0x00007B6E1BFFE030]
00007b6e1c3d03bc  jmp 0x00007B6E1C3CFF4C
00007b6e1c3d03c1  vxorps xmm0, xmm1, xmm13
00007b6e1c3d03c6  pextrw r14d, xmm0, 0x03
00007b6e1c3d03cc  and r14d, 0x7FF8
00007b6e1c3d03d3  cmp r14d, 0x08
00007b6e1c3d03d7  jnz 0x00007B6E1C3CFF4C
00007b6e1c3d03dd  movq r14, xmm13
00007b6e1c3d03e2  shl r14, 0x0D
00007b6e1c3d03e6  jbe 0x00007B6E1C3CFF4C
00007b6e1c3d03ec  vorps xmm12, xmm13, [0x00007B6E1BFFE040]
00007b6e1c3d03f4  jmp 0x00007B6E1C3CFF4C
00007b6e1c3d03f9  ucomisd xmm1, xmm15
00007b6e1c3d03fe  jp 0x00007B6E1C3D040D
00007b6e1c3d0400  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d0408  jmp 0x00007B6E1C3CFF81
00007b6e1c3d040d  vxorps xmm0, xmm1, xmm15
00007b6e1c3d0412  pextrw r14d, xmm0, 0x03
00007b6e1c3d0418  and r14d, 0x7FF8
00007b6e1c3d041f  cmp r14d, 0x08
00007b6e1c3d0423  jnz 0x00007B6E1C3CFF81
00007b6e1c3d0429  movq r14, xmm15
00007b6e1c3d042e  shl r14, 0x0D
00007b6e1c3d0432  jbe 0x00007B6E1C3CFF81
00007b6e1c3d0438  vorps xmm13, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d0440  jmp 0x00007B6E1C3CFF81
00007b6e1c3d0445  ucomisd xmm1, xmm15
00007b6e1c3d044a  jp 0x00007B6E1C3D0459
00007b6e1c3d044c  movaps xmm12, [0x00007B6E1BFFE030]
00007b6e1c3d0454  jmp 0x00007B6E1C3CFFB6
00007b6e1c3d0459  vxorps xmm0, xmm1, xmm15
00007b6e1c3d045e  pextrw r14d, xmm0, 0x03
00007b6e1c3d0464  and r14d, 0x7FF8
00007b6e1c3d046b  cmp r14d, 0x08
00007b6e1c3d046f  jnz 0x00007B6E1C3CFFB6
00007b6e1c3d0475  movq r14, xmm15
00007b6e1c3d047a  shl r14, 0x0D
00007b6e1c3d047e  jbe 0x00007B6E1C3CFFB6
00007b6e1c3d0484  vorps xmm12, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d048c  jmp 0x00007B6E1C3CFFB6
00007b6e1c3d0491  ucomisd xmm1, xmm15
00007b6e1c3d0496  jp 0x00007B6E1C3D04A5
00007b6e1c3d0498  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d04a0  jmp 0x00007B6E1C3CFFE3
00007b6e1c3d04a5  vxorps xmm0, xmm1, xmm15
00007b6e1c3d04aa  pextrw r14d, xmm0, 0x03
00007b6e1c3d04b0  and r14d, 0x7FF8
00007b6e1c3d04b7  cmp r14d, 0x08
00007b6e1c3d04bb  jnz 0x00007B6E1C3CFFE3
00007b6e1c3d04c1  movq r14, xmm15
00007b6e1c3d04c6  shl r14, 0x0D
00007b6e1c3d04ca  jbe 0x00007B6E1C3CFFE3
00007b6e1c3d04d0  vorps xmm13, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d04d8  jmp 0x00007B6E1C3CFFE3
00007b6e1c3d04dd  ucomisd xmm1, xmm15
00007b6e1c3d04e2  jp 0x00007B6E1C3D04F1
00007b6e1c3d04e4  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d04ec  jmp 0x00007B6E1C3D0018
00007b6e1c3d04f1  vxorps xmm0, xmm1, xmm15
00007b6e1c3d04f6  pextrw r14d, xmm0, 0x03
00007b6e1c3d04fc  and r14d, 0x7FF8
00007b6e1c3d0503  cmp r14d, 0x08
00007b6e1c3d0507  jnz 0x00007B6E1C3D0018
00007b6e1c3d050d  movq r14, xmm15
00007b6e1c3d0512  shl r14, 0x0D
00007b6e1c3d0516  jbe 0x00007B6E1C3D0018
00007b6e1c3d051c  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d0524  jmp 0x00007B6E1C3D0018
00007b6e1c3d0529  call 0x00007B6E1C2E27E0
00007b6e1c3d052e  jmp 0x00007B6E1C3D0029
00007b6e1c3d0533  ucomisd xmm15, xmm14
00007b6e1c3d0538  jp 0x00007B6E1C3D0547
00007b6e1c3d053a  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d0542  jmp 0x00007B6E1C3D0056
00007b6e1c3d0547  vxorps xmm0, xmm15, xmm14
00007b6e1c3d054c  pextrw r14d, xmm0, 0x03
00007b6e1c3d0552  and r14d, 0x7FF8
00007b6e1c3d0559  cmp r14d, 0x08
00007b6e1c3d055d  jnz 0x00007B6E1C3D0056
00007b6e1c3d0563  movq r14, xmm14
00007b6e1c3d0568  shl r14, 0x0D
00007b6e1c3d056c  jbe 0x00007B6E1C3D0056
00007b6e1c3d0572  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d057a  jmp 0x00007B6E1C3D0056
00007b6e1c3d057f  ucomisd xmm1, xmm15
00007b6e1c3d0584  jp 0x00007B6E1C3D0593
00007b6e1c3d0586  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d058e  jmp 0x00007B6E1C3D008B
00007b6e1c3d0593  vxorps xmm0, xmm1, xmm15
00007b6e1c3d0598  pextrw r14d, xmm0, 0x03
00007b6e1c3d059e  and r14d, 0x7FF8
00007b6e1c3d05a5  cmp r14d, 0x08
00007b6e1c3d05a9  jnz 0x00007B6E1C3D008B
00007b6e1c3d05af  movq r14, xmm15
00007b6e1c3d05b4  shl r14, 0x0D
00007b6e1c3d05b8  jbe 0x00007B6E1C3D008B
00007b6e1c3d05be  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d05c6  jmp 0x00007B6E1C3D008B
00007b6e1c3d05cb  call 0x00007B6E1C2E27E0
00007b6e1c3d05d0  jmp 0x00007B6E1C3D009C
00007b6e1c3d05d5  ucomisd xmm15, xmm14
00007b6e1c3d05da  jp 0x00007B6E1C3D05E9
00007b6e1c3d05dc  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d05e4  jmp 0x00007B6E1C3D00C9
00007b6e1c3d05e9  vxorps xmm0, xmm15, xmm14
00007b6e1c3d05ee  pextrw r14d, xmm0, 0x03
00007b6e1c3d05f4  and r14d, 0x7FF8
00007b6e1c3d05fb  cmp r14d, 0x08
00007b6e1c3d05ff  jnz 0x00007B6E1C3D00C9
00007b6e1c3d0605  movq r14, xmm14
00007b6e1c3d060a  shl r14, 0x0D
00007b6e1c3d060e  jbe 0x00007B6E1C3D00C9
00007b6e1c3d0614  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d061c  jmp 0x00007B6E1C3D00C9
00007b6e1c3d0621  ucomisd xmm1, xmm15
00007b6e1c3d0626  jp 0x00007B6E1C3D0635
00007b6e1c3d0628  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d0630  jmp 0x00007B6E1C3D00FE
00007b6e1c3d0635  vxorps xmm0, xmm1, xmm15
00007b6e1c3d063a  pextrw r14d, xmm0, 0x03
00007b6e1c3d0640  and r14d, 0x7FF8
00007b6e1c3d0647  cmp r14d, 0x08
00007b6e1c3d064b  jnz 0x00007B6E1C3D00FE
00007b6e1c3d0651  movq r14, xmm15
00007b6e1c3d0656  shl r14, 0x0D
00007b6e1c3d065a  jbe 0x00007B6E1C3D00FE
00007b6e1c3d0660  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d0668  jmp 0x00007B6E1C3D00FE
00007b6e1c3d066d  call 0x00007B6E1C2E27E0
00007b6e1c3d0672  jmp 0x00007B6E1C3D010F
00007b6e1c3d0677  ucomisd xmm15, xmm14
00007b6e1c3d067c  jp 0x00007B6E1C3D068B
00007b6e1c3d067e  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d0686  jmp 0x00007B6E1C3D013C
00007b6e1c3d068b  vxorps xmm0, xmm15, xmm14
00007b6e1c3d0690  pextrw r14d, xmm0, 0x03
00007b6e1c3d0696  and r14d, 0x7FF8
00007b6e1c3d069d  cmp r14d, 0x08
00007b6e1c3d06a1  jnz 0x00007B6E1C3D013C
00007b6e1c3d06a7  movq r14, xmm14
00007b6e1c3d06ac  shl r14, 0x0D
00007b6e1c3d06b0  jbe 0x00007B6E1C3D013C
00007b6e1c3d06b6  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d06be  jmp 0x00007B6E1C3D013C
00007b6e1c3d06c3  ucomisd xmm1, xmm15
00007b6e1c3d06c8  jp 0x00007B6E1C3D06D7
00007b6e1c3d06ca  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d06d2  jmp 0x00007B6E1C3D0171
00007b6e1c3d06d7  vxorps xmm0, xmm1, xmm15
00007b6e1c3d06dc  pextrw r14d, xmm0, 0x03
00007b6e1c3d06e2  and r14d, 0x7FF8
00007b6e1c3d06e9  cmp r14d, 0x08
00007b6e1c3d06ed  jnz 0x00007B6E1C3D0171
00007b6e1c3d06f3  movq r14, xmm15
00007b6e1c3d06f8  shl r14, 0x0D
00007b6e1c3d06fc  jbe 0x00007B6E1C3D0171
00007b6e1c3d0702  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d070a  jmp 0x00007B6E1C3D0171
00007b6e1c3d070f  call 0x00007B6E1C2E27E0
00007b6e1c3d0714  jmp 0x00007B6E1C3D0182
00007b6e1c3d0719  ucomisd xmm15, xmm14
00007b6e1c3d071e  jp 0x00007B6E1C3D072D
00007b6e1c3d0720  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d0728  jmp 0x00007B6E1C3D01AF
00007b6e1c3d072d  vxorps xmm0, xmm15, xmm14
00007b6e1c3d0732  pextrw r14d, xmm0, 0x03
00007b6e1c3d0738  and r14d, 0x7FF8
00007b6e1c3d073f  cmp r14d, 0x08
00007b6e1c3d0743  jnz 0x00007B6E1C3D01AF
00007b6e1c3d0749  movq r14, xmm14
00007b6e1c3d074e  shl r14, 0x0D
00007b6e1c3d0752  jbe 0x00007B6E1C3D01AF
00007b6e1c3d0758  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d0760  jmp 0x00007B6E1C3D01AF
00007b6e1c3d0765  ucomisd xmm1, xmm15
00007b6e1c3d076a  jp 0x00007B6E1C3D0779
00007b6e1c3d076c  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d0774  jmp 0x00007B6E1C3D01E4
00007b6e1c3d0779  vxorps xmm0, xmm1, xmm15
00007b6e1c3d077e  pextrw r14d, xmm0, 0x03
00007b6e1c3d0784  and r14d, 0x7FF8
00007b6e1c3d078b  cmp r14d, 0x08
00007b6e1c3d078f  jnz 0x00007B6E1C3D01E4
00007b6e1c3d0795  movq r14, xmm15
00007b6e1c3d079a  shl r14, 0x0D
00007b6e1c3d079e  jbe 0x00007B6E1C3D01E4
00007b6e1c3d07a4  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d07ac  jmp 0x00007B6E1C3D01E4
00007b6e1c3d07b1  call 0x00007B6E1C2D59C0
00007b6e1c3d07b6  jmp 0x00007B6E1C3D01F5
00007b6e1c3d07bb  ucomisd xmm15, xmm14
00007b6e1c3d07c0  jp 0x00007B6E1C3D07CF
00007b6e1c3d07c2  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d07ca  jmp 0x00007B6E1C3D022A
00007b6e1c3d07cf  vxorps xmm0, xmm15, xmm14
00007b6e1c3d07d4  pextrw eax, xmm0, 0x03
00007b6e1c3d07d9  and eax, 0x7FF8
00007b6e1c3d07de  cmp eax, 0x08
00007b6e1c3d07e1  jnz 0x00007B6E1C3D022A
00007b6e1c3d07e7  movq rax, xmm14
00007b6e1c3d07ec  shl rax, 0x0D
00007b6e1c3d07f0  jbe 0x00007B6E1C3D022A
00007b6e1c3d07f6  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d07fe  jmp 0x00007B6E1C3D022A
00007b6e1c3d0803  ucomisd xmm1, xmm15
00007b6e1c3d0808  jp 0x00007B6E1C3D0817
00007b6e1c3d080a  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d0812  jmp 0x00007B6E1C3D025F
00007b6e1c3d0817  vxorps xmm0, xmm1, xmm15
00007b6e1c3d081c  pextrw eax, xmm0, 0x03
00007b6e1c3d0821  and eax, 0x7FF8
00007b6e1c3d0826  cmp eax, 0x08
00007b6e1c3d0829  jnz 0x00007B6E1C3D025F
00007b6e1c3d082f  movq rax, xmm15
00007b6e1c3d0834  shl rax, 0x0D
00007b6e1c3d0838  jbe 0x00007B6E1C3D025F
00007b6e1c3d083e  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d0846  jmp 0x00007B6E1C3D025F
00007b6e1c3d084b  ucomisd xmm1, xmm15
00007b6e1c3d0850  jp 0x00007B6E1C3D085F
00007b6e1c3d0852  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d085a  jmp 0x00007B6E1C3D0294
00007b6e1c3d085f  vxorps xmm0, xmm1, xmm15
00007b6e1c3d0864  pextrw eax, xmm0, 0x03
00007b6e1c3d0869  and eax, 0x7FF8
00007b6e1c3d086e  cmp eax, 0x08
00007b6e1c3d0871  jnz 0x00007B6E1C3D0294
00007b6e1c3d0877  movq rax, xmm15
00007b6e1c3d087c  shl rax, 0x0D
00007b6e1c3d0880  jbe 0x00007B6E1C3D0294
00007b6e1c3d0886  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d088e  jmp 0x00007B6E1C3D0294
00007b6e1c3d0893  call 0x00007B6E1C20E120
00007b6e1c3d0898  jmp 0x00007B6E1C3D02AF
00007b6e1c3d089d  int3
00007b6e1c3d089e  nop
00007b6e1c3d08a0  mov eax, [r15+0x58]
00007b6e1c3d08a4  lea r14d, [eax+0x01]
00007b6e1c3d08a9  mov [rsp+0x10], r14d
00007b6e1c3d08ae  mov r14d, r14d
00007b6e1c3d08b1  mov [r15+0x58], r14
00007b6e1c3d08b5  xor eax, eax
00007b6e1c3d08b7  mov r14d, [rsp+0x10]
00007b6e1c3d08bc  cmp r14d, 0x1F4
00007b6e1c3d08c3  cmc
00007b6e1c3d08c4  lahf
00007b6e1c3d08c5  seto al
00007b6e1c3d08c8  mov [r15+0x108], eax
00007b6e1c3d08cf  mov eax, [r15+0x108]
00007b6e1c3d08d6  sahf
00007b6e1c3d08d7  jnz 0x00007B6E1C3D0909
00007b6e1c3d08d9  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d08e1  jz 0x00007B6E1C3D1410
00007b6e1c3d08e7  nop [rax+rax*1], ax
00007b6e1c3d08f0  nop [rax+rax*1], eax
00007b6e1c3d08f8  mov eax, 0x410134
00007b6e1c3d08fd  mov [r15+0x100], rax
00007b6e1c3d0904  jmp 0x00007B6E1C1FE110
00007b6e1c3d0909  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d0911  jz 0x00007B6E1C3D0940
00007b6e1c3d0917  nop [rax+rax*1], ax
00007b6e1c3d0920  nop [rax+rax*1], eax
00007b6e1c3d0928  mov eax, 0x410084
00007b6e1c3d092d  mov [r15+0x100], rax
00007b6e1c3d0934  jmp 0x00007B6E1C1FE110
00007b6e1c3d0939  int3
00007b6e1c3d093a  int3
00007b6e1c3d093b  nop [rax+rax*1], eax
00007b6e1c3d0940  mov qword ptr [r15+0x60], 0x00
00007b6e1c3d0948  mov rax, [r15+0x50]
00007b6e1c3d094c  mov [r15+0x68], rax
00007b6e1c3d0950  mov r14, [r15+0x40]
00007b6e1c3d0954  mov r12, [r13+r14*1]
00007b6e1c3d0959  lea r11, [r14+0x08]
00007b6e1c3d095d  mov r10, [r13+r11*1]
00007b6e1c3d0962  movq xmm1, r12
00007b6e1c3d0967  movq xmm15, r10
00007b6e1c3d096c  movq xmm1, xmm1
00007b6e1c3d0970  movq xmm1, xmm1
00007b6e1c3d0974  movaps [r15+0x120], xmm1
00007b6e1c3d097c  movq xmm15, xmm15
00007b6e1c3d0981  movq xmm15, xmm15
00007b6e1c3d0986  movaps [r15+0x130], xmm15
00007b6e1c3d098e  lea r12, [r14+0x10]
00007b6e1c3d0992  mov r11, [r13+r12*1]
00007b6e1c3d0997  lea r12, [r14+0x18]
00007b6e1c3d099b  mov r10, [r13+r12*1]
00007b6e1c3d09a0  movq xmm1, r11
00007b6e1c3d09a5  movq xmm15, r10
00007b6e1c3d09aa  movq xmm1, xmm1
00007b6e1c3d09ae  movq xmm1, xmm1
00007b6e1c3d09b2  movaps [r15+0x140], xmm1
00007b6e1c3d09ba  movq xmm15, xmm15
00007b6e1c3d09bf  movq xmm15, xmm15
00007b6e1c3d09c4  movaps [r15+0x150], xmm15
00007b6e1c3d09cc  lea r12, [r14+0x20]
00007b6e1c3d09d0  mov r11, [r13+r12*1]
00007b6e1c3d09d5  lea r12, [r14+0x28]
00007b6e1c3d09d9  mov r10, [r13+r12*1]
00007b6e1c3d09de  movq xmm1, r11
00007b6e1c3d09e3  movq xmm15, r10
00007b6e1c3d09e8  movq xmm1, xmm1
00007b6e1c3d09ec  movq xmm1, xmm1
00007b6e1c3d09f0  movaps [r15+0x160], xmm1
00007b6e1c3d09f8  movq xmm15, xmm15
00007b6e1c3d09fd  movq xmm15, xmm15
00007b6e1c3d0a02  movaps [r15+0x170], xmm15
00007b6e1c3d0a0a  lea r12, [r14+0x30]
00007b6e1c3d0a0e  mov r11, [r13+r12*1]
00007b6e1c3d0a13  lea r12, [r14+0x38]
00007b6e1c3d0a17  mov r14, [r13+r12*1]
00007b6e1c3d0a1c  movq xmm1, r11
00007b6e1c3d0a21  movq xmm15, r14
00007b6e1c3d0a26  movq xmm1, xmm1
00007b6e1c3d0a2a  movq xmm1, xmm1
00007b6e1c3d0a2e  movaps [r15+0x180], xmm1
00007b6e1c3d0a36  movq xmm15, xmm15
00007b6e1c3d0a3b  movq xmm15, xmm15
00007b6e1c3d0a40  movaps [r15+0x210], xmm15
00007b6e1c3d0a48  mov r14, [r15+0x48]
00007b6e1c3d0a4c  mov [r15+0x78], r14
00007b6e1c3d0a50  mov r12, [r13+r14*1]
00007b6e1c3d0a55  movq xmm1, r12
00007b6e1c3d0a5a  lea r12, [r14+0x40]
00007b6e1c3d0a5e  mov r11, [r13+r12*1]
00007b6e1c3d0a63  movq xmm15, r11
00007b6e1c3d0a68  lea r12, [r14+0x80]
00007b6e1c3d0a6f  mov r11, [r13+r12*1]
00007b6e1c3d0a74  movq xmm14, r11
00007b6e1c3d0a79  movaps xmm13, [r15+0x120]
00007b6e1c3d0a81  movq r12, xmm13
00007b6e1c3d0a86  movq r11, xmm1
00007b6e1c3d0a8b  vmovq xmm1, r12
00007b6e1c3d0a90  vmovq xmm13, r11
00007b6e1c3d0a95  movaps xmm12, xmm1
00007b6e1c3d0a99  mulsd xmm12, xmm13
00007b6e1c3d0a9e  ucomisd xmm12, xmm12
00007b6e1c3d0aa3  jp 0x00007B6E1C3D0F06
00007b6e1c3d0aa9  movq xmm12, xmm12
00007b6e1c3d0aae  movaps xmm1, [r15+0x130]
00007b6e1c3d0ab6  movq r12, xmm1
00007b6e1c3d0abb  movq r11, xmm15
00007b6e1c3d0ac0  vmovq xmm1, r12
00007b6e1c3d0ac5  vmovq xmm15, r11
00007b6e1c3d0aca  movaps xmm13, xmm1
00007b6e1c3d0ace  mulsd xmm13, xmm15
00007b6e1c3d0ad3  ucomisd xmm13, xmm13
00007b6e1c3d0ad8  jp 0x00007B6E1C3D0F52
00007b6e1c3d0ade  movq xmm13, xmm13
00007b6e1c3d0ae3  movq r12, xmm12
00007b6e1c3d0ae8  movaps xmm1, [r15+0x110]
00007b6e1c3d0af0  movq r11, xmm1
00007b6e1c3d0af5  vmovq xmm1, r12
00007b6e1c3d0afa  vmovq xmm15, r11
00007b6e1c3d0aff  movaps xmm12, xmm1
00007b6e1c3d0b03  addsd xmm12, xmm15
00007b6e1c3d0b08  ucomisd xmm12, xmm12
00007b6e1c3d0b0d  jp 0x00007B6E1C3D0F9E
00007b6e1c3d0b13  movq xmm12, xmm12
00007b6e1c3d0b18  movq r12, xmm12
00007b6e1c3d0b1d  movq r11, xmm13
00007b6e1c3d0b22  vmovq xmm1, r12
00007b6e1c3d0b27  vmovq xmm15, r11
00007b6e1c3d0b2c  movaps xmm13, xmm1
00007b6e1c3d0b30  addsd xmm13, xmm15
00007b6e1c3d0b35  ucomisd xmm13, xmm13
00007b6e1c3d0b3a  jp 0x00007B6E1C3D0FEA
00007b6e1c3d0b40  movq xmm13, xmm13
00007b6e1c3d0b45  movaps xmm1, [r15+0x140]
00007b6e1c3d0b4d  movq r12, xmm1
00007b6e1c3d0b52  movq r11, xmm14
00007b6e1c3d0b57  vmovq xmm1, r12
00007b6e1c3d0b5c  vmovq xmm15, r11
00007b6e1c3d0b61  movaps xmm14, xmm1
00007b6e1c3d0b65  mulsd xmm14, xmm15
00007b6e1c3d0b6a  ucomisd xmm14, xmm14
00007b6e1c3d0b6f  jp 0x00007B6E1C3D1036
00007b6e1c3d0b75  movq xmm14, xmm14
00007b6e1c3d0b7a  lea r12, [r14+0xC0]
00007b6e1c3d0b81  mov r11, [r13+r12*1]
00007b6e1c3d0b86  movq xmm1, r11
00007b6e1c3d0b8b  movq r12, xmm13
00007b6e1c3d0b90  movq r11, xmm14
00007b6e1c3d0b95  vmovq xmm15, r12
00007b6e1c3d0b9a  vmovq xmm14, r11
00007b6e1c3d0b9f  movaps xmm13, xmm15
00007b6e1c3d0ba3  addsd xmm13, xmm14
00007b6e1c3d0ba8  ucomisd xmm13, xmm13
00007b6e1c3d0bad  jp 0x00007B6E1C3D108C
00007b6e1c3d0bb3  movq xmm13, xmm13
00007b6e1c3d0bb8  movaps xmm15, [r15+0x150]
00007b6e1c3d0bc0  movq r12, xmm15
00007b6e1c3d0bc5  movq r11, xmm1
00007b6e1c3d0bca  vmovq xmm1, r12
00007b6e1c3d0bcf  vmovq xmm15, r11
00007b6e1c3d0bd4  movaps xmm14, xmm1
00007b6e1c3d0bd8  mulsd xmm14, xmm15
00007b6e1c3d0bdd  ucomisd xmm14, xmm14
00007b6e1c3d0be2  jp 0x00007B6E1C3D10D8
00007b6e1c3d0be8  movq xmm14, xmm14
00007b6e1c3d0bed  lea r12, [r14+0x100]
00007b6e1c3d0bf4  mov r11, [r13+r12*1]
00007b6e1c3d0bf9  movq xmm1, r11
00007b6e1c3d0bfe  movq r12, xmm13
00007b6e1c3d0c03  movq r11, xmm14
00007b6e1c3d0c08  vmovq xmm15, r12
00007b6e1c3d0c0d  vmovq xmm14, r11
00007b6e1c3d0c12  movaps xmm13, xmm15
00007b6e1c3d0c16  addsd xmm13, xmm14
00007b6e1c3d0c1b  ucomisd xmm13, xmm13
00007b6e1c3d0c20  jp 0x00007B6E1C3D112E
00007b6e1c3d0c26  movq xmm13, xmm13
00007b6e1c3d0c2b  movaps xmm15, [r15+0x160]
00007b6e1c3d0c33  movq r12, xmm15
00007b6e1c3d0c38  movq r11, xmm1
00007b6e1c3d0c3d  vmovq xmm1, r12
00007b6e1c3d0c42  vmovq xmm15, r11
00007b6e1c3d0c47  movaps xmm14, xmm1
00007b6e1c3d0c4b  mulsd xmm14, xmm15
00007b6e1c3d0c50  ucomisd xmm14, xmm14
00007b6e1c3d0c55  jp 0x00007B6E1C3D117A
00007b6e1c3d0c5b  movq xmm14, xmm14
00007b6e1c3d0c60  lea r12, [r14+0x140]
00007b6e1c3d0c67  mov r11, [r13+r12*1]
00007b6e1c3d0c6c  movq xmm1, r11
00007b6e1c3d0c71  movq r12, xmm13
00007b6e1c3d0c76  movq r11, xmm14
00007b6e1c3d0c7b  vmovq xmm15, r12
00007b6e1c3d0c80  vmovq xmm14, r11
00007b6e1c3d0c85  movaps xmm13, xmm15
00007b6e1c3d0c89  addsd xmm13, xmm14
00007b6e1c3d0c8e  ucomisd xmm13, xmm13
00007b6e1c3d0c93  jp 0x00007B6E1C3D11D0
00007b6e1c3d0c99  movq xmm13, xmm13
00007b6e1c3d0c9e  movaps xmm15, [r15+0x170]
00007b6e1c3d0ca6  movq r12, xmm15
00007b6e1c3d0cab  movq r11, xmm1
00007b6e1c3d0cb0  vmovq xmm1, r12
00007b6e1c3d0cb5  vmovq xmm15, r11
00007b6e1c3d0cba  movaps xmm14, xmm1
00007b6e1c3d0cbe  mulsd xmm14, xmm15
00007b6e1c3d0cc3  ucomisd xmm14, xmm14
00007b6e1c3d0cc8  jp 0x00007B6E1C3D121C
00007b6e1c3d0cce  movq xmm14, xmm14
00007b6e1c3d0cd3  lea r12, [r14+0x180]
00007b6e1c3d0cda  mov r11, [r13+r12*1]
00007b6e1c3d0cdf  movq xmm1, r11
00007b6e1c3d0ce4  movq r12, xmm13
00007b6e1c3d0ce9  movq r11, xmm14
00007b6e1c3d0cee  vmovq xmm15, r12
00007b6e1c3d0cf3  vmovq xmm14, r11
00007b6e1c3d0cf8  movaps xmm13, xmm15
00007b6e1c3d0cfc  addsd xmm13, xmm14
00007b6e1c3d0d01  ucomisd xmm13, xmm13
00007b6e1c3d0d06  jp 0x00007B6E1C3D1272
00007b6e1c3d0d0c  movq xmm13, xmm13
00007b6e1c3d0d11  movaps xmm15, [r15+0x180]
00007b6e1c3d0d19  movq r12, xmm15
00007b6e1c3d0d1e  movq r11, xmm1
00007b6e1c3d0d23  vmovq xmm1, r12
00007b6e1c3d0d28  vmovq xmm15, r11
00007b6e1c3d0d2d  movaps xmm14, xmm1
00007b6e1c3d0d31  mulsd xmm14, xmm15
00007b6e1c3d0d36  ucomisd xmm14, xmm14
00007b6e1c3d0d3b  jp 0x00007B6E1C3D12BE
00007b6e1c3d0d41  movq xmm14, xmm14
00007b6e1c3d0d46  lea r12, [r14+0x1C0]
00007b6e1c3d0d4d  mov r14, [r13+r12*1]
00007b6e1c3d0d52  movq xmm1, r14
00007b6e1c3d0d57  movaps [r15+0x240], xmm1
00007b6e1c3d0d5f  movq r14, xmm13
00007b6e1c3d0d64  movq r12, xmm14
00007b6e1c3d0d69  vmovq xmm15, r14
00007b6e1c3d0d6e  vmovq xmm14, r12
00007b6e1c3d0d73  movaps xmm13, xmm15
00007b6e1c3d0d77  addsd xmm13, xmm14
00007b6e1c3d0d7c  ucomisd xmm13, xmm13
00007b6e1c3d0d81  jp 0x00007B6E1C3D1314
00007b6e1c3d0d87  movq xmm13, xmm13
00007b6e1c3d0d8c  movaps xmm15, [r15+0x210]
00007b6e1c3d0d94  movq r14, xmm15
00007b6e1c3d0d99  movq r12, xmm1
00007b6e1c3d0d9e  vmovq xmm1, r14
00007b6e1c3d0da3  vmovq xmm15, r12
00007b6e1c3d0da8  movaps xmm14, xmm1
00007b6e1c3d0dac  mulsd xmm14, xmm15
00007b6e1c3d0db1  ucomisd xmm14, xmm14
00007b6e1c3d0db6  jp 0x00007B6E1C3D1360
00007b6e1c3d0dbc  movq xmm14, xmm14
00007b6e1c3d0dc1  movaps [r15+0x230], xmm14
00007b6e1c3d0dc9  movq r14, xmm13
00007b6e1c3d0dce  movq r12, xmm14
00007b6e1c3d0dd3  vmovq xmm1, r14
00007b6e1c3d0dd8  vmovq xmm15, r12
00007b6e1c3d0ddd  movaps xmm14, xmm1
00007b6e1c3d0de1  addsd xmm14, xmm15
00007b6e1c3d0de6  ucomisd xmm14, xmm14
00007b6e1c3d0deb  jp 0x00007B6E1C3D13AC
00007b6e1c3d0df1  movq xmm14, xmm14
00007b6e1c3d0df6  movaps [r15+0x220], xmm14
00007b6e1c3d0dfe  movq r14, xmm14
00007b6e1c3d0e03  mov [r13+rax*1], r14
00007b6e1c3d0e08  mov qword ptr [r15+0x70], 0x08
00007b6e1c3d0e10  xor eax, eax
00007b6e1c3d0e12  mov r14d, 0x08
00007b6e1c3d0e18  mov r12d, 0x40
00007b6e1c3d0e1e  cmp r14, r12
00007b6e1c3d0e21  cmc
00007b6e1c3d0e22  lahf
00007b6e1c3d0e23  seto al
00007b6e1c3d0e26  mov [r15+0x108], eax
00007b6e1c3d0e2d  mov eax, [r15+0x108]
00007b6e1c3d0e34  sahf
00007b6e1c3d0e35  jnz 0x00007B6E1C3D0E67
00007b6e1c3d0e37  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d0e3f  jz 0x00007B6E1C3CFD40
00007b6e1c3d0e45  nop [rax+rax*1], ax
00007b6e1c3d0e4e  nop [rax+rax*1], eax
00007b6e1c3d0e56  mov eax, 0x410118
00007b6e1c3d0e5b  mov [r15+0x100], rax
00007b6e1c3d0e62  jmp 0x00007B6E1C1FE110
00007b6e1c3d0e67  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d0e6f  jz 0x00007B6E1C3CF3F0
00007b6e1c3d0e75  nop [rax+rax*1], ax
00007b6e1c3d0e7e  nop [rax+rax*1], eax
00007b6e1c3d0e86  mov eax, 0x4100A4
00007b6e1c3d0e8b  mov [r15+0x100], rax
00007b6e1c3d0e92  jmp 0x00007B6E1C1FE110
00007b6e1c3d0e97  int3
00007b6e1c3d0e98  call 0x00007B6E1C2E27E0
00007b6e1c3d0e9d  jmp 0x00007B6E1C3D0959
00007b6e1c3d0ea2  call 0x00007B6E1C2AE800
00007b6e1c3d0ea7  jmp 0x00007B6E1C3D0962
00007b6e1c3d0eac  call 0x00007B6E1C2C0370
00007b6e1c3d0eb1  jmp 0x00007B6E1C3D0997
00007b6e1c3d0eb6  call 0x00007B6E1C2BF100
00007b6e1c3d0ebb  jmp 0x00007B6E1C3D09A0
00007b6e1c3d0ec0  call 0x00007B6E1C2C0370
00007b6e1c3d0ec5  jmp 0x00007B6E1C3D09D5
00007b6e1c3d0eca  call 0x00007B6E1C2BF100
00007b6e1c3d0ecf  jmp 0x00007B6E1C3D09DE
00007b6e1c3d0ed4  call 0x00007B6E1C2C0370
00007b6e1c3d0ed9  jmp 0x00007B6E1C3D0A13
00007b6e1c3d0ede  call 0x00007B6E1C2C3AE0
00007b6e1c3d0ee3  jmp 0x00007B6E1C3D0A1C
00007b6e1c3d0ee8  call 0x00007B6E1C2E27E0
00007b6e1c3d0eed  jmp 0x00007B6E1C3D0A55
00007b6e1c3d0ef2  call 0x00007B6E1C2C0370
00007b6e1c3d0ef7  jmp 0x00007B6E1C3D0A63
00007b6e1c3d0efc  call 0x00007B6E1C2C0370
00007b6e1c3d0f01  jmp 0x00007B6E1C3D0A74
00007b6e1c3d0f06  ucomisd xmm1, xmm13
00007b6e1c3d0f0b  jp 0x00007B6E1C3D0F1A
00007b6e1c3d0f0d  movaps xmm12, [0x00007B6E1BFFE030]
00007b6e1c3d0f15  jmp 0x00007B6E1C3D0AA9
00007b6e1c3d0f1a  vxorps xmm0, xmm1, xmm13
00007b6e1c3d0f1f  pextrw r12d, xmm0, 0x03
00007b6e1c3d0f25  and r12d, 0x7FF8
00007b6e1c3d0f2c  cmp r12d, 0x08
00007b6e1c3d0f30  jnz 0x00007B6E1C3D0AA9
00007b6e1c3d0f36  movq r12, xmm13
00007b6e1c3d0f3b  shl r12, 0x0D
00007b6e1c3d0f3f  jbe 0x00007B6E1C3D0AA9
00007b6e1c3d0f45  vorps xmm12, xmm13, [0x00007B6E1BFFE040]
00007b6e1c3d0f4d  jmp 0x00007B6E1C3D0AA9
00007b6e1c3d0f52  ucomisd xmm1, xmm15
00007b6e1c3d0f57  jp 0x00007B6E1C3D0F66
00007b6e1c3d0f59  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d0f61  jmp 0x00007B6E1C3D0ADE
00007b6e1c3d0f66  vxorps xmm0, xmm1, xmm15
00007b6e1c3d0f6b  pextrw r12d, xmm0, 0x03
00007b6e1c3d0f71  and r12d, 0x7FF8
00007b6e1c3d0f78  cmp r12d, 0x08
00007b6e1c3d0f7c  jnz 0x00007B6E1C3D0ADE
00007b6e1c3d0f82  movq r12, xmm15
00007b6e1c3d0f87  shl r12, 0x0D
00007b6e1c3d0f8b  jbe 0x00007B6E1C3D0ADE
00007b6e1c3d0f91  vorps xmm13, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d0f99  jmp 0x00007B6E1C3D0ADE
00007b6e1c3d0f9e  ucomisd xmm1, xmm15
00007b6e1c3d0fa3  jp 0x00007B6E1C3D0FB2
00007b6e1c3d0fa5  movaps xmm12, [0x00007B6E1BFFE030]
00007b6e1c3d0fad  jmp 0x00007B6E1C3D0B13
00007b6e1c3d0fb2  vxorps xmm0, xmm1, xmm15
00007b6e1c3d0fb7  pextrw r12d, xmm0, 0x03
00007b6e1c3d0fbd  and r12d, 0x7FF8
00007b6e1c3d0fc4  cmp r12d, 0x08
00007b6e1c3d0fc8  jnz 0x00007B6E1C3D0B13
00007b6e1c3d0fce  movq r12, xmm15
00007b6e1c3d0fd3  shl r12, 0x0D
00007b6e1c3d0fd7  jbe 0x00007B6E1C3D0B13
00007b6e1c3d0fdd  vorps xmm12, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d0fe5  jmp 0x00007B6E1C3D0B13
00007b6e1c3d0fea  ucomisd xmm1, xmm15
00007b6e1c3d0fef  jp 0x00007B6E1C3D0FFE
00007b6e1c3d0ff1  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d0ff9  jmp 0x00007B6E1C3D0B40
00007b6e1c3d0ffe  vxorps xmm0, xmm1, xmm15
00007b6e1c3d1003  pextrw r12d, xmm0, 0x03
00007b6e1c3d1009  and r12d, 0x7FF8
00007b6e1c3d1010  cmp r12d, 0x08
00007b6e1c3d1014  jnz 0x00007B6E1C3D0B40
00007b6e1c3d101a  movq r12, xmm15
00007b6e1c3d101f  shl r12, 0x0D
00007b6e1c3d1023  jbe 0x00007B6E1C3D0B40
00007b6e1c3d1029  vorps xmm13, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d1031  jmp 0x00007B6E1C3D0B40
00007b6e1c3d1036  ucomisd xmm1, xmm15
00007b6e1c3d103b  jp 0x00007B6E1C3D104A
00007b6e1c3d103d  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d1045  jmp 0x00007B6E1C3D0B75
00007b6e1c3d104a  vxorps xmm0, xmm1, xmm15
00007b6e1c3d104f  pextrw r12d, xmm0, 0x03
00007b6e1c3d1055  and r12d, 0x7FF8
00007b6e1c3d105c  cmp r12d, 0x08
00007b6e1c3d1060  jnz 0x00007B6E1C3D0B75
00007b6e1c3d1066  movq r12, xmm15
00007b6e1c3d106b  shl r12, 0x0D
00007b6e1c3d106f  jbe 0x00007B6E1C3D0B75
00007b6e1c3d1075  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d107d  jmp 0x00007B6E1C3D0B75
00007b6e1c3d1082  call 0x00007B6E1C2C0370
00007b6e1c3d1087  jmp 0x00007B6E1C3D0B86
00007b6e1c3d108c  ucomisd xmm15, xmm14
00007b6e1c3d1091  jp 0x00007B6E1C3D10A0
00007b6e1c3d1093  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d109b  jmp 0x00007B6E1C3D0BB3
00007b6e1c3d10a0  vxorps xmm0, xmm15, xmm14
00007b6e1c3d10a5  pextrw r12d, xmm0, 0x03
00007b6e1c3d10ab  and r12d, 0x7FF8
00007b6e1c3d10b2  cmp r12d, 0x08
00007b6e1c3d10b6  jnz 0x00007B6E1C3D0BB3
00007b6e1c3d10bc  movq r12, xmm14
00007b6e1c3d10c1  shl r12, 0x0D
00007b6e1c3d10c5  jbe 0x00007B6E1C3D0BB3
00007b6e1c3d10cb  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d10d3  jmp 0x00007B6E1C3D0BB3
00007b6e1c3d10d8  ucomisd xmm1, xmm15
00007b6e1c3d10dd  jp 0x00007B6E1C3D10EC
00007b6e1c3d10df  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d10e7  jmp 0x00007B6E1C3D0BE8
00007b6e1c3d10ec  vxorps xmm0, xmm1, xmm15
00007b6e1c3d10f1  pextrw r12d, xmm0, 0x03
00007b6e1c3d10f7  and r12d, 0x7FF8
00007b6e1c3d10fe  cmp r12d, 0x08
00007b6e1c3d1102  jnz 0x00007B6E1C3D0BE8
00007b6e1c3d1108  movq r12, xmm15
00007b6e1c3d110d  shl r12, 0x0D
00007b6e1c3d1111  jbe 0x00007B6E1C3D0BE8
00007b6e1c3d1117  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d111f  jmp 0x00007B6E1C3D0BE8
00007b6e1c3d1124  call 0x00007B6E1C2C0370
00007b6e1c3d1129  jmp 0x00007B6E1C3D0BF9
00007b6e1c3d112e  ucomisd xmm15, xmm14
00007b6e1c3d1133  jp 0x00007B6E1C3D1142
00007b6e1c3d1135  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d113d  jmp 0x00007B6E1C3D0C26
00007b6e1c3d1142  vxorps xmm0, xmm15, xmm14
00007b6e1c3d1147  pextrw r12d, xmm0, 0x03
00007b6e1c3d114d  and r12d, 0x7FF8
00007b6e1c3d1154  cmp r12d, 0x08
00007b6e1c3d1158  jnz 0x00007B6E1C3D0C26
00007b6e1c3d115e  movq r12, xmm14
00007b6e1c3d1163  shl r12, 0x0D
00007b6e1c3d1167  jbe 0x00007B6E1C3D0C26
00007b6e1c3d116d  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d1175  jmp 0x00007B6E1C3D0C26
00007b6e1c3d117a  ucomisd xmm1, xmm15
00007b6e1c3d117f  jp 0x00007B6E1C3D118E
00007b6e1c3d1181  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d1189  jmp 0x00007B6E1C3D0C5B
00007b6e1c3d118e  vxorps xmm0, xmm1, xmm15
00007b6e1c3d1193  pextrw r12d, xmm0, 0x03
00007b6e1c3d1199  and r12d, 0x7FF8
00007b6e1c3d11a0  cmp r12d, 0x08
00007b6e1c3d11a4  jnz 0x00007B6E1C3D0C5B
00007b6e1c3d11aa  movq r12, xmm15
00007b6e1c3d11af  shl r12, 0x0D
00007b6e1c3d11b3  jbe 0x00007B6E1C3D0C5B
00007b6e1c3d11b9  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d11c1  jmp 0x00007B6E1C3D0C5B
00007b6e1c3d11c6  call 0x00007B6E1C2C0370
00007b6e1c3d11cb  jmp 0x00007B6E1C3D0C6C
00007b6e1c3d11d0  ucomisd xmm15, xmm14
00007b6e1c3d11d5  jp 0x00007B6E1C3D11E4
00007b6e1c3d11d7  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d11df  jmp 0x00007B6E1C3D0C99
00007b6e1c3d11e4  vxorps xmm0, xmm15, xmm14
00007b6e1c3d11e9  pextrw r12d, xmm0, 0x03
00007b6e1c3d11ef  and r12d, 0x7FF8
00007b6e1c3d11f6  cmp r12d, 0x08
00007b6e1c3d11fa  jnz 0x00007B6E1C3D0C99
00007b6e1c3d1200  movq r12, xmm14
00007b6e1c3d1205  shl r12, 0x0D
00007b6e1c3d1209  jbe 0x00007B6E1C3D0C99
00007b6e1c3d120f  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d1217  jmp 0x00007B6E1C3D0C99
00007b6e1c3d121c  ucomisd xmm1, xmm15
00007b6e1c3d1221  jp 0x00007B6E1C3D1230
00007b6e1c3d1223  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d122b  jmp 0x00007B6E1C3D0CCE
00007b6e1c3d1230  vxorps xmm0, xmm1, xmm15
00007b6e1c3d1235  pextrw r12d, xmm0, 0x03
00007b6e1c3d123b  and r12d, 0x7FF8
00007b6e1c3d1242  cmp r12d, 0x08
00007b6e1c3d1246  jnz 0x00007B6E1C3D0CCE
00007b6e1c3d124c  movq r12, xmm15
00007b6e1c3d1251  shl r12, 0x0D
00007b6e1c3d1255  jbe 0x00007B6E1C3D0CCE
00007b6e1c3d125b  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d1263  jmp 0x00007B6E1C3D0CCE
00007b6e1c3d1268  call 0x00007B6E1C2C0370
00007b6e1c3d126d  jmp 0x00007B6E1C3D0CDF
00007b6e1c3d1272  ucomisd xmm15, xmm14
00007b6e1c3d1277  jp 0x00007B6E1C3D1286
00007b6e1c3d1279  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d1281  jmp 0x00007B6E1C3D0D0C
00007b6e1c3d1286  vxorps xmm0, xmm15, xmm14
00007b6e1c3d128b  pextrw r12d, xmm0, 0x03
00007b6e1c3d1291  and r12d, 0x7FF8
00007b6e1c3d1298  cmp r12d, 0x08
00007b6e1c3d129c  jnz 0x00007B6E1C3D0D0C
00007b6e1c3d12a2  movq r12, xmm14
00007b6e1c3d12a7  shl r12, 0x0D
00007b6e1c3d12ab  jbe 0x00007B6E1C3D0D0C
00007b6e1c3d12b1  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d12b9  jmp 0x00007B6E1C3D0D0C
00007b6e1c3d12be  ucomisd xmm1, xmm15
00007b6e1c3d12c3  jp 0x00007B6E1C3D12D2
00007b6e1c3d12c5  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d12cd  jmp 0x00007B6E1C3D0D41
00007b6e1c3d12d2  vxorps xmm0, xmm1, xmm15
00007b6e1c3d12d7  pextrw r12d, xmm0, 0x03
00007b6e1c3d12dd  and r12d, 0x7FF8
00007b6e1c3d12e4  cmp r12d, 0x08
00007b6e1c3d12e8  jnz 0x00007B6E1C3D0D41
00007b6e1c3d12ee  movq r12, xmm15
00007b6e1c3d12f3  shl r12, 0x0D
00007b6e1c3d12f7  jbe 0x00007B6E1C3D0D41
00007b6e1c3d12fd  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d1305  jmp 0x00007B6E1C3D0D41
00007b6e1c3d130a  call 0x00007B6E1C2C3AE0
00007b6e1c3d130f  jmp 0x00007B6E1C3D0D52
00007b6e1c3d1314  ucomisd xmm15, xmm14
00007b6e1c3d1319  jp 0x00007B6E1C3D1328
00007b6e1c3d131b  movaps xmm13, [0x00007B6E1BFFE030]
00007b6e1c3d1323  jmp 0x00007B6E1C3D0D87
00007b6e1c3d1328  vxorps xmm0, xmm15, xmm14
00007b6e1c3d132d  pextrw r14d, xmm0, 0x03
00007b6e1c3d1333  and r14d, 0x7FF8
00007b6e1c3d133a  cmp r14d, 0x08
00007b6e1c3d133e  jnz 0x00007B6E1C3D0D87
00007b6e1c3d1344  movq r14, xmm14
00007b6e1c3d1349  shl r14, 0x0D
00007b6e1c3d134d  jbe 0x00007B6E1C3D0D87
00007b6e1c3d1353  vorps xmm13, xmm14, [0x00007B6E1BFFE040]
00007b6e1c3d135b  jmp 0x00007B6E1C3D0D87
00007b6e1c3d1360  ucomisd xmm1, xmm15
00007b6e1c3d1365  jp 0x00007B6E1C3D1374
00007b6e1c3d1367  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d136f  jmp 0x00007B6E1C3D0DBC
00007b6e1c3d1374  vxorps xmm0, xmm1, xmm15
00007b6e1c3d1379  pextrw r14d, xmm0, 0x03
00007b6e1c3d137f  and r14d, 0x7FF8
00007b6e1c3d1386  cmp r14d, 0x08
00007b6e1c3d138a  jnz 0x00007B6E1C3D0DBC
00007b6e1c3d1390  movq r14, xmm15
00007b6e1c3d1395  shl r14, 0x0D
00007b6e1c3d1399  jbe 0x00007B6E1C3D0DBC
00007b6e1c3d139f  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d13a7  jmp 0x00007B6E1C3D0DBC
00007b6e1c3d13ac  ucomisd xmm1, xmm15
00007b6e1c3d13b1  jp 0x00007B6E1C3D13C0
00007b6e1c3d13b3  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d13bb  jmp 0x00007B6E1C3D0DF1
00007b6e1c3d13c0  vxorps xmm0, xmm1, xmm15
00007b6e1c3d13c5  pextrw r14d, xmm0, 0x03
00007b6e1c3d13cb  and r14d, 0x7FF8
00007b6e1c3d13d2  cmp r14d, 0x08
00007b6e1c3d13d6  jnz 0x00007B6E1C3D0DF1
00007b6e1c3d13dc  movq r14, xmm15
00007b6e1c3d13e1  shl r14, 0x0D
00007b6e1c3d13e5  jbe 0x00007B6E1C3D0DF1
00007b6e1c3d13eb  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d13f3  jmp 0x00007B6E1C3D0DF1
00007b6e1c3d13f8  call 0x00007B6E1C20E120
00007b6e1c3d13fd  jmp 0x00007B6E1C3D0E08
00007b6e1c3d1402  int3
00007b6e1c3d1403  nop [rax+rax*1], ax
00007b6e1c3d140c  nop [rax], eax
00007b6e1c3d1410  mov qword ptr [r15+0x40], 0x420000
00007b6e1c3d1418  mov eax, 0x4201B8
00007b6e1c3d141d  mov r14, [r13+rax*1]
00007b6e1c3d1422  movq xmm1, r14
00007b6e1c3d1427  mov rax, [r15+0x50]
00007b6e1c3d142b  mov r14, [r13+rax*1]
00007b6e1c3d1430  movq xmm15, r14
00007b6e1c3d1435  movaps [r15+0x120], xmm15
00007b6e1c3d143d  mov qword ptr [r15+0x48], 0x08
00007b6e1c3d1445  xor eax, eax
00007b6e1c3d1447  mov r14d, 0x08
00007b6e1c3d144d  mov r12d, 0x200
00007b6e1c3d1453  cmp r14, r12
00007b6e1c3d1456  cmc
00007b6e1c3d1457  lahf
00007b6e1c3d1458  seto al
00007b6e1c3d145b  mov [r15+0x108], eax
00007b6e1c3d1462  movq rax, xmm1
00007b6e1c3d1467  movq r14, xmm15
00007b6e1c3d146c  vmovq xmm1, rax
00007b6e1c3d1471  vmovq xmm15, r14
00007b6e1c3d1476  movaps xmm14, xmm1
00007b6e1c3d147a  addsd xmm14, xmm15
00007b6e1c3d147f  ucomisd xmm14, xmm14
00007b6e1c3d1484  jp 0x00007B6E1C3D1516
00007b6e1c3d148a  movq xmm14, xmm14
00007b6e1c3d148f  movaps [r15+0x110], xmm14
00007b6e1c3d1497  mov eax, [r15+0x108]
00007b6e1c3d149e  sahf
00007b6e1c3d149f  jnz 0x00007B6E1C3D14D1
00007b6e1c3d14a1  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d14a9  jz 0x00007B6E1C3D16A0
00007b6e1c3d14af  nop [rax+rax*1], ax
00007b6e1c3d14b8  nop [rax+rax*1], eax
00007b6e1c3d14c0  mov eax, 0x410154
00007b6e1c3d14c5  mov [r15+0x100], rax
00007b6e1c3d14cc  jmp 0x00007B6E1C1FE110
00007b6e1c3d14d1  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d14d9  jz 0x00007B6E1C3D1560
00007b6e1c3d14df  nop [rax+rax*1], ax
00007b6e1c3d14e8  nop [rax+rax*1], eax
00007b6e1c3d14f0  mov eax, 0x410140
00007b6e1c3d14f5  mov [r15+0x100], rax
00007b6e1c3d14fc  jmp 0x00007B6E1C1FE110
00007b6e1c3d1501  int3
00007b6e1c3d1502  call 0x00007B6E1C20DC20
00007b6e1c3d1507  jmp 0x00007B6E1C3D1422
00007b6e1c3d150c  call 0x00007B6E1C20DC20
00007b6e1c3d1511  jmp 0x00007B6E1C3D1430
00007b6e1c3d1516  ucomisd xmm1, xmm15
00007b6e1c3d151b  jp 0x00007B6E1C3D152A
00007b6e1c3d151d  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d1525  jmp 0x00007B6E1C3D148A
00007b6e1c3d152a  vxorps xmm0, xmm1, xmm15
00007b6e1c3d152f  pextrw eax, xmm0, 0x03
00007b6e1c3d1534  and eax, 0x7FF8
00007b6e1c3d1539  cmp eax, 0x08
00007b6e1c3d153c  jnz 0x00007B6E1C3D148A
00007b6e1c3d1542  movq rax, xmm15
00007b6e1c3d1547  shl rax, 0x0D
00007b6e1c3d154b  jbe 0x00007B6E1C3D148A
00007b6e1c3d1551  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d1559  jmp 0x00007B6E1C3D148A
00007b6e1c3d155e  int3
00007b6e1c3d155f  nop
00007b6e1c3d1560  mov rax, [r15+0x48]
00007b6e1c3d1564  mov r14, [r15+0x50]
00007b6e1c3d1568  lea r12, [r14+rax*1]
00007b6e1c3d156c  mov r14, [r13+r12*1]
00007b6e1c3d1571  movq xmm1, r14
00007b6e1c3d1576  movaps [r15+0x120], xmm1
00007b6e1c3d157e  lea r14, [rax+0x08]
00007b6e1c3d1582  mov [r15+0x48], r14
00007b6e1c3d1586  xor eax, eax
00007b6e1c3d1588  mov r12d, 0x200
00007b6e1c3d158e  cmp r14, r12
00007b6e1c3d1591  cmc
00007b6e1c3d1592  lahf
00007b6e1c3d1593  seto al
00007b6e1c3d1596  mov [r15+0x108], eax
00007b6e1c3d159d  movaps xmm15, [r15+0x110]
00007b6e1c3d15a5  movq rax, xmm15
00007b6e1c3d15aa  movq r14, xmm1
00007b6e1c3d15af  vmovq xmm1, rax
00007b6e1c3d15b4  vmovq xmm15, r14
00007b6e1c3d15b9  movaps xmm14, xmm1
00007b6e1c3d15bd  addsd xmm14, xmm15
00007b6e1c3d15c2  ucomisd xmm14, xmm14
00007b6e1c3d15c7  jp 0x00007B6E1C3D164F
00007b6e1c3d15cd  movq xmm14, xmm14
00007b6e1c3d15d2  movaps [r15+0x110], xmm14
00007b6e1c3d15da  mov eax, [r15+0x108]
00007b6e1c3d15e1  sahf
00007b6e1c3d15e2  jnz 0x00007B6E1C3D1614
00007b6e1c3d15e4  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d15ec  jz 0x00007B6E1C3D16A0
00007b6e1c3d15f2  nop [rax+rax*1], ax
00007b6e1c3d15fb  nop [rax+rax*1], eax
00007b6e1c3d1603  mov eax, 0x410154
00007b6e1c3d1608  mov [r15+0x100], rax
00007b6e1c3d160f  jmp 0x00007B6E1C1FE110
00007b6e1c3d1614  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d161c  jz 0x00007B6E1C3D1560
00007b6e1c3d1622  nop [rax+rax*1], ax
00007b6e1c3d162b  nop [rax+rax*1], eax
00007b6e1c3d1633  mov eax, 0x410140
00007b6e1c3d1638  mov [r15+0x100], rax
00007b6e1c3d163f  jmp 0x00007B6E1C1FE110
00007b6e1c3d1644  int3
00007b6e1c3d1645  call 0x00007B6E1C2C3AE0
00007b6e1c3d164a  jmp 0x00007B6E1C3D1571
00007b6e1c3d164f  ucomisd xmm1, xmm15
00007b6e1c3d1654  jp 0x00007B6E1C3D1663
00007b6e1c3d1656  movaps xmm14, [0x00007B6E1BFFE030]
00007b6e1c3d165e  jmp 0x00007B6E1C3D15CD
00007b6e1c3d1663  vxorps xmm0, xmm1, xmm15
00007b6e1c3d1668  pextrw eax, xmm0, 0x03
00007b6e1c3d166d  and eax, 0x7FF8
00007b6e1c3d1672  cmp eax, 0x08
00007b6e1c3d1675  jnz 0x00007B6E1C3D15CD
00007b6e1c3d167b  movq rax, xmm15
00007b6e1c3d1680  shl rax, 0x0D
00007b6e1c3d1684  jbe 0x00007B6E1C3D15CD
00007b6e1c3d168a  vorps xmm14, xmm15, [0x00007B6E1BFFE040]
00007b6e1c3d1692  jmp 0x00007B6E1C3D15CD
00007b6e1c3d1697  int3
00007b6e1c3d1698  nop [rax+rax*1], eax
00007b6e1c3d16a0  mov rax, [r15+0x40]
00007b6e1c3d16a4  lea r14, [rax+0x1B8]
00007b6e1c3d16ab  movaps xmm1, [r15+0x110]
00007b6e1c3d16b3  movq rax, xmm1
00007b6e1c3d16b8  mov [r13+r14*1], rax
00007b6e1c3d16bd  mov rax, [r15+0xF0]
00007b6e1c3d16c4  mov [r15+0x100], rax
00007b6e1c3d16cb  jmp 0x00007B6E1C3CE5C0
00007b6e1c3d16d0  int3
00007b6e1c3d16d1  call 0x00007B6E1C2D5EB0
00007b6e1c3d16d6  jmp 0x00007B6E1C3D16BD
00007b6e1c3d16db  int3
00007b6e1c3d16dc  nop [rax], eax
00007b6e1c3d16e0  mov qword ptr [r15+0x100], 0x04
00007b6e1c3d16eb  mov esi, 0x00
00007b6e1c3d16f0  mov edx, 0x09
00007b6e1c3d16f5  mov rdi, 0x7FFFD602FF20
00007b6e1c3d16ff  mov rax, 0x5AD007999970
00007b6e1c3d1709  call rax
00007b6e1c3d170b  cmp dword ptr [r15+0x318], 0x00
00007b6e1c3d1713  jnz 0x00007B6E1C1FE110
00007b6e1c3d1719  jmp 0x00007B6E1C1FE0A0
00007b6e1c3d171e  int3
00007b6e1c3d171f  int3
