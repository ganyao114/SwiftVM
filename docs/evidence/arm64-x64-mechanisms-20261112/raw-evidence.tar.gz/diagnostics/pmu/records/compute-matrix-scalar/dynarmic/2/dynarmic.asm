0000740abd3ce69b  nop [rax+rax*1], eax
0000740abd3ce6a0  mov qword ptr [r15+0x40], 0x4201C0
0000740abd3ce6a8  mov qword ptr [r15+0x48], 0x4203C0
0000740abd3ce6b0  mov qword ptr [r15+0x60], 0x01
0000740abd3ce6b8  xorps xmm1, xmm1
0000740abd3ce6bb  mov eax, 0x41
0000740abd3ce6c0  vcvtusi2sd xmm1, xmm1, eax
0000740abd3ce6c6  mulsd xmm1, [0x0000740ABCFFE010]
0000740abd3ce6ce  movq xmm1, xmm1
0000740abd3ce6d2  movaps [r15+0x120], xmm1
0000740abd3ce6da  mov eax, [r15+0x60]
0000740abd3ce6de  xorps xmm15, xmm15
0000740abd3ce6e2  vcvtusi2sd xmm15, xmm15, eax
0000740abd3ce6e8  mulsd xmm15, [0x0000740ABCFFE020]
0000740abd3ce6f1  movq xmm15, xmm15
0000740abd3ce6f6  movaps [r15+0x110], xmm15
0000740abd3ce6fe  mov rax, [r15+0x60]
0000740abd3ce702  mov [rsp+0x10], rax
0000740abd3ce707  xor eax, eax
0000740abd3ce709  mov r14, [rsp+0x10]
0000740abd3ce70e  mov r12d, 0x40
0000740abd3ce714  cmp r14, r12
0000740abd3ce717  cmc
0000740abd3ce718  lahf
0000740abd3ce719  seto al
0000740abd3ce71c  mov [r15+0x108], eax
0000740abd3ce723  mov qword ptr [r15+0x50], 0x40
0000740abd3ce72b  movq rax, xmm1
0000740abd3ce730  mov r12d, 0x4203C0
0000740abd3ce736  mov [r13+r12*1], rax
0000740abd3ce73b  movq rax, xmm15
0000740abd3ce740  mov r12d, 0x4201C0
0000740abd3ce746  mov [r13+r12*1], rax
0000740abd3ce74b  mov [r15+0x58], r14
0000740abd3ce74f  mov eax, [r15+0x108]
0000740abd3ce756  sahf
0000740abd3ce757  jnz 0x0000740ABD3CE789
0000740abd3ce759  cmp dword ptr [r15+0x318], 0x00
0000740abd3ce761  jz 0x0000740ABD3CE910
0000740abd3ce767  nop [rax+rax*1], ax
0000740abd3ce770  nop [rax+rax*1], eax
0000740abd3ce778  mov eax, 0x410074
0000740abd3ce77d  mov [r15+0x100], rax
0000740abd3ce784  jmp 0x0000740ABD1FE110
0000740abd3ce789  cmp dword ptr [r15+0x318], 0x00
0000740abd3ce791  jz 0x0000740ABD3CE7D0
0000740abd3ce797  nop [rax+rax*1], ax
0000740abd3ce7a0  nop [rax+rax*1], eax
0000740abd3ce7a8  mov eax, 0x41004C
0000740abd3ce7ad  mov [r15+0x100], rax
0000740abd3ce7b4  jmp 0x0000740ABD1FE110
0000740abd3ce7b9  int3
0000740abd3ce7ba  call 0x0000740ABD2B4CB0
0000740abd3ce7bf  jmp 0x0000740ABD3CE73B
0000740abd3ce7c4  call 0x0000740ABD2B4CB0
0000740abd3ce7c9  jmp 0x0000740ABD3CE74B
0000740abd3ce7ce  int3
0000740abd3ce7cf  nop
0000740abd3ce7d0  mov rax, [r15+0x58]
0000740abd3ce7d4  lea r14, [rax+0x01]
0000740abd3ce7d8  mov [r15+0x60], r14
0000740abd3ce7dc  mov r14d, [r15+0x50]
0000740abd3ce7e0  xorps xmm1, xmm1
0000740abd3ce7e3  vcvtusi2sd xmm1, xmm1, r14d
0000740abd3ce7e9  mulsd xmm1, [0x0000740ABCFFE010]
0000740abd3ce7f1  movq xmm1, xmm1
0000740abd3ce7f5  movaps [r15+0x120], xmm1
0000740abd3ce7fd  rorx r12, rax, 0x3D
0000740abd3ce803  and r12, 0xFFFFFFFFFFFFFFF8
0000740abd3ce807  mov eax, [r15+0x60]
0000740abd3ce80b  xorps xmm15, xmm15
0000740abd3ce80f  vcvtusi2sd xmm15, xmm15, eax
0000740abd3ce815  mulsd xmm15, [0x0000740ABCFFE020]
0000740abd3ce81e  movq xmm15, xmm15
0000740abd3ce823  movaps [r15+0x110], xmm15
0000740abd3ce82b  mov rax, [r15+0x60]
0000740abd3ce82f  mov [rsp+0x10], rax
0000740abd3ce834  xor eax, eax
0000740abd3ce836  mov r11, [rsp+0x10]
0000740abd3ce83b  mov r10d, 0x40
0000740abd3ce841  cmp r11, r10
0000740abd3ce844  cmc
0000740abd3ce845  lahf
0000740abd3ce846  seto al
0000740abd3ce849  mov [r15+0x108], eax
0000740abd3ce850  lea eax, [r14d-0x01]
0000740abd3ce855  mov eax, eax
0000740abd3ce857  mov [r15+0x50], rax
0000740abd3ce85b  mov rax, [r15+0x48]
0000740abd3ce85f  lea r14, [rax+r12*1]
0000740abd3ce863  movq rax, xmm1
0000740abd3ce868  mov [r13+r14*1], rax
0000740abd3ce86d  mov rax, [r15+0x40]
0000740abd3ce871  lea r14, [rax+r12*1]
0000740abd3ce875  movq rax, xmm15
0000740abd3ce87a  mov [r13+r14*1], rax
0000740abd3ce87f  mov [r15+0x58], r11
0000740abd3ce883  mov eax, [r15+0x108]
0000740abd3ce88a  sahf
0000740abd3ce88b  jnz 0x0000740ABD3CE8BD
0000740abd3ce88d  cmp dword ptr [r15+0x318], 0x00
0000740abd3ce895  jz 0x0000740ABD3CE910
0000740abd3ce89b  nop [rax+rax*1], ax
0000740abd3ce8a4  nop [rax+rax*1], eax
0000740abd3ce8ac  mov eax, 0x410074
0000740abd3ce8b1  mov [r15+0x100], rax
0000740abd3ce8b8  jmp 0x0000740ABD1FE110
0000740abd3ce8bd  cmp dword ptr [r15+0x318], 0x00
0000740abd3ce8c5  jz 0x0000740ABD3CE7D0
0000740abd3ce8cb  nop [rax+rax*1], ax
0000740abd3ce8d4  nop [rax+rax*1], eax
0000740abd3ce8dc  mov eax, 0x41004C
0000740abd3ce8e1  mov [r15+0x100], rax
0000740abd3ce8e8  jmp 0x0000740ABD1FE110
0000740abd3ce8ed  int3
0000740abd3ce8ee  call 0x0000740ABD2D5EB0
0000740abd3ce8f3  jmp 0x0000740ABD3CE86D
0000740abd3ce8f8  call 0x0000740ABD2D5EB0
0000740abd3ce8fd  jmp 0x0000740ABD3CE87F
0000740abd3ce902  int3
0000740abd3ce903  nop [rax+rax*1], ax
0000740abd3ce90c  nop [rax], eax
0000740abd3ce910  vxorps xmm1, xmm1, xmm1
0000740abd3ce914  movq xmm1, xmm1
0000740abd3ce918  movaps [r15+0x110], xmm1
0000740abd3ce920  mov qword ptr [r15+0x58], 0x00
0000740abd3ce928  mov qword ptr [r15+0x50], 0x4205C0
0000740abd3ce930  mov qword ptr [r15+0x60], 0x00
0000740abd3ce938  mov qword ptr [r15+0x68], 0x4205C0
0000740abd3ce940  mov rax, [r15+0x40]
0000740abd3ce944  mov r14, [r13+rax*1]
0000740abd3ce949  lea r12, [rax+0x08]
0000740abd3ce94d  mov r11, [r13+r12*1]
0000740abd3ce952  movq xmm15, r14
0000740abd3ce957  movq xmm14, r11
0000740abd3ce95c  movq xmm15, xmm15
0000740abd3ce961  movq xmm15, xmm15
0000740abd3ce966  movaps [r15+0x120], xmm15
0000740abd3ce96e  movq xmm14, xmm14
0000740abd3ce973  movq xmm14, xmm14
0000740abd3ce978  movaps [r15+0x130], xmm14
0000740abd3ce980  lea r14, [rax+0x10]
0000740abd3ce984  mov r12, [r13+r14*1]
0000740abd3ce989  lea r14, [rax+0x18]
0000740abd3ce98d  mov r11, [r13+r14*1]
0000740abd3ce992  movq xmm15, r12
0000740abd3ce997  movq xmm14, r11
0000740abd3ce99c  movq xmm15, xmm15
0000740abd3ce9a1  movq xmm15, xmm15
0000740abd3ce9a6  movaps [r15+0x140], xmm15
0000740abd3ce9ae  movq xmm14, xmm14
0000740abd3ce9b3  movq xmm14, xmm14
0000740abd3ce9b8  movaps [r15+0x150], xmm14
0000740abd3ce9c0  lea r14, [rax+0x20]
0000740abd3ce9c4  mov r12, [r13+r14*1]
0000740abd3ce9c9  lea r14, [rax+0x28]
0000740abd3ce9cd  mov r11, [r13+r14*1]
0000740abd3ce9d2  movq xmm15, r12
0000740abd3ce9d7  movq xmm14, r11
0000740abd3ce9dc  movq xmm15, xmm15
0000740abd3ce9e1  movq xmm15, xmm15
0000740abd3ce9e6  movaps [r15+0x160], xmm15
0000740abd3ce9ee  movq xmm14, xmm14
0000740abd3ce9f3  movq xmm14, xmm14
0000740abd3ce9f8  movaps [r15+0x170], xmm14
0000740abd3cea00  lea r14, [rax+0x30]
0000740abd3cea04  mov r12, [r13+r14*1]
0000740abd3cea09  lea r14, [rax+0x38]
0000740abd3cea0d  mov rax, [r13+r14*1]
0000740abd3cea12  movq xmm15, r12
0000740abd3cea17  movq xmm14, rax
0000740abd3cea1c  movq xmm15, xmm15
0000740abd3cea21  movq xmm15, xmm15
0000740abd3cea26  movaps [r15+0x180], xmm15
0000740abd3cea2e  movq xmm14, xmm14
0000740abd3cea33  movq xmm14, xmm14
0000740abd3cea38  movaps [r15+0x210], xmm14
0000740abd3cea40  mov rax, [r15+0x48]
0000740abd3cea44  mov [r15+0x78], rax
0000740abd3cea48  mov r14, [r13+rax*1]
0000740abd3cea4d  movq xmm15, r14
0000740abd3cea52  lea r14, [rax+0x40]
0000740abd3cea56  mov r12, [r13+r14*1]
0000740abd3cea5b  movq xmm14, r12
0000740abd3cea60  lea r14, [rax+0x80]
0000740abd3cea67  mov r12, [r13+r14*1]
0000740abd3cea6c  movq xmm13, r12
0000740abd3cea71  movaps xmm12, [r15+0x120]
0000740abd3cea79  movq r14, xmm12
0000740abd3cea7e  movq r12, xmm15
0000740abd3cea83  vmovq xmm15, r14
0000740abd3cea88  vmovq xmm12, r12
0000740abd3cea8d  movaps xmm11, xmm15
0000740abd3cea91  mulsd xmm11, xmm12
0000740abd3cea96  ucomisd xmm11, xmm11
0000740abd3cea9b  jp 0x0000740ABD3CEEFC
0000740abd3ceaa1  movq xmm11, xmm11
0000740abd3ceaa6  movaps xmm15, [r15+0x130]
0000740abd3ceaae  movq r14, xmm15
0000740abd3ceab3  movq r12, xmm14
0000740abd3ceab8  vmovq xmm15, r14
0000740abd3ceabd  vmovq xmm14, r12
0000740abd3ceac2  movaps xmm12, xmm15
0000740abd3ceac6  mulsd xmm12, xmm14
0000740abd3ceacb  ucomisd xmm12, xmm12
0000740abd3cead0  jp 0x0000740ABD3CEF48
0000740abd3cead6  movq xmm12, xmm12
0000740abd3ceadb  movq r14, xmm11
0000740abd3ceae0  movq r12, xmm1
0000740abd3ceae5  vmovq xmm1, r14
0000740abd3ceaea  vmovq xmm15, r12
0000740abd3ceaef  movaps xmm14, xmm1
0000740abd3ceaf3  addsd xmm14, xmm15
0000740abd3ceaf8  ucomisd xmm14, xmm14
0000740abd3ceafd  jp 0x0000740ABD3CEF94
0000740abd3ceb03  movq xmm14, xmm14
0000740abd3ceb08  movq r14, xmm14
0000740abd3ceb0d  movq r12, xmm12
0000740abd3ceb12  vmovq xmm1, r14
0000740abd3ceb17  vmovq xmm15, r12
0000740abd3ceb1c  movaps xmm14, xmm1
0000740abd3ceb20  addsd xmm14, xmm15
0000740abd3ceb25  ucomisd xmm14, xmm14
0000740abd3ceb2a  jp 0x0000740ABD3CEFE0
0000740abd3ceb30  movq xmm14, xmm14
0000740abd3ceb35  movaps xmm1, [r15+0x140]
0000740abd3ceb3d  movq r14, xmm1
0000740abd3ceb42  movq r12, xmm13
0000740abd3ceb47  vmovq xmm1, r14
0000740abd3ceb4c  vmovq xmm15, r12
0000740abd3ceb51  movaps xmm13, xmm1
0000740abd3ceb55  mulsd xmm13, xmm15
0000740abd3ceb5a  ucomisd xmm13, xmm13
0000740abd3ceb5f  jp 0x0000740ABD3CF02C
0000740abd3ceb65  movq xmm13, xmm13
0000740abd3ceb6a  lea r14, [rax+0xC0]
0000740abd3ceb71  mov r12, [r13+r14*1]
0000740abd3ceb76  movq xmm1, r12
0000740abd3ceb7b  movq r14, xmm14
0000740abd3ceb80  movq r12, xmm13
0000740abd3ceb85  vmovq xmm15, r14
0000740abd3ceb8a  vmovq xmm14, r12
0000740abd3ceb8f  movaps xmm13, xmm15
0000740abd3ceb93  addsd xmm13, xmm14
0000740abd3ceb98  ucomisd xmm13, xmm13
0000740abd3ceb9d  jp 0x0000740ABD3CF082
0000740abd3ceba3  movq xmm13, xmm13
0000740abd3ceba8  movaps xmm15, [r15+0x150]
0000740abd3cebb0  movq r14, xmm15
0000740abd3cebb5  movq r12, xmm1
0000740abd3cebba  vmovq xmm1, r14
0000740abd3cebbf  vmovq xmm15, r12
0000740abd3cebc4  movaps xmm14, xmm1
0000740abd3cebc8  mulsd xmm14, xmm15
0000740abd3cebcd  ucomisd xmm14, xmm14
0000740abd3cebd2  jp 0x0000740ABD3CF0CE
0000740abd3cebd8  movq xmm14, xmm14
0000740abd3cebdd  lea r14, [rax+0x100]
0000740abd3cebe4  mov r12, [r13+r14*1]
0000740abd3cebe9  movq xmm1, r12
0000740abd3cebee  movq r14, xmm13
0000740abd3cebf3  movq r12, xmm14
0000740abd3cebf8  vmovq xmm15, r14
0000740abd3cebfd  vmovq xmm14, r12
0000740abd3cec02  movaps xmm13, xmm15
0000740abd3cec06  addsd xmm13, xmm14
0000740abd3cec0b  ucomisd xmm13, xmm13
0000740abd3cec10  jp 0x0000740ABD3CF124
0000740abd3cec16  movq xmm13, xmm13
0000740abd3cec1b  movaps xmm15, [r15+0x160]
0000740abd3cec23  movq r14, xmm15
0000740abd3cec28  movq r12, xmm1
0000740abd3cec2d  vmovq xmm1, r14
0000740abd3cec32  vmovq xmm15, r12
0000740abd3cec37  movaps xmm14, xmm1
0000740abd3cec3b  mulsd xmm14, xmm15
0000740abd3cec40  ucomisd xmm14, xmm14
0000740abd3cec45  jp 0x0000740ABD3CF170
0000740abd3cec4b  movq xmm14, xmm14
0000740abd3cec50  lea r14, [rax+0x140]
0000740abd3cec57  mov r12, [r13+r14*1]
0000740abd3cec5c  movq xmm1, r12
0000740abd3cec61  movq r14, xmm13
0000740abd3cec66  movq r12, xmm14
0000740abd3cec6b  vmovq xmm15, r14
0000740abd3cec70  vmovq xmm14, r12
0000740abd3cec75  movaps xmm13, xmm15
0000740abd3cec79  addsd xmm13, xmm14
0000740abd3cec7e  ucomisd xmm13, xmm13
0000740abd3cec83  jp 0x0000740ABD3CF1C6
0000740abd3cec89  movq xmm13, xmm13
0000740abd3cec8e  movaps xmm15, [r15+0x170]
0000740abd3cec96  movq r14, xmm15
0000740abd3cec9b  movq r12, xmm1
0000740abd3ceca0  vmovq xmm1, r14
0000740abd3ceca5  vmovq xmm15, r12
0000740abd3cecaa  movaps xmm14, xmm1
0000740abd3cecae  mulsd xmm14, xmm15
0000740abd3cecb3  ucomisd xmm14, xmm14
0000740abd3cecb8  jp 0x0000740ABD3CF212
0000740abd3cecbe  movq xmm14, xmm14
0000740abd3cecc3  lea r14, [rax+0x180]
0000740abd3cecca  mov r12, [r13+r14*1]
0000740abd3ceccf  movq xmm1, r12
0000740abd3cecd4  movq r14, xmm13
0000740abd3cecd9  movq r12, xmm14
0000740abd3cecde  vmovq xmm15, r14
0000740abd3cece3  vmovq xmm14, r12
0000740abd3cece8  movaps xmm13, xmm15
0000740abd3cecec  addsd xmm13, xmm14
0000740abd3cecf1  ucomisd xmm13, xmm13
0000740abd3cecf6  jp 0x0000740ABD3CF268
0000740abd3cecfc  movq xmm13, xmm13
0000740abd3ced01  movaps xmm15, [r15+0x180]
0000740abd3ced09  movq r14, xmm15
0000740abd3ced0e  movq r12, xmm1
0000740abd3ced13  vmovq xmm1, r14
0000740abd3ced18  vmovq xmm15, r12
0000740abd3ced1d  movaps xmm14, xmm1
0000740abd3ced21  mulsd xmm14, xmm15
0000740abd3ced26  ucomisd xmm14, xmm14
0000740abd3ced2b  jp 0x0000740ABD3CF2B4
0000740abd3ced31  movq xmm14, xmm14
0000740abd3ced36  lea r14, [rax+0x1C0]
0000740abd3ced3d  mov rax, [r13+r14*1]
0000740abd3ced42  movq xmm1, rax
0000740abd3ced47  movaps [r15+0x240], xmm1
0000740abd3ced4f  movq rax, xmm13
0000740abd3ced54  movq r14, xmm14
0000740abd3ced59  vmovq xmm15, rax
0000740abd3ced5e  vmovq xmm14, r14
0000740abd3ced63  movaps xmm13, xmm15
0000740abd3ced67  addsd xmm13, xmm14
0000740abd3ced6c  ucomisd xmm13, xmm13
0000740abd3ced71  jp 0x0000740ABD3CF30A
0000740abd3ced77  movq xmm13, xmm13
0000740abd3ced7c  movaps xmm15, [r15+0x210]
0000740abd3ced84  movq rax, xmm15
0000740abd3ced89  movq r14, xmm1
0000740abd3ced8e  vmovq xmm1, rax
0000740abd3ced93  vmovq xmm15, r14
0000740abd3ced98  movaps xmm14, xmm1
0000740abd3ced9c  mulsd xmm14, xmm15
0000740abd3ceda1  ucomisd xmm14, xmm14
0000740abd3ceda6  jp 0x0000740ABD3CF352
0000740abd3cedac  movq xmm14, xmm14
0000740abd3cedb1  movaps [r15+0x230], xmm14
0000740abd3cedb9  movq rax, xmm13
0000740abd3cedbe  movq r14, xmm14
0000740abd3cedc3  vmovq xmm1, rax
0000740abd3cedc8  vmovq xmm15, r14
0000740abd3cedcd  movaps xmm14, xmm1
0000740abd3cedd1  addsd xmm14, xmm15
0000740abd3cedd6  ucomisd xmm14, xmm14
0000740abd3ceddb  jp 0x0000740ABD3CF39A
0000740abd3cede1  movq xmm14, xmm14
0000740abd3cede6  movaps [r15+0x220], xmm14
0000740abd3cedee  movq rax, xmm14
0000740abd3cedf3  mov r14d, 0x4205C0
0000740abd3cedf9  mov [r13+r14*1], rax
0000740abd3cedfe  mov qword ptr [r15+0x70], 0x08
0000740abd3cee06  xor eax, eax
0000740abd3cee08  mov r14d, 0x08
0000740abd3cee0e  mov r12d, 0x40
0000740abd3cee14  cmp r14, r12
0000740abd3cee17  cmc
0000740abd3cee18  lahf
0000740abd3cee19  seto al
0000740abd3cee1c  mov [r15+0x108], eax
0000740abd3cee23  mov eax, [r15+0x108]
0000740abd3cee2a  sahf
0000740abd3cee2b  jnz 0x0000740ABD3CEE5D
0000740abd3cee2d  cmp dword ptr [r15+0x318], 0x00
0000740abd3cee35  jz 0x0000740ABD3CFD40
0000740abd3cee3b  nop [rax+rax*1], ax
0000740abd3cee44  nop [rax+rax*1], eax
0000740abd3cee4c  mov eax, 0x410118
0000740abd3cee51  mov [r15+0x100], rax
0000740abd3cee58  jmp 0x0000740ABD1FE110
0000740abd3cee5d  cmp dword ptr [r15+0x318], 0x00
0000740abd3cee65  jz 0x0000740ABD3CF3F0
0000740abd3cee6b  nop [rax+rax*1], ax
0000740abd3cee74  nop [rax+rax*1], eax
0000740abd3cee7c  mov eax, 0x4100A4
0000740abd3cee81  mov [r15+0x100], rax
0000740abd3cee88  jmp 0x0000740ABD1FE110
0000740abd3cee8d  int3
0000740abd3cee8e  call 0x0000740ABD20DC20
0000740abd3cee93  jmp 0x0000740ABD3CE949
0000740abd3cee98  call 0x0000740ABD2C0370
0000740abd3cee9d  jmp 0x0000740ABD3CE952
0000740abd3ceea2  call 0x0000740ABD2E27E0
0000740abd3ceea7  jmp 0x0000740ABD3CE989
0000740abd3ceeac  call 0x0000740ABD2E1570
0000740abd3ceeb1  jmp 0x0000740ABD3CE992
0000740abd3ceeb6  call 0x0000740ABD2E27E0
0000740abd3ceebb  jmp 0x0000740ABD3CE9C9
0000740abd3ceec0  call 0x0000740ABD2E1570
0000740abd3ceec5  jmp 0x0000740ABD3CE9D2
0000740abd3ceeca  call 0x0000740ABD2E27E0
0000740abd3ceecf  jmp 0x0000740ABD3CEA09
0000740abd3ceed4  call 0x0000740ABD2D59C0
0000740abd3ceed9  jmp 0x0000740ABD3CEA12
0000740abd3ceede  call 0x0000740ABD20DC20
0000740abd3ceee3  jmp 0x0000740ABD3CEA4D
0000740abd3ceee8  call 0x0000740ABD2E27E0
0000740abd3ceeed  jmp 0x0000740ABD3CEA5B
0000740abd3ceef2  call 0x0000740ABD2E27E0
0000740abd3ceef7  jmp 0x0000740ABD3CEA6C
0000740abd3ceefc  ucomisd xmm15, xmm12
0000740abd3cef01  jp 0x0000740ABD3CEF10
0000740abd3cef03  movaps xmm11, [0x0000740ABCFFE030]
0000740abd3cef0b  jmp 0x0000740ABD3CEAA1
0000740abd3cef10  vxorps xmm0, xmm15, xmm12
0000740abd3cef15  pextrw r14d, xmm0, 0x03
0000740abd3cef1b  and r14d, 0x7FF8
0000740abd3cef22  cmp r14d, 0x08
0000740abd3cef26  jnz 0x0000740ABD3CEAA1
0000740abd3cef2c  movq r14, xmm12
0000740abd3cef31  shl r14, 0x0D
0000740abd3cef35  jbe 0x0000740ABD3CEAA1
0000740abd3cef3b  vorps xmm11, xmm12, [0x0000740ABCFFE040]
0000740abd3cef43  jmp 0x0000740ABD3CEAA1
0000740abd3cef48  ucomisd xmm15, xmm14
0000740abd3cef4d  jp 0x0000740ABD3CEF5C
0000740abd3cef4f  movaps xmm12, [0x0000740ABCFFE030]
0000740abd3cef57  jmp 0x0000740ABD3CEAD6
0000740abd3cef5c  vxorps xmm0, xmm15, xmm14
0000740abd3cef61  pextrw r14d, xmm0, 0x03
0000740abd3cef67  and r14d, 0x7FF8
0000740abd3cef6e  cmp r14d, 0x08
0000740abd3cef72  jnz 0x0000740ABD3CEAD6
0000740abd3cef78  movq r14, xmm14
0000740abd3cef7d  shl r14, 0x0D
0000740abd3cef81  jbe 0x0000740ABD3CEAD6
0000740abd3cef87  vorps xmm12, xmm14, [0x0000740ABCFFE040]
0000740abd3cef8f  jmp 0x0000740ABD3CEAD6
0000740abd3cef94  ucomisd xmm1, xmm15
0000740abd3cef99  jp 0x0000740ABD3CEFA8
0000740abd3cef9b  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cefa3  jmp 0x0000740ABD3CEB03
0000740abd3cefa8  vxorps xmm0, xmm1, xmm15
0000740abd3cefad  pextrw r14d, xmm0, 0x03
0000740abd3cefb3  and r14d, 0x7FF8
0000740abd3cefba  cmp r14d, 0x08
0000740abd3cefbe  jnz 0x0000740ABD3CEB03
0000740abd3cefc4  movq r14, xmm15
0000740abd3cefc9  shl r14, 0x0D
0000740abd3cefcd  jbe 0x0000740ABD3CEB03
0000740abd3cefd3  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cefdb  jmp 0x0000740ABD3CEB03
0000740abd3cefe0  ucomisd xmm1, xmm15
0000740abd3cefe5  jp 0x0000740ABD3CEFF4
0000740abd3cefe7  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cefef  jmp 0x0000740ABD3CEB30
0000740abd3ceff4  vxorps xmm0, xmm1, xmm15
0000740abd3ceff9  pextrw r14d, xmm0, 0x03
0000740abd3cefff  and r14d, 0x7FF8
0000740abd3cf006  cmp r14d, 0x08
0000740abd3cf00a  jnz 0x0000740ABD3CEB30
0000740abd3cf010  movq r14, xmm15
0000740abd3cf015  shl r14, 0x0D
0000740abd3cf019  jbe 0x0000740ABD3CEB30
0000740abd3cf01f  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cf027  jmp 0x0000740ABD3CEB30
0000740abd3cf02c  ucomisd xmm1, xmm15
0000740abd3cf031  jp 0x0000740ABD3CF040
0000740abd3cf033  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cf03b  jmp 0x0000740ABD3CEB65
0000740abd3cf040  vxorps xmm0, xmm1, xmm15
0000740abd3cf045  pextrw r14d, xmm0, 0x03
0000740abd3cf04b  and r14d, 0x7FF8
0000740abd3cf052  cmp r14d, 0x08
0000740abd3cf056  jnz 0x0000740ABD3CEB65
0000740abd3cf05c  movq r14, xmm15
0000740abd3cf061  shl r14, 0x0D
0000740abd3cf065  jbe 0x0000740ABD3CEB65
0000740abd3cf06b  vorps xmm13, xmm15, [0x0000740ABCFFE040]
0000740abd3cf073  jmp 0x0000740ABD3CEB65
0000740abd3cf078  call 0x0000740ABD2E27E0
0000740abd3cf07d  jmp 0x0000740ABD3CEB76
0000740abd3cf082  ucomisd xmm15, xmm14
0000740abd3cf087  jp 0x0000740ABD3CF096
0000740abd3cf089  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cf091  jmp 0x0000740ABD3CEBA3
0000740abd3cf096  vxorps xmm0, xmm15, xmm14
0000740abd3cf09b  pextrw r14d, xmm0, 0x03
0000740abd3cf0a1  and r14d, 0x7FF8
0000740abd3cf0a8  cmp r14d, 0x08
0000740abd3cf0ac  jnz 0x0000740ABD3CEBA3
0000740abd3cf0b2  movq r14, xmm14
0000740abd3cf0b7  shl r14, 0x0D
0000740abd3cf0bb  jbe 0x0000740ABD3CEBA3
0000740abd3cf0c1  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cf0c9  jmp 0x0000740ABD3CEBA3
0000740abd3cf0ce  ucomisd xmm1, xmm15
0000740abd3cf0d3  jp 0x0000740ABD3CF0E2
0000740abd3cf0d5  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cf0dd  jmp 0x0000740ABD3CEBD8
0000740abd3cf0e2  vxorps xmm0, xmm1, xmm15
0000740abd3cf0e7  pextrw r14d, xmm0, 0x03
0000740abd3cf0ed  and r14d, 0x7FF8
0000740abd3cf0f4  cmp r14d, 0x08
0000740abd3cf0f8  jnz 0x0000740ABD3CEBD8
0000740abd3cf0fe  movq r14, xmm15
0000740abd3cf103  shl r14, 0x0D
0000740abd3cf107  jbe 0x0000740ABD3CEBD8
0000740abd3cf10d  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cf115  jmp 0x0000740ABD3CEBD8
0000740abd3cf11a  call 0x0000740ABD2E27E0
0000740abd3cf11f  jmp 0x0000740ABD3CEBE9
0000740abd3cf124  ucomisd xmm15, xmm14
0000740abd3cf129  jp 0x0000740ABD3CF138
0000740abd3cf12b  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cf133  jmp 0x0000740ABD3CEC16
0000740abd3cf138  vxorps xmm0, xmm15, xmm14
0000740abd3cf13d  pextrw r14d, xmm0, 0x03
0000740abd3cf143  and r14d, 0x7FF8
0000740abd3cf14a  cmp r14d, 0x08
0000740abd3cf14e  jnz 0x0000740ABD3CEC16
0000740abd3cf154  movq r14, xmm14
0000740abd3cf159  shl r14, 0x0D
0000740abd3cf15d  jbe 0x0000740ABD3CEC16
0000740abd3cf163  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cf16b  jmp 0x0000740ABD3CEC16
0000740abd3cf170  ucomisd xmm1, xmm15
0000740abd3cf175  jp 0x0000740ABD3CF184
0000740abd3cf177  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cf17f  jmp 0x0000740ABD3CEC4B
0000740abd3cf184  vxorps xmm0, xmm1, xmm15
0000740abd3cf189  pextrw r14d, xmm0, 0x03
0000740abd3cf18f  and r14d, 0x7FF8
0000740abd3cf196  cmp r14d, 0x08
0000740abd3cf19a  jnz 0x0000740ABD3CEC4B
0000740abd3cf1a0  movq r14, xmm15
0000740abd3cf1a5  shl r14, 0x0D
0000740abd3cf1a9  jbe 0x0000740ABD3CEC4B
0000740abd3cf1af  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cf1b7  jmp 0x0000740ABD3CEC4B
0000740abd3cf1bc  call 0x0000740ABD2E27E0
0000740abd3cf1c1  jmp 0x0000740ABD3CEC5C
0000740abd3cf1c6  ucomisd xmm15, xmm14
0000740abd3cf1cb  jp 0x0000740ABD3CF1DA
0000740abd3cf1cd  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cf1d5  jmp 0x0000740ABD3CEC89
0000740abd3cf1da  vxorps xmm0, xmm15, xmm14
0000740abd3cf1df  pextrw r14d, xmm0, 0x03
0000740abd3cf1e5  and r14d, 0x7FF8
0000740abd3cf1ec  cmp r14d, 0x08
0000740abd3cf1f0  jnz 0x0000740ABD3CEC89
0000740abd3cf1f6  movq r14, xmm14
0000740abd3cf1fb  shl r14, 0x0D
0000740abd3cf1ff  jbe 0x0000740ABD3CEC89
0000740abd3cf205  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cf20d  jmp 0x0000740ABD3CEC89
0000740abd3cf212  ucomisd xmm1, xmm15
0000740abd3cf217  jp 0x0000740ABD3CF226
0000740abd3cf219  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cf221  jmp 0x0000740ABD3CECBE
0000740abd3cf226  vxorps xmm0, xmm1, xmm15
0000740abd3cf22b  pextrw r14d, xmm0, 0x03
0000740abd3cf231  and r14d, 0x7FF8
0000740abd3cf238  cmp r14d, 0x08
0000740abd3cf23c  jnz 0x0000740ABD3CECBE
0000740abd3cf242  movq r14, xmm15
0000740abd3cf247  shl r14, 0x0D
0000740abd3cf24b  jbe 0x0000740ABD3CECBE
0000740abd3cf251  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cf259  jmp 0x0000740ABD3CECBE
0000740abd3cf25e  call 0x0000740ABD2E27E0
0000740abd3cf263  jmp 0x0000740ABD3CECCF
0000740abd3cf268  ucomisd xmm15, xmm14
0000740abd3cf26d  jp 0x0000740ABD3CF27C
0000740abd3cf26f  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cf277  jmp 0x0000740ABD3CECFC
0000740abd3cf27c  vxorps xmm0, xmm15, xmm14
0000740abd3cf281  pextrw r14d, xmm0, 0x03
0000740abd3cf287  and r14d, 0x7FF8
0000740abd3cf28e  cmp r14d, 0x08
0000740abd3cf292  jnz 0x0000740ABD3CECFC
0000740abd3cf298  movq r14, xmm14
0000740abd3cf29d  shl r14, 0x0D
0000740abd3cf2a1  jbe 0x0000740ABD3CECFC
0000740abd3cf2a7  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cf2af  jmp 0x0000740ABD3CECFC
0000740abd3cf2b4  ucomisd xmm1, xmm15
0000740abd3cf2b9  jp 0x0000740ABD3CF2C8
0000740abd3cf2bb  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cf2c3  jmp 0x0000740ABD3CED31
0000740abd3cf2c8  vxorps xmm0, xmm1, xmm15
0000740abd3cf2cd  pextrw r14d, xmm0, 0x03
0000740abd3cf2d3  and r14d, 0x7FF8
0000740abd3cf2da  cmp r14d, 0x08
0000740abd3cf2de  jnz 0x0000740ABD3CED31
0000740abd3cf2e4  movq r14, xmm15
0000740abd3cf2e9  shl r14, 0x0D
0000740abd3cf2ed  jbe 0x0000740ABD3CED31
0000740abd3cf2f3  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cf2fb  jmp 0x0000740ABD3CED31
0000740abd3cf300  call 0x0000740ABD2D59C0
0000740abd3cf305  jmp 0x0000740ABD3CED42
0000740abd3cf30a  ucomisd xmm15, xmm14
0000740abd3cf30f  jp 0x0000740ABD3CF31E
0000740abd3cf311  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cf319  jmp 0x0000740ABD3CED77
0000740abd3cf31e  vxorps xmm0, xmm15, xmm14
0000740abd3cf323  pextrw eax, xmm0, 0x03
0000740abd3cf328  and eax, 0x7FF8
0000740abd3cf32d  cmp eax, 0x08
0000740abd3cf330  jnz 0x0000740ABD3CED77
0000740abd3cf336  movq rax, xmm14
0000740abd3cf33b  shl rax, 0x0D
0000740abd3cf33f  jbe 0x0000740ABD3CED77
0000740abd3cf345  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cf34d  jmp 0x0000740ABD3CED77
0000740abd3cf352  ucomisd xmm1, xmm15
0000740abd3cf357  jp 0x0000740ABD3CF366
0000740abd3cf359  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cf361  jmp 0x0000740ABD3CEDAC
0000740abd3cf366  vxorps xmm0, xmm1, xmm15
0000740abd3cf36b  pextrw eax, xmm0, 0x03
0000740abd3cf370  and eax, 0x7FF8
0000740abd3cf375  cmp eax, 0x08
0000740abd3cf378  jnz 0x0000740ABD3CEDAC
0000740abd3cf37e  movq rax, xmm15
0000740abd3cf383  shl rax, 0x0D
0000740abd3cf387  jbe 0x0000740ABD3CEDAC
0000740abd3cf38d  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cf395  jmp 0x0000740ABD3CEDAC
0000740abd3cf39a  ucomisd xmm1, xmm15
0000740abd3cf39f  jp 0x0000740ABD3CF3AE
0000740abd3cf3a1  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cf3a9  jmp 0x0000740ABD3CEDE1
0000740abd3cf3ae  vxorps xmm0, xmm1, xmm15
0000740abd3cf3b3  pextrw eax, xmm0, 0x03
0000740abd3cf3b8  and eax, 0x7FF8
0000740abd3cf3bd  cmp eax, 0x08
0000740abd3cf3c0  jnz 0x0000740ABD3CEDE1
0000740abd3cf3c6  movq rax, xmm15
0000740abd3cf3cb  shl rax, 0x0D
0000740abd3cf3cf  jbe 0x0000740ABD3CEDE1
0000740abd3cf3d5  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cf3dd  jmp 0x0000740ABD3CEDE1
0000740abd3cf3e2  call 0x0000740ABD2D5EB0
0000740abd3cf3e7  jmp 0x0000740ABD3CEDFE
0000740abd3cf3ec  int3
0000740abd3cf3ed  nop [rax], eax
0000740abd3cf3f0  mov rax, [r15+0x48]
0000740abd3cf3f4  mov r14, [r15+0x70]
0000740abd3cf3f8  lea r12, [rax+r14*1]
0000740abd3cf3fc  mov [r15+0x78], r12
0000740abd3cf400  mov rax, [r13+r12*1]
0000740abd3cf405  movq xmm1, rax
0000740abd3cf40a  lea rax, [r12+0x40]
0000740abd3cf40f  mov r11, [r13+rax*1]
0000740abd3cf414  movq xmm15, r11
0000740abd3cf419  lea rax, [r12+0x80]
0000740abd3cf421  mov r11, [r13+rax*1]
0000740abd3cf426  movq xmm14, r11
0000740abd3cf42b  movaps xmm13, [r15+0x120]
0000740abd3cf433  movq rax, xmm13
0000740abd3cf438  movq r11, xmm1
0000740abd3cf43d  vmovq xmm1, rax
0000740abd3cf442  vmovq xmm13, r11
0000740abd3cf447  movaps xmm12, xmm1
0000740abd3cf44b  mulsd xmm12, xmm13
0000740abd3cf450  ucomisd xmm12, xmm12
0000740abd3cf455  jp 0x0000740ABD3CF879
0000740abd3cf45b  movq xmm12, xmm12
0000740abd3cf460  movaps xmm1, [r15+0x130]
0000740abd3cf468  movq rax, xmm1
0000740abd3cf46d  movq r11, xmm15
0000740abd3cf472  vmovq xmm1, rax
0000740abd3cf477  vmovq xmm15, r11
0000740abd3cf47c  movaps xmm13, xmm1
0000740abd3cf480  mulsd xmm13, xmm15
0000740abd3cf485  ucomisd xmm13, xmm13
0000740abd3cf48a  jp 0x0000740ABD3CF8C1
0000740abd3cf490  movq xmm13, xmm13
0000740abd3cf495  movq rax, xmm12
0000740abd3cf49a  movaps xmm1, [r15+0x110]
0000740abd3cf4a2  movq r11, xmm1
0000740abd3cf4a7  vmovq xmm1, rax
0000740abd3cf4ac  vmovq xmm15, r11
0000740abd3cf4b1  movaps xmm12, xmm1
0000740abd3cf4b5  addsd xmm12, xmm15
0000740abd3cf4ba  ucomisd xmm12, xmm12
0000740abd3cf4bf  jp 0x0000740ABD3CF909
0000740abd3cf4c5  movq xmm12, xmm12
0000740abd3cf4ca  movq rax, xmm12
0000740abd3cf4cf  movq r11, xmm13
0000740abd3cf4d4  vmovq xmm1, rax
0000740abd3cf4d9  vmovq xmm15, r11
0000740abd3cf4de  movaps xmm13, xmm1
0000740abd3cf4e2  addsd xmm13, xmm15
0000740abd3cf4e7  ucomisd xmm13, xmm13
0000740abd3cf4ec  jp 0x0000740ABD3CF951
0000740abd3cf4f2  movq xmm13, xmm13
0000740abd3cf4f7  movaps xmm1, [r15+0x140]
0000740abd3cf4ff  movq rax, xmm1
0000740abd3cf504  movq r11, xmm14
0000740abd3cf509  vmovq xmm1, rax
0000740abd3cf50e  vmovq xmm15, r11
0000740abd3cf513  movaps xmm14, xmm1
0000740abd3cf517  mulsd xmm14, xmm15
0000740abd3cf51c  ucomisd xmm14, xmm14
0000740abd3cf521  jp 0x0000740ABD3CF999
0000740abd3cf527  movq xmm14, xmm14
0000740abd3cf52c  lea rax, [r12+0xC0]
0000740abd3cf534  mov r11, [r13+rax*1]
0000740abd3cf539  movq xmm1, r11
0000740abd3cf53e  movq rax, xmm13
0000740abd3cf543  movq r11, xmm14
0000740abd3cf548  vmovq xmm15, rax
0000740abd3cf54d  vmovq xmm14, r11
0000740abd3cf552  movaps xmm13, xmm15
0000740abd3cf556  addsd xmm13, xmm14
0000740abd3cf55b  ucomisd xmm13, xmm13
0000740abd3cf560  jp 0x0000740ABD3CF9EB
0000740abd3cf566  movq xmm13, xmm13
0000740abd3cf56b  movaps xmm15, [r15+0x150]
0000740abd3cf573  movq rax, xmm15
0000740abd3cf578  movq r11, xmm1
0000740abd3cf57d  vmovq xmm1, rax
0000740abd3cf582  vmovq xmm15, r11
0000740abd3cf587  movaps xmm14, xmm1
0000740abd3cf58b  mulsd xmm14, xmm15
0000740abd3cf590  ucomisd xmm14, xmm14
0000740abd3cf595  jp 0x0000740ABD3CFA33
0000740abd3cf59b  movq xmm14, xmm14
0000740abd3cf5a0  lea rax, [r12+0x100]
0000740abd3cf5a8  mov r11, [r13+rax*1]
0000740abd3cf5ad  movq xmm1, r11
0000740abd3cf5b2  movq rax, xmm13
0000740abd3cf5b7  movq r11, xmm14
0000740abd3cf5bc  vmovq xmm15, rax
0000740abd3cf5c1  vmovq xmm14, r11
0000740abd3cf5c6  movaps xmm13, xmm15
0000740abd3cf5ca  addsd xmm13, xmm14
0000740abd3cf5cf  ucomisd xmm13, xmm13
0000740abd3cf5d4  jp 0x0000740ABD3CFA85
0000740abd3cf5da  movq xmm13, xmm13
0000740abd3cf5df  movaps xmm15, [r15+0x160]
0000740abd3cf5e7  movq rax, xmm15
0000740abd3cf5ec  movq r11, xmm1
0000740abd3cf5f1  vmovq xmm1, rax
0000740abd3cf5f6  vmovq xmm15, r11
0000740abd3cf5fb  movaps xmm14, xmm1
0000740abd3cf5ff  mulsd xmm14, xmm15
0000740abd3cf604  ucomisd xmm14, xmm14
0000740abd3cf609  jp 0x0000740ABD3CFACD
0000740abd3cf60f  movq xmm14, xmm14
0000740abd3cf614  lea rax, [r12+0x140]
0000740abd3cf61c  mov r11, [r13+rax*1]
0000740abd3cf621  movq xmm1, r11
0000740abd3cf626  movq rax, xmm13
0000740abd3cf62b  movq r11, xmm14
0000740abd3cf630  vmovq xmm15, rax
0000740abd3cf635  vmovq xmm14, r11
0000740abd3cf63a  movaps xmm13, xmm15
0000740abd3cf63e  addsd xmm13, xmm14
0000740abd3cf643  ucomisd xmm13, xmm13
0000740abd3cf648  jp 0x0000740ABD3CFB1F
0000740abd3cf64e  movq xmm13, xmm13
0000740abd3cf653  movaps xmm15, [r15+0x170]
0000740abd3cf65b  movq rax, xmm15
0000740abd3cf660  movq r11, xmm1
0000740abd3cf665  vmovq xmm1, rax
0000740abd3cf66a  vmovq xmm15, r11
0000740abd3cf66f  movaps xmm14, xmm1
0000740abd3cf673  mulsd xmm14, xmm15
0000740abd3cf678  ucomisd xmm14, xmm14
0000740abd3cf67d  jp 0x0000740ABD3CFB67
0000740abd3cf683  movq xmm14, xmm14
0000740abd3cf688  lea rax, [r12+0x180]
0000740abd3cf690  mov r11, [r13+rax*1]
0000740abd3cf695  movq xmm1, r11
0000740abd3cf69a  movq rax, xmm13
0000740abd3cf69f  movq r11, xmm14
0000740abd3cf6a4  vmovq xmm15, rax
0000740abd3cf6a9  vmovq xmm14, r11
0000740abd3cf6ae  movaps xmm13, xmm15
0000740abd3cf6b2  addsd xmm13, xmm14
0000740abd3cf6b7  ucomisd xmm13, xmm13
0000740abd3cf6bc  jp 0x0000740ABD3CFBB9
0000740abd3cf6c2  movq xmm13, xmm13
0000740abd3cf6c7  movaps xmm15, [r15+0x180]
0000740abd3cf6cf  movq rax, xmm15
0000740abd3cf6d4  movq r11, xmm1
0000740abd3cf6d9  vmovq xmm1, rax
0000740abd3cf6de  vmovq xmm15, r11
0000740abd3cf6e3  movaps xmm14, xmm1
0000740abd3cf6e7  mulsd xmm14, xmm15
0000740abd3cf6ec  ucomisd xmm14, xmm14
0000740abd3cf6f1  jp 0x0000740ABD3CFC01
0000740abd3cf6f7  movq xmm14, xmm14
0000740abd3cf6fc  lea rax, [r12+0x1C0]
0000740abd3cf704  mov r12, [r13+rax*1]
0000740abd3cf709  movq xmm1, r12
0000740abd3cf70e  movaps [r15+0x240], xmm1
0000740abd3cf716  movq rax, xmm13
0000740abd3cf71b  movq r12, xmm14
0000740abd3cf720  vmovq xmm15, rax
0000740abd3cf725  vmovq xmm14, r12
0000740abd3cf72a  movaps xmm13, xmm15
0000740abd3cf72e  addsd xmm13, xmm14
0000740abd3cf733  ucomisd xmm13, xmm13
0000740abd3cf738  jp 0x0000740ABD3CFC53
0000740abd3cf73e  movq xmm13, xmm13
0000740abd3cf743  movaps xmm15, [r15+0x210]
0000740abd3cf74b  movq rax, xmm15
0000740abd3cf750  movq r12, xmm1
0000740abd3cf755  vmovq xmm1, rax
0000740abd3cf75a  vmovq xmm15, r12
0000740abd3cf75f  movaps xmm14, xmm1
0000740abd3cf763  mulsd xmm14, xmm15
0000740abd3cf768  ucomisd xmm14, xmm14
0000740abd3cf76d  jp 0x0000740ABD3CFC9B
0000740abd3cf773  movq xmm14, xmm14
0000740abd3cf778  movaps [r15+0x230], xmm14
0000740abd3cf780  movq rax, xmm13
0000740abd3cf785  movq r12, xmm14
0000740abd3cf78a  vmovq xmm1, rax
0000740abd3cf78f  vmovq xmm15, r12
0000740abd3cf794  movaps xmm14, xmm1
0000740abd3cf798  addsd xmm14, xmm15
0000740abd3cf79d  ucomisd xmm14, xmm14
0000740abd3cf7a2  jp 0x0000740ABD3CFCE3
0000740abd3cf7a8  movq xmm14, xmm14
0000740abd3cf7ad  movaps [r15+0x220], xmm14
0000740abd3cf7b5  mov rax, [r15+0x68]
0000740abd3cf7b9  lea r12, [rax+r14*1]
0000740abd3cf7bd  movq rax, xmm14
0000740abd3cf7c2  mov [r13+r12*1], rax
0000740abd3cf7c7  lea rax, [r14+0x08]
0000740abd3cf7cb  mov [r15+0x70], rax
0000740abd3cf7cf  mov [rsp+0x10], rax
0000740abd3cf7d4  xor eax, eax
0000740abd3cf7d6  mov r14, [rsp+0x10]
0000740abd3cf7db  mov r12d, 0x40
0000740abd3cf7e1  cmp r14, r12
0000740abd3cf7e4  cmc
0000740abd3cf7e5  lahf
0000740abd3cf7e6  seto al
0000740abd3cf7e9  mov [r15+0x108], eax
0000740abd3cf7f0  mov eax, [r15+0x108]
0000740abd3cf7f7  sahf
0000740abd3cf7f8  jnz 0x0000740ABD3CF82A
0000740abd3cf7fa  cmp dword ptr [r15+0x318], 0x00
0000740abd3cf802  jz 0x0000740ABD3CFD40
0000740abd3cf808  nop [rax+rax*1], ax
0000740abd3cf811  nop [rax+rax*1], eax
0000740abd3cf819  mov eax, 0x410118
0000740abd3cf81e  mov [r15+0x100], rax
0000740abd3cf825  jmp 0x0000740ABD1FE110
0000740abd3cf82a  cmp dword ptr [r15+0x318], 0x00
0000740abd3cf832  jz 0x0000740ABD3CF3F0
0000740abd3cf838  nop [rax+rax*1], ax
0000740abd3cf841  nop [rax+rax*1], eax
0000740abd3cf849  mov eax, 0x4100A4
0000740abd3cf84e  mov [r15+0x100], rax
0000740abd3cf855  jmp 0x0000740ABD1FE110
0000740abd3cf85a  int3
0000740abd3cf85b  call 0x0000740ABD2B47C0
0000740abd3cf860  jmp 0x0000740ABD3CF405
0000740abd3cf865  call 0x0000740ABD20A4B0
0000740abd3cf86a  jmp 0x0000740ABD3CF414
0000740abd3cf86f  call 0x0000740ABD20A4B0
0000740abd3cf874  jmp 0x0000740ABD3CF426
0000740abd3cf879  ucomisd xmm1, xmm13
0000740abd3cf87e  jp 0x0000740ABD3CF88D
0000740abd3cf880  movaps xmm12, [0x0000740ABCFFE030]
0000740abd3cf888  jmp 0x0000740ABD3CF45B
0000740abd3cf88d  vxorps xmm0, xmm1, xmm13
0000740abd3cf892  pextrw eax, xmm0, 0x03
0000740abd3cf897  and eax, 0x7FF8
0000740abd3cf89c  cmp eax, 0x08
0000740abd3cf89f  jnz 0x0000740ABD3CF45B
0000740abd3cf8a5  movq rax, xmm13
0000740abd3cf8aa  shl rax, 0x0D
0000740abd3cf8ae  jbe 0x0000740ABD3CF45B
0000740abd3cf8b4  vorps xmm12, xmm13, [0x0000740ABCFFE040]
0000740abd3cf8bc  jmp 0x0000740ABD3CF45B
0000740abd3cf8c1  ucomisd xmm1, xmm15
0000740abd3cf8c6  jp 0x0000740ABD3CF8D5
0000740abd3cf8c8  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cf8d0  jmp 0x0000740ABD3CF490
0000740abd3cf8d5  vxorps xmm0, xmm1, xmm15
0000740abd3cf8da  pextrw eax, xmm0, 0x03
0000740abd3cf8df  and eax, 0x7FF8
0000740abd3cf8e4  cmp eax, 0x08
0000740abd3cf8e7  jnz 0x0000740ABD3CF490
0000740abd3cf8ed  movq rax, xmm15
0000740abd3cf8f2  shl rax, 0x0D
0000740abd3cf8f6  jbe 0x0000740ABD3CF490
0000740abd3cf8fc  vorps xmm13, xmm15, [0x0000740ABCFFE040]
0000740abd3cf904  jmp 0x0000740ABD3CF490
0000740abd3cf909  ucomisd xmm1, xmm15
0000740abd3cf90e  jp 0x0000740ABD3CF91D
0000740abd3cf910  movaps xmm12, [0x0000740ABCFFE030]
0000740abd3cf918  jmp 0x0000740ABD3CF4C5
0000740abd3cf91d  vxorps xmm0, xmm1, xmm15
0000740abd3cf922  pextrw eax, xmm0, 0x03
0000740abd3cf927  and eax, 0x7FF8
0000740abd3cf92c  cmp eax, 0x08
0000740abd3cf92f  jnz 0x0000740ABD3CF4C5
0000740abd3cf935  movq rax, xmm15
0000740abd3cf93a  shl rax, 0x0D
0000740abd3cf93e  jbe 0x0000740ABD3CF4C5
0000740abd3cf944  vorps xmm12, xmm15, [0x0000740ABCFFE040]
0000740abd3cf94c  jmp 0x0000740ABD3CF4C5
0000740abd3cf951  ucomisd xmm1, xmm15
0000740abd3cf956  jp 0x0000740ABD3CF965
0000740abd3cf958  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cf960  jmp 0x0000740ABD3CF4F2
0000740abd3cf965  vxorps xmm0, xmm1, xmm15
0000740abd3cf96a  pextrw eax, xmm0, 0x03
0000740abd3cf96f  and eax, 0x7FF8
0000740abd3cf974  cmp eax, 0x08
0000740abd3cf977  jnz 0x0000740ABD3CF4F2
0000740abd3cf97d  movq rax, xmm15
0000740abd3cf982  shl rax, 0x0D
0000740abd3cf986  jbe 0x0000740ABD3CF4F2
0000740abd3cf98c  vorps xmm13, xmm15, [0x0000740ABCFFE040]
0000740abd3cf994  jmp 0x0000740ABD3CF4F2
0000740abd3cf999  ucomisd xmm1, xmm15
0000740abd3cf99e  jp 0x0000740ABD3CF9AD
0000740abd3cf9a0  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cf9a8  jmp 0x0000740ABD3CF527
0000740abd3cf9ad  vxorps xmm0, xmm1, xmm15
0000740abd3cf9b2  pextrw eax, xmm0, 0x03
0000740abd3cf9b7  and eax, 0x7FF8
0000740abd3cf9bc  cmp eax, 0x08
0000740abd3cf9bf  jnz 0x0000740ABD3CF527
0000740abd3cf9c5  movq rax, xmm15
0000740abd3cf9ca  shl rax, 0x0D
0000740abd3cf9ce  jbe 0x0000740ABD3CF527
0000740abd3cf9d4  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cf9dc  jmp 0x0000740ABD3CF527
0000740abd3cf9e1  call 0x0000740ABD20A4B0
0000740abd3cf9e6  jmp 0x0000740ABD3CF539
0000740abd3cf9eb  ucomisd xmm15, xmm14
0000740abd3cf9f0  jp 0x0000740ABD3CF9FF
0000740abd3cf9f2  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cf9fa  jmp 0x0000740ABD3CF566
0000740abd3cf9ff  vxorps xmm0, xmm15, xmm14
0000740abd3cfa04  pextrw eax, xmm0, 0x03
0000740abd3cfa09  and eax, 0x7FF8
0000740abd3cfa0e  cmp eax, 0x08
0000740abd3cfa11  jnz 0x0000740ABD3CF566
0000740abd3cfa17  movq rax, xmm14
0000740abd3cfa1c  shl rax, 0x0D
0000740abd3cfa20  jbe 0x0000740ABD3CF566
0000740abd3cfa26  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cfa2e  jmp 0x0000740ABD3CF566
0000740abd3cfa33  ucomisd xmm1, xmm15
0000740abd3cfa38  jp 0x0000740ABD3CFA47
0000740abd3cfa3a  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cfa42  jmp 0x0000740ABD3CF59B
0000740abd3cfa47  vxorps xmm0, xmm1, xmm15
0000740abd3cfa4c  pextrw eax, xmm0, 0x03
0000740abd3cfa51  and eax, 0x7FF8
0000740abd3cfa56  cmp eax, 0x08
0000740abd3cfa59  jnz 0x0000740ABD3CF59B
0000740abd3cfa5f  movq rax, xmm15
0000740abd3cfa64  shl rax, 0x0D
0000740abd3cfa68  jbe 0x0000740ABD3CF59B
0000740abd3cfa6e  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cfa76  jmp 0x0000740ABD3CF59B
0000740abd3cfa7b  call 0x0000740ABD20A4B0
0000740abd3cfa80  jmp 0x0000740ABD3CF5AD
0000740abd3cfa85  ucomisd xmm15, xmm14
0000740abd3cfa8a  jp 0x0000740ABD3CFA99
0000740abd3cfa8c  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cfa94  jmp 0x0000740ABD3CF5DA
0000740abd3cfa99  vxorps xmm0, xmm15, xmm14
0000740abd3cfa9e  pextrw eax, xmm0, 0x03
0000740abd3cfaa3  and eax, 0x7FF8
0000740abd3cfaa8  cmp eax, 0x08
0000740abd3cfaab  jnz 0x0000740ABD3CF5DA
0000740abd3cfab1  movq rax, xmm14
0000740abd3cfab6  shl rax, 0x0D
0000740abd3cfaba  jbe 0x0000740ABD3CF5DA
0000740abd3cfac0  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cfac8  jmp 0x0000740ABD3CF5DA
0000740abd3cfacd  ucomisd xmm1, xmm15
0000740abd3cfad2  jp 0x0000740ABD3CFAE1
0000740abd3cfad4  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cfadc  jmp 0x0000740ABD3CF60F
0000740abd3cfae1  vxorps xmm0, xmm1, xmm15
0000740abd3cfae6  pextrw eax, xmm0, 0x03
0000740abd3cfaeb  and eax, 0x7FF8
0000740abd3cfaf0  cmp eax, 0x08
0000740abd3cfaf3  jnz 0x0000740ABD3CF60F
0000740abd3cfaf9  movq rax, xmm15
0000740abd3cfafe  shl rax, 0x0D
0000740abd3cfb02  jbe 0x0000740ABD3CF60F
0000740abd3cfb08  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cfb10  jmp 0x0000740ABD3CF60F
0000740abd3cfb15  call 0x0000740ABD20A4B0
0000740abd3cfb1a  jmp 0x0000740ABD3CF621
0000740abd3cfb1f  ucomisd xmm15, xmm14
0000740abd3cfb24  jp 0x0000740ABD3CFB33
0000740abd3cfb26  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cfb2e  jmp 0x0000740ABD3CF64E
0000740abd3cfb33  vxorps xmm0, xmm15, xmm14
0000740abd3cfb38  pextrw eax, xmm0, 0x03
0000740abd3cfb3d  and eax, 0x7FF8
0000740abd3cfb42  cmp eax, 0x08
0000740abd3cfb45  jnz 0x0000740ABD3CF64E
0000740abd3cfb4b  movq rax, xmm14
0000740abd3cfb50  shl rax, 0x0D
0000740abd3cfb54  jbe 0x0000740ABD3CF64E
0000740abd3cfb5a  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cfb62  jmp 0x0000740ABD3CF64E
0000740abd3cfb67  ucomisd xmm1, xmm15
0000740abd3cfb6c  jp 0x0000740ABD3CFB7B
0000740abd3cfb6e  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cfb76  jmp 0x0000740ABD3CF683
0000740abd3cfb7b  vxorps xmm0, xmm1, xmm15
0000740abd3cfb80  pextrw eax, xmm0, 0x03
0000740abd3cfb85  and eax, 0x7FF8
0000740abd3cfb8a  cmp eax, 0x08
0000740abd3cfb8d  jnz 0x0000740ABD3CF683
0000740abd3cfb93  movq rax, xmm15
0000740abd3cfb98  shl rax, 0x0D
0000740abd3cfb9c  jbe 0x0000740ABD3CF683
0000740abd3cfba2  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cfbaa  jmp 0x0000740ABD3CF683
0000740abd3cfbaf  call 0x0000740ABD20A4B0
0000740abd3cfbb4  jmp 0x0000740ABD3CF695
0000740abd3cfbb9  ucomisd xmm15, xmm14
0000740abd3cfbbe  jp 0x0000740ABD3CFBCD
0000740abd3cfbc0  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cfbc8  jmp 0x0000740ABD3CF6C2
0000740abd3cfbcd  vxorps xmm0, xmm15, xmm14
0000740abd3cfbd2  pextrw eax, xmm0, 0x03
0000740abd3cfbd7  and eax, 0x7FF8
0000740abd3cfbdc  cmp eax, 0x08
0000740abd3cfbdf  jnz 0x0000740ABD3CF6C2
0000740abd3cfbe5  movq rax, xmm14
0000740abd3cfbea  shl rax, 0x0D
0000740abd3cfbee  jbe 0x0000740ABD3CF6C2
0000740abd3cfbf4  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cfbfc  jmp 0x0000740ABD3CF6C2
0000740abd3cfc01  ucomisd xmm1, xmm15
0000740abd3cfc06  jp 0x0000740ABD3CFC15
0000740abd3cfc08  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cfc10  jmp 0x0000740ABD3CF6F7
0000740abd3cfc15  vxorps xmm0, xmm1, xmm15
0000740abd3cfc1a  pextrw eax, xmm0, 0x03
0000740abd3cfc1f  and eax, 0x7FF8
0000740abd3cfc24  cmp eax, 0x08
0000740abd3cfc27  jnz 0x0000740ABD3CF6F7
0000740abd3cfc2d  movq rax, xmm15
0000740abd3cfc32  shl rax, 0x0D
0000740abd3cfc36  jbe 0x0000740ABD3CF6F7
0000740abd3cfc3c  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cfc44  jmp 0x0000740ABD3CF6F7
0000740abd3cfc49  call 0x0000740ABD20B720
0000740abd3cfc4e  jmp 0x0000740ABD3CF709
0000740abd3cfc53  ucomisd xmm15, xmm14
0000740abd3cfc58  jp 0x0000740ABD3CFC67
0000740abd3cfc5a  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3cfc62  jmp 0x0000740ABD3CF73E
0000740abd3cfc67  vxorps xmm0, xmm15, xmm14
0000740abd3cfc6c  pextrw eax, xmm0, 0x03
0000740abd3cfc71  and eax, 0x7FF8
0000740abd3cfc76  cmp eax, 0x08
0000740abd3cfc79  jnz 0x0000740ABD3CF73E
0000740abd3cfc7f  movq rax, xmm14
0000740abd3cfc84  shl rax, 0x0D
0000740abd3cfc88  jbe 0x0000740ABD3CF73E
0000740abd3cfc8e  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3cfc96  jmp 0x0000740ABD3CF73E
0000740abd3cfc9b  ucomisd xmm1, xmm15
0000740abd3cfca0  jp 0x0000740ABD3CFCAF
0000740abd3cfca2  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cfcaa  jmp 0x0000740ABD3CF773
0000740abd3cfcaf  vxorps xmm0, xmm1, xmm15
0000740abd3cfcb4  pextrw eax, xmm0, 0x03
0000740abd3cfcb9  and eax, 0x7FF8
0000740abd3cfcbe  cmp eax, 0x08
0000740abd3cfcc1  jnz 0x0000740ABD3CF773
0000740abd3cfcc7  movq rax, xmm15
0000740abd3cfccc  shl rax, 0x0D
0000740abd3cfcd0  jbe 0x0000740ABD3CF773
0000740abd3cfcd6  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cfcde  jmp 0x0000740ABD3CF773
0000740abd3cfce3  ucomisd xmm1, xmm15
0000740abd3cfce8  jp 0x0000740ABD3CFCF7
0000740abd3cfcea  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3cfcf2  jmp 0x0000740ABD3CF7A8
0000740abd3cfcf7  vxorps xmm0, xmm1, xmm15
0000740abd3cfcfc  pextrw eax, xmm0, 0x03
0000740abd3cfd01  and eax, 0x7FF8
0000740abd3cfd06  cmp eax, 0x08
0000740abd3cfd09  jnz 0x0000740ABD3CF7A8
0000740abd3cfd0f  movq rax, xmm15
0000740abd3cfd14  shl rax, 0x0D
0000740abd3cfd18  jbe 0x0000740ABD3CF7A8
0000740abd3cfd1e  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3cfd26  jmp 0x0000740ABD3CF7A8
0000740abd3cfd2b  call 0x0000740ABD2B4CB0
0000740abd3cfd30  jmp 0x0000740ABD3CF7C7
0000740abd3cfd35  int3
0000740abd3cfd36  nop [rax+rax*1], ax
0000740abd3cfd3f  nop
0000740abd3cfd40  mov rax, [r15+0x60]
0000740abd3cfd44  lea r14, [rax+0x01]
0000740abd3cfd48  mov [r15+0x60], r14
0000740abd3cfd4c  mov rax, [r15+0x68]
0000740abd3cfd50  lea r12, [rax+0x40]
0000740abd3cfd54  mov [r15+0x68], r12
0000740abd3cfd58  xor eax, eax
0000740abd3cfd5a  mov r12d, 0x08
0000740abd3cfd60  cmp r14, r12
0000740abd3cfd63  cmc
0000740abd3cfd64  lahf
0000740abd3cfd65  seto al
0000740abd3cfd68  mov [r15+0x108], eax
0000740abd3cfd6f  mov eax, [r15+0x108]
0000740abd3cfd76  sahf
0000740abd3cfd77  jnz 0x0000740ABD3CFDA9
0000740abd3cfd79  cmp dword ptr [r15+0x318], 0x00
0000740abd3cfd81  jz 0x0000740ABD3D08A0
0000740abd3cfd87  nop [rax+rax*1], ax
0000740abd3cfd90  nop [rax+rax*1], eax
0000740abd3cfd98  mov eax, 0x410128
0000740abd3cfd9d  mov [r15+0x100], rax
0000740abd3cfda4  jmp 0x0000740ABD1FE110
0000740abd3cfda9  cmp dword ptr [r15+0x318], 0x00
0000740abd3cfdb1  jz 0x0000740ABD3CFDE0
0000740abd3cfdb7  nop [rax+rax*1], ax
0000740abd3cfdc0  nop [rax+rax*1], eax
0000740abd3cfdc8  mov eax, 0x41008C
0000740abd3cfdcd  mov [r15+0x100], rax
0000740abd3cfdd4  jmp 0x0000740ABD1FE110
0000740abd3cfdd9  int3
0000740abd3cfdda  int3
0000740abd3cfddb  nop [rax+rax*1], eax
0000740abd3cfde0  mov rax, [r15+0x40]
0000740abd3cfde4  mov r14, [r15+0x60]
0000740abd3cfde8  shl r14, 0x06
0000740abd3cfdec  lea r12, [rax+r14*1]
0000740abd3cfdf0  mov rax, [r13+r12*1]
0000740abd3cfdf5  lea r14, [r12+0x08]
0000740abd3cfdfa  mov r11, [r13+r14*1]
0000740abd3cfdff  movq xmm1, rax
0000740abd3cfe04  movq xmm15, r11
0000740abd3cfe09  movq xmm1, xmm1
0000740abd3cfe0d  movq xmm1, xmm1
0000740abd3cfe11  movaps [r15+0x120], xmm1
0000740abd3cfe19  movq xmm15, xmm15
0000740abd3cfe1e  movq xmm15, xmm15
0000740abd3cfe23  movaps [r15+0x130], xmm15
0000740abd3cfe2b  lea rax, [r12+0x10]
0000740abd3cfe30  mov r14, [r13+rax*1]
0000740abd3cfe35  lea rax, [r12+0x18]
0000740abd3cfe3a  mov r11, [r13+rax*1]
0000740abd3cfe3f  movq xmm1, r14
0000740abd3cfe44  movq xmm15, r11
0000740abd3cfe49  movq xmm1, xmm1
0000740abd3cfe4d  movq xmm1, xmm1
0000740abd3cfe51  movaps [r15+0x140], xmm1
0000740abd3cfe59  movq xmm15, xmm15
0000740abd3cfe5e  movq xmm15, xmm15
0000740abd3cfe63  movaps [r15+0x150], xmm15
0000740abd3cfe6b  lea rax, [r12+0x20]
0000740abd3cfe70  mov r14, [r13+rax*1]
0000740abd3cfe75  lea rax, [r12+0x28]
0000740abd3cfe7a  mov r11, [r13+rax*1]
0000740abd3cfe7f  movq xmm1, r14
0000740abd3cfe84  movq xmm15, r11
0000740abd3cfe89  movq xmm1, xmm1
0000740abd3cfe8d  movq xmm1, xmm1
0000740abd3cfe91  movaps [r15+0x160], xmm1
0000740abd3cfe99  movq xmm15, xmm15
0000740abd3cfe9e  movq xmm15, xmm15
0000740abd3cfea3  movaps [r15+0x170], xmm15
0000740abd3cfeab  lea rax, [r12+0x30]
0000740abd3cfeb0  mov r14, [r13+rax*1]
0000740abd3cfeb5  lea rax, [r12+0x38]
0000740abd3cfeba  mov r12, [r13+rax*1]
0000740abd3cfebf  movq xmm1, r14
0000740abd3cfec4  movq xmm15, r12
0000740abd3cfec9  movq xmm1, xmm1
0000740abd3cfecd  movq xmm1, xmm1
0000740abd3cfed1  movaps [r15+0x180], xmm1
0000740abd3cfed9  movq xmm15, xmm15
0000740abd3cfede  movq xmm15, xmm15
0000740abd3cfee3  movaps [r15+0x210], xmm15
0000740abd3cfeeb  mov rax, [r15+0x48]
0000740abd3cfeef  mov [r15+0x78], rax
0000740abd3cfef3  mov r14, [r13+rax*1]
0000740abd3cfef8  movq xmm1, r14
0000740abd3cfefd  lea r14, [rax+0x40]
0000740abd3cff01  mov r12, [r13+r14*1]
0000740abd3cff06  movq xmm15, r12
0000740abd3cff0b  lea r14, [rax+0x80]
0000740abd3cff12  mov r12, [r13+r14*1]
0000740abd3cff17  movq xmm14, r12
0000740abd3cff1c  movaps xmm13, [r15+0x120]
0000740abd3cff24  movq r14, xmm13
0000740abd3cff29  movq r12, xmm1
0000740abd3cff2e  vmovq xmm1, r14
0000740abd3cff33  vmovq xmm13, r12
0000740abd3cff38  movaps xmm12, xmm1
0000740abd3cff3c  mulsd xmm12, xmm13
0000740abd3cff41  ucomisd xmm12, xmm12
0000740abd3cff46  jp 0x0000740ABD3D03AD
0000740abd3cff4c  movq xmm12, xmm12
0000740abd3cff51  movaps xmm1, [r15+0x130]
0000740abd3cff59  movq r14, xmm1
0000740abd3cff5e  movq r12, xmm15
0000740abd3cff63  vmovq xmm1, r14
0000740abd3cff68  vmovq xmm15, r12
0000740abd3cff6d  movaps xmm13, xmm1
0000740abd3cff71  mulsd xmm13, xmm15
0000740abd3cff76  ucomisd xmm13, xmm13
0000740abd3cff7b  jp 0x0000740ABD3D03F9
0000740abd3cff81  movq xmm13, xmm13
0000740abd3cff86  movq r14, xmm12
0000740abd3cff8b  movaps xmm1, [r15+0x110]
0000740abd3cff93  movq r12, xmm1
0000740abd3cff98  vmovq xmm1, r14
0000740abd3cff9d  vmovq xmm15, r12
0000740abd3cffa2  movaps xmm12, xmm1
0000740abd3cffa6  addsd xmm12, xmm15
0000740abd3cffab  ucomisd xmm12, xmm12
0000740abd3cffb0  jp 0x0000740ABD3D0445
0000740abd3cffb6  movq xmm12, xmm12
0000740abd3cffbb  movq r14, xmm12
0000740abd3cffc0  movq r12, xmm13
0000740abd3cffc5  vmovq xmm1, r14
0000740abd3cffca  vmovq xmm15, r12
0000740abd3cffcf  movaps xmm13, xmm1
0000740abd3cffd3  addsd xmm13, xmm15
0000740abd3cffd8  ucomisd xmm13, xmm13
0000740abd3cffdd  jp 0x0000740ABD3D0491
0000740abd3cffe3  movq xmm13, xmm13
0000740abd3cffe8  movaps xmm1, [r15+0x140]
0000740abd3cfff0  movq r14, xmm1
0000740abd3cfff5  movq r12, xmm14
0000740abd3cfffa  vmovq xmm1, r14
0000740abd3cffff  vmovq xmm15, r12
0000740abd3d0004  movaps xmm14, xmm1
0000740abd3d0008  mulsd xmm14, xmm15
0000740abd3d000d  ucomisd xmm14, xmm14
0000740abd3d0012  jp 0x0000740ABD3D04DD
0000740abd3d0018  movq xmm14, xmm14
0000740abd3d001d  lea r14, [rax+0xC0]
0000740abd3d0024  mov r12, [r13+r14*1]
0000740abd3d0029  movq xmm1, r12
0000740abd3d002e  movq r14, xmm13
0000740abd3d0033  movq r12, xmm14
0000740abd3d0038  vmovq xmm15, r14
0000740abd3d003d  vmovq xmm14, r12
0000740abd3d0042  movaps xmm13, xmm15
0000740abd3d0046  addsd xmm13, xmm14
0000740abd3d004b  ucomisd xmm13, xmm13
0000740abd3d0050  jp 0x0000740ABD3D0533
0000740abd3d0056  movq xmm13, xmm13
0000740abd3d005b  movaps xmm15, [r15+0x150]
0000740abd3d0063  movq r14, xmm15
0000740abd3d0068  movq r12, xmm1
0000740abd3d006d  vmovq xmm1, r14
0000740abd3d0072  vmovq xmm15, r12
0000740abd3d0077  movaps xmm14, xmm1
0000740abd3d007b  mulsd xmm14, xmm15
0000740abd3d0080  ucomisd xmm14, xmm14
0000740abd3d0085  jp 0x0000740ABD3D057F
0000740abd3d008b  movq xmm14, xmm14
0000740abd3d0090  lea r14, [rax+0x100]
0000740abd3d0097  mov r12, [r13+r14*1]
0000740abd3d009c  movq xmm1, r12
0000740abd3d00a1  movq r14, xmm13
0000740abd3d00a6  movq r12, xmm14
0000740abd3d00ab  vmovq xmm15, r14
0000740abd3d00b0  vmovq xmm14, r12
0000740abd3d00b5  movaps xmm13, xmm15
0000740abd3d00b9  addsd xmm13, xmm14
0000740abd3d00be  ucomisd xmm13, xmm13
0000740abd3d00c3  jp 0x0000740ABD3D05D5
0000740abd3d00c9  movq xmm13, xmm13
0000740abd3d00ce  movaps xmm15, [r15+0x160]
0000740abd3d00d6  movq r14, xmm15
0000740abd3d00db  movq r12, xmm1
0000740abd3d00e0  vmovq xmm1, r14
0000740abd3d00e5  vmovq xmm15, r12
0000740abd3d00ea  movaps xmm14, xmm1
0000740abd3d00ee  mulsd xmm14, xmm15
0000740abd3d00f3  ucomisd xmm14, xmm14
0000740abd3d00f8  jp 0x0000740ABD3D0621
0000740abd3d00fe  movq xmm14, xmm14
0000740abd3d0103  lea r14, [rax+0x140]
0000740abd3d010a  mov r12, [r13+r14*1]
0000740abd3d010f  movq xmm1, r12
0000740abd3d0114  movq r14, xmm13
0000740abd3d0119  movq r12, xmm14
0000740abd3d011e  vmovq xmm15, r14
0000740abd3d0123  vmovq xmm14, r12
0000740abd3d0128  movaps xmm13, xmm15
0000740abd3d012c  addsd xmm13, xmm14
0000740abd3d0131  ucomisd xmm13, xmm13
0000740abd3d0136  jp 0x0000740ABD3D0677
0000740abd3d013c  movq xmm13, xmm13
0000740abd3d0141  movaps xmm15, [r15+0x170]
0000740abd3d0149  movq r14, xmm15
0000740abd3d014e  movq r12, xmm1
0000740abd3d0153  vmovq xmm1, r14
0000740abd3d0158  vmovq xmm15, r12
0000740abd3d015d  movaps xmm14, xmm1
0000740abd3d0161  mulsd xmm14, xmm15
0000740abd3d0166  ucomisd xmm14, xmm14
0000740abd3d016b  jp 0x0000740ABD3D06C3
0000740abd3d0171  movq xmm14, xmm14
0000740abd3d0176  lea r14, [rax+0x180]
0000740abd3d017d  mov r12, [r13+r14*1]
0000740abd3d0182  movq xmm1, r12
0000740abd3d0187  movq r14, xmm13
0000740abd3d018c  movq r12, xmm14
0000740abd3d0191  vmovq xmm15, r14
0000740abd3d0196  vmovq xmm14, r12
0000740abd3d019b  movaps xmm13, xmm15
0000740abd3d019f  addsd xmm13, xmm14
0000740abd3d01a4  ucomisd xmm13, xmm13
0000740abd3d01a9  jp 0x0000740ABD3D0719
0000740abd3d01af  movq xmm13, xmm13
0000740abd3d01b4  movaps xmm15, [r15+0x180]
0000740abd3d01bc  movq r14, xmm15
0000740abd3d01c1  movq r12, xmm1
0000740abd3d01c6  vmovq xmm1, r14
0000740abd3d01cb  vmovq xmm15, r12
0000740abd3d01d0  movaps xmm14, xmm1
0000740abd3d01d4  mulsd xmm14, xmm15
0000740abd3d01d9  ucomisd xmm14, xmm14
0000740abd3d01de  jp 0x0000740ABD3D0765
0000740abd3d01e4  movq xmm14, xmm14
0000740abd3d01e9  lea r14, [rax+0x1C0]
0000740abd3d01f0  mov rax, [r13+r14*1]
0000740abd3d01f5  movq xmm1, rax
0000740abd3d01fa  movaps [r15+0x240], xmm1
0000740abd3d0202  movq rax, xmm13
0000740abd3d0207  movq r14, xmm14
0000740abd3d020c  vmovq xmm15, rax
0000740abd3d0211  vmovq xmm14, r14
0000740abd3d0216  movaps xmm13, xmm15
0000740abd3d021a  addsd xmm13, xmm14
0000740abd3d021f  ucomisd xmm13, xmm13
0000740abd3d0224  jp 0x0000740ABD3D07BB
0000740abd3d022a  movq xmm13, xmm13
0000740abd3d022f  movaps xmm15, [r15+0x210]
0000740abd3d0237  movq rax, xmm15
0000740abd3d023c  movq r14, xmm1
0000740abd3d0241  vmovq xmm1, rax
0000740abd3d0246  vmovq xmm15, r14
0000740abd3d024b  movaps xmm14, xmm1
0000740abd3d024f  mulsd xmm14, xmm15
0000740abd3d0254  ucomisd xmm14, xmm14
0000740abd3d0259  jp 0x0000740ABD3D0803
0000740abd3d025f  movq xmm14, xmm14
0000740abd3d0264  movaps [r15+0x230], xmm14
0000740abd3d026c  movq rax, xmm13
0000740abd3d0271  movq r14, xmm14
0000740abd3d0276  vmovq xmm1, rax
0000740abd3d027b  vmovq xmm15, r14
0000740abd3d0280  movaps xmm14, xmm1
0000740abd3d0284  addsd xmm14, xmm15
0000740abd3d0289  ucomisd xmm14, xmm14
0000740abd3d028e  jp 0x0000740ABD3D084B
0000740abd3d0294  movq xmm14, xmm14
0000740abd3d0299  movaps [r15+0x220], xmm14
0000740abd3d02a1  mov rax, [r15+0x68]
0000740abd3d02a5  movq r14, xmm14
0000740abd3d02aa  mov [r13+rax*1], r14
0000740abd3d02af  mov qword ptr [r15+0x70], 0x08
0000740abd3d02b7  xor eax, eax
0000740abd3d02b9  mov r14d, 0x08
0000740abd3d02bf  mov r12d, 0x40
0000740abd3d02c5  cmp r14, r12
0000740abd3d02c8  cmc
0000740abd3d02c9  lahf
0000740abd3d02ca  seto al
0000740abd3d02cd  mov [r15+0x108], eax
0000740abd3d02d4  mov eax, [r15+0x108]
0000740abd3d02db  sahf
0000740abd3d02dc  jnz 0x0000740ABD3D030E
0000740abd3d02de  cmp dword ptr [r15+0x318], 0x00
0000740abd3d02e6  jz 0x0000740ABD3CFD40
0000740abd3d02ec  nop [rax+rax*1], ax
0000740abd3d02f5  nop [rax+rax*1], eax
0000740abd3d02fd  mov eax, 0x410118
0000740abd3d0302  mov [r15+0x100], rax
0000740abd3d0309  jmp 0x0000740ABD1FE110
0000740abd3d030e  cmp dword ptr [r15+0x318], 0x00
0000740abd3d0316  jz 0x0000740ABD3CF3F0
0000740abd3d031c  nop [rax+rax*1], ax
0000740abd3d0325  nop [rax+rax*1], eax
0000740abd3d032d  mov eax, 0x4100A4
0000740abd3d0332  mov [r15+0x100], rax
0000740abd3d0339  jmp 0x0000740ABD1FE110
0000740abd3d033e  int3
0000740abd3d033f  call 0x0000740ABD2B47C0
0000740abd3d0344  jmp 0x0000740ABD3CFDF5
0000740abd3d0349  call 0x0000740ABD2E1570
0000740abd3d034e  jmp 0x0000740ABD3CFDFF
0000740abd3d0353  call 0x0000740ABD20DC20
0000740abd3d0358  jmp 0x0000740ABD3CFE35
0000740abd3d035d  call 0x0000740ABD20A4B0
0000740abd3d0362  jmp 0x0000740ABD3CFE3F
0000740abd3d0367  call 0x0000740ABD20DC20
0000740abd3d036c  jmp 0x0000740ABD3CFE75
0000740abd3d0371  call 0x0000740ABD20A4B0
0000740abd3d0376  jmp 0x0000740ABD3CFE7F
0000740abd3d037b  call 0x0000740ABD20DC20
0000740abd3d0380  jmp 0x0000740ABD3CFEB5
0000740abd3d0385  call 0x0000740ABD20B720
0000740abd3d038a  jmp 0x0000740ABD3CFEBF
0000740abd3d038f  call 0x0000740ABD20DC20
0000740abd3d0394  jmp 0x0000740ABD3CFEF8
0000740abd3d0399  call 0x0000740ABD2E27E0
0000740abd3d039e  jmp 0x0000740ABD3CFF06
0000740abd3d03a3  call 0x0000740ABD2E27E0
0000740abd3d03a8  jmp 0x0000740ABD3CFF17
0000740abd3d03ad  ucomisd xmm1, xmm13
0000740abd3d03b2  jp 0x0000740ABD3D03C1
0000740abd3d03b4  movaps xmm12, [0x0000740ABCFFE030]
0000740abd3d03bc  jmp 0x0000740ABD3CFF4C
0000740abd3d03c1  vxorps xmm0, xmm1, xmm13
0000740abd3d03c6  pextrw r14d, xmm0, 0x03
0000740abd3d03cc  and r14d, 0x7FF8
0000740abd3d03d3  cmp r14d, 0x08
0000740abd3d03d7  jnz 0x0000740ABD3CFF4C
0000740abd3d03dd  movq r14, xmm13
0000740abd3d03e2  shl r14, 0x0D
0000740abd3d03e6  jbe 0x0000740ABD3CFF4C
0000740abd3d03ec  vorps xmm12, xmm13, [0x0000740ABCFFE040]
0000740abd3d03f4  jmp 0x0000740ABD3CFF4C
0000740abd3d03f9  ucomisd xmm1, xmm15
0000740abd3d03fe  jp 0x0000740ABD3D040D
0000740abd3d0400  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d0408  jmp 0x0000740ABD3CFF81
0000740abd3d040d  vxorps xmm0, xmm1, xmm15
0000740abd3d0412  pextrw r14d, xmm0, 0x03
0000740abd3d0418  and r14d, 0x7FF8
0000740abd3d041f  cmp r14d, 0x08
0000740abd3d0423  jnz 0x0000740ABD3CFF81
0000740abd3d0429  movq r14, xmm15
0000740abd3d042e  shl r14, 0x0D
0000740abd3d0432  jbe 0x0000740ABD3CFF81
0000740abd3d0438  vorps xmm13, xmm15, [0x0000740ABCFFE040]
0000740abd3d0440  jmp 0x0000740ABD3CFF81
0000740abd3d0445  ucomisd xmm1, xmm15
0000740abd3d044a  jp 0x0000740ABD3D0459
0000740abd3d044c  movaps xmm12, [0x0000740ABCFFE030]
0000740abd3d0454  jmp 0x0000740ABD3CFFB6
0000740abd3d0459  vxorps xmm0, xmm1, xmm15
0000740abd3d045e  pextrw r14d, xmm0, 0x03
0000740abd3d0464  and r14d, 0x7FF8
0000740abd3d046b  cmp r14d, 0x08
0000740abd3d046f  jnz 0x0000740ABD3CFFB6
0000740abd3d0475  movq r14, xmm15
0000740abd3d047a  shl r14, 0x0D
0000740abd3d047e  jbe 0x0000740ABD3CFFB6
0000740abd3d0484  vorps xmm12, xmm15, [0x0000740ABCFFE040]
0000740abd3d048c  jmp 0x0000740ABD3CFFB6
0000740abd3d0491  ucomisd xmm1, xmm15
0000740abd3d0496  jp 0x0000740ABD3D04A5
0000740abd3d0498  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d04a0  jmp 0x0000740ABD3CFFE3
0000740abd3d04a5  vxorps xmm0, xmm1, xmm15
0000740abd3d04aa  pextrw r14d, xmm0, 0x03
0000740abd3d04b0  and r14d, 0x7FF8
0000740abd3d04b7  cmp r14d, 0x08
0000740abd3d04bb  jnz 0x0000740ABD3CFFE3
0000740abd3d04c1  movq r14, xmm15
0000740abd3d04c6  shl r14, 0x0D
0000740abd3d04ca  jbe 0x0000740ABD3CFFE3
0000740abd3d04d0  vorps xmm13, xmm15, [0x0000740ABCFFE040]
0000740abd3d04d8  jmp 0x0000740ABD3CFFE3
0000740abd3d04dd  ucomisd xmm1, xmm15
0000740abd3d04e2  jp 0x0000740ABD3D04F1
0000740abd3d04e4  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d04ec  jmp 0x0000740ABD3D0018
0000740abd3d04f1  vxorps xmm0, xmm1, xmm15
0000740abd3d04f6  pextrw r14d, xmm0, 0x03
0000740abd3d04fc  and r14d, 0x7FF8
0000740abd3d0503  cmp r14d, 0x08
0000740abd3d0507  jnz 0x0000740ABD3D0018
0000740abd3d050d  movq r14, xmm15
0000740abd3d0512  shl r14, 0x0D
0000740abd3d0516  jbe 0x0000740ABD3D0018
0000740abd3d051c  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d0524  jmp 0x0000740ABD3D0018
0000740abd3d0529  call 0x0000740ABD2E27E0
0000740abd3d052e  jmp 0x0000740ABD3D0029
0000740abd3d0533  ucomisd xmm15, xmm14
0000740abd3d0538  jp 0x0000740ABD3D0547
0000740abd3d053a  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d0542  jmp 0x0000740ABD3D0056
0000740abd3d0547  vxorps xmm0, xmm15, xmm14
0000740abd3d054c  pextrw r14d, xmm0, 0x03
0000740abd3d0552  and r14d, 0x7FF8
0000740abd3d0559  cmp r14d, 0x08
0000740abd3d055d  jnz 0x0000740ABD3D0056
0000740abd3d0563  movq r14, xmm14
0000740abd3d0568  shl r14, 0x0D
0000740abd3d056c  jbe 0x0000740ABD3D0056
0000740abd3d0572  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d057a  jmp 0x0000740ABD3D0056
0000740abd3d057f  ucomisd xmm1, xmm15
0000740abd3d0584  jp 0x0000740ABD3D0593
0000740abd3d0586  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d058e  jmp 0x0000740ABD3D008B
0000740abd3d0593  vxorps xmm0, xmm1, xmm15
0000740abd3d0598  pextrw r14d, xmm0, 0x03
0000740abd3d059e  and r14d, 0x7FF8
0000740abd3d05a5  cmp r14d, 0x08
0000740abd3d05a9  jnz 0x0000740ABD3D008B
0000740abd3d05af  movq r14, xmm15
0000740abd3d05b4  shl r14, 0x0D
0000740abd3d05b8  jbe 0x0000740ABD3D008B
0000740abd3d05be  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d05c6  jmp 0x0000740ABD3D008B
0000740abd3d05cb  call 0x0000740ABD2E27E0
0000740abd3d05d0  jmp 0x0000740ABD3D009C
0000740abd3d05d5  ucomisd xmm15, xmm14
0000740abd3d05da  jp 0x0000740ABD3D05E9
0000740abd3d05dc  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d05e4  jmp 0x0000740ABD3D00C9
0000740abd3d05e9  vxorps xmm0, xmm15, xmm14
0000740abd3d05ee  pextrw r14d, xmm0, 0x03
0000740abd3d05f4  and r14d, 0x7FF8
0000740abd3d05fb  cmp r14d, 0x08
0000740abd3d05ff  jnz 0x0000740ABD3D00C9
0000740abd3d0605  movq r14, xmm14
0000740abd3d060a  shl r14, 0x0D
0000740abd3d060e  jbe 0x0000740ABD3D00C9
0000740abd3d0614  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d061c  jmp 0x0000740ABD3D00C9
0000740abd3d0621  ucomisd xmm1, xmm15
0000740abd3d0626  jp 0x0000740ABD3D0635
0000740abd3d0628  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d0630  jmp 0x0000740ABD3D00FE
0000740abd3d0635  vxorps xmm0, xmm1, xmm15
0000740abd3d063a  pextrw r14d, xmm0, 0x03
0000740abd3d0640  and r14d, 0x7FF8
0000740abd3d0647  cmp r14d, 0x08
0000740abd3d064b  jnz 0x0000740ABD3D00FE
0000740abd3d0651  movq r14, xmm15
0000740abd3d0656  shl r14, 0x0D
0000740abd3d065a  jbe 0x0000740ABD3D00FE
0000740abd3d0660  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d0668  jmp 0x0000740ABD3D00FE
0000740abd3d066d  call 0x0000740ABD2E27E0
0000740abd3d0672  jmp 0x0000740ABD3D010F
0000740abd3d0677  ucomisd xmm15, xmm14
0000740abd3d067c  jp 0x0000740ABD3D068B
0000740abd3d067e  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d0686  jmp 0x0000740ABD3D013C
0000740abd3d068b  vxorps xmm0, xmm15, xmm14
0000740abd3d0690  pextrw r14d, xmm0, 0x03
0000740abd3d0696  and r14d, 0x7FF8
0000740abd3d069d  cmp r14d, 0x08
0000740abd3d06a1  jnz 0x0000740ABD3D013C
0000740abd3d06a7  movq r14, xmm14
0000740abd3d06ac  shl r14, 0x0D
0000740abd3d06b0  jbe 0x0000740ABD3D013C
0000740abd3d06b6  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d06be  jmp 0x0000740ABD3D013C
0000740abd3d06c3  ucomisd xmm1, xmm15
0000740abd3d06c8  jp 0x0000740ABD3D06D7
0000740abd3d06ca  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d06d2  jmp 0x0000740ABD3D0171
0000740abd3d06d7  vxorps xmm0, xmm1, xmm15
0000740abd3d06dc  pextrw r14d, xmm0, 0x03
0000740abd3d06e2  and r14d, 0x7FF8
0000740abd3d06e9  cmp r14d, 0x08
0000740abd3d06ed  jnz 0x0000740ABD3D0171
0000740abd3d06f3  movq r14, xmm15
0000740abd3d06f8  shl r14, 0x0D
0000740abd3d06fc  jbe 0x0000740ABD3D0171
0000740abd3d0702  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d070a  jmp 0x0000740ABD3D0171
0000740abd3d070f  call 0x0000740ABD2E27E0
0000740abd3d0714  jmp 0x0000740ABD3D0182
0000740abd3d0719  ucomisd xmm15, xmm14
0000740abd3d071e  jp 0x0000740ABD3D072D
0000740abd3d0720  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d0728  jmp 0x0000740ABD3D01AF
0000740abd3d072d  vxorps xmm0, xmm15, xmm14
0000740abd3d0732  pextrw r14d, xmm0, 0x03
0000740abd3d0738  and r14d, 0x7FF8
0000740abd3d073f  cmp r14d, 0x08
0000740abd3d0743  jnz 0x0000740ABD3D01AF
0000740abd3d0749  movq r14, xmm14
0000740abd3d074e  shl r14, 0x0D
0000740abd3d0752  jbe 0x0000740ABD3D01AF
0000740abd3d0758  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d0760  jmp 0x0000740ABD3D01AF
0000740abd3d0765  ucomisd xmm1, xmm15
0000740abd3d076a  jp 0x0000740ABD3D0779
0000740abd3d076c  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d0774  jmp 0x0000740ABD3D01E4
0000740abd3d0779  vxorps xmm0, xmm1, xmm15
0000740abd3d077e  pextrw r14d, xmm0, 0x03
0000740abd3d0784  and r14d, 0x7FF8
0000740abd3d078b  cmp r14d, 0x08
0000740abd3d078f  jnz 0x0000740ABD3D01E4
0000740abd3d0795  movq r14, xmm15
0000740abd3d079a  shl r14, 0x0D
0000740abd3d079e  jbe 0x0000740ABD3D01E4
0000740abd3d07a4  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d07ac  jmp 0x0000740ABD3D01E4
0000740abd3d07b1  call 0x0000740ABD2D59C0
0000740abd3d07b6  jmp 0x0000740ABD3D01F5
0000740abd3d07bb  ucomisd xmm15, xmm14
0000740abd3d07c0  jp 0x0000740ABD3D07CF
0000740abd3d07c2  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d07ca  jmp 0x0000740ABD3D022A
0000740abd3d07cf  vxorps xmm0, xmm15, xmm14
0000740abd3d07d4  pextrw eax, xmm0, 0x03
0000740abd3d07d9  and eax, 0x7FF8
0000740abd3d07de  cmp eax, 0x08
0000740abd3d07e1  jnz 0x0000740ABD3D022A
0000740abd3d07e7  movq rax, xmm14
0000740abd3d07ec  shl rax, 0x0D
0000740abd3d07f0  jbe 0x0000740ABD3D022A
0000740abd3d07f6  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d07fe  jmp 0x0000740ABD3D022A
0000740abd3d0803  ucomisd xmm1, xmm15
0000740abd3d0808  jp 0x0000740ABD3D0817
0000740abd3d080a  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d0812  jmp 0x0000740ABD3D025F
0000740abd3d0817  vxorps xmm0, xmm1, xmm15
0000740abd3d081c  pextrw eax, xmm0, 0x03
0000740abd3d0821  and eax, 0x7FF8
0000740abd3d0826  cmp eax, 0x08
0000740abd3d0829  jnz 0x0000740ABD3D025F
0000740abd3d082f  movq rax, xmm15
0000740abd3d0834  shl rax, 0x0D
0000740abd3d0838  jbe 0x0000740ABD3D025F
0000740abd3d083e  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d0846  jmp 0x0000740ABD3D025F
0000740abd3d084b  ucomisd xmm1, xmm15
0000740abd3d0850  jp 0x0000740ABD3D085F
0000740abd3d0852  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d085a  jmp 0x0000740ABD3D0294
0000740abd3d085f  vxorps xmm0, xmm1, xmm15
0000740abd3d0864  pextrw eax, xmm0, 0x03
0000740abd3d0869  and eax, 0x7FF8
0000740abd3d086e  cmp eax, 0x08
0000740abd3d0871  jnz 0x0000740ABD3D0294
0000740abd3d0877  movq rax, xmm15
0000740abd3d087c  shl rax, 0x0D
0000740abd3d0880  jbe 0x0000740ABD3D0294
0000740abd3d0886  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d088e  jmp 0x0000740ABD3D0294
0000740abd3d0893  call 0x0000740ABD20E120
0000740abd3d0898  jmp 0x0000740ABD3D02AF
0000740abd3d089d  int3
0000740abd3d089e  nop
0000740abd3d08a0  mov eax, [r15+0x58]
0000740abd3d08a4  lea r14d, [eax+0x01]
0000740abd3d08a9  mov [rsp+0x10], r14d
0000740abd3d08ae  mov r14d, r14d
0000740abd3d08b1  mov [r15+0x58], r14
0000740abd3d08b5  xor eax, eax
0000740abd3d08b7  mov r14d, [rsp+0x10]
0000740abd3d08bc  cmp r14d, 0x1F4
0000740abd3d08c3  cmc
0000740abd3d08c4  lahf
0000740abd3d08c5  seto al
0000740abd3d08c8  mov [r15+0x108], eax
0000740abd3d08cf  mov eax, [r15+0x108]
0000740abd3d08d6  sahf
0000740abd3d08d7  jnz 0x0000740ABD3D0909
0000740abd3d08d9  cmp dword ptr [r15+0x318], 0x00
0000740abd3d08e1  jz 0x0000740ABD3D1410
0000740abd3d08e7  nop [rax+rax*1], ax
0000740abd3d08f0  nop [rax+rax*1], eax
0000740abd3d08f8  mov eax, 0x410134
0000740abd3d08fd  mov [r15+0x100], rax
0000740abd3d0904  jmp 0x0000740ABD1FE110
0000740abd3d0909  cmp dword ptr [r15+0x318], 0x00
0000740abd3d0911  jz 0x0000740ABD3D0940
0000740abd3d0917  nop [rax+rax*1], ax
0000740abd3d0920  nop [rax+rax*1], eax
0000740abd3d0928  mov eax, 0x410084
0000740abd3d092d  mov [r15+0x100], rax
0000740abd3d0934  jmp 0x0000740ABD1FE110
0000740abd3d0939  int3
0000740abd3d093a  int3
0000740abd3d093b  nop [rax+rax*1], eax
0000740abd3d0940  mov qword ptr [r15+0x60], 0x00
0000740abd3d0948  mov rax, [r15+0x50]
0000740abd3d094c  mov [r15+0x68], rax
0000740abd3d0950  mov r14, [r15+0x40]
0000740abd3d0954  mov r12, [r13+r14*1]
0000740abd3d0959  lea r11, [r14+0x08]
0000740abd3d095d  mov r10, [r13+r11*1]
0000740abd3d0962  movq xmm1, r12
0000740abd3d0967  movq xmm15, r10
0000740abd3d096c  movq xmm1, xmm1
0000740abd3d0970  movq xmm1, xmm1
0000740abd3d0974  movaps [r15+0x120], xmm1
0000740abd3d097c  movq xmm15, xmm15
0000740abd3d0981  movq xmm15, xmm15
0000740abd3d0986  movaps [r15+0x130], xmm15
0000740abd3d098e  lea r12, [r14+0x10]
0000740abd3d0992  mov r11, [r13+r12*1]
0000740abd3d0997  lea r12, [r14+0x18]
0000740abd3d099b  mov r10, [r13+r12*1]
0000740abd3d09a0  movq xmm1, r11
0000740abd3d09a5  movq xmm15, r10
0000740abd3d09aa  movq xmm1, xmm1
0000740abd3d09ae  movq xmm1, xmm1
0000740abd3d09b2  movaps [r15+0x140], xmm1
0000740abd3d09ba  movq xmm15, xmm15
0000740abd3d09bf  movq xmm15, xmm15
0000740abd3d09c4  movaps [r15+0x150], xmm15
0000740abd3d09cc  lea r12, [r14+0x20]
0000740abd3d09d0  mov r11, [r13+r12*1]
0000740abd3d09d5  lea r12, [r14+0x28]
0000740abd3d09d9  mov r10, [r13+r12*1]
0000740abd3d09de  movq xmm1, r11
0000740abd3d09e3  movq xmm15, r10
0000740abd3d09e8  movq xmm1, xmm1
0000740abd3d09ec  movq xmm1, xmm1
0000740abd3d09f0  movaps [r15+0x160], xmm1
0000740abd3d09f8  movq xmm15, xmm15
0000740abd3d09fd  movq xmm15, xmm15
0000740abd3d0a02  movaps [r15+0x170], xmm15
0000740abd3d0a0a  lea r12, [r14+0x30]
0000740abd3d0a0e  mov r11, [r13+r12*1]
0000740abd3d0a13  lea r12, [r14+0x38]
0000740abd3d0a17  mov r14, [r13+r12*1]
0000740abd3d0a1c  movq xmm1, r11
0000740abd3d0a21  movq xmm15, r14
0000740abd3d0a26  movq xmm1, xmm1
0000740abd3d0a2a  movq xmm1, xmm1
0000740abd3d0a2e  movaps [r15+0x180], xmm1
0000740abd3d0a36  movq xmm15, xmm15
0000740abd3d0a3b  movq xmm15, xmm15
0000740abd3d0a40  movaps [r15+0x210], xmm15
0000740abd3d0a48  mov r14, [r15+0x48]
0000740abd3d0a4c  mov [r15+0x78], r14
0000740abd3d0a50  mov r12, [r13+r14*1]
0000740abd3d0a55  movq xmm1, r12
0000740abd3d0a5a  lea r12, [r14+0x40]
0000740abd3d0a5e  mov r11, [r13+r12*1]
0000740abd3d0a63  movq xmm15, r11
0000740abd3d0a68  lea r12, [r14+0x80]
0000740abd3d0a6f  mov r11, [r13+r12*1]
0000740abd3d0a74  movq xmm14, r11
0000740abd3d0a79  movaps xmm13, [r15+0x120]
0000740abd3d0a81  movq r12, xmm13
0000740abd3d0a86  movq r11, xmm1
0000740abd3d0a8b  vmovq xmm1, r12
0000740abd3d0a90  vmovq xmm13, r11
0000740abd3d0a95  movaps xmm12, xmm1
0000740abd3d0a99  mulsd xmm12, xmm13
0000740abd3d0a9e  ucomisd xmm12, xmm12
0000740abd3d0aa3  jp 0x0000740ABD3D0F06
0000740abd3d0aa9  movq xmm12, xmm12
0000740abd3d0aae  movaps xmm1, [r15+0x130]
0000740abd3d0ab6  movq r12, xmm1
0000740abd3d0abb  movq r11, xmm15
0000740abd3d0ac0  vmovq xmm1, r12
0000740abd3d0ac5  vmovq xmm15, r11
0000740abd3d0aca  movaps xmm13, xmm1
0000740abd3d0ace  mulsd xmm13, xmm15
0000740abd3d0ad3  ucomisd xmm13, xmm13
0000740abd3d0ad8  jp 0x0000740ABD3D0F52
0000740abd3d0ade  movq xmm13, xmm13
0000740abd3d0ae3  movq r12, xmm12
0000740abd3d0ae8  movaps xmm1, [r15+0x110]
0000740abd3d0af0  movq r11, xmm1
0000740abd3d0af5  vmovq xmm1, r12
0000740abd3d0afa  vmovq xmm15, r11
0000740abd3d0aff  movaps xmm12, xmm1
0000740abd3d0b03  addsd xmm12, xmm15
0000740abd3d0b08  ucomisd xmm12, xmm12
0000740abd3d0b0d  jp 0x0000740ABD3D0F9E
0000740abd3d0b13  movq xmm12, xmm12
0000740abd3d0b18  movq r12, xmm12
0000740abd3d0b1d  movq r11, xmm13
0000740abd3d0b22  vmovq xmm1, r12
0000740abd3d0b27  vmovq xmm15, r11
0000740abd3d0b2c  movaps xmm13, xmm1
0000740abd3d0b30  addsd xmm13, xmm15
0000740abd3d0b35  ucomisd xmm13, xmm13
0000740abd3d0b3a  jp 0x0000740ABD3D0FEA
0000740abd3d0b40  movq xmm13, xmm13
0000740abd3d0b45  movaps xmm1, [r15+0x140]
0000740abd3d0b4d  movq r12, xmm1
0000740abd3d0b52  movq r11, xmm14
0000740abd3d0b57  vmovq xmm1, r12
0000740abd3d0b5c  vmovq xmm15, r11
0000740abd3d0b61  movaps xmm14, xmm1
0000740abd3d0b65  mulsd xmm14, xmm15
0000740abd3d0b6a  ucomisd xmm14, xmm14
0000740abd3d0b6f  jp 0x0000740ABD3D1036
0000740abd3d0b75  movq xmm14, xmm14
0000740abd3d0b7a  lea r12, [r14+0xC0]
0000740abd3d0b81  mov r11, [r13+r12*1]
0000740abd3d0b86  movq xmm1, r11
0000740abd3d0b8b  movq r12, xmm13
0000740abd3d0b90  movq r11, xmm14
0000740abd3d0b95  vmovq xmm15, r12
0000740abd3d0b9a  vmovq xmm14, r11
0000740abd3d0b9f  movaps xmm13, xmm15
0000740abd3d0ba3  addsd xmm13, xmm14
0000740abd3d0ba8  ucomisd xmm13, xmm13
0000740abd3d0bad  jp 0x0000740ABD3D108C
0000740abd3d0bb3  movq xmm13, xmm13
0000740abd3d0bb8  movaps xmm15, [r15+0x150]
0000740abd3d0bc0  movq r12, xmm15
0000740abd3d0bc5  movq r11, xmm1
0000740abd3d0bca  vmovq xmm1, r12
0000740abd3d0bcf  vmovq xmm15, r11
0000740abd3d0bd4  movaps xmm14, xmm1
0000740abd3d0bd8  mulsd xmm14, xmm15
0000740abd3d0bdd  ucomisd xmm14, xmm14
0000740abd3d0be2  jp 0x0000740ABD3D10D8
0000740abd3d0be8  movq xmm14, xmm14
0000740abd3d0bed  lea r12, [r14+0x100]
0000740abd3d0bf4  mov r11, [r13+r12*1]
0000740abd3d0bf9  movq xmm1, r11
0000740abd3d0bfe  movq r12, xmm13
0000740abd3d0c03  movq r11, xmm14
0000740abd3d0c08  vmovq xmm15, r12
0000740abd3d0c0d  vmovq xmm14, r11
0000740abd3d0c12  movaps xmm13, xmm15
0000740abd3d0c16  addsd xmm13, xmm14
0000740abd3d0c1b  ucomisd xmm13, xmm13
0000740abd3d0c20  jp 0x0000740ABD3D112E
0000740abd3d0c26  movq xmm13, xmm13
0000740abd3d0c2b  movaps xmm15, [r15+0x160]
0000740abd3d0c33  movq r12, xmm15
0000740abd3d0c38  movq r11, xmm1
0000740abd3d0c3d  vmovq xmm1, r12
0000740abd3d0c42  vmovq xmm15, r11
0000740abd3d0c47  movaps xmm14, xmm1
0000740abd3d0c4b  mulsd xmm14, xmm15
0000740abd3d0c50  ucomisd xmm14, xmm14
0000740abd3d0c55  jp 0x0000740ABD3D117A
0000740abd3d0c5b  movq xmm14, xmm14
0000740abd3d0c60  lea r12, [r14+0x140]
0000740abd3d0c67  mov r11, [r13+r12*1]
0000740abd3d0c6c  movq xmm1, r11
0000740abd3d0c71  movq r12, xmm13
0000740abd3d0c76  movq r11, xmm14
0000740abd3d0c7b  vmovq xmm15, r12
0000740abd3d0c80  vmovq xmm14, r11
0000740abd3d0c85  movaps xmm13, xmm15
0000740abd3d0c89  addsd xmm13, xmm14
0000740abd3d0c8e  ucomisd xmm13, xmm13
0000740abd3d0c93  jp 0x0000740ABD3D11D0
0000740abd3d0c99  movq xmm13, xmm13
0000740abd3d0c9e  movaps xmm15, [r15+0x170]
0000740abd3d0ca6  movq r12, xmm15
0000740abd3d0cab  movq r11, xmm1
0000740abd3d0cb0  vmovq xmm1, r12
0000740abd3d0cb5  vmovq xmm15, r11
0000740abd3d0cba  movaps xmm14, xmm1
0000740abd3d0cbe  mulsd xmm14, xmm15
0000740abd3d0cc3  ucomisd xmm14, xmm14
0000740abd3d0cc8  jp 0x0000740ABD3D121C
0000740abd3d0cce  movq xmm14, xmm14
0000740abd3d0cd3  lea r12, [r14+0x180]
0000740abd3d0cda  mov r11, [r13+r12*1]
0000740abd3d0cdf  movq xmm1, r11
0000740abd3d0ce4  movq r12, xmm13
0000740abd3d0ce9  movq r11, xmm14
0000740abd3d0cee  vmovq xmm15, r12
0000740abd3d0cf3  vmovq xmm14, r11
0000740abd3d0cf8  movaps xmm13, xmm15
0000740abd3d0cfc  addsd xmm13, xmm14
0000740abd3d0d01  ucomisd xmm13, xmm13
0000740abd3d0d06  jp 0x0000740ABD3D1272
0000740abd3d0d0c  movq xmm13, xmm13
0000740abd3d0d11  movaps xmm15, [r15+0x180]
0000740abd3d0d19  movq r12, xmm15
0000740abd3d0d1e  movq r11, xmm1
0000740abd3d0d23  vmovq xmm1, r12
0000740abd3d0d28  vmovq xmm15, r11
0000740abd3d0d2d  movaps xmm14, xmm1
0000740abd3d0d31  mulsd xmm14, xmm15
0000740abd3d0d36  ucomisd xmm14, xmm14
0000740abd3d0d3b  jp 0x0000740ABD3D12BE
0000740abd3d0d41  movq xmm14, xmm14
0000740abd3d0d46  lea r12, [r14+0x1C0]
0000740abd3d0d4d  mov r14, [r13+r12*1]
0000740abd3d0d52  movq xmm1, r14
0000740abd3d0d57  movaps [r15+0x240], xmm1
0000740abd3d0d5f  movq r14, xmm13
0000740abd3d0d64  movq r12, xmm14
0000740abd3d0d69  vmovq xmm15, r14
0000740abd3d0d6e  vmovq xmm14, r12
0000740abd3d0d73  movaps xmm13, xmm15
0000740abd3d0d77  addsd xmm13, xmm14
0000740abd3d0d7c  ucomisd xmm13, xmm13
0000740abd3d0d81  jp 0x0000740ABD3D1314
0000740abd3d0d87  movq xmm13, xmm13
0000740abd3d0d8c  movaps xmm15, [r15+0x210]
0000740abd3d0d94  movq r14, xmm15
0000740abd3d0d99  movq r12, xmm1
0000740abd3d0d9e  vmovq xmm1, r14
0000740abd3d0da3  vmovq xmm15, r12
0000740abd3d0da8  movaps xmm14, xmm1
0000740abd3d0dac  mulsd xmm14, xmm15
0000740abd3d0db1  ucomisd xmm14, xmm14
0000740abd3d0db6  jp 0x0000740ABD3D1360
0000740abd3d0dbc  movq xmm14, xmm14
0000740abd3d0dc1  movaps [r15+0x230], xmm14
0000740abd3d0dc9  movq r14, xmm13
0000740abd3d0dce  movq r12, xmm14
0000740abd3d0dd3  vmovq xmm1, r14
0000740abd3d0dd8  vmovq xmm15, r12
0000740abd3d0ddd  movaps xmm14, xmm1
0000740abd3d0de1  addsd xmm14, xmm15
0000740abd3d0de6  ucomisd xmm14, xmm14
0000740abd3d0deb  jp 0x0000740ABD3D13AC
0000740abd3d0df1  movq xmm14, xmm14
0000740abd3d0df6  movaps [r15+0x220], xmm14
0000740abd3d0dfe  movq r14, xmm14
0000740abd3d0e03  mov [r13+rax*1], r14
0000740abd3d0e08  mov qword ptr [r15+0x70], 0x08
0000740abd3d0e10  xor eax, eax
0000740abd3d0e12  mov r14d, 0x08
0000740abd3d0e18  mov r12d, 0x40
0000740abd3d0e1e  cmp r14, r12
0000740abd3d0e21  cmc
0000740abd3d0e22  lahf
0000740abd3d0e23  seto al
0000740abd3d0e26  mov [r15+0x108], eax
0000740abd3d0e2d  mov eax, [r15+0x108]
0000740abd3d0e34  sahf
0000740abd3d0e35  jnz 0x0000740ABD3D0E67
0000740abd3d0e37  cmp dword ptr [r15+0x318], 0x00
0000740abd3d0e3f  jz 0x0000740ABD3CFD40
0000740abd3d0e45  nop [rax+rax*1], ax
0000740abd3d0e4e  nop [rax+rax*1], eax
0000740abd3d0e56  mov eax, 0x410118
0000740abd3d0e5b  mov [r15+0x100], rax
0000740abd3d0e62  jmp 0x0000740ABD1FE110
0000740abd3d0e67  cmp dword ptr [r15+0x318], 0x00
0000740abd3d0e6f  jz 0x0000740ABD3CF3F0
0000740abd3d0e75  nop [rax+rax*1], ax
0000740abd3d0e7e  nop [rax+rax*1], eax
0000740abd3d0e86  mov eax, 0x4100A4
0000740abd3d0e8b  mov [r15+0x100], rax
0000740abd3d0e92  jmp 0x0000740ABD1FE110
0000740abd3d0e97  int3
0000740abd3d0e98  call 0x0000740ABD2E27E0
0000740abd3d0e9d  jmp 0x0000740ABD3D0959
0000740abd3d0ea2  call 0x0000740ABD2AE800
0000740abd3d0ea7  jmp 0x0000740ABD3D0962
0000740abd3d0eac  call 0x0000740ABD2C0370
0000740abd3d0eb1  jmp 0x0000740ABD3D0997
0000740abd3d0eb6  call 0x0000740ABD2BF100
0000740abd3d0ebb  jmp 0x0000740ABD3D09A0
0000740abd3d0ec0  call 0x0000740ABD2C0370
0000740abd3d0ec5  jmp 0x0000740ABD3D09D5
0000740abd3d0eca  call 0x0000740ABD2BF100
0000740abd3d0ecf  jmp 0x0000740ABD3D09DE
0000740abd3d0ed4  call 0x0000740ABD2C0370
0000740abd3d0ed9  jmp 0x0000740ABD3D0A13
0000740abd3d0ede  call 0x0000740ABD2C3AE0
0000740abd3d0ee3  jmp 0x0000740ABD3D0A1C
0000740abd3d0ee8  call 0x0000740ABD2E27E0
0000740abd3d0eed  jmp 0x0000740ABD3D0A55
0000740abd3d0ef2  call 0x0000740ABD2C0370
0000740abd3d0ef7  jmp 0x0000740ABD3D0A63
0000740abd3d0efc  call 0x0000740ABD2C0370
0000740abd3d0f01  jmp 0x0000740ABD3D0A74
0000740abd3d0f06  ucomisd xmm1, xmm13
0000740abd3d0f0b  jp 0x0000740ABD3D0F1A
0000740abd3d0f0d  movaps xmm12, [0x0000740ABCFFE030]
0000740abd3d0f15  jmp 0x0000740ABD3D0AA9
0000740abd3d0f1a  vxorps xmm0, xmm1, xmm13
0000740abd3d0f1f  pextrw r12d, xmm0, 0x03
0000740abd3d0f25  and r12d, 0x7FF8
0000740abd3d0f2c  cmp r12d, 0x08
0000740abd3d0f30  jnz 0x0000740ABD3D0AA9
0000740abd3d0f36  movq r12, xmm13
0000740abd3d0f3b  shl r12, 0x0D
0000740abd3d0f3f  jbe 0x0000740ABD3D0AA9
0000740abd3d0f45  vorps xmm12, xmm13, [0x0000740ABCFFE040]
0000740abd3d0f4d  jmp 0x0000740ABD3D0AA9
0000740abd3d0f52  ucomisd xmm1, xmm15
0000740abd3d0f57  jp 0x0000740ABD3D0F66
0000740abd3d0f59  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d0f61  jmp 0x0000740ABD3D0ADE
0000740abd3d0f66  vxorps xmm0, xmm1, xmm15
0000740abd3d0f6b  pextrw r12d, xmm0, 0x03
0000740abd3d0f71  and r12d, 0x7FF8
0000740abd3d0f78  cmp r12d, 0x08
0000740abd3d0f7c  jnz 0x0000740ABD3D0ADE
0000740abd3d0f82  movq r12, xmm15
0000740abd3d0f87  shl r12, 0x0D
0000740abd3d0f8b  jbe 0x0000740ABD3D0ADE
0000740abd3d0f91  vorps xmm13, xmm15, [0x0000740ABCFFE040]
0000740abd3d0f99  jmp 0x0000740ABD3D0ADE
0000740abd3d0f9e  ucomisd xmm1, xmm15
0000740abd3d0fa3  jp 0x0000740ABD3D0FB2
0000740abd3d0fa5  movaps xmm12, [0x0000740ABCFFE030]
0000740abd3d0fad  jmp 0x0000740ABD3D0B13
0000740abd3d0fb2  vxorps xmm0, xmm1, xmm15
0000740abd3d0fb7  pextrw r12d, xmm0, 0x03
0000740abd3d0fbd  and r12d, 0x7FF8
0000740abd3d0fc4  cmp r12d, 0x08
0000740abd3d0fc8  jnz 0x0000740ABD3D0B13
0000740abd3d0fce  movq r12, xmm15
0000740abd3d0fd3  shl r12, 0x0D
0000740abd3d0fd7  jbe 0x0000740ABD3D0B13
0000740abd3d0fdd  vorps xmm12, xmm15, [0x0000740ABCFFE040]
0000740abd3d0fe5  jmp 0x0000740ABD3D0B13
0000740abd3d0fea  ucomisd xmm1, xmm15
0000740abd3d0fef  jp 0x0000740ABD3D0FFE
0000740abd3d0ff1  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d0ff9  jmp 0x0000740ABD3D0B40
0000740abd3d0ffe  vxorps xmm0, xmm1, xmm15
0000740abd3d1003  pextrw r12d, xmm0, 0x03
0000740abd3d1009  and r12d, 0x7FF8
0000740abd3d1010  cmp r12d, 0x08
0000740abd3d1014  jnz 0x0000740ABD3D0B40
0000740abd3d101a  movq r12, xmm15
0000740abd3d101f  shl r12, 0x0D
0000740abd3d1023  jbe 0x0000740ABD3D0B40
0000740abd3d1029  vorps xmm13, xmm15, [0x0000740ABCFFE040]
0000740abd3d1031  jmp 0x0000740ABD3D0B40
0000740abd3d1036  ucomisd xmm1, xmm15
0000740abd3d103b  jp 0x0000740ABD3D104A
0000740abd3d103d  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d1045  jmp 0x0000740ABD3D0B75
0000740abd3d104a  vxorps xmm0, xmm1, xmm15
0000740abd3d104f  pextrw r12d, xmm0, 0x03
0000740abd3d1055  and r12d, 0x7FF8
0000740abd3d105c  cmp r12d, 0x08
0000740abd3d1060  jnz 0x0000740ABD3D0B75
0000740abd3d1066  movq r12, xmm15
0000740abd3d106b  shl r12, 0x0D
0000740abd3d106f  jbe 0x0000740ABD3D0B75
0000740abd3d1075  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d107d  jmp 0x0000740ABD3D0B75
0000740abd3d1082  call 0x0000740ABD2C0370
0000740abd3d1087  jmp 0x0000740ABD3D0B86
0000740abd3d108c  ucomisd xmm15, xmm14
0000740abd3d1091  jp 0x0000740ABD3D10A0
0000740abd3d1093  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d109b  jmp 0x0000740ABD3D0BB3
0000740abd3d10a0  vxorps xmm0, xmm15, xmm14
0000740abd3d10a5  pextrw r12d, xmm0, 0x03
0000740abd3d10ab  and r12d, 0x7FF8
0000740abd3d10b2  cmp r12d, 0x08
0000740abd3d10b6  jnz 0x0000740ABD3D0BB3
0000740abd3d10bc  movq r12, xmm14
0000740abd3d10c1  shl r12, 0x0D
0000740abd3d10c5  jbe 0x0000740ABD3D0BB3
0000740abd3d10cb  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d10d3  jmp 0x0000740ABD3D0BB3
0000740abd3d10d8  ucomisd xmm1, xmm15
0000740abd3d10dd  jp 0x0000740ABD3D10EC
0000740abd3d10df  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d10e7  jmp 0x0000740ABD3D0BE8
0000740abd3d10ec  vxorps xmm0, xmm1, xmm15
0000740abd3d10f1  pextrw r12d, xmm0, 0x03
0000740abd3d10f7  and r12d, 0x7FF8
0000740abd3d10fe  cmp r12d, 0x08
0000740abd3d1102  jnz 0x0000740ABD3D0BE8
0000740abd3d1108  movq r12, xmm15
0000740abd3d110d  shl r12, 0x0D
0000740abd3d1111  jbe 0x0000740ABD3D0BE8
0000740abd3d1117  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d111f  jmp 0x0000740ABD3D0BE8
0000740abd3d1124  call 0x0000740ABD2C0370
0000740abd3d1129  jmp 0x0000740ABD3D0BF9
0000740abd3d112e  ucomisd xmm15, xmm14
0000740abd3d1133  jp 0x0000740ABD3D1142
0000740abd3d1135  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d113d  jmp 0x0000740ABD3D0C26
0000740abd3d1142  vxorps xmm0, xmm15, xmm14
0000740abd3d1147  pextrw r12d, xmm0, 0x03
0000740abd3d114d  and r12d, 0x7FF8
0000740abd3d1154  cmp r12d, 0x08
0000740abd3d1158  jnz 0x0000740ABD3D0C26
0000740abd3d115e  movq r12, xmm14
0000740abd3d1163  shl r12, 0x0D
0000740abd3d1167  jbe 0x0000740ABD3D0C26
0000740abd3d116d  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d1175  jmp 0x0000740ABD3D0C26
0000740abd3d117a  ucomisd xmm1, xmm15
0000740abd3d117f  jp 0x0000740ABD3D118E
0000740abd3d1181  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d1189  jmp 0x0000740ABD3D0C5B
0000740abd3d118e  vxorps xmm0, xmm1, xmm15
0000740abd3d1193  pextrw r12d, xmm0, 0x03
0000740abd3d1199  and r12d, 0x7FF8
0000740abd3d11a0  cmp r12d, 0x08
0000740abd3d11a4  jnz 0x0000740ABD3D0C5B
0000740abd3d11aa  movq r12, xmm15
0000740abd3d11af  shl r12, 0x0D
0000740abd3d11b3  jbe 0x0000740ABD3D0C5B
0000740abd3d11b9  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d11c1  jmp 0x0000740ABD3D0C5B
0000740abd3d11c6  call 0x0000740ABD2C0370
0000740abd3d11cb  jmp 0x0000740ABD3D0C6C
0000740abd3d11d0  ucomisd xmm15, xmm14
0000740abd3d11d5  jp 0x0000740ABD3D11E4
0000740abd3d11d7  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d11df  jmp 0x0000740ABD3D0C99
0000740abd3d11e4  vxorps xmm0, xmm15, xmm14
0000740abd3d11e9  pextrw r12d, xmm0, 0x03
0000740abd3d11ef  and r12d, 0x7FF8
0000740abd3d11f6  cmp r12d, 0x08
0000740abd3d11fa  jnz 0x0000740ABD3D0C99
0000740abd3d1200  movq r12, xmm14
0000740abd3d1205  shl r12, 0x0D
0000740abd3d1209  jbe 0x0000740ABD3D0C99
0000740abd3d120f  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d1217  jmp 0x0000740ABD3D0C99
0000740abd3d121c  ucomisd xmm1, xmm15
0000740abd3d1221  jp 0x0000740ABD3D1230
0000740abd3d1223  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d122b  jmp 0x0000740ABD3D0CCE
0000740abd3d1230  vxorps xmm0, xmm1, xmm15
0000740abd3d1235  pextrw r12d, xmm0, 0x03
0000740abd3d123b  and r12d, 0x7FF8
0000740abd3d1242  cmp r12d, 0x08
0000740abd3d1246  jnz 0x0000740ABD3D0CCE
0000740abd3d124c  movq r12, xmm15
0000740abd3d1251  shl r12, 0x0D
0000740abd3d1255  jbe 0x0000740ABD3D0CCE
0000740abd3d125b  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d1263  jmp 0x0000740ABD3D0CCE
0000740abd3d1268  call 0x0000740ABD2C0370
0000740abd3d126d  jmp 0x0000740ABD3D0CDF
0000740abd3d1272  ucomisd xmm15, xmm14
0000740abd3d1277  jp 0x0000740ABD3D1286
0000740abd3d1279  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d1281  jmp 0x0000740ABD3D0D0C
0000740abd3d1286  vxorps xmm0, xmm15, xmm14
0000740abd3d128b  pextrw r12d, xmm0, 0x03
0000740abd3d1291  and r12d, 0x7FF8
0000740abd3d1298  cmp r12d, 0x08
0000740abd3d129c  jnz 0x0000740ABD3D0D0C
0000740abd3d12a2  movq r12, xmm14
0000740abd3d12a7  shl r12, 0x0D
0000740abd3d12ab  jbe 0x0000740ABD3D0D0C
0000740abd3d12b1  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d12b9  jmp 0x0000740ABD3D0D0C
0000740abd3d12be  ucomisd xmm1, xmm15
0000740abd3d12c3  jp 0x0000740ABD3D12D2
0000740abd3d12c5  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d12cd  jmp 0x0000740ABD3D0D41
0000740abd3d12d2  vxorps xmm0, xmm1, xmm15
0000740abd3d12d7  pextrw r12d, xmm0, 0x03
0000740abd3d12dd  and r12d, 0x7FF8
0000740abd3d12e4  cmp r12d, 0x08
0000740abd3d12e8  jnz 0x0000740ABD3D0D41
0000740abd3d12ee  movq r12, xmm15
0000740abd3d12f3  shl r12, 0x0D
0000740abd3d12f7  jbe 0x0000740ABD3D0D41
0000740abd3d12fd  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d1305  jmp 0x0000740ABD3D0D41
0000740abd3d130a  call 0x0000740ABD2C3AE0
0000740abd3d130f  jmp 0x0000740ABD3D0D52
0000740abd3d1314  ucomisd xmm15, xmm14
0000740abd3d1319  jp 0x0000740ABD3D1328
0000740abd3d131b  movaps xmm13, [0x0000740ABCFFE030]
0000740abd3d1323  jmp 0x0000740ABD3D0D87
0000740abd3d1328  vxorps xmm0, xmm15, xmm14
0000740abd3d132d  pextrw r14d, xmm0, 0x03
0000740abd3d1333  and r14d, 0x7FF8
0000740abd3d133a  cmp r14d, 0x08
0000740abd3d133e  jnz 0x0000740ABD3D0D87
0000740abd3d1344  movq r14, xmm14
0000740abd3d1349  shl r14, 0x0D
0000740abd3d134d  jbe 0x0000740ABD3D0D87
0000740abd3d1353  vorps xmm13, xmm14, [0x0000740ABCFFE040]
0000740abd3d135b  jmp 0x0000740ABD3D0D87
0000740abd3d1360  ucomisd xmm1, xmm15
0000740abd3d1365  jp 0x0000740ABD3D1374
0000740abd3d1367  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d136f  jmp 0x0000740ABD3D0DBC
0000740abd3d1374  vxorps xmm0, xmm1, xmm15
0000740abd3d1379  pextrw r14d, xmm0, 0x03
0000740abd3d137f  and r14d, 0x7FF8
0000740abd3d1386  cmp r14d, 0x08
0000740abd3d138a  jnz 0x0000740ABD3D0DBC
0000740abd3d1390  movq r14, xmm15
0000740abd3d1395  shl r14, 0x0D
0000740abd3d1399  jbe 0x0000740ABD3D0DBC
0000740abd3d139f  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d13a7  jmp 0x0000740ABD3D0DBC
0000740abd3d13ac  ucomisd xmm1, xmm15
0000740abd3d13b1  jp 0x0000740ABD3D13C0
0000740abd3d13b3  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d13bb  jmp 0x0000740ABD3D0DF1
0000740abd3d13c0  vxorps xmm0, xmm1, xmm15
0000740abd3d13c5  pextrw r14d, xmm0, 0x03
0000740abd3d13cb  and r14d, 0x7FF8
0000740abd3d13d2  cmp r14d, 0x08
0000740abd3d13d6  jnz 0x0000740ABD3D0DF1
0000740abd3d13dc  movq r14, xmm15
0000740abd3d13e1  shl r14, 0x0D
0000740abd3d13e5  jbe 0x0000740ABD3D0DF1
0000740abd3d13eb  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d13f3  jmp 0x0000740ABD3D0DF1
0000740abd3d13f8  call 0x0000740ABD20E120
0000740abd3d13fd  jmp 0x0000740ABD3D0E08
0000740abd3d1402  int3
0000740abd3d1403  nop [rax+rax*1], ax
0000740abd3d140c  nop [rax], eax
0000740abd3d1410  mov qword ptr [r15+0x40], 0x420000
0000740abd3d1418  mov eax, 0x4201B8
0000740abd3d141d  mov r14, [r13+rax*1]
0000740abd3d1422  movq xmm1, r14
0000740abd3d1427  mov rax, [r15+0x50]
0000740abd3d142b  mov r14, [r13+rax*1]
0000740abd3d1430  movq xmm15, r14
0000740abd3d1435  movaps [r15+0x120], xmm15
0000740abd3d143d  mov qword ptr [r15+0x48], 0x08
0000740abd3d1445  xor eax, eax
0000740abd3d1447  mov r14d, 0x08
0000740abd3d144d  mov r12d, 0x200
0000740abd3d1453  cmp r14, r12
0000740abd3d1456  cmc
0000740abd3d1457  lahf
0000740abd3d1458  seto al
0000740abd3d145b  mov [r15+0x108], eax
0000740abd3d1462  movq rax, xmm1
0000740abd3d1467  movq r14, xmm15
0000740abd3d146c  vmovq xmm1, rax
0000740abd3d1471  vmovq xmm15, r14
0000740abd3d1476  movaps xmm14, xmm1
0000740abd3d147a  addsd xmm14, xmm15
0000740abd3d147f  ucomisd xmm14, xmm14
0000740abd3d1484  jp 0x0000740ABD3D1516
0000740abd3d148a  movq xmm14, xmm14
0000740abd3d148f  movaps [r15+0x110], xmm14
0000740abd3d1497  mov eax, [r15+0x108]
0000740abd3d149e  sahf
0000740abd3d149f  jnz 0x0000740ABD3D14D1
0000740abd3d14a1  cmp dword ptr [r15+0x318], 0x00
0000740abd3d14a9  jz 0x0000740ABD3D16A0
0000740abd3d14af  nop [rax+rax*1], ax
0000740abd3d14b8  nop [rax+rax*1], eax
0000740abd3d14c0  mov eax, 0x410154
0000740abd3d14c5  mov [r15+0x100], rax
0000740abd3d14cc  jmp 0x0000740ABD1FE110
0000740abd3d14d1  cmp dword ptr [r15+0x318], 0x00
0000740abd3d14d9  jz 0x0000740ABD3D1560
0000740abd3d14df  nop [rax+rax*1], ax
0000740abd3d14e8  nop [rax+rax*1], eax
0000740abd3d14f0  mov eax, 0x410140
0000740abd3d14f5  mov [r15+0x100], rax
0000740abd3d14fc  jmp 0x0000740ABD1FE110
0000740abd3d1501  int3
0000740abd3d1502  call 0x0000740ABD20DC20
0000740abd3d1507  jmp 0x0000740ABD3D1422
0000740abd3d150c  call 0x0000740ABD20DC20
0000740abd3d1511  jmp 0x0000740ABD3D1430
0000740abd3d1516  ucomisd xmm1, xmm15
0000740abd3d151b  jp 0x0000740ABD3D152A
0000740abd3d151d  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d1525  jmp 0x0000740ABD3D148A
0000740abd3d152a  vxorps xmm0, xmm1, xmm15
0000740abd3d152f  pextrw eax, xmm0, 0x03
0000740abd3d1534  and eax, 0x7FF8
0000740abd3d1539  cmp eax, 0x08
0000740abd3d153c  jnz 0x0000740ABD3D148A
0000740abd3d1542  movq rax, xmm15
0000740abd3d1547  shl rax, 0x0D
0000740abd3d154b  jbe 0x0000740ABD3D148A
0000740abd3d1551  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d1559  jmp 0x0000740ABD3D148A
0000740abd3d155e  int3
0000740abd3d155f  nop
0000740abd3d1560  mov rax, [r15+0x48]
0000740abd3d1564  mov r14, [r15+0x50]
0000740abd3d1568  lea r12, [r14+rax*1]
0000740abd3d156c  mov r14, [r13+r12*1]
0000740abd3d1571  movq xmm1, r14
0000740abd3d1576  movaps [r15+0x120], xmm1
0000740abd3d157e  lea r14, [rax+0x08]
0000740abd3d1582  mov [r15+0x48], r14
0000740abd3d1586  xor eax, eax
0000740abd3d1588  mov r12d, 0x200
0000740abd3d158e  cmp r14, r12
0000740abd3d1591  cmc
0000740abd3d1592  lahf
0000740abd3d1593  seto al
0000740abd3d1596  mov [r15+0x108], eax
0000740abd3d159d  movaps xmm15, [r15+0x110]
0000740abd3d15a5  movq rax, xmm15
0000740abd3d15aa  movq r14, xmm1
0000740abd3d15af  vmovq xmm1, rax
0000740abd3d15b4  vmovq xmm15, r14
0000740abd3d15b9  movaps xmm14, xmm1
0000740abd3d15bd  addsd xmm14, xmm15
0000740abd3d15c2  ucomisd xmm14, xmm14
0000740abd3d15c7  jp 0x0000740ABD3D164F
0000740abd3d15cd  movq xmm14, xmm14
0000740abd3d15d2  movaps [r15+0x110], xmm14
0000740abd3d15da  mov eax, [r15+0x108]
0000740abd3d15e1  sahf
0000740abd3d15e2  jnz 0x0000740ABD3D1614
0000740abd3d15e4  cmp dword ptr [r15+0x318], 0x00
0000740abd3d15ec  jz 0x0000740ABD3D16A0
0000740abd3d15f2  nop [rax+rax*1], ax
0000740abd3d15fb  nop [rax+rax*1], eax
0000740abd3d1603  mov eax, 0x410154
0000740abd3d1608  mov [r15+0x100], rax
0000740abd3d160f  jmp 0x0000740ABD1FE110
0000740abd3d1614  cmp dword ptr [r15+0x318], 0x00
0000740abd3d161c  jz 0x0000740ABD3D1560
0000740abd3d1622  nop [rax+rax*1], ax
0000740abd3d162b  nop [rax+rax*1], eax
0000740abd3d1633  mov eax, 0x410140
0000740abd3d1638  mov [r15+0x100], rax
0000740abd3d163f  jmp 0x0000740ABD1FE110
0000740abd3d1644  int3
0000740abd3d1645  call 0x0000740ABD2C3AE0
0000740abd3d164a  jmp 0x0000740ABD3D1571
0000740abd3d164f  ucomisd xmm1, xmm15
0000740abd3d1654  jp 0x0000740ABD3D1663
0000740abd3d1656  movaps xmm14, [0x0000740ABCFFE030]
0000740abd3d165e  jmp 0x0000740ABD3D15CD
0000740abd3d1663  vxorps xmm0, xmm1, xmm15
0000740abd3d1668  pextrw eax, xmm0, 0x03
0000740abd3d166d  and eax, 0x7FF8
0000740abd3d1672  cmp eax, 0x08
0000740abd3d1675  jnz 0x0000740ABD3D15CD
0000740abd3d167b  movq rax, xmm15
0000740abd3d1680  shl rax, 0x0D
0000740abd3d1684  jbe 0x0000740ABD3D15CD
0000740abd3d168a  vorps xmm14, xmm15, [0x0000740ABCFFE040]
0000740abd3d1692  jmp 0x0000740ABD3D15CD
0000740abd3d1697  int3
0000740abd3d1698  nop [rax+rax*1], eax
0000740abd3d16a0  mov rax, [r15+0x40]
0000740abd3d16a4  lea r14, [rax+0x1B8]
0000740abd3d16ab  movaps xmm1, [r15+0x110]
0000740abd3d16b3  movq rax, xmm1
0000740abd3d16b8  mov [r13+r14*1], rax
0000740abd3d16bd  mov rax, [r15+0xF0]
0000740abd3d16c4  mov [r15+0x100], rax
0000740abd3d16cb  jmp 0x0000740ABD3CE5C0
0000740abd3d16d0  int3
0000740abd3d16d1  call 0x0000740ABD2D5EB0
0000740abd3d16d6  jmp 0x0000740ABD3D16BD
0000740abd3d16db  int3
0000740abd3d16dc  nop [rax], eax
0000740abd3d16e0  mov qword ptr [r15+0x100], 0x04
0000740abd3d16eb  mov esi, 0x00
0000740abd3d16f0  mov edx, 0x09
0000740abd3d16f5  mov rdi, 0x7FFEAD8BD420
0000740abd3d16ff  mov rax, 0x5E9B0A008970
0000740abd3d1709  call rax
0000740abd3d170b  cmp dword ptr [r15+0x318], 0x00
0000740abd3d1713  jnz 0x0000740ABD1FE110
0000740abd3d1719  jmp 0x0000740ABD1FE0A0
0000740abd3d171e  int3
0000740abd3d171f  int3
