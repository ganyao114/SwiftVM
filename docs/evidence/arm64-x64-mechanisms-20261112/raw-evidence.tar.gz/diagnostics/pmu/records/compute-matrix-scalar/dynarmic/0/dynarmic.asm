000079fe5f5ce69b  nop [rax+rax*1], eax
000079fe5f5ce6a0  mov qword ptr [r15+0x40], 0x4201C0
000079fe5f5ce6a8  mov qword ptr [r15+0x48], 0x4203C0
000079fe5f5ce6b0  mov qword ptr [r15+0x60], 0x01
000079fe5f5ce6b8  xorps xmm1, xmm1
000079fe5f5ce6bb  mov eax, 0x41
000079fe5f5ce6c0  vcvtusi2sd xmm1, xmm1, eax
000079fe5f5ce6c6  mulsd xmm1, [0x000079FE5F1FE010]
000079fe5f5ce6ce  movq xmm1, xmm1
000079fe5f5ce6d2  movaps [r15+0x120], xmm1
000079fe5f5ce6da  mov eax, [r15+0x60]
000079fe5f5ce6de  xorps xmm15, xmm15
000079fe5f5ce6e2  vcvtusi2sd xmm15, xmm15, eax
000079fe5f5ce6e8  mulsd xmm15, [0x000079FE5F1FE020]
000079fe5f5ce6f1  movq xmm15, xmm15
000079fe5f5ce6f6  movaps [r15+0x110], xmm15
000079fe5f5ce6fe  mov rax, [r15+0x60]
000079fe5f5ce702  mov [rsp+0x10], rax
000079fe5f5ce707  xor eax, eax
000079fe5f5ce709  mov r14, [rsp+0x10]
000079fe5f5ce70e  mov r12d, 0x40
000079fe5f5ce714  cmp r14, r12
000079fe5f5ce717  cmc
000079fe5f5ce718  lahf
000079fe5f5ce719  seto al
000079fe5f5ce71c  mov [r15+0x108], eax
000079fe5f5ce723  mov qword ptr [r15+0x50], 0x40
000079fe5f5ce72b  movq rax, xmm1
000079fe5f5ce730  mov r12d, 0x4203C0
000079fe5f5ce736  mov [r13+r12*1], rax
000079fe5f5ce73b  movq rax, xmm15
000079fe5f5ce740  mov r12d, 0x4201C0
000079fe5f5ce746  mov [r13+r12*1], rax
000079fe5f5ce74b  mov [r15+0x58], r14
000079fe5f5ce74f  mov eax, [r15+0x108]
000079fe5f5ce756  sahf
000079fe5f5ce757  jnz 0x000079FE5F5CE789
000079fe5f5ce759  cmp dword ptr [r15+0x318], 0x00
000079fe5f5ce761  jz 0x000079FE5F5CE910
000079fe5f5ce767  nop [rax+rax*1], ax
000079fe5f5ce770  nop [rax+rax*1], eax
000079fe5f5ce778  mov eax, 0x410074
000079fe5f5ce77d  mov [r15+0x100], rax
000079fe5f5ce784  jmp 0x000079FE5F3FE110
000079fe5f5ce789  cmp dword ptr [r15+0x318], 0x00
000079fe5f5ce791  jz 0x000079FE5F5CE7D0
000079fe5f5ce797  nop [rax+rax*1], ax
000079fe5f5ce7a0  nop [rax+rax*1], eax
000079fe5f5ce7a8  mov eax, 0x41004C
000079fe5f5ce7ad  mov [r15+0x100], rax
000079fe5f5ce7b4  jmp 0x000079FE5F3FE110
000079fe5f5ce7b9  int3
000079fe5f5ce7ba  call 0x000079FE5F4B4CB0
000079fe5f5ce7bf  jmp 0x000079FE5F5CE73B
000079fe5f5ce7c4  call 0x000079FE5F4B4CB0
000079fe5f5ce7c9  jmp 0x000079FE5F5CE74B
000079fe5f5ce7ce  int3
000079fe5f5ce7cf  nop
000079fe5f5ce7d0  mov rax, [r15+0x58]
000079fe5f5ce7d4  lea r14, [rax+0x01]
000079fe5f5ce7d8  mov [r15+0x60], r14
000079fe5f5ce7dc  mov r14d, [r15+0x50]
000079fe5f5ce7e0  xorps xmm1, xmm1
000079fe5f5ce7e3  vcvtusi2sd xmm1, xmm1, r14d
000079fe5f5ce7e9  mulsd xmm1, [0x000079FE5F1FE010]
000079fe5f5ce7f1  movq xmm1, xmm1
000079fe5f5ce7f5  movaps [r15+0x120], xmm1
000079fe5f5ce7fd  rorx r12, rax, 0x3D
000079fe5f5ce803  and r12, 0xFFFFFFFFFFFFFFF8
000079fe5f5ce807  mov eax, [r15+0x60]
000079fe5f5ce80b  xorps xmm15, xmm15
000079fe5f5ce80f  vcvtusi2sd xmm15, xmm15, eax
000079fe5f5ce815  mulsd xmm15, [0x000079FE5F1FE020]
000079fe5f5ce81e  movq xmm15, xmm15
000079fe5f5ce823  movaps [r15+0x110], xmm15
000079fe5f5ce82b  mov rax, [r15+0x60]
000079fe5f5ce82f  mov [rsp+0x10], rax
000079fe5f5ce834  xor eax, eax
000079fe5f5ce836  mov r11, [rsp+0x10]
000079fe5f5ce83b  mov r10d, 0x40
000079fe5f5ce841  cmp r11, r10
000079fe5f5ce844  cmc
000079fe5f5ce845  lahf
000079fe5f5ce846  seto al
000079fe5f5ce849  mov [r15+0x108], eax
000079fe5f5ce850  lea eax, [r14d-0x01]
000079fe5f5ce855  mov eax, eax
000079fe5f5ce857  mov [r15+0x50], rax
000079fe5f5ce85b  mov rax, [r15+0x48]
000079fe5f5ce85f  lea r14, [rax+r12*1]
000079fe5f5ce863  movq rax, xmm1
000079fe5f5ce868  mov [r13+r14*1], rax
000079fe5f5ce86d  mov rax, [r15+0x40]
000079fe5f5ce871  lea r14, [rax+r12*1]
000079fe5f5ce875  movq rax, xmm15
000079fe5f5ce87a  mov [r13+r14*1], rax
000079fe5f5ce87f  mov [r15+0x58], r11
000079fe5f5ce883  mov eax, [r15+0x108]
000079fe5f5ce88a  sahf
000079fe5f5ce88b  jnz 0x000079FE5F5CE8BD
000079fe5f5ce88d  cmp dword ptr [r15+0x318], 0x00
000079fe5f5ce895  jz 0x000079FE5F5CE910
000079fe5f5ce89b  nop [rax+rax*1], ax
000079fe5f5ce8a4  nop [rax+rax*1], eax
000079fe5f5ce8ac  mov eax, 0x410074
000079fe5f5ce8b1  mov [r15+0x100], rax
000079fe5f5ce8b8  jmp 0x000079FE5F3FE110
000079fe5f5ce8bd  cmp dword ptr [r15+0x318], 0x00
000079fe5f5ce8c5  jz 0x000079FE5F5CE7D0
000079fe5f5ce8cb  nop [rax+rax*1], ax
000079fe5f5ce8d4  nop [rax+rax*1], eax
000079fe5f5ce8dc  mov eax, 0x41004C
000079fe5f5ce8e1  mov [r15+0x100], rax
000079fe5f5ce8e8  jmp 0x000079FE5F3FE110
000079fe5f5ce8ed  int3
000079fe5f5ce8ee  call 0x000079FE5F4D5EB0
000079fe5f5ce8f3  jmp 0x000079FE5F5CE86D
000079fe5f5ce8f8  call 0x000079FE5F4D5EB0
000079fe5f5ce8fd  jmp 0x000079FE5F5CE87F
000079fe5f5ce902  int3
000079fe5f5ce903  nop [rax+rax*1], ax
000079fe5f5ce90c  nop [rax], eax
000079fe5f5ce910  vxorps xmm1, xmm1, xmm1
000079fe5f5ce914  movq xmm1, xmm1
000079fe5f5ce918  movaps [r15+0x110], xmm1
000079fe5f5ce920  mov qword ptr [r15+0x58], 0x00
000079fe5f5ce928  mov qword ptr [r15+0x50], 0x4205C0
000079fe5f5ce930  mov qword ptr [r15+0x60], 0x00
000079fe5f5ce938  mov qword ptr [r15+0x68], 0x4205C0
000079fe5f5ce940  mov rax, [r15+0x40]
000079fe5f5ce944  mov r14, [r13+rax*1]
000079fe5f5ce949  lea r12, [rax+0x08]
000079fe5f5ce94d  mov r11, [r13+r12*1]
000079fe5f5ce952  movq xmm15, r14
000079fe5f5ce957  movq xmm14, r11
000079fe5f5ce95c  movq xmm15, xmm15
000079fe5f5ce961  movq xmm15, xmm15
000079fe5f5ce966  movaps [r15+0x120], xmm15
000079fe5f5ce96e  movq xmm14, xmm14
000079fe5f5ce973  movq xmm14, xmm14
000079fe5f5ce978  movaps [r15+0x130], xmm14
000079fe5f5ce980  lea r14, [rax+0x10]
000079fe5f5ce984  mov r12, [r13+r14*1]
000079fe5f5ce989  lea r14, [rax+0x18]
000079fe5f5ce98d  mov r11, [r13+r14*1]
000079fe5f5ce992  movq xmm15, r12
000079fe5f5ce997  movq xmm14, r11
000079fe5f5ce99c  movq xmm15, xmm15
000079fe5f5ce9a1  movq xmm15, xmm15
000079fe5f5ce9a6  movaps [r15+0x140], xmm15
000079fe5f5ce9ae  movq xmm14, xmm14
000079fe5f5ce9b3  movq xmm14, xmm14
000079fe5f5ce9b8  movaps [r15+0x150], xmm14
000079fe5f5ce9c0  lea r14, [rax+0x20]
000079fe5f5ce9c4  mov r12, [r13+r14*1]
000079fe5f5ce9c9  lea r14, [rax+0x28]
000079fe5f5ce9cd  mov r11, [r13+r14*1]
000079fe5f5ce9d2  movq xmm15, r12
000079fe5f5ce9d7  movq xmm14, r11
000079fe5f5ce9dc  movq xmm15, xmm15
000079fe5f5ce9e1  movq xmm15, xmm15
000079fe5f5ce9e6  movaps [r15+0x160], xmm15
000079fe5f5ce9ee  movq xmm14, xmm14
000079fe5f5ce9f3  movq xmm14, xmm14
000079fe5f5ce9f8  movaps [r15+0x170], xmm14
000079fe5f5cea00  lea r14, [rax+0x30]
000079fe5f5cea04  mov r12, [r13+r14*1]
000079fe5f5cea09  lea r14, [rax+0x38]
000079fe5f5cea0d  mov rax, [r13+r14*1]
000079fe5f5cea12  movq xmm15, r12
000079fe5f5cea17  movq xmm14, rax
000079fe5f5cea1c  movq xmm15, xmm15
000079fe5f5cea21  movq xmm15, xmm15
000079fe5f5cea26  movaps [r15+0x180], xmm15
000079fe5f5cea2e  movq xmm14, xmm14
000079fe5f5cea33  movq xmm14, xmm14
000079fe5f5cea38  movaps [r15+0x210], xmm14
000079fe5f5cea40  mov rax, [r15+0x48]
000079fe5f5cea44  mov [r15+0x78], rax
000079fe5f5cea48  mov r14, [r13+rax*1]
000079fe5f5cea4d  movq xmm15, r14
000079fe5f5cea52  lea r14, [rax+0x40]
000079fe5f5cea56  mov r12, [r13+r14*1]
000079fe5f5cea5b  movq xmm14, r12
000079fe5f5cea60  lea r14, [rax+0x80]
000079fe5f5cea67  mov r12, [r13+r14*1]
000079fe5f5cea6c  movq xmm13, r12
000079fe5f5cea71  movaps xmm12, [r15+0x120]
000079fe5f5cea79  movq r14, xmm12
000079fe5f5cea7e  movq r12, xmm15
000079fe5f5cea83  vmovq xmm15, r14
000079fe5f5cea88  vmovq xmm12, r12
000079fe5f5cea8d  movaps xmm11, xmm15
000079fe5f5cea91  mulsd xmm11, xmm12
000079fe5f5cea96  ucomisd xmm11, xmm11
000079fe5f5cea9b  jp 0x000079FE5F5CEEFC
000079fe5f5ceaa1  movq xmm11, xmm11
000079fe5f5ceaa6  movaps xmm15, [r15+0x130]
000079fe5f5ceaae  movq r14, xmm15
000079fe5f5ceab3  movq r12, xmm14
000079fe5f5ceab8  vmovq xmm15, r14
000079fe5f5ceabd  vmovq xmm14, r12
000079fe5f5ceac2  movaps xmm12, xmm15
000079fe5f5ceac6  mulsd xmm12, xmm14
000079fe5f5ceacb  ucomisd xmm12, xmm12
000079fe5f5cead0  jp 0x000079FE5F5CEF48
000079fe5f5cead6  movq xmm12, xmm12
000079fe5f5ceadb  movq r14, xmm11
000079fe5f5ceae0  movq r12, xmm1
000079fe5f5ceae5  vmovq xmm1, r14
000079fe5f5ceaea  vmovq xmm15, r12
000079fe5f5ceaef  movaps xmm14, xmm1
000079fe5f5ceaf3  addsd xmm14, xmm15
000079fe5f5ceaf8  ucomisd xmm14, xmm14
000079fe5f5ceafd  jp 0x000079FE5F5CEF94
000079fe5f5ceb03  movq xmm14, xmm14
000079fe5f5ceb08  movq r14, xmm14
000079fe5f5ceb0d  movq r12, xmm12
000079fe5f5ceb12  vmovq xmm1, r14
000079fe5f5ceb17  vmovq xmm15, r12
000079fe5f5ceb1c  movaps xmm14, xmm1
000079fe5f5ceb20  addsd xmm14, xmm15
000079fe5f5ceb25  ucomisd xmm14, xmm14
000079fe5f5ceb2a  jp 0x000079FE5F5CEFE0
000079fe5f5ceb30  movq xmm14, xmm14
000079fe5f5ceb35  movaps xmm1, [r15+0x140]
000079fe5f5ceb3d  movq r14, xmm1
000079fe5f5ceb42  movq r12, xmm13
000079fe5f5ceb47  vmovq xmm1, r14
000079fe5f5ceb4c  vmovq xmm15, r12
000079fe5f5ceb51  movaps xmm13, xmm1
000079fe5f5ceb55  mulsd xmm13, xmm15
000079fe5f5ceb5a  ucomisd xmm13, xmm13
000079fe5f5ceb5f  jp 0x000079FE5F5CF02C
000079fe5f5ceb65  movq xmm13, xmm13
000079fe5f5ceb6a  lea r14, [rax+0xC0]
000079fe5f5ceb71  mov r12, [r13+r14*1]
000079fe5f5ceb76  movq xmm1, r12
000079fe5f5ceb7b  movq r14, xmm14
000079fe5f5ceb80  movq r12, xmm13
000079fe5f5ceb85  vmovq xmm15, r14
000079fe5f5ceb8a  vmovq xmm14, r12
000079fe5f5ceb8f  movaps xmm13, xmm15
000079fe5f5ceb93  addsd xmm13, xmm14
000079fe5f5ceb98  ucomisd xmm13, xmm13
000079fe5f5ceb9d  jp 0x000079FE5F5CF082
000079fe5f5ceba3  movq xmm13, xmm13
000079fe5f5ceba8  movaps xmm15, [r15+0x150]
000079fe5f5cebb0  movq r14, xmm15
000079fe5f5cebb5  movq r12, xmm1
000079fe5f5cebba  vmovq xmm1, r14
000079fe5f5cebbf  vmovq xmm15, r12
000079fe5f5cebc4  movaps xmm14, xmm1
000079fe5f5cebc8  mulsd xmm14, xmm15
000079fe5f5cebcd  ucomisd xmm14, xmm14
000079fe5f5cebd2  jp 0x000079FE5F5CF0CE
000079fe5f5cebd8  movq xmm14, xmm14
000079fe5f5cebdd  lea r14, [rax+0x100]
000079fe5f5cebe4  mov r12, [r13+r14*1]
000079fe5f5cebe9  movq xmm1, r12
000079fe5f5cebee  movq r14, xmm13
000079fe5f5cebf3  movq r12, xmm14
000079fe5f5cebf8  vmovq xmm15, r14
000079fe5f5cebfd  vmovq xmm14, r12
000079fe5f5cec02  movaps xmm13, xmm15
000079fe5f5cec06  addsd xmm13, xmm14
000079fe5f5cec0b  ucomisd xmm13, xmm13
000079fe5f5cec10  jp 0x000079FE5F5CF124
000079fe5f5cec16  movq xmm13, xmm13
000079fe5f5cec1b  movaps xmm15, [r15+0x160]
000079fe5f5cec23  movq r14, xmm15
000079fe5f5cec28  movq r12, xmm1
000079fe5f5cec2d  vmovq xmm1, r14
000079fe5f5cec32  vmovq xmm15, r12
000079fe5f5cec37  movaps xmm14, xmm1
000079fe5f5cec3b  mulsd xmm14, xmm15
000079fe5f5cec40  ucomisd xmm14, xmm14
000079fe5f5cec45  jp 0x000079FE5F5CF170
000079fe5f5cec4b  movq xmm14, xmm14
000079fe5f5cec50  lea r14, [rax+0x140]
000079fe5f5cec57  mov r12, [r13+r14*1]
000079fe5f5cec5c  movq xmm1, r12
000079fe5f5cec61  movq r14, xmm13
000079fe5f5cec66  movq r12, xmm14
000079fe5f5cec6b  vmovq xmm15, r14
000079fe5f5cec70  vmovq xmm14, r12
000079fe5f5cec75  movaps xmm13, xmm15
000079fe5f5cec79  addsd xmm13, xmm14
000079fe5f5cec7e  ucomisd xmm13, xmm13
000079fe5f5cec83  jp 0x000079FE5F5CF1C6
000079fe5f5cec89  movq xmm13, xmm13
000079fe5f5cec8e  movaps xmm15, [r15+0x170]
000079fe5f5cec96  movq r14, xmm15
000079fe5f5cec9b  movq r12, xmm1
000079fe5f5ceca0  vmovq xmm1, r14
000079fe5f5ceca5  vmovq xmm15, r12
000079fe5f5cecaa  movaps xmm14, xmm1
000079fe5f5cecae  mulsd xmm14, xmm15
000079fe5f5cecb3  ucomisd xmm14, xmm14
000079fe5f5cecb8  jp 0x000079FE5F5CF212
000079fe5f5cecbe  movq xmm14, xmm14
000079fe5f5cecc3  lea r14, [rax+0x180]
000079fe5f5cecca  mov r12, [r13+r14*1]
000079fe5f5ceccf  movq xmm1, r12
000079fe5f5cecd4  movq r14, xmm13
000079fe5f5cecd9  movq r12, xmm14
000079fe5f5cecde  vmovq xmm15, r14
000079fe5f5cece3  vmovq xmm14, r12
000079fe5f5cece8  movaps xmm13, xmm15
000079fe5f5cecec  addsd xmm13, xmm14
000079fe5f5cecf1  ucomisd xmm13, xmm13
000079fe5f5cecf6  jp 0x000079FE5F5CF268
000079fe5f5cecfc  movq xmm13, xmm13
000079fe5f5ced01  movaps xmm15, [r15+0x180]
000079fe5f5ced09  movq r14, xmm15
000079fe5f5ced0e  movq r12, xmm1
000079fe5f5ced13  vmovq xmm1, r14
000079fe5f5ced18  vmovq xmm15, r12
000079fe5f5ced1d  movaps xmm14, xmm1
000079fe5f5ced21  mulsd xmm14, xmm15
000079fe5f5ced26  ucomisd xmm14, xmm14
000079fe5f5ced2b  jp 0x000079FE5F5CF2B4
000079fe5f5ced31  movq xmm14, xmm14
000079fe5f5ced36  lea r14, [rax+0x1C0]
000079fe5f5ced3d  mov rax, [r13+r14*1]
000079fe5f5ced42  movq xmm1, rax
000079fe5f5ced47  movaps [r15+0x240], xmm1
000079fe5f5ced4f  movq rax, xmm13
000079fe5f5ced54  movq r14, xmm14
000079fe5f5ced59  vmovq xmm15, rax
000079fe5f5ced5e  vmovq xmm14, r14
000079fe5f5ced63  movaps xmm13, xmm15
000079fe5f5ced67  addsd xmm13, xmm14
000079fe5f5ced6c  ucomisd xmm13, xmm13
000079fe5f5ced71  jp 0x000079FE5F5CF30A
000079fe5f5ced77  movq xmm13, xmm13
000079fe5f5ced7c  movaps xmm15, [r15+0x210]
000079fe5f5ced84  movq rax, xmm15
000079fe5f5ced89  movq r14, xmm1
000079fe5f5ced8e  vmovq xmm1, rax
000079fe5f5ced93  vmovq xmm15, r14
000079fe5f5ced98  movaps xmm14, xmm1
000079fe5f5ced9c  mulsd xmm14, xmm15
000079fe5f5ceda1  ucomisd xmm14, xmm14
000079fe5f5ceda6  jp 0x000079FE5F5CF352
000079fe5f5cedac  movq xmm14, xmm14
000079fe5f5cedb1  movaps [r15+0x230], xmm14
000079fe5f5cedb9  movq rax, xmm13
000079fe5f5cedbe  movq r14, xmm14
000079fe5f5cedc3  vmovq xmm1, rax
000079fe5f5cedc8  vmovq xmm15, r14
000079fe5f5cedcd  movaps xmm14, xmm1
000079fe5f5cedd1  addsd xmm14, xmm15
000079fe5f5cedd6  ucomisd xmm14, xmm14
000079fe5f5ceddb  jp 0x000079FE5F5CF39A
000079fe5f5cede1  movq xmm14, xmm14
000079fe5f5cede6  movaps [r15+0x220], xmm14
000079fe5f5cedee  movq rax, xmm14
000079fe5f5cedf3  mov r14d, 0x4205C0
000079fe5f5cedf9  mov [r13+r14*1], rax
000079fe5f5cedfe  mov qword ptr [r15+0x70], 0x08
000079fe5f5cee06  xor eax, eax
000079fe5f5cee08  mov r14d, 0x08
000079fe5f5cee0e  mov r12d, 0x40
000079fe5f5cee14  cmp r14, r12
000079fe5f5cee17  cmc
000079fe5f5cee18  lahf
000079fe5f5cee19  seto al
000079fe5f5cee1c  mov [r15+0x108], eax
000079fe5f5cee23  mov eax, [r15+0x108]
000079fe5f5cee2a  sahf
000079fe5f5cee2b  jnz 0x000079FE5F5CEE5D
000079fe5f5cee2d  cmp dword ptr [r15+0x318], 0x00
000079fe5f5cee35  jz 0x000079FE5F5CFD40
000079fe5f5cee3b  nop [rax+rax*1], ax
000079fe5f5cee44  nop [rax+rax*1], eax
000079fe5f5cee4c  mov eax, 0x410118
000079fe5f5cee51  mov [r15+0x100], rax
000079fe5f5cee58  jmp 0x000079FE5F3FE110
000079fe5f5cee5d  cmp dword ptr [r15+0x318], 0x00
000079fe5f5cee65  jz 0x000079FE5F5CF3F0
000079fe5f5cee6b  nop [rax+rax*1], ax
000079fe5f5cee74  nop [rax+rax*1], eax
000079fe5f5cee7c  mov eax, 0x4100A4
000079fe5f5cee81  mov [r15+0x100], rax
000079fe5f5cee88  jmp 0x000079FE5F3FE110
000079fe5f5cee8d  int3
000079fe5f5cee8e  call 0x000079FE5F40DC20
000079fe5f5cee93  jmp 0x000079FE5F5CE949
000079fe5f5cee98  call 0x000079FE5F4C0370
000079fe5f5cee9d  jmp 0x000079FE5F5CE952
000079fe5f5ceea2  call 0x000079FE5F4E27E0
000079fe5f5ceea7  jmp 0x000079FE5F5CE989
000079fe5f5ceeac  call 0x000079FE5F4E1570
000079fe5f5ceeb1  jmp 0x000079FE5F5CE992
000079fe5f5ceeb6  call 0x000079FE5F4E27E0
000079fe5f5ceebb  jmp 0x000079FE5F5CE9C9
000079fe5f5ceec0  call 0x000079FE5F4E1570
000079fe5f5ceec5  jmp 0x000079FE5F5CE9D2
000079fe5f5ceeca  call 0x000079FE5F4E27E0
000079fe5f5ceecf  jmp 0x000079FE5F5CEA09
000079fe5f5ceed4  call 0x000079FE5F4D59C0
000079fe5f5ceed9  jmp 0x000079FE5F5CEA12
000079fe5f5ceede  call 0x000079FE5F40DC20
000079fe5f5ceee3  jmp 0x000079FE5F5CEA4D
000079fe5f5ceee8  call 0x000079FE5F4E27E0
000079fe5f5ceeed  jmp 0x000079FE5F5CEA5B
000079fe5f5ceef2  call 0x000079FE5F4E27E0
000079fe5f5ceef7  jmp 0x000079FE5F5CEA6C
000079fe5f5ceefc  ucomisd xmm15, xmm12
000079fe5f5cef01  jp 0x000079FE5F5CEF10
000079fe5f5cef03  movaps xmm11, [0x000079FE5F1FE030]
000079fe5f5cef0b  jmp 0x000079FE5F5CEAA1
000079fe5f5cef10  vxorps xmm0, xmm15, xmm12
000079fe5f5cef15  pextrw r14d, xmm0, 0x03
000079fe5f5cef1b  and r14d, 0x7FF8
000079fe5f5cef22  cmp r14d, 0x08
000079fe5f5cef26  jnz 0x000079FE5F5CEAA1
000079fe5f5cef2c  movq r14, xmm12
000079fe5f5cef31  shl r14, 0x0D
000079fe5f5cef35  jbe 0x000079FE5F5CEAA1
000079fe5f5cef3b  vorps xmm11, xmm12, [0x000079FE5F1FE040]
000079fe5f5cef43  jmp 0x000079FE5F5CEAA1
000079fe5f5cef48  ucomisd xmm15, xmm14
000079fe5f5cef4d  jp 0x000079FE5F5CEF5C
000079fe5f5cef4f  movaps xmm12, [0x000079FE5F1FE030]
000079fe5f5cef57  jmp 0x000079FE5F5CEAD6
000079fe5f5cef5c  vxorps xmm0, xmm15, xmm14
000079fe5f5cef61  pextrw r14d, xmm0, 0x03
000079fe5f5cef67  and r14d, 0x7FF8
000079fe5f5cef6e  cmp r14d, 0x08
000079fe5f5cef72  jnz 0x000079FE5F5CEAD6
000079fe5f5cef78  movq r14, xmm14
000079fe5f5cef7d  shl r14, 0x0D
000079fe5f5cef81  jbe 0x000079FE5F5CEAD6
000079fe5f5cef87  vorps xmm12, xmm14, [0x000079FE5F1FE040]
000079fe5f5cef8f  jmp 0x000079FE5F5CEAD6
000079fe5f5cef94  ucomisd xmm1, xmm15
000079fe5f5cef99  jp 0x000079FE5F5CEFA8
000079fe5f5cef9b  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cefa3  jmp 0x000079FE5F5CEB03
000079fe5f5cefa8  vxorps xmm0, xmm1, xmm15
000079fe5f5cefad  pextrw r14d, xmm0, 0x03
000079fe5f5cefb3  and r14d, 0x7FF8
000079fe5f5cefba  cmp r14d, 0x08
000079fe5f5cefbe  jnz 0x000079FE5F5CEB03
000079fe5f5cefc4  movq r14, xmm15
000079fe5f5cefc9  shl r14, 0x0D
000079fe5f5cefcd  jbe 0x000079FE5F5CEB03
000079fe5f5cefd3  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cefdb  jmp 0x000079FE5F5CEB03
000079fe5f5cefe0  ucomisd xmm1, xmm15
000079fe5f5cefe5  jp 0x000079FE5F5CEFF4
000079fe5f5cefe7  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cefef  jmp 0x000079FE5F5CEB30
000079fe5f5ceff4  vxorps xmm0, xmm1, xmm15
000079fe5f5ceff9  pextrw r14d, xmm0, 0x03
000079fe5f5cefff  and r14d, 0x7FF8
000079fe5f5cf006  cmp r14d, 0x08
000079fe5f5cf00a  jnz 0x000079FE5F5CEB30
000079fe5f5cf010  movq r14, xmm15
000079fe5f5cf015  shl r14, 0x0D
000079fe5f5cf019  jbe 0x000079FE5F5CEB30
000079fe5f5cf01f  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf027  jmp 0x000079FE5F5CEB30
000079fe5f5cf02c  ucomisd xmm1, xmm15
000079fe5f5cf031  jp 0x000079FE5F5CF040
000079fe5f5cf033  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cf03b  jmp 0x000079FE5F5CEB65
000079fe5f5cf040  vxorps xmm0, xmm1, xmm15
000079fe5f5cf045  pextrw r14d, xmm0, 0x03
000079fe5f5cf04b  and r14d, 0x7FF8
000079fe5f5cf052  cmp r14d, 0x08
000079fe5f5cf056  jnz 0x000079FE5F5CEB65
000079fe5f5cf05c  movq r14, xmm15
000079fe5f5cf061  shl r14, 0x0D
000079fe5f5cf065  jbe 0x000079FE5F5CEB65
000079fe5f5cf06b  vorps xmm13, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf073  jmp 0x000079FE5F5CEB65
000079fe5f5cf078  call 0x000079FE5F4E27E0
000079fe5f5cf07d  jmp 0x000079FE5F5CEB76
000079fe5f5cf082  ucomisd xmm15, xmm14
000079fe5f5cf087  jp 0x000079FE5F5CF096
000079fe5f5cf089  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cf091  jmp 0x000079FE5F5CEBA3
000079fe5f5cf096  vxorps xmm0, xmm15, xmm14
000079fe5f5cf09b  pextrw r14d, xmm0, 0x03
000079fe5f5cf0a1  and r14d, 0x7FF8
000079fe5f5cf0a8  cmp r14d, 0x08
000079fe5f5cf0ac  jnz 0x000079FE5F5CEBA3
000079fe5f5cf0b2  movq r14, xmm14
000079fe5f5cf0b7  shl r14, 0x0D
000079fe5f5cf0bb  jbe 0x000079FE5F5CEBA3
000079fe5f5cf0c1  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cf0c9  jmp 0x000079FE5F5CEBA3
000079fe5f5cf0ce  ucomisd xmm1, xmm15
000079fe5f5cf0d3  jp 0x000079FE5F5CF0E2
000079fe5f5cf0d5  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cf0dd  jmp 0x000079FE5F5CEBD8
000079fe5f5cf0e2  vxorps xmm0, xmm1, xmm15
000079fe5f5cf0e7  pextrw r14d, xmm0, 0x03
000079fe5f5cf0ed  and r14d, 0x7FF8
000079fe5f5cf0f4  cmp r14d, 0x08
000079fe5f5cf0f8  jnz 0x000079FE5F5CEBD8
000079fe5f5cf0fe  movq r14, xmm15
000079fe5f5cf103  shl r14, 0x0D
000079fe5f5cf107  jbe 0x000079FE5F5CEBD8
000079fe5f5cf10d  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf115  jmp 0x000079FE5F5CEBD8
000079fe5f5cf11a  call 0x000079FE5F4E27E0
000079fe5f5cf11f  jmp 0x000079FE5F5CEBE9
000079fe5f5cf124  ucomisd xmm15, xmm14
000079fe5f5cf129  jp 0x000079FE5F5CF138
000079fe5f5cf12b  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cf133  jmp 0x000079FE5F5CEC16
000079fe5f5cf138  vxorps xmm0, xmm15, xmm14
000079fe5f5cf13d  pextrw r14d, xmm0, 0x03
000079fe5f5cf143  and r14d, 0x7FF8
000079fe5f5cf14a  cmp r14d, 0x08
000079fe5f5cf14e  jnz 0x000079FE5F5CEC16
000079fe5f5cf154  movq r14, xmm14
000079fe5f5cf159  shl r14, 0x0D
000079fe5f5cf15d  jbe 0x000079FE5F5CEC16
000079fe5f5cf163  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cf16b  jmp 0x000079FE5F5CEC16
000079fe5f5cf170  ucomisd xmm1, xmm15
000079fe5f5cf175  jp 0x000079FE5F5CF184
000079fe5f5cf177  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cf17f  jmp 0x000079FE5F5CEC4B
000079fe5f5cf184  vxorps xmm0, xmm1, xmm15
000079fe5f5cf189  pextrw r14d, xmm0, 0x03
000079fe5f5cf18f  and r14d, 0x7FF8
000079fe5f5cf196  cmp r14d, 0x08
000079fe5f5cf19a  jnz 0x000079FE5F5CEC4B
000079fe5f5cf1a0  movq r14, xmm15
000079fe5f5cf1a5  shl r14, 0x0D
000079fe5f5cf1a9  jbe 0x000079FE5F5CEC4B
000079fe5f5cf1af  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf1b7  jmp 0x000079FE5F5CEC4B
000079fe5f5cf1bc  call 0x000079FE5F4E27E0
000079fe5f5cf1c1  jmp 0x000079FE5F5CEC5C
000079fe5f5cf1c6  ucomisd xmm15, xmm14
000079fe5f5cf1cb  jp 0x000079FE5F5CF1DA
000079fe5f5cf1cd  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cf1d5  jmp 0x000079FE5F5CEC89
000079fe5f5cf1da  vxorps xmm0, xmm15, xmm14
000079fe5f5cf1df  pextrw r14d, xmm0, 0x03
000079fe5f5cf1e5  and r14d, 0x7FF8
000079fe5f5cf1ec  cmp r14d, 0x08
000079fe5f5cf1f0  jnz 0x000079FE5F5CEC89
000079fe5f5cf1f6  movq r14, xmm14
000079fe5f5cf1fb  shl r14, 0x0D
000079fe5f5cf1ff  jbe 0x000079FE5F5CEC89
000079fe5f5cf205  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cf20d  jmp 0x000079FE5F5CEC89
000079fe5f5cf212  ucomisd xmm1, xmm15
000079fe5f5cf217  jp 0x000079FE5F5CF226
000079fe5f5cf219  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cf221  jmp 0x000079FE5F5CECBE
000079fe5f5cf226  vxorps xmm0, xmm1, xmm15
000079fe5f5cf22b  pextrw r14d, xmm0, 0x03
000079fe5f5cf231  and r14d, 0x7FF8
000079fe5f5cf238  cmp r14d, 0x08
000079fe5f5cf23c  jnz 0x000079FE5F5CECBE
000079fe5f5cf242  movq r14, xmm15
000079fe5f5cf247  shl r14, 0x0D
000079fe5f5cf24b  jbe 0x000079FE5F5CECBE
000079fe5f5cf251  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf259  jmp 0x000079FE5F5CECBE
000079fe5f5cf25e  call 0x000079FE5F4E27E0
000079fe5f5cf263  jmp 0x000079FE5F5CECCF
000079fe5f5cf268  ucomisd xmm15, xmm14
000079fe5f5cf26d  jp 0x000079FE5F5CF27C
000079fe5f5cf26f  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cf277  jmp 0x000079FE5F5CECFC
000079fe5f5cf27c  vxorps xmm0, xmm15, xmm14
000079fe5f5cf281  pextrw r14d, xmm0, 0x03
000079fe5f5cf287  and r14d, 0x7FF8
000079fe5f5cf28e  cmp r14d, 0x08
000079fe5f5cf292  jnz 0x000079FE5F5CECFC
000079fe5f5cf298  movq r14, xmm14
000079fe5f5cf29d  shl r14, 0x0D
000079fe5f5cf2a1  jbe 0x000079FE5F5CECFC
000079fe5f5cf2a7  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cf2af  jmp 0x000079FE5F5CECFC
000079fe5f5cf2b4  ucomisd xmm1, xmm15
000079fe5f5cf2b9  jp 0x000079FE5F5CF2C8
000079fe5f5cf2bb  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cf2c3  jmp 0x000079FE5F5CED31
000079fe5f5cf2c8  vxorps xmm0, xmm1, xmm15
000079fe5f5cf2cd  pextrw r14d, xmm0, 0x03
000079fe5f5cf2d3  and r14d, 0x7FF8
000079fe5f5cf2da  cmp r14d, 0x08
000079fe5f5cf2de  jnz 0x000079FE5F5CED31
000079fe5f5cf2e4  movq r14, xmm15
000079fe5f5cf2e9  shl r14, 0x0D
000079fe5f5cf2ed  jbe 0x000079FE5F5CED31
000079fe5f5cf2f3  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf2fb  jmp 0x000079FE5F5CED31
000079fe5f5cf300  call 0x000079FE5F4D59C0
000079fe5f5cf305  jmp 0x000079FE5F5CED42
000079fe5f5cf30a  ucomisd xmm15, xmm14
000079fe5f5cf30f  jp 0x000079FE5F5CF31E
000079fe5f5cf311  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cf319  jmp 0x000079FE5F5CED77
000079fe5f5cf31e  vxorps xmm0, xmm15, xmm14
000079fe5f5cf323  pextrw eax, xmm0, 0x03
000079fe5f5cf328  and eax, 0x7FF8
000079fe5f5cf32d  cmp eax, 0x08
000079fe5f5cf330  jnz 0x000079FE5F5CED77
000079fe5f5cf336  movq rax, xmm14
000079fe5f5cf33b  shl rax, 0x0D
000079fe5f5cf33f  jbe 0x000079FE5F5CED77
000079fe5f5cf345  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cf34d  jmp 0x000079FE5F5CED77
000079fe5f5cf352  ucomisd xmm1, xmm15
000079fe5f5cf357  jp 0x000079FE5F5CF366
000079fe5f5cf359  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cf361  jmp 0x000079FE5F5CEDAC
000079fe5f5cf366  vxorps xmm0, xmm1, xmm15
000079fe5f5cf36b  pextrw eax, xmm0, 0x03
000079fe5f5cf370  and eax, 0x7FF8
000079fe5f5cf375  cmp eax, 0x08
000079fe5f5cf378  jnz 0x000079FE5F5CEDAC
000079fe5f5cf37e  movq rax, xmm15
000079fe5f5cf383  shl rax, 0x0D
000079fe5f5cf387  jbe 0x000079FE5F5CEDAC
000079fe5f5cf38d  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf395  jmp 0x000079FE5F5CEDAC
000079fe5f5cf39a  ucomisd xmm1, xmm15
000079fe5f5cf39f  jp 0x000079FE5F5CF3AE
000079fe5f5cf3a1  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cf3a9  jmp 0x000079FE5F5CEDE1
000079fe5f5cf3ae  vxorps xmm0, xmm1, xmm15
000079fe5f5cf3b3  pextrw eax, xmm0, 0x03
000079fe5f5cf3b8  and eax, 0x7FF8
000079fe5f5cf3bd  cmp eax, 0x08
000079fe5f5cf3c0  jnz 0x000079FE5F5CEDE1
000079fe5f5cf3c6  movq rax, xmm15
000079fe5f5cf3cb  shl rax, 0x0D
000079fe5f5cf3cf  jbe 0x000079FE5F5CEDE1
000079fe5f5cf3d5  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf3dd  jmp 0x000079FE5F5CEDE1
000079fe5f5cf3e2  call 0x000079FE5F4D5EB0
000079fe5f5cf3e7  jmp 0x000079FE5F5CEDFE
000079fe5f5cf3ec  int3
000079fe5f5cf3ed  nop [rax], eax
000079fe5f5cf3f0  mov rax, [r15+0x48]
000079fe5f5cf3f4  mov r14, [r15+0x70]
000079fe5f5cf3f8  lea r12, [rax+r14*1]
000079fe5f5cf3fc  mov [r15+0x78], r12
000079fe5f5cf400  mov rax, [r13+r12*1]
000079fe5f5cf405  movq xmm1, rax
000079fe5f5cf40a  lea rax, [r12+0x40]
000079fe5f5cf40f  mov r11, [r13+rax*1]
000079fe5f5cf414  movq xmm15, r11
000079fe5f5cf419  lea rax, [r12+0x80]
000079fe5f5cf421  mov r11, [r13+rax*1]
000079fe5f5cf426  movq xmm14, r11
000079fe5f5cf42b  movaps xmm13, [r15+0x120]
000079fe5f5cf433  movq rax, xmm13
000079fe5f5cf438  movq r11, xmm1
000079fe5f5cf43d  vmovq xmm1, rax
000079fe5f5cf442  vmovq xmm13, r11
000079fe5f5cf447  movaps xmm12, xmm1
000079fe5f5cf44b  mulsd xmm12, xmm13
000079fe5f5cf450  ucomisd xmm12, xmm12
000079fe5f5cf455  jp 0x000079FE5F5CF879
000079fe5f5cf45b  movq xmm12, xmm12
000079fe5f5cf460  movaps xmm1, [r15+0x130]
000079fe5f5cf468  movq rax, xmm1
000079fe5f5cf46d  movq r11, xmm15
000079fe5f5cf472  vmovq xmm1, rax
000079fe5f5cf477  vmovq xmm15, r11
000079fe5f5cf47c  movaps xmm13, xmm1
000079fe5f5cf480  mulsd xmm13, xmm15
000079fe5f5cf485  ucomisd xmm13, xmm13
000079fe5f5cf48a  jp 0x000079FE5F5CF8C1
000079fe5f5cf490  movq xmm13, xmm13
000079fe5f5cf495  movq rax, xmm12
000079fe5f5cf49a  movaps xmm1, [r15+0x110]
000079fe5f5cf4a2  movq r11, xmm1
000079fe5f5cf4a7  vmovq xmm1, rax
000079fe5f5cf4ac  vmovq xmm15, r11
000079fe5f5cf4b1  movaps xmm12, xmm1
000079fe5f5cf4b5  addsd xmm12, xmm15
000079fe5f5cf4ba  ucomisd xmm12, xmm12
000079fe5f5cf4bf  jp 0x000079FE5F5CF909
000079fe5f5cf4c5  movq xmm12, xmm12
000079fe5f5cf4ca  movq rax, xmm12
000079fe5f5cf4cf  movq r11, xmm13
000079fe5f5cf4d4  vmovq xmm1, rax
000079fe5f5cf4d9  vmovq xmm15, r11
000079fe5f5cf4de  movaps xmm13, xmm1
000079fe5f5cf4e2  addsd xmm13, xmm15
000079fe5f5cf4e7  ucomisd xmm13, xmm13
000079fe5f5cf4ec  jp 0x000079FE5F5CF951
000079fe5f5cf4f2  movq xmm13, xmm13
000079fe5f5cf4f7  movaps xmm1, [r15+0x140]
000079fe5f5cf4ff  movq rax, xmm1
000079fe5f5cf504  movq r11, xmm14
000079fe5f5cf509  vmovq xmm1, rax
000079fe5f5cf50e  vmovq xmm15, r11
000079fe5f5cf513  movaps xmm14, xmm1
000079fe5f5cf517  mulsd xmm14, xmm15
000079fe5f5cf51c  ucomisd xmm14, xmm14
000079fe5f5cf521  jp 0x000079FE5F5CF999
000079fe5f5cf527  movq xmm14, xmm14
000079fe5f5cf52c  lea rax, [r12+0xC0]
000079fe5f5cf534  mov r11, [r13+rax*1]
000079fe5f5cf539  movq xmm1, r11
000079fe5f5cf53e  movq rax, xmm13
000079fe5f5cf543  movq r11, xmm14
000079fe5f5cf548  vmovq xmm15, rax
000079fe5f5cf54d  vmovq xmm14, r11
000079fe5f5cf552  movaps xmm13, xmm15
000079fe5f5cf556  addsd xmm13, xmm14
000079fe5f5cf55b  ucomisd xmm13, xmm13
000079fe5f5cf560  jp 0x000079FE5F5CF9EB
000079fe5f5cf566  movq xmm13, xmm13
000079fe5f5cf56b  movaps xmm15, [r15+0x150]
000079fe5f5cf573  movq rax, xmm15
000079fe5f5cf578  movq r11, xmm1
000079fe5f5cf57d  vmovq xmm1, rax
000079fe5f5cf582  vmovq xmm15, r11
000079fe5f5cf587  movaps xmm14, xmm1
000079fe5f5cf58b  mulsd xmm14, xmm15
000079fe5f5cf590  ucomisd xmm14, xmm14
000079fe5f5cf595  jp 0x000079FE5F5CFA33
000079fe5f5cf59b  movq xmm14, xmm14
000079fe5f5cf5a0  lea rax, [r12+0x100]
000079fe5f5cf5a8  mov r11, [r13+rax*1]
000079fe5f5cf5ad  movq xmm1, r11
000079fe5f5cf5b2  movq rax, xmm13
000079fe5f5cf5b7  movq r11, xmm14
000079fe5f5cf5bc  vmovq xmm15, rax
000079fe5f5cf5c1  vmovq xmm14, r11
000079fe5f5cf5c6  movaps xmm13, xmm15
000079fe5f5cf5ca  addsd xmm13, xmm14
000079fe5f5cf5cf  ucomisd xmm13, xmm13
000079fe5f5cf5d4  jp 0x000079FE5F5CFA85
000079fe5f5cf5da  movq xmm13, xmm13
000079fe5f5cf5df  movaps xmm15, [r15+0x160]
000079fe5f5cf5e7  movq rax, xmm15
000079fe5f5cf5ec  movq r11, xmm1
000079fe5f5cf5f1  vmovq xmm1, rax
000079fe5f5cf5f6  vmovq xmm15, r11
000079fe5f5cf5fb  movaps xmm14, xmm1
000079fe5f5cf5ff  mulsd xmm14, xmm15
000079fe5f5cf604  ucomisd xmm14, xmm14
000079fe5f5cf609  jp 0x000079FE5F5CFACD
000079fe5f5cf60f  movq xmm14, xmm14
000079fe5f5cf614  lea rax, [r12+0x140]
000079fe5f5cf61c  mov r11, [r13+rax*1]
000079fe5f5cf621  movq xmm1, r11
000079fe5f5cf626  movq rax, xmm13
000079fe5f5cf62b  movq r11, xmm14
000079fe5f5cf630  vmovq xmm15, rax
000079fe5f5cf635  vmovq xmm14, r11
000079fe5f5cf63a  movaps xmm13, xmm15
000079fe5f5cf63e  addsd xmm13, xmm14
000079fe5f5cf643  ucomisd xmm13, xmm13
000079fe5f5cf648  jp 0x000079FE5F5CFB1F
000079fe5f5cf64e  movq xmm13, xmm13
000079fe5f5cf653  movaps xmm15, [r15+0x170]
000079fe5f5cf65b  movq rax, xmm15
000079fe5f5cf660  movq r11, xmm1
000079fe5f5cf665  vmovq xmm1, rax
000079fe5f5cf66a  vmovq xmm15, r11
000079fe5f5cf66f  movaps xmm14, xmm1
000079fe5f5cf673  mulsd xmm14, xmm15
000079fe5f5cf678  ucomisd xmm14, xmm14
000079fe5f5cf67d  jp 0x000079FE5F5CFB67
000079fe5f5cf683  movq xmm14, xmm14
000079fe5f5cf688  lea rax, [r12+0x180]
000079fe5f5cf690  mov r11, [r13+rax*1]
000079fe5f5cf695  movq xmm1, r11
000079fe5f5cf69a  movq rax, xmm13
000079fe5f5cf69f  movq r11, xmm14
000079fe5f5cf6a4  vmovq xmm15, rax
000079fe5f5cf6a9  vmovq xmm14, r11
000079fe5f5cf6ae  movaps xmm13, xmm15
000079fe5f5cf6b2  addsd xmm13, xmm14
000079fe5f5cf6b7  ucomisd xmm13, xmm13
000079fe5f5cf6bc  jp 0x000079FE5F5CFBB9
000079fe5f5cf6c2  movq xmm13, xmm13
000079fe5f5cf6c7  movaps xmm15, [r15+0x180]
000079fe5f5cf6cf  movq rax, xmm15
000079fe5f5cf6d4  movq r11, xmm1
000079fe5f5cf6d9  vmovq xmm1, rax
000079fe5f5cf6de  vmovq xmm15, r11
000079fe5f5cf6e3  movaps xmm14, xmm1
000079fe5f5cf6e7  mulsd xmm14, xmm15
000079fe5f5cf6ec  ucomisd xmm14, xmm14
000079fe5f5cf6f1  jp 0x000079FE5F5CFC01
000079fe5f5cf6f7  movq xmm14, xmm14
000079fe5f5cf6fc  lea rax, [r12+0x1C0]
000079fe5f5cf704  mov r12, [r13+rax*1]
000079fe5f5cf709  movq xmm1, r12
000079fe5f5cf70e  movaps [r15+0x240], xmm1
000079fe5f5cf716  movq rax, xmm13
000079fe5f5cf71b  movq r12, xmm14
000079fe5f5cf720  vmovq xmm15, rax
000079fe5f5cf725  vmovq xmm14, r12
000079fe5f5cf72a  movaps xmm13, xmm15
000079fe5f5cf72e  addsd xmm13, xmm14
000079fe5f5cf733  ucomisd xmm13, xmm13
000079fe5f5cf738  jp 0x000079FE5F5CFC53
000079fe5f5cf73e  movq xmm13, xmm13
000079fe5f5cf743  movaps xmm15, [r15+0x210]
000079fe5f5cf74b  movq rax, xmm15
000079fe5f5cf750  movq r12, xmm1
000079fe5f5cf755  vmovq xmm1, rax
000079fe5f5cf75a  vmovq xmm15, r12
000079fe5f5cf75f  movaps xmm14, xmm1
000079fe5f5cf763  mulsd xmm14, xmm15
000079fe5f5cf768  ucomisd xmm14, xmm14
000079fe5f5cf76d  jp 0x000079FE5F5CFC9B
000079fe5f5cf773  movq xmm14, xmm14
000079fe5f5cf778  movaps [r15+0x230], xmm14
000079fe5f5cf780  movq rax, xmm13
000079fe5f5cf785  movq r12, xmm14
000079fe5f5cf78a  vmovq xmm1, rax
000079fe5f5cf78f  vmovq xmm15, r12
000079fe5f5cf794  movaps xmm14, xmm1
000079fe5f5cf798  addsd xmm14, xmm15
000079fe5f5cf79d  ucomisd xmm14, xmm14
000079fe5f5cf7a2  jp 0x000079FE5F5CFCE3
000079fe5f5cf7a8  movq xmm14, xmm14
000079fe5f5cf7ad  movaps [r15+0x220], xmm14
000079fe5f5cf7b5  mov rax, [r15+0x68]
000079fe5f5cf7b9  lea r12, [rax+r14*1]
000079fe5f5cf7bd  movq rax, xmm14
000079fe5f5cf7c2  mov [r13+r12*1], rax
000079fe5f5cf7c7  lea rax, [r14+0x08]
000079fe5f5cf7cb  mov [r15+0x70], rax
000079fe5f5cf7cf  mov [rsp+0x10], rax
000079fe5f5cf7d4  xor eax, eax
000079fe5f5cf7d6  mov r14, [rsp+0x10]
000079fe5f5cf7db  mov r12d, 0x40
000079fe5f5cf7e1  cmp r14, r12
000079fe5f5cf7e4  cmc
000079fe5f5cf7e5  lahf
000079fe5f5cf7e6  seto al
000079fe5f5cf7e9  mov [r15+0x108], eax
000079fe5f5cf7f0  mov eax, [r15+0x108]
000079fe5f5cf7f7  sahf
000079fe5f5cf7f8  jnz 0x000079FE5F5CF82A
000079fe5f5cf7fa  cmp dword ptr [r15+0x318], 0x00
000079fe5f5cf802  jz 0x000079FE5F5CFD40
000079fe5f5cf808  nop [rax+rax*1], ax
000079fe5f5cf811  nop [rax+rax*1], eax
000079fe5f5cf819  mov eax, 0x410118
000079fe5f5cf81e  mov [r15+0x100], rax
000079fe5f5cf825  jmp 0x000079FE5F3FE110
000079fe5f5cf82a  cmp dword ptr [r15+0x318], 0x00
000079fe5f5cf832  jz 0x000079FE5F5CF3F0
000079fe5f5cf838  nop [rax+rax*1], ax
000079fe5f5cf841  nop [rax+rax*1], eax
000079fe5f5cf849  mov eax, 0x4100A4
000079fe5f5cf84e  mov [r15+0x100], rax
000079fe5f5cf855  jmp 0x000079FE5F3FE110
000079fe5f5cf85a  int3
000079fe5f5cf85b  call 0x000079FE5F4B47C0
000079fe5f5cf860  jmp 0x000079FE5F5CF405
000079fe5f5cf865  call 0x000079FE5F40A4B0
000079fe5f5cf86a  jmp 0x000079FE5F5CF414
000079fe5f5cf86f  call 0x000079FE5F40A4B0
000079fe5f5cf874  jmp 0x000079FE5F5CF426
000079fe5f5cf879  ucomisd xmm1, xmm13
000079fe5f5cf87e  jp 0x000079FE5F5CF88D
000079fe5f5cf880  movaps xmm12, [0x000079FE5F1FE030]
000079fe5f5cf888  jmp 0x000079FE5F5CF45B
000079fe5f5cf88d  vxorps xmm0, xmm1, xmm13
000079fe5f5cf892  pextrw eax, xmm0, 0x03
000079fe5f5cf897  and eax, 0x7FF8
000079fe5f5cf89c  cmp eax, 0x08
000079fe5f5cf89f  jnz 0x000079FE5F5CF45B
000079fe5f5cf8a5  movq rax, xmm13
000079fe5f5cf8aa  shl rax, 0x0D
000079fe5f5cf8ae  jbe 0x000079FE5F5CF45B
000079fe5f5cf8b4  vorps xmm12, xmm13, [0x000079FE5F1FE040]
000079fe5f5cf8bc  jmp 0x000079FE5F5CF45B
000079fe5f5cf8c1  ucomisd xmm1, xmm15
000079fe5f5cf8c6  jp 0x000079FE5F5CF8D5
000079fe5f5cf8c8  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cf8d0  jmp 0x000079FE5F5CF490
000079fe5f5cf8d5  vxorps xmm0, xmm1, xmm15
000079fe5f5cf8da  pextrw eax, xmm0, 0x03
000079fe5f5cf8df  and eax, 0x7FF8
000079fe5f5cf8e4  cmp eax, 0x08
000079fe5f5cf8e7  jnz 0x000079FE5F5CF490
000079fe5f5cf8ed  movq rax, xmm15
000079fe5f5cf8f2  shl rax, 0x0D
000079fe5f5cf8f6  jbe 0x000079FE5F5CF490
000079fe5f5cf8fc  vorps xmm13, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf904  jmp 0x000079FE5F5CF490
000079fe5f5cf909  ucomisd xmm1, xmm15
000079fe5f5cf90e  jp 0x000079FE5F5CF91D
000079fe5f5cf910  movaps xmm12, [0x000079FE5F1FE030]
000079fe5f5cf918  jmp 0x000079FE5F5CF4C5
000079fe5f5cf91d  vxorps xmm0, xmm1, xmm15
000079fe5f5cf922  pextrw eax, xmm0, 0x03
000079fe5f5cf927  and eax, 0x7FF8
000079fe5f5cf92c  cmp eax, 0x08
000079fe5f5cf92f  jnz 0x000079FE5F5CF4C5
000079fe5f5cf935  movq rax, xmm15
000079fe5f5cf93a  shl rax, 0x0D
000079fe5f5cf93e  jbe 0x000079FE5F5CF4C5
000079fe5f5cf944  vorps xmm12, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf94c  jmp 0x000079FE5F5CF4C5
000079fe5f5cf951  ucomisd xmm1, xmm15
000079fe5f5cf956  jp 0x000079FE5F5CF965
000079fe5f5cf958  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cf960  jmp 0x000079FE5F5CF4F2
000079fe5f5cf965  vxorps xmm0, xmm1, xmm15
000079fe5f5cf96a  pextrw eax, xmm0, 0x03
000079fe5f5cf96f  and eax, 0x7FF8
000079fe5f5cf974  cmp eax, 0x08
000079fe5f5cf977  jnz 0x000079FE5F5CF4F2
000079fe5f5cf97d  movq rax, xmm15
000079fe5f5cf982  shl rax, 0x0D
000079fe5f5cf986  jbe 0x000079FE5F5CF4F2
000079fe5f5cf98c  vorps xmm13, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf994  jmp 0x000079FE5F5CF4F2
000079fe5f5cf999  ucomisd xmm1, xmm15
000079fe5f5cf99e  jp 0x000079FE5F5CF9AD
000079fe5f5cf9a0  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cf9a8  jmp 0x000079FE5F5CF527
000079fe5f5cf9ad  vxorps xmm0, xmm1, xmm15
000079fe5f5cf9b2  pextrw eax, xmm0, 0x03
000079fe5f5cf9b7  and eax, 0x7FF8
000079fe5f5cf9bc  cmp eax, 0x08
000079fe5f5cf9bf  jnz 0x000079FE5F5CF527
000079fe5f5cf9c5  movq rax, xmm15
000079fe5f5cf9ca  shl rax, 0x0D
000079fe5f5cf9ce  jbe 0x000079FE5F5CF527
000079fe5f5cf9d4  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cf9dc  jmp 0x000079FE5F5CF527
000079fe5f5cf9e1  call 0x000079FE5F40A4B0
000079fe5f5cf9e6  jmp 0x000079FE5F5CF539
000079fe5f5cf9eb  ucomisd xmm15, xmm14
000079fe5f5cf9f0  jp 0x000079FE5F5CF9FF
000079fe5f5cf9f2  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cf9fa  jmp 0x000079FE5F5CF566
000079fe5f5cf9ff  vxorps xmm0, xmm15, xmm14
000079fe5f5cfa04  pextrw eax, xmm0, 0x03
000079fe5f5cfa09  and eax, 0x7FF8
000079fe5f5cfa0e  cmp eax, 0x08
000079fe5f5cfa11  jnz 0x000079FE5F5CF566
000079fe5f5cfa17  movq rax, xmm14
000079fe5f5cfa1c  shl rax, 0x0D
000079fe5f5cfa20  jbe 0x000079FE5F5CF566
000079fe5f5cfa26  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cfa2e  jmp 0x000079FE5F5CF566
000079fe5f5cfa33  ucomisd xmm1, xmm15
000079fe5f5cfa38  jp 0x000079FE5F5CFA47
000079fe5f5cfa3a  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cfa42  jmp 0x000079FE5F5CF59B
000079fe5f5cfa47  vxorps xmm0, xmm1, xmm15
000079fe5f5cfa4c  pextrw eax, xmm0, 0x03
000079fe5f5cfa51  and eax, 0x7FF8
000079fe5f5cfa56  cmp eax, 0x08
000079fe5f5cfa59  jnz 0x000079FE5F5CF59B
000079fe5f5cfa5f  movq rax, xmm15
000079fe5f5cfa64  shl rax, 0x0D
000079fe5f5cfa68  jbe 0x000079FE5F5CF59B
000079fe5f5cfa6e  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cfa76  jmp 0x000079FE5F5CF59B
000079fe5f5cfa7b  call 0x000079FE5F40A4B0
000079fe5f5cfa80  jmp 0x000079FE5F5CF5AD
000079fe5f5cfa85  ucomisd xmm15, xmm14
000079fe5f5cfa8a  jp 0x000079FE5F5CFA99
000079fe5f5cfa8c  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cfa94  jmp 0x000079FE5F5CF5DA
000079fe5f5cfa99  vxorps xmm0, xmm15, xmm14
000079fe5f5cfa9e  pextrw eax, xmm0, 0x03
000079fe5f5cfaa3  and eax, 0x7FF8
000079fe5f5cfaa8  cmp eax, 0x08
000079fe5f5cfaab  jnz 0x000079FE5F5CF5DA
000079fe5f5cfab1  movq rax, xmm14
000079fe5f5cfab6  shl rax, 0x0D
000079fe5f5cfaba  jbe 0x000079FE5F5CF5DA
000079fe5f5cfac0  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cfac8  jmp 0x000079FE5F5CF5DA
000079fe5f5cfacd  ucomisd xmm1, xmm15
000079fe5f5cfad2  jp 0x000079FE5F5CFAE1
000079fe5f5cfad4  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cfadc  jmp 0x000079FE5F5CF60F
000079fe5f5cfae1  vxorps xmm0, xmm1, xmm15
000079fe5f5cfae6  pextrw eax, xmm0, 0x03
000079fe5f5cfaeb  and eax, 0x7FF8
000079fe5f5cfaf0  cmp eax, 0x08
000079fe5f5cfaf3  jnz 0x000079FE5F5CF60F
000079fe5f5cfaf9  movq rax, xmm15
000079fe5f5cfafe  shl rax, 0x0D
000079fe5f5cfb02  jbe 0x000079FE5F5CF60F
000079fe5f5cfb08  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cfb10  jmp 0x000079FE5F5CF60F
000079fe5f5cfb15  call 0x000079FE5F40A4B0
000079fe5f5cfb1a  jmp 0x000079FE5F5CF621
000079fe5f5cfb1f  ucomisd xmm15, xmm14
000079fe5f5cfb24  jp 0x000079FE5F5CFB33
000079fe5f5cfb26  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cfb2e  jmp 0x000079FE5F5CF64E
000079fe5f5cfb33  vxorps xmm0, xmm15, xmm14
000079fe5f5cfb38  pextrw eax, xmm0, 0x03
000079fe5f5cfb3d  and eax, 0x7FF8
000079fe5f5cfb42  cmp eax, 0x08
000079fe5f5cfb45  jnz 0x000079FE5F5CF64E
000079fe5f5cfb4b  movq rax, xmm14
000079fe5f5cfb50  shl rax, 0x0D
000079fe5f5cfb54  jbe 0x000079FE5F5CF64E
000079fe5f5cfb5a  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cfb62  jmp 0x000079FE5F5CF64E
000079fe5f5cfb67  ucomisd xmm1, xmm15
000079fe5f5cfb6c  jp 0x000079FE5F5CFB7B
000079fe5f5cfb6e  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cfb76  jmp 0x000079FE5F5CF683
000079fe5f5cfb7b  vxorps xmm0, xmm1, xmm15
000079fe5f5cfb80  pextrw eax, xmm0, 0x03
000079fe5f5cfb85  and eax, 0x7FF8
000079fe5f5cfb8a  cmp eax, 0x08
000079fe5f5cfb8d  jnz 0x000079FE5F5CF683
000079fe5f5cfb93  movq rax, xmm15
000079fe5f5cfb98  shl rax, 0x0D
000079fe5f5cfb9c  jbe 0x000079FE5F5CF683
000079fe5f5cfba2  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cfbaa  jmp 0x000079FE5F5CF683
000079fe5f5cfbaf  call 0x000079FE5F40A4B0
000079fe5f5cfbb4  jmp 0x000079FE5F5CF695
000079fe5f5cfbb9  ucomisd xmm15, xmm14
000079fe5f5cfbbe  jp 0x000079FE5F5CFBCD
000079fe5f5cfbc0  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cfbc8  jmp 0x000079FE5F5CF6C2
000079fe5f5cfbcd  vxorps xmm0, xmm15, xmm14
000079fe5f5cfbd2  pextrw eax, xmm0, 0x03
000079fe5f5cfbd7  and eax, 0x7FF8
000079fe5f5cfbdc  cmp eax, 0x08
000079fe5f5cfbdf  jnz 0x000079FE5F5CF6C2
000079fe5f5cfbe5  movq rax, xmm14
000079fe5f5cfbea  shl rax, 0x0D
000079fe5f5cfbee  jbe 0x000079FE5F5CF6C2
000079fe5f5cfbf4  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cfbfc  jmp 0x000079FE5F5CF6C2
000079fe5f5cfc01  ucomisd xmm1, xmm15
000079fe5f5cfc06  jp 0x000079FE5F5CFC15
000079fe5f5cfc08  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cfc10  jmp 0x000079FE5F5CF6F7
000079fe5f5cfc15  vxorps xmm0, xmm1, xmm15
000079fe5f5cfc1a  pextrw eax, xmm0, 0x03
000079fe5f5cfc1f  and eax, 0x7FF8
000079fe5f5cfc24  cmp eax, 0x08
000079fe5f5cfc27  jnz 0x000079FE5F5CF6F7
000079fe5f5cfc2d  movq rax, xmm15
000079fe5f5cfc32  shl rax, 0x0D
000079fe5f5cfc36  jbe 0x000079FE5F5CF6F7
000079fe5f5cfc3c  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cfc44  jmp 0x000079FE5F5CF6F7
000079fe5f5cfc49  call 0x000079FE5F40B720
000079fe5f5cfc4e  jmp 0x000079FE5F5CF709
000079fe5f5cfc53  ucomisd xmm15, xmm14
000079fe5f5cfc58  jp 0x000079FE5F5CFC67
000079fe5f5cfc5a  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5cfc62  jmp 0x000079FE5F5CF73E
000079fe5f5cfc67  vxorps xmm0, xmm15, xmm14
000079fe5f5cfc6c  pextrw eax, xmm0, 0x03
000079fe5f5cfc71  and eax, 0x7FF8
000079fe5f5cfc76  cmp eax, 0x08
000079fe5f5cfc79  jnz 0x000079FE5F5CF73E
000079fe5f5cfc7f  movq rax, xmm14
000079fe5f5cfc84  shl rax, 0x0D
000079fe5f5cfc88  jbe 0x000079FE5F5CF73E
000079fe5f5cfc8e  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5cfc96  jmp 0x000079FE5F5CF73E
000079fe5f5cfc9b  ucomisd xmm1, xmm15
000079fe5f5cfca0  jp 0x000079FE5F5CFCAF
000079fe5f5cfca2  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cfcaa  jmp 0x000079FE5F5CF773
000079fe5f5cfcaf  vxorps xmm0, xmm1, xmm15
000079fe5f5cfcb4  pextrw eax, xmm0, 0x03
000079fe5f5cfcb9  and eax, 0x7FF8
000079fe5f5cfcbe  cmp eax, 0x08
000079fe5f5cfcc1  jnz 0x000079FE5F5CF773
000079fe5f5cfcc7  movq rax, xmm15
000079fe5f5cfccc  shl rax, 0x0D
000079fe5f5cfcd0  jbe 0x000079FE5F5CF773
000079fe5f5cfcd6  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cfcde  jmp 0x000079FE5F5CF773
000079fe5f5cfce3  ucomisd xmm1, xmm15
000079fe5f5cfce8  jp 0x000079FE5F5CFCF7
000079fe5f5cfcea  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5cfcf2  jmp 0x000079FE5F5CF7A8
000079fe5f5cfcf7  vxorps xmm0, xmm1, xmm15
000079fe5f5cfcfc  pextrw eax, xmm0, 0x03
000079fe5f5cfd01  and eax, 0x7FF8
000079fe5f5cfd06  cmp eax, 0x08
000079fe5f5cfd09  jnz 0x000079FE5F5CF7A8
000079fe5f5cfd0f  movq rax, xmm15
000079fe5f5cfd14  shl rax, 0x0D
000079fe5f5cfd18  jbe 0x000079FE5F5CF7A8
000079fe5f5cfd1e  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5cfd26  jmp 0x000079FE5F5CF7A8
000079fe5f5cfd2b  call 0x000079FE5F4B4CB0
000079fe5f5cfd30  jmp 0x000079FE5F5CF7C7
000079fe5f5cfd35  int3
000079fe5f5cfd36  nop [rax+rax*1], ax
000079fe5f5cfd3f  nop
000079fe5f5cfd40  mov rax, [r15+0x60]
000079fe5f5cfd44  lea r14, [rax+0x01]
000079fe5f5cfd48  mov [r15+0x60], r14
000079fe5f5cfd4c  mov rax, [r15+0x68]
000079fe5f5cfd50  lea r12, [rax+0x40]
000079fe5f5cfd54  mov [r15+0x68], r12
000079fe5f5cfd58  xor eax, eax
000079fe5f5cfd5a  mov r12d, 0x08
000079fe5f5cfd60  cmp r14, r12
000079fe5f5cfd63  cmc
000079fe5f5cfd64  lahf
000079fe5f5cfd65  seto al
000079fe5f5cfd68  mov [r15+0x108], eax
000079fe5f5cfd6f  mov eax, [r15+0x108]
000079fe5f5cfd76  sahf
000079fe5f5cfd77  jnz 0x000079FE5F5CFDA9
000079fe5f5cfd79  cmp dword ptr [r15+0x318], 0x00
000079fe5f5cfd81  jz 0x000079FE5F5D08A0
000079fe5f5cfd87  nop [rax+rax*1], ax
000079fe5f5cfd90  nop [rax+rax*1], eax
000079fe5f5cfd98  mov eax, 0x410128
000079fe5f5cfd9d  mov [r15+0x100], rax
000079fe5f5cfda4  jmp 0x000079FE5F3FE110
000079fe5f5cfda9  cmp dword ptr [r15+0x318], 0x00
000079fe5f5cfdb1  jz 0x000079FE5F5CFDE0
000079fe5f5cfdb7  nop [rax+rax*1], ax
000079fe5f5cfdc0  nop [rax+rax*1], eax
000079fe5f5cfdc8  mov eax, 0x41008C
000079fe5f5cfdcd  mov [r15+0x100], rax
000079fe5f5cfdd4  jmp 0x000079FE5F3FE110
000079fe5f5cfdd9  int3
000079fe5f5cfdda  int3
000079fe5f5cfddb  nop [rax+rax*1], eax
000079fe5f5cfde0  mov rax, [r15+0x40]
000079fe5f5cfde4  mov r14, [r15+0x60]
000079fe5f5cfde8  shl r14, 0x06
000079fe5f5cfdec  lea r12, [rax+r14*1]
000079fe5f5cfdf0  mov rax, [r13+r12*1]
000079fe5f5cfdf5  lea r14, [r12+0x08]
000079fe5f5cfdfa  mov r11, [r13+r14*1]
000079fe5f5cfdff  movq xmm1, rax
000079fe5f5cfe04  movq xmm15, r11
000079fe5f5cfe09  movq xmm1, xmm1
000079fe5f5cfe0d  movq xmm1, xmm1
000079fe5f5cfe11  movaps [r15+0x120], xmm1
000079fe5f5cfe19  movq xmm15, xmm15
000079fe5f5cfe1e  movq xmm15, xmm15
000079fe5f5cfe23  movaps [r15+0x130], xmm15
000079fe5f5cfe2b  lea rax, [r12+0x10]
000079fe5f5cfe30  mov r14, [r13+rax*1]
000079fe5f5cfe35  lea rax, [r12+0x18]
000079fe5f5cfe3a  mov r11, [r13+rax*1]
000079fe5f5cfe3f  movq xmm1, r14
000079fe5f5cfe44  movq xmm15, r11
000079fe5f5cfe49  movq xmm1, xmm1
000079fe5f5cfe4d  movq xmm1, xmm1
000079fe5f5cfe51  movaps [r15+0x140], xmm1
000079fe5f5cfe59  movq xmm15, xmm15
000079fe5f5cfe5e  movq xmm15, xmm15
000079fe5f5cfe63  movaps [r15+0x150], xmm15
000079fe5f5cfe6b  lea rax, [r12+0x20]
000079fe5f5cfe70  mov r14, [r13+rax*1]
000079fe5f5cfe75  lea rax, [r12+0x28]
000079fe5f5cfe7a  mov r11, [r13+rax*1]
000079fe5f5cfe7f  movq xmm1, r14
000079fe5f5cfe84  movq xmm15, r11
000079fe5f5cfe89  movq xmm1, xmm1
000079fe5f5cfe8d  movq xmm1, xmm1
000079fe5f5cfe91  movaps [r15+0x160], xmm1
000079fe5f5cfe99  movq xmm15, xmm15
000079fe5f5cfe9e  movq xmm15, xmm15
000079fe5f5cfea3  movaps [r15+0x170], xmm15
000079fe5f5cfeab  lea rax, [r12+0x30]
000079fe5f5cfeb0  mov r14, [r13+rax*1]
000079fe5f5cfeb5  lea rax, [r12+0x38]
000079fe5f5cfeba  mov r12, [r13+rax*1]
000079fe5f5cfebf  movq xmm1, r14
000079fe5f5cfec4  movq xmm15, r12
000079fe5f5cfec9  movq xmm1, xmm1
000079fe5f5cfecd  movq xmm1, xmm1
000079fe5f5cfed1  movaps [r15+0x180], xmm1
000079fe5f5cfed9  movq xmm15, xmm15
000079fe5f5cfede  movq xmm15, xmm15
000079fe5f5cfee3  movaps [r15+0x210], xmm15
000079fe5f5cfeeb  mov rax, [r15+0x48]
000079fe5f5cfeef  mov [r15+0x78], rax
000079fe5f5cfef3  mov r14, [r13+rax*1]
000079fe5f5cfef8  movq xmm1, r14
000079fe5f5cfefd  lea r14, [rax+0x40]
000079fe5f5cff01  mov r12, [r13+r14*1]
000079fe5f5cff06  movq xmm15, r12
000079fe5f5cff0b  lea r14, [rax+0x80]
000079fe5f5cff12  mov r12, [r13+r14*1]
000079fe5f5cff17  movq xmm14, r12
000079fe5f5cff1c  movaps xmm13, [r15+0x120]
000079fe5f5cff24  movq r14, xmm13
000079fe5f5cff29  movq r12, xmm1
000079fe5f5cff2e  vmovq xmm1, r14
000079fe5f5cff33  vmovq xmm13, r12
000079fe5f5cff38  movaps xmm12, xmm1
000079fe5f5cff3c  mulsd xmm12, xmm13
000079fe5f5cff41  ucomisd xmm12, xmm12
000079fe5f5cff46  jp 0x000079FE5F5D03AD
000079fe5f5cff4c  movq xmm12, xmm12
000079fe5f5cff51  movaps xmm1, [r15+0x130]
000079fe5f5cff59  movq r14, xmm1
000079fe5f5cff5e  movq r12, xmm15
000079fe5f5cff63  vmovq xmm1, r14
000079fe5f5cff68  vmovq xmm15, r12
000079fe5f5cff6d  movaps xmm13, xmm1
000079fe5f5cff71  mulsd xmm13, xmm15
000079fe5f5cff76  ucomisd xmm13, xmm13
000079fe5f5cff7b  jp 0x000079FE5F5D03F9
000079fe5f5cff81  movq xmm13, xmm13
000079fe5f5cff86  movq r14, xmm12
000079fe5f5cff8b  movaps xmm1, [r15+0x110]
000079fe5f5cff93  movq r12, xmm1
000079fe5f5cff98  vmovq xmm1, r14
000079fe5f5cff9d  vmovq xmm15, r12
000079fe5f5cffa2  movaps xmm12, xmm1
000079fe5f5cffa6  addsd xmm12, xmm15
000079fe5f5cffab  ucomisd xmm12, xmm12
000079fe5f5cffb0  jp 0x000079FE5F5D0445
000079fe5f5cffb6  movq xmm12, xmm12
000079fe5f5cffbb  movq r14, xmm12
000079fe5f5cffc0  movq r12, xmm13
000079fe5f5cffc5  vmovq xmm1, r14
000079fe5f5cffca  vmovq xmm15, r12
000079fe5f5cffcf  movaps xmm13, xmm1
000079fe5f5cffd3  addsd xmm13, xmm15
000079fe5f5cffd8  ucomisd xmm13, xmm13
000079fe5f5cffdd  jp 0x000079FE5F5D0491
000079fe5f5cffe3  movq xmm13, xmm13
000079fe5f5cffe8  movaps xmm1, [r15+0x140]
000079fe5f5cfff0  movq r14, xmm1
000079fe5f5cfff5  movq r12, xmm14
000079fe5f5cfffa  vmovq xmm1, r14
000079fe5f5cffff  vmovq xmm15, r12
000079fe5f5d0004  movaps xmm14, xmm1
000079fe5f5d0008  mulsd xmm14, xmm15
000079fe5f5d000d  ucomisd xmm14, xmm14
000079fe5f5d0012  jp 0x000079FE5F5D04DD
000079fe5f5d0018  movq xmm14, xmm14
000079fe5f5d001d  lea r14, [rax+0xC0]
000079fe5f5d0024  mov r12, [r13+r14*1]
000079fe5f5d0029  movq xmm1, r12
000079fe5f5d002e  movq r14, xmm13
000079fe5f5d0033  movq r12, xmm14
000079fe5f5d0038  vmovq xmm15, r14
000079fe5f5d003d  vmovq xmm14, r12
000079fe5f5d0042  movaps xmm13, xmm15
000079fe5f5d0046  addsd xmm13, xmm14
000079fe5f5d004b  ucomisd xmm13, xmm13
000079fe5f5d0050  jp 0x000079FE5F5D0533
000079fe5f5d0056  movq xmm13, xmm13
000079fe5f5d005b  movaps xmm15, [r15+0x150]
000079fe5f5d0063  movq r14, xmm15
000079fe5f5d0068  movq r12, xmm1
000079fe5f5d006d  vmovq xmm1, r14
000079fe5f5d0072  vmovq xmm15, r12
000079fe5f5d0077  movaps xmm14, xmm1
000079fe5f5d007b  mulsd xmm14, xmm15
000079fe5f5d0080  ucomisd xmm14, xmm14
000079fe5f5d0085  jp 0x000079FE5F5D057F
000079fe5f5d008b  movq xmm14, xmm14
000079fe5f5d0090  lea r14, [rax+0x100]
000079fe5f5d0097  mov r12, [r13+r14*1]
000079fe5f5d009c  movq xmm1, r12
000079fe5f5d00a1  movq r14, xmm13
000079fe5f5d00a6  movq r12, xmm14
000079fe5f5d00ab  vmovq xmm15, r14
000079fe5f5d00b0  vmovq xmm14, r12
000079fe5f5d00b5  movaps xmm13, xmm15
000079fe5f5d00b9  addsd xmm13, xmm14
000079fe5f5d00be  ucomisd xmm13, xmm13
000079fe5f5d00c3  jp 0x000079FE5F5D05D5
000079fe5f5d00c9  movq xmm13, xmm13
000079fe5f5d00ce  movaps xmm15, [r15+0x160]
000079fe5f5d00d6  movq r14, xmm15
000079fe5f5d00db  movq r12, xmm1
000079fe5f5d00e0  vmovq xmm1, r14
000079fe5f5d00e5  vmovq xmm15, r12
000079fe5f5d00ea  movaps xmm14, xmm1
000079fe5f5d00ee  mulsd xmm14, xmm15
000079fe5f5d00f3  ucomisd xmm14, xmm14
000079fe5f5d00f8  jp 0x000079FE5F5D0621
000079fe5f5d00fe  movq xmm14, xmm14
000079fe5f5d0103  lea r14, [rax+0x140]
000079fe5f5d010a  mov r12, [r13+r14*1]
000079fe5f5d010f  movq xmm1, r12
000079fe5f5d0114  movq r14, xmm13
000079fe5f5d0119  movq r12, xmm14
000079fe5f5d011e  vmovq xmm15, r14
000079fe5f5d0123  vmovq xmm14, r12
000079fe5f5d0128  movaps xmm13, xmm15
000079fe5f5d012c  addsd xmm13, xmm14
000079fe5f5d0131  ucomisd xmm13, xmm13
000079fe5f5d0136  jp 0x000079FE5F5D0677
000079fe5f5d013c  movq xmm13, xmm13
000079fe5f5d0141  movaps xmm15, [r15+0x170]
000079fe5f5d0149  movq r14, xmm15
000079fe5f5d014e  movq r12, xmm1
000079fe5f5d0153  vmovq xmm1, r14
000079fe5f5d0158  vmovq xmm15, r12
000079fe5f5d015d  movaps xmm14, xmm1
000079fe5f5d0161  mulsd xmm14, xmm15
000079fe5f5d0166  ucomisd xmm14, xmm14
000079fe5f5d016b  jp 0x000079FE5F5D06C3
000079fe5f5d0171  movq xmm14, xmm14
000079fe5f5d0176  lea r14, [rax+0x180]
000079fe5f5d017d  mov r12, [r13+r14*1]
000079fe5f5d0182  movq xmm1, r12
000079fe5f5d0187  movq r14, xmm13
000079fe5f5d018c  movq r12, xmm14
000079fe5f5d0191  vmovq xmm15, r14
000079fe5f5d0196  vmovq xmm14, r12
000079fe5f5d019b  movaps xmm13, xmm15
000079fe5f5d019f  addsd xmm13, xmm14
000079fe5f5d01a4  ucomisd xmm13, xmm13
000079fe5f5d01a9  jp 0x000079FE5F5D0719
000079fe5f5d01af  movq xmm13, xmm13
000079fe5f5d01b4  movaps xmm15, [r15+0x180]
000079fe5f5d01bc  movq r14, xmm15
000079fe5f5d01c1  movq r12, xmm1
000079fe5f5d01c6  vmovq xmm1, r14
000079fe5f5d01cb  vmovq xmm15, r12
000079fe5f5d01d0  movaps xmm14, xmm1
000079fe5f5d01d4  mulsd xmm14, xmm15
000079fe5f5d01d9  ucomisd xmm14, xmm14
000079fe5f5d01de  jp 0x000079FE5F5D0765
000079fe5f5d01e4  movq xmm14, xmm14
000079fe5f5d01e9  lea r14, [rax+0x1C0]
000079fe5f5d01f0  mov rax, [r13+r14*1]
000079fe5f5d01f5  movq xmm1, rax
000079fe5f5d01fa  movaps [r15+0x240], xmm1
000079fe5f5d0202  movq rax, xmm13
000079fe5f5d0207  movq r14, xmm14
000079fe5f5d020c  vmovq xmm15, rax
000079fe5f5d0211  vmovq xmm14, r14
000079fe5f5d0216  movaps xmm13, xmm15
000079fe5f5d021a  addsd xmm13, xmm14
000079fe5f5d021f  ucomisd xmm13, xmm13
000079fe5f5d0224  jp 0x000079FE5F5D07BB
000079fe5f5d022a  movq xmm13, xmm13
000079fe5f5d022f  movaps xmm15, [r15+0x210]
000079fe5f5d0237  movq rax, xmm15
000079fe5f5d023c  movq r14, xmm1
000079fe5f5d0241  vmovq xmm1, rax
000079fe5f5d0246  vmovq xmm15, r14
000079fe5f5d024b  movaps xmm14, xmm1
000079fe5f5d024f  mulsd xmm14, xmm15
000079fe5f5d0254  ucomisd xmm14, xmm14
000079fe5f5d0259  jp 0x000079FE5F5D0803
000079fe5f5d025f  movq xmm14, xmm14
000079fe5f5d0264  movaps [r15+0x230], xmm14
000079fe5f5d026c  movq rax, xmm13
000079fe5f5d0271  movq r14, xmm14
000079fe5f5d0276  vmovq xmm1, rax
000079fe5f5d027b  vmovq xmm15, r14
000079fe5f5d0280  movaps xmm14, xmm1
000079fe5f5d0284  addsd xmm14, xmm15
000079fe5f5d0289  ucomisd xmm14, xmm14
000079fe5f5d028e  jp 0x000079FE5F5D084B
000079fe5f5d0294  movq xmm14, xmm14
000079fe5f5d0299  movaps [r15+0x220], xmm14
000079fe5f5d02a1  mov rax, [r15+0x68]
000079fe5f5d02a5  movq r14, xmm14
000079fe5f5d02aa  mov [r13+rax*1], r14
000079fe5f5d02af  mov qword ptr [r15+0x70], 0x08
000079fe5f5d02b7  xor eax, eax
000079fe5f5d02b9  mov r14d, 0x08
000079fe5f5d02bf  mov r12d, 0x40
000079fe5f5d02c5  cmp r14, r12
000079fe5f5d02c8  cmc
000079fe5f5d02c9  lahf
000079fe5f5d02ca  seto al
000079fe5f5d02cd  mov [r15+0x108], eax
000079fe5f5d02d4  mov eax, [r15+0x108]
000079fe5f5d02db  sahf
000079fe5f5d02dc  jnz 0x000079FE5F5D030E
000079fe5f5d02de  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d02e6  jz 0x000079FE5F5CFD40
000079fe5f5d02ec  nop [rax+rax*1], ax
000079fe5f5d02f5  nop [rax+rax*1], eax
000079fe5f5d02fd  mov eax, 0x410118
000079fe5f5d0302  mov [r15+0x100], rax
000079fe5f5d0309  jmp 0x000079FE5F3FE110
000079fe5f5d030e  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d0316  jz 0x000079FE5F5CF3F0
000079fe5f5d031c  nop [rax+rax*1], ax
000079fe5f5d0325  nop [rax+rax*1], eax
000079fe5f5d032d  mov eax, 0x4100A4
000079fe5f5d0332  mov [r15+0x100], rax
000079fe5f5d0339  jmp 0x000079FE5F3FE110
000079fe5f5d033e  int3
000079fe5f5d033f  call 0x000079FE5F4B47C0
000079fe5f5d0344  jmp 0x000079FE5F5CFDF5
000079fe5f5d0349  call 0x000079FE5F4E1570
000079fe5f5d034e  jmp 0x000079FE5F5CFDFF
000079fe5f5d0353  call 0x000079FE5F40DC20
000079fe5f5d0358  jmp 0x000079FE5F5CFE35
000079fe5f5d035d  call 0x000079FE5F40A4B0
000079fe5f5d0362  jmp 0x000079FE5F5CFE3F
000079fe5f5d0367  call 0x000079FE5F40DC20
000079fe5f5d036c  jmp 0x000079FE5F5CFE75
000079fe5f5d0371  call 0x000079FE5F40A4B0
000079fe5f5d0376  jmp 0x000079FE5F5CFE7F
000079fe5f5d037b  call 0x000079FE5F40DC20
000079fe5f5d0380  jmp 0x000079FE5F5CFEB5
000079fe5f5d0385  call 0x000079FE5F40B720
000079fe5f5d038a  jmp 0x000079FE5F5CFEBF
000079fe5f5d038f  call 0x000079FE5F40DC20
000079fe5f5d0394  jmp 0x000079FE5F5CFEF8
000079fe5f5d0399  call 0x000079FE5F4E27E0
000079fe5f5d039e  jmp 0x000079FE5F5CFF06
000079fe5f5d03a3  call 0x000079FE5F4E27E0
000079fe5f5d03a8  jmp 0x000079FE5F5CFF17
000079fe5f5d03ad  ucomisd xmm1, xmm13
000079fe5f5d03b2  jp 0x000079FE5F5D03C1
000079fe5f5d03b4  movaps xmm12, [0x000079FE5F1FE030]
000079fe5f5d03bc  jmp 0x000079FE5F5CFF4C
000079fe5f5d03c1  vxorps xmm0, xmm1, xmm13
000079fe5f5d03c6  pextrw r14d, xmm0, 0x03
000079fe5f5d03cc  and r14d, 0x7FF8
000079fe5f5d03d3  cmp r14d, 0x08
000079fe5f5d03d7  jnz 0x000079FE5F5CFF4C
000079fe5f5d03dd  movq r14, xmm13
000079fe5f5d03e2  shl r14, 0x0D
000079fe5f5d03e6  jbe 0x000079FE5F5CFF4C
000079fe5f5d03ec  vorps xmm12, xmm13, [0x000079FE5F1FE040]
000079fe5f5d03f4  jmp 0x000079FE5F5CFF4C
000079fe5f5d03f9  ucomisd xmm1, xmm15
000079fe5f5d03fe  jp 0x000079FE5F5D040D
000079fe5f5d0400  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d0408  jmp 0x000079FE5F5CFF81
000079fe5f5d040d  vxorps xmm0, xmm1, xmm15
000079fe5f5d0412  pextrw r14d, xmm0, 0x03
000079fe5f5d0418  and r14d, 0x7FF8
000079fe5f5d041f  cmp r14d, 0x08
000079fe5f5d0423  jnz 0x000079FE5F5CFF81
000079fe5f5d0429  movq r14, xmm15
000079fe5f5d042e  shl r14, 0x0D
000079fe5f5d0432  jbe 0x000079FE5F5CFF81
000079fe5f5d0438  vorps xmm13, xmm15, [0x000079FE5F1FE040]
000079fe5f5d0440  jmp 0x000079FE5F5CFF81
000079fe5f5d0445  ucomisd xmm1, xmm15
000079fe5f5d044a  jp 0x000079FE5F5D0459
000079fe5f5d044c  movaps xmm12, [0x000079FE5F1FE030]
000079fe5f5d0454  jmp 0x000079FE5F5CFFB6
000079fe5f5d0459  vxorps xmm0, xmm1, xmm15
000079fe5f5d045e  pextrw r14d, xmm0, 0x03
000079fe5f5d0464  and r14d, 0x7FF8
000079fe5f5d046b  cmp r14d, 0x08
000079fe5f5d046f  jnz 0x000079FE5F5CFFB6
000079fe5f5d0475  movq r14, xmm15
000079fe5f5d047a  shl r14, 0x0D
000079fe5f5d047e  jbe 0x000079FE5F5CFFB6
000079fe5f5d0484  vorps xmm12, xmm15, [0x000079FE5F1FE040]
000079fe5f5d048c  jmp 0x000079FE5F5CFFB6
000079fe5f5d0491  ucomisd xmm1, xmm15
000079fe5f5d0496  jp 0x000079FE5F5D04A5
000079fe5f5d0498  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d04a0  jmp 0x000079FE5F5CFFE3
000079fe5f5d04a5  vxorps xmm0, xmm1, xmm15
000079fe5f5d04aa  pextrw r14d, xmm0, 0x03
000079fe5f5d04b0  and r14d, 0x7FF8
000079fe5f5d04b7  cmp r14d, 0x08
000079fe5f5d04bb  jnz 0x000079FE5F5CFFE3
000079fe5f5d04c1  movq r14, xmm15
000079fe5f5d04c6  shl r14, 0x0D
000079fe5f5d04ca  jbe 0x000079FE5F5CFFE3
000079fe5f5d04d0  vorps xmm13, xmm15, [0x000079FE5F1FE040]
000079fe5f5d04d8  jmp 0x000079FE5F5CFFE3
000079fe5f5d04dd  ucomisd xmm1, xmm15
000079fe5f5d04e2  jp 0x000079FE5F5D04F1
000079fe5f5d04e4  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d04ec  jmp 0x000079FE5F5D0018
000079fe5f5d04f1  vxorps xmm0, xmm1, xmm15
000079fe5f5d04f6  pextrw r14d, xmm0, 0x03
000079fe5f5d04fc  and r14d, 0x7FF8
000079fe5f5d0503  cmp r14d, 0x08
000079fe5f5d0507  jnz 0x000079FE5F5D0018
000079fe5f5d050d  movq r14, xmm15
000079fe5f5d0512  shl r14, 0x0D
000079fe5f5d0516  jbe 0x000079FE5F5D0018
000079fe5f5d051c  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d0524  jmp 0x000079FE5F5D0018
000079fe5f5d0529  call 0x000079FE5F4E27E0
000079fe5f5d052e  jmp 0x000079FE5F5D0029
000079fe5f5d0533  ucomisd xmm15, xmm14
000079fe5f5d0538  jp 0x000079FE5F5D0547
000079fe5f5d053a  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d0542  jmp 0x000079FE5F5D0056
000079fe5f5d0547  vxorps xmm0, xmm15, xmm14
000079fe5f5d054c  pextrw r14d, xmm0, 0x03
000079fe5f5d0552  and r14d, 0x7FF8
000079fe5f5d0559  cmp r14d, 0x08
000079fe5f5d055d  jnz 0x000079FE5F5D0056
000079fe5f5d0563  movq r14, xmm14
000079fe5f5d0568  shl r14, 0x0D
000079fe5f5d056c  jbe 0x000079FE5F5D0056
000079fe5f5d0572  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d057a  jmp 0x000079FE5F5D0056
000079fe5f5d057f  ucomisd xmm1, xmm15
000079fe5f5d0584  jp 0x000079FE5F5D0593
000079fe5f5d0586  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d058e  jmp 0x000079FE5F5D008B
000079fe5f5d0593  vxorps xmm0, xmm1, xmm15
000079fe5f5d0598  pextrw r14d, xmm0, 0x03
000079fe5f5d059e  and r14d, 0x7FF8
000079fe5f5d05a5  cmp r14d, 0x08
000079fe5f5d05a9  jnz 0x000079FE5F5D008B
000079fe5f5d05af  movq r14, xmm15
000079fe5f5d05b4  shl r14, 0x0D
000079fe5f5d05b8  jbe 0x000079FE5F5D008B
000079fe5f5d05be  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d05c6  jmp 0x000079FE5F5D008B
000079fe5f5d05cb  call 0x000079FE5F4E27E0
000079fe5f5d05d0  jmp 0x000079FE5F5D009C
000079fe5f5d05d5  ucomisd xmm15, xmm14
000079fe5f5d05da  jp 0x000079FE5F5D05E9
000079fe5f5d05dc  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d05e4  jmp 0x000079FE5F5D00C9
000079fe5f5d05e9  vxorps xmm0, xmm15, xmm14
000079fe5f5d05ee  pextrw r14d, xmm0, 0x03
000079fe5f5d05f4  and r14d, 0x7FF8
000079fe5f5d05fb  cmp r14d, 0x08
000079fe5f5d05ff  jnz 0x000079FE5F5D00C9
000079fe5f5d0605  movq r14, xmm14
000079fe5f5d060a  shl r14, 0x0D
000079fe5f5d060e  jbe 0x000079FE5F5D00C9
000079fe5f5d0614  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d061c  jmp 0x000079FE5F5D00C9
000079fe5f5d0621  ucomisd xmm1, xmm15
000079fe5f5d0626  jp 0x000079FE5F5D0635
000079fe5f5d0628  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d0630  jmp 0x000079FE5F5D00FE
000079fe5f5d0635  vxorps xmm0, xmm1, xmm15
000079fe5f5d063a  pextrw r14d, xmm0, 0x03
000079fe5f5d0640  and r14d, 0x7FF8
000079fe5f5d0647  cmp r14d, 0x08
000079fe5f5d064b  jnz 0x000079FE5F5D00FE
000079fe5f5d0651  movq r14, xmm15
000079fe5f5d0656  shl r14, 0x0D
000079fe5f5d065a  jbe 0x000079FE5F5D00FE
000079fe5f5d0660  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d0668  jmp 0x000079FE5F5D00FE
000079fe5f5d066d  call 0x000079FE5F4E27E0
000079fe5f5d0672  jmp 0x000079FE5F5D010F
000079fe5f5d0677  ucomisd xmm15, xmm14
000079fe5f5d067c  jp 0x000079FE5F5D068B
000079fe5f5d067e  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d0686  jmp 0x000079FE5F5D013C
000079fe5f5d068b  vxorps xmm0, xmm15, xmm14
000079fe5f5d0690  pextrw r14d, xmm0, 0x03
000079fe5f5d0696  and r14d, 0x7FF8
000079fe5f5d069d  cmp r14d, 0x08
000079fe5f5d06a1  jnz 0x000079FE5F5D013C
000079fe5f5d06a7  movq r14, xmm14
000079fe5f5d06ac  shl r14, 0x0D
000079fe5f5d06b0  jbe 0x000079FE5F5D013C
000079fe5f5d06b6  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d06be  jmp 0x000079FE5F5D013C
000079fe5f5d06c3  ucomisd xmm1, xmm15
000079fe5f5d06c8  jp 0x000079FE5F5D06D7
000079fe5f5d06ca  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d06d2  jmp 0x000079FE5F5D0171
000079fe5f5d06d7  vxorps xmm0, xmm1, xmm15
000079fe5f5d06dc  pextrw r14d, xmm0, 0x03
000079fe5f5d06e2  and r14d, 0x7FF8
000079fe5f5d06e9  cmp r14d, 0x08
000079fe5f5d06ed  jnz 0x000079FE5F5D0171
000079fe5f5d06f3  movq r14, xmm15
000079fe5f5d06f8  shl r14, 0x0D
000079fe5f5d06fc  jbe 0x000079FE5F5D0171
000079fe5f5d0702  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d070a  jmp 0x000079FE5F5D0171
000079fe5f5d070f  call 0x000079FE5F4E27E0
000079fe5f5d0714  jmp 0x000079FE5F5D0182
000079fe5f5d0719  ucomisd xmm15, xmm14
000079fe5f5d071e  jp 0x000079FE5F5D072D
000079fe5f5d0720  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d0728  jmp 0x000079FE5F5D01AF
000079fe5f5d072d  vxorps xmm0, xmm15, xmm14
000079fe5f5d0732  pextrw r14d, xmm0, 0x03
000079fe5f5d0738  and r14d, 0x7FF8
000079fe5f5d073f  cmp r14d, 0x08
000079fe5f5d0743  jnz 0x000079FE5F5D01AF
000079fe5f5d0749  movq r14, xmm14
000079fe5f5d074e  shl r14, 0x0D
000079fe5f5d0752  jbe 0x000079FE5F5D01AF
000079fe5f5d0758  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d0760  jmp 0x000079FE5F5D01AF
000079fe5f5d0765  ucomisd xmm1, xmm15
000079fe5f5d076a  jp 0x000079FE5F5D0779
000079fe5f5d076c  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d0774  jmp 0x000079FE5F5D01E4
000079fe5f5d0779  vxorps xmm0, xmm1, xmm15
000079fe5f5d077e  pextrw r14d, xmm0, 0x03
000079fe5f5d0784  and r14d, 0x7FF8
000079fe5f5d078b  cmp r14d, 0x08
000079fe5f5d078f  jnz 0x000079FE5F5D01E4
000079fe5f5d0795  movq r14, xmm15
000079fe5f5d079a  shl r14, 0x0D
000079fe5f5d079e  jbe 0x000079FE5F5D01E4
000079fe5f5d07a4  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d07ac  jmp 0x000079FE5F5D01E4
000079fe5f5d07b1  call 0x000079FE5F4D59C0
000079fe5f5d07b6  jmp 0x000079FE5F5D01F5
000079fe5f5d07bb  ucomisd xmm15, xmm14
000079fe5f5d07c0  jp 0x000079FE5F5D07CF
000079fe5f5d07c2  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d07ca  jmp 0x000079FE5F5D022A
000079fe5f5d07cf  vxorps xmm0, xmm15, xmm14
000079fe5f5d07d4  pextrw eax, xmm0, 0x03
000079fe5f5d07d9  and eax, 0x7FF8
000079fe5f5d07de  cmp eax, 0x08
000079fe5f5d07e1  jnz 0x000079FE5F5D022A
000079fe5f5d07e7  movq rax, xmm14
000079fe5f5d07ec  shl rax, 0x0D
000079fe5f5d07f0  jbe 0x000079FE5F5D022A
000079fe5f5d07f6  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d07fe  jmp 0x000079FE5F5D022A
000079fe5f5d0803  ucomisd xmm1, xmm15
000079fe5f5d0808  jp 0x000079FE5F5D0817
000079fe5f5d080a  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d0812  jmp 0x000079FE5F5D025F
000079fe5f5d0817  vxorps xmm0, xmm1, xmm15
000079fe5f5d081c  pextrw eax, xmm0, 0x03
000079fe5f5d0821  and eax, 0x7FF8
000079fe5f5d0826  cmp eax, 0x08
000079fe5f5d0829  jnz 0x000079FE5F5D025F
000079fe5f5d082f  movq rax, xmm15
000079fe5f5d0834  shl rax, 0x0D
000079fe5f5d0838  jbe 0x000079FE5F5D025F
000079fe5f5d083e  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d0846  jmp 0x000079FE5F5D025F
000079fe5f5d084b  ucomisd xmm1, xmm15
000079fe5f5d0850  jp 0x000079FE5F5D085F
000079fe5f5d0852  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d085a  jmp 0x000079FE5F5D0294
000079fe5f5d085f  vxorps xmm0, xmm1, xmm15
000079fe5f5d0864  pextrw eax, xmm0, 0x03
000079fe5f5d0869  and eax, 0x7FF8
000079fe5f5d086e  cmp eax, 0x08
000079fe5f5d0871  jnz 0x000079FE5F5D0294
000079fe5f5d0877  movq rax, xmm15
000079fe5f5d087c  shl rax, 0x0D
000079fe5f5d0880  jbe 0x000079FE5F5D0294
000079fe5f5d0886  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d088e  jmp 0x000079FE5F5D0294
000079fe5f5d0893  call 0x000079FE5F40E120
000079fe5f5d0898  jmp 0x000079FE5F5D02AF
000079fe5f5d089d  int3
000079fe5f5d089e  nop
000079fe5f5d08a0  mov eax, [r15+0x58]
000079fe5f5d08a4  lea r14d, [eax+0x01]
000079fe5f5d08a9  mov [rsp+0x10], r14d
000079fe5f5d08ae  mov r14d, r14d
000079fe5f5d08b1  mov [r15+0x58], r14
000079fe5f5d08b5  xor eax, eax
000079fe5f5d08b7  mov r14d, [rsp+0x10]
000079fe5f5d08bc  cmp r14d, 0x1F4
000079fe5f5d08c3  cmc
000079fe5f5d08c4  lahf
000079fe5f5d08c5  seto al
000079fe5f5d08c8  mov [r15+0x108], eax
000079fe5f5d08cf  mov eax, [r15+0x108]
000079fe5f5d08d6  sahf
000079fe5f5d08d7  jnz 0x000079FE5F5D0909
000079fe5f5d08d9  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d08e1  jz 0x000079FE5F5D1410
000079fe5f5d08e7  nop [rax+rax*1], ax
000079fe5f5d08f0  nop [rax+rax*1], eax
000079fe5f5d08f8  mov eax, 0x410134
000079fe5f5d08fd  mov [r15+0x100], rax
000079fe5f5d0904  jmp 0x000079FE5F3FE110
000079fe5f5d0909  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d0911  jz 0x000079FE5F5D0940
000079fe5f5d0917  nop [rax+rax*1], ax
000079fe5f5d0920  nop [rax+rax*1], eax
000079fe5f5d0928  mov eax, 0x410084
000079fe5f5d092d  mov [r15+0x100], rax
000079fe5f5d0934  jmp 0x000079FE5F3FE110
000079fe5f5d0939  int3
000079fe5f5d093a  int3
000079fe5f5d093b  nop [rax+rax*1], eax
000079fe5f5d0940  mov qword ptr [r15+0x60], 0x00
000079fe5f5d0948  mov rax, [r15+0x50]
000079fe5f5d094c  mov [r15+0x68], rax
000079fe5f5d0950  mov r14, [r15+0x40]
000079fe5f5d0954  mov r12, [r13+r14*1]
000079fe5f5d0959  lea r11, [r14+0x08]
000079fe5f5d095d  mov r10, [r13+r11*1]
000079fe5f5d0962  movq xmm1, r12
000079fe5f5d0967  movq xmm15, r10
000079fe5f5d096c  movq xmm1, xmm1
000079fe5f5d0970  movq xmm1, xmm1
000079fe5f5d0974  movaps [r15+0x120], xmm1
000079fe5f5d097c  movq xmm15, xmm15
000079fe5f5d0981  movq xmm15, xmm15
000079fe5f5d0986  movaps [r15+0x130], xmm15
000079fe5f5d098e  lea r12, [r14+0x10]
000079fe5f5d0992  mov r11, [r13+r12*1]
000079fe5f5d0997  lea r12, [r14+0x18]
000079fe5f5d099b  mov r10, [r13+r12*1]
000079fe5f5d09a0  movq xmm1, r11
000079fe5f5d09a5  movq xmm15, r10
000079fe5f5d09aa  movq xmm1, xmm1
000079fe5f5d09ae  movq xmm1, xmm1
000079fe5f5d09b2  movaps [r15+0x140], xmm1
000079fe5f5d09ba  movq xmm15, xmm15
000079fe5f5d09bf  movq xmm15, xmm15
000079fe5f5d09c4  movaps [r15+0x150], xmm15
000079fe5f5d09cc  lea r12, [r14+0x20]
000079fe5f5d09d0  mov r11, [r13+r12*1]
000079fe5f5d09d5  lea r12, [r14+0x28]
000079fe5f5d09d9  mov r10, [r13+r12*1]
000079fe5f5d09de  movq xmm1, r11
000079fe5f5d09e3  movq xmm15, r10
000079fe5f5d09e8  movq xmm1, xmm1
000079fe5f5d09ec  movq xmm1, xmm1
000079fe5f5d09f0  movaps [r15+0x160], xmm1
000079fe5f5d09f8  movq xmm15, xmm15
000079fe5f5d09fd  movq xmm15, xmm15
000079fe5f5d0a02  movaps [r15+0x170], xmm15
000079fe5f5d0a0a  lea r12, [r14+0x30]
000079fe5f5d0a0e  mov r11, [r13+r12*1]
000079fe5f5d0a13  lea r12, [r14+0x38]
000079fe5f5d0a17  mov r14, [r13+r12*1]
000079fe5f5d0a1c  movq xmm1, r11
000079fe5f5d0a21  movq xmm15, r14
000079fe5f5d0a26  movq xmm1, xmm1
000079fe5f5d0a2a  movq xmm1, xmm1
000079fe5f5d0a2e  movaps [r15+0x180], xmm1
000079fe5f5d0a36  movq xmm15, xmm15
000079fe5f5d0a3b  movq xmm15, xmm15
000079fe5f5d0a40  movaps [r15+0x210], xmm15
000079fe5f5d0a48  mov r14, [r15+0x48]
000079fe5f5d0a4c  mov [r15+0x78], r14
000079fe5f5d0a50  mov r12, [r13+r14*1]
000079fe5f5d0a55  movq xmm1, r12
000079fe5f5d0a5a  lea r12, [r14+0x40]
000079fe5f5d0a5e  mov r11, [r13+r12*1]
000079fe5f5d0a63  movq xmm15, r11
000079fe5f5d0a68  lea r12, [r14+0x80]
000079fe5f5d0a6f  mov r11, [r13+r12*1]
000079fe5f5d0a74  movq xmm14, r11
000079fe5f5d0a79  movaps xmm13, [r15+0x120]
000079fe5f5d0a81  movq r12, xmm13
000079fe5f5d0a86  movq r11, xmm1
000079fe5f5d0a8b  vmovq xmm1, r12
000079fe5f5d0a90  vmovq xmm13, r11
000079fe5f5d0a95  movaps xmm12, xmm1
000079fe5f5d0a99  mulsd xmm12, xmm13
000079fe5f5d0a9e  ucomisd xmm12, xmm12
000079fe5f5d0aa3  jp 0x000079FE5F5D0F06
000079fe5f5d0aa9  movq xmm12, xmm12
000079fe5f5d0aae  movaps xmm1, [r15+0x130]
000079fe5f5d0ab6  movq r12, xmm1
000079fe5f5d0abb  movq r11, xmm15
000079fe5f5d0ac0  vmovq xmm1, r12
000079fe5f5d0ac5  vmovq xmm15, r11
000079fe5f5d0aca  movaps xmm13, xmm1
000079fe5f5d0ace  mulsd xmm13, xmm15
000079fe5f5d0ad3  ucomisd xmm13, xmm13
000079fe5f5d0ad8  jp 0x000079FE5F5D0F52
000079fe5f5d0ade  movq xmm13, xmm13
000079fe5f5d0ae3  movq r12, xmm12
000079fe5f5d0ae8  movaps xmm1, [r15+0x110]
000079fe5f5d0af0  movq r11, xmm1
000079fe5f5d0af5  vmovq xmm1, r12
000079fe5f5d0afa  vmovq xmm15, r11
000079fe5f5d0aff  movaps xmm12, xmm1
000079fe5f5d0b03  addsd xmm12, xmm15
000079fe5f5d0b08  ucomisd xmm12, xmm12
000079fe5f5d0b0d  jp 0x000079FE5F5D0F9E
000079fe5f5d0b13  movq xmm12, xmm12
000079fe5f5d0b18  movq r12, xmm12
000079fe5f5d0b1d  movq r11, xmm13
000079fe5f5d0b22  vmovq xmm1, r12
000079fe5f5d0b27  vmovq xmm15, r11
000079fe5f5d0b2c  movaps xmm13, xmm1
000079fe5f5d0b30  addsd xmm13, xmm15
000079fe5f5d0b35  ucomisd xmm13, xmm13
000079fe5f5d0b3a  jp 0x000079FE5F5D0FEA
000079fe5f5d0b40  movq xmm13, xmm13
000079fe5f5d0b45  movaps xmm1, [r15+0x140]
000079fe5f5d0b4d  movq r12, xmm1
000079fe5f5d0b52  movq r11, xmm14
000079fe5f5d0b57  vmovq xmm1, r12
000079fe5f5d0b5c  vmovq xmm15, r11
000079fe5f5d0b61  movaps xmm14, xmm1
000079fe5f5d0b65  mulsd xmm14, xmm15
000079fe5f5d0b6a  ucomisd xmm14, xmm14
000079fe5f5d0b6f  jp 0x000079FE5F5D1036
000079fe5f5d0b75  movq xmm14, xmm14
000079fe5f5d0b7a  lea r12, [r14+0xC0]
000079fe5f5d0b81  mov r11, [r13+r12*1]
000079fe5f5d0b86  movq xmm1, r11
000079fe5f5d0b8b  movq r12, xmm13
000079fe5f5d0b90  movq r11, xmm14
000079fe5f5d0b95  vmovq xmm15, r12
000079fe5f5d0b9a  vmovq xmm14, r11
000079fe5f5d0b9f  movaps xmm13, xmm15
000079fe5f5d0ba3  addsd xmm13, xmm14
000079fe5f5d0ba8  ucomisd xmm13, xmm13
000079fe5f5d0bad  jp 0x000079FE5F5D108C
000079fe5f5d0bb3  movq xmm13, xmm13
000079fe5f5d0bb8  movaps xmm15, [r15+0x150]
000079fe5f5d0bc0  movq r12, xmm15
000079fe5f5d0bc5  movq r11, xmm1
000079fe5f5d0bca  vmovq xmm1, r12
000079fe5f5d0bcf  vmovq xmm15, r11
000079fe5f5d0bd4  movaps xmm14, xmm1
000079fe5f5d0bd8  mulsd xmm14, xmm15
000079fe5f5d0bdd  ucomisd xmm14, xmm14
000079fe5f5d0be2  jp 0x000079FE5F5D10D8
000079fe5f5d0be8  movq xmm14, xmm14
000079fe5f5d0bed  lea r12, [r14+0x100]
000079fe5f5d0bf4  mov r11, [r13+r12*1]
000079fe5f5d0bf9  movq xmm1, r11
000079fe5f5d0bfe  movq r12, xmm13
000079fe5f5d0c03  movq r11, xmm14
000079fe5f5d0c08  vmovq xmm15, r12
000079fe5f5d0c0d  vmovq xmm14, r11
000079fe5f5d0c12  movaps xmm13, xmm15
000079fe5f5d0c16  addsd xmm13, xmm14
000079fe5f5d0c1b  ucomisd xmm13, xmm13
000079fe5f5d0c20  jp 0x000079FE5F5D112E
000079fe5f5d0c26  movq xmm13, xmm13
000079fe5f5d0c2b  movaps xmm15, [r15+0x160]
000079fe5f5d0c33  movq r12, xmm15
000079fe5f5d0c38  movq r11, xmm1
000079fe5f5d0c3d  vmovq xmm1, r12
000079fe5f5d0c42  vmovq xmm15, r11
000079fe5f5d0c47  movaps xmm14, xmm1
000079fe5f5d0c4b  mulsd xmm14, xmm15
000079fe5f5d0c50  ucomisd xmm14, xmm14
000079fe5f5d0c55  jp 0x000079FE5F5D117A
000079fe5f5d0c5b  movq xmm14, xmm14
000079fe5f5d0c60  lea r12, [r14+0x140]
000079fe5f5d0c67  mov r11, [r13+r12*1]
000079fe5f5d0c6c  movq xmm1, r11
000079fe5f5d0c71  movq r12, xmm13
000079fe5f5d0c76  movq r11, xmm14
000079fe5f5d0c7b  vmovq xmm15, r12
000079fe5f5d0c80  vmovq xmm14, r11
000079fe5f5d0c85  movaps xmm13, xmm15
000079fe5f5d0c89  addsd xmm13, xmm14
000079fe5f5d0c8e  ucomisd xmm13, xmm13
000079fe5f5d0c93  jp 0x000079FE5F5D11D0
000079fe5f5d0c99  movq xmm13, xmm13
000079fe5f5d0c9e  movaps xmm15, [r15+0x170]
000079fe5f5d0ca6  movq r12, xmm15
000079fe5f5d0cab  movq r11, xmm1
000079fe5f5d0cb0  vmovq xmm1, r12
000079fe5f5d0cb5  vmovq xmm15, r11
000079fe5f5d0cba  movaps xmm14, xmm1
000079fe5f5d0cbe  mulsd xmm14, xmm15
000079fe5f5d0cc3  ucomisd xmm14, xmm14
000079fe5f5d0cc8  jp 0x000079FE5F5D121C
000079fe5f5d0cce  movq xmm14, xmm14
000079fe5f5d0cd3  lea r12, [r14+0x180]
000079fe5f5d0cda  mov r11, [r13+r12*1]
000079fe5f5d0cdf  movq xmm1, r11
000079fe5f5d0ce4  movq r12, xmm13
000079fe5f5d0ce9  movq r11, xmm14
000079fe5f5d0cee  vmovq xmm15, r12
000079fe5f5d0cf3  vmovq xmm14, r11
000079fe5f5d0cf8  movaps xmm13, xmm15
000079fe5f5d0cfc  addsd xmm13, xmm14
000079fe5f5d0d01  ucomisd xmm13, xmm13
000079fe5f5d0d06  jp 0x000079FE5F5D1272
000079fe5f5d0d0c  movq xmm13, xmm13
000079fe5f5d0d11  movaps xmm15, [r15+0x180]
000079fe5f5d0d19  movq r12, xmm15
000079fe5f5d0d1e  movq r11, xmm1
000079fe5f5d0d23  vmovq xmm1, r12
000079fe5f5d0d28  vmovq xmm15, r11
000079fe5f5d0d2d  movaps xmm14, xmm1
000079fe5f5d0d31  mulsd xmm14, xmm15
000079fe5f5d0d36  ucomisd xmm14, xmm14
000079fe5f5d0d3b  jp 0x000079FE5F5D12BE
000079fe5f5d0d41  movq xmm14, xmm14
000079fe5f5d0d46  lea r12, [r14+0x1C0]
000079fe5f5d0d4d  mov r14, [r13+r12*1]
000079fe5f5d0d52  movq xmm1, r14
000079fe5f5d0d57  movaps [r15+0x240], xmm1
000079fe5f5d0d5f  movq r14, xmm13
000079fe5f5d0d64  movq r12, xmm14
000079fe5f5d0d69  vmovq xmm15, r14
000079fe5f5d0d6e  vmovq xmm14, r12
000079fe5f5d0d73  movaps xmm13, xmm15
000079fe5f5d0d77  addsd xmm13, xmm14
000079fe5f5d0d7c  ucomisd xmm13, xmm13
000079fe5f5d0d81  jp 0x000079FE5F5D1314
000079fe5f5d0d87  movq xmm13, xmm13
000079fe5f5d0d8c  movaps xmm15, [r15+0x210]
000079fe5f5d0d94  movq r14, xmm15
000079fe5f5d0d99  movq r12, xmm1
000079fe5f5d0d9e  vmovq xmm1, r14
000079fe5f5d0da3  vmovq xmm15, r12
000079fe5f5d0da8  movaps xmm14, xmm1
000079fe5f5d0dac  mulsd xmm14, xmm15
000079fe5f5d0db1  ucomisd xmm14, xmm14
000079fe5f5d0db6  jp 0x000079FE5F5D1360
000079fe5f5d0dbc  movq xmm14, xmm14
000079fe5f5d0dc1  movaps [r15+0x230], xmm14
000079fe5f5d0dc9  movq r14, xmm13
000079fe5f5d0dce  movq r12, xmm14
000079fe5f5d0dd3  vmovq xmm1, r14
000079fe5f5d0dd8  vmovq xmm15, r12
000079fe5f5d0ddd  movaps xmm14, xmm1
000079fe5f5d0de1  addsd xmm14, xmm15
000079fe5f5d0de6  ucomisd xmm14, xmm14
000079fe5f5d0deb  jp 0x000079FE5F5D13AC
000079fe5f5d0df1  movq xmm14, xmm14
000079fe5f5d0df6  movaps [r15+0x220], xmm14
000079fe5f5d0dfe  movq r14, xmm14
000079fe5f5d0e03  mov [r13+rax*1], r14
000079fe5f5d0e08  mov qword ptr [r15+0x70], 0x08
000079fe5f5d0e10  xor eax, eax
000079fe5f5d0e12  mov r14d, 0x08
000079fe5f5d0e18  mov r12d, 0x40
000079fe5f5d0e1e  cmp r14, r12
000079fe5f5d0e21  cmc
000079fe5f5d0e22  lahf
000079fe5f5d0e23  seto al
000079fe5f5d0e26  mov [r15+0x108], eax
000079fe5f5d0e2d  mov eax, [r15+0x108]
000079fe5f5d0e34  sahf
000079fe5f5d0e35  jnz 0x000079FE5F5D0E67
000079fe5f5d0e37  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d0e3f  jz 0x000079FE5F5CFD40
000079fe5f5d0e45  nop [rax+rax*1], ax
000079fe5f5d0e4e  nop [rax+rax*1], eax
000079fe5f5d0e56  mov eax, 0x410118
000079fe5f5d0e5b  mov [r15+0x100], rax
000079fe5f5d0e62  jmp 0x000079FE5F3FE110
000079fe5f5d0e67  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d0e6f  jz 0x000079FE5F5CF3F0
000079fe5f5d0e75  nop [rax+rax*1], ax
000079fe5f5d0e7e  nop [rax+rax*1], eax
000079fe5f5d0e86  mov eax, 0x4100A4
000079fe5f5d0e8b  mov [r15+0x100], rax
000079fe5f5d0e92  jmp 0x000079FE5F3FE110
000079fe5f5d0e97  int3
000079fe5f5d0e98  call 0x000079FE5F4E27E0
000079fe5f5d0e9d  jmp 0x000079FE5F5D0959
000079fe5f5d0ea2  call 0x000079FE5F4AE800
000079fe5f5d0ea7  jmp 0x000079FE5F5D0962
000079fe5f5d0eac  call 0x000079FE5F4C0370
000079fe5f5d0eb1  jmp 0x000079FE5F5D0997
000079fe5f5d0eb6  call 0x000079FE5F4BF100
000079fe5f5d0ebb  jmp 0x000079FE5F5D09A0
000079fe5f5d0ec0  call 0x000079FE5F4C0370
000079fe5f5d0ec5  jmp 0x000079FE5F5D09D5
000079fe5f5d0eca  call 0x000079FE5F4BF100
000079fe5f5d0ecf  jmp 0x000079FE5F5D09DE
000079fe5f5d0ed4  call 0x000079FE5F4C0370
000079fe5f5d0ed9  jmp 0x000079FE5F5D0A13
000079fe5f5d0ede  call 0x000079FE5F4C3AE0
000079fe5f5d0ee3  jmp 0x000079FE5F5D0A1C
000079fe5f5d0ee8  call 0x000079FE5F4E27E0
000079fe5f5d0eed  jmp 0x000079FE5F5D0A55
000079fe5f5d0ef2  call 0x000079FE5F4C0370
000079fe5f5d0ef7  jmp 0x000079FE5F5D0A63
000079fe5f5d0efc  call 0x000079FE5F4C0370
000079fe5f5d0f01  jmp 0x000079FE5F5D0A74
000079fe5f5d0f06  ucomisd xmm1, xmm13
000079fe5f5d0f0b  jp 0x000079FE5F5D0F1A
000079fe5f5d0f0d  movaps xmm12, [0x000079FE5F1FE030]
000079fe5f5d0f15  jmp 0x000079FE5F5D0AA9
000079fe5f5d0f1a  vxorps xmm0, xmm1, xmm13
000079fe5f5d0f1f  pextrw r12d, xmm0, 0x03
000079fe5f5d0f25  and r12d, 0x7FF8
000079fe5f5d0f2c  cmp r12d, 0x08
000079fe5f5d0f30  jnz 0x000079FE5F5D0AA9
000079fe5f5d0f36  movq r12, xmm13
000079fe5f5d0f3b  shl r12, 0x0D
000079fe5f5d0f3f  jbe 0x000079FE5F5D0AA9
000079fe5f5d0f45  vorps xmm12, xmm13, [0x000079FE5F1FE040]
000079fe5f5d0f4d  jmp 0x000079FE5F5D0AA9
000079fe5f5d0f52  ucomisd xmm1, xmm15
000079fe5f5d0f57  jp 0x000079FE5F5D0F66
000079fe5f5d0f59  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d0f61  jmp 0x000079FE5F5D0ADE
000079fe5f5d0f66  vxorps xmm0, xmm1, xmm15
000079fe5f5d0f6b  pextrw r12d, xmm0, 0x03
000079fe5f5d0f71  and r12d, 0x7FF8
000079fe5f5d0f78  cmp r12d, 0x08
000079fe5f5d0f7c  jnz 0x000079FE5F5D0ADE
000079fe5f5d0f82  movq r12, xmm15
000079fe5f5d0f87  shl r12, 0x0D
000079fe5f5d0f8b  jbe 0x000079FE5F5D0ADE
000079fe5f5d0f91  vorps xmm13, xmm15, [0x000079FE5F1FE040]
000079fe5f5d0f99  jmp 0x000079FE5F5D0ADE
000079fe5f5d0f9e  ucomisd xmm1, xmm15
000079fe5f5d0fa3  jp 0x000079FE5F5D0FB2
000079fe5f5d0fa5  movaps xmm12, [0x000079FE5F1FE030]
000079fe5f5d0fad  jmp 0x000079FE5F5D0B13
000079fe5f5d0fb2  vxorps xmm0, xmm1, xmm15
000079fe5f5d0fb7  pextrw r12d, xmm0, 0x03
000079fe5f5d0fbd  and r12d, 0x7FF8
000079fe5f5d0fc4  cmp r12d, 0x08
000079fe5f5d0fc8  jnz 0x000079FE5F5D0B13
000079fe5f5d0fce  movq r12, xmm15
000079fe5f5d0fd3  shl r12, 0x0D
000079fe5f5d0fd7  jbe 0x000079FE5F5D0B13
000079fe5f5d0fdd  vorps xmm12, xmm15, [0x000079FE5F1FE040]
000079fe5f5d0fe5  jmp 0x000079FE5F5D0B13
000079fe5f5d0fea  ucomisd xmm1, xmm15
000079fe5f5d0fef  jp 0x000079FE5F5D0FFE
000079fe5f5d0ff1  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d0ff9  jmp 0x000079FE5F5D0B40
000079fe5f5d0ffe  vxorps xmm0, xmm1, xmm15
000079fe5f5d1003  pextrw r12d, xmm0, 0x03
000079fe5f5d1009  and r12d, 0x7FF8
000079fe5f5d1010  cmp r12d, 0x08
000079fe5f5d1014  jnz 0x000079FE5F5D0B40
000079fe5f5d101a  movq r12, xmm15
000079fe5f5d101f  shl r12, 0x0D
000079fe5f5d1023  jbe 0x000079FE5F5D0B40
000079fe5f5d1029  vorps xmm13, xmm15, [0x000079FE5F1FE040]
000079fe5f5d1031  jmp 0x000079FE5F5D0B40
000079fe5f5d1036  ucomisd xmm1, xmm15
000079fe5f5d103b  jp 0x000079FE5F5D104A
000079fe5f5d103d  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d1045  jmp 0x000079FE5F5D0B75
000079fe5f5d104a  vxorps xmm0, xmm1, xmm15
000079fe5f5d104f  pextrw r12d, xmm0, 0x03
000079fe5f5d1055  and r12d, 0x7FF8
000079fe5f5d105c  cmp r12d, 0x08
000079fe5f5d1060  jnz 0x000079FE5F5D0B75
000079fe5f5d1066  movq r12, xmm15
000079fe5f5d106b  shl r12, 0x0D
000079fe5f5d106f  jbe 0x000079FE5F5D0B75
000079fe5f5d1075  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d107d  jmp 0x000079FE5F5D0B75
000079fe5f5d1082  call 0x000079FE5F4C0370
000079fe5f5d1087  jmp 0x000079FE5F5D0B86
000079fe5f5d108c  ucomisd xmm15, xmm14
000079fe5f5d1091  jp 0x000079FE5F5D10A0
000079fe5f5d1093  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d109b  jmp 0x000079FE5F5D0BB3
000079fe5f5d10a0  vxorps xmm0, xmm15, xmm14
000079fe5f5d10a5  pextrw r12d, xmm0, 0x03
000079fe5f5d10ab  and r12d, 0x7FF8
000079fe5f5d10b2  cmp r12d, 0x08
000079fe5f5d10b6  jnz 0x000079FE5F5D0BB3
000079fe5f5d10bc  movq r12, xmm14
000079fe5f5d10c1  shl r12, 0x0D
000079fe5f5d10c5  jbe 0x000079FE5F5D0BB3
000079fe5f5d10cb  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d10d3  jmp 0x000079FE5F5D0BB3
000079fe5f5d10d8  ucomisd xmm1, xmm15
000079fe5f5d10dd  jp 0x000079FE5F5D10EC
000079fe5f5d10df  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d10e7  jmp 0x000079FE5F5D0BE8
000079fe5f5d10ec  vxorps xmm0, xmm1, xmm15
000079fe5f5d10f1  pextrw r12d, xmm0, 0x03
000079fe5f5d10f7  and r12d, 0x7FF8
000079fe5f5d10fe  cmp r12d, 0x08
000079fe5f5d1102  jnz 0x000079FE5F5D0BE8
000079fe5f5d1108  movq r12, xmm15
000079fe5f5d110d  shl r12, 0x0D
000079fe5f5d1111  jbe 0x000079FE5F5D0BE8
000079fe5f5d1117  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d111f  jmp 0x000079FE5F5D0BE8
000079fe5f5d1124  call 0x000079FE5F4C0370
000079fe5f5d1129  jmp 0x000079FE5F5D0BF9
000079fe5f5d112e  ucomisd xmm15, xmm14
000079fe5f5d1133  jp 0x000079FE5F5D1142
000079fe5f5d1135  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d113d  jmp 0x000079FE5F5D0C26
000079fe5f5d1142  vxorps xmm0, xmm15, xmm14
000079fe5f5d1147  pextrw r12d, xmm0, 0x03
000079fe5f5d114d  and r12d, 0x7FF8
000079fe5f5d1154  cmp r12d, 0x08
000079fe5f5d1158  jnz 0x000079FE5F5D0C26
000079fe5f5d115e  movq r12, xmm14
000079fe5f5d1163  shl r12, 0x0D
000079fe5f5d1167  jbe 0x000079FE5F5D0C26
000079fe5f5d116d  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d1175  jmp 0x000079FE5F5D0C26
000079fe5f5d117a  ucomisd xmm1, xmm15
000079fe5f5d117f  jp 0x000079FE5F5D118E
000079fe5f5d1181  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d1189  jmp 0x000079FE5F5D0C5B
000079fe5f5d118e  vxorps xmm0, xmm1, xmm15
000079fe5f5d1193  pextrw r12d, xmm0, 0x03
000079fe5f5d1199  and r12d, 0x7FF8
000079fe5f5d11a0  cmp r12d, 0x08
000079fe5f5d11a4  jnz 0x000079FE5F5D0C5B
000079fe5f5d11aa  movq r12, xmm15
000079fe5f5d11af  shl r12, 0x0D
000079fe5f5d11b3  jbe 0x000079FE5F5D0C5B
000079fe5f5d11b9  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d11c1  jmp 0x000079FE5F5D0C5B
000079fe5f5d11c6  call 0x000079FE5F4C0370
000079fe5f5d11cb  jmp 0x000079FE5F5D0C6C
000079fe5f5d11d0  ucomisd xmm15, xmm14
000079fe5f5d11d5  jp 0x000079FE5F5D11E4
000079fe5f5d11d7  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d11df  jmp 0x000079FE5F5D0C99
000079fe5f5d11e4  vxorps xmm0, xmm15, xmm14
000079fe5f5d11e9  pextrw r12d, xmm0, 0x03
000079fe5f5d11ef  and r12d, 0x7FF8
000079fe5f5d11f6  cmp r12d, 0x08
000079fe5f5d11fa  jnz 0x000079FE5F5D0C99
000079fe5f5d1200  movq r12, xmm14
000079fe5f5d1205  shl r12, 0x0D
000079fe5f5d1209  jbe 0x000079FE5F5D0C99
000079fe5f5d120f  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d1217  jmp 0x000079FE5F5D0C99
000079fe5f5d121c  ucomisd xmm1, xmm15
000079fe5f5d1221  jp 0x000079FE5F5D1230
000079fe5f5d1223  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d122b  jmp 0x000079FE5F5D0CCE
000079fe5f5d1230  vxorps xmm0, xmm1, xmm15
000079fe5f5d1235  pextrw r12d, xmm0, 0x03
000079fe5f5d123b  and r12d, 0x7FF8
000079fe5f5d1242  cmp r12d, 0x08
000079fe5f5d1246  jnz 0x000079FE5F5D0CCE
000079fe5f5d124c  movq r12, xmm15
000079fe5f5d1251  shl r12, 0x0D
000079fe5f5d1255  jbe 0x000079FE5F5D0CCE
000079fe5f5d125b  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d1263  jmp 0x000079FE5F5D0CCE
000079fe5f5d1268  call 0x000079FE5F4C0370
000079fe5f5d126d  jmp 0x000079FE5F5D0CDF
000079fe5f5d1272  ucomisd xmm15, xmm14
000079fe5f5d1277  jp 0x000079FE5F5D1286
000079fe5f5d1279  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d1281  jmp 0x000079FE5F5D0D0C
000079fe5f5d1286  vxorps xmm0, xmm15, xmm14
000079fe5f5d128b  pextrw r12d, xmm0, 0x03
000079fe5f5d1291  and r12d, 0x7FF8
000079fe5f5d1298  cmp r12d, 0x08
000079fe5f5d129c  jnz 0x000079FE5F5D0D0C
000079fe5f5d12a2  movq r12, xmm14
000079fe5f5d12a7  shl r12, 0x0D
000079fe5f5d12ab  jbe 0x000079FE5F5D0D0C
000079fe5f5d12b1  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d12b9  jmp 0x000079FE5F5D0D0C
000079fe5f5d12be  ucomisd xmm1, xmm15
000079fe5f5d12c3  jp 0x000079FE5F5D12D2
000079fe5f5d12c5  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d12cd  jmp 0x000079FE5F5D0D41
000079fe5f5d12d2  vxorps xmm0, xmm1, xmm15
000079fe5f5d12d7  pextrw r12d, xmm0, 0x03
000079fe5f5d12dd  and r12d, 0x7FF8
000079fe5f5d12e4  cmp r12d, 0x08
000079fe5f5d12e8  jnz 0x000079FE5F5D0D41
000079fe5f5d12ee  movq r12, xmm15
000079fe5f5d12f3  shl r12, 0x0D
000079fe5f5d12f7  jbe 0x000079FE5F5D0D41
000079fe5f5d12fd  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d1305  jmp 0x000079FE5F5D0D41
000079fe5f5d130a  call 0x000079FE5F4C3AE0
000079fe5f5d130f  jmp 0x000079FE5F5D0D52
000079fe5f5d1314  ucomisd xmm15, xmm14
000079fe5f5d1319  jp 0x000079FE5F5D1328
000079fe5f5d131b  movaps xmm13, [0x000079FE5F1FE030]
000079fe5f5d1323  jmp 0x000079FE5F5D0D87
000079fe5f5d1328  vxorps xmm0, xmm15, xmm14
000079fe5f5d132d  pextrw r14d, xmm0, 0x03
000079fe5f5d1333  and r14d, 0x7FF8
000079fe5f5d133a  cmp r14d, 0x08
000079fe5f5d133e  jnz 0x000079FE5F5D0D87
000079fe5f5d1344  movq r14, xmm14
000079fe5f5d1349  shl r14, 0x0D
000079fe5f5d134d  jbe 0x000079FE5F5D0D87
000079fe5f5d1353  vorps xmm13, xmm14, [0x000079FE5F1FE040]
000079fe5f5d135b  jmp 0x000079FE5F5D0D87
000079fe5f5d1360  ucomisd xmm1, xmm15
000079fe5f5d1365  jp 0x000079FE5F5D1374
000079fe5f5d1367  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d136f  jmp 0x000079FE5F5D0DBC
000079fe5f5d1374  vxorps xmm0, xmm1, xmm15
000079fe5f5d1379  pextrw r14d, xmm0, 0x03
000079fe5f5d137f  and r14d, 0x7FF8
000079fe5f5d1386  cmp r14d, 0x08
000079fe5f5d138a  jnz 0x000079FE5F5D0DBC
000079fe5f5d1390  movq r14, xmm15
000079fe5f5d1395  shl r14, 0x0D
000079fe5f5d1399  jbe 0x000079FE5F5D0DBC
000079fe5f5d139f  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d13a7  jmp 0x000079FE5F5D0DBC
000079fe5f5d13ac  ucomisd xmm1, xmm15
000079fe5f5d13b1  jp 0x000079FE5F5D13C0
000079fe5f5d13b3  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d13bb  jmp 0x000079FE5F5D0DF1
000079fe5f5d13c0  vxorps xmm0, xmm1, xmm15
000079fe5f5d13c5  pextrw r14d, xmm0, 0x03
000079fe5f5d13cb  and r14d, 0x7FF8
000079fe5f5d13d2  cmp r14d, 0x08
000079fe5f5d13d6  jnz 0x000079FE5F5D0DF1
000079fe5f5d13dc  movq r14, xmm15
000079fe5f5d13e1  shl r14, 0x0D
000079fe5f5d13e5  jbe 0x000079FE5F5D0DF1
000079fe5f5d13eb  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d13f3  jmp 0x000079FE5F5D0DF1
000079fe5f5d13f8  call 0x000079FE5F40E120
000079fe5f5d13fd  jmp 0x000079FE5F5D0E08
000079fe5f5d1402  int3
000079fe5f5d1403  nop [rax+rax*1], ax
000079fe5f5d140c  nop [rax], eax
000079fe5f5d1410  mov qword ptr [r15+0x40], 0x420000
000079fe5f5d1418  mov eax, 0x4201B8
000079fe5f5d141d  mov r14, [r13+rax*1]
000079fe5f5d1422  movq xmm1, r14
000079fe5f5d1427  mov rax, [r15+0x50]
000079fe5f5d142b  mov r14, [r13+rax*1]
000079fe5f5d1430  movq xmm15, r14
000079fe5f5d1435  movaps [r15+0x120], xmm15
000079fe5f5d143d  mov qword ptr [r15+0x48], 0x08
000079fe5f5d1445  xor eax, eax
000079fe5f5d1447  mov r14d, 0x08
000079fe5f5d144d  mov r12d, 0x200
000079fe5f5d1453  cmp r14, r12
000079fe5f5d1456  cmc
000079fe5f5d1457  lahf
000079fe5f5d1458  seto al
000079fe5f5d145b  mov [r15+0x108], eax
000079fe5f5d1462  movq rax, xmm1
000079fe5f5d1467  movq r14, xmm15
000079fe5f5d146c  vmovq xmm1, rax
000079fe5f5d1471  vmovq xmm15, r14
000079fe5f5d1476  movaps xmm14, xmm1
000079fe5f5d147a  addsd xmm14, xmm15
000079fe5f5d147f  ucomisd xmm14, xmm14
000079fe5f5d1484  jp 0x000079FE5F5D1516
000079fe5f5d148a  movq xmm14, xmm14
000079fe5f5d148f  movaps [r15+0x110], xmm14
000079fe5f5d1497  mov eax, [r15+0x108]
000079fe5f5d149e  sahf
000079fe5f5d149f  jnz 0x000079FE5F5D14D1
000079fe5f5d14a1  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d14a9  jz 0x000079FE5F5D16A0
000079fe5f5d14af  nop [rax+rax*1], ax
000079fe5f5d14b8  nop [rax+rax*1], eax
000079fe5f5d14c0  mov eax, 0x410154
000079fe5f5d14c5  mov [r15+0x100], rax
000079fe5f5d14cc  jmp 0x000079FE5F3FE110
000079fe5f5d14d1  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d14d9  jz 0x000079FE5F5D1560
000079fe5f5d14df  nop [rax+rax*1], ax
000079fe5f5d14e8  nop [rax+rax*1], eax
000079fe5f5d14f0  mov eax, 0x410140
000079fe5f5d14f5  mov [r15+0x100], rax
000079fe5f5d14fc  jmp 0x000079FE5F3FE110
000079fe5f5d1501  int3
000079fe5f5d1502  call 0x000079FE5F40DC20
000079fe5f5d1507  jmp 0x000079FE5F5D1422
000079fe5f5d150c  call 0x000079FE5F40DC20
000079fe5f5d1511  jmp 0x000079FE5F5D1430
000079fe5f5d1516  ucomisd xmm1, xmm15
000079fe5f5d151b  jp 0x000079FE5F5D152A
000079fe5f5d151d  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d1525  jmp 0x000079FE5F5D148A
000079fe5f5d152a  vxorps xmm0, xmm1, xmm15
000079fe5f5d152f  pextrw eax, xmm0, 0x03
000079fe5f5d1534  and eax, 0x7FF8
000079fe5f5d1539  cmp eax, 0x08
000079fe5f5d153c  jnz 0x000079FE5F5D148A
000079fe5f5d1542  movq rax, xmm15
000079fe5f5d1547  shl rax, 0x0D
000079fe5f5d154b  jbe 0x000079FE5F5D148A
000079fe5f5d1551  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d1559  jmp 0x000079FE5F5D148A
000079fe5f5d155e  int3
000079fe5f5d155f  nop
000079fe5f5d1560  mov rax, [r15+0x48]
000079fe5f5d1564  mov r14, [r15+0x50]
000079fe5f5d1568  lea r12, [r14+rax*1]
000079fe5f5d156c  mov r14, [r13+r12*1]
000079fe5f5d1571  movq xmm1, r14
000079fe5f5d1576  movaps [r15+0x120], xmm1
000079fe5f5d157e  lea r14, [rax+0x08]
000079fe5f5d1582  mov [r15+0x48], r14
000079fe5f5d1586  xor eax, eax
000079fe5f5d1588  mov r12d, 0x200
000079fe5f5d158e  cmp r14, r12
000079fe5f5d1591  cmc
000079fe5f5d1592  lahf
000079fe5f5d1593  seto al
000079fe5f5d1596  mov [r15+0x108], eax
000079fe5f5d159d  movaps xmm15, [r15+0x110]
000079fe5f5d15a5  movq rax, xmm15
000079fe5f5d15aa  movq r14, xmm1
000079fe5f5d15af  vmovq xmm1, rax
000079fe5f5d15b4  vmovq xmm15, r14
000079fe5f5d15b9  movaps xmm14, xmm1
000079fe5f5d15bd  addsd xmm14, xmm15
000079fe5f5d15c2  ucomisd xmm14, xmm14
000079fe5f5d15c7  jp 0x000079FE5F5D164F
000079fe5f5d15cd  movq xmm14, xmm14
000079fe5f5d15d2  movaps [r15+0x110], xmm14
000079fe5f5d15da  mov eax, [r15+0x108]
000079fe5f5d15e1  sahf
000079fe5f5d15e2  jnz 0x000079FE5F5D1614
000079fe5f5d15e4  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d15ec  jz 0x000079FE5F5D16A0
000079fe5f5d15f2  nop [rax+rax*1], ax
000079fe5f5d15fb  nop [rax+rax*1], eax
000079fe5f5d1603  mov eax, 0x410154
000079fe5f5d1608  mov [r15+0x100], rax
000079fe5f5d160f  jmp 0x000079FE5F3FE110
000079fe5f5d1614  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d161c  jz 0x000079FE5F5D1560
000079fe5f5d1622  nop [rax+rax*1], ax
000079fe5f5d162b  nop [rax+rax*1], eax
000079fe5f5d1633  mov eax, 0x410140
000079fe5f5d1638  mov [r15+0x100], rax
000079fe5f5d163f  jmp 0x000079FE5F3FE110
000079fe5f5d1644  int3
000079fe5f5d1645  call 0x000079FE5F4C3AE0
000079fe5f5d164a  jmp 0x000079FE5F5D1571
000079fe5f5d164f  ucomisd xmm1, xmm15
000079fe5f5d1654  jp 0x000079FE5F5D1663
000079fe5f5d1656  movaps xmm14, [0x000079FE5F1FE030]
000079fe5f5d165e  jmp 0x000079FE5F5D15CD
000079fe5f5d1663  vxorps xmm0, xmm1, xmm15
000079fe5f5d1668  pextrw eax, xmm0, 0x03
000079fe5f5d166d  and eax, 0x7FF8
000079fe5f5d1672  cmp eax, 0x08
000079fe5f5d1675  jnz 0x000079FE5F5D15CD
000079fe5f5d167b  movq rax, xmm15
000079fe5f5d1680  shl rax, 0x0D
000079fe5f5d1684  jbe 0x000079FE5F5D15CD
000079fe5f5d168a  vorps xmm14, xmm15, [0x000079FE5F1FE040]
000079fe5f5d1692  jmp 0x000079FE5F5D15CD
000079fe5f5d1697  int3
000079fe5f5d1698  nop [rax+rax*1], eax
000079fe5f5d16a0  mov rax, [r15+0x40]
000079fe5f5d16a4  lea r14, [rax+0x1B8]
000079fe5f5d16ab  movaps xmm1, [r15+0x110]
000079fe5f5d16b3  movq rax, xmm1
000079fe5f5d16b8  mov [r13+r14*1], rax
000079fe5f5d16bd  mov rax, [r15+0xF0]
000079fe5f5d16c4  mov [r15+0x100], rax
000079fe5f5d16cb  jmp 0x000079FE5F5CE5C0
000079fe5f5d16d0  int3
000079fe5f5d16d1  call 0x000079FE5F4D5EB0
000079fe5f5d16d6  jmp 0x000079FE5F5D16BD
000079fe5f5d16db  int3
000079fe5f5d16dc  nop [rax], eax
000079fe5f5d16e0  mov qword ptr [r15+0x100], 0x04
000079fe5f5d16eb  mov esi, 0x00
000079fe5f5d16f0  mov edx, 0x09
000079fe5f5d16f5  mov rdi, 0x7FFFEBA499C0
000079fe5f5d16ff  mov rax, 0x612D403A8970
000079fe5f5d1709  call rax
000079fe5f5d170b  cmp dword ptr [r15+0x318], 0x00
000079fe5f5d1713  jnz 0x000079FE5F3FE110
000079fe5f5d1719  jmp 0x000079FE5F3FE0A0
000079fe5f5d171e  int3
000079fe5f5d171f  int3
