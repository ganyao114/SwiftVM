
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/integer/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13d,0x1b00
   6:	mov    QWORD PTR [r12+0x8],r13
   b:	mov    r13d,0x1b00
  11:	mov    r14d,0xb7
  17:	and    r14d,0xffff
  1e:	mov    rax,r13
  21:	movabs rcx,0xffffffff0000ffff
  2b:	and    rax,rcx
  2e:	mov    rdx,r14
  31:	shl    rdx,0x10
  35:	mov    ecx,0xffff0000
  3a:	and    rdx,rcx
  3d:	or     rax,rdx
  40:	mov    r15,rax
  43:	mov    QWORD PTR [r12+0x8],r15
  48:	mov    r13d,0x420060
  4e:	mov    QWORD PTR [r12+0x20],r13
  53:	mov    r13d,0x0
  59:	mov    QWORD PTR [r12],r13
  5d:	jmp    0x62
  62:	mov    r13,QWORD PTR [r12]
  66:	mov    r14,r13
  69:	add    r14,0x3
  6d:	mov    QWORD PTR [r12],r14
  71:	mov    r13,r14
  74:	shr    r13,0x7
  78:	mov    rcx,r13
  7b:	mov    r15,r14
  7e:	xor    r15,rcx
  81:	mov    QWORD PTR [r12],r15
  85:	mov    r13,QWORD PTR [r12+0x8]
  8a:	mov    r14,r13
  8d:	sub    r14,0x1
  91:	pushf
  92:	pop    rdx
  93:	mov    r10d,edx
  96:	and    r10d,0xc0
  9d:	shl    r10d,0x18
  a1:	mov    r11d,edx
  a4:	and    r11d,0x1
  a8:	shl    r11d,0x1d
  ac:	or     r10d,r11d
  af:	mov    r11d,edx
  b2:	and    r11d,0x800
  b9:	shl    r11d,0x11
  bd:	or     r10d,r11d
  c0:	mov    r11d,0xf0000000
  c6:	and    r11,r10
  c9:	movabs rsi,0xffffffff0fffffff
  d3:	and    rbx,rsi
  d6:	or     rbx,r11
  d9:	btc    rbx,0x1d
  de:	mov    QWORD PTR [r12+0x8],r14
  e3:	cmp    QWORD PTR [r12+0x380],0x0
  ec:	je     0x119
  f2:	mov    eax,0x410048
  f7:	mov    QWORD PTR [r12+0x100],rax
  ff:	mov    QWORD PTR [r12+0x108],rbx
 107:	mov    eax,0xc
 10c:	movabs r11,0x59c03bc0b5f0
 116:	jmp    r11
 119:	test   ebx,0x40000000
 11f:	je     0x62
 125:	jmp    0x12a
 12a:	mov    r13,QWORD PTR [r12+0x20]
 12f:	mov    r14,QWORD PTR [r12]
 133:	mov    QWORD PTR [r13+0x0],r14
 137:	mov    r13d,0x0
 13d:	mov    DWORD PTR [r12+0x32c],r13d
 145:	cmp    QWORD PTR [r12+0x380],0x0
 14e:	je     0x17b
 154:	mov    eax,0x410050
 159:	mov    QWORD PTR [r12+0x100],rax
 161:	mov    QWORD PTR [r12+0x108],rbx
 169:	mov    eax,0xc
 16e:	movabs r11,0x59c03bc0b5f0
 178:	jmp    r11
 17b:	mov    r13,QWORD PTR [r12+0xf0]
 183:	mov    QWORD PTR [r12+0x100],r13
 18b:	mov    QWORD PTR [r12+0x108],rbx
 193:	mov    rdi,QWORD PTR [r12+0x100]
 19b:	movabs r11,0x59c03bc0b370
 1a5:	jmp    r11
 1a8:	nop    DWORD PTR [rax+rax*1+0x0]
 1b0:	jmp    0x62
 1b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 1c0:	jmp    0x12a
 1c5:	nop
 1c6:	nop
 1c7:	nop
