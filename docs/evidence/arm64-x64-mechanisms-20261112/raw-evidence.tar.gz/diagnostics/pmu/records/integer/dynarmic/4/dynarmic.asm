000073bcd17ce69b  nop [rax+rax*1], eax
000073bcd17ce6a0  mov qword ptr [r15+0x20], 0x420060
000073bcd17ce6a8  mov qword ptr [r15], 0x03
000073bcd17ce6af  xor eax, eax
000073bcd17ce6b1  mov r14d, 0xB71B00
000073bcd17ce6b7  mov r12d, 0x01
000073bcd17ce6bd  sub r14, r12
000073bcd17ce6c0  cmc
000073bcd17ce6c1  lahf
000073bcd17ce6c2  seto al
000073bcd17ce6c5  mov [r15+0x108], eax
000073bcd17ce6cc  mov [r15+0x08], r14
000073bcd17ce6d0  mov eax, [r15+0x108]
000073bcd17ce6d7  sahf
000073bcd17ce6d8  jnz 0x000073BCD17CE70A
000073bcd17ce6da  cmp dword ptr [r15+0x318], 0x00
000073bcd17ce6e2  jz 0x000073BCD17CE7F0
000073bcd17ce6e8  nop [rax+rax*1], ax
000073bcd17ce6f1  nop [rax+rax*1], eax
000073bcd17ce6f9  mov eax, 0x41004C
000073bcd17ce6fe  mov [r15+0x100], rax
000073bcd17ce705  jmp 0x000073BCD15FE110
000073bcd17ce70a  cmp dword ptr [r15+0x318], 0x00
000073bcd17ce712  jz 0x000073BCD17CE740
000073bcd17ce718  nop [rax+rax*1], ax
000073bcd17ce721  nop [rax+rax*1], eax
000073bcd17ce729  mov eax, 0x41003C
000073bcd17ce72e  mov [r15+0x100], rax
000073bcd17ce735  jmp 0x000073BCD15FE110
000073bcd17ce73a  int3
000073bcd17ce73b  int3
000073bcd17ce73c  nop [rax], eax
000073bcd17ce740  mov rax, [r15]
000073bcd17ce743  lea r14, [rax+0x03]
000073bcd17ce747  mov [rsp+0x10], r14
000073bcd17ce74c  shr r14, 0x07
000073bcd17ce750  mov rax, [rsp+0x10]
000073bcd17ce755  xor rax, r14
000073bcd17ce758  mov [r15], rax
000073bcd17ce75b  mov rax, [r15+0x08]
000073bcd17ce75f  mov [rsp+0x10], rax
000073bcd17ce764  xor eax, eax
000073bcd17ce766  mov r14, [rsp+0x10]
000073bcd17ce76b  mov r12d, 0x01
000073bcd17ce771  sub r14, r12
000073bcd17ce774  cmc
000073bcd17ce775  lahf
000073bcd17ce776  seto al
000073bcd17ce779  mov [r15+0x108], eax
000073bcd17ce780  mov [r15+0x08], r14
000073bcd17ce784  mov eax, [r15+0x108]
000073bcd17ce78b  sahf
000073bcd17ce78c  jnz 0x000073BCD17CE7BE
000073bcd17ce78e  cmp dword ptr [r15+0x318], 0x00
000073bcd17ce796  jz 0x000073BCD17CE7F0
000073bcd17ce79c  nop [rax+rax*1], ax
000073bcd17ce7a5  nop [rax+rax*1], eax
000073bcd17ce7ad  mov eax, 0x41004C
000073bcd17ce7b2  mov [r15+0x100], rax
000073bcd17ce7b9  jmp 0x000073BCD15FE110
000073bcd17ce7be  cmp dword ptr [r15+0x318], 0x00
000073bcd17ce7c6  jz 0x000073BCD17CE740
000073bcd17ce7cc  nop [rax+rax*1], ax
000073bcd17ce7d5  nop [rax+rax*1], eax
000073bcd17ce7dd  mov eax, 0x41003C
000073bcd17ce7e2  mov [r15+0x100], rax
000073bcd17ce7e9  jmp 0x000073BCD15FE110
000073bcd17ce7ee  int3
000073bcd17ce7ef  int3
000073bcd17ce7f0  mov rax, [r15+0x20]
000073bcd17ce7f4  mov r14, [r15]
000073bcd17ce7f7  mov [r13+rax*1], r14
000073bcd17ce7fc  mov rax, [r15+0xF0]
000073bcd17ce803  mov [r15+0x100], rax
000073bcd17ce80a  jmp 0x000073BCD17CE5C0
000073bcd17ce80f  int3
000073bcd17ce810  call 0x000073BCD160E120
000073bcd17ce815  jmp 0x000073BCD17CE7FC
000073bcd17ce81a  int3
000073bcd17ce81b  nop [rax+rax*1], eax
000073bcd17ce820  mov qword ptr [r15+0x100], 0x04
000073bcd17ce82b  mov esi, 0x00
000073bcd17ce830  mov edx, 0x09
000073bcd17ce835  mov rdi, 0x7FFD21352C80
000073bcd17ce83f  mov rax, 0x56029D729970
000073bcd17ce849  call rax
000073bcd17ce84b  cmp dword ptr [r15+0x318], 0x00
000073bcd17ce853  jnz 0x000073BCD15FE110
000073bcd17ce859  jmp 0x000073BCD15FE0A0
000073bcd17ce85e  int3
000073bcd17ce85f  int3
