00007db39ebce69b  nop [rax+rax*1], eax
00007db39ebce6a0  mov qword ptr [r15+0x20], 0x420060
00007db39ebce6a8  mov qword ptr [r15], 0x03
00007db39ebce6af  xor eax, eax
00007db39ebce6b1  mov r14d, 0xB71B00
00007db39ebce6b7  mov r12d, 0x01
00007db39ebce6bd  sub r14, r12
00007db39ebce6c0  cmc
00007db39ebce6c1  lahf
00007db39ebce6c2  seto al
00007db39ebce6c5  mov [r15+0x108], eax
00007db39ebce6cc  mov [r15+0x08], r14
00007db39ebce6d0  mov eax, [r15+0x108]
00007db39ebce6d7  sahf
00007db39ebce6d8  jnz 0x00007DB39EBCE70A
00007db39ebce6da  cmp dword ptr [r15+0x318], 0x00
00007db39ebce6e2  jz 0x00007DB39EBCE7F0
00007db39ebce6e8  nop [rax+rax*1], ax
00007db39ebce6f1  nop [rax+rax*1], eax
00007db39ebce6f9  mov eax, 0x41004C
00007db39ebce6fe  mov [r15+0x100], rax
00007db39ebce705  jmp 0x00007DB39E9FE110
00007db39ebce70a  cmp dword ptr [r15+0x318], 0x00
00007db39ebce712  jz 0x00007DB39EBCE740
00007db39ebce718  nop [rax+rax*1], ax
00007db39ebce721  nop [rax+rax*1], eax
00007db39ebce729  mov eax, 0x41003C
00007db39ebce72e  mov [r15+0x100], rax
00007db39ebce735  jmp 0x00007DB39E9FE110
00007db39ebce73a  int3
00007db39ebce73b  int3
00007db39ebce73c  nop [rax], eax
00007db39ebce740  mov rax, [r15]
00007db39ebce743  lea r14, [rax+0x03]
00007db39ebce747  mov [rsp+0x10], r14
00007db39ebce74c  shr r14, 0x07
00007db39ebce750  mov rax, [rsp+0x10]
00007db39ebce755  xor rax, r14
00007db39ebce758  mov [r15], rax
00007db39ebce75b  mov rax, [r15+0x08]
00007db39ebce75f  mov [rsp+0x10], rax
00007db39ebce764  xor eax, eax
00007db39ebce766  mov r14, [rsp+0x10]
00007db39ebce76b  mov r12d, 0x01
00007db39ebce771  sub r14, r12
00007db39ebce774  cmc
00007db39ebce775  lahf
00007db39ebce776  seto al
00007db39ebce779  mov [r15+0x108], eax
00007db39ebce780  mov [r15+0x08], r14
00007db39ebce784  mov eax, [r15+0x108]
00007db39ebce78b  sahf
00007db39ebce78c  jnz 0x00007DB39EBCE7BE
00007db39ebce78e  cmp dword ptr [r15+0x318], 0x00
00007db39ebce796  jz 0x00007DB39EBCE7F0
00007db39ebce79c  nop [rax+rax*1], ax
00007db39ebce7a5  nop [rax+rax*1], eax
00007db39ebce7ad  mov eax, 0x41004C
00007db39ebce7b2  mov [r15+0x100], rax
00007db39ebce7b9  jmp 0x00007DB39E9FE110
00007db39ebce7be  cmp dword ptr [r15+0x318], 0x00
00007db39ebce7c6  jz 0x00007DB39EBCE740
00007db39ebce7cc  nop [rax+rax*1], ax
00007db39ebce7d5  nop [rax+rax*1], eax
00007db39ebce7dd  mov eax, 0x41003C
00007db39ebce7e2  mov [r15+0x100], rax
00007db39ebce7e9  jmp 0x00007DB39E9FE110
00007db39ebce7ee  int3
00007db39ebce7ef  int3
00007db39ebce7f0  mov rax, [r15+0x20]
00007db39ebce7f4  mov r14, [r15]
00007db39ebce7f7  mov [r13+rax*1], r14
00007db39ebce7fc  mov rax, [r15+0xF0]
00007db39ebce803  mov [r15+0x100], rax
00007db39ebce80a  jmp 0x00007DB39EBCE5C0
00007db39ebce80f  int3
00007db39ebce810  call 0x00007DB39EA0E120
00007db39ebce815  jmp 0x00007DB39EBCE7FC
00007db39ebce81a  int3
00007db39ebce81b  nop [rax+rax*1], eax
00007db39ebce820  mov qword ptr [r15+0x100], 0x04
00007db39ebce82b  mov esi, 0x00
00007db39ebce830  mov edx, 0x09
00007db39ebce835  mov rdi, 0x7FFC485113E0
00007db39ebce83f  mov rax, 0x5CFF3DAB7970
00007db39ebce849  call rax
00007db39ebce84b  cmp dword ptr [r15+0x318], 0x00
00007db39ebce853  jnz 0x00007DB39E9FE110
00007db39ebce859  jmp 0x00007DB39E9FE0A0
00007db39ebce85e  int3
00007db39ebce85f  int3
