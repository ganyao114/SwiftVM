
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/integer/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13d,0x1b00
   a:	mov    r14d,0xb7
  10:	and    r14d,0xffff
  17:	mov    rax,r13
  1a:	movabs rcx,0xffffffff0000ffff
  24:	and    rax,rcx
  27:	mov    rdx,r14
  2a:	shl    rdx,0x10
  2e:	mov    ecx,0xffff0000
  33:	and    rdx,rcx
  36:	or     rax,rdx
  39:	mov    r15,rax
  3c:	mov    QWORD PTR [r12+0x8],r15
  41:	mov    r13d,0x420060
  47:	mov    QWORD PTR [r12+0x20],r13
  4c:	mov    r13d,0x0
  52:	mov    QWORD PTR [r12],r13
  56:	jmp    0x5b
  5b:	mov    r13,QWORD PTR [r12]
  5f:	add    r13,0x3
  63:	mov    r14,r13
  66:	shr    r14,0x7
  6a:	mov    rcx,r14
  6d:	xor    r13,rcx
  70:	mov    QWORD PTR [r12],r13
  74:	mov    r13,QWORD PTR [r12+0x8]
  79:	sub    r13,0x1
  7d:	mov    QWORD PTR [r12+0x8],r13
  82:	mov    rcx,QWORD PTR [r12+0x380]
  8a:	jrcxz  0x91
  8c:	jmp    0x102
  91:	jne    0x5b
  97:	pushf
  98:	pop    r11
  9a:	mov    QWORD PTR [rsp],r11
  9e:	jmp    0xa3
  a3:	mov    r13,QWORD PTR [r12+0x20]
  a8:	mov    r14,QWORD PTR [r12]
  ac:	mov    QWORD PTR [r13+0x0],r14
  b0:	mov    r13d,0x0
  b6:	mov    DWORD PTR [r12+0x32c],r13d
  be:	mov    rcx,QWORD PTR [r12+0x380]
  c6:	jrcxz  0xcd
  c8:	jmp    0x191
  cd:	mov    r13,QWORD PTR [r12+0xf0]
  d5:	mov    QWORD PTR [r12+0x100],r13
  dd:	mov    r11,QWORD PTR [rsp]
  e1:	mov    QWORD PTR [r12+0x398],r11
  e9:	mov    rdi,QWORD PTR [r12+0x100]
  f1:	add    rsp,0x10
  f5:	movabs r11,0x5ed09492e0a0
  ff:	jmp    r11
 102:	mov    eax,0x410048
 107:	mov    QWORD PTR [r12+0x100],rax
 10f:	push   rdx
 110:	push   rsi
 111:	push   r10
 113:	push   r11
 115:	pushf
 116:	pop    r11
 118:	mov    QWORD PTR [rsp+0x20],r11
 11d:	mov    rdx,QWORD PTR [rsp+0x20]
 122:	mov    r10d,edx
 125:	and    r10d,0xc0
 12c:	shl    r10d,0x18
 130:	mov    r11d,edx
 133:	and    r11d,0x1
 137:	shl    r11d,0x1d
 13b:	or     r10d,r11d
 13e:	mov    r11d,edx
 141:	and    r11d,0x800
 148:	shl    r11d,0x11
 14c:	or     r10d,r11d
 14f:	btc    r10,0x1d
 154:	mov    r11d,0xf0000000
 15a:	and    r11,r10
 15d:	movabs rsi,0xffffffff0fffffff
 167:	and    rbx,rsi
 16a:	or     rbx,r11
 16d:	pop    r11
 16f:	pop    r10
 171:	pop    rsi
 172:	pop    rdx
 173:	mov    QWORD PTR [r12+0x108],rbx
 17b:	add    rsp,0x10
 17f:	mov    eax,0xc
 184:	movabs r11,0x5ed09492e390
 18e:	jmp    r11
 191:	mov    eax,0x410050
 196:	mov    QWORD PTR [r12+0x100],rax
 19e:	push   rdx
 19f:	push   rsi
 1a0:	push   r10
 1a2:	push   r11
 1a4:	mov    rdx,QWORD PTR [rsp+0x20]
 1a9:	mov    r10d,edx
 1ac:	and    r10d,0xc0
 1b3:	shl    r10d,0x18
 1b7:	mov    r11d,edx
 1ba:	and    r11d,0x1
 1be:	shl    r11d,0x1d
 1c2:	or     r10d,r11d
 1c5:	mov    r11d,edx
 1c8:	and    r11d,0x800
 1cf:	shl    r11d,0x11
 1d3:	or     r10d,r11d
 1d6:	btc    r10,0x1d
 1db:	mov    r11d,0xf0000000
 1e1:	and    r11,r10
 1e4:	movabs rsi,0xffffffff0fffffff
 1ee:	and    rbx,rsi
 1f1:	or     rbx,r11
 1f4:	pop    r11
 1f6:	pop    r10
 1f8:	pop    rsi
 1f9:	pop    rdx
 1fa:	mov    QWORD PTR [r12+0x108],rbx
 202:	add    rsp,0x10
 206:	mov    eax,0xc
 20b:	movabs r11,0x5ed09492e390
 215:	jmp    r11
 218:	nop    DWORD PTR [rax+rax*1+0x0]
 220:	sub    rsp,0x10
 224:	jmp    0x5b
 229:	nop    DWORD PTR [rax+0x0]
 230:	sub    rsp,0x10
 234:	mov    r11,QWORD PTR [r12+0x398]
 23c:	mov    QWORD PTR [rsp],r11
 240:	jmp    0xa3
 245:	nop
 246:	nop
 247:	nop
