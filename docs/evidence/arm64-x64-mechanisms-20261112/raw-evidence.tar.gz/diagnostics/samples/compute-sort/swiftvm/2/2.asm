
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sort/swiftvm/2/2.bin:     file format binary


Disassembly of section .data:

0000765defefe2f0 <.data>:
    765defefe2f0:	sub    rsp,0x10
    765defefe2f4:	mov    r11,QWORD PTR [r12+0x398]
    765defefe2fc:	mov    QWORD PTR [rsp],r11
    765defefe300:	mov    r13,QWORD PTR [r12+0xa0]
    765defefe308:	mov    r14,r13
    765defefe30b:	shl    r14,0x2
    765defefe30f:	mov    r15,QWORD PTR [r12+0x98]
    765defefe317:	mov    rcx,r14
    765defefe31a:	add    r15,rcx
    765defefe31d:	mov    r14d,DWORD PTR [r12]
    765defefe321:	mov    DWORD PTR [r15],r14d
    765defefe324:	mov    r14d,0x0
    765defefe32a:	mov    DWORD PTR [r12+0x32c],r14d
    765defefe332:	add    r13,0x1
    765defefe336:	mov    QWORD PTR [r12+0xa0],r13
    765defefe33e:	sub    r13,0x400
    765defefe345:	mov    rcx,QWORD PTR [r12+0x380]
    765defefe34d:	jrcxz  0x765defefe354
    765defefe34f:	jmp    0x765defefe74d
    765defefe354:	pushf
    765defefe355:	pop    r11
    765defefe357:	mov    QWORD PTR [rsp],r11
    765defefe35b:	jne    0x765defefe6de
    765defefe361:	jmp    0x765defefe366
    765defefe366:	mov    r13d,0x1
    765defefe36c:	mov    QWORD PTR [r12+0x40],r13
    765defefe371:	jmp    0x765defefe376
    765defefe376:	mov    r13,QWORD PTR [r12+0x40]
    765defefe37b:	mov    r14,r13
    765defefe37e:	shl    r14,0x2
    765defefe382:	mov    r15,QWORD PTR [r12+0x98]
    765defefe38a:	mov    rcx,r14
    765defefe38d:	add    r15,rcx
    765defefe390:	mov    r14d,DWORD PTR [r15]
    765defefe393:	mov    QWORD PTR [r12+0x48],r14
    765defefe398:	mov    r14d,0x0
    765defefe39e:	mov    rcx,r13
    765defefe3a1:	or     r14,rcx
    765defefe3a4:	mov    QWORD PTR [r12+0x50],r14
    765defefe3a9:	jmp    0x765defefe3ae
    765defefe3ae:	mov    r13d,DWORD PTR [r12+0x50]
    765defefe3b3:	sub    r13d,0x1
    765defefe3b7:	mov    QWORD PTR [r12+0x58],r13
    765defefe3bc:	mov    ecx,0xffffffff
    765defefe3c1:	mov    r14,r13
    765defefe3c4:	and    r14,rcx
    765defefe3c7:	shl    r14,0x2
    765defefe3cb:	mov    r13,QWORD PTR [r12+0x98]
    765defefe3d3:	mov    rcx,r14
    765defefe3d6:	add    r13,rcx
    765defefe3d9:	mov    r14d,DWORD PTR [r13+0x0]
    765defefe3dd:	mov    QWORD PTR [r12+0x60],r14
    765defefe3e2:	mov    r13d,DWORD PTR [r12+0x48]
    765defefe3e7:	mov    ecx,r13d
    765defefe3ea:	sub    r14d,ecx
    765defefe3ed:	mov    rcx,QWORD PTR [r12+0x380]
    765defefe3f5:	jrcxz  0x765defefe3fc
    765defefe3f7:	jmp    0x765defefe7dc
    765defefe3fc:	sete   al
    765defefe3ff:	movzx  eax,al
    765defefe402:	mov    r13,rax
    765defefe405:	setb   al
    765defefe408:	movzx  eax,al
    765defefe40b:	mov    r14,rax
    765defefe40e:	pushf
    765defefe40f:	pop    r11
    765defefe411:	mov    QWORD PTR [rsp],r11
    765defefe415:	mov    rcx,r13
    765defefe418:	and    ecx,0xff
    765defefe41e:	mov    r15,r14
    765defefe421:	and    r15d,0xff
    765defefe428:	or     r15,rcx
    765defefe42b:	and    r15d,0xff
    765defefe432:	mov    rax,r15
    765defefe435:	and    eax,0xff
    765defefe43a:	test   rax,rax
    765defefe43d:	jne    0x765defefe4df
    765defefe443:	jmp    0x765defefe448
    765defefe448:	mov    r13,QWORD PTR [r12+0x50]
    765defefe44d:	mov    r14,r13
    765defefe450:	shl    r14,0x2
    765defefe454:	mov    r15,QWORD PTR [r12+0x98]
    765defefe45c:	mov    rcx,r14
    765defefe45f:	add    r15,rcx
    765defefe462:	mov    r14d,DWORD PTR [r12+0x60]
    765defefe467:	mov    DWORD PTR [r15],r14d
    765defefe46a:	mov    r14d,0x0
    765defefe470:	mov    DWORD PTR [r12+0x32c],r14d
    765defefe478:	sub    r13,0x1
    765defefe47c:	mov    QWORD PTR [r12+0x50],r13
    765defefe481:	mov    rcx,QWORD PTR [r12+0x380]
    765defefe489:	jrcxz  0x765defefe490
    765defefe48b:	jmp    0x765defefe86b
    765defefe490:	mov    r13,QWORD PTR [r12+0x58]
    765defefe495:	mov    rax,r13
    765defefe498:	test   rax,rax
    765defefe49b:	setne  al
    765defefe49e:	movzx  eax,al
    765defefe4a1:	and    eax,0x1
    765defefe4a4:	mov    r14,rax
    765defefe4a7:	mov    rax,r14
    765defefe4aa:	and    eax,0x1
    765defefe4ad:	test   rax,rax
    765defefe4b0:	jne    0x765defefe3ae
    765defefe4b6:	jmp    0x765defefe4bb
    765defefe4bb:	mov    rcx,QWORD PTR [r12+0x380]
    765defefe4c3:	jrcxz  0x765defefe4ca
    765defefe4c5:	jmp    0x765defefe8f2
    765defefe4ca:	jmp    0x765defefe4cf
    765defefe4cf:	mov    r13d,0x0
    765defefe4d5:	mov    QWORD PTR [r12+0x50],r13
    765defefe4da:	jmp    0x765defefe4df
    765defefe4df:	mov    r13,QWORD PTR [r12+0x40]
    765defefe4e4:	add    r13,0x1
    765defefe4e8:	mov    QWORD PTR [r12+0x40],r13
    765defefe4ed:	mov    r14,QWORD PTR [r12+0x50]
    765defefe4f2:	mov    ecx,0xffffffff
    765defefe4f7:	and    r14,rcx
    765defefe4fa:	shl    r14,0x2
    765defefe4fe:	mov    r15,QWORD PTR [r12+0x98]
    765defefe506:	mov    rcx,r14
    765defefe509:	add    r15,rcx
    765defefe50c:	mov    r14d,DWORD PTR [r12+0x48]
    765defefe511:	mov    DWORD PTR [r15],r14d
    765defefe514:	mov    r14d,0x0
    765defefe51a:	mov    DWORD PTR [r12+0x32c],r14d
    765defefe522:	sub    r13,0x400
    765defefe529:	pushf
    765defefe52a:	pop    r11
    765defefe52c:	mov    QWORD PTR [rsp],r11
    765defefe530:	je     0x765defefe53b
    765defefe536:	jmp    0x765defefe376
    765defefe53b:	mov    r13d,0x420000
    765defefe541:	mov    QWORD PTR [r12+0x40],r13
    765defefe546:	mov    r13d,0x0
    765defefe54c:	mov    QWORD PTR [r12+0x58],r13
    765defefe551:	mov    r13d,0x0
    765defefe557:	mov    QWORD PTR [r12+0x50],r13
    765defefe55c:	mov    r13d,0x420288
    765defefe562:	mov    r14,QWORD PTR [r13+0x0]
    765defefe566:	mov    QWORD PTR [r12+0x48],r14
    765defefe56b:	jmp    0x765defefe570
    765defefe570:	mov    r13,QWORD PTR [r12+0x58]
    765defefe575:	mov    r14,r13
    765defefe578:	shl    r14,0x2
    765defefe57c:	mov    r15,QWORD PTR [r12+0x98]
    765defefe584:	mov    rcx,r14
    765defefe587:	add    r15,rcx
    765defefe58a:	mov    QWORD PTR [r12+0x60],r15
    765defefe58f:	mov    r14,r15
    765defefe592:	add    r14,0x4
    765defefe596:	mov    ebp,DWORD PTR [r15]
    765defefe599:	mov    r15d,DWORD PTR [r14]
    765defefe59c:	mov    QWORD PTR [r12+0x60],r15
    765defefe5a1:	mov    rax,rbp
    765defefe5a4:	mov    rcx,r13
    765defefe5a7:	imul   rax,rcx
    765defefe5ab:	mov    r14,rax
    765defefe5ae:	mov    rcx,r14
    765defefe5b1:	mov    r8,rbp
    765defefe5b4:	add    r8,rcx
    765defefe5b7:	mov    QWORD PTR [r12+0x68],r8
    765defefe5bc:	add    r13,0x2
    765defefe5c0:	mov    QWORD PTR [r12+0x58],r13
    765defefe5c5:	mov    r14,r13
    765defefe5c8:	sub    r14,0x400
    765defefe5cf:	mov    r14,QWORD PTR [r12+0x50]
    765defefe5d4:	pushf
    765defefe5d5:	pop    r11
    765defefe5d7:	mov    QWORD PTR [rsp],r11
    765defefe5db:	mov    rax,r13
    765defefe5de:	mov    rcx,r15
    765defefe5e1:	imul   rax,rcx
    765defefe5e5:	mov    rbp,rax
    765defefe5e8:	mov    rcx,rbp
    765defefe5eb:	add    r14,rcx
    765defefe5ee:	mov    QWORD PTR [r12+0x50],r14
    765defefe5f3:	mov    r13,QWORD PTR [r12+0x48]
    765defefe5f8:	mov    rcx,r13
    765defefe5fb:	add    r8,rcx
    765defefe5fe:	mov    QWORD PTR [r12+0x48],r8
    765defefe603:	mov    rcx,QWORD PTR [r12+0x380]
    765defefe60b:	jrcxz  0x765defefe612
    765defefe60d:	jmp    0x765defefe979
    765defefe612:	push   QWORD PTR [rsp]
    765defefe615:	popf
    765defefe616:	jne    0x765defefe570
    765defefe61c:	jmp    0x765defefe621
    765defefe621:	mov    r13,QWORD PTR [r12+0xf8]
    765defefe629:	mov    r14,r13
    765defefe62c:	add    r14,0x10
    765defefe630:	mov    r15,r14
    765defefe633:	add    r15,0x8
    765defefe637:	mov    rbp,QWORD PTR [r14]
    765defefe63a:	mov    r14,QWORD PTR [r15]
    765defefe63d:	mov    QWORD PTR [r12+0xa0],rbp
    765defefe645:	mov    QWORD PTR [r12+0x98],r14
    765defefe64d:	mov    r14,QWORD PTR [r12+0x48]
    765defefe652:	mov    r15,QWORD PTR [r12+0x50]
    765defefe657:	mov    rcx,r14
    765defefe65a:	add    r15,rcx
    765defefe65d:	mov    QWORD PTR [r12+0x48],r15
    765defefe662:	mov    r14,QWORD PTR [r12+0x40]
    765defefe667:	add    r14,0x288
    765defefe66e:	mov    QWORD PTR [r14],r15
    765defefe671:	mov    r14d,0x0
    765defefe677:	mov    DWORD PTR [r12+0x32c],r14d
    765defefe67f:	mov    r14,r13
    765defefe682:	add    r14,0x20
    765defefe686:	mov    r15,QWORD PTR [r13+0x0]
    765defefe68a:	mov    QWORD PTR [r12+0xf0],r15
    765defefe692:	mov    QWORD PTR [r12+0xf8],r14
    765defefe69a:	mov    rcx,QWORD PTR [r12+0x380]
    765defefe6a2:	jrcxz  0x765defefe6a9
    765defefe6a4:	jmp    0x765defefea00
    765defefe6a9:	mov    r13,QWORD PTR [r12+0xf0]
    765defefe6b1:	mov    QWORD PTR [r12+0x100],r13
    765defefe6b9:	mov    r11,QWORD PTR [rsp]
    765defefe6bd:	mov    QWORD PTR [r12+0x398],r11
    765defefe6c5:	mov    rdi,QWORD PTR [r12+0x100]
    765defefe6cd:	add    rsp,0x10
    765defefe6d1:	movabs r11,0x5c12b40a60a0
    765defefe6db:	jmp    r11
    765defefe6de:	mov    r13d,DWORD PTR [r12+0xa0]
    765defefe6e6:	add    r13d,0x11
    765defefe6ea:	mov    QWORD PTR [r12],r13
    765defefe6ee:	mov    r13d,0x410184
    765defefe6f4:	mov    QWORD PTR [r12+0xf0],r13
    765defefe6fc:	mov    r13d,0x41021c
    765defefe702:	mov    QWORD PTR [r12+0x100],r13
    765defefe70a:	mov    r11,QWORD PTR [rsp]
    765defefe70e:	mov    QWORD PTR [r12+0x398],r11
    765defefe716:	mov    edi,0x41021c
    765defefe71b:	mov    QWORD PTR [r12+0x100],rdi
    765defefe723:	add    rsp,0x10
    765defefe727:	nop
    765defefe728:	jmp    QWORD PTR [rip+0x2]        # 0x765defefe730
    765defefe72e:	xchg   ax,ax
    765defefe730:	adc    cl,ah
    765defefe732:	out    dx,eax
    765defefe733:	out    dx,eax
    765defefe734:	pop    rbp
    765defefe735:	jbe    0x765defefe737
    765defefe737:	add    BYTE PTR [rax-0x19],al
    765defefe73a:	out    dx,eax
    765defefe73b:	out    dx,eax
    765defefe73c:	pop    rbp
    765defefe73d:	jbe    0x765defefe73f
    765defefe73f:	add    BYTE PTR [rcx-0x45],cl
    765defefe742:	movabs al,ds:0x4100005c12b40a60
    765defefe74b:	jmp    rbx
    765defefe74d:	mov    eax,0x410190
    765defefe752:	mov    QWORD PTR [r12+0x100],rax
    765defefe75a:	push   rdx
    765defefe75b:	push   rsi
    765defefe75c:	push   r10
    765defefe75e:	push   r11
    765defefe760:	pushf
    765defefe761:	pop    r11
    765defefe763:	mov    QWORD PTR [rsp+0x20],r11
    765defefe768:	mov    rdx,QWORD PTR [rsp+0x20]
    765defefe76d:	mov    r10d,edx
    765defefe770:	and    r10d,0xc0
    765defefe777:	shl    r10d,0x18
    765defefe77b:	mov    r11d,edx
    765defefe77e:	and    r11d,0x1
    765defefe782:	shl    r11d,0x1d
    765defefe786:	or     r10d,r11d
    765defefe789:	mov    r11d,edx
    765defefe78c:	and    r11d,0x800
    765defefe793:	shl    r11d,0x11
    765defefe797:	or     r10d,r11d
    765defefe79a:	btc    r10,0x1d
    765defefe79f:	mov    r11d,0xf0000000
    765defefe7a5:	and    r11,r10
    765defefe7a8:	movabs rsi,0xffffffff0fffffff
    765defefe7b2:	and    rbx,rsi
    765defefe7b5:	or     rbx,r11
    765defefe7b8:	pop    r11
    765defefe7ba:	pop    r10
    765defefe7bc:	pop    rsi
    765defefe7bd:	pop    rdx
    765defefe7be:	mov    QWORD PTR [r12+0x108],rbx
    765defefe7c6:	add    rsp,0x10
    765defefe7ca:	mov    eax,0xc
    765defefe7cf:	movabs r11,0x5c12b40a6390
    765defefe7d9:	jmp    r11
    765defefe7dc:	mov    eax,0x4101c4
    765defefe7e1:	mov    QWORD PTR [r12+0x100],rax
    765defefe7e9:	push   rdx
    765defefe7ea:	push   rsi
    765defefe7eb:	push   r10
    765defefe7ed:	push   r11
    765defefe7ef:	pushf
    765defefe7f0:	pop    r11
    765defefe7f2:	mov    QWORD PTR [rsp+0x20],r11
    765defefe7f7:	mov    rdx,QWORD PTR [rsp+0x20]
    765defefe7fc:	mov    r10d,edx
    765defefe7ff:	and    r10d,0xc0
    765defefe806:	shl    r10d,0x18
    765defefe80a:	mov    r11d,edx
    765defefe80d:	and    r11d,0x1
    765defefe811:	shl    r11d,0x1d
    765defefe815:	or     r10d,r11d
    765defefe818:	mov    r11d,edx
    765defefe81b:	and    r11d,0x800
    765defefe822:	shl    r11d,0x11
    765defefe826:	or     r10d,r11d
    765defefe829:	btc    r10,0x1d
    765defefe82e:	mov    r11d,0xf0000000
    765defefe834:	and    r11,r10
    765defefe837:	movabs rsi,0xffffffff0fffffff
    765defefe841:	and    rbx,rsi
    765defefe844:	or     rbx,r11
    765defefe847:	pop    r11
    765defefe849:	pop    r10
    765defefe84b:	pop    rsi
    765defefe84c:	pop    rdx
    765defefe84d:	mov    QWORD PTR [r12+0x108],rbx
    765defefe855:	add    rsp,0x10
    765defefe859:	mov    eax,0xc
    765defefe85e:	movabs r11,0x5c12b40a6390
    765defefe868:	jmp    r11
    765defefe86b:	mov    eax,0x4101d0
    765defefe870:	mov    QWORD PTR [r12+0x100],rax
    765defefe878:	push   rdx
    765defefe879:	push   rsi
    765defefe87a:	push   r10
    765defefe87c:	push   r11
    765defefe87e:	mov    rdx,QWORD PTR [rsp+0x20]
    765defefe883:	mov    r10d,edx
    765defefe886:	and    r10d,0xc0
    765defefe88d:	shl    r10d,0x18
    765defefe891:	mov    r11d,edx
    765defefe894:	and    r11d,0x1
    765defefe898:	shl    r11d,0x1d
    765defefe89c:	or     r10d,r11d
    765defefe89f:	mov    r11d,edx
    765defefe8a2:	and    r11d,0x800
    765defefe8a9:	shl    r11d,0x11
    765defefe8ad:	or     r10d,r11d
    765defefe8b0:	btc    r10,0x1d
    765defefe8b5:	mov    r11d,0xf0000000
    765defefe8bb:	and    r11,r10
    765defefe8be:	movabs rsi,0xffffffff0fffffff
    765defefe8c8:	and    rbx,rsi
    765defefe8cb:	or     rbx,r11
    765defefe8ce:	pop    r11
    765defefe8d0:	pop    r10
    765defefe8d2:	pop    rsi
    765defefe8d3:	pop    rdx
    765defefe8d4:	mov    QWORD PTR [r12+0x108],rbx
    765defefe8dc:	add    rsp,0x10
    765defefe8e0:	mov    eax,0xc
    765defefe8e5:	movabs r11,0x5c12b40a6390
    765defefe8ef:	jmp    r11
    765defefe8f2:	mov    eax,0x4101d4
    765defefe8f7:	mov    QWORD PTR [r12+0x100],rax
    765defefe8ff:	push   rdx
    765defefe900:	push   rsi
    765defefe901:	push   r10
    765defefe903:	push   r11
    765defefe905:	mov    rdx,QWORD PTR [rsp+0x20]
    765defefe90a:	mov    r10d,edx
    765defefe90d:	and    r10d,0xc0
    765defefe914:	shl    r10d,0x18
    765defefe918:	mov    r11d,edx
    765defefe91b:	and    r11d,0x1
    765defefe91f:	shl    r11d,0x1d
    765defefe923:	or     r10d,r11d
    765defefe926:	mov    r11d,edx
    765defefe929:	and    r11d,0x800
    765defefe930:	shl    r11d,0x11
    765defefe934:	or     r10d,r11d
    765defefe937:	btc    r10,0x1d
    765defefe93c:	mov    r11d,0xf0000000
    765defefe942:	and    r11,r10
    765defefe945:	movabs rsi,0xffffffff0fffffff
    765defefe94f:	and    rbx,rsi
    765defefe952:	or     rbx,r11
    765defefe955:	pop    r11
    765defefe957:	pop    r10
    765defefe959:	pop    rsi
    765defefe95a:	pop    rdx
    765defefe95b:	mov    QWORD PTR [r12+0x108],rbx
    765defefe963:	add    rsp,0x10
    765defefe967:	mov    eax,0xc
    765defefe96c:	movabs r11,0x5c12b40a6390
    765defefe976:	jmp    r11
    765defefe979:	mov    eax,0x410204
    765defefe97e:	mov    QWORD PTR [r12+0x100],rax
    765defefe986:	push   rdx
    765defefe987:	push   rsi
    765defefe988:	push   r10
    765defefe98a:	push   r11
    765defefe98c:	mov    rdx,QWORD PTR [rsp+0x20]
    765defefe991:	mov    r10d,edx
    765defefe994:	and    r10d,0xc0
    765defefe99b:	shl    r10d,0x18
    765defefe99f:	mov    r11d,edx
    765defefe9a2:	and    r11d,0x1
    765defefe9a6:	shl    r11d,0x1d
    765defefe9aa:	or     r10d,r11d
    765defefe9ad:	mov    r11d,edx
    765defefe9b0:	and    r11d,0x800
    765defefe9b7:	shl    r11d,0x11
    765defefe9bb:	or     r10d,r11d
    765defefe9be:	btc    r10,0x1d
    765defefe9c3:	mov    r11d,0xf0000000
    765defefe9c9:	and    r11,r10
    765defefe9cc:	movabs rsi,0xffffffff0fffffff
    765defefe9d6:	and    rbx,rsi
    765defefe9d9:	or     rbx,r11
    765defefe9dc:	pop    r11
    765defefe9de:	pop    r10
    765defefe9e0:	pop    rsi
    765defefe9e1:	pop    rdx
    765defefe9e2:	mov    QWORD PTR [r12+0x108],rbx
    765defefe9ea:	add    rsp,0x10
    765defefe9ee:	mov    eax,0xc
    765defefe9f3:	movabs r11,0x5c12b40a6390
    765defefe9fd:	jmp    r11
    765defefea00:	mov    eax,0x410218
    765defefea05:	mov    QWORD PTR [r12+0x100],rax
    765defefea0d:	push   rdx
    765defefea0e:	push   rsi
    765defefea0f:	push   r10
    765defefea11:	push   r11
    765defefea13:	mov    rdx,QWORD PTR [rsp+0x20]
    765defefea18:	mov    r10d,edx
    765defefea1b:	and    r10d,0xc0
    765defefea22:	shl    r10d,0x18
    765defefea26:	mov    r11d,edx
    765defefea29:	and    r11d,0x1
    765defefea2d:	shl    r11d,0x1d
    765defefea31:	or     r10d,r11d
    765defefea34:	mov    r11d,edx
    765defefea37:	and    r11d,0x800
    765defefea3e:	shl    r11d,0x11
    765defefea42:	or     r10d,r11d
    765defefea45:	btc    r10,0x1d
    765defefea4a:	mov    r11d,0xf0000000
    765defefea50:	and    r11,r10
    765defefea53:	movabs rsi,0xffffffff0fffffff
    765defefea5d:	and    rbx,rsi
    765defefea60:	or     rbx,r11
    765defefea63:	pop    r11
    765defefea65:	pop    r10
    765defefea67:	pop    rsi
    765defefea68:	pop    rdx
    765defefea69:	mov    QWORD PTR [r12+0x108],rbx
    765defefea71:	add    rsp,0x10
    765defefea75:	mov    eax,0xc
    765defefea7a:	movabs r11,0x5c12b40a6390
    765defefea84:	jmp    r11
    765defefea87:	nop    WORD PTR [rax+rax*1+0x0]
    765defefea90:	sub    rsp,0x10
    765defefea94:	mov    r11,QWORD PTR [r12+0x398]
    765defefea9c:	mov    QWORD PTR [rsp],r11
    765defefeaa0:	jmp    0x765defefe366
    765defefeaa5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefeab0:	sub    rsp,0x10
    765defefeab4:	mov    r11,QWORD PTR [r12+0x398]
    765defefeabc:	mov    QWORD PTR [rsp],r11
    765defefeac0:	jmp    0x765defefe376
    765defefeac5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefead0:	sub    rsp,0x10
    765defefead4:	mov    r11,QWORD PTR [r12+0x398]
    765defefeadc:	mov    QWORD PTR [rsp],r11
    765defefeae0:	jmp    0x765defefe3ae
    765defefeae5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefeaf0:	sub    rsp,0x10
    765defefeaf4:	mov    r11,QWORD PTR [r12+0x398]
    765defefeafc:	mov    QWORD PTR [rsp],r11
    765defefeb00:	jmp    0x765defefe448
    765defefeb05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefeb10:	sub    rsp,0x10
    765defefeb14:	mov    r11,QWORD PTR [r12+0x398]
    765defefeb1c:	mov    QWORD PTR [rsp],r11
    765defefeb20:	jmp    0x765defefe4bb
    765defefeb25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefeb30:	sub    rsp,0x10
    765defefeb34:	mov    r11,QWORD PTR [r12+0x398]
    765defefeb3c:	mov    QWORD PTR [rsp],r11
    765defefeb40:	jmp    0x765defefe4cf
    765defefeb45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefeb50:	sub    rsp,0x10
    765defefeb54:	mov    r11,QWORD PTR [r12+0x398]
    765defefeb5c:	mov    QWORD PTR [rsp],r11
    765defefeb60:	jmp    0x765defefe4df
    765defefeb65:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefeb70:	sub    rsp,0x10
    765defefeb74:	mov    r11,QWORD PTR [r12+0x398]
    765defefeb7c:	mov    QWORD PTR [rsp],r11
    765defefeb80:	jmp    0x765defefe53b
    765defefeb85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefeb90:	sub    rsp,0x10
    765defefeb94:	mov    r11,QWORD PTR [r12+0x398]
    765defefeb9c:	mov    QWORD PTR [rsp],r11
    765defefeba0:	jmp    0x765defefe570
    765defefeba5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefebb0:	sub    rsp,0x10
    765defefebb4:	mov    r11,QWORD PTR [r12+0x398]
    765defefebbc:	mov    QWORD PTR [rsp],r11
    765defefebc0:	jmp    0x765defefe621
    765defefebc5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    765defefebd0:	sub    rsp,0x10
    765defefebd4:	mov    r11,QWORD PTR [r12+0x398]
    765defefebdc:	mov    QWORD PTR [rsp],r11
    765defefebe0:	jmp    0x765defefe6de
    765defefebe5:	nop
    765defefebe6:	nop
    765defefebe7:	nop
