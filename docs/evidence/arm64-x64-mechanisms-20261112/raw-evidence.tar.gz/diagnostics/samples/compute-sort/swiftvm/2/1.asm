
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sort/swiftvm/2/1.bin:     file format binary


Disassembly of section .data:

0000765defefe110 <.data>:
    765defefe110:	sub    rsp,0x10
    765defefe114:	mov    r11,QWORD PTR [r12+0x398]
    765defefe11c:	mov    QWORD PTR [rsp],r11
    765defefe120:	mov    r13d,0x352d
    765defefe126:	mov    QWORD PTR [r12+0x40],r13
    765defefe12b:	mov    r13d,0xa68b
    765defefe131:	mov    QWORD PTR [r12+0x48],r13
    765defefe136:	mov    r13d,0x352d
    765defefe13c:	mov    r14d,0x7feb
    765defefe142:	and    r14d,0xffff
    765defefe149:	mov    rax,r13
    765defefe14c:	movabs rcx,0xffffffff0000ffff
    765defefe156:	and    rax,rcx
    765defefe159:	mov    rdx,r14
    765defefe15c:	shl    rdx,0x10
    765defefe160:	mov    ecx,0xffff0000
    765defefe165:	and    rdx,rcx
    765defefe168:	or     rax,rdx
    765defefe16b:	mov    r15d,eax
    765defefe16e:	mov    QWORD PTR [r12+0x40],r15
    765defefe173:	mov    r13d,0xa68b
    765defefe179:	mov    r14d,0x846c
    765defefe17f:	and    r14d,0xffff
    765defefe186:	mov    rax,r13
    765defefe189:	movabs rcx,0xffffffff0000ffff
    765defefe193:	and    rax,rcx
    765defefe196:	mov    rdx,r14
    765defefe199:	shl    rdx,0x10
    765defefe19d:	mov    ecx,0xffff0000
    765defefe1a2:	and    rdx,rcx
    765defefe1a5:	or     rax,rdx
    765defefe1a8:	mov    ebp,eax
    765defefe1aa:	mov    QWORD PTR [r12+0x48],rbp
    765defefe1af:	mov    r13d,DWORD PTR [r12]
    765defefe1b3:	mov    r14d,0x0
    765defefe1b9:	mov    eax,r13d
    765defefe1bc:	mov    ecx,r15d
    765defefe1bf:	imul   rax,rcx
    765defefe1c3:	mov    r8d,eax
    765defefe1c6:	mov    ecx,r8d
    765defefe1c9:	mov    r13d,r14d
    765defefe1cc:	add    r13d,ecx
    765defefe1cf:	mov    QWORD PTR [r12+0x40],r13
    765defefe1d4:	mov    r14d,r13d
    765defefe1d7:	mov    r14d,r14d
    765defefe1da:	shr    r14d,0xf
    765defefe1de:	mov    ecx,r14d
    765defefe1e1:	xor    r13,rcx
    765defefe1e4:	mov    r13d,r13d
    765defefe1e7:	mov    QWORD PTR [r12+0x40],r13
    765defefe1ec:	mov    r14d,0x0
    765defefe1f2:	mov    eax,r13d
    765defefe1f5:	mov    ecx,ebp
    765defefe1f7:	imul   rax,rcx
    765defefe1fb:	mov    r15d,eax
    765defefe1fe:	mov    ecx,r15d
    765defefe201:	mov    r13d,r14d
    765defefe204:	add    r13d,ecx
    765defefe207:	mov    QWORD PTR [r12+0x40],r13
    765defefe20c:	mov    r14d,r13d
    765defefe20f:	mov    r14d,r14d
    765defefe212:	shr    r14d,0x10
    765defefe216:	mov    ecx,r14d
    765defefe219:	xor    r13,rcx
    765defefe21c:	mov    r13d,r13d
    765defefe21f:	mov    QWORD PTR [r12],r13
    765defefe223:	mov    rcx,QWORD PTR [r12+0x380]
    765defefe22b:	jrcxz  0x765defefe232
    765defefe22d:	jmp    0x765defefe267
    765defefe232:	mov    r13,QWORD PTR [r12+0xf0]
    765defefe23a:	mov    QWORD PTR [r12+0x100],r13
    765defefe242:	mov    r11,QWORD PTR [rsp]
    765defefe246:	mov    QWORD PTR [r12+0x398],r11
    765defefe24e:	mov    rdi,QWORD PTR [r12+0x100]
    765defefe256:	add    rsp,0x10
    765defefe25a:	movabs r11,0x5c12b40a60a0
    765defefe264:	jmp    r11
    765defefe267:	mov    eax,0x41023c
    765defefe26c:	mov    QWORD PTR [r12+0x100],rax
    765defefe274:	push   rdx
    765defefe275:	push   rsi
    765defefe276:	push   r10
    765defefe278:	push   r11
    765defefe27a:	mov    rdx,QWORD PTR [rsp+0x20]
    765defefe27f:	mov    r10d,edx
    765defefe282:	and    r10d,0xc0
    765defefe289:	shl    r10d,0x18
    765defefe28d:	mov    r11d,edx
    765defefe290:	and    r11d,0x1
    765defefe294:	shl    r11d,0x1d
    765defefe298:	or     r10d,r11d
    765defefe29b:	mov    r11d,edx
    765defefe29e:	and    r11d,0x800
    765defefe2a5:	shl    r11d,0x11
    765defefe2a9:	or     r10d,r11d
    765defefe2ac:	btc    r10,0x1d
    765defefe2b1:	mov    r11d,0xf0000000
    765defefe2b7:	and    r11,r10
    765defefe2ba:	movabs rsi,0xffffffff0fffffff
    765defefe2c4:	and    rbx,rsi
    765defefe2c7:	or     rbx,r11
    765defefe2ca:	pop    r11
    765defefe2cc:	pop    r10
    765defefe2ce:	pop    rsi
    765defefe2cf:	pop    rdx
    765defefe2d0:	mov    QWORD PTR [r12+0x108],rbx
    765defefe2d8:	add    rsp,0x10
    765defefe2dc:	mov    eax,0xc
    765defefe2e1:	movabs r11,0x5c12b40a6390
    765defefe2eb:	jmp    r11
    765defefe2ee:	nop
    765defefe2ef:	nop
