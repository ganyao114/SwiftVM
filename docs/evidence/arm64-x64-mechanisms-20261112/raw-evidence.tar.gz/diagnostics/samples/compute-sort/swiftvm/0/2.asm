
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sort/swiftvm/0/2.bin:     file format binary


Disassembly of section .data:

000072e641efe2f0 <.data>:
    72e641efe2f0:	sub    rsp,0x10
    72e641efe2f4:	mov    r11,QWORD PTR [r12+0x398]
    72e641efe2fc:	mov    QWORD PTR [rsp],r11
    72e641efe300:	mov    r13,QWORD PTR [r12+0xa0]
    72e641efe308:	mov    r14,r13
    72e641efe30b:	shl    r14,0x2
    72e641efe30f:	mov    r15,QWORD PTR [r12+0x98]
    72e641efe317:	mov    rcx,r14
    72e641efe31a:	add    r15,rcx
    72e641efe31d:	mov    r14d,DWORD PTR [r12]
    72e641efe321:	mov    DWORD PTR [r15],r14d
    72e641efe324:	mov    r14d,0x0
    72e641efe32a:	mov    DWORD PTR [r12+0x32c],r14d
    72e641efe332:	add    r13,0x1
    72e641efe336:	mov    QWORD PTR [r12+0xa0],r13
    72e641efe33e:	sub    r13,0x400
    72e641efe345:	mov    rcx,QWORD PTR [r12+0x380]
    72e641efe34d:	jrcxz  0x72e641efe354
    72e641efe34f:	jmp    0x72e641efe74d
    72e641efe354:	pushf
    72e641efe355:	pop    r11
    72e641efe357:	mov    QWORD PTR [rsp],r11
    72e641efe35b:	jne    0x72e641efe6de
    72e641efe361:	jmp    0x72e641efe366
    72e641efe366:	mov    r13d,0x1
    72e641efe36c:	mov    QWORD PTR [r12+0x40],r13
    72e641efe371:	jmp    0x72e641efe376
    72e641efe376:	mov    r13,QWORD PTR [r12+0x40]
    72e641efe37b:	mov    r14,r13
    72e641efe37e:	shl    r14,0x2
    72e641efe382:	mov    r15,QWORD PTR [r12+0x98]
    72e641efe38a:	mov    rcx,r14
    72e641efe38d:	add    r15,rcx
    72e641efe390:	mov    r14d,DWORD PTR [r15]
    72e641efe393:	mov    QWORD PTR [r12+0x48],r14
    72e641efe398:	mov    r14d,0x0
    72e641efe39e:	mov    rcx,r13
    72e641efe3a1:	or     r14,rcx
    72e641efe3a4:	mov    QWORD PTR [r12+0x50],r14
    72e641efe3a9:	jmp    0x72e641efe3ae
    72e641efe3ae:	mov    r13d,DWORD PTR [r12+0x50]
    72e641efe3b3:	sub    r13d,0x1
    72e641efe3b7:	mov    QWORD PTR [r12+0x58],r13
    72e641efe3bc:	mov    ecx,0xffffffff
    72e641efe3c1:	mov    r14,r13
    72e641efe3c4:	and    r14,rcx
    72e641efe3c7:	shl    r14,0x2
    72e641efe3cb:	mov    r13,QWORD PTR [r12+0x98]
    72e641efe3d3:	mov    rcx,r14
    72e641efe3d6:	add    r13,rcx
    72e641efe3d9:	mov    r14d,DWORD PTR [r13+0x0]
    72e641efe3dd:	mov    QWORD PTR [r12+0x60],r14
    72e641efe3e2:	mov    r13d,DWORD PTR [r12+0x48]
    72e641efe3e7:	mov    ecx,r13d
    72e641efe3ea:	sub    r14d,ecx
    72e641efe3ed:	mov    rcx,QWORD PTR [r12+0x380]
    72e641efe3f5:	jrcxz  0x72e641efe3fc
    72e641efe3f7:	jmp    0x72e641efe7dc
    72e641efe3fc:	sete   al
    72e641efe3ff:	movzx  eax,al
    72e641efe402:	mov    r13,rax
    72e641efe405:	setb   al
    72e641efe408:	movzx  eax,al
    72e641efe40b:	mov    r14,rax
    72e641efe40e:	pushf
    72e641efe40f:	pop    r11
    72e641efe411:	mov    QWORD PTR [rsp],r11
    72e641efe415:	mov    rcx,r13
    72e641efe418:	and    ecx,0xff
    72e641efe41e:	mov    r15,r14
    72e641efe421:	and    r15d,0xff
    72e641efe428:	or     r15,rcx
    72e641efe42b:	and    r15d,0xff
    72e641efe432:	mov    rax,r15
    72e641efe435:	and    eax,0xff
    72e641efe43a:	test   rax,rax
    72e641efe43d:	jne    0x72e641efe4df
    72e641efe443:	jmp    0x72e641efe448
    72e641efe448:	mov    r13,QWORD PTR [r12+0x50]
    72e641efe44d:	mov    r14,r13
    72e641efe450:	shl    r14,0x2
    72e641efe454:	mov    r15,QWORD PTR [r12+0x98]
    72e641efe45c:	mov    rcx,r14
    72e641efe45f:	add    r15,rcx
    72e641efe462:	mov    r14d,DWORD PTR [r12+0x60]
    72e641efe467:	mov    DWORD PTR [r15],r14d
    72e641efe46a:	mov    r14d,0x0
    72e641efe470:	mov    DWORD PTR [r12+0x32c],r14d
    72e641efe478:	sub    r13,0x1
    72e641efe47c:	mov    QWORD PTR [r12+0x50],r13
    72e641efe481:	mov    rcx,QWORD PTR [r12+0x380]
    72e641efe489:	jrcxz  0x72e641efe490
    72e641efe48b:	jmp    0x72e641efe86b
    72e641efe490:	mov    r13,QWORD PTR [r12+0x58]
    72e641efe495:	mov    rax,r13
    72e641efe498:	test   rax,rax
    72e641efe49b:	setne  al
    72e641efe49e:	movzx  eax,al
    72e641efe4a1:	and    eax,0x1
    72e641efe4a4:	mov    r14,rax
    72e641efe4a7:	mov    rax,r14
    72e641efe4aa:	and    eax,0x1
    72e641efe4ad:	test   rax,rax
    72e641efe4b0:	jne    0x72e641efe3ae
    72e641efe4b6:	jmp    0x72e641efe4bb
    72e641efe4bb:	mov    rcx,QWORD PTR [r12+0x380]
    72e641efe4c3:	jrcxz  0x72e641efe4ca
    72e641efe4c5:	jmp    0x72e641efe8f2
    72e641efe4ca:	jmp    0x72e641efe4cf
    72e641efe4cf:	mov    r13d,0x0
    72e641efe4d5:	mov    QWORD PTR [r12+0x50],r13
    72e641efe4da:	jmp    0x72e641efe4df
    72e641efe4df:	mov    r13,QWORD PTR [r12+0x40]
    72e641efe4e4:	add    r13,0x1
    72e641efe4e8:	mov    QWORD PTR [r12+0x40],r13
    72e641efe4ed:	mov    r14,QWORD PTR [r12+0x50]
    72e641efe4f2:	mov    ecx,0xffffffff
    72e641efe4f7:	and    r14,rcx
    72e641efe4fa:	shl    r14,0x2
    72e641efe4fe:	mov    r15,QWORD PTR [r12+0x98]
    72e641efe506:	mov    rcx,r14
    72e641efe509:	add    r15,rcx
    72e641efe50c:	mov    r14d,DWORD PTR [r12+0x48]
    72e641efe511:	mov    DWORD PTR [r15],r14d
    72e641efe514:	mov    r14d,0x0
    72e641efe51a:	mov    DWORD PTR [r12+0x32c],r14d
    72e641efe522:	sub    r13,0x400
    72e641efe529:	pushf
    72e641efe52a:	pop    r11
    72e641efe52c:	mov    QWORD PTR [rsp],r11
    72e641efe530:	je     0x72e641efe53b
    72e641efe536:	jmp    0x72e641efe376
    72e641efe53b:	mov    r13d,0x420000
    72e641efe541:	mov    QWORD PTR [r12+0x40],r13
    72e641efe546:	mov    r13d,0x0
    72e641efe54c:	mov    QWORD PTR [r12+0x58],r13
    72e641efe551:	mov    r13d,0x0
    72e641efe557:	mov    QWORD PTR [r12+0x50],r13
    72e641efe55c:	mov    r13d,0x420288
    72e641efe562:	mov    r14,QWORD PTR [r13+0x0]
    72e641efe566:	mov    QWORD PTR [r12+0x48],r14
    72e641efe56b:	jmp    0x72e641efe570
    72e641efe570:	mov    r13,QWORD PTR [r12+0x58]
    72e641efe575:	mov    r14,r13
    72e641efe578:	shl    r14,0x2
    72e641efe57c:	mov    r15,QWORD PTR [r12+0x98]
    72e641efe584:	mov    rcx,r14
    72e641efe587:	add    r15,rcx
    72e641efe58a:	mov    QWORD PTR [r12+0x60],r15
    72e641efe58f:	mov    r14,r15
    72e641efe592:	add    r14,0x4
    72e641efe596:	mov    ebp,DWORD PTR [r15]
    72e641efe599:	mov    r15d,DWORD PTR [r14]
    72e641efe59c:	mov    QWORD PTR [r12+0x60],r15
    72e641efe5a1:	mov    rax,rbp
    72e641efe5a4:	mov    rcx,r13
    72e641efe5a7:	imul   rax,rcx
    72e641efe5ab:	mov    r14,rax
    72e641efe5ae:	mov    rcx,r14
    72e641efe5b1:	mov    r8,rbp
    72e641efe5b4:	add    r8,rcx
    72e641efe5b7:	mov    QWORD PTR [r12+0x68],r8
    72e641efe5bc:	add    r13,0x2
    72e641efe5c0:	mov    QWORD PTR [r12+0x58],r13
    72e641efe5c5:	mov    r14,r13
    72e641efe5c8:	sub    r14,0x400
    72e641efe5cf:	mov    r14,QWORD PTR [r12+0x50]
    72e641efe5d4:	pushf
    72e641efe5d5:	pop    r11
    72e641efe5d7:	mov    QWORD PTR [rsp],r11
    72e641efe5db:	mov    rax,r13
    72e641efe5de:	mov    rcx,r15
    72e641efe5e1:	imul   rax,rcx
    72e641efe5e5:	mov    rbp,rax
    72e641efe5e8:	mov    rcx,rbp
    72e641efe5eb:	add    r14,rcx
    72e641efe5ee:	mov    QWORD PTR [r12+0x50],r14
    72e641efe5f3:	mov    r13,QWORD PTR [r12+0x48]
    72e641efe5f8:	mov    rcx,r13
    72e641efe5fb:	add    r8,rcx
    72e641efe5fe:	mov    QWORD PTR [r12+0x48],r8
    72e641efe603:	mov    rcx,QWORD PTR [r12+0x380]
    72e641efe60b:	jrcxz  0x72e641efe612
    72e641efe60d:	jmp    0x72e641efe979
    72e641efe612:	push   QWORD PTR [rsp]
    72e641efe615:	popf
    72e641efe616:	jne    0x72e641efe570
    72e641efe61c:	jmp    0x72e641efe621
    72e641efe621:	mov    r13,QWORD PTR [r12+0xf8]
    72e641efe629:	mov    r14,r13
    72e641efe62c:	add    r14,0x10
    72e641efe630:	mov    r15,r14
    72e641efe633:	add    r15,0x8
    72e641efe637:	mov    rbp,QWORD PTR [r14]
    72e641efe63a:	mov    r14,QWORD PTR [r15]
    72e641efe63d:	mov    QWORD PTR [r12+0xa0],rbp
    72e641efe645:	mov    QWORD PTR [r12+0x98],r14
    72e641efe64d:	mov    r14,QWORD PTR [r12+0x48]
    72e641efe652:	mov    r15,QWORD PTR [r12+0x50]
    72e641efe657:	mov    rcx,r14
    72e641efe65a:	add    r15,rcx
    72e641efe65d:	mov    QWORD PTR [r12+0x48],r15
    72e641efe662:	mov    r14,QWORD PTR [r12+0x40]
    72e641efe667:	add    r14,0x288
    72e641efe66e:	mov    QWORD PTR [r14],r15
    72e641efe671:	mov    r14d,0x0
    72e641efe677:	mov    DWORD PTR [r12+0x32c],r14d
    72e641efe67f:	mov    r14,r13
    72e641efe682:	add    r14,0x20
    72e641efe686:	mov    r15,QWORD PTR [r13+0x0]
    72e641efe68a:	mov    QWORD PTR [r12+0xf0],r15
    72e641efe692:	mov    QWORD PTR [r12+0xf8],r14
    72e641efe69a:	mov    rcx,QWORD PTR [r12+0x380]
    72e641efe6a2:	jrcxz  0x72e641efe6a9
    72e641efe6a4:	jmp    0x72e641efea00
    72e641efe6a9:	mov    r13,QWORD PTR [r12+0xf0]
    72e641efe6b1:	mov    QWORD PTR [r12+0x100],r13
    72e641efe6b9:	mov    r11,QWORD PTR [rsp]
    72e641efe6bd:	mov    QWORD PTR [r12+0x398],r11
    72e641efe6c5:	mov    rdi,QWORD PTR [r12+0x100]
    72e641efe6cd:	add    rsp,0x10
    72e641efe6d1:	movabs r11,0x5abaef4870a0
    72e641efe6db:	jmp    r11
    72e641efe6de:	mov    r13d,DWORD PTR [r12+0xa0]
    72e641efe6e6:	add    r13d,0x11
    72e641efe6ea:	mov    QWORD PTR [r12],r13
    72e641efe6ee:	mov    r13d,0x410184
    72e641efe6f4:	mov    QWORD PTR [r12+0xf0],r13
    72e641efe6fc:	mov    r13d,0x41021c
    72e641efe702:	mov    QWORD PTR [r12+0x100],r13
    72e641efe70a:	mov    r11,QWORD PTR [rsp]
    72e641efe70e:	mov    QWORD PTR [r12+0x398],r11
    72e641efe716:	mov    edi,0x41021c
    72e641efe71b:	mov    QWORD PTR [r12+0x100],rdi
    72e641efe723:	add    rsp,0x10
    72e641efe727:	nop
    72e641efe728:	jmp    QWORD PTR [rip+0x2]        # 0x72e641efe730
    72e641efe72e:	xchg   ax,ax
    72e641efe730:	adc    cl,ah
    72e641efe732:	out    dx,eax
    72e641efe733:	rex.B out 0x72,al
    72e641efe736:	add    BYTE PTR [rax],al
    72e641efe738:	rex out 0xef,eax
    72e641efe73b:	rex.B out 0x72,al
    72e641efe73e:	add    BYTE PTR [rax],al
    72e641efe740:	movabs r11,0x5abaef4870a0
    72e641efe74a:	jmp    r11
    72e641efe74d:	mov    eax,0x410190
    72e641efe752:	mov    QWORD PTR [r12+0x100],rax
    72e641efe75a:	push   rdx
    72e641efe75b:	push   rsi
    72e641efe75c:	push   r10
    72e641efe75e:	push   r11
    72e641efe760:	pushf
    72e641efe761:	pop    r11
    72e641efe763:	mov    QWORD PTR [rsp+0x20],r11
    72e641efe768:	mov    rdx,QWORD PTR [rsp+0x20]
    72e641efe76d:	mov    r10d,edx
    72e641efe770:	and    r10d,0xc0
    72e641efe777:	shl    r10d,0x18
    72e641efe77b:	mov    r11d,edx
    72e641efe77e:	and    r11d,0x1
    72e641efe782:	shl    r11d,0x1d
    72e641efe786:	or     r10d,r11d
    72e641efe789:	mov    r11d,edx
    72e641efe78c:	and    r11d,0x800
    72e641efe793:	shl    r11d,0x11
    72e641efe797:	or     r10d,r11d
    72e641efe79a:	btc    r10,0x1d
    72e641efe79f:	mov    r11d,0xf0000000
    72e641efe7a5:	and    r11,r10
    72e641efe7a8:	movabs rsi,0xffffffff0fffffff
    72e641efe7b2:	and    rbx,rsi
    72e641efe7b5:	or     rbx,r11
    72e641efe7b8:	pop    r11
    72e641efe7ba:	pop    r10
    72e641efe7bc:	pop    rsi
    72e641efe7bd:	pop    rdx
    72e641efe7be:	mov    QWORD PTR [r12+0x108],rbx
    72e641efe7c6:	add    rsp,0x10
    72e641efe7ca:	mov    eax,0xc
    72e641efe7cf:	movabs r11,0x5abaef487390
    72e641efe7d9:	jmp    r11
    72e641efe7dc:	mov    eax,0x4101c4
    72e641efe7e1:	mov    QWORD PTR [r12+0x100],rax
    72e641efe7e9:	push   rdx
    72e641efe7ea:	push   rsi
    72e641efe7eb:	push   r10
    72e641efe7ed:	push   r11
    72e641efe7ef:	pushf
    72e641efe7f0:	pop    r11
    72e641efe7f2:	mov    QWORD PTR [rsp+0x20],r11
    72e641efe7f7:	mov    rdx,QWORD PTR [rsp+0x20]
    72e641efe7fc:	mov    r10d,edx
    72e641efe7ff:	and    r10d,0xc0
    72e641efe806:	shl    r10d,0x18
    72e641efe80a:	mov    r11d,edx
    72e641efe80d:	and    r11d,0x1
    72e641efe811:	shl    r11d,0x1d
    72e641efe815:	or     r10d,r11d
    72e641efe818:	mov    r11d,edx
    72e641efe81b:	and    r11d,0x800
    72e641efe822:	shl    r11d,0x11
    72e641efe826:	or     r10d,r11d
    72e641efe829:	btc    r10,0x1d
    72e641efe82e:	mov    r11d,0xf0000000
    72e641efe834:	and    r11,r10
    72e641efe837:	movabs rsi,0xffffffff0fffffff
    72e641efe841:	and    rbx,rsi
    72e641efe844:	or     rbx,r11
    72e641efe847:	pop    r11
    72e641efe849:	pop    r10
    72e641efe84b:	pop    rsi
    72e641efe84c:	pop    rdx
    72e641efe84d:	mov    QWORD PTR [r12+0x108],rbx
    72e641efe855:	add    rsp,0x10
    72e641efe859:	mov    eax,0xc
    72e641efe85e:	movabs r11,0x5abaef487390
    72e641efe868:	jmp    r11
    72e641efe86b:	mov    eax,0x4101d0
    72e641efe870:	mov    QWORD PTR [r12+0x100],rax
    72e641efe878:	push   rdx
    72e641efe879:	push   rsi
    72e641efe87a:	push   r10
    72e641efe87c:	push   r11
    72e641efe87e:	mov    rdx,QWORD PTR [rsp+0x20]
    72e641efe883:	mov    r10d,edx
    72e641efe886:	and    r10d,0xc0
    72e641efe88d:	shl    r10d,0x18
    72e641efe891:	mov    r11d,edx
    72e641efe894:	and    r11d,0x1
    72e641efe898:	shl    r11d,0x1d
    72e641efe89c:	or     r10d,r11d
    72e641efe89f:	mov    r11d,edx
    72e641efe8a2:	and    r11d,0x800
    72e641efe8a9:	shl    r11d,0x11
    72e641efe8ad:	or     r10d,r11d
    72e641efe8b0:	btc    r10,0x1d
    72e641efe8b5:	mov    r11d,0xf0000000
    72e641efe8bb:	and    r11,r10
    72e641efe8be:	movabs rsi,0xffffffff0fffffff
    72e641efe8c8:	and    rbx,rsi
    72e641efe8cb:	or     rbx,r11
    72e641efe8ce:	pop    r11
    72e641efe8d0:	pop    r10
    72e641efe8d2:	pop    rsi
    72e641efe8d3:	pop    rdx
    72e641efe8d4:	mov    QWORD PTR [r12+0x108],rbx
    72e641efe8dc:	add    rsp,0x10
    72e641efe8e0:	mov    eax,0xc
    72e641efe8e5:	movabs r11,0x5abaef487390
    72e641efe8ef:	jmp    r11
    72e641efe8f2:	mov    eax,0x4101d4
    72e641efe8f7:	mov    QWORD PTR [r12+0x100],rax
    72e641efe8ff:	push   rdx
    72e641efe900:	push   rsi
    72e641efe901:	push   r10
    72e641efe903:	push   r11
    72e641efe905:	mov    rdx,QWORD PTR [rsp+0x20]
    72e641efe90a:	mov    r10d,edx
    72e641efe90d:	and    r10d,0xc0
    72e641efe914:	shl    r10d,0x18
    72e641efe918:	mov    r11d,edx
    72e641efe91b:	and    r11d,0x1
    72e641efe91f:	shl    r11d,0x1d
    72e641efe923:	or     r10d,r11d
    72e641efe926:	mov    r11d,edx
    72e641efe929:	and    r11d,0x800
    72e641efe930:	shl    r11d,0x11
    72e641efe934:	or     r10d,r11d
    72e641efe937:	btc    r10,0x1d
    72e641efe93c:	mov    r11d,0xf0000000
    72e641efe942:	and    r11,r10
    72e641efe945:	movabs rsi,0xffffffff0fffffff
    72e641efe94f:	and    rbx,rsi
    72e641efe952:	or     rbx,r11
    72e641efe955:	pop    r11
    72e641efe957:	pop    r10
    72e641efe959:	pop    rsi
    72e641efe95a:	pop    rdx
    72e641efe95b:	mov    QWORD PTR [r12+0x108],rbx
    72e641efe963:	add    rsp,0x10
    72e641efe967:	mov    eax,0xc
    72e641efe96c:	movabs r11,0x5abaef487390
    72e641efe976:	jmp    r11
    72e641efe979:	mov    eax,0x410204
    72e641efe97e:	mov    QWORD PTR [r12+0x100],rax
    72e641efe986:	push   rdx
    72e641efe987:	push   rsi
    72e641efe988:	push   r10
    72e641efe98a:	push   r11
    72e641efe98c:	mov    rdx,QWORD PTR [rsp+0x20]
    72e641efe991:	mov    r10d,edx
    72e641efe994:	and    r10d,0xc0
    72e641efe99b:	shl    r10d,0x18
    72e641efe99f:	mov    r11d,edx
    72e641efe9a2:	and    r11d,0x1
    72e641efe9a6:	shl    r11d,0x1d
    72e641efe9aa:	or     r10d,r11d
    72e641efe9ad:	mov    r11d,edx
    72e641efe9b0:	and    r11d,0x800
    72e641efe9b7:	shl    r11d,0x11
    72e641efe9bb:	or     r10d,r11d
    72e641efe9be:	btc    r10,0x1d
    72e641efe9c3:	mov    r11d,0xf0000000
    72e641efe9c9:	and    r11,r10
    72e641efe9cc:	movabs rsi,0xffffffff0fffffff
    72e641efe9d6:	and    rbx,rsi
    72e641efe9d9:	or     rbx,r11
    72e641efe9dc:	pop    r11
    72e641efe9de:	pop    r10
    72e641efe9e0:	pop    rsi
    72e641efe9e1:	pop    rdx
    72e641efe9e2:	mov    QWORD PTR [r12+0x108],rbx
    72e641efe9ea:	add    rsp,0x10
    72e641efe9ee:	mov    eax,0xc
    72e641efe9f3:	movabs r11,0x5abaef487390
    72e641efe9fd:	jmp    r11
    72e641efea00:	mov    eax,0x410218
    72e641efea05:	mov    QWORD PTR [r12+0x100],rax
    72e641efea0d:	push   rdx
    72e641efea0e:	push   rsi
    72e641efea0f:	push   r10
    72e641efea11:	push   r11
    72e641efea13:	mov    rdx,QWORD PTR [rsp+0x20]
    72e641efea18:	mov    r10d,edx
    72e641efea1b:	and    r10d,0xc0
    72e641efea22:	shl    r10d,0x18
    72e641efea26:	mov    r11d,edx
    72e641efea29:	and    r11d,0x1
    72e641efea2d:	shl    r11d,0x1d
    72e641efea31:	or     r10d,r11d
    72e641efea34:	mov    r11d,edx
    72e641efea37:	and    r11d,0x800
    72e641efea3e:	shl    r11d,0x11
    72e641efea42:	or     r10d,r11d
    72e641efea45:	btc    r10,0x1d
    72e641efea4a:	mov    r11d,0xf0000000
    72e641efea50:	and    r11,r10
    72e641efea53:	movabs rsi,0xffffffff0fffffff
    72e641efea5d:	and    rbx,rsi
    72e641efea60:	or     rbx,r11
    72e641efea63:	pop    r11
    72e641efea65:	pop    r10
    72e641efea67:	pop    rsi
    72e641efea68:	pop    rdx
    72e641efea69:	mov    QWORD PTR [r12+0x108],rbx
    72e641efea71:	add    rsp,0x10
    72e641efea75:	mov    eax,0xc
    72e641efea7a:	movabs r11,0x5abaef487390
    72e641efea84:	jmp    r11
    72e641efea87:	nop    WORD PTR [rax+rax*1+0x0]
    72e641efea90:	sub    rsp,0x10
    72e641efea94:	mov    r11,QWORD PTR [r12+0x398]
    72e641efea9c:	mov    QWORD PTR [rsp],r11
    72e641efeaa0:	jmp    0x72e641efe366
    72e641efeaa5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efeab0:	sub    rsp,0x10
    72e641efeab4:	mov    r11,QWORD PTR [r12+0x398]
    72e641efeabc:	mov    QWORD PTR [rsp],r11
    72e641efeac0:	jmp    0x72e641efe376
    72e641efeac5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efead0:	sub    rsp,0x10
    72e641efead4:	mov    r11,QWORD PTR [r12+0x398]
    72e641efeadc:	mov    QWORD PTR [rsp],r11
    72e641efeae0:	jmp    0x72e641efe3ae
    72e641efeae5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efeaf0:	sub    rsp,0x10
    72e641efeaf4:	mov    r11,QWORD PTR [r12+0x398]
    72e641efeafc:	mov    QWORD PTR [rsp],r11
    72e641efeb00:	jmp    0x72e641efe448
    72e641efeb05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efeb10:	sub    rsp,0x10
    72e641efeb14:	mov    r11,QWORD PTR [r12+0x398]
    72e641efeb1c:	mov    QWORD PTR [rsp],r11
    72e641efeb20:	jmp    0x72e641efe4bb
    72e641efeb25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efeb30:	sub    rsp,0x10
    72e641efeb34:	mov    r11,QWORD PTR [r12+0x398]
    72e641efeb3c:	mov    QWORD PTR [rsp],r11
    72e641efeb40:	jmp    0x72e641efe4cf
    72e641efeb45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efeb50:	sub    rsp,0x10
    72e641efeb54:	mov    r11,QWORD PTR [r12+0x398]
    72e641efeb5c:	mov    QWORD PTR [rsp],r11
    72e641efeb60:	jmp    0x72e641efe4df
    72e641efeb65:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efeb70:	sub    rsp,0x10
    72e641efeb74:	mov    r11,QWORD PTR [r12+0x398]
    72e641efeb7c:	mov    QWORD PTR [rsp],r11
    72e641efeb80:	jmp    0x72e641efe53b
    72e641efeb85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efeb90:	sub    rsp,0x10
    72e641efeb94:	mov    r11,QWORD PTR [r12+0x398]
    72e641efeb9c:	mov    QWORD PTR [rsp],r11
    72e641efeba0:	jmp    0x72e641efe570
    72e641efeba5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efebb0:	sub    rsp,0x10
    72e641efebb4:	mov    r11,QWORD PTR [r12+0x398]
    72e641efebbc:	mov    QWORD PTR [rsp],r11
    72e641efebc0:	jmp    0x72e641efe621
    72e641efebc5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e641efebd0:	sub    rsp,0x10
    72e641efebd4:	mov    r11,QWORD PTR [r12+0x398]
    72e641efebdc:	mov    QWORD PTR [rsp],r11
    72e641efebe0:	jmp    0x72e641efe6de
    72e641efebe5:	nop
    72e641efebe6:	nop
    72e641efebe7:	nop
