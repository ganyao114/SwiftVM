
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sort/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

0000765defefe000 <.data>:
    765defefe000:	sub    rsp,0x10
    765defefe004:	mov    r11,QWORD PTR [r12+0x398]
    765defefe00c:	mov    QWORD PTR [rsp],r11
    765defefe010:	mov    r13,QWORD PTR [r12+0xf8]
    765defefe018:	sub    r13,0x20
    765defefe01c:	mov    r14,QWORD PTR [r12+0xf0]
    765defefe024:	mov    QWORD PTR [r13+0x0],r14
    765defefe028:	mov    r14d,0x0
    765defefe02e:	mov    DWORD PTR [r12+0x32c],r14d
    765defefe036:	mov    QWORD PTR [r12+0xf8],r13
    765defefe03e:	add    r13,0x10
    765defefe042:	mov    r14,r13
    765defefe045:	add    r14,0x8
    765defefe049:	mov    r15,QWORD PTR [r12+0xa0]
    765defefe051:	mov    rbp,QWORD PTR [r12+0x98]
    765defefe059:	mov    QWORD PTR [r13+0x0],r15
    765defefe05d:	mov    r13d,0x0
    765defefe063:	mov    DWORD PTR [r12+0x32c],r13d
    765defefe06b:	mov    QWORD PTR [r14],rbp
    765defefe06e:	mov    r13d,0x0
    765defefe074:	mov    DWORD PTR [r12+0x32c],r13d
    765defefe07c:	mov    r13d,0x0
    765defefe082:	mov    QWORD PTR [r12+0xa0],r13
    765defefe08a:	mov    r13d,0x420000
    765defefe090:	add    r13,0x2a0
    765defefe097:	mov    QWORD PTR [r12+0x98],r13
    765defefe09f:	mov    r13d,0x11
    765defefe0a5:	mov    QWORD PTR [r12],r13
    765defefe0a9:	mov    r13d,0x410184
    765defefe0af:	mov    QWORD PTR [r12+0xf0],r13
    765defefe0b7:	mov    r13d,0x41021c
    765defefe0bd:	mov    QWORD PTR [r12+0x100],r13
    765defefe0c5:	mov    r11,QWORD PTR [rsp]
    765defefe0c9:	mov    QWORD PTR [r12+0x398],r11
    765defefe0d1:	mov    edi,0x41021c
    765defefe0d6:	mov    QWORD PTR [r12+0x100],rdi
    765defefe0de:	add    rsp,0x10
    765defefe0e2:	nop    WORD PTR [rax+rax*1+0x0]
    765defefe0e8:	jmp    QWORD PTR [rip+0x2]        # 0x765defefe0f0
    765defefe0ee:	xchg   ax,ax
    765defefe0f0:	adc    cl,ah
    765defefe0f2:	out    dx,eax
    765defefe0f3:	out    dx,eax
    765defefe0f4:	pop    rbp
    765defefe0f5:	jbe    0x765defefe0f7
    765defefe0f7:	add    BYTE PTR [rax],al
    765defefe0f9:	loope  0x765defefe0ea
    765defefe0fb:	out    dx,eax
    765defefe0fc:	pop    rbp
    765defefe0fd:	jbe    0x765defefe0ff
    765defefe0ff:	add    BYTE PTR [rcx-0x45],cl
    765defefe102:	movabs al,ds:0x4100005c12b40a60
    765defefe10b:	jmp    rbx
    765defefe10d:	nop
    765defefe10e:	nop
    765defefe10f:	nop
