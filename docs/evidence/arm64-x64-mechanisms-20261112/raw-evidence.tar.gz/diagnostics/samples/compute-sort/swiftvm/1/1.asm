
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sort/swiftvm/1/1.bin:     file format binary


Disassembly of section .data:

00007009a3ffd110 <.data>:
    7009a3ffd110:	sub    rsp,0x10
    7009a3ffd114:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffd11c:	mov    QWORD PTR [rsp],r11
    7009a3ffd120:	mov    r13d,0x352d
    7009a3ffd126:	mov    QWORD PTR [r12+0x40],r13
    7009a3ffd12b:	mov    r13d,0xa68b
    7009a3ffd131:	mov    QWORD PTR [r12+0x48],r13
    7009a3ffd136:	mov    r13d,0x352d
    7009a3ffd13c:	mov    r14d,0x7feb
    7009a3ffd142:	and    r14d,0xffff
    7009a3ffd149:	mov    rax,r13
    7009a3ffd14c:	movabs rcx,0xffffffff0000ffff
    7009a3ffd156:	and    rax,rcx
    7009a3ffd159:	mov    rdx,r14
    7009a3ffd15c:	shl    rdx,0x10
    7009a3ffd160:	mov    ecx,0xffff0000
    7009a3ffd165:	and    rdx,rcx
    7009a3ffd168:	or     rax,rdx
    7009a3ffd16b:	mov    r15d,eax
    7009a3ffd16e:	mov    QWORD PTR [r12+0x40],r15
    7009a3ffd173:	mov    r13d,0xa68b
    7009a3ffd179:	mov    r14d,0x846c
    7009a3ffd17f:	and    r14d,0xffff
    7009a3ffd186:	mov    rax,r13
    7009a3ffd189:	movabs rcx,0xffffffff0000ffff
    7009a3ffd193:	and    rax,rcx
    7009a3ffd196:	mov    rdx,r14
    7009a3ffd199:	shl    rdx,0x10
    7009a3ffd19d:	mov    ecx,0xffff0000
    7009a3ffd1a2:	and    rdx,rcx
    7009a3ffd1a5:	or     rax,rdx
    7009a3ffd1a8:	mov    ebp,eax
    7009a3ffd1aa:	mov    QWORD PTR [r12+0x48],rbp
    7009a3ffd1af:	mov    r13d,DWORD PTR [r12]
    7009a3ffd1b3:	mov    r14d,0x0
    7009a3ffd1b9:	mov    eax,r13d
    7009a3ffd1bc:	mov    ecx,r15d
    7009a3ffd1bf:	imul   rax,rcx
    7009a3ffd1c3:	mov    r8d,eax
    7009a3ffd1c6:	mov    ecx,r8d
    7009a3ffd1c9:	mov    r13d,r14d
    7009a3ffd1cc:	add    r13d,ecx
    7009a3ffd1cf:	mov    QWORD PTR [r12+0x40],r13
    7009a3ffd1d4:	mov    r14d,r13d
    7009a3ffd1d7:	mov    r14d,r14d
    7009a3ffd1da:	shr    r14d,0xf
    7009a3ffd1de:	mov    ecx,r14d
    7009a3ffd1e1:	xor    r13,rcx
    7009a3ffd1e4:	mov    r13d,r13d
    7009a3ffd1e7:	mov    QWORD PTR [r12+0x40],r13
    7009a3ffd1ec:	mov    r14d,0x0
    7009a3ffd1f2:	mov    eax,r13d
    7009a3ffd1f5:	mov    ecx,ebp
    7009a3ffd1f7:	imul   rax,rcx
    7009a3ffd1fb:	mov    r15d,eax
    7009a3ffd1fe:	mov    ecx,r15d
    7009a3ffd201:	mov    r13d,r14d
    7009a3ffd204:	add    r13d,ecx
    7009a3ffd207:	mov    QWORD PTR [r12+0x40],r13
    7009a3ffd20c:	mov    r14d,r13d
    7009a3ffd20f:	mov    r14d,r14d
    7009a3ffd212:	shr    r14d,0x10
    7009a3ffd216:	mov    ecx,r14d
    7009a3ffd219:	xor    r13,rcx
    7009a3ffd21c:	mov    r13d,r13d
    7009a3ffd21f:	mov    QWORD PTR [r12],r13
    7009a3ffd223:	mov    rcx,QWORD PTR [r12+0x380]
    7009a3ffd22b:	jrcxz  0x7009a3ffd232
    7009a3ffd22d:	jmp    0x7009a3ffd267
    7009a3ffd232:	mov    r13,QWORD PTR [r12+0xf0]
    7009a3ffd23a:	mov    QWORD PTR [r12+0x100],r13
    7009a3ffd242:	mov    r11,QWORD PTR [rsp]
    7009a3ffd246:	mov    QWORD PTR [r12+0x398],r11
    7009a3ffd24e:	mov    rdi,QWORD PTR [r12+0x100]
    7009a3ffd256:	add    rsp,0x10
    7009a3ffd25a:	movabs r11,0x5f8bdbcc40a0
    7009a3ffd264:	jmp    r11
    7009a3ffd267:	mov    eax,0x41023c
    7009a3ffd26c:	mov    QWORD PTR [r12+0x100],rax
    7009a3ffd274:	push   rdx
    7009a3ffd275:	push   rsi
    7009a3ffd276:	push   r10
    7009a3ffd278:	push   r11
    7009a3ffd27a:	mov    rdx,QWORD PTR [rsp+0x20]
    7009a3ffd27f:	mov    r10d,edx
    7009a3ffd282:	and    r10d,0xc0
    7009a3ffd289:	shl    r10d,0x18
    7009a3ffd28d:	mov    r11d,edx
    7009a3ffd290:	and    r11d,0x1
    7009a3ffd294:	shl    r11d,0x1d
    7009a3ffd298:	or     r10d,r11d
    7009a3ffd29b:	mov    r11d,edx
    7009a3ffd29e:	and    r11d,0x800
    7009a3ffd2a5:	shl    r11d,0x11
    7009a3ffd2a9:	or     r10d,r11d
    7009a3ffd2ac:	btc    r10,0x1d
    7009a3ffd2b1:	mov    r11d,0xf0000000
    7009a3ffd2b7:	and    r11,r10
    7009a3ffd2ba:	movabs rsi,0xffffffff0fffffff
    7009a3ffd2c4:	and    rbx,rsi
    7009a3ffd2c7:	or     rbx,r11
    7009a3ffd2ca:	pop    r11
    7009a3ffd2cc:	pop    r10
    7009a3ffd2ce:	pop    rsi
    7009a3ffd2cf:	pop    rdx
    7009a3ffd2d0:	mov    QWORD PTR [r12+0x108],rbx
    7009a3ffd2d8:	add    rsp,0x10
    7009a3ffd2dc:	mov    eax,0xc
    7009a3ffd2e1:	movabs r11,0x5f8bdbcc4390
    7009a3ffd2eb:	jmp    r11
    7009a3ffd2ee:	nop
    7009a3ffd2ef:	nop
