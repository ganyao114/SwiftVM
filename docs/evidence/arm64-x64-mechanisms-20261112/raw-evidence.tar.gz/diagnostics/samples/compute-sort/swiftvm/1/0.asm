
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sort/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

00007009a3ffd000 <.data>:
    7009a3ffd000:	sub    rsp,0x10
    7009a3ffd004:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffd00c:	mov    QWORD PTR [rsp],r11
    7009a3ffd010:	mov    r13,QWORD PTR [r12+0xf8]
    7009a3ffd018:	sub    r13,0x20
    7009a3ffd01c:	mov    r14,QWORD PTR [r12+0xf0]
    7009a3ffd024:	mov    QWORD PTR [r13+0x0],r14
    7009a3ffd028:	mov    r14d,0x0
    7009a3ffd02e:	mov    DWORD PTR [r12+0x32c],r14d
    7009a3ffd036:	mov    QWORD PTR [r12+0xf8],r13
    7009a3ffd03e:	add    r13,0x10
    7009a3ffd042:	mov    r14,r13
    7009a3ffd045:	add    r14,0x8
    7009a3ffd049:	mov    r15,QWORD PTR [r12+0xa0]
    7009a3ffd051:	mov    rbp,QWORD PTR [r12+0x98]
    7009a3ffd059:	mov    QWORD PTR [r13+0x0],r15
    7009a3ffd05d:	mov    r13d,0x0
    7009a3ffd063:	mov    DWORD PTR [r12+0x32c],r13d
    7009a3ffd06b:	mov    QWORD PTR [r14],rbp
    7009a3ffd06e:	mov    r13d,0x0
    7009a3ffd074:	mov    DWORD PTR [r12+0x32c],r13d
    7009a3ffd07c:	mov    r13d,0x0
    7009a3ffd082:	mov    QWORD PTR [r12+0xa0],r13
    7009a3ffd08a:	mov    r13d,0x420000
    7009a3ffd090:	add    r13,0x2a0
    7009a3ffd097:	mov    QWORD PTR [r12+0x98],r13
    7009a3ffd09f:	mov    r13d,0x11
    7009a3ffd0a5:	mov    QWORD PTR [r12],r13
    7009a3ffd0a9:	mov    r13d,0x410184
    7009a3ffd0af:	mov    QWORD PTR [r12+0xf0],r13
    7009a3ffd0b7:	mov    r13d,0x41021c
    7009a3ffd0bd:	mov    QWORD PTR [r12+0x100],r13
    7009a3ffd0c5:	mov    r11,QWORD PTR [rsp]
    7009a3ffd0c9:	mov    QWORD PTR [r12+0x398],r11
    7009a3ffd0d1:	mov    edi,0x41021c
    7009a3ffd0d6:	mov    QWORD PTR [r12+0x100],rdi
    7009a3ffd0de:	add    rsp,0x10
    7009a3ffd0e2:	nop    WORD PTR [rax+rax*1+0x0]
    7009a3ffd0e8:	jmp    QWORD PTR [rip+0x2]        # 0x7009a3ffd0f0
    7009a3ffd0ee:	xchg   ax,ax
    7009a3ffd0f0:	adc    cl,dl
    7009a3ffd0f2:	jmp    QWORD PTR [rbx+0x7009]
    7009a3ffd0f8:	add    cl,dl
    7009a3ffd0fa:	jmp    QWORD PTR [rbx+0x7009]
    7009a3ffd100:	movabs r11,0x5f8bdbcc40a0
    7009a3ffd10a:	jmp    r11
    7009a3ffd10d:	nop
    7009a3ffd10e:	nop
    7009a3ffd10f:	nop
