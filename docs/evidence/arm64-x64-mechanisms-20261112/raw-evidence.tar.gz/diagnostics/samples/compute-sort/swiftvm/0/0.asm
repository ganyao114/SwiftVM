
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sort/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000072e641efe000 <.data>:
    72e641efe000:	sub    rsp,0x10
    72e641efe004:	mov    r11,QWORD PTR [r12+0x398]
    72e641efe00c:	mov    QWORD PTR [rsp],r11
    72e641efe010:	mov    r13,QWORD PTR [r12+0xf8]
    72e641efe018:	sub    r13,0x20
    72e641efe01c:	mov    r14,QWORD PTR [r12+0xf0]
    72e641efe024:	mov    QWORD PTR [r13+0x0],r14
    72e641efe028:	mov    r14d,0x0
    72e641efe02e:	mov    DWORD PTR [r12+0x32c],r14d
    72e641efe036:	mov    QWORD PTR [r12+0xf8],r13
    72e641efe03e:	add    r13,0x10
    72e641efe042:	mov    r14,r13
    72e641efe045:	add    r14,0x8
    72e641efe049:	mov    r15,QWORD PTR [r12+0xa0]
    72e641efe051:	mov    rbp,QWORD PTR [r12+0x98]
    72e641efe059:	mov    QWORD PTR [r13+0x0],r15
    72e641efe05d:	mov    r13d,0x0
    72e641efe063:	mov    DWORD PTR [r12+0x32c],r13d
    72e641efe06b:	mov    QWORD PTR [r14],rbp
    72e641efe06e:	mov    r13d,0x0
    72e641efe074:	mov    DWORD PTR [r12+0x32c],r13d
    72e641efe07c:	mov    r13d,0x0
    72e641efe082:	mov    QWORD PTR [r12+0xa0],r13
    72e641efe08a:	mov    r13d,0x420000
    72e641efe090:	add    r13,0x2a0
    72e641efe097:	mov    QWORD PTR [r12+0x98],r13
    72e641efe09f:	mov    r13d,0x11
    72e641efe0a5:	mov    QWORD PTR [r12],r13
    72e641efe0a9:	mov    r13d,0x410184
    72e641efe0af:	mov    QWORD PTR [r12+0xf0],r13
    72e641efe0b7:	mov    r13d,0x41021c
    72e641efe0bd:	mov    QWORD PTR [r12+0x100],r13
    72e641efe0c5:	mov    r11,QWORD PTR [rsp]
    72e641efe0c9:	mov    QWORD PTR [r12+0x398],r11
    72e641efe0d1:	mov    edi,0x41021c
    72e641efe0d6:	mov    QWORD PTR [r12+0x100],rdi
    72e641efe0de:	add    rsp,0x10
    72e641efe0e2:	nop    WORD PTR [rax+rax*1+0x0]
    72e641efe0e8:	jmp    QWORD PTR [rip+0x2]        # 0x72e641efe0f0
    72e641efe0ee:	xchg   ax,ax
    72e641efe0f0:	adc    cl,ah
    72e641efe0f2:	out    dx,eax
    72e641efe0f3:	rex.B out 0x72,al
    72e641efe0f6:	add    BYTE PTR [rax],al
    72e641efe0f8:	add    cl,ah
    72e641efe0fa:	out    dx,eax
    72e641efe0fb:	rex.B out 0x72,al
    72e641efe0fe:	add    BYTE PTR [rax],al
    72e641efe100:	movabs r11,0x5abaef4870a0
    72e641efe10a:	jmp    r11
    72e641efe10d:	nop
    72e641efe10e:	nop
    72e641efe10f:	nop
