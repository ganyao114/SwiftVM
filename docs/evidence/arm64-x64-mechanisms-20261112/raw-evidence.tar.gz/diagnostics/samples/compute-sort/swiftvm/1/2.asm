
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sort/swiftvm/1/2.bin:     file format binary


Disassembly of section .data:

00007009a3ffd2f0 <.data>:
    7009a3ffd2f0:	sub    rsp,0x10
    7009a3ffd2f4:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffd2fc:	mov    QWORD PTR [rsp],r11
    7009a3ffd300:	mov    r13,QWORD PTR [r12+0xa0]
    7009a3ffd308:	mov    r14,r13
    7009a3ffd30b:	shl    r14,0x2
    7009a3ffd30f:	mov    r15,QWORD PTR [r12+0x98]
    7009a3ffd317:	mov    rcx,r14
    7009a3ffd31a:	add    r15,rcx
    7009a3ffd31d:	mov    r14d,DWORD PTR [r12]
    7009a3ffd321:	mov    DWORD PTR [r15],r14d
    7009a3ffd324:	mov    r14d,0x0
    7009a3ffd32a:	mov    DWORD PTR [r12+0x32c],r14d
    7009a3ffd332:	add    r13,0x1
    7009a3ffd336:	mov    QWORD PTR [r12+0xa0],r13
    7009a3ffd33e:	sub    r13,0x400
    7009a3ffd345:	mov    rcx,QWORD PTR [r12+0x380]
    7009a3ffd34d:	jrcxz  0x7009a3ffd354
    7009a3ffd34f:	jmp    0x7009a3ffd74d
    7009a3ffd354:	pushf
    7009a3ffd355:	pop    r11
    7009a3ffd357:	mov    QWORD PTR [rsp],r11
    7009a3ffd35b:	jne    0x7009a3ffd6de
    7009a3ffd361:	jmp    0x7009a3ffd366
    7009a3ffd366:	mov    r13d,0x1
    7009a3ffd36c:	mov    QWORD PTR [r12+0x40],r13
    7009a3ffd371:	jmp    0x7009a3ffd376
    7009a3ffd376:	mov    r13,QWORD PTR [r12+0x40]
    7009a3ffd37b:	mov    r14,r13
    7009a3ffd37e:	shl    r14,0x2
    7009a3ffd382:	mov    r15,QWORD PTR [r12+0x98]
    7009a3ffd38a:	mov    rcx,r14
    7009a3ffd38d:	add    r15,rcx
    7009a3ffd390:	mov    r14d,DWORD PTR [r15]
    7009a3ffd393:	mov    QWORD PTR [r12+0x48],r14
    7009a3ffd398:	mov    r14d,0x0
    7009a3ffd39e:	mov    rcx,r13
    7009a3ffd3a1:	or     r14,rcx
    7009a3ffd3a4:	mov    QWORD PTR [r12+0x50],r14
    7009a3ffd3a9:	jmp    0x7009a3ffd3ae
    7009a3ffd3ae:	mov    r13d,DWORD PTR [r12+0x50]
    7009a3ffd3b3:	sub    r13d,0x1
    7009a3ffd3b7:	mov    QWORD PTR [r12+0x58],r13
    7009a3ffd3bc:	mov    ecx,0xffffffff
    7009a3ffd3c1:	mov    r14,r13
    7009a3ffd3c4:	and    r14,rcx
    7009a3ffd3c7:	shl    r14,0x2
    7009a3ffd3cb:	mov    r13,QWORD PTR [r12+0x98]
    7009a3ffd3d3:	mov    rcx,r14
    7009a3ffd3d6:	add    r13,rcx
    7009a3ffd3d9:	mov    r14d,DWORD PTR [r13+0x0]
    7009a3ffd3dd:	mov    QWORD PTR [r12+0x60],r14
    7009a3ffd3e2:	mov    r13d,DWORD PTR [r12+0x48]
    7009a3ffd3e7:	mov    ecx,r13d
    7009a3ffd3ea:	sub    r14d,ecx
    7009a3ffd3ed:	mov    rcx,QWORD PTR [r12+0x380]
    7009a3ffd3f5:	jrcxz  0x7009a3ffd3fc
    7009a3ffd3f7:	jmp    0x7009a3ffd7dc
    7009a3ffd3fc:	sete   al
    7009a3ffd3ff:	movzx  eax,al
    7009a3ffd402:	mov    r13,rax
    7009a3ffd405:	setb   al
    7009a3ffd408:	movzx  eax,al
    7009a3ffd40b:	mov    r14,rax
    7009a3ffd40e:	pushf
    7009a3ffd40f:	pop    r11
    7009a3ffd411:	mov    QWORD PTR [rsp],r11
    7009a3ffd415:	mov    rcx,r13
    7009a3ffd418:	and    ecx,0xff
    7009a3ffd41e:	mov    r15,r14
    7009a3ffd421:	and    r15d,0xff
    7009a3ffd428:	or     r15,rcx
    7009a3ffd42b:	and    r15d,0xff
    7009a3ffd432:	mov    rax,r15
    7009a3ffd435:	and    eax,0xff
    7009a3ffd43a:	test   rax,rax
    7009a3ffd43d:	jne    0x7009a3ffd4df
    7009a3ffd443:	jmp    0x7009a3ffd448
    7009a3ffd448:	mov    r13,QWORD PTR [r12+0x50]
    7009a3ffd44d:	mov    r14,r13
    7009a3ffd450:	shl    r14,0x2
    7009a3ffd454:	mov    r15,QWORD PTR [r12+0x98]
    7009a3ffd45c:	mov    rcx,r14
    7009a3ffd45f:	add    r15,rcx
    7009a3ffd462:	mov    r14d,DWORD PTR [r12+0x60]
    7009a3ffd467:	mov    DWORD PTR [r15],r14d
    7009a3ffd46a:	mov    r14d,0x0
    7009a3ffd470:	mov    DWORD PTR [r12+0x32c],r14d
    7009a3ffd478:	sub    r13,0x1
    7009a3ffd47c:	mov    QWORD PTR [r12+0x50],r13
    7009a3ffd481:	mov    rcx,QWORD PTR [r12+0x380]
    7009a3ffd489:	jrcxz  0x7009a3ffd490
    7009a3ffd48b:	jmp    0x7009a3ffd86b
    7009a3ffd490:	mov    r13,QWORD PTR [r12+0x58]
    7009a3ffd495:	mov    rax,r13
    7009a3ffd498:	test   rax,rax
    7009a3ffd49b:	setne  al
    7009a3ffd49e:	movzx  eax,al
    7009a3ffd4a1:	and    eax,0x1
    7009a3ffd4a4:	mov    r14,rax
    7009a3ffd4a7:	mov    rax,r14
    7009a3ffd4aa:	and    eax,0x1
    7009a3ffd4ad:	test   rax,rax
    7009a3ffd4b0:	jne    0x7009a3ffd3ae
    7009a3ffd4b6:	jmp    0x7009a3ffd4bb
    7009a3ffd4bb:	mov    rcx,QWORD PTR [r12+0x380]
    7009a3ffd4c3:	jrcxz  0x7009a3ffd4ca
    7009a3ffd4c5:	jmp    0x7009a3ffd8f2
    7009a3ffd4ca:	jmp    0x7009a3ffd4cf
    7009a3ffd4cf:	mov    r13d,0x0
    7009a3ffd4d5:	mov    QWORD PTR [r12+0x50],r13
    7009a3ffd4da:	jmp    0x7009a3ffd4df
    7009a3ffd4df:	mov    r13,QWORD PTR [r12+0x40]
    7009a3ffd4e4:	add    r13,0x1
    7009a3ffd4e8:	mov    QWORD PTR [r12+0x40],r13
    7009a3ffd4ed:	mov    r14,QWORD PTR [r12+0x50]
    7009a3ffd4f2:	mov    ecx,0xffffffff
    7009a3ffd4f7:	and    r14,rcx
    7009a3ffd4fa:	shl    r14,0x2
    7009a3ffd4fe:	mov    r15,QWORD PTR [r12+0x98]
    7009a3ffd506:	mov    rcx,r14
    7009a3ffd509:	add    r15,rcx
    7009a3ffd50c:	mov    r14d,DWORD PTR [r12+0x48]
    7009a3ffd511:	mov    DWORD PTR [r15],r14d
    7009a3ffd514:	mov    r14d,0x0
    7009a3ffd51a:	mov    DWORD PTR [r12+0x32c],r14d
    7009a3ffd522:	sub    r13,0x400
    7009a3ffd529:	pushf
    7009a3ffd52a:	pop    r11
    7009a3ffd52c:	mov    QWORD PTR [rsp],r11
    7009a3ffd530:	je     0x7009a3ffd53b
    7009a3ffd536:	jmp    0x7009a3ffd376
    7009a3ffd53b:	mov    r13d,0x420000
    7009a3ffd541:	mov    QWORD PTR [r12+0x40],r13
    7009a3ffd546:	mov    r13d,0x0
    7009a3ffd54c:	mov    QWORD PTR [r12+0x58],r13
    7009a3ffd551:	mov    r13d,0x0
    7009a3ffd557:	mov    QWORD PTR [r12+0x50],r13
    7009a3ffd55c:	mov    r13d,0x420288
    7009a3ffd562:	mov    r14,QWORD PTR [r13+0x0]
    7009a3ffd566:	mov    QWORD PTR [r12+0x48],r14
    7009a3ffd56b:	jmp    0x7009a3ffd570
    7009a3ffd570:	mov    r13,QWORD PTR [r12+0x58]
    7009a3ffd575:	mov    r14,r13
    7009a3ffd578:	shl    r14,0x2
    7009a3ffd57c:	mov    r15,QWORD PTR [r12+0x98]
    7009a3ffd584:	mov    rcx,r14
    7009a3ffd587:	add    r15,rcx
    7009a3ffd58a:	mov    QWORD PTR [r12+0x60],r15
    7009a3ffd58f:	mov    r14,r15
    7009a3ffd592:	add    r14,0x4
    7009a3ffd596:	mov    ebp,DWORD PTR [r15]
    7009a3ffd599:	mov    r15d,DWORD PTR [r14]
    7009a3ffd59c:	mov    QWORD PTR [r12+0x60],r15
    7009a3ffd5a1:	mov    rax,rbp
    7009a3ffd5a4:	mov    rcx,r13
    7009a3ffd5a7:	imul   rax,rcx
    7009a3ffd5ab:	mov    r14,rax
    7009a3ffd5ae:	mov    rcx,r14
    7009a3ffd5b1:	mov    r8,rbp
    7009a3ffd5b4:	add    r8,rcx
    7009a3ffd5b7:	mov    QWORD PTR [r12+0x68],r8
    7009a3ffd5bc:	add    r13,0x2
    7009a3ffd5c0:	mov    QWORD PTR [r12+0x58],r13
    7009a3ffd5c5:	mov    r14,r13
    7009a3ffd5c8:	sub    r14,0x400
    7009a3ffd5cf:	mov    r14,QWORD PTR [r12+0x50]
    7009a3ffd5d4:	pushf
    7009a3ffd5d5:	pop    r11
    7009a3ffd5d7:	mov    QWORD PTR [rsp],r11
    7009a3ffd5db:	mov    rax,r13
    7009a3ffd5de:	mov    rcx,r15
    7009a3ffd5e1:	imul   rax,rcx
    7009a3ffd5e5:	mov    rbp,rax
    7009a3ffd5e8:	mov    rcx,rbp
    7009a3ffd5eb:	add    r14,rcx
    7009a3ffd5ee:	mov    QWORD PTR [r12+0x50],r14
    7009a3ffd5f3:	mov    r13,QWORD PTR [r12+0x48]
    7009a3ffd5f8:	mov    rcx,r13
    7009a3ffd5fb:	add    r8,rcx
    7009a3ffd5fe:	mov    QWORD PTR [r12+0x48],r8
    7009a3ffd603:	mov    rcx,QWORD PTR [r12+0x380]
    7009a3ffd60b:	jrcxz  0x7009a3ffd612
    7009a3ffd60d:	jmp    0x7009a3ffd979
    7009a3ffd612:	push   QWORD PTR [rsp]
    7009a3ffd615:	popf
    7009a3ffd616:	jne    0x7009a3ffd570
    7009a3ffd61c:	jmp    0x7009a3ffd621
    7009a3ffd621:	mov    r13,QWORD PTR [r12+0xf8]
    7009a3ffd629:	mov    r14,r13
    7009a3ffd62c:	add    r14,0x10
    7009a3ffd630:	mov    r15,r14
    7009a3ffd633:	add    r15,0x8
    7009a3ffd637:	mov    rbp,QWORD PTR [r14]
    7009a3ffd63a:	mov    r14,QWORD PTR [r15]
    7009a3ffd63d:	mov    QWORD PTR [r12+0xa0],rbp
    7009a3ffd645:	mov    QWORD PTR [r12+0x98],r14
    7009a3ffd64d:	mov    r14,QWORD PTR [r12+0x48]
    7009a3ffd652:	mov    r15,QWORD PTR [r12+0x50]
    7009a3ffd657:	mov    rcx,r14
    7009a3ffd65a:	add    r15,rcx
    7009a3ffd65d:	mov    QWORD PTR [r12+0x48],r15
    7009a3ffd662:	mov    r14,QWORD PTR [r12+0x40]
    7009a3ffd667:	add    r14,0x288
    7009a3ffd66e:	mov    QWORD PTR [r14],r15
    7009a3ffd671:	mov    r14d,0x0
    7009a3ffd677:	mov    DWORD PTR [r12+0x32c],r14d
    7009a3ffd67f:	mov    r14,r13
    7009a3ffd682:	add    r14,0x20
    7009a3ffd686:	mov    r15,QWORD PTR [r13+0x0]
    7009a3ffd68a:	mov    QWORD PTR [r12+0xf0],r15
    7009a3ffd692:	mov    QWORD PTR [r12+0xf8],r14
    7009a3ffd69a:	mov    rcx,QWORD PTR [r12+0x380]
    7009a3ffd6a2:	jrcxz  0x7009a3ffd6a9
    7009a3ffd6a4:	jmp    0x7009a3ffda00
    7009a3ffd6a9:	mov    r13,QWORD PTR [r12+0xf0]
    7009a3ffd6b1:	mov    QWORD PTR [r12+0x100],r13
    7009a3ffd6b9:	mov    r11,QWORD PTR [rsp]
    7009a3ffd6bd:	mov    QWORD PTR [r12+0x398],r11
    7009a3ffd6c5:	mov    rdi,QWORD PTR [r12+0x100]
    7009a3ffd6cd:	add    rsp,0x10
    7009a3ffd6d1:	movabs r11,0x5f8bdbcc40a0
    7009a3ffd6db:	jmp    r11
    7009a3ffd6de:	mov    r13d,DWORD PTR [r12+0xa0]
    7009a3ffd6e6:	add    r13d,0x11
    7009a3ffd6ea:	mov    QWORD PTR [r12],r13
    7009a3ffd6ee:	mov    r13d,0x410184
    7009a3ffd6f4:	mov    QWORD PTR [r12+0xf0],r13
    7009a3ffd6fc:	mov    r13d,0x41021c
    7009a3ffd702:	mov    QWORD PTR [r12+0x100],r13
    7009a3ffd70a:	mov    r11,QWORD PTR [rsp]
    7009a3ffd70e:	mov    QWORD PTR [r12+0x398],r11
    7009a3ffd716:	mov    edi,0x41021c
    7009a3ffd71b:	mov    QWORD PTR [r12+0x100],rdi
    7009a3ffd723:	add    rsp,0x10
    7009a3ffd727:	nop
    7009a3ffd728:	jmp    QWORD PTR [rip+0x2]        # 0x7009a3ffd730
    7009a3ffd72e:	xchg   ax,ax
    7009a3ffd730:	adc    cl,dl
    7009a3ffd732:	jmp    QWORD PTR [rbx+0x7009]
    7009a3ffd738:	rex xlat BYTE PTR ds:[rbx]
    7009a3ffd73a:	jmp    QWORD PTR [rbx+0x7009]
    7009a3ffd740:	movabs r11,0x5f8bdbcc40a0
    7009a3ffd74a:	jmp    r11
    7009a3ffd74d:	mov    eax,0x410190
    7009a3ffd752:	mov    QWORD PTR [r12+0x100],rax
    7009a3ffd75a:	push   rdx
    7009a3ffd75b:	push   rsi
    7009a3ffd75c:	push   r10
    7009a3ffd75e:	push   r11
    7009a3ffd760:	pushf
    7009a3ffd761:	pop    r11
    7009a3ffd763:	mov    QWORD PTR [rsp+0x20],r11
    7009a3ffd768:	mov    rdx,QWORD PTR [rsp+0x20]
    7009a3ffd76d:	mov    r10d,edx
    7009a3ffd770:	and    r10d,0xc0
    7009a3ffd777:	shl    r10d,0x18
    7009a3ffd77b:	mov    r11d,edx
    7009a3ffd77e:	and    r11d,0x1
    7009a3ffd782:	shl    r11d,0x1d
    7009a3ffd786:	or     r10d,r11d
    7009a3ffd789:	mov    r11d,edx
    7009a3ffd78c:	and    r11d,0x800
    7009a3ffd793:	shl    r11d,0x11
    7009a3ffd797:	or     r10d,r11d
    7009a3ffd79a:	btc    r10,0x1d
    7009a3ffd79f:	mov    r11d,0xf0000000
    7009a3ffd7a5:	and    r11,r10
    7009a3ffd7a8:	movabs rsi,0xffffffff0fffffff
    7009a3ffd7b2:	and    rbx,rsi
    7009a3ffd7b5:	or     rbx,r11
    7009a3ffd7b8:	pop    r11
    7009a3ffd7ba:	pop    r10
    7009a3ffd7bc:	pop    rsi
    7009a3ffd7bd:	pop    rdx
    7009a3ffd7be:	mov    QWORD PTR [r12+0x108],rbx
    7009a3ffd7c6:	add    rsp,0x10
    7009a3ffd7ca:	mov    eax,0xc
    7009a3ffd7cf:	movabs r11,0x5f8bdbcc4390
    7009a3ffd7d9:	jmp    r11
    7009a3ffd7dc:	mov    eax,0x4101c4
    7009a3ffd7e1:	mov    QWORD PTR [r12+0x100],rax
    7009a3ffd7e9:	push   rdx
    7009a3ffd7ea:	push   rsi
    7009a3ffd7eb:	push   r10
    7009a3ffd7ed:	push   r11
    7009a3ffd7ef:	pushf
    7009a3ffd7f0:	pop    r11
    7009a3ffd7f2:	mov    QWORD PTR [rsp+0x20],r11
    7009a3ffd7f7:	mov    rdx,QWORD PTR [rsp+0x20]
    7009a3ffd7fc:	mov    r10d,edx
    7009a3ffd7ff:	and    r10d,0xc0
    7009a3ffd806:	shl    r10d,0x18
    7009a3ffd80a:	mov    r11d,edx
    7009a3ffd80d:	and    r11d,0x1
    7009a3ffd811:	shl    r11d,0x1d
    7009a3ffd815:	or     r10d,r11d
    7009a3ffd818:	mov    r11d,edx
    7009a3ffd81b:	and    r11d,0x800
    7009a3ffd822:	shl    r11d,0x11
    7009a3ffd826:	or     r10d,r11d
    7009a3ffd829:	btc    r10,0x1d
    7009a3ffd82e:	mov    r11d,0xf0000000
    7009a3ffd834:	and    r11,r10
    7009a3ffd837:	movabs rsi,0xffffffff0fffffff
    7009a3ffd841:	and    rbx,rsi
    7009a3ffd844:	or     rbx,r11
    7009a3ffd847:	pop    r11
    7009a3ffd849:	pop    r10
    7009a3ffd84b:	pop    rsi
    7009a3ffd84c:	pop    rdx
    7009a3ffd84d:	mov    QWORD PTR [r12+0x108],rbx
    7009a3ffd855:	add    rsp,0x10
    7009a3ffd859:	mov    eax,0xc
    7009a3ffd85e:	movabs r11,0x5f8bdbcc4390
    7009a3ffd868:	jmp    r11
    7009a3ffd86b:	mov    eax,0x4101d0
    7009a3ffd870:	mov    QWORD PTR [r12+0x100],rax
    7009a3ffd878:	push   rdx
    7009a3ffd879:	push   rsi
    7009a3ffd87a:	push   r10
    7009a3ffd87c:	push   r11
    7009a3ffd87e:	mov    rdx,QWORD PTR [rsp+0x20]
    7009a3ffd883:	mov    r10d,edx
    7009a3ffd886:	and    r10d,0xc0
    7009a3ffd88d:	shl    r10d,0x18
    7009a3ffd891:	mov    r11d,edx
    7009a3ffd894:	and    r11d,0x1
    7009a3ffd898:	shl    r11d,0x1d
    7009a3ffd89c:	or     r10d,r11d
    7009a3ffd89f:	mov    r11d,edx
    7009a3ffd8a2:	and    r11d,0x800
    7009a3ffd8a9:	shl    r11d,0x11
    7009a3ffd8ad:	or     r10d,r11d
    7009a3ffd8b0:	btc    r10,0x1d
    7009a3ffd8b5:	mov    r11d,0xf0000000
    7009a3ffd8bb:	and    r11,r10
    7009a3ffd8be:	movabs rsi,0xffffffff0fffffff
    7009a3ffd8c8:	and    rbx,rsi
    7009a3ffd8cb:	or     rbx,r11
    7009a3ffd8ce:	pop    r11
    7009a3ffd8d0:	pop    r10
    7009a3ffd8d2:	pop    rsi
    7009a3ffd8d3:	pop    rdx
    7009a3ffd8d4:	mov    QWORD PTR [r12+0x108],rbx
    7009a3ffd8dc:	add    rsp,0x10
    7009a3ffd8e0:	mov    eax,0xc
    7009a3ffd8e5:	movabs r11,0x5f8bdbcc4390
    7009a3ffd8ef:	jmp    r11
    7009a3ffd8f2:	mov    eax,0x4101d4
    7009a3ffd8f7:	mov    QWORD PTR [r12+0x100],rax
    7009a3ffd8ff:	push   rdx
    7009a3ffd900:	push   rsi
    7009a3ffd901:	push   r10
    7009a3ffd903:	push   r11
    7009a3ffd905:	mov    rdx,QWORD PTR [rsp+0x20]
    7009a3ffd90a:	mov    r10d,edx
    7009a3ffd90d:	and    r10d,0xc0
    7009a3ffd914:	shl    r10d,0x18
    7009a3ffd918:	mov    r11d,edx
    7009a3ffd91b:	and    r11d,0x1
    7009a3ffd91f:	shl    r11d,0x1d
    7009a3ffd923:	or     r10d,r11d
    7009a3ffd926:	mov    r11d,edx
    7009a3ffd929:	and    r11d,0x800
    7009a3ffd930:	shl    r11d,0x11
    7009a3ffd934:	or     r10d,r11d
    7009a3ffd937:	btc    r10,0x1d
    7009a3ffd93c:	mov    r11d,0xf0000000
    7009a3ffd942:	and    r11,r10
    7009a3ffd945:	movabs rsi,0xffffffff0fffffff
    7009a3ffd94f:	and    rbx,rsi
    7009a3ffd952:	or     rbx,r11
    7009a3ffd955:	pop    r11
    7009a3ffd957:	pop    r10
    7009a3ffd959:	pop    rsi
    7009a3ffd95a:	pop    rdx
    7009a3ffd95b:	mov    QWORD PTR [r12+0x108],rbx
    7009a3ffd963:	add    rsp,0x10
    7009a3ffd967:	mov    eax,0xc
    7009a3ffd96c:	movabs r11,0x5f8bdbcc4390
    7009a3ffd976:	jmp    r11
    7009a3ffd979:	mov    eax,0x410204
    7009a3ffd97e:	mov    QWORD PTR [r12+0x100],rax
    7009a3ffd986:	push   rdx
    7009a3ffd987:	push   rsi
    7009a3ffd988:	push   r10
    7009a3ffd98a:	push   r11
    7009a3ffd98c:	mov    rdx,QWORD PTR [rsp+0x20]
    7009a3ffd991:	mov    r10d,edx
    7009a3ffd994:	and    r10d,0xc0
    7009a3ffd99b:	shl    r10d,0x18
    7009a3ffd99f:	mov    r11d,edx
    7009a3ffd9a2:	and    r11d,0x1
    7009a3ffd9a6:	shl    r11d,0x1d
    7009a3ffd9aa:	or     r10d,r11d
    7009a3ffd9ad:	mov    r11d,edx
    7009a3ffd9b0:	and    r11d,0x800
    7009a3ffd9b7:	shl    r11d,0x11
    7009a3ffd9bb:	or     r10d,r11d
    7009a3ffd9be:	btc    r10,0x1d
    7009a3ffd9c3:	mov    r11d,0xf0000000
    7009a3ffd9c9:	and    r11,r10
    7009a3ffd9cc:	movabs rsi,0xffffffff0fffffff
    7009a3ffd9d6:	and    rbx,rsi
    7009a3ffd9d9:	or     rbx,r11
    7009a3ffd9dc:	pop    r11
    7009a3ffd9de:	pop    r10
    7009a3ffd9e0:	pop    rsi
    7009a3ffd9e1:	pop    rdx
    7009a3ffd9e2:	mov    QWORD PTR [r12+0x108],rbx
    7009a3ffd9ea:	add    rsp,0x10
    7009a3ffd9ee:	mov    eax,0xc
    7009a3ffd9f3:	movabs r11,0x5f8bdbcc4390
    7009a3ffd9fd:	jmp    r11
    7009a3ffda00:	mov    eax,0x410218
    7009a3ffda05:	mov    QWORD PTR [r12+0x100],rax
    7009a3ffda0d:	push   rdx
    7009a3ffda0e:	push   rsi
    7009a3ffda0f:	push   r10
    7009a3ffda11:	push   r11
    7009a3ffda13:	mov    rdx,QWORD PTR [rsp+0x20]
    7009a3ffda18:	mov    r10d,edx
    7009a3ffda1b:	and    r10d,0xc0
    7009a3ffda22:	shl    r10d,0x18
    7009a3ffda26:	mov    r11d,edx
    7009a3ffda29:	and    r11d,0x1
    7009a3ffda2d:	shl    r11d,0x1d
    7009a3ffda31:	or     r10d,r11d
    7009a3ffda34:	mov    r11d,edx
    7009a3ffda37:	and    r11d,0x800
    7009a3ffda3e:	shl    r11d,0x11
    7009a3ffda42:	or     r10d,r11d
    7009a3ffda45:	btc    r10,0x1d
    7009a3ffda4a:	mov    r11d,0xf0000000
    7009a3ffda50:	and    r11,r10
    7009a3ffda53:	movabs rsi,0xffffffff0fffffff
    7009a3ffda5d:	and    rbx,rsi
    7009a3ffda60:	or     rbx,r11
    7009a3ffda63:	pop    r11
    7009a3ffda65:	pop    r10
    7009a3ffda67:	pop    rsi
    7009a3ffda68:	pop    rdx
    7009a3ffda69:	mov    QWORD PTR [r12+0x108],rbx
    7009a3ffda71:	add    rsp,0x10
    7009a3ffda75:	mov    eax,0xc
    7009a3ffda7a:	movabs r11,0x5f8bdbcc4390
    7009a3ffda84:	jmp    r11
    7009a3ffda87:	nop    WORD PTR [rax+rax*1+0x0]
    7009a3ffda90:	sub    rsp,0x10
    7009a3ffda94:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffda9c:	mov    QWORD PTR [rsp],r11
    7009a3ffdaa0:	jmp    0x7009a3ffd366
    7009a3ffdaa5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdab0:	sub    rsp,0x10
    7009a3ffdab4:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdabc:	mov    QWORD PTR [rsp],r11
    7009a3ffdac0:	jmp    0x7009a3ffd376
    7009a3ffdac5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdad0:	sub    rsp,0x10
    7009a3ffdad4:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdadc:	mov    QWORD PTR [rsp],r11
    7009a3ffdae0:	jmp    0x7009a3ffd3ae
    7009a3ffdae5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdaf0:	sub    rsp,0x10
    7009a3ffdaf4:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdafc:	mov    QWORD PTR [rsp],r11
    7009a3ffdb00:	jmp    0x7009a3ffd448
    7009a3ffdb05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdb10:	sub    rsp,0x10
    7009a3ffdb14:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdb1c:	mov    QWORD PTR [rsp],r11
    7009a3ffdb20:	jmp    0x7009a3ffd4bb
    7009a3ffdb25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdb30:	sub    rsp,0x10
    7009a3ffdb34:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdb3c:	mov    QWORD PTR [rsp],r11
    7009a3ffdb40:	jmp    0x7009a3ffd4cf
    7009a3ffdb45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdb50:	sub    rsp,0x10
    7009a3ffdb54:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdb5c:	mov    QWORD PTR [rsp],r11
    7009a3ffdb60:	jmp    0x7009a3ffd4df
    7009a3ffdb65:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdb70:	sub    rsp,0x10
    7009a3ffdb74:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdb7c:	mov    QWORD PTR [rsp],r11
    7009a3ffdb80:	jmp    0x7009a3ffd53b
    7009a3ffdb85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdb90:	sub    rsp,0x10
    7009a3ffdb94:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdb9c:	mov    QWORD PTR [rsp],r11
    7009a3ffdba0:	jmp    0x7009a3ffd570
    7009a3ffdba5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdbb0:	sub    rsp,0x10
    7009a3ffdbb4:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdbbc:	mov    QWORD PTR [rsp],r11
    7009a3ffdbc0:	jmp    0x7009a3ffd621
    7009a3ffdbc5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7009a3ffdbd0:	sub    rsp,0x10
    7009a3ffdbd4:	mov    r11,QWORD PTR [r12+0x398]
    7009a3ffdbdc:	mov    QWORD PTR [rsp],r11
    7009a3ffdbe0:	jmp    0x7009a3ffd6de
    7009a3ffdbe5:	nop
    7009a3ffdbe6:	nop
    7009a3ffdbe7:	nop
