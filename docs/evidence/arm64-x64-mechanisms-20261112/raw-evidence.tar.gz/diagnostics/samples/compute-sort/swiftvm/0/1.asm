
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sort/swiftvm/0/1.bin:     file format binary


Disassembly of section .data:

000072e641efe110 <.data>:
    72e641efe110:	sub    rsp,0x10
    72e641efe114:	mov    r11,QWORD PTR [r12+0x398]
    72e641efe11c:	mov    QWORD PTR [rsp],r11
    72e641efe120:	mov    r13d,0x352d
    72e641efe126:	mov    QWORD PTR [r12+0x40],r13
    72e641efe12b:	mov    r13d,0xa68b
    72e641efe131:	mov    QWORD PTR [r12+0x48],r13
    72e641efe136:	mov    r13d,0x352d
    72e641efe13c:	mov    r14d,0x7feb
    72e641efe142:	and    r14d,0xffff
    72e641efe149:	mov    rax,r13
    72e641efe14c:	movabs rcx,0xffffffff0000ffff
    72e641efe156:	and    rax,rcx
    72e641efe159:	mov    rdx,r14
    72e641efe15c:	shl    rdx,0x10
    72e641efe160:	mov    ecx,0xffff0000
    72e641efe165:	and    rdx,rcx
    72e641efe168:	or     rax,rdx
    72e641efe16b:	mov    r15d,eax
    72e641efe16e:	mov    QWORD PTR [r12+0x40],r15
    72e641efe173:	mov    r13d,0xa68b
    72e641efe179:	mov    r14d,0x846c
    72e641efe17f:	and    r14d,0xffff
    72e641efe186:	mov    rax,r13
    72e641efe189:	movabs rcx,0xffffffff0000ffff
    72e641efe193:	and    rax,rcx
    72e641efe196:	mov    rdx,r14
    72e641efe199:	shl    rdx,0x10
    72e641efe19d:	mov    ecx,0xffff0000
    72e641efe1a2:	and    rdx,rcx
    72e641efe1a5:	or     rax,rdx
    72e641efe1a8:	mov    ebp,eax
    72e641efe1aa:	mov    QWORD PTR [r12+0x48],rbp
    72e641efe1af:	mov    r13d,DWORD PTR [r12]
    72e641efe1b3:	mov    r14d,0x0
    72e641efe1b9:	mov    eax,r13d
    72e641efe1bc:	mov    ecx,r15d
    72e641efe1bf:	imul   rax,rcx
    72e641efe1c3:	mov    r8d,eax
    72e641efe1c6:	mov    ecx,r8d
    72e641efe1c9:	mov    r13d,r14d
    72e641efe1cc:	add    r13d,ecx
    72e641efe1cf:	mov    QWORD PTR [r12+0x40],r13
    72e641efe1d4:	mov    r14d,r13d
    72e641efe1d7:	mov    r14d,r14d
    72e641efe1da:	shr    r14d,0xf
    72e641efe1de:	mov    ecx,r14d
    72e641efe1e1:	xor    r13,rcx
    72e641efe1e4:	mov    r13d,r13d
    72e641efe1e7:	mov    QWORD PTR [r12+0x40],r13
    72e641efe1ec:	mov    r14d,0x0
    72e641efe1f2:	mov    eax,r13d
    72e641efe1f5:	mov    ecx,ebp
    72e641efe1f7:	imul   rax,rcx
    72e641efe1fb:	mov    r15d,eax
    72e641efe1fe:	mov    ecx,r15d
    72e641efe201:	mov    r13d,r14d
    72e641efe204:	add    r13d,ecx
    72e641efe207:	mov    QWORD PTR [r12+0x40],r13
    72e641efe20c:	mov    r14d,r13d
    72e641efe20f:	mov    r14d,r14d
    72e641efe212:	shr    r14d,0x10
    72e641efe216:	mov    ecx,r14d
    72e641efe219:	xor    r13,rcx
    72e641efe21c:	mov    r13d,r13d
    72e641efe21f:	mov    QWORD PTR [r12],r13
    72e641efe223:	mov    rcx,QWORD PTR [r12+0x380]
    72e641efe22b:	jrcxz  0x72e641efe232
    72e641efe22d:	jmp    0x72e641efe267
    72e641efe232:	mov    r13,QWORD PTR [r12+0xf0]
    72e641efe23a:	mov    QWORD PTR [r12+0x100],r13
    72e641efe242:	mov    r11,QWORD PTR [rsp]
    72e641efe246:	mov    QWORD PTR [r12+0x398],r11
    72e641efe24e:	mov    rdi,QWORD PTR [r12+0x100]
    72e641efe256:	add    rsp,0x10
    72e641efe25a:	movabs r11,0x5abaef4870a0
    72e641efe264:	jmp    r11
    72e641efe267:	mov    eax,0x41023c
    72e641efe26c:	mov    QWORD PTR [r12+0x100],rax
    72e641efe274:	push   rdx
    72e641efe275:	push   rsi
    72e641efe276:	push   r10
    72e641efe278:	push   r11
    72e641efe27a:	mov    rdx,QWORD PTR [rsp+0x20]
    72e641efe27f:	mov    r10d,edx
    72e641efe282:	and    r10d,0xc0
    72e641efe289:	shl    r10d,0x18
    72e641efe28d:	mov    r11d,edx
    72e641efe290:	and    r11d,0x1
    72e641efe294:	shl    r11d,0x1d
    72e641efe298:	or     r10d,r11d
    72e641efe29b:	mov    r11d,edx
    72e641efe29e:	and    r11d,0x800
    72e641efe2a5:	shl    r11d,0x11
    72e641efe2a9:	or     r10d,r11d
    72e641efe2ac:	btc    r10,0x1d
    72e641efe2b1:	mov    r11d,0xf0000000
    72e641efe2b7:	and    r11,r10
    72e641efe2ba:	movabs rsi,0xffffffff0fffffff
    72e641efe2c4:	and    rbx,rsi
    72e641efe2c7:	or     rbx,r11
    72e641efe2ca:	pop    r11
    72e641efe2cc:	pop    r10
    72e641efe2ce:	pop    rsi
    72e641efe2cf:	pop    rdx
    72e641efe2d0:	mov    QWORD PTR [r12+0x108],rbx
    72e641efe2d8:	add    rsp,0x10
    72e641efe2dc:	mov    eax,0xc
    72e641efe2e1:	movabs r11,0x5abaef487390
    72e641efe2eb:	jmp    r11
    72e641efe2ee:	nop
    72e641efe2ef:	nop
