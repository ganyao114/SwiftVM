00007a8ab83ce69b  nop [rax+rax*1], eax
00007a8ab83ce6a0  mov rax, [r15+0xF8]
00007a8ab83ce6a7  lea r14, [rax-0x20]
00007a8ab83ce6ab  mov r12, [r15+0xF0]
00007a8ab83ce6b2  mov [r13+r14*1], r12
00007a8ab83ce6b7  mov [r15+0xF8], r14
00007a8ab83ce6be  lea r14, [rax-0x10]
00007a8ab83ce6c2  mov r12, [r15+0xA0]
00007a8ab83ce6c9  mov r11, [r15+0x98]
00007a8ab83ce6d0  mov [r13+r14*1], r12
00007a8ab83ce6d5  lea r14, [rax-0x08]
00007a8ab83ce6d9  mov [r13+r14*1], r11
00007a8ab83ce6de  mov qword ptr [r15+0xA0], 0x00
00007a8ab83ce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007a8ab83ce6f4  mov eax, [r15+0xA0]
00007a8ab83ce6fb  lea r14d, [eax+0x11]
00007a8ab83ce700  mov r14d, r14d
00007a8ab83ce703  mov [r15], r14
00007a8ab83ce706  mov qword ptr [r15+0xF0], 0x410184
00007a8ab83ce711  mov r14d, [r15+0x320]
00007a8ab83ce718  mov eax, 0x410184
00007a8ab83ce71d  mov rcx, 0x7A8AB83CE800
00007a8ab83ce727  mov [r15+r14*8+0x328], rax
00007a8ab83ce72f  mov [r15+r14*8+0x368], rcx
00007a8ab83ce737  add r14d, 0x01
00007a8ab83ce73b  and r14d, 0x07
00007a8ab83ce73f  mov [r15+0x320], r14d
00007a8ab83ce746  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ce74e  jz 0x00007A8AB83CE7A0
00007a8ab83ce754  nop [rax+rax*1], ax
00007a8ab83ce75d  nop [rax+rax*1], eax
00007a8ab83ce765  mov eax, 0x41021C
00007a8ab83ce76a  mov [r15+0x100], rax
00007a8ab83ce771  jmp 0x00007A8AB81FE110
00007a8ab83ce776  int3
00007a8ab83ce777  call 0x00007A8AB82E2CE0
00007a8ab83ce77c  jmp 0x00007A8AB83CE6B7
00007a8ab83ce781  call 0x00007A8AB82E2CE0
00007a8ab83ce786  jmp 0x00007A8AB83CE6D5
00007a8ab83ce78b  call 0x00007A8AB82E1A60
00007a8ab83ce790  jmp 0x00007A8AB83CE6DE
00007a8ab83ce795  int3
00007a8ab83ce796  nop [rax+rax*1], ax
00007a8ab83ce79f  nop
00007a8ab83ce7a0  mov eax, 0x846CA68B
00007a8ab83ce7a5  mov eax, eax
00007a8ab83ce7a7  mov [r15+0x48], rax
00007a8ab83ce7ab  mov eax, [r15]
00007a8ab83ce7ae  imul eax, eax, 0x7FEB352D
00007a8ab83ce7b4  mov [rsp+0x10], eax
00007a8ab83ce7b8  shr eax, 0x0F
00007a8ab83ce7bb  mov r14d, [rsp+0x10]
00007a8ab83ce7c0  xor r14d, eax
00007a8ab83ce7c3  imul r14d, r14d, 0x846CA68B
00007a8ab83ce7ca  mov [rsp+0x10], r14d
00007a8ab83ce7cf  mov r14d, r14d
00007a8ab83ce7d2  mov [r15+0x40], r14
00007a8ab83ce7d6  mov eax, [rsp+0x10]
00007a8ab83ce7da  shr eax, 0x10
00007a8ab83ce7dd  mov r14d, [rsp+0x10]
00007a8ab83ce7e2  xor r14d, eax
00007a8ab83ce7e5  mov r14d, r14d
00007a8ab83ce7e8  mov [r15], r14
00007a8ab83ce7eb  mov rax, [r15+0xF0]
00007a8ab83ce7f2  mov [r15+0x100], rax
00007a8ab83ce7f9  jmp 0x00007A8AB83CE5C0
00007a8ab83ce7fe  int3
00007a8ab83ce7ff  int3
00007a8ab83ce800  mov rax, [r15+0xA0]
00007a8ab83ce807  mov [rsp+0x10], rax
00007a8ab83ce80c  shl rax, 0x02
00007a8ab83ce810  mov r14, [r15+0x98]
00007a8ab83ce817  lea r12, [r14+rax*1]
00007a8ab83ce81b  mov eax, [r15]
00007a8ab83ce81e  mov [r13+r12*1], eax
00007a8ab83ce823  mov rax, [rsp+0x10]
00007a8ab83ce828  lea r14, [rax+0x01]
00007a8ab83ce82c  mov [r15+0xA0], r14
00007a8ab83ce833  xor eax, eax
00007a8ab83ce835  mov r12d, 0x400
00007a8ab83ce83b  cmp r14, r12
00007a8ab83ce83e  cmc
00007a8ab83ce83f  lahf
00007a8ab83ce840  seto al
00007a8ab83ce843  mov [r15+0x108], eax
00007a8ab83ce84a  mov eax, [r15+0x108]
00007a8ab83ce851  sahf
00007a8ab83ce852  jnz 0x00007A8AB83CE884
00007a8ab83ce854  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ce85c  jz 0x00007A8AB83CE950
00007a8ab83ce862  nop [rax+rax*1], ax
00007a8ab83ce86b  nop [rax+rax*1], eax
00007a8ab83ce873  mov eax, 0x410194
00007a8ab83ce878  mov [r15+0x100], rax
00007a8ab83ce87f  jmp 0x00007A8AB81FE110
00007a8ab83ce884  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ce88c  jz 0x00007A8AB83CE8C0
00007a8ab83ce892  nop [rax+rax*1], ax
00007a8ab83ce89b  nop [rax+rax*1], eax
00007a8ab83ce8a3  mov eax, 0x41017C
00007a8ab83ce8a8  mov [r15+0x100], rax
00007a8ab83ce8af  jmp 0x00007A8AB81FE110
00007a8ab83ce8b4  int3
00007a8ab83ce8b5  call 0x00007A8AB82B4B70
00007a8ab83ce8ba  jmp 0x00007A8AB83CE823
00007a8ab83ce8bf  int3
00007a8ab83ce8c0  mov eax, [r15+0xA0]
00007a8ab83ce8c7  lea r14d, [eax+0x11]
00007a8ab83ce8cc  mov r14d, r14d
00007a8ab83ce8cf  mov [r15], r14
00007a8ab83ce8d2  mov qword ptr [r15+0xF0], 0x410184
00007a8ab83ce8dd  mov r14d, [r15+0x320]
00007a8ab83ce8e4  mov eax, 0x410184
00007a8ab83ce8e9  mov rcx, 0x7A8AB83CE800
00007a8ab83ce8f3  mov [r15+r14*8+0x328], rax
00007a8ab83ce8fb  mov [r15+r14*8+0x368], rcx
00007a8ab83ce903  add r14d, 0x01
00007a8ab83ce907  and r14d, 0x07
00007a8ab83ce90b  mov [r15+0x320], r14d
00007a8ab83ce912  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ce91a  jz 0x00007A8AB83CE7A0
00007a8ab83ce920  nop [rax+rax*1], ax
00007a8ab83ce929  nop [rax+rax*1], eax
00007a8ab83ce931  mov eax, 0x41021C
00007a8ab83ce936  mov [r15+0x100], rax
00007a8ab83ce93d  jmp 0x00007A8AB81FE110
00007a8ab83ce942  int3
00007a8ab83ce943  int3
00007a8ab83ce944  nop [rax+rax*1], ax
00007a8ab83ce94d  nop [rax], eax
00007a8ab83ce950  mov qword ptr [r15+0x40], 0x01
00007a8ab83ce958  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ce960  jz 0x00007A8AB83CE990
00007a8ab83ce966  nop [rax+rax*1], ax
00007a8ab83ce96f  nop [rax+rax*1], eax
00007a8ab83ce977  mov eax, 0x4101B0
00007a8ab83ce97c  mov [r15+0x100], rax
00007a8ab83ce983  jmp 0x00007A8AB81FE110
00007a8ab83ce988  int3
00007a8ab83ce989  int3
00007a8ab83ce98a  nop [rax+rax*1], ax
00007a8ab83ce990  mov rax, [r15+0x40]
00007a8ab83ce994  mov [rsp+0x10], rax
00007a8ab83ce999  shl rax, 0x02
00007a8ab83ce99d  mov r14, [r15+0x98]
00007a8ab83ce9a4  lea r12, [r14+rax*1]
00007a8ab83ce9a8  mov eax, [r13+r12*1]
00007a8ab83ce9ad  mov [rsp+0x20], eax
00007a8ab83ce9b1  mov eax, eax
00007a8ab83ce9b3  mov [r15+0x48], rax
00007a8ab83ce9b7  mov rax, [rsp+0x10]
00007a8ab83ce9bc  mov [r15+0x50], rax
00007a8ab83ce9c0  mov eax, [r15+0x50]
00007a8ab83ce9c4  lea r12d, [eax-0x01]
00007a8ab83ce9c9  mov r12d, r12d
00007a8ab83ce9cc  mov [r15+0x58], r12
00007a8ab83ce9d0  mov rax, [r15+0x58]
00007a8ab83ce9d4  mov r12d, eax
00007a8ab83ce9d7  mov r12d, r12d
00007a8ab83ce9da  shl r12, 0x02
00007a8ab83ce9de  lea rax, [r14+r12*1]
00007a8ab83ce9e2  mov r14d, [r13+rax*1]
00007a8ab83ce9e7  mov [rsp+0x10], r14d
00007a8ab83ce9ec  mov r14d, r14d
00007a8ab83ce9ef  mov [r15+0x60], r14
00007a8ab83ce9f3  xor eax, eax
00007a8ab83ce9f5  mov r14d, [rsp+0x10]
00007a8ab83ce9fa  mov r12d, [rsp+0x20]
00007a8ab83ce9ff  cmp r14d, r12d
00007a8ab83cea02  cmc
00007a8ab83cea03  lahf
00007a8ab83cea04  seto al
00007a8ab83cea07  mov [r15+0x108], eax
00007a8ab83cea0e  mov eax, [r15+0x108]
00007a8ab83cea15  sahf
00007a8ab83cea16  cmc
00007a8ab83cea17  jbe 0x00007A8AB83CEA49
00007a8ab83cea19  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cea21  jz 0x00007A8AB83CEA90
00007a8ab83cea27  nop [rax+rax*1], ax
00007a8ab83cea30  nop [rax+rax*1], eax
00007a8ab83cea38  mov eax, 0x4101C8
00007a8ab83cea3d  mov [r15+0x100], rax
00007a8ab83cea44  jmp 0x00007A8AB81FE110
00007a8ab83cea49  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cea51  jz 0x00007A8AB83CED30
00007a8ab83cea57  nop [rax+rax*1], ax
00007a8ab83cea60  nop [rax+rax*1], eax
00007a8ab83cea68  mov eax, 0x4101A0
00007a8ab83cea6d  mov [r15+0x100], rax
00007a8ab83cea74  jmp 0x00007A8AB81FE110
00007a8ab83cea79  int3
00007a8ab83cea7a  call 0x00007A8AB82B4690
00007a8ab83cea7f  jmp 0x00007A8AB83CE9AD
00007a8ab83cea84  call 0x00007A8AB820DAE0
00007a8ab83cea89  jmp 0x00007A8AB83CE9E7
00007a8ab83cea8e  int3
00007a8ab83cea8f  nop
00007a8ab83cea90  mov rax, [r15+0x50]
00007a8ab83cea94  mov [rsp+0x10], rax
00007a8ab83cea99  shl rax, 0x02
00007a8ab83cea9d  mov r14, [r15+0x98]
00007a8ab83ceaa4  lea r12, [r14+rax*1]
00007a8ab83ceaa8  mov eax, [r15+0x60]
00007a8ab83ceaac  mov [r13+r12*1], eax
00007a8ab83ceab1  mov rax, [rsp+0x10]
00007a8ab83ceab6  lea r14, [rax-0x01]
00007a8ab83ceaba  mov [r15+0x50], r14
00007a8ab83ceabe  mov rax, [r15+0x58]
00007a8ab83ceac2  test rax, rax
00007a8ab83ceac5  setz al
00007a8ab83ceac8  movzx rax, al
00007a8ab83ceacc  mov [rsp+0x414], al
00007a8ab83cead3  cmp byte ptr [rsp+0x414], 0x00
00007a8ab83ceadb  jz 0x00007A8AB83CEB0D
00007a8ab83ceadd  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ceae5  jz 0x00007A8AB83CEB50
00007a8ab83ceaeb  nop [rax+rax*1], ax
00007a8ab83ceaf4  nop [rax+rax*1], eax
00007a8ab83ceafc  mov eax, 0x4101D4
00007a8ab83ceb01  mov [r15+0x100], rax
00007a8ab83ceb08  jmp 0x00007A8AB81FE110
00007a8ab83ceb0d  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ceb15  jz 0x00007A8AB83CEC50
00007a8ab83ceb1b  nop [rax+rax*1], ax
00007a8ab83ceb24  nop [rax+rax*1], eax
00007a8ab83ceb2c  mov eax, 0x4101B8
00007a8ab83ceb31  mov [r15+0x100], rax
00007a8ab83ceb38  jmp 0x00007A8AB81FE110
00007a8ab83ceb3d  int3
00007a8ab83ceb3e  call 0x00007A8AB82B4B70
00007a8ab83ceb43  jmp 0x00007A8AB83CEAB1
00007a8ab83ceb48  int3
00007a8ab83ceb49  nop [rax], eax
00007a8ab83ceb50  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ceb58  jz 0x00007A8AB83CEB90
00007a8ab83ceb5e  nop [rax+rax*1], ax
00007a8ab83ceb67  nop [rax+rax*1], eax
00007a8ab83ceb6f  mov eax, 0x41019C
00007a8ab83ceb74  mov [r15+0x100], rax
00007a8ab83ceb7b  jmp 0x00007A8AB81FE110
00007a8ab83ceb80  int3
00007a8ab83ceb81  int3
00007a8ab83ceb82  nop [rax+rax*1], ax
00007a8ab83ceb8b  nop [rax+rax*1], eax
00007a8ab83ceb90  mov qword ptr [r15+0x50], 0x00
00007a8ab83ceb98  mov rax, [r15+0x40]
00007a8ab83ceb9c  lea r14, [rax+0x01]
00007a8ab83ceba0  mov [r15+0x40], r14
00007a8ab83ceba4  mov rax, [r15+0x98]
00007a8ab83cebab  mov r12d, [r15+0x48]
00007a8ab83cebaf  mov [r13+rax*1], r12d
00007a8ab83cebb4  xor eax, eax
00007a8ab83cebb6  mov r12d, 0x400
00007a8ab83cebbc  cmp r14, r12
00007a8ab83cebbf  cmc
00007a8ab83cebc0  lahf
00007a8ab83cebc1  seto al
00007a8ab83cebc4  mov [r15+0x108], eax
00007a8ab83cebcb  mov eax, [r15+0x108]
00007a8ab83cebd2  sahf
00007a8ab83cebd3  jz 0x00007A8AB83CEC05
00007a8ab83cebd5  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cebdd  jz 0x00007A8AB83CE990
00007a8ab83cebe3  nop [rax+rax*1], ax
00007a8ab83cebec  nop [rax+rax*1], eax
00007a8ab83cebf4  mov eax, 0x4101B0
00007a8ab83cebf9  mov [r15+0x100], rax
00007a8ab83cec00  jmp 0x00007A8AB81FE110
00007a8ab83cec05  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cec0d  jz 0x00007A8AB83CEDF0
00007a8ab83cec13  nop [rax+rax*1], ax
00007a8ab83cec1c  nop [rax+rax*1], eax
00007a8ab83cec24  mov eax, 0x4101D8
00007a8ab83cec29  mov [r15+0x100], rax
00007a8ab83cec30  jmp 0x00007A8AB81FE110
00007a8ab83cec35  int3
00007a8ab83cec36  call 0x00007A8AB820BAE0
00007a8ab83cec3b  jmp 0x00007A8AB83CEBB4
00007a8ab83cec40  int3
00007a8ab83cec41  nop [rax+rax*1], ax
00007a8ab83cec4a  nop [rax+rax*1], ax
00007a8ab83cec50  mov eax, [r15+0x50]
00007a8ab83cec54  lea r14d, [eax-0x01]
00007a8ab83cec59  mov r14d, r14d
00007a8ab83cec5c  mov [r15+0x58], r14
00007a8ab83cec60  mov rax, [r15+0x58]
00007a8ab83cec64  mov r14d, eax
00007a8ab83cec67  mov r14d, r14d
00007a8ab83cec6a  shl r14, 0x02
00007a8ab83cec6e  mov rax, [r15+0x98]
00007a8ab83cec75  lea r12, [rax+r14*1]
00007a8ab83cec79  mov eax, [r13+r12*1]
00007a8ab83cec7e  mov [rsp+0x10], eax
00007a8ab83cec82  mov eax, eax
00007a8ab83cec84  mov [r15+0x60], rax
00007a8ab83cec88  mov eax, [r15+0x48]
00007a8ab83cec8c  mov [rsp+0x20], eax
00007a8ab83cec90  xor eax, eax
00007a8ab83cec92  mov r14d, [rsp+0x10]
00007a8ab83cec97  mov r12d, [rsp+0x20]
00007a8ab83cec9c  cmp r14d, r12d
00007a8ab83cec9f  cmc
00007a8ab83ceca0  lahf
00007a8ab83ceca1  seto al
00007a8ab83ceca4  mov [r15+0x108], eax
00007a8ab83cecab  mov eax, [r15+0x108]
00007a8ab83cecb2  sahf
00007a8ab83cecb3  cmc
00007a8ab83cecb4  jbe 0x00007A8AB83CECE6
00007a8ab83cecb6  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cecbe  jz 0x00007A8AB83CEA90
00007a8ab83cecc4  nop [rax+rax*1], ax
00007a8ab83ceccd  nop [rax+rax*1], eax
00007a8ab83cecd5  mov eax, 0x4101C8
00007a8ab83cecda  mov [r15+0x100], rax
00007a8ab83cece1  jmp 0x00007A8AB81FE110
00007a8ab83cece6  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cecee  jz 0x00007A8AB83CED30
00007a8ab83cecf4  nop [rax+rax*1], ax
00007a8ab83cecfd  nop [rax+rax*1], eax
00007a8ab83ced05  mov eax, 0x4101A0
00007a8ab83ced0a  mov [r15+0x100], rax
00007a8ab83ced11  jmp 0x00007A8AB81FE110
00007a8ab83ced16  int3
00007a8ab83ced17  call 0x00007A8AB82B4690
00007a8ab83ced1c  jmp 0x00007A8AB83CEC7E
00007a8ab83ced21  int3
00007a8ab83ced22  nop [rax+rax*1], ax
00007a8ab83ced2b  nop [rax+rax*1], eax
00007a8ab83ced30  mov rax, [r15+0x40]
00007a8ab83ced34  lea r14, [rax+0x01]
00007a8ab83ced38  mov [r15+0x40], r14
00007a8ab83ced3c  mov rax, [r15+0x50]
00007a8ab83ced40  mov r12d, eax
00007a8ab83ced43  mov r12d, r12d
00007a8ab83ced46  shl r12, 0x02
00007a8ab83ced4a  mov rax, [r15+0x98]
00007a8ab83ced51  lea r11, [rax+r12*1]
00007a8ab83ced55  mov eax, [r15+0x48]
00007a8ab83ced59  mov [r13+r11*1], eax
00007a8ab83ced5e  xor eax, eax
00007a8ab83ced60  mov r12d, 0x400
00007a8ab83ced66  cmp r14, r12
00007a8ab83ced69  cmc
00007a8ab83ced6a  lahf
00007a8ab83ced6b  seto al
00007a8ab83ced6e  mov [r15+0x108], eax
00007a8ab83ced75  mov eax, [r15+0x108]
00007a8ab83ced7c  sahf
00007a8ab83ced7d  jz 0x00007A8AB83CEDAF
00007a8ab83ced7f  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ced87  jz 0x00007A8AB83CE990
00007a8ab83ced8d  nop [rax+rax*1], ax
00007a8ab83ced96  nop [rax+rax*1], eax
00007a8ab83ced9e  mov eax, 0x4101B0
00007a8ab83ceda3  mov [r15+0x100], rax
00007a8ab83cedaa  jmp 0x00007A8AB81FE110
00007a8ab83cedaf  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cedb7  jz 0x00007A8AB83CEDF0
00007a8ab83cedbd  nop [rax+rax*1], ax
00007a8ab83cedc6  nop [rax+rax*1], eax
00007a8ab83cedce  mov eax, 0x4101D8
00007a8ab83cedd3  mov [r15+0x100], rax
00007a8ab83cedda  jmp 0x00007A8AB81FE110
00007a8ab83ceddf  int3
00007a8ab83cede0  call 0x00007A8AB82A4270
00007a8ab83cede5  jmp 0x00007A8AB83CED5E
00007a8ab83cedea  int3
00007a8ab83cedeb  nop [rax+rax*1], eax
00007a8ab83cedf0  mov qword ptr [r15+0x40], 0x420000
00007a8ab83cedf8  mov eax, 0x420288
00007a8ab83cedfd  mov r14, [r13+rax*1]
00007a8ab83cee02  mov rax, [r15+0x98]
00007a8ab83cee09  mov r12d, [r13+rax*1]
00007a8ab83cee0e  lea r11, [rax+0x04]
00007a8ab83cee12  mov eax, [r13+r11*1]
00007a8ab83cee17  mov r12d, r12d
00007a8ab83cee1a  mov [r15+0x68], r12
00007a8ab83cee1e  mov eax, eax
00007a8ab83cee20  mov [r15+0x60], rax
00007a8ab83cee24  mov rax, [r15+0x68]
00007a8ab83cee28  mov [r15+0x68], rax
00007a8ab83cee2c  mov qword ptr [r15+0x58], 0x02
00007a8ab83cee34  mov [rsp+0x10], rax
00007a8ab83cee39  xor eax, eax
00007a8ab83cee3b  mov r12d, 0x02
00007a8ab83cee41  mov r11d, 0x400
00007a8ab83cee47  cmp r12, r11
00007a8ab83cee4a  cmc
00007a8ab83cee4b  lahf
00007a8ab83cee4c  seto al
00007a8ab83cee4f  mov [r15+0x108], eax
00007a8ab83cee56  mov rax, [r15+0x60]
00007a8ab83cee5a  mov r12d, 0x02
00007a8ab83cee60  imul rax, r12
00007a8ab83cee64  mov [r15+0x50], rax
00007a8ab83cee68  mov rax, [rsp+0x10]
00007a8ab83cee6d  lea r12, [rax+r14*1]
00007a8ab83cee71  mov [r15+0x48], r12
00007a8ab83cee75  mov eax, [r15+0x108]
00007a8ab83cee7c  sahf
00007a8ab83cee7d  jnz 0x00007A8AB83CEEAF
00007a8ab83cee7f  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cee87  jz 0x00007A8AB83CF020
00007a8ab83cee8d  nop [rax+rax*1], ax
00007a8ab83cee96  nop [rax+rax*1], eax
00007a8ab83cee9e  mov eax, 0x410208
00007a8ab83ceea3  mov [r15+0x100], rax
00007a8ab83ceeaa  jmp 0x00007A8AB81FE110
00007a8ab83ceeaf  cmp dword ptr [r15+0x318], 0x00
00007a8ab83ceeb7  jz 0x00007A8AB83CEF00
00007a8ab83ceebd  nop [rax+rax*1], ax
00007a8ab83ceec6  nop [rax+rax*1], eax
00007a8ab83ceece  mov eax, 0x4101E8
00007a8ab83ceed3  mov [r15+0x100], rax
00007a8ab83ceeda  jmp 0x00007A8AB81FE110
00007a8ab83ceedf  int3
00007a8ab83ceee0  call 0x00007A8AB820DC20
00007a8ab83ceee5  jmp 0x00007A8AB83CEE02
00007a8ab83ceeea  call 0x00007A8AB820B5E0
00007a8ab83ceeef  jmp 0x00007A8AB83CEE0E
00007a8ab83ceef4  call 0x00007A8AB82A3D90
00007a8ab83ceef9  jmp 0x00007A8AB83CEE17
00007a8ab83ceefe  int3
00007a8ab83ceeff  nop
00007a8ab83cef00  mov rax, [r15+0x98]
00007a8ab83cef07  mov r14, [r15+0x58]
00007a8ab83cef0b  mov [rsp+0x10], r14
00007a8ab83cef10  shl r14, 0x02
00007a8ab83cef14  lea r12, [rax+r14*1]
00007a8ab83cef18  mov eax, [r13+r12*1]
00007a8ab83cef1d  lea r14, [r12+0x04]
00007a8ab83cef22  mov r12d, [r13+r14*1]
00007a8ab83cef27  mov eax, eax
00007a8ab83cef29  mov [r15+0x68], rax
00007a8ab83cef2d  mov r12d, r12d
00007a8ab83cef30  mov [r15+0x60], r12
00007a8ab83cef34  mov rax, [r15+0x68]
00007a8ab83cef38  mov [rsp+0x20], rax
00007a8ab83cef3d  mov r14, [rsp+0x10]
00007a8ab83cef42  imul rax, r14
00007a8ab83cef46  mov r12, [rsp+0x20]
00007a8ab83cef4b  lea r11, [r12+rax*1]
00007a8ab83cef4f  mov [r15+0x68], r11
00007a8ab83cef53  lea rax, [r14+0x02]
00007a8ab83cef57  mov [r15+0x58], rax
00007a8ab83cef5b  mov [rsp+0x10], rax
00007a8ab83cef60  xor eax, eax
00007a8ab83cef62  mov r14, [rsp+0x10]
00007a8ab83cef67  mov r12d, 0x400
00007a8ab83cef6d  cmp r14, r12
00007a8ab83cef70  cmc
00007a8ab83cef71  lahf
00007a8ab83cef72  seto al
00007a8ab83cef75  mov [r15+0x108], eax
00007a8ab83cef7c  mov rax, [r15+0x50]
00007a8ab83cef80  mov r12, [r15+0x60]
00007a8ab83cef84  imul r14, r12
00007a8ab83cef88  lea r12, [rax+r14*1]
00007a8ab83cef8c  mov [r15+0x50], r12
00007a8ab83cef90  mov rax, [r15+0x48]
00007a8ab83cef94  lea r14, [r11+rax*1]
00007a8ab83cef98  mov [r15+0x48], r14
00007a8ab83cef9c  mov eax, [r15+0x108]
00007a8ab83cefa3  sahf
00007a8ab83cefa4  jnz 0x00007A8AB83CEFD6
00007a8ab83cefa6  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cefae  jz 0x00007A8AB83CF020
00007a8ab83cefb4  nop [rax+rax*1], ax
00007a8ab83cefbd  nop [rax+rax*1], eax
00007a8ab83cefc5  mov eax, 0x410208
00007a8ab83cefca  mov [r15+0x100], rax
00007a8ab83cefd1  jmp 0x00007A8AB81FE110
00007a8ab83cefd6  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cefde  jz 0x00007A8AB83CEF00
00007a8ab83cefe4  nop [rax+rax*1], ax
00007a8ab83cefed  nop [rax+rax*1], eax
00007a8ab83ceff5  mov eax, 0x4101E8
00007a8ab83ceffa  mov [r15+0x100], rax
00007a8ab83cf001  jmp 0x00007A8AB81FE110
00007a8ab83cf006  int3
00007a8ab83cf007  call 0x00007A8AB82B4690
00007a8ab83cf00c  jmp 0x00007A8AB83CEF1D
00007a8ab83cf011  call 0x00007A8AB82E26A0
00007a8ab83cf016  jmp 0x00007A8AB83CEF27
00007a8ab83cf01b  int3
00007a8ab83cf01c  nop [rax], eax
00007a8ab83cf020  mov rax, [r15+0xF8]
00007a8ab83cf027  lea r14, [rax+0x10]
00007a8ab83cf02b  mov r12, [r13+r14*1]
00007a8ab83cf030  lea r14, [rax+0x18]
00007a8ab83cf034  mov r11, [r13+r14*1]
00007a8ab83cf039  mov [r15+0xA0], r12
00007a8ab83cf040  mov [r15+0x98], r11
00007a8ab83cf047  mov r14, [r15+0x50]
00007a8ab83cf04b  mov r12, [r15+0x48]
00007a8ab83cf04f  lea r11, [r14+r12*1]
00007a8ab83cf053  mov [r15+0x48], r11
00007a8ab83cf057  mov r14, [r15+0x40]
00007a8ab83cf05b  lea r12, [r14+0x288]
00007a8ab83cf062  mov [r13+r12*1], r11
00007a8ab83cf067  mov r14, [r13+rax*1]
00007a8ab83cf06c  mov [r15+0xF0], r14
00007a8ab83cf073  lea r12, [rax+0x20]
00007a8ab83cf077  mov [r15+0xF8], r12
00007a8ab83cf07e  mov [r15+0x100], r14
00007a8ab83cf085  jmp 0x00007A8AB83CE5C0
00007a8ab83cf08a  int3
00007a8ab83cf08b  call 0x00007A8AB82E27E0
00007a8ab83cf090  jmp 0x00007A8AB83CF030
00007a8ab83cf095  call 0x00007A8AB82E1570
00007a8ab83cf09a  jmp 0x00007A8AB83CF039
00007a8ab83cf09f  call 0x00007A8AB82C0860
00007a8ab83cf0a4  jmp 0x00007A8AB83CF067
00007a8ab83cf0a9  call 0x00007A8AB820DC20
00007a8ab83cf0ae  jmp 0x00007A8AB83CF06C
00007a8ab83cf0b3  int3
00007a8ab83cf0b4  nop [rax+rax*1], ax
00007a8ab83cf0bd  nop [rax], eax
00007a8ab83cf0c0  mov qword ptr [r15+0x100], 0x04
00007a8ab83cf0cb  mov esi, 0x00
00007a8ab83cf0d0  mov edx, 0x09
00007a8ab83cf0d5  mov rdi, 0x7FFF542F3870
00007a8ab83cf0df  mov rax, 0x56556E099970
00007a8ab83cf0e9  call rax
00007a8ab83cf0eb  cmp dword ptr [r15+0x318], 0x00
00007a8ab83cf0f3  jnz 0x00007A8AB81FE110
00007a8ab83cf0f9  jmp 0x00007A8AB81FE0A0
00007a8ab83cf0fe  int3
00007a8ab83cf0ff  int3
