00007ddbb35ce69b  nop [rax+rax*1], eax
00007ddbb35ce6a0  mov rax, [r15+0xF8]
00007ddbb35ce6a7  lea r14, [rax-0x20]
00007ddbb35ce6ab  mov r12, [r15+0xF0]
00007ddbb35ce6b2  mov [r13+r14*1], r12
00007ddbb35ce6b7  mov [r15+0xF8], r14
00007ddbb35ce6be  lea r14, [rax-0x10]
00007ddbb35ce6c2  mov r12, [r15+0xA0]
00007ddbb35ce6c9  mov r11, [r15+0x98]
00007ddbb35ce6d0  mov [r13+r14*1], r12
00007ddbb35ce6d5  lea r14, [rax-0x08]
00007ddbb35ce6d9  mov [r13+r14*1], r11
00007ddbb35ce6de  mov qword ptr [r15+0xA0], 0x00
00007ddbb35ce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007ddbb35ce6f4  mov eax, [r15+0xA0]
00007ddbb35ce6fb  lea r14d, [eax+0x11]
00007ddbb35ce700  mov r14d, r14d
00007ddbb35ce703  mov [r15], r14
00007ddbb35ce706  mov qword ptr [r15+0xF0], 0x410184
00007ddbb35ce711  mov r14d, [r15+0x320]
00007ddbb35ce718  mov eax, 0x410184
00007ddbb35ce71d  mov rcx, 0x7DDBB35CE800
00007ddbb35ce727  mov [r15+r14*8+0x328], rax
00007ddbb35ce72f  mov [r15+r14*8+0x368], rcx
00007ddbb35ce737  add r14d, 0x01
00007ddbb35ce73b  and r14d, 0x07
00007ddbb35ce73f  mov [r15+0x320], r14d
00007ddbb35ce746  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ce74e  jz 0x00007DDBB35CE7A0
00007ddbb35ce754  nop [rax+rax*1], ax
00007ddbb35ce75d  nop [rax+rax*1], eax
00007ddbb35ce765  mov eax, 0x41021C
00007ddbb35ce76a  mov [r15+0x100], rax
00007ddbb35ce771  jmp 0x00007DDBB33FE110
00007ddbb35ce776  int3
00007ddbb35ce777  call 0x00007DDBB34E2CE0
00007ddbb35ce77c  jmp 0x00007DDBB35CE6B7
00007ddbb35ce781  call 0x00007DDBB34E2CE0
00007ddbb35ce786  jmp 0x00007DDBB35CE6D5
00007ddbb35ce78b  call 0x00007DDBB34E1A60
00007ddbb35ce790  jmp 0x00007DDBB35CE6DE
00007ddbb35ce795  int3
00007ddbb35ce796  nop [rax+rax*1], ax
00007ddbb35ce79f  nop
00007ddbb35ce7a0  mov eax, 0x846CA68B
00007ddbb35ce7a5  mov eax, eax
00007ddbb35ce7a7  mov [r15+0x48], rax
00007ddbb35ce7ab  mov eax, [r15]
00007ddbb35ce7ae  imul eax, eax, 0x7FEB352D
00007ddbb35ce7b4  mov [rsp+0x10], eax
00007ddbb35ce7b8  shr eax, 0x0F
00007ddbb35ce7bb  mov r14d, [rsp+0x10]
00007ddbb35ce7c0  xor r14d, eax
00007ddbb35ce7c3  imul r14d, r14d, 0x846CA68B
00007ddbb35ce7ca  mov [rsp+0x10], r14d
00007ddbb35ce7cf  mov r14d, r14d
00007ddbb35ce7d2  mov [r15+0x40], r14
00007ddbb35ce7d6  mov eax, [rsp+0x10]
00007ddbb35ce7da  shr eax, 0x10
00007ddbb35ce7dd  mov r14d, [rsp+0x10]
00007ddbb35ce7e2  xor r14d, eax
00007ddbb35ce7e5  mov r14d, r14d
00007ddbb35ce7e8  mov [r15], r14
00007ddbb35ce7eb  mov rax, [r15+0xF0]
00007ddbb35ce7f2  mov [r15+0x100], rax
00007ddbb35ce7f9  jmp 0x00007DDBB35CE5C0
00007ddbb35ce7fe  int3
00007ddbb35ce7ff  int3
00007ddbb35ce800  mov rax, [r15+0xA0]
00007ddbb35ce807  mov [rsp+0x10], rax
00007ddbb35ce80c  shl rax, 0x02
00007ddbb35ce810  mov r14, [r15+0x98]
00007ddbb35ce817  lea r12, [r14+rax*1]
00007ddbb35ce81b  mov eax, [r15]
00007ddbb35ce81e  mov [r13+r12*1], eax
00007ddbb35ce823  mov rax, [rsp+0x10]
00007ddbb35ce828  lea r14, [rax+0x01]
00007ddbb35ce82c  mov [r15+0xA0], r14
00007ddbb35ce833  xor eax, eax
00007ddbb35ce835  mov r12d, 0x400
00007ddbb35ce83b  cmp r14, r12
00007ddbb35ce83e  cmc
00007ddbb35ce83f  lahf
00007ddbb35ce840  seto al
00007ddbb35ce843  mov [r15+0x108], eax
00007ddbb35ce84a  mov eax, [r15+0x108]
00007ddbb35ce851  sahf
00007ddbb35ce852  jnz 0x00007DDBB35CE884
00007ddbb35ce854  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ce85c  jz 0x00007DDBB35CE950
00007ddbb35ce862  nop [rax+rax*1], ax
00007ddbb35ce86b  nop [rax+rax*1], eax
00007ddbb35ce873  mov eax, 0x410194
00007ddbb35ce878  mov [r15+0x100], rax
00007ddbb35ce87f  jmp 0x00007DDBB33FE110
00007ddbb35ce884  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ce88c  jz 0x00007DDBB35CE8C0
00007ddbb35ce892  nop [rax+rax*1], ax
00007ddbb35ce89b  nop [rax+rax*1], eax
00007ddbb35ce8a3  mov eax, 0x41017C
00007ddbb35ce8a8  mov [r15+0x100], rax
00007ddbb35ce8af  jmp 0x00007DDBB33FE110
00007ddbb35ce8b4  int3
00007ddbb35ce8b5  call 0x00007DDBB34B4B70
00007ddbb35ce8ba  jmp 0x00007DDBB35CE823
00007ddbb35ce8bf  int3
00007ddbb35ce8c0  mov eax, [r15+0xA0]
00007ddbb35ce8c7  lea r14d, [eax+0x11]
00007ddbb35ce8cc  mov r14d, r14d
00007ddbb35ce8cf  mov [r15], r14
00007ddbb35ce8d2  mov qword ptr [r15+0xF0], 0x410184
00007ddbb35ce8dd  mov r14d, [r15+0x320]
00007ddbb35ce8e4  mov eax, 0x410184
00007ddbb35ce8e9  mov rcx, 0x7DDBB35CE800
00007ddbb35ce8f3  mov [r15+r14*8+0x328], rax
00007ddbb35ce8fb  mov [r15+r14*8+0x368], rcx
00007ddbb35ce903  add r14d, 0x01
00007ddbb35ce907  and r14d, 0x07
00007ddbb35ce90b  mov [r15+0x320], r14d
00007ddbb35ce912  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ce91a  jz 0x00007DDBB35CE7A0
00007ddbb35ce920  nop [rax+rax*1], ax
00007ddbb35ce929  nop [rax+rax*1], eax
00007ddbb35ce931  mov eax, 0x41021C
00007ddbb35ce936  mov [r15+0x100], rax
00007ddbb35ce93d  jmp 0x00007DDBB33FE110
00007ddbb35ce942  int3
00007ddbb35ce943  int3
00007ddbb35ce944  nop [rax+rax*1], ax
00007ddbb35ce94d  nop [rax], eax
00007ddbb35ce950  mov qword ptr [r15+0x40], 0x01
00007ddbb35ce958  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ce960  jz 0x00007DDBB35CE990
00007ddbb35ce966  nop [rax+rax*1], ax
00007ddbb35ce96f  nop [rax+rax*1], eax
00007ddbb35ce977  mov eax, 0x4101B0
00007ddbb35ce97c  mov [r15+0x100], rax
00007ddbb35ce983  jmp 0x00007DDBB33FE110
00007ddbb35ce988  int3
00007ddbb35ce989  int3
00007ddbb35ce98a  nop [rax+rax*1], ax
00007ddbb35ce990  mov rax, [r15+0x40]
00007ddbb35ce994  mov [rsp+0x10], rax
00007ddbb35ce999  shl rax, 0x02
00007ddbb35ce99d  mov r14, [r15+0x98]
00007ddbb35ce9a4  lea r12, [r14+rax*1]
00007ddbb35ce9a8  mov eax, [r13+r12*1]
00007ddbb35ce9ad  mov [rsp+0x20], eax
00007ddbb35ce9b1  mov eax, eax
00007ddbb35ce9b3  mov [r15+0x48], rax
00007ddbb35ce9b7  mov rax, [rsp+0x10]
00007ddbb35ce9bc  mov [r15+0x50], rax
00007ddbb35ce9c0  mov eax, [r15+0x50]
00007ddbb35ce9c4  lea r12d, [eax-0x01]
00007ddbb35ce9c9  mov r12d, r12d
00007ddbb35ce9cc  mov [r15+0x58], r12
00007ddbb35ce9d0  mov rax, [r15+0x58]
00007ddbb35ce9d4  mov r12d, eax
00007ddbb35ce9d7  mov r12d, r12d
00007ddbb35ce9da  shl r12, 0x02
00007ddbb35ce9de  lea rax, [r14+r12*1]
00007ddbb35ce9e2  mov r14d, [r13+rax*1]
00007ddbb35ce9e7  mov [rsp+0x10], r14d
00007ddbb35ce9ec  mov r14d, r14d
00007ddbb35ce9ef  mov [r15+0x60], r14
00007ddbb35ce9f3  xor eax, eax
00007ddbb35ce9f5  mov r14d, [rsp+0x10]
00007ddbb35ce9fa  mov r12d, [rsp+0x20]
00007ddbb35ce9ff  cmp r14d, r12d
00007ddbb35cea02  cmc
00007ddbb35cea03  lahf
00007ddbb35cea04  seto al
00007ddbb35cea07  mov [r15+0x108], eax
00007ddbb35cea0e  mov eax, [r15+0x108]
00007ddbb35cea15  sahf
00007ddbb35cea16  cmc
00007ddbb35cea17  jbe 0x00007DDBB35CEA49
00007ddbb35cea19  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cea21  jz 0x00007DDBB35CEA90
00007ddbb35cea27  nop [rax+rax*1], ax
00007ddbb35cea30  nop [rax+rax*1], eax
00007ddbb35cea38  mov eax, 0x4101C8
00007ddbb35cea3d  mov [r15+0x100], rax
00007ddbb35cea44  jmp 0x00007DDBB33FE110
00007ddbb35cea49  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cea51  jz 0x00007DDBB35CED30
00007ddbb35cea57  nop [rax+rax*1], ax
00007ddbb35cea60  nop [rax+rax*1], eax
00007ddbb35cea68  mov eax, 0x4101A0
00007ddbb35cea6d  mov [r15+0x100], rax
00007ddbb35cea74  jmp 0x00007DDBB33FE110
00007ddbb35cea79  int3
00007ddbb35cea7a  call 0x00007DDBB34B4690
00007ddbb35cea7f  jmp 0x00007DDBB35CE9AD
00007ddbb35cea84  call 0x00007DDBB340DAE0
00007ddbb35cea89  jmp 0x00007DDBB35CE9E7
00007ddbb35cea8e  int3
00007ddbb35cea8f  nop
00007ddbb35cea90  mov rax, [r15+0x50]
00007ddbb35cea94  mov [rsp+0x10], rax
00007ddbb35cea99  shl rax, 0x02
00007ddbb35cea9d  mov r14, [r15+0x98]
00007ddbb35ceaa4  lea r12, [r14+rax*1]
00007ddbb35ceaa8  mov eax, [r15+0x60]
00007ddbb35ceaac  mov [r13+r12*1], eax
00007ddbb35ceab1  mov rax, [rsp+0x10]
00007ddbb35ceab6  lea r14, [rax-0x01]
00007ddbb35ceaba  mov [r15+0x50], r14
00007ddbb35ceabe  mov rax, [r15+0x58]
00007ddbb35ceac2  test rax, rax
00007ddbb35ceac5  setz al
00007ddbb35ceac8  movzx rax, al
00007ddbb35ceacc  mov [rsp+0x414], al
00007ddbb35cead3  cmp byte ptr [rsp+0x414], 0x00
00007ddbb35ceadb  jz 0x00007DDBB35CEB0D
00007ddbb35ceadd  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ceae5  jz 0x00007DDBB35CEB50
00007ddbb35ceaeb  nop [rax+rax*1], ax
00007ddbb35ceaf4  nop [rax+rax*1], eax
00007ddbb35ceafc  mov eax, 0x4101D4
00007ddbb35ceb01  mov [r15+0x100], rax
00007ddbb35ceb08  jmp 0x00007DDBB33FE110
00007ddbb35ceb0d  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ceb15  jz 0x00007DDBB35CEC50
00007ddbb35ceb1b  nop [rax+rax*1], ax
00007ddbb35ceb24  nop [rax+rax*1], eax
00007ddbb35ceb2c  mov eax, 0x4101B8
00007ddbb35ceb31  mov [r15+0x100], rax
00007ddbb35ceb38  jmp 0x00007DDBB33FE110
00007ddbb35ceb3d  int3
00007ddbb35ceb3e  call 0x00007DDBB34B4B70
00007ddbb35ceb43  jmp 0x00007DDBB35CEAB1
00007ddbb35ceb48  int3
00007ddbb35ceb49  nop [rax], eax
00007ddbb35ceb50  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ceb58  jz 0x00007DDBB35CEB90
00007ddbb35ceb5e  nop [rax+rax*1], ax
00007ddbb35ceb67  nop [rax+rax*1], eax
00007ddbb35ceb6f  mov eax, 0x41019C
00007ddbb35ceb74  mov [r15+0x100], rax
00007ddbb35ceb7b  jmp 0x00007DDBB33FE110
00007ddbb35ceb80  int3
00007ddbb35ceb81  int3
00007ddbb35ceb82  nop [rax+rax*1], ax
00007ddbb35ceb8b  nop [rax+rax*1], eax
00007ddbb35ceb90  mov qword ptr [r15+0x50], 0x00
00007ddbb35ceb98  mov rax, [r15+0x40]
00007ddbb35ceb9c  lea r14, [rax+0x01]
00007ddbb35ceba0  mov [r15+0x40], r14
00007ddbb35ceba4  mov rax, [r15+0x98]
00007ddbb35cebab  mov r12d, [r15+0x48]
00007ddbb35cebaf  mov [r13+rax*1], r12d
00007ddbb35cebb4  xor eax, eax
00007ddbb35cebb6  mov r12d, 0x400
00007ddbb35cebbc  cmp r14, r12
00007ddbb35cebbf  cmc
00007ddbb35cebc0  lahf
00007ddbb35cebc1  seto al
00007ddbb35cebc4  mov [r15+0x108], eax
00007ddbb35cebcb  mov eax, [r15+0x108]
00007ddbb35cebd2  sahf
00007ddbb35cebd3  jz 0x00007DDBB35CEC05
00007ddbb35cebd5  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cebdd  jz 0x00007DDBB35CE990
00007ddbb35cebe3  nop [rax+rax*1], ax
00007ddbb35cebec  nop [rax+rax*1], eax
00007ddbb35cebf4  mov eax, 0x4101B0
00007ddbb35cebf9  mov [r15+0x100], rax
00007ddbb35cec00  jmp 0x00007DDBB33FE110
00007ddbb35cec05  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cec0d  jz 0x00007DDBB35CEDF0
00007ddbb35cec13  nop [rax+rax*1], ax
00007ddbb35cec1c  nop [rax+rax*1], eax
00007ddbb35cec24  mov eax, 0x4101D8
00007ddbb35cec29  mov [r15+0x100], rax
00007ddbb35cec30  jmp 0x00007DDBB33FE110
00007ddbb35cec35  int3
00007ddbb35cec36  call 0x00007DDBB340BAE0
00007ddbb35cec3b  jmp 0x00007DDBB35CEBB4
00007ddbb35cec40  int3
00007ddbb35cec41  nop [rax+rax*1], ax
00007ddbb35cec4a  nop [rax+rax*1], ax
00007ddbb35cec50  mov eax, [r15+0x50]
00007ddbb35cec54  lea r14d, [eax-0x01]
00007ddbb35cec59  mov r14d, r14d
00007ddbb35cec5c  mov [r15+0x58], r14
00007ddbb35cec60  mov rax, [r15+0x58]
00007ddbb35cec64  mov r14d, eax
00007ddbb35cec67  mov r14d, r14d
00007ddbb35cec6a  shl r14, 0x02
00007ddbb35cec6e  mov rax, [r15+0x98]
00007ddbb35cec75  lea r12, [rax+r14*1]
00007ddbb35cec79  mov eax, [r13+r12*1]
00007ddbb35cec7e  mov [rsp+0x10], eax
00007ddbb35cec82  mov eax, eax
00007ddbb35cec84  mov [r15+0x60], rax
00007ddbb35cec88  mov eax, [r15+0x48]
00007ddbb35cec8c  mov [rsp+0x20], eax
00007ddbb35cec90  xor eax, eax
00007ddbb35cec92  mov r14d, [rsp+0x10]
00007ddbb35cec97  mov r12d, [rsp+0x20]
00007ddbb35cec9c  cmp r14d, r12d
00007ddbb35cec9f  cmc
00007ddbb35ceca0  lahf
00007ddbb35ceca1  seto al
00007ddbb35ceca4  mov [r15+0x108], eax
00007ddbb35cecab  mov eax, [r15+0x108]
00007ddbb35cecb2  sahf
00007ddbb35cecb3  cmc
00007ddbb35cecb4  jbe 0x00007DDBB35CECE6
00007ddbb35cecb6  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cecbe  jz 0x00007DDBB35CEA90
00007ddbb35cecc4  nop [rax+rax*1], ax
00007ddbb35ceccd  nop [rax+rax*1], eax
00007ddbb35cecd5  mov eax, 0x4101C8
00007ddbb35cecda  mov [r15+0x100], rax
00007ddbb35cece1  jmp 0x00007DDBB33FE110
00007ddbb35cece6  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cecee  jz 0x00007DDBB35CED30
00007ddbb35cecf4  nop [rax+rax*1], ax
00007ddbb35cecfd  nop [rax+rax*1], eax
00007ddbb35ced05  mov eax, 0x4101A0
00007ddbb35ced0a  mov [r15+0x100], rax
00007ddbb35ced11  jmp 0x00007DDBB33FE110
00007ddbb35ced16  int3
00007ddbb35ced17  call 0x00007DDBB34B4690
00007ddbb35ced1c  jmp 0x00007DDBB35CEC7E
00007ddbb35ced21  int3
00007ddbb35ced22  nop [rax+rax*1], ax
00007ddbb35ced2b  nop [rax+rax*1], eax
00007ddbb35ced30  mov rax, [r15+0x40]
00007ddbb35ced34  lea r14, [rax+0x01]
00007ddbb35ced38  mov [r15+0x40], r14
00007ddbb35ced3c  mov rax, [r15+0x50]
00007ddbb35ced40  mov r12d, eax
00007ddbb35ced43  mov r12d, r12d
00007ddbb35ced46  shl r12, 0x02
00007ddbb35ced4a  mov rax, [r15+0x98]
00007ddbb35ced51  lea r11, [rax+r12*1]
00007ddbb35ced55  mov eax, [r15+0x48]
00007ddbb35ced59  mov [r13+r11*1], eax
00007ddbb35ced5e  xor eax, eax
00007ddbb35ced60  mov r12d, 0x400
00007ddbb35ced66  cmp r14, r12
00007ddbb35ced69  cmc
00007ddbb35ced6a  lahf
00007ddbb35ced6b  seto al
00007ddbb35ced6e  mov [r15+0x108], eax
00007ddbb35ced75  mov eax, [r15+0x108]
00007ddbb35ced7c  sahf
00007ddbb35ced7d  jz 0x00007DDBB35CEDAF
00007ddbb35ced7f  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ced87  jz 0x00007DDBB35CE990
00007ddbb35ced8d  nop [rax+rax*1], ax
00007ddbb35ced96  nop [rax+rax*1], eax
00007ddbb35ced9e  mov eax, 0x4101B0
00007ddbb35ceda3  mov [r15+0x100], rax
00007ddbb35cedaa  jmp 0x00007DDBB33FE110
00007ddbb35cedaf  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cedb7  jz 0x00007DDBB35CEDF0
00007ddbb35cedbd  nop [rax+rax*1], ax
00007ddbb35cedc6  nop [rax+rax*1], eax
00007ddbb35cedce  mov eax, 0x4101D8
00007ddbb35cedd3  mov [r15+0x100], rax
00007ddbb35cedda  jmp 0x00007DDBB33FE110
00007ddbb35ceddf  int3
00007ddbb35cede0  call 0x00007DDBB34A4270
00007ddbb35cede5  jmp 0x00007DDBB35CED5E
00007ddbb35cedea  int3
00007ddbb35cedeb  nop [rax+rax*1], eax
00007ddbb35cedf0  mov qword ptr [r15+0x40], 0x420000
00007ddbb35cedf8  mov eax, 0x420288
00007ddbb35cedfd  mov r14, [r13+rax*1]
00007ddbb35cee02  mov rax, [r15+0x98]
00007ddbb35cee09  mov r12d, [r13+rax*1]
00007ddbb35cee0e  lea r11, [rax+0x04]
00007ddbb35cee12  mov eax, [r13+r11*1]
00007ddbb35cee17  mov r12d, r12d
00007ddbb35cee1a  mov [r15+0x68], r12
00007ddbb35cee1e  mov eax, eax
00007ddbb35cee20  mov [r15+0x60], rax
00007ddbb35cee24  mov rax, [r15+0x68]
00007ddbb35cee28  mov [r15+0x68], rax
00007ddbb35cee2c  mov qword ptr [r15+0x58], 0x02
00007ddbb35cee34  mov [rsp+0x10], rax
00007ddbb35cee39  xor eax, eax
00007ddbb35cee3b  mov r12d, 0x02
00007ddbb35cee41  mov r11d, 0x400
00007ddbb35cee47  cmp r12, r11
00007ddbb35cee4a  cmc
00007ddbb35cee4b  lahf
00007ddbb35cee4c  seto al
00007ddbb35cee4f  mov [r15+0x108], eax
00007ddbb35cee56  mov rax, [r15+0x60]
00007ddbb35cee5a  mov r12d, 0x02
00007ddbb35cee60  imul rax, r12
00007ddbb35cee64  mov [r15+0x50], rax
00007ddbb35cee68  mov rax, [rsp+0x10]
00007ddbb35cee6d  lea r12, [rax+r14*1]
00007ddbb35cee71  mov [r15+0x48], r12
00007ddbb35cee75  mov eax, [r15+0x108]
00007ddbb35cee7c  sahf
00007ddbb35cee7d  jnz 0x00007DDBB35CEEAF
00007ddbb35cee7f  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cee87  jz 0x00007DDBB35CF020
00007ddbb35cee8d  nop [rax+rax*1], ax
00007ddbb35cee96  nop [rax+rax*1], eax
00007ddbb35cee9e  mov eax, 0x410208
00007ddbb35ceea3  mov [r15+0x100], rax
00007ddbb35ceeaa  jmp 0x00007DDBB33FE110
00007ddbb35ceeaf  cmp dword ptr [r15+0x318], 0x00
00007ddbb35ceeb7  jz 0x00007DDBB35CEF00
00007ddbb35ceebd  nop [rax+rax*1], ax
00007ddbb35ceec6  nop [rax+rax*1], eax
00007ddbb35ceece  mov eax, 0x4101E8
00007ddbb35ceed3  mov [r15+0x100], rax
00007ddbb35ceeda  jmp 0x00007DDBB33FE110
00007ddbb35ceedf  int3
00007ddbb35ceee0  call 0x00007DDBB340DC20
00007ddbb35ceee5  jmp 0x00007DDBB35CEE02
00007ddbb35ceeea  call 0x00007DDBB340B5E0
00007ddbb35ceeef  jmp 0x00007DDBB35CEE0E
00007ddbb35ceef4  call 0x00007DDBB34A3D90
00007ddbb35ceef9  jmp 0x00007DDBB35CEE17
00007ddbb35ceefe  int3
00007ddbb35ceeff  nop
00007ddbb35cef00  mov rax, [r15+0x98]
00007ddbb35cef07  mov r14, [r15+0x58]
00007ddbb35cef0b  mov [rsp+0x10], r14
00007ddbb35cef10  shl r14, 0x02
00007ddbb35cef14  lea r12, [rax+r14*1]
00007ddbb35cef18  mov eax, [r13+r12*1]
00007ddbb35cef1d  lea r14, [r12+0x04]
00007ddbb35cef22  mov r12d, [r13+r14*1]
00007ddbb35cef27  mov eax, eax
00007ddbb35cef29  mov [r15+0x68], rax
00007ddbb35cef2d  mov r12d, r12d
00007ddbb35cef30  mov [r15+0x60], r12
00007ddbb35cef34  mov rax, [r15+0x68]
00007ddbb35cef38  mov [rsp+0x20], rax
00007ddbb35cef3d  mov r14, [rsp+0x10]
00007ddbb35cef42  imul rax, r14
00007ddbb35cef46  mov r12, [rsp+0x20]
00007ddbb35cef4b  lea r11, [r12+rax*1]
00007ddbb35cef4f  mov [r15+0x68], r11
00007ddbb35cef53  lea rax, [r14+0x02]
00007ddbb35cef57  mov [r15+0x58], rax
00007ddbb35cef5b  mov [rsp+0x10], rax
00007ddbb35cef60  xor eax, eax
00007ddbb35cef62  mov r14, [rsp+0x10]
00007ddbb35cef67  mov r12d, 0x400
00007ddbb35cef6d  cmp r14, r12
00007ddbb35cef70  cmc
00007ddbb35cef71  lahf
00007ddbb35cef72  seto al
00007ddbb35cef75  mov [r15+0x108], eax
00007ddbb35cef7c  mov rax, [r15+0x50]
00007ddbb35cef80  mov r12, [r15+0x60]
00007ddbb35cef84  imul r14, r12
00007ddbb35cef88  lea r12, [rax+r14*1]
00007ddbb35cef8c  mov [r15+0x50], r12
00007ddbb35cef90  mov rax, [r15+0x48]
00007ddbb35cef94  lea r14, [r11+rax*1]
00007ddbb35cef98  mov [r15+0x48], r14
00007ddbb35cef9c  mov eax, [r15+0x108]
00007ddbb35cefa3  sahf
00007ddbb35cefa4  jnz 0x00007DDBB35CEFD6
00007ddbb35cefa6  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cefae  jz 0x00007DDBB35CF020
00007ddbb35cefb4  nop [rax+rax*1], ax
00007ddbb35cefbd  nop [rax+rax*1], eax
00007ddbb35cefc5  mov eax, 0x410208
00007ddbb35cefca  mov [r15+0x100], rax
00007ddbb35cefd1  jmp 0x00007DDBB33FE110
00007ddbb35cefd6  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cefde  jz 0x00007DDBB35CEF00
00007ddbb35cefe4  nop [rax+rax*1], ax
00007ddbb35cefed  nop [rax+rax*1], eax
00007ddbb35ceff5  mov eax, 0x4101E8
00007ddbb35ceffa  mov [r15+0x100], rax
00007ddbb35cf001  jmp 0x00007DDBB33FE110
00007ddbb35cf006  int3
00007ddbb35cf007  call 0x00007DDBB34B4690
00007ddbb35cf00c  jmp 0x00007DDBB35CEF1D
00007ddbb35cf011  call 0x00007DDBB34E26A0
00007ddbb35cf016  jmp 0x00007DDBB35CEF27
00007ddbb35cf01b  int3
00007ddbb35cf01c  nop [rax], eax
00007ddbb35cf020  mov rax, [r15+0xF8]
00007ddbb35cf027  lea r14, [rax+0x10]
00007ddbb35cf02b  mov r12, [r13+r14*1]
00007ddbb35cf030  lea r14, [rax+0x18]
00007ddbb35cf034  mov r11, [r13+r14*1]
00007ddbb35cf039  mov [r15+0xA0], r12
00007ddbb35cf040  mov [r15+0x98], r11
00007ddbb35cf047  mov r14, [r15+0x50]
00007ddbb35cf04b  mov r12, [r15+0x48]
00007ddbb35cf04f  lea r11, [r14+r12*1]
00007ddbb35cf053  mov [r15+0x48], r11
00007ddbb35cf057  mov r14, [r15+0x40]
00007ddbb35cf05b  lea r12, [r14+0x288]
00007ddbb35cf062  mov [r13+r12*1], r11
00007ddbb35cf067  mov r14, [r13+rax*1]
00007ddbb35cf06c  mov [r15+0xF0], r14
00007ddbb35cf073  lea r12, [rax+0x20]
00007ddbb35cf077  mov [r15+0xF8], r12
00007ddbb35cf07e  mov [r15+0x100], r14
00007ddbb35cf085  jmp 0x00007DDBB35CE5C0
00007ddbb35cf08a  int3
00007ddbb35cf08b  call 0x00007DDBB34E27E0
00007ddbb35cf090  jmp 0x00007DDBB35CF030
00007ddbb35cf095  call 0x00007DDBB34E1570
00007ddbb35cf09a  jmp 0x00007DDBB35CF039
00007ddbb35cf09f  call 0x00007DDBB34C0860
00007ddbb35cf0a4  jmp 0x00007DDBB35CF067
00007ddbb35cf0a9  call 0x00007DDBB340DC20
00007ddbb35cf0ae  jmp 0x00007DDBB35CF06C
00007ddbb35cf0b3  int3
00007ddbb35cf0b4  nop [rax+rax*1], ax
00007ddbb35cf0bd  nop [rax], eax
00007ddbb35cf0c0  mov qword ptr [r15+0x100], 0x04
00007ddbb35cf0cb  mov esi, 0x00
00007ddbb35cf0d0  mov edx, 0x09
00007ddbb35cf0d5  mov rdi, 0x7FFEA760A5D0
00007ddbb35cf0df  mov rax, 0x5A2012AD9970
00007ddbb35cf0e9  call rax
00007ddbb35cf0eb  cmp dword ptr [r15+0x318], 0x00
00007ddbb35cf0f3  jnz 0x00007DDBB33FE110
00007ddbb35cf0f9  jmp 0x00007DDBB33FE0A0
00007ddbb35cf0fe  int3
00007ddbb35cf0ff  int3
