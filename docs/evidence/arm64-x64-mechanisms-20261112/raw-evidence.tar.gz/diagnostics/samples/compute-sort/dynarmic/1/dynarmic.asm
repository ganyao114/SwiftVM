0000736dd07ce69b  nop [rax+rax*1], eax
0000736dd07ce6a0  mov rax, [r15+0xF8]
0000736dd07ce6a7  lea r14, [rax-0x20]
0000736dd07ce6ab  mov r12, [r15+0xF0]
0000736dd07ce6b2  mov [r13+r14*1], r12
0000736dd07ce6b7  mov [r15+0xF8], r14
0000736dd07ce6be  lea r14, [rax-0x10]
0000736dd07ce6c2  mov r12, [r15+0xA0]
0000736dd07ce6c9  mov r11, [r15+0x98]
0000736dd07ce6d0  mov [r13+r14*1], r12
0000736dd07ce6d5  lea r14, [rax-0x08]
0000736dd07ce6d9  mov [r13+r14*1], r11
0000736dd07ce6de  mov qword ptr [r15+0xA0], 0x00
0000736dd07ce6e9  mov qword ptr [r15+0x98], 0x4202A0
0000736dd07ce6f4  mov eax, [r15+0xA0]
0000736dd07ce6fb  lea r14d, [eax+0x11]
0000736dd07ce700  mov r14d, r14d
0000736dd07ce703  mov [r15], r14
0000736dd07ce706  mov qword ptr [r15+0xF0], 0x410184
0000736dd07ce711  mov r14d, [r15+0x320]
0000736dd07ce718  mov eax, 0x410184
0000736dd07ce71d  mov rcx, 0x736DD07CE800
0000736dd07ce727  mov [r15+r14*8+0x328], rax
0000736dd07ce72f  mov [r15+r14*8+0x368], rcx
0000736dd07ce737  add r14d, 0x01
0000736dd07ce73b  and r14d, 0x07
0000736dd07ce73f  mov [r15+0x320], r14d
0000736dd07ce746  cmp dword ptr [r15+0x318], 0x00
0000736dd07ce74e  jz 0x0000736DD07CE7A0
0000736dd07ce754  nop [rax+rax*1], ax
0000736dd07ce75d  nop [rax+rax*1], eax
0000736dd07ce765  mov eax, 0x41021C
0000736dd07ce76a  mov [r15+0x100], rax
0000736dd07ce771  jmp 0x0000736DD05FE110
0000736dd07ce776  int3
0000736dd07ce777  call 0x0000736DD06E2CE0
0000736dd07ce77c  jmp 0x0000736DD07CE6B7
0000736dd07ce781  call 0x0000736DD06E2CE0
0000736dd07ce786  jmp 0x0000736DD07CE6D5
0000736dd07ce78b  call 0x0000736DD06E1A60
0000736dd07ce790  jmp 0x0000736DD07CE6DE
0000736dd07ce795  int3
0000736dd07ce796  nop [rax+rax*1], ax
0000736dd07ce79f  nop
0000736dd07ce7a0  mov eax, 0x846CA68B
0000736dd07ce7a5  mov eax, eax
0000736dd07ce7a7  mov [r15+0x48], rax
0000736dd07ce7ab  mov eax, [r15]
0000736dd07ce7ae  imul eax, eax, 0x7FEB352D
0000736dd07ce7b4  mov [rsp+0x10], eax
0000736dd07ce7b8  shr eax, 0x0F
0000736dd07ce7bb  mov r14d, [rsp+0x10]
0000736dd07ce7c0  xor r14d, eax
0000736dd07ce7c3  imul r14d, r14d, 0x846CA68B
0000736dd07ce7ca  mov [rsp+0x10], r14d
0000736dd07ce7cf  mov r14d, r14d
0000736dd07ce7d2  mov [r15+0x40], r14
0000736dd07ce7d6  mov eax, [rsp+0x10]
0000736dd07ce7da  shr eax, 0x10
0000736dd07ce7dd  mov r14d, [rsp+0x10]
0000736dd07ce7e2  xor r14d, eax
0000736dd07ce7e5  mov r14d, r14d
0000736dd07ce7e8  mov [r15], r14
0000736dd07ce7eb  mov rax, [r15+0xF0]
0000736dd07ce7f2  mov [r15+0x100], rax
0000736dd07ce7f9  jmp 0x0000736DD07CE5C0
0000736dd07ce7fe  int3
0000736dd07ce7ff  int3
0000736dd07ce800  mov rax, [r15+0xA0]
0000736dd07ce807  mov [rsp+0x10], rax
0000736dd07ce80c  shl rax, 0x02
0000736dd07ce810  mov r14, [r15+0x98]
0000736dd07ce817  lea r12, [r14+rax*1]
0000736dd07ce81b  mov eax, [r15]
0000736dd07ce81e  mov [r13+r12*1], eax
0000736dd07ce823  mov rax, [rsp+0x10]
0000736dd07ce828  lea r14, [rax+0x01]
0000736dd07ce82c  mov [r15+0xA0], r14
0000736dd07ce833  xor eax, eax
0000736dd07ce835  mov r12d, 0x400
0000736dd07ce83b  cmp r14, r12
0000736dd07ce83e  cmc
0000736dd07ce83f  lahf
0000736dd07ce840  seto al
0000736dd07ce843  mov [r15+0x108], eax
0000736dd07ce84a  mov eax, [r15+0x108]
0000736dd07ce851  sahf
0000736dd07ce852  jnz 0x0000736DD07CE884
0000736dd07ce854  cmp dword ptr [r15+0x318], 0x00
0000736dd07ce85c  jz 0x0000736DD07CE950
0000736dd07ce862  nop [rax+rax*1], ax
0000736dd07ce86b  nop [rax+rax*1], eax
0000736dd07ce873  mov eax, 0x410194
0000736dd07ce878  mov [r15+0x100], rax
0000736dd07ce87f  jmp 0x0000736DD05FE110
0000736dd07ce884  cmp dword ptr [r15+0x318], 0x00
0000736dd07ce88c  jz 0x0000736DD07CE8C0
0000736dd07ce892  nop [rax+rax*1], ax
0000736dd07ce89b  nop [rax+rax*1], eax
0000736dd07ce8a3  mov eax, 0x41017C
0000736dd07ce8a8  mov [r15+0x100], rax
0000736dd07ce8af  jmp 0x0000736DD05FE110
0000736dd07ce8b4  int3
0000736dd07ce8b5  call 0x0000736DD06B4B70
0000736dd07ce8ba  jmp 0x0000736DD07CE823
0000736dd07ce8bf  int3
0000736dd07ce8c0  mov eax, [r15+0xA0]
0000736dd07ce8c7  lea r14d, [eax+0x11]
0000736dd07ce8cc  mov r14d, r14d
0000736dd07ce8cf  mov [r15], r14
0000736dd07ce8d2  mov qword ptr [r15+0xF0], 0x410184
0000736dd07ce8dd  mov r14d, [r15+0x320]
0000736dd07ce8e4  mov eax, 0x410184
0000736dd07ce8e9  mov rcx, 0x736DD07CE800
0000736dd07ce8f3  mov [r15+r14*8+0x328], rax
0000736dd07ce8fb  mov [r15+r14*8+0x368], rcx
0000736dd07ce903  add r14d, 0x01
0000736dd07ce907  and r14d, 0x07
0000736dd07ce90b  mov [r15+0x320], r14d
0000736dd07ce912  cmp dword ptr [r15+0x318], 0x00
0000736dd07ce91a  jz 0x0000736DD07CE7A0
0000736dd07ce920  nop [rax+rax*1], ax
0000736dd07ce929  nop [rax+rax*1], eax
0000736dd07ce931  mov eax, 0x41021C
0000736dd07ce936  mov [r15+0x100], rax
0000736dd07ce93d  jmp 0x0000736DD05FE110
0000736dd07ce942  int3
0000736dd07ce943  int3
0000736dd07ce944  nop [rax+rax*1], ax
0000736dd07ce94d  nop [rax], eax
0000736dd07ce950  mov qword ptr [r15+0x40], 0x01
0000736dd07ce958  cmp dword ptr [r15+0x318], 0x00
0000736dd07ce960  jz 0x0000736DD07CE990
0000736dd07ce966  nop [rax+rax*1], ax
0000736dd07ce96f  nop [rax+rax*1], eax
0000736dd07ce977  mov eax, 0x4101B0
0000736dd07ce97c  mov [r15+0x100], rax
0000736dd07ce983  jmp 0x0000736DD05FE110
0000736dd07ce988  int3
0000736dd07ce989  int3
0000736dd07ce98a  nop [rax+rax*1], ax
0000736dd07ce990  mov rax, [r15+0x40]
0000736dd07ce994  mov [rsp+0x10], rax
0000736dd07ce999  shl rax, 0x02
0000736dd07ce99d  mov r14, [r15+0x98]
0000736dd07ce9a4  lea r12, [r14+rax*1]
0000736dd07ce9a8  mov eax, [r13+r12*1]
0000736dd07ce9ad  mov [rsp+0x20], eax
0000736dd07ce9b1  mov eax, eax
0000736dd07ce9b3  mov [r15+0x48], rax
0000736dd07ce9b7  mov rax, [rsp+0x10]
0000736dd07ce9bc  mov [r15+0x50], rax
0000736dd07ce9c0  mov eax, [r15+0x50]
0000736dd07ce9c4  lea r12d, [eax-0x01]
0000736dd07ce9c9  mov r12d, r12d
0000736dd07ce9cc  mov [r15+0x58], r12
0000736dd07ce9d0  mov rax, [r15+0x58]
0000736dd07ce9d4  mov r12d, eax
0000736dd07ce9d7  mov r12d, r12d
0000736dd07ce9da  shl r12, 0x02
0000736dd07ce9de  lea rax, [r14+r12*1]
0000736dd07ce9e2  mov r14d, [r13+rax*1]
0000736dd07ce9e7  mov [rsp+0x10], r14d
0000736dd07ce9ec  mov r14d, r14d
0000736dd07ce9ef  mov [r15+0x60], r14
0000736dd07ce9f3  xor eax, eax
0000736dd07ce9f5  mov r14d, [rsp+0x10]
0000736dd07ce9fa  mov r12d, [rsp+0x20]
0000736dd07ce9ff  cmp r14d, r12d
0000736dd07cea02  cmc
0000736dd07cea03  lahf
0000736dd07cea04  seto al
0000736dd07cea07  mov [r15+0x108], eax
0000736dd07cea0e  mov eax, [r15+0x108]
0000736dd07cea15  sahf
0000736dd07cea16  cmc
0000736dd07cea17  jbe 0x0000736DD07CEA49
0000736dd07cea19  cmp dword ptr [r15+0x318], 0x00
0000736dd07cea21  jz 0x0000736DD07CEA90
0000736dd07cea27  nop [rax+rax*1], ax
0000736dd07cea30  nop [rax+rax*1], eax
0000736dd07cea38  mov eax, 0x4101C8
0000736dd07cea3d  mov [r15+0x100], rax
0000736dd07cea44  jmp 0x0000736DD05FE110
0000736dd07cea49  cmp dword ptr [r15+0x318], 0x00
0000736dd07cea51  jz 0x0000736DD07CED30
0000736dd07cea57  nop [rax+rax*1], ax
0000736dd07cea60  nop [rax+rax*1], eax
0000736dd07cea68  mov eax, 0x4101A0
0000736dd07cea6d  mov [r15+0x100], rax
0000736dd07cea74  jmp 0x0000736DD05FE110
0000736dd07cea79  int3
0000736dd07cea7a  call 0x0000736DD06B4690
0000736dd07cea7f  jmp 0x0000736DD07CE9AD
0000736dd07cea84  call 0x0000736DD060DAE0
0000736dd07cea89  jmp 0x0000736DD07CE9E7
0000736dd07cea8e  int3
0000736dd07cea8f  nop
0000736dd07cea90  mov rax, [r15+0x50]
0000736dd07cea94  mov [rsp+0x10], rax
0000736dd07cea99  shl rax, 0x02
0000736dd07cea9d  mov r14, [r15+0x98]
0000736dd07ceaa4  lea r12, [r14+rax*1]
0000736dd07ceaa8  mov eax, [r15+0x60]
0000736dd07ceaac  mov [r13+r12*1], eax
0000736dd07ceab1  mov rax, [rsp+0x10]
0000736dd07ceab6  lea r14, [rax-0x01]
0000736dd07ceaba  mov [r15+0x50], r14
0000736dd07ceabe  mov rax, [r15+0x58]
0000736dd07ceac2  test rax, rax
0000736dd07ceac5  setz al
0000736dd07ceac8  movzx rax, al
0000736dd07ceacc  mov [rsp+0x414], al
0000736dd07cead3  cmp byte ptr [rsp+0x414], 0x00
0000736dd07ceadb  jz 0x0000736DD07CEB0D
0000736dd07ceadd  cmp dword ptr [r15+0x318], 0x00
0000736dd07ceae5  jz 0x0000736DD07CEB50
0000736dd07ceaeb  nop [rax+rax*1], ax
0000736dd07ceaf4  nop [rax+rax*1], eax
0000736dd07ceafc  mov eax, 0x4101D4
0000736dd07ceb01  mov [r15+0x100], rax
0000736dd07ceb08  jmp 0x0000736DD05FE110
0000736dd07ceb0d  cmp dword ptr [r15+0x318], 0x00
0000736dd07ceb15  jz 0x0000736DD07CEC50
0000736dd07ceb1b  nop [rax+rax*1], ax
0000736dd07ceb24  nop [rax+rax*1], eax
0000736dd07ceb2c  mov eax, 0x4101B8
0000736dd07ceb31  mov [r15+0x100], rax
0000736dd07ceb38  jmp 0x0000736DD05FE110
0000736dd07ceb3d  int3
0000736dd07ceb3e  call 0x0000736DD06B4B70
0000736dd07ceb43  jmp 0x0000736DD07CEAB1
0000736dd07ceb48  int3
0000736dd07ceb49  nop [rax], eax
0000736dd07ceb50  cmp dword ptr [r15+0x318], 0x00
0000736dd07ceb58  jz 0x0000736DD07CEB90
0000736dd07ceb5e  nop [rax+rax*1], ax
0000736dd07ceb67  nop [rax+rax*1], eax
0000736dd07ceb6f  mov eax, 0x41019C
0000736dd07ceb74  mov [r15+0x100], rax
0000736dd07ceb7b  jmp 0x0000736DD05FE110
0000736dd07ceb80  int3
0000736dd07ceb81  int3
0000736dd07ceb82  nop [rax+rax*1], ax
0000736dd07ceb8b  nop [rax+rax*1], eax
0000736dd07ceb90  mov qword ptr [r15+0x50], 0x00
0000736dd07ceb98  mov rax, [r15+0x40]
0000736dd07ceb9c  lea r14, [rax+0x01]
0000736dd07ceba0  mov [r15+0x40], r14
0000736dd07ceba4  mov rax, [r15+0x98]
0000736dd07cebab  mov r12d, [r15+0x48]
0000736dd07cebaf  mov [r13+rax*1], r12d
0000736dd07cebb4  xor eax, eax
0000736dd07cebb6  mov r12d, 0x400
0000736dd07cebbc  cmp r14, r12
0000736dd07cebbf  cmc
0000736dd07cebc0  lahf
0000736dd07cebc1  seto al
0000736dd07cebc4  mov [r15+0x108], eax
0000736dd07cebcb  mov eax, [r15+0x108]
0000736dd07cebd2  sahf
0000736dd07cebd3  jz 0x0000736DD07CEC05
0000736dd07cebd5  cmp dword ptr [r15+0x318], 0x00
0000736dd07cebdd  jz 0x0000736DD07CE990
0000736dd07cebe3  nop [rax+rax*1], ax
0000736dd07cebec  nop [rax+rax*1], eax
0000736dd07cebf4  mov eax, 0x4101B0
0000736dd07cebf9  mov [r15+0x100], rax
0000736dd07cec00  jmp 0x0000736DD05FE110
0000736dd07cec05  cmp dword ptr [r15+0x318], 0x00
0000736dd07cec0d  jz 0x0000736DD07CEDF0
0000736dd07cec13  nop [rax+rax*1], ax
0000736dd07cec1c  nop [rax+rax*1], eax
0000736dd07cec24  mov eax, 0x4101D8
0000736dd07cec29  mov [r15+0x100], rax
0000736dd07cec30  jmp 0x0000736DD05FE110
0000736dd07cec35  int3
0000736dd07cec36  call 0x0000736DD060BAE0
0000736dd07cec3b  jmp 0x0000736DD07CEBB4
0000736dd07cec40  int3
0000736dd07cec41  nop [rax+rax*1], ax
0000736dd07cec4a  nop [rax+rax*1], ax
0000736dd07cec50  mov eax, [r15+0x50]
0000736dd07cec54  lea r14d, [eax-0x01]
0000736dd07cec59  mov r14d, r14d
0000736dd07cec5c  mov [r15+0x58], r14
0000736dd07cec60  mov rax, [r15+0x58]
0000736dd07cec64  mov r14d, eax
0000736dd07cec67  mov r14d, r14d
0000736dd07cec6a  shl r14, 0x02
0000736dd07cec6e  mov rax, [r15+0x98]
0000736dd07cec75  lea r12, [rax+r14*1]
0000736dd07cec79  mov eax, [r13+r12*1]
0000736dd07cec7e  mov [rsp+0x10], eax
0000736dd07cec82  mov eax, eax
0000736dd07cec84  mov [r15+0x60], rax
0000736dd07cec88  mov eax, [r15+0x48]
0000736dd07cec8c  mov [rsp+0x20], eax
0000736dd07cec90  xor eax, eax
0000736dd07cec92  mov r14d, [rsp+0x10]
0000736dd07cec97  mov r12d, [rsp+0x20]
0000736dd07cec9c  cmp r14d, r12d
0000736dd07cec9f  cmc
0000736dd07ceca0  lahf
0000736dd07ceca1  seto al
0000736dd07ceca4  mov [r15+0x108], eax
0000736dd07cecab  mov eax, [r15+0x108]
0000736dd07cecb2  sahf
0000736dd07cecb3  cmc
0000736dd07cecb4  jbe 0x0000736DD07CECE6
0000736dd07cecb6  cmp dword ptr [r15+0x318], 0x00
0000736dd07cecbe  jz 0x0000736DD07CEA90
0000736dd07cecc4  nop [rax+rax*1], ax
0000736dd07ceccd  nop [rax+rax*1], eax
0000736dd07cecd5  mov eax, 0x4101C8
0000736dd07cecda  mov [r15+0x100], rax
0000736dd07cece1  jmp 0x0000736DD05FE110
0000736dd07cece6  cmp dword ptr [r15+0x318], 0x00
0000736dd07cecee  jz 0x0000736DD07CED30
0000736dd07cecf4  nop [rax+rax*1], ax
0000736dd07cecfd  nop [rax+rax*1], eax
0000736dd07ced05  mov eax, 0x4101A0
0000736dd07ced0a  mov [r15+0x100], rax
0000736dd07ced11  jmp 0x0000736DD05FE110
0000736dd07ced16  int3
0000736dd07ced17  call 0x0000736DD06B4690
0000736dd07ced1c  jmp 0x0000736DD07CEC7E
0000736dd07ced21  int3
0000736dd07ced22  nop [rax+rax*1], ax
0000736dd07ced2b  nop [rax+rax*1], eax
0000736dd07ced30  mov rax, [r15+0x40]
0000736dd07ced34  lea r14, [rax+0x01]
0000736dd07ced38  mov [r15+0x40], r14
0000736dd07ced3c  mov rax, [r15+0x50]
0000736dd07ced40  mov r12d, eax
0000736dd07ced43  mov r12d, r12d
0000736dd07ced46  shl r12, 0x02
0000736dd07ced4a  mov rax, [r15+0x98]
0000736dd07ced51  lea r11, [rax+r12*1]
0000736dd07ced55  mov eax, [r15+0x48]
0000736dd07ced59  mov [r13+r11*1], eax
0000736dd07ced5e  xor eax, eax
0000736dd07ced60  mov r12d, 0x400
0000736dd07ced66  cmp r14, r12
0000736dd07ced69  cmc
0000736dd07ced6a  lahf
0000736dd07ced6b  seto al
0000736dd07ced6e  mov [r15+0x108], eax
0000736dd07ced75  mov eax, [r15+0x108]
0000736dd07ced7c  sahf
0000736dd07ced7d  jz 0x0000736DD07CEDAF
0000736dd07ced7f  cmp dword ptr [r15+0x318], 0x00
0000736dd07ced87  jz 0x0000736DD07CE990
0000736dd07ced8d  nop [rax+rax*1], ax
0000736dd07ced96  nop [rax+rax*1], eax
0000736dd07ced9e  mov eax, 0x4101B0
0000736dd07ceda3  mov [r15+0x100], rax
0000736dd07cedaa  jmp 0x0000736DD05FE110
0000736dd07cedaf  cmp dword ptr [r15+0x318], 0x00
0000736dd07cedb7  jz 0x0000736DD07CEDF0
0000736dd07cedbd  nop [rax+rax*1], ax
0000736dd07cedc6  nop [rax+rax*1], eax
0000736dd07cedce  mov eax, 0x4101D8
0000736dd07cedd3  mov [r15+0x100], rax
0000736dd07cedda  jmp 0x0000736DD05FE110
0000736dd07ceddf  int3
0000736dd07cede0  call 0x0000736DD06A4270
0000736dd07cede5  jmp 0x0000736DD07CED5E
0000736dd07cedea  int3
0000736dd07cedeb  nop [rax+rax*1], eax
0000736dd07cedf0  mov qword ptr [r15+0x40], 0x420000
0000736dd07cedf8  mov eax, 0x420288
0000736dd07cedfd  mov r14, [r13+rax*1]
0000736dd07cee02  mov rax, [r15+0x98]
0000736dd07cee09  mov r12d, [r13+rax*1]
0000736dd07cee0e  lea r11, [rax+0x04]
0000736dd07cee12  mov eax, [r13+r11*1]
0000736dd07cee17  mov r12d, r12d
0000736dd07cee1a  mov [r15+0x68], r12
0000736dd07cee1e  mov eax, eax
0000736dd07cee20  mov [r15+0x60], rax
0000736dd07cee24  mov rax, [r15+0x68]
0000736dd07cee28  mov [r15+0x68], rax
0000736dd07cee2c  mov qword ptr [r15+0x58], 0x02
0000736dd07cee34  mov [rsp+0x10], rax
0000736dd07cee39  xor eax, eax
0000736dd07cee3b  mov r12d, 0x02
0000736dd07cee41  mov r11d, 0x400
0000736dd07cee47  cmp r12, r11
0000736dd07cee4a  cmc
0000736dd07cee4b  lahf
0000736dd07cee4c  seto al
0000736dd07cee4f  mov [r15+0x108], eax
0000736dd07cee56  mov rax, [r15+0x60]
0000736dd07cee5a  mov r12d, 0x02
0000736dd07cee60  imul rax, r12
0000736dd07cee64  mov [r15+0x50], rax
0000736dd07cee68  mov rax, [rsp+0x10]
0000736dd07cee6d  lea r12, [rax+r14*1]
0000736dd07cee71  mov [r15+0x48], r12
0000736dd07cee75  mov eax, [r15+0x108]
0000736dd07cee7c  sahf
0000736dd07cee7d  jnz 0x0000736DD07CEEAF
0000736dd07cee7f  cmp dword ptr [r15+0x318], 0x00
0000736dd07cee87  jz 0x0000736DD07CF020
0000736dd07cee8d  nop [rax+rax*1], ax
0000736dd07cee96  nop [rax+rax*1], eax
0000736dd07cee9e  mov eax, 0x410208
0000736dd07ceea3  mov [r15+0x100], rax
0000736dd07ceeaa  jmp 0x0000736DD05FE110
0000736dd07ceeaf  cmp dword ptr [r15+0x318], 0x00
0000736dd07ceeb7  jz 0x0000736DD07CEF00
0000736dd07ceebd  nop [rax+rax*1], ax
0000736dd07ceec6  nop [rax+rax*1], eax
0000736dd07ceece  mov eax, 0x4101E8
0000736dd07ceed3  mov [r15+0x100], rax
0000736dd07ceeda  jmp 0x0000736DD05FE110
0000736dd07ceedf  int3
0000736dd07ceee0  call 0x0000736DD060DC20
0000736dd07ceee5  jmp 0x0000736DD07CEE02
0000736dd07ceeea  call 0x0000736DD060B5E0
0000736dd07ceeef  jmp 0x0000736DD07CEE0E
0000736dd07ceef4  call 0x0000736DD06A3D90
0000736dd07ceef9  jmp 0x0000736DD07CEE17
0000736dd07ceefe  int3
0000736dd07ceeff  nop
0000736dd07cef00  mov rax, [r15+0x98]
0000736dd07cef07  mov r14, [r15+0x58]
0000736dd07cef0b  mov [rsp+0x10], r14
0000736dd07cef10  shl r14, 0x02
0000736dd07cef14  lea r12, [rax+r14*1]
0000736dd07cef18  mov eax, [r13+r12*1]
0000736dd07cef1d  lea r14, [r12+0x04]
0000736dd07cef22  mov r12d, [r13+r14*1]
0000736dd07cef27  mov eax, eax
0000736dd07cef29  mov [r15+0x68], rax
0000736dd07cef2d  mov r12d, r12d
0000736dd07cef30  mov [r15+0x60], r12
0000736dd07cef34  mov rax, [r15+0x68]
0000736dd07cef38  mov [rsp+0x20], rax
0000736dd07cef3d  mov r14, [rsp+0x10]
0000736dd07cef42  imul rax, r14
0000736dd07cef46  mov r12, [rsp+0x20]
0000736dd07cef4b  lea r11, [r12+rax*1]
0000736dd07cef4f  mov [r15+0x68], r11
0000736dd07cef53  lea rax, [r14+0x02]
0000736dd07cef57  mov [r15+0x58], rax
0000736dd07cef5b  mov [rsp+0x10], rax
0000736dd07cef60  xor eax, eax
0000736dd07cef62  mov r14, [rsp+0x10]
0000736dd07cef67  mov r12d, 0x400
0000736dd07cef6d  cmp r14, r12
0000736dd07cef70  cmc
0000736dd07cef71  lahf
0000736dd07cef72  seto al
0000736dd07cef75  mov [r15+0x108], eax
0000736dd07cef7c  mov rax, [r15+0x50]
0000736dd07cef80  mov r12, [r15+0x60]
0000736dd07cef84  imul r14, r12
0000736dd07cef88  lea r12, [rax+r14*1]
0000736dd07cef8c  mov [r15+0x50], r12
0000736dd07cef90  mov rax, [r15+0x48]
0000736dd07cef94  lea r14, [r11+rax*1]
0000736dd07cef98  mov [r15+0x48], r14
0000736dd07cef9c  mov eax, [r15+0x108]
0000736dd07cefa3  sahf
0000736dd07cefa4  jnz 0x0000736DD07CEFD6
0000736dd07cefa6  cmp dword ptr [r15+0x318], 0x00
0000736dd07cefae  jz 0x0000736DD07CF020
0000736dd07cefb4  nop [rax+rax*1], ax
0000736dd07cefbd  nop [rax+rax*1], eax
0000736dd07cefc5  mov eax, 0x410208
0000736dd07cefca  mov [r15+0x100], rax
0000736dd07cefd1  jmp 0x0000736DD05FE110
0000736dd07cefd6  cmp dword ptr [r15+0x318], 0x00
0000736dd07cefde  jz 0x0000736DD07CEF00
0000736dd07cefe4  nop [rax+rax*1], ax
0000736dd07cefed  nop [rax+rax*1], eax
0000736dd07ceff5  mov eax, 0x4101E8
0000736dd07ceffa  mov [r15+0x100], rax
0000736dd07cf001  jmp 0x0000736DD05FE110
0000736dd07cf006  int3
0000736dd07cf007  call 0x0000736DD06B4690
0000736dd07cf00c  jmp 0x0000736DD07CEF1D
0000736dd07cf011  call 0x0000736DD06E26A0
0000736dd07cf016  jmp 0x0000736DD07CEF27
0000736dd07cf01b  int3
0000736dd07cf01c  nop [rax], eax
0000736dd07cf020  mov rax, [r15+0xF8]
0000736dd07cf027  lea r14, [rax+0x10]
0000736dd07cf02b  mov r12, [r13+r14*1]
0000736dd07cf030  lea r14, [rax+0x18]
0000736dd07cf034  mov r11, [r13+r14*1]
0000736dd07cf039  mov [r15+0xA0], r12
0000736dd07cf040  mov [r15+0x98], r11
0000736dd07cf047  mov r14, [r15+0x50]
0000736dd07cf04b  mov r12, [r15+0x48]
0000736dd07cf04f  lea r11, [r14+r12*1]
0000736dd07cf053  mov [r15+0x48], r11
0000736dd07cf057  mov r14, [r15+0x40]
0000736dd07cf05b  lea r12, [r14+0x288]
0000736dd07cf062  mov [r13+r12*1], r11
0000736dd07cf067  mov r14, [r13+rax*1]
0000736dd07cf06c  mov [r15+0xF0], r14
0000736dd07cf073  lea r12, [rax+0x20]
0000736dd07cf077  mov [r15+0xF8], r12
0000736dd07cf07e  mov [r15+0x100], r14
0000736dd07cf085  jmp 0x0000736DD07CE5C0
0000736dd07cf08a  int3
0000736dd07cf08b  call 0x0000736DD06E27E0
0000736dd07cf090  jmp 0x0000736DD07CF030
0000736dd07cf095  call 0x0000736DD06E1570
0000736dd07cf09a  jmp 0x0000736DD07CF039
0000736dd07cf09f  call 0x0000736DD06C0860
0000736dd07cf0a4  jmp 0x0000736DD07CF067
0000736dd07cf0a9  call 0x0000736DD060DC20
0000736dd07cf0ae  jmp 0x0000736DD07CF06C
0000736dd07cf0b3  int3
0000736dd07cf0b4  nop [rax+rax*1], ax
0000736dd07cf0bd  nop [rax], eax
0000736dd07cf0c0  mov qword ptr [r15+0x100], 0x04
0000736dd07cf0cb  mov esi, 0x00
0000736dd07cf0d0  mov edx, 0x09
0000736dd07cf0d5  mov rdi, 0x7FFCDAAE9E00
0000736dd07cf0df  mov rax, 0x63501FEC0970
0000736dd07cf0e9  call rax
0000736dd07cf0eb  cmp dword ptr [r15+0x318], 0x00
0000736dd07cf0f3  jnz 0x0000736DD05FE110
0000736dd07cf0f9  jmp 0x0000736DD05FE0A0
0000736dd07cf0fe  int3
0000736dd07cf0ff  int3
