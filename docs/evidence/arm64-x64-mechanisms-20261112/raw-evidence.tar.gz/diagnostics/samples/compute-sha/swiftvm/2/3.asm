
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/2/3.bin:     file format binary


Disassembly of section .data:

00007a2a29701660 <.data>:
    7a2a29701660:	sub    rsp,0x10
    7a2a29701664:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970166c:	mov    QWORD PTR [rsp],r11
    7a2a29701670:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a29701678:	mov    r14,r13
    7a2a2970167b:	add    r14,0x68
    7a2a2970167f:	mov    r15,QWORD PTR [r14]
    7a2a29701682:	mov    QWORD PTR [r12+0x40],r15
    7a2a29701687:	add    r13,0x88
    7a2a2970168e:	mov    r14d,0x0
    7a2a29701694:	mov    BYTE PTR [r13+0x0],r14b
    7a2a29701698:	mov    r13d,0x0
    7a2a2970169e:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a297016a6:	sub    r15,0x38
    7a2a297016aa:	pushf
    7a2a297016ab:	pop    r11
    7a2a297016ad:	mov    QWORD PTR [rsp],r11
    7a2a297016b1:	je     0x7a2a29701745
    7a2a297016b7:	jmp    0x7a2a297016bc
    7a2a297016bc:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a297016c4:	mov    r14,r13
    7a2a297016c7:	add    r14,0x0
    7a2a297016cb:	mov    QWORD PTR [r12],r14
    7a2a297016cf:	add    r13,0x88
    7a2a297016d6:	mov    QWORD PTR [r12+0x8],r13
    7a2a297016db:	mov    r13d,0x1
    7a2a297016e1:	mov    QWORD PTR [r12+0x10],r13
    7a2a297016e6:	mov    r13d,0x4102b8
    7a2a297016ec:	mov    QWORD PTR [r12+0xf0],r13
    7a2a297016f4:	mov    r13d,0x410338
    7a2a297016fa:	mov    QWORD PTR [r12+0x100],r13
    7a2a29701702:	mov    r11,QWORD PTR [rsp]
    7a2a29701706:	mov    QWORD PTR [r12+0x398],r11
    7a2a2970170e:	mov    edi,0x410338
    7a2a29701713:	mov    QWORD PTR [r12+0x100],rdi
    7a2a2970171b:	add    rsp,0x10
    7a2a2970171f:	nop
    7a2a29701720:	jmp    QWORD PTR [rip+0x2]        # 0x7a2a29701728
    7a2a29701726:	xchg   ax,ax
    7a2a29701728:	loopne 0x7a2a29701711
    7a2a2970172a:	outs   dx,DWORD PTR ds:[rsi]
    7a2a2970172b:	sub    DWORD PTR [rdx],ebp
    7a2a2970172d:	jp     0x7a2a2970172f
    7a2a2970172f:	add    BYTE PTR [rax],bh
    7a2a29701731:	(bad)
    7a2a29701732:	jo     0x7a2a2970175d
    7a2a29701734:	sub    bh,BYTE PTR [rdx+0x0]
    7a2a29701737:	add    BYTE PTR [rcx-0x45],cl
    7a2a2970173a:	movabs al,ds:0x4100006284fe3820
    7a2a29701743:	jmp    rbx
    7a2a29701745:	mov    r13,QWORD PTR [r12+0x98]
    7a2a2970174d:	ror    r13,0x3d
    7a2a29701751:	and    r13,0xfffffffffffffff8
    7a2a29701755:	mov    r14,QWORD PTR [r12+0xf8]
    7a2a2970175d:	mov    r15,r14
    7a2a29701760:	add    r15,0x0
    7a2a29701764:	mov    QWORD PTR [r12],r15
    7a2a29701768:	mov    r15,r14
    7a2a2970176b:	add    r15,0x78
    7a2a2970176f:	mov    QWORD PTR [r12+0x8],r15
    7a2a29701774:	mov    r15d,0x8
    7a2a2970177a:	mov    QWORD PTR [r12+0x10],r15
    7a2a2970177f:	movabs rcx,0xff00ff00ff00ff
    7a2a29701789:	mov    r15,r13
    7a2a2970178c:	and    r15,rcx
    7a2a2970178f:	shl    r15,0x8
    7a2a29701793:	movabs rcx,0xff00ff00ff00ff00
    7a2a2970179d:	and    r13,rcx
    7a2a297017a0:	shr    r13,0x8
    7a2a297017a4:	mov    rcx,r15
    7a2a297017a7:	or     r13,rcx
    7a2a297017aa:	movabs rcx,0xffff0000ffff
    7a2a297017b4:	mov    r15,r13
    7a2a297017b7:	and    r15,rcx
    7a2a297017ba:	shl    r15,0x10
    7a2a297017be:	movabs rcx,0xffff0000ffff0000
    7a2a297017c8:	and    r13,rcx
    7a2a297017cb:	shr    r13,0x10
    7a2a297017cf:	mov    rcx,r15
    7a2a297017d2:	or     r13,rcx
    7a2a297017d5:	mov    r15,r13
    7a2a297017d8:	shl    r15,0x20
    7a2a297017dc:	shr    r13,0x20
    7a2a297017e0:	mov    rcx,r15
    7a2a297017e3:	or     r13,rcx
    7a2a297017e6:	mov    QWORD PTR [r12+0x40],r13
    7a2a297017eb:	add    r14,0x78
    7a2a297017ef:	mov    QWORD PTR [r14],r13
    7a2a297017f2:	mov    r13d,0x0
    7a2a297017f8:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29701800:	mov    r13d,0x4102e0
    7a2a29701806:	mov    QWORD PTR [r12+0xf0],r13
    7a2a2970180e:	mov    r13d,0x410338
    7a2a29701814:	mov    QWORD PTR [r12+0x100],r13
    7a2a2970181c:	mov    r11,QWORD PTR [rsp]
    7a2a29701820:	mov    QWORD PTR [r12+0x398],r11
    7a2a29701828:	mov    edi,0x410338
    7a2a2970182d:	mov    QWORD PTR [r12+0x100],rdi
    7a2a29701835:	add    rsp,0x10
    7a2a29701839:	nop    DWORD PTR [rax+0x0]
    7a2a29701840:	jmp    QWORD PTR [rip+0x2]        # 0x7a2a29701848
    7a2a29701846:	xchg   ax,ax
    7a2a29701848:	loopne 0x7a2a29701831
    7a2a2970184a:	outs   dx,DWORD PTR ds:[rsi]
    7a2a2970184b:	sub    DWORD PTR [rdx],ebp
    7a2a2970184d:	jp     0x7a2a2970184f
    7a2a2970184f:	add    BYTE PTR [rax+0x18],bl
    7a2a29701852:	jo     0x7a2a2970187d
    7a2a29701854:	sub    bh,BYTE PTR [rdx+0x0]
    7a2a29701857:	add    BYTE PTR [rcx-0x45],cl
    7a2a2970185a:	movabs al,ds:0x4100006284fe3820
    7a2a29701863:	jmp    rbx
    7a2a29701865:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a29701870:	sub    rsp,0x10
    7a2a29701874:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970187c:	mov    QWORD PTR [rsp],r11
    7a2a29701880:	jmp    0x7a2a297016bc
    7a2a29701885:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a29701890:	sub    rsp,0x10
    7a2a29701894:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970189c:	mov    QWORD PTR [rsp],r11
    7a2a297018a0:	jmp    0x7a2a29701745
    7a2a297018a5:	nop
    7a2a297018a6:	nop
    7a2a297018a7:	nop
