
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

00007a2a296fe000 <.data>:
    7a2a296fe000:	sub    rsp,0x10
    7a2a296fe004:	mov    r11,QWORD PTR [r12+0x398]
    7a2a296fe00c:	mov    QWORD PTR [rsp],r11
    7a2a296fe010:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a296fe018:	sub    r13,0xa0
    7a2a296fe01f:	mov    QWORD PTR [r12+0xf8],r13
    7a2a296fe027:	mov    r14d,0x420000
    7a2a296fe02d:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe032:	mov    r14d,0x420000
    7a2a296fe038:	mov    QWORD PTR [r12+0x48],r14
    7a2a296fe03d:	add    r13,0x90
    7a2a296fe044:	mov    r14,r13
    7a2a296fe047:	add    r14,0x8
    7a2a296fe04b:	mov    r15,QWORD PTR [r12+0xa0]
    7a2a296fe053:	mov    rbp,QWORD PTR [r12+0x98]
    7a2a296fe05b:	mov    QWORD PTR [r13+0x0],r15
    7a2a296fe05f:	mov    r13d,0x0
    7a2a296fe065:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe06d:	mov    QWORD PTR [r14],rbp
    7a2a296fe070:	mov    r13d,0x0
    7a2a296fe076:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe07e:	mov    r13d,0x420670
    7a2a296fe084:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7a2a296fe08a:	movdqa xmm0,xmm2
    7a2a296fe08e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7a2a296fe098:	mov    r13d,0x420000
    7a2a296fe09e:	mov    QWORD PTR [r12+0x40],r13
    7a2a296fe0a3:	mov    r13d,0x420610
    7a2a296fe0a9:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7a2a296fe0af:	movdqa xmm0,xmm3
    7a2a296fe0b3:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7a2a296fe0bd:	mov    r13d,0x420000
    7a2a296fe0c3:	mov    QWORD PTR [r12+0x48],r13
    7a2a296fe0c8:	mov    r13d,0x420690
    7a2a296fe0ce:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    7a2a296fe0d4:	movdqa xmm0,xmm4
    7a2a296fe0d8:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a296fe0e2:	mov    r13d,0x420000
    7a2a296fe0e8:	mov    QWORD PTR [r12+0x40],r13
    7a2a296fe0ed:	mov    r13d,0x420630
    7a2a296fe0f3:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7a2a296fe0f9:	movdqa xmm0,xmm5
    7a2a296fe0fd:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7a2a296fe107:	mov    r13d,0x430000
    7a2a296fe10d:	add    r13,0x8a0
    7a2a296fe114:	mov    QWORD PTR [r12+0x98],r13
    7a2a296fe11c:	mov    r14,QWORD PTR [r12+0x40]
    7a2a296fe121:	add    r14,0x6a0
    7a2a296fe128:	movdqu xmm6,XMMWORD PTR [r14]
    7a2a296fe12d:	movdqa xmm0,xmm6
    7a2a296fe131:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7a2a296fe13b:	mov    r14d,0x420000
    7a2a296fe141:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe146:	mov    r14,r13
    7a2a296fe149:	add    r14,0x10
    7a2a296fe14d:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7a2a296fe153:	mov    r15d,0x0
    7a2a296fe159:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a296fe161:	movdqu XMMWORD PTR [r14],xmm3
    7a2a296fe166:	mov    r14d,0x0
    7a2a296fe16c:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe174:	mov    r14,r13
    7a2a296fe177:	add    r14,0x20
    7a2a296fe17b:	mov    r15,r14
    7a2a296fe17e:	add    r15,0x10
    7a2a296fe182:	movdqu XMMWORD PTR [r14],xmm4
    7a2a296fe187:	mov    r14d,0x0
    7a2a296fe18d:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe195:	movdqu XMMWORD PTR [r15],xmm5
    7a2a296fe19a:	mov    r14d,0x0
    7a2a296fe1a0:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe1a8:	mov    r14d,0x420600
    7a2a296fe1ae:	movdqu xmm4,XMMWORD PTR [r14]
    7a2a296fe1b3:	movdqa xmm0,xmm4
    7a2a296fe1b7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a296fe1c1:	mov    r14d,0x420000
    7a2a296fe1c7:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe1cc:	mov    r14d,0x4205f0
    7a2a296fe1d2:	movdqu xmm5,XMMWORD PTR [r14]
    7a2a296fe1d7:	movdqa xmm0,xmm5
    7a2a296fe1db:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7a2a296fe1e5:	mov    r14d,0x420000
    7a2a296fe1eb:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe1f0:	mov    r14,r13
    7a2a296fe1f3:	add    r14,0x100
    7a2a296fe1fa:	mov    r15,r14
    7a2a296fe1fd:	add    r15,0x10
    7a2a296fe201:	movdqu XMMWORD PTR [r14],xmm2
    7a2a296fe206:	mov    r14d,0x0
    7a2a296fe20c:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe214:	movdqu XMMWORD PTR [r15],xmm3
    7a2a296fe219:	mov    r14d,0x0
    7a2a296fe21f:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe227:	add    r13,0x40
    7a2a296fe22b:	mov    r14,r13
    7a2a296fe22e:	add    r14,0x10
    7a2a296fe232:	movdqu XMMWORD PTR [r13+0x0],xmm6
    7a2a296fe238:	mov    r13d,0x0
    7a2a296fe23e:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe246:	movdqu XMMWORD PTR [r14],xmm4
    7a2a296fe24b:	mov    r13d,0x0
    7a2a296fe251:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe259:	mov    r13d,0x4205e0
    7a2a296fe25f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7a2a296fe265:	movdqa xmm0,xmm2
    7a2a296fe269:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a296fe273:	mov    r13d,0x420000
    7a2a296fe279:	mov    QWORD PTR [r12+0x40],r13
    7a2a296fe27e:	mov    r13d,0x420640
    7a2a296fe284:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7a2a296fe28a:	movdqa xmm0,xmm3
    7a2a296fe28e:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7a2a296fe298:	mov    r13d,0x420000
    7a2a296fe29e:	mov    QWORD PTR [r12+0x40],r13
    7a2a296fe2a3:	mov    r13d,0xf8d3
    7a2a296fe2a9:	mov    QWORD PTR [r12+0x48],r13
    7a2a296fe2ae:	mov    r13,QWORD PTR [r12+0x98]
    7a2a296fe2b6:	mov    r14,r13
    7a2a296fe2b9:	add    r14,0x60
    7a2a296fe2bd:	mov    r15,r14
    7a2a296fe2c0:	add    r15,0x10
    7a2a296fe2c4:	movdqu XMMWORD PTR [r14],xmm5
    7a2a296fe2c9:	mov    r14d,0x0
    7a2a296fe2cf:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe2d7:	movdqu XMMWORD PTR [r15],xmm2
    7a2a296fe2dc:	mov    r14d,0x0
    7a2a296fe2e2:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe2ea:	mov    r14d,0x420650
    7a2a296fe2f0:	movdqu xmm2,XMMWORD PTR [r14]
    7a2a296fe2f5:	movdqa xmm0,xmm2
    7a2a296fe2f9:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a296fe303:	mov    r14d,0x420000
    7a2a296fe309:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe30e:	mov    r14d,0x420620
    7a2a296fe314:	movdqu xmm2,XMMWORD PTR [r14]
    7a2a296fe319:	movdqa xmm0,xmm2
    7a2a296fe31d:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7a2a296fe327:	mov    r14d,0x420000
    7a2a296fe32d:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe332:	mov    r14d,0xf8d3
    7a2a296fe338:	mov    r15d,0x421d
    7a2a296fe33e:	and    r15d,0xffff
    7a2a296fe345:	mov    rax,r14
    7a2a296fe348:	movabs rcx,0xffffffff0000ffff
    7a2a296fe352:	and    rax,rcx
    7a2a296fe355:	mov    rdx,r15
    7a2a296fe358:	shl    rdx,0x10
    7a2a296fe35c:	mov    ecx,0xffff0000
    7a2a296fe361:	and    rdx,rcx
    7a2a296fe364:	or     rax,rdx
    7a2a296fe367:	mov    ebp,eax
    7a2a296fe369:	mov    QWORD PTR [r12+0x48],rbp
    7a2a296fe36e:	mov    r14,r13
    7a2a296fe371:	add    r14,0x80
    7a2a296fe378:	mov    r15,r14
    7a2a296fe37b:	add    r15,0x10
    7a2a296fe37f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7a2a296fe389:	movdqa xmm2,xmm0
    7a2a296fe38d:	movdqu XMMWORD PTR [r14],xmm3
    7a2a296fe392:	mov    r14d,0x0
    7a2a296fe398:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe3a0:	movdqu XMMWORD PTR [r15],xmm2
    7a2a296fe3a5:	mov    r14d,0x0
    7a2a296fe3ab:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe3b3:	mov    r14d,0x4206c0
    7a2a296fe3b9:	movdqu xmm2,XMMWORD PTR [r14]
    7a2a296fe3be:	movdqa xmm0,xmm2
    7a2a296fe3c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a296fe3cc:	mov    r14d,0x420000
    7a2a296fe3d2:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe3d7:	mov    r14d,0x4206d0
    7a2a296fe3dd:	movdqu xmm3,XMMWORD PTR [r14]
    7a2a296fe3e2:	movdqa xmm0,xmm3
    7a2a296fe3e6:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7a2a296fe3f0:	mov    r14d,0x420000
    7a2a296fe3f6:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe3fb:	mov    r14d,0x3e8
    7a2a296fe401:	mov    QWORD PTR [r12+0xa0],r14
    7a2a296fe409:	add    r13,0xa0
    7a2a296fe410:	mov    r14,r13
    7a2a296fe413:	add    r14,0x10
    7a2a296fe417:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7a2a296fe421:	movdqa xmm3,xmm0
    7a2a296fe425:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7a2a296fe42b:	mov    r13d,0x0
    7a2a296fe431:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe439:	movdqu XMMWORD PTR [r14],xmm2
    7a2a296fe43e:	mov    r13d,0x0
    7a2a296fe444:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe44c:	mov    r13,QWORD PTR [r12+0x40]
    7a2a296fe451:	add    r13,0x6b0
    7a2a296fe458:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7a2a296fe45e:	movdqa xmm0,xmm2
    7a2a296fe462:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a296fe46c:	mov    r13d,0x420000
    7a2a296fe472:	mov    QWORD PTR [r12+0x40],r13
    7a2a296fe477:	mov    r13d,0x420660
    7a2a296fe47d:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7a2a296fe483:	movdqa xmm0,xmm2
    7a2a296fe487:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7a2a296fe491:	mov    r13d,0x420000
    7a2a296fe497:	mov    QWORD PTR [r12+0x40],r13
    7a2a296fe49c:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a296fe4a4:	add    r13,0x80
    7a2a296fe4ab:	mov    r14,QWORD PTR [r12+0xf0]
    7a2a296fe4b3:	mov    QWORD PTR [r13+0x0],r14
    7a2a296fe4b7:	mov    r13d,0x0
    7a2a296fe4bd:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe4c5:	mov    r13,QWORD PTR [r12+0x98]
    7a2a296fe4cd:	mov    r14,r13
    7a2a296fe4d0:	add    r14,0xc0
    7a2a296fe4d7:	mov    r15,r14
    7a2a296fe4da:	add    r15,0x10
    7a2a296fe4de:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7a2a296fe4e8:	movdqa xmm2,xmm0
    7a2a296fe4ec:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7a2a296fe4f6:	movdqa xmm3,xmm0
    7a2a296fe4fa:	movdqu XMMWORD PTR [r14],xmm2
    7a2a296fe4ff:	mov    r14d,0x0
    7a2a296fe505:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe50d:	movdqu XMMWORD PTR [r15],xmm3
    7a2a296fe512:	mov    r14d,0x0
    7a2a296fe518:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe520:	mov    r14d,0x420680
    7a2a296fe526:	movdqu xmm2,XMMWORD PTR [r14]
    7a2a296fe52b:	movdqa xmm0,xmm2
    7a2a296fe52f:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a296fe539:	mov    r14d,0x420000
    7a2a296fe53f:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe544:	mov    r14d,0x4206e0
    7a2a296fe54a:	mov    r15,QWORD PTR [r14]
    7a2a296fe54d:	mov    r14d,0x0
    7a2a296fe553:	mov    QWORD PTR [r12+0x110],r15
    7a2a296fe55b:	mov    QWORD PTR [r12+0x118],r14
    7a2a296fe563:	mov    r14d,0x4206e8
    7a2a296fe569:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe56e:	mov    r14,r13
    7a2a296fe571:	add    r14,0xe0
    7a2a296fe578:	mov    rbp,r14
    7a2a296fe57b:	add    rbp,0x10
    7a2a296fe57f:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7a2a296fe589:	movdqa xmm3,xmm0
    7a2a296fe58d:	movdqu XMMWORD PTR [r14],xmm3
    7a2a296fe592:	mov    r14d,0x0
    7a2a296fe598:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe5a0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7a2a296fe5a5:	mov    r14d,0x0
    7a2a296fe5ab:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe5b3:	mov    r14d,0x420748
    7a2a296fe5b9:	movdqu xmm2,XMMWORD PTR [r14]
    7a2a296fe5be:	movdqa xmm0,xmm2
    7a2a296fe5c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a296fe5cc:	add    r13,0x120
    7a2a296fe5d3:	mov    QWORD PTR [r13+0x0],r15
    7a2a296fe5d7:	mov    r13d,0x0
    7a2a296fe5dd:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe5e5:	mov    r13d,0x420728
    7a2a296fe5eb:	mov    r14d,0x420738
    7a2a296fe5f1:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7a2a296fe5f7:	movdqu xmm4,XMMWORD PTR [r14]
    7a2a296fe5fc:	movdqa xmm0,xmm3
    7a2a296fe600:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7a2a296fe60a:	movdqa xmm0,xmm4
    7a2a296fe60e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7a2a296fe618:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a296fe620:	mov    r14,r13
    7a2a296fe623:	add    r14,0x60
    7a2a296fe627:	movdqu XMMWORD PTR [r14],xmm2
    7a2a296fe62c:	mov    r14d,0x0
    7a2a296fe632:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe63a:	mov    r14,QWORD PTR [r12+0x98]
    7a2a296fe642:	mov    r15,r14
    7a2a296fe645:	add    r15,0x128
    7a2a296fe64c:	mov    ebp,DWORD PTR [r12+0x48]
    7a2a296fe651:	mov    DWORD PTR [r15],ebp
    7a2a296fe654:	mov    r15d,0x0
    7a2a296fe65a:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a296fe662:	mov    r15,r13
    7a2a296fe665:	add    r15,0x40
    7a2a296fe669:	mov    rbp,r15
    7a2a296fe66c:	add    rbp,0x10
    7a2a296fe670:	movdqu XMMWORD PTR [r15],xmm3
    7a2a296fe675:	mov    r15d,0x0
    7a2a296fe67b:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a296fe683:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    7a2a296fe688:	mov    r15d,0x0
    7a2a296fe68e:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a296fe696:	mov    r15d,0x4206e8
    7a2a296fe69c:	mov    ebp,0x4206f8
    7a2a296fe6a1:	movdqu xmm2,XMMWORD PTR [r15]
    7a2a296fe6a6:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7a2a296fe6ab:	movdqa xmm0,xmm2
    7a2a296fe6af:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7a2a296fe6b9:	movdqa xmm0,xmm3
    7a2a296fe6bd:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7a2a296fe6c7:	mov    r15,r13
    7a2a296fe6ca:	add    r15,0x10
    7a2a296fe6ce:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7a2a296fe6d4:	mov    ebp,0x0
    7a2a296fe6d9:	mov    DWORD PTR [r12+0x32c],ebp
    7a2a296fe6e1:	movdqu XMMWORD PTR [r15],xmm3
    7a2a296fe6e6:	mov    r15d,0x0
    7a2a296fe6ec:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a296fe6f4:	mov    r15d,0x420708
    7a2a296fe6fa:	mov    ebp,0x420718
    7a2a296fe6ff:	movdqu xmm2,XMMWORD PTR [r15]
    7a2a296fe704:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7a2a296fe709:	movdqa xmm0,xmm2
    7a2a296fe70d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7a2a296fe717:	movdqa xmm0,xmm3
    7a2a296fe71b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a296fe725:	mov    r15,r13
    7a2a296fe728:	add    r15,0x20
    7a2a296fe72c:	mov    rbp,r15
    7a2a296fe72f:	add    rbp,0x10
    7a2a296fe733:	movdqu XMMWORD PTR [r15],xmm2
    7a2a296fe738:	mov    r15d,0x0
    7a2a296fe73e:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a296fe746:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7a2a296fe74b:	mov    r15d,0x0
    7a2a296fe751:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a296fe759:	add    r13,0x0
    7a2a296fe75d:	mov    QWORD PTR [r12],r13
    7a2a296fe761:	mov    r13d,0x0
    7a2a296fe767:	mov    rcx,r14
    7a2a296fe76a:	or     r13,rcx
    7a2a296fe76d:	mov    QWORD PTR [r12+0x8],r13
    7a2a296fe772:	mov    r13d,0x12c
    7a2a296fe778:	mov    QWORD PTR [r12+0x10],r13
    7a2a296fe77d:	mov    r13d,0x410274
    7a2a296fe783:	mov    QWORD PTR [r12+0xf0],r13
    7a2a296fe78b:	mov    r13d,0x410338
    7a2a296fe791:	mov    QWORD PTR [r12+0x100],r13
    7a2a296fe799:	mov    r11,QWORD PTR [rsp]
    7a2a296fe79d:	mov    QWORD PTR [r12+0x398],r11
    7a2a296fe7a5:	mov    edi,0x410338
    7a2a296fe7aa:	mov    QWORD PTR [r12+0x100],rdi
    7a2a296fe7b2:	add    rsp,0x10
    7a2a296fe7b6:	xchg   ax,ax
    7a2a296fe7b8:	jmp    QWORD PTR [rip+0x2]        # 0x7a2a296fe7c0
    7a2a296fe7be:	xchg   ax,ax
    7a2a296fe7c0:	loopne 0x7a2a296fe7a9
    7a2a296fe7c2:	outs   dx,DWORD PTR ds:[rsi]
    7a2a296fe7c3:	sub    DWORD PTR [rdx],ebp
    7a2a296fe7c5:	jp     0x7a2a296fe7c7
    7a2a296fe7c7:	add    al,dl
    7a2a296fe7c9:	out    0x6f,eax
    7a2a296fe7cb:	sub    DWORD PTR [rdx],ebp
    7a2a296fe7cd:	jp     0x7a2a296fe7cf
    7a2a296fe7cf:	add    BYTE PTR [rcx-0x45],cl
    7a2a296fe7d2:	movabs al,ds:0x4100006284fe3820
    7a2a296fe7db:	jmp    rbx
    7a2a296fe7dd:	nop
    7a2a296fe7de:	nop
    7a2a296fe7df:	nop
