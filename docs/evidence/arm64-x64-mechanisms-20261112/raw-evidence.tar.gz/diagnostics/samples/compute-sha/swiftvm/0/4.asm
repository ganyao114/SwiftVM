
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/0/4.bin:     file format binary


Disassembly of section .data:

00007017df8008b0 <.data>:
    7017df8008b0:	sub    rsp,0x10
    7017df8008b4:	mov    r11,QWORD PTR [r12+0x398]
    7017df8008bc:	mov    QWORD PTR [rsp],r11
    7017df8008c0:	mov    r13,QWORD PTR [r12+0xf8]
    7017df8008c8:	add    r13,0x68
    7017df8008cc:	mov    r14,QWORD PTR [r13+0x0]
    7017df8008d0:	mov    QWORD PTR [r12+0x40],r14
    7017df8008d5:	sub    r14,0x38
    7017df8008d9:	mov    rcx,QWORD PTR [r12+0x380]
    7017df8008e1:	jrcxz  0x7017df8008e8
    7017df8008e3:	jmp    0x7017df80099d
    7017df8008e8:	pushf
    7017df8008e9:	pop    r11
    7017df8008eb:	mov    QWORD PTR [rsp],r11
    7017df8008ef:	jne    0x7017df80094d
    7017df8008f5:	jmp    0x7017df8008fa
    7017df8008fa:	mov    r13d,0x4102c4
    7017df800900:	mov    QWORD PTR [r12+0x100],r13
    7017df800908:	mov    r11,QWORD PTR [rsp]
    7017df80090c:	mov    QWORD PTR [r12+0x398],r11
    7017df800914:	mov    edi,0x4102c4
    7017df800919:	mov    QWORD PTR [r12+0x100],rdi
    7017df800921:	add    rsp,0x10
    7017df800925:	nop    DWORD PTR [rax]
    7017df800928:	jmp    QWORD PTR [rip+0x2]        # 0x7017df800930
    7017df80092e:	xchg   ax,ax
    7017df800930:	nop
    7017df800931:	or     BYTE PTR [rax+0x7017df],al
    7017df800937:	add    BYTE PTR [rax+0x9],al
    7017df80093a:	sbb    bh,0x17
    7017df80093d:	jo     0x7017df80093f
    7017df80093f:	add    BYTE PTR [rcx-0x45],cl
    7017df800942:	movabs al,ds:0x4100005dba7c1c00
    7017df80094b:	jmp    rbx
    7017df80094d:	mov    r13d,0x4102a8
    7017df800953:	mov    QWORD PTR [r12+0x100],r13
    7017df80095b:	mov    r11,QWORD PTR [rsp]
    7017df80095f:	mov    QWORD PTR [r12+0x398],r11
    7017df800967:	mov    edi,0x4102a8
    7017df80096c:	mov    QWORD PTR [r12+0x100],rdi
    7017df800974:	add    rsp,0x10
    7017df800978:	jmp    QWORD PTR [rip+0x2]        # 0x7017df800980
    7017df80097e:	xchg   ax,ax
    7017df800980:	jo     0x7017df80098a
    7017df800982:	sbb    bh,0x17
    7017df800985:	jo     0x7017df800987
    7017df800987:	add    BYTE PTR [rax+0x17df8009],dl
    7017df80098d:	jo     0x7017df80098f
    7017df80098f:	add    BYTE PTR [rcx-0x45],cl
    7017df800992:	movabs al,ds:0x4100005dba7c1c00
    7017df80099b:	jmp    rbx
    7017df80099d:	mov    eax,0x4102c0
    7017df8009a2:	mov    QWORD PTR [r12+0x100],rax
    7017df8009aa:	push   rdx
    7017df8009ab:	push   rsi
    7017df8009ac:	push   r10
    7017df8009ae:	push   r11
    7017df8009b0:	pushf
    7017df8009b1:	pop    r11
    7017df8009b3:	mov    QWORD PTR [rsp+0x20],r11
    7017df8009b8:	mov    rdx,QWORD PTR [rsp+0x20]
    7017df8009bd:	mov    r10d,edx
    7017df8009c0:	and    r10d,0xc0
    7017df8009c7:	shl    r10d,0x18
    7017df8009cb:	mov    r11d,edx
    7017df8009ce:	and    r11d,0x1
    7017df8009d2:	shl    r11d,0x1d
    7017df8009d6:	or     r10d,r11d
    7017df8009d9:	mov    r11d,edx
    7017df8009dc:	and    r11d,0x800
    7017df8009e3:	shl    r11d,0x11
    7017df8009e7:	or     r10d,r11d
    7017df8009ea:	btc    r10,0x1d
    7017df8009ef:	mov    r11d,0xf0000000
    7017df8009f5:	and    r11,r10
    7017df8009f8:	movabs rsi,0xffffffff0fffffff
    7017df800a02:	and    rbx,rsi
    7017df800a05:	or     rbx,r11
    7017df800a08:	pop    r11
    7017df800a0a:	pop    r10
    7017df800a0c:	pop    rsi
    7017df800a0d:	pop    rdx
    7017df800a0e:	mov    QWORD PTR [r12+0x108],rbx
    7017df800a16:	add    rsp,0x10
    7017df800a1a:	mov    eax,0xc
    7017df800a1f:	movabs r11,0x5dba7c1c0390
    7017df800a29:	jmp    r11
