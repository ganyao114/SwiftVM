
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/2/5.bin:     file format binary


Disassembly of section .data:

00007a2a29701a30 <.data>:
    7a2a29701a30:	sub    rsp,0x20
    7a2a29701a34:	mov    r11,QWORD PTR [r12+0x398]
    7a2a29701a3c:	mov    QWORD PTR [rsp+0x18],r11
    7a2a29701a41:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a29701a49:	mov    r14,r13
    7a2a29701a4c:	add    r14,0x4
    7a2a29701a50:	mov    r15d,DWORD PTR [r13+0x0]
    7a2a29701a54:	mov    ebp,DWORD PTR [r14]
    7a2a29701a57:	mov    QWORD PTR [r12+0x40],r15
    7a2a29701a5c:	mov    QWORD PTR [r12+0x50],rbp
    7a2a29701a61:	mov    r14,r13
    7a2a29701a64:	add    r14,0x8
    7a2a29701a68:	mov    r8,r14
    7a2a29701a6b:	add    r8,0x4
    7a2a29701a6f:	mov    r9d,DWORD PTR [r14]
    7a2a29701a72:	mov    r14d,DWORD PTR [r8]
    7a2a29701a75:	mov    QWORD PTR [r12+0x58],r9
    7a2a29701a7a:	mov    QWORD PTR [r12+0x60],r14
    7a2a29701a7f:	mov    r14d,0x430860
    7a2a29701a85:	mov    QWORD PTR [r12+0x48],r14
    7a2a29701a8a:	add    r13,0x80
    7a2a29701a91:	mov    r14,QWORD PTR [r13+0x0]
    7a2a29701a95:	mov    QWORD PTR [r12+0xf0],r14
    7a2a29701a9d:	movabs rcx,0xff00ff00ff00ff
    7a2a29701aa7:	mov    r13,r15
    7a2a29701aaa:	and    r13,rcx
    7a2a29701aad:	shl    r13,0x8
    7a2a29701ab1:	movabs rcx,0xff00ff00ff00ff00
    7a2a29701abb:	mov    r14,r15
    7a2a29701abe:	and    r14,rcx
    7a2a29701ac1:	shr    r14,0x8
    7a2a29701ac5:	mov    rcx,r13
    7a2a29701ac8:	or     r14,rcx
    7a2a29701acb:	movabs rcx,0xffff0000ffff
    7a2a29701ad5:	mov    r13,r14
    7a2a29701ad8:	and    r13,rcx
    7a2a29701adb:	shl    r13,0x10
    7a2a29701adf:	movabs rcx,0xffff0000ffff0000
    7a2a29701ae9:	and    r14,rcx
    7a2a29701aec:	shr    r14,0x10
    7a2a29701af0:	mov    rcx,r13
    7a2a29701af3:	or     r14,rcx
    7a2a29701af6:	mov    ecx,0xffffffff
    7a2a29701afb:	and    r14,rcx
    7a2a29701afe:	mov    QWORD PTR [r12+0x40],r14
    7a2a29701b03:	movabs rcx,0xff00ff00ff00ff
    7a2a29701b0d:	mov    r13,rbp
    7a2a29701b10:	and    r13,rcx
    7a2a29701b13:	shl    r13,0x8
    7a2a29701b17:	movabs rcx,0xff00ff00ff00ff00
    7a2a29701b21:	mov    r15,rbp
    7a2a29701b24:	and    r15,rcx
    7a2a29701b27:	shr    r15,0x8
    7a2a29701b2b:	mov    rcx,r13
    7a2a29701b2e:	or     r15,rcx
    7a2a29701b31:	movabs rcx,0xffff0000ffff
    7a2a29701b3b:	mov    r13,r15
    7a2a29701b3e:	and    r13,rcx
    7a2a29701b41:	shl    r13,0x10
    7a2a29701b45:	movabs rcx,0xffff0000ffff0000
    7a2a29701b4f:	and    r15,rcx
    7a2a29701b52:	shr    r15,0x10
    7a2a29701b56:	mov    rcx,r13
    7a2a29701b59:	or     r15,rcx
    7a2a29701b5c:	mov    ecx,0xffffffff
    7a2a29701b61:	and    r15,rcx
    7a2a29701b64:	mov    QWORD PTR [r12+0x50],r15
    7a2a29701b69:	mov    r13d,0x430860
    7a2a29701b6f:	mov    ebp,0x430864
    7a2a29701b74:	mov    rax,r14
    7a2a29701b77:	mov    eax,eax
    7a2a29701b79:	mov    r8d,eax
    7a2a29701b7c:	mov    rax,r15
    7a2a29701b7f:	mov    eax,eax
    7a2a29701b81:	mov    r14d,eax
    7a2a29701b84:	mov    DWORD PTR [r13+0x0],r8d
    7a2a29701b88:	mov    r13d,0x0
    7a2a29701b8e:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29701b96:	mov    DWORD PTR [rbp+0x0],r14d
    7a2a29701b9a:	mov    r13d,0x0
    7a2a29701ba0:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29701ba8:	mov    r13d,DWORD PTR [r12+0x58]
    7a2a29701bad:	movabs rcx,0xff00ff00ff00ff
    7a2a29701bb7:	mov    r14,r13
    7a2a29701bba:	and    r14,rcx
    7a2a29701bbd:	shl    r14,0x8
    7a2a29701bc1:	movabs rcx,0xff00ff00ff00ff00
    7a2a29701bcb:	mov    r15,r13
    7a2a29701bce:	and    r15,rcx
    7a2a29701bd1:	shr    r15,0x8
    7a2a29701bd5:	mov    rcx,r14
    7a2a29701bd8:	or     r15,rcx
    7a2a29701bdb:	movabs rcx,0xffff0000ffff
    7a2a29701be5:	mov    r13,r15
    7a2a29701be8:	and    r13,rcx
    7a2a29701beb:	shl    r13,0x10
    7a2a29701bef:	movabs rcx,0xffff0000ffff0000
    7a2a29701bf9:	and    r15,rcx
    7a2a29701bfc:	shr    r15,0x10
    7a2a29701c00:	mov    rcx,r13
    7a2a29701c03:	or     r15,rcx
    7a2a29701c06:	mov    ecx,0xffffffff
    7a2a29701c0b:	and    r15,rcx
    7a2a29701c0e:	mov    QWORD PTR [r12+0x40],r15
    7a2a29701c13:	mov    r13d,DWORD PTR [r12+0x60]
    7a2a29701c18:	movabs rcx,0xff00ff00ff00ff
    7a2a29701c22:	mov    r14,r13
    7a2a29701c25:	and    r14,rcx
    7a2a29701c28:	shl    r14,0x8
    7a2a29701c2c:	movabs rcx,0xff00ff00ff00ff00
    7a2a29701c36:	mov    rbp,r13
    7a2a29701c39:	and    rbp,rcx
    7a2a29701c3c:	shr    rbp,0x8
    7a2a29701c40:	mov    rcx,r14
    7a2a29701c43:	or     rbp,rcx
    7a2a29701c46:	movabs rcx,0xffff0000ffff
    7a2a29701c50:	mov    r13,rbp
    7a2a29701c53:	and    r13,rcx
    7a2a29701c56:	shl    r13,0x10
    7a2a29701c5a:	movabs rcx,0xffff0000ffff0000
    7a2a29701c64:	and    rbp,rcx
    7a2a29701c67:	shr    rbp,0x10
    7a2a29701c6b:	mov    rcx,r13
    7a2a29701c6e:	or     rbp,rcx
    7a2a29701c71:	mov    ecx,0xffffffff
    7a2a29701c76:	and    rbp,rcx
    7a2a29701c79:	mov    QWORD PTR [r12+0x58],rbp
    7a2a29701c7e:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a29701c86:	mov    r14,r13
    7a2a29701c89:	add    r14,0x10
    7a2a29701c8d:	mov    r8,r14
    7a2a29701c90:	add    r8,0x4
    7a2a29701c94:	mov    eax,DWORD PTR [r14]
    7a2a29701c97:	mov    QWORD PTR [rsp],rax
    7a2a29701c9b:	mov    r14d,DWORD PTR [r8]
    7a2a29701c9e:	mov    rax,QWORD PTR [rsp]
    7a2a29701ca2:	mov    QWORD PTR [r12+0x50],rax
    7a2a29701ca7:	mov    QWORD PTR [r12+0x60],r14
    7a2a29701cac:	mov    r14,QWORD PTR [r12+0x48]
    7a2a29701cb1:	add    r14,0x8
    7a2a29701cb5:	mov    r8,r14
    7a2a29701cb8:	add    r8,0x4
    7a2a29701cbc:	mov    rax,r15
    7a2a29701cbf:	mov    eax,eax
    7a2a29701cc1:	mov    r9d,eax
    7a2a29701cc4:	mov    rax,rbp
    7a2a29701cc7:	mov    eax,eax
    7a2a29701cc9:	mov    r15d,eax
    7a2a29701ccc:	mov    DWORD PTR [r14],r9d
    7a2a29701ccf:	mov    r14d,0x0
    7a2a29701cd5:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a29701cdd:	mov    DWORD PTR [r8],r15d
    7a2a29701ce0:	mov    r14d,0x0
    7a2a29701ce6:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a29701cee:	add    r13,0x90
    7a2a29701cf5:	mov    r14,r13
    7a2a29701cf8:	add    r14,0x8
    7a2a29701cfc:	mov    r15,QWORD PTR [r13+0x0]
    7a2a29701d00:	mov    r13,QWORD PTR [r14]
    7a2a29701d03:	mov    QWORD PTR [r12+0xa0],r15
    7a2a29701d0b:	mov    QWORD PTR [r12+0x98],r13
    7a2a29701d13:	movabs rcx,0xff00ff00ff00ff
    7a2a29701d1d:	mov    r13,QWORD PTR [rsp]
    7a2a29701d21:	and    r13,rcx
    7a2a29701d24:	shl    r13,0x8
    7a2a29701d28:	movabs rcx,0xff00ff00ff00ff00
    7a2a29701d32:	mov    r14,QWORD PTR [rsp]
    7a2a29701d36:	and    r14,rcx
    7a2a29701d39:	shr    r14,0x8
    7a2a29701d3d:	mov    rcx,r13
    7a2a29701d40:	or     r14,rcx
    7a2a29701d43:	movabs rcx,0xffff0000ffff
    7a2a29701d4d:	mov    r13,r14
    7a2a29701d50:	and    r13,rcx
    7a2a29701d53:	shl    r13,0x10
    7a2a29701d57:	movabs rcx,0xffff0000ffff0000
    7a2a29701d61:	and    r14,rcx
    7a2a29701d64:	shr    r14,0x10
    7a2a29701d68:	mov    rcx,r13
    7a2a29701d6b:	or     r14,rcx
    7a2a29701d6e:	mov    ecx,0xffffffff
    7a2a29701d73:	and    r14,rcx
    7a2a29701d76:	mov    QWORD PTR [r12+0x40],r14
    7a2a29701d7b:	mov    r13d,DWORD PTR [r12+0x60]
    7a2a29701d80:	movabs rcx,0xff00ff00ff00ff
    7a2a29701d8a:	mov    r15,r13
    7a2a29701d8d:	and    r15,rcx
    7a2a29701d90:	shl    r15,0x8
    7a2a29701d94:	movabs rcx,0xff00ff00ff00ff00
    7a2a29701d9e:	mov    rbp,r13
    7a2a29701da1:	and    rbp,rcx
    7a2a29701da4:	shr    rbp,0x8
    7a2a29701da8:	mov    rcx,r15
    7a2a29701dab:	or     rbp,rcx
    7a2a29701dae:	movabs rcx,0xffff0000ffff
    7a2a29701db8:	mov    r13,rbp
    7a2a29701dbb:	and    r13,rcx
    7a2a29701dbe:	shl    r13,0x10
    7a2a29701dc2:	movabs rcx,0xffff0000ffff0000
    7a2a29701dcc:	and    rbp,rcx
    7a2a29701dcf:	shr    rbp,0x10
    7a2a29701dd3:	mov    rcx,r13
    7a2a29701dd6:	or     rbp,rcx
    7a2a29701dd9:	mov    ecx,0xffffffff
    7a2a29701dde:	and    rbp,rcx
    7a2a29701de1:	mov    QWORD PTR [r12+0x58],rbp
    7a2a29701de6:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a29701dee:	add    r13,0x18
    7a2a29701df2:	mov    r15,r13
    7a2a29701df5:	add    r15,0x4
    7a2a29701df9:	mov    r8d,DWORD PTR [r13+0x0]
    7a2a29701dfd:	mov    eax,DWORD PTR [r15]
    7a2a29701e00:	mov    QWORD PTR [rsp+0x10],rax
    7a2a29701e05:	mov    QWORD PTR [r12+0x50],r8
    7a2a29701e0a:	mov    rax,QWORD PTR [rsp+0x10]
    7a2a29701e0f:	mov    QWORD PTR [r12+0x60],rax
    7a2a29701e14:	mov    rax,QWORD PTR [r12+0x48]
    7a2a29701e19:	mov    QWORD PTR [rsp+0x8],rax
    7a2a29701e1e:	mov    r9,QWORD PTR [rsp+0x8]
    7a2a29701e23:	add    r9,0x10
    7a2a29701e27:	mov    r15,r9
    7a2a29701e2a:	add    r15,0x4
    7a2a29701e2e:	mov    rax,r14
    7a2a29701e31:	mov    eax,eax
    7a2a29701e33:	mov    r13d,eax
    7a2a29701e36:	mov    rax,rbp
    7a2a29701e39:	mov    eax,eax
    7a2a29701e3b:	mov    r14d,eax
    7a2a29701e3e:	mov    DWORD PTR [r9],r13d
    7a2a29701e41:	mov    r13d,0x0
    7a2a29701e47:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29701e4f:	mov    DWORD PTR [r15],r14d
    7a2a29701e52:	mov    r13d,0x0
    7a2a29701e58:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29701e60:	movabs rcx,0xff00ff00ff00ff
    7a2a29701e6a:	mov    r13,r8
    7a2a29701e6d:	and    r13,rcx
    7a2a29701e70:	shl    r13,0x8
    7a2a29701e74:	movabs rcx,0xff00ff00ff00ff00
    7a2a29701e7e:	mov    r14,r8
    7a2a29701e81:	and    r14,rcx
    7a2a29701e84:	shr    r14,0x8
    7a2a29701e88:	mov    rcx,r13
    7a2a29701e8b:	or     r14,rcx
    7a2a29701e8e:	movabs rcx,0xffff0000ffff
    7a2a29701e98:	mov    r13,r14
    7a2a29701e9b:	and    r13,rcx
    7a2a29701e9e:	shl    r13,0x10
    7a2a29701ea2:	movabs rcx,0xffff0000ffff0000
    7a2a29701eac:	and    r14,rcx
    7a2a29701eaf:	shr    r14,0x10
    7a2a29701eb3:	mov    rcx,r13
    7a2a29701eb6:	or     r14,rcx
    7a2a29701eb9:	mov    ecx,0xffffffff
    7a2a29701ebe:	and    r14,rcx
    7a2a29701ec1:	mov    QWORD PTR [r12+0x40],r14
    7a2a29701ec6:	movabs rcx,0xff00ff00ff00ff
    7a2a29701ed0:	mov    r13,QWORD PTR [rsp+0x10]
    7a2a29701ed5:	and    r13,rcx
    7a2a29701ed8:	shl    r13,0x8
    7a2a29701edc:	movabs rcx,0xff00ff00ff00ff00
    7a2a29701ee6:	mov    r15,QWORD PTR [rsp+0x10]
    7a2a29701eeb:	and    r15,rcx
    7a2a29701eee:	shr    r15,0x8
    7a2a29701ef2:	mov    rcx,r13
    7a2a29701ef5:	or     r15,rcx
    7a2a29701ef8:	movabs rcx,0xffff0000ffff
    7a2a29701f02:	mov    r13,r15
    7a2a29701f05:	and    r13,rcx
    7a2a29701f08:	shl    r13,0x10
    7a2a29701f0c:	movabs rcx,0xffff0000ffff0000
    7a2a29701f16:	and    r15,rcx
    7a2a29701f19:	shr    r15,0x10
    7a2a29701f1d:	mov    rcx,r13
    7a2a29701f20:	or     r15,rcx
    7a2a29701f23:	mov    ecx,0xffffffff
    7a2a29701f28:	and    r15,rcx
    7a2a29701f2b:	mov    QWORD PTR [r12+0x50],r15
    7a2a29701f30:	mov    r13,QWORD PTR [rsp+0x8]
    7a2a29701f35:	add    r13,0x18
    7a2a29701f39:	mov    rbp,r13
    7a2a29701f3c:	add    rbp,0x4
    7a2a29701f40:	mov    rax,r14
    7a2a29701f43:	mov    eax,eax
    7a2a29701f45:	mov    r8d,eax
    7a2a29701f48:	mov    rax,r15
    7a2a29701f4b:	mov    eax,eax
    7a2a29701f4d:	mov    r14d,eax
    7a2a29701f50:	mov    DWORD PTR [r13+0x0],r8d
    7a2a29701f54:	mov    r13d,0x0
    7a2a29701f5a:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29701f62:	mov    DWORD PTR [rbp+0x0],r14d
    7a2a29701f66:	mov    r13d,0x0
    7a2a29701f6c:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29701f74:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a29701f7c:	add    r13,0xa0
    7a2a29701f83:	mov    QWORD PTR [r12+0xf8],r13
    7a2a29701f8b:	mov    rcx,QWORD PTR [r12+0x380]
    7a2a29701f93:	jrcxz  0x7a2a29701f9a
    7a2a29701f95:	jmp    0x7a2a29701fd0
    7a2a29701f9a:	mov    r13,QWORD PTR [r12+0xf0]
    7a2a29701fa2:	mov    QWORD PTR [r12+0x100],r13
    7a2a29701faa:	mov    r11,QWORD PTR [rsp+0x18]
    7a2a29701faf:	mov    QWORD PTR [r12+0x398],r11
    7a2a29701fb7:	mov    rdi,QWORD PTR [r12+0x100]
    7a2a29701fbf:	add    rsp,0x20
    7a2a29701fc3:	movabs r11,0x6284fe3820a0
    7a2a29701fcd:	jmp    r11
    7a2a29701fd0:	mov    eax,0x410334
    7a2a29701fd5:	mov    QWORD PTR [r12+0x100],rax
    7a2a29701fdd:	push   rdx
    7a2a29701fde:	push   rsi
    7a2a29701fdf:	push   r10
    7a2a29701fe1:	push   r11
    7a2a29701fe3:	mov    rdx,QWORD PTR [rsp+0x38]
    7a2a29701fe8:	mov    r10d,edx
    7a2a29701feb:	and    r10d,0xc0
    7a2a29701ff2:	shl    r10d,0x18
    7a2a29701ff6:	mov    r11d,edx
    7a2a29701ff9:	and    r11d,0x1
    7a2a29701ffd:	shl    r11d,0x1d
    7a2a29702001:	or     r10d,r11d
    7a2a29702004:	mov    r11d,edx
    7a2a29702007:	and    r11d,0x800
    7a2a2970200e:	shl    r11d,0x11
    7a2a29702012:	or     r10d,r11d
    7a2a29702015:	btc    r10,0x1d
    7a2a2970201a:	mov    r11d,0xf0000000
    7a2a29702020:	and    r11,r10
    7a2a29702023:	movabs rsi,0xffffffff0fffffff
    7a2a2970202d:	and    rbx,rsi
    7a2a29702030:	or     rbx,r11
    7a2a29702033:	pop    r11
    7a2a29702035:	pop    r10
    7a2a29702037:	pop    rsi
    7a2a29702038:	pop    rdx
    7a2a29702039:	mov    QWORD PTR [r12+0x108],rbx
    7a2a29702041:	add    rsp,0x20
    7a2a29702045:	mov    eax,0xc
    7a2a2970204a:	movabs r11,0x6284fe382390
    7a2a29702054:	jmp    r11
    7a2a29702057:	nop
