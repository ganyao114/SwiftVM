
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

00007c6369ffd000 <.data>:
    7c6369ffd000:	sub    rsp,0x10
    7c6369ffd004:	mov    r11,QWORD PTR [r12+0x398]
    7c6369ffd00c:	mov    QWORD PTR [rsp],r11
    7c6369ffd010:	mov    r13,QWORD PTR [r12+0xf8]
    7c6369ffd018:	sub    r13,0xa0
    7c6369ffd01f:	mov    QWORD PTR [r12+0xf8],r13
    7c6369ffd027:	mov    r14d,0x420000
    7c6369ffd02d:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd032:	mov    r14d,0x420000
    7c6369ffd038:	mov    QWORD PTR [r12+0x48],r14
    7c6369ffd03d:	add    r13,0x90
    7c6369ffd044:	mov    r14,r13
    7c6369ffd047:	add    r14,0x8
    7c6369ffd04b:	mov    r15,QWORD PTR [r12+0xa0]
    7c6369ffd053:	mov    rbp,QWORD PTR [r12+0x98]
    7c6369ffd05b:	mov    QWORD PTR [r13+0x0],r15
    7c6369ffd05f:	mov    r13d,0x0
    7c6369ffd065:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd06d:	mov    QWORD PTR [r14],rbp
    7c6369ffd070:	mov    r13d,0x0
    7c6369ffd076:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd07e:	mov    r13d,0x420670
    7c6369ffd084:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c6369ffd08a:	movdqa xmm0,xmm2
    7c6369ffd08e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c6369ffd098:	mov    r13d,0x420000
    7c6369ffd09e:	mov    QWORD PTR [r12+0x40],r13
    7c6369ffd0a3:	mov    r13d,0x420610
    7c6369ffd0a9:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c6369ffd0af:	movdqa xmm0,xmm3
    7c6369ffd0b3:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c6369ffd0bd:	mov    r13d,0x420000
    7c6369ffd0c3:	mov    QWORD PTR [r12+0x48],r13
    7c6369ffd0c8:	mov    r13d,0x420690
    7c6369ffd0ce:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    7c6369ffd0d4:	movdqa xmm0,xmm4
    7c6369ffd0d8:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369ffd0e2:	mov    r13d,0x420000
    7c6369ffd0e8:	mov    QWORD PTR [r12+0x40],r13
    7c6369ffd0ed:	mov    r13d,0x420630
    7c6369ffd0f3:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7c6369ffd0f9:	movdqa xmm0,xmm5
    7c6369ffd0fd:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c6369ffd107:	mov    r13d,0x430000
    7c6369ffd10d:	add    r13,0x8a0
    7c6369ffd114:	mov    QWORD PTR [r12+0x98],r13
    7c6369ffd11c:	mov    r14,QWORD PTR [r12+0x40]
    7c6369ffd121:	add    r14,0x6a0
    7c6369ffd128:	movdqu xmm6,XMMWORD PTR [r14]
    7c6369ffd12d:	movdqa xmm0,xmm6
    7c6369ffd131:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c6369ffd13b:	mov    r14d,0x420000
    7c6369ffd141:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd146:	mov    r14,r13
    7c6369ffd149:	add    r14,0x10
    7c6369ffd14d:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c6369ffd153:	mov    r15d,0x0
    7c6369ffd159:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369ffd161:	movdqu XMMWORD PTR [r14],xmm3
    7c6369ffd166:	mov    r14d,0x0
    7c6369ffd16c:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd174:	mov    r14,r13
    7c6369ffd177:	add    r14,0x20
    7c6369ffd17b:	mov    r15,r14
    7c6369ffd17e:	add    r15,0x10
    7c6369ffd182:	movdqu XMMWORD PTR [r14],xmm4
    7c6369ffd187:	mov    r14d,0x0
    7c6369ffd18d:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd195:	movdqu XMMWORD PTR [r15],xmm5
    7c6369ffd19a:	mov    r14d,0x0
    7c6369ffd1a0:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd1a8:	mov    r14d,0x420600
    7c6369ffd1ae:	movdqu xmm4,XMMWORD PTR [r14]
    7c6369ffd1b3:	movdqa xmm0,xmm4
    7c6369ffd1b7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369ffd1c1:	mov    r14d,0x420000
    7c6369ffd1c7:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd1cc:	mov    r14d,0x4205f0
    7c6369ffd1d2:	movdqu xmm5,XMMWORD PTR [r14]
    7c6369ffd1d7:	movdqa xmm0,xmm5
    7c6369ffd1db:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c6369ffd1e5:	mov    r14d,0x420000
    7c6369ffd1eb:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd1f0:	mov    r14,r13
    7c6369ffd1f3:	add    r14,0x100
    7c6369ffd1fa:	mov    r15,r14
    7c6369ffd1fd:	add    r15,0x10
    7c6369ffd201:	movdqu XMMWORD PTR [r14],xmm2
    7c6369ffd206:	mov    r14d,0x0
    7c6369ffd20c:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd214:	movdqu XMMWORD PTR [r15],xmm3
    7c6369ffd219:	mov    r14d,0x0
    7c6369ffd21f:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd227:	add    r13,0x40
    7c6369ffd22b:	mov    r14,r13
    7c6369ffd22e:	add    r14,0x10
    7c6369ffd232:	movdqu XMMWORD PTR [r13+0x0],xmm6
    7c6369ffd238:	mov    r13d,0x0
    7c6369ffd23e:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd246:	movdqu XMMWORD PTR [r14],xmm4
    7c6369ffd24b:	mov    r13d,0x0
    7c6369ffd251:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd259:	mov    r13d,0x4205e0
    7c6369ffd25f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c6369ffd265:	movdqa xmm0,xmm2
    7c6369ffd269:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369ffd273:	mov    r13d,0x420000
    7c6369ffd279:	mov    QWORD PTR [r12+0x40],r13
    7c6369ffd27e:	mov    r13d,0x420640
    7c6369ffd284:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c6369ffd28a:	movdqa xmm0,xmm3
    7c6369ffd28e:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c6369ffd298:	mov    r13d,0x420000
    7c6369ffd29e:	mov    QWORD PTR [r12+0x40],r13
    7c6369ffd2a3:	mov    r13d,0xf8d3
    7c6369ffd2a9:	mov    QWORD PTR [r12+0x48],r13
    7c6369ffd2ae:	mov    r13,QWORD PTR [r12+0x98]
    7c6369ffd2b6:	mov    r14,r13
    7c6369ffd2b9:	add    r14,0x60
    7c6369ffd2bd:	mov    r15,r14
    7c6369ffd2c0:	add    r15,0x10
    7c6369ffd2c4:	movdqu XMMWORD PTR [r14],xmm5
    7c6369ffd2c9:	mov    r14d,0x0
    7c6369ffd2cf:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd2d7:	movdqu XMMWORD PTR [r15],xmm2
    7c6369ffd2dc:	mov    r14d,0x0
    7c6369ffd2e2:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd2ea:	mov    r14d,0x420650
    7c6369ffd2f0:	movdqu xmm2,XMMWORD PTR [r14]
    7c6369ffd2f5:	movdqa xmm0,xmm2
    7c6369ffd2f9:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369ffd303:	mov    r14d,0x420000
    7c6369ffd309:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd30e:	mov    r14d,0x420620
    7c6369ffd314:	movdqu xmm2,XMMWORD PTR [r14]
    7c6369ffd319:	movdqa xmm0,xmm2
    7c6369ffd31d:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c6369ffd327:	mov    r14d,0x420000
    7c6369ffd32d:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd332:	mov    r14d,0xf8d3
    7c6369ffd338:	mov    r15d,0x421d
    7c6369ffd33e:	and    r15d,0xffff
    7c6369ffd345:	mov    rax,r14
    7c6369ffd348:	movabs rcx,0xffffffff0000ffff
    7c6369ffd352:	and    rax,rcx
    7c6369ffd355:	mov    rdx,r15
    7c6369ffd358:	shl    rdx,0x10
    7c6369ffd35c:	mov    ecx,0xffff0000
    7c6369ffd361:	and    rdx,rcx
    7c6369ffd364:	or     rax,rdx
    7c6369ffd367:	mov    ebp,eax
    7c6369ffd369:	mov    QWORD PTR [r12+0x48],rbp
    7c6369ffd36e:	mov    r14,r13
    7c6369ffd371:	add    r14,0x80
    7c6369ffd378:	mov    r15,r14
    7c6369ffd37b:	add    r15,0x10
    7c6369ffd37f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c6369ffd389:	movdqa xmm2,xmm0
    7c6369ffd38d:	movdqu XMMWORD PTR [r14],xmm3
    7c6369ffd392:	mov    r14d,0x0
    7c6369ffd398:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd3a0:	movdqu XMMWORD PTR [r15],xmm2
    7c6369ffd3a5:	mov    r14d,0x0
    7c6369ffd3ab:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd3b3:	mov    r14d,0x4206c0
    7c6369ffd3b9:	movdqu xmm2,XMMWORD PTR [r14]
    7c6369ffd3be:	movdqa xmm0,xmm2
    7c6369ffd3c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369ffd3cc:	mov    r14d,0x420000
    7c6369ffd3d2:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd3d7:	mov    r14d,0x4206d0
    7c6369ffd3dd:	movdqu xmm3,XMMWORD PTR [r14]
    7c6369ffd3e2:	movdqa xmm0,xmm3
    7c6369ffd3e6:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c6369ffd3f0:	mov    r14d,0x420000
    7c6369ffd3f6:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd3fb:	mov    r14d,0x3e8
    7c6369ffd401:	mov    QWORD PTR [r12+0xa0],r14
    7c6369ffd409:	add    r13,0xa0
    7c6369ffd410:	mov    r14,r13
    7c6369ffd413:	add    r14,0x10
    7c6369ffd417:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c6369ffd421:	movdqa xmm3,xmm0
    7c6369ffd425:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7c6369ffd42b:	mov    r13d,0x0
    7c6369ffd431:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd439:	movdqu XMMWORD PTR [r14],xmm2
    7c6369ffd43e:	mov    r13d,0x0
    7c6369ffd444:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd44c:	mov    r13,QWORD PTR [r12+0x40]
    7c6369ffd451:	add    r13,0x6b0
    7c6369ffd458:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c6369ffd45e:	movdqa xmm0,xmm2
    7c6369ffd462:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369ffd46c:	mov    r13d,0x420000
    7c6369ffd472:	mov    QWORD PTR [r12+0x40],r13
    7c6369ffd477:	mov    r13d,0x420660
    7c6369ffd47d:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c6369ffd483:	movdqa xmm0,xmm2
    7c6369ffd487:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c6369ffd491:	mov    r13d,0x420000
    7c6369ffd497:	mov    QWORD PTR [r12+0x40],r13
    7c6369ffd49c:	mov    r13,QWORD PTR [r12+0xf8]
    7c6369ffd4a4:	add    r13,0x80
    7c6369ffd4ab:	mov    r14,QWORD PTR [r12+0xf0]
    7c6369ffd4b3:	mov    QWORD PTR [r13+0x0],r14
    7c6369ffd4b7:	mov    r13d,0x0
    7c6369ffd4bd:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd4c5:	mov    r13,QWORD PTR [r12+0x98]
    7c6369ffd4cd:	mov    r14,r13
    7c6369ffd4d0:	add    r14,0xc0
    7c6369ffd4d7:	mov    r15,r14
    7c6369ffd4da:	add    r15,0x10
    7c6369ffd4de:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c6369ffd4e8:	movdqa xmm2,xmm0
    7c6369ffd4ec:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c6369ffd4f6:	movdqa xmm3,xmm0
    7c6369ffd4fa:	movdqu XMMWORD PTR [r14],xmm2
    7c6369ffd4ff:	mov    r14d,0x0
    7c6369ffd505:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd50d:	movdqu XMMWORD PTR [r15],xmm3
    7c6369ffd512:	mov    r14d,0x0
    7c6369ffd518:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd520:	mov    r14d,0x420680
    7c6369ffd526:	movdqu xmm2,XMMWORD PTR [r14]
    7c6369ffd52b:	movdqa xmm0,xmm2
    7c6369ffd52f:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369ffd539:	mov    r14d,0x420000
    7c6369ffd53f:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd544:	mov    r14d,0x4206e0
    7c6369ffd54a:	mov    r15,QWORD PTR [r14]
    7c6369ffd54d:	mov    r14d,0x0
    7c6369ffd553:	mov    QWORD PTR [r12+0x110],r15
    7c6369ffd55b:	mov    QWORD PTR [r12+0x118],r14
    7c6369ffd563:	mov    r14d,0x4206e8
    7c6369ffd569:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd56e:	mov    r14,r13
    7c6369ffd571:	add    r14,0xe0
    7c6369ffd578:	mov    rbp,r14
    7c6369ffd57b:	add    rbp,0x10
    7c6369ffd57f:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c6369ffd589:	movdqa xmm3,xmm0
    7c6369ffd58d:	movdqu XMMWORD PTR [r14],xmm3
    7c6369ffd592:	mov    r14d,0x0
    7c6369ffd598:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd5a0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c6369ffd5a5:	mov    r14d,0x0
    7c6369ffd5ab:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd5b3:	mov    r14d,0x420748
    7c6369ffd5b9:	movdqu xmm2,XMMWORD PTR [r14]
    7c6369ffd5be:	movdqa xmm0,xmm2
    7c6369ffd5c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369ffd5cc:	add    r13,0x120
    7c6369ffd5d3:	mov    QWORD PTR [r13+0x0],r15
    7c6369ffd5d7:	mov    r13d,0x0
    7c6369ffd5dd:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd5e5:	mov    r13d,0x420728
    7c6369ffd5eb:	mov    r14d,0x420738
    7c6369ffd5f1:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c6369ffd5f7:	movdqu xmm4,XMMWORD PTR [r14]
    7c6369ffd5fc:	movdqa xmm0,xmm3
    7c6369ffd600:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c6369ffd60a:	movdqa xmm0,xmm4
    7c6369ffd60e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c6369ffd618:	mov    r13,QWORD PTR [r12+0xf8]
    7c6369ffd620:	mov    r14,r13
    7c6369ffd623:	add    r14,0x60
    7c6369ffd627:	movdqu XMMWORD PTR [r14],xmm2
    7c6369ffd62c:	mov    r14d,0x0
    7c6369ffd632:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd63a:	mov    r14,QWORD PTR [r12+0x98]
    7c6369ffd642:	mov    r15,r14
    7c6369ffd645:	add    r15,0x128
    7c6369ffd64c:	mov    ebp,DWORD PTR [r12+0x48]
    7c6369ffd651:	mov    DWORD PTR [r15],ebp
    7c6369ffd654:	mov    r15d,0x0
    7c6369ffd65a:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369ffd662:	mov    r15,r13
    7c6369ffd665:	add    r15,0x40
    7c6369ffd669:	mov    rbp,r15
    7c6369ffd66c:	add    rbp,0x10
    7c6369ffd670:	movdqu XMMWORD PTR [r15],xmm3
    7c6369ffd675:	mov    r15d,0x0
    7c6369ffd67b:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369ffd683:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    7c6369ffd688:	mov    r15d,0x0
    7c6369ffd68e:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369ffd696:	mov    r15d,0x4206e8
    7c6369ffd69c:	mov    ebp,0x4206f8
    7c6369ffd6a1:	movdqu xmm2,XMMWORD PTR [r15]
    7c6369ffd6a6:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c6369ffd6ab:	movdqa xmm0,xmm2
    7c6369ffd6af:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c6369ffd6b9:	movdqa xmm0,xmm3
    7c6369ffd6bd:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c6369ffd6c7:	mov    r15,r13
    7c6369ffd6ca:	add    r15,0x10
    7c6369ffd6ce:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c6369ffd6d4:	mov    ebp,0x0
    7c6369ffd6d9:	mov    DWORD PTR [r12+0x32c],ebp
    7c6369ffd6e1:	movdqu XMMWORD PTR [r15],xmm3
    7c6369ffd6e6:	mov    r15d,0x0
    7c6369ffd6ec:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369ffd6f4:	mov    r15d,0x420708
    7c6369ffd6fa:	mov    ebp,0x420718
    7c6369ffd6ff:	movdqu xmm2,XMMWORD PTR [r15]
    7c6369ffd704:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c6369ffd709:	movdqa xmm0,xmm2
    7c6369ffd70d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c6369ffd717:	movdqa xmm0,xmm3
    7c6369ffd71b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369ffd725:	mov    r15,r13
    7c6369ffd728:	add    r15,0x20
    7c6369ffd72c:	mov    rbp,r15
    7c6369ffd72f:	add    rbp,0x10
    7c6369ffd733:	movdqu XMMWORD PTR [r15],xmm2
    7c6369ffd738:	mov    r15d,0x0
    7c6369ffd73e:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369ffd746:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7c6369ffd74b:	mov    r15d,0x0
    7c6369ffd751:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369ffd759:	add    r13,0x0
    7c6369ffd75d:	mov    QWORD PTR [r12],r13
    7c6369ffd761:	mov    r13d,0x0
    7c6369ffd767:	mov    rcx,r14
    7c6369ffd76a:	or     r13,rcx
    7c6369ffd76d:	mov    QWORD PTR [r12+0x8],r13
    7c6369ffd772:	mov    r13d,0x12c
    7c6369ffd778:	mov    QWORD PTR [r12+0x10],r13
    7c6369ffd77d:	mov    r13d,0x410274
    7c6369ffd783:	mov    QWORD PTR [r12+0xf0],r13
    7c6369ffd78b:	mov    r13d,0x410338
    7c6369ffd791:	mov    QWORD PTR [r12+0x100],r13
    7c6369ffd799:	mov    r11,QWORD PTR [rsp]
    7c6369ffd79d:	mov    QWORD PTR [r12+0x398],r11
    7c6369ffd7a5:	mov    edi,0x410338
    7c6369ffd7aa:	mov    QWORD PTR [r12+0x100],rdi
    7c6369ffd7b2:	add    rsp,0x10
    7c6369ffd7b6:	xchg   ax,ax
    7c6369ffd7b8:	jmp    QWORD PTR [rip+0x2]        # 0x7c6369ffd7c0
    7c6369ffd7be:	xchg   ax,ax
    7c6369ffd7c0:	loopne 0x7c6369ffd799
    7c6369ffd7c2:	jmp    FWORD PTR [rcx+0x63]
    7c6369ffd7c5:	jl     0x7c6369ffd7c7
    7c6369ffd7c7:	add    al,dl
    7c6369ffd7c9:	xlat   BYTE PTR ds:[rbx]
    7c6369ffd7ca:	jmp    FWORD PTR [rcx+0x63]
    7c6369ffd7cd:	jl     0x7c6369ffd7cf
    7c6369ffd7cf:	add    BYTE PTR [rcx-0x45],cl
    7c6369ffd7d2:	movabs al,ds:0x41000059733cd1d0
    7c6369ffd7db:	jmp    rbx
    7c6369ffd7dd:	nop
    7c6369ffd7de:	nop
    7c6369ffd7df:	nop
