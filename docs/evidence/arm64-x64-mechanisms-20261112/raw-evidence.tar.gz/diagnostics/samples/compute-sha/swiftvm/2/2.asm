
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/2/2.bin:     file format binary


Disassembly of section .data:

00007a2a297013f0 <.data>:
    7a2a297013f0:	sub    rsp,0x10
    7a2a297013f4:	mov    r13d,DWORD PTR [r12+0xa0]
    7a2a297013fc:	sub    r13d,0x1
    7a2a29701400:	mov    QWORD PTR [r12+0xa0],r13
    7a2a29701408:	mov    rcx,QWORD PTR [r12+0x380]
    7a2a29701410:	jrcxz  0x7a2a29701417
    7a2a29701412:	jmp    0x7a2a2970158d
    7a2a29701417:	pushf
    7a2a29701418:	pop    r11
    7a2a2970141a:	mov    QWORD PTR [rsp],r11
    7a2a2970141e:	jne    0x7a2a297014f5
    7a2a29701424:	jmp    0x7a2a29701429
    7a2a29701429:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a29701431:	mov    r14,r13
    7a2a29701434:	add    r14,0x20
    7a2a29701438:	mov    r15,QWORD PTR [r14]
    7a2a2970143b:	mov    QWORD PTR [r12+0x98],r15
    7a2a29701443:	mov    r14d,0x80
    7a2a29701449:	mov    QWORD PTR [r12+0x40],r14
    7a2a2970144e:	mov    r14,r13
    7a2a29701451:	add    r14,0x0
    7a2a29701455:	mov    QWORD PTR [r12],r14
    7a2a29701459:	mov    r14,r13
    7a2a2970145c:	add    r14,0x8c
    7a2a29701463:	mov    QWORD PTR [r12+0x8],r14
    7a2a29701468:	mov    r14d,0x1
    7a2a2970146e:	mov    QWORD PTR [r12+0x10],r14
    7a2a29701473:	add    r13,0x8c
    7a2a2970147a:	movzx  r14d,BYTE PTR [r12+0x40]
    7a2a29701480:	mov    BYTE PTR [r13+0x0],r14b
    7a2a29701484:	mov    r13d,0x0
    7a2a2970148a:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29701492:	mov    r13d,0x410298
    7a2a29701498:	mov    QWORD PTR [r12+0xf0],r13
    7a2a297014a0:	mov    r13d,0x410338
    7a2a297014a6:	mov    QWORD PTR [r12+0x100],r13
    7a2a297014ae:	mov    r11,QWORD PTR [rsp]
    7a2a297014b2:	mov    QWORD PTR [r12+0x398],r11
    7a2a297014ba:	mov    edi,0x410338
    7a2a297014bf:	mov    QWORD PTR [r12+0x100],rdi
    7a2a297014c7:	add    rsp,0x10
    7a2a297014cb:	nop    DWORD PTR [rax+rax*1+0x0]
    7a2a297014d0:	jmp    QWORD PTR [rip+0x2]        # 0x7a2a297014d8
    7a2a297014d6:	xchg   ax,ax
    7a2a297014d8:	loopne 0x7a2a297014c1
    7a2a297014da:	outs   dx,DWORD PTR ds:[rsi]
    7a2a297014db:	sub    DWORD PTR [rdx],ebp
    7a2a297014dd:	jp     0x7a2a297014df
    7a2a297014df:	add    al,ch
    7a2a297014e1:	adc    al,0x70
    7a2a297014e3:	sub    DWORD PTR [rdx],ebp
    7a2a297014e5:	jp     0x7a2a297014e7
    7a2a297014e7:	add    BYTE PTR [rcx-0x45],cl
    7a2a297014ea:	movabs al,ds:0x4100006284fe3820
    7a2a297014f3:	jmp    rbx
    7a2a297014f5:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a297014fd:	add    r13,0x0
    7a2a29701501:	mov    QWORD PTR [r12],r13
    7a2a29701505:	mov    r13d,0x0
    7a2a2970150b:	mov    r14,QWORD PTR [r12+0x98]
    7a2a29701513:	mov    rcx,r14
    7a2a29701516:	or     r13,rcx
    7a2a29701519:	mov    QWORD PTR [r12+0x8],r13
    7a2a2970151e:	mov    r13d,0x12c
    7a2a29701524:	mov    QWORD PTR [r12+0x10],r13
    7a2a29701529:	mov    r13d,0x410274
    7a2a2970152f:	mov    QWORD PTR [r12+0xf0],r13
    7a2a29701537:	mov    r13d,0x410338
    7a2a2970153d:	mov    QWORD PTR [r12+0x100],r13
    7a2a29701545:	mov    r11,QWORD PTR [rsp]
    7a2a29701549:	mov    QWORD PTR [r12+0x398],r11
    7a2a29701551:	mov    edi,0x410338
    7a2a29701556:	mov    QWORD PTR [r12+0x100],rdi
    7a2a2970155e:	add    rsp,0x10
    7a2a29701562:	nop    WORD PTR [rax+rax*1+0x0]
    7a2a29701568:	jmp    QWORD PTR [rip+0x2]        # 0x7a2a29701570
    7a2a2970156e:	xchg   ax,ax
    7a2a29701570:	loopne 0x7a2a29701559
    7a2a29701572:	outs   dx,DWORD PTR ds:[rsi]
    7a2a29701573:	sub    DWORD PTR [rdx],ebp
    7a2a29701575:	jp     0x7a2a29701577
    7a2a29701577:	add    BYTE PTR [rax+0x2a297015],al
    7a2a2970157d:	jp     0x7a2a2970157f
    7a2a2970157f:	add    BYTE PTR [rcx-0x45],cl
    7a2a29701582:	movabs al,ds:0x4100006284fe3820
    7a2a2970158b:	jmp    rbx
    7a2a2970158d:	mov    eax,0x410278
    7a2a29701592:	mov    QWORD PTR [r12+0x100],rax
    7a2a2970159a:	push   rdx
    7a2a2970159b:	push   rsi
    7a2a2970159c:	push   r10
    7a2a2970159e:	push   r11
    7a2a297015a0:	pushf
    7a2a297015a1:	pop    r11
    7a2a297015a3:	mov    QWORD PTR [rsp+0x20],r11
    7a2a297015a8:	mov    rdx,QWORD PTR [rsp+0x20]
    7a2a297015ad:	mov    r10d,edx
    7a2a297015b0:	and    r10d,0xc0
    7a2a297015b7:	shl    r10d,0x18
    7a2a297015bb:	mov    r11d,edx
    7a2a297015be:	and    r11d,0x1
    7a2a297015c2:	shl    r11d,0x1d
    7a2a297015c6:	or     r10d,r11d
    7a2a297015c9:	mov    r11d,edx
    7a2a297015cc:	and    r11d,0x800
    7a2a297015d3:	shl    r11d,0x11
    7a2a297015d7:	or     r10d,r11d
    7a2a297015da:	btc    r10,0x1d
    7a2a297015df:	mov    r11d,0xf0000000
    7a2a297015e5:	and    r11,r10
    7a2a297015e8:	movabs rsi,0xffffffff0fffffff
    7a2a297015f2:	and    rbx,rsi
    7a2a297015f5:	or     rbx,r11
    7a2a297015f8:	pop    r11
    7a2a297015fa:	pop    r10
    7a2a297015fc:	pop    rsi
    7a2a297015fd:	pop    rdx
    7a2a297015fe:	mov    QWORD PTR [r12+0x108],rbx
    7a2a29701606:	add    rsp,0x10
    7a2a2970160a:	mov    eax,0xc
    7a2a2970160f:	movabs r11,0x6284fe382390
    7a2a29701619:	jmp    r11
    7a2a2970161c:	nop    DWORD PTR [rax+0x0]
    7a2a29701620:	sub    rsp,0x10
    7a2a29701624:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970162c:	mov    QWORD PTR [rsp],r11
    7a2a29701630:	jmp    0x7a2a29701429
    7a2a29701635:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a29701640:	sub    rsp,0x10
    7a2a29701644:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970164c:	mov    QWORD PTR [rsp],r11
    7a2a29701650:	jmp    0x7a2a297014f5
    7a2a29701655:	nop
    7a2a29701656:	nop
    7a2a29701657:	nop
