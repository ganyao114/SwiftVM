
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/0/2.bin:     file format binary


Disassembly of section .data:

00007017df8003f0 <.data>:
    7017df8003f0:	sub    rsp,0x10
    7017df8003f4:	mov    r13d,DWORD PTR [r12+0xa0]
    7017df8003fc:	sub    r13d,0x1
    7017df800400:	mov    QWORD PTR [r12+0xa0],r13
    7017df800408:	mov    rcx,QWORD PTR [r12+0x380]
    7017df800410:	jrcxz  0x7017df800417
    7017df800412:	jmp    0x7017df80058d
    7017df800417:	pushf
    7017df800418:	pop    r11
    7017df80041a:	mov    QWORD PTR [rsp],r11
    7017df80041e:	jne    0x7017df8004f5
    7017df800424:	jmp    0x7017df800429
    7017df800429:	mov    r13,QWORD PTR [r12+0xf8]
    7017df800431:	mov    r14,r13
    7017df800434:	add    r14,0x20
    7017df800438:	mov    r15,QWORD PTR [r14]
    7017df80043b:	mov    QWORD PTR [r12+0x98],r15
    7017df800443:	mov    r14d,0x80
    7017df800449:	mov    QWORD PTR [r12+0x40],r14
    7017df80044e:	mov    r14,r13
    7017df800451:	add    r14,0x0
    7017df800455:	mov    QWORD PTR [r12],r14
    7017df800459:	mov    r14,r13
    7017df80045c:	add    r14,0x8c
    7017df800463:	mov    QWORD PTR [r12+0x8],r14
    7017df800468:	mov    r14d,0x1
    7017df80046e:	mov    QWORD PTR [r12+0x10],r14
    7017df800473:	add    r13,0x8c
    7017df80047a:	movzx  r14d,BYTE PTR [r12+0x40]
    7017df800480:	mov    BYTE PTR [r13+0x0],r14b
    7017df800484:	mov    r13d,0x0
    7017df80048a:	mov    DWORD PTR [r12+0x32c],r13d
    7017df800492:	mov    r13d,0x410298
    7017df800498:	mov    QWORD PTR [r12+0xf0],r13
    7017df8004a0:	mov    r13d,0x410338
    7017df8004a6:	mov    QWORD PTR [r12+0x100],r13
    7017df8004ae:	mov    r11,QWORD PTR [rsp]
    7017df8004b2:	mov    QWORD PTR [r12+0x398],r11
    7017df8004ba:	mov    edi,0x410338
    7017df8004bf:	mov    QWORD PTR [r12+0x100],rdi
    7017df8004c7:	add    rsp,0x10
    7017df8004cb:	nop    DWORD PTR [rax+rax*1+0x0]
    7017df8004d0:	jmp    QWORD PTR [rip+0x2]        # 0x7017df8004d8
    7017df8004d6:	xchg   ax,ax
    7017df8004d8:	loopne 0x7017df8004b1
    7017df8004da:	jg     0x7017df8004bb
    7017df8004dc:	(bad)
    7017df8004dd:	jo     0x7017df8004df
    7017df8004df:	add    al,ch
    7017df8004e1:	add    al,0x80
    7017df8004e3:	fist   WORD PTR [rdi]
    7017df8004e5:	jo     0x7017df8004e7
    7017df8004e7:	add    BYTE PTR [rcx-0x45],cl
    7017df8004ea:	movabs al,ds:0x4100005dba7c1c00
    7017df8004f3:	jmp    rbx
    7017df8004f5:	mov    r13,QWORD PTR [r12+0xf8]
    7017df8004fd:	add    r13,0x0
    7017df800501:	mov    QWORD PTR [r12],r13
    7017df800505:	mov    r13d,0x0
    7017df80050b:	mov    r14,QWORD PTR [r12+0x98]
    7017df800513:	mov    rcx,r14
    7017df800516:	or     r13,rcx
    7017df800519:	mov    QWORD PTR [r12+0x8],r13
    7017df80051e:	mov    r13d,0x12c
    7017df800524:	mov    QWORD PTR [r12+0x10],r13
    7017df800529:	mov    r13d,0x410274
    7017df80052f:	mov    QWORD PTR [r12+0xf0],r13
    7017df800537:	mov    r13d,0x410338
    7017df80053d:	mov    QWORD PTR [r12+0x100],r13
    7017df800545:	mov    r11,QWORD PTR [rsp]
    7017df800549:	mov    QWORD PTR [r12+0x398],r11
    7017df800551:	mov    edi,0x410338
    7017df800556:	mov    QWORD PTR [r12+0x100],rdi
    7017df80055e:	add    rsp,0x10
    7017df800562:	nop    WORD PTR [rax+rax*1+0x0]
    7017df800568:	jmp    QWORD PTR [rip+0x2]        # 0x7017df800570
    7017df80056e:	xchg   ax,ax
    7017df800570:	loopne 0x7017df800549
    7017df800572:	jg     0x7017df800553
    7017df800574:	(bad)
    7017df800575:	jo     0x7017df800577
    7017df800577:	add    BYTE PTR [rax+0x17df8005],al
    7017df80057d:	jo     0x7017df80057f
    7017df80057f:	add    BYTE PTR [rcx-0x45],cl
    7017df800582:	movabs al,ds:0x4100005dba7c1c00
    7017df80058b:	jmp    rbx
    7017df80058d:	mov    eax,0x410278
    7017df800592:	mov    QWORD PTR [r12+0x100],rax
    7017df80059a:	push   rdx
    7017df80059b:	push   rsi
    7017df80059c:	push   r10
    7017df80059e:	push   r11
    7017df8005a0:	pushf
    7017df8005a1:	pop    r11
    7017df8005a3:	mov    QWORD PTR [rsp+0x20],r11
    7017df8005a8:	mov    rdx,QWORD PTR [rsp+0x20]
    7017df8005ad:	mov    r10d,edx
    7017df8005b0:	and    r10d,0xc0
    7017df8005b7:	shl    r10d,0x18
    7017df8005bb:	mov    r11d,edx
    7017df8005be:	and    r11d,0x1
    7017df8005c2:	shl    r11d,0x1d
    7017df8005c6:	or     r10d,r11d
    7017df8005c9:	mov    r11d,edx
    7017df8005cc:	and    r11d,0x800
    7017df8005d3:	shl    r11d,0x11
    7017df8005d7:	or     r10d,r11d
    7017df8005da:	btc    r10,0x1d
    7017df8005df:	mov    r11d,0xf0000000
    7017df8005e5:	and    r11,r10
    7017df8005e8:	movabs rsi,0xffffffff0fffffff
    7017df8005f2:	and    rbx,rsi
    7017df8005f5:	or     rbx,r11
    7017df8005f8:	pop    r11
    7017df8005fa:	pop    r10
    7017df8005fc:	pop    rsi
    7017df8005fd:	pop    rdx
    7017df8005fe:	mov    QWORD PTR [r12+0x108],rbx
    7017df800606:	add    rsp,0x10
    7017df80060a:	mov    eax,0xc
    7017df80060f:	movabs r11,0x5dba7c1c0390
    7017df800619:	jmp    r11
    7017df80061c:	nop    DWORD PTR [rax+0x0]
    7017df800620:	sub    rsp,0x10
    7017df800624:	mov    r11,QWORD PTR [r12+0x398]
    7017df80062c:	mov    QWORD PTR [rsp],r11
    7017df800630:	jmp    0x7017df800429
    7017df800635:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7017df800640:	sub    rsp,0x10
    7017df800644:	mov    r11,QWORD PTR [r12+0x398]
    7017df80064c:	mov    QWORD PTR [rsp],r11
    7017df800650:	jmp    0x7017df8004f5
    7017df800655:	nop
    7017df800656:	nop
    7017df800657:	nop
