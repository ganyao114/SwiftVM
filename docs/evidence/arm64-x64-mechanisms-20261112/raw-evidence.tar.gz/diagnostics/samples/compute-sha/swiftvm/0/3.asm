
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/0/3.bin:     file format binary


Disassembly of section .data:

00007017df800660 <.data>:
    7017df800660:	sub    rsp,0x10
    7017df800664:	mov    r11,QWORD PTR [r12+0x398]
    7017df80066c:	mov    QWORD PTR [rsp],r11
    7017df800670:	mov    r13,QWORD PTR [r12+0xf8]
    7017df800678:	mov    r14,r13
    7017df80067b:	add    r14,0x68
    7017df80067f:	mov    r15,QWORD PTR [r14]
    7017df800682:	mov    QWORD PTR [r12+0x40],r15
    7017df800687:	add    r13,0x88
    7017df80068e:	mov    r14d,0x0
    7017df800694:	mov    BYTE PTR [r13+0x0],r14b
    7017df800698:	mov    r13d,0x0
    7017df80069e:	mov    DWORD PTR [r12+0x32c],r13d
    7017df8006a6:	sub    r15,0x38
    7017df8006aa:	pushf
    7017df8006ab:	pop    r11
    7017df8006ad:	mov    QWORD PTR [rsp],r11
    7017df8006b1:	je     0x7017df800745
    7017df8006b7:	jmp    0x7017df8006bc
    7017df8006bc:	mov    r13,QWORD PTR [r12+0xf8]
    7017df8006c4:	mov    r14,r13
    7017df8006c7:	add    r14,0x0
    7017df8006cb:	mov    QWORD PTR [r12],r14
    7017df8006cf:	add    r13,0x88
    7017df8006d6:	mov    QWORD PTR [r12+0x8],r13
    7017df8006db:	mov    r13d,0x1
    7017df8006e1:	mov    QWORD PTR [r12+0x10],r13
    7017df8006e6:	mov    r13d,0x4102b8
    7017df8006ec:	mov    QWORD PTR [r12+0xf0],r13
    7017df8006f4:	mov    r13d,0x410338
    7017df8006fa:	mov    QWORD PTR [r12+0x100],r13
    7017df800702:	mov    r11,QWORD PTR [rsp]
    7017df800706:	mov    QWORD PTR [r12+0x398],r11
    7017df80070e:	mov    edi,0x410338
    7017df800713:	mov    QWORD PTR [r12+0x100],rdi
    7017df80071b:	add    rsp,0x10
    7017df80071f:	nop
    7017df800720:	jmp    QWORD PTR [rip+0x2]        # 0x7017df800728
    7017df800726:	xchg   ax,ax
    7017df800728:	loopne 0x7017df800701
    7017df80072a:	jg     0x7017df80070b
    7017df80072c:	(bad)
    7017df80072d:	jo     0x7017df80072f
    7017df80072f:	add    BYTE PTR [rax],bh
    7017df800731:	(bad)
    7017df800732:	sbb    bh,0x17
    7017df800735:	jo     0x7017df800737
    7017df800737:	add    BYTE PTR [rcx-0x45],cl
    7017df80073a:	movabs al,ds:0x4100005dba7c1c00
    7017df800743:	jmp    rbx
    7017df800745:	mov    r13,QWORD PTR [r12+0x98]
    7017df80074d:	ror    r13,0x3d
    7017df800751:	and    r13,0xfffffffffffffff8
    7017df800755:	mov    r14,QWORD PTR [r12+0xf8]
    7017df80075d:	mov    r15,r14
    7017df800760:	add    r15,0x0
    7017df800764:	mov    QWORD PTR [r12],r15
    7017df800768:	mov    r15,r14
    7017df80076b:	add    r15,0x78
    7017df80076f:	mov    QWORD PTR [r12+0x8],r15
    7017df800774:	mov    r15d,0x8
    7017df80077a:	mov    QWORD PTR [r12+0x10],r15
    7017df80077f:	movabs rcx,0xff00ff00ff00ff
    7017df800789:	mov    r15,r13
    7017df80078c:	and    r15,rcx
    7017df80078f:	shl    r15,0x8
    7017df800793:	movabs rcx,0xff00ff00ff00ff00
    7017df80079d:	and    r13,rcx
    7017df8007a0:	shr    r13,0x8
    7017df8007a4:	mov    rcx,r15
    7017df8007a7:	or     r13,rcx
    7017df8007aa:	movabs rcx,0xffff0000ffff
    7017df8007b4:	mov    r15,r13
    7017df8007b7:	and    r15,rcx
    7017df8007ba:	shl    r15,0x10
    7017df8007be:	movabs rcx,0xffff0000ffff0000
    7017df8007c8:	and    r13,rcx
    7017df8007cb:	shr    r13,0x10
    7017df8007cf:	mov    rcx,r15
    7017df8007d2:	or     r13,rcx
    7017df8007d5:	mov    r15,r13
    7017df8007d8:	shl    r15,0x20
    7017df8007dc:	shr    r13,0x20
    7017df8007e0:	mov    rcx,r15
    7017df8007e3:	or     r13,rcx
    7017df8007e6:	mov    QWORD PTR [r12+0x40],r13
    7017df8007eb:	add    r14,0x78
    7017df8007ef:	mov    QWORD PTR [r14],r13
    7017df8007f2:	mov    r13d,0x0
    7017df8007f8:	mov    DWORD PTR [r12+0x32c],r13d
    7017df800800:	mov    r13d,0x4102e0
    7017df800806:	mov    QWORD PTR [r12+0xf0],r13
    7017df80080e:	mov    r13d,0x410338
    7017df800814:	mov    QWORD PTR [r12+0x100],r13
    7017df80081c:	mov    r11,QWORD PTR [rsp]
    7017df800820:	mov    QWORD PTR [r12+0x398],r11
    7017df800828:	mov    edi,0x410338
    7017df80082d:	mov    QWORD PTR [r12+0x100],rdi
    7017df800835:	add    rsp,0x10
    7017df800839:	nop    DWORD PTR [rax+0x0]
    7017df800840:	jmp    QWORD PTR [rip+0x2]        # 0x7017df800848
    7017df800846:	xchg   ax,ax
    7017df800848:	loopne 0x7017df800821
    7017df80084a:	jg     0x7017df80082b
    7017df80084c:	(bad)
    7017df80084d:	jo     0x7017df80084f
    7017df80084f:	add    BYTE PTR [rax+0x8],bl
    7017df800852:	sbb    bh,0x17
    7017df800855:	jo     0x7017df800857
    7017df800857:	add    BYTE PTR [rcx-0x45],cl
    7017df80085a:	movabs al,ds:0x4100005dba7c1c00
    7017df800863:	jmp    rbx
    7017df800865:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7017df800870:	sub    rsp,0x10
    7017df800874:	mov    r11,QWORD PTR [r12+0x398]
    7017df80087c:	mov    QWORD PTR [rsp],r11
    7017df800880:	jmp    0x7017df8006bc
    7017df800885:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7017df800890:	sub    rsp,0x10
    7017df800894:	mov    r11,QWORD PTR [r12+0x398]
    7017df80089c:	mov    QWORD PTR [rsp],r11
    7017df8008a0:	jmp    0x7017df800745
    7017df8008a5:	nop
    7017df8008a6:	nop
    7017df8008a7:	nop
