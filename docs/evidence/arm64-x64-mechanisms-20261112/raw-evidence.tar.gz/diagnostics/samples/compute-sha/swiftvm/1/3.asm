
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/1/3.bin:     file format binary


Disassembly of section .data:

00007c636a000660 <.data>:
    7c636a000660:	sub    rsp,0x10
    7c636a000664:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00066c:	mov    QWORD PTR [rsp],r11
    7c636a000670:	mov    r13,QWORD PTR [r12+0xf8]
    7c636a000678:	mov    r14,r13
    7c636a00067b:	add    r14,0x68
    7c636a00067f:	mov    r15,QWORD PTR [r14]
    7c636a000682:	mov    QWORD PTR [r12+0x40],r15
    7c636a000687:	add    r13,0x88
    7c636a00068e:	mov    r14d,0x0
    7c636a000694:	mov    BYTE PTR [r13+0x0],r14b
    7c636a000698:	mov    r13d,0x0
    7c636a00069e:	mov    DWORD PTR [r12+0x32c],r13d
    7c636a0006a6:	sub    r15,0x38
    7c636a0006aa:	pushf
    7c636a0006ab:	pop    r11
    7c636a0006ad:	mov    QWORD PTR [rsp],r11
    7c636a0006b1:	je     0x7c636a000745
    7c636a0006b7:	jmp    0x7c636a0006bc
    7c636a0006bc:	mov    r13,QWORD PTR [r12+0xf8]
    7c636a0006c4:	mov    r14,r13
    7c636a0006c7:	add    r14,0x0
    7c636a0006cb:	mov    QWORD PTR [r12],r14
    7c636a0006cf:	add    r13,0x88
    7c636a0006d6:	mov    QWORD PTR [r12+0x8],r13
    7c636a0006db:	mov    r13d,0x1
    7c636a0006e1:	mov    QWORD PTR [r12+0x10],r13
    7c636a0006e6:	mov    r13d,0x4102b8
    7c636a0006ec:	mov    QWORD PTR [r12+0xf0],r13
    7c636a0006f4:	mov    r13d,0x410338
    7c636a0006fa:	mov    QWORD PTR [r12+0x100],r13
    7c636a000702:	mov    r11,QWORD PTR [rsp]
    7c636a000706:	mov    QWORD PTR [r12+0x398],r11
    7c636a00070e:	mov    edi,0x410338
    7c636a000713:	mov    QWORD PTR [r12+0x100],rdi
    7c636a00071b:	add    rsp,0x10
    7c636a00071f:	nop
    7c636a000720:	jmp    QWORD PTR [rip+0x2]        # 0x7c636a000728
    7c636a000726:	xchg   ax,ax
    7c636a000728:	loopne 0x7c636a000701
    7c636a00072a:	jmp    FWORD PTR [rcx+0x63]
    7c636a00072d:	jl     0x7c636a00072f
    7c636a00072f:	add    BYTE PTR [rax],bh
    7c636a000731:	(bad)
    7c636a000732:	add    BYTE PTR [rdx+0x63],ch
    7c636a000735:	jl     0x7c636a000737
    7c636a000737:	add    BYTE PTR [rcx-0x45],cl
    7c636a00073a:	movabs al,ds:0x41000059733cd1d0
    7c636a000743:	jmp    rbx
    7c636a000745:	mov    r13,QWORD PTR [r12+0x98]
    7c636a00074d:	ror    r13,0x3d
    7c636a000751:	and    r13,0xfffffffffffffff8
    7c636a000755:	mov    r14,QWORD PTR [r12+0xf8]
    7c636a00075d:	mov    r15,r14
    7c636a000760:	add    r15,0x0
    7c636a000764:	mov    QWORD PTR [r12],r15
    7c636a000768:	mov    r15,r14
    7c636a00076b:	add    r15,0x78
    7c636a00076f:	mov    QWORD PTR [r12+0x8],r15
    7c636a000774:	mov    r15d,0x8
    7c636a00077a:	mov    QWORD PTR [r12+0x10],r15
    7c636a00077f:	movabs rcx,0xff00ff00ff00ff
    7c636a000789:	mov    r15,r13
    7c636a00078c:	and    r15,rcx
    7c636a00078f:	shl    r15,0x8
    7c636a000793:	movabs rcx,0xff00ff00ff00ff00
    7c636a00079d:	and    r13,rcx
    7c636a0007a0:	shr    r13,0x8
    7c636a0007a4:	mov    rcx,r15
    7c636a0007a7:	or     r13,rcx
    7c636a0007aa:	movabs rcx,0xffff0000ffff
    7c636a0007b4:	mov    r15,r13
    7c636a0007b7:	and    r15,rcx
    7c636a0007ba:	shl    r15,0x10
    7c636a0007be:	movabs rcx,0xffff0000ffff0000
    7c636a0007c8:	and    r13,rcx
    7c636a0007cb:	shr    r13,0x10
    7c636a0007cf:	mov    rcx,r15
    7c636a0007d2:	or     r13,rcx
    7c636a0007d5:	mov    r15,r13
    7c636a0007d8:	shl    r15,0x20
    7c636a0007dc:	shr    r13,0x20
    7c636a0007e0:	mov    rcx,r15
    7c636a0007e3:	or     r13,rcx
    7c636a0007e6:	mov    QWORD PTR [r12+0x40],r13
    7c636a0007eb:	add    r14,0x78
    7c636a0007ef:	mov    QWORD PTR [r14],r13
    7c636a0007f2:	mov    r13d,0x0
    7c636a0007f8:	mov    DWORD PTR [r12+0x32c],r13d
    7c636a000800:	mov    r13d,0x4102e0
    7c636a000806:	mov    QWORD PTR [r12+0xf0],r13
    7c636a00080e:	mov    r13d,0x410338
    7c636a000814:	mov    QWORD PTR [r12+0x100],r13
    7c636a00081c:	mov    r11,QWORD PTR [rsp]
    7c636a000820:	mov    QWORD PTR [r12+0x398],r11
    7c636a000828:	mov    edi,0x410338
    7c636a00082d:	mov    QWORD PTR [r12+0x100],rdi
    7c636a000835:	add    rsp,0x10
    7c636a000839:	nop    DWORD PTR [rax+0x0]
    7c636a000840:	jmp    QWORD PTR [rip+0x2]        # 0x7c636a000848
    7c636a000846:	xchg   ax,ax
    7c636a000848:	loopne 0x7c636a000821
    7c636a00084a:	jmp    FWORD PTR [rcx+0x63]
    7c636a00084d:	jl     0x7c636a00084f
    7c636a00084f:	add    BYTE PTR [rax+0x8],bl
    7c636a000852:	add    BYTE PTR [rdx+0x63],ch
    7c636a000855:	jl     0x7c636a000857
    7c636a000857:	add    BYTE PTR [rcx-0x45],cl
    7c636a00085a:	movabs al,ds:0x41000059733cd1d0
    7c636a000863:	jmp    rbx
    7c636a000865:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a000870:	sub    rsp,0x10
    7c636a000874:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00087c:	mov    QWORD PTR [rsp],r11
    7c636a000880:	jmp    0x7c636a0006bc
    7c636a000885:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a000890:	sub    rsp,0x10
    7c636a000894:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00089c:	mov    QWORD PTR [rsp],r11
    7c636a0008a0:	jmp    0x7c636a000745
    7c636a0008a5:	nop
    7c636a0008a6:	nop
    7c636a0008a7:	nop
