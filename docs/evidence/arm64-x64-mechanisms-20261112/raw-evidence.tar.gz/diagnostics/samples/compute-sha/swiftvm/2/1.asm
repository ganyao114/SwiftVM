
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/2/1.bin:     file format binary


Disassembly of section .data:

00007a2a296fe7e0 <.data>:
    7a2a296fe7e0:	sub    rsp,0x50
    7a2a296fe7e4:	mov    r11,QWORD PTR [r12+0x398]
    7a2a296fe7ec:	mov    QWORD PTR [rsp+0x48],r11
    7a2a296fe7f1:	mov    r13,QWORD PTR [r12]
    7a2a296fe7f5:	mov    r14,r13
    7a2a296fe7f8:	add    r14,0x20
    7a2a296fe7fc:	mov    r15,QWORD PTR [r14]
    7a2a296fe7ff:	mov    r14,QWORD PTR [r12+0x10]
    7a2a296fe804:	mov    rcx,r14
    7a2a296fe807:	add    r15,rcx
    7a2a296fe80a:	mov    QWORD PTR [r12+0x40],r15
    7a2a296fe80f:	add    r13,0x20
    7a2a296fe813:	mov    QWORD PTR [r13+0x0],r15
    7a2a296fe817:	mov    r13d,0x0
    7a2a296fe81d:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe825:	mov    rax,r14
    7a2a296fe828:	test   rax,rax
    7a2a296fe82b:	sete   al
    7a2a296fe82e:	movzx  eax,al
    7a2a296fe831:	and    eax,0x1
    7a2a296fe834:	mov    r13,rax
    7a2a296fe837:	mov    rax,r13
    7a2a296fe83a:	and    eax,0x1
    7a2a296fe83d:	test   rax,rax
    7a2a296fe840:	jne    0x7a2a29700fba
    7a2a296fe846:	jmp    0x7a2a296fe84b
    7a2a296fe84b:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a296fe853:	sub    r13,0x150
    7a2a296fe85a:	mov    QWORD PTR [r12+0xf8],r13
    7a2a296fe862:	mov    r14,QWORD PTR [r12]
    7a2a296fe866:	mov    r15,r14
    7a2a296fe869:	add    r15,0x68
    7a2a296fe86d:	mov    rbp,QWORD PTR [r15]
    7a2a296fe870:	mov    QWORD PTR [r12+0x88],rbp
    7a2a296fe878:	add    r14,0x28
    7a2a296fe87c:	mov    QWORD PTR [r12+0x40],r14
    7a2a296fe881:	mov    r14,r13
    7a2a296fe884:	add    r14,0x0
    7a2a296fe888:	mov    QWORD PTR [r12+0x48],r14
    7a2a296fe88d:	mov    r14d,0x420000
    7a2a296fe893:	add    r14,0x758
    7a2a296fe89a:	mov    QWORD PTR [r12+0x50],r14
    7a2a296fe89f:	add    r13,0x100
    7a2a296fe8a6:	mov    r14,r13
    7a2a296fe8a9:	add    r14,0x8
    7a2a296fe8ad:	mov    r15,QWORD PTR [r12+0xe8]
    7a2a296fe8b5:	mov    rbp,QWORD PTR [r12+0xd8]
    7a2a296fe8bd:	mov    QWORD PTR [r13+0x0],r15
    7a2a296fe8c1:	mov    r13d,0x0
    7a2a296fe8c7:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe8cf:	mov    QWORD PTR [r14],rbp
    7a2a296fe8d2:	mov    r13d,0x0
    7a2a296fe8d8:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe8e0:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a296fe8e8:	mov    r14,r13
    7a2a296fe8eb:	add    r14,0x110
    7a2a296fe8f2:	mov    r15,r14
    7a2a296fe8f5:	add    r15,0x8
    7a2a296fe8f9:	mov    rbp,QWORD PTR [r12+0xd0]
    7a2a296fe901:	mov    r8,QWORD PTR [r12+0xc8]
    7a2a296fe909:	mov    QWORD PTR [r14],rbp
    7a2a296fe90c:	mov    r14d,0x0
    7a2a296fe912:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe91a:	mov    QWORD PTR [r15],r8
    7a2a296fe91d:	mov    r14d,0x0
    7a2a296fe923:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe92b:	mov    r14,r13
    7a2a296fe92e:	add    r14,0x120
    7a2a296fe935:	mov    r15,r14
    7a2a296fe938:	add    r15,0x8
    7a2a296fe93c:	mov    rbp,QWORD PTR [r12+0xc0]
    7a2a296fe944:	mov    r8,QWORD PTR [r12+0xb8]
    7a2a296fe94c:	mov    QWORD PTR [r14],rbp
    7a2a296fe94f:	mov    r14d,0x0
    7a2a296fe955:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe95d:	mov    QWORD PTR [r15],r8
    7a2a296fe960:	mov    r14d,0x0
    7a2a296fe966:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe96e:	mov    r14,r13
    7a2a296fe971:	add    r14,0x130
    7a2a296fe978:	mov    r15,r14
    7a2a296fe97b:	add    r15,0x8
    7a2a296fe97f:	mov    rbp,QWORD PTR [r12+0xb0]
    7a2a296fe987:	mov    r8,QWORD PTR [r12+0xa8]
    7a2a296fe98f:	mov    QWORD PTR [r14],rbp
    7a2a296fe992:	mov    r14d,0x0
    7a2a296fe998:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe9a0:	mov    QWORD PTR [r15],r8
    7a2a296fe9a3:	mov    r14d,0x0
    7a2a296fe9a9:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fe9b1:	add    r13,0x140
    7a2a296fe9b8:	mov    r14,r13
    7a2a296fe9bb:	add    r14,0x8
    7a2a296fe9bf:	mov    r15,QWORD PTR [r12+0xa0]
    7a2a296fe9c7:	mov    rbp,QWORD PTR [r12+0x98]
    7a2a296fe9cf:	mov    QWORD PTR [r13+0x0],r15
    7a2a296fe9d3:	mov    r13d,0x0
    7a2a296fe9d9:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe9e1:	mov    QWORD PTR [r14],rbp
    7a2a296fe9e4:	mov    r13d,0x0
    7a2a296fe9ea:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fe9f2:	jmp    0x7a2a296fe9f7
    7a2a296fe9f7:	mov    r13,QWORD PTR [r12+0x8]
    7a2a296fe9fc:	mov    r14,r13
    7a2a296fe9ff:	add    r14,0x1
    7a2a296fea03:	movzx  r15d,BYTE PTR [r13+0x0]
    7a2a296fea08:	mov    QWORD PTR [r12+0x58],r15
    7a2a296fea0d:	mov    QWORD PTR [r12+0x8],r14
    7a2a296fea12:	mov    r13,QWORD PTR [r12+0x88]
    7a2a296fea1a:	mov    r14,r13
    7a2a296fea1d:	add    r14,0x1
    7a2a296fea21:	mov    QWORD PTR [r12+0x60],r14
    7a2a296fea26:	mov    r15,QWORD PTR [r12]
    7a2a296fea2a:	mov    rbp,r15
    7a2a296fea2d:	add    rbp,0x68
    7a2a296fea31:	mov    QWORD PTR [rbp+0x0],r14
    7a2a296fea35:	mov    r14d,0x0
    7a2a296fea3b:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a296fea43:	mov    rcx,r13
    7a2a296fea46:	mov    r14,r15
    7a2a296fea49:	add    r14,rcx
    7a2a296fea4c:	mov    QWORD PTR [r12+0x60],r14
    7a2a296fea51:	add    r14,0x28
    7a2a296fea55:	movzx  r13d,BYTE PTR [r12+0x58]
    7a2a296fea5b:	mov    BYTE PTR [r14],r13b
    7a2a296fea5e:	mov    r13d,0x0
    7a2a296fea64:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a296fea6c:	add    r15,0x68
    7a2a296fea70:	mov    r13,QWORD PTR [r15]
    7a2a296fea73:	mov    QWORD PTR [r12+0x88],r13
    7a2a296fea7b:	sub    r13,0x40
    7a2a296fea7f:	mov    rcx,QWORD PTR [r12+0x380]
    7a2a296fea87:	jrcxz  0x7a2a296fea8e
    7a2a296fea89:	jmp    0x7a2a29700fff
    7a2a296fea8e:	pushf
    7a2a296fea8f:	pop    r11
    7a2a296fea91:	mov    QWORD PTR [rsp+0x48],r11
    7a2a296fea96:	jne    0x7a2a29700ea1
    7a2a296fea9c:	jmp    0x7a2a296feaa1
    7a2a296feaa1:	mov    rax,QWORD PTR [r12+0x40]
    7a2a296feaa6:	mov    QWORD PTR [rsp],rax
    7a2a296feaaa:	mov    eax,0x0
    7a2a296feaaf:	mov    QWORD PTR [rsp+0x20],rax
    7a2a296feab4:	mov    eax,0x0
    7a2a296feab9:	mov    QWORD PTR [rsp+0x18],rax
    7a2a296feabe:	mov    eax,0x0
    7a2a296feac3:	mov    QWORD PTR [rsp+0x10],rax
    7a2a296feac8:	mov    eax,0x0
    7a2a296feacd:	mov    QWORD PTR [rsp+0x8],rax
    7a2a296fead2:	mov    rdi,QWORD PTR [rsp]
    7a2a296fead6:	movzx  r9d,BYTE PTR [rdi]
    7a2a296feada:	mov    r13,r9
    7a2a296feadd:	mov    rcx,r13
    7a2a296feae0:	mov    r9,QWORD PTR [rsp+0x20]
    7a2a296feae5:	or     r9,rcx
    7a2a296feae8:	mov    r13,QWORD PTR [rsp]
    7a2a296feaec:	add    r13,0x1
    7a2a296feaf0:	movzx  r8d,BYTE PTR [r13+0x0]
    7a2a296feaf5:	mov    r13,r8
    7a2a296feaf8:	mov    rcx,r13
    7a2a296feafb:	mov    r8,QWORD PTR [rsp+0x18]
    7a2a296feb00:	or     r8,rcx
    7a2a296feb03:	mov    r13,QWORD PTR [rsp]
    7a2a296feb07:	add    r13,0x2
    7a2a296feb0b:	movzx  ebp,BYTE PTR [r13+0x0]
    7a2a296feb10:	mov    r13,rbp
    7a2a296feb13:	mov    rcx,r13
    7a2a296feb16:	mov    rbp,QWORD PTR [rsp+0x10]
    7a2a296feb1b:	or     rbp,rcx
    7a2a296feb1e:	mov    r13,QWORD PTR [rsp]
    7a2a296feb22:	add    r13,0x3
    7a2a296feb26:	movzx  r15d,BYTE PTR [r13+0x0]
    7a2a296feb2b:	mov    r13,r15
    7a2a296feb2e:	mov    rcx,r13
    7a2a296feb31:	mov    r15,QWORD PTR [rsp+0x8]
    7a2a296feb36:	or     r15,rcx
    7a2a296feb39:	mov    r13,QWORD PTR [rsp]
    7a2a296feb3d:	add    r13,0x4
    7a2a296feb41:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296feb46:	mov    r13,r14
    7a2a296feb49:	shl    r13,0x8
    7a2a296feb4d:	mov    rcx,r13
    7a2a296feb50:	or     r9,rcx
    7a2a296feb53:	mov    r13,QWORD PTR [rsp]
    7a2a296feb57:	add    r13,0x5
    7a2a296feb5b:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296feb60:	mov    r13,r14
    7a2a296feb63:	shl    r13,0x8
    7a2a296feb67:	mov    rcx,r13
    7a2a296feb6a:	or     r8,rcx
    7a2a296feb6d:	mov    r13,QWORD PTR [rsp]
    7a2a296feb71:	add    r13,0x6
    7a2a296feb75:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296feb7a:	mov    r13,r14
    7a2a296feb7d:	shl    r13,0x8
    7a2a296feb81:	mov    rcx,r13
    7a2a296feb84:	or     rbp,rcx
    7a2a296feb87:	mov    r13,QWORD PTR [rsp]
    7a2a296feb8b:	add    r13,0x7
    7a2a296feb8f:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296feb94:	mov    r13,r14
    7a2a296feb97:	shl    r13,0x8
    7a2a296feb9b:	mov    rcx,r13
    7a2a296feb9e:	or     r15,rcx
    7a2a296feba1:	mov    r13,QWORD PTR [rsp]
    7a2a296feba5:	add    r13,0x8
    7a2a296feba9:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296febae:	mov    r13,r14
    7a2a296febb1:	shl    r13,0x10
    7a2a296febb5:	mov    rcx,r13
    7a2a296febb8:	or     r9,rcx
    7a2a296febbb:	mov    r13,QWORD PTR [rsp]
    7a2a296febbf:	add    r13,0x9
    7a2a296febc3:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296febc8:	mov    r13,r14
    7a2a296febcb:	shl    r13,0x10
    7a2a296febcf:	mov    rcx,r13
    7a2a296febd2:	or     r8,rcx
    7a2a296febd5:	mov    r13,QWORD PTR [rsp]
    7a2a296febd9:	add    r13,0xa
    7a2a296febdd:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296febe2:	mov    r13,r14
    7a2a296febe5:	shl    r13,0x10
    7a2a296febe9:	mov    rcx,r13
    7a2a296febec:	or     rbp,rcx
    7a2a296febef:	mov    r13,QWORD PTR [rsp]
    7a2a296febf3:	add    r13,0xb
    7a2a296febf7:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296febfc:	mov    r13,r14
    7a2a296febff:	shl    r13,0x10
    7a2a296fec03:	mov    rcx,r13
    7a2a296fec06:	or     r15,rcx
    7a2a296fec09:	mov    r13,QWORD PTR [rsp]
    7a2a296fec0d:	add    r13,0xc
    7a2a296fec11:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fec16:	mov    r13,r14
    7a2a296fec19:	shl    r13,0x18
    7a2a296fec1d:	mov    rcx,r13
    7a2a296fec20:	or     r9,rcx
    7a2a296fec23:	mov    r13,QWORD PTR [rsp]
    7a2a296fec27:	add    r13,0xd
    7a2a296fec2b:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fec30:	mov    r13,r14
    7a2a296fec33:	shl    r13,0x18
    7a2a296fec37:	mov    rcx,r13
    7a2a296fec3a:	or     r8,rcx
    7a2a296fec3d:	mov    r13,QWORD PTR [rsp]
    7a2a296fec41:	add    r13,0xe
    7a2a296fec45:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fec4a:	mov    r13,r14
    7a2a296fec4d:	shl    r13,0x18
    7a2a296fec51:	mov    rcx,r13
    7a2a296fec54:	or     rbp,rcx
    7a2a296fec57:	mov    r13,QWORD PTR [rsp]
    7a2a296fec5b:	add    r13,0xf
    7a2a296fec5f:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fec64:	mov    r13,r14
    7a2a296fec67:	shl    r13,0x18
    7a2a296fec6b:	mov    rcx,r13
    7a2a296fec6e:	or     r15,rcx
    7a2a296fec71:	mov    r13,QWORD PTR [rsp]
    7a2a296fec75:	add    r13,0x10
    7a2a296fec79:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fec7e:	mov    r13,r14
    7a2a296fec81:	shl    r13,0x20
    7a2a296fec85:	mov    rcx,r13
    7a2a296fec88:	or     r9,rcx
    7a2a296fec8b:	mov    r13,QWORD PTR [rsp]
    7a2a296fec8f:	add    r13,0x11
    7a2a296fec93:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fec98:	mov    r13,r14
    7a2a296fec9b:	shl    r13,0x20
    7a2a296fec9f:	mov    rcx,r13
    7a2a296feca2:	or     r8,rcx
    7a2a296feca5:	mov    r13,QWORD PTR [rsp]
    7a2a296feca9:	add    r13,0x12
    7a2a296fecad:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fecb2:	mov    r13,r14
    7a2a296fecb5:	shl    r13,0x20
    7a2a296fecb9:	mov    rcx,r13
    7a2a296fecbc:	or     rbp,rcx
    7a2a296fecbf:	mov    r13,QWORD PTR [rsp]
    7a2a296fecc3:	add    r13,0x13
    7a2a296fecc7:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296feccc:	mov    r13,r14
    7a2a296feccf:	shl    r13,0x20
    7a2a296fecd3:	mov    rcx,r13
    7a2a296fecd6:	or     r15,rcx
    7a2a296fecd9:	mov    r13,QWORD PTR [rsp]
    7a2a296fecdd:	add    r13,0x14
    7a2a296fece1:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fece6:	mov    r13,r14
    7a2a296fece9:	shl    r13,0x28
    7a2a296feced:	mov    rcx,r13
    7a2a296fecf0:	or     r9,rcx
    7a2a296fecf3:	mov    r13,QWORD PTR [rsp]
    7a2a296fecf7:	add    r13,0x15
    7a2a296fecfb:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fed00:	mov    r13,r14
    7a2a296fed03:	shl    r13,0x28
    7a2a296fed07:	mov    rcx,r13
    7a2a296fed0a:	or     r8,rcx
    7a2a296fed0d:	mov    r13,QWORD PTR [rsp]
    7a2a296fed11:	add    r13,0x16
    7a2a296fed15:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fed1a:	mov    r13,r14
    7a2a296fed1d:	shl    r13,0x28
    7a2a296fed21:	mov    rcx,r13
    7a2a296fed24:	or     rbp,rcx
    7a2a296fed27:	mov    r13,QWORD PTR [rsp]
    7a2a296fed2b:	add    r13,0x17
    7a2a296fed2f:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fed34:	mov    r13,r14
    7a2a296fed37:	shl    r13,0x28
    7a2a296fed3b:	mov    rcx,r13
    7a2a296fed3e:	or     r15,rcx
    7a2a296fed41:	mov    r13,QWORD PTR [rsp]
    7a2a296fed45:	add    r13,0x18
    7a2a296fed49:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fed4e:	mov    r13,r14
    7a2a296fed51:	shl    r13,0x30
    7a2a296fed55:	mov    rcx,r13
    7a2a296fed58:	or     r9,rcx
    7a2a296fed5b:	mov    r13,QWORD PTR [rsp]
    7a2a296fed5f:	add    r13,0x19
    7a2a296fed63:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fed68:	mov    r13,r14
    7a2a296fed6b:	shl    r13,0x30
    7a2a296fed6f:	mov    rcx,r13
    7a2a296fed72:	or     r8,rcx
    7a2a296fed75:	mov    r13,QWORD PTR [rsp]
    7a2a296fed79:	add    r13,0x1a
    7a2a296fed7d:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fed82:	mov    r13,r14
    7a2a296fed85:	shl    r13,0x30
    7a2a296fed89:	mov    rcx,r13
    7a2a296fed8c:	or     rbp,rcx
    7a2a296fed8f:	mov    r13,QWORD PTR [rsp]
    7a2a296fed93:	add    r13,0x1b
    7a2a296fed97:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fed9c:	mov    r13,r14
    7a2a296fed9f:	shl    r13,0x30
    7a2a296feda3:	mov    rcx,r13
    7a2a296feda6:	or     r15,rcx
    7a2a296feda9:	mov    r13,QWORD PTR [rsp]
    7a2a296fedad:	add    r13,0x1c
    7a2a296fedb1:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fedb6:	mov    r13,r14
    7a2a296fedb9:	shl    r13,0x38
    7a2a296fedbd:	mov    rcx,r13
    7a2a296fedc0:	mov    rax,r9
    7a2a296fedc3:	or     rax,rcx
    7a2a296fedc6:	mov    QWORD PTR [rsp+0x40],rax
    7a2a296fedcb:	mov    r13,QWORD PTR [rsp]
    7a2a296fedcf:	add    r13,0x1d
    7a2a296fedd3:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fedd8:	mov    r13,r14
    7a2a296feddb:	shl    r13,0x38
    7a2a296feddf:	mov    rcx,r13
    7a2a296fede2:	mov    rax,r8
    7a2a296fede5:	or     rax,rcx
    7a2a296fede8:	mov    QWORD PTR [rsp+0x30],rax
    7a2a296feded:	mov    r13,QWORD PTR [rsp]
    7a2a296fedf1:	add    r13,0x1e
    7a2a296fedf5:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fedfa:	mov    r13,r14
    7a2a296fedfd:	shl    r13,0x38
    7a2a296fee01:	mov    rcx,r13
    7a2a296fee04:	mov    rax,rbp
    7a2a296fee07:	or     rax,rcx
    7a2a296fee0a:	mov    QWORD PTR [rsp+0x28],rax
    7a2a296fee0f:	mov    r13,QWORD PTR [rsp]
    7a2a296fee13:	add    r13,0x1f
    7a2a296fee17:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fee1c:	mov    r13,r14
    7a2a296fee1f:	shl    r13,0x38
    7a2a296fee23:	mov    rcx,r13
    7a2a296fee26:	mov    rax,r15
    7a2a296fee29:	or     rax,rcx
    7a2a296fee2c:	mov    QWORD PTR [rsp+0x38],rax
    7a2a296fee31:	mov    r13,QWORD PTR [rsp]
    7a2a296fee35:	add    r13,0x20
    7a2a296fee39:	movzx  r14d,BYTE PTR [r13+0x0]
    7a2a296fee3e:	mov    r13,r14
    7a2a296fee41:	mov    rcx,r13
    7a2a296fee44:	mov    r14,QWORD PTR [rsp+0x20]
    7a2a296fee49:	or     r14,rcx
    7a2a296fee4c:	mov    r13,QWORD PTR [rsp]
    7a2a296fee50:	add    r13,0x21
    7a2a296fee54:	movzx  ebp,BYTE PTR [r13+0x0]
    7a2a296fee59:	mov    r13,rbp
    7a2a296fee5c:	mov    rcx,r13
    7a2a296fee5f:	mov    rbp,QWORD PTR [rsp+0x18]
    7a2a296fee64:	or     rbp,rcx
    7a2a296fee67:	mov    r13,QWORD PTR [rsp]
    7a2a296fee6b:	add    r13,0x22
    7a2a296fee6f:	movzx  r8d,BYTE PTR [r13+0x0]
    7a2a296fee74:	mov    r13,r8
    7a2a296fee77:	mov    rcx,r13
    7a2a296fee7a:	mov    r8,QWORD PTR [rsp+0x10]
    7a2a296fee7f:	or     r8,rcx
    7a2a296fee82:	mov    r13,QWORD PTR [rsp]
    7a2a296fee86:	add    r13,0x23
    7a2a296fee8a:	movzx  r15d,BYTE PTR [r13+0x0]
    7a2a296fee8f:	mov    r13,r15
    7a2a296fee92:	mov    rcx,r13
    7a2a296fee95:	mov    r15,QWORD PTR [rsp+0x8]
    7a2a296fee9a:	or     r15,rcx
    7a2a296fee9d:	mov    r13,QWORD PTR [rsp]
    7a2a296feea1:	add    r13,0x24
    7a2a296feea5:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296feeaa:	mov    r13,r9
    7a2a296feead:	shl    r13,0x8
    7a2a296feeb1:	mov    rcx,r13
    7a2a296feeb4:	or     r14,rcx
    7a2a296feeb7:	mov    r13,QWORD PTR [rsp]
    7a2a296feebb:	add    r13,0x25
    7a2a296feebf:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296feec4:	mov    r13,r9
    7a2a296feec7:	shl    r13,0x8
    7a2a296feecb:	mov    rcx,r13
    7a2a296feece:	or     rbp,rcx
    7a2a296feed1:	mov    r13,QWORD PTR [rsp]
    7a2a296feed5:	add    r13,0x26
    7a2a296feed9:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296feede:	mov    r13,r9
    7a2a296feee1:	shl    r13,0x8
    7a2a296feee5:	mov    rcx,r13
    7a2a296feee8:	or     r8,rcx
    7a2a296feeeb:	mov    r13,QWORD PTR [rsp]
    7a2a296feeef:	add    r13,0x27
    7a2a296feef3:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296feef8:	mov    r13,r9
    7a2a296feefb:	shl    r13,0x8
    7a2a296feeff:	mov    rcx,r13
    7a2a296fef02:	or     r15,rcx
    7a2a296fef05:	mov    r13,QWORD PTR [rsp]
    7a2a296fef09:	add    r13,0x28
    7a2a296fef0d:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296fef12:	mov    r13,r9
    7a2a296fef15:	shl    r13,0x10
    7a2a296fef19:	mov    rcx,r13
    7a2a296fef1c:	or     r14,rcx
    7a2a296fef1f:	mov    r13,QWORD PTR [rsp]
    7a2a296fef23:	add    r13,0x29
    7a2a296fef27:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296fef2c:	mov    r13,r9
    7a2a296fef2f:	shl    r13,0x10
    7a2a296fef33:	mov    rcx,r13
    7a2a296fef36:	or     rbp,rcx
    7a2a296fef39:	mov    r13,QWORD PTR [rsp]
    7a2a296fef3d:	add    r13,0x2a
    7a2a296fef41:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296fef46:	mov    r13,r9
    7a2a296fef49:	shl    r13,0x10
    7a2a296fef4d:	mov    rcx,r13
    7a2a296fef50:	or     r8,rcx
    7a2a296fef53:	mov    r13,QWORD PTR [rsp]
    7a2a296fef57:	add    r13,0x2b
    7a2a296fef5b:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296fef60:	mov    r13,r9
    7a2a296fef63:	shl    r13,0x10
    7a2a296fef67:	mov    rcx,r13
    7a2a296fef6a:	or     r15,rcx
    7a2a296fef6d:	mov    r13,QWORD PTR [rsp]
    7a2a296fef71:	add    r13,0x2c
    7a2a296fef75:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296fef7a:	mov    r13,r9
    7a2a296fef7d:	shl    r13,0x18
    7a2a296fef81:	mov    rcx,r13
    7a2a296fef84:	or     r14,rcx
    7a2a296fef87:	mov    r13,QWORD PTR [rsp]
    7a2a296fef8b:	add    r13,0x2d
    7a2a296fef8f:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296fef94:	mov    r13,r9
    7a2a296fef97:	shl    r13,0x18
    7a2a296fef9b:	mov    rcx,r13
    7a2a296fef9e:	or     rbp,rcx
    7a2a296fefa1:	mov    r13,QWORD PTR [rsp]
    7a2a296fefa5:	add    r13,0x2e
    7a2a296fefa9:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296fefae:	mov    r13,r9
    7a2a296fefb1:	shl    r13,0x18
    7a2a296fefb5:	mov    rcx,r13
    7a2a296fefb8:	or     r8,rcx
    7a2a296fefbb:	mov    r13,QWORD PTR [rsp]
    7a2a296fefbf:	add    r13,0x2f
    7a2a296fefc3:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296fefc8:	mov    r13,r9
    7a2a296fefcb:	shl    r13,0x18
    7a2a296fefcf:	mov    rcx,r13
    7a2a296fefd2:	or     r15,rcx
    7a2a296fefd5:	mov    r13,QWORD PTR [rsp]
    7a2a296fefd9:	add    r13,0x30
    7a2a296fefdd:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296fefe2:	mov    r13,r9
    7a2a296fefe5:	shl    r13,0x20
    7a2a296fefe9:	mov    rcx,r13
    7a2a296fefec:	or     r14,rcx
    7a2a296fefef:	mov    r13,QWORD PTR [rsp]
    7a2a296feff3:	add    r13,0x31
    7a2a296feff7:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296feffc:	mov    r13,r9
    7a2a296fefff:	shl    r13,0x20
    7a2a296ff003:	mov    rcx,r13
    7a2a296ff006:	or     rbp,rcx
    7a2a296ff009:	mov    r13,QWORD PTR [rsp]
    7a2a296ff00d:	add    r13,0x32
    7a2a296ff011:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff016:	mov    r13,r9
    7a2a296ff019:	shl    r13,0x20
    7a2a296ff01d:	mov    rcx,r13
    7a2a296ff020:	or     r8,rcx
    7a2a296ff023:	mov    r13,QWORD PTR [rsp]
    7a2a296ff027:	add    r13,0x33
    7a2a296ff02b:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff030:	mov    r13,r9
    7a2a296ff033:	shl    r13,0x20
    7a2a296ff037:	mov    rcx,r13
    7a2a296ff03a:	or     r15,rcx
    7a2a296ff03d:	mov    r13,QWORD PTR [rsp]
    7a2a296ff041:	add    r13,0x34
    7a2a296ff045:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff04a:	mov    r13,r9
    7a2a296ff04d:	shl    r13,0x28
    7a2a296ff051:	mov    rcx,r13
    7a2a296ff054:	or     r14,rcx
    7a2a296ff057:	mov    r13,QWORD PTR [rsp]
    7a2a296ff05b:	add    r13,0x35
    7a2a296ff05f:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff064:	mov    r13,r9
    7a2a296ff067:	shl    r13,0x28
    7a2a296ff06b:	mov    rcx,r13
    7a2a296ff06e:	or     rbp,rcx
    7a2a296ff071:	mov    r13,QWORD PTR [rsp]
    7a2a296ff075:	add    r13,0x36
    7a2a296ff079:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff07e:	mov    r13,r9
    7a2a296ff081:	shl    r13,0x28
    7a2a296ff085:	mov    rcx,r13
    7a2a296ff088:	or     r8,rcx
    7a2a296ff08b:	mov    r13,QWORD PTR [rsp]
    7a2a296ff08f:	add    r13,0x37
    7a2a296ff093:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff098:	mov    r13,r9
    7a2a296ff09b:	shl    r13,0x28
    7a2a296ff09f:	mov    rcx,r13
    7a2a296ff0a2:	or     r15,rcx
    7a2a296ff0a5:	mov    r13,QWORD PTR [rsp]
    7a2a296ff0a9:	add    r13,0x38
    7a2a296ff0ad:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff0b2:	mov    r13,r9
    7a2a296ff0b5:	shl    r13,0x30
    7a2a296ff0b9:	mov    rcx,r13
    7a2a296ff0bc:	or     r14,rcx
    7a2a296ff0bf:	mov    r13,QWORD PTR [rsp]
    7a2a296ff0c3:	add    r13,0x39
    7a2a296ff0c7:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff0cc:	mov    r13,r9
    7a2a296ff0cf:	shl    r13,0x30
    7a2a296ff0d3:	mov    rcx,r13
    7a2a296ff0d6:	or     rbp,rcx
    7a2a296ff0d9:	mov    r13,QWORD PTR [rsp]
    7a2a296ff0dd:	add    r13,0x3a
    7a2a296ff0e1:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff0e6:	mov    r13,r9
    7a2a296ff0e9:	shl    r13,0x30
    7a2a296ff0ed:	mov    rcx,r13
    7a2a296ff0f0:	or     r8,rcx
    7a2a296ff0f3:	mov    r13,QWORD PTR [rsp]
    7a2a296ff0f7:	add    r13,0x3b
    7a2a296ff0fb:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff100:	mov    r13,r9
    7a2a296ff103:	shl    r13,0x30
    7a2a296ff107:	mov    rcx,r13
    7a2a296ff10a:	or     r15,rcx
    7a2a296ff10d:	mov    r13,QWORD PTR [rsp]
    7a2a296ff111:	add    r13,0x3c
    7a2a296ff115:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff11a:	mov    r13,r9
    7a2a296ff11d:	shl    r13,0x38
    7a2a296ff121:	mov    rcx,r13
    7a2a296ff124:	or     r14,rcx
    7a2a296ff127:	mov    r13,QWORD PTR [rsp]
    7a2a296ff12b:	add    r13,0x3d
    7a2a296ff12f:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff134:	mov    r13,r9
    7a2a296ff137:	shl    r13,0x38
    7a2a296ff13b:	mov    rcx,r13
    7a2a296ff13e:	or     rbp,rcx
    7a2a296ff141:	mov    r13,QWORD PTR [rsp]
    7a2a296ff145:	add    r13,0x3e
    7a2a296ff149:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff14e:	mov    r13,r9
    7a2a296ff151:	shl    r13,0x38
    7a2a296ff155:	mov    rcx,r13
    7a2a296ff158:	or     r8,rcx
    7a2a296ff15b:	mov    r13,QWORD PTR [rsp]
    7a2a296ff15f:	add    r13,0x3f
    7a2a296ff163:	movzx  r9d,BYTE PTR [r13+0x0]
    7a2a296ff168:	mov    r13,r9
    7a2a296ff16b:	shl    r13,0x38
    7a2a296ff16f:	mov    rcx,r13
    7a2a296ff172:	or     r15,rcx
    7a2a296ff175:	mov    rax,QWORD PTR [rsp+0x40]
    7a2a296ff17a:	mov    QWORD PTR [r12+0x110],rax
    7a2a296ff182:	mov    QWORD PTR [r12+0x118],r14
    7a2a296ff18a:	mov    rax,QWORD PTR [rsp+0x30]
    7a2a296ff18f:	mov    QWORD PTR [r12+0x120],rax
    7a2a296ff197:	mov    QWORD PTR [r12+0x128],rbp
    7a2a296ff19f:	mov    rax,QWORD PTR [rsp+0x28]
    7a2a296ff1a4:	mov    QWORD PTR [r12+0x130],rax
    7a2a296ff1ac:	mov    QWORD PTR [r12+0x138],r8
    7a2a296ff1b4:	mov    rax,QWORD PTR [rsp+0x38]
    7a2a296ff1b9:	mov    QWORD PTR [r12+0x140],rax
    7a2a296ff1c1:	mov    QWORD PTR [r12+0x148],r15
    7a2a296ff1c9:	mov    r13d,0x0
    7a2a296ff1cf:	mov    QWORD PTR [r12+0x58],r13
    7a2a296ff1d4:	mov    r13d,0x0
    7a2a296ff1da:	mov    r14,QWORD PTR [rsp+0x30]
    7a2a296ff1df:	and    r14,0xff
    7a2a296ff1e6:	and    r14,0xffff
    7a2a296ff1ed:	mov    rcx,r14
    7a2a296ff1f0:	mov    r15,r13
    7a2a296ff1f3:	or     r15,rcx
    7a2a296ff1f6:	mov    r14,QWORD PTR [rsp+0x30]
    7a2a296ff1fb:	shr    r14,0x8
    7a2a296ff1ff:	and    r14,0xff
    7a2a296ff206:	and    r14,0xffff
    7a2a296ff20d:	shl    r14,0x10
    7a2a296ff211:	mov    rcx,r14
    7a2a296ff214:	or     r15,rcx
    7a2a296ff217:	mov    r14,QWORD PTR [rsp+0x30]
    7a2a296ff21c:	shr    r14,0x10
    7a2a296ff220:	and    r14,0xff
    7a2a296ff227:	and    r14,0xffff
    7a2a296ff22e:	shl    r14,0x20
    7a2a296ff232:	mov    rcx,r14
    7a2a296ff235:	or     r15,rcx
    7a2a296ff238:	mov    r14,QWORD PTR [rsp+0x30]
    7a2a296ff23d:	shr    r14,0x18
    7a2a296ff241:	and    r14,0xff
    7a2a296ff248:	and    r14,0xffff
    7a2a296ff24f:	shl    r14,0x30
    7a2a296ff253:	mov    rcx,r14
    7a2a296ff256:	or     r15,rcx
    7a2a296ff259:	mov    r14,QWORD PTR [rsp+0x30]
    7a2a296ff25e:	shr    r14,0x20
    7a2a296ff262:	and    r14,0xff
    7a2a296ff269:	and    r14,0xffff
    7a2a296ff270:	mov    rcx,r14
    7a2a296ff273:	or     r13,rcx
    7a2a296ff276:	mov    r14,QWORD PTR [rsp+0x30]
    7a2a296ff27b:	shr    r14,0x28
    7a2a296ff27f:	and    r14,0xff
    7a2a296ff286:	and    r14,0xffff
    7a2a296ff28d:	shl    r14,0x10
    7a2a296ff291:	mov    rcx,r14
    7a2a296ff294:	or     r13,rcx
    7a2a296ff297:	mov    r14,QWORD PTR [rsp+0x30]
    7a2a296ff29c:	shr    r14,0x30
    7a2a296ff2a0:	and    r14,0xff
    7a2a296ff2a7:	and    r14,0xffff
    7a2a296ff2ae:	shl    r14,0x20
    7a2a296ff2b2:	mov    rcx,r14
    7a2a296ff2b5:	or     r13,rcx
    7a2a296ff2b8:	mov    r14,QWORD PTR [rsp+0x30]
    7a2a296ff2bd:	shr    r14,0x38
    7a2a296ff2c1:	and    r14,0xff
    7a2a296ff2c8:	and    r14,0xffff
    7a2a296ff2cf:	shl    r14,0x30
    7a2a296ff2d3:	mov    rcx,r14
    7a2a296ff2d6:	or     r13,rcx
    7a2a296ff2d9:	mov    QWORD PTR [r12+0x150],r15
    7a2a296ff2e1:	mov    QWORD PTR [r12+0x158],r13
    7a2a296ff2e9:	mov    r13d,0x0
    7a2a296ff2ef:	mov    r14,QWORD PTR [rsp+0x28]
    7a2a296ff2f4:	and    r14,0xff
    7a2a296ff2fb:	and    r14,0xffff
    7a2a296ff302:	mov    rcx,r14
    7a2a296ff305:	mov    r15,r13
    7a2a296ff308:	or     r15,rcx
    7a2a296ff30b:	mov    r14,QWORD PTR [rsp+0x28]
    7a2a296ff310:	shr    r14,0x8
    7a2a296ff314:	and    r14,0xff
    7a2a296ff31b:	and    r14,0xffff
    7a2a296ff322:	shl    r14,0x10
    7a2a296ff326:	mov    rcx,r14
    7a2a296ff329:	or     r15,rcx
    7a2a296ff32c:	mov    r14,QWORD PTR [rsp+0x28]
    7a2a296ff331:	shr    r14,0x10
    7a2a296ff335:	and    r14,0xff
    7a2a296ff33c:	and    r14,0xffff
    7a2a296ff343:	shl    r14,0x20
    7a2a296ff347:	mov    rcx,r14
    7a2a296ff34a:	or     r15,rcx
    7a2a296ff34d:	mov    r14,QWORD PTR [rsp+0x28]
    7a2a296ff352:	shr    r14,0x18
    7a2a296ff356:	and    r14,0xff
    7a2a296ff35d:	and    r14,0xffff
    7a2a296ff364:	shl    r14,0x30
    7a2a296ff368:	mov    rcx,r14
    7a2a296ff36b:	or     r15,rcx
    7a2a296ff36e:	mov    r14,QWORD PTR [rsp+0x28]
    7a2a296ff373:	shr    r14,0x20
    7a2a296ff377:	and    r14,0xff
    7a2a296ff37e:	and    r14,0xffff
    7a2a296ff385:	mov    rcx,r14
    7a2a296ff388:	or     r13,rcx
    7a2a296ff38b:	mov    r14,QWORD PTR [rsp+0x28]
    7a2a296ff390:	shr    r14,0x28
    7a2a296ff394:	and    r14,0xff
    7a2a296ff39b:	and    r14,0xffff
    7a2a296ff3a2:	shl    r14,0x10
    7a2a296ff3a6:	mov    rcx,r14
    7a2a296ff3a9:	or     r13,rcx
    7a2a296ff3ac:	mov    r14,QWORD PTR [rsp+0x28]
    7a2a296ff3b1:	shr    r14,0x30
    7a2a296ff3b5:	and    r14,0xff
    7a2a296ff3bc:	and    r14,0xffff
    7a2a296ff3c3:	shl    r14,0x20
    7a2a296ff3c7:	mov    rcx,r14
    7a2a296ff3ca:	or     r13,rcx
    7a2a296ff3cd:	mov    r14,QWORD PTR [rsp+0x28]
    7a2a296ff3d2:	shr    r14,0x38
    7a2a296ff3d6:	and    r14,0xff
    7a2a296ff3dd:	and    r14,0xffff
    7a2a296ff3e4:	shl    r14,0x30
    7a2a296ff3e8:	mov    rcx,r14
    7a2a296ff3eb:	or     r13,rcx
    7a2a296ff3ee:	mov    QWORD PTR [r12+0x160],r15
    7a2a296ff3f6:	mov    QWORD PTR [r12+0x168],r13
    7a2a296ff3fe:	mov    r13,QWORD PTR [r12+0x110]
    7a2a296ff406:	mov    r14d,0x0
    7a2a296ff40c:	mov    r15,r13
    7a2a296ff40f:	and    r15,0xff
    7a2a296ff416:	and    r15,0xffff
    7a2a296ff41d:	mov    rcx,r15
    7a2a296ff420:	mov    rbp,r14
    7a2a296ff423:	or     rbp,rcx
    7a2a296ff426:	mov    r15,r13
    7a2a296ff429:	shr    r15,0x8
    7a2a296ff42d:	and    r15,0xff
    7a2a296ff434:	and    r15,0xffff
    7a2a296ff43b:	shl    r15,0x10
    7a2a296ff43f:	mov    rcx,r15
    7a2a296ff442:	or     rbp,rcx
    7a2a296ff445:	mov    r15,r13
    7a2a296ff448:	shr    r15,0x10
    7a2a296ff44c:	and    r15,0xff
    7a2a296ff453:	and    r15,0xffff
    7a2a296ff45a:	shl    r15,0x20
    7a2a296ff45e:	mov    rcx,r15
    7a2a296ff461:	or     rbp,rcx
    7a2a296ff464:	mov    r15,r13
    7a2a296ff467:	shr    r15,0x18
    7a2a296ff46b:	and    r15,0xff
    7a2a296ff472:	and    r15,0xffff
    7a2a296ff479:	shl    r15,0x30
    7a2a296ff47d:	mov    rcx,r15
    7a2a296ff480:	or     rbp,rcx
    7a2a296ff483:	mov    r15,r13
    7a2a296ff486:	shr    r15,0x20
    7a2a296ff48a:	and    r15,0xff
    7a2a296ff491:	and    r15,0xffff
    7a2a296ff498:	mov    rcx,r15
    7a2a296ff49b:	or     r14,rcx
    7a2a296ff49e:	mov    r15,r13
    7a2a296ff4a1:	shr    r15,0x28
    7a2a296ff4a5:	and    r15,0xff
    7a2a296ff4ac:	and    r15,0xffff
    7a2a296ff4b3:	shl    r15,0x10
    7a2a296ff4b7:	mov    rcx,r15
    7a2a296ff4ba:	or     r14,rcx
    7a2a296ff4bd:	mov    r15,r13
    7a2a296ff4c0:	shr    r15,0x30
    7a2a296ff4c4:	and    r15,0xff
    7a2a296ff4cb:	and    r15,0xffff
    7a2a296ff4d2:	shl    r15,0x20
    7a2a296ff4d6:	mov    rcx,r15
    7a2a296ff4d9:	or     r14,rcx
    7a2a296ff4dc:	shr    r13,0x38
    7a2a296ff4e0:	and    r13,0xff
    7a2a296ff4e7:	and    r13,0xffff
    7a2a296ff4ee:	shl    r13,0x30
    7a2a296ff4f2:	mov    rcx,r13
    7a2a296ff4f5:	or     r14,rcx
    7a2a296ff4f8:	mov    QWORD PTR [r12+0x170],rbp
    7a2a296ff500:	mov    QWORD PTR [r12+0x178],r14
    7a2a296ff508:	mov    r13,QWORD PTR [r12+0x118]
    7a2a296ff510:	mov    r14d,0x0
    7a2a296ff516:	mov    r15,r13
    7a2a296ff519:	and    r15,0xff
    7a2a296ff520:	and    r15,0xffff
    7a2a296ff527:	mov    rcx,r15
    7a2a296ff52a:	mov    rbp,r14
    7a2a296ff52d:	or     rbp,rcx
    7a2a296ff530:	mov    r15,r13
    7a2a296ff533:	shr    r15,0x8
    7a2a296ff537:	and    r15,0xff
    7a2a296ff53e:	and    r15,0xffff
    7a2a296ff545:	shl    r15,0x10
    7a2a296ff549:	mov    rcx,r15
    7a2a296ff54c:	or     rbp,rcx
    7a2a296ff54f:	mov    r15,r13
    7a2a296ff552:	shr    r15,0x10
    7a2a296ff556:	and    r15,0xff
    7a2a296ff55d:	and    r15,0xffff
    7a2a296ff564:	shl    r15,0x20
    7a2a296ff568:	mov    rcx,r15
    7a2a296ff56b:	or     rbp,rcx
    7a2a296ff56e:	mov    r15,r13
    7a2a296ff571:	shr    r15,0x18
    7a2a296ff575:	and    r15,0xff
    7a2a296ff57c:	and    r15,0xffff
    7a2a296ff583:	shl    r15,0x30
    7a2a296ff587:	mov    rcx,r15
    7a2a296ff58a:	or     rbp,rcx
    7a2a296ff58d:	mov    r15,r13
    7a2a296ff590:	shr    r15,0x20
    7a2a296ff594:	and    r15,0xff
    7a2a296ff59b:	and    r15,0xffff
    7a2a296ff5a2:	mov    rcx,r15
    7a2a296ff5a5:	or     r14,rcx
    7a2a296ff5a8:	mov    r15,r13
    7a2a296ff5ab:	shr    r15,0x28
    7a2a296ff5af:	and    r15,0xff
    7a2a296ff5b6:	and    r15,0xffff
    7a2a296ff5bd:	shl    r15,0x10
    7a2a296ff5c1:	mov    rcx,r15
    7a2a296ff5c4:	or     r14,rcx
    7a2a296ff5c7:	mov    r15,r13
    7a2a296ff5ca:	shr    r15,0x30
    7a2a296ff5ce:	and    r15,0xff
    7a2a296ff5d5:	and    r15,0xffff
    7a2a296ff5dc:	shl    r15,0x20
    7a2a296ff5e0:	mov    rcx,r15
    7a2a296ff5e3:	or     r14,rcx
    7a2a296ff5e6:	shr    r13,0x38
    7a2a296ff5ea:	and    r13,0xff
    7a2a296ff5f1:	and    r13,0xffff
    7a2a296ff5f8:	shl    r13,0x30
    7a2a296ff5fc:	mov    rcx,r13
    7a2a296ff5ff:	or     r14,rcx
    7a2a296ff602:	mov    QWORD PTR [r12+0x180],rbp
    7a2a296ff60a:	mov    QWORD PTR [r12+0x188],r14
    7a2a296ff612:	mov    r13,QWORD PTR [r12+0x128]
    7a2a296ff61a:	mov    r14d,0x0
    7a2a296ff620:	mov    r15,r13
    7a2a296ff623:	and    r15,0xff
    7a2a296ff62a:	and    r15,0xffff
    7a2a296ff631:	mov    rcx,r15
    7a2a296ff634:	mov    rbp,r14
    7a2a296ff637:	or     rbp,rcx
    7a2a296ff63a:	mov    r15,r13
    7a2a296ff63d:	shr    r15,0x8
    7a2a296ff641:	and    r15,0xff
    7a2a296ff648:	and    r15,0xffff
    7a2a296ff64f:	shl    r15,0x10
    7a2a296ff653:	mov    rcx,r15
    7a2a296ff656:	or     rbp,rcx
    7a2a296ff659:	mov    r15,r13
    7a2a296ff65c:	shr    r15,0x10
    7a2a296ff660:	and    r15,0xff
    7a2a296ff667:	and    r15,0xffff
    7a2a296ff66e:	shl    r15,0x20
    7a2a296ff672:	mov    rcx,r15
    7a2a296ff675:	or     rbp,rcx
    7a2a296ff678:	mov    r15,r13
    7a2a296ff67b:	shr    r15,0x18
    7a2a296ff67f:	and    r15,0xff
    7a2a296ff686:	and    r15,0xffff
    7a2a296ff68d:	shl    r15,0x30
    7a2a296ff691:	mov    rcx,r15
    7a2a296ff694:	or     rbp,rcx
    7a2a296ff697:	mov    r15,r13
    7a2a296ff69a:	shr    r15,0x20
    7a2a296ff69e:	and    r15,0xff
    7a2a296ff6a5:	and    r15,0xffff
    7a2a296ff6ac:	mov    rcx,r15
    7a2a296ff6af:	or     r14,rcx
    7a2a296ff6b2:	mov    r15,r13
    7a2a296ff6b5:	shr    r15,0x28
    7a2a296ff6b9:	and    r15,0xff
    7a2a296ff6c0:	and    r15,0xffff
    7a2a296ff6c7:	shl    r15,0x10
    7a2a296ff6cb:	mov    rcx,r15
    7a2a296ff6ce:	or     r14,rcx
    7a2a296ff6d1:	mov    r15,r13
    7a2a296ff6d4:	shr    r15,0x30
    7a2a296ff6d8:	and    r15,0xff
    7a2a296ff6df:	and    r15,0xffff
    7a2a296ff6e6:	shl    r15,0x20
    7a2a296ff6ea:	mov    rcx,r15
    7a2a296ff6ed:	or     r14,rcx
    7a2a296ff6f0:	shr    r13,0x38
    7a2a296ff6f4:	and    r13,0xff
    7a2a296ff6fb:	and    r13,0xffff
    7a2a296ff702:	shl    r13,0x30
    7a2a296ff706:	mov    rcx,r13
    7a2a296ff709:	or     r14,rcx
    7a2a296ff70c:	mov    QWORD PTR [r12+0x210],rbp
    7a2a296ff714:	mov    QWORD PTR [r12+0x218],r14
    7a2a296ff71c:	mov    r13,QWORD PTR [r12+0x138]
    7a2a296ff724:	mov    r14d,0x0
    7a2a296ff72a:	mov    r15,r13
    7a2a296ff72d:	and    r15,0xff
    7a2a296ff734:	and    r15,0xffff
    7a2a296ff73b:	mov    rcx,r15
    7a2a296ff73e:	mov    rbp,r14
    7a2a296ff741:	or     rbp,rcx
    7a2a296ff744:	mov    r15,r13
    7a2a296ff747:	shr    r15,0x8
    7a2a296ff74b:	and    r15,0xff
    7a2a296ff752:	and    r15,0xffff
    7a2a296ff759:	shl    r15,0x10
    7a2a296ff75d:	mov    rcx,r15
    7a2a296ff760:	or     rbp,rcx
    7a2a296ff763:	mov    r15,r13
    7a2a296ff766:	shr    r15,0x10
    7a2a296ff76a:	and    r15,0xff
    7a2a296ff771:	and    r15,0xffff
    7a2a296ff778:	shl    r15,0x20
    7a2a296ff77c:	mov    rcx,r15
    7a2a296ff77f:	or     rbp,rcx
    7a2a296ff782:	mov    r15,r13
    7a2a296ff785:	shr    r15,0x18
    7a2a296ff789:	and    r15,0xff
    7a2a296ff790:	and    r15,0xffff
    7a2a296ff797:	shl    r15,0x30
    7a2a296ff79b:	mov    rcx,r15
    7a2a296ff79e:	or     rbp,rcx
    7a2a296ff7a1:	mov    r15,r13
    7a2a296ff7a4:	shr    r15,0x20
    7a2a296ff7a8:	and    r15,0xff
    7a2a296ff7af:	and    r15,0xffff
    7a2a296ff7b6:	mov    rcx,r15
    7a2a296ff7b9:	or     r14,rcx
    7a2a296ff7bc:	mov    r15,r13
    7a2a296ff7bf:	shr    r15,0x28
    7a2a296ff7c3:	and    r15,0xff
    7a2a296ff7ca:	and    r15,0xffff
    7a2a296ff7d1:	shl    r15,0x10
    7a2a296ff7d5:	mov    rcx,r15
    7a2a296ff7d8:	or     r14,rcx
    7a2a296ff7db:	mov    r15,r13
    7a2a296ff7de:	shr    r15,0x30
    7a2a296ff7e2:	and    r15,0xff
    7a2a296ff7e9:	and    r15,0xffff
    7a2a296ff7f0:	shl    r15,0x20
    7a2a296ff7f4:	mov    rcx,r15
    7a2a296ff7f7:	or     r14,rcx
    7a2a296ff7fa:	shr    r13,0x38
    7a2a296ff7fe:	and    r13,0xff
    7a2a296ff805:	and    r13,0xffff
    7a2a296ff80c:	shl    r13,0x30
    7a2a296ff810:	mov    rcx,r13
    7a2a296ff813:	or     r14,rcx
    7a2a296ff816:	mov    QWORD PTR [r12+0x220],rbp
    7a2a296ff81e:	mov    QWORD PTR [r12+0x228],r14
    7a2a296ff826:	mov    r13,QWORD PTR [r12+0x140]
    7a2a296ff82e:	mov    r14d,0x0
    7a2a296ff834:	mov    r15,r13
    7a2a296ff837:	and    r15,0xff
    7a2a296ff83e:	and    r15,0xffff
    7a2a296ff845:	mov    rcx,r15
    7a2a296ff848:	mov    rbp,r14
    7a2a296ff84b:	or     rbp,rcx
    7a2a296ff84e:	mov    r15,r13
    7a2a296ff851:	shr    r15,0x8
    7a2a296ff855:	and    r15,0xff
    7a2a296ff85c:	and    r15,0xffff
    7a2a296ff863:	shl    r15,0x10
    7a2a296ff867:	mov    rcx,r15
    7a2a296ff86a:	or     rbp,rcx
    7a2a296ff86d:	mov    r15,r13
    7a2a296ff870:	shr    r15,0x10
    7a2a296ff874:	and    r15,0xff
    7a2a296ff87b:	and    r15,0xffff
    7a2a296ff882:	shl    r15,0x20
    7a2a296ff886:	mov    rcx,r15
    7a2a296ff889:	or     rbp,rcx
    7a2a296ff88c:	mov    r15,r13
    7a2a296ff88f:	shr    r15,0x18
    7a2a296ff893:	and    r15,0xff
    7a2a296ff89a:	and    r15,0xffff
    7a2a296ff8a1:	shl    r15,0x30
    7a2a296ff8a5:	mov    rcx,r15
    7a2a296ff8a8:	or     rbp,rcx
    7a2a296ff8ab:	mov    r15,r13
    7a2a296ff8ae:	shr    r15,0x20
    7a2a296ff8b2:	and    r15,0xff
    7a2a296ff8b9:	and    r15,0xffff
    7a2a296ff8c0:	mov    rcx,r15
    7a2a296ff8c3:	or     r14,rcx
    7a2a296ff8c6:	mov    r15,r13
    7a2a296ff8c9:	shr    r15,0x28
    7a2a296ff8cd:	and    r15,0xff
    7a2a296ff8d4:	and    r15,0xffff
    7a2a296ff8db:	shl    r15,0x10
    7a2a296ff8df:	mov    rcx,r15
    7a2a296ff8e2:	or     r14,rcx
    7a2a296ff8e5:	mov    r15,r13
    7a2a296ff8e8:	shr    r15,0x30
    7a2a296ff8ec:	and    r15,0xff
    7a2a296ff8f3:	and    r15,0xffff
    7a2a296ff8fa:	shl    r15,0x20
    7a2a296ff8fe:	mov    rcx,r15
    7a2a296ff901:	or     r14,rcx
    7a2a296ff904:	shr    r13,0x38
    7a2a296ff908:	and    r13,0xff
    7a2a296ff90f:	and    r13,0xffff
    7a2a296ff916:	shl    r13,0x30
    7a2a296ff91a:	mov    rcx,r13
    7a2a296ff91d:	or     r14,rcx
    7a2a296ff920:	mov    QWORD PTR [r12+0x250],rbp
    7a2a296ff928:	mov    QWORD PTR [r12+0x258],r14
    7a2a296ff930:	mov    r13,QWORD PTR [r12+0x148]
    7a2a296ff938:	mov    r14d,0x0
    7a2a296ff93e:	mov    r15,r13
    7a2a296ff941:	and    r15,0xff
    7a2a296ff948:	and    r15,0xffff
    7a2a296ff94f:	mov    rcx,r15
    7a2a296ff952:	mov    rbp,r14
    7a2a296ff955:	or     rbp,rcx
    7a2a296ff958:	mov    r15,r13
    7a2a296ff95b:	shr    r15,0x8
    7a2a296ff95f:	and    r15,0xff
    7a2a296ff966:	and    r15,0xffff
    7a2a296ff96d:	shl    r15,0x10
    7a2a296ff971:	mov    rcx,r15
    7a2a296ff974:	or     rbp,rcx
    7a2a296ff977:	mov    r15,r13
    7a2a296ff97a:	shr    r15,0x10
    7a2a296ff97e:	and    r15,0xff
    7a2a296ff985:	and    r15,0xffff
    7a2a296ff98c:	shl    r15,0x20
    7a2a296ff990:	mov    rcx,r15
    7a2a296ff993:	or     rbp,rcx
    7a2a296ff996:	mov    r15,r13
    7a2a296ff999:	shr    r15,0x18
    7a2a296ff99d:	and    r15,0xff
    7a2a296ff9a4:	and    r15,0xffff
    7a2a296ff9ab:	shl    r15,0x30
    7a2a296ff9af:	mov    rcx,r15
    7a2a296ff9b2:	or     rbp,rcx
    7a2a296ff9b5:	mov    r15,r13
    7a2a296ff9b8:	shr    r15,0x20
    7a2a296ff9bc:	and    r15,0xff
    7a2a296ff9c3:	and    r15,0xffff
    7a2a296ff9ca:	mov    rcx,r15
    7a2a296ff9cd:	or     r14,rcx
    7a2a296ff9d0:	mov    r15,r13
    7a2a296ff9d3:	shr    r15,0x28
    7a2a296ff9d7:	and    r15,0xff
    7a2a296ff9de:	and    r15,0xffff
    7a2a296ff9e5:	shl    r15,0x10
    7a2a296ff9e9:	mov    rcx,r15
    7a2a296ff9ec:	or     r14,rcx
    7a2a296ff9ef:	mov    r15,r13
    7a2a296ff9f2:	shr    r15,0x30
    7a2a296ff9f6:	and    r15,0xff
    7a2a296ff9fd:	and    r15,0xffff
    7a2a296ffa04:	shl    r15,0x20
    7a2a296ffa08:	mov    rcx,r15
    7a2a296ffa0b:	or     r14,rcx
    7a2a296ffa0e:	shr    r13,0x38
    7a2a296ffa12:	and    r13,0xff
    7a2a296ffa19:	and    r13,0xffff
    7a2a296ffa20:	shl    r13,0x30
    7a2a296ffa24:	mov    rcx,r13
    7a2a296ffa27:	or     r14,rcx
    7a2a296ffa2a:	mov    QWORD PTR [r12+0x110],rbp
    7a2a296ffa32:	mov    QWORD PTR [r12+0x118],r14
    7a2a296ffa3a:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7a2a296ffa44:	movdqa xmm2,xmm0
    7a2a296ffa48:	pxor   xmm0,xmm0
    7a2a296ffa4c:	movdqa xmm3,xmm0
    7a2a296ffa50:	movdqa xmm0,xmm2
    7a2a296ffa54:	movdqa xmm1,xmm3
    7a2a296ffa58:	punpcklwd xmm0,xmm1
    7a2a296ffa5c:	movdqa xmm4,xmm0
    7a2a296ffa60:	movdqa xmm0,xmm4
    7a2a296ffa64:	pslld  xmm0,0x10
    7a2a296ffa69:	movdqa xmm2,xmm0
    7a2a296ffa6d:	movdqa xmm0,xmm2
    7a2a296ffa71:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7a2a296ffa7b:	mov    r13,QWORD PTR [r12+0x160]
    7a2a296ffa83:	mov    r14d,0x0
    7a2a296ffa89:	mov    r15,r13
    7a2a296ffa8c:	and    r15,0xffff
    7a2a296ffa93:	shl    r15,0x8
    7a2a296ffa97:	mov    ecx,0xffffffff
    7a2a296ffa9c:	and    r15,rcx
    7a2a296ffa9f:	mov    rcx,r15
    7a2a296ffaa2:	mov    rbp,r14
    7a2a296ffaa5:	or     rbp,rcx
    7a2a296ffaa8:	mov    r15,r13
    7a2a296ffaab:	shr    r15,0x10
    7a2a296ffaaf:	and    r15,0xffff
    7a2a296ffab6:	shl    r15,0x8
    7a2a296ffaba:	mov    ecx,0xffffffff
    7a2a296ffabf:	and    r15,rcx
    7a2a296ffac2:	shl    r15,0x20
    7a2a296ffac6:	mov    rcx,r15
    7a2a296ffac9:	or     rbp,rcx
    7a2a296ffacc:	mov    r15,r13
    7a2a296ffacf:	shr    r15,0x20
    7a2a296ffad3:	and    r15,0xffff
    7a2a296ffada:	shl    r15,0x8
    7a2a296ffade:	mov    ecx,0xffffffff
    7a2a296ffae3:	and    r15,rcx
    7a2a296ffae6:	mov    rcx,r15
    7a2a296ffae9:	or     r14,rcx
    7a2a296ffaec:	shr    r13,0x30
    7a2a296ffaf0:	and    r13,0xffff
    7a2a296ffaf7:	shl    r13,0x8
    7a2a296ffafb:	mov    ecx,0xffffffff
    7a2a296ffb00:	and    r13,rcx
    7a2a296ffb03:	shl    r13,0x20
    7a2a296ffb07:	mov    rcx,r13
    7a2a296ffb0a:	or     r14,rcx
    7a2a296ffb0d:	mov    QWORD PTR [r12+0x240],rbp
    7a2a296ffb15:	mov    QWORD PTR [r12+0x248],r14
    7a2a296ffb1d:	mov    r13,QWORD PTR [r12+0x178]
    7a2a296ffb25:	mov    r14d,0x0
    7a2a296ffb2b:	mov    r15,r13
    7a2a296ffb2e:	and    r15,0xffff
    7a2a296ffb35:	mov    ecx,0xffffffff
    7a2a296ffb3a:	and    r15,rcx
    7a2a296ffb3d:	mov    rcx,r15
    7a2a296ffb40:	mov    rbp,r14
    7a2a296ffb43:	or     rbp,rcx
    7a2a296ffb46:	mov    r15,r13
    7a2a296ffb49:	shr    r15,0x10
    7a2a296ffb4d:	and    r15,0xffff
    7a2a296ffb54:	mov    ecx,0xffffffff
    7a2a296ffb59:	and    r15,rcx
    7a2a296ffb5c:	shl    r15,0x20
    7a2a296ffb60:	mov    rcx,r15
    7a2a296ffb63:	or     rbp,rcx
    7a2a296ffb66:	mov    r15,r13
    7a2a296ffb69:	shr    r15,0x20
    7a2a296ffb6d:	and    r15,0xffff
    7a2a296ffb74:	mov    ecx,0xffffffff
    7a2a296ffb79:	and    r15,rcx
    7a2a296ffb7c:	mov    rcx,r15
    7a2a296ffb7f:	or     r14,rcx
    7a2a296ffb82:	shr    r13,0x30
    7a2a296ffb86:	and    r13,0xffff
    7a2a296ffb8d:	mov    ecx,0xffffffff
    7a2a296ffb92:	and    r13,rcx
    7a2a296ffb95:	shl    r13,0x20
    7a2a296ffb99:	mov    rcx,r13
    7a2a296ffb9c:	or     r14,rcx
    7a2a296ffb9f:	mov    QWORD PTR [r12+0x260],rbp
    7a2a296ffba7:	mov    QWORD PTR [r12+0x268],r14
    7a2a296ffbaf:	mov    r13,QWORD PTR [r12+0x188]
    7a2a296ffbb7:	mov    r14d,0x0
    7a2a296ffbbd:	mov    r15,r13
    7a2a296ffbc0:	and    r15,0xffff
    7a2a296ffbc7:	mov    ecx,0xffffffff
    7a2a296ffbcc:	and    r15,rcx
    7a2a296ffbcf:	mov    rcx,r15
    7a2a296ffbd2:	mov    rbp,r14
    7a2a296ffbd5:	or     rbp,rcx
    7a2a296ffbd8:	mov    r15,r13
    7a2a296ffbdb:	shr    r15,0x10
    7a2a296ffbdf:	and    r15,0xffff
    7a2a296ffbe6:	mov    ecx,0xffffffff
    7a2a296ffbeb:	and    r15,rcx
    7a2a296ffbee:	shl    r15,0x20
    7a2a296ffbf2:	mov    rcx,r15
    7a2a296ffbf5:	or     rbp,rcx
    7a2a296ffbf8:	mov    r15,r13
    7a2a296ffbfb:	shr    r15,0x20
    7a2a296ffbff:	and    r15,0xffff
    7a2a296ffc06:	mov    ecx,0xffffffff
    7a2a296ffc0b:	and    r15,rcx
    7a2a296ffc0e:	mov    rcx,r15
    7a2a296ffc11:	or     r14,rcx
    7a2a296ffc14:	shr    r13,0x30
    7a2a296ffc18:	and    r13,0xffff
    7a2a296ffc1f:	mov    ecx,0xffffffff
    7a2a296ffc24:	and    r13,rcx
    7a2a296ffc27:	shl    r13,0x20
    7a2a296ffc2b:	mov    rcx,r13
    7a2a296ffc2e:	or     r14,rcx
    7a2a296ffc31:	mov    QWORD PTR [r12+0x270],rbp
    7a2a296ffc39:	mov    QWORD PTR [r12+0x278],r14
    7a2a296ffc41:	mov    r13,QWORD PTR [r12+0x170]
    7a2a296ffc49:	mov    r14d,0x0
    7a2a296ffc4f:	mov    r15,r13
    7a2a296ffc52:	and    r15,0xffff
    7a2a296ffc59:	mov    ecx,0xffffffff
    7a2a296ffc5e:	and    r15,rcx
    7a2a296ffc61:	mov    rcx,r15
    7a2a296ffc64:	mov    rbp,r14
    7a2a296ffc67:	or     rbp,rcx
    7a2a296ffc6a:	mov    r15,r13
    7a2a296ffc6d:	shr    r15,0x10
    7a2a296ffc71:	and    r15,0xffff
    7a2a296ffc78:	mov    ecx,0xffffffff
    7a2a296ffc7d:	and    r15,rcx
    7a2a296ffc80:	shl    r15,0x20
    7a2a296ffc84:	mov    rcx,r15
    7a2a296ffc87:	or     rbp,rcx
    7a2a296ffc8a:	mov    r15,r13
    7a2a296ffc8d:	shr    r15,0x20
    7a2a296ffc91:	and    r15,0xffff
    7a2a296ffc98:	mov    ecx,0xffffffff
    7a2a296ffc9d:	and    r15,rcx
    7a2a296ffca0:	mov    rcx,r15
    7a2a296ffca3:	or     r14,rcx
    7a2a296ffca6:	shr    r13,0x30
    7a2a296ffcaa:	and    r13,0xffff
    7a2a296ffcb1:	mov    ecx,0xffffffff
    7a2a296ffcb6:	and    r13,rcx
    7a2a296ffcb9:	shl    r13,0x20
    7a2a296ffcbd:	mov    rcx,r13
    7a2a296ffcc0:	or     r14,rcx
    7a2a296ffcc3:	mov    QWORD PTR [r12+0x170],rbp
    7a2a296ffccb:	mov    QWORD PTR [r12+0x178],r14
    7a2a296ffcd3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7a2a296ffcdd:	movdqa xmm2,xmm0
    7a2a296ffce1:	pxor   xmm0,xmm0
    7a2a296ffce5:	movdqa xmm3,xmm0
    7a2a296ffce9:	movdqa xmm0,xmm2
    7a2a296ffced:	movdqa xmm1,xmm3
    7a2a296ffcf1:	punpckhwd xmm0,xmm1
    7a2a296ffcf5:	movdqa xmm4,xmm0
    7a2a296ffcf9:	movdqa xmm0,xmm4
    7a2a296ffcfd:	pslld  xmm0,0x10
    7a2a296ffd02:	movdqa xmm3,xmm0
    7a2a296ffd06:	movdqa xmm0,xmm3
    7a2a296ffd0a:	movdqu XMMWORD PTR [r12+0x280],xmm0
    7a2a296ffd14:	mov    r13,QWORD PTR [r12+0x180]
    7a2a296ffd1c:	mov    r14d,0x0
    7a2a296ffd22:	mov    r15,r13
    7a2a296ffd25:	and    r15,0xffff
    7a2a296ffd2c:	mov    ecx,0xffffffff
    7a2a296ffd31:	and    r15,rcx
    7a2a296ffd34:	mov    rcx,r15
    7a2a296ffd37:	mov    rbp,r14
    7a2a296ffd3a:	or     rbp,rcx
    7a2a296ffd3d:	mov    r15,r13
    7a2a296ffd40:	shr    r15,0x10
    7a2a296ffd44:	and    r15,0xffff
    7a2a296ffd4b:	mov    ecx,0xffffffff
    7a2a296ffd50:	and    r15,rcx
    7a2a296ffd53:	shl    r15,0x20
    7a2a296ffd57:	mov    rcx,r15
    7a2a296ffd5a:	or     rbp,rcx
    7a2a296ffd5d:	mov    r15,r13
    7a2a296ffd60:	shr    r15,0x20
    7a2a296ffd64:	and    r15,0xffff
    7a2a296ffd6b:	mov    ecx,0xffffffff
    7a2a296ffd70:	and    r15,rcx
    7a2a296ffd73:	mov    rcx,r15
    7a2a296ffd76:	or     r14,rcx
    7a2a296ffd79:	shr    r13,0x30
    7a2a296ffd7d:	and    r13,0xffff
    7a2a296ffd84:	mov    ecx,0xffffffff
    7a2a296ffd89:	and    r13,rcx
    7a2a296ffd8c:	shl    r13,0x20
    7a2a296ffd90:	mov    rcx,r13
    7a2a296ffd93:	or     r14,rcx
    7a2a296ffd96:	mov    QWORD PTR [r12+0x180],rbp
    7a2a296ffd9e:	mov    QWORD PTR [r12+0x188],r14
    7a2a296ffda6:	pxor   xmm0,xmm0
    7a2a296ffdaa:	movdqa xmm3,xmm0
    7a2a296ffdae:	movdqa xmm0,xmm2
    7a2a296ffdb2:	movdqa xmm1,xmm3
    7a2a296ffdb6:	punpcklwd xmm0,xmm1
    7a2a296ffdba:	movdqa xmm4,xmm0
    7a2a296ffdbe:	movdqa xmm0,xmm4
    7a2a296ffdc2:	pslld  xmm0,0x10
    7a2a296ffdc7:	movdqa xmm2,xmm0
    7a2a296ffdcb:	movdqa xmm0,xmm2
    7a2a296ffdcf:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7a2a296ffdd9:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7a2a296ffde3:	movdqa xmm2,xmm0
    7a2a296ffde7:	pxor   xmm0,xmm0
    7a2a296ffdeb:	movdqa xmm3,xmm0
    7a2a296ffdef:	movdqa xmm0,xmm2
    7a2a296ffdf3:	movdqa xmm1,xmm3
    7a2a296ffdf7:	punpckhwd xmm0,xmm1
    7a2a296ffdfb:	movdqa xmm4,xmm0
    7a2a296ffdff:	movdqa xmm0,xmm4
    7a2a296ffe03:	pslld  xmm0,0x10
    7a2a296ffe08:	movdqa xmm2,xmm0
    7a2a296ffe0c:	movdqa xmm0,xmm2
    7a2a296ffe10:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7a2a296ffe1a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7a2a296ffe24:	movdqa xmm2,xmm0
    7a2a296ffe28:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7a2a296ffe32:	movdqa xmm3,xmm0
    7a2a296ffe36:	movdqa xmm1,xmm2
    7a2a296ffe3a:	por    xmm3,xmm1
    7a2a296ffe3e:	movdqa xmm0,xmm3
    7a2a296ffe42:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7a2a296ffe4c:	mov    r13,QWORD PTR [r12+0x228]
    7a2a296ffe54:	mov    r14d,0x0
    7a2a296ffe5a:	mov    r15,r13
    7a2a296ffe5d:	and    r15,0xffff
    7a2a296ffe64:	shl    r15,0x8
    7a2a296ffe68:	mov    ecx,0xffffffff
    7a2a296ffe6d:	and    r15,rcx
    7a2a296ffe70:	mov    rcx,r15
    7a2a296ffe73:	mov    rbp,r14
    7a2a296ffe76:	or     rbp,rcx
    7a2a296ffe79:	mov    r15,r13
    7a2a296ffe7c:	shr    r15,0x10
    7a2a296ffe80:	and    r15,0xffff
    7a2a296ffe87:	shl    r15,0x8
    7a2a296ffe8b:	mov    ecx,0xffffffff
    7a2a296ffe90:	and    r15,rcx
    7a2a296ffe93:	shl    r15,0x20
    7a2a296ffe97:	mov    rcx,r15
    7a2a296ffe9a:	or     rbp,rcx
    7a2a296ffe9d:	mov    r15,r13
    7a2a296ffea0:	shr    r15,0x20
    7a2a296ffea4:	and    r15,0xffff
    7a2a296ffeab:	shl    r15,0x8
    7a2a296ffeaf:	mov    ecx,0xffffffff
    7a2a296ffeb4:	and    r15,rcx
    7a2a296ffeb7:	mov    rcx,r15
    7a2a296ffeba:	or     r14,rcx
    7a2a296ffebd:	shr    r13,0x30
    7a2a296ffec1:	and    r13,0xffff
    7a2a296ffec8:	shl    r13,0x8
    7a2a296ffecc:	mov    ecx,0xffffffff
    7a2a296ffed1:	and    r13,rcx
    7a2a296ffed4:	shl    r13,0x20
    7a2a296ffed8:	mov    rcx,r13
    7a2a296ffedb:	or     r14,rcx
    7a2a296ffede:	mov    QWORD PTR [r12+0x240],rbp
    7a2a296ffee6:	mov    QWORD PTR [r12+0x248],r14
    7a2a296ffeee:	mov    r13,QWORD PTR [r12+0x220]
    7a2a296ffef6:	mov    r14d,0x0
    7a2a296ffefc:	mov    r15,r13
    7a2a296ffeff:	and    r15,0xffff
    7a2a296fff06:	shl    r15,0x8
    7a2a296fff0a:	mov    ecx,0xffffffff
    7a2a296fff0f:	and    r15,rcx
    7a2a296fff12:	mov    rcx,r15
    7a2a296fff15:	mov    rbp,r14
    7a2a296fff18:	or     rbp,rcx
    7a2a296fff1b:	mov    r15,r13
    7a2a296fff1e:	shr    r15,0x10
    7a2a296fff22:	and    r15,0xffff
    7a2a296fff29:	shl    r15,0x8
    7a2a296fff2d:	mov    ecx,0xffffffff
    7a2a296fff32:	and    r15,rcx
    7a2a296fff35:	shl    r15,0x20
    7a2a296fff39:	mov    rcx,r15
    7a2a296fff3c:	or     rbp,rcx
    7a2a296fff3f:	mov    r15,r13
    7a2a296fff42:	shr    r15,0x20
    7a2a296fff46:	and    r15,0xffff
    7a2a296fff4d:	shl    r15,0x8
    7a2a296fff51:	mov    ecx,0xffffffff
    7a2a296fff56:	and    r15,rcx
    7a2a296fff59:	mov    rcx,r15
    7a2a296fff5c:	or     r14,rcx
    7a2a296fff5f:	shr    r13,0x30
    7a2a296fff63:	and    r13,0xffff
    7a2a296fff6a:	shl    r13,0x8
    7a2a296fff6e:	mov    ecx,0xffffffff
    7a2a296fff73:	and    r13,rcx
    7a2a296fff76:	shl    r13,0x20
    7a2a296fff7a:	mov    rcx,r13
    7a2a296fff7d:	or     r14,rcx
    7a2a296fff80:	mov    QWORD PTR [r12+0x220],rbp
    7a2a296fff88:	mov    QWORD PTR [r12+0x228],r14
    7a2a296fff90:	mov    r13,QWORD PTR [r12+0x168]
    7a2a296fff98:	mov    r14d,0x0
    7a2a296fff9e:	mov    r15,r13
    7a2a296fffa1:	and    r15,0xffff
    7a2a296fffa8:	shl    r15,0x8
    7a2a296fffac:	mov    ecx,0xffffffff
    7a2a296fffb1:	and    r15,rcx
    7a2a296fffb4:	mov    rcx,r15
    7a2a296fffb7:	mov    rbp,r14
    7a2a296fffba:	or     rbp,rcx
    7a2a296fffbd:	mov    r15,r13
    7a2a296fffc0:	shr    r15,0x10
    7a2a296fffc4:	and    r15,0xffff
    7a2a296fffcb:	shl    r15,0x8
    7a2a296fffcf:	mov    ecx,0xffffffff
    7a2a296fffd4:	and    r15,rcx
    7a2a296fffd7:	shl    r15,0x20
    7a2a296fffdb:	mov    rcx,r15
    7a2a296fffde:	or     rbp,rcx
    7a2a296fffe1:	mov    r15,r13
    7a2a296fffe4:	shr    r15,0x20
    7a2a296fffe8:	and    r15,0xffff
    7a2a296fffef:	shl    r15,0x8
    7a2a296ffff3:	mov    ecx,0xffffffff
    7a2a296ffff8:	and    r15,rcx
    7a2a296ffffb:	mov    rcx,r15
    7a2a296ffffe:	or     r14,rcx
    7a2a29700001:	shr    r13,0x30
    7a2a29700005:	and    r13,0xffff
    7a2a2970000c:	shl    r13,0x8
    7a2a29700010:	mov    ecx,0xffffffff
    7a2a29700015:	and    r13,rcx
    7a2a29700018:	shl    r13,0x20
    7a2a2970001c:	mov    rcx,r13
    7a2a2970001f:	or     r14,rcx
    7a2a29700022:	mov    QWORD PTR [r12+0x160],rbp
    7a2a2970002a:	mov    QWORD PTR [r12+0x168],r14
    7a2a29700032:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7a2a2970003c:	movdqa xmm2,xmm0
    7a2a29700040:	movdqa xmm0,xmm2
    7a2a29700044:	pslld  xmm0,0x18
    7a2a29700049:	movdqa xmm3,xmm0
    7a2a2970004d:	movdqa xmm0,xmm3
    7a2a29700051:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7a2a2970005b:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7a2a29700065:	movdqa xmm2,xmm0
    7a2a29700069:	movdqa xmm0,xmm2
    7a2a2970006d:	pslld  xmm0,0x18
    7a2a29700072:	movdqa xmm3,xmm0
    7a2a29700076:	movdqa xmm0,xmm3
    7a2a2970007a:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7a2a29700084:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7a2a2970008e:	movdqa xmm2,xmm0
    7a2a29700092:	movdqa xmm0,xmm2
    7a2a29700096:	pslld  xmm0,0x18
    7a2a2970009b:	movdqa xmm3,xmm0
    7a2a2970009f:	movdqa xmm0,xmm3
    7a2a297000a3:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7a2a297000ad:	mov    r13,QWORD PTR [r12+0x250]
    7a2a297000b5:	mov    r14d,0x0
    7a2a297000bb:	mov    r15,r13
    7a2a297000be:	and    r15,0xffff
    7a2a297000c5:	mov    ecx,0xffffffff
    7a2a297000ca:	and    r15,rcx
    7a2a297000cd:	mov    rcx,r15
    7a2a297000d0:	mov    rbp,r14
    7a2a297000d3:	or     rbp,rcx
    7a2a297000d6:	mov    r15,r13
    7a2a297000d9:	shr    r15,0x10
    7a2a297000dd:	and    r15,0xffff
    7a2a297000e4:	mov    ecx,0xffffffff
    7a2a297000e9:	and    r15,rcx
    7a2a297000ec:	shl    r15,0x20
    7a2a297000f0:	mov    rcx,r15
    7a2a297000f3:	or     rbp,rcx
    7a2a297000f6:	mov    r15,r13
    7a2a297000f9:	shr    r15,0x20
    7a2a297000fd:	and    r15,0xffff
    7a2a29700104:	mov    ecx,0xffffffff
    7a2a29700109:	and    r15,rcx
    7a2a2970010c:	mov    rcx,r15
    7a2a2970010f:	or     r14,rcx
    7a2a29700112:	shr    r13,0x30
    7a2a29700116:	and    r13,0xffff
    7a2a2970011d:	mov    ecx,0xffffffff
    7a2a29700122:	and    r13,rcx
    7a2a29700125:	shl    r13,0x20
    7a2a29700129:	mov    rcx,r13
    7a2a2970012c:	or     r14,rcx
    7a2a2970012f:	mov    QWORD PTR [r12+0x140],rbp
    7a2a29700137:	mov    QWORD PTR [r12+0x148],r14
    7a2a2970013f:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7a2a29700149:	movdqa xmm2,xmm0
    7a2a2970014d:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7a2a29700157:	movdqa xmm3,xmm0
    7a2a2970015b:	movdqa xmm1,xmm2
    7a2a2970015f:	por    xmm3,xmm1
    7a2a29700163:	movdqa xmm0,xmm3
    7a2a29700167:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a29700171:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7a2a2970017b:	movdqa xmm2,xmm0
    7a2a2970017f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7a2a29700189:	movdqa xmm3,xmm0
    7a2a2970018d:	movdqa xmm1,xmm2
    7a2a29700191:	por    xmm3,xmm1
    7a2a29700195:	movdqa xmm0,xmm3
    7a2a29700199:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7a2a297001a3:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7a2a297001ad:	movdqa xmm2,xmm0
    7a2a297001b1:	movdqa xmm0,xmm2
    7a2a297001b5:	pslld  xmm0,0x18
    7a2a297001ba:	movdqa xmm3,xmm0
    7a2a297001be:	movdqa xmm0,xmm3
    7a2a297001c2:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7a2a297001cc:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7a2a297001d6:	movdqa xmm2,xmm0
    7a2a297001da:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7a2a297001e4:	movdqa xmm3,xmm0
    7a2a297001e8:	movdqa xmm1,xmm2
    7a2a297001ec:	por    xmm3,xmm1
    7a2a297001f0:	movdqa xmm0,xmm3
    7a2a297001f4:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7a2a297001fe:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7a2a29700208:	movdqa xmm2,xmm0
    7a2a2970020c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7a2a29700216:	movdqa xmm3,xmm0
    7a2a2970021a:	movdqa xmm1,xmm2
    7a2a2970021e:	por    xmm3,xmm1
    7a2a29700222:	movdqa xmm0,xmm3
    7a2a29700226:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7a2a29700230:	mov    r13,QWORD PTR [r12+0x118]
    7a2a29700238:	mov    r14d,0x0
    7a2a2970023e:	mov    r15,r13
    7a2a29700241:	and    r15,0xffff
    7a2a29700248:	mov    ecx,0xffffffff
    7a2a2970024d:	and    r15,rcx
    7a2a29700250:	mov    rcx,r15
    7a2a29700253:	mov    rbp,r14
    7a2a29700256:	or     rbp,rcx
    7a2a29700259:	mov    r15,r13
    7a2a2970025c:	shr    r15,0x10
    7a2a29700260:	and    r15,0xffff
    7a2a29700267:	mov    ecx,0xffffffff
    7a2a2970026c:	and    r15,rcx
    7a2a2970026f:	shl    r15,0x20
    7a2a29700273:	mov    rcx,r15
    7a2a29700276:	or     rbp,rcx
    7a2a29700279:	mov    r15,r13
    7a2a2970027c:	shr    r15,0x20
    7a2a29700280:	and    r15,0xffff
    7a2a29700287:	mov    ecx,0xffffffff
    7a2a2970028c:	and    r15,rcx
    7a2a2970028f:	mov    rcx,r15
    7a2a29700292:	or     r14,rcx
    7a2a29700295:	shr    r13,0x30
    7a2a29700299:	and    r13,0xffff
    7a2a297002a0:	mov    ecx,0xffffffff
    7a2a297002a5:	and    r13,rcx
    7a2a297002a8:	shl    r13,0x20
    7a2a297002ac:	mov    rcx,r13
    7a2a297002af:	or     r14,rcx
    7a2a297002b2:	mov    QWORD PTR [r12+0x170],rbp
    7a2a297002ba:	mov    QWORD PTR [r12+0x178],r14
    7a2a297002c2:	mov    r13,QWORD PTR [r12+0x110]
    7a2a297002ca:	mov    r14d,0x0
    7a2a297002d0:	mov    r15,r13
    7a2a297002d3:	and    r15,0xffff
    7a2a297002da:	mov    ecx,0xffffffff
    7a2a297002df:	and    r15,rcx
    7a2a297002e2:	mov    rcx,r15
    7a2a297002e5:	mov    rbp,r14
    7a2a297002e8:	or     rbp,rcx
    7a2a297002eb:	mov    r15,r13
    7a2a297002ee:	shr    r15,0x10
    7a2a297002f2:	and    r15,0xffff
    7a2a297002f9:	mov    ecx,0xffffffff
    7a2a297002fe:	and    r15,rcx
    7a2a29700301:	shl    r15,0x20
    7a2a29700305:	mov    rcx,r15
    7a2a29700308:	or     rbp,rcx
    7a2a2970030b:	mov    r15,r13
    7a2a2970030e:	shr    r15,0x20
    7a2a29700312:	and    r15,0xffff
    7a2a29700319:	mov    ecx,0xffffffff
    7a2a2970031e:	and    r15,rcx
    7a2a29700321:	mov    rcx,r15
    7a2a29700324:	or     r14,rcx
    7a2a29700327:	shr    r13,0x30
    7a2a2970032b:	and    r13,0xffff
    7a2a29700332:	mov    ecx,0xffffffff
    7a2a29700337:	and    r13,rcx
    7a2a2970033a:	shl    r13,0x20
    7a2a2970033e:	mov    rcx,r13
    7a2a29700341:	or     r14,rcx
    7a2a29700344:	mov    QWORD PTR [r12+0x110],rbp
    7a2a2970034c:	mov    QWORD PTR [r12+0x118],r14
    7a2a29700354:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7a2a2970035e:	movdqa xmm2,xmm0
    7a2a29700362:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7a2a2970036c:	movdqa xmm3,xmm0
    7a2a29700370:	movdqa xmm1,xmm2
    7a2a29700374:	por    xmm3,xmm1
    7a2a29700378:	movdqa xmm0,xmm3
    7a2a2970037c:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7a2a29700386:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7a2a29700390:	movdqa xmm2,xmm0
    7a2a29700394:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7a2a2970039e:	movdqa xmm3,xmm0
    7a2a297003a2:	movdqa xmm1,xmm2
    7a2a297003a6:	por    xmm3,xmm1
    7a2a297003aa:	movdqa xmm0,xmm3
    7a2a297003ae:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a297003b8:	mov    r13,QWORD PTR [r12+0x258]
    7a2a297003c0:	mov    r14d,0x0
    7a2a297003c6:	mov    r15,r13
    7a2a297003c9:	and    r15,0xffff
    7a2a297003d0:	mov    ecx,0xffffffff
    7a2a297003d5:	and    r15,rcx
    7a2a297003d8:	mov    rcx,r15
    7a2a297003db:	mov    rbp,r14
    7a2a297003de:	or     rbp,rcx
    7a2a297003e1:	mov    r15,r13
    7a2a297003e4:	shr    r15,0x10
    7a2a297003e8:	and    r15,0xffff
    7a2a297003ef:	mov    ecx,0xffffffff
    7a2a297003f4:	and    r15,rcx
    7a2a297003f7:	shl    r15,0x20
    7a2a297003fb:	mov    rcx,r15
    7a2a297003fe:	or     rbp,rcx
    7a2a29700401:	mov    r15,r13
    7a2a29700404:	shr    r15,0x20
    7a2a29700408:	and    r15,0xffff
    7a2a2970040f:	mov    ecx,0xffffffff
    7a2a29700414:	and    r15,rcx
    7a2a29700417:	mov    rcx,r15
    7a2a2970041a:	or     r14,rcx
    7a2a2970041d:	shr    r13,0x30
    7a2a29700421:	and    r13,0xffff
    7a2a29700428:	mov    ecx,0xffffffff
    7a2a2970042d:	and    r13,rcx
    7a2a29700430:	shl    r13,0x20
    7a2a29700434:	mov    rcx,r13
    7a2a29700437:	or     r14,rcx
    7a2a2970043a:	mov    QWORD PTR [r12+0x180],rbp
    7a2a29700442:	mov    QWORD PTR [r12+0x188],r14
    7a2a2970044a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7a2a29700454:	movdqa xmm2,xmm0
    7a2a29700458:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7a2a29700462:	movdqa xmm3,xmm0
    7a2a29700466:	movdqa xmm1,xmm2
    7a2a2970046a:	por    xmm3,xmm1
    7a2a2970046e:	movdqa xmm0,xmm3
    7a2a29700472:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7a2a2970047c:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7a2a29700486:	movdqa xmm2,xmm0
    7a2a2970048a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7a2a29700494:	movdqa xmm4,xmm0
    7a2a29700498:	movdqa xmm1,xmm2
    7a2a2970049c:	por    xmm4,xmm1
    7a2a297004a0:	movdqa xmm0,xmm4
    7a2a297004a4:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7a2a297004ae:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7a2a297004b8:	movdqa xmm2,xmm0
    7a2a297004bc:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7a2a297004c6:	movdqa xmm4,xmm0
    7a2a297004ca:	movdqa xmm1,xmm2
    7a2a297004ce:	por    xmm4,xmm1
    7a2a297004d2:	movdqa xmm0,xmm4
    7a2a297004d6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7a2a297004e0:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7a2a297004ea:	movdqa xmm2,xmm0
    7a2a297004ee:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7a2a297004f8:	movdqa xmm5,xmm0
    7a2a297004fc:	movdqa xmm1,xmm2
    7a2a29700500:	por    xmm5,xmm1
    7a2a29700504:	movdqa xmm0,xmm5
    7a2a29700508:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7a2a29700512:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7a2a2970051c:	movdqa xmm2,xmm0
    7a2a29700520:	movdqa xmm1,xmm2
    7a2a29700524:	por    xmm3,xmm1
    7a2a29700528:	movdqa xmm0,xmm3
    7a2a2970052c:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7a2a29700536:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a2970053e:	mov    r14,r13
    7a2a29700541:	add    r14,0x20
    7a2a29700545:	mov    r15,r14
    7a2a29700548:	add    r15,0x10
    7a2a2970054c:	movdqu XMMWORD PTR [r14],xmm4
    7a2a29700551:	mov    r14d,0x0
    7a2a29700557:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a2970055f:	movdqu XMMWORD PTR [r15],xmm5
    7a2a29700564:	mov    r14d,0x0
    7a2a2970056a:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a29700572:	mov    r14,r13
    7a2a29700575:	add    r14,0x10
    7a2a29700579:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7a2a29700583:	movdqa xmm2,xmm0
    7a2a29700587:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7a2a2970058d:	mov    r15d,0x0
    7a2a29700593:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a2970059b:	movdqu XMMWORD PTR [r14],xmm3
    7a2a297005a0:	mov    r14d,0x0
    7a2a297005a6:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a297005ae:	mov    r14d,DWORD PTR [r13+0x0]
    7a2a297005b2:	mov    QWORD PTR [r12+0x60],r14
    7a2a297005b7:	jmp    0x7a2a297005bc
    7a2a297005bc:	mov    r13,QWORD PTR [r12+0x58]
    7a2a297005c1:	mov    r14,QWORD PTR [r12+0x48]
    7a2a297005c6:	mov    rcx,r13
    7a2a297005c9:	add    r14,rcx
    7a2a297005cc:	mov    QWORD PTR [r12+0x68],r14
    7a2a297005d1:	add    r13,0x4
    7a2a297005d5:	mov    QWORD PTR [r12+0x58],r13
    7a2a297005da:	mov    r15,r14
    7a2a297005dd:	add    r15,0x4
    7a2a297005e1:	mov    ebp,DWORD PTR [r15]
    7a2a297005e4:	mov    QWORD PTR [r12+0x70],rbp
    7a2a297005e9:	mov    r15,r14
    7a2a297005ec:	add    r15,0x38
    7a2a297005f0:	mov    r8d,DWORD PTR [r15]
    7a2a297005f3:	mov    QWORD PTR [r12+0x78],r8
    7a2a297005f8:	add    r14,0x24
    7a2a297005fc:	mov    r15d,DWORD PTR [r14]
    7a2a297005ff:	mov    QWORD PTR [r12+0x90],r15
    7a2a29700607:	sub    r13,0xc0
    7a2a2970060e:	pushf
    7a2a2970060f:	pop    r11
    7a2a29700611:	mov    QWORD PTR [rsp+0x48],r11
    7a2a29700616:	mov    r13d,ebp
    7a2a29700619:	mov    r13d,r13d
    7a2a2970061c:	ror    r13d,0x7
    7a2a29700620:	mov    QWORD PTR [r12+0x80],r13
    7a2a29700628:	mov    r14d,r8d
    7a2a2970062b:	mov    r14d,r14d
    7a2a2970062e:	ror    r14d,0x11
    7a2a29700632:	mov    QWORD PTR [r12+0x88],r14
    7a2a2970063a:	mov    r9d,DWORD PTR [r12+0x60]
    7a2a2970063f:	mov    ecx,r9d
    7a2a29700642:	add    r15d,ecx
    7a2a29700645:	mov    QWORD PTR [r12+0x60],r15
    7a2a2970064a:	mov    r15d,ebp
    7a2a2970064d:	mov    r15d,r15d
    7a2a29700650:	shr    r15d,0x12
    7a2a29700654:	mov    ebp,ebp
    7a2a29700656:	shl    ebp,0xe
    7a2a29700659:	mov    ecx,ebp
    7a2a2970065b:	or     r15,rcx
    7a2a2970065e:	mov    r15d,r15d
    7a2a29700661:	mov    ecx,r15d
    7a2a29700664:	xor    r13,rcx
    7a2a29700667:	mov    r13d,r13d
    7a2a2970066a:	mov    QWORD PTR [r12+0x80],r13
    7a2a29700672:	mov    r15d,r8d
    7a2a29700675:	mov    r15d,r15d
    7a2a29700678:	shr    r15d,0x13
    7a2a2970067c:	mov    r8d,r8d
    7a2a2970067f:	shl    r8d,0xd
    7a2a29700683:	mov    ecx,r8d
    7a2a29700686:	or     r15,rcx
    7a2a29700689:	mov    r15d,r15d
    7a2a2970068c:	mov    ecx,r15d
    7a2a2970068f:	xor    r14,rcx
    7a2a29700692:	mov    r14d,r14d
    7a2a29700695:	mov    QWORD PTR [r12+0x88],r14
    7a2a2970069d:	mov    r15d,DWORD PTR [r12+0x70]
    7a2a297006a2:	mov    r15d,r15d
    7a2a297006a5:	shr    r15d,0x3
    7a2a297006a9:	mov    ecx,r15d
    7a2a297006ac:	xor    r13,rcx
    7a2a297006af:	mov    r13d,r13d
    7a2a297006b2:	mov    QWORD PTR [r12+0x80],r13
    7a2a297006ba:	mov    r15d,DWORD PTR [r12+0x78]
    7a2a297006bf:	mov    r15d,r15d
    7a2a297006c2:	shr    r15d,0xa
    7a2a297006c6:	mov    ecx,r15d
    7a2a297006c9:	xor    r14,rcx
    7a2a297006cc:	mov    r14d,r14d
    7a2a297006cf:	mov    QWORD PTR [r12+0x78],r14
    7a2a297006d4:	mov    r15d,DWORD PTR [r12+0x60]
    7a2a297006d9:	mov    ecx,r13d
    7a2a297006dc:	add    r15d,ecx
    7a2a297006df:	mov    QWORD PTR [r12+0x60],r15
    7a2a297006e4:	mov    ecx,r14d
    7a2a297006e7:	add    r15d,ecx
    7a2a297006ea:	mov    QWORD PTR [r12+0x60],r15
    7a2a297006ef:	mov    r13,QWORD PTR [r12+0x68]
    7a2a297006f4:	add    r13,0x40
    7a2a297006f8:	mov    DWORD PTR [r13+0x0],r15d
    7a2a297006fc:	mov    r13d,0x0
    7a2a29700702:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a2970070a:	mov    r13d,0x0
    7a2a29700710:	mov    r14d,DWORD PTR [r12+0x70]
    7a2a29700715:	mov    ecx,r14d
    7a2a29700718:	mov    r15d,r13d
    7a2a2970071b:	or     r15,rcx
    7a2a2970071e:	mov    r15d,r15d
    7a2a29700721:	mov    QWORD PTR [r12+0x60],r15
    7a2a29700726:	mov    rcx,QWORD PTR [r12+0x380]
    7a2a2970072e:	jrcxz  0x7a2a29700735
    7a2a29700730:	jmp    0x7a2a2970108e
    7a2a29700735:	push   QWORD PTR [rsp+0x48]
    7a2a29700739:	popf
    7a2a2970073a:	jne    0x7a2a297005bc
    7a2a29700740:	jmp    0x7a2a29700745
    7a2a29700745:	mov    r13,QWORD PTR [r12]
    7a2a29700749:	mov    r14,r13
    7a2a2970074c:	add    r14,0x4
    7a2a29700750:	mov    r15d,DWORD PTR [r13+0x0]
    7a2a29700754:	mov    ebp,DWORD PTR [r14]
    7a2a29700757:	mov    QWORD PTR [r12+0x78],r15
    7a2a2970075c:	mov    QWORD PTR [r12+0x80],rbp
    7a2a29700764:	mov    r14,r13
    7a2a29700767:	add    r14,0x8
    7a2a2970076b:	mov    r15,r14
    7a2a2970076e:	add    r15,0x4
    7a2a29700772:	mov    ebp,DWORD PTR [r14]
    7a2a29700775:	mov    r14d,DWORD PTR [r15]
    7a2a29700778:	mov    QWORD PTR [r12+0x70],rbp
    7a2a2970077d:	mov    QWORD PTR [r12+0x68],r14
    7a2a29700782:	mov    r14,r13
    7a2a29700785:	add    r14,0x18
    7a2a29700789:	mov    r15,r14
    7a2a2970078c:	add    r15,0x4
    7a2a29700790:	mov    ebp,DWORD PTR [r14]
    7a2a29700793:	mov    r14d,DWORD PTR [r15]
    7a2a29700796:	mov    QWORD PTR [r12+0x58],rbp
    7a2a2970079b:	mov    QWORD PTR [r12+0x60],r14
    7a2a297007a0:	add    r13,0x10
    7a2a297007a4:	mov    r14,r13
    7a2a297007a7:	add    r14,0x4
    7a2a297007ab:	mov    r15d,DWORD PTR [r13+0x0]
    7a2a297007af:	mov    r13d,DWORD PTR [r14]
    7a2a297007b2:	mov    QWORD PTR [r12+0x18],r15
    7a2a297007b7:	mov    QWORD PTR [r12+0x90],r13
    7a2a297007bf:	mov    r13d,0x0
    7a2a297007c5:	mov    QWORD PTR [r12+0x88],r13
    7a2a297007cd:	mov    r13d,0x0
    7a2a297007d3:	mov    r14d,DWORD PTR [r12+0x78]
    7a2a297007d8:	mov    ecx,r14d
    7a2a297007db:	mov    r15d,r13d
    7a2a297007de:	or     r15,rcx
    7a2a297007e1:	mov    r15d,r15d
    7a2a297007e4:	mov    QWORD PTR [r12+0xa8],r15
    7a2a297007ec:	mov    r13d,0x0
    7a2a297007f2:	mov    r14d,DWORD PTR [r12+0x80]
    7a2a297007fa:	mov    ecx,r14d
    7a2a297007fd:	mov    r15d,r13d
    7a2a29700800:	or     r15,rcx
    7a2a29700803:	mov    r15d,r15d
    7a2a29700806:	mov    QWORD PTR [r12+0x38],r15
    7a2a2970080b:	mov    r13d,0x0
    7a2a29700811:	mov    r14d,DWORD PTR [r12+0x70]
    7a2a29700816:	mov    ecx,r14d
    7a2a29700819:	mov    r15d,r13d
    7a2a2970081c:	or     r15,rcx
    7a2a2970081f:	mov    r15d,r15d
    7a2a29700822:	mov    QWORD PTR [r12+0x98],r15
    7a2a2970082a:	mov    r13d,0x0
    7a2a29700830:	mov    r14d,DWORD PTR [r12+0x68]
    7a2a29700835:	mov    ecx,r14d
    7a2a29700838:	mov    r15d,r13d
    7a2a2970083b:	or     r15,rcx
    7a2a2970083e:	mov    r15d,r15d
    7a2a29700841:	mov    QWORD PTR [r12+0x28],r15
    7a2a29700846:	mov    r13d,0x0
    7a2a2970084c:	mov    r14d,DWORD PTR [r12+0x60]
    7a2a29700851:	mov    ecx,r14d
    7a2a29700854:	mov    r15d,r13d
    7a2a29700857:	or     r15,rcx
    7a2a2970085a:	mov    r15d,r15d
    7a2a2970085d:	mov    QWORD PTR [r12+0xb0],r15
    7a2a29700865:	mov    r13d,0x0
    7a2a2970086b:	mov    r14d,DWORD PTR [r12+0x58]
    7a2a29700870:	mov    ecx,r14d
    7a2a29700873:	mov    r15d,r13d
    7a2a29700876:	or     r15,rcx
    7a2a29700879:	mov    r15d,r15d
    7a2a2970087c:	mov    QWORD PTR [r12+0xc0],r15
    7a2a29700884:	mov    r13d,0x0
    7a2a2970088a:	mov    r14d,DWORD PTR [r12+0x90]
    7a2a29700892:	mov    ecx,r14d
    7a2a29700895:	mov    r15d,r13d
    7a2a29700898:	or     r15,rcx
    7a2a2970089b:	mov    r15d,r15d
    7a2a2970089e:	mov    QWORD PTR [r12+0xc8],r15
    7a2a297008a6:	mov    r13d,0x0
    7a2a297008ac:	mov    r14d,DWORD PTR [r12+0x18]
    7a2a297008b1:	mov    ecx,r14d
    7a2a297008b4:	mov    r15d,r13d
    7a2a297008b7:	or     r15,rcx
    7a2a297008ba:	mov    r15d,r15d
    7a2a297008bd:	mov    QWORD PTR [r12+0xb8],r15
    7a2a297008c5:	jmp    0x7a2a297008ca
    7a2a297008ca:	mov    r13d,0x0
    7a2a297008d0:	mov    r14d,DWORD PTR [r12+0xb8]
    7a2a297008d8:	mov    ecx,r14d
    7a2a297008db:	mov    r15d,r13d
    7a2a297008de:	or     r15,rcx
    7a2a297008e1:	mov    r15d,r15d
    7a2a297008e4:	mov    QWORD PTR [r12+0x30],r15
    7a2a297008e9:	mov    r13d,0x0
    7a2a297008ef:	mov    r14d,DWORD PTR [r12+0xc0]
    7a2a297008f7:	mov    ecx,r14d
    7a2a297008fa:	mov    r15d,r13d
    7a2a297008fd:	or     r15,rcx
    7a2a29700900:	mov    r15d,r15d
    7a2a29700903:	mov    QWORD PTR [r12+0xa0],r15
    7a2a2970090b:	mov    r13d,0x0
    7a2a29700911:	mov    r14d,DWORD PTR [r12+0x28]
    7a2a29700916:	mov    ecx,r14d
    7a2a29700919:	mov    r15d,r13d
    7a2a2970091c:	or     r15,rcx
    7a2a2970091f:	mov    r15d,r15d
    7a2a29700922:	mov    QWORD PTR [r12+0xc0],r15
    7a2a2970092a:	mov    r13d,0x0
    7a2a29700930:	mov    r14d,DWORD PTR [r12+0x98]
    7a2a29700938:	mov    ecx,r14d
    7a2a2970093b:	mov    r15d,r13d
    7a2a2970093e:	or     r15,rcx
    7a2a29700941:	mov    r15d,r15d
    7a2a29700944:	mov    QWORD PTR [r12+0x28],r15
    7a2a29700949:	mov    r13d,0x0
    7a2a2970094f:	mov    r14d,DWORD PTR [r12+0x38]
    7a2a29700954:	mov    ecx,r14d
    7a2a29700957:	mov    r15d,r13d
    7a2a2970095a:	or     r15,rcx
    7a2a2970095d:	mov    r15d,r15d
    7a2a29700960:	mov    QWORD PTR [r12+0x98],r15
    7a2a29700968:	mov    r13d,0x0
    7a2a2970096e:	mov    r14d,DWORD PTR [r12+0xa8]
    7a2a29700976:	mov    ecx,r14d
    7a2a29700979:	mov    r15d,r13d
    7a2a2970097c:	or     r15,rcx
    7a2a2970097f:	mov    r15d,r15d
    7a2a29700982:	mov    QWORD PTR [r12+0x38],r15
    7a2a29700987:	mov    r13d,DWORD PTR [r12+0xb8]
    7a2a2970098f:	mov    r13d,r13d
    7a2a29700992:	ror    r13d,0x6
    7a2a29700996:	mov    QWORD PTR [r12+0xb8],r13
    7a2a2970099e:	mov    r13d,DWORD PTR [r12+0x30]
    7a2a297009a3:	mov    r14d,DWORD PTR [r12+0xc8]
    7a2a297009ab:	mov    ecx,r14d
    7a2a297009ae:	and    r13,rcx
    7a2a297009b1:	mov    r13d,r13d
    7a2a297009b4:	mov    QWORD PTR [r12+0xa8],r13
    7a2a297009bc:	mov    r15d,r15d
    7a2a297009bf:	ror    r15d,0x2
    7a2a297009c3:	mov    QWORD PTR [r12+0xd0],r15
    7a2a297009cb:	mov    r13d,0x0
    7a2a297009d1:	mov    ecx,r14d
    7a2a297009d4:	mov    r15d,r13d
    7a2a297009d7:	or     r15,rcx
    7a2a297009da:	mov    r15d,r15d
    7a2a297009dd:	mov    QWORD PTR [r12+0x20],r15
    7a2a297009e2:	mov    r13,QWORD PTR [r12+0x88]
    7a2a297009ea:	mov    r14,QWORD PTR [r12+0x50]
    7a2a297009ef:	mov    rcx,r13
    7a2a297009f2:	add    r14,rcx
    7a2a297009f5:	mov    r13d,DWORD PTR [r14]
    7a2a297009f8:	mov    QWORD PTR [r12+0xc8],r13
    7a2a29700a00:	mov    r13d,DWORD PTR [r12+0xa0]
    7a2a29700a08:	mov    r14d,DWORD PTR [r12+0x30]
    7a2a29700a0d:	mov    ecx,r14d
    7a2a29700a10:	not    rcx
    7a2a29700a13:	and    r13,rcx
    7a2a29700a16:	mov    r13d,r13d
    7a2a29700a19:	mov    QWORD PTR [r12+0xd8],r13
    7a2a29700a21:	mov    r13d,DWORD PTR [r12+0xb0]
    7a2a29700a29:	mov    r15d,DWORD PTR [r12+0xa8]
    7a2a29700a31:	mov    ecx,r13d
    7a2a29700a34:	add    r15d,ecx
    7a2a29700a37:	mov    QWORD PTR [r12+0xa8],r15
    7a2a29700a3f:	mov    r13d,DWORD PTR [r12+0xb8]
    7a2a29700a47:	mov    ebp,r14d
    7a2a29700a4a:	mov    ebp,ebp
    7a2a29700a4c:	shr    ebp,0xb
    7a2a29700a4f:	mov    r14d,r14d
    7a2a29700a52:	shl    r14d,0x15
    7a2a29700a56:	mov    ecx,r14d
    7a2a29700a59:	or     rbp,rcx
    7a2a29700a5c:	mov    ebp,ebp
    7a2a29700a5e:	mov    ecx,ebp
    7a2a29700a60:	xor    r13,rcx
    7a2a29700a63:	mov    r13d,r13d
    7a2a29700a66:	mov    QWORD PTR [r12+0xb0],r13
    7a2a29700a6e:	mov    r13d,DWORD PTR [r12+0xd0]
    7a2a29700a76:	mov    r14d,DWORD PTR [r12+0x38]
    7a2a29700a7b:	mov    ebp,r14d
    7a2a29700a7e:	mov    ebp,ebp
    7a2a29700a80:	shr    ebp,0xd
    7a2a29700a83:	mov    r14d,r14d
    7a2a29700a86:	shl    r14d,0x13
    7a2a29700a8a:	mov    ecx,r14d
    7a2a29700a8d:	or     rbp,rcx
    7a2a29700a90:	mov    ebp,ebp
    7a2a29700a92:	mov    ecx,ebp
    7a2a29700a94:	xor    r13,rcx
    7a2a29700a97:	mov    r13d,r13d
    7a2a29700a9a:	mov    QWORD PTR [r12+0xd0],r13
    7a2a29700aa2:	mov    r13d,DWORD PTR [r12+0xd8]
    7a2a29700aaa:	mov    ecx,r13d
    7a2a29700aad:	add    r15d,ecx
    7a2a29700ab0:	mov    QWORD PTR [r12+0xa8],r15
    7a2a29700ab8:	mov    r13,QWORD PTR [r12+0x88]
    7a2a29700ac0:	mov    r14,QWORD PTR [r12+0x48]
    7a2a29700ac5:	mov    rcx,r13
    7a2a29700ac8:	add    r14,rcx
    7a2a29700acb:	mov    r13d,DWORD PTR [r14]
    7a2a29700ace:	mov    QWORD PTR [r12+0xb8],r13
    7a2a29700ad6:	mov    r13d,DWORD PTR [r12+0x28]
    7a2a29700adb:	mov    r14d,DWORD PTR [r12+0x98]
    7a2a29700ae3:	mov    ecx,r14d
    7a2a29700ae6:	mov    ebp,r13d
    7a2a29700ae9:	and    rbp,rcx
    7a2a29700aec:	mov    ebp,ebp
    7a2a29700aee:	mov    QWORD PTR [r12+0xd8],rbp
    7a2a29700af6:	mov    ebp,DWORD PTR [r12+0xc8]
    7a2a29700afe:	mov    ecx,ebp
    7a2a29700b00:	add    r15d,ecx
    7a2a29700b03:	mov    QWORD PTR [r12+0xa8],r15
    7a2a29700b0b:	mov    ecx,r14d
    7a2a29700b0e:	xor    r13,rcx
    7a2a29700b11:	mov    r13d,r13d
    7a2a29700b14:	mov    QWORD PTR [r12+0xc8],r13
    7a2a29700b1c:	mov    r14d,DWORD PTR [r12+0xb0]
    7a2a29700b24:	mov    r15d,DWORD PTR [r12+0x30]
    7a2a29700b29:	mov    ebp,r15d
    7a2a29700b2c:	mov    ebp,ebp
    7a2a29700b2e:	shr    ebp,0x19
    7a2a29700b31:	mov    r15d,r15d
    7a2a29700b34:	shl    r15d,0x7
    7a2a29700b38:	mov    ecx,r15d
    7a2a29700b3b:	or     rbp,rcx
    7a2a29700b3e:	mov    ebp,ebp
    7a2a29700b40:	mov    ecx,ebp
    7a2a29700b42:	xor    r14,rcx
    7a2a29700b45:	mov    r14d,r14d
    7a2a29700b48:	mov    QWORD PTR [r12+0xb0],r14
    7a2a29700b50:	mov    r14d,DWORD PTR [r12+0x38]
    7a2a29700b55:	mov    ecx,r14d
    7a2a29700b58:	and    r13,rcx
    7a2a29700b5b:	mov    r13d,r13d
    7a2a29700b5e:	mov    QWORD PTR [r12+0xc8],r13
    7a2a29700b66:	mov    r15d,DWORD PTR [r12+0xd0]
    7a2a29700b6e:	mov    ebp,r14d
    7a2a29700b71:	mov    ebp,ebp
    7a2a29700b73:	shr    ebp,0x16
    7a2a29700b76:	mov    r14d,r14d
    7a2a29700b79:	shl    r14d,0xa
    7a2a29700b7d:	mov    ecx,r14d
    7a2a29700b80:	or     rbp,rcx
    7a2a29700b83:	mov    ebp,ebp
    7a2a29700b85:	mov    ecx,ebp
    7a2a29700b87:	xor    r15,rcx
    7a2a29700b8a:	mov    r15d,r15d
    7a2a29700b8d:	mov    QWORD PTR [r12+0xd0],r15
    7a2a29700b95:	mov    r14d,DWORD PTR [r12+0xb8]
    7a2a29700b9d:	mov    r15d,DWORD PTR [r12+0xa8]
    7a2a29700ba5:	mov    ecx,r14d
    7a2a29700ba8:	add    r15d,ecx
    7a2a29700bab:	mov    QWORD PTR [r12+0xa8],r15
    7a2a29700bb3:	mov    r14d,DWORD PTR [r12+0xd8]
    7a2a29700bbb:	mov    ecx,r14d
    7a2a29700bbe:	xor    r13,rcx
    7a2a29700bc1:	mov    r13d,r13d
    7a2a29700bc4:	mov    QWORD PTR [r12+0xb8],r13
    7a2a29700bcc:	mov    r14d,DWORD PTR [r12+0xb0]
    7a2a29700bd4:	mov    ecx,r14d
    7a2a29700bd7:	add    r15d,ecx
    7a2a29700bda:	mov    QWORD PTR [r12+0xa8],r15
    7a2a29700be2:	mov    r14,QWORD PTR [r12+0x88]
    7a2a29700bea:	add    r14,0x4
    7a2a29700bee:	mov    QWORD PTR [r12+0x88],r14
    7a2a29700bf6:	mov    ebp,DWORD PTR [r12+0xd0]
    7a2a29700bfe:	mov    ecx,ebp
    7a2a29700c00:	add    r13d,ecx
    7a2a29700c03:	mov    QWORD PTR [r12+0xb0],r13
    7a2a29700c0b:	mov    ebp,DWORD PTR [r12+0xc0]
    7a2a29700c13:	mov    ecx,ebp
    7a2a29700c15:	mov    r8d,r15d
    7a2a29700c18:	add    r8d,ecx
    7a2a29700c1b:	mov    QWORD PTR [r12+0xb8],r8
    7a2a29700c23:	sub    r14,0x100
    7a2a29700c2a:	pushf
    7a2a29700c2b:	pop    r11
    7a2a29700c2d:	mov    QWORD PTR [rsp+0x48],r11
    7a2a29700c32:	mov    ecx,r15d
    7a2a29700c35:	add    r13d,ecx
    7a2a29700c38:	mov    QWORD PTR [r12+0xa8],r13
    7a2a29700c40:	mov    r13d,0x0
    7a2a29700c46:	mov    r14d,DWORD PTR [r12+0xa0]
    7a2a29700c4e:	mov    ecx,r14d
    7a2a29700c51:	mov    r15d,r13d
    7a2a29700c54:	or     r15,rcx
    7a2a29700c57:	mov    r15d,r15d
    7a2a29700c5a:	mov    QWORD PTR [r12+0xb0],r15
    7a2a29700c62:	mov    r13d,0x0
    7a2a29700c68:	mov    r14d,DWORD PTR [r12+0x20]
    7a2a29700c6d:	mov    ecx,r14d
    7a2a29700c70:	mov    r15d,r13d
    7a2a29700c73:	or     r15,rcx
    7a2a29700c76:	mov    r15d,r15d
    7a2a29700c79:	mov    QWORD PTR [r12+0xc0],r15
    7a2a29700c81:	mov    r13d,0x0
    7a2a29700c87:	mov    r14d,DWORD PTR [r12+0x30]
    7a2a29700c8c:	mov    ecx,r14d
    7a2a29700c8f:	mov    r15d,r13d
    7a2a29700c92:	or     r15,rcx
    7a2a29700c95:	mov    r15d,r15d
    7a2a29700c98:	mov    QWORD PTR [r12+0xc8],r15
    7a2a29700ca0:	mov    rcx,QWORD PTR [r12+0x380]
    7a2a29700ca8:	jrcxz  0x7a2a29700caf
    7a2a29700caa:	jmp    0x7a2a29701115
    7a2a29700caf:	push   QWORD PTR [rsp+0x48]
    7a2a29700cb3:	popf
    7a2a29700cb4:	jne    0x7a2a297008ca
    7a2a29700cba:	jmp    0x7a2a29700cbf
    7a2a29700cbf:	mov    r13d,DWORD PTR [r12+0x70]
    7a2a29700cc4:	mov    r14d,DWORD PTR [r12+0x98]
    7a2a29700ccc:	mov    ecx,r13d
    7a2a29700ccf:	add    r14d,ecx
    7a2a29700cd2:	mov    QWORD PTR [r12+0x70],r14
    7a2a29700cd7:	mov    r13d,DWORD PTR [r12+0x68]
    7a2a29700cdc:	mov    r14d,DWORD PTR [r12+0x28]
    7a2a29700ce1:	mov    ecx,r13d
    7a2a29700ce4:	add    r14d,ecx
    7a2a29700ce7:	mov    QWORD PTR [r12+0x68],r14
    7a2a29700cec:	mov    r13d,0x0
    7a2a29700cf2:	mov    QWORD PTR [r12+0x88],r13
    7a2a29700cfa:	mov    r13d,DWORD PTR [r12+0x78]
    7a2a29700cff:	mov    r14d,DWORD PTR [r12+0xa8]
    7a2a29700d07:	mov    ecx,r13d
    7a2a29700d0a:	add    r14d,ecx
    7a2a29700d0d:	mov    QWORD PTR [r12+0x78],r14
    7a2a29700d12:	mov    r13d,DWORD PTR [r12+0x80]
    7a2a29700d1a:	mov    r14d,DWORD PTR [r12+0x38]
    7a2a29700d1f:	mov    ecx,r13d
    7a2a29700d22:	add    r14d,ecx
    7a2a29700d25:	mov    QWORD PTR [r12+0x80],r14
    7a2a29700d2d:	mov    r13,QWORD PTR [r12]
    7a2a29700d31:	add    r13,0x8
    7a2a29700d35:	mov    r14,r13
    7a2a29700d38:	add    r14,0x4
    7a2a29700d3c:	mov    r15d,DWORD PTR [r12+0x70]
    7a2a29700d41:	mov    ebp,DWORD PTR [r12+0x68]
    7a2a29700d46:	mov    DWORD PTR [r13+0x0],r15d
    7a2a29700d4a:	mov    r13d,0x0
    7a2a29700d50:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29700d58:	mov    DWORD PTR [r14],ebp
    7a2a29700d5b:	mov    r13d,0x0
    7a2a29700d61:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29700d69:	mov    r13d,DWORD PTR [r12+0x18]
    7a2a29700d6e:	mov    r14d,DWORD PTR [r12+0xb8]
    7a2a29700d76:	mov    ecx,r13d
    7a2a29700d79:	add    r14d,ecx
    7a2a29700d7c:	mov    QWORD PTR [r12+0x68],r14
    7a2a29700d81:	mov    r13d,DWORD PTR [r12+0x90]
    7a2a29700d89:	mov    r14d,DWORD PTR [r12+0x30]
    7a2a29700d8e:	mov    ecx,r13d
    7a2a29700d91:	add    r14d,ecx
    7a2a29700d94:	mov    QWORD PTR [r12+0x70],r14
    7a2a29700d99:	mov    r13d,DWORD PTR [r12+0x58]
    7a2a29700d9e:	mov    r14d,DWORD PTR [r12+0x20]
    7a2a29700da3:	mov    ecx,r13d
    7a2a29700da6:	add    r14d,ecx
    7a2a29700da9:	mov    QWORD PTR [r12+0x58],r14
    7a2a29700dae:	mov    r13d,DWORD PTR [r12+0x60]
    7a2a29700db3:	mov    r14d,DWORD PTR [r12+0xa0]
    7a2a29700dbb:	mov    ecx,r13d
    7a2a29700dbe:	add    r14d,ecx
    7a2a29700dc1:	mov    QWORD PTR [r12+0x60],r14
    7a2a29700dc6:	mov    r13,QWORD PTR [r12]
    7a2a29700dca:	mov    r15,r13
    7a2a29700dcd:	add    r15,0x4
    7a2a29700dd1:	mov    ebp,DWORD PTR [r12+0x78]
    7a2a29700dd6:	mov    r8d,DWORD PTR [r12+0x80]
    7a2a29700dde:	mov    DWORD PTR [r13+0x0],ebp
    7a2a29700de2:	mov    ebp,0x0
    7a2a29700de7:	mov    DWORD PTR [r12+0x32c],ebp
    7a2a29700def:	mov    DWORD PTR [r15],r8d
    7a2a29700df2:	mov    r15d,0x0
    7a2a29700df8:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a29700e00:	mov    r15,r13
    7a2a29700e03:	add    r15,0x10
    7a2a29700e07:	mov    rbp,r15
    7a2a29700e0a:	add    rbp,0x4
    7a2a29700e0e:	mov    r8d,DWORD PTR [r12+0x68]
    7a2a29700e13:	mov    r9d,DWORD PTR [r12+0x70]
    7a2a29700e18:	mov    DWORD PTR [r15],r8d
    7a2a29700e1b:	mov    r15d,0x0
    7a2a29700e21:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a29700e29:	mov    DWORD PTR [rbp+0x0],r9d
    7a2a29700e2d:	mov    r15d,0x0
    7a2a29700e33:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a29700e3b:	mov    r15,r13
    7a2a29700e3e:	add    r15,0x18
    7a2a29700e42:	mov    rbp,r15
    7a2a29700e45:	add    rbp,0x4
    7a2a29700e49:	mov    r8d,DWORD PTR [r12+0x58]
    7a2a29700e4e:	mov    DWORD PTR [r15],r8d
    7a2a29700e51:	mov    r15d,0x0
    7a2a29700e57:	mov    DWORD PTR [r12+0x32c],r15d
    7a2a29700e5f:	mov    DWORD PTR [rbp+0x0],r14d
    7a2a29700e63:	mov    r14d,0x0
    7a2a29700e69:	mov    DWORD PTR [r12+0x32c],r14d
    7a2a29700e71:	add    r13,0x68
    7a2a29700e75:	mov    r14d,0x0
    7a2a29700e7b:	mov    QWORD PTR [r13+0x0],r14
    7a2a29700e7f:	mov    r13d,0x0
    7a2a29700e85:	mov    DWORD PTR [r12+0x32c],r13d
    7a2a29700e8d:	mov    rcx,QWORD PTR [r12+0x380]
    7a2a29700e95:	jrcxz  0x7a2a29700e9c
    7a2a29700e97:	jmp    0x7a2a2970119c
    7a2a29700e9c:	jmp    0x7a2a29700ea1
    7a2a29700ea1:	mov    r13,QWORD PTR [r12+0x10]
    7a2a29700ea6:	sub    r13,0x1
    7a2a29700eaa:	mov    QWORD PTR [r12+0x10],r13
    7a2a29700eaf:	mov    rax,r13
    7a2a29700eb2:	test   rax,rax
    7a2a29700eb5:	sete   al
    7a2a29700eb8:	movzx  eax,al
    7a2a29700ebb:	and    eax,0x1
    7a2a29700ebe:	mov    r14,rax
    7a2a29700ec1:	mov    rax,r14
    7a2a29700ec4:	and    eax,0x1
    7a2a29700ec7:	test   rax,rax
    7a2a29700eca:	jne    0x7a2a29700ed5
    7a2a29700ed0:	jmp    0x7a2a296fe9f7
    7a2a29700ed5:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a29700edd:	mov    r14,r13
    7a2a29700ee0:	add    r14,0x140
    7a2a29700ee7:	mov    r15,r14
    7a2a29700eea:	add    r15,0x8
    7a2a29700eee:	mov    rbp,QWORD PTR [r14]
    7a2a29700ef1:	mov    r14,QWORD PTR [r15]
    7a2a29700ef4:	mov    QWORD PTR [r12+0xa0],rbp
    7a2a29700efc:	mov    QWORD PTR [r12+0x98],r14
    7a2a29700f04:	mov    r14,r13
    7a2a29700f07:	add    r14,0x130
    7a2a29700f0e:	mov    r15,r14
    7a2a29700f11:	add    r15,0x8
    7a2a29700f15:	mov    rbp,QWORD PTR [r14]
    7a2a29700f18:	mov    r14,QWORD PTR [r15]
    7a2a29700f1b:	mov    QWORD PTR [r12+0xb0],rbp
    7a2a29700f23:	mov    QWORD PTR [r12+0xa8],r14
    7a2a29700f2b:	mov    r14,r13
    7a2a29700f2e:	add    r14,0x120
    7a2a29700f35:	mov    r15,r14
    7a2a29700f38:	add    r15,0x8
    7a2a29700f3c:	mov    rbp,QWORD PTR [r14]
    7a2a29700f3f:	mov    r14,QWORD PTR [r15]
    7a2a29700f42:	mov    QWORD PTR [r12+0xc0],rbp
    7a2a29700f4a:	mov    QWORD PTR [r12+0xb8],r14
    7a2a29700f52:	add    r13,0x110
    7a2a29700f59:	mov    r14,r13
    7a2a29700f5c:	add    r14,0x8
    7a2a29700f60:	mov    r15,QWORD PTR [r13+0x0]
    7a2a29700f64:	mov    r13,QWORD PTR [r14]
    7a2a29700f67:	mov    QWORD PTR [r12+0xd0],r15
    7a2a29700f6f:	mov    QWORD PTR [r12+0xc8],r13
    7a2a29700f77:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a29700f7f:	mov    r14,r13
    7a2a29700f82:	add    r14,0x100
    7a2a29700f89:	mov    r15,r14
    7a2a29700f8c:	add    r15,0x8
    7a2a29700f90:	mov    rbp,QWORD PTR [r14]
    7a2a29700f93:	mov    r14,QWORD PTR [r15]
    7a2a29700f96:	mov    QWORD PTR [r12+0xe8],rbp
    7a2a29700f9e:	mov    QWORD PTR [r12+0xd8],r14
    7a2a29700fa6:	add    r13,0x150
    7a2a29700fad:	mov    QWORD PTR [r12+0xf8],r13
    7a2a29700fb5:	jmp    0x7a2a29700fba
    7a2a29700fba:	mov    rcx,QWORD PTR [r12+0x380]
    7a2a29700fc2:	jrcxz  0x7a2a29700fc9
    7a2a29700fc4:	jmp    0x7a2a29701223
    7a2a29700fc9:	mov    r13,QWORD PTR [r12+0xf0]
    7a2a29700fd1:	mov    QWORD PTR [r12+0x100],r13
    7a2a29700fd9:	mov    r11,QWORD PTR [rsp+0x48]
    7a2a29700fde:	mov    QWORD PTR [r12+0x398],r11
    7a2a29700fe6:	mov    rdi,QWORD PTR [r12+0x100]
    7a2a29700fee:	add    rsp,0x50
    7a2a29700ff2:	movabs r11,0x6284fe3820a0
    7a2a29700ffc:	jmp    r11
    7a2a29700fff:	mov    eax,0x41039c
    7a2a29701004:	mov    QWORD PTR [r12+0x100],rax
    7a2a2970100c:	push   rdx
    7a2a2970100d:	push   rsi
    7a2a2970100e:	push   r10
    7a2a29701010:	push   r11
    7a2a29701012:	pushf
    7a2a29701013:	pop    r11
    7a2a29701015:	mov    QWORD PTR [rsp+0x68],r11
    7a2a2970101a:	mov    rdx,QWORD PTR [rsp+0x68]
    7a2a2970101f:	mov    r10d,edx
    7a2a29701022:	and    r10d,0xc0
    7a2a29701029:	shl    r10d,0x18
    7a2a2970102d:	mov    r11d,edx
    7a2a29701030:	and    r11d,0x1
    7a2a29701034:	shl    r11d,0x1d
    7a2a29701038:	or     r10d,r11d
    7a2a2970103b:	mov    r11d,edx
    7a2a2970103e:	and    r11d,0x800
    7a2a29701045:	shl    r11d,0x11
    7a2a29701049:	or     r10d,r11d
    7a2a2970104c:	btc    r10,0x1d
    7a2a29701051:	mov    r11d,0xf0000000
    7a2a29701057:	and    r11,r10
    7a2a2970105a:	movabs rsi,0xffffffff0fffffff
    7a2a29701064:	and    rbx,rsi
    7a2a29701067:	or     rbx,r11
    7a2a2970106a:	pop    r11
    7a2a2970106c:	pop    r10
    7a2a2970106e:	pop    rsi
    7a2a2970106f:	pop    rdx
    7a2a29701070:	mov    QWORD PTR [r12+0x108],rbx
    7a2a29701078:	add    rsp,0x50
    7a2a2970107c:	mov    eax,0xc
    7a2a29701081:	movabs r11,0x6284fe382390
    7a2a2970108b:	jmp    r11
    7a2a2970108e:	mov    eax,0x410498
    7a2a29701093:	mov    QWORD PTR [r12+0x100],rax
    7a2a2970109b:	push   rdx
    7a2a2970109c:	push   rsi
    7a2a2970109d:	push   r10
    7a2a2970109f:	push   r11
    7a2a297010a1:	mov    rdx,QWORD PTR [rsp+0x68]
    7a2a297010a6:	mov    r10d,edx
    7a2a297010a9:	and    r10d,0xc0
    7a2a297010b0:	shl    r10d,0x18
    7a2a297010b4:	mov    r11d,edx
    7a2a297010b7:	and    r11d,0x1
    7a2a297010bb:	shl    r11d,0x1d
    7a2a297010bf:	or     r10d,r11d
    7a2a297010c2:	mov    r11d,edx
    7a2a297010c5:	and    r11d,0x800
    7a2a297010cc:	shl    r11d,0x11
    7a2a297010d0:	or     r10d,r11d
    7a2a297010d3:	btc    r10,0x1d
    7a2a297010d8:	mov    r11d,0xf0000000
    7a2a297010de:	and    r11,r10
    7a2a297010e1:	movabs rsi,0xffffffff0fffffff
    7a2a297010eb:	and    rbx,rsi
    7a2a297010ee:	or     rbx,r11
    7a2a297010f1:	pop    r11
    7a2a297010f3:	pop    r10
    7a2a297010f5:	pop    rsi
    7a2a297010f6:	pop    rdx
    7a2a297010f7:	mov    QWORD PTR [r12+0x108],rbx
    7a2a297010ff:	add    rsp,0x50
    7a2a29701103:	mov    eax,0xc
    7a2a29701108:	movabs r11,0x6284fe382390
    7a2a29701112:	jmp    r11
    7a2a29701115:	mov    eax,0x410558
    7a2a2970111a:	mov    QWORD PTR [r12+0x100],rax
    7a2a29701122:	push   rdx
    7a2a29701123:	push   rsi
    7a2a29701124:	push   r10
    7a2a29701126:	push   r11
    7a2a29701128:	mov    rdx,QWORD PTR [rsp+0x68]
    7a2a2970112d:	mov    r10d,edx
    7a2a29701130:	and    r10d,0xc0
    7a2a29701137:	shl    r10d,0x18
    7a2a2970113b:	mov    r11d,edx
    7a2a2970113e:	and    r11d,0x1
    7a2a29701142:	shl    r11d,0x1d
    7a2a29701146:	or     r10d,r11d
    7a2a29701149:	mov    r11d,edx
    7a2a2970114c:	and    r11d,0x800
    7a2a29701153:	shl    r11d,0x11
    7a2a29701157:	or     r10d,r11d
    7a2a2970115a:	btc    r10,0x1d
    7a2a2970115f:	mov    r11d,0xf0000000
    7a2a29701165:	and    r11,r10
    7a2a29701168:	movabs rsi,0xffffffff0fffffff
    7a2a29701172:	and    rbx,rsi
    7a2a29701175:	or     rbx,r11
    7a2a29701178:	pop    r11
    7a2a2970117a:	pop    r10
    7a2a2970117c:	pop    rsi
    7a2a2970117d:	pop    rdx
    7a2a2970117e:	mov    QWORD PTR [r12+0x108],rbx
    7a2a29701186:	add    rsp,0x50
    7a2a2970118a:	mov    eax,0xc
    7a2a2970118f:	movabs r11,0x6284fe382390
    7a2a29701199:	jmp    r11
    7a2a2970119c:	mov    eax,0x410594
    7a2a297011a1:	mov    QWORD PTR [r12+0x100],rax
    7a2a297011a9:	push   rdx
    7a2a297011aa:	push   rsi
    7a2a297011ab:	push   r10
    7a2a297011ad:	push   r11
    7a2a297011af:	mov    rdx,QWORD PTR [rsp+0x68]
    7a2a297011b4:	mov    r10d,edx
    7a2a297011b7:	and    r10d,0xc0
    7a2a297011be:	shl    r10d,0x18
    7a2a297011c2:	mov    r11d,edx
    7a2a297011c5:	and    r11d,0x1
    7a2a297011c9:	shl    r11d,0x1d
    7a2a297011cd:	or     r10d,r11d
    7a2a297011d0:	mov    r11d,edx
    7a2a297011d3:	and    r11d,0x800
    7a2a297011da:	shl    r11d,0x11
    7a2a297011de:	or     r10d,r11d
    7a2a297011e1:	btc    r10,0x1d
    7a2a297011e6:	mov    r11d,0xf0000000
    7a2a297011ec:	and    r11,r10
    7a2a297011ef:	movabs rsi,0xffffffff0fffffff
    7a2a297011f9:	and    rbx,rsi
    7a2a297011fc:	or     rbx,r11
    7a2a297011ff:	pop    r11
    7a2a29701201:	pop    r10
    7a2a29701203:	pop    rsi
    7a2a29701204:	pop    rdx
    7a2a29701205:	mov    QWORD PTR [r12+0x108],rbx
    7a2a2970120d:	add    rsp,0x50
    7a2a29701211:	mov    eax,0xc
    7a2a29701216:	movabs r11,0x6284fe382390
    7a2a29701220:	jmp    r11
    7a2a29701223:	mov    eax,0x4105b0
    7a2a29701228:	mov    QWORD PTR [r12+0x100],rax
    7a2a29701230:	push   rdx
    7a2a29701231:	push   rsi
    7a2a29701232:	push   r10
    7a2a29701234:	push   r11
    7a2a29701236:	mov    rdx,QWORD PTR [rsp+0x68]
    7a2a2970123b:	mov    r10d,edx
    7a2a2970123e:	and    r10d,0xc0
    7a2a29701245:	shl    r10d,0x18
    7a2a29701249:	mov    r11d,edx
    7a2a2970124c:	and    r11d,0x1
    7a2a29701250:	shl    r11d,0x1d
    7a2a29701254:	or     r10d,r11d
    7a2a29701257:	mov    r11d,edx
    7a2a2970125a:	and    r11d,0x800
    7a2a29701261:	shl    r11d,0x11
    7a2a29701265:	or     r10d,r11d
    7a2a29701268:	btc    r10,0x1d
    7a2a2970126d:	mov    r11d,0xf0000000
    7a2a29701273:	and    r11,r10
    7a2a29701276:	movabs rsi,0xffffffff0fffffff
    7a2a29701280:	and    rbx,rsi
    7a2a29701283:	or     rbx,r11
    7a2a29701286:	pop    r11
    7a2a29701288:	pop    r10
    7a2a2970128a:	pop    rsi
    7a2a2970128b:	pop    rdx
    7a2a2970128c:	mov    QWORD PTR [r12+0x108],rbx
    7a2a29701294:	add    rsp,0x50
    7a2a29701298:	mov    eax,0xc
    7a2a2970129d:	movabs r11,0x6284fe382390
    7a2a297012a7:	jmp    r11
    7a2a297012aa:	nop    WORD PTR [rax+rax*1+0x0]
    7a2a297012b0:	sub    rsp,0x50
    7a2a297012b4:	mov    r11,QWORD PTR [r12+0x398]
    7a2a297012bc:	mov    QWORD PTR [rsp+0x48],r11
    7a2a297012c1:	jmp    0x7a2a296fe84b
    7a2a297012c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a297012d0:	sub    rsp,0x50
    7a2a297012d4:	mov    r11,QWORD PTR [r12+0x398]
    7a2a297012dc:	mov    QWORD PTR [rsp+0x48],r11
    7a2a297012e1:	jmp    0x7a2a296fe9f7
    7a2a297012e6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a297012f0:	sub    rsp,0x50
    7a2a297012f4:	mov    r11,QWORD PTR [r12+0x398]
    7a2a297012fc:	mov    QWORD PTR [rsp+0x48],r11
    7a2a29701301:	jmp    0x7a2a296feaa1
    7a2a29701306:	data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a29701310:	sub    rsp,0x50
    7a2a29701314:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970131c:	mov    QWORD PTR [rsp+0x48],r11
    7a2a29701321:	jmp    0x7a2a297005bc
    7a2a29701326:	data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a29701330:	sub    rsp,0x50
    7a2a29701334:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970133c:	mov    QWORD PTR [rsp+0x48],r11
    7a2a29701341:	jmp    0x7a2a29700745
    7a2a29701346:	data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a29701350:	sub    rsp,0x50
    7a2a29701354:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970135c:	mov    QWORD PTR [rsp+0x48],r11
    7a2a29701361:	jmp    0x7a2a297008ca
    7a2a29701366:	data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a29701370:	sub    rsp,0x50
    7a2a29701374:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970137c:	mov    QWORD PTR [rsp+0x48],r11
    7a2a29701381:	jmp    0x7a2a29700cbf
    7a2a29701386:	data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a29701390:	sub    rsp,0x50
    7a2a29701394:	mov    r11,QWORD PTR [r12+0x398]
    7a2a2970139c:	mov    QWORD PTR [rsp+0x48],r11
    7a2a297013a1:	jmp    0x7a2a29700ea1
    7a2a297013a6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a297013b0:	sub    rsp,0x50
    7a2a297013b4:	mov    r11,QWORD PTR [r12+0x398]
    7a2a297013bc:	mov    QWORD PTR [rsp+0x48],r11
    7a2a297013c1:	jmp    0x7a2a29700ed5
    7a2a297013c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7a2a297013d0:	sub    rsp,0x50
    7a2a297013d4:	mov    r11,QWORD PTR [r12+0x398]
    7a2a297013dc:	mov    QWORD PTR [rsp+0x48],r11
    7a2a297013e1:	jmp    0x7a2a29700fba
    7a2a297013e6:	nop
    7a2a297013e7:	nop
