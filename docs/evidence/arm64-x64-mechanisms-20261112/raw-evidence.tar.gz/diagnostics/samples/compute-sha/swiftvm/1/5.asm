
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/1/5.bin:     file format binary


Disassembly of section .data:

00007c636a000a30 <.data>:
    7c636a000a30:	sub    rsp,0x20
    7c636a000a34:	mov    r11,QWORD PTR [r12+0x398]
    7c636a000a3c:	mov    QWORD PTR [rsp+0x18],r11
    7c636a000a41:	mov    r13,QWORD PTR [r12+0xf8]
    7c636a000a49:	mov    r14,r13
    7c636a000a4c:	add    r14,0x4
    7c636a000a50:	mov    r15d,DWORD PTR [r13+0x0]
    7c636a000a54:	mov    ebp,DWORD PTR [r14]
    7c636a000a57:	mov    QWORD PTR [r12+0x40],r15
    7c636a000a5c:	mov    QWORD PTR [r12+0x50],rbp
    7c636a000a61:	mov    r14,r13
    7c636a000a64:	add    r14,0x8
    7c636a000a68:	mov    r8,r14
    7c636a000a6b:	add    r8,0x4
    7c636a000a6f:	mov    r9d,DWORD PTR [r14]
    7c636a000a72:	mov    r14d,DWORD PTR [r8]
    7c636a000a75:	mov    QWORD PTR [r12+0x58],r9
    7c636a000a7a:	mov    QWORD PTR [r12+0x60],r14
    7c636a000a7f:	mov    r14d,0x430860
    7c636a000a85:	mov    QWORD PTR [r12+0x48],r14
    7c636a000a8a:	add    r13,0x80
    7c636a000a91:	mov    r14,QWORD PTR [r13+0x0]
    7c636a000a95:	mov    QWORD PTR [r12+0xf0],r14
    7c636a000a9d:	movabs rcx,0xff00ff00ff00ff
    7c636a000aa7:	mov    r13,r15
    7c636a000aaa:	and    r13,rcx
    7c636a000aad:	shl    r13,0x8
    7c636a000ab1:	movabs rcx,0xff00ff00ff00ff00
    7c636a000abb:	mov    r14,r15
    7c636a000abe:	and    r14,rcx
    7c636a000ac1:	shr    r14,0x8
    7c636a000ac5:	mov    rcx,r13
    7c636a000ac8:	or     r14,rcx
    7c636a000acb:	movabs rcx,0xffff0000ffff
    7c636a000ad5:	mov    r13,r14
    7c636a000ad8:	and    r13,rcx
    7c636a000adb:	shl    r13,0x10
    7c636a000adf:	movabs rcx,0xffff0000ffff0000
    7c636a000ae9:	and    r14,rcx
    7c636a000aec:	shr    r14,0x10
    7c636a000af0:	mov    rcx,r13
    7c636a000af3:	or     r14,rcx
    7c636a000af6:	mov    ecx,0xffffffff
    7c636a000afb:	and    r14,rcx
    7c636a000afe:	mov    QWORD PTR [r12+0x40],r14
    7c636a000b03:	movabs rcx,0xff00ff00ff00ff
    7c636a000b0d:	mov    r13,rbp
    7c636a000b10:	and    r13,rcx
    7c636a000b13:	shl    r13,0x8
    7c636a000b17:	movabs rcx,0xff00ff00ff00ff00
    7c636a000b21:	mov    r15,rbp
    7c636a000b24:	and    r15,rcx
    7c636a000b27:	shr    r15,0x8
    7c636a000b2b:	mov    rcx,r13
    7c636a000b2e:	or     r15,rcx
    7c636a000b31:	movabs rcx,0xffff0000ffff
    7c636a000b3b:	mov    r13,r15
    7c636a000b3e:	and    r13,rcx
    7c636a000b41:	shl    r13,0x10
    7c636a000b45:	movabs rcx,0xffff0000ffff0000
    7c636a000b4f:	and    r15,rcx
    7c636a000b52:	shr    r15,0x10
    7c636a000b56:	mov    rcx,r13
    7c636a000b59:	or     r15,rcx
    7c636a000b5c:	mov    ecx,0xffffffff
    7c636a000b61:	and    r15,rcx
    7c636a000b64:	mov    QWORD PTR [r12+0x50],r15
    7c636a000b69:	mov    r13d,0x430860
    7c636a000b6f:	mov    ebp,0x430864
    7c636a000b74:	mov    rax,r14
    7c636a000b77:	mov    eax,eax
    7c636a000b79:	mov    r8d,eax
    7c636a000b7c:	mov    rax,r15
    7c636a000b7f:	mov    eax,eax
    7c636a000b81:	mov    r14d,eax
    7c636a000b84:	mov    DWORD PTR [r13+0x0],r8d
    7c636a000b88:	mov    r13d,0x0
    7c636a000b8e:	mov    DWORD PTR [r12+0x32c],r13d
    7c636a000b96:	mov    DWORD PTR [rbp+0x0],r14d
    7c636a000b9a:	mov    r13d,0x0
    7c636a000ba0:	mov    DWORD PTR [r12+0x32c],r13d
    7c636a000ba8:	mov    r13d,DWORD PTR [r12+0x58]
    7c636a000bad:	movabs rcx,0xff00ff00ff00ff
    7c636a000bb7:	mov    r14,r13
    7c636a000bba:	and    r14,rcx
    7c636a000bbd:	shl    r14,0x8
    7c636a000bc1:	movabs rcx,0xff00ff00ff00ff00
    7c636a000bcb:	mov    r15,r13
    7c636a000bce:	and    r15,rcx
    7c636a000bd1:	shr    r15,0x8
    7c636a000bd5:	mov    rcx,r14
    7c636a000bd8:	or     r15,rcx
    7c636a000bdb:	movabs rcx,0xffff0000ffff
    7c636a000be5:	mov    r13,r15
    7c636a000be8:	and    r13,rcx
    7c636a000beb:	shl    r13,0x10
    7c636a000bef:	movabs rcx,0xffff0000ffff0000
    7c636a000bf9:	and    r15,rcx
    7c636a000bfc:	shr    r15,0x10
    7c636a000c00:	mov    rcx,r13
    7c636a000c03:	or     r15,rcx
    7c636a000c06:	mov    ecx,0xffffffff
    7c636a000c0b:	and    r15,rcx
    7c636a000c0e:	mov    QWORD PTR [r12+0x40],r15
    7c636a000c13:	mov    r13d,DWORD PTR [r12+0x60]
    7c636a000c18:	movabs rcx,0xff00ff00ff00ff
    7c636a000c22:	mov    r14,r13
    7c636a000c25:	and    r14,rcx
    7c636a000c28:	shl    r14,0x8
    7c636a000c2c:	movabs rcx,0xff00ff00ff00ff00
    7c636a000c36:	mov    rbp,r13
    7c636a000c39:	and    rbp,rcx
    7c636a000c3c:	shr    rbp,0x8
    7c636a000c40:	mov    rcx,r14
    7c636a000c43:	or     rbp,rcx
    7c636a000c46:	movabs rcx,0xffff0000ffff
    7c636a000c50:	mov    r13,rbp
    7c636a000c53:	and    r13,rcx
    7c636a000c56:	shl    r13,0x10
    7c636a000c5a:	movabs rcx,0xffff0000ffff0000
    7c636a000c64:	and    rbp,rcx
    7c636a000c67:	shr    rbp,0x10
    7c636a000c6b:	mov    rcx,r13
    7c636a000c6e:	or     rbp,rcx
    7c636a000c71:	mov    ecx,0xffffffff
    7c636a000c76:	and    rbp,rcx
    7c636a000c79:	mov    QWORD PTR [r12+0x58],rbp
    7c636a000c7e:	mov    r13,QWORD PTR [r12+0xf8]
    7c636a000c86:	mov    r14,r13
    7c636a000c89:	add    r14,0x10
    7c636a000c8d:	mov    r8,r14
    7c636a000c90:	add    r8,0x4
    7c636a000c94:	mov    eax,DWORD PTR [r14]
    7c636a000c97:	mov    QWORD PTR [rsp],rax
    7c636a000c9b:	mov    r14d,DWORD PTR [r8]
    7c636a000c9e:	mov    rax,QWORD PTR [rsp]
    7c636a000ca2:	mov    QWORD PTR [r12+0x50],rax
    7c636a000ca7:	mov    QWORD PTR [r12+0x60],r14
    7c636a000cac:	mov    r14,QWORD PTR [r12+0x48]
    7c636a000cb1:	add    r14,0x8
    7c636a000cb5:	mov    r8,r14
    7c636a000cb8:	add    r8,0x4
    7c636a000cbc:	mov    rax,r15
    7c636a000cbf:	mov    eax,eax
    7c636a000cc1:	mov    r9d,eax
    7c636a000cc4:	mov    rax,rbp
    7c636a000cc7:	mov    eax,eax
    7c636a000cc9:	mov    r15d,eax
    7c636a000ccc:	mov    DWORD PTR [r14],r9d
    7c636a000ccf:	mov    r14d,0x0
    7c636a000cd5:	mov    DWORD PTR [r12+0x32c],r14d
    7c636a000cdd:	mov    DWORD PTR [r8],r15d
    7c636a000ce0:	mov    r14d,0x0
    7c636a000ce6:	mov    DWORD PTR [r12+0x32c],r14d
    7c636a000cee:	add    r13,0x90
    7c636a000cf5:	mov    r14,r13
    7c636a000cf8:	add    r14,0x8
    7c636a000cfc:	mov    r15,QWORD PTR [r13+0x0]
    7c636a000d00:	mov    r13,QWORD PTR [r14]
    7c636a000d03:	mov    QWORD PTR [r12+0xa0],r15
    7c636a000d0b:	mov    QWORD PTR [r12+0x98],r13
    7c636a000d13:	movabs rcx,0xff00ff00ff00ff
    7c636a000d1d:	mov    r13,QWORD PTR [rsp]
    7c636a000d21:	and    r13,rcx
    7c636a000d24:	shl    r13,0x8
    7c636a000d28:	movabs rcx,0xff00ff00ff00ff00
    7c636a000d32:	mov    r14,QWORD PTR [rsp]
    7c636a000d36:	and    r14,rcx
    7c636a000d39:	shr    r14,0x8
    7c636a000d3d:	mov    rcx,r13
    7c636a000d40:	or     r14,rcx
    7c636a000d43:	movabs rcx,0xffff0000ffff
    7c636a000d4d:	mov    r13,r14
    7c636a000d50:	and    r13,rcx
    7c636a000d53:	shl    r13,0x10
    7c636a000d57:	movabs rcx,0xffff0000ffff0000
    7c636a000d61:	and    r14,rcx
    7c636a000d64:	shr    r14,0x10
    7c636a000d68:	mov    rcx,r13
    7c636a000d6b:	or     r14,rcx
    7c636a000d6e:	mov    ecx,0xffffffff
    7c636a000d73:	and    r14,rcx
    7c636a000d76:	mov    QWORD PTR [r12+0x40],r14
    7c636a000d7b:	mov    r13d,DWORD PTR [r12+0x60]
    7c636a000d80:	movabs rcx,0xff00ff00ff00ff
    7c636a000d8a:	mov    r15,r13
    7c636a000d8d:	and    r15,rcx
    7c636a000d90:	shl    r15,0x8
    7c636a000d94:	movabs rcx,0xff00ff00ff00ff00
    7c636a000d9e:	mov    rbp,r13
    7c636a000da1:	and    rbp,rcx
    7c636a000da4:	shr    rbp,0x8
    7c636a000da8:	mov    rcx,r15
    7c636a000dab:	or     rbp,rcx
    7c636a000dae:	movabs rcx,0xffff0000ffff
    7c636a000db8:	mov    r13,rbp
    7c636a000dbb:	and    r13,rcx
    7c636a000dbe:	shl    r13,0x10
    7c636a000dc2:	movabs rcx,0xffff0000ffff0000
    7c636a000dcc:	and    rbp,rcx
    7c636a000dcf:	shr    rbp,0x10
    7c636a000dd3:	mov    rcx,r13
    7c636a000dd6:	or     rbp,rcx
    7c636a000dd9:	mov    ecx,0xffffffff
    7c636a000dde:	and    rbp,rcx
    7c636a000de1:	mov    QWORD PTR [r12+0x58],rbp
    7c636a000de6:	mov    r13,QWORD PTR [r12+0xf8]
    7c636a000dee:	add    r13,0x18
    7c636a000df2:	mov    r15,r13
    7c636a000df5:	add    r15,0x4
    7c636a000df9:	mov    r8d,DWORD PTR [r13+0x0]
    7c636a000dfd:	mov    eax,DWORD PTR [r15]
    7c636a000e00:	mov    QWORD PTR [rsp+0x10],rax
    7c636a000e05:	mov    QWORD PTR [r12+0x50],r8
    7c636a000e0a:	mov    rax,QWORD PTR [rsp+0x10]
    7c636a000e0f:	mov    QWORD PTR [r12+0x60],rax
    7c636a000e14:	mov    rax,QWORD PTR [r12+0x48]
    7c636a000e19:	mov    QWORD PTR [rsp+0x8],rax
    7c636a000e1e:	mov    r9,QWORD PTR [rsp+0x8]
    7c636a000e23:	add    r9,0x10
    7c636a000e27:	mov    r15,r9
    7c636a000e2a:	add    r15,0x4
    7c636a000e2e:	mov    rax,r14
    7c636a000e31:	mov    eax,eax
    7c636a000e33:	mov    r13d,eax
    7c636a000e36:	mov    rax,rbp
    7c636a000e39:	mov    eax,eax
    7c636a000e3b:	mov    r14d,eax
    7c636a000e3e:	mov    DWORD PTR [r9],r13d
    7c636a000e41:	mov    r13d,0x0
    7c636a000e47:	mov    DWORD PTR [r12+0x32c],r13d
    7c636a000e4f:	mov    DWORD PTR [r15],r14d
    7c636a000e52:	mov    r13d,0x0
    7c636a000e58:	mov    DWORD PTR [r12+0x32c],r13d
    7c636a000e60:	movabs rcx,0xff00ff00ff00ff
    7c636a000e6a:	mov    r13,r8
    7c636a000e6d:	and    r13,rcx
    7c636a000e70:	shl    r13,0x8
    7c636a000e74:	movabs rcx,0xff00ff00ff00ff00
    7c636a000e7e:	mov    r14,r8
    7c636a000e81:	and    r14,rcx
    7c636a000e84:	shr    r14,0x8
    7c636a000e88:	mov    rcx,r13
    7c636a000e8b:	or     r14,rcx
    7c636a000e8e:	movabs rcx,0xffff0000ffff
    7c636a000e98:	mov    r13,r14
    7c636a000e9b:	and    r13,rcx
    7c636a000e9e:	shl    r13,0x10
    7c636a000ea2:	movabs rcx,0xffff0000ffff0000
    7c636a000eac:	and    r14,rcx
    7c636a000eaf:	shr    r14,0x10
    7c636a000eb3:	mov    rcx,r13
    7c636a000eb6:	or     r14,rcx
    7c636a000eb9:	mov    ecx,0xffffffff
    7c636a000ebe:	and    r14,rcx
    7c636a000ec1:	mov    QWORD PTR [r12+0x40],r14
    7c636a000ec6:	movabs rcx,0xff00ff00ff00ff
    7c636a000ed0:	mov    r13,QWORD PTR [rsp+0x10]
    7c636a000ed5:	and    r13,rcx
    7c636a000ed8:	shl    r13,0x8
    7c636a000edc:	movabs rcx,0xff00ff00ff00ff00
    7c636a000ee6:	mov    r15,QWORD PTR [rsp+0x10]
    7c636a000eeb:	and    r15,rcx
    7c636a000eee:	shr    r15,0x8
    7c636a000ef2:	mov    rcx,r13
    7c636a000ef5:	or     r15,rcx
    7c636a000ef8:	movabs rcx,0xffff0000ffff
    7c636a000f02:	mov    r13,r15
    7c636a000f05:	and    r13,rcx
    7c636a000f08:	shl    r13,0x10
    7c636a000f0c:	movabs rcx,0xffff0000ffff0000
    7c636a000f16:	and    r15,rcx
    7c636a000f19:	shr    r15,0x10
    7c636a000f1d:	mov    rcx,r13
    7c636a000f20:	or     r15,rcx
    7c636a000f23:	mov    ecx,0xffffffff
    7c636a000f28:	and    r15,rcx
    7c636a000f2b:	mov    QWORD PTR [r12+0x50],r15
    7c636a000f30:	mov    r13,QWORD PTR [rsp+0x8]
    7c636a000f35:	add    r13,0x18
    7c636a000f39:	mov    rbp,r13
    7c636a000f3c:	add    rbp,0x4
    7c636a000f40:	mov    rax,r14
    7c636a000f43:	mov    eax,eax
    7c636a000f45:	mov    r8d,eax
    7c636a000f48:	mov    rax,r15
    7c636a000f4b:	mov    eax,eax
    7c636a000f4d:	mov    r14d,eax
    7c636a000f50:	mov    DWORD PTR [r13+0x0],r8d
    7c636a000f54:	mov    r13d,0x0
    7c636a000f5a:	mov    DWORD PTR [r12+0x32c],r13d
    7c636a000f62:	mov    DWORD PTR [rbp+0x0],r14d
    7c636a000f66:	mov    r13d,0x0
    7c636a000f6c:	mov    DWORD PTR [r12+0x32c],r13d
    7c636a000f74:	mov    r13,QWORD PTR [r12+0xf8]
    7c636a000f7c:	add    r13,0xa0
    7c636a000f83:	mov    QWORD PTR [r12+0xf8],r13
    7c636a000f8b:	mov    rcx,QWORD PTR [r12+0x380]
    7c636a000f93:	jrcxz  0x7c636a000f9a
    7c636a000f95:	jmp    0x7c636a000fd0
    7c636a000f9a:	mov    r13,QWORD PTR [r12+0xf0]
    7c636a000fa2:	mov    QWORD PTR [r12+0x100],r13
    7c636a000faa:	mov    r11,QWORD PTR [rsp+0x18]
    7c636a000faf:	mov    QWORD PTR [r12+0x398],r11
    7c636a000fb7:	mov    rdi,QWORD PTR [r12+0x100]
    7c636a000fbf:	add    rsp,0x20
    7c636a000fc3:	movabs r11,0x59733cd1d0a0
    7c636a000fcd:	jmp    r11
    7c636a000fd0:	mov    eax,0x410334
    7c636a000fd5:	mov    QWORD PTR [r12+0x100],rax
    7c636a000fdd:	push   rdx
    7c636a000fde:	push   rsi
    7c636a000fdf:	push   r10
    7c636a000fe1:	push   r11
    7c636a000fe3:	mov    rdx,QWORD PTR [rsp+0x38]
    7c636a000fe8:	mov    r10d,edx
    7c636a000feb:	and    r10d,0xc0
    7c636a000ff2:	shl    r10d,0x18
    7c636a000ff6:	mov    r11d,edx
    7c636a000ff9:	and    r11d,0x1
    7c636a000ffd:	shl    r11d,0x1d
    7c636a001001:	or     r10d,r11d
    7c636a001004:	mov    r11d,edx
    7c636a001007:	and    r11d,0x800
    7c636a00100e:	shl    r11d,0x11
    7c636a001012:	or     r10d,r11d
    7c636a001015:	btc    r10,0x1d
    7c636a00101a:	mov    r11d,0xf0000000
    7c636a001020:	and    r11,r10
    7c636a001023:	movabs rsi,0xffffffff0fffffff
    7c636a00102d:	and    rbx,rsi
    7c636a001030:	or     rbx,r11
    7c636a001033:	pop    r11
    7c636a001035:	pop    r10
    7c636a001037:	pop    rsi
    7c636a001038:	pop    rdx
    7c636a001039:	mov    QWORD PTR [r12+0x108],rbx
    7c636a001041:	add    rsp,0x20
    7c636a001045:	mov    eax,0xc
    7c636a00104a:	movabs r11,0x59733cd1d390
    7c636a001054:	jmp    r11
    7c636a001057:	nop
