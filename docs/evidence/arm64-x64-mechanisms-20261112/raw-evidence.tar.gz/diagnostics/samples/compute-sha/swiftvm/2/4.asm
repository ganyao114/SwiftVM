
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/2/4.bin:     file format binary


Disassembly of section .data:

00007a2a297018b0 <.data>:
    7a2a297018b0:	sub    rsp,0x10
    7a2a297018b4:	mov    r11,QWORD PTR [r12+0x398]
    7a2a297018bc:	mov    QWORD PTR [rsp],r11
    7a2a297018c0:	mov    r13,QWORD PTR [r12+0xf8]
    7a2a297018c8:	add    r13,0x68
    7a2a297018cc:	mov    r14,QWORD PTR [r13+0x0]
    7a2a297018d0:	mov    QWORD PTR [r12+0x40],r14
    7a2a297018d5:	sub    r14,0x38
    7a2a297018d9:	mov    rcx,QWORD PTR [r12+0x380]
    7a2a297018e1:	jrcxz  0x7a2a297018e8
    7a2a297018e3:	jmp    0x7a2a2970199d
    7a2a297018e8:	pushf
    7a2a297018e9:	pop    r11
    7a2a297018eb:	mov    QWORD PTR [rsp],r11
    7a2a297018ef:	jne    0x7a2a2970194d
    7a2a297018f5:	jmp    0x7a2a297018fa
    7a2a297018fa:	mov    r13d,0x4102c4
    7a2a29701900:	mov    QWORD PTR [r12+0x100],r13
    7a2a29701908:	mov    r11,QWORD PTR [rsp]
    7a2a2970190c:	mov    QWORD PTR [r12+0x398],r11
    7a2a29701914:	mov    edi,0x4102c4
    7a2a29701919:	mov    QWORD PTR [r12+0x100],rdi
    7a2a29701921:	add    rsp,0x10
    7a2a29701925:	nop    DWORD PTR [rax]
    7a2a29701928:	jmp    QWORD PTR [rip+0x2]        # 0x7a2a29701930
    7a2a2970192e:	xchg   ax,ax
    7a2a29701930:	nop
    7a2a29701931:	sbb    BYTE PTR [rax+0x29],dh
    7a2a29701934:	sub    bh,BYTE PTR [rdx+0x0]
    7a2a29701937:	add    BYTE PTR [rax+0x19],al
    7a2a2970193a:	jo     0x7a2a29701965
    7a2a2970193c:	sub    bh,BYTE PTR [rdx+0x0]
    7a2a2970193f:	add    BYTE PTR [rcx-0x45],cl
    7a2a29701942:	movabs al,ds:0x4100006284fe3820
    7a2a2970194b:	jmp    rbx
    7a2a2970194d:	mov    r13d,0x4102a8
    7a2a29701953:	mov    QWORD PTR [r12+0x100],r13
    7a2a2970195b:	mov    r11,QWORD PTR [rsp]
    7a2a2970195f:	mov    QWORD PTR [r12+0x398],r11
    7a2a29701967:	mov    edi,0x4102a8
    7a2a2970196c:	mov    QWORD PTR [r12+0x100],rdi
    7a2a29701974:	add    rsp,0x10
    7a2a29701978:	jmp    QWORD PTR [rip+0x2]        # 0x7a2a29701980
    7a2a2970197e:	xchg   ax,ax
    7a2a29701980:	jo     0x7a2a2970199a
    7a2a29701982:	jo     0x7a2a297019ad
    7a2a29701984:	sub    bh,BYTE PTR [rdx+0x0]
    7a2a29701987:	add    BYTE PTR [rax+0x2a297019],dl
    7a2a2970198d:	jp     0x7a2a2970198f
    7a2a2970198f:	add    BYTE PTR [rcx-0x45],cl
    7a2a29701992:	movabs al,ds:0x4100006284fe3820
    7a2a2970199b:	jmp    rbx
    7a2a2970199d:	mov    eax,0x4102c0
    7a2a297019a2:	mov    QWORD PTR [r12+0x100],rax
    7a2a297019aa:	push   rdx
    7a2a297019ab:	push   rsi
    7a2a297019ac:	push   r10
    7a2a297019ae:	push   r11
    7a2a297019b0:	pushf
    7a2a297019b1:	pop    r11
    7a2a297019b3:	mov    QWORD PTR [rsp+0x20],r11
    7a2a297019b8:	mov    rdx,QWORD PTR [rsp+0x20]
    7a2a297019bd:	mov    r10d,edx
    7a2a297019c0:	and    r10d,0xc0
    7a2a297019c7:	shl    r10d,0x18
    7a2a297019cb:	mov    r11d,edx
    7a2a297019ce:	and    r11d,0x1
    7a2a297019d2:	shl    r11d,0x1d
    7a2a297019d6:	or     r10d,r11d
    7a2a297019d9:	mov    r11d,edx
    7a2a297019dc:	and    r11d,0x800
    7a2a297019e3:	shl    r11d,0x11
    7a2a297019e7:	or     r10d,r11d
    7a2a297019ea:	btc    r10,0x1d
    7a2a297019ef:	mov    r11d,0xf0000000
    7a2a297019f5:	and    r11,r10
    7a2a297019f8:	movabs rsi,0xffffffff0fffffff
    7a2a29701a02:	and    rbx,rsi
    7a2a29701a05:	or     rbx,r11
    7a2a29701a08:	pop    r11
    7a2a29701a0a:	pop    r10
    7a2a29701a0c:	pop    rsi
    7a2a29701a0d:	pop    rdx
    7a2a29701a0e:	mov    QWORD PTR [r12+0x108],rbx
    7a2a29701a16:	add    rsp,0x10
    7a2a29701a1a:	mov    eax,0xc
    7a2a29701a1f:	movabs r11,0x6284fe382390
    7a2a29701a29:	jmp    r11
