
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

00007017df7fd000 <.data>:
    7017df7fd000:	sub    rsp,0x10
    7017df7fd004:	mov    r11,QWORD PTR [r12+0x398]
    7017df7fd00c:	mov    QWORD PTR [rsp],r11
    7017df7fd010:	mov    r13,QWORD PTR [r12+0xf8]
    7017df7fd018:	sub    r13,0xa0
    7017df7fd01f:	mov    QWORD PTR [r12+0xf8],r13
    7017df7fd027:	mov    r14d,0x420000
    7017df7fd02d:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd032:	mov    r14d,0x420000
    7017df7fd038:	mov    QWORD PTR [r12+0x48],r14
    7017df7fd03d:	add    r13,0x90
    7017df7fd044:	mov    r14,r13
    7017df7fd047:	add    r14,0x8
    7017df7fd04b:	mov    r15,QWORD PTR [r12+0xa0]
    7017df7fd053:	mov    rbp,QWORD PTR [r12+0x98]
    7017df7fd05b:	mov    QWORD PTR [r13+0x0],r15
    7017df7fd05f:	mov    r13d,0x0
    7017df7fd065:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd06d:	mov    QWORD PTR [r14],rbp
    7017df7fd070:	mov    r13d,0x0
    7017df7fd076:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd07e:	mov    r13d,0x420670
    7017df7fd084:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7017df7fd08a:	movdqa xmm0,xmm2
    7017df7fd08e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7017df7fd098:	mov    r13d,0x420000
    7017df7fd09e:	mov    QWORD PTR [r12+0x40],r13
    7017df7fd0a3:	mov    r13d,0x420610
    7017df7fd0a9:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7017df7fd0af:	movdqa xmm0,xmm3
    7017df7fd0b3:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7017df7fd0bd:	mov    r13d,0x420000
    7017df7fd0c3:	mov    QWORD PTR [r12+0x48],r13
    7017df7fd0c8:	mov    r13d,0x420690
    7017df7fd0ce:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    7017df7fd0d4:	movdqa xmm0,xmm4
    7017df7fd0d8:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7fd0e2:	mov    r13d,0x420000
    7017df7fd0e8:	mov    QWORD PTR [r12+0x40],r13
    7017df7fd0ed:	mov    r13d,0x420630
    7017df7fd0f3:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7017df7fd0f9:	movdqa xmm0,xmm5
    7017df7fd0fd:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7017df7fd107:	mov    r13d,0x430000
    7017df7fd10d:	add    r13,0x8a0
    7017df7fd114:	mov    QWORD PTR [r12+0x98],r13
    7017df7fd11c:	mov    r14,QWORD PTR [r12+0x40]
    7017df7fd121:	add    r14,0x6a0
    7017df7fd128:	movdqu xmm6,XMMWORD PTR [r14]
    7017df7fd12d:	movdqa xmm0,xmm6
    7017df7fd131:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7017df7fd13b:	mov    r14d,0x420000
    7017df7fd141:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd146:	mov    r14,r13
    7017df7fd149:	add    r14,0x10
    7017df7fd14d:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7017df7fd153:	mov    r15d,0x0
    7017df7fd159:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7fd161:	movdqu XMMWORD PTR [r14],xmm3
    7017df7fd166:	mov    r14d,0x0
    7017df7fd16c:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd174:	mov    r14,r13
    7017df7fd177:	add    r14,0x20
    7017df7fd17b:	mov    r15,r14
    7017df7fd17e:	add    r15,0x10
    7017df7fd182:	movdqu XMMWORD PTR [r14],xmm4
    7017df7fd187:	mov    r14d,0x0
    7017df7fd18d:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd195:	movdqu XMMWORD PTR [r15],xmm5
    7017df7fd19a:	mov    r14d,0x0
    7017df7fd1a0:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd1a8:	mov    r14d,0x420600
    7017df7fd1ae:	movdqu xmm4,XMMWORD PTR [r14]
    7017df7fd1b3:	movdqa xmm0,xmm4
    7017df7fd1b7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7fd1c1:	mov    r14d,0x420000
    7017df7fd1c7:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd1cc:	mov    r14d,0x4205f0
    7017df7fd1d2:	movdqu xmm5,XMMWORD PTR [r14]
    7017df7fd1d7:	movdqa xmm0,xmm5
    7017df7fd1db:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7017df7fd1e5:	mov    r14d,0x420000
    7017df7fd1eb:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd1f0:	mov    r14,r13
    7017df7fd1f3:	add    r14,0x100
    7017df7fd1fa:	mov    r15,r14
    7017df7fd1fd:	add    r15,0x10
    7017df7fd201:	movdqu XMMWORD PTR [r14],xmm2
    7017df7fd206:	mov    r14d,0x0
    7017df7fd20c:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd214:	movdqu XMMWORD PTR [r15],xmm3
    7017df7fd219:	mov    r14d,0x0
    7017df7fd21f:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd227:	add    r13,0x40
    7017df7fd22b:	mov    r14,r13
    7017df7fd22e:	add    r14,0x10
    7017df7fd232:	movdqu XMMWORD PTR [r13+0x0],xmm6
    7017df7fd238:	mov    r13d,0x0
    7017df7fd23e:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd246:	movdqu XMMWORD PTR [r14],xmm4
    7017df7fd24b:	mov    r13d,0x0
    7017df7fd251:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd259:	mov    r13d,0x4205e0
    7017df7fd25f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7017df7fd265:	movdqa xmm0,xmm2
    7017df7fd269:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7fd273:	mov    r13d,0x420000
    7017df7fd279:	mov    QWORD PTR [r12+0x40],r13
    7017df7fd27e:	mov    r13d,0x420640
    7017df7fd284:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7017df7fd28a:	movdqa xmm0,xmm3
    7017df7fd28e:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7017df7fd298:	mov    r13d,0x420000
    7017df7fd29e:	mov    QWORD PTR [r12+0x40],r13
    7017df7fd2a3:	mov    r13d,0xf8d3
    7017df7fd2a9:	mov    QWORD PTR [r12+0x48],r13
    7017df7fd2ae:	mov    r13,QWORD PTR [r12+0x98]
    7017df7fd2b6:	mov    r14,r13
    7017df7fd2b9:	add    r14,0x60
    7017df7fd2bd:	mov    r15,r14
    7017df7fd2c0:	add    r15,0x10
    7017df7fd2c4:	movdqu XMMWORD PTR [r14],xmm5
    7017df7fd2c9:	mov    r14d,0x0
    7017df7fd2cf:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd2d7:	movdqu XMMWORD PTR [r15],xmm2
    7017df7fd2dc:	mov    r14d,0x0
    7017df7fd2e2:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd2ea:	mov    r14d,0x420650
    7017df7fd2f0:	movdqu xmm2,XMMWORD PTR [r14]
    7017df7fd2f5:	movdqa xmm0,xmm2
    7017df7fd2f9:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7fd303:	mov    r14d,0x420000
    7017df7fd309:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd30e:	mov    r14d,0x420620
    7017df7fd314:	movdqu xmm2,XMMWORD PTR [r14]
    7017df7fd319:	movdqa xmm0,xmm2
    7017df7fd31d:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7017df7fd327:	mov    r14d,0x420000
    7017df7fd32d:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd332:	mov    r14d,0xf8d3
    7017df7fd338:	mov    r15d,0x421d
    7017df7fd33e:	and    r15d,0xffff
    7017df7fd345:	mov    rax,r14
    7017df7fd348:	movabs rcx,0xffffffff0000ffff
    7017df7fd352:	and    rax,rcx
    7017df7fd355:	mov    rdx,r15
    7017df7fd358:	shl    rdx,0x10
    7017df7fd35c:	mov    ecx,0xffff0000
    7017df7fd361:	and    rdx,rcx
    7017df7fd364:	or     rax,rdx
    7017df7fd367:	mov    ebp,eax
    7017df7fd369:	mov    QWORD PTR [r12+0x48],rbp
    7017df7fd36e:	mov    r14,r13
    7017df7fd371:	add    r14,0x80
    7017df7fd378:	mov    r15,r14
    7017df7fd37b:	add    r15,0x10
    7017df7fd37f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7017df7fd389:	movdqa xmm2,xmm0
    7017df7fd38d:	movdqu XMMWORD PTR [r14],xmm3
    7017df7fd392:	mov    r14d,0x0
    7017df7fd398:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd3a0:	movdqu XMMWORD PTR [r15],xmm2
    7017df7fd3a5:	mov    r14d,0x0
    7017df7fd3ab:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd3b3:	mov    r14d,0x4206c0
    7017df7fd3b9:	movdqu xmm2,XMMWORD PTR [r14]
    7017df7fd3be:	movdqa xmm0,xmm2
    7017df7fd3c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7fd3cc:	mov    r14d,0x420000
    7017df7fd3d2:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd3d7:	mov    r14d,0x4206d0
    7017df7fd3dd:	movdqu xmm3,XMMWORD PTR [r14]
    7017df7fd3e2:	movdqa xmm0,xmm3
    7017df7fd3e6:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7017df7fd3f0:	mov    r14d,0x420000
    7017df7fd3f6:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd3fb:	mov    r14d,0x3e8
    7017df7fd401:	mov    QWORD PTR [r12+0xa0],r14
    7017df7fd409:	add    r13,0xa0
    7017df7fd410:	mov    r14,r13
    7017df7fd413:	add    r14,0x10
    7017df7fd417:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7017df7fd421:	movdqa xmm3,xmm0
    7017df7fd425:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7017df7fd42b:	mov    r13d,0x0
    7017df7fd431:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd439:	movdqu XMMWORD PTR [r14],xmm2
    7017df7fd43e:	mov    r13d,0x0
    7017df7fd444:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd44c:	mov    r13,QWORD PTR [r12+0x40]
    7017df7fd451:	add    r13,0x6b0
    7017df7fd458:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7017df7fd45e:	movdqa xmm0,xmm2
    7017df7fd462:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7fd46c:	mov    r13d,0x420000
    7017df7fd472:	mov    QWORD PTR [r12+0x40],r13
    7017df7fd477:	mov    r13d,0x420660
    7017df7fd47d:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7017df7fd483:	movdqa xmm0,xmm2
    7017df7fd487:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7017df7fd491:	mov    r13d,0x420000
    7017df7fd497:	mov    QWORD PTR [r12+0x40],r13
    7017df7fd49c:	mov    r13,QWORD PTR [r12+0xf8]
    7017df7fd4a4:	add    r13,0x80
    7017df7fd4ab:	mov    r14,QWORD PTR [r12+0xf0]
    7017df7fd4b3:	mov    QWORD PTR [r13+0x0],r14
    7017df7fd4b7:	mov    r13d,0x0
    7017df7fd4bd:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd4c5:	mov    r13,QWORD PTR [r12+0x98]
    7017df7fd4cd:	mov    r14,r13
    7017df7fd4d0:	add    r14,0xc0
    7017df7fd4d7:	mov    r15,r14
    7017df7fd4da:	add    r15,0x10
    7017df7fd4de:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7017df7fd4e8:	movdqa xmm2,xmm0
    7017df7fd4ec:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7017df7fd4f6:	movdqa xmm3,xmm0
    7017df7fd4fa:	movdqu XMMWORD PTR [r14],xmm2
    7017df7fd4ff:	mov    r14d,0x0
    7017df7fd505:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd50d:	movdqu XMMWORD PTR [r15],xmm3
    7017df7fd512:	mov    r14d,0x0
    7017df7fd518:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd520:	mov    r14d,0x420680
    7017df7fd526:	movdqu xmm2,XMMWORD PTR [r14]
    7017df7fd52b:	movdqa xmm0,xmm2
    7017df7fd52f:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7fd539:	mov    r14d,0x420000
    7017df7fd53f:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd544:	mov    r14d,0x4206e0
    7017df7fd54a:	mov    r15,QWORD PTR [r14]
    7017df7fd54d:	mov    r14d,0x0
    7017df7fd553:	mov    QWORD PTR [r12+0x110],r15
    7017df7fd55b:	mov    QWORD PTR [r12+0x118],r14
    7017df7fd563:	mov    r14d,0x4206e8
    7017df7fd569:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd56e:	mov    r14,r13
    7017df7fd571:	add    r14,0xe0
    7017df7fd578:	mov    rbp,r14
    7017df7fd57b:	add    rbp,0x10
    7017df7fd57f:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7017df7fd589:	movdqa xmm3,xmm0
    7017df7fd58d:	movdqu XMMWORD PTR [r14],xmm3
    7017df7fd592:	mov    r14d,0x0
    7017df7fd598:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd5a0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7017df7fd5a5:	mov    r14d,0x0
    7017df7fd5ab:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd5b3:	mov    r14d,0x420748
    7017df7fd5b9:	movdqu xmm2,XMMWORD PTR [r14]
    7017df7fd5be:	movdqa xmm0,xmm2
    7017df7fd5c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7fd5cc:	add    r13,0x120
    7017df7fd5d3:	mov    QWORD PTR [r13+0x0],r15
    7017df7fd5d7:	mov    r13d,0x0
    7017df7fd5dd:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd5e5:	mov    r13d,0x420728
    7017df7fd5eb:	mov    r14d,0x420738
    7017df7fd5f1:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7017df7fd5f7:	movdqu xmm4,XMMWORD PTR [r14]
    7017df7fd5fc:	movdqa xmm0,xmm3
    7017df7fd600:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7017df7fd60a:	movdqa xmm0,xmm4
    7017df7fd60e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7017df7fd618:	mov    r13,QWORD PTR [r12+0xf8]
    7017df7fd620:	mov    r14,r13
    7017df7fd623:	add    r14,0x60
    7017df7fd627:	movdqu XMMWORD PTR [r14],xmm2
    7017df7fd62c:	mov    r14d,0x0
    7017df7fd632:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd63a:	mov    r14,QWORD PTR [r12+0x98]
    7017df7fd642:	mov    r15,r14
    7017df7fd645:	add    r15,0x128
    7017df7fd64c:	mov    ebp,DWORD PTR [r12+0x48]
    7017df7fd651:	mov    DWORD PTR [r15],ebp
    7017df7fd654:	mov    r15d,0x0
    7017df7fd65a:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7fd662:	mov    r15,r13
    7017df7fd665:	add    r15,0x40
    7017df7fd669:	mov    rbp,r15
    7017df7fd66c:	add    rbp,0x10
    7017df7fd670:	movdqu XMMWORD PTR [r15],xmm3
    7017df7fd675:	mov    r15d,0x0
    7017df7fd67b:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7fd683:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    7017df7fd688:	mov    r15d,0x0
    7017df7fd68e:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7fd696:	mov    r15d,0x4206e8
    7017df7fd69c:	mov    ebp,0x4206f8
    7017df7fd6a1:	movdqu xmm2,XMMWORD PTR [r15]
    7017df7fd6a6:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7017df7fd6ab:	movdqa xmm0,xmm2
    7017df7fd6af:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7017df7fd6b9:	movdqa xmm0,xmm3
    7017df7fd6bd:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7017df7fd6c7:	mov    r15,r13
    7017df7fd6ca:	add    r15,0x10
    7017df7fd6ce:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7017df7fd6d4:	mov    ebp,0x0
    7017df7fd6d9:	mov    DWORD PTR [r12+0x32c],ebp
    7017df7fd6e1:	movdqu XMMWORD PTR [r15],xmm3
    7017df7fd6e6:	mov    r15d,0x0
    7017df7fd6ec:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7fd6f4:	mov    r15d,0x420708
    7017df7fd6fa:	mov    ebp,0x420718
    7017df7fd6ff:	movdqu xmm2,XMMWORD PTR [r15]
    7017df7fd704:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7017df7fd709:	movdqa xmm0,xmm2
    7017df7fd70d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7017df7fd717:	movdqa xmm0,xmm3
    7017df7fd71b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7fd725:	mov    r15,r13
    7017df7fd728:	add    r15,0x20
    7017df7fd72c:	mov    rbp,r15
    7017df7fd72f:	add    rbp,0x10
    7017df7fd733:	movdqu XMMWORD PTR [r15],xmm2
    7017df7fd738:	mov    r15d,0x0
    7017df7fd73e:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7fd746:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7017df7fd74b:	mov    r15d,0x0
    7017df7fd751:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7fd759:	add    r13,0x0
    7017df7fd75d:	mov    QWORD PTR [r12],r13
    7017df7fd761:	mov    r13d,0x0
    7017df7fd767:	mov    rcx,r14
    7017df7fd76a:	or     r13,rcx
    7017df7fd76d:	mov    QWORD PTR [r12+0x8],r13
    7017df7fd772:	mov    r13d,0x12c
    7017df7fd778:	mov    QWORD PTR [r12+0x10],r13
    7017df7fd77d:	mov    r13d,0x410274
    7017df7fd783:	mov    QWORD PTR [r12+0xf0],r13
    7017df7fd78b:	mov    r13d,0x410338
    7017df7fd791:	mov    QWORD PTR [r12+0x100],r13
    7017df7fd799:	mov    r11,QWORD PTR [rsp]
    7017df7fd79d:	mov    QWORD PTR [r12+0x398],r11
    7017df7fd7a5:	mov    edi,0x410338
    7017df7fd7aa:	mov    QWORD PTR [r12+0x100],rdi
    7017df7fd7b2:	add    rsp,0x10
    7017df7fd7b6:	xchg   ax,ax
    7017df7fd7b8:	jmp    QWORD PTR [rip+0x2]        # 0x7017df7fd7c0
    7017df7fd7be:	xchg   ax,ax
    7017df7fd7c0:	loopne 0x7017df7fd799
    7017df7fd7c2:	jg     0x7017df7fd7a3
    7017df7fd7c4:	(bad)
    7017df7fd7c5:	jo     0x7017df7fd7c7
    7017df7fd7c7:	add    al,dl
    7017df7fd7c9:	xlat   BYTE PTR ds:[rbx]
    7017df7fd7ca:	jg     0x7017df7fd7ab
    7017df7fd7cc:	(bad)
    7017df7fd7cd:	jo     0x7017df7fd7cf
    7017df7fd7cf:	add    BYTE PTR [rcx-0x45],cl
    7017df7fd7d2:	movabs al,ds:0x4100005dba7c1c00
    7017df7fd7db:	jmp    rbx
    7017df7fd7dd:	nop
    7017df7fd7de:	nop
    7017df7fd7df:	nop
