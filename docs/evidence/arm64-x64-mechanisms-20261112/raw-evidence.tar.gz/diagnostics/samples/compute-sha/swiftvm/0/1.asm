
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/0/1.bin:     file format binary


Disassembly of section .data:

00007017df7fd7e0 <.data>:
    7017df7fd7e0:	sub    rsp,0x50
    7017df7fd7e4:	mov    r11,QWORD PTR [r12+0x398]
    7017df7fd7ec:	mov    QWORD PTR [rsp+0x48],r11
    7017df7fd7f1:	mov    r13,QWORD PTR [r12]
    7017df7fd7f5:	mov    r14,r13
    7017df7fd7f8:	add    r14,0x20
    7017df7fd7fc:	mov    r15,QWORD PTR [r14]
    7017df7fd7ff:	mov    r14,QWORD PTR [r12+0x10]
    7017df7fd804:	mov    rcx,r14
    7017df7fd807:	add    r15,rcx
    7017df7fd80a:	mov    QWORD PTR [r12+0x40],r15
    7017df7fd80f:	add    r13,0x20
    7017df7fd813:	mov    QWORD PTR [r13+0x0],r15
    7017df7fd817:	mov    r13d,0x0
    7017df7fd81d:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd825:	mov    rax,r14
    7017df7fd828:	test   rax,rax
    7017df7fd82b:	sete   al
    7017df7fd82e:	movzx  eax,al
    7017df7fd831:	and    eax,0x1
    7017df7fd834:	mov    r13,rax
    7017df7fd837:	mov    rax,r13
    7017df7fd83a:	and    eax,0x1
    7017df7fd83d:	test   rax,rax
    7017df7fd840:	jne    0x7017df7fffba
    7017df7fd846:	jmp    0x7017df7fd84b
    7017df7fd84b:	mov    r13,QWORD PTR [r12+0xf8]
    7017df7fd853:	sub    r13,0x150
    7017df7fd85a:	mov    QWORD PTR [r12+0xf8],r13
    7017df7fd862:	mov    r14,QWORD PTR [r12]
    7017df7fd866:	mov    r15,r14
    7017df7fd869:	add    r15,0x68
    7017df7fd86d:	mov    rbp,QWORD PTR [r15]
    7017df7fd870:	mov    QWORD PTR [r12+0x88],rbp
    7017df7fd878:	add    r14,0x28
    7017df7fd87c:	mov    QWORD PTR [r12+0x40],r14
    7017df7fd881:	mov    r14,r13
    7017df7fd884:	add    r14,0x0
    7017df7fd888:	mov    QWORD PTR [r12+0x48],r14
    7017df7fd88d:	mov    r14d,0x420000
    7017df7fd893:	add    r14,0x758
    7017df7fd89a:	mov    QWORD PTR [r12+0x50],r14
    7017df7fd89f:	add    r13,0x100
    7017df7fd8a6:	mov    r14,r13
    7017df7fd8a9:	add    r14,0x8
    7017df7fd8ad:	mov    r15,QWORD PTR [r12+0xe8]
    7017df7fd8b5:	mov    rbp,QWORD PTR [r12+0xd8]
    7017df7fd8bd:	mov    QWORD PTR [r13+0x0],r15
    7017df7fd8c1:	mov    r13d,0x0
    7017df7fd8c7:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd8cf:	mov    QWORD PTR [r14],rbp
    7017df7fd8d2:	mov    r13d,0x0
    7017df7fd8d8:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd8e0:	mov    r13,QWORD PTR [r12+0xf8]
    7017df7fd8e8:	mov    r14,r13
    7017df7fd8eb:	add    r14,0x110
    7017df7fd8f2:	mov    r15,r14
    7017df7fd8f5:	add    r15,0x8
    7017df7fd8f9:	mov    rbp,QWORD PTR [r12+0xd0]
    7017df7fd901:	mov    r8,QWORD PTR [r12+0xc8]
    7017df7fd909:	mov    QWORD PTR [r14],rbp
    7017df7fd90c:	mov    r14d,0x0
    7017df7fd912:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd91a:	mov    QWORD PTR [r15],r8
    7017df7fd91d:	mov    r14d,0x0
    7017df7fd923:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd92b:	mov    r14,r13
    7017df7fd92e:	add    r14,0x120
    7017df7fd935:	mov    r15,r14
    7017df7fd938:	add    r15,0x8
    7017df7fd93c:	mov    rbp,QWORD PTR [r12+0xc0]
    7017df7fd944:	mov    r8,QWORD PTR [r12+0xb8]
    7017df7fd94c:	mov    QWORD PTR [r14],rbp
    7017df7fd94f:	mov    r14d,0x0
    7017df7fd955:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd95d:	mov    QWORD PTR [r15],r8
    7017df7fd960:	mov    r14d,0x0
    7017df7fd966:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd96e:	mov    r14,r13
    7017df7fd971:	add    r14,0x130
    7017df7fd978:	mov    r15,r14
    7017df7fd97b:	add    r15,0x8
    7017df7fd97f:	mov    rbp,QWORD PTR [r12+0xb0]
    7017df7fd987:	mov    r8,QWORD PTR [r12+0xa8]
    7017df7fd98f:	mov    QWORD PTR [r14],rbp
    7017df7fd992:	mov    r14d,0x0
    7017df7fd998:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd9a0:	mov    QWORD PTR [r15],r8
    7017df7fd9a3:	mov    r14d,0x0
    7017df7fd9a9:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fd9b1:	add    r13,0x140
    7017df7fd9b8:	mov    r14,r13
    7017df7fd9bb:	add    r14,0x8
    7017df7fd9bf:	mov    r15,QWORD PTR [r12+0xa0]
    7017df7fd9c7:	mov    rbp,QWORD PTR [r12+0x98]
    7017df7fd9cf:	mov    QWORD PTR [r13+0x0],r15
    7017df7fd9d3:	mov    r13d,0x0
    7017df7fd9d9:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd9e1:	mov    QWORD PTR [r14],rbp
    7017df7fd9e4:	mov    r13d,0x0
    7017df7fd9ea:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fd9f2:	jmp    0x7017df7fd9f7
    7017df7fd9f7:	mov    r13,QWORD PTR [r12+0x8]
    7017df7fd9fc:	mov    r14,r13
    7017df7fd9ff:	add    r14,0x1
    7017df7fda03:	movzx  r15d,BYTE PTR [r13+0x0]
    7017df7fda08:	mov    QWORD PTR [r12+0x58],r15
    7017df7fda0d:	mov    QWORD PTR [r12+0x8],r14
    7017df7fda12:	mov    r13,QWORD PTR [r12+0x88]
    7017df7fda1a:	mov    r14,r13
    7017df7fda1d:	add    r14,0x1
    7017df7fda21:	mov    QWORD PTR [r12+0x60],r14
    7017df7fda26:	mov    r15,QWORD PTR [r12]
    7017df7fda2a:	mov    rbp,r15
    7017df7fda2d:	add    rbp,0x68
    7017df7fda31:	mov    QWORD PTR [rbp+0x0],r14
    7017df7fda35:	mov    r14d,0x0
    7017df7fda3b:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7fda43:	mov    rcx,r13
    7017df7fda46:	mov    r14,r15
    7017df7fda49:	add    r14,rcx
    7017df7fda4c:	mov    QWORD PTR [r12+0x60],r14
    7017df7fda51:	add    r14,0x28
    7017df7fda55:	movzx  r13d,BYTE PTR [r12+0x58]
    7017df7fda5b:	mov    BYTE PTR [r14],r13b
    7017df7fda5e:	mov    r13d,0x0
    7017df7fda64:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7fda6c:	add    r15,0x68
    7017df7fda70:	mov    r13,QWORD PTR [r15]
    7017df7fda73:	mov    QWORD PTR [r12+0x88],r13
    7017df7fda7b:	sub    r13,0x40
    7017df7fda7f:	mov    rcx,QWORD PTR [r12+0x380]
    7017df7fda87:	jrcxz  0x7017df7fda8e
    7017df7fda89:	jmp    0x7017df7fffff
    7017df7fda8e:	pushf
    7017df7fda8f:	pop    r11
    7017df7fda91:	mov    QWORD PTR [rsp+0x48],r11
    7017df7fda96:	jne    0x7017df7ffea1
    7017df7fda9c:	jmp    0x7017df7fdaa1
    7017df7fdaa1:	mov    rax,QWORD PTR [r12+0x40]
    7017df7fdaa6:	mov    QWORD PTR [rsp],rax
    7017df7fdaaa:	mov    eax,0x0
    7017df7fdaaf:	mov    QWORD PTR [rsp+0x20],rax
    7017df7fdab4:	mov    eax,0x0
    7017df7fdab9:	mov    QWORD PTR [rsp+0x18],rax
    7017df7fdabe:	mov    eax,0x0
    7017df7fdac3:	mov    QWORD PTR [rsp+0x10],rax
    7017df7fdac8:	mov    eax,0x0
    7017df7fdacd:	mov    QWORD PTR [rsp+0x8],rax
    7017df7fdad2:	mov    rdi,QWORD PTR [rsp]
    7017df7fdad6:	movzx  r9d,BYTE PTR [rdi]
    7017df7fdada:	mov    r13,r9
    7017df7fdadd:	mov    rcx,r13
    7017df7fdae0:	mov    r9,QWORD PTR [rsp+0x20]
    7017df7fdae5:	or     r9,rcx
    7017df7fdae8:	mov    r13,QWORD PTR [rsp]
    7017df7fdaec:	add    r13,0x1
    7017df7fdaf0:	movzx  r8d,BYTE PTR [r13+0x0]
    7017df7fdaf5:	mov    r13,r8
    7017df7fdaf8:	mov    rcx,r13
    7017df7fdafb:	mov    r8,QWORD PTR [rsp+0x18]
    7017df7fdb00:	or     r8,rcx
    7017df7fdb03:	mov    r13,QWORD PTR [rsp]
    7017df7fdb07:	add    r13,0x2
    7017df7fdb0b:	movzx  ebp,BYTE PTR [r13+0x0]
    7017df7fdb10:	mov    r13,rbp
    7017df7fdb13:	mov    rcx,r13
    7017df7fdb16:	mov    rbp,QWORD PTR [rsp+0x10]
    7017df7fdb1b:	or     rbp,rcx
    7017df7fdb1e:	mov    r13,QWORD PTR [rsp]
    7017df7fdb22:	add    r13,0x3
    7017df7fdb26:	movzx  r15d,BYTE PTR [r13+0x0]
    7017df7fdb2b:	mov    r13,r15
    7017df7fdb2e:	mov    rcx,r13
    7017df7fdb31:	mov    r15,QWORD PTR [rsp+0x8]
    7017df7fdb36:	or     r15,rcx
    7017df7fdb39:	mov    r13,QWORD PTR [rsp]
    7017df7fdb3d:	add    r13,0x4
    7017df7fdb41:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdb46:	mov    r13,r14
    7017df7fdb49:	shl    r13,0x8
    7017df7fdb4d:	mov    rcx,r13
    7017df7fdb50:	or     r9,rcx
    7017df7fdb53:	mov    r13,QWORD PTR [rsp]
    7017df7fdb57:	add    r13,0x5
    7017df7fdb5b:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdb60:	mov    r13,r14
    7017df7fdb63:	shl    r13,0x8
    7017df7fdb67:	mov    rcx,r13
    7017df7fdb6a:	or     r8,rcx
    7017df7fdb6d:	mov    r13,QWORD PTR [rsp]
    7017df7fdb71:	add    r13,0x6
    7017df7fdb75:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdb7a:	mov    r13,r14
    7017df7fdb7d:	shl    r13,0x8
    7017df7fdb81:	mov    rcx,r13
    7017df7fdb84:	or     rbp,rcx
    7017df7fdb87:	mov    r13,QWORD PTR [rsp]
    7017df7fdb8b:	add    r13,0x7
    7017df7fdb8f:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdb94:	mov    r13,r14
    7017df7fdb97:	shl    r13,0x8
    7017df7fdb9b:	mov    rcx,r13
    7017df7fdb9e:	or     r15,rcx
    7017df7fdba1:	mov    r13,QWORD PTR [rsp]
    7017df7fdba5:	add    r13,0x8
    7017df7fdba9:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdbae:	mov    r13,r14
    7017df7fdbb1:	shl    r13,0x10
    7017df7fdbb5:	mov    rcx,r13
    7017df7fdbb8:	or     r9,rcx
    7017df7fdbbb:	mov    r13,QWORD PTR [rsp]
    7017df7fdbbf:	add    r13,0x9
    7017df7fdbc3:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdbc8:	mov    r13,r14
    7017df7fdbcb:	shl    r13,0x10
    7017df7fdbcf:	mov    rcx,r13
    7017df7fdbd2:	or     r8,rcx
    7017df7fdbd5:	mov    r13,QWORD PTR [rsp]
    7017df7fdbd9:	add    r13,0xa
    7017df7fdbdd:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdbe2:	mov    r13,r14
    7017df7fdbe5:	shl    r13,0x10
    7017df7fdbe9:	mov    rcx,r13
    7017df7fdbec:	or     rbp,rcx
    7017df7fdbef:	mov    r13,QWORD PTR [rsp]
    7017df7fdbf3:	add    r13,0xb
    7017df7fdbf7:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdbfc:	mov    r13,r14
    7017df7fdbff:	shl    r13,0x10
    7017df7fdc03:	mov    rcx,r13
    7017df7fdc06:	or     r15,rcx
    7017df7fdc09:	mov    r13,QWORD PTR [rsp]
    7017df7fdc0d:	add    r13,0xc
    7017df7fdc11:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdc16:	mov    r13,r14
    7017df7fdc19:	shl    r13,0x18
    7017df7fdc1d:	mov    rcx,r13
    7017df7fdc20:	or     r9,rcx
    7017df7fdc23:	mov    r13,QWORD PTR [rsp]
    7017df7fdc27:	add    r13,0xd
    7017df7fdc2b:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdc30:	mov    r13,r14
    7017df7fdc33:	shl    r13,0x18
    7017df7fdc37:	mov    rcx,r13
    7017df7fdc3a:	or     r8,rcx
    7017df7fdc3d:	mov    r13,QWORD PTR [rsp]
    7017df7fdc41:	add    r13,0xe
    7017df7fdc45:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdc4a:	mov    r13,r14
    7017df7fdc4d:	shl    r13,0x18
    7017df7fdc51:	mov    rcx,r13
    7017df7fdc54:	or     rbp,rcx
    7017df7fdc57:	mov    r13,QWORD PTR [rsp]
    7017df7fdc5b:	add    r13,0xf
    7017df7fdc5f:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdc64:	mov    r13,r14
    7017df7fdc67:	shl    r13,0x18
    7017df7fdc6b:	mov    rcx,r13
    7017df7fdc6e:	or     r15,rcx
    7017df7fdc71:	mov    r13,QWORD PTR [rsp]
    7017df7fdc75:	add    r13,0x10
    7017df7fdc79:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdc7e:	mov    r13,r14
    7017df7fdc81:	shl    r13,0x20
    7017df7fdc85:	mov    rcx,r13
    7017df7fdc88:	or     r9,rcx
    7017df7fdc8b:	mov    r13,QWORD PTR [rsp]
    7017df7fdc8f:	add    r13,0x11
    7017df7fdc93:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdc98:	mov    r13,r14
    7017df7fdc9b:	shl    r13,0x20
    7017df7fdc9f:	mov    rcx,r13
    7017df7fdca2:	or     r8,rcx
    7017df7fdca5:	mov    r13,QWORD PTR [rsp]
    7017df7fdca9:	add    r13,0x12
    7017df7fdcad:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdcb2:	mov    r13,r14
    7017df7fdcb5:	shl    r13,0x20
    7017df7fdcb9:	mov    rcx,r13
    7017df7fdcbc:	or     rbp,rcx
    7017df7fdcbf:	mov    r13,QWORD PTR [rsp]
    7017df7fdcc3:	add    r13,0x13
    7017df7fdcc7:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdccc:	mov    r13,r14
    7017df7fdccf:	shl    r13,0x20
    7017df7fdcd3:	mov    rcx,r13
    7017df7fdcd6:	or     r15,rcx
    7017df7fdcd9:	mov    r13,QWORD PTR [rsp]
    7017df7fdcdd:	add    r13,0x14
    7017df7fdce1:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdce6:	mov    r13,r14
    7017df7fdce9:	shl    r13,0x28
    7017df7fdced:	mov    rcx,r13
    7017df7fdcf0:	or     r9,rcx
    7017df7fdcf3:	mov    r13,QWORD PTR [rsp]
    7017df7fdcf7:	add    r13,0x15
    7017df7fdcfb:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdd00:	mov    r13,r14
    7017df7fdd03:	shl    r13,0x28
    7017df7fdd07:	mov    rcx,r13
    7017df7fdd0a:	or     r8,rcx
    7017df7fdd0d:	mov    r13,QWORD PTR [rsp]
    7017df7fdd11:	add    r13,0x16
    7017df7fdd15:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdd1a:	mov    r13,r14
    7017df7fdd1d:	shl    r13,0x28
    7017df7fdd21:	mov    rcx,r13
    7017df7fdd24:	or     rbp,rcx
    7017df7fdd27:	mov    r13,QWORD PTR [rsp]
    7017df7fdd2b:	add    r13,0x17
    7017df7fdd2f:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdd34:	mov    r13,r14
    7017df7fdd37:	shl    r13,0x28
    7017df7fdd3b:	mov    rcx,r13
    7017df7fdd3e:	or     r15,rcx
    7017df7fdd41:	mov    r13,QWORD PTR [rsp]
    7017df7fdd45:	add    r13,0x18
    7017df7fdd49:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdd4e:	mov    r13,r14
    7017df7fdd51:	shl    r13,0x30
    7017df7fdd55:	mov    rcx,r13
    7017df7fdd58:	or     r9,rcx
    7017df7fdd5b:	mov    r13,QWORD PTR [rsp]
    7017df7fdd5f:	add    r13,0x19
    7017df7fdd63:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdd68:	mov    r13,r14
    7017df7fdd6b:	shl    r13,0x30
    7017df7fdd6f:	mov    rcx,r13
    7017df7fdd72:	or     r8,rcx
    7017df7fdd75:	mov    r13,QWORD PTR [rsp]
    7017df7fdd79:	add    r13,0x1a
    7017df7fdd7d:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdd82:	mov    r13,r14
    7017df7fdd85:	shl    r13,0x30
    7017df7fdd89:	mov    rcx,r13
    7017df7fdd8c:	or     rbp,rcx
    7017df7fdd8f:	mov    r13,QWORD PTR [rsp]
    7017df7fdd93:	add    r13,0x1b
    7017df7fdd97:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fdd9c:	mov    r13,r14
    7017df7fdd9f:	shl    r13,0x30
    7017df7fdda3:	mov    rcx,r13
    7017df7fdda6:	or     r15,rcx
    7017df7fdda9:	mov    r13,QWORD PTR [rsp]
    7017df7fddad:	add    r13,0x1c
    7017df7fddb1:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fddb6:	mov    r13,r14
    7017df7fddb9:	shl    r13,0x38
    7017df7fddbd:	mov    rcx,r13
    7017df7fddc0:	mov    rax,r9
    7017df7fddc3:	or     rax,rcx
    7017df7fddc6:	mov    QWORD PTR [rsp+0x40],rax
    7017df7fddcb:	mov    r13,QWORD PTR [rsp]
    7017df7fddcf:	add    r13,0x1d
    7017df7fddd3:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fddd8:	mov    r13,r14
    7017df7fdddb:	shl    r13,0x38
    7017df7fdddf:	mov    rcx,r13
    7017df7fdde2:	mov    rax,r8
    7017df7fdde5:	or     rax,rcx
    7017df7fdde8:	mov    QWORD PTR [rsp+0x30],rax
    7017df7fdded:	mov    r13,QWORD PTR [rsp]
    7017df7fddf1:	add    r13,0x1e
    7017df7fddf5:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fddfa:	mov    r13,r14
    7017df7fddfd:	shl    r13,0x38
    7017df7fde01:	mov    rcx,r13
    7017df7fde04:	mov    rax,rbp
    7017df7fde07:	or     rax,rcx
    7017df7fde0a:	mov    QWORD PTR [rsp+0x28],rax
    7017df7fde0f:	mov    r13,QWORD PTR [rsp]
    7017df7fde13:	add    r13,0x1f
    7017df7fde17:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fde1c:	mov    r13,r14
    7017df7fde1f:	shl    r13,0x38
    7017df7fde23:	mov    rcx,r13
    7017df7fde26:	mov    rax,r15
    7017df7fde29:	or     rax,rcx
    7017df7fde2c:	mov    QWORD PTR [rsp+0x38],rax
    7017df7fde31:	mov    r13,QWORD PTR [rsp]
    7017df7fde35:	add    r13,0x20
    7017df7fde39:	movzx  r14d,BYTE PTR [r13+0x0]
    7017df7fde3e:	mov    r13,r14
    7017df7fde41:	mov    rcx,r13
    7017df7fde44:	mov    r14,QWORD PTR [rsp+0x20]
    7017df7fde49:	or     r14,rcx
    7017df7fde4c:	mov    r13,QWORD PTR [rsp]
    7017df7fde50:	add    r13,0x21
    7017df7fde54:	movzx  ebp,BYTE PTR [r13+0x0]
    7017df7fde59:	mov    r13,rbp
    7017df7fde5c:	mov    rcx,r13
    7017df7fde5f:	mov    rbp,QWORD PTR [rsp+0x18]
    7017df7fde64:	or     rbp,rcx
    7017df7fde67:	mov    r13,QWORD PTR [rsp]
    7017df7fde6b:	add    r13,0x22
    7017df7fde6f:	movzx  r8d,BYTE PTR [r13+0x0]
    7017df7fde74:	mov    r13,r8
    7017df7fde77:	mov    rcx,r13
    7017df7fde7a:	mov    r8,QWORD PTR [rsp+0x10]
    7017df7fde7f:	or     r8,rcx
    7017df7fde82:	mov    r13,QWORD PTR [rsp]
    7017df7fde86:	add    r13,0x23
    7017df7fde8a:	movzx  r15d,BYTE PTR [r13+0x0]
    7017df7fde8f:	mov    r13,r15
    7017df7fde92:	mov    rcx,r13
    7017df7fde95:	mov    r15,QWORD PTR [rsp+0x8]
    7017df7fde9a:	or     r15,rcx
    7017df7fde9d:	mov    r13,QWORD PTR [rsp]
    7017df7fdea1:	add    r13,0x24
    7017df7fdea5:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdeaa:	mov    r13,r9
    7017df7fdead:	shl    r13,0x8
    7017df7fdeb1:	mov    rcx,r13
    7017df7fdeb4:	or     r14,rcx
    7017df7fdeb7:	mov    r13,QWORD PTR [rsp]
    7017df7fdebb:	add    r13,0x25
    7017df7fdebf:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdec4:	mov    r13,r9
    7017df7fdec7:	shl    r13,0x8
    7017df7fdecb:	mov    rcx,r13
    7017df7fdece:	or     rbp,rcx
    7017df7fded1:	mov    r13,QWORD PTR [rsp]
    7017df7fded5:	add    r13,0x26
    7017df7fded9:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdede:	mov    r13,r9
    7017df7fdee1:	shl    r13,0x8
    7017df7fdee5:	mov    rcx,r13
    7017df7fdee8:	or     r8,rcx
    7017df7fdeeb:	mov    r13,QWORD PTR [rsp]
    7017df7fdeef:	add    r13,0x27
    7017df7fdef3:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdef8:	mov    r13,r9
    7017df7fdefb:	shl    r13,0x8
    7017df7fdeff:	mov    rcx,r13
    7017df7fdf02:	or     r15,rcx
    7017df7fdf05:	mov    r13,QWORD PTR [rsp]
    7017df7fdf09:	add    r13,0x28
    7017df7fdf0d:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdf12:	mov    r13,r9
    7017df7fdf15:	shl    r13,0x10
    7017df7fdf19:	mov    rcx,r13
    7017df7fdf1c:	or     r14,rcx
    7017df7fdf1f:	mov    r13,QWORD PTR [rsp]
    7017df7fdf23:	add    r13,0x29
    7017df7fdf27:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdf2c:	mov    r13,r9
    7017df7fdf2f:	shl    r13,0x10
    7017df7fdf33:	mov    rcx,r13
    7017df7fdf36:	or     rbp,rcx
    7017df7fdf39:	mov    r13,QWORD PTR [rsp]
    7017df7fdf3d:	add    r13,0x2a
    7017df7fdf41:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdf46:	mov    r13,r9
    7017df7fdf49:	shl    r13,0x10
    7017df7fdf4d:	mov    rcx,r13
    7017df7fdf50:	or     r8,rcx
    7017df7fdf53:	mov    r13,QWORD PTR [rsp]
    7017df7fdf57:	add    r13,0x2b
    7017df7fdf5b:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdf60:	mov    r13,r9
    7017df7fdf63:	shl    r13,0x10
    7017df7fdf67:	mov    rcx,r13
    7017df7fdf6a:	or     r15,rcx
    7017df7fdf6d:	mov    r13,QWORD PTR [rsp]
    7017df7fdf71:	add    r13,0x2c
    7017df7fdf75:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdf7a:	mov    r13,r9
    7017df7fdf7d:	shl    r13,0x18
    7017df7fdf81:	mov    rcx,r13
    7017df7fdf84:	or     r14,rcx
    7017df7fdf87:	mov    r13,QWORD PTR [rsp]
    7017df7fdf8b:	add    r13,0x2d
    7017df7fdf8f:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdf94:	mov    r13,r9
    7017df7fdf97:	shl    r13,0x18
    7017df7fdf9b:	mov    rcx,r13
    7017df7fdf9e:	or     rbp,rcx
    7017df7fdfa1:	mov    r13,QWORD PTR [rsp]
    7017df7fdfa5:	add    r13,0x2e
    7017df7fdfa9:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdfae:	mov    r13,r9
    7017df7fdfb1:	shl    r13,0x18
    7017df7fdfb5:	mov    rcx,r13
    7017df7fdfb8:	or     r8,rcx
    7017df7fdfbb:	mov    r13,QWORD PTR [rsp]
    7017df7fdfbf:	add    r13,0x2f
    7017df7fdfc3:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdfc8:	mov    r13,r9
    7017df7fdfcb:	shl    r13,0x18
    7017df7fdfcf:	mov    rcx,r13
    7017df7fdfd2:	or     r15,rcx
    7017df7fdfd5:	mov    r13,QWORD PTR [rsp]
    7017df7fdfd9:	add    r13,0x30
    7017df7fdfdd:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdfe2:	mov    r13,r9
    7017df7fdfe5:	shl    r13,0x20
    7017df7fdfe9:	mov    rcx,r13
    7017df7fdfec:	or     r14,rcx
    7017df7fdfef:	mov    r13,QWORD PTR [rsp]
    7017df7fdff3:	add    r13,0x31
    7017df7fdff7:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fdffc:	mov    r13,r9
    7017df7fdfff:	shl    r13,0x20
    7017df7fe003:	mov    rcx,r13
    7017df7fe006:	or     rbp,rcx
    7017df7fe009:	mov    r13,QWORD PTR [rsp]
    7017df7fe00d:	add    r13,0x32
    7017df7fe011:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe016:	mov    r13,r9
    7017df7fe019:	shl    r13,0x20
    7017df7fe01d:	mov    rcx,r13
    7017df7fe020:	or     r8,rcx
    7017df7fe023:	mov    r13,QWORD PTR [rsp]
    7017df7fe027:	add    r13,0x33
    7017df7fe02b:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe030:	mov    r13,r9
    7017df7fe033:	shl    r13,0x20
    7017df7fe037:	mov    rcx,r13
    7017df7fe03a:	or     r15,rcx
    7017df7fe03d:	mov    r13,QWORD PTR [rsp]
    7017df7fe041:	add    r13,0x34
    7017df7fe045:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe04a:	mov    r13,r9
    7017df7fe04d:	shl    r13,0x28
    7017df7fe051:	mov    rcx,r13
    7017df7fe054:	or     r14,rcx
    7017df7fe057:	mov    r13,QWORD PTR [rsp]
    7017df7fe05b:	add    r13,0x35
    7017df7fe05f:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe064:	mov    r13,r9
    7017df7fe067:	shl    r13,0x28
    7017df7fe06b:	mov    rcx,r13
    7017df7fe06e:	or     rbp,rcx
    7017df7fe071:	mov    r13,QWORD PTR [rsp]
    7017df7fe075:	add    r13,0x36
    7017df7fe079:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe07e:	mov    r13,r9
    7017df7fe081:	shl    r13,0x28
    7017df7fe085:	mov    rcx,r13
    7017df7fe088:	or     r8,rcx
    7017df7fe08b:	mov    r13,QWORD PTR [rsp]
    7017df7fe08f:	add    r13,0x37
    7017df7fe093:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe098:	mov    r13,r9
    7017df7fe09b:	shl    r13,0x28
    7017df7fe09f:	mov    rcx,r13
    7017df7fe0a2:	or     r15,rcx
    7017df7fe0a5:	mov    r13,QWORD PTR [rsp]
    7017df7fe0a9:	add    r13,0x38
    7017df7fe0ad:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe0b2:	mov    r13,r9
    7017df7fe0b5:	shl    r13,0x30
    7017df7fe0b9:	mov    rcx,r13
    7017df7fe0bc:	or     r14,rcx
    7017df7fe0bf:	mov    r13,QWORD PTR [rsp]
    7017df7fe0c3:	add    r13,0x39
    7017df7fe0c7:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe0cc:	mov    r13,r9
    7017df7fe0cf:	shl    r13,0x30
    7017df7fe0d3:	mov    rcx,r13
    7017df7fe0d6:	or     rbp,rcx
    7017df7fe0d9:	mov    r13,QWORD PTR [rsp]
    7017df7fe0dd:	add    r13,0x3a
    7017df7fe0e1:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe0e6:	mov    r13,r9
    7017df7fe0e9:	shl    r13,0x30
    7017df7fe0ed:	mov    rcx,r13
    7017df7fe0f0:	or     r8,rcx
    7017df7fe0f3:	mov    r13,QWORD PTR [rsp]
    7017df7fe0f7:	add    r13,0x3b
    7017df7fe0fb:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe100:	mov    r13,r9
    7017df7fe103:	shl    r13,0x30
    7017df7fe107:	mov    rcx,r13
    7017df7fe10a:	or     r15,rcx
    7017df7fe10d:	mov    r13,QWORD PTR [rsp]
    7017df7fe111:	add    r13,0x3c
    7017df7fe115:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe11a:	mov    r13,r9
    7017df7fe11d:	shl    r13,0x38
    7017df7fe121:	mov    rcx,r13
    7017df7fe124:	or     r14,rcx
    7017df7fe127:	mov    r13,QWORD PTR [rsp]
    7017df7fe12b:	add    r13,0x3d
    7017df7fe12f:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe134:	mov    r13,r9
    7017df7fe137:	shl    r13,0x38
    7017df7fe13b:	mov    rcx,r13
    7017df7fe13e:	or     rbp,rcx
    7017df7fe141:	mov    r13,QWORD PTR [rsp]
    7017df7fe145:	add    r13,0x3e
    7017df7fe149:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe14e:	mov    r13,r9
    7017df7fe151:	shl    r13,0x38
    7017df7fe155:	mov    rcx,r13
    7017df7fe158:	or     r8,rcx
    7017df7fe15b:	mov    r13,QWORD PTR [rsp]
    7017df7fe15f:	add    r13,0x3f
    7017df7fe163:	movzx  r9d,BYTE PTR [r13+0x0]
    7017df7fe168:	mov    r13,r9
    7017df7fe16b:	shl    r13,0x38
    7017df7fe16f:	mov    rcx,r13
    7017df7fe172:	or     r15,rcx
    7017df7fe175:	mov    rax,QWORD PTR [rsp+0x40]
    7017df7fe17a:	mov    QWORD PTR [r12+0x110],rax
    7017df7fe182:	mov    QWORD PTR [r12+0x118],r14
    7017df7fe18a:	mov    rax,QWORD PTR [rsp+0x30]
    7017df7fe18f:	mov    QWORD PTR [r12+0x120],rax
    7017df7fe197:	mov    QWORD PTR [r12+0x128],rbp
    7017df7fe19f:	mov    rax,QWORD PTR [rsp+0x28]
    7017df7fe1a4:	mov    QWORD PTR [r12+0x130],rax
    7017df7fe1ac:	mov    QWORD PTR [r12+0x138],r8
    7017df7fe1b4:	mov    rax,QWORD PTR [rsp+0x38]
    7017df7fe1b9:	mov    QWORD PTR [r12+0x140],rax
    7017df7fe1c1:	mov    QWORD PTR [r12+0x148],r15
    7017df7fe1c9:	mov    r13d,0x0
    7017df7fe1cf:	mov    QWORD PTR [r12+0x58],r13
    7017df7fe1d4:	mov    r13d,0x0
    7017df7fe1da:	mov    r14,QWORD PTR [rsp+0x30]
    7017df7fe1df:	and    r14,0xff
    7017df7fe1e6:	and    r14,0xffff
    7017df7fe1ed:	mov    rcx,r14
    7017df7fe1f0:	mov    r15,r13
    7017df7fe1f3:	or     r15,rcx
    7017df7fe1f6:	mov    r14,QWORD PTR [rsp+0x30]
    7017df7fe1fb:	shr    r14,0x8
    7017df7fe1ff:	and    r14,0xff
    7017df7fe206:	and    r14,0xffff
    7017df7fe20d:	shl    r14,0x10
    7017df7fe211:	mov    rcx,r14
    7017df7fe214:	or     r15,rcx
    7017df7fe217:	mov    r14,QWORD PTR [rsp+0x30]
    7017df7fe21c:	shr    r14,0x10
    7017df7fe220:	and    r14,0xff
    7017df7fe227:	and    r14,0xffff
    7017df7fe22e:	shl    r14,0x20
    7017df7fe232:	mov    rcx,r14
    7017df7fe235:	or     r15,rcx
    7017df7fe238:	mov    r14,QWORD PTR [rsp+0x30]
    7017df7fe23d:	shr    r14,0x18
    7017df7fe241:	and    r14,0xff
    7017df7fe248:	and    r14,0xffff
    7017df7fe24f:	shl    r14,0x30
    7017df7fe253:	mov    rcx,r14
    7017df7fe256:	or     r15,rcx
    7017df7fe259:	mov    r14,QWORD PTR [rsp+0x30]
    7017df7fe25e:	shr    r14,0x20
    7017df7fe262:	and    r14,0xff
    7017df7fe269:	and    r14,0xffff
    7017df7fe270:	mov    rcx,r14
    7017df7fe273:	or     r13,rcx
    7017df7fe276:	mov    r14,QWORD PTR [rsp+0x30]
    7017df7fe27b:	shr    r14,0x28
    7017df7fe27f:	and    r14,0xff
    7017df7fe286:	and    r14,0xffff
    7017df7fe28d:	shl    r14,0x10
    7017df7fe291:	mov    rcx,r14
    7017df7fe294:	or     r13,rcx
    7017df7fe297:	mov    r14,QWORD PTR [rsp+0x30]
    7017df7fe29c:	shr    r14,0x30
    7017df7fe2a0:	and    r14,0xff
    7017df7fe2a7:	and    r14,0xffff
    7017df7fe2ae:	shl    r14,0x20
    7017df7fe2b2:	mov    rcx,r14
    7017df7fe2b5:	or     r13,rcx
    7017df7fe2b8:	mov    r14,QWORD PTR [rsp+0x30]
    7017df7fe2bd:	shr    r14,0x38
    7017df7fe2c1:	and    r14,0xff
    7017df7fe2c8:	and    r14,0xffff
    7017df7fe2cf:	shl    r14,0x30
    7017df7fe2d3:	mov    rcx,r14
    7017df7fe2d6:	or     r13,rcx
    7017df7fe2d9:	mov    QWORD PTR [r12+0x150],r15
    7017df7fe2e1:	mov    QWORD PTR [r12+0x158],r13
    7017df7fe2e9:	mov    r13d,0x0
    7017df7fe2ef:	mov    r14,QWORD PTR [rsp+0x28]
    7017df7fe2f4:	and    r14,0xff
    7017df7fe2fb:	and    r14,0xffff
    7017df7fe302:	mov    rcx,r14
    7017df7fe305:	mov    r15,r13
    7017df7fe308:	or     r15,rcx
    7017df7fe30b:	mov    r14,QWORD PTR [rsp+0x28]
    7017df7fe310:	shr    r14,0x8
    7017df7fe314:	and    r14,0xff
    7017df7fe31b:	and    r14,0xffff
    7017df7fe322:	shl    r14,0x10
    7017df7fe326:	mov    rcx,r14
    7017df7fe329:	or     r15,rcx
    7017df7fe32c:	mov    r14,QWORD PTR [rsp+0x28]
    7017df7fe331:	shr    r14,0x10
    7017df7fe335:	and    r14,0xff
    7017df7fe33c:	and    r14,0xffff
    7017df7fe343:	shl    r14,0x20
    7017df7fe347:	mov    rcx,r14
    7017df7fe34a:	or     r15,rcx
    7017df7fe34d:	mov    r14,QWORD PTR [rsp+0x28]
    7017df7fe352:	shr    r14,0x18
    7017df7fe356:	and    r14,0xff
    7017df7fe35d:	and    r14,0xffff
    7017df7fe364:	shl    r14,0x30
    7017df7fe368:	mov    rcx,r14
    7017df7fe36b:	or     r15,rcx
    7017df7fe36e:	mov    r14,QWORD PTR [rsp+0x28]
    7017df7fe373:	shr    r14,0x20
    7017df7fe377:	and    r14,0xff
    7017df7fe37e:	and    r14,0xffff
    7017df7fe385:	mov    rcx,r14
    7017df7fe388:	or     r13,rcx
    7017df7fe38b:	mov    r14,QWORD PTR [rsp+0x28]
    7017df7fe390:	shr    r14,0x28
    7017df7fe394:	and    r14,0xff
    7017df7fe39b:	and    r14,0xffff
    7017df7fe3a2:	shl    r14,0x10
    7017df7fe3a6:	mov    rcx,r14
    7017df7fe3a9:	or     r13,rcx
    7017df7fe3ac:	mov    r14,QWORD PTR [rsp+0x28]
    7017df7fe3b1:	shr    r14,0x30
    7017df7fe3b5:	and    r14,0xff
    7017df7fe3bc:	and    r14,0xffff
    7017df7fe3c3:	shl    r14,0x20
    7017df7fe3c7:	mov    rcx,r14
    7017df7fe3ca:	or     r13,rcx
    7017df7fe3cd:	mov    r14,QWORD PTR [rsp+0x28]
    7017df7fe3d2:	shr    r14,0x38
    7017df7fe3d6:	and    r14,0xff
    7017df7fe3dd:	and    r14,0xffff
    7017df7fe3e4:	shl    r14,0x30
    7017df7fe3e8:	mov    rcx,r14
    7017df7fe3eb:	or     r13,rcx
    7017df7fe3ee:	mov    QWORD PTR [r12+0x160],r15
    7017df7fe3f6:	mov    QWORD PTR [r12+0x168],r13
    7017df7fe3fe:	mov    r13,QWORD PTR [r12+0x110]
    7017df7fe406:	mov    r14d,0x0
    7017df7fe40c:	mov    r15,r13
    7017df7fe40f:	and    r15,0xff
    7017df7fe416:	and    r15,0xffff
    7017df7fe41d:	mov    rcx,r15
    7017df7fe420:	mov    rbp,r14
    7017df7fe423:	or     rbp,rcx
    7017df7fe426:	mov    r15,r13
    7017df7fe429:	shr    r15,0x8
    7017df7fe42d:	and    r15,0xff
    7017df7fe434:	and    r15,0xffff
    7017df7fe43b:	shl    r15,0x10
    7017df7fe43f:	mov    rcx,r15
    7017df7fe442:	or     rbp,rcx
    7017df7fe445:	mov    r15,r13
    7017df7fe448:	shr    r15,0x10
    7017df7fe44c:	and    r15,0xff
    7017df7fe453:	and    r15,0xffff
    7017df7fe45a:	shl    r15,0x20
    7017df7fe45e:	mov    rcx,r15
    7017df7fe461:	or     rbp,rcx
    7017df7fe464:	mov    r15,r13
    7017df7fe467:	shr    r15,0x18
    7017df7fe46b:	and    r15,0xff
    7017df7fe472:	and    r15,0xffff
    7017df7fe479:	shl    r15,0x30
    7017df7fe47d:	mov    rcx,r15
    7017df7fe480:	or     rbp,rcx
    7017df7fe483:	mov    r15,r13
    7017df7fe486:	shr    r15,0x20
    7017df7fe48a:	and    r15,0xff
    7017df7fe491:	and    r15,0xffff
    7017df7fe498:	mov    rcx,r15
    7017df7fe49b:	or     r14,rcx
    7017df7fe49e:	mov    r15,r13
    7017df7fe4a1:	shr    r15,0x28
    7017df7fe4a5:	and    r15,0xff
    7017df7fe4ac:	and    r15,0xffff
    7017df7fe4b3:	shl    r15,0x10
    7017df7fe4b7:	mov    rcx,r15
    7017df7fe4ba:	or     r14,rcx
    7017df7fe4bd:	mov    r15,r13
    7017df7fe4c0:	shr    r15,0x30
    7017df7fe4c4:	and    r15,0xff
    7017df7fe4cb:	and    r15,0xffff
    7017df7fe4d2:	shl    r15,0x20
    7017df7fe4d6:	mov    rcx,r15
    7017df7fe4d9:	or     r14,rcx
    7017df7fe4dc:	shr    r13,0x38
    7017df7fe4e0:	and    r13,0xff
    7017df7fe4e7:	and    r13,0xffff
    7017df7fe4ee:	shl    r13,0x30
    7017df7fe4f2:	mov    rcx,r13
    7017df7fe4f5:	or     r14,rcx
    7017df7fe4f8:	mov    QWORD PTR [r12+0x170],rbp
    7017df7fe500:	mov    QWORD PTR [r12+0x178],r14
    7017df7fe508:	mov    r13,QWORD PTR [r12+0x118]
    7017df7fe510:	mov    r14d,0x0
    7017df7fe516:	mov    r15,r13
    7017df7fe519:	and    r15,0xff
    7017df7fe520:	and    r15,0xffff
    7017df7fe527:	mov    rcx,r15
    7017df7fe52a:	mov    rbp,r14
    7017df7fe52d:	or     rbp,rcx
    7017df7fe530:	mov    r15,r13
    7017df7fe533:	shr    r15,0x8
    7017df7fe537:	and    r15,0xff
    7017df7fe53e:	and    r15,0xffff
    7017df7fe545:	shl    r15,0x10
    7017df7fe549:	mov    rcx,r15
    7017df7fe54c:	or     rbp,rcx
    7017df7fe54f:	mov    r15,r13
    7017df7fe552:	shr    r15,0x10
    7017df7fe556:	and    r15,0xff
    7017df7fe55d:	and    r15,0xffff
    7017df7fe564:	shl    r15,0x20
    7017df7fe568:	mov    rcx,r15
    7017df7fe56b:	or     rbp,rcx
    7017df7fe56e:	mov    r15,r13
    7017df7fe571:	shr    r15,0x18
    7017df7fe575:	and    r15,0xff
    7017df7fe57c:	and    r15,0xffff
    7017df7fe583:	shl    r15,0x30
    7017df7fe587:	mov    rcx,r15
    7017df7fe58a:	or     rbp,rcx
    7017df7fe58d:	mov    r15,r13
    7017df7fe590:	shr    r15,0x20
    7017df7fe594:	and    r15,0xff
    7017df7fe59b:	and    r15,0xffff
    7017df7fe5a2:	mov    rcx,r15
    7017df7fe5a5:	or     r14,rcx
    7017df7fe5a8:	mov    r15,r13
    7017df7fe5ab:	shr    r15,0x28
    7017df7fe5af:	and    r15,0xff
    7017df7fe5b6:	and    r15,0xffff
    7017df7fe5bd:	shl    r15,0x10
    7017df7fe5c1:	mov    rcx,r15
    7017df7fe5c4:	or     r14,rcx
    7017df7fe5c7:	mov    r15,r13
    7017df7fe5ca:	shr    r15,0x30
    7017df7fe5ce:	and    r15,0xff
    7017df7fe5d5:	and    r15,0xffff
    7017df7fe5dc:	shl    r15,0x20
    7017df7fe5e0:	mov    rcx,r15
    7017df7fe5e3:	or     r14,rcx
    7017df7fe5e6:	shr    r13,0x38
    7017df7fe5ea:	and    r13,0xff
    7017df7fe5f1:	and    r13,0xffff
    7017df7fe5f8:	shl    r13,0x30
    7017df7fe5fc:	mov    rcx,r13
    7017df7fe5ff:	or     r14,rcx
    7017df7fe602:	mov    QWORD PTR [r12+0x180],rbp
    7017df7fe60a:	mov    QWORD PTR [r12+0x188],r14
    7017df7fe612:	mov    r13,QWORD PTR [r12+0x128]
    7017df7fe61a:	mov    r14d,0x0
    7017df7fe620:	mov    r15,r13
    7017df7fe623:	and    r15,0xff
    7017df7fe62a:	and    r15,0xffff
    7017df7fe631:	mov    rcx,r15
    7017df7fe634:	mov    rbp,r14
    7017df7fe637:	or     rbp,rcx
    7017df7fe63a:	mov    r15,r13
    7017df7fe63d:	shr    r15,0x8
    7017df7fe641:	and    r15,0xff
    7017df7fe648:	and    r15,0xffff
    7017df7fe64f:	shl    r15,0x10
    7017df7fe653:	mov    rcx,r15
    7017df7fe656:	or     rbp,rcx
    7017df7fe659:	mov    r15,r13
    7017df7fe65c:	shr    r15,0x10
    7017df7fe660:	and    r15,0xff
    7017df7fe667:	and    r15,0xffff
    7017df7fe66e:	shl    r15,0x20
    7017df7fe672:	mov    rcx,r15
    7017df7fe675:	or     rbp,rcx
    7017df7fe678:	mov    r15,r13
    7017df7fe67b:	shr    r15,0x18
    7017df7fe67f:	and    r15,0xff
    7017df7fe686:	and    r15,0xffff
    7017df7fe68d:	shl    r15,0x30
    7017df7fe691:	mov    rcx,r15
    7017df7fe694:	or     rbp,rcx
    7017df7fe697:	mov    r15,r13
    7017df7fe69a:	shr    r15,0x20
    7017df7fe69e:	and    r15,0xff
    7017df7fe6a5:	and    r15,0xffff
    7017df7fe6ac:	mov    rcx,r15
    7017df7fe6af:	or     r14,rcx
    7017df7fe6b2:	mov    r15,r13
    7017df7fe6b5:	shr    r15,0x28
    7017df7fe6b9:	and    r15,0xff
    7017df7fe6c0:	and    r15,0xffff
    7017df7fe6c7:	shl    r15,0x10
    7017df7fe6cb:	mov    rcx,r15
    7017df7fe6ce:	or     r14,rcx
    7017df7fe6d1:	mov    r15,r13
    7017df7fe6d4:	shr    r15,0x30
    7017df7fe6d8:	and    r15,0xff
    7017df7fe6df:	and    r15,0xffff
    7017df7fe6e6:	shl    r15,0x20
    7017df7fe6ea:	mov    rcx,r15
    7017df7fe6ed:	or     r14,rcx
    7017df7fe6f0:	shr    r13,0x38
    7017df7fe6f4:	and    r13,0xff
    7017df7fe6fb:	and    r13,0xffff
    7017df7fe702:	shl    r13,0x30
    7017df7fe706:	mov    rcx,r13
    7017df7fe709:	or     r14,rcx
    7017df7fe70c:	mov    QWORD PTR [r12+0x210],rbp
    7017df7fe714:	mov    QWORD PTR [r12+0x218],r14
    7017df7fe71c:	mov    r13,QWORD PTR [r12+0x138]
    7017df7fe724:	mov    r14d,0x0
    7017df7fe72a:	mov    r15,r13
    7017df7fe72d:	and    r15,0xff
    7017df7fe734:	and    r15,0xffff
    7017df7fe73b:	mov    rcx,r15
    7017df7fe73e:	mov    rbp,r14
    7017df7fe741:	or     rbp,rcx
    7017df7fe744:	mov    r15,r13
    7017df7fe747:	shr    r15,0x8
    7017df7fe74b:	and    r15,0xff
    7017df7fe752:	and    r15,0xffff
    7017df7fe759:	shl    r15,0x10
    7017df7fe75d:	mov    rcx,r15
    7017df7fe760:	or     rbp,rcx
    7017df7fe763:	mov    r15,r13
    7017df7fe766:	shr    r15,0x10
    7017df7fe76a:	and    r15,0xff
    7017df7fe771:	and    r15,0xffff
    7017df7fe778:	shl    r15,0x20
    7017df7fe77c:	mov    rcx,r15
    7017df7fe77f:	or     rbp,rcx
    7017df7fe782:	mov    r15,r13
    7017df7fe785:	shr    r15,0x18
    7017df7fe789:	and    r15,0xff
    7017df7fe790:	and    r15,0xffff
    7017df7fe797:	shl    r15,0x30
    7017df7fe79b:	mov    rcx,r15
    7017df7fe79e:	or     rbp,rcx
    7017df7fe7a1:	mov    r15,r13
    7017df7fe7a4:	shr    r15,0x20
    7017df7fe7a8:	and    r15,0xff
    7017df7fe7af:	and    r15,0xffff
    7017df7fe7b6:	mov    rcx,r15
    7017df7fe7b9:	or     r14,rcx
    7017df7fe7bc:	mov    r15,r13
    7017df7fe7bf:	shr    r15,0x28
    7017df7fe7c3:	and    r15,0xff
    7017df7fe7ca:	and    r15,0xffff
    7017df7fe7d1:	shl    r15,0x10
    7017df7fe7d5:	mov    rcx,r15
    7017df7fe7d8:	or     r14,rcx
    7017df7fe7db:	mov    r15,r13
    7017df7fe7de:	shr    r15,0x30
    7017df7fe7e2:	and    r15,0xff
    7017df7fe7e9:	and    r15,0xffff
    7017df7fe7f0:	shl    r15,0x20
    7017df7fe7f4:	mov    rcx,r15
    7017df7fe7f7:	or     r14,rcx
    7017df7fe7fa:	shr    r13,0x38
    7017df7fe7fe:	and    r13,0xff
    7017df7fe805:	and    r13,0xffff
    7017df7fe80c:	shl    r13,0x30
    7017df7fe810:	mov    rcx,r13
    7017df7fe813:	or     r14,rcx
    7017df7fe816:	mov    QWORD PTR [r12+0x220],rbp
    7017df7fe81e:	mov    QWORD PTR [r12+0x228],r14
    7017df7fe826:	mov    r13,QWORD PTR [r12+0x140]
    7017df7fe82e:	mov    r14d,0x0
    7017df7fe834:	mov    r15,r13
    7017df7fe837:	and    r15,0xff
    7017df7fe83e:	and    r15,0xffff
    7017df7fe845:	mov    rcx,r15
    7017df7fe848:	mov    rbp,r14
    7017df7fe84b:	or     rbp,rcx
    7017df7fe84e:	mov    r15,r13
    7017df7fe851:	shr    r15,0x8
    7017df7fe855:	and    r15,0xff
    7017df7fe85c:	and    r15,0xffff
    7017df7fe863:	shl    r15,0x10
    7017df7fe867:	mov    rcx,r15
    7017df7fe86a:	or     rbp,rcx
    7017df7fe86d:	mov    r15,r13
    7017df7fe870:	shr    r15,0x10
    7017df7fe874:	and    r15,0xff
    7017df7fe87b:	and    r15,0xffff
    7017df7fe882:	shl    r15,0x20
    7017df7fe886:	mov    rcx,r15
    7017df7fe889:	or     rbp,rcx
    7017df7fe88c:	mov    r15,r13
    7017df7fe88f:	shr    r15,0x18
    7017df7fe893:	and    r15,0xff
    7017df7fe89a:	and    r15,0xffff
    7017df7fe8a1:	shl    r15,0x30
    7017df7fe8a5:	mov    rcx,r15
    7017df7fe8a8:	or     rbp,rcx
    7017df7fe8ab:	mov    r15,r13
    7017df7fe8ae:	shr    r15,0x20
    7017df7fe8b2:	and    r15,0xff
    7017df7fe8b9:	and    r15,0xffff
    7017df7fe8c0:	mov    rcx,r15
    7017df7fe8c3:	or     r14,rcx
    7017df7fe8c6:	mov    r15,r13
    7017df7fe8c9:	shr    r15,0x28
    7017df7fe8cd:	and    r15,0xff
    7017df7fe8d4:	and    r15,0xffff
    7017df7fe8db:	shl    r15,0x10
    7017df7fe8df:	mov    rcx,r15
    7017df7fe8e2:	or     r14,rcx
    7017df7fe8e5:	mov    r15,r13
    7017df7fe8e8:	shr    r15,0x30
    7017df7fe8ec:	and    r15,0xff
    7017df7fe8f3:	and    r15,0xffff
    7017df7fe8fa:	shl    r15,0x20
    7017df7fe8fe:	mov    rcx,r15
    7017df7fe901:	or     r14,rcx
    7017df7fe904:	shr    r13,0x38
    7017df7fe908:	and    r13,0xff
    7017df7fe90f:	and    r13,0xffff
    7017df7fe916:	shl    r13,0x30
    7017df7fe91a:	mov    rcx,r13
    7017df7fe91d:	or     r14,rcx
    7017df7fe920:	mov    QWORD PTR [r12+0x250],rbp
    7017df7fe928:	mov    QWORD PTR [r12+0x258],r14
    7017df7fe930:	mov    r13,QWORD PTR [r12+0x148]
    7017df7fe938:	mov    r14d,0x0
    7017df7fe93e:	mov    r15,r13
    7017df7fe941:	and    r15,0xff
    7017df7fe948:	and    r15,0xffff
    7017df7fe94f:	mov    rcx,r15
    7017df7fe952:	mov    rbp,r14
    7017df7fe955:	or     rbp,rcx
    7017df7fe958:	mov    r15,r13
    7017df7fe95b:	shr    r15,0x8
    7017df7fe95f:	and    r15,0xff
    7017df7fe966:	and    r15,0xffff
    7017df7fe96d:	shl    r15,0x10
    7017df7fe971:	mov    rcx,r15
    7017df7fe974:	or     rbp,rcx
    7017df7fe977:	mov    r15,r13
    7017df7fe97a:	shr    r15,0x10
    7017df7fe97e:	and    r15,0xff
    7017df7fe985:	and    r15,0xffff
    7017df7fe98c:	shl    r15,0x20
    7017df7fe990:	mov    rcx,r15
    7017df7fe993:	or     rbp,rcx
    7017df7fe996:	mov    r15,r13
    7017df7fe999:	shr    r15,0x18
    7017df7fe99d:	and    r15,0xff
    7017df7fe9a4:	and    r15,0xffff
    7017df7fe9ab:	shl    r15,0x30
    7017df7fe9af:	mov    rcx,r15
    7017df7fe9b2:	or     rbp,rcx
    7017df7fe9b5:	mov    r15,r13
    7017df7fe9b8:	shr    r15,0x20
    7017df7fe9bc:	and    r15,0xff
    7017df7fe9c3:	and    r15,0xffff
    7017df7fe9ca:	mov    rcx,r15
    7017df7fe9cd:	or     r14,rcx
    7017df7fe9d0:	mov    r15,r13
    7017df7fe9d3:	shr    r15,0x28
    7017df7fe9d7:	and    r15,0xff
    7017df7fe9de:	and    r15,0xffff
    7017df7fe9e5:	shl    r15,0x10
    7017df7fe9e9:	mov    rcx,r15
    7017df7fe9ec:	or     r14,rcx
    7017df7fe9ef:	mov    r15,r13
    7017df7fe9f2:	shr    r15,0x30
    7017df7fe9f6:	and    r15,0xff
    7017df7fe9fd:	and    r15,0xffff
    7017df7fea04:	shl    r15,0x20
    7017df7fea08:	mov    rcx,r15
    7017df7fea0b:	or     r14,rcx
    7017df7fea0e:	shr    r13,0x38
    7017df7fea12:	and    r13,0xff
    7017df7fea19:	and    r13,0xffff
    7017df7fea20:	shl    r13,0x30
    7017df7fea24:	mov    rcx,r13
    7017df7fea27:	or     r14,rcx
    7017df7fea2a:	mov    QWORD PTR [r12+0x110],rbp
    7017df7fea32:	mov    QWORD PTR [r12+0x118],r14
    7017df7fea3a:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7017df7fea44:	movdqa xmm2,xmm0
    7017df7fea48:	pxor   xmm0,xmm0
    7017df7fea4c:	movdqa xmm3,xmm0
    7017df7fea50:	movdqa xmm0,xmm2
    7017df7fea54:	movdqa xmm1,xmm3
    7017df7fea58:	punpcklwd xmm0,xmm1
    7017df7fea5c:	movdqa xmm4,xmm0
    7017df7fea60:	movdqa xmm0,xmm4
    7017df7fea64:	pslld  xmm0,0x10
    7017df7fea69:	movdqa xmm2,xmm0
    7017df7fea6d:	movdqa xmm0,xmm2
    7017df7fea71:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7017df7fea7b:	mov    r13,QWORD PTR [r12+0x160]
    7017df7fea83:	mov    r14d,0x0
    7017df7fea89:	mov    r15,r13
    7017df7fea8c:	and    r15,0xffff
    7017df7fea93:	shl    r15,0x8
    7017df7fea97:	mov    ecx,0xffffffff
    7017df7fea9c:	and    r15,rcx
    7017df7fea9f:	mov    rcx,r15
    7017df7feaa2:	mov    rbp,r14
    7017df7feaa5:	or     rbp,rcx
    7017df7feaa8:	mov    r15,r13
    7017df7feaab:	shr    r15,0x10
    7017df7feaaf:	and    r15,0xffff
    7017df7feab6:	shl    r15,0x8
    7017df7feaba:	mov    ecx,0xffffffff
    7017df7feabf:	and    r15,rcx
    7017df7feac2:	shl    r15,0x20
    7017df7feac6:	mov    rcx,r15
    7017df7feac9:	or     rbp,rcx
    7017df7feacc:	mov    r15,r13
    7017df7feacf:	shr    r15,0x20
    7017df7fead3:	and    r15,0xffff
    7017df7feada:	shl    r15,0x8
    7017df7feade:	mov    ecx,0xffffffff
    7017df7feae3:	and    r15,rcx
    7017df7feae6:	mov    rcx,r15
    7017df7feae9:	or     r14,rcx
    7017df7feaec:	shr    r13,0x30
    7017df7feaf0:	and    r13,0xffff
    7017df7feaf7:	shl    r13,0x8
    7017df7feafb:	mov    ecx,0xffffffff
    7017df7feb00:	and    r13,rcx
    7017df7feb03:	shl    r13,0x20
    7017df7feb07:	mov    rcx,r13
    7017df7feb0a:	or     r14,rcx
    7017df7feb0d:	mov    QWORD PTR [r12+0x240],rbp
    7017df7feb15:	mov    QWORD PTR [r12+0x248],r14
    7017df7feb1d:	mov    r13,QWORD PTR [r12+0x178]
    7017df7feb25:	mov    r14d,0x0
    7017df7feb2b:	mov    r15,r13
    7017df7feb2e:	and    r15,0xffff
    7017df7feb35:	mov    ecx,0xffffffff
    7017df7feb3a:	and    r15,rcx
    7017df7feb3d:	mov    rcx,r15
    7017df7feb40:	mov    rbp,r14
    7017df7feb43:	or     rbp,rcx
    7017df7feb46:	mov    r15,r13
    7017df7feb49:	shr    r15,0x10
    7017df7feb4d:	and    r15,0xffff
    7017df7feb54:	mov    ecx,0xffffffff
    7017df7feb59:	and    r15,rcx
    7017df7feb5c:	shl    r15,0x20
    7017df7feb60:	mov    rcx,r15
    7017df7feb63:	or     rbp,rcx
    7017df7feb66:	mov    r15,r13
    7017df7feb69:	shr    r15,0x20
    7017df7feb6d:	and    r15,0xffff
    7017df7feb74:	mov    ecx,0xffffffff
    7017df7feb79:	and    r15,rcx
    7017df7feb7c:	mov    rcx,r15
    7017df7feb7f:	or     r14,rcx
    7017df7feb82:	shr    r13,0x30
    7017df7feb86:	and    r13,0xffff
    7017df7feb8d:	mov    ecx,0xffffffff
    7017df7feb92:	and    r13,rcx
    7017df7feb95:	shl    r13,0x20
    7017df7feb99:	mov    rcx,r13
    7017df7feb9c:	or     r14,rcx
    7017df7feb9f:	mov    QWORD PTR [r12+0x260],rbp
    7017df7feba7:	mov    QWORD PTR [r12+0x268],r14
    7017df7febaf:	mov    r13,QWORD PTR [r12+0x188]
    7017df7febb7:	mov    r14d,0x0
    7017df7febbd:	mov    r15,r13
    7017df7febc0:	and    r15,0xffff
    7017df7febc7:	mov    ecx,0xffffffff
    7017df7febcc:	and    r15,rcx
    7017df7febcf:	mov    rcx,r15
    7017df7febd2:	mov    rbp,r14
    7017df7febd5:	or     rbp,rcx
    7017df7febd8:	mov    r15,r13
    7017df7febdb:	shr    r15,0x10
    7017df7febdf:	and    r15,0xffff
    7017df7febe6:	mov    ecx,0xffffffff
    7017df7febeb:	and    r15,rcx
    7017df7febee:	shl    r15,0x20
    7017df7febf2:	mov    rcx,r15
    7017df7febf5:	or     rbp,rcx
    7017df7febf8:	mov    r15,r13
    7017df7febfb:	shr    r15,0x20
    7017df7febff:	and    r15,0xffff
    7017df7fec06:	mov    ecx,0xffffffff
    7017df7fec0b:	and    r15,rcx
    7017df7fec0e:	mov    rcx,r15
    7017df7fec11:	or     r14,rcx
    7017df7fec14:	shr    r13,0x30
    7017df7fec18:	and    r13,0xffff
    7017df7fec1f:	mov    ecx,0xffffffff
    7017df7fec24:	and    r13,rcx
    7017df7fec27:	shl    r13,0x20
    7017df7fec2b:	mov    rcx,r13
    7017df7fec2e:	or     r14,rcx
    7017df7fec31:	mov    QWORD PTR [r12+0x270],rbp
    7017df7fec39:	mov    QWORD PTR [r12+0x278],r14
    7017df7fec41:	mov    r13,QWORD PTR [r12+0x170]
    7017df7fec49:	mov    r14d,0x0
    7017df7fec4f:	mov    r15,r13
    7017df7fec52:	and    r15,0xffff
    7017df7fec59:	mov    ecx,0xffffffff
    7017df7fec5e:	and    r15,rcx
    7017df7fec61:	mov    rcx,r15
    7017df7fec64:	mov    rbp,r14
    7017df7fec67:	or     rbp,rcx
    7017df7fec6a:	mov    r15,r13
    7017df7fec6d:	shr    r15,0x10
    7017df7fec71:	and    r15,0xffff
    7017df7fec78:	mov    ecx,0xffffffff
    7017df7fec7d:	and    r15,rcx
    7017df7fec80:	shl    r15,0x20
    7017df7fec84:	mov    rcx,r15
    7017df7fec87:	or     rbp,rcx
    7017df7fec8a:	mov    r15,r13
    7017df7fec8d:	shr    r15,0x20
    7017df7fec91:	and    r15,0xffff
    7017df7fec98:	mov    ecx,0xffffffff
    7017df7fec9d:	and    r15,rcx
    7017df7feca0:	mov    rcx,r15
    7017df7feca3:	or     r14,rcx
    7017df7feca6:	shr    r13,0x30
    7017df7fecaa:	and    r13,0xffff
    7017df7fecb1:	mov    ecx,0xffffffff
    7017df7fecb6:	and    r13,rcx
    7017df7fecb9:	shl    r13,0x20
    7017df7fecbd:	mov    rcx,r13
    7017df7fecc0:	or     r14,rcx
    7017df7fecc3:	mov    QWORD PTR [r12+0x170],rbp
    7017df7feccb:	mov    QWORD PTR [r12+0x178],r14
    7017df7fecd3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7017df7fecdd:	movdqa xmm2,xmm0
    7017df7fece1:	pxor   xmm0,xmm0
    7017df7fece5:	movdqa xmm3,xmm0
    7017df7fece9:	movdqa xmm0,xmm2
    7017df7feced:	movdqa xmm1,xmm3
    7017df7fecf1:	punpckhwd xmm0,xmm1
    7017df7fecf5:	movdqa xmm4,xmm0
    7017df7fecf9:	movdqa xmm0,xmm4
    7017df7fecfd:	pslld  xmm0,0x10
    7017df7fed02:	movdqa xmm3,xmm0
    7017df7fed06:	movdqa xmm0,xmm3
    7017df7fed0a:	movdqu XMMWORD PTR [r12+0x280],xmm0
    7017df7fed14:	mov    r13,QWORD PTR [r12+0x180]
    7017df7fed1c:	mov    r14d,0x0
    7017df7fed22:	mov    r15,r13
    7017df7fed25:	and    r15,0xffff
    7017df7fed2c:	mov    ecx,0xffffffff
    7017df7fed31:	and    r15,rcx
    7017df7fed34:	mov    rcx,r15
    7017df7fed37:	mov    rbp,r14
    7017df7fed3a:	or     rbp,rcx
    7017df7fed3d:	mov    r15,r13
    7017df7fed40:	shr    r15,0x10
    7017df7fed44:	and    r15,0xffff
    7017df7fed4b:	mov    ecx,0xffffffff
    7017df7fed50:	and    r15,rcx
    7017df7fed53:	shl    r15,0x20
    7017df7fed57:	mov    rcx,r15
    7017df7fed5a:	or     rbp,rcx
    7017df7fed5d:	mov    r15,r13
    7017df7fed60:	shr    r15,0x20
    7017df7fed64:	and    r15,0xffff
    7017df7fed6b:	mov    ecx,0xffffffff
    7017df7fed70:	and    r15,rcx
    7017df7fed73:	mov    rcx,r15
    7017df7fed76:	or     r14,rcx
    7017df7fed79:	shr    r13,0x30
    7017df7fed7d:	and    r13,0xffff
    7017df7fed84:	mov    ecx,0xffffffff
    7017df7fed89:	and    r13,rcx
    7017df7fed8c:	shl    r13,0x20
    7017df7fed90:	mov    rcx,r13
    7017df7fed93:	or     r14,rcx
    7017df7fed96:	mov    QWORD PTR [r12+0x180],rbp
    7017df7fed9e:	mov    QWORD PTR [r12+0x188],r14
    7017df7feda6:	pxor   xmm0,xmm0
    7017df7fedaa:	movdqa xmm3,xmm0
    7017df7fedae:	movdqa xmm0,xmm2
    7017df7fedb2:	movdqa xmm1,xmm3
    7017df7fedb6:	punpcklwd xmm0,xmm1
    7017df7fedba:	movdqa xmm4,xmm0
    7017df7fedbe:	movdqa xmm0,xmm4
    7017df7fedc2:	pslld  xmm0,0x10
    7017df7fedc7:	movdqa xmm2,xmm0
    7017df7fedcb:	movdqa xmm0,xmm2
    7017df7fedcf:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7017df7fedd9:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7017df7fede3:	movdqa xmm2,xmm0
    7017df7fede7:	pxor   xmm0,xmm0
    7017df7fedeb:	movdqa xmm3,xmm0
    7017df7fedef:	movdqa xmm0,xmm2
    7017df7fedf3:	movdqa xmm1,xmm3
    7017df7fedf7:	punpckhwd xmm0,xmm1
    7017df7fedfb:	movdqa xmm4,xmm0
    7017df7fedff:	movdqa xmm0,xmm4
    7017df7fee03:	pslld  xmm0,0x10
    7017df7fee08:	movdqa xmm2,xmm0
    7017df7fee0c:	movdqa xmm0,xmm2
    7017df7fee10:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7017df7fee1a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7017df7fee24:	movdqa xmm2,xmm0
    7017df7fee28:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7017df7fee32:	movdqa xmm3,xmm0
    7017df7fee36:	movdqa xmm1,xmm2
    7017df7fee3a:	por    xmm3,xmm1
    7017df7fee3e:	movdqa xmm0,xmm3
    7017df7fee42:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7017df7fee4c:	mov    r13,QWORD PTR [r12+0x228]
    7017df7fee54:	mov    r14d,0x0
    7017df7fee5a:	mov    r15,r13
    7017df7fee5d:	and    r15,0xffff
    7017df7fee64:	shl    r15,0x8
    7017df7fee68:	mov    ecx,0xffffffff
    7017df7fee6d:	and    r15,rcx
    7017df7fee70:	mov    rcx,r15
    7017df7fee73:	mov    rbp,r14
    7017df7fee76:	or     rbp,rcx
    7017df7fee79:	mov    r15,r13
    7017df7fee7c:	shr    r15,0x10
    7017df7fee80:	and    r15,0xffff
    7017df7fee87:	shl    r15,0x8
    7017df7fee8b:	mov    ecx,0xffffffff
    7017df7fee90:	and    r15,rcx
    7017df7fee93:	shl    r15,0x20
    7017df7fee97:	mov    rcx,r15
    7017df7fee9a:	or     rbp,rcx
    7017df7fee9d:	mov    r15,r13
    7017df7feea0:	shr    r15,0x20
    7017df7feea4:	and    r15,0xffff
    7017df7feeab:	shl    r15,0x8
    7017df7feeaf:	mov    ecx,0xffffffff
    7017df7feeb4:	and    r15,rcx
    7017df7feeb7:	mov    rcx,r15
    7017df7feeba:	or     r14,rcx
    7017df7feebd:	shr    r13,0x30
    7017df7feec1:	and    r13,0xffff
    7017df7feec8:	shl    r13,0x8
    7017df7feecc:	mov    ecx,0xffffffff
    7017df7feed1:	and    r13,rcx
    7017df7feed4:	shl    r13,0x20
    7017df7feed8:	mov    rcx,r13
    7017df7feedb:	or     r14,rcx
    7017df7feede:	mov    QWORD PTR [r12+0x240],rbp
    7017df7feee6:	mov    QWORD PTR [r12+0x248],r14
    7017df7feeee:	mov    r13,QWORD PTR [r12+0x220]
    7017df7feef6:	mov    r14d,0x0
    7017df7feefc:	mov    r15,r13
    7017df7feeff:	and    r15,0xffff
    7017df7fef06:	shl    r15,0x8
    7017df7fef0a:	mov    ecx,0xffffffff
    7017df7fef0f:	and    r15,rcx
    7017df7fef12:	mov    rcx,r15
    7017df7fef15:	mov    rbp,r14
    7017df7fef18:	or     rbp,rcx
    7017df7fef1b:	mov    r15,r13
    7017df7fef1e:	shr    r15,0x10
    7017df7fef22:	and    r15,0xffff
    7017df7fef29:	shl    r15,0x8
    7017df7fef2d:	mov    ecx,0xffffffff
    7017df7fef32:	and    r15,rcx
    7017df7fef35:	shl    r15,0x20
    7017df7fef39:	mov    rcx,r15
    7017df7fef3c:	or     rbp,rcx
    7017df7fef3f:	mov    r15,r13
    7017df7fef42:	shr    r15,0x20
    7017df7fef46:	and    r15,0xffff
    7017df7fef4d:	shl    r15,0x8
    7017df7fef51:	mov    ecx,0xffffffff
    7017df7fef56:	and    r15,rcx
    7017df7fef59:	mov    rcx,r15
    7017df7fef5c:	or     r14,rcx
    7017df7fef5f:	shr    r13,0x30
    7017df7fef63:	and    r13,0xffff
    7017df7fef6a:	shl    r13,0x8
    7017df7fef6e:	mov    ecx,0xffffffff
    7017df7fef73:	and    r13,rcx
    7017df7fef76:	shl    r13,0x20
    7017df7fef7a:	mov    rcx,r13
    7017df7fef7d:	or     r14,rcx
    7017df7fef80:	mov    QWORD PTR [r12+0x220],rbp
    7017df7fef88:	mov    QWORD PTR [r12+0x228],r14
    7017df7fef90:	mov    r13,QWORD PTR [r12+0x168]
    7017df7fef98:	mov    r14d,0x0
    7017df7fef9e:	mov    r15,r13
    7017df7fefa1:	and    r15,0xffff
    7017df7fefa8:	shl    r15,0x8
    7017df7fefac:	mov    ecx,0xffffffff
    7017df7fefb1:	and    r15,rcx
    7017df7fefb4:	mov    rcx,r15
    7017df7fefb7:	mov    rbp,r14
    7017df7fefba:	or     rbp,rcx
    7017df7fefbd:	mov    r15,r13
    7017df7fefc0:	shr    r15,0x10
    7017df7fefc4:	and    r15,0xffff
    7017df7fefcb:	shl    r15,0x8
    7017df7fefcf:	mov    ecx,0xffffffff
    7017df7fefd4:	and    r15,rcx
    7017df7fefd7:	shl    r15,0x20
    7017df7fefdb:	mov    rcx,r15
    7017df7fefde:	or     rbp,rcx
    7017df7fefe1:	mov    r15,r13
    7017df7fefe4:	shr    r15,0x20
    7017df7fefe8:	and    r15,0xffff
    7017df7fefef:	shl    r15,0x8
    7017df7feff3:	mov    ecx,0xffffffff
    7017df7feff8:	and    r15,rcx
    7017df7feffb:	mov    rcx,r15
    7017df7feffe:	or     r14,rcx
    7017df7ff001:	shr    r13,0x30
    7017df7ff005:	and    r13,0xffff
    7017df7ff00c:	shl    r13,0x8
    7017df7ff010:	mov    ecx,0xffffffff
    7017df7ff015:	and    r13,rcx
    7017df7ff018:	shl    r13,0x20
    7017df7ff01c:	mov    rcx,r13
    7017df7ff01f:	or     r14,rcx
    7017df7ff022:	mov    QWORD PTR [r12+0x160],rbp
    7017df7ff02a:	mov    QWORD PTR [r12+0x168],r14
    7017df7ff032:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7017df7ff03c:	movdqa xmm2,xmm0
    7017df7ff040:	movdqa xmm0,xmm2
    7017df7ff044:	pslld  xmm0,0x18
    7017df7ff049:	movdqa xmm3,xmm0
    7017df7ff04d:	movdqa xmm0,xmm3
    7017df7ff051:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7017df7ff05b:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7017df7ff065:	movdqa xmm2,xmm0
    7017df7ff069:	movdqa xmm0,xmm2
    7017df7ff06d:	pslld  xmm0,0x18
    7017df7ff072:	movdqa xmm3,xmm0
    7017df7ff076:	movdqa xmm0,xmm3
    7017df7ff07a:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7017df7ff084:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7017df7ff08e:	movdqa xmm2,xmm0
    7017df7ff092:	movdqa xmm0,xmm2
    7017df7ff096:	pslld  xmm0,0x18
    7017df7ff09b:	movdqa xmm3,xmm0
    7017df7ff09f:	movdqa xmm0,xmm3
    7017df7ff0a3:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7017df7ff0ad:	mov    r13,QWORD PTR [r12+0x250]
    7017df7ff0b5:	mov    r14d,0x0
    7017df7ff0bb:	mov    r15,r13
    7017df7ff0be:	and    r15,0xffff
    7017df7ff0c5:	mov    ecx,0xffffffff
    7017df7ff0ca:	and    r15,rcx
    7017df7ff0cd:	mov    rcx,r15
    7017df7ff0d0:	mov    rbp,r14
    7017df7ff0d3:	or     rbp,rcx
    7017df7ff0d6:	mov    r15,r13
    7017df7ff0d9:	shr    r15,0x10
    7017df7ff0dd:	and    r15,0xffff
    7017df7ff0e4:	mov    ecx,0xffffffff
    7017df7ff0e9:	and    r15,rcx
    7017df7ff0ec:	shl    r15,0x20
    7017df7ff0f0:	mov    rcx,r15
    7017df7ff0f3:	or     rbp,rcx
    7017df7ff0f6:	mov    r15,r13
    7017df7ff0f9:	shr    r15,0x20
    7017df7ff0fd:	and    r15,0xffff
    7017df7ff104:	mov    ecx,0xffffffff
    7017df7ff109:	and    r15,rcx
    7017df7ff10c:	mov    rcx,r15
    7017df7ff10f:	or     r14,rcx
    7017df7ff112:	shr    r13,0x30
    7017df7ff116:	and    r13,0xffff
    7017df7ff11d:	mov    ecx,0xffffffff
    7017df7ff122:	and    r13,rcx
    7017df7ff125:	shl    r13,0x20
    7017df7ff129:	mov    rcx,r13
    7017df7ff12c:	or     r14,rcx
    7017df7ff12f:	mov    QWORD PTR [r12+0x140],rbp
    7017df7ff137:	mov    QWORD PTR [r12+0x148],r14
    7017df7ff13f:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7017df7ff149:	movdqa xmm2,xmm0
    7017df7ff14d:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7017df7ff157:	movdqa xmm3,xmm0
    7017df7ff15b:	movdqa xmm1,xmm2
    7017df7ff15f:	por    xmm3,xmm1
    7017df7ff163:	movdqa xmm0,xmm3
    7017df7ff167:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7ff171:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7017df7ff17b:	movdqa xmm2,xmm0
    7017df7ff17f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7017df7ff189:	movdqa xmm3,xmm0
    7017df7ff18d:	movdqa xmm1,xmm2
    7017df7ff191:	por    xmm3,xmm1
    7017df7ff195:	movdqa xmm0,xmm3
    7017df7ff199:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7017df7ff1a3:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7017df7ff1ad:	movdqa xmm2,xmm0
    7017df7ff1b1:	movdqa xmm0,xmm2
    7017df7ff1b5:	pslld  xmm0,0x18
    7017df7ff1ba:	movdqa xmm3,xmm0
    7017df7ff1be:	movdqa xmm0,xmm3
    7017df7ff1c2:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7017df7ff1cc:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7017df7ff1d6:	movdqa xmm2,xmm0
    7017df7ff1da:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7017df7ff1e4:	movdqa xmm3,xmm0
    7017df7ff1e8:	movdqa xmm1,xmm2
    7017df7ff1ec:	por    xmm3,xmm1
    7017df7ff1f0:	movdqa xmm0,xmm3
    7017df7ff1f4:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7017df7ff1fe:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7017df7ff208:	movdqa xmm2,xmm0
    7017df7ff20c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7017df7ff216:	movdqa xmm3,xmm0
    7017df7ff21a:	movdqa xmm1,xmm2
    7017df7ff21e:	por    xmm3,xmm1
    7017df7ff222:	movdqa xmm0,xmm3
    7017df7ff226:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7017df7ff230:	mov    r13,QWORD PTR [r12+0x118]
    7017df7ff238:	mov    r14d,0x0
    7017df7ff23e:	mov    r15,r13
    7017df7ff241:	and    r15,0xffff
    7017df7ff248:	mov    ecx,0xffffffff
    7017df7ff24d:	and    r15,rcx
    7017df7ff250:	mov    rcx,r15
    7017df7ff253:	mov    rbp,r14
    7017df7ff256:	or     rbp,rcx
    7017df7ff259:	mov    r15,r13
    7017df7ff25c:	shr    r15,0x10
    7017df7ff260:	and    r15,0xffff
    7017df7ff267:	mov    ecx,0xffffffff
    7017df7ff26c:	and    r15,rcx
    7017df7ff26f:	shl    r15,0x20
    7017df7ff273:	mov    rcx,r15
    7017df7ff276:	or     rbp,rcx
    7017df7ff279:	mov    r15,r13
    7017df7ff27c:	shr    r15,0x20
    7017df7ff280:	and    r15,0xffff
    7017df7ff287:	mov    ecx,0xffffffff
    7017df7ff28c:	and    r15,rcx
    7017df7ff28f:	mov    rcx,r15
    7017df7ff292:	or     r14,rcx
    7017df7ff295:	shr    r13,0x30
    7017df7ff299:	and    r13,0xffff
    7017df7ff2a0:	mov    ecx,0xffffffff
    7017df7ff2a5:	and    r13,rcx
    7017df7ff2a8:	shl    r13,0x20
    7017df7ff2ac:	mov    rcx,r13
    7017df7ff2af:	or     r14,rcx
    7017df7ff2b2:	mov    QWORD PTR [r12+0x170],rbp
    7017df7ff2ba:	mov    QWORD PTR [r12+0x178],r14
    7017df7ff2c2:	mov    r13,QWORD PTR [r12+0x110]
    7017df7ff2ca:	mov    r14d,0x0
    7017df7ff2d0:	mov    r15,r13
    7017df7ff2d3:	and    r15,0xffff
    7017df7ff2da:	mov    ecx,0xffffffff
    7017df7ff2df:	and    r15,rcx
    7017df7ff2e2:	mov    rcx,r15
    7017df7ff2e5:	mov    rbp,r14
    7017df7ff2e8:	or     rbp,rcx
    7017df7ff2eb:	mov    r15,r13
    7017df7ff2ee:	shr    r15,0x10
    7017df7ff2f2:	and    r15,0xffff
    7017df7ff2f9:	mov    ecx,0xffffffff
    7017df7ff2fe:	and    r15,rcx
    7017df7ff301:	shl    r15,0x20
    7017df7ff305:	mov    rcx,r15
    7017df7ff308:	or     rbp,rcx
    7017df7ff30b:	mov    r15,r13
    7017df7ff30e:	shr    r15,0x20
    7017df7ff312:	and    r15,0xffff
    7017df7ff319:	mov    ecx,0xffffffff
    7017df7ff31e:	and    r15,rcx
    7017df7ff321:	mov    rcx,r15
    7017df7ff324:	or     r14,rcx
    7017df7ff327:	shr    r13,0x30
    7017df7ff32b:	and    r13,0xffff
    7017df7ff332:	mov    ecx,0xffffffff
    7017df7ff337:	and    r13,rcx
    7017df7ff33a:	shl    r13,0x20
    7017df7ff33e:	mov    rcx,r13
    7017df7ff341:	or     r14,rcx
    7017df7ff344:	mov    QWORD PTR [r12+0x110],rbp
    7017df7ff34c:	mov    QWORD PTR [r12+0x118],r14
    7017df7ff354:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7017df7ff35e:	movdqa xmm2,xmm0
    7017df7ff362:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7017df7ff36c:	movdqa xmm3,xmm0
    7017df7ff370:	movdqa xmm1,xmm2
    7017df7ff374:	por    xmm3,xmm1
    7017df7ff378:	movdqa xmm0,xmm3
    7017df7ff37c:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7017df7ff386:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7017df7ff390:	movdqa xmm2,xmm0
    7017df7ff394:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7017df7ff39e:	movdqa xmm3,xmm0
    7017df7ff3a2:	movdqa xmm1,xmm2
    7017df7ff3a6:	por    xmm3,xmm1
    7017df7ff3aa:	movdqa xmm0,xmm3
    7017df7ff3ae:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7ff3b8:	mov    r13,QWORD PTR [r12+0x258]
    7017df7ff3c0:	mov    r14d,0x0
    7017df7ff3c6:	mov    r15,r13
    7017df7ff3c9:	and    r15,0xffff
    7017df7ff3d0:	mov    ecx,0xffffffff
    7017df7ff3d5:	and    r15,rcx
    7017df7ff3d8:	mov    rcx,r15
    7017df7ff3db:	mov    rbp,r14
    7017df7ff3de:	or     rbp,rcx
    7017df7ff3e1:	mov    r15,r13
    7017df7ff3e4:	shr    r15,0x10
    7017df7ff3e8:	and    r15,0xffff
    7017df7ff3ef:	mov    ecx,0xffffffff
    7017df7ff3f4:	and    r15,rcx
    7017df7ff3f7:	shl    r15,0x20
    7017df7ff3fb:	mov    rcx,r15
    7017df7ff3fe:	or     rbp,rcx
    7017df7ff401:	mov    r15,r13
    7017df7ff404:	shr    r15,0x20
    7017df7ff408:	and    r15,0xffff
    7017df7ff40f:	mov    ecx,0xffffffff
    7017df7ff414:	and    r15,rcx
    7017df7ff417:	mov    rcx,r15
    7017df7ff41a:	or     r14,rcx
    7017df7ff41d:	shr    r13,0x30
    7017df7ff421:	and    r13,0xffff
    7017df7ff428:	mov    ecx,0xffffffff
    7017df7ff42d:	and    r13,rcx
    7017df7ff430:	shl    r13,0x20
    7017df7ff434:	mov    rcx,r13
    7017df7ff437:	or     r14,rcx
    7017df7ff43a:	mov    QWORD PTR [r12+0x180],rbp
    7017df7ff442:	mov    QWORD PTR [r12+0x188],r14
    7017df7ff44a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7017df7ff454:	movdqa xmm2,xmm0
    7017df7ff458:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7017df7ff462:	movdqa xmm3,xmm0
    7017df7ff466:	movdqa xmm1,xmm2
    7017df7ff46a:	por    xmm3,xmm1
    7017df7ff46e:	movdqa xmm0,xmm3
    7017df7ff472:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7017df7ff47c:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7017df7ff486:	movdqa xmm2,xmm0
    7017df7ff48a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7017df7ff494:	movdqa xmm4,xmm0
    7017df7ff498:	movdqa xmm1,xmm2
    7017df7ff49c:	por    xmm4,xmm1
    7017df7ff4a0:	movdqa xmm0,xmm4
    7017df7ff4a4:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7017df7ff4ae:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7017df7ff4b8:	movdqa xmm2,xmm0
    7017df7ff4bc:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7017df7ff4c6:	movdqa xmm4,xmm0
    7017df7ff4ca:	movdqa xmm1,xmm2
    7017df7ff4ce:	por    xmm4,xmm1
    7017df7ff4d2:	movdqa xmm0,xmm4
    7017df7ff4d6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7017df7ff4e0:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7017df7ff4ea:	movdqa xmm2,xmm0
    7017df7ff4ee:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7017df7ff4f8:	movdqa xmm5,xmm0
    7017df7ff4fc:	movdqa xmm1,xmm2
    7017df7ff500:	por    xmm5,xmm1
    7017df7ff504:	movdqa xmm0,xmm5
    7017df7ff508:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7017df7ff512:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7017df7ff51c:	movdqa xmm2,xmm0
    7017df7ff520:	movdqa xmm1,xmm2
    7017df7ff524:	por    xmm3,xmm1
    7017df7ff528:	movdqa xmm0,xmm3
    7017df7ff52c:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7017df7ff536:	mov    r13,QWORD PTR [r12+0xf8]
    7017df7ff53e:	mov    r14,r13
    7017df7ff541:	add    r14,0x20
    7017df7ff545:	mov    r15,r14
    7017df7ff548:	add    r15,0x10
    7017df7ff54c:	movdqu XMMWORD PTR [r14],xmm4
    7017df7ff551:	mov    r14d,0x0
    7017df7ff557:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7ff55f:	movdqu XMMWORD PTR [r15],xmm5
    7017df7ff564:	mov    r14d,0x0
    7017df7ff56a:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7ff572:	mov    r14,r13
    7017df7ff575:	add    r14,0x10
    7017df7ff579:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7017df7ff583:	movdqa xmm2,xmm0
    7017df7ff587:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7017df7ff58d:	mov    r15d,0x0
    7017df7ff593:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7ff59b:	movdqu XMMWORD PTR [r14],xmm3
    7017df7ff5a0:	mov    r14d,0x0
    7017df7ff5a6:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7ff5ae:	mov    r14d,DWORD PTR [r13+0x0]
    7017df7ff5b2:	mov    QWORD PTR [r12+0x60],r14
    7017df7ff5b7:	jmp    0x7017df7ff5bc
    7017df7ff5bc:	mov    r13,QWORD PTR [r12+0x58]
    7017df7ff5c1:	mov    r14,QWORD PTR [r12+0x48]
    7017df7ff5c6:	mov    rcx,r13
    7017df7ff5c9:	add    r14,rcx
    7017df7ff5cc:	mov    QWORD PTR [r12+0x68],r14
    7017df7ff5d1:	add    r13,0x4
    7017df7ff5d5:	mov    QWORD PTR [r12+0x58],r13
    7017df7ff5da:	mov    r15,r14
    7017df7ff5dd:	add    r15,0x4
    7017df7ff5e1:	mov    ebp,DWORD PTR [r15]
    7017df7ff5e4:	mov    QWORD PTR [r12+0x70],rbp
    7017df7ff5e9:	mov    r15,r14
    7017df7ff5ec:	add    r15,0x38
    7017df7ff5f0:	mov    r8d,DWORD PTR [r15]
    7017df7ff5f3:	mov    QWORD PTR [r12+0x78],r8
    7017df7ff5f8:	add    r14,0x24
    7017df7ff5fc:	mov    r15d,DWORD PTR [r14]
    7017df7ff5ff:	mov    QWORD PTR [r12+0x90],r15
    7017df7ff607:	sub    r13,0xc0
    7017df7ff60e:	pushf
    7017df7ff60f:	pop    r11
    7017df7ff611:	mov    QWORD PTR [rsp+0x48],r11
    7017df7ff616:	mov    r13d,ebp
    7017df7ff619:	mov    r13d,r13d
    7017df7ff61c:	ror    r13d,0x7
    7017df7ff620:	mov    QWORD PTR [r12+0x80],r13
    7017df7ff628:	mov    r14d,r8d
    7017df7ff62b:	mov    r14d,r14d
    7017df7ff62e:	ror    r14d,0x11
    7017df7ff632:	mov    QWORD PTR [r12+0x88],r14
    7017df7ff63a:	mov    r9d,DWORD PTR [r12+0x60]
    7017df7ff63f:	mov    ecx,r9d
    7017df7ff642:	add    r15d,ecx
    7017df7ff645:	mov    QWORD PTR [r12+0x60],r15
    7017df7ff64a:	mov    r15d,ebp
    7017df7ff64d:	mov    r15d,r15d
    7017df7ff650:	shr    r15d,0x12
    7017df7ff654:	mov    ebp,ebp
    7017df7ff656:	shl    ebp,0xe
    7017df7ff659:	mov    ecx,ebp
    7017df7ff65b:	or     r15,rcx
    7017df7ff65e:	mov    r15d,r15d
    7017df7ff661:	mov    ecx,r15d
    7017df7ff664:	xor    r13,rcx
    7017df7ff667:	mov    r13d,r13d
    7017df7ff66a:	mov    QWORD PTR [r12+0x80],r13
    7017df7ff672:	mov    r15d,r8d
    7017df7ff675:	mov    r15d,r15d
    7017df7ff678:	shr    r15d,0x13
    7017df7ff67c:	mov    r8d,r8d
    7017df7ff67f:	shl    r8d,0xd
    7017df7ff683:	mov    ecx,r8d
    7017df7ff686:	or     r15,rcx
    7017df7ff689:	mov    r15d,r15d
    7017df7ff68c:	mov    ecx,r15d
    7017df7ff68f:	xor    r14,rcx
    7017df7ff692:	mov    r14d,r14d
    7017df7ff695:	mov    QWORD PTR [r12+0x88],r14
    7017df7ff69d:	mov    r15d,DWORD PTR [r12+0x70]
    7017df7ff6a2:	mov    r15d,r15d
    7017df7ff6a5:	shr    r15d,0x3
    7017df7ff6a9:	mov    ecx,r15d
    7017df7ff6ac:	xor    r13,rcx
    7017df7ff6af:	mov    r13d,r13d
    7017df7ff6b2:	mov    QWORD PTR [r12+0x80],r13
    7017df7ff6ba:	mov    r15d,DWORD PTR [r12+0x78]
    7017df7ff6bf:	mov    r15d,r15d
    7017df7ff6c2:	shr    r15d,0xa
    7017df7ff6c6:	mov    ecx,r15d
    7017df7ff6c9:	xor    r14,rcx
    7017df7ff6cc:	mov    r14d,r14d
    7017df7ff6cf:	mov    QWORD PTR [r12+0x78],r14
    7017df7ff6d4:	mov    r15d,DWORD PTR [r12+0x60]
    7017df7ff6d9:	mov    ecx,r13d
    7017df7ff6dc:	add    r15d,ecx
    7017df7ff6df:	mov    QWORD PTR [r12+0x60],r15
    7017df7ff6e4:	mov    ecx,r14d
    7017df7ff6e7:	add    r15d,ecx
    7017df7ff6ea:	mov    QWORD PTR [r12+0x60],r15
    7017df7ff6ef:	mov    r13,QWORD PTR [r12+0x68]
    7017df7ff6f4:	add    r13,0x40
    7017df7ff6f8:	mov    DWORD PTR [r13+0x0],r15d
    7017df7ff6fc:	mov    r13d,0x0
    7017df7ff702:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7ff70a:	mov    r13d,0x0
    7017df7ff710:	mov    r14d,DWORD PTR [r12+0x70]
    7017df7ff715:	mov    ecx,r14d
    7017df7ff718:	mov    r15d,r13d
    7017df7ff71b:	or     r15,rcx
    7017df7ff71e:	mov    r15d,r15d
    7017df7ff721:	mov    QWORD PTR [r12+0x60],r15
    7017df7ff726:	mov    rcx,QWORD PTR [r12+0x380]
    7017df7ff72e:	jrcxz  0x7017df7ff735
    7017df7ff730:	jmp    0x7017df80008e
    7017df7ff735:	push   QWORD PTR [rsp+0x48]
    7017df7ff739:	popf
    7017df7ff73a:	jne    0x7017df7ff5bc
    7017df7ff740:	jmp    0x7017df7ff745
    7017df7ff745:	mov    r13,QWORD PTR [r12]
    7017df7ff749:	mov    r14,r13
    7017df7ff74c:	add    r14,0x4
    7017df7ff750:	mov    r15d,DWORD PTR [r13+0x0]
    7017df7ff754:	mov    ebp,DWORD PTR [r14]
    7017df7ff757:	mov    QWORD PTR [r12+0x78],r15
    7017df7ff75c:	mov    QWORD PTR [r12+0x80],rbp
    7017df7ff764:	mov    r14,r13
    7017df7ff767:	add    r14,0x8
    7017df7ff76b:	mov    r15,r14
    7017df7ff76e:	add    r15,0x4
    7017df7ff772:	mov    ebp,DWORD PTR [r14]
    7017df7ff775:	mov    r14d,DWORD PTR [r15]
    7017df7ff778:	mov    QWORD PTR [r12+0x70],rbp
    7017df7ff77d:	mov    QWORD PTR [r12+0x68],r14
    7017df7ff782:	mov    r14,r13
    7017df7ff785:	add    r14,0x18
    7017df7ff789:	mov    r15,r14
    7017df7ff78c:	add    r15,0x4
    7017df7ff790:	mov    ebp,DWORD PTR [r14]
    7017df7ff793:	mov    r14d,DWORD PTR [r15]
    7017df7ff796:	mov    QWORD PTR [r12+0x58],rbp
    7017df7ff79b:	mov    QWORD PTR [r12+0x60],r14
    7017df7ff7a0:	add    r13,0x10
    7017df7ff7a4:	mov    r14,r13
    7017df7ff7a7:	add    r14,0x4
    7017df7ff7ab:	mov    r15d,DWORD PTR [r13+0x0]
    7017df7ff7af:	mov    r13d,DWORD PTR [r14]
    7017df7ff7b2:	mov    QWORD PTR [r12+0x18],r15
    7017df7ff7b7:	mov    QWORD PTR [r12+0x90],r13
    7017df7ff7bf:	mov    r13d,0x0
    7017df7ff7c5:	mov    QWORD PTR [r12+0x88],r13
    7017df7ff7cd:	mov    r13d,0x0
    7017df7ff7d3:	mov    r14d,DWORD PTR [r12+0x78]
    7017df7ff7d8:	mov    ecx,r14d
    7017df7ff7db:	mov    r15d,r13d
    7017df7ff7de:	or     r15,rcx
    7017df7ff7e1:	mov    r15d,r15d
    7017df7ff7e4:	mov    QWORD PTR [r12+0xa8],r15
    7017df7ff7ec:	mov    r13d,0x0
    7017df7ff7f2:	mov    r14d,DWORD PTR [r12+0x80]
    7017df7ff7fa:	mov    ecx,r14d
    7017df7ff7fd:	mov    r15d,r13d
    7017df7ff800:	or     r15,rcx
    7017df7ff803:	mov    r15d,r15d
    7017df7ff806:	mov    QWORD PTR [r12+0x38],r15
    7017df7ff80b:	mov    r13d,0x0
    7017df7ff811:	mov    r14d,DWORD PTR [r12+0x70]
    7017df7ff816:	mov    ecx,r14d
    7017df7ff819:	mov    r15d,r13d
    7017df7ff81c:	or     r15,rcx
    7017df7ff81f:	mov    r15d,r15d
    7017df7ff822:	mov    QWORD PTR [r12+0x98],r15
    7017df7ff82a:	mov    r13d,0x0
    7017df7ff830:	mov    r14d,DWORD PTR [r12+0x68]
    7017df7ff835:	mov    ecx,r14d
    7017df7ff838:	mov    r15d,r13d
    7017df7ff83b:	or     r15,rcx
    7017df7ff83e:	mov    r15d,r15d
    7017df7ff841:	mov    QWORD PTR [r12+0x28],r15
    7017df7ff846:	mov    r13d,0x0
    7017df7ff84c:	mov    r14d,DWORD PTR [r12+0x60]
    7017df7ff851:	mov    ecx,r14d
    7017df7ff854:	mov    r15d,r13d
    7017df7ff857:	or     r15,rcx
    7017df7ff85a:	mov    r15d,r15d
    7017df7ff85d:	mov    QWORD PTR [r12+0xb0],r15
    7017df7ff865:	mov    r13d,0x0
    7017df7ff86b:	mov    r14d,DWORD PTR [r12+0x58]
    7017df7ff870:	mov    ecx,r14d
    7017df7ff873:	mov    r15d,r13d
    7017df7ff876:	or     r15,rcx
    7017df7ff879:	mov    r15d,r15d
    7017df7ff87c:	mov    QWORD PTR [r12+0xc0],r15
    7017df7ff884:	mov    r13d,0x0
    7017df7ff88a:	mov    r14d,DWORD PTR [r12+0x90]
    7017df7ff892:	mov    ecx,r14d
    7017df7ff895:	mov    r15d,r13d
    7017df7ff898:	or     r15,rcx
    7017df7ff89b:	mov    r15d,r15d
    7017df7ff89e:	mov    QWORD PTR [r12+0xc8],r15
    7017df7ff8a6:	mov    r13d,0x0
    7017df7ff8ac:	mov    r14d,DWORD PTR [r12+0x18]
    7017df7ff8b1:	mov    ecx,r14d
    7017df7ff8b4:	mov    r15d,r13d
    7017df7ff8b7:	or     r15,rcx
    7017df7ff8ba:	mov    r15d,r15d
    7017df7ff8bd:	mov    QWORD PTR [r12+0xb8],r15
    7017df7ff8c5:	jmp    0x7017df7ff8ca
    7017df7ff8ca:	mov    r13d,0x0
    7017df7ff8d0:	mov    r14d,DWORD PTR [r12+0xb8]
    7017df7ff8d8:	mov    ecx,r14d
    7017df7ff8db:	mov    r15d,r13d
    7017df7ff8de:	or     r15,rcx
    7017df7ff8e1:	mov    r15d,r15d
    7017df7ff8e4:	mov    QWORD PTR [r12+0x30],r15
    7017df7ff8e9:	mov    r13d,0x0
    7017df7ff8ef:	mov    r14d,DWORD PTR [r12+0xc0]
    7017df7ff8f7:	mov    ecx,r14d
    7017df7ff8fa:	mov    r15d,r13d
    7017df7ff8fd:	or     r15,rcx
    7017df7ff900:	mov    r15d,r15d
    7017df7ff903:	mov    QWORD PTR [r12+0xa0],r15
    7017df7ff90b:	mov    r13d,0x0
    7017df7ff911:	mov    r14d,DWORD PTR [r12+0x28]
    7017df7ff916:	mov    ecx,r14d
    7017df7ff919:	mov    r15d,r13d
    7017df7ff91c:	or     r15,rcx
    7017df7ff91f:	mov    r15d,r15d
    7017df7ff922:	mov    QWORD PTR [r12+0xc0],r15
    7017df7ff92a:	mov    r13d,0x0
    7017df7ff930:	mov    r14d,DWORD PTR [r12+0x98]
    7017df7ff938:	mov    ecx,r14d
    7017df7ff93b:	mov    r15d,r13d
    7017df7ff93e:	or     r15,rcx
    7017df7ff941:	mov    r15d,r15d
    7017df7ff944:	mov    QWORD PTR [r12+0x28],r15
    7017df7ff949:	mov    r13d,0x0
    7017df7ff94f:	mov    r14d,DWORD PTR [r12+0x38]
    7017df7ff954:	mov    ecx,r14d
    7017df7ff957:	mov    r15d,r13d
    7017df7ff95a:	or     r15,rcx
    7017df7ff95d:	mov    r15d,r15d
    7017df7ff960:	mov    QWORD PTR [r12+0x98],r15
    7017df7ff968:	mov    r13d,0x0
    7017df7ff96e:	mov    r14d,DWORD PTR [r12+0xa8]
    7017df7ff976:	mov    ecx,r14d
    7017df7ff979:	mov    r15d,r13d
    7017df7ff97c:	or     r15,rcx
    7017df7ff97f:	mov    r15d,r15d
    7017df7ff982:	mov    QWORD PTR [r12+0x38],r15
    7017df7ff987:	mov    r13d,DWORD PTR [r12+0xb8]
    7017df7ff98f:	mov    r13d,r13d
    7017df7ff992:	ror    r13d,0x6
    7017df7ff996:	mov    QWORD PTR [r12+0xb8],r13
    7017df7ff99e:	mov    r13d,DWORD PTR [r12+0x30]
    7017df7ff9a3:	mov    r14d,DWORD PTR [r12+0xc8]
    7017df7ff9ab:	mov    ecx,r14d
    7017df7ff9ae:	and    r13,rcx
    7017df7ff9b1:	mov    r13d,r13d
    7017df7ff9b4:	mov    QWORD PTR [r12+0xa8],r13
    7017df7ff9bc:	mov    r15d,r15d
    7017df7ff9bf:	ror    r15d,0x2
    7017df7ff9c3:	mov    QWORD PTR [r12+0xd0],r15
    7017df7ff9cb:	mov    r13d,0x0
    7017df7ff9d1:	mov    ecx,r14d
    7017df7ff9d4:	mov    r15d,r13d
    7017df7ff9d7:	or     r15,rcx
    7017df7ff9da:	mov    r15d,r15d
    7017df7ff9dd:	mov    QWORD PTR [r12+0x20],r15
    7017df7ff9e2:	mov    r13,QWORD PTR [r12+0x88]
    7017df7ff9ea:	mov    r14,QWORD PTR [r12+0x50]
    7017df7ff9ef:	mov    rcx,r13
    7017df7ff9f2:	add    r14,rcx
    7017df7ff9f5:	mov    r13d,DWORD PTR [r14]
    7017df7ff9f8:	mov    QWORD PTR [r12+0xc8],r13
    7017df7ffa00:	mov    r13d,DWORD PTR [r12+0xa0]
    7017df7ffa08:	mov    r14d,DWORD PTR [r12+0x30]
    7017df7ffa0d:	mov    ecx,r14d
    7017df7ffa10:	not    rcx
    7017df7ffa13:	and    r13,rcx
    7017df7ffa16:	mov    r13d,r13d
    7017df7ffa19:	mov    QWORD PTR [r12+0xd8],r13
    7017df7ffa21:	mov    r13d,DWORD PTR [r12+0xb0]
    7017df7ffa29:	mov    r15d,DWORD PTR [r12+0xa8]
    7017df7ffa31:	mov    ecx,r13d
    7017df7ffa34:	add    r15d,ecx
    7017df7ffa37:	mov    QWORD PTR [r12+0xa8],r15
    7017df7ffa3f:	mov    r13d,DWORD PTR [r12+0xb8]
    7017df7ffa47:	mov    ebp,r14d
    7017df7ffa4a:	mov    ebp,ebp
    7017df7ffa4c:	shr    ebp,0xb
    7017df7ffa4f:	mov    r14d,r14d
    7017df7ffa52:	shl    r14d,0x15
    7017df7ffa56:	mov    ecx,r14d
    7017df7ffa59:	or     rbp,rcx
    7017df7ffa5c:	mov    ebp,ebp
    7017df7ffa5e:	mov    ecx,ebp
    7017df7ffa60:	xor    r13,rcx
    7017df7ffa63:	mov    r13d,r13d
    7017df7ffa66:	mov    QWORD PTR [r12+0xb0],r13
    7017df7ffa6e:	mov    r13d,DWORD PTR [r12+0xd0]
    7017df7ffa76:	mov    r14d,DWORD PTR [r12+0x38]
    7017df7ffa7b:	mov    ebp,r14d
    7017df7ffa7e:	mov    ebp,ebp
    7017df7ffa80:	shr    ebp,0xd
    7017df7ffa83:	mov    r14d,r14d
    7017df7ffa86:	shl    r14d,0x13
    7017df7ffa8a:	mov    ecx,r14d
    7017df7ffa8d:	or     rbp,rcx
    7017df7ffa90:	mov    ebp,ebp
    7017df7ffa92:	mov    ecx,ebp
    7017df7ffa94:	xor    r13,rcx
    7017df7ffa97:	mov    r13d,r13d
    7017df7ffa9a:	mov    QWORD PTR [r12+0xd0],r13
    7017df7ffaa2:	mov    r13d,DWORD PTR [r12+0xd8]
    7017df7ffaaa:	mov    ecx,r13d
    7017df7ffaad:	add    r15d,ecx
    7017df7ffab0:	mov    QWORD PTR [r12+0xa8],r15
    7017df7ffab8:	mov    r13,QWORD PTR [r12+0x88]
    7017df7ffac0:	mov    r14,QWORD PTR [r12+0x48]
    7017df7ffac5:	mov    rcx,r13
    7017df7ffac8:	add    r14,rcx
    7017df7ffacb:	mov    r13d,DWORD PTR [r14]
    7017df7fface:	mov    QWORD PTR [r12+0xb8],r13
    7017df7ffad6:	mov    r13d,DWORD PTR [r12+0x28]
    7017df7ffadb:	mov    r14d,DWORD PTR [r12+0x98]
    7017df7ffae3:	mov    ecx,r14d
    7017df7ffae6:	mov    ebp,r13d
    7017df7ffae9:	and    rbp,rcx
    7017df7ffaec:	mov    ebp,ebp
    7017df7ffaee:	mov    QWORD PTR [r12+0xd8],rbp
    7017df7ffaf6:	mov    ebp,DWORD PTR [r12+0xc8]
    7017df7ffafe:	mov    ecx,ebp
    7017df7ffb00:	add    r15d,ecx
    7017df7ffb03:	mov    QWORD PTR [r12+0xa8],r15
    7017df7ffb0b:	mov    ecx,r14d
    7017df7ffb0e:	xor    r13,rcx
    7017df7ffb11:	mov    r13d,r13d
    7017df7ffb14:	mov    QWORD PTR [r12+0xc8],r13
    7017df7ffb1c:	mov    r14d,DWORD PTR [r12+0xb0]
    7017df7ffb24:	mov    r15d,DWORD PTR [r12+0x30]
    7017df7ffb29:	mov    ebp,r15d
    7017df7ffb2c:	mov    ebp,ebp
    7017df7ffb2e:	shr    ebp,0x19
    7017df7ffb31:	mov    r15d,r15d
    7017df7ffb34:	shl    r15d,0x7
    7017df7ffb38:	mov    ecx,r15d
    7017df7ffb3b:	or     rbp,rcx
    7017df7ffb3e:	mov    ebp,ebp
    7017df7ffb40:	mov    ecx,ebp
    7017df7ffb42:	xor    r14,rcx
    7017df7ffb45:	mov    r14d,r14d
    7017df7ffb48:	mov    QWORD PTR [r12+0xb0],r14
    7017df7ffb50:	mov    r14d,DWORD PTR [r12+0x38]
    7017df7ffb55:	mov    ecx,r14d
    7017df7ffb58:	and    r13,rcx
    7017df7ffb5b:	mov    r13d,r13d
    7017df7ffb5e:	mov    QWORD PTR [r12+0xc8],r13
    7017df7ffb66:	mov    r15d,DWORD PTR [r12+0xd0]
    7017df7ffb6e:	mov    ebp,r14d
    7017df7ffb71:	mov    ebp,ebp
    7017df7ffb73:	shr    ebp,0x16
    7017df7ffb76:	mov    r14d,r14d
    7017df7ffb79:	shl    r14d,0xa
    7017df7ffb7d:	mov    ecx,r14d
    7017df7ffb80:	or     rbp,rcx
    7017df7ffb83:	mov    ebp,ebp
    7017df7ffb85:	mov    ecx,ebp
    7017df7ffb87:	xor    r15,rcx
    7017df7ffb8a:	mov    r15d,r15d
    7017df7ffb8d:	mov    QWORD PTR [r12+0xd0],r15
    7017df7ffb95:	mov    r14d,DWORD PTR [r12+0xb8]
    7017df7ffb9d:	mov    r15d,DWORD PTR [r12+0xa8]
    7017df7ffba5:	mov    ecx,r14d
    7017df7ffba8:	add    r15d,ecx
    7017df7ffbab:	mov    QWORD PTR [r12+0xa8],r15
    7017df7ffbb3:	mov    r14d,DWORD PTR [r12+0xd8]
    7017df7ffbbb:	mov    ecx,r14d
    7017df7ffbbe:	xor    r13,rcx
    7017df7ffbc1:	mov    r13d,r13d
    7017df7ffbc4:	mov    QWORD PTR [r12+0xb8],r13
    7017df7ffbcc:	mov    r14d,DWORD PTR [r12+0xb0]
    7017df7ffbd4:	mov    ecx,r14d
    7017df7ffbd7:	add    r15d,ecx
    7017df7ffbda:	mov    QWORD PTR [r12+0xa8],r15
    7017df7ffbe2:	mov    r14,QWORD PTR [r12+0x88]
    7017df7ffbea:	add    r14,0x4
    7017df7ffbee:	mov    QWORD PTR [r12+0x88],r14
    7017df7ffbf6:	mov    ebp,DWORD PTR [r12+0xd0]
    7017df7ffbfe:	mov    ecx,ebp
    7017df7ffc00:	add    r13d,ecx
    7017df7ffc03:	mov    QWORD PTR [r12+0xb0],r13
    7017df7ffc0b:	mov    ebp,DWORD PTR [r12+0xc0]
    7017df7ffc13:	mov    ecx,ebp
    7017df7ffc15:	mov    r8d,r15d
    7017df7ffc18:	add    r8d,ecx
    7017df7ffc1b:	mov    QWORD PTR [r12+0xb8],r8
    7017df7ffc23:	sub    r14,0x100
    7017df7ffc2a:	pushf
    7017df7ffc2b:	pop    r11
    7017df7ffc2d:	mov    QWORD PTR [rsp+0x48],r11
    7017df7ffc32:	mov    ecx,r15d
    7017df7ffc35:	add    r13d,ecx
    7017df7ffc38:	mov    QWORD PTR [r12+0xa8],r13
    7017df7ffc40:	mov    r13d,0x0
    7017df7ffc46:	mov    r14d,DWORD PTR [r12+0xa0]
    7017df7ffc4e:	mov    ecx,r14d
    7017df7ffc51:	mov    r15d,r13d
    7017df7ffc54:	or     r15,rcx
    7017df7ffc57:	mov    r15d,r15d
    7017df7ffc5a:	mov    QWORD PTR [r12+0xb0],r15
    7017df7ffc62:	mov    r13d,0x0
    7017df7ffc68:	mov    r14d,DWORD PTR [r12+0x20]
    7017df7ffc6d:	mov    ecx,r14d
    7017df7ffc70:	mov    r15d,r13d
    7017df7ffc73:	or     r15,rcx
    7017df7ffc76:	mov    r15d,r15d
    7017df7ffc79:	mov    QWORD PTR [r12+0xc0],r15
    7017df7ffc81:	mov    r13d,0x0
    7017df7ffc87:	mov    r14d,DWORD PTR [r12+0x30]
    7017df7ffc8c:	mov    ecx,r14d
    7017df7ffc8f:	mov    r15d,r13d
    7017df7ffc92:	or     r15,rcx
    7017df7ffc95:	mov    r15d,r15d
    7017df7ffc98:	mov    QWORD PTR [r12+0xc8],r15
    7017df7ffca0:	mov    rcx,QWORD PTR [r12+0x380]
    7017df7ffca8:	jrcxz  0x7017df7ffcaf
    7017df7ffcaa:	jmp    0x7017df800115
    7017df7ffcaf:	push   QWORD PTR [rsp+0x48]
    7017df7ffcb3:	popf
    7017df7ffcb4:	jne    0x7017df7ff8ca
    7017df7ffcba:	jmp    0x7017df7ffcbf
    7017df7ffcbf:	mov    r13d,DWORD PTR [r12+0x70]
    7017df7ffcc4:	mov    r14d,DWORD PTR [r12+0x98]
    7017df7ffccc:	mov    ecx,r13d
    7017df7ffccf:	add    r14d,ecx
    7017df7ffcd2:	mov    QWORD PTR [r12+0x70],r14
    7017df7ffcd7:	mov    r13d,DWORD PTR [r12+0x68]
    7017df7ffcdc:	mov    r14d,DWORD PTR [r12+0x28]
    7017df7ffce1:	mov    ecx,r13d
    7017df7ffce4:	add    r14d,ecx
    7017df7ffce7:	mov    QWORD PTR [r12+0x68],r14
    7017df7ffcec:	mov    r13d,0x0
    7017df7ffcf2:	mov    QWORD PTR [r12+0x88],r13
    7017df7ffcfa:	mov    r13d,DWORD PTR [r12+0x78]
    7017df7ffcff:	mov    r14d,DWORD PTR [r12+0xa8]
    7017df7ffd07:	mov    ecx,r13d
    7017df7ffd0a:	add    r14d,ecx
    7017df7ffd0d:	mov    QWORD PTR [r12+0x78],r14
    7017df7ffd12:	mov    r13d,DWORD PTR [r12+0x80]
    7017df7ffd1a:	mov    r14d,DWORD PTR [r12+0x38]
    7017df7ffd1f:	mov    ecx,r13d
    7017df7ffd22:	add    r14d,ecx
    7017df7ffd25:	mov    QWORD PTR [r12+0x80],r14
    7017df7ffd2d:	mov    r13,QWORD PTR [r12]
    7017df7ffd31:	add    r13,0x8
    7017df7ffd35:	mov    r14,r13
    7017df7ffd38:	add    r14,0x4
    7017df7ffd3c:	mov    r15d,DWORD PTR [r12+0x70]
    7017df7ffd41:	mov    ebp,DWORD PTR [r12+0x68]
    7017df7ffd46:	mov    DWORD PTR [r13+0x0],r15d
    7017df7ffd4a:	mov    r13d,0x0
    7017df7ffd50:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7ffd58:	mov    DWORD PTR [r14],ebp
    7017df7ffd5b:	mov    r13d,0x0
    7017df7ffd61:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7ffd69:	mov    r13d,DWORD PTR [r12+0x18]
    7017df7ffd6e:	mov    r14d,DWORD PTR [r12+0xb8]
    7017df7ffd76:	mov    ecx,r13d
    7017df7ffd79:	add    r14d,ecx
    7017df7ffd7c:	mov    QWORD PTR [r12+0x68],r14
    7017df7ffd81:	mov    r13d,DWORD PTR [r12+0x90]
    7017df7ffd89:	mov    r14d,DWORD PTR [r12+0x30]
    7017df7ffd8e:	mov    ecx,r13d
    7017df7ffd91:	add    r14d,ecx
    7017df7ffd94:	mov    QWORD PTR [r12+0x70],r14
    7017df7ffd99:	mov    r13d,DWORD PTR [r12+0x58]
    7017df7ffd9e:	mov    r14d,DWORD PTR [r12+0x20]
    7017df7ffda3:	mov    ecx,r13d
    7017df7ffda6:	add    r14d,ecx
    7017df7ffda9:	mov    QWORD PTR [r12+0x58],r14
    7017df7ffdae:	mov    r13d,DWORD PTR [r12+0x60]
    7017df7ffdb3:	mov    r14d,DWORD PTR [r12+0xa0]
    7017df7ffdbb:	mov    ecx,r13d
    7017df7ffdbe:	add    r14d,ecx
    7017df7ffdc1:	mov    QWORD PTR [r12+0x60],r14
    7017df7ffdc6:	mov    r13,QWORD PTR [r12]
    7017df7ffdca:	mov    r15,r13
    7017df7ffdcd:	add    r15,0x4
    7017df7ffdd1:	mov    ebp,DWORD PTR [r12+0x78]
    7017df7ffdd6:	mov    r8d,DWORD PTR [r12+0x80]
    7017df7ffdde:	mov    DWORD PTR [r13+0x0],ebp
    7017df7ffde2:	mov    ebp,0x0
    7017df7ffde7:	mov    DWORD PTR [r12+0x32c],ebp
    7017df7ffdef:	mov    DWORD PTR [r15],r8d
    7017df7ffdf2:	mov    r15d,0x0
    7017df7ffdf8:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7ffe00:	mov    r15,r13
    7017df7ffe03:	add    r15,0x10
    7017df7ffe07:	mov    rbp,r15
    7017df7ffe0a:	add    rbp,0x4
    7017df7ffe0e:	mov    r8d,DWORD PTR [r12+0x68]
    7017df7ffe13:	mov    r9d,DWORD PTR [r12+0x70]
    7017df7ffe18:	mov    DWORD PTR [r15],r8d
    7017df7ffe1b:	mov    r15d,0x0
    7017df7ffe21:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7ffe29:	mov    DWORD PTR [rbp+0x0],r9d
    7017df7ffe2d:	mov    r15d,0x0
    7017df7ffe33:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7ffe3b:	mov    r15,r13
    7017df7ffe3e:	add    r15,0x18
    7017df7ffe42:	mov    rbp,r15
    7017df7ffe45:	add    rbp,0x4
    7017df7ffe49:	mov    r8d,DWORD PTR [r12+0x58]
    7017df7ffe4e:	mov    DWORD PTR [r15],r8d
    7017df7ffe51:	mov    r15d,0x0
    7017df7ffe57:	mov    DWORD PTR [r12+0x32c],r15d
    7017df7ffe5f:	mov    DWORD PTR [rbp+0x0],r14d
    7017df7ffe63:	mov    r14d,0x0
    7017df7ffe69:	mov    DWORD PTR [r12+0x32c],r14d
    7017df7ffe71:	add    r13,0x68
    7017df7ffe75:	mov    r14d,0x0
    7017df7ffe7b:	mov    QWORD PTR [r13+0x0],r14
    7017df7ffe7f:	mov    r13d,0x0
    7017df7ffe85:	mov    DWORD PTR [r12+0x32c],r13d
    7017df7ffe8d:	mov    rcx,QWORD PTR [r12+0x380]
    7017df7ffe95:	jrcxz  0x7017df7ffe9c
    7017df7ffe97:	jmp    0x7017df80019c
    7017df7ffe9c:	jmp    0x7017df7ffea1
    7017df7ffea1:	mov    r13,QWORD PTR [r12+0x10]
    7017df7ffea6:	sub    r13,0x1
    7017df7ffeaa:	mov    QWORD PTR [r12+0x10],r13
    7017df7ffeaf:	mov    rax,r13
    7017df7ffeb2:	test   rax,rax
    7017df7ffeb5:	sete   al
    7017df7ffeb8:	movzx  eax,al
    7017df7ffebb:	and    eax,0x1
    7017df7ffebe:	mov    r14,rax
    7017df7ffec1:	mov    rax,r14
    7017df7ffec4:	and    eax,0x1
    7017df7ffec7:	test   rax,rax
    7017df7ffeca:	jne    0x7017df7ffed5
    7017df7ffed0:	jmp    0x7017df7fd9f7
    7017df7ffed5:	mov    r13,QWORD PTR [r12+0xf8]
    7017df7ffedd:	mov    r14,r13
    7017df7ffee0:	add    r14,0x140
    7017df7ffee7:	mov    r15,r14
    7017df7ffeea:	add    r15,0x8
    7017df7ffeee:	mov    rbp,QWORD PTR [r14]
    7017df7ffef1:	mov    r14,QWORD PTR [r15]
    7017df7ffef4:	mov    QWORD PTR [r12+0xa0],rbp
    7017df7ffefc:	mov    QWORD PTR [r12+0x98],r14
    7017df7fff04:	mov    r14,r13
    7017df7fff07:	add    r14,0x130
    7017df7fff0e:	mov    r15,r14
    7017df7fff11:	add    r15,0x8
    7017df7fff15:	mov    rbp,QWORD PTR [r14]
    7017df7fff18:	mov    r14,QWORD PTR [r15]
    7017df7fff1b:	mov    QWORD PTR [r12+0xb0],rbp
    7017df7fff23:	mov    QWORD PTR [r12+0xa8],r14
    7017df7fff2b:	mov    r14,r13
    7017df7fff2e:	add    r14,0x120
    7017df7fff35:	mov    r15,r14
    7017df7fff38:	add    r15,0x8
    7017df7fff3c:	mov    rbp,QWORD PTR [r14]
    7017df7fff3f:	mov    r14,QWORD PTR [r15]
    7017df7fff42:	mov    QWORD PTR [r12+0xc0],rbp
    7017df7fff4a:	mov    QWORD PTR [r12+0xb8],r14
    7017df7fff52:	add    r13,0x110
    7017df7fff59:	mov    r14,r13
    7017df7fff5c:	add    r14,0x8
    7017df7fff60:	mov    r15,QWORD PTR [r13+0x0]
    7017df7fff64:	mov    r13,QWORD PTR [r14]
    7017df7fff67:	mov    QWORD PTR [r12+0xd0],r15
    7017df7fff6f:	mov    QWORD PTR [r12+0xc8],r13
    7017df7fff77:	mov    r13,QWORD PTR [r12+0xf8]
    7017df7fff7f:	mov    r14,r13
    7017df7fff82:	add    r14,0x100
    7017df7fff89:	mov    r15,r14
    7017df7fff8c:	add    r15,0x8
    7017df7fff90:	mov    rbp,QWORD PTR [r14]
    7017df7fff93:	mov    r14,QWORD PTR [r15]
    7017df7fff96:	mov    QWORD PTR [r12+0xe8],rbp
    7017df7fff9e:	mov    QWORD PTR [r12+0xd8],r14
    7017df7fffa6:	add    r13,0x150
    7017df7fffad:	mov    QWORD PTR [r12+0xf8],r13
    7017df7fffb5:	jmp    0x7017df7fffba
    7017df7fffba:	mov    rcx,QWORD PTR [r12+0x380]
    7017df7fffc2:	jrcxz  0x7017df7fffc9
    7017df7fffc4:	jmp    0x7017df800223
    7017df7fffc9:	mov    r13,QWORD PTR [r12+0xf0]
    7017df7fffd1:	mov    QWORD PTR [r12+0x100],r13
    7017df7fffd9:	mov    r11,QWORD PTR [rsp+0x48]
    7017df7fffde:	mov    QWORD PTR [r12+0x398],r11
    7017df7fffe6:	mov    rdi,QWORD PTR [r12+0x100]
    7017df7fffee:	add    rsp,0x50
    7017df7ffff2:	movabs r11,0x5dba7c1c00a0
    7017df7ffffc:	jmp    r11
    7017df7fffff:	mov    eax,0x41039c
    7017df800004:	mov    QWORD PTR [r12+0x100],rax
    7017df80000c:	push   rdx
    7017df80000d:	push   rsi
    7017df80000e:	push   r10
    7017df800010:	push   r11
    7017df800012:	pushf
    7017df800013:	pop    r11
    7017df800015:	mov    QWORD PTR [rsp+0x68],r11
    7017df80001a:	mov    rdx,QWORD PTR [rsp+0x68]
    7017df80001f:	mov    r10d,edx
    7017df800022:	and    r10d,0xc0
    7017df800029:	shl    r10d,0x18
    7017df80002d:	mov    r11d,edx
    7017df800030:	and    r11d,0x1
    7017df800034:	shl    r11d,0x1d
    7017df800038:	or     r10d,r11d
    7017df80003b:	mov    r11d,edx
    7017df80003e:	and    r11d,0x800
    7017df800045:	shl    r11d,0x11
    7017df800049:	or     r10d,r11d
    7017df80004c:	btc    r10,0x1d
    7017df800051:	mov    r11d,0xf0000000
    7017df800057:	and    r11,r10
    7017df80005a:	movabs rsi,0xffffffff0fffffff
    7017df800064:	and    rbx,rsi
    7017df800067:	or     rbx,r11
    7017df80006a:	pop    r11
    7017df80006c:	pop    r10
    7017df80006e:	pop    rsi
    7017df80006f:	pop    rdx
    7017df800070:	mov    QWORD PTR [r12+0x108],rbx
    7017df800078:	add    rsp,0x50
    7017df80007c:	mov    eax,0xc
    7017df800081:	movabs r11,0x5dba7c1c0390
    7017df80008b:	jmp    r11
    7017df80008e:	mov    eax,0x410498
    7017df800093:	mov    QWORD PTR [r12+0x100],rax
    7017df80009b:	push   rdx
    7017df80009c:	push   rsi
    7017df80009d:	push   r10
    7017df80009f:	push   r11
    7017df8000a1:	mov    rdx,QWORD PTR [rsp+0x68]
    7017df8000a6:	mov    r10d,edx
    7017df8000a9:	and    r10d,0xc0
    7017df8000b0:	shl    r10d,0x18
    7017df8000b4:	mov    r11d,edx
    7017df8000b7:	and    r11d,0x1
    7017df8000bb:	shl    r11d,0x1d
    7017df8000bf:	or     r10d,r11d
    7017df8000c2:	mov    r11d,edx
    7017df8000c5:	and    r11d,0x800
    7017df8000cc:	shl    r11d,0x11
    7017df8000d0:	or     r10d,r11d
    7017df8000d3:	btc    r10,0x1d
    7017df8000d8:	mov    r11d,0xf0000000
    7017df8000de:	and    r11,r10
    7017df8000e1:	movabs rsi,0xffffffff0fffffff
    7017df8000eb:	and    rbx,rsi
    7017df8000ee:	or     rbx,r11
    7017df8000f1:	pop    r11
    7017df8000f3:	pop    r10
    7017df8000f5:	pop    rsi
    7017df8000f6:	pop    rdx
    7017df8000f7:	mov    QWORD PTR [r12+0x108],rbx
    7017df8000ff:	add    rsp,0x50
    7017df800103:	mov    eax,0xc
    7017df800108:	movabs r11,0x5dba7c1c0390
    7017df800112:	jmp    r11
    7017df800115:	mov    eax,0x410558
    7017df80011a:	mov    QWORD PTR [r12+0x100],rax
    7017df800122:	push   rdx
    7017df800123:	push   rsi
    7017df800124:	push   r10
    7017df800126:	push   r11
    7017df800128:	mov    rdx,QWORD PTR [rsp+0x68]
    7017df80012d:	mov    r10d,edx
    7017df800130:	and    r10d,0xc0
    7017df800137:	shl    r10d,0x18
    7017df80013b:	mov    r11d,edx
    7017df80013e:	and    r11d,0x1
    7017df800142:	shl    r11d,0x1d
    7017df800146:	or     r10d,r11d
    7017df800149:	mov    r11d,edx
    7017df80014c:	and    r11d,0x800
    7017df800153:	shl    r11d,0x11
    7017df800157:	or     r10d,r11d
    7017df80015a:	btc    r10,0x1d
    7017df80015f:	mov    r11d,0xf0000000
    7017df800165:	and    r11,r10
    7017df800168:	movabs rsi,0xffffffff0fffffff
    7017df800172:	and    rbx,rsi
    7017df800175:	or     rbx,r11
    7017df800178:	pop    r11
    7017df80017a:	pop    r10
    7017df80017c:	pop    rsi
    7017df80017d:	pop    rdx
    7017df80017e:	mov    QWORD PTR [r12+0x108],rbx
    7017df800186:	add    rsp,0x50
    7017df80018a:	mov    eax,0xc
    7017df80018f:	movabs r11,0x5dba7c1c0390
    7017df800199:	jmp    r11
    7017df80019c:	mov    eax,0x410594
    7017df8001a1:	mov    QWORD PTR [r12+0x100],rax
    7017df8001a9:	push   rdx
    7017df8001aa:	push   rsi
    7017df8001ab:	push   r10
    7017df8001ad:	push   r11
    7017df8001af:	mov    rdx,QWORD PTR [rsp+0x68]
    7017df8001b4:	mov    r10d,edx
    7017df8001b7:	and    r10d,0xc0
    7017df8001be:	shl    r10d,0x18
    7017df8001c2:	mov    r11d,edx
    7017df8001c5:	and    r11d,0x1
    7017df8001c9:	shl    r11d,0x1d
    7017df8001cd:	or     r10d,r11d
    7017df8001d0:	mov    r11d,edx
    7017df8001d3:	and    r11d,0x800
    7017df8001da:	shl    r11d,0x11
    7017df8001de:	or     r10d,r11d
    7017df8001e1:	btc    r10,0x1d
    7017df8001e6:	mov    r11d,0xf0000000
    7017df8001ec:	and    r11,r10
    7017df8001ef:	movabs rsi,0xffffffff0fffffff
    7017df8001f9:	and    rbx,rsi
    7017df8001fc:	or     rbx,r11
    7017df8001ff:	pop    r11
    7017df800201:	pop    r10
    7017df800203:	pop    rsi
    7017df800204:	pop    rdx
    7017df800205:	mov    QWORD PTR [r12+0x108],rbx
    7017df80020d:	add    rsp,0x50
    7017df800211:	mov    eax,0xc
    7017df800216:	movabs r11,0x5dba7c1c0390
    7017df800220:	jmp    r11
    7017df800223:	mov    eax,0x4105b0
    7017df800228:	mov    QWORD PTR [r12+0x100],rax
    7017df800230:	push   rdx
    7017df800231:	push   rsi
    7017df800232:	push   r10
    7017df800234:	push   r11
    7017df800236:	mov    rdx,QWORD PTR [rsp+0x68]
    7017df80023b:	mov    r10d,edx
    7017df80023e:	and    r10d,0xc0
    7017df800245:	shl    r10d,0x18
    7017df800249:	mov    r11d,edx
    7017df80024c:	and    r11d,0x1
    7017df800250:	shl    r11d,0x1d
    7017df800254:	or     r10d,r11d
    7017df800257:	mov    r11d,edx
    7017df80025a:	and    r11d,0x800
    7017df800261:	shl    r11d,0x11
    7017df800265:	or     r10d,r11d
    7017df800268:	btc    r10,0x1d
    7017df80026d:	mov    r11d,0xf0000000
    7017df800273:	and    r11,r10
    7017df800276:	movabs rsi,0xffffffff0fffffff
    7017df800280:	and    rbx,rsi
    7017df800283:	or     rbx,r11
    7017df800286:	pop    r11
    7017df800288:	pop    r10
    7017df80028a:	pop    rsi
    7017df80028b:	pop    rdx
    7017df80028c:	mov    QWORD PTR [r12+0x108],rbx
    7017df800294:	add    rsp,0x50
    7017df800298:	mov    eax,0xc
    7017df80029d:	movabs r11,0x5dba7c1c0390
    7017df8002a7:	jmp    r11
    7017df8002aa:	nop    WORD PTR [rax+rax*1+0x0]
    7017df8002b0:	sub    rsp,0x50
    7017df8002b4:	mov    r11,QWORD PTR [r12+0x398]
    7017df8002bc:	mov    QWORD PTR [rsp+0x48],r11
    7017df8002c1:	jmp    0x7017df7fd84b
    7017df8002c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7017df8002d0:	sub    rsp,0x50
    7017df8002d4:	mov    r11,QWORD PTR [r12+0x398]
    7017df8002dc:	mov    QWORD PTR [rsp+0x48],r11
    7017df8002e1:	jmp    0x7017df7fd9f7
    7017df8002e6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7017df8002f0:	sub    rsp,0x50
    7017df8002f4:	mov    r11,QWORD PTR [r12+0x398]
    7017df8002fc:	mov    QWORD PTR [rsp+0x48],r11
    7017df800301:	jmp    0x7017df7fdaa1
    7017df800306:	data16 nop WORD PTR [rax+rax*1+0x0]
    7017df800310:	sub    rsp,0x50
    7017df800314:	mov    r11,QWORD PTR [r12+0x398]
    7017df80031c:	mov    QWORD PTR [rsp+0x48],r11
    7017df800321:	jmp    0x7017df7ff5bc
    7017df800326:	data16 nop WORD PTR [rax+rax*1+0x0]
    7017df800330:	sub    rsp,0x50
    7017df800334:	mov    r11,QWORD PTR [r12+0x398]
    7017df80033c:	mov    QWORD PTR [rsp+0x48],r11
    7017df800341:	jmp    0x7017df7ff745
    7017df800346:	data16 nop WORD PTR [rax+rax*1+0x0]
    7017df800350:	sub    rsp,0x50
    7017df800354:	mov    r11,QWORD PTR [r12+0x398]
    7017df80035c:	mov    QWORD PTR [rsp+0x48],r11
    7017df800361:	jmp    0x7017df7ff8ca
    7017df800366:	data16 nop WORD PTR [rax+rax*1+0x0]
    7017df800370:	sub    rsp,0x50
    7017df800374:	mov    r11,QWORD PTR [r12+0x398]
    7017df80037c:	mov    QWORD PTR [rsp+0x48],r11
    7017df800381:	jmp    0x7017df7ffcbf
    7017df800386:	data16 nop WORD PTR [rax+rax*1+0x0]
    7017df800390:	sub    rsp,0x50
    7017df800394:	mov    r11,QWORD PTR [r12+0x398]
    7017df80039c:	mov    QWORD PTR [rsp+0x48],r11
    7017df8003a1:	jmp    0x7017df7ffea1
    7017df8003a6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7017df8003b0:	sub    rsp,0x50
    7017df8003b4:	mov    r11,QWORD PTR [r12+0x398]
    7017df8003bc:	mov    QWORD PTR [rsp+0x48],r11
    7017df8003c1:	jmp    0x7017df7ffed5
    7017df8003c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7017df8003d0:	sub    rsp,0x50
    7017df8003d4:	mov    r11,QWORD PTR [r12+0x398]
    7017df8003dc:	mov    QWORD PTR [rsp+0x48],r11
    7017df8003e1:	jmp    0x7017df7fffba
    7017df8003e6:	nop
    7017df8003e7:	nop
