
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/1/2.bin:     file format binary


Disassembly of section .data:

00007c636a0003f0 <.data>:
    7c636a0003f0:	sub    rsp,0x10
    7c636a0003f4:	mov    r13d,DWORD PTR [r12+0xa0]
    7c636a0003fc:	sub    r13d,0x1
    7c636a000400:	mov    QWORD PTR [r12+0xa0],r13
    7c636a000408:	mov    rcx,QWORD PTR [r12+0x380]
    7c636a000410:	jrcxz  0x7c636a000417
    7c636a000412:	jmp    0x7c636a00058d
    7c636a000417:	pushf
    7c636a000418:	pop    r11
    7c636a00041a:	mov    QWORD PTR [rsp],r11
    7c636a00041e:	jne    0x7c636a0004f5
    7c636a000424:	jmp    0x7c636a000429
    7c636a000429:	mov    r13,QWORD PTR [r12+0xf8]
    7c636a000431:	mov    r14,r13
    7c636a000434:	add    r14,0x20
    7c636a000438:	mov    r15,QWORD PTR [r14]
    7c636a00043b:	mov    QWORD PTR [r12+0x98],r15
    7c636a000443:	mov    r14d,0x80
    7c636a000449:	mov    QWORD PTR [r12+0x40],r14
    7c636a00044e:	mov    r14,r13
    7c636a000451:	add    r14,0x0
    7c636a000455:	mov    QWORD PTR [r12],r14
    7c636a000459:	mov    r14,r13
    7c636a00045c:	add    r14,0x8c
    7c636a000463:	mov    QWORD PTR [r12+0x8],r14
    7c636a000468:	mov    r14d,0x1
    7c636a00046e:	mov    QWORD PTR [r12+0x10],r14
    7c636a000473:	add    r13,0x8c
    7c636a00047a:	movzx  r14d,BYTE PTR [r12+0x40]
    7c636a000480:	mov    BYTE PTR [r13+0x0],r14b
    7c636a000484:	mov    r13d,0x0
    7c636a00048a:	mov    DWORD PTR [r12+0x32c],r13d
    7c636a000492:	mov    r13d,0x410298
    7c636a000498:	mov    QWORD PTR [r12+0xf0],r13
    7c636a0004a0:	mov    r13d,0x410338
    7c636a0004a6:	mov    QWORD PTR [r12+0x100],r13
    7c636a0004ae:	mov    r11,QWORD PTR [rsp]
    7c636a0004b2:	mov    QWORD PTR [r12+0x398],r11
    7c636a0004ba:	mov    edi,0x410338
    7c636a0004bf:	mov    QWORD PTR [r12+0x100],rdi
    7c636a0004c7:	add    rsp,0x10
    7c636a0004cb:	nop    DWORD PTR [rax+rax*1+0x0]
    7c636a0004d0:	jmp    QWORD PTR [rip+0x2]        # 0x7c636a0004d8
    7c636a0004d6:	xchg   ax,ax
    7c636a0004d8:	loopne 0x7c636a0004b1
    7c636a0004da:	jmp    FWORD PTR [rcx+0x63]
    7c636a0004dd:	jl     0x7c636a0004df
    7c636a0004df:	add    al,ch
    7c636a0004e1:	add    al,0x0
    7c636a0004e3:	push   0x63
    7c636a0004e5:	jl     0x7c636a0004e7
    7c636a0004e7:	add    BYTE PTR [rcx-0x45],cl
    7c636a0004ea:	movabs al,ds:0x41000059733cd1d0
    7c636a0004f3:	jmp    rbx
    7c636a0004f5:	mov    r13,QWORD PTR [r12+0xf8]
    7c636a0004fd:	add    r13,0x0
    7c636a000501:	mov    QWORD PTR [r12],r13
    7c636a000505:	mov    r13d,0x0
    7c636a00050b:	mov    r14,QWORD PTR [r12+0x98]
    7c636a000513:	mov    rcx,r14
    7c636a000516:	or     r13,rcx
    7c636a000519:	mov    QWORD PTR [r12+0x8],r13
    7c636a00051e:	mov    r13d,0x12c
    7c636a000524:	mov    QWORD PTR [r12+0x10],r13
    7c636a000529:	mov    r13d,0x410274
    7c636a00052f:	mov    QWORD PTR [r12+0xf0],r13
    7c636a000537:	mov    r13d,0x410338
    7c636a00053d:	mov    QWORD PTR [r12+0x100],r13
    7c636a000545:	mov    r11,QWORD PTR [rsp]
    7c636a000549:	mov    QWORD PTR [r12+0x398],r11
    7c636a000551:	mov    edi,0x410338
    7c636a000556:	mov    QWORD PTR [r12+0x100],rdi
    7c636a00055e:	add    rsp,0x10
    7c636a000562:	nop    WORD PTR [rax+rax*1+0x0]
    7c636a000568:	jmp    QWORD PTR [rip+0x2]        # 0x7c636a000570
    7c636a00056e:	xchg   ax,ax
    7c636a000570:	loopne 0x7c636a000549
    7c636a000572:	jmp    FWORD PTR [rcx+0x63]
    7c636a000575:	jl     0x7c636a000577
    7c636a000577:	add    BYTE PTR [rax+0x636a0005],al
    7c636a00057d:	jl     0x7c636a00057f
    7c636a00057f:	add    BYTE PTR [rcx-0x45],cl
    7c636a000582:	movabs al,ds:0x41000059733cd1d0
    7c636a00058b:	jmp    rbx
    7c636a00058d:	mov    eax,0x410278
    7c636a000592:	mov    QWORD PTR [r12+0x100],rax
    7c636a00059a:	push   rdx
    7c636a00059b:	push   rsi
    7c636a00059c:	push   r10
    7c636a00059e:	push   r11
    7c636a0005a0:	pushf
    7c636a0005a1:	pop    r11
    7c636a0005a3:	mov    QWORD PTR [rsp+0x20],r11
    7c636a0005a8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c636a0005ad:	mov    r10d,edx
    7c636a0005b0:	and    r10d,0xc0
    7c636a0005b7:	shl    r10d,0x18
    7c636a0005bb:	mov    r11d,edx
    7c636a0005be:	and    r11d,0x1
    7c636a0005c2:	shl    r11d,0x1d
    7c636a0005c6:	or     r10d,r11d
    7c636a0005c9:	mov    r11d,edx
    7c636a0005cc:	and    r11d,0x800
    7c636a0005d3:	shl    r11d,0x11
    7c636a0005d7:	or     r10d,r11d
    7c636a0005da:	btc    r10,0x1d
    7c636a0005df:	mov    r11d,0xf0000000
    7c636a0005e5:	and    r11,r10
    7c636a0005e8:	movabs rsi,0xffffffff0fffffff
    7c636a0005f2:	and    rbx,rsi
    7c636a0005f5:	or     rbx,r11
    7c636a0005f8:	pop    r11
    7c636a0005fa:	pop    r10
    7c636a0005fc:	pop    rsi
    7c636a0005fd:	pop    rdx
    7c636a0005fe:	mov    QWORD PTR [r12+0x108],rbx
    7c636a000606:	add    rsp,0x10
    7c636a00060a:	mov    eax,0xc
    7c636a00060f:	movabs r11,0x59733cd1d390
    7c636a000619:	jmp    r11
    7c636a00061c:	nop    DWORD PTR [rax+0x0]
    7c636a000620:	sub    rsp,0x10
    7c636a000624:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00062c:	mov    QWORD PTR [rsp],r11
    7c636a000630:	jmp    0x7c636a000429
    7c636a000635:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a000640:	sub    rsp,0x10
    7c636a000644:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00064c:	mov    QWORD PTR [rsp],r11
    7c636a000650:	jmp    0x7c636a0004f5
    7c636a000655:	nop
    7c636a000656:	nop
    7c636a000657:	nop
