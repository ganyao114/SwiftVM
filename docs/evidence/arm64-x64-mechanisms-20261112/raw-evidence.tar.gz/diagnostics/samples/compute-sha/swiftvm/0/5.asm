
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/0/5.bin:     file format binary


Disassembly of section .data:

00007017df800a30 <.data>:
    7017df800a30:	sub    rsp,0x20
    7017df800a34:	mov    r11,QWORD PTR [r12+0x398]
    7017df800a3c:	mov    QWORD PTR [rsp+0x18],r11
    7017df800a41:	mov    r13,QWORD PTR [r12+0xf8]
    7017df800a49:	mov    r14,r13
    7017df800a4c:	add    r14,0x4
    7017df800a50:	mov    r15d,DWORD PTR [r13+0x0]
    7017df800a54:	mov    ebp,DWORD PTR [r14]
    7017df800a57:	mov    QWORD PTR [r12+0x40],r15
    7017df800a5c:	mov    QWORD PTR [r12+0x50],rbp
    7017df800a61:	mov    r14,r13
    7017df800a64:	add    r14,0x8
    7017df800a68:	mov    r8,r14
    7017df800a6b:	add    r8,0x4
    7017df800a6f:	mov    r9d,DWORD PTR [r14]
    7017df800a72:	mov    r14d,DWORD PTR [r8]
    7017df800a75:	mov    QWORD PTR [r12+0x58],r9
    7017df800a7a:	mov    QWORD PTR [r12+0x60],r14
    7017df800a7f:	mov    r14d,0x430860
    7017df800a85:	mov    QWORD PTR [r12+0x48],r14
    7017df800a8a:	add    r13,0x80
    7017df800a91:	mov    r14,QWORD PTR [r13+0x0]
    7017df800a95:	mov    QWORD PTR [r12+0xf0],r14
    7017df800a9d:	movabs rcx,0xff00ff00ff00ff
    7017df800aa7:	mov    r13,r15
    7017df800aaa:	and    r13,rcx
    7017df800aad:	shl    r13,0x8
    7017df800ab1:	movabs rcx,0xff00ff00ff00ff00
    7017df800abb:	mov    r14,r15
    7017df800abe:	and    r14,rcx
    7017df800ac1:	shr    r14,0x8
    7017df800ac5:	mov    rcx,r13
    7017df800ac8:	or     r14,rcx
    7017df800acb:	movabs rcx,0xffff0000ffff
    7017df800ad5:	mov    r13,r14
    7017df800ad8:	and    r13,rcx
    7017df800adb:	shl    r13,0x10
    7017df800adf:	movabs rcx,0xffff0000ffff0000
    7017df800ae9:	and    r14,rcx
    7017df800aec:	shr    r14,0x10
    7017df800af0:	mov    rcx,r13
    7017df800af3:	or     r14,rcx
    7017df800af6:	mov    ecx,0xffffffff
    7017df800afb:	and    r14,rcx
    7017df800afe:	mov    QWORD PTR [r12+0x40],r14
    7017df800b03:	movabs rcx,0xff00ff00ff00ff
    7017df800b0d:	mov    r13,rbp
    7017df800b10:	and    r13,rcx
    7017df800b13:	shl    r13,0x8
    7017df800b17:	movabs rcx,0xff00ff00ff00ff00
    7017df800b21:	mov    r15,rbp
    7017df800b24:	and    r15,rcx
    7017df800b27:	shr    r15,0x8
    7017df800b2b:	mov    rcx,r13
    7017df800b2e:	or     r15,rcx
    7017df800b31:	movabs rcx,0xffff0000ffff
    7017df800b3b:	mov    r13,r15
    7017df800b3e:	and    r13,rcx
    7017df800b41:	shl    r13,0x10
    7017df800b45:	movabs rcx,0xffff0000ffff0000
    7017df800b4f:	and    r15,rcx
    7017df800b52:	shr    r15,0x10
    7017df800b56:	mov    rcx,r13
    7017df800b59:	or     r15,rcx
    7017df800b5c:	mov    ecx,0xffffffff
    7017df800b61:	and    r15,rcx
    7017df800b64:	mov    QWORD PTR [r12+0x50],r15
    7017df800b69:	mov    r13d,0x430860
    7017df800b6f:	mov    ebp,0x430864
    7017df800b74:	mov    rax,r14
    7017df800b77:	mov    eax,eax
    7017df800b79:	mov    r8d,eax
    7017df800b7c:	mov    rax,r15
    7017df800b7f:	mov    eax,eax
    7017df800b81:	mov    r14d,eax
    7017df800b84:	mov    DWORD PTR [r13+0x0],r8d
    7017df800b88:	mov    r13d,0x0
    7017df800b8e:	mov    DWORD PTR [r12+0x32c],r13d
    7017df800b96:	mov    DWORD PTR [rbp+0x0],r14d
    7017df800b9a:	mov    r13d,0x0
    7017df800ba0:	mov    DWORD PTR [r12+0x32c],r13d
    7017df800ba8:	mov    r13d,DWORD PTR [r12+0x58]
    7017df800bad:	movabs rcx,0xff00ff00ff00ff
    7017df800bb7:	mov    r14,r13
    7017df800bba:	and    r14,rcx
    7017df800bbd:	shl    r14,0x8
    7017df800bc1:	movabs rcx,0xff00ff00ff00ff00
    7017df800bcb:	mov    r15,r13
    7017df800bce:	and    r15,rcx
    7017df800bd1:	shr    r15,0x8
    7017df800bd5:	mov    rcx,r14
    7017df800bd8:	or     r15,rcx
    7017df800bdb:	movabs rcx,0xffff0000ffff
    7017df800be5:	mov    r13,r15
    7017df800be8:	and    r13,rcx
    7017df800beb:	shl    r13,0x10
    7017df800bef:	movabs rcx,0xffff0000ffff0000
    7017df800bf9:	and    r15,rcx
    7017df800bfc:	shr    r15,0x10
    7017df800c00:	mov    rcx,r13
    7017df800c03:	or     r15,rcx
    7017df800c06:	mov    ecx,0xffffffff
    7017df800c0b:	and    r15,rcx
    7017df800c0e:	mov    QWORD PTR [r12+0x40],r15
    7017df800c13:	mov    r13d,DWORD PTR [r12+0x60]
    7017df800c18:	movabs rcx,0xff00ff00ff00ff
    7017df800c22:	mov    r14,r13
    7017df800c25:	and    r14,rcx
    7017df800c28:	shl    r14,0x8
    7017df800c2c:	movabs rcx,0xff00ff00ff00ff00
    7017df800c36:	mov    rbp,r13
    7017df800c39:	and    rbp,rcx
    7017df800c3c:	shr    rbp,0x8
    7017df800c40:	mov    rcx,r14
    7017df800c43:	or     rbp,rcx
    7017df800c46:	movabs rcx,0xffff0000ffff
    7017df800c50:	mov    r13,rbp
    7017df800c53:	and    r13,rcx
    7017df800c56:	shl    r13,0x10
    7017df800c5a:	movabs rcx,0xffff0000ffff0000
    7017df800c64:	and    rbp,rcx
    7017df800c67:	shr    rbp,0x10
    7017df800c6b:	mov    rcx,r13
    7017df800c6e:	or     rbp,rcx
    7017df800c71:	mov    ecx,0xffffffff
    7017df800c76:	and    rbp,rcx
    7017df800c79:	mov    QWORD PTR [r12+0x58],rbp
    7017df800c7e:	mov    r13,QWORD PTR [r12+0xf8]
    7017df800c86:	mov    r14,r13
    7017df800c89:	add    r14,0x10
    7017df800c8d:	mov    r8,r14
    7017df800c90:	add    r8,0x4
    7017df800c94:	mov    eax,DWORD PTR [r14]
    7017df800c97:	mov    QWORD PTR [rsp],rax
    7017df800c9b:	mov    r14d,DWORD PTR [r8]
    7017df800c9e:	mov    rax,QWORD PTR [rsp]
    7017df800ca2:	mov    QWORD PTR [r12+0x50],rax
    7017df800ca7:	mov    QWORD PTR [r12+0x60],r14
    7017df800cac:	mov    r14,QWORD PTR [r12+0x48]
    7017df800cb1:	add    r14,0x8
    7017df800cb5:	mov    r8,r14
    7017df800cb8:	add    r8,0x4
    7017df800cbc:	mov    rax,r15
    7017df800cbf:	mov    eax,eax
    7017df800cc1:	mov    r9d,eax
    7017df800cc4:	mov    rax,rbp
    7017df800cc7:	mov    eax,eax
    7017df800cc9:	mov    r15d,eax
    7017df800ccc:	mov    DWORD PTR [r14],r9d
    7017df800ccf:	mov    r14d,0x0
    7017df800cd5:	mov    DWORD PTR [r12+0x32c],r14d
    7017df800cdd:	mov    DWORD PTR [r8],r15d
    7017df800ce0:	mov    r14d,0x0
    7017df800ce6:	mov    DWORD PTR [r12+0x32c],r14d
    7017df800cee:	add    r13,0x90
    7017df800cf5:	mov    r14,r13
    7017df800cf8:	add    r14,0x8
    7017df800cfc:	mov    r15,QWORD PTR [r13+0x0]
    7017df800d00:	mov    r13,QWORD PTR [r14]
    7017df800d03:	mov    QWORD PTR [r12+0xa0],r15
    7017df800d0b:	mov    QWORD PTR [r12+0x98],r13
    7017df800d13:	movabs rcx,0xff00ff00ff00ff
    7017df800d1d:	mov    r13,QWORD PTR [rsp]
    7017df800d21:	and    r13,rcx
    7017df800d24:	shl    r13,0x8
    7017df800d28:	movabs rcx,0xff00ff00ff00ff00
    7017df800d32:	mov    r14,QWORD PTR [rsp]
    7017df800d36:	and    r14,rcx
    7017df800d39:	shr    r14,0x8
    7017df800d3d:	mov    rcx,r13
    7017df800d40:	or     r14,rcx
    7017df800d43:	movabs rcx,0xffff0000ffff
    7017df800d4d:	mov    r13,r14
    7017df800d50:	and    r13,rcx
    7017df800d53:	shl    r13,0x10
    7017df800d57:	movabs rcx,0xffff0000ffff0000
    7017df800d61:	and    r14,rcx
    7017df800d64:	shr    r14,0x10
    7017df800d68:	mov    rcx,r13
    7017df800d6b:	or     r14,rcx
    7017df800d6e:	mov    ecx,0xffffffff
    7017df800d73:	and    r14,rcx
    7017df800d76:	mov    QWORD PTR [r12+0x40],r14
    7017df800d7b:	mov    r13d,DWORD PTR [r12+0x60]
    7017df800d80:	movabs rcx,0xff00ff00ff00ff
    7017df800d8a:	mov    r15,r13
    7017df800d8d:	and    r15,rcx
    7017df800d90:	shl    r15,0x8
    7017df800d94:	movabs rcx,0xff00ff00ff00ff00
    7017df800d9e:	mov    rbp,r13
    7017df800da1:	and    rbp,rcx
    7017df800da4:	shr    rbp,0x8
    7017df800da8:	mov    rcx,r15
    7017df800dab:	or     rbp,rcx
    7017df800dae:	movabs rcx,0xffff0000ffff
    7017df800db8:	mov    r13,rbp
    7017df800dbb:	and    r13,rcx
    7017df800dbe:	shl    r13,0x10
    7017df800dc2:	movabs rcx,0xffff0000ffff0000
    7017df800dcc:	and    rbp,rcx
    7017df800dcf:	shr    rbp,0x10
    7017df800dd3:	mov    rcx,r13
    7017df800dd6:	or     rbp,rcx
    7017df800dd9:	mov    ecx,0xffffffff
    7017df800dde:	and    rbp,rcx
    7017df800de1:	mov    QWORD PTR [r12+0x58],rbp
    7017df800de6:	mov    r13,QWORD PTR [r12+0xf8]
    7017df800dee:	add    r13,0x18
    7017df800df2:	mov    r15,r13
    7017df800df5:	add    r15,0x4
    7017df800df9:	mov    r8d,DWORD PTR [r13+0x0]
    7017df800dfd:	mov    eax,DWORD PTR [r15]
    7017df800e00:	mov    QWORD PTR [rsp+0x10],rax
    7017df800e05:	mov    QWORD PTR [r12+0x50],r8
    7017df800e0a:	mov    rax,QWORD PTR [rsp+0x10]
    7017df800e0f:	mov    QWORD PTR [r12+0x60],rax
    7017df800e14:	mov    rax,QWORD PTR [r12+0x48]
    7017df800e19:	mov    QWORD PTR [rsp+0x8],rax
    7017df800e1e:	mov    r9,QWORD PTR [rsp+0x8]
    7017df800e23:	add    r9,0x10
    7017df800e27:	mov    r15,r9
    7017df800e2a:	add    r15,0x4
    7017df800e2e:	mov    rax,r14
    7017df800e31:	mov    eax,eax
    7017df800e33:	mov    r13d,eax
    7017df800e36:	mov    rax,rbp
    7017df800e39:	mov    eax,eax
    7017df800e3b:	mov    r14d,eax
    7017df800e3e:	mov    DWORD PTR [r9],r13d
    7017df800e41:	mov    r13d,0x0
    7017df800e47:	mov    DWORD PTR [r12+0x32c],r13d
    7017df800e4f:	mov    DWORD PTR [r15],r14d
    7017df800e52:	mov    r13d,0x0
    7017df800e58:	mov    DWORD PTR [r12+0x32c],r13d
    7017df800e60:	movabs rcx,0xff00ff00ff00ff
    7017df800e6a:	mov    r13,r8
    7017df800e6d:	and    r13,rcx
    7017df800e70:	shl    r13,0x8
    7017df800e74:	movabs rcx,0xff00ff00ff00ff00
    7017df800e7e:	mov    r14,r8
    7017df800e81:	and    r14,rcx
    7017df800e84:	shr    r14,0x8
    7017df800e88:	mov    rcx,r13
    7017df800e8b:	or     r14,rcx
    7017df800e8e:	movabs rcx,0xffff0000ffff
    7017df800e98:	mov    r13,r14
    7017df800e9b:	and    r13,rcx
    7017df800e9e:	shl    r13,0x10
    7017df800ea2:	movabs rcx,0xffff0000ffff0000
    7017df800eac:	and    r14,rcx
    7017df800eaf:	shr    r14,0x10
    7017df800eb3:	mov    rcx,r13
    7017df800eb6:	or     r14,rcx
    7017df800eb9:	mov    ecx,0xffffffff
    7017df800ebe:	and    r14,rcx
    7017df800ec1:	mov    QWORD PTR [r12+0x40],r14
    7017df800ec6:	movabs rcx,0xff00ff00ff00ff
    7017df800ed0:	mov    r13,QWORD PTR [rsp+0x10]
    7017df800ed5:	and    r13,rcx
    7017df800ed8:	shl    r13,0x8
    7017df800edc:	movabs rcx,0xff00ff00ff00ff00
    7017df800ee6:	mov    r15,QWORD PTR [rsp+0x10]
    7017df800eeb:	and    r15,rcx
    7017df800eee:	shr    r15,0x8
    7017df800ef2:	mov    rcx,r13
    7017df800ef5:	or     r15,rcx
    7017df800ef8:	movabs rcx,0xffff0000ffff
    7017df800f02:	mov    r13,r15
    7017df800f05:	and    r13,rcx
    7017df800f08:	shl    r13,0x10
    7017df800f0c:	movabs rcx,0xffff0000ffff0000
    7017df800f16:	and    r15,rcx
    7017df800f19:	shr    r15,0x10
    7017df800f1d:	mov    rcx,r13
    7017df800f20:	or     r15,rcx
    7017df800f23:	mov    ecx,0xffffffff
    7017df800f28:	and    r15,rcx
    7017df800f2b:	mov    QWORD PTR [r12+0x50],r15
    7017df800f30:	mov    r13,QWORD PTR [rsp+0x8]
    7017df800f35:	add    r13,0x18
    7017df800f39:	mov    rbp,r13
    7017df800f3c:	add    rbp,0x4
    7017df800f40:	mov    rax,r14
    7017df800f43:	mov    eax,eax
    7017df800f45:	mov    r8d,eax
    7017df800f48:	mov    rax,r15
    7017df800f4b:	mov    eax,eax
    7017df800f4d:	mov    r14d,eax
    7017df800f50:	mov    DWORD PTR [r13+0x0],r8d
    7017df800f54:	mov    r13d,0x0
    7017df800f5a:	mov    DWORD PTR [r12+0x32c],r13d
    7017df800f62:	mov    DWORD PTR [rbp+0x0],r14d
    7017df800f66:	mov    r13d,0x0
    7017df800f6c:	mov    DWORD PTR [r12+0x32c],r13d
    7017df800f74:	mov    r13,QWORD PTR [r12+0xf8]
    7017df800f7c:	add    r13,0xa0
    7017df800f83:	mov    QWORD PTR [r12+0xf8],r13
    7017df800f8b:	mov    rcx,QWORD PTR [r12+0x380]
    7017df800f93:	jrcxz  0x7017df800f9a
    7017df800f95:	jmp    0x7017df800fd0
    7017df800f9a:	mov    r13,QWORD PTR [r12+0xf0]
    7017df800fa2:	mov    QWORD PTR [r12+0x100],r13
    7017df800faa:	mov    r11,QWORD PTR [rsp+0x18]
    7017df800faf:	mov    QWORD PTR [r12+0x398],r11
    7017df800fb7:	mov    rdi,QWORD PTR [r12+0x100]
    7017df800fbf:	add    rsp,0x20
    7017df800fc3:	movabs r11,0x5dba7c1c00a0
    7017df800fcd:	jmp    r11
    7017df800fd0:	mov    eax,0x410334
    7017df800fd5:	mov    QWORD PTR [r12+0x100],rax
    7017df800fdd:	push   rdx
    7017df800fde:	push   rsi
    7017df800fdf:	push   r10
    7017df800fe1:	push   r11
    7017df800fe3:	mov    rdx,QWORD PTR [rsp+0x38]
    7017df800fe8:	mov    r10d,edx
    7017df800feb:	and    r10d,0xc0
    7017df800ff2:	shl    r10d,0x18
    7017df800ff6:	mov    r11d,edx
    7017df800ff9:	and    r11d,0x1
    7017df800ffd:	shl    r11d,0x1d
    7017df801001:	or     r10d,r11d
    7017df801004:	mov    r11d,edx
    7017df801007:	and    r11d,0x800
    7017df80100e:	shl    r11d,0x11
    7017df801012:	or     r10d,r11d
    7017df801015:	btc    r10,0x1d
    7017df80101a:	mov    r11d,0xf0000000
    7017df801020:	and    r11,r10
    7017df801023:	movabs rsi,0xffffffff0fffffff
    7017df80102d:	and    rbx,rsi
    7017df801030:	or     rbx,r11
    7017df801033:	pop    r11
    7017df801035:	pop    r10
    7017df801037:	pop    rsi
    7017df801038:	pop    rdx
    7017df801039:	mov    QWORD PTR [r12+0x108],rbx
    7017df801041:	add    rsp,0x20
    7017df801045:	mov    eax,0xc
    7017df80104a:	movabs r11,0x5dba7c1c0390
    7017df801054:	jmp    r11
    7017df801057:	nop
