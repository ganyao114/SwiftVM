
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/1/4.bin:     file format binary


Disassembly of section .data:

00007c636a0008b0 <.data>:
    7c636a0008b0:	sub    rsp,0x10
    7c636a0008b4:	mov    r11,QWORD PTR [r12+0x398]
    7c636a0008bc:	mov    QWORD PTR [rsp],r11
    7c636a0008c0:	mov    r13,QWORD PTR [r12+0xf8]
    7c636a0008c8:	add    r13,0x68
    7c636a0008cc:	mov    r14,QWORD PTR [r13+0x0]
    7c636a0008d0:	mov    QWORD PTR [r12+0x40],r14
    7c636a0008d5:	sub    r14,0x38
    7c636a0008d9:	mov    rcx,QWORD PTR [r12+0x380]
    7c636a0008e1:	jrcxz  0x7c636a0008e8
    7c636a0008e3:	jmp    0x7c636a00099d
    7c636a0008e8:	pushf
    7c636a0008e9:	pop    r11
    7c636a0008eb:	mov    QWORD PTR [rsp],r11
    7c636a0008ef:	jne    0x7c636a00094d
    7c636a0008f5:	jmp    0x7c636a0008fa
    7c636a0008fa:	mov    r13d,0x4102c4
    7c636a000900:	mov    QWORD PTR [r12+0x100],r13
    7c636a000908:	mov    r11,QWORD PTR [rsp]
    7c636a00090c:	mov    QWORD PTR [r12+0x398],r11
    7c636a000914:	mov    edi,0x4102c4
    7c636a000919:	mov    QWORD PTR [r12+0x100],rdi
    7c636a000921:	add    rsp,0x10
    7c636a000925:	nop    DWORD PTR [rax]
    7c636a000928:	jmp    QWORD PTR [rip+0x2]        # 0x7c636a000930
    7c636a00092e:	xchg   ax,ax
    7c636a000930:	nop
    7c636a000931:	or     BYTE PTR [rax],al
    7c636a000933:	push   0x63
    7c636a000935:	jl     0x7c636a000937
    7c636a000937:	add    BYTE PTR [rax+0x9],al
    7c636a00093a:	add    BYTE PTR [rdx+0x63],ch
    7c636a00093d:	jl     0x7c636a00093f
    7c636a00093f:	add    BYTE PTR [rcx-0x45],cl
    7c636a000942:	movabs al,ds:0x41000059733cd1d0
    7c636a00094b:	jmp    rbx
    7c636a00094d:	mov    r13d,0x4102a8
    7c636a000953:	mov    QWORD PTR [r12+0x100],r13
    7c636a00095b:	mov    r11,QWORD PTR [rsp]
    7c636a00095f:	mov    QWORD PTR [r12+0x398],r11
    7c636a000967:	mov    edi,0x4102a8
    7c636a00096c:	mov    QWORD PTR [r12+0x100],rdi
    7c636a000974:	add    rsp,0x10
    7c636a000978:	jmp    QWORD PTR [rip+0x2]        # 0x7c636a000980
    7c636a00097e:	xchg   ax,ax
    7c636a000980:	jo     0x7c636a00098a
    7c636a000982:	add    BYTE PTR [rdx+0x63],ch
    7c636a000985:	jl     0x7c636a000987
    7c636a000987:	add    BYTE PTR [rax+0x636a0009],dl
    7c636a00098d:	jl     0x7c636a00098f
    7c636a00098f:	add    BYTE PTR [rcx-0x45],cl
    7c636a000992:	movabs al,ds:0x41000059733cd1d0
    7c636a00099b:	jmp    rbx
    7c636a00099d:	mov    eax,0x4102c0
    7c636a0009a2:	mov    QWORD PTR [r12+0x100],rax
    7c636a0009aa:	push   rdx
    7c636a0009ab:	push   rsi
    7c636a0009ac:	push   r10
    7c636a0009ae:	push   r11
    7c636a0009b0:	pushf
    7c636a0009b1:	pop    r11
    7c636a0009b3:	mov    QWORD PTR [rsp+0x20],r11
    7c636a0009b8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c636a0009bd:	mov    r10d,edx
    7c636a0009c0:	and    r10d,0xc0
    7c636a0009c7:	shl    r10d,0x18
    7c636a0009cb:	mov    r11d,edx
    7c636a0009ce:	and    r11d,0x1
    7c636a0009d2:	shl    r11d,0x1d
    7c636a0009d6:	or     r10d,r11d
    7c636a0009d9:	mov    r11d,edx
    7c636a0009dc:	and    r11d,0x800
    7c636a0009e3:	shl    r11d,0x11
    7c636a0009e7:	or     r10d,r11d
    7c636a0009ea:	btc    r10,0x1d
    7c636a0009ef:	mov    r11d,0xf0000000
    7c636a0009f5:	and    r11,r10
    7c636a0009f8:	movabs rsi,0xffffffff0fffffff
    7c636a000a02:	and    rbx,rsi
    7c636a000a05:	or     rbx,r11
    7c636a000a08:	pop    r11
    7c636a000a0a:	pop    r10
    7c636a000a0c:	pop    rsi
    7c636a000a0d:	pop    rdx
    7c636a000a0e:	mov    QWORD PTR [r12+0x108],rbx
    7c636a000a16:	add    rsp,0x10
    7c636a000a1a:	mov    eax,0xc
    7c636a000a1f:	movabs r11,0x59733cd1d390
    7c636a000a29:	jmp    r11
