
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-sha/swiftvm/1/1.bin:     file format binary


Disassembly of section .data:

00007c6369ffd7e0 <.data>:
    7c6369ffd7e0:	sub    rsp,0x50
    7c6369ffd7e4:	mov    r11,QWORD PTR [r12+0x398]
    7c6369ffd7ec:	mov    QWORD PTR [rsp+0x48],r11
    7c6369ffd7f1:	mov    r13,QWORD PTR [r12]
    7c6369ffd7f5:	mov    r14,r13
    7c6369ffd7f8:	add    r14,0x20
    7c6369ffd7fc:	mov    r15,QWORD PTR [r14]
    7c6369ffd7ff:	mov    r14,QWORD PTR [r12+0x10]
    7c6369ffd804:	mov    rcx,r14
    7c6369ffd807:	add    r15,rcx
    7c6369ffd80a:	mov    QWORD PTR [r12+0x40],r15
    7c6369ffd80f:	add    r13,0x20
    7c6369ffd813:	mov    QWORD PTR [r13+0x0],r15
    7c6369ffd817:	mov    r13d,0x0
    7c6369ffd81d:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd825:	mov    rax,r14
    7c6369ffd828:	test   rax,rax
    7c6369ffd82b:	sete   al
    7c6369ffd82e:	movzx  eax,al
    7c6369ffd831:	and    eax,0x1
    7c6369ffd834:	mov    r13,rax
    7c6369ffd837:	mov    rax,r13
    7c6369ffd83a:	and    eax,0x1
    7c6369ffd83d:	test   rax,rax
    7c6369ffd840:	jne    0x7c6369ffffba
    7c6369ffd846:	jmp    0x7c6369ffd84b
    7c6369ffd84b:	mov    r13,QWORD PTR [r12+0xf8]
    7c6369ffd853:	sub    r13,0x150
    7c6369ffd85a:	mov    QWORD PTR [r12+0xf8],r13
    7c6369ffd862:	mov    r14,QWORD PTR [r12]
    7c6369ffd866:	mov    r15,r14
    7c6369ffd869:	add    r15,0x68
    7c6369ffd86d:	mov    rbp,QWORD PTR [r15]
    7c6369ffd870:	mov    QWORD PTR [r12+0x88],rbp
    7c6369ffd878:	add    r14,0x28
    7c6369ffd87c:	mov    QWORD PTR [r12+0x40],r14
    7c6369ffd881:	mov    r14,r13
    7c6369ffd884:	add    r14,0x0
    7c6369ffd888:	mov    QWORD PTR [r12+0x48],r14
    7c6369ffd88d:	mov    r14d,0x420000
    7c6369ffd893:	add    r14,0x758
    7c6369ffd89a:	mov    QWORD PTR [r12+0x50],r14
    7c6369ffd89f:	add    r13,0x100
    7c6369ffd8a6:	mov    r14,r13
    7c6369ffd8a9:	add    r14,0x8
    7c6369ffd8ad:	mov    r15,QWORD PTR [r12+0xe8]
    7c6369ffd8b5:	mov    rbp,QWORD PTR [r12+0xd8]
    7c6369ffd8bd:	mov    QWORD PTR [r13+0x0],r15
    7c6369ffd8c1:	mov    r13d,0x0
    7c6369ffd8c7:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd8cf:	mov    QWORD PTR [r14],rbp
    7c6369ffd8d2:	mov    r13d,0x0
    7c6369ffd8d8:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd8e0:	mov    r13,QWORD PTR [r12+0xf8]
    7c6369ffd8e8:	mov    r14,r13
    7c6369ffd8eb:	add    r14,0x110
    7c6369ffd8f2:	mov    r15,r14
    7c6369ffd8f5:	add    r15,0x8
    7c6369ffd8f9:	mov    rbp,QWORD PTR [r12+0xd0]
    7c6369ffd901:	mov    r8,QWORD PTR [r12+0xc8]
    7c6369ffd909:	mov    QWORD PTR [r14],rbp
    7c6369ffd90c:	mov    r14d,0x0
    7c6369ffd912:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd91a:	mov    QWORD PTR [r15],r8
    7c6369ffd91d:	mov    r14d,0x0
    7c6369ffd923:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd92b:	mov    r14,r13
    7c6369ffd92e:	add    r14,0x120
    7c6369ffd935:	mov    r15,r14
    7c6369ffd938:	add    r15,0x8
    7c6369ffd93c:	mov    rbp,QWORD PTR [r12+0xc0]
    7c6369ffd944:	mov    r8,QWORD PTR [r12+0xb8]
    7c6369ffd94c:	mov    QWORD PTR [r14],rbp
    7c6369ffd94f:	mov    r14d,0x0
    7c6369ffd955:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd95d:	mov    QWORD PTR [r15],r8
    7c6369ffd960:	mov    r14d,0x0
    7c6369ffd966:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd96e:	mov    r14,r13
    7c6369ffd971:	add    r14,0x130
    7c6369ffd978:	mov    r15,r14
    7c6369ffd97b:	add    r15,0x8
    7c6369ffd97f:	mov    rbp,QWORD PTR [r12+0xb0]
    7c6369ffd987:	mov    r8,QWORD PTR [r12+0xa8]
    7c6369ffd98f:	mov    QWORD PTR [r14],rbp
    7c6369ffd992:	mov    r14d,0x0
    7c6369ffd998:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd9a0:	mov    QWORD PTR [r15],r8
    7c6369ffd9a3:	mov    r14d,0x0
    7c6369ffd9a9:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffd9b1:	add    r13,0x140
    7c6369ffd9b8:	mov    r14,r13
    7c6369ffd9bb:	add    r14,0x8
    7c6369ffd9bf:	mov    r15,QWORD PTR [r12+0xa0]
    7c6369ffd9c7:	mov    rbp,QWORD PTR [r12+0x98]
    7c6369ffd9cf:	mov    QWORD PTR [r13+0x0],r15
    7c6369ffd9d3:	mov    r13d,0x0
    7c6369ffd9d9:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd9e1:	mov    QWORD PTR [r14],rbp
    7c6369ffd9e4:	mov    r13d,0x0
    7c6369ffd9ea:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffd9f2:	jmp    0x7c6369ffd9f7
    7c6369ffd9f7:	mov    r13,QWORD PTR [r12+0x8]
    7c6369ffd9fc:	mov    r14,r13
    7c6369ffd9ff:	add    r14,0x1
    7c6369ffda03:	movzx  r15d,BYTE PTR [r13+0x0]
    7c6369ffda08:	mov    QWORD PTR [r12+0x58],r15
    7c6369ffda0d:	mov    QWORD PTR [r12+0x8],r14
    7c6369ffda12:	mov    r13,QWORD PTR [r12+0x88]
    7c6369ffda1a:	mov    r14,r13
    7c6369ffda1d:	add    r14,0x1
    7c6369ffda21:	mov    QWORD PTR [r12+0x60],r14
    7c6369ffda26:	mov    r15,QWORD PTR [r12]
    7c6369ffda2a:	mov    rbp,r15
    7c6369ffda2d:	add    rbp,0x68
    7c6369ffda31:	mov    QWORD PTR [rbp+0x0],r14
    7c6369ffda35:	mov    r14d,0x0
    7c6369ffda3b:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369ffda43:	mov    rcx,r13
    7c6369ffda46:	mov    r14,r15
    7c6369ffda49:	add    r14,rcx
    7c6369ffda4c:	mov    QWORD PTR [r12+0x60],r14
    7c6369ffda51:	add    r14,0x28
    7c6369ffda55:	movzx  r13d,BYTE PTR [r12+0x58]
    7c6369ffda5b:	mov    BYTE PTR [r14],r13b
    7c6369ffda5e:	mov    r13d,0x0
    7c6369ffda64:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369ffda6c:	add    r15,0x68
    7c6369ffda70:	mov    r13,QWORD PTR [r15]
    7c6369ffda73:	mov    QWORD PTR [r12+0x88],r13
    7c6369ffda7b:	sub    r13,0x40
    7c6369ffda7f:	mov    rcx,QWORD PTR [r12+0x380]
    7c6369ffda87:	jrcxz  0x7c6369ffda8e
    7c6369ffda89:	jmp    0x7c6369ffffff
    7c6369ffda8e:	pushf
    7c6369ffda8f:	pop    r11
    7c6369ffda91:	mov    QWORD PTR [rsp+0x48],r11
    7c6369ffda96:	jne    0x7c6369fffea1
    7c6369ffda9c:	jmp    0x7c6369ffdaa1
    7c6369ffdaa1:	mov    rax,QWORD PTR [r12+0x40]
    7c6369ffdaa6:	mov    QWORD PTR [rsp],rax
    7c6369ffdaaa:	mov    eax,0x0
    7c6369ffdaaf:	mov    QWORD PTR [rsp+0x20],rax
    7c6369ffdab4:	mov    eax,0x0
    7c6369ffdab9:	mov    QWORD PTR [rsp+0x18],rax
    7c6369ffdabe:	mov    eax,0x0
    7c6369ffdac3:	mov    QWORD PTR [rsp+0x10],rax
    7c6369ffdac8:	mov    eax,0x0
    7c6369ffdacd:	mov    QWORD PTR [rsp+0x8],rax
    7c6369ffdad2:	mov    rdi,QWORD PTR [rsp]
    7c6369ffdad6:	movzx  r9d,BYTE PTR [rdi]
    7c6369ffdada:	mov    r13,r9
    7c6369ffdadd:	mov    rcx,r13
    7c6369ffdae0:	mov    r9,QWORD PTR [rsp+0x20]
    7c6369ffdae5:	or     r9,rcx
    7c6369ffdae8:	mov    r13,QWORD PTR [rsp]
    7c6369ffdaec:	add    r13,0x1
    7c6369ffdaf0:	movzx  r8d,BYTE PTR [r13+0x0]
    7c6369ffdaf5:	mov    r13,r8
    7c6369ffdaf8:	mov    rcx,r13
    7c6369ffdafb:	mov    r8,QWORD PTR [rsp+0x18]
    7c6369ffdb00:	or     r8,rcx
    7c6369ffdb03:	mov    r13,QWORD PTR [rsp]
    7c6369ffdb07:	add    r13,0x2
    7c6369ffdb0b:	movzx  ebp,BYTE PTR [r13+0x0]
    7c6369ffdb10:	mov    r13,rbp
    7c6369ffdb13:	mov    rcx,r13
    7c6369ffdb16:	mov    rbp,QWORD PTR [rsp+0x10]
    7c6369ffdb1b:	or     rbp,rcx
    7c6369ffdb1e:	mov    r13,QWORD PTR [rsp]
    7c6369ffdb22:	add    r13,0x3
    7c6369ffdb26:	movzx  r15d,BYTE PTR [r13+0x0]
    7c6369ffdb2b:	mov    r13,r15
    7c6369ffdb2e:	mov    rcx,r13
    7c6369ffdb31:	mov    r15,QWORD PTR [rsp+0x8]
    7c6369ffdb36:	or     r15,rcx
    7c6369ffdb39:	mov    r13,QWORD PTR [rsp]
    7c6369ffdb3d:	add    r13,0x4
    7c6369ffdb41:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdb46:	mov    r13,r14
    7c6369ffdb49:	shl    r13,0x8
    7c6369ffdb4d:	mov    rcx,r13
    7c6369ffdb50:	or     r9,rcx
    7c6369ffdb53:	mov    r13,QWORD PTR [rsp]
    7c6369ffdb57:	add    r13,0x5
    7c6369ffdb5b:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdb60:	mov    r13,r14
    7c6369ffdb63:	shl    r13,0x8
    7c6369ffdb67:	mov    rcx,r13
    7c6369ffdb6a:	or     r8,rcx
    7c6369ffdb6d:	mov    r13,QWORD PTR [rsp]
    7c6369ffdb71:	add    r13,0x6
    7c6369ffdb75:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdb7a:	mov    r13,r14
    7c6369ffdb7d:	shl    r13,0x8
    7c6369ffdb81:	mov    rcx,r13
    7c6369ffdb84:	or     rbp,rcx
    7c6369ffdb87:	mov    r13,QWORD PTR [rsp]
    7c6369ffdb8b:	add    r13,0x7
    7c6369ffdb8f:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdb94:	mov    r13,r14
    7c6369ffdb97:	shl    r13,0x8
    7c6369ffdb9b:	mov    rcx,r13
    7c6369ffdb9e:	or     r15,rcx
    7c6369ffdba1:	mov    r13,QWORD PTR [rsp]
    7c6369ffdba5:	add    r13,0x8
    7c6369ffdba9:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdbae:	mov    r13,r14
    7c6369ffdbb1:	shl    r13,0x10
    7c6369ffdbb5:	mov    rcx,r13
    7c6369ffdbb8:	or     r9,rcx
    7c6369ffdbbb:	mov    r13,QWORD PTR [rsp]
    7c6369ffdbbf:	add    r13,0x9
    7c6369ffdbc3:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdbc8:	mov    r13,r14
    7c6369ffdbcb:	shl    r13,0x10
    7c6369ffdbcf:	mov    rcx,r13
    7c6369ffdbd2:	or     r8,rcx
    7c6369ffdbd5:	mov    r13,QWORD PTR [rsp]
    7c6369ffdbd9:	add    r13,0xa
    7c6369ffdbdd:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdbe2:	mov    r13,r14
    7c6369ffdbe5:	shl    r13,0x10
    7c6369ffdbe9:	mov    rcx,r13
    7c6369ffdbec:	or     rbp,rcx
    7c6369ffdbef:	mov    r13,QWORD PTR [rsp]
    7c6369ffdbf3:	add    r13,0xb
    7c6369ffdbf7:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdbfc:	mov    r13,r14
    7c6369ffdbff:	shl    r13,0x10
    7c6369ffdc03:	mov    rcx,r13
    7c6369ffdc06:	or     r15,rcx
    7c6369ffdc09:	mov    r13,QWORD PTR [rsp]
    7c6369ffdc0d:	add    r13,0xc
    7c6369ffdc11:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdc16:	mov    r13,r14
    7c6369ffdc19:	shl    r13,0x18
    7c6369ffdc1d:	mov    rcx,r13
    7c6369ffdc20:	or     r9,rcx
    7c6369ffdc23:	mov    r13,QWORD PTR [rsp]
    7c6369ffdc27:	add    r13,0xd
    7c6369ffdc2b:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdc30:	mov    r13,r14
    7c6369ffdc33:	shl    r13,0x18
    7c6369ffdc37:	mov    rcx,r13
    7c6369ffdc3a:	or     r8,rcx
    7c6369ffdc3d:	mov    r13,QWORD PTR [rsp]
    7c6369ffdc41:	add    r13,0xe
    7c6369ffdc45:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdc4a:	mov    r13,r14
    7c6369ffdc4d:	shl    r13,0x18
    7c6369ffdc51:	mov    rcx,r13
    7c6369ffdc54:	or     rbp,rcx
    7c6369ffdc57:	mov    r13,QWORD PTR [rsp]
    7c6369ffdc5b:	add    r13,0xf
    7c6369ffdc5f:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdc64:	mov    r13,r14
    7c6369ffdc67:	shl    r13,0x18
    7c6369ffdc6b:	mov    rcx,r13
    7c6369ffdc6e:	or     r15,rcx
    7c6369ffdc71:	mov    r13,QWORD PTR [rsp]
    7c6369ffdc75:	add    r13,0x10
    7c6369ffdc79:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdc7e:	mov    r13,r14
    7c6369ffdc81:	shl    r13,0x20
    7c6369ffdc85:	mov    rcx,r13
    7c6369ffdc88:	or     r9,rcx
    7c6369ffdc8b:	mov    r13,QWORD PTR [rsp]
    7c6369ffdc8f:	add    r13,0x11
    7c6369ffdc93:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdc98:	mov    r13,r14
    7c6369ffdc9b:	shl    r13,0x20
    7c6369ffdc9f:	mov    rcx,r13
    7c6369ffdca2:	or     r8,rcx
    7c6369ffdca5:	mov    r13,QWORD PTR [rsp]
    7c6369ffdca9:	add    r13,0x12
    7c6369ffdcad:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdcb2:	mov    r13,r14
    7c6369ffdcb5:	shl    r13,0x20
    7c6369ffdcb9:	mov    rcx,r13
    7c6369ffdcbc:	or     rbp,rcx
    7c6369ffdcbf:	mov    r13,QWORD PTR [rsp]
    7c6369ffdcc3:	add    r13,0x13
    7c6369ffdcc7:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdccc:	mov    r13,r14
    7c6369ffdccf:	shl    r13,0x20
    7c6369ffdcd3:	mov    rcx,r13
    7c6369ffdcd6:	or     r15,rcx
    7c6369ffdcd9:	mov    r13,QWORD PTR [rsp]
    7c6369ffdcdd:	add    r13,0x14
    7c6369ffdce1:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdce6:	mov    r13,r14
    7c6369ffdce9:	shl    r13,0x28
    7c6369ffdced:	mov    rcx,r13
    7c6369ffdcf0:	or     r9,rcx
    7c6369ffdcf3:	mov    r13,QWORD PTR [rsp]
    7c6369ffdcf7:	add    r13,0x15
    7c6369ffdcfb:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdd00:	mov    r13,r14
    7c6369ffdd03:	shl    r13,0x28
    7c6369ffdd07:	mov    rcx,r13
    7c6369ffdd0a:	or     r8,rcx
    7c6369ffdd0d:	mov    r13,QWORD PTR [rsp]
    7c6369ffdd11:	add    r13,0x16
    7c6369ffdd15:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdd1a:	mov    r13,r14
    7c6369ffdd1d:	shl    r13,0x28
    7c6369ffdd21:	mov    rcx,r13
    7c6369ffdd24:	or     rbp,rcx
    7c6369ffdd27:	mov    r13,QWORD PTR [rsp]
    7c6369ffdd2b:	add    r13,0x17
    7c6369ffdd2f:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdd34:	mov    r13,r14
    7c6369ffdd37:	shl    r13,0x28
    7c6369ffdd3b:	mov    rcx,r13
    7c6369ffdd3e:	or     r15,rcx
    7c6369ffdd41:	mov    r13,QWORD PTR [rsp]
    7c6369ffdd45:	add    r13,0x18
    7c6369ffdd49:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdd4e:	mov    r13,r14
    7c6369ffdd51:	shl    r13,0x30
    7c6369ffdd55:	mov    rcx,r13
    7c6369ffdd58:	or     r9,rcx
    7c6369ffdd5b:	mov    r13,QWORD PTR [rsp]
    7c6369ffdd5f:	add    r13,0x19
    7c6369ffdd63:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdd68:	mov    r13,r14
    7c6369ffdd6b:	shl    r13,0x30
    7c6369ffdd6f:	mov    rcx,r13
    7c6369ffdd72:	or     r8,rcx
    7c6369ffdd75:	mov    r13,QWORD PTR [rsp]
    7c6369ffdd79:	add    r13,0x1a
    7c6369ffdd7d:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdd82:	mov    r13,r14
    7c6369ffdd85:	shl    r13,0x30
    7c6369ffdd89:	mov    rcx,r13
    7c6369ffdd8c:	or     rbp,rcx
    7c6369ffdd8f:	mov    r13,QWORD PTR [rsp]
    7c6369ffdd93:	add    r13,0x1b
    7c6369ffdd97:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffdd9c:	mov    r13,r14
    7c6369ffdd9f:	shl    r13,0x30
    7c6369ffdda3:	mov    rcx,r13
    7c6369ffdda6:	or     r15,rcx
    7c6369ffdda9:	mov    r13,QWORD PTR [rsp]
    7c6369ffddad:	add    r13,0x1c
    7c6369ffddb1:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffddb6:	mov    r13,r14
    7c6369ffddb9:	shl    r13,0x38
    7c6369ffddbd:	mov    rcx,r13
    7c6369ffddc0:	mov    rax,r9
    7c6369ffddc3:	or     rax,rcx
    7c6369ffddc6:	mov    QWORD PTR [rsp+0x40],rax
    7c6369ffddcb:	mov    r13,QWORD PTR [rsp]
    7c6369ffddcf:	add    r13,0x1d
    7c6369ffddd3:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffddd8:	mov    r13,r14
    7c6369ffdddb:	shl    r13,0x38
    7c6369ffdddf:	mov    rcx,r13
    7c6369ffdde2:	mov    rax,r8
    7c6369ffdde5:	or     rax,rcx
    7c6369ffdde8:	mov    QWORD PTR [rsp+0x30],rax
    7c6369ffdded:	mov    r13,QWORD PTR [rsp]
    7c6369ffddf1:	add    r13,0x1e
    7c6369ffddf5:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffddfa:	mov    r13,r14
    7c6369ffddfd:	shl    r13,0x38
    7c6369ffde01:	mov    rcx,r13
    7c6369ffde04:	mov    rax,rbp
    7c6369ffde07:	or     rax,rcx
    7c6369ffde0a:	mov    QWORD PTR [rsp+0x28],rax
    7c6369ffde0f:	mov    r13,QWORD PTR [rsp]
    7c6369ffde13:	add    r13,0x1f
    7c6369ffde17:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffde1c:	mov    r13,r14
    7c6369ffde1f:	shl    r13,0x38
    7c6369ffde23:	mov    rcx,r13
    7c6369ffde26:	mov    rax,r15
    7c6369ffde29:	or     rax,rcx
    7c6369ffde2c:	mov    QWORD PTR [rsp+0x38],rax
    7c6369ffde31:	mov    r13,QWORD PTR [rsp]
    7c6369ffde35:	add    r13,0x20
    7c6369ffde39:	movzx  r14d,BYTE PTR [r13+0x0]
    7c6369ffde3e:	mov    r13,r14
    7c6369ffde41:	mov    rcx,r13
    7c6369ffde44:	mov    r14,QWORD PTR [rsp+0x20]
    7c6369ffde49:	or     r14,rcx
    7c6369ffde4c:	mov    r13,QWORD PTR [rsp]
    7c6369ffde50:	add    r13,0x21
    7c6369ffde54:	movzx  ebp,BYTE PTR [r13+0x0]
    7c6369ffde59:	mov    r13,rbp
    7c6369ffde5c:	mov    rcx,r13
    7c6369ffde5f:	mov    rbp,QWORD PTR [rsp+0x18]
    7c6369ffde64:	or     rbp,rcx
    7c6369ffde67:	mov    r13,QWORD PTR [rsp]
    7c6369ffde6b:	add    r13,0x22
    7c6369ffde6f:	movzx  r8d,BYTE PTR [r13+0x0]
    7c6369ffde74:	mov    r13,r8
    7c6369ffde77:	mov    rcx,r13
    7c6369ffde7a:	mov    r8,QWORD PTR [rsp+0x10]
    7c6369ffde7f:	or     r8,rcx
    7c6369ffde82:	mov    r13,QWORD PTR [rsp]
    7c6369ffde86:	add    r13,0x23
    7c6369ffde8a:	movzx  r15d,BYTE PTR [r13+0x0]
    7c6369ffde8f:	mov    r13,r15
    7c6369ffde92:	mov    rcx,r13
    7c6369ffde95:	mov    r15,QWORD PTR [rsp+0x8]
    7c6369ffde9a:	or     r15,rcx
    7c6369ffde9d:	mov    r13,QWORD PTR [rsp]
    7c6369ffdea1:	add    r13,0x24
    7c6369ffdea5:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdeaa:	mov    r13,r9
    7c6369ffdead:	shl    r13,0x8
    7c6369ffdeb1:	mov    rcx,r13
    7c6369ffdeb4:	or     r14,rcx
    7c6369ffdeb7:	mov    r13,QWORD PTR [rsp]
    7c6369ffdebb:	add    r13,0x25
    7c6369ffdebf:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdec4:	mov    r13,r9
    7c6369ffdec7:	shl    r13,0x8
    7c6369ffdecb:	mov    rcx,r13
    7c6369ffdece:	or     rbp,rcx
    7c6369ffded1:	mov    r13,QWORD PTR [rsp]
    7c6369ffded5:	add    r13,0x26
    7c6369ffded9:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdede:	mov    r13,r9
    7c6369ffdee1:	shl    r13,0x8
    7c6369ffdee5:	mov    rcx,r13
    7c6369ffdee8:	or     r8,rcx
    7c6369ffdeeb:	mov    r13,QWORD PTR [rsp]
    7c6369ffdeef:	add    r13,0x27
    7c6369ffdef3:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdef8:	mov    r13,r9
    7c6369ffdefb:	shl    r13,0x8
    7c6369ffdeff:	mov    rcx,r13
    7c6369ffdf02:	or     r15,rcx
    7c6369ffdf05:	mov    r13,QWORD PTR [rsp]
    7c6369ffdf09:	add    r13,0x28
    7c6369ffdf0d:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdf12:	mov    r13,r9
    7c6369ffdf15:	shl    r13,0x10
    7c6369ffdf19:	mov    rcx,r13
    7c6369ffdf1c:	or     r14,rcx
    7c6369ffdf1f:	mov    r13,QWORD PTR [rsp]
    7c6369ffdf23:	add    r13,0x29
    7c6369ffdf27:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdf2c:	mov    r13,r9
    7c6369ffdf2f:	shl    r13,0x10
    7c6369ffdf33:	mov    rcx,r13
    7c6369ffdf36:	or     rbp,rcx
    7c6369ffdf39:	mov    r13,QWORD PTR [rsp]
    7c6369ffdf3d:	add    r13,0x2a
    7c6369ffdf41:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdf46:	mov    r13,r9
    7c6369ffdf49:	shl    r13,0x10
    7c6369ffdf4d:	mov    rcx,r13
    7c6369ffdf50:	or     r8,rcx
    7c6369ffdf53:	mov    r13,QWORD PTR [rsp]
    7c6369ffdf57:	add    r13,0x2b
    7c6369ffdf5b:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdf60:	mov    r13,r9
    7c6369ffdf63:	shl    r13,0x10
    7c6369ffdf67:	mov    rcx,r13
    7c6369ffdf6a:	or     r15,rcx
    7c6369ffdf6d:	mov    r13,QWORD PTR [rsp]
    7c6369ffdf71:	add    r13,0x2c
    7c6369ffdf75:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdf7a:	mov    r13,r9
    7c6369ffdf7d:	shl    r13,0x18
    7c6369ffdf81:	mov    rcx,r13
    7c6369ffdf84:	or     r14,rcx
    7c6369ffdf87:	mov    r13,QWORD PTR [rsp]
    7c6369ffdf8b:	add    r13,0x2d
    7c6369ffdf8f:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdf94:	mov    r13,r9
    7c6369ffdf97:	shl    r13,0x18
    7c6369ffdf9b:	mov    rcx,r13
    7c6369ffdf9e:	or     rbp,rcx
    7c6369ffdfa1:	mov    r13,QWORD PTR [rsp]
    7c6369ffdfa5:	add    r13,0x2e
    7c6369ffdfa9:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdfae:	mov    r13,r9
    7c6369ffdfb1:	shl    r13,0x18
    7c6369ffdfb5:	mov    rcx,r13
    7c6369ffdfb8:	or     r8,rcx
    7c6369ffdfbb:	mov    r13,QWORD PTR [rsp]
    7c6369ffdfbf:	add    r13,0x2f
    7c6369ffdfc3:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdfc8:	mov    r13,r9
    7c6369ffdfcb:	shl    r13,0x18
    7c6369ffdfcf:	mov    rcx,r13
    7c6369ffdfd2:	or     r15,rcx
    7c6369ffdfd5:	mov    r13,QWORD PTR [rsp]
    7c6369ffdfd9:	add    r13,0x30
    7c6369ffdfdd:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdfe2:	mov    r13,r9
    7c6369ffdfe5:	shl    r13,0x20
    7c6369ffdfe9:	mov    rcx,r13
    7c6369ffdfec:	or     r14,rcx
    7c6369ffdfef:	mov    r13,QWORD PTR [rsp]
    7c6369ffdff3:	add    r13,0x31
    7c6369ffdff7:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffdffc:	mov    r13,r9
    7c6369ffdfff:	shl    r13,0x20
    7c6369ffe003:	mov    rcx,r13
    7c6369ffe006:	or     rbp,rcx
    7c6369ffe009:	mov    r13,QWORD PTR [rsp]
    7c6369ffe00d:	add    r13,0x32
    7c6369ffe011:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe016:	mov    r13,r9
    7c6369ffe019:	shl    r13,0x20
    7c6369ffe01d:	mov    rcx,r13
    7c6369ffe020:	or     r8,rcx
    7c6369ffe023:	mov    r13,QWORD PTR [rsp]
    7c6369ffe027:	add    r13,0x33
    7c6369ffe02b:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe030:	mov    r13,r9
    7c6369ffe033:	shl    r13,0x20
    7c6369ffe037:	mov    rcx,r13
    7c6369ffe03a:	or     r15,rcx
    7c6369ffe03d:	mov    r13,QWORD PTR [rsp]
    7c6369ffe041:	add    r13,0x34
    7c6369ffe045:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe04a:	mov    r13,r9
    7c6369ffe04d:	shl    r13,0x28
    7c6369ffe051:	mov    rcx,r13
    7c6369ffe054:	or     r14,rcx
    7c6369ffe057:	mov    r13,QWORD PTR [rsp]
    7c6369ffe05b:	add    r13,0x35
    7c6369ffe05f:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe064:	mov    r13,r9
    7c6369ffe067:	shl    r13,0x28
    7c6369ffe06b:	mov    rcx,r13
    7c6369ffe06e:	or     rbp,rcx
    7c6369ffe071:	mov    r13,QWORD PTR [rsp]
    7c6369ffe075:	add    r13,0x36
    7c6369ffe079:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe07e:	mov    r13,r9
    7c6369ffe081:	shl    r13,0x28
    7c6369ffe085:	mov    rcx,r13
    7c6369ffe088:	or     r8,rcx
    7c6369ffe08b:	mov    r13,QWORD PTR [rsp]
    7c6369ffe08f:	add    r13,0x37
    7c6369ffe093:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe098:	mov    r13,r9
    7c6369ffe09b:	shl    r13,0x28
    7c6369ffe09f:	mov    rcx,r13
    7c6369ffe0a2:	or     r15,rcx
    7c6369ffe0a5:	mov    r13,QWORD PTR [rsp]
    7c6369ffe0a9:	add    r13,0x38
    7c6369ffe0ad:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe0b2:	mov    r13,r9
    7c6369ffe0b5:	shl    r13,0x30
    7c6369ffe0b9:	mov    rcx,r13
    7c6369ffe0bc:	or     r14,rcx
    7c6369ffe0bf:	mov    r13,QWORD PTR [rsp]
    7c6369ffe0c3:	add    r13,0x39
    7c6369ffe0c7:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe0cc:	mov    r13,r9
    7c6369ffe0cf:	shl    r13,0x30
    7c6369ffe0d3:	mov    rcx,r13
    7c6369ffe0d6:	or     rbp,rcx
    7c6369ffe0d9:	mov    r13,QWORD PTR [rsp]
    7c6369ffe0dd:	add    r13,0x3a
    7c6369ffe0e1:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe0e6:	mov    r13,r9
    7c6369ffe0e9:	shl    r13,0x30
    7c6369ffe0ed:	mov    rcx,r13
    7c6369ffe0f0:	or     r8,rcx
    7c6369ffe0f3:	mov    r13,QWORD PTR [rsp]
    7c6369ffe0f7:	add    r13,0x3b
    7c6369ffe0fb:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe100:	mov    r13,r9
    7c6369ffe103:	shl    r13,0x30
    7c6369ffe107:	mov    rcx,r13
    7c6369ffe10a:	or     r15,rcx
    7c6369ffe10d:	mov    r13,QWORD PTR [rsp]
    7c6369ffe111:	add    r13,0x3c
    7c6369ffe115:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe11a:	mov    r13,r9
    7c6369ffe11d:	shl    r13,0x38
    7c6369ffe121:	mov    rcx,r13
    7c6369ffe124:	or     r14,rcx
    7c6369ffe127:	mov    r13,QWORD PTR [rsp]
    7c6369ffe12b:	add    r13,0x3d
    7c6369ffe12f:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe134:	mov    r13,r9
    7c6369ffe137:	shl    r13,0x38
    7c6369ffe13b:	mov    rcx,r13
    7c6369ffe13e:	or     rbp,rcx
    7c6369ffe141:	mov    r13,QWORD PTR [rsp]
    7c6369ffe145:	add    r13,0x3e
    7c6369ffe149:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe14e:	mov    r13,r9
    7c6369ffe151:	shl    r13,0x38
    7c6369ffe155:	mov    rcx,r13
    7c6369ffe158:	or     r8,rcx
    7c6369ffe15b:	mov    r13,QWORD PTR [rsp]
    7c6369ffe15f:	add    r13,0x3f
    7c6369ffe163:	movzx  r9d,BYTE PTR [r13+0x0]
    7c6369ffe168:	mov    r13,r9
    7c6369ffe16b:	shl    r13,0x38
    7c6369ffe16f:	mov    rcx,r13
    7c6369ffe172:	or     r15,rcx
    7c6369ffe175:	mov    rax,QWORD PTR [rsp+0x40]
    7c6369ffe17a:	mov    QWORD PTR [r12+0x110],rax
    7c6369ffe182:	mov    QWORD PTR [r12+0x118],r14
    7c6369ffe18a:	mov    rax,QWORD PTR [rsp+0x30]
    7c6369ffe18f:	mov    QWORD PTR [r12+0x120],rax
    7c6369ffe197:	mov    QWORD PTR [r12+0x128],rbp
    7c6369ffe19f:	mov    rax,QWORD PTR [rsp+0x28]
    7c6369ffe1a4:	mov    QWORD PTR [r12+0x130],rax
    7c6369ffe1ac:	mov    QWORD PTR [r12+0x138],r8
    7c6369ffe1b4:	mov    rax,QWORD PTR [rsp+0x38]
    7c6369ffe1b9:	mov    QWORD PTR [r12+0x140],rax
    7c6369ffe1c1:	mov    QWORD PTR [r12+0x148],r15
    7c6369ffe1c9:	mov    r13d,0x0
    7c6369ffe1cf:	mov    QWORD PTR [r12+0x58],r13
    7c6369ffe1d4:	mov    r13d,0x0
    7c6369ffe1da:	mov    r14,QWORD PTR [rsp+0x30]
    7c6369ffe1df:	and    r14,0xff
    7c6369ffe1e6:	and    r14,0xffff
    7c6369ffe1ed:	mov    rcx,r14
    7c6369ffe1f0:	mov    r15,r13
    7c6369ffe1f3:	or     r15,rcx
    7c6369ffe1f6:	mov    r14,QWORD PTR [rsp+0x30]
    7c6369ffe1fb:	shr    r14,0x8
    7c6369ffe1ff:	and    r14,0xff
    7c6369ffe206:	and    r14,0xffff
    7c6369ffe20d:	shl    r14,0x10
    7c6369ffe211:	mov    rcx,r14
    7c6369ffe214:	or     r15,rcx
    7c6369ffe217:	mov    r14,QWORD PTR [rsp+0x30]
    7c6369ffe21c:	shr    r14,0x10
    7c6369ffe220:	and    r14,0xff
    7c6369ffe227:	and    r14,0xffff
    7c6369ffe22e:	shl    r14,0x20
    7c6369ffe232:	mov    rcx,r14
    7c6369ffe235:	or     r15,rcx
    7c6369ffe238:	mov    r14,QWORD PTR [rsp+0x30]
    7c6369ffe23d:	shr    r14,0x18
    7c6369ffe241:	and    r14,0xff
    7c6369ffe248:	and    r14,0xffff
    7c6369ffe24f:	shl    r14,0x30
    7c6369ffe253:	mov    rcx,r14
    7c6369ffe256:	or     r15,rcx
    7c6369ffe259:	mov    r14,QWORD PTR [rsp+0x30]
    7c6369ffe25e:	shr    r14,0x20
    7c6369ffe262:	and    r14,0xff
    7c6369ffe269:	and    r14,0xffff
    7c6369ffe270:	mov    rcx,r14
    7c6369ffe273:	or     r13,rcx
    7c6369ffe276:	mov    r14,QWORD PTR [rsp+0x30]
    7c6369ffe27b:	shr    r14,0x28
    7c6369ffe27f:	and    r14,0xff
    7c6369ffe286:	and    r14,0xffff
    7c6369ffe28d:	shl    r14,0x10
    7c6369ffe291:	mov    rcx,r14
    7c6369ffe294:	or     r13,rcx
    7c6369ffe297:	mov    r14,QWORD PTR [rsp+0x30]
    7c6369ffe29c:	shr    r14,0x30
    7c6369ffe2a0:	and    r14,0xff
    7c6369ffe2a7:	and    r14,0xffff
    7c6369ffe2ae:	shl    r14,0x20
    7c6369ffe2b2:	mov    rcx,r14
    7c6369ffe2b5:	or     r13,rcx
    7c6369ffe2b8:	mov    r14,QWORD PTR [rsp+0x30]
    7c6369ffe2bd:	shr    r14,0x38
    7c6369ffe2c1:	and    r14,0xff
    7c6369ffe2c8:	and    r14,0xffff
    7c6369ffe2cf:	shl    r14,0x30
    7c6369ffe2d3:	mov    rcx,r14
    7c6369ffe2d6:	or     r13,rcx
    7c6369ffe2d9:	mov    QWORD PTR [r12+0x150],r15
    7c6369ffe2e1:	mov    QWORD PTR [r12+0x158],r13
    7c6369ffe2e9:	mov    r13d,0x0
    7c6369ffe2ef:	mov    r14,QWORD PTR [rsp+0x28]
    7c6369ffe2f4:	and    r14,0xff
    7c6369ffe2fb:	and    r14,0xffff
    7c6369ffe302:	mov    rcx,r14
    7c6369ffe305:	mov    r15,r13
    7c6369ffe308:	or     r15,rcx
    7c6369ffe30b:	mov    r14,QWORD PTR [rsp+0x28]
    7c6369ffe310:	shr    r14,0x8
    7c6369ffe314:	and    r14,0xff
    7c6369ffe31b:	and    r14,0xffff
    7c6369ffe322:	shl    r14,0x10
    7c6369ffe326:	mov    rcx,r14
    7c6369ffe329:	or     r15,rcx
    7c6369ffe32c:	mov    r14,QWORD PTR [rsp+0x28]
    7c6369ffe331:	shr    r14,0x10
    7c6369ffe335:	and    r14,0xff
    7c6369ffe33c:	and    r14,0xffff
    7c6369ffe343:	shl    r14,0x20
    7c6369ffe347:	mov    rcx,r14
    7c6369ffe34a:	or     r15,rcx
    7c6369ffe34d:	mov    r14,QWORD PTR [rsp+0x28]
    7c6369ffe352:	shr    r14,0x18
    7c6369ffe356:	and    r14,0xff
    7c6369ffe35d:	and    r14,0xffff
    7c6369ffe364:	shl    r14,0x30
    7c6369ffe368:	mov    rcx,r14
    7c6369ffe36b:	or     r15,rcx
    7c6369ffe36e:	mov    r14,QWORD PTR [rsp+0x28]
    7c6369ffe373:	shr    r14,0x20
    7c6369ffe377:	and    r14,0xff
    7c6369ffe37e:	and    r14,0xffff
    7c6369ffe385:	mov    rcx,r14
    7c6369ffe388:	or     r13,rcx
    7c6369ffe38b:	mov    r14,QWORD PTR [rsp+0x28]
    7c6369ffe390:	shr    r14,0x28
    7c6369ffe394:	and    r14,0xff
    7c6369ffe39b:	and    r14,0xffff
    7c6369ffe3a2:	shl    r14,0x10
    7c6369ffe3a6:	mov    rcx,r14
    7c6369ffe3a9:	or     r13,rcx
    7c6369ffe3ac:	mov    r14,QWORD PTR [rsp+0x28]
    7c6369ffe3b1:	shr    r14,0x30
    7c6369ffe3b5:	and    r14,0xff
    7c6369ffe3bc:	and    r14,0xffff
    7c6369ffe3c3:	shl    r14,0x20
    7c6369ffe3c7:	mov    rcx,r14
    7c6369ffe3ca:	or     r13,rcx
    7c6369ffe3cd:	mov    r14,QWORD PTR [rsp+0x28]
    7c6369ffe3d2:	shr    r14,0x38
    7c6369ffe3d6:	and    r14,0xff
    7c6369ffe3dd:	and    r14,0xffff
    7c6369ffe3e4:	shl    r14,0x30
    7c6369ffe3e8:	mov    rcx,r14
    7c6369ffe3eb:	or     r13,rcx
    7c6369ffe3ee:	mov    QWORD PTR [r12+0x160],r15
    7c6369ffe3f6:	mov    QWORD PTR [r12+0x168],r13
    7c6369ffe3fe:	mov    r13,QWORD PTR [r12+0x110]
    7c6369ffe406:	mov    r14d,0x0
    7c6369ffe40c:	mov    r15,r13
    7c6369ffe40f:	and    r15,0xff
    7c6369ffe416:	and    r15,0xffff
    7c6369ffe41d:	mov    rcx,r15
    7c6369ffe420:	mov    rbp,r14
    7c6369ffe423:	or     rbp,rcx
    7c6369ffe426:	mov    r15,r13
    7c6369ffe429:	shr    r15,0x8
    7c6369ffe42d:	and    r15,0xff
    7c6369ffe434:	and    r15,0xffff
    7c6369ffe43b:	shl    r15,0x10
    7c6369ffe43f:	mov    rcx,r15
    7c6369ffe442:	or     rbp,rcx
    7c6369ffe445:	mov    r15,r13
    7c6369ffe448:	shr    r15,0x10
    7c6369ffe44c:	and    r15,0xff
    7c6369ffe453:	and    r15,0xffff
    7c6369ffe45a:	shl    r15,0x20
    7c6369ffe45e:	mov    rcx,r15
    7c6369ffe461:	or     rbp,rcx
    7c6369ffe464:	mov    r15,r13
    7c6369ffe467:	shr    r15,0x18
    7c6369ffe46b:	and    r15,0xff
    7c6369ffe472:	and    r15,0xffff
    7c6369ffe479:	shl    r15,0x30
    7c6369ffe47d:	mov    rcx,r15
    7c6369ffe480:	or     rbp,rcx
    7c6369ffe483:	mov    r15,r13
    7c6369ffe486:	shr    r15,0x20
    7c6369ffe48a:	and    r15,0xff
    7c6369ffe491:	and    r15,0xffff
    7c6369ffe498:	mov    rcx,r15
    7c6369ffe49b:	or     r14,rcx
    7c6369ffe49e:	mov    r15,r13
    7c6369ffe4a1:	shr    r15,0x28
    7c6369ffe4a5:	and    r15,0xff
    7c6369ffe4ac:	and    r15,0xffff
    7c6369ffe4b3:	shl    r15,0x10
    7c6369ffe4b7:	mov    rcx,r15
    7c6369ffe4ba:	or     r14,rcx
    7c6369ffe4bd:	mov    r15,r13
    7c6369ffe4c0:	shr    r15,0x30
    7c6369ffe4c4:	and    r15,0xff
    7c6369ffe4cb:	and    r15,0xffff
    7c6369ffe4d2:	shl    r15,0x20
    7c6369ffe4d6:	mov    rcx,r15
    7c6369ffe4d9:	or     r14,rcx
    7c6369ffe4dc:	shr    r13,0x38
    7c6369ffe4e0:	and    r13,0xff
    7c6369ffe4e7:	and    r13,0xffff
    7c6369ffe4ee:	shl    r13,0x30
    7c6369ffe4f2:	mov    rcx,r13
    7c6369ffe4f5:	or     r14,rcx
    7c6369ffe4f8:	mov    QWORD PTR [r12+0x170],rbp
    7c6369ffe500:	mov    QWORD PTR [r12+0x178],r14
    7c6369ffe508:	mov    r13,QWORD PTR [r12+0x118]
    7c6369ffe510:	mov    r14d,0x0
    7c6369ffe516:	mov    r15,r13
    7c6369ffe519:	and    r15,0xff
    7c6369ffe520:	and    r15,0xffff
    7c6369ffe527:	mov    rcx,r15
    7c6369ffe52a:	mov    rbp,r14
    7c6369ffe52d:	or     rbp,rcx
    7c6369ffe530:	mov    r15,r13
    7c6369ffe533:	shr    r15,0x8
    7c6369ffe537:	and    r15,0xff
    7c6369ffe53e:	and    r15,0xffff
    7c6369ffe545:	shl    r15,0x10
    7c6369ffe549:	mov    rcx,r15
    7c6369ffe54c:	or     rbp,rcx
    7c6369ffe54f:	mov    r15,r13
    7c6369ffe552:	shr    r15,0x10
    7c6369ffe556:	and    r15,0xff
    7c6369ffe55d:	and    r15,0xffff
    7c6369ffe564:	shl    r15,0x20
    7c6369ffe568:	mov    rcx,r15
    7c6369ffe56b:	or     rbp,rcx
    7c6369ffe56e:	mov    r15,r13
    7c6369ffe571:	shr    r15,0x18
    7c6369ffe575:	and    r15,0xff
    7c6369ffe57c:	and    r15,0xffff
    7c6369ffe583:	shl    r15,0x30
    7c6369ffe587:	mov    rcx,r15
    7c6369ffe58a:	or     rbp,rcx
    7c6369ffe58d:	mov    r15,r13
    7c6369ffe590:	shr    r15,0x20
    7c6369ffe594:	and    r15,0xff
    7c6369ffe59b:	and    r15,0xffff
    7c6369ffe5a2:	mov    rcx,r15
    7c6369ffe5a5:	or     r14,rcx
    7c6369ffe5a8:	mov    r15,r13
    7c6369ffe5ab:	shr    r15,0x28
    7c6369ffe5af:	and    r15,0xff
    7c6369ffe5b6:	and    r15,0xffff
    7c6369ffe5bd:	shl    r15,0x10
    7c6369ffe5c1:	mov    rcx,r15
    7c6369ffe5c4:	or     r14,rcx
    7c6369ffe5c7:	mov    r15,r13
    7c6369ffe5ca:	shr    r15,0x30
    7c6369ffe5ce:	and    r15,0xff
    7c6369ffe5d5:	and    r15,0xffff
    7c6369ffe5dc:	shl    r15,0x20
    7c6369ffe5e0:	mov    rcx,r15
    7c6369ffe5e3:	or     r14,rcx
    7c6369ffe5e6:	shr    r13,0x38
    7c6369ffe5ea:	and    r13,0xff
    7c6369ffe5f1:	and    r13,0xffff
    7c6369ffe5f8:	shl    r13,0x30
    7c6369ffe5fc:	mov    rcx,r13
    7c6369ffe5ff:	or     r14,rcx
    7c6369ffe602:	mov    QWORD PTR [r12+0x180],rbp
    7c6369ffe60a:	mov    QWORD PTR [r12+0x188],r14
    7c6369ffe612:	mov    r13,QWORD PTR [r12+0x128]
    7c6369ffe61a:	mov    r14d,0x0
    7c6369ffe620:	mov    r15,r13
    7c6369ffe623:	and    r15,0xff
    7c6369ffe62a:	and    r15,0xffff
    7c6369ffe631:	mov    rcx,r15
    7c6369ffe634:	mov    rbp,r14
    7c6369ffe637:	or     rbp,rcx
    7c6369ffe63a:	mov    r15,r13
    7c6369ffe63d:	shr    r15,0x8
    7c6369ffe641:	and    r15,0xff
    7c6369ffe648:	and    r15,0xffff
    7c6369ffe64f:	shl    r15,0x10
    7c6369ffe653:	mov    rcx,r15
    7c6369ffe656:	or     rbp,rcx
    7c6369ffe659:	mov    r15,r13
    7c6369ffe65c:	shr    r15,0x10
    7c6369ffe660:	and    r15,0xff
    7c6369ffe667:	and    r15,0xffff
    7c6369ffe66e:	shl    r15,0x20
    7c6369ffe672:	mov    rcx,r15
    7c6369ffe675:	or     rbp,rcx
    7c6369ffe678:	mov    r15,r13
    7c6369ffe67b:	shr    r15,0x18
    7c6369ffe67f:	and    r15,0xff
    7c6369ffe686:	and    r15,0xffff
    7c6369ffe68d:	shl    r15,0x30
    7c6369ffe691:	mov    rcx,r15
    7c6369ffe694:	or     rbp,rcx
    7c6369ffe697:	mov    r15,r13
    7c6369ffe69a:	shr    r15,0x20
    7c6369ffe69e:	and    r15,0xff
    7c6369ffe6a5:	and    r15,0xffff
    7c6369ffe6ac:	mov    rcx,r15
    7c6369ffe6af:	or     r14,rcx
    7c6369ffe6b2:	mov    r15,r13
    7c6369ffe6b5:	shr    r15,0x28
    7c6369ffe6b9:	and    r15,0xff
    7c6369ffe6c0:	and    r15,0xffff
    7c6369ffe6c7:	shl    r15,0x10
    7c6369ffe6cb:	mov    rcx,r15
    7c6369ffe6ce:	or     r14,rcx
    7c6369ffe6d1:	mov    r15,r13
    7c6369ffe6d4:	shr    r15,0x30
    7c6369ffe6d8:	and    r15,0xff
    7c6369ffe6df:	and    r15,0xffff
    7c6369ffe6e6:	shl    r15,0x20
    7c6369ffe6ea:	mov    rcx,r15
    7c6369ffe6ed:	or     r14,rcx
    7c6369ffe6f0:	shr    r13,0x38
    7c6369ffe6f4:	and    r13,0xff
    7c6369ffe6fb:	and    r13,0xffff
    7c6369ffe702:	shl    r13,0x30
    7c6369ffe706:	mov    rcx,r13
    7c6369ffe709:	or     r14,rcx
    7c6369ffe70c:	mov    QWORD PTR [r12+0x210],rbp
    7c6369ffe714:	mov    QWORD PTR [r12+0x218],r14
    7c6369ffe71c:	mov    r13,QWORD PTR [r12+0x138]
    7c6369ffe724:	mov    r14d,0x0
    7c6369ffe72a:	mov    r15,r13
    7c6369ffe72d:	and    r15,0xff
    7c6369ffe734:	and    r15,0xffff
    7c6369ffe73b:	mov    rcx,r15
    7c6369ffe73e:	mov    rbp,r14
    7c6369ffe741:	or     rbp,rcx
    7c6369ffe744:	mov    r15,r13
    7c6369ffe747:	shr    r15,0x8
    7c6369ffe74b:	and    r15,0xff
    7c6369ffe752:	and    r15,0xffff
    7c6369ffe759:	shl    r15,0x10
    7c6369ffe75d:	mov    rcx,r15
    7c6369ffe760:	or     rbp,rcx
    7c6369ffe763:	mov    r15,r13
    7c6369ffe766:	shr    r15,0x10
    7c6369ffe76a:	and    r15,0xff
    7c6369ffe771:	and    r15,0xffff
    7c6369ffe778:	shl    r15,0x20
    7c6369ffe77c:	mov    rcx,r15
    7c6369ffe77f:	or     rbp,rcx
    7c6369ffe782:	mov    r15,r13
    7c6369ffe785:	shr    r15,0x18
    7c6369ffe789:	and    r15,0xff
    7c6369ffe790:	and    r15,0xffff
    7c6369ffe797:	shl    r15,0x30
    7c6369ffe79b:	mov    rcx,r15
    7c6369ffe79e:	or     rbp,rcx
    7c6369ffe7a1:	mov    r15,r13
    7c6369ffe7a4:	shr    r15,0x20
    7c6369ffe7a8:	and    r15,0xff
    7c6369ffe7af:	and    r15,0xffff
    7c6369ffe7b6:	mov    rcx,r15
    7c6369ffe7b9:	or     r14,rcx
    7c6369ffe7bc:	mov    r15,r13
    7c6369ffe7bf:	shr    r15,0x28
    7c6369ffe7c3:	and    r15,0xff
    7c6369ffe7ca:	and    r15,0xffff
    7c6369ffe7d1:	shl    r15,0x10
    7c6369ffe7d5:	mov    rcx,r15
    7c6369ffe7d8:	or     r14,rcx
    7c6369ffe7db:	mov    r15,r13
    7c6369ffe7de:	shr    r15,0x30
    7c6369ffe7e2:	and    r15,0xff
    7c6369ffe7e9:	and    r15,0xffff
    7c6369ffe7f0:	shl    r15,0x20
    7c6369ffe7f4:	mov    rcx,r15
    7c6369ffe7f7:	or     r14,rcx
    7c6369ffe7fa:	shr    r13,0x38
    7c6369ffe7fe:	and    r13,0xff
    7c6369ffe805:	and    r13,0xffff
    7c6369ffe80c:	shl    r13,0x30
    7c6369ffe810:	mov    rcx,r13
    7c6369ffe813:	or     r14,rcx
    7c6369ffe816:	mov    QWORD PTR [r12+0x220],rbp
    7c6369ffe81e:	mov    QWORD PTR [r12+0x228],r14
    7c6369ffe826:	mov    r13,QWORD PTR [r12+0x140]
    7c6369ffe82e:	mov    r14d,0x0
    7c6369ffe834:	mov    r15,r13
    7c6369ffe837:	and    r15,0xff
    7c6369ffe83e:	and    r15,0xffff
    7c6369ffe845:	mov    rcx,r15
    7c6369ffe848:	mov    rbp,r14
    7c6369ffe84b:	or     rbp,rcx
    7c6369ffe84e:	mov    r15,r13
    7c6369ffe851:	shr    r15,0x8
    7c6369ffe855:	and    r15,0xff
    7c6369ffe85c:	and    r15,0xffff
    7c6369ffe863:	shl    r15,0x10
    7c6369ffe867:	mov    rcx,r15
    7c6369ffe86a:	or     rbp,rcx
    7c6369ffe86d:	mov    r15,r13
    7c6369ffe870:	shr    r15,0x10
    7c6369ffe874:	and    r15,0xff
    7c6369ffe87b:	and    r15,0xffff
    7c6369ffe882:	shl    r15,0x20
    7c6369ffe886:	mov    rcx,r15
    7c6369ffe889:	or     rbp,rcx
    7c6369ffe88c:	mov    r15,r13
    7c6369ffe88f:	shr    r15,0x18
    7c6369ffe893:	and    r15,0xff
    7c6369ffe89a:	and    r15,0xffff
    7c6369ffe8a1:	shl    r15,0x30
    7c6369ffe8a5:	mov    rcx,r15
    7c6369ffe8a8:	or     rbp,rcx
    7c6369ffe8ab:	mov    r15,r13
    7c6369ffe8ae:	shr    r15,0x20
    7c6369ffe8b2:	and    r15,0xff
    7c6369ffe8b9:	and    r15,0xffff
    7c6369ffe8c0:	mov    rcx,r15
    7c6369ffe8c3:	or     r14,rcx
    7c6369ffe8c6:	mov    r15,r13
    7c6369ffe8c9:	shr    r15,0x28
    7c6369ffe8cd:	and    r15,0xff
    7c6369ffe8d4:	and    r15,0xffff
    7c6369ffe8db:	shl    r15,0x10
    7c6369ffe8df:	mov    rcx,r15
    7c6369ffe8e2:	or     r14,rcx
    7c6369ffe8e5:	mov    r15,r13
    7c6369ffe8e8:	shr    r15,0x30
    7c6369ffe8ec:	and    r15,0xff
    7c6369ffe8f3:	and    r15,0xffff
    7c6369ffe8fa:	shl    r15,0x20
    7c6369ffe8fe:	mov    rcx,r15
    7c6369ffe901:	or     r14,rcx
    7c6369ffe904:	shr    r13,0x38
    7c6369ffe908:	and    r13,0xff
    7c6369ffe90f:	and    r13,0xffff
    7c6369ffe916:	shl    r13,0x30
    7c6369ffe91a:	mov    rcx,r13
    7c6369ffe91d:	or     r14,rcx
    7c6369ffe920:	mov    QWORD PTR [r12+0x250],rbp
    7c6369ffe928:	mov    QWORD PTR [r12+0x258],r14
    7c6369ffe930:	mov    r13,QWORD PTR [r12+0x148]
    7c6369ffe938:	mov    r14d,0x0
    7c6369ffe93e:	mov    r15,r13
    7c6369ffe941:	and    r15,0xff
    7c6369ffe948:	and    r15,0xffff
    7c6369ffe94f:	mov    rcx,r15
    7c6369ffe952:	mov    rbp,r14
    7c6369ffe955:	or     rbp,rcx
    7c6369ffe958:	mov    r15,r13
    7c6369ffe95b:	shr    r15,0x8
    7c6369ffe95f:	and    r15,0xff
    7c6369ffe966:	and    r15,0xffff
    7c6369ffe96d:	shl    r15,0x10
    7c6369ffe971:	mov    rcx,r15
    7c6369ffe974:	or     rbp,rcx
    7c6369ffe977:	mov    r15,r13
    7c6369ffe97a:	shr    r15,0x10
    7c6369ffe97e:	and    r15,0xff
    7c6369ffe985:	and    r15,0xffff
    7c6369ffe98c:	shl    r15,0x20
    7c6369ffe990:	mov    rcx,r15
    7c6369ffe993:	or     rbp,rcx
    7c6369ffe996:	mov    r15,r13
    7c6369ffe999:	shr    r15,0x18
    7c6369ffe99d:	and    r15,0xff
    7c6369ffe9a4:	and    r15,0xffff
    7c6369ffe9ab:	shl    r15,0x30
    7c6369ffe9af:	mov    rcx,r15
    7c6369ffe9b2:	or     rbp,rcx
    7c6369ffe9b5:	mov    r15,r13
    7c6369ffe9b8:	shr    r15,0x20
    7c6369ffe9bc:	and    r15,0xff
    7c6369ffe9c3:	and    r15,0xffff
    7c6369ffe9ca:	mov    rcx,r15
    7c6369ffe9cd:	or     r14,rcx
    7c6369ffe9d0:	mov    r15,r13
    7c6369ffe9d3:	shr    r15,0x28
    7c6369ffe9d7:	and    r15,0xff
    7c6369ffe9de:	and    r15,0xffff
    7c6369ffe9e5:	shl    r15,0x10
    7c6369ffe9e9:	mov    rcx,r15
    7c6369ffe9ec:	or     r14,rcx
    7c6369ffe9ef:	mov    r15,r13
    7c6369ffe9f2:	shr    r15,0x30
    7c6369ffe9f6:	and    r15,0xff
    7c6369ffe9fd:	and    r15,0xffff
    7c6369ffea04:	shl    r15,0x20
    7c6369ffea08:	mov    rcx,r15
    7c6369ffea0b:	or     r14,rcx
    7c6369ffea0e:	shr    r13,0x38
    7c6369ffea12:	and    r13,0xff
    7c6369ffea19:	and    r13,0xffff
    7c6369ffea20:	shl    r13,0x30
    7c6369ffea24:	mov    rcx,r13
    7c6369ffea27:	or     r14,rcx
    7c6369ffea2a:	mov    QWORD PTR [r12+0x110],rbp
    7c6369ffea32:	mov    QWORD PTR [r12+0x118],r14
    7c6369ffea3a:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c6369ffea44:	movdqa xmm2,xmm0
    7c6369ffea48:	pxor   xmm0,xmm0
    7c6369ffea4c:	movdqa xmm3,xmm0
    7c6369ffea50:	movdqa xmm0,xmm2
    7c6369ffea54:	movdqa xmm1,xmm3
    7c6369ffea58:	punpcklwd xmm0,xmm1
    7c6369ffea5c:	movdqa xmm4,xmm0
    7c6369ffea60:	movdqa xmm0,xmm4
    7c6369ffea64:	pslld  xmm0,0x10
    7c6369ffea69:	movdqa xmm2,xmm0
    7c6369ffea6d:	movdqa xmm0,xmm2
    7c6369ffea71:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c6369ffea7b:	mov    r13,QWORD PTR [r12+0x160]
    7c6369ffea83:	mov    r14d,0x0
    7c6369ffea89:	mov    r15,r13
    7c6369ffea8c:	and    r15,0xffff
    7c6369ffea93:	shl    r15,0x8
    7c6369ffea97:	mov    ecx,0xffffffff
    7c6369ffea9c:	and    r15,rcx
    7c6369ffea9f:	mov    rcx,r15
    7c6369ffeaa2:	mov    rbp,r14
    7c6369ffeaa5:	or     rbp,rcx
    7c6369ffeaa8:	mov    r15,r13
    7c6369ffeaab:	shr    r15,0x10
    7c6369ffeaaf:	and    r15,0xffff
    7c6369ffeab6:	shl    r15,0x8
    7c6369ffeaba:	mov    ecx,0xffffffff
    7c6369ffeabf:	and    r15,rcx
    7c6369ffeac2:	shl    r15,0x20
    7c6369ffeac6:	mov    rcx,r15
    7c6369ffeac9:	or     rbp,rcx
    7c6369ffeacc:	mov    r15,r13
    7c6369ffeacf:	shr    r15,0x20
    7c6369ffead3:	and    r15,0xffff
    7c6369ffeada:	shl    r15,0x8
    7c6369ffeade:	mov    ecx,0xffffffff
    7c6369ffeae3:	and    r15,rcx
    7c6369ffeae6:	mov    rcx,r15
    7c6369ffeae9:	or     r14,rcx
    7c6369ffeaec:	shr    r13,0x30
    7c6369ffeaf0:	and    r13,0xffff
    7c6369ffeaf7:	shl    r13,0x8
    7c6369ffeafb:	mov    ecx,0xffffffff
    7c6369ffeb00:	and    r13,rcx
    7c6369ffeb03:	shl    r13,0x20
    7c6369ffeb07:	mov    rcx,r13
    7c6369ffeb0a:	or     r14,rcx
    7c6369ffeb0d:	mov    QWORD PTR [r12+0x240],rbp
    7c6369ffeb15:	mov    QWORD PTR [r12+0x248],r14
    7c6369ffeb1d:	mov    r13,QWORD PTR [r12+0x178]
    7c6369ffeb25:	mov    r14d,0x0
    7c6369ffeb2b:	mov    r15,r13
    7c6369ffeb2e:	and    r15,0xffff
    7c6369ffeb35:	mov    ecx,0xffffffff
    7c6369ffeb3a:	and    r15,rcx
    7c6369ffeb3d:	mov    rcx,r15
    7c6369ffeb40:	mov    rbp,r14
    7c6369ffeb43:	or     rbp,rcx
    7c6369ffeb46:	mov    r15,r13
    7c6369ffeb49:	shr    r15,0x10
    7c6369ffeb4d:	and    r15,0xffff
    7c6369ffeb54:	mov    ecx,0xffffffff
    7c6369ffeb59:	and    r15,rcx
    7c6369ffeb5c:	shl    r15,0x20
    7c6369ffeb60:	mov    rcx,r15
    7c6369ffeb63:	or     rbp,rcx
    7c6369ffeb66:	mov    r15,r13
    7c6369ffeb69:	shr    r15,0x20
    7c6369ffeb6d:	and    r15,0xffff
    7c6369ffeb74:	mov    ecx,0xffffffff
    7c6369ffeb79:	and    r15,rcx
    7c6369ffeb7c:	mov    rcx,r15
    7c6369ffeb7f:	or     r14,rcx
    7c6369ffeb82:	shr    r13,0x30
    7c6369ffeb86:	and    r13,0xffff
    7c6369ffeb8d:	mov    ecx,0xffffffff
    7c6369ffeb92:	and    r13,rcx
    7c6369ffeb95:	shl    r13,0x20
    7c6369ffeb99:	mov    rcx,r13
    7c6369ffeb9c:	or     r14,rcx
    7c6369ffeb9f:	mov    QWORD PTR [r12+0x260],rbp
    7c6369ffeba7:	mov    QWORD PTR [r12+0x268],r14
    7c6369ffebaf:	mov    r13,QWORD PTR [r12+0x188]
    7c6369ffebb7:	mov    r14d,0x0
    7c6369ffebbd:	mov    r15,r13
    7c6369ffebc0:	and    r15,0xffff
    7c6369ffebc7:	mov    ecx,0xffffffff
    7c6369ffebcc:	and    r15,rcx
    7c6369ffebcf:	mov    rcx,r15
    7c6369ffebd2:	mov    rbp,r14
    7c6369ffebd5:	or     rbp,rcx
    7c6369ffebd8:	mov    r15,r13
    7c6369ffebdb:	shr    r15,0x10
    7c6369ffebdf:	and    r15,0xffff
    7c6369ffebe6:	mov    ecx,0xffffffff
    7c6369ffebeb:	and    r15,rcx
    7c6369ffebee:	shl    r15,0x20
    7c6369ffebf2:	mov    rcx,r15
    7c6369ffebf5:	or     rbp,rcx
    7c6369ffebf8:	mov    r15,r13
    7c6369ffebfb:	shr    r15,0x20
    7c6369ffebff:	and    r15,0xffff
    7c6369ffec06:	mov    ecx,0xffffffff
    7c6369ffec0b:	and    r15,rcx
    7c6369ffec0e:	mov    rcx,r15
    7c6369ffec11:	or     r14,rcx
    7c6369ffec14:	shr    r13,0x30
    7c6369ffec18:	and    r13,0xffff
    7c6369ffec1f:	mov    ecx,0xffffffff
    7c6369ffec24:	and    r13,rcx
    7c6369ffec27:	shl    r13,0x20
    7c6369ffec2b:	mov    rcx,r13
    7c6369ffec2e:	or     r14,rcx
    7c6369ffec31:	mov    QWORD PTR [r12+0x270],rbp
    7c6369ffec39:	mov    QWORD PTR [r12+0x278],r14
    7c6369ffec41:	mov    r13,QWORD PTR [r12+0x170]
    7c6369ffec49:	mov    r14d,0x0
    7c6369ffec4f:	mov    r15,r13
    7c6369ffec52:	and    r15,0xffff
    7c6369ffec59:	mov    ecx,0xffffffff
    7c6369ffec5e:	and    r15,rcx
    7c6369ffec61:	mov    rcx,r15
    7c6369ffec64:	mov    rbp,r14
    7c6369ffec67:	or     rbp,rcx
    7c6369ffec6a:	mov    r15,r13
    7c6369ffec6d:	shr    r15,0x10
    7c6369ffec71:	and    r15,0xffff
    7c6369ffec78:	mov    ecx,0xffffffff
    7c6369ffec7d:	and    r15,rcx
    7c6369ffec80:	shl    r15,0x20
    7c6369ffec84:	mov    rcx,r15
    7c6369ffec87:	or     rbp,rcx
    7c6369ffec8a:	mov    r15,r13
    7c6369ffec8d:	shr    r15,0x20
    7c6369ffec91:	and    r15,0xffff
    7c6369ffec98:	mov    ecx,0xffffffff
    7c6369ffec9d:	and    r15,rcx
    7c6369ffeca0:	mov    rcx,r15
    7c6369ffeca3:	or     r14,rcx
    7c6369ffeca6:	shr    r13,0x30
    7c6369ffecaa:	and    r13,0xffff
    7c6369ffecb1:	mov    ecx,0xffffffff
    7c6369ffecb6:	and    r13,rcx
    7c6369ffecb9:	shl    r13,0x20
    7c6369ffecbd:	mov    rcx,r13
    7c6369ffecc0:	or     r14,rcx
    7c6369ffecc3:	mov    QWORD PTR [r12+0x170],rbp
    7c6369ffeccb:	mov    QWORD PTR [r12+0x178],r14
    7c6369ffecd3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c6369ffecdd:	movdqa xmm2,xmm0
    7c6369ffece1:	pxor   xmm0,xmm0
    7c6369ffece5:	movdqa xmm3,xmm0
    7c6369ffece9:	movdqa xmm0,xmm2
    7c6369ffeced:	movdqa xmm1,xmm3
    7c6369ffecf1:	punpckhwd xmm0,xmm1
    7c6369ffecf5:	movdqa xmm4,xmm0
    7c6369ffecf9:	movdqa xmm0,xmm4
    7c6369ffecfd:	pslld  xmm0,0x10
    7c6369ffed02:	movdqa xmm3,xmm0
    7c6369ffed06:	movdqa xmm0,xmm3
    7c6369ffed0a:	movdqu XMMWORD PTR [r12+0x280],xmm0
    7c6369ffed14:	mov    r13,QWORD PTR [r12+0x180]
    7c6369ffed1c:	mov    r14d,0x0
    7c6369ffed22:	mov    r15,r13
    7c6369ffed25:	and    r15,0xffff
    7c6369ffed2c:	mov    ecx,0xffffffff
    7c6369ffed31:	and    r15,rcx
    7c6369ffed34:	mov    rcx,r15
    7c6369ffed37:	mov    rbp,r14
    7c6369ffed3a:	or     rbp,rcx
    7c6369ffed3d:	mov    r15,r13
    7c6369ffed40:	shr    r15,0x10
    7c6369ffed44:	and    r15,0xffff
    7c6369ffed4b:	mov    ecx,0xffffffff
    7c6369ffed50:	and    r15,rcx
    7c6369ffed53:	shl    r15,0x20
    7c6369ffed57:	mov    rcx,r15
    7c6369ffed5a:	or     rbp,rcx
    7c6369ffed5d:	mov    r15,r13
    7c6369ffed60:	shr    r15,0x20
    7c6369ffed64:	and    r15,0xffff
    7c6369ffed6b:	mov    ecx,0xffffffff
    7c6369ffed70:	and    r15,rcx
    7c6369ffed73:	mov    rcx,r15
    7c6369ffed76:	or     r14,rcx
    7c6369ffed79:	shr    r13,0x30
    7c6369ffed7d:	and    r13,0xffff
    7c6369ffed84:	mov    ecx,0xffffffff
    7c6369ffed89:	and    r13,rcx
    7c6369ffed8c:	shl    r13,0x20
    7c6369ffed90:	mov    rcx,r13
    7c6369ffed93:	or     r14,rcx
    7c6369ffed96:	mov    QWORD PTR [r12+0x180],rbp
    7c6369ffed9e:	mov    QWORD PTR [r12+0x188],r14
    7c6369ffeda6:	pxor   xmm0,xmm0
    7c6369ffedaa:	movdqa xmm3,xmm0
    7c6369ffedae:	movdqa xmm0,xmm2
    7c6369ffedb2:	movdqa xmm1,xmm3
    7c6369ffedb6:	punpcklwd xmm0,xmm1
    7c6369ffedba:	movdqa xmm4,xmm0
    7c6369ffedbe:	movdqa xmm0,xmm4
    7c6369ffedc2:	pslld  xmm0,0x10
    7c6369ffedc7:	movdqa xmm2,xmm0
    7c6369ffedcb:	movdqa xmm0,xmm2
    7c6369ffedcf:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c6369ffedd9:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c6369ffede3:	movdqa xmm2,xmm0
    7c6369ffede7:	pxor   xmm0,xmm0
    7c6369ffedeb:	movdqa xmm3,xmm0
    7c6369ffedef:	movdqa xmm0,xmm2
    7c6369ffedf3:	movdqa xmm1,xmm3
    7c6369ffedf7:	punpckhwd xmm0,xmm1
    7c6369ffedfb:	movdqa xmm4,xmm0
    7c6369ffedff:	movdqa xmm0,xmm4
    7c6369ffee03:	pslld  xmm0,0x10
    7c6369ffee08:	movdqa xmm2,xmm0
    7c6369ffee0c:	movdqa xmm0,xmm2
    7c6369ffee10:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c6369ffee1a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c6369ffee24:	movdqa xmm2,xmm0
    7c6369ffee28:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c6369ffee32:	movdqa xmm3,xmm0
    7c6369ffee36:	movdqa xmm1,xmm2
    7c6369ffee3a:	por    xmm3,xmm1
    7c6369ffee3e:	movdqa xmm0,xmm3
    7c6369ffee42:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c6369ffee4c:	mov    r13,QWORD PTR [r12+0x228]
    7c6369ffee54:	mov    r14d,0x0
    7c6369ffee5a:	mov    r15,r13
    7c6369ffee5d:	and    r15,0xffff
    7c6369ffee64:	shl    r15,0x8
    7c6369ffee68:	mov    ecx,0xffffffff
    7c6369ffee6d:	and    r15,rcx
    7c6369ffee70:	mov    rcx,r15
    7c6369ffee73:	mov    rbp,r14
    7c6369ffee76:	or     rbp,rcx
    7c6369ffee79:	mov    r15,r13
    7c6369ffee7c:	shr    r15,0x10
    7c6369ffee80:	and    r15,0xffff
    7c6369ffee87:	shl    r15,0x8
    7c6369ffee8b:	mov    ecx,0xffffffff
    7c6369ffee90:	and    r15,rcx
    7c6369ffee93:	shl    r15,0x20
    7c6369ffee97:	mov    rcx,r15
    7c6369ffee9a:	or     rbp,rcx
    7c6369ffee9d:	mov    r15,r13
    7c6369ffeea0:	shr    r15,0x20
    7c6369ffeea4:	and    r15,0xffff
    7c6369ffeeab:	shl    r15,0x8
    7c6369ffeeaf:	mov    ecx,0xffffffff
    7c6369ffeeb4:	and    r15,rcx
    7c6369ffeeb7:	mov    rcx,r15
    7c6369ffeeba:	or     r14,rcx
    7c6369ffeebd:	shr    r13,0x30
    7c6369ffeec1:	and    r13,0xffff
    7c6369ffeec8:	shl    r13,0x8
    7c6369ffeecc:	mov    ecx,0xffffffff
    7c6369ffeed1:	and    r13,rcx
    7c6369ffeed4:	shl    r13,0x20
    7c6369ffeed8:	mov    rcx,r13
    7c6369ffeedb:	or     r14,rcx
    7c6369ffeede:	mov    QWORD PTR [r12+0x240],rbp
    7c6369ffeee6:	mov    QWORD PTR [r12+0x248],r14
    7c6369ffeeee:	mov    r13,QWORD PTR [r12+0x220]
    7c6369ffeef6:	mov    r14d,0x0
    7c6369ffeefc:	mov    r15,r13
    7c6369ffeeff:	and    r15,0xffff
    7c6369ffef06:	shl    r15,0x8
    7c6369ffef0a:	mov    ecx,0xffffffff
    7c6369ffef0f:	and    r15,rcx
    7c6369ffef12:	mov    rcx,r15
    7c6369ffef15:	mov    rbp,r14
    7c6369ffef18:	or     rbp,rcx
    7c6369ffef1b:	mov    r15,r13
    7c6369ffef1e:	shr    r15,0x10
    7c6369ffef22:	and    r15,0xffff
    7c6369ffef29:	shl    r15,0x8
    7c6369ffef2d:	mov    ecx,0xffffffff
    7c6369ffef32:	and    r15,rcx
    7c6369ffef35:	shl    r15,0x20
    7c6369ffef39:	mov    rcx,r15
    7c6369ffef3c:	or     rbp,rcx
    7c6369ffef3f:	mov    r15,r13
    7c6369ffef42:	shr    r15,0x20
    7c6369ffef46:	and    r15,0xffff
    7c6369ffef4d:	shl    r15,0x8
    7c6369ffef51:	mov    ecx,0xffffffff
    7c6369ffef56:	and    r15,rcx
    7c6369ffef59:	mov    rcx,r15
    7c6369ffef5c:	or     r14,rcx
    7c6369ffef5f:	shr    r13,0x30
    7c6369ffef63:	and    r13,0xffff
    7c6369ffef6a:	shl    r13,0x8
    7c6369ffef6e:	mov    ecx,0xffffffff
    7c6369ffef73:	and    r13,rcx
    7c6369ffef76:	shl    r13,0x20
    7c6369ffef7a:	mov    rcx,r13
    7c6369ffef7d:	or     r14,rcx
    7c6369ffef80:	mov    QWORD PTR [r12+0x220],rbp
    7c6369ffef88:	mov    QWORD PTR [r12+0x228],r14
    7c6369ffef90:	mov    r13,QWORD PTR [r12+0x168]
    7c6369ffef98:	mov    r14d,0x0
    7c6369ffef9e:	mov    r15,r13
    7c6369ffefa1:	and    r15,0xffff
    7c6369ffefa8:	shl    r15,0x8
    7c6369ffefac:	mov    ecx,0xffffffff
    7c6369ffefb1:	and    r15,rcx
    7c6369ffefb4:	mov    rcx,r15
    7c6369ffefb7:	mov    rbp,r14
    7c6369ffefba:	or     rbp,rcx
    7c6369ffefbd:	mov    r15,r13
    7c6369ffefc0:	shr    r15,0x10
    7c6369ffefc4:	and    r15,0xffff
    7c6369ffefcb:	shl    r15,0x8
    7c6369ffefcf:	mov    ecx,0xffffffff
    7c6369ffefd4:	and    r15,rcx
    7c6369ffefd7:	shl    r15,0x20
    7c6369ffefdb:	mov    rcx,r15
    7c6369ffefde:	or     rbp,rcx
    7c6369ffefe1:	mov    r15,r13
    7c6369ffefe4:	shr    r15,0x20
    7c6369ffefe8:	and    r15,0xffff
    7c6369ffefef:	shl    r15,0x8
    7c6369ffeff3:	mov    ecx,0xffffffff
    7c6369ffeff8:	and    r15,rcx
    7c6369ffeffb:	mov    rcx,r15
    7c6369ffeffe:	or     r14,rcx
    7c6369fff001:	shr    r13,0x30
    7c6369fff005:	and    r13,0xffff
    7c6369fff00c:	shl    r13,0x8
    7c6369fff010:	mov    ecx,0xffffffff
    7c6369fff015:	and    r13,rcx
    7c6369fff018:	shl    r13,0x20
    7c6369fff01c:	mov    rcx,r13
    7c6369fff01f:	or     r14,rcx
    7c6369fff022:	mov    QWORD PTR [r12+0x160],rbp
    7c6369fff02a:	mov    QWORD PTR [r12+0x168],r14
    7c6369fff032:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c6369fff03c:	movdqa xmm2,xmm0
    7c6369fff040:	movdqa xmm0,xmm2
    7c6369fff044:	pslld  xmm0,0x18
    7c6369fff049:	movdqa xmm3,xmm0
    7c6369fff04d:	movdqa xmm0,xmm3
    7c6369fff051:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c6369fff05b:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c6369fff065:	movdqa xmm2,xmm0
    7c6369fff069:	movdqa xmm0,xmm2
    7c6369fff06d:	pslld  xmm0,0x18
    7c6369fff072:	movdqa xmm3,xmm0
    7c6369fff076:	movdqa xmm0,xmm3
    7c6369fff07a:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c6369fff084:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c6369fff08e:	movdqa xmm2,xmm0
    7c6369fff092:	movdqa xmm0,xmm2
    7c6369fff096:	pslld  xmm0,0x18
    7c6369fff09b:	movdqa xmm3,xmm0
    7c6369fff09f:	movdqa xmm0,xmm3
    7c6369fff0a3:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c6369fff0ad:	mov    r13,QWORD PTR [r12+0x250]
    7c6369fff0b5:	mov    r14d,0x0
    7c6369fff0bb:	mov    r15,r13
    7c6369fff0be:	and    r15,0xffff
    7c6369fff0c5:	mov    ecx,0xffffffff
    7c6369fff0ca:	and    r15,rcx
    7c6369fff0cd:	mov    rcx,r15
    7c6369fff0d0:	mov    rbp,r14
    7c6369fff0d3:	or     rbp,rcx
    7c6369fff0d6:	mov    r15,r13
    7c6369fff0d9:	shr    r15,0x10
    7c6369fff0dd:	and    r15,0xffff
    7c6369fff0e4:	mov    ecx,0xffffffff
    7c6369fff0e9:	and    r15,rcx
    7c6369fff0ec:	shl    r15,0x20
    7c6369fff0f0:	mov    rcx,r15
    7c6369fff0f3:	or     rbp,rcx
    7c6369fff0f6:	mov    r15,r13
    7c6369fff0f9:	shr    r15,0x20
    7c6369fff0fd:	and    r15,0xffff
    7c6369fff104:	mov    ecx,0xffffffff
    7c6369fff109:	and    r15,rcx
    7c6369fff10c:	mov    rcx,r15
    7c6369fff10f:	or     r14,rcx
    7c6369fff112:	shr    r13,0x30
    7c6369fff116:	and    r13,0xffff
    7c6369fff11d:	mov    ecx,0xffffffff
    7c6369fff122:	and    r13,rcx
    7c6369fff125:	shl    r13,0x20
    7c6369fff129:	mov    rcx,r13
    7c6369fff12c:	or     r14,rcx
    7c6369fff12f:	mov    QWORD PTR [r12+0x140],rbp
    7c6369fff137:	mov    QWORD PTR [r12+0x148],r14
    7c6369fff13f:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c6369fff149:	movdqa xmm2,xmm0
    7c6369fff14d:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7c6369fff157:	movdqa xmm3,xmm0
    7c6369fff15b:	movdqa xmm1,xmm2
    7c6369fff15f:	por    xmm3,xmm1
    7c6369fff163:	movdqa xmm0,xmm3
    7c6369fff167:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369fff171:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c6369fff17b:	movdqa xmm2,xmm0
    7c6369fff17f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c6369fff189:	movdqa xmm3,xmm0
    7c6369fff18d:	movdqa xmm1,xmm2
    7c6369fff191:	por    xmm3,xmm1
    7c6369fff195:	movdqa xmm0,xmm3
    7c6369fff199:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c6369fff1a3:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7c6369fff1ad:	movdqa xmm2,xmm0
    7c6369fff1b1:	movdqa xmm0,xmm2
    7c6369fff1b5:	pslld  xmm0,0x18
    7c6369fff1ba:	movdqa xmm3,xmm0
    7c6369fff1be:	movdqa xmm0,xmm3
    7c6369fff1c2:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c6369fff1cc:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c6369fff1d6:	movdqa xmm2,xmm0
    7c6369fff1da:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c6369fff1e4:	movdqa xmm3,xmm0
    7c6369fff1e8:	movdqa xmm1,xmm2
    7c6369fff1ec:	por    xmm3,xmm1
    7c6369fff1f0:	movdqa xmm0,xmm3
    7c6369fff1f4:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c6369fff1fe:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c6369fff208:	movdqa xmm2,xmm0
    7c6369fff20c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c6369fff216:	movdqa xmm3,xmm0
    7c6369fff21a:	movdqa xmm1,xmm2
    7c6369fff21e:	por    xmm3,xmm1
    7c6369fff222:	movdqa xmm0,xmm3
    7c6369fff226:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c6369fff230:	mov    r13,QWORD PTR [r12+0x118]
    7c6369fff238:	mov    r14d,0x0
    7c6369fff23e:	mov    r15,r13
    7c6369fff241:	and    r15,0xffff
    7c6369fff248:	mov    ecx,0xffffffff
    7c6369fff24d:	and    r15,rcx
    7c6369fff250:	mov    rcx,r15
    7c6369fff253:	mov    rbp,r14
    7c6369fff256:	or     rbp,rcx
    7c6369fff259:	mov    r15,r13
    7c6369fff25c:	shr    r15,0x10
    7c6369fff260:	and    r15,0xffff
    7c6369fff267:	mov    ecx,0xffffffff
    7c6369fff26c:	and    r15,rcx
    7c6369fff26f:	shl    r15,0x20
    7c6369fff273:	mov    rcx,r15
    7c6369fff276:	or     rbp,rcx
    7c6369fff279:	mov    r15,r13
    7c6369fff27c:	shr    r15,0x20
    7c6369fff280:	and    r15,0xffff
    7c6369fff287:	mov    ecx,0xffffffff
    7c6369fff28c:	and    r15,rcx
    7c6369fff28f:	mov    rcx,r15
    7c6369fff292:	or     r14,rcx
    7c6369fff295:	shr    r13,0x30
    7c6369fff299:	and    r13,0xffff
    7c6369fff2a0:	mov    ecx,0xffffffff
    7c6369fff2a5:	and    r13,rcx
    7c6369fff2a8:	shl    r13,0x20
    7c6369fff2ac:	mov    rcx,r13
    7c6369fff2af:	or     r14,rcx
    7c6369fff2b2:	mov    QWORD PTR [r12+0x170],rbp
    7c6369fff2ba:	mov    QWORD PTR [r12+0x178],r14
    7c6369fff2c2:	mov    r13,QWORD PTR [r12+0x110]
    7c6369fff2ca:	mov    r14d,0x0
    7c6369fff2d0:	mov    r15,r13
    7c6369fff2d3:	and    r15,0xffff
    7c6369fff2da:	mov    ecx,0xffffffff
    7c6369fff2df:	and    r15,rcx
    7c6369fff2e2:	mov    rcx,r15
    7c6369fff2e5:	mov    rbp,r14
    7c6369fff2e8:	or     rbp,rcx
    7c6369fff2eb:	mov    r15,r13
    7c6369fff2ee:	shr    r15,0x10
    7c6369fff2f2:	and    r15,0xffff
    7c6369fff2f9:	mov    ecx,0xffffffff
    7c6369fff2fe:	and    r15,rcx
    7c6369fff301:	shl    r15,0x20
    7c6369fff305:	mov    rcx,r15
    7c6369fff308:	or     rbp,rcx
    7c6369fff30b:	mov    r15,r13
    7c6369fff30e:	shr    r15,0x20
    7c6369fff312:	and    r15,0xffff
    7c6369fff319:	mov    ecx,0xffffffff
    7c6369fff31e:	and    r15,rcx
    7c6369fff321:	mov    rcx,r15
    7c6369fff324:	or     r14,rcx
    7c6369fff327:	shr    r13,0x30
    7c6369fff32b:	and    r13,0xffff
    7c6369fff332:	mov    ecx,0xffffffff
    7c6369fff337:	and    r13,rcx
    7c6369fff33a:	shl    r13,0x20
    7c6369fff33e:	mov    rcx,r13
    7c6369fff341:	or     r14,rcx
    7c6369fff344:	mov    QWORD PTR [r12+0x110],rbp
    7c6369fff34c:	mov    QWORD PTR [r12+0x118],r14
    7c6369fff354:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c6369fff35e:	movdqa xmm2,xmm0
    7c6369fff362:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c6369fff36c:	movdqa xmm3,xmm0
    7c6369fff370:	movdqa xmm1,xmm2
    7c6369fff374:	por    xmm3,xmm1
    7c6369fff378:	movdqa xmm0,xmm3
    7c6369fff37c:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c6369fff386:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c6369fff390:	movdqa xmm2,xmm0
    7c6369fff394:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c6369fff39e:	movdqa xmm3,xmm0
    7c6369fff3a2:	movdqa xmm1,xmm2
    7c6369fff3a6:	por    xmm3,xmm1
    7c6369fff3aa:	movdqa xmm0,xmm3
    7c6369fff3ae:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369fff3b8:	mov    r13,QWORD PTR [r12+0x258]
    7c6369fff3c0:	mov    r14d,0x0
    7c6369fff3c6:	mov    r15,r13
    7c6369fff3c9:	and    r15,0xffff
    7c6369fff3d0:	mov    ecx,0xffffffff
    7c6369fff3d5:	and    r15,rcx
    7c6369fff3d8:	mov    rcx,r15
    7c6369fff3db:	mov    rbp,r14
    7c6369fff3de:	or     rbp,rcx
    7c6369fff3e1:	mov    r15,r13
    7c6369fff3e4:	shr    r15,0x10
    7c6369fff3e8:	and    r15,0xffff
    7c6369fff3ef:	mov    ecx,0xffffffff
    7c6369fff3f4:	and    r15,rcx
    7c6369fff3f7:	shl    r15,0x20
    7c6369fff3fb:	mov    rcx,r15
    7c6369fff3fe:	or     rbp,rcx
    7c6369fff401:	mov    r15,r13
    7c6369fff404:	shr    r15,0x20
    7c6369fff408:	and    r15,0xffff
    7c6369fff40f:	mov    ecx,0xffffffff
    7c6369fff414:	and    r15,rcx
    7c6369fff417:	mov    rcx,r15
    7c6369fff41a:	or     r14,rcx
    7c6369fff41d:	shr    r13,0x30
    7c6369fff421:	and    r13,0xffff
    7c6369fff428:	mov    ecx,0xffffffff
    7c6369fff42d:	and    r13,rcx
    7c6369fff430:	shl    r13,0x20
    7c6369fff434:	mov    rcx,r13
    7c6369fff437:	or     r14,rcx
    7c6369fff43a:	mov    QWORD PTR [r12+0x180],rbp
    7c6369fff442:	mov    QWORD PTR [r12+0x188],r14
    7c6369fff44a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c6369fff454:	movdqa xmm2,xmm0
    7c6369fff458:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c6369fff462:	movdqa xmm3,xmm0
    7c6369fff466:	movdqa xmm1,xmm2
    7c6369fff46a:	por    xmm3,xmm1
    7c6369fff46e:	movdqa xmm0,xmm3
    7c6369fff472:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c6369fff47c:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c6369fff486:	movdqa xmm2,xmm0
    7c6369fff48a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c6369fff494:	movdqa xmm4,xmm0
    7c6369fff498:	movdqa xmm1,xmm2
    7c6369fff49c:	por    xmm4,xmm1
    7c6369fff4a0:	movdqa xmm0,xmm4
    7c6369fff4a4:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c6369fff4ae:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c6369fff4b8:	movdqa xmm2,xmm0
    7c6369fff4bc:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c6369fff4c6:	movdqa xmm4,xmm0
    7c6369fff4ca:	movdqa xmm1,xmm2
    7c6369fff4ce:	por    xmm4,xmm1
    7c6369fff4d2:	movdqa xmm0,xmm4
    7c6369fff4d6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c6369fff4e0:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c6369fff4ea:	movdqa xmm2,xmm0
    7c6369fff4ee:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c6369fff4f8:	movdqa xmm5,xmm0
    7c6369fff4fc:	movdqa xmm1,xmm2
    7c6369fff500:	por    xmm5,xmm1
    7c6369fff504:	movdqa xmm0,xmm5
    7c6369fff508:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c6369fff512:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c6369fff51c:	movdqa xmm2,xmm0
    7c6369fff520:	movdqa xmm1,xmm2
    7c6369fff524:	por    xmm3,xmm1
    7c6369fff528:	movdqa xmm0,xmm3
    7c6369fff52c:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c6369fff536:	mov    r13,QWORD PTR [r12+0xf8]
    7c6369fff53e:	mov    r14,r13
    7c6369fff541:	add    r14,0x20
    7c6369fff545:	mov    r15,r14
    7c6369fff548:	add    r15,0x10
    7c6369fff54c:	movdqu XMMWORD PTR [r14],xmm4
    7c6369fff551:	mov    r14d,0x0
    7c6369fff557:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369fff55f:	movdqu XMMWORD PTR [r15],xmm5
    7c6369fff564:	mov    r14d,0x0
    7c6369fff56a:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369fff572:	mov    r14,r13
    7c6369fff575:	add    r14,0x10
    7c6369fff579:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c6369fff583:	movdqa xmm2,xmm0
    7c6369fff587:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c6369fff58d:	mov    r15d,0x0
    7c6369fff593:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369fff59b:	movdqu XMMWORD PTR [r14],xmm3
    7c6369fff5a0:	mov    r14d,0x0
    7c6369fff5a6:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369fff5ae:	mov    r14d,DWORD PTR [r13+0x0]
    7c6369fff5b2:	mov    QWORD PTR [r12+0x60],r14
    7c6369fff5b7:	jmp    0x7c6369fff5bc
    7c6369fff5bc:	mov    r13,QWORD PTR [r12+0x58]
    7c6369fff5c1:	mov    r14,QWORD PTR [r12+0x48]
    7c6369fff5c6:	mov    rcx,r13
    7c6369fff5c9:	add    r14,rcx
    7c6369fff5cc:	mov    QWORD PTR [r12+0x68],r14
    7c6369fff5d1:	add    r13,0x4
    7c6369fff5d5:	mov    QWORD PTR [r12+0x58],r13
    7c6369fff5da:	mov    r15,r14
    7c6369fff5dd:	add    r15,0x4
    7c6369fff5e1:	mov    ebp,DWORD PTR [r15]
    7c6369fff5e4:	mov    QWORD PTR [r12+0x70],rbp
    7c6369fff5e9:	mov    r15,r14
    7c6369fff5ec:	add    r15,0x38
    7c6369fff5f0:	mov    r8d,DWORD PTR [r15]
    7c6369fff5f3:	mov    QWORD PTR [r12+0x78],r8
    7c6369fff5f8:	add    r14,0x24
    7c6369fff5fc:	mov    r15d,DWORD PTR [r14]
    7c6369fff5ff:	mov    QWORD PTR [r12+0x90],r15
    7c6369fff607:	sub    r13,0xc0
    7c6369fff60e:	pushf
    7c6369fff60f:	pop    r11
    7c6369fff611:	mov    QWORD PTR [rsp+0x48],r11
    7c6369fff616:	mov    r13d,ebp
    7c6369fff619:	mov    r13d,r13d
    7c6369fff61c:	ror    r13d,0x7
    7c6369fff620:	mov    QWORD PTR [r12+0x80],r13
    7c6369fff628:	mov    r14d,r8d
    7c6369fff62b:	mov    r14d,r14d
    7c6369fff62e:	ror    r14d,0x11
    7c6369fff632:	mov    QWORD PTR [r12+0x88],r14
    7c6369fff63a:	mov    r9d,DWORD PTR [r12+0x60]
    7c6369fff63f:	mov    ecx,r9d
    7c6369fff642:	add    r15d,ecx
    7c6369fff645:	mov    QWORD PTR [r12+0x60],r15
    7c6369fff64a:	mov    r15d,ebp
    7c6369fff64d:	mov    r15d,r15d
    7c6369fff650:	shr    r15d,0x12
    7c6369fff654:	mov    ebp,ebp
    7c6369fff656:	shl    ebp,0xe
    7c6369fff659:	mov    ecx,ebp
    7c6369fff65b:	or     r15,rcx
    7c6369fff65e:	mov    r15d,r15d
    7c6369fff661:	mov    ecx,r15d
    7c6369fff664:	xor    r13,rcx
    7c6369fff667:	mov    r13d,r13d
    7c6369fff66a:	mov    QWORD PTR [r12+0x80],r13
    7c6369fff672:	mov    r15d,r8d
    7c6369fff675:	mov    r15d,r15d
    7c6369fff678:	shr    r15d,0x13
    7c6369fff67c:	mov    r8d,r8d
    7c6369fff67f:	shl    r8d,0xd
    7c6369fff683:	mov    ecx,r8d
    7c6369fff686:	or     r15,rcx
    7c6369fff689:	mov    r15d,r15d
    7c6369fff68c:	mov    ecx,r15d
    7c6369fff68f:	xor    r14,rcx
    7c6369fff692:	mov    r14d,r14d
    7c6369fff695:	mov    QWORD PTR [r12+0x88],r14
    7c6369fff69d:	mov    r15d,DWORD PTR [r12+0x70]
    7c6369fff6a2:	mov    r15d,r15d
    7c6369fff6a5:	shr    r15d,0x3
    7c6369fff6a9:	mov    ecx,r15d
    7c6369fff6ac:	xor    r13,rcx
    7c6369fff6af:	mov    r13d,r13d
    7c6369fff6b2:	mov    QWORD PTR [r12+0x80],r13
    7c6369fff6ba:	mov    r15d,DWORD PTR [r12+0x78]
    7c6369fff6bf:	mov    r15d,r15d
    7c6369fff6c2:	shr    r15d,0xa
    7c6369fff6c6:	mov    ecx,r15d
    7c6369fff6c9:	xor    r14,rcx
    7c6369fff6cc:	mov    r14d,r14d
    7c6369fff6cf:	mov    QWORD PTR [r12+0x78],r14
    7c6369fff6d4:	mov    r15d,DWORD PTR [r12+0x60]
    7c6369fff6d9:	mov    ecx,r13d
    7c6369fff6dc:	add    r15d,ecx
    7c6369fff6df:	mov    QWORD PTR [r12+0x60],r15
    7c6369fff6e4:	mov    ecx,r14d
    7c6369fff6e7:	add    r15d,ecx
    7c6369fff6ea:	mov    QWORD PTR [r12+0x60],r15
    7c6369fff6ef:	mov    r13,QWORD PTR [r12+0x68]
    7c6369fff6f4:	add    r13,0x40
    7c6369fff6f8:	mov    DWORD PTR [r13+0x0],r15d
    7c6369fff6fc:	mov    r13d,0x0
    7c6369fff702:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369fff70a:	mov    r13d,0x0
    7c6369fff710:	mov    r14d,DWORD PTR [r12+0x70]
    7c6369fff715:	mov    ecx,r14d
    7c6369fff718:	mov    r15d,r13d
    7c6369fff71b:	or     r15,rcx
    7c6369fff71e:	mov    r15d,r15d
    7c6369fff721:	mov    QWORD PTR [r12+0x60],r15
    7c6369fff726:	mov    rcx,QWORD PTR [r12+0x380]
    7c6369fff72e:	jrcxz  0x7c6369fff735
    7c6369fff730:	jmp    0x7c636a00008e
    7c6369fff735:	push   QWORD PTR [rsp+0x48]
    7c6369fff739:	popf
    7c6369fff73a:	jne    0x7c6369fff5bc
    7c6369fff740:	jmp    0x7c6369fff745
    7c6369fff745:	mov    r13,QWORD PTR [r12]
    7c6369fff749:	mov    r14,r13
    7c6369fff74c:	add    r14,0x4
    7c6369fff750:	mov    r15d,DWORD PTR [r13+0x0]
    7c6369fff754:	mov    ebp,DWORD PTR [r14]
    7c6369fff757:	mov    QWORD PTR [r12+0x78],r15
    7c6369fff75c:	mov    QWORD PTR [r12+0x80],rbp
    7c6369fff764:	mov    r14,r13
    7c6369fff767:	add    r14,0x8
    7c6369fff76b:	mov    r15,r14
    7c6369fff76e:	add    r15,0x4
    7c6369fff772:	mov    ebp,DWORD PTR [r14]
    7c6369fff775:	mov    r14d,DWORD PTR [r15]
    7c6369fff778:	mov    QWORD PTR [r12+0x70],rbp
    7c6369fff77d:	mov    QWORD PTR [r12+0x68],r14
    7c6369fff782:	mov    r14,r13
    7c6369fff785:	add    r14,0x18
    7c6369fff789:	mov    r15,r14
    7c6369fff78c:	add    r15,0x4
    7c6369fff790:	mov    ebp,DWORD PTR [r14]
    7c6369fff793:	mov    r14d,DWORD PTR [r15]
    7c6369fff796:	mov    QWORD PTR [r12+0x58],rbp
    7c6369fff79b:	mov    QWORD PTR [r12+0x60],r14
    7c6369fff7a0:	add    r13,0x10
    7c6369fff7a4:	mov    r14,r13
    7c6369fff7a7:	add    r14,0x4
    7c6369fff7ab:	mov    r15d,DWORD PTR [r13+0x0]
    7c6369fff7af:	mov    r13d,DWORD PTR [r14]
    7c6369fff7b2:	mov    QWORD PTR [r12+0x18],r15
    7c6369fff7b7:	mov    QWORD PTR [r12+0x90],r13
    7c6369fff7bf:	mov    r13d,0x0
    7c6369fff7c5:	mov    QWORD PTR [r12+0x88],r13
    7c6369fff7cd:	mov    r13d,0x0
    7c6369fff7d3:	mov    r14d,DWORD PTR [r12+0x78]
    7c6369fff7d8:	mov    ecx,r14d
    7c6369fff7db:	mov    r15d,r13d
    7c6369fff7de:	or     r15,rcx
    7c6369fff7e1:	mov    r15d,r15d
    7c6369fff7e4:	mov    QWORD PTR [r12+0xa8],r15
    7c6369fff7ec:	mov    r13d,0x0
    7c6369fff7f2:	mov    r14d,DWORD PTR [r12+0x80]
    7c6369fff7fa:	mov    ecx,r14d
    7c6369fff7fd:	mov    r15d,r13d
    7c6369fff800:	or     r15,rcx
    7c6369fff803:	mov    r15d,r15d
    7c6369fff806:	mov    QWORD PTR [r12+0x38],r15
    7c6369fff80b:	mov    r13d,0x0
    7c6369fff811:	mov    r14d,DWORD PTR [r12+0x70]
    7c6369fff816:	mov    ecx,r14d
    7c6369fff819:	mov    r15d,r13d
    7c6369fff81c:	or     r15,rcx
    7c6369fff81f:	mov    r15d,r15d
    7c6369fff822:	mov    QWORD PTR [r12+0x98],r15
    7c6369fff82a:	mov    r13d,0x0
    7c6369fff830:	mov    r14d,DWORD PTR [r12+0x68]
    7c6369fff835:	mov    ecx,r14d
    7c6369fff838:	mov    r15d,r13d
    7c6369fff83b:	or     r15,rcx
    7c6369fff83e:	mov    r15d,r15d
    7c6369fff841:	mov    QWORD PTR [r12+0x28],r15
    7c6369fff846:	mov    r13d,0x0
    7c6369fff84c:	mov    r14d,DWORD PTR [r12+0x60]
    7c6369fff851:	mov    ecx,r14d
    7c6369fff854:	mov    r15d,r13d
    7c6369fff857:	or     r15,rcx
    7c6369fff85a:	mov    r15d,r15d
    7c6369fff85d:	mov    QWORD PTR [r12+0xb0],r15
    7c6369fff865:	mov    r13d,0x0
    7c6369fff86b:	mov    r14d,DWORD PTR [r12+0x58]
    7c6369fff870:	mov    ecx,r14d
    7c6369fff873:	mov    r15d,r13d
    7c6369fff876:	or     r15,rcx
    7c6369fff879:	mov    r15d,r15d
    7c6369fff87c:	mov    QWORD PTR [r12+0xc0],r15
    7c6369fff884:	mov    r13d,0x0
    7c6369fff88a:	mov    r14d,DWORD PTR [r12+0x90]
    7c6369fff892:	mov    ecx,r14d
    7c6369fff895:	mov    r15d,r13d
    7c6369fff898:	or     r15,rcx
    7c6369fff89b:	mov    r15d,r15d
    7c6369fff89e:	mov    QWORD PTR [r12+0xc8],r15
    7c6369fff8a6:	mov    r13d,0x0
    7c6369fff8ac:	mov    r14d,DWORD PTR [r12+0x18]
    7c6369fff8b1:	mov    ecx,r14d
    7c6369fff8b4:	mov    r15d,r13d
    7c6369fff8b7:	or     r15,rcx
    7c6369fff8ba:	mov    r15d,r15d
    7c6369fff8bd:	mov    QWORD PTR [r12+0xb8],r15
    7c6369fff8c5:	jmp    0x7c6369fff8ca
    7c6369fff8ca:	mov    r13d,0x0
    7c6369fff8d0:	mov    r14d,DWORD PTR [r12+0xb8]
    7c6369fff8d8:	mov    ecx,r14d
    7c6369fff8db:	mov    r15d,r13d
    7c6369fff8de:	or     r15,rcx
    7c6369fff8e1:	mov    r15d,r15d
    7c6369fff8e4:	mov    QWORD PTR [r12+0x30],r15
    7c6369fff8e9:	mov    r13d,0x0
    7c6369fff8ef:	mov    r14d,DWORD PTR [r12+0xc0]
    7c6369fff8f7:	mov    ecx,r14d
    7c6369fff8fa:	mov    r15d,r13d
    7c6369fff8fd:	or     r15,rcx
    7c6369fff900:	mov    r15d,r15d
    7c6369fff903:	mov    QWORD PTR [r12+0xa0],r15
    7c6369fff90b:	mov    r13d,0x0
    7c6369fff911:	mov    r14d,DWORD PTR [r12+0x28]
    7c6369fff916:	mov    ecx,r14d
    7c6369fff919:	mov    r15d,r13d
    7c6369fff91c:	or     r15,rcx
    7c6369fff91f:	mov    r15d,r15d
    7c6369fff922:	mov    QWORD PTR [r12+0xc0],r15
    7c6369fff92a:	mov    r13d,0x0
    7c6369fff930:	mov    r14d,DWORD PTR [r12+0x98]
    7c6369fff938:	mov    ecx,r14d
    7c6369fff93b:	mov    r15d,r13d
    7c6369fff93e:	or     r15,rcx
    7c6369fff941:	mov    r15d,r15d
    7c6369fff944:	mov    QWORD PTR [r12+0x28],r15
    7c6369fff949:	mov    r13d,0x0
    7c6369fff94f:	mov    r14d,DWORD PTR [r12+0x38]
    7c6369fff954:	mov    ecx,r14d
    7c6369fff957:	mov    r15d,r13d
    7c6369fff95a:	or     r15,rcx
    7c6369fff95d:	mov    r15d,r15d
    7c6369fff960:	mov    QWORD PTR [r12+0x98],r15
    7c6369fff968:	mov    r13d,0x0
    7c6369fff96e:	mov    r14d,DWORD PTR [r12+0xa8]
    7c6369fff976:	mov    ecx,r14d
    7c6369fff979:	mov    r15d,r13d
    7c6369fff97c:	or     r15,rcx
    7c6369fff97f:	mov    r15d,r15d
    7c6369fff982:	mov    QWORD PTR [r12+0x38],r15
    7c6369fff987:	mov    r13d,DWORD PTR [r12+0xb8]
    7c6369fff98f:	mov    r13d,r13d
    7c6369fff992:	ror    r13d,0x6
    7c6369fff996:	mov    QWORD PTR [r12+0xb8],r13
    7c6369fff99e:	mov    r13d,DWORD PTR [r12+0x30]
    7c6369fff9a3:	mov    r14d,DWORD PTR [r12+0xc8]
    7c6369fff9ab:	mov    ecx,r14d
    7c6369fff9ae:	and    r13,rcx
    7c6369fff9b1:	mov    r13d,r13d
    7c6369fff9b4:	mov    QWORD PTR [r12+0xa8],r13
    7c6369fff9bc:	mov    r15d,r15d
    7c6369fff9bf:	ror    r15d,0x2
    7c6369fff9c3:	mov    QWORD PTR [r12+0xd0],r15
    7c6369fff9cb:	mov    r13d,0x0
    7c6369fff9d1:	mov    ecx,r14d
    7c6369fff9d4:	mov    r15d,r13d
    7c6369fff9d7:	or     r15,rcx
    7c6369fff9da:	mov    r15d,r15d
    7c6369fff9dd:	mov    QWORD PTR [r12+0x20],r15
    7c6369fff9e2:	mov    r13,QWORD PTR [r12+0x88]
    7c6369fff9ea:	mov    r14,QWORD PTR [r12+0x50]
    7c6369fff9ef:	mov    rcx,r13
    7c6369fff9f2:	add    r14,rcx
    7c6369fff9f5:	mov    r13d,DWORD PTR [r14]
    7c6369fff9f8:	mov    QWORD PTR [r12+0xc8],r13
    7c6369fffa00:	mov    r13d,DWORD PTR [r12+0xa0]
    7c6369fffa08:	mov    r14d,DWORD PTR [r12+0x30]
    7c6369fffa0d:	mov    ecx,r14d
    7c6369fffa10:	not    rcx
    7c6369fffa13:	and    r13,rcx
    7c6369fffa16:	mov    r13d,r13d
    7c6369fffa19:	mov    QWORD PTR [r12+0xd8],r13
    7c6369fffa21:	mov    r13d,DWORD PTR [r12+0xb0]
    7c6369fffa29:	mov    r15d,DWORD PTR [r12+0xa8]
    7c6369fffa31:	mov    ecx,r13d
    7c6369fffa34:	add    r15d,ecx
    7c6369fffa37:	mov    QWORD PTR [r12+0xa8],r15
    7c6369fffa3f:	mov    r13d,DWORD PTR [r12+0xb8]
    7c6369fffa47:	mov    ebp,r14d
    7c6369fffa4a:	mov    ebp,ebp
    7c6369fffa4c:	shr    ebp,0xb
    7c6369fffa4f:	mov    r14d,r14d
    7c6369fffa52:	shl    r14d,0x15
    7c6369fffa56:	mov    ecx,r14d
    7c6369fffa59:	or     rbp,rcx
    7c6369fffa5c:	mov    ebp,ebp
    7c6369fffa5e:	mov    ecx,ebp
    7c6369fffa60:	xor    r13,rcx
    7c6369fffa63:	mov    r13d,r13d
    7c6369fffa66:	mov    QWORD PTR [r12+0xb0],r13
    7c6369fffa6e:	mov    r13d,DWORD PTR [r12+0xd0]
    7c6369fffa76:	mov    r14d,DWORD PTR [r12+0x38]
    7c6369fffa7b:	mov    ebp,r14d
    7c6369fffa7e:	mov    ebp,ebp
    7c6369fffa80:	shr    ebp,0xd
    7c6369fffa83:	mov    r14d,r14d
    7c6369fffa86:	shl    r14d,0x13
    7c6369fffa8a:	mov    ecx,r14d
    7c6369fffa8d:	or     rbp,rcx
    7c6369fffa90:	mov    ebp,ebp
    7c6369fffa92:	mov    ecx,ebp
    7c6369fffa94:	xor    r13,rcx
    7c6369fffa97:	mov    r13d,r13d
    7c6369fffa9a:	mov    QWORD PTR [r12+0xd0],r13
    7c6369fffaa2:	mov    r13d,DWORD PTR [r12+0xd8]
    7c6369fffaaa:	mov    ecx,r13d
    7c6369fffaad:	add    r15d,ecx
    7c6369fffab0:	mov    QWORD PTR [r12+0xa8],r15
    7c6369fffab8:	mov    r13,QWORD PTR [r12+0x88]
    7c6369fffac0:	mov    r14,QWORD PTR [r12+0x48]
    7c6369fffac5:	mov    rcx,r13
    7c6369fffac8:	add    r14,rcx
    7c6369fffacb:	mov    r13d,DWORD PTR [r14]
    7c6369ffface:	mov    QWORD PTR [r12+0xb8],r13
    7c6369fffad6:	mov    r13d,DWORD PTR [r12+0x28]
    7c6369fffadb:	mov    r14d,DWORD PTR [r12+0x98]
    7c6369fffae3:	mov    ecx,r14d
    7c6369fffae6:	mov    ebp,r13d
    7c6369fffae9:	and    rbp,rcx
    7c6369fffaec:	mov    ebp,ebp
    7c6369fffaee:	mov    QWORD PTR [r12+0xd8],rbp
    7c6369fffaf6:	mov    ebp,DWORD PTR [r12+0xc8]
    7c6369fffafe:	mov    ecx,ebp
    7c6369fffb00:	add    r15d,ecx
    7c6369fffb03:	mov    QWORD PTR [r12+0xa8],r15
    7c6369fffb0b:	mov    ecx,r14d
    7c6369fffb0e:	xor    r13,rcx
    7c6369fffb11:	mov    r13d,r13d
    7c6369fffb14:	mov    QWORD PTR [r12+0xc8],r13
    7c6369fffb1c:	mov    r14d,DWORD PTR [r12+0xb0]
    7c6369fffb24:	mov    r15d,DWORD PTR [r12+0x30]
    7c6369fffb29:	mov    ebp,r15d
    7c6369fffb2c:	mov    ebp,ebp
    7c6369fffb2e:	shr    ebp,0x19
    7c6369fffb31:	mov    r15d,r15d
    7c6369fffb34:	shl    r15d,0x7
    7c6369fffb38:	mov    ecx,r15d
    7c6369fffb3b:	or     rbp,rcx
    7c6369fffb3e:	mov    ebp,ebp
    7c6369fffb40:	mov    ecx,ebp
    7c6369fffb42:	xor    r14,rcx
    7c6369fffb45:	mov    r14d,r14d
    7c6369fffb48:	mov    QWORD PTR [r12+0xb0],r14
    7c6369fffb50:	mov    r14d,DWORD PTR [r12+0x38]
    7c6369fffb55:	mov    ecx,r14d
    7c6369fffb58:	and    r13,rcx
    7c6369fffb5b:	mov    r13d,r13d
    7c6369fffb5e:	mov    QWORD PTR [r12+0xc8],r13
    7c6369fffb66:	mov    r15d,DWORD PTR [r12+0xd0]
    7c6369fffb6e:	mov    ebp,r14d
    7c6369fffb71:	mov    ebp,ebp
    7c6369fffb73:	shr    ebp,0x16
    7c6369fffb76:	mov    r14d,r14d
    7c6369fffb79:	shl    r14d,0xa
    7c6369fffb7d:	mov    ecx,r14d
    7c6369fffb80:	or     rbp,rcx
    7c6369fffb83:	mov    ebp,ebp
    7c6369fffb85:	mov    ecx,ebp
    7c6369fffb87:	xor    r15,rcx
    7c6369fffb8a:	mov    r15d,r15d
    7c6369fffb8d:	mov    QWORD PTR [r12+0xd0],r15
    7c6369fffb95:	mov    r14d,DWORD PTR [r12+0xb8]
    7c6369fffb9d:	mov    r15d,DWORD PTR [r12+0xa8]
    7c6369fffba5:	mov    ecx,r14d
    7c6369fffba8:	add    r15d,ecx
    7c6369fffbab:	mov    QWORD PTR [r12+0xa8],r15
    7c6369fffbb3:	mov    r14d,DWORD PTR [r12+0xd8]
    7c6369fffbbb:	mov    ecx,r14d
    7c6369fffbbe:	xor    r13,rcx
    7c6369fffbc1:	mov    r13d,r13d
    7c6369fffbc4:	mov    QWORD PTR [r12+0xb8],r13
    7c6369fffbcc:	mov    r14d,DWORD PTR [r12+0xb0]
    7c6369fffbd4:	mov    ecx,r14d
    7c6369fffbd7:	add    r15d,ecx
    7c6369fffbda:	mov    QWORD PTR [r12+0xa8],r15
    7c6369fffbe2:	mov    r14,QWORD PTR [r12+0x88]
    7c6369fffbea:	add    r14,0x4
    7c6369fffbee:	mov    QWORD PTR [r12+0x88],r14
    7c6369fffbf6:	mov    ebp,DWORD PTR [r12+0xd0]
    7c6369fffbfe:	mov    ecx,ebp
    7c6369fffc00:	add    r13d,ecx
    7c6369fffc03:	mov    QWORD PTR [r12+0xb0],r13
    7c6369fffc0b:	mov    ebp,DWORD PTR [r12+0xc0]
    7c6369fffc13:	mov    ecx,ebp
    7c6369fffc15:	mov    r8d,r15d
    7c6369fffc18:	add    r8d,ecx
    7c6369fffc1b:	mov    QWORD PTR [r12+0xb8],r8
    7c6369fffc23:	sub    r14,0x100
    7c6369fffc2a:	pushf
    7c6369fffc2b:	pop    r11
    7c6369fffc2d:	mov    QWORD PTR [rsp+0x48],r11
    7c6369fffc32:	mov    ecx,r15d
    7c6369fffc35:	add    r13d,ecx
    7c6369fffc38:	mov    QWORD PTR [r12+0xa8],r13
    7c6369fffc40:	mov    r13d,0x0
    7c6369fffc46:	mov    r14d,DWORD PTR [r12+0xa0]
    7c6369fffc4e:	mov    ecx,r14d
    7c6369fffc51:	mov    r15d,r13d
    7c6369fffc54:	or     r15,rcx
    7c6369fffc57:	mov    r15d,r15d
    7c6369fffc5a:	mov    QWORD PTR [r12+0xb0],r15
    7c6369fffc62:	mov    r13d,0x0
    7c6369fffc68:	mov    r14d,DWORD PTR [r12+0x20]
    7c6369fffc6d:	mov    ecx,r14d
    7c6369fffc70:	mov    r15d,r13d
    7c6369fffc73:	or     r15,rcx
    7c6369fffc76:	mov    r15d,r15d
    7c6369fffc79:	mov    QWORD PTR [r12+0xc0],r15
    7c6369fffc81:	mov    r13d,0x0
    7c6369fffc87:	mov    r14d,DWORD PTR [r12+0x30]
    7c6369fffc8c:	mov    ecx,r14d
    7c6369fffc8f:	mov    r15d,r13d
    7c6369fffc92:	or     r15,rcx
    7c6369fffc95:	mov    r15d,r15d
    7c6369fffc98:	mov    QWORD PTR [r12+0xc8],r15
    7c6369fffca0:	mov    rcx,QWORD PTR [r12+0x380]
    7c6369fffca8:	jrcxz  0x7c6369fffcaf
    7c6369fffcaa:	jmp    0x7c636a000115
    7c6369fffcaf:	push   QWORD PTR [rsp+0x48]
    7c6369fffcb3:	popf
    7c6369fffcb4:	jne    0x7c6369fff8ca
    7c6369fffcba:	jmp    0x7c6369fffcbf
    7c6369fffcbf:	mov    r13d,DWORD PTR [r12+0x70]
    7c6369fffcc4:	mov    r14d,DWORD PTR [r12+0x98]
    7c6369fffccc:	mov    ecx,r13d
    7c6369fffccf:	add    r14d,ecx
    7c6369fffcd2:	mov    QWORD PTR [r12+0x70],r14
    7c6369fffcd7:	mov    r13d,DWORD PTR [r12+0x68]
    7c6369fffcdc:	mov    r14d,DWORD PTR [r12+0x28]
    7c6369fffce1:	mov    ecx,r13d
    7c6369fffce4:	add    r14d,ecx
    7c6369fffce7:	mov    QWORD PTR [r12+0x68],r14
    7c6369fffcec:	mov    r13d,0x0
    7c6369fffcf2:	mov    QWORD PTR [r12+0x88],r13
    7c6369fffcfa:	mov    r13d,DWORD PTR [r12+0x78]
    7c6369fffcff:	mov    r14d,DWORD PTR [r12+0xa8]
    7c6369fffd07:	mov    ecx,r13d
    7c6369fffd0a:	add    r14d,ecx
    7c6369fffd0d:	mov    QWORD PTR [r12+0x78],r14
    7c6369fffd12:	mov    r13d,DWORD PTR [r12+0x80]
    7c6369fffd1a:	mov    r14d,DWORD PTR [r12+0x38]
    7c6369fffd1f:	mov    ecx,r13d
    7c6369fffd22:	add    r14d,ecx
    7c6369fffd25:	mov    QWORD PTR [r12+0x80],r14
    7c6369fffd2d:	mov    r13,QWORD PTR [r12]
    7c6369fffd31:	add    r13,0x8
    7c6369fffd35:	mov    r14,r13
    7c6369fffd38:	add    r14,0x4
    7c6369fffd3c:	mov    r15d,DWORD PTR [r12+0x70]
    7c6369fffd41:	mov    ebp,DWORD PTR [r12+0x68]
    7c6369fffd46:	mov    DWORD PTR [r13+0x0],r15d
    7c6369fffd4a:	mov    r13d,0x0
    7c6369fffd50:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369fffd58:	mov    DWORD PTR [r14],ebp
    7c6369fffd5b:	mov    r13d,0x0
    7c6369fffd61:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369fffd69:	mov    r13d,DWORD PTR [r12+0x18]
    7c6369fffd6e:	mov    r14d,DWORD PTR [r12+0xb8]
    7c6369fffd76:	mov    ecx,r13d
    7c6369fffd79:	add    r14d,ecx
    7c6369fffd7c:	mov    QWORD PTR [r12+0x68],r14
    7c6369fffd81:	mov    r13d,DWORD PTR [r12+0x90]
    7c6369fffd89:	mov    r14d,DWORD PTR [r12+0x30]
    7c6369fffd8e:	mov    ecx,r13d
    7c6369fffd91:	add    r14d,ecx
    7c6369fffd94:	mov    QWORD PTR [r12+0x70],r14
    7c6369fffd99:	mov    r13d,DWORD PTR [r12+0x58]
    7c6369fffd9e:	mov    r14d,DWORD PTR [r12+0x20]
    7c6369fffda3:	mov    ecx,r13d
    7c6369fffda6:	add    r14d,ecx
    7c6369fffda9:	mov    QWORD PTR [r12+0x58],r14
    7c6369fffdae:	mov    r13d,DWORD PTR [r12+0x60]
    7c6369fffdb3:	mov    r14d,DWORD PTR [r12+0xa0]
    7c6369fffdbb:	mov    ecx,r13d
    7c6369fffdbe:	add    r14d,ecx
    7c6369fffdc1:	mov    QWORD PTR [r12+0x60],r14
    7c6369fffdc6:	mov    r13,QWORD PTR [r12]
    7c6369fffdca:	mov    r15,r13
    7c6369fffdcd:	add    r15,0x4
    7c6369fffdd1:	mov    ebp,DWORD PTR [r12+0x78]
    7c6369fffdd6:	mov    r8d,DWORD PTR [r12+0x80]
    7c6369fffdde:	mov    DWORD PTR [r13+0x0],ebp
    7c6369fffde2:	mov    ebp,0x0
    7c6369fffde7:	mov    DWORD PTR [r12+0x32c],ebp
    7c6369fffdef:	mov    DWORD PTR [r15],r8d
    7c6369fffdf2:	mov    r15d,0x0
    7c6369fffdf8:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369fffe00:	mov    r15,r13
    7c6369fffe03:	add    r15,0x10
    7c6369fffe07:	mov    rbp,r15
    7c6369fffe0a:	add    rbp,0x4
    7c6369fffe0e:	mov    r8d,DWORD PTR [r12+0x68]
    7c6369fffe13:	mov    r9d,DWORD PTR [r12+0x70]
    7c6369fffe18:	mov    DWORD PTR [r15],r8d
    7c6369fffe1b:	mov    r15d,0x0
    7c6369fffe21:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369fffe29:	mov    DWORD PTR [rbp+0x0],r9d
    7c6369fffe2d:	mov    r15d,0x0
    7c6369fffe33:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369fffe3b:	mov    r15,r13
    7c6369fffe3e:	add    r15,0x18
    7c6369fffe42:	mov    rbp,r15
    7c6369fffe45:	add    rbp,0x4
    7c6369fffe49:	mov    r8d,DWORD PTR [r12+0x58]
    7c6369fffe4e:	mov    DWORD PTR [r15],r8d
    7c6369fffe51:	mov    r15d,0x0
    7c6369fffe57:	mov    DWORD PTR [r12+0x32c],r15d
    7c6369fffe5f:	mov    DWORD PTR [rbp+0x0],r14d
    7c6369fffe63:	mov    r14d,0x0
    7c6369fffe69:	mov    DWORD PTR [r12+0x32c],r14d
    7c6369fffe71:	add    r13,0x68
    7c6369fffe75:	mov    r14d,0x0
    7c6369fffe7b:	mov    QWORD PTR [r13+0x0],r14
    7c6369fffe7f:	mov    r13d,0x0
    7c6369fffe85:	mov    DWORD PTR [r12+0x32c],r13d
    7c6369fffe8d:	mov    rcx,QWORD PTR [r12+0x380]
    7c6369fffe95:	jrcxz  0x7c6369fffe9c
    7c6369fffe97:	jmp    0x7c636a00019c
    7c6369fffe9c:	jmp    0x7c6369fffea1
    7c6369fffea1:	mov    r13,QWORD PTR [r12+0x10]
    7c6369fffea6:	sub    r13,0x1
    7c6369fffeaa:	mov    QWORD PTR [r12+0x10],r13
    7c6369fffeaf:	mov    rax,r13
    7c6369fffeb2:	test   rax,rax
    7c6369fffeb5:	sete   al
    7c6369fffeb8:	movzx  eax,al
    7c6369fffebb:	and    eax,0x1
    7c6369fffebe:	mov    r14,rax
    7c6369fffec1:	mov    rax,r14
    7c6369fffec4:	and    eax,0x1
    7c6369fffec7:	test   rax,rax
    7c6369fffeca:	jne    0x7c6369fffed5
    7c6369fffed0:	jmp    0x7c6369ffd9f7
    7c6369fffed5:	mov    r13,QWORD PTR [r12+0xf8]
    7c6369fffedd:	mov    r14,r13
    7c6369fffee0:	add    r14,0x140
    7c6369fffee7:	mov    r15,r14
    7c6369fffeea:	add    r15,0x8
    7c6369fffeee:	mov    rbp,QWORD PTR [r14]
    7c6369fffef1:	mov    r14,QWORD PTR [r15]
    7c6369fffef4:	mov    QWORD PTR [r12+0xa0],rbp
    7c6369fffefc:	mov    QWORD PTR [r12+0x98],r14
    7c6369ffff04:	mov    r14,r13
    7c6369ffff07:	add    r14,0x130
    7c6369ffff0e:	mov    r15,r14
    7c6369ffff11:	add    r15,0x8
    7c6369ffff15:	mov    rbp,QWORD PTR [r14]
    7c6369ffff18:	mov    r14,QWORD PTR [r15]
    7c6369ffff1b:	mov    QWORD PTR [r12+0xb0],rbp
    7c6369ffff23:	mov    QWORD PTR [r12+0xa8],r14
    7c6369ffff2b:	mov    r14,r13
    7c6369ffff2e:	add    r14,0x120
    7c6369ffff35:	mov    r15,r14
    7c6369ffff38:	add    r15,0x8
    7c6369ffff3c:	mov    rbp,QWORD PTR [r14]
    7c6369ffff3f:	mov    r14,QWORD PTR [r15]
    7c6369ffff42:	mov    QWORD PTR [r12+0xc0],rbp
    7c6369ffff4a:	mov    QWORD PTR [r12+0xb8],r14
    7c6369ffff52:	add    r13,0x110
    7c6369ffff59:	mov    r14,r13
    7c6369ffff5c:	add    r14,0x8
    7c6369ffff60:	mov    r15,QWORD PTR [r13+0x0]
    7c6369ffff64:	mov    r13,QWORD PTR [r14]
    7c6369ffff67:	mov    QWORD PTR [r12+0xd0],r15
    7c6369ffff6f:	mov    QWORD PTR [r12+0xc8],r13
    7c6369ffff77:	mov    r13,QWORD PTR [r12+0xf8]
    7c6369ffff7f:	mov    r14,r13
    7c6369ffff82:	add    r14,0x100
    7c6369ffff89:	mov    r15,r14
    7c6369ffff8c:	add    r15,0x8
    7c6369ffff90:	mov    rbp,QWORD PTR [r14]
    7c6369ffff93:	mov    r14,QWORD PTR [r15]
    7c6369ffff96:	mov    QWORD PTR [r12+0xe8],rbp
    7c6369ffff9e:	mov    QWORD PTR [r12+0xd8],r14
    7c6369ffffa6:	add    r13,0x150
    7c6369ffffad:	mov    QWORD PTR [r12+0xf8],r13
    7c6369ffffb5:	jmp    0x7c6369ffffba
    7c6369ffffba:	mov    rcx,QWORD PTR [r12+0x380]
    7c6369ffffc2:	jrcxz  0x7c6369ffffc9
    7c6369ffffc4:	jmp    0x7c636a000223
    7c6369ffffc9:	mov    r13,QWORD PTR [r12+0xf0]
    7c6369ffffd1:	mov    QWORD PTR [r12+0x100],r13
    7c6369ffffd9:	mov    r11,QWORD PTR [rsp+0x48]
    7c6369ffffde:	mov    QWORD PTR [r12+0x398],r11
    7c6369ffffe6:	mov    rdi,QWORD PTR [r12+0x100]
    7c6369ffffee:	add    rsp,0x50
    7c6369fffff2:	movabs r11,0x59733cd1d0a0
    7c6369fffffc:	jmp    r11
    7c6369ffffff:	mov    eax,0x41039c
    7c636a000004:	mov    QWORD PTR [r12+0x100],rax
    7c636a00000c:	push   rdx
    7c636a00000d:	push   rsi
    7c636a00000e:	push   r10
    7c636a000010:	push   r11
    7c636a000012:	pushf
    7c636a000013:	pop    r11
    7c636a000015:	mov    QWORD PTR [rsp+0x68],r11
    7c636a00001a:	mov    rdx,QWORD PTR [rsp+0x68]
    7c636a00001f:	mov    r10d,edx
    7c636a000022:	and    r10d,0xc0
    7c636a000029:	shl    r10d,0x18
    7c636a00002d:	mov    r11d,edx
    7c636a000030:	and    r11d,0x1
    7c636a000034:	shl    r11d,0x1d
    7c636a000038:	or     r10d,r11d
    7c636a00003b:	mov    r11d,edx
    7c636a00003e:	and    r11d,0x800
    7c636a000045:	shl    r11d,0x11
    7c636a000049:	or     r10d,r11d
    7c636a00004c:	btc    r10,0x1d
    7c636a000051:	mov    r11d,0xf0000000
    7c636a000057:	and    r11,r10
    7c636a00005a:	movabs rsi,0xffffffff0fffffff
    7c636a000064:	and    rbx,rsi
    7c636a000067:	or     rbx,r11
    7c636a00006a:	pop    r11
    7c636a00006c:	pop    r10
    7c636a00006e:	pop    rsi
    7c636a00006f:	pop    rdx
    7c636a000070:	mov    QWORD PTR [r12+0x108],rbx
    7c636a000078:	add    rsp,0x50
    7c636a00007c:	mov    eax,0xc
    7c636a000081:	movabs r11,0x59733cd1d390
    7c636a00008b:	jmp    r11
    7c636a00008e:	mov    eax,0x410498
    7c636a000093:	mov    QWORD PTR [r12+0x100],rax
    7c636a00009b:	push   rdx
    7c636a00009c:	push   rsi
    7c636a00009d:	push   r10
    7c636a00009f:	push   r11
    7c636a0000a1:	mov    rdx,QWORD PTR [rsp+0x68]
    7c636a0000a6:	mov    r10d,edx
    7c636a0000a9:	and    r10d,0xc0
    7c636a0000b0:	shl    r10d,0x18
    7c636a0000b4:	mov    r11d,edx
    7c636a0000b7:	and    r11d,0x1
    7c636a0000bb:	shl    r11d,0x1d
    7c636a0000bf:	or     r10d,r11d
    7c636a0000c2:	mov    r11d,edx
    7c636a0000c5:	and    r11d,0x800
    7c636a0000cc:	shl    r11d,0x11
    7c636a0000d0:	or     r10d,r11d
    7c636a0000d3:	btc    r10,0x1d
    7c636a0000d8:	mov    r11d,0xf0000000
    7c636a0000de:	and    r11,r10
    7c636a0000e1:	movabs rsi,0xffffffff0fffffff
    7c636a0000eb:	and    rbx,rsi
    7c636a0000ee:	or     rbx,r11
    7c636a0000f1:	pop    r11
    7c636a0000f3:	pop    r10
    7c636a0000f5:	pop    rsi
    7c636a0000f6:	pop    rdx
    7c636a0000f7:	mov    QWORD PTR [r12+0x108],rbx
    7c636a0000ff:	add    rsp,0x50
    7c636a000103:	mov    eax,0xc
    7c636a000108:	movabs r11,0x59733cd1d390
    7c636a000112:	jmp    r11
    7c636a000115:	mov    eax,0x410558
    7c636a00011a:	mov    QWORD PTR [r12+0x100],rax
    7c636a000122:	push   rdx
    7c636a000123:	push   rsi
    7c636a000124:	push   r10
    7c636a000126:	push   r11
    7c636a000128:	mov    rdx,QWORD PTR [rsp+0x68]
    7c636a00012d:	mov    r10d,edx
    7c636a000130:	and    r10d,0xc0
    7c636a000137:	shl    r10d,0x18
    7c636a00013b:	mov    r11d,edx
    7c636a00013e:	and    r11d,0x1
    7c636a000142:	shl    r11d,0x1d
    7c636a000146:	or     r10d,r11d
    7c636a000149:	mov    r11d,edx
    7c636a00014c:	and    r11d,0x800
    7c636a000153:	shl    r11d,0x11
    7c636a000157:	or     r10d,r11d
    7c636a00015a:	btc    r10,0x1d
    7c636a00015f:	mov    r11d,0xf0000000
    7c636a000165:	and    r11,r10
    7c636a000168:	movabs rsi,0xffffffff0fffffff
    7c636a000172:	and    rbx,rsi
    7c636a000175:	or     rbx,r11
    7c636a000178:	pop    r11
    7c636a00017a:	pop    r10
    7c636a00017c:	pop    rsi
    7c636a00017d:	pop    rdx
    7c636a00017e:	mov    QWORD PTR [r12+0x108],rbx
    7c636a000186:	add    rsp,0x50
    7c636a00018a:	mov    eax,0xc
    7c636a00018f:	movabs r11,0x59733cd1d390
    7c636a000199:	jmp    r11
    7c636a00019c:	mov    eax,0x410594
    7c636a0001a1:	mov    QWORD PTR [r12+0x100],rax
    7c636a0001a9:	push   rdx
    7c636a0001aa:	push   rsi
    7c636a0001ab:	push   r10
    7c636a0001ad:	push   r11
    7c636a0001af:	mov    rdx,QWORD PTR [rsp+0x68]
    7c636a0001b4:	mov    r10d,edx
    7c636a0001b7:	and    r10d,0xc0
    7c636a0001be:	shl    r10d,0x18
    7c636a0001c2:	mov    r11d,edx
    7c636a0001c5:	and    r11d,0x1
    7c636a0001c9:	shl    r11d,0x1d
    7c636a0001cd:	or     r10d,r11d
    7c636a0001d0:	mov    r11d,edx
    7c636a0001d3:	and    r11d,0x800
    7c636a0001da:	shl    r11d,0x11
    7c636a0001de:	or     r10d,r11d
    7c636a0001e1:	btc    r10,0x1d
    7c636a0001e6:	mov    r11d,0xf0000000
    7c636a0001ec:	and    r11,r10
    7c636a0001ef:	movabs rsi,0xffffffff0fffffff
    7c636a0001f9:	and    rbx,rsi
    7c636a0001fc:	or     rbx,r11
    7c636a0001ff:	pop    r11
    7c636a000201:	pop    r10
    7c636a000203:	pop    rsi
    7c636a000204:	pop    rdx
    7c636a000205:	mov    QWORD PTR [r12+0x108],rbx
    7c636a00020d:	add    rsp,0x50
    7c636a000211:	mov    eax,0xc
    7c636a000216:	movabs r11,0x59733cd1d390
    7c636a000220:	jmp    r11
    7c636a000223:	mov    eax,0x4105b0
    7c636a000228:	mov    QWORD PTR [r12+0x100],rax
    7c636a000230:	push   rdx
    7c636a000231:	push   rsi
    7c636a000232:	push   r10
    7c636a000234:	push   r11
    7c636a000236:	mov    rdx,QWORD PTR [rsp+0x68]
    7c636a00023b:	mov    r10d,edx
    7c636a00023e:	and    r10d,0xc0
    7c636a000245:	shl    r10d,0x18
    7c636a000249:	mov    r11d,edx
    7c636a00024c:	and    r11d,0x1
    7c636a000250:	shl    r11d,0x1d
    7c636a000254:	or     r10d,r11d
    7c636a000257:	mov    r11d,edx
    7c636a00025a:	and    r11d,0x800
    7c636a000261:	shl    r11d,0x11
    7c636a000265:	or     r10d,r11d
    7c636a000268:	btc    r10,0x1d
    7c636a00026d:	mov    r11d,0xf0000000
    7c636a000273:	and    r11,r10
    7c636a000276:	movabs rsi,0xffffffff0fffffff
    7c636a000280:	and    rbx,rsi
    7c636a000283:	or     rbx,r11
    7c636a000286:	pop    r11
    7c636a000288:	pop    r10
    7c636a00028a:	pop    rsi
    7c636a00028b:	pop    rdx
    7c636a00028c:	mov    QWORD PTR [r12+0x108],rbx
    7c636a000294:	add    rsp,0x50
    7c636a000298:	mov    eax,0xc
    7c636a00029d:	movabs r11,0x59733cd1d390
    7c636a0002a7:	jmp    r11
    7c636a0002aa:	nop    WORD PTR [rax+rax*1+0x0]
    7c636a0002b0:	sub    rsp,0x50
    7c636a0002b4:	mov    r11,QWORD PTR [r12+0x398]
    7c636a0002bc:	mov    QWORD PTR [rsp+0x48],r11
    7c636a0002c1:	jmp    0x7c6369ffd84b
    7c636a0002c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a0002d0:	sub    rsp,0x50
    7c636a0002d4:	mov    r11,QWORD PTR [r12+0x398]
    7c636a0002dc:	mov    QWORD PTR [rsp+0x48],r11
    7c636a0002e1:	jmp    0x7c6369ffd9f7
    7c636a0002e6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a0002f0:	sub    rsp,0x50
    7c636a0002f4:	mov    r11,QWORD PTR [r12+0x398]
    7c636a0002fc:	mov    QWORD PTR [rsp+0x48],r11
    7c636a000301:	jmp    0x7c6369ffdaa1
    7c636a000306:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a000310:	sub    rsp,0x50
    7c636a000314:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00031c:	mov    QWORD PTR [rsp+0x48],r11
    7c636a000321:	jmp    0x7c6369fff5bc
    7c636a000326:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a000330:	sub    rsp,0x50
    7c636a000334:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00033c:	mov    QWORD PTR [rsp+0x48],r11
    7c636a000341:	jmp    0x7c6369fff745
    7c636a000346:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a000350:	sub    rsp,0x50
    7c636a000354:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00035c:	mov    QWORD PTR [rsp+0x48],r11
    7c636a000361:	jmp    0x7c6369fff8ca
    7c636a000366:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a000370:	sub    rsp,0x50
    7c636a000374:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00037c:	mov    QWORD PTR [rsp+0x48],r11
    7c636a000381:	jmp    0x7c6369fffcbf
    7c636a000386:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a000390:	sub    rsp,0x50
    7c636a000394:	mov    r11,QWORD PTR [r12+0x398]
    7c636a00039c:	mov    QWORD PTR [rsp+0x48],r11
    7c636a0003a1:	jmp    0x7c6369fffea1
    7c636a0003a6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a0003b0:	sub    rsp,0x50
    7c636a0003b4:	mov    r11,QWORD PTR [r12+0x398]
    7c636a0003bc:	mov    QWORD PTR [rsp+0x48],r11
    7c636a0003c1:	jmp    0x7c6369fffed5
    7c636a0003c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c636a0003d0:	sub    rsp,0x50
    7c636a0003d4:	mov    r11,QWORD PTR [r12+0x398]
    7c636a0003dc:	mov    QWORD PTR [rsp+0x48],r11
    7c636a0003e1:	jmp    0x7c6369ffffba
    7c636a0003e6:	nop
    7c636a0003e7:	nop
