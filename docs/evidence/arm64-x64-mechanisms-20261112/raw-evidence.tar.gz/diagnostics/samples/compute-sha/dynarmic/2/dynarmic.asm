00007debeebce69b  nop [rax+rax*1], eax
00007debeebce6a0  mov rax, [r15+0xF8]
00007debeebce6a7  lea r14, [rax-0xA0]
00007debeebce6ae  mov [r15+0xF8], r14
00007debeebce6b5  lea rax, [r14+0x90]
00007debeebce6bc  mov r12, [r15+0xA0]
00007debeebce6c3  mov r11, [r15+0x98]
00007debeebce6ca  mov [r13+rax*1], r12
00007debeebce6cf  lea rax, [r14+0x98]
00007debeebce6d6  mov [r13+rax*1], r11
00007debeebce6db  mov eax, 0x420670
00007debeebce6e0  movups xmm1, [r13+rax*1]
00007debeebce6e6  mov eax, 0x420610
00007debeebce6eb  movups xmm15, [r13+rax*1]
00007debeebce6f1  mov eax, 0x420690
00007debeebce6f6  movups xmm14, [r13+rax*1]
00007debeebce6fc  mov eax, 0x420630
00007debeebce701  movups xmm13, [r13+rax*1]
00007debeebce707  mov qword ptr [r15+0x98], 0x4308A0
00007debeebce712  mov eax, 0x4206A0
00007debeebce717  movups xmm12, [r13+rax*1]
00007debeebce71d  mov eax, 0x4308A0
00007debeebce722  movups [r13+rax*1], xmm1
00007debeebce728  mov eax, 0x4308B0
00007debeebce72d  movups [r13+rax*1], xmm15
00007debeebce733  mov eax, 0x4308C0
00007debeebce738  movups [r13+rax*1], xmm14
00007debeebce73e  mov eax, 0x4308D0
00007debeebce743  movups [r13+rax*1], xmm13
00007debeebce749  mov eax, 0x420600
00007debeebce74e  movups xmm14, [r13+rax*1]
00007debeebce754  mov eax, 0x4205F0
00007debeebce759  movups xmm13, [r13+rax*1]
00007debeebce75f  mov eax, 0x4309A0
00007debeebce764  movups [r13+rax*1], xmm1
00007debeebce76a  mov eax, 0x4309B0
00007debeebce76f  movups [r13+rax*1], xmm15
00007debeebce775  mov eax, 0x4308E0
00007debeebce77a  movups [r13+rax*1], xmm12
00007debeebce780  mov eax, 0x4308F0
00007debeebce785  movups [r13+rax*1], xmm14
00007debeebce78b  mov eax, 0x4205E0
00007debeebce790  movups xmm1, [r13+rax*1]
00007debeebce796  mov eax, 0x420640
00007debeebce79b  movups xmm15, [r13+rax*1]
00007debeebce7a1  mov eax, 0x430900
00007debeebce7a6  movups [r13+rax*1], xmm13
00007debeebce7ac  mov eax, 0x430910
00007debeebce7b1  movups [r13+rax*1], xmm1
00007debeebce7b7  mov eax, 0x420650
00007debeebce7bc  movups xmm1, [r13+rax*1]
00007debeebce7c2  mov eax, 0x420620
00007debeebce7c7  movups xmm14, [r13+rax*1]
00007debeebce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007debeebce7d5  mov eax, 0x430920
00007debeebce7da  movups [r13+rax*1], xmm15
00007debeebce7e0  mov eax, 0x430930
00007debeebce7e5  movups [r13+rax*1], xmm1
00007debeebce7eb  mov eax, 0x4206C0
00007debeebce7f0  movups xmm1, [r13+rax*1]
00007debeebce7f6  mov eax, 0x4206D0
00007debeebce7fb  movups xmm15, [r13+rax*1]
00007debeebce801  movaps [r15+0x150], xmm15
00007debeebce809  mov qword ptr [r15+0xA0], 0x3E8
00007debeebce814  mov eax, 0x430940
00007debeebce819  movups [r13+rax*1], xmm14
00007debeebce81f  mov eax, 0x430950
00007debeebce824  movups [r13+rax*1], xmm1
00007debeebce82a  mov eax, 0x4206B0
00007debeebce82f  movups xmm1, [r13+rax*1]
00007debeebce835  mov eax, 0x420660
00007debeebce83a  movups xmm14, [r13+rax*1]
00007debeebce840  movaps [r15+0x140], xmm14
00007debeebce848  lea rax, [r14+0x80]
00007debeebce84f  mov r12, [r15+0xF0]
00007debeebce856  mov [r13+rax*1], r12
00007debeebce85b  mov eax, 0x430960
00007debeebce860  movups [r13+rax*1], xmm15
00007debeebce866  mov eax, 0x430970
00007debeebce86b  movups [r13+rax*1], xmm1
00007debeebce871  mov eax, 0x420680
00007debeebce876  movups xmm1, [r13+rax*1]
00007debeebce87c  mov eax, 0x4206E0
00007debeebce881  mov r12, [r13+rax*1]
00007debeebce886  movq xmm15, r12
00007debeebce88b  mov qword ptr [r15+0x40], 0x4206E8
00007debeebce893  mov eax, 0x430980
00007debeebce898  movups [r13+rax*1], xmm14
00007debeebce89e  mov eax, 0x430990
00007debeebce8a3  movups [r13+rax*1], xmm1
00007debeebce8a9  mov eax, 0x420748
00007debeebce8ae  movups xmm1, [r13+rax*1]
00007debeebce8b4  movq rax, xmm15
00007debeebce8b9  mov r12d, 0x4309C0
00007debeebce8bf  mov [r13+r12*1], rax
00007debeebce8c4  mov eax, 0x420728
00007debeebce8c9  movups xmm15, [r13+rax*1]
00007debeebce8cf  mov eax, 0x420738
00007debeebce8d4  movups xmm14, [r13+rax*1]
00007debeebce8da  lea rax, [r14+0x60]
00007debeebce8de  movups [r13+rax*1], xmm1
00007debeebce8e4  mov eax, 0x4309C8
00007debeebce8e9  mov r12d, 0x421DF8D3
00007debeebce8ef  mov [r13+rax*1], r12d
00007debeebce8f4  lea rax, [r14+0x40]
00007debeebce8f8  movups [r13+rax*1], xmm15
00007debeebce8fe  lea rax, [r14+0x50]
00007debeebce902  movups [r13+rax*1], xmm14
00007debeebce908  mov eax, 0x4206E8
00007debeebce90d  movups xmm1, [r13+rax*1]
00007debeebce913  mov eax, 0x4206F8
00007debeebce918  movups xmm15, [r13+rax*1]
00007debeebce91e  movaps [r15+0x120], xmm15
00007debeebce926  movups [r13+r14*1], xmm1
00007debeebce92c  lea rax, [r14+0x10]
00007debeebce930  movups [r13+rax*1], xmm15
00007debeebce936  mov eax, 0x420708
00007debeebce93b  movups xmm1, [r13+rax*1]
00007debeebce941  mov eax, 0x420718
00007debeebce946  movups xmm15, [r13+rax*1]
00007debeebce94c  movaps [r15+0x110], xmm1
00007debeebce954  movaps [r15+0x130], xmm15
00007debeebce95c  lea rax, [r14+0x20]
00007debeebce960  movups [r13+rax*1], xmm1
00007debeebce966  lea rax, [r14+0x30]
00007debeebce96a  movups [r13+rax*1], xmm15
00007debeebce970  mov [r15], r14
00007debeebce973  mov qword ptr [r15+0x08], 0x4308A0
00007debeebce97b  mov qword ptr [r15+0x10], 0x12C
00007debeebce983  mov qword ptr [r15+0xF0], 0x410274
00007debeebce98e  mov r14d, [r15+0x320]
00007debeebce995  mov eax, 0x410274
00007debeebce99a  mov rcx, 0x7DEBEEBD0670
00007debeebce9a4  mov [r15+r14*8+0x328], rax
00007debeebce9ac  mov [r15+r14*8+0x368], rcx
00007debeebce9b4  add r14d, 0x01
00007debeebce9b8  and r14d, 0x07
00007debeebce9bc  mov [r15+0x320], r14d
00007debeebce9c3  cmp dword ptr [r15+0x318], 0x00
00007debeebce9cb  jz 0x00007DEBEEBCEC20
00007debeebce9d1  nop [rax+rax*1], ax
00007debeebce9da  nop [rax+rax*1], eax
00007debeebce9e2  mov eax, 0x410338
00007debeebce9e7  mov [r15+0x100], rax
00007debeebce9ee  jmp 0x00007DEBEE9FE110
00007debeebce9f3  int3
00007debeebce9f4  call 0x00007DEBEEA0BC20
00007debeebce9f9  jmp 0x00007DEBEEBCE6CF
00007debeebce9fe  call 0x00007DEBEEA0A9A0
00007debeebcea03  jmp 0x00007DEBEEBCE6DB
00007debeebcea08  call 0x00007DEBEE9FF430
00007debeebcea0d  jmp 0x00007DEBEEBCE6E6
00007debeebcea12  call 0x00007DEBEEA0E760
00007debeebcea17  jmp 0x00007DEBEEBCE6F1
00007debeebcea1c  call 0x00007DEBEEA0D4E0
00007debeebcea21  jmp 0x00007DEBEEBCE6FC
00007debeebcea26  call 0x00007DEBEEA0C260
00007debeebcea2b  jmp 0x00007DEBEEBCE707
00007debeebcea30  call 0x00007DEBEEA0AFE0
00007debeebcea35  jmp 0x00007DEBEEBCE71D
00007debeebcea3a  call 0x00007DEBEE9FF540
00007debeebcea3f  jmp 0x00007DEBEEBCE728
00007debeebcea44  call 0x00007DEBEEA0E880
00007debeebcea49  jmp 0x00007DEBEEBCE733
00007debeebcea4e  call 0x00007DEBEEA0D600
00007debeebcea53  jmp 0x00007DEBEEBCE73E
00007debeebcea58  call 0x00007DEBEEA0C380
00007debeebcea5d  jmp 0x00007DEBEEBCE749
00007debeebcea62  call 0x00007DEBEEA0D4E0
00007debeebcea67  jmp 0x00007DEBEEBCE754
00007debeebcea6c  call 0x00007DEBEEA0C260
00007debeebcea71  jmp 0x00007DEBEEBCE75F
00007debeebcea76  call 0x00007DEBEE9FF540
00007debeebcea7b  jmp 0x00007DEBEEBCE76A
00007debeebcea80  call 0x00007DEBEEA0E880
00007debeebcea85  jmp 0x00007DEBEEBCE775
00007debeebcea8a  call 0x00007DEBEEA0B100
00007debeebcea8f  jmp 0x00007DEBEEBCE780
00007debeebcea94  call 0x00007DEBEEA0D600
00007debeebcea99  jmp 0x00007DEBEEBCE78B
00007debeebcea9e  call 0x00007DEBEE9FF430
00007debeebceaa3  jmp 0x00007DEBEEBCE796
00007debeebceaa8  call 0x00007DEBEEA0E760
00007debeebceaad  jmp 0x00007DEBEEBCE7A1
00007debeebceab2  call 0x00007DEBEEA0C380
00007debeebceab7  jmp 0x00007DEBEEBCE7AC
00007debeebceabc  call 0x00007DEBEE9FF540
00007debeebceac1  jmp 0x00007DEBEEBCE7B7
00007debeebceac6  call 0x00007DEBEE9FF430
00007debeebceacb  jmp 0x00007DEBEEBCE7C2
00007debeebcead0  call 0x00007DEBEEA0D4E0
00007debeebcead5  jmp 0x00007DEBEEBCE7CD
00007debeebceada  call 0x00007DEBEEA0E880
00007debeebceadf  jmp 0x00007DEBEEBCE7E0
00007debeebceae4  call 0x00007DEBEE9FF540
00007debeebceae9  jmp 0x00007DEBEEBCE7EB
00007debeebceaee  call 0x00007DEBEE9FF430
00007debeebceaf3  jmp 0x00007DEBEEBCE7F6
00007debeebceaf8  call 0x00007DEBEEA0E760
00007debeebceafd  jmp 0x00007DEBEEBCE801
00007debeebceb02  call 0x00007DEBEEA0D600
00007debeebceb07  jmp 0x00007DEBEEBCE81F
00007debeebceb0c  call 0x00007DEBEE9FF540
00007debeebceb11  jmp 0x00007DEBEEBCE82A
00007debeebceb16  call 0x00007DEBEE9FF430
00007debeebceb1b  jmp 0x00007DEBEEBCE835
00007debeebceb20  call 0x00007DEBEEA0D4E0
00007debeebceb25  jmp 0x00007DEBEEBCE840
00007debeebceb2a  call 0x00007DEBEEA0BC20
00007debeebceb2f  jmp 0x00007DEBEEBCE85B
00007debeebceb34  call 0x00007DEBEEA0E880
00007debeebceb39  jmp 0x00007DEBEEBCE866
00007debeebceb3e  call 0x00007DEBEE9FF540
00007debeebceb43  jmp 0x00007DEBEEBCE871
00007debeebceb48  call 0x00007DEBEE9FF430
00007debeebceb4d  jmp 0x00007DEBEEBCE87C
00007debeebceb52  call 0x00007DEBEEA0B720
00007debeebceb57  jmp 0x00007DEBEEBCE886
00007debeebceb5c  call 0x00007DEBEEA0D600
00007debeebceb61  jmp 0x00007DEBEEBCE89E
00007debeebceb66  call 0x00007DEBEE9FF540
00007debeebceb6b  jmp 0x00007DEBEEBCE8A9
00007debeebceb70  call 0x00007DEBEE9FF430
00007debeebceb75  jmp 0x00007DEBEEBCE8B4
00007debeebceb7a  call 0x00007DEBEEAB4CB0
00007debeebceb7f  jmp 0x00007DEBEEBCE8C4
00007debeebceb84  call 0x00007DEBEEA0E760
00007debeebceb89  jmp 0x00007DEBEEBCE8CF
00007debeebceb8e  call 0x00007DEBEEA0D4E0
00007debeebceb93  jmp 0x00007DEBEEBCE8DA
00007debeebceb98  call 0x00007DEBEE9FF540
00007debeebceb9d  jmp 0x00007DEBEEBCE8E4
00007debeebceba2  call 0x00007DEBEEA0BAE0
00007debeebceba7  jmp 0x00007DEBEEBCE8F4
00007debeebcebac  call 0x00007DEBEEA0E880
00007debeebcebb1  jmp 0x00007DEBEEBCE8FE
00007debeebcebb6  call 0x00007DEBEEA0D600
00007debeebcebbb  jmp 0x00007DEBEEBCE908
00007debeebcebc0  call 0x00007DEBEE9FF430
00007debeebcebc5  jmp 0x00007DEBEEBCE913
00007debeebcebca  call 0x00007DEBEEA0E760
00007debeebcebcf  jmp 0x00007DEBEEBCE91E
00007debeebcebd4  call 0x00007DEBEEAD6600
00007debeebcebd9  jmp 0x00007DEBEEBCE92C
00007debeebcebde  call 0x00007DEBEEA0E880
00007debeebcebe3  jmp 0x00007DEBEEBCE936
00007debeebcebe8  call 0x00007DEBEE9FF430
00007debeebcebed  jmp 0x00007DEBEEBCE941
00007debeebcebf2  call 0x00007DEBEEA0E760
00007debeebcebf7  jmp 0x00007DEBEEBCE94C
00007debeebcebfc  call 0x00007DEBEE9FF540
00007debeebcec01  jmp 0x00007DEBEEBCE966
00007debeebcec06  call 0x00007DEBEEA0E880
00007debeebcec0b  jmp 0x00007DEBEEBCE970
00007debeebcec10  int3
00007debeebcec11  nop [rax+rax*1], ax
00007debeebcec1a  nop [rax+rax*1], ax
00007debeebcec20  mov rax, [r15]
00007debeebcec23  lea r14, [rax+0x20]
00007debeebcec27  mov r12, [r13+r14*1]
00007debeebcec2c  mov r14, [r15+0x10]
00007debeebcec30  lea r11, [r12+r14*1]
00007debeebcec34  mov [r15+0x40], r11
00007debeebcec38  lea r12, [rax+0x20]
00007debeebcec3c  mov [r13+r12*1], r11
00007debeebcec41  test r14, r14
00007debeebcec44  setz r14b
00007debeebcec48  movzx r14, r14b
00007debeebcec4c  mov [rsp+0x414], r14b
00007debeebcec54  cmp byte ptr [rsp+0x414], 0x00
00007debeebcec5c  jz 0x00007DEBEEBCEC8E
00007debeebcec5e  cmp dword ptr [r15+0x318], 0x00
00007debeebcec66  mov eax, 0x4105B0
00007debeebcec6b  mov [r15+0x100], rax
00007debeebcec72  jz 0x00007DEBEE9FE0A0
00007debeebcec78  nop [rax+rax*1], eax
00007debeebcec7d  mov eax, 0x4105B0
00007debeebcec82  mov [r15+0x100], rax
00007debeebcec89  jmp 0x00007DEBEE9FE110
00007debeebcec8e  cmp dword ptr [r15+0x318], 0x00
00007debeebcec96  jz 0x00007DEBEEBCECE0
00007debeebcec9c  nop [rax+rax*1], ax
00007debeebceca5  nop [rax+rax*1], eax
00007debeebcecad  mov eax, 0x410348
00007debeebcecb2  mov [r15+0x100], rax
00007debeebcecb9  jmp 0x00007DEBEE9FE110
00007debeebcecbe  int3
00007debeebcecbf  call 0x00007DEBEEAE27E0
00007debeebcecc4  jmp 0x00007DEBEEBCEC2C
00007debeebcecc9  call 0x00007DEBEEAC0860
00007debeebcecce  jmp 0x00007DEBEEBCEC41
00007debeebcecd3  int3
00007debeebcecd4  nop [rax+rax*1], ax
00007debeebcecdd  nop [rax], eax
00007debeebcece0  mov rax, [r15+0xF8]
00007debeebcece7  lea r14, [rax-0x150]
00007debeebcecee  mov [r15+0xF8], r14
00007debeebcecf5  mov rax, [r15]
00007debeebcecf8  lea r12, [rax+0x68]
00007debeebcecfc  mov r11, [r13+r12*1]
00007debeebced01  mov [r15+0x88], r11
00007debeebced08  lea r12, [rax+0x28]
00007debeebced0c  mov [r15+0x40], r12
00007debeebced10  mov [r15+0x48], r14
00007debeebced14  mov qword ptr [r15+0x50], 0x420758
00007debeebced1c  lea rax, [r14+0x100]
00007debeebced23  mov r12, [r15+0xE8]
00007debeebced2a  mov r11, [r15+0xD8]
00007debeebced31  mov [r13+rax*1], r12
00007debeebced36  lea rax, [r14+0x108]
00007debeebced3d  mov [r13+rax*1], r11
00007debeebced42  lea rax, [r14+0x110]
00007debeebced49  mov r12, [r15+0xD0]
00007debeebced50  mov r11, [r15+0xC8]
00007debeebced57  mov [r13+rax*1], r12
00007debeebced5c  lea rax, [r14+0x118]
00007debeebced63  mov [r13+rax*1], r11
00007debeebced68  lea rax, [r14+0x120]
00007debeebced6f  mov r12, [r15+0xC0]
00007debeebced76  mov r11, [r15+0xB8]
00007debeebced7d  mov [r13+rax*1], r12
00007debeebced82  lea rax, [r14+0x128]
00007debeebced89  mov [r13+rax*1], r11
00007debeebced8e  lea rax, [r14+0x130]
00007debeebced95  mov r12, [r15+0xB0]
00007debeebced9c  mov r11, [r15+0xA8]
00007debeebceda3  mov [r13+rax*1], r12
00007debeebceda8  lea rax, [r14+0x138]
00007debeebcedaf  mov [r13+rax*1], r11
00007debeebcedb4  lea rax, [r14+0x140]
00007debeebcedbb  mov r12, [r15+0xA0]
00007debeebcedc2  mov r11, [r15+0x98]
00007debeebcedc9  mov [r13+rax*1], r12
00007debeebcedce  lea rax, [r14+0x148]
00007debeebcedd5  mov [r13+rax*1], r11
00007debeebcedda  cmp dword ptr [r15+0x318], 0x00
00007debeebcede2  jz 0x00007DEBEEBCEE80
00007debeebcede8  nop [rax+rax*1], ax
00007debeebcedf1  nop [rax+rax*1], eax
00007debeebcedf9  mov eax, 0x410380
00007debeebcedfe  mov [r15+0x100], rax
00007debeebcee05  jmp 0x00007DEBEE9FE110
00007debeebcee0a  int3
00007debeebcee0b  call 0x00007DEBEEAC0370
00007debeebcee10  jmp 0x00007DEBEEBCED01
00007debeebcee15  call 0x00007DEBEEA0BC20
00007debeebcee1a  jmp 0x00007DEBEEBCED36
00007debeebcee1f  call 0x00007DEBEEA0A9A0
00007debeebcee24  jmp 0x00007DEBEEBCED42
00007debeebcee29  call 0x00007DEBEEA0BC20
00007debeebcee2e  jmp 0x00007DEBEEBCED5C
00007debeebcee33  call 0x00007DEBEEA0A9A0
00007debeebcee38  jmp 0x00007DEBEEBCED68
00007debeebcee3d  call 0x00007DEBEEA0BC20
00007debeebcee42  jmp 0x00007DEBEEBCED82
00007debeebcee47  call 0x00007DEBEEA0A9A0
00007debeebcee4c  jmp 0x00007DEBEEBCED8E
00007debeebcee51  call 0x00007DEBEEA0BC20
00007debeebcee56  jmp 0x00007DEBEEBCEDA8
00007debeebcee5b  call 0x00007DEBEEA0A9A0
00007debeebcee60  jmp 0x00007DEBEEBCEDB4
00007debeebcee65  call 0x00007DEBEEA0BC20
00007debeebcee6a  jmp 0x00007DEBEEBCEDCE
00007debeebcee6f  call 0x00007DEBEEA0A9A0
00007debeebcee74  jmp 0x00007DEBEEBCEDDA
00007debeebcee79  int3
00007debeebcee7a  nop [rax+rax*1], ax
00007debeebcee80  mov rax, [r15+0x08]
00007debeebcee84  movzx r14d, byte ptr [r13+rax*1]
00007debeebcee8a  movzx r14d, r14b
00007debeebcee8e  mov [rsp+0x10], r14d
00007debeebcee93  mov r14d, r14d
00007debeebcee96  mov [r15+0x58], r14
00007debeebcee9a  lea r14, [rax+0x01]
00007debeebcee9e  mov [r15+0x08], r14
00007debeebceea2  mov rax, [r15+0x88]
00007debeebceea9  lea r14, [rax+0x01]
00007debeebceead  mov r12, [r15]
00007debeebceeb0  lea r11, [r12+0x68]
00007debeebceeb5  mov [r13+r11*1], r14
00007debeebceeba  lea r14, [r12+rax*1]
00007debeebceebe  mov [r15+0x60], r14
00007debeebceec2  lea rax, [r14+0x28]
00007debeebceec6  mov r11d, [rsp+0x10]
00007debeebceecb  movzx r14d, r11b
00007debeebceecf  mov [r13+rax*1], r14b
00007debeebceed4  lea rax, [r12+0x68]
00007debeebceed9  mov r14, [r13+rax*1]
00007debeebceede  mov [r15+0x88], r14
00007debeebceee5  xor eax, eax
00007debeebceee7  mov r12d, 0x40
00007debeebceeed  cmp r14, r12
00007debeebceef0  cmc
00007debeebceef1  lahf
00007debeebceef2  seto al
00007debeebceef5  mov [r15+0x108], eax
00007debeebceefc  mov eax, [r15+0x108]
00007debeebcef03  sahf
00007debeebcef04  jnz 0x00007DEBEEBCEF36
00007debeebcef06  cmp dword ptr [r15+0x318], 0x00
00007debeebcef0e  jz 0x00007DEBEEBCF020
00007debeebcef14  nop [rax+rax*1], ax
00007debeebcef1d  nop [rax+rax*1], eax
00007debeebcef25  mov eax, 0x4103A0
00007debeebcef2a  mov [r15+0x100], rax
00007debeebcef31  jmp 0x00007DEBEE9FE110
00007debeebcef36  cmp dword ptr [r15+0x318], 0x00
00007debeebcef3e  jz 0x00007DEBEEBCEF90
00007debeebcef44  nop [rax+rax*1], ax
00007debeebcef4d  nop [rax+rax*1], eax
00007debeebcef55  mov eax, 0x410378
00007debeebcef5a  mov [r15+0x100], rax
00007debeebcef61  jmp 0x00007DEBEE9FE110
00007debeebcef66  int3
00007debeebcef67  call 0x00007DEBEEA0D860
00007debeebcef6c  jmp 0x00007DEBEEBCEE8A
00007debeebcef71  call 0x00007DEBEEAB36E0
00007debeebcef76  jmp 0x00007DEBEEBCEEBA
00007debeebcef7b  call 0x00007DEBEEA0DD60
00007debeebcef80  jmp 0x00007DEBEEBCEED4
00007debeebcef85  call 0x00007DEBEEA0DC20
00007debeebcef8a  jmp 0x00007DEBEEBCEEDE
00007debeebcef8f  int3
00007debeebcef90  mov rax, [r15+0x10]
00007debeebcef94  lea r14, [rax-0x01]
00007debeebcef98  mov [r15+0x10], r14
00007debeebcef9c  test r14, r14
00007debeebcef9f  setz r14b
00007debeebcefa3  movzx r14, r14b
00007debeebcefa7  mov [rsp+0x414], r14b
00007debeebcefaf  cmp byte ptr [rsp+0x414], 0x00
00007debeebcefb7  jz 0x00007DEBEEBCEFE9
00007debeebcefb9  cmp dword ptr [r15+0x318], 0x00
00007debeebcefc1  jz 0x00007DEBEEBD0520
00007debeebcefc7  nop [rax+rax*1], ax
00007debeebcefd0  nop [rax+rax*1], eax
00007debeebcefd8  mov eax, 0x410598
00007debeebcefdd  mov [r15+0x100], rax
00007debeebcefe4  jmp 0x00007DEBEE9FE110
00007debeebcefe9  cmp dword ptr [r15+0x318], 0x00
00007debeebceff1  jz 0x00007DEBEEBCEE80
00007debeebceff7  nop [rax+rax*1], ax
00007debeebcf000  nop [rax+rax*1], eax
00007debeebcf008  mov eax, 0x410380
00007debeebcf00d  mov [r15+0x100], rax
00007debeebcf014  jmp 0x00007DEBEE9FE110
00007debeebcf019  int3
00007debeebcf01a  int3
00007debeebcf01b  nop [rax+rax*1], eax
00007debeebcf020  mov rax, [r15+0x40]
00007debeebcf024  movzx r14d, byte ptr [r13+rax*1]
00007debeebcf02a  movaps xmm1, [r15+0x110]
00007debeebcf032  pinsrb xmm1, r14d, 0x00
00007debeebcf039  lea r14, [rax+0x01]
00007debeebcf03d  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf043  movaps xmm15, [r15+0x120]
00007debeebcf04b  pinsrb xmm15, r12d, 0x00
00007debeebcf052  lea r14, [rax+0x02]
00007debeebcf056  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf05c  movaps xmm14, [r15+0x130]
00007debeebcf064  pinsrb xmm14, r12d, 0x00
00007debeebcf06b  lea r14, [rax+0x03]
00007debeebcf06f  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf075  movaps xmm13, [r15+0x140]
00007debeebcf07d  pinsrb xmm13, r12d, 0x00
00007debeebcf084  lea r14, [rax+0x04]
00007debeebcf088  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf08e  pinsrb xmm1, r12d, 0x01
00007debeebcf095  lea r14, [rax+0x05]
00007debeebcf099  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf09f  pinsrb xmm15, r12d, 0x01
00007debeebcf0a6  lea r14, [rax+0x06]
00007debeebcf0aa  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf0b0  pinsrb xmm14, r12d, 0x01
00007debeebcf0b7  lea r14, [rax+0x07]
00007debeebcf0bb  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf0c1  pinsrb xmm13, r12d, 0x01
00007debeebcf0c8  lea r14, [rax+0x08]
00007debeebcf0cc  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf0d2  pinsrb xmm1, r12d, 0x02
00007debeebcf0d9  lea r14, [rax+0x09]
00007debeebcf0dd  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf0e3  pinsrb xmm15, r12d, 0x02
00007debeebcf0ea  lea r14, [rax+0x0A]
00007debeebcf0ee  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf0f4  pinsrb xmm14, r12d, 0x02
00007debeebcf0fb  lea r14, [rax+0x0B]
00007debeebcf0ff  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf105  pinsrb xmm13, r12d, 0x02
00007debeebcf10c  lea r14, [rax+0x0C]
00007debeebcf110  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf116  pinsrb xmm1, r12d, 0x03
00007debeebcf11d  lea r14, [rax+0x0D]
00007debeebcf121  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf127  pinsrb xmm15, r12d, 0x03
00007debeebcf12e  lea r14, [rax+0x0E]
00007debeebcf132  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf138  pinsrb xmm14, r12d, 0x03
00007debeebcf13f  lea r14, [rax+0x0F]
00007debeebcf143  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf149  pinsrb xmm13, r12d, 0x03
00007debeebcf150  lea r14, [rax+0x10]
00007debeebcf154  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf15a  pinsrb xmm1, r12d, 0x04
00007debeebcf161  lea r14, [rax+0x11]
00007debeebcf165  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf16b  pinsrb xmm15, r12d, 0x04
00007debeebcf172  lea r14, [rax+0x12]
00007debeebcf176  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf17c  pinsrb xmm14, r12d, 0x04
00007debeebcf183  lea r14, [rax+0x13]
00007debeebcf187  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf18d  pinsrb xmm13, r12d, 0x04
00007debeebcf194  lea r14, [rax+0x14]
00007debeebcf198  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf19e  pinsrb xmm1, r12d, 0x05
00007debeebcf1a5  lea r14, [rax+0x15]
00007debeebcf1a9  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf1af  pinsrb xmm15, r12d, 0x05
00007debeebcf1b6  lea r14, [rax+0x16]
00007debeebcf1ba  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf1c0  pinsrb xmm14, r12d, 0x05
00007debeebcf1c7  lea r14, [rax+0x17]
00007debeebcf1cb  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf1d1  pinsrb xmm13, r12d, 0x05
00007debeebcf1d8  lea r14, [rax+0x18]
00007debeebcf1dc  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf1e2  pinsrb xmm1, r12d, 0x06
00007debeebcf1e9  lea r14, [rax+0x19]
00007debeebcf1ed  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf1f3  pinsrb xmm15, r12d, 0x06
00007debeebcf1fa  lea r14, [rax+0x1A]
00007debeebcf1fe  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf204  pinsrb xmm14, r12d, 0x06
00007debeebcf20b  lea r14, [rax+0x1B]
00007debeebcf20f  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf215  pinsrb xmm13, r12d, 0x06
00007debeebcf21c  lea r14, [rax+0x1C]
00007debeebcf220  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf226  pinsrb xmm1, r12d, 0x07
00007debeebcf22d  lea r14, [rax+0x1D]
00007debeebcf231  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf237  pinsrb xmm15, r12d, 0x07
00007debeebcf23e  lea r14, [rax+0x1E]
00007debeebcf242  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf248  pinsrb xmm14, r12d, 0x07
00007debeebcf24f  lea r14, [rax+0x1F]
00007debeebcf253  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf259  pinsrb xmm13, r12d, 0x07
00007debeebcf260  lea r14, [rax+0x20]
00007debeebcf264  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf26a  pinsrb xmm1, r12d, 0x08
00007debeebcf271  lea r14, [rax+0x21]
00007debeebcf275  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf27b  pinsrb xmm15, r12d, 0x08
00007debeebcf282  lea r14, [rax+0x22]
00007debeebcf286  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf28c  pinsrb xmm14, r12d, 0x08
00007debeebcf293  lea r14, [rax+0x23]
00007debeebcf297  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf29d  pinsrb xmm13, r12d, 0x08
00007debeebcf2a4  lea r14, [rax+0x24]
00007debeebcf2a8  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf2ae  pinsrb xmm1, r12d, 0x09
00007debeebcf2b5  lea r14, [rax+0x25]
00007debeebcf2b9  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf2bf  pinsrb xmm15, r12d, 0x09
00007debeebcf2c6  lea r14, [rax+0x26]
00007debeebcf2ca  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf2d0  pinsrb xmm14, r12d, 0x09
00007debeebcf2d7  lea r14, [rax+0x27]
00007debeebcf2db  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf2e1  pinsrb xmm13, r12d, 0x09
00007debeebcf2e8  lea r14, [rax+0x28]
00007debeebcf2ec  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf2f2  pinsrb xmm1, r12d, 0x0A
00007debeebcf2f9  lea r14, [rax+0x29]
00007debeebcf2fd  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf303  pinsrb xmm15, r12d, 0x0A
00007debeebcf30a  lea r14, [rax+0x2A]
00007debeebcf30e  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf314  pinsrb xmm14, r12d, 0x0A
00007debeebcf31b  lea r14, [rax+0x2B]
00007debeebcf31f  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf325  pinsrb xmm13, r12d, 0x0A
00007debeebcf32c  lea r14, [rax+0x2C]
00007debeebcf330  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf336  pinsrb xmm1, r12d, 0x0B
00007debeebcf33d  lea r14, [rax+0x2D]
00007debeebcf341  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf347  pinsrb xmm15, r12d, 0x0B
00007debeebcf34e  lea r14, [rax+0x2E]
00007debeebcf352  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf358  pinsrb xmm14, r12d, 0x0B
00007debeebcf35f  lea r14, [rax+0x2F]
00007debeebcf363  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf369  pinsrb xmm13, r12d, 0x0B
00007debeebcf370  lea r14, [rax+0x30]
00007debeebcf374  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf37a  pinsrb xmm1, r12d, 0x0C
00007debeebcf381  lea r14, [rax+0x31]
00007debeebcf385  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf38b  pinsrb xmm15, r12d, 0x0C
00007debeebcf392  lea r14, [rax+0x32]
00007debeebcf396  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf39c  pinsrb xmm14, r12d, 0x0C
00007debeebcf3a3  lea r14, [rax+0x33]
00007debeebcf3a7  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf3ad  pinsrb xmm13, r12d, 0x0C
00007debeebcf3b4  lea r14, [rax+0x34]
00007debeebcf3b8  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf3be  pinsrb xmm1, r12d, 0x0D
00007debeebcf3c5  lea r14, [rax+0x35]
00007debeebcf3c9  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf3cf  pinsrb xmm15, r12d, 0x0D
00007debeebcf3d6  lea r14, [rax+0x36]
00007debeebcf3da  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf3e0  pinsrb xmm14, r12d, 0x0D
00007debeebcf3e7  lea r14, [rax+0x37]
00007debeebcf3eb  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf3f1  pinsrb xmm13, r12d, 0x0D
00007debeebcf3f8  lea r14, [rax+0x38]
00007debeebcf3fc  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf402  pinsrb xmm1, r12d, 0x0E
00007debeebcf409  lea r14, [rax+0x39]
00007debeebcf40d  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf413  pinsrb xmm15, r12d, 0x0E
00007debeebcf41a  lea r14, [rax+0x3A]
00007debeebcf41e  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf424  pinsrb xmm14, r12d, 0x0E
00007debeebcf42b  lea r14, [rax+0x3B]
00007debeebcf42f  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf435  pinsrb xmm13, r12d, 0x0E
00007debeebcf43c  lea r14, [rax+0x3C]
00007debeebcf440  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf446  pinsrb xmm1, r12d, 0x0F
00007debeebcf44d  movaps [r15+0x110], xmm1
00007debeebcf455  lea r14, [rax+0x3D]
00007debeebcf459  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf45f  pinsrb xmm15, r12d, 0x0F
00007debeebcf466  movaps [r15+0x120], xmm15
00007debeebcf46e  lea r14, [rax+0x3E]
00007debeebcf472  movzx r12d, byte ptr [r13+r14*1]
00007debeebcf478  pinsrb xmm14, r12d, 0x0F
00007debeebcf47f  movaps [r15+0x130], xmm14
00007debeebcf487  lea r14, [rax+0x3F]
00007debeebcf48b  movzx eax, byte ptr [r13+r14*1]
00007debeebcf491  pinsrb xmm13, eax, 0x0F
00007debeebcf498  movaps [r15+0x140], xmm13
00007debeebcf4a0  movq xmm1, qword ptr [r15+0x120]
00007debeebcf4a9  pmovzxbw xmm1, xmm1
00007debeebcf4ae  psllw xmm1, 0x00
00007debeebcf4b3  movaps [r15+0x150], xmm1
00007debeebcf4bb  movq xmm1, qword ptr [r15+0x130]
00007debeebcf4c4  pmovzxbw xmm1, xmm1
00007debeebcf4c9  psllw xmm1, 0x00
00007debeebcf4ce  movaps [r15+0x160], xmm1
00007debeebcf4d6  movq xmm1, qword ptr [r15+0x110]
00007debeebcf4df  pmovzxbw xmm1, xmm1
00007debeebcf4e4  psllw xmm1, 0x00
00007debeebcf4e9  movaps [r15+0x170], xmm1
00007debeebcf4f1  movaps xmm15, [r15+0x110]
00007debeebcf4f9  pextrq rax, xmm15, 0x01
00007debeebcf500  movq xmm15, rax
00007debeebcf505  pmovzxbw xmm15, xmm15
00007debeebcf50b  psllw xmm15, 0x00
00007debeebcf511  movaps [r15+0x180], xmm15
00007debeebcf519  movaps xmm14, [r15+0x120]
00007debeebcf521  pextrq rax, xmm14, 0x01
00007debeebcf528  movq xmm14, rax
00007debeebcf52d  pmovzxbw xmm14, xmm14
00007debeebcf533  psllw xmm14, 0x00
00007debeebcf539  movaps [r15+0x210], xmm14
00007debeebcf541  movaps xmm13, [r15+0x130]
00007debeebcf549  pextrq rax, xmm13, 0x01
00007debeebcf550  movq xmm13, rax
00007debeebcf555  pmovzxbw xmm13, xmm13
00007debeebcf55b  psllw xmm13, 0x00
00007debeebcf561  movaps [r15+0x220], xmm13
00007debeebcf569  movq xmm12, qword ptr [r15+0x140]
00007debeebcf572  pmovzxbw xmm12, xmm12
00007debeebcf578  psllw xmm12, 0x00
00007debeebcf57e  movaps [r15+0x250], xmm12
00007debeebcf586  movaps xmm12, [r15+0x140]
00007debeebcf58e  pextrq rax, xmm12, 0x01
00007debeebcf595  movq xmm12, rax
00007debeebcf59a  pmovzxbw xmm12, xmm12
00007debeebcf5a0  psllw xmm12, 0x00
00007debeebcf5a6  movaps [r15+0x110], xmm12
00007debeebcf5ae  movq xmm11, qword ptr [r15+0x150]
00007debeebcf5b7  pmovzxwd xmm11, xmm11
00007debeebcf5bd  pslld xmm11, 0x10
00007debeebcf5c3  movq xmm10, qword ptr [r15+0x160]
00007debeebcf5cc  pmovzxwd xmm10, xmm10
00007debeebcf5d2  pslld xmm10, 0x08
00007debeebcf5d8  pextrq rax, xmm1, 0x01
00007debeebcf5df  movq xmm1, rax
00007debeebcf5e4  pmovzxwd xmm1, xmm1
00007debeebcf5e9  pslld xmm1, 0x00
00007debeebcf5ee  movaps [r15+0x260], xmm1
00007debeebcf5f6  pextrq rax, xmm15, 0x01
00007debeebcf5fd  movq xmm15, rax
00007debeebcf602  pmovzxwd xmm15, xmm15
00007debeebcf608  pslld xmm15, 0x00
00007debeebcf60e  movaps [r15+0x270], xmm15
00007debeebcf616  movq xmm9, qword ptr [r15+0x170]
00007debeebcf61f  pmovzxwd xmm9, xmm9
00007debeebcf625  pslld xmm9, 0x00
00007debeebcf62b  pextrq rax, xmm14, 0x01
00007debeebcf632  movq xmm14, rax
00007debeebcf637  pmovzxwd xmm14, xmm14
00007debeebcf63d  pslld xmm14, 0x10
00007debeebcf643  movaps [r15+0x280], xmm14
00007debeebcf64b  movq xmm8, qword ptr [r15+0x180]
00007debeebcf654  pmovzxwd xmm8, xmm8
00007debeebcf65a  pslld xmm8, 0x00
00007debeebcf660  movq xmm7, qword ptr [r15+0x210]
00007debeebcf669  pmovzxwd xmm7, xmm7
00007debeebcf66e  pslld xmm7, 0x10
00007debeebcf673  movaps xmm6, [r15+0x150]
00007debeebcf67b  pextrq rax, xmm6, 0x01
00007debeebcf682  movq xmm6, rax
00007debeebcf687  pmovzxwd xmm6, xmm6
00007debeebcf68c  pslld xmm6, 0x10
00007debeebcf691  por xmm11, xmm10
00007debeebcf696  movaps [r15+0x230], xmm11
00007debeebcf69e  pextrq rax, xmm13, 0x01
00007debeebcf6a5  movq xmm13, rax
00007debeebcf6aa  pmovzxwd xmm13, xmm13
00007debeebcf6b0  pslld xmm13, 0x08
00007debeebcf6b6  movaps [r15+0x240], xmm13
00007debeebcf6be  movq xmm10, qword ptr [r15+0x220]
00007debeebcf6c7  pmovzxwd xmm10, xmm10
00007debeebcf6cd  pslld xmm10, 0x08
00007debeebcf6d3  movaps xmm5, [r15+0x160]
00007debeebcf6db  pextrq rax, xmm5, 0x01
00007debeebcf6e2  movq xmm5, rax
00007debeebcf6e7  pmovzxwd xmm5, xmm5
00007debeebcf6ec  pslld xmm5, 0x08
00007debeebcf6f1  pslld xmm9, 0x18
00007debeebcf6f7  pslld xmm15, 0x18
00007debeebcf6fd  pslld xmm8, 0x18
00007debeebcf703  movq xmm4, qword ptr [r15+0x250]
00007debeebcf70c  pmovzxwd xmm4, xmm4
00007debeebcf711  pslld xmm4, 0x00
00007debeebcf716  por xmm14, xmm13
00007debeebcf71b  por xmm7, xmm10
00007debeebcf720  movaps [r15+0x210], xmm7
00007debeebcf728  pslld xmm1, 0x18
00007debeebcf72d  movaps [r15+0x220], xmm1
00007debeebcf735  por xmm6, xmm5
00007debeebcf739  por xmm11, xmm9
00007debeebcf73e  movaps [r15+0x160], xmm11
00007debeebcf746  pextrq rax, xmm12, 0x01
00007debeebcf74d  movq xmm13, rax
00007debeebcf752  pmovzxwd xmm13, xmm13
00007debeebcf758  pslld xmm13, 0x00
00007debeebcf75e  movaps [r15+0x170], xmm13
00007debeebcf766  movq xmm12, qword ptr [r15+0x110]
00007debeebcf76f  pmovzxwd xmm12, xmm12
00007debeebcf775  pslld xmm12, 0x00
00007debeebcf77b  por xmm14, xmm15
00007debeebcf780  por xmm7, xmm8
00007debeebcf785  movaps xmm15, [r15+0x250]
00007debeebcf78d  pextrq rax, xmm15, 0x01
00007debeebcf794  movq xmm15, rax
00007debeebcf799  pmovzxwd xmm15, xmm15
00007debeebcf79f  pslld xmm15, 0x00
00007debeebcf7a5  movaps [r15+0x180], xmm15
00007debeebcf7ad  por xmm6, xmm1
00007debeebcf7b1  movaps [r15+0x150], xmm6
00007debeebcf7b9  por xmm11, xmm4
00007debeebcf7be  movaps [r15+0x140], xmm11
00007debeebcf7c6  por xmm7, xmm12
00007debeebcf7cb  movaps [r15+0x110], xmm7
00007debeebcf7d3  por xmm14, xmm13
00007debeebcf7d8  movaps [r15+0x120], xmm14
00007debeebcf7e0  por xmm6, xmm15
00007debeebcf7e5  movaps [r15+0x130], xmm6
00007debeebcf7ed  mov rax, [r15+0xF8]
00007debeebcf7f4  lea r14, [rax+0x20]
00007debeebcf7f8  movups [r13+r14*1], xmm7
00007debeebcf7fe  lea r14, [rax+0x30]
00007debeebcf802  movups [r13+r14*1], xmm14
00007debeebcf808  movups [r13+rax*1], xmm11
00007debeebcf80e  lea r14, [rax+0x10]
00007debeebcf812  movups [r13+r14*1], xmm6
00007debeebcf818  mov r14d, [r13+rax*1]
00007debeebcf81d  mov rax, [r15+0x48]
00007debeebcf821  mov [r15+0x68], rax
00007debeebcf825  mov qword ptr [r15+0x58], 0x04
00007debeebcf82d  lea r12, [rax+0x04]
00007debeebcf831  mov r11d, [r13+r12*1]
00007debeebcf836  mov [rsp+0x10], r11d
00007debeebcf83b  mov r11d, r11d
00007debeebcf83e  mov [r15+0x70], r11
00007debeebcf842  lea r12, [rax+0x38]
00007debeebcf846  mov r11d, [r13+r12*1]
00007debeebcf84b  lea r12, [rax+0x24]
00007debeebcf84f  mov r10d, [r13+r12*1]
00007debeebcf854  mov [rsp+0x20], r10d
00007debeebcf859  mov r10d, r10d
00007debeebcf85c  mov [r15+0x90], r10
00007debeebcf863  mov [rsp+0x30], rax
00007debeebcf868  xor eax, eax
00007debeebcf86a  mov r12d, 0x04
00007debeebcf870  mov r10d, 0xC0
00007debeebcf876  cmp r12, r10
00007debeebcf879  cmc
00007debeebcf87a  lahf
00007debeebcf87b  seto al
00007debeebcf87e  mov [r15+0x108], eax
00007debeebcf885  mov eax, [rsp+0x10]
00007debeebcf889  mov r12d, [rsp+0x10]
00007debeebcf88e  shrd eax, r12d, 0x07
00007debeebcf893  mov [rsp+0x10], r11d
00007debeebcf898  mov r10d, [rsp+0x10]
00007debeebcf89d  shrd r11d, r10d, 0x11
00007debeebcf8a2  mov r9d, [rsp+0x20]
00007debeebcf8a7  lea r8d, [r9d+r14d*1]
00007debeebcf8ac  rorx r14d, r12d, 0x12
00007debeebcf8b2  xor eax, r14d
00007debeebcf8b5  rorx r14d, r10d, 0x13
00007debeebcf8bb  xor r11d, r14d
00007debeebcf8be  mov [rsp+0x10], r11d
00007debeebcf8c3  mov r11d, r11d
00007debeebcf8c6  mov [r15+0x88], r11
00007debeebcf8cd  mov [rsp+0x20], r12d
00007debeebcf8d2  shr r12d, 0x03
00007debeebcf8d6  xor eax, r12d
00007debeebcf8d9  mov [rsp+0x40], eax
00007debeebcf8dd  mov eax, eax
00007debeebcf8df  mov [r15+0x80], rax
00007debeebcf8e6  shr r10d, 0x0A
00007debeebcf8ea  mov eax, [rsp+0x10]
00007debeebcf8ee  xor eax, r10d
00007debeebcf8f1  mov [rsp+0x10], eax
00007debeebcf8f5  mov eax, eax
00007debeebcf8f7  mov [r15+0x78], rax
00007debeebcf8fb  mov eax, [rsp+0x40]
00007debeebcf8ff  lea r14d, [r8d+eax*1]
00007debeebcf904  mov eax, [rsp+0x10]
00007debeebcf908  lea r12d, [r14d+eax*1]
00007debeebcf90d  mov rax, [rsp+0x30]
00007debeebcf912  lea r14, [rax+0x40]
00007debeebcf916  mov [r13+r14*1], r12d
00007debeebcf91b  mov eax, [rsp+0x20]
00007debeebcf91f  mov eax, eax
00007debeebcf921  mov [r15+0x60], rax
00007debeebcf925  mov eax, [r15+0x108]
00007debeebcf92c  sahf
00007debeebcf92d  jnz 0x00007DEBEEBCF95F
00007debeebcf92f  cmp dword ptr [r15+0x318], 0x00
00007debeebcf937  jz 0x00007DEBEEBCFE20
00007debeebcf93d  nop [rax+rax*1], ax
00007debeebcf946  nop [rax+rax*1], eax
00007debeebcf94e  mov eax, 0x41049C
00007debeebcf953  mov [r15+0x100], rax
00007debeebcf95a  jmp 0x00007DEBEE9FE110
00007debeebcf95f  cmp dword ptr [r15+0x318], 0x00
00007debeebcf967  jz 0x00007DEBEEBCFC70
00007debeebcf96d  nop [rax+rax*1], ax
00007debeebcf976  nop [rax+rax*1], eax
00007debeebcf97e  mov eax, 0x410454
00007debeebcf983  mov [r15+0x100], rax
00007debeebcf98a  jmp 0x00007DEBEE9FE110
00007debeebcf98f  int3
00007debeebcf990  call 0x00007DEBEEA0D860
00007debeebcf995  jmp 0x00007DEBEEBCF02A
00007debeebcf99a  call 0x00007DEBEEAE2420
00007debeebcf99f  jmp 0x00007DEBEEBCF043
00007debeebcf9a4  call 0x00007DEBEEAE2420
00007debeebcf9a9  jmp 0x00007DEBEEBCF05C
00007debeebcf9ae  call 0x00007DEBEEAE2420
00007debeebcf9b3  jmp 0x00007DEBEEBCF075
00007debeebcf9b8  call 0x00007DEBEEAE2420
00007debeebcf9bd  jmp 0x00007DEBEEBCF08E
00007debeebcf9c2  call 0x00007DEBEEAE2420
00007debeebcf9c7  jmp 0x00007DEBEEBCF09F
00007debeebcf9cc  call 0x00007DEBEEAE2420
00007debeebcf9d1  jmp 0x00007DEBEEBCF0B0
00007debeebcf9d6  call 0x00007DEBEEAE2420
00007debeebcf9db  jmp 0x00007DEBEEBCF0C1
00007debeebcf9e0  call 0x00007DEBEEAE2420
00007debeebcf9e5  jmp 0x00007DEBEEBCF0D2
00007debeebcf9ea  call 0x00007DEBEEAE2420
00007debeebcf9ef  jmp 0x00007DEBEEBCF0E3
00007debeebcf9f4  call 0x00007DEBEEAE2420
00007debeebcf9f9  jmp 0x00007DEBEEBCF0F4
00007debeebcf9fe  call 0x00007DEBEEAE2420
00007debeebcfa03  jmp 0x00007DEBEEBCF105
00007debeebcfa08  call 0x00007DEBEEAE2420
00007debeebcfa0d  jmp 0x00007DEBEEBCF116
00007debeebcfa12  call 0x00007DEBEEAE2420
00007debeebcfa17  jmp 0x00007DEBEEBCF127
00007debeebcfa1c  call 0x00007DEBEEAE2420
00007debeebcfa21  jmp 0x00007DEBEEBCF138
00007debeebcfa26  call 0x00007DEBEEAE2420
00007debeebcfa2b  jmp 0x00007DEBEEBCF149
00007debeebcfa30  call 0x00007DEBEEAE2420
00007debeebcfa35  jmp 0x00007DEBEEBCF15A
00007debeebcfa3a  call 0x00007DEBEEAE2420
00007debeebcfa3f  jmp 0x00007DEBEEBCF16B
00007debeebcfa44  call 0x00007DEBEEAE2420
00007debeebcfa49  jmp 0x00007DEBEEBCF17C
00007debeebcfa4e  call 0x00007DEBEEAE2420
00007debeebcfa53  jmp 0x00007DEBEEBCF18D
00007debeebcfa58  call 0x00007DEBEEAE2420
00007debeebcfa5d  jmp 0x00007DEBEEBCF19E
00007debeebcfa62  call 0x00007DEBEEAE2420
00007debeebcfa67  jmp 0x00007DEBEEBCF1AF
00007debeebcfa6c  call 0x00007DEBEEAE2420
00007debeebcfa71  jmp 0x00007DEBEEBCF1C0
00007debeebcfa76  call 0x00007DEBEEAE2420
00007debeebcfa7b  jmp 0x00007DEBEEBCF1D1
00007debeebcfa80  call 0x00007DEBEEAE2420
00007debeebcfa85  jmp 0x00007DEBEEBCF1E2
00007debeebcfa8a  call 0x00007DEBEEAE2420
00007debeebcfa8f  jmp 0x00007DEBEEBCF1F3
00007debeebcfa94  call 0x00007DEBEEAE2420
00007debeebcfa99  jmp 0x00007DEBEEBCF204
00007debeebcfa9e  call 0x00007DEBEEAE2420
00007debeebcfaa3  jmp 0x00007DEBEEBCF215
00007debeebcfaa8  call 0x00007DEBEEAE2420
00007debeebcfaad  jmp 0x00007DEBEEBCF226
00007debeebcfab2  call 0x00007DEBEEAE2420
00007debeebcfab7  jmp 0x00007DEBEEBCF237
00007debeebcfabc  call 0x00007DEBEEAE2420
00007debeebcfac1  jmp 0x00007DEBEEBCF248
00007debeebcfac6  call 0x00007DEBEEAE2420
00007debeebcfacb  jmp 0x00007DEBEEBCF259
00007debeebcfad0  call 0x00007DEBEEAE2420
00007debeebcfad5  jmp 0x00007DEBEEBCF26A
00007debeebcfada  call 0x00007DEBEEAE2420
00007debeebcfadf  jmp 0x00007DEBEEBCF27B
00007debeebcfae4  call 0x00007DEBEEAE2420
00007debeebcfae9  jmp 0x00007DEBEEBCF28C
00007debeebcfaee  call 0x00007DEBEEAE2420
00007debeebcfaf3  jmp 0x00007DEBEEBCF29D
00007debeebcfaf8  call 0x00007DEBEEAE2420
00007debeebcfafd  jmp 0x00007DEBEEBCF2AE
00007debeebcfb02  call 0x00007DEBEEAE2420
00007debeebcfb07  jmp 0x00007DEBEEBCF2BF
00007debeebcfb0c  call 0x00007DEBEEAE2420
00007debeebcfb11  jmp 0x00007DEBEEBCF2D0
00007debeebcfb16  call 0x00007DEBEEAE2420
00007debeebcfb1b  jmp 0x00007DEBEEBCF2E1
00007debeebcfb20  call 0x00007DEBEEAE2420
00007debeebcfb25  jmp 0x00007DEBEEBCF2F2
00007debeebcfb2a  call 0x00007DEBEEAE2420
00007debeebcfb2f  jmp 0x00007DEBEEBCF303
00007debeebcfb34  call 0x00007DEBEEAE2420
00007debeebcfb39  jmp 0x00007DEBEEBCF314
00007debeebcfb3e  call 0x00007DEBEEAE2420
00007debeebcfb43  jmp 0x00007DEBEEBCF325
00007debeebcfb48  call 0x00007DEBEEAE2420
00007debeebcfb4d  jmp 0x00007DEBEEBCF336
00007debeebcfb52  call 0x00007DEBEEAE2420
00007debeebcfb57  jmp 0x00007DEBEEBCF347
00007debeebcfb5c  call 0x00007DEBEEAE2420
00007debeebcfb61  jmp 0x00007DEBEEBCF358
00007debeebcfb66  call 0x00007DEBEEAE2420
00007debeebcfb6b  jmp 0x00007DEBEEBCF369
00007debeebcfb70  call 0x00007DEBEEAE2420
00007debeebcfb75  jmp 0x00007DEBEEBCF37A
00007debeebcfb7a  call 0x00007DEBEEAE2420
00007debeebcfb7f  jmp 0x00007DEBEEBCF38B
00007debeebcfb84  call 0x00007DEBEEAE2420
00007debeebcfb89  jmp 0x00007DEBEEBCF39C
00007debeebcfb8e  call 0x00007DEBEEAE2420
00007debeebcfb93  jmp 0x00007DEBEEBCF3AD
00007debeebcfb98  call 0x00007DEBEEAE2420
00007debeebcfb9d  jmp 0x00007DEBEEBCF3BE
00007debeebcfba2  call 0x00007DEBEEAE2420
00007debeebcfba7  jmp 0x00007DEBEEBCF3CF
00007debeebcfbac  call 0x00007DEBEEAE2420
00007debeebcfbb1  jmp 0x00007DEBEEBCF3E0
00007debeebcfbb6  call 0x00007DEBEEAE2420
00007debeebcfbbb  jmp 0x00007DEBEEBCF3F1
00007debeebcfbc0  call 0x00007DEBEEAE2420
00007debeebcfbc5  jmp 0x00007DEBEEBCF402
00007debeebcfbca  call 0x00007DEBEEAE2420
00007debeebcfbcf  jmp 0x00007DEBEEBCF413
00007debeebcfbd4  call 0x00007DEBEEAE2420
00007debeebcfbd9  jmp 0x00007DEBEEBCF424
00007debeebcfbde  call 0x00007DEBEEAE2420
00007debeebcfbe3  jmp 0x00007DEBEEBCF435
00007debeebcfbe8  call 0x00007DEBEEAE2420
00007debeebcfbed  jmp 0x00007DEBEEBCF446
00007debeebcfbf2  call 0x00007DEBEEAE2420
00007debeebcfbf7  jmp 0x00007DEBEEBCF45F
00007debeebcfbfc  call 0x00007DEBEEAE2420
00007debeebcfc01  jmp 0x00007DEBEEBCF478
00007debeebcfc06  call 0x00007DEBEEAD5610
00007debeebcfc0b  jmp 0x00007DEBEEBCF491
00007debeebcfc10  call 0x00007DEBEEADC580
00007debeebcfc15  jmp 0x00007DEBEEBCF7FE
00007debeebcfc1a  call 0x00007DEBEEAE46C0
00007debeebcfc1f  jmp 0x00007DEBEEBCF808
00007debeebcfc24  call 0x00007DEBEEA09E90
00007debeebcfc29  jmp 0x00007DEBEEBCF80E
00007debeebcfc2e  call 0x00007DEBEEADB310
00007debeebcfc33  jmp 0x00007DEBEEBCF818
00007debeebcfc38  call 0x00007DEBEEA0DAE0
00007debeebcfc3d  jmp 0x00007DEBEEBCF81D
00007debeebcfc42  call 0x00007DEBEEAC0230
00007debeebcfc47  jmp 0x00007DEBEEBCF836
00007debeebcfc4c  call 0x00007DEBEEAC0230
00007debeebcfc51  jmp 0x00007DEBEEBCF84B
00007debeebcfc56  call 0x00007DEBEEABEFC0
00007debeebcfc5b  jmp 0x00007DEBEEBCF854
00007debeebcfc60  call 0x00007DEBEEAE2BA0
00007debeebcfc65  jmp 0x00007DEBEEBCF91B
00007debeebcfc6a  int3
00007debeebcfc6b  nop [rax+rax*1], eax
00007debeebcfc70  mov rax, [r15+0x48]
00007debeebcfc74  mov r14, [r15+0x58]
00007debeebcfc78  lea r12, [rax+r14*1]
00007debeebcfc7c  mov [r15+0x68], r12
00007debeebcfc80  lea rax, [r14+0x04]
00007debeebcfc84  mov [r15+0x58], rax
00007debeebcfc88  lea r14, [r12+0x04]
00007debeebcfc8d  mov r11d, [r13+r14*1]
00007debeebcfc92  mov [rsp+0x10], r11d
00007debeebcfc97  mov r11d, r11d
00007debeebcfc9a  mov [r15+0x70], r11
00007debeebcfc9e  lea r14, [r12+0x38]
00007debeebcfca3  mov r11d, [r13+r14*1]
00007debeebcfca8  lea r14, [r12+0x24]
00007debeebcfcad  mov r10d, [r13+r14*1]
00007debeebcfcb2  mov [rsp+0x20], r10d
00007debeebcfcb7  mov r10d, r10d
00007debeebcfcba  mov [r15+0x90], r10
00007debeebcfcc1  mov [rsp+0x30], rax
00007debeebcfcc6  xor eax, eax
00007debeebcfcc8  mov r14, [rsp+0x30]
00007debeebcfccd  mov r10d, 0xC0
00007debeebcfcd3  cmp r14, r10
00007debeebcfcd6  cmc
00007debeebcfcd7  lahf
00007debeebcfcd8  seto al
00007debeebcfcdb  mov [r15+0x108], eax
00007debeebcfce2  mov eax, [rsp+0x10]
00007debeebcfce6  mov r14d, [rsp+0x10]
00007debeebcfceb  shrd eax, r14d, 0x07
00007debeebcfcf0  mov [rsp+0x10], r11d
00007debeebcfcf5  mov r10d, [rsp+0x10]
00007debeebcfcfa  shrd r11d, r10d, 0x11
00007debeebcfcff  mov r9d, [r15+0x60]
00007debeebcfd03  mov r8d, [rsp+0x20]
00007debeebcfd08  lea ebp, [r8d+r9d*1]
00007debeebcfd0d  rorx r9d, r14d, 0x12
00007debeebcfd13  xor eax, r9d
00007debeebcfd16  rorx r9d, r10d, 0x13
00007debeebcfd1c  xor r11d, r9d
00007debeebcfd1f  mov [rsp+0x10], r11d
00007debeebcfd24  mov r11d, r11d
00007debeebcfd27  mov [r15+0x88], r11
00007debeebcfd2e  mov [rsp+0x20], r14d
00007debeebcfd33  shr r14d, 0x03
00007debeebcfd37  xor eax, r14d
00007debeebcfd3a  mov [rsp+0x30], eax
00007debeebcfd3e  mov eax, eax
00007debeebcfd40  mov [r15+0x80], rax
00007debeebcfd47  shr r10d, 0x0A
00007debeebcfd4b  mov eax, [rsp+0x10]
00007debeebcfd4f  xor eax, r10d
00007debeebcfd52  mov [rsp+0x10], eax
00007debeebcfd56  mov eax, eax
00007debeebcfd58  mov [r15+0x78], rax
00007debeebcfd5c  mov eax, [rsp+0x30]
00007debeebcfd60  lea r14d, [ebp+eax*1]
00007debeebcfd66  mov eax, [rsp+0x10]
00007debeebcfd6a  lea r11d, [r14d+eax*1]
00007debeebcfd6f  lea rax, [r12+0x40]
00007debeebcfd74  mov [r13+rax*1], r11d
00007debeebcfd79  mov eax, [rsp+0x20]
00007debeebcfd7d  mov eax, eax
00007debeebcfd7f  mov [r15+0x60], rax
00007debeebcfd83  mov eax, [r15+0x108]
00007debeebcfd8a  sahf
00007debeebcfd8b  jnz 0x00007DEBEEBCFDBD
00007debeebcfd8d  cmp dword ptr [r15+0x318], 0x00
00007debeebcfd95  jz 0x00007DEBEEBCFE20
00007debeebcfd9b  nop [rax+rax*1], ax
00007debeebcfda4  nop [rax+rax*1], eax
00007debeebcfdac  mov eax, 0x41049C
00007debeebcfdb1  mov [r15+0x100], rax
00007debeebcfdb8  jmp 0x00007DEBEE9FE110
00007debeebcfdbd  cmp dword ptr [r15+0x318], 0x00
00007debeebcfdc5  jz 0x00007DEBEEBCFC70
00007debeebcfdcb  nop [rax+rax*1], ax
00007debeebcfdd4  nop [rax+rax*1], eax
00007debeebcfddc  mov eax, 0x410454
00007debeebcfde1  mov [r15+0x100], rax
00007debeebcfde8  jmp 0x00007DEBEE9FE110
00007debeebcfded  int3
00007debeebcfdee  call 0x00007DEBEEAE1430
00007debeebcfdf3  jmp 0x00007DEBEEBCFC92
00007debeebcfdf8  call 0x00007DEBEEAE1430
00007debeebcfdfd  jmp 0x00007DEBEEBCFCA8
00007debeebcfe02  call 0x00007DEBEEAE01C0
00007debeebcfe07  jmp 0x00007DEBEEBCFCB2
00007debeebcfe0c  call 0x00007DEBEEA0A860
00007debeebcfe11  jmp 0x00007DEBEEBCFD79
00007debeebcfe16  int3
00007debeebcfe17  nop [rax+rax*1], ax
00007debeebcfe20  mov rax, [r15]
00007debeebcfe23  mov r14d, [r13+rax*1]
00007debeebcfe28  lea r12, [rax+0x04]
00007debeebcfe2c  mov r11d, [r13+r12*1]
00007debeebcfe31  mov [rsp+0x10], r14d
00007debeebcfe36  mov r14d, r14d
00007debeebcfe39  mov [r15+0x78], r14
00007debeebcfe3d  mov [rsp+0x20], r11d
00007debeebcfe42  mov r11d, r11d
00007debeebcfe45  mov [r15+0x80], r11
00007debeebcfe4c  lea r14, [rax+0x08]
00007debeebcfe50  mov r12d, [r13+r14*1]
00007debeebcfe55  lea r14, [rax+0x0C]
00007debeebcfe59  mov r11d, [r13+r14*1]
00007debeebcfe5e  mov [rsp+0x30], r12d
00007debeebcfe63  mov r12d, r12d
00007debeebcfe66  mov [r15+0x70], r12
00007debeebcfe6a  mov [rsp+0x40], r11d
00007debeebcfe6f  mov r11d, r11d
00007debeebcfe72  mov [r15+0x68], r11
00007debeebcfe76  lea r14, [rax+0x18]
00007debeebcfe7a  mov r12d, [r13+r14*1]
00007debeebcfe7f  lea r14, [rax+0x1C]
00007debeebcfe83  mov r11d, [r13+r14*1]
00007debeebcfe88  mov [rsp+0x50], r12d
00007debeebcfe8d  mov r12d, r12d
00007debeebcfe90  mov [r15+0x58], r12
00007debeebcfe94  mov [rsp+0x60], r11d
00007debeebcfe99  mov r11d, r11d
00007debeebcfe9c  mov [r15+0x60], r11
00007debeebcfea0  lea r14, [rax+0x10]
00007debeebcfea4  mov r12d, [r13+r14*1]
00007debeebcfea9  lea r14, [rax+0x14]
00007debeebcfead  mov eax, [r13+r14*1]
00007debeebcfeb2  mov [rsp+0x70], r12d
00007debeebcfeb7  mov r12d, r12d
00007debeebcfeba  mov [r15+0x18], r12
00007debeebcfebe  mov [rsp+0x80], eax
00007debeebcfec5  mov eax, eax
00007debeebcfec7  mov [r15+0x90], rax
00007debeebcfece  mov eax, [rsp+0x70]
00007debeebcfed2  mov eax, eax
00007debeebcfed4  mov [r15+0x30], rax
00007debeebcfed8  mov eax, [rsp+0x50]
00007debeebcfedc  mov eax, eax
00007debeebcfede  mov [r15+0xA0], rax
00007debeebcfee5  mov eax, [rsp+0x30]
00007debeebcfee9  mov eax, eax
00007debeebcfeeb  mov [r15+0x28], rax
00007debeebcfeef  mov eax, [rsp+0x20]
00007debeebcfef3  mov eax, eax
00007debeebcfef5  mov [r15+0x98], rax
00007debeebcfefc  mov eax, [rsp+0x10]
00007debeebcff00  mov eax, eax
00007debeebcff02  mov [r15+0x38], rax
00007debeebcff06  mov eax, [rsp+0x70]
00007debeebcff0a  mov r14d, [rsp+0x70]
00007debeebcff0f  shrd eax, r14d, 0x06
00007debeebcff14  mov [rsp+0x70], r14d
00007debeebcff19  mov r12d, [rsp+0x80]
00007debeebcff21  and r14d, r12d
00007debeebcff24  mov r11d, [rsp+0x10]
00007debeebcff29  mov r10d, [rsp+0x10]
00007debeebcff2e  shrd r11d, r10d, 0x02
00007debeebcff33  mov [rsp+0x10], r12d
00007debeebcff38  mov r12d, r12d
00007debeebcff3b  mov [r15+0x20], r12
00007debeebcff3f  mov r12, [r15+0x50]
00007debeebcff43  mov r9d, [r13+r12*1]
00007debeebcff48  mov r12d, [rsp+0x50]
00007debeebcff4d  mov r8d, [rsp+0x70]
00007debeebcff52  andn ebp, r8d, r12d
00007debeebcff57  mov edi, [rsp+0x60]
00007debeebcff5b  lea esi, [r14d+edi*1]
00007debeebcff60  rorx r14d, r8d, 0x0B
00007debeebcff66  xor eax, r14d
00007debeebcff69  rorx r14d, r10d, 0x0D
00007debeebcff6f  xor r11d, r14d
00007debeebcff72  lea edi, [esi+ebp*1]
00007debeebcff76  mov r14, [r15+0x48]
00007debeebcff7a  mov ebp, [r13+r14*1]
00007debeebcff7f  mov r14d, [rsp+0x30]
00007debeebcff84  mov esi, [rsp+0x20]
00007debeebcff88  and r14d, esi
00007debeebcff8b  mov [rsp+0x20], r14d
00007debeebcff90  mov r14d, r14d
00007debeebcff93  mov [r15+0xD8], r14
00007debeebcff9a  lea r14d, [edi+r9d*1]
00007debeebcff9f  mov r9d, [rsp+0x30]
00007debeebcffa4  xor r9d, esi
00007debeebcffa7  rorx edi, r8d, 0x19
00007debeebcffad  xor eax, edi
00007debeebcffaf  and r9d, r10d
00007debeebcffb2  rorx edi, r10d, 0x16
00007debeebcffb8  xor r11d, edi
00007debeebcffbb  mov [rsp+0x30], r11d
00007debeebcffc0  mov r11d, r11d
00007debeebcffc3  mov [r15+0xD0], r11
00007debeebcffca  lea r11d, [r14d+ebp*1]
00007debeebcffcf  mov r10d, [rsp+0x20]
00007debeebcffd4  xor r9d, r10d
00007debeebcffd7  lea r14d, [r11d+eax*1]
00007debeebcffdc  mov qword ptr [r15+0x88], 0x04
00007debeebcffe7  mov eax, [rsp+0x30]
00007debeebcffeb  lea r11d, [r9d+eax*1]
00007debeebcfff0  mov eax, [rsp+0x40]
00007debeebcfff4  lea r10d, [r14d+eax*1]
00007debeebcfff9  mov r10d, r10d
00007debeebcfffc  mov [r15+0xB8], r10
00007debeebd0003  xor eax, eax
00007debeebd0005  mov r10d, 0x04
00007debeebd000b  mov r9d, 0x100
00007debeebd0011  cmp r10, r9
00007debeebd0014  cmc
00007debeebd0015  lahf
00007debeebd0016  seto al
00007debeebd0019  mov [r15+0x108], eax
00007debeebd0020  lea eax, [r11d+r14d*1]
00007debeebd0025  mov eax, eax
00007debeebd0027  mov [r15+0xA8], rax
00007debeebd002e  mov r12d, r12d
00007debeebd0031  mov [r15+0xB0], r12
00007debeebd0038  mov eax, [rsp+0x10]
00007debeebd003c  mov eax, eax
00007debeebd003e  mov [r15+0xC0], rax
00007debeebd0045  mov r8d, r8d
00007debeebd0048  mov [r15+0xC8], r8
00007debeebd004f  mov eax, [r15+0x108]
00007debeebd0056  sahf
00007debeebd0057  jnz 0x00007DEBEEBD0089
00007debeebd0059  cmp dword ptr [r15+0x318], 0x00
00007debeebd0061  jz 0x00007DEBEEBD0350
00007debeebd0067  nop [rax+rax*1], ax
00007debeebd0070  nop [rax+rax*1], eax
00007debeebd0078  mov eax, 0x41055C
00007debeebd007d  mov [r15+0x100], rax
00007debeebd0084  jmp 0x00007DEBEE9FE110
00007debeebd0089  cmp dword ptr [r15+0x318], 0x00
00007debeebd0091  jz 0x00007DEBEEBD0120
00007debeebd0097  nop [rax+rax*1], ax
00007debeebd00a0  nop [rax+rax*1], eax
00007debeebd00a8  mov eax, 0x4104D0
00007debeebd00ad  mov [r15+0x100], rax
00007debeebd00b4  jmp 0x00007DEBEE9FE110
00007debeebd00b9  int3
00007debeebd00ba  call 0x00007DEBEEA0DAE0
00007debeebd00bf  jmp 0x00007DEBEEBCFE28
00007debeebd00c4  call 0x00007DEBEEAC0230
00007debeebd00c9  jmp 0x00007DEBEEBCFE31
00007debeebd00ce  call 0x00007DEBEEAE26A0
00007debeebd00d3  jmp 0x00007DEBEEBCFE55
00007debeebd00d8  call 0x00007DEBEEAE1430
00007debeebd00dd  jmp 0x00007DEBEEBCFE5E
00007debeebd00e2  call 0x00007DEBEEAE26A0
00007debeebd00e7  jmp 0x00007DEBEEBCFE7F
00007debeebd00ec  call 0x00007DEBEEAE1430
00007debeebd00f1  jmp 0x00007DEBEEBCFE88
00007debeebd00f6  call 0x00007DEBEEAE26A0
00007debeebd00fb  jmp 0x00007DEBEEBCFEA9
00007debeebd0100  call 0x00007DEBEEAD5890
00007debeebd0105  jmp 0x00007DEBEEBCFEB2
00007debeebd010a  call 0x00007DEBEEABDD50
00007debeebd010f  jmp 0x00007DEBEEBCFF48
00007debeebd0114  call 0x00007DEBEEADA580
00007debeebd0119  jmp 0x00007DEBEEBCFF7F
00007debeebd011e  int3
00007debeebd011f  nop
00007debeebd0120  mov eax, [r15+0xB8]
00007debeebd0127  mov [rsp+0x10], eax
00007debeebd012b  mov eax, eax
00007debeebd012d  mov [r15+0x30], rax
00007debeebd0131  mov eax, [r15+0xC0]
00007debeebd0138  mov [rsp+0x20], eax
00007debeebd013c  mov eax, eax
00007debeebd013e  mov [r15+0xA0], rax
00007debeebd0145  mov eax, [r15+0x28]
00007debeebd0149  mov r14d, [r15+0x98]
00007debeebd0150  mov [rsp+0x30], r14d
00007debeebd0155  mov r14d, r14d
00007debeebd0158  mov [r15+0x28], r14
00007debeebd015c  mov r14d, [r15+0x38]
00007debeebd0160  mov [rsp+0x40], r14d
00007debeebd0165  mov r14d, r14d
00007debeebd0168  mov [r15+0x98], r14
00007debeebd016f  mov r14d, [r15+0xA8]
00007debeebd0176  mov [rsp+0x50], r14d
00007debeebd017b  mov r14d, r14d
00007debeebd017e  mov [r15+0x38], r14
00007debeebd0182  mov r14d, [rsp+0x10]
00007debeebd0187  mov r12d, [rsp+0x10]
00007debeebd018c  shrd r14d, r12d, 0x06
00007debeebd0191  mov r11d, [r15+0xC8]
00007debeebd0198  mov [rsp+0x10], r12d
00007debeebd019d  and r12d, r11d
00007debeebd01a0  mov r10d, [rsp+0x50]
00007debeebd01a5  mov r9d, [rsp+0x50]
00007debeebd01aa  shrd r10d, r9d, 0x02
00007debeebd01af  mov [rsp+0x50], r11d
00007debeebd01b4  mov r11d, r11d
00007debeebd01b7  mov [r15+0x20], r11
00007debeebd01bb  mov r11, [r15+0x88]
00007debeebd01c2  mov r8, [r15+0x50]
00007debeebd01c6  lea rbp, [r8+r11*1]
00007debeebd01ca  mov r8d, [r13+rbp*1]
00007debeebd01cf  mov ebp, [rsp+0x20]
00007debeebd01d3  mov edi, [rsp+0x10]
00007debeebd01d7  andn esi, edi, ebp
00007debeebd01dc  mov edx, [r15+0xB0]
00007debeebd01e3  lea ecx, [r12d+edx*1]
00007debeebd01e8  rorx r12d, edi, 0x0B
00007debeebd01ee  xor r14d, r12d
00007debeebd01f1  rorx r12d, r9d, 0x0D
00007debeebd01f7  xor r10d, r12d
00007debeebd01fa  lea r12d, [ecx+esi*1]
00007debeebd01ff  mov rsi, [r15+0x48]
00007debeebd0203  lea rdx, [rsi+r11*1]
00007debeebd0207  mov esi, [r13+rdx*1]
00007debeebd020c  mov edx, [rsp+0x30]
00007debeebd0210  mov ecx, [rsp+0x40]
00007debeebd0214  and edx, ecx
00007debeebd0216  mov [rsp+0x10], edx
00007debeebd021a  mov edx, edx
00007debeebd021c  mov [r15+0xD8], rdx
00007debeebd0223  lea edx, [r12d+r8d*1]
00007debeebd0228  mov r12d, [rsp+0x30]
00007debeebd022d  xor r12d, ecx
00007debeebd0230  rorx r8d, edi, 0x19
00007debeebd0236  xor r14d, r8d
00007debeebd0239  and r12d, r9d
00007debeebd023c  rorx r8d, r9d, 0x16
00007debeebd0242  xor r10d, r8d
00007debeebd0245  mov [rsp+0x20], r10d
00007debeebd024a  mov r10d, r10d
00007debeebd024d  mov [r15+0xD0], r10
00007debeebd0254  lea r10d, [edx+esi*1]
00007debeebd0259  mov r9d, [rsp+0x10]
00007debeebd025e  xor r12d, r9d
00007debeebd0261  lea r9d, [r10d+r14d*1]
00007debeebd0266  lea r14, [r11+0x04]
00007debeebd026a  mov [r15+0x88], r14
00007debeebd0271  mov r11d, [rsp+0x20]
00007debeebd0276  lea r10d, [r12d+r11d*1]
00007debeebd027b  lea r11d, [r9d+eax*1]
00007debeebd0280  mov r11d, r11d
00007debeebd0283  mov [r15+0xB8], r11
00007debeebd028a  xor eax, eax
00007debeebd028c  mov r12d, 0x100
00007debeebd0292  cmp r14, r12
00007debeebd0295  cmc
00007debeebd0296  lahf
00007debeebd0297  seto al
00007debeebd029a  mov [r15+0x108], eax
00007debeebd02a1  lea eax, [r10d+r9d*1]
00007debeebd02a6  mov eax, eax
00007debeebd02a8  mov [r15+0xA8], rax
00007debeebd02af  mov ebp, ebp
00007debeebd02b1  mov [r15+0xB0], rbp
00007debeebd02b8  mov eax, [rsp+0x50]
00007debeebd02bc  mov eax, eax
00007debeebd02be  mov [r15+0xC0], rax
00007debeebd02c5  mov edi, edi
00007debeebd02c7  mov [r15+0xC8], rdi
00007debeebd02ce  mov eax, [r15+0x108]
00007debeebd02d5  sahf
00007debeebd02d6  jnz 0x00007DEBEEBD0308
00007debeebd02d8  cmp dword ptr [r15+0x318], 0x00
00007debeebd02e0  jz 0x00007DEBEEBD0350
00007debeebd02e6  nop [rax+rax*1], ax
00007debeebd02ef  nop [rax+rax*1], eax
00007debeebd02f7  mov eax, 0x41055C
00007debeebd02fc  mov [r15+0x100], rax
00007debeebd0303  jmp 0x00007DEBEE9FE110
00007debeebd0308  cmp dword ptr [r15+0x318], 0x00
00007debeebd0310  jz 0x00007DEBEEBD0120
00007debeebd0316  nop [rax+rax*1], ax
00007debeebd031f  nop [rax+rax*1], eax
00007debeebd0327  mov eax, 0x4104D0
00007debeebd032c  mov [r15+0x100], rax
00007debeebd0333  jmp 0x00007DEBEE9FE110
00007debeebd0338  int3
00007debeebd0339  call 0x00007DEBEEA49010
00007debeebd033e  jmp 0x00007DEBEEBD01CF
00007debeebd0343  call 0x00007DEBEEA25930
00007debeebd0348  jmp 0x00007DEBEEBD020C
00007debeebd034d  int3
00007debeebd034e  nop
00007debeebd0350  mov eax, [r15+0x98]
00007debeebd0357  mov r14d, [r15+0x70]
00007debeebd035b  lea r12d, [eax+r14d*1]
00007debeebd0360  mov eax, [r15+0x28]
00007debeebd0364  mov r14d, [r15+0x68]
00007debeebd0368  lea r11d, [eax+r14d*1]
00007debeebd036d  mov qword ptr [r15+0x88], 0x00
00007debeebd0378  mov eax, [r15+0xA8]
00007debeebd037f  mov r14d, [r15+0x78]
00007debeebd0383  lea r10d, [eax+r14d*1]
00007debeebd0388  mov [rsp+0x10], r10d
00007debeebd038d  mov r10d, r10d
00007debeebd0390  mov [r15+0x78], r10
00007debeebd0394  mov eax, [r15+0x38]
00007debeebd0398  mov r14d, [r15+0x80]
00007debeebd039f  lea r10d, [eax+r14d*1]
00007debeebd03a4  mov [rsp+0x20], r10d
00007debeebd03a9  mov r10d, r10d
00007debeebd03ac  mov [r15+0x80], r10
00007debeebd03b3  mov rax, [r15]
00007debeebd03b6  lea r14, [rax+0x08]
00007debeebd03ba  mov [r13+r14*1], r12d
00007debeebd03bf  lea r14, [rax+0x0C]
00007debeebd03c3  mov [r13+r14*1], r11d
00007debeebd03c8  mov r14d, [r15+0xB8]
00007debeebd03cf  mov r12d, [r15+0x18]
00007debeebd03d3  lea r11d, [r14d+r12d*1]
00007debeebd03d8  mov [rsp+0x30], r11d
00007debeebd03dd  mov r11d, r11d
00007debeebd03e0  mov [r15+0x68], r11
00007debeebd03e4  mov r14d, [r15+0x30]
00007debeebd03e8  mov r12d, [r15+0x90]
00007debeebd03ef  lea r11d, [r14d+r12d*1]
00007debeebd03f4  mov [rsp+0x40], r11d
00007debeebd03f9  mov r11d, r11d
00007debeebd03fc  mov [r15+0x70], r11
00007debeebd0400  mov r14d, [r15+0x20]
00007debeebd0404  mov r12d, [r15+0x58]
00007debeebd0408  lea r11d, [r14d+r12d*1]
00007debeebd040d  mov [rsp+0x50], r11d
00007debeebd0412  mov r11d, r11d
00007debeebd0415  mov [r15+0x58], r11
00007debeebd0419  mov r14d, [r15+0xA0]
00007debeebd0420  mov r12d, [r15+0x60]
00007debeebd0424  lea r11d, [r14d+r12d*1]
00007debeebd0429  mov [rsp+0x60], r11d
00007debeebd042e  mov r11d, r11d
00007debeebd0431  mov [r15+0x60], r11
00007debeebd0435  mov r14d, [rsp+0x10]
00007debeebd043a  mov [r13+rax*1], r14d
00007debeebd043f  lea r14, [rax+0x04]
00007debeebd0443  mov r12d, [rsp+0x20]
00007debeebd0448  mov [r13+r14*1], r12d
00007debeebd044d  lea r14, [rax+0x10]
00007debeebd0451  mov r12d, [rsp+0x30]
00007debeebd0456  mov [r13+r14*1], r12d
00007debeebd045b  lea r14, [rax+0x14]
00007debeebd045f  mov r12d, [rsp+0x40]
00007debeebd0464  mov [r13+r14*1], r12d
00007debeebd0469  lea r14, [rax+0x18]
00007debeebd046d  mov r12d, [rsp+0x50]
00007debeebd0472  mov [r13+r14*1], r12d
00007debeebd0477  lea r14, [rax+0x1C]
00007debeebd047b  mov r12d, [rsp+0x60]
00007debeebd0480  mov [r13+r14*1], r12d
00007debeebd0485  lea r14, [rax+0x68]
00007debeebd0489  xor eax, eax
00007debeebd048b  mov [r13+r14*1], rax
00007debeebd0490  cmp dword ptr [r15+0x318], 0x00
00007debeebd0498  jz 0x00007DEBEEBCEF90
00007debeebd049e  nop [rax+rax*1], ax
00007debeebd04a7  nop [rax+rax*1], eax
00007debeebd04af  mov eax, 0x410378
00007debeebd04b4  mov [r15+0x100], rax
00007debeebd04bb  jmp 0x00007DEBEE9FE110
00007debeebd04c0  int3
00007debeebd04c1  call 0x00007DEBEEAE2BA0
00007debeebd04c6  jmp 0x00007DEBEEBD03BF
00007debeebd04cb  call 0x00007DEBEEAE1920
00007debeebd04d0  jmp 0x00007DEBEEBD03C8
00007debeebd04d5  call 0x00007DEBEEA0DFE0
00007debeebd04da  jmp 0x00007DEBEEBD043F
00007debeebd04df  call 0x00007DEBEEAE2BA0
00007debeebd04e4  jmp 0x00007DEBEEBD044D
00007debeebd04e9  call 0x00007DEBEEAE2BA0
00007debeebd04ee  jmp 0x00007DEBEEBD045B
00007debeebd04f3  call 0x00007DEBEEAE2BA0
00007debeebd04f8  jmp 0x00007DEBEEBD0469
00007debeebd04fd  call 0x00007DEBEEAE2BA0
00007debeebd0502  jmp 0x00007DEBEEBD0477
00007debeebd0507  call 0x00007DEBEEAE2BA0
00007debeebd050c  jmp 0x00007DEBEEBD0485
00007debeebd0511  call 0x00007DEBEEAD5EB0
00007debeebd0516  jmp 0x00007DEBEEBD0490
00007debeebd051b  int3
00007debeebd051c  nop [rax], eax
00007debeebd0520  mov rax, [r15+0xF8]
00007debeebd0527  lea r14, [rax+0x140]
00007debeebd052e  mov r12, [r13+r14*1]
00007debeebd0533  lea r14, [rax+0x148]
00007debeebd053a  mov r11, [r13+r14*1]
00007debeebd053f  mov [r15+0xA0], r12
00007debeebd0546  mov [r15+0x98], r11
00007debeebd054d  lea r14, [rax+0x130]
00007debeebd0554  mov r12, [r13+r14*1]
00007debeebd0559  lea r14, [rax+0x138]
00007debeebd0560  mov r11, [r13+r14*1]
00007debeebd0565  mov [r15+0xB0], r12
00007debeebd056c  mov [r15+0xA8], r11
00007debeebd0573  lea r14, [rax+0x120]
00007debeebd057a  mov r12, [r13+r14*1]
00007debeebd057f  lea r14, [rax+0x128]
00007debeebd0586  mov r11, [r13+r14*1]
00007debeebd058b  mov [r15+0xC0], r12
00007debeebd0592  mov [r15+0xB8], r11
00007debeebd0599  lea r14, [rax+0x110]
00007debeebd05a0  mov r12, [r13+r14*1]
00007debeebd05a5  lea r14, [rax+0x118]
00007debeebd05ac  mov r11, [r13+r14*1]
00007debeebd05b1  mov [r15+0xD0], r12
00007debeebd05b8  mov [r15+0xC8], r11
00007debeebd05bf  lea r14, [rax+0x100]
00007debeebd05c6  mov r12, [r13+r14*1]
00007debeebd05cb  lea r14, [rax+0x108]
00007debeebd05d2  mov r11, [r13+r14*1]
00007debeebd05d7  mov [r15+0xE8], r12
00007debeebd05de  mov [r15+0xD8], r11
00007debeebd05e5  lea r14, [rax+0x150]
00007debeebd05ec  mov [r15+0xF8], r14
00007debeebd05f3  mov rax, [r15+0xF0]
00007debeebd05fa  mov [r15+0x100], rax
00007debeebd0601  jmp 0x00007DEBEEBCE5C0
00007debeebd0606  int3
00007debeebd0607  call 0x00007DEBEEAE27E0
00007debeebd060c  jmp 0x00007DEBEEBD0533
00007debeebd0611  call 0x00007DEBEEAE1570
00007debeebd0616  jmp 0x00007DEBEEBD053F
00007debeebd061b  call 0x00007DEBEEAE27E0
00007debeebd0620  jmp 0x00007DEBEEBD0559
00007debeebd0625  call 0x00007DEBEEAE1570
00007debeebd062a  jmp 0x00007DEBEEBD0565
00007debeebd062f  call 0x00007DEBEEAE27E0
00007debeebd0634  jmp 0x00007DEBEEBD057F
00007debeebd0639  call 0x00007DEBEEAE1570
00007debeebd063e  jmp 0x00007DEBEEBD058B
00007debeebd0643  call 0x00007DEBEEAE27E0
00007debeebd0648  jmp 0x00007DEBEEBD05A5
00007debeebd064d  call 0x00007DEBEEAE1570
00007debeebd0652  jmp 0x00007DEBEEBD05B1
00007debeebd0657  call 0x00007DEBEEAE27E0
00007debeebd065c  jmp 0x00007DEBEEBD05CB
00007debeebd0661  call 0x00007DEBEEAE1570
00007debeebd0666  jmp 0x00007DEBEEBD05D7
00007debeebd066b  int3
00007debeebd066c  nop [rax], eax
00007debeebd0670  mov eax, [r15+0xA0]
00007debeebd0677  mov [rsp+0x10], eax
00007debeebd067b  xor eax, eax
00007debeebd067d  mov r14d, [rsp+0x10]
00007debeebd0682  sub r14d, 0x01
00007debeebd0686  cmc
00007debeebd0687  lahf
00007debeebd0688  seto al
00007debeebd068b  mov [r15+0x108], eax
00007debeebd0692  mov r14d, r14d
00007debeebd0695  mov [r15+0xA0], r14
00007debeebd069c  mov eax, [r15+0x108]
00007debeebd06a3  sahf
00007debeebd06a4  jnz 0x00007DEBEEBD06D6
00007debeebd06a6  cmp dword ptr [r15+0x318], 0x00
00007debeebd06ae  jz 0x00007DEBEEBD07A0
00007debeebd06b4  nop [rax+rax*1], ax
00007debeebd06bd  nop [rax+rax*1], eax
00007debeebd06c5  mov eax, 0x41027C
00007debeebd06ca  mov [r15+0x100], rax
00007debeebd06d1  jmp 0x00007DEBEE9FE110
00007debeebd06d6  cmp dword ptr [r15+0x318], 0x00
00007debeebd06de  jz 0x00007DEBEEBD0710
00007debeebd06e4  nop [rax+rax*1], ax
00007debeebd06ed  nop [rax+rax*1], eax
00007debeebd06f5  mov eax, 0x410264
00007debeebd06fa  mov [r15+0x100], rax
00007debeebd0701  jmp 0x00007DEBEE9FE110
00007debeebd0706  int3
00007debeebd0707  int3
00007debeebd0708  nop [rax+rax*1], eax
00007debeebd0710  mov rax, [r15+0xF8]
00007debeebd0717  mov [r15], rax
00007debeebd071a  mov rax, [r15+0x98]
00007debeebd0721  mov [r15+0x08], rax
00007debeebd0725  mov qword ptr [r15+0x10], 0x12C
00007debeebd072d  mov qword ptr [r15+0xF0], 0x410274
00007debeebd0738  mov r14d, [r15+0x320]
00007debeebd073f  mov eax, 0x410274
00007debeebd0744  mov rcx, 0x7DEBEEBD0670
00007debeebd074e  mov [r15+r14*8+0x328], rax
00007debeebd0756  mov [r15+r14*8+0x368], rcx
00007debeebd075e  add r14d, 0x01
00007debeebd0762  and r14d, 0x07
00007debeebd0766  mov [r15+0x320], r14d
00007debeebd076d  cmp dword ptr [r15+0x318], 0x00
00007debeebd0775  jz 0x00007DEBEEBCEC20
00007debeebd077b  nop [rax+rax*1], ax
00007debeebd0784  nop [rax+rax*1], eax
00007debeebd078c  mov eax, 0x410338
00007debeebd0791  mov [r15+0x100], rax
00007debeebd0798  jmp 0x00007DEBEE9FE110
00007debeebd079d  int3
00007debeebd079e  int3
00007debeebd079f  nop
00007debeebd07a0  mov rax, [r15+0xF8]
00007debeebd07a7  lea r14, [rax+0x20]
00007debeebd07ab  mov r12, [r13+r14*1]
00007debeebd07b0  mov [r15+0x98], r12
00007debeebd07b7  mov qword ptr [r15+0x40], 0x80
00007debeebd07bf  mov [r15], rax
00007debeebd07c2  lea r14, [rax+0x8C]
00007debeebd07c9  mov [r15+0x08], r14
00007debeebd07cd  mov qword ptr [r15+0x10], 0x01
00007debeebd07d5  lea r14, [rax+0x8C]
00007debeebd07dc  mov eax, 0x80
00007debeebd07e1  mov [r13+r14*1], al
00007debeebd07e6  mov qword ptr [r15+0xF0], 0x410298
00007debeebd07f1  mov r14d, [r15+0x320]
00007debeebd07f8  mov eax, 0x410298
00007debeebd07fd  mov rcx, 0x7DEBEEBD0870
00007debeebd0807  mov [r15+r14*8+0x328], rax
00007debeebd080f  mov [r15+r14*8+0x368], rcx
00007debeebd0817  add r14d, 0x01
00007debeebd081b  and r14d, 0x07
00007debeebd081f  mov [r15+0x320], r14d
00007debeebd0826  cmp dword ptr [r15+0x318], 0x00
00007debeebd082e  jz 0x00007DEBEEBCEC20
00007debeebd0834  nop [rax+rax*1], ax
00007debeebd083d  nop [rax+rax*1], eax
00007debeebd0845  mov eax, 0x410338
00007debeebd084a  mov [r15+0x100], rax
00007debeebd0851  jmp 0x00007DEBEE9FE110
00007debeebd0856  int3
00007debeebd0857  call 0x00007DEBEEAE27E0
00007debeebd085c  jmp 0x00007DEBEEBD07B0
00007debeebd0861  call 0x00007DEBEEAD5AF0
00007debeebd0866  jmp 0x00007DEBEEBD07E6
00007debeebd086b  int3
00007debeebd086c  nop [rax], eax
00007debeebd0870  mov rax, [r15+0xF8]
00007debeebd0877  lea r14, [rax+0x68]
00007debeebd087b  mov r12, [r13+r14*1]
00007debeebd0880  mov [r15+0x40], r12
00007debeebd0884  lea r14, [rax+0x88]
00007debeebd088b  xor eax, eax
00007debeebd088d  mov [r13+r14*1], al
00007debeebd0892  xor eax, eax
00007debeebd0894  mov r14d, 0x38
00007debeebd089a  cmp r12, r14
00007debeebd089d  cmc
00007debeebd089e  lahf
00007debeebd089f  seto al
00007debeebd08a2  mov [r15+0x108], eax
00007debeebd08a9  mov eax, [r15+0x108]
00007debeebd08b0  sahf
00007debeebd08b1  jz 0x00007DEBEEBD08E3
00007debeebd08b3  cmp dword ptr [r15+0x318], 0x00
00007debeebd08bb  jz 0x00007DEBEEBD0930
00007debeebd08c1  nop [rax+rax*1], ax
00007debeebd08ca  nop [rax+rax*1], eax
00007debeebd08d2  mov eax, 0x4102A8
00007debeebd08d7  mov [r15+0x100], rax
00007debeebd08de  jmp 0x00007DEBEE9FE110
00007debeebd08e3  cmp dword ptr [r15+0x318], 0x00
00007debeebd08eb  jz 0x00007DEBEEBD0A70
00007debeebd08f1  nop [rax+rax*1], ax
00007debeebd08fa  nop [rax+rax*1], eax
00007debeebd0902  mov eax, 0x4102C4
00007debeebd0907  mov [r15+0x100], rax
00007debeebd090e  jmp 0x00007DEBEE9FE110
00007debeebd0913  int3
00007debeebd0914  call 0x00007DEBEEAE27E0
00007debeebd0919  jmp 0x00007DEBEEBD0880
00007debeebd091e  call 0x00007DEBEEAD5AF0
00007debeebd0923  jmp 0x00007DEBEEBD0892
00007debeebd0928  int3
00007debeebd0929  nop [rax], eax
00007debeebd0930  mov rax, [r15+0xF8]
00007debeebd0937  mov [r15], rax
00007debeebd093a  lea r14, [rax+0x88]
00007debeebd0941  mov [r15+0x08], r14
00007debeebd0945  mov qword ptr [r15+0x10], 0x01
00007debeebd094d  mov qword ptr [r15+0xF0], 0x4102B8
00007debeebd0958  mov r14d, [r15+0x320]
00007debeebd095f  mov eax, 0x4102B8
00007debeebd0964  mov rcx, 0x7DEBEEBD09C0
00007debeebd096e  mov [r15+r14*8+0x328], rax
00007debeebd0976  mov [r15+r14*8+0x368], rcx
00007debeebd097e  add r14d, 0x01
00007debeebd0982  and r14d, 0x07
00007debeebd0986  mov [r15+0x320], r14d
00007debeebd098d  cmp dword ptr [r15+0x318], 0x00
00007debeebd0995  jz 0x00007DEBEEBCEC20
00007debeebd099b  nop [rax+rax*1], ax
00007debeebd09a4  nop [rax+rax*1], eax
00007debeebd09ac  mov eax, 0x410338
00007debeebd09b1  mov [r15+0x100], rax
00007debeebd09b8  jmp 0x00007DEBEE9FE110
00007debeebd09bd  int3
00007debeebd09be  int3
00007debeebd09bf  nop
00007debeebd09c0  mov rax, [r15+0xF8]
00007debeebd09c7  lea r14, [rax+0x68]
00007debeebd09cb  mov rax, [r13+r14*1]
00007debeebd09d0  mov [r15+0x40], rax
00007debeebd09d4  mov [rsp+0x10], rax
00007debeebd09d9  xor eax, eax
00007debeebd09db  mov r14, [rsp+0x10]
00007debeebd09e0  mov r12d, 0x38
00007debeebd09e6  cmp r14, r12
00007debeebd09e9  cmc
00007debeebd09ea  lahf
00007debeebd09eb  seto al
00007debeebd09ee  mov [r15+0x108], eax
00007debeebd09f5  mov eax, [r15+0x108]
00007debeebd09fc  sahf
00007debeebd09fd  jnz 0x00007DEBEEBD0A2F
00007debeebd09ff  cmp dword ptr [r15+0x318], 0x00
00007debeebd0a07  jz 0x00007DEBEEBD0A70
00007debeebd0a0d  nop [rax+rax*1], ax
00007debeebd0a16  nop [rax+rax*1], eax
00007debeebd0a1e  mov eax, 0x4102C4
00007debeebd0a23  mov [r15+0x100], rax
00007debeebd0a2a  jmp 0x00007DEBEE9FE110
00007debeebd0a2f  cmp dword ptr [r15+0x318], 0x00
00007debeebd0a37  jz 0x00007DEBEEBD0930
00007debeebd0a3d  nop [rax+rax*1], ax
00007debeebd0a46  nop [rax+rax*1], eax
00007debeebd0a4e  mov eax, 0x4102A8
00007debeebd0a53  mov [r15+0x100], rax
00007debeebd0a5a  jmp 0x00007DEBEE9FE110
00007debeebd0a5f  int3
00007debeebd0a60  call 0x00007DEBEEAD59C0
00007debeebd0a65  jmp 0x00007DEBEEBD09D0
00007debeebd0a6a  int3
00007debeebd0a6b  nop [rax+rax*1], eax
00007debeebd0a70  mov rax, [r15+0x98]
00007debeebd0a77  rorx r14, rax, 0x3D
00007debeebd0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007debeebd0a81  mov rax, [r15+0xF8]
00007debeebd0a88  mov [r15], rax
00007debeebd0a8b  lea r12, [rax+0x78]
00007debeebd0a8f  mov [r15+0x08], r12
00007debeebd0a93  mov qword ptr [r15+0x10], 0x08
00007debeebd0a9b  bswap r14
00007debeebd0a9e  mov [r15+0x40], r14
00007debeebd0aa2  lea r12, [rax+0x78]
00007debeebd0aa6  mov [r13+r12*1], r14
00007debeebd0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007debeebd0ab6  mov r14d, [r15+0x320]
00007debeebd0abd  mov eax, 0x4102E0
00007debeebd0ac2  mov rcx, 0x7DEBEEBD0B30
00007debeebd0acc  mov [r15+r14*8+0x328], rax
00007debeebd0ad4  mov [r15+r14*8+0x368], rcx
00007debeebd0adc  add r14d, 0x01
00007debeebd0ae0  and r14d, 0x07
00007debeebd0ae4  mov [r15+0x320], r14d
00007debeebd0aeb  cmp dword ptr [r15+0x318], 0x00
00007debeebd0af3  jz 0x00007DEBEEBCEC20
00007debeebd0af9  nop [rax+rax*1], ax
00007debeebd0b02  nop [rax+rax*1], eax
00007debeebd0b0a  mov eax, 0x410338
00007debeebd0b0f  mov [r15+0x100], rax
00007debeebd0b16  jmp 0x00007DEBEE9FE110
00007debeebd0b1b  int3
00007debeebd0b1c  call 0x00007DEBEEAC3FE0
00007debeebd0b21  jmp 0x00007DEBEEBD0AAB
00007debeebd0b26  int3
00007debeebd0b27  nop [rax+rax*1], ax
00007debeebd0b30  mov rax, [r15+0xF8]
00007debeebd0b37  mov r14d, [r13+rax*1]
00007debeebd0b3c  lea r12, [rax+0x04]
00007debeebd0b40  mov r11d, [r13+r12*1]
00007debeebd0b45  lea r12, [rax+0x08]
00007debeebd0b49  mov r10d, [r13+r12*1]
00007debeebd0b4e  lea r12, [rax+0x0C]
00007debeebd0b52  mov r9d, [r13+r12*1]
00007debeebd0b57  mov qword ptr [r15+0x48], 0x430860
00007debeebd0b5f  lea r12, [rax+0x80]
00007debeebd0b66  mov r8, [r13+r12*1]
00007debeebd0b6b  mov [r15+0xF0], r8
00007debeebd0b72  bswap r14d
00007debeebd0b75  bswap r11d
00007debeebd0b78  mov r12d, 0x430860
00007debeebd0b7e  mov [r13+r12*1], r14d
00007debeebd0b83  mov r14d, 0x430864
00007debeebd0b89  mov [r13+r14*1], r11d
00007debeebd0b8e  bswap r10d
00007debeebd0b91  bswap r9d
00007debeebd0b94  lea r14, [rax+0x10]
00007debeebd0b98  mov r12d, [r13+r14*1]
00007debeebd0b9d  lea r14, [rax+0x14]
00007debeebd0ba1  mov r11d, [r13+r14*1]
00007debeebd0ba6  mov r14d, 0x430868
00007debeebd0bac  mov [r13+r14*1], r10d
00007debeebd0bb1  mov r14d, 0x43086C
00007debeebd0bb7  mov [r13+r14*1], r9d
00007debeebd0bbc  lea r14, [rax+0x90]
00007debeebd0bc3  mov r10, [r13+r14*1]
00007debeebd0bc8  lea r14, [rax+0x98]
00007debeebd0bcf  mov r9, [r13+r14*1]
00007debeebd0bd4  mov [r15+0xA0], r10
00007debeebd0bdb  mov [r15+0x98], r9
00007debeebd0be2  bswap r12d
00007debeebd0be5  bswap r11d
00007debeebd0be8  mov [rsp+0x10], r11d
00007debeebd0bed  mov r11d, r11d
00007debeebd0bf0  mov [r15+0x58], r11
00007debeebd0bf4  lea r14, [rax+0x18]
00007debeebd0bf8  mov r11d, [r13+r14*1]
00007debeebd0bfd  lea r14, [rax+0x1C]
00007debeebd0c01  mov r10d, [r13+r14*1]
00007debeebd0c06  mov [rsp+0x20], r10d
00007debeebd0c0b  mov r10d, r10d
00007debeebd0c0e  mov [r15+0x60], r10
00007debeebd0c12  mov r14d, 0x430870
00007debeebd0c18  mov [r13+r14*1], r12d
00007debeebd0c1d  mov r14d, 0x430874
00007debeebd0c23  mov r12d, [rsp+0x10]
00007debeebd0c28  mov [r13+r14*1], r12d
00007debeebd0c2d  bswap r11d
00007debeebd0c30  mov [rsp+0x10], r11d
00007debeebd0c35  mov r11d, r11d
00007debeebd0c38  mov [r15+0x40], r11
00007debeebd0c3c  mov r14d, [rsp+0x20]
00007debeebd0c41  bswap r14d
00007debeebd0c44  mov [rsp+0x20], r14d
00007debeebd0c49  mov r14d, r14d
00007debeebd0c4c  mov [r15+0x50], r14
00007debeebd0c50  mov r14d, 0x430878
00007debeebd0c56  mov r12d, [rsp+0x10]
00007debeebd0c5b  mov [r13+r14*1], r12d
00007debeebd0c60  mov r14d, 0x43087C
00007debeebd0c66  mov r12d, [rsp+0x20]
00007debeebd0c6b  mov [r13+r14*1], r12d
00007debeebd0c70  lea r14, [rax+0xA0]
00007debeebd0c77  mov [r15+0xF8], r14
00007debeebd0c7e  mov [r15+0x100], r8
00007debeebd0c85  jmp 0x00007DEBEEBCE5C0
00007debeebd0c8a  int3
00007debeebd0c8b  call 0x00007DEBEEA0DAE0
00007debeebd0c90  jmp 0x00007DEBEEBD0B3C
00007debeebd0c95  call 0x00007DEBEEAC0230
00007debeebd0c9a  jmp 0x00007DEBEEBD0B45
00007debeebd0c9f  call 0x00007DEBEEABEFC0
00007debeebd0ca4  jmp 0x00007DEBEEBD0B4E
00007debeebd0ca9  call 0x00007DEBEEABDD50
00007debeebd0cae  jmp 0x00007DEBEEBD0B57
00007debeebd0cb3  call 0x00007DEBEEABCC20
00007debeebd0cb8  jmp 0x00007DEBEEBD0B6B
00007debeebd0cbd  call 0x00007DEBEEAC3EA0
00007debeebd0cc2  jmp 0x00007DEBEEBD0B83
00007debeebd0cc7  call 0x00007DEBEEAE1920
00007debeebd0ccc  jmp 0x00007DEBEEBD0B8E
00007debeebd0cd1  call 0x00007DEBEEAE26A0
00007debeebd0cd6  jmp 0x00007DEBEEBD0B9D
00007debeebd0cdb  call 0x00007DEBEEAE1430
00007debeebd0ce0  jmp 0x00007DEBEEBD0BA6
00007debeebd0ce5  call 0x00007DEBEEAE06B0
00007debeebd0cea  jmp 0x00007DEBEEBD0BB1
00007debeebd0cef  call 0x00007DEBEEADF440
00007debeebd0cf4  jmp 0x00007DEBEEBD0BBC
00007debeebd0cf9  call 0x00007DEBEEAE0300
00007debeebd0cfe  jmp 0x00007DEBEEBD0BC8
00007debeebd0d03  call 0x00007DEBEEADF090
00007debeebd0d08  jmp 0x00007DEBEEBD0BD4
00007debeebd0d0d  call 0x00007DEBEEAE1430
00007debeebd0d12  jmp 0x00007DEBEEBD0BFD
00007debeebd0d17  call 0x00007DEBEEAE01C0
00007debeebd0d1c  jmp 0x00007DEBEEBD0C06
00007debeebd0d21  call 0x00007DEBEEAE2BA0
00007debeebd0d26  jmp 0x00007DEBEEBD0C1D
00007debeebd0d2b  call 0x00007DEBEEAE2BA0
00007debeebd0d30  jmp 0x00007DEBEEBD0C2D
00007debeebd0d35  call 0x00007DEBEEAE2BA0
00007debeebd0d3a  jmp 0x00007DEBEEBD0C60
00007debeebd0d3f  call 0x00007DEBEEAE2BA0
00007debeebd0d44  jmp 0x00007DEBEEBD0C70
00007debeebd0d49  int3
00007debeebd0d4a  nop [rax+rax*1], ax
00007debeebd0d50  mov qword ptr [r15+0x100], 0x04
00007debeebd0d5b  mov esi, 0x00
00007debeebd0d60  mov edx, 0x09
00007debeebd0d65  mov rdi, 0x7FFE256D44B0
00007debeebd0d6f  mov rax, 0x63C8FFD19970
00007debeebd0d79  call rax
00007debeebd0d7b  cmp dword ptr [r15+0x318], 0x00
00007debeebd0d83  jnz 0x00007DEBEE9FE110
00007debeebd0d89  jmp 0x00007DEBEE9FE0A0
00007debeebd0d8e  int3
00007debeebd0d8f  int3
