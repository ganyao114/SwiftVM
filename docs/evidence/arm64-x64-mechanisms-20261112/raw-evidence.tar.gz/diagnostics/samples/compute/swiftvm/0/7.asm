
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/0/7.bin:     file format binary


Disassembly of section .data:

00007c33ec902390 <.data>:
    7c33ec902390:	sub    rsp,0x10
    7c33ec902394:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90239c:	mov    QWORD PTR [rsp],r11
    7c33ec9023a0:	mov    r13,QWORD PTR [r12+0xa0]
    7c33ec9023a8:	mov    r14,r13
    7c33ec9023ab:	shl    r14,0x2
    7c33ec9023af:	mov    r15,QWORD PTR [r12+0x98]
    7c33ec9023b7:	mov    rcx,r14
    7c33ec9023ba:	add    r15,rcx
    7c33ec9023bd:	mov    r14d,DWORD PTR [r12]
    7c33ec9023c1:	mov    DWORD PTR [r15],r14d
    7c33ec9023c4:	mov    r14d,0x0
    7c33ec9023ca:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec9023d2:	add    r13,0x1
    7c33ec9023d6:	mov    QWORD PTR [r12+0xa0],r13
    7c33ec9023de:	sub    r13,0x400
    7c33ec9023e5:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec9023ed:	jrcxz  0x7c33ec9023f4
    7c33ec9023ef:	jmp    0x7c33ec9027e5
    7c33ec9023f4:	pushf
    7c33ec9023f5:	pop    r11
    7c33ec9023f7:	mov    QWORD PTR [rsp],r11
    7c33ec9023fb:	jne    0x7c33ec902775
    7c33ec902401:	jmp    0x7c33ec902406
    7c33ec902406:	mov    r13d,0x1
    7c33ec90240c:	mov    QWORD PTR [r12+0x40],r13
    7c33ec902411:	jmp    0x7c33ec902416
    7c33ec902416:	mov    r13,QWORD PTR [r12+0x40]
    7c33ec90241b:	mov    r14,r13
    7c33ec90241e:	shl    r14,0x2
    7c33ec902422:	mov    r15,QWORD PTR [r12+0x98]
    7c33ec90242a:	mov    rcx,r14
    7c33ec90242d:	add    r15,rcx
    7c33ec902430:	mov    r14d,DWORD PTR [r15]
    7c33ec902433:	mov    QWORD PTR [r12+0x48],r14
    7c33ec902438:	mov    r14d,0x0
    7c33ec90243e:	mov    rcx,r13
    7c33ec902441:	or     r14,rcx
    7c33ec902444:	mov    QWORD PTR [r12+0x50],r14
    7c33ec902449:	jmp    0x7c33ec90244e
    7c33ec90244e:	mov    r13d,DWORD PTR [r12+0x50]
    7c33ec902453:	sub    r13d,0x1
    7c33ec902457:	mov    QWORD PTR [r12+0x58],r13
    7c33ec90245c:	mov    ecx,0xffffffff
    7c33ec902461:	mov    r14,r13
    7c33ec902464:	and    r14,rcx
    7c33ec902467:	shl    r14,0x2
    7c33ec90246b:	mov    r13,QWORD PTR [r12+0x98]
    7c33ec902473:	mov    rcx,r14
    7c33ec902476:	add    r13,rcx
    7c33ec902479:	mov    r14d,DWORD PTR [r13+0x0]
    7c33ec90247d:	mov    QWORD PTR [r12+0x60],r14
    7c33ec902482:	mov    r13d,DWORD PTR [r12+0x48]
    7c33ec902487:	mov    ecx,r13d
    7c33ec90248a:	sub    r14d,ecx
    7c33ec90248d:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec902495:	jrcxz  0x7c33ec90249c
    7c33ec902497:	jmp    0x7c33ec902874
    7c33ec90249c:	sete   al
    7c33ec90249f:	movzx  eax,al
    7c33ec9024a2:	mov    r13,rax
    7c33ec9024a5:	setb   al
    7c33ec9024a8:	movzx  eax,al
    7c33ec9024ab:	mov    r14,rax
    7c33ec9024ae:	pushf
    7c33ec9024af:	pop    r11
    7c33ec9024b1:	mov    QWORD PTR [rsp],r11
    7c33ec9024b5:	mov    rcx,r13
    7c33ec9024b8:	and    ecx,0xff
    7c33ec9024be:	mov    r15,r14
    7c33ec9024c1:	and    r15d,0xff
    7c33ec9024c8:	or     r15,rcx
    7c33ec9024cb:	and    r15d,0xff
    7c33ec9024d2:	mov    rax,r15
    7c33ec9024d5:	and    eax,0xff
    7c33ec9024da:	test   rax,rax
    7c33ec9024dd:	jne    0x7c33ec90257f
    7c33ec9024e3:	jmp    0x7c33ec9024e8
    7c33ec9024e8:	mov    r13,QWORD PTR [r12+0x50]
    7c33ec9024ed:	mov    r14,r13
    7c33ec9024f0:	shl    r14,0x2
    7c33ec9024f4:	mov    r15,QWORD PTR [r12+0x98]
    7c33ec9024fc:	mov    rcx,r14
    7c33ec9024ff:	add    r15,rcx
    7c33ec902502:	mov    r14d,DWORD PTR [r12+0x60]
    7c33ec902507:	mov    DWORD PTR [r15],r14d
    7c33ec90250a:	mov    r14d,0x0
    7c33ec902510:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec902518:	sub    r13,0x1
    7c33ec90251c:	mov    QWORD PTR [r12+0x50],r13
    7c33ec902521:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec902529:	jrcxz  0x7c33ec902530
    7c33ec90252b:	jmp    0x7c33ec902903
    7c33ec902530:	mov    r13,QWORD PTR [r12+0x58]
    7c33ec902535:	mov    rax,r13
    7c33ec902538:	test   rax,rax
    7c33ec90253b:	setne  al
    7c33ec90253e:	movzx  eax,al
    7c33ec902541:	and    eax,0x1
    7c33ec902544:	mov    r14,rax
    7c33ec902547:	mov    rax,r14
    7c33ec90254a:	and    eax,0x1
    7c33ec90254d:	test   rax,rax
    7c33ec902550:	jne    0x7c33ec90244e
    7c33ec902556:	jmp    0x7c33ec90255b
    7c33ec90255b:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec902563:	jrcxz  0x7c33ec90256a
    7c33ec902565:	jmp    0x7c33ec90298a
    7c33ec90256a:	jmp    0x7c33ec90256f
    7c33ec90256f:	mov    r13d,0x0
    7c33ec902575:	mov    QWORD PTR [r12+0x50],r13
    7c33ec90257a:	jmp    0x7c33ec90257f
    7c33ec90257f:	mov    r13,QWORD PTR [r12+0x40]
    7c33ec902584:	add    r13,0x1
    7c33ec902588:	mov    QWORD PTR [r12+0x40],r13
    7c33ec90258d:	mov    r14,QWORD PTR [r12+0x50]
    7c33ec902592:	mov    ecx,0xffffffff
    7c33ec902597:	and    r14,rcx
    7c33ec90259a:	shl    r14,0x2
    7c33ec90259e:	mov    r15,QWORD PTR [r12+0x98]
    7c33ec9025a6:	mov    rcx,r14
    7c33ec9025a9:	add    r15,rcx
    7c33ec9025ac:	mov    r14d,DWORD PTR [r12+0x48]
    7c33ec9025b1:	mov    DWORD PTR [r15],r14d
    7c33ec9025b4:	mov    r14d,0x0
    7c33ec9025ba:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec9025c2:	sub    r13,0x400
    7c33ec9025c9:	pushf
    7c33ec9025ca:	pop    r11
    7c33ec9025cc:	mov    QWORD PTR [rsp],r11
    7c33ec9025d0:	je     0x7c33ec9025db
    7c33ec9025d6:	jmp    0x7c33ec902416
    7c33ec9025db:	mov    r13d,0x430000
    7c33ec9025e1:	mov    QWORD PTR [r12+0x40],r13
    7c33ec9025e6:	mov    r13d,0x0
    7c33ec9025ec:	mov    QWORD PTR [r12+0x58],r13
    7c33ec9025f1:	mov    r13d,0x0
    7c33ec9025f7:	mov    QWORD PTR [r12+0x50],r13
    7c33ec9025fc:	mov    r13d,0x430cb0
    7c33ec902602:	mov    r14,QWORD PTR [r13+0x0]
    7c33ec902606:	mov    QWORD PTR [r12+0x48],r14
    7c33ec90260b:	jmp    0x7c33ec902610
    7c33ec902610:	mov    r13,QWORD PTR [r12+0x58]
    7c33ec902615:	mov    r14,r13
    7c33ec902618:	shl    r14,0x2
    7c33ec90261c:	mov    r15,QWORD PTR [r12+0x98]
    7c33ec902624:	mov    rcx,r14
    7c33ec902627:	add    r15,rcx
    7c33ec90262a:	mov    QWORD PTR [r12+0x60],r15
    7c33ec90262f:	mov    r14,r15
    7c33ec902632:	add    r14,0x4
    7c33ec902636:	mov    ebp,DWORD PTR [r15]
    7c33ec902639:	mov    r15d,DWORD PTR [r14]
    7c33ec90263c:	mov    QWORD PTR [r12+0x60],r15
    7c33ec902641:	mov    rax,rbp
    7c33ec902644:	mov    rcx,r13
    7c33ec902647:	imul   rax,rcx
    7c33ec90264b:	mov    r14,rax
    7c33ec90264e:	mov    rcx,r14
    7c33ec902651:	mov    r8,rbp
    7c33ec902654:	add    r8,rcx
    7c33ec902657:	mov    QWORD PTR [r12+0x68],r8
    7c33ec90265c:	add    r13,0x2
    7c33ec902660:	mov    QWORD PTR [r12+0x58],r13
    7c33ec902665:	mov    r14,r13
    7c33ec902668:	sub    r14,0x400
    7c33ec90266f:	mov    r14,QWORD PTR [r12+0x50]
    7c33ec902674:	pushf
    7c33ec902675:	pop    r11
    7c33ec902677:	mov    QWORD PTR [rsp],r11
    7c33ec90267b:	mov    rax,r13
    7c33ec90267e:	mov    rcx,r15
    7c33ec902681:	imul   rax,rcx
    7c33ec902685:	mov    rbp,rax
    7c33ec902688:	mov    rcx,rbp
    7c33ec90268b:	add    r14,rcx
    7c33ec90268e:	mov    QWORD PTR [r12+0x50],r14
    7c33ec902693:	mov    r13,QWORD PTR [r12+0x48]
    7c33ec902698:	mov    rcx,r13
    7c33ec90269b:	add    r8,rcx
    7c33ec90269e:	mov    QWORD PTR [r12+0x48],r8
    7c33ec9026a3:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec9026ab:	jrcxz  0x7c33ec9026b2
    7c33ec9026ad:	jmp    0x7c33ec902a11
    7c33ec9026b2:	push   QWORD PTR [rsp]
    7c33ec9026b5:	popf
    7c33ec9026b6:	jne    0x7c33ec902610
    7c33ec9026bc:	jmp    0x7c33ec9026c1
    7c33ec9026c1:	mov    r13d,0x0
    7c33ec9026c7:	mov    QWORD PTR [r12+0x98],r13
    7c33ec9026cf:	mov    r13,QWORD PTR [r12+0x48]
    7c33ec9026d4:	mov    r14,QWORD PTR [r12+0x50]
    7c33ec9026d9:	mov    rcx,r13
    7c33ec9026dc:	add    r14,rcx
    7c33ec9026df:	mov    QWORD PTR [r12+0x48],r14
    7c33ec9026e4:	mov    r13d,0x1
    7c33ec9026ea:	mov    QWORD PTR [r12],r13
    7c33ec9026ee:	mov    r13,QWORD PTR [r12+0x40]
    7c33ec9026f3:	add    r13,0xcb0
    7c33ec9026fa:	mov    QWORD PTR [r13+0x0],r14
    7c33ec9026fe:	mov    r13d,0x0
    7c33ec902704:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec90270c:	mov    r13d,0x1
    7c33ec902712:	mov    QWORD PTR [r12],r13
    7c33ec902716:	mov    r13d,0x4103f8
    7c33ec90271c:	mov    QWORD PTR [r12+0xf0],r13
    7c33ec902724:	mov    r13d,0x4109a4
    7c33ec90272a:	mov    QWORD PTR [r12+0x100],r13
    7c33ec902732:	mov    r11,QWORD PTR [rsp]
    7c33ec902736:	mov    QWORD PTR [r12+0x398],r11
    7c33ec90273e:	mov    edi,0x4109a4
    7c33ec902743:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec90274b:	add    rsp,0x10
    7c33ec90274f:	nop
    7c33ec902750:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec902758
    7c33ec902756:	xchg   ax,ax
    7c33ec902758:	nop
    7c33ec902759:	and    DWORD PTR [rax+0x7c33ec],edx
    7c33ec90275f:	add    BYTE PTR [rax+0x27],ch
    7c33ec902762:	nop
    7c33ec902763:	in     al,dx
    7c33ec902764:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec902768:	movabs r11,0x5585303950a0
    7c33ec902772:	jmp    r11
    7c33ec902775:	mov    r13d,DWORD PTR [r12+0xa0]
    7c33ec90277d:	add    r13d,0x11
    7c33ec902781:	mov    QWORD PTR [r12],r13
    7c33ec902785:	mov    r13d,0x41035c
    7c33ec90278b:	mov    QWORD PTR [r12+0xf0],r13
    7c33ec902793:	mov    r13d,0x4109a4
    7c33ec902799:	mov    QWORD PTR [r12+0x100],r13
    7c33ec9027a1:	mov    r11,QWORD PTR [rsp]
    7c33ec9027a5:	mov    QWORD PTR [r12+0x398],r11
    7c33ec9027ad:	mov    edi,0x4109a4
    7c33ec9027b2:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec9027ba:	add    rsp,0x10
    7c33ec9027be:	xchg   ax,ax
    7c33ec9027c0:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec9027c8
    7c33ec9027c6:	xchg   ax,ax
    7c33ec9027c8:	nop
    7c33ec9027c9:	and    DWORD PTR [rax+0x7c33ec],edx
    7c33ec9027cf:	add    al,bl
    7c33ec9027d1:	(bad)
    7c33ec9027d2:	nop
    7c33ec9027d3:	in     al,dx
    7c33ec9027d4:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec9027d8:	movabs r11,0x5585303950a0
    7c33ec9027e2:	jmp    r11
    7c33ec9027e5:	mov    eax,0x410368
    7c33ec9027ea:	mov    QWORD PTR [r12+0x100],rax
    7c33ec9027f2:	push   rdx
    7c33ec9027f3:	push   rsi
    7c33ec9027f4:	push   r10
    7c33ec9027f6:	push   r11
    7c33ec9027f8:	pushf
    7c33ec9027f9:	pop    r11
    7c33ec9027fb:	mov    QWORD PTR [rsp+0x20],r11
    7c33ec902800:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec902805:	mov    r10d,edx
    7c33ec902808:	and    r10d,0xc0
    7c33ec90280f:	shl    r10d,0x18
    7c33ec902813:	mov    r11d,edx
    7c33ec902816:	and    r11d,0x1
    7c33ec90281a:	shl    r11d,0x1d
    7c33ec90281e:	or     r10d,r11d
    7c33ec902821:	mov    r11d,edx
    7c33ec902824:	and    r11d,0x800
    7c33ec90282b:	shl    r11d,0x11
    7c33ec90282f:	or     r10d,r11d
    7c33ec902832:	btc    r10,0x1d
    7c33ec902837:	mov    r11d,0xf0000000
    7c33ec90283d:	and    r11,r10
    7c33ec902840:	movabs rsi,0xffffffff0fffffff
    7c33ec90284a:	and    rbx,rsi
    7c33ec90284d:	or     rbx,r11
    7c33ec902850:	pop    r11
    7c33ec902852:	pop    r10
    7c33ec902854:	pop    rsi
    7c33ec902855:	pop    rdx
    7c33ec902856:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90285e:	add    rsp,0x10
    7c33ec902862:	mov    eax,0xc
    7c33ec902867:	movabs r11,0x558530395390
    7c33ec902871:	jmp    r11
    7c33ec902874:	mov    eax,0x41039c
    7c33ec902879:	mov    QWORD PTR [r12+0x100],rax
    7c33ec902881:	push   rdx
    7c33ec902882:	push   rsi
    7c33ec902883:	push   r10
    7c33ec902885:	push   r11
    7c33ec902887:	pushf
    7c33ec902888:	pop    r11
    7c33ec90288a:	mov    QWORD PTR [rsp+0x20],r11
    7c33ec90288f:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec902894:	mov    r10d,edx
    7c33ec902897:	and    r10d,0xc0
    7c33ec90289e:	shl    r10d,0x18
    7c33ec9028a2:	mov    r11d,edx
    7c33ec9028a5:	and    r11d,0x1
    7c33ec9028a9:	shl    r11d,0x1d
    7c33ec9028ad:	or     r10d,r11d
    7c33ec9028b0:	mov    r11d,edx
    7c33ec9028b3:	and    r11d,0x800
    7c33ec9028ba:	shl    r11d,0x11
    7c33ec9028be:	or     r10d,r11d
    7c33ec9028c1:	btc    r10,0x1d
    7c33ec9028c6:	mov    r11d,0xf0000000
    7c33ec9028cc:	and    r11,r10
    7c33ec9028cf:	movabs rsi,0xffffffff0fffffff
    7c33ec9028d9:	and    rbx,rsi
    7c33ec9028dc:	or     rbx,r11
    7c33ec9028df:	pop    r11
    7c33ec9028e1:	pop    r10
    7c33ec9028e3:	pop    rsi
    7c33ec9028e4:	pop    rdx
    7c33ec9028e5:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec9028ed:	add    rsp,0x10
    7c33ec9028f1:	mov    eax,0xc
    7c33ec9028f6:	movabs r11,0x558530395390
    7c33ec902900:	jmp    r11
    7c33ec902903:	mov    eax,0x4103a8
    7c33ec902908:	mov    QWORD PTR [r12+0x100],rax
    7c33ec902910:	push   rdx
    7c33ec902911:	push   rsi
    7c33ec902912:	push   r10
    7c33ec902914:	push   r11
    7c33ec902916:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90291b:	mov    r10d,edx
    7c33ec90291e:	and    r10d,0xc0
    7c33ec902925:	shl    r10d,0x18
    7c33ec902929:	mov    r11d,edx
    7c33ec90292c:	and    r11d,0x1
    7c33ec902930:	shl    r11d,0x1d
    7c33ec902934:	or     r10d,r11d
    7c33ec902937:	mov    r11d,edx
    7c33ec90293a:	and    r11d,0x800
    7c33ec902941:	shl    r11d,0x11
    7c33ec902945:	or     r10d,r11d
    7c33ec902948:	btc    r10,0x1d
    7c33ec90294d:	mov    r11d,0xf0000000
    7c33ec902953:	and    r11,r10
    7c33ec902956:	movabs rsi,0xffffffff0fffffff
    7c33ec902960:	and    rbx,rsi
    7c33ec902963:	or     rbx,r11
    7c33ec902966:	pop    r11
    7c33ec902968:	pop    r10
    7c33ec90296a:	pop    rsi
    7c33ec90296b:	pop    rdx
    7c33ec90296c:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec902974:	add    rsp,0x10
    7c33ec902978:	mov    eax,0xc
    7c33ec90297d:	movabs r11,0x558530395390
    7c33ec902987:	jmp    r11
    7c33ec90298a:	mov    eax,0x4103ac
    7c33ec90298f:	mov    QWORD PTR [r12+0x100],rax
    7c33ec902997:	push   rdx
    7c33ec902998:	push   rsi
    7c33ec902999:	push   r10
    7c33ec90299b:	push   r11
    7c33ec90299d:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec9029a2:	mov    r10d,edx
    7c33ec9029a5:	and    r10d,0xc0
    7c33ec9029ac:	shl    r10d,0x18
    7c33ec9029b0:	mov    r11d,edx
    7c33ec9029b3:	and    r11d,0x1
    7c33ec9029b7:	shl    r11d,0x1d
    7c33ec9029bb:	or     r10d,r11d
    7c33ec9029be:	mov    r11d,edx
    7c33ec9029c1:	and    r11d,0x800
    7c33ec9029c8:	shl    r11d,0x11
    7c33ec9029cc:	or     r10d,r11d
    7c33ec9029cf:	btc    r10,0x1d
    7c33ec9029d4:	mov    r11d,0xf0000000
    7c33ec9029da:	and    r11,r10
    7c33ec9029dd:	movabs rsi,0xffffffff0fffffff
    7c33ec9029e7:	and    rbx,rsi
    7c33ec9029ea:	or     rbx,r11
    7c33ec9029ed:	pop    r11
    7c33ec9029ef:	pop    r10
    7c33ec9029f1:	pop    rsi
    7c33ec9029f2:	pop    rdx
    7c33ec9029f3:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec9029fb:	add    rsp,0x10
    7c33ec9029ff:	mov    eax,0xc
    7c33ec902a04:	movabs r11,0x558530395390
    7c33ec902a0e:	jmp    r11
    7c33ec902a11:	mov    eax,0x4103dc
    7c33ec902a16:	mov    QWORD PTR [r12+0x100],rax
    7c33ec902a1e:	push   rdx
    7c33ec902a1f:	push   rsi
    7c33ec902a20:	push   r10
    7c33ec902a22:	push   r11
    7c33ec902a24:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec902a29:	mov    r10d,edx
    7c33ec902a2c:	and    r10d,0xc0
    7c33ec902a33:	shl    r10d,0x18
    7c33ec902a37:	mov    r11d,edx
    7c33ec902a3a:	and    r11d,0x1
    7c33ec902a3e:	shl    r11d,0x1d
    7c33ec902a42:	or     r10d,r11d
    7c33ec902a45:	mov    r11d,edx
    7c33ec902a48:	and    r11d,0x800
    7c33ec902a4f:	shl    r11d,0x11
    7c33ec902a53:	or     r10d,r11d
    7c33ec902a56:	btc    r10,0x1d
    7c33ec902a5b:	mov    r11d,0xf0000000
    7c33ec902a61:	and    r11,r10
    7c33ec902a64:	movabs rsi,0xffffffff0fffffff
    7c33ec902a6e:	and    rbx,rsi
    7c33ec902a71:	or     rbx,r11
    7c33ec902a74:	pop    r11
    7c33ec902a76:	pop    r10
    7c33ec902a78:	pop    rsi
    7c33ec902a79:	pop    rdx
    7c33ec902a7a:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec902a82:	add    rsp,0x10
    7c33ec902a86:	mov    eax,0xc
    7c33ec902a8b:	movabs r11,0x558530395390
    7c33ec902a95:	jmp    r11
    7c33ec902a98:	nop    DWORD PTR [rax+rax*1+0x0]
    7c33ec902aa0:	sub    rsp,0x10
    7c33ec902aa4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902aac:	mov    QWORD PTR [rsp],r11
    7c33ec902ab0:	jmp    0x7c33ec902406
    7c33ec902ab5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902ac0:	sub    rsp,0x10
    7c33ec902ac4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902acc:	mov    QWORD PTR [rsp],r11
    7c33ec902ad0:	jmp    0x7c33ec902416
    7c33ec902ad5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902ae0:	sub    rsp,0x10
    7c33ec902ae4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902aec:	mov    QWORD PTR [rsp],r11
    7c33ec902af0:	jmp    0x7c33ec90244e
    7c33ec902af5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902b00:	sub    rsp,0x10
    7c33ec902b04:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902b0c:	mov    QWORD PTR [rsp],r11
    7c33ec902b10:	jmp    0x7c33ec9024e8
    7c33ec902b15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902b20:	sub    rsp,0x10
    7c33ec902b24:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902b2c:	mov    QWORD PTR [rsp],r11
    7c33ec902b30:	jmp    0x7c33ec90255b
    7c33ec902b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902b40:	sub    rsp,0x10
    7c33ec902b44:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902b4c:	mov    QWORD PTR [rsp],r11
    7c33ec902b50:	jmp    0x7c33ec90256f
    7c33ec902b55:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902b60:	sub    rsp,0x10
    7c33ec902b64:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902b6c:	mov    QWORD PTR [rsp],r11
    7c33ec902b70:	jmp    0x7c33ec90257f
    7c33ec902b75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902b80:	sub    rsp,0x10
    7c33ec902b84:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902b8c:	mov    QWORD PTR [rsp],r11
    7c33ec902b90:	jmp    0x7c33ec9025db
    7c33ec902b95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902ba0:	sub    rsp,0x10
    7c33ec902ba4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902bac:	mov    QWORD PTR [rsp],r11
    7c33ec902bb0:	jmp    0x7c33ec902610
    7c33ec902bb5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902bc0:	sub    rsp,0x10
    7c33ec902bc4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902bcc:	mov    QWORD PTR [rsp],r11
    7c33ec902bd0:	jmp    0x7c33ec9026c1
    7c33ec902bd5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec902be0:	sub    rsp,0x10
    7c33ec902be4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902bec:	mov    QWORD PTR [rsp],r11
    7c33ec902bf0:	jmp    0x7c33ec902775
    7c33ec902bf5:	nop
    7c33ec902bf6:	nop
    7c33ec902bf7:	nop
