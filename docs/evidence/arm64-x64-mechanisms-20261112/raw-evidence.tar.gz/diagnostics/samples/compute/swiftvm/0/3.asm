
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/0/3.bin:     file format binary


Disassembly of section .data:

00007c33ec9017f0 <.data>:
    7c33ec9017f0:	sub    rsp,0x10
    7c33ec9017f4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec9017fc:	mov    QWORD PTR [rsp],r11
    7c33ec901800:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec901808:	mov    r14,r13
    7c33ec90180b:	add    r14,0x168
    7c33ec901812:	mov    r15,QWORD PTR [r14]
    7c33ec901815:	mov    QWORD PTR [r12+0x40],r15
    7c33ec90181a:	add    r13,0x178
    7c33ec901821:	mov    r14d,0x0
    7c33ec901827:	mov    BYTE PTR [r13+0x0],r14b
    7c33ec90182b:	mov    r13d,0x0
    7c33ec901831:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec901839:	sub    r15,0x38
    7c33ec90183d:	pushf
    7c33ec90183e:	pop    r11
    7c33ec901840:	mov    QWORD PTR [rsp],r11
    7c33ec901844:	je     0x7c33ec9018dd
    7c33ec90184a:	jmp    0x7c33ec90184f
    7c33ec90184f:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec901857:	mov    r14,r13
    7c33ec90185a:	add    r14,0x100
    7c33ec901861:	mov    QWORD PTR [r12],r14
    7c33ec901865:	add    r13,0x178
    7c33ec90186c:	mov    QWORD PTR [r12+0x8],r13
    7c33ec901871:	mov    r13d,0x1
    7c33ec901877:	mov    QWORD PTR [r12+0x10],r13
    7c33ec90187c:	mov    r13d,0x4102c8
    7c33ec901882:	mov    QWORD PTR [r12+0xf0],r13
    7c33ec90188a:	mov    r13d,0x410728
    7c33ec901890:	mov    QWORD PTR [r12+0x100],r13
    7c33ec901898:	mov    r11,QWORD PTR [rsp]
    7c33ec90189c:	mov    QWORD PTR [r12+0x398],r11
    7c33ec9018a4:	mov    edi,0x410728
    7c33ec9018a9:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec9018b1:	add    rsp,0x10
    7c33ec9018b5:	nop    DWORD PTR [rax]
    7c33ec9018b8:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec9018c0
    7c33ec9018be:	xchg   ax,ax
    7c33ec9018c0:	(bad)
    7c33ec9018c1:	jmp    0x7c3468c40555
    7c33ec9018c6:	add    BYTE PTR [rax],al
    7c33ec9018c8:	rcr    BYTE PTR [rax],1
    7c33ec9018ca:	nop
    7c33ec9018cb:	in     al,dx
    7c33ec9018cc:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec9018d0:	movabs r11,0x5585303950a0
    7c33ec9018da:	jmp    r11
    7c33ec9018dd:	mov    r13,QWORD PTR [r12+0x98]
    7c33ec9018e5:	ror    r13,0x3d
    7c33ec9018e9:	and    r13,0xfffffffffffffff8
    7c33ec9018ed:	mov    r14,QWORD PTR [r12+0xf8]
    7c33ec9018f5:	mov    r15,r14
    7c33ec9018f8:	add    r15,0x100
    7c33ec9018ff:	mov    QWORD PTR [r12],r15
    7c33ec901903:	mov    r15,r14
    7c33ec901906:	add    r15,0x170
    7c33ec90190d:	mov    QWORD PTR [r12+0x8],r15
    7c33ec901912:	mov    r15d,0x8
    7c33ec901918:	mov    QWORD PTR [r12+0x10],r15
    7c33ec90191d:	movabs rcx,0xff00ff00ff00ff
    7c33ec901927:	mov    r15,r13
    7c33ec90192a:	and    r15,rcx
    7c33ec90192d:	shl    r15,0x8
    7c33ec901931:	movabs rcx,0xff00ff00ff00ff00
    7c33ec90193b:	and    r13,rcx
    7c33ec90193e:	shr    r13,0x8
    7c33ec901942:	mov    rcx,r15
    7c33ec901945:	or     r13,rcx
    7c33ec901948:	movabs rcx,0xffff0000ffff
    7c33ec901952:	mov    r15,r13
    7c33ec901955:	and    r15,rcx
    7c33ec901958:	shl    r15,0x10
    7c33ec90195c:	movabs rcx,0xffff0000ffff0000
    7c33ec901966:	and    r13,rcx
    7c33ec901969:	shr    r13,0x10
    7c33ec90196d:	mov    rcx,r15
    7c33ec901970:	or     r13,rcx
    7c33ec901973:	mov    r15,r13
    7c33ec901976:	shl    r15,0x20
    7c33ec90197a:	shr    r13,0x20
    7c33ec90197e:	mov    rcx,r15
    7c33ec901981:	or     r13,rcx
    7c33ec901984:	mov    QWORD PTR [r12+0x40],r13
    7c33ec901989:	add    r14,0x170
    7c33ec901990:	mov    QWORD PTR [r14],r13
    7c33ec901993:	mov    r13d,0x0
    7c33ec901999:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9019a1:	mov    r13d,0x4102f0
    7c33ec9019a7:	mov    QWORD PTR [r12+0xf0],r13
    7c33ec9019af:	mov    r13d,0x410728
    7c33ec9019b5:	mov    QWORD PTR [r12+0x100],r13
    7c33ec9019bd:	mov    r11,QWORD PTR [rsp]
    7c33ec9019c1:	mov    QWORD PTR [r12+0x398],r11
    7c33ec9019c9:	mov    edi,0x410728
    7c33ec9019ce:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec9019d6:	add    rsp,0x10
    7c33ec9019da:	nop    WORD PTR [rax+rax*1+0x0]
    7c33ec9019e0:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec9019e8
    7c33ec9019e6:	xchg   ax,ax
    7c33ec9019e8:	(bad)
    7c33ec9019e9:	jmp    0x7c3468c4067d
    7c33ec9019ee:	add    BYTE PTR [rax],al
    7c33ec9019f0:	clc
    7c33ec9019f1:	sbb    DWORD PTR [rax+0x7c33ec],edx
    7c33ec9019f7:	add    BYTE PTR [rcx-0x45],cl
    7c33ec9019fa:	movabs al,ds:0x4100005585303950
    7c33ec901a03:	jmp    rbx
    7c33ec901a05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec901a10:	sub    rsp,0x10
    7c33ec901a14:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec901a1c:	mov    QWORD PTR [rsp],r11
    7c33ec901a20:	jmp    0x7c33ec90184f
    7c33ec901a25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec901a30:	sub    rsp,0x10
    7c33ec901a34:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec901a3c:	mov    QWORD PTR [rsp],r11
    7c33ec901a40:	jmp    0x7c33ec9018dd
    7c33ec901a45:	nop
    7c33ec901a46:	nop
    7c33ec901a47:	nop
