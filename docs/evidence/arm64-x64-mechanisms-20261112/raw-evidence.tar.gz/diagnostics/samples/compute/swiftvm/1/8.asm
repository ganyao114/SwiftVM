
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/1/8.bin:     file format binary


Disassembly of section .data:

0000707120f02c00 <.data>:
    707120f02c00:	sub    rsp,0x150
    707120f02c07:	mov    r11,QWORD PTR [r12+0x398]
    707120f02c0f:	mov    QWORD PTR [rsp],r11
    707120f02c13:	cmp    DWORD PTR [r12+0x310],0x0
    707120f02c1c:	je     0x707120f02cac
    707120f02c22:	push   rdx
    707120f02c23:	push   rsi
    707120f02c24:	push   r10
    707120f02c26:	push   r11
    707120f02c28:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f02c2d:	mov    r10d,edx
    707120f02c30:	and    r10d,0xc0
    707120f02c37:	shl    r10d,0x18
    707120f02c3b:	mov    r11d,edx
    707120f02c3e:	and    r11d,0x1
    707120f02c42:	shl    r11d,0x1d
    707120f02c46:	or     r10d,r11d
    707120f02c49:	mov    r11d,edx
    707120f02c4c:	and    r11d,0x800
    707120f02c53:	shl    r11d,0x11
    707120f02c57:	or     r10d,r11d
    707120f02c5a:	btc    r10,0x1d
    707120f02c5f:	mov    r11d,0xf0000000
    707120f02c65:	and    r11,r10
    707120f02c68:	movabs rsi,0xffffffff0fffffff
    707120f02c72:	and    rbx,rsi
    707120f02c75:	or     rbx,r11
    707120f02c78:	pop    r11
    707120f02c7a:	pop    r10
    707120f02c7c:	pop    rsi
    707120f02c7d:	pop    rdx
    707120f02c7e:	mov    QWORD PTR [r12+0x108],rbx
    707120f02c86:	mov    eax,0x4103f8
    707120f02c8b:	mov    QWORD PTR [r12+0x100],rax
    707120f02c93:	add    rsp,0x150
    707120f02c9a:	mov    eax,0x3
    707120f02c9f:	movabs r11,0x5ab6724ae390
    707120f02ca9:	jmp    r11
    707120f02cac:	mov    r13d,DWORD PTR [r12+0x98]
    707120f02cb4:	add    r13d,0x1
    707120f02cb8:	mov    QWORD PTR [r12+0x98],r13
    707120f02cc0:	sub    r13d,0x10000
    707120f02cc7:	mov    rcx,QWORD PTR [r12+0x380]
    707120f02ccf:	jrcxz  0x707120f02cd6
    707120f02cd1:	jmp    0x707120f09bc6
    707120f02cd6:	pushf
    707120f02cd7:	pop    r11
    707120f02cd9:	mov    QWORD PTR [rsp],r11
    707120f02cdd:	jne    0x707120f079cf
    707120f02ce3:	jmp    0x707120f02ce8
    707120f02ce8:	mov    r13d,0x420000
    707120f02cee:	mov    QWORD PTR [r12+0x40],r13
    707120f02cf3:	movabs r13,0x100000001
    707120f02cfd:	mov    r14d,0x0
    707120f02d03:	mov    QWORD PTR [r12+0x110],r13
    707120f02d0b:	mov    QWORD PTR [r12+0x118],r14
    707120f02d13:	movabs r13,0x3fa0000000000000
    707120f02d1d:	mov    QWORD PTR [r12+0x50],r13
    707120f02d22:	mov    r13d,0x420b10
    707120f02d28:	mov    r14,QWORD PTR [r13+0x0]
    707120f02d2c:	mov    r13d,0x0
    707120f02d32:	mov    QWORD PTR [r12+0x120],r14
    707120f02d3a:	mov    QWORD PTR [r12+0x128],r13
    707120f02d42:	movabs r13,0x4100000041
    707120f02d4c:	mov    r14d,0x0
    707120f02d52:	mov    QWORD PTR [r12+0x140],r13
    707120f02d5a:	mov    QWORD PTR [r12+0x148],r14
    707120f02d62:	movabs r13,0x3fc0000000000000
    707120f02d6c:	movabs r14,0x3fc0000000000000
    707120f02d76:	mov    QWORD PTR [r12+0x150],r13
    707120f02d7e:	mov    QWORD PTR [r12+0x158],r14
    707120f02d86:	movabs r13,0x200000002
    707120f02d90:	mov    r14d,0x0
    707120f02d96:	mov    QWORD PTR [r12+0x160],r13
    707120f02d9e:	mov    QWORD PTR [r12+0x168],r14
    707120f02da6:	mov    r13,QWORD PTR [r12+0x50]
    707120f02dab:	and    r13,0xffffffffffffffff
    707120f02daf:	mov    QWORD PTR [r12+0x130],r13
    707120f02db7:	mov    QWORD PTR [r12+0x138],r13
    707120f02dbf:	mov    r13d,0x2
    707120f02dc5:	mov    QWORD PTR [r12+0x170],r13
    707120f02dcd:	mov    QWORD PTR [r12+0x178],r13
    707120f02dd5:	mov    r13d,0x420000
    707120f02ddb:	mov    QWORD PTR [r12+0x40],r13
    707120f02de0:	mov    r13d,0x430000
    707120f02de6:	mov    QWORD PTR [r12+0x50],r13
    707120f02deb:	mov    r13d,0x420a40
    707120f02df1:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f02df7:	movdqa xmm0,xmm2
    707120f02dfb:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f02e05:	mov    r13d,0x0
    707120f02e0b:	mov    QWORD PTR [r12+0x48],r13
    707120f02e10:	mov    r13d,0x431000
    707120f02e16:	add    r13,0xe00
    707120f02e1d:	mov    QWORD PTR [r12+0x40],r13
    707120f02e22:	mov    r13d,0x430cb8
    707120f02e28:	mov    r14d,DWORD PTR [r12]
    707120f02e2c:	mov    DWORD PTR [r13+0x0],r14d
    707120f02e30:	mov    r13d,0x0
    707120f02e36:	mov    DWORD PTR [r12+0x32c],r13d
    707120f02e3e:	mov    r13d,0x432000
    707120f02e44:	add    r13,0x0
    707120f02e48:	mov    QWORD PTR [r12+0x50],r13
    707120f02e4d:	jmp    0x707120f02e52
    707120f02e52:	mov    r13,QWORD PTR [r12+0x180]
    707120f02e5a:	mov    r14,QWORD PTR [r12+0x188]
    707120f02e62:	mov    r15d,0x0
    707120f02e68:	and    r13,0xffffffffffffffff
    707120f02e6c:	mov    ecx,0xffffffff
    707120f02e71:	and    r13,rcx
    707120f02e74:	mov    rcx,r13
    707120f02e77:	mov    rbp,r15
    707120f02e7a:	or     rbp,rcx
    707120f02e7d:	and    r14,0xffffffffffffffff
    707120f02e81:	mov    ecx,0xffffffff
    707120f02e86:	and    r14,rcx
    707120f02e89:	shl    r14,0x20
    707120f02e8d:	mov    rcx,r14
    707120f02e90:	or     rbp,rcx
    707120f02e93:	mov    QWORD PTR [r12+0x210],rbp
    707120f02e9b:	mov    QWORD PTR [r12+0x218],r15
    707120f02ea3:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120f02ead:	movdqa xmm2,xmm0
    707120f02eb1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f02ebb:	movdqa xmm3,xmm0
    707120f02ebf:	movdqa xmm1,xmm3
    707120f02ec3:	psubd  xmm2,xmm1
    707120f02ec7:	movdqa xmm14,xmm2
    707120f02ecc:	movdqa xmm1,xmm14
    707120f02ed1:	movq   rax,xmm1
    707120f02ed6:	mov    r13,rax
    707120f02ed9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f02ee3:	movdqa xmm2,xmm0
    707120f02ee7:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f02ef1:	movdqa xmm4,xmm0
    707120f02ef5:	movdqa xmm1,xmm4
    707120f02ef9:	paddq  xmm2,xmm1
    707120f02efd:	movdqa xmm0,xmm2
    707120f02f01:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f02f0b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f02f15:	movdqa xmm2,xmm0
    707120f02f19:	movdqa xmm1,xmm2
    707120f02f1d:	paddd  xmm3,xmm1
    707120f02f21:	movdqa xmm14,xmm3
    707120f02f26:	movdqa xmm1,xmm14
    707120f02f2b:	movq   rax,xmm1
    707120f02f30:	mov    r14,rax
    707120f02f33:	mov    r15d,0x0
    707120f02f39:	mov    QWORD PTR [r12+0x120],r14
    707120f02f41:	mov    QWORD PTR [r12+0x128],r15
    707120f02f49:	mov    r14d,0x0
    707120f02f4f:	mov    r15,r13
    707120f02f52:	mov    ecx,0xffffffff
    707120f02f57:	and    r15,rcx
    707120f02f5a:	and    r15,0xffffffffffffffff
    707120f02f5e:	mov    rcx,r15
    707120f02f61:	mov    rbp,r14
    707120f02f64:	or     rbp,rcx
    707120f02f67:	shr    r13,0x20
    707120f02f6b:	mov    ecx,0xffffffff
    707120f02f70:	and    r13,rcx
    707120f02f73:	and    r13,0xffffffffffffffff
    707120f02f77:	mov    rcx,r13
    707120f02f7a:	or     r14,rcx
    707120f02f7d:	mov    QWORD PTR [r12+0x220],rbp
    707120f02f85:	mov    QWORD PTR [r12+0x228],r14
    707120f02f8d:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f02f97:	movdqa xmm2,xmm0
    707120f02f9b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f02fa5:	movdqa xmm3,xmm0
    707120f02fa9:	movdqa xmm1,xmm3
    707120f02fad:	paddd  xmm2,xmm1
    707120f02fb1:	movdqa xmm14,xmm2
    707120f02fb6:	movdqa xmm1,xmm14
    707120f02fbb:	movq   rax,xmm1
    707120f02fc0:	mov    r13,rax
    707120f02fc3:	mov    r14d,0x0
    707120f02fc9:	mov    QWORD PTR [r12+0x210],r13
    707120f02fd1:	mov    QWORD PTR [r12+0x218],r14
    707120f02fd9:	lea    r13,[r12]
    707120f02fdd:	movabs r14,0xb6e61da31
    707120f02fe7:	mov    r15d,0x410468
    707120f02fed:	mov    rdx,QWORD PTR [rsp]
    707120f02ff1:	mov    r10d,edx
    707120f02ff4:	and    r10d,0xc0
    707120f02ffb:	shl    r10d,0x18
    707120f02fff:	mov    r11d,edx
    707120f03002:	and    r11d,0x1
    707120f03006:	shl    r11d,0x1d
    707120f0300a:	or     r10d,r11d
    707120f0300d:	mov    r11d,edx
    707120f03010:	and    r11d,0x800
    707120f03017:	shl    r11d,0x11
    707120f0301b:	or     r10d,r11d
    707120f0301e:	btc    r10,0x1d
    707120f03023:	mov    r11d,0xf0000000
    707120f03029:	and    r11,r10
    707120f0302c:	movabs rsi,0xffffffff0fffffff
    707120f03036:	and    rbx,rsi
    707120f03039:	or     rbx,r11
    707120f0303c:	mov    QWORD PTR [r12+0x378],0x3
    707120f03048:	mov    QWORD PTR [r12+0x108],rbx
    707120f03050:	stmxcsr DWORD PTR [r12-0x28]
    707120f03056:	ldmxcsr DWORD PTR [r12-0x38]
    707120f0305c:	movabs r11,0x5ab672314dc0
    707120f03066:	mov    rdi,r13
    707120f03069:	mov    rsi,r14
    707120f0306c:	mov    rdx,r15
    707120f0306f:	call   r11
    707120f03072:	ldmxcsr DWORD PTR [r12-0x28]
    707120f03078:	mov    rbx,QWORD PTR [r12+0x108]
    707120f03080:	mov    QWORD PTR [r12+0x378],0x2
    707120f0308c:	mov    rbp,rax
    707120f0308f:	mov    r13,QWORD PTR [r12+0x210]
    707120f03097:	mov    r14d,0x0
    707120f0309d:	mov    r15,r13
    707120f030a0:	mov    ecx,0xffffffff
    707120f030a5:	and    r15,rcx
    707120f030a8:	and    r15,0xffffffffffffffff
    707120f030ac:	mov    rcx,r15
    707120f030af:	mov    rbp,r14
    707120f030b2:	or     rbp,rcx
    707120f030b5:	shr    r13,0x20
    707120f030b9:	mov    ecx,0xffffffff
    707120f030be:	and    r13,rcx
    707120f030c1:	and    r13,0xffffffffffffffff
    707120f030c5:	mov    rcx,r13
    707120f030c8:	or     r14,rcx
    707120f030cb:	mov    QWORD PTR [r12+0x210],rbp
    707120f030d3:	mov    QWORD PTR [r12+0x218],r14
    707120f030db:	lea    r13,[r12]
    707120f030df:	movabs r14,0xb6e61da10
    707120f030e9:	mov    r15d,0x410470
    707120f030ef:	mov    QWORD PTR [r12+0x378],0x3
    707120f030fb:	mov    QWORD PTR [r12+0x108],rbx
    707120f03103:	stmxcsr DWORD PTR [r12-0x28]
    707120f03109:	ldmxcsr DWORD PTR [r12-0x38]
    707120f0310f:	movabs r11,0x5ab672314dc0
    707120f03119:	mov    rdi,r13
    707120f0311c:	mov    rsi,r14
    707120f0311f:	mov    rdx,r15
    707120f03122:	call   r11
    707120f03125:	ldmxcsr DWORD PTR [r12-0x28]
    707120f0312b:	mov    rbx,QWORD PTR [r12+0x108]
    707120f03133:	mov    QWORD PTR [r12+0x378],0x2
    707120f0313f:	mov    rbp,rax
    707120f03142:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f0314c:	movdqa xmm2,xmm0
    707120f03150:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120f0315a:	movdqa xmm3,xmm0
    707120f0315e:	stmxcsr DWORD PTR [rsp+0x110]
    707120f03166:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f03171:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f03179:	movdqa xmm0,xmm2
    707120f0317d:	movdqa xmm1,xmm3
    707120f03181:	movq   rax,xmm0
    707120f03186:	add    rax,rax
    707120f03189:	je     0x707120f0319f
    707120f0318b:	shr    rax,0x35
    707120f0318f:	sub    eax,0x201
    707120f03194:	cmp    eax,0x3fc
    707120f03199:	ja     0x707120f07a4d
    707120f0319f:	movdqa xmm14,xmm0
    707120f031a4:	psrldq xmm14,0x8
    707120f031aa:	movq   rax,xmm14
    707120f031af:	add    rax,rax
    707120f031b2:	je     0x707120f031c8
    707120f031b4:	shr    rax,0x35
    707120f031b8:	sub    eax,0x201
    707120f031bd:	cmp    eax,0x3fc
    707120f031c2:	ja     0x707120f07a4d
    707120f031c8:	movq   rax,xmm1
    707120f031cd:	add    rax,rax
    707120f031d0:	je     0x707120f031e6
    707120f031d2:	shr    rax,0x35
    707120f031d6:	sub    eax,0x201
    707120f031db:	cmp    eax,0x3fc
    707120f031e0:	ja     0x707120f07a4d
    707120f031e6:	movdqa xmm14,xmm1
    707120f031eb:	psrldq xmm14,0x8
    707120f031f1:	movq   rax,xmm14
    707120f031f6:	add    rax,rax
    707120f031f9:	je     0x707120f0320f
    707120f031fb:	shr    rax,0x35
    707120f031ff:	sub    eax,0x201
    707120f03204:	cmp    eax,0x3fc
    707120f03209:	ja     0x707120f07a4d
    707120f0320f:	mulpd  xmm0,xmm1
    707120f03213:	movdqa xmm4,xmm0
    707120f03217:	movdqa xmm0,xmm4
    707120f0321b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f03225:	mov    r13,QWORD PTR [r12+0x48]
    707120f0322a:	mov    r14,QWORD PTR [r12+0x50]
    707120f0322f:	mov    rcx,r13
    707120f03232:	add    r14,rcx
    707120f03235:	stmxcsr DWORD PTR [rsp+0x114]
    707120f0323d:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f03245:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f0324d:	shr    r11d,1
    707120f03250:	and    r11d,0x10
    707120f03254:	or     DWORD PTR [r12+0x314],r11d
    707120f0325c:	movdqu XMMWORD PTR [r14],xmm4
    707120f03261:	mov    r14d,0x0
    707120f03267:	mov    DWORD PTR [r12+0x32c],r14d
    707120f0326f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f03279:	movdqa xmm2,xmm0
    707120f0327d:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120f03287:	movdqa xmm3,xmm0
    707120f0328b:	stmxcsr DWORD PTR [rsp+0x110]
    707120f03293:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f0329e:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f032a6:	movdqa xmm0,xmm2
    707120f032aa:	movdqa xmm1,xmm3
    707120f032ae:	movq   rax,xmm0
    707120f032b3:	add    rax,rax
    707120f032b6:	je     0x707120f032cc
    707120f032b8:	shr    rax,0x35
    707120f032bc:	sub    eax,0x201
    707120f032c1:	cmp    eax,0x3fc
    707120f032c6:	ja     0x707120f07a71
    707120f032cc:	movdqa xmm14,xmm0
    707120f032d1:	psrldq xmm14,0x8
    707120f032d7:	movq   rax,xmm14
    707120f032dc:	add    rax,rax
    707120f032df:	je     0x707120f032f5
    707120f032e1:	shr    rax,0x35
    707120f032e5:	sub    eax,0x201
    707120f032ea:	cmp    eax,0x3fc
    707120f032ef:	ja     0x707120f07a71
    707120f032f5:	movq   rax,xmm1
    707120f032fa:	add    rax,rax
    707120f032fd:	je     0x707120f03313
    707120f032ff:	shr    rax,0x35
    707120f03303:	sub    eax,0x201
    707120f03308:	cmp    eax,0x3fc
    707120f0330d:	ja     0x707120f07a71
    707120f03313:	movdqa xmm14,xmm1
    707120f03318:	psrldq xmm14,0x8
    707120f0331e:	movq   rax,xmm14
    707120f03323:	add    rax,rax
    707120f03326:	je     0x707120f0333c
    707120f03328:	shr    rax,0x35
    707120f0332c:	sub    eax,0x201
    707120f03331:	cmp    eax,0x3fc
    707120f03336:	ja     0x707120f07a71
    707120f0333c:	mulpd  xmm0,xmm1
    707120f03340:	movdqa xmm4,xmm0
    707120f03344:	movdqa xmm0,xmm4
    707120f03348:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f03352:	mov    r14,QWORD PTR [r12+0x40]
    707120f03357:	mov    rcx,r13
    707120f0335a:	add    r14,rcx
    707120f0335d:	stmxcsr DWORD PTR [rsp+0x114]
    707120f03365:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f0336d:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f03375:	shr    r11d,1
    707120f03378:	and    r11d,0x10
    707120f0337c:	or     DWORD PTR [r12+0x314],r11d
    707120f03384:	movdqu XMMWORD PTR [r14],xmm4
    707120f03389:	mov    r14d,0x0
    707120f0338f:	mov    DWORD PTR [r12+0x32c],r14d
    707120f03397:	add    r13,0x10
    707120f0339b:	mov    QWORD PTR [r12+0x48],r13
    707120f033a0:	sub    r13,0x200
    707120f033a7:	mov    rcx,QWORD PTR [r12+0x380]
    707120f033af:	jrcxz  0x707120f033b6
    707120f033b1:	jmp    0x707120f09c58
    707120f033b6:	pushf
    707120f033b7:	pop    r11
    707120f033b9:	mov    QWORD PTR [rsp],r11
    707120f033bd:	jne    0x707120f02e52
    707120f033c3:	jmp    0x707120f033c8
    707120f033c8:	mov    r13,QWORD PTR [r12+0x50]
    707120f033cd:	mov    r14,r13
    707120f033d0:	add    r14,0x80
    707120f033d7:	mov    r15,r14
    707120f033da:	add    r15,0x10
    707120f033de:	movdqu xmm2,XMMWORD PTR [r14]
    707120f033e3:	movdqu xmm3,XMMWORD PTR [r15]
    707120f033e8:	movdqa xmm0,xmm2
    707120f033ec:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120f033f6:	movdqa xmm0,xmm3
    707120f033fa:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f03404:	mov    r14d,0x0
    707120f0340a:	mov    r15d,0x0
    707120f03410:	mov    QWORD PTR [r12+0x1b0],r14
    707120f03418:	mov    QWORD PTR [r12+0x1b8],r15
    707120f03420:	mov    r14,r13
    707120f03423:	add    r14,0x40
    707120f03427:	mov    r15,r14
    707120f0342a:	add    r15,0x10
    707120f0342e:	movdqu xmm2,XMMWORD PTR [r14]
    707120f03433:	movdqu xmm3,XMMWORD PTR [r15]
    707120f03438:	movdqa xmm0,xmm2
    707120f0343c:	movdqu XMMWORD PTR [r12+0x250],xmm0
    707120f03446:	movdqa xmm0,xmm3
    707120f0344a:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f03454:	mov    r14d,0x0
    707120f0345a:	mov    QWORD PTR [r12+0x48],r14
    707120f0345f:	mov    r14,r13
    707120f03462:	add    r14,0x10
    707120f03466:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f0346c:	movdqu xmm3,XMMWORD PTR [r14]
    707120f03471:	movdqa xmm0,xmm2
    707120f03475:	movdqu XMMWORD PTR [r12+0x170],xmm0
    707120f0347f:	movdqa xmm0,xmm3
    707120f03483:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f0348d:	mov    r13,QWORD PTR [r12+0xf8]
    707120f03495:	add    r13,0xe0
    707120f0349c:	mov    r14,r13
    707120f0349f:	add    r14,0x10
    707120f034a3:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f034ad:	movdqa xmm2,xmm0
    707120f034b1:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120f034bb:	movdqa xmm3,xmm0
    707120f034bf:	movdqu XMMWORD PTR [r13+0x0],xmm2
    707120f034c5:	mov    r13d,0x0
    707120f034cb:	mov    DWORD PTR [r12+0x32c],r13d
    707120f034d3:	movdqu XMMWORD PTR [r14],xmm3
    707120f034d8:	mov    r13d,0x0
    707120f034de:	mov    DWORD PTR [r12+0x32c],r13d
    707120f034e6:	mov    r13,QWORD PTR [r12+0x50]
    707120f034eb:	mov    r14,r13
    707120f034ee:	add    r14,0xc0
    707120f034f5:	mov    r15,r14
    707120f034f8:	add    r15,0x10
    707120f034fc:	movdqu xmm2,XMMWORD PTR [r14]
    707120f03501:	movdqu xmm3,XMMWORD PTR [r15]
    707120f03506:	movdqa xmm0,xmm2
    707120f0350a:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120f03514:	movdqa xmm0,xmm3
    707120f03518:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f03522:	mov    r14,r13
    707120f03525:	add    r14,0x140
    707120f0352c:	mov    r15,r14
    707120f0352f:	add    r15,0x10
    707120f03533:	movdqu xmm2,XMMWORD PTR [r14]
    707120f03538:	movdqu xmm3,XMMWORD PTR [r15]
    707120f0353d:	movdqa xmm0,xmm2
    707120f03541:	movdqu XMMWORD PTR [r12+0x270],xmm0
    707120f0354b:	movdqa xmm0,xmm3
    707120f0354f:	movdqu XMMWORD PTR [r12+0x190],xmm0
    707120f03559:	add    r13,0x180
    707120f03560:	mov    r14,r13
    707120f03563:	add    r14,0x10
    707120f03567:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f0356d:	movdqu xmm3,XMMWORD PTR [r14]
    707120f03572:	movdqa xmm0,xmm2
    707120f03576:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    707120f03580:	movdqa xmm0,xmm3
    707120f03584:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    707120f0358e:	mov    r13,QWORD PTR [r12+0xf8]
    707120f03596:	add    r13,0xc0
    707120f0359d:	mov    r14,r13
    707120f035a0:	add    r14,0x10
    707120f035a4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f035ae:	movdqa xmm2,xmm0
    707120f035b2:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120f035bc:	movdqa xmm3,xmm0
    707120f035c0:	movdqu XMMWORD PTR [r13+0x0],xmm2
    707120f035c6:	mov    r13d,0x0
    707120f035cc:	mov    DWORD PTR [r12+0x32c],r13d
    707120f035d4:	movdqu XMMWORD PTR [r14],xmm3
    707120f035d9:	mov    r13d,0x0
    707120f035df:	mov    DWORD PTR [r12+0x32c],r13d
    707120f035e7:	mov    r13,QWORD PTR [r12+0x50]
    707120f035ec:	mov    r14,r13
    707120f035ef:	add    r14,0x100
    707120f035f6:	mov    r15,r14
    707120f035f9:	add    r15,0x10
    707120f035fd:	movdqu xmm2,XMMWORD PTR [r14]
    707120f03602:	movdqu xmm3,XMMWORD PTR [r15]
    707120f03607:	movdqa xmm0,xmm2
    707120f0360b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f03615:	movdqa xmm0,xmm3
    707120f03619:	movdqu XMMWORD PTR [r12+0x300],xmm0
    707120f03623:	mov    r14,r13
    707120f03626:	add    r14,0x1c0
    707120f0362d:	mov    r15,r14
    707120f03630:	add    r15,0x10
    707120f03634:	movdqu xmm2,XMMWORD PTR [r14]
    707120f03639:	movdqu xmm3,XMMWORD PTR [r15]
    707120f0363e:	movdqa xmm0,xmm2
    707120f03642:	movdqu XMMWORD PTR [r12+0x240],xmm0
    707120f0364c:	movdqa xmm0,xmm3
    707120f03650:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    707120f0365a:	add    r13,0x20
    707120f0365e:	mov    r14,r13
    707120f03661:	add    r14,0x10
    707120f03665:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f0366b:	movdqu xmm3,XMMWORD PTR [r14]
    707120f03670:	movdqa xmm0,xmm2
    707120f03674:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    707120f0367e:	movdqa xmm0,xmm3
    707120f03682:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
    707120f0368c:	mov    r13,QWORD PTR [r12+0xf8]
    707120f03694:	mov    r14,r13
    707120f03697:	add    r14,0x20
    707120f0369b:	mov    r15,r14
    707120f0369e:	add    r15,0x10
    707120f036a2:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f036ac:	movdqa xmm2,xmm0
    707120f036b0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f036ba:	movdqa xmm3,xmm0
    707120f036be:	movdqu XMMWORD PTR [r14],xmm2
    707120f036c3:	mov    r14d,0x0
    707120f036c9:	mov    DWORD PTR [r12+0x32c],r14d
    707120f036d1:	movdqu XMMWORD PTR [r15],xmm3
    707120f036d6:	mov    r14d,0x0
    707120f036dc:	mov    DWORD PTR [r12+0x32c],r14d
    707120f036e4:	mov    r14,QWORD PTR [r12+0x50]
    707120f036e9:	mov    r15,r14
    707120f036ec:	add    r15,0x60
    707120f036f0:	mov    rbp,r15
    707120f036f3:	add    rbp,0x10
    707120f036f7:	movdqu xmm2,XMMWORD PTR [r15]
    707120f036fc:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    707120f03701:	movdqa xmm0,xmm2
    707120f03705:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f0370f:	movdqa xmm0,xmm3
    707120f03713:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f0371d:	add    r13,0x60
    707120f03721:	mov    r15,r13
    707120f03724:	add    r15,0x10
    707120f03728:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f03732:	movdqa xmm2,xmm0
    707120f03736:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    707120f03740:	movdqa xmm3,xmm0
    707120f03744:	movdqu XMMWORD PTR [r13+0x0],xmm2
    707120f0374a:	mov    r13d,0x0
    707120f03750:	mov    DWORD PTR [r12+0x32c],r13d
    707120f03758:	movdqu XMMWORD PTR [r15],xmm3
    707120f0375d:	mov    r13d,0x0
    707120f03763:	mov    DWORD PTR [r12+0x32c],r13d
    707120f0376b:	mov    r13,r14
    707120f0376e:	add    r13,0xe0
    707120f03775:	mov    r15,r13
    707120f03778:	add    r15,0x10
    707120f0377c:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f03782:	movdqu xmm3,XMMWORD PTR [r15]
    707120f03787:	movdqa xmm0,xmm2
    707120f0378b:	movdqu XMMWORD PTR [r12+0x200],xmm0
    707120f03795:	movdqa xmm0,xmm3
    707120f03799:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    707120f037a3:	add    r14,0x120
    707120f037aa:	mov    r13,r14
    707120f037ad:	add    r13,0x10
    707120f037b1:	movdqu xmm2,XMMWORD PTR [r14]
    707120f037b6:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    707120f037bc:	movdqa xmm0,xmm2
    707120f037c0:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    707120f037ca:	movdqa xmm0,xmm3
    707120f037ce:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    707120f037d8:	mov    r13,QWORD PTR [r12+0xf8]
    707120f037e0:	add    r13,0xa0
    707120f037e7:	mov    r14,r13
    707120f037ea:	add    r14,0x10
    707120f037ee:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f037f8:	movdqa xmm2,xmm0
    707120f037fc:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f03806:	movdqa xmm3,xmm0
    707120f0380a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    707120f03810:	mov    r13d,0x0
    707120f03816:	mov    DWORD PTR [r12+0x32c],r13d
    707120f0381e:	movdqu XMMWORD PTR [r14],xmm3
    707120f03823:	mov    r13d,0x0
    707120f03829:	mov    DWORD PTR [r12+0x32c],r13d
    707120f03831:	mov    r13,QWORD PTR [r12+0x50]
    707120f03836:	mov    r14,r13
    707120f03839:	add    r14,0xa0
    707120f03840:	mov    r15,r14
    707120f03843:	add    r15,0x10
    707120f03847:	movdqu xmm2,XMMWORD PTR [r14]
    707120f0384c:	movdqu xmm3,XMMWORD PTR [r15]
    707120f03851:	movdqa xmm0,xmm2
    707120f03855:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f0385f:	movdqa xmm0,xmm3
    707120f03863:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f0386d:	mov    r14,r13
    707120f03870:	add    r14,0x160
    707120f03877:	mov    r15,r14
    707120f0387a:	add    r15,0x10
    707120f0387e:	movdqu xmm2,XMMWORD PTR [r14]
    707120f03883:	movdqu xmm3,XMMWORD PTR [r15]
    707120f03888:	movdqa xmm0,xmm2
    707120f0388c:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    707120f03896:	movdqa xmm0,xmm3
    707120f0389a:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
    707120f038a4:	add    r13,0x1a0
    707120f038ab:	mov    r14,r13
    707120f038ae:	add    r14,0x10
    707120f038b2:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f038b8:	movdqu xmm3,XMMWORD PTR [r14]
    707120f038bd:	movdqa xmm0,xmm2
    707120f038c1:	movdqu XMMWORD PTR [r12+0x290],xmm0
    707120f038cb:	movdqa xmm0,xmm3
    707120f038cf:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
    707120f038d9:	mov    r13,QWORD PTR [r12+0xf8]
    707120f038e1:	mov    r14,r13
    707120f038e4:	add    r14,0x80
    707120f038eb:	mov    r15,r14
    707120f038ee:	add    r15,0x10
    707120f038f2:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f038fc:	movdqa xmm2,xmm0
    707120f03900:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f0390a:	movdqa xmm3,xmm0
    707120f0390e:	movdqu XMMWORD PTR [r14],xmm2
    707120f03913:	mov    r14d,0x0
    707120f03919:	mov    DWORD PTR [r12+0x32c],r14d
    707120f03921:	movdqu XMMWORD PTR [r15],xmm3
    707120f03926:	mov    r14d,0x0
    707120f0392c:	mov    DWORD PTR [r12+0x32c],r14d
    707120f03934:	mov    r14,QWORD PTR [r12+0x50]
    707120f03939:	add    r14,0x1e0
    707120f03940:	mov    r15,r14
    707120f03943:	add    r15,0x10
    707120f03947:	movdqu xmm2,XMMWORD PTR [r14]
    707120f0394c:	movdqu xmm3,XMMWORD PTR [r15]
    707120f03951:	movdqa xmm0,xmm2
    707120f03955:	movdqu XMMWORD PTR [r12+0x230],xmm0
    707120f0395f:	movdqa xmm0,xmm3
    707120f03963:	movdqu XMMWORD PTR [r12+0x280],xmm0
    707120f0396d:	mov    r14d,0x432000
    707120f03973:	add    r14,0x200
    707120f0397a:	mov    QWORD PTR [r12+0x50],r14
    707120f0397f:	add    r13,0x40
    707120f03983:	mov    r14,r13
    707120f03986:	add    r14,0x10
    707120f0398a:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    707120f03994:	movdqa xmm4,xmm0
    707120f03998:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f039a2:	movdqa xmm5,xmm0
    707120f039a6:	movdqu XMMWORD PTR [r13+0x0],xmm4
    707120f039ac:	mov    r13d,0x0
    707120f039b2:	mov    DWORD PTR [r12+0x32c],r13d
    707120f039ba:	movdqu XMMWORD PTR [r14],xmm5
    707120f039bf:	mov    r13d,0x0
    707120f039c5:	mov    DWORD PTR [r12+0x32c],r13d
    707120f039cd:	mov    r13,QWORD PTR [r12+0xf8]
    707120f039d5:	mov    r14,r13
    707120f039d8:	add    r14,0x10
    707120f039dc:	movdqu XMMWORD PTR [r13+0x0],xmm3
    707120f039e2:	mov    r13d,0x0
    707120f039e8:	mov    DWORD PTR [r12+0x32c],r13d
    707120f039f0:	movdqu XMMWORD PTR [r14],xmm2
    707120f039f5:	mov    r13d,0x0
    707120f039fb:	mov    DWORD PTR [r12+0x32c],r13d
    707120f03a03:	jmp    0x707120f03a08
    707120f03a08:	mov    r13d,0x0
    707120f03a0e:	mov    QWORD PTR [r12+0x58],r13
    707120f03a13:	jmp    0x707120f03a18
    707120f03a18:	mov    r13,QWORD PTR [r12+0x58]
    707120f03a1d:	mov    r14,QWORD PTR [r12+0x40]
    707120f03a22:	mov    rcx,r13
    707120f03a25:	add    r14,rcx
    707120f03a28:	mov    QWORD PTR [r12+0x60],r14
    707120f03a2d:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    707120f03a37:	movdqa xmm2,xmm0
    707120f03a3b:	movdqa xmm1,xmm2
    707120f03a3f:	por    xmm2,xmm1
    707120f03a43:	movdqa xmm0,xmm2
    707120f03a47:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    707120f03a51:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    707120f03a5b:	movdqa xmm2,xmm0
    707120f03a5f:	movdqa xmm1,xmm2
    707120f03a63:	por    xmm2,xmm1
    707120f03a67:	movdqa xmm0,xmm2
    707120f03a6b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f03a75:	add    r14,0x30
    707120f03a79:	mov    r13,r14
    707120f03a7c:	add    r13,0x8
    707120f03a80:	mov    r15,QWORD PTR [r14]
    707120f03a83:	mov    r14,QWORD PTR [r13+0x0]
    707120f03a87:	mov    r13d,0x0
    707120f03a8d:	mov    QWORD PTR [r12+0x130],r15
    707120f03a95:	mov    QWORD PTR [r12+0x138],r13
    707120f03a9d:	mov    r13d,0x0
    707120f03aa3:	mov    QWORD PTR [r12+0x280],r14
    707120f03aab:	mov    QWORD PTR [r12+0x288],r13
    707120f03ab3:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    707120f03abd:	movdqa xmm2,xmm0
    707120f03ac1:	movdqa xmm1,xmm2
    707120f03ac5:	por    xmm2,xmm1
    707120f03ac9:	movdqa xmm0,xmm2
    707120f03acd:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    707120f03ad7:	mov    r13,QWORD PTR [r12+0x60]
    707120f03adc:	mov    r14,r13
    707120f03adf:	add    r14,0x20
    707120f03ae3:	mov    r15,r14
    707120f03ae6:	add    r15,0x8
    707120f03aea:	mov    rbp,QWORD PTR [r14]
    707120f03aed:	mov    r14,QWORD PTR [r15]
    707120f03af0:	mov    r15d,0x0
    707120f03af6:	mov    QWORD PTR [r12+0x150],rbp
    707120f03afe:	mov    QWORD PTR [r12+0x158],r15
    707120f03b06:	mov    r15d,0x0
    707120f03b0c:	mov    QWORD PTR [r12+0x140],r14
    707120f03b14:	mov    QWORD PTR [r12+0x148],r15
    707120f03b1c:	add    r13,0x10
    707120f03b20:	mov    r14,r13
    707120f03b23:	add    r14,0x8
    707120f03b27:	mov    r15,QWORD PTR [r13+0x0]
    707120f03b2b:	mov    r13,QWORD PTR [r14]
    707120f03b2e:	mov    r14d,0x0
    707120f03b34:	mov    QWORD PTR [r12+0x170],r15
    707120f03b3c:	mov    QWORD PTR [r12+0x178],r14
    707120f03b44:	mov    r14d,0x0
    707120f03b4a:	mov    QWORD PTR [r12+0x160],r13
    707120f03b52:	mov    QWORD PTR [r12+0x168],r14
    707120f03b5a:	mov    r13,QWORD PTR [r12+0x60]
    707120f03b5f:	mov    r14d,0x8
    707120f03b65:	mov    r15,QWORD PTR [r13+0x0]
    707120f03b69:	mov    QWORD PTR [r12+0x180],r15
    707120f03b71:	mov    QWORD PTR [r12+0x188],r15
    707120f03b79:	mov    rcx,r14
    707120f03b7c:	add    r13,rcx
    707120f03b7f:	mov    QWORD PTR [r12+0x60],r13
    707120f03b84:	mov    r14,QWORD PTR [r13+0x0]
    707120f03b88:	mov    r13d,0x0
    707120f03b8e:	mov    QWORD PTR [r12+0x230],r14
    707120f03b96:	mov    QWORD PTR [r12+0x238],r13
    707120f03b9e:	mov    r13,QWORD PTR [r12+0xf8]
    707120f03ba6:	mov    r14,r13
    707120f03ba9:	add    r14,0x50
    707120f03bad:	mov    r15,r14
    707120f03bb0:	add    r15,0x10
    707120f03bb4:	movdqu xmm2,XMMWORD PTR [r14]
    707120f03bb9:	movdqu xmm3,XMMWORD PTR [r15]
    707120f03bbe:	movdqa xmm0,xmm2
    707120f03bc2:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f03bcc:	movdqa xmm0,xmm3
    707120f03bd0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f03bda:	add    r13,0x30
    707120f03bde:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f03be4:	movdqa xmm0,xmm2
    707120f03be8:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f03bf2:	mov    r13,QWORD PTR [r12+0x58]
    707120f03bf7:	mov    r14,QWORD PTR [r12+0x50]
    707120f03bfc:	mov    rcx,r13
    707120f03bff:	add    r14,rcx
    707120f03c02:	mov    QWORD PTR [r12+0x60],r14
    707120f03c07:	add    r13,0x40
    707120f03c0b:	mov    QWORD PTR [r12+0x58],r13
    707120f03c10:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f03c1a:	movdqa xmm3,xmm0
    707120f03c1e:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    707120f03c28:	movdqa xmm4,xmm0
    707120f03c2c:	stmxcsr DWORD PTR [rsp+0x110]
    707120f03c34:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f03c3f:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f03c47:	movdqa xmm0,xmm3
    707120f03c4b:	movdqa xmm1,xmm4
    707120f03c4f:	movq   rax,xmm0
    707120f03c54:	add    rax,rax
    707120f03c57:	je     0x707120f03c6d
    707120f03c59:	shr    rax,0x35
    707120f03c5d:	sub    eax,0x201
    707120f03c62:	cmp    eax,0x3fc
    707120f03c67:	ja     0x707120f07a95
    707120f03c6d:	movdqa xmm14,xmm0
    707120f03c72:	psrldq xmm14,0x8
    707120f03c78:	movq   rax,xmm14
    707120f03c7d:	add    rax,rax
    707120f03c80:	je     0x707120f03c96
    707120f03c82:	shr    rax,0x35
    707120f03c86:	sub    eax,0x201
    707120f03c8b:	cmp    eax,0x3fc
    707120f03c90:	ja     0x707120f07a95
    707120f03c96:	movq   rax,xmm1
    707120f03c9b:	add    rax,rax
    707120f03c9e:	je     0x707120f03cb4
    707120f03ca0:	shr    rax,0x35
    707120f03ca4:	sub    eax,0x201
    707120f03ca9:	cmp    eax,0x3fc
    707120f03cae:	ja     0x707120f07a95
    707120f03cb4:	movdqa xmm14,xmm1
    707120f03cb9:	psrldq xmm14,0x8
    707120f03cbf:	movq   rax,xmm14
    707120f03cc4:	add    rax,rax
    707120f03cc7:	je     0x707120f03cdd
    707120f03cc9:	shr    rax,0x35
    707120f03ccd:	sub    eax,0x201
    707120f03cd2:	cmp    eax,0x3fc
    707120f03cd7:	ja     0x707120f07a95
    707120f03cdd:	mulpd  xmm0,xmm1
    707120f03ce1:	movdqa xmm5,xmm0
    707120f03ce5:	movdqa xmm0,xmm5
    707120f03ce9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    707120f03cf3:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120f03cfd:	movdqa xmm4,xmm0
    707120f03d01:	movdqa xmm0,xmm2
    707120f03d05:	movdqa xmm1,xmm4
    707120f03d09:	pshufd xmm1,xmm1,0x44
    707120f03d0e:	movq   rax,xmm0
    707120f03d13:	add    rax,rax
    707120f03d16:	je     0x707120f03d2c
    707120f03d18:	shr    rax,0x35
    707120f03d1c:	sub    eax,0x201
    707120f03d21:	cmp    eax,0x3fc
    707120f03d26:	ja     0x707120f07ab9
    707120f03d2c:	movdqa xmm14,xmm0
    707120f03d31:	psrldq xmm14,0x8
    707120f03d37:	movq   rax,xmm14
    707120f03d3c:	add    rax,rax
    707120f03d3f:	je     0x707120f03d55
    707120f03d41:	shr    rax,0x35
    707120f03d45:	sub    eax,0x201
    707120f03d4a:	cmp    eax,0x3fc
    707120f03d4f:	ja     0x707120f07ab9
    707120f03d55:	movq   rax,xmm1
    707120f03d5a:	add    rax,rax
    707120f03d5d:	je     0x707120f03d73
    707120f03d5f:	shr    rax,0x35
    707120f03d63:	sub    eax,0x201
    707120f03d68:	cmp    eax,0x3fc
    707120f03d6d:	ja     0x707120f07ab9
    707120f03d73:	movdqa xmm14,xmm1
    707120f03d78:	psrldq xmm14,0x8
    707120f03d7e:	movq   rax,xmm14
    707120f03d83:	add    rax,rax
    707120f03d86:	je     0x707120f03d9c
    707120f03d88:	shr    rax,0x35
    707120f03d8c:	sub    eax,0x201
    707120f03d91:	cmp    eax,0x3fc
    707120f03d96:	ja     0x707120f07ab9
    707120f03d9c:	mulpd  xmm0,xmm1
    707120f03da0:	movdqa xmm5,xmm0
    707120f03da4:	movdqa xmm0,xmm5
    707120f03da8:	movdqu XMMWORD PTR [r12+0x260],xmm0
    707120f03db2:	mov    r13d,0x0
    707120f03db8:	mov    r14d,0x0
    707120f03dbe:	mov    QWORD PTR [r12+0x110],r13
    707120f03dc6:	mov    QWORD PTR [r12+0x118],r14
    707120f03dce:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f03dd8:	movdqa xmm2,xmm0
    707120f03ddc:	movdqa xmm0,xmm3
    707120f03de0:	movdqa xmm1,xmm2
    707120f03de4:	movq   rax,xmm0
    707120f03de9:	add    rax,rax
    707120f03dec:	je     0x707120f03e02
    707120f03dee:	shr    rax,0x35
    707120f03df2:	sub    eax,0x201
    707120f03df7:	cmp    eax,0x3fc
    707120f03dfc:	ja     0x707120f07add
    707120f03e02:	movdqa xmm14,xmm0
    707120f03e07:	psrldq xmm14,0x8
    707120f03e0d:	movq   rax,xmm14
    707120f03e12:	add    rax,rax
    707120f03e15:	je     0x707120f03e2b
    707120f03e17:	shr    rax,0x35
    707120f03e1b:	sub    eax,0x201
    707120f03e20:	cmp    eax,0x3fc
    707120f03e25:	ja     0x707120f07add
    707120f03e2b:	movq   rax,xmm1
    707120f03e30:	add    rax,rax
    707120f03e33:	je     0x707120f03e49
    707120f03e35:	shr    rax,0x35
    707120f03e39:	sub    eax,0x201
    707120f03e3e:	cmp    eax,0x3fc
    707120f03e43:	ja     0x707120f07add
    707120f03e49:	movdqa xmm14,xmm1
    707120f03e4e:	psrldq xmm14,0x8
    707120f03e54:	movq   rax,xmm14
    707120f03e59:	add    rax,rax
    707120f03e5c:	je     0x707120f03e72
    707120f03e5e:	shr    rax,0x35
    707120f03e62:	sub    eax,0x201
    707120f03e67:	cmp    eax,0x3fc
    707120f03e6c:	ja     0x707120f07add
    707120f03e72:	mulpd  xmm0,xmm1
    707120f03e76:	movdqa xmm4,xmm0
    707120f03e7a:	movdqa xmm0,xmm4
    707120f03e7e:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f03e88:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f03e92:	movdqa xmm2,xmm0
    707120f03e96:	movdqa xmm0,xmm3
    707120f03e9a:	movdqa xmm1,xmm2
    707120f03e9e:	movq   rax,xmm0
    707120f03ea3:	add    rax,rax
    707120f03ea6:	je     0x707120f03ebc
    707120f03ea8:	shr    rax,0x35
    707120f03eac:	sub    eax,0x201
    707120f03eb1:	cmp    eax,0x3fc
    707120f03eb6:	ja     0x707120f07b01
    707120f03ebc:	movdqa xmm14,xmm0
    707120f03ec1:	psrldq xmm14,0x8
    707120f03ec7:	movq   rax,xmm14
    707120f03ecc:	add    rax,rax
    707120f03ecf:	je     0x707120f03ee5
    707120f03ed1:	shr    rax,0x35
    707120f03ed5:	sub    eax,0x201
    707120f03eda:	cmp    eax,0x3fc
    707120f03edf:	ja     0x707120f07b01
    707120f03ee5:	movq   rax,xmm1
    707120f03eea:	add    rax,rax
    707120f03eed:	je     0x707120f03f03
    707120f03eef:	shr    rax,0x35
    707120f03ef3:	sub    eax,0x201
    707120f03ef8:	cmp    eax,0x3fc
    707120f03efd:	ja     0x707120f07b01
    707120f03f03:	movdqa xmm14,xmm1
    707120f03f08:	psrldq xmm14,0x8
    707120f03f0e:	movq   rax,xmm14
    707120f03f13:	add    rax,rax
    707120f03f16:	je     0x707120f03f2c
    707120f03f18:	shr    rax,0x35
    707120f03f1c:	sub    eax,0x201
    707120f03f21:	cmp    eax,0x3fc
    707120f03f26:	ja     0x707120f07b01
    707120f03f2c:	mulpd  xmm0,xmm1
    707120f03f30:	movdqa xmm4,xmm0
    707120f03f34:	movdqa xmm0,xmm4
    707120f03f38:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f03f42:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f03f4c:	movdqa xmm2,xmm0
    707120f03f50:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    707120f03f5a:	movdqa xmm3,xmm0
    707120f03f5e:	movdqa xmm0,xmm2
    707120f03f62:	movdqa xmm1,xmm3
    707120f03f66:	movq   rax,xmm0
    707120f03f6b:	add    rax,rax
    707120f03f6e:	je     0x707120f03f84
    707120f03f70:	shr    rax,0x35
    707120f03f74:	sub    eax,0x201
    707120f03f79:	cmp    eax,0x3fc
    707120f03f7e:	ja     0x707120f07b25
    707120f03f84:	movdqa xmm14,xmm0
    707120f03f89:	psrldq xmm14,0x8
    707120f03f8f:	movq   rax,xmm14
    707120f03f94:	add    rax,rax
    707120f03f97:	je     0x707120f03fad
    707120f03f99:	shr    rax,0x35
    707120f03f9d:	sub    eax,0x201
    707120f03fa2:	cmp    eax,0x3fc
    707120f03fa7:	ja     0x707120f07b25
    707120f03fad:	movq   rax,xmm1
    707120f03fb2:	add    rax,rax
    707120f03fb5:	je     0x707120f03fcb
    707120f03fb7:	shr    rax,0x35
    707120f03fbb:	sub    eax,0x201
    707120f03fc0:	cmp    eax,0x3fc
    707120f03fc5:	ja     0x707120f07b25
    707120f03fcb:	movdqa xmm14,xmm1
    707120f03fd0:	psrldq xmm14,0x8
    707120f03fd6:	movq   rax,xmm14
    707120f03fdb:	add    rax,rax
    707120f03fde:	je     0x707120f03ff4
    707120f03fe0:	shr    rax,0x35
    707120f03fe4:	sub    eax,0x201
    707120f03fe9:	cmp    eax,0x3fc
    707120f03fee:	ja     0x707120f07b25
    707120f03ff4:	mulpd  xmm0,xmm1
    707120f03ff8:	movdqa xmm4,xmm0
    707120f03ffc:	movdqa xmm0,xmm4
    707120f04000:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f0400a:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    707120f04014:	movdqa xmm2,xmm0
    707120f04018:	movdqa xmm1,xmm2
    707120f0401c:	por    xmm2,xmm1
    707120f04020:	movdqa xmm0,xmm2
    707120f04024:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    707120f0402e:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    707120f04038:	movdqa xmm2,xmm0
    707120f0403c:	movdqa xmm3,xmm2
    707120f04040:	movdqa xmm1,xmm2
    707120f04044:	por    xmm3,xmm1
    707120f04048:	movdqa xmm0,xmm3
    707120f0404c:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    707120f04056:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120f04060:	movdqa xmm3,xmm0
    707120f04064:	movdqa xmm0,xmm2
    707120f04068:	movdqa xmm1,xmm3
    707120f0406c:	pshufd xmm1,xmm1,0x44
    707120f04071:	movq   rax,xmm0
    707120f04076:	add    rax,rax
    707120f04079:	je     0x707120f0408f
    707120f0407b:	shr    rax,0x35
    707120f0407f:	sub    eax,0x201
    707120f04084:	cmp    eax,0x3fc
    707120f04089:	ja     0x707120f07b49
    707120f0408f:	movdqa xmm14,xmm0
    707120f04094:	psrldq xmm14,0x8
    707120f0409a:	movq   rax,xmm14
    707120f0409f:	add    rax,rax
    707120f040a2:	je     0x707120f040b8
    707120f040a4:	shr    rax,0x35
    707120f040a8:	sub    eax,0x201
    707120f040ad:	cmp    eax,0x3fc
    707120f040b2:	ja     0x707120f07b49
    707120f040b8:	movq   rax,xmm1
    707120f040bd:	add    rax,rax
    707120f040c0:	je     0x707120f040d6
    707120f040c2:	shr    rax,0x35
    707120f040c6:	sub    eax,0x201
    707120f040cb:	cmp    eax,0x3fc
    707120f040d0:	ja     0x707120f07b49
    707120f040d6:	movdqa xmm14,xmm1
    707120f040db:	psrldq xmm14,0x8
    707120f040e1:	movq   rax,xmm14
    707120f040e6:	add    rax,rax
    707120f040e9:	je     0x707120f040ff
    707120f040eb:	shr    rax,0x35
    707120f040ef:	sub    eax,0x201
    707120f040f4:	cmp    eax,0x3fc
    707120f040f9:	ja     0x707120f07b49
    707120f040ff:	mulpd  xmm0,xmm1
    707120f04103:	movdqa xmm4,xmm0
    707120f04107:	movdqa xmm0,xmm4
    707120f0410b:	movdqu XMMWORD PTR [r12+0x250],xmm0
    707120f04115:	mov    r13,QWORD PTR [r12+0x58]
    707120f0411a:	stmxcsr DWORD PTR [rsp+0x114]
    707120f04122:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f0412a:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f04132:	shr    r11d,1
    707120f04135:	and    r11d,0x10
    707120f04139:	or     DWORD PTR [r12+0x314],r11d
    707120f04141:	sub    r13,0x200
    707120f04148:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    707120f04152:	movdqa xmm2,xmm0
    707120f04156:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f04160:	movdqa xmm3,xmm0
    707120f04164:	pushf
    707120f04165:	pop    r11
    707120f04167:	mov    QWORD PTR [rsp],r11
    707120f0416b:	stmxcsr DWORD PTR [rsp+0x110]
    707120f04173:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f0417e:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f04186:	movdqa xmm0,xmm2
    707120f0418a:	movdqa xmm1,xmm3
    707120f0418e:	movq   rax,xmm0
    707120f04193:	add    rax,rax
    707120f04196:	je     0x707120f041ac
    707120f04198:	shr    rax,0x35
    707120f0419c:	sub    eax,0x201
    707120f041a1:	cmp    eax,0x3fc
    707120f041a6:	ja     0x707120f07b6d
    707120f041ac:	movdqa xmm14,xmm0
    707120f041b1:	psrldq xmm14,0x8
    707120f041b7:	movq   rax,xmm14
    707120f041bc:	add    rax,rax
    707120f041bf:	je     0x707120f041d5
    707120f041c1:	shr    rax,0x35
    707120f041c5:	sub    eax,0x201
    707120f041ca:	cmp    eax,0x3fc
    707120f041cf:	ja     0x707120f07b6d
    707120f041d5:	movq   rax,xmm1
    707120f041da:	add    rax,rax
    707120f041dd:	je     0x707120f041f3
    707120f041df:	shr    rax,0x35
    707120f041e3:	sub    eax,0x201
    707120f041e8:	cmp    eax,0x3fc
    707120f041ed:	ja     0x707120f07b6d
    707120f041f3:	movdqa xmm14,xmm1
    707120f041f8:	psrldq xmm14,0x8
    707120f041fe:	movq   rax,xmm14
    707120f04203:	add    rax,rax
    707120f04206:	je     0x707120f0421c
    707120f04208:	shr    rax,0x35
    707120f0420c:	sub    eax,0x201
    707120f04211:	cmp    eax,0x3fc
    707120f04216:	ja     0x707120f07b6d
    707120f0421c:	addpd  xmm0,xmm1
    707120f04220:	movdqa xmm4,xmm0
    707120f04224:	movdqa xmm0,xmm4
    707120f04228:	movdqu XMMWORD PTR [r12+0x240],xmm0
    707120f04232:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f0423c:	movdqa xmm2,xmm0
    707120f04240:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    707120f0424a:	movdqa xmm3,xmm0
    707120f0424e:	movdqa xmm0,xmm2
    707120f04252:	movdqa xmm1,xmm3
    707120f04256:	movq   rax,xmm0
    707120f0425b:	add    rax,rax
    707120f0425e:	je     0x707120f04274
    707120f04260:	shr    rax,0x35
    707120f04264:	sub    eax,0x201
    707120f04269:	cmp    eax,0x3fc
    707120f0426e:	ja     0x707120f07b91
    707120f04274:	movdqa xmm14,xmm0
    707120f04279:	psrldq xmm14,0x8
    707120f0427f:	movq   rax,xmm14
    707120f04284:	add    rax,rax
    707120f04287:	je     0x707120f0429d
    707120f04289:	shr    rax,0x35
    707120f0428d:	sub    eax,0x201
    707120f04292:	cmp    eax,0x3fc
    707120f04297:	ja     0x707120f07b91
    707120f0429d:	movq   rax,xmm1
    707120f042a2:	add    rax,rax
    707120f042a5:	je     0x707120f042bb
    707120f042a7:	shr    rax,0x35
    707120f042ab:	sub    eax,0x201
    707120f042b0:	cmp    eax,0x3fc
    707120f042b5:	ja     0x707120f07b91
    707120f042bb:	movdqa xmm14,xmm1
    707120f042c0:	psrldq xmm14,0x8
    707120f042c6:	movq   rax,xmm14
    707120f042cb:	add    rax,rax
    707120f042ce:	je     0x707120f042e4
    707120f042d0:	shr    rax,0x35
    707120f042d4:	sub    eax,0x201
    707120f042d9:	cmp    eax,0x3fc
    707120f042de:	ja     0x707120f07b91
    707120f042e4:	addpd  xmm0,xmm1
    707120f042e8:	movdqa xmm4,xmm0
    707120f042ec:	movdqa xmm0,xmm4
    707120f042f0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f042fa:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f04304:	movdqa xmm2,xmm0
    707120f04308:	movdqa xmm0,xmm2
    707120f0430c:	movdqa xmm1,xmm3
    707120f04310:	movq   rax,xmm0
    707120f04315:	add    rax,rax
    707120f04318:	je     0x707120f0432e
    707120f0431a:	shr    rax,0x35
    707120f0431e:	sub    eax,0x201
    707120f04323:	cmp    eax,0x3fc
    707120f04328:	ja     0x707120f07bb5
    707120f0432e:	movdqa xmm14,xmm0
    707120f04333:	psrldq xmm14,0x8
    707120f04339:	movq   rax,xmm14
    707120f0433e:	add    rax,rax
    707120f04341:	je     0x707120f04357
    707120f04343:	shr    rax,0x35
    707120f04347:	sub    eax,0x201
    707120f0434c:	cmp    eax,0x3fc
    707120f04351:	ja     0x707120f07bb5
    707120f04357:	movq   rax,xmm1
    707120f0435c:	add    rax,rax
    707120f0435f:	je     0x707120f04375
    707120f04361:	shr    rax,0x35
    707120f04365:	sub    eax,0x201
    707120f0436a:	cmp    eax,0x3fc
    707120f0436f:	ja     0x707120f07bb5
    707120f04375:	movdqa xmm14,xmm1
    707120f0437a:	psrldq xmm14,0x8
    707120f04380:	movq   rax,xmm14
    707120f04385:	add    rax,rax
    707120f04388:	je     0x707120f0439e
    707120f0438a:	shr    rax,0x35
    707120f0438e:	sub    eax,0x201
    707120f04393:	cmp    eax,0x3fc
    707120f04398:	ja     0x707120f07bb5
    707120f0439e:	addpd  xmm0,xmm1
    707120f043a2:	movdqa xmm4,xmm0
    707120f043a6:	movdqa xmm0,xmm4
    707120f043aa:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f043b4:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    707120f043be:	movdqa xmm2,xmm0
    707120f043c2:	movdqa xmm1,xmm2
    707120f043c6:	por    xmm2,xmm1
    707120f043ca:	movdqa xmm0,xmm2
    707120f043ce:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    707120f043d8:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    707120f043e2:	movdqa xmm2,xmm0
    707120f043e6:	movdqa xmm1,xmm2
    707120f043ea:	por    xmm2,xmm1
    707120f043ee:	movdqa xmm0,xmm2
    707120f043f2:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    707120f043fc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    707120f04406:	movdqa xmm2,xmm0
    707120f0440a:	movdqa xmm1,xmm2
    707120f0440e:	por    xmm2,xmm1
    707120f04412:	movdqa xmm0,xmm2
    707120f04416:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    707120f04420:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    707120f0442a:	movdqa xmm2,xmm0
    707120f0442e:	movdqa xmm1,xmm2
    707120f04432:	por    xmm2,xmm1
    707120f04436:	movdqa xmm0,xmm2
    707120f0443a:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    707120f04444:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    707120f0444e:	movdqa xmm2,xmm0
    707120f04452:	movdqa xmm1,xmm2
    707120f04456:	por    xmm2,xmm1
    707120f0445a:	movdqa xmm0,xmm2
    707120f0445e:	movdqu XMMWORD PTR [r12+0x200],xmm0
    707120f04468:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    707120f04472:	movdqa xmm2,xmm0
    707120f04476:	movdqa xmm1,xmm2
    707120f0447a:	por    xmm2,xmm1
    707120f0447e:	movdqa xmm0,xmm2
    707120f04482:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    707120f0448c:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    707120f04496:	movdqa xmm2,xmm0
    707120f0449a:	movdqa xmm1,xmm2
    707120f0449e:	por    xmm2,xmm1
    707120f044a2:	movdqa xmm0,xmm2
    707120f044a6:	movdqu XMMWORD PTR [r12+0x190],xmm0
    707120f044b0:	mov    r13,QWORD PTR [r12+0xf8]
    707120f044b8:	mov    r14,r13
    707120f044bb:	add    r14,0xa0
    707120f044c2:	mov    r15,r14
    707120f044c5:	add    r15,0x10
    707120f044c9:	stmxcsr DWORD PTR [rsp+0x114]
    707120f044d1:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f044d9:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f044e1:	shr    r11d,1
    707120f044e4:	and    r11d,0x10
    707120f044e8:	or     DWORD PTR [r12+0x314],r11d
    707120f044f0:	movdqu xmm2,XMMWORD PTR [r14]
    707120f044f5:	movdqu xmm3,XMMWORD PTR [r15]
    707120f044fa:	movdqa xmm0,xmm2
    707120f044fe:	movdqu XMMWORD PTR [r12+0x300],xmm0
    707120f04508:	movdqa xmm0,xmm3
    707120f0450c:	movdqu XMMWORD PTR [r12+0x270],xmm0
    707120f04516:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f04520:	movdqa xmm2,xmm0
    707120f04524:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f0452e:	movdqa xmm4,xmm0
    707120f04532:	stmxcsr DWORD PTR [rsp+0x110]
    707120f0453a:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f04545:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f0454d:	movdqa xmm0,xmm2
    707120f04551:	movdqa xmm1,xmm4
    707120f04555:	movq   rax,xmm0
    707120f0455a:	add    rax,rax
    707120f0455d:	je     0x707120f04573
    707120f0455f:	shr    rax,0x35
    707120f04563:	sub    eax,0x201
    707120f04568:	cmp    eax,0x3fc
    707120f0456d:	ja     0x707120f07bd9
    707120f04573:	movdqa xmm14,xmm0
    707120f04578:	psrldq xmm14,0x8
    707120f0457e:	movq   rax,xmm14
    707120f04583:	add    rax,rax
    707120f04586:	je     0x707120f0459c
    707120f04588:	shr    rax,0x35
    707120f0458c:	sub    eax,0x201
    707120f04591:	cmp    eax,0x3fc
    707120f04596:	ja     0x707120f07bd9
    707120f0459c:	movq   rax,xmm1
    707120f045a1:	add    rax,rax
    707120f045a4:	je     0x707120f045ba
    707120f045a6:	shr    rax,0x35
    707120f045aa:	sub    eax,0x201
    707120f045af:	cmp    eax,0x3fc
    707120f045b4:	ja     0x707120f07bd9
    707120f045ba:	movdqa xmm14,xmm1
    707120f045bf:	psrldq xmm14,0x8
    707120f045c5:	movq   rax,xmm14
    707120f045ca:	add    rax,rax
    707120f045cd:	je     0x707120f045e3
    707120f045cf:	shr    rax,0x35
    707120f045d3:	sub    eax,0x201
    707120f045d8:	cmp    eax,0x3fc
    707120f045dd:	ja     0x707120f07bd9
    707120f045e3:	addpd  xmm0,xmm1
    707120f045e7:	movdqa xmm5,xmm0
    707120f045eb:	movdqa xmm0,xmm5
    707120f045ef:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f045f9:	add    r13,0xf0
    707120f04600:	stmxcsr DWORD PTR [rsp+0x114]
    707120f04608:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f04610:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f04618:	shr    r11d,1
    707120f0461b:	and    r11d,0x10
    707120f0461f:	or     DWORD PTR [r12+0x314],r11d
    707120f04627:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f0462d:	movdqa xmm0,xmm2
    707120f04631:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f0463b:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f04645:	movdqa xmm4,xmm0
    707120f04649:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    707120f04653:	movdqa xmm5,xmm0
    707120f04657:	stmxcsr DWORD PTR [rsp+0x110]
    707120f0465f:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f0466a:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f04672:	movdqa xmm0,xmm4
    707120f04676:	movdqa xmm1,xmm5
    707120f0467a:	movq   rax,xmm0
    707120f0467f:	add    rax,rax
    707120f04682:	je     0x707120f04698
    707120f04684:	shr    rax,0x35
    707120f04688:	sub    eax,0x201
    707120f0468d:	cmp    eax,0x3fc
    707120f04692:	ja     0x707120f07bfd
    707120f04698:	movdqa xmm14,xmm0
    707120f0469d:	psrldq xmm14,0x8
    707120f046a3:	movq   rax,xmm14
    707120f046a8:	add    rax,rax
    707120f046ab:	je     0x707120f046c1
    707120f046ad:	shr    rax,0x35
    707120f046b1:	sub    eax,0x201
    707120f046b6:	cmp    eax,0x3fc
    707120f046bb:	ja     0x707120f07bfd
    707120f046c1:	movq   rax,xmm1
    707120f046c6:	add    rax,rax
    707120f046c9:	je     0x707120f046df
    707120f046cb:	shr    rax,0x35
    707120f046cf:	sub    eax,0x201
    707120f046d4:	cmp    eax,0x3fc
    707120f046d9:	ja     0x707120f07bfd
    707120f046df:	movdqa xmm14,xmm1
    707120f046e4:	psrldq xmm14,0x8
    707120f046ea:	movq   rax,xmm14
    707120f046ef:	add    rax,rax
    707120f046f2:	je     0x707120f04708
    707120f046f4:	shr    rax,0x35
    707120f046f8:	sub    eax,0x201
    707120f046fd:	cmp    eax,0x3fc
    707120f04702:	ja     0x707120f07bfd
    707120f04708:	addpd  xmm0,xmm1
    707120f0470c:	movdqa xmm6,xmm0
    707120f04710:	movdqa xmm0,xmm6
    707120f04714:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f0471e:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f04728:	movdqa xmm4,xmm0
    707120f0472c:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    707120f04736:	movdqa xmm5,xmm0
    707120f0473a:	movdqa xmm0,xmm4
    707120f0473e:	movdqa xmm1,xmm5
    707120f04742:	movq   rax,xmm0
    707120f04747:	add    rax,rax
    707120f0474a:	je     0x707120f04760
    707120f0474c:	shr    rax,0x35
    707120f04750:	sub    eax,0x201
    707120f04755:	cmp    eax,0x3fc
    707120f0475a:	ja     0x707120f07c21
    707120f04760:	movdqa xmm14,xmm0
    707120f04765:	psrldq xmm14,0x8
    707120f0476b:	movq   rax,xmm14
    707120f04770:	add    rax,rax
    707120f04773:	je     0x707120f04789
    707120f04775:	shr    rax,0x35
    707120f04779:	sub    eax,0x201
    707120f0477e:	cmp    eax,0x3fc
    707120f04783:	ja     0x707120f07c21
    707120f04789:	movq   rax,xmm1
    707120f0478e:	add    rax,rax
    707120f04791:	je     0x707120f047a7
    707120f04793:	shr    rax,0x35
    707120f04797:	sub    eax,0x201
    707120f0479c:	cmp    eax,0x3fc
    707120f047a1:	ja     0x707120f07c21
    707120f047a7:	movdqa xmm14,xmm1
    707120f047ac:	psrldq xmm14,0x8
    707120f047b2:	movq   rax,xmm14
    707120f047b7:	add    rax,rax
    707120f047ba:	je     0x707120f047d0
    707120f047bc:	shr    rax,0x35
    707120f047c0:	sub    eax,0x201
    707120f047c5:	cmp    eax,0x3fc
    707120f047ca:	ja     0x707120f07c21
    707120f047d0:	addpd  xmm0,xmm1
    707120f047d4:	movdqa xmm6,xmm0
    707120f047d8:	movdqa xmm0,xmm6
    707120f047dc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f047e6:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120f047f0:	movdqa xmm4,xmm0
    707120f047f4:	movdqa xmm0,xmm3
    707120f047f8:	movdqa xmm1,xmm4
    707120f047fc:	pshufd xmm1,xmm1,0x44
    707120f04801:	movq   rax,xmm0
    707120f04806:	add    rax,rax
    707120f04809:	je     0x707120f0481f
    707120f0480b:	shr    rax,0x35
    707120f0480f:	sub    eax,0x201
    707120f04814:	cmp    eax,0x3fc
    707120f04819:	ja     0x707120f07c45
    707120f0481f:	movdqa xmm14,xmm0
    707120f04824:	psrldq xmm14,0x8
    707120f0482a:	movq   rax,xmm14
    707120f0482f:	add    rax,rax
    707120f04832:	je     0x707120f04848
    707120f04834:	shr    rax,0x35
    707120f04838:	sub    eax,0x201
    707120f0483d:	cmp    eax,0x3fc
    707120f04842:	ja     0x707120f07c45
    707120f04848:	movq   rax,xmm1
    707120f0484d:	add    rax,rax
    707120f04850:	je     0x707120f04866
    707120f04852:	shr    rax,0x35
    707120f04856:	sub    eax,0x201
    707120f0485b:	cmp    eax,0x3fc
    707120f04860:	ja     0x707120f07c45
    707120f04866:	movdqa xmm14,xmm1
    707120f0486b:	psrldq xmm14,0x8
    707120f04871:	movq   rax,xmm14
    707120f04876:	add    rax,rax
    707120f04879:	je     0x707120f0488f
    707120f0487b:	shr    rax,0x35
    707120f0487f:	sub    eax,0x201
    707120f04884:	cmp    eax,0x3fc
    707120f04889:	ja     0x707120f07c45
    707120f0488f:	mulpd  xmm0,xmm1
    707120f04893:	movdqa xmm5,xmm0
    707120f04897:	movdqa xmm0,xmm5
    707120f0489b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    707120f048a5:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f048af:	movdqa xmm3,xmm0
    707120f048b3:	movdqa xmm0,xmm2
    707120f048b7:	movdqa xmm1,xmm3
    707120f048bb:	pshufd xmm1,xmm1,0x44
    707120f048c0:	movq   rax,xmm0
    707120f048c5:	add    rax,rax
    707120f048c8:	je     0x707120f048de
    707120f048ca:	shr    rax,0x35
    707120f048ce:	sub    eax,0x201
    707120f048d3:	cmp    eax,0x3fc
    707120f048d8:	ja     0x707120f07c69
    707120f048de:	movdqa xmm14,xmm0
    707120f048e3:	psrldq xmm14,0x8
    707120f048e9:	movq   rax,xmm14
    707120f048ee:	add    rax,rax
    707120f048f1:	je     0x707120f04907
    707120f048f3:	shr    rax,0x35
    707120f048f7:	sub    eax,0x201
    707120f048fc:	cmp    eax,0x3fc
    707120f04901:	ja     0x707120f07c69
    707120f04907:	movq   rax,xmm1
    707120f0490c:	add    rax,rax
    707120f0490f:	je     0x707120f04925
    707120f04911:	shr    rax,0x35
    707120f04915:	sub    eax,0x201
    707120f0491a:	cmp    eax,0x3fc
    707120f0491f:	ja     0x707120f07c69
    707120f04925:	movdqa xmm14,xmm1
    707120f0492a:	psrldq xmm14,0x8
    707120f04930:	movq   rax,xmm14
    707120f04935:	add    rax,rax
    707120f04938:	je     0x707120f0494e
    707120f0493a:	shr    rax,0x35
    707120f0493e:	sub    eax,0x201
    707120f04943:	cmp    eax,0x3fc
    707120f04948:	ja     0x707120f07c69
    707120f0494e:	mulpd  xmm0,xmm1
    707120f04952:	movdqa xmm5,xmm0
    707120f04956:	movdqa xmm0,xmm5
    707120f0495a:	movdqu XMMWORD PTR [r12+0x250],xmm0
    707120f04964:	mov    r13,QWORD PTR [r12+0xf8]
    707120f0496c:	mov    r14,r13
    707120f0496f:	add    r14,0xe0
    707120f04976:	stmxcsr DWORD PTR [rsp+0x114]
    707120f0497e:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f04986:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f0498e:	shr    r11d,1
    707120f04991:	and    r11d,0x10
    707120f04995:	or     DWORD PTR [r12+0x314],r11d
    707120f0499d:	movdqu xmm2,XMMWORD PTR [r14]
    707120f049a2:	movdqa xmm0,xmm2
    707120f049a6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f049b0:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    707120f049ba:	movdqa xmm2,xmm0
    707120f049be:	stmxcsr DWORD PTR [rsp+0x110]
    707120f049c6:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f049d1:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f049d9:	movdqa xmm0,xmm2
    707120f049dd:	movdqa xmm1,xmm4
    707120f049e1:	pshufd xmm1,xmm1,0x44
    707120f049e6:	movq   rax,xmm0
    707120f049eb:	add    rax,rax
    707120f049ee:	je     0x707120f04a04
    707120f049f0:	shr    rax,0x35
    707120f049f4:	sub    eax,0x201
    707120f049f9:	cmp    eax,0x3fc
    707120f049fe:	ja     0x707120f07c8d
    707120f04a04:	movdqa xmm14,xmm0
    707120f04a09:	psrldq xmm14,0x8
    707120f04a0f:	movq   rax,xmm14
    707120f04a14:	add    rax,rax
    707120f04a17:	je     0x707120f04a2d
    707120f04a19:	shr    rax,0x35
    707120f04a1d:	sub    eax,0x201
    707120f04a22:	cmp    eax,0x3fc
    707120f04a27:	ja     0x707120f07c8d
    707120f04a2d:	movq   rax,xmm1
    707120f04a32:	add    rax,rax
    707120f04a35:	je     0x707120f04a4b
    707120f04a37:	shr    rax,0x35
    707120f04a3b:	sub    eax,0x201
    707120f04a40:	cmp    eax,0x3fc
    707120f04a45:	ja     0x707120f07c8d
    707120f04a4b:	movdqa xmm14,xmm1
    707120f04a50:	psrldq xmm14,0x8
    707120f04a56:	movq   rax,xmm14
    707120f04a5b:	add    rax,rax
    707120f04a5e:	je     0x707120f04a74
    707120f04a60:	shr    rax,0x35
    707120f04a64:	sub    eax,0x201
    707120f04a69:	cmp    eax,0x3fc
    707120f04a6e:	ja     0x707120f07c8d
    707120f04a74:	mulpd  xmm0,xmm1
    707120f04a78:	movdqa xmm5,xmm0
    707120f04a7c:	movdqa xmm0,xmm5
    707120f04a80:	movdqu XMMWORD PTR [r12+0x230],xmm0
    707120f04a8a:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    707120f04a94:	movdqa xmm2,xmm0
    707120f04a98:	movdqa xmm1,xmm2
    707120f04a9c:	por    xmm2,xmm1
    707120f04aa0:	movdqa xmm0,xmm2
    707120f04aa4:	movdqu XMMWORD PTR [r12+0x300],xmm0
    707120f04aae:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    707120f04ab8:	movdqa xmm2,xmm0
    707120f04abc:	movdqa xmm1,xmm2
    707120f04ac0:	por    xmm2,xmm1
    707120f04ac4:	movdqa xmm0,xmm2
    707120f04ac8:	movdqu XMMWORD PTR [r12+0x190],xmm0
    707120f04ad2:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f04adc:	movdqa xmm2,xmm0
    707120f04ae0:	movdqa xmm0,xmm2
    707120f04ae4:	movdqa xmm1,xmm3
    707120f04ae8:	pshufd xmm1,xmm1,0x44
    707120f04aed:	movq   rax,xmm0
    707120f04af2:	add    rax,rax
    707120f04af5:	je     0x707120f04b0b
    707120f04af7:	shr    rax,0x35
    707120f04afb:	sub    eax,0x201
    707120f04b00:	cmp    eax,0x3fc
    707120f04b05:	ja     0x707120f07cb1
    707120f04b0b:	movdqa xmm14,xmm0
    707120f04b10:	psrldq xmm14,0x8
    707120f04b16:	movq   rax,xmm14
    707120f04b1b:	add    rax,rax
    707120f04b1e:	je     0x707120f04b34
    707120f04b20:	shr    rax,0x35
    707120f04b24:	sub    eax,0x201
    707120f04b29:	cmp    eax,0x3fc
    707120f04b2e:	ja     0x707120f07cb1
    707120f04b34:	movq   rax,xmm1
    707120f04b39:	add    rax,rax
    707120f04b3c:	je     0x707120f04b52
    707120f04b3e:	shr    rax,0x35
    707120f04b42:	sub    eax,0x201
    707120f04b47:	cmp    eax,0x3fc
    707120f04b4c:	ja     0x707120f07cb1
    707120f04b52:	movdqa xmm14,xmm1
    707120f04b57:	psrldq xmm14,0x8
    707120f04b5d:	movq   rax,xmm14
    707120f04b62:	add    rax,rax
    707120f04b65:	je     0x707120f04b7b
    707120f04b67:	shr    rax,0x35
    707120f04b6b:	sub    eax,0x201
    707120f04b70:	cmp    eax,0x3fc
    707120f04b75:	ja     0x707120f07cb1
    707120f04b7b:	mulpd  xmm0,xmm1
    707120f04b7f:	movdqa xmm4,xmm0
    707120f04b83:	movdqa xmm0,xmm4
    707120f04b87:	movdqu XMMWORD PTR [r12+0x260],xmm0
    707120f04b91:	add    r13,0x90
    707120f04b98:	stmxcsr DWORD PTR [rsp+0x114]
    707120f04ba0:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f04ba8:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f04bb0:	shr    r11d,1
    707120f04bb3:	and    r11d,0x10
    707120f04bb7:	or     DWORD PTR [r12+0x314],r11d
    707120f04bbf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f04bc5:	movdqa xmm0,xmm2
    707120f04bc9:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f04bd3:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    707120f04bdd:	movdqa xmm3,xmm0
    707120f04be1:	movdqa xmm1,xmm3
    707120f04be5:	por    xmm3,xmm1
    707120f04be9:	movdqa xmm0,xmm3
    707120f04bed:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    707120f04bf7:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    707120f04c01:	movdqa xmm3,xmm0
    707120f04c05:	movdqa xmm1,xmm3
    707120f04c09:	por    xmm3,xmm1
    707120f04c0d:	movdqa xmm0,xmm3
    707120f04c11:	movdqu XMMWORD PTR [r12+0x200],xmm0
    707120f04c1b:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    707120f04c25:	movdqa xmm3,xmm0
    707120f04c29:	movdqa xmm1,xmm3
    707120f04c2d:	por    xmm3,xmm1
    707120f04c31:	movdqa xmm0,xmm3
    707120f04c35:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    707120f04c3f:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    707120f04c49:	movdqa xmm3,xmm0
    707120f04c4d:	movdqa xmm1,xmm3
    707120f04c51:	por    xmm3,xmm1
    707120f04c55:	movdqa xmm0,xmm3
    707120f04c59:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    707120f04c63:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    707120f04c6d:	movdqa xmm3,xmm0
    707120f04c71:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    707120f04c7b:	movdqa xmm4,xmm0
    707120f04c7f:	stmxcsr DWORD PTR [rsp+0x110]
    707120f04c87:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f04c92:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f04c9a:	movdqa xmm0,xmm3
    707120f04c9e:	movdqa xmm1,xmm4
    707120f04ca2:	movq   rax,xmm0
    707120f04ca7:	add    rax,rax
    707120f04caa:	je     0x707120f04cc0
    707120f04cac:	shr    rax,0x35
    707120f04cb0:	sub    eax,0x201
    707120f04cb5:	cmp    eax,0x3fc
    707120f04cba:	ja     0x707120f07cd5
    707120f04cc0:	movdqa xmm14,xmm0
    707120f04cc5:	psrldq xmm14,0x8
    707120f04ccb:	movq   rax,xmm14
    707120f04cd0:	add    rax,rax
    707120f04cd3:	je     0x707120f04ce9
    707120f04cd5:	shr    rax,0x35
    707120f04cd9:	sub    eax,0x201
    707120f04cde:	cmp    eax,0x3fc
    707120f04ce3:	ja     0x707120f07cd5
    707120f04ce9:	movq   rax,xmm1
    707120f04cee:	add    rax,rax
    707120f04cf1:	je     0x707120f04d07
    707120f04cf3:	shr    rax,0x35
    707120f04cf7:	sub    eax,0x201
    707120f04cfc:	cmp    eax,0x3fc
    707120f04d01:	ja     0x707120f07cd5
    707120f04d07:	movdqa xmm14,xmm1
    707120f04d0c:	psrldq xmm14,0x8
    707120f04d12:	movq   rax,xmm14
    707120f04d17:	add    rax,rax
    707120f04d1a:	je     0x707120f04d30
    707120f04d1c:	shr    rax,0x35
    707120f04d20:	sub    eax,0x201
    707120f04d25:	cmp    eax,0x3fc
    707120f04d2a:	ja     0x707120f07cd5
    707120f04d30:	addpd  xmm0,xmm1
    707120f04d34:	movdqa xmm5,xmm0
    707120f04d38:	movdqa xmm0,xmm5
    707120f04d3c:	movdqu XMMWORD PTR [r12+0x240],xmm0
    707120f04d46:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f04d50:	movdqa xmm3,xmm0
    707120f04d54:	movdqa xmm0,xmm2
    707120f04d58:	movdqa xmm1,xmm3
    707120f04d5c:	pshufd xmm1,xmm1,0x44
    707120f04d61:	movq   rax,xmm0
    707120f04d66:	add    rax,rax
    707120f04d69:	je     0x707120f04d7f
    707120f04d6b:	shr    rax,0x35
    707120f04d6f:	sub    eax,0x201
    707120f04d74:	cmp    eax,0x3fc
    707120f04d79:	ja     0x707120f07cf9
    707120f04d7f:	movdqa xmm14,xmm0
    707120f04d84:	psrldq xmm14,0x8
    707120f04d8a:	movq   rax,xmm14
    707120f04d8f:	add    rax,rax
    707120f04d92:	je     0x707120f04da8
    707120f04d94:	shr    rax,0x35
    707120f04d98:	sub    eax,0x201
    707120f04d9d:	cmp    eax,0x3fc
    707120f04da2:	ja     0x707120f07cf9
    707120f04da8:	movq   rax,xmm1
    707120f04dad:	add    rax,rax
    707120f04db0:	je     0x707120f04dc6
    707120f04db2:	shr    rax,0x35
    707120f04db6:	sub    eax,0x201
    707120f04dbb:	cmp    eax,0x3fc
    707120f04dc0:	ja     0x707120f07cf9
    707120f04dc6:	movdqa xmm14,xmm1
    707120f04dcb:	psrldq xmm14,0x8
    707120f04dd1:	movq   rax,xmm14
    707120f04dd6:	add    rax,rax
    707120f04dd9:	je     0x707120f04def
    707120f04ddb:	shr    rax,0x35
    707120f04ddf:	sub    eax,0x201
    707120f04de4:	cmp    eax,0x3fc
    707120f04de9:	ja     0x707120f07cf9
    707120f04def:	mulpd  xmm0,xmm1
    707120f04df3:	movdqa xmm4,xmm0
    707120f04df7:	movdqa xmm0,xmm4
    707120f04dfb:	movdqu XMMWORD PTR [r12+0x270],xmm0
    707120f04e05:	mov    r13,QWORD PTR [r12+0xf8]
    707120f04e0d:	add    r13,0x80
    707120f04e14:	stmxcsr DWORD PTR [rsp+0x114]
    707120f04e1c:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f04e24:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f04e2c:	shr    r11d,1
    707120f04e2f:	and    r11d,0x10
    707120f04e33:	or     DWORD PTR [r12+0x314],r11d
    707120f04e3b:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f04e41:	movdqa xmm0,xmm2
    707120f04e45:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f04e4f:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f04e59:	movdqa xmm3,xmm0
    707120f04e5d:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120f04e67:	movdqa xmm4,xmm0
    707120f04e6b:	stmxcsr DWORD PTR [rsp+0x110]
    707120f04e73:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f04e7e:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f04e86:	movdqa xmm0,xmm3
    707120f04e8a:	movdqa xmm1,xmm4
    707120f04e8e:	movq   rax,xmm0
    707120f04e93:	add    rax,rax
    707120f04e96:	je     0x707120f04eac
    707120f04e98:	shr    rax,0x35
    707120f04e9c:	sub    eax,0x201
    707120f04ea1:	cmp    eax,0x3fc
    707120f04ea6:	ja     0x707120f07d1d
    707120f04eac:	movdqa xmm14,xmm0
    707120f04eb1:	psrldq xmm14,0x8
    707120f04eb7:	movq   rax,xmm14
    707120f04ebc:	add    rax,rax
    707120f04ebf:	je     0x707120f04ed5
    707120f04ec1:	shr    rax,0x35
    707120f04ec5:	sub    eax,0x201
    707120f04eca:	cmp    eax,0x3fc
    707120f04ecf:	ja     0x707120f07d1d
    707120f04ed5:	movq   rax,xmm1
    707120f04eda:	add    rax,rax
    707120f04edd:	je     0x707120f04ef3
    707120f04edf:	shr    rax,0x35
    707120f04ee3:	sub    eax,0x201
    707120f04ee8:	cmp    eax,0x3fc
    707120f04eed:	ja     0x707120f07d1d
    707120f04ef3:	movdqa xmm14,xmm1
    707120f04ef8:	psrldq xmm14,0x8
    707120f04efe:	movq   rax,xmm14
    707120f04f03:	add    rax,rax
    707120f04f06:	je     0x707120f04f1c
    707120f04f08:	shr    rax,0x35
    707120f04f0c:	sub    eax,0x201
    707120f04f11:	cmp    eax,0x3fc
    707120f04f16:	ja     0x707120f07d1d
    707120f04f1c:	addpd  xmm0,xmm1
    707120f04f20:	movdqa xmm5,xmm0
    707120f04f24:	movdqa xmm0,xmm5
    707120f04f28:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f04f32:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f04f3c:	movdqa xmm3,xmm0
    707120f04f40:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    707120f04f4a:	movdqa xmm4,xmm0
    707120f04f4e:	movdqa xmm0,xmm3
    707120f04f52:	movdqa xmm1,xmm4
    707120f04f56:	movq   rax,xmm0
    707120f04f5b:	add    rax,rax
    707120f04f5e:	je     0x707120f04f74
    707120f04f60:	shr    rax,0x35
    707120f04f64:	sub    eax,0x201
    707120f04f69:	cmp    eax,0x3fc
    707120f04f6e:	ja     0x707120f07d41
    707120f04f74:	movdqa xmm14,xmm0
    707120f04f79:	psrldq xmm14,0x8
    707120f04f7f:	movq   rax,xmm14
    707120f04f84:	add    rax,rax
    707120f04f87:	je     0x707120f04f9d
    707120f04f89:	shr    rax,0x35
    707120f04f8d:	sub    eax,0x201
    707120f04f92:	cmp    eax,0x3fc
    707120f04f97:	ja     0x707120f07d41
    707120f04f9d:	movq   rax,xmm1
    707120f04fa2:	add    rax,rax
    707120f04fa5:	je     0x707120f04fbb
    707120f04fa7:	shr    rax,0x35
    707120f04fab:	sub    eax,0x201
    707120f04fb0:	cmp    eax,0x3fc
    707120f04fb5:	ja     0x707120f07d41
    707120f04fbb:	movdqa xmm14,xmm1
    707120f04fc0:	psrldq xmm14,0x8
    707120f04fc6:	movq   rax,xmm14
    707120f04fcb:	add    rax,rax
    707120f04fce:	je     0x707120f04fe4
    707120f04fd0:	shr    rax,0x35
    707120f04fd4:	sub    eax,0x201
    707120f04fd9:	cmp    eax,0x3fc
    707120f04fde:	ja     0x707120f07d41
    707120f04fe4:	addpd  xmm0,xmm1
    707120f04fe8:	movdqa xmm5,xmm0
    707120f04fec:	movdqa xmm0,xmm5
    707120f04ff0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f04ffa:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    707120f05004:	movdqa xmm3,xmm0
    707120f05008:	movdqa xmm1,xmm3
    707120f0500c:	por    xmm3,xmm1
    707120f05010:	movdqa xmm0,xmm3
    707120f05014:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    707120f0501e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f05028:	movdqa xmm3,xmm0
    707120f0502c:	movdqa xmm0,xmm2
    707120f05030:	movdqa xmm1,xmm3
    707120f05034:	pshufd xmm1,xmm1,0x44
    707120f05039:	movq   rax,xmm0
    707120f0503e:	add    rax,rax
    707120f05041:	je     0x707120f05057
    707120f05043:	shr    rax,0x35
    707120f05047:	sub    eax,0x201
    707120f0504c:	cmp    eax,0x3fc
    707120f05051:	ja     0x707120f07d65
    707120f05057:	movdqa xmm14,xmm0
    707120f0505c:	psrldq xmm14,0x8
    707120f05062:	movq   rax,xmm14
    707120f05067:	add    rax,rax
    707120f0506a:	je     0x707120f05080
    707120f0506c:	shr    rax,0x35
    707120f05070:	sub    eax,0x201
    707120f05075:	cmp    eax,0x3fc
    707120f0507a:	ja     0x707120f07d65
    707120f05080:	movq   rax,xmm1
    707120f05085:	add    rax,rax
    707120f05088:	je     0x707120f0509e
    707120f0508a:	shr    rax,0x35
    707120f0508e:	sub    eax,0x201
    707120f05093:	cmp    eax,0x3fc
    707120f05098:	ja     0x707120f07d65
    707120f0509e:	movdqa xmm14,xmm1
    707120f050a3:	psrldq xmm14,0x8
    707120f050a9:	movq   rax,xmm14
    707120f050ae:	add    rax,rax
    707120f050b1:	je     0x707120f050c7
    707120f050b3:	shr    rax,0x35
    707120f050b7:	sub    eax,0x201
    707120f050bc:	cmp    eax,0x3fc
    707120f050c1:	ja     0x707120f07d65
    707120f050c7:	mulpd  xmm0,xmm1
    707120f050cb:	movdqa xmm4,xmm0
    707120f050cf:	movdqa xmm0,xmm4
    707120f050d3:	movdqu XMMWORD PTR [r12+0x170],xmm0
    707120f050dd:	mov    r13,QWORD PTR [r12+0xf8]
    707120f050e5:	add    r13,0xd0
    707120f050ec:	stmxcsr DWORD PTR [rsp+0x114]
    707120f050f4:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f050fc:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f05104:	shr    r11d,1
    707120f05107:	and    r11d,0x10
    707120f0510b:	or     DWORD PTR [r12+0x314],r11d
    707120f05113:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f05119:	movdqa xmm0,xmm2
    707120f0511d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f05127:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f05131:	movdqa xmm3,xmm0
    707120f05135:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    707120f0513f:	movdqa xmm4,xmm0
    707120f05143:	stmxcsr DWORD PTR [rsp+0x110]
    707120f0514b:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f05156:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f0515e:	movdqa xmm0,xmm3
    707120f05162:	movdqa xmm1,xmm4
    707120f05166:	movq   rax,xmm0
    707120f0516b:	add    rax,rax
    707120f0516e:	je     0x707120f05184
    707120f05170:	shr    rax,0x35
    707120f05174:	sub    eax,0x201
    707120f05179:	cmp    eax,0x3fc
    707120f0517e:	ja     0x707120f07d89
    707120f05184:	movdqa xmm14,xmm0
    707120f05189:	psrldq xmm14,0x8
    707120f0518f:	movq   rax,xmm14
    707120f05194:	add    rax,rax
    707120f05197:	je     0x707120f051ad
    707120f05199:	shr    rax,0x35
    707120f0519d:	sub    eax,0x201
    707120f051a2:	cmp    eax,0x3fc
    707120f051a7:	ja     0x707120f07d89
    707120f051ad:	movq   rax,xmm1
    707120f051b2:	add    rax,rax
    707120f051b5:	je     0x707120f051cb
    707120f051b7:	shr    rax,0x35
    707120f051bb:	sub    eax,0x201
    707120f051c0:	cmp    eax,0x3fc
    707120f051c5:	ja     0x707120f07d89
    707120f051cb:	movdqa xmm14,xmm1
    707120f051d0:	psrldq xmm14,0x8
    707120f051d6:	movq   rax,xmm14
    707120f051db:	add    rax,rax
    707120f051de:	je     0x707120f051f4
    707120f051e0:	shr    rax,0x35
    707120f051e4:	sub    eax,0x201
    707120f051e9:	cmp    eax,0x3fc
    707120f051ee:	ja     0x707120f07d89
    707120f051f4:	addpd  xmm0,xmm1
    707120f051f8:	movdqa xmm5,xmm0
    707120f051fc:	movdqa xmm0,xmm5
    707120f05200:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f0520a:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    707120f05214:	movdqa xmm3,xmm0
    707120f05218:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f05222:	movdqa xmm4,xmm0
    707120f05226:	movdqa xmm0,xmm3
    707120f0522a:	movdqa xmm1,xmm4
    707120f0522e:	pshufd xmm1,xmm1,0x44
    707120f05233:	movq   rax,xmm0
    707120f05238:	add    rax,rax
    707120f0523b:	je     0x707120f05251
    707120f0523d:	shr    rax,0x35
    707120f05241:	sub    eax,0x201
    707120f05246:	cmp    eax,0x3fc
    707120f0524b:	ja     0x707120f07dad
    707120f05251:	movdqa xmm14,xmm0
    707120f05256:	psrldq xmm14,0x8
    707120f0525c:	movq   rax,xmm14
    707120f05261:	add    rax,rax
    707120f05264:	je     0x707120f0527a
    707120f05266:	shr    rax,0x35
    707120f0526a:	sub    eax,0x201
    707120f0526f:	cmp    eax,0x3fc
    707120f05274:	ja     0x707120f07dad
    707120f0527a:	movq   rax,xmm1
    707120f0527f:	add    rax,rax
    707120f05282:	je     0x707120f05298
    707120f05284:	shr    rax,0x35
    707120f05288:	sub    eax,0x201
    707120f0528d:	cmp    eax,0x3fc
    707120f05292:	ja     0x707120f07dad
    707120f05298:	movdqa xmm14,xmm1
    707120f0529d:	psrldq xmm14,0x8
    707120f052a3:	movq   rax,xmm14
    707120f052a8:	add    rax,rax
    707120f052ab:	je     0x707120f052c1
    707120f052ad:	shr    rax,0x35
    707120f052b1:	sub    eax,0x201
    707120f052b6:	cmp    eax,0x3fc
    707120f052bb:	ja     0x707120f07dad
    707120f052c1:	mulpd  xmm0,xmm1
    707120f052c5:	movdqa xmm5,xmm0
    707120f052c9:	movdqa xmm0,xmm5
    707120f052cd:	movdqu XMMWORD PTR [r12+0x260],xmm0
    707120f052d7:	mov    r13d,0x0
    707120f052dd:	mov    r14d,0x0
    707120f052e3:	mov    QWORD PTR [r12+0x1b0],r13
    707120f052eb:	mov    QWORD PTR [r12+0x1b8],r14
    707120f052f3:	movdqa xmm0,xmm2
    707120f052f7:	movdqa xmm1,xmm4
    707120f052fb:	pshufd xmm1,xmm1,0x44
    707120f05300:	movq   rax,xmm0
    707120f05305:	add    rax,rax
    707120f05308:	je     0x707120f0531e
    707120f0530a:	shr    rax,0x35
    707120f0530e:	sub    eax,0x201
    707120f05313:	cmp    eax,0x3fc
    707120f05318:	ja     0x707120f07dd1
    707120f0531e:	movdqa xmm14,xmm0
    707120f05323:	psrldq xmm14,0x8
    707120f05329:	movq   rax,xmm14
    707120f0532e:	add    rax,rax
    707120f05331:	je     0x707120f05347
    707120f05333:	shr    rax,0x35
    707120f05337:	sub    eax,0x201
    707120f0533c:	cmp    eax,0x3fc
    707120f05341:	ja     0x707120f07dd1
    707120f05347:	movq   rax,xmm1
    707120f0534c:	add    rax,rax
    707120f0534f:	je     0x707120f05365
    707120f05351:	shr    rax,0x35
    707120f05355:	sub    eax,0x201
    707120f0535a:	cmp    eax,0x3fc
    707120f0535f:	ja     0x707120f07dd1
    707120f05365:	movdqa xmm14,xmm1
    707120f0536a:	psrldq xmm14,0x8
    707120f05370:	movq   rax,xmm14
    707120f05375:	add    rax,rax
    707120f05378:	je     0x707120f0538e
    707120f0537a:	shr    rax,0x35
    707120f0537e:	sub    eax,0x201
    707120f05383:	cmp    eax,0x3fc
    707120f05388:	ja     0x707120f07dd1
    707120f0538e:	mulpd  xmm0,xmm1
    707120f05392:	movdqa xmm3,xmm0
    707120f05396:	movdqa xmm0,xmm3
    707120f0539a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    707120f053a4:	mov    r13,QWORD PTR [r12+0xf8]
    707120f053ac:	mov    r14,r13
    707120f053af:	add    r14,0xc0
    707120f053b6:	stmxcsr DWORD PTR [rsp+0x114]
    707120f053be:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f053c6:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f053ce:	shr    r11d,1
    707120f053d1:	and    r11d,0x10
    707120f053d5:	or     DWORD PTR [r12+0x314],r11d
    707120f053dd:	movdqu xmm2,XMMWORD PTR [r14]
    707120f053e2:	movdqa xmm0,xmm2
    707120f053e6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f053f0:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    707120f053fa:	movdqa xmm3,xmm0
    707120f053fe:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    707120f05408:	movdqa xmm4,xmm0
    707120f0540c:	stmxcsr DWORD PTR [rsp+0x110]
    707120f05414:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f0541f:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f05427:	movdqa xmm0,xmm3
    707120f0542b:	movdqa xmm1,xmm4
    707120f0542f:	movq   rax,xmm0
    707120f05434:	add    rax,rax
    707120f05437:	je     0x707120f0544d
    707120f05439:	shr    rax,0x35
    707120f0543d:	sub    eax,0x201
    707120f05442:	cmp    eax,0x3fc
    707120f05447:	ja     0x707120f07df5
    707120f0544d:	movdqa xmm14,xmm0
    707120f05452:	psrldq xmm14,0x8
    707120f05458:	movq   rax,xmm14
    707120f0545d:	add    rax,rax
    707120f05460:	je     0x707120f05476
    707120f05462:	shr    rax,0x35
    707120f05466:	sub    eax,0x201
    707120f0546b:	cmp    eax,0x3fc
    707120f05470:	ja     0x707120f07df5
    707120f05476:	movq   rax,xmm1
    707120f0547b:	add    rax,rax
    707120f0547e:	je     0x707120f05494
    707120f05480:	shr    rax,0x35
    707120f05484:	sub    eax,0x201
    707120f05489:	cmp    eax,0x3fc
    707120f0548e:	ja     0x707120f07df5
    707120f05494:	movdqa xmm14,xmm1
    707120f05499:	psrldq xmm14,0x8
    707120f0549f:	movq   rax,xmm14
    707120f054a4:	add    rax,rax
    707120f054a7:	je     0x707120f054bd
    707120f054a9:	shr    rax,0x35
    707120f054ad:	sub    eax,0x201
    707120f054b2:	cmp    eax,0x3fc
    707120f054b7:	ja     0x707120f07df5
    707120f054bd:	addpd  xmm0,xmm1
    707120f054c1:	movdqa xmm5,xmm0
    707120f054c5:	movdqa xmm0,xmm5
    707120f054c9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    707120f054d3:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    707120f054dd:	movdqa xmm3,xmm0
    707120f054e1:	movdqa xmm1,xmm3
    707120f054e5:	por    xmm3,xmm1
    707120f054e9:	movdqa xmm0,xmm3
    707120f054ed:	movdqu XMMWORD PTR [r12+0x270],xmm0
    707120f054f7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f05501:	movdqa xmm3,xmm0
    707120f05505:	movdqa xmm1,xmm3
    707120f05509:	por    xmm3,xmm1
    707120f0550d:	movdqa xmm0,xmm3
    707120f05511:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    707120f0551b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f05525:	movdqa xmm3,xmm0
    707120f05529:	movdqa xmm0,xmm2
    707120f0552d:	movdqa xmm1,xmm3
    707120f05531:	pshufd xmm1,xmm1,0x44
    707120f05536:	movq   rax,xmm0
    707120f0553b:	add    rax,rax
    707120f0553e:	je     0x707120f05554
    707120f05540:	shr    rax,0x35
    707120f05544:	sub    eax,0x201
    707120f05549:	cmp    eax,0x3fc
    707120f0554e:	ja     0x707120f07e19
    707120f05554:	movdqa xmm14,xmm0
    707120f05559:	psrldq xmm14,0x8
    707120f0555f:	movq   rax,xmm14
    707120f05564:	add    rax,rax
    707120f05567:	je     0x707120f0557d
    707120f05569:	shr    rax,0x35
    707120f0556d:	sub    eax,0x201
    707120f05572:	cmp    eax,0x3fc
    707120f05577:	ja     0x707120f07e19
    707120f0557d:	movq   rax,xmm1
    707120f05582:	add    rax,rax
    707120f05585:	je     0x707120f0559b
    707120f05587:	shr    rax,0x35
    707120f0558b:	sub    eax,0x201
    707120f05590:	cmp    eax,0x3fc
    707120f05595:	ja     0x707120f07e19
    707120f0559b:	movdqa xmm14,xmm1
    707120f055a0:	psrldq xmm14,0x8
    707120f055a6:	movq   rax,xmm14
    707120f055ab:	add    rax,rax
    707120f055ae:	je     0x707120f055c4
    707120f055b0:	shr    rax,0x35
    707120f055b4:	sub    eax,0x201
    707120f055b9:	cmp    eax,0x3fc
    707120f055be:	ja     0x707120f07e19
    707120f055c4:	mulpd  xmm0,xmm1
    707120f055c8:	movdqa xmm4,xmm0
    707120f055cc:	movdqa xmm0,xmm4
    707120f055d0:	movdqu XMMWORD PTR [r12+0x250],xmm0
    707120f055da:	add    r13,0x20
    707120f055de:	stmxcsr DWORD PTR [rsp+0x114]
    707120f055e6:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f055ee:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f055f6:	shr    r11d,1
    707120f055f9:	and    r11d,0x10
    707120f055fd:	or     DWORD PTR [r12+0x314],r11d
    707120f05605:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f0560b:	movdqa xmm0,xmm2
    707120f0560f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f05619:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f05623:	movdqa xmm2,xmm0
    707120f05627:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f05631:	movdqa xmm4,xmm0
    707120f05635:	stmxcsr DWORD PTR [rsp+0x110]
    707120f0563d:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f05648:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f05650:	movdqa xmm0,xmm2
    707120f05654:	movdqa xmm1,xmm4
    707120f05658:	movq   rax,xmm0
    707120f0565d:	add    rax,rax
    707120f05660:	je     0x707120f05676
    707120f05662:	shr    rax,0x35
    707120f05666:	sub    eax,0x201
    707120f0566b:	cmp    eax,0x3fc
    707120f05670:	ja     0x707120f07e3d
    707120f05676:	movdqa xmm14,xmm0
    707120f0567b:	psrldq xmm14,0x8
    707120f05681:	movq   rax,xmm14
    707120f05686:	add    rax,rax
    707120f05689:	je     0x707120f0569f
    707120f0568b:	shr    rax,0x35
    707120f0568f:	sub    eax,0x201
    707120f05694:	cmp    eax,0x3fc
    707120f05699:	ja     0x707120f07e3d
    707120f0569f:	movq   rax,xmm1
    707120f056a4:	add    rax,rax
    707120f056a7:	je     0x707120f056bd
    707120f056a9:	shr    rax,0x35
    707120f056ad:	sub    eax,0x201
    707120f056b2:	cmp    eax,0x3fc
    707120f056b7:	ja     0x707120f07e3d
    707120f056bd:	movdqa xmm14,xmm1
    707120f056c2:	psrldq xmm14,0x8
    707120f056c8:	movq   rax,xmm14
    707120f056cd:	add    rax,rax
    707120f056d0:	je     0x707120f056e6
    707120f056d2:	shr    rax,0x35
    707120f056d6:	sub    eax,0x201
    707120f056db:	cmp    eax,0x3fc
    707120f056e0:	ja     0x707120f07e3d
    707120f056e6:	addpd  xmm0,xmm1
    707120f056ea:	movdqa xmm5,xmm0
    707120f056ee:	movdqa xmm0,xmm5
    707120f056f2:	movdqu XMMWORD PTR [r12+0x170],xmm0
    707120f056fc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    707120f05706:	movdqa xmm2,xmm0
    707120f0570a:	movdqa xmm0,xmm2
    707120f0570e:	movdqa xmm1,xmm3
    707120f05712:	pshufd xmm1,xmm1,0x44
    707120f05717:	movq   rax,xmm0
    707120f0571c:	add    rax,rax
    707120f0571f:	je     0x707120f05735
    707120f05721:	shr    rax,0x35
    707120f05725:	sub    eax,0x201
    707120f0572a:	cmp    eax,0x3fc
    707120f0572f:	ja     0x707120f07e61
    707120f05735:	movdqa xmm14,xmm0
    707120f0573a:	psrldq xmm14,0x8
    707120f05740:	movq   rax,xmm14
    707120f05745:	add    rax,rax
    707120f05748:	je     0x707120f0575e
    707120f0574a:	shr    rax,0x35
    707120f0574e:	sub    eax,0x201
    707120f05753:	cmp    eax,0x3fc
    707120f05758:	ja     0x707120f07e61
    707120f0575e:	movq   rax,xmm1
    707120f05763:	add    rax,rax
    707120f05766:	je     0x707120f0577c
    707120f05768:	shr    rax,0x35
    707120f0576c:	sub    eax,0x201
    707120f05771:	cmp    eax,0x3fc
    707120f05776:	ja     0x707120f07e61
    707120f0577c:	movdqa xmm14,xmm1
    707120f05781:	psrldq xmm14,0x8
    707120f05787:	movq   rax,xmm14
    707120f0578c:	add    rax,rax
    707120f0578f:	je     0x707120f057a5
    707120f05791:	shr    rax,0x35
    707120f05795:	sub    eax,0x201
    707120f0579a:	cmp    eax,0x3fc
    707120f0579f:	ja     0x707120f07e61
    707120f057a5:	mulpd  xmm0,xmm1
    707120f057a9:	movdqa xmm4,xmm0
    707120f057ad:	movdqa xmm0,xmm4
    707120f057b1:	movdqu XMMWORD PTR [r12+0x160],xmm0
    707120f057bb:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f057c5:	movdqa xmm2,xmm0
    707120f057c9:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120f057d3:	movdqa xmm3,xmm0
    707120f057d7:	movdqa xmm0,xmm2
    707120f057db:	movdqa xmm1,xmm3
    707120f057df:	movq   rax,xmm0
    707120f057e4:	add    rax,rax
    707120f057e7:	je     0x707120f057fd
    707120f057e9:	shr    rax,0x35
    707120f057ed:	sub    eax,0x201
    707120f057f2:	cmp    eax,0x3fc
    707120f057f7:	ja     0x707120f07e85
    707120f057fd:	movdqa xmm14,xmm0
    707120f05802:	psrldq xmm14,0x8
    707120f05808:	movq   rax,xmm14
    707120f0580d:	add    rax,rax
    707120f05810:	je     0x707120f05826
    707120f05812:	shr    rax,0x35
    707120f05816:	sub    eax,0x201
    707120f0581b:	cmp    eax,0x3fc
    707120f05820:	ja     0x707120f07e85
    707120f05826:	movq   rax,xmm1
    707120f0582b:	add    rax,rax
    707120f0582e:	je     0x707120f05844
    707120f05830:	shr    rax,0x35
    707120f05834:	sub    eax,0x201
    707120f05839:	cmp    eax,0x3fc
    707120f0583e:	ja     0x707120f07e85
    707120f05844:	movdqa xmm14,xmm1
    707120f05849:	psrldq xmm14,0x8
    707120f0584f:	movq   rax,xmm14
    707120f05854:	add    rax,rax
    707120f05857:	je     0x707120f0586d
    707120f05859:	shr    rax,0x35
    707120f0585d:	sub    eax,0x201
    707120f05862:	cmp    eax,0x3fc
    707120f05867:	ja     0x707120f07e85
    707120f0586d:	addpd  xmm0,xmm1
    707120f05871:	movdqa xmm4,xmm0
    707120f05875:	movdqa xmm0,xmm4
    707120f05879:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f05883:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f0588d:	movdqa xmm2,xmm0
    707120f05891:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120f0589b:	movdqa xmm3,xmm0
    707120f0589f:	movdqa xmm0,xmm2
    707120f058a3:	movdqa xmm1,xmm3
    707120f058a7:	pshufd xmm1,xmm1,0x44
    707120f058ac:	movq   rax,xmm0
    707120f058b1:	add    rax,rax
    707120f058b4:	je     0x707120f058ca
    707120f058b6:	shr    rax,0x35
    707120f058ba:	sub    eax,0x201
    707120f058bf:	cmp    eax,0x3fc
    707120f058c4:	ja     0x707120f07ea9
    707120f058ca:	movdqa xmm14,xmm0
    707120f058cf:	psrldq xmm14,0x8
    707120f058d5:	movq   rax,xmm14
    707120f058da:	add    rax,rax
    707120f058dd:	je     0x707120f058f3
    707120f058df:	shr    rax,0x35
    707120f058e3:	sub    eax,0x201
    707120f058e8:	cmp    eax,0x3fc
    707120f058ed:	ja     0x707120f07ea9
    707120f058f3:	movq   rax,xmm1
    707120f058f8:	add    rax,rax
    707120f058fb:	je     0x707120f05911
    707120f058fd:	shr    rax,0x35
    707120f05901:	sub    eax,0x201
    707120f05906:	cmp    eax,0x3fc
    707120f0590b:	ja     0x707120f07ea9
    707120f05911:	movdqa xmm14,xmm1
    707120f05916:	psrldq xmm14,0x8
    707120f0591c:	movq   rax,xmm14
    707120f05921:	add    rax,rax
    707120f05924:	je     0x707120f0593a
    707120f05926:	shr    rax,0x35
    707120f0592a:	sub    eax,0x201
    707120f0592f:	cmp    eax,0x3fc
    707120f05934:	ja     0x707120f07ea9
    707120f0593a:	mulpd  xmm0,xmm1
    707120f0593e:	movdqa xmm4,xmm0
    707120f05942:	movdqa xmm0,xmm4
    707120f05946:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f05950:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    707120f0595a:	movdqa xmm2,xmm0
    707120f0595e:	movdqa xmm0,xmm2
    707120f05962:	movdqa xmm1,xmm3
    707120f05966:	pshufd xmm1,xmm1,0x44
    707120f0596b:	movq   rax,xmm0
    707120f05970:	add    rax,rax
    707120f05973:	je     0x707120f05989
    707120f05975:	shr    rax,0x35
    707120f05979:	sub    eax,0x201
    707120f0597e:	cmp    eax,0x3fc
    707120f05983:	ja     0x707120f07ecd
    707120f05989:	movdqa xmm14,xmm0
    707120f0598e:	psrldq xmm14,0x8
    707120f05994:	movq   rax,xmm14
    707120f05999:	add    rax,rax
    707120f0599c:	je     0x707120f059b2
    707120f0599e:	shr    rax,0x35
    707120f059a2:	sub    eax,0x201
    707120f059a7:	cmp    eax,0x3fc
    707120f059ac:	ja     0x707120f07ecd
    707120f059b2:	movq   rax,xmm1
    707120f059b7:	add    rax,rax
    707120f059ba:	je     0x707120f059d0
    707120f059bc:	shr    rax,0x35
    707120f059c0:	sub    eax,0x201
    707120f059c5:	cmp    eax,0x3fc
    707120f059ca:	ja     0x707120f07ecd
    707120f059d0:	movdqa xmm14,xmm1
    707120f059d5:	psrldq xmm14,0x8
    707120f059db:	movq   rax,xmm14
    707120f059e0:	add    rax,rax
    707120f059e3:	je     0x707120f059f9
    707120f059e5:	shr    rax,0x35
    707120f059e9:	sub    eax,0x201
    707120f059ee:	cmp    eax,0x3fc
    707120f059f3:	ja     0x707120f07ecd
    707120f059f9:	mulpd  xmm0,xmm1
    707120f059fd:	movdqa xmm4,xmm0
    707120f05a01:	movdqa xmm0,xmm4
    707120f05a05:	movdqu XMMWORD PTR [r12+0x230],xmm0
    707120f05a0f:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    707120f05a19:	movdqa xmm2,xmm0
    707120f05a1d:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    707120f05a27:	movdqa xmm4,xmm0
    707120f05a2b:	movdqa xmm0,xmm2
    707120f05a2f:	movdqa xmm1,xmm4
    707120f05a33:	movq   rax,xmm0
    707120f05a38:	add    rax,rax
    707120f05a3b:	je     0x707120f05a51
    707120f05a3d:	shr    rax,0x35
    707120f05a41:	sub    eax,0x201
    707120f05a46:	cmp    eax,0x3fc
    707120f05a4b:	ja     0x707120f07ef1
    707120f05a51:	movdqa xmm14,xmm0
    707120f05a56:	psrldq xmm14,0x8
    707120f05a5c:	movq   rax,xmm14
    707120f05a61:	add    rax,rax
    707120f05a64:	je     0x707120f05a7a
    707120f05a66:	shr    rax,0x35
    707120f05a6a:	sub    eax,0x201
    707120f05a6f:	cmp    eax,0x3fc
    707120f05a74:	ja     0x707120f07ef1
    707120f05a7a:	movq   rax,xmm1
    707120f05a7f:	add    rax,rax
    707120f05a82:	je     0x707120f05a98
    707120f05a84:	shr    rax,0x35
    707120f05a88:	sub    eax,0x201
    707120f05a8d:	cmp    eax,0x3fc
    707120f05a92:	ja     0x707120f07ef1
    707120f05a98:	movdqa xmm14,xmm1
    707120f05a9d:	psrldq xmm14,0x8
    707120f05aa3:	movq   rax,xmm14
    707120f05aa8:	add    rax,rax
    707120f05aab:	je     0x707120f05ac1
    707120f05aad:	shr    rax,0x35
    707120f05ab1:	sub    eax,0x201
    707120f05ab6:	cmp    eax,0x3fc
    707120f05abb:	ja     0x707120f07ef1
    707120f05ac1:	addpd  xmm0,xmm1
    707120f05ac5:	movdqa xmm5,xmm0
    707120f05ac9:	movdqa xmm0,xmm5
    707120f05acd:	movdqu XMMWORD PTR [r12+0x240],xmm0
    707120f05ad7:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f05ae1:	movdqa xmm2,xmm0
    707120f05ae5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    707120f05aef:	movdqa xmm4,xmm0
    707120f05af3:	movdqa xmm0,xmm2
    707120f05af7:	movdqa xmm1,xmm4
    707120f05afb:	movq   rax,xmm0
    707120f05b00:	add    rax,rax
    707120f05b03:	je     0x707120f05b19
    707120f05b05:	shr    rax,0x35
    707120f05b09:	sub    eax,0x201
    707120f05b0e:	cmp    eax,0x3fc
    707120f05b13:	ja     0x707120f07f15
    707120f05b19:	movdqa xmm14,xmm0
    707120f05b1e:	psrldq xmm14,0x8
    707120f05b24:	movq   rax,xmm14
    707120f05b29:	add    rax,rax
    707120f05b2c:	je     0x707120f05b42
    707120f05b2e:	shr    rax,0x35
    707120f05b32:	sub    eax,0x201
    707120f05b37:	cmp    eax,0x3fc
    707120f05b3c:	ja     0x707120f07f15
    707120f05b42:	movq   rax,xmm1
    707120f05b47:	add    rax,rax
    707120f05b4a:	je     0x707120f05b60
    707120f05b4c:	shr    rax,0x35
    707120f05b50:	sub    eax,0x201
    707120f05b55:	cmp    eax,0x3fc
    707120f05b5a:	ja     0x707120f07f15
    707120f05b60:	movdqa xmm14,xmm1
    707120f05b65:	psrldq xmm14,0x8
    707120f05b6b:	movq   rax,xmm14
    707120f05b70:	add    rax,rax
    707120f05b73:	je     0x707120f05b89
    707120f05b75:	shr    rax,0x35
    707120f05b79:	sub    eax,0x201
    707120f05b7e:	cmp    eax,0x3fc
    707120f05b83:	ja     0x707120f07f15
    707120f05b89:	addpd  xmm0,xmm1
    707120f05b8d:	movdqa xmm5,xmm0
    707120f05b91:	movdqa xmm0,xmm5
    707120f05b95:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f05b9f:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    707120f05ba9:	movdqa xmm2,xmm0
    707120f05bad:	movdqa xmm0,xmm2
    707120f05bb1:	movdqa xmm1,xmm3
    707120f05bb5:	pshufd xmm1,xmm1,0x44
    707120f05bba:	movq   rax,xmm0
    707120f05bbf:	add    rax,rax
    707120f05bc2:	je     0x707120f05bd8
    707120f05bc4:	shr    rax,0x35
    707120f05bc8:	sub    eax,0x201
    707120f05bcd:	cmp    eax,0x3fc
    707120f05bd2:	ja     0x707120f07f39
    707120f05bd8:	movdqa xmm14,xmm0
    707120f05bdd:	psrldq xmm14,0x8
    707120f05be3:	movq   rax,xmm14
    707120f05be8:	add    rax,rax
    707120f05beb:	je     0x707120f05c01
    707120f05bed:	shr    rax,0x35
    707120f05bf1:	sub    eax,0x201
    707120f05bf6:	cmp    eax,0x3fc
    707120f05bfb:	ja     0x707120f07f39
    707120f05c01:	movq   rax,xmm1
    707120f05c06:	add    rax,rax
    707120f05c09:	je     0x707120f05c1f
    707120f05c0b:	shr    rax,0x35
    707120f05c0f:	sub    eax,0x201
    707120f05c14:	cmp    eax,0x3fc
    707120f05c19:	ja     0x707120f07f39
    707120f05c1f:	movdqa xmm14,xmm1
    707120f05c24:	psrldq xmm14,0x8
    707120f05c2a:	movq   rax,xmm14
    707120f05c2f:	add    rax,rax
    707120f05c32:	je     0x707120f05c48
    707120f05c34:	shr    rax,0x35
    707120f05c38:	sub    eax,0x201
    707120f05c3d:	cmp    eax,0x3fc
    707120f05c42:	ja     0x707120f07f39
    707120f05c48:	mulpd  xmm0,xmm1
    707120f05c4c:	movdqa xmm4,xmm0
    707120f05c50:	movdqa xmm0,xmm4
    707120f05c54:	movdqu XMMWORD PTR [r12+0x250],xmm0
    707120f05c5e:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    707120f05c68:	movdqa xmm2,xmm0
    707120f05c6c:	movdqa xmm0,xmm2
    707120f05c70:	movdqa xmm1,xmm3
    707120f05c74:	pshufd xmm1,xmm1,0x44
    707120f05c79:	movq   rax,xmm0
    707120f05c7e:	add    rax,rax
    707120f05c81:	je     0x707120f05c97
    707120f05c83:	shr    rax,0x35
    707120f05c87:	sub    eax,0x201
    707120f05c8c:	cmp    eax,0x3fc
    707120f05c91:	ja     0x707120f07f5d
    707120f05c97:	movdqa xmm14,xmm0
    707120f05c9c:	psrldq xmm14,0x8
    707120f05ca2:	movq   rax,xmm14
    707120f05ca7:	add    rax,rax
    707120f05caa:	je     0x707120f05cc0
    707120f05cac:	shr    rax,0x35
    707120f05cb0:	sub    eax,0x201
    707120f05cb5:	cmp    eax,0x3fc
    707120f05cba:	ja     0x707120f07f5d
    707120f05cc0:	movq   rax,xmm1
    707120f05cc5:	add    rax,rax
    707120f05cc8:	je     0x707120f05cde
    707120f05cca:	shr    rax,0x35
    707120f05cce:	sub    eax,0x201
    707120f05cd3:	cmp    eax,0x3fc
    707120f05cd8:	ja     0x707120f07f5d
    707120f05cde:	movdqa xmm14,xmm1
    707120f05ce3:	psrldq xmm14,0x8
    707120f05ce9:	movq   rax,xmm14
    707120f05cee:	add    rax,rax
    707120f05cf1:	je     0x707120f05d07
    707120f05cf3:	shr    rax,0x35
    707120f05cf7:	sub    eax,0x201
    707120f05cfc:	cmp    eax,0x3fc
    707120f05d01:	ja     0x707120f07f5d
    707120f05d07:	mulpd  xmm0,xmm1
    707120f05d0b:	movdqa xmm4,xmm0
    707120f05d0f:	movdqa xmm0,xmm4
    707120f05d13:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120f05d1d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f05d27:	movdqa xmm2,xmm0
    707120f05d2b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f05d35:	movdqa xmm3,xmm0
    707120f05d39:	movdqa xmm0,xmm2
    707120f05d3d:	movdqa xmm1,xmm3
    707120f05d41:	movq   rax,xmm0
    707120f05d46:	add    rax,rax
    707120f05d49:	je     0x707120f05d5f
    707120f05d4b:	shr    rax,0x35
    707120f05d4f:	sub    eax,0x201
    707120f05d54:	cmp    eax,0x3fc
    707120f05d59:	ja     0x707120f07f81
    707120f05d5f:	movdqa xmm14,xmm0
    707120f05d64:	psrldq xmm14,0x8
    707120f05d6a:	movq   rax,xmm14
    707120f05d6f:	add    rax,rax
    707120f05d72:	je     0x707120f05d88
    707120f05d74:	shr    rax,0x35
    707120f05d78:	sub    eax,0x201
    707120f05d7d:	cmp    eax,0x3fc
    707120f05d82:	ja     0x707120f07f81
    707120f05d88:	movq   rax,xmm1
    707120f05d8d:	add    rax,rax
    707120f05d90:	je     0x707120f05da6
    707120f05d92:	shr    rax,0x35
    707120f05d96:	sub    eax,0x201
    707120f05d9b:	cmp    eax,0x3fc
    707120f05da0:	ja     0x707120f07f81
    707120f05da6:	movdqa xmm14,xmm1
    707120f05dab:	psrldq xmm14,0x8
    707120f05db1:	movq   rax,xmm14
    707120f05db6:	add    rax,rax
    707120f05db9:	je     0x707120f05dcf
    707120f05dbb:	shr    rax,0x35
    707120f05dbf:	sub    eax,0x201
    707120f05dc4:	cmp    eax,0x3fc
    707120f05dc9:	ja     0x707120f07f81
    707120f05dcf:	addpd  xmm0,xmm1
    707120f05dd3:	movdqa xmm4,xmm0
    707120f05dd7:	movdqa xmm0,xmm4
    707120f05ddb:	movdqu XMMWORD PTR [r12+0x160],xmm0
    707120f05de5:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f05def:	movdqa xmm2,xmm0
    707120f05df3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f05dfd:	movdqa xmm3,xmm0
    707120f05e01:	movdqa xmm0,xmm2
    707120f05e05:	movdqa xmm1,xmm3
    707120f05e09:	movq   rax,xmm0
    707120f05e0e:	add    rax,rax
    707120f05e11:	je     0x707120f05e27
    707120f05e13:	shr    rax,0x35
    707120f05e17:	sub    eax,0x201
    707120f05e1c:	cmp    eax,0x3fc
    707120f05e21:	ja     0x707120f07fa5
    707120f05e27:	movdqa xmm14,xmm0
    707120f05e2c:	psrldq xmm14,0x8
    707120f05e32:	movq   rax,xmm14
    707120f05e37:	add    rax,rax
    707120f05e3a:	je     0x707120f05e50
    707120f05e3c:	shr    rax,0x35
    707120f05e40:	sub    eax,0x201
    707120f05e45:	cmp    eax,0x3fc
    707120f05e4a:	ja     0x707120f07fa5
    707120f05e50:	movq   rax,xmm1
    707120f05e55:	add    rax,rax
    707120f05e58:	je     0x707120f05e6e
    707120f05e5a:	shr    rax,0x35
    707120f05e5e:	sub    eax,0x201
    707120f05e63:	cmp    eax,0x3fc
    707120f05e68:	ja     0x707120f07fa5
    707120f05e6e:	movdqa xmm14,xmm1
    707120f05e73:	psrldq xmm14,0x8
    707120f05e79:	movq   rax,xmm14
    707120f05e7e:	add    rax,rax
    707120f05e81:	je     0x707120f05e97
    707120f05e83:	shr    rax,0x35
    707120f05e87:	sub    eax,0x201
    707120f05e8c:	cmp    eax,0x3fc
    707120f05e91:	ja     0x707120f07fa5
    707120f05e97:	addpd  xmm0,xmm1
    707120f05e9b:	movdqa xmm4,xmm0
    707120f05e9f:	movdqa xmm0,xmm4
    707120f05ea3:	movdqu XMMWORD PTR [r12+0x170],xmm0
    707120f05ead:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    707120f05eb7:	movdqa xmm2,xmm0
    707120f05ebb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120f05ec5:	movdqa xmm3,xmm0
    707120f05ec9:	movdqa xmm0,xmm2
    707120f05ecd:	movdqa xmm1,xmm3
    707120f05ed1:	pshufd xmm1,xmm1,0x44
    707120f05ed6:	movq   rax,xmm0
    707120f05edb:	add    rax,rax
    707120f05ede:	je     0x707120f05ef4
    707120f05ee0:	shr    rax,0x35
    707120f05ee4:	sub    eax,0x201
    707120f05ee9:	cmp    eax,0x3fc
    707120f05eee:	ja     0x707120f07fc9
    707120f05ef4:	movdqa xmm14,xmm0
    707120f05ef9:	psrldq xmm14,0x8
    707120f05eff:	movq   rax,xmm14
    707120f05f04:	add    rax,rax
    707120f05f07:	je     0x707120f05f1d
    707120f05f09:	shr    rax,0x35
    707120f05f0d:	sub    eax,0x201
    707120f05f12:	cmp    eax,0x3fc
    707120f05f17:	ja     0x707120f07fc9
    707120f05f1d:	movq   rax,xmm1
    707120f05f22:	add    rax,rax
    707120f05f25:	je     0x707120f05f3b
    707120f05f27:	shr    rax,0x35
    707120f05f2b:	sub    eax,0x201
    707120f05f30:	cmp    eax,0x3fc
    707120f05f35:	ja     0x707120f07fc9
    707120f05f3b:	movdqa xmm14,xmm1
    707120f05f40:	psrldq xmm14,0x8
    707120f05f46:	movq   rax,xmm14
    707120f05f4b:	add    rax,rax
    707120f05f4e:	je     0x707120f05f64
    707120f05f50:	shr    rax,0x35
    707120f05f54:	sub    eax,0x201
    707120f05f59:	cmp    eax,0x3fc
    707120f05f5e:	ja     0x707120f07fc9
    707120f05f64:	mulpd  xmm0,xmm1
    707120f05f68:	movdqa xmm4,xmm0
    707120f05f6c:	movdqa xmm0,xmm4
    707120f05f70:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f05f7a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f05f84:	movdqa xmm2,xmm0
    707120f05f88:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120f05f92:	movdqa xmm3,xmm0
    707120f05f96:	movdqa xmm0,xmm2
    707120f05f9a:	movdqa xmm1,xmm3
    707120f05f9e:	movq   rax,xmm0
    707120f05fa3:	add    rax,rax
    707120f05fa6:	je     0x707120f05fbc
    707120f05fa8:	shr    rax,0x35
    707120f05fac:	sub    eax,0x201
    707120f05fb1:	cmp    eax,0x3fc
    707120f05fb6:	ja     0x707120f07fed
    707120f05fbc:	movdqa xmm14,xmm0
    707120f05fc1:	psrldq xmm14,0x8
    707120f05fc7:	movq   rax,xmm14
    707120f05fcc:	add    rax,rax
    707120f05fcf:	je     0x707120f05fe5
    707120f05fd1:	shr    rax,0x35
    707120f05fd5:	sub    eax,0x201
    707120f05fda:	cmp    eax,0x3fc
    707120f05fdf:	ja     0x707120f07fed
    707120f05fe5:	movq   rax,xmm1
    707120f05fea:	add    rax,rax
    707120f05fed:	je     0x707120f06003
    707120f05fef:	shr    rax,0x35
    707120f05ff3:	sub    eax,0x201
    707120f05ff8:	cmp    eax,0x3fc
    707120f05ffd:	ja     0x707120f07fed
    707120f06003:	movdqa xmm14,xmm1
    707120f06008:	psrldq xmm14,0x8
    707120f0600e:	movq   rax,xmm14
    707120f06013:	add    rax,rax
    707120f06016:	je     0x707120f0602c
    707120f06018:	shr    rax,0x35
    707120f0601c:	sub    eax,0x201
    707120f06021:	cmp    eax,0x3fc
    707120f06026:	ja     0x707120f07fed
    707120f0602c:	addpd  xmm0,xmm1
    707120f06030:	movdqa xmm4,xmm0
    707120f06034:	movdqa xmm0,xmm4
    707120f06038:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f06042:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    707120f0604c:	movdqa xmm2,xmm0
    707120f06050:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    707120f0605a:	movdqa xmm3,xmm0
    707120f0605e:	movdqa xmm0,xmm2
    707120f06062:	movdqa xmm1,xmm3
    707120f06066:	movq   rax,xmm0
    707120f0606b:	add    rax,rax
    707120f0606e:	je     0x707120f06084
    707120f06070:	shr    rax,0x35
    707120f06074:	sub    eax,0x201
    707120f06079:	cmp    eax,0x3fc
    707120f0607e:	ja     0x707120f08011
    707120f06084:	movdqa xmm14,xmm0
    707120f06089:	psrldq xmm14,0x8
    707120f0608f:	movq   rax,xmm14
    707120f06094:	add    rax,rax
    707120f06097:	je     0x707120f060ad
    707120f06099:	shr    rax,0x35
    707120f0609d:	sub    eax,0x201
    707120f060a2:	cmp    eax,0x3fc
    707120f060a7:	ja     0x707120f08011
    707120f060ad:	movq   rax,xmm1
    707120f060b2:	add    rax,rax
    707120f060b5:	je     0x707120f060cb
    707120f060b7:	shr    rax,0x35
    707120f060bb:	sub    eax,0x201
    707120f060c0:	cmp    eax,0x3fc
    707120f060c5:	ja     0x707120f08011
    707120f060cb:	movdqa xmm14,xmm1
    707120f060d0:	psrldq xmm14,0x8
    707120f060d6:	movq   rax,xmm14
    707120f060db:	add    rax,rax
    707120f060de:	je     0x707120f060f4
    707120f060e0:	shr    rax,0x35
    707120f060e4:	sub    eax,0x201
    707120f060e9:	cmp    eax,0x3fc
    707120f060ee:	ja     0x707120f08011
    707120f060f4:	addpd  xmm0,xmm1
    707120f060f8:	movdqa xmm4,xmm0
    707120f060fc:	movdqa xmm0,xmm4
    707120f06100:	movdqu XMMWORD PTR [r12+0x230],xmm0
    707120f0610a:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    707120f06114:	movdqa xmm2,xmm0
    707120f06118:	movdqa xmm1,xmm2
    707120f0611c:	por    xmm2,xmm1
    707120f06120:	movdqa xmm0,xmm2
    707120f06124:	movdqu XMMWORD PTR [r12+0x250],xmm0
    707120f0612e:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    707120f06138:	movdqa xmm2,xmm0
    707120f0613c:	movdqa xmm1,xmm2
    707120f06140:	por    xmm2,xmm1
    707120f06144:	movdqa xmm0,xmm2
    707120f06148:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    707120f06152:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    707120f0615c:	movdqa xmm2,xmm0
    707120f06160:	movdqa xmm1,xmm2
    707120f06164:	por    xmm2,xmm1
    707120f06168:	movdqa xmm0,xmm2
    707120f0616c:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    707120f06176:	mov    r13,QWORD PTR [r12+0xf8]
    707120f0617e:	add    r13,0x40
    707120f06182:	stmxcsr DWORD PTR [rsp+0x114]
    707120f0618a:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f06192:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f0619a:	shr    r11d,1
    707120f0619d:	and    r11d,0x10
    707120f061a1:	or     DWORD PTR [r12+0x314],r11d
    707120f061a9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f061af:	movdqa xmm0,xmm2
    707120f061b3:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    707120f061bd:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    707120f061c7:	movdqa xmm2,xmm0
    707120f061cb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120f061d5:	movdqa xmm3,xmm0
    707120f061d9:	stmxcsr DWORD PTR [rsp+0x110]
    707120f061e1:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f061ec:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f061f4:	movdqa xmm0,xmm2
    707120f061f8:	movdqa xmm1,xmm3
    707120f061fc:	pshufd xmm1,xmm1,0x44
    707120f06201:	movq   rax,xmm0
    707120f06206:	add    rax,rax
    707120f06209:	je     0x707120f0621f
    707120f0620b:	shr    rax,0x35
    707120f0620f:	sub    eax,0x201
    707120f06214:	cmp    eax,0x3fc
    707120f06219:	ja     0x707120f08035
    707120f0621f:	movdqa xmm14,xmm0
    707120f06224:	psrldq xmm14,0x8
    707120f0622a:	movq   rax,xmm14
    707120f0622f:	add    rax,rax
    707120f06232:	je     0x707120f06248
    707120f06234:	shr    rax,0x35
    707120f06238:	sub    eax,0x201
    707120f0623d:	cmp    eax,0x3fc
    707120f06242:	ja     0x707120f08035
    707120f06248:	movq   rax,xmm1
    707120f0624d:	add    rax,rax
    707120f06250:	je     0x707120f06266
    707120f06252:	shr    rax,0x35
    707120f06256:	sub    eax,0x201
    707120f0625b:	cmp    eax,0x3fc
    707120f06260:	ja     0x707120f08035
    707120f06266:	movdqa xmm14,xmm1
    707120f0626b:	psrldq xmm14,0x8
    707120f06271:	movq   rax,xmm14
    707120f06276:	add    rax,rax
    707120f06279:	je     0x707120f0628f
    707120f0627b:	shr    rax,0x35
    707120f0627f:	sub    eax,0x201
    707120f06284:	cmp    eax,0x3fc
    707120f06289:	ja     0x707120f08035
    707120f0628f:	mulpd  xmm0,xmm1
    707120f06293:	movdqa xmm4,xmm0
    707120f06297:	movdqa xmm0,xmm4
    707120f0629b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f062a5:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f062af:	movdqa xmm2,xmm0
    707120f062b3:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120f062bd:	movdqa xmm4,xmm0
    707120f062c1:	movdqa xmm0,xmm2
    707120f062c5:	movdqa xmm1,xmm4
    707120f062c9:	movq   rax,xmm0
    707120f062ce:	add    rax,rax
    707120f062d1:	je     0x707120f062e7
    707120f062d3:	shr    rax,0x35
    707120f062d7:	sub    eax,0x201
    707120f062dc:	cmp    eax,0x3fc
    707120f062e1:	ja     0x707120f08059
    707120f062e7:	movdqa xmm14,xmm0
    707120f062ec:	psrldq xmm14,0x8
    707120f062f2:	movq   rax,xmm14
    707120f062f7:	add    rax,rax
    707120f062fa:	je     0x707120f06310
    707120f062fc:	shr    rax,0x35
    707120f06300:	sub    eax,0x201
    707120f06305:	cmp    eax,0x3fc
    707120f0630a:	ja     0x707120f08059
    707120f06310:	movq   rax,xmm1
    707120f06315:	add    rax,rax
    707120f06318:	je     0x707120f0632e
    707120f0631a:	shr    rax,0x35
    707120f0631e:	sub    eax,0x201
    707120f06323:	cmp    eax,0x3fc
    707120f06328:	ja     0x707120f08059
    707120f0632e:	movdqa xmm14,xmm1
    707120f06333:	psrldq xmm14,0x8
    707120f06339:	movq   rax,xmm14
    707120f0633e:	add    rax,rax
    707120f06341:	je     0x707120f06357
    707120f06343:	shr    rax,0x35
    707120f06347:	sub    eax,0x201
    707120f0634c:	cmp    eax,0x3fc
    707120f06351:	ja     0x707120f08059
    707120f06357:	addpd  xmm0,xmm1
    707120f0635b:	movdqa xmm5,xmm0
    707120f0635f:	movdqa xmm0,xmm5
    707120f06363:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120f0636d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f06377:	movdqa xmm2,xmm0
    707120f0637b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f06385:	movdqa xmm4,xmm0
    707120f06389:	movdqa xmm0,xmm2
    707120f0638d:	movdqa xmm1,xmm4
    707120f06391:	movq   rax,xmm0
    707120f06396:	add    rax,rax
    707120f06399:	je     0x707120f063af
    707120f0639b:	shr    rax,0x35
    707120f0639f:	sub    eax,0x201
    707120f063a4:	cmp    eax,0x3fc
    707120f063a9:	ja     0x707120f0807d
    707120f063af:	movdqa xmm14,xmm0
    707120f063b4:	psrldq xmm14,0x8
    707120f063ba:	movq   rax,xmm14
    707120f063bf:	add    rax,rax
    707120f063c2:	je     0x707120f063d8
    707120f063c4:	shr    rax,0x35
    707120f063c8:	sub    eax,0x201
    707120f063cd:	cmp    eax,0x3fc
    707120f063d2:	ja     0x707120f0807d
    707120f063d8:	movq   rax,xmm1
    707120f063dd:	add    rax,rax
    707120f063e0:	je     0x707120f063f6
    707120f063e2:	shr    rax,0x35
    707120f063e6:	sub    eax,0x201
    707120f063eb:	cmp    eax,0x3fc
    707120f063f0:	ja     0x707120f0807d
    707120f063f6:	movdqa xmm14,xmm1
    707120f063fb:	psrldq xmm14,0x8
    707120f06401:	movq   rax,xmm14
    707120f06406:	add    rax,rax
    707120f06409:	je     0x707120f0641f
    707120f0640b:	shr    rax,0x35
    707120f0640f:	sub    eax,0x201
    707120f06414:	cmp    eax,0x3fc
    707120f06419:	ja     0x707120f0807d
    707120f0641f:	addpd  xmm0,xmm1
    707120f06423:	movdqa xmm5,xmm0
    707120f06427:	movdqa xmm0,xmm5
    707120f0642b:	movdqu XMMWORD PTR [r12+0x160],xmm0
    707120f06435:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    707120f0643f:	movdqa xmm2,xmm0
    707120f06443:	movdqa xmm0,xmm2
    707120f06447:	movdqa xmm1,xmm3
    707120f0644b:	pshufd xmm1,xmm1,0x44
    707120f06450:	movq   rax,xmm0
    707120f06455:	add    rax,rax
    707120f06458:	je     0x707120f0646e
    707120f0645a:	shr    rax,0x35
    707120f0645e:	sub    eax,0x201
    707120f06463:	cmp    eax,0x3fc
    707120f06468:	ja     0x707120f080a1
    707120f0646e:	movdqa xmm14,xmm0
    707120f06473:	psrldq xmm14,0x8
    707120f06479:	movq   rax,xmm14
    707120f0647e:	add    rax,rax
    707120f06481:	je     0x707120f06497
    707120f06483:	shr    rax,0x35
    707120f06487:	sub    eax,0x201
    707120f0648c:	cmp    eax,0x3fc
    707120f06491:	ja     0x707120f080a1
    707120f06497:	movq   rax,xmm1
    707120f0649c:	add    rax,rax
    707120f0649f:	je     0x707120f064b5
    707120f064a1:	shr    rax,0x35
    707120f064a5:	sub    eax,0x201
    707120f064aa:	cmp    eax,0x3fc
    707120f064af:	ja     0x707120f080a1
    707120f064b5:	movdqa xmm14,xmm1
    707120f064ba:	psrldq xmm14,0x8
    707120f064c0:	movq   rax,xmm14
    707120f064c5:	add    rax,rax
    707120f064c8:	je     0x707120f064de
    707120f064ca:	shr    rax,0x35
    707120f064ce:	sub    eax,0x201
    707120f064d3:	cmp    eax,0x3fc
    707120f064d8:	ja     0x707120f080a1
    707120f064de:	mulpd  xmm0,xmm1
    707120f064e2:	movdqa xmm4,xmm0
    707120f064e6:	movdqa xmm0,xmm4
    707120f064ea:	movdqu XMMWORD PTR [r12+0x240],xmm0
    707120f064f4:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    707120f064fe:	movdqa xmm2,xmm0
    707120f06502:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120f0650c:	movdqa xmm3,xmm0
    707120f06510:	movdqa xmm0,xmm2
    707120f06514:	movdqa xmm1,xmm3
    707120f06518:	pshufd xmm1,xmm1,0x44
    707120f0651d:	movq   rax,xmm0
    707120f06522:	add    rax,rax
    707120f06525:	je     0x707120f0653b
    707120f06527:	shr    rax,0x35
    707120f0652b:	sub    eax,0x201
    707120f06530:	cmp    eax,0x3fc
    707120f06535:	ja     0x707120f080c5
    707120f0653b:	movdqa xmm14,xmm0
    707120f06540:	psrldq xmm14,0x8
    707120f06546:	movq   rax,xmm14
    707120f0654b:	add    rax,rax
    707120f0654e:	je     0x707120f06564
    707120f06550:	shr    rax,0x35
    707120f06554:	sub    eax,0x201
    707120f06559:	cmp    eax,0x3fc
    707120f0655e:	ja     0x707120f080c5
    707120f06564:	movq   rax,xmm1
    707120f06569:	add    rax,rax
    707120f0656c:	je     0x707120f06582
    707120f0656e:	shr    rax,0x35
    707120f06572:	sub    eax,0x201
    707120f06577:	cmp    eax,0x3fc
    707120f0657c:	ja     0x707120f080c5
    707120f06582:	movdqa xmm14,xmm1
    707120f06587:	psrldq xmm14,0x8
    707120f0658d:	movq   rax,xmm14
    707120f06592:	add    rax,rax
    707120f06595:	je     0x707120f065ab
    707120f06597:	shr    rax,0x35
    707120f0659b:	sub    eax,0x201
    707120f065a0:	cmp    eax,0x3fc
    707120f065a5:	ja     0x707120f080c5
    707120f065ab:	mulpd  xmm0,xmm1
    707120f065af:	movdqa xmm4,xmm0
    707120f065b3:	movdqa xmm0,xmm4
    707120f065b7:	movdqu XMMWORD PTR [r12+0x140],xmm0
    707120f065c1:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    707120f065cb:	movdqa xmm2,xmm0
    707120f065cf:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120f065d9:	movdqa xmm3,xmm0
    707120f065dd:	movdqa xmm0,xmm2
    707120f065e1:	movdqa xmm1,xmm3
    707120f065e5:	pshufd xmm1,xmm1,0x44
    707120f065ea:	movq   rax,xmm0
    707120f065ef:	add    rax,rax
    707120f065f2:	je     0x707120f06608
    707120f065f4:	shr    rax,0x35
    707120f065f8:	sub    eax,0x201
    707120f065fd:	cmp    eax,0x3fc
    707120f06602:	ja     0x707120f080e9
    707120f06608:	movdqa xmm14,xmm0
    707120f0660d:	psrldq xmm14,0x8
    707120f06613:	movq   rax,xmm14
    707120f06618:	add    rax,rax
    707120f0661b:	je     0x707120f06631
    707120f0661d:	shr    rax,0x35
    707120f06621:	sub    eax,0x201
    707120f06626:	cmp    eax,0x3fc
    707120f0662b:	ja     0x707120f080e9
    707120f06631:	movq   rax,xmm1
    707120f06636:	add    rax,rax
    707120f06639:	je     0x707120f0664f
    707120f0663b:	shr    rax,0x35
    707120f0663f:	sub    eax,0x201
    707120f06644:	cmp    eax,0x3fc
    707120f06649:	ja     0x707120f080e9
    707120f0664f:	movdqa xmm14,xmm1
    707120f06654:	psrldq xmm14,0x8
    707120f0665a:	movq   rax,xmm14
    707120f0665f:	add    rax,rax
    707120f06662:	je     0x707120f06678
    707120f06664:	shr    rax,0x35
    707120f06668:	sub    eax,0x201
    707120f0666d:	cmp    eax,0x3fc
    707120f06672:	ja     0x707120f080e9
    707120f06678:	mulpd  xmm0,xmm1
    707120f0667c:	movdqa xmm4,xmm0
    707120f06680:	movdqa xmm0,xmm4
    707120f06684:	movdqu XMMWORD PTR [r12+0x170],xmm0
    707120f0668e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f06698:	movdqa xmm2,xmm0
    707120f0669c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f066a6:	movdqa xmm4,xmm0
    707120f066aa:	movdqa xmm0,xmm2
    707120f066ae:	movdqa xmm1,xmm4
    707120f066b2:	movq   rax,xmm0
    707120f066b7:	add    rax,rax
    707120f066ba:	je     0x707120f066d0
    707120f066bc:	shr    rax,0x35
    707120f066c0:	sub    eax,0x201
    707120f066c5:	cmp    eax,0x3fc
    707120f066ca:	ja     0x707120f0810d
    707120f066d0:	movdqa xmm14,xmm0
    707120f066d5:	psrldq xmm14,0x8
    707120f066db:	movq   rax,xmm14
    707120f066e0:	add    rax,rax
    707120f066e3:	je     0x707120f066f9
    707120f066e5:	shr    rax,0x35
    707120f066e9:	sub    eax,0x201
    707120f066ee:	cmp    eax,0x3fc
    707120f066f3:	ja     0x707120f0810d
    707120f066f9:	movq   rax,xmm1
    707120f066fe:	add    rax,rax
    707120f06701:	je     0x707120f06717
    707120f06703:	shr    rax,0x35
    707120f06707:	sub    eax,0x201
    707120f0670c:	cmp    eax,0x3fc
    707120f06711:	ja     0x707120f0810d
    707120f06717:	movdqa xmm14,xmm1
    707120f0671c:	psrldq xmm14,0x8
    707120f06722:	movq   rax,xmm14
    707120f06727:	add    rax,rax
    707120f0672a:	je     0x707120f06740
    707120f0672c:	shr    rax,0x35
    707120f06730:	sub    eax,0x201
    707120f06735:	cmp    eax,0x3fc
    707120f0673a:	ja     0x707120f0810d
    707120f06740:	addpd  xmm0,xmm1
    707120f06744:	movdqa xmm5,xmm0
    707120f06748:	movdqa xmm0,xmm5
    707120f0674c:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f06756:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f06760:	movdqa xmm2,xmm0
    707120f06764:	movdqa xmm0,xmm2
    707120f06768:	movdqa xmm1,xmm3
    707120f0676c:	pshufd xmm1,xmm1,0x44
    707120f06771:	movq   rax,xmm0
    707120f06776:	add    rax,rax
    707120f06779:	je     0x707120f0678f
    707120f0677b:	shr    rax,0x35
    707120f0677f:	sub    eax,0x201
    707120f06784:	cmp    eax,0x3fc
    707120f06789:	ja     0x707120f08131
    707120f0678f:	movdqa xmm14,xmm0
    707120f06794:	psrldq xmm14,0x8
    707120f0679a:	movq   rax,xmm14
    707120f0679f:	add    rax,rax
    707120f067a2:	je     0x707120f067b8
    707120f067a4:	shr    rax,0x35
    707120f067a8:	sub    eax,0x201
    707120f067ad:	cmp    eax,0x3fc
    707120f067b2:	ja     0x707120f08131
    707120f067b8:	movq   rax,xmm1
    707120f067bd:	add    rax,rax
    707120f067c0:	je     0x707120f067d6
    707120f067c2:	shr    rax,0x35
    707120f067c6:	sub    eax,0x201
    707120f067cb:	cmp    eax,0x3fc
    707120f067d0:	ja     0x707120f08131
    707120f067d6:	movdqa xmm14,xmm1
    707120f067db:	psrldq xmm14,0x8
    707120f067e1:	movq   rax,xmm14
    707120f067e6:	add    rax,rax
    707120f067e9:	je     0x707120f067ff
    707120f067eb:	shr    rax,0x35
    707120f067ef:	sub    eax,0x201
    707120f067f4:	cmp    eax,0x3fc
    707120f067f9:	ja     0x707120f08131
    707120f067ff:	mulpd  xmm0,xmm1
    707120f06803:	movdqa xmm4,xmm0
    707120f06807:	movdqa xmm0,xmm4
    707120f0680b:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f06815:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120f0681f:	movdqa xmm2,xmm0
    707120f06823:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    707120f0682d:	movdqa xmm4,xmm0
    707120f06831:	movdqa xmm0,xmm2
    707120f06835:	movdqa xmm1,xmm4
    707120f06839:	movq   rax,xmm0
    707120f0683e:	add    rax,rax
    707120f06841:	je     0x707120f06857
    707120f06843:	shr    rax,0x35
    707120f06847:	sub    eax,0x201
    707120f0684c:	cmp    eax,0x3fc
    707120f06851:	ja     0x707120f08155
    707120f06857:	movdqa xmm14,xmm0
    707120f0685c:	psrldq xmm14,0x8
    707120f06862:	movq   rax,xmm14
    707120f06867:	add    rax,rax
    707120f0686a:	je     0x707120f06880
    707120f0686c:	shr    rax,0x35
    707120f06870:	sub    eax,0x201
    707120f06875:	cmp    eax,0x3fc
    707120f0687a:	ja     0x707120f08155
    707120f06880:	movq   rax,xmm1
    707120f06885:	add    rax,rax
    707120f06888:	je     0x707120f0689e
    707120f0688a:	shr    rax,0x35
    707120f0688e:	sub    eax,0x201
    707120f06893:	cmp    eax,0x3fc
    707120f06898:	ja     0x707120f08155
    707120f0689e:	movdqa xmm14,xmm1
    707120f068a3:	psrldq xmm14,0x8
    707120f068a9:	movq   rax,xmm14
    707120f068ae:	add    rax,rax
    707120f068b1:	je     0x707120f068c7
    707120f068b3:	shr    rax,0x35
    707120f068b7:	sub    eax,0x201
    707120f068bc:	cmp    eax,0x3fc
    707120f068c1:	ja     0x707120f08155
    707120f068c7:	addpd  xmm0,xmm1
    707120f068cb:	movdqa xmm5,xmm0
    707120f068cf:	movdqa xmm0,xmm5
    707120f068d3:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f068dd:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    707120f068e7:	movdqa xmm2,xmm0
    707120f068eb:	movdqa xmm0,xmm2
    707120f068ef:	movdqa xmm1,xmm3
    707120f068f3:	pshufd xmm1,xmm1,0x44
    707120f068f8:	movq   rax,xmm0
    707120f068fd:	add    rax,rax
    707120f06900:	je     0x707120f06916
    707120f06902:	shr    rax,0x35
    707120f06906:	sub    eax,0x201
    707120f0690b:	cmp    eax,0x3fc
    707120f06910:	ja     0x707120f08179
    707120f06916:	movdqa xmm14,xmm0
    707120f0691b:	psrldq xmm14,0x8
    707120f06921:	movq   rax,xmm14
    707120f06926:	add    rax,rax
    707120f06929:	je     0x707120f0693f
    707120f0692b:	shr    rax,0x35
    707120f0692f:	sub    eax,0x201
    707120f06934:	cmp    eax,0x3fc
    707120f06939:	ja     0x707120f08179
    707120f0693f:	movq   rax,xmm1
    707120f06944:	add    rax,rax
    707120f06947:	je     0x707120f0695d
    707120f06949:	shr    rax,0x35
    707120f0694d:	sub    eax,0x201
    707120f06952:	cmp    eax,0x3fc
    707120f06957:	ja     0x707120f08179
    707120f0695d:	movdqa xmm14,xmm1
    707120f06962:	psrldq xmm14,0x8
    707120f06968:	movq   rax,xmm14
    707120f0696d:	add    rax,rax
    707120f06970:	je     0x707120f06986
    707120f06972:	shr    rax,0x35
    707120f06976:	sub    eax,0x201
    707120f0697b:	cmp    eax,0x3fc
    707120f06980:	ja     0x707120f08179
    707120f06986:	mulpd  xmm0,xmm1
    707120f0698a:	movdqa xmm4,xmm0
    707120f0698e:	movdqa xmm0,xmm4
    707120f06992:	movdqu XMMWORD PTR [r12+0x230],xmm0
    707120f0699c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120f069a6:	movdqa xmm2,xmm0
    707120f069aa:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120f069b4:	movdqa xmm3,xmm0
    707120f069b8:	movdqa xmm0,xmm2
    707120f069bc:	movdqa xmm1,xmm3
    707120f069c0:	movq   rax,xmm0
    707120f069c5:	add    rax,rax
    707120f069c8:	je     0x707120f069de
    707120f069ca:	shr    rax,0x35
    707120f069ce:	sub    eax,0x201
    707120f069d3:	cmp    eax,0x3fc
    707120f069d8:	ja     0x707120f0819d
    707120f069de:	movdqa xmm14,xmm0
    707120f069e3:	psrldq xmm14,0x8
    707120f069e9:	movq   rax,xmm14
    707120f069ee:	add    rax,rax
    707120f069f1:	je     0x707120f06a07
    707120f069f3:	shr    rax,0x35
    707120f069f7:	sub    eax,0x201
    707120f069fc:	cmp    eax,0x3fc
    707120f06a01:	ja     0x707120f0819d
    707120f06a07:	movq   rax,xmm1
    707120f06a0c:	add    rax,rax
    707120f06a0f:	je     0x707120f06a25
    707120f06a11:	shr    rax,0x35
    707120f06a15:	sub    eax,0x201
    707120f06a1a:	cmp    eax,0x3fc
    707120f06a1f:	ja     0x707120f0819d
    707120f06a25:	movdqa xmm14,xmm1
    707120f06a2a:	psrldq xmm14,0x8
    707120f06a30:	movq   rax,xmm14
    707120f06a35:	add    rax,rax
    707120f06a38:	je     0x707120f06a4e
    707120f06a3a:	shr    rax,0x35
    707120f06a3e:	sub    eax,0x201
    707120f06a43:	cmp    eax,0x3fc
    707120f06a48:	ja     0x707120f0819d
    707120f06a4e:	addpd  xmm0,xmm1
    707120f06a52:	movdqa xmm4,xmm0
    707120f06a56:	movdqa xmm0,xmm4
    707120f06a5a:	movdqu XMMWORD PTR [r12+0x140],xmm0
    707120f06a64:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    707120f06a6e:	movdqa xmm2,xmm0
    707120f06a72:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120f06a7c:	movdqa xmm3,xmm0
    707120f06a80:	movdqa xmm0,xmm2
    707120f06a84:	movdqa xmm1,xmm3
    707120f06a88:	pshufd xmm1,xmm1,0x44
    707120f06a8d:	movq   rax,xmm0
    707120f06a92:	add    rax,rax
    707120f06a95:	je     0x707120f06aab
    707120f06a97:	shr    rax,0x35
    707120f06a9b:	sub    eax,0x201
    707120f06aa0:	cmp    eax,0x3fc
    707120f06aa5:	ja     0x707120f081c1
    707120f06aab:	movdqa xmm14,xmm0
    707120f06ab0:	psrldq xmm14,0x8
    707120f06ab6:	movq   rax,xmm14
    707120f06abb:	add    rax,rax
    707120f06abe:	je     0x707120f06ad4
    707120f06ac0:	shr    rax,0x35
    707120f06ac4:	sub    eax,0x201
    707120f06ac9:	cmp    eax,0x3fc
    707120f06ace:	ja     0x707120f081c1
    707120f06ad4:	movq   rax,xmm1
    707120f06ad9:	add    rax,rax
    707120f06adc:	je     0x707120f06af2
    707120f06ade:	shr    rax,0x35
    707120f06ae2:	sub    eax,0x201
    707120f06ae7:	cmp    eax,0x3fc
    707120f06aec:	ja     0x707120f081c1
    707120f06af2:	movdqa xmm14,xmm1
    707120f06af7:	psrldq xmm14,0x8
    707120f06afd:	movq   rax,xmm14
    707120f06b02:	add    rax,rax
    707120f06b05:	je     0x707120f06b1b
    707120f06b07:	shr    rax,0x35
    707120f06b0b:	sub    eax,0x201
    707120f06b10:	cmp    eax,0x3fc
    707120f06b15:	ja     0x707120f081c1
    707120f06b1b:	mulpd  xmm0,xmm1
    707120f06b1f:	movdqa xmm4,xmm0
    707120f06b23:	movdqa xmm0,xmm4
    707120f06b27:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120f06b31:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f06b3b:	movdqa xmm2,xmm0
    707120f06b3f:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f06b49:	movdqa xmm3,xmm0
    707120f06b4d:	movdqa xmm0,xmm2
    707120f06b51:	movdqa xmm1,xmm3
    707120f06b55:	movq   rax,xmm0
    707120f06b5a:	add    rax,rax
    707120f06b5d:	je     0x707120f06b73
    707120f06b5f:	shr    rax,0x35
    707120f06b63:	sub    eax,0x201
    707120f06b68:	cmp    eax,0x3fc
    707120f06b6d:	ja     0x707120f081e5
    707120f06b73:	movdqa xmm14,xmm0
    707120f06b78:	psrldq xmm14,0x8
    707120f06b7e:	movq   rax,xmm14
    707120f06b83:	add    rax,rax
    707120f06b86:	je     0x707120f06b9c
    707120f06b88:	shr    rax,0x35
    707120f06b8c:	sub    eax,0x201
    707120f06b91:	cmp    eax,0x3fc
    707120f06b96:	ja     0x707120f081e5
    707120f06b9c:	movq   rax,xmm1
    707120f06ba1:	add    rax,rax
    707120f06ba4:	je     0x707120f06bba
    707120f06ba6:	shr    rax,0x35
    707120f06baa:	sub    eax,0x201
    707120f06baf:	cmp    eax,0x3fc
    707120f06bb4:	ja     0x707120f081e5
    707120f06bba:	movdqa xmm14,xmm1
    707120f06bbf:	psrldq xmm14,0x8
    707120f06bc5:	movq   rax,xmm14
    707120f06bca:	add    rax,rax
    707120f06bcd:	je     0x707120f06be3
    707120f06bcf:	shr    rax,0x35
    707120f06bd3:	sub    eax,0x201
    707120f06bd8:	cmp    eax,0x3fc
    707120f06bdd:	ja     0x707120f081e5
    707120f06be3:	addpd  xmm0,xmm1
    707120f06be7:	movdqa xmm4,xmm0
    707120f06beb:	movdqa xmm0,xmm4
    707120f06bef:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120f06bf9:	mov    r13,QWORD PTR [r12+0xf8]
    707120f06c01:	mov    r14,r13
    707120f06c04:	add    r14,0x70
    707120f06c08:	stmxcsr DWORD PTR [rsp+0x114]
    707120f06c10:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f06c18:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f06c20:	shr    r11d,1
    707120f06c23:	and    r11d,0x10
    707120f06c27:	or     DWORD PTR [r12+0x314],r11d
    707120f06c2f:	movdqu xmm2,XMMWORD PTR [r14]
    707120f06c34:	movdqa xmm0,xmm2
    707120f06c38:	movdqu XMMWORD PTR [r12+0x240],xmm0
    707120f06c42:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f06c4c:	movdqa xmm3,xmm0
    707120f06c50:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f06c5a:	movdqa xmm4,xmm0
    707120f06c5e:	stmxcsr DWORD PTR [rsp+0x110]
    707120f06c66:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f06c71:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f06c79:	movdqa xmm0,xmm3
    707120f06c7d:	movdqa xmm1,xmm4
    707120f06c81:	movq   rax,xmm0
    707120f06c86:	add    rax,rax
    707120f06c89:	je     0x707120f06c9f
    707120f06c8b:	shr    rax,0x35
    707120f06c8f:	sub    eax,0x201
    707120f06c94:	cmp    eax,0x3fc
    707120f06c99:	ja     0x707120f08209
    707120f06c9f:	movdqa xmm14,xmm0
    707120f06ca4:	psrldq xmm14,0x8
    707120f06caa:	movq   rax,xmm14
    707120f06caf:	add    rax,rax
    707120f06cb2:	je     0x707120f06cc8
    707120f06cb4:	shr    rax,0x35
    707120f06cb8:	sub    eax,0x201
    707120f06cbd:	cmp    eax,0x3fc
    707120f06cc2:	ja     0x707120f08209
    707120f06cc8:	movq   rax,xmm1
    707120f06ccd:	add    rax,rax
    707120f06cd0:	je     0x707120f06ce6
    707120f06cd2:	shr    rax,0x35
    707120f06cd6:	sub    eax,0x201
    707120f06cdb:	cmp    eax,0x3fc
    707120f06ce0:	ja     0x707120f08209
    707120f06ce6:	movdqa xmm14,xmm1
    707120f06ceb:	psrldq xmm14,0x8
    707120f06cf1:	movq   rax,xmm14
    707120f06cf6:	add    rax,rax
    707120f06cf9:	je     0x707120f06d0f
    707120f06cfb:	shr    rax,0x35
    707120f06cff:	sub    eax,0x201
    707120f06d04:	cmp    eax,0x3fc
    707120f06d09:	ja     0x707120f08209
    707120f06d0f:	addpd  xmm0,xmm1
    707120f06d13:	movdqa xmm5,xmm0
    707120f06d17:	movdqa xmm0,xmm5
    707120f06d1b:	movdqu XMMWORD PTR [r12+0x170],xmm0
    707120f06d25:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    707120f06d2f:	movdqa xmm3,xmm0
    707120f06d33:	movdqa xmm0,xmm2
    707120f06d37:	movdqa xmm1,xmm3
    707120f06d3b:	pshufd xmm1,xmm1,0x44
    707120f06d40:	movq   rax,xmm0
    707120f06d45:	add    rax,rax
    707120f06d48:	je     0x707120f06d5e
    707120f06d4a:	shr    rax,0x35
    707120f06d4e:	sub    eax,0x201
    707120f06d53:	cmp    eax,0x3fc
    707120f06d58:	ja     0x707120f0822d
    707120f06d5e:	movdqa xmm14,xmm0
    707120f06d63:	psrldq xmm14,0x8
    707120f06d69:	movq   rax,xmm14
    707120f06d6e:	add    rax,rax
    707120f06d71:	je     0x707120f06d87
    707120f06d73:	shr    rax,0x35
    707120f06d77:	sub    eax,0x201
    707120f06d7c:	cmp    eax,0x3fc
    707120f06d81:	ja     0x707120f0822d
    707120f06d87:	movq   rax,xmm1
    707120f06d8c:	add    rax,rax
    707120f06d8f:	je     0x707120f06da5
    707120f06d91:	shr    rax,0x35
    707120f06d95:	sub    eax,0x201
    707120f06d9a:	cmp    eax,0x3fc
    707120f06d9f:	ja     0x707120f0822d
    707120f06da5:	movdqa xmm14,xmm1
    707120f06daa:	psrldq xmm14,0x8
    707120f06db0:	movq   rax,xmm14
    707120f06db5:	add    rax,rax
    707120f06db8:	je     0x707120f06dce
    707120f06dba:	shr    rax,0x35
    707120f06dbe:	sub    eax,0x201
    707120f06dc3:	cmp    eax,0x3fc
    707120f06dc8:	ja     0x707120f0822d
    707120f06dce:	mulpd  xmm0,xmm1
    707120f06dd2:	movdqa xmm4,xmm0
    707120f06dd6:	movdqa xmm0,xmm4
    707120f06dda:	movdqu XMMWORD PTR [r12+0x160],xmm0
    707120f06de4:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    707120f06dee:	movdqa xmm2,xmm0
    707120f06df2:	movdqa xmm0,xmm2
    707120f06df6:	movdqa xmm1,xmm3
    707120f06dfa:	pshufd xmm1,xmm1,0x44
    707120f06dff:	movq   rax,xmm0
    707120f06e04:	add    rax,rax
    707120f06e07:	je     0x707120f06e1d
    707120f06e09:	shr    rax,0x35
    707120f06e0d:	sub    eax,0x201
    707120f06e12:	cmp    eax,0x3fc
    707120f06e17:	ja     0x707120f08251
    707120f06e1d:	movdqa xmm14,xmm0
    707120f06e22:	psrldq xmm14,0x8
    707120f06e28:	movq   rax,xmm14
    707120f06e2d:	add    rax,rax
    707120f06e30:	je     0x707120f06e46
    707120f06e32:	shr    rax,0x35
    707120f06e36:	sub    eax,0x201
    707120f06e3b:	cmp    eax,0x3fc
    707120f06e40:	ja     0x707120f08251
    707120f06e46:	movq   rax,xmm1
    707120f06e4b:	add    rax,rax
    707120f06e4e:	je     0x707120f06e64
    707120f06e50:	shr    rax,0x35
    707120f06e54:	sub    eax,0x201
    707120f06e59:	cmp    eax,0x3fc
    707120f06e5e:	ja     0x707120f08251
    707120f06e64:	movdqa xmm14,xmm1
    707120f06e69:	psrldq xmm14,0x8
    707120f06e6f:	movq   rax,xmm14
    707120f06e74:	add    rax,rax
    707120f06e77:	je     0x707120f06e8d
    707120f06e79:	shr    rax,0x35
    707120f06e7d:	sub    eax,0x201
    707120f06e82:	cmp    eax,0x3fc
    707120f06e87:	ja     0x707120f08251
    707120f06e8d:	mulpd  xmm0,xmm1
    707120f06e91:	movdqa xmm4,xmm0
    707120f06e95:	movdqa xmm0,xmm4
    707120f06e99:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f06ea3:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f06ead:	movdqa xmm2,xmm0
    707120f06eb1:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120f06ebb:	movdqa xmm4,xmm0
    707120f06ebf:	movdqa xmm0,xmm2
    707120f06ec3:	movdqa xmm1,xmm4
    707120f06ec7:	movq   rax,xmm0
    707120f06ecc:	add    rax,rax
    707120f06ecf:	je     0x707120f06ee5
    707120f06ed1:	shr    rax,0x35
    707120f06ed5:	sub    eax,0x201
    707120f06eda:	cmp    eax,0x3fc
    707120f06edf:	ja     0x707120f08275
    707120f06ee5:	movdqa xmm14,xmm0
    707120f06eea:	psrldq xmm14,0x8
    707120f06ef0:	movq   rax,xmm14
    707120f06ef5:	add    rax,rax
    707120f06ef8:	je     0x707120f06f0e
    707120f06efa:	shr    rax,0x35
    707120f06efe:	sub    eax,0x201
    707120f06f03:	cmp    eax,0x3fc
    707120f06f08:	ja     0x707120f08275
    707120f06f0e:	movq   rax,xmm1
    707120f06f13:	add    rax,rax
    707120f06f16:	je     0x707120f06f2c
    707120f06f18:	shr    rax,0x35
    707120f06f1c:	sub    eax,0x201
    707120f06f21:	cmp    eax,0x3fc
    707120f06f26:	ja     0x707120f08275
    707120f06f2c:	movdqa xmm14,xmm1
    707120f06f31:	psrldq xmm14,0x8
    707120f06f37:	movq   rax,xmm14
    707120f06f3c:	add    rax,rax
    707120f06f3f:	je     0x707120f06f55
    707120f06f41:	shr    rax,0x35
    707120f06f45:	sub    eax,0x201
    707120f06f4a:	cmp    eax,0x3fc
    707120f06f4f:	ja     0x707120f08275
    707120f06f55:	addpd  xmm0,xmm1
    707120f06f59:	movdqa xmm5,xmm0
    707120f06f5d:	movdqa xmm0,xmm5
    707120f06f61:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f06f6b:	mov    r14,r13
    707120f06f6e:	add    r14,0x10
    707120f06f72:	stmxcsr DWORD PTR [rsp+0x114]
    707120f06f7a:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f06f82:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f06f8a:	shr    r11d,1
    707120f06f8d:	and    r11d,0x10
    707120f06f91:	or     DWORD PTR [r12+0x314],r11d
    707120f06f99:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120f06f9f:	movdqu xmm4,XMMWORD PTR [r14]
    707120f06fa4:	movdqa xmm0,xmm4
    707120f06fa8:	movdqu XMMWORD PTR [r12+0x230],xmm0
    707120f06fb2:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120f06fbc:	movdqa xmm5,xmm0
    707120f06fc0:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120f06fca:	movdqa xmm6,xmm0
    707120f06fce:	stmxcsr DWORD PTR [rsp+0x110]
    707120f06fd6:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f06fe1:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f06fe9:	movdqa xmm0,xmm5
    707120f06fed:	movdqa xmm1,xmm6
    707120f06ff1:	movq   rax,xmm0
    707120f06ff6:	add    rax,rax
    707120f06ff9:	je     0x707120f0700f
    707120f06ffb:	shr    rax,0x35
    707120f06fff:	sub    eax,0x201
    707120f07004:	cmp    eax,0x3fc
    707120f07009:	ja     0x707120f08299
    707120f0700f:	movdqa xmm14,xmm0
    707120f07014:	psrldq xmm14,0x8
    707120f0701a:	movq   rax,xmm14
    707120f0701f:	add    rax,rax
    707120f07022:	je     0x707120f07038
    707120f07024:	shr    rax,0x35
    707120f07028:	sub    eax,0x201
    707120f0702d:	cmp    eax,0x3fc
    707120f07032:	ja     0x707120f08299
    707120f07038:	movq   rax,xmm1
    707120f0703d:	add    rax,rax
    707120f07040:	je     0x707120f07056
    707120f07042:	shr    rax,0x35
    707120f07046:	sub    eax,0x201
    707120f0704b:	cmp    eax,0x3fc
    707120f07050:	ja     0x707120f08299
    707120f07056:	movdqa xmm14,xmm1
    707120f0705b:	psrldq xmm14,0x8
    707120f07061:	movq   rax,xmm14
    707120f07066:	add    rax,rax
    707120f07069:	je     0x707120f0707f
    707120f0706b:	shr    rax,0x35
    707120f0706f:	sub    eax,0x201
    707120f07074:	cmp    eax,0x3fc
    707120f07079:	ja     0x707120f08299
    707120f0707f:	addpd  xmm0,xmm1
    707120f07083:	movdqa xmm7,xmm0
    707120f07087:	movdqa xmm0,xmm7
    707120f0708b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120f07095:	movdqa xmm0,xmm4
    707120f07099:	movdqa xmm1,xmm3
    707120f0709d:	pshufd xmm1,xmm1,0x44
    707120f070a2:	movq   rax,xmm0
    707120f070a7:	add    rax,rax
    707120f070aa:	je     0x707120f070c0
    707120f070ac:	shr    rax,0x35
    707120f070b0:	sub    eax,0x201
    707120f070b5:	cmp    eax,0x3fc
    707120f070ba:	ja     0x707120f082bd
    707120f070c0:	movdqa xmm14,xmm0
    707120f070c5:	psrldq xmm14,0x8
    707120f070cb:	movq   rax,xmm14
    707120f070d0:	add    rax,rax
    707120f070d3:	je     0x707120f070e9
    707120f070d5:	shr    rax,0x35
    707120f070d9:	sub    eax,0x201
    707120f070de:	cmp    eax,0x3fc
    707120f070e3:	ja     0x707120f082bd
    707120f070e9:	movq   rax,xmm1
    707120f070ee:	add    rax,rax
    707120f070f1:	je     0x707120f07107
    707120f070f3:	shr    rax,0x35
    707120f070f7:	sub    eax,0x201
    707120f070fc:	cmp    eax,0x3fc
    707120f07101:	ja     0x707120f082bd
    707120f07107:	movdqa xmm14,xmm1
    707120f0710c:	psrldq xmm14,0x8
    707120f07112:	movq   rax,xmm14
    707120f07117:	add    rax,rax
    707120f0711a:	je     0x707120f07130
    707120f0711c:	shr    rax,0x35
    707120f07120:	sub    eax,0x201
    707120f07125:	cmp    eax,0x3fc
    707120f0712a:	ja     0x707120f082bd
    707120f07130:	mulpd  xmm0,xmm1
    707120f07134:	movdqa xmm5,xmm0
    707120f07138:	movdqa xmm0,xmm5
    707120f0713c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f07146:	movdqa xmm0,xmm2
    707120f0714a:	movdqa xmm1,xmm3
    707120f0714e:	pshufd xmm1,xmm1,0x44
    707120f07153:	movq   rax,xmm0
    707120f07158:	add    rax,rax
    707120f0715b:	je     0x707120f07171
    707120f0715d:	shr    rax,0x35
    707120f07161:	sub    eax,0x201
    707120f07166:	cmp    eax,0x3fc
    707120f0716b:	ja     0x707120f082e1
    707120f07171:	movdqa xmm14,xmm0
    707120f07176:	psrldq xmm14,0x8
    707120f0717c:	movq   rax,xmm14
    707120f07181:	add    rax,rax
    707120f07184:	je     0x707120f0719a
    707120f07186:	shr    rax,0x35
    707120f0718a:	sub    eax,0x201
    707120f0718f:	cmp    eax,0x3fc
    707120f07194:	ja     0x707120f082e1
    707120f0719a:	movq   rax,xmm1
    707120f0719f:	add    rax,rax
    707120f071a2:	je     0x707120f071b8
    707120f071a4:	shr    rax,0x35
    707120f071a8:	sub    eax,0x201
    707120f071ad:	cmp    eax,0x3fc
    707120f071b2:	ja     0x707120f082e1
    707120f071b8:	movdqa xmm14,xmm1
    707120f071bd:	psrldq xmm14,0x8
    707120f071c3:	movq   rax,xmm14
    707120f071c8:	add    rax,rax
    707120f071cb:	je     0x707120f071e1
    707120f071cd:	shr    rax,0x35
    707120f071d1:	sub    eax,0x201
    707120f071d6:	cmp    eax,0x3fc
    707120f071db:	ja     0x707120f082e1
    707120f071e1:	mulpd  xmm0,xmm1
    707120f071e5:	movdqa xmm4,xmm0
    707120f071e9:	movdqa xmm0,xmm4
    707120f071ed:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f071f7:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120f07201:	movdqa xmm2,xmm0
    707120f07205:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f0720f:	movdqa xmm3,xmm0
    707120f07213:	movdqa xmm0,xmm2
    707120f07217:	movdqa xmm1,xmm3
    707120f0721b:	movq   rax,xmm0
    707120f07220:	add    rax,rax
    707120f07223:	je     0x707120f07239
    707120f07225:	shr    rax,0x35
    707120f07229:	sub    eax,0x201
    707120f0722e:	cmp    eax,0x3fc
    707120f07233:	ja     0x707120f08305
    707120f07239:	movdqa xmm14,xmm0
    707120f0723e:	psrldq xmm14,0x8
    707120f07244:	movq   rax,xmm14
    707120f07249:	add    rax,rax
    707120f0724c:	je     0x707120f07262
    707120f0724e:	shr    rax,0x35
    707120f07252:	sub    eax,0x201
    707120f07257:	cmp    eax,0x3fc
    707120f0725c:	ja     0x707120f08305
    707120f07262:	movq   rax,xmm1
    707120f07267:	add    rax,rax
    707120f0726a:	je     0x707120f07280
    707120f0726c:	shr    rax,0x35
    707120f07270:	sub    eax,0x201
    707120f07275:	cmp    eax,0x3fc
    707120f0727a:	ja     0x707120f08305
    707120f07280:	movdqa xmm14,xmm1
    707120f07285:	psrldq xmm14,0x8
    707120f0728b:	movq   rax,xmm14
    707120f07290:	add    rax,rax
    707120f07293:	je     0x707120f072a9
    707120f07295:	shr    rax,0x35
    707120f07299:	sub    eax,0x201
    707120f0729e:	cmp    eax,0x3fc
    707120f072a3:	ja     0x707120f08305
    707120f072a9:	addpd  xmm0,xmm1
    707120f072ad:	movdqa xmm4,xmm0
    707120f072b1:	movdqa xmm0,xmm4
    707120f072b5:	movdqu XMMWORD PTR [r12+0x140],xmm0
    707120f072bf:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f072c9:	movdqa xmm2,xmm0
    707120f072cd:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f072d7:	movdqa xmm3,xmm0
    707120f072db:	movdqa xmm0,xmm2
    707120f072df:	movdqa xmm1,xmm3
    707120f072e3:	movq   rax,xmm0
    707120f072e8:	add    rax,rax
    707120f072eb:	je     0x707120f07301
    707120f072ed:	shr    rax,0x35
    707120f072f1:	sub    eax,0x201
    707120f072f6:	cmp    eax,0x3fc
    707120f072fb:	ja     0x707120f08329
    707120f07301:	movdqa xmm14,xmm0
    707120f07306:	psrldq xmm14,0x8
    707120f0730c:	movq   rax,xmm14
    707120f07311:	add    rax,rax
    707120f07314:	je     0x707120f0732a
    707120f07316:	shr    rax,0x35
    707120f0731a:	sub    eax,0x201
    707120f0731f:	cmp    eax,0x3fc
    707120f07324:	ja     0x707120f08329
    707120f0732a:	movq   rax,xmm1
    707120f0732f:	add    rax,rax
    707120f07332:	je     0x707120f07348
    707120f07334:	shr    rax,0x35
    707120f07338:	sub    eax,0x201
    707120f0733d:	cmp    eax,0x3fc
    707120f07342:	ja     0x707120f08329
    707120f07348:	movdqa xmm14,xmm1
    707120f0734d:	psrldq xmm14,0x8
    707120f07353:	movq   rax,xmm14
    707120f07358:	add    rax,rax
    707120f0735b:	je     0x707120f07371
    707120f0735d:	shr    rax,0x35
    707120f07361:	sub    eax,0x201
    707120f07366:	cmp    eax,0x3fc
    707120f0736b:	ja     0x707120f08329
    707120f07371:	addpd  xmm0,xmm1
    707120f07375:	movdqa xmm4,xmm0
    707120f07379:	movdqa xmm0,xmm4
    707120f0737d:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120f07387:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f07391:	movdqa xmm2,xmm0
    707120f07395:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f0739f:	movdqa xmm3,xmm0
    707120f073a3:	movdqa xmm0,xmm2
    707120f073a7:	movdqa xmm1,xmm3
    707120f073ab:	movq   rax,xmm0
    707120f073b0:	add    rax,rax
    707120f073b3:	je     0x707120f073c9
    707120f073b5:	shr    rax,0x35
    707120f073b9:	sub    eax,0x201
    707120f073be:	cmp    eax,0x3fc
    707120f073c3:	ja     0x707120f0834d
    707120f073c9:	movdqa xmm14,xmm0
    707120f073ce:	psrldq xmm14,0x8
    707120f073d4:	movq   rax,xmm14
    707120f073d9:	add    rax,rax
    707120f073dc:	je     0x707120f073f2
    707120f073de:	shr    rax,0x35
    707120f073e2:	sub    eax,0x201
    707120f073e7:	cmp    eax,0x3fc
    707120f073ec:	ja     0x707120f0834d
    707120f073f2:	movq   rax,xmm1
    707120f073f7:	add    rax,rax
    707120f073fa:	je     0x707120f07410
    707120f073fc:	shr    rax,0x35
    707120f07400:	sub    eax,0x201
    707120f07405:	cmp    eax,0x3fc
    707120f0740a:	ja     0x707120f0834d
    707120f07410:	movdqa xmm14,xmm1
    707120f07415:	psrldq xmm14,0x8
    707120f0741b:	movq   rax,xmm14
    707120f07420:	add    rax,rax
    707120f07423:	je     0x707120f07439
    707120f07425:	shr    rax,0x35
    707120f07429:	sub    eax,0x201
    707120f0742e:	cmp    eax,0x3fc
    707120f07433:	ja     0x707120f0834d
    707120f07439:	addpd  xmm0,xmm1
    707120f0743d:	movdqa xmm4,xmm0
    707120f07441:	movdqa xmm0,xmm4
    707120f07445:	movdqu XMMWORD PTR [r12+0x160],xmm0
    707120f0744f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f07459:	movdqa xmm2,xmm0
    707120f0745d:	movdqa xmm0,xmm7
    707120f07461:	movdqa xmm1,xmm2
    707120f07465:	movq   rax,xmm0
    707120f0746a:	add    rax,rax
    707120f0746d:	je     0x707120f07483
    707120f0746f:	shr    rax,0x35
    707120f07473:	sub    eax,0x201
    707120f07478:	cmp    eax,0x3fc
    707120f0747d:	ja     0x707120f08371
    707120f07483:	movdqa xmm14,xmm0
    707120f07488:	psrldq xmm14,0x8
    707120f0748e:	movq   rax,xmm14
    707120f07493:	add    rax,rax
    707120f07496:	je     0x707120f074ac
    707120f07498:	shr    rax,0x35
    707120f0749c:	sub    eax,0x201
    707120f074a1:	cmp    eax,0x3fc
    707120f074a6:	ja     0x707120f08371
    707120f074ac:	movq   rax,xmm1
    707120f074b1:	add    rax,rax
    707120f074b4:	je     0x707120f074ca
    707120f074b6:	shr    rax,0x35
    707120f074ba:	sub    eax,0x201
    707120f074bf:	cmp    eax,0x3fc
    707120f074c4:	ja     0x707120f08371
    707120f074ca:	movdqa xmm14,xmm1
    707120f074cf:	psrldq xmm14,0x8
    707120f074d5:	movq   rax,xmm14
    707120f074da:	add    rax,rax
    707120f074dd:	je     0x707120f074f3
    707120f074df:	shr    rax,0x35
    707120f074e3:	sub    eax,0x201
    707120f074e8:	cmp    eax,0x3fc
    707120f074ed:	ja     0x707120f08371
    707120f074f3:	addpd  xmm0,xmm1
    707120f074f7:	movdqa xmm3,xmm0
    707120f074fb:	movdqa xmm0,xmm3
    707120f074ff:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f07509:	mov    r13,QWORD PTR [r12+0x60]
    707120f0750e:	mov    r14,r13
    707120f07511:	add    r14,0x10
    707120f07515:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120f0751f:	movdqa xmm2,xmm0
    707120f07523:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120f0752d:	movdqa xmm4,xmm0
    707120f07531:	stmxcsr DWORD PTR [rsp+0x114]
    707120f07539:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f07541:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f07549:	shr    r11d,1
    707120f0754c:	and    r11d,0x10
    707120f07550:	or     DWORD PTR [r12+0x314],r11d
    707120f07558:	movdqu XMMWORD PTR [r13+0x0],xmm2
    707120f0755e:	mov    r15d,0x0
    707120f07564:	mov    DWORD PTR [r12+0x32c],r15d
    707120f0756c:	movdqu XMMWORD PTR [r14],xmm4
    707120f07571:	mov    r14d,0x0
    707120f07577:	mov    DWORD PTR [r12+0x32c],r14d
    707120f0757f:	add    r13,0x20
    707120f07583:	mov    r14,r13
    707120f07586:	add    r14,0x10
    707120f0758a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f07594:	movdqa xmm2,xmm0
    707120f07598:	movdqu XMMWORD PTR [r13+0x0],xmm2
    707120f0759e:	mov    r13d,0x0
    707120f075a4:	mov    DWORD PTR [r12+0x32c],r13d
    707120f075ac:	movdqu XMMWORD PTR [r14],xmm3
    707120f075b1:	mov    r13d,0x0
    707120f075b7:	mov    DWORD PTR [r12+0x32c],r13d
    707120f075bf:	mov    rcx,QWORD PTR [r12+0x380]
    707120f075c7:	jrcxz  0x707120f075ce
    707120f075c9:	jmp    0x707120f09cea
    707120f075ce:	push   QWORD PTR [rsp]
    707120f075d1:	popf
    707120f075d2:	je     0x707120f075dd
    707120f075d8:	jmp    0x707120f03a18
    707120f075dd:	mov    r13d,DWORD PTR [r12+0x48]
    707120f075e2:	add    r13d,0x1
    707120f075e6:	mov    QWORD PTR [r12+0x48],r13
    707120f075eb:	sub    r13d,0x1f4
    707120f075f2:	mov    rcx,QWORD PTR [r12+0x380]
    707120f075fa:	jrcxz  0x707120f07601
    707120f075fc:	jmp    0x707120f09d74
    707120f07601:	pushf
    707120f07602:	pop    r11
    707120f07604:	mov    QWORD PTR [rsp],r11
    707120f07608:	jne    0x707120f03a08
    707120f0760e:	jmp    0x707120f07613
    707120f07613:	mov    r13d,0x430000
    707120f07619:	mov    QWORD PTR [r12+0x40],r13
    707120f0761e:	mov    r13d,0x0
    707120f07624:	mov    QWORD PTR [r12+0x48],r13
    707120f07629:	mov    r13d,0x430cc0
    707120f0762f:	mov    r14,QWORD PTR [r13+0x0]
    707120f07633:	mov    r13d,0x0
    707120f07639:	mov    QWORD PTR [r12+0x110],r14
    707120f07641:	mov    QWORD PTR [r12+0x118],r13
    707120f07649:	jmp    0x707120f0764e
    707120f0764e:	mov    r13,QWORD PTR [r12+0x48]
    707120f07653:	mov    r14,QWORD PTR [r12+0x50]
    707120f07658:	mov    rcx,r13
    707120f0765b:	add    r14,rcx
    707120f0765e:	movdqu xmm2,XMMWORD PTR [r14]
    707120f07663:	movdqa xmm0,xmm2
    707120f07667:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f07671:	add    r13,0x10
    707120f07675:	mov    QWORD PTR [r12+0x48],r13
    707120f0767a:	sub    r13,0x200
    707120f07681:	mov    r13,QWORD PTR [r12+0x128]
    707120f07689:	mov    r14d,0x0
    707120f0768f:	mov    QWORD PTR [r12+0x130],r13
    707120f07697:	mov    QWORD PTR [r12+0x138],r14
    707120f0769f:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f076a9:	movdqa xmm2,xmm0
    707120f076ad:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f076b7:	movdqa xmm3,xmm0
    707120f076bb:	pushf
    707120f076bc:	pop    r11
    707120f076be:	mov    QWORD PTR [rsp],r11
    707120f076c2:	stmxcsr DWORD PTR [rsp+0x110]
    707120f076ca:	mov    DWORD PTR [rsp+0x114],0x1f80
    707120f076d5:	ldmxcsr DWORD PTR [rsp+0x114]
    707120f076dd:	movdqa xmm0,xmm2
    707120f076e1:	movdqa xmm1,xmm3
    707120f076e5:	movq   rax,xmm0
    707120f076ea:	add    rax,rax
    707120f076ed:	je     0x707120f07703
    707120f076ef:	shr    rax,0x35
    707120f076f3:	sub    eax,0x201
    707120f076f8:	cmp    eax,0x3fc
    707120f076fd:	ja     0x707120f08395
    707120f07703:	movq   rax,xmm1
    707120f07708:	add    rax,rax
    707120f0770b:	je     0x707120f07721
    707120f0770d:	shr    rax,0x35
    707120f07711:	sub    eax,0x201
    707120f07716:	cmp    eax,0x3fc
    707120f0771b:	ja     0x707120f08395
    707120f07721:	movq   xmm0,xmm0
    707120f07725:	movq   xmm1,xmm1
    707120f07729:	addsd  xmm0,xmm1
    707120f0772d:	movdqa xmm4,xmm0
    707120f07731:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120f0773b:	movdqa xmm2,xmm0
    707120f0773f:	movdqa xmm0,xmm4
    707120f07743:	movdqa xmm1,xmm2
    707120f07747:	movq   rax,xmm0
    707120f0774c:	add    rax,rax
    707120f0774f:	je     0x707120f07765
    707120f07751:	shr    rax,0x35
    707120f07755:	sub    eax,0x201
    707120f0775a:	cmp    eax,0x3fc
    707120f0775f:	ja     0x707120f083b9
    707120f07765:	movq   rax,xmm1
    707120f0776a:	add    rax,rax
    707120f0776d:	je     0x707120f07783
    707120f0776f:	shr    rax,0x35
    707120f07773:	sub    eax,0x201
    707120f07778:	cmp    eax,0x3fc
    707120f0777d:	ja     0x707120f083b9
    707120f07783:	movq   xmm0,xmm0
    707120f07787:	movq   xmm1,xmm1
    707120f0778b:	addsd  xmm0,xmm1
    707120f0778f:	movdqa xmm3,xmm0
    707120f07793:	movdqa xmm0,xmm3
    707120f07797:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f077a1:	stmxcsr DWORD PTR [rsp+0x114]
    707120f077a9:	ldmxcsr DWORD PTR [rsp+0x110]
    707120f077b1:	mov    r11d,DWORD PTR [rsp+0x114]
    707120f077b9:	shr    r11d,1
    707120f077bc:	and    r11d,0x10
    707120f077c0:	or     DWORD PTR [r12+0x314],r11d
    707120f077c8:	mov    rcx,QWORD PTR [r12+0x380]
    707120f077d0:	jrcxz  0x707120f077d7
    707120f077d2:	jmp    0x707120f09e06
    707120f077d7:	push   QWORD PTR [rsp]
    707120f077da:	popf
    707120f077db:	jne    0x707120f0764e
    707120f077e1:	jmp    0x707120f077e6
    707120f077e6:	mov    r13,QWORD PTR [r12+0xf8]
    707120f077ee:	mov    r14,r13
    707120f077f1:	add    r14,0x1d0
    707120f077f8:	mov    r15,r14
    707120f077fb:	add    r15,0x8
    707120f077ff:	mov    rbp,QWORD PTR [r14]
    707120f07802:	mov    r14,QWORD PTR [r15]
    707120f07805:	mov    QWORD PTR [r12+0xa0],rbp
    707120f0780d:	mov    QWORD PTR [r12+0x98],r14
    707120f07815:	mov    r14,QWORD PTR [r12+0x40]
    707120f0781a:	add    r14,0xcc0
    707120f07821:	mov    r15,QWORD PTR [r12+0x110]
    707120f07829:	mov    QWORD PTR [r14],r15
    707120f0782c:	mov    r14d,0x0
    707120f07832:	mov    DWORD PTR [r12+0x32c],r14d
    707120f0783a:	mov    r14,r13
    707120f0783d:	add    r14,0x1c0
    707120f07844:	mov    r15,r14
    707120f07847:	add    r15,0x8
    707120f0784b:	mov    rbp,QWORD PTR [r14]
    707120f0784e:	mov    r14,QWORD PTR [r15]
    707120f07851:	mov    QWORD PTR [r12+0xe8],rbp
    707120f07859:	mov    QWORD PTR [r12+0xf0],r14
    707120f07861:	add    r13,0x1b0
    707120f07868:	mov    r14,r13
    707120f0786b:	add    r14,0x8
    707120f0786f:	mov    r15,QWORD PTR [r13+0x0]
    707120f07873:	mov    r13,QWORD PTR [r14]
    707120f07876:	mov    r14d,0x0
    707120f0787c:	mov    QWORD PTR [r12+0x1a0],r15
    707120f07884:	mov    QWORD PTR [r12+0x1a8],r14
    707120f0788c:	mov    r14d,0x0
    707120f07892:	mov    QWORD PTR [r12+0x190],r13
    707120f0789a:	mov    QWORD PTR [r12+0x198],r14
    707120f078a2:	mov    r13,QWORD PTR [r12+0xf8]
    707120f078aa:	mov    r14,r13
    707120f078ad:	add    r14,0x1a0
    707120f078b4:	mov    r15,r14
    707120f078b7:	add    r15,0x8
    707120f078bb:	mov    rbp,QWORD PTR [r14]
    707120f078be:	mov    r14,QWORD PTR [r15]
    707120f078c1:	mov    r15d,0x0
    707120f078c7:	mov    QWORD PTR [r12+0x1c0],rbp
    707120f078cf:	mov    QWORD PTR [r12+0x1c8],r15
    707120f078d7:	mov    r15d,0x0
    707120f078dd:	mov    QWORD PTR [r12+0x1b0],r14
    707120f078e5:	mov    QWORD PTR [r12+0x1b8],r15
    707120f078ed:	add    r13,0x190
    707120f078f4:	mov    r14,r13
    707120f078f7:	add    r14,0x8
    707120f078fb:	mov    r15,QWORD PTR [r13+0x0]
    707120f078ff:	mov    r13,QWORD PTR [r14]
    707120f07902:	mov    r14d,0x0
    707120f07908:	mov    QWORD PTR [r12+0x1e0],r15
    707120f07910:	mov    QWORD PTR [r12+0x1e8],r14
    707120f07918:	mov    r14d,0x0
    707120f0791e:	mov    QWORD PTR [r12+0x1d0],r13
    707120f07926:	mov    QWORD PTR [r12+0x1d8],r14
    707120f0792e:	mov    r13,QWORD PTR [r12+0xf8]
    707120f07936:	mov    r14,r13
    707120f07939:	add    r14,0x180
    707120f07940:	mov    r15,r14
    707120f07943:	add    r15,0x8
    707120f07947:	mov    rbp,QWORD PTR [r14]
    707120f0794a:	mov    r14,QWORD PTR [r15]
    707120f0794d:	mov    r15d,0x0
    707120f07953:	mov    QWORD PTR [r12+0x200],rbp
    707120f0795b:	mov    QWORD PTR [r12+0x208],r15
    707120f07963:	mov    r15d,0x0
    707120f07969:	mov    QWORD PTR [r12+0x1f0],r14
    707120f07971:	mov    QWORD PTR [r12+0x1f8],r15
    707120f07979:	add    r13,0x1e0
    707120f07980:	mov    QWORD PTR [r12+0xf8],r13
    707120f07988:	mov    rcx,QWORD PTR [r12+0x380]
    707120f07990:	jrcxz  0x707120f07997
    707120f07992:	jmp    0x707120f09e90
    707120f07997:	mov    r13,QWORD PTR [r12+0xf0]
    707120f0799f:	mov    QWORD PTR [r12+0x100],r13
    707120f079a7:	mov    r11,QWORD PTR [rsp]
    707120f079ab:	mov    QWORD PTR [r12+0x398],r11
    707120f079b3:	mov    rdi,QWORD PTR [r12+0x100]
    707120f079bb:	add    rsp,0x150
    707120f079c2:	movabs r11,0x5ab6724ae0a0
    707120f079cc:	jmp    r11
    707120f079cf:	mov    r13d,DWORD PTR [r12+0x98]
    707120f079d7:	mov    r14d,DWORD PTR [r12]
    707120f079db:	mov    ecx,r13d
    707120f079de:	add    r14d,ecx
    707120f079e1:	mov    QWORD PTR [r12],r14
    707120f079e5:	mov    r13d,0x4103f8
    707120f079eb:	mov    QWORD PTR [r12+0xf0],r13
    707120f079f3:	mov    r13d,0x4109a4
    707120f079f9:	mov    QWORD PTR [r12+0x100],r13
    707120f07a01:	mov    r11,QWORD PTR [rsp]
    707120f07a05:	mov    QWORD PTR [r12+0x398],r11
    707120f07a0d:	mov    edi,0x4109a4
    707120f07a12:	mov    QWORD PTR [r12+0x100],rdi
    707120f07a1a:	add    rsp,0x150
    707120f07a21:	nop    DWORD PTR [rax+0x0]
    707120f07a28:	jmp    QWORD PTR [rip+0x2]        # 0x707120f07a30
    707120f07a2e:	xchg   ax,ax
    707120f07a30:	nop
    707120f07a31:	and    eax,esi
    707120f07a33:	and    BYTE PTR [rcx+0x70],dh
    707120f07a36:	add    BYTE PTR [rax],al
    707120f07a38:	rex jp 0x707120f07a2b
    707120f07a3b:	and    BYTE PTR [rcx+0x70],dh
    707120f07a3e:	add    BYTE PTR [rax],al
    707120f07a40:	movabs r11,0x5ab6724ae0a0
    707120f07a4a:	jmp    r11
    707120f07a4d:	movdqa xmm0,xmm2
    707120f07a51:	movdqa xmm1,xmm3
    707120f07a55:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07a5e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07a67:	call   0x707120f083e0
    707120f07a6c:	jmp    0x707120f03213
    707120f07a71:	movdqa xmm0,xmm2
    707120f07a75:	movdqa xmm1,xmm3
    707120f07a79:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07a82:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07a8b:	call   0x707120f083e0
    707120f07a90:	jmp    0x707120f03340
    707120f07a95:	movdqa xmm0,xmm3
    707120f07a99:	movdqa xmm1,xmm4
    707120f07a9d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07aa6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07aaf:	call   0x707120f084c0
    707120f07ab4:	jmp    0x707120f03ce1
    707120f07ab9:	movdqa xmm0,xmm2
    707120f07abd:	movdqa xmm1,xmm4
    707120f07ac1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07aca:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07ad3:	call   0x707120f08650
    707120f07ad8:	jmp    0x707120f03da0
    707120f07add:	movdqa xmm0,xmm3
    707120f07ae1:	movdqa xmm1,xmm2
    707120f07ae5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07aee:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07af7:	call   0x707120f087e0
    707120f07afc:	jmp    0x707120f03e76
    707120f07b01:	movdqa xmm0,xmm3
    707120f07b05:	movdqa xmm1,xmm2
    707120f07b09:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07b12:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07b1b:	call   0x707120f087e0
    707120f07b20:	jmp    0x707120f03f30
    707120f07b25:	movdqa xmm0,xmm2
    707120f07b29:	movdqa xmm1,xmm3
    707120f07b2d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07b36:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07b3f:	call   0x707120f087e0
    707120f07b44:	jmp    0x707120f03ff8
    707120f07b49:	movdqa xmm0,xmm2
    707120f07b4d:	movdqa xmm1,xmm3
    707120f07b51:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07b5a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07b63:	call   0x707120f08960
    707120f07b68:	jmp    0x707120f04103
    707120f07b6d:	movdqa xmm0,xmm2
    707120f07b71:	movdqa xmm1,xmm3
    707120f07b75:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07b7e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07b87:	call   0x707120f08ae0
    707120f07b8c:	jmp    0x707120f04220
    707120f07b91:	movdqa xmm0,xmm2
    707120f07b95:	movdqa xmm1,xmm3
    707120f07b99:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07ba2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07bab:	call   0x707120f08ae0
    707120f07bb0:	jmp    0x707120f042e8
    707120f07bb5:	movdqa xmm0,xmm2
    707120f07bb9:	movdqa xmm1,xmm3
    707120f07bbd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07bc6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07bcf:	call   0x707120f08ae0
    707120f07bd4:	jmp    0x707120f043a2
    707120f07bd9:	movdqa xmm0,xmm2
    707120f07bdd:	movdqa xmm1,xmm4
    707120f07be1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07bea:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07bf3:	call   0x707120f08c60
    707120f07bf8:	jmp    0x707120f045e7
    707120f07bfd:	movdqa xmm0,xmm4
    707120f07c01:	movdqa xmm1,xmm5
    707120f07c05:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07c0e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07c17:	call   0x707120f08df0
    707120f07c1c:	jmp    0x707120f0470c
    707120f07c21:	movdqa xmm0,xmm4
    707120f07c25:	movdqa xmm1,xmm5
    707120f07c29:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07c32:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07c3b:	call   0x707120f08df0
    707120f07c40:	jmp    0x707120f047d4
    707120f07c45:	movdqa xmm0,xmm3
    707120f07c49:	movdqa xmm1,xmm4
    707120f07c4d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07c56:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07c5f:	call   0x707120f08650
    707120f07c64:	jmp    0x707120f04893
    707120f07c69:	movdqa xmm0,xmm2
    707120f07c6d:	movdqa xmm1,xmm3
    707120f07c71:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07c7a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07c83:	call   0x707120f08650
    707120f07c88:	jmp    0x707120f04952
    707120f07c8d:	movdqa xmm0,xmm2
    707120f07c91:	movdqa xmm1,xmm4
    707120f07c95:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07c9e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07ca7:	call   0x707120f08650
    707120f07cac:	jmp    0x707120f04a78
    707120f07cb1:	movdqa xmm0,xmm2
    707120f07cb5:	movdqa xmm1,xmm3
    707120f07cb9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07cc2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07ccb:	call   0x707120f08960
    707120f07cd0:	jmp    0x707120f04b7f
    707120f07cd5:	movdqa xmm0,xmm3
    707120f07cd9:	movdqa xmm1,xmm4
    707120f07cdd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07ce6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07cef:	call   0x707120f08c60
    707120f07cf4:	jmp    0x707120f04d34
    707120f07cf9:	movdqa xmm0,xmm2
    707120f07cfd:	movdqa xmm1,xmm3
    707120f07d01:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07d0a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07d13:	call   0x707120f08960
    707120f07d18:	jmp    0x707120f04df3
    707120f07d1d:	movdqa xmm0,xmm3
    707120f07d21:	movdqa xmm1,xmm4
    707120f07d25:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07d2e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07d37:	call   0x707120f08c60
    707120f07d3c:	jmp    0x707120f04f20
    707120f07d41:	movdqa xmm0,xmm3
    707120f07d45:	movdqa xmm1,xmm4
    707120f07d49:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07d52:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07d5b:	call   0x707120f08c60
    707120f07d60:	jmp    0x707120f04fe8
    707120f07d65:	movdqa xmm0,xmm2
    707120f07d69:	movdqa xmm1,xmm3
    707120f07d6d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07d76:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07d7f:	call   0x707120f08960
    707120f07d84:	jmp    0x707120f050cb
    707120f07d89:	movdqa xmm0,xmm3
    707120f07d8d:	movdqa xmm1,xmm4
    707120f07d91:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07d9a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07da3:	call   0x707120f08c60
    707120f07da8:	jmp    0x707120f051f8
    707120f07dad:	movdqa xmm0,xmm3
    707120f07db1:	movdqa xmm1,xmm4
    707120f07db5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07dbe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07dc7:	call   0x707120f08650
    707120f07dcc:	jmp    0x707120f052c5
    707120f07dd1:	movdqa xmm0,xmm2
    707120f07dd5:	movdqa xmm1,xmm4
    707120f07dd9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07de2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07deb:	call   0x707120f08f80
    707120f07df0:	jmp    0x707120f05392
    707120f07df5:	movdqa xmm0,xmm3
    707120f07df9:	movdqa xmm1,xmm4
    707120f07dfd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07e06:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07e0f:	call   0x707120f08c60
    707120f07e14:	jmp    0x707120f054c1
    707120f07e19:	movdqa xmm0,xmm2
    707120f07e1d:	movdqa xmm1,xmm3
    707120f07e21:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07e2a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07e33:	call   0x707120f08960
    707120f07e38:	jmp    0x707120f055c8
    707120f07e3d:	movdqa xmm0,xmm2
    707120f07e41:	movdqa xmm1,xmm4
    707120f07e45:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07e4e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07e57:	call   0x707120f08c60
    707120f07e5c:	jmp    0x707120f056ea
    707120f07e61:	movdqa xmm0,xmm2
    707120f07e65:	movdqa xmm1,xmm3
    707120f07e69:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07e72:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07e7b:	call   0x707120f08960
    707120f07e80:	jmp    0x707120f057a9
    707120f07e85:	movdqa xmm0,xmm2
    707120f07e89:	movdqa xmm1,xmm3
    707120f07e8d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07e96:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07e9f:	call   0x707120f08ae0
    707120f07ea4:	jmp    0x707120f05871
    707120f07ea9:	movdqa xmm0,xmm2
    707120f07ead:	movdqa xmm1,xmm3
    707120f07eb1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07eba:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07ec3:	call   0x707120f08960
    707120f07ec8:	jmp    0x707120f0593e
    707120f07ecd:	movdqa xmm0,xmm2
    707120f07ed1:	movdqa xmm1,xmm3
    707120f07ed5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07ede:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07ee7:	call   0x707120f08960
    707120f07eec:	jmp    0x707120f059fd
    707120f07ef1:	movdqa xmm0,xmm2
    707120f07ef5:	movdqa xmm1,xmm4
    707120f07ef9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07f02:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07f0b:	call   0x707120f08c60
    707120f07f10:	jmp    0x707120f05ac5
    707120f07f15:	movdqa xmm0,xmm2
    707120f07f19:	movdqa xmm1,xmm4
    707120f07f1d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07f26:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07f2f:	call   0x707120f08c60
    707120f07f34:	jmp    0x707120f05b8d
    707120f07f39:	movdqa xmm0,xmm2
    707120f07f3d:	movdqa xmm1,xmm3
    707120f07f41:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07f4a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07f53:	call   0x707120f08960
    707120f07f58:	jmp    0x707120f05c4c
    707120f07f5d:	movdqa xmm0,xmm2
    707120f07f61:	movdqa xmm1,xmm3
    707120f07f65:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07f6e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07f77:	call   0x707120f08960
    707120f07f7c:	jmp    0x707120f05d0b
    707120f07f81:	movdqa xmm0,xmm2
    707120f07f85:	movdqa xmm1,xmm3
    707120f07f89:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07f92:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07f9b:	call   0x707120f08ae0
    707120f07fa0:	jmp    0x707120f05dd3
    707120f07fa5:	movdqa xmm0,xmm2
    707120f07fa9:	movdqa xmm1,xmm3
    707120f07fad:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07fb6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07fbf:	call   0x707120f08ae0
    707120f07fc4:	jmp    0x707120f05e9b
    707120f07fc9:	movdqa xmm0,xmm2
    707120f07fcd:	movdqa xmm1,xmm3
    707120f07fd1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07fda:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f07fe3:	call   0x707120f08960
    707120f07fe8:	jmp    0x707120f05f68
    707120f07fed:	movdqa xmm0,xmm2
    707120f07ff1:	movdqa xmm1,xmm3
    707120f07ff5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f07ffe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08007:	call   0x707120f08ae0
    707120f0800c:	jmp    0x707120f06030
    707120f08011:	movdqa xmm0,xmm2
    707120f08015:	movdqa xmm1,xmm3
    707120f08019:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f08022:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f0802b:	call   0x707120f08ae0
    707120f08030:	jmp    0x707120f060f8
    707120f08035:	movdqa xmm0,xmm2
    707120f08039:	movdqa xmm1,xmm3
    707120f0803d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f08046:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f0804f:	call   0x707120f08960
    707120f08054:	jmp    0x707120f06293
    707120f08059:	movdqa xmm0,xmm2
    707120f0805d:	movdqa xmm1,xmm4
    707120f08061:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f0806a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08073:	call   0x707120f08c60
    707120f08078:	jmp    0x707120f0635b
    707120f0807d:	movdqa xmm0,xmm2
    707120f08081:	movdqa xmm1,xmm4
    707120f08085:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f0808e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08097:	call   0x707120f08c60
    707120f0809c:	jmp    0x707120f06423
    707120f080a1:	movdqa xmm0,xmm2
    707120f080a5:	movdqa xmm1,xmm3
    707120f080a9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f080b2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f080bb:	call   0x707120f08960
    707120f080c0:	jmp    0x707120f064e2
    707120f080c5:	movdqa xmm0,xmm2
    707120f080c9:	movdqa xmm1,xmm3
    707120f080cd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f080d6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f080df:	call   0x707120f08960
    707120f080e4:	jmp    0x707120f065af
    707120f080e9:	movdqa xmm0,xmm2
    707120f080ed:	movdqa xmm1,xmm3
    707120f080f1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f080fa:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08103:	call   0x707120f08960
    707120f08108:	jmp    0x707120f0667c
    707120f0810d:	movdqa xmm0,xmm2
    707120f08111:	movdqa xmm1,xmm4
    707120f08115:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f0811e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08127:	call   0x707120f08c60
    707120f0812c:	jmp    0x707120f06744
    707120f08131:	movdqa xmm0,xmm2
    707120f08135:	movdqa xmm1,xmm3
    707120f08139:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f08142:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f0814b:	call   0x707120f08960
    707120f08150:	jmp    0x707120f06803
    707120f08155:	movdqa xmm0,xmm2
    707120f08159:	movdqa xmm1,xmm4
    707120f0815d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f08166:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f0816f:	call   0x707120f08c60
    707120f08174:	jmp    0x707120f068cb
    707120f08179:	movdqa xmm0,xmm2
    707120f0817d:	movdqa xmm1,xmm3
    707120f08181:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f0818a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08193:	call   0x707120f08960
    707120f08198:	jmp    0x707120f0698a
    707120f0819d:	movdqa xmm0,xmm2
    707120f081a1:	movdqa xmm1,xmm3
    707120f081a5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f081ae:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f081b7:	call   0x707120f08ae0
    707120f081bc:	jmp    0x707120f06a52
    707120f081c1:	movdqa xmm0,xmm2
    707120f081c5:	movdqa xmm1,xmm3
    707120f081c9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f081d2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f081db:	call   0x707120f08960
    707120f081e0:	jmp    0x707120f06b1f
    707120f081e5:	movdqa xmm0,xmm2
    707120f081e9:	movdqa xmm1,xmm3
    707120f081ed:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f081f6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f081ff:	call   0x707120f08ae0
    707120f08204:	jmp    0x707120f06be7
    707120f08209:	movdqa xmm0,xmm3
    707120f0820d:	movdqa xmm1,xmm4
    707120f08211:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f0821a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08223:	call   0x707120f08c60
    707120f08228:	jmp    0x707120f06d13
    707120f0822d:	movdqa xmm0,xmm2
    707120f08231:	movdqa xmm1,xmm3
    707120f08235:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f0823e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08247:	call   0x707120f08960
    707120f0824c:	jmp    0x707120f06dd2
    707120f08251:	movdqa xmm0,xmm2
    707120f08255:	movdqa xmm1,xmm3
    707120f08259:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f08262:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f0826b:	call   0x707120f08960
    707120f08270:	jmp    0x707120f06e91
    707120f08275:	movdqa xmm0,xmm2
    707120f08279:	movdqa xmm1,xmm4
    707120f0827d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f08286:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f0828f:	call   0x707120f08c60
    707120f08294:	jmp    0x707120f06f59
    707120f08299:	movdqa xmm0,xmm5
    707120f0829d:	movdqa xmm1,xmm6
    707120f082a1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f082aa:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f082b3:	call   0x707120f09100
    707120f082b8:	jmp    0x707120f07083
    707120f082bd:	movdqa xmm0,xmm4
    707120f082c1:	movdqa xmm1,xmm3
    707120f082c5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f082ce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f082d7:	call   0x707120f092a0
    707120f082dc:	jmp    0x707120f07134
    707120f082e1:	movdqa xmm0,xmm2
    707120f082e5:	movdqa xmm1,xmm3
    707120f082e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f082f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f082fb:	call   0x707120f09430
    707120f08300:	jmp    0x707120f071e5
    707120f08305:	movdqa xmm0,xmm2
    707120f08309:	movdqa xmm1,xmm3
    707120f0830d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f08316:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f0831f:	call   0x707120f095c0
    707120f08324:	jmp    0x707120f072ad
    707120f08329:	movdqa xmm0,xmm2
    707120f0832d:	movdqa xmm1,xmm3
    707120f08331:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f0833a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08343:	call   0x707120f095c0
    707120f08348:	jmp    0x707120f07375
    707120f0834d:	movdqa xmm0,xmm2
    707120f08351:	movdqa xmm1,xmm3
    707120f08355:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f0835e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f08367:	call   0x707120f095c0
    707120f0836c:	jmp    0x707120f0743d
    707120f08371:	movdqa xmm0,xmm7
    707120f08375:	movdqa xmm1,xmm2
    707120f08379:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f08382:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f0838b:	call   0x707120f09750
    707120f08390:	jmp    0x707120f074f7
    707120f08395:	movdqa xmm0,xmm2
    707120f08399:	movdqa xmm1,xmm3
    707120f0839d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f083a6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f083af:	call   0x707120f098d0
    707120f083b4:	jmp    0x707120f0772d
    707120f083b9:	movdqa xmm0,xmm4
    707120f083bd:	movdqa xmm1,xmm2
    707120f083c1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    707120f083ca:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    707120f083d3:	call   0x707120f09a50
    707120f083d8:	jmp    0x707120f0778f
    707120f083dd:	nop    DWORD PTR [rax]
    707120f083e0:	sub    rsp,0x8
    707120f083e4:	stmxcsr DWORD PTR [rsp+0x124]
    707120f083ec:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f083f4:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f083fc:	shr    r11d,1
    707120f083ff:	and    r11d,0x10
    707120f08403:	or     DWORD PTR [r12+0x314],r11d
    707120f0840b:	mov    QWORD PTR [r12+0x378],0x3
    707120f08417:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f0841d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f08423:	mov    QWORD PTR [r12+0x108],rbx
    707120f0842b:	stmxcsr DWORD PTR [r12-0x28]
    707120f08431:	ldmxcsr DWORD PTR [r12-0x38]
    707120f08437:	lea    rdi,[rsp+0x110]
    707120f0843f:	lea    rsi,[rsp+0xf0]
    707120f08447:	lea    rdx,[rsp+0x100]
    707120f0844f:	mov    ecx,0x16
    707120f08454:	mov    r8d,0x0
    707120f0845a:	lea    r9,[r12+0x314]
    707120f08462:	movabs r11,0x5ab6723191b0
    707120f0846c:	call   r11
    707120f0846f:	ldmxcsr DWORD PTR [r12-0x28]
    707120f08475:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f0847b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f08481:	mov    rbx,QWORD PTR [r12+0x108]
    707120f08489:	mov    QWORD PTR [r12+0x378],0x2
    707120f08495:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f0849e:	stmxcsr DWORD PTR [rsp+0x120]
    707120f084a6:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f084b1:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f084b9:	add    rsp,0x8
    707120f084bd:	ret
    707120f084be:	xchg   ax,ax
    707120f084c0:	sub    rsp,0x8
    707120f084c4:	stmxcsr DWORD PTR [rsp+0x124]
    707120f084cc:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f084d4:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f084dc:	shr    r11d,1
    707120f084df:	and    r11d,0x10
    707120f084e3:	or     DWORD PTR [r12+0x314],r11d
    707120f084eb:	mov    QWORD PTR [r12+0x378],0x3
    707120f084f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f084fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f08503:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    707120f08509:	push   rdx
    707120f0850a:	push   rsi
    707120f0850b:	push   r10
    707120f0850d:	push   r11
    707120f0850f:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f08514:	mov    r10d,edx
    707120f08517:	and    r10d,0xc0
    707120f0851e:	shl    r10d,0x18
    707120f08522:	mov    r11d,edx
    707120f08525:	and    r11d,0x1
    707120f08529:	shl    r11d,0x1d
    707120f0852d:	or     r10d,r11d
    707120f08530:	mov    r11d,edx
    707120f08533:	and    r11d,0x800
    707120f0853a:	shl    r11d,0x11
    707120f0853e:	or     r10d,r11d
    707120f08541:	btc    r10,0x1d
    707120f08546:	mov    r11d,0xf0000000
    707120f0854c:	and    r11,r10
    707120f0854f:	movabs rsi,0xffffffff0fffffff
    707120f08559:	and    rbx,rsi
    707120f0855c:	or     rbx,r11
    707120f0855f:	pop    r11
    707120f08561:	pop    r10
    707120f08563:	pop    rsi
    707120f08564:	pop    rdx
    707120f08565:	mov    QWORD PTR [r12+0x108],rbx
    707120f0856d:	stmxcsr DWORD PTR [r12-0x28]
    707120f08573:	ldmxcsr DWORD PTR [r12-0x38]
    707120f08579:	lea    rdi,[rsp+0x110]
    707120f08581:	lea    rsi,[rsp+0xf0]
    707120f08589:	lea    rdx,[rsp+0x100]
    707120f08591:	mov    ecx,0x16
    707120f08596:	mov    r8d,0x0
    707120f0859c:	lea    r9,[r12+0x314]
    707120f085a4:	movabs r11,0x5ab6723191b0
    707120f085ae:	call   r11
    707120f085b1:	ldmxcsr DWORD PTR [r12-0x28]
    707120f085b7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f085bd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f085c3:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    707120f085c9:	mov    rbx,QWORD PTR [r12+0x108]
    707120f085d1:	mov    QWORD PTR [r12+0x378],0x2
    707120f085dd:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f085e6:	pushf
    707120f085e7:	pop    rdx
    707120f085e8:	and    rdx,0xfffffffffffff73e
    707120f085ef:	mov    rax,rbx
    707120f085f2:	shr    rax,0x18
    707120f085f6:	and    eax,0xc0
    707120f085fb:	or     rdx,rax
    707120f085fe:	mov    rax,rbx
    707120f08601:	shr    rax,0x1d
    707120f08605:	and    eax,0x1
    707120f08608:	xor    eax,0x1
    707120f0860b:	or     rdx,rax
    707120f0860e:	mov    rax,rbx
    707120f08611:	shr    rax,0x11
    707120f08615:	and    eax,0x800
    707120f0861a:	or     rdx,rax
    707120f0861d:	mov    QWORD PTR [rsp+0x10],rdx
    707120f08622:	stmxcsr DWORD PTR [rsp+0x120]
    707120f0862a:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f08635:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f0863d:	add    rsp,0x8
    707120f08641:	ret
    707120f08642:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f08650:	sub    rsp,0x8
    707120f08654:	stmxcsr DWORD PTR [rsp+0x124]
    707120f0865c:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f08664:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f0866c:	shr    r11d,1
    707120f0866f:	and    r11d,0x10
    707120f08673:	or     DWORD PTR [r12+0x314],r11d
    707120f0867b:	mov    QWORD PTR [r12+0x378],0x3
    707120f08687:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f0868d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f08693:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    707120f08699:	push   rdx
    707120f0869a:	push   rsi
    707120f0869b:	push   r10
    707120f0869d:	push   r11
    707120f0869f:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f086a4:	mov    r10d,edx
    707120f086a7:	and    r10d,0xc0
    707120f086ae:	shl    r10d,0x18
    707120f086b2:	mov    r11d,edx
    707120f086b5:	and    r11d,0x1
    707120f086b9:	shl    r11d,0x1d
    707120f086bd:	or     r10d,r11d
    707120f086c0:	mov    r11d,edx
    707120f086c3:	and    r11d,0x800
    707120f086ca:	shl    r11d,0x11
    707120f086ce:	or     r10d,r11d
    707120f086d1:	btc    r10,0x1d
    707120f086d6:	mov    r11d,0xf0000000
    707120f086dc:	and    r11,r10
    707120f086df:	movabs rsi,0xffffffff0fffffff
    707120f086e9:	and    rbx,rsi
    707120f086ec:	or     rbx,r11
    707120f086ef:	pop    r11
    707120f086f1:	pop    r10
    707120f086f3:	pop    rsi
    707120f086f4:	pop    rdx
    707120f086f5:	mov    QWORD PTR [r12+0x108],rbx
    707120f086fd:	stmxcsr DWORD PTR [r12-0x28]
    707120f08703:	ldmxcsr DWORD PTR [r12-0x38]
    707120f08709:	lea    rdi,[rsp+0x110]
    707120f08711:	lea    rsi,[rsp+0xf0]
    707120f08719:	lea    rdx,[rsp+0x100]
    707120f08721:	mov    ecx,0x56
    707120f08726:	mov    r8d,0x0
    707120f0872c:	lea    r9,[r12+0x314]
    707120f08734:	movabs r11,0x5ab6723191b0
    707120f0873e:	call   r11
    707120f08741:	ldmxcsr DWORD PTR [r12-0x28]
    707120f08747:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f0874d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f08753:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    707120f08759:	mov    rbx,QWORD PTR [r12+0x108]
    707120f08761:	mov    QWORD PTR [r12+0x378],0x2
    707120f0876d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f08776:	pushf
    707120f08777:	pop    rdx
    707120f08778:	and    rdx,0xfffffffffffff73e
    707120f0877f:	mov    rax,rbx
    707120f08782:	shr    rax,0x18
    707120f08786:	and    eax,0xc0
    707120f0878b:	or     rdx,rax
    707120f0878e:	mov    rax,rbx
    707120f08791:	shr    rax,0x1d
    707120f08795:	and    eax,0x1
    707120f08798:	xor    eax,0x1
    707120f0879b:	or     rdx,rax
    707120f0879e:	mov    rax,rbx
    707120f087a1:	shr    rax,0x11
    707120f087a5:	and    eax,0x800
    707120f087aa:	or     rdx,rax
    707120f087ad:	mov    QWORD PTR [rsp+0x10],rdx
    707120f087b2:	stmxcsr DWORD PTR [rsp+0x120]
    707120f087ba:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f087c5:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f087cd:	add    rsp,0x8
    707120f087d1:	ret
    707120f087d2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f087e0:	sub    rsp,0x8
    707120f087e4:	stmxcsr DWORD PTR [rsp+0x124]
    707120f087ec:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f087f4:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f087fc:	shr    r11d,1
    707120f087ff:	and    r11d,0x10
    707120f08803:	or     DWORD PTR [r12+0x314],r11d
    707120f0880b:	mov    QWORD PTR [r12+0x378],0x3
    707120f08817:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f0881d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f08823:	push   rdx
    707120f08824:	push   rsi
    707120f08825:	push   r10
    707120f08827:	push   r11
    707120f08829:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f0882e:	mov    r10d,edx
    707120f08831:	and    r10d,0xc0
    707120f08838:	shl    r10d,0x18
    707120f0883c:	mov    r11d,edx
    707120f0883f:	and    r11d,0x1
    707120f08843:	shl    r11d,0x1d
    707120f08847:	or     r10d,r11d
    707120f0884a:	mov    r11d,edx
    707120f0884d:	and    r11d,0x800
    707120f08854:	shl    r11d,0x11
    707120f08858:	or     r10d,r11d
    707120f0885b:	btc    r10,0x1d
    707120f08860:	mov    r11d,0xf0000000
    707120f08866:	and    r11,r10
    707120f08869:	movabs rsi,0xffffffff0fffffff
    707120f08873:	and    rbx,rsi
    707120f08876:	or     rbx,r11
    707120f08879:	pop    r11
    707120f0887b:	pop    r10
    707120f0887d:	pop    rsi
    707120f0887e:	pop    rdx
    707120f0887f:	mov    QWORD PTR [r12+0x108],rbx
    707120f08887:	stmxcsr DWORD PTR [r12-0x28]
    707120f0888d:	ldmxcsr DWORD PTR [r12-0x38]
    707120f08893:	lea    rdi,[rsp+0x110]
    707120f0889b:	lea    rsi,[rsp+0xf0]
    707120f088a3:	lea    rdx,[rsp+0x100]
    707120f088ab:	mov    ecx,0x16
    707120f088b0:	mov    r8d,0x0
    707120f088b6:	lea    r9,[r12+0x314]
    707120f088be:	movabs r11,0x5ab6723191b0
    707120f088c8:	call   r11
    707120f088cb:	ldmxcsr DWORD PTR [r12-0x28]
    707120f088d1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f088d7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f088dd:	mov    rbx,QWORD PTR [r12+0x108]
    707120f088e5:	mov    QWORD PTR [r12+0x378],0x2
    707120f088f1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f088fa:	pushf
    707120f088fb:	pop    rdx
    707120f088fc:	and    rdx,0xfffffffffffff73e
    707120f08903:	mov    rax,rbx
    707120f08906:	shr    rax,0x18
    707120f0890a:	and    eax,0xc0
    707120f0890f:	or     rdx,rax
    707120f08912:	mov    rax,rbx
    707120f08915:	shr    rax,0x1d
    707120f08919:	and    eax,0x1
    707120f0891c:	xor    eax,0x1
    707120f0891f:	or     rdx,rax
    707120f08922:	mov    rax,rbx
    707120f08925:	shr    rax,0x11
    707120f08929:	and    eax,0x800
    707120f0892e:	or     rdx,rax
    707120f08931:	mov    QWORD PTR [rsp+0x10],rdx
    707120f08936:	stmxcsr DWORD PTR [rsp+0x120]
    707120f0893e:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f08949:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f08951:	add    rsp,0x8
    707120f08955:	ret
    707120f08956:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f08960:	sub    rsp,0x8
    707120f08964:	stmxcsr DWORD PTR [rsp+0x124]
    707120f0896c:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f08974:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f0897c:	shr    r11d,1
    707120f0897f:	and    r11d,0x10
    707120f08983:	or     DWORD PTR [r12+0x314],r11d
    707120f0898b:	mov    QWORD PTR [r12+0x378],0x3
    707120f08997:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f0899d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f089a3:	push   rdx
    707120f089a4:	push   rsi
    707120f089a5:	push   r10
    707120f089a7:	push   r11
    707120f089a9:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f089ae:	mov    r10d,edx
    707120f089b1:	and    r10d,0xc0
    707120f089b8:	shl    r10d,0x18
    707120f089bc:	mov    r11d,edx
    707120f089bf:	and    r11d,0x1
    707120f089c3:	shl    r11d,0x1d
    707120f089c7:	or     r10d,r11d
    707120f089ca:	mov    r11d,edx
    707120f089cd:	and    r11d,0x800
    707120f089d4:	shl    r11d,0x11
    707120f089d8:	or     r10d,r11d
    707120f089db:	btc    r10,0x1d
    707120f089e0:	mov    r11d,0xf0000000
    707120f089e6:	and    r11,r10
    707120f089e9:	movabs rsi,0xffffffff0fffffff
    707120f089f3:	and    rbx,rsi
    707120f089f6:	or     rbx,r11
    707120f089f9:	pop    r11
    707120f089fb:	pop    r10
    707120f089fd:	pop    rsi
    707120f089fe:	pop    rdx
    707120f089ff:	mov    QWORD PTR [r12+0x108],rbx
    707120f08a07:	stmxcsr DWORD PTR [r12-0x28]
    707120f08a0d:	ldmxcsr DWORD PTR [r12-0x38]
    707120f08a13:	lea    rdi,[rsp+0x110]
    707120f08a1b:	lea    rsi,[rsp+0xf0]
    707120f08a23:	lea    rdx,[rsp+0x100]
    707120f08a2b:	mov    ecx,0x56
    707120f08a30:	mov    r8d,0x0
    707120f08a36:	lea    r9,[r12+0x314]
    707120f08a3e:	movabs r11,0x5ab6723191b0
    707120f08a48:	call   r11
    707120f08a4b:	ldmxcsr DWORD PTR [r12-0x28]
    707120f08a51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f08a57:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f08a5d:	mov    rbx,QWORD PTR [r12+0x108]
    707120f08a65:	mov    QWORD PTR [r12+0x378],0x2
    707120f08a71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f08a7a:	pushf
    707120f08a7b:	pop    rdx
    707120f08a7c:	and    rdx,0xfffffffffffff73e
    707120f08a83:	mov    rax,rbx
    707120f08a86:	shr    rax,0x18
    707120f08a8a:	and    eax,0xc0
    707120f08a8f:	or     rdx,rax
    707120f08a92:	mov    rax,rbx
    707120f08a95:	shr    rax,0x1d
    707120f08a99:	and    eax,0x1
    707120f08a9c:	xor    eax,0x1
    707120f08a9f:	or     rdx,rax
    707120f08aa2:	mov    rax,rbx
    707120f08aa5:	shr    rax,0x11
    707120f08aa9:	and    eax,0x800
    707120f08aae:	or     rdx,rax
    707120f08ab1:	mov    QWORD PTR [rsp+0x10],rdx
    707120f08ab6:	stmxcsr DWORD PTR [rsp+0x120]
    707120f08abe:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f08ac9:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f08ad1:	add    rsp,0x8
    707120f08ad5:	ret
    707120f08ad6:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f08ae0:	sub    rsp,0x8
    707120f08ae4:	stmxcsr DWORD PTR [rsp+0x124]
    707120f08aec:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f08af4:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f08afc:	shr    r11d,1
    707120f08aff:	and    r11d,0x10
    707120f08b03:	or     DWORD PTR [r12+0x314],r11d
    707120f08b0b:	mov    QWORD PTR [r12+0x378],0x3
    707120f08b17:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f08b1d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f08b23:	push   rdx
    707120f08b24:	push   rsi
    707120f08b25:	push   r10
    707120f08b27:	push   r11
    707120f08b29:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f08b2e:	mov    r10d,edx
    707120f08b31:	and    r10d,0xc0
    707120f08b38:	shl    r10d,0x18
    707120f08b3c:	mov    r11d,edx
    707120f08b3f:	and    r11d,0x1
    707120f08b43:	shl    r11d,0x1d
    707120f08b47:	or     r10d,r11d
    707120f08b4a:	mov    r11d,edx
    707120f08b4d:	and    r11d,0x800
    707120f08b54:	shl    r11d,0x11
    707120f08b58:	or     r10d,r11d
    707120f08b5b:	btc    r10,0x1d
    707120f08b60:	mov    r11d,0xf0000000
    707120f08b66:	and    r11,r10
    707120f08b69:	movabs rsi,0xffffffff0fffffff
    707120f08b73:	and    rbx,rsi
    707120f08b76:	or     rbx,r11
    707120f08b79:	pop    r11
    707120f08b7b:	pop    r10
    707120f08b7d:	pop    rsi
    707120f08b7e:	pop    rdx
    707120f08b7f:	mov    QWORD PTR [r12+0x108],rbx
    707120f08b87:	stmxcsr DWORD PTR [r12-0x28]
    707120f08b8d:	ldmxcsr DWORD PTR [r12-0x38]
    707120f08b93:	lea    rdi,[rsp+0x110]
    707120f08b9b:	lea    rsi,[rsp+0xf0]
    707120f08ba3:	lea    rdx,[rsp+0x100]
    707120f08bab:	mov    ecx,0x14
    707120f08bb0:	mov    r8d,0x0
    707120f08bb6:	lea    r9,[r12+0x314]
    707120f08bbe:	movabs r11,0x5ab6723191b0
    707120f08bc8:	call   r11
    707120f08bcb:	ldmxcsr DWORD PTR [r12-0x28]
    707120f08bd1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f08bd7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f08bdd:	mov    rbx,QWORD PTR [r12+0x108]
    707120f08be5:	mov    QWORD PTR [r12+0x378],0x2
    707120f08bf1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f08bfa:	pushf
    707120f08bfb:	pop    rdx
    707120f08bfc:	and    rdx,0xfffffffffffff73e
    707120f08c03:	mov    rax,rbx
    707120f08c06:	shr    rax,0x18
    707120f08c0a:	and    eax,0xc0
    707120f08c0f:	or     rdx,rax
    707120f08c12:	mov    rax,rbx
    707120f08c15:	shr    rax,0x1d
    707120f08c19:	and    eax,0x1
    707120f08c1c:	xor    eax,0x1
    707120f08c1f:	or     rdx,rax
    707120f08c22:	mov    rax,rbx
    707120f08c25:	shr    rax,0x11
    707120f08c29:	and    eax,0x800
    707120f08c2e:	or     rdx,rax
    707120f08c31:	mov    QWORD PTR [rsp+0x10],rdx
    707120f08c36:	stmxcsr DWORD PTR [rsp+0x120]
    707120f08c3e:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f08c49:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f08c51:	add    rsp,0x8
    707120f08c55:	ret
    707120f08c56:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f08c60:	sub    rsp,0x8
    707120f08c64:	stmxcsr DWORD PTR [rsp+0x124]
    707120f08c6c:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f08c74:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f08c7c:	shr    r11d,1
    707120f08c7f:	and    r11d,0x10
    707120f08c83:	or     DWORD PTR [r12+0x314],r11d
    707120f08c8b:	mov    QWORD PTR [r12+0x378],0x3
    707120f08c97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f08c9d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f08ca3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    707120f08ca9:	push   rdx
    707120f08caa:	push   rsi
    707120f08cab:	push   r10
    707120f08cad:	push   r11
    707120f08caf:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f08cb4:	mov    r10d,edx
    707120f08cb7:	and    r10d,0xc0
    707120f08cbe:	shl    r10d,0x18
    707120f08cc2:	mov    r11d,edx
    707120f08cc5:	and    r11d,0x1
    707120f08cc9:	shl    r11d,0x1d
    707120f08ccd:	or     r10d,r11d
    707120f08cd0:	mov    r11d,edx
    707120f08cd3:	and    r11d,0x800
    707120f08cda:	shl    r11d,0x11
    707120f08cde:	or     r10d,r11d
    707120f08ce1:	btc    r10,0x1d
    707120f08ce6:	mov    r11d,0xf0000000
    707120f08cec:	and    r11,r10
    707120f08cef:	movabs rsi,0xffffffff0fffffff
    707120f08cf9:	and    rbx,rsi
    707120f08cfc:	or     rbx,r11
    707120f08cff:	pop    r11
    707120f08d01:	pop    r10
    707120f08d03:	pop    rsi
    707120f08d04:	pop    rdx
    707120f08d05:	mov    QWORD PTR [r12+0x108],rbx
    707120f08d0d:	stmxcsr DWORD PTR [r12-0x28]
    707120f08d13:	ldmxcsr DWORD PTR [r12-0x38]
    707120f08d19:	lea    rdi,[rsp+0x110]
    707120f08d21:	lea    rsi,[rsp+0xf0]
    707120f08d29:	lea    rdx,[rsp+0x100]
    707120f08d31:	mov    ecx,0x14
    707120f08d36:	mov    r8d,0x0
    707120f08d3c:	lea    r9,[r12+0x314]
    707120f08d44:	movabs r11,0x5ab6723191b0
    707120f08d4e:	call   r11
    707120f08d51:	ldmxcsr DWORD PTR [r12-0x28]
    707120f08d57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f08d5d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f08d63:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    707120f08d69:	mov    rbx,QWORD PTR [r12+0x108]
    707120f08d71:	mov    QWORD PTR [r12+0x378],0x2
    707120f08d7d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f08d86:	pushf
    707120f08d87:	pop    rdx
    707120f08d88:	and    rdx,0xfffffffffffff73e
    707120f08d8f:	mov    rax,rbx
    707120f08d92:	shr    rax,0x18
    707120f08d96:	and    eax,0xc0
    707120f08d9b:	or     rdx,rax
    707120f08d9e:	mov    rax,rbx
    707120f08da1:	shr    rax,0x1d
    707120f08da5:	and    eax,0x1
    707120f08da8:	xor    eax,0x1
    707120f08dab:	or     rdx,rax
    707120f08dae:	mov    rax,rbx
    707120f08db1:	shr    rax,0x11
    707120f08db5:	and    eax,0x800
    707120f08dba:	or     rdx,rax
    707120f08dbd:	mov    QWORD PTR [rsp+0x10],rdx
    707120f08dc2:	stmxcsr DWORD PTR [rsp+0x120]
    707120f08dca:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f08dd5:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f08ddd:	add    rsp,0x8
    707120f08de1:	ret
    707120f08de2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f08df0:	sub    rsp,0x8
    707120f08df4:	stmxcsr DWORD PTR [rsp+0x124]
    707120f08dfc:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f08e04:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f08e0c:	shr    r11d,1
    707120f08e0f:	and    r11d,0x10
    707120f08e13:	or     DWORD PTR [r12+0x314],r11d
    707120f08e1b:	mov    QWORD PTR [r12+0x378],0x3
    707120f08e27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f08e2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f08e33:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    707120f08e39:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    707120f08e3f:	push   rdx
    707120f08e40:	push   rsi
    707120f08e41:	push   r10
    707120f08e43:	push   r11
    707120f08e45:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f08e4a:	mov    r10d,edx
    707120f08e4d:	and    r10d,0xc0
    707120f08e54:	shl    r10d,0x18
    707120f08e58:	mov    r11d,edx
    707120f08e5b:	and    r11d,0x1
    707120f08e5f:	shl    r11d,0x1d
    707120f08e63:	or     r10d,r11d
    707120f08e66:	mov    r11d,edx
    707120f08e69:	and    r11d,0x800
    707120f08e70:	shl    r11d,0x11
    707120f08e74:	or     r10d,r11d
    707120f08e77:	btc    r10,0x1d
    707120f08e7c:	mov    r11d,0xf0000000
    707120f08e82:	and    r11,r10
    707120f08e85:	movabs rsi,0xffffffff0fffffff
    707120f08e8f:	and    rbx,rsi
    707120f08e92:	or     rbx,r11
    707120f08e95:	pop    r11
    707120f08e97:	pop    r10
    707120f08e99:	pop    rsi
    707120f08e9a:	pop    rdx
    707120f08e9b:	mov    QWORD PTR [r12+0x108],rbx
    707120f08ea3:	stmxcsr DWORD PTR [r12-0x28]
    707120f08ea9:	ldmxcsr DWORD PTR [r12-0x38]
    707120f08eaf:	lea    rdi,[rsp+0x110]
    707120f08eb7:	lea    rsi,[rsp+0xf0]
    707120f08ebf:	lea    rdx,[rsp+0x100]
    707120f08ec7:	mov    ecx,0x14
    707120f08ecc:	mov    r8d,0x0
    707120f08ed2:	lea    r9,[r12+0x314]
    707120f08eda:	movabs r11,0x5ab6723191b0
    707120f08ee4:	call   r11
    707120f08ee7:	ldmxcsr DWORD PTR [r12-0x28]
    707120f08eed:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f08ef3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f08ef9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    707120f08eff:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    707120f08f05:	mov    rbx,QWORD PTR [r12+0x108]
    707120f08f0d:	mov    QWORD PTR [r12+0x378],0x2
    707120f08f19:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f08f22:	pushf
    707120f08f23:	pop    rdx
    707120f08f24:	and    rdx,0xfffffffffffff73e
    707120f08f2b:	mov    rax,rbx
    707120f08f2e:	shr    rax,0x18
    707120f08f32:	and    eax,0xc0
    707120f08f37:	or     rdx,rax
    707120f08f3a:	mov    rax,rbx
    707120f08f3d:	shr    rax,0x1d
    707120f08f41:	and    eax,0x1
    707120f08f44:	xor    eax,0x1
    707120f08f47:	or     rdx,rax
    707120f08f4a:	mov    rax,rbx
    707120f08f4d:	shr    rax,0x11
    707120f08f51:	and    eax,0x800
    707120f08f56:	or     rdx,rax
    707120f08f59:	mov    QWORD PTR [rsp+0x10],rdx
    707120f08f5e:	stmxcsr DWORD PTR [rsp+0x120]
    707120f08f66:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f08f71:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f08f79:	add    rsp,0x8
    707120f08f7d:	ret
    707120f08f7e:	xchg   ax,ax
    707120f08f80:	sub    rsp,0x8
    707120f08f84:	stmxcsr DWORD PTR [rsp+0x124]
    707120f08f8c:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f08f94:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f08f9c:	shr    r11d,1
    707120f08f9f:	and    r11d,0x10
    707120f08fa3:	or     DWORD PTR [r12+0x314],r11d
    707120f08fab:	mov    QWORD PTR [r12+0x378],0x3
    707120f08fb7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f08fbd:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    707120f08fc3:	push   rdx
    707120f08fc4:	push   rsi
    707120f08fc5:	push   r10
    707120f08fc7:	push   r11
    707120f08fc9:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f08fce:	mov    r10d,edx
    707120f08fd1:	and    r10d,0xc0
    707120f08fd8:	shl    r10d,0x18
    707120f08fdc:	mov    r11d,edx
    707120f08fdf:	and    r11d,0x1
    707120f08fe3:	shl    r11d,0x1d
    707120f08fe7:	or     r10d,r11d
    707120f08fea:	mov    r11d,edx
    707120f08fed:	and    r11d,0x800
    707120f08ff4:	shl    r11d,0x11
    707120f08ff8:	or     r10d,r11d
    707120f08ffb:	btc    r10,0x1d
    707120f09000:	mov    r11d,0xf0000000
    707120f09006:	and    r11,r10
    707120f09009:	movabs rsi,0xffffffff0fffffff
    707120f09013:	and    rbx,rsi
    707120f09016:	or     rbx,r11
    707120f09019:	pop    r11
    707120f0901b:	pop    r10
    707120f0901d:	pop    rsi
    707120f0901e:	pop    rdx
    707120f0901f:	mov    QWORD PTR [r12+0x108],rbx
    707120f09027:	stmxcsr DWORD PTR [r12-0x28]
    707120f0902d:	ldmxcsr DWORD PTR [r12-0x38]
    707120f09033:	lea    rdi,[rsp+0x110]
    707120f0903b:	lea    rsi,[rsp+0xf0]
    707120f09043:	lea    rdx,[rsp+0x100]
    707120f0904b:	mov    ecx,0x56
    707120f09050:	mov    r8d,0x0
    707120f09056:	lea    r9,[r12+0x314]
    707120f0905e:	movabs r11,0x5ab6723191b0
    707120f09068:	call   r11
    707120f0906b:	ldmxcsr DWORD PTR [r12-0x28]
    707120f09071:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f09077:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    707120f0907d:	mov    rbx,QWORD PTR [r12+0x108]
    707120f09085:	mov    QWORD PTR [r12+0x378],0x2
    707120f09091:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f0909a:	pushf
    707120f0909b:	pop    rdx
    707120f0909c:	and    rdx,0xfffffffffffff73e
    707120f090a3:	mov    rax,rbx
    707120f090a6:	shr    rax,0x18
    707120f090aa:	and    eax,0xc0
    707120f090af:	or     rdx,rax
    707120f090b2:	mov    rax,rbx
    707120f090b5:	shr    rax,0x1d
    707120f090b9:	and    eax,0x1
    707120f090bc:	xor    eax,0x1
    707120f090bf:	or     rdx,rax
    707120f090c2:	mov    rax,rbx
    707120f090c5:	shr    rax,0x11
    707120f090c9:	and    eax,0x800
    707120f090ce:	or     rdx,rax
    707120f090d1:	mov    QWORD PTR [rsp+0x10],rdx
    707120f090d6:	stmxcsr DWORD PTR [rsp+0x120]
    707120f090de:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f090e9:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f090f1:	add    rsp,0x8
    707120f090f5:	ret
    707120f090f6:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f09100:	sub    rsp,0x8
    707120f09104:	stmxcsr DWORD PTR [rsp+0x124]
    707120f0910c:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f09114:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f0911c:	shr    r11d,1
    707120f0911f:	and    r11d,0x10
    707120f09123:	or     DWORD PTR [r12+0x314],r11d
    707120f0912b:	mov    QWORD PTR [r12+0x378],0x3
    707120f09137:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f0913d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f09143:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    707120f09149:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    707120f0914f:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    707120f09155:	push   rdx
    707120f09156:	push   rsi
    707120f09157:	push   r10
    707120f09159:	push   r11
    707120f0915b:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f09160:	mov    r10d,edx
    707120f09163:	and    r10d,0xc0
    707120f0916a:	shl    r10d,0x18
    707120f0916e:	mov    r11d,edx
    707120f09171:	and    r11d,0x1
    707120f09175:	shl    r11d,0x1d
    707120f09179:	or     r10d,r11d
    707120f0917c:	mov    r11d,edx
    707120f0917f:	and    r11d,0x800
    707120f09186:	shl    r11d,0x11
    707120f0918a:	or     r10d,r11d
    707120f0918d:	btc    r10,0x1d
    707120f09192:	mov    r11d,0xf0000000
    707120f09198:	and    r11,r10
    707120f0919b:	movabs rsi,0xffffffff0fffffff
    707120f091a5:	and    rbx,rsi
    707120f091a8:	or     rbx,r11
    707120f091ab:	pop    r11
    707120f091ad:	pop    r10
    707120f091af:	pop    rsi
    707120f091b0:	pop    rdx
    707120f091b1:	mov    QWORD PTR [r12+0x108],rbx
    707120f091b9:	stmxcsr DWORD PTR [r12-0x28]
    707120f091bf:	ldmxcsr DWORD PTR [r12-0x38]
    707120f091c5:	lea    rdi,[rsp+0x110]
    707120f091cd:	lea    rsi,[rsp+0xf0]
    707120f091d5:	lea    rdx,[rsp+0x100]
    707120f091dd:	mov    ecx,0x14
    707120f091e2:	mov    r8d,0x0
    707120f091e8:	lea    r9,[r12+0x314]
    707120f091f0:	movabs r11,0x5ab6723191b0
    707120f091fa:	call   r11
    707120f091fd:	ldmxcsr DWORD PTR [r12-0x28]
    707120f09203:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f09209:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f0920f:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    707120f09215:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    707120f0921b:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    707120f09221:	mov    rbx,QWORD PTR [r12+0x108]
    707120f09229:	mov    QWORD PTR [r12+0x378],0x2
    707120f09235:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f0923e:	pushf
    707120f0923f:	pop    rdx
    707120f09240:	and    rdx,0xfffffffffffff73e
    707120f09247:	mov    rax,rbx
    707120f0924a:	shr    rax,0x18
    707120f0924e:	and    eax,0xc0
    707120f09253:	or     rdx,rax
    707120f09256:	mov    rax,rbx
    707120f09259:	shr    rax,0x1d
    707120f0925d:	and    eax,0x1
    707120f09260:	xor    eax,0x1
    707120f09263:	or     rdx,rax
    707120f09266:	mov    rax,rbx
    707120f09269:	shr    rax,0x11
    707120f0926d:	and    eax,0x800
    707120f09272:	or     rdx,rax
    707120f09275:	mov    QWORD PTR [rsp+0x10],rdx
    707120f0927a:	stmxcsr DWORD PTR [rsp+0x120]
    707120f09282:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f0928d:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f09295:	add    rsp,0x8
    707120f09299:	ret
    707120f0929a:	nop    WORD PTR [rax+rax*1+0x0]
    707120f092a0:	sub    rsp,0x8
    707120f092a4:	stmxcsr DWORD PTR [rsp+0x124]
    707120f092ac:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f092b4:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f092bc:	shr    r11d,1
    707120f092bf:	and    r11d,0x10
    707120f092c3:	or     DWORD PTR [r12+0x314],r11d
    707120f092cb:	mov    QWORD PTR [r12+0x378],0x3
    707120f092d7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f092dd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f092e3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    707120f092e9:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    707120f092ef:	push   rdx
    707120f092f0:	push   rsi
    707120f092f1:	push   r10
    707120f092f3:	push   r11
    707120f092f5:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f092fa:	mov    r10d,edx
    707120f092fd:	and    r10d,0xc0
    707120f09304:	shl    r10d,0x18
    707120f09308:	mov    r11d,edx
    707120f0930b:	and    r11d,0x1
    707120f0930f:	shl    r11d,0x1d
    707120f09313:	or     r10d,r11d
    707120f09316:	mov    r11d,edx
    707120f09319:	and    r11d,0x800
    707120f09320:	shl    r11d,0x11
    707120f09324:	or     r10d,r11d
    707120f09327:	btc    r10,0x1d
    707120f0932c:	mov    r11d,0xf0000000
    707120f09332:	and    r11,r10
    707120f09335:	movabs rsi,0xffffffff0fffffff
    707120f0933f:	and    rbx,rsi
    707120f09342:	or     rbx,r11
    707120f09345:	pop    r11
    707120f09347:	pop    r10
    707120f09349:	pop    rsi
    707120f0934a:	pop    rdx
    707120f0934b:	mov    QWORD PTR [r12+0x108],rbx
    707120f09353:	stmxcsr DWORD PTR [r12-0x28]
    707120f09359:	ldmxcsr DWORD PTR [r12-0x38]
    707120f0935f:	lea    rdi,[rsp+0x110]
    707120f09367:	lea    rsi,[rsp+0xf0]
    707120f0936f:	lea    rdx,[rsp+0x100]
    707120f09377:	mov    ecx,0x56
    707120f0937c:	mov    r8d,0x0
    707120f09382:	lea    r9,[r12+0x314]
    707120f0938a:	movabs r11,0x5ab6723191b0
    707120f09394:	call   r11
    707120f09397:	ldmxcsr DWORD PTR [r12-0x28]
    707120f0939d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f093a3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f093a9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    707120f093af:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    707120f093b5:	mov    rbx,QWORD PTR [r12+0x108]
    707120f093bd:	mov    QWORD PTR [r12+0x378],0x2
    707120f093c9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f093d2:	pushf
    707120f093d3:	pop    rdx
    707120f093d4:	and    rdx,0xfffffffffffff73e
    707120f093db:	mov    rax,rbx
    707120f093de:	shr    rax,0x18
    707120f093e2:	and    eax,0xc0
    707120f093e7:	or     rdx,rax
    707120f093ea:	mov    rax,rbx
    707120f093ed:	shr    rax,0x1d
    707120f093f1:	and    eax,0x1
    707120f093f4:	xor    eax,0x1
    707120f093f7:	or     rdx,rax
    707120f093fa:	mov    rax,rbx
    707120f093fd:	shr    rax,0x11
    707120f09401:	and    eax,0x800
    707120f09406:	or     rdx,rax
    707120f09409:	mov    QWORD PTR [rsp+0x10],rdx
    707120f0940e:	stmxcsr DWORD PTR [rsp+0x120]
    707120f09416:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f09421:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f09429:	add    rsp,0x8
    707120f0942d:	ret
    707120f0942e:	xchg   ax,ax
    707120f09430:	sub    rsp,0x8
    707120f09434:	stmxcsr DWORD PTR [rsp+0x124]
    707120f0943c:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f09444:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f0944c:	shr    r11d,1
    707120f0944f:	and    r11d,0x10
    707120f09453:	or     DWORD PTR [r12+0x314],r11d
    707120f0945b:	mov    QWORD PTR [r12+0x378],0x3
    707120f09467:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f0946d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f09473:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    707120f09479:	push   rdx
    707120f0947a:	push   rsi
    707120f0947b:	push   r10
    707120f0947d:	push   r11
    707120f0947f:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f09484:	mov    r10d,edx
    707120f09487:	and    r10d,0xc0
    707120f0948e:	shl    r10d,0x18
    707120f09492:	mov    r11d,edx
    707120f09495:	and    r11d,0x1
    707120f09499:	shl    r11d,0x1d
    707120f0949d:	or     r10d,r11d
    707120f094a0:	mov    r11d,edx
    707120f094a3:	and    r11d,0x800
    707120f094aa:	shl    r11d,0x11
    707120f094ae:	or     r10d,r11d
    707120f094b1:	btc    r10,0x1d
    707120f094b6:	mov    r11d,0xf0000000
    707120f094bc:	and    r11,r10
    707120f094bf:	movabs rsi,0xffffffff0fffffff
    707120f094c9:	and    rbx,rsi
    707120f094cc:	or     rbx,r11
    707120f094cf:	pop    r11
    707120f094d1:	pop    r10
    707120f094d3:	pop    rsi
    707120f094d4:	pop    rdx
    707120f094d5:	mov    QWORD PTR [r12+0x108],rbx
    707120f094dd:	stmxcsr DWORD PTR [r12-0x28]
    707120f094e3:	ldmxcsr DWORD PTR [r12-0x38]
    707120f094e9:	lea    rdi,[rsp+0x110]
    707120f094f1:	lea    rsi,[rsp+0xf0]
    707120f094f9:	lea    rdx,[rsp+0x100]
    707120f09501:	mov    ecx,0x56
    707120f09506:	mov    r8d,0x0
    707120f0950c:	lea    r9,[r12+0x314]
    707120f09514:	movabs r11,0x5ab6723191b0
    707120f0951e:	call   r11
    707120f09521:	ldmxcsr DWORD PTR [r12-0x28]
    707120f09527:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f0952d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f09533:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    707120f09539:	mov    rbx,QWORD PTR [r12+0x108]
    707120f09541:	mov    QWORD PTR [r12+0x378],0x2
    707120f0954d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f09556:	pushf
    707120f09557:	pop    rdx
    707120f09558:	and    rdx,0xfffffffffffff73e
    707120f0955f:	mov    rax,rbx
    707120f09562:	shr    rax,0x18
    707120f09566:	and    eax,0xc0
    707120f0956b:	or     rdx,rax
    707120f0956e:	mov    rax,rbx
    707120f09571:	shr    rax,0x1d
    707120f09575:	and    eax,0x1
    707120f09578:	xor    eax,0x1
    707120f0957b:	or     rdx,rax
    707120f0957e:	mov    rax,rbx
    707120f09581:	shr    rax,0x11
    707120f09585:	and    eax,0x800
    707120f0958a:	or     rdx,rax
    707120f0958d:	mov    QWORD PTR [rsp+0x10],rdx
    707120f09592:	stmxcsr DWORD PTR [rsp+0x120]
    707120f0959a:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f095a5:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f095ad:	add    rsp,0x8
    707120f095b1:	ret
    707120f095b2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f095c0:	sub    rsp,0x8
    707120f095c4:	stmxcsr DWORD PTR [rsp+0x124]
    707120f095cc:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f095d4:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f095dc:	shr    r11d,1
    707120f095df:	and    r11d,0x10
    707120f095e3:	or     DWORD PTR [r12+0x314],r11d
    707120f095eb:	mov    QWORD PTR [r12+0x378],0x3
    707120f095f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f095fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f09603:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    707120f09609:	push   rdx
    707120f0960a:	push   rsi
    707120f0960b:	push   r10
    707120f0960d:	push   r11
    707120f0960f:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f09614:	mov    r10d,edx
    707120f09617:	and    r10d,0xc0
    707120f0961e:	shl    r10d,0x18
    707120f09622:	mov    r11d,edx
    707120f09625:	and    r11d,0x1
    707120f09629:	shl    r11d,0x1d
    707120f0962d:	or     r10d,r11d
    707120f09630:	mov    r11d,edx
    707120f09633:	and    r11d,0x800
    707120f0963a:	shl    r11d,0x11
    707120f0963e:	or     r10d,r11d
    707120f09641:	btc    r10,0x1d
    707120f09646:	mov    r11d,0xf0000000
    707120f0964c:	and    r11,r10
    707120f0964f:	movabs rsi,0xffffffff0fffffff
    707120f09659:	and    rbx,rsi
    707120f0965c:	or     rbx,r11
    707120f0965f:	pop    r11
    707120f09661:	pop    r10
    707120f09663:	pop    rsi
    707120f09664:	pop    rdx
    707120f09665:	mov    QWORD PTR [r12+0x108],rbx
    707120f0966d:	stmxcsr DWORD PTR [r12-0x28]
    707120f09673:	ldmxcsr DWORD PTR [r12-0x38]
    707120f09679:	lea    rdi,[rsp+0x110]
    707120f09681:	lea    rsi,[rsp+0xf0]
    707120f09689:	lea    rdx,[rsp+0x100]
    707120f09691:	mov    ecx,0x14
    707120f09696:	mov    r8d,0x0
    707120f0969c:	lea    r9,[r12+0x314]
    707120f096a4:	movabs r11,0x5ab6723191b0
    707120f096ae:	call   r11
    707120f096b1:	ldmxcsr DWORD PTR [r12-0x28]
    707120f096b7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f096bd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f096c3:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    707120f096c9:	mov    rbx,QWORD PTR [r12+0x108]
    707120f096d1:	mov    QWORD PTR [r12+0x378],0x2
    707120f096dd:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f096e6:	pushf
    707120f096e7:	pop    rdx
    707120f096e8:	and    rdx,0xfffffffffffff73e
    707120f096ef:	mov    rax,rbx
    707120f096f2:	shr    rax,0x18
    707120f096f6:	and    eax,0xc0
    707120f096fb:	or     rdx,rax
    707120f096fe:	mov    rax,rbx
    707120f09701:	shr    rax,0x1d
    707120f09705:	and    eax,0x1
    707120f09708:	xor    eax,0x1
    707120f0970b:	or     rdx,rax
    707120f0970e:	mov    rax,rbx
    707120f09711:	shr    rax,0x11
    707120f09715:	and    eax,0x800
    707120f0971a:	or     rdx,rax
    707120f0971d:	mov    QWORD PTR [rsp+0x10],rdx
    707120f09722:	stmxcsr DWORD PTR [rsp+0x120]
    707120f0972a:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f09735:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f0973d:	add    rsp,0x8
    707120f09741:	ret
    707120f09742:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f09750:	sub    rsp,0x8
    707120f09754:	stmxcsr DWORD PTR [rsp+0x124]
    707120f0975c:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f09764:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f0976c:	shr    r11d,1
    707120f0976f:	and    r11d,0x10
    707120f09773:	or     DWORD PTR [r12+0x314],r11d
    707120f0977b:	mov    QWORD PTR [r12+0x378],0x3
    707120f09787:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f0978d:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    707120f09793:	push   rdx
    707120f09794:	push   rsi
    707120f09795:	push   r10
    707120f09797:	push   r11
    707120f09799:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f0979e:	mov    r10d,edx
    707120f097a1:	and    r10d,0xc0
    707120f097a8:	shl    r10d,0x18
    707120f097ac:	mov    r11d,edx
    707120f097af:	and    r11d,0x1
    707120f097b3:	shl    r11d,0x1d
    707120f097b7:	or     r10d,r11d
    707120f097ba:	mov    r11d,edx
    707120f097bd:	and    r11d,0x800
    707120f097c4:	shl    r11d,0x11
    707120f097c8:	or     r10d,r11d
    707120f097cb:	btc    r10,0x1d
    707120f097d0:	mov    r11d,0xf0000000
    707120f097d6:	and    r11,r10
    707120f097d9:	movabs rsi,0xffffffff0fffffff
    707120f097e3:	and    rbx,rsi
    707120f097e6:	or     rbx,r11
    707120f097e9:	pop    r11
    707120f097eb:	pop    r10
    707120f097ed:	pop    rsi
    707120f097ee:	pop    rdx
    707120f097ef:	mov    QWORD PTR [r12+0x108],rbx
    707120f097f7:	stmxcsr DWORD PTR [r12-0x28]
    707120f097fd:	ldmxcsr DWORD PTR [r12-0x38]
    707120f09803:	lea    rdi,[rsp+0x110]
    707120f0980b:	lea    rsi,[rsp+0xf0]
    707120f09813:	lea    rdx,[rsp+0x100]
    707120f0981b:	mov    ecx,0x14
    707120f09820:	mov    r8d,0x0
    707120f09826:	lea    r9,[r12+0x314]
    707120f0982e:	movabs r11,0x5ab6723191b0
    707120f09838:	call   r11
    707120f0983b:	ldmxcsr DWORD PTR [r12-0x28]
    707120f09841:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f09847:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    707120f0984d:	mov    rbx,QWORD PTR [r12+0x108]
    707120f09855:	mov    QWORD PTR [r12+0x378],0x2
    707120f09861:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f0986a:	pushf
    707120f0986b:	pop    rdx
    707120f0986c:	and    rdx,0xfffffffffffff73e
    707120f09873:	mov    rax,rbx
    707120f09876:	shr    rax,0x18
    707120f0987a:	and    eax,0xc0
    707120f0987f:	or     rdx,rax
    707120f09882:	mov    rax,rbx
    707120f09885:	shr    rax,0x1d
    707120f09889:	and    eax,0x1
    707120f0988c:	xor    eax,0x1
    707120f0988f:	or     rdx,rax
    707120f09892:	mov    rax,rbx
    707120f09895:	shr    rax,0x11
    707120f09899:	and    eax,0x800
    707120f0989e:	or     rdx,rax
    707120f098a1:	mov    QWORD PTR [rsp+0x10],rdx
    707120f098a6:	stmxcsr DWORD PTR [rsp+0x120]
    707120f098ae:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f098b9:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f098c1:	add    rsp,0x8
    707120f098c5:	ret
    707120f098c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f098d0:	sub    rsp,0x8
    707120f098d4:	stmxcsr DWORD PTR [rsp+0x124]
    707120f098dc:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f098e4:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f098ec:	shr    r11d,1
    707120f098ef:	and    r11d,0x10
    707120f098f3:	or     DWORD PTR [r12+0x314],r11d
    707120f098fb:	mov    QWORD PTR [r12+0x378],0x3
    707120f09907:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f0990d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    707120f09913:	push   rdx
    707120f09914:	push   rsi
    707120f09915:	push   r10
    707120f09917:	push   r11
    707120f09919:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f0991e:	mov    r10d,edx
    707120f09921:	and    r10d,0xc0
    707120f09928:	shl    r10d,0x18
    707120f0992c:	mov    r11d,edx
    707120f0992f:	and    r11d,0x1
    707120f09933:	shl    r11d,0x1d
    707120f09937:	or     r10d,r11d
    707120f0993a:	mov    r11d,edx
    707120f0993d:	and    r11d,0x800
    707120f09944:	shl    r11d,0x11
    707120f09948:	or     r10d,r11d
    707120f0994b:	btc    r10,0x1d
    707120f09950:	mov    r11d,0xf0000000
    707120f09956:	and    r11,r10
    707120f09959:	movabs rsi,0xffffffff0fffffff
    707120f09963:	and    rbx,rsi
    707120f09966:	or     rbx,r11
    707120f09969:	pop    r11
    707120f0996b:	pop    r10
    707120f0996d:	pop    rsi
    707120f0996e:	pop    rdx
    707120f0996f:	mov    QWORD PTR [r12+0x108],rbx
    707120f09977:	stmxcsr DWORD PTR [r12-0x28]
    707120f0997d:	ldmxcsr DWORD PTR [r12-0x38]
    707120f09983:	lea    rdi,[rsp+0x110]
    707120f0998b:	lea    rsi,[rsp+0xf0]
    707120f09993:	lea    rdx,[rsp+0x100]
    707120f0999b:	mov    ecx,0xc
    707120f099a0:	mov    r8d,0x0
    707120f099a6:	lea    r9,[r12+0x314]
    707120f099ae:	movabs r11,0x5ab6723191b0
    707120f099b8:	call   r11
    707120f099bb:	ldmxcsr DWORD PTR [r12-0x28]
    707120f099c1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f099c7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    707120f099cd:	mov    rbx,QWORD PTR [r12+0x108]
    707120f099d5:	mov    QWORD PTR [r12+0x378],0x2
    707120f099e1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f099ea:	pushf
    707120f099eb:	pop    rdx
    707120f099ec:	and    rdx,0xfffffffffffff73e
    707120f099f3:	mov    rax,rbx
    707120f099f6:	shr    rax,0x18
    707120f099fa:	and    eax,0xc0
    707120f099ff:	or     rdx,rax
    707120f09a02:	mov    rax,rbx
    707120f09a05:	shr    rax,0x1d
    707120f09a09:	and    eax,0x1
    707120f09a0c:	xor    eax,0x1
    707120f09a0f:	or     rdx,rax
    707120f09a12:	mov    rax,rbx
    707120f09a15:	shr    rax,0x11
    707120f09a19:	and    eax,0x800
    707120f09a1e:	or     rdx,rax
    707120f09a21:	mov    QWORD PTR [rsp+0x10],rdx
    707120f09a26:	stmxcsr DWORD PTR [rsp+0x120]
    707120f09a2e:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f09a39:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f09a41:	add    rsp,0x8
    707120f09a45:	ret
    707120f09a46:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f09a50:	sub    rsp,0x8
    707120f09a54:	stmxcsr DWORD PTR [rsp+0x124]
    707120f09a5c:	ldmxcsr DWORD PTR [rsp+0x120]
    707120f09a64:	mov    r11d,DWORD PTR [rsp+0x124]
    707120f09a6c:	shr    r11d,1
    707120f09a6f:	and    r11d,0x10
    707120f09a73:	or     DWORD PTR [r12+0x314],r11d
    707120f09a7b:	mov    QWORD PTR [r12+0x378],0x3
    707120f09a87:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    707120f09a8d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    707120f09a93:	push   rdx
    707120f09a94:	push   rsi
    707120f09a95:	push   r10
    707120f09a97:	push   r11
    707120f09a99:	mov    rdx,QWORD PTR [rsp+0x30]
    707120f09a9e:	mov    r10d,edx
    707120f09aa1:	and    r10d,0xc0
    707120f09aa8:	shl    r10d,0x18
    707120f09aac:	mov    r11d,edx
    707120f09aaf:	and    r11d,0x1
    707120f09ab3:	shl    r11d,0x1d
    707120f09ab7:	or     r10d,r11d
    707120f09aba:	mov    r11d,edx
    707120f09abd:	and    r11d,0x800
    707120f09ac4:	shl    r11d,0x11
    707120f09ac8:	or     r10d,r11d
    707120f09acb:	btc    r10,0x1d
    707120f09ad0:	mov    r11d,0xf0000000
    707120f09ad6:	and    r11,r10
    707120f09ad9:	movabs rsi,0xffffffff0fffffff
    707120f09ae3:	and    rbx,rsi
    707120f09ae6:	or     rbx,r11
    707120f09ae9:	pop    r11
    707120f09aeb:	pop    r10
    707120f09aed:	pop    rsi
    707120f09aee:	pop    rdx
    707120f09aef:	mov    QWORD PTR [r12+0x108],rbx
    707120f09af7:	stmxcsr DWORD PTR [r12-0x28]
    707120f09afd:	ldmxcsr DWORD PTR [r12-0x38]
    707120f09b03:	lea    rdi,[rsp+0x110]
    707120f09b0b:	lea    rsi,[rsp+0xf0]
    707120f09b13:	lea    rdx,[rsp+0x100]
    707120f09b1b:	mov    ecx,0xc
    707120f09b20:	mov    r8d,0x0
    707120f09b26:	lea    r9,[r12+0x314]
    707120f09b2e:	movabs r11,0x5ab6723191b0
    707120f09b38:	call   r11
    707120f09b3b:	ldmxcsr DWORD PTR [r12-0x28]
    707120f09b41:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    707120f09b47:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    707120f09b4d:	mov    rbx,QWORD PTR [r12+0x108]
    707120f09b55:	mov    QWORD PTR [r12+0x378],0x2
    707120f09b61:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707120f09b6a:	pushf
    707120f09b6b:	pop    rdx
    707120f09b6c:	and    rdx,0xfffffffffffff73e
    707120f09b73:	mov    rax,rbx
    707120f09b76:	shr    rax,0x18
    707120f09b7a:	and    eax,0xc0
    707120f09b7f:	or     rdx,rax
    707120f09b82:	mov    rax,rbx
    707120f09b85:	shr    rax,0x1d
    707120f09b89:	and    eax,0x1
    707120f09b8c:	xor    eax,0x1
    707120f09b8f:	or     rdx,rax
    707120f09b92:	mov    rax,rbx
    707120f09b95:	shr    rax,0x11
    707120f09b99:	and    eax,0x800
    707120f09b9e:	or     rdx,rax
    707120f09ba1:	mov    QWORD PTR [rsp+0x10],rdx
    707120f09ba6:	stmxcsr DWORD PTR [rsp+0x120]
    707120f09bae:	mov    DWORD PTR [rsp+0x124],0x1f80
    707120f09bb9:	ldmxcsr DWORD PTR [rsp+0x124]
    707120f09bc1:	add    rsp,0x8
    707120f09bc5:	ret
    707120f09bc6:	mov    eax,0x410400
    707120f09bcb:	mov    QWORD PTR [r12+0x100],rax
    707120f09bd3:	push   rdx
    707120f09bd4:	push   rsi
    707120f09bd5:	push   r10
    707120f09bd7:	push   r11
    707120f09bd9:	pushf
    707120f09bda:	pop    r11
    707120f09bdc:	mov    QWORD PTR [rsp+0x20],r11
    707120f09be1:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f09be6:	mov    r10d,edx
    707120f09be9:	and    r10d,0xc0
    707120f09bf0:	shl    r10d,0x18
    707120f09bf4:	mov    r11d,edx
    707120f09bf7:	and    r11d,0x1
    707120f09bfb:	shl    r11d,0x1d
    707120f09bff:	or     r10d,r11d
    707120f09c02:	mov    r11d,edx
    707120f09c05:	and    r11d,0x800
    707120f09c0c:	shl    r11d,0x11
    707120f09c10:	or     r10d,r11d
    707120f09c13:	btc    r10,0x1d
    707120f09c18:	mov    r11d,0xf0000000
    707120f09c1e:	and    r11,r10
    707120f09c21:	movabs rsi,0xffffffff0fffffff
    707120f09c2b:	and    rbx,rsi
    707120f09c2e:	or     rbx,r11
    707120f09c31:	pop    r11
    707120f09c33:	pop    r10
    707120f09c35:	pop    rsi
    707120f09c36:	pop    rdx
    707120f09c37:	mov    QWORD PTR [r12+0x108],rbx
    707120f09c3f:	add    rsp,0x150
    707120f09c46:	mov    eax,0xc
    707120f09c4b:	movabs r11,0x5ab6724ae390
    707120f09c55:	jmp    r11
    707120f09c58:	mov    eax,0x41048c
    707120f09c5d:	mov    QWORD PTR [r12+0x100],rax
    707120f09c65:	push   rdx
    707120f09c66:	push   rsi
    707120f09c67:	push   r10
    707120f09c69:	push   r11
    707120f09c6b:	pushf
    707120f09c6c:	pop    r11
    707120f09c6e:	mov    QWORD PTR [rsp+0x20],r11
    707120f09c73:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f09c78:	mov    r10d,edx
    707120f09c7b:	and    r10d,0xc0
    707120f09c82:	shl    r10d,0x18
    707120f09c86:	mov    r11d,edx
    707120f09c89:	and    r11d,0x1
    707120f09c8d:	shl    r11d,0x1d
    707120f09c91:	or     r10d,r11d
    707120f09c94:	mov    r11d,edx
    707120f09c97:	and    r11d,0x800
    707120f09c9e:	shl    r11d,0x11
    707120f09ca2:	or     r10d,r11d
    707120f09ca5:	btc    r10,0x1d
    707120f09caa:	mov    r11d,0xf0000000
    707120f09cb0:	and    r11,r10
    707120f09cb3:	movabs rsi,0xffffffff0fffffff
    707120f09cbd:	and    rbx,rsi
    707120f09cc0:	or     rbx,r11
    707120f09cc3:	pop    r11
    707120f09cc5:	pop    r10
    707120f09cc7:	pop    rsi
    707120f09cc8:	pop    rdx
    707120f09cc9:	mov    QWORD PTR [r12+0x108],rbx
    707120f09cd1:	add    rsp,0x150
    707120f09cd8:	mov    eax,0xc
    707120f09cdd:	movabs r11,0x5ab6724ae390
    707120f09ce7:	jmp    r11
    707120f09cea:	mov    eax,0x4106cc
    707120f09cef:	mov    QWORD PTR [r12+0x100],rax
    707120f09cf7:	push   rdx
    707120f09cf8:	push   rsi
    707120f09cf9:	push   r10
    707120f09cfb:	push   r11
    707120f09cfd:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f09d02:	mov    r10d,edx
    707120f09d05:	and    r10d,0xc0
    707120f09d0c:	shl    r10d,0x18
    707120f09d10:	mov    r11d,edx
    707120f09d13:	and    r11d,0x1
    707120f09d17:	shl    r11d,0x1d
    707120f09d1b:	or     r10d,r11d
    707120f09d1e:	mov    r11d,edx
    707120f09d21:	and    r11d,0x800
    707120f09d28:	shl    r11d,0x11
    707120f09d2c:	or     r10d,r11d
    707120f09d2f:	btc    r10,0x1d
    707120f09d34:	mov    r11d,0xf0000000
    707120f09d3a:	and    r11,r10
    707120f09d3d:	movabs rsi,0xffffffff0fffffff
    707120f09d47:	and    rbx,rsi
    707120f09d4a:	or     rbx,r11
    707120f09d4d:	pop    r11
    707120f09d4f:	pop    r10
    707120f09d51:	pop    rsi
    707120f09d52:	pop    rdx
    707120f09d53:	mov    QWORD PTR [r12+0x108],rbx
    707120f09d5b:	add    rsp,0x150
    707120f09d62:	mov    eax,0xc
    707120f09d67:	movabs r11,0x5ab6724ae390
    707120f09d71:	jmp    r11
    707120f09d74:	mov    eax,0x4106d8
    707120f09d79:	mov    QWORD PTR [r12+0x100],rax
    707120f09d81:	push   rdx
    707120f09d82:	push   rsi
    707120f09d83:	push   r10
    707120f09d85:	push   r11
    707120f09d87:	pushf
    707120f09d88:	pop    r11
    707120f09d8a:	mov    QWORD PTR [rsp+0x20],r11
    707120f09d8f:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f09d94:	mov    r10d,edx
    707120f09d97:	and    r10d,0xc0
    707120f09d9e:	shl    r10d,0x18
    707120f09da2:	mov    r11d,edx
    707120f09da5:	and    r11d,0x1
    707120f09da9:	shl    r11d,0x1d
    707120f09dad:	or     r10d,r11d
    707120f09db0:	mov    r11d,edx
    707120f09db3:	and    r11d,0x800
    707120f09dba:	shl    r11d,0x11
    707120f09dbe:	or     r10d,r11d
    707120f09dc1:	btc    r10,0x1d
    707120f09dc6:	mov    r11d,0xf0000000
    707120f09dcc:	and    r11,r10
    707120f09dcf:	movabs rsi,0xffffffff0fffffff
    707120f09dd9:	and    rbx,rsi
    707120f09ddc:	or     rbx,r11
    707120f09ddf:	pop    r11
    707120f09de1:	pop    r10
    707120f09de3:	pop    rsi
    707120f09de4:	pop    rdx
    707120f09de5:	mov    QWORD PTR [r12+0x108],rbx
    707120f09ded:	add    rsp,0x150
    707120f09df4:	mov    eax,0xc
    707120f09df9:	movabs r11,0x5ab6724ae390
    707120f09e03:	jmp    r11
    707120f09e06:	mov    eax,0x410700
    707120f09e0b:	mov    QWORD PTR [r12+0x100],rax
    707120f09e13:	push   rdx
    707120f09e14:	push   rsi
    707120f09e15:	push   r10
    707120f09e17:	push   r11
    707120f09e19:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f09e1e:	mov    r10d,edx
    707120f09e21:	and    r10d,0xc0
    707120f09e28:	shl    r10d,0x18
    707120f09e2c:	mov    r11d,edx
    707120f09e2f:	and    r11d,0x1
    707120f09e33:	shl    r11d,0x1d
    707120f09e37:	or     r10d,r11d
    707120f09e3a:	mov    r11d,edx
    707120f09e3d:	and    r11d,0x800
    707120f09e44:	shl    r11d,0x11
    707120f09e48:	or     r10d,r11d
    707120f09e4b:	btc    r10,0x1d
    707120f09e50:	mov    r11d,0xf0000000
    707120f09e56:	and    r11,r10
    707120f09e59:	movabs rsi,0xffffffff0fffffff
    707120f09e63:	and    rbx,rsi
    707120f09e66:	or     rbx,r11
    707120f09e69:	pop    r11
    707120f09e6b:	pop    r10
    707120f09e6d:	pop    rsi
    707120f09e6e:	pop    rdx
    707120f09e6f:	mov    QWORD PTR [r12+0x108],rbx
    707120f09e77:	add    rsp,0x150
    707120f09e7e:	mov    eax,0xc
    707120f09e83:	movabs r11,0x5ab6724ae390
    707120f09e8d:	jmp    r11
    707120f09e90:	mov    eax,0x410724
    707120f09e95:	mov    QWORD PTR [r12+0x100],rax
    707120f09e9d:	push   rdx
    707120f09e9e:	push   rsi
    707120f09e9f:	push   r10
    707120f09ea1:	push   r11
    707120f09ea3:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f09ea8:	mov    r10d,edx
    707120f09eab:	and    r10d,0xc0
    707120f09eb2:	shl    r10d,0x18
    707120f09eb6:	mov    r11d,edx
    707120f09eb9:	and    r11d,0x1
    707120f09ebd:	shl    r11d,0x1d
    707120f09ec1:	or     r10d,r11d
    707120f09ec4:	mov    r11d,edx
    707120f09ec7:	and    r11d,0x800
    707120f09ece:	shl    r11d,0x11
    707120f09ed2:	or     r10d,r11d
    707120f09ed5:	btc    r10,0x1d
    707120f09eda:	mov    r11d,0xf0000000
    707120f09ee0:	and    r11,r10
    707120f09ee3:	movabs rsi,0xffffffff0fffffff
    707120f09eed:	and    rbx,rsi
    707120f09ef0:	or     rbx,r11
    707120f09ef3:	pop    r11
    707120f09ef5:	pop    r10
    707120f09ef7:	pop    rsi
    707120f09ef8:	pop    rdx
    707120f09ef9:	mov    QWORD PTR [r12+0x108],rbx
    707120f09f01:	add    rsp,0x150
    707120f09f08:	mov    eax,0xc
    707120f09f0d:	movabs r11,0x5ab6724ae390
    707120f09f17:	jmp    r11
    707120f09f1a:	nop    WORD PTR [rax+rax*1+0x0]
    707120f09f20:	sub    rsp,0x150
    707120f09f27:	mov    r11,QWORD PTR [r12+0x398]
    707120f09f2f:	mov    QWORD PTR [rsp],r11
    707120f09f33:	cmp    DWORD PTR [r12+0x310],0x0
    707120f09f3c:	je     0x707120f09fcc
    707120f09f42:	push   rdx
    707120f09f43:	push   rsi
    707120f09f44:	push   r10
    707120f09f46:	push   r11
    707120f09f48:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f09f4d:	mov    r10d,edx
    707120f09f50:	and    r10d,0xc0
    707120f09f57:	shl    r10d,0x18
    707120f09f5b:	mov    r11d,edx
    707120f09f5e:	and    r11d,0x1
    707120f09f62:	shl    r11d,0x1d
    707120f09f66:	or     r10d,r11d
    707120f09f69:	mov    r11d,edx
    707120f09f6c:	and    r11d,0x800
    707120f09f73:	shl    r11d,0x11
    707120f09f77:	or     r10d,r11d
    707120f09f7a:	btc    r10,0x1d
    707120f09f7f:	mov    r11d,0xf0000000
    707120f09f85:	and    r11,r10
    707120f09f88:	movabs rsi,0xffffffff0fffffff
    707120f09f92:	and    rbx,rsi
    707120f09f95:	or     rbx,r11
    707120f09f98:	pop    r11
    707120f09f9a:	pop    r10
    707120f09f9c:	pop    rsi
    707120f09f9d:	pop    rdx
    707120f09f9e:	mov    QWORD PTR [r12+0x108],rbx
    707120f09fa6:	mov    eax,0x410404
    707120f09fab:	mov    QWORD PTR [r12+0x100],rax
    707120f09fb3:	add    rsp,0x150
    707120f09fba:	mov    eax,0x3
    707120f09fbf:	movabs r11,0x5ab6724ae390
    707120f09fc9:	jmp    r11
    707120f09fcc:	jmp    0x707120f02ce8
    707120f09fd1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f09fe0:	sub    rsp,0x150
    707120f09fe7:	mov    r11,QWORD PTR [r12+0x398]
    707120f09fef:	mov    QWORD PTR [rsp],r11
    707120f09ff3:	cmp    DWORD PTR [r12+0x310],0x0
    707120f09ffc:	je     0x707120f0a08c
    707120f0a002:	push   rdx
    707120f0a003:	push   rsi
    707120f0a004:	push   r10
    707120f0a006:	push   r11
    707120f0a008:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0a00d:	mov    r10d,edx
    707120f0a010:	and    r10d,0xc0
    707120f0a017:	shl    r10d,0x18
    707120f0a01b:	mov    r11d,edx
    707120f0a01e:	and    r11d,0x1
    707120f0a022:	shl    r11d,0x1d
    707120f0a026:	or     r10d,r11d
    707120f0a029:	mov    r11d,edx
    707120f0a02c:	and    r11d,0x800
    707120f0a033:	shl    r11d,0x11
    707120f0a037:	or     r10d,r11d
    707120f0a03a:	btc    r10,0x1d
    707120f0a03f:	mov    r11d,0xf0000000
    707120f0a045:	and    r11,r10
    707120f0a048:	movabs rsi,0xffffffff0fffffff
    707120f0a052:	and    rbx,rsi
    707120f0a055:	or     rbx,r11
    707120f0a058:	pop    r11
    707120f0a05a:	pop    r10
    707120f0a05c:	pop    rsi
    707120f0a05d:	pop    rdx
    707120f0a05e:	mov    QWORD PTR [r12+0x108],rbx
    707120f0a066:	mov    eax,0x410450
    707120f0a06b:	mov    QWORD PTR [r12+0x100],rax
    707120f0a073:	add    rsp,0x150
    707120f0a07a:	mov    eax,0x3
    707120f0a07f:	movabs r11,0x5ab6724ae390
    707120f0a089:	jmp    r11
    707120f0a08c:	jmp    0x707120f02e52
    707120f0a091:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f0a0a0:	sub    rsp,0x150
    707120f0a0a7:	mov    r11,QWORD PTR [r12+0x398]
    707120f0a0af:	mov    QWORD PTR [rsp],r11
    707120f0a0b3:	cmp    DWORD PTR [r12+0x310],0x0
    707120f0a0bc:	je     0x707120f0a14c
    707120f0a0c2:	push   rdx
    707120f0a0c3:	push   rsi
    707120f0a0c4:	push   r10
    707120f0a0c6:	push   r11
    707120f0a0c8:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0a0cd:	mov    r10d,edx
    707120f0a0d0:	and    r10d,0xc0
    707120f0a0d7:	shl    r10d,0x18
    707120f0a0db:	mov    r11d,edx
    707120f0a0de:	and    r11d,0x1
    707120f0a0e2:	shl    r11d,0x1d
    707120f0a0e6:	or     r10d,r11d
    707120f0a0e9:	mov    r11d,edx
    707120f0a0ec:	and    r11d,0x800
    707120f0a0f3:	shl    r11d,0x11
    707120f0a0f7:	or     r10d,r11d
    707120f0a0fa:	btc    r10,0x1d
    707120f0a0ff:	mov    r11d,0xf0000000
    707120f0a105:	and    r11,r10
    707120f0a108:	movabs rsi,0xffffffff0fffffff
    707120f0a112:	and    rbx,rsi
    707120f0a115:	or     rbx,r11
    707120f0a118:	pop    r11
    707120f0a11a:	pop    r10
    707120f0a11c:	pop    rsi
    707120f0a11d:	pop    rdx
    707120f0a11e:	mov    QWORD PTR [r12+0x108],rbx
    707120f0a126:	mov    eax,0x410490
    707120f0a12b:	mov    QWORD PTR [r12+0x100],rax
    707120f0a133:	add    rsp,0x150
    707120f0a13a:	mov    eax,0x3
    707120f0a13f:	movabs r11,0x5ab6724ae390
    707120f0a149:	jmp    r11
    707120f0a14c:	jmp    0x707120f033c8
    707120f0a151:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f0a160:	sub    rsp,0x150
    707120f0a167:	mov    r11,QWORD PTR [r12+0x398]
    707120f0a16f:	mov    QWORD PTR [rsp],r11
    707120f0a173:	cmp    DWORD PTR [r12+0x310],0x0
    707120f0a17c:	je     0x707120f0a20c
    707120f0a182:	push   rdx
    707120f0a183:	push   rsi
    707120f0a184:	push   r10
    707120f0a186:	push   r11
    707120f0a188:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0a18d:	mov    r10d,edx
    707120f0a190:	and    r10d,0xc0
    707120f0a197:	shl    r10d,0x18
    707120f0a19b:	mov    r11d,edx
    707120f0a19e:	and    r11d,0x1
    707120f0a1a2:	shl    r11d,0x1d
    707120f0a1a6:	or     r10d,r11d
    707120f0a1a9:	mov    r11d,edx
    707120f0a1ac:	and    r11d,0x800
    707120f0a1b3:	shl    r11d,0x11
    707120f0a1b7:	or     r10d,r11d
    707120f0a1ba:	btc    r10,0x1d
    707120f0a1bf:	mov    r11d,0xf0000000
    707120f0a1c5:	and    r11,r10
    707120f0a1c8:	movabs rsi,0xffffffff0fffffff
    707120f0a1d2:	and    rbx,rsi
    707120f0a1d5:	or     rbx,r11
    707120f0a1d8:	pop    r11
    707120f0a1da:	pop    r10
    707120f0a1dc:	pop    rsi
    707120f0a1dd:	pop    rdx
    707120f0a1de:	mov    QWORD PTR [r12+0x108],rbx
    707120f0a1e6:	mov    eax,0x410500
    707120f0a1eb:	mov    QWORD PTR [r12+0x100],rax
    707120f0a1f3:	add    rsp,0x150
    707120f0a1fa:	mov    eax,0x3
    707120f0a1ff:	movabs r11,0x5ab6724ae390
    707120f0a209:	jmp    r11
    707120f0a20c:	jmp    0x707120f03a08
    707120f0a211:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f0a220:	sub    rsp,0x150
    707120f0a227:	mov    r11,QWORD PTR [r12+0x398]
    707120f0a22f:	mov    QWORD PTR [rsp],r11
    707120f0a233:	cmp    DWORD PTR [r12+0x310],0x0
    707120f0a23c:	je     0x707120f0a2cc
    707120f0a242:	push   rdx
    707120f0a243:	push   rsi
    707120f0a244:	push   r10
    707120f0a246:	push   r11
    707120f0a248:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0a24d:	mov    r10d,edx
    707120f0a250:	and    r10d,0xc0
    707120f0a257:	shl    r10d,0x18
    707120f0a25b:	mov    r11d,edx
    707120f0a25e:	and    r11d,0x1
    707120f0a262:	shl    r11d,0x1d
    707120f0a266:	or     r10d,r11d
    707120f0a269:	mov    r11d,edx
    707120f0a26c:	and    r11d,0x800
    707120f0a273:	shl    r11d,0x11
    707120f0a277:	or     r10d,r11d
    707120f0a27a:	btc    r10,0x1d
    707120f0a27f:	mov    r11d,0xf0000000
    707120f0a285:	and    r11,r10
    707120f0a288:	movabs rsi,0xffffffff0fffffff
    707120f0a292:	and    rbx,rsi
    707120f0a295:	or     rbx,r11
    707120f0a298:	pop    r11
    707120f0a29a:	pop    r10
    707120f0a29c:	pop    rsi
    707120f0a29d:	pop    rdx
    707120f0a29e:	mov    QWORD PTR [r12+0x108],rbx
    707120f0a2a6:	mov    eax,0x410504
    707120f0a2ab:	mov    QWORD PTR [r12+0x100],rax
    707120f0a2b3:	add    rsp,0x150
    707120f0a2ba:	mov    eax,0x3
    707120f0a2bf:	movabs r11,0x5ab6724ae390
    707120f0a2c9:	jmp    r11
    707120f0a2cc:	jmp    0x707120f03a18
    707120f0a2d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f0a2e0:	sub    rsp,0x150
    707120f0a2e7:	mov    r11,QWORD PTR [r12+0x398]
    707120f0a2ef:	mov    QWORD PTR [rsp],r11
    707120f0a2f3:	cmp    DWORD PTR [r12+0x310],0x0
    707120f0a2fc:	je     0x707120f0a38c
    707120f0a302:	push   rdx
    707120f0a303:	push   rsi
    707120f0a304:	push   r10
    707120f0a306:	push   r11
    707120f0a308:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0a30d:	mov    r10d,edx
    707120f0a310:	and    r10d,0xc0
    707120f0a317:	shl    r10d,0x18
    707120f0a31b:	mov    r11d,edx
    707120f0a31e:	and    r11d,0x1
    707120f0a322:	shl    r11d,0x1d
    707120f0a326:	or     r10d,r11d
    707120f0a329:	mov    r11d,edx
    707120f0a32c:	and    r11d,0x800
    707120f0a333:	shl    r11d,0x11
    707120f0a337:	or     r10d,r11d
    707120f0a33a:	btc    r10,0x1d
    707120f0a33f:	mov    r11d,0xf0000000
    707120f0a345:	and    r11,r10
    707120f0a348:	movabs rsi,0xffffffff0fffffff
    707120f0a352:	and    rbx,rsi
    707120f0a355:	or     rbx,r11
    707120f0a358:	pop    r11
    707120f0a35a:	pop    r10
    707120f0a35c:	pop    rsi
    707120f0a35d:	pop    rdx
    707120f0a35e:	mov    QWORD PTR [r12+0x108],rbx
    707120f0a366:	mov    eax,0x4106d0
    707120f0a36b:	mov    QWORD PTR [r12+0x100],rax
    707120f0a373:	add    rsp,0x150
    707120f0a37a:	mov    eax,0x3
    707120f0a37f:	movabs r11,0x5ab6724ae390
    707120f0a389:	jmp    r11
    707120f0a38c:	jmp    0x707120f075dd
    707120f0a391:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f0a3a0:	sub    rsp,0x150
    707120f0a3a7:	mov    r11,QWORD PTR [r12+0x398]
    707120f0a3af:	mov    QWORD PTR [rsp],r11
    707120f0a3b3:	cmp    DWORD PTR [r12+0x310],0x0
    707120f0a3bc:	je     0x707120f0a44c
    707120f0a3c2:	push   rdx
    707120f0a3c3:	push   rsi
    707120f0a3c4:	push   r10
    707120f0a3c6:	push   r11
    707120f0a3c8:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0a3cd:	mov    r10d,edx
    707120f0a3d0:	and    r10d,0xc0
    707120f0a3d7:	shl    r10d,0x18
    707120f0a3db:	mov    r11d,edx
    707120f0a3de:	and    r11d,0x1
    707120f0a3e2:	shl    r11d,0x1d
    707120f0a3e6:	or     r10d,r11d
    707120f0a3e9:	mov    r11d,edx
    707120f0a3ec:	and    r11d,0x800
    707120f0a3f3:	shl    r11d,0x11
    707120f0a3f7:	or     r10d,r11d
    707120f0a3fa:	btc    r10,0x1d
    707120f0a3ff:	mov    r11d,0xf0000000
    707120f0a405:	and    r11,r10
    707120f0a408:	movabs rsi,0xffffffff0fffffff
    707120f0a412:	and    rbx,rsi
    707120f0a415:	or     rbx,r11
    707120f0a418:	pop    r11
    707120f0a41a:	pop    r10
    707120f0a41c:	pop    rsi
    707120f0a41d:	pop    rdx
    707120f0a41e:	mov    QWORD PTR [r12+0x108],rbx
    707120f0a426:	mov    eax,0x4106dc
    707120f0a42b:	mov    QWORD PTR [r12+0x100],rax
    707120f0a433:	add    rsp,0x150
    707120f0a43a:	mov    eax,0x3
    707120f0a43f:	movabs r11,0x5ab6724ae390
    707120f0a449:	jmp    r11
    707120f0a44c:	jmp    0x707120f07613
    707120f0a451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f0a460:	sub    rsp,0x150
    707120f0a467:	mov    r11,QWORD PTR [r12+0x398]
    707120f0a46f:	mov    QWORD PTR [rsp],r11
    707120f0a473:	cmp    DWORD PTR [r12+0x310],0x0
    707120f0a47c:	je     0x707120f0a50c
    707120f0a482:	push   rdx
    707120f0a483:	push   rsi
    707120f0a484:	push   r10
    707120f0a486:	push   r11
    707120f0a488:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0a48d:	mov    r10d,edx
    707120f0a490:	and    r10d,0xc0
    707120f0a497:	shl    r10d,0x18
    707120f0a49b:	mov    r11d,edx
    707120f0a49e:	and    r11d,0x1
    707120f0a4a2:	shl    r11d,0x1d
    707120f0a4a6:	or     r10d,r11d
    707120f0a4a9:	mov    r11d,edx
    707120f0a4ac:	and    r11d,0x800
    707120f0a4b3:	shl    r11d,0x11
    707120f0a4b7:	or     r10d,r11d
    707120f0a4ba:	btc    r10,0x1d
    707120f0a4bf:	mov    r11d,0xf0000000
    707120f0a4c5:	and    r11,r10
    707120f0a4c8:	movabs rsi,0xffffffff0fffffff
    707120f0a4d2:	and    rbx,rsi
    707120f0a4d5:	or     rbx,r11
    707120f0a4d8:	pop    r11
    707120f0a4da:	pop    r10
    707120f0a4dc:	pop    rsi
    707120f0a4dd:	pop    rdx
    707120f0a4de:	mov    QWORD PTR [r12+0x108],rbx
    707120f0a4e6:	mov    eax,0x4106e8
    707120f0a4eb:	mov    QWORD PTR [r12+0x100],rax
    707120f0a4f3:	add    rsp,0x150
    707120f0a4fa:	mov    eax,0x3
    707120f0a4ff:	movabs r11,0x5ab6724ae390
    707120f0a509:	jmp    r11
    707120f0a50c:	jmp    0x707120f0764e
    707120f0a511:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f0a520:	sub    rsp,0x150
    707120f0a527:	mov    r11,QWORD PTR [r12+0x398]
    707120f0a52f:	mov    QWORD PTR [rsp],r11
    707120f0a533:	cmp    DWORD PTR [r12+0x310],0x0
    707120f0a53c:	je     0x707120f0a5cc
    707120f0a542:	push   rdx
    707120f0a543:	push   rsi
    707120f0a544:	push   r10
    707120f0a546:	push   r11
    707120f0a548:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0a54d:	mov    r10d,edx
    707120f0a550:	and    r10d,0xc0
    707120f0a557:	shl    r10d,0x18
    707120f0a55b:	mov    r11d,edx
    707120f0a55e:	and    r11d,0x1
    707120f0a562:	shl    r11d,0x1d
    707120f0a566:	or     r10d,r11d
    707120f0a569:	mov    r11d,edx
    707120f0a56c:	and    r11d,0x800
    707120f0a573:	shl    r11d,0x11
    707120f0a577:	or     r10d,r11d
    707120f0a57a:	btc    r10,0x1d
    707120f0a57f:	mov    r11d,0xf0000000
    707120f0a585:	and    r11,r10
    707120f0a588:	movabs rsi,0xffffffff0fffffff
    707120f0a592:	and    rbx,rsi
    707120f0a595:	or     rbx,r11
    707120f0a598:	pop    r11
    707120f0a59a:	pop    r10
    707120f0a59c:	pop    rsi
    707120f0a59d:	pop    rdx
    707120f0a59e:	mov    QWORD PTR [r12+0x108],rbx
    707120f0a5a6:	mov    eax,0x410704
    707120f0a5ab:	mov    QWORD PTR [r12+0x100],rax
    707120f0a5b3:	add    rsp,0x150
    707120f0a5ba:	mov    eax,0x3
    707120f0a5bf:	movabs r11,0x5ab6724ae390
    707120f0a5c9:	jmp    r11
    707120f0a5cc:	jmp    0x707120f077e6
    707120f0a5d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f0a5e0:	sub    rsp,0x150
    707120f0a5e7:	mov    r11,QWORD PTR [r12+0x398]
    707120f0a5ef:	mov    QWORD PTR [rsp],r11
    707120f0a5f3:	cmp    DWORD PTR [r12+0x310],0x0
    707120f0a5fc:	je     0x707120f0a68c
    707120f0a602:	push   rdx
    707120f0a603:	push   rsi
    707120f0a604:	push   r10
    707120f0a606:	push   r11
    707120f0a608:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0a60d:	mov    r10d,edx
    707120f0a610:	and    r10d,0xc0
    707120f0a617:	shl    r10d,0x18
    707120f0a61b:	mov    r11d,edx
    707120f0a61e:	and    r11d,0x1
    707120f0a622:	shl    r11d,0x1d
    707120f0a626:	or     r10d,r11d
    707120f0a629:	mov    r11d,edx
    707120f0a62c:	and    r11d,0x800
    707120f0a633:	shl    r11d,0x11
    707120f0a637:	or     r10d,r11d
    707120f0a63a:	btc    r10,0x1d
    707120f0a63f:	mov    r11d,0xf0000000
    707120f0a645:	and    r11,r10
    707120f0a648:	movabs rsi,0xffffffff0fffffff
    707120f0a652:	and    rbx,rsi
    707120f0a655:	or     rbx,r11
    707120f0a658:	pop    r11
    707120f0a65a:	pop    r10
    707120f0a65c:	pop    rsi
    707120f0a65d:	pop    rdx
    707120f0a65e:	mov    QWORD PTR [r12+0x108],rbx
    707120f0a666:	mov    eax,0x4103f0
    707120f0a66b:	mov    QWORD PTR [r12+0x100],rax
    707120f0a673:	add    rsp,0x150
    707120f0a67a:	mov    eax,0x3
    707120f0a67f:	movabs r11,0x5ab6724ae390
    707120f0a689:	jmp    r11
    707120f0a68c:	jmp    0x707120f079cf
    707120f0a691:	nop
    707120f0a692:	nop
    707120f0a693:	nop
