
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/2/1.bin:     file format binary


Disassembly of section .data:

0000786625cfe960 <.data>:
    786625cfe960:	sub    rsp,0x50
    786625cfe964:	mov    r11,QWORD PTR [r12+0x398]
    786625cfe96c:	mov    QWORD PTR [rsp+0x48],r11
    786625cfe971:	mov    r13,QWORD PTR [r12]
    786625cfe975:	mov    r14,r13
    786625cfe978:	add    r14,0x20
    786625cfe97c:	mov    r15,QWORD PTR [r14]
    786625cfe97f:	mov    r14,QWORD PTR [r12+0x10]
    786625cfe984:	mov    rcx,r14
    786625cfe987:	add    r15,rcx
    786625cfe98a:	mov    QWORD PTR [r12+0x40],r15
    786625cfe98f:	add    r13,0x20
    786625cfe993:	mov    QWORD PTR [r13+0x0],r15
    786625cfe997:	mov    r13d,0x0
    786625cfe99d:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe9a5:	mov    rax,r14
    786625cfe9a8:	test   rax,rax
    786625cfe9ab:	sete   al
    786625cfe9ae:	movzx  eax,al
    786625cfe9b1:	and    eax,0x1
    786625cfe9b4:	mov    r13,rax
    786625cfe9b7:	mov    rax,r13
    786625cfe9ba:	and    eax,0x1
    786625cfe9bd:	test   rax,rax
    786625cfe9c0:	jne    0x786625d0113a
    786625cfe9c6:	jmp    0x786625cfe9cb
    786625cfe9cb:	mov    r13,QWORD PTR [r12+0xf8]
    786625cfe9d3:	sub    r13,0x150
    786625cfe9da:	mov    QWORD PTR [r12+0xf8],r13
    786625cfe9e2:	mov    r14,QWORD PTR [r12]
    786625cfe9e6:	mov    r15,r14
    786625cfe9e9:	add    r15,0x68
    786625cfe9ed:	mov    rbp,QWORD PTR [r15]
    786625cfe9f0:	mov    QWORD PTR [r12+0x88],rbp
    786625cfe9f8:	add    r14,0x28
    786625cfe9fc:	mov    QWORD PTR [r12+0x40],r14
    786625cfea01:	mov    r14,r13
    786625cfea04:	add    r14,0x0
    786625cfea08:	mov    QWORD PTR [r12+0x48],r14
    786625cfea0d:	mov    r14d,0x420000
    786625cfea13:	add    r14,0xb90
    786625cfea1a:	mov    QWORD PTR [r12+0x50],r14
    786625cfea1f:	add    r13,0x100
    786625cfea26:	mov    r14,r13
    786625cfea29:	add    r14,0x8
    786625cfea2d:	mov    r15,QWORD PTR [r12+0xe8]
    786625cfea35:	mov    rbp,QWORD PTR [r12+0xd8]
    786625cfea3d:	mov    QWORD PTR [r13+0x0],r15
    786625cfea41:	mov    r13d,0x0
    786625cfea47:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfea4f:	mov    QWORD PTR [r14],rbp
    786625cfea52:	mov    r13d,0x0
    786625cfea58:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfea60:	mov    r13,QWORD PTR [r12+0xf8]
    786625cfea68:	mov    r14,r13
    786625cfea6b:	add    r14,0x110
    786625cfea72:	mov    r15,r14
    786625cfea75:	add    r15,0x8
    786625cfea79:	mov    rbp,QWORD PTR [r12+0xd0]
    786625cfea81:	mov    r8,QWORD PTR [r12+0xc8]
    786625cfea89:	mov    QWORD PTR [r14],rbp
    786625cfea8c:	mov    r14d,0x0
    786625cfea92:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfea9a:	mov    QWORD PTR [r15],r8
    786625cfea9d:	mov    r14d,0x0
    786625cfeaa3:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfeaab:	mov    r14,r13
    786625cfeaae:	add    r14,0x120
    786625cfeab5:	mov    r15,r14
    786625cfeab8:	add    r15,0x8
    786625cfeabc:	mov    rbp,QWORD PTR [r12+0xc0]
    786625cfeac4:	mov    r8,QWORD PTR [r12+0xb8]
    786625cfeacc:	mov    QWORD PTR [r14],rbp
    786625cfeacf:	mov    r14d,0x0
    786625cfead5:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfeadd:	mov    QWORD PTR [r15],r8
    786625cfeae0:	mov    r14d,0x0
    786625cfeae6:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfeaee:	mov    r14,r13
    786625cfeaf1:	add    r14,0x130
    786625cfeaf8:	mov    r15,r14
    786625cfeafb:	add    r15,0x8
    786625cfeaff:	mov    rbp,QWORD PTR [r12+0xb0]
    786625cfeb07:	mov    r8,QWORD PTR [r12+0xa8]
    786625cfeb0f:	mov    QWORD PTR [r14],rbp
    786625cfeb12:	mov    r14d,0x0
    786625cfeb18:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfeb20:	mov    QWORD PTR [r15],r8
    786625cfeb23:	mov    r14d,0x0
    786625cfeb29:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfeb31:	add    r13,0x140
    786625cfeb38:	mov    r14,r13
    786625cfeb3b:	add    r14,0x8
    786625cfeb3f:	mov    r15,QWORD PTR [r12+0xa0]
    786625cfeb47:	mov    rbp,QWORD PTR [r12+0x98]
    786625cfeb4f:	mov    QWORD PTR [r13+0x0],r15
    786625cfeb53:	mov    r13d,0x0
    786625cfeb59:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfeb61:	mov    QWORD PTR [r14],rbp
    786625cfeb64:	mov    r13d,0x0
    786625cfeb6a:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfeb72:	jmp    0x786625cfeb77
    786625cfeb77:	mov    r13,QWORD PTR [r12+0x8]
    786625cfeb7c:	mov    r14,r13
    786625cfeb7f:	add    r14,0x1
    786625cfeb83:	movzx  r15d,BYTE PTR [r13+0x0]
    786625cfeb88:	mov    QWORD PTR [r12+0x58],r15
    786625cfeb8d:	mov    QWORD PTR [r12+0x8],r14
    786625cfeb92:	mov    r13,QWORD PTR [r12+0x88]
    786625cfeb9a:	mov    r14,r13
    786625cfeb9d:	add    r14,0x1
    786625cfeba1:	mov    QWORD PTR [r12+0x60],r14
    786625cfeba6:	mov    r15,QWORD PTR [r12]
    786625cfebaa:	mov    rbp,r15
    786625cfebad:	add    rbp,0x68
    786625cfebb1:	mov    QWORD PTR [rbp+0x0],r14
    786625cfebb5:	mov    r14d,0x0
    786625cfebbb:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfebc3:	mov    rcx,r13
    786625cfebc6:	mov    r14,r15
    786625cfebc9:	add    r14,rcx
    786625cfebcc:	mov    QWORD PTR [r12+0x60],r14
    786625cfebd1:	add    r14,0x28
    786625cfebd5:	movzx  r13d,BYTE PTR [r12+0x58]
    786625cfebdb:	mov    BYTE PTR [r14],r13b
    786625cfebde:	mov    r13d,0x0
    786625cfebe4:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfebec:	add    r15,0x68
    786625cfebf0:	mov    r13,QWORD PTR [r15]
    786625cfebf3:	mov    QWORD PTR [r12+0x88],r13
    786625cfebfb:	sub    r13,0x40
    786625cfebff:	mov    rcx,QWORD PTR [r12+0x380]
    786625cfec07:	jrcxz  0x786625cfec0e
    786625cfec09:	jmp    0x786625d0117f
    786625cfec0e:	pushf
    786625cfec0f:	pop    r11
    786625cfec11:	mov    QWORD PTR [rsp+0x48],r11
    786625cfec16:	jne    0x786625d01021
    786625cfec1c:	jmp    0x786625cfec21
    786625cfec21:	mov    rax,QWORD PTR [r12+0x40]
    786625cfec26:	mov    QWORD PTR [rsp],rax
    786625cfec2a:	mov    eax,0x0
    786625cfec2f:	mov    QWORD PTR [rsp+0x20],rax
    786625cfec34:	mov    eax,0x0
    786625cfec39:	mov    QWORD PTR [rsp+0x18],rax
    786625cfec3e:	mov    eax,0x0
    786625cfec43:	mov    QWORD PTR [rsp+0x10],rax
    786625cfec48:	mov    eax,0x0
    786625cfec4d:	mov    QWORD PTR [rsp+0x8],rax
    786625cfec52:	mov    rdi,QWORD PTR [rsp]
    786625cfec56:	movzx  r9d,BYTE PTR [rdi]
    786625cfec5a:	mov    r13,r9
    786625cfec5d:	mov    rcx,r13
    786625cfec60:	mov    r9,QWORD PTR [rsp+0x20]
    786625cfec65:	or     r9,rcx
    786625cfec68:	mov    r13,QWORD PTR [rsp]
    786625cfec6c:	add    r13,0x1
    786625cfec70:	movzx  r8d,BYTE PTR [r13+0x0]
    786625cfec75:	mov    r13,r8
    786625cfec78:	mov    rcx,r13
    786625cfec7b:	mov    r8,QWORD PTR [rsp+0x18]
    786625cfec80:	or     r8,rcx
    786625cfec83:	mov    r13,QWORD PTR [rsp]
    786625cfec87:	add    r13,0x2
    786625cfec8b:	movzx  ebp,BYTE PTR [r13+0x0]
    786625cfec90:	mov    r13,rbp
    786625cfec93:	mov    rcx,r13
    786625cfec96:	mov    rbp,QWORD PTR [rsp+0x10]
    786625cfec9b:	or     rbp,rcx
    786625cfec9e:	mov    r13,QWORD PTR [rsp]
    786625cfeca2:	add    r13,0x3
    786625cfeca6:	movzx  r15d,BYTE PTR [r13+0x0]
    786625cfecab:	mov    r13,r15
    786625cfecae:	mov    rcx,r13
    786625cfecb1:	mov    r15,QWORD PTR [rsp+0x8]
    786625cfecb6:	or     r15,rcx
    786625cfecb9:	mov    r13,QWORD PTR [rsp]
    786625cfecbd:	add    r13,0x4
    786625cfecc1:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfecc6:	mov    r13,r14
    786625cfecc9:	shl    r13,0x8
    786625cfeccd:	mov    rcx,r13
    786625cfecd0:	or     r9,rcx
    786625cfecd3:	mov    r13,QWORD PTR [rsp]
    786625cfecd7:	add    r13,0x5
    786625cfecdb:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfece0:	mov    r13,r14
    786625cfece3:	shl    r13,0x8
    786625cfece7:	mov    rcx,r13
    786625cfecea:	or     r8,rcx
    786625cfeced:	mov    r13,QWORD PTR [rsp]
    786625cfecf1:	add    r13,0x6
    786625cfecf5:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfecfa:	mov    r13,r14
    786625cfecfd:	shl    r13,0x8
    786625cfed01:	mov    rcx,r13
    786625cfed04:	or     rbp,rcx
    786625cfed07:	mov    r13,QWORD PTR [rsp]
    786625cfed0b:	add    r13,0x7
    786625cfed0f:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfed14:	mov    r13,r14
    786625cfed17:	shl    r13,0x8
    786625cfed1b:	mov    rcx,r13
    786625cfed1e:	or     r15,rcx
    786625cfed21:	mov    r13,QWORD PTR [rsp]
    786625cfed25:	add    r13,0x8
    786625cfed29:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfed2e:	mov    r13,r14
    786625cfed31:	shl    r13,0x10
    786625cfed35:	mov    rcx,r13
    786625cfed38:	or     r9,rcx
    786625cfed3b:	mov    r13,QWORD PTR [rsp]
    786625cfed3f:	add    r13,0x9
    786625cfed43:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfed48:	mov    r13,r14
    786625cfed4b:	shl    r13,0x10
    786625cfed4f:	mov    rcx,r13
    786625cfed52:	or     r8,rcx
    786625cfed55:	mov    r13,QWORD PTR [rsp]
    786625cfed59:	add    r13,0xa
    786625cfed5d:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfed62:	mov    r13,r14
    786625cfed65:	shl    r13,0x10
    786625cfed69:	mov    rcx,r13
    786625cfed6c:	or     rbp,rcx
    786625cfed6f:	mov    r13,QWORD PTR [rsp]
    786625cfed73:	add    r13,0xb
    786625cfed77:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfed7c:	mov    r13,r14
    786625cfed7f:	shl    r13,0x10
    786625cfed83:	mov    rcx,r13
    786625cfed86:	or     r15,rcx
    786625cfed89:	mov    r13,QWORD PTR [rsp]
    786625cfed8d:	add    r13,0xc
    786625cfed91:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfed96:	mov    r13,r14
    786625cfed99:	shl    r13,0x18
    786625cfed9d:	mov    rcx,r13
    786625cfeda0:	or     r9,rcx
    786625cfeda3:	mov    r13,QWORD PTR [rsp]
    786625cfeda7:	add    r13,0xd
    786625cfedab:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfedb0:	mov    r13,r14
    786625cfedb3:	shl    r13,0x18
    786625cfedb7:	mov    rcx,r13
    786625cfedba:	or     r8,rcx
    786625cfedbd:	mov    r13,QWORD PTR [rsp]
    786625cfedc1:	add    r13,0xe
    786625cfedc5:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfedca:	mov    r13,r14
    786625cfedcd:	shl    r13,0x18
    786625cfedd1:	mov    rcx,r13
    786625cfedd4:	or     rbp,rcx
    786625cfedd7:	mov    r13,QWORD PTR [rsp]
    786625cfeddb:	add    r13,0xf
    786625cfeddf:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfede4:	mov    r13,r14
    786625cfede7:	shl    r13,0x18
    786625cfedeb:	mov    rcx,r13
    786625cfedee:	or     r15,rcx
    786625cfedf1:	mov    r13,QWORD PTR [rsp]
    786625cfedf5:	add    r13,0x10
    786625cfedf9:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfedfe:	mov    r13,r14
    786625cfee01:	shl    r13,0x20
    786625cfee05:	mov    rcx,r13
    786625cfee08:	or     r9,rcx
    786625cfee0b:	mov    r13,QWORD PTR [rsp]
    786625cfee0f:	add    r13,0x11
    786625cfee13:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfee18:	mov    r13,r14
    786625cfee1b:	shl    r13,0x20
    786625cfee1f:	mov    rcx,r13
    786625cfee22:	or     r8,rcx
    786625cfee25:	mov    r13,QWORD PTR [rsp]
    786625cfee29:	add    r13,0x12
    786625cfee2d:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfee32:	mov    r13,r14
    786625cfee35:	shl    r13,0x20
    786625cfee39:	mov    rcx,r13
    786625cfee3c:	or     rbp,rcx
    786625cfee3f:	mov    r13,QWORD PTR [rsp]
    786625cfee43:	add    r13,0x13
    786625cfee47:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfee4c:	mov    r13,r14
    786625cfee4f:	shl    r13,0x20
    786625cfee53:	mov    rcx,r13
    786625cfee56:	or     r15,rcx
    786625cfee59:	mov    r13,QWORD PTR [rsp]
    786625cfee5d:	add    r13,0x14
    786625cfee61:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfee66:	mov    r13,r14
    786625cfee69:	shl    r13,0x28
    786625cfee6d:	mov    rcx,r13
    786625cfee70:	or     r9,rcx
    786625cfee73:	mov    r13,QWORD PTR [rsp]
    786625cfee77:	add    r13,0x15
    786625cfee7b:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfee80:	mov    r13,r14
    786625cfee83:	shl    r13,0x28
    786625cfee87:	mov    rcx,r13
    786625cfee8a:	or     r8,rcx
    786625cfee8d:	mov    r13,QWORD PTR [rsp]
    786625cfee91:	add    r13,0x16
    786625cfee95:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfee9a:	mov    r13,r14
    786625cfee9d:	shl    r13,0x28
    786625cfeea1:	mov    rcx,r13
    786625cfeea4:	or     rbp,rcx
    786625cfeea7:	mov    r13,QWORD PTR [rsp]
    786625cfeeab:	add    r13,0x17
    786625cfeeaf:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfeeb4:	mov    r13,r14
    786625cfeeb7:	shl    r13,0x28
    786625cfeebb:	mov    rcx,r13
    786625cfeebe:	or     r15,rcx
    786625cfeec1:	mov    r13,QWORD PTR [rsp]
    786625cfeec5:	add    r13,0x18
    786625cfeec9:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfeece:	mov    r13,r14
    786625cfeed1:	shl    r13,0x30
    786625cfeed5:	mov    rcx,r13
    786625cfeed8:	or     r9,rcx
    786625cfeedb:	mov    r13,QWORD PTR [rsp]
    786625cfeedf:	add    r13,0x19
    786625cfeee3:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfeee8:	mov    r13,r14
    786625cfeeeb:	shl    r13,0x30
    786625cfeeef:	mov    rcx,r13
    786625cfeef2:	or     r8,rcx
    786625cfeef5:	mov    r13,QWORD PTR [rsp]
    786625cfeef9:	add    r13,0x1a
    786625cfeefd:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfef02:	mov    r13,r14
    786625cfef05:	shl    r13,0x30
    786625cfef09:	mov    rcx,r13
    786625cfef0c:	or     rbp,rcx
    786625cfef0f:	mov    r13,QWORD PTR [rsp]
    786625cfef13:	add    r13,0x1b
    786625cfef17:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfef1c:	mov    r13,r14
    786625cfef1f:	shl    r13,0x30
    786625cfef23:	mov    rcx,r13
    786625cfef26:	or     r15,rcx
    786625cfef29:	mov    r13,QWORD PTR [rsp]
    786625cfef2d:	add    r13,0x1c
    786625cfef31:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfef36:	mov    r13,r14
    786625cfef39:	shl    r13,0x38
    786625cfef3d:	mov    rcx,r13
    786625cfef40:	mov    rax,r9
    786625cfef43:	or     rax,rcx
    786625cfef46:	mov    QWORD PTR [rsp+0x40],rax
    786625cfef4b:	mov    r13,QWORD PTR [rsp]
    786625cfef4f:	add    r13,0x1d
    786625cfef53:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfef58:	mov    r13,r14
    786625cfef5b:	shl    r13,0x38
    786625cfef5f:	mov    rcx,r13
    786625cfef62:	mov    rax,r8
    786625cfef65:	or     rax,rcx
    786625cfef68:	mov    QWORD PTR [rsp+0x30],rax
    786625cfef6d:	mov    r13,QWORD PTR [rsp]
    786625cfef71:	add    r13,0x1e
    786625cfef75:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfef7a:	mov    r13,r14
    786625cfef7d:	shl    r13,0x38
    786625cfef81:	mov    rcx,r13
    786625cfef84:	mov    rax,rbp
    786625cfef87:	or     rax,rcx
    786625cfef8a:	mov    QWORD PTR [rsp+0x28],rax
    786625cfef8f:	mov    r13,QWORD PTR [rsp]
    786625cfef93:	add    r13,0x1f
    786625cfef97:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfef9c:	mov    r13,r14
    786625cfef9f:	shl    r13,0x38
    786625cfefa3:	mov    rcx,r13
    786625cfefa6:	mov    rax,r15
    786625cfefa9:	or     rax,rcx
    786625cfefac:	mov    QWORD PTR [rsp+0x38],rax
    786625cfefb1:	mov    r13,QWORD PTR [rsp]
    786625cfefb5:	add    r13,0x20
    786625cfefb9:	movzx  r14d,BYTE PTR [r13+0x0]
    786625cfefbe:	mov    r13,r14
    786625cfefc1:	mov    rcx,r13
    786625cfefc4:	mov    r14,QWORD PTR [rsp+0x20]
    786625cfefc9:	or     r14,rcx
    786625cfefcc:	mov    r13,QWORD PTR [rsp]
    786625cfefd0:	add    r13,0x21
    786625cfefd4:	movzx  ebp,BYTE PTR [r13+0x0]
    786625cfefd9:	mov    r13,rbp
    786625cfefdc:	mov    rcx,r13
    786625cfefdf:	mov    rbp,QWORD PTR [rsp+0x18]
    786625cfefe4:	or     rbp,rcx
    786625cfefe7:	mov    r13,QWORD PTR [rsp]
    786625cfefeb:	add    r13,0x22
    786625cfefef:	movzx  r8d,BYTE PTR [r13+0x0]
    786625cfeff4:	mov    r13,r8
    786625cfeff7:	mov    rcx,r13
    786625cfeffa:	mov    r8,QWORD PTR [rsp+0x10]
    786625cfefff:	or     r8,rcx
    786625cff002:	mov    r13,QWORD PTR [rsp]
    786625cff006:	add    r13,0x23
    786625cff00a:	movzx  r15d,BYTE PTR [r13+0x0]
    786625cff00f:	mov    r13,r15
    786625cff012:	mov    rcx,r13
    786625cff015:	mov    r15,QWORD PTR [rsp+0x8]
    786625cff01a:	or     r15,rcx
    786625cff01d:	mov    r13,QWORD PTR [rsp]
    786625cff021:	add    r13,0x24
    786625cff025:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff02a:	mov    r13,r9
    786625cff02d:	shl    r13,0x8
    786625cff031:	mov    rcx,r13
    786625cff034:	or     r14,rcx
    786625cff037:	mov    r13,QWORD PTR [rsp]
    786625cff03b:	add    r13,0x25
    786625cff03f:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff044:	mov    r13,r9
    786625cff047:	shl    r13,0x8
    786625cff04b:	mov    rcx,r13
    786625cff04e:	or     rbp,rcx
    786625cff051:	mov    r13,QWORD PTR [rsp]
    786625cff055:	add    r13,0x26
    786625cff059:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff05e:	mov    r13,r9
    786625cff061:	shl    r13,0x8
    786625cff065:	mov    rcx,r13
    786625cff068:	or     r8,rcx
    786625cff06b:	mov    r13,QWORD PTR [rsp]
    786625cff06f:	add    r13,0x27
    786625cff073:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff078:	mov    r13,r9
    786625cff07b:	shl    r13,0x8
    786625cff07f:	mov    rcx,r13
    786625cff082:	or     r15,rcx
    786625cff085:	mov    r13,QWORD PTR [rsp]
    786625cff089:	add    r13,0x28
    786625cff08d:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff092:	mov    r13,r9
    786625cff095:	shl    r13,0x10
    786625cff099:	mov    rcx,r13
    786625cff09c:	or     r14,rcx
    786625cff09f:	mov    r13,QWORD PTR [rsp]
    786625cff0a3:	add    r13,0x29
    786625cff0a7:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff0ac:	mov    r13,r9
    786625cff0af:	shl    r13,0x10
    786625cff0b3:	mov    rcx,r13
    786625cff0b6:	or     rbp,rcx
    786625cff0b9:	mov    r13,QWORD PTR [rsp]
    786625cff0bd:	add    r13,0x2a
    786625cff0c1:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff0c6:	mov    r13,r9
    786625cff0c9:	shl    r13,0x10
    786625cff0cd:	mov    rcx,r13
    786625cff0d0:	or     r8,rcx
    786625cff0d3:	mov    r13,QWORD PTR [rsp]
    786625cff0d7:	add    r13,0x2b
    786625cff0db:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff0e0:	mov    r13,r9
    786625cff0e3:	shl    r13,0x10
    786625cff0e7:	mov    rcx,r13
    786625cff0ea:	or     r15,rcx
    786625cff0ed:	mov    r13,QWORD PTR [rsp]
    786625cff0f1:	add    r13,0x2c
    786625cff0f5:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff0fa:	mov    r13,r9
    786625cff0fd:	shl    r13,0x18
    786625cff101:	mov    rcx,r13
    786625cff104:	or     r14,rcx
    786625cff107:	mov    r13,QWORD PTR [rsp]
    786625cff10b:	add    r13,0x2d
    786625cff10f:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff114:	mov    r13,r9
    786625cff117:	shl    r13,0x18
    786625cff11b:	mov    rcx,r13
    786625cff11e:	or     rbp,rcx
    786625cff121:	mov    r13,QWORD PTR [rsp]
    786625cff125:	add    r13,0x2e
    786625cff129:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff12e:	mov    r13,r9
    786625cff131:	shl    r13,0x18
    786625cff135:	mov    rcx,r13
    786625cff138:	or     r8,rcx
    786625cff13b:	mov    r13,QWORD PTR [rsp]
    786625cff13f:	add    r13,0x2f
    786625cff143:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff148:	mov    r13,r9
    786625cff14b:	shl    r13,0x18
    786625cff14f:	mov    rcx,r13
    786625cff152:	or     r15,rcx
    786625cff155:	mov    r13,QWORD PTR [rsp]
    786625cff159:	add    r13,0x30
    786625cff15d:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff162:	mov    r13,r9
    786625cff165:	shl    r13,0x20
    786625cff169:	mov    rcx,r13
    786625cff16c:	or     r14,rcx
    786625cff16f:	mov    r13,QWORD PTR [rsp]
    786625cff173:	add    r13,0x31
    786625cff177:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff17c:	mov    r13,r9
    786625cff17f:	shl    r13,0x20
    786625cff183:	mov    rcx,r13
    786625cff186:	or     rbp,rcx
    786625cff189:	mov    r13,QWORD PTR [rsp]
    786625cff18d:	add    r13,0x32
    786625cff191:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff196:	mov    r13,r9
    786625cff199:	shl    r13,0x20
    786625cff19d:	mov    rcx,r13
    786625cff1a0:	or     r8,rcx
    786625cff1a3:	mov    r13,QWORD PTR [rsp]
    786625cff1a7:	add    r13,0x33
    786625cff1ab:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff1b0:	mov    r13,r9
    786625cff1b3:	shl    r13,0x20
    786625cff1b7:	mov    rcx,r13
    786625cff1ba:	or     r15,rcx
    786625cff1bd:	mov    r13,QWORD PTR [rsp]
    786625cff1c1:	add    r13,0x34
    786625cff1c5:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff1ca:	mov    r13,r9
    786625cff1cd:	shl    r13,0x28
    786625cff1d1:	mov    rcx,r13
    786625cff1d4:	or     r14,rcx
    786625cff1d7:	mov    r13,QWORD PTR [rsp]
    786625cff1db:	add    r13,0x35
    786625cff1df:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff1e4:	mov    r13,r9
    786625cff1e7:	shl    r13,0x28
    786625cff1eb:	mov    rcx,r13
    786625cff1ee:	or     rbp,rcx
    786625cff1f1:	mov    r13,QWORD PTR [rsp]
    786625cff1f5:	add    r13,0x36
    786625cff1f9:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff1fe:	mov    r13,r9
    786625cff201:	shl    r13,0x28
    786625cff205:	mov    rcx,r13
    786625cff208:	or     r8,rcx
    786625cff20b:	mov    r13,QWORD PTR [rsp]
    786625cff20f:	add    r13,0x37
    786625cff213:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff218:	mov    r13,r9
    786625cff21b:	shl    r13,0x28
    786625cff21f:	mov    rcx,r13
    786625cff222:	or     r15,rcx
    786625cff225:	mov    r13,QWORD PTR [rsp]
    786625cff229:	add    r13,0x38
    786625cff22d:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff232:	mov    r13,r9
    786625cff235:	shl    r13,0x30
    786625cff239:	mov    rcx,r13
    786625cff23c:	or     r14,rcx
    786625cff23f:	mov    r13,QWORD PTR [rsp]
    786625cff243:	add    r13,0x39
    786625cff247:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff24c:	mov    r13,r9
    786625cff24f:	shl    r13,0x30
    786625cff253:	mov    rcx,r13
    786625cff256:	or     rbp,rcx
    786625cff259:	mov    r13,QWORD PTR [rsp]
    786625cff25d:	add    r13,0x3a
    786625cff261:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff266:	mov    r13,r9
    786625cff269:	shl    r13,0x30
    786625cff26d:	mov    rcx,r13
    786625cff270:	or     r8,rcx
    786625cff273:	mov    r13,QWORD PTR [rsp]
    786625cff277:	add    r13,0x3b
    786625cff27b:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff280:	mov    r13,r9
    786625cff283:	shl    r13,0x30
    786625cff287:	mov    rcx,r13
    786625cff28a:	or     r15,rcx
    786625cff28d:	mov    r13,QWORD PTR [rsp]
    786625cff291:	add    r13,0x3c
    786625cff295:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff29a:	mov    r13,r9
    786625cff29d:	shl    r13,0x38
    786625cff2a1:	mov    rcx,r13
    786625cff2a4:	or     r14,rcx
    786625cff2a7:	mov    r13,QWORD PTR [rsp]
    786625cff2ab:	add    r13,0x3d
    786625cff2af:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff2b4:	mov    r13,r9
    786625cff2b7:	shl    r13,0x38
    786625cff2bb:	mov    rcx,r13
    786625cff2be:	or     rbp,rcx
    786625cff2c1:	mov    r13,QWORD PTR [rsp]
    786625cff2c5:	add    r13,0x3e
    786625cff2c9:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff2ce:	mov    r13,r9
    786625cff2d1:	shl    r13,0x38
    786625cff2d5:	mov    rcx,r13
    786625cff2d8:	or     r8,rcx
    786625cff2db:	mov    r13,QWORD PTR [rsp]
    786625cff2df:	add    r13,0x3f
    786625cff2e3:	movzx  r9d,BYTE PTR [r13+0x0]
    786625cff2e8:	mov    r13,r9
    786625cff2eb:	shl    r13,0x38
    786625cff2ef:	mov    rcx,r13
    786625cff2f2:	or     r15,rcx
    786625cff2f5:	mov    rax,QWORD PTR [rsp+0x40]
    786625cff2fa:	mov    QWORD PTR [r12+0x110],rax
    786625cff302:	mov    QWORD PTR [r12+0x118],r14
    786625cff30a:	mov    rax,QWORD PTR [rsp+0x30]
    786625cff30f:	mov    QWORD PTR [r12+0x120],rax
    786625cff317:	mov    QWORD PTR [r12+0x128],rbp
    786625cff31f:	mov    rax,QWORD PTR [rsp+0x28]
    786625cff324:	mov    QWORD PTR [r12+0x130],rax
    786625cff32c:	mov    QWORD PTR [r12+0x138],r8
    786625cff334:	mov    rax,QWORD PTR [rsp+0x38]
    786625cff339:	mov    QWORD PTR [r12+0x140],rax
    786625cff341:	mov    QWORD PTR [r12+0x148],r15
    786625cff349:	mov    r13d,0x0
    786625cff34f:	mov    QWORD PTR [r12+0x58],r13
    786625cff354:	mov    r13d,0x0
    786625cff35a:	mov    r14,QWORD PTR [rsp+0x30]
    786625cff35f:	and    r14,0xff
    786625cff366:	and    r14,0xffff
    786625cff36d:	mov    rcx,r14
    786625cff370:	mov    r15,r13
    786625cff373:	or     r15,rcx
    786625cff376:	mov    r14,QWORD PTR [rsp+0x30]
    786625cff37b:	shr    r14,0x8
    786625cff37f:	and    r14,0xff
    786625cff386:	and    r14,0xffff
    786625cff38d:	shl    r14,0x10
    786625cff391:	mov    rcx,r14
    786625cff394:	or     r15,rcx
    786625cff397:	mov    r14,QWORD PTR [rsp+0x30]
    786625cff39c:	shr    r14,0x10
    786625cff3a0:	and    r14,0xff
    786625cff3a7:	and    r14,0xffff
    786625cff3ae:	shl    r14,0x20
    786625cff3b2:	mov    rcx,r14
    786625cff3b5:	or     r15,rcx
    786625cff3b8:	mov    r14,QWORD PTR [rsp+0x30]
    786625cff3bd:	shr    r14,0x18
    786625cff3c1:	and    r14,0xff
    786625cff3c8:	and    r14,0xffff
    786625cff3cf:	shl    r14,0x30
    786625cff3d3:	mov    rcx,r14
    786625cff3d6:	or     r15,rcx
    786625cff3d9:	mov    r14,QWORD PTR [rsp+0x30]
    786625cff3de:	shr    r14,0x20
    786625cff3e2:	and    r14,0xff
    786625cff3e9:	and    r14,0xffff
    786625cff3f0:	mov    rcx,r14
    786625cff3f3:	or     r13,rcx
    786625cff3f6:	mov    r14,QWORD PTR [rsp+0x30]
    786625cff3fb:	shr    r14,0x28
    786625cff3ff:	and    r14,0xff
    786625cff406:	and    r14,0xffff
    786625cff40d:	shl    r14,0x10
    786625cff411:	mov    rcx,r14
    786625cff414:	or     r13,rcx
    786625cff417:	mov    r14,QWORD PTR [rsp+0x30]
    786625cff41c:	shr    r14,0x30
    786625cff420:	and    r14,0xff
    786625cff427:	and    r14,0xffff
    786625cff42e:	shl    r14,0x20
    786625cff432:	mov    rcx,r14
    786625cff435:	or     r13,rcx
    786625cff438:	mov    r14,QWORD PTR [rsp+0x30]
    786625cff43d:	shr    r14,0x38
    786625cff441:	and    r14,0xff
    786625cff448:	and    r14,0xffff
    786625cff44f:	shl    r14,0x30
    786625cff453:	mov    rcx,r14
    786625cff456:	or     r13,rcx
    786625cff459:	mov    QWORD PTR [r12+0x150],r15
    786625cff461:	mov    QWORD PTR [r12+0x158],r13
    786625cff469:	mov    r13d,0x0
    786625cff46f:	mov    r14,QWORD PTR [rsp+0x28]
    786625cff474:	and    r14,0xff
    786625cff47b:	and    r14,0xffff
    786625cff482:	mov    rcx,r14
    786625cff485:	mov    r15,r13
    786625cff488:	or     r15,rcx
    786625cff48b:	mov    r14,QWORD PTR [rsp+0x28]
    786625cff490:	shr    r14,0x8
    786625cff494:	and    r14,0xff
    786625cff49b:	and    r14,0xffff
    786625cff4a2:	shl    r14,0x10
    786625cff4a6:	mov    rcx,r14
    786625cff4a9:	or     r15,rcx
    786625cff4ac:	mov    r14,QWORD PTR [rsp+0x28]
    786625cff4b1:	shr    r14,0x10
    786625cff4b5:	and    r14,0xff
    786625cff4bc:	and    r14,0xffff
    786625cff4c3:	shl    r14,0x20
    786625cff4c7:	mov    rcx,r14
    786625cff4ca:	or     r15,rcx
    786625cff4cd:	mov    r14,QWORD PTR [rsp+0x28]
    786625cff4d2:	shr    r14,0x18
    786625cff4d6:	and    r14,0xff
    786625cff4dd:	and    r14,0xffff
    786625cff4e4:	shl    r14,0x30
    786625cff4e8:	mov    rcx,r14
    786625cff4eb:	or     r15,rcx
    786625cff4ee:	mov    r14,QWORD PTR [rsp+0x28]
    786625cff4f3:	shr    r14,0x20
    786625cff4f7:	and    r14,0xff
    786625cff4fe:	and    r14,0xffff
    786625cff505:	mov    rcx,r14
    786625cff508:	or     r13,rcx
    786625cff50b:	mov    r14,QWORD PTR [rsp+0x28]
    786625cff510:	shr    r14,0x28
    786625cff514:	and    r14,0xff
    786625cff51b:	and    r14,0xffff
    786625cff522:	shl    r14,0x10
    786625cff526:	mov    rcx,r14
    786625cff529:	or     r13,rcx
    786625cff52c:	mov    r14,QWORD PTR [rsp+0x28]
    786625cff531:	shr    r14,0x30
    786625cff535:	and    r14,0xff
    786625cff53c:	and    r14,0xffff
    786625cff543:	shl    r14,0x20
    786625cff547:	mov    rcx,r14
    786625cff54a:	or     r13,rcx
    786625cff54d:	mov    r14,QWORD PTR [rsp+0x28]
    786625cff552:	shr    r14,0x38
    786625cff556:	and    r14,0xff
    786625cff55d:	and    r14,0xffff
    786625cff564:	shl    r14,0x30
    786625cff568:	mov    rcx,r14
    786625cff56b:	or     r13,rcx
    786625cff56e:	mov    QWORD PTR [r12+0x160],r15
    786625cff576:	mov    QWORD PTR [r12+0x168],r13
    786625cff57e:	mov    r13,QWORD PTR [r12+0x110]
    786625cff586:	mov    r14d,0x0
    786625cff58c:	mov    r15,r13
    786625cff58f:	and    r15,0xff
    786625cff596:	and    r15,0xffff
    786625cff59d:	mov    rcx,r15
    786625cff5a0:	mov    rbp,r14
    786625cff5a3:	or     rbp,rcx
    786625cff5a6:	mov    r15,r13
    786625cff5a9:	shr    r15,0x8
    786625cff5ad:	and    r15,0xff
    786625cff5b4:	and    r15,0xffff
    786625cff5bb:	shl    r15,0x10
    786625cff5bf:	mov    rcx,r15
    786625cff5c2:	or     rbp,rcx
    786625cff5c5:	mov    r15,r13
    786625cff5c8:	shr    r15,0x10
    786625cff5cc:	and    r15,0xff
    786625cff5d3:	and    r15,0xffff
    786625cff5da:	shl    r15,0x20
    786625cff5de:	mov    rcx,r15
    786625cff5e1:	or     rbp,rcx
    786625cff5e4:	mov    r15,r13
    786625cff5e7:	shr    r15,0x18
    786625cff5eb:	and    r15,0xff
    786625cff5f2:	and    r15,0xffff
    786625cff5f9:	shl    r15,0x30
    786625cff5fd:	mov    rcx,r15
    786625cff600:	or     rbp,rcx
    786625cff603:	mov    r15,r13
    786625cff606:	shr    r15,0x20
    786625cff60a:	and    r15,0xff
    786625cff611:	and    r15,0xffff
    786625cff618:	mov    rcx,r15
    786625cff61b:	or     r14,rcx
    786625cff61e:	mov    r15,r13
    786625cff621:	shr    r15,0x28
    786625cff625:	and    r15,0xff
    786625cff62c:	and    r15,0xffff
    786625cff633:	shl    r15,0x10
    786625cff637:	mov    rcx,r15
    786625cff63a:	or     r14,rcx
    786625cff63d:	mov    r15,r13
    786625cff640:	shr    r15,0x30
    786625cff644:	and    r15,0xff
    786625cff64b:	and    r15,0xffff
    786625cff652:	shl    r15,0x20
    786625cff656:	mov    rcx,r15
    786625cff659:	or     r14,rcx
    786625cff65c:	shr    r13,0x38
    786625cff660:	and    r13,0xff
    786625cff667:	and    r13,0xffff
    786625cff66e:	shl    r13,0x30
    786625cff672:	mov    rcx,r13
    786625cff675:	or     r14,rcx
    786625cff678:	mov    QWORD PTR [r12+0x170],rbp
    786625cff680:	mov    QWORD PTR [r12+0x178],r14
    786625cff688:	mov    r13,QWORD PTR [r12+0x118]
    786625cff690:	mov    r14d,0x0
    786625cff696:	mov    r15,r13
    786625cff699:	and    r15,0xff
    786625cff6a0:	and    r15,0xffff
    786625cff6a7:	mov    rcx,r15
    786625cff6aa:	mov    rbp,r14
    786625cff6ad:	or     rbp,rcx
    786625cff6b0:	mov    r15,r13
    786625cff6b3:	shr    r15,0x8
    786625cff6b7:	and    r15,0xff
    786625cff6be:	and    r15,0xffff
    786625cff6c5:	shl    r15,0x10
    786625cff6c9:	mov    rcx,r15
    786625cff6cc:	or     rbp,rcx
    786625cff6cf:	mov    r15,r13
    786625cff6d2:	shr    r15,0x10
    786625cff6d6:	and    r15,0xff
    786625cff6dd:	and    r15,0xffff
    786625cff6e4:	shl    r15,0x20
    786625cff6e8:	mov    rcx,r15
    786625cff6eb:	or     rbp,rcx
    786625cff6ee:	mov    r15,r13
    786625cff6f1:	shr    r15,0x18
    786625cff6f5:	and    r15,0xff
    786625cff6fc:	and    r15,0xffff
    786625cff703:	shl    r15,0x30
    786625cff707:	mov    rcx,r15
    786625cff70a:	or     rbp,rcx
    786625cff70d:	mov    r15,r13
    786625cff710:	shr    r15,0x20
    786625cff714:	and    r15,0xff
    786625cff71b:	and    r15,0xffff
    786625cff722:	mov    rcx,r15
    786625cff725:	or     r14,rcx
    786625cff728:	mov    r15,r13
    786625cff72b:	shr    r15,0x28
    786625cff72f:	and    r15,0xff
    786625cff736:	and    r15,0xffff
    786625cff73d:	shl    r15,0x10
    786625cff741:	mov    rcx,r15
    786625cff744:	or     r14,rcx
    786625cff747:	mov    r15,r13
    786625cff74a:	shr    r15,0x30
    786625cff74e:	and    r15,0xff
    786625cff755:	and    r15,0xffff
    786625cff75c:	shl    r15,0x20
    786625cff760:	mov    rcx,r15
    786625cff763:	or     r14,rcx
    786625cff766:	shr    r13,0x38
    786625cff76a:	and    r13,0xff
    786625cff771:	and    r13,0xffff
    786625cff778:	shl    r13,0x30
    786625cff77c:	mov    rcx,r13
    786625cff77f:	or     r14,rcx
    786625cff782:	mov    QWORD PTR [r12+0x180],rbp
    786625cff78a:	mov    QWORD PTR [r12+0x188],r14
    786625cff792:	mov    r13,QWORD PTR [r12+0x128]
    786625cff79a:	mov    r14d,0x0
    786625cff7a0:	mov    r15,r13
    786625cff7a3:	and    r15,0xff
    786625cff7aa:	and    r15,0xffff
    786625cff7b1:	mov    rcx,r15
    786625cff7b4:	mov    rbp,r14
    786625cff7b7:	or     rbp,rcx
    786625cff7ba:	mov    r15,r13
    786625cff7bd:	shr    r15,0x8
    786625cff7c1:	and    r15,0xff
    786625cff7c8:	and    r15,0xffff
    786625cff7cf:	shl    r15,0x10
    786625cff7d3:	mov    rcx,r15
    786625cff7d6:	or     rbp,rcx
    786625cff7d9:	mov    r15,r13
    786625cff7dc:	shr    r15,0x10
    786625cff7e0:	and    r15,0xff
    786625cff7e7:	and    r15,0xffff
    786625cff7ee:	shl    r15,0x20
    786625cff7f2:	mov    rcx,r15
    786625cff7f5:	or     rbp,rcx
    786625cff7f8:	mov    r15,r13
    786625cff7fb:	shr    r15,0x18
    786625cff7ff:	and    r15,0xff
    786625cff806:	and    r15,0xffff
    786625cff80d:	shl    r15,0x30
    786625cff811:	mov    rcx,r15
    786625cff814:	or     rbp,rcx
    786625cff817:	mov    r15,r13
    786625cff81a:	shr    r15,0x20
    786625cff81e:	and    r15,0xff
    786625cff825:	and    r15,0xffff
    786625cff82c:	mov    rcx,r15
    786625cff82f:	or     r14,rcx
    786625cff832:	mov    r15,r13
    786625cff835:	shr    r15,0x28
    786625cff839:	and    r15,0xff
    786625cff840:	and    r15,0xffff
    786625cff847:	shl    r15,0x10
    786625cff84b:	mov    rcx,r15
    786625cff84e:	or     r14,rcx
    786625cff851:	mov    r15,r13
    786625cff854:	shr    r15,0x30
    786625cff858:	and    r15,0xff
    786625cff85f:	and    r15,0xffff
    786625cff866:	shl    r15,0x20
    786625cff86a:	mov    rcx,r15
    786625cff86d:	or     r14,rcx
    786625cff870:	shr    r13,0x38
    786625cff874:	and    r13,0xff
    786625cff87b:	and    r13,0xffff
    786625cff882:	shl    r13,0x30
    786625cff886:	mov    rcx,r13
    786625cff889:	or     r14,rcx
    786625cff88c:	mov    QWORD PTR [r12+0x210],rbp
    786625cff894:	mov    QWORD PTR [r12+0x218],r14
    786625cff89c:	mov    r13,QWORD PTR [r12+0x138]
    786625cff8a4:	mov    r14d,0x0
    786625cff8aa:	mov    r15,r13
    786625cff8ad:	and    r15,0xff
    786625cff8b4:	and    r15,0xffff
    786625cff8bb:	mov    rcx,r15
    786625cff8be:	mov    rbp,r14
    786625cff8c1:	or     rbp,rcx
    786625cff8c4:	mov    r15,r13
    786625cff8c7:	shr    r15,0x8
    786625cff8cb:	and    r15,0xff
    786625cff8d2:	and    r15,0xffff
    786625cff8d9:	shl    r15,0x10
    786625cff8dd:	mov    rcx,r15
    786625cff8e0:	or     rbp,rcx
    786625cff8e3:	mov    r15,r13
    786625cff8e6:	shr    r15,0x10
    786625cff8ea:	and    r15,0xff
    786625cff8f1:	and    r15,0xffff
    786625cff8f8:	shl    r15,0x20
    786625cff8fc:	mov    rcx,r15
    786625cff8ff:	or     rbp,rcx
    786625cff902:	mov    r15,r13
    786625cff905:	shr    r15,0x18
    786625cff909:	and    r15,0xff
    786625cff910:	and    r15,0xffff
    786625cff917:	shl    r15,0x30
    786625cff91b:	mov    rcx,r15
    786625cff91e:	or     rbp,rcx
    786625cff921:	mov    r15,r13
    786625cff924:	shr    r15,0x20
    786625cff928:	and    r15,0xff
    786625cff92f:	and    r15,0xffff
    786625cff936:	mov    rcx,r15
    786625cff939:	or     r14,rcx
    786625cff93c:	mov    r15,r13
    786625cff93f:	shr    r15,0x28
    786625cff943:	and    r15,0xff
    786625cff94a:	and    r15,0xffff
    786625cff951:	shl    r15,0x10
    786625cff955:	mov    rcx,r15
    786625cff958:	or     r14,rcx
    786625cff95b:	mov    r15,r13
    786625cff95e:	shr    r15,0x30
    786625cff962:	and    r15,0xff
    786625cff969:	and    r15,0xffff
    786625cff970:	shl    r15,0x20
    786625cff974:	mov    rcx,r15
    786625cff977:	or     r14,rcx
    786625cff97a:	shr    r13,0x38
    786625cff97e:	and    r13,0xff
    786625cff985:	and    r13,0xffff
    786625cff98c:	shl    r13,0x30
    786625cff990:	mov    rcx,r13
    786625cff993:	or     r14,rcx
    786625cff996:	mov    QWORD PTR [r12+0x220],rbp
    786625cff99e:	mov    QWORD PTR [r12+0x228],r14
    786625cff9a6:	mov    r13,QWORD PTR [r12+0x140]
    786625cff9ae:	mov    r14d,0x0
    786625cff9b4:	mov    r15,r13
    786625cff9b7:	and    r15,0xff
    786625cff9be:	and    r15,0xffff
    786625cff9c5:	mov    rcx,r15
    786625cff9c8:	mov    rbp,r14
    786625cff9cb:	or     rbp,rcx
    786625cff9ce:	mov    r15,r13
    786625cff9d1:	shr    r15,0x8
    786625cff9d5:	and    r15,0xff
    786625cff9dc:	and    r15,0xffff
    786625cff9e3:	shl    r15,0x10
    786625cff9e7:	mov    rcx,r15
    786625cff9ea:	or     rbp,rcx
    786625cff9ed:	mov    r15,r13
    786625cff9f0:	shr    r15,0x10
    786625cff9f4:	and    r15,0xff
    786625cff9fb:	and    r15,0xffff
    786625cffa02:	shl    r15,0x20
    786625cffa06:	mov    rcx,r15
    786625cffa09:	or     rbp,rcx
    786625cffa0c:	mov    r15,r13
    786625cffa0f:	shr    r15,0x18
    786625cffa13:	and    r15,0xff
    786625cffa1a:	and    r15,0xffff
    786625cffa21:	shl    r15,0x30
    786625cffa25:	mov    rcx,r15
    786625cffa28:	or     rbp,rcx
    786625cffa2b:	mov    r15,r13
    786625cffa2e:	shr    r15,0x20
    786625cffa32:	and    r15,0xff
    786625cffa39:	and    r15,0xffff
    786625cffa40:	mov    rcx,r15
    786625cffa43:	or     r14,rcx
    786625cffa46:	mov    r15,r13
    786625cffa49:	shr    r15,0x28
    786625cffa4d:	and    r15,0xff
    786625cffa54:	and    r15,0xffff
    786625cffa5b:	shl    r15,0x10
    786625cffa5f:	mov    rcx,r15
    786625cffa62:	or     r14,rcx
    786625cffa65:	mov    r15,r13
    786625cffa68:	shr    r15,0x30
    786625cffa6c:	and    r15,0xff
    786625cffa73:	and    r15,0xffff
    786625cffa7a:	shl    r15,0x20
    786625cffa7e:	mov    rcx,r15
    786625cffa81:	or     r14,rcx
    786625cffa84:	shr    r13,0x38
    786625cffa88:	and    r13,0xff
    786625cffa8f:	and    r13,0xffff
    786625cffa96:	shl    r13,0x30
    786625cffa9a:	mov    rcx,r13
    786625cffa9d:	or     r14,rcx
    786625cffaa0:	mov    QWORD PTR [r12+0x250],rbp
    786625cffaa8:	mov    QWORD PTR [r12+0x258],r14
    786625cffab0:	mov    r13,QWORD PTR [r12+0x148]
    786625cffab8:	mov    r14d,0x0
    786625cffabe:	mov    r15,r13
    786625cffac1:	and    r15,0xff
    786625cffac8:	and    r15,0xffff
    786625cffacf:	mov    rcx,r15
    786625cffad2:	mov    rbp,r14
    786625cffad5:	or     rbp,rcx
    786625cffad8:	mov    r15,r13
    786625cffadb:	shr    r15,0x8
    786625cffadf:	and    r15,0xff
    786625cffae6:	and    r15,0xffff
    786625cffaed:	shl    r15,0x10
    786625cffaf1:	mov    rcx,r15
    786625cffaf4:	or     rbp,rcx
    786625cffaf7:	mov    r15,r13
    786625cffafa:	shr    r15,0x10
    786625cffafe:	and    r15,0xff
    786625cffb05:	and    r15,0xffff
    786625cffb0c:	shl    r15,0x20
    786625cffb10:	mov    rcx,r15
    786625cffb13:	or     rbp,rcx
    786625cffb16:	mov    r15,r13
    786625cffb19:	shr    r15,0x18
    786625cffb1d:	and    r15,0xff
    786625cffb24:	and    r15,0xffff
    786625cffb2b:	shl    r15,0x30
    786625cffb2f:	mov    rcx,r15
    786625cffb32:	or     rbp,rcx
    786625cffb35:	mov    r15,r13
    786625cffb38:	shr    r15,0x20
    786625cffb3c:	and    r15,0xff
    786625cffb43:	and    r15,0xffff
    786625cffb4a:	mov    rcx,r15
    786625cffb4d:	or     r14,rcx
    786625cffb50:	mov    r15,r13
    786625cffb53:	shr    r15,0x28
    786625cffb57:	and    r15,0xff
    786625cffb5e:	and    r15,0xffff
    786625cffb65:	shl    r15,0x10
    786625cffb69:	mov    rcx,r15
    786625cffb6c:	or     r14,rcx
    786625cffb6f:	mov    r15,r13
    786625cffb72:	shr    r15,0x30
    786625cffb76:	and    r15,0xff
    786625cffb7d:	and    r15,0xffff
    786625cffb84:	shl    r15,0x20
    786625cffb88:	mov    rcx,r15
    786625cffb8b:	or     r14,rcx
    786625cffb8e:	shr    r13,0x38
    786625cffb92:	and    r13,0xff
    786625cffb99:	and    r13,0xffff
    786625cffba0:	shl    r13,0x30
    786625cffba4:	mov    rcx,r13
    786625cffba7:	or     r14,rcx
    786625cffbaa:	mov    QWORD PTR [r12+0x110],rbp
    786625cffbb2:	mov    QWORD PTR [r12+0x118],r14
    786625cffbba:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625cffbc4:	movdqa xmm2,xmm0
    786625cffbc8:	pxor   xmm0,xmm0
    786625cffbcc:	movdqa xmm3,xmm0
    786625cffbd0:	movdqa xmm0,xmm2
    786625cffbd4:	movdqa xmm1,xmm3
    786625cffbd8:	punpcklwd xmm0,xmm1
    786625cffbdc:	movdqa xmm4,xmm0
    786625cffbe0:	movdqa xmm0,xmm4
    786625cffbe4:	pslld  xmm0,0x10
    786625cffbe9:	movdqa xmm2,xmm0
    786625cffbed:	movdqa xmm0,xmm2
    786625cffbf1:	movdqu XMMWORD PTR [r12+0x230],xmm0
    786625cffbfb:	mov    r13,QWORD PTR [r12+0x160]
    786625cffc03:	mov    r14d,0x0
    786625cffc09:	mov    r15,r13
    786625cffc0c:	and    r15,0xffff
    786625cffc13:	shl    r15,0x8
    786625cffc17:	mov    ecx,0xffffffff
    786625cffc1c:	and    r15,rcx
    786625cffc1f:	mov    rcx,r15
    786625cffc22:	mov    rbp,r14
    786625cffc25:	or     rbp,rcx
    786625cffc28:	mov    r15,r13
    786625cffc2b:	shr    r15,0x10
    786625cffc2f:	and    r15,0xffff
    786625cffc36:	shl    r15,0x8
    786625cffc3a:	mov    ecx,0xffffffff
    786625cffc3f:	and    r15,rcx
    786625cffc42:	shl    r15,0x20
    786625cffc46:	mov    rcx,r15
    786625cffc49:	or     rbp,rcx
    786625cffc4c:	mov    r15,r13
    786625cffc4f:	shr    r15,0x20
    786625cffc53:	and    r15,0xffff
    786625cffc5a:	shl    r15,0x8
    786625cffc5e:	mov    ecx,0xffffffff
    786625cffc63:	and    r15,rcx
    786625cffc66:	mov    rcx,r15
    786625cffc69:	or     r14,rcx
    786625cffc6c:	shr    r13,0x30
    786625cffc70:	and    r13,0xffff
    786625cffc77:	shl    r13,0x8
    786625cffc7b:	mov    ecx,0xffffffff
    786625cffc80:	and    r13,rcx
    786625cffc83:	shl    r13,0x20
    786625cffc87:	mov    rcx,r13
    786625cffc8a:	or     r14,rcx
    786625cffc8d:	mov    QWORD PTR [r12+0x240],rbp
    786625cffc95:	mov    QWORD PTR [r12+0x248],r14
    786625cffc9d:	mov    r13,QWORD PTR [r12+0x178]
    786625cffca5:	mov    r14d,0x0
    786625cffcab:	mov    r15,r13
    786625cffcae:	and    r15,0xffff
    786625cffcb5:	mov    ecx,0xffffffff
    786625cffcba:	and    r15,rcx
    786625cffcbd:	mov    rcx,r15
    786625cffcc0:	mov    rbp,r14
    786625cffcc3:	or     rbp,rcx
    786625cffcc6:	mov    r15,r13
    786625cffcc9:	shr    r15,0x10
    786625cffccd:	and    r15,0xffff
    786625cffcd4:	mov    ecx,0xffffffff
    786625cffcd9:	and    r15,rcx
    786625cffcdc:	shl    r15,0x20
    786625cffce0:	mov    rcx,r15
    786625cffce3:	or     rbp,rcx
    786625cffce6:	mov    r15,r13
    786625cffce9:	shr    r15,0x20
    786625cffced:	and    r15,0xffff
    786625cffcf4:	mov    ecx,0xffffffff
    786625cffcf9:	and    r15,rcx
    786625cffcfc:	mov    rcx,r15
    786625cffcff:	or     r14,rcx
    786625cffd02:	shr    r13,0x30
    786625cffd06:	and    r13,0xffff
    786625cffd0d:	mov    ecx,0xffffffff
    786625cffd12:	and    r13,rcx
    786625cffd15:	shl    r13,0x20
    786625cffd19:	mov    rcx,r13
    786625cffd1c:	or     r14,rcx
    786625cffd1f:	mov    QWORD PTR [r12+0x260],rbp
    786625cffd27:	mov    QWORD PTR [r12+0x268],r14
    786625cffd2f:	mov    r13,QWORD PTR [r12+0x188]
    786625cffd37:	mov    r14d,0x0
    786625cffd3d:	mov    r15,r13
    786625cffd40:	and    r15,0xffff
    786625cffd47:	mov    ecx,0xffffffff
    786625cffd4c:	and    r15,rcx
    786625cffd4f:	mov    rcx,r15
    786625cffd52:	mov    rbp,r14
    786625cffd55:	or     rbp,rcx
    786625cffd58:	mov    r15,r13
    786625cffd5b:	shr    r15,0x10
    786625cffd5f:	and    r15,0xffff
    786625cffd66:	mov    ecx,0xffffffff
    786625cffd6b:	and    r15,rcx
    786625cffd6e:	shl    r15,0x20
    786625cffd72:	mov    rcx,r15
    786625cffd75:	or     rbp,rcx
    786625cffd78:	mov    r15,r13
    786625cffd7b:	shr    r15,0x20
    786625cffd7f:	and    r15,0xffff
    786625cffd86:	mov    ecx,0xffffffff
    786625cffd8b:	and    r15,rcx
    786625cffd8e:	mov    rcx,r15
    786625cffd91:	or     r14,rcx
    786625cffd94:	shr    r13,0x30
    786625cffd98:	and    r13,0xffff
    786625cffd9f:	mov    ecx,0xffffffff
    786625cffda4:	and    r13,rcx
    786625cffda7:	shl    r13,0x20
    786625cffdab:	mov    rcx,r13
    786625cffdae:	or     r14,rcx
    786625cffdb1:	mov    QWORD PTR [r12+0x270],rbp
    786625cffdb9:	mov    QWORD PTR [r12+0x278],r14
    786625cffdc1:	mov    r13,QWORD PTR [r12+0x170]
    786625cffdc9:	mov    r14d,0x0
    786625cffdcf:	mov    r15,r13
    786625cffdd2:	and    r15,0xffff
    786625cffdd9:	mov    ecx,0xffffffff
    786625cffdde:	and    r15,rcx
    786625cffde1:	mov    rcx,r15
    786625cffde4:	mov    rbp,r14
    786625cffde7:	or     rbp,rcx
    786625cffdea:	mov    r15,r13
    786625cffded:	shr    r15,0x10
    786625cffdf1:	and    r15,0xffff
    786625cffdf8:	mov    ecx,0xffffffff
    786625cffdfd:	and    r15,rcx
    786625cffe00:	shl    r15,0x20
    786625cffe04:	mov    rcx,r15
    786625cffe07:	or     rbp,rcx
    786625cffe0a:	mov    r15,r13
    786625cffe0d:	shr    r15,0x20
    786625cffe11:	and    r15,0xffff
    786625cffe18:	mov    ecx,0xffffffff
    786625cffe1d:	and    r15,rcx
    786625cffe20:	mov    rcx,r15
    786625cffe23:	or     r14,rcx
    786625cffe26:	shr    r13,0x30
    786625cffe2a:	and    r13,0xffff
    786625cffe31:	mov    ecx,0xffffffff
    786625cffe36:	and    r13,rcx
    786625cffe39:	shl    r13,0x20
    786625cffe3d:	mov    rcx,r13
    786625cffe40:	or     r14,rcx
    786625cffe43:	mov    QWORD PTR [r12+0x170],rbp
    786625cffe4b:	mov    QWORD PTR [r12+0x178],r14
    786625cffe53:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625cffe5d:	movdqa xmm2,xmm0
    786625cffe61:	pxor   xmm0,xmm0
    786625cffe65:	movdqa xmm3,xmm0
    786625cffe69:	movdqa xmm0,xmm2
    786625cffe6d:	movdqa xmm1,xmm3
    786625cffe71:	punpckhwd xmm0,xmm1
    786625cffe75:	movdqa xmm4,xmm0
    786625cffe79:	movdqa xmm0,xmm4
    786625cffe7d:	pslld  xmm0,0x10
    786625cffe82:	movdqa xmm3,xmm0
    786625cffe86:	movdqa xmm0,xmm3
    786625cffe8a:	movdqu XMMWORD PTR [r12+0x280],xmm0
    786625cffe94:	mov    r13,QWORD PTR [r12+0x180]
    786625cffe9c:	mov    r14d,0x0
    786625cffea2:	mov    r15,r13
    786625cffea5:	and    r15,0xffff
    786625cffeac:	mov    ecx,0xffffffff
    786625cffeb1:	and    r15,rcx
    786625cffeb4:	mov    rcx,r15
    786625cffeb7:	mov    rbp,r14
    786625cffeba:	or     rbp,rcx
    786625cffebd:	mov    r15,r13
    786625cffec0:	shr    r15,0x10
    786625cffec4:	and    r15,0xffff
    786625cffecb:	mov    ecx,0xffffffff
    786625cffed0:	and    r15,rcx
    786625cffed3:	shl    r15,0x20
    786625cffed7:	mov    rcx,r15
    786625cffeda:	or     rbp,rcx
    786625cffedd:	mov    r15,r13
    786625cffee0:	shr    r15,0x20
    786625cffee4:	and    r15,0xffff
    786625cffeeb:	mov    ecx,0xffffffff
    786625cffef0:	and    r15,rcx
    786625cffef3:	mov    rcx,r15
    786625cffef6:	or     r14,rcx
    786625cffef9:	shr    r13,0x30
    786625cffefd:	and    r13,0xffff
    786625cfff04:	mov    ecx,0xffffffff
    786625cfff09:	and    r13,rcx
    786625cfff0c:	shl    r13,0x20
    786625cfff10:	mov    rcx,r13
    786625cfff13:	or     r14,rcx
    786625cfff16:	mov    QWORD PTR [r12+0x180],rbp
    786625cfff1e:	mov    QWORD PTR [r12+0x188],r14
    786625cfff26:	pxor   xmm0,xmm0
    786625cfff2a:	movdqa xmm3,xmm0
    786625cfff2e:	movdqa xmm0,xmm2
    786625cfff32:	movdqa xmm1,xmm3
    786625cfff36:	punpcklwd xmm0,xmm1
    786625cfff3a:	movdqa xmm4,xmm0
    786625cfff3e:	movdqa xmm0,xmm4
    786625cfff42:	pslld  xmm0,0x10
    786625cfff47:	movdqa xmm2,xmm0
    786625cfff4b:	movdqa xmm0,xmm2
    786625cfff4f:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625cfff59:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625cfff63:	movdqa xmm2,xmm0
    786625cfff67:	pxor   xmm0,xmm0
    786625cfff6b:	movdqa xmm3,xmm0
    786625cfff6f:	movdqa xmm0,xmm2
    786625cfff73:	movdqa xmm1,xmm3
    786625cfff77:	punpckhwd xmm0,xmm1
    786625cfff7b:	movdqa xmm4,xmm0
    786625cfff7f:	movdqa xmm0,xmm4
    786625cfff83:	pslld  xmm0,0x10
    786625cfff88:	movdqa xmm2,xmm0
    786625cfff8c:	movdqa xmm0,xmm2
    786625cfff90:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625cfff9a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    786625cfffa4:	movdqa xmm2,xmm0
    786625cfffa8:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625cfffb2:	movdqa xmm3,xmm0
    786625cfffb6:	movdqa xmm1,xmm2
    786625cfffba:	por    xmm3,xmm1
    786625cfffbe:	movdqa xmm0,xmm3
    786625cfffc2:	movdqu XMMWORD PTR [r12+0x230],xmm0
    786625cfffcc:	mov    r13,QWORD PTR [r12+0x228]
    786625cfffd4:	mov    r14d,0x0
    786625cfffda:	mov    r15,r13
    786625cfffdd:	and    r15,0xffff
    786625cfffe4:	shl    r15,0x8
    786625cfffe8:	mov    ecx,0xffffffff
    786625cfffed:	and    r15,rcx
    786625cffff0:	mov    rcx,r15
    786625cffff3:	mov    rbp,r14
    786625cffff6:	or     rbp,rcx
    786625cffff9:	mov    r15,r13
    786625cffffc:	shr    r15,0x10
    786625d00000:	and    r15,0xffff
    786625d00007:	shl    r15,0x8
    786625d0000b:	mov    ecx,0xffffffff
    786625d00010:	and    r15,rcx
    786625d00013:	shl    r15,0x20
    786625d00017:	mov    rcx,r15
    786625d0001a:	or     rbp,rcx
    786625d0001d:	mov    r15,r13
    786625d00020:	shr    r15,0x20
    786625d00024:	and    r15,0xffff
    786625d0002b:	shl    r15,0x8
    786625d0002f:	mov    ecx,0xffffffff
    786625d00034:	and    r15,rcx
    786625d00037:	mov    rcx,r15
    786625d0003a:	or     r14,rcx
    786625d0003d:	shr    r13,0x30
    786625d00041:	and    r13,0xffff
    786625d00048:	shl    r13,0x8
    786625d0004c:	mov    ecx,0xffffffff
    786625d00051:	and    r13,rcx
    786625d00054:	shl    r13,0x20
    786625d00058:	mov    rcx,r13
    786625d0005b:	or     r14,rcx
    786625d0005e:	mov    QWORD PTR [r12+0x240],rbp
    786625d00066:	mov    QWORD PTR [r12+0x248],r14
    786625d0006e:	mov    r13,QWORD PTR [r12+0x220]
    786625d00076:	mov    r14d,0x0
    786625d0007c:	mov    r15,r13
    786625d0007f:	and    r15,0xffff
    786625d00086:	shl    r15,0x8
    786625d0008a:	mov    ecx,0xffffffff
    786625d0008f:	and    r15,rcx
    786625d00092:	mov    rcx,r15
    786625d00095:	mov    rbp,r14
    786625d00098:	or     rbp,rcx
    786625d0009b:	mov    r15,r13
    786625d0009e:	shr    r15,0x10
    786625d000a2:	and    r15,0xffff
    786625d000a9:	shl    r15,0x8
    786625d000ad:	mov    ecx,0xffffffff
    786625d000b2:	and    r15,rcx
    786625d000b5:	shl    r15,0x20
    786625d000b9:	mov    rcx,r15
    786625d000bc:	or     rbp,rcx
    786625d000bf:	mov    r15,r13
    786625d000c2:	shr    r15,0x20
    786625d000c6:	and    r15,0xffff
    786625d000cd:	shl    r15,0x8
    786625d000d1:	mov    ecx,0xffffffff
    786625d000d6:	and    r15,rcx
    786625d000d9:	mov    rcx,r15
    786625d000dc:	or     r14,rcx
    786625d000df:	shr    r13,0x30
    786625d000e3:	and    r13,0xffff
    786625d000ea:	shl    r13,0x8
    786625d000ee:	mov    ecx,0xffffffff
    786625d000f3:	and    r13,rcx
    786625d000f6:	shl    r13,0x20
    786625d000fa:	mov    rcx,r13
    786625d000fd:	or     r14,rcx
    786625d00100:	mov    QWORD PTR [r12+0x220],rbp
    786625d00108:	mov    QWORD PTR [r12+0x228],r14
    786625d00110:	mov    r13,QWORD PTR [r12+0x168]
    786625d00118:	mov    r14d,0x0
    786625d0011e:	mov    r15,r13
    786625d00121:	and    r15,0xffff
    786625d00128:	shl    r15,0x8
    786625d0012c:	mov    ecx,0xffffffff
    786625d00131:	and    r15,rcx
    786625d00134:	mov    rcx,r15
    786625d00137:	mov    rbp,r14
    786625d0013a:	or     rbp,rcx
    786625d0013d:	mov    r15,r13
    786625d00140:	shr    r15,0x10
    786625d00144:	and    r15,0xffff
    786625d0014b:	shl    r15,0x8
    786625d0014f:	mov    ecx,0xffffffff
    786625d00154:	and    r15,rcx
    786625d00157:	shl    r15,0x20
    786625d0015b:	mov    rcx,r15
    786625d0015e:	or     rbp,rcx
    786625d00161:	mov    r15,r13
    786625d00164:	shr    r15,0x20
    786625d00168:	and    r15,0xffff
    786625d0016f:	shl    r15,0x8
    786625d00173:	mov    ecx,0xffffffff
    786625d00178:	and    r15,rcx
    786625d0017b:	mov    rcx,r15
    786625d0017e:	or     r14,rcx
    786625d00181:	shr    r13,0x30
    786625d00185:	and    r13,0xffff
    786625d0018c:	shl    r13,0x8
    786625d00190:	mov    ecx,0xffffffff
    786625d00195:	and    r13,rcx
    786625d00198:	shl    r13,0x20
    786625d0019c:	mov    rcx,r13
    786625d0019f:	or     r14,rcx
    786625d001a2:	mov    QWORD PTR [r12+0x160],rbp
    786625d001aa:	mov    QWORD PTR [r12+0x168],r14
    786625d001b2:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d001bc:	movdqa xmm2,xmm0
    786625d001c0:	movdqa xmm0,xmm2
    786625d001c4:	pslld  xmm0,0x18
    786625d001c9:	movdqa xmm3,xmm0
    786625d001cd:	movdqa xmm0,xmm3
    786625d001d1:	movdqu XMMWORD PTR [r12+0x170],xmm0
    786625d001db:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    786625d001e5:	movdqa xmm2,xmm0
    786625d001e9:	movdqa xmm0,xmm2
    786625d001ed:	pslld  xmm0,0x18
    786625d001f2:	movdqa xmm3,xmm0
    786625d001f6:	movdqa xmm0,xmm3
    786625d001fa:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d00204:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d0020e:	movdqa xmm2,xmm0
    786625d00212:	movdqa xmm0,xmm2
    786625d00216:	pslld  xmm0,0x18
    786625d0021b:	movdqa xmm3,xmm0
    786625d0021f:	movdqa xmm0,xmm3
    786625d00223:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d0022d:	mov    r13,QWORD PTR [r12+0x250]
    786625d00235:	mov    r14d,0x0
    786625d0023b:	mov    r15,r13
    786625d0023e:	and    r15,0xffff
    786625d00245:	mov    ecx,0xffffffff
    786625d0024a:	and    r15,rcx
    786625d0024d:	mov    rcx,r15
    786625d00250:	mov    rbp,r14
    786625d00253:	or     rbp,rcx
    786625d00256:	mov    r15,r13
    786625d00259:	shr    r15,0x10
    786625d0025d:	and    r15,0xffff
    786625d00264:	mov    ecx,0xffffffff
    786625d00269:	and    r15,rcx
    786625d0026c:	shl    r15,0x20
    786625d00270:	mov    rcx,r15
    786625d00273:	or     rbp,rcx
    786625d00276:	mov    r15,r13
    786625d00279:	shr    r15,0x20
    786625d0027d:	and    r15,0xffff
    786625d00284:	mov    ecx,0xffffffff
    786625d00289:	and    r15,rcx
    786625d0028c:	mov    rcx,r15
    786625d0028f:	or     r14,rcx
    786625d00292:	shr    r13,0x30
    786625d00296:	and    r13,0xffff
    786625d0029d:	mov    ecx,0xffffffff
    786625d002a2:	and    r13,rcx
    786625d002a5:	shl    r13,0x20
    786625d002a9:	mov    rcx,r13
    786625d002ac:	or     r14,rcx
    786625d002af:	mov    QWORD PTR [r12+0x140],rbp
    786625d002b7:	mov    QWORD PTR [r12+0x148],r14
    786625d002bf:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    786625d002c9:	movdqa xmm2,xmm0
    786625d002cd:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    786625d002d7:	movdqa xmm3,xmm0
    786625d002db:	movdqa xmm1,xmm2
    786625d002df:	por    xmm3,xmm1
    786625d002e3:	movdqa xmm0,xmm3
    786625d002e7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625d002f1:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d002fb:	movdqa xmm2,xmm0
    786625d002ff:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d00309:	movdqa xmm3,xmm0
    786625d0030d:	movdqa xmm1,xmm2
    786625d00311:	por    xmm3,xmm1
    786625d00315:	movdqa xmm0,xmm3
    786625d00319:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d00323:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    786625d0032d:	movdqa xmm2,xmm0
    786625d00331:	movdqa xmm0,xmm2
    786625d00335:	pslld  xmm0,0x18
    786625d0033a:	movdqa xmm3,xmm0
    786625d0033e:	movdqa xmm0,xmm3
    786625d00342:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d0034c:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d00356:	movdqa xmm2,xmm0
    786625d0035a:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625d00364:	movdqa xmm3,xmm0
    786625d00368:	movdqa xmm1,xmm2
    786625d0036c:	por    xmm3,xmm1
    786625d00370:	movdqa xmm0,xmm3
    786625d00374:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625d0037e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d00388:	movdqa xmm2,xmm0
    786625d0038c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625d00396:	movdqa xmm3,xmm0
    786625d0039a:	movdqa xmm1,xmm2
    786625d0039e:	por    xmm3,xmm1
    786625d003a2:	movdqa xmm0,xmm3
    786625d003a6:	movdqu XMMWORD PTR [r12+0x160],xmm0
    786625d003b0:	mov    r13,QWORD PTR [r12+0x118]
    786625d003b8:	mov    r14d,0x0
    786625d003be:	mov    r15,r13
    786625d003c1:	and    r15,0xffff
    786625d003c8:	mov    ecx,0xffffffff
    786625d003cd:	and    r15,rcx
    786625d003d0:	mov    rcx,r15
    786625d003d3:	mov    rbp,r14
    786625d003d6:	or     rbp,rcx
    786625d003d9:	mov    r15,r13
    786625d003dc:	shr    r15,0x10
    786625d003e0:	and    r15,0xffff
    786625d003e7:	mov    ecx,0xffffffff
    786625d003ec:	and    r15,rcx
    786625d003ef:	shl    r15,0x20
    786625d003f3:	mov    rcx,r15
    786625d003f6:	or     rbp,rcx
    786625d003f9:	mov    r15,r13
    786625d003fc:	shr    r15,0x20
    786625d00400:	and    r15,0xffff
    786625d00407:	mov    ecx,0xffffffff
    786625d0040c:	and    r15,rcx
    786625d0040f:	mov    rcx,r15
    786625d00412:	or     r14,rcx
    786625d00415:	shr    r13,0x30
    786625d00419:	and    r13,0xffff
    786625d00420:	mov    ecx,0xffffffff
    786625d00425:	and    r13,rcx
    786625d00428:	shl    r13,0x20
    786625d0042c:	mov    rcx,r13
    786625d0042f:	or     r14,rcx
    786625d00432:	mov    QWORD PTR [r12+0x170],rbp
    786625d0043a:	mov    QWORD PTR [r12+0x178],r14
    786625d00442:	mov    r13,QWORD PTR [r12+0x110]
    786625d0044a:	mov    r14d,0x0
    786625d00450:	mov    r15,r13
    786625d00453:	and    r15,0xffff
    786625d0045a:	mov    ecx,0xffffffff
    786625d0045f:	and    r15,rcx
    786625d00462:	mov    rcx,r15
    786625d00465:	mov    rbp,r14
    786625d00468:	or     rbp,rcx
    786625d0046b:	mov    r15,r13
    786625d0046e:	shr    r15,0x10
    786625d00472:	and    r15,0xffff
    786625d00479:	mov    ecx,0xffffffff
    786625d0047e:	and    r15,rcx
    786625d00481:	shl    r15,0x20
    786625d00485:	mov    rcx,r15
    786625d00488:	or     rbp,rcx
    786625d0048b:	mov    r15,r13
    786625d0048e:	shr    r15,0x20
    786625d00492:	and    r15,0xffff
    786625d00499:	mov    ecx,0xffffffff
    786625d0049e:	and    r15,rcx
    786625d004a1:	mov    rcx,r15
    786625d004a4:	or     r14,rcx
    786625d004a7:	shr    r13,0x30
    786625d004ab:	and    r13,0xffff
    786625d004b2:	mov    ecx,0xffffffff
    786625d004b7:	and    r13,rcx
    786625d004ba:	shl    r13,0x20
    786625d004be:	mov    rcx,r13
    786625d004c1:	or     r14,rcx
    786625d004c4:	mov    QWORD PTR [r12+0x110],rbp
    786625d004cc:	mov    QWORD PTR [r12+0x118],r14
    786625d004d4:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d004de:	movdqa xmm2,xmm0
    786625d004e2:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625d004ec:	movdqa xmm3,xmm0
    786625d004f0:	movdqa xmm1,xmm2
    786625d004f4:	por    xmm3,xmm1
    786625d004f8:	movdqa xmm0,xmm3
    786625d004fc:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d00506:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d00510:	movdqa xmm2,xmm0
    786625d00514:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d0051e:	movdqa xmm3,xmm0
    786625d00522:	movdqa xmm1,xmm2
    786625d00526:	por    xmm3,xmm1
    786625d0052a:	movdqa xmm0,xmm3
    786625d0052e:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625d00538:	mov    r13,QWORD PTR [r12+0x258]
    786625d00540:	mov    r14d,0x0
    786625d00546:	mov    r15,r13
    786625d00549:	and    r15,0xffff
    786625d00550:	mov    ecx,0xffffffff
    786625d00555:	and    r15,rcx
    786625d00558:	mov    rcx,r15
    786625d0055b:	mov    rbp,r14
    786625d0055e:	or     rbp,rcx
    786625d00561:	mov    r15,r13
    786625d00564:	shr    r15,0x10
    786625d00568:	and    r15,0xffff
    786625d0056f:	mov    ecx,0xffffffff
    786625d00574:	and    r15,rcx
    786625d00577:	shl    r15,0x20
    786625d0057b:	mov    rcx,r15
    786625d0057e:	or     rbp,rcx
    786625d00581:	mov    r15,r13
    786625d00584:	shr    r15,0x20
    786625d00588:	and    r15,0xffff
    786625d0058f:	mov    ecx,0xffffffff
    786625d00594:	and    r15,rcx
    786625d00597:	mov    rcx,r15
    786625d0059a:	or     r14,rcx
    786625d0059d:	shr    r13,0x30
    786625d005a1:	and    r13,0xffff
    786625d005a8:	mov    ecx,0xffffffff
    786625d005ad:	and    r13,rcx
    786625d005b0:	shl    r13,0x20
    786625d005b4:	mov    rcx,r13
    786625d005b7:	or     r14,rcx
    786625d005ba:	mov    QWORD PTR [r12+0x180],rbp
    786625d005c2:	mov    QWORD PTR [r12+0x188],r14
    786625d005ca:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d005d4:	movdqa xmm2,xmm0
    786625d005d8:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625d005e2:	movdqa xmm3,xmm0
    786625d005e6:	movdqa xmm1,xmm2
    786625d005ea:	por    xmm3,xmm1
    786625d005ee:	movdqa xmm0,xmm3
    786625d005f2:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625d005fc:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625d00606:	movdqa xmm2,xmm0
    786625d0060a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d00614:	movdqa xmm4,xmm0
    786625d00618:	movdqa xmm1,xmm2
    786625d0061c:	por    xmm4,xmm1
    786625d00620:	movdqa xmm0,xmm4
    786625d00624:	movdqu XMMWORD PTR [r12+0x140],xmm0
    786625d0062e:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d00638:	movdqa xmm2,xmm0
    786625d0063c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625d00646:	movdqa xmm4,xmm0
    786625d0064a:	movdqa xmm1,xmm2
    786625d0064e:	por    xmm4,xmm1
    786625d00652:	movdqa xmm0,xmm4
    786625d00656:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d00660:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d0066a:	movdqa xmm2,xmm0
    786625d0066e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d00678:	movdqa xmm5,xmm0
    786625d0067c:	movdqa xmm1,xmm2
    786625d00680:	por    xmm5,xmm1
    786625d00684:	movdqa xmm0,xmm5
    786625d00688:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d00692:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d0069c:	movdqa xmm2,xmm0
    786625d006a0:	movdqa xmm1,xmm2
    786625d006a4:	por    xmm3,xmm1
    786625d006a8:	movdqa xmm0,xmm3
    786625d006ac:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625d006b6:	mov    r13,QWORD PTR [r12+0xf8]
    786625d006be:	mov    r14,r13
    786625d006c1:	add    r14,0x20
    786625d006c5:	mov    r15,r14
    786625d006c8:	add    r15,0x10
    786625d006cc:	movdqu XMMWORD PTR [r14],xmm4
    786625d006d1:	mov    r14d,0x0
    786625d006d7:	mov    DWORD PTR [r12+0x32c],r14d
    786625d006df:	movdqu XMMWORD PTR [r15],xmm5
    786625d006e4:	mov    r14d,0x0
    786625d006ea:	mov    DWORD PTR [r12+0x32c],r14d
    786625d006f2:	mov    r14,r13
    786625d006f5:	add    r14,0x10
    786625d006f9:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625d00703:	movdqa xmm2,xmm0
    786625d00707:	movdqu XMMWORD PTR [r13+0x0],xmm2
    786625d0070d:	mov    r15d,0x0
    786625d00713:	mov    DWORD PTR [r12+0x32c],r15d
    786625d0071b:	movdqu XMMWORD PTR [r14],xmm3
    786625d00720:	mov    r14d,0x0
    786625d00726:	mov    DWORD PTR [r12+0x32c],r14d
    786625d0072e:	mov    r14d,DWORD PTR [r13+0x0]
    786625d00732:	mov    QWORD PTR [r12+0x60],r14
    786625d00737:	jmp    0x786625d0073c
    786625d0073c:	mov    r13,QWORD PTR [r12+0x58]
    786625d00741:	mov    r14,QWORD PTR [r12+0x48]
    786625d00746:	mov    rcx,r13
    786625d00749:	add    r14,rcx
    786625d0074c:	mov    QWORD PTR [r12+0x68],r14
    786625d00751:	add    r13,0x4
    786625d00755:	mov    QWORD PTR [r12+0x58],r13
    786625d0075a:	mov    r15,r14
    786625d0075d:	add    r15,0x4
    786625d00761:	mov    ebp,DWORD PTR [r15]
    786625d00764:	mov    QWORD PTR [r12+0x70],rbp
    786625d00769:	mov    r15,r14
    786625d0076c:	add    r15,0x38
    786625d00770:	mov    r8d,DWORD PTR [r15]
    786625d00773:	mov    QWORD PTR [r12+0x78],r8
    786625d00778:	add    r14,0x24
    786625d0077c:	mov    r15d,DWORD PTR [r14]
    786625d0077f:	mov    QWORD PTR [r12+0x90],r15
    786625d00787:	sub    r13,0xc0
    786625d0078e:	pushf
    786625d0078f:	pop    r11
    786625d00791:	mov    QWORD PTR [rsp+0x48],r11
    786625d00796:	mov    r13d,ebp
    786625d00799:	mov    r13d,r13d
    786625d0079c:	ror    r13d,0x7
    786625d007a0:	mov    QWORD PTR [r12+0x80],r13
    786625d007a8:	mov    r14d,r8d
    786625d007ab:	mov    r14d,r14d
    786625d007ae:	ror    r14d,0x11
    786625d007b2:	mov    QWORD PTR [r12+0x88],r14
    786625d007ba:	mov    r9d,DWORD PTR [r12+0x60]
    786625d007bf:	mov    ecx,r9d
    786625d007c2:	add    r15d,ecx
    786625d007c5:	mov    QWORD PTR [r12+0x60],r15
    786625d007ca:	mov    r15d,ebp
    786625d007cd:	mov    r15d,r15d
    786625d007d0:	shr    r15d,0x12
    786625d007d4:	mov    ebp,ebp
    786625d007d6:	shl    ebp,0xe
    786625d007d9:	mov    ecx,ebp
    786625d007db:	or     r15,rcx
    786625d007de:	mov    r15d,r15d
    786625d007e1:	mov    ecx,r15d
    786625d007e4:	xor    r13,rcx
    786625d007e7:	mov    r13d,r13d
    786625d007ea:	mov    QWORD PTR [r12+0x80],r13
    786625d007f2:	mov    r15d,r8d
    786625d007f5:	mov    r15d,r15d
    786625d007f8:	shr    r15d,0x13
    786625d007fc:	mov    r8d,r8d
    786625d007ff:	shl    r8d,0xd
    786625d00803:	mov    ecx,r8d
    786625d00806:	or     r15,rcx
    786625d00809:	mov    r15d,r15d
    786625d0080c:	mov    ecx,r15d
    786625d0080f:	xor    r14,rcx
    786625d00812:	mov    r14d,r14d
    786625d00815:	mov    QWORD PTR [r12+0x88],r14
    786625d0081d:	mov    r15d,DWORD PTR [r12+0x70]
    786625d00822:	mov    r15d,r15d
    786625d00825:	shr    r15d,0x3
    786625d00829:	mov    ecx,r15d
    786625d0082c:	xor    r13,rcx
    786625d0082f:	mov    r13d,r13d
    786625d00832:	mov    QWORD PTR [r12+0x80],r13
    786625d0083a:	mov    r15d,DWORD PTR [r12+0x78]
    786625d0083f:	mov    r15d,r15d
    786625d00842:	shr    r15d,0xa
    786625d00846:	mov    ecx,r15d
    786625d00849:	xor    r14,rcx
    786625d0084c:	mov    r14d,r14d
    786625d0084f:	mov    QWORD PTR [r12+0x78],r14
    786625d00854:	mov    r15d,DWORD PTR [r12+0x60]
    786625d00859:	mov    ecx,r13d
    786625d0085c:	add    r15d,ecx
    786625d0085f:	mov    QWORD PTR [r12+0x60],r15
    786625d00864:	mov    ecx,r14d
    786625d00867:	add    r15d,ecx
    786625d0086a:	mov    QWORD PTR [r12+0x60],r15
    786625d0086f:	mov    r13,QWORD PTR [r12+0x68]
    786625d00874:	add    r13,0x40
    786625d00878:	mov    DWORD PTR [r13+0x0],r15d
    786625d0087c:	mov    r13d,0x0
    786625d00882:	mov    DWORD PTR [r12+0x32c],r13d
    786625d0088a:	mov    r13d,0x0
    786625d00890:	mov    r14d,DWORD PTR [r12+0x70]
    786625d00895:	mov    ecx,r14d
    786625d00898:	mov    r15d,r13d
    786625d0089b:	or     r15,rcx
    786625d0089e:	mov    r15d,r15d
    786625d008a1:	mov    QWORD PTR [r12+0x60],r15
    786625d008a6:	mov    rcx,QWORD PTR [r12+0x380]
    786625d008ae:	jrcxz  0x786625d008b5
    786625d008b0:	jmp    0x786625d0120e
    786625d008b5:	push   QWORD PTR [rsp+0x48]
    786625d008b9:	popf
    786625d008ba:	jne    0x786625d0073c
    786625d008c0:	jmp    0x786625d008c5
    786625d008c5:	mov    r13,QWORD PTR [r12]
    786625d008c9:	mov    r14,r13
    786625d008cc:	add    r14,0x4
    786625d008d0:	mov    r15d,DWORD PTR [r13+0x0]
    786625d008d4:	mov    ebp,DWORD PTR [r14]
    786625d008d7:	mov    QWORD PTR [r12+0x78],r15
    786625d008dc:	mov    QWORD PTR [r12+0x80],rbp
    786625d008e4:	mov    r14,r13
    786625d008e7:	add    r14,0x8
    786625d008eb:	mov    r15,r14
    786625d008ee:	add    r15,0x4
    786625d008f2:	mov    ebp,DWORD PTR [r14]
    786625d008f5:	mov    r14d,DWORD PTR [r15]
    786625d008f8:	mov    QWORD PTR [r12+0x70],rbp
    786625d008fd:	mov    QWORD PTR [r12+0x68],r14
    786625d00902:	mov    r14,r13
    786625d00905:	add    r14,0x18
    786625d00909:	mov    r15,r14
    786625d0090c:	add    r15,0x4
    786625d00910:	mov    ebp,DWORD PTR [r14]
    786625d00913:	mov    r14d,DWORD PTR [r15]
    786625d00916:	mov    QWORD PTR [r12+0x58],rbp
    786625d0091b:	mov    QWORD PTR [r12+0x60],r14
    786625d00920:	add    r13,0x10
    786625d00924:	mov    r14,r13
    786625d00927:	add    r14,0x4
    786625d0092b:	mov    r15d,DWORD PTR [r13+0x0]
    786625d0092f:	mov    r13d,DWORD PTR [r14]
    786625d00932:	mov    QWORD PTR [r12+0x18],r15
    786625d00937:	mov    QWORD PTR [r12+0x90],r13
    786625d0093f:	mov    r13d,0x0
    786625d00945:	mov    QWORD PTR [r12+0x88],r13
    786625d0094d:	mov    r13d,0x0
    786625d00953:	mov    r14d,DWORD PTR [r12+0x78]
    786625d00958:	mov    ecx,r14d
    786625d0095b:	mov    r15d,r13d
    786625d0095e:	or     r15,rcx
    786625d00961:	mov    r15d,r15d
    786625d00964:	mov    QWORD PTR [r12+0xa8],r15
    786625d0096c:	mov    r13d,0x0
    786625d00972:	mov    r14d,DWORD PTR [r12+0x80]
    786625d0097a:	mov    ecx,r14d
    786625d0097d:	mov    r15d,r13d
    786625d00980:	or     r15,rcx
    786625d00983:	mov    r15d,r15d
    786625d00986:	mov    QWORD PTR [r12+0x38],r15
    786625d0098b:	mov    r13d,0x0
    786625d00991:	mov    r14d,DWORD PTR [r12+0x70]
    786625d00996:	mov    ecx,r14d
    786625d00999:	mov    r15d,r13d
    786625d0099c:	or     r15,rcx
    786625d0099f:	mov    r15d,r15d
    786625d009a2:	mov    QWORD PTR [r12+0x98],r15
    786625d009aa:	mov    r13d,0x0
    786625d009b0:	mov    r14d,DWORD PTR [r12+0x68]
    786625d009b5:	mov    ecx,r14d
    786625d009b8:	mov    r15d,r13d
    786625d009bb:	or     r15,rcx
    786625d009be:	mov    r15d,r15d
    786625d009c1:	mov    QWORD PTR [r12+0x28],r15
    786625d009c6:	mov    r13d,0x0
    786625d009cc:	mov    r14d,DWORD PTR [r12+0x60]
    786625d009d1:	mov    ecx,r14d
    786625d009d4:	mov    r15d,r13d
    786625d009d7:	or     r15,rcx
    786625d009da:	mov    r15d,r15d
    786625d009dd:	mov    QWORD PTR [r12+0xb0],r15
    786625d009e5:	mov    r13d,0x0
    786625d009eb:	mov    r14d,DWORD PTR [r12+0x58]
    786625d009f0:	mov    ecx,r14d
    786625d009f3:	mov    r15d,r13d
    786625d009f6:	or     r15,rcx
    786625d009f9:	mov    r15d,r15d
    786625d009fc:	mov    QWORD PTR [r12+0xc0],r15
    786625d00a04:	mov    r13d,0x0
    786625d00a0a:	mov    r14d,DWORD PTR [r12+0x90]
    786625d00a12:	mov    ecx,r14d
    786625d00a15:	mov    r15d,r13d
    786625d00a18:	or     r15,rcx
    786625d00a1b:	mov    r15d,r15d
    786625d00a1e:	mov    QWORD PTR [r12+0xc8],r15
    786625d00a26:	mov    r13d,0x0
    786625d00a2c:	mov    r14d,DWORD PTR [r12+0x18]
    786625d00a31:	mov    ecx,r14d
    786625d00a34:	mov    r15d,r13d
    786625d00a37:	or     r15,rcx
    786625d00a3a:	mov    r15d,r15d
    786625d00a3d:	mov    QWORD PTR [r12+0xb8],r15
    786625d00a45:	jmp    0x786625d00a4a
    786625d00a4a:	mov    r13d,0x0
    786625d00a50:	mov    r14d,DWORD PTR [r12+0xb8]
    786625d00a58:	mov    ecx,r14d
    786625d00a5b:	mov    r15d,r13d
    786625d00a5e:	or     r15,rcx
    786625d00a61:	mov    r15d,r15d
    786625d00a64:	mov    QWORD PTR [r12+0x30],r15
    786625d00a69:	mov    r13d,0x0
    786625d00a6f:	mov    r14d,DWORD PTR [r12+0xc0]
    786625d00a77:	mov    ecx,r14d
    786625d00a7a:	mov    r15d,r13d
    786625d00a7d:	or     r15,rcx
    786625d00a80:	mov    r15d,r15d
    786625d00a83:	mov    QWORD PTR [r12+0xa0],r15
    786625d00a8b:	mov    r13d,0x0
    786625d00a91:	mov    r14d,DWORD PTR [r12+0x28]
    786625d00a96:	mov    ecx,r14d
    786625d00a99:	mov    r15d,r13d
    786625d00a9c:	or     r15,rcx
    786625d00a9f:	mov    r15d,r15d
    786625d00aa2:	mov    QWORD PTR [r12+0xc0],r15
    786625d00aaa:	mov    r13d,0x0
    786625d00ab0:	mov    r14d,DWORD PTR [r12+0x98]
    786625d00ab8:	mov    ecx,r14d
    786625d00abb:	mov    r15d,r13d
    786625d00abe:	or     r15,rcx
    786625d00ac1:	mov    r15d,r15d
    786625d00ac4:	mov    QWORD PTR [r12+0x28],r15
    786625d00ac9:	mov    r13d,0x0
    786625d00acf:	mov    r14d,DWORD PTR [r12+0x38]
    786625d00ad4:	mov    ecx,r14d
    786625d00ad7:	mov    r15d,r13d
    786625d00ada:	or     r15,rcx
    786625d00add:	mov    r15d,r15d
    786625d00ae0:	mov    QWORD PTR [r12+0x98],r15
    786625d00ae8:	mov    r13d,0x0
    786625d00aee:	mov    r14d,DWORD PTR [r12+0xa8]
    786625d00af6:	mov    ecx,r14d
    786625d00af9:	mov    r15d,r13d
    786625d00afc:	or     r15,rcx
    786625d00aff:	mov    r15d,r15d
    786625d00b02:	mov    QWORD PTR [r12+0x38],r15
    786625d00b07:	mov    r13d,DWORD PTR [r12+0xb8]
    786625d00b0f:	mov    r13d,r13d
    786625d00b12:	ror    r13d,0x6
    786625d00b16:	mov    QWORD PTR [r12+0xb8],r13
    786625d00b1e:	mov    r13d,DWORD PTR [r12+0x30]
    786625d00b23:	mov    r14d,DWORD PTR [r12+0xc8]
    786625d00b2b:	mov    ecx,r14d
    786625d00b2e:	and    r13,rcx
    786625d00b31:	mov    r13d,r13d
    786625d00b34:	mov    QWORD PTR [r12+0xa8],r13
    786625d00b3c:	mov    r15d,r15d
    786625d00b3f:	ror    r15d,0x2
    786625d00b43:	mov    QWORD PTR [r12+0xd0],r15
    786625d00b4b:	mov    r13d,0x0
    786625d00b51:	mov    ecx,r14d
    786625d00b54:	mov    r15d,r13d
    786625d00b57:	or     r15,rcx
    786625d00b5a:	mov    r15d,r15d
    786625d00b5d:	mov    QWORD PTR [r12+0x20],r15
    786625d00b62:	mov    r13,QWORD PTR [r12+0x88]
    786625d00b6a:	mov    r14,QWORD PTR [r12+0x50]
    786625d00b6f:	mov    rcx,r13
    786625d00b72:	add    r14,rcx
    786625d00b75:	mov    r13d,DWORD PTR [r14]
    786625d00b78:	mov    QWORD PTR [r12+0xc8],r13
    786625d00b80:	mov    r13d,DWORD PTR [r12+0xa0]
    786625d00b88:	mov    r14d,DWORD PTR [r12+0x30]
    786625d00b8d:	mov    ecx,r14d
    786625d00b90:	not    rcx
    786625d00b93:	and    r13,rcx
    786625d00b96:	mov    r13d,r13d
    786625d00b99:	mov    QWORD PTR [r12+0xd8],r13
    786625d00ba1:	mov    r13d,DWORD PTR [r12+0xb0]
    786625d00ba9:	mov    r15d,DWORD PTR [r12+0xa8]
    786625d00bb1:	mov    ecx,r13d
    786625d00bb4:	add    r15d,ecx
    786625d00bb7:	mov    QWORD PTR [r12+0xa8],r15
    786625d00bbf:	mov    r13d,DWORD PTR [r12+0xb8]
    786625d00bc7:	mov    ebp,r14d
    786625d00bca:	mov    ebp,ebp
    786625d00bcc:	shr    ebp,0xb
    786625d00bcf:	mov    r14d,r14d
    786625d00bd2:	shl    r14d,0x15
    786625d00bd6:	mov    ecx,r14d
    786625d00bd9:	or     rbp,rcx
    786625d00bdc:	mov    ebp,ebp
    786625d00bde:	mov    ecx,ebp
    786625d00be0:	xor    r13,rcx
    786625d00be3:	mov    r13d,r13d
    786625d00be6:	mov    QWORD PTR [r12+0xb0],r13
    786625d00bee:	mov    r13d,DWORD PTR [r12+0xd0]
    786625d00bf6:	mov    r14d,DWORD PTR [r12+0x38]
    786625d00bfb:	mov    ebp,r14d
    786625d00bfe:	mov    ebp,ebp
    786625d00c00:	shr    ebp,0xd
    786625d00c03:	mov    r14d,r14d
    786625d00c06:	shl    r14d,0x13
    786625d00c0a:	mov    ecx,r14d
    786625d00c0d:	or     rbp,rcx
    786625d00c10:	mov    ebp,ebp
    786625d00c12:	mov    ecx,ebp
    786625d00c14:	xor    r13,rcx
    786625d00c17:	mov    r13d,r13d
    786625d00c1a:	mov    QWORD PTR [r12+0xd0],r13
    786625d00c22:	mov    r13d,DWORD PTR [r12+0xd8]
    786625d00c2a:	mov    ecx,r13d
    786625d00c2d:	add    r15d,ecx
    786625d00c30:	mov    QWORD PTR [r12+0xa8],r15
    786625d00c38:	mov    r13,QWORD PTR [r12+0x88]
    786625d00c40:	mov    r14,QWORD PTR [r12+0x48]
    786625d00c45:	mov    rcx,r13
    786625d00c48:	add    r14,rcx
    786625d00c4b:	mov    r13d,DWORD PTR [r14]
    786625d00c4e:	mov    QWORD PTR [r12+0xb8],r13
    786625d00c56:	mov    r13d,DWORD PTR [r12+0x28]
    786625d00c5b:	mov    r14d,DWORD PTR [r12+0x98]
    786625d00c63:	mov    ecx,r14d
    786625d00c66:	mov    ebp,r13d
    786625d00c69:	and    rbp,rcx
    786625d00c6c:	mov    ebp,ebp
    786625d00c6e:	mov    QWORD PTR [r12+0xd8],rbp
    786625d00c76:	mov    ebp,DWORD PTR [r12+0xc8]
    786625d00c7e:	mov    ecx,ebp
    786625d00c80:	add    r15d,ecx
    786625d00c83:	mov    QWORD PTR [r12+0xa8],r15
    786625d00c8b:	mov    ecx,r14d
    786625d00c8e:	xor    r13,rcx
    786625d00c91:	mov    r13d,r13d
    786625d00c94:	mov    QWORD PTR [r12+0xc8],r13
    786625d00c9c:	mov    r14d,DWORD PTR [r12+0xb0]
    786625d00ca4:	mov    r15d,DWORD PTR [r12+0x30]
    786625d00ca9:	mov    ebp,r15d
    786625d00cac:	mov    ebp,ebp
    786625d00cae:	shr    ebp,0x19
    786625d00cb1:	mov    r15d,r15d
    786625d00cb4:	shl    r15d,0x7
    786625d00cb8:	mov    ecx,r15d
    786625d00cbb:	or     rbp,rcx
    786625d00cbe:	mov    ebp,ebp
    786625d00cc0:	mov    ecx,ebp
    786625d00cc2:	xor    r14,rcx
    786625d00cc5:	mov    r14d,r14d
    786625d00cc8:	mov    QWORD PTR [r12+0xb0],r14
    786625d00cd0:	mov    r14d,DWORD PTR [r12+0x38]
    786625d00cd5:	mov    ecx,r14d
    786625d00cd8:	and    r13,rcx
    786625d00cdb:	mov    r13d,r13d
    786625d00cde:	mov    QWORD PTR [r12+0xc8],r13
    786625d00ce6:	mov    r15d,DWORD PTR [r12+0xd0]
    786625d00cee:	mov    ebp,r14d
    786625d00cf1:	mov    ebp,ebp
    786625d00cf3:	shr    ebp,0x16
    786625d00cf6:	mov    r14d,r14d
    786625d00cf9:	shl    r14d,0xa
    786625d00cfd:	mov    ecx,r14d
    786625d00d00:	or     rbp,rcx
    786625d00d03:	mov    ebp,ebp
    786625d00d05:	mov    ecx,ebp
    786625d00d07:	xor    r15,rcx
    786625d00d0a:	mov    r15d,r15d
    786625d00d0d:	mov    QWORD PTR [r12+0xd0],r15
    786625d00d15:	mov    r14d,DWORD PTR [r12+0xb8]
    786625d00d1d:	mov    r15d,DWORD PTR [r12+0xa8]
    786625d00d25:	mov    ecx,r14d
    786625d00d28:	add    r15d,ecx
    786625d00d2b:	mov    QWORD PTR [r12+0xa8],r15
    786625d00d33:	mov    r14d,DWORD PTR [r12+0xd8]
    786625d00d3b:	mov    ecx,r14d
    786625d00d3e:	xor    r13,rcx
    786625d00d41:	mov    r13d,r13d
    786625d00d44:	mov    QWORD PTR [r12+0xb8],r13
    786625d00d4c:	mov    r14d,DWORD PTR [r12+0xb0]
    786625d00d54:	mov    ecx,r14d
    786625d00d57:	add    r15d,ecx
    786625d00d5a:	mov    QWORD PTR [r12+0xa8],r15
    786625d00d62:	mov    r14,QWORD PTR [r12+0x88]
    786625d00d6a:	add    r14,0x4
    786625d00d6e:	mov    QWORD PTR [r12+0x88],r14
    786625d00d76:	mov    ebp,DWORD PTR [r12+0xd0]
    786625d00d7e:	mov    ecx,ebp
    786625d00d80:	add    r13d,ecx
    786625d00d83:	mov    QWORD PTR [r12+0xb0],r13
    786625d00d8b:	mov    ebp,DWORD PTR [r12+0xc0]
    786625d00d93:	mov    ecx,ebp
    786625d00d95:	mov    r8d,r15d
    786625d00d98:	add    r8d,ecx
    786625d00d9b:	mov    QWORD PTR [r12+0xb8],r8
    786625d00da3:	sub    r14,0x100
    786625d00daa:	pushf
    786625d00dab:	pop    r11
    786625d00dad:	mov    QWORD PTR [rsp+0x48],r11
    786625d00db2:	mov    ecx,r15d
    786625d00db5:	add    r13d,ecx
    786625d00db8:	mov    QWORD PTR [r12+0xa8],r13
    786625d00dc0:	mov    r13d,0x0
    786625d00dc6:	mov    r14d,DWORD PTR [r12+0xa0]
    786625d00dce:	mov    ecx,r14d
    786625d00dd1:	mov    r15d,r13d
    786625d00dd4:	or     r15,rcx
    786625d00dd7:	mov    r15d,r15d
    786625d00dda:	mov    QWORD PTR [r12+0xb0],r15
    786625d00de2:	mov    r13d,0x0
    786625d00de8:	mov    r14d,DWORD PTR [r12+0x20]
    786625d00ded:	mov    ecx,r14d
    786625d00df0:	mov    r15d,r13d
    786625d00df3:	or     r15,rcx
    786625d00df6:	mov    r15d,r15d
    786625d00df9:	mov    QWORD PTR [r12+0xc0],r15
    786625d00e01:	mov    r13d,0x0
    786625d00e07:	mov    r14d,DWORD PTR [r12+0x30]
    786625d00e0c:	mov    ecx,r14d
    786625d00e0f:	mov    r15d,r13d
    786625d00e12:	or     r15,rcx
    786625d00e15:	mov    r15d,r15d
    786625d00e18:	mov    QWORD PTR [r12+0xc8],r15
    786625d00e20:	mov    rcx,QWORD PTR [r12+0x380]
    786625d00e28:	jrcxz  0x786625d00e2f
    786625d00e2a:	jmp    0x786625d01295
    786625d00e2f:	push   QWORD PTR [rsp+0x48]
    786625d00e33:	popf
    786625d00e34:	jne    0x786625d00a4a
    786625d00e3a:	jmp    0x786625d00e3f
    786625d00e3f:	mov    r13d,DWORD PTR [r12+0x70]
    786625d00e44:	mov    r14d,DWORD PTR [r12+0x98]
    786625d00e4c:	mov    ecx,r13d
    786625d00e4f:	add    r14d,ecx
    786625d00e52:	mov    QWORD PTR [r12+0x70],r14
    786625d00e57:	mov    r13d,DWORD PTR [r12+0x68]
    786625d00e5c:	mov    r14d,DWORD PTR [r12+0x28]
    786625d00e61:	mov    ecx,r13d
    786625d00e64:	add    r14d,ecx
    786625d00e67:	mov    QWORD PTR [r12+0x68],r14
    786625d00e6c:	mov    r13d,0x0
    786625d00e72:	mov    QWORD PTR [r12+0x88],r13
    786625d00e7a:	mov    r13d,DWORD PTR [r12+0x78]
    786625d00e7f:	mov    r14d,DWORD PTR [r12+0xa8]
    786625d00e87:	mov    ecx,r13d
    786625d00e8a:	add    r14d,ecx
    786625d00e8d:	mov    QWORD PTR [r12+0x78],r14
    786625d00e92:	mov    r13d,DWORD PTR [r12+0x80]
    786625d00e9a:	mov    r14d,DWORD PTR [r12+0x38]
    786625d00e9f:	mov    ecx,r13d
    786625d00ea2:	add    r14d,ecx
    786625d00ea5:	mov    QWORD PTR [r12+0x80],r14
    786625d00ead:	mov    r13,QWORD PTR [r12]
    786625d00eb1:	add    r13,0x8
    786625d00eb5:	mov    r14,r13
    786625d00eb8:	add    r14,0x4
    786625d00ebc:	mov    r15d,DWORD PTR [r12+0x70]
    786625d00ec1:	mov    ebp,DWORD PTR [r12+0x68]
    786625d00ec6:	mov    DWORD PTR [r13+0x0],r15d
    786625d00eca:	mov    r13d,0x0
    786625d00ed0:	mov    DWORD PTR [r12+0x32c],r13d
    786625d00ed8:	mov    DWORD PTR [r14],ebp
    786625d00edb:	mov    r13d,0x0
    786625d00ee1:	mov    DWORD PTR [r12+0x32c],r13d
    786625d00ee9:	mov    r13d,DWORD PTR [r12+0x18]
    786625d00eee:	mov    r14d,DWORD PTR [r12+0xb8]
    786625d00ef6:	mov    ecx,r13d
    786625d00ef9:	add    r14d,ecx
    786625d00efc:	mov    QWORD PTR [r12+0x68],r14
    786625d00f01:	mov    r13d,DWORD PTR [r12+0x90]
    786625d00f09:	mov    r14d,DWORD PTR [r12+0x30]
    786625d00f0e:	mov    ecx,r13d
    786625d00f11:	add    r14d,ecx
    786625d00f14:	mov    QWORD PTR [r12+0x70],r14
    786625d00f19:	mov    r13d,DWORD PTR [r12+0x58]
    786625d00f1e:	mov    r14d,DWORD PTR [r12+0x20]
    786625d00f23:	mov    ecx,r13d
    786625d00f26:	add    r14d,ecx
    786625d00f29:	mov    QWORD PTR [r12+0x58],r14
    786625d00f2e:	mov    r13d,DWORD PTR [r12+0x60]
    786625d00f33:	mov    r14d,DWORD PTR [r12+0xa0]
    786625d00f3b:	mov    ecx,r13d
    786625d00f3e:	add    r14d,ecx
    786625d00f41:	mov    QWORD PTR [r12+0x60],r14
    786625d00f46:	mov    r13,QWORD PTR [r12]
    786625d00f4a:	mov    r15,r13
    786625d00f4d:	add    r15,0x4
    786625d00f51:	mov    ebp,DWORD PTR [r12+0x78]
    786625d00f56:	mov    r8d,DWORD PTR [r12+0x80]
    786625d00f5e:	mov    DWORD PTR [r13+0x0],ebp
    786625d00f62:	mov    ebp,0x0
    786625d00f67:	mov    DWORD PTR [r12+0x32c],ebp
    786625d00f6f:	mov    DWORD PTR [r15],r8d
    786625d00f72:	mov    r15d,0x0
    786625d00f78:	mov    DWORD PTR [r12+0x32c],r15d
    786625d00f80:	mov    r15,r13
    786625d00f83:	add    r15,0x10
    786625d00f87:	mov    rbp,r15
    786625d00f8a:	add    rbp,0x4
    786625d00f8e:	mov    r8d,DWORD PTR [r12+0x68]
    786625d00f93:	mov    r9d,DWORD PTR [r12+0x70]
    786625d00f98:	mov    DWORD PTR [r15],r8d
    786625d00f9b:	mov    r15d,0x0
    786625d00fa1:	mov    DWORD PTR [r12+0x32c],r15d
    786625d00fa9:	mov    DWORD PTR [rbp+0x0],r9d
    786625d00fad:	mov    r15d,0x0
    786625d00fb3:	mov    DWORD PTR [r12+0x32c],r15d
    786625d00fbb:	mov    r15,r13
    786625d00fbe:	add    r15,0x18
    786625d00fc2:	mov    rbp,r15
    786625d00fc5:	add    rbp,0x4
    786625d00fc9:	mov    r8d,DWORD PTR [r12+0x58]
    786625d00fce:	mov    DWORD PTR [r15],r8d
    786625d00fd1:	mov    r15d,0x0
    786625d00fd7:	mov    DWORD PTR [r12+0x32c],r15d
    786625d00fdf:	mov    DWORD PTR [rbp+0x0],r14d
    786625d00fe3:	mov    r14d,0x0
    786625d00fe9:	mov    DWORD PTR [r12+0x32c],r14d
    786625d00ff1:	add    r13,0x68
    786625d00ff5:	mov    r14d,0x0
    786625d00ffb:	mov    QWORD PTR [r13+0x0],r14
    786625d00fff:	mov    r13d,0x0
    786625d01005:	mov    DWORD PTR [r12+0x32c],r13d
    786625d0100d:	mov    rcx,QWORD PTR [r12+0x380]
    786625d01015:	jrcxz  0x786625d0101c
    786625d01017:	jmp    0x786625d0131c
    786625d0101c:	jmp    0x786625d01021
    786625d01021:	mov    r13,QWORD PTR [r12+0x10]
    786625d01026:	sub    r13,0x1
    786625d0102a:	mov    QWORD PTR [r12+0x10],r13
    786625d0102f:	mov    rax,r13
    786625d01032:	test   rax,rax
    786625d01035:	sete   al
    786625d01038:	movzx  eax,al
    786625d0103b:	and    eax,0x1
    786625d0103e:	mov    r14,rax
    786625d01041:	mov    rax,r14
    786625d01044:	and    eax,0x1
    786625d01047:	test   rax,rax
    786625d0104a:	jne    0x786625d01055
    786625d01050:	jmp    0x786625cfeb77
    786625d01055:	mov    r13,QWORD PTR [r12+0xf8]
    786625d0105d:	mov    r14,r13
    786625d01060:	add    r14,0x140
    786625d01067:	mov    r15,r14
    786625d0106a:	add    r15,0x8
    786625d0106e:	mov    rbp,QWORD PTR [r14]
    786625d01071:	mov    r14,QWORD PTR [r15]
    786625d01074:	mov    QWORD PTR [r12+0xa0],rbp
    786625d0107c:	mov    QWORD PTR [r12+0x98],r14
    786625d01084:	mov    r14,r13
    786625d01087:	add    r14,0x130
    786625d0108e:	mov    r15,r14
    786625d01091:	add    r15,0x8
    786625d01095:	mov    rbp,QWORD PTR [r14]
    786625d01098:	mov    r14,QWORD PTR [r15]
    786625d0109b:	mov    QWORD PTR [r12+0xb0],rbp
    786625d010a3:	mov    QWORD PTR [r12+0xa8],r14
    786625d010ab:	mov    r14,r13
    786625d010ae:	add    r14,0x120
    786625d010b5:	mov    r15,r14
    786625d010b8:	add    r15,0x8
    786625d010bc:	mov    rbp,QWORD PTR [r14]
    786625d010bf:	mov    r14,QWORD PTR [r15]
    786625d010c2:	mov    QWORD PTR [r12+0xc0],rbp
    786625d010ca:	mov    QWORD PTR [r12+0xb8],r14
    786625d010d2:	add    r13,0x110
    786625d010d9:	mov    r14,r13
    786625d010dc:	add    r14,0x8
    786625d010e0:	mov    r15,QWORD PTR [r13+0x0]
    786625d010e4:	mov    r13,QWORD PTR [r14]
    786625d010e7:	mov    QWORD PTR [r12+0xd0],r15
    786625d010ef:	mov    QWORD PTR [r12+0xc8],r13
    786625d010f7:	mov    r13,QWORD PTR [r12+0xf8]
    786625d010ff:	mov    r14,r13
    786625d01102:	add    r14,0x100
    786625d01109:	mov    r15,r14
    786625d0110c:	add    r15,0x8
    786625d01110:	mov    rbp,QWORD PTR [r14]
    786625d01113:	mov    r14,QWORD PTR [r15]
    786625d01116:	mov    QWORD PTR [r12+0xe8],rbp
    786625d0111e:	mov    QWORD PTR [r12+0xd8],r14
    786625d01126:	add    r13,0x150
    786625d0112d:	mov    QWORD PTR [r12+0xf8],r13
    786625d01135:	jmp    0x786625d0113a
    786625d0113a:	mov    rcx,QWORD PTR [r12+0x380]
    786625d01142:	jrcxz  0x786625d01149
    786625d01144:	jmp    0x786625d013a3
    786625d01149:	mov    r13,QWORD PTR [r12+0xf0]
    786625d01151:	mov    QWORD PTR [r12+0x100],r13
    786625d01159:	mov    r11,QWORD PTR [rsp+0x48]
    786625d0115e:	mov    QWORD PTR [r12+0x398],r11
    786625d01166:	mov    rdi,QWORD PTR [r12+0x100]
    786625d0116e:	add    rsp,0x50
    786625d01172:	movabs r11,0x5c9c39de20a0
    786625d0117c:	jmp    r11
    786625d0117f:	mov    eax,0x41078c
    786625d01184:	mov    QWORD PTR [r12+0x100],rax
    786625d0118c:	push   rdx
    786625d0118d:	push   rsi
    786625d0118e:	push   r10
    786625d01190:	push   r11
    786625d01192:	pushf
    786625d01193:	pop    r11
    786625d01195:	mov    QWORD PTR [rsp+0x68],r11
    786625d0119a:	mov    rdx,QWORD PTR [rsp+0x68]
    786625d0119f:	mov    r10d,edx
    786625d011a2:	and    r10d,0xc0
    786625d011a9:	shl    r10d,0x18
    786625d011ad:	mov    r11d,edx
    786625d011b0:	and    r11d,0x1
    786625d011b4:	shl    r11d,0x1d
    786625d011b8:	or     r10d,r11d
    786625d011bb:	mov    r11d,edx
    786625d011be:	and    r11d,0x800
    786625d011c5:	shl    r11d,0x11
    786625d011c9:	or     r10d,r11d
    786625d011cc:	btc    r10,0x1d
    786625d011d1:	mov    r11d,0xf0000000
    786625d011d7:	and    r11,r10
    786625d011da:	movabs rsi,0xffffffff0fffffff
    786625d011e4:	and    rbx,rsi
    786625d011e7:	or     rbx,r11
    786625d011ea:	pop    r11
    786625d011ec:	pop    r10
    786625d011ee:	pop    rsi
    786625d011ef:	pop    rdx
    786625d011f0:	mov    QWORD PTR [r12+0x108],rbx
    786625d011f8:	add    rsp,0x50
    786625d011fc:	mov    eax,0xc
    786625d01201:	movabs r11,0x5c9c39de2390
    786625d0120b:	jmp    r11
    786625d0120e:	mov    eax,0x410888
    786625d01213:	mov    QWORD PTR [r12+0x100],rax
    786625d0121b:	push   rdx
    786625d0121c:	push   rsi
    786625d0121d:	push   r10
    786625d0121f:	push   r11
    786625d01221:	mov    rdx,QWORD PTR [rsp+0x68]
    786625d01226:	mov    r10d,edx
    786625d01229:	and    r10d,0xc0
    786625d01230:	shl    r10d,0x18
    786625d01234:	mov    r11d,edx
    786625d01237:	and    r11d,0x1
    786625d0123b:	shl    r11d,0x1d
    786625d0123f:	or     r10d,r11d
    786625d01242:	mov    r11d,edx
    786625d01245:	and    r11d,0x800
    786625d0124c:	shl    r11d,0x11
    786625d01250:	or     r10d,r11d
    786625d01253:	btc    r10,0x1d
    786625d01258:	mov    r11d,0xf0000000
    786625d0125e:	and    r11,r10
    786625d01261:	movabs rsi,0xffffffff0fffffff
    786625d0126b:	and    rbx,rsi
    786625d0126e:	or     rbx,r11
    786625d01271:	pop    r11
    786625d01273:	pop    r10
    786625d01275:	pop    rsi
    786625d01276:	pop    rdx
    786625d01277:	mov    QWORD PTR [r12+0x108],rbx
    786625d0127f:	add    rsp,0x50
    786625d01283:	mov    eax,0xc
    786625d01288:	movabs r11,0x5c9c39de2390
    786625d01292:	jmp    r11
    786625d01295:	mov    eax,0x410948
    786625d0129a:	mov    QWORD PTR [r12+0x100],rax
    786625d012a2:	push   rdx
    786625d012a3:	push   rsi
    786625d012a4:	push   r10
    786625d012a6:	push   r11
    786625d012a8:	mov    rdx,QWORD PTR [rsp+0x68]
    786625d012ad:	mov    r10d,edx
    786625d012b0:	and    r10d,0xc0
    786625d012b7:	shl    r10d,0x18
    786625d012bb:	mov    r11d,edx
    786625d012be:	and    r11d,0x1
    786625d012c2:	shl    r11d,0x1d
    786625d012c6:	or     r10d,r11d
    786625d012c9:	mov    r11d,edx
    786625d012cc:	and    r11d,0x800
    786625d012d3:	shl    r11d,0x11
    786625d012d7:	or     r10d,r11d
    786625d012da:	btc    r10,0x1d
    786625d012df:	mov    r11d,0xf0000000
    786625d012e5:	and    r11,r10
    786625d012e8:	movabs rsi,0xffffffff0fffffff
    786625d012f2:	and    rbx,rsi
    786625d012f5:	or     rbx,r11
    786625d012f8:	pop    r11
    786625d012fa:	pop    r10
    786625d012fc:	pop    rsi
    786625d012fd:	pop    rdx
    786625d012fe:	mov    QWORD PTR [r12+0x108],rbx
    786625d01306:	add    rsp,0x50
    786625d0130a:	mov    eax,0xc
    786625d0130f:	movabs r11,0x5c9c39de2390
    786625d01319:	jmp    r11
    786625d0131c:	mov    eax,0x410984
    786625d01321:	mov    QWORD PTR [r12+0x100],rax
    786625d01329:	push   rdx
    786625d0132a:	push   rsi
    786625d0132b:	push   r10
    786625d0132d:	push   r11
    786625d0132f:	mov    rdx,QWORD PTR [rsp+0x68]
    786625d01334:	mov    r10d,edx
    786625d01337:	and    r10d,0xc0
    786625d0133e:	shl    r10d,0x18
    786625d01342:	mov    r11d,edx
    786625d01345:	and    r11d,0x1
    786625d01349:	shl    r11d,0x1d
    786625d0134d:	or     r10d,r11d
    786625d01350:	mov    r11d,edx
    786625d01353:	and    r11d,0x800
    786625d0135a:	shl    r11d,0x11
    786625d0135e:	or     r10d,r11d
    786625d01361:	btc    r10,0x1d
    786625d01366:	mov    r11d,0xf0000000
    786625d0136c:	and    r11,r10
    786625d0136f:	movabs rsi,0xffffffff0fffffff
    786625d01379:	and    rbx,rsi
    786625d0137c:	or     rbx,r11
    786625d0137f:	pop    r11
    786625d01381:	pop    r10
    786625d01383:	pop    rsi
    786625d01384:	pop    rdx
    786625d01385:	mov    QWORD PTR [r12+0x108],rbx
    786625d0138d:	add    rsp,0x50
    786625d01391:	mov    eax,0xc
    786625d01396:	movabs r11,0x5c9c39de2390
    786625d013a0:	jmp    r11
    786625d013a3:	mov    eax,0x4109a0
    786625d013a8:	mov    QWORD PTR [r12+0x100],rax
    786625d013b0:	push   rdx
    786625d013b1:	push   rsi
    786625d013b2:	push   r10
    786625d013b4:	push   r11
    786625d013b6:	mov    rdx,QWORD PTR [rsp+0x68]
    786625d013bb:	mov    r10d,edx
    786625d013be:	and    r10d,0xc0
    786625d013c5:	shl    r10d,0x18
    786625d013c9:	mov    r11d,edx
    786625d013cc:	and    r11d,0x1
    786625d013d0:	shl    r11d,0x1d
    786625d013d4:	or     r10d,r11d
    786625d013d7:	mov    r11d,edx
    786625d013da:	and    r11d,0x800
    786625d013e1:	shl    r11d,0x11
    786625d013e5:	or     r10d,r11d
    786625d013e8:	btc    r10,0x1d
    786625d013ed:	mov    r11d,0xf0000000
    786625d013f3:	and    r11,r10
    786625d013f6:	movabs rsi,0xffffffff0fffffff
    786625d01400:	and    rbx,rsi
    786625d01403:	or     rbx,r11
    786625d01406:	pop    r11
    786625d01408:	pop    r10
    786625d0140a:	pop    rsi
    786625d0140b:	pop    rdx
    786625d0140c:	mov    QWORD PTR [r12+0x108],rbx
    786625d01414:	add    rsp,0x50
    786625d01418:	mov    eax,0xc
    786625d0141d:	movabs r11,0x5c9c39de2390
    786625d01427:	jmp    r11
    786625d0142a:	nop    WORD PTR [rax+rax*1+0x0]
    786625d01430:	sub    rsp,0x50
    786625d01434:	mov    r11,QWORD PTR [r12+0x398]
    786625d0143c:	mov    QWORD PTR [rsp+0x48],r11
    786625d01441:	jmp    0x786625cfe9cb
    786625d01446:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d01450:	sub    rsp,0x50
    786625d01454:	mov    r11,QWORD PTR [r12+0x398]
    786625d0145c:	mov    QWORD PTR [rsp+0x48],r11
    786625d01461:	jmp    0x786625cfeb77
    786625d01466:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d01470:	sub    rsp,0x50
    786625d01474:	mov    r11,QWORD PTR [r12+0x398]
    786625d0147c:	mov    QWORD PTR [rsp+0x48],r11
    786625d01481:	jmp    0x786625cfec21
    786625d01486:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d01490:	sub    rsp,0x50
    786625d01494:	mov    r11,QWORD PTR [r12+0x398]
    786625d0149c:	mov    QWORD PTR [rsp+0x48],r11
    786625d014a1:	jmp    0x786625d0073c
    786625d014a6:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d014b0:	sub    rsp,0x50
    786625d014b4:	mov    r11,QWORD PTR [r12+0x398]
    786625d014bc:	mov    QWORD PTR [rsp+0x48],r11
    786625d014c1:	jmp    0x786625d008c5
    786625d014c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d014d0:	sub    rsp,0x50
    786625d014d4:	mov    r11,QWORD PTR [r12+0x398]
    786625d014dc:	mov    QWORD PTR [rsp+0x48],r11
    786625d014e1:	jmp    0x786625d00a4a
    786625d014e6:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d014f0:	sub    rsp,0x50
    786625d014f4:	mov    r11,QWORD PTR [r12+0x398]
    786625d014fc:	mov    QWORD PTR [rsp+0x48],r11
    786625d01501:	jmp    0x786625d00e3f
    786625d01506:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d01510:	sub    rsp,0x50
    786625d01514:	mov    r11,QWORD PTR [r12+0x398]
    786625d0151c:	mov    QWORD PTR [rsp+0x48],r11
    786625d01521:	jmp    0x786625d01021
    786625d01526:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d01530:	sub    rsp,0x50
    786625d01534:	mov    r11,QWORD PTR [r12+0x398]
    786625d0153c:	mov    QWORD PTR [rsp+0x48],r11
    786625d01541:	jmp    0x786625d01055
    786625d01546:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d01550:	sub    rsp,0x50
    786625d01554:	mov    r11,QWORD PTR [r12+0x398]
    786625d0155c:	mov    QWORD PTR [rsp+0x48],r11
    786625d01561:	jmp    0x786625d0113a
    786625d01566:	nop
    786625d01567:	nop
