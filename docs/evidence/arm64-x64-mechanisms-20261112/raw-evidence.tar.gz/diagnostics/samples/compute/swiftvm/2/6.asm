
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/2/6.bin:     file format binary


Disassembly of section .data:

0000786625d02190 <.data>:
    786625d02190:	sub    rsp,0x10
    786625d02194:	mov    r11,QWORD PTR [r12+0x398]
    786625d0219c:	mov    QWORD PTR [rsp],r11
    786625d021a0:	mov    r13d,DWORD PTR [r12]
    786625d021a4:	mov    r14d,r13d
    786625d021a7:	mov    r14d,r14d
    786625d021aa:	shr    r14d,0x10
    786625d021ae:	mov    ecx,r14d
    786625d021b1:	xor    r13,rcx
    786625d021b4:	mov    r13d,r13d
    786625d021b7:	mov    QWORD PTR [r12+0x40],r13
    786625d021bc:	mov    r14d,0x352d
    786625d021c2:	mov    QWORD PTR [r12+0x48],r14
    786625d021c7:	mov    r14d,0x352d
    786625d021cd:	mov    r15d,0x7feb
    786625d021d3:	and    r15d,0xffff
    786625d021da:	mov    rax,r14
    786625d021dd:	movabs rcx,0xffffffff0000ffff
    786625d021e7:	and    rax,rcx
    786625d021ea:	mov    rdx,r15
    786625d021ed:	shl    rdx,0x10
    786625d021f1:	mov    ecx,0xffff0000
    786625d021f6:	and    rdx,rcx
    786625d021f9:	or     rax,rdx
    786625d021fc:	mov    ebp,eax
    786625d021fe:	mov    QWORD PTR [r12+0x48],rbp
    786625d02203:	mov    r14d,0x0
    786625d02209:	mov    eax,r13d
    786625d0220c:	mov    ecx,ebp
    786625d0220e:	imul   rax,rcx
    786625d02212:	mov    r15d,eax
    786625d02215:	mov    ecx,r15d
    786625d02218:	mov    r13d,r14d
    786625d0221b:	add    r13d,ecx
    786625d0221e:	mov    QWORD PTR [r12+0x40],r13
    786625d02223:	mov    r14d,0xa68b
    786625d02229:	mov    QWORD PTR [r12+0x48],r14
    786625d0222e:	mov    r14d,0xa68b
    786625d02234:	mov    r15d,0x846c
    786625d0223a:	and    r15d,0xffff
    786625d02241:	mov    rax,r14
    786625d02244:	movabs rcx,0xffffffff0000ffff
    786625d0224e:	and    rax,rcx
    786625d02251:	mov    rdx,r15
    786625d02254:	shl    rdx,0x10
    786625d02258:	mov    ecx,0xffff0000
    786625d0225d:	and    rdx,rcx
    786625d02260:	or     rax,rdx
    786625d02263:	mov    ebp,eax
    786625d02265:	mov    QWORD PTR [r12+0x48],rbp
    786625d0226a:	mov    r14d,r13d
    786625d0226d:	mov    r14d,r14d
    786625d02270:	shr    r14d,0xf
    786625d02274:	mov    ecx,r14d
    786625d02277:	xor    r13,rcx
    786625d0227a:	mov    r13d,r13d
    786625d0227d:	mov    QWORD PTR [r12+0x40],r13
    786625d02282:	mov    r14d,0x0
    786625d02288:	mov    eax,r13d
    786625d0228b:	mov    ecx,ebp
    786625d0228d:	imul   rax,rcx
    786625d02291:	mov    r15d,eax
    786625d02294:	mov    ecx,r15d
    786625d02297:	mov    r13d,r14d
    786625d0229a:	add    r13d,ecx
    786625d0229d:	mov    QWORD PTR [r12+0x40],r13
    786625d022a2:	mov    r14d,r13d
    786625d022a5:	mov    r14d,r14d
    786625d022a8:	shr    r14d,0x10
    786625d022ac:	mov    ecx,r14d
    786625d022af:	xor    r13,rcx
    786625d022b2:	mov    r13d,r13d
    786625d022b5:	mov    QWORD PTR [r12],r13
    786625d022b9:	mov    rcx,QWORD PTR [r12+0x380]
    786625d022c1:	jrcxz  0x786625d022c8
    786625d022c3:	jmp    0x786625d022fd
    786625d022c8:	mov    r13,QWORD PTR [r12+0xf0]
    786625d022d0:	mov    QWORD PTR [r12+0x100],r13
    786625d022d8:	mov    r11,QWORD PTR [rsp]
    786625d022dc:	mov    QWORD PTR [r12+0x398],r11
    786625d022e4:	mov    rdi,QWORD PTR [r12+0x100]
    786625d022ec:	add    rsp,0x10
    786625d022f0:	movabs r11,0x5c9c39de20a0
    786625d022fa:	jmp    r11
    786625d022fd:	mov    eax,0x4109c8
    786625d02302:	mov    QWORD PTR [r12+0x100],rax
    786625d0230a:	push   rdx
    786625d0230b:	push   rsi
    786625d0230c:	push   r10
    786625d0230e:	push   r11
    786625d02310:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d02315:	mov    r10d,edx
    786625d02318:	and    r10d,0xc0
    786625d0231f:	shl    r10d,0x18
    786625d02323:	mov    r11d,edx
    786625d02326:	and    r11d,0x1
    786625d0232a:	shl    r11d,0x1d
    786625d0232e:	or     r10d,r11d
    786625d02331:	mov    r11d,edx
    786625d02334:	and    r11d,0x800
    786625d0233b:	shl    r11d,0x11
    786625d0233f:	or     r10d,r11d
    786625d02342:	btc    r10,0x1d
    786625d02347:	mov    r11d,0xf0000000
    786625d0234d:	and    r11,r10
    786625d02350:	movabs rsi,0xffffffff0fffffff
    786625d0235a:	and    rbx,rsi
    786625d0235d:	or     rbx,r11
    786625d02360:	pop    r11
    786625d02362:	pop    r10
    786625d02364:	pop    rsi
    786625d02365:	pop    rdx
    786625d02366:	mov    QWORD PTR [r12+0x108],rbx
    786625d0236e:	add    rsp,0x10
    786625d02372:	mov    eax,0xc
    786625d02377:	movabs r11,0x5c9c39de2390
    786625d02381:	jmp    r11
