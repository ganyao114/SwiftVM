
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/2/2.bin:     file format binary


Disassembly of section .data:

0000786625d01570 <.data>:
    786625d01570:	sub    rsp,0x10
    786625d01574:	mov    r13d,DWORD PTR [r12+0xa0]
    786625d0157c:	sub    r13d,0x1
    786625d01580:	mov    QWORD PTR [r12+0xa0],r13
    786625d01588:	mov    rcx,QWORD PTR [r12+0x380]
    786625d01590:	jrcxz  0x786625d01597
    786625d01592:	jmp    0x786625d01715
    786625d01597:	pushf
    786625d01598:	pop    r11
    786625d0159a:	mov    QWORD PTR [rsp],r11
    786625d0159e:	jne    0x786625d0167d
    786625d015a4:	jmp    0x786625d015a9
    786625d015a9:	mov    r13,QWORD PTR [r12+0xf8]
    786625d015b1:	mov    r14,r13
    786625d015b4:	add    r14,0x120
    786625d015bb:	mov    r15,QWORD PTR [r14]
    786625d015be:	mov    QWORD PTR [r12+0x98],r15
    786625d015c6:	mov    r14d,0x80
    786625d015cc:	mov    QWORD PTR [r12+0x40],r14
    786625d015d1:	mov    r14,r13
    786625d015d4:	add    r14,0x100
    786625d015db:	mov    QWORD PTR [r12],r14
    786625d015df:	mov    r14,r13
    786625d015e2:	add    r14,0x17c
    786625d015e9:	mov    QWORD PTR [r12+0x8],r14
    786625d015ee:	mov    r14d,0x1
    786625d015f4:	mov    QWORD PTR [r12+0x10],r14
    786625d015f9:	add    r13,0x17c
    786625d01600:	movzx  r14d,BYTE PTR [r12+0x40]
    786625d01606:	mov    BYTE PTR [r13+0x0],r14b
    786625d0160a:	mov    r13d,0x0
    786625d01610:	mov    DWORD PTR [r12+0x32c],r13d
    786625d01618:	mov    r13d,0x4102a8
    786625d0161e:	mov    QWORD PTR [r12+0xf0],r13
    786625d01626:	mov    r13d,0x410728
    786625d0162c:	mov    QWORD PTR [r12+0x100],r13
    786625d01634:	mov    r11,QWORD PTR [rsp]
    786625d01638:	mov    QWORD PTR [r12+0x398],r11
    786625d01640:	mov    edi,0x410728
    786625d01645:	mov    QWORD PTR [r12+0x100],rdi
    786625d0164d:	add    rsp,0x10
    786625d01651:	nop    DWORD PTR [rax+0x0]
    786625d01658:	jmp    QWORD PTR [rip+0x2]        # 0x786625d01660
    786625d0165e:	xchg   ax,ax
    786625d01660:	(bad)
    786625d01661:	jmp    0x78669e363c35
    786625d01666:	add    BYTE PTR [rax],al
    786625d01668:	jo     0x786625d01680
    786625d0166a:	shl    BYTE PTR [rip+0x7866],1        # 0x786625d08ed6
    786625d01670:	movabs r11,0x5c9c39de20a0
    786625d0167a:	jmp    r11
    786625d0167d:	mov    r13,QWORD PTR [r12+0xf8]
    786625d01685:	add    r13,0x100
    786625d0168c:	mov    QWORD PTR [r12],r13
    786625d01690:	mov    r13d,0x0
    786625d01696:	mov    r14,QWORD PTR [r12+0x98]
    786625d0169e:	mov    rcx,r14
    786625d016a1:	or     r13,rcx
    786625d016a4:	mov    QWORD PTR [r12+0x8],r13
    786625d016a9:	mov    r13d,0x12c
    786625d016af:	mov    QWORD PTR [r12+0x10],r13
    786625d016b4:	mov    r13d,0x410284
    786625d016ba:	mov    QWORD PTR [r12+0xf0],r13
    786625d016c2:	mov    r13d,0x410728
    786625d016c8:	mov    QWORD PTR [r12+0x100],r13
    786625d016d0:	mov    r11,QWORD PTR [rsp]
    786625d016d4:	mov    QWORD PTR [r12+0x398],r11
    786625d016dc:	mov    edi,0x410728
    786625d016e1:	mov    QWORD PTR [r12+0x100],rdi
    786625d016e9:	add    rsp,0x10
    786625d016ed:	nop    DWORD PTR [rax]
    786625d016f0:	jmp    QWORD PTR [rip+0x2]        # 0x786625d016f8
    786625d016f6:	xchg   ax,ax
    786625d016f8:	(bad)
    786625d016f9:	jmp    0x78669e363ccd
    786625d016fe:	add    BYTE PTR [rax],al
    786625d01700:	or     BYTE PTR [rdi],dl
    786625d01702:	shl    BYTE PTR [rip+0x7866],1        # 0x786625d08f6e
    786625d01708:	movabs r11,0x5c9c39de20a0
    786625d01712:	jmp    r11
    786625d01715:	mov    eax,0x410288
    786625d0171a:	mov    QWORD PTR [r12+0x100],rax
    786625d01722:	push   rdx
    786625d01723:	push   rsi
    786625d01724:	push   r10
    786625d01726:	push   r11
    786625d01728:	pushf
    786625d01729:	pop    r11
    786625d0172b:	mov    QWORD PTR [rsp+0x20],r11
    786625d01730:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d01735:	mov    r10d,edx
    786625d01738:	and    r10d,0xc0
    786625d0173f:	shl    r10d,0x18
    786625d01743:	mov    r11d,edx
    786625d01746:	and    r11d,0x1
    786625d0174a:	shl    r11d,0x1d
    786625d0174e:	or     r10d,r11d
    786625d01751:	mov    r11d,edx
    786625d01754:	and    r11d,0x800
    786625d0175b:	shl    r11d,0x11
    786625d0175f:	or     r10d,r11d
    786625d01762:	btc    r10,0x1d
    786625d01767:	mov    r11d,0xf0000000
    786625d0176d:	and    r11,r10
    786625d01770:	movabs rsi,0xffffffff0fffffff
    786625d0177a:	and    rbx,rsi
    786625d0177d:	or     rbx,r11
    786625d01780:	pop    r11
    786625d01782:	pop    r10
    786625d01784:	pop    rsi
    786625d01785:	pop    rdx
    786625d01786:	mov    QWORD PTR [r12+0x108],rbx
    786625d0178e:	add    rsp,0x10
    786625d01792:	mov    eax,0xc
    786625d01797:	movabs r11,0x5c9c39de2390
    786625d017a1:	jmp    r11
    786625d017a4:	data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d017b0:	sub    rsp,0x10
    786625d017b4:	mov    r11,QWORD PTR [r12+0x398]
    786625d017bc:	mov    QWORD PTR [rsp],r11
    786625d017c0:	jmp    0x786625d015a9
    786625d017c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d017d0:	sub    rsp,0x10
    786625d017d4:	mov    r11,QWORD PTR [r12+0x398]
    786625d017dc:	mov    QWORD PTR [rsp],r11
    786625d017e0:	jmp    0x786625d0167d
    786625d017e5:	nop
    786625d017e6:	nop
    786625d017e7:	nop
