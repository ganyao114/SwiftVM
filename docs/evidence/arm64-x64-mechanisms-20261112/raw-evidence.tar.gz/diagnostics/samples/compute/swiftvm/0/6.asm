
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/0/6.bin:     file format binary


Disassembly of section .data:

00007c33ec902190 <.data>:
    7c33ec902190:	sub    rsp,0x10
    7c33ec902194:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90219c:	mov    QWORD PTR [rsp],r11
    7c33ec9021a0:	mov    r13d,DWORD PTR [r12]
    7c33ec9021a4:	mov    r14d,r13d
    7c33ec9021a7:	mov    r14d,r14d
    7c33ec9021aa:	shr    r14d,0x10
    7c33ec9021ae:	mov    ecx,r14d
    7c33ec9021b1:	xor    r13,rcx
    7c33ec9021b4:	mov    r13d,r13d
    7c33ec9021b7:	mov    QWORD PTR [r12+0x40],r13
    7c33ec9021bc:	mov    r14d,0x352d
    7c33ec9021c2:	mov    QWORD PTR [r12+0x48],r14
    7c33ec9021c7:	mov    r14d,0x352d
    7c33ec9021cd:	mov    r15d,0x7feb
    7c33ec9021d3:	and    r15d,0xffff
    7c33ec9021da:	mov    rax,r14
    7c33ec9021dd:	movabs rcx,0xffffffff0000ffff
    7c33ec9021e7:	and    rax,rcx
    7c33ec9021ea:	mov    rdx,r15
    7c33ec9021ed:	shl    rdx,0x10
    7c33ec9021f1:	mov    ecx,0xffff0000
    7c33ec9021f6:	and    rdx,rcx
    7c33ec9021f9:	or     rax,rdx
    7c33ec9021fc:	mov    ebp,eax
    7c33ec9021fe:	mov    QWORD PTR [r12+0x48],rbp
    7c33ec902203:	mov    r14d,0x0
    7c33ec902209:	mov    eax,r13d
    7c33ec90220c:	mov    ecx,ebp
    7c33ec90220e:	imul   rax,rcx
    7c33ec902212:	mov    r15d,eax
    7c33ec902215:	mov    ecx,r15d
    7c33ec902218:	mov    r13d,r14d
    7c33ec90221b:	add    r13d,ecx
    7c33ec90221e:	mov    QWORD PTR [r12+0x40],r13
    7c33ec902223:	mov    r14d,0xa68b
    7c33ec902229:	mov    QWORD PTR [r12+0x48],r14
    7c33ec90222e:	mov    r14d,0xa68b
    7c33ec902234:	mov    r15d,0x846c
    7c33ec90223a:	and    r15d,0xffff
    7c33ec902241:	mov    rax,r14
    7c33ec902244:	movabs rcx,0xffffffff0000ffff
    7c33ec90224e:	and    rax,rcx
    7c33ec902251:	mov    rdx,r15
    7c33ec902254:	shl    rdx,0x10
    7c33ec902258:	mov    ecx,0xffff0000
    7c33ec90225d:	and    rdx,rcx
    7c33ec902260:	or     rax,rdx
    7c33ec902263:	mov    ebp,eax
    7c33ec902265:	mov    QWORD PTR [r12+0x48],rbp
    7c33ec90226a:	mov    r14d,r13d
    7c33ec90226d:	mov    r14d,r14d
    7c33ec902270:	shr    r14d,0xf
    7c33ec902274:	mov    ecx,r14d
    7c33ec902277:	xor    r13,rcx
    7c33ec90227a:	mov    r13d,r13d
    7c33ec90227d:	mov    QWORD PTR [r12+0x40],r13
    7c33ec902282:	mov    r14d,0x0
    7c33ec902288:	mov    eax,r13d
    7c33ec90228b:	mov    ecx,ebp
    7c33ec90228d:	imul   rax,rcx
    7c33ec902291:	mov    r15d,eax
    7c33ec902294:	mov    ecx,r15d
    7c33ec902297:	mov    r13d,r14d
    7c33ec90229a:	add    r13d,ecx
    7c33ec90229d:	mov    QWORD PTR [r12+0x40],r13
    7c33ec9022a2:	mov    r14d,r13d
    7c33ec9022a5:	mov    r14d,r14d
    7c33ec9022a8:	shr    r14d,0x10
    7c33ec9022ac:	mov    ecx,r14d
    7c33ec9022af:	xor    r13,rcx
    7c33ec9022b2:	mov    r13d,r13d
    7c33ec9022b5:	mov    QWORD PTR [r12],r13
    7c33ec9022b9:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec9022c1:	jrcxz  0x7c33ec9022c8
    7c33ec9022c3:	jmp    0x7c33ec9022fd
    7c33ec9022c8:	mov    r13,QWORD PTR [r12+0xf0]
    7c33ec9022d0:	mov    QWORD PTR [r12+0x100],r13
    7c33ec9022d8:	mov    r11,QWORD PTR [rsp]
    7c33ec9022dc:	mov    QWORD PTR [r12+0x398],r11
    7c33ec9022e4:	mov    rdi,QWORD PTR [r12+0x100]
    7c33ec9022ec:	add    rsp,0x10
    7c33ec9022f0:	movabs r11,0x5585303950a0
    7c33ec9022fa:	jmp    r11
    7c33ec9022fd:	mov    eax,0x4109c8
    7c33ec902302:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90230a:	push   rdx
    7c33ec90230b:	push   rsi
    7c33ec90230c:	push   r10
    7c33ec90230e:	push   r11
    7c33ec902310:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec902315:	mov    r10d,edx
    7c33ec902318:	and    r10d,0xc0
    7c33ec90231f:	shl    r10d,0x18
    7c33ec902323:	mov    r11d,edx
    7c33ec902326:	and    r11d,0x1
    7c33ec90232a:	shl    r11d,0x1d
    7c33ec90232e:	or     r10d,r11d
    7c33ec902331:	mov    r11d,edx
    7c33ec902334:	and    r11d,0x800
    7c33ec90233b:	shl    r11d,0x11
    7c33ec90233f:	or     r10d,r11d
    7c33ec902342:	btc    r10,0x1d
    7c33ec902347:	mov    r11d,0xf0000000
    7c33ec90234d:	and    r11,r10
    7c33ec902350:	movabs rsi,0xffffffff0fffffff
    7c33ec90235a:	and    rbx,rsi
    7c33ec90235d:	or     rbx,r11
    7c33ec902360:	pop    r11
    7c33ec902362:	pop    r10
    7c33ec902364:	pop    rsi
    7c33ec902365:	pop    rdx
    7c33ec902366:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90236e:	add    rsp,0x10
    7c33ec902372:	mov    eax,0xc
    7c33ec902377:	movabs r11,0x558530395390
    7c33ec902381:	jmp    r11
