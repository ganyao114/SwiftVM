
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/0/8.bin:     file format binary


Disassembly of section .data:

00007c33ec902c00 <.data>:
    7c33ec902c00:	sub    rsp,0x150
    7c33ec902c07:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec902c0f:	mov    QWORD PTR [rsp],r11
    7c33ec902c13:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec902c1c:	je     0x7c33ec902cac
    7c33ec902c22:	push   rdx
    7c33ec902c23:	push   rsi
    7c33ec902c24:	push   r10
    7c33ec902c26:	push   r11
    7c33ec902c28:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec902c2d:	mov    r10d,edx
    7c33ec902c30:	and    r10d,0xc0
    7c33ec902c37:	shl    r10d,0x18
    7c33ec902c3b:	mov    r11d,edx
    7c33ec902c3e:	and    r11d,0x1
    7c33ec902c42:	shl    r11d,0x1d
    7c33ec902c46:	or     r10d,r11d
    7c33ec902c49:	mov    r11d,edx
    7c33ec902c4c:	and    r11d,0x800
    7c33ec902c53:	shl    r11d,0x11
    7c33ec902c57:	or     r10d,r11d
    7c33ec902c5a:	btc    r10,0x1d
    7c33ec902c5f:	mov    r11d,0xf0000000
    7c33ec902c65:	and    r11,r10
    7c33ec902c68:	movabs rsi,0xffffffff0fffffff
    7c33ec902c72:	and    rbx,rsi
    7c33ec902c75:	or     rbx,r11
    7c33ec902c78:	pop    r11
    7c33ec902c7a:	pop    r10
    7c33ec902c7c:	pop    rsi
    7c33ec902c7d:	pop    rdx
    7c33ec902c7e:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec902c86:	mov    eax,0x4103f8
    7c33ec902c8b:	mov    QWORD PTR [r12+0x100],rax
    7c33ec902c93:	add    rsp,0x150
    7c33ec902c9a:	mov    eax,0x3
    7c33ec902c9f:	movabs r11,0x558530395390
    7c33ec902ca9:	jmp    r11
    7c33ec902cac:	mov    r13d,DWORD PTR [r12+0x98]
    7c33ec902cb4:	add    r13d,0x1
    7c33ec902cb8:	mov    QWORD PTR [r12+0x98],r13
    7c33ec902cc0:	sub    r13d,0x10000
    7c33ec902cc7:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec902ccf:	jrcxz  0x7c33ec902cd6
    7c33ec902cd1:	jmp    0x7c33ec909bc6
    7c33ec902cd6:	pushf
    7c33ec902cd7:	pop    r11
    7c33ec902cd9:	mov    QWORD PTR [rsp],r11
    7c33ec902cdd:	jne    0x7c33ec9079cf
    7c33ec902ce3:	jmp    0x7c33ec902ce8
    7c33ec902ce8:	mov    r13d,0x420000
    7c33ec902cee:	mov    QWORD PTR [r12+0x40],r13
    7c33ec902cf3:	movabs r13,0x100000001
    7c33ec902cfd:	mov    r14d,0x0
    7c33ec902d03:	mov    QWORD PTR [r12+0x110],r13
    7c33ec902d0b:	mov    QWORD PTR [r12+0x118],r14
    7c33ec902d13:	movabs r13,0x3fa0000000000000
    7c33ec902d1d:	mov    QWORD PTR [r12+0x50],r13
    7c33ec902d22:	mov    r13d,0x420b10
    7c33ec902d28:	mov    r14,QWORD PTR [r13+0x0]
    7c33ec902d2c:	mov    r13d,0x0
    7c33ec902d32:	mov    QWORD PTR [r12+0x120],r14
    7c33ec902d3a:	mov    QWORD PTR [r12+0x128],r13
    7c33ec902d42:	movabs r13,0x4100000041
    7c33ec902d4c:	mov    r14d,0x0
    7c33ec902d52:	mov    QWORD PTR [r12+0x140],r13
    7c33ec902d5a:	mov    QWORD PTR [r12+0x148],r14
    7c33ec902d62:	movabs r13,0x3fc0000000000000
    7c33ec902d6c:	movabs r14,0x3fc0000000000000
    7c33ec902d76:	mov    QWORD PTR [r12+0x150],r13
    7c33ec902d7e:	mov    QWORD PTR [r12+0x158],r14
    7c33ec902d86:	movabs r13,0x200000002
    7c33ec902d90:	mov    r14d,0x0
    7c33ec902d96:	mov    QWORD PTR [r12+0x160],r13
    7c33ec902d9e:	mov    QWORD PTR [r12+0x168],r14
    7c33ec902da6:	mov    r13,QWORD PTR [r12+0x50]
    7c33ec902dab:	and    r13,0xffffffffffffffff
    7c33ec902daf:	mov    QWORD PTR [r12+0x130],r13
    7c33ec902db7:	mov    QWORD PTR [r12+0x138],r13
    7c33ec902dbf:	mov    r13d,0x2
    7c33ec902dc5:	mov    QWORD PTR [r12+0x170],r13
    7c33ec902dcd:	mov    QWORD PTR [r12+0x178],r13
    7c33ec902dd5:	mov    r13d,0x420000
    7c33ec902ddb:	mov    QWORD PTR [r12+0x40],r13
    7c33ec902de0:	mov    r13d,0x430000
    7c33ec902de6:	mov    QWORD PTR [r12+0x50],r13
    7c33ec902deb:	mov    r13d,0x420a40
    7c33ec902df1:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec902df7:	movdqa xmm0,xmm2
    7c33ec902dfb:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec902e05:	mov    r13d,0x0
    7c33ec902e0b:	mov    QWORD PTR [r12+0x48],r13
    7c33ec902e10:	mov    r13d,0x431000
    7c33ec902e16:	add    r13,0xe00
    7c33ec902e1d:	mov    QWORD PTR [r12+0x40],r13
    7c33ec902e22:	mov    r13d,0x430cb8
    7c33ec902e28:	mov    r14d,DWORD PTR [r12]
    7c33ec902e2c:	mov    DWORD PTR [r13+0x0],r14d
    7c33ec902e30:	mov    r13d,0x0
    7c33ec902e36:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec902e3e:	mov    r13d,0x432000
    7c33ec902e44:	add    r13,0x0
    7c33ec902e48:	mov    QWORD PTR [r12+0x50],r13
    7c33ec902e4d:	jmp    0x7c33ec902e52
    7c33ec902e52:	mov    r13,QWORD PTR [r12+0x180]
    7c33ec902e5a:	mov    r14,QWORD PTR [r12+0x188]
    7c33ec902e62:	mov    r15d,0x0
    7c33ec902e68:	and    r13,0xffffffffffffffff
    7c33ec902e6c:	mov    ecx,0xffffffff
    7c33ec902e71:	and    r13,rcx
    7c33ec902e74:	mov    rcx,r13
    7c33ec902e77:	mov    rbp,r15
    7c33ec902e7a:	or     rbp,rcx
    7c33ec902e7d:	and    r14,0xffffffffffffffff
    7c33ec902e81:	mov    ecx,0xffffffff
    7c33ec902e86:	and    r14,rcx
    7c33ec902e89:	shl    r14,0x20
    7c33ec902e8d:	mov    rcx,r14
    7c33ec902e90:	or     rbp,rcx
    7c33ec902e93:	mov    QWORD PTR [r12+0x210],rbp
    7c33ec902e9b:	mov    QWORD PTR [r12+0x218],r15
    7c33ec902ea3:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec902ead:	movdqa xmm2,xmm0
    7c33ec902eb1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec902ebb:	movdqa xmm3,xmm0
    7c33ec902ebf:	movdqa xmm1,xmm3
    7c33ec902ec3:	psubd  xmm2,xmm1
    7c33ec902ec7:	movdqa xmm14,xmm2
    7c33ec902ecc:	movdqa xmm1,xmm14
    7c33ec902ed1:	movq   rax,xmm1
    7c33ec902ed6:	mov    r13,rax
    7c33ec902ed9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec902ee3:	movdqa xmm2,xmm0
    7c33ec902ee7:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec902ef1:	movdqa xmm4,xmm0
    7c33ec902ef5:	movdqa xmm1,xmm4
    7c33ec902ef9:	paddq  xmm2,xmm1
    7c33ec902efd:	movdqa xmm0,xmm2
    7c33ec902f01:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec902f0b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec902f15:	movdqa xmm2,xmm0
    7c33ec902f19:	movdqa xmm1,xmm2
    7c33ec902f1d:	paddd  xmm3,xmm1
    7c33ec902f21:	movdqa xmm14,xmm3
    7c33ec902f26:	movdqa xmm1,xmm14
    7c33ec902f2b:	movq   rax,xmm1
    7c33ec902f30:	mov    r14,rax
    7c33ec902f33:	mov    r15d,0x0
    7c33ec902f39:	mov    QWORD PTR [r12+0x120],r14
    7c33ec902f41:	mov    QWORD PTR [r12+0x128],r15
    7c33ec902f49:	mov    r14d,0x0
    7c33ec902f4f:	mov    r15,r13
    7c33ec902f52:	mov    ecx,0xffffffff
    7c33ec902f57:	and    r15,rcx
    7c33ec902f5a:	and    r15,0xffffffffffffffff
    7c33ec902f5e:	mov    rcx,r15
    7c33ec902f61:	mov    rbp,r14
    7c33ec902f64:	or     rbp,rcx
    7c33ec902f67:	shr    r13,0x20
    7c33ec902f6b:	mov    ecx,0xffffffff
    7c33ec902f70:	and    r13,rcx
    7c33ec902f73:	and    r13,0xffffffffffffffff
    7c33ec902f77:	mov    rcx,r13
    7c33ec902f7a:	or     r14,rcx
    7c33ec902f7d:	mov    QWORD PTR [r12+0x220],rbp
    7c33ec902f85:	mov    QWORD PTR [r12+0x228],r14
    7c33ec902f8d:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec902f97:	movdqa xmm2,xmm0
    7c33ec902f9b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec902fa5:	movdqa xmm3,xmm0
    7c33ec902fa9:	movdqa xmm1,xmm3
    7c33ec902fad:	paddd  xmm2,xmm1
    7c33ec902fb1:	movdqa xmm14,xmm2
    7c33ec902fb6:	movdqa xmm1,xmm14
    7c33ec902fbb:	movq   rax,xmm1
    7c33ec902fc0:	mov    r13,rax
    7c33ec902fc3:	mov    r14d,0x0
    7c33ec902fc9:	mov    QWORD PTR [r12+0x210],r13
    7c33ec902fd1:	mov    QWORD PTR [r12+0x218],r14
    7c33ec902fd9:	lea    r13,[r12]
    7c33ec902fdd:	movabs r14,0xb6e61da31
    7c33ec902fe7:	mov    r15d,0x410468
    7c33ec902fed:	mov    rdx,QWORD PTR [rsp]
    7c33ec902ff1:	mov    r10d,edx
    7c33ec902ff4:	and    r10d,0xc0
    7c33ec902ffb:	shl    r10d,0x18
    7c33ec902fff:	mov    r11d,edx
    7c33ec903002:	and    r11d,0x1
    7c33ec903006:	shl    r11d,0x1d
    7c33ec90300a:	or     r10d,r11d
    7c33ec90300d:	mov    r11d,edx
    7c33ec903010:	and    r11d,0x800
    7c33ec903017:	shl    r11d,0x11
    7c33ec90301b:	or     r10d,r11d
    7c33ec90301e:	btc    r10,0x1d
    7c33ec903023:	mov    r11d,0xf0000000
    7c33ec903029:	and    r11,r10
    7c33ec90302c:	movabs rsi,0xffffffff0fffffff
    7c33ec903036:	and    rbx,rsi
    7c33ec903039:	or     rbx,r11
    7c33ec90303c:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec903048:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec903050:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec903056:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec90305c:	movabs r11,0x5585301fbdc0
    7c33ec903066:	mov    rdi,r13
    7c33ec903069:	mov    rsi,r14
    7c33ec90306c:	mov    rdx,r15
    7c33ec90306f:	call   r11
    7c33ec903072:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec903078:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec903080:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec90308c:	mov    rbp,rax
    7c33ec90308f:	mov    r13,QWORD PTR [r12+0x210]
    7c33ec903097:	mov    r14d,0x0
    7c33ec90309d:	mov    r15,r13
    7c33ec9030a0:	mov    ecx,0xffffffff
    7c33ec9030a5:	and    r15,rcx
    7c33ec9030a8:	and    r15,0xffffffffffffffff
    7c33ec9030ac:	mov    rcx,r15
    7c33ec9030af:	mov    rbp,r14
    7c33ec9030b2:	or     rbp,rcx
    7c33ec9030b5:	shr    r13,0x20
    7c33ec9030b9:	mov    ecx,0xffffffff
    7c33ec9030be:	and    r13,rcx
    7c33ec9030c1:	and    r13,0xffffffffffffffff
    7c33ec9030c5:	mov    rcx,r13
    7c33ec9030c8:	or     r14,rcx
    7c33ec9030cb:	mov    QWORD PTR [r12+0x210],rbp
    7c33ec9030d3:	mov    QWORD PTR [r12+0x218],r14
    7c33ec9030db:	lea    r13,[r12]
    7c33ec9030df:	movabs r14,0xb6e61da10
    7c33ec9030e9:	mov    r15d,0x410470
    7c33ec9030ef:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec9030fb:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec903103:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec903109:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec90310f:	movabs r11,0x5585301fbdc0
    7c33ec903119:	mov    rdi,r13
    7c33ec90311c:	mov    rsi,r14
    7c33ec90311f:	mov    rdx,r15
    7c33ec903122:	call   r11
    7c33ec903125:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec90312b:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec903133:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec90313f:	mov    rbp,rax
    7c33ec903142:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec90314c:	movdqa xmm2,xmm0
    7c33ec903150:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec90315a:	movdqa xmm3,xmm0
    7c33ec90315e:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec903166:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec903171:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec903179:	movdqa xmm0,xmm2
    7c33ec90317d:	movdqa xmm1,xmm3
    7c33ec903181:	movq   rax,xmm0
    7c33ec903186:	add    rax,rax
    7c33ec903189:	je     0x7c33ec90319f
    7c33ec90318b:	shr    rax,0x35
    7c33ec90318f:	sub    eax,0x201
    7c33ec903194:	cmp    eax,0x3fc
    7c33ec903199:	ja     0x7c33ec907a4d
    7c33ec90319f:	movdqa xmm14,xmm0
    7c33ec9031a4:	psrldq xmm14,0x8
    7c33ec9031aa:	movq   rax,xmm14
    7c33ec9031af:	add    rax,rax
    7c33ec9031b2:	je     0x7c33ec9031c8
    7c33ec9031b4:	shr    rax,0x35
    7c33ec9031b8:	sub    eax,0x201
    7c33ec9031bd:	cmp    eax,0x3fc
    7c33ec9031c2:	ja     0x7c33ec907a4d
    7c33ec9031c8:	movq   rax,xmm1
    7c33ec9031cd:	add    rax,rax
    7c33ec9031d0:	je     0x7c33ec9031e6
    7c33ec9031d2:	shr    rax,0x35
    7c33ec9031d6:	sub    eax,0x201
    7c33ec9031db:	cmp    eax,0x3fc
    7c33ec9031e0:	ja     0x7c33ec907a4d
    7c33ec9031e6:	movdqa xmm14,xmm1
    7c33ec9031eb:	psrldq xmm14,0x8
    7c33ec9031f1:	movq   rax,xmm14
    7c33ec9031f6:	add    rax,rax
    7c33ec9031f9:	je     0x7c33ec90320f
    7c33ec9031fb:	shr    rax,0x35
    7c33ec9031ff:	sub    eax,0x201
    7c33ec903204:	cmp    eax,0x3fc
    7c33ec903209:	ja     0x7c33ec907a4d
    7c33ec90320f:	mulpd  xmm0,xmm1
    7c33ec903213:	movdqa xmm4,xmm0
    7c33ec903217:	movdqa xmm0,xmm4
    7c33ec90321b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec903225:	mov    r13,QWORD PTR [r12+0x48]
    7c33ec90322a:	mov    r14,QWORD PTR [r12+0x50]
    7c33ec90322f:	mov    rcx,r13
    7c33ec903232:	add    r14,rcx
    7c33ec903235:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec90323d:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec903245:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec90324d:	shr    r11d,1
    7c33ec903250:	and    r11d,0x10
    7c33ec903254:	or     DWORD PTR [r12+0x314],r11d
    7c33ec90325c:	movdqu XMMWORD PTR [r14],xmm4
    7c33ec903261:	mov    r14d,0x0
    7c33ec903267:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec90326f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec903279:	movdqa xmm2,xmm0
    7c33ec90327d:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec903287:	movdqa xmm3,xmm0
    7c33ec90328b:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec903293:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec90329e:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec9032a6:	movdqa xmm0,xmm2
    7c33ec9032aa:	movdqa xmm1,xmm3
    7c33ec9032ae:	movq   rax,xmm0
    7c33ec9032b3:	add    rax,rax
    7c33ec9032b6:	je     0x7c33ec9032cc
    7c33ec9032b8:	shr    rax,0x35
    7c33ec9032bc:	sub    eax,0x201
    7c33ec9032c1:	cmp    eax,0x3fc
    7c33ec9032c6:	ja     0x7c33ec907a71
    7c33ec9032cc:	movdqa xmm14,xmm0
    7c33ec9032d1:	psrldq xmm14,0x8
    7c33ec9032d7:	movq   rax,xmm14
    7c33ec9032dc:	add    rax,rax
    7c33ec9032df:	je     0x7c33ec9032f5
    7c33ec9032e1:	shr    rax,0x35
    7c33ec9032e5:	sub    eax,0x201
    7c33ec9032ea:	cmp    eax,0x3fc
    7c33ec9032ef:	ja     0x7c33ec907a71
    7c33ec9032f5:	movq   rax,xmm1
    7c33ec9032fa:	add    rax,rax
    7c33ec9032fd:	je     0x7c33ec903313
    7c33ec9032ff:	shr    rax,0x35
    7c33ec903303:	sub    eax,0x201
    7c33ec903308:	cmp    eax,0x3fc
    7c33ec90330d:	ja     0x7c33ec907a71
    7c33ec903313:	movdqa xmm14,xmm1
    7c33ec903318:	psrldq xmm14,0x8
    7c33ec90331e:	movq   rax,xmm14
    7c33ec903323:	add    rax,rax
    7c33ec903326:	je     0x7c33ec90333c
    7c33ec903328:	shr    rax,0x35
    7c33ec90332c:	sub    eax,0x201
    7c33ec903331:	cmp    eax,0x3fc
    7c33ec903336:	ja     0x7c33ec907a71
    7c33ec90333c:	mulpd  xmm0,xmm1
    7c33ec903340:	movdqa xmm4,xmm0
    7c33ec903344:	movdqa xmm0,xmm4
    7c33ec903348:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec903352:	mov    r14,QWORD PTR [r12+0x40]
    7c33ec903357:	mov    rcx,r13
    7c33ec90335a:	add    r14,rcx
    7c33ec90335d:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec903365:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec90336d:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec903375:	shr    r11d,1
    7c33ec903378:	and    r11d,0x10
    7c33ec90337c:	or     DWORD PTR [r12+0x314],r11d
    7c33ec903384:	movdqu XMMWORD PTR [r14],xmm4
    7c33ec903389:	mov    r14d,0x0
    7c33ec90338f:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec903397:	add    r13,0x10
    7c33ec90339b:	mov    QWORD PTR [r12+0x48],r13
    7c33ec9033a0:	sub    r13,0x200
    7c33ec9033a7:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec9033af:	jrcxz  0x7c33ec9033b6
    7c33ec9033b1:	jmp    0x7c33ec909c58
    7c33ec9033b6:	pushf
    7c33ec9033b7:	pop    r11
    7c33ec9033b9:	mov    QWORD PTR [rsp],r11
    7c33ec9033bd:	jne    0x7c33ec902e52
    7c33ec9033c3:	jmp    0x7c33ec9033c8
    7c33ec9033c8:	mov    r13,QWORD PTR [r12+0x50]
    7c33ec9033cd:	mov    r14,r13
    7c33ec9033d0:	add    r14,0x80
    7c33ec9033d7:	mov    r15,r14
    7c33ec9033da:	add    r15,0x10
    7c33ec9033de:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec9033e3:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec9033e8:	movdqa xmm0,xmm2
    7c33ec9033ec:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec9033f6:	movdqa xmm0,xmm3
    7c33ec9033fa:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec903404:	mov    r14d,0x0
    7c33ec90340a:	mov    r15d,0x0
    7c33ec903410:	mov    QWORD PTR [r12+0x1b0],r14
    7c33ec903418:	mov    QWORD PTR [r12+0x1b8],r15
    7c33ec903420:	mov    r14,r13
    7c33ec903423:	add    r14,0x40
    7c33ec903427:	mov    r15,r14
    7c33ec90342a:	add    r15,0x10
    7c33ec90342e:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec903433:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec903438:	movdqa xmm0,xmm2
    7c33ec90343c:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c33ec903446:	movdqa xmm0,xmm3
    7c33ec90344a:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec903454:	mov    r14d,0x0
    7c33ec90345a:	mov    QWORD PTR [r12+0x48],r14
    7c33ec90345f:	mov    r14,r13
    7c33ec903462:	add    r14,0x10
    7c33ec903466:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec90346c:	movdqu xmm3,XMMWORD PTR [r14]
    7c33ec903471:	movdqa xmm0,xmm2
    7c33ec903475:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c33ec90347f:	movdqa xmm0,xmm3
    7c33ec903483:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec90348d:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec903495:	add    r13,0xe0
    7c33ec90349c:	mov    r14,r13
    7c33ec90349f:	add    r14,0x10
    7c33ec9034a3:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec9034ad:	movdqa xmm2,xmm0
    7c33ec9034b1:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec9034bb:	movdqa xmm3,xmm0
    7c33ec9034bf:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c33ec9034c5:	mov    r13d,0x0
    7c33ec9034cb:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9034d3:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec9034d8:	mov    r13d,0x0
    7c33ec9034de:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9034e6:	mov    r13,QWORD PTR [r12+0x50]
    7c33ec9034eb:	mov    r14,r13
    7c33ec9034ee:	add    r14,0xc0
    7c33ec9034f5:	mov    r15,r14
    7c33ec9034f8:	add    r15,0x10
    7c33ec9034fc:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec903501:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec903506:	movdqa xmm0,xmm2
    7c33ec90350a:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec903514:	movdqa xmm0,xmm3
    7c33ec903518:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec903522:	mov    r14,r13
    7c33ec903525:	add    r14,0x140
    7c33ec90352c:	mov    r15,r14
    7c33ec90352f:	add    r15,0x10
    7c33ec903533:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec903538:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec90353d:	movdqa xmm0,xmm2
    7c33ec903541:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c33ec90354b:	movdqa xmm0,xmm3
    7c33ec90354f:	movdqu XMMWORD PTR [r12+0x190],xmm0
    7c33ec903559:	add    r13,0x180
    7c33ec903560:	mov    r14,r13
    7c33ec903563:	add    r14,0x10
    7c33ec903567:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec90356d:	movdqu xmm3,XMMWORD PTR [r14]
    7c33ec903572:	movdqa xmm0,xmm2
    7c33ec903576:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    7c33ec903580:	movdqa xmm0,xmm3
    7c33ec903584:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    7c33ec90358e:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec903596:	add    r13,0xc0
    7c33ec90359d:	mov    r14,r13
    7c33ec9035a0:	add    r14,0x10
    7c33ec9035a4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec9035ae:	movdqa xmm2,xmm0
    7c33ec9035b2:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec9035bc:	movdqa xmm3,xmm0
    7c33ec9035c0:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c33ec9035c6:	mov    r13d,0x0
    7c33ec9035cc:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9035d4:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec9035d9:	mov    r13d,0x0
    7c33ec9035df:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9035e7:	mov    r13,QWORD PTR [r12+0x50]
    7c33ec9035ec:	mov    r14,r13
    7c33ec9035ef:	add    r14,0x100
    7c33ec9035f6:	mov    r15,r14
    7c33ec9035f9:	add    r15,0x10
    7c33ec9035fd:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec903602:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec903607:	movdqa xmm0,xmm2
    7c33ec90360b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec903615:	movdqa xmm0,xmm3
    7c33ec903619:	movdqu XMMWORD PTR [r12+0x300],xmm0
    7c33ec903623:	mov    r14,r13
    7c33ec903626:	add    r14,0x1c0
    7c33ec90362d:	mov    r15,r14
    7c33ec903630:	add    r15,0x10
    7c33ec903634:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec903639:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec90363e:	movdqa xmm0,xmm2
    7c33ec903642:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c33ec90364c:	movdqa xmm0,xmm3
    7c33ec903650:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    7c33ec90365a:	add    r13,0x20
    7c33ec90365e:	mov    r14,r13
    7c33ec903661:	add    r14,0x10
    7c33ec903665:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec90366b:	movdqu xmm3,XMMWORD PTR [r14]
    7c33ec903670:	movdqa xmm0,xmm2
    7c33ec903674:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    7c33ec90367e:	movdqa xmm0,xmm3
    7c33ec903682:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
    7c33ec90368c:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec903694:	mov    r14,r13
    7c33ec903697:	add    r14,0x20
    7c33ec90369b:	mov    r15,r14
    7c33ec90369e:	add    r15,0x10
    7c33ec9036a2:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec9036ac:	movdqa xmm2,xmm0
    7c33ec9036b0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec9036ba:	movdqa xmm3,xmm0
    7c33ec9036be:	movdqu XMMWORD PTR [r14],xmm2
    7c33ec9036c3:	mov    r14d,0x0
    7c33ec9036c9:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec9036d1:	movdqu XMMWORD PTR [r15],xmm3
    7c33ec9036d6:	mov    r14d,0x0
    7c33ec9036dc:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec9036e4:	mov    r14,QWORD PTR [r12+0x50]
    7c33ec9036e9:	mov    r15,r14
    7c33ec9036ec:	add    r15,0x60
    7c33ec9036f0:	mov    rbp,r15
    7c33ec9036f3:	add    rbp,0x10
    7c33ec9036f7:	movdqu xmm2,XMMWORD PTR [r15]
    7c33ec9036fc:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c33ec903701:	movdqa xmm0,xmm2
    7c33ec903705:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec90370f:	movdqa xmm0,xmm3
    7c33ec903713:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec90371d:	add    r13,0x60
    7c33ec903721:	mov    r15,r13
    7c33ec903724:	add    r15,0x10
    7c33ec903728:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec903732:	movdqa xmm2,xmm0
    7c33ec903736:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c33ec903740:	movdqa xmm3,xmm0
    7c33ec903744:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c33ec90374a:	mov    r13d,0x0
    7c33ec903750:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec903758:	movdqu XMMWORD PTR [r15],xmm3
    7c33ec90375d:	mov    r13d,0x0
    7c33ec903763:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec90376b:	mov    r13,r14
    7c33ec90376e:	add    r13,0xe0
    7c33ec903775:	mov    r15,r13
    7c33ec903778:	add    r15,0x10
    7c33ec90377c:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec903782:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec903787:	movdqa xmm0,xmm2
    7c33ec90378b:	movdqu XMMWORD PTR [r12+0x200],xmm0
    7c33ec903795:	movdqa xmm0,xmm3
    7c33ec903799:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    7c33ec9037a3:	add    r14,0x120
    7c33ec9037aa:	mov    r13,r14
    7c33ec9037ad:	add    r13,0x10
    7c33ec9037b1:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec9037b6:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c33ec9037bc:	movdqa xmm0,xmm2
    7c33ec9037c0:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7c33ec9037ca:	movdqa xmm0,xmm3
    7c33ec9037ce:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7c33ec9037d8:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9037e0:	add    r13,0xa0
    7c33ec9037e7:	mov    r14,r13
    7c33ec9037ea:	add    r14,0x10
    7c33ec9037ee:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec9037f8:	movdqa xmm2,xmm0
    7c33ec9037fc:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec903806:	movdqa xmm3,xmm0
    7c33ec90380a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c33ec903810:	mov    r13d,0x0
    7c33ec903816:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec90381e:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec903823:	mov    r13d,0x0
    7c33ec903829:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec903831:	mov    r13,QWORD PTR [r12+0x50]
    7c33ec903836:	mov    r14,r13
    7c33ec903839:	add    r14,0xa0
    7c33ec903840:	mov    r15,r14
    7c33ec903843:	add    r15,0x10
    7c33ec903847:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec90384c:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec903851:	movdqa xmm0,xmm2
    7c33ec903855:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec90385f:	movdqa xmm0,xmm3
    7c33ec903863:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec90386d:	mov    r14,r13
    7c33ec903870:	add    r14,0x160
    7c33ec903877:	mov    r15,r14
    7c33ec90387a:	add    r15,0x10
    7c33ec90387e:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec903883:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec903888:	movdqa xmm0,xmm2
    7c33ec90388c:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    7c33ec903896:	movdqa xmm0,xmm3
    7c33ec90389a:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
    7c33ec9038a4:	add    r13,0x1a0
    7c33ec9038ab:	mov    r14,r13
    7c33ec9038ae:	add    r14,0x10
    7c33ec9038b2:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec9038b8:	movdqu xmm3,XMMWORD PTR [r14]
    7c33ec9038bd:	movdqa xmm0,xmm2
    7c33ec9038c1:	movdqu XMMWORD PTR [r12+0x290],xmm0
    7c33ec9038cb:	movdqa xmm0,xmm3
    7c33ec9038cf:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
    7c33ec9038d9:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9038e1:	mov    r14,r13
    7c33ec9038e4:	add    r14,0x80
    7c33ec9038eb:	mov    r15,r14
    7c33ec9038ee:	add    r15,0x10
    7c33ec9038f2:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec9038fc:	movdqa xmm2,xmm0
    7c33ec903900:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec90390a:	movdqa xmm3,xmm0
    7c33ec90390e:	movdqu XMMWORD PTR [r14],xmm2
    7c33ec903913:	mov    r14d,0x0
    7c33ec903919:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec903921:	movdqu XMMWORD PTR [r15],xmm3
    7c33ec903926:	mov    r14d,0x0
    7c33ec90392c:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec903934:	mov    r14,QWORD PTR [r12+0x50]
    7c33ec903939:	add    r14,0x1e0
    7c33ec903940:	mov    r15,r14
    7c33ec903943:	add    r15,0x10
    7c33ec903947:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec90394c:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec903951:	movdqa xmm0,xmm2
    7c33ec903955:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c33ec90395f:	movdqa xmm0,xmm3
    7c33ec903963:	movdqu XMMWORD PTR [r12+0x280],xmm0
    7c33ec90396d:	mov    r14d,0x432000
    7c33ec903973:	add    r14,0x200
    7c33ec90397a:	mov    QWORD PTR [r12+0x50],r14
    7c33ec90397f:	add    r13,0x40
    7c33ec903983:	mov    r14,r13
    7c33ec903986:	add    r14,0x10
    7c33ec90398a:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    7c33ec903994:	movdqa xmm4,xmm0
    7c33ec903998:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec9039a2:	movdqa xmm5,xmm0
    7c33ec9039a6:	movdqu XMMWORD PTR [r13+0x0],xmm4
    7c33ec9039ac:	mov    r13d,0x0
    7c33ec9039b2:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9039ba:	movdqu XMMWORD PTR [r14],xmm5
    7c33ec9039bf:	mov    r13d,0x0
    7c33ec9039c5:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9039cd:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9039d5:	mov    r14,r13
    7c33ec9039d8:	add    r14,0x10
    7c33ec9039dc:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7c33ec9039e2:	mov    r13d,0x0
    7c33ec9039e8:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9039f0:	movdqu XMMWORD PTR [r14],xmm2
    7c33ec9039f5:	mov    r13d,0x0
    7c33ec9039fb:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec903a03:	jmp    0x7c33ec903a08
    7c33ec903a08:	mov    r13d,0x0
    7c33ec903a0e:	mov    QWORD PTR [r12+0x58],r13
    7c33ec903a13:	jmp    0x7c33ec903a18
    7c33ec903a18:	mov    r13,QWORD PTR [r12+0x58]
    7c33ec903a1d:	mov    r14,QWORD PTR [r12+0x40]
    7c33ec903a22:	mov    rcx,r13
    7c33ec903a25:	add    r14,rcx
    7c33ec903a28:	mov    QWORD PTR [r12+0x60],r14
    7c33ec903a2d:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    7c33ec903a37:	movdqa xmm2,xmm0
    7c33ec903a3b:	movdqa xmm1,xmm2
    7c33ec903a3f:	por    xmm2,xmm1
    7c33ec903a43:	movdqa xmm0,xmm2
    7c33ec903a47:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    7c33ec903a51:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7c33ec903a5b:	movdqa xmm2,xmm0
    7c33ec903a5f:	movdqa xmm1,xmm2
    7c33ec903a63:	por    xmm2,xmm1
    7c33ec903a67:	movdqa xmm0,xmm2
    7c33ec903a6b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec903a75:	add    r14,0x30
    7c33ec903a79:	mov    r13,r14
    7c33ec903a7c:	add    r13,0x8
    7c33ec903a80:	mov    r15,QWORD PTR [r14]
    7c33ec903a83:	mov    r14,QWORD PTR [r13+0x0]
    7c33ec903a87:	mov    r13d,0x0
    7c33ec903a8d:	mov    QWORD PTR [r12+0x130],r15
    7c33ec903a95:	mov    QWORD PTR [r12+0x138],r13
    7c33ec903a9d:	mov    r13d,0x0
    7c33ec903aa3:	mov    QWORD PTR [r12+0x280],r14
    7c33ec903aab:	mov    QWORD PTR [r12+0x288],r13
    7c33ec903ab3:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c33ec903abd:	movdqa xmm2,xmm0
    7c33ec903ac1:	movdqa xmm1,xmm2
    7c33ec903ac5:	por    xmm2,xmm1
    7c33ec903ac9:	movdqa xmm0,xmm2
    7c33ec903acd:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    7c33ec903ad7:	mov    r13,QWORD PTR [r12+0x60]
    7c33ec903adc:	mov    r14,r13
    7c33ec903adf:	add    r14,0x20
    7c33ec903ae3:	mov    r15,r14
    7c33ec903ae6:	add    r15,0x8
    7c33ec903aea:	mov    rbp,QWORD PTR [r14]
    7c33ec903aed:	mov    r14,QWORD PTR [r15]
    7c33ec903af0:	mov    r15d,0x0
    7c33ec903af6:	mov    QWORD PTR [r12+0x150],rbp
    7c33ec903afe:	mov    QWORD PTR [r12+0x158],r15
    7c33ec903b06:	mov    r15d,0x0
    7c33ec903b0c:	mov    QWORD PTR [r12+0x140],r14
    7c33ec903b14:	mov    QWORD PTR [r12+0x148],r15
    7c33ec903b1c:	add    r13,0x10
    7c33ec903b20:	mov    r14,r13
    7c33ec903b23:	add    r14,0x8
    7c33ec903b27:	mov    r15,QWORD PTR [r13+0x0]
    7c33ec903b2b:	mov    r13,QWORD PTR [r14]
    7c33ec903b2e:	mov    r14d,0x0
    7c33ec903b34:	mov    QWORD PTR [r12+0x170],r15
    7c33ec903b3c:	mov    QWORD PTR [r12+0x178],r14
    7c33ec903b44:	mov    r14d,0x0
    7c33ec903b4a:	mov    QWORD PTR [r12+0x160],r13
    7c33ec903b52:	mov    QWORD PTR [r12+0x168],r14
    7c33ec903b5a:	mov    r13,QWORD PTR [r12+0x60]
    7c33ec903b5f:	mov    r14d,0x8
    7c33ec903b65:	mov    r15,QWORD PTR [r13+0x0]
    7c33ec903b69:	mov    QWORD PTR [r12+0x180],r15
    7c33ec903b71:	mov    QWORD PTR [r12+0x188],r15
    7c33ec903b79:	mov    rcx,r14
    7c33ec903b7c:	add    r13,rcx
    7c33ec903b7f:	mov    QWORD PTR [r12+0x60],r13
    7c33ec903b84:	mov    r14,QWORD PTR [r13+0x0]
    7c33ec903b88:	mov    r13d,0x0
    7c33ec903b8e:	mov    QWORD PTR [r12+0x230],r14
    7c33ec903b96:	mov    QWORD PTR [r12+0x238],r13
    7c33ec903b9e:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec903ba6:	mov    r14,r13
    7c33ec903ba9:	add    r14,0x50
    7c33ec903bad:	mov    r15,r14
    7c33ec903bb0:	add    r15,0x10
    7c33ec903bb4:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec903bb9:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec903bbe:	movdqa xmm0,xmm2
    7c33ec903bc2:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec903bcc:	movdqa xmm0,xmm3
    7c33ec903bd0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec903bda:	add    r13,0x30
    7c33ec903bde:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec903be4:	movdqa xmm0,xmm2
    7c33ec903be8:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec903bf2:	mov    r13,QWORD PTR [r12+0x58]
    7c33ec903bf7:	mov    r14,QWORD PTR [r12+0x50]
    7c33ec903bfc:	mov    rcx,r13
    7c33ec903bff:	add    r14,rcx
    7c33ec903c02:	mov    QWORD PTR [r12+0x60],r14
    7c33ec903c07:	add    r13,0x40
    7c33ec903c0b:	mov    QWORD PTR [r12+0x58],r13
    7c33ec903c10:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec903c1a:	movdqa xmm3,xmm0
    7c33ec903c1e:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    7c33ec903c28:	movdqa xmm4,xmm0
    7c33ec903c2c:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec903c34:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec903c3f:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec903c47:	movdqa xmm0,xmm3
    7c33ec903c4b:	movdqa xmm1,xmm4
    7c33ec903c4f:	movq   rax,xmm0
    7c33ec903c54:	add    rax,rax
    7c33ec903c57:	je     0x7c33ec903c6d
    7c33ec903c59:	shr    rax,0x35
    7c33ec903c5d:	sub    eax,0x201
    7c33ec903c62:	cmp    eax,0x3fc
    7c33ec903c67:	ja     0x7c33ec907a95
    7c33ec903c6d:	movdqa xmm14,xmm0
    7c33ec903c72:	psrldq xmm14,0x8
    7c33ec903c78:	movq   rax,xmm14
    7c33ec903c7d:	add    rax,rax
    7c33ec903c80:	je     0x7c33ec903c96
    7c33ec903c82:	shr    rax,0x35
    7c33ec903c86:	sub    eax,0x201
    7c33ec903c8b:	cmp    eax,0x3fc
    7c33ec903c90:	ja     0x7c33ec907a95
    7c33ec903c96:	movq   rax,xmm1
    7c33ec903c9b:	add    rax,rax
    7c33ec903c9e:	je     0x7c33ec903cb4
    7c33ec903ca0:	shr    rax,0x35
    7c33ec903ca4:	sub    eax,0x201
    7c33ec903ca9:	cmp    eax,0x3fc
    7c33ec903cae:	ja     0x7c33ec907a95
    7c33ec903cb4:	movdqa xmm14,xmm1
    7c33ec903cb9:	psrldq xmm14,0x8
    7c33ec903cbf:	movq   rax,xmm14
    7c33ec903cc4:	add    rax,rax
    7c33ec903cc7:	je     0x7c33ec903cdd
    7c33ec903cc9:	shr    rax,0x35
    7c33ec903ccd:	sub    eax,0x201
    7c33ec903cd2:	cmp    eax,0x3fc
    7c33ec903cd7:	ja     0x7c33ec907a95
    7c33ec903cdd:	mulpd  xmm0,xmm1
    7c33ec903ce1:	movdqa xmm5,xmm0
    7c33ec903ce5:	movdqa xmm0,xmm5
    7c33ec903ce9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c33ec903cf3:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec903cfd:	movdqa xmm4,xmm0
    7c33ec903d01:	movdqa xmm0,xmm2
    7c33ec903d05:	movdqa xmm1,xmm4
    7c33ec903d09:	pshufd xmm1,xmm1,0x44
    7c33ec903d0e:	movq   rax,xmm0
    7c33ec903d13:	add    rax,rax
    7c33ec903d16:	je     0x7c33ec903d2c
    7c33ec903d18:	shr    rax,0x35
    7c33ec903d1c:	sub    eax,0x201
    7c33ec903d21:	cmp    eax,0x3fc
    7c33ec903d26:	ja     0x7c33ec907ab9
    7c33ec903d2c:	movdqa xmm14,xmm0
    7c33ec903d31:	psrldq xmm14,0x8
    7c33ec903d37:	movq   rax,xmm14
    7c33ec903d3c:	add    rax,rax
    7c33ec903d3f:	je     0x7c33ec903d55
    7c33ec903d41:	shr    rax,0x35
    7c33ec903d45:	sub    eax,0x201
    7c33ec903d4a:	cmp    eax,0x3fc
    7c33ec903d4f:	ja     0x7c33ec907ab9
    7c33ec903d55:	movq   rax,xmm1
    7c33ec903d5a:	add    rax,rax
    7c33ec903d5d:	je     0x7c33ec903d73
    7c33ec903d5f:	shr    rax,0x35
    7c33ec903d63:	sub    eax,0x201
    7c33ec903d68:	cmp    eax,0x3fc
    7c33ec903d6d:	ja     0x7c33ec907ab9
    7c33ec903d73:	movdqa xmm14,xmm1
    7c33ec903d78:	psrldq xmm14,0x8
    7c33ec903d7e:	movq   rax,xmm14
    7c33ec903d83:	add    rax,rax
    7c33ec903d86:	je     0x7c33ec903d9c
    7c33ec903d88:	shr    rax,0x35
    7c33ec903d8c:	sub    eax,0x201
    7c33ec903d91:	cmp    eax,0x3fc
    7c33ec903d96:	ja     0x7c33ec907ab9
    7c33ec903d9c:	mulpd  xmm0,xmm1
    7c33ec903da0:	movdqa xmm5,xmm0
    7c33ec903da4:	movdqa xmm0,xmm5
    7c33ec903da8:	movdqu XMMWORD PTR [r12+0x260],xmm0
    7c33ec903db2:	mov    r13d,0x0
    7c33ec903db8:	mov    r14d,0x0
    7c33ec903dbe:	mov    QWORD PTR [r12+0x110],r13
    7c33ec903dc6:	mov    QWORD PTR [r12+0x118],r14
    7c33ec903dce:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec903dd8:	movdqa xmm2,xmm0
    7c33ec903ddc:	movdqa xmm0,xmm3
    7c33ec903de0:	movdqa xmm1,xmm2
    7c33ec903de4:	movq   rax,xmm0
    7c33ec903de9:	add    rax,rax
    7c33ec903dec:	je     0x7c33ec903e02
    7c33ec903dee:	shr    rax,0x35
    7c33ec903df2:	sub    eax,0x201
    7c33ec903df7:	cmp    eax,0x3fc
    7c33ec903dfc:	ja     0x7c33ec907add
    7c33ec903e02:	movdqa xmm14,xmm0
    7c33ec903e07:	psrldq xmm14,0x8
    7c33ec903e0d:	movq   rax,xmm14
    7c33ec903e12:	add    rax,rax
    7c33ec903e15:	je     0x7c33ec903e2b
    7c33ec903e17:	shr    rax,0x35
    7c33ec903e1b:	sub    eax,0x201
    7c33ec903e20:	cmp    eax,0x3fc
    7c33ec903e25:	ja     0x7c33ec907add
    7c33ec903e2b:	movq   rax,xmm1
    7c33ec903e30:	add    rax,rax
    7c33ec903e33:	je     0x7c33ec903e49
    7c33ec903e35:	shr    rax,0x35
    7c33ec903e39:	sub    eax,0x201
    7c33ec903e3e:	cmp    eax,0x3fc
    7c33ec903e43:	ja     0x7c33ec907add
    7c33ec903e49:	movdqa xmm14,xmm1
    7c33ec903e4e:	psrldq xmm14,0x8
    7c33ec903e54:	movq   rax,xmm14
    7c33ec903e59:	add    rax,rax
    7c33ec903e5c:	je     0x7c33ec903e72
    7c33ec903e5e:	shr    rax,0x35
    7c33ec903e62:	sub    eax,0x201
    7c33ec903e67:	cmp    eax,0x3fc
    7c33ec903e6c:	ja     0x7c33ec907add
    7c33ec903e72:	mulpd  xmm0,xmm1
    7c33ec903e76:	movdqa xmm4,xmm0
    7c33ec903e7a:	movdqa xmm0,xmm4
    7c33ec903e7e:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec903e88:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec903e92:	movdqa xmm2,xmm0
    7c33ec903e96:	movdqa xmm0,xmm3
    7c33ec903e9a:	movdqa xmm1,xmm2
    7c33ec903e9e:	movq   rax,xmm0
    7c33ec903ea3:	add    rax,rax
    7c33ec903ea6:	je     0x7c33ec903ebc
    7c33ec903ea8:	shr    rax,0x35
    7c33ec903eac:	sub    eax,0x201
    7c33ec903eb1:	cmp    eax,0x3fc
    7c33ec903eb6:	ja     0x7c33ec907b01
    7c33ec903ebc:	movdqa xmm14,xmm0
    7c33ec903ec1:	psrldq xmm14,0x8
    7c33ec903ec7:	movq   rax,xmm14
    7c33ec903ecc:	add    rax,rax
    7c33ec903ecf:	je     0x7c33ec903ee5
    7c33ec903ed1:	shr    rax,0x35
    7c33ec903ed5:	sub    eax,0x201
    7c33ec903eda:	cmp    eax,0x3fc
    7c33ec903edf:	ja     0x7c33ec907b01
    7c33ec903ee5:	movq   rax,xmm1
    7c33ec903eea:	add    rax,rax
    7c33ec903eed:	je     0x7c33ec903f03
    7c33ec903eef:	shr    rax,0x35
    7c33ec903ef3:	sub    eax,0x201
    7c33ec903ef8:	cmp    eax,0x3fc
    7c33ec903efd:	ja     0x7c33ec907b01
    7c33ec903f03:	movdqa xmm14,xmm1
    7c33ec903f08:	psrldq xmm14,0x8
    7c33ec903f0e:	movq   rax,xmm14
    7c33ec903f13:	add    rax,rax
    7c33ec903f16:	je     0x7c33ec903f2c
    7c33ec903f18:	shr    rax,0x35
    7c33ec903f1c:	sub    eax,0x201
    7c33ec903f21:	cmp    eax,0x3fc
    7c33ec903f26:	ja     0x7c33ec907b01
    7c33ec903f2c:	mulpd  xmm0,xmm1
    7c33ec903f30:	movdqa xmm4,xmm0
    7c33ec903f34:	movdqa xmm0,xmm4
    7c33ec903f38:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec903f42:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec903f4c:	movdqa xmm2,xmm0
    7c33ec903f50:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    7c33ec903f5a:	movdqa xmm3,xmm0
    7c33ec903f5e:	movdqa xmm0,xmm2
    7c33ec903f62:	movdqa xmm1,xmm3
    7c33ec903f66:	movq   rax,xmm0
    7c33ec903f6b:	add    rax,rax
    7c33ec903f6e:	je     0x7c33ec903f84
    7c33ec903f70:	shr    rax,0x35
    7c33ec903f74:	sub    eax,0x201
    7c33ec903f79:	cmp    eax,0x3fc
    7c33ec903f7e:	ja     0x7c33ec907b25
    7c33ec903f84:	movdqa xmm14,xmm0
    7c33ec903f89:	psrldq xmm14,0x8
    7c33ec903f8f:	movq   rax,xmm14
    7c33ec903f94:	add    rax,rax
    7c33ec903f97:	je     0x7c33ec903fad
    7c33ec903f99:	shr    rax,0x35
    7c33ec903f9d:	sub    eax,0x201
    7c33ec903fa2:	cmp    eax,0x3fc
    7c33ec903fa7:	ja     0x7c33ec907b25
    7c33ec903fad:	movq   rax,xmm1
    7c33ec903fb2:	add    rax,rax
    7c33ec903fb5:	je     0x7c33ec903fcb
    7c33ec903fb7:	shr    rax,0x35
    7c33ec903fbb:	sub    eax,0x201
    7c33ec903fc0:	cmp    eax,0x3fc
    7c33ec903fc5:	ja     0x7c33ec907b25
    7c33ec903fcb:	movdqa xmm14,xmm1
    7c33ec903fd0:	psrldq xmm14,0x8
    7c33ec903fd6:	movq   rax,xmm14
    7c33ec903fdb:	add    rax,rax
    7c33ec903fde:	je     0x7c33ec903ff4
    7c33ec903fe0:	shr    rax,0x35
    7c33ec903fe4:	sub    eax,0x201
    7c33ec903fe9:	cmp    eax,0x3fc
    7c33ec903fee:	ja     0x7c33ec907b25
    7c33ec903ff4:	mulpd  xmm0,xmm1
    7c33ec903ff8:	movdqa xmm4,xmm0
    7c33ec903ffc:	movdqa xmm0,xmm4
    7c33ec904000:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec90400a:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    7c33ec904014:	movdqa xmm2,xmm0
    7c33ec904018:	movdqa xmm1,xmm2
    7c33ec90401c:	por    xmm2,xmm1
    7c33ec904020:	movdqa xmm0,xmm2
    7c33ec904024:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    7c33ec90402e:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c33ec904038:	movdqa xmm2,xmm0
    7c33ec90403c:	movdqa xmm3,xmm2
    7c33ec904040:	movdqa xmm1,xmm2
    7c33ec904044:	por    xmm3,xmm1
    7c33ec904048:	movdqa xmm0,xmm3
    7c33ec90404c:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    7c33ec904056:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec904060:	movdqa xmm3,xmm0
    7c33ec904064:	movdqa xmm0,xmm2
    7c33ec904068:	movdqa xmm1,xmm3
    7c33ec90406c:	pshufd xmm1,xmm1,0x44
    7c33ec904071:	movq   rax,xmm0
    7c33ec904076:	add    rax,rax
    7c33ec904079:	je     0x7c33ec90408f
    7c33ec90407b:	shr    rax,0x35
    7c33ec90407f:	sub    eax,0x201
    7c33ec904084:	cmp    eax,0x3fc
    7c33ec904089:	ja     0x7c33ec907b49
    7c33ec90408f:	movdqa xmm14,xmm0
    7c33ec904094:	psrldq xmm14,0x8
    7c33ec90409a:	movq   rax,xmm14
    7c33ec90409f:	add    rax,rax
    7c33ec9040a2:	je     0x7c33ec9040b8
    7c33ec9040a4:	shr    rax,0x35
    7c33ec9040a8:	sub    eax,0x201
    7c33ec9040ad:	cmp    eax,0x3fc
    7c33ec9040b2:	ja     0x7c33ec907b49
    7c33ec9040b8:	movq   rax,xmm1
    7c33ec9040bd:	add    rax,rax
    7c33ec9040c0:	je     0x7c33ec9040d6
    7c33ec9040c2:	shr    rax,0x35
    7c33ec9040c6:	sub    eax,0x201
    7c33ec9040cb:	cmp    eax,0x3fc
    7c33ec9040d0:	ja     0x7c33ec907b49
    7c33ec9040d6:	movdqa xmm14,xmm1
    7c33ec9040db:	psrldq xmm14,0x8
    7c33ec9040e1:	movq   rax,xmm14
    7c33ec9040e6:	add    rax,rax
    7c33ec9040e9:	je     0x7c33ec9040ff
    7c33ec9040eb:	shr    rax,0x35
    7c33ec9040ef:	sub    eax,0x201
    7c33ec9040f4:	cmp    eax,0x3fc
    7c33ec9040f9:	ja     0x7c33ec907b49
    7c33ec9040ff:	mulpd  xmm0,xmm1
    7c33ec904103:	movdqa xmm4,xmm0
    7c33ec904107:	movdqa xmm0,xmm4
    7c33ec90410b:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c33ec904115:	mov    r13,QWORD PTR [r12+0x58]
    7c33ec90411a:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec904122:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec90412a:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec904132:	shr    r11d,1
    7c33ec904135:	and    r11d,0x10
    7c33ec904139:	or     DWORD PTR [r12+0x314],r11d
    7c33ec904141:	sub    r13,0x200
    7c33ec904148:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c33ec904152:	movdqa xmm2,xmm0
    7c33ec904156:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec904160:	movdqa xmm3,xmm0
    7c33ec904164:	pushf
    7c33ec904165:	pop    r11
    7c33ec904167:	mov    QWORD PTR [rsp],r11
    7c33ec90416b:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec904173:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec90417e:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec904186:	movdqa xmm0,xmm2
    7c33ec90418a:	movdqa xmm1,xmm3
    7c33ec90418e:	movq   rax,xmm0
    7c33ec904193:	add    rax,rax
    7c33ec904196:	je     0x7c33ec9041ac
    7c33ec904198:	shr    rax,0x35
    7c33ec90419c:	sub    eax,0x201
    7c33ec9041a1:	cmp    eax,0x3fc
    7c33ec9041a6:	ja     0x7c33ec907b6d
    7c33ec9041ac:	movdqa xmm14,xmm0
    7c33ec9041b1:	psrldq xmm14,0x8
    7c33ec9041b7:	movq   rax,xmm14
    7c33ec9041bc:	add    rax,rax
    7c33ec9041bf:	je     0x7c33ec9041d5
    7c33ec9041c1:	shr    rax,0x35
    7c33ec9041c5:	sub    eax,0x201
    7c33ec9041ca:	cmp    eax,0x3fc
    7c33ec9041cf:	ja     0x7c33ec907b6d
    7c33ec9041d5:	movq   rax,xmm1
    7c33ec9041da:	add    rax,rax
    7c33ec9041dd:	je     0x7c33ec9041f3
    7c33ec9041df:	shr    rax,0x35
    7c33ec9041e3:	sub    eax,0x201
    7c33ec9041e8:	cmp    eax,0x3fc
    7c33ec9041ed:	ja     0x7c33ec907b6d
    7c33ec9041f3:	movdqa xmm14,xmm1
    7c33ec9041f8:	psrldq xmm14,0x8
    7c33ec9041fe:	movq   rax,xmm14
    7c33ec904203:	add    rax,rax
    7c33ec904206:	je     0x7c33ec90421c
    7c33ec904208:	shr    rax,0x35
    7c33ec90420c:	sub    eax,0x201
    7c33ec904211:	cmp    eax,0x3fc
    7c33ec904216:	ja     0x7c33ec907b6d
    7c33ec90421c:	addpd  xmm0,xmm1
    7c33ec904220:	movdqa xmm4,xmm0
    7c33ec904224:	movdqa xmm0,xmm4
    7c33ec904228:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c33ec904232:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec90423c:	movdqa xmm2,xmm0
    7c33ec904240:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    7c33ec90424a:	movdqa xmm3,xmm0
    7c33ec90424e:	movdqa xmm0,xmm2
    7c33ec904252:	movdqa xmm1,xmm3
    7c33ec904256:	movq   rax,xmm0
    7c33ec90425b:	add    rax,rax
    7c33ec90425e:	je     0x7c33ec904274
    7c33ec904260:	shr    rax,0x35
    7c33ec904264:	sub    eax,0x201
    7c33ec904269:	cmp    eax,0x3fc
    7c33ec90426e:	ja     0x7c33ec907b91
    7c33ec904274:	movdqa xmm14,xmm0
    7c33ec904279:	psrldq xmm14,0x8
    7c33ec90427f:	movq   rax,xmm14
    7c33ec904284:	add    rax,rax
    7c33ec904287:	je     0x7c33ec90429d
    7c33ec904289:	shr    rax,0x35
    7c33ec90428d:	sub    eax,0x201
    7c33ec904292:	cmp    eax,0x3fc
    7c33ec904297:	ja     0x7c33ec907b91
    7c33ec90429d:	movq   rax,xmm1
    7c33ec9042a2:	add    rax,rax
    7c33ec9042a5:	je     0x7c33ec9042bb
    7c33ec9042a7:	shr    rax,0x35
    7c33ec9042ab:	sub    eax,0x201
    7c33ec9042b0:	cmp    eax,0x3fc
    7c33ec9042b5:	ja     0x7c33ec907b91
    7c33ec9042bb:	movdqa xmm14,xmm1
    7c33ec9042c0:	psrldq xmm14,0x8
    7c33ec9042c6:	movq   rax,xmm14
    7c33ec9042cb:	add    rax,rax
    7c33ec9042ce:	je     0x7c33ec9042e4
    7c33ec9042d0:	shr    rax,0x35
    7c33ec9042d4:	sub    eax,0x201
    7c33ec9042d9:	cmp    eax,0x3fc
    7c33ec9042de:	ja     0x7c33ec907b91
    7c33ec9042e4:	addpd  xmm0,xmm1
    7c33ec9042e8:	movdqa xmm4,xmm0
    7c33ec9042ec:	movdqa xmm0,xmm4
    7c33ec9042f0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec9042fa:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec904304:	movdqa xmm2,xmm0
    7c33ec904308:	movdqa xmm0,xmm2
    7c33ec90430c:	movdqa xmm1,xmm3
    7c33ec904310:	movq   rax,xmm0
    7c33ec904315:	add    rax,rax
    7c33ec904318:	je     0x7c33ec90432e
    7c33ec90431a:	shr    rax,0x35
    7c33ec90431e:	sub    eax,0x201
    7c33ec904323:	cmp    eax,0x3fc
    7c33ec904328:	ja     0x7c33ec907bb5
    7c33ec90432e:	movdqa xmm14,xmm0
    7c33ec904333:	psrldq xmm14,0x8
    7c33ec904339:	movq   rax,xmm14
    7c33ec90433e:	add    rax,rax
    7c33ec904341:	je     0x7c33ec904357
    7c33ec904343:	shr    rax,0x35
    7c33ec904347:	sub    eax,0x201
    7c33ec90434c:	cmp    eax,0x3fc
    7c33ec904351:	ja     0x7c33ec907bb5
    7c33ec904357:	movq   rax,xmm1
    7c33ec90435c:	add    rax,rax
    7c33ec90435f:	je     0x7c33ec904375
    7c33ec904361:	shr    rax,0x35
    7c33ec904365:	sub    eax,0x201
    7c33ec90436a:	cmp    eax,0x3fc
    7c33ec90436f:	ja     0x7c33ec907bb5
    7c33ec904375:	movdqa xmm14,xmm1
    7c33ec90437a:	psrldq xmm14,0x8
    7c33ec904380:	movq   rax,xmm14
    7c33ec904385:	add    rax,rax
    7c33ec904388:	je     0x7c33ec90439e
    7c33ec90438a:	shr    rax,0x35
    7c33ec90438e:	sub    eax,0x201
    7c33ec904393:	cmp    eax,0x3fc
    7c33ec904398:	ja     0x7c33ec907bb5
    7c33ec90439e:	addpd  xmm0,xmm1
    7c33ec9043a2:	movdqa xmm4,xmm0
    7c33ec9043a6:	movdqa xmm0,xmm4
    7c33ec9043aa:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec9043b4:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7c33ec9043be:	movdqa xmm2,xmm0
    7c33ec9043c2:	movdqa xmm1,xmm2
    7c33ec9043c6:	por    xmm2,xmm1
    7c33ec9043ca:	movdqa xmm0,xmm2
    7c33ec9043ce:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    7c33ec9043d8:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7c33ec9043e2:	movdqa xmm2,xmm0
    7c33ec9043e6:	movdqa xmm1,xmm2
    7c33ec9043ea:	por    xmm2,xmm1
    7c33ec9043ee:	movdqa xmm0,xmm2
    7c33ec9043f2:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7c33ec9043fc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    7c33ec904406:	movdqa xmm2,xmm0
    7c33ec90440a:	movdqa xmm1,xmm2
    7c33ec90440e:	por    xmm2,xmm1
    7c33ec904412:	movdqa xmm0,xmm2
    7c33ec904416:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7c33ec904420:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    7c33ec90442a:	movdqa xmm2,xmm0
    7c33ec90442e:	movdqa xmm1,xmm2
    7c33ec904432:	por    xmm2,xmm1
    7c33ec904436:	movdqa xmm0,xmm2
    7c33ec90443a:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    7c33ec904444:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7c33ec90444e:	movdqa xmm2,xmm0
    7c33ec904452:	movdqa xmm1,xmm2
    7c33ec904456:	por    xmm2,xmm1
    7c33ec90445a:	movdqa xmm0,xmm2
    7c33ec90445e:	movdqu XMMWORD PTR [r12+0x200],xmm0
    7c33ec904468:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7c33ec904472:	movdqa xmm2,xmm0
    7c33ec904476:	movdqa xmm1,xmm2
    7c33ec90447a:	por    xmm2,xmm1
    7c33ec90447e:	movdqa xmm0,xmm2
    7c33ec904482:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    7c33ec90448c:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7c33ec904496:	movdqa xmm2,xmm0
    7c33ec90449a:	movdqa xmm1,xmm2
    7c33ec90449e:	por    xmm2,xmm1
    7c33ec9044a2:	movdqa xmm0,xmm2
    7c33ec9044a6:	movdqu XMMWORD PTR [r12+0x190],xmm0
    7c33ec9044b0:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9044b8:	mov    r14,r13
    7c33ec9044bb:	add    r14,0xa0
    7c33ec9044c2:	mov    r15,r14
    7c33ec9044c5:	add    r15,0x10
    7c33ec9044c9:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec9044d1:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec9044d9:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec9044e1:	shr    r11d,1
    7c33ec9044e4:	and    r11d,0x10
    7c33ec9044e8:	or     DWORD PTR [r12+0x314],r11d
    7c33ec9044f0:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec9044f5:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec9044fa:	movdqa xmm0,xmm2
    7c33ec9044fe:	movdqu XMMWORD PTR [r12+0x300],xmm0
    7c33ec904508:	movdqa xmm0,xmm3
    7c33ec90450c:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c33ec904516:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec904520:	movdqa xmm2,xmm0
    7c33ec904524:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec90452e:	movdqa xmm4,xmm0
    7c33ec904532:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec90453a:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec904545:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec90454d:	movdqa xmm0,xmm2
    7c33ec904551:	movdqa xmm1,xmm4
    7c33ec904555:	movq   rax,xmm0
    7c33ec90455a:	add    rax,rax
    7c33ec90455d:	je     0x7c33ec904573
    7c33ec90455f:	shr    rax,0x35
    7c33ec904563:	sub    eax,0x201
    7c33ec904568:	cmp    eax,0x3fc
    7c33ec90456d:	ja     0x7c33ec907bd9
    7c33ec904573:	movdqa xmm14,xmm0
    7c33ec904578:	psrldq xmm14,0x8
    7c33ec90457e:	movq   rax,xmm14
    7c33ec904583:	add    rax,rax
    7c33ec904586:	je     0x7c33ec90459c
    7c33ec904588:	shr    rax,0x35
    7c33ec90458c:	sub    eax,0x201
    7c33ec904591:	cmp    eax,0x3fc
    7c33ec904596:	ja     0x7c33ec907bd9
    7c33ec90459c:	movq   rax,xmm1
    7c33ec9045a1:	add    rax,rax
    7c33ec9045a4:	je     0x7c33ec9045ba
    7c33ec9045a6:	shr    rax,0x35
    7c33ec9045aa:	sub    eax,0x201
    7c33ec9045af:	cmp    eax,0x3fc
    7c33ec9045b4:	ja     0x7c33ec907bd9
    7c33ec9045ba:	movdqa xmm14,xmm1
    7c33ec9045bf:	psrldq xmm14,0x8
    7c33ec9045c5:	movq   rax,xmm14
    7c33ec9045ca:	add    rax,rax
    7c33ec9045cd:	je     0x7c33ec9045e3
    7c33ec9045cf:	shr    rax,0x35
    7c33ec9045d3:	sub    eax,0x201
    7c33ec9045d8:	cmp    eax,0x3fc
    7c33ec9045dd:	ja     0x7c33ec907bd9
    7c33ec9045e3:	addpd  xmm0,xmm1
    7c33ec9045e7:	movdqa xmm5,xmm0
    7c33ec9045eb:	movdqa xmm0,xmm5
    7c33ec9045ef:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec9045f9:	add    r13,0xf0
    7c33ec904600:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec904608:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec904610:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec904618:	shr    r11d,1
    7c33ec90461b:	and    r11d,0x10
    7c33ec90461f:	or     DWORD PTR [r12+0x314],r11d
    7c33ec904627:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec90462d:	movdqa xmm0,xmm2
    7c33ec904631:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec90463b:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec904645:	movdqa xmm4,xmm0
    7c33ec904649:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c33ec904653:	movdqa xmm5,xmm0
    7c33ec904657:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec90465f:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec90466a:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec904672:	movdqa xmm0,xmm4
    7c33ec904676:	movdqa xmm1,xmm5
    7c33ec90467a:	movq   rax,xmm0
    7c33ec90467f:	add    rax,rax
    7c33ec904682:	je     0x7c33ec904698
    7c33ec904684:	shr    rax,0x35
    7c33ec904688:	sub    eax,0x201
    7c33ec90468d:	cmp    eax,0x3fc
    7c33ec904692:	ja     0x7c33ec907bfd
    7c33ec904698:	movdqa xmm14,xmm0
    7c33ec90469d:	psrldq xmm14,0x8
    7c33ec9046a3:	movq   rax,xmm14
    7c33ec9046a8:	add    rax,rax
    7c33ec9046ab:	je     0x7c33ec9046c1
    7c33ec9046ad:	shr    rax,0x35
    7c33ec9046b1:	sub    eax,0x201
    7c33ec9046b6:	cmp    eax,0x3fc
    7c33ec9046bb:	ja     0x7c33ec907bfd
    7c33ec9046c1:	movq   rax,xmm1
    7c33ec9046c6:	add    rax,rax
    7c33ec9046c9:	je     0x7c33ec9046df
    7c33ec9046cb:	shr    rax,0x35
    7c33ec9046cf:	sub    eax,0x201
    7c33ec9046d4:	cmp    eax,0x3fc
    7c33ec9046d9:	ja     0x7c33ec907bfd
    7c33ec9046df:	movdqa xmm14,xmm1
    7c33ec9046e4:	psrldq xmm14,0x8
    7c33ec9046ea:	movq   rax,xmm14
    7c33ec9046ef:	add    rax,rax
    7c33ec9046f2:	je     0x7c33ec904708
    7c33ec9046f4:	shr    rax,0x35
    7c33ec9046f8:	sub    eax,0x201
    7c33ec9046fd:	cmp    eax,0x3fc
    7c33ec904702:	ja     0x7c33ec907bfd
    7c33ec904708:	addpd  xmm0,xmm1
    7c33ec90470c:	movdqa xmm6,xmm0
    7c33ec904710:	movdqa xmm0,xmm6
    7c33ec904714:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec90471e:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec904728:	movdqa xmm4,xmm0
    7c33ec90472c:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7c33ec904736:	movdqa xmm5,xmm0
    7c33ec90473a:	movdqa xmm0,xmm4
    7c33ec90473e:	movdqa xmm1,xmm5
    7c33ec904742:	movq   rax,xmm0
    7c33ec904747:	add    rax,rax
    7c33ec90474a:	je     0x7c33ec904760
    7c33ec90474c:	shr    rax,0x35
    7c33ec904750:	sub    eax,0x201
    7c33ec904755:	cmp    eax,0x3fc
    7c33ec90475a:	ja     0x7c33ec907c21
    7c33ec904760:	movdqa xmm14,xmm0
    7c33ec904765:	psrldq xmm14,0x8
    7c33ec90476b:	movq   rax,xmm14
    7c33ec904770:	add    rax,rax
    7c33ec904773:	je     0x7c33ec904789
    7c33ec904775:	shr    rax,0x35
    7c33ec904779:	sub    eax,0x201
    7c33ec90477e:	cmp    eax,0x3fc
    7c33ec904783:	ja     0x7c33ec907c21
    7c33ec904789:	movq   rax,xmm1
    7c33ec90478e:	add    rax,rax
    7c33ec904791:	je     0x7c33ec9047a7
    7c33ec904793:	shr    rax,0x35
    7c33ec904797:	sub    eax,0x201
    7c33ec90479c:	cmp    eax,0x3fc
    7c33ec9047a1:	ja     0x7c33ec907c21
    7c33ec9047a7:	movdqa xmm14,xmm1
    7c33ec9047ac:	psrldq xmm14,0x8
    7c33ec9047b2:	movq   rax,xmm14
    7c33ec9047b7:	add    rax,rax
    7c33ec9047ba:	je     0x7c33ec9047d0
    7c33ec9047bc:	shr    rax,0x35
    7c33ec9047c0:	sub    eax,0x201
    7c33ec9047c5:	cmp    eax,0x3fc
    7c33ec9047ca:	ja     0x7c33ec907c21
    7c33ec9047d0:	addpd  xmm0,xmm1
    7c33ec9047d4:	movdqa xmm6,xmm0
    7c33ec9047d8:	movdqa xmm0,xmm6
    7c33ec9047dc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec9047e6:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec9047f0:	movdqa xmm4,xmm0
    7c33ec9047f4:	movdqa xmm0,xmm3
    7c33ec9047f8:	movdqa xmm1,xmm4
    7c33ec9047fc:	pshufd xmm1,xmm1,0x44
    7c33ec904801:	movq   rax,xmm0
    7c33ec904806:	add    rax,rax
    7c33ec904809:	je     0x7c33ec90481f
    7c33ec90480b:	shr    rax,0x35
    7c33ec90480f:	sub    eax,0x201
    7c33ec904814:	cmp    eax,0x3fc
    7c33ec904819:	ja     0x7c33ec907c45
    7c33ec90481f:	movdqa xmm14,xmm0
    7c33ec904824:	psrldq xmm14,0x8
    7c33ec90482a:	movq   rax,xmm14
    7c33ec90482f:	add    rax,rax
    7c33ec904832:	je     0x7c33ec904848
    7c33ec904834:	shr    rax,0x35
    7c33ec904838:	sub    eax,0x201
    7c33ec90483d:	cmp    eax,0x3fc
    7c33ec904842:	ja     0x7c33ec907c45
    7c33ec904848:	movq   rax,xmm1
    7c33ec90484d:	add    rax,rax
    7c33ec904850:	je     0x7c33ec904866
    7c33ec904852:	shr    rax,0x35
    7c33ec904856:	sub    eax,0x201
    7c33ec90485b:	cmp    eax,0x3fc
    7c33ec904860:	ja     0x7c33ec907c45
    7c33ec904866:	movdqa xmm14,xmm1
    7c33ec90486b:	psrldq xmm14,0x8
    7c33ec904871:	movq   rax,xmm14
    7c33ec904876:	add    rax,rax
    7c33ec904879:	je     0x7c33ec90488f
    7c33ec90487b:	shr    rax,0x35
    7c33ec90487f:	sub    eax,0x201
    7c33ec904884:	cmp    eax,0x3fc
    7c33ec904889:	ja     0x7c33ec907c45
    7c33ec90488f:	mulpd  xmm0,xmm1
    7c33ec904893:	movdqa xmm5,xmm0
    7c33ec904897:	movdqa xmm0,xmm5
    7c33ec90489b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c33ec9048a5:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec9048af:	movdqa xmm3,xmm0
    7c33ec9048b3:	movdqa xmm0,xmm2
    7c33ec9048b7:	movdqa xmm1,xmm3
    7c33ec9048bb:	pshufd xmm1,xmm1,0x44
    7c33ec9048c0:	movq   rax,xmm0
    7c33ec9048c5:	add    rax,rax
    7c33ec9048c8:	je     0x7c33ec9048de
    7c33ec9048ca:	shr    rax,0x35
    7c33ec9048ce:	sub    eax,0x201
    7c33ec9048d3:	cmp    eax,0x3fc
    7c33ec9048d8:	ja     0x7c33ec907c69
    7c33ec9048de:	movdqa xmm14,xmm0
    7c33ec9048e3:	psrldq xmm14,0x8
    7c33ec9048e9:	movq   rax,xmm14
    7c33ec9048ee:	add    rax,rax
    7c33ec9048f1:	je     0x7c33ec904907
    7c33ec9048f3:	shr    rax,0x35
    7c33ec9048f7:	sub    eax,0x201
    7c33ec9048fc:	cmp    eax,0x3fc
    7c33ec904901:	ja     0x7c33ec907c69
    7c33ec904907:	movq   rax,xmm1
    7c33ec90490c:	add    rax,rax
    7c33ec90490f:	je     0x7c33ec904925
    7c33ec904911:	shr    rax,0x35
    7c33ec904915:	sub    eax,0x201
    7c33ec90491a:	cmp    eax,0x3fc
    7c33ec90491f:	ja     0x7c33ec907c69
    7c33ec904925:	movdqa xmm14,xmm1
    7c33ec90492a:	psrldq xmm14,0x8
    7c33ec904930:	movq   rax,xmm14
    7c33ec904935:	add    rax,rax
    7c33ec904938:	je     0x7c33ec90494e
    7c33ec90493a:	shr    rax,0x35
    7c33ec90493e:	sub    eax,0x201
    7c33ec904943:	cmp    eax,0x3fc
    7c33ec904948:	ja     0x7c33ec907c69
    7c33ec90494e:	mulpd  xmm0,xmm1
    7c33ec904952:	movdqa xmm5,xmm0
    7c33ec904956:	movdqa xmm0,xmm5
    7c33ec90495a:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c33ec904964:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec90496c:	mov    r14,r13
    7c33ec90496f:	add    r14,0xe0
    7c33ec904976:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec90497e:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec904986:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec90498e:	shr    r11d,1
    7c33ec904991:	and    r11d,0x10
    7c33ec904995:	or     DWORD PTR [r12+0x314],r11d
    7c33ec90499d:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec9049a2:	movdqa xmm0,xmm2
    7c33ec9049a6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec9049b0:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7c33ec9049ba:	movdqa xmm2,xmm0
    7c33ec9049be:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec9049c6:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec9049d1:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec9049d9:	movdqa xmm0,xmm2
    7c33ec9049dd:	movdqa xmm1,xmm4
    7c33ec9049e1:	pshufd xmm1,xmm1,0x44
    7c33ec9049e6:	movq   rax,xmm0
    7c33ec9049eb:	add    rax,rax
    7c33ec9049ee:	je     0x7c33ec904a04
    7c33ec9049f0:	shr    rax,0x35
    7c33ec9049f4:	sub    eax,0x201
    7c33ec9049f9:	cmp    eax,0x3fc
    7c33ec9049fe:	ja     0x7c33ec907c8d
    7c33ec904a04:	movdqa xmm14,xmm0
    7c33ec904a09:	psrldq xmm14,0x8
    7c33ec904a0f:	movq   rax,xmm14
    7c33ec904a14:	add    rax,rax
    7c33ec904a17:	je     0x7c33ec904a2d
    7c33ec904a19:	shr    rax,0x35
    7c33ec904a1d:	sub    eax,0x201
    7c33ec904a22:	cmp    eax,0x3fc
    7c33ec904a27:	ja     0x7c33ec907c8d
    7c33ec904a2d:	movq   rax,xmm1
    7c33ec904a32:	add    rax,rax
    7c33ec904a35:	je     0x7c33ec904a4b
    7c33ec904a37:	shr    rax,0x35
    7c33ec904a3b:	sub    eax,0x201
    7c33ec904a40:	cmp    eax,0x3fc
    7c33ec904a45:	ja     0x7c33ec907c8d
    7c33ec904a4b:	movdqa xmm14,xmm1
    7c33ec904a50:	psrldq xmm14,0x8
    7c33ec904a56:	movq   rax,xmm14
    7c33ec904a5b:	add    rax,rax
    7c33ec904a5e:	je     0x7c33ec904a74
    7c33ec904a60:	shr    rax,0x35
    7c33ec904a64:	sub    eax,0x201
    7c33ec904a69:	cmp    eax,0x3fc
    7c33ec904a6e:	ja     0x7c33ec907c8d
    7c33ec904a74:	mulpd  xmm0,xmm1
    7c33ec904a78:	movdqa xmm5,xmm0
    7c33ec904a7c:	movdqa xmm0,xmm5
    7c33ec904a80:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c33ec904a8a:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7c33ec904a94:	movdqa xmm2,xmm0
    7c33ec904a98:	movdqa xmm1,xmm2
    7c33ec904a9c:	por    xmm2,xmm1
    7c33ec904aa0:	movdqa xmm0,xmm2
    7c33ec904aa4:	movdqu XMMWORD PTR [r12+0x300],xmm0
    7c33ec904aae:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7c33ec904ab8:	movdqa xmm2,xmm0
    7c33ec904abc:	movdqa xmm1,xmm2
    7c33ec904ac0:	por    xmm2,xmm1
    7c33ec904ac4:	movdqa xmm0,xmm2
    7c33ec904ac8:	movdqu XMMWORD PTR [r12+0x190],xmm0
    7c33ec904ad2:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec904adc:	movdqa xmm2,xmm0
    7c33ec904ae0:	movdqa xmm0,xmm2
    7c33ec904ae4:	movdqa xmm1,xmm3
    7c33ec904ae8:	pshufd xmm1,xmm1,0x44
    7c33ec904aed:	movq   rax,xmm0
    7c33ec904af2:	add    rax,rax
    7c33ec904af5:	je     0x7c33ec904b0b
    7c33ec904af7:	shr    rax,0x35
    7c33ec904afb:	sub    eax,0x201
    7c33ec904b00:	cmp    eax,0x3fc
    7c33ec904b05:	ja     0x7c33ec907cb1
    7c33ec904b0b:	movdqa xmm14,xmm0
    7c33ec904b10:	psrldq xmm14,0x8
    7c33ec904b16:	movq   rax,xmm14
    7c33ec904b1b:	add    rax,rax
    7c33ec904b1e:	je     0x7c33ec904b34
    7c33ec904b20:	shr    rax,0x35
    7c33ec904b24:	sub    eax,0x201
    7c33ec904b29:	cmp    eax,0x3fc
    7c33ec904b2e:	ja     0x7c33ec907cb1
    7c33ec904b34:	movq   rax,xmm1
    7c33ec904b39:	add    rax,rax
    7c33ec904b3c:	je     0x7c33ec904b52
    7c33ec904b3e:	shr    rax,0x35
    7c33ec904b42:	sub    eax,0x201
    7c33ec904b47:	cmp    eax,0x3fc
    7c33ec904b4c:	ja     0x7c33ec907cb1
    7c33ec904b52:	movdqa xmm14,xmm1
    7c33ec904b57:	psrldq xmm14,0x8
    7c33ec904b5d:	movq   rax,xmm14
    7c33ec904b62:	add    rax,rax
    7c33ec904b65:	je     0x7c33ec904b7b
    7c33ec904b67:	shr    rax,0x35
    7c33ec904b6b:	sub    eax,0x201
    7c33ec904b70:	cmp    eax,0x3fc
    7c33ec904b75:	ja     0x7c33ec907cb1
    7c33ec904b7b:	mulpd  xmm0,xmm1
    7c33ec904b7f:	movdqa xmm4,xmm0
    7c33ec904b83:	movdqa xmm0,xmm4
    7c33ec904b87:	movdqu XMMWORD PTR [r12+0x260],xmm0
    7c33ec904b91:	add    r13,0x90
    7c33ec904b98:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec904ba0:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec904ba8:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec904bb0:	shr    r11d,1
    7c33ec904bb3:	and    r11d,0x10
    7c33ec904bb7:	or     DWORD PTR [r12+0x314],r11d
    7c33ec904bbf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec904bc5:	movdqa xmm0,xmm2
    7c33ec904bc9:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec904bd3:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    7c33ec904bdd:	movdqa xmm3,xmm0
    7c33ec904be1:	movdqa xmm1,xmm3
    7c33ec904be5:	por    xmm3,xmm1
    7c33ec904be9:	movdqa xmm0,xmm3
    7c33ec904bed:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    7c33ec904bf7:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    7c33ec904c01:	movdqa xmm3,xmm0
    7c33ec904c05:	movdqa xmm1,xmm3
    7c33ec904c09:	por    xmm3,xmm1
    7c33ec904c0d:	movdqa xmm0,xmm3
    7c33ec904c11:	movdqu XMMWORD PTR [r12+0x200],xmm0
    7c33ec904c1b:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7c33ec904c25:	movdqa xmm3,xmm0
    7c33ec904c29:	movdqa xmm1,xmm3
    7c33ec904c2d:	por    xmm3,xmm1
    7c33ec904c31:	movdqa xmm0,xmm3
    7c33ec904c35:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    7c33ec904c3f:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7c33ec904c49:	movdqa xmm3,xmm0
    7c33ec904c4d:	movdqa xmm1,xmm3
    7c33ec904c51:	por    xmm3,xmm1
    7c33ec904c55:	movdqa xmm0,xmm3
    7c33ec904c59:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7c33ec904c63:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c33ec904c6d:	movdqa xmm3,xmm0
    7c33ec904c71:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c33ec904c7b:	movdqa xmm4,xmm0
    7c33ec904c7f:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec904c87:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec904c92:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec904c9a:	movdqa xmm0,xmm3
    7c33ec904c9e:	movdqa xmm1,xmm4
    7c33ec904ca2:	movq   rax,xmm0
    7c33ec904ca7:	add    rax,rax
    7c33ec904caa:	je     0x7c33ec904cc0
    7c33ec904cac:	shr    rax,0x35
    7c33ec904cb0:	sub    eax,0x201
    7c33ec904cb5:	cmp    eax,0x3fc
    7c33ec904cba:	ja     0x7c33ec907cd5
    7c33ec904cc0:	movdqa xmm14,xmm0
    7c33ec904cc5:	psrldq xmm14,0x8
    7c33ec904ccb:	movq   rax,xmm14
    7c33ec904cd0:	add    rax,rax
    7c33ec904cd3:	je     0x7c33ec904ce9
    7c33ec904cd5:	shr    rax,0x35
    7c33ec904cd9:	sub    eax,0x201
    7c33ec904cde:	cmp    eax,0x3fc
    7c33ec904ce3:	ja     0x7c33ec907cd5
    7c33ec904ce9:	movq   rax,xmm1
    7c33ec904cee:	add    rax,rax
    7c33ec904cf1:	je     0x7c33ec904d07
    7c33ec904cf3:	shr    rax,0x35
    7c33ec904cf7:	sub    eax,0x201
    7c33ec904cfc:	cmp    eax,0x3fc
    7c33ec904d01:	ja     0x7c33ec907cd5
    7c33ec904d07:	movdqa xmm14,xmm1
    7c33ec904d0c:	psrldq xmm14,0x8
    7c33ec904d12:	movq   rax,xmm14
    7c33ec904d17:	add    rax,rax
    7c33ec904d1a:	je     0x7c33ec904d30
    7c33ec904d1c:	shr    rax,0x35
    7c33ec904d20:	sub    eax,0x201
    7c33ec904d25:	cmp    eax,0x3fc
    7c33ec904d2a:	ja     0x7c33ec907cd5
    7c33ec904d30:	addpd  xmm0,xmm1
    7c33ec904d34:	movdqa xmm5,xmm0
    7c33ec904d38:	movdqa xmm0,xmm5
    7c33ec904d3c:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c33ec904d46:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec904d50:	movdqa xmm3,xmm0
    7c33ec904d54:	movdqa xmm0,xmm2
    7c33ec904d58:	movdqa xmm1,xmm3
    7c33ec904d5c:	pshufd xmm1,xmm1,0x44
    7c33ec904d61:	movq   rax,xmm0
    7c33ec904d66:	add    rax,rax
    7c33ec904d69:	je     0x7c33ec904d7f
    7c33ec904d6b:	shr    rax,0x35
    7c33ec904d6f:	sub    eax,0x201
    7c33ec904d74:	cmp    eax,0x3fc
    7c33ec904d79:	ja     0x7c33ec907cf9
    7c33ec904d7f:	movdqa xmm14,xmm0
    7c33ec904d84:	psrldq xmm14,0x8
    7c33ec904d8a:	movq   rax,xmm14
    7c33ec904d8f:	add    rax,rax
    7c33ec904d92:	je     0x7c33ec904da8
    7c33ec904d94:	shr    rax,0x35
    7c33ec904d98:	sub    eax,0x201
    7c33ec904d9d:	cmp    eax,0x3fc
    7c33ec904da2:	ja     0x7c33ec907cf9
    7c33ec904da8:	movq   rax,xmm1
    7c33ec904dad:	add    rax,rax
    7c33ec904db0:	je     0x7c33ec904dc6
    7c33ec904db2:	shr    rax,0x35
    7c33ec904db6:	sub    eax,0x201
    7c33ec904dbb:	cmp    eax,0x3fc
    7c33ec904dc0:	ja     0x7c33ec907cf9
    7c33ec904dc6:	movdqa xmm14,xmm1
    7c33ec904dcb:	psrldq xmm14,0x8
    7c33ec904dd1:	movq   rax,xmm14
    7c33ec904dd6:	add    rax,rax
    7c33ec904dd9:	je     0x7c33ec904def
    7c33ec904ddb:	shr    rax,0x35
    7c33ec904ddf:	sub    eax,0x201
    7c33ec904de4:	cmp    eax,0x3fc
    7c33ec904de9:	ja     0x7c33ec907cf9
    7c33ec904def:	mulpd  xmm0,xmm1
    7c33ec904df3:	movdqa xmm4,xmm0
    7c33ec904df7:	movdqa xmm0,xmm4
    7c33ec904dfb:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c33ec904e05:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec904e0d:	add    r13,0x80
    7c33ec904e14:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec904e1c:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec904e24:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec904e2c:	shr    r11d,1
    7c33ec904e2f:	and    r11d,0x10
    7c33ec904e33:	or     DWORD PTR [r12+0x314],r11d
    7c33ec904e3b:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec904e41:	movdqa xmm0,xmm2
    7c33ec904e45:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec904e4f:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec904e59:	movdqa xmm3,xmm0
    7c33ec904e5d:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec904e67:	movdqa xmm4,xmm0
    7c33ec904e6b:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec904e73:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec904e7e:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec904e86:	movdqa xmm0,xmm3
    7c33ec904e8a:	movdqa xmm1,xmm4
    7c33ec904e8e:	movq   rax,xmm0
    7c33ec904e93:	add    rax,rax
    7c33ec904e96:	je     0x7c33ec904eac
    7c33ec904e98:	shr    rax,0x35
    7c33ec904e9c:	sub    eax,0x201
    7c33ec904ea1:	cmp    eax,0x3fc
    7c33ec904ea6:	ja     0x7c33ec907d1d
    7c33ec904eac:	movdqa xmm14,xmm0
    7c33ec904eb1:	psrldq xmm14,0x8
    7c33ec904eb7:	movq   rax,xmm14
    7c33ec904ebc:	add    rax,rax
    7c33ec904ebf:	je     0x7c33ec904ed5
    7c33ec904ec1:	shr    rax,0x35
    7c33ec904ec5:	sub    eax,0x201
    7c33ec904eca:	cmp    eax,0x3fc
    7c33ec904ecf:	ja     0x7c33ec907d1d
    7c33ec904ed5:	movq   rax,xmm1
    7c33ec904eda:	add    rax,rax
    7c33ec904edd:	je     0x7c33ec904ef3
    7c33ec904edf:	shr    rax,0x35
    7c33ec904ee3:	sub    eax,0x201
    7c33ec904ee8:	cmp    eax,0x3fc
    7c33ec904eed:	ja     0x7c33ec907d1d
    7c33ec904ef3:	movdqa xmm14,xmm1
    7c33ec904ef8:	psrldq xmm14,0x8
    7c33ec904efe:	movq   rax,xmm14
    7c33ec904f03:	add    rax,rax
    7c33ec904f06:	je     0x7c33ec904f1c
    7c33ec904f08:	shr    rax,0x35
    7c33ec904f0c:	sub    eax,0x201
    7c33ec904f11:	cmp    eax,0x3fc
    7c33ec904f16:	ja     0x7c33ec907d1d
    7c33ec904f1c:	addpd  xmm0,xmm1
    7c33ec904f20:	movdqa xmm5,xmm0
    7c33ec904f24:	movdqa xmm0,xmm5
    7c33ec904f28:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec904f32:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec904f3c:	movdqa xmm3,xmm0
    7c33ec904f40:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c33ec904f4a:	movdqa xmm4,xmm0
    7c33ec904f4e:	movdqa xmm0,xmm3
    7c33ec904f52:	movdqa xmm1,xmm4
    7c33ec904f56:	movq   rax,xmm0
    7c33ec904f5b:	add    rax,rax
    7c33ec904f5e:	je     0x7c33ec904f74
    7c33ec904f60:	shr    rax,0x35
    7c33ec904f64:	sub    eax,0x201
    7c33ec904f69:	cmp    eax,0x3fc
    7c33ec904f6e:	ja     0x7c33ec907d41
    7c33ec904f74:	movdqa xmm14,xmm0
    7c33ec904f79:	psrldq xmm14,0x8
    7c33ec904f7f:	movq   rax,xmm14
    7c33ec904f84:	add    rax,rax
    7c33ec904f87:	je     0x7c33ec904f9d
    7c33ec904f89:	shr    rax,0x35
    7c33ec904f8d:	sub    eax,0x201
    7c33ec904f92:	cmp    eax,0x3fc
    7c33ec904f97:	ja     0x7c33ec907d41
    7c33ec904f9d:	movq   rax,xmm1
    7c33ec904fa2:	add    rax,rax
    7c33ec904fa5:	je     0x7c33ec904fbb
    7c33ec904fa7:	shr    rax,0x35
    7c33ec904fab:	sub    eax,0x201
    7c33ec904fb0:	cmp    eax,0x3fc
    7c33ec904fb5:	ja     0x7c33ec907d41
    7c33ec904fbb:	movdqa xmm14,xmm1
    7c33ec904fc0:	psrldq xmm14,0x8
    7c33ec904fc6:	movq   rax,xmm14
    7c33ec904fcb:	add    rax,rax
    7c33ec904fce:	je     0x7c33ec904fe4
    7c33ec904fd0:	shr    rax,0x35
    7c33ec904fd4:	sub    eax,0x201
    7c33ec904fd9:	cmp    eax,0x3fc
    7c33ec904fde:	ja     0x7c33ec907d41
    7c33ec904fe4:	addpd  xmm0,xmm1
    7c33ec904fe8:	movdqa xmm5,xmm0
    7c33ec904fec:	movdqa xmm0,xmm5
    7c33ec904ff0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec904ffa:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    7c33ec905004:	movdqa xmm3,xmm0
    7c33ec905008:	movdqa xmm1,xmm3
    7c33ec90500c:	por    xmm3,xmm1
    7c33ec905010:	movdqa xmm0,xmm3
    7c33ec905014:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7c33ec90501e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec905028:	movdqa xmm3,xmm0
    7c33ec90502c:	movdqa xmm0,xmm2
    7c33ec905030:	movdqa xmm1,xmm3
    7c33ec905034:	pshufd xmm1,xmm1,0x44
    7c33ec905039:	movq   rax,xmm0
    7c33ec90503e:	add    rax,rax
    7c33ec905041:	je     0x7c33ec905057
    7c33ec905043:	shr    rax,0x35
    7c33ec905047:	sub    eax,0x201
    7c33ec90504c:	cmp    eax,0x3fc
    7c33ec905051:	ja     0x7c33ec907d65
    7c33ec905057:	movdqa xmm14,xmm0
    7c33ec90505c:	psrldq xmm14,0x8
    7c33ec905062:	movq   rax,xmm14
    7c33ec905067:	add    rax,rax
    7c33ec90506a:	je     0x7c33ec905080
    7c33ec90506c:	shr    rax,0x35
    7c33ec905070:	sub    eax,0x201
    7c33ec905075:	cmp    eax,0x3fc
    7c33ec90507a:	ja     0x7c33ec907d65
    7c33ec905080:	movq   rax,xmm1
    7c33ec905085:	add    rax,rax
    7c33ec905088:	je     0x7c33ec90509e
    7c33ec90508a:	shr    rax,0x35
    7c33ec90508e:	sub    eax,0x201
    7c33ec905093:	cmp    eax,0x3fc
    7c33ec905098:	ja     0x7c33ec907d65
    7c33ec90509e:	movdqa xmm14,xmm1
    7c33ec9050a3:	psrldq xmm14,0x8
    7c33ec9050a9:	movq   rax,xmm14
    7c33ec9050ae:	add    rax,rax
    7c33ec9050b1:	je     0x7c33ec9050c7
    7c33ec9050b3:	shr    rax,0x35
    7c33ec9050b7:	sub    eax,0x201
    7c33ec9050bc:	cmp    eax,0x3fc
    7c33ec9050c1:	ja     0x7c33ec907d65
    7c33ec9050c7:	mulpd  xmm0,xmm1
    7c33ec9050cb:	movdqa xmm4,xmm0
    7c33ec9050cf:	movdqa xmm0,xmm4
    7c33ec9050d3:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c33ec9050dd:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9050e5:	add    r13,0xd0
    7c33ec9050ec:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec9050f4:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec9050fc:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec905104:	shr    r11d,1
    7c33ec905107:	and    r11d,0x10
    7c33ec90510b:	or     DWORD PTR [r12+0x314],r11d
    7c33ec905113:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec905119:	movdqa xmm0,xmm2
    7c33ec90511d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec905127:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec905131:	movdqa xmm3,xmm0
    7c33ec905135:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7c33ec90513f:	movdqa xmm4,xmm0
    7c33ec905143:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec90514b:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec905156:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec90515e:	movdqa xmm0,xmm3
    7c33ec905162:	movdqa xmm1,xmm4
    7c33ec905166:	movq   rax,xmm0
    7c33ec90516b:	add    rax,rax
    7c33ec90516e:	je     0x7c33ec905184
    7c33ec905170:	shr    rax,0x35
    7c33ec905174:	sub    eax,0x201
    7c33ec905179:	cmp    eax,0x3fc
    7c33ec90517e:	ja     0x7c33ec907d89
    7c33ec905184:	movdqa xmm14,xmm0
    7c33ec905189:	psrldq xmm14,0x8
    7c33ec90518f:	movq   rax,xmm14
    7c33ec905194:	add    rax,rax
    7c33ec905197:	je     0x7c33ec9051ad
    7c33ec905199:	shr    rax,0x35
    7c33ec90519d:	sub    eax,0x201
    7c33ec9051a2:	cmp    eax,0x3fc
    7c33ec9051a7:	ja     0x7c33ec907d89
    7c33ec9051ad:	movq   rax,xmm1
    7c33ec9051b2:	add    rax,rax
    7c33ec9051b5:	je     0x7c33ec9051cb
    7c33ec9051b7:	shr    rax,0x35
    7c33ec9051bb:	sub    eax,0x201
    7c33ec9051c0:	cmp    eax,0x3fc
    7c33ec9051c5:	ja     0x7c33ec907d89
    7c33ec9051cb:	movdqa xmm14,xmm1
    7c33ec9051d0:	psrldq xmm14,0x8
    7c33ec9051d6:	movq   rax,xmm14
    7c33ec9051db:	add    rax,rax
    7c33ec9051de:	je     0x7c33ec9051f4
    7c33ec9051e0:	shr    rax,0x35
    7c33ec9051e4:	sub    eax,0x201
    7c33ec9051e9:	cmp    eax,0x3fc
    7c33ec9051ee:	ja     0x7c33ec907d89
    7c33ec9051f4:	addpd  xmm0,xmm1
    7c33ec9051f8:	movdqa xmm5,xmm0
    7c33ec9051fc:	movdqa xmm0,xmm5
    7c33ec905200:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec90520a:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    7c33ec905214:	movdqa xmm3,xmm0
    7c33ec905218:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec905222:	movdqa xmm4,xmm0
    7c33ec905226:	movdqa xmm0,xmm3
    7c33ec90522a:	movdqa xmm1,xmm4
    7c33ec90522e:	pshufd xmm1,xmm1,0x44
    7c33ec905233:	movq   rax,xmm0
    7c33ec905238:	add    rax,rax
    7c33ec90523b:	je     0x7c33ec905251
    7c33ec90523d:	shr    rax,0x35
    7c33ec905241:	sub    eax,0x201
    7c33ec905246:	cmp    eax,0x3fc
    7c33ec90524b:	ja     0x7c33ec907dad
    7c33ec905251:	movdqa xmm14,xmm0
    7c33ec905256:	psrldq xmm14,0x8
    7c33ec90525c:	movq   rax,xmm14
    7c33ec905261:	add    rax,rax
    7c33ec905264:	je     0x7c33ec90527a
    7c33ec905266:	shr    rax,0x35
    7c33ec90526a:	sub    eax,0x201
    7c33ec90526f:	cmp    eax,0x3fc
    7c33ec905274:	ja     0x7c33ec907dad
    7c33ec90527a:	movq   rax,xmm1
    7c33ec90527f:	add    rax,rax
    7c33ec905282:	je     0x7c33ec905298
    7c33ec905284:	shr    rax,0x35
    7c33ec905288:	sub    eax,0x201
    7c33ec90528d:	cmp    eax,0x3fc
    7c33ec905292:	ja     0x7c33ec907dad
    7c33ec905298:	movdqa xmm14,xmm1
    7c33ec90529d:	psrldq xmm14,0x8
    7c33ec9052a3:	movq   rax,xmm14
    7c33ec9052a8:	add    rax,rax
    7c33ec9052ab:	je     0x7c33ec9052c1
    7c33ec9052ad:	shr    rax,0x35
    7c33ec9052b1:	sub    eax,0x201
    7c33ec9052b6:	cmp    eax,0x3fc
    7c33ec9052bb:	ja     0x7c33ec907dad
    7c33ec9052c1:	mulpd  xmm0,xmm1
    7c33ec9052c5:	movdqa xmm5,xmm0
    7c33ec9052c9:	movdqa xmm0,xmm5
    7c33ec9052cd:	movdqu XMMWORD PTR [r12+0x260],xmm0
    7c33ec9052d7:	mov    r13d,0x0
    7c33ec9052dd:	mov    r14d,0x0
    7c33ec9052e3:	mov    QWORD PTR [r12+0x1b0],r13
    7c33ec9052eb:	mov    QWORD PTR [r12+0x1b8],r14
    7c33ec9052f3:	movdqa xmm0,xmm2
    7c33ec9052f7:	movdqa xmm1,xmm4
    7c33ec9052fb:	pshufd xmm1,xmm1,0x44
    7c33ec905300:	movq   rax,xmm0
    7c33ec905305:	add    rax,rax
    7c33ec905308:	je     0x7c33ec90531e
    7c33ec90530a:	shr    rax,0x35
    7c33ec90530e:	sub    eax,0x201
    7c33ec905313:	cmp    eax,0x3fc
    7c33ec905318:	ja     0x7c33ec907dd1
    7c33ec90531e:	movdqa xmm14,xmm0
    7c33ec905323:	psrldq xmm14,0x8
    7c33ec905329:	movq   rax,xmm14
    7c33ec90532e:	add    rax,rax
    7c33ec905331:	je     0x7c33ec905347
    7c33ec905333:	shr    rax,0x35
    7c33ec905337:	sub    eax,0x201
    7c33ec90533c:	cmp    eax,0x3fc
    7c33ec905341:	ja     0x7c33ec907dd1
    7c33ec905347:	movq   rax,xmm1
    7c33ec90534c:	add    rax,rax
    7c33ec90534f:	je     0x7c33ec905365
    7c33ec905351:	shr    rax,0x35
    7c33ec905355:	sub    eax,0x201
    7c33ec90535a:	cmp    eax,0x3fc
    7c33ec90535f:	ja     0x7c33ec907dd1
    7c33ec905365:	movdqa xmm14,xmm1
    7c33ec90536a:	psrldq xmm14,0x8
    7c33ec905370:	movq   rax,xmm14
    7c33ec905375:	add    rax,rax
    7c33ec905378:	je     0x7c33ec90538e
    7c33ec90537a:	shr    rax,0x35
    7c33ec90537e:	sub    eax,0x201
    7c33ec905383:	cmp    eax,0x3fc
    7c33ec905388:	ja     0x7c33ec907dd1
    7c33ec90538e:	mulpd  xmm0,xmm1
    7c33ec905392:	movdqa xmm3,xmm0
    7c33ec905396:	movdqa xmm0,xmm3
    7c33ec90539a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c33ec9053a4:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9053ac:	mov    r14,r13
    7c33ec9053af:	add    r14,0xc0
    7c33ec9053b6:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec9053be:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec9053c6:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec9053ce:	shr    r11d,1
    7c33ec9053d1:	and    r11d,0x10
    7c33ec9053d5:	or     DWORD PTR [r12+0x314],r11d
    7c33ec9053dd:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec9053e2:	movdqa xmm0,xmm2
    7c33ec9053e6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec9053f0:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c33ec9053fa:	movdqa xmm3,xmm0
    7c33ec9053fe:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c33ec905408:	movdqa xmm4,xmm0
    7c33ec90540c:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec905414:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec90541f:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec905427:	movdqa xmm0,xmm3
    7c33ec90542b:	movdqa xmm1,xmm4
    7c33ec90542f:	movq   rax,xmm0
    7c33ec905434:	add    rax,rax
    7c33ec905437:	je     0x7c33ec90544d
    7c33ec905439:	shr    rax,0x35
    7c33ec90543d:	sub    eax,0x201
    7c33ec905442:	cmp    eax,0x3fc
    7c33ec905447:	ja     0x7c33ec907df5
    7c33ec90544d:	movdqa xmm14,xmm0
    7c33ec905452:	psrldq xmm14,0x8
    7c33ec905458:	movq   rax,xmm14
    7c33ec90545d:	add    rax,rax
    7c33ec905460:	je     0x7c33ec905476
    7c33ec905462:	shr    rax,0x35
    7c33ec905466:	sub    eax,0x201
    7c33ec90546b:	cmp    eax,0x3fc
    7c33ec905470:	ja     0x7c33ec907df5
    7c33ec905476:	movq   rax,xmm1
    7c33ec90547b:	add    rax,rax
    7c33ec90547e:	je     0x7c33ec905494
    7c33ec905480:	shr    rax,0x35
    7c33ec905484:	sub    eax,0x201
    7c33ec905489:	cmp    eax,0x3fc
    7c33ec90548e:	ja     0x7c33ec907df5
    7c33ec905494:	movdqa xmm14,xmm1
    7c33ec905499:	psrldq xmm14,0x8
    7c33ec90549f:	movq   rax,xmm14
    7c33ec9054a4:	add    rax,rax
    7c33ec9054a7:	je     0x7c33ec9054bd
    7c33ec9054a9:	shr    rax,0x35
    7c33ec9054ad:	sub    eax,0x201
    7c33ec9054b2:	cmp    eax,0x3fc
    7c33ec9054b7:	ja     0x7c33ec907df5
    7c33ec9054bd:	addpd  xmm0,xmm1
    7c33ec9054c1:	movdqa xmm5,xmm0
    7c33ec9054c5:	movdqa xmm0,xmm5
    7c33ec9054c9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c33ec9054d3:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7c33ec9054dd:	movdqa xmm3,xmm0
    7c33ec9054e1:	movdqa xmm1,xmm3
    7c33ec9054e5:	por    xmm3,xmm1
    7c33ec9054e9:	movdqa xmm0,xmm3
    7c33ec9054ed:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c33ec9054f7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec905501:	movdqa xmm3,xmm0
    7c33ec905505:	movdqa xmm1,xmm3
    7c33ec905509:	por    xmm3,xmm1
    7c33ec90550d:	movdqa xmm0,xmm3
    7c33ec905511:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    7c33ec90551b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec905525:	movdqa xmm3,xmm0
    7c33ec905529:	movdqa xmm0,xmm2
    7c33ec90552d:	movdqa xmm1,xmm3
    7c33ec905531:	pshufd xmm1,xmm1,0x44
    7c33ec905536:	movq   rax,xmm0
    7c33ec90553b:	add    rax,rax
    7c33ec90553e:	je     0x7c33ec905554
    7c33ec905540:	shr    rax,0x35
    7c33ec905544:	sub    eax,0x201
    7c33ec905549:	cmp    eax,0x3fc
    7c33ec90554e:	ja     0x7c33ec907e19
    7c33ec905554:	movdqa xmm14,xmm0
    7c33ec905559:	psrldq xmm14,0x8
    7c33ec90555f:	movq   rax,xmm14
    7c33ec905564:	add    rax,rax
    7c33ec905567:	je     0x7c33ec90557d
    7c33ec905569:	shr    rax,0x35
    7c33ec90556d:	sub    eax,0x201
    7c33ec905572:	cmp    eax,0x3fc
    7c33ec905577:	ja     0x7c33ec907e19
    7c33ec90557d:	movq   rax,xmm1
    7c33ec905582:	add    rax,rax
    7c33ec905585:	je     0x7c33ec90559b
    7c33ec905587:	shr    rax,0x35
    7c33ec90558b:	sub    eax,0x201
    7c33ec905590:	cmp    eax,0x3fc
    7c33ec905595:	ja     0x7c33ec907e19
    7c33ec90559b:	movdqa xmm14,xmm1
    7c33ec9055a0:	psrldq xmm14,0x8
    7c33ec9055a6:	movq   rax,xmm14
    7c33ec9055ab:	add    rax,rax
    7c33ec9055ae:	je     0x7c33ec9055c4
    7c33ec9055b0:	shr    rax,0x35
    7c33ec9055b4:	sub    eax,0x201
    7c33ec9055b9:	cmp    eax,0x3fc
    7c33ec9055be:	ja     0x7c33ec907e19
    7c33ec9055c4:	mulpd  xmm0,xmm1
    7c33ec9055c8:	movdqa xmm4,xmm0
    7c33ec9055cc:	movdqa xmm0,xmm4
    7c33ec9055d0:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c33ec9055da:	add    r13,0x20
    7c33ec9055de:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec9055e6:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec9055ee:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec9055f6:	shr    r11d,1
    7c33ec9055f9:	and    r11d,0x10
    7c33ec9055fd:	or     DWORD PTR [r12+0x314],r11d
    7c33ec905605:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec90560b:	movdqa xmm0,xmm2
    7c33ec90560f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec905619:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec905623:	movdqa xmm2,xmm0
    7c33ec905627:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec905631:	movdqa xmm4,xmm0
    7c33ec905635:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec90563d:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec905648:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec905650:	movdqa xmm0,xmm2
    7c33ec905654:	movdqa xmm1,xmm4
    7c33ec905658:	movq   rax,xmm0
    7c33ec90565d:	add    rax,rax
    7c33ec905660:	je     0x7c33ec905676
    7c33ec905662:	shr    rax,0x35
    7c33ec905666:	sub    eax,0x201
    7c33ec90566b:	cmp    eax,0x3fc
    7c33ec905670:	ja     0x7c33ec907e3d
    7c33ec905676:	movdqa xmm14,xmm0
    7c33ec90567b:	psrldq xmm14,0x8
    7c33ec905681:	movq   rax,xmm14
    7c33ec905686:	add    rax,rax
    7c33ec905689:	je     0x7c33ec90569f
    7c33ec90568b:	shr    rax,0x35
    7c33ec90568f:	sub    eax,0x201
    7c33ec905694:	cmp    eax,0x3fc
    7c33ec905699:	ja     0x7c33ec907e3d
    7c33ec90569f:	movq   rax,xmm1
    7c33ec9056a4:	add    rax,rax
    7c33ec9056a7:	je     0x7c33ec9056bd
    7c33ec9056a9:	shr    rax,0x35
    7c33ec9056ad:	sub    eax,0x201
    7c33ec9056b2:	cmp    eax,0x3fc
    7c33ec9056b7:	ja     0x7c33ec907e3d
    7c33ec9056bd:	movdqa xmm14,xmm1
    7c33ec9056c2:	psrldq xmm14,0x8
    7c33ec9056c8:	movq   rax,xmm14
    7c33ec9056cd:	add    rax,rax
    7c33ec9056d0:	je     0x7c33ec9056e6
    7c33ec9056d2:	shr    rax,0x35
    7c33ec9056d6:	sub    eax,0x201
    7c33ec9056db:	cmp    eax,0x3fc
    7c33ec9056e0:	ja     0x7c33ec907e3d
    7c33ec9056e6:	addpd  xmm0,xmm1
    7c33ec9056ea:	movdqa xmm5,xmm0
    7c33ec9056ee:	movdqa xmm0,xmm5
    7c33ec9056f2:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c33ec9056fc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    7c33ec905706:	movdqa xmm2,xmm0
    7c33ec90570a:	movdqa xmm0,xmm2
    7c33ec90570e:	movdqa xmm1,xmm3
    7c33ec905712:	pshufd xmm1,xmm1,0x44
    7c33ec905717:	movq   rax,xmm0
    7c33ec90571c:	add    rax,rax
    7c33ec90571f:	je     0x7c33ec905735
    7c33ec905721:	shr    rax,0x35
    7c33ec905725:	sub    eax,0x201
    7c33ec90572a:	cmp    eax,0x3fc
    7c33ec90572f:	ja     0x7c33ec907e61
    7c33ec905735:	movdqa xmm14,xmm0
    7c33ec90573a:	psrldq xmm14,0x8
    7c33ec905740:	movq   rax,xmm14
    7c33ec905745:	add    rax,rax
    7c33ec905748:	je     0x7c33ec90575e
    7c33ec90574a:	shr    rax,0x35
    7c33ec90574e:	sub    eax,0x201
    7c33ec905753:	cmp    eax,0x3fc
    7c33ec905758:	ja     0x7c33ec907e61
    7c33ec90575e:	movq   rax,xmm1
    7c33ec905763:	add    rax,rax
    7c33ec905766:	je     0x7c33ec90577c
    7c33ec905768:	shr    rax,0x35
    7c33ec90576c:	sub    eax,0x201
    7c33ec905771:	cmp    eax,0x3fc
    7c33ec905776:	ja     0x7c33ec907e61
    7c33ec90577c:	movdqa xmm14,xmm1
    7c33ec905781:	psrldq xmm14,0x8
    7c33ec905787:	movq   rax,xmm14
    7c33ec90578c:	add    rax,rax
    7c33ec90578f:	je     0x7c33ec9057a5
    7c33ec905791:	shr    rax,0x35
    7c33ec905795:	sub    eax,0x201
    7c33ec90579a:	cmp    eax,0x3fc
    7c33ec90579f:	ja     0x7c33ec907e61
    7c33ec9057a5:	mulpd  xmm0,xmm1
    7c33ec9057a9:	movdqa xmm4,xmm0
    7c33ec9057ad:	movdqa xmm0,xmm4
    7c33ec9057b1:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c33ec9057bb:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec9057c5:	movdqa xmm2,xmm0
    7c33ec9057c9:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec9057d3:	movdqa xmm3,xmm0
    7c33ec9057d7:	movdqa xmm0,xmm2
    7c33ec9057db:	movdqa xmm1,xmm3
    7c33ec9057df:	movq   rax,xmm0
    7c33ec9057e4:	add    rax,rax
    7c33ec9057e7:	je     0x7c33ec9057fd
    7c33ec9057e9:	shr    rax,0x35
    7c33ec9057ed:	sub    eax,0x201
    7c33ec9057f2:	cmp    eax,0x3fc
    7c33ec9057f7:	ja     0x7c33ec907e85
    7c33ec9057fd:	movdqa xmm14,xmm0
    7c33ec905802:	psrldq xmm14,0x8
    7c33ec905808:	movq   rax,xmm14
    7c33ec90580d:	add    rax,rax
    7c33ec905810:	je     0x7c33ec905826
    7c33ec905812:	shr    rax,0x35
    7c33ec905816:	sub    eax,0x201
    7c33ec90581b:	cmp    eax,0x3fc
    7c33ec905820:	ja     0x7c33ec907e85
    7c33ec905826:	movq   rax,xmm1
    7c33ec90582b:	add    rax,rax
    7c33ec90582e:	je     0x7c33ec905844
    7c33ec905830:	shr    rax,0x35
    7c33ec905834:	sub    eax,0x201
    7c33ec905839:	cmp    eax,0x3fc
    7c33ec90583e:	ja     0x7c33ec907e85
    7c33ec905844:	movdqa xmm14,xmm1
    7c33ec905849:	psrldq xmm14,0x8
    7c33ec90584f:	movq   rax,xmm14
    7c33ec905854:	add    rax,rax
    7c33ec905857:	je     0x7c33ec90586d
    7c33ec905859:	shr    rax,0x35
    7c33ec90585d:	sub    eax,0x201
    7c33ec905862:	cmp    eax,0x3fc
    7c33ec905867:	ja     0x7c33ec907e85
    7c33ec90586d:	addpd  xmm0,xmm1
    7c33ec905871:	movdqa xmm4,xmm0
    7c33ec905875:	movdqa xmm0,xmm4
    7c33ec905879:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec905883:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec90588d:	movdqa xmm2,xmm0
    7c33ec905891:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec90589b:	movdqa xmm3,xmm0
    7c33ec90589f:	movdqa xmm0,xmm2
    7c33ec9058a3:	movdqa xmm1,xmm3
    7c33ec9058a7:	pshufd xmm1,xmm1,0x44
    7c33ec9058ac:	movq   rax,xmm0
    7c33ec9058b1:	add    rax,rax
    7c33ec9058b4:	je     0x7c33ec9058ca
    7c33ec9058b6:	shr    rax,0x35
    7c33ec9058ba:	sub    eax,0x201
    7c33ec9058bf:	cmp    eax,0x3fc
    7c33ec9058c4:	ja     0x7c33ec907ea9
    7c33ec9058ca:	movdqa xmm14,xmm0
    7c33ec9058cf:	psrldq xmm14,0x8
    7c33ec9058d5:	movq   rax,xmm14
    7c33ec9058da:	add    rax,rax
    7c33ec9058dd:	je     0x7c33ec9058f3
    7c33ec9058df:	shr    rax,0x35
    7c33ec9058e3:	sub    eax,0x201
    7c33ec9058e8:	cmp    eax,0x3fc
    7c33ec9058ed:	ja     0x7c33ec907ea9
    7c33ec9058f3:	movq   rax,xmm1
    7c33ec9058f8:	add    rax,rax
    7c33ec9058fb:	je     0x7c33ec905911
    7c33ec9058fd:	shr    rax,0x35
    7c33ec905901:	sub    eax,0x201
    7c33ec905906:	cmp    eax,0x3fc
    7c33ec90590b:	ja     0x7c33ec907ea9
    7c33ec905911:	movdqa xmm14,xmm1
    7c33ec905916:	psrldq xmm14,0x8
    7c33ec90591c:	movq   rax,xmm14
    7c33ec905921:	add    rax,rax
    7c33ec905924:	je     0x7c33ec90593a
    7c33ec905926:	shr    rax,0x35
    7c33ec90592a:	sub    eax,0x201
    7c33ec90592f:	cmp    eax,0x3fc
    7c33ec905934:	ja     0x7c33ec907ea9
    7c33ec90593a:	mulpd  xmm0,xmm1
    7c33ec90593e:	movdqa xmm4,xmm0
    7c33ec905942:	movdqa xmm0,xmm4
    7c33ec905946:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec905950:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7c33ec90595a:	movdqa xmm2,xmm0
    7c33ec90595e:	movdqa xmm0,xmm2
    7c33ec905962:	movdqa xmm1,xmm3
    7c33ec905966:	pshufd xmm1,xmm1,0x44
    7c33ec90596b:	movq   rax,xmm0
    7c33ec905970:	add    rax,rax
    7c33ec905973:	je     0x7c33ec905989
    7c33ec905975:	shr    rax,0x35
    7c33ec905979:	sub    eax,0x201
    7c33ec90597e:	cmp    eax,0x3fc
    7c33ec905983:	ja     0x7c33ec907ecd
    7c33ec905989:	movdqa xmm14,xmm0
    7c33ec90598e:	psrldq xmm14,0x8
    7c33ec905994:	movq   rax,xmm14
    7c33ec905999:	add    rax,rax
    7c33ec90599c:	je     0x7c33ec9059b2
    7c33ec90599e:	shr    rax,0x35
    7c33ec9059a2:	sub    eax,0x201
    7c33ec9059a7:	cmp    eax,0x3fc
    7c33ec9059ac:	ja     0x7c33ec907ecd
    7c33ec9059b2:	movq   rax,xmm1
    7c33ec9059b7:	add    rax,rax
    7c33ec9059ba:	je     0x7c33ec9059d0
    7c33ec9059bc:	shr    rax,0x35
    7c33ec9059c0:	sub    eax,0x201
    7c33ec9059c5:	cmp    eax,0x3fc
    7c33ec9059ca:	ja     0x7c33ec907ecd
    7c33ec9059d0:	movdqa xmm14,xmm1
    7c33ec9059d5:	psrldq xmm14,0x8
    7c33ec9059db:	movq   rax,xmm14
    7c33ec9059e0:	add    rax,rax
    7c33ec9059e3:	je     0x7c33ec9059f9
    7c33ec9059e5:	shr    rax,0x35
    7c33ec9059e9:	sub    eax,0x201
    7c33ec9059ee:	cmp    eax,0x3fc
    7c33ec9059f3:	ja     0x7c33ec907ecd
    7c33ec9059f9:	mulpd  xmm0,xmm1
    7c33ec9059fd:	movdqa xmm4,xmm0
    7c33ec905a01:	movdqa xmm0,xmm4
    7c33ec905a05:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c33ec905a0f:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c33ec905a19:	movdqa xmm2,xmm0
    7c33ec905a1d:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7c33ec905a27:	movdqa xmm4,xmm0
    7c33ec905a2b:	movdqa xmm0,xmm2
    7c33ec905a2f:	movdqa xmm1,xmm4
    7c33ec905a33:	movq   rax,xmm0
    7c33ec905a38:	add    rax,rax
    7c33ec905a3b:	je     0x7c33ec905a51
    7c33ec905a3d:	shr    rax,0x35
    7c33ec905a41:	sub    eax,0x201
    7c33ec905a46:	cmp    eax,0x3fc
    7c33ec905a4b:	ja     0x7c33ec907ef1
    7c33ec905a51:	movdqa xmm14,xmm0
    7c33ec905a56:	psrldq xmm14,0x8
    7c33ec905a5c:	movq   rax,xmm14
    7c33ec905a61:	add    rax,rax
    7c33ec905a64:	je     0x7c33ec905a7a
    7c33ec905a66:	shr    rax,0x35
    7c33ec905a6a:	sub    eax,0x201
    7c33ec905a6f:	cmp    eax,0x3fc
    7c33ec905a74:	ja     0x7c33ec907ef1
    7c33ec905a7a:	movq   rax,xmm1
    7c33ec905a7f:	add    rax,rax
    7c33ec905a82:	je     0x7c33ec905a98
    7c33ec905a84:	shr    rax,0x35
    7c33ec905a88:	sub    eax,0x201
    7c33ec905a8d:	cmp    eax,0x3fc
    7c33ec905a92:	ja     0x7c33ec907ef1
    7c33ec905a98:	movdqa xmm14,xmm1
    7c33ec905a9d:	psrldq xmm14,0x8
    7c33ec905aa3:	movq   rax,xmm14
    7c33ec905aa8:	add    rax,rax
    7c33ec905aab:	je     0x7c33ec905ac1
    7c33ec905aad:	shr    rax,0x35
    7c33ec905ab1:	sub    eax,0x201
    7c33ec905ab6:	cmp    eax,0x3fc
    7c33ec905abb:	ja     0x7c33ec907ef1
    7c33ec905ac1:	addpd  xmm0,xmm1
    7c33ec905ac5:	movdqa xmm5,xmm0
    7c33ec905ac9:	movdqa xmm0,xmm5
    7c33ec905acd:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c33ec905ad7:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec905ae1:	movdqa xmm2,xmm0
    7c33ec905ae5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c33ec905aef:	movdqa xmm4,xmm0
    7c33ec905af3:	movdqa xmm0,xmm2
    7c33ec905af7:	movdqa xmm1,xmm4
    7c33ec905afb:	movq   rax,xmm0
    7c33ec905b00:	add    rax,rax
    7c33ec905b03:	je     0x7c33ec905b19
    7c33ec905b05:	shr    rax,0x35
    7c33ec905b09:	sub    eax,0x201
    7c33ec905b0e:	cmp    eax,0x3fc
    7c33ec905b13:	ja     0x7c33ec907f15
    7c33ec905b19:	movdqa xmm14,xmm0
    7c33ec905b1e:	psrldq xmm14,0x8
    7c33ec905b24:	movq   rax,xmm14
    7c33ec905b29:	add    rax,rax
    7c33ec905b2c:	je     0x7c33ec905b42
    7c33ec905b2e:	shr    rax,0x35
    7c33ec905b32:	sub    eax,0x201
    7c33ec905b37:	cmp    eax,0x3fc
    7c33ec905b3c:	ja     0x7c33ec907f15
    7c33ec905b42:	movq   rax,xmm1
    7c33ec905b47:	add    rax,rax
    7c33ec905b4a:	je     0x7c33ec905b60
    7c33ec905b4c:	shr    rax,0x35
    7c33ec905b50:	sub    eax,0x201
    7c33ec905b55:	cmp    eax,0x3fc
    7c33ec905b5a:	ja     0x7c33ec907f15
    7c33ec905b60:	movdqa xmm14,xmm1
    7c33ec905b65:	psrldq xmm14,0x8
    7c33ec905b6b:	movq   rax,xmm14
    7c33ec905b70:	add    rax,rax
    7c33ec905b73:	je     0x7c33ec905b89
    7c33ec905b75:	shr    rax,0x35
    7c33ec905b79:	sub    eax,0x201
    7c33ec905b7e:	cmp    eax,0x3fc
    7c33ec905b83:	ja     0x7c33ec907f15
    7c33ec905b89:	addpd  xmm0,xmm1
    7c33ec905b8d:	movdqa xmm5,xmm0
    7c33ec905b91:	movdqa xmm0,xmm5
    7c33ec905b95:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec905b9f:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7c33ec905ba9:	movdqa xmm2,xmm0
    7c33ec905bad:	movdqa xmm0,xmm2
    7c33ec905bb1:	movdqa xmm1,xmm3
    7c33ec905bb5:	pshufd xmm1,xmm1,0x44
    7c33ec905bba:	movq   rax,xmm0
    7c33ec905bbf:	add    rax,rax
    7c33ec905bc2:	je     0x7c33ec905bd8
    7c33ec905bc4:	shr    rax,0x35
    7c33ec905bc8:	sub    eax,0x201
    7c33ec905bcd:	cmp    eax,0x3fc
    7c33ec905bd2:	ja     0x7c33ec907f39
    7c33ec905bd8:	movdqa xmm14,xmm0
    7c33ec905bdd:	psrldq xmm14,0x8
    7c33ec905be3:	movq   rax,xmm14
    7c33ec905be8:	add    rax,rax
    7c33ec905beb:	je     0x7c33ec905c01
    7c33ec905bed:	shr    rax,0x35
    7c33ec905bf1:	sub    eax,0x201
    7c33ec905bf6:	cmp    eax,0x3fc
    7c33ec905bfb:	ja     0x7c33ec907f39
    7c33ec905c01:	movq   rax,xmm1
    7c33ec905c06:	add    rax,rax
    7c33ec905c09:	je     0x7c33ec905c1f
    7c33ec905c0b:	shr    rax,0x35
    7c33ec905c0f:	sub    eax,0x201
    7c33ec905c14:	cmp    eax,0x3fc
    7c33ec905c19:	ja     0x7c33ec907f39
    7c33ec905c1f:	movdqa xmm14,xmm1
    7c33ec905c24:	psrldq xmm14,0x8
    7c33ec905c2a:	movq   rax,xmm14
    7c33ec905c2f:	add    rax,rax
    7c33ec905c32:	je     0x7c33ec905c48
    7c33ec905c34:	shr    rax,0x35
    7c33ec905c38:	sub    eax,0x201
    7c33ec905c3d:	cmp    eax,0x3fc
    7c33ec905c42:	ja     0x7c33ec907f39
    7c33ec905c48:	mulpd  xmm0,xmm1
    7c33ec905c4c:	movdqa xmm4,xmm0
    7c33ec905c50:	movdqa xmm0,xmm4
    7c33ec905c54:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c33ec905c5e:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7c33ec905c68:	movdqa xmm2,xmm0
    7c33ec905c6c:	movdqa xmm0,xmm2
    7c33ec905c70:	movdqa xmm1,xmm3
    7c33ec905c74:	pshufd xmm1,xmm1,0x44
    7c33ec905c79:	movq   rax,xmm0
    7c33ec905c7e:	add    rax,rax
    7c33ec905c81:	je     0x7c33ec905c97
    7c33ec905c83:	shr    rax,0x35
    7c33ec905c87:	sub    eax,0x201
    7c33ec905c8c:	cmp    eax,0x3fc
    7c33ec905c91:	ja     0x7c33ec907f5d
    7c33ec905c97:	movdqa xmm14,xmm0
    7c33ec905c9c:	psrldq xmm14,0x8
    7c33ec905ca2:	movq   rax,xmm14
    7c33ec905ca7:	add    rax,rax
    7c33ec905caa:	je     0x7c33ec905cc0
    7c33ec905cac:	shr    rax,0x35
    7c33ec905cb0:	sub    eax,0x201
    7c33ec905cb5:	cmp    eax,0x3fc
    7c33ec905cba:	ja     0x7c33ec907f5d
    7c33ec905cc0:	movq   rax,xmm1
    7c33ec905cc5:	add    rax,rax
    7c33ec905cc8:	je     0x7c33ec905cde
    7c33ec905cca:	shr    rax,0x35
    7c33ec905cce:	sub    eax,0x201
    7c33ec905cd3:	cmp    eax,0x3fc
    7c33ec905cd8:	ja     0x7c33ec907f5d
    7c33ec905cde:	movdqa xmm14,xmm1
    7c33ec905ce3:	psrldq xmm14,0x8
    7c33ec905ce9:	movq   rax,xmm14
    7c33ec905cee:	add    rax,rax
    7c33ec905cf1:	je     0x7c33ec905d07
    7c33ec905cf3:	shr    rax,0x35
    7c33ec905cf7:	sub    eax,0x201
    7c33ec905cfc:	cmp    eax,0x3fc
    7c33ec905d01:	ja     0x7c33ec907f5d
    7c33ec905d07:	mulpd  xmm0,xmm1
    7c33ec905d0b:	movdqa xmm4,xmm0
    7c33ec905d0f:	movdqa xmm0,xmm4
    7c33ec905d13:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec905d1d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec905d27:	movdqa xmm2,xmm0
    7c33ec905d2b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec905d35:	movdqa xmm3,xmm0
    7c33ec905d39:	movdqa xmm0,xmm2
    7c33ec905d3d:	movdqa xmm1,xmm3
    7c33ec905d41:	movq   rax,xmm0
    7c33ec905d46:	add    rax,rax
    7c33ec905d49:	je     0x7c33ec905d5f
    7c33ec905d4b:	shr    rax,0x35
    7c33ec905d4f:	sub    eax,0x201
    7c33ec905d54:	cmp    eax,0x3fc
    7c33ec905d59:	ja     0x7c33ec907f81
    7c33ec905d5f:	movdqa xmm14,xmm0
    7c33ec905d64:	psrldq xmm14,0x8
    7c33ec905d6a:	movq   rax,xmm14
    7c33ec905d6f:	add    rax,rax
    7c33ec905d72:	je     0x7c33ec905d88
    7c33ec905d74:	shr    rax,0x35
    7c33ec905d78:	sub    eax,0x201
    7c33ec905d7d:	cmp    eax,0x3fc
    7c33ec905d82:	ja     0x7c33ec907f81
    7c33ec905d88:	movq   rax,xmm1
    7c33ec905d8d:	add    rax,rax
    7c33ec905d90:	je     0x7c33ec905da6
    7c33ec905d92:	shr    rax,0x35
    7c33ec905d96:	sub    eax,0x201
    7c33ec905d9b:	cmp    eax,0x3fc
    7c33ec905da0:	ja     0x7c33ec907f81
    7c33ec905da6:	movdqa xmm14,xmm1
    7c33ec905dab:	psrldq xmm14,0x8
    7c33ec905db1:	movq   rax,xmm14
    7c33ec905db6:	add    rax,rax
    7c33ec905db9:	je     0x7c33ec905dcf
    7c33ec905dbb:	shr    rax,0x35
    7c33ec905dbf:	sub    eax,0x201
    7c33ec905dc4:	cmp    eax,0x3fc
    7c33ec905dc9:	ja     0x7c33ec907f81
    7c33ec905dcf:	addpd  xmm0,xmm1
    7c33ec905dd3:	movdqa xmm4,xmm0
    7c33ec905dd7:	movdqa xmm0,xmm4
    7c33ec905ddb:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c33ec905de5:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec905def:	movdqa xmm2,xmm0
    7c33ec905df3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec905dfd:	movdqa xmm3,xmm0
    7c33ec905e01:	movdqa xmm0,xmm2
    7c33ec905e05:	movdqa xmm1,xmm3
    7c33ec905e09:	movq   rax,xmm0
    7c33ec905e0e:	add    rax,rax
    7c33ec905e11:	je     0x7c33ec905e27
    7c33ec905e13:	shr    rax,0x35
    7c33ec905e17:	sub    eax,0x201
    7c33ec905e1c:	cmp    eax,0x3fc
    7c33ec905e21:	ja     0x7c33ec907fa5
    7c33ec905e27:	movdqa xmm14,xmm0
    7c33ec905e2c:	psrldq xmm14,0x8
    7c33ec905e32:	movq   rax,xmm14
    7c33ec905e37:	add    rax,rax
    7c33ec905e3a:	je     0x7c33ec905e50
    7c33ec905e3c:	shr    rax,0x35
    7c33ec905e40:	sub    eax,0x201
    7c33ec905e45:	cmp    eax,0x3fc
    7c33ec905e4a:	ja     0x7c33ec907fa5
    7c33ec905e50:	movq   rax,xmm1
    7c33ec905e55:	add    rax,rax
    7c33ec905e58:	je     0x7c33ec905e6e
    7c33ec905e5a:	shr    rax,0x35
    7c33ec905e5e:	sub    eax,0x201
    7c33ec905e63:	cmp    eax,0x3fc
    7c33ec905e68:	ja     0x7c33ec907fa5
    7c33ec905e6e:	movdqa xmm14,xmm1
    7c33ec905e73:	psrldq xmm14,0x8
    7c33ec905e79:	movq   rax,xmm14
    7c33ec905e7e:	add    rax,rax
    7c33ec905e81:	je     0x7c33ec905e97
    7c33ec905e83:	shr    rax,0x35
    7c33ec905e87:	sub    eax,0x201
    7c33ec905e8c:	cmp    eax,0x3fc
    7c33ec905e91:	ja     0x7c33ec907fa5
    7c33ec905e97:	addpd  xmm0,xmm1
    7c33ec905e9b:	movdqa xmm4,xmm0
    7c33ec905e9f:	movdqa xmm0,xmm4
    7c33ec905ea3:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c33ec905ead:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c33ec905eb7:	movdqa xmm2,xmm0
    7c33ec905ebb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec905ec5:	movdqa xmm3,xmm0
    7c33ec905ec9:	movdqa xmm0,xmm2
    7c33ec905ecd:	movdqa xmm1,xmm3
    7c33ec905ed1:	pshufd xmm1,xmm1,0x44
    7c33ec905ed6:	movq   rax,xmm0
    7c33ec905edb:	add    rax,rax
    7c33ec905ede:	je     0x7c33ec905ef4
    7c33ec905ee0:	shr    rax,0x35
    7c33ec905ee4:	sub    eax,0x201
    7c33ec905ee9:	cmp    eax,0x3fc
    7c33ec905eee:	ja     0x7c33ec907fc9
    7c33ec905ef4:	movdqa xmm14,xmm0
    7c33ec905ef9:	psrldq xmm14,0x8
    7c33ec905eff:	movq   rax,xmm14
    7c33ec905f04:	add    rax,rax
    7c33ec905f07:	je     0x7c33ec905f1d
    7c33ec905f09:	shr    rax,0x35
    7c33ec905f0d:	sub    eax,0x201
    7c33ec905f12:	cmp    eax,0x3fc
    7c33ec905f17:	ja     0x7c33ec907fc9
    7c33ec905f1d:	movq   rax,xmm1
    7c33ec905f22:	add    rax,rax
    7c33ec905f25:	je     0x7c33ec905f3b
    7c33ec905f27:	shr    rax,0x35
    7c33ec905f2b:	sub    eax,0x201
    7c33ec905f30:	cmp    eax,0x3fc
    7c33ec905f35:	ja     0x7c33ec907fc9
    7c33ec905f3b:	movdqa xmm14,xmm1
    7c33ec905f40:	psrldq xmm14,0x8
    7c33ec905f46:	movq   rax,xmm14
    7c33ec905f4b:	add    rax,rax
    7c33ec905f4e:	je     0x7c33ec905f64
    7c33ec905f50:	shr    rax,0x35
    7c33ec905f54:	sub    eax,0x201
    7c33ec905f59:	cmp    eax,0x3fc
    7c33ec905f5e:	ja     0x7c33ec907fc9
    7c33ec905f64:	mulpd  xmm0,xmm1
    7c33ec905f68:	movdqa xmm4,xmm0
    7c33ec905f6c:	movdqa xmm0,xmm4
    7c33ec905f70:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec905f7a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec905f84:	movdqa xmm2,xmm0
    7c33ec905f88:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec905f92:	movdqa xmm3,xmm0
    7c33ec905f96:	movdqa xmm0,xmm2
    7c33ec905f9a:	movdqa xmm1,xmm3
    7c33ec905f9e:	movq   rax,xmm0
    7c33ec905fa3:	add    rax,rax
    7c33ec905fa6:	je     0x7c33ec905fbc
    7c33ec905fa8:	shr    rax,0x35
    7c33ec905fac:	sub    eax,0x201
    7c33ec905fb1:	cmp    eax,0x3fc
    7c33ec905fb6:	ja     0x7c33ec907fed
    7c33ec905fbc:	movdqa xmm14,xmm0
    7c33ec905fc1:	psrldq xmm14,0x8
    7c33ec905fc7:	movq   rax,xmm14
    7c33ec905fcc:	add    rax,rax
    7c33ec905fcf:	je     0x7c33ec905fe5
    7c33ec905fd1:	shr    rax,0x35
    7c33ec905fd5:	sub    eax,0x201
    7c33ec905fda:	cmp    eax,0x3fc
    7c33ec905fdf:	ja     0x7c33ec907fed
    7c33ec905fe5:	movq   rax,xmm1
    7c33ec905fea:	add    rax,rax
    7c33ec905fed:	je     0x7c33ec906003
    7c33ec905fef:	shr    rax,0x35
    7c33ec905ff3:	sub    eax,0x201
    7c33ec905ff8:	cmp    eax,0x3fc
    7c33ec905ffd:	ja     0x7c33ec907fed
    7c33ec906003:	movdqa xmm14,xmm1
    7c33ec906008:	psrldq xmm14,0x8
    7c33ec90600e:	movq   rax,xmm14
    7c33ec906013:	add    rax,rax
    7c33ec906016:	je     0x7c33ec90602c
    7c33ec906018:	shr    rax,0x35
    7c33ec90601c:	sub    eax,0x201
    7c33ec906021:	cmp    eax,0x3fc
    7c33ec906026:	ja     0x7c33ec907fed
    7c33ec90602c:	addpd  xmm0,xmm1
    7c33ec906030:	movdqa xmm4,xmm0
    7c33ec906034:	movdqa xmm0,xmm4
    7c33ec906038:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec906042:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c33ec90604c:	movdqa xmm2,xmm0
    7c33ec906050:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c33ec90605a:	movdqa xmm3,xmm0
    7c33ec90605e:	movdqa xmm0,xmm2
    7c33ec906062:	movdqa xmm1,xmm3
    7c33ec906066:	movq   rax,xmm0
    7c33ec90606b:	add    rax,rax
    7c33ec90606e:	je     0x7c33ec906084
    7c33ec906070:	shr    rax,0x35
    7c33ec906074:	sub    eax,0x201
    7c33ec906079:	cmp    eax,0x3fc
    7c33ec90607e:	ja     0x7c33ec908011
    7c33ec906084:	movdqa xmm14,xmm0
    7c33ec906089:	psrldq xmm14,0x8
    7c33ec90608f:	movq   rax,xmm14
    7c33ec906094:	add    rax,rax
    7c33ec906097:	je     0x7c33ec9060ad
    7c33ec906099:	shr    rax,0x35
    7c33ec90609d:	sub    eax,0x201
    7c33ec9060a2:	cmp    eax,0x3fc
    7c33ec9060a7:	ja     0x7c33ec908011
    7c33ec9060ad:	movq   rax,xmm1
    7c33ec9060b2:	add    rax,rax
    7c33ec9060b5:	je     0x7c33ec9060cb
    7c33ec9060b7:	shr    rax,0x35
    7c33ec9060bb:	sub    eax,0x201
    7c33ec9060c0:	cmp    eax,0x3fc
    7c33ec9060c5:	ja     0x7c33ec908011
    7c33ec9060cb:	movdqa xmm14,xmm1
    7c33ec9060d0:	psrldq xmm14,0x8
    7c33ec9060d6:	movq   rax,xmm14
    7c33ec9060db:	add    rax,rax
    7c33ec9060de:	je     0x7c33ec9060f4
    7c33ec9060e0:	shr    rax,0x35
    7c33ec9060e4:	sub    eax,0x201
    7c33ec9060e9:	cmp    eax,0x3fc
    7c33ec9060ee:	ja     0x7c33ec908011
    7c33ec9060f4:	addpd  xmm0,xmm1
    7c33ec9060f8:	movdqa xmm4,xmm0
    7c33ec9060fc:	movdqa xmm0,xmm4
    7c33ec906100:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c33ec90610a:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    7c33ec906114:	movdqa xmm2,xmm0
    7c33ec906118:	movdqa xmm1,xmm2
    7c33ec90611c:	por    xmm2,xmm1
    7c33ec906120:	movdqa xmm0,xmm2
    7c33ec906124:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c33ec90612e:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    7c33ec906138:	movdqa xmm2,xmm0
    7c33ec90613c:	movdqa xmm1,xmm2
    7c33ec906140:	por    xmm2,xmm1
    7c33ec906144:	movdqa xmm0,xmm2
    7c33ec906148:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    7c33ec906152:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    7c33ec90615c:	movdqa xmm2,xmm0
    7c33ec906160:	movdqa xmm1,xmm2
    7c33ec906164:	por    xmm2,xmm1
    7c33ec906168:	movdqa xmm0,xmm2
    7c33ec90616c:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    7c33ec906176:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec90617e:	add    r13,0x40
    7c33ec906182:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec90618a:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec906192:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec90619a:	shr    r11d,1
    7c33ec90619d:	and    r11d,0x10
    7c33ec9061a1:	or     DWORD PTR [r12+0x314],r11d
    7c33ec9061a9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec9061af:	movdqa xmm0,xmm2
    7c33ec9061b3:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    7c33ec9061bd:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7c33ec9061c7:	movdqa xmm2,xmm0
    7c33ec9061cb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec9061d5:	movdqa xmm3,xmm0
    7c33ec9061d9:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec9061e1:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec9061ec:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec9061f4:	movdqa xmm0,xmm2
    7c33ec9061f8:	movdqa xmm1,xmm3
    7c33ec9061fc:	pshufd xmm1,xmm1,0x44
    7c33ec906201:	movq   rax,xmm0
    7c33ec906206:	add    rax,rax
    7c33ec906209:	je     0x7c33ec90621f
    7c33ec90620b:	shr    rax,0x35
    7c33ec90620f:	sub    eax,0x201
    7c33ec906214:	cmp    eax,0x3fc
    7c33ec906219:	ja     0x7c33ec908035
    7c33ec90621f:	movdqa xmm14,xmm0
    7c33ec906224:	psrldq xmm14,0x8
    7c33ec90622a:	movq   rax,xmm14
    7c33ec90622f:	add    rax,rax
    7c33ec906232:	je     0x7c33ec906248
    7c33ec906234:	shr    rax,0x35
    7c33ec906238:	sub    eax,0x201
    7c33ec90623d:	cmp    eax,0x3fc
    7c33ec906242:	ja     0x7c33ec908035
    7c33ec906248:	movq   rax,xmm1
    7c33ec90624d:	add    rax,rax
    7c33ec906250:	je     0x7c33ec906266
    7c33ec906252:	shr    rax,0x35
    7c33ec906256:	sub    eax,0x201
    7c33ec90625b:	cmp    eax,0x3fc
    7c33ec906260:	ja     0x7c33ec908035
    7c33ec906266:	movdqa xmm14,xmm1
    7c33ec90626b:	psrldq xmm14,0x8
    7c33ec906271:	movq   rax,xmm14
    7c33ec906276:	add    rax,rax
    7c33ec906279:	je     0x7c33ec90628f
    7c33ec90627b:	shr    rax,0x35
    7c33ec90627f:	sub    eax,0x201
    7c33ec906284:	cmp    eax,0x3fc
    7c33ec906289:	ja     0x7c33ec908035
    7c33ec90628f:	mulpd  xmm0,xmm1
    7c33ec906293:	movdqa xmm4,xmm0
    7c33ec906297:	movdqa xmm0,xmm4
    7c33ec90629b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec9062a5:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec9062af:	movdqa xmm2,xmm0
    7c33ec9062b3:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec9062bd:	movdqa xmm4,xmm0
    7c33ec9062c1:	movdqa xmm0,xmm2
    7c33ec9062c5:	movdqa xmm1,xmm4
    7c33ec9062c9:	movq   rax,xmm0
    7c33ec9062ce:	add    rax,rax
    7c33ec9062d1:	je     0x7c33ec9062e7
    7c33ec9062d3:	shr    rax,0x35
    7c33ec9062d7:	sub    eax,0x201
    7c33ec9062dc:	cmp    eax,0x3fc
    7c33ec9062e1:	ja     0x7c33ec908059
    7c33ec9062e7:	movdqa xmm14,xmm0
    7c33ec9062ec:	psrldq xmm14,0x8
    7c33ec9062f2:	movq   rax,xmm14
    7c33ec9062f7:	add    rax,rax
    7c33ec9062fa:	je     0x7c33ec906310
    7c33ec9062fc:	shr    rax,0x35
    7c33ec906300:	sub    eax,0x201
    7c33ec906305:	cmp    eax,0x3fc
    7c33ec90630a:	ja     0x7c33ec908059
    7c33ec906310:	movq   rax,xmm1
    7c33ec906315:	add    rax,rax
    7c33ec906318:	je     0x7c33ec90632e
    7c33ec90631a:	shr    rax,0x35
    7c33ec90631e:	sub    eax,0x201
    7c33ec906323:	cmp    eax,0x3fc
    7c33ec906328:	ja     0x7c33ec908059
    7c33ec90632e:	movdqa xmm14,xmm1
    7c33ec906333:	psrldq xmm14,0x8
    7c33ec906339:	movq   rax,xmm14
    7c33ec90633e:	add    rax,rax
    7c33ec906341:	je     0x7c33ec906357
    7c33ec906343:	shr    rax,0x35
    7c33ec906347:	sub    eax,0x201
    7c33ec90634c:	cmp    eax,0x3fc
    7c33ec906351:	ja     0x7c33ec908059
    7c33ec906357:	addpd  xmm0,xmm1
    7c33ec90635b:	movdqa xmm5,xmm0
    7c33ec90635f:	movdqa xmm0,xmm5
    7c33ec906363:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec90636d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec906377:	movdqa xmm2,xmm0
    7c33ec90637b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec906385:	movdqa xmm4,xmm0
    7c33ec906389:	movdqa xmm0,xmm2
    7c33ec90638d:	movdqa xmm1,xmm4
    7c33ec906391:	movq   rax,xmm0
    7c33ec906396:	add    rax,rax
    7c33ec906399:	je     0x7c33ec9063af
    7c33ec90639b:	shr    rax,0x35
    7c33ec90639f:	sub    eax,0x201
    7c33ec9063a4:	cmp    eax,0x3fc
    7c33ec9063a9:	ja     0x7c33ec90807d
    7c33ec9063af:	movdqa xmm14,xmm0
    7c33ec9063b4:	psrldq xmm14,0x8
    7c33ec9063ba:	movq   rax,xmm14
    7c33ec9063bf:	add    rax,rax
    7c33ec9063c2:	je     0x7c33ec9063d8
    7c33ec9063c4:	shr    rax,0x35
    7c33ec9063c8:	sub    eax,0x201
    7c33ec9063cd:	cmp    eax,0x3fc
    7c33ec9063d2:	ja     0x7c33ec90807d
    7c33ec9063d8:	movq   rax,xmm1
    7c33ec9063dd:	add    rax,rax
    7c33ec9063e0:	je     0x7c33ec9063f6
    7c33ec9063e2:	shr    rax,0x35
    7c33ec9063e6:	sub    eax,0x201
    7c33ec9063eb:	cmp    eax,0x3fc
    7c33ec9063f0:	ja     0x7c33ec90807d
    7c33ec9063f6:	movdqa xmm14,xmm1
    7c33ec9063fb:	psrldq xmm14,0x8
    7c33ec906401:	movq   rax,xmm14
    7c33ec906406:	add    rax,rax
    7c33ec906409:	je     0x7c33ec90641f
    7c33ec90640b:	shr    rax,0x35
    7c33ec90640f:	sub    eax,0x201
    7c33ec906414:	cmp    eax,0x3fc
    7c33ec906419:	ja     0x7c33ec90807d
    7c33ec90641f:	addpd  xmm0,xmm1
    7c33ec906423:	movdqa xmm5,xmm0
    7c33ec906427:	movdqa xmm0,xmm5
    7c33ec90642b:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c33ec906435:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    7c33ec90643f:	movdqa xmm2,xmm0
    7c33ec906443:	movdqa xmm0,xmm2
    7c33ec906447:	movdqa xmm1,xmm3
    7c33ec90644b:	pshufd xmm1,xmm1,0x44
    7c33ec906450:	movq   rax,xmm0
    7c33ec906455:	add    rax,rax
    7c33ec906458:	je     0x7c33ec90646e
    7c33ec90645a:	shr    rax,0x35
    7c33ec90645e:	sub    eax,0x201
    7c33ec906463:	cmp    eax,0x3fc
    7c33ec906468:	ja     0x7c33ec9080a1
    7c33ec90646e:	movdqa xmm14,xmm0
    7c33ec906473:	psrldq xmm14,0x8
    7c33ec906479:	movq   rax,xmm14
    7c33ec90647e:	add    rax,rax
    7c33ec906481:	je     0x7c33ec906497
    7c33ec906483:	shr    rax,0x35
    7c33ec906487:	sub    eax,0x201
    7c33ec90648c:	cmp    eax,0x3fc
    7c33ec906491:	ja     0x7c33ec9080a1
    7c33ec906497:	movq   rax,xmm1
    7c33ec90649c:	add    rax,rax
    7c33ec90649f:	je     0x7c33ec9064b5
    7c33ec9064a1:	shr    rax,0x35
    7c33ec9064a5:	sub    eax,0x201
    7c33ec9064aa:	cmp    eax,0x3fc
    7c33ec9064af:	ja     0x7c33ec9080a1
    7c33ec9064b5:	movdqa xmm14,xmm1
    7c33ec9064ba:	psrldq xmm14,0x8
    7c33ec9064c0:	movq   rax,xmm14
    7c33ec9064c5:	add    rax,rax
    7c33ec9064c8:	je     0x7c33ec9064de
    7c33ec9064ca:	shr    rax,0x35
    7c33ec9064ce:	sub    eax,0x201
    7c33ec9064d3:	cmp    eax,0x3fc
    7c33ec9064d8:	ja     0x7c33ec9080a1
    7c33ec9064de:	mulpd  xmm0,xmm1
    7c33ec9064e2:	movdqa xmm4,xmm0
    7c33ec9064e6:	movdqa xmm0,xmm4
    7c33ec9064ea:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c33ec9064f4:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    7c33ec9064fe:	movdqa xmm2,xmm0
    7c33ec906502:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec90650c:	movdqa xmm3,xmm0
    7c33ec906510:	movdqa xmm0,xmm2
    7c33ec906514:	movdqa xmm1,xmm3
    7c33ec906518:	pshufd xmm1,xmm1,0x44
    7c33ec90651d:	movq   rax,xmm0
    7c33ec906522:	add    rax,rax
    7c33ec906525:	je     0x7c33ec90653b
    7c33ec906527:	shr    rax,0x35
    7c33ec90652b:	sub    eax,0x201
    7c33ec906530:	cmp    eax,0x3fc
    7c33ec906535:	ja     0x7c33ec9080c5
    7c33ec90653b:	movdqa xmm14,xmm0
    7c33ec906540:	psrldq xmm14,0x8
    7c33ec906546:	movq   rax,xmm14
    7c33ec90654b:	add    rax,rax
    7c33ec90654e:	je     0x7c33ec906564
    7c33ec906550:	shr    rax,0x35
    7c33ec906554:	sub    eax,0x201
    7c33ec906559:	cmp    eax,0x3fc
    7c33ec90655e:	ja     0x7c33ec9080c5
    7c33ec906564:	movq   rax,xmm1
    7c33ec906569:	add    rax,rax
    7c33ec90656c:	je     0x7c33ec906582
    7c33ec90656e:	shr    rax,0x35
    7c33ec906572:	sub    eax,0x201
    7c33ec906577:	cmp    eax,0x3fc
    7c33ec90657c:	ja     0x7c33ec9080c5
    7c33ec906582:	movdqa xmm14,xmm1
    7c33ec906587:	psrldq xmm14,0x8
    7c33ec90658d:	movq   rax,xmm14
    7c33ec906592:	add    rax,rax
    7c33ec906595:	je     0x7c33ec9065ab
    7c33ec906597:	shr    rax,0x35
    7c33ec90659b:	sub    eax,0x201
    7c33ec9065a0:	cmp    eax,0x3fc
    7c33ec9065a5:	ja     0x7c33ec9080c5
    7c33ec9065ab:	mulpd  xmm0,xmm1
    7c33ec9065af:	movdqa xmm4,xmm0
    7c33ec9065b3:	movdqa xmm0,xmm4
    7c33ec9065b7:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c33ec9065c1:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    7c33ec9065cb:	movdqa xmm2,xmm0
    7c33ec9065cf:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec9065d9:	movdqa xmm3,xmm0
    7c33ec9065dd:	movdqa xmm0,xmm2
    7c33ec9065e1:	movdqa xmm1,xmm3
    7c33ec9065e5:	pshufd xmm1,xmm1,0x44
    7c33ec9065ea:	movq   rax,xmm0
    7c33ec9065ef:	add    rax,rax
    7c33ec9065f2:	je     0x7c33ec906608
    7c33ec9065f4:	shr    rax,0x35
    7c33ec9065f8:	sub    eax,0x201
    7c33ec9065fd:	cmp    eax,0x3fc
    7c33ec906602:	ja     0x7c33ec9080e9
    7c33ec906608:	movdqa xmm14,xmm0
    7c33ec90660d:	psrldq xmm14,0x8
    7c33ec906613:	movq   rax,xmm14
    7c33ec906618:	add    rax,rax
    7c33ec90661b:	je     0x7c33ec906631
    7c33ec90661d:	shr    rax,0x35
    7c33ec906621:	sub    eax,0x201
    7c33ec906626:	cmp    eax,0x3fc
    7c33ec90662b:	ja     0x7c33ec9080e9
    7c33ec906631:	movq   rax,xmm1
    7c33ec906636:	add    rax,rax
    7c33ec906639:	je     0x7c33ec90664f
    7c33ec90663b:	shr    rax,0x35
    7c33ec90663f:	sub    eax,0x201
    7c33ec906644:	cmp    eax,0x3fc
    7c33ec906649:	ja     0x7c33ec9080e9
    7c33ec90664f:	movdqa xmm14,xmm1
    7c33ec906654:	psrldq xmm14,0x8
    7c33ec90665a:	movq   rax,xmm14
    7c33ec90665f:	add    rax,rax
    7c33ec906662:	je     0x7c33ec906678
    7c33ec906664:	shr    rax,0x35
    7c33ec906668:	sub    eax,0x201
    7c33ec90666d:	cmp    eax,0x3fc
    7c33ec906672:	ja     0x7c33ec9080e9
    7c33ec906678:	mulpd  xmm0,xmm1
    7c33ec90667c:	movdqa xmm4,xmm0
    7c33ec906680:	movdqa xmm0,xmm4
    7c33ec906684:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c33ec90668e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec906698:	movdqa xmm2,xmm0
    7c33ec90669c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec9066a6:	movdqa xmm4,xmm0
    7c33ec9066aa:	movdqa xmm0,xmm2
    7c33ec9066ae:	movdqa xmm1,xmm4
    7c33ec9066b2:	movq   rax,xmm0
    7c33ec9066b7:	add    rax,rax
    7c33ec9066ba:	je     0x7c33ec9066d0
    7c33ec9066bc:	shr    rax,0x35
    7c33ec9066c0:	sub    eax,0x201
    7c33ec9066c5:	cmp    eax,0x3fc
    7c33ec9066ca:	ja     0x7c33ec90810d
    7c33ec9066d0:	movdqa xmm14,xmm0
    7c33ec9066d5:	psrldq xmm14,0x8
    7c33ec9066db:	movq   rax,xmm14
    7c33ec9066e0:	add    rax,rax
    7c33ec9066e3:	je     0x7c33ec9066f9
    7c33ec9066e5:	shr    rax,0x35
    7c33ec9066e9:	sub    eax,0x201
    7c33ec9066ee:	cmp    eax,0x3fc
    7c33ec9066f3:	ja     0x7c33ec90810d
    7c33ec9066f9:	movq   rax,xmm1
    7c33ec9066fe:	add    rax,rax
    7c33ec906701:	je     0x7c33ec906717
    7c33ec906703:	shr    rax,0x35
    7c33ec906707:	sub    eax,0x201
    7c33ec90670c:	cmp    eax,0x3fc
    7c33ec906711:	ja     0x7c33ec90810d
    7c33ec906717:	movdqa xmm14,xmm1
    7c33ec90671c:	psrldq xmm14,0x8
    7c33ec906722:	movq   rax,xmm14
    7c33ec906727:	add    rax,rax
    7c33ec90672a:	je     0x7c33ec906740
    7c33ec90672c:	shr    rax,0x35
    7c33ec906730:	sub    eax,0x201
    7c33ec906735:	cmp    eax,0x3fc
    7c33ec90673a:	ja     0x7c33ec90810d
    7c33ec906740:	addpd  xmm0,xmm1
    7c33ec906744:	movdqa xmm5,xmm0
    7c33ec906748:	movdqa xmm0,xmm5
    7c33ec90674c:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec906756:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec906760:	movdqa xmm2,xmm0
    7c33ec906764:	movdqa xmm0,xmm2
    7c33ec906768:	movdqa xmm1,xmm3
    7c33ec90676c:	pshufd xmm1,xmm1,0x44
    7c33ec906771:	movq   rax,xmm0
    7c33ec906776:	add    rax,rax
    7c33ec906779:	je     0x7c33ec90678f
    7c33ec90677b:	shr    rax,0x35
    7c33ec90677f:	sub    eax,0x201
    7c33ec906784:	cmp    eax,0x3fc
    7c33ec906789:	ja     0x7c33ec908131
    7c33ec90678f:	movdqa xmm14,xmm0
    7c33ec906794:	psrldq xmm14,0x8
    7c33ec90679a:	movq   rax,xmm14
    7c33ec90679f:	add    rax,rax
    7c33ec9067a2:	je     0x7c33ec9067b8
    7c33ec9067a4:	shr    rax,0x35
    7c33ec9067a8:	sub    eax,0x201
    7c33ec9067ad:	cmp    eax,0x3fc
    7c33ec9067b2:	ja     0x7c33ec908131
    7c33ec9067b8:	movq   rax,xmm1
    7c33ec9067bd:	add    rax,rax
    7c33ec9067c0:	je     0x7c33ec9067d6
    7c33ec9067c2:	shr    rax,0x35
    7c33ec9067c6:	sub    eax,0x201
    7c33ec9067cb:	cmp    eax,0x3fc
    7c33ec9067d0:	ja     0x7c33ec908131
    7c33ec9067d6:	movdqa xmm14,xmm1
    7c33ec9067db:	psrldq xmm14,0x8
    7c33ec9067e1:	movq   rax,xmm14
    7c33ec9067e6:	add    rax,rax
    7c33ec9067e9:	je     0x7c33ec9067ff
    7c33ec9067eb:	shr    rax,0x35
    7c33ec9067ef:	sub    eax,0x201
    7c33ec9067f4:	cmp    eax,0x3fc
    7c33ec9067f9:	ja     0x7c33ec908131
    7c33ec9067ff:	mulpd  xmm0,xmm1
    7c33ec906803:	movdqa xmm4,xmm0
    7c33ec906807:	movdqa xmm0,xmm4
    7c33ec90680b:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec906815:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec90681f:	movdqa xmm2,xmm0
    7c33ec906823:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c33ec90682d:	movdqa xmm4,xmm0
    7c33ec906831:	movdqa xmm0,xmm2
    7c33ec906835:	movdqa xmm1,xmm4
    7c33ec906839:	movq   rax,xmm0
    7c33ec90683e:	add    rax,rax
    7c33ec906841:	je     0x7c33ec906857
    7c33ec906843:	shr    rax,0x35
    7c33ec906847:	sub    eax,0x201
    7c33ec90684c:	cmp    eax,0x3fc
    7c33ec906851:	ja     0x7c33ec908155
    7c33ec906857:	movdqa xmm14,xmm0
    7c33ec90685c:	psrldq xmm14,0x8
    7c33ec906862:	movq   rax,xmm14
    7c33ec906867:	add    rax,rax
    7c33ec90686a:	je     0x7c33ec906880
    7c33ec90686c:	shr    rax,0x35
    7c33ec906870:	sub    eax,0x201
    7c33ec906875:	cmp    eax,0x3fc
    7c33ec90687a:	ja     0x7c33ec908155
    7c33ec906880:	movq   rax,xmm1
    7c33ec906885:	add    rax,rax
    7c33ec906888:	je     0x7c33ec90689e
    7c33ec90688a:	shr    rax,0x35
    7c33ec90688e:	sub    eax,0x201
    7c33ec906893:	cmp    eax,0x3fc
    7c33ec906898:	ja     0x7c33ec908155
    7c33ec90689e:	movdqa xmm14,xmm1
    7c33ec9068a3:	psrldq xmm14,0x8
    7c33ec9068a9:	movq   rax,xmm14
    7c33ec9068ae:	add    rax,rax
    7c33ec9068b1:	je     0x7c33ec9068c7
    7c33ec9068b3:	shr    rax,0x35
    7c33ec9068b7:	sub    eax,0x201
    7c33ec9068bc:	cmp    eax,0x3fc
    7c33ec9068c1:	ja     0x7c33ec908155
    7c33ec9068c7:	addpd  xmm0,xmm1
    7c33ec9068cb:	movdqa xmm5,xmm0
    7c33ec9068cf:	movdqa xmm0,xmm5
    7c33ec9068d3:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec9068dd:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    7c33ec9068e7:	movdqa xmm2,xmm0
    7c33ec9068eb:	movdqa xmm0,xmm2
    7c33ec9068ef:	movdqa xmm1,xmm3
    7c33ec9068f3:	pshufd xmm1,xmm1,0x44
    7c33ec9068f8:	movq   rax,xmm0
    7c33ec9068fd:	add    rax,rax
    7c33ec906900:	je     0x7c33ec906916
    7c33ec906902:	shr    rax,0x35
    7c33ec906906:	sub    eax,0x201
    7c33ec90690b:	cmp    eax,0x3fc
    7c33ec906910:	ja     0x7c33ec908179
    7c33ec906916:	movdqa xmm14,xmm0
    7c33ec90691b:	psrldq xmm14,0x8
    7c33ec906921:	movq   rax,xmm14
    7c33ec906926:	add    rax,rax
    7c33ec906929:	je     0x7c33ec90693f
    7c33ec90692b:	shr    rax,0x35
    7c33ec90692f:	sub    eax,0x201
    7c33ec906934:	cmp    eax,0x3fc
    7c33ec906939:	ja     0x7c33ec908179
    7c33ec90693f:	movq   rax,xmm1
    7c33ec906944:	add    rax,rax
    7c33ec906947:	je     0x7c33ec90695d
    7c33ec906949:	shr    rax,0x35
    7c33ec90694d:	sub    eax,0x201
    7c33ec906952:	cmp    eax,0x3fc
    7c33ec906957:	ja     0x7c33ec908179
    7c33ec90695d:	movdqa xmm14,xmm1
    7c33ec906962:	psrldq xmm14,0x8
    7c33ec906968:	movq   rax,xmm14
    7c33ec90696d:	add    rax,rax
    7c33ec906970:	je     0x7c33ec906986
    7c33ec906972:	shr    rax,0x35
    7c33ec906976:	sub    eax,0x201
    7c33ec90697b:	cmp    eax,0x3fc
    7c33ec906980:	ja     0x7c33ec908179
    7c33ec906986:	mulpd  xmm0,xmm1
    7c33ec90698a:	movdqa xmm4,xmm0
    7c33ec90698e:	movdqa xmm0,xmm4
    7c33ec906992:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c33ec90699c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec9069a6:	movdqa xmm2,xmm0
    7c33ec9069aa:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec9069b4:	movdqa xmm3,xmm0
    7c33ec9069b8:	movdqa xmm0,xmm2
    7c33ec9069bc:	movdqa xmm1,xmm3
    7c33ec9069c0:	movq   rax,xmm0
    7c33ec9069c5:	add    rax,rax
    7c33ec9069c8:	je     0x7c33ec9069de
    7c33ec9069ca:	shr    rax,0x35
    7c33ec9069ce:	sub    eax,0x201
    7c33ec9069d3:	cmp    eax,0x3fc
    7c33ec9069d8:	ja     0x7c33ec90819d
    7c33ec9069de:	movdqa xmm14,xmm0
    7c33ec9069e3:	psrldq xmm14,0x8
    7c33ec9069e9:	movq   rax,xmm14
    7c33ec9069ee:	add    rax,rax
    7c33ec9069f1:	je     0x7c33ec906a07
    7c33ec9069f3:	shr    rax,0x35
    7c33ec9069f7:	sub    eax,0x201
    7c33ec9069fc:	cmp    eax,0x3fc
    7c33ec906a01:	ja     0x7c33ec90819d
    7c33ec906a07:	movq   rax,xmm1
    7c33ec906a0c:	add    rax,rax
    7c33ec906a0f:	je     0x7c33ec906a25
    7c33ec906a11:	shr    rax,0x35
    7c33ec906a15:	sub    eax,0x201
    7c33ec906a1a:	cmp    eax,0x3fc
    7c33ec906a1f:	ja     0x7c33ec90819d
    7c33ec906a25:	movdqa xmm14,xmm1
    7c33ec906a2a:	psrldq xmm14,0x8
    7c33ec906a30:	movq   rax,xmm14
    7c33ec906a35:	add    rax,rax
    7c33ec906a38:	je     0x7c33ec906a4e
    7c33ec906a3a:	shr    rax,0x35
    7c33ec906a3e:	sub    eax,0x201
    7c33ec906a43:	cmp    eax,0x3fc
    7c33ec906a48:	ja     0x7c33ec90819d
    7c33ec906a4e:	addpd  xmm0,xmm1
    7c33ec906a52:	movdqa xmm4,xmm0
    7c33ec906a56:	movdqa xmm0,xmm4
    7c33ec906a5a:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c33ec906a64:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    7c33ec906a6e:	movdqa xmm2,xmm0
    7c33ec906a72:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec906a7c:	movdqa xmm3,xmm0
    7c33ec906a80:	movdqa xmm0,xmm2
    7c33ec906a84:	movdqa xmm1,xmm3
    7c33ec906a88:	pshufd xmm1,xmm1,0x44
    7c33ec906a8d:	movq   rax,xmm0
    7c33ec906a92:	add    rax,rax
    7c33ec906a95:	je     0x7c33ec906aab
    7c33ec906a97:	shr    rax,0x35
    7c33ec906a9b:	sub    eax,0x201
    7c33ec906aa0:	cmp    eax,0x3fc
    7c33ec906aa5:	ja     0x7c33ec9081c1
    7c33ec906aab:	movdqa xmm14,xmm0
    7c33ec906ab0:	psrldq xmm14,0x8
    7c33ec906ab6:	movq   rax,xmm14
    7c33ec906abb:	add    rax,rax
    7c33ec906abe:	je     0x7c33ec906ad4
    7c33ec906ac0:	shr    rax,0x35
    7c33ec906ac4:	sub    eax,0x201
    7c33ec906ac9:	cmp    eax,0x3fc
    7c33ec906ace:	ja     0x7c33ec9081c1
    7c33ec906ad4:	movq   rax,xmm1
    7c33ec906ad9:	add    rax,rax
    7c33ec906adc:	je     0x7c33ec906af2
    7c33ec906ade:	shr    rax,0x35
    7c33ec906ae2:	sub    eax,0x201
    7c33ec906ae7:	cmp    eax,0x3fc
    7c33ec906aec:	ja     0x7c33ec9081c1
    7c33ec906af2:	movdqa xmm14,xmm1
    7c33ec906af7:	psrldq xmm14,0x8
    7c33ec906afd:	movq   rax,xmm14
    7c33ec906b02:	add    rax,rax
    7c33ec906b05:	je     0x7c33ec906b1b
    7c33ec906b07:	shr    rax,0x35
    7c33ec906b0b:	sub    eax,0x201
    7c33ec906b10:	cmp    eax,0x3fc
    7c33ec906b15:	ja     0x7c33ec9081c1
    7c33ec906b1b:	mulpd  xmm0,xmm1
    7c33ec906b1f:	movdqa xmm4,xmm0
    7c33ec906b23:	movdqa xmm0,xmm4
    7c33ec906b27:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec906b31:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec906b3b:	movdqa xmm2,xmm0
    7c33ec906b3f:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec906b49:	movdqa xmm3,xmm0
    7c33ec906b4d:	movdqa xmm0,xmm2
    7c33ec906b51:	movdqa xmm1,xmm3
    7c33ec906b55:	movq   rax,xmm0
    7c33ec906b5a:	add    rax,rax
    7c33ec906b5d:	je     0x7c33ec906b73
    7c33ec906b5f:	shr    rax,0x35
    7c33ec906b63:	sub    eax,0x201
    7c33ec906b68:	cmp    eax,0x3fc
    7c33ec906b6d:	ja     0x7c33ec9081e5
    7c33ec906b73:	movdqa xmm14,xmm0
    7c33ec906b78:	psrldq xmm14,0x8
    7c33ec906b7e:	movq   rax,xmm14
    7c33ec906b83:	add    rax,rax
    7c33ec906b86:	je     0x7c33ec906b9c
    7c33ec906b88:	shr    rax,0x35
    7c33ec906b8c:	sub    eax,0x201
    7c33ec906b91:	cmp    eax,0x3fc
    7c33ec906b96:	ja     0x7c33ec9081e5
    7c33ec906b9c:	movq   rax,xmm1
    7c33ec906ba1:	add    rax,rax
    7c33ec906ba4:	je     0x7c33ec906bba
    7c33ec906ba6:	shr    rax,0x35
    7c33ec906baa:	sub    eax,0x201
    7c33ec906baf:	cmp    eax,0x3fc
    7c33ec906bb4:	ja     0x7c33ec9081e5
    7c33ec906bba:	movdqa xmm14,xmm1
    7c33ec906bbf:	psrldq xmm14,0x8
    7c33ec906bc5:	movq   rax,xmm14
    7c33ec906bca:	add    rax,rax
    7c33ec906bcd:	je     0x7c33ec906be3
    7c33ec906bcf:	shr    rax,0x35
    7c33ec906bd3:	sub    eax,0x201
    7c33ec906bd8:	cmp    eax,0x3fc
    7c33ec906bdd:	ja     0x7c33ec9081e5
    7c33ec906be3:	addpd  xmm0,xmm1
    7c33ec906be7:	movdqa xmm4,xmm0
    7c33ec906beb:	movdqa xmm0,xmm4
    7c33ec906bef:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec906bf9:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec906c01:	mov    r14,r13
    7c33ec906c04:	add    r14,0x70
    7c33ec906c08:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec906c10:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec906c18:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec906c20:	shr    r11d,1
    7c33ec906c23:	and    r11d,0x10
    7c33ec906c27:	or     DWORD PTR [r12+0x314],r11d
    7c33ec906c2f:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec906c34:	movdqa xmm0,xmm2
    7c33ec906c38:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c33ec906c42:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec906c4c:	movdqa xmm3,xmm0
    7c33ec906c50:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec906c5a:	movdqa xmm4,xmm0
    7c33ec906c5e:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec906c66:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec906c71:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec906c79:	movdqa xmm0,xmm3
    7c33ec906c7d:	movdqa xmm1,xmm4
    7c33ec906c81:	movq   rax,xmm0
    7c33ec906c86:	add    rax,rax
    7c33ec906c89:	je     0x7c33ec906c9f
    7c33ec906c8b:	shr    rax,0x35
    7c33ec906c8f:	sub    eax,0x201
    7c33ec906c94:	cmp    eax,0x3fc
    7c33ec906c99:	ja     0x7c33ec908209
    7c33ec906c9f:	movdqa xmm14,xmm0
    7c33ec906ca4:	psrldq xmm14,0x8
    7c33ec906caa:	movq   rax,xmm14
    7c33ec906caf:	add    rax,rax
    7c33ec906cb2:	je     0x7c33ec906cc8
    7c33ec906cb4:	shr    rax,0x35
    7c33ec906cb8:	sub    eax,0x201
    7c33ec906cbd:	cmp    eax,0x3fc
    7c33ec906cc2:	ja     0x7c33ec908209
    7c33ec906cc8:	movq   rax,xmm1
    7c33ec906ccd:	add    rax,rax
    7c33ec906cd0:	je     0x7c33ec906ce6
    7c33ec906cd2:	shr    rax,0x35
    7c33ec906cd6:	sub    eax,0x201
    7c33ec906cdb:	cmp    eax,0x3fc
    7c33ec906ce0:	ja     0x7c33ec908209
    7c33ec906ce6:	movdqa xmm14,xmm1
    7c33ec906ceb:	psrldq xmm14,0x8
    7c33ec906cf1:	movq   rax,xmm14
    7c33ec906cf6:	add    rax,rax
    7c33ec906cf9:	je     0x7c33ec906d0f
    7c33ec906cfb:	shr    rax,0x35
    7c33ec906cff:	sub    eax,0x201
    7c33ec906d04:	cmp    eax,0x3fc
    7c33ec906d09:	ja     0x7c33ec908209
    7c33ec906d0f:	addpd  xmm0,xmm1
    7c33ec906d13:	movdqa xmm5,xmm0
    7c33ec906d17:	movdqa xmm0,xmm5
    7c33ec906d1b:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c33ec906d25:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7c33ec906d2f:	movdqa xmm3,xmm0
    7c33ec906d33:	movdqa xmm0,xmm2
    7c33ec906d37:	movdqa xmm1,xmm3
    7c33ec906d3b:	pshufd xmm1,xmm1,0x44
    7c33ec906d40:	movq   rax,xmm0
    7c33ec906d45:	add    rax,rax
    7c33ec906d48:	je     0x7c33ec906d5e
    7c33ec906d4a:	shr    rax,0x35
    7c33ec906d4e:	sub    eax,0x201
    7c33ec906d53:	cmp    eax,0x3fc
    7c33ec906d58:	ja     0x7c33ec90822d
    7c33ec906d5e:	movdqa xmm14,xmm0
    7c33ec906d63:	psrldq xmm14,0x8
    7c33ec906d69:	movq   rax,xmm14
    7c33ec906d6e:	add    rax,rax
    7c33ec906d71:	je     0x7c33ec906d87
    7c33ec906d73:	shr    rax,0x35
    7c33ec906d77:	sub    eax,0x201
    7c33ec906d7c:	cmp    eax,0x3fc
    7c33ec906d81:	ja     0x7c33ec90822d
    7c33ec906d87:	movq   rax,xmm1
    7c33ec906d8c:	add    rax,rax
    7c33ec906d8f:	je     0x7c33ec906da5
    7c33ec906d91:	shr    rax,0x35
    7c33ec906d95:	sub    eax,0x201
    7c33ec906d9a:	cmp    eax,0x3fc
    7c33ec906d9f:	ja     0x7c33ec90822d
    7c33ec906da5:	movdqa xmm14,xmm1
    7c33ec906daa:	psrldq xmm14,0x8
    7c33ec906db0:	movq   rax,xmm14
    7c33ec906db5:	add    rax,rax
    7c33ec906db8:	je     0x7c33ec906dce
    7c33ec906dba:	shr    rax,0x35
    7c33ec906dbe:	sub    eax,0x201
    7c33ec906dc3:	cmp    eax,0x3fc
    7c33ec906dc8:	ja     0x7c33ec90822d
    7c33ec906dce:	mulpd  xmm0,xmm1
    7c33ec906dd2:	movdqa xmm4,xmm0
    7c33ec906dd6:	movdqa xmm0,xmm4
    7c33ec906dda:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c33ec906de4:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7c33ec906dee:	movdqa xmm2,xmm0
    7c33ec906df2:	movdqa xmm0,xmm2
    7c33ec906df6:	movdqa xmm1,xmm3
    7c33ec906dfa:	pshufd xmm1,xmm1,0x44
    7c33ec906dff:	movq   rax,xmm0
    7c33ec906e04:	add    rax,rax
    7c33ec906e07:	je     0x7c33ec906e1d
    7c33ec906e09:	shr    rax,0x35
    7c33ec906e0d:	sub    eax,0x201
    7c33ec906e12:	cmp    eax,0x3fc
    7c33ec906e17:	ja     0x7c33ec908251
    7c33ec906e1d:	movdqa xmm14,xmm0
    7c33ec906e22:	psrldq xmm14,0x8
    7c33ec906e28:	movq   rax,xmm14
    7c33ec906e2d:	add    rax,rax
    7c33ec906e30:	je     0x7c33ec906e46
    7c33ec906e32:	shr    rax,0x35
    7c33ec906e36:	sub    eax,0x201
    7c33ec906e3b:	cmp    eax,0x3fc
    7c33ec906e40:	ja     0x7c33ec908251
    7c33ec906e46:	movq   rax,xmm1
    7c33ec906e4b:	add    rax,rax
    7c33ec906e4e:	je     0x7c33ec906e64
    7c33ec906e50:	shr    rax,0x35
    7c33ec906e54:	sub    eax,0x201
    7c33ec906e59:	cmp    eax,0x3fc
    7c33ec906e5e:	ja     0x7c33ec908251
    7c33ec906e64:	movdqa xmm14,xmm1
    7c33ec906e69:	psrldq xmm14,0x8
    7c33ec906e6f:	movq   rax,xmm14
    7c33ec906e74:	add    rax,rax
    7c33ec906e77:	je     0x7c33ec906e8d
    7c33ec906e79:	shr    rax,0x35
    7c33ec906e7d:	sub    eax,0x201
    7c33ec906e82:	cmp    eax,0x3fc
    7c33ec906e87:	ja     0x7c33ec908251
    7c33ec906e8d:	mulpd  xmm0,xmm1
    7c33ec906e91:	movdqa xmm4,xmm0
    7c33ec906e95:	movdqa xmm0,xmm4
    7c33ec906e99:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec906ea3:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec906ead:	movdqa xmm2,xmm0
    7c33ec906eb1:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec906ebb:	movdqa xmm4,xmm0
    7c33ec906ebf:	movdqa xmm0,xmm2
    7c33ec906ec3:	movdqa xmm1,xmm4
    7c33ec906ec7:	movq   rax,xmm0
    7c33ec906ecc:	add    rax,rax
    7c33ec906ecf:	je     0x7c33ec906ee5
    7c33ec906ed1:	shr    rax,0x35
    7c33ec906ed5:	sub    eax,0x201
    7c33ec906eda:	cmp    eax,0x3fc
    7c33ec906edf:	ja     0x7c33ec908275
    7c33ec906ee5:	movdqa xmm14,xmm0
    7c33ec906eea:	psrldq xmm14,0x8
    7c33ec906ef0:	movq   rax,xmm14
    7c33ec906ef5:	add    rax,rax
    7c33ec906ef8:	je     0x7c33ec906f0e
    7c33ec906efa:	shr    rax,0x35
    7c33ec906efe:	sub    eax,0x201
    7c33ec906f03:	cmp    eax,0x3fc
    7c33ec906f08:	ja     0x7c33ec908275
    7c33ec906f0e:	movq   rax,xmm1
    7c33ec906f13:	add    rax,rax
    7c33ec906f16:	je     0x7c33ec906f2c
    7c33ec906f18:	shr    rax,0x35
    7c33ec906f1c:	sub    eax,0x201
    7c33ec906f21:	cmp    eax,0x3fc
    7c33ec906f26:	ja     0x7c33ec908275
    7c33ec906f2c:	movdqa xmm14,xmm1
    7c33ec906f31:	psrldq xmm14,0x8
    7c33ec906f37:	movq   rax,xmm14
    7c33ec906f3c:	add    rax,rax
    7c33ec906f3f:	je     0x7c33ec906f55
    7c33ec906f41:	shr    rax,0x35
    7c33ec906f45:	sub    eax,0x201
    7c33ec906f4a:	cmp    eax,0x3fc
    7c33ec906f4f:	ja     0x7c33ec908275
    7c33ec906f55:	addpd  xmm0,xmm1
    7c33ec906f59:	movdqa xmm5,xmm0
    7c33ec906f5d:	movdqa xmm0,xmm5
    7c33ec906f61:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec906f6b:	mov    r14,r13
    7c33ec906f6e:	add    r14,0x10
    7c33ec906f72:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec906f7a:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec906f82:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec906f8a:	shr    r11d,1
    7c33ec906f8d:	and    r11d,0x10
    7c33ec906f91:	or     DWORD PTR [r12+0x314],r11d
    7c33ec906f99:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec906f9f:	movdqu xmm4,XMMWORD PTR [r14]
    7c33ec906fa4:	movdqa xmm0,xmm4
    7c33ec906fa8:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c33ec906fb2:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec906fbc:	movdqa xmm5,xmm0
    7c33ec906fc0:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec906fca:	movdqa xmm6,xmm0
    7c33ec906fce:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec906fd6:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec906fe1:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec906fe9:	movdqa xmm0,xmm5
    7c33ec906fed:	movdqa xmm1,xmm6
    7c33ec906ff1:	movq   rax,xmm0
    7c33ec906ff6:	add    rax,rax
    7c33ec906ff9:	je     0x7c33ec90700f
    7c33ec906ffb:	shr    rax,0x35
    7c33ec906fff:	sub    eax,0x201
    7c33ec907004:	cmp    eax,0x3fc
    7c33ec907009:	ja     0x7c33ec908299
    7c33ec90700f:	movdqa xmm14,xmm0
    7c33ec907014:	psrldq xmm14,0x8
    7c33ec90701a:	movq   rax,xmm14
    7c33ec90701f:	add    rax,rax
    7c33ec907022:	je     0x7c33ec907038
    7c33ec907024:	shr    rax,0x35
    7c33ec907028:	sub    eax,0x201
    7c33ec90702d:	cmp    eax,0x3fc
    7c33ec907032:	ja     0x7c33ec908299
    7c33ec907038:	movq   rax,xmm1
    7c33ec90703d:	add    rax,rax
    7c33ec907040:	je     0x7c33ec907056
    7c33ec907042:	shr    rax,0x35
    7c33ec907046:	sub    eax,0x201
    7c33ec90704b:	cmp    eax,0x3fc
    7c33ec907050:	ja     0x7c33ec908299
    7c33ec907056:	movdqa xmm14,xmm1
    7c33ec90705b:	psrldq xmm14,0x8
    7c33ec907061:	movq   rax,xmm14
    7c33ec907066:	add    rax,rax
    7c33ec907069:	je     0x7c33ec90707f
    7c33ec90706b:	shr    rax,0x35
    7c33ec90706f:	sub    eax,0x201
    7c33ec907074:	cmp    eax,0x3fc
    7c33ec907079:	ja     0x7c33ec908299
    7c33ec90707f:	addpd  xmm0,xmm1
    7c33ec907083:	movdqa xmm7,xmm0
    7c33ec907087:	movdqa xmm0,xmm7
    7c33ec90708b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec907095:	movdqa xmm0,xmm4
    7c33ec907099:	movdqa xmm1,xmm3
    7c33ec90709d:	pshufd xmm1,xmm1,0x44
    7c33ec9070a2:	movq   rax,xmm0
    7c33ec9070a7:	add    rax,rax
    7c33ec9070aa:	je     0x7c33ec9070c0
    7c33ec9070ac:	shr    rax,0x35
    7c33ec9070b0:	sub    eax,0x201
    7c33ec9070b5:	cmp    eax,0x3fc
    7c33ec9070ba:	ja     0x7c33ec9082bd
    7c33ec9070c0:	movdqa xmm14,xmm0
    7c33ec9070c5:	psrldq xmm14,0x8
    7c33ec9070cb:	movq   rax,xmm14
    7c33ec9070d0:	add    rax,rax
    7c33ec9070d3:	je     0x7c33ec9070e9
    7c33ec9070d5:	shr    rax,0x35
    7c33ec9070d9:	sub    eax,0x201
    7c33ec9070de:	cmp    eax,0x3fc
    7c33ec9070e3:	ja     0x7c33ec9082bd
    7c33ec9070e9:	movq   rax,xmm1
    7c33ec9070ee:	add    rax,rax
    7c33ec9070f1:	je     0x7c33ec907107
    7c33ec9070f3:	shr    rax,0x35
    7c33ec9070f7:	sub    eax,0x201
    7c33ec9070fc:	cmp    eax,0x3fc
    7c33ec907101:	ja     0x7c33ec9082bd
    7c33ec907107:	movdqa xmm14,xmm1
    7c33ec90710c:	psrldq xmm14,0x8
    7c33ec907112:	movq   rax,xmm14
    7c33ec907117:	add    rax,rax
    7c33ec90711a:	je     0x7c33ec907130
    7c33ec90711c:	shr    rax,0x35
    7c33ec907120:	sub    eax,0x201
    7c33ec907125:	cmp    eax,0x3fc
    7c33ec90712a:	ja     0x7c33ec9082bd
    7c33ec907130:	mulpd  xmm0,xmm1
    7c33ec907134:	movdqa xmm5,xmm0
    7c33ec907138:	movdqa xmm0,xmm5
    7c33ec90713c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec907146:	movdqa xmm0,xmm2
    7c33ec90714a:	movdqa xmm1,xmm3
    7c33ec90714e:	pshufd xmm1,xmm1,0x44
    7c33ec907153:	movq   rax,xmm0
    7c33ec907158:	add    rax,rax
    7c33ec90715b:	je     0x7c33ec907171
    7c33ec90715d:	shr    rax,0x35
    7c33ec907161:	sub    eax,0x201
    7c33ec907166:	cmp    eax,0x3fc
    7c33ec90716b:	ja     0x7c33ec9082e1
    7c33ec907171:	movdqa xmm14,xmm0
    7c33ec907176:	psrldq xmm14,0x8
    7c33ec90717c:	movq   rax,xmm14
    7c33ec907181:	add    rax,rax
    7c33ec907184:	je     0x7c33ec90719a
    7c33ec907186:	shr    rax,0x35
    7c33ec90718a:	sub    eax,0x201
    7c33ec90718f:	cmp    eax,0x3fc
    7c33ec907194:	ja     0x7c33ec9082e1
    7c33ec90719a:	movq   rax,xmm1
    7c33ec90719f:	add    rax,rax
    7c33ec9071a2:	je     0x7c33ec9071b8
    7c33ec9071a4:	shr    rax,0x35
    7c33ec9071a8:	sub    eax,0x201
    7c33ec9071ad:	cmp    eax,0x3fc
    7c33ec9071b2:	ja     0x7c33ec9082e1
    7c33ec9071b8:	movdqa xmm14,xmm1
    7c33ec9071bd:	psrldq xmm14,0x8
    7c33ec9071c3:	movq   rax,xmm14
    7c33ec9071c8:	add    rax,rax
    7c33ec9071cb:	je     0x7c33ec9071e1
    7c33ec9071cd:	shr    rax,0x35
    7c33ec9071d1:	sub    eax,0x201
    7c33ec9071d6:	cmp    eax,0x3fc
    7c33ec9071db:	ja     0x7c33ec9082e1
    7c33ec9071e1:	mulpd  xmm0,xmm1
    7c33ec9071e5:	movdqa xmm4,xmm0
    7c33ec9071e9:	movdqa xmm0,xmm4
    7c33ec9071ed:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec9071f7:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec907201:	movdqa xmm2,xmm0
    7c33ec907205:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec90720f:	movdqa xmm3,xmm0
    7c33ec907213:	movdqa xmm0,xmm2
    7c33ec907217:	movdqa xmm1,xmm3
    7c33ec90721b:	movq   rax,xmm0
    7c33ec907220:	add    rax,rax
    7c33ec907223:	je     0x7c33ec907239
    7c33ec907225:	shr    rax,0x35
    7c33ec907229:	sub    eax,0x201
    7c33ec90722e:	cmp    eax,0x3fc
    7c33ec907233:	ja     0x7c33ec908305
    7c33ec907239:	movdqa xmm14,xmm0
    7c33ec90723e:	psrldq xmm14,0x8
    7c33ec907244:	movq   rax,xmm14
    7c33ec907249:	add    rax,rax
    7c33ec90724c:	je     0x7c33ec907262
    7c33ec90724e:	shr    rax,0x35
    7c33ec907252:	sub    eax,0x201
    7c33ec907257:	cmp    eax,0x3fc
    7c33ec90725c:	ja     0x7c33ec908305
    7c33ec907262:	movq   rax,xmm1
    7c33ec907267:	add    rax,rax
    7c33ec90726a:	je     0x7c33ec907280
    7c33ec90726c:	shr    rax,0x35
    7c33ec907270:	sub    eax,0x201
    7c33ec907275:	cmp    eax,0x3fc
    7c33ec90727a:	ja     0x7c33ec908305
    7c33ec907280:	movdqa xmm14,xmm1
    7c33ec907285:	psrldq xmm14,0x8
    7c33ec90728b:	movq   rax,xmm14
    7c33ec907290:	add    rax,rax
    7c33ec907293:	je     0x7c33ec9072a9
    7c33ec907295:	shr    rax,0x35
    7c33ec907299:	sub    eax,0x201
    7c33ec90729e:	cmp    eax,0x3fc
    7c33ec9072a3:	ja     0x7c33ec908305
    7c33ec9072a9:	addpd  xmm0,xmm1
    7c33ec9072ad:	movdqa xmm4,xmm0
    7c33ec9072b1:	movdqa xmm0,xmm4
    7c33ec9072b5:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c33ec9072bf:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec9072c9:	movdqa xmm2,xmm0
    7c33ec9072cd:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec9072d7:	movdqa xmm3,xmm0
    7c33ec9072db:	movdqa xmm0,xmm2
    7c33ec9072df:	movdqa xmm1,xmm3
    7c33ec9072e3:	movq   rax,xmm0
    7c33ec9072e8:	add    rax,rax
    7c33ec9072eb:	je     0x7c33ec907301
    7c33ec9072ed:	shr    rax,0x35
    7c33ec9072f1:	sub    eax,0x201
    7c33ec9072f6:	cmp    eax,0x3fc
    7c33ec9072fb:	ja     0x7c33ec908329
    7c33ec907301:	movdqa xmm14,xmm0
    7c33ec907306:	psrldq xmm14,0x8
    7c33ec90730c:	movq   rax,xmm14
    7c33ec907311:	add    rax,rax
    7c33ec907314:	je     0x7c33ec90732a
    7c33ec907316:	shr    rax,0x35
    7c33ec90731a:	sub    eax,0x201
    7c33ec90731f:	cmp    eax,0x3fc
    7c33ec907324:	ja     0x7c33ec908329
    7c33ec90732a:	movq   rax,xmm1
    7c33ec90732f:	add    rax,rax
    7c33ec907332:	je     0x7c33ec907348
    7c33ec907334:	shr    rax,0x35
    7c33ec907338:	sub    eax,0x201
    7c33ec90733d:	cmp    eax,0x3fc
    7c33ec907342:	ja     0x7c33ec908329
    7c33ec907348:	movdqa xmm14,xmm1
    7c33ec90734d:	psrldq xmm14,0x8
    7c33ec907353:	movq   rax,xmm14
    7c33ec907358:	add    rax,rax
    7c33ec90735b:	je     0x7c33ec907371
    7c33ec90735d:	shr    rax,0x35
    7c33ec907361:	sub    eax,0x201
    7c33ec907366:	cmp    eax,0x3fc
    7c33ec90736b:	ja     0x7c33ec908329
    7c33ec907371:	addpd  xmm0,xmm1
    7c33ec907375:	movdqa xmm4,xmm0
    7c33ec907379:	movdqa xmm0,xmm4
    7c33ec90737d:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec907387:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec907391:	movdqa xmm2,xmm0
    7c33ec907395:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec90739f:	movdqa xmm3,xmm0
    7c33ec9073a3:	movdqa xmm0,xmm2
    7c33ec9073a7:	movdqa xmm1,xmm3
    7c33ec9073ab:	movq   rax,xmm0
    7c33ec9073b0:	add    rax,rax
    7c33ec9073b3:	je     0x7c33ec9073c9
    7c33ec9073b5:	shr    rax,0x35
    7c33ec9073b9:	sub    eax,0x201
    7c33ec9073be:	cmp    eax,0x3fc
    7c33ec9073c3:	ja     0x7c33ec90834d
    7c33ec9073c9:	movdqa xmm14,xmm0
    7c33ec9073ce:	psrldq xmm14,0x8
    7c33ec9073d4:	movq   rax,xmm14
    7c33ec9073d9:	add    rax,rax
    7c33ec9073dc:	je     0x7c33ec9073f2
    7c33ec9073de:	shr    rax,0x35
    7c33ec9073e2:	sub    eax,0x201
    7c33ec9073e7:	cmp    eax,0x3fc
    7c33ec9073ec:	ja     0x7c33ec90834d
    7c33ec9073f2:	movq   rax,xmm1
    7c33ec9073f7:	add    rax,rax
    7c33ec9073fa:	je     0x7c33ec907410
    7c33ec9073fc:	shr    rax,0x35
    7c33ec907400:	sub    eax,0x201
    7c33ec907405:	cmp    eax,0x3fc
    7c33ec90740a:	ja     0x7c33ec90834d
    7c33ec907410:	movdqa xmm14,xmm1
    7c33ec907415:	psrldq xmm14,0x8
    7c33ec90741b:	movq   rax,xmm14
    7c33ec907420:	add    rax,rax
    7c33ec907423:	je     0x7c33ec907439
    7c33ec907425:	shr    rax,0x35
    7c33ec907429:	sub    eax,0x201
    7c33ec90742e:	cmp    eax,0x3fc
    7c33ec907433:	ja     0x7c33ec90834d
    7c33ec907439:	addpd  xmm0,xmm1
    7c33ec90743d:	movdqa xmm4,xmm0
    7c33ec907441:	movdqa xmm0,xmm4
    7c33ec907445:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c33ec90744f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec907459:	movdqa xmm2,xmm0
    7c33ec90745d:	movdqa xmm0,xmm7
    7c33ec907461:	movdqa xmm1,xmm2
    7c33ec907465:	movq   rax,xmm0
    7c33ec90746a:	add    rax,rax
    7c33ec90746d:	je     0x7c33ec907483
    7c33ec90746f:	shr    rax,0x35
    7c33ec907473:	sub    eax,0x201
    7c33ec907478:	cmp    eax,0x3fc
    7c33ec90747d:	ja     0x7c33ec908371
    7c33ec907483:	movdqa xmm14,xmm0
    7c33ec907488:	psrldq xmm14,0x8
    7c33ec90748e:	movq   rax,xmm14
    7c33ec907493:	add    rax,rax
    7c33ec907496:	je     0x7c33ec9074ac
    7c33ec907498:	shr    rax,0x35
    7c33ec90749c:	sub    eax,0x201
    7c33ec9074a1:	cmp    eax,0x3fc
    7c33ec9074a6:	ja     0x7c33ec908371
    7c33ec9074ac:	movq   rax,xmm1
    7c33ec9074b1:	add    rax,rax
    7c33ec9074b4:	je     0x7c33ec9074ca
    7c33ec9074b6:	shr    rax,0x35
    7c33ec9074ba:	sub    eax,0x201
    7c33ec9074bf:	cmp    eax,0x3fc
    7c33ec9074c4:	ja     0x7c33ec908371
    7c33ec9074ca:	movdqa xmm14,xmm1
    7c33ec9074cf:	psrldq xmm14,0x8
    7c33ec9074d5:	movq   rax,xmm14
    7c33ec9074da:	add    rax,rax
    7c33ec9074dd:	je     0x7c33ec9074f3
    7c33ec9074df:	shr    rax,0x35
    7c33ec9074e3:	sub    eax,0x201
    7c33ec9074e8:	cmp    eax,0x3fc
    7c33ec9074ed:	ja     0x7c33ec908371
    7c33ec9074f3:	addpd  xmm0,xmm1
    7c33ec9074f7:	movdqa xmm3,xmm0
    7c33ec9074fb:	movdqa xmm0,xmm3
    7c33ec9074ff:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec907509:	mov    r13,QWORD PTR [r12+0x60]
    7c33ec90750e:	mov    r14,r13
    7c33ec907511:	add    r14,0x10
    7c33ec907515:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec90751f:	movdqa xmm2,xmm0
    7c33ec907523:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec90752d:	movdqa xmm4,xmm0
    7c33ec907531:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec907539:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec907541:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec907549:	shr    r11d,1
    7c33ec90754c:	and    r11d,0x10
    7c33ec907550:	or     DWORD PTR [r12+0x314],r11d
    7c33ec907558:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c33ec90755e:	mov    r15d,0x0
    7c33ec907564:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec90756c:	movdqu XMMWORD PTR [r14],xmm4
    7c33ec907571:	mov    r14d,0x0
    7c33ec907577:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec90757f:	add    r13,0x20
    7c33ec907583:	mov    r14,r13
    7c33ec907586:	add    r14,0x10
    7c33ec90758a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec907594:	movdqa xmm2,xmm0
    7c33ec907598:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c33ec90759e:	mov    r13d,0x0
    7c33ec9075a4:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9075ac:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec9075b1:	mov    r13d,0x0
    7c33ec9075b7:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec9075bf:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec9075c7:	jrcxz  0x7c33ec9075ce
    7c33ec9075c9:	jmp    0x7c33ec909cea
    7c33ec9075ce:	push   QWORD PTR [rsp]
    7c33ec9075d1:	popf
    7c33ec9075d2:	je     0x7c33ec9075dd
    7c33ec9075d8:	jmp    0x7c33ec903a18
    7c33ec9075dd:	mov    r13d,DWORD PTR [r12+0x48]
    7c33ec9075e2:	add    r13d,0x1
    7c33ec9075e6:	mov    QWORD PTR [r12+0x48],r13
    7c33ec9075eb:	sub    r13d,0x1f4
    7c33ec9075f2:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec9075fa:	jrcxz  0x7c33ec907601
    7c33ec9075fc:	jmp    0x7c33ec909d74
    7c33ec907601:	pushf
    7c33ec907602:	pop    r11
    7c33ec907604:	mov    QWORD PTR [rsp],r11
    7c33ec907608:	jne    0x7c33ec903a08
    7c33ec90760e:	jmp    0x7c33ec907613
    7c33ec907613:	mov    r13d,0x430000
    7c33ec907619:	mov    QWORD PTR [r12+0x40],r13
    7c33ec90761e:	mov    r13d,0x0
    7c33ec907624:	mov    QWORD PTR [r12+0x48],r13
    7c33ec907629:	mov    r13d,0x430cc0
    7c33ec90762f:	mov    r14,QWORD PTR [r13+0x0]
    7c33ec907633:	mov    r13d,0x0
    7c33ec907639:	mov    QWORD PTR [r12+0x110],r14
    7c33ec907641:	mov    QWORD PTR [r12+0x118],r13
    7c33ec907649:	jmp    0x7c33ec90764e
    7c33ec90764e:	mov    r13,QWORD PTR [r12+0x48]
    7c33ec907653:	mov    r14,QWORD PTR [r12+0x50]
    7c33ec907658:	mov    rcx,r13
    7c33ec90765b:	add    r14,rcx
    7c33ec90765e:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec907663:	movdqa xmm0,xmm2
    7c33ec907667:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec907671:	add    r13,0x10
    7c33ec907675:	mov    QWORD PTR [r12+0x48],r13
    7c33ec90767a:	sub    r13,0x200
    7c33ec907681:	mov    r13,QWORD PTR [r12+0x128]
    7c33ec907689:	mov    r14d,0x0
    7c33ec90768f:	mov    QWORD PTR [r12+0x130],r13
    7c33ec907697:	mov    QWORD PTR [r12+0x138],r14
    7c33ec90769f:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec9076a9:	movdqa xmm2,xmm0
    7c33ec9076ad:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec9076b7:	movdqa xmm3,xmm0
    7c33ec9076bb:	pushf
    7c33ec9076bc:	pop    r11
    7c33ec9076be:	mov    QWORD PTR [rsp],r11
    7c33ec9076c2:	stmxcsr DWORD PTR [rsp+0x110]
    7c33ec9076ca:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c33ec9076d5:	ldmxcsr DWORD PTR [rsp+0x114]
    7c33ec9076dd:	movdqa xmm0,xmm2
    7c33ec9076e1:	movdqa xmm1,xmm3
    7c33ec9076e5:	movq   rax,xmm0
    7c33ec9076ea:	add    rax,rax
    7c33ec9076ed:	je     0x7c33ec907703
    7c33ec9076ef:	shr    rax,0x35
    7c33ec9076f3:	sub    eax,0x201
    7c33ec9076f8:	cmp    eax,0x3fc
    7c33ec9076fd:	ja     0x7c33ec908395
    7c33ec907703:	movq   rax,xmm1
    7c33ec907708:	add    rax,rax
    7c33ec90770b:	je     0x7c33ec907721
    7c33ec90770d:	shr    rax,0x35
    7c33ec907711:	sub    eax,0x201
    7c33ec907716:	cmp    eax,0x3fc
    7c33ec90771b:	ja     0x7c33ec908395
    7c33ec907721:	movq   xmm0,xmm0
    7c33ec907725:	movq   xmm1,xmm1
    7c33ec907729:	addsd  xmm0,xmm1
    7c33ec90772d:	movdqa xmm4,xmm0
    7c33ec907731:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec90773b:	movdqa xmm2,xmm0
    7c33ec90773f:	movdqa xmm0,xmm4
    7c33ec907743:	movdqa xmm1,xmm2
    7c33ec907747:	movq   rax,xmm0
    7c33ec90774c:	add    rax,rax
    7c33ec90774f:	je     0x7c33ec907765
    7c33ec907751:	shr    rax,0x35
    7c33ec907755:	sub    eax,0x201
    7c33ec90775a:	cmp    eax,0x3fc
    7c33ec90775f:	ja     0x7c33ec9083b9
    7c33ec907765:	movq   rax,xmm1
    7c33ec90776a:	add    rax,rax
    7c33ec90776d:	je     0x7c33ec907783
    7c33ec90776f:	shr    rax,0x35
    7c33ec907773:	sub    eax,0x201
    7c33ec907778:	cmp    eax,0x3fc
    7c33ec90777d:	ja     0x7c33ec9083b9
    7c33ec907783:	movq   xmm0,xmm0
    7c33ec907787:	movq   xmm1,xmm1
    7c33ec90778b:	addsd  xmm0,xmm1
    7c33ec90778f:	movdqa xmm3,xmm0
    7c33ec907793:	movdqa xmm0,xmm3
    7c33ec907797:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec9077a1:	stmxcsr DWORD PTR [rsp+0x114]
    7c33ec9077a9:	ldmxcsr DWORD PTR [rsp+0x110]
    7c33ec9077b1:	mov    r11d,DWORD PTR [rsp+0x114]
    7c33ec9077b9:	shr    r11d,1
    7c33ec9077bc:	and    r11d,0x10
    7c33ec9077c0:	or     DWORD PTR [r12+0x314],r11d
    7c33ec9077c8:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec9077d0:	jrcxz  0x7c33ec9077d7
    7c33ec9077d2:	jmp    0x7c33ec909e06
    7c33ec9077d7:	push   QWORD PTR [rsp]
    7c33ec9077da:	popf
    7c33ec9077db:	jne    0x7c33ec90764e
    7c33ec9077e1:	jmp    0x7c33ec9077e6
    7c33ec9077e6:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9077ee:	mov    r14,r13
    7c33ec9077f1:	add    r14,0x1d0
    7c33ec9077f8:	mov    r15,r14
    7c33ec9077fb:	add    r15,0x8
    7c33ec9077ff:	mov    rbp,QWORD PTR [r14]
    7c33ec907802:	mov    r14,QWORD PTR [r15]
    7c33ec907805:	mov    QWORD PTR [r12+0xa0],rbp
    7c33ec90780d:	mov    QWORD PTR [r12+0x98],r14
    7c33ec907815:	mov    r14,QWORD PTR [r12+0x40]
    7c33ec90781a:	add    r14,0xcc0
    7c33ec907821:	mov    r15,QWORD PTR [r12+0x110]
    7c33ec907829:	mov    QWORD PTR [r14],r15
    7c33ec90782c:	mov    r14d,0x0
    7c33ec907832:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec90783a:	mov    r14,r13
    7c33ec90783d:	add    r14,0x1c0
    7c33ec907844:	mov    r15,r14
    7c33ec907847:	add    r15,0x8
    7c33ec90784b:	mov    rbp,QWORD PTR [r14]
    7c33ec90784e:	mov    r14,QWORD PTR [r15]
    7c33ec907851:	mov    QWORD PTR [r12+0xe8],rbp
    7c33ec907859:	mov    QWORD PTR [r12+0xf0],r14
    7c33ec907861:	add    r13,0x1b0
    7c33ec907868:	mov    r14,r13
    7c33ec90786b:	add    r14,0x8
    7c33ec90786f:	mov    r15,QWORD PTR [r13+0x0]
    7c33ec907873:	mov    r13,QWORD PTR [r14]
    7c33ec907876:	mov    r14d,0x0
    7c33ec90787c:	mov    QWORD PTR [r12+0x1a0],r15
    7c33ec907884:	mov    QWORD PTR [r12+0x1a8],r14
    7c33ec90788c:	mov    r14d,0x0
    7c33ec907892:	mov    QWORD PTR [r12+0x190],r13
    7c33ec90789a:	mov    QWORD PTR [r12+0x198],r14
    7c33ec9078a2:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9078aa:	mov    r14,r13
    7c33ec9078ad:	add    r14,0x1a0
    7c33ec9078b4:	mov    r15,r14
    7c33ec9078b7:	add    r15,0x8
    7c33ec9078bb:	mov    rbp,QWORD PTR [r14]
    7c33ec9078be:	mov    r14,QWORD PTR [r15]
    7c33ec9078c1:	mov    r15d,0x0
    7c33ec9078c7:	mov    QWORD PTR [r12+0x1c0],rbp
    7c33ec9078cf:	mov    QWORD PTR [r12+0x1c8],r15
    7c33ec9078d7:	mov    r15d,0x0
    7c33ec9078dd:	mov    QWORD PTR [r12+0x1b0],r14
    7c33ec9078e5:	mov    QWORD PTR [r12+0x1b8],r15
    7c33ec9078ed:	add    r13,0x190
    7c33ec9078f4:	mov    r14,r13
    7c33ec9078f7:	add    r14,0x8
    7c33ec9078fb:	mov    r15,QWORD PTR [r13+0x0]
    7c33ec9078ff:	mov    r13,QWORD PTR [r14]
    7c33ec907902:	mov    r14d,0x0
    7c33ec907908:	mov    QWORD PTR [r12+0x1e0],r15
    7c33ec907910:	mov    QWORD PTR [r12+0x1e8],r14
    7c33ec907918:	mov    r14d,0x0
    7c33ec90791e:	mov    QWORD PTR [r12+0x1d0],r13
    7c33ec907926:	mov    QWORD PTR [r12+0x1d8],r14
    7c33ec90792e:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec907936:	mov    r14,r13
    7c33ec907939:	add    r14,0x180
    7c33ec907940:	mov    r15,r14
    7c33ec907943:	add    r15,0x8
    7c33ec907947:	mov    rbp,QWORD PTR [r14]
    7c33ec90794a:	mov    r14,QWORD PTR [r15]
    7c33ec90794d:	mov    r15d,0x0
    7c33ec907953:	mov    QWORD PTR [r12+0x200],rbp
    7c33ec90795b:	mov    QWORD PTR [r12+0x208],r15
    7c33ec907963:	mov    r15d,0x0
    7c33ec907969:	mov    QWORD PTR [r12+0x1f0],r14
    7c33ec907971:	mov    QWORD PTR [r12+0x1f8],r15
    7c33ec907979:	add    r13,0x1e0
    7c33ec907980:	mov    QWORD PTR [r12+0xf8],r13
    7c33ec907988:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec907990:	jrcxz  0x7c33ec907997
    7c33ec907992:	jmp    0x7c33ec909e90
    7c33ec907997:	mov    r13,QWORD PTR [r12+0xf0]
    7c33ec90799f:	mov    QWORD PTR [r12+0x100],r13
    7c33ec9079a7:	mov    r11,QWORD PTR [rsp]
    7c33ec9079ab:	mov    QWORD PTR [r12+0x398],r11
    7c33ec9079b3:	mov    rdi,QWORD PTR [r12+0x100]
    7c33ec9079bb:	add    rsp,0x150
    7c33ec9079c2:	movabs r11,0x5585303950a0
    7c33ec9079cc:	jmp    r11
    7c33ec9079cf:	mov    r13d,DWORD PTR [r12+0x98]
    7c33ec9079d7:	mov    r14d,DWORD PTR [r12]
    7c33ec9079db:	mov    ecx,r13d
    7c33ec9079de:	add    r14d,ecx
    7c33ec9079e1:	mov    QWORD PTR [r12],r14
    7c33ec9079e5:	mov    r13d,0x4103f8
    7c33ec9079eb:	mov    QWORD PTR [r12+0xf0],r13
    7c33ec9079f3:	mov    r13d,0x4109a4
    7c33ec9079f9:	mov    QWORD PTR [r12+0x100],r13
    7c33ec907a01:	mov    r11,QWORD PTR [rsp]
    7c33ec907a05:	mov    QWORD PTR [r12+0x398],r11
    7c33ec907a0d:	mov    edi,0x4109a4
    7c33ec907a12:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec907a1a:	add    rsp,0x150
    7c33ec907a21:	nop    DWORD PTR [rax+0x0]
    7c33ec907a28:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec907a30
    7c33ec907a2e:	xchg   ax,ax
    7c33ec907a30:	nop
    7c33ec907a31:	and    DWORD PTR [rax+0x7c33ec],edx
    7c33ec907a37:	add    BYTE PTR [rax+0x7a],al
    7c33ec907a3a:	nop
    7c33ec907a3b:	in     al,dx
    7c33ec907a3c:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec907a40:	movabs r11,0x5585303950a0
    7c33ec907a4a:	jmp    r11
    7c33ec907a4d:	movdqa xmm0,xmm2
    7c33ec907a51:	movdqa xmm1,xmm3
    7c33ec907a55:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907a5e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907a67:	call   0x7c33ec9083e0
    7c33ec907a6c:	jmp    0x7c33ec903213
    7c33ec907a71:	movdqa xmm0,xmm2
    7c33ec907a75:	movdqa xmm1,xmm3
    7c33ec907a79:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907a82:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907a8b:	call   0x7c33ec9083e0
    7c33ec907a90:	jmp    0x7c33ec903340
    7c33ec907a95:	movdqa xmm0,xmm3
    7c33ec907a99:	movdqa xmm1,xmm4
    7c33ec907a9d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907aa6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907aaf:	call   0x7c33ec9084c0
    7c33ec907ab4:	jmp    0x7c33ec903ce1
    7c33ec907ab9:	movdqa xmm0,xmm2
    7c33ec907abd:	movdqa xmm1,xmm4
    7c33ec907ac1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907aca:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907ad3:	call   0x7c33ec908650
    7c33ec907ad8:	jmp    0x7c33ec903da0
    7c33ec907add:	movdqa xmm0,xmm3
    7c33ec907ae1:	movdqa xmm1,xmm2
    7c33ec907ae5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907aee:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907af7:	call   0x7c33ec9087e0
    7c33ec907afc:	jmp    0x7c33ec903e76
    7c33ec907b01:	movdqa xmm0,xmm3
    7c33ec907b05:	movdqa xmm1,xmm2
    7c33ec907b09:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907b12:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907b1b:	call   0x7c33ec9087e0
    7c33ec907b20:	jmp    0x7c33ec903f30
    7c33ec907b25:	movdqa xmm0,xmm2
    7c33ec907b29:	movdqa xmm1,xmm3
    7c33ec907b2d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907b36:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907b3f:	call   0x7c33ec9087e0
    7c33ec907b44:	jmp    0x7c33ec903ff8
    7c33ec907b49:	movdqa xmm0,xmm2
    7c33ec907b4d:	movdqa xmm1,xmm3
    7c33ec907b51:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907b5a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907b63:	call   0x7c33ec908960
    7c33ec907b68:	jmp    0x7c33ec904103
    7c33ec907b6d:	movdqa xmm0,xmm2
    7c33ec907b71:	movdqa xmm1,xmm3
    7c33ec907b75:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907b7e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907b87:	call   0x7c33ec908ae0
    7c33ec907b8c:	jmp    0x7c33ec904220
    7c33ec907b91:	movdqa xmm0,xmm2
    7c33ec907b95:	movdqa xmm1,xmm3
    7c33ec907b99:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907ba2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907bab:	call   0x7c33ec908ae0
    7c33ec907bb0:	jmp    0x7c33ec9042e8
    7c33ec907bb5:	movdqa xmm0,xmm2
    7c33ec907bb9:	movdqa xmm1,xmm3
    7c33ec907bbd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907bc6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907bcf:	call   0x7c33ec908ae0
    7c33ec907bd4:	jmp    0x7c33ec9043a2
    7c33ec907bd9:	movdqa xmm0,xmm2
    7c33ec907bdd:	movdqa xmm1,xmm4
    7c33ec907be1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907bea:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907bf3:	call   0x7c33ec908c60
    7c33ec907bf8:	jmp    0x7c33ec9045e7
    7c33ec907bfd:	movdqa xmm0,xmm4
    7c33ec907c01:	movdqa xmm1,xmm5
    7c33ec907c05:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907c0e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907c17:	call   0x7c33ec908df0
    7c33ec907c1c:	jmp    0x7c33ec90470c
    7c33ec907c21:	movdqa xmm0,xmm4
    7c33ec907c25:	movdqa xmm1,xmm5
    7c33ec907c29:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907c32:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907c3b:	call   0x7c33ec908df0
    7c33ec907c40:	jmp    0x7c33ec9047d4
    7c33ec907c45:	movdqa xmm0,xmm3
    7c33ec907c49:	movdqa xmm1,xmm4
    7c33ec907c4d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907c56:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907c5f:	call   0x7c33ec908650
    7c33ec907c64:	jmp    0x7c33ec904893
    7c33ec907c69:	movdqa xmm0,xmm2
    7c33ec907c6d:	movdqa xmm1,xmm3
    7c33ec907c71:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907c7a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907c83:	call   0x7c33ec908650
    7c33ec907c88:	jmp    0x7c33ec904952
    7c33ec907c8d:	movdqa xmm0,xmm2
    7c33ec907c91:	movdqa xmm1,xmm4
    7c33ec907c95:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907c9e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907ca7:	call   0x7c33ec908650
    7c33ec907cac:	jmp    0x7c33ec904a78
    7c33ec907cb1:	movdqa xmm0,xmm2
    7c33ec907cb5:	movdqa xmm1,xmm3
    7c33ec907cb9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907cc2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907ccb:	call   0x7c33ec908960
    7c33ec907cd0:	jmp    0x7c33ec904b7f
    7c33ec907cd5:	movdqa xmm0,xmm3
    7c33ec907cd9:	movdqa xmm1,xmm4
    7c33ec907cdd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907ce6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907cef:	call   0x7c33ec908c60
    7c33ec907cf4:	jmp    0x7c33ec904d34
    7c33ec907cf9:	movdqa xmm0,xmm2
    7c33ec907cfd:	movdqa xmm1,xmm3
    7c33ec907d01:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907d0a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907d13:	call   0x7c33ec908960
    7c33ec907d18:	jmp    0x7c33ec904df3
    7c33ec907d1d:	movdqa xmm0,xmm3
    7c33ec907d21:	movdqa xmm1,xmm4
    7c33ec907d25:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907d2e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907d37:	call   0x7c33ec908c60
    7c33ec907d3c:	jmp    0x7c33ec904f20
    7c33ec907d41:	movdqa xmm0,xmm3
    7c33ec907d45:	movdqa xmm1,xmm4
    7c33ec907d49:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907d52:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907d5b:	call   0x7c33ec908c60
    7c33ec907d60:	jmp    0x7c33ec904fe8
    7c33ec907d65:	movdqa xmm0,xmm2
    7c33ec907d69:	movdqa xmm1,xmm3
    7c33ec907d6d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907d76:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907d7f:	call   0x7c33ec908960
    7c33ec907d84:	jmp    0x7c33ec9050cb
    7c33ec907d89:	movdqa xmm0,xmm3
    7c33ec907d8d:	movdqa xmm1,xmm4
    7c33ec907d91:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907d9a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907da3:	call   0x7c33ec908c60
    7c33ec907da8:	jmp    0x7c33ec9051f8
    7c33ec907dad:	movdqa xmm0,xmm3
    7c33ec907db1:	movdqa xmm1,xmm4
    7c33ec907db5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907dbe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907dc7:	call   0x7c33ec908650
    7c33ec907dcc:	jmp    0x7c33ec9052c5
    7c33ec907dd1:	movdqa xmm0,xmm2
    7c33ec907dd5:	movdqa xmm1,xmm4
    7c33ec907dd9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907de2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907deb:	call   0x7c33ec908f80
    7c33ec907df0:	jmp    0x7c33ec905392
    7c33ec907df5:	movdqa xmm0,xmm3
    7c33ec907df9:	movdqa xmm1,xmm4
    7c33ec907dfd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907e06:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907e0f:	call   0x7c33ec908c60
    7c33ec907e14:	jmp    0x7c33ec9054c1
    7c33ec907e19:	movdqa xmm0,xmm2
    7c33ec907e1d:	movdqa xmm1,xmm3
    7c33ec907e21:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907e2a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907e33:	call   0x7c33ec908960
    7c33ec907e38:	jmp    0x7c33ec9055c8
    7c33ec907e3d:	movdqa xmm0,xmm2
    7c33ec907e41:	movdqa xmm1,xmm4
    7c33ec907e45:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907e4e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907e57:	call   0x7c33ec908c60
    7c33ec907e5c:	jmp    0x7c33ec9056ea
    7c33ec907e61:	movdqa xmm0,xmm2
    7c33ec907e65:	movdqa xmm1,xmm3
    7c33ec907e69:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907e72:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907e7b:	call   0x7c33ec908960
    7c33ec907e80:	jmp    0x7c33ec9057a9
    7c33ec907e85:	movdqa xmm0,xmm2
    7c33ec907e89:	movdqa xmm1,xmm3
    7c33ec907e8d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907e96:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907e9f:	call   0x7c33ec908ae0
    7c33ec907ea4:	jmp    0x7c33ec905871
    7c33ec907ea9:	movdqa xmm0,xmm2
    7c33ec907ead:	movdqa xmm1,xmm3
    7c33ec907eb1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907eba:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907ec3:	call   0x7c33ec908960
    7c33ec907ec8:	jmp    0x7c33ec90593e
    7c33ec907ecd:	movdqa xmm0,xmm2
    7c33ec907ed1:	movdqa xmm1,xmm3
    7c33ec907ed5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907ede:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907ee7:	call   0x7c33ec908960
    7c33ec907eec:	jmp    0x7c33ec9059fd
    7c33ec907ef1:	movdqa xmm0,xmm2
    7c33ec907ef5:	movdqa xmm1,xmm4
    7c33ec907ef9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907f02:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907f0b:	call   0x7c33ec908c60
    7c33ec907f10:	jmp    0x7c33ec905ac5
    7c33ec907f15:	movdqa xmm0,xmm2
    7c33ec907f19:	movdqa xmm1,xmm4
    7c33ec907f1d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907f26:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907f2f:	call   0x7c33ec908c60
    7c33ec907f34:	jmp    0x7c33ec905b8d
    7c33ec907f39:	movdqa xmm0,xmm2
    7c33ec907f3d:	movdqa xmm1,xmm3
    7c33ec907f41:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907f4a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907f53:	call   0x7c33ec908960
    7c33ec907f58:	jmp    0x7c33ec905c4c
    7c33ec907f5d:	movdqa xmm0,xmm2
    7c33ec907f61:	movdqa xmm1,xmm3
    7c33ec907f65:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907f6e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907f77:	call   0x7c33ec908960
    7c33ec907f7c:	jmp    0x7c33ec905d0b
    7c33ec907f81:	movdqa xmm0,xmm2
    7c33ec907f85:	movdqa xmm1,xmm3
    7c33ec907f89:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907f92:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907f9b:	call   0x7c33ec908ae0
    7c33ec907fa0:	jmp    0x7c33ec905dd3
    7c33ec907fa5:	movdqa xmm0,xmm2
    7c33ec907fa9:	movdqa xmm1,xmm3
    7c33ec907fad:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907fb6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907fbf:	call   0x7c33ec908ae0
    7c33ec907fc4:	jmp    0x7c33ec905e9b
    7c33ec907fc9:	movdqa xmm0,xmm2
    7c33ec907fcd:	movdqa xmm1,xmm3
    7c33ec907fd1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907fda:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec907fe3:	call   0x7c33ec908960
    7c33ec907fe8:	jmp    0x7c33ec905f68
    7c33ec907fed:	movdqa xmm0,xmm2
    7c33ec907ff1:	movdqa xmm1,xmm3
    7c33ec907ff5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec907ffe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908007:	call   0x7c33ec908ae0
    7c33ec90800c:	jmp    0x7c33ec906030
    7c33ec908011:	movdqa xmm0,xmm2
    7c33ec908015:	movdqa xmm1,xmm3
    7c33ec908019:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec908022:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec90802b:	call   0x7c33ec908ae0
    7c33ec908030:	jmp    0x7c33ec9060f8
    7c33ec908035:	movdqa xmm0,xmm2
    7c33ec908039:	movdqa xmm1,xmm3
    7c33ec90803d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec908046:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec90804f:	call   0x7c33ec908960
    7c33ec908054:	jmp    0x7c33ec906293
    7c33ec908059:	movdqa xmm0,xmm2
    7c33ec90805d:	movdqa xmm1,xmm4
    7c33ec908061:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec90806a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908073:	call   0x7c33ec908c60
    7c33ec908078:	jmp    0x7c33ec90635b
    7c33ec90807d:	movdqa xmm0,xmm2
    7c33ec908081:	movdqa xmm1,xmm4
    7c33ec908085:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec90808e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908097:	call   0x7c33ec908c60
    7c33ec90809c:	jmp    0x7c33ec906423
    7c33ec9080a1:	movdqa xmm0,xmm2
    7c33ec9080a5:	movdqa xmm1,xmm3
    7c33ec9080a9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9080b2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9080bb:	call   0x7c33ec908960
    7c33ec9080c0:	jmp    0x7c33ec9064e2
    7c33ec9080c5:	movdqa xmm0,xmm2
    7c33ec9080c9:	movdqa xmm1,xmm3
    7c33ec9080cd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9080d6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9080df:	call   0x7c33ec908960
    7c33ec9080e4:	jmp    0x7c33ec9065af
    7c33ec9080e9:	movdqa xmm0,xmm2
    7c33ec9080ed:	movdqa xmm1,xmm3
    7c33ec9080f1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9080fa:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908103:	call   0x7c33ec908960
    7c33ec908108:	jmp    0x7c33ec90667c
    7c33ec90810d:	movdqa xmm0,xmm2
    7c33ec908111:	movdqa xmm1,xmm4
    7c33ec908115:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec90811e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908127:	call   0x7c33ec908c60
    7c33ec90812c:	jmp    0x7c33ec906744
    7c33ec908131:	movdqa xmm0,xmm2
    7c33ec908135:	movdqa xmm1,xmm3
    7c33ec908139:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec908142:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec90814b:	call   0x7c33ec908960
    7c33ec908150:	jmp    0x7c33ec906803
    7c33ec908155:	movdqa xmm0,xmm2
    7c33ec908159:	movdqa xmm1,xmm4
    7c33ec90815d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec908166:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec90816f:	call   0x7c33ec908c60
    7c33ec908174:	jmp    0x7c33ec9068cb
    7c33ec908179:	movdqa xmm0,xmm2
    7c33ec90817d:	movdqa xmm1,xmm3
    7c33ec908181:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec90818a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908193:	call   0x7c33ec908960
    7c33ec908198:	jmp    0x7c33ec90698a
    7c33ec90819d:	movdqa xmm0,xmm2
    7c33ec9081a1:	movdqa xmm1,xmm3
    7c33ec9081a5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9081ae:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9081b7:	call   0x7c33ec908ae0
    7c33ec9081bc:	jmp    0x7c33ec906a52
    7c33ec9081c1:	movdqa xmm0,xmm2
    7c33ec9081c5:	movdqa xmm1,xmm3
    7c33ec9081c9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9081d2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9081db:	call   0x7c33ec908960
    7c33ec9081e0:	jmp    0x7c33ec906b1f
    7c33ec9081e5:	movdqa xmm0,xmm2
    7c33ec9081e9:	movdqa xmm1,xmm3
    7c33ec9081ed:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9081f6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9081ff:	call   0x7c33ec908ae0
    7c33ec908204:	jmp    0x7c33ec906be7
    7c33ec908209:	movdqa xmm0,xmm3
    7c33ec90820d:	movdqa xmm1,xmm4
    7c33ec908211:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec90821a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908223:	call   0x7c33ec908c60
    7c33ec908228:	jmp    0x7c33ec906d13
    7c33ec90822d:	movdqa xmm0,xmm2
    7c33ec908231:	movdqa xmm1,xmm3
    7c33ec908235:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec90823e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908247:	call   0x7c33ec908960
    7c33ec90824c:	jmp    0x7c33ec906dd2
    7c33ec908251:	movdqa xmm0,xmm2
    7c33ec908255:	movdqa xmm1,xmm3
    7c33ec908259:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec908262:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec90826b:	call   0x7c33ec908960
    7c33ec908270:	jmp    0x7c33ec906e91
    7c33ec908275:	movdqa xmm0,xmm2
    7c33ec908279:	movdqa xmm1,xmm4
    7c33ec90827d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec908286:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec90828f:	call   0x7c33ec908c60
    7c33ec908294:	jmp    0x7c33ec906f59
    7c33ec908299:	movdqa xmm0,xmm5
    7c33ec90829d:	movdqa xmm1,xmm6
    7c33ec9082a1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9082aa:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9082b3:	call   0x7c33ec909100
    7c33ec9082b8:	jmp    0x7c33ec907083
    7c33ec9082bd:	movdqa xmm0,xmm4
    7c33ec9082c1:	movdqa xmm1,xmm3
    7c33ec9082c5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9082ce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9082d7:	call   0x7c33ec9092a0
    7c33ec9082dc:	jmp    0x7c33ec907134
    7c33ec9082e1:	movdqa xmm0,xmm2
    7c33ec9082e5:	movdqa xmm1,xmm3
    7c33ec9082e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9082f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9082fb:	call   0x7c33ec909430
    7c33ec908300:	jmp    0x7c33ec9071e5
    7c33ec908305:	movdqa xmm0,xmm2
    7c33ec908309:	movdqa xmm1,xmm3
    7c33ec90830d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec908316:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec90831f:	call   0x7c33ec9095c0
    7c33ec908324:	jmp    0x7c33ec9072ad
    7c33ec908329:	movdqa xmm0,xmm2
    7c33ec90832d:	movdqa xmm1,xmm3
    7c33ec908331:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec90833a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908343:	call   0x7c33ec9095c0
    7c33ec908348:	jmp    0x7c33ec907375
    7c33ec90834d:	movdqa xmm0,xmm2
    7c33ec908351:	movdqa xmm1,xmm3
    7c33ec908355:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec90835e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec908367:	call   0x7c33ec9095c0
    7c33ec90836c:	jmp    0x7c33ec90743d
    7c33ec908371:	movdqa xmm0,xmm7
    7c33ec908375:	movdqa xmm1,xmm2
    7c33ec908379:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec908382:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec90838b:	call   0x7c33ec909750
    7c33ec908390:	jmp    0x7c33ec9074f7
    7c33ec908395:	movdqa xmm0,xmm2
    7c33ec908399:	movdqa xmm1,xmm3
    7c33ec90839d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9083a6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9083af:	call   0x7c33ec9098d0
    7c33ec9083b4:	jmp    0x7c33ec90772d
    7c33ec9083b9:	movdqa xmm0,xmm4
    7c33ec9083bd:	movdqa xmm1,xmm2
    7c33ec9083c1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c33ec9083ca:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c33ec9083d3:	call   0x7c33ec909a50
    7c33ec9083d8:	jmp    0x7c33ec90778f
    7c33ec9083dd:	nop    DWORD PTR [rax]
    7c33ec9083e0:	sub    rsp,0x8
    7c33ec9083e4:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec9083ec:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec9083f4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec9083fc:	shr    r11d,1
    7c33ec9083ff:	and    r11d,0x10
    7c33ec908403:	or     DWORD PTR [r12+0x314],r11d
    7c33ec90840b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec908417:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec90841d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec908423:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90842b:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec908431:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec908437:	lea    rdi,[rsp+0x110]
    7c33ec90843f:	lea    rsi,[rsp+0xf0]
    7c33ec908447:	lea    rdx,[rsp+0x100]
    7c33ec90844f:	mov    ecx,0x16
    7c33ec908454:	mov    r8d,0x0
    7c33ec90845a:	lea    r9,[r12+0x314]
    7c33ec908462:	movabs r11,0x5585302001b0
    7c33ec90846c:	call   r11
    7c33ec90846f:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec908475:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec90847b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec908481:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec908489:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec908495:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec90849e:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec9084a6:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec9084b1:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec9084b9:	add    rsp,0x8
    7c33ec9084bd:	ret
    7c33ec9084be:	xchg   ax,ax
    7c33ec9084c0:	sub    rsp,0x8
    7c33ec9084c4:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec9084cc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec9084d4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec9084dc:	shr    r11d,1
    7c33ec9084df:	and    r11d,0x10
    7c33ec9084e3:	or     DWORD PTR [r12+0x314],r11d
    7c33ec9084eb:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec9084f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec9084fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec908503:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c33ec908509:	push   rdx
    7c33ec90850a:	push   rsi
    7c33ec90850b:	push   r10
    7c33ec90850d:	push   r11
    7c33ec90850f:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec908514:	mov    r10d,edx
    7c33ec908517:	and    r10d,0xc0
    7c33ec90851e:	shl    r10d,0x18
    7c33ec908522:	mov    r11d,edx
    7c33ec908525:	and    r11d,0x1
    7c33ec908529:	shl    r11d,0x1d
    7c33ec90852d:	or     r10d,r11d
    7c33ec908530:	mov    r11d,edx
    7c33ec908533:	and    r11d,0x800
    7c33ec90853a:	shl    r11d,0x11
    7c33ec90853e:	or     r10d,r11d
    7c33ec908541:	btc    r10,0x1d
    7c33ec908546:	mov    r11d,0xf0000000
    7c33ec90854c:	and    r11,r10
    7c33ec90854f:	movabs rsi,0xffffffff0fffffff
    7c33ec908559:	and    rbx,rsi
    7c33ec90855c:	or     rbx,r11
    7c33ec90855f:	pop    r11
    7c33ec908561:	pop    r10
    7c33ec908563:	pop    rsi
    7c33ec908564:	pop    rdx
    7c33ec908565:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90856d:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec908573:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec908579:	lea    rdi,[rsp+0x110]
    7c33ec908581:	lea    rsi,[rsp+0xf0]
    7c33ec908589:	lea    rdx,[rsp+0x100]
    7c33ec908591:	mov    ecx,0x16
    7c33ec908596:	mov    r8d,0x0
    7c33ec90859c:	lea    r9,[r12+0x314]
    7c33ec9085a4:	movabs r11,0x5585302001b0
    7c33ec9085ae:	call   r11
    7c33ec9085b1:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec9085b7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec9085bd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec9085c3:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c33ec9085c9:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec9085d1:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec9085dd:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec9085e6:	pushf
    7c33ec9085e7:	pop    rdx
    7c33ec9085e8:	and    rdx,0xfffffffffffff73e
    7c33ec9085ef:	mov    rax,rbx
    7c33ec9085f2:	shr    rax,0x18
    7c33ec9085f6:	and    eax,0xc0
    7c33ec9085fb:	or     rdx,rax
    7c33ec9085fe:	mov    rax,rbx
    7c33ec908601:	shr    rax,0x1d
    7c33ec908605:	and    eax,0x1
    7c33ec908608:	xor    eax,0x1
    7c33ec90860b:	or     rdx,rax
    7c33ec90860e:	mov    rax,rbx
    7c33ec908611:	shr    rax,0x11
    7c33ec908615:	and    eax,0x800
    7c33ec90861a:	or     rdx,rax
    7c33ec90861d:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec908622:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec90862a:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec908635:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec90863d:	add    rsp,0x8
    7c33ec908641:	ret
    7c33ec908642:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec908650:	sub    rsp,0x8
    7c33ec908654:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec90865c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec908664:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec90866c:	shr    r11d,1
    7c33ec90866f:	and    r11d,0x10
    7c33ec908673:	or     DWORD PTR [r12+0x314],r11d
    7c33ec90867b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec908687:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec90868d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec908693:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c33ec908699:	push   rdx
    7c33ec90869a:	push   rsi
    7c33ec90869b:	push   r10
    7c33ec90869d:	push   r11
    7c33ec90869f:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec9086a4:	mov    r10d,edx
    7c33ec9086a7:	and    r10d,0xc0
    7c33ec9086ae:	shl    r10d,0x18
    7c33ec9086b2:	mov    r11d,edx
    7c33ec9086b5:	and    r11d,0x1
    7c33ec9086b9:	shl    r11d,0x1d
    7c33ec9086bd:	or     r10d,r11d
    7c33ec9086c0:	mov    r11d,edx
    7c33ec9086c3:	and    r11d,0x800
    7c33ec9086ca:	shl    r11d,0x11
    7c33ec9086ce:	or     r10d,r11d
    7c33ec9086d1:	btc    r10,0x1d
    7c33ec9086d6:	mov    r11d,0xf0000000
    7c33ec9086dc:	and    r11,r10
    7c33ec9086df:	movabs rsi,0xffffffff0fffffff
    7c33ec9086e9:	and    rbx,rsi
    7c33ec9086ec:	or     rbx,r11
    7c33ec9086ef:	pop    r11
    7c33ec9086f1:	pop    r10
    7c33ec9086f3:	pop    rsi
    7c33ec9086f4:	pop    rdx
    7c33ec9086f5:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec9086fd:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec908703:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec908709:	lea    rdi,[rsp+0x110]
    7c33ec908711:	lea    rsi,[rsp+0xf0]
    7c33ec908719:	lea    rdx,[rsp+0x100]
    7c33ec908721:	mov    ecx,0x56
    7c33ec908726:	mov    r8d,0x0
    7c33ec90872c:	lea    r9,[r12+0x314]
    7c33ec908734:	movabs r11,0x5585302001b0
    7c33ec90873e:	call   r11
    7c33ec908741:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec908747:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec90874d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec908753:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c33ec908759:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec908761:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec90876d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec908776:	pushf
    7c33ec908777:	pop    rdx
    7c33ec908778:	and    rdx,0xfffffffffffff73e
    7c33ec90877f:	mov    rax,rbx
    7c33ec908782:	shr    rax,0x18
    7c33ec908786:	and    eax,0xc0
    7c33ec90878b:	or     rdx,rax
    7c33ec90878e:	mov    rax,rbx
    7c33ec908791:	shr    rax,0x1d
    7c33ec908795:	and    eax,0x1
    7c33ec908798:	xor    eax,0x1
    7c33ec90879b:	or     rdx,rax
    7c33ec90879e:	mov    rax,rbx
    7c33ec9087a1:	shr    rax,0x11
    7c33ec9087a5:	and    eax,0x800
    7c33ec9087aa:	or     rdx,rax
    7c33ec9087ad:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec9087b2:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec9087ba:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec9087c5:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec9087cd:	add    rsp,0x8
    7c33ec9087d1:	ret
    7c33ec9087d2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec9087e0:	sub    rsp,0x8
    7c33ec9087e4:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec9087ec:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec9087f4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec9087fc:	shr    r11d,1
    7c33ec9087ff:	and    r11d,0x10
    7c33ec908803:	or     DWORD PTR [r12+0x314],r11d
    7c33ec90880b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec908817:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec90881d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec908823:	push   rdx
    7c33ec908824:	push   rsi
    7c33ec908825:	push   r10
    7c33ec908827:	push   r11
    7c33ec908829:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec90882e:	mov    r10d,edx
    7c33ec908831:	and    r10d,0xc0
    7c33ec908838:	shl    r10d,0x18
    7c33ec90883c:	mov    r11d,edx
    7c33ec90883f:	and    r11d,0x1
    7c33ec908843:	shl    r11d,0x1d
    7c33ec908847:	or     r10d,r11d
    7c33ec90884a:	mov    r11d,edx
    7c33ec90884d:	and    r11d,0x800
    7c33ec908854:	shl    r11d,0x11
    7c33ec908858:	or     r10d,r11d
    7c33ec90885b:	btc    r10,0x1d
    7c33ec908860:	mov    r11d,0xf0000000
    7c33ec908866:	and    r11,r10
    7c33ec908869:	movabs rsi,0xffffffff0fffffff
    7c33ec908873:	and    rbx,rsi
    7c33ec908876:	or     rbx,r11
    7c33ec908879:	pop    r11
    7c33ec90887b:	pop    r10
    7c33ec90887d:	pop    rsi
    7c33ec90887e:	pop    rdx
    7c33ec90887f:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec908887:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec90888d:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec908893:	lea    rdi,[rsp+0x110]
    7c33ec90889b:	lea    rsi,[rsp+0xf0]
    7c33ec9088a3:	lea    rdx,[rsp+0x100]
    7c33ec9088ab:	mov    ecx,0x16
    7c33ec9088b0:	mov    r8d,0x0
    7c33ec9088b6:	lea    r9,[r12+0x314]
    7c33ec9088be:	movabs r11,0x5585302001b0
    7c33ec9088c8:	call   r11
    7c33ec9088cb:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec9088d1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec9088d7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec9088dd:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec9088e5:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec9088f1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec9088fa:	pushf
    7c33ec9088fb:	pop    rdx
    7c33ec9088fc:	and    rdx,0xfffffffffffff73e
    7c33ec908903:	mov    rax,rbx
    7c33ec908906:	shr    rax,0x18
    7c33ec90890a:	and    eax,0xc0
    7c33ec90890f:	or     rdx,rax
    7c33ec908912:	mov    rax,rbx
    7c33ec908915:	shr    rax,0x1d
    7c33ec908919:	and    eax,0x1
    7c33ec90891c:	xor    eax,0x1
    7c33ec90891f:	or     rdx,rax
    7c33ec908922:	mov    rax,rbx
    7c33ec908925:	shr    rax,0x11
    7c33ec908929:	and    eax,0x800
    7c33ec90892e:	or     rdx,rax
    7c33ec908931:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec908936:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec90893e:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec908949:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec908951:	add    rsp,0x8
    7c33ec908955:	ret
    7c33ec908956:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec908960:	sub    rsp,0x8
    7c33ec908964:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec90896c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec908974:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec90897c:	shr    r11d,1
    7c33ec90897f:	and    r11d,0x10
    7c33ec908983:	or     DWORD PTR [r12+0x314],r11d
    7c33ec90898b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec908997:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec90899d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec9089a3:	push   rdx
    7c33ec9089a4:	push   rsi
    7c33ec9089a5:	push   r10
    7c33ec9089a7:	push   r11
    7c33ec9089a9:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec9089ae:	mov    r10d,edx
    7c33ec9089b1:	and    r10d,0xc0
    7c33ec9089b8:	shl    r10d,0x18
    7c33ec9089bc:	mov    r11d,edx
    7c33ec9089bf:	and    r11d,0x1
    7c33ec9089c3:	shl    r11d,0x1d
    7c33ec9089c7:	or     r10d,r11d
    7c33ec9089ca:	mov    r11d,edx
    7c33ec9089cd:	and    r11d,0x800
    7c33ec9089d4:	shl    r11d,0x11
    7c33ec9089d8:	or     r10d,r11d
    7c33ec9089db:	btc    r10,0x1d
    7c33ec9089e0:	mov    r11d,0xf0000000
    7c33ec9089e6:	and    r11,r10
    7c33ec9089e9:	movabs rsi,0xffffffff0fffffff
    7c33ec9089f3:	and    rbx,rsi
    7c33ec9089f6:	or     rbx,r11
    7c33ec9089f9:	pop    r11
    7c33ec9089fb:	pop    r10
    7c33ec9089fd:	pop    rsi
    7c33ec9089fe:	pop    rdx
    7c33ec9089ff:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec908a07:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec908a0d:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec908a13:	lea    rdi,[rsp+0x110]
    7c33ec908a1b:	lea    rsi,[rsp+0xf0]
    7c33ec908a23:	lea    rdx,[rsp+0x100]
    7c33ec908a2b:	mov    ecx,0x56
    7c33ec908a30:	mov    r8d,0x0
    7c33ec908a36:	lea    r9,[r12+0x314]
    7c33ec908a3e:	movabs r11,0x5585302001b0
    7c33ec908a48:	call   r11
    7c33ec908a4b:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec908a51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec908a57:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec908a5d:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec908a65:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec908a71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec908a7a:	pushf
    7c33ec908a7b:	pop    rdx
    7c33ec908a7c:	and    rdx,0xfffffffffffff73e
    7c33ec908a83:	mov    rax,rbx
    7c33ec908a86:	shr    rax,0x18
    7c33ec908a8a:	and    eax,0xc0
    7c33ec908a8f:	or     rdx,rax
    7c33ec908a92:	mov    rax,rbx
    7c33ec908a95:	shr    rax,0x1d
    7c33ec908a99:	and    eax,0x1
    7c33ec908a9c:	xor    eax,0x1
    7c33ec908a9f:	or     rdx,rax
    7c33ec908aa2:	mov    rax,rbx
    7c33ec908aa5:	shr    rax,0x11
    7c33ec908aa9:	and    eax,0x800
    7c33ec908aae:	or     rdx,rax
    7c33ec908ab1:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec908ab6:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec908abe:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec908ac9:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec908ad1:	add    rsp,0x8
    7c33ec908ad5:	ret
    7c33ec908ad6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec908ae0:	sub    rsp,0x8
    7c33ec908ae4:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec908aec:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec908af4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec908afc:	shr    r11d,1
    7c33ec908aff:	and    r11d,0x10
    7c33ec908b03:	or     DWORD PTR [r12+0x314],r11d
    7c33ec908b0b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec908b17:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec908b1d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec908b23:	push   rdx
    7c33ec908b24:	push   rsi
    7c33ec908b25:	push   r10
    7c33ec908b27:	push   r11
    7c33ec908b29:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec908b2e:	mov    r10d,edx
    7c33ec908b31:	and    r10d,0xc0
    7c33ec908b38:	shl    r10d,0x18
    7c33ec908b3c:	mov    r11d,edx
    7c33ec908b3f:	and    r11d,0x1
    7c33ec908b43:	shl    r11d,0x1d
    7c33ec908b47:	or     r10d,r11d
    7c33ec908b4a:	mov    r11d,edx
    7c33ec908b4d:	and    r11d,0x800
    7c33ec908b54:	shl    r11d,0x11
    7c33ec908b58:	or     r10d,r11d
    7c33ec908b5b:	btc    r10,0x1d
    7c33ec908b60:	mov    r11d,0xf0000000
    7c33ec908b66:	and    r11,r10
    7c33ec908b69:	movabs rsi,0xffffffff0fffffff
    7c33ec908b73:	and    rbx,rsi
    7c33ec908b76:	or     rbx,r11
    7c33ec908b79:	pop    r11
    7c33ec908b7b:	pop    r10
    7c33ec908b7d:	pop    rsi
    7c33ec908b7e:	pop    rdx
    7c33ec908b7f:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec908b87:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec908b8d:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec908b93:	lea    rdi,[rsp+0x110]
    7c33ec908b9b:	lea    rsi,[rsp+0xf0]
    7c33ec908ba3:	lea    rdx,[rsp+0x100]
    7c33ec908bab:	mov    ecx,0x14
    7c33ec908bb0:	mov    r8d,0x0
    7c33ec908bb6:	lea    r9,[r12+0x314]
    7c33ec908bbe:	movabs r11,0x5585302001b0
    7c33ec908bc8:	call   r11
    7c33ec908bcb:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec908bd1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec908bd7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec908bdd:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec908be5:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec908bf1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec908bfa:	pushf
    7c33ec908bfb:	pop    rdx
    7c33ec908bfc:	and    rdx,0xfffffffffffff73e
    7c33ec908c03:	mov    rax,rbx
    7c33ec908c06:	shr    rax,0x18
    7c33ec908c0a:	and    eax,0xc0
    7c33ec908c0f:	or     rdx,rax
    7c33ec908c12:	mov    rax,rbx
    7c33ec908c15:	shr    rax,0x1d
    7c33ec908c19:	and    eax,0x1
    7c33ec908c1c:	xor    eax,0x1
    7c33ec908c1f:	or     rdx,rax
    7c33ec908c22:	mov    rax,rbx
    7c33ec908c25:	shr    rax,0x11
    7c33ec908c29:	and    eax,0x800
    7c33ec908c2e:	or     rdx,rax
    7c33ec908c31:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec908c36:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec908c3e:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec908c49:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec908c51:	add    rsp,0x8
    7c33ec908c55:	ret
    7c33ec908c56:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec908c60:	sub    rsp,0x8
    7c33ec908c64:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec908c6c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec908c74:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec908c7c:	shr    r11d,1
    7c33ec908c7f:	and    r11d,0x10
    7c33ec908c83:	or     DWORD PTR [r12+0x314],r11d
    7c33ec908c8b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec908c97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec908c9d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec908ca3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c33ec908ca9:	push   rdx
    7c33ec908caa:	push   rsi
    7c33ec908cab:	push   r10
    7c33ec908cad:	push   r11
    7c33ec908caf:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec908cb4:	mov    r10d,edx
    7c33ec908cb7:	and    r10d,0xc0
    7c33ec908cbe:	shl    r10d,0x18
    7c33ec908cc2:	mov    r11d,edx
    7c33ec908cc5:	and    r11d,0x1
    7c33ec908cc9:	shl    r11d,0x1d
    7c33ec908ccd:	or     r10d,r11d
    7c33ec908cd0:	mov    r11d,edx
    7c33ec908cd3:	and    r11d,0x800
    7c33ec908cda:	shl    r11d,0x11
    7c33ec908cde:	or     r10d,r11d
    7c33ec908ce1:	btc    r10,0x1d
    7c33ec908ce6:	mov    r11d,0xf0000000
    7c33ec908cec:	and    r11,r10
    7c33ec908cef:	movabs rsi,0xffffffff0fffffff
    7c33ec908cf9:	and    rbx,rsi
    7c33ec908cfc:	or     rbx,r11
    7c33ec908cff:	pop    r11
    7c33ec908d01:	pop    r10
    7c33ec908d03:	pop    rsi
    7c33ec908d04:	pop    rdx
    7c33ec908d05:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec908d0d:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec908d13:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec908d19:	lea    rdi,[rsp+0x110]
    7c33ec908d21:	lea    rsi,[rsp+0xf0]
    7c33ec908d29:	lea    rdx,[rsp+0x100]
    7c33ec908d31:	mov    ecx,0x14
    7c33ec908d36:	mov    r8d,0x0
    7c33ec908d3c:	lea    r9,[r12+0x314]
    7c33ec908d44:	movabs r11,0x5585302001b0
    7c33ec908d4e:	call   r11
    7c33ec908d51:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec908d57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec908d5d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec908d63:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c33ec908d69:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec908d71:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec908d7d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec908d86:	pushf
    7c33ec908d87:	pop    rdx
    7c33ec908d88:	and    rdx,0xfffffffffffff73e
    7c33ec908d8f:	mov    rax,rbx
    7c33ec908d92:	shr    rax,0x18
    7c33ec908d96:	and    eax,0xc0
    7c33ec908d9b:	or     rdx,rax
    7c33ec908d9e:	mov    rax,rbx
    7c33ec908da1:	shr    rax,0x1d
    7c33ec908da5:	and    eax,0x1
    7c33ec908da8:	xor    eax,0x1
    7c33ec908dab:	or     rdx,rax
    7c33ec908dae:	mov    rax,rbx
    7c33ec908db1:	shr    rax,0x11
    7c33ec908db5:	and    eax,0x800
    7c33ec908dba:	or     rdx,rax
    7c33ec908dbd:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec908dc2:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec908dca:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec908dd5:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec908ddd:	add    rsp,0x8
    7c33ec908de1:	ret
    7c33ec908de2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec908df0:	sub    rsp,0x8
    7c33ec908df4:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec908dfc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec908e04:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec908e0c:	shr    r11d,1
    7c33ec908e0f:	and    r11d,0x10
    7c33ec908e13:	or     DWORD PTR [r12+0x314],r11d
    7c33ec908e1b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec908e27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec908e2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec908e33:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c33ec908e39:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c33ec908e3f:	push   rdx
    7c33ec908e40:	push   rsi
    7c33ec908e41:	push   r10
    7c33ec908e43:	push   r11
    7c33ec908e45:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec908e4a:	mov    r10d,edx
    7c33ec908e4d:	and    r10d,0xc0
    7c33ec908e54:	shl    r10d,0x18
    7c33ec908e58:	mov    r11d,edx
    7c33ec908e5b:	and    r11d,0x1
    7c33ec908e5f:	shl    r11d,0x1d
    7c33ec908e63:	or     r10d,r11d
    7c33ec908e66:	mov    r11d,edx
    7c33ec908e69:	and    r11d,0x800
    7c33ec908e70:	shl    r11d,0x11
    7c33ec908e74:	or     r10d,r11d
    7c33ec908e77:	btc    r10,0x1d
    7c33ec908e7c:	mov    r11d,0xf0000000
    7c33ec908e82:	and    r11,r10
    7c33ec908e85:	movabs rsi,0xffffffff0fffffff
    7c33ec908e8f:	and    rbx,rsi
    7c33ec908e92:	or     rbx,r11
    7c33ec908e95:	pop    r11
    7c33ec908e97:	pop    r10
    7c33ec908e99:	pop    rsi
    7c33ec908e9a:	pop    rdx
    7c33ec908e9b:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec908ea3:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec908ea9:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec908eaf:	lea    rdi,[rsp+0x110]
    7c33ec908eb7:	lea    rsi,[rsp+0xf0]
    7c33ec908ebf:	lea    rdx,[rsp+0x100]
    7c33ec908ec7:	mov    ecx,0x14
    7c33ec908ecc:	mov    r8d,0x0
    7c33ec908ed2:	lea    r9,[r12+0x314]
    7c33ec908eda:	movabs r11,0x5585302001b0
    7c33ec908ee4:	call   r11
    7c33ec908ee7:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec908eed:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec908ef3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec908ef9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c33ec908eff:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c33ec908f05:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec908f0d:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec908f19:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec908f22:	pushf
    7c33ec908f23:	pop    rdx
    7c33ec908f24:	and    rdx,0xfffffffffffff73e
    7c33ec908f2b:	mov    rax,rbx
    7c33ec908f2e:	shr    rax,0x18
    7c33ec908f32:	and    eax,0xc0
    7c33ec908f37:	or     rdx,rax
    7c33ec908f3a:	mov    rax,rbx
    7c33ec908f3d:	shr    rax,0x1d
    7c33ec908f41:	and    eax,0x1
    7c33ec908f44:	xor    eax,0x1
    7c33ec908f47:	or     rdx,rax
    7c33ec908f4a:	mov    rax,rbx
    7c33ec908f4d:	shr    rax,0x11
    7c33ec908f51:	and    eax,0x800
    7c33ec908f56:	or     rdx,rax
    7c33ec908f59:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec908f5e:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec908f66:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec908f71:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec908f79:	add    rsp,0x8
    7c33ec908f7d:	ret
    7c33ec908f7e:	xchg   ax,ax
    7c33ec908f80:	sub    rsp,0x8
    7c33ec908f84:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec908f8c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec908f94:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec908f9c:	shr    r11d,1
    7c33ec908f9f:	and    r11d,0x10
    7c33ec908fa3:	or     DWORD PTR [r12+0x314],r11d
    7c33ec908fab:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec908fb7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec908fbd:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c33ec908fc3:	push   rdx
    7c33ec908fc4:	push   rsi
    7c33ec908fc5:	push   r10
    7c33ec908fc7:	push   r11
    7c33ec908fc9:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec908fce:	mov    r10d,edx
    7c33ec908fd1:	and    r10d,0xc0
    7c33ec908fd8:	shl    r10d,0x18
    7c33ec908fdc:	mov    r11d,edx
    7c33ec908fdf:	and    r11d,0x1
    7c33ec908fe3:	shl    r11d,0x1d
    7c33ec908fe7:	or     r10d,r11d
    7c33ec908fea:	mov    r11d,edx
    7c33ec908fed:	and    r11d,0x800
    7c33ec908ff4:	shl    r11d,0x11
    7c33ec908ff8:	or     r10d,r11d
    7c33ec908ffb:	btc    r10,0x1d
    7c33ec909000:	mov    r11d,0xf0000000
    7c33ec909006:	and    r11,r10
    7c33ec909009:	movabs rsi,0xffffffff0fffffff
    7c33ec909013:	and    rbx,rsi
    7c33ec909016:	or     rbx,r11
    7c33ec909019:	pop    r11
    7c33ec90901b:	pop    r10
    7c33ec90901d:	pop    rsi
    7c33ec90901e:	pop    rdx
    7c33ec90901f:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909027:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec90902d:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec909033:	lea    rdi,[rsp+0x110]
    7c33ec90903b:	lea    rsi,[rsp+0xf0]
    7c33ec909043:	lea    rdx,[rsp+0x100]
    7c33ec90904b:	mov    ecx,0x56
    7c33ec909050:	mov    r8d,0x0
    7c33ec909056:	lea    r9,[r12+0x314]
    7c33ec90905e:	movabs r11,0x5585302001b0
    7c33ec909068:	call   r11
    7c33ec90906b:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec909071:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec909077:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c33ec90907d:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec909085:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec909091:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec90909a:	pushf
    7c33ec90909b:	pop    rdx
    7c33ec90909c:	and    rdx,0xfffffffffffff73e
    7c33ec9090a3:	mov    rax,rbx
    7c33ec9090a6:	shr    rax,0x18
    7c33ec9090aa:	and    eax,0xc0
    7c33ec9090af:	or     rdx,rax
    7c33ec9090b2:	mov    rax,rbx
    7c33ec9090b5:	shr    rax,0x1d
    7c33ec9090b9:	and    eax,0x1
    7c33ec9090bc:	xor    eax,0x1
    7c33ec9090bf:	or     rdx,rax
    7c33ec9090c2:	mov    rax,rbx
    7c33ec9090c5:	shr    rax,0x11
    7c33ec9090c9:	and    eax,0x800
    7c33ec9090ce:	or     rdx,rax
    7c33ec9090d1:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec9090d6:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec9090de:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec9090e9:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec9090f1:	add    rsp,0x8
    7c33ec9090f5:	ret
    7c33ec9090f6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec909100:	sub    rsp,0x8
    7c33ec909104:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec90910c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec909114:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec90911c:	shr    r11d,1
    7c33ec90911f:	and    r11d,0x10
    7c33ec909123:	or     DWORD PTR [r12+0x314],r11d
    7c33ec90912b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec909137:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec90913d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec909143:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c33ec909149:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c33ec90914f:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c33ec909155:	push   rdx
    7c33ec909156:	push   rsi
    7c33ec909157:	push   r10
    7c33ec909159:	push   r11
    7c33ec90915b:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec909160:	mov    r10d,edx
    7c33ec909163:	and    r10d,0xc0
    7c33ec90916a:	shl    r10d,0x18
    7c33ec90916e:	mov    r11d,edx
    7c33ec909171:	and    r11d,0x1
    7c33ec909175:	shl    r11d,0x1d
    7c33ec909179:	or     r10d,r11d
    7c33ec90917c:	mov    r11d,edx
    7c33ec90917f:	and    r11d,0x800
    7c33ec909186:	shl    r11d,0x11
    7c33ec90918a:	or     r10d,r11d
    7c33ec90918d:	btc    r10,0x1d
    7c33ec909192:	mov    r11d,0xf0000000
    7c33ec909198:	and    r11,r10
    7c33ec90919b:	movabs rsi,0xffffffff0fffffff
    7c33ec9091a5:	and    rbx,rsi
    7c33ec9091a8:	or     rbx,r11
    7c33ec9091ab:	pop    r11
    7c33ec9091ad:	pop    r10
    7c33ec9091af:	pop    rsi
    7c33ec9091b0:	pop    rdx
    7c33ec9091b1:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec9091b9:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec9091bf:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec9091c5:	lea    rdi,[rsp+0x110]
    7c33ec9091cd:	lea    rsi,[rsp+0xf0]
    7c33ec9091d5:	lea    rdx,[rsp+0x100]
    7c33ec9091dd:	mov    ecx,0x14
    7c33ec9091e2:	mov    r8d,0x0
    7c33ec9091e8:	lea    r9,[r12+0x314]
    7c33ec9091f0:	movabs r11,0x5585302001b0
    7c33ec9091fa:	call   r11
    7c33ec9091fd:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec909203:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec909209:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec90920f:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c33ec909215:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c33ec90921b:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c33ec909221:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec909229:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec909235:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec90923e:	pushf
    7c33ec90923f:	pop    rdx
    7c33ec909240:	and    rdx,0xfffffffffffff73e
    7c33ec909247:	mov    rax,rbx
    7c33ec90924a:	shr    rax,0x18
    7c33ec90924e:	and    eax,0xc0
    7c33ec909253:	or     rdx,rax
    7c33ec909256:	mov    rax,rbx
    7c33ec909259:	shr    rax,0x1d
    7c33ec90925d:	and    eax,0x1
    7c33ec909260:	xor    eax,0x1
    7c33ec909263:	or     rdx,rax
    7c33ec909266:	mov    rax,rbx
    7c33ec909269:	shr    rax,0x11
    7c33ec90926d:	and    eax,0x800
    7c33ec909272:	or     rdx,rax
    7c33ec909275:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec90927a:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec909282:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec90928d:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec909295:	add    rsp,0x8
    7c33ec909299:	ret
    7c33ec90929a:	nop    WORD PTR [rax+rax*1+0x0]
    7c33ec9092a0:	sub    rsp,0x8
    7c33ec9092a4:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec9092ac:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec9092b4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec9092bc:	shr    r11d,1
    7c33ec9092bf:	and    r11d,0x10
    7c33ec9092c3:	or     DWORD PTR [r12+0x314],r11d
    7c33ec9092cb:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec9092d7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec9092dd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec9092e3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c33ec9092e9:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c33ec9092ef:	push   rdx
    7c33ec9092f0:	push   rsi
    7c33ec9092f1:	push   r10
    7c33ec9092f3:	push   r11
    7c33ec9092f5:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec9092fa:	mov    r10d,edx
    7c33ec9092fd:	and    r10d,0xc0
    7c33ec909304:	shl    r10d,0x18
    7c33ec909308:	mov    r11d,edx
    7c33ec90930b:	and    r11d,0x1
    7c33ec90930f:	shl    r11d,0x1d
    7c33ec909313:	or     r10d,r11d
    7c33ec909316:	mov    r11d,edx
    7c33ec909319:	and    r11d,0x800
    7c33ec909320:	shl    r11d,0x11
    7c33ec909324:	or     r10d,r11d
    7c33ec909327:	btc    r10,0x1d
    7c33ec90932c:	mov    r11d,0xf0000000
    7c33ec909332:	and    r11,r10
    7c33ec909335:	movabs rsi,0xffffffff0fffffff
    7c33ec90933f:	and    rbx,rsi
    7c33ec909342:	or     rbx,r11
    7c33ec909345:	pop    r11
    7c33ec909347:	pop    r10
    7c33ec909349:	pop    rsi
    7c33ec90934a:	pop    rdx
    7c33ec90934b:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909353:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec909359:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec90935f:	lea    rdi,[rsp+0x110]
    7c33ec909367:	lea    rsi,[rsp+0xf0]
    7c33ec90936f:	lea    rdx,[rsp+0x100]
    7c33ec909377:	mov    ecx,0x56
    7c33ec90937c:	mov    r8d,0x0
    7c33ec909382:	lea    r9,[r12+0x314]
    7c33ec90938a:	movabs r11,0x5585302001b0
    7c33ec909394:	call   r11
    7c33ec909397:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec90939d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec9093a3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec9093a9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c33ec9093af:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c33ec9093b5:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec9093bd:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec9093c9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec9093d2:	pushf
    7c33ec9093d3:	pop    rdx
    7c33ec9093d4:	and    rdx,0xfffffffffffff73e
    7c33ec9093db:	mov    rax,rbx
    7c33ec9093de:	shr    rax,0x18
    7c33ec9093e2:	and    eax,0xc0
    7c33ec9093e7:	or     rdx,rax
    7c33ec9093ea:	mov    rax,rbx
    7c33ec9093ed:	shr    rax,0x1d
    7c33ec9093f1:	and    eax,0x1
    7c33ec9093f4:	xor    eax,0x1
    7c33ec9093f7:	or     rdx,rax
    7c33ec9093fa:	mov    rax,rbx
    7c33ec9093fd:	shr    rax,0x11
    7c33ec909401:	and    eax,0x800
    7c33ec909406:	or     rdx,rax
    7c33ec909409:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec90940e:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec909416:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec909421:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec909429:	add    rsp,0x8
    7c33ec90942d:	ret
    7c33ec90942e:	xchg   ax,ax
    7c33ec909430:	sub    rsp,0x8
    7c33ec909434:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec90943c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec909444:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec90944c:	shr    r11d,1
    7c33ec90944f:	and    r11d,0x10
    7c33ec909453:	or     DWORD PTR [r12+0x314],r11d
    7c33ec90945b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec909467:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec90946d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec909473:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c33ec909479:	push   rdx
    7c33ec90947a:	push   rsi
    7c33ec90947b:	push   r10
    7c33ec90947d:	push   r11
    7c33ec90947f:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec909484:	mov    r10d,edx
    7c33ec909487:	and    r10d,0xc0
    7c33ec90948e:	shl    r10d,0x18
    7c33ec909492:	mov    r11d,edx
    7c33ec909495:	and    r11d,0x1
    7c33ec909499:	shl    r11d,0x1d
    7c33ec90949d:	or     r10d,r11d
    7c33ec9094a0:	mov    r11d,edx
    7c33ec9094a3:	and    r11d,0x800
    7c33ec9094aa:	shl    r11d,0x11
    7c33ec9094ae:	or     r10d,r11d
    7c33ec9094b1:	btc    r10,0x1d
    7c33ec9094b6:	mov    r11d,0xf0000000
    7c33ec9094bc:	and    r11,r10
    7c33ec9094bf:	movabs rsi,0xffffffff0fffffff
    7c33ec9094c9:	and    rbx,rsi
    7c33ec9094cc:	or     rbx,r11
    7c33ec9094cf:	pop    r11
    7c33ec9094d1:	pop    r10
    7c33ec9094d3:	pop    rsi
    7c33ec9094d4:	pop    rdx
    7c33ec9094d5:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec9094dd:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec9094e3:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec9094e9:	lea    rdi,[rsp+0x110]
    7c33ec9094f1:	lea    rsi,[rsp+0xf0]
    7c33ec9094f9:	lea    rdx,[rsp+0x100]
    7c33ec909501:	mov    ecx,0x56
    7c33ec909506:	mov    r8d,0x0
    7c33ec90950c:	lea    r9,[r12+0x314]
    7c33ec909514:	movabs r11,0x5585302001b0
    7c33ec90951e:	call   r11
    7c33ec909521:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec909527:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec90952d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec909533:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c33ec909539:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec909541:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec90954d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec909556:	pushf
    7c33ec909557:	pop    rdx
    7c33ec909558:	and    rdx,0xfffffffffffff73e
    7c33ec90955f:	mov    rax,rbx
    7c33ec909562:	shr    rax,0x18
    7c33ec909566:	and    eax,0xc0
    7c33ec90956b:	or     rdx,rax
    7c33ec90956e:	mov    rax,rbx
    7c33ec909571:	shr    rax,0x1d
    7c33ec909575:	and    eax,0x1
    7c33ec909578:	xor    eax,0x1
    7c33ec90957b:	or     rdx,rax
    7c33ec90957e:	mov    rax,rbx
    7c33ec909581:	shr    rax,0x11
    7c33ec909585:	and    eax,0x800
    7c33ec90958a:	or     rdx,rax
    7c33ec90958d:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec909592:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec90959a:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec9095a5:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec9095ad:	add    rsp,0x8
    7c33ec9095b1:	ret
    7c33ec9095b2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec9095c0:	sub    rsp,0x8
    7c33ec9095c4:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec9095cc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec9095d4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec9095dc:	shr    r11d,1
    7c33ec9095df:	and    r11d,0x10
    7c33ec9095e3:	or     DWORD PTR [r12+0x314],r11d
    7c33ec9095eb:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec9095f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec9095fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec909603:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c33ec909609:	push   rdx
    7c33ec90960a:	push   rsi
    7c33ec90960b:	push   r10
    7c33ec90960d:	push   r11
    7c33ec90960f:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec909614:	mov    r10d,edx
    7c33ec909617:	and    r10d,0xc0
    7c33ec90961e:	shl    r10d,0x18
    7c33ec909622:	mov    r11d,edx
    7c33ec909625:	and    r11d,0x1
    7c33ec909629:	shl    r11d,0x1d
    7c33ec90962d:	or     r10d,r11d
    7c33ec909630:	mov    r11d,edx
    7c33ec909633:	and    r11d,0x800
    7c33ec90963a:	shl    r11d,0x11
    7c33ec90963e:	or     r10d,r11d
    7c33ec909641:	btc    r10,0x1d
    7c33ec909646:	mov    r11d,0xf0000000
    7c33ec90964c:	and    r11,r10
    7c33ec90964f:	movabs rsi,0xffffffff0fffffff
    7c33ec909659:	and    rbx,rsi
    7c33ec90965c:	or     rbx,r11
    7c33ec90965f:	pop    r11
    7c33ec909661:	pop    r10
    7c33ec909663:	pop    rsi
    7c33ec909664:	pop    rdx
    7c33ec909665:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90966d:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec909673:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec909679:	lea    rdi,[rsp+0x110]
    7c33ec909681:	lea    rsi,[rsp+0xf0]
    7c33ec909689:	lea    rdx,[rsp+0x100]
    7c33ec909691:	mov    ecx,0x14
    7c33ec909696:	mov    r8d,0x0
    7c33ec90969c:	lea    r9,[r12+0x314]
    7c33ec9096a4:	movabs r11,0x5585302001b0
    7c33ec9096ae:	call   r11
    7c33ec9096b1:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec9096b7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec9096bd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec9096c3:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c33ec9096c9:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec9096d1:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec9096dd:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec9096e6:	pushf
    7c33ec9096e7:	pop    rdx
    7c33ec9096e8:	and    rdx,0xfffffffffffff73e
    7c33ec9096ef:	mov    rax,rbx
    7c33ec9096f2:	shr    rax,0x18
    7c33ec9096f6:	and    eax,0xc0
    7c33ec9096fb:	or     rdx,rax
    7c33ec9096fe:	mov    rax,rbx
    7c33ec909701:	shr    rax,0x1d
    7c33ec909705:	and    eax,0x1
    7c33ec909708:	xor    eax,0x1
    7c33ec90970b:	or     rdx,rax
    7c33ec90970e:	mov    rax,rbx
    7c33ec909711:	shr    rax,0x11
    7c33ec909715:	and    eax,0x800
    7c33ec90971a:	or     rdx,rax
    7c33ec90971d:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec909722:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec90972a:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec909735:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec90973d:	add    rsp,0x8
    7c33ec909741:	ret
    7c33ec909742:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec909750:	sub    rsp,0x8
    7c33ec909754:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec90975c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec909764:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec90976c:	shr    r11d,1
    7c33ec90976f:	and    r11d,0x10
    7c33ec909773:	or     DWORD PTR [r12+0x314],r11d
    7c33ec90977b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec909787:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec90978d:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c33ec909793:	push   rdx
    7c33ec909794:	push   rsi
    7c33ec909795:	push   r10
    7c33ec909797:	push   r11
    7c33ec909799:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec90979e:	mov    r10d,edx
    7c33ec9097a1:	and    r10d,0xc0
    7c33ec9097a8:	shl    r10d,0x18
    7c33ec9097ac:	mov    r11d,edx
    7c33ec9097af:	and    r11d,0x1
    7c33ec9097b3:	shl    r11d,0x1d
    7c33ec9097b7:	or     r10d,r11d
    7c33ec9097ba:	mov    r11d,edx
    7c33ec9097bd:	and    r11d,0x800
    7c33ec9097c4:	shl    r11d,0x11
    7c33ec9097c8:	or     r10d,r11d
    7c33ec9097cb:	btc    r10,0x1d
    7c33ec9097d0:	mov    r11d,0xf0000000
    7c33ec9097d6:	and    r11,r10
    7c33ec9097d9:	movabs rsi,0xffffffff0fffffff
    7c33ec9097e3:	and    rbx,rsi
    7c33ec9097e6:	or     rbx,r11
    7c33ec9097e9:	pop    r11
    7c33ec9097eb:	pop    r10
    7c33ec9097ed:	pop    rsi
    7c33ec9097ee:	pop    rdx
    7c33ec9097ef:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec9097f7:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec9097fd:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec909803:	lea    rdi,[rsp+0x110]
    7c33ec90980b:	lea    rsi,[rsp+0xf0]
    7c33ec909813:	lea    rdx,[rsp+0x100]
    7c33ec90981b:	mov    ecx,0x14
    7c33ec909820:	mov    r8d,0x0
    7c33ec909826:	lea    r9,[r12+0x314]
    7c33ec90982e:	movabs r11,0x5585302001b0
    7c33ec909838:	call   r11
    7c33ec90983b:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec909841:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec909847:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c33ec90984d:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec909855:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec909861:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec90986a:	pushf
    7c33ec90986b:	pop    rdx
    7c33ec90986c:	and    rdx,0xfffffffffffff73e
    7c33ec909873:	mov    rax,rbx
    7c33ec909876:	shr    rax,0x18
    7c33ec90987a:	and    eax,0xc0
    7c33ec90987f:	or     rdx,rax
    7c33ec909882:	mov    rax,rbx
    7c33ec909885:	shr    rax,0x1d
    7c33ec909889:	and    eax,0x1
    7c33ec90988c:	xor    eax,0x1
    7c33ec90988f:	or     rdx,rax
    7c33ec909892:	mov    rax,rbx
    7c33ec909895:	shr    rax,0x11
    7c33ec909899:	and    eax,0x800
    7c33ec90989e:	or     rdx,rax
    7c33ec9098a1:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec9098a6:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec9098ae:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec9098b9:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec9098c1:	add    rsp,0x8
    7c33ec9098c5:	ret
    7c33ec9098c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec9098d0:	sub    rsp,0x8
    7c33ec9098d4:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec9098dc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec9098e4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec9098ec:	shr    r11d,1
    7c33ec9098ef:	and    r11d,0x10
    7c33ec9098f3:	or     DWORD PTR [r12+0x314],r11d
    7c33ec9098fb:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec909907:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec90990d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c33ec909913:	push   rdx
    7c33ec909914:	push   rsi
    7c33ec909915:	push   r10
    7c33ec909917:	push   r11
    7c33ec909919:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec90991e:	mov    r10d,edx
    7c33ec909921:	and    r10d,0xc0
    7c33ec909928:	shl    r10d,0x18
    7c33ec90992c:	mov    r11d,edx
    7c33ec90992f:	and    r11d,0x1
    7c33ec909933:	shl    r11d,0x1d
    7c33ec909937:	or     r10d,r11d
    7c33ec90993a:	mov    r11d,edx
    7c33ec90993d:	and    r11d,0x800
    7c33ec909944:	shl    r11d,0x11
    7c33ec909948:	or     r10d,r11d
    7c33ec90994b:	btc    r10,0x1d
    7c33ec909950:	mov    r11d,0xf0000000
    7c33ec909956:	and    r11,r10
    7c33ec909959:	movabs rsi,0xffffffff0fffffff
    7c33ec909963:	and    rbx,rsi
    7c33ec909966:	or     rbx,r11
    7c33ec909969:	pop    r11
    7c33ec90996b:	pop    r10
    7c33ec90996d:	pop    rsi
    7c33ec90996e:	pop    rdx
    7c33ec90996f:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909977:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec90997d:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec909983:	lea    rdi,[rsp+0x110]
    7c33ec90998b:	lea    rsi,[rsp+0xf0]
    7c33ec909993:	lea    rdx,[rsp+0x100]
    7c33ec90999b:	mov    ecx,0xc
    7c33ec9099a0:	mov    r8d,0x0
    7c33ec9099a6:	lea    r9,[r12+0x314]
    7c33ec9099ae:	movabs r11,0x5585302001b0
    7c33ec9099b8:	call   r11
    7c33ec9099bb:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec9099c1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec9099c7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c33ec9099cd:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec9099d5:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec9099e1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec9099ea:	pushf
    7c33ec9099eb:	pop    rdx
    7c33ec9099ec:	and    rdx,0xfffffffffffff73e
    7c33ec9099f3:	mov    rax,rbx
    7c33ec9099f6:	shr    rax,0x18
    7c33ec9099fa:	and    eax,0xc0
    7c33ec9099ff:	or     rdx,rax
    7c33ec909a02:	mov    rax,rbx
    7c33ec909a05:	shr    rax,0x1d
    7c33ec909a09:	and    eax,0x1
    7c33ec909a0c:	xor    eax,0x1
    7c33ec909a0f:	or     rdx,rax
    7c33ec909a12:	mov    rax,rbx
    7c33ec909a15:	shr    rax,0x11
    7c33ec909a19:	and    eax,0x800
    7c33ec909a1e:	or     rdx,rax
    7c33ec909a21:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec909a26:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec909a2e:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec909a39:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec909a41:	add    rsp,0x8
    7c33ec909a45:	ret
    7c33ec909a46:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec909a50:	sub    rsp,0x8
    7c33ec909a54:	stmxcsr DWORD PTR [rsp+0x124]
    7c33ec909a5c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c33ec909a64:	mov    r11d,DWORD PTR [rsp+0x124]
    7c33ec909a6c:	shr    r11d,1
    7c33ec909a6f:	and    r11d,0x10
    7c33ec909a73:	or     DWORD PTR [r12+0x314],r11d
    7c33ec909a7b:	mov    QWORD PTR [r12+0x378],0x3
    7c33ec909a87:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c33ec909a8d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c33ec909a93:	push   rdx
    7c33ec909a94:	push   rsi
    7c33ec909a95:	push   r10
    7c33ec909a97:	push   r11
    7c33ec909a99:	mov    rdx,QWORD PTR [rsp+0x30]
    7c33ec909a9e:	mov    r10d,edx
    7c33ec909aa1:	and    r10d,0xc0
    7c33ec909aa8:	shl    r10d,0x18
    7c33ec909aac:	mov    r11d,edx
    7c33ec909aaf:	and    r11d,0x1
    7c33ec909ab3:	shl    r11d,0x1d
    7c33ec909ab7:	or     r10d,r11d
    7c33ec909aba:	mov    r11d,edx
    7c33ec909abd:	and    r11d,0x800
    7c33ec909ac4:	shl    r11d,0x11
    7c33ec909ac8:	or     r10d,r11d
    7c33ec909acb:	btc    r10,0x1d
    7c33ec909ad0:	mov    r11d,0xf0000000
    7c33ec909ad6:	and    r11,r10
    7c33ec909ad9:	movabs rsi,0xffffffff0fffffff
    7c33ec909ae3:	and    rbx,rsi
    7c33ec909ae6:	or     rbx,r11
    7c33ec909ae9:	pop    r11
    7c33ec909aeb:	pop    r10
    7c33ec909aed:	pop    rsi
    7c33ec909aee:	pop    rdx
    7c33ec909aef:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909af7:	stmxcsr DWORD PTR [r12-0x28]
    7c33ec909afd:	ldmxcsr DWORD PTR [r12-0x38]
    7c33ec909b03:	lea    rdi,[rsp+0x110]
    7c33ec909b0b:	lea    rsi,[rsp+0xf0]
    7c33ec909b13:	lea    rdx,[rsp+0x100]
    7c33ec909b1b:	mov    ecx,0xc
    7c33ec909b20:	mov    r8d,0x0
    7c33ec909b26:	lea    r9,[r12+0x314]
    7c33ec909b2e:	movabs r11,0x5585302001b0
    7c33ec909b38:	call   r11
    7c33ec909b3b:	ldmxcsr DWORD PTR [r12-0x28]
    7c33ec909b41:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c33ec909b47:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c33ec909b4d:	mov    rbx,QWORD PTR [r12+0x108]
    7c33ec909b55:	mov    QWORD PTR [r12+0x378],0x2
    7c33ec909b61:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c33ec909b6a:	pushf
    7c33ec909b6b:	pop    rdx
    7c33ec909b6c:	and    rdx,0xfffffffffffff73e
    7c33ec909b73:	mov    rax,rbx
    7c33ec909b76:	shr    rax,0x18
    7c33ec909b7a:	and    eax,0xc0
    7c33ec909b7f:	or     rdx,rax
    7c33ec909b82:	mov    rax,rbx
    7c33ec909b85:	shr    rax,0x1d
    7c33ec909b89:	and    eax,0x1
    7c33ec909b8c:	xor    eax,0x1
    7c33ec909b8f:	or     rdx,rax
    7c33ec909b92:	mov    rax,rbx
    7c33ec909b95:	shr    rax,0x11
    7c33ec909b99:	and    eax,0x800
    7c33ec909b9e:	or     rdx,rax
    7c33ec909ba1:	mov    QWORD PTR [rsp+0x10],rdx
    7c33ec909ba6:	stmxcsr DWORD PTR [rsp+0x120]
    7c33ec909bae:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c33ec909bb9:	ldmxcsr DWORD PTR [rsp+0x124]
    7c33ec909bc1:	add    rsp,0x8
    7c33ec909bc5:	ret
    7c33ec909bc6:	mov    eax,0x410400
    7c33ec909bcb:	mov    QWORD PTR [r12+0x100],rax
    7c33ec909bd3:	push   rdx
    7c33ec909bd4:	push   rsi
    7c33ec909bd5:	push   r10
    7c33ec909bd7:	push   r11
    7c33ec909bd9:	pushf
    7c33ec909bda:	pop    r11
    7c33ec909bdc:	mov    QWORD PTR [rsp+0x20],r11
    7c33ec909be1:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec909be6:	mov    r10d,edx
    7c33ec909be9:	and    r10d,0xc0
    7c33ec909bf0:	shl    r10d,0x18
    7c33ec909bf4:	mov    r11d,edx
    7c33ec909bf7:	and    r11d,0x1
    7c33ec909bfb:	shl    r11d,0x1d
    7c33ec909bff:	or     r10d,r11d
    7c33ec909c02:	mov    r11d,edx
    7c33ec909c05:	and    r11d,0x800
    7c33ec909c0c:	shl    r11d,0x11
    7c33ec909c10:	or     r10d,r11d
    7c33ec909c13:	btc    r10,0x1d
    7c33ec909c18:	mov    r11d,0xf0000000
    7c33ec909c1e:	and    r11,r10
    7c33ec909c21:	movabs rsi,0xffffffff0fffffff
    7c33ec909c2b:	and    rbx,rsi
    7c33ec909c2e:	or     rbx,r11
    7c33ec909c31:	pop    r11
    7c33ec909c33:	pop    r10
    7c33ec909c35:	pop    rsi
    7c33ec909c36:	pop    rdx
    7c33ec909c37:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909c3f:	add    rsp,0x150
    7c33ec909c46:	mov    eax,0xc
    7c33ec909c4b:	movabs r11,0x558530395390
    7c33ec909c55:	jmp    r11
    7c33ec909c58:	mov    eax,0x41048c
    7c33ec909c5d:	mov    QWORD PTR [r12+0x100],rax
    7c33ec909c65:	push   rdx
    7c33ec909c66:	push   rsi
    7c33ec909c67:	push   r10
    7c33ec909c69:	push   r11
    7c33ec909c6b:	pushf
    7c33ec909c6c:	pop    r11
    7c33ec909c6e:	mov    QWORD PTR [rsp+0x20],r11
    7c33ec909c73:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec909c78:	mov    r10d,edx
    7c33ec909c7b:	and    r10d,0xc0
    7c33ec909c82:	shl    r10d,0x18
    7c33ec909c86:	mov    r11d,edx
    7c33ec909c89:	and    r11d,0x1
    7c33ec909c8d:	shl    r11d,0x1d
    7c33ec909c91:	or     r10d,r11d
    7c33ec909c94:	mov    r11d,edx
    7c33ec909c97:	and    r11d,0x800
    7c33ec909c9e:	shl    r11d,0x11
    7c33ec909ca2:	or     r10d,r11d
    7c33ec909ca5:	btc    r10,0x1d
    7c33ec909caa:	mov    r11d,0xf0000000
    7c33ec909cb0:	and    r11,r10
    7c33ec909cb3:	movabs rsi,0xffffffff0fffffff
    7c33ec909cbd:	and    rbx,rsi
    7c33ec909cc0:	or     rbx,r11
    7c33ec909cc3:	pop    r11
    7c33ec909cc5:	pop    r10
    7c33ec909cc7:	pop    rsi
    7c33ec909cc8:	pop    rdx
    7c33ec909cc9:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909cd1:	add    rsp,0x150
    7c33ec909cd8:	mov    eax,0xc
    7c33ec909cdd:	movabs r11,0x558530395390
    7c33ec909ce7:	jmp    r11
    7c33ec909cea:	mov    eax,0x4106cc
    7c33ec909cef:	mov    QWORD PTR [r12+0x100],rax
    7c33ec909cf7:	push   rdx
    7c33ec909cf8:	push   rsi
    7c33ec909cf9:	push   r10
    7c33ec909cfb:	push   r11
    7c33ec909cfd:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec909d02:	mov    r10d,edx
    7c33ec909d05:	and    r10d,0xc0
    7c33ec909d0c:	shl    r10d,0x18
    7c33ec909d10:	mov    r11d,edx
    7c33ec909d13:	and    r11d,0x1
    7c33ec909d17:	shl    r11d,0x1d
    7c33ec909d1b:	or     r10d,r11d
    7c33ec909d1e:	mov    r11d,edx
    7c33ec909d21:	and    r11d,0x800
    7c33ec909d28:	shl    r11d,0x11
    7c33ec909d2c:	or     r10d,r11d
    7c33ec909d2f:	btc    r10,0x1d
    7c33ec909d34:	mov    r11d,0xf0000000
    7c33ec909d3a:	and    r11,r10
    7c33ec909d3d:	movabs rsi,0xffffffff0fffffff
    7c33ec909d47:	and    rbx,rsi
    7c33ec909d4a:	or     rbx,r11
    7c33ec909d4d:	pop    r11
    7c33ec909d4f:	pop    r10
    7c33ec909d51:	pop    rsi
    7c33ec909d52:	pop    rdx
    7c33ec909d53:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909d5b:	add    rsp,0x150
    7c33ec909d62:	mov    eax,0xc
    7c33ec909d67:	movabs r11,0x558530395390
    7c33ec909d71:	jmp    r11
    7c33ec909d74:	mov    eax,0x4106d8
    7c33ec909d79:	mov    QWORD PTR [r12+0x100],rax
    7c33ec909d81:	push   rdx
    7c33ec909d82:	push   rsi
    7c33ec909d83:	push   r10
    7c33ec909d85:	push   r11
    7c33ec909d87:	pushf
    7c33ec909d88:	pop    r11
    7c33ec909d8a:	mov    QWORD PTR [rsp+0x20],r11
    7c33ec909d8f:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec909d94:	mov    r10d,edx
    7c33ec909d97:	and    r10d,0xc0
    7c33ec909d9e:	shl    r10d,0x18
    7c33ec909da2:	mov    r11d,edx
    7c33ec909da5:	and    r11d,0x1
    7c33ec909da9:	shl    r11d,0x1d
    7c33ec909dad:	or     r10d,r11d
    7c33ec909db0:	mov    r11d,edx
    7c33ec909db3:	and    r11d,0x800
    7c33ec909dba:	shl    r11d,0x11
    7c33ec909dbe:	or     r10d,r11d
    7c33ec909dc1:	btc    r10,0x1d
    7c33ec909dc6:	mov    r11d,0xf0000000
    7c33ec909dcc:	and    r11,r10
    7c33ec909dcf:	movabs rsi,0xffffffff0fffffff
    7c33ec909dd9:	and    rbx,rsi
    7c33ec909ddc:	or     rbx,r11
    7c33ec909ddf:	pop    r11
    7c33ec909de1:	pop    r10
    7c33ec909de3:	pop    rsi
    7c33ec909de4:	pop    rdx
    7c33ec909de5:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909ded:	add    rsp,0x150
    7c33ec909df4:	mov    eax,0xc
    7c33ec909df9:	movabs r11,0x558530395390
    7c33ec909e03:	jmp    r11
    7c33ec909e06:	mov    eax,0x410700
    7c33ec909e0b:	mov    QWORD PTR [r12+0x100],rax
    7c33ec909e13:	push   rdx
    7c33ec909e14:	push   rsi
    7c33ec909e15:	push   r10
    7c33ec909e17:	push   r11
    7c33ec909e19:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec909e1e:	mov    r10d,edx
    7c33ec909e21:	and    r10d,0xc0
    7c33ec909e28:	shl    r10d,0x18
    7c33ec909e2c:	mov    r11d,edx
    7c33ec909e2f:	and    r11d,0x1
    7c33ec909e33:	shl    r11d,0x1d
    7c33ec909e37:	or     r10d,r11d
    7c33ec909e3a:	mov    r11d,edx
    7c33ec909e3d:	and    r11d,0x800
    7c33ec909e44:	shl    r11d,0x11
    7c33ec909e48:	or     r10d,r11d
    7c33ec909e4b:	btc    r10,0x1d
    7c33ec909e50:	mov    r11d,0xf0000000
    7c33ec909e56:	and    r11,r10
    7c33ec909e59:	movabs rsi,0xffffffff0fffffff
    7c33ec909e63:	and    rbx,rsi
    7c33ec909e66:	or     rbx,r11
    7c33ec909e69:	pop    r11
    7c33ec909e6b:	pop    r10
    7c33ec909e6d:	pop    rsi
    7c33ec909e6e:	pop    rdx
    7c33ec909e6f:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909e77:	add    rsp,0x150
    7c33ec909e7e:	mov    eax,0xc
    7c33ec909e83:	movabs r11,0x558530395390
    7c33ec909e8d:	jmp    r11
    7c33ec909e90:	mov    eax,0x410724
    7c33ec909e95:	mov    QWORD PTR [r12+0x100],rax
    7c33ec909e9d:	push   rdx
    7c33ec909e9e:	push   rsi
    7c33ec909e9f:	push   r10
    7c33ec909ea1:	push   r11
    7c33ec909ea3:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec909ea8:	mov    r10d,edx
    7c33ec909eab:	and    r10d,0xc0
    7c33ec909eb2:	shl    r10d,0x18
    7c33ec909eb6:	mov    r11d,edx
    7c33ec909eb9:	and    r11d,0x1
    7c33ec909ebd:	shl    r11d,0x1d
    7c33ec909ec1:	or     r10d,r11d
    7c33ec909ec4:	mov    r11d,edx
    7c33ec909ec7:	and    r11d,0x800
    7c33ec909ece:	shl    r11d,0x11
    7c33ec909ed2:	or     r10d,r11d
    7c33ec909ed5:	btc    r10,0x1d
    7c33ec909eda:	mov    r11d,0xf0000000
    7c33ec909ee0:	and    r11,r10
    7c33ec909ee3:	movabs rsi,0xffffffff0fffffff
    7c33ec909eed:	and    rbx,rsi
    7c33ec909ef0:	or     rbx,r11
    7c33ec909ef3:	pop    r11
    7c33ec909ef5:	pop    r10
    7c33ec909ef7:	pop    rsi
    7c33ec909ef8:	pop    rdx
    7c33ec909ef9:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909f01:	add    rsp,0x150
    7c33ec909f08:	mov    eax,0xc
    7c33ec909f0d:	movabs r11,0x558530395390
    7c33ec909f17:	jmp    r11
    7c33ec909f1a:	nop    WORD PTR [rax+rax*1+0x0]
    7c33ec909f20:	sub    rsp,0x150
    7c33ec909f27:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec909f2f:	mov    QWORD PTR [rsp],r11
    7c33ec909f33:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec909f3c:	je     0x7c33ec909fcc
    7c33ec909f42:	push   rdx
    7c33ec909f43:	push   rsi
    7c33ec909f44:	push   r10
    7c33ec909f46:	push   r11
    7c33ec909f48:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec909f4d:	mov    r10d,edx
    7c33ec909f50:	and    r10d,0xc0
    7c33ec909f57:	shl    r10d,0x18
    7c33ec909f5b:	mov    r11d,edx
    7c33ec909f5e:	and    r11d,0x1
    7c33ec909f62:	shl    r11d,0x1d
    7c33ec909f66:	or     r10d,r11d
    7c33ec909f69:	mov    r11d,edx
    7c33ec909f6c:	and    r11d,0x800
    7c33ec909f73:	shl    r11d,0x11
    7c33ec909f77:	or     r10d,r11d
    7c33ec909f7a:	btc    r10,0x1d
    7c33ec909f7f:	mov    r11d,0xf0000000
    7c33ec909f85:	and    r11,r10
    7c33ec909f88:	movabs rsi,0xffffffff0fffffff
    7c33ec909f92:	and    rbx,rsi
    7c33ec909f95:	or     rbx,r11
    7c33ec909f98:	pop    r11
    7c33ec909f9a:	pop    r10
    7c33ec909f9c:	pop    rsi
    7c33ec909f9d:	pop    rdx
    7c33ec909f9e:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec909fa6:	mov    eax,0x410404
    7c33ec909fab:	mov    QWORD PTR [r12+0x100],rax
    7c33ec909fb3:	add    rsp,0x150
    7c33ec909fba:	mov    eax,0x3
    7c33ec909fbf:	movabs r11,0x558530395390
    7c33ec909fc9:	jmp    r11
    7c33ec909fcc:	jmp    0x7c33ec902ce8
    7c33ec909fd1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec909fe0:	sub    rsp,0x150
    7c33ec909fe7:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec909fef:	mov    QWORD PTR [rsp],r11
    7c33ec909ff3:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec909ffc:	je     0x7c33ec90a08c
    7c33ec90a002:	push   rdx
    7c33ec90a003:	push   rsi
    7c33ec90a004:	push   r10
    7c33ec90a006:	push   r11
    7c33ec90a008:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90a00d:	mov    r10d,edx
    7c33ec90a010:	and    r10d,0xc0
    7c33ec90a017:	shl    r10d,0x18
    7c33ec90a01b:	mov    r11d,edx
    7c33ec90a01e:	and    r11d,0x1
    7c33ec90a022:	shl    r11d,0x1d
    7c33ec90a026:	or     r10d,r11d
    7c33ec90a029:	mov    r11d,edx
    7c33ec90a02c:	and    r11d,0x800
    7c33ec90a033:	shl    r11d,0x11
    7c33ec90a037:	or     r10d,r11d
    7c33ec90a03a:	btc    r10,0x1d
    7c33ec90a03f:	mov    r11d,0xf0000000
    7c33ec90a045:	and    r11,r10
    7c33ec90a048:	movabs rsi,0xffffffff0fffffff
    7c33ec90a052:	and    rbx,rsi
    7c33ec90a055:	or     rbx,r11
    7c33ec90a058:	pop    r11
    7c33ec90a05a:	pop    r10
    7c33ec90a05c:	pop    rsi
    7c33ec90a05d:	pop    rdx
    7c33ec90a05e:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90a066:	mov    eax,0x410450
    7c33ec90a06b:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90a073:	add    rsp,0x150
    7c33ec90a07a:	mov    eax,0x3
    7c33ec90a07f:	movabs r11,0x558530395390
    7c33ec90a089:	jmp    r11
    7c33ec90a08c:	jmp    0x7c33ec902e52
    7c33ec90a091:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec90a0a0:	sub    rsp,0x150
    7c33ec90a0a7:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90a0af:	mov    QWORD PTR [rsp],r11
    7c33ec90a0b3:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec90a0bc:	je     0x7c33ec90a14c
    7c33ec90a0c2:	push   rdx
    7c33ec90a0c3:	push   rsi
    7c33ec90a0c4:	push   r10
    7c33ec90a0c6:	push   r11
    7c33ec90a0c8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90a0cd:	mov    r10d,edx
    7c33ec90a0d0:	and    r10d,0xc0
    7c33ec90a0d7:	shl    r10d,0x18
    7c33ec90a0db:	mov    r11d,edx
    7c33ec90a0de:	and    r11d,0x1
    7c33ec90a0e2:	shl    r11d,0x1d
    7c33ec90a0e6:	or     r10d,r11d
    7c33ec90a0e9:	mov    r11d,edx
    7c33ec90a0ec:	and    r11d,0x800
    7c33ec90a0f3:	shl    r11d,0x11
    7c33ec90a0f7:	or     r10d,r11d
    7c33ec90a0fa:	btc    r10,0x1d
    7c33ec90a0ff:	mov    r11d,0xf0000000
    7c33ec90a105:	and    r11,r10
    7c33ec90a108:	movabs rsi,0xffffffff0fffffff
    7c33ec90a112:	and    rbx,rsi
    7c33ec90a115:	or     rbx,r11
    7c33ec90a118:	pop    r11
    7c33ec90a11a:	pop    r10
    7c33ec90a11c:	pop    rsi
    7c33ec90a11d:	pop    rdx
    7c33ec90a11e:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90a126:	mov    eax,0x410490
    7c33ec90a12b:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90a133:	add    rsp,0x150
    7c33ec90a13a:	mov    eax,0x3
    7c33ec90a13f:	movabs r11,0x558530395390
    7c33ec90a149:	jmp    r11
    7c33ec90a14c:	jmp    0x7c33ec9033c8
    7c33ec90a151:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec90a160:	sub    rsp,0x150
    7c33ec90a167:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90a16f:	mov    QWORD PTR [rsp],r11
    7c33ec90a173:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec90a17c:	je     0x7c33ec90a20c
    7c33ec90a182:	push   rdx
    7c33ec90a183:	push   rsi
    7c33ec90a184:	push   r10
    7c33ec90a186:	push   r11
    7c33ec90a188:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90a18d:	mov    r10d,edx
    7c33ec90a190:	and    r10d,0xc0
    7c33ec90a197:	shl    r10d,0x18
    7c33ec90a19b:	mov    r11d,edx
    7c33ec90a19e:	and    r11d,0x1
    7c33ec90a1a2:	shl    r11d,0x1d
    7c33ec90a1a6:	or     r10d,r11d
    7c33ec90a1a9:	mov    r11d,edx
    7c33ec90a1ac:	and    r11d,0x800
    7c33ec90a1b3:	shl    r11d,0x11
    7c33ec90a1b7:	or     r10d,r11d
    7c33ec90a1ba:	btc    r10,0x1d
    7c33ec90a1bf:	mov    r11d,0xf0000000
    7c33ec90a1c5:	and    r11,r10
    7c33ec90a1c8:	movabs rsi,0xffffffff0fffffff
    7c33ec90a1d2:	and    rbx,rsi
    7c33ec90a1d5:	or     rbx,r11
    7c33ec90a1d8:	pop    r11
    7c33ec90a1da:	pop    r10
    7c33ec90a1dc:	pop    rsi
    7c33ec90a1dd:	pop    rdx
    7c33ec90a1de:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90a1e6:	mov    eax,0x410500
    7c33ec90a1eb:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90a1f3:	add    rsp,0x150
    7c33ec90a1fa:	mov    eax,0x3
    7c33ec90a1ff:	movabs r11,0x558530395390
    7c33ec90a209:	jmp    r11
    7c33ec90a20c:	jmp    0x7c33ec903a08
    7c33ec90a211:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec90a220:	sub    rsp,0x150
    7c33ec90a227:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90a22f:	mov    QWORD PTR [rsp],r11
    7c33ec90a233:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec90a23c:	je     0x7c33ec90a2cc
    7c33ec90a242:	push   rdx
    7c33ec90a243:	push   rsi
    7c33ec90a244:	push   r10
    7c33ec90a246:	push   r11
    7c33ec90a248:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90a24d:	mov    r10d,edx
    7c33ec90a250:	and    r10d,0xc0
    7c33ec90a257:	shl    r10d,0x18
    7c33ec90a25b:	mov    r11d,edx
    7c33ec90a25e:	and    r11d,0x1
    7c33ec90a262:	shl    r11d,0x1d
    7c33ec90a266:	or     r10d,r11d
    7c33ec90a269:	mov    r11d,edx
    7c33ec90a26c:	and    r11d,0x800
    7c33ec90a273:	shl    r11d,0x11
    7c33ec90a277:	or     r10d,r11d
    7c33ec90a27a:	btc    r10,0x1d
    7c33ec90a27f:	mov    r11d,0xf0000000
    7c33ec90a285:	and    r11,r10
    7c33ec90a288:	movabs rsi,0xffffffff0fffffff
    7c33ec90a292:	and    rbx,rsi
    7c33ec90a295:	or     rbx,r11
    7c33ec90a298:	pop    r11
    7c33ec90a29a:	pop    r10
    7c33ec90a29c:	pop    rsi
    7c33ec90a29d:	pop    rdx
    7c33ec90a29e:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90a2a6:	mov    eax,0x410504
    7c33ec90a2ab:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90a2b3:	add    rsp,0x150
    7c33ec90a2ba:	mov    eax,0x3
    7c33ec90a2bf:	movabs r11,0x558530395390
    7c33ec90a2c9:	jmp    r11
    7c33ec90a2cc:	jmp    0x7c33ec903a18
    7c33ec90a2d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec90a2e0:	sub    rsp,0x150
    7c33ec90a2e7:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90a2ef:	mov    QWORD PTR [rsp],r11
    7c33ec90a2f3:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec90a2fc:	je     0x7c33ec90a38c
    7c33ec90a302:	push   rdx
    7c33ec90a303:	push   rsi
    7c33ec90a304:	push   r10
    7c33ec90a306:	push   r11
    7c33ec90a308:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90a30d:	mov    r10d,edx
    7c33ec90a310:	and    r10d,0xc0
    7c33ec90a317:	shl    r10d,0x18
    7c33ec90a31b:	mov    r11d,edx
    7c33ec90a31e:	and    r11d,0x1
    7c33ec90a322:	shl    r11d,0x1d
    7c33ec90a326:	or     r10d,r11d
    7c33ec90a329:	mov    r11d,edx
    7c33ec90a32c:	and    r11d,0x800
    7c33ec90a333:	shl    r11d,0x11
    7c33ec90a337:	or     r10d,r11d
    7c33ec90a33a:	btc    r10,0x1d
    7c33ec90a33f:	mov    r11d,0xf0000000
    7c33ec90a345:	and    r11,r10
    7c33ec90a348:	movabs rsi,0xffffffff0fffffff
    7c33ec90a352:	and    rbx,rsi
    7c33ec90a355:	or     rbx,r11
    7c33ec90a358:	pop    r11
    7c33ec90a35a:	pop    r10
    7c33ec90a35c:	pop    rsi
    7c33ec90a35d:	pop    rdx
    7c33ec90a35e:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90a366:	mov    eax,0x4106d0
    7c33ec90a36b:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90a373:	add    rsp,0x150
    7c33ec90a37a:	mov    eax,0x3
    7c33ec90a37f:	movabs r11,0x558530395390
    7c33ec90a389:	jmp    r11
    7c33ec90a38c:	jmp    0x7c33ec9075dd
    7c33ec90a391:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec90a3a0:	sub    rsp,0x150
    7c33ec90a3a7:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90a3af:	mov    QWORD PTR [rsp],r11
    7c33ec90a3b3:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec90a3bc:	je     0x7c33ec90a44c
    7c33ec90a3c2:	push   rdx
    7c33ec90a3c3:	push   rsi
    7c33ec90a3c4:	push   r10
    7c33ec90a3c6:	push   r11
    7c33ec90a3c8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90a3cd:	mov    r10d,edx
    7c33ec90a3d0:	and    r10d,0xc0
    7c33ec90a3d7:	shl    r10d,0x18
    7c33ec90a3db:	mov    r11d,edx
    7c33ec90a3de:	and    r11d,0x1
    7c33ec90a3e2:	shl    r11d,0x1d
    7c33ec90a3e6:	or     r10d,r11d
    7c33ec90a3e9:	mov    r11d,edx
    7c33ec90a3ec:	and    r11d,0x800
    7c33ec90a3f3:	shl    r11d,0x11
    7c33ec90a3f7:	or     r10d,r11d
    7c33ec90a3fa:	btc    r10,0x1d
    7c33ec90a3ff:	mov    r11d,0xf0000000
    7c33ec90a405:	and    r11,r10
    7c33ec90a408:	movabs rsi,0xffffffff0fffffff
    7c33ec90a412:	and    rbx,rsi
    7c33ec90a415:	or     rbx,r11
    7c33ec90a418:	pop    r11
    7c33ec90a41a:	pop    r10
    7c33ec90a41c:	pop    rsi
    7c33ec90a41d:	pop    rdx
    7c33ec90a41e:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90a426:	mov    eax,0x4106dc
    7c33ec90a42b:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90a433:	add    rsp,0x150
    7c33ec90a43a:	mov    eax,0x3
    7c33ec90a43f:	movabs r11,0x558530395390
    7c33ec90a449:	jmp    r11
    7c33ec90a44c:	jmp    0x7c33ec907613
    7c33ec90a451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec90a460:	sub    rsp,0x150
    7c33ec90a467:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90a46f:	mov    QWORD PTR [rsp],r11
    7c33ec90a473:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec90a47c:	je     0x7c33ec90a50c
    7c33ec90a482:	push   rdx
    7c33ec90a483:	push   rsi
    7c33ec90a484:	push   r10
    7c33ec90a486:	push   r11
    7c33ec90a488:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90a48d:	mov    r10d,edx
    7c33ec90a490:	and    r10d,0xc0
    7c33ec90a497:	shl    r10d,0x18
    7c33ec90a49b:	mov    r11d,edx
    7c33ec90a49e:	and    r11d,0x1
    7c33ec90a4a2:	shl    r11d,0x1d
    7c33ec90a4a6:	or     r10d,r11d
    7c33ec90a4a9:	mov    r11d,edx
    7c33ec90a4ac:	and    r11d,0x800
    7c33ec90a4b3:	shl    r11d,0x11
    7c33ec90a4b7:	or     r10d,r11d
    7c33ec90a4ba:	btc    r10,0x1d
    7c33ec90a4bf:	mov    r11d,0xf0000000
    7c33ec90a4c5:	and    r11,r10
    7c33ec90a4c8:	movabs rsi,0xffffffff0fffffff
    7c33ec90a4d2:	and    rbx,rsi
    7c33ec90a4d5:	or     rbx,r11
    7c33ec90a4d8:	pop    r11
    7c33ec90a4da:	pop    r10
    7c33ec90a4dc:	pop    rsi
    7c33ec90a4dd:	pop    rdx
    7c33ec90a4de:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90a4e6:	mov    eax,0x4106e8
    7c33ec90a4eb:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90a4f3:	add    rsp,0x150
    7c33ec90a4fa:	mov    eax,0x3
    7c33ec90a4ff:	movabs r11,0x558530395390
    7c33ec90a509:	jmp    r11
    7c33ec90a50c:	jmp    0x7c33ec90764e
    7c33ec90a511:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec90a520:	sub    rsp,0x150
    7c33ec90a527:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90a52f:	mov    QWORD PTR [rsp],r11
    7c33ec90a533:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec90a53c:	je     0x7c33ec90a5cc
    7c33ec90a542:	push   rdx
    7c33ec90a543:	push   rsi
    7c33ec90a544:	push   r10
    7c33ec90a546:	push   r11
    7c33ec90a548:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90a54d:	mov    r10d,edx
    7c33ec90a550:	and    r10d,0xc0
    7c33ec90a557:	shl    r10d,0x18
    7c33ec90a55b:	mov    r11d,edx
    7c33ec90a55e:	and    r11d,0x1
    7c33ec90a562:	shl    r11d,0x1d
    7c33ec90a566:	or     r10d,r11d
    7c33ec90a569:	mov    r11d,edx
    7c33ec90a56c:	and    r11d,0x800
    7c33ec90a573:	shl    r11d,0x11
    7c33ec90a577:	or     r10d,r11d
    7c33ec90a57a:	btc    r10,0x1d
    7c33ec90a57f:	mov    r11d,0xf0000000
    7c33ec90a585:	and    r11,r10
    7c33ec90a588:	movabs rsi,0xffffffff0fffffff
    7c33ec90a592:	and    rbx,rsi
    7c33ec90a595:	or     rbx,r11
    7c33ec90a598:	pop    r11
    7c33ec90a59a:	pop    r10
    7c33ec90a59c:	pop    rsi
    7c33ec90a59d:	pop    rdx
    7c33ec90a59e:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90a5a6:	mov    eax,0x410704
    7c33ec90a5ab:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90a5b3:	add    rsp,0x150
    7c33ec90a5ba:	mov    eax,0x3
    7c33ec90a5bf:	movabs r11,0x558530395390
    7c33ec90a5c9:	jmp    r11
    7c33ec90a5cc:	jmp    0x7c33ec9077e6
    7c33ec90a5d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec90a5e0:	sub    rsp,0x150
    7c33ec90a5e7:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90a5ef:	mov    QWORD PTR [rsp],r11
    7c33ec90a5f3:	cmp    DWORD PTR [r12+0x310],0x0
    7c33ec90a5fc:	je     0x7c33ec90a68c
    7c33ec90a602:	push   rdx
    7c33ec90a603:	push   rsi
    7c33ec90a604:	push   r10
    7c33ec90a606:	push   r11
    7c33ec90a608:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec90a60d:	mov    r10d,edx
    7c33ec90a610:	and    r10d,0xc0
    7c33ec90a617:	shl    r10d,0x18
    7c33ec90a61b:	mov    r11d,edx
    7c33ec90a61e:	and    r11d,0x1
    7c33ec90a622:	shl    r11d,0x1d
    7c33ec90a626:	or     r10d,r11d
    7c33ec90a629:	mov    r11d,edx
    7c33ec90a62c:	and    r11d,0x800
    7c33ec90a633:	shl    r11d,0x11
    7c33ec90a637:	or     r10d,r11d
    7c33ec90a63a:	btc    r10,0x1d
    7c33ec90a63f:	mov    r11d,0xf0000000
    7c33ec90a645:	and    r11,r10
    7c33ec90a648:	movabs rsi,0xffffffff0fffffff
    7c33ec90a652:	and    rbx,rsi
    7c33ec90a655:	or     rbx,r11
    7c33ec90a658:	pop    r11
    7c33ec90a65a:	pop    r10
    7c33ec90a65c:	pop    rsi
    7c33ec90a65d:	pop    rdx
    7c33ec90a65e:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90a666:	mov    eax,0x4103f0
    7c33ec90a66b:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90a673:	add    rsp,0x150
    7c33ec90a67a:	mov    eax,0x3
    7c33ec90a67f:	movabs r11,0x558530395390
    7c33ec90a689:	jmp    r11
    7c33ec90a68c:	jmp    0x7c33ec9079cf
    7c33ec90a691:	nop
    7c33ec90a692:	nop
    7c33ec90a693:	nop
