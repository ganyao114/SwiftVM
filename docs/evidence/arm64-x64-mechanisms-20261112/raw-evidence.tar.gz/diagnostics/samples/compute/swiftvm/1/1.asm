
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/1/1.bin:     file format binary


Disassembly of section .data:

0000707120efe960 <.data>:
    707120efe960:	sub    rsp,0x50
    707120efe964:	mov    r11,QWORD PTR [r12+0x398]
    707120efe96c:	mov    QWORD PTR [rsp+0x48],r11
    707120efe971:	mov    r13,QWORD PTR [r12]
    707120efe975:	mov    r14,r13
    707120efe978:	add    r14,0x20
    707120efe97c:	mov    r15,QWORD PTR [r14]
    707120efe97f:	mov    r14,QWORD PTR [r12+0x10]
    707120efe984:	mov    rcx,r14
    707120efe987:	add    r15,rcx
    707120efe98a:	mov    QWORD PTR [r12+0x40],r15
    707120efe98f:	add    r13,0x20
    707120efe993:	mov    QWORD PTR [r13+0x0],r15
    707120efe997:	mov    r13d,0x0
    707120efe99d:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe9a5:	mov    rax,r14
    707120efe9a8:	test   rax,rax
    707120efe9ab:	sete   al
    707120efe9ae:	movzx  eax,al
    707120efe9b1:	and    eax,0x1
    707120efe9b4:	mov    r13,rax
    707120efe9b7:	mov    rax,r13
    707120efe9ba:	and    eax,0x1
    707120efe9bd:	test   rax,rax
    707120efe9c0:	jne    0x707120f0113a
    707120efe9c6:	jmp    0x707120efe9cb
    707120efe9cb:	mov    r13,QWORD PTR [r12+0xf8]
    707120efe9d3:	sub    r13,0x150
    707120efe9da:	mov    QWORD PTR [r12+0xf8],r13
    707120efe9e2:	mov    r14,QWORD PTR [r12]
    707120efe9e6:	mov    r15,r14
    707120efe9e9:	add    r15,0x68
    707120efe9ed:	mov    rbp,QWORD PTR [r15]
    707120efe9f0:	mov    QWORD PTR [r12+0x88],rbp
    707120efe9f8:	add    r14,0x28
    707120efe9fc:	mov    QWORD PTR [r12+0x40],r14
    707120efea01:	mov    r14,r13
    707120efea04:	add    r14,0x0
    707120efea08:	mov    QWORD PTR [r12+0x48],r14
    707120efea0d:	mov    r14d,0x420000
    707120efea13:	add    r14,0xb90
    707120efea1a:	mov    QWORD PTR [r12+0x50],r14
    707120efea1f:	add    r13,0x100
    707120efea26:	mov    r14,r13
    707120efea29:	add    r14,0x8
    707120efea2d:	mov    r15,QWORD PTR [r12+0xe8]
    707120efea35:	mov    rbp,QWORD PTR [r12+0xd8]
    707120efea3d:	mov    QWORD PTR [r13+0x0],r15
    707120efea41:	mov    r13d,0x0
    707120efea47:	mov    DWORD PTR [r12+0x32c],r13d
    707120efea4f:	mov    QWORD PTR [r14],rbp
    707120efea52:	mov    r13d,0x0
    707120efea58:	mov    DWORD PTR [r12+0x32c],r13d
    707120efea60:	mov    r13,QWORD PTR [r12+0xf8]
    707120efea68:	mov    r14,r13
    707120efea6b:	add    r14,0x110
    707120efea72:	mov    r15,r14
    707120efea75:	add    r15,0x8
    707120efea79:	mov    rbp,QWORD PTR [r12+0xd0]
    707120efea81:	mov    r8,QWORD PTR [r12+0xc8]
    707120efea89:	mov    QWORD PTR [r14],rbp
    707120efea8c:	mov    r14d,0x0
    707120efea92:	mov    DWORD PTR [r12+0x32c],r14d
    707120efea9a:	mov    QWORD PTR [r15],r8
    707120efea9d:	mov    r14d,0x0
    707120efeaa3:	mov    DWORD PTR [r12+0x32c],r14d
    707120efeaab:	mov    r14,r13
    707120efeaae:	add    r14,0x120
    707120efeab5:	mov    r15,r14
    707120efeab8:	add    r15,0x8
    707120efeabc:	mov    rbp,QWORD PTR [r12+0xc0]
    707120efeac4:	mov    r8,QWORD PTR [r12+0xb8]
    707120efeacc:	mov    QWORD PTR [r14],rbp
    707120efeacf:	mov    r14d,0x0
    707120efead5:	mov    DWORD PTR [r12+0x32c],r14d
    707120efeadd:	mov    QWORD PTR [r15],r8
    707120efeae0:	mov    r14d,0x0
    707120efeae6:	mov    DWORD PTR [r12+0x32c],r14d
    707120efeaee:	mov    r14,r13
    707120efeaf1:	add    r14,0x130
    707120efeaf8:	mov    r15,r14
    707120efeafb:	add    r15,0x8
    707120efeaff:	mov    rbp,QWORD PTR [r12+0xb0]
    707120efeb07:	mov    r8,QWORD PTR [r12+0xa8]
    707120efeb0f:	mov    QWORD PTR [r14],rbp
    707120efeb12:	mov    r14d,0x0
    707120efeb18:	mov    DWORD PTR [r12+0x32c],r14d
    707120efeb20:	mov    QWORD PTR [r15],r8
    707120efeb23:	mov    r14d,0x0
    707120efeb29:	mov    DWORD PTR [r12+0x32c],r14d
    707120efeb31:	add    r13,0x140
    707120efeb38:	mov    r14,r13
    707120efeb3b:	add    r14,0x8
    707120efeb3f:	mov    r15,QWORD PTR [r12+0xa0]
    707120efeb47:	mov    rbp,QWORD PTR [r12+0x98]
    707120efeb4f:	mov    QWORD PTR [r13+0x0],r15
    707120efeb53:	mov    r13d,0x0
    707120efeb59:	mov    DWORD PTR [r12+0x32c],r13d
    707120efeb61:	mov    QWORD PTR [r14],rbp
    707120efeb64:	mov    r13d,0x0
    707120efeb6a:	mov    DWORD PTR [r12+0x32c],r13d
    707120efeb72:	jmp    0x707120efeb77
    707120efeb77:	mov    r13,QWORD PTR [r12+0x8]
    707120efeb7c:	mov    r14,r13
    707120efeb7f:	add    r14,0x1
    707120efeb83:	movzx  r15d,BYTE PTR [r13+0x0]
    707120efeb88:	mov    QWORD PTR [r12+0x58],r15
    707120efeb8d:	mov    QWORD PTR [r12+0x8],r14
    707120efeb92:	mov    r13,QWORD PTR [r12+0x88]
    707120efeb9a:	mov    r14,r13
    707120efeb9d:	add    r14,0x1
    707120efeba1:	mov    QWORD PTR [r12+0x60],r14
    707120efeba6:	mov    r15,QWORD PTR [r12]
    707120efebaa:	mov    rbp,r15
    707120efebad:	add    rbp,0x68
    707120efebb1:	mov    QWORD PTR [rbp+0x0],r14
    707120efebb5:	mov    r14d,0x0
    707120efebbb:	mov    DWORD PTR [r12+0x32c],r14d
    707120efebc3:	mov    rcx,r13
    707120efebc6:	mov    r14,r15
    707120efebc9:	add    r14,rcx
    707120efebcc:	mov    QWORD PTR [r12+0x60],r14
    707120efebd1:	add    r14,0x28
    707120efebd5:	movzx  r13d,BYTE PTR [r12+0x58]
    707120efebdb:	mov    BYTE PTR [r14],r13b
    707120efebde:	mov    r13d,0x0
    707120efebe4:	mov    DWORD PTR [r12+0x32c],r13d
    707120efebec:	add    r15,0x68
    707120efebf0:	mov    r13,QWORD PTR [r15]
    707120efebf3:	mov    QWORD PTR [r12+0x88],r13
    707120efebfb:	sub    r13,0x40
    707120efebff:	mov    rcx,QWORD PTR [r12+0x380]
    707120efec07:	jrcxz  0x707120efec0e
    707120efec09:	jmp    0x707120f0117f
    707120efec0e:	pushf
    707120efec0f:	pop    r11
    707120efec11:	mov    QWORD PTR [rsp+0x48],r11
    707120efec16:	jne    0x707120f01021
    707120efec1c:	jmp    0x707120efec21
    707120efec21:	mov    rax,QWORD PTR [r12+0x40]
    707120efec26:	mov    QWORD PTR [rsp],rax
    707120efec2a:	mov    eax,0x0
    707120efec2f:	mov    QWORD PTR [rsp+0x20],rax
    707120efec34:	mov    eax,0x0
    707120efec39:	mov    QWORD PTR [rsp+0x18],rax
    707120efec3e:	mov    eax,0x0
    707120efec43:	mov    QWORD PTR [rsp+0x10],rax
    707120efec48:	mov    eax,0x0
    707120efec4d:	mov    QWORD PTR [rsp+0x8],rax
    707120efec52:	mov    rdi,QWORD PTR [rsp]
    707120efec56:	movzx  r9d,BYTE PTR [rdi]
    707120efec5a:	mov    r13,r9
    707120efec5d:	mov    rcx,r13
    707120efec60:	mov    r9,QWORD PTR [rsp+0x20]
    707120efec65:	or     r9,rcx
    707120efec68:	mov    r13,QWORD PTR [rsp]
    707120efec6c:	add    r13,0x1
    707120efec70:	movzx  r8d,BYTE PTR [r13+0x0]
    707120efec75:	mov    r13,r8
    707120efec78:	mov    rcx,r13
    707120efec7b:	mov    r8,QWORD PTR [rsp+0x18]
    707120efec80:	or     r8,rcx
    707120efec83:	mov    r13,QWORD PTR [rsp]
    707120efec87:	add    r13,0x2
    707120efec8b:	movzx  ebp,BYTE PTR [r13+0x0]
    707120efec90:	mov    r13,rbp
    707120efec93:	mov    rcx,r13
    707120efec96:	mov    rbp,QWORD PTR [rsp+0x10]
    707120efec9b:	or     rbp,rcx
    707120efec9e:	mov    r13,QWORD PTR [rsp]
    707120efeca2:	add    r13,0x3
    707120efeca6:	movzx  r15d,BYTE PTR [r13+0x0]
    707120efecab:	mov    r13,r15
    707120efecae:	mov    rcx,r13
    707120efecb1:	mov    r15,QWORD PTR [rsp+0x8]
    707120efecb6:	or     r15,rcx
    707120efecb9:	mov    r13,QWORD PTR [rsp]
    707120efecbd:	add    r13,0x4
    707120efecc1:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efecc6:	mov    r13,r14
    707120efecc9:	shl    r13,0x8
    707120efeccd:	mov    rcx,r13
    707120efecd0:	or     r9,rcx
    707120efecd3:	mov    r13,QWORD PTR [rsp]
    707120efecd7:	add    r13,0x5
    707120efecdb:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efece0:	mov    r13,r14
    707120efece3:	shl    r13,0x8
    707120efece7:	mov    rcx,r13
    707120efecea:	or     r8,rcx
    707120efeced:	mov    r13,QWORD PTR [rsp]
    707120efecf1:	add    r13,0x6
    707120efecf5:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efecfa:	mov    r13,r14
    707120efecfd:	shl    r13,0x8
    707120efed01:	mov    rcx,r13
    707120efed04:	or     rbp,rcx
    707120efed07:	mov    r13,QWORD PTR [rsp]
    707120efed0b:	add    r13,0x7
    707120efed0f:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efed14:	mov    r13,r14
    707120efed17:	shl    r13,0x8
    707120efed1b:	mov    rcx,r13
    707120efed1e:	or     r15,rcx
    707120efed21:	mov    r13,QWORD PTR [rsp]
    707120efed25:	add    r13,0x8
    707120efed29:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efed2e:	mov    r13,r14
    707120efed31:	shl    r13,0x10
    707120efed35:	mov    rcx,r13
    707120efed38:	or     r9,rcx
    707120efed3b:	mov    r13,QWORD PTR [rsp]
    707120efed3f:	add    r13,0x9
    707120efed43:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efed48:	mov    r13,r14
    707120efed4b:	shl    r13,0x10
    707120efed4f:	mov    rcx,r13
    707120efed52:	or     r8,rcx
    707120efed55:	mov    r13,QWORD PTR [rsp]
    707120efed59:	add    r13,0xa
    707120efed5d:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efed62:	mov    r13,r14
    707120efed65:	shl    r13,0x10
    707120efed69:	mov    rcx,r13
    707120efed6c:	or     rbp,rcx
    707120efed6f:	mov    r13,QWORD PTR [rsp]
    707120efed73:	add    r13,0xb
    707120efed77:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efed7c:	mov    r13,r14
    707120efed7f:	shl    r13,0x10
    707120efed83:	mov    rcx,r13
    707120efed86:	or     r15,rcx
    707120efed89:	mov    r13,QWORD PTR [rsp]
    707120efed8d:	add    r13,0xc
    707120efed91:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efed96:	mov    r13,r14
    707120efed99:	shl    r13,0x18
    707120efed9d:	mov    rcx,r13
    707120efeda0:	or     r9,rcx
    707120efeda3:	mov    r13,QWORD PTR [rsp]
    707120efeda7:	add    r13,0xd
    707120efedab:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efedb0:	mov    r13,r14
    707120efedb3:	shl    r13,0x18
    707120efedb7:	mov    rcx,r13
    707120efedba:	or     r8,rcx
    707120efedbd:	mov    r13,QWORD PTR [rsp]
    707120efedc1:	add    r13,0xe
    707120efedc5:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efedca:	mov    r13,r14
    707120efedcd:	shl    r13,0x18
    707120efedd1:	mov    rcx,r13
    707120efedd4:	or     rbp,rcx
    707120efedd7:	mov    r13,QWORD PTR [rsp]
    707120efeddb:	add    r13,0xf
    707120efeddf:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efede4:	mov    r13,r14
    707120efede7:	shl    r13,0x18
    707120efedeb:	mov    rcx,r13
    707120efedee:	or     r15,rcx
    707120efedf1:	mov    r13,QWORD PTR [rsp]
    707120efedf5:	add    r13,0x10
    707120efedf9:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efedfe:	mov    r13,r14
    707120efee01:	shl    r13,0x20
    707120efee05:	mov    rcx,r13
    707120efee08:	or     r9,rcx
    707120efee0b:	mov    r13,QWORD PTR [rsp]
    707120efee0f:	add    r13,0x11
    707120efee13:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efee18:	mov    r13,r14
    707120efee1b:	shl    r13,0x20
    707120efee1f:	mov    rcx,r13
    707120efee22:	or     r8,rcx
    707120efee25:	mov    r13,QWORD PTR [rsp]
    707120efee29:	add    r13,0x12
    707120efee2d:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efee32:	mov    r13,r14
    707120efee35:	shl    r13,0x20
    707120efee39:	mov    rcx,r13
    707120efee3c:	or     rbp,rcx
    707120efee3f:	mov    r13,QWORD PTR [rsp]
    707120efee43:	add    r13,0x13
    707120efee47:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efee4c:	mov    r13,r14
    707120efee4f:	shl    r13,0x20
    707120efee53:	mov    rcx,r13
    707120efee56:	or     r15,rcx
    707120efee59:	mov    r13,QWORD PTR [rsp]
    707120efee5d:	add    r13,0x14
    707120efee61:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efee66:	mov    r13,r14
    707120efee69:	shl    r13,0x28
    707120efee6d:	mov    rcx,r13
    707120efee70:	or     r9,rcx
    707120efee73:	mov    r13,QWORD PTR [rsp]
    707120efee77:	add    r13,0x15
    707120efee7b:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efee80:	mov    r13,r14
    707120efee83:	shl    r13,0x28
    707120efee87:	mov    rcx,r13
    707120efee8a:	or     r8,rcx
    707120efee8d:	mov    r13,QWORD PTR [rsp]
    707120efee91:	add    r13,0x16
    707120efee95:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efee9a:	mov    r13,r14
    707120efee9d:	shl    r13,0x28
    707120efeea1:	mov    rcx,r13
    707120efeea4:	or     rbp,rcx
    707120efeea7:	mov    r13,QWORD PTR [rsp]
    707120efeeab:	add    r13,0x17
    707120efeeaf:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efeeb4:	mov    r13,r14
    707120efeeb7:	shl    r13,0x28
    707120efeebb:	mov    rcx,r13
    707120efeebe:	or     r15,rcx
    707120efeec1:	mov    r13,QWORD PTR [rsp]
    707120efeec5:	add    r13,0x18
    707120efeec9:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efeece:	mov    r13,r14
    707120efeed1:	shl    r13,0x30
    707120efeed5:	mov    rcx,r13
    707120efeed8:	or     r9,rcx
    707120efeedb:	mov    r13,QWORD PTR [rsp]
    707120efeedf:	add    r13,0x19
    707120efeee3:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efeee8:	mov    r13,r14
    707120efeeeb:	shl    r13,0x30
    707120efeeef:	mov    rcx,r13
    707120efeef2:	or     r8,rcx
    707120efeef5:	mov    r13,QWORD PTR [rsp]
    707120efeef9:	add    r13,0x1a
    707120efeefd:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efef02:	mov    r13,r14
    707120efef05:	shl    r13,0x30
    707120efef09:	mov    rcx,r13
    707120efef0c:	or     rbp,rcx
    707120efef0f:	mov    r13,QWORD PTR [rsp]
    707120efef13:	add    r13,0x1b
    707120efef17:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efef1c:	mov    r13,r14
    707120efef1f:	shl    r13,0x30
    707120efef23:	mov    rcx,r13
    707120efef26:	or     r15,rcx
    707120efef29:	mov    r13,QWORD PTR [rsp]
    707120efef2d:	add    r13,0x1c
    707120efef31:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efef36:	mov    r13,r14
    707120efef39:	shl    r13,0x38
    707120efef3d:	mov    rcx,r13
    707120efef40:	mov    rax,r9
    707120efef43:	or     rax,rcx
    707120efef46:	mov    QWORD PTR [rsp+0x40],rax
    707120efef4b:	mov    r13,QWORD PTR [rsp]
    707120efef4f:	add    r13,0x1d
    707120efef53:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efef58:	mov    r13,r14
    707120efef5b:	shl    r13,0x38
    707120efef5f:	mov    rcx,r13
    707120efef62:	mov    rax,r8
    707120efef65:	or     rax,rcx
    707120efef68:	mov    QWORD PTR [rsp+0x30],rax
    707120efef6d:	mov    r13,QWORD PTR [rsp]
    707120efef71:	add    r13,0x1e
    707120efef75:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efef7a:	mov    r13,r14
    707120efef7d:	shl    r13,0x38
    707120efef81:	mov    rcx,r13
    707120efef84:	mov    rax,rbp
    707120efef87:	or     rax,rcx
    707120efef8a:	mov    QWORD PTR [rsp+0x28],rax
    707120efef8f:	mov    r13,QWORD PTR [rsp]
    707120efef93:	add    r13,0x1f
    707120efef97:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efef9c:	mov    r13,r14
    707120efef9f:	shl    r13,0x38
    707120efefa3:	mov    rcx,r13
    707120efefa6:	mov    rax,r15
    707120efefa9:	or     rax,rcx
    707120efefac:	mov    QWORD PTR [rsp+0x38],rax
    707120efefb1:	mov    r13,QWORD PTR [rsp]
    707120efefb5:	add    r13,0x20
    707120efefb9:	movzx  r14d,BYTE PTR [r13+0x0]
    707120efefbe:	mov    r13,r14
    707120efefc1:	mov    rcx,r13
    707120efefc4:	mov    r14,QWORD PTR [rsp+0x20]
    707120efefc9:	or     r14,rcx
    707120efefcc:	mov    r13,QWORD PTR [rsp]
    707120efefd0:	add    r13,0x21
    707120efefd4:	movzx  ebp,BYTE PTR [r13+0x0]
    707120efefd9:	mov    r13,rbp
    707120efefdc:	mov    rcx,r13
    707120efefdf:	mov    rbp,QWORD PTR [rsp+0x18]
    707120efefe4:	or     rbp,rcx
    707120efefe7:	mov    r13,QWORD PTR [rsp]
    707120efefeb:	add    r13,0x22
    707120efefef:	movzx  r8d,BYTE PTR [r13+0x0]
    707120efeff4:	mov    r13,r8
    707120efeff7:	mov    rcx,r13
    707120efeffa:	mov    r8,QWORD PTR [rsp+0x10]
    707120efefff:	or     r8,rcx
    707120eff002:	mov    r13,QWORD PTR [rsp]
    707120eff006:	add    r13,0x23
    707120eff00a:	movzx  r15d,BYTE PTR [r13+0x0]
    707120eff00f:	mov    r13,r15
    707120eff012:	mov    rcx,r13
    707120eff015:	mov    r15,QWORD PTR [rsp+0x8]
    707120eff01a:	or     r15,rcx
    707120eff01d:	mov    r13,QWORD PTR [rsp]
    707120eff021:	add    r13,0x24
    707120eff025:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff02a:	mov    r13,r9
    707120eff02d:	shl    r13,0x8
    707120eff031:	mov    rcx,r13
    707120eff034:	or     r14,rcx
    707120eff037:	mov    r13,QWORD PTR [rsp]
    707120eff03b:	add    r13,0x25
    707120eff03f:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff044:	mov    r13,r9
    707120eff047:	shl    r13,0x8
    707120eff04b:	mov    rcx,r13
    707120eff04e:	or     rbp,rcx
    707120eff051:	mov    r13,QWORD PTR [rsp]
    707120eff055:	add    r13,0x26
    707120eff059:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff05e:	mov    r13,r9
    707120eff061:	shl    r13,0x8
    707120eff065:	mov    rcx,r13
    707120eff068:	or     r8,rcx
    707120eff06b:	mov    r13,QWORD PTR [rsp]
    707120eff06f:	add    r13,0x27
    707120eff073:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff078:	mov    r13,r9
    707120eff07b:	shl    r13,0x8
    707120eff07f:	mov    rcx,r13
    707120eff082:	or     r15,rcx
    707120eff085:	mov    r13,QWORD PTR [rsp]
    707120eff089:	add    r13,0x28
    707120eff08d:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff092:	mov    r13,r9
    707120eff095:	shl    r13,0x10
    707120eff099:	mov    rcx,r13
    707120eff09c:	or     r14,rcx
    707120eff09f:	mov    r13,QWORD PTR [rsp]
    707120eff0a3:	add    r13,0x29
    707120eff0a7:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff0ac:	mov    r13,r9
    707120eff0af:	shl    r13,0x10
    707120eff0b3:	mov    rcx,r13
    707120eff0b6:	or     rbp,rcx
    707120eff0b9:	mov    r13,QWORD PTR [rsp]
    707120eff0bd:	add    r13,0x2a
    707120eff0c1:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff0c6:	mov    r13,r9
    707120eff0c9:	shl    r13,0x10
    707120eff0cd:	mov    rcx,r13
    707120eff0d0:	or     r8,rcx
    707120eff0d3:	mov    r13,QWORD PTR [rsp]
    707120eff0d7:	add    r13,0x2b
    707120eff0db:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff0e0:	mov    r13,r9
    707120eff0e3:	shl    r13,0x10
    707120eff0e7:	mov    rcx,r13
    707120eff0ea:	or     r15,rcx
    707120eff0ed:	mov    r13,QWORD PTR [rsp]
    707120eff0f1:	add    r13,0x2c
    707120eff0f5:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff0fa:	mov    r13,r9
    707120eff0fd:	shl    r13,0x18
    707120eff101:	mov    rcx,r13
    707120eff104:	or     r14,rcx
    707120eff107:	mov    r13,QWORD PTR [rsp]
    707120eff10b:	add    r13,0x2d
    707120eff10f:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff114:	mov    r13,r9
    707120eff117:	shl    r13,0x18
    707120eff11b:	mov    rcx,r13
    707120eff11e:	or     rbp,rcx
    707120eff121:	mov    r13,QWORD PTR [rsp]
    707120eff125:	add    r13,0x2e
    707120eff129:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff12e:	mov    r13,r9
    707120eff131:	shl    r13,0x18
    707120eff135:	mov    rcx,r13
    707120eff138:	or     r8,rcx
    707120eff13b:	mov    r13,QWORD PTR [rsp]
    707120eff13f:	add    r13,0x2f
    707120eff143:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff148:	mov    r13,r9
    707120eff14b:	shl    r13,0x18
    707120eff14f:	mov    rcx,r13
    707120eff152:	or     r15,rcx
    707120eff155:	mov    r13,QWORD PTR [rsp]
    707120eff159:	add    r13,0x30
    707120eff15d:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff162:	mov    r13,r9
    707120eff165:	shl    r13,0x20
    707120eff169:	mov    rcx,r13
    707120eff16c:	or     r14,rcx
    707120eff16f:	mov    r13,QWORD PTR [rsp]
    707120eff173:	add    r13,0x31
    707120eff177:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff17c:	mov    r13,r9
    707120eff17f:	shl    r13,0x20
    707120eff183:	mov    rcx,r13
    707120eff186:	or     rbp,rcx
    707120eff189:	mov    r13,QWORD PTR [rsp]
    707120eff18d:	add    r13,0x32
    707120eff191:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff196:	mov    r13,r9
    707120eff199:	shl    r13,0x20
    707120eff19d:	mov    rcx,r13
    707120eff1a0:	or     r8,rcx
    707120eff1a3:	mov    r13,QWORD PTR [rsp]
    707120eff1a7:	add    r13,0x33
    707120eff1ab:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff1b0:	mov    r13,r9
    707120eff1b3:	shl    r13,0x20
    707120eff1b7:	mov    rcx,r13
    707120eff1ba:	or     r15,rcx
    707120eff1bd:	mov    r13,QWORD PTR [rsp]
    707120eff1c1:	add    r13,0x34
    707120eff1c5:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff1ca:	mov    r13,r9
    707120eff1cd:	shl    r13,0x28
    707120eff1d1:	mov    rcx,r13
    707120eff1d4:	or     r14,rcx
    707120eff1d7:	mov    r13,QWORD PTR [rsp]
    707120eff1db:	add    r13,0x35
    707120eff1df:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff1e4:	mov    r13,r9
    707120eff1e7:	shl    r13,0x28
    707120eff1eb:	mov    rcx,r13
    707120eff1ee:	or     rbp,rcx
    707120eff1f1:	mov    r13,QWORD PTR [rsp]
    707120eff1f5:	add    r13,0x36
    707120eff1f9:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff1fe:	mov    r13,r9
    707120eff201:	shl    r13,0x28
    707120eff205:	mov    rcx,r13
    707120eff208:	or     r8,rcx
    707120eff20b:	mov    r13,QWORD PTR [rsp]
    707120eff20f:	add    r13,0x37
    707120eff213:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff218:	mov    r13,r9
    707120eff21b:	shl    r13,0x28
    707120eff21f:	mov    rcx,r13
    707120eff222:	or     r15,rcx
    707120eff225:	mov    r13,QWORD PTR [rsp]
    707120eff229:	add    r13,0x38
    707120eff22d:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff232:	mov    r13,r9
    707120eff235:	shl    r13,0x30
    707120eff239:	mov    rcx,r13
    707120eff23c:	or     r14,rcx
    707120eff23f:	mov    r13,QWORD PTR [rsp]
    707120eff243:	add    r13,0x39
    707120eff247:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff24c:	mov    r13,r9
    707120eff24f:	shl    r13,0x30
    707120eff253:	mov    rcx,r13
    707120eff256:	or     rbp,rcx
    707120eff259:	mov    r13,QWORD PTR [rsp]
    707120eff25d:	add    r13,0x3a
    707120eff261:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff266:	mov    r13,r9
    707120eff269:	shl    r13,0x30
    707120eff26d:	mov    rcx,r13
    707120eff270:	or     r8,rcx
    707120eff273:	mov    r13,QWORD PTR [rsp]
    707120eff277:	add    r13,0x3b
    707120eff27b:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff280:	mov    r13,r9
    707120eff283:	shl    r13,0x30
    707120eff287:	mov    rcx,r13
    707120eff28a:	or     r15,rcx
    707120eff28d:	mov    r13,QWORD PTR [rsp]
    707120eff291:	add    r13,0x3c
    707120eff295:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff29a:	mov    r13,r9
    707120eff29d:	shl    r13,0x38
    707120eff2a1:	mov    rcx,r13
    707120eff2a4:	or     r14,rcx
    707120eff2a7:	mov    r13,QWORD PTR [rsp]
    707120eff2ab:	add    r13,0x3d
    707120eff2af:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff2b4:	mov    r13,r9
    707120eff2b7:	shl    r13,0x38
    707120eff2bb:	mov    rcx,r13
    707120eff2be:	or     rbp,rcx
    707120eff2c1:	mov    r13,QWORD PTR [rsp]
    707120eff2c5:	add    r13,0x3e
    707120eff2c9:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff2ce:	mov    r13,r9
    707120eff2d1:	shl    r13,0x38
    707120eff2d5:	mov    rcx,r13
    707120eff2d8:	or     r8,rcx
    707120eff2db:	mov    r13,QWORD PTR [rsp]
    707120eff2df:	add    r13,0x3f
    707120eff2e3:	movzx  r9d,BYTE PTR [r13+0x0]
    707120eff2e8:	mov    r13,r9
    707120eff2eb:	shl    r13,0x38
    707120eff2ef:	mov    rcx,r13
    707120eff2f2:	or     r15,rcx
    707120eff2f5:	mov    rax,QWORD PTR [rsp+0x40]
    707120eff2fa:	mov    QWORD PTR [r12+0x110],rax
    707120eff302:	mov    QWORD PTR [r12+0x118],r14
    707120eff30a:	mov    rax,QWORD PTR [rsp+0x30]
    707120eff30f:	mov    QWORD PTR [r12+0x120],rax
    707120eff317:	mov    QWORD PTR [r12+0x128],rbp
    707120eff31f:	mov    rax,QWORD PTR [rsp+0x28]
    707120eff324:	mov    QWORD PTR [r12+0x130],rax
    707120eff32c:	mov    QWORD PTR [r12+0x138],r8
    707120eff334:	mov    rax,QWORD PTR [rsp+0x38]
    707120eff339:	mov    QWORD PTR [r12+0x140],rax
    707120eff341:	mov    QWORD PTR [r12+0x148],r15
    707120eff349:	mov    r13d,0x0
    707120eff34f:	mov    QWORD PTR [r12+0x58],r13
    707120eff354:	mov    r13d,0x0
    707120eff35a:	mov    r14,QWORD PTR [rsp+0x30]
    707120eff35f:	and    r14,0xff
    707120eff366:	and    r14,0xffff
    707120eff36d:	mov    rcx,r14
    707120eff370:	mov    r15,r13
    707120eff373:	or     r15,rcx
    707120eff376:	mov    r14,QWORD PTR [rsp+0x30]
    707120eff37b:	shr    r14,0x8
    707120eff37f:	and    r14,0xff
    707120eff386:	and    r14,0xffff
    707120eff38d:	shl    r14,0x10
    707120eff391:	mov    rcx,r14
    707120eff394:	or     r15,rcx
    707120eff397:	mov    r14,QWORD PTR [rsp+0x30]
    707120eff39c:	shr    r14,0x10
    707120eff3a0:	and    r14,0xff
    707120eff3a7:	and    r14,0xffff
    707120eff3ae:	shl    r14,0x20
    707120eff3b2:	mov    rcx,r14
    707120eff3b5:	or     r15,rcx
    707120eff3b8:	mov    r14,QWORD PTR [rsp+0x30]
    707120eff3bd:	shr    r14,0x18
    707120eff3c1:	and    r14,0xff
    707120eff3c8:	and    r14,0xffff
    707120eff3cf:	shl    r14,0x30
    707120eff3d3:	mov    rcx,r14
    707120eff3d6:	or     r15,rcx
    707120eff3d9:	mov    r14,QWORD PTR [rsp+0x30]
    707120eff3de:	shr    r14,0x20
    707120eff3e2:	and    r14,0xff
    707120eff3e9:	and    r14,0xffff
    707120eff3f0:	mov    rcx,r14
    707120eff3f3:	or     r13,rcx
    707120eff3f6:	mov    r14,QWORD PTR [rsp+0x30]
    707120eff3fb:	shr    r14,0x28
    707120eff3ff:	and    r14,0xff
    707120eff406:	and    r14,0xffff
    707120eff40d:	shl    r14,0x10
    707120eff411:	mov    rcx,r14
    707120eff414:	or     r13,rcx
    707120eff417:	mov    r14,QWORD PTR [rsp+0x30]
    707120eff41c:	shr    r14,0x30
    707120eff420:	and    r14,0xff
    707120eff427:	and    r14,0xffff
    707120eff42e:	shl    r14,0x20
    707120eff432:	mov    rcx,r14
    707120eff435:	or     r13,rcx
    707120eff438:	mov    r14,QWORD PTR [rsp+0x30]
    707120eff43d:	shr    r14,0x38
    707120eff441:	and    r14,0xff
    707120eff448:	and    r14,0xffff
    707120eff44f:	shl    r14,0x30
    707120eff453:	mov    rcx,r14
    707120eff456:	or     r13,rcx
    707120eff459:	mov    QWORD PTR [r12+0x150],r15
    707120eff461:	mov    QWORD PTR [r12+0x158],r13
    707120eff469:	mov    r13d,0x0
    707120eff46f:	mov    r14,QWORD PTR [rsp+0x28]
    707120eff474:	and    r14,0xff
    707120eff47b:	and    r14,0xffff
    707120eff482:	mov    rcx,r14
    707120eff485:	mov    r15,r13
    707120eff488:	or     r15,rcx
    707120eff48b:	mov    r14,QWORD PTR [rsp+0x28]
    707120eff490:	shr    r14,0x8
    707120eff494:	and    r14,0xff
    707120eff49b:	and    r14,0xffff
    707120eff4a2:	shl    r14,0x10
    707120eff4a6:	mov    rcx,r14
    707120eff4a9:	or     r15,rcx
    707120eff4ac:	mov    r14,QWORD PTR [rsp+0x28]
    707120eff4b1:	shr    r14,0x10
    707120eff4b5:	and    r14,0xff
    707120eff4bc:	and    r14,0xffff
    707120eff4c3:	shl    r14,0x20
    707120eff4c7:	mov    rcx,r14
    707120eff4ca:	or     r15,rcx
    707120eff4cd:	mov    r14,QWORD PTR [rsp+0x28]
    707120eff4d2:	shr    r14,0x18
    707120eff4d6:	and    r14,0xff
    707120eff4dd:	and    r14,0xffff
    707120eff4e4:	shl    r14,0x30
    707120eff4e8:	mov    rcx,r14
    707120eff4eb:	or     r15,rcx
    707120eff4ee:	mov    r14,QWORD PTR [rsp+0x28]
    707120eff4f3:	shr    r14,0x20
    707120eff4f7:	and    r14,0xff
    707120eff4fe:	and    r14,0xffff
    707120eff505:	mov    rcx,r14
    707120eff508:	or     r13,rcx
    707120eff50b:	mov    r14,QWORD PTR [rsp+0x28]
    707120eff510:	shr    r14,0x28
    707120eff514:	and    r14,0xff
    707120eff51b:	and    r14,0xffff
    707120eff522:	shl    r14,0x10
    707120eff526:	mov    rcx,r14
    707120eff529:	or     r13,rcx
    707120eff52c:	mov    r14,QWORD PTR [rsp+0x28]
    707120eff531:	shr    r14,0x30
    707120eff535:	and    r14,0xff
    707120eff53c:	and    r14,0xffff
    707120eff543:	shl    r14,0x20
    707120eff547:	mov    rcx,r14
    707120eff54a:	or     r13,rcx
    707120eff54d:	mov    r14,QWORD PTR [rsp+0x28]
    707120eff552:	shr    r14,0x38
    707120eff556:	and    r14,0xff
    707120eff55d:	and    r14,0xffff
    707120eff564:	shl    r14,0x30
    707120eff568:	mov    rcx,r14
    707120eff56b:	or     r13,rcx
    707120eff56e:	mov    QWORD PTR [r12+0x160],r15
    707120eff576:	mov    QWORD PTR [r12+0x168],r13
    707120eff57e:	mov    r13,QWORD PTR [r12+0x110]
    707120eff586:	mov    r14d,0x0
    707120eff58c:	mov    r15,r13
    707120eff58f:	and    r15,0xff
    707120eff596:	and    r15,0xffff
    707120eff59d:	mov    rcx,r15
    707120eff5a0:	mov    rbp,r14
    707120eff5a3:	or     rbp,rcx
    707120eff5a6:	mov    r15,r13
    707120eff5a9:	shr    r15,0x8
    707120eff5ad:	and    r15,0xff
    707120eff5b4:	and    r15,0xffff
    707120eff5bb:	shl    r15,0x10
    707120eff5bf:	mov    rcx,r15
    707120eff5c2:	or     rbp,rcx
    707120eff5c5:	mov    r15,r13
    707120eff5c8:	shr    r15,0x10
    707120eff5cc:	and    r15,0xff
    707120eff5d3:	and    r15,0xffff
    707120eff5da:	shl    r15,0x20
    707120eff5de:	mov    rcx,r15
    707120eff5e1:	or     rbp,rcx
    707120eff5e4:	mov    r15,r13
    707120eff5e7:	shr    r15,0x18
    707120eff5eb:	and    r15,0xff
    707120eff5f2:	and    r15,0xffff
    707120eff5f9:	shl    r15,0x30
    707120eff5fd:	mov    rcx,r15
    707120eff600:	or     rbp,rcx
    707120eff603:	mov    r15,r13
    707120eff606:	shr    r15,0x20
    707120eff60a:	and    r15,0xff
    707120eff611:	and    r15,0xffff
    707120eff618:	mov    rcx,r15
    707120eff61b:	or     r14,rcx
    707120eff61e:	mov    r15,r13
    707120eff621:	shr    r15,0x28
    707120eff625:	and    r15,0xff
    707120eff62c:	and    r15,0xffff
    707120eff633:	shl    r15,0x10
    707120eff637:	mov    rcx,r15
    707120eff63a:	or     r14,rcx
    707120eff63d:	mov    r15,r13
    707120eff640:	shr    r15,0x30
    707120eff644:	and    r15,0xff
    707120eff64b:	and    r15,0xffff
    707120eff652:	shl    r15,0x20
    707120eff656:	mov    rcx,r15
    707120eff659:	or     r14,rcx
    707120eff65c:	shr    r13,0x38
    707120eff660:	and    r13,0xff
    707120eff667:	and    r13,0xffff
    707120eff66e:	shl    r13,0x30
    707120eff672:	mov    rcx,r13
    707120eff675:	or     r14,rcx
    707120eff678:	mov    QWORD PTR [r12+0x170],rbp
    707120eff680:	mov    QWORD PTR [r12+0x178],r14
    707120eff688:	mov    r13,QWORD PTR [r12+0x118]
    707120eff690:	mov    r14d,0x0
    707120eff696:	mov    r15,r13
    707120eff699:	and    r15,0xff
    707120eff6a0:	and    r15,0xffff
    707120eff6a7:	mov    rcx,r15
    707120eff6aa:	mov    rbp,r14
    707120eff6ad:	or     rbp,rcx
    707120eff6b0:	mov    r15,r13
    707120eff6b3:	shr    r15,0x8
    707120eff6b7:	and    r15,0xff
    707120eff6be:	and    r15,0xffff
    707120eff6c5:	shl    r15,0x10
    707120eff6c9:	mov    rcx,r15
    707120eff6cc:	or     rbp,rcx
    707120eff6cf:	mov    r15,r13
    707120eff6d2:	shr    r15,0x10
    707120eff6d6:	and    r15,0xff
    707120eff6dd:	and    r15,0xffff
    707120eff6e4:	shl    r15,0x20
    707120eff6e8:	mov    rcx,r15
    707120eff6eb:	or     rbp,rcx
    707120eff6ee:	mov    r15,r13
    707120eff6f1:	shr    r15,0x18
    707120eff6f5:	and    r15,0xff
    707120eff6fc:	and    r15,0xffff
    707120eff703:	shl    r15,0x30
    707120eff707:	mov    rcx,r15
    707120eff70a:	or     rbp,rcx
    707120eff70d:	mov    r15,r13
    707120eff710:	shr    r15,0x20
    707120eff714:	and    r15,0xff
    707120eff71b:	and    r15,0xffff
    707120eff722:	mov    rcx,r15
    707120eff725:	or     r14,rcx
    707120eff728:	mov    r15,r13
    707120eff72b:	shr    r15,0x28
    707120eff72f:	and    r15,0xff
    707120eff736:	and    r15,0xffff
    707120eff73d:	shl    r15,0x10
    707120eff741:	mov    rcx,r15
    707120eff744:	or     r14,rcx
    707120eff747:	mov    r15,r13
    707120eff74a:	shr    r15,0x30
    707120eff74e:	and    r15,0xff
    707120eff755:	and    r15,0xffff
    707120eff75c:	shl    r15,0x20
    707120eff760:	mov    rcx,r15
    707120eff763:	or     r14,rcx
    707120eff766:	shr    r13,0x38
    707120eff76a:	and    r13,0xff
    707120eff771:	and    r13,0xffff
    707120eff778:	shl    r13,0x30
    707120eff77c:	mov    rcx,r13
    707120eff77f:	or     r14,rcx
    707120eff782:	mov    QWORD PTR [r12+0x180],rbp
    707120eff78a:	mov    QWORD PTR [r12+0x188],r14
    707120eff792:	mov    r13,QWORD PTR [r12+0x128]
    707120eff79a:	mov    r14d,0x0
    707120eff7a0:	mov    r15,r13
    707120eff7a3:	and    r15,0xff
    707120eff7aa:	and    r15,0xffff
    707120eff7b1:	mov    rcx,r15
    707120eff7b4:	mov    rbp,r14
    707120eff7b7:	or     rbp,rcx
    707120eff7ba:	mov    r15,r13
    707120eff7bd:	shr    r15,0x8
    707120eff7c1:	and    r15,0xff
    707120eff7c8:	and    r15,0xffff
    707120eff7cf:	shl    r15,0x10
    707120eff7d3:	mov    rcx,r15
    707120eff7d6:	or     rbp,rcx
    707120eff7d9:	mov    r15,r13
    707120eff7dc:	shr    r15,0x10
    707120eff7e0:	and    r15,0xff
    707120eff7e7:	and    r15,0xffff
    707120eff7ee:	shl    r15,0x20
    707120eff7f2:	mov    rcx,r15
    707120eff7f5:	or     rbp,rcx
    707120eff7f8:	mov    r15,r13
    707120eff7fb:	shr    r15,0x18
    707120eff7ff:	and    r15,0xff
    707120eff806:	and    r15,0xffff
    707120eff80d:	shl    r15,0x30
    707120eff811:	mov    rcx,r15
    707120eff814:	or     rbp,rcx
    707120eff817:	mov    r15,r13
    707120eff81a:	shr    r15,0x20
    707120eff81e:	and    r15,0xff
    707120eff825:	and    r15,0xffff
    707120eff82c:	mov    rcx,r15
    707120eff82f:	or     r14,rcx
    707120eff832:	mov    r15,r13
    707120eff835:	shr    r15,0x28
    707120eff839:	and    r15,0xff
    707120eff840:	and    r15,0xffff
    707120eff847:	shl    r15,0x10
    707120eff84b:	mov    rcx,r15
    707120eff84e:	or     r14,rcx
    707120eff851:	mov    r15,r13
    707120eff854:	shr    r15,0x30
    707120eff858:	and    r15,0xff
    707120eff85f:	and    r15,0xffff
    707120eff866:	shl    r15,0x20
    707120eff86a:	mov    rcx,r15
    707120eff86d:	or     r14,rcx
    707120eff870:	shr    r13,0x38
    707120eff874:	and    r13,0xff
    707120eff87b:	and    r13,0xffff
    707120eff882:	shl    r13,0x30
    707120eff886:	mov    rcx,r13
    707120eff889:	or     r14,rcx
    707120eff88c:	mov    QWORD PTR [r12+0x210],rbp
    707120eff894:	mov    QWORD PTR [r12+0x218],r14
    707120eff89c:	mov    r13,QWORD PTR [r12+0x138]
    707120eff8a4:	mov    r14d,0x0
    707120eff8aa:	mov    r15,r13
    707120eff8ad:	and    r15,0xff
    707120eff8b4:	and    r15,0xffff
    707120eff8bb:	mov    rcx,r15
    707120eff8be:	mov    rbp,r14
    707120eff8c1:	or     rbp,rcx
    707120eff8c4:	mov    r15,r13
    707120eff8c7:	shr    r15,0x8
    707120eff8cb:	and    r15,0xff
    707120eff8d2:	and    r15,0xffff
    707120eff8d9:	shl    r15,0x10
    707120eff8dd:	mov    rcx,r15
    707120eff8e0:	or     rbp,rcx
    707120eff8e3:	mov    r15,r13
    707120eff8e6:	shr    r15,0x10
    707120eff8ea:	and    r15,0xff
    707120eff8f1:	and    r15,0xffff
    707120eff8f8:	shl    r15,0x20
    707120eff8fc:	mov    rcx,r15
    707120eff8ff:	or     rbp,rcx
    707120eff902:	mov    r15,r13
    707120eff905:	shr    r15,0x18
    707120eff909:	and    r15,0xff
    707120eff910:	and    r15,0xffff
    707120eff917:	shl    r15,0x30
    707120eff91b:	mov    rcx,r15
    707120eff91e:	or     rbp,rcx
    707120eff921:	mov    r15,r13
    707120eff924:	shr    r15,0x20
    707120eff928:	and    r15,0xff
    707120eff92f:	and    r15,0xffff
    707120eff936:	mov    rcx,r15
    707120eff939:	or     r14,rcx
    707120eff93c:	mov    r15,r13
    707120eff93f:	shr    r15,0x28
    707120eff943:	and    r15,0xff
    707120eff94a:	and    r15,0xffff
    707120eff951:	shl    r15,0x10
    707120eff955:	mov    rcx,r15
    707120eff958:	or     r14,rcx
    707120eff95b:	mov    r15,r13
    707120eff95e:	shr    r15,0x30
    707120eff962:	and    r15,0xff
    707120eff969:	and    r15,0xffff
    707120eff970:	shl    r15,0x20
    707120eff974:	mov    rcx,r15
    707120eff977:	or     r14,rcx
    707120eff97a:	shr    r13,0x38
    707120eff97e:	and    r13,0xff
    707120eff985:	and    r13,0xffff
    707120eff98c:	shl    r13,0x30
    707120eff990:	mov    rcx,r13
    707120eff993:	or     r14,rcx
    707120eff996:	mov    QWORD PTR [r12+0x220],rbp
    707120eff99e:	mov    QWORD PTR [r12+0x228],r14
    707120eff9a6:	mov    r13,QWORD PTR [r12+0x140]
    707120eff9ae:	mov    r14d,0x0
    707120eff9b4:	mov    r15,r13
    707120eff9b7:	and    r15,0xff
    707120eff9be:	and    r15,0xffff
    707120eff9c5:	mov    rcx,r15
    707120eff9c8:	mov    rbp,r14
    707120eff9cb:	or     rbp,rcx
    707120eff9ce:	mov    r15,r13
    707120eff9d1:	shr    r15,0x8
    707120eff9d5:	and    r15,0xff
    707120eff9dc:	and    r15,0xffff
    707120eff9e3:	shl    r15,0x10
    707120eff9e7:	mov    rcx,r15
    707120eff9ea:	or     rbp,rcx
    707120eff9ed:	mov    r15,r13
    707120eff9f0:	shr    r15,0x10
    707120eff9f4:	and    r15,0xff
    707120eff9fb:	and    r15,0xffff
    707120effa02:	shl    r15,0x20
    707120effa06:	mov    rcx,r15
    707120effa09:	or     rbp,rcx
    707120effa0c:	mov    r15,r13
    707120effa0f:	shr    r15,0x18
    707120effa13:	and    r15,0xff
    707120effa1a:	and    r15,0xffff
    707120effa21:	shl    r15,0x30
    707120effa25:	mov    rcx,r15
    707120effa28:	or     rbp,rcx
    707120effa2b:	mov    r15,r13
    707120effa2e:	shr    r15,0x20
    707120effa32:	and    r15,0xff
    707120effa39:	and    r15,0xffff
    707120effa40:	mov    rcx,r15
    707120effa43:	or     r14,rcx
    707120effa46:	mov    r15,r13
    707120effa49:	shr    r15,0x28
    707120effa4d:	and    r15,0xff
    707120effa54:	and    r15,0xffff
    707120effa5b:	shl    r15,0x10
    707120effa5f:	mov    rcx,r15
    707120effa62:	or     r14,rcx
    707120effa65:	mov    r15,r13
    707120effa68:	shr    r15,0x30
    707120effa6c:	and    r15,0xff
    707120effa73:	and    r15,0xffff
    707120effa7a:	shl    r15,0x20
    707120effa7e:	mov    rcx,r15
    707120effa81:	or     r14,rcx
    707120effa84:	shr    r13,0x38
    707120effa88:	and    r13,0xff
    707120effa8f:	and    r13,0xffff
    707120effa96:	shl    r13,0x30
    707120effa9a:	mov    rcx,r13
    707120effa9d:	or     r14,rcx
    707120effaa0:	mov    QWORD PTR [r12+0x250],rbp
    707120effaa8:	mov    QWORD PTR [r12+0x258],r14
    707120effab0:	mov    r13,QWORD PTR [r12+0x148]
    707120effab8:	mov    r14d,0x0
    707120effabe:	mov    r15,r13
    707120effac1:	and    r15,0xff
    707120effac8:	and    r15,0xffff
    707120effacf:	mov    rcx,r15
    707120effad2:	mov    rbp,r14
    707120effad5:	or     rbp,rcx
    707120effad8:	mov    r15,r13
    707120effadb:	shr    r15,0x8
    707120effadf:	and    r15,0xff
    707120effae6:	and    r15,0xffff
    707120effaed:	shl    r15,0x10
    707120effaf1:	mov    rcx,r15
    707120effaf4:	or     rbp,rcx
    707120effaf7:	mov    r15,r13
    707120effafa:	shr    r15,0x10
    707120effafe:	and    r15,0xff
    707120effb05:	and    r15,0xffff
    707120effb0c:	shl    r15,0x20
    707120effb10:	mov    rcx,r15
    707120effb13:	or     rbp,rcx
    707120effb16:	mov    r15,r13
    707120effb19:	shr    r15,0x18
    707120effb1d:	and    r15,0xff
    707120effb24:	and    r15,0xffff
    707120effb2b:	shl    r15,0x30
    707120effb2f:	mov    rcx,r15
    707120effb32:	or     rbp,rcx
    707120effb35:	mov    r15,r13
    707120effb38:	shr    r15,0x20
    707120effb3c:	and    r15,0xff
    707120effb43:	and    r15,0xffff
    707120effb4a:	mov    rcx,r15
    707120effb4d:	or     r14,rcx
    707120effb50:	mov    r15,r13
    707120effb53:	shr    r15,0x28
    707120effb57:	and    r15,0xff
    707120effb5e:	and    r15,0xffff
    707120effb65:	shl    r15,0x10
    707120effb69:	mov    rcx,r15
    707120effb6c:	or     r14,rcx
    707120effb6f:	mov    r15,r13
    707120effb72:	shr    r15,0x30
    707120effb76:	and    r15,0xff
    707120effb7d:	and    r15,0xffff
    707120effb84:	shl    r15,0x20
    707120effb88:	mov    rcx,r15
    707120effb8b:	or     r14,rcx
    707120effb8e:	shr    r13,0x38
    707120effb92:	and    r13,0xff
    707120effb99:	and    r13,0xffff
    707120effba0:	shl    r13,0x30
    707120effba4:	mov    rcx,r13
    707120effba7:	or     r14,rcx
    707120effbaa:	mov    QWORD PTR [r12+0x110],rbp
    707120effbb2:	mov    QWORD PTR [r12+0x118],r14
    707120effbba:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120effbc4:	movdqa xmm2,xmm0
    707120effbc8:	pxor   xmm0,xmm0
    707120effbcc:	movdqa xmm3,xmm0
    707120effbd0:	movdqa xmm0,xmm2
    707120effbd4:	movdqa xmm1,xmm3
    707120effbd8:	punpcklwd xmm0,xmm1
    707120effbdc:	movdqa xmm4,xmm0
    707120effbe0:	movdqa xmm0,xmm4
    707120effbe4:	pslld  xmm0,0x10
    707120effbe9:	movdqa xmm2,xmm0
    707120effbed:	movdqa xmm0,xmm2
    707120effbf1:	movdqu XMMWORD PTR [r12+0x230],xmm0
    707120effbfb:	mov    r13,QWORD PTR [r12+0x160]
    707120effc03:	mov    r14d,0x0
    707120effc09:	mov    r15,r13
    707120effc0c:	and    r15,0xffff
    707120effc13:	shl    r15,0x8
    707120effc17:	mov    ecx,0xffffffff
    707120effc1c:	and    r15,rcx
    707120effc1f:	mov    rcx,r15
    707120effc22:	mov    rbp,r14
    707120effc25:	or     rbp,rcx
    707120effc28:	mov    r15,r13
    707120effc2b:	shr    r15,0x10
    707120effc2f:	and    r15,0xffff
    707120effc36:	shl    r15,0x8
    707120effc3a:	mov    ecx,0xffffffff
    707120effc3f:	and    r15,rcx
    707120effc42:	shl    r15,0x20
    707120effc46:	mov    rcx,r15
    707120effc49:	or     rbp,rcx
    707120effc4c:	mov    r15,r13
    707120effc4f:	shr    r15,0x20
    707120effc53:	and    r15,0xffff
    707120effc5a:	shl    r15,0x8
    707120effc5e:	mov    ecx,0xffffffff
    707120effc63:	and    r15,rcx
    707120effc66:	mov    rcx,r15
    707120effc69:	or     r14,rcx
    707120effc6c:	shr    r13,0x30
    707120effc70:	and    r13,0xffff
    707120effc77:	shl    r13,0x8
    707120effc7b:	mov    ecx,0xffffffff
    707120effc80:	and    r13,rcx
    707120effc83:	shl    r13,0x20
    707120effc87:	mov    rcx,r13
    707120effc8a:	or     r14,rcx
    707120effc8d:	mov    QWORD PTR [r12+0x240],rbp
    707120effc95:	mov    QWORD PTR [r12+0x248],r14
    707120effc9d:	mov    r13,QWORD PTR [r12+0x178]
    707120effca5:	mov    r14d,0x0
    707120effcab:	mov    r15,r13
    707120effcae:	and    r15,0xffff
    707120effcb5:	mov    ecx,0xffffffff
    707120effcba:	and    r15,rcx
    707120effcbd:	mov    rcx,r15
    707120effcc0:	mov    rbp,r14
    707120effcc3:	or     rbp,rcx
    707120effcc6:	mov    r15,r13
    707120effcc9:	shr    r15,0x10
    707120effccd:	and    r15,0xffff
    707120effcd4:	mov    ecx,0xffffffff
    707120effcd9:	and    r15,rcx
    707120effcdc:	shl    r15,0x20
    707120effce0:	mov    rcx,r15
    707120effce3:	or     rbp,rcx
    707120effce6:	mov    r15,r13
    707120effce9:	shr    r15,0x20
    707120effced:	and    r15,0xffff
    707120effcf4:	mov    ecx,0xffffffff
    707120effcf9:	and    r15,rcx
    707120effcfc:	mov    rcx,r15
    707120effcff:	or     r14,rcx
    707120effd02:	shr    r13,0x30
    707120effd06:	and    r13,0xffff
    707120effd0d:	mov    ecx,0xffffffff
    707120effd12:	and    r13,rcx
    707120effd15:	shl    r13,0x20
    707120effd19:	mov    rcx,r13
    707120effd1c:	or     r14,rcx
    707120effd1f:	mov    QWORD PTR [r12+0x260],rbp
    707120effd27:	mov    QWORD PTR [r12+0x268],r14
    707120effd2f:	mov    r13,QWORD PTR [r12+0x188]
    707120effd37:	mov    r14d,0x0
    707120effd3d:	mov    r15,r13
    707120effd40:	and    r15,0xffff
    707120effd47:	mov    ecx,0xffffffff
    707120effd4c:	and    r15,rcx
    707120effd4f:	mov    rcx,r15
    707120effd52:	mov    rbp,r14
    707120effd55:	or     rbp,rcx
    707120effd58:	mov    r15,r13
    707120effd5b:	shr    r15,0x10
    707120effd5f:	and    r15,0xffff
    707120effd66:	mov    ecx,0xffffffff
    707120effd6b:	and    r15,rcx
    707120effd6e:	shl    r15,0x20
    707120effd72:	mov    rcx,r15
    707120effd75:	or     rbp,rcx
    707120effd78:	mov    r15,r13
    707120effd7b:	shr    r15,0x20
    707120effd7f:	and    r15,0xffff
    707120effd86:	mov    ecx,0xffffffff
    707120effd8b:	and    r15,rcx
    707120effd8e:	mov    rcx,r15
    707120effd91:	or     r14,rcx
    707120effd94:	shr    r13,0x30
    707120effd98:	and    r13,0xffff
    707120effd9f:	mov    ecx,0xffffffff
    707120effda4:	and    r13,rcx
    707120effda7:	shl    r13,0x20
    707120effdab:	mov    rcx,r13
    707120effdae:	or     r14,rcx
    707120effdb1:	mov    QWORD PTR [r12+0x270],rbp
    707120effdb9:	mov    QWORD PTR [r12+0x278],r14
    707120effdc1:	mov    r13,QWORD PTR [r12+0x170]
    707120effdc9:	mov    r14d,0x0
    707120effdcf:	mov    r15,r13
    707120effdd2:	and    r15,0xffff
    707120effdd9:	mov    ecx,0xffffffff
    707120effdde:	and    r15,rcx
    707120effde1:	mov    rcx,r15
    707120effde4:	mov    rbp,r14
    707120effde7:	or     rbp,rcx
    707120effdea:	mov    r15,r13
    707120effded:	shr    r15,0x10
    707120effdf1:	and    r15,0xffff
    707120effdf8:	mov    ecx,0xffffffff
    707120effdfd:	and    r15,rcx
    707120effe00:	shl    r15,0x20
    707120effe04:	mov    rcx,r15
    707120effe07:	or     rbp,rcx
    707120effe0a:	mov    r15,r13
    707120effe0d:	shr    r15,0x20
    707120effe11:	and    r15,0xffff
    707120effe18:	mov    ecx,0xffffffff
    707120effe1d:	and    r15,rcx
    707120effe20:	mov    rcx,r15
    707120effe23:	or     r14,rcx
    707120effe26:	shr    r13,0x30
    707120effe2a:	and    r13,0xffff
    707120effe31:	mov    ecx,0xffffffff
    707120effe36:	and    r13,rcx
    707120effe39:	shl    r13,0x20
    707120effe3d:	mov    rcx,r13
    707120effe40:	or     r14,rcx
    707120effe43:	mov    QWORD PTR [r12+0x170],rbp
    707120effe4b:	mov    QWORD PTR [r12+0x178],r14
    707120effe53:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120effe5d:	movdqa xmm2,xmm0
    707120effe61:	pxor   xmm0,xmm0
    707120effe65:	movdqa xmm3,xmm0
    707120effe69:	movdqa xmm0,xmm2
    707120effe6d:	movdqa xmm1,xmm3
    707120effe71:	punpckhwd xmm0,xmm1
    707120effe75:	movdqa xmm4,xmm0
    707120effe79:	movdqa xmm0,xmm4
    707120effe7d:	pslld  xmm0,0x10
    707120effe82:	movdqa xmm3,xmm0
    707120effe86:	movdqa xmm0,xmm3
    707120effe8a:	movdqu XMMWORD PTR [r12+0x280],xmm0
    707120effe94:	mov    r13,QWORD PTR [r12+0x180]
    707120effe9c:	mov    r14d,0x0
    707120effea2:	mov    r15,r13
    707120effea5:	and    r15,0xffff
    707120effeac:	mov    ecx,0xffffffff
    707120effeb1:	and    r15,rcx
    707120effeb4:	mov    rcx,r15
    707120effeb7:	mov    rbp,r14
    707120effeba:	or     rbp,rcx
    707120effebd:	mov    r15,r13
    707120effec0:	shr    r15,0x10
    707120effec4:	and    r15,0xffff
    707120effecb:	mov    ecx,0xffffffff
    707120effed0:	and    r15,rcx
    707120effed3:	shl    r15,0x20
    707120effed7:	mov    rcx,r15
    707120effeda:	or     rbp,rcx
    707120effedd:	mov    r15,r13
    707120effee0:	shr    r15,0x20
    707120effee4:	and    r15,0xffff
    707120effeeb:	mov    ecx,0xffffffff
    707120effef0:	and    r15,rcx
    707120effef3:	mov    rcx,r15
    707120effef6:	or     r14,rcx
    707120effef9:	shr    r13,0x30
    707120effefd:	and    r13,0xffff
    707120efff04:	mov    ecx,0xffffffff
    707120efff09:	and    r13,rcx
    707120efff0c:	shl    r13,0x20
    707120efff10:	mov    rcx,r13
    707120efff13:	or     r14,rcx
    707120efff16:	mov    QWORD PTR [r12+0x180],rbp
    707120efff1e:	mov    QWORD PTR [r12+0x188],r14
    707120efff26:	pxor   xmm0,xmm0
    707120efff2a:	movdqa xmm3,xmm0
    707120efff2e:	movdqa xmm0,xmm2
    707120efff32:	movdqa xmm1,xmm3
    707120efff36:	punpcklwd xmm0,xmm1
    707120efff3a:	movdqa xmm4,xmm0
    707120efff3e:	movdqa xmm0,xmm4
    707120efff42:	pslld  xmm0,0x10
    707120efff47:	movdqa xmm2,xmm0
    707120efff4b:	movdqa xmm0,xmm2
    707120efff4f:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120efff59:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120efff63:	movdqa xmm2,xmm0
    707120efff67:	pxor   xmm0,xmm0
    707120efff6b:	movdqa xmm3,xmm0
    707120efff6f:	movdqa xmm0,xmm2
    707120efff73:	movdqa xmm1,xmm3
    707120efff77:	punpckhwd xmm0,xmm1
    707120efff7b:	movdqa xmm4,xmm0
    707120efff7f:	movdqa xmm0,xmm4
    707120efff83:	pslld  xmm0,0x10
    707120efff88:	movdqa xmm2,xmm0
    707120efff8c:	movdqa xmm0,xmm2
    707120efff90:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120efff9a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    707120efffa4:	movdqa xmm2,xmm0
    707120efffa8:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120efffb2:	movdqa xmm3,xmm0
    707120efffb6:	movdqa xmm1,xmm2
    707120efffba:	por    xmm3,xmm1
    707120efffbe:	movdqa xmm0,xmm3
    707120efffc2:	movdqu XMMWORD PTR [r12+0x230],xmm0
    707120efffcc:	mov    r13,QWORD PTR [r12+0x228]
    707120efffd4:	mov    r14d,0x0
    707120efffda:	mov    r15,r13
    707120efffdd:	and    r15,0xffff
    707120efffe4:	shl    r15,0x8
    707120efffe8:	mov    ecx,0xffffffff
    707120efffed:	and    r15,rcx
    707120effff0:	mov    rcx,r15
    707120effff3:	mov    rbp,r14
    707120effff6:	or     rbp,rcx
    707120effff9:	mov    r15,r13
    707120effffc:	shr    r15,0x10
    707120f00000:	and    r15,0xffff
    707120f00007:	shl    r15,0x8
    707120f0000b:	mov    ecx,0xffffffff
    707120f00010:	and    r15,rcx
    707120f00013:	shl    r15,0x20
    707120f00017:	mov    rcx,r15
    707120f0001a:	or     rbp,rcx
    707120f0001d:	mov    r15,r13
    707120f00020:	shr    r15,0x20
    707120f00024:	and    r15,0xffff
    707120f0002b:	shl    r15,0x8
    707120f0002f:	mov    ecx,0xffffffff
    707120f00034:	and    r15,rcx
    707120f00037:	mov    rcx,r15
    707120f0003a:	or     r14,rcx
    707120f0003d:	shr    r13,0x30
    707120f00041:	and    r13,0xffff
    707120f00048:	shl    r13,0x8
    707120f0004c:	mov    ecx,0xffffffff
    707120f00051:	and    r13,rcx
    707120f00054:	shl    r13,0x20
    707120f00058:	mov    rcx,r13
    707120f0005b:	or     r14,rcx
    707120f0005e:	mov    QWORD PTR [r12+0x240],rbp
    707120f00066:	mov    QWORD PTR [r12+0x248],r14
    707120f0006e:	mov    r13,QWORD PTR [r12+0x220]
    707120f00076:	mov    r14d,0x0
    707120f0007c:	mov    r15,r13
    707120f0007f:	and    r15,0xffff
    707120f00086:	shl    r15,0x8
    707120f0008a:	mov    ecx,0xffffffff
    707120f0008f:	and    r15,rcx
    707120f00092:	mov    rcx,r15
    707120f00095:	mov    rbp,r14
    707120f00098:	or     rbp,rcx
    707120f0009b:	mov    r15,r13
    707120f0009e:	shr    r15,0x10
    707120f000a2:	and    r15,0xffff
    707120f000a9:	shl    r15,0x8
    707120f000ad:	mov    ecx,0xffffffff
    707120f000b2:	and    r15,rcx
    707120f000b5:	shl    r15,0x20
    707120f000b9:	mov    rcx,r15
    707120f000bc:	or     rbp,rcx
    707120f000bf:	mov    r15,r13
    707120f000c2:	shr    r15,0x20
    707120f000c6:	and    r15,0xffff
    707120f000cd:	shl    r15,0x8
    707120f000d1:	mov    ecx,0xffffffff
    707120f000d6:	and    r15,rcx
    707120f000d9:	mov    rcx,r15
    707120f000dc:	or     r14,rcx
    707120f000df:	shr    r13,0x30
    707120f000e3:	and    r13,0xffff
    707120f000ea:	shl    r13,0x8
    707120f000ee:	mov    ecx,0xffffffff
    707120f000f3:	and    r13,rcx
    707120f000f6:	shl    r13,0x20
    707120f000fa:	mov    rcx,r13
    707120f000fd:	or     r14,rcx
    707120f00100:	mov    QWORD PTR [r12+0x220],rbp
    707120f00108:	mov    QWORD PTR [r12+0x228],r14
    707120f00110:	mov    r13,QWORD PTR [r12+0x168]
    707120f00118:	mov    r14d,0x0
    707120f0011e:	mov    r15,r13
    707120f00121:	and    r15,0xffff
    707120f00128:	shl    r15,0x8
    707120f0012c:	mov    ecx,0xffffffff
    707120f00131:	and    r15,rcx
    707120f00134:	mov    rcx,r15
    707120f00137:	mov    rbp,r14
    707120f0013a:	or     rbp,rcx
    707120f0013d:	mov    r15,r13
    707120f00140:	shr    r15,0x10
    707120f00144:	and    r15,0xffff
    707120f0014b:	shl    r15,0x8
    707120f0014f:	mov    ecx,0xffffffff
    707120f00154:	and    r15,rcx
    707120f00157:	shl    r15,0x20
    707120f0015b:	mov    rcx,r15
    707120f0015e:	or     rbp,rcx
    707120f00161:	mov    r15,r13
    707120f00164:	shr    r15,0x20
    707120f00168:	and    r15,0xffff
    707120f0016f:	shl    r15,0x8
    707120f00173:	mov    ecx,0xffffffff
    707120f00178:	and    r15,rcx
    707120f0017b:	mov    rcx,r15
    707120f0017e:	or     r14,rcx
    707120f00181:	shr    r13,0x30
    707120f00185:	and    r13,0xffff
    707120f0018c:	shl    r13,0x8
    707120f00190:	mov    ecx,0xffffffff
    707120f00195:	and    r13,rcx
    707120f00198:	shl    r13,0x20
    707120f0019c:	mov    rcx,r13
    707120f0019f:	or     r14,rcx
    707120f001a2:	mov    QWORD PTR [r12+0x160],rbp
    707120f001aa:	mov    QWORD PTR [r12+0x168],r14
    707120f001b2:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f001bc:	movdqa xmm2,xmm0
    707120f001c0:	movdqa xmm0,xmm2
    707120f001c4:	pslld  xmm0,0x18
    707120f001c9:	movdqa xmm3,xmm0
    707120f001cd:	movdqa xmm0,xmm3
    707120f001d1:	movdqu XMMWORD PTR [r12+0x170],xmm0
    707120f001db:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    707120f001e5:	movdqa xmm2,xmm0
    707120f001e9:	movdqa xmm0,xmm2
    707120f001ed:	pslld  xmm0,0x18
    707120f001f2:	movdqa xmm3,xmm0
    707120f001f6:	movdqa xmm0,xmm3
    707120f001fa:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f00204:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f0020e:	movdqa xmm2,xmm0
    707120f00212:	movdqa xmm0,xmm2
    707120f00216:	pslld  xmm0,0x18
    707120f0021b:	movdqa xmm3,xmm0
    707120f0021f:	movdqa xmm0,xmm3
    707120f00223:	movdqu XMMWORD PTR [r12+0x180],xmm0
    707120f0022d:	mov    r13,QWORD PTR [r12+0x250]
    707120f00235:	mov    r14d,0x0
    707120f0023b:	mov    r15,r13
    707120f0023e:	and    r15,0xffff
    707120f00245:	mov    ecx,0xffffffff
    707120f0024a:	and    r15,rcx
    707120f0024d:	mov    rcx,r15
    707120f00250:	mov    rbp,r14
    707120f00253:	or     rbp,rcx
    707120f00256:	mov    r15,r13
    707120f00259:	shr    r15,0x10
    707120f0025d:	and    r15,0xffff
    707120f00264:	mov    ecx,0xffffffff
    707120f00269:	and    r15,rcx
    707120f0026c:	shl    r15,0x20
    707120f00270:	mov    rcx,r15
    707120f00273:	or     rbp,rcx
    707120f00276:	mov    r15,r13
    707120f00279:	shr    r15,0x20
    707120f0027d:	and    r15,0xffff
    707120f00284:	mov    ecx,0xffffffff
    707120f00289:	and    r15,rcx
    707120f0028c:	mov    rcx,r15
    707120f0028f:	or     r14,rcx
    707120f00292:	shr    r13,0x30
    707120f00296:	and    r13,0xffff
    707120f0029d:	mov    ecx,0xffffffff
    707120f002a2:	and    r13,rcx
    707120f002a5:	shl    r13,0x20
    707120f002a9:	mov    rcx,r13
    707120f002ac:	or     r14,rcx
    707120f002af:	mov    QWORD PTR [r12+0x140],rbp
    707120f002b7:	mov    QWORD PTR [r12+0x148],r14
    707120f002bf:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    707120f002c9:	movdqa xmm2,xmm0
    707120f002cd:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    707120f002d7:	movdqa xmm3,xmm0
    707120f002db:	movdqa xmm1,xmm2
    707120f002df:	por    xmm3,xmm1
    707120f002e3:	movdqa xmm0,xmm3
    707120f002e7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120f002f1:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f002fb:	movdqa xmm2,xmm0
    707120f002ff:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f00309:	movdqa xmm3,xmm0
    707120f0030d:	movdqa xmm1,xmm2
    707120f00311:	por    xmm3,xmm1
    707120f00315:	movdqa xmm0,xmm3
    707120f00319:	movdqu XMMWORD PTR [r12+0x210],xmm0
    707120f00323:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    707120f0032d:	movdqa xmm2,xmm0
    707120f00331:	movdqa xmm0,xmm2
    707120f00335:	pslld  xmm0,0x18
    707120f0033a:	movdqa xmm3,xmm0
    707120f0033e:	movdqa xmm0,xmm3
    707120f00342:	movdqu XMMWORD PTR [r12+0x220],xmm0
    707120f0034c:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f00356:	movdqa xmm2,xmm0
    707120f0035a:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120f00364:	movdqa xmm3,xmm0
    707120f00368:	movdqa xmm1,xmm2
    707120f0036c:	por    xmm3,xmm1
    707120f00370:	movdqa xmm0,xmm3
    707120f00374:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120f0037e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f00388:	movdqa xmm2,xmm0
    707120f0038c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    707120f00396:	movdqa xmm3,xmm0
    707120f0039a:	movdqa xmm1,xmm2
    707120f0039e:	por    xmm3,xmm1
    707120f003a2:	movdqa xmm0,xmm3
    707120f003a6:	movdqu XMMWORD PTR [r12+0x160],xmm0
    707120f003b0:	mov    r13,QWORD PTR [r12+0x118]
    707120f003b8:	mov    r14d,0x0
    707120f003be:	mov    r15,r13
    707120f003c1:	and    r15,0xffff
    707120f003c8:	mov    ecx,0xffffffff
    707120f003cd:	and    r15,rcx
    707120f003d0:	mov    rcx,r15
    707120f003d3:	mov    rbp,r14
    707120f003d6:	or     rbp,rcx
    707120f003d9:	mov    r15,r13
    707120f003dc:	shr    r15,0x10
    707120f003e0:	and    r15,0xffff
    707120f003e7:	mov    ecx,0xffffffff
    707120f003ec:	and    r15,rcx
    707120f003ef:	shl    r15,0x20
    707120f003f3:	mov    rcx,r15
    707120f003f6:	or     rbp,rcx
    707120f003f9:	mov    r15,r13
    707120f003fc:	shr    r15,0x20
    707120f00400:	and    r15,0xffff
    707120f00407:	mov    ecx,0xffffffff
    707120f0040c:	and    r15,rcx
    707120f0040f:	mov    rcx,r15
    707120f00412:	or     r14,rcx
    707120f00415:	shr    r13,0x30
    707120f00419:	and    r13,0xffff
    707120f00420:	mov    ecx,0xffffffff
    707120f00425:	and    r13,rcx
    707120f00428:	shl    r13,0x20
    707120f0042c:	mov    rcx,r13
    707120f0042f:	or     r14,rcx
    707120f00432:	mov    QWORD PTR [r12+0x170],rbp
    707120f0043a:	mov    QWORD PTR [r12+0x178],r14
    707120f00442:	mov    r13,QWORD PTR [r12+0x110]
    707120f0044a:	mov    r14d,0x0
    707120f00450:	mov    r15,r13
    707120f00453:	and    r15,0xffff
    707120f0045a:	mov    ecx,0xffffffff
    707120f0045f:	and    r15,rcx
    707120f00462:	mov    rcx,r15
    707120f00465:	mov    rbp,r14
    707120f00468:	or     rbp,rcx
    707120f0046b:	mov    r15,r13
    707120f0046e:	shr    r15,0x10
    707120f00472:	and    r15,0xffff
    707120f00479:	mov    ecx,0xffffffff
    707120f0047e:	and    r15,rcx
    707120f00481:	shl    r15,0x20
    707120f00485:	mov    rcx,r15
    707120f00488:	or     rbp,rcx
    707120f0048b:	mov    r15,r13
    707120f0048e:	shr    r15,0x20
    707120f00492:	and    r15,0xffff
    707120f00499:	mov    ecx,0xffffffff
    707120f0049e:	and    r15,rcx
    707120f004a1:	mov    rcx,r15
    707120f004a4:	or     r14,rcx
    707120f004a7:	shr    r13,0x30
    707120f004ab:	and    r13,0xffff
    707120f004b2:	mov    ecx,0xffffffff
    707120f004b7:	and    r13,rcx
    707120f004ba:	shl    r13,0x20
    707120f004be:	mov    rcx,r13
    707120f004c1:	or     r14,rcx
    707120f004c4:	mov    QWORD PTR [r12+0x110],rbp
    707120f004cc:	mov    QWORD PTR [r12+0x118],r14
    707120f004d4:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f004de:	movdqa xmm2,xmm0
    707120f004e2:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120f004ec:	movdqa xmm3,xmm0
    707120f004f0:	movdqa xmm1,xmm2
    707120f004f4:	por    xmm3,xmm1
    707120f004f8:	movdqa xmm0,xmm3
    707120f004fc:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f00506:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f00510:	movdqa xmm2,xmm0
    707120f00514:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    707120f0051e:	movdqa xmm3,xmm0
    707120f00522:	movdqa xmm1,xmm2
    707120f00526:	por    xmm3,xmm1
    707120f0052a:	movdqa xmm0,xmm3
    707120f0052e:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120f00538:	mov    r13,QWORD PTR [r12+0x258]
    707120f00540:	mov    r14d,0x0
    707120f00546:	mov    r15,r13
    707120f00549:	and    r15,0xffff
    707120f00550:	mov    ecx,0xffffffff
    707120f00555:	and    r15,rcx
    707120f00558:	mov    rcx,r15
    707120f0055b:	mov    rbp,r14
    707120f0055e:	or     rbp,rcx
    707120f00561:	mov    r15,r13
    707120f00564:	shr    r15,0x10
    707120f00568:	and    r15,0xffff
    707120f0056f:	mov    ecx,0xffffffff
    707120f00574:	and    r15,rcx
    707120f00577:	shl    r15,0x20
    707120f0057b:	mov    rcx,r15
    707120f0057e:	or     rbp,rcx
    707120f00581:	mov    r15,r13
    707120f00584:	shr    r15,0x20
    707120f00588:	and    r15,0xffff
    707120f0058f:	mov    ecx,0xffffffff
    707120f00594:	and    r15,rcx
    707120f00597:	mov    rcx,r15
    707120f0059a:	or     r14,rcx
    707120f0059d:	shr    r13,0x30
    707120f005a1:	and    r13,0xffff
    707120f005a8:	mov    ecx,0xffffffff
    707120f005ad:	and    r13,rcx
    707120f005b0:	shl    r13,0x20
    707120f005b4:	mov    rcx,r13
    707120f005b7:	or     r14,rcx
    707120f005ba:	mov    QWORD PTR [r12+0x180],rbp
    707120f005c2:	mov    QWORD PTR [r12+0x188],r14
    707120f005ca:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    707120f005d4:	movdqa xmm2,xmm0
    707120f005d8:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120f005e2:	movdqa xmm3,xmm0
    707120f005e6:	movdqa xmm1,xmm2
    707120f005ea:	por    xmm3,xmm1
    707120f005ee:	movdqa xmm0,xmm3
    707120f005f2:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120f005fc:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120f00606:	movdqa xmm2,xmm0
    707120f0060a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    707120f00614:	movdqa xmm4,xmm0
    707120f00618:	movdqa xmm1,xmm2
    707120f0061c:	por    xmm4,xmm1
    707120f00620:	movdqa xmm0,xmm4
    707120f00624:	movdqu XMMWORD PTR [r12+0x140],xmm0
    707120f0062e:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120f00638:	movdqa xmm2,xmm0
    707120f0063c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120f00646:	movdqa xmm4,xmm0
    707120f0064a:	movdqa xmm1,xmm2
    707120f0064e:	por    xmm4,xmm1
    707120f00652:	movdqa xmm0,xmm4
    707120f00656:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120f00660:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    707120f0066a:	movdqa xmm2,xmm0
    707120f0066e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120f00678:	movdqa xmm5,xmm0
    707120f0067c:	movdqa xmm1,xmm2
    707120f00680:	por    xmm5,xmm1
    707120f00684:	movdqa xmm0,xmm5
    707120f00688:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120f00692:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    707120f0069c:	movdqa xmm2,xmm0
    707120f006a0:	movdqa xmm1,xmm2
    707120f006a4:	por    xmm3,xmm1
    707120f006a8:	movdqa xmm0,xmm3
    707120f006ac:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120f006b6:	mov    r13,QWORD PTR [r12+0xf8]
    707120f006be:	mov    r14,r13
    707120f006c1:	add    r14,0x20
    707120f006c5:	mov    r15,r14
    707120f006c8:	add    r15,0x10
    707120f006cc:	movdqu XMMWORD PTR [r14],xmm4
    707120f006d1:	mov    r14d,0x0
    707120f006d7:	mov    DWORD PTR [r12+0x32c],r14d
    707120f006df:	movdqu XMMWORD PTR [r15],xmm5
    707120f006e4:	mov    r14d,0x0
    707120f006ea:	mov    DWORD PTR [r12+0x32c],r14d
    707120f006f2:	mov    r14,r13
    707120f006f5:	add    r14,0x10
    707120f006f9:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120f00703:	movdqa xmm2,xmm0
    707120f00707:	movdqu XMMWORD PTR [r13+0x0],xmm2
    707120f0070d:	mov    r15d,0x0
    707120f00713:	mov    DWORD PTR [r12+0x32c],r15d
    707120f0071b:	movdqu XMMWORD PTR [r14],xmm3
    707120f00720:	mov    r14d,0x0
    707120f00726:	mov    DWORD PTR [r12+0x32c],r14d
    707120f0072e:	mov    r14d,DWORD PTR [r13+0x0]
    707120f00732:	mov    QWORD PTR [r12+0x60],r14
    707120f00737:	jmp    0x707120f0073c
    707120f0073c:	mov    r13,QWORD PTR [r12+0x58]
    707120f00741:	mov    r14,QWORD PTR [r12+0x48]
    707120f00746:	mov    rcx,r13
    707120f00749:	add    r14,rcx
    707120f0074c:	mov    QWORD PTR [r12+0x68],r14
    707120f00751:	add    r13,0x4
    707120f00755:	mov    QWORD PTR [r12+0x58],r13
    707120f0075a:	mov    r15,r14
    707120f0075d:	add    r15,0x4
    707120f00761:	mov    ebp,DWORD PTR [r15]
    707120f00764:	mov    QWORD PTR [r12+0x70],rbp
    707120f00769:	mov    r15,r14
    707120f0076c:	add    r15,0x38
    707120f00770:	mov    r8d,DWORD PTR [r15]
    707120f00773:	mov    QWORD PTR [r12+0x78],r8
    707120f00778:	add    r14,0x24
    707120f0077c:	mov    r15d,DWORD PTR [r14]
    707120f0077f:	mov    QWORD PTR [r12+0x90],r15
    707120f00787:	sub    r13,0xc0
    707120f0078e:	pushf
    707120f0078f:	pop    r11
    707120f00791:	mov    QWORD PTR [rsp+0x48],r11
    707120f00796:	mov    r13d,ebp
    707120f00799:	mov    r13d,r13d
    707120f0079c:	ror    r13d,0x7
    707120f007a0:	mov    QWORD PTR [r12+0x80],r13
    707120f007a8:	mov    r14d,r8d
    707120f007ab:	mov    r14d,r14d
    707120f007ae:	ror    r14d,0x11
    707120f007b2:	mov    QWORD PTR [r12+0x88],r14
    707120f007ba:	mov    r9d,DWORD PTR [r12+0x60]
    707120f007bf:	mov    ecx,r9d
    707120f007c2:	add    r15d,ecx
    707120f007c5:	mov    QWORD PTR [r12+0x60],r15
    707120f007ca:	mov    r15d,ebp
    707120f007cd:	mov    r15d,r15d
    707120f007d0:	shr    r15d,0x12
    707120f007d4:	mov    ebp,ebp
    707120f007d6:	shl    ebp,0xe
    707120f007d9:	mov    ecx,ebp
    707120f007db:	or     r15,rcx
    707120f007de:	mov    r15d,r15d
    707120f007e1:	mov    ecx,r15d
    707120f007e4:	xor    r13,rcx
    707120f007e7:	mov    r13d,r13d
    707120f007ea:	mov    QWORD PTR [r12+0x80],r13
    707120f007f2:	mov    r15d,r8d
    707120f007f5:	mov    r15d,r15d
    707120f007f8:	shr    r15d,0x13
    707120f007fc:	mov    r8d,r8d
    707120f007ff:	shl    r8d,0xd
    707120f00803:	mov    ecx,r8d
    707120f00806:	or     r15,rcx
    707120f00809:	mov    r15d,r15d
    707120f0080c:	mov    ecx,r15d
    707120f0080f:	xor    r14,rcx
    707120f00812:	mov    r14d,r14d
    707120f00815:	mov    QWORD PTR [r12+0x88],r14
    707120f0081d:	mov    r15d,DWORD PTR [r12+0x70]
    707120f00822:	mov    r15d,r15d
    707120f00825:	shr    r15d,0x3
    707120f00829:	mov    ecx,r15d
    707120f0082c:	xor    r13,rcx
    707120f0082f:	mov    r13d,r13d
    707120f00832:	mov    QWORD PTR [r12+0x80],r13
    707120f0083a:	mov    r15d,DWORD PTR [r12+0x78]
    707120f0083f:	mov    r15d,r15d
    707120f00842:	shr    r15d,0xa
    707120f00846:	mov    ecx,r15d
    707120f00849:	xor    r14,rcx
    707120f0084c:	mov    r14d,r14d
    707120f0084f:	mov    QWORD PTR [r12+0x78],r14
    707120f00854:	mov    r15d,DWORD PTR [r12+0x60]
    707120f00859:	mov    ecx,r13d
    707120f0085c:	add    r15d,ecx
    707120f0085f:	mov    QWORD PTR [r12+0x60],r15
    707120f00864:	mov    ecx,r14d
    707120f00867:	add    r15d,ecx
    707120f0086a:	mov    QWORD PTR [r12+0x60],r15
    707120f0086f:	mov    r13,QWORD PTR [r12+0x68]
    707120f00874:	add    r13,0x40
    707120f00878:	mov    DWORD PTR [r13+0x0],r15d
    707120f0087c:	mov    r13d,0x0
    707120f00882:	mov    DWORD PTR [r12+0x32c],r13d
    707120f0088a:	mov    r13d,0x0
    707120f00890:	mov    r14d,DWORD PTR [r12+0x70]
    707120f00895:	mov    ecx,r14d
    707120f00898:	mov    r15d,r13d
    707120f0089b:	or     r15,rcx
    707120f0089e:	mov    r15d,r15d
    707120f008a1:	mov    QWORD PTR [r12+0x60],r15
    707120f008a6:	mov    rcx,QWORD PTR [r12+0x380]
    707120f008ae:	jrcxz  0x707120f008b5
    707120f008b0:	jmp    0x707120f0120e
    707120f008b5:	push   QWORD PTR [rsp+0x48]
    707120f008b9:	popf
    707120f008ba:	jne    0x707120f0073c
    707120f008c0:	jmp    0x707120f008c5
    707120f008c5:	mov    r13,QWORD PTR [r12]
    707120f008c9:	mov    r14,r13
    707120f008cc:	add    r14,0x4
    707120f008d0:	mov    r15d,DWORD PTR [r13+0x0]
    707120f008d4:	mov    ebp,DWORD PTR [r14]
    707120f008d7:	mov    QWORD PTR [r12+0x78],r15
    707120f008dc:	mov    QWORD PTR [r12+0x80],rbp
    707120f008e4:	mov    r14,r13
    707120f008e7:	add    r14,0x8
    707120f008eb:	mov    r15,r14
    707120f008ee:	add    r15,0x4
    707120f008f2:	mov    ebp,DWORD PTR [r14]
    707120f008f5:	mov    r14d,DWORD PTR [r15]
    707120f008f8:	mov    QWORD PTR [r12+0x70],rbp
    707120f008fd:	mov    QWORD PTR [r12+0x68],r14
    707120f00902:	mov    r14,r13
    707120f00905:	add    r14,0x18
    707120f00909:	mov    r15,r14
    707120f0090c:	add    r15,0x4
    707120f00910:	mov    ebp,DWORD PTR [r14]
    707120f00913:	mov    r14d,DWORD PTR [r15]
    707120f00916:	mov    QWORD PTR [r12+0x58],rbp
    707120f0091b:	mov    QWORD PTR [r12+0x60],r14
    707120f00920:	add    r13,0x10
    707120f00924:	mov    r14,r13
    707120f00927:	add    r14,0x4
    707120f0092b:	mov    r15d,DWORD PTR [r13+0x0]
    707120f0092f:	mov    r13d,DWORD PTR [r14]
    707120f00932:	mov    QWORD PTR [r12+0x18],r15
    707120f00937:	mov    QWORD PTR [r12+0x90],r13
    707120f0093f:	mov    r13d,0x0
    707120f00945:	mov    QWORD PTR [r12+0x88],r13
    707120f0094d:	mov    r13d,0x0
    707120f00953:	mov    r14d,DWORD PTR [r12+0x78]
    707120f00958:	mov    ecx,r14d
    707120f0095b:	mov    r15d,r13d
    707120f0095e:	or     r15,rcx
    707120f00961:	mov    r15d,r15d
    707120f00964:	mov    QWORD PTR [r12+0xa8],r15
    707120f0096c:	mov    r13d,0x0
    707120f00972:	mov    r14d,DWORD PTR [r12+0x80]
    707120f0097a:	mov    ecx,r14d
    707120f0097d:	mov    r15d,r13d
    707120f00980:	or     r15,rcx
    707120f00983:	mov    r15d,r15d
    707120f00986:	mov    QWORD PTR [r12+0x38],r15
    707120f0098b:	mov    r13d,0x0
    707120f00991:	mov    r14d,DWORD PTR [r12+0x70]
    707120f00996:	mov    ecx,r14d
    707120f00999:	mov    r15d,r13d
    707120f0099c:	or     r15,rcx
    707120f0099f:	mov    r15d,r15d
    707120f009a2:	mov    QWORD PTR [r12+0x98],r15
    707120f009aa:	mov    r13d,0x0
    707120f009b0:	mov    r14d,DWORD PTR [r12+0x68]
    707120f009b5:	mov    ecx,r14d
    707120f009b8:	mov    r15d,r13d
    707120f009bb:	or     r15,rcx
    707120f009be:	mov    r15d,r15d
    707120f009c1:	mov    QWORD PTR [r12+0x28],r15
    707120f009c6:	mov    r13d,0x0
    707120f009cc:	mov    r14d,DWORD PTR [r12+0x60]
    707120f009d1:	mov    ecx,r14d
    707120f009d4:	mov    r15d,r13d
    707120f009d7:	or     r15,rcx
    707120f009da:	mov    r15d,r15d
    707120f009dd:	mov    QWORD PTR [r12+0xb0],r15
    707120f009e5:	mov    r13d,0x0
    707120f009eb:	mov    r14d,DWORD PTR [r12+0x58]
    707120f009f0:	mov    ecx,r14d
    707120f009f3:	mov    r15d,r13d
    707120f009f6:	or     r15,rcx
    707120f009f9:	mov    r15d,r15d
    707120f009fc:	mov    QWORD PTR [r12+0xc0],r15
    707120f00a04:	mov    r13d,0x0
    707120f00a0a:	mov    r14d,DWORD PTR [r12+0x90]
    707120f00a12:	mov    ecx,r14d
    707120f00a15:	mov    r15d,r13d
    707120f00a18:	or     r15,rcx
    707120f00a1b:	mov    r15d,r15d
    707120f00a1e:	mov    QWORD PTR [r12+0xc8],r15
    707120f00a26:	mov    r13d,0x0
    707120f00a2c:	mov    r14d,DWORD PTR [r12+0x18]
    707120f00a31:	mov    ecx,r14d
    707120f00a34:	mov    r15d,r13d
    707120f00a37:	or     r15,rcx
    707120f00a3a:	mov    r15d,r15d
    707120f00a3d:	mov    QWORD PTR [r12+0xb8],r15
    707120f00a45:	jmp    0x707120f00a4a
    707120f00a4a:	mov    r13d,0x0
    707120f00a50:	mov    r14d,DWORD PTR [r12+0xb8]
    707120f00a58:	mov    ecx,r14d
    707120f00a5b:	mov    r15d,r13d
    707120f00a5e:	or     r15,rcx
    707120f00a61:	mov    r15d,r15d
    707120f00a64:	mov    QWORD PTR [r12+0x30],r15
    707120f00a69:	mov    r13d,0x0
    707120f00a6f:	mov    r14d,DWORD PTR [r12+0xc0]
    707120f00a77:	mov    ecx,r14d
    707120f00a7a:	mov    r15d,r13d
    707120f00a7d:	or     r15,rcx
    707120f00a80:	mov    r15d,r15d
    707120f00a83:	mov    QWORD PTR [r12+0xa0],r15
    707120f00a8b:	mov    r13d,0x0
    707120f00a91:	mov    r14d,DWORD PTR [r12+0x28]
    707120f00a96:	mov    ecx,r14d
    707120f00a99:	mov    r15d,r13d
    707120f00a9c:	or     r15,rcx
    707120f00a9f:	mov    r15d,r15d
    707120f00aa2:	mov    QWORD PTR [r12+0xc0],r15
    707120f00aaa:	mov    r13d,0x0
    707120f00ab0:	mov    r14d,DWORD PTR [r12+0x98]
    707120f00ab8:	mov    ecx,r14d
    707120f00abb:	mov    r15d,r13d
    707120f00abe:	or     r15,rcx
    707120f00ac1:	mov    r15d,r15d
    707120f00ac4:	mov    QWORD PTR [r12+0x28],r15
    707120f00ac9:	mov    r13d,0x0
    707120f00acf:	mov    r14d,DWORD PTR [r12+0x38]
    707120f00ad4:	mov    ecx,r14d
    707120f00ad7:	mov    r15d,r13d
    707120f00ada:	or     r15,rcx
    707120f00add:	mov    r15d,r15d
    707120f00ae0:	mov    QWORD PTR [r12+0x98],r15
    707120f00ae8:	mov    r13d,0x0
    707120f00aee:	mov    r14d,DWORD PTR [r12+0xa8]
    707120f00af6:	mov    ecx,r14d
    707120f00af9:	mov    r15d,r13d
    707120f00afc:	or     r15,rcx
    707120f00aff:	mov    r15d,r15d
    707120f00b02:	mov    QWORD PTR [r12+0x38],r15
    707120f00b07:	mov    r13d,DWORD PTR [r12+0xb8]
    707120f00b0f:	mov    r13d,r13d
    707120f00b12:	ror    r13d,0x6
    707120f00b16:	mov    QWORD PTR [r12+0xb8],r13
    707120f00b1e:	mov    r13d,DWORD PTR [r12+0x30]
    707120f00b23:	mov    r14d,DWORD PTR [r12+0xc8]
    707120f00b2b:	mov    ecx,r14d
    707120f00b2e:	and    r13,rcx
    707120f00b31:	mov    r13d,r13d
    707120f00b34:	mov    QWORD PTR [r12+0xa8],r13
    707120f00b3c:	mov    r15d,r15d
    707120f00b3f:	ror    r15d,0x2
    707120f00b43:	mov    QWORD PTR [r12+0xd0],r15
    707120f00b4b:	mov    r13d,0x0
    707120f00b51:	mov    ecx,r14d
    707120f00b54:	mov    r15d,r13d
    707120f00b57:	or     r15,rcx
    707120f00b5a:	mov    r15d,r15d
    707120f00b5d:	mov    QWORD PTR [r12+0x20],r15
    707120f00b62:	mov    r13,QWORD PTR [r12+0x88]
    707120f00b6a:	mov    r14,QWORD PTR [r12+0x50]
    707120f00b6f:	mov    rcx,r13
    707120f00b72:	add    r14,rcx
    707120f00b75:	mov    r13d,DWORD PTR [r14]
    707120f00b78:	mov    QWORD PTR [r12+0xc8],r13
    707120f00b80:	mov    r13d,DWORD PTR [r12+0xa0]
    707120f00b88:	mov    r14d,DWORD PTR [r12+0x30]
    707120f00b8d:	mov    ecx,r14d
    707120f00b90:	not    rcx
    707120f00b93:	and    r13,rcx
    707120f00b96:	mov    r13d,r13d
    707120f00b99:	mov    QWORD PTR [r12+0xd8],r13
    707120f00ba1:	mov    r13d,DWORD PTR [r12+0xb0]
    707120f00ba9:	mov    r15d,DWORD PTR [r12+0xa8]
    707120f00bb1:	mov    ecx,r13d
    707120f00bb4:	add    r15d,ecx
    707120f00bb7:	mov    QWORD PTR [r12+0xa8],r15
    707120f00bbf:	mov    r13d,DWORD PTR [r12+0xb8]
    707120f00bc7:	mov    ebp,r14d
    707120f00bca:	mov    ebp,ebp
    707120f00bcc:	shr    ebp,0xb
    707120f00bcf:	mov    r14d,r14d
    707120f00bd2:	shl    r14d,0x15
    707120f00bd6:	mov    ecx,r14d
    707120f00bd9:	or     rbp,rcx
    707120f00bdc:	mov    ebp,ebp
    707120f00bde:	mov    ecx,ebp
    707120f00be0:	xor    r13,rcx
    707120f00be3:	mov    r13d,r13d
    707120f00be6:	mov    QWORD PTR [r12+0xb0],r13
    707120f00bee:	mov    r13d,DWORD PTR [r12+0xd0]
    707120f00bf6:	mov    r14d,DWORD PTR [r12+0x38]
    707120f00bfb:	mov    ebp,r14d
    707120f00bfe:	mov    ebp,ebp
    707120f00c00:	shr    ebp,0xd
    707120f00c03:	mov    r14d,r14d
    707120f00c06:	shl    r14d,0x13
    707120f00c0a:	mov    ecx,r14d
    707120f00c0d:	or     rbp,rcx
    707120f00c10:	mov    ebp,ebp
    707120f00c12:	mov    ecx,ebp
    707120f00c14:	xor    r13,rcx
    707120f00c17:	mov    r13d,r13d
    707120f00c1a:	mov    QWORD PTR [r12+0xd0],r13
    707120f00c22:	mov    r13d,DWORD PTR [r12+0xd8]
    707120f00c2a:	mov    ecx,r13d
    707120f00c2d:	add    r15d,ecx
    707120f00c30:	mov    QWORD PTR [r12+0xa8],r15
    707120f00c38:	mov    r13,QWORD PTR [r12+0x88]
    707120f00c40:	mov    r14,QWORD PTR [r12+0x48]
    707120f00c45:	mov    rcx,r13
    707120f00c48:	add    r14,rcx
    707120f00c4b:	mov    r13d,DWORD PTR [r14]
    707120f00c4e:	mov    QWORD PTR [r12+0xb8],r13
    707120f00c56:	mov    r13d,DWORD PTR [r12+0x28]
    707120f00c5b:	mov    r14d,DWORD PTR [r12+0x98]
    707120f00c63:	mov    ecx,r14d
    707120f00c66:	mov    ebp,r13d
    707120f00c69:	and    rbp,rcx
    707120f00c6c:	mov    ebp,ebp
    707120f00c6e:	mov    QWORD PTR [r12+0xd8],rbp
    707120f00c76:	mov    ebp,DWORD PTR [r12+0xc8]
    707120f00c7e:	mov    ecx,ebp
    707120f00c80:	add    r15d,ecx
    707120f00c83:	mov    QWORD PTR [r12+0xa8],r15
    707120f00c8b:	mov    ecx,r14d
    707120f00c8e:	xor    r13,rcx
    707120f00c91:	mov    r13d,r13d
    707120f00c94:	mov    QWORD PTR [r12+0xc8],r13
    707120f00c9c:	mov    r14d,DWORD PTR [r12+0xb0]
    707120f00ca4:	mov    r15d,DWORD PTR [r12+0x30]
    707120f00ca9:	mov    ebp,r15d
    707120f00cac:	mov    ebp,ebp
    707120f00cae:	shr    ebp,0x19
    707120f00cb1:	mov    r15d,r15d
    707120f00cb4:	shl    r15d,0x7
    707120f00cb8:	mov    ecx,r15d
    707120f00cbb:	or     rbp,rcx
    707120f00cbe:	mov    ebp,ebp
    707120f00cc0:	mov    ecx,ebp
    707120f00cc2:	xor    r14,rcx
    707120f00cc5:	mov    r14d,r14d
    707120f00cc8:	mov    QWORD PTR [r12+0xb0],r14
    707120f00cd0:	mov    r14d,DWORD PTR [r12+0x38]
    707120f00cd5:	mov    ecx,r14d
    707120f00cd8:	and    r13,rcx
    707120f00cdb:	mov    r13d,r13d
    707120f00cde:	mov    QWORD PTR [r12+0xc8],r13
    707120f00ce6:	mov    r15d,DWORD PTR [r12+0xd0]
    707120f00cee:	mov    ebp,r14d
    707120f00cf1:	mov    ebp,ebp
    707120f00cf3:	shr    ebp,0x16
    707120f00cf6:	mov    r14d,r14d
    707120f00cf9:	shl    r14d,0xa
    707120f00cfd:	mov    ecx,r14d
    707120f00d00:	or     rbp,rcx
    707120f00d03:	mov    ebp,ebp
    707120f00d05:	mov    ecx,ebp
    707120f00d07:	xor    r15,rcx
    707120f00d0a:	mov    r15d,r15d
    707120f00d0d:	mov    QWORD PTR [r12+0xd0],r15
    707120f00d15:	mov    r14d,DWORD PTR [r12+0xb8]
    707120f00d1d:	mov    r15d,DWORD PTR [r12+0xa8]
    707120f00d25:	mov    ecx,r14d
    707120f00d28:	add    r15d,ecx
    707120f00d2b:	mov    QWORD PTR [r12+0xa8],r15
    707120f00d33:	mov    r14d,DWORD PTR [r12+0xd8]
    707120f00d3b:	mov    ecx,r14d
    707120f00d3e:	xor    r13,rcx
    707120f00d41:	mov    r13d,r13d
    707120f00d44:	mov    QWORD PTR [r12+0xb8],r13
    707120f00d4c:	mov    r14d,DWORD PTR [r12+0xb0]
    707120f00d54:	mov    ecx,r14d
    707120f00d57:	add    r15d,ecx
    707120f00d5a:	mov    QWORD PTR [r12+0xa8],r15
    707120f00d62:	mov    r14,QWORD PTR [r12+0x88]
    707120f00d6a:	add    r14,0x4
    707120f00d6e:	mov    QWORD PTR [r12+0x88],r14
    707120f00d76:	mov    ebp,DWORD PTR [r12+0xd0]
    707120f00d7e:	mov    ecx,ebp
    707120f00d80:	add    r13d,ecx
    707120f00d83:	mov    QWORD PTR [r12+0xb0],r13
    707120f00d8b:	mov    ebp,DWORD PTR [r12+0xc0]
    707120f00d93:	mov    ecx,ebp
    707120f00d95:	mov    r8d,r15d
    707120f00d98:	add    r8d,ecx
    707120f00d9b:	mov    QWORD PTR [r12+0xb8],r8
    707120f00da3:	sub    r14,0x100
    707120f00daa:	pushf
    707120f00dab:	pop    r11
    707120f00dad:	mov    QWORD PTR [rsp+0x48],r11
    707120f00db2:	mov    ecx,r15d
    707120f00db5:	add    r13d,ecx
    707120f00db8:	mov    QWORD PTR [r12+0xa8],r13
    707120f00dc0:	mov    r13d,0x0
    707120f00dc6:	mov    r14d,DWORD PTR [r12+0xa0]
    707120f00dce:	mov    ecx,r14d
    707120f00dd1:	mov    r15d,r13d
    707120f00dd4:	or     r15,rcx
    707120f00dd7:	mov    r15d,r15d
    707120f00dda:	mov    QWORD PTR [r12+0xb0],r15
    707120f00de2:	mov    r13d,0x0
    707120f00de8:	mov    r14d,DWORD PTR [r12+0x20]
    707120f00ded:	mov    ecx,r14d
    707120f00df0:	mov    r15d,r13d
    707120f00df3:	or     r15,rcx
    707120f00df6:	mov    r15d,r15d
    707120f00df9:	mov    QWORD PTR [r12+0xc0],r15
    707120f00e01:	mov    r13d,0x0
    707120f00e07:	mov    r14d,DWORD PTR [r12+0x30]
    707120f00e0c:	mov    ecx,r14d
    707120f00e0f:	mov    r15d,r13d
    707120f00e12:	or     r15,rcx
    707120f00e15:	mov    r15d,r15d
    707120f00e18:	mov    QWORD PTR [r12+0xc8],r15
    707120f00e20:	mov    rcx,QWORD PTR [r12+0x380]
    707120f00e28:	jrcxz  0x707120f00e2f
    707120f00e2a:	jmp    0x707120f01295
    707120f00e2f:	push   QWORD PTR [rsp+0x48]
    707120f00e33:	popf
    707120f00e34:	jne    0x707120f00a4a
    707120f00e3a:	jmp    0x707120f00e3f
    707120f00e3f:	mov    r13d,DWORD PTR [r12+0x70]
    707120f00e44:	mov    r14d,DWORD PTR [r12+0x98]
    707120f00e4c:	mov    ecx,r13d
    707120f00e4f:	add    r14d,ecx
    707120f00e52:	mov    QWORD PTR [r12+0x70],r14
    707120f00e57:	mov    r13d,DWORD PTR [r12+0x68]
    707120f00e5c:	mov    r14d,DWORD PTR [r12+0x28]
    707120f00e61:	mov    ecx,r13d
    707120f00e64:	add    r14d,ecx
    707120f00e67:	mov    QWORD PTR [r12+0x68],r14
    707120f00e6c:	mov    r13d,0x0
    707120f00e72:	mov    QWORD PTR [r12+0x88],r13
    707120f00e7a:	mov    r13d,DWORD PTR [r12+0x78]
    707120f00e7f:	mov    r14d,DWORD PTR [r12+0xa8]
    707120f00e87:	mov    ecx,r13d
    707120f00e8a:	add    r14d,ecx
    707120f00e8d:	mov    QWORD PTR [r12+0x78],r14
    707120f00e92:	mov    r13d,DWORD PTR [r12+0x80]
    707120f00e9a:	mov    r14d,DWORD PTR [r12+0x38]
    707120f00e9f:	mov    ecx,r13d
    707120f00ea2:	add    r14d,ecx
    707120f00ea5:	mov    QWORD PTR [r12+0x80],r14
    707120f00ead:	mov    r13,QWORD PTR [r12]
    707120f00eb1:	add    r13,0x8
    707120f00eb5:	mov    r14,r13
    707120f00eb8:	add    r14,0x4
    707120f00ebc:	mov    r15d,DWORD PTR [r12+0x70]
    707120f00ec1:	mov    ebp,DWORD PTR [r12+0x68]
    707120f00ec6:	mov    DWORD PTR [r13+0x0],r15d
    707120f00eca:	mov    r13d,0x0
    707120f00ed0:	mov    DWORD PTR [r12+0x32c],r13d
    707120f00ed8:	mov    DWORD PTR [r14],ebp
    707120f00edb:	mov    r13d,0x0
    707120f00ee1:	mov    DWORD PTR [r12+0x32c],r13d
    707120f00ee9:	mov    r13d,DWORD PTR [r12+0x18]
    707120f00eee:	mov    r14d,DWORD PTR [r12+0xb8]
    707120f00ef6:	mov    ecx,r13d
    707120f00ef9:	add    r14d,ecx
    707120f00efc:	mov    QWORD PTR [r12+0x68],r14
    707120f00f01:	mov    r13d,DWORD PTR [r12+0x90]
    707120f00f09:	mov    r14d,DWORD PTR [r12+0x30]
    707120f00f0e:	mov    ecx,r13d
    707120f00f11:	add    r14d,ecx
    707120f00f14:	mov    QWORD PTR [r12+0x70],r14
    707120f00f19:	mov    r13d,DWORD PTR [r12+0x58]
    707120f00f1e:	mov    r14d,DWORD PTR [r12+0x20]
    707120f00f23:	mov    ecx,r13d
    707120f00f26:	add    r14d,ecx
    707120f00f29:	mov    QWORD PTR [r12+0x58],r14
    707120f00f2e:	mov    r13d,DWORD PTR [r12+0x60]
    707120f00f33:	mov    r14d,DWORD PTR [r12+0xa0]
    707120f00f3b:	mov    ecx,r13d
    707120f00f3e:	add    r14d,ecx
    707120f00f41:	mov    QWORD PTR [r12+0x60],r14
    707120f00f46:	mov    r13,QWORD PTR [r12]
    707120f00f4a:	mov    r15,r13
    707120f00f4d:	add    r15,0x4
    707120f00f51:	mov    ebp,DWORD PTR [r12+0x78]
    707120f00f56:	mov    r8d,DWORD PTR [r12+0x80]
    707120f00f5e:	mov    DWORD PTR [r13+0x0],ebp
    707120f00f62:	mov    ebp,0x0
    707120f00f67:	mov    DWORD PTR [r12+0x32c],ebp
    707120f00f6f:	mov    DWORD PTR [r15],r8d
    707120f00f72:	mov    r15d,0x0
    707120f00f78:	mov    DWORD PTR [r12+0x32c],r15d
    707120f00f80:	mov    r15,r13
    707120f00f83:	add    r15,0x10
    707120f00f87:	mov    rbp,r15
    707120f00f8a:	add    rbp,0x4
    707120f00f8e:	mov    r8d,DWORD PTR [r12+0x68]
    707120f00f93:	mov    r9d,DWORD PTR [r12+0x70]
    707120f00f98:	mov    DWORD PTR [r15],r8d
    707120f00f9b:	mov    r15d,0x0
    707120f00fa1:	mov    DWORD PTR [r12+0x32c],r15d
    707120f00fa9:	mov    DWORD PTR [rbp+0x0],r9d
    707120f00fad:	mov    r15d,0x0
    707120f00fb3:	mov    DWORD PTR [r12+0x32c],r15d
    707120f00fbb:	mov    r15,r13
    707120f00fbe:	add    r15,0x18
    707120f00fc2:	mov    rbp,r15
    707120f00fc5:	add    rbp,0x4
    707120f00fc9:	mov    r8d,DWORD PTR [r12+0x58]
    707120f00fce:	mov    DWORD PTR [r15],r8d
    707120f00fd1:	mov    r15d,0x0
    707120f00fd7:	mov    DWORD PTR [r12+0x32c],r15d
    707120f00fdf:	mov    DWORD PTR [rbp+0x0],r14d
    707120f00fe3:	mov    r14d,0x0
    707120f00fe9:	mov    DWORD PTR [r12+0x32c],r14d
    707120f00ff1:	add    r13,0x68
    707120f00ff5:	mov    r14d,0x0
    707120f00ffb:	mov    QWORD PTR [r13+0x0],r14
    707120f00fff:	mov    r13d,0x0
    707120f01005:	mov    DWORD PTR [r12+0x32c],r13d
    707120f0100d:	mov    rcx,QWORD PTR [r12+0x380]
    707120f01015:	jrcxz  0x707120f0101c
    707120f01017:	jmp    0x707120f0131c
    707120f0101c:	jmp    0x707120f01021
    707120f01021:	mov    r13,QWORD PTR [r12+0x10]
    707120f01026:	sub    r13,0x1
    707120f0102a:	mov    QWORD PTR [r12+0x10],r13
    707120f0102f:	mov    rax,r13
    707120f01032:	test   rax,rax
    707120f01035:	sete   al
    707120f01038:	movzx  eax,al
    707120f0103b:	and    eax,0x1
    707120f0103e:	mov    r14,rax
    707120f01041:	mov    rax,r14
    707120f01044:	and    eax,0x1
    707120f01047:	test   rax,rax
    707120f0104a:	jne    0x707120f01055
    707120f01050:	jmp    0x707120efeb77
    707120f01055:	mov    r13,QWORD PTR [r12+0xf8]
    707120f0105d:	mov    r14,r13
    707120f01060:	add    r14,0x140
    707120f01067:	mov    r15,r14
    707120f0106a:	add    r15,0x8
    707120f0106e:	mov    rbp,QWORD PTR [r14]
    707120f01071:	mov    r14,QWORD PTR [r15]
    707120f01074:	mov    QWORD PTR [r12+0xa0],rbp
    707120f0107c:	mov    QWORD PTR [r12+0x98],r14
    707120f01084:	mov    r14,r13
    707120f01087:	add    r14,0x130
    707120f0108e:	mov    r15,r14
    707120f01091:	add    r15,0x8
    707120f01095:	mov    rbp,QWORD PTR [r14]
    707120f01098:	mov    r14,QWORD PTR [r15]
    707120f0109b:	mov    QWORD PTR [r12+0xb0],rbp
    707120f010a3:	mov    QWORD PTR [r12+0xa8],r14
    707120f010ab:	mov    r14,r13
    707120f010ae:	add    r14,0x120
    707120f010b5:	mov    r15,r14
    707120f010b8:	add    r15,0x8
    707120f010bc:	mov    rbp,QWORD PTR [r14]
    707120f010bf:	mov    r14,QWORD PTR [r15]
    707120f010c2:	mov    QWORD PTR [r12+0xc0],rbp
    707120f010ca:	mov    QWORD PTR [r12+0xb8],r14
    707120f010d2:	add    r13,0x110
    707120f010d9:	mov    r14,r13
    707120f010dc:	add    r14,0x8
    707120f010e0:	mov    r15,QWORD PTR [r13+0x0]
    707120f010e4:	mov    r13,QWORD PTR [r14]
    707120f010e7:	mov    QWORD PTR [r12+0xd0],r15
    707120f010ef:	mov    QWORD PTR [r12+0xc8],r13
    707120f010f7:	mov    r13,QWORD PTR [r12+0xf8]
    707120f010ff:	mov    r14,r13
    707120f01102:	add    r14,0x100
    707120f01109:	mov    r15,r14
    707120f0110c:	add    r15,0x8
    707120f01110:	mov    rbp,QWORD PTR [r14]
    707120f01113:	mov    r14,QWORD PTR [r15]
    707120f01116:	mov    QWORD PTR [r12+0xe8],rbp
    707120f0111e:	mov    QWORD PTR [r12+0xd8],r14
    707120f01126:	add    r13,0x150
    707120f0112d:	mov    QWORD PTR [r12+0xf8],r13
    707120f01135:	jmp    0x707120f0113a
    707120f0113a:	mov    rcx,QWORD PTR [r12+0x380]
    707120f01142:	jrcxz  0x707120f01149
    707120f01144:	jmp    0x707120f013a3
    707120f01149:	mov    r13,QWORD PTR [r12+0xf0]
    707120f01151:	mov    QWORD PTR [r12+0x100],r13
    707120f01159:	mov    r11,QWORD PTR [rsp+0x48]
    707120f0115e:	mov    QWORD PTR [r12+0x398],r11
    707120f01166:	mov    rdi,QWORD PTR [r12+0x100]
    707120f0116e:	add    rsp,0x50
    707120f01172:	movabs r11,0x5ab6724ae0a0
    707120f0117c:	jmp    r11
    707120f0117f:	mov    eax,0x41078c
    707120f01184:	mov    QWORD PTR [r12+0x100],rax
    707120f0118c:	push   rdx
    707120f0118d:	push   rsi
    707120f0118e:	push   r10
    707120f01190:	push   r11
    707120f01192:	pushf
    707120f01193:	pop    r11
    707120f01195:	mov    QWORD PTR [rsp+0x68],r11
    707120f0119a:	mov    rdx,QWORD PTR [rsp+0x68]
    707120f0119f:	mov    r10d,edx
    707120f011a2:	and    r10d,0xc0
    707120f011a9:	shl    r10d,0x18
    707120f011ad:	mov    r11d,edx
    707120f011b0:	and    r11d,0x1
    707120f011b4:	shl    r11d,0x1d
    707120f011b8:	or     r10d,r11d
    707120f011bb:	mov    r11d,edx
    707120f011be:	and    r11d,0x800
    707120f011c5:	shl    r11d,0x11
    707120f011c9:	or     r10d,r11d
    707120f011cc:	btc    r10,0x1d
    707120f011d1:	mov    r11d,0xf0000000
    707120f011d7:	and    r11,r10
    707120f011da:	movabs rsi,0xffffffff0fffffff
    707120f011e4:	and    rbx,rsi
    707120f011e7:	or     rbx,r11
    707120f011ea:	pop    r11
    707120f011ec:	pop    r10
    707120f011ee:	pop    rsi
    707120f011ef:	pop    rdx
    707120f011f0:	mov    QWORD PTR [r12+0x108],rbx
    707120f011f8:	add    rsp,0x50
    707120f011fc:	mov    eax,0xc
    707120f01201:	movabs r11,0x5ab6724ae390
    707120f0120b:	jmp    r11
    707120f0120e:	mov    eax,0x410888
    707120f01213:	mov    QWORD PTR [r12+0x100],rax
    707120f0121b:	push   rdx
    707120f0121c:	push   rsi
    707120f0121d:	push   r10
    707120f0121f:	push   r11
    707120f01221:	mov    rdx,QWORD PTR [rsp+0x68]
    707120f01226:	mov    r10d,edx
    707120f01229:	and    r10d,0xc0
    707120f01230:	shl    r10d,0x18
    707120f01234:	mov    r11d,edx
    707120f01237:	and    r11d,0x1
    707120f0123b:	shl    r11d,0x1d
    707120f0123f:	or     r10d,r11d
    707120f01242:	mov    r11d,edx
    707120f01245:	and    r11d,0x800
    707120f0124c:	shl    r11d,0x11
    707120f01250:	or     r10d,r11d
    707120f01253:	btc    r10,0x1d
    707120f01258:	mov    r11d,0xf0000000
    707120f0125e:	and    r11,r10
    707120f01261:	movabs rsi,0xffffffff0fffffff
    707120f0126b:	and    rbx,rsi
    707120f0126e:	or     rbx,r11
    707120f01271:	pop    r11
    707120f01273:	pop    r10
    707120f01275:	pop    rsi
    707120f01276:	pop    rdx
    707120f01277:	mov    QWORD PTR [r12+0x108],rbx
    707120f0127f:	add    rsp,0x50
    707120f01283:	mov    eax,0xc
    707120f01288:	movabs r11,0x5ab6724ae390
    707120f01292:	jmp    r11
    707120f01295:	mov    eax,0x410948
    707120f0129a:	mov    QWORD PTR [r12+0x100],rax
    707120f012a2:	push   rdx
    707120f012a3:	push   rsi
    707120f012a4:	push   r10
    707120f012a6:	push   r11
    707120f012a8:	mov    rdx,QWORD PTR [rsp+0x68]
    707120f012ad:	mov    r10d,edx
    707120f012b0:	and    r10d,0xc0
    707120f012b7:	shl    r10d,0x18
    707120f012bb:	mov    r11d,edx
    707120f012be:	and    r11d,0x1
    707120f012c2:	shl    r11d,0x1d
    707120f012c6:	or     r10d,r11d
    707120f012c9:	mov    r11d,edx
    707120f012cc:	and    r11d,0x800
    707120f012d3:	shl    r11d,0x11
    707120f012d7:	or     r10d,r11d
    707120f012da:	btc    r10,0x1d
    707120f012df:	mov    r11d,0xf0000000
    707120f012e5:	and    r11,r10
    707120f012e8:	movabs rsi,0xffffffff0fffffff
    707120f012f2:	and    rbx,rsi
    707120f012f5:	or     rbx,r11
    707120f012f8:	pop    r11
    707120f012fa:	pop    r10
    707120f012fc:	pop    rsi
    707120f012fd:	pop    rdx
    707120f012fe:	mov    QWORD PTR [r12+0x108],rbx
    707120f01306:	add    rsp,0x50
    707120f0130a:	mov    eax,0xc
    707120f0130f:	movabs r11,0x5ab6724ae390
    707120f01319:	jmp    r11
    707120f0131c:	mov    eax,0x410984
    707120f01321:	mov    QWORD PTR [r12+0x100],rax
    707120f01329:	push   rdx
    707120f0132a:	push   rsi
    707120f0132b:	push   r10
    707120f0132d:	push   r11
    707120f0132f:	mov    rdx,QWORD PTR [rsp+0x68]
    707120f01334:	mov    r10d,edx
    707120f01337:	and    r10d,0xc0
    707120f0133e:	shl    r10d,0x18
    707120f01342:	mov    r11d,edx
    707120f01345:	and    r11d,0x1
    707120f01349:	shl    r11d,0x1d
    707120f0134d:	or     r10d,r11d
    707120f01350:	mov    r11d,edx
    707120f01353:	and    r11d,0x800
    707120f0135a:	shl    r11d,0x11
    707120f0135e:	or     r10d,r11d
    707120f01361:	btc    r10,0x1d
    707120f01366:	mov    r11d,0xf0000000
    707120f0136c:	and    r11,r10
    707120f0136f:	movabs rsi,0xffffffff0fffffff
    707120f01379:	and    rbx,rsi
    707120f0137c:	or     rbx,r11
    707120f0137f:	pop    r11
    707120f01381:	pop    r10
    707120f01383:	pop    rsi
    707120f01384:	pop    rdx
    707120f01385:	mov    QWORD PTR [r12+0x108],rbx
    707120f0138d:	add    rsp,0x50
    707120f01391:	mov    eax,0xc
    707120f01396:	movabs r11,0x5ab6724ae390
    707120f013a0:	jmp    r11
    707120f013a3:	mov    eax,0x4109a0
    707120f013a8:	mov    QWORD PTR [r12+0x100],rax
    707120f013b0:	push   rdx
    707120f013b1:	push   rsi
    707120f013b2:	push   r10
    707120f013b4:	push   r11
    707120f013b6:	mov    rdx,QWORD PTR [rsp+0x68]
    707120f013bb:	mov    r10d,edx
    707120f013be:	and    r10d,0xc0
    707120f013c5:	shl    r10d,0x18
    707120f013c9:	mov    r11d,edx
    707120f013cc:	and    r11d,0x1
    707120f013d0:	shl    r11d,0x1d
    707120f013d4:	or     r10d,r11d
    707120f013d7:	mov    r11d,edx
    707120f013da:	and    r11d,0x800
    707120f013e1:	shl    r11d,0x11
    707120f013e5:	or     r10d,r11d
    707120f013e8:	btc    r10,0x1d
    707120f013ed:	mov    r11d,0xf0000000
    707120f013f3:	and    r11,r10
    707120f013f6:	movabs rsi,0xffffffff0fffffff
    707120f01400:	and    rbx,rsi
    707120f01403:	or     rbx,r11
    707120f01406:	pop    r11
    707120f01408:	pop    r10
    707120f0140a:	pop    rsi
    707120f0140b:	pop    rdx
    707120f0140c:	mov    QWORD PTR [r12+0x108],rbx
    707120f01414:	add    rsp,0x50
    707120f01418:	mov    eax,0xc
    707120f0141d:	movabs r11,0x5ab6724ae390
    707120f01427:	jmp    r11
    707120f0142a:	nop    WORD PTR [rax+rax*1+0x0]
    707120f01430:	sub    rsp,0x50
    707120f01434:	mov    r11,QWORD PTR [r12+0x398]
    707120f0143c:	mov    QWORD PTR [rsp+0x48],r11
    707120f01441:	jmp    0x707120efe9cb
    707120f01446:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f01450:	sub    rsp,0x50
    707120f01454:	mov    r11,QWORD PTR [r12+0x398]
    707120f0145c:	mov    QWORD PTR [rsp+0x48],r11
    707120f01461:	jmp    0x707120efeb77
    707120f01466:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f01470:	sub    rsp,0x50
    707120f01474:	mov    r11,QWORD PTR [r12+0x398]
    707120f0147c:	mov    QWORD PTR [rsp+0x48],r11
    707120f01481:	jmp    0x707120efec21
    707120f01486:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f01490:	sub    rsp,0x50
    707120f01494:	mov    r11,QWORD PTR [r12+0x398]
    707120f0149c:	mov    QWORD PTR [rsp+0x48],r11
    707120f014a1:	jmp    0x707120f0073c
    707120f014a6:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f014b0:	sub    rsp,0x50
    707120f014b4:	mov    r11,QWORD PTR [r12+0x398]
    707120f014bc:	mov    QWORD PTR [rsp+0x48],r11
    707120f014c1:	jmp    0x707120f008c5
    707120f014c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f014d0:	sub    rsp,0x50
    707120f014d4:	mov    r11,QWORD PTR [r12+0x398]
    707120f014dc:	mov    QWORD PTR [rsp+0x48],r11
    707120f014e1:	jmp    0x707120f00a4a
    707120f014e6:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f014f0:	sub    rsp,0x50
    707120f014f4:	mov    r11,QWORD PTR [r12+0x398]
    707120f014fc:	mov    QWORD PTR [rsp+0x48],r11
    707120f01501:	jmp    0x707120f00e3f
    707120f01506:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f01510:	sub    rsp,0x50
    707120f01514:	mov    r11,QWORD PTR [r12+0x398]
    707120f0151c:	mov    QWORD PTR [rsp+0x48],r11
    707120f01521:	jmp    0x707120f01021
    707120f01526:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f01530:	sub    rsp,0x50
    707120f01534:	mov    r11,QWORD PTR [r12+0x398]
    707120f0153c:	mov    QWORD PTR [rsp+0x48],r11
    707120f01541:	jmp    0x707120f01055
    707120f01546:	data16 nop WORD PTR [rax+rax*1+0x0]
    707120f01550:	sub    rsp,0x50
    707120f01554:	mov    r11,QWORD PTR [r12+0x398]
    707120f0155c:	mov    QWORD PTR [rsp+0x48],r11
    707120f01561:	jmp    0x707120f0113a
    707120f01566:	nop
    707120f01567:	nop
