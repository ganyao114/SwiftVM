
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/2/5.bin:     file format binary


Disassembly of section .data:

0000786625d01bd0 <.data>:
    786625d01bd0:	sub    rsp,0x20
    786625d01bd4:	mov    r11,QWORD PTR [r12+0x398]
    786625d01bdc:	mov    QWORD PTR [rsp+0x10],r11
    786625d01be1:	mov    r13,QWORD PTR [r12+0xf8]
    786625d01be9:	mov    r14,r13
    786625d01bec:	add    r14,0x100
    786625d01bf3:	mov    r15d,DWORD PTR [r14]
    786625d01bf6:	mov    QWORD PTR [r12+0x40],r15
    786625d01bfb:	mov    r14,r13
    786625d01bfe:	add    r14,0x104
    786625d01c05:	mov    ebp,DWORD PTR [r14]
    786625d01c08:	mov    QWORD PTR [r12+0x50],rbp
    786625d01c0d:	mov    r14d,0x430c90
    786625d01c13:	mov    QWORD PTR [r12+0x48],r14
    786625d01c18:	mov    r14,r13
    786625d01c1b:	add    r14,0x108
    786625d01c22:	mov    r8d,DWORD PTR [r14]
    786625d01c25:	mov    QWORD PTR [r12+0x58],r8
    786625d01c2a:	add    r13,0x10c
    786625d01c31:	mov    r14d,DWORD PTR [r13+0x0]
    786625d01c35:	mov    QWORD PTR [r12+0x60],r14
    786625d01c3a:	movabs rcx,0xff00ff00ff00ff
    786625d01c44:	mov    r13,r15
    786625d01c47:	and    r13,rcx
    786625d01c4a:	shl    r13,0x8
    786625d01c4e:	movabs rcx,0xff00ff00ff00ff00
    786625d01c58:	mov    r14,r15
    786625d01c5b:	and    r14,rcx
    786625d01c5e:	shr    r14,0x8
    786625d01c62:	mov    rcx,r13
    786625d01c65:	or     r14,rcx
    786625d01c68:	movabs rcx,0xffff0000ffff
    786625d01c72:	mov    r13,r14
    786625d01c75:	and    r13,rcx
    786625d01c78:	shl    r13,0x10
    786625d01c7c:	movabs rcx,0xffff0000ffff0000
    786625d01c86:	and    r14,rcx
    786625d01c89:	shr    r14,0x10
    786625d01c8d:	mov    rcx,r13
    786625d01c90:	or     r14,rcx
    786625d01c93:	mov    ecx,0xffffffff
    786625d01c98:	and    r14,rcx
    786625d01c9b:	mov    QWORD PTR [r12+0x40],r14
    786625d01ca0:	movabs rcx,0xff00ff00ff00ff
    786625d01caa:	mov    r13,rbp
    786625d01cad:	and    r13,rcx
    786625d01cb0:	shl    r13,0x8
    786625d01cb4:	movabs rcx,0xff00ff00ff00ff00
    786625d01cbe:	mov    r15,rbp
    786625d01cc1:	and    r15,rcx
    786625d01cc4:	shr    r15,0x8
    786625d01cc8:	mov    rcx,r13
    786625d01ccb:	or     r15,rcx
    786625d01cce:	movabs rcx,0xffff0000ffff
    786625d01cd8:	mov    r13,r15
    786625d01cdb:	and    r13,rcx
    786625d01cde:	shl    r13,0x10
    786625d01ce2:	movabs rcx,0xffff0000ffff0000
    786625d01cec:	and    r15,rcx
    786625d01cef:	shr    r15,0x10
    786625d01cf3:	mov    rcx,r13
    786625d01cf6:	or     r15,rcx
    786625d01cf9:	mov    ecx,0xffffffff
    786625d01cfe:	and    r15,rcx
    786625d01d01:	mov    QWORD PTR [r12+0x50],r15
    786625d01d06:	mov    r13d,0x0
    786625d01d0c:	mov    QWORD PTR [r12+0xa0],r13
    786625d01d14:	mov    r13d,0x430c90
    786625d01d1a:	mov    ebp,0x430c94
    786625d01d1f:	mov    rax,r14
    786625d01d22:	mov    eax,eax
    786625d01d24:	mov    r8d,eax
    786625d01d27:	mov    rax,r15
    786625d01d2a:	mov    eax,eax
    786625d01d2c:	mov    r14d,eax
    786625d01d2f:	mov    DWORD PTR [r13+0x0],r8d
    786625d01d33:	mov    r13d,0x0
    786625d01d39:	mov    DWORD PTR [r12+0x32c],r13d
    786625d01d41:	mov    DWORD PTR [rbp+0x0],r14d
    786625d01d45:	mov    r13d,0x0
    786625d01d4b:	mov    DWORD PTR [r12+0x32c],r13d
    786625d01d53:	mov    r13d,DWORD PTR [r12+0x58]
    786625d01d58:	movabs rcx,0xff00ff00ff00ff
    786625d01d62:	mov    r14,r13
    786625d01d65:	and    r14,rcx
    786625d01d68:	shl    r14,0x8
    786625d01d6c:	movabs rcx,0xff00ff00ff00ff00
    786625d01d76:	mov    r15,r13
    786625d01d79:	and    r15,rcx
    786625d01d7c:	shr    r15,0x8
    786625d01d80:	mov    rcx,r14
    786625d01d83:	or     r15,rcx
    786625d01d86:	movabs rcx,0xffff0000ffff
    786625d01d90:	mov    r13,r15
    786625d01d93:	and    r13,rcx
    786625d01d96:	shl    r13,0x10
    786625d01d9a:	movabs rcx,0xffff0000ffff0000
    786625d01da4:	and    r15,rcx
    786625d01da7:	shr    r15,0x10
    786625d01dab:	mov    rcx,r13
    786625d01dae:	or     r15,rcx
    786625d01db1:	mov    ecx,0xffffffff
    786625d01db6:	and    r15,rcx
    786625d01db9:	mov    QWORD PTR [r12+0x40],r15
    786625d01dbe:	mov    r13,QWORD PTR [r12+0xf8]
    786625d01dc6:	mov    r14,r13
    786625d01dc9:	add    r14,0x110
    786625d01dd0:	mov    ebp,DWORD PTR [r14]
    786625d01dd3:	mov    QWORD PTR [r12+0x50],rbp
    786625d01dd8:	mov    r14d,DWORD PTR [r12+0x60]
    786625d01ddd:	movabs rcx,0xff00ff00ff00ff
    786625d01de7:	mov    rbp,r14
    786625d01dea:	and    rbp,rcx
    786625d01ded:	shl    rbp,0x8
    786625d01df1:	movabs rcx,0xff00ff00ff00ff00
    786625d01dfb:	mov    r8,r14
    786625d01dfe:	and    r8,rcx
    786625d01e01:	shr    r8,0x8
    786625d01e05:	mov    rcx,rbp
    786625d01e08:	or     r8,rcx
    786625d01e0b:	movabs rcx,0xffff0000ffff
    786625d01e15:	mov    r14,r8
    786625d01e18:	and    r14,rcx
    786625d01e1b:	shl    r14,0x10
    786625d01e1f:	movabs rcx,0xffff0000ffff0000
    786625d01e29:	and    r8,rcx
    786625d01e2c:	shr    r8,0x10
    786625d01e30:	mov    rcx,r14
    786625d01e33:	or     r8,rcx
    786625d01e36:	mov    ecx,0xffffffff
    786625d01e3b:	and    r8,rcx
    786625d01e3e:	mov    QWORD PTR [r12+0x58],r8
    786625d01e43:	add    r13,0x114
    786625d01e4a:	mov    r14d,DWORD PTR [r13+0x0]
    786625d01e4e:	mov    QWORD PTR [r12+0x60],r14
    786625d01e53:	mov    r13d,0x430000
    786625d01e59:	add    r13,0xdfc
    786625d01e60:	mov    QWORD PTR [r12+0x98],r13
    786625d01e68:	mov    r13,QWORD PTR [r12+0x48]
    786625d01e6d:	add    r13,0x8
    786625d01e71:	mov    r14,r13
    786625d01e74:	add    r14,0x4
    786625d01e78:	mov    rax,r15
    786625d01e7b:	mov    eax,eax
    786625d01e7d:	mov    ebp,eax
    786625d01e7f:	mov    rax,r8
    786625d01e82:	mov    eax,eax
    786625d01e84:	mov    r15d,eax
    786625d01e87:	mov    DWORD PTR [r13+0x0],ebp
    786625d01e8b:	mov    r13d,0x0
    786625d01e91:	mov    DWORD PTR [r12+0x32c],r13d
    786625d01e99:	mov    DWORD PTR [r14],r15d
    786625d01e9c:	mov    r13d,0x0
    786625d01ea2:	mov    DWORD PTR [r12+0x32c],r13d
    786625d01eaa:	mov    r13d,DWORD PTR [r12+0x50]
    786625d01eaf:	movabs rcx,0xff00ff00ff00ff
    786625d01eb9:	mov    r14,r13
    786625d01ebc:	and    r14,rcx
    786625d01ebf:	shl    r14,0x8
    786625d01ec3:	movabs rcx,0xff00ff00ff00ff00
    786625d01ecd:	mov    r15,r13
    786625d01ed0:	and    r15,rcx
    786625d01ed3:	shr    r15,0x8
    786625d01ed7:	mov    rcx,r14
    786625d01eda:	or     r15,rcx
    786625d01edd:	movabs rcx,0xffff0000ffff
    786625d01ee7:	mov    r13,r15
    786625d01eea:	and    r13,rcx
    786625d01eed:	shl    r13,0x10
    786625d01ef1:	movabs rcx,0xffff0000ffff0000
    786625d01efb:	and    r15,rcx
    786625d01efe:	shr    r15,0x10
    786625d01f02:	mov    rcx,r13
    786625d01f05:	or     r15,rcx
    786625d01f08:	mov    ecx,0xffffffff
    786625d01f0d:	and    r15,rcx
    786625d01f10:	mov    QWORD PTR [r12+0x40],r15
    786625d01f15:	mov    r13,QWORD PTR [r12+0xf8]
    786625d01f1d:	mov    r14,r13
    786625d01f20:	add    r14,0x118
    786625d01f27:	mov    ebp,DWORD PTR [r14]
    786625d01f2a:	mov    QWORD PTR [r12+0x50],rbp
    786625d01f2f:	mov    r14d,DWORD PTR [r12+0x60]
    786625d01f34:	movabs rcx,0xff00ff00ff00ff
    786625d01f3e:	mov    r8,r14
    786625d01f41:	and    r8,rcx
    786625d01f44:	shl    r8,0x8
    786625d01f48:	movabs rcx,0xff00ff00ff00ff00
    786625d01f52:	mov    r9,r14
    786625d01f55:	and    r9,rcx
    786625d01f58:	shr    r9,0x8
    786625d01f5c:	mov    rcx,r8
    786625d01f5f:	or     r9,rcx
    786625d01f62:	movabs rcx,0xffff0000ffff
    786625d01f6c:	mov    r14,r9
    786625d01f6f:	and    r14,rcx
    786625d01f72:	shl    r14,0x10
    786625d01f76:	movabs rcx,0xffff0000ffff0000
    786625d01f80:	and    r9,rcx
    786625d01f83:	shr    r9,0x10
    786625d01f87:	mov    rcx,r14
    786625d01f8a:	or     r9,rcx
    786625d01f8d:	mov    ecx,0xffffffff
    786625d01f92:	and    r9,rcx
    786625d01f95:	mov    QWORD PTR [r12+0x58],r9
    786625d01f9a:	add    r13,0x11c
    786625d01fa1:	mov    eax,DWORD PTR [r13+0x0]
    786625d01fa5:	mov    QWORD PTR [rsp+0x8],rax
    786625d01faa:	mov    rax,QWORD PTR [rsp+0x8]
    786625d01faf:	mov    QWORD PTR [r12+0x60],rax
    786625d01fb4:	mov    rax,QWORD PTR [r12+0x48]
    786625d01fb9:	mov    QWORD PTR [rsp],rax
    786625d01fbd:	mov    r8,QWORD PTR [rsp]
    786625d01fc1:	add    r8,0x10
    786625d01fc5:	mov    r13,r8
    786625d01fc8:	add    r13,0x4
    786625d01fcc:	mov    rax,r15
    786625d01fcf:	mov    eax,eax
    786625d01fd1:	mov    r14d,eax
    786625d01fd4:	mov    rax,r9
    786625d01fd7:	mov    eax,eax
    786625d01fd9:	mov    r15d,eax
    786625d01fdc:	mov    DWORD PTR [r8],r14d
    786625d01fdf:	mov    r14d,0x0
    786625d01fe5:	mov    DWORD PTR [r12+0x32c],r14d
    786625d01fed:	mov    DWORD PTR [r13+0x0],r15d
    786625d01ff1:	mov    r13d,0x0
    786625d01ff7:	mov    DWORD PTR [r12+0x32c],r13d
    786625d01fff:	movabs rcx,0xff00ff00ff00ff
    786625d02009:	mov    r13,rbp
    786625d0200c:	and    r13,rcx
    786625d0200f:	shl    r13,0x8
    786625d02013:	movabs rcx,0xff00ff00ff00ff00
    786625d0201d:	mov    r14,rbp
    786625d02020:	and    r14,rcx
    786625d02023:	shr    r14,0x8
    786625d02027:	mov    rcx,r13
    786625d0202a:	or     r14,rcx
    786625d0202d:	movabs rcx,0xffff0000ffff
    786625d02037:	mov    r13,r14
    786625d0203a:	and    r13,rcx
    786625d0203d:	shl    r13,0x10
    786625d02041:	movabs rcx,0xffff0000ffff0000
    786625d0204b:	and    r14,rcx
    786625d0204e:	shr    r14,0x10
    786625d02052:	mov    rcx,r13
    786625d02055:	or     r14,rcx
    786625d02058:	mov    ecx,0xffffffff
    786625d0205d:	and    r14,rcx
    786625d02060:	mov    QWORD PTR [r12+0x40],r14
    786625d02065:	movabs rcx,0xff00ff00ff00ff
    786625d0206f:	mov    r13,QWORD PTR [rsp+0x8]
    786625d02074:	and    r13,rcx
    786625d02077:	shl    r13,0x8
    786625d0207b:	movabs rcx,0xff00ff00ff00ff00
    786625d02085:	mov    r15,QWORD PTR [rsp+0x8]
    786625d0208a:	and    r15,rcx
    786625d0208d:	shr    r15,0x8
    786625d02091:	mov    rcx,r13
    786625d02094:	or     r15,rcx
    786625d02097:	movabs rcx,0xffff0000ffff
    786625d020a1:	mov    r13,r15
    786625d020a4:	and    r13,rcx
    786625d020a7:	shl    r13,0x10
    786625d020ab:	movabs rcx,0xffff0000ffff0000
    786625d020b5:	and    r15,rcx
    786625d020b8:	shr    r15,0x10
    786625d020bc:	mov    rcx,r13
    786625d020bf:	or     r15,rcx
    786625d020c2:	mov    ecx,0xffffffff
    786625d020c7:	and    r15,rcx
    786625d020ca:	mov    QWORD PTR [r12+0x50],r15
    786625d020cf:	mov    r13,QWORD PTR [rsp]
    786625d020d3:	add    r13,0x18
    786625d020d7:	mov    rbp,r13
    786625d020da:	add    rbp,0x4
    786625d020de:	mov    rax,r14
    786625d020e1:	mov    eax,eax
    786625d020e3:	mov    r8d,eax
    786625d020e6:	mov    rax,r15
    786625d020e9:	mov    eax,eax
    786625d020eb:	mov    r14d,eax
    786625d020ee:	mov    DWORD PTR [r13+0x0],r8d
    786625d020f2:	mov    r13d,0x0
    786625d020f8:	mov    DWORD PTR [r12+0x32c],r13d
    786625d02100:	mov    DWORD PTR [rbp+0x0],r14d
    786625d02104:	mov    r13d,0x0
    786625d0210a:	mov    DWORD PTR [r12+0x32c],r13d
    786625d02112:	mov    r13d,DWORD PTR [r12+0xa0]
    786625d0211a:	add    r13d,0x11
    786625d0211e:	mov    QWORD PTR [r12],r13
    786625d02122:	mov    r13d,0x41035c
    786625d02128:	mov    QWORD PTR [r12+0xf0],r13
    786625d02130:	mov    r13d,0x4109a4
    786625d02136:	mov    QWORD PTR [r12+0x100],r13
    786625d0213e:	mov    r11,QWORD PTR [rsp+0x10]
    786625d02143:	mov    QWORD PTR [r12+0x398],r11
    786625d0214b:	mov    edi,0x4109a4
    786625d02150:	mov    QWORD PTR [r12+0x100],rdi
    786625d02158:	add    rsp,0x20
    786625d0215c:	nop    DWORD PTR [rax+0x0]
    786625d02160:	jmp    QWORD PTR [rip+0x2]        # 0x786625d02168
    786625d02166:	xchg   ax,ax
    786625d02168:	nop
    786625d02169:	and    eax,edx
    786625d0216b:	and    eax,0x7866
    786625d02170:	js     0x786625d02193
    786625d02172:	shl    BYTE PTR [rip+0x7866],1        # 0x786625d099de
    786625d02178:	movabs r11,0x5c9c39de20a0
    786625d02182:	jmp    r11
    786625d02185:	nop
    786625d02186:	nop
    786625d02187:	nop
