
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/2/3.bin:     file format binary


Disassembly of section .data:

0000786625d017f0 <.data>:
    786625d017f0:	sub    rsp,0x10
    786625d017f4:	mov    r11,QWORD PTR [r12+0x398]
    786625d017fc:	mov    QWORD PTR [rsp],r11
    786625d01800:	mov    r13,QWORD PTR [r12+0xf8]
    786625d01808:	mov    r14,r13
    786625d0180b:	add    r14,0x168
    786625d01812:	mov    r15,QWORD PTR [r14]
    786625d01815:	mov    QWORD PTR [r12+0x40],r15
    786625d0181a:	add    r13,0x178
    786625d01821:	mov    r14d,0x0
    786625d01827:	mov    BYTE PTR [r13+0x0],r14b
    786625d0182b:	mov    r13d,0x0
    786625d01831:	mov    DWORD PTR [r12+0x32c],r13d
    786625d01839:	sub    r15,0x38
    786625d0183d:	pushf
    786625d0183e:	pop    r11
    786625d01840:	mov    QWORD PTR [rsp],r11
    786625d01844:	je     0x786625d018dd
    786625d0184a:	jmp    0x786625d0184f
    786625d0184f:	mov    r13,QWORD PTR [r12+0xf8]
    786625d01857:	mov    r14,r13
    786625d0185a:	add    r14,0x100
    786625d01861:	mov    QWORD PTR [r12],r14
    786625d01865:	add    r13,0x178
    786625d0186c:	mov    QWORD PTR [r12+0x8],r13
    786625d01871:	mov    r13d,0x1
    786625d01877:	mov    QWORD PTR [r12+0x10],r13
    786625d0187c:	mov    r13d,0x4102c8
    786625d01882:	mov    QWORD PTR [r12+0xf0],r13
    786625d0188a:	mov    r13d,0x410728
    786625d01890:	mov    QWORD PTR [r12+0x100],r13
    786625d01898:	mov    r11,QWORD PTR [rsp]
    786625d0189c:	mov    QWORD PTR [r12+0x398],r11
    786625d018a4:	mov    edi,0x410728
    786625d018a9:	mov    QWORD PTR [r12+0x100],rdi
    786625d018b1:	add    rsp,0x10
    786625d018b5:	nop    DWORD PTR [rax]
    786625d018b8:	jmp    QWORD PTR [rip+0x2]        # 0x786625d018c0
    786625d018be:	xchg   ax,ax
    786625d018c0:	(bad)
    786625d018c1:	jmp    0x78669e363e95
    786625d018c6:	add    BYTE PTR [rax],al
    786625d018c8:	rcr    BYTE PTR [rax],1
    786625d018ca:	shl    BYTE PTR [rip+0x7866],1        # 0x786625d09136
    786625d018d0:	movabs r11,0x5c9c39de20a0
    786625d018da:	jmp    r11
    786625d018dd:	mov    r13,QWORD PTR [r12+0x98]
    786625d018e5:	ror    r13,0x3d
    786625d018e9:	and    r13,0xfffffffffffffff8
    786625d018ed:	mov    r14,QWORD PTR [r12+0xf8]
    786625d018f5:	mov    r15,r14
    786625d018f8:	add    r15,0x100
    786625d018ff:	mov    QWORD PTR [r12],r15
    786625d01903:	mov    r15,r14
    786625d01906:	add    r15,0x170
    786625d0190d:	mov    QWORD PTR [r12+0x8],r15
    786625d01912:	mov    r15d,0x8
    786625d01918:	mov    QWORD PTR [r12+0x10],r15
    786625d0191d:	movabs rcx,0xff00ff00ff00ff
    786625d01927:	mov    r15,r13
    786625d0192a:	and    r15,rcx
    786625d0192d:	shl    r15,0x8
    786625d01931:	movabs rcx,0xff00ff00ff00ff00
    786625d0193b:	and    r13,rcx
    786625d0193e:	shr    r13,0x8
    786625d01942:	mov    rcx,r15
    786625d01945:	or     r13,rcx
    786625d01948:	movabs rcx,0xffff0000ffff
    786625d01952:	mov    r15,r13
    786625d01955:	and    r15,rcx
    786625d01958:	shl    r15,0x10
    786625d0195c:	movabs rcx,0xffff0000ffff0000
    786625d01966:	and    r13,rcx
    786625d01969:	shr    r13,0x10
    786625d0196d:	mov    rcx,r15
    786625d01970:	or     r13,rcx
    786625d01973:	mov    r15,r13
    786625d01976:	shl    r15,0x20
    786625d0197a:	shr    r13,0x20
    786625d0197e:	mov    rcx,r15
    786625d01981:	or     r13,rcx
    786625d01984:	mov    QWORD PTR [r12+0x40],r13
    786625d01989:	add    r14,0x170
    786625d01990:	mov    QWORD PTR [r14],r13
    786625d01993:	mov    r13d,0x0
    786625d01999:	mov    DWORD PTR [r12+0x32c],r13d
    786625d019a1:	mov    r13d,0x4102f0
    786625d019a7:	mov    QWORD PTR [r12+0xf0],r13
    786625d019af:	mov    r13d,0x410728
    786625d019b5:	mov    QWORD PTR [r12+0x100],r13
    786625d019bd:	mov    r11,QWORD PTR [rsp]
    786625d019c1:	mov    QWORD PTR [r12+0x398],r11
    786625d019c9:	mov    edi,0x410728
    786625d019ce:	mov    QWORD PTR [r12+0x100],rdi
    786625d019d6:	add    rsp,0x10
    786625d019da:	nop    WORD PTR [rax+rax*1+0x0]
    786625d019e0:	jmp    QWORD PTR [rip+0x2]        # 0x786625d019e8
    786625d019e6:	xchg   ax,ax
    786625d019e8:	(bad)
    786625d019e9:	jmp    0x78669e363fbd
    786625d019ee:	add    BYTE PTR [rax],al
    786625d019f0:	clc
    786625d019f1:	sbb    eax,edx
    786625d019f3:	and    eax,0x7866
    786625d019f8:	movabs r11,0x5c9c39de20a0
    786625d01a02:	jmp    r11
    786625d01a05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d01a10:	sub    rsp,0x10
    786625d01a14:	mov    r11,QWORD PTR [r12+0x398]
    786625d01a1c:	mov    QWORD PTR [rsp],r11
    786625d01a20:	jmp    0x786625d0184f
    786625d01a25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d01a30:	sub    rsp,0x10
    786625d01a34:	mov    r11,QWORD PTR [r12+0x398]
    786625d01a3c:	mov    QWORD PTR [rsp],r11
    786625d01a40:	jmp    0x786625d018dd
    786625d01a45:	nop
    786625d01a46:	nop
    786625d01a47:	nop
