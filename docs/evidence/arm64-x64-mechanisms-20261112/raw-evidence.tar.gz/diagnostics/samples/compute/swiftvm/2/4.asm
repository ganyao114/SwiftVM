
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/2/4.bin:     file format binary


Disassembly of section .data:

0000786625d01a50 <.data>:
    786625d01a50:	sub    rsp,0x10
    786625d01a54:	mov    r11,QWORD PTR [r12+0x398]
    786625d01a5c:	mov    QWORD PTR [rsp],r11
    786625d01a60:	mov    r13,QWORD PTR [r12+0xf8]
    786625d01a68:	add    r13,0x168
    786625d01a6f:	mov    r14,QWORD PTR [r13+0x0]
    786625d01a73:	mov    QWORD PTR [r12+0x40],r14
    786625d01a78:	sub    r14,0x38
    786625d01a7c:	mov    rcx,QWORD PTR [r12+0x380]
    786625d01a84:	jrcxz  0x786625d01a8b
    786625d01a86:	jmp    0x786625d01b3d
    786625d01a8b:	pushf
    786625d01a8c:	pop    r11
    786625d01a8e:	mov    QWORD PTR [rsp],r11
    786625d01a92:	jne    0x786625d01aed
    786625d01a98:	jmp    0x786625d01a9d
    786625d01a9d:	mov    r13d,0x4102d4
    786625d01aa3:	mov    QWORD PTR [r12+0x100],r13
    786625d01aab:	mov    r11,QWORD PTR [rsp]
    786625d01aaf:	mov    QWORD PTR [r12+0x398],r11
    786625d01ab7:	mov    edi,0x4102d4
    786625d01abc:	mov    QWORD PTR [r12+0x100],rdi
    786625d01ac4:	add    rsp,0x10
    786625d01ac8:	jmp    QWORD PTR [rip+0x2]        # 0x786625d01ad0
    786625d01ace:	xchg   ax,ax
    786625d01ad0:	xor    BYTE PTR [rdx],bl
    786625d01ad2:	shl    BYTE PTR [rip+0x7866],1        # 0x786625d0933e
    786625d01ad8:	loopne 0x786625d01af4
    786625d01ada:	shl    BYTE PTR [rip+0x7866],1        # 0x786625d09346
    786625d01ae0:	movabs r11,0x5c9c39de20a0
    786625d01aea:	jmp    r11
    786625d01aed:	mov    r13d,0x4102b8
    786625d01af3:	mov    QWORD PTR [r12+0x100],r13
    786625d01afb:	mov    r11,QWORD PTR [rsp]
    786625d01aff:	mov    QWORD PTR [r12+0x398],r11
    786625d01b07:	mov    edi,0x4102b8
    786625d01b0c:	mov    QWORD PTR [r12+0x100],rdi
    786625d01b14:	add    rsp,0x10
    786625d01b18:	jmp    QWORD PTR [rip+0x2]        # 0x786625d01b20
    786625d01b1e:	xchg   ax,ax
    786625d01b20:	adc    BYTE PTR [rdx],bl
    786625d01b22:	shl    BYTE PTR [rip+0x7866],1        # 0x786625d0938e
    786625d01b28:	xor    BYTE PTR [rbx],bl
    786625d01b2a:	shl    BYTE PTR [rip+0x7866],1        # 0x786625d09396
    786625d01b30:	movabs r11,0x5c9c39de20a0
    786625d01b3a:	jmp    r11
    786625d01b3d:	mov    eax,0x4102d0
    786625d01b42:	mov    QWORD PTR [r12+0x100],rax
    786625d01b4a:	push   rdx
    786625d01b4b:	push   rsi
    786625d01b4c:	push   r10
    786625d01b4e:	push   r11
    786625d01b50:	pushf
    786625d01b51:	pop    r11
    786625d01b53:	mov    QWORD PTR [rsp+0x20],r11
    786625d01b58:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d01b5d:	mov    r10d,edx
    786625d01b60:	and    r10d,0xc0
    786625d01b67:	shl    r10d,0x18
    786625d01b6b:	mov    r11d,edx
    786625d01b6e:	and    r11d,0x1
    786625d01b72:	shl    r11d,0x1d
    786625d01b76:	or     r10d,r11d
    786625d01b79:	mov    r11d,edx
    786625d01b7c:	and    r11d,0x800
    786625d01b83:	shl    r11d,0x11
    786625d01b87:	or     r10d,r11d
    786625d01b8a:	btc    r10,0x1d
    786625d01b8f:	mov    r11d,0xf0000000
    786625d01b95:	and    r11,r10
    786625d01b98:	movabs rsi,0xffffffff0fffffff
    786625d01ba2:	and    rbx,rsi
    786625d01ba5:	or     rbx,r11
    786625d01ba8:	pop    r11
    786625d01baa:	pop    r10
    786625d01bac:	pop    rsi
    786625d01bad:	pop    rdx
    786625d01bae:	mov    QWORD PTR [r12+0x108],rbx
    786625d01bb6:	add    rsp,0x10
    786625d01bba:	mov    eax,0xc
    786625d01bbf:	movabs r11,0x5c9c39de2390
    786625d01bc9:	jmp    r11
