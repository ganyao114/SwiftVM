
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/1/6.bin:     file format binary


Disassembly of section .data:

0000707120f02190 <.data>:
    707120f02190:	sub    rsp,0x10
    707120f02194:	mov    r11,QWORD PTR [r12+0x398]
    707120f0219c:	mov    QWORD PTR [rsp],r11
    707120f021a0:	mov    r13d,DWORD PTR [r12]
    707120f021a4:	mov    r14d,r13d
    707120f021a7:	mov    r14d,r14d
    707120f021aa:	shr    r14d,0x10
    707120f021ae:	mov    ecx,r14d
    707120f021b1:	xor    r13,rcx
    707120f021b4:	mov    r13d,r13d
    707120f021b7:	mov    QWORD PTR [r12+0x40],r13
    707120f021bc:	mov    r14d,0x352d
    707120f021c2:	mov    QWORD PTR [r12+0x48],r14
    707120f021c7:	mov    r14d,0x352d
    707120f021cd:	mov    r15d,0x7feb
    707120f021d3:	and    r15d,0xffff
    707120f021da:	mov    rax,r14
    707120f021dd:	movabs rcx,0xffffffff0000ffff
    707120f021e7:	and    rax,rcx
    707120f021ea:	mov    rdx,r15
    707120f021ed:	shl    rdx,0x10
    707120f021f1:	mov    ecx,0xffff0000
    707120f021f6:	and    rdx,rcx
    707120f021f9:	or     rax,rdx
    707120f021fc:	mov    ebp,eax
    707120f021fe:	mov    QWORD PTR [r12+0x48],rbp
    707120f02203:	mov    r14d,0x0
    707120f02209:	mov    eax,r13d
    707120f0220c:	mov    ecx,ebp
    707120f0220e:	imul   rax,rcx
    707120f02212:	mov    r15d,eax
    707120f02215:	mov    ecx,r15d
    707120f02218:	mov    r13d,r14d
    707120f0221b:	add    r13d,ecx
    707120f0221e:	mov    QWORD PTR [r12+0x40],r13
    707120f02223:	mov    r14d,0xa68b
    707120f02229:	mov    QWORD PTR [r12+0x48],r14
    707120f0222e:	mov    r14d,0xa68b
    707120f02234:	mov    r15d,0x846c
    707120f0223a:	and    r15d,0xffff
    707120f02241:	mov    rax,r14
    707120f02244:	movabs rcx,0xffffffff0000ffff
    707120f0224e:	and    rax,rcx
    707120f02251:	mov    rdx,r15
    707120f02254:	shl    rdx,0x10
    707120f02258:	mov    ecx,0xffff0000
    707120f0225d:	and    rdx,rcx
    707120f02260:	or     rax,rdx
    707120f02263:	mov    ebp,eax
    707120f02265:	mov    QWORD PTR [r12+0x48],rbp
    707120f0226a:	mov    r14d,r13d
    707120f0226d:	mov    r14d,r14d
    707120f02270:	shr    r14d,0xf
    707120f02274:	mov    ecx,r14d
    707120f02277:	xor    r13,rcx
    707120f0227a:	mov    r13d,r13d
    707120f0227d:	mov    QWORD PTR [r12+0x40],r13
    707120f02282:	mov    r14d,0x0
    707120f02288:	mov    eax,r13d
    707120f0228b:	mov    ecx,ebp
    707120f0228d:	imul   rax,rcx
    707120f02291:	mov    r15d,eax
    707120f02294:	mov    ecx,r15d
    707120f02297:	mov    r13d,r14d
    707120f0229a:	add    r13d,ecx
    707120f0229d:	mov    QWORD PTR [r12+0x40],r13
    707120f022a2:	mov    r14d,r13d
    707120f022a5:	mov    r14d,r14d
    707120f022a8:	shr    r14d,0x10
    707120f022ac:	mov    ecx,r14d
    707120f022af:	xor    r13,rcx
    707120f022b2:	mov    r13d,r13d
    707120f022b5:	mov    QWORD PTR [r12],r13
    707120f022b9:	mov    rcx,QWORD PTR [r12+0x380]
    707120f022c1:	jrcxz  0x707120f022c8
    707120f022c3:	jmp    0x707120f022fd
    707120f022c8:	mov    r13,QWORD PTR [r12+0xf0]
    707120f022d0:	mov    QWORD PTR [r12+0x100],r13
    707120f022d8:	mov    r11,QWORD PTR [rsp]
    707120f022dc:	mov    QWORD PTR [r12+0x398],r11
    707120f022e4:	mov    rdi,QWORD PTR [r12+0x100]
    707120f022ec:	add    rsp,0x10
    707120f022f0:	movabs r11,0x5ab6724ae0a0
    707120f022fa:	jmp    r11
    707120f022fd:	mov    eax,0x4109c8
    707120f02302:	mov    QWORD PTR [r12+0x100],rax
    707120f0230a:	push   rdx
    707120f0230b:	push   rsi
    707120f0230c:	push   r10
    707120f0230e:	push   r11
    707120f02310:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f02315:	mov    r10d,edx
    707120f02318:	and    r10d,0xc0
    707120f0231f:	shl    r10d,0x18
    707120f02323:	mov    r11d,edx
    707120f02326:	and    r11d,0x1
    707120f0232a:	shl    r11d,0x1d
    707120f0232e:	or     r10d,r11d
    707120f02331:	mov    r11d,edx
    707120f02334:	and    r11d,0x800
    707120f0233b:	shl    r11d,0x11
    707120f0233f:	or     r10d,r11d
    707120f02342:	btc    r10,0x1d
    707120f02347:	mov    r11d,0xf0000000
    707120f0234d:	and    r11,r10
    707120f02350:	movabs rsi,0xffffffff0fffffff
    707120f0235a:	and    rbx,rsi
    707120f0235d:	or     rbx,r11
    707120f02360:	pop    r11
    707120f02362:	pop    r10
    707120f02364:	pop    rsi
    707120f02365:	pop    rdx
    707120f02366:	mov    QWORD PTR [r12+0x108],rbx
    707120f0236e:	add    rsp,0x10
    707120f02372:	mov    eax,0xc
    707120f02377:	movabs r11,0x5ab6724ae390
    707120f02381:	jmp    r11
