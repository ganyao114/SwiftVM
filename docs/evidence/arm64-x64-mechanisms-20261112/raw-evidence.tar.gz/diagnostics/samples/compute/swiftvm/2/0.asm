
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

0000786625cfe000 <.data>:
    786625cfe000:	sub    rsp,0x10
    786625cfe004:	mov    r11,QWORD PTR [r12+0x398]
    786625cfe00c:	mov    QWORD PTR [rsp],r11
    786625cfe010:	mov    r13,QWORD PTR [r12+0xf8]
    786625cfe018:	sub    r13,0x1e0
    786625cfe01f:	mov    QWORD PTR [r12+0xf8],r13
    786625cfe027:	mov    r14d,0x420000
    786625cfe02d:	mov    QWORD PTR [r12+0x40],r14
    786625cfe032:	mov    r14d,0x420000
    786625cfe038:	mov    QWORD PTR [r12+0x48],r14
    786625cfe03d:	add    r13,0x1d0
    786625cfe044:	mov    r14,r13
    786625cfe047:	add    r14,0x8
    786625cfe04b:	mov    r15,QWORD PTR [r12+0xa0]
    786625cfe053:	mov    rbp,QWORD PTR [r12+0x98]
    786625cfe05b:	mov    QWORD PTR [r13+0x0],r15
    786625cfe05f:	mov    r13d,0x0
    786625cfe065:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe06d:	mov    QWORD PTR [r14],rbp
    786625cfe070:	mov    r13d,0x0
    786625cfe076:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe07e:	mov    r13d,0x420aa0
    786625cfe084:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625cfe08a:	movdqa xmm0,xmm2
    786625cfe08e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625cfe098:	mov    r13d,0x420000
    786625cfe09e:	mov    QWORD PTR [r12+0x40],r13
    786625cfe0a3:	mov    r13d,0x420a30
    786625cfe0a9:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    786625cfe0af:	movdqa xmm0,xmm3
    786625cfe0b3:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625cfe0bd:	mov    r13d,0x420000
    786625cfe0c3:	mov    QWORD PTR [r12+0x48],r13
    786625cfe0c8:	mov    r13d,0x420ac0
    786625cfe0ce:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    786625cfe0d4:	movdqa xmm0,xmm4
    786625cfe0d8:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625cfe0e2:	mov    r13d,0x420000
    786625cfe0e8:	mov    QWORD PTR [r12+0x40],r13
    786625cfe0ed:	mov    r13d,0x420a60
    786625cfe0f3:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    786625cfe0f9:	movdqa xmm0,xmm5
    786625cfe0fd:	movdqu XMMWORD PTR [r12+0x140],xmm0
    786625cfe107:	mov    r13d,0x430000
    786625cfe10d:	add    r13,0xcd0
    786625cfe114:	mov    QWORD PTR [r12+0x98],r13
    786625cfe11c:	mov    r14,QWORD PTR [r12+0x40]
    786625cfe121:	add    r14,0xad0
    786625cfe128:	movdqu xmm6,XMMWORD PTR [r14]
    786625cfe12d:	movdqa xmm0,xmm6
    786625cfe131:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625cfe13b:	mov    r14d,0x420000
    786625cfe141:	mov    QWORD PTR [r12+0x40],r14
    786625cfe146:	mov    r14,r13
    786625cfe149:	add    r14,0x10
    786625cfe14d:	movdqu XMMWORD PTR [r13+0x0],xmm2
    786625cfe153:	mov    r15d,0x0
    786625cfe159:	mov    DWORD PTR [r12+0x32c],r15d
    786625cfe161:	movdqu XMMWORD PTR [r14],xmm3
    786625cfe166:	mov    r14d,0x0
    786625cfe16c:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe174:	mov    r14,r13
    786625cfe177:	add    r14,0x20
    786625cfe17b:	mov    r15,r14
    786625cfe17e:	add    r15,0x10
    786625cfe182:	movdqu XMMWORD PTR [r14],xmm4
    786625cfe187:	mov    r14d,0x0
    786625cfe18d:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe195:	movdqu XMMWORD PTR [r15],xmm5
    786625cfe19a:	mov    r14d,0x0
    786625cfe1a0:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe1a8:	mov    r14d,0x420a20
    786625cfe1ae:	movdqu xmm4,XMMWORD PTR [r14]
    786625cfe1b3:	movdqa xmm0,xmm4
    786625cfe1b7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625cfe1c1:	mov    r14d,0x420000
    786625cfe1c7:	mov    QWORD PTR [r12+0x40],r14
    786625cfe1cc:	mov    r14d,0x420a10
    786625cfe1d2:	movdqu xmm5,XMMWORD PTR [r14]
    786625cfe1d7:	movdqa xmm0,xmm5
    786625cfe1db:	movdqu XMMWORD PTR [r12+0x140],xmm0
    786625cfe1e5:	mov    r14d,0x420000
    786625cfe1eb:	mov    QWORD PTR [r12+0x40],r14
    786625cfe1f0:	mov    r14,r13
    786625cfe1f3:	add    r14,0x100
    786625cfe1fa:	mov    r15,r14
    786625cfe1fd:	add    r15,0x10
    786625cfe201:	movdqu XMMWORD PTR [r14],xmm2
    786625cfe206:	mov    r14d,0x0
    786625cfe20c:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe214:	movdqu XMMWORD PTR [r15],xmm3
    786625cfe219:	mov    r14d,0x0
    786625cfe21f:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe227:	add    r13,0x40
    786625cfe22b:	mov    r14,r13
    786625cfe22e:	add    r14,0x10
    786625cfe232:	movdqu XMMWORD PTR [r13+0x0],xmm6
    786625cfe238:	mov    r13d,0x0
    786625cfe23e:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe246:	movdqu XMMWORD PTR [r14],xmm4
    786625cfe24b:	mov    r13d,0x0
    786625cfe251:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe259:	mov    r13d,0x420a00
    786625cfe25f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625cfe265:	movdqa xmm0,xmm2
    786625cfe269:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625cfe273:	mov    r13d,0x420000
    786625cfe279:	mov    QWORD PTR [r12+0x40],r13
    786625cfe27e:	mov    r13d,0x420a70
    786625cfe284:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    786625cfe28a:	movdqa xmm0,xmm3
    786625cfe28e:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625cfe298:	mov    r13d,0x420000
    786625cfe29e:	mov    QWORD PTR [r12+0x40],r13
    786625cfe2a3:	mov    r13d,0xf8d3
    786625cfe2a9:	mov    QWORD PTR [r12+0x48],r13
    786625cfe2ae:	mov    r13,QWORD PTR [r12+0x98]
    786625cfe2b6:	mov    r14,r13
    786625cfe2b9:	add    r14,0x60
    786625cfe2bd:	mov    r15,r14
    786625cfe2c0:	add    r15,0x10
    786625cfe2c4:	movdqu XMMWORD PTR [r14],xmm5
    786625cfe2c9:	mov    r14d,0x0
    786625cfe2cf:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe2d7:	movdqu XMMWORD PTR [r15],xmm2
    786625cfe2dc:	mov    r14d,0x0
    786625cfe2e2:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe2ea:	mov    r14d,0x420a80
    786625cfe2f0:	movdqu xmm2,XMMWORD PTR [r14]
    786625cfe2f5:	movdqa xmm0,xmm2
    786625cfe2f9:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625cfe303:	mov    r14d,0x420000
    786625cfe309:	mov    QWORD PTR [r12+0x40],r14
    786625cfe30e:	mov    r14d,0x420a50
    786625cfe314:	movdqu xmm2,XMMWORD PTR [r14]
    786625cfe319:	movdqa xmm0,xmm2
    786625cfe31d:	movdqu XMMWORD PTR [r12+0x140],xmm0
    786625cfe327:	mov    r14d,0x420000
    786625cfe32d:	mov    QWORD PTR [r12+0x40],r14
    786625cfe332:	mov    r14d,0xf8d3
    786625cfe338:	mov    r15d,0x421d
    786625cfe33e:	and    r15d,0xffff
    786625cfe345:	mov    rax,r14
    786625cfe348:	movabs rcx,0xffffffff0000ffff
    786625cfe352:	and    rax,rcx
    786625cfe355:	mov    rdx,r15
    786625cfe358:	shl    rdx,0x10
    786625cfe35c:	mov    ecx,0xffff0000
    786625cfe361:	and    rdx,rcx
    786625cfe364:	or     rax,rdx
    786625cfe367:	mov    ebp,eax
    786625cfe369:	mov    QWORD PTR [r12+0x48],rbp
    786625cfe36e:	mov    r14,r13
    786625cfe371:	add    r14,0x80
    786625cfe378:	mov    r15,r14
    786625cfe37b:	add    r15,0x10
    786625cfe37f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625cfe389:	movdqa xmm2,xmm0
    786625cfe38d:	movdqu XMMWORD PTR [r14],xmm3
    786625cfe392:	mov    r14d,0x0
    786625cfe398:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe3a0:	movdqu XMMWORD PTR [r15],xmm2
    786625cfe3a5:	mov    r14d,0x0
    786625cfe3ab:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe3b3:	mov    r14d,0x420af0
    786625cfe3b9:	movdqu xmm2,XMMWORD PTR [r14]
    786625cfe3be:	movdqa xmm0,xmm2
    786625cfe3c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625cfe3cc:	mov    r14d,0x420000
    786625cfe3d2:	mov    QWORD PTR [r12+0x40],r14
    786625cfe3d7:	mov    r14d,0x420b00
    786625cfe3dd:	movdqu xmm3,XMMWORD PTR [r14]
    786625cfe3e2:	movdqa xmm0,xmm3
    786625cfe3e6:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625cfe3f0:	mov    r14d,0x420000
    786625cfe3f6:	mov    QWORD PTR [r12+0x40],r14
    786625cfe3fb:	mov    r14d,0x3e8
    786625cfe401:	mov    QWORD PTR [r12+0xa0],r14
    786625cfe409:	add    r13,0xa0
    786625cfe410:	mov    r14,r13
    786625cfe413:	add    r14,0x10
    786625cfe417:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625cfe421:	movdqa xmm3,xmm0
    786625cfe425:	movdqu XMMWORD PTR [r13+0x0],xmm3
    786625cfe42b:	mov    r13d,0x0
    786625cfe431:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe439:	movdqu XMMWORD PTR [r14],xmm2
    786625cfe43e:	mov    r13d,0x0
    786625cfe444:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe44c:	mov    r13,QWORD PTR [r12+0x40]
    786625cfe451:	add    r13,0xae0
    786625cfe458:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625cfe45e:	movdqa xmm0,xmm2
    786625cfe462:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625cfe46c:	mov    r13d,0x420000
    786625cfe472:	mov    QWORD PTR [r12+0x40],r13
    786625cfe477:	mov    r13d,0x420a90
    786625cfe47d:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625cfe483:	movdqa xmm0,xmm2
    786625cfe487:	movdqu XMMWORD PTR [r12+0x140],xmm0
    786625cfe491:	mov    r13d,0x420000
    786625cfe497:	mov    QWORD PTR [r12+0x40],r13
    786625cfe49c:	mov    r13,QWORD PTR [r12+0xf8]
    786625cfe4a4:	add    r13,0x180
    786625cfe4ab:	mov    r14,r13
    786625cfe4ae:	add    r14,0x8
    786625cfe4b2:	mov    r15,QWORD PTR [r12+0x200]
    786625cfe4ba:	mov    rbp,QWORD PTR [r12+0x1f0]
    786625cfe4c2:	mov    QWORD PTR [r13+0x0],r15
    786625cfe4c6:	mov    r13d,0x0
    786625cfe4cc:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe4d4:	mov    QWORD PTR [r14],rbp
    786625cfe4d7:	mov    r13d,0x0
    786625cfe4dd:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe4e5:	mov    r13,QWORD PTR [r12+0x98]
    786625cfe4ed:	mov    r14,r13
    786625cfe4f0:	add    r14,0xc0
    786625cfe4f7:	mov    r15,r14
    786625cfe4fa:	add    r15,0x10
    786625cfe4fe:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625cfe508:	movdqa xmm2,xmm0
    786625cfe50c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625cfe516:	movdqa xmm3,xmm0
    786625cfe51a:	movdqu XMMWORD PTR [r14],xmm2
    786625cfe51f:	mov    r14d,0x0
    786625cfe525:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe52d:	movdqu XMMWORD PTR [r15],xmm3
    786625cfe532:	mov    r14d,0x0
    786625cfe538:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe540:	mov    r14d,0x420ab0
    786625cfe546:	movdqu xmm2,XMMWORD PTR [r14]
    786625cfe54b:	movdqa xmm0,xmm2
    786625cfe54f:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625cfe559:	mov    r14d,0x420000
    786625cfe55f:	mov    QWORD PTR [r12+0x40],r14
    786625cfe564:	mov    r14d,0x420b18
    786625cfe56a:	mov    r15,QWORD PTR [r14]
    786625cfe56d:	mov    r14d,0x0
    786625cfe573:	mov    QWORD PTR [r12+0x110],r15
    786625cfe57b:	mov    QWORD PTR [r12+0x118],r14
    786625cfe583:	mov    r14d,0x420b20
    786625cfe589:	mov    QWORD PTR [r12+0x40],r14
    786625cfe58e:	mov    r14,r13
    786625cfe591:	add    r14,0xe0
    786625cfe598:	mov    rbp,r14
    786625cfe59b:	add    rbp,0x10
    786625cfe59f:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625cfe5a9:	movdqa xmm3,xmm0
    786625cfe5ad:	movdqu XMMWORD PTR [r14],xmm3
    786625cfe5b2:	mov    r14d,0x0
    786625cfe5b8:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe5c0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    786625cfe5c5:	mov    r14d,0x0
    786625cfe5cb:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe5d3:	mov    r14d,0x420b80
    786625cfe5d9:	movdqu xmm2,XMMWORD PTR [r14]
    786625cfe5de:	movdqa xmm0,xmm2
    786625cfe5e2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625cfe5ec:	add    r13,0x120
    786625cfe5f3:	mov    QWORD PTR [r13+0x0],r15
    786625cfe5f7:	mov    r13d,0x0
    786625cfe5fd:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe605:	mov    r13d,0x420b60
    786625cfe60b:	mov    r14d,0x420b70
    786625cfe611:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    786625cfe617:	movdqu xmm4,XMMWORD PTR [r14]
    786625cfe61c:	movdqa xmm0,xmm3
    786625cfe620:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625cfe62a:	movdqa xmm0,xmm4
    786625cfe62e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625cfe638:	mov    r13,QWORD PTR [r12+0xf8]
    786625cfe640:	mov    r14,r13
    786625cfe643:	add    r14,0x160
    786625cfe64a:	movdqu XMMWORD PTR [r14],xmm2
    786625cfe64f:	mov    r14d,0x0
    786625cfe655:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe65d:	mov    r14,r13
    786625cfe660:	add    r14,0x190
    786625cfe667:	mov    r15,r14
    786625cfe66a:	add    r15,0x8
    786625cfe66e:	mov    rbp,QWORD PTR [r12+0x1e0]
    786625cfe676:	mov    r8,QWORD PTR [r12+0x1d0]
    786625cfe67e:	mov    QWORD PTR [r14],rbp
    786625cfe681:	mov    r14d,0x0
    786625cfe687:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe68f:	mov    QWORD PTR [r15],r8
    786625cfe692:	mov    r14d,0x0
    786625cfe698:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe6a0:	mov    r14,r13
    786625cfe6a3:	add    r14,0x140
    786625cfe6aa:	mov    r15,r14
    786625cfe6ad:	add    r15,0x10
    786625cfe6b1:	movdqu XMMWORD PTR [r14],xmm3
    786625cfe6b6:	mov    r14d,0x0
    786625cfe6bc:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe6c4:	movdqu XMMWORD PTR [r15],xmm4
    786625cfe6c9:	mov    r14d,0x0
    786625cfe6cf:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe6d7:	mov    r14d,0x420b20
    786625cfe6dd:	mov    r15d,0x420b30
    786625cfe6e3:	movdqu xmm2,XMMWORD PTR [r14]
    786625cfe6e8:	movdqu xmm3,XMMWORD PTR [r15]
    786625cfe6ed:	movdqa xmm0,xmm2
    786625cfe6f1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625cfe6fb:	movdqa xmm0,xmm3
    786625cfe6ff:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625cfe709:	mov    r14,r13
    786625cfe70c:	add    r14,0x1a0
    786625cfe713:	mov    r15,r14
    786625cfe716:	add    r15,0x8
    786625cfe71a:	mov    rbp,QWORD PTR [r12+0x1c0]
    786625cfe722:	mov    r8,QWORD PTR [r12+0x1b0]
    786625cfe72a:	mov    QWORD PTR [r14],rbp
    786625cfe72d:	mov    r14d,0x0
    786625cfe733:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe73b:	mov    QWORD PTR [r15],r8
    786625cfe73e:	mov    r14d,0x0
    786625cfe744:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe74c:	mov    r14,r13
    786625cfe74f:	add    r14,0x1b0
    786625cfe756:	mov    r15,r14
    786625cfe759:	add    r15,0x8
    786625cfe75d:	mov    rbp,QWORD PTR [r12+0x1a0]
    786625cfe765:	mov    r8,QWORD PTR [r12+0x190]
    786625cfe76d:	mov    QWORD PTR [r14],rbp
    786625cfe770:	mov    r14d,0x0
    786625cfe776:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe77e:	mov    QWORD PTR [r15],r8
    786625cfe781:	mov    r14d,0x0
    786625cfe787:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe78f:	add    r13,0x100
    786625cfe796:	mov    r14,r13
    786625cfe799:	add    r14,0x10
    786625cfe79d:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625cfe7a7:	movdqa xmm2,xmm0
    786625cfe7ab:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625cfe7b5:	movdqa xmm3,xmm0
    786625cfe7b9:	movdqu XMMWORD PTR [r13+0x0],xmm2
    786625cfe7bf:	mov    r13d,0x0
    786625cfe7c5:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe7cd:	movdqu XMMWORD PTR [r14],xmm3
    786625cfe7d2:	mov    r13d,0x0
    786625cfe7d8:	mov    DWORD PTR [r12+0x32c],r13d
    786625cfe7e0:	mov    r13,QWORD PTR [r12+0x40]
    786625cfe7e5:	add    r13,0x20
    786625cfe7e9:	mov    r14,r13
    786625cfe7ec:	add    r14,0x10
    786625cfe7f0:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625cfe7f6:	movdqu xmm3,XMMWORD PTR [r14]
    786625cfe7fb:	movdqa xmm0,xmm2
    786625cfe7ff:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625cfe809:	movdqa xmm0,xmm3
    786625cfe80d:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625cfe817:	mov    r13,QWORD PTR [r12+0xf8]
    786625cfe81f:	mov    r14,r13
    786625cfe822:	add    r14,0x1c0
    786625cfe829:	mov    r15,r14
    786625cfe82c:	add    r15,0x8
    786625cfe830:	mov    rbp,QWORD PTR [r12+0xe8]
    786625cfe838:	mov    r8,QWORD PTR [r12+0xf0]
    786625cfe840:	mov    QWORD PTR [r14],rbp
    786625cfe843:	mov    r14d,0x0
    786625cfe849:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe851:	mov    QWORD PTR [r15],r8
    786625cfe854:	mov    r14d,0x0
    786625cfe85a:	mov    DWORD PTR [r12+0x32c],r14d
    786625cfe862:	mov    r14,QWORD PTR [r12+0x98]
    786625cfe86a:	mov    r15,r14
    786625cfe86d:	add    r15,0x128
    786625cfe874:	mov    ebp,DWORD PTR [r12+0x48]
    786625cfe879:	mov    DWORD PTR [r15],ebp
    786625cfe87c:	mov    r15d,0x0
    786625cfe882:	mov    DWORD PTR [r12+0x32c],r15d
    786625cfe88a:	mov    r15,r13
    786625cfe88d:	add    r15,0x120
    786625cfe894:	mov    rbp,r15
    786625cfe897:	add    rbp,0x10
    786625cfe89b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625cfe8a5:	movdqa xmm2,xmm0
    786625cfe8a9:	movdqu XMMWORD PTR [r15],xmm2
    786625cfe8ae:	mov    r15d,0x0
    786625cfe8b4:	mov    DWORD PTR [r12+0x32c],r15d
    786625cfe8bc:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    786625cfe8c1:	mov    r15d,0x0
    786625cfe8c7:	mov    DWORD PTR [r12+0x32c],r15d
    786625cfe8cf:	add    r13,0x100
    786625cfe8d6:	mov    QWORD PTR [r12],r13
    786625cfe8da:	mov    r13d,0x0
    786625cfe8e0:	mov    rcx,r14
    786625cfe8e3:	or     r13,rcx
    786625cfe8e6:	mov    QWORD PTR [r12+0x8],r13
    786625cfe8eb:	mov    r13d,0x12c
    786625cfe8f1:	mov    QWORD PTR [r12+0x10],r13
    786625cfe8f6:	mov    r13d,0x410284
    786625cfe8fc:	mov    QWORD PTR [r12+0xf0],r13
    786625cfe904:	mov    r13d,0x410728
    786625cfe90a:	mov    QWORD PTR [r12+0x100],r13
    786625cfe912:	mov    r11,QWORD PTR [rsp]
    786625cfe916:	mov    QWORD PTR [r12+0x398],r11
    786625cfe91e:	mov    edi,0x410728
    786625cfe923:	mov    QWORD PTR [r12+0x100],rdi
    786625cfe92b:	add    rsp,0x10
    786625cfe92f:	nop
    786625cfe930:	jmp    QWORD PTR [rip+0x2]        # 0x786625cfe938
    786625cfe936:	xchg   ax,ax
    786625cfe938:	(bad)
    786625cfe939:	jmp    0x78669e360f0d
    786625cfe93e:	add    BYTE PTR [rax],al
    786625cfe940:	rex.W jmp 0x78669e360f15
    786625cfe946:	add    BYTE PTR [rax],al
    786625cfe948:	movabs r11,0x5c9c39de20a0
    786625cfe952:	jmp    r11
    786625cfe955:	nop
    786625cfe956:	nop
    786625cfe957:	nop
