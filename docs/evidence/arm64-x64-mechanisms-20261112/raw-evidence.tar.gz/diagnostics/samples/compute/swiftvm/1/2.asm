
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/1/2.bin:     file format binary


Disassembly of section .data:

0000707120f01570 <.data>:
    707120f01570:	sub    rsp,0x10
    707120f01574:	mov    r13d,DWORD PTR [r12+0xa0]
    707120f0157c:	sub    r13d,0x1
    707120f01580:	mov    QWORD PTR [r12+0xa0],r13
    707120f01588:	mov    rcx,QWORD PTR [r12+0x380]
    707120f01590:	jrcxz  0x707120f01597
    707120f01592:	jmp    0x707120f01715
    707120f01597:	pushf
    707120f01598:	pop    r11
    707120f0159a:	mov    QWORD PTR [rsp],r11
    707120f0159e:	jne    0x707120f0167d
    707120f015a4:	jmp    0x707120f015a9
    707120f015a9:	mov    r13,QWORD PTR [r12+0xf8]
    707120f015b1:	mov    r14,r13
    707120f015b4:	add    r14,0x120
    707120f015bb:	mov    r15,QWORD PTR [r14]
    707120f015be:	mov    QWORD PTR [r12+0x98],r15
    707120f015c6:	mov    r14d,0x80
    707120f015cc:	mov    QWORD PTR [r12+0x40],r14
    707120f015d1:	mov    r14,r13
    707120f015d4:	add    r14,0x100
    707120f015db:	mov    QWORD PTR [r12],r14
    707120f015df:	mov    r14,r13
    707120f015e2:	add    r14,0x17c
    707120f015e9:	mov    QWORD PTR [r12+0x8],r14
    707120f015ee:	mov    r14d,0x1
    707120f015f4:	mov    QWORD PTR [r12+0x10],r14
    707120f015f9:	add    r13,0x17c
    707120f01600:	movzx  r14d,BYTE PTR [r12+0x40]
    707120f01606:	mov    BYTE PTR [r13+0x0],r14b
    707120f0160a:	mov    r13d,0x0
    707120f01610:	mov    DWORD PTR [r12+0x32c],r13d
    707120f01618:	mov    r13d,0x4102a8
    707120f0161e:	mov    QWORD PTR [r12+0xf0],r13
    707120f01626:	mov    r13d,0x410728
    707120f0162c:	mov    QWORD PTR [r12+0x100],r13
    707120f01634:	mov    r11,QWORD PTR [rsp]
    707120f01638:	mov    QWORD PTR [r12+0x398],r11
    707120f01640:	mov    edi,0x410728
    707120f01645:	mov    QWORD PTR [r12+0x100],rdi
    707120f0164d:	add    rsp,0x10
    707120f01651:	nop    DWORD PTR [rax+0x0]
    707120f01658:	jmp    QWORD PTR [rip+0x2]        # 0x707120f01660
    707120f0165e:	xchg   ax,ax
    707120f01660:	(bad)
    707120f01661:	jmp    0x707191613755
    707120f01666:	add    BYTE PTR [rax],al
    707120f01668:	jo     0x707120f01680
    707120f0166a:	lock and BYTE PTR [rcx+0x70],dh
    707120f0166e:	add    BYTE PTR [rax],al
    707120f01670:	movabs r11,0x5ab6724ae0a0
    707120f0167a:	jmp    r11
    707120f0167d:	mov    r13,QWORD PTR [r12+0xf8]
    707120f01685:	add    r13,0x100
    707120f0168c:	mov    QWORD PTR [r12],r13
    707120f01690:	mov    r13d,0x0
    707120f01696:	mov    r14,QWORD PTR [r12+0x98]
    707120f0169e:	mov    rcx,r14
    707120f016a1:	or     r13,rcx
    707120f016a4:	mov    QWORD PTR [r12+0x8],r13
    707120f016a9:	mov    r13d,0x12c
    707120f016af:	mov    QWORD PTR [r12+0x10],r13
    707120f016b4:	mov    r13d,0x410284
    707120f016ba:	mov    QWORD PTR [r12+0xf0],r13
    707120f016c2:	mov    r13d,0x410728
    707120f016c8:	mov    QWORD PTR [r12+0x100],r13
    707120f016d0:	mov    r11,QWORD PTR [rsp]
    707120f016d4:	mov    QWORD PTR [r12+0x398],r11
    707120f016dc:	mov    edi,0x410728
    707120f016e1:	mov    QWORD PTR [r12+0x100],rdi
    707120f016e9:	add    rsp,0x10
    707120f016ed:	nop    DWORD PTR [rax]
    707120f016f0:	jmp    QWORD PTR [rip+0x2]        # 0x707120f016f8
    707120f016f6:	xchg   ax,ax
    707120f016f8:	(bad)
    707120f016f9:	jmp    0x7071916137ed
    707120f016fe:	add    BYTE PTR [rax],al
    707120f01700:	or     BYTE PTR [rdi],dl
    707120f01702:	lock and BYTE PTR [rcx+0x70],dh
    707120f01706:	add    BYTE PTR [rax],al
    707120f01708:	movabs r11,0x5ab6724ae0a0
    707120f01712:	jmp    r11
    707120f01715:	mov    eax,0x410288
    707120f0171a:	mov    QWORD PTR [r12+0x100],rax
    707120f01722:	push   rdx
    707120f01723:	push   rsi
    707120f01724:	push   r10
    707120f01726:	push   r11
    707120f01728:	pushf
    707120f01729:	pop    r11
    707120f0172b:	mov    QWORD PTR [rsp+0x20],r11
    707120f01730:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f01735:	mov    r10d,edx
    707120f01738:	and    r10d,0xc0
    707120f0173f:	shl    r10d,0x18
    707120f01743:	mov    r11d,edx
    707120f01746:	and    r11d,0x1
    707120f0174a:	shl    r11d,0x1d
    707120f0174e:	or     r10d,r11d
    707120f01751:	mov    r11d,edx
    707120f01754:	and    r11d,0x800
    707120f0175b:	shl    r11d,0x11
    707120f0175f:	or     r10d,r11d
    707120f01762:	btc    r10,0x1d
    707120f01767:	mov    r11d,0xf0000000
    707120f0176d:	and    r11,r10
    707120f01770:	movabs rsi,0xffffffff0fffffff
    707120f0177a:	and    rbx,rsi
    707120f0177d:	or     rbx,r11
    707120f01780:	pop    r11
    707120f01782:	pop    r10
    707120f01784:	pop    rsi
    707120f01785:	pop    rdx
    707120f01786:	mov    QWORD PTR [r12+0x108],rbx
    707120f0178e:	add    rsp,0x10
    707120f01792:	mov    eax,0xc
    707120f01797:	movabs r11,0x5ab6724ae390
    707120f017a1:	jmp    r11
    707120f017a4:	data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f017b0:	sub    rsp,0x10
    707120f017b4:	mov    r11,QWORD PTR [r12+0x398]
    707120f017bc:	mov    QWORD PTR [rsp],r11
    707120f017c0:	jmp    0x707120f015a9
    707120f017c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f017d0:	sub    rsp,0x10
    707120f017d4:	mov    r11,QWORD PTR [r12+0x398]
    707120f017dc:	mov    QWORD PTR [rsp],r11
    707120f017e0:	jmp    0x707120f0167d
    707120f017e5:	nop
    707120f017e6:	nop
    707120f017e7:	nop
