
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/1/3.bin:     file format binary


Disassembly of section .data:

0000707120f017f0 <.data>:
    707120f017f0:	sub    rsp,0x10
    707120f017f4:	mov    r11,QWORD PTR [r12+0x398]
    707120f017fc:	mov    QWORD PTR [rsp],r11
    707120f01800:	mov    r13,QWORD PTR [r12+0xf8]
    707120f01808:	mov    r14,r13
    707120f0180b:	add    r14,0x168
    707120f01812:	mov    r15,QWORD PTR [r14]
    707120f01815:	mov    QWORD PTR [r12+0x40],r15
    707120f0181a:	add    r13,0x178
    707120f01821:	mov    r14d,0x0
    707120f01827:	mov    BYTE PTR [r13+0x0],r14b
    707120f0182b:	mov    r13d,0x0
    707120f01831:	mov    DWORD PTR [r12+0x32c],r13d
    707120f01839:	sub    r15,0x38
    707120f0183d:	pushf
    707120f0183e:	pop    r11
    707120f01840:	mov    QWORD PTR [rsp],r11
    707120f01844:	je     0x707120f018dd
    707120f0184a:	jmp    0x707120f0184f
    707120f0184f:	mov    r13,QWORD PTR [r12+0xf8]
    707120f01857:	mov    r14,r13
    707120f0185a:	add    r14,0x100
    707120f01861:	mov    QWORD PTR [r12],r14
    707120f01865:	add    r13,0x178
    707120f0186c:	mov    QWORD PTR [r12+0x8],r13
    707120f01871:	mov    r13d,0x1
    707120f01877:	mov    QWORD PTR [r12+0x10],r13
    707120f0187c:	mov    r13d,0x4102c8
    707120f01882:	mov    QWORD PTR [r12+0xf0],r13
    707120f0188a:	mov    r13d,0x410728
    707120f01890:	mov    QWORD PTR [r12+0x100],r13
    707120f01898:	mov    r11,QWORD PTR [rsp]
    707120f0189c:	mov    QWORD PTR [r12+0x398],r11
    707120f018a4:	mov    edi,0x410728
    707120f018a9:	mov    QWORD PTR [r12+0x100],rdi
    707120f018b1:	add    rsp,0x10
    707120f018b5:	nop    DWORD PTR [rax]
    707120f018b8:	jmp    QWORD PTR [rip+0x2]        # 0x707120f018c0
    707120f018be:	xchg   ax,ax
    707120f018c0:	(bad)
    707120f018c1:	jmp    0x7071916139b5
    707120f018c6:	add    BYTE PTR [rax],al
    707120f018c8:	rcr    BYTE PTR [rax],1
    707120f018ca:	lock and BYTE PTR [rcx+0x70],dh
    707120f018ce:	add    BYTE PTR [rax],al
    707120f018d0:	movabs r11,0x5ab6724ae0a0
    707120f018da:	jmp    r11
    707120f018dd:	mov    r13,QWORD PTR [r12+0x98]
    707120f018e5:	ror    r13,0x3d
    707120f018e9:	and    r13,0xfffffffffffffff8
    707120f018ed:	mov    r14,QWORD PTR [r12+0xf8]
    707120f018f5:	mov    r15,r14
    707120f018f8:	add    r15,0x100
    707120f018ff:	mov    QWORD PTR [r12],r15
    707120f01903:	mov    r15,r14
    707120f01906:	add    r15,0x170
    707120f0190d:	mov    QWORD PTR [r12+0x8],r15
    707120f01912:	mov    r15d,0x8
    707120f01918:	mov    QWORD PTR [r12+0x10],r15
    707120f0191d:	movabs rcx,0xff00ff00ff00ff
    707120f01927:	mov    r15,r13
    707120f0192a:	and    r15,rcx
    707120f0192d:	shl    r15,0x8
    707120f01931:	movabs rcx,0xff00ff00ff00ff00
    707120f0193b:	and    r13,rcx
    707120f0193e:	shr    r13,0x8
    707120f01942:	mov    rcx,r15
    707120f01945:	or     r13,rcx
    707120f01948:	movabs rcx,0xffff0000ffff
    707120f01952:	mov    r15,r13
    707120f01955:	and    r15,rcx
    707120f01958:	shl    r15,0x10
    707120f0195c:	movabs rcx,0xffff0000ffff0000
    707120f01966:	and    r13,rcx
    707120f01969:	shr    r13,0x10
    707120f0196d:	mov    rcx,r15
    707120f01970:	or     r13,rcx
    707120f01973:	mov    r15,r13
    707120f01976:	shl    r15,0x20
    707120f0197a:	shr    r13,0x20
    707120f0197e:	mov    rcx,r15
    707120f01981:	or     r13,rcx
    707120f01984:	mov    QWORD PTR [r12+0x40],r13
    707120f01989:	add    r14,0x170
    707120f01990:	mov    QWORD PTR [r14],r13
    707120f01993:	mov    r13d,0x0
    707120f01999:	mov    DWORD PTR [r12+0x32c],r13d
    707120f019a1:	mov    r13d,0x4102f0
    707120f019a7:	mov    QWORD PTR [r12+0xf0],r13
    707120f019af:	mov    r13d,0x410728
    707120f019b5:	mov    QWORD PTR [r12+0x100],r13
    707120f019bd:	mov    r11,QWORD PTR [rsp]
    707120f019c1:	mov    QWORD PTR [r12+0x398],r11
    707120f019c9:	mov    edi,0x410728
    707120f019ce:	mov    QWORD PTR [r12+0x100],rdi
    707120f019d6:	add    rsp,0x10
    707120f019da:	nop    WORD PTR [rax+rax*1+0x0]
    707120f019e0:	jmp    QWORD PTR [rip+0x2]        # 0x707120f019e8
    707120f019e6:	xchg   ax,ax
    707120f019e8:	(bad)
    707120f019e9:	jmp    0x707191613add
    707120f019ee:	add    BYTE PTR [rax],al
    707120f019f0:	clc
    707120f019f1:	sbb    eax,esi
    707120f019f3:	and    BYTE PTR [rcx+0x70],dh
    707120f019f6:	add    BYTE PTR [rax],al
    707120f019f8:	movabs r11,0x5ab6724ae0a0
    707120f01a02:	jmp    r11
    707120f01a05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f01a10:	sub    rsp,0x10
    707120f01a14:	mov    r11,QWORD PTR [r12+0x398]
    707120f01a1c:	mov    QWORD PTR [rsp],r11
    707120f01a20:	jmp    0x707120f0184f
    707120f01a25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f01a30:	sub    rsp,0x10
    707120f01a34:	mov    r11,QWORD PTR [r12+0x398]
    707120f01a3c:	mov    QWORD PTR [rsp],r11
    707120f01a40:	jmp    0x707120f018dd
    707120f01a45:	nop
    707120f01a46:	nop
    707120f01a47:	nop
