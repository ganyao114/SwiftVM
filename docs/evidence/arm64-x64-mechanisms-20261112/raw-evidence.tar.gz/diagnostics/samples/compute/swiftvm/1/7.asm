
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/1/7.bin:     file format binary


Disassembly of section .data:

0000707120f02390 <.data>:
    707120f02390:	sub    rsp,0x10
    707120f02394:	mov    r11,QWORD PTR [r12+0x398]
    707120f0239c:	mov    QWORD PTR [rsp],r11
    707120f023a0:	mov    r13,QWORD PTR [r12+0xa0]
    707120f023a8:	mov    r14,r13
    707120f023ab:	shl    r14,0x2
    707120f023af:	mov    r15,QWORD PTR [r12+0x98]
    707120f023b7:	mov    rcx,r14
    707120f023ba:	add    r15,rcx
    707120f023bd:	mov    r14d,DWORD PTR [r12]
    707120f023c1:	mov    DWORD PTR [r15],r14d
    707120f023c4:	mov    r14d,0x0
    707120f023ca:	mov    DWORD PTR [r12+0x32c],r14d
    707120f023d2:	add    r13,0x1
    707120f023d6:	mov    QWORD PTR [r12+0xa0],r13
    707120f023de:	sub    r13,0x400
    707120f023e5:	mov    rcx,QWORD PTR [r12+0x380]
    707120f023ed:	jrcxz  0x707120f023f4
    707120f023ef:	jmp    0x707120f027e5
    707120f023f4:	pushf
    707120f023f5:	pop    r11
    707120f023f7:	mov    QWORD PTR [rsp],r11
    707120f023fb:	jne    0x707120f02775
    707120f02401:	jmp    0x707120f02406
    707120f02406:	mov    r13d,0x1
    707120f0240c:	mov    QWORD PTR [r12+0x40],r13
    707120f02411:	jmp    0x707120f02416
    707120f02416:	mov    r13,QWORD PTR [r12+0x40]
    707120f0241b:	mov    r14,r13
    707120f0241e:	shl    r14,0x2
    707120f02422:	mov    r15,QWORD PTR [r12+0x98]
    707120f0242a:	mov    rcx,r14
    707120f0242d:	add    r15,rcx
    707120f02430:	mov    r14d,DWORD PTR [r15]
    707120f02433:	mov    QWORD PTR [r12+0x48],r14
    707120f02438:	mov    r14d,0x0
    707120f0243e:	mov    rcx,r13
    707120f02441:	or     r14,rcx
    707120f02444:	mov    QWORD PTR [r12+0x50],r14
    707120f02449:	jmp    0x707120f0244e
    707120f0244e:	mov    r13d,DWORD PTR [r12+0x50]
    707120f02453:	sub    r13d,0x1
    707120f02457:	mov    QWORD PTR [r12+0x58],r13
    707120f0245c:	mov    ecx,0xffffffff
    707120f02461:	mov    r14,r13
    707120f02464:	and    r14,rcx
    707120f02467:	shl    r14,0x2
    707120f0246b:	mov    r13,QWORD PTR [r12+0x98]
    707120f02473:	mov    rcx,r14
    707120f02476:	add    r13,rcx
    707120f02479:	mov    r14d,DWORD PTR [r13+0x0]
    707120f0247d:	mov    QWORD PTR [r12+0x60],r14
    707120f02482:	mov    r13d,DWORD PTR [r12+0x48]
    707120f02487:	mov    ecx,r13d
    707120f0248a:	sub    r14d,ecx
    707120f0248d:	mov    rcx,QWORD PTR [r12+0x380]
    707120f02495:	jrcxz  0x707120f0249c
    707120f02497:	jmp    0x707120f02874
    707120f0249c:	sete   al
    707120f0249f:	movzx  eax,al
    707120f024a2:	mov    r13,rax
    707120f024a5:	setb   al
    707120f024a8:	movzx  eax,al
    707120f024ab:	mov    r14,rax
    707120f024ae:	pushf
    707120f024af:	pop    r11
    707120f024b1:	mov    QWORD PTR [rsp],r11
    707120f024b5:	mov    rcx,r13
    707120f024b8:	and    ecx,0xff
    707120f024be:	mov    r15,r14
    707120f024c1:	and    r15d,0xff
    707120f024c8:	or     r15,rcx
    707120f024cb:	and    r15d,0xff
    707120f024d2:	mov    rax,r15
    707120f024d5:	and    eax,0xff
    707120f024da:	test   rax,rax
    707120f024dd:	jne    0x707120f0257f
    707120f024e3:	jmp    0x707120f024e8
    707120f024e8:	mov    r13,QWORD PTR [r12+0x50]
    707120f024ed:	mov    r14,r13
    707120f024f0:	shl    r14,0x2
    707120f024f4:	mov    r15,QWORD PTR [r12+0x98]
    707120f024fc:	mov    rcx,r14
    707120f024ff:	add    r15,rcx
    707120f02502:	mov    r14d,DWORD PTR [r12+0x60]
    707120f02507:	mov    DWORD PTR [r15],r14d
    707120f0250a:	mov    r14d,0x0
    707120f02510:	mov    DWORD PTR [r12+0x32c],r14d
    707120f02518:	sub    r13,0x1
    707120f0251c:	mov    QWORD PTR [r12+0x50],r13
    707120f02521:	mov    rcx,QWORD PTR [r12+0x380]
    707120f02529:	jrcxz  0x707120f02530
    707120f0252b:	jmp    0x707120f02903
    707120f02530:	mov    r13,QWORD PTR [r12+0x58]
    707120f02535:	mov    rax,r13
    707120f02538:	test   rax,rax
    707120f0253b:	setne  al
    707120f0253e:	movzx  eax,al
    707120f02541:	and    eax,0x1
    707120f02544:	mov    r14,rax
    707120f02547:	mov    rax,r14
    707120f0254a:	and    eax,0x1
    707120f0254d:	test   rax,rax
    707120f02550:	jne    0x707120f0244e
    707120f02556:	jmp    0x707120f0255b
    707120f0255b:	mov    rcx,QWORD PTR [r12+0x380]
    707120f02563:	jrcxz  0x707120f0256a
    707120f02565:	jmp    0x707120f0298a
    707120f0256a:	jmp    0x707120f0256f
    707120f0256f:	mov    r13d,0x0
    707120f02575:	mov    QWORD PTR [r12+0x50],r13
    707120f0257a:	jmp    0x707120f0257f
    707120f0257f:	mov    r13,QWORD PTR [r12+0x40]
    707120f02584:	add    r13,0x1
    707120f02588:	mov    QWORD PTR [r12+0x40],r13
    707120f0258d:	mov    r14,QWORD PTR [r12+0x50]
    707120f02592:	mov    ecx,0xffffffff
    707120f02597:	and    r14,rcx
    707120f0259a:	shl    r14,0x2
    707120f0259e:	mov    r15,QWORD PTR [r12+0x98]
    707120f025a6:	mov    rcx,r14
    707120f025a9:	add    r15,rcx
    707120f025ac:	mov    r14d,DWORD PTR [r12+0x48]
    707120f025b1:	mov    DWORD PTR [r15],r14d
    707120f025b4:	mov    r14d,0x0
    707120f025ba:	mov    DWORD PTR [r12+0x32c],r14d
    707120f025c2:	sub    r13,0x400
    707120f025c9:	pushf
    707120f025ca:	pop    r11
    707120f025cc:	mov    QWORD PTR [rsp],r11
    707120f025d0:	je     0x707120f025db
    707120f025d6:	jmp    0x707120f02416
    707120f025db:	mov    r13d,0x430000
    707120f025e1:	mov    QWORD PTR [r12+0x40],r13
    707120f025e6:	mov    r13d,0x0
    707120f025ec:	mov    QWORD PTR [r12+0x58],r13
    707120f025f1:	mov    r13d,0x0
    707120f025f7:	mov    QWORD PTR [r12+0x50],r13
    707120f025fc:	mov    r13d,0x430cb0
    707120f02602:	mov    r14,QWORD PTR [r13+0x0]
    707120f02606:	mov    QWORD PTR [r12+0x48],r14
    707120f0260b:	jmp    0x707120f02610
    707120f02610:	mov    r13,QWORD PTR [r12+0x58]
    707120f02615:	mov    r14,r13
    707120f02618:	shl    r14,0x2
    707120f0261c:	mov    r15,QWORD PTR [r12+0x98]
    707120f02624:	mov    rcx,r14
    707120f02627:	add    r15,rcx
    707120f0262a:	mov    QWORD PTR [r12+0x60],r15
    707120f0262f:	mov    r14,r15
    707120f02632:	add    r14,0x4
    707120f02636:	mov    ebp,DWORD PTR [r15]
    707120f02639:	mov    r15d,DWORD PTR [r14]
    707120f0263c:	mov    QWORD PTR [r12+0x60],r15
    707120f02641:	mov    rax,rbp
    707120f02644:	mov    rcx,r13
    707120f02647:	imul   rax,rcx
    707120f0264b:	mov    r14,rax
    707120f0264e:	mov    rcx,r14
    707120f02651:	mov    r8,rbp
    707120f02654:	add    r8,rcx
    707120f02657:	mov    QWORD PTR [r12+0x68],r8
    707120f0265c:	add    r13,0x2
    707120f02660:	mov    QWORD PTR [r12+0x58],r13
    707120f02665:	mov    r14,r13
    707120f02668:	sub    r14,0x400
    707120f0266f:	mov    r14,QWORD PTR [r12+0x50]
    707120f02674:	pushf
    707120f02675:	pop    r11
    707120f02677:	mov    QWORD PTR [rsp],r11
    707120f0267b:	mov    rax,r13
    707120f0267e:	mov    rcx,r15
    707120f02681:	imul   rax,rcx
    707120f02685:	mov    rbp,rax
    707120f02688:	mov    rcx,rbp
    707120f0268b:	add    r14,rcx
    707120f0268e:	mov    QWORD PTR [r12+0x50],r14
    707120f02693:	mov    r13,QWORD PTR [r12+0x48]
    707120f02698:	mov    rcx,r13
    707120f0269b:	add    r8,rcx
    707120f0269e:	mov    QWORD PTR [r12+0x48],r8
    707120f026a3:	mov    rcx,QWORD PTR [r12+0x380]
    707120f026ab:	jrcxz  0x707120f026b2
    707120f026ad:	jmp    0x707120f02a11
    707120f026b2:	push   QWORD PTR [rsp]
    707120f026b5:	popf
    707120f026b6:	jne    0x707120f02610
    707120f026bc:	jmp    0x707120f026c1
    707120f026c1:	mov    r13d,0x0
    707120f026c7:	mov    QWORD PTR [r12+0x98],r13
    707120f026cf:	mov    r13,QWORD PTR [r12+0x48]
    707120f026d4:	mov    r14,QWORD PTR [r12+0x50]
    707120f026d9:	mov    rcx,r13
    707120f026dc:	add    r14,rcx
    707120f026df:	mov    QWORD PTR [r12+0x48],r14
    707120f026e4:	mov    r13d,0x1
    707120f026ea:	mov    QWORD PTR [r12],r13
    707120f026ee:	mov    r13,QWORD PTR [r12+0x40]
    707120f026f3:	add    r13,0xcb0
    707120f026fa:	mov    QWORD PTR [r13+0x0],r14
    707120f026fe:	mov    r13d,0x0
    707120f02704:	mov    DWORD PTR [r12+0x32c],r13d
    707120f0270c:	mov    r13d,0x1
    707120f02712:	mov    QWORD PTR [r12],r13
    707120f02716:	mov    r13d,0x4103f8
    707120f0271c:	mov    QWORD PTR [r12+0xf0],r13
    707120f02724:	mov    r13d,0x4109a4
    707120f0272a:	mov    QWORD PTR [r12+0x100],r13
    707120f02732:	mov    r11,QWORD PTR [rsp]
    707120f02736:	mov    QWORD PTR [r12+0x398],r11
    707120f0273e:	mov    edi,0x4109a4
    707120f02743:	mov    QWORD PTR [r12+0x100],rdi
    707120f0274b:	add    rsp,0x10
    707120f0274f:	nop
    707120f02750:	jmp    QWORD PTR [rip+0x2]        # 0x707120f02758
    707120f02756:	xchg   ax,ax
    707120f02758:	nop
    707120f02759:	and    eax,esi
    707120f0275b:	and    BYTE PTR [rcx+0x70],dh
    707120f0275e:	add    BYTE PTR [rax],al
    707120f02760:	push   0x7120f027
    707120f02765:	jo     0x707120f02767
    707120f02767:	add    BYTE PTR [rcx-0x45],cl
    707120f0276a:	movabs al,ds:0x4100005ab6724ae0
    707120f02773:	jmp    rbx
    707120f02775:	mov    r13d,DWORD PTR [r12+0xa0]
    707120f0277d:	add    r13d,0x11
    707120f02781:	mov    QWORD PTR [r12],r13
    707120f02785:	mov    r13d,0x41035c
    707120f0278b:	mov    QWORD PTR [r12+0xf0],r13
    707120f02793:	mov    r13d,0x4109a4
    707120f02799:	mov    QWORD PTR [r12+0x100],r13
    707120f027a1:	mov    r11,QWORD PTR [rsp]
    707120f027a5:	mov    QWORD PTR [r12+0x398],r11
    707120f027ad:	mov    edi,0x4109a4
    707120f027b2:	mov    QWORD PTR [r12+0x100],rdi
    707120f027ba:	add    rsp,0x10
    707120f027be:	xchg   ax,ax
    707120f027c0:	jmp    QWORD PTR [rip+0x2]        # 0x707120f027c8
    707120f027c6:	xchg   ax,ax
    707120f027c8:	nop
    707120f027c9:	and    eax,esi
    707120f027cb:	and    BYTE PTR [rcx+0x70],dh
    707120f027ce:	add    BYTE PTR [rax],al
    707120f027d0:	fsub   DWORD PTR [rdi]
    707120f027d2:	lock and BYTE PTR [rcx+0x70],dh
    707120f027d6:	add    BYTE PTR [rax],al
    707120f027d8:	movabs r11,0x5ab6724ae0a0
    707120f027e2:	jmp    r11
    707120f027e5:	mov    eax,0x410368
    707120f027ea:	mov    QWORD PTR [r12+0x100],rax
    707120f027f2:	push   rdx
    707120f027f3:	push   rsi
    707120f027f4:	push   r10
    707120f027f6:	push   r11
    707120f027f8:	pushf
    707120f027f9:	pop    r11
    707120f027fb:	mov    QWORD PTR [rsp+0x20],r11
    707120f02800:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f02805:	mov    r10d,edx
    707120f02808:	and    r10d,0xc0
    707120f0280f:	shl    r10d,0x18
    707120f02813:	mov    r11d,edx
    707120f02816:	and    r11d,0x1
    707120f0281a:	shl    r11d,0x1d
    707120f0281e:	or     r10d,r11d
    707120f02821:	mov    r11d,edx
    707120f02824:	and    r11d,0x800
    707120f0282b:	shl    r11d,0x11
    707120f0282f:	or     r10d,r11d
    707120f02832:	btc    r10,0x1d
    707120f02837:	mov    r11d,0xf0000000
    707120f0283d:	and    r11,r10
    707120f02840:	movabs rsi,0xffffffff0fffffff
    707120f0284a:	and    rbx,rsi
    707120f0284d:	or     rbx,r11
    707120f02850:	pop    r11
    707120f02852:	pop    r10
    707120f02854:	pop    rsi
    707120f02855:	pop    rdx
    707120f02856:	mov    QWORD PTR [r12+0x108],rbx
    707120f0285e:	add    rsp,0x10
    707120f02862:	mov    eax,0xc
    707120f02867:	movabs r11,0x5ab6724ae390
    707120f02871:	jmp    r11
    707120f02874:	mov    eax,0x41039c
    707120f02879:	mov    QWORD PTR [r12+0x100],rax
    707120f02881:	push   rdx
    707120f02882:	push   rsi
    707120f02883:	push   r10
    707120f02885:	push   r11
    707120f02887:	pushf
    707120f02888:	pop    r11
    707120f0288a:	mov    QWORD PTR [rsp+0x20],r11
    707120f0288f:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f02894:	mov    r10d,edx
    707120f02897:	and    r10d,0xc0
    707120f0289e:	shl    r10d,0x18
    707120f028a2:	mov    r11d,edx
    707120f028a5:	and    r11d,0x1
    707120f028a9:	shl    r11d,0x1d
    707120f028ad:	or     r10d,r11d
    707120f028b0:	mov    r11d,edx
    707120f028b3:	and    r11d,0x800
    707120f028ba:	shl    r11d,0x11
    707120f028be:	or     r10d,r11d
    707120f028c1:	btc    r10,0x1d
    707120f028c6:	mov    r11d,0xf0000000
    707120f028cc:	and    r11,r10
    707120f028cf:	movabs rsi,0xffffffff0fffffff
    707120f028d9:	and    rbx,rsi
    707120f028dc:	or     rbx,r11
    707120f028df:	pop    r11
    707120f028e1:	pop    r10
    707120f028e3:	pop    rsi
    707120f028e4:	pop    rdx
    707120f028e5:	mov    QWORD PTR [r12+0x108],rbx
    707120f028ed:	add    rsp,0x10
    707120f028f1:	mov    eax,0xc
    707120f028f6:	movabs r11,0x5ab6724ae390
    707120f02900:	jmp    r11
    707120f02903:	mov    eax,0x4103a8
    707120f02908:	mov    QWORD PTR [r12+0x100],rax
    707120f02910:	push   rdx
    707120f02911:	push   rsi
    707120f02912:	push   r10
    707120f02914:	push   r11
    707120f02916:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f0291b:	mov    r10d,edx
    707120f0291e:	and    r10d,0xc0
    707120f02925:	shl    r10d,0x18
    707120f02929:	mov    r11d,edx
    707120f0292c:	and    r11d,0x1
    707120f02930:	shl    r11d,0x1d
    707120f02934:	or     r10d,r11d
    707120f02937:	mov    r11d,edx
    707120f0293a:	and    r11d,0x800
    707120f02941:	shl    r11d,0x11
    707120f02945:	or     r10d,r11d
    707120f02948:	btc    r10,0x1d
    707120f0294d:	mov    r11d,0xf0000000
    707120f02953:	and    r11,r10
    707120f02956:	movabs rsi,0xffffffff0fffffff
    707120f02960:	and    rbx,rsi
    707120f02963:	or     rbx,r11
    707120f02966:	pop    r11
    707120f02968:	pop    r10
    707120f0296a:	pop    rsi
    707120f0296b:	pop    rdx
    707120f0296c:	mov    QWORD PTR [r12+0x108],rbx
    707120f02974:	add    rsp,0x10
    707120f02978:	mov    eax,0xc
    707120f0297d:	movabs r11,0x5ab6724ae390
    707120f02987:	jmp    r11
    707120f0298a:	mov    eax,0x4103ac
    707120f0298f:	mov    QWORD PTR [r12+0x100],rax
    707120f02997:	push   rdx
    707120f02998:	push   rsi
    707120f02999:	push   r10
    707120f0299b:	push   r11
    707120f0299d:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f029a2:	mov    r10d,edx
    707120f029a5:	and    r10d,0xc0
    707120f029ac:	shl    r10d,0x18
    707120f029b0:	mov    r11d,edx
    707120f029b3:	and    r11d,0x1
    707120f029b7:	shl    r11d,0x1d
    707120f029bb:	or     r10d,r11d
    707120f029be:	mov    r11d,edx
    707120f029c1:	and    r11d,0x800
    707120f029c8:	shl    r11d,0x11
    707120f029cc:	or     r10d,r11d
    707120f029cf:	btc    r10,0x1d
    707120f029d4:	mov    r11d,0xf0000000
    707120f029da:	and    r11,r10
    707120f029dd:	movabs rsi,0xffffffff0fffffff
    707120f029e7:	and    rbx,rsi
    707120f029ea:	or     rbx,r11
    707120f029ed:	pop    r11
    707120f029ef:	pop    r10
    707120f029f1:	pop    rsi
    707120f029f2:	pop    rdx
    707120f029f3:	mov    QWORD PTR [r12+0x108],rbx
    707120f029fb:	add    rsp,0x10
    707120f029ff:	mov    eax,0xc
    707120f02a04:	movabs r11,0x5ab6724ae390
    707120f02a0e:	jmp    r11
    707120f02a11:	mov    eax,0x4103dc
    707120f02a16:	mov    QWORD PTR [r12+0x100],rax
    707120f02a1e:	push   rdx
    707120f02a1f:	push   rsi
    707120f02a20:	push   r10
    707120f02a22:	push   r11
    707120f02a24:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f02a29:	mov    r10d,edx
    707120f02a2c:	and    r10d,0xc0
    707120f02a33:	shl    r10d,0x18
    707120f02a37:	mov    r11d,edx
    707120f02a3a:	and    r11d,0x1
    707120f02a3e:	shl    r11d,0x1d
    707120f02a42:	or     r10d,r11d
    707120f02a45:	mov    r11d,edx
    707120f02a48:	and    r11d,0x800
    707120f02a4f:	shl    r11d,0x11
    707120f02a53:	or     r10d,r11d
    707120f02a56:	btc    r10,0x1d
    707120f02a5b:	mov    r11d,0xf0000000
    707120f02a61:	and    r11,r10
    707120f02a64:	movabs rsi,0xffffffff0fffffff
    707120f02a6e:	and    rbx,rsi
    707120f02a71:	or     rbx,r11
    707120f02a74:	pop    r11
    707120f02a76:	pop    r10
    707120f02a78:	pop    rsi
    707120f02a79:	pop    rdx
    707120f02a7a:	mov    QWORD PTR [r12+0x108],rbx
    707120f02a82:	add    rsp,0x10
    707120f02a86:	mov    eax,0xc
    707120f02a8b:	movabs r11,0x5ab6724ae390
    707120f02a95:	jmp    r11
    707120f02a98:	nop    DWORD PTR [rax+rax*1+0x0]
    707120f02aa0:	sub    rsp,0x10
    707120f02aa4:	mov    r11,QWORD PTR [r12+0x398]
    707120f02aac:	mov    QWORD PTR [rsp],r11
    707120f02ab0:	jmp    0x707120f02406
    707120f02ab5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02ac0:	sub    rsp,0x10
    707120f02ac4:	mov    r11,QWORD PTR [r12+0x398]
    707120f02acc:	mov    QWORD PTR [rsp],r11
    707120f02ad0:	jmp    0x707120f02416
    707120f02ad5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02ae0:	sub    rsp,0x10
    707120f02ae4:	mov    r11,QWORD PTR [r12+0x398]
    707120f02aec:	mov    QWORD PTR [rsp],r11
    707120f02af0:	jmp    0x707120f0244e
    707120f02af5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02b00:	sub    rsp,0x10
    707120f02b04:	mov    r11,QWORD PTR [r12+0x398]
    707120f02b0c:	mov    QWORD PTR [rsp],r11
    707120f02b10:	jmp    0x707120f024e8
    707120f02b15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02b20:	sub    rsp,0x10
    707120f02b24:	mov    r11,QWORD PTR [r12+0x398]
    707120f02b2c:	mov    QWORD PTR [rsp],r11
    707120f02b30:	jmp    0x707120f0255b
    707120f02b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02b40:	sub    rsp,0x10
    707120f02b44:	mov    r11,QWORD PTR [r12+0x398]
    707120f02b4c:	mov    QWORD PTR [rsp],r11
    707120f02b50:	jmp    0x707120f0256f
    707120f02b55:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02b60:	sub    rsp,0x10
    707120f02b64:	mov    r11,QWORD PTR [r12+0x398]
    707120f02b6c:	mov    QWORD PTR [rsp],r11
    707120f02b70:	jmp    0x707120f0257f
    707120f02b75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02b80:	sub    rsp,0x10
    707120f02b84:	mov    r11,QWORD PTR [r12+0x398]
    707120f02b8c:	mov    QWORD PTR [rsp],r11
    707120f02b90:	jmp    0x707120f025db
    707120f02b95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02ba0:	sub    rsp,0x10
    707120f02ba4:	mov    r11,QWORD PTR [r12+0x398]
    707120f02bac:	mov    QWORD PTR [rsp],r11
    707120f02bb0:	jmp    0x707120f02610
    707120f02bb5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02bc0:	sub    rsp,0x10
    707120f02bc4:	mov    r11,QWORD PTR [r12+0x398]
    707120f02bcc:	mov    QWORD PTR [rsp],r11
    707120f02bd0:	jmp    0x707120f026c1
    707120f02bd5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    707120f02be0:	sub    rsp,0x10
    707120f02be4:	mov    r11,QWORD PTR [r12+0x398]
    707120f02bec:	mov    QWORD PTR [rsp],r11
    707120f02bf0:	jmp    0x707120f02775
    707120f02bf5:	nop
    707120f02bf6:	nop
    707120f02bf7:	nop
