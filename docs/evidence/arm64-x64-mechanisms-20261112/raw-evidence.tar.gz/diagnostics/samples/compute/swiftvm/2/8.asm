
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/2/8.bin:     file format binary


Disassembly of section .data:

0000786625d02c00 <.data>:
    786625d02c00:	sub    rsp,0x150
    786625d02c07:	mov    r11,QWORD PTR [r12+0x398]
    786625d02c0f:	mov    QWORD PTR [rsp],r11
    786625d02c13:	cmp    DWORD PTR [r12+0x310],0x0
    786625d02c1c:	je     0x786625d02cac
    786625d02c22:	push   rdx
    786625d02c23:	push   rsi
    786625d02c24:	push   r10
    786625d02c26:	push   r11
    786625d02c28:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d02c2d:	mov    r10d,edx
    786625d02c30:	and    r10d,0xc0
    786625d02c37:	shl    r10d,0x18
    786625d02c3b:	mov    r11d,edx
    786625d02c3e:	and    r11d,0x1
    786625d02c42:	shl    r11d,0x1d
    786625d02c46:	or     r10d,r11d
    786625d02c49:	mov    r11d,edx
    786625d02c4c:	and    r11d,0x800
    786625d02c53:	shl    r11d,0x11
    786625d02c57:	or     r10d,r11d
    786625d02c5a:	btc    r10,0x1d
    786625d02c5f:	mov    r11d,0xf0000000
    786625d02c65:	and    r11,r10
    786625d02c68:	movabs rsi,0xffffffff0fffffff
    786625d02c72:	and    rbx,rsi
    786625d02c75:	or     rbx,r11
    786625d02c78:	pop    r11
    786625d02c7a:	pop    r10
    786625d02c7c:	pop    rsi
    786625d02c7d:	pop    rdx
    786625d02c7e:	mov    QWORD PTR [r12+0x108],rbx
    786625d02c86:	mov    eax,0x4103f8
    786625d02c8b:	mov    QWORD PTR [r12+0x100],rax
    786625d02c93:	add    rsp,0x150
    786625d02c9a:	mov    eax,0x3
    786625d02c9f:	movabs r11,0x5c9c39de2390
    786625d02ca9:	jmp    r11
    786625d02cac:	mov    r13d,DWORD PTR [r12+0x98]
    786625d02cb4:	add    r13d,0x1
    786625d02cb8:	mov    QWORD PTR [r12+0x98],r13
    786625d02cc0:	sub    r13d,0x10000
    786625d02cc7:	mov    rcx,QWORD PTR [r12+0x380]
    786625d02ccf:	jrcxz  0x786625d02cd6
    786625d02cd1:	jmp    0x786625d09bc6
    786625d02cd6:	pushf
    786625d02cd7:	pop    r11
    786625d02cd9:	mov    QWORD PTR [rsp],r11
    786625d02cdd:	jne    0x786625d079cf
    786625d02ce3:	jmp    0x786625d02ce8
    786625d02ce8:	mov    r13d,0x420000
    786625d02cee:	mov    QWORD PTR [r12+0x40],r13
    786625d02cf3:	movabs r13,0x100000001
    786625d02cfd:	mov    r14d,0x0
    786625d02d03:	mov    QWORD PTR [r12+0x110],r13
    786625d02d0b:	mov    QWORD PTR [r12+0x118],r14
    786625d02d13:	movabs r13,0x3fa0000000000000
    786625d02d1d:	mov    QWORD PTR [r12+0x50],r13
    786625d02d22:	mov    r13d,0x420b10
    786625d02d28:	mov    r14,QWORD PTR [r13+0x0]
    786625d02d2c:	mov    r13d,0x0
    786625d02d32:	mov    QWORD PTR [r12+0x120],r14
    786625d02d3a:	mov    QWORD PTR [r12+0x128],r13
    786625d02d42:	movabs r13,0x4100000041
    786625d02d4c:	mov    r14d,0x0
    786625d02d52:	mov    QWORD PTR [r12+0x140],r13
    786625d02d5a:	mov    QWORD PTR [r12+0x148],r14
    786625d02d62:	movabs r13,0x3fc0000000000000
    786625d02d6c:	movabs r14,0x3fc0000000000000
    786625d02d76:	mov    QWORD PTR [r12+0x150],r13
    786625d02d7e:	mov    QWORD PTR [r12+0x158],r14
    786625d02d86:	movabs r13,0x200000002
    786625d02d90:	mov    r14d,0x0
    786625d02d96:	mov    QWORD PTR [r12+0x160],r13
    786625d02d9e:	mov    QWORD PTR [r12+0x168],r14
    786625d02da6:	mov    r13,QWORD PTR [r12+0x50]
    786625d02dab:	and    r13,0xffffffffffffffff
    786625d02daf:	mov    QWORD PTR [r12+0x130],r13
    786625d02db7:	mov    QWORD PTR [r12+0x138],r13
    786625d02dbf:	mov    r13d,0x2
    786625d02dc5:	mov    QWORD PTR [r12+0x170],r13
    786625d02dcd:	mov    QWORD PTR [r12+0x178],r13
    786625d02dd5:	mov    r13d,0x420000
    786625d02ddb:	mov    QWORD PTR [r12+0x40],r13
    786625d02de0:	mov    r13d,0x430000
    786625d02de6:	mov    QWORD PTR [r12+0x50],r13
    786625d02deb:	mov    r13d,0x420a40
    786625d02df1:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d02df7:	movdqa xmm0,xmm2
    786625d02dfb:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d02e05:	mov    r13d,0x0
    786625d02e0b:	mov    QWORD PTR [r12+0x48],r13
    786625d02e10:	mov    r13d,0x431000
    786625d02e16:	add    r13,0xe00
    786625d02e1d:	mov    QWORD PTR [r12+0x40],r13
    786625d02e22:	mov    r13d,0x430cb8
    786625d02e28:	mov    r14d,DWORD PTR [r12]
    786625d02e2c:	mov    DWORD PTR [r13+0x0],r14d
    786625d02e30:	mov    r13d,0x0
    786625d02e36:	mov    DWORD PTR [r12+0x32c],r13d
    786625d02e3e:	mov    r13d,0x432000
    786625d02e44:	add    r13,0x0
    786625d02e48:	mov    QWORD PTR [r12+0x50],r13
    786625d02e4d:	jmp    0x786625d02e52
    786625d02e52:	mov    r13,QWORD PTR [r12+0x180]
    786625d02e5a:	mov    r14,QWORD PTR [r12+0x188]
    786625d02e62:	mov    r15d,0x0
    786625d02e68:	and    r13,0xffffffffffffffff
    786625d02e6c:	mov    ecx,0xffffffff
    786625d02e71:	and    r13,rcx
    786625d02e74:	mov    rcx,r13
    786625d02e77:	mov    rbp,r15
    786625d02e7a:	or     rbp,rcx
    786625d02e7d:	and    r14,0xffffffffffffffff
    786625d02e81:	mov    ecx,0xffffffff
    786625d02e86:	and    r14,rcx
    786625d02e89:	shl    r14,0x20
    786625d02e8d:	mov    rcx,r14
    786625d02e90:	or     rbp,rcx
    786625d02e93:	mov    QWORD PTR [r12+0x210],rbp
    786625d02e9b:	mov    QWORD PTR [r12+0x218],r15
    786625d02ea3:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625d02ead:	movdqa xmm2,xmm0
    786625d02eb1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d02ebb:	movdqa xmm3,xmm0
    786625d02ebf:	movdqa xmm1,xmm3
    786625d02ec3:	psubd  xmm2,xmm1
    786625d02ec7:	movdqa xmm14,xmm2
    786625d02ecc:	movdqa xmm1,xmm14
    786625d02ed1:	movq   rax,xmm1
    786625d02ed6:	mov    r13,rax
    786625d02ed9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d02ee3:	movdqa xmm2,xmm0
    786625d02ee7:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d02ef1:	movdqa xmm4,xmm0
    786625d02ef5:	movdqa xmm1,xmm4
    786625d02ef9:	paddq  xmm2,xmm1
    786625d02efd:	movdqa xmm0,xmm2
    786625d02f01:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d02f0b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d02f15:	movdqa xmm2,xmm0
    786625d02f19:	movdqa xmm1,xmm2
    786625d02f1d:	paddd  xmm3,xmm1
    786625d02f21:	movdqa xmm14,xmm3
    786625d02f26:	movdqa xmm1,xmm14
    786625d02f2b:	movq   rax,xmm1
    786625d02f30:	mov    r14,rax
    786625d02f33:	mov    r15d,0x0
    786625d02f39:	mov    QWORD PTR [r12+0x120],r14
    786625d02f41:	mov    QWORD PTR [r12+0x128],r15
    786625d02f49:	mov    r14d,0x0
    786625d02f4f:	mov    r15,r13
    786625d02f52:	mov    ecx,0xffffffff
    786625d02f57:	and    r15,rcx
    786625d02f5a:	and    r15,0xffffffffffffffff
    786625d02f5e:	mov    rcx,r15
    786625d02f61:	mov    rbp,r14
    786625d02f64:	or     rbp,rcx
    786625d02f67:	shr    r13,0x20
    786625d02f6b:	mov    ecx,0xffffffff
    786625d02f70:	and    r13,rcx
    786625d02f73:	and    r13,0xffffffffffffffff
    786625d02f77:	mov    rcx,r13
    786625d02f7a:	or     r14,rcx
    786625d02f7d:	mov    QWORD PTR [r12+0x220],rbp
    786625d02f85:	mov    QWORD PTR [r12+0x228],r14
    786625d02f8d:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d02f97:	movdqa xmm2,xmm0
    786625d02f9b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d02fa5:	movdqa xmm3,xmm0
    786625d02fa9:	movdqa xmm1,xmm3
    786625d02fad:	paddd  xmm2,xmm1
    786625d02fb1:	movdqa xmm14,xmm2
    786625d02fb6:	movdqa xmm1,xmm14
    786625d02fbb:	movq   rax,xmm1
    786625d02fc0:	mov    r13,rax
    786625d02fc3:	mov    r14d,0x0
    786625d02fc9:	mov    QWORD PTR [r12+0x210],r13
    786625d02fd1:	mov    QWORD PTR [r12+0x218],r14
    786625d02fd9:	lea    r13,[r12]
    786625d02fdd:	movabs r14,0xb6e61da31
    786625d02fe7:	mov    r15d,0x410468
    786625d02fed:	mov    rdx,QWORD PTR [rsp]
    786625d02ff1:	mov    r10d,edx
    786625d02ff4:	and    r10d,0xc0
    786625d02ffb:	shl    r10d,0x18
    786625d02fff:	mov    r11d,edx
    786625d03002:	and    r11d,0x1
    786625d03006:	shl    r11d,0x1d
    786625d0300a:	or     r10d,r11d
    786625d0300d:	mov    r11d,edx
    786625d03010:	and    r11d,0x800
    786625d03017:	shl    r11d,0x11
    786625d0301b:	or     r10d,r11d
    786625d0301e:	btc    r10,0x1d
    786625d03023:	mov    r11d,0xf0000000
    786625d03029:	and    r11,r10
    786625d0302c:	movabs rsi,0xffffffff0fffffff
    786625d03036:	and    rbx,rsi
    786625d03039:	or     rbx,r11
    786625d0303c:	mov    QWORD PTR [r12+0x378],0x3
    786625d03048:	mov    QWORD PTR [r12+0x108],rbx
    786625d03050:	stmxcsr DWORD PTR [r12-0x28]
    786625d03056:	ldmxcsr DWORD PTR [r12-0x38]
    786625d0305c:	movabs r11,0x5c9c39c48dc0
    786625d03066:	mov    rdi,r13
    786625d03069:	mov    rsi,r14
    786625d0306c:	mov    rdx,r15
    786625d0306f:	call   r11
    786625d03072:	ldmxcsr DWORD PTR [r12-0x28]
    786625d03078:	mov    rbx,QWORD PTR [r12+0x108]
    786625d03080:	mov    QWORD PTR [r12+0x378],0x2
    786625d0308c:	mov    rbp,rax
    786625d0308f:	mov    r13,QWORD PTR [r12+0x210]
    786625d03097:	mov    r14d,0x0
    786625d0309d:	mov    r15,r13
    786625d030a0:	mov    ecx,0xffffffff
    786625d030a5:	and    r15,rcx
    786625d030a8:	and    r15,0xffffffffffffffff
    786625d030ac:	mov    rcx,r15
    786625d030af:	mov    rbp,r14
    786625d030b2:	or     rbp,rcx
    786625d030b5:	shr    r13,0x20
    786625d030b9:	mov    ecx,0xffffffff
    786625d030be:	and    r13,rcx
    786625d030c1:	and    r13,0xffffffffffffffff
    786625d030c5:	mov    rcx,r13
    786625d030c8:	or     r14,rcx
    786625d030cb:	mov    QWORD PTR [r12+0x210],rbp
    786625d030d3:	mov    QWORD PTR [r12+0x218],r14
    786625d030db:	lea    r13,[r12]
    786625d030df:	movabs r14,0xb6e61da10
    786625d030e9:	mov    r15d,0x410470
    786625d030ef:	mov    QWORD PTR [r12+0x378],0x3
    786625d030fb:	mov    QWORD PTR [r12+0x108],rbx
    786625d03103:	stmxcsr DWORD PTR [r12-0x28]
    786625d03109:	ldmxcsr DWORD PTR [r12-0x38]
    786625d0310f:	movabs r11,0x5c9c39c48dc0
    786625d03119:	mov    rdi,r13
    786625d0311c:	mov    rsi,r14
    786625d0311f:	mov    rdx,r15
    786625d03122:	call   r11
    786625d03125:	ldmxcsr DWORD PTR [r12-0x28]
    786625d0312b:	mov    rbx,QWORD PTR [r12+0x108]
    786625d03133:	mov    QWORD PTR [r12+0x378],0x2
    786625d0313f:	mov    rbp,rax
    786625d03142:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d0314c:	movdqa xmm2,xmm0
    786625d03150:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625d0315a:	movdqa xmm3,xmm0
    786625d0315e:	stmxcsr DWORD PTR [rsp+0x110]
    786625d03166:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d03171:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d03179:	movdqa xmm0,xmm2
    786625d0317d:	movdqa xmm1,xmm3
    786625d03181:	movq   rax,xmm0
    786625d03186:	add    rax,rax
    786625d03189:	je     0x786625d0319f
    786625d0318b:	shr    rax,0x35
    786625d0318f:	sub    eax,0x201
    786625d03194:	cmp    eax,0x3fc
    786625d03199:	ja     0x786625d07a4d
    786625d0319f:	movdqa xmm14,xmm0
    786625d031a4:	psrldq xmm14,0x8
    786625d031aa:	movq   rax,xmm14
    786625d031af:	add    rax,rax
    786625d031b2:	je     0x786625d031c8
    786625d031b4:	shr    rax,0x35
    786625d031b8:	sub    eax,0x201
    786625d031bd:	cmp    eax,0x3fc
    786625d031c2:	ja     0x786625d07a4d
    786625d031c8:	movq   rax,xmm1
    786625d031cd:	add    rax,rax
    786625d031d0:	je     0x786625d031e6
    786625d031d2:	shr    rax,0x35
    786625d031d6:	sub    eax,0x201
    786625d031db:	cmp    eax,0x3fc
    786625d031e0:	ja     0x786625d07a4d
    786625d031e6:	movdqa xmm14,xmm1
    786625d031eb:	psrldq xmm14,0x8
    786625d031f1:	movq   rax,xmm14
    786625d031f6:	add    rax,rax
    786625d031f9:	je     0x786625d0320f
    786625d031fb:	shr    rax,0x35
    786625d031ff:	sub    eax,0x201
    786625d03204:	cmp    eax,0x3fc
    786625d03209:	ja     0x786625d07a4d
    786625d0320f:	mulpd  xmm0,xmm1
    786625d03213:	movdqa xmm4,xmm0
    786625d03217:	movdqa xmm0,xmm4
    786625d0321b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d03225:	mov    r13,QWORD PTR [r12+0x48]
    786625d0322a:	mov    r14,QWORD PTR [r12+0x50]
    786625d0322f:	mov    rcx,r13
    786625d03232:	add    r14,rcx
    786625d03235:	stmxcsr DWORD PTR [rsp+0x114]
    786625d0323d:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d03245:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d0324d:	shr    r11d,1
    786625d03250:	and    r11d,0x10
    786625d03254:	or     DWORD PTR [r12+0x314],r11d
    786625d0325c:	movdqu XMMWORD PTR [r14],xmm4
    786625d03261:	mov    r14d,0x0
    786625d03267:	mov    DWORD PTR [r12+0x32c],r14d
    786625d0326f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d03279:	movdqa xmm2,xmm0
    786625d0327d:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625d03287:	movdqa xmm3,xmm0
    786625d0328b:	stmxcsr DWORD PTR [rsp+0x110]
    786625d03293:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d0329e:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d032a6:	movdqa xmm0,xmm2
    786625d032aa:	movdqa xmm1,xmm3
    786625d032ae:	movq   rax,xmm0
    786625d032b3:	add    rax,rax
    786625d032b6:	je     0x786625d032cc
    786625d032b8:	shr    rax,0x35
    786625d032bc:	sub    eax,0x201
    786625d032c1:	cmp    eax,0x3fc
    786625d032c6:	ja     0x786625d07a71
    786625d032cc:	movdqa xmm14,xmm0
    786625d032d1:	psrldq xmm14,0x8
    786625d032d7:	movq   rax,xmm14
    786625d032dc:	add    rax,rax
    786625d032df:	je     0x786625d032f5
    786625d032e1:	shr    rax,0x35
    786625d032e5:	sub    eax,0x201
    786625d032ea:	cmp    eax,0x3fc
    786625d032ef:	ja     0x786625d07a71
    786625d032f5:	movq   rax,xmm1
    786625d032fa:	add    rax,rax
    786625d032fd:	je     0x786625d03313
    786625d032ff:	shr    rax,0x35
    786625d03303:	sub    eax,0x201
    786625d03308:	cmp    eax,0x3fc
    786625d0330d:	ja     0x786625d07a71
    786625d03313:	movdqa xmm14,xmm1
    786625d03318:	psrldq xmm14,0x8
    786625d0331e:	movq   rax,xmm14
    786625d03323:	add    rax,rax
    786625d03326:	je     0x786625d0333c
    786625d03328:	shr    rax,0x35
    786625d0332c:	sub    eax,0x201
    786625d03331:	cmp    eax,0x3fc
    786625d03336:	ja     0x786625d07a71
    786625d0333c:	mulpd  xmm0,xmm1
    786625d03340:	movdqa xmm4,xmm0
    786625d03344:	movdqa xmm0,xmm4
    786625d03348:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d03352:	mov    r14,QWORD PTR [r12+0x40]
    786625d03357:	mov    rcx,r13
    786625d0335a:	add    r14,rcx
    786625d0335d:	stmxcsr DWORD PTR [rsp+0x114]
    786625d03365:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d0336d:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d03375:	shr    r11d,1
    786625d03378:	and    r11d,0x10
    786625d0337c:	or     DWORD PTR [r12+0x314],r11d
    786625d03384:	movdqu XMMWORD PTR [r14],xmm4
    786625d03389:	mov    r14d,0x0
    786625d0338f:	mov    DWORD PTR [r12+0x32c],r14d
    786625d03397:	add    r13,0x10
    786625d0339b:	mov    QWORD PTR [r12+0x48],r13
    786625d033a0:	sub    r13,0x200
    786625d033a7:	mov    rcx,QWORD PTR [r12+0x380]
    786625d033af:	jrcxz  0x786625d033b6
    786625d033b1:	jmp    0x786625d09c58
    786625d033b6:	pushf
    786625d033b7:	pop    r11
    786625d033b9:	mov    QWORD PTR [rsp],r11
    786625d033bd:	jne    0x786625d02e52
    786625d033c3:	jmp    0x786625d033c8
    786625d033c8:	mov    r13,QWORD PTR [r12+0x50]
    786625d033cd:	mov    r14,r13
    786625d033d0:	add    r14,0x80
    786625d033d7:	mov    r15,r14
    786625d033da:	add    r15,0x10
    786625d033de:	movdqu xmm2,XMMWORD PTR [r14]
    786625d033e3:	movdqu xmm3,XMMWORD PTR [r15]
    786625d033e8:	movdqa xmm0,xmm2
    786625d033ec:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625d033f6:	movdqa xmm0,xmm3
    786625d033fa:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d03404:	mov    r14d,0x0
    786625d0340a:	mov    r15d,0x0
    786625d03410:	mov    QWORD PTR [r12+0x1b0],r14
    786625d03418:	mov    QWORD PTR [r12+0x1b8],r15
    786625d03420:	mov    r14,r13
    786625d03423:	add    r14,0x40
    786625d03427:	mov    r15,r14
    786625d0342a:	add    r15,0x10
    786625d0342e:	movdqu xmm2,XMMWORD PTR [r14]
    786625d03433:	movdqu xmm3,XMMWORD PTR [r15]
    786625d03438:	movdqa xmm0,xmm2
    786625d0343c:	movdqu XMMWORD PTR [r12+0x250],xmm0
    786625d03446:	movdqa xmm0,xmm3
    786625d0344a:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d03454:	mov    r14d,0x0
    786625d0345a:	mov    QWORD PTR [r12+0x48],r14
    786625d0345f:	mov    r14,r13
    786625d03462:	add    r14,0x10
    786625d03466:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d0346c:	movdqu xmm3,XMMWORD PTR [r14]
    786625d03471:	movdqa xmm0,xmm2
    786625d03475:	movdqu XMMWORD PTR [r12+0x170],xmm0
    786625d0347f:	movdqa xmm0,xmm3
    786625d03483:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d0348d:	mov    r13,QWORD PTR [r12+0xf8]
    786625d03495:	add    r13,0xe0
    786625d0349c:	mov    r14,r13
    786625d0349f:	add    r14,0x10
    786625d034a3:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d034ad:	movdqa xmm2,xmm0
    786625d034b1:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625d034bb:	movdqa xmm3,xmm0
    786625d034bf:	movdqu XMMWORD PTR [r13+0x0],xmm2
    786625d034c5:	mov    r13d,0x0
    786625d034cb:	mov    DWORD PTR [r12+0x32c],r13d
    786625d034d3:	movdqu XMMWORD PTR [r14],xmm3
    786625d034d8:	mov    r13d,0x0
    786625d034de:	mov    DWORD PTR [r12+0x32c],r13d
    786625d034e6:	mov    r13,QWORD PTR [r12+0x50]
    786625d034eb:	mov    r14,r13
    786625d034ee:	add    r14,0xc0
    786625d034f5:	mov    r15,r14
    786625d034f8:	add    r15,0x10
    786625d034fc:	movdqu xmm2,XMMWORD PTR [r14]
    786625d03501:	movdqu xmm3,XMMWORD PTR [r15]
    786625d03506:	movdqa xmm0,xmm2
    786625d0350a:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625d03514:	movdqa xmm0,xmm3
    786625d03518:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d03522:	mov    r14,r13
    786625d03525:	add    r14,0x140
    786625d0352c:	mov    r15,r14
    786625d0352f:	add    r15,0x10
    786625d03533:	movdqu xmm2,XMMWORD PTR [r14]
    786625d03538:	movdqu xmm3,XMMWORD PTR [r15]
    786625d0353d:	movdqa xmm0,xmm2
    786625d03541:	movdqu XMMWORD PTR [r12+0x270],xmm0
    786625d0354b:	movdqa xmm0,xmm3
    786625d0354f:	movdqu XMMWORD PTR [r12+0x190],xmm0
    786625d03559:	add    r13,0x180
    786625d03560:	mov    r14,r13
    786625d03563:	add    r14,0x10
    786625d03567:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d0356d:	movdqu xmm3,XMMWORD PTR [r14]
    786625d03572:	movdqa xmm0,xmm2
    786625d03576:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    786625d03580:	movdqa xmm0,xmm3
    786625d03584:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    786625d0358e:	mov    r13,QWORD PTR [r12+0xf8]
    786625d03596:	add    r13,0xc0
    786625d0359d:	mov    r14,r13
    786625d035a0:	add    r14,0x10
    786625d035a4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d035ae:	movdqa xmm2,xmm0
    786625d035b2:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625d035bc:	movdqa xmm3,xmm0
    786625d035c0:	movdqu XMMWORD PTR [r13+0x0],xmm2
    786625d035c6:	mov    r13d,0x0
    786625d035cc:	mov    DWORD PTR [r12+0x32c],r13d
    786625d035d4:	movdqu XMMWORD PTR [r14],xmm3
    786625d035d9:	mov    r13d,0x0
    786625d035df:	mov    DWORD PTR [r12+0x32c],r13d
    786625d035e7:	mov    r13,QWORD PTR [r12+0x50]
    786625d035ec:	mov    r14,r13
    786625d035ef:	add    r14,0x100
    786625d035f6:	mov    r15,r14
    786625d035f9:	add    r15,0x10
    786625d035fd:	movdqu xmm2,XMMWORD PTR [r14]
    786625d03602:	movdqu xmm3,XMMWORD PTR [r15]
    786625d03607:	movdqa xmm0,xmm2
    786625d0360b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d03615:	movdqa xmm0,xmm3
    786625d03619:	movdqu XMMWORD PTR [r12+0x300],xmm0
    786625d03623:	mov    r14,r13
    786625d03626:	add    r14,0x1c0
    786625d0362d:	mov    r15,r14
    786625d03630:	add    r15,0x10
    786625d03634:	movdqu xmm2,XMMWORD PTR [r14]
    786625d03639:	movdqu xmm3,XMMWORD PTR [r15]
    786625d0363e:	movdqa xmm0,xmm2
    786625d03642:	movdqu XMMWORD PTR [r12+0x240],xmm0
    786625d0364c:	movdqa xmm0,xmm3
    786625d03650:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    786625d0365a:	add    r13,0x20
    786625d0365e:	mov    r14,r13
    786625d03661:	add    r14,0x10
    786625d03665:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d0366b:	movdqu xmm3,XMMWORD PTR [r14]
    786625d03670:	movdqa xmm0,xmm2
    786625d03674:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    786625d0367e:	movdqa xmm0,xmm3
    786625d03682:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
    786625d0368c:	mov    r13,QWORD PTR [r12+0xf8]
    786625d03694:	mov    r14,r13
    786625d03697:	add    r14,0x20
    786625d0369b:	mov    r15,r14
    786625d0369e:	add    r15,0x10
    786625d036a2:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d036ac:	movdqa xmm2,xmm0
    786625d036b0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d036ba:	movdqa xmm3,xmm0
    786625d036be:	movdqu XMMWORD PTR [r14],xmm2
    786625d036c3:	mov    r14d,0x0
    786625d036c9:	mov    DWORD PTR [r12+0x32c],r14d
    786625d036d1:	movdqu XMMWORD PTR [r15],xmm3
    786625d036d6:	mov    r14d,0x0
    786625d036dc:	mov    DWORD PTR [r12+0x32c],r14d
    786625d036e4:	mov    r14,QWORD PTR [r12+0x50]
    786625d036e9:	mov    r15,r14
    786625d036ec:	add    r15,0x60
    786625d036f0:	mov    rbp,r15
    786625d036f3:	add    rbp,0x10
    786625d036f7:	movdqu xmm2,XMMWORD PTR [r15]
    786625d036fc:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    786625d03701:	movdqa xmm0,xmm2
    786625d03705:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d0370f:	movdqa xmm0,xmm3
    786625d03713:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d0371d:	add    r13,0x60
    786625d03721:	mov    r15,r13
    786625d03724:	add    r15,0x10
    786625d03728:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d03732:	movdqa xmm2,xmm0
    786625d03736:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    786625d03740:	movdqa xmm3,xmm0
    786625d03744:	movdqu XMMWORD PTR [r13+0x0],xmm2
    786625d0374a:	mov    r13d,0x0
    786625d03750:	mov    DWORD PTR [r12+0x32c],r13d
    786625d03758:	movdqu XMMWORD PTR [r15],xmm3
    786625d0375d:	mov    r13d,0x0
    786625d03763:	mov    DWORD PTR [r12+0x32c],r13d
    786625d0376b:	mov    r13,r14
    786625d0376e:	add    r13,0xe0
    786625d03775:	mov    r15,r13
    786625d03778:	add    r15,0x10
    786625d0377c:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d03782:	movdqu xmm3,XMMWORD PTR [r15]
    786625d03787:	movdqa xmm0,xmm2
    786625d0378b:	movdqu XMMWORD PTR [r12+0x200],xmm0
    786625d03795:	movdqa xmm0,xmm3
    786625d03799:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    786625d037a3:	add    r14,0x120
    786625d037aa:	mov    r13,r14
    786625d037ad:	add    r13,0x10
    786625d037b1:	movdqu xmm2,XMMWORD PTR [r14]
    786625d037b6:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    786625d037bc:	movdqa xmm0,xmm2
    786625d037c0:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    786625d037ca:	movdqa xmm0,xmm3
    786625d037ce:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    786625d037d8:	mov    r13,QWORD PTR [r12+0xf8]
    786625d037e0:	add    r13,0xa0
    786625d037e7:	mov    r14,r13
    786625d037ea:	add    r14,0x10
    786625d037ee:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d037f8:	movdqa xmm2,xmm0
    786625d037fc:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d03806:	movdqa xmm3,xmm0
    786625d0380a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    786625d03810:	mov    r13d,0x0
    786625d03816:	mov    DWORD PTR [r12+0x32c],r13d
    786625d0381e:	movdqu XMMWORD PTR [r14],xmm3
    786625d03823:	mov    r13d,0x0
    786625d03829:	mov    DWORD PTR [r12+0x32c],r13d
    786625d03831:	mov    r13,QWORD PTR [r12+0x50]
    786625d03836:	mov    r14,r13
    786625d03839:	add    r14,0xa0
    786625d03840:	mov    r15,r14
    786625d03843:	add    r15,0x10
    786625d03847:	movdqu xmm2,XMMWORD PTR [r14]
    786625d0384c:	movdqu xmm3,XMMWORD PTR [r15]
    786625d03851:	movdqa xmm0,xmm2
    786625d03855:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d0385f:	movdqa xmm0,xmm3
    786625d03863:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d0386d:	mov    r14,r13
    786625d03870:	add    r14,0x160
    786625d03877:	mov    r15,r14
    786625d0387a:	add    r15,0x10
    786625d0387e:	movdqu xmm2,XMMWORD PTR [r14]
    786625d03883:	movdqu xmm3,XMMWORD PTR [r15]
    786625d03888:	movdqa xmm0,xmm2
    786625d0388c:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    786625d03896:	movdqa xmm0,xmm3
    786625d0389a:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
    786625d038a4:	add    r13,0x1a0
    786625d038ab:	mov    r14,r13
    786625d038ae:	add    r14,0x10
    786625d038b2:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d038b8:	movdqu xmm3,XMMWORD PTR [r14]
    786625d038bd:	movdqa xmm0,xmm2
    786625d038c1:	movdqu XMMWORD PTR [r12+0x290],xmm0
    786625d038cb:	movdqa xmm0,xmm3
    786625d038cf:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
    786625d038d9:	mov    r13,QWORD PTR [r12+0xf8]
    786625d038e1:	mov    r14,r13
    786625d038e4:	add    r14,0x80
    786625d038eb:	mov    r15,r14
    786625d038ee:	add    r15,0x10
    786625d038f2:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d038fc:	movdqa xmm2,xmm0
    786625d03900:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d0390a:	movdqa xmm3,xmm0
    786625d0390e:	movdqu XMMWORD PTR [r14],xmm2
    786625d03913:	mov    r14d,0x0
    786625d03919:	mov    DWORD PTR [r12+0x32c],r14d
    786625d03921:	movdqu XMMWORD PTR [r15],xmm3
    786625d03926:	mov    r14d,0x0
    786625d0392c:	mov    DWORD PTR [r12+0x32c],r14d
    786625d03934:	mov    r14,QWORD PTR [r12+0x50]
    786625d03939:	add    r14,0x1e0
    786625d03940:	mov    r15,r14
    786625d03943:	add    r15,0x10
    786625d03947:	movdqu xmm2,XMMWORD PTR [r14]
    786625d0394c:	movdqu xmm3,XMMWORD PTR [r15]
    786625d03951:	movdqa xmm0,xmm2
    786625d03955:	movdqu XMMWORD PTR [r12+0x230],xmm0
    786625d0395f:	movdqa xmm0,xmm3
    786625d03963:	movdqu XMMWORD PTR [r12+0x280],xmm0
    786625d0396d:	mov    r14d,0x432000
    786625d03973:	add    r14,0x200
    786625d0397a:	mov    QWORD PTR [r12+0x50],r14
    786625d0397f:	add    r13,0x40
    786625d03983:	mov    r14,r13
    786625d03986:	add    r14,0x10
    786625d0398a:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    786625d03994:	movdqa xmm4,xmm0
    786625d03998:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d039a2:	movdqa xmm5,xmm0
    786625d039a6:	movdqu XMMWORD PTR [r13+0x0],xmm4
    786625d039ac:	mov    r13d,0x0
    786625d039b2:	mov    DWORD PTR [r12+0x32c],r13d
    786625d039ba:	movdqu XMMWORD PTR [r14],xmm5
    786625d039bf:	mov    r13d,0x0
    786625d039c5:	mov    DWORD PTR [r12+0x32c],r13d
    786625d039cd:	mov    r13,QWORD PTR [r12+0xf8]
    786625d039d5:	mov    r14,r13
    786625d039d8:	add    r14,0x10
    786625d039dc:	movdqu XMMWORD PTR [r13+0x0],xmm3
    786625d039e2:	mov    r13d,0x0
    786625d039e8:	mov    DWORD PTR [r12+0x32c],r13d
    786625d039f0:	movdqu XMMWORD PTR [r14],xmm2
    786625d039f5:	mov    r13d,0x0
    786625d039fb:	mov    DWORD PTR [r12+0x32c],r13d
    786625d03a03:	jmp    0x786625d03a08
    786625d03a08:	mov    r13d,0x0
    786625d03a0e:	mov    QWORD PTR [r12+0x58],r13
    786625d03a13:	jmp    0x786625d03a18
    786625d03a18:	mov    r13,QWORD PTR [r12+0x58]
    786625d03a1d:	mov    r14,QWORD PTR [r12+0x40]
    786625d03a22:	mov    rcx,r13
    786625d03a25:	add    r14,rcx
    786625d03a28:	mov    QWORD PTR [r12+0x60],r14
    786625d03a2d:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    786625d03a37:	movdqa xmm2,xmm0
    786625d03a3b:	movdqa xmm1,xmm2
    786625d03a3f:	por    xmm2,xmm1
    786625d03a43:	movdqa xmm0,xmm2
    786625d03a47:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    786625d03a51:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    786625d03a5b:	movdqa xmm2,xmm0
    786625d03a5f:	movdqa xmm1,xmm2
    786625d03a63:	por    xmm2,xmm1
    786625d03a67:	movdqa xmm0,xmm2
    786625d03a6b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d03a75:	add    r14,0x30
    786625d03a79:	mov    r13,r14
    786625d03a7c:	add    r13,0x8
    786625d03a80:	mov    r15,QWORD PTR [r14]
    786625d03a83:	mov    r14,QWORD PTR [r13+0x0]
    786625d03a87:	mov    r13d,0x0
    786625d03a8d:	mov    QWORD PTR [r12+0x130],r15
    786625d03a95:	mov    QWORD PTR [r12+0x138],r13
    786625d03a9d:	mov    r13d,0x0
    786625d03aa3:	mov    QWORD PTR [r12+0x280],r14
    786625d03aab:	mov    QWORD PTR [r12+0x288],r13
    786625d03ab3:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    786625d03abd:	movdqa xmm2,xmm0
    786625d03ac1:	movdqa xmm1,xmm2
    786625d03ac5:	por    xmm2,xmm1
    786625d03ac9:	movdqa xmm0,xmm2
    786625d03acd:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    786625d03ad7:	mov    r13,QWORD PTR [r12+0x60]
    786625d03adc:	mov    r14,r13
    786625d03adf:	add    r14,0x20
    786625d03ae3:	mov    r15,r14
    786625d03ae6:	add    r15,0x8
    786625d03aea:	mov    rbp,QWORD PTR [r14]
    786625d03aed:	mov    r14,QWORD PTR [r15]
    786625d03af0:	mov    r15d,0x0
    786625d03af6:	mov    QWORD PTR [r12+0x150],rbp
    786625d03afe:	mov    QWORD PTR [r12+0x158],r15
    786625d03b06:	mov    r15d,0x0
    786625d03b0c:	mov    QWORD PTR [r12+0x140],r14
    786625d03b14:	mov    QWORD PTR [r12+0x148],r15
    786625d03b1c:	add    r13,0x10
    786625d03b20:	mov    r14,r13
    786625d03b23:	add    r14,0x8
    786625d03b27:	mov    r15,QWORD PTR [r13+0x0]
    786625d03b2b:	mov    r13,QWORD PTR [r14]
    786625d03b2e:	mov    r14d,0x0
    786625d03b34:	mov    QWORD PTR [r12+0x170],r15
    786625d03b3c:	mov    QWORD PTR [r12+0x178],r14
    786625d03b44:	mov    r14d,0x0
    786625d03b4a:	mov    QWORD PTR [r12+0x160],r13
    786625d03b52:	mov    QWORD PTR [r12+0x168],r14
    786625d03b5a:	mov    r13,QWORD PTR [r12+0x60]
    786625d03b5f:	mov    r14d,0x8
    786625d03b65:	mov    r15,QWORD PTR [r13+0x0]
    786625d03b69:	mov    QWORD PTR [r12+0x180],r15
    786625d03b71:	mov    QWORD PTR [r12+0x188],r15
    786625d03b79:	mov    rcx,r14
    786625d03b7c:	add    r13,rcx
    786625d03b7f:	mov    QWORD PTR [r12+0x60],r13
    786625d03b84:	mov    r14,QWORD PTR [r13+0x0]
    786625d03b88:	mov    r13d,0x0
    786625d03b8e:	mov    QWORD PTR [r12+0x230],r14
    786625d03b96:	mov    QWORD PTR [r12+0x238],r13
    786625d03b9e:	mov    r13,QWORD PTR [r12+0xf8]
    786625d03ba6:	mov    r14,r13
    786625d03ba9:	add    r14,0x50
    786625d03bad:	mov    r15,r14
    786625d03bb0:	add    r15,0x10
    786625d03bb4:	movdqu xmm2,XMMWORD PTR [r14]
    786625d03bb9:	movdqu xmm3,XMMWORD PTR [r15]
    786625d03bbe:	movdqa xmm0,xmm2
    786625d03bc2:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d03bcc:	movdqa xmm0,xmm3
    786625d03bd0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d03bda:	add    r13,0x30
    786625d03bde:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d03be4:	movdqa xmm0,xmm2
    786625d03be8:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d03bf2:	mov    r13,QWORD PTR [r12+0x58]
    786625d03bf7:	mov    r14,QWORD PTR [r12+0x50]
    786625d03bfc:	mov    rcx,r13
    786625d03bff:	add    r14,rcx
    786625d03c02:	mov    QWORD PTR [r12+0x60],r14
    786625d03c07:	add    r13,0x40
    786625d03c0b:	mov    QWORD PTR [r12+0x58],r13
    786625d03c10:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d03c1a:	movdqa xmm3,xmm0
    786625d03c1e:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    786625d03c28:	movdqa xmm4,xmm0
    786625d03c2c:	stmxcsr DWORD PTR [rsp+0x110]
    786625d03c34:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d03c3f:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d03c47:	movdqa xmm0,xmm3
    786625d03c4b:	movdqa xmm1,xmm4
    786625d03c4f:	movq   rax,xmm0
    786625d03c54:	add    rax,rax
    786625d03c57:	je     0x786625d03c6d
    786625d03c59:	shr    rax,0x35
    786625d03c5d:	sub    eax,0x201
    786625d03c62:	cmp    eax,0x3fc
    786625d03c67:	ja     0x786625d07a95
    786625d03c6d:	movdqa xmm14,xmm0
    786625d03c72:	psrldq xmm14,0x8
    786625d03c78:	movq   rax,xmm14
    786625d03c7d:	add    rax,rax
    786625d03c80:	je     0x786625d03c96
    786625d03c82:	shr    rax,0x35
    786625d03c86:	sub    eax,0x201
    786625d03c8b:	cmp    eax,0x3fc
    786625d03c90:	ja     0x786625d07a95
    786625d03c96:	movq   rax,xmm1
    786625d03c9b:	add    rax,rax
    786625d03c9e:	je     0x786625d03cb4
    786625d03ca0:	shr    rax,0x35
    786625d03ca4:	sub    eax,0x201
    786625d03ca9:	cmp    eax,0x3fc
    786625d03cae:	ja     0x786625d07a95
    786625d03cb4:	movdqa xmm14,xmm1
    786625d03cb9:	psrldq xmm14,0x8
    786625d03cbf:	movq   rax,xmm14
    786625d03cc4:	add    rax,rax
    786625d03cc7:	je     0x786625d03cdd
    786625d03cc9:	shr    rax,0x35
    786625d03ccd:	sub    eax,0x201
    786625d03cd2:	cmp    eax,0x3fc
    786625d03cd7:	ja     0x786625d07a95
    786625d03cdd:	mulpd  xmm0,xmm1
    786625d03ce1:	movdqa xmm5,xmm0
    786625d03ce5:	movdqa xmm0,xmm5
    786625d03ce9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    786625d03cf3:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625d03cfd:	movdqa xmm4,xmm0
    786625d03d01:	movdqa xmm0,xmm2
    786625d03d05:	movdqa xmm1,xmm4
    786625d03d09:	pshufd xmm1,xmm1,0x44
    786625d03d0e:	movq   rax,xmm0
    786625d03d13:	add    rax,rax
    786625d03d16:	je     0x786625d03d2c
    786625d03d18:	shr    rax,0x35
    786625d03d1c:	sub    eax,0x201
    786625d03d21:	cmp    eax,0x3fc
    786625d03d26:	ja     0x786625d07ab9
    786625d03d2c:	movdqa xmm14,xmm0
    786625d03d31:	psrldq xmm14,0x8
    786625d03d37:	movq   rax,xmm14
    786625d03d3c:	add    rax,rax
    786625d03d3f:	je     0x786625d03d55
    786625d03d41:	shr    rax,0x35
    786625d03d45:	sub    eax,0x201
    786625d03d4a:	cmp    eax,0x3fc
    786625d03d4f:	ja     0x786625d07ab9
    786625d03d55:	movq   rax,xmm1
    786625d03d5a:	add    rax,rax
    786625d03d5d:	je     0x786625d03d73
    786625d03d5f:	shr    rax,0x35
    786625d03d63:	sub    eax,0x201
    786625d03d68:	cmp    eax,0x3fc
    786625d03d6d:	ja     0x786625d07ab9
    786625d03d73:	movdqa xmm14,xmm1
    786625d03d78:	psrldq xmm14,0x8
    786625d03d7e:	movq   rax,xmm14
    786625d03d83:	add    rax,rax
    786625d03d86:	je     0x786625d03d9c
    786625d03d88:	shr    rax,0x35
    786625d03d8c:	sub    eax,0x201
    786625d03d91:	cmp    eax,0x3fc
    786625d03d96:	ja     0x786625d07ab9
    786625d03d9c:	mulpd  xmm0,xmm1
    786625d03da0:	movdqa xmm5,xmm0
    786625d03da4:	movdqa xmm0,xmm5
    786625d03da8:	movdqu XMMWORD PTR [r12+0x260],xmm0
    786625d03db2:	mov    r13d,0x0
    786625d03db8:	mov    r14d,0x0
    786625d03dbe:	mov    QWORD PTR [r12+0x110],r13
    786625d03dc6:	mov    QWORD PTR [r12+0x118],r14
    786625d03dce:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d03dd8:	movdqa xmm2,xmm0
    786625d03ddc:	movdqa xmm0,xmm3
    786625d03de0:	movdqa xmm1,xmm2
    786625d03de4:	movq   rax,xmm0
    786625d03de9:	add    rax,rax
    786625d03dec:	je     0x786625d03e02
    786625d03dee:	shr    rax,0x35
    786625d03df2:	sub    eax,0x201
    786625d03df7:	cmp    eax,0x3fc
    786625d03dfc:	ja     0x786625d07add
    786625d03e02:	movdqa xmm14,xmm0
    786625d03e07:	psrldq xmm14,0x8
    786625d03e0d:	movq   rax,xmm14
    786625d03e12:	add    rax,rax
    786625d03e15:	je     0x786625d03e2b
    786625d03e17:	shr    rax,0x35
    786625d03e1b:	sub    eax,0x201
    786625d03e20:	cmp    eax,0x3fc
    786625d03e25:	ja     0x786625d07add
    786625d03e2b:	movq   rax,xmm1
    786625d03e30:	add    rax,rax
    786625d03e33:	je     0x786625d03e49
    786625d03e35:	shr    rax,0x35
    786625d03e39:	sub    eax,0x201
    786625d03e3e:	cmp    eax,0x3fc
    786625d03e43:	ja     0x786625d07add
    786625d03e49:	movdqa xmm14,xmm1
    786625d03e4e:	psrldq xmm14,0x8
    786625d03e54:	movq   rax,xmm14
    786625d03e59:	add    rax,rax
    786625d03e5c:	je     0x786625d03e72
    786625d03e5e:	shr    rax,0x35
    786625d03e62:	sub    eax,0x201
    786625d03e67:	cmp    eax,0x3fc
    786625d03e6c:	ja     0x786625d07add
    786625d03e72:	mulpd  xmm0,xmm1
    786625d03e76:	movdqa xmm4,xmm0
    786625d03e7a:	movdqa xmm0,xmm4
    786625d03e7e:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d03e88:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d03e92:	movdqa xmm2,xmm0
    786625d03e96:	movdqa xmm0,xmm3
    786625d03e9a:	movdqa xmm1,xmm2
    786625d03e9e:	movq   rax,xmm0
    786625d03ea3:	add    rax,rax
    786625d03ea6:	je     0x786625d03ebc
    786625d03ea8:	shr    rax,0x35
    786625d03eac:	sub    eax,0x201
    786625d03eb1:	cmp    eax,0x3fc
    786625d03eb6:	ja     0x786625d07b01
    786625d03ebc:	movdqa xmm14,xmm0
    786625d03ec1:	psrldq xmm14,0x8
    786625d03ec7:	movq   rax,xmm14
    786625d03ecc:	add    rax,rax
    786625d03ecf:	je     0x786625d03ee5
    786625d03ed1:	shr    rax,0x35
    786625d03ed5:	sub    eax,0x201
    786625d03eda:	cmp    eax,0x3fc
    786625d03edf:	ja     0x786625d07b01
    786625d03ee5:	movq   rax,xmm1
    786625d03eea:	add    rax,rax
    786625d03eed:	je     0x786625d03f03
    786625d03eef:	shr    rax,0x35
    786625d03ef3:	sub    eax,0x201
    786625d03ef8:	cmp    eax,0x3fc
    786625d03efd:	ja     0x786625d07b01
    786625d03f03:	movdqa xmm14,xmm1
    786625d03f08:	psrldq xmm14,0x8
    786625d03f0e:	movq   rax,xmm14
    786625d03f13:	add    rax,rax
    786625d03f16:	je     0x786625d03f2c
    786625d03f18:	shr    rax,0x35
    786625d03f1c:	sub    eax,0x201
    786625d03f21:	cmp    eax,0x3fc
    786625d03f26:	ja     0x786625d07b01
    786625d03f2c:	mulpd  xmm0,xmm1
    786625d03f30:	movdqa xmm4,xmm0
    786625d03f34:	movdqa xmm0,xmm4
    786625d03f38:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d03f42:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d03f4c:	movdqa xmm2,xmm0
    786625d03f50:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    786625d03f5a:	movdqa xmm3,xmm0
    786625d03f5e:	movdqa xmm0,xmm2
    786625d03f62:	movdqa xmm1,xmm3
    786625d03f66:	movq   rax,xmm0
    786625d03f6b:	add    rax,rax
    786625d03f6e:	je     0x786625d03f84
    786625d03f70:	shr    rax,0x35
    786625d03f74:	sub    eax,0x201
    786625d03f79:	cmp    eax,0x3fc
    786625d03f7e:	ja     0x786625d07b25
    786625d03f84:	movdqa xmm14,xmm0
    786625d03f89:	psrldq xmm14,0x8
    786625d03f8f:	movq   rax,xmm14
    786625d03f94:	add    rax,rax
    786625d03f97:	je     0x786625d03fad
    786625d03f99:	shr    rax,0x35
    786625d03f9d:	sub    eax,0x201
    786625d03fa2:	cmp    eax,0x3fc
    786625d03fa7:	ja     0x786625d07b25
    786625d03fad:	movq   rax,xmm1
    786625d03fb2:	add    rax,rax
    786625d03fb5:	je     0x786625d03fcb
    786625d03fb7:	shr    rax,0x35
    786625d03fbb:	sub    eax,0x201
    786625d03fc0:	cmp    eax,0x3fc
    786625d03fc5:	ja     0x786625d07b25
    786625d03fcb:	movdqa xmm14,xmm1
    786625d03fd0:	psrldq xmm14,0x8
    786625d03fd6:	movq   rax,xmm14
    786625d03fdb:	add    rax,rax
    786625d03fde:	je     0x786625d03ff4
    786625d03fe0:	shr    rax,0x35
    786625d03fe4:	sub    eax,0x201
    786625d03fe9:	cmp    eax,0x3fc
    786625d03fee:	ja     0x786625d07b25
    786625d03ff4:	mulpd  xmm0,xmm1
    786625d03ff8:	movdqa xmm4,xmm0
    786625d03ffc:	movdqa xmm0,xmm4
    786625d04000:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d0400a:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    786625d04014:	movdqa xmm2,xmm0
    786625d04018:	movdqa xmm1,xmm2
    786625d0401c:	por    xmm2,xmm1
    786625d04020:	movdqa xmm0,xmm2
    786625d04024:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    786625d0402e:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    786625d04038:	movdqa xmm2,xmm0
    786625d0403c:	movdqa xmm3,xmm2
    786625d04040:	movdqa xmm1,xmm2
    786625d04044:	por    xmm3,xmm1
    786625d04048:	movdqa xmm0,xmm3
    786625d0404c:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    786625d04056:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625d04060:	movdqa xmm3,xmm0
    786625d04064:	movdqa xmm0,xmm2
    786625d04068:	movdqa xmm1,xmm3
    786625d0406c:	pshufd xmm1,xmm1,0x44
    786625d04071:	movq   rax,xmm0
    786625d04076:	add    rax,rax
    786625d04079:	je     0x786625d0408f
    786625d0407b:	shr    rax,0x35
    786625d0407f:	sub    eax,0x201
    786625d04084:	cmp    eax,0x3fc
    786625d04089:	ja     0x786625d07b49
    786625d0408f:	movdqa xmm14,xmm0
    786625d04094:	psrldq xmm14,0x8
    786625d0409a:	movq   rax,xmm14
    786625d0409f:	add    rax,rax
    786625d040a2:	je     0x786625d040b8
    786625d040a4:	shr    rax,0x35
    786625d040a8:	sub    eax,0x201
    786625d040ad:	cmp    eax,0x3fc
    786625d040b2:	ja     0x786625d07b49
    786625d040b8:	movq   rax,xmm1
    786625d040bd:	add    rax,rax
    786625d040c0:	je     0x786625d040d6
    786625d040c2:	shr    rax,0x35
    786625d040c6:	sub    eax,0x201
    786625d040cb:	cmp    eax,0x3fc
    786625d040d0:	ja     0x786625d07b49
    786625d040d6:	movdqa xmm14,xmm1
    786625d040db:	psrldq xmm14,0x8
    786625d040e1:	movq   rax,xmm14
    786625d040e6:	add    rax,rax
    786625d040e9:	je     0x786625d040ff
    786625d040eb:	shr    rax,0x35
    786625d040ef:	sub    eax,0x201
    786625d040f4:	cmp    eax,0x3fc
    786625d040f9:	ja     0x786625d07b49
    786625d040ff:	mulpd  xmm0,xmm1
    786625d04103:	movdqa xmm4,xmm0
    786625d04107:	movdqa xmm0,xmm4
    786625d0410b:	movdqu XMMWORD PTR [r12+0x250],xmm0
    786625d04115:	mov    r13,QWORD PTR [r12+0x58]
    786625d0411a:	stmxcsr DWORD PTR [rsp+0x114]
    786625d04122:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d0412a:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d04132:	shr    r11d,1
    786625d04135:	and    r11d,0x10
    786625d04139:	or     DWORD PTR [r12+0x314],r11d
    786625d04141:	sub    r13,0x200
    786625d04148:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    786625d04152:	movdqa xmm2,xmm0
    786625d04156:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d04160:	movdqa xmm3,xmm0
    786625d04164:	pushf
    786625d04165:	pop    r11
    786625d04167:	mov    QWORD PTR [rsp],r11
    786625d0416b:	stmxcsr DWORD PTR [rsp+0x110]
    786625d04173:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d0417e:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d04186:	movdqa xmm0,xmm2
    786625d0418a:	movdqa xmm1,xmm3
    786625d0418e:	movq   rax,xmm0
    786625d04193:	add    rax,rax
    786625d04196:	je     0x786625d041ac
    786625d04198:	shr    rax,0x35
    786625d0419c:	sub    eax,0x201
    786625d041a1:	cmp    eax,0x3fc
    786625d041a6:	ja     0x786625d07b6d
    786625d041ac:	movdqa xmm14,xmm0
    786625d041b1:	psrldq xmm14,0x8
    786625d041b7:	movq   rax,xmm14
    786625d041bc:	add    rax,rax
    786625d041bf:	je     0x786625d041d5
    786625d041c1:	shr    rax,0x35
    786625d041c5:	sub    eax,0x201
    786625d041ca:	cmp    eax,0x3fc
    786625d041cf:	ja     0x786625d07b6d
    786625d041d5:	movq   rax,xmm1
    786625d041da:	add    rax,rax
    786625d041dd:	je     0x786625d041f3
    786625d041df:	shr    rax,0x35
    786625d041e3:	sub    eax,0x201
    786625d041e8:	cmp    eax,0x3fc
    786625d041ed:	ja     0x786625d07b6d
    786625d041f3:	movdqa xmm14,xmm1
    786625d041f8:	psrldq xmm14,0x8
    786625d041fe:	movq   rax,xmm14
    786625d04203:	add    rax,rax
    786625d04206:	je     0x786625d0421c
    786625d04208:	shr    rax,0x35
    786625d0420c:	sub    eax,0x201
    786625d04211:	cmp    eax,0x3fc
    786625d04216:	ja     0x786625d07b6d
    786625d0421c:	addpd  xmm0,xmm1
    786625d04220:	movdqa xmm4,xmm0
    786625d04224:	movdqa xmm0,xmm4
    786625d04228:	movdqu XMMWORD PTR [r12+0x240],xmm0
    786625d04232:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d0423c:	movdqa xmm2,xmm0
    786625d04240:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    786625d0424a:	movdqa xmm3,xmm0
    786625d0424e:	movdqa xmm0,xmm2
    786625d04252:	movdqa xmm1,xmm3
    786625d04256:	movq   rax,xmm0
    786625d0425b:	add    rax,rax
    786625d0425e:	je     0x786625d04274
    786625d04260:	shr    rax,0x35
    786625d04264:	sub    eax,0x201
    786625d04269:	cmp    eax,0x3fc
    786625d0426e:	ja     0x786625d07b91
    786625d04274:	movdqa xmm14,xmm0
    786625d04279:	psrldq xmm14,0x8
    786625d0427f:	movq   rax,xmm14
    786625d04284:	add    rax,rax
    786625d04287:	je     0x786625d0429d
    786625d04289:	shr    rax,0x35
    786625d0428d:	sub    eax,0x201
    786625d04292:	cmp    eax,0x3fc
    786625d04297:	ja     0x786625d07b91
    786625d0429d:	movq   rax,xmm1
    786625d042a2:	add    rax,rax
    786625d042a5:	je     0x786625d042bb
    786625d042a7:	shr    rax,0x35
    786625d042ab:	sub    eax,0x201
    786625d042b0:	cmp    eax,0x3fc
    786625d042b5:	ja     0x786625d07b91
    786625d042bb:	movdqa xmm14,xmm1
    786625d042c0:	psrldq xmm14,0x8
    786625d042c6:	movq   rax,xmm14
    786625d042cb:	add    rax,rax
    786625d042ce:	je     0x786625d042e4
    786625d042d0:	shr    rax,0x35
    786625d042d4:	sub    eax,0x201
    786625d042d9:	cmp    eax,0x3fc
    786625d042de:	ja     0x786625d07b91
    786625d042e4:	addpd  xmm0,xmm1
    786625d042e8:	movdqa xmm4,xmm0
    786625d042ec:	movdqa xmm0,xmm4
    786625d042f0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d042fa:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d04304:	movdqa xmm2,xmm0
    786625d04308:	movdqa xmm0,xmm2
    786625d0430c:	movdqa xmm1,xmm3
    786625d04310:	movq   rax,xmm0
    786625d04315:	add    rax,rax
    786625d04318:	je     0x786625d0432e
    786625d0431a:	shr    rax,0x35
    786625d0431e:	sub    eax,0x201
    786625d04323:	cmp    eax,0x3fc
    786625d04328:	ja     0x786625d07bb5
    786625d0432e:	movdqa xmm14,xmm0
    786625d04333:	psrldq xmm14,0x8
    786625d04339:	movq   rax,xmm14
    786625d0433e:	add    rax,rax
    786625d04341:	je     0x786625d04357
    786625d04343:	shr    rax,0x35
    786625d04347:	sub    eax,0x201
    786625d0434c:	cmp    eax,0x3fc
    786625d04351:	ja     0x786625d07bb5
    786625d04357:	movq   rax,xmm1
    786625d0435c:	add    rax,rax
    786625d0435f:	je     0x786625d04375
    786625d04361:	shr    rax,0x35
    786625d04365:	sub    eax,0x201
    786625d0436a:	cmp    eax,0x3fc
    786625d0436f:	ja     0x786625d07bb5
    786625d04375:	movdqa xmm14,xmm1
    786625d0437a:	psrldq xmm14,0x8
    786625d04380:	movq   rax,xmm14
    786625d04385:	add    rax,rax
    786625d04388:	je     0x786625d0439e
    786625d0438a:	shr    rax,0x35
    786625d0438e:	sub    eax,0x201
    786625d04393:	cmp    eax,0x3fc
    786625d04398:	ja     0x786625d07bb5
    786625d0439e:	addpd  xmm0,xmm1
    786625d043a2:	movdqa xmm4,xmm0
    786625d043a6:	movdqa xmm0,xmm4
    786625d043aa:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d043b4:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    786625d043be:	movdqa xmm2,xmm0
    786625d043c2:	movdqa xmm1,xmm2
    786625d043c6:	por    xmm2,xmm1
    786625d043ca:	movdqa xmm0,xmm2
    786625d043ce:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    786625d043d8:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    786625d043e2:	movdqa xmm2,xmm0
    786625d043e6:	movdqa xmm1,xmm2
    786625d043ea:	por    xmm2,xmm1
    786625d043ee:	movdqa xmm0,xmm2
    786625d043f2:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    786625d043fc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    786625d04406:	movdqa xmm2,xmm0
    786625d0440a:	movdqa xmm1,xmm2
    786625d0440e:	por    xmm2,xmm1
    786625d04412:	movdqa xmm0,xmm2
    786625d04416:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    786625d04420:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    786625d0442a:	movdqa xmm2,xmm0
    786625d0442e:	movdqa xmm1,xmm2
    786625d04432:	por    xmm2,xmm1
    786625d04436:	movdqa xmm0,xmm2
    786625d0443a:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    786625d04444:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    786625d0444e:	movdqa xmm2,xmm0
    786625d04452:	movdqa xmm1,xmm2
    786625d04456:	por    xmm2,xmm1
    786625d0445a:	movdqa xmm0,xmm2
    786625d0445e:	movdqu XMMWORD PTR [r12+0x200],xmm0
    786625d04468:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    786625d04472:	movdqa xmm2,xmm0
    786625d04476:	movdqa xmm1,xmm2
    786625d0447a:	por    xmm2,xmm1
    786625d0447e:	movdqa xmm0,xmm2
    786625d04482:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    786625d0448c:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    786625d04496:	movdqa xmm2,xmm0
    786625d0449a:	movdqa xmm1,xmm2
    786625d0449e:	por    xmm2,xmm1
    786625d044a2:	movdqa xmm0,xmm2
    786625d044a6:	movdqu XMMWORD PTR [r12+0x190],xmm0
    786625d044b0:	mov    r13,QWORD PTR [r12+0xf8]
    786625d044b8:	mov    r14,r13
    786625d044bb:	add    r14,0xa0
    786625d044c2:	mov    r15,r14
    786625d044c5:	add    r15,0x10
    786625d044c9:	stmxcsr DWORD PTR [rsp+0x114]
    786625d044d1:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d044d9:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d044e1:	shr    r11d,1
    786625d044e4:	and    r11d,0x10
    786625d044e8:	or     DWORD PTR [r12+0x314],r11d
    786625d044f0:	movdqu xmm2,XMMWORD PTR [r14]
    786625d044f5:	movdqu xmm3,XMMWORD PTR [r15]
    786625d044fa:	movdqa xmm0,xmm2
    786625d044fe:	movdqu XMMWORD PTR [r12+0x300],xmm0
    786625d04508:	movdqa xmm0,xmm3
    786625d0450c:	movdqu XMMWORD PTR [r12+0x270],xmm0
    786625d04516:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d04520:	movdqa xmm2,xmm0
    786625d04524:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d0452e:	movdqa xmm4,xmm0
    786625d04532:	stmxcsr DWORD PTR [rsp+0x110]
    786625d0453a:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d04545:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d0454d:	movdqa xmm0,xmm2
    786625d04551:	movdqa xmm1,xmm4
    786625d04555:	movq   rax,xmm0
    786625d0455a:	add    rax,rax
    786625d0455d:	je     0x786625d04573
    786625d0455f:	shr    rax,0x35
    786625d04563:	sub    eax,0x201
    786625d04568:	cmp    eax,0x3fc
    786625d0456d:	ja     0x786625d07bd9
    786625d04573:	movdqa xmm14,xmm0
    786625d04578:	psrldq xmm14,0x8
    786625d0457e:	movq   rax,xmm14
    786625d04583:	add    rax,rax
    786625d04586:	je     0x786625d0459c
    786625d04588:	shr    rax,0x35
    786625d0458c:	sub    eax,0x201
    786625d04591:	cmp    eax,0x3fc
    786625d04596:	ja     0x786625d07bd9
    786625d0459c:	movq   rax,xmm1
    786625d045a1:	add    rax,rax
    786625d045a4:	je     0x786625d045ba
    786625d045a6:	shr    rax,0x35
    786625d045aa:	sub    eax,0x201
    786625d045af:	cmp    eax,0x3fc
    786625d045b4:	ja     0x786625d07bd9
    786625d045ba:	movdqa xmm14,xmm1
    786625d045bf:	psrldq xmm14,0x8
    786625d045c5:	movq   rax,xmm14
    786625d045ca:	add    rax,rax
    786625d045cd:	je     0x786625d045e3
    786625d045cf:	shr    rax,0x35
    786625d045d3:	sub    eax,0x201
    786625d045d8:	cmp    eax,0x3fc
    786625d045dd:	ja     0x786625d07bd9
    786625d045e3:	addpd  xmm0,xmm1
    786625d045e7:	movdqa xmm5,xmm0
    786625d045eb:	movdqa xmm0,xmm5
    786625d045ef:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d045f9:	add    r13,0xf0
    786625d04600:	stmxcsr DWORD PTR [rsp+0x114]
    786625d04608:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d04610:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d04618:	shr    r11d,1
    786625d0461b:	and    r11d,0x10
    786625d0461f:	or     DWORD PTR [r12+0x314],r11d
    786625d04627:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d0462d:	movdqa xmm0,xmm2
    786625d04631:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d0463b:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d04645:	movdqa xmm4,xmm0
    786625d04649:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    786625d04653:	movdqa xmm5,xmm0
    786625d04657:	stmxcsr DWORD PTR [rsp+0x110]
    786625d0465f:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d0466a:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d04672:	movdqa xmm0,xmm4
    786625d04676:	movdqa xmm1,xmm5
    786625d0467a:	movq   rax,xmm0
    786625d0467f:	add    rax,rax
    786625d04682:	je     0x786625d04698
    786625d04684:	shr    rax,0x35
    786625d04688:	sub    eax,0x201
    786625d0468d:	cmp    eax,0x3fc
    786625d04692:	ja     0x786625d07bfd
    786625d04698:	movdqa xmm14,xmm0
    786625d0469d:	psrldq xmm14,0x8
    786625d046a3:	movq   rax,xmm14
    786625d046a8:	add    rax,rax
    786625d046ab:	je     0x786625d046c1
    786625d046ad:	shr    rax,0x35
    786625d046b1:	sub    eax,0x201
    786625d046b6:	cmp    eax,0x3fc
    786625d046bb:	ja     0x786625d07bfd
    786625d046c1:	movq   rax,xmm1
    786625d046c6:	add    rax,rax
    786625d046c9:	je     0x786625d046df
    786625d046cb:	shr    rax,0x35
    786625d046cf:	sub    eax,0x201
    786625d046d4:	cmp    eax,0x3fc
    786625d046d9:	ja     0x786625d07bfd
    786625d046df:	movdqa xmm14,xmm1
    786625d046e4:	psrldq xmm14,0x8
    786625d046ea:	movq   rax,xmm14
    786625d046ef:	add    rax,rax
    786625d046f2:	je     0x786625d04708
    786625d046f4:	shr    rax,0x35
    786625d046f8:	sub    eax,0x201
    786625d046fd:	cmp    eax,0x3fc
    786625d04702:	ja     0x786625d07bfd
    786625d04708:	addpd  xmm0,xmm1
    786625d0470c:	movdqa xmm6,xmm0
    786625d04710:	movdqa xmm0,xmm6
    786625d04714:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d0471e:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d04728:	movdqa xmm4,xmm0
    786625d0472c:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    786625d04736:	movdqa xmm5,xmm0
    786625d0473a:	movdqa xmm0,xmm4
    786625d0473e:	movdqa xmm1,xmm5
    786625d04742:	movq   rax,xmm0
    786625d04747:	add    rax,rax
    786625d0474a:	je     0x786625d04760
    786625d0474c:	shr    rax,0x35
    786625d04750:	sub    eax,0x201
    786625d04755:	cmp    eax,0x3fc
    786625d0475a:	ja     0x786625d07c21
    786625d04760:	movdqa xmm14,xmm0
    786625d04765:	psrldq xmm14,0x8
    786625d0476b:	movq   rax,xmm14
    786625d04770:	add    rax,rax
    786625d04773:	je     0x786625d04789
    786625d04775:	shr    rax,0x35
    786625d04779:	sub    eax,0x201
    786625d0477e:	cmp    eax,0x3fc
    786625d04783:	ja     0x786625d07c21
    786625d04789:	movq   rax,xmm1
    786625d0478e:	add    rax,rax
    786625d04791:	je     0x786625d047a7
    786625d04793:	shr    rax,0x35
    786625d04797:	sub    eax,0x201
    786625d0479c:	cmp    eax,0x3fc
    786625d047a1:	ja     0x786625d07c21
    786625d047a7:	movdqa xmm14,xmm1
    786625d047ac:	psrldq xmm14,0x8
    786625d047b2:	movq   rax,xmm14
    786625d047b7:	add    rax,rax
    786625d047ba:	je     0x786625d047d0
    786625d047bc:	shr    rax,0x35
    786625d047c0:	sub    eax,0x201
    786625d047c5:	cmp    eax,0x3fc
    786625d047ca:	ja     0x786625d07c21
    786625d047d0:	addpd  xmm0,xmm1
    786625d047d4:	movdqa xmm6,xmm0
    786625d047d8:	movdqa xmm0,xmm6
    786625d047dc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d047e6:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625d047f0:	movdqa xmm4,xmm0
    786625d047f4:	movdqa xmm0,xmm3
    786625d047f8:	movdqa xmm1,xmm4
    786625d047fc:	pshufd xmm1,xmm1,0x44
    786625d04801:	movq   rax,xmm0
    786625d04806:	add    rax,rax
    786625d04809:	je     0x786625d0481f
    786625d0480b:	shr    rax,0x35
    786625d0480f:	sub    eax,0x201
    786625d04814:	cmp    eax,0x3fc
    786625d04819:	ja     0x786625d07c45
    786625d0481f:	movdqa xmm14,xmm0
    786625d04824:	psrldq xmm14,0x8
    786625d0482a:	movq   rax,xmm14
    786625d0482f:	add    rax,rax
    786625d04832:	je     0x786625d04848
    786625d04834:	shr    rax,0x35
    786625d04838:	sub    eax,0x201
    786625d0483d:	cmp    eax,0x3fc
    786625d04842:	ja     0x786625d07c45
    786625d04848:	movq   rax,xmm1
    786625d0484d:	add    rax,rax
    786625d04850:	je     0x786625d04866
    786625d04852:	shr    rax,0x35
    786625d04856:	sub    eax,0x201
    786625d0485b:	cmp    eax,0x3fc
    786625d04860:	ja     0x786625d07c45
    786625d04866:	movdqa xmm14,xmm1
    786625d0486b:	psrldq xmm14,0x8
    786625d04871:	movq   rax,xmm14
    786625d04876:	add    rax,rax
    786625d04879:	je     0x786625d0488f
    786625d0487b:	shr    rax,0x35
    786625d0487f:	sub    eax,0x201
    786625d04884:	cmp    eax,0x3fc
    786625d04889:	ja     0x786625d07c45
    786625d0488f:	mulpd  xmm0,xmm1
    786625d04893:	movdqa xmm5,xmm0
    786625d04897:	movdqa xmm0,xmm5
    786625d0489b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    786625d048a5:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d048af:	movdqa xmm3,xmm0
    786625d048b3:	movdqa xmm0,xmm2
    786625d048b7:	movdqa xmm1,xmm3
    786625d048bb:	pshufd xmm1,xmm1,0x44
    786625d048c0:	movq   rax,xmm0
    786625d048c5:	add    rax,rax
    786625d048c8:	je     0x786625d048de
    786625d048ca:	shr    rax,0x35
    786625d048ce:	sub    eax,0x201
    786625d048d3:	cmp    eax,0x3fc
    786625d048d8:	ja     0x786625d07c69
    786625d048de:	movdqa xmm14,xmm0
    786625d048e3:	psrldq xmm14,0x8
    786625d048e9:	movq   rax,xmm14
    786625d048ee:	add    rax,rax
    786625d048f1:	je     0x786625d04907
    786625d048f3:	shr    rax,0x35
    786625d048f7:	sub    eax,0x201
    786625d048fc:	cmp    eax,0x3fc
    786625d04901:	ja     0x786625d07c69
    786625d04907:	movq   rax,xmm1
    786625d0490c:	add    rax,rax
    786625d0490f:	je     0x786625d04925
    786625d04911:	shr    rax,0x35
    786625d04915:	sub    eax,0x201
    786625d0491a:	cmp    eax,0x3fc
    786625d0491f:	ja     0x786625d07c69
    786625d04925:	movdqa xmm14,xmm1
    786625d0492a:	psrldq xmm14,0x8
    786625d04930:	movq   rax,xmm14
    786625d04935:	add    rax,rax
    786625d04938:	je     0x786625d0494e
    786625d0493a:	shr    rax,0x35
    786625d0493e:	sub    eax,0x201
    786625d04943:	cmp    eax,0x3fc
    786625d04948:	ja     0x786625d07c69
    786625d0494e:	mulpd  xmm0,xmm1
    786625d04952:	movdqa xmm5,xmm0
    786625d04956:	movdqa xmm0,xmm5
    786625d0495a:	movdqu XMMWORD PTR [r12+0x250],xmm0
    786625d04964:	mov    r13,QWORD PTR [r12+0xf8]
    786625d0496c:	mov    r14,r13
    786625d0496f:	add    r14,0xe0
    786625d04976:	stmxcsr DWORD PTR [rsp+0x114]
    786625d0497e:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d04986:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d0498e:	shr    r11d,1
    786625d04991:	and    r11d,0x10
    786625d04995:	or     DWORD PTR [r12+0x314],r11d
    786625d0499d:	movdqu xmm2,XMMWORD PTR [r14]
    786625d049a2:	movdqa xmm0,xmm2
    786625d049a6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d049b0:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    786625d049ba:	movdqa xmm2,xmm0
    786625d049be:	stmxcsr DWORD PTR [rsp+0x110]
    786625d049c6:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d049d1:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d049d9:	movdqa xmm0,xmm2
    786625d049dd:	movdqa xmm1,xmm4
    786625d049e1:	pshufd xmm1,xmm1,0x44
    786625d049e6:	movq   rax,xmm0
    786625d049eb:	add    rax,rax
    786625d049ee:	je     0x786625d04a04
    786625d049f0:	shr    rax,0x35
    786625d049f4:	sub    eax,0x201
    786625d049f9:	cmp    eax,0x3fc
    786625d049fe:	ja     0x786625d07c8d
    786625d04a04:	movdqa xmm14,xmm0
    786625d04a09:	psrldq xmm14,0x8
    786625d04a0f:	movq   rax,xmm14
    786625d04a14:	add    rax,rax
    786625d04a17:	je     0x786625d04a2d
    786625d04a19:	shr    rax,0x35
    786625d04a1d:	sub    eax,0x201
    786625d04a22:	cmp    eax,0x3fc
    786625d04a27:	ja     0x786625d07c8d
    786625d04a2d:	movq   rax,xmm1
    786625d04a32:	add    rax,rax
    786625d04a35:	je     0x786625d04a4b
    786625d04a37:	shr    rax,0x35
    786625d04a3b:	sub    eax,0x201
    786625d04a40:	cmp    eax,0x3fc
    786625d04a45:	ja     0x786625d07c8d
    786625d04a4b:	movdqa xmm14,xmm1
    786625d04a50:	psrldq xmm14,0x8
    786625d04a56:	movq   rax,xmm14
    786625d04a5b:	add    rax,rax
    786625d04a5e:	je     0x786625d04a74
    786625d04a60:	shr    rax,0x35
    786625d04a64:	sub    eax,0x201
    786625d04a69:	cmp    eax,0x3fc
    786625d04a6e:	ja     0x786625d07c8d
    786625d04a74:	mulpd  xmm0,xmm1
    786625d04a78:	movdqa xmm5,xmm0
    786625d04a7c:	movdqa xmm0,xmm5
    786625d04a80:	movdqu XMMWORD PTR [r12+0x230],xmm0
    786625d04a8a:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    786625d04a94:	movdqa xmm2,xmm0
    786625d04a98:	movdqa xmm1,xmm2
    786625d04a9c:	por    xmm2,xmm1
    786625d04aa0:	movdqa xmm0,xmm2
    786625d04aa4:	movdqu XMMWORD PTR [r12+0x300],xmm0
    786625d04aae:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    786625d04ab8:	movdqa xmm2,xmm0
    786625d04abc:	movdqa xmm1,xmm2
    786625d04ac0:	por    xmm2,xmm1
    786625d04ac4:	movdqa xmm0,xmm2
    786625d04ac8:	movdqu XMMWORD PTR [r12+0x190],xmm0
    786625d04ad2:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d04adc:	movdqa xmm2,xmm0
    786625d04ae0:	movdqa xmm0,xmm2
    786625d04ae4:	movdqa xmm1,xmm3
    786625d04ae8:	pshufd xmm1,xmm1,0x44
    786625d04aed:	movq   rax,xmm0
    786625d04af2:	add    rax,rax
    786625d04af5:	je     0x786625d04b0b
    786625d04af7:	shr    rax,0x35
    786625d04afb:	sub    eax,0x201
    786625d04b00:	cmp    eax,0x3fc
    786625d04b05:	ja     0x786625d07cb1
    786625d04b0b:	movdqa xmm14,xmm0
    786625d04b10:	psrldq xmm14,0x8
    786625d04b16:	movq   rax,xmm14
    786625d04b1b:	add    rax,rax
    786625d04b1e:	je     0x786625d04b34
    786625d04b20:	shr    rax,0x35
    786625d04b24:	sub    eax,0x201
    786625d04b29:	cmp    eax,0x3fc
    786625d04b2e:	ja     0x786625d07cb1
    786625d04b34:	movq   rax,xmm1
    786625d04b39:	add    rax,rax
    786625d04b3c:	je     0x786625d04b52
    786625d04b3e:	shr    rax,0x35
    786625d04b42:	sub    eax,0x201
    786625d04b47:	cmp    eax,0x3fc
    786625d04b4c:	ja     0x786625d07cb1
    786625d04b52:	movdqa xmm14,xmm1
    786625d04b57:	psrldq xmm14,0x8
    786625d04b5d:	movq   rax,xmm14
    786625d04b62:	add    rax,rax
    786625d04b65:	je     0x786625d04b7b
    786625d04b67:	shr    rax,0x35
    786625d04b6b:	sub    eax,0x201
    786625d04b70:	cmp    eax,0x3fc
    786625d04b75:	ja     0x786625d07cb1
    786625d04b7b:	mulpd  xmm0,xmm1
    786625d04b7f:	movdqa xmm4,xmm0
    786625d04b83:	movdqa xmm0,xmm4
    786625d04b87:	movdqu XMMWORD PTR [r12+0x260],xmm0
    786625d04b91:	add    r13,0x90
    786625d04b98:	stmxcsr DWORD PTR [rsp+0x114]
    786625d04ba0:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d04ba8:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d04bb0:	shr    r11d,1
    786625d04bb3:	and    r11d,0x10
    786625d04bb7:	or     DWORD PTR [r12+0x314],r11d
    786625d04bbf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d04bc5:	movdqa xmm0,xmm2
    786625d04bc9:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d04bd3:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    786625d04bdd:	movdqa xmm3,xmm0
    786625d04be1:	movdqa xmm1,xmm3
    786625d04be5:	por    xmm3,xmm1
    786625d04be9:	movdqa xmm0,xmm3
    786625d04bed:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    786625d04bf7:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    786625d04c01:	movdqa xmm3,xmm0
    786625d04c05:	movdqa xmm1,xmm3
    786625d04c09:	por    xmm3,xmm1
    786625d04c0d:	movdqa xmm0,xmm3
    786625d04c11:	movdqu XMMWORD PTR [r12+0x200],xmm0
    786625d04c1b:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    786625d04c25:	movdqa xmm3,xmm0
    786625d04c29:	movdqa xmm1,xmm3
    786625d04c2d:	por    xmm3,xmm1
    786625d04c31:	movdqa xmm0,xmm3
    786625d04c35:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    786625d04c3f:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    786625d04c49:	movdqa xmm3,xmm0
    786625d04c4d:	movdqa xmm1,xmm3
    786625d04c51:	por    xmm3,xmm1
    786625d04c55:	movdqa xmm0,xmm3
    786625d04c59:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    786625d04c63:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    786625d04c6d:	movdqa xmm3,xmm0
    786625d04c71:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    786625d04c7b:	movdqa xmm4,xmm0
    786625d04c7f:	stmxcsr DWORD PTR [rsp+0x110]
    786625d04c87:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d04c92:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d04c9a:	movdqa xmm0,xmm3
    786625d04c9e:	movdqa xmm1,xmm4
    786625d04ca2:	movq   rax,xmm0
    786625d04ca7:	add    rax,rax
    786625d04caa:	je     0x786625d04cc0
    786625d04cac:	shr    rax,0x35
    786625d04cb0:	sub    eax,0x201
    786625d04cb5:	cmp    eax,0x3fc
    786625d04cba:	ja     0x786625d07cd5
    786625d04cc0:	movdqa xmm14,xmm0
    786625d04cc5:	psrldq xmm14,0x8
    786625d04ccb:	movq   rax,xmm14
    786625d04cd0:	add    rax,rax
    786625d04cd3:	je     0x786625d04ce9
    786625d04cd5:	shr    rax,0x35
    786625d04cd9:	sub    eax,0x201
    786625d04cde:	cmp    eax,0x3fc
    786625d04ce3:	ja     0x786625d07cd5
    786625d04ce9:	movq   rax,xmm1
    786625d04cee:	add    rax,rax
    786625d04cf1:	je     0x786625d04d07
    786625d04cf3:	shr    rax,0x35
    786625d04cf7:	sub    eax,0x201
    786625d04cfc:	cmp    eax,0x3fc
    786625d04d01:	ja     0x786625d07cd5
    786625d04d07:	movdqa xmm14,xmm1
    786625d04d0c:	psrldq xmm14,0x8
    786625d04d12:	movq   rax,xmm14
    786625d04d17:	add    rax,rax
    786625d04d1a:	je     0x786625d04d30
    786625d04d1c:	shr    rax,0x35
    786625d04d20:	sub    eax,0x201
    786625d04d25:	cmp    eax,0x3fc
    786625d04d2a:	ja     0x786625d07cd5
    786625d04d30:	addpd  xmm0,xmm1
    786625d04d34:	movdqa xmm5,xmm0
    786625d04d38:	movdqa xmm0,xmm5
    786625d04d3c:	movdqu XMMWORD PTR [r12+0x240],xmm0
    786625d04d46:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d04d50:	movdqa xmm3,xmm0
    786625d04d54:	movdqa xmm0,xmm2
    786625d04d58:	movdqa xmm1,xmm3
    786625d04d5c:	pshufd xmm1,xmm1,0x44
    786625d04d61:	movq   rax,xmm0
    786625d04d66:	add    rax,rax
    786625d04d69:	je     0x786625d04d7f
    786625d04d6b:	shr    rax,0x35
    786625d04d6f:	sub    eax,0x201
    786625d04d74:	cmp    eax,0x3fc
    786625d04d79:	ja     0x786625d07cf9
    786625d04d7f:	movdqa xmm14,xmm0
    786625d04d84:	psrldq xmm14,0x8
    786625d04d8a:	movq   rax,xmm14
    786625d04d8f:	add    rax,rax
    786625d04d92:	je     0x786625d04da8
    786625d04d94:	shr    rax,0x35
    786625d04d98:	sub    eax,0x201
    786625d04d9d:	cmp    eax,0x3fc
    786625d04da2:	ja     0x786625d07cf9
    786625d04da8:	movq   rax,xmm1
    786625d04dad:	add    rax,rax
    786625d04db0:	je     0x786625d04dc6
    786625d04db2:	shr    rax,0x35
    786625d04db6:	sub    eax,0x201
    786625d04dbb:	cmp    eax,0x3fc
    786625d04dc0:	ja     0x786625d07cf9
    786625d04dc6:	movdqa xmm14,xmm1
    786625d04dcb:	psrldq xmm14,0x8
    786625d04dd1:	movq   rax,xmm14
    786625d04dd6:	add    rax,rax
    786625d04dd9:	je     0x786625d04def
    786625d04ddb:	shr    rax,0x35
    786625d04ddf:	sub    eax,0x201
    786625d04de4:	cmp    eax,0x3fc
    786625d04de9:	ja     0x786625d07cf9
    786625d04def:	mulpd  xmm0,xmm1
    786625d04df3:	movdqa xmm4,xmm0
    786625d04df7:	movdqa xmm0,xmm4
    786625d04dfb:	movdqu XMMWORD PTR [r12+0x270],xmm0
    786625d04e05:	mov    r13,QWORD PTR [r12+0xf8]
    786625d04e0d:	add    r13,0x80
    786625d04e14:	stmxcsr DWORD PTR [rsp+0x114]
    786625d04e1c:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d04e24:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d04e2c:	shr    r11d,1
    786625d04e2f:	and    r11d,0x10
    786625d04e33:	or     DWORD PTR [r12+0x314],r11d
    786625d04e3b:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d04e41:	movdqa xmm0,xmm2
    786625d04e45:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d04e4f:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d04e59:	movdqa xmm3,xmm0
    786625d04e5d:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625d04e67:	movdqa xmm4,xmm0
    786625d04e6b:	stmxcsr DWORD PTR [rsp+0x110]
    786625d04e73:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d04e7e:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d04e86:	movdqa xmm0,xmm3
    786625d04e8a:	movdqa xmm1,xmm4
    786625d04e8e:	movq   rax,xmm0
    786625d04e93:	add    rax,rax
    786625d04e96:	je     0x786625d04eac
    786625d04e98:	shr    rax,0x35
    786625d04e9c:	sub    eax,0x201
    786625d04ea1:	cmp    eax,0x3fc
    786625d04ea6:	ja     0x786625d07d1d
    786625d04eac:	movdqa xmm14,xmm0
    786625d04eb1:	psrldq xmm14,0x8
    786625d04eb7:	movq   rax,xmm14
    786625d04ebc:	add    rax,rax
    786625d04ebf:	je     0x786625d04ed5
    786625d04ec1:	shr    rax,0x35
    786625d04ec5:	sub    eax,0x201
    786625d04eca:	cmp    eax,0x3fc
    786625d04ecf:	ja     0x786625d07d1d
    786625d04ed5:	movq   rax,xmm1
    786625d04eda:	add    rax,rax
    786625d04edd:	je     0x786625d04ef3
    786625d04edf:	shr    rax,0x35
    786625d04ee3:	sub    eax,0x201
    786625d04ee8:	cmp    eax,0x3fc
    786625d04eed:	ja     0x786625d07d1d
    786625d04ef3:	movdqa xmm14,xmm1
    786625d04ef8:	psrldq xmm14,0x8
    786625d04efe:	movq   rax,xmm14
    786625d04f03:	add    rax,rax
    786625d04f06:	je     0x786625d04f1c
    786625d04f08:	shr    rax,0x35
    786625d04f0c:	sub    eax,0x201
    786625d04f11:	cmp    eax,0x3fc
    786625d04f16:	ja     0x786625d07d1d
    786625d04f1c:	addpd  xmm0,xmm1
    786625d04f20:	movdqa xmm5,xmm0
    786625d04f24:	movdqa xmm0,xmm5
    786625d04f28:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d04f32:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d04f3c:	movdqa xmm3,xmm0
    786625d04f40:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    786625d04f4a:	movdqa xmm4,xmm0
    786625d04f4e:	movdqa xmm0,xmm3
    786625d04f52:	movdqa xmm1,xmm4
    786625d04f56:	movq   rax,xmm0
    786625d04f5b:	add    rax,rax
    786625d04f5e:	je     0x786625d04f74
    786625d04f60:	shr    rax,0x35
    786625d04f64:	sub    eax,0x201
    786625d04f69:	cmp    eax,0x3fc
    786625d04f6e:	ja     0x786625d07d41
    786625d04f74:	movdqa xmm14,xmm0
    786625d04f79:	psrldq xmm14,0x8
    786625d04f7f:	movq   rax,xmm14
    786625d04f84:	add    rax,rax
    786625d04f87:	je     0x786625d04f9d
    786625d04f89:	shr    rax,0x35
    786625d04f8d:	sub    eax,0x201
    786625d04f92:	cmp    eax,0x3fc
    786625d04f97:	ja     0x786625d07d41
    786625d04f9d:	movq   rax,xmm1
    786625d04fa2:	add    rax,rax
    786625d04fa5:	je     0x786625d04fbb
    786625d04fa7:	shr    rax,0x35
    786625d04fab:	sub    eax,0x201
    786625d04fb0:	cmp    eax,0x3fc
    786625d04fb5:	ja     0x786625d07d41
    786625d04fbb:	movdqa xmm14,xmm1
    786625d04fc0:	psrldq xmm14,0x8
    786625d04fc6:	movq   rax,xmm14
    786625d04fcb:	add    rax,rax
    786625d04fce:	je     0x786625d04fe4
    786625d04fd0:	shr    rax,0x35
    786625d04fd4:	sub    eax,0x201
    786625d04fd9:	cmp    eax,0x3fc
    786625d04fde:	ja     0x786625d07d41
    786625d04fe4:	addpd  xmm0,xmm1
    786625d04fe8:	movdqa xmm5,xmm0
    786625d04fec:	movdqa xmm0,xmm5
    786625d04ff0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d04ffa:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    786625d05004:	movdqa xmm3,xmm0
    786625d05008:	movdqa xmm1,xmm3
    786625d0500c:	por    xmm3,xmm1
    786625d05010:	movdqa xmm0,xmm3
    786625d05014:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    786625d0501e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d05028:	movdqa xmm3,xmm0
    786625d0502c:	movdqa xmm0,xmm2
    786625d05030:	movdqa xmm1,xmm3
    786625d05034:	pshufd xmm1,xmm1,0x44
    786625d05039:	movq   rax,xmm0
    786625d0503e:	add    rax,rax
    786625d05041:	je     0x786625d05057
    786625d05043:	shr    rax,0x35
    786625d05047:	sub    eax,0x201
    786625d0504c:	cmp    eax,0x3fc
    786625d05051:	ja     0x786625d07d65
    786625d05057:	movdqa xmm14,xmm0
    786625d0505c:	psrldq xmm14,0x8
    786625d05062:	movq   rax,xmm14
    786625d05067:	add    rax,rax
    786625d0506a:	je     0x786625d05080
    786625d0506c:	shr    rax,0x35
    786625d05070:	sub    eax,0x201
    786625d05075:	cmp    eax,0x3fc
    786625d0507a:	ja     0x786625d07d65
    786625d05080:	movq   rax,xmm1
    786625d05085:	add    rax,rax
    786625d05088:	je     0x786625d0509e
    786625d0508a:	shr    rax,0x35
    786625d0508e:	sub    eax,0x201
    786625d05093:	cmp    eax,0x3fc
    786625d05098:	ja     0x786625d07d65
    786625d0509e:	movdqa xmm14,xmm1
    786625d050a3:	psrldq xmm14,0x8
    786625d050a9:	movq   rax,xmm14
    786625d050ae:	add    rax,rax
    786625d050b1:	je     0x786625d050c7
    786625d050b3:	shr    rax,0x35
    786625d050b7:	sub    eax,0x201
    786625d050bc:	cmp    eax,0x3fc
    786625d050c1:	ja     0x786625d07d65
    786625d050c7:	mulpd  xmm0,xmm1
    786625d050cb:	movdqa xmm4,xmm0
    786625d050cf:	movdqa xmm0,xmm4
    786625d050d3:	movdqu XMMWORD PTR [r12+0x170],xmm0
    786625d050dd:	mov    r13,QWORD PTR [r12+0xf8]
    786625d050e5:	add    r13,0xd0
    786625d050ec:	stmxcsr DWORD PTR [rsp+0x114]
    786625d050f4:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d050fc:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d05104:	shr    r11d,1
    786625d05107:	and    r11d,0x10
    786625d0510b:	or     DWORD PTR [r12+0x314],r11d
    786625d05113:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d05119:	movdqa xmm0,xmm2
    786625d0511d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d05127:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d05131:	movdqa xmm3,xmm0
    786625d05135:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    786625d0513f:	movdqa xmm4,xmm0
    786625d05143:	stmxcsr DWORD PTR [rsp+0x110]
    786625d0514b:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d05156:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d0515e:	movdqa xmm0,xmm3
    786625d05162:	movdqa xmm1,xmm4
    786625d05166:	movq   rax,xmm0
    786625d0516b:	add    rax,rax
    786625d0516e:	je     0x786625d05184
    786625d05170:	shr    rax,0x35
    786625d05174:	sub    eax,0x201
    786625d05179:	cmp    eax,0x3fc
    786625d0517e:	ja     0x786625d07d89
    786625d05184:	movdqa xmm14,xmm0
    786625d05189:	psrldq xmm14,0x8
    786625d0518f:	movq   rax,xmm14
    786625d05194:	add    rax,rax
    786625d05197:	je     0x786625d051ad
    786625d05199:	shr    rax,0x35
    786625d0519d:	sub    eax,0x201
    786625d051a2:	cmp    eax,0x3fc
    786625d051a7:	ja     0x786625d07d89
    786625d051ad:	movq   rax,xmm1
    786625d051b2:	add    rax,rax
    786625d051b5:	je     0x786625d051cb
    786625d051b7:	shr    rax,0x35
    786625d051bb:	sub    eax,0x201
    786625d051c0:	cmp    eax,0x3fc
    786625d051c5:	ja     0x786625d07d89
    786625d051cb:	movdqa xmm14,xmm1
    786625d051d0:	psrldq xmm14,0x8
    786625d051d6:	movq   rax,xmm14
    786625d051db:	add    rax,rax
    786625d051de:	je     0x786625d051f4
    786625d051e0:	shr    rax,0x35
    786625d051e4:	sub    eax,0x201
    786625d051e9:	cmp    eax,0x3fc
    786625d051ee:	ja     0x786625d07d89
    786625d051f4:	addpd  xmm0,xmm1
    786625d051f8:	movdqa xmm5,xmm0
    786625d051fc:	movdqa xmm0,xmm5
    786625d05200:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d0520a:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    786625d05214:	movdqa xmm3,xmm0
    786625d05218:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d05222:	movdqa xmm4,xmm0
    786625d05226:	movdqa xmm0,xmm3
    786625d0522a:	movdqa xmm1,xmm4
    786625d0522e:	pshufd xmm1,xmm1,0x44
    786625d05233:	movq   rax,xmm0
    786625d05238:	add    rax,rax
    786625d0523b:	je     0x786625d05251
    786625d0523d:	shr    rax,0x35
    786625d05241:	sub    eax,0x201
    786625d05246:	cmp    eax,0x3fc
    786625d0524b:	ja     0x786625d07dad
    786625d05251:	movdqa xmm14,xmm0
    786625d05256:	psrldq xmm14,0x8
    786625d0525c:	movq   rax,xmm14
    786625d05261:	add    rax,rax
    786625d05264:	je     0x786625d0527a
    786625d05266:	shr    rax,0x35
    786625d0526a:	sub    eax,0x201
    786625d0526f:	cmp    eax,0x3fc
    786625d05274:	ja     0x786625d07dad
    786625d0527a:	movq   rax,xmm1
    786625d0527f:	add    rax,rax
    786625d05282:	je     0x786625d05298
    786625d05284:	shr    rax,0x35
    786625d05288:	sub    eax,0x201
    786625d0528d:	cmp    eax,0x3fc
    786625d05292:	ja     0x786625d07dad
    786625d05298:	movdqa xmm14,xmm1
    786625d0529d:	psrldq xmm14,0x8
    786625d052a3:	movq   rax,xmm14
    786625d052a8:	add    rax,rax
    786625d052ab:	je     0x786625d052c1
    786625d052ad:	shr    rax,0x35
    786625d052b1:	sub    eax,0x201
    786625d052b6:	cmp    eax,0x3fc
    786625d052bb:	ja     0x786625d07dad
    786625d052c1:	mulpd  xmm0,xmm1
    786625d052c5:	movdqa xmm5,xmm0
    786625d052c9:	movdqa xmm0,xmm5
    786625d052cd:	movdqu XMMWORD PTR [r12+0x260],xmm0
    786625d052d7:	mov    r13d,0x0
    786625d052dd:	mov    r14d,0x0
    786625d052e3:	mov    QWORD PTR [r12+0x1b0],r13
    786625d052eb:	mov    QWORD PTR [r12+0x1b8],r14
    786625d052f3:	movdqa xmm0,xmm2
    786625d052f7:	movdqa xmm1,xmm4
    786625d052fb:	pshufd xmm1,xmm1,0x44
    786625d05300:	movq   rax,xmm0
    786625d05305:	add    rax,rax
    786625d05308:	je     0x786625d0531e
    786625d0530a:	shr    rax,0x35
    786625d0530e:	sub    eax,0x201
    786625d05313:	cmp    eax,0x3fc
    786625d05318:	ja     0x786625d07dd1
    786625d0531e:	movdqa xmm14,xmm0
    786625d05323:	psrldq xmm14,0x8
    786625d05329:	movq   rax,xmm14
    786625d0532e:	add    rax,rax
    786625d05331:	je     0x786625d05347
    786625d05333:	shr    rax,0x35
    786625d05337:	sub    eax,0x201
    786625d0533c:	cmp    eax,0x3fc
    786625d05341:	ja     0x786625d07dd1
    786625d05347:	movq   rax,xmm1
    786625d0534c:	add    rax,rax
    786625d0534f:	je     0x786625d05365
    786625d05351:	shr    rax,0x35
    786625d05355:	sub    eax,0x201
    786625d0535a:	cmp    eax,0x3fc
    786625d0535f:	ja     0x786625d07dd1
    786625d05365:	movdqa xmm14,xmm1
    786625d0536a:	psrldq xmm14,0x8
    786625d05370:	movq   rax,xmm14
    786625d05375:	add    rax,rax
    786625d05378:	je     0x786625d0538e
    786625d0537a:	shr    rax,0x35
    786625d0537e:	sub    eax,0x201
    786625d05383:	cmp    eax,0x3fc
    786625d05388:	ja     0x786625d07dd1
    786625d0538e:	mulpd  xmm0,xmm1
    786625d05392:	movdqa xmm3,xmm0
    786625d05396:	movdqa xmm0,xmm3
    786625d0539a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    786625d053a4:	mov    r13,QWORD PTR [r12+0xf8]
    786625d053ac:	mov    r14,r13
    786625d053af:	add    r14,0xc0
    786625d053b6:	stmxcsr DWORD PTR [rsp+0x114]
    786625d053be:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d053c6:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d053ce:	shr    r11d,1
    786625d053d1:	and    r11d,0x10
    786625d053d5:	or     DWORD PTR [r12+0x314],r11d
    786625d053dd:	movdqu xmm2,XMMWORD PTR [r14]
    786625d053e2:	movdqa xmm0,xmm2
    786625d053e6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d053f0:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    786625d053fa:	movdqa xmm3,xmm0
    786625d053fe:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    786625d05408:	movdqa xmm4,xmm0
    786625d0540c:	stmxcsr DWORD PTR [rsp+0x110]
    786625d05414:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d0541f:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d05427:	movdqa xmm0,xmm3
    786625d0542b:	movdqa xmm1,xmm4
    786625d0542f:	movq   rax,xmm0
    786625d05434:	add    rax,rax
    786625d05437:	je     0x786625d0544d
    786625d05439:	shr    rax,0x35
    786625d0543d:	sub    eax,0x201
    786625d05442:	cmp    eax,0x3fc
    786625d05447:	ja     0x786625d07df5
    786625d0544d:	movdqa xmm14,xmm0
    786625d05452:	psrldq xmm14,0x8
    786625d05458:	movq   rax,xmm14
    786625d0545d:	add    rax,rax
    786625d05460:	je     0x786625d05476
    786625d05462:	shr    rax,0x35
    786625d05466:	sub    eax,0x201
    786625d0546b:	cmp    eax,0x3fc
    786625d05470:	ja     0x786625d07df5
    786625d05476:	movq   rax,xmm1
    786625d0547b:	add    rax,rax
    786625d0547e:	je     0x786625d05494
    786625d05480:	shr    rax,0x35
    786625d05484:	sub    eax,0x201
    786625d05489:	cmp    eax,0x3fc
    786625d0548e:	ja     0x786625d07df5
    786625d05494:	movdqa xmm14,xmm1
    786625d05499:	psrldq xmm14,0x8
    786625d0549f:	movq   rax,xmm14
    786625d054a4:	add    rax,rax
    786625d054a7:	je     0x786625d054bd
    786625d054a9:	shr    rax,0x35
    786625d054ad:	sub    eax,0x201
    786625d054b2:	cmp    eax,0x3fc
    786625d054b7:	ja     0x786625d07df5
    786625d054bd:	addpd  xmm0,xmm1
    786625d054c1:	movdqa xmm5,xmm0
    786625d054c5:	movdqa xmm0,xmm5
    786625d054c9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    786625d054d3:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    786625d054dd:	movdqa xmm3,xmm0
    786625d054e1:	movdqa xmm1,xmm3
    786625d054e5:	por    xmm3,xmm1
    786625d054e9:	movdqa xmm0,xmm3
    786625d054ed:	movdqu XMMWORD PTR [r12+0x270],xmm0
    786625d054f7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d05501:	movdqa xmm3,xmm0
    786625d05505:	movdqa xmm1,xmm3
    786625d05509:	por    xmm3,xmm1
    786625d0550d:	movdqa xmm0,xmm3
    786625d05511:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    786625d0551b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d05525:	movdqa xmm3,xmm0
    786625d05529:	movdqa xmm0,xmm2
    786625d0552d:	movdqa xmm1,xmm3
    786625d05531:	pshufd xmm1,xmm1,0x44
    786625d05536:	movq   rax,xmm0
    786625d0553b:	add    rax,rax
    786625d0553e:	je     0x786625d05554
    786625d05540:	shr    rax,0x35
    786625d05544:	sub    eax,0x201
    786625d05549:	cmp    eax,0x3fc
    786625d0554e:	ja     0x786625d07e19
    786625d05554:	movdqa xmm14,xmm0
    786625d05559:	psrldq xmm14,0x8
    786625d0555f:	movq   rax,xmm14
    786625d05564:	add    rax,rax
    786625d05567:	je     0x786625d0557d
    786625d05569:	shr    rax,0x35
    786625d0556d:	sub    eax,0x201
    786625d05572:	cmp    eax,0x3fc
    786625d05577:	ja     0x786625d07e19
    786625d0557d:	movq   rax,xmm1
    786625d05582:	add    rax,rax
    786625d05585:	je     0x786625d0559b
    786625d05587:	shr    rax,0x35
    786625d0558b:	sub    eax,0x201
    786625d05590:	cmp    eax,0x3fc
    786625d05595:	ja     0x786625d07e19
    786625d0559b:	movdqa xmm14,xmm1
    786625d055a0:	psrldq xmm14,0x8
    786625d055a6:	movq   rax,xmm14
    786625d055ab:	add    rax,rax
    786625d055ae:	je     0x786625d055c4
    786625d055b0:	shr    rax,0x35
    786625d055b4:	sub    eax,0x201
    786625d055b9:	cmp    eax,0x3fc
    786625d055be:	ja     0x786625d07e19
    786625d055c4:	mulpd  xmm0,xmm1
    786625d055c8:	movdqa xmm4,xmm0
    786625d055cc:	movdqa xmm0,xmm4
    786625d055d0:	movdqu XMMWORD PTR [r12+0x250],xmm0
    786625d055da:	add    r13,0x20
    786625d055de:	stmxcsr DWORD PTR [rsp+0x114]
    786625d055e6:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d055ee:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d055f6:	shr    r11d,1
    786625d055f9:	and    r11d,0x10
    786625d055fd:	or     DWORD PTR [r12+0x314],r11d
    786625d05605:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d0560b:	movdqa xmm0,xmm2
    786625d0560f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d05619:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d05623:	movdqa xmm2,xmm0
    786625d05627:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d05631:	movdqa xmm4,xmm0
    786625d05635:	stmxcsr DWORD PTR [rsp+0x110]
    786625d0563d:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d05648:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d05650:	movdqa xmm0,xmm2
    786625d05654:	movdqa xmm1,xmm4
    786625d05658:	movq   rax,xmm0
    786625d0565d:	add    rax,rax
    786625d05660:	je     0x786625d05676
    786625d05662:	shr    rax,0x35
    786625d05666:	sub    eax,0x201
    786625d0566b:	cmp    eax,0x3fc
    786625d05670:	ja     0x786625d07e3d
    786625d05676:	movdqa xmm14,xmm0
    786625d0567b:	psrldq xmm14,0x8
    786625d05681:	movq   rax,xmm14
    786625d05686:	add    rax,rax
    786625d05689:	je     0x786625d0569f
    786625d0568b:	shr    rax,0x35
    786625d0568f:	sub    eax,0x201
    786625d05694:	cmp    eax,0x3fc
    786625d05699:	ja     0x786625d07e3d
    786625d0569f:	movq   rax,xmm1
    786625d056a4:	add    rax,rax
    786625d056a7:	je     0x786625d056bd
    786625d056a9:	shr    rax,0x35
    786625d056ad:	sub    eax,0x201
    786625d056b2:	cmp    eax,0x3fc
    786625d056b7:	ja     0x786625d07e3d
    786625d056bd:	movdqa xmm14,xmm1
    786625d056c2:	psrldq xmm14,0x8
    786625d056c8:	movq   rax,xmm14
    786625d056cd:	add    rax,rax
    786625d056d0:	je     0x786625d056e6
    786625d056d2:	shr    rax,0x35
    786625d056d6:	sub    eax,0x201
    786625d056db:	cmp    eax,0x3fc
    786625d056e0:	ja     0x786625d07e3d
    786625d056e6:	addpd  xmm0,xmm1
    786625d056ea:	movdqa xmm5,xmm0
    786625d056ee:	movdqa xmm0,xmm5
    786625d056f2:	movdqu XMMWORD PTR [r12+0x170],xmm0
    786625d056fc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    786625d05706:	movdqa xmm2,xmm0
    786625d0570a:	movdqa xmm0,xmm2
    786625d0570e:	movdqa xmm1,xmm3
    786625d05712:	pshufd xmm1,xmm1,0x44
    786625d05717:	movq   rax,xmm0
    786625d0571c:	add    rax,rax
    786625d0571f:	je     0x786625d05735
    786625d05721:	shr    rax,0x35
    786625d05725:	sub    eax,0x201
    786625d0572a:	cmp    eax,0x3fc
    786625d0572f:	ja     0x786625d07e61
    786625d05735:	movdqa xmm14,xmm0
    786625d0573a:	psrldq xmm14,0x8
    786625d05740:	movq   rax,xmm14
    786625d05745:	add    rax,rax
    786625d05748:	je     0x786625d0575e
    786625d0574a:	shr    rax,0x35
    786625d0574e:	sub    eax,0x201
    786625d05753:	cmp    eax,0x3fc
    786625d05758:	ja     0x786625d07e61
    786625d0575e:	movq   rax,xmm1
    786625d05763:	add    rax,rax
    786625d05766:	je     0x786625d0577c
    786625d05768:	shr    rax,0x35
    786625d0576c:	sub    eax,0x201
    786625d05771:	cmp    eax,0x3fc
    786625d05776:	ja     0x786625d07e61
    786625d0577c:	movdqa xmm14,xmm1
    786625d05781:	psrldq xmm14,0x8
    786625d05787:	movq   rax,xmm14
    786625d0578c:	add    rax,rax
    786625d0578f:	je     0x786625d057a5
    786625d05791:	shr    rax,0x35
    786625d05795:	sub    eax,0x201
    786625d0579a:	cmp    eax,0x3fc
    786625d0579f:	ja     0x786625d07e61
    786625d057a5:	mulpd  xmm0,xmm1
    786625d057a9:	movdqa xmm4,xmm0
    786625d057ad:	movdqa xmm0,xmm4
    786625d057b1:	movdqu XMMWORD PTR [r12+0x160],xmm0
    786625d057bb:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d057c5:	movdqa xmm2,xmm0
    786625d057c9:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625d057d3:	movdqa xmm3,xmm0
    786625d057d7:	movdqa xmm0,xmm2
    786625d057db:	movdqa xmm1,xmm3
    786625d057df:	movq   rax,xmm0
    786625d057e4:	add    rax,rax
    786625d057e7:	je     0x786625d057fd
    786625d057e9:	shr    rax,0x35
    786625d057ed:	sub    eax,0x201
    786625d057f2:	cmp    eax,0x3fc
    786625d057f7:	ja     0x786625d07e85
    786625d057fd:	movdqa xmm14,xmm0
    786625d05802:	psrldq xmm14,0x8
    786625d05808:	movq   rax,xmm14
    786625d0580d:	add    rax,rax
    786625d05810:	je     0x786625d05826
    786625d05812:	shr    rax,0x35
    786625d05816:	sub    eax,0x201
    786625d0581b:	cmp    eax,0x3fc
    786625d05820:	ja     0x786625d07e85
    786625d05826:	movq   rax,xmm1
    786625d0582b:	add    rax,rax
    786625d0582e:	je     0x786625d05844
    786625d05830:	shr    rax,0x35
    786625d05834:	sub    eax,0x201
    786625d05839:	cmp    eax,0x3fc
    786625d0583e:	ja     0x786625d07e85
    786625d05844:	movdqa xmm14,xmm1
    786625d05849:	psrldq xmm14,0x8
    786625d0584f:	movq   rax,xmm14
    786625d05854:	add    rax,rax
    786625d05857:	je     0x786625d0586d
    786625d05859:	shr    rax,0x35
    786625d0585d:	sub    eax,0x201
    786625d05862:	cmp    eax,0x3fc
    786625d05867:	ja     0x786625d07e85
    786625d0586d:	addpd  xmm0,xmm1
    786625d05871:	movdqa xmm4,xmm0
    786625d05875:	movdqa xmm0,xmm4
    786625d05879:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d05883:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d0588d:	movdqa xmm2,xmm0
    786625d05891:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625d0589b:	movdqa xmm3,xmm0
    786625d0589f:	movdqa xmm0,xmm2
    786625d058a3:	movdqa xmm1,xmm3
    786625d058a7:	pshufd xmm1,xmm1,0x44
    786625d058ac:	movq   rax,xmm0
    786625d058b1:	add    rax,rax
    786625d058b4:	je     0x786625d058ca
    786625d058b6:	shr    rax,0x35
    786625d058ba:	sub    eax,0x201
    786625d058bf:	cmp    eax,0x3fc
    786625d058c4:	ja     0x786625d07ea9
    786625d058ca:	movdqa xmm14,xmm0
    786625d058cf:	psrldq xmm14,0x8
    786625d058d5:	movq   rax,xmm14
    786625d058da:	add    rax,rax
    786625d058dd:	je     0x786625d058f3
    786625d058df:	shr    rax,0x35
    786625d058e3:	sub    eax,0x201
    786625d058e8:	cmp    eax,0x3fc
    786625d058ed:	ja     0x786625d07ea9
    786625d058f3:	movq   rax,xmm1
    786625d058f8:	add    rax,rax
    786625d058fb:	je     0x786625d05911
    786625d058fd:	shr    rax,0x35
    786625d05901:	sub    eax,0x201
    786625d05906:	cmp    eax,0x3fc
    786625d0590b:	ja     0x786625d07ea9
    786625d05911:	movdqa xmm14,xmm1
    786625d05916:	psrldq xmm14,0x8
    786625d0591c:	movq   rax,xmm14
    786625d05921:	add    rax,rax
    786625d05924:	je     0x786625d0593a
    786625d05926:	shr    rax,0x35
    786625d0592a:	sub    eax,0x201
    786625d0592f:	cmp    eax,0x3fc
    786625d05934:	ja     0x786625d07ea9
    786625d0593a:	mulpd  xmm0,xmm1
    786625d0593e:	movdqa xmm4,xmm0
    786625d05942:	movdqa xmm0,xmm4
    786625d05946:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d05950:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    786625d0595a:	movdqa xmm2,xmm0
    786625d0595e:	movdqa xmm0,xmm2
    786625d05962:	movdqa xmm1,xmm3
    786625d05966:	pshufd xmm1,xmm1,0x44
    786625d0596b:	movq   rax,xmm0
    786625d05970:	add    rax,rax
    786625d05973:	je     0x786625d05989
    786625d05975:	shr    rax,0x35
    786625d05979:	sub    eax,0x201
    786625d0597e:	cmp    eax,0x3fc
    786625d05983:	ja     0x786625d07ecd
    786625d05989:	movdqa xmm14,xmm0
    786625d0598e:	psrldq xmm14,0x8
    786625d05994:	movq   rax,xmm14
    786625d05999:	add    rax,rax
    786625d0599c:	je     0x786625d059b2
    786625d0599e:	shr    rax,0x35
    786625d059a2:	sub    eax,0x201
    786625d059a7:	cmp    eax,0x3fc
    786625d059ac:	ja     0x786625d07ecd
    786625d059b2:	movq   rax,xmm1
    786625d059b7:	add    rax,rax
    786625d059ba:	je     0x786625d059d0
    786625d059bc:	shr    rax,0x35
    786625d059c0:	sub    eax,0x201
    786625d059c5:	cmp    eax,0x3fc
    786625d059ca:	ja     0x786625d07ecd
    786625d059d0:	movdqa xmm14,xmm1
    786625d059d5:	psrldq xmm14,0x8
    786625d059db:	movq   rax,xmm14
    786625d059e0:	add    rax,rax
    786625d059e3:	je     0x786625d059f9
    786625d059e5:	shr    rax,0x35
    786625d059e9:	sub    eax,0x201
    786625d059ee:	cmp    eax,0x3fc
    786625d059f3:	ja     0x786625d07ecd
    786625d059f9:	mulpd  xmm0,xmm1
    786625d059fd:	movdqa xmm4,xmm0
    786625d05a01:	movdqa xmm0,xmm4
    786625d05a05:	movdqu XMMWORD PTR [r12+0x230],xmm0
    786625d05a0f:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    786625d05a19:	movdqa xmm2,xmm0
    786625d05a1d:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    786625d05a27:	movdqa xmm4,xmm0
    786625d05a2b:	movdqa xmm0,xmm2
    786625d05a2f:	movdqa xmm1,xmm4
    786625d05a33:	movq   rax,xmm0
    786625d05a38:	add    rax,rax
    786625d05a3b:	je     0x786625d05a51
    786625d05a3d:	shr    rax,0x35
    786625d05a41:	sub    eax,0x201
    786625d05a46:	cmp    eax,0x3fc
    786625d05a4b:	ja     0x786625d07ef1
    786625d05a51:	movdqa xmm14,xmm0
    786625d05a56:	psrldq xmm14,0x8
    786625d05a5c:	movq   rax,xmm14
    786625d05a61:	add    rax,rax
    786625d05a64:	je     0x786625d05a7a
    786625d05a66:	shr    rax,0x35
    786625d05a6a:	sub    eax,0x201
    786625d05a6f:	cmp    eax,0x3fc
    786625d05a74:	ja     0x786625d07ef1
    786625d05a7a:	movq   rax,xmm1
    786625d05a7f:	add    rax,rax
    786625d05a82:	je     0x786625d05a98
    786625d05a84:	shr    rax,0x35
    786625d05a88:	sub    eax,0x201
    786625d05a8d:	cmp    eax,0x3fc
    786625d05a92:	ja     0x786625d07ef1
    786625d05a98:	movdqa xmm14,xmm1
    786625d05a9d:	psrldq xmm14,0x8
    786625d05aa3:	movq   rax,xmm14
    786625d05aa8:	add    rax,rax
    786625d05aab:	je     0x786625d05ac1
    786625d05aad:	shr    rax,0x35
    786625d05ab1:	sub    eax,0x201
    786625d05ab6:	cmp    eax,0x3fc
    786625d05abb:	ja     0x786625d07ef1
    786625d05ac1:	addpd  xmm0,xmm1
    786625d05ac5:	movdqa xmm5,xmm0
    786625d05ac9:	movdqa xmm0,xmm5
    786625d05acd:	movdqu XMMWORD PTR [r12+0x240],xmm0
    786625d05ad7:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d05ae1:	movdqa xmm2,xmm0
    786625d05ae5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    786625d05aef:	movdqa xmm4,xmm0
    786625d05af3:	movdqa xmm0,xmm2
    786625d05af7:	movdqa xmm1,xmm4
    786625d05afb:	movq   rax,xmm0
    786625d05b00:	add    rax,rax
    786625d05b03:	je     0x786625d05b19
    786625d05b05:	shr    rax,0x35
    786625d05b09:	sub    eax,0x201
    786625d05b0e:	cmp    eax,0x3fc
    786625d05b13:	ja     0x786625d07f15
    786625d05b19:	movdqa xmm14,xmm0
    786625d05b1e:	psrldq xmm14,0x8
    786625d05b24:	movq   rax,xmm14
    786625d05b29:	add    rax,rax
    786625d05b2c:	je     0x786625d05b42
    786625d05b2e:	shr    rax,0x35
    786625d05b32:	sub    eax,0x201
    786625d05b37:	cmp    eax,0x3fc
    786625d05b3c:	ja     0x786625d07f15
    786625d05b42:	movq   rax,xmm1
    786625d05b47:	add    rax,rax
    786625d05b4a:	je     0x786625d05b60
    786625d05b4c:	shr    rax,0x35
    786625d05b50:	sub    eax,0x201
    786625d05b55:	cmp    eax,0x3fc
    786625d05b5a:	ja     0x786625d07f15
    786625d05b60:	movdqa xmm14,xmm1
    786625d05b65:	psrldq xmm14,0x8
    786625d05b6b:	movq   rax,xmm14
    786625d05b70:	add    rax,rax
    786625d05b73:	je     0x786625d05b89
    786625d05b75:	shr    rax,0x35
    786625d05b79:	sub    eax,0x201
    786625d05b7e:	cmp    eax,0x3fc
    786625d05b83:	ja     0x786625d07f15
    786625d05b89:	addpd  xmm0,xmm1
    786625d05b8d:	movdqa xmm5,xmm0
    786625d05b91:	movdqa xmm0,xmm5
    786625d05b95:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d05b9f:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    786625d05ba9:	movdqa xmm2,xmm0
    786625d05bad:	movdqa xmm0,xmm2
    786625d05bb1:	movdqa xmm1,xmm3
    786625d05bb5:	pshufd xmm1,xmm1,0x44
    786625d05bba:	movq   rax,xmm0
    786625d05bbf:	add    rax,rax
    786625d05bc2:	je     0x786625d05bd8
    786625d05bc4:	shr    rax,0x35
    786625d05bc8:	sub    eax,0x201
    786625d05bcd:	cmp    eax,0x3fc
    786625d05bd2:	ja     0x786625d07f39
    786625d05bd8:	movdqa xmm14,xmm0
    786625d05bdd:	psrldq xmm14,0x8
    786625d05be3:	movq   rax,xmm14
    786625d05be8:	add    rax,rax
    786625d05beb:	je     0x786625d05c01
    786625d05bed:	shr    rax,0x35
    786625d05bf1:	sub    eax,0x201
    786625d05bf6:	cmp    eax,0x3fc
    786625d05bfb:	ja     0x786625d07f39
    786625d05c01:	movq   rax,xmm1
    786625d05c06:	add    rax,rax
    786625d05c09:	je     0x786625d05c1f
    786625d05c0b:	shr    rax,0x35
    786625d05c0f:	sub    eax,0x201
    786625d05c14:	cmp    eax,0x3fc
    786625d05c19:	ja     0x786625d07f39
    786625d05c1f:	movdqa xmm14,xmm1
    786625d05c24:	psrldq xmm14,0x8
    786625d05c2a:	movq   rax,xmm14
    786625d05c2f:	add    rax,rax
    786625d05c32:	je     0x786625d05c48
    786625d05c34:	shr    rax,0x35
    786625d05c38:	sub    eax,0x201
    786625d05c3d:	cmp    eax,0x3fc
    786625d05c42:	ja     0x786625d07f39
    786625d05c48:	mulpd  xmm0,xmm1
    786625d05c4c:	movdqa xmm4,xmm0
    786625d05c50:	movdqa xmm0,xmm4
    786625d05c54:	movdqu XMMWORD PTR [r12+0x250],xmm0
    786625d05c5e:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    786625d05c68:	movdqa xmm2,xmm0
    786625d05c6c:	movdqa xmm0,xmm2
    786625d05c70:	movdqa xmm1,xmm3
    786625d05c74:	pshufd xmm1,xmm1,0x44
    786625d05c79:	movq   rax,xmm0
    786625d05c7e:	add    rax,rax
    786625d05c81:	je     0x786625d05c97
    786625d05c83:	shr    rax,0x35
    786625d05c87:	sub    eax,0x201
    786625d05c8c:	cmp    eax,0x3fc
    786625d05c91:	ja     0x786625d07f5d
    786625d05c97:	movdqa xmm14,xmm0
    786625d05c9c:	psrldq xmm14,0x8
    786625d05ca2:	movq   rax,xmm14
    786625d05ca7:	add    rax,rax
    786625d05caa:	je     0x786625d05cc0
    786625d05cac:	shr    rax,0x35
    786625d05cb0:	sub    eax,0x201
    786625d05cb5:	cmp    eax,0x3fc
    786625d05cba:	ja     0x786625d07f5d
    786625d05cc0:	movq   rax,xmm1
    786625d05cc5:	add    rax,rax
    786625d05cc8:	je     0x786625d05cde
    786625d05cca:	shr    rax,0x35
    786625d05cce:	sub    eax,0x201
    786625d05cd3:	cmp    eax,0x3fc
    786625d05cd8:	ja     0x786625d07f5d
    786625d05cde:	movdqa xmm14,xmm1
    786625d05ce3:	psrldq xmm14,0x8
    786625d05ce9:	movq   rax,xmm14
    786625d05cee:	add    rax,rax
    786625d05cf1:	je     0x786625d05d07
    786625d05cf3:	shr    rax,0x35
    786625d05cf7:	sub    eax,0x201
    786625d05cfc:	cmp    eax,0x3fc
    786625d05d01:	ja     0x786625d07f5d
    786625d05d07:	mulpd  xmm0,xmm1
    786625d05d0b:	movdqa xmm4,xmm0
    786625d05d0f:	movdqa xmm0,xmm4
    786625d05d13:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625d05d1d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d05d27:	movdqa xmm2,xmm0
    786625d05d2b:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d05d35:	movdqa xmm3,xmm0
    786625d05d39:	movdqa xmm0,xmm2
    786625d05d3d:	movdqa xmm1,xmm3
    786625d05d41:	movq   rax,xmm0
    786625d05d46:	add    rax,rax
    786625d05d49:	je     0x786625d05d5f
    786625d05d4b:	shr    rax,0x35
    786625d05d4f:	sub    eax,0x201
    786625d05d54:	cmp    eax,0x3fc
    786625d05d59:	ja     0x786625d07f81
    786625d05d5f:	movdqa xmm14,xmm0
    786625d05d64:	psrldq xmm14,0x8
    786625d05d6a:	movq   rax,xmm14
    786625d05d6f:	add    rax,rax
    786625d05d72:	je     0x786625d05d88
    786625d05d74:	shr    rax,0x35
    786625d05d78:	sub    eax,0x201
    786625d05d7d:	cmp    eax,0x3fc
    786625d05d82:	ja     0x786625d07f81
    786625d05d88:	movq   rax,xmm1
    786625d05d8d:	add    rax,rax
    786625d05d90:	je     0x786625d05da6
    786625d05d92:	shr    rax,0x35
    786625d05d96:	sub    eax,0x201
    786625d05d9b:	cmp    eax,0x3fc
    786625d05da0:	ja     0x786625d07f81
    786625d05da6:	movdqa xmm14,xmm1
    786625d05dab:	psrldq xmm14,0x8
    786625d05db1:	movq   rax,xmm14
    786625d05db6:	add    rax,rax
    786625d05db9:	je     0x786625d05dcf
    786625d05dbb:	shr    rax,0x35
    786625d05dbf:	sub    eax,0x201
    786625d05dc4:	cmp    eax,0x3fc
    786625d05dc9:	ja     0x786625d07f81
    786625d05dcf:	addpd  xmm0,xmm1
    786625d05dd3:	movdqa xmm4,xmm0
    786625d05dd7:	movdqa xmm0,xmm4
    786625d05ddb:	movdqu XMMWORD PTR [r12+0x160],xmm0
    786625d05de5:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d05def:	movdqa xmm2,xmm0
    786625d05df3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d05dfd:	movdqa xmm3,xmm0
    786625d05e01:	movdqa xmm0,xmm2
    786625d05e05:	movdqa xmm1,xmm3
    786625d05e09:	movq   rax,xmm0
    786625d05e0e:	add    rax,rax
    786625d05e11:	je     0x786625d05e27
    786625d05e13:	shr    rax,0x35
    786625d05e17:	sub    eax,0x201
    786625d05e1c:	cmp    eax,0x3fc
    786625d05e21:	ja     0x786625d07fa5
    786625d05e27:	movdqa xmm14,xmm0
    786625d05e2c:	psrldq xmm14,0x8
    786625d05e32:	movq   rax,xmm14
    786625d05e37:	add    rax,rax
    786625d05e3a:	je     0x786625d05e50
    786625d05e3c:	shr    rax,0x35
    786625d05e40:	sub    eax,0x201
    786625d05e45:	cmp    eax,0x3fc
    786625d05e4a:	ja     0x786625d07fa5
    786625d05e50:	movq   rax,xmm1
    786625d05e55:	add    rax,rax
    786625d05e58:	je     0x786625d05e6e
    786625d05e5a:	shr    rax,0x35
    786625d05e5e:	sub    eax,0x201
    786625d05e63:	cmp    eax,0x3fc
    786625d05e68:	ja     0x786625d07fa5
    786625d05e6e:	movdqa xmm14,xmm1
    786625d05e73:	psrldq xmm14,0x8
    786625d05e79:	movq   rax,xmm14
    786625d05e7e:	add    rax,rax
    786625d05e81:	je     0x786625d05e97
    786625d05e83:	shr    rax,0x35
    786625d05e87:	sub    eax,0x201
    786625d05e8c:	cmp    eax,0x3fc
    786625d05e91:	ja     0x786625d07fa5
    786625d05e97:	addpd  xmm0,xmm1
    786625d05e9b:	movdqa xmm4,xmm0
    786625d05e9f:	movdqa xmm0,xmm4
    786625d05ea3:	movdqu XMMWORD PTR [r12+0x170],xmm0
    786625d05ead:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    786625d05eb7:	movdqa xmm2,xmm0
    786625d05ebb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625d05ec5:	movdqa xmm3,xmm0
    786625d05ec9:	movdqa xmm0,xmm2
    786625d05ecd:	movdqa xmm1,xmm3
    786625d05ed1:	pshufd xmm1,xmm1,0x44
    786625d05ed6:	movq   rax,xmm0
    786625d05edb:	add    rax,rax
    786625d05ede:	je     0x786625d05ef4
    786625d05ee0:	shr    rax,0x35
    786625d05ee4:	sub    eax,0x201
    786625d05ee9:	cmp    eax,0x3fc
    786625d05eee:	ja     0x786625d07fc9
    786625d05ef4:	movdqa xmm14,xmm0
    786625d05ef9:	psrldq xmm14,0x8
    786625d05eff:	movq   rax,xmm14
    786625d05f04:	add    rax,rax
    786625d05f07:	je     0x786625d05f1d
    786625d05f09:	shr    rax,0x35
    786625d05f0d:	sub    eax,0x201
    786625d05f12:	cmp    eax,0x3fc
    786625d05f17:	ja     0x786625d07fc9
    786625d05f1d:	movq   rax,xmm1
    786625d05f22:	add    rax,rax
    786625d05f25:	je     0x786625d05f3b
    786625d05f27:	shr    rax,0x35
    786625d05f2b:	sub    eax,0x201
    786625d05f30:	cmp    eax,0x3fc
    786625d05f35:	ja     0x786625d07fc9
    786625d05f3b:	movdqa xmm14,xmm1
    786625d05f40:	psrldq xmm14,0x8
    786625d05f46:	movq   rax,xmm14
    786625d05f4b:	add    rax,rax
    786625d05f4e:	je     0x786625d05f64
    786625d05f50:	shr    rax,0x35
    786625d05f54:	sub    eax,0x201
    786625d05f59:	cmp    eax,0x3fc
    786625d05f5e:	ja     0x786625d07fc9
    786625d05f64:	mulpd  xmm0,xmm1
    786625d05f68:	movdqa xmm4,xmm0
    786625d05f6c:	movdqa xmm0,xmm4
    786625d05f70:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d05f7a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d05f84:	movdqa xmm2,xmm0
    786625d05f88:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625d05f92:	movdqa xmm3,xmm0
    786625d05f96:	movdqa xmm0,xmm2
    786625d05f9a:	movdqa xmm1,xmm3
    786625d05f9e:	movq   rax,xmm0
    786625d05fa3:	add    rax,rax
    786625d05fa6:	je     0x786625d05fbc
    786625d05fa8:	shr    rax,0x35
    786625d05fac:	sub    eax,0x201
    786625d05fb1:	cmp    eax,0x3fc
    786625d05fb6:	ja     0x786625d07fed
    786625d05fbc:	movdqa xmm14,xmm0
    786625d05fc1:	psrldq xmm14,0x8
    786625d05fc7:	movq   rax,xmm14
    786625d05fcc:	add    rax,rax
    786625d05fcf:	je     0x786625d05fe5
    786625d05fd1:	shr    rax,0x35
    786625d05fd5:	sub    eax,0x201
    786625d05fda:	cmp    eax,0x3fc
    786625d05fdf:	ja     0x786625d07fed
    786625d05fe5:	movq   rax,xmm1
    786625d05fea:	add    rax,rax
    786625d05fed:	je     0x786625d06003
    786625d05fef:	shr    rax,0x35
    786625d05ff3:	sub    eax,0x201
    786625d05ff8:	cmp    eax,0x3fc
    786625d05ffd:	ja     0x786625d07fed
    786625d06003:	movdqa xmm14,xmm1
    786625d06008:	psrldq xmm14,0x8
    786625d0600e:	movq   rax,xmm14
    786625d06013:	add    rax,rax
    786625d06016:	je     0x786625d0602c
    786625d06018:	shr    rax,0x35
    786625d0601c:	sub    eax,0x201
    786625d06021:	cmp    eax,0x3fc
    786625d06026:	ja     0x786625d07fed
    786625d0602c:	addpd  xmm0,xmm1
    786625d06030:	movdqa xmm4,xmm0
    786625d06034:	movdqa xmm0,xmm4
    786625d06038:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d06042:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    786625d0604c:	movdqa xmm2,xmm0
    786625d06050:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    786625d0605a:	movdqa xmm3,xmm0
    786625d0605e:	movdqa xmm0,xmm2
    786625d06062:	movdqa xmm1,xmm3
    786625d06066:	movq   rax,xmm0
    786625d0606b:	add    rax,rax
    786625d0606e:	je     0x786625d06084
    786625d06070:	shr    rax,0x35
    786625d06074:	sub    eax,0x201
    786625d06079:	cmp    eax,0x3fc
    786625d0607e:	ja     0x786625d08011
    786625d06084:	movdqa xmm14,xmm0
    786625d06089:	psrldq xmm14,0x8
    786625d0608f:	movq   rax,xmm14
    786625d06094:	add    rax,rax
    786625d06097:	je     0x786625d060ad
    786625d06099:	shr    rax,0x35
    786625d0609d:	sub    eax,0x201
    786625d060a2:	cmp    eax,0x3fc
    786625d060a7:	ja     0x786625d08011
    786625d060ad:	movq   rax,xmm1
    786625d060b2:	add    rax,rax
    786625d060b5:	je     0x786625d060cb
    786625d060b7:	shr    rax,0x35
    786625d060bb:	sub    eax,0x201
    786625d060c0:	cmp    eax,0x3fc
    786625d060c5:	ja     0x786625d08011
    786625d060cb:	movdqa xmm14,xmm1
    786625d060d0:	psrldq xmm14,0x8
    786625d060d6:	movq   rax,xmm14
    786625d060db:	add    rax,rax
    786625d060de:	je     0x786625d060f4
    786625d060e0:	shr    rax,0x35
    786625d060e4:	sub    eax,0x201
    786625d060e9:	cmp    eax,0x3fc
    786625d060ee:	ja     0x786625d08011
    786625d060f4:	addpd  xmm0,xmm1
    786625d060f8:	movdqa xmm4,xmm0
    786625d060fc:	movdqa xmm0,xmm4
    786625d06100:	movdqu XMMWORD PTR [r12+0x230],xmm0
    786625d0610a:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    786625d06114:	movdqa xmm2,xmm0
    786625d06118:	movdqa xmm1,xmm2
    786625d0611c:	por    xmm2,xmm1
    786625d06120:	movdqa xmm0,xmm2
    786625d06124:	movdqu XMMWORD PTR [r12+0x250],xmm0
    786625d0612e:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    786625d06138:	movdqa xmm2,xmm0
    786625d0613c:	movdqa xmm1,xmm2
    786625d06140:	por    xmm2,xmm1
    786625d06144:	movdqa xmm0,xmm2
    786625d06148:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    786625d06152:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    786625d0615c:	movdqa xmm2,xmm0
    786625d06160:	movdqa xmm1,xmm2
    786625d06164:	por    xmm2,xmm1
    786625d06168:	movdqa xmm0,xmm2
    786625d0616c:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    786625d06176:	mov    r13,QWORD PTR [r12+0xf8]
    786625d0617e:	add    r13,0x40
    786625d06182:	stmxcsr DWORD PTR [rsp+0x114]
    786625d0618a:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d06192:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d0619a:	shr    r11d,1
    786625d0619d:	and    r11d,0x10
    786625d061a1:	or     DWORD PTR [r12+0x314],r11d
    786625d061a9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d061af:	movdqa xmm0,xmm2
    786625d061b3:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    786625d061bd:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    786625d061c7:	movdqa xmm2,xmm0
    786625d061cb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625d061d5:	movdqa xmm3,xmm0
    786625d061d9:	stmxcsr DWORD PTR [rsp+0x110]
    786625d061e1:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d061ec:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d061f4:	movdqa xmm0,xmm2
    786625d061f8:	movdqa xmm1,xmm3
    786625d061fc:	pshufd xmm1,xmm1,0x44
    786625d06201:	movq   rax,xmm0
    786625d06206:	add    rax,rax
    786625d06209:	je     0x786625d0621f
    786625d0620b:	shr    rax,0x35
    786625d0620f:	sub    eax,0x201
    786625d06214:	cmp    eax,0x3fc
    786625d06219:	ja     0x786625d08035
    786625d0621f:	movdqa xmm14,xmm0
    786625d06224:	psrldq xmm14,0x8
    786625d0622a:	movq   rax,xmm14
    786625d0622f:	add    rax,rax
    786625d06232:	je     0x786625d06248
    786625d06234:	shr    rax,0x35
    786625d06238:	sub    eax,0x201
    786625d0623d:	cmp    eax,0x3fc
    786625d06242:	ja     0x786625d08035
    786625d06248:	movq   rax,xmm1
    786625d0624d:	add    rax,rax
    786625d06250:	je     0x786625d06266
    786625d06252:	shr    rax,0x35
    786625d06256:	sub    eax,0x201
    786625d0625b:	cmp    eax,0x3fc
    786625d06260:	ja     0x786625d08035
    786625d06266:	movdqa xmm14,xmm1
    786625d0626b:	psrldq xmm14,0x8
    786625d06271:	movq   rax,xmm14
    786625d06276:	add    rax,rax
    786625d06279:	je     0x786625d0628f
    786625d0627b:	shr    rax,0x35
    786625d0627f:	sub    eax,0x201
    786625d06284:	cmp    eax,0x3fc
    786625d06289:	ja     0x786625d08035
    786625d0628f:	mulpd  xmm0,xmm1
    786625d06293:	movdqa xmm4,xmm0
    786625d06297:	movdqa xmm0,xmm4
    786625d0629b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d062a5:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d062af:	movdqa xmm2,xmm0
    786625d062b3:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625d062bd:	movdqa xmm4,xmm0
    786625d062c1:	movdqa xmm0,xmm2
    786625d062c5:	movdqa xmm1,xmm4
    786625d062c9:	movq   rax,xmm0
    786625d062ce:	add    rax,rax
    786625d062d1:	je     0x786625d062e7
    786625d062d3:	shr    rax,0x35
    786625d062d7:	sub    eax,0x201
    786625d062dc:	cmp    eax,0x3fc
    786625d062e1:	ja     0x786625d08059
    786625d062e7:	movdqa xmm14,xmm0
    786625d062ec:	psrldq xmm14,0x8
    786625d062f2:	movq   rax,xmm14
    786625d062f7:	add    rax,rax
    786625d062fa:	je     0x786625d06310
    786625d062fc:	shr    rax,0x35
    786625d06300:	sub    eax,0x201
    786625d06305:	cmp    eax,0x3fc
    786625d0630a:	ja     0x786625d08059
    786625d06310:	movq   rax,xmm1
    786625d06315:	add    rax,rax
    786625d06318:	je     0x786625d0632e
    786625d0631a:	shr    rax,0x35
    786625d0631e:	sub    eax,0x201
    786625d06323:	cmp    eax,0x3fc
    786625d06328:	ja     0x786625d08059
    786625d0632e:	movdqa xmm14,xmm1
    786625d06333:	psrldq xmm14,0x8
    786625d06339:	movq   rax,xmm14
    786625d0633e:	add    rax,rax
    786625d06341:	je     0x786625d06357
    786625d06343:	shr    rax,0x35
    786625d06347:	sub    eax,0x201
    786625d0634c:	cmp    eax,0x3fc
    786625d06351:	ja     0x786625d08059
    786625d06357:	addpd  xmm0,xmm1
    786625d0635b:	movdqa xmm5,xmm0
    786625d0635f:	movdqa xmm0,xmm5
    786625d06363:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625d0636d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d06377:	movdqa xmm2,xmm0
    786625d0637b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d06385:	movdqa xmm4,xmm0
    786625d06389:	movdqa xmm0,xmm2
    786625d0638d:	movdqa xmm1,xmm4
    786625d06391:	movq   rax,xmm0
    786625d06396:	add    rax,rax
    786625d06399:	je     0x786625d063af
    786625d0639b:	shr    rax,0x35
    786625d0639f:	sub    eax,0x201
    786625d063a4:	cmp    eax,0x3fc
    786625d063a9:	ja     0x786625d0807d
    786625d063af:	movdqa xmm14,xmm0
    786625d063b4:	psrldq xmm14,0x8
    786625d063ba:	movq   rax,xmm14
    786625d063bf:	add    rax,rax
    786625d063c2:	je     0x786625d063d8
    786625d063c4:	shr    rax,0x35
    786625d063c8:	sub    eax,0x201
    786625d063cd:	cmp    eax,0x3fc
    786625d063d2:	ja     0x786625d0807d
    786625d063d8:	movq   rax,xmm1
    786625d063dd:	add    rax,rax
    786625d063e0:	je     0x786625d063f6
    786625d063e2:	shr    rax,0x35
    786625d063e6:	sub    eax,0x201
    786625d063eb:	cmp    eax,0x3fc
    786625d063f0:	ja     0x786625d0807d
    786625d063f6:	movdqa xmm14,xmm1
    786625d063fb:	psrldq xmm14,0x8
    786625d06401:	movq   rax,xmm14
    786625d06406:	add    rax,rax
    786625d06409:	je     0x786625d0641f
    786625d0640b:	shr    rax,0x35
    786625d0640f:	sub    eax,0x201
    786625d06414:	cmp    eax,0x3fc
    786625d06419:	ja     0x786625d0807d
    786625d0641f:	addpd  xmm0,xmm1
    786625d06423:	movdqa xmm5,xmm0
    786625d06427:	movdqa xmm0,xmm5
    786625d0642b:	movdqu XMMWORD PTR [r12+0x160],xmm0
    786625d06435:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    786625d0643f:	movdqa xmm2,xmm0
    786625d06443:	movdqa xmm0,xmm2
    786625d06447:	movdqa xmm1,xmm3
    786625d0644b:	pshufd xmm1,xmm1,0x44
    786625d06450:	movq   rax,xmm0
    786625d06455:	add    rax,rax
    786625d06458:	je     0x786625d0646e
    786625d0645a:	shr    rax,0x35
    786625d0645e:	sub    eax,0x201
    786625d06463:	cmp    eax,0x3fc
    786625d06468:	ja     0x786625d080a1
    786625d0646e:	movdqa xmm14,xmm0
    786625d06473:	psrldq xmm14,0x8
    786625d06479:	movq   rax,xmm14
    786625d0647e:	add    rax,rax
    786625d06481:	je     0x786625d06497
    786625d06483:	shr    rax,0x35
    786625d06487:	sub    eax,0x201
    786625d0648c:	cmp    eax,0x3fc
    786625d06491:	ja     0x786625d080a1
    786625d06497:	movq   rax,xmm1
    786625d0649c:	add    rax,rax
    786625d0649f:	je     0x786625d064b5
    786625d064a1:	shr    rax,0x35
    786625d064a5:	sub    eax,0x201
    786625d064aa:	cmp    eax,0x3fc
    786625d064af:	ja     0x786625d080a1
    786625d064b5:	movdqa xmm14,xmm1
    786625d064ba:	psrldq xmm14,0x8
    786625d064c0:	movq   rax,xmm14
    786625d064c5:	add    rax,rax
    786625d064c8:	je     0x786625d064de
    786625d064ca:	shr    rax,0x35
    786625d064ce:	sub    eax,0x201
    786625d064d3:	cmp    eax,0x3fc
    786625d064d8:	ja     0x786625d080a1
    786625d064de:	mulpd  xmm0,xmm1
    786625d064e2:	movdqa xmm4,xmm0
    786625d064e6:	movdqa xmm0,xmm4
    786625d064ea:	movdqu XMMWORD PTR [r12+0x240],xmm0
    786625d064f4:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    786625d064fe:	movdqa xmm2,xmm0
    786625d06502:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625d0650c:	movdqa xmm3,xmm0
    786625d06510:	movdqa xmm0,xmm2
    786625d06514:	movdqa xmm1,xmm3
    786625d06518:	pshufd xmm1,xmm1,0x44
    786625d0651d:	movq   rax,xmm0
    786625d06522:	add    rax,rax
    786625d06525:	je     0x786625d0653b
    786625d06527:	shr    rax,0x35
    786625d0652b:	sub    eax,0x201
    786625d06530:	cmp    eax,0x3fc
    786625d06535:	ja     0x786625d080c5
    786625d0653b:	movdqa xmm14,xmm0
    786625d06540:	psrldq xmm14,0x8
    786625d06546:	movq   rax,xmm14
    786625d0654b:	add    rax,rax
    786625d0654e:	je     0x786625d06564
    786625d06550:	shr    rax,0x35
    786625d06554:	sub    eax,0x201
    786625d06559:	cmp    eax,0x3fc
    786625d0655e:	ja     0x786625d080c5
    786625d06564:	movq   rax,xmm1
    786625d06569:	add    rax,rax
    786625d0656c:	je     0x786625d06582
    786625d0656e:	shr    rax,0x35
    786625d06572:	sub    eax,0x201
    786625d06577:	cmp    eax,0x3fc
    786625d0657c:	ja     0x786625d080c5
    786625d06582:	movdqa xmm14,xmm1
    786625d06587:	psrldq xmm14,0x8
    786625d0658d:	movq   rax,xmm14
    786625d06592:	add    rax,rax
    786625d06595:	je     0x786625d065ab
    786625d06597:	shr    rax,0x35
    786625d0659b:	sub    eax,0x201
    786625d065a0:	cmp    eax,0x3fc
    786625d065a5:	ja     0x786625d080c5
    786625d065ab:	mulpd  xmm0,xmm1
    786625d065af:	movdqa xmm4,xmm0
    786625d065b3:	movdqa xmm0,xmm4
    786625d065b7:	movdqu XMMWORD PTR [r12+0x140],xmm0
    786625d065c1:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    786625d065cb:	movdqa xmm2,xmm0
    786625d065cf:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625d065d9:	movdqa xmm3,xmm0
    786625d065dd:	movdqa xmm0,xmm2
    786625d065e1:	movdqa xmm1,xmm3
    786625d065e5:	pshufd xmm1,xmm1,0x44
    786625d065ea:	movq   rax,xmm0
    786625d065ef:	add    rax,rax
    786625d065f2:	je     0x786625d06608
    786625d065f4:	shr    rax,0x35
    786625d065f8:	sub    eax,0x201
    786625d065fd:	cmp    eax,0x3fc
    786625d06602:	ja     0x786625d080e9
    786625d06608:	movdqa xmm14,xmm0
    786625d0660d:	psrldq xmm14,0x8
    786625d06613:	movq   rax,xmm14
    786625d06618:	add    rax,rax
    786625d0661b:	je     0x786625d06631
    786625d0661d:	shr    rax,0x35
    786625d06621:	sub    eax,0x201
    786625d06626:	cmp    eax,0x3fc
    786625d0662b:	ja     0x786625d080e9
    786625d06631:	movq   rax,xmm1
    786625d06636:	add    rax,rax
    786625d06639:	je     0x786625d0664f
    786625d0663b:	shr    rax,0x35
    786625d0663f:	sub    eax,0x201
    786625d06644:	cmp    eax,0x3fc
    786625d06649:	ja     0x786625d080e9
    786625d0664f:	movdqa xmm14,xmm1
    786625d06654:	psrldq xmm14,0x8
    786625d0665a:	movq   rax,xmm14
    786625d0665f:	add    rax,rax
    786625d06662:	je     0x786625d06678
    786625d06664:	shr    rax,0x35
    786625d06668:	sub    eax,0x201
    786625d0666d:	cmp    eax,0x3fc
    786625d06672:	ja     0x786625d080e9
    786625d06678:	mulpd  xmm0,xmm1
    786625d0667c:	movdqa xmm4,xmm0
    786625d06680:	movdqa xmm0,xmm4
    786625d06684:	movdqu XMMWORD PTR [r12+0x170],xmm0
    786625d0668e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d06698:	movdqa xmm2,xmm0
    786625d0669c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d066a6:	movdqa xmm4,xmm0
    786625d066aa:	movdqa xmm0,xmm2
    786625d066ae:	movdqa xmm1,xmm4
    786625d066b2:	movq   rax,xmm0
    786625d066b7:	add    rax,rax
    786625d066ba:	je     0x786625d066d0
    786625d066bc:	shr    rax,0x35
    786625d066c0:	sub    eax,0x201
    786625d066c5:	cmp    eax,0x3fc
    786625d066ca:	ja     0x786625d0810d
    786625d066d0:	movdqa xmm14,xmm0
    786625d066d5:	psrldq xmm14,0x8
    786625d066db:	movq   rax,xmm14
    786625d066e0:	add    rax,rax
    786625d066e3:	je     0x786625d066f9
    786625d066e5:	shr    rax,0x35
    786625d066e9:	sub    eax,0x201
    786625d066ee:	cmp    eax,0x3fc
    786625d066f3:	ja     0x786625d0810d
    786625d066f9:	movq   rax,xmm1
    786625d066fe:	add    rax,rax
    786625d06701:	je     0x786625d06717
    786625d06703:	shr    rax,0x35
    786625d06707:	sub    eax,0x201
    786625d0670c:	cmp    eax,0x3fc
    786625d06711:	ja     0x786625d0810d
    786625d06717:	movdqa xmm14,xmm1
    786625d0671c:	psrldq xmm14,0x8
    786625d06722:	movq   rax,xmm14
    786625d06727:	add    rax,rax
    786625d0672a:	je     0x786625d06740
    786625d0672c:	shr    rax,0x35
    786625d06730:	sub    eax,0x201
    786625d06735:	cmp    eax,0x3fc
    786625d0673a:	ja     0x786625d0810d
    786625d06740:	addpd  xmm0,xmm1
    786625d06744:	movdqa xmm5,xmm0
    786625d06748:	movdqa xmm0,xmm5
    786625d0674c:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d06756:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d06760:	movdqa xmm2,xmm0
    786625d06764:	movdqa xmm0,xmm2
    786625d06768:	movdqa xmm1,xmm3
    786625d0676c:	pshufd xmm1,xmm1,0x44
    786625d06771:	movq   rax,xmm0
    786625d06776:	add    rax,rax
    786625d06779:	je     0x786625d0678f
    786625d0677b:	shr    rax,0x35
    786625d0677f:	sub    eax,0x201
    786625d06784:	cmp    eax,0x3fc
    786625d06789:	ja     0x786625d08131
    786625d0678f:	movdqa xmm14,xmm0
    786625d06794:	psrldq xmm14,0x8
    786625d0679a:	movq   rax,xmm14
    786625d0679f:	add    rax,rax
    786625d067a2:	je     0x786625d067b8
    786625d067a4:	shr    rax,0x35
    786625d067a8:	sub    eax,0x201
    786625d067ad:	cmp    eax,0x3fc
    786625d067b2:	ja     0x786625d08131
    786625d067b8:	movq   rax,xmm1
    786625d067bd:	add    rax,rax
    786625d067c0:	je     0x786625d067d6
    786625d067c2:	shr    rax,0x35
    786625d067c6:	sub    eax,0x201
    786625d067cb:	cmp    eax,0x3fc
    786625d067d0:	ja     0x786625d08131
    786625d067d6:	movdqa xmm14,xmm1
    786625d067db:	psrldq xmm14,0x8
    786625d067e1:	movq   rax,xmm14
    786625d067e6:	add    rax,rax
    786625d067e9:	je     0x786625d067ff
    786625d067eb:	shr    rax,0x35
    786625d067ef:	sub    eax,0x201
    786625d067f4:	cmp    eax,0x3fc
    786625d067f9:	ja     0x786625d08131
    786625d067ff:	mulpd  xmm0,xmm1
    786625d06803:	movdqa xmm4,xmm0
    786625d06807:	movdqa xmm0,xmm4
    786625d0680b:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d06815:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625d0681f:	movdqa xmm2,xmm0
    786625d06823:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    786625d0682d:	movdqa xmm4,xmm0
    786625d06831:	movdqa xmm0,xmm2
    786625d06835:	movdqa xmm1,xmm4
    786625d06839:	movq   rax,xmm0
    786625d0683e:	add    rax,rax
    786625d06841:	je     0x786625d06857
    786625d06843:	shr    rax,0x35
    786625d06847:	sub    eax,0x201
    786625d0684c:	cmp    eax,0x3fc
    786625d06851:	ja     0x786625d08155
    786625d06857:	movdqa xmm14,xmm0
    786625d0685c:	psrldq xmm14,0x8
    786625d06862:	movq   rax,xmm14
    786625d06867:	add    rax,rax
    786625d0686a:	je     0x786625d06880
    786625d0686c:	shr    rax,0x35
    786625d06870:	sub    eax,0x201
    786625d06875:	cmp    eax,0x3fc
    786625d0687a:	ja     0x786625d08155
    786625d06880:	movq   rax,xmm1
    786625d06885:	add    rax,rax
    786625d06888:	je     0x786625d0689e
    786625d0688a:	shr    rax,0x35
    786625d0688e:	sub    eax,0x201
    786625d06893:	cmp    eax,0x3fc
    786625d06898:	ja     0x786625d08155
    786625d0689e:	movdqa xmm14,xmm1
    786625d068a3:	psrldq xmm14,0x8
    786625d068a9:	movq   rax,xmm14
    786625d068ae:	add    rax,rax
    786625d068b1:	je     0x786625d068c7
    786625d068b3:	shr    rax,0x35
    786625d068b7:	sub    eax,0x201
    786625d068bc:	cmp    eax,0x3fc
    786625d068c1:	ja     0x786625d08155
    786625d068c7:	addpd  xmm0,xmm1
    786625d068cb:	movdqa xmm5,xmm0
    786625d068cf:	movdqa xmm0,xmm5
    786625d068d3:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d068dd:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    786625d068e7:	movdqa xmm2,xmm0
    786625d068eb:	movdqa xmm0,xmm2
    786625d068ef:	movdqa xmm1,xmm3
    786625d068f3:	pshufd xmm1,xmm1,0x44
    786625d068f8:	movq   rax,xmm0
    786625d068fd:	add    rax,rax
    786625d06900:	je     0x786625d06916
    786625d06902:	shr    rax,0x35
    786625d06906:	sub    eax,0x201
    786625d0690b:	cmp    eax,0x3fc
    786625d06910:	ja     0x786625d08179
    786625d06916:	movdqa xmm14,xmm0
    786625d0691b:	psrldq xmm14,0x8
    786625d06921:	movq   rax,xmm14
    786625d06926:	add    rax,rax
    786625d06929:	je     0x786625d0693f
    786625d0692b:	shr    rax,0x35
    786625d0692f:	sub    eax,0x201
    786625d06934:	cmp    eax,0x3fc
    786625d06939:	ja     0x786625d08179
    786625d0693f:	movq   rax,xmm1
    786625d06944:	add    rax,rax
    786625d06947:	je     0x786625d0695d
    786625d06949:	shr    rax,0x35
    786625d0694d:	sub    eax,0x201
    786625d06952:	cmp    eax,0x3fc
    786625d06957:	ja     0x786625d08179
    786625d0695d:	movdqa xmm14,xmm1
    786625d06962:	psrldq xmm14,0x8
    786625d06968:	movq   rax,xmm14
    786625d0696d:	add    rax,rax
    786625d06970:	je     0x786625d06986
    786625d06972:	shr    rax,0x35
    786625d06976:	sub    eax,0x201
    786625d0697b:	cmp    eax,0x3fc
    786625d06980:	ja     0x786625d08179
    786625d06986:	mulpd  xmm0,xmm1
    786625d0698a:	movdqa xmm4,xmm0
    786625d0698e:	movdqa xmm0,xmm4
    786625d06992:	movdqu XMMWORD PTR [r12+0x230],xmm0
    786625d0699c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625d069a6:	movdqa xmm2,xmm0
    786625d069aa:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625d069b4:	movdqa xmm3,xmm0
    786625d069b8:	movdqa xmm0,xmm2
    786625d069bc:	movdqa xmm1,xmm3
    786625d069c0:	movq   rax,xmm0
    786625d069c5:	add    rax,rax
    786625d069c8:	je     0x786625d069de
    786625d069ca:	shr    rax,0x35
    786625d069ce:	sub    eax,0x201
    786625d069d3:	cmp    eax,0x3fc
    786625d069d8:	ja     0x786625d0819d
    786625d069de:	movdqa xmm14,xmm0
    786625d069e3:	psrldq xmm14,0x8
    786625d069e9:	movq   rax,xmm14
    786625d069ee:	add    rax,rax
    786625d069f1:	je     0x786625d06a07
    786625d069f3:	shr    rax,0x35
    786625d069f7:	sub    eax,0x201
    786625d069fc:	cmp    eax,0x3fc
    786625d06a01:	ja     0x786625d0819d
    786625d06a07:	movq   rax,xmm1
    786625d06a0c:	add    rax,rax
    786625d06a0f:	je     0x786625d06a25
    786625d06a11:	shr    rax,0x35
    786625d06a15:	sub    eax,0x201
    786625d06a1a:	cmp    eax,0x3fc
    786625d06a1f:	ja     0x786625d0819d
    786625d06a25:	movdqa xmm14,xmm1
    786625d06a2a:	psrldq xmm14,0x8
    786625d06a30:	movq   rax,xmm14
    786625d06a35:	add    rax,rax
    786625d06a38:	je     0x786625d06a4e
    786625d06a3a:	shr    rax,0x35
    786625d06a3e:	sub    eax,0x201
    786625d06a43:	cmp    eax,0x3fc
    786625d06a48:	ja     0x786625d0819d
    786625d06a4e:	addpd  xmm0,xmm1
    786625d06a52:	movdqa xmm4,xmm0
    786625d06a56:	movdqa xmm0,xmm4
    786625d06a5a:	movdqu XMMWORD PTR [r12+0x140],xmm0
    786625d06a64:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    786625d06a6e:	movdqa xmm2,xmm0
    786625d06a72:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625d06a7c:	movdqa xmm3,xmm0
    786625d06a80:	movdqa xmm0,xmm2
    786625d06a84:	movdqa xmm1,xmm3
    786625d06a88:	pshufd xmm1,xmm1,0x44
    786625d06a8d:	movq   rax,xmm0
    786625d06a92:	add    rax,rax
    786625d06a95:	je     0x786625d06aab
    786625d06a97:	shr    rax,0x35
    786625d06a9b:	sub    eax,0x201
    786625d06aa0:	cmp    eax,0x3fc
    786625d06aa5:	ja     0x786625d081c1
    786625d06aab:	movdqa xmm14,xmm0
    786625d06ab0:	psrldq xmm14,0x8
    786625d06ab6:	movq   rax,xmm14
    786625d06abb:	add    rax,rax
    786625d06abe:	je     0x786625d06ad4
    786625d06ac0:	shr    rax,0x35
    786625d06ac4:	sub    eax,0x201
    786625d06ac9:	cmp    eax,0x3fc
    786625d06ace:	ja     0x786625d081c1
    786625d06ad4:	movq   rax,xmm1
    786625d06ad9:	add    rax,rax
    786625d06adc:	je     0x786625d06af2
    786625d06ade:	shr    rax,0x35
    786625d06ae2:	sub    eax,0x201
    786625d06ae7:	cmp    eax,0x3fc
    786625d06aec:	ja     0x786625d081c1
    786625d06af2:	movdqa xmm14,xmm1
    786625d06af7:	psrldq xmm14,0x8
    786625d06afd:	movq   rax,xmm14
    786625d06b02:	add    rax,rax
    786625d06b05:	je     0x786625d06b1b
    786625d06b07:	shr    rax,0x35
    786625d06b0b:	sub    eax,0x201
    786625d06b10:	cmp    eax,0x3fc
    786625d06b15:	ja     0x786625d081c1
    786625d06b1b:	mulpd  xmm0,xmm1
    786625d06b1f:	movdqa xmm4,xmm0
    786625d06b23:	movdqa xmm0,xmm4
    786625d06b27:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625d06b31:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d06b3b:	movdqa xmm2,xmm0
    786625d06b3f:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d06b49:	movdqa xmm3,xmm0
    786625d06b4d:	movdqa xmm0,xmm2
    786625d06b51:	movdqa xmm1,xmm3
    786625d06b55:	movq   rax,xmm0
    786625d06b5a:	add    rax,rax
    786625d06b5d:	je     0x786625d06b73
    786625d06b5f:	shr    rax,0x35
    786625d06b63:	sub    eax,0x201
    786625d06b68:	cmp    eax,0x3fc
    786625d06b6d:	ja     0x786625d081e5
    786625d06b73:	movdqa xmm14,xmm0
    786625d06b78:	psrldq xmm14,0x8
    786625d06b7e:	movq   rax,xmm14
    786625d06b83:	add    rax,rax
    786625d06b86:	je     0x786625d06b9c
    786625d06b88:	shr    rax,0x35
    786625d06b8c:	sub    eax,0x201
    786625d06b91:	cmp    eax,0x3fc
    786625d06b96:	ja     0x786625d081e5
    786625d06b9c:	movq   rax,xmm1
    786625d06ba1:	add    rax,rax
    786625d06ba4:	je     0x786625d06bba
    786625d06ba6:	shr    rax,0x35
    786625d06baa:	sub    eax,0x201
    786625d06baf:	cmp    eax,0x3fc
    786625d06bb4:	ja     0x786625d081e5
    786625d06bba:	movdqa xmm14,xmm1
    786625d06bbf:	psrldq xmm14,0x8
    786625d06bc5:	movq   rax,xmm14
    786625d06bca:	add    rax,rax
    786625d06bcd:	je     0x786625d06be3
    786625d06bcf:	shr    rax,0x35
    786625d06bd3:	sub    eax,0x201
    786625d06bd8:	cmp    eax,0x3fc
    786625d06bdd:	ja     0x786625d081e5
    786625d06be3:	addpd  xmm0,xmm1
    786625d06be7:	movdqa xmm4,xmm0
    786625d06beb:	movdqa xmm0,xmm4
    786625d06bef:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625d06bf9:	mov    r13,QWORD PTR [r12+0xf8]
    786625d06c01:	mov    r14,r13
    786625d06c04:	add    r14,0x70
    786625d06c08:	stmxcsr DWORD PTR [rsp+0x114]
    786625d06c10:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d06c18:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d06c20:	shr    r11d,1
    786625d06c23:	and    r11d,0x10
    786625d06c27:	or     DWORD PTR [r12+0x314],r11d
    786625d06c2f:	movdqu xmm2,XMMWORD PTR [r14]
    786625d06c34:	movdqa xmm0,xmm2
    786625d06c38:	movdqu XMMWORD PTR [r12+0x240],xmm0
    786625d06c42:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d06c4c:	movdqa xmm3,xmm0
    786625d06c50:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d06c5a:	movdqa xmm4,xmm0
    786625d06c5e:	stmxcsr DWORD PTR [rsp+0x110]
    786625d06c66:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d06c71:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d06c79:	movdqa xmm0,xmm3
    786625d06c7d:	movdqa xmm1,xmm4
    786625d06c81:	movq   rax,xmm0
    786625d06c86:	add    rax,rax
    786625d06c89:	je     0x786625d06c9f
    786625d06c8b:	shr    rax,0x35
    786625d06c8f:	sub    eax,0x201
    786625d06c94:	cmp    eax,0x3fc
    786625d06c99:	ja     0x786625d08209
    786625d06c9f:	movdqa xmm14,xmm0
    786625d06ca4:	psrldq xmm14,0x8
    786625d06caa:	movq   rax,xmm14
    786625d06caf:	add    rax,rax
    786625d06cb2:	je     0x786625d06cc8
    786625d06cb4:	shr    rax,0x35
    786625d06cb8:	sub    eax,0x201
    786625d06cbd:	cmp    eax,0x3fc
    786625d06cc2:	ja     0x786625d08209
    786625d06cc8:	movq   rax,xmm1
    786625d06ccd:	add    rax,rax
    786625d06cd0:	je     0x786625d06ce6
    786625d06cd2:	shr    rax,0x35
    786625d06cd6:	sub    eax,0x201
    786625d06cdb:	cmp    eax,0x3fc
    786625d06ce0:	ja     0x786625d08209
    786625d06ce6:	movdqa xmm14,xmm1
    786625d06ceb:	psrldq xmm14,0x8
    786625d06cf1:	movq   rax,xmm14
    786625d06cf6:	add    rax,rax
    786625d06cf9:	je     0x786625d06d0f
    786625d06cfb:	shr    rax,0x35
    786625d06cff:	sub    eax,0x201
    786625d06d04:	cmp    eax,0x3fc
    786625d06d09:	ja     0x786625d08209
    786625d06d0f:	addpd  xmm0,xmm1
    786625d06d13:	movdqa xmm5,xmm0
    786625d06d17:	movdqa xmm0,xmm5
    786625d06d1b:	movdqu XMMWORD PTR [r12+0x170],xmm0
    786625d06d25:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    786625d06d2f:	movdqa xmm3,xmm0
    786625d06d33:	movdqa xmm0,xmm2
    786625d06d37:	movdqa xmm1,xmm3
    786625d06d3b:	pshufd xmm1,xmm1,0x44
    786625d06d40:	movq   rax,xmm0
    786625d06d45:	add    rax,rax
    786625d06d48:	je     0x786625d06d5e
    786625d06d4a:	shr    rax,0x35
    786625d06d4e:	sub    eax,0x201
    786625d06d53:	cmp    eax,0x3fc
    786625d06d58:	ja     0x786625d0822d
    786625d06d5e:	movdqa xmm14,xmm0
    786625d06d63:	psrldq xmm14,0x8
    786625d06d69:	movq   rax,xmm14
    786625d06d6e:	add    rax,rax
    786625d06d71:	je     0x786625d06d87
    786625d06d73:	shr    rax,0x35
    786625d06d77:	sub    eax,0x201
    786625d06d7c:	cmp    eax,0x3fc
    786625d06d81:	ja     0x786625d0822d
    786625d06d87:	movq   rax,xmm1
    786625d06d8c:	add    rax,rax
    786625d06d8f:	je     0x786625d06da5
    786625d06d91:	shr    rax,0x35
    786625d06d95:	sub    eax,0x201
    786625d06d9a:	cmp    eax,0x3fc
    786625d06d9f:	ja     0x786625d0822d
    786625d06da5:	movdqa xmm14,xmm1
    786625d06daa:	psrldq xmm14,0x8
    786625d06db0:	movq   rax,xmm14
    786625d06db5:	add    rax,rax
    786625d06db8:	je     0x786625d06dce
    786625d06dba:	shr    rax,0x35
    786625d06dbe:	sub    eax,0x201
    786625d06dc3:	cmp    eax,0x3fc
    786625d06dc8:	ja     0x786625d0822d
    786625d06dce:	mulpd  xmm0,xmm1
    786625d06dd2:	movdqa xmm4,xmm0
    786625d06dd6:	movdqa xmm0,xmm4
    786625d06dda:	movdqu XMMWORD PTR [r12+0x160],xmm0
    786625d06de4:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    786625d06dee:	movdqa xmm2,xmm0
    786625d06df2:	movdqa xmm0,xmm2
    786625d06df6:	movdqa xmm1,xmm3
    786625d06dfa:	pshufd xmm1,xmm1,0x44
    786625d06dff:	movq   rax,xmm0
    786625d06e04:	add    rax,rax
    786625d06e07:	je     0x786625d06e1d
    786625d06e09:	shr    rax,0x35
    786625d06e0d:	sub    eax,0x201
    786625d06e12:	cmp    eax,0x3fc
    786625d06e17:	ja     0x786625d08251
    786625d06e1d:	movdqa xmm14,xmm0
    786625d06e22:	psrldq xmm14,0x8
    786625d06e28:	movq   rax,xmm14
    786625d06e2d:	add    rax,rax
    786625d06e30:	je     0x786625d06e46
    786625d06e32:	shr    rax,0x35
    786625d06e36:	sub    eax,0x201
    786625d06e3b:	cmp    eax,0x3fc
    786625d06e40:	ja     0x786625d08251
    786625d06e46:	movq   rax,xmm1
    786625d06e4b:	add    rax,rax
    786625d06e4e:	je     0x786625d06e64
    786625d06e50:	shr    rax,0x35
    786625d06e54:	sub    eax,0x201
    786625d06e59:	cmp    eax,0x3fc
    786625d06e5e:	ja     0x786625d08251
    786625d06e64:	movdqa xmm14,xmm1
    786625d06e69:	psrldq xmm14,0x8
    786625d06e6f:	movq   rax,xmm14
    786625d06e74:	add    rax,rax
    786625d06e77:	je     0x786625d06e8d
    786625d06e79:	shr    rax,0x35
    786625d06e7d:	sub    eax,0x201
    786625d06e82:	cmp    eax,0x3fc
    786625d06e87:	ja     0x786625d08251
    786625d06e8d:	mulpd  xmm0,xmm1
    786625d06e91:	movdqa xmm4,xmm0
    786625d06e95:	movdqa xmm0,xmm4
    786625d06e99:	movdqu XMMWORD PTR [r12+0x180],xmm0
    786625d06ea3:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d06ead:	movdqa xmm2,xmm0
    786625d06eb1:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    786625d06ebb:	movdqa xmm4,xmm0
    786625d06ebf:	movdqa xmm0,xmm2
    786625d06ec3:	movdqa xmm1,xmm4
    786625d06ec7:	movq   rax,xmm0
    786625d06ecc:	add    rax,rax
    786625d06ecf:	je     0x786625d06ee5
    786625d06ed1:	shr    rax,0x35
    786625d06ed5:	sub    eax,0x201
    786625d06eda:	cmp    eax,0x3fc
    786625d06edf:	ja     0x786625d08275
    786625d06ee5:	movdqa xmm14,xmm0
    786625d06eea:	psrldq xmm14,0x8
    786625d06ef0:	movq   rax,xmm14
    786625d06ef5:	add    rax,rax
    786625d06ef8:	je     0x786625d06f0e
    786625d06efa:	shr    rax,0x35
    786625d06efe:	sub    eax,0x201
    786625d06f03:	cmp    eax,0x3fc
    786625d06f08:	ja     0x786625d08275
    786625d06f0e:	movq   rax,xmm1
    786625d06f13:	add    rax,rax
    786625d06f16:	je     0x786625d06f2c
    786625d06f18:	shr    rax,0x35
    786625d06f1c:	sub    eax,0x201
    786625d06f21:	cmp    eax,0x3fc
    786625d06f26:	ja     0x786625d08275
    786625d06f2c:	movdqa xmm14,xmm1
    786625d06f31:	psrldq xmm14,0x8
    786625d06f37:	movq   rax,xmm14
    786625d06f3c:	add    rax,rax
    786625d06f3f:	je     0x786625d06f55
    786625d06f41:	shr    rax,0x35
    786625d06f45:	sub    eax,0x201
    786625d06f4a:	cmp    eax,0x3fc
    786625d06f4f:	ja     0x786625d08275
    786625d06f55:	addpd  xmm0,xmm1
    786625d06f59:	movdqa xmm5,xmm0
    786625d06f5d:	movdqa xmm0,xmm5
    786625d06f61:	movdqu XMMWORD PTR [r12+0x210],xmm0
    786625d06f6b:	mov    r14,r13
    786625d06f6e:	add    r14,0x10
    786625d06f72:	stmxcsr DWORD PTR [rsp+0x114]
    786625d06f7a:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d06f82:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d06f8a:	shr    r11d,1
    786625d06f8d:	and    r11d,0x10
    786625d06f91:	or     DWORD PTR [r12+0x314],r11d
    786625d06f99:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    786625d06f9f:	movdqu xmm4,XMMWORD PTR [r14]
    786625d06fa4:	movdqa xmm0,xmm4
    786625d06fa8:	movdqu XMMWORD PTR [r12+0x230],xmm0
    786625d06fb2:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625d06fbc:	movdqa xmm5,xmm0
    786625d06fc0:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625d06fca:	movdqa xmm6,xmm0
    786625d06fce:	stmxcsr DWORD PTR [rsp+0x110]
    786625d06fd6:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d06fe1:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d06fe9:	movdqa xmm0,xmm5
    786625d06fed:	movdqa xmm1,xmm6
    786625d06ff1:	movq   rax,xmm0
    786625d06ff6:	add    rax,rax
    786625d06ff9:	je     0x786625d0700f
    786625d06ffb:	shr    rax,0x35
    786625d06fff:	sub    eax,0x201
    786625d07004:	cmp    eax,0x3fc
    786625d07009:	ja     0x786625d08299
    786625d0700f:	movdqa xmm14,xmm0
    786625d07014:	psrldq xmm14,0x8
    786625d0701a:	movq   rax,xmm14
    786625d0701f:	add    rax,rax
    786625d07022:	je     0x786625d07038
    786625d07024:	shr    rax,0x35
    786625d07028:	sub    eax,0x201
    786625d0702d:	cmp    eax,0x3fc
    786625d07032:	ja     0x786625d08299
    786625d07038:	movq   rax,xmm1
    786625d0703d:	add    rax,rax
    786625d07040:	je     0x786625d07056
    786625d07042:	shr    rax,0x35
    786625d07046:	sub    eax,0x201
    786625d0704b:	cmp    eax,0x3fc
    786625d07050:	ja     0x786625d08299
    786625d07056:	movdqa xmm14,xmm1
    786625d0705b:	psrldq xmm14,0x8
    786625d07061:	movq   rax,xmm14
    786625d07066:	add    rax,rax
    786625d07069:	je     0x786625d0707f
    786625d0706b:	shr    rax,0x35
    786625d0706f:	sub    eax,0x201
    786625d07074:	cmp    eax,0x3fc
    786625d07079:	ja     0x786625d08299
    786625d0707f:	addpd  xmm0,xmm1
    786625d07083:	movdqa xmm7,xmm0
    786625d07087:	movdqa xmm0,xmm7
    786625d0708b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    786625d07095:	movdqa xmm0,xmm4
    786625d07099:	movdqa xmm1,xmm3
    786625d0709d:	pshufd xmm1,xmm1,0x44
    786625d070a2:	movq   rax,xmm0
    786625d070a7:	add    rax,rax
    786625d070aa:	je     0x786625d070c0
    786625d070ac:	shr    rax,0x35
    786625d070b0:	sub    eax,0x201
    786625d070b5:	cmp    eax,0x3fc
    786625d070ba:	ja     0x786625d082bd
    786625d070c0:	movdqa xmm14,xmm0
    786625d070c5:	psrldq xmm14,0x8
    786625d070cb:	movq   rax,xmm14
    786625d070d0:	add    rax,rax
    786625d070d3:	je     0x786625d070e9
    786625d070d5:	shr    rax,0x35
    786625d070d9:	sub    eax,0x201
    786625d070de:	cmp    eax,0x3fc
    786625d070e3:	ja     0x786625d082bd
    786625d070e9:	movq   rax,xmm1
    786625d070ee:	add    rax,rax
    786625d070f1:	je     0x786625d07107
    786625d070f3:	shr    rax,0x35
    786625d070f7:	sub    eax,0x201
    786625d070fc:	cmp    eax,0x3fc
    786625d07101:	ja     0x786625d082bd
    786625d07107:	movdqa xmm14,xmm1
    786625d0710c:	psrldq xmm14,0x8
    786625d07112:	movq   rax,xmm14
    786625d07117:	add    rax,rax
    786625d0711a:	je     0x786625d07130
    786625d0711c:	shr    rax,0x35
    786625d07120:	sub    eax,0x201
    786625d07125:	cmp    eax,0x3fc
    786625d0712a:	ja     0x786625d082bd
    786625d07130:	mulpd  xmm0,xmm1
    786625d07134:	movdqa xmm5,xmm0
    786625d07138:	movdqa xmm0,xmm5
    786625d0713c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    786625d07146:	movdqa xmm0,xmm2
    786625d0714a:	movdqa xmm1,xmm3
    786625d0714e:	pshufd xmm1,xmm1,0x44
    786625d07153:	movq   rax,xmm0
    786625d07158:	add    rax,rax
    786625d0715b:	je     0x786625d07171
    786625d0715d:	shr    rax,0x35
    786625d07161:	sub    eax,0x201
    786625d07166:	cmp    eax,0x3fc
    786625d0716b:	ja     0x786625d082e1
    786625d07171:	movdqa xmm14,xmm0
    786625d07176:	psrldq xmm14,0x8
    786625d0717c:	movq   rax,xmm14
    786625d07181:	add    rax,rax
    786625d07184:	je     0x786625d0719a
    786625d07186:	shr    rax,0x35
    786625d0718a:	sub    eax,0x201
    786625d0718f:	cmp    eax,0x3fc
    786625d07194:	ja     0x786625d082e1
    786625d0719a:	movq   rax,xmm1
    786625d0719f:	add    rax,rax
    786625d071a2:	je     0x786625d071b8
    786625d071a4:	shr    rax,0x35
    786625d071a8:	sub    eax,0x201
    786625d071ad:	cmp    eax,0x3fc
    786625d071b2:	ja     0x786625d082e1
    786625d071b8:	movdqa xmm14,xmm1
    786625d071bd:	psrldq xmm14,0x8
    786625d071c3:	movq   rax,xmm14
    786625d071c8:	add    rax,rax
    786625d071cb:	je     0x786625d071e1
    786625d071cd:	shr    rax,0x35
    786625d071d1:	sub    eax,0x201
    786625d071d6:	cmp    eax,0x3fc
    786625d071db:	ja     0x786625d082e1
    786625d071e1:	mulpd  xmm0,xmm1
    786625d071e5:	movdqa xmm4,xmm0
    786625d071e9:	movdqa xmm0,xmm4
    786625d071ed:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d071f7:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625d07201:	movdqa xmm2,xmm0
    786625d07205:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d0720f:	movdqa xmm3,xmm0
    786625d07213:	movdqa xmm0,xmm2
    786625d07217:	movdqa xmm1,xmm3
    786625d0721b:	movq   rax,xmm0
    786625d07220:	add    rax,rax
    786625d07223:	je     0x786625d07239
    786625d07225:	shr    rax,0x35
    786625d07229:	sub    eax,0x201
    786625d0722e:	cmp    eax,0x3fc
    786625d07233:	ja     0x786625d08305
    786625d07239:	movdqa xmm14,xmm0
    786625d0723e:	psrldq xmm14,0x8
    786625d07244:	movq   rax,xmm14
    786625d07249:	add    rax,rax
    786625d0724c:	je     0x786625d07262
    786625d0724e:	shr    rax,0x35
    786625d07252:	sub    eax,0x201
    786625d07257:	cmp    eax,0x3fc
    786625d0725c:	ja     0x786625d08305
    786625d07262:	movq   rax,xmm1
    786625d07267:	add    rax,rax
    786625d0726a:	je     0x786625d07280
    786625d0726c:	shr    rax,0x35
    786625d07270:	sub    eax,0x201
    786625d07275:	cmp    eax,0x3fc
    786625d0727a:	ja     0x786625d08305
    786625d07280:	movdqa xmm14,xmm1
    786625d07285:	psrldq xmm14,0x8
    786625d0728b:	movq   rax,xmm14
    786625d07290:	add    rax,rax
    786625d07293:	je     0x786625d072a9
    786625d07295:	shr    rax,0x35
    786625d07299:	sub    eax,0x201
    786625d0729e:	cmp    eax,0x3fc
    786625d072a3:	ja     0x786625d08305
    786625d072a9:	addpd  xmm0,xmm1
    786625d072ad:	movdqa xmm4,xmm0
    786625d072b1:	movdqa xmm0,xmm4
    786625d072b5:	movdqu XMMWORD PTR [r12+0x140],xmm0
    786625d072bf:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    786625d072c9:	movdqa xmm2,xmm0
    786625d072cd:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    786625d072d7:	movdqa xmm3,xmm0
    786625d072db:	movdqa xmm0,xmm2
    786625d072df:	movdqa xmm1,xmm3
    786625d072e3:	movq   rax,xmm0
    786625d072e8:	add    rax,rax
    786625d072eb:	je     0x786625d07301
    786625d072ed:	shr    rax,0x35
    786625d072f1:	sub    eax,0x201
    786625d072f6:	cmp    eax,0x3fc
    786625d072fb:	ja     0x786625d08329
    786625d07301:	movdqa xmm14,xmm0
    786625d07306:	psrldq xmm14,0x8
    786625d0730c:	movq   rax,xmm14
    786625d07311:	add    rax,rax
    786625d07314:	je     0x786625d0732a
    786625d07316:	shr    rax,0x35
    786625d0731a:	sub    eax,0x201
    786625d0731f:	cmp    eax,0x3fc
    786625d07324:	ja     0x786625d08329
    786625d0732a:	movq   rax,xmm1
    786625d0732f:	add    rax,rax
    786625d07332:	je     0x786625d07348
    786625d07334:	shr    rax,0x35
    786625d07338:	sub    eax,0x201
    786625d0733d:	cmp    eax,0x3fc
    786625d07342:	ja     0x786625d08329
    786625d07348:	movdqa xmm14,xmm1
    786625d0734d:	psrldq xmm14,0x8
    786625d07353:	movq   rax,xmm14
    786625d07358:	add    rax,rax
    786625d0735b:	je     0x786625d07371
    786625d0735d:	shr    rax,0x35
    786625d07361:	sub    eax,0x201
    786625d07366:	cmp    eax,0x3fc
    786625d0736b:	ja     0x786625d08329
    786625d07371:	addpd  xmm0,xmm1
    786625d07375:	movdqa xmm4,xmm0
    786625d07379:	movdqa xmm0,xmm4
    786625d0737d:	movdqu XMMWORD PTR [r12+0x150],xmm0
    786625d07387:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    786625d07391:	movdqa xmm2,xmm0
    786625d07395:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    786625d0739f:	movdqa xmm3,xmm0
    786625d073a3:	movdqa xmm0,xmm2
    786625d073a7:	movdqa xmm1,xmm3
    786625d073ab:	movq   rax,xmm0
    786625d073b0:	add    rax,rax
    786625d073b3:	je     0x786625d073c9
    786625d073b5:	shr    rax,0x35
    786625d073b9:	sub    eax,0x201
    786625d073be:	cmp    eax,0x3fc
    786625d073c3:	ja     0x786625d0834d
    786625d073c9:	movdqa xmm14,xmm0
    786625d073ce:	psrldq xmm14,0x8
    786625d073d4:	movq   rax,xmm14
    786625d073d9:	add    rax,rax
    786625d073dc:	je     0x786625d073f2
    786625d073de:	shr    rax,0x35
    786625d073e2:	sub    eax,0x201
    786625d073e7:	cmp    eax,0x3fc
    786625d073ec:	ja     0x786625d0834d
    786625d073f2:	movq   rax,xmm1
    786625d073f7:	add    rax,rax
    786625d073fa:	je     0x786625d07410
    786625d073fc:	shr    rax,0x35
    786625d07400:	sub    eax,0x201
    786625d07405:	cmp    eax,0x3fc
    786625d0740a:	ja     0x786625d0834d
    786625d07410:	movdqa xmm14,xmm1
    786625d07415:	psrldq xmm14,0x8
    786625d0741b:	movq   rax,xmm14
    786625d07420:	add    rax,rax
    786625d07423:	je     0x786625d07439
    786625d07425:	shr    rax,0x35
    786625d07429:	sub    eax,0x201
    786625d0742e:	cmp    eax,0x3fc
    786625d07433:	ja     0x786625d0834d
    786625d07439:	addpd  xmm0,xmm1
    786625d0743d:	movdqa xmm4,xmm0
    786625d07441:	movdqa xmm0,xmm4
    786625d07445:	movdqu XMMWORD PTR [r12+0x160],xmm0
    786625d0744f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d07459:	movdqa xmm2,xmm0
    786625d0745d:	movdqa xmm0,xmm7
    786625d07461:	movdqa xmm1,xmm2
    786625d07465:	movq   rax,xmm0
    786625d0746a:	add    rax,rax
    786625d0746d:	je     0x786625d07483
    786625d0746f:	shr    rax,0x35
    786625d07473:	sub    eax,0x201
    786625d07478:	cmp    eax,0x3fc
    786625d0747d:	ja     0x786625d08371
    786625d07483:	movdqa xmm14,xmm0
    786625d07488:	psrldq xmm14,0x8
    786625d0748e:	movq   rax,xmm14
    786625d07493:	add    rax,rax
    786625d07496:	je     0x786625d074ac
    786625d07498:	shr    rax,0x35
    786625d0749c:	sub    eax,0x201
    786625d074a1:	cmp    eax,0x3fc
    786625d074a6:	ja     0x786625d08371
    786625d074ac:	movq   rax,xmm1
    786625d074b1:	add    rax,rax
    786625d074b4:	je     0x786625d074ca
    786625d074b6:	shr    rax,0x35
    786625d074ba:	sub    eax,0x201
    786625d074bf:	cmp    eax,0x3fc
    786625d074c4:	ja     0x786625d08371
    786625d074ca:	movdqa xmm14,xmm1
    786625d074cf:	psrldq xmm14,0x8
    786625d074d5:	movq   rax,xmm14
    786625d074da:	add    rax,rax
    786625d074dd:	je     0x786625d074f3
    786625d074df:	shr    rax,0x35
    786625d074e3:	sub    eax,0x201
    786625d074e8:	cmp    eax,0x3fc
    786625d074ed:	ja     0x786625d08371
    786625d074f3:	addpd  xmm0,xmm1
    786625d074f7:	movdqa xmm3,xmm0
    786625d074fb:	movdqa xmm0,xmm3
    786625d074ff:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d07509:	mov    r13,QWORD PTR [r12+0x60]
    786625d0750e:	mov    r14,r13
    786625d07511:	add    r14,0x10
    786625d07515:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    786625d0751f:	movdqa xmm2,xmm0
    786625d07523:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    786625d0752d:	movdqa xmm4,xmm0
    786625d07531:	stmxcsr DWORD PTR [rsp+0x114]
    786625d07539:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d07541:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d07549:	shr    r11d,1
    786625d0754c:	and    r11d,0x10
    786625d07550:	or     DWORD PTR [r12+0x314],r11d
    786625d07558:	movdqu XMMWORD PTR [r13+0x0],xmm2
    786625d0755e:	mov    r15d,0x0
    786625d07564:	mov    DWORD PTR [r12+0x32c],r15d
    786625d0756c:	movdqu XMMWORD PTR [r14],xmm4
    786625d07571:	mov    r14d,0x0
    786625d07577:	mov    DWORD PTR [r12+0x32c],r14d
    786625d0757f:	add    r13,0x20
    786625d07583:	mov    r14,r13
    786625d07586:	add    r14,0x10
    786625d0758a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    786625d07594:	movdqa xmm2,xmm0
    786625d07598:	movdqu XMMWORD PTR [r13+0x0],xmm2
    786625d0759e:	mov    r13d,0x0
    786625d075a4:	mov    DWORD PTR [r12+0x32c],r13d
    786625d075ac:	movdqu XMMWORD PTR [r14],xmm3
    786625d075b1:	mov    r13d,0x0
    786625d075b7:	mov    DWORD PTR [r12+0x32c],r13d
    786625d075bf:	mov    rcx,QWORD PTR [r12+0x380]
    786625d075c7:	jrcxz  0x786625d075ce
    786625d075c9:	jmp    0x786625d09cea
    786625d075ce:	push   QWORD PTR [rsp]
    786625d075d1:	popf
    786625d075d2:	je     0x786625d075dd
    786625d075d8:	jmp    0x786625d03a18
    786625d075dd:	mov    r13d,DWORD PTR [r12+0x48]
    786625d075e2:	add    r13d,0x1
    786625d075e6:	mov    QWORD PTR [r12+0x48],r13
    786625d075eb:	sub    r13d,0x1f4
    786625d075f2:	mov    rcx,QWORD PTR [r12+0x380]
    786625d075fa:	jrcxz  0x786625d07601
    786625d075fc:	jmp    0x786625d09d74
    786625d07601:	pushf
    786625d07602:	pop    r11
    786625d07604:	mov    QWORD PTR [rsp],r11
    786625d07608:	jne    0x786625d03a08
    786625d0760e:	jmp    0x786625d07613
    786625d07613:	mov    r13d,0x430000
    786625d07619:	mov    QWORD PTR [r12+0x40],r13
    786625d0761e:	mov    r13d,0x0
    786625d07624:	mov    QWORD PTR [r12+0x48],r13
    786625d07629:	mov    r13d,0x430cc0
    786625d0762f:	mov    r14,QWORD PTR [r13+0x0]
    786625d07633:	mov    r13d,0x0
    786625d07639:	mov    QWORD PTR [r12+0x110],r14
    786625d07641:	mov    QWORD PTR [r12+0x118],r13
    786625d07649:	jmp    0x786625d0764e
    786625d0764e:	mov    r13,QWORD PTR [r12+0x48]
    786625d07653:	mov    r14,QWORD PTR [r12+0x50]
    786625d07658:	mov    rcx,r13
    786625d0765b:	add    r14,rcx
    786625d0765e:	movdqu xmm2,XMMWORD PTR [r14]
    786625d07663:	movdqa xmm0,xmm2
    786625d07667:	movdqu XMMWORD PTR [r12+0x120],xmm0
    786625d07671:	add    r13,0x10
    786625d07675:	mov    QWORD PTR [r12+0x48],r13
    786625d0767a:	sub    r13,0x200
    786625d07681:	mov    r13,QWORD PTR [r12+0x128]
    786625d07689:	mov    r14d,0x0
    786625d0768f:	mov    QWORD PTR [r12+0x130],r13
    786625d07697:	mov    QWORD PTR [r12+0x138],r14
    786625d0769f:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    786625d076a9:	movdqa xmm2,xmm0
    786625d076ad:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    786625d076b7:	movdqa xmm3,xmm0
    786625d076bb:	pushf
    786625d076bc:	pop    r11
    786625d076be:	mov    QWORD PTR [rsp],r11
    786625d076c2:	stmxcsr DWORD PTR [rsp+0x110]
    786625d076ca:	mov    DWORD PTR [rsp+0x114],0x1f80
    786625d076d5:	ldmxcsr DWORD PTR [rsp+0x114]
    786625d076dd:	movdqa xmm0,xmm2
    786625d076e1:	movdqa xmm1,xmm3
    786625d076e5:	movq   rax,xmm0
    786625d076ea:	add    rax,rax
    786625d076ed:	je     0x786625d07703
    786625d076ef:	shr    rax,0x35
    786625d076f3:	sub    eax,0x201
    786625d076f8:	cmp    eax,0x3fc
    786625d076fd:	ja     0x786625d08395
    786625d07703:	movq   rax,xmm1
    786625d07708:	add    rax,rax
    786625d0770b:	je     0x786625d07721
    786625d0770d:	shr    rax,0x35
    786625d07711:	sub    eax,0x201
    786625d07716:	cmp    eax,0x3fc
    786625d0771b:	ja     0x786625d08395
    786625d07721:	movq   xmm0,xmm0
    786625d07725:	movq   xmm1,xmm1
    786625d07729:	addsd  xmm0,xmm1
    786625d0772d:	movdqa xmm4,xmm0
    786625d07731:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    786625d0773b:	movdqa xmm2,xmm0
    786625d0773f:	movdqa xmm0,xmm4
    786625d07743:	movdqa xmm1,xmm2
    786625d07747:	movq   rax,xmm0
    786625d0774c:	add    rax,rax
    786625d0774f:	je     0x786625d07765
    786625d07751:	shr    rax,0x35
    786625d07755:	sub    eax,0x201
    786625d0775a:	cmp    eax,0x3fc
    786625d0775f:	ja     0x786625d083b9
    786625d07765:	movq   rax,xmm1
    786625d0776a:	add    rax,rax
    786625d0776d:	je     0x786625d07783
    786625d0776f:	shr    rax,0x35
    786625d07773:	sub    eax,0x201
    786625d07778:	cmp    eax,0x3fc
    786625d0777d:	ja     0x786625d083b9
    786625d07783:	movq   xmm0,xmm0
    786625d07787:	movq   xmm1,xmm1
    786625d0778b:	addsd  xmm0,xmm1
    786625d0778f:	movdqa xmm3,xmm0
    786625d07793:	movdqa xmm0,xmm3
    786625d07797:	movdqu XMMWORD PTR [r12+0x110],xmm0
    786625d077a1:	stmxcsr DWORD PTR [rsp+0x114]
    786625d077a9:	ldmxcsr DWORD PTR [rsp+0x110]
    786625d077b1:	mov    r11d,DWORD PTR [rsp+0x114]
    786625d077b9:	shr    r11d,1
    786625d077bc:	and    r11d,0x10
    786625d077c0:	or     DWORD PTR [r12+0x314],r11d
    786625d077c8:	mov    rcx,QWORD PTR [r12+0x380]
    786625d077d0:	jrcxz  0x786625d077d7
    786625d077d2:	jmp    0x786625d09e06
    786625d077d7:	push   QWORD PTR [rsp]
    786625d077da:	popf
    786625d077db:	jne    0x786625d0764e
    786625d077e1:	jmp    0x786625d077e6
    786625d077e6:	mov    r13,QWORD PTR [r12+0xf8]
    786625d077ee:	mov    r14,r13
    786625d077f1:	add    r14,0x1d0
    786625d077f8:	mov    r15,r14
    786625d077fb:	add    r15,0x8
    786625d077ff:	mov    rbp,QWORD PTR [r14]
    786625d07802:	mov    r14,QWORD PTR [r15]
    786625d07805:	mov    QWORD PTR [r12+0xa0],rbp
    786625d0780d:	mov    QWORD PTR [r12+0x98],r14
    786625d07815:	mov    r14,QWORD PTR [r12+0x40]
    786625d0781a:	add    r14,0xcc0
    786625d07821:	mov    r15,QWORD PTR [r12+0x110]
    786625d07829:	mov    QWORD PTR [r14],r15
    786625d0782c:	mov    r14d,0x0
    786625d07832:	mov    DWORD PTR [r12+0x32c],r14d
    786625d0783a:	mov    r14,r13
    786625d0783d:	add    r14,0x1c0
    786625d07844:	mov    r15,r14
    786625d07847:	add    r15,0x8
    786625d0784b:	mov    rbp,QWORD PTR [r14]
    786625d0784e:	mov    r14,QWORD PTR [r15]
    786625d07851:	mov    QWORD PTR [r12+0xe8],rbp
    786625d07859:	mov    QWORD PTR [r12+0xf0],r14
    786625d07861:	add    r13,0x1b0
    786625d07868:	mov    r14,r13
    786625d0786b:	add    r14,0x8
    786625d0786f:	mov    r15,QWORD PTR [r13+0x0]
    786625d07873:	mov    r13,QWORD PTR [r14]
    786625d07876:	mov    r14d,0x0
    786625d0787c:	mov    QWORD PTR [r12+0x1a0],r15
    786625d07884:	mov    QWORD PTR [r12+0x1a8],r14
    786625d0788c:	mov    r14d,0x0
    786625d07892:	mov    QWORD PTR [r12+0x190],r13
    786625d0789a:	mov    QWORD PTR [r12+0x198],r14
    786625d078a2:	mov    r13,QWORD PTR [r12+0xf8]
    786625d078aa:	mov    r14,r13
    786625d078ad:	add    r14,0x1a0
    786625d078b4:	mov    r15,r14
    786625d078b7:	add    r15,0x8
    786625d078bb:	mov    rbp,QWORD PTR [r14]
    786625d078be:	mov    r14,QWORD PTR [r15]
    786625d078c1:	mov    r15d,0x0
    786625d078c7:	mov    QWORD PTR [r12+0x1c0],rbp
    786625d078cf:	mov    QWORD PTR [r12+0x1c8],r15
    786625d078d7:	mov    r15d,0x0
    786625d078dd:	mov    QWORD PTR [r12+0x1b0],r14
    786625d078e5:	mov    QWORD PTR [r12+0x1b8],r15
    786625d078ed:	add    r13,0x190
    786625d078f4:	mov    r14,r13
    786625d078f7:	add    r14,0x8
    786625d078fb:	mov    r15,QWORD PTR [r13+0x0]
    786625d078ff:	mov    r13,QWORD PTR [r14]
    786625d07902:	mov    r14d,0x0
    786625d07908:	mov    QWORD PTR [r12+0x1e0],r15
    786625d07910:	mov    QWORD PTR [r12+0x1e8],r14
    786625d07918:	mov    r14d,0x0
    786625d0791e:	mov    QWORD PTR [r12+0x1d0],r13
    786625d07926:	mov    QWORD PTR [r12+0x1d8],r14
    786625d0792e:	mov    r13,QWORD PTR [r12+0xf8]
    786625d07936:	mov    r14,r13
    786625d07939:	add    r14,0x180
    786625d07940:	mov    r15,r14
    786625d07943:	add    r15,0x8
    786625d07947:	mov    rbp,QWORD PTR [r14]
    786625d0794a:	mov    r14,QWORD PTR [r15]
    786625d0794d:	mov    r15d,0x0
    786625d07953:	mov    QWORD PTR [r12+0x200],rbp
    786625d0795b:	mov    QWORD PTR [r12+0x208],r15
    786625d07963:	mov    r15d,0x0
    786625d07969:	mov    QWORD PTR [r12+0x1f0],r14
    786625d07971:	mov    QWORD PTR [r12+0x1f8],r15
    786625d07979:	add    r13,0x1e0
    786625d07980:	mov    QWORD PTR [r12+0xf8],r13
    786625d07988:	mov    rcx,QWORD PTR [r12+0x380]
    786625d07990:	jrcxz  0x786625d07997
    786625d07992:	jmp    0x786625d09e90
    786625d07997:	mov    r13,QWORD PTR [r12+0xf0]
    786625d0799f:	mov    QWORD PTR [r12+0x100],r13
    786625d079a7:	mov    r11,QWORD PTR [rsp]
    786625d079ab:	mov    QWORD PTR [r12+0x398],r11
    786625d079b3:	mov    rdi,QWORD PTR [r12+0x100]
    786625d079bb:	add    rsp,0x150
    786625d079c2:	movabs r11,0x5c9c39de20a0
    786625d079cc:	jmp    r11
    786625d079cf:	mov    r13d,DWORD PTR [r12+0x98]
    786625d079d7:	mov    r14d,DWORD PTR [r12]
    786625d079db:	mov    ecx,r13d
    786625d079de:	add    r14d,ecx
    786625d079e1:	mov    QWORD PTR [r12],r14
    786625d079e5:	mov    r13d,0x4103f8
    786625d079eb:	mov    QWORD PTR [r12+0xf0],r13
    786625d079f3:	mov    r13d,0x4109a4
    786625d079f9:	mov    QWORD PTR [r12+0x100],r13
    786625d07a01:	mov    r11,QWORD PTR [rsp]
    786625d07a05:	mov    QWORD PTR [r12+0x398],r11
    786625d07a0d:	mov    edi,0x4109a4
    786625d07a12:	mov    QWORD PTR [r12+0x100],rdi
    786625d07a1a:	add    rsp,0x150
    786625d07a21:	nop    DWORD PTR [rax+0x0]
    786625d07a28:	jmp    QWORD PTR [rip+0x2]        # 0x786625d07a30
    786625d07a2e:	xchg   ax,ax
    786625d07a30:	nop
    786625d07a31:	and    eax,edx
    786625d07a33:	and    eax,0x7866
    786625d07a38:	rex jp 0x786625d07a0b
    786625d07a3b:	and    eax,0x7866
    786625d07a40:	movabs r11,0x5c9c39de20a0
    786625d07a4a:	jmp    r11
    786625d07a4d:	movdqa xmm0,xmm2
    786625d07a51:	movdqa xmm1,xmm3
    786625d07a55:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07a5e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07a67:	call   0x786625d083e0
    786625d07a6c:	jmp    0x786625d03213
    786625d07a71:	movdqa xmm0,xmm2
    786625d07a75:	movdqa xmm1,xmm3
    786625d07a79:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07a82:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07a8b:	call   0x786625d083e0
    786625d07a90:	jmp    0x786625d03340
    786625d07a95:	movdqa xmm0,xmm3
    786625d07a99:	movdqa xmm1,xmm4
    786625d07a9d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07aa6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07aaf:	call   0x786625d084c0
    786625d07ab4:	jmp    0x786625d03ce1
    786625d07ab9:	movdqa xmm0,xmm2
    786625d07abd:	movdqa xmm1,xmm4
    786625d07ac1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07aca:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07ad3:	call   0x786625d08650
    786625d07ad8:	jmp    0x786625d03da0
    786625d07add:	movdqa xmm0,xmm3
    786625d07ae1:	movdqa xmm1,xmm2
    786625d07ae5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07aee:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07af7:	call   0x786625d087e0
    786625d07afc:	jmp    0x786625d03e76
    786625d07b01:	movdqa xmm0,xmm3
    786625d07b05:	movdqa xmm1,xmm2
    786625d07b09:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07b12:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07b1b:	call   0x786625d087e0
    786625d07b20:	jmp    0x786625d03f30
    786625d07b25:	movdqa xmm0,xmm2
    786625d07b29:	movdqa xmm1,xmm3
    786625d07b2d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07b36:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07b3f:	call   0x786625d087e0
    786625d07b44:	jmp    0x786625d03ff8
    786625d07b49:	movdqa xmm0,xmm2
    786625d07b4d:	movdqa xmm1,xmm3
    786625d07b51:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07b5a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07b63:	call   0x786625d08960
    786625d07b68:	jmp    0x786625d04103
    786625d07b6d:	movdqa xmm0,xmm2
    786625d07b71:	movdqa xmm1,xmm3
    786625d07b75:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07b7e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07b87:	call   0x786625d08ae0
    786625d07b8c:	jmp    0x786625d04220
    786625d07b91:	movdqa xmm0,xmm2
    786625d07b95:	movdqa xmm1,xmm3
    786625d07b99:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07ba2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07bab:	call   0x786625d08ae0
    786625d07bb0:	jmp    0x786625d042e8
    786625d07bb5:	movdqa xmm0,xmm2
    786625d07bb9:	movdqa xmm1,xmm3
    786625d07bbd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07bc6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07bcf:	call   0x786625d08ae0
    786625d07bd4:	jmp    0x786625d043a2
    786625d07bd9:	movdqa xmm0,xmm2
    786625d07bdd:	movdqa xmm1,xmm4
    786625d07be1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07bea:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07bf3:	call   0x786625d08c60
    786625d07bf8:	jmp    0x786625d045e7
    786625d07bfd:	movdqa xmm0,xmm4
    786625d07c01:	movdqa xmm1,xmm5
    786625d07c05:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07c0e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07c17:	call   0x786625d08df0
    786625d07c1c:	jmp    0x786625d0470c
    786625d07c21:	movdqa xmm0,xmm4
    786625d07c25:	movdqa xmm1,xmm5
    786625d07c29:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07c32:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07c3b:	call   0x786625d08df0
    786625d07c40:	jmp    0x786625d047d4
    786625d07c45:	movdqa xmm0,xmm3
    786625d07c49:	movdqa xmm1,xmm4
    786625d07c4d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07c56:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07c5f:	call   0x786625d08650
    786625d07c64:	jmp    0x786625d04893
    786625d07c69:	movdqa xmm0,xmm2
    786625d07c6d:	movdqa xmm1,xmm3
    786625d07c71:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07c7a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07c83:	call   0x786625d08650
    786625d07c88:	jmp    0x786625d04952
    786625d07c8d:	movdqa xmm0,xmm2
    786625d07c91:	movdqa xmm1,xmm4
    786625d07c95:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07c9e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07ca7:	call   0x786625d08650
    786625d07cac:	jmp    0x786625d04a78
    786625d07cb1:	movdqa xmm0,xmm2
    786625d07cb5:	movdqa xmm1,xmm3
    786625d07cb9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07cc2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07ccb:	call   0x786625d08960
    786625d07cd0:	jmp    0x786625d04b7f
    786625d07cd5:	movdqa xmm0,xmm3
    786625d07cd9:	movdqa xmm1,xmm4
    786625d07cdd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07ce6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07cef:	call   0x786625d08c60
    786625d07cf4:	jmp    0x786625d04d34
    786625d07cf9:	movdqa xmm0,xmm2
    786625d07cfd:	movdqa xmm1,xmm3
    786625d07d01:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07d0a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07d13:	call   0x786625d08960
    786625d07d18:	jmp    0x786625d04df3
    786625d07d1d:	movdqa xmm0,xmm3
    786625d07d21:	movdqa xmm1,xmm4
    786625d07d25:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07d2e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07d37:	call   0x786625d08c60
    786625d07d3c:	jmp    0x786625d04f20
    786625d07d41:	movdqa xmm0,xmm3
    786625d07d45:	movdqa xmm1,xmm4
    786625d07d49:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07d52:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07d5b:	call   0x786625d08c60
    786625d07d60:	jmp    0x786625d04fe8
    786625d07d65:	movdqa xmm0,xmm2
    786625d07d69:	movdqa xmm1,xmm3
    786625d07d6d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07d76:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07d7f:	call   0x786625d08960
    786625d07d84:	jmp    0x786625d050cb
    786625d07d89:	movdqa xmm0,xmm3
    786625d07d8d:	movdqa xmm1,xmm4
    786625d07d91:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07d9a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07da3:	call   0x786625d08c60
    786625d07da8:	jmp    0x786625d051f8
    786625d07dad:	movdqa xmm0,xmm3
    786625d07db1:	movdqa xmm1,xmm4
    786625d07db5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07dbe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07dc7:	call   0x786625d08650
    786625d07dcc:	jmp    0x786625d052c5
    786625d07dd1:	movdqa xmm0,xmm2
    786625d07dd5:	movdqa xmm1,xmm4
    786625d07dd9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07de2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07deb:	call   0x786625d08f80
    786625d07df0:	jmp    0x786625d05392
    786625d07df5:	movdqa xmm0,xmm3
    786625d07df9:	movdqa xmm1,xmm4
    786625d07dfd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07e06:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07e0f:	call   0x786625d08c60
    786625d07e14:	jmp    0x786625d054c1
    786625d07e19:	movdqa xmm0,xmm2
    786625d07e1d:	movdqa xmm1,xmm3
    786625d07e21:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07e2a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07e33:	call   0x786625d08960
    786625d07e38:	jmp    0x786625d055c8
    786625d07e3d:	movdqa xmm0,xmm2
    786625d07e41:	movdqa xmm1,xmm4
    786625d07e45:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07e4e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07e57:	call   0x786625d08c60
    786625d07e5c:	jmp    0x786625d056ea
    786625d07e61:	movdqa xmm0,xmm2
    786625d07e65:	movdqa xmm1,xmm3
    786625d07e69:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07e72:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07e7b:	call   0x786625d08960
    786625d07e80:	jmp    0x786625d057a9
    786625d07e85:	movdqa xmm0,xmm2
    786625d07e89:	movdqa xmm1,xmm3
    786625d07e8d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07e96:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07e9f:	call   0x786625d08ae0
    786625d07ea4:	jmp    0x786625d05871
    786625d07ea9:	movdqa xmm0,xmm2
    786625d07ead:	movdqa xmm1,xmm3
    786625d07eb1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07eba:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07ec3:	call   0x786625d08960
    786625d07ec8:	jmp    0x786625d0593e
    786625d07ecd:	movdqa xmm0,xmm2
    786625d07ed1:	movdqa xmm1,xmm3
    786625d07ed5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07ede:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07ee7:	call   0x786625d08960
    786625d07eec:	jmp    0x786625d059fd
    786625d07ef1:	movdqa xmm0,xmm2
    786625d07ef5:	movdqa xmm1,xmm4
    786625d07ef9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07f02:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07f0b:	call   0x786625d08c60
    786625d07f10:	jmp    0x786625d05ac5
    786625d07f15:	movdqa xmm0,xmm2
    786625d07f19:	movdqa xmm1,xmm4
    786625d07f1d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07f26:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07f2f:	call   0x786625d08c60
    786625d07f34:	jmp    0x786625d05b8d
    786625d07f39:	movdqa xmm0,xmm2
    786625d07f3d:	movdqa xmm1,xmm3
    786625d07f41:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07f4a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07f53:	call   0x786625d08960
    786625d07f58:	jmp    0x786625d05c4c
    786625d07f5d:	movdqa xmm0,xmm2
    786625d07f61:	movdqa xmm1,xmm3
    786625d07f65:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07f6e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07f77:	call   0x786625d08960
    786625d07f7c:	jmp    0x786625d05d0b
    786625d07f81:	movdqa xmm0,xmm2
    786625d07f85:	movdqa xmm1,xmm3
    786625d07f89:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07f92:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07f9b:	call   0x786625d08ae0
    786625d07fa0:	jmp    0x786625d05dd3
    786625d07fa5:	movdqa xmm0,xmm2
    786625d07fa9:	movdqa xmm1,xmm3
    786625d07fad:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07fb6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07fbf:	call   0x786625d08ae0
    786625d07fc4:	jmp    0x786625d05e9b
    786625d07fc9:	movdqa xmm0,xmm2
    786625d07fcd:	movdqa xmm1,xmm3
    786625d07fd1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07fda:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d07fe3:	call   0x786625d08960
    786625d07fe8:	jmp    0x786625d05f68
    786625d07fed:	movdqa xmm0,xmm2
    786625d07ff1:	movdqa xmm1,xmm3
    786625d07ff5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d07ffe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08007:	call   0x786625d08ae0
    786625d0800c:	jmp    0x786625d06030
    786625d08011:	movdqa xmm0,xmm2
    786625d08015:	movdqa xmm1,xmm3
    786625d08019:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d08022:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d0802b:	call   0x786625d08ae0
    786625d08030:	jmp    0x786625d060f8
    786625d08035:	movdqa xmm0,xmm2
    786625d08039:	movdqa xmm1,xmm3
    786625d0803d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d08046:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d0804f:	call   0x786625d08960
    786625d08054:	jmp    0x786625d06293
    786625d08059:	movdqa xmm0,xmm2
    786625d0805d:	movdqa xmm1,xmm4
    786625d08061:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d0806a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08073:	call   0x786625d08c60
    786625d08078:	jmp    0x786625d0635b
    786625d0807d:	movdqa xmm0,xmm2
    786625d08081:	movdqa xmm1,xmm4
    786625d08085:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d0808e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08097:	call   0x786625d08c60
    786625d0809c:	jmp    0x786625d06423
    786625d080a1:	movdqa xmm0,xmm2
    786625d080a5:	movdqa xmm1,xmm3
    786625d080a9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d080b2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d080bb:	call   0x786625d08960
    786625d080c0:	jmp    0x786625d064e2
    786625d080c5:	movdqa xmm0,xmm2
    786625d080c9:	movdqa xmm1,xmm3
    786625d080cd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d080d6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d080df:	call   0x786625d08960
    786625d080e4:	jmp    0x786625d065af
    786625d080e9:	movdqa xmm0,xmm2
    786625d080ed:	movdqa xmm1,xmm3
    786625d080f1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d080fa:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08103:	call   0x786625d08960
    786625d08108:	jmp    0x786625d0667c
    786625d0810d:	movdqa xmm0,xmm2
    786625d08111:	movdqa xmm1,xmm4
    786625d08115:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d0811e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08127:	call   0x786625d08c60
    786625d0812c:	jmp    0x786625d06744
    786625d08131:	movdqa xmm0,xmm2
    786625d08135:	movdqa xmm1,xmm3
    786625d08139:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d08142:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d0814b:	call   0x786625d08960
    786625d08150:	jmp    0x786625d06803
    786625d08155:	movdqa xmm0,xmm2
    786625d08159:	movdqa xmm1,xmm4
    786625d0815d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d08166:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d0816f:	call   0x786625d08c60
    786625d08174:	jmp    0x786625d068cb
    786625d08179:	movdqa xmm0,xmm2
    786625d0817d:	movdqa xmm1,xmm3
    786625d08181:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d0818a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08193:	call   0x786625d08960
    786625d08198:	jmp    0x786625d0698a
    786625d0819d:	movdqa xmm0,xmm2
    786625d081a1:	movdqa xmm1,xmm3
    786625d081a5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d081ae:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d081b7:	call   0x786625d08ae0
    786625d081bc:	jmp    0x786625d06a52
    786625d081c1:	movdqa xmm0,xmm2
    786625d081c5:	movdqa xmm1,xmm3
    786625d081c9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d081d2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d081db:	call   0x786625d08960
    786625d081e0:	jmp    0x786625d06b1f
    786625d081e5:	movdqa xmm0,xmm2
    786625d081e9:	movdqa xmm1,xmm3
    786625d081ed:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d081f6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d081ff:	call   0x786625d08ae0
    786625d08204:	jmp    0x786625d06be7
    786625d08209:	movdqa xmm0,xmm3
    786625d0820d:	movdqa xmm1,xmm4
    786625d08211:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d0821a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08223:	call   0x786625d08c60
    786625d08228:	jmp    0x786625d06d13
    786625d0822d:	movdqa xmm0,xmm2
    786625d08231:	movdqa xmm1,xmm3
    786625d08235:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d0823e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08247:	call   0x786625d08960
    786625d0824c:	jmp    0x786625d06dd2
    786625d08251:	movdqa xmm0,xmm2
    786625d08255:	movdqa xmm1,xmm3
    786625d08259:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d08262:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d0826b:	call   0x786625d08960
    786625d08270:	jmp    0x786625d06e91
    786625d08275:	movdqa xmm0,xmm2
    786625d08279:	movdqa xmm1,xmm4
    786625d0827d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d08286:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d0828f:	call   0x786625d08c60
    786625d08294:	jmp    0x786625d06f59
    786625d08299:	movdqa xmm0,xmm5
    786625d0829d:	movdqa xmm1,xmm6
    786625d082a1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d082aa:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d082b3:	call   0x786625d09100
    786625d082b8:	jmp    0x786625d07083
    786625d082bd:	movdqa xmm0,xmm4
    786625d082c1:	movdqa xmm1,xmm3
    786625d082c5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d082ce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d082d7:	call   0x786625d092a0
    786625d082dc:	jmp    0x786625d07134
    786625d082e1:	movdqa xmm0,xmm2
    786625d082e5:	movdqa xmm1,xmm3
    786625d082e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d082f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d082fb:	call   0x786625d09430
    786625d08300:	jmp    0x786625d071e5
    786625d08305:	movdqa xmm0,xmm2
    786625d08309:	movdqa xmm1,xmm3
    786625d0830d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d08316:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d0831f:	call   0x786625d095c0
    786625d08324:	jmp    0x786625d072ad
    786625d08329:	movdqa xmm0,xmm2
    786625d0832d:	movdqa xmm1,xmm3
    786625d08331:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d0833a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08343:	call   0x786625d095c0
    786625d08348:	jmp    0x786625d07375
    786625d0834d:	movdqa xmm0,xmm2
    786625d08351:	movdqa xmm1,xmm3
    786625d08355:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d0835e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d08367:	call   0x786625d095c0
    786625d0836c:	jmp    0x786625d0743d
    786625d08371:	movdqa xmm0,xmm7
    786625d08375:	movdqa xmm1,xmm2
    786625d08379:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d08382:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d0838b:	call   0x786625d09750
    786625d08390:	jmp    0x786625d074f7
    786625d08395:	movdqa xmm0,xmm2
    786625d08399:	movdqa xmm1,xmm3
    786625d0839d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d083a6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d083af:	call   0x786625d098d0
    786625d083b4:	jmp    0x786625d0772d
    786625d083b9:	movdqa xmm0,xmm4
    786625d083bd:	movdqa xmm1,xmm2
    786625d083c1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    786625d083ca:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    786625d083d3:	call   0x786625d09a50
    786625d083d8:	jmp    0x786625d0778f
    786625d083dd:	nop    DWORD PTR [rax]
    786625d083e0:	sub    rsp,0x8
    786625d083e4:	stmxcsr DWORD PTR [rsp+0x124]
    786625d083ec:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d083f4:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d083fc:	shr    r11d,1
    786625d083ff:	and    r11d,0x10
    786625d08403:	or     DWORD PTR [r12+0x314],r11d
    786625d0840b:	mov    QWORD PTR [r12+0x378],0x3
    786625d08417:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d0841d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d08423:	mov    QWORD PTR [r12+0x108],rbx
    786625d0842b:	stmxcsr DWORD PTR [r12-0x28]
    786625d08431:	ldmxcsr DWORD PTR [r12-0x38]
    786625d08437:	lea    rdi,[rsp+0x110]
    786625d0843f:	lea    rsi,[rsp+0xf0]
    786625d08447:	lea    rdx,[rsp+0x100]
    786625d0844f:	mov    ecx,0x16
    786625d08454:	mov    r8d,0x0
    786625d0845a:	lea    r9,[r12+0x314]
    786625d08462:	movabs r11,0x5c9c39c4d1b0
    786625d0846c:	call   r11
    786625d0846f:	ldmxcsr DWORD PTR [r12-0x28]
    786625d08475:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d0847b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d08481:	mov    rbx,QWORD PTR [r12+0x108]
    786625d08489:	mov    QWORD PTR [r12+0x378],0x2
    786625d08495:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d0849e:	stmxcsr DWORD PTR [rsp+0x120]
    786625d084a6:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d084b1:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d084b9:	add    rsp,0x8
    786625d084bd:	ret
    786625d084be:	xchg   ax,ax
    786625d084c0:	sub    rsp,0x8
    786625d084c4:	stmxcsr DWORD PTR [rsp+0x124]
    786625d084cc:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d084d4:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d084dc:	shr    r11d,1
    786625d084df:	and    r11d,0x10
    786625d084e3:	or     DWORD PTR [r12+0x314],r11d
    786625d084eb:	mov    QWORD PTR [r12+0x378],0x3
    786625d084f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d084fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d08503:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    786625d08509:	push   rdx
    786625d0850a:	push   rsi
    786625d0850b:	push   r10
    786625d0850d:	push   r11
    786625d0850f:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d08514:	mov    r10d,edx
    786625d08517:	and    r10d,0xc0
    786625d0851e:	shl    r10d,0x18
    786625d08522:	mov    r11d,edx
    786625d08525:	and    r11d,0x1
    786625d08529:	shl    r11d,0x1d
    786625d0852d:	or     r10d,r11d
    786625d08530:	mov    r11d,edx
    786625d08533:	and    r11d,0x800
    786625d0853a:	shl    r11d,0x11
    786625d0853e:	or     r10d,r11d
    786625d08541:	btc    r10,0x1d
    786625d08546:	mov    r11d,0xf0000000
    786625d0854c:	and    r11,r10
    786625d0854f:	movabs rsi,0xffffffff0fffffff
    786625d08559:	and    rbx,rsi
    786625d0855c:	or     rbx,r11
    786625d0855f:	pop    r11
    786625d08561:	pop    r10
    786625d08563:	pop    rsi
    786625d08564:	pop    rdx
    786625d08565:	mov    QWORD PTR [r12+0x108],rbx
    786625d0856d:	stmxcsr DWORD PTR [r12-0x28]
    786625d08573:	ldmxcsr DWORD PTR [r12-0x38]
    786625d08579:	lea    rdi,[rsp+0x110]
    786625d08581:	lea    rsi,[rsp+0xf0]
    786625d08589:	lea    rdx,[rsp+0x100]
    786625d08591:	mov    ecx,0x16
    786625d08596:	mov    r8d,0x0
    786625d0859c:	lea    r9,[r12+0x314]
    786625d085a4:	movabs r11,0x5c9c39c4d1b0
    786625d085ae:	call   r11
    786625d085b1:	ldmxcsr DWORD PTR [r12-0x28]
    786625d085b7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d085bd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d085c3:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    786625d085c9:	mov    rbx,QWORD PTR [r12+0x108]
    786625d085d1:	mov    QWORD PTR [r12+0x378],0x2
    786625d085dd:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d085e6:	pushf
    786625d085e7:	pop    rdx
    786625d085e8:	and    rdx,0xfffffffffffff73e
    786625d085ef:	mov    rax,rbx
    786625d085f2:	shr    rax,0x18
    786625d085f6:	and    eax,0xc0
    786625d085fb:	or     rdx,rax
    786625d085fe:	mov    rax,rbx
    786625d08601:	shr    rax,0x1d
    786625d08605:	and    eax,0x1
    786625d08608:	xor    eax,0x1
    786625d0860b:	or     rdx,rax
    786625d0860e:	mov    rax,rbx
    786625d08611:	shr    rax,0x11
    786625d08615:	and    eax,0x800
    786625d0861a:	or     rdx,rax
    786625d0861d:	mov    QWORD PTR [rsp+0x10],rdx
    786625d08622:	stmxcsr DWORD PTR [rsp+0x120]
    786625d0862a:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d08635:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d0863d:	add    rsp,0x8
    786625d08641:	ret
    786625d08642:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d08650:	sub    rsp,0x8
    786625d08654:	stmxcsr DWORD PTR [rsp+0x124]
    786625d0865c:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d08664:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d0866c:	shr    r11d,1
    786625d0866f:	and    r11d,0x10
    786625d08673:	or     DWORD PTR [r12+0x314],r11d
    786625d0867b:	mov    QWORD PTR [r12+0x378],0x3
    786625d08687:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d0868d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d08693:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    786625d08699:	push   rdx
    786625d0869a:	push   rsi
    786625d0869b:	push   r10
    786625d0869d:	push   r11
    786625d0869f:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d086a4:	mov    r10d,edx
    786625d086a7:	and    r10d,0xc0
    786625d086ae:	shl    r10d,0x18
    786625d086b2:	mov    r11d,edx
    786625d086b5:	and    r11d,0x1
    786625d086b9:	shl    r11d,0x1d
    786625d086bd:	or     r10d,r11d
    786625d086c0:	mov    r11d,edx
    786625d086c3:	and    r11d,0x800
    786625d086ca:	shl    r11d,0x11
    786625d086ce:	or     r10d,r11d
    786625d086d1:	btc    r10,0x1d
    786625d086d6:	mov    r11d,0xf0000000
    786625d086dc:	and    r11,r10
    786625d086df:	movabs rsi,0xffffffff0fffffff
    786625d086e9:	and    rbx,rsi
    786625d086ec:	or     rbx,r11
    786625d086ef:	pop    r11
    786625d086f1:	pop    r10
    786625d086f3:	pop    rsi
    786625d086f4:	pop    rdx
    786625d086f5:	mov    QWORD PTR [r12+0x108],rbx
    786625d086fd:	stmxcsr DWORD PTR [r12-0x28]
    786625d08703:	ldmxcsr DWORD PTR [r12-0x38]
    786625d08709:	lea    rdi,[rsp+0x110]
    786625d08711:	lea    rsi,[rsp+0xf0]
    786625d08719:	lea    rdx,[rsp+0x100]
    786625d08721:	mov    ecx,0x56
    786625d08726:	mov    r8d,0x0
    786625d0872c:	lea    r9,[r12+0x314]
    786625d08734:	movabs r11,0x5c9c39c4d1b0
    786625d0873e:	call   r11
    786625d08741:	ldmxcsr DWORD PTR [r12-0x28]
    786625d08747:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d0874d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d08753:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    786625d08759:	mov    rbx,QWORD PTR [r12+0x108]
    786625d08761:	mov    QWORD PTR [r12+0x378],0x2
    786625d0876d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d08776:	pushf
    786625d08777:	pop    rdx
    786625d08778:	and    rdx,0xfffffffffffff73e
    786625d0877f:	mov    rax,rbx
    786625d08782:	shr    rax,0x18
    786625d08786:	and    eax,0xc0
    786625d0878b:	or     rdx,rax
    786625d0878e:	mov    rax,rbx
    786625d08791:	shr    rax,0x1d
    786625d08795:	and    eax,0x1
    786625d08798:	xor    eax,0x1
    786625d0879b:	or     rdx,rax
    786625d0879e:	mov    rax,rbx
    786625d087a1:	shr    rax,0x11
    786625d087a5:	and    eax,0x800
    786625d087aa:	or     rdx,rax
    786625d087ad:	mov    QWORD PTR [rsp+0x10],rdx
    786625d087b2:	stmxcsr DWORD PTR [rsp+0x120]
    786625d087ba:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d087c5:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d087cd:	add    rsp,0x8
    786625d087d1:	ret
    786625d087d2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d087e0:	sub    rsp,0x8
    786625d087e4:	stmxcsr DWORD PTR [rsp+0x124]
    786625d087ec:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d087f4:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d087fc:	shr    r11d,1
    786625d087ff:	and    r11d,0x10
    786625d08803:	or     DWORD PTR [r12+0x314],r11d
    786625d0880b:	mov    QWORD PTR [r12+0x378],0x3
    786625d08817:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d0881d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d08823:	push   rdx
    786625d08824:	push   rsi
    786625d08825:	push   r10
    786625d08827:	push   r11
    786625d08829:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d0882e:	mov    r10d,edx
    786625d08831:	and    r10d,0xc0
    786625d08838:	shl    r10d,0x18
    786625d0883c:	mov    r11d,edx
    786625d0883f:	and    r11d,0x1
    786625d08843:	shl    r11d,0x1d
    786625d08847:	or     r10d,r11d
    786625d0884a:	mov    r11d,edx
    786625d0884d:	and    r11d,0x800
    786625d08854:	shl    r11d,0x11
    786625d08858:	or     r10d,r11d
    786625d0885b:	btc    r10,0x1d
    786625d08860:	mov    r11d,0xf0000000
    786625d08866:	and    r11,r10
    786625d08869:	movabs rsi,0xffffffff0fffffff
    786625d08873:	and    rbx,rsi
    786625d08876:	or     rbx,r11
    786625d08879:	pop    r11
    786625d0887b:	pop    r10
    786625d0887d:	pop    rsi
    786625d0887e:	pop    rdx
    786625d0887f:	mov    QWORD PTR [r12+0x108],rbx
    786625d08887:	stmxcsr DWORD PTR [r12-0x28]
    786625d0888d:	ldmxcsr DWORD PTR [r12-0x38]
    786625d08893:	lea    rdi,[rsp+0x110]
    786625d0889b:	lea    rsi,[rsp+0xf0]
    786625d088a3:	lea    rdx,[rsp+0x100]
    786625d088ab:	mov    ecx,0x16
    786625d088b0:	mov    r8d,0x0
    786625d088b6:	lea    r9,[r12+0x314]
    786625d088be:	movabs r11,0x5c9c39c4d1b0
    786625d088c8:	call   r11
    786625d088cb:	ldmxcsr DWORD PTR [r12-0x28]
    786625d088d1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d088d7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d088dd:	mov    rbx,QWORD PTR [r12+0x108]
    786625d088e5:	mov    QWORD PTR [r12+0x378],0x2
    786625d088f1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d088fa:	pushf
    786625d088fb:	pop    rdx
    786625d088fc:	and    rdx,0xfffffffffffff73e
    786625d08903:	mov    rax,rbx
    786625d08906:	shr    rax,0x18
    786625d0890a:	and    eax,0xc0
    786625d0890f:	or     rdx,rax
    786625d08912:	mov    rax,rbx
    786625d08915:	shr    rax,0x1d
    786625d08919:	and    eax,0x1
    786625d0891c:	xor    eax,0x1
    786625d0891f:	or     rdx,rax
    786625d08922:	mov    rax,rbx
    786625d08925:	shr    rax,0x11
    786625d08929:	and    eax,0x800
    786625d0892e:	or     rdx,rax
    786625d08931:	mov    QWORD PTR [rsp+0x10],rdx
    786625d08936:	stmxcsr DWORD PTR [rsp+0x120]
    786625d0893e:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d08949:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d08951:	add    rsp,0x8
    786625d08955:	ret
    786625d08956:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d08960:	sub    rsp,0x8
    786625d08964:	stmxcsr DWORD PTR [rsp+0x124]
    786625d0896c:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d08974:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d0897c:	shr    r11d,1
    786625d0897f:	and    r11d,0x10
    786625d08983:	or     DWORD PTR [r12+0x314],r11d
    786625d0898b:	mov    QWORD PTR [r12+0x378],0x3
    786625d08997:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d0899d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d089a3:	push   rdx
    786625d089a4:	push   rsi
    786625d089a5:	push   r10
    786625d089a7:	push   r11
    786625d089a9:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d089ae:	mov    r10d,edx
    786625d089b1:	and    r10d,0xc0
    786625d089b8:	shl    r10d,0x18
    786625d089bc:	mov    r11d,edx
    786625d089bf:	and    r11d,0x1
    786625d089c3:	shl    r11d,0x1d
    786625d089c7:	or     r10d,r11d
    786625d089ca:	mov    r11d,edx
    786625d089cd:	and    r11d,0x800
    786625d089d4:	shl    r11d,0x11
    786625d089d8:	or     r10d,r11d
    786625d089db:	btc    r10,0x1d
    786625d089e0:	mov    r11d,0xf0000000
    786625d089e6:	and    r11,r10
    786625d089e9:	movabs rsi,0xffffffff0fffffff
    786625d089f3:	and    rbx,rsi
    786625d089f6:	or     rbx,r11
    786625d089f9:	pop    r11
    786625d089fb:	pop    r10
    786625d089fd:	pop    rsi
    786625d089fe:	pop    rdx
    786625d089ff:	mov    QWORD PTR [r12+0x108],rbx
    786625d08a07:	stmxcsr DWORD PTR [r12-0x28]
    786625d08a0d:	ldmxcsr DWORD PTR [r12-0x38]
    786625d08a13:	lea    rdi,[rsp+0x110]
    786625d08a1b:	lea    rsi,[rsp+0xf0]
    786625d08a23:	lea    rdx,[rsp+0x100]
    786625d08a2b:	mov    ecx,0x56
    786625d08a30:	mov    r8d,0x0
    786625d08a36:	lea    r9,[r12+0x314]
    786625d08a3e:	movabs r11,0x5c9c39c4d1b0
    786625d08a48:	call   r11
    786625d08a4b:	ldmxcsr DWORD PTR [r12-0x28]
    786625d08a51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d08a57:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d08a5d:	mov    rbx,QWORD PTR [r12+0x108]
    786625d08a65:	mov    QWORD PTR [r12+0x378],0x2
    786625d08a71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d08a7a:	pushf
    786625d08a7b:	pop    rdx
    786625d08a7c:	and    rdx,0xfffffffffffff73e
    786625d08a83:	mov    rax,rbx
    786625d08a86:	shr    rax,0x18
    786625d08a8a:	and    eax,0xc0
    786625d08a8f:	or     rdx,rax
    786625d08a92:	mov    rax,rbx
    786625d08a95:	shr    rax,0x1d
    786625d08a99:	and    eax,0x1
    786625d08a9c:	xor    eax,0x1
    786625d08a9f:	or     rdx,rax
    786625d08aa2:	mov    rax,rbx
    786625d08aa5:	shr    rax,0x11
    786625d08aa9:	and    eax,0x800
    786625d08aae:	or     rdx,rax
    786625d08ab1:	mov    QWORD PTR [rsp+0x10],rdx
    786625d08ab6:	stmxcsr DWORD PTR [rsp+0x120]
    786625d08abe:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d08ac9:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d08ad1:	add    rsp,0x8
    786625d08ad5:	ret
    786625d08ad6:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d08ae0:	sub    rsp,0x8
    786625d08ae4:	stmxcsr DWORD PTR [rsp+0x124]
    786625d08aec:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d08af4:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d08afc:	shr    r11d,1
    786625d08aff:	and    r11d,0x10
    786625d08b03:	or     DWORD PTR [r12+0x314],r11d
    786625d08b0b:	mov    QWORD PTR [r12+0x378],0x3
    786625d08b17:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d08b1d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d08b23:	push   rdx
    786625d08b24:	push   rsi
    786625d08b25:	push   r10
    786625d08b27:	push   r11
    786625d08b29:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d08b2e:	mov    r10d,edx
    786625d08b31:	and    r10d,0xc0
    786625d08b38:	shl    r10d,0x18
    786625d08b3c:	mov    r11d,edx
    786625d08b3f:	and    r11d,0x1
    786625d08b43:	shl    r11d,0x1d
    786625d08b47:	or     r10d,r11d
    786625d08b4a:	mov    r11d,edx
    786625d08b4d:	and    r11d,0x800
    786625d08b54:	shl    r11d,0x11
    786625d08b58:	or     r10d,r11d
    786625d08b5b:	btc    r10,0x1d
    786625d08b60:	mov    r11d,0xf0000000
    786625d08b66:	and    r11,r10
    786625d08b69:	movabs rsi,0xffffffff0fffffff
    786625d08b73:	and    rbx,rsi
    786625d08b76:	or     rbx,r11
    786625d08b79:	pop    r11
    786625d08b7b:	pop    r10
    786625d08b7d:	pop    rsi
    786625d08b7e:	pop    rdx
    786625d08b7f:	mov    QWORD PTR [r12+0x108],rbx
    786625d08b87:	stmxcsr DWORD PTR [r12-0x28]
    786625d08b8d:	ldmxcsr DWORD PTR [r12-0x38]
    786625d08b93:	lea    rdi,[rsp+0x110]
    786625d08b9b:	lea    rsi,[rsp+0xf0]
    786625d08ba3:	lea    rdx,[rsp+0x100]
    786625d08bab:	mov    ecx,0x14
    786625d08bb0:	mov    r8d,0x0
    786625d08bb6:	lea    r9,[r12+0x314]
    786625d08bbe:	movabs r11,0x5c9c39c4d1b0
    786625d08bc8:	call   r11
    786625d08bcb:	ldmxcsr DWORD PTR [r12-0x28]
    786625d08bd1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d08bd7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d08bdd:	mov    rbx,QWORD PTR [r12+0x108]
    786625d08be5:	mov    QWORD PTR [r12+0x378],0x2
    786625d08bf1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d08bfa:	pushf
    786625d08bfb:	pop    rdx
    786625d08bfc:	and    rdx,0xfffffffffffff73e
    786625d08c03:	mov    rax,rbx
    786625d08c06:	shr    rax,0x18
    786625d08c0a:	and    eax,0xc0
    786625d08c0f:	or     rdx,rax
    786625d08c12:	mov    rax,rbx
    786625d08c15:	shr    rax,0x1d
    786625d08c19:	and    eax,0x1
    786625d08c1c:	xor    eax,0x1
    786625d08c1f:	or     rdx,rax
    786625d08c22:	mov    rax,rbx
    786625d08c25:	shr    rax,0x11
    786625d08c29:	and    eax,0x800
    786625d08c2e:	or     rdx,rax
    786625d08c31:	mov    QWORD PTR [rsp+0x10],rdx
    786625d08c36:	stmxcsr DWORD PTR [rsp+0x120]
    786625d08c3e:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d08c49:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d08c51:	add    rsp,0x8
    786625d08c55:	ret
    786625d08c56:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d08c60:	sub    rsp,0x8
    786625d08c64:	stmxcsr DWORD PTR [rsp+0x124]
    786625d08c6c:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d08c74:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d08c7c:	shr    r11d,1
    786625d08c7f:	and    r11d,0x10
    786625d08c83:	or     DWORD PTR [r12+0x314],r11d
    786625d08c8b:	mov    QWORD PTR [r12+0x378],0x3
    786625d08c97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d08c9d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d08ca3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    786625d08ca9:	push   rdx
    786625d08caa:	push   rsi
    786625d08cab:	push   r10
    786625d08cad:	push   r11
    786625d08caf:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d08cb4:	mov    r10d,edx
    786625d08cb7:	and    r10d,0xc0
    786625d08cbe:	shl    r10d,0x18
    786625d08cc2:	mov    r11d,edx
    786625d08cc5:	and    r11d,0x1
    786625d08cc9:	shl    r11d,0x1d
    786625d08ccd:	or     r10d,r11d
    786625d08cd0:	mov    r11d,edx
    786625d08cd3:	and    r11d,0x800
    786625d08cda:	shl    r11d,0x11
    786625d08cde:	or     r10d,r11d
    786625d08ce1:	btc    r10,0x1d
    786625d08ce6:	mov    r11d,0xf0000000
    786625d08cec:	and    r11,r10
    786625d08cef:	movabs rsi,0xffffffff0fffffff
    786625d08cf9:	and    rbx,rsi
    786625d08cfc:	or     rbx,r11
    786625d08cff:	pop    r11
    786625d08d01:	pop    r10
    786625d08d03:	pop    rsi
    786625d08d04:	pop    rdx
    786625d08d05:	mov    QWORD PTR [r12+0x108],rbx
    786625d08d0d:	stmxcsr DWORD PTR [r12-0x28]
    786625d08d13:	ldmxcsr DWORD PTR [r12-0x38]
    786625d08d19:	lea    rdi,[rsp+0x110]
    786625d08d21:	lea    rsi,[rsp+0xf0]
    786625d08d29:	lea    rdx,[rsp+0x100]
    786625d08d31:	mov    ecx,0x14
    786625d08d36:	mov    r8d,0x0
    786625d08d3c:	lea    r9,[r12+0x314]
    786625d08d44:	movabs r11,0x5c9c39c4d1b0
    786625d08d4e:	call   r11
    786625d08d51:	ldmxcsr DWORD PTR [r12-0x28]
    786625d08d57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d08d5d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d08d63:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    786625d08d69:	mov    rbx,QWORD PTR [r12+0x108]
    786625d08d71:	mov    QWORD PTR [r12+0x378],0x2
    786625d08d7d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d08d86:	pushf
    786625d08d87:	pop    rdx
    786625d08d88:	and    rdx,0xfffffffffffff73e
    786625d08d8f:	mov    rax,rbx
    786625d08d92:	shr    rax,0x18
    786625d08d96:	and    eax,0xc0
    786625d08d9b:	or     rdx,rax
    786625d08d9e:	mov    rax,rbx
    786625d08da1:	shr    rax,0x1d
    786625d08da5:	and    eax,0x1
    786625d08da8:	xor    eax,0x1
    786625d08dab:	or     rdx,rax
    786625d08dae:	mov    rax,rbx
    786625d08db1:	shr    rax,0x11
    786625d08db5:	and    eax,0x800
    786625d08dba:	or     rdx,rax
    786625d08dbd:	mov    QWORD PTR [rsp+0x10],rdx
    786625d08dc2:	stmxcsr DWORD PTR [rsp+0x120]
    786625d08dca:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d08dd5:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d08ddd:	add    rsp,0x8
    786625d08de1:	ret
    786625d08de2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d08df0:	sub    rsp,0x8
    786625d08df4:	stmxcsr DWORD PTR [rsp+0x124]
    786625d08dfc:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d08e04:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d08e0c:	shr    r11d,1
    786625d08e0f:	and    r11d,0x10
    786625d08e13:	or     DWORD PTR [r12+0x314],r11d
    786625d08e1b:	mov    QWORD PTR [r12+0x378],0x3
    786625d08e27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d08e2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d08e33:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    786625d08e39:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    786625d08e3f:	push   rdx
    786625d08e40:	push   rsi
    786625d08e41:	push   r10
    786625d08e43:	push   r11
    786625d08e45:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d08e4a:	mov    r10d,edx
    786625d08e4d:	and    r10d,0xc0
    786625d08e54:	shl    r10d,0x18
    786625d08e58:	mov    r11d,edx
    786625d08e5b:	and    r11d,0x1
    786625d08e5f:	shl    r11d,0x1d
    786625d08e63:	or     r10d,r11d
    786625d08e66:	mov    r11d,edx
    786625d08e69:	and    r11d,0x800
    786625d08e70:	shl    r11d,0x11
    786625d08e74:	or     r10d,r11d
    786625d08e77:	btc    r10,0x1d
    786625d08e7c:	mov    r11d,0xf0000000
    786625d08e82:	and    r11,r10
    786625d08e85:	movabs rsi,0xffffffff0fffffff
    786625d08e8f:	and    rbx,rsi
    786625d08e92:	or     rbx,r11
    786625d08e95:	pop    r11
    786625d08e97:	pop    r10
    786625d08e99:	pop    rsi
    786625d08e9a:	pop    rdx
    786625d08e9b:	mov    QWORD PTR [r12+0x108],rbx
    786625d08ea3:	stmxcsr DWORD PTR [r12-0x28]
    786625d08ea9:	ldmxcsr DWORD PTR [r12-0x38]
    786625d08eaf:	lea    rdi,[rsp+0x110]
    786625d08eb7:	lea    rsi,[rsp+0xf0]
    786625d08ebf:	lea    rdx,[rsp+0x100]
    786625d08ec7:	mov    ecx,0x14
    786625d08ecc:	mov    r8d,0x0
    786625d08ed2:	lea    r9,[r12+0x314]
    786625d08eda:	movabs r11,0x5c9c39c4d1b0
    786625d08ee4:	call   r11
    786625d08ee7:	ldmxcsr DWORD PTR [r12-0x28]
    786625d08eed:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d08ef3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d08ef9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    786625d08eff:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    786625d08f05:	mov    rbx,QWORD PTR [r12+0x108]
    786625d08f0d:	mov    QWORD PTR [r12+0x378],0x2
    786625d08f19:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d08f22:	pushf
    786625d08f23:	pop    rdx
    786625d08f24:	and    rdx,0xfffffffffffff73e
    786625d08f2b:	mov    rax,rbx
    786625d08f2e:	shr    rax,0x18
    786625d08f32:	and    eax,0xc0
    786625d08f37:	or     rdx,rax
    786625d08f3a:	mov    rax,rbx
    786625d08f3d:	shr    rax,0x1d
    786625d08f41:	and    eax,0x1
    786625d08f44:	xor    eax,0x1
    786625d08f47:	or     rdx,rax
    786625d08f4a:	mov    rax,rbx
    786625d08f4d:	shr    rax,0x11
    786625d08f51:	and    eax,0x800
    786625d08f56:	or     rdx,rax
    786625d08f59:	mov    QWORD PTR [rsp+0x10],rdx
    786625d08f5e:	stmxcsr DWORD PTR [rsp+0x120]
    786625d08f66:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d08f71:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d08f79:	add    rsp,0x8
    786625d08f7d:	ret
    786625d08f7e:	xchg   ax,ax
    786625d08f80:	sub    rsp,0x8
    786625d08f84:	stmxcsr DWORD PTR [rsp+0x124]
    786625d08f8c:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d08f94:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d08f9c:	shr    r11d,1
    786625d08f9f:	and    r11d,0x10
    786625d08fa3:	or     DWORD PTR [r12+0x314],r11d
    786625d08fab:	mov    QWORD PTR [r12+0x378],0x3
    786625d08fb7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d08fbd:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    786625d08fc3:	push   rdx
    786625d08fc4:	push   rsi
    786625d08fc5:	push   r10
    786625d08fc7:	push   r11
    786625d08fc9:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d08fce:	mov    r10d,edx
    786625d08fd1:	and    r10d,0xc0
    786625d08fd8:	shl    r10d,0x18
    786625d08fdc:	mov    r11d,edx
    786625d08fdf:	and    r11d,0x1
    786625d08fe3:	shl    r11d,0x1d
    786625d08fe7:	or     r10d,r11d
    786625d08fea:	mov    r11d,edx
    786625d08fed:	and    r11d,0x800
    786625d08ff4:	shl    r11d,0x11
    786625d08ff8:	or     r10d,r11d
    786625d08ffb:	btc    r10,0x1d
    786625d09000:	mov    r11d,0xf0000000
    786625d09006:	and    r11,r10
    786625d09009:	movabs rsi,0xffffffff0fffffff
    786625d09013:	and    rbx,rsi
    786625d09016:	or     rbx,r11
    786625d09019:	pop    r11
    786625d0901b:	pop    r10
    786625d0901d:	pop    rsi
    786625d0901e:	pop    rdx
    786625d0901f:	mov    QWORD PTR [r12+0x108],rbx
    786625d09027:	stmxcsr DWORD PTR [r12-0x28]
    786625d0902d:	ldmxcsr DWORD PTR [r12-0x38]
    786625d09033:	lea    rdi,[rsp+0x110]
    786625d0903b:	lea    rsi,[rsp+0xf0]
    786625d09043:	lea    rdx,[rsp+0x100]
    786625d0904b:	mov    ecx,0x56
    786625d09050:	mov    r8d,0x0
    786625d09056:	lea    r9,[r12+0x314]
    786625d0905e:	movabs r11,0x5c9c39c4d1b0
    786625d09068:	call   r11
    786625d0906b:	ldmxcsr DWORD PTR [r12-0x28]
    786625d09071:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d09077:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    786625d0907d:	mov    rbx,QWORD PTR [r12+0x108]
    786625d09085:	mov    QWORD PTR [r12+0x378],0x2
    786625d09091:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d0909a:	pushf
    786625d0909b:	pop    rdx
    786625d0909c:	and    rdx,0xfffffffffffff73e
    786625d090a3:	mov    rax,rbx
    786625d090a6:	shr    rax,0x18
    786625d090aa:	and    eax,0xc0
    786625d090af:	or     rdx,rax
    786625d090b2:	mov    rax,rbx
    786625d090b5:	shr    rax,0x1d
    786625d090b9:	and    eax,0x1
    786625d090bc:	xor    eax,0x1
    786625d090bf:	or     rdx,rax
    786625d090c2:	mov    rax,rbx
    786625d090c5:	shr    rax,0x11
    786625d090c9:	and    eax,0x800
    786625d090ce:	or     rdx,rax
    786625d090d1:	mov    QWORD PTR [rsp+0x10],rdx
    786625d090d6:	stmxcsr DWORD PTR [rsp+0x120]
    786625d090de:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d090e9:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d090f1:	add    rsp,0x8
    786625d090f5:	ret
    786625d090f6:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d09100:	sub    rsp,0x8
    786625d09104:	stmxcsr DWORD PTR [rsp+0x124]
    786625d0910c:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d09114:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d0911c:	shr    r11d,1
    786625d0911f:	and    r11d,0x10
    786625d09123:	or     DWORD PTR [r12+0x314],r11d
    786625d0912b:	mov    QWORD PTR [r12+0x378],0x3
    786625d09137:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d0913d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d09143:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    786625d09149:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    786625d0914f:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    786625d09155:	push   rdx
    786625d09156:	push   rsi
    786625d09157:	push   r10
    786625d09159:	push   r11
    786625d0915b:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d09160:	mov    r10d,edx
    786625d09163:	and    r10d,0xc0
    786625d0916a:	shl    r10d,0x18
    786625d0916e:	mov    r11d,edx
    786625d09171:	and    r11d,0x1
    786625d09175:	shl    r11d,0x1d
    786625d09179:	or     r10d,r11d
    786625d0917c:	mov    r11d,edx
    786625d0917f:	and    r11d,0x800
    786625d09186:	shl    r11d,0x11
    786625d0918a:	or     r10d,r11d
    786625d0918d:	btc    r10,0x1d
    786625d09192:	mov    r11d,0xf0000000
    786625d09198:	and    r11,r10
    786625d0919b:	movabs rsi,0xffffffff0fffffff
    786625d091a5:	and    rbx,rsi
    786625d091a8:	or     rbx,r11
    786625d091ab:	pop    r11
    786625d091ad:	pop    r10
    786625d091af:	pop    rsi
    786625d091b0:	pop    rdx
    786625d091b1:	mov    QWORD PTR [r12+0x108],rbx
    786625d091b9:	stmxcsr DWORD PTR [r12-0x28]
    786625d091bf:	ldmxcsr DWORD PTR [r12-0x38]
    786625d091c5:	lea    rdi,[rsp+0x110]
    786625d091cd:	lea    rsi,[rsp+0xf0]
    786625d091d5:	lea    rdx,[rsp+0x100]
    786625d091dd:	mov    ecx,0x14
    786625d091e2:	mov    r8d,0x0
    786625d091e8:	lea    r9,[r12+0x314]
    786625d091f0:	movabs r11,0x5c9c39c4d1b0
    786625d091fa:	call   r11
    786625d091fd:	ldmxcsr DWORD PTR [r12-0x28]
    786625d09203:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d09209:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d0920f:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    786625d09215:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    786625d0921b:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    786625d09221:	mov    rbx,QWORD PTR [r12+0x108]
    786625d09229:	mov    QWORD PTR [r12+0x378],0x2
    786625d09235:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d0923e:	pushf
    786625d0923f:	pop    rdx
    786625d09240:	and    rdx,0xfffffffffffff73e
    786625d09247:	mov    rax,rbx
    786625d0924a:	shr    rax,0x18
    786625d0924e:	and    eax,0xc0
    786625d09253:	or     rdx,rax
    786625d09256:	mov    rax,rbx
    786625d09259:	shr    rax,0x1d
    786625d0925d:	and    eax,0x1
    786625d09260:	xor    eax,0x1
    786625d09263:	or     rdx,rax
    786625d09266:	mov    rax,rbx
    786625d09269:	shr    rax,0x11
    786625d0926d:	and    eax,0x800
    786625d09272:	or     rdx,rax
    786625d09275:	mov    QWORD PTR [rsp+0x10],rdx
    786625d0927a:	stmxcsr DWORD PTR [rsp+0x120]
    786625d09282:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d0928d:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d09295:	add    rsp,0x8
    786625d09299:	ret
    786625d0929a:	nop    WORD PTR [rax+rax*1+0x0]
    786625d092a0:	sub    rsp,0x8
    786625d092a4:	stmxcsr DWORD PTR [rsp+0x124]
    786625d092ac:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d092b4:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d092bc:	shr    r11d,1
    786625d092bf:	and    r11d,0x10
    786625d092c3:	or     DWORD PTR [r12+0x314],r11d
    786625d092cb:	mov    QWORD PTR [r12+0x378],0x3
    786625d092d7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d092dd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d092e3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    786625d092e9:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    786625d092ef:	push   rdx
    786625d092f0:	push   rsi
    786625d092f1:	push   r10
    786625d092f3:	push   r11
    786625d092f5:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d092fa:	mov    r10d,edx
    786625d092fd:	and    r10d,0xc0
    786625d09304:	shl    r10d,0x18
    786625d09308:	mov    r11d,edx
    786625d0930b:	and    r11d,0x1
    786625d0930f:	shl    r11d,0x1d
    786625d09313:	or     r10d,r11d
    786625d09316:	mov    r11d,edx
    786625d09319:	and    r11d,0x800
    786625d09320:	shl    r11d,0x11
    786625d09324:	or     r10d,r11d
    786625d09327:	btc    r10,0x1d
    786625d0932c:	mov    r11d,0xf0000000
    786625d09332:	and    r11,r10
    786625d09335:	movabs rsi,0xffffffff0fffffff
    786625d0933f:	and    rbx,rsi
    786625d09342:	or     rbx,r11
    786625d09345:	pop    r11
    786625d09347:	pop    r10
    786625d09349:	pop    rsi
    786625d0934a:	pop    rdx
    786625d0934b:	mov    QWORD PTR [r12+0x108],rbx
    786625d09353:	stmxcsr DWORD PTR [r12-0x28]
    786625d09359:	ldmxcsr DWORD PTR [r12-0x38]
    786625d0935f:	lea    rdi,[rsp+0x110]
    786625d09367:	lea    rsi,[rsp+0xf0]
    786625d0936f:	lea    rdx,[rsp+0x100]
    786625d09377:	mov    ecx,0x56
    786625d0937c:	mov    r8d,0x0
    786625d09382:	lea    r9,[r12+0x314]
    786625d0938a:	movabs r11,0x5c9c39c4d1b0
    786625d09394:	call   r11
    786625d09397:	ldmxcsr DWORD PTR [r12-0x28]
    786625d0939d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d093a3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d093a9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    786625d093af:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    786625d093b5:	mov    rbx,QWORD PTR [r12+0x108]
    786625d093bd:	mov    QWORD PTR [r12+0x378],0x2
    786625d093c9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d093d2:	pushf
    786625d093d3:	pop    rdx
    786625d093d4:	and    rdx,0xfffffffffffff73e
    786625d093db:	mov    rax,rbx
    786625d093de:	shr    rax,0x18
    786625d093e2:	and    eax,0xc0
    786625d093e7:	or     rdx,rax
    786625d093ea:	mov    rax,rbx
    786625d093ed:	shr    rax,0x1d
    786625d093f1:	and    eax,0x1
    786625d093f4:	xor    eax,0x1
    786625d093f7:	or     rdx,rax
    786625d093fa:	mov    rax,rbx
    786625d093fd:	shr    rax,0x11
    786625d09401:	and    eax,0x800
    786625d09406:	or     rdx,rax
    786625d09409:	mov    QWORD PTR [rsp+0x10],rdx
    786625d0940e:	stmxcsr DWORD PTR [rsp+0x120]
    786625d09416:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d09421:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d09429:	add    rsp,0x8
    786625d0942d:	ret
    786625d0942e:	xchg   ax,ax
    786625d09430:	sub    rsp,0x8
    786625d09434:	stmxcsr DWORD PTR [rsp+0x124]
    786625d0943c:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d09444:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d0944c:	shr    r11d,1
    786625d0944f:	and    r11d,0x10
    786625d09453:	or     DWORD PTR [r12+0x314],r11d
    786625d0945b:	mov    QWORD PTR [r12+0x378],0x3
    786625d09467:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d0946d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d09473:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    786625d09479:	push   rdx
    786625d0947a:	push   rsi
    786625d0947b:	push   r10
    786625d0947d:	push   r11
    786625d0947f:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d09484:	mov    r10d,edx
    786625d09487:	and    r10d,0xc0
    786625d0948e:	shl    r10d,0x18
    786625d09492:	mov    r11d,edx
    786625d09495:	and    r11d,0x1
    786625d09499:	shl    r11d,0x1d
    786625d0949d:	or     r10d,r11d
    786625d094a0:	mov    r11d,edx
    786625d094a3:	and    r11d,0x800
    786625d094aa:	shl    r11d,0x11
    786625d094ae:	or     r10d,r11d
    786625d094b1:	btc    r10,0x1d
    786625d094b6:	mov    r11d,0xf0000000
    786625d094bc:	and    r11,r10
    786625d094bf:	movabs rsi,0xffffffff0fffffff
    786625d094c9:	and    rbx,rsi
    786625d094cc:	or     rbx,r11
    786625d094cf:	pop    r11
    786625d094d1:	pop    r10
    786625d094d3:	pop    rsi
    786625d094d4:	pop    rdx
    786625d094d5:	mov    QWORD PTR [r12+0x108],rbx
    786625d094dd:	stmxcsr DWORD PTR [r12-0x28]
    786625d094e3:	ldmxcsr DWORD PTR [r12-0x38]
    786625d094e9:	lea    rdi,[rsp+0x110]
    786625d094f1:	lea    rsi,[rsp+0xf0]
    786625d094f9:	lea    rdx,[rsp+0x100]
    786625d09501:	mov    ecx,0x56
    786625d09506:	mov    r8d,0x0
    786625d0950c:	lea    r9,[r12+0x314]
    786625d09514:	movabs r11,0x5c9c39c4d1b0
    786625d0951e:	call   r11
    786625d09521:	ldmxcsr DWORD PTR [r12-0x28]
    786625d09527:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d0952d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d09533:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    786625d09539:	mov    rbx,QWORD PTR [r12+0x108]
    786625d09541:	mov    QWORD PTR [r12+0x378],0x2
    786625d0954d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d09556:	pushf
    786625d09557:	pop    rdx
    786625d09558:	and    rdx,0xfffffffffffff73e
    786625d0955f:	mov    rax,rbx
    786625d09562:	shr    rax,0x18
    786625d09566:	and    eax,0xc0
    786625d0956b:	or     rdx,rax
    786625d0956e:	mov    rax,rbx
    786625d09571:	shr    rax,0x1d
    786625d09575:	and    eax,0x1
    786625d09578:	xor    eax,0x1
    786625d0957b:	or     rdx,rax
    786625d0957e:	mov    rax,rbx
    786625d09581:	shr    rax,0x11
    786625d09585:	and    eax,0x800
    786625d0958a:	or     rdx,rax
    786625d0958d:	mov    QWORD PTR [rsp+0x10],rdx
    786625d09592:	stmxcsr DWORD PTR [rsp+0x120]
    786625d0959a:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d095a5:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d095ad:	add    rsp,0x8
    786625d095b1:	ret
    786625d095b2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d095c0:	sub    rsp,0x8
    786625d095c4:	stmxcsr DWORD PTR [rsp+0x124]
    786625d095cc:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d095d4:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d095dc:	shr    r11d,1
    786625d095df:	and    r11d,0x10
    786625d095e3:	or     DWORD PTR [r12+0x314],r11d
    786625d095eb:	mov    QWORD PTR [r12+0x378],0x3
    786625d095f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d095fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d09603:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    786625d09609:	push   rdx
    786625d0960a:	push   rsi
    786625d0960b:	push   r10
    786625d0960d:	push   r11
    786625d0960f:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d09614:	mov    r10d,edx
    786625d09617:	and    r10d,0xc0
    786625d0961e:	shl    r10d,0x18
    786625d09622:	mov    r11d,edx
    786625d09625:	and    r11d,0x1
    786625d09629:	shl    r11d,0x1d
    786625d0962d:	or     r10d,r11d
    786625d09630:	mov    r11d,edx
    786625d09633:	and    r11d,0x800
    786625d0963a:	shl    r11d,0x11
    786625d0963e:	or     r10d,r11d
    786625d09641:	btc    r10,0x1d
    786625d09646:	mov    r11d,0xf0000000
    786625d0964c:	and    r11,r10
    786625d0964f:	movabs rsi,0xffffffff0fffffff
    786625d09659:	and    rbx,rsi
    786625d0965c:	or     rbx,r11
    786625d0965f:	pop    r11
    786625d09661:	pop    r10
    786625d09663:	pop    rsi
    786625d09664:	pop    rdx
    786625d09665:	mov    QWORD PTR [r12+0x108],rbx
    786625d0966d:	stmxcsr DWORD PTR [r12-0x28]
    786625d09673:	ldmxcsr DWORD PTR [r12-0x38]
    786625d09679:	lea    rdi,[rsp+0x110]
    786625d09681:	lea    rsi,[rsp+0xf0]
    786625d09689:	lea    rdx,[rsp+0x100]
    786625d09691:	mov    ecx,0x14
    786625d09696:	mov    r8d,0x0
    786625d0969c:	lea    r9,[r12+0x314]
    786625d096a4:	movabs r11,0x5c9c39c4d1b0
    786625d096ae:	call   r11
    786625d096b1:	ldmxcsr DWORD PTR [r12-0x28]
    786625d096b7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d096bd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d096c3:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    786625d096c9:	mov    rbx,QWORD PTR [r12+0x108]
    786625d096d1:	mov    QWORD PTR [r12+0x378],0x2
    786625d096dd:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d096e6:	pushf
    786625d096e7:	pop    rdx
    786625d096e8:	and    rdx,0xfffffffffffff73e
    786625d096ef:	mov    rax,rbx
    786625d096f2:	shr    rax,0x18
    786625d096f6:	and    eax,0xc0
    786625d096fb:	or     rdx,rax
    786625d096fe:	mov    rax,rbx
    786625d09701:	shr    rax,0x1d
    786625d09705:	and    eax,0x1
    786625d09708:	xor    eax,0x1
    786625d0970b:	or     rdx,rax
    786625d0970e:	mov    rax,rbx
    786625d09711:	shr    rax,0x11
    786625d09715:	and    eax,0x800
    786625d0971a:	or     rdx,rax
    786625d0971d:	mov    QWORD PTR [rsp+0x10],rdx
    786625d09722:	stmxcsr DWORD PTR [rsp+0x120]
    786625d0972a:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d09735:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d0973d:	add    rsp,0x8
    786625d09741:	ret
    786625d09742:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d09750:	sub    rsp,0x8
    786625d09754:	stmxcsr DWORD PTR [rsp+0x124]
    786625d0975c:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d09764:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d0976c:	shr    r11d,1
    786625d0976f:	and    r11d,0x10
    786625d09773:	or     DWORD PTR [r12+0x314],r11d
    786625d0977b:	mov    QWORD PTR [r12+0x378],0x3
    786625d09787:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d0978d:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    786625d09793:	push   rdx
    786625d09794:	push   rsi
    786625d09795:	push   r10
    786625d09797:	push   r11
    786625d09799:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d0979e:	mov    r10d,edx
    786625d097a1:	and    r10d,0xc0
    786625d097a8:	shl    r10d,0x18
    786625d097ac:	mov    r11d,edx
    786625d097af:	and    r11d,0x1
    786625d097b3:	shl    r11d,0x1d
    786625d097b7:	or     r10d,r11d
    786625d097ba:	mov    r11d,edx
    786625d097bd:	and    r11d,0x800
    786625d097c4:	shl    r11d,0x11
    786625d097c8:	or     r10d,r11d
    786625d097cb:	btc    r10,0x1d
    786625d097d0:	mov    r11d,0xf0000000
    786625d097d6:	and    r11,r10
    786625d097d9:	movabs rsi,0xffffffff0fffffff
    786625d097e3:	and    rbx,rsi
    786625d097e6:	or     rbx,r11
    786625d097e9:	pop    r11
    786625d097eb:	pop    r10
    786625d097ed:	pop    rsi
    786625d097ee:	pop    rdx
    786625d097ef:	mov    QWORD PTR [r12+0x108],rbx
    786625d097f7:	stmxcsr DWORD PTR [r12-0x28]
    786625d097fd:	ldmxcsr DWORD PTR [r12-0x38]
    786625d09803:	lea    rdi,[rsp+0x110]
    786625d0980b:	lea    rsi,[rsp+0xf0]
    786625d09813:	lea    rdx,[rsp+0x100]
    786625d0981b:	mov    ecx,0x14
    786625d09820:	mov    r8d,0x0
    786625d09826:	lea    r9,[r12+0x314]
    786625d0982e:	movabs r11,0x5c9c39c4d1b0
    786625d09838:	call   r11
    786625d0983b:	ldmxcsr DWORD PTR [r12-0x28]
    786625d09841:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d09847:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    786625d0984d:	mov    rbx,QWORD PTR [r12+0x108]
    786625d09855:	mov    QWORD PTR [r12+0x378],0x2
    786625d09861:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d0986a:	pushf
    786625d0986b:	pop    rdx
    786625d0986c:	and    rdx,0xfffffffffffff73e
    786625d09873:	mov    rax,rbx
    786625d09876:	shr    rax,0x18
    786625d0987a:	and    eax,0xc0
    786625d0987f:	or     rdx,rax
    786625d09882:	mov    rax,rbx
    786625d09885:	shr    rax,0x1d
    786625d09889:	and    eax,0x1
    786625d0988c:	xor    eax,0x1
    786625d0988f:	or     rdx,rax
    786625d09892:	mov    rax,rbx
    786625d09895:	shr    rax,0x11
    786625d09899:	and    eax,0x800
    786625d0989e:	or     rdx,rax
    786625d098a1:	mov    QWORD PTR [rsp+0x10],rdx
    786625d098a6:	stmxcsr DWORD PTR [rsp+0x120]
    786625d098ae:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d098b9:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d098c1:	add    rsp,0x8
    786625d098c5:	ret
    786625d098c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d098d0:	sub    rsp,0x8
    786625d098d4:	stmxcsr DWORD PTR [rsp+0x124]
    786625d098dc:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d098e4:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d098ec:	shr    r11d,1
    786625d098ef:	and    r11d,0x10
    786625d098f3:	or     DWORD PTR [r12+0x314],r11d
    786625d098fb:	mov    QWORD PTR [r12+0x378],0x3
    786625d09907:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d0990d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    786625d09913:	push   rdx
    786625d09914:	push   rsi
    786625d09915:	push   r10
    786625d09917:	push   r11
    786625d09919:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d0991e:	mov    r10d,edx
    786625d09921:	and    r10d,0xc0
    786625d09928:	shl    r10d,0x18
    786625d0992c:	mov    r11d,edx
    786625d0992f:	and    r11d,0x1
    786625d09933:	shl    r11d,0x1d
    786625d09937:	or     r10d,r11d
    786625d0993a:	mov    r11d,edx
    786625d0993d:	and    r11d,0x800
    786625d09944:	shl    r11d,0x11
    786625d09948:	or     r10d,r11d
    786625d0994b:	btc    r10,0x1d
    786625d09950:	mov    r11d,0xf0000000
    786625d09956:	and    r11,r10
    786625d09959:	movabs rsi,0xffffffff0fffffff
    786625d09963:	and    rbx,rsi
    786625d09966:	or     rbx,r11
    786625d09969:	pop    r11
    786625d0996b:	pop    r10
    786625d0996d:	pop    rsi
    786625d0996e:	pop    rdx
    786625d0996f:	mov    QWORD PTR [r12+0x108],rbx
    786625d09977:	stmxcsr DWORD PTR [r12-0x28]
    786625d0997d:	ldmxcsr DWORD PTR [r12-0x38]
    786625d09983:	lea    rdi,[rsp+0x110]
    786625d0998b:	lea    rsi,[rsp+0xf0]
    786625d09993:	lea    rdx,[rsp+0x100]
    786625d0999b:	mov    ecx,0xc
    786625d099a0:	mov    r8d,0x0
    786625d099a6:	lea    r9,[r12+0x314]
    786625d099ae:	movabs r11,0x5c9c39c4d1b0
    786625d099b8:	call   r11
    786625d099bb:	ldmxcsr DWORD PTR [r12-0x28]
    786625d099c1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d099c7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    786625d099cd:	mov    rbx,QWORD PTR [r12+0x108]
    786625d099d5:	mov    QWORD PTR [r12+0x378],0x2
    786625d099e1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d099ea:	pushf
    786625d099eb:	pop    rdx
    786625d099ec:	and    rdx,0xfffffffffffff73e
    786625d099f3:	mov    rax,rbx
    786625d099f6:	shr    rax,0x18
    786625d099fa:	and    eax,0xc0
    786625d099ff:	or     rdx,rax
    786625d09a02:	mov    rax,rbx
    786625d09a05:	shr    rax,0x1d
    786625d09a09:	and    eax,0x1
    786625d09a0c:	xor    eax,0x1
    786625d09a0f:	or     rdx,rax
    786625d09a12:	mov    rax,rbx
    786625d09a15:	shr    rax,0x11
    786625d09a19:	and    eax,0x800
    786625d09a1e:	or     rdx,rax
    786625d09a21:	mov    QWORD PTR [rsp+0x10],rdx
    786625d09a26:	stmxcsr DWORD PTR [rsp+0x120]
    786625d09a2e:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d09a39:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d09a41:	add    rsp,0x8
    786625d09a45:	ret
    786625d09a46:	data16 nop WORD PTR [rax+rax*1+0x0]
    786625d09a50:	sub    rsp,0x8
    786625d09a54:	stmxcsr DWORD PTR [rsp+0x124]
    786625d09a5c:	ldmxcsr DWORD PTR [rsp+0x120]
    786625d09a64:	mov    r11d,DWORD PTR [rsp+0x124]
    786625d09a6c:	shr    r11d,1
    786625d09a6f:	and    r11d,0x10
    786625d09a73:	or     DWORD PTR [r12+0x314],r11d
    786625d09a7b:	mov    QWORD PTR [r12+0x378],0x3
    786625d09a87:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    786625d09a8d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    786625d09a93:	push   rdx
    786625d09a94:	push   rsi
    786625d09a95:	push   r10
    786625d09a97:	push   r11
    786625d09a99:	mov    rdx,QWORD PTR [rsp+0x30]
    786625d09a9e:	mov    r10d,edx
    786625d09aa1:	and    r10d,0xc0
    786625d09aa8:	shl    r10d,0x18
    786625d09aac:	mov    r11d,edx
    786625d09aaf:	and    r11d,0x1
    786625d09ab3:	shl    r11d,0x1d
    786625d09ab7:	or     r10d,r11d
    786625d09aba:	mov    r11d,edx
    786625d09abd:	and    r11d,0x800
    786625d09ac4:	shl    r11d,0x11
    786625d09ac8:	or     r10d,r11d
    786625d09acb:	btc    r10,0x1d
    786625d09ad0:	mov    r11d,0xf0000000
    786625d09ad6:	and    r11,r10
    786625d09ad9:	movabs rsi,0xffffffff0fffffff
    786625d09ae3:	and    rbx,rsi
    786625d09ae6:	or     rbx,r11
    786625d09ae9:	pop    r11
    786625d09aeb:	pop    r10
    786625d09aed:	pop    rsi
    786625d09aee:	pop    rdx
    786625d09aef:	mov    QWORD PTR [r12+0x108],rbx
    786625d09af7:	stmxcsr DWORD PTR [r12-0x28]
    786625d09afd:	ldmxcsr DWORD PTR [r12-0x38]
    786625d09b03:	lea    rdi,[rsp+0x110]
    786625d09b0b:	lea    rsi,[rsp+0xf0]
    786625d09b13:	lea    rdx,[rsp+0x100]
    786625d09b1b:	mov    ecx,0xc
    786625d09b20:	mov    r8d,0x0
    786625d09b26:	lea    r9,[r12+0x314]
    786625d09b2e:	movabs r11,0x5c9c39c4d1b0
    786625d09b38:	call   r11
    786625d09b3b:	ldmxcsr DWORD PTR [r12-0x28]
    786625d09b41:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    786625d09b47:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    786625d09b4d:	mov    rbx,QWORD PTR [r12+0x108]
    786625d09b55:	mov    QWORD PTR [r12+0x378],0x2
    786625d09b61:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    786625d09b6a:	pushf
    786625d09b6b:	pop    rdx
    786625d09b6c:	and    rdx,0xfffffffffffff73e
    786625d09b73:	mov    rax,rbx
    786625d09b76:	shr    rax,0x18
    786625d09b7a:	and    eax,0xc0
    786625d09b7f:	or     rdx,rax
    786625d09b82:	mov    rax,rbx
    786625d09b85:	shr    rax,0x1d
    786625d09b89:	and    eax,0x1
    786625d09b8c:	xor    eax,0x1
    786625d09b8f:	or     rdx,rax
    786625d09b92:	mov    rax,rbx
    786625d09b95:	shr    rax,0x11
    786625d09b99:	and    eax,0x800
    786625d09b9e:	or     rdx,rax
    786625d09ba1:	mov    QWORD PTR [rsp+0x10],rdx
    786625d09ba6:	stmxcsr DWORD PTR [rsp+0x120]
    786625d09bae:	mov    DWORD PTR [rsp+0x124],0x1f80
    786625d09bb9:	ldmxcsr DWORD PTR [rsp+0x124]
    786625d09bc1:	add    rsp,0x8
    786625d09bc5:	ret
    786625d09bc6:	mov    eax,0x410400
    786625d09bcb:	mov    QWORD PTR [r12+0x100],rax
    786625d09bd3:	push   rdx
    786625d09bd4:	push   rsi
    786625d09bd5:	push   r10
    786625d09bd7:	push   r11
    786625d09bd9:	pushf
    786625d09bda:	pop    r11
    786625d09bdc:	mov    QWORD PTR [rsp+0x20],r11
    786625d09be1:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d09be6:	mov    r10d,edx
    786625d09be9:	and    r10d,0xc0
    786625d09bf0:	shl    r10d,0x18
    786625d09bf4:	mov    r11d,edx
    786625d09bf7:	and    r11d,0x1
    786625d09bfb:	shl    r11d,0x1d
    786625d09bff:	or     r10d,r11d
    786625d09c02:	mov    r11d,edx
    786625d09c05:	and    r11d,0x800
    786625d09c0c:	shl    r11d,0x11
    786625d09c10:	or     r10d,r11d
    786625d09c13:	btc    r10,0x1d
    786625d09c18:	mov    r11d,0xf0000000
    786625d09c1e:	and    r11,r10
    786625d09c21:	movabs rsi,0xffffffff0fffffff
    786625d09c2b:	and    rbx,rsi
    786625d09c2e:	or     rbx,r11
    786625d09c31:	pop    r11
    786625d09c33:	pop    r10
    786625d09c35:	pop    rsi
    786625d09c36:	pop    rdx
    786625d09c37:	mov    QWORD PTR [r12+0x108],rbx
    786625d09c3f:	add    rsp,0x150
    786625d09c46:	mov    eax,0xc
    786625d09c4b:	movabs r11,0x5c9c39de2390
    786625d09c55:	jmp    r11
    786625d09c58:	mov    eax,0x41048c
    786625d09c5d:	mov    QWORD PTR [r12+0x100],rax
    786625d09c65:	push   rdx
    786625d09c66:	push   rsi
    786625d09c67:	push   r10
    786625d09c69:	push   r11
    786625d09c6b:	pushf
    786625d09c6c:	pop    r11
    786625d09c6e:	mov    QWORD PTR [rsp+0x20],r11
    786625d09c73:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d09c78:	mov    r10d,edx
    786625d09c7b:	and    r10d,0xc0
    786625d09c82:	shl    r10d,0x18
    786625d09c86:	mov    r11d,edx
    786625d09c89:	and    r11d,0x1
    786625d09c8d:	shl    r11d,0x1d
    786625d09c91:	or     r10d,r11d
    786625d09c94:	mov    r11d,edx
    786625d09c97:	and    r11d,0x800
    786625d09c9e:	shl    r11d,0x11
    786625d09ca2:	or     r10d,r11d
    786625d09ca5:	btc    r10,0x1d
    786625d09caa:	mov    r11d,0xf0000000
    786625d09cb0:	and    r11,r10
    786625d09cb3:	movabs rsi,0xffffffff0fffffff
    786625d09cbd:	and    rbx,rsi
    786625d09cc0:	or     rbx,r11
    786625d09cc3:	pop    r11
    786625d09cc5:	pop    r10
    786625d09cc7:	pop    rsi
    786625d09cc8:	pop    rdx
    786625d09cc9:	mov    QWORD PTR [r12+0x108],rbx
    786625d09cd1:	add    rsp,0x150
    786625d09cd8:	mov    eax,0xc
    786625d09cdd:	movabs r11,0x5c9c39de2390
    786625d09ce7:	jmp    r11
    786625d09cea:	mov    eax,0x4106cc
    786625d09cef:	mov    QWORD PTR [r12+0x100],rax
    786625d09cf7:	push   rdx
    786625d09cf8:	push   rsi
    786625d09cf9:	push   r10
    786625d09cfb:	push   r11
    786625d09cfd:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d09d02:	mov    r10d,edx
    786625d09d05:	and    r10d,0xc0
    786625d09d0c:	shl    r10d,0x18
    786625d09d10:	mov    r11d,edx
    786625d09d13:	and    r11d,0x1
    786625d09d17:	shl    r11d,0x1d
    786625d09d1b:	or     r10d,r11d
    786625d09d1e:	mov    r11d,edx
    786625d09d21:	and    r11d,0x800
    786625d09d28:	shl    r11d,0x11
    786625d09d2c:	or     r10d,r11d
    786625d09d2f:	btc    r10,0x1d
    786625d09d34:	mov    r11d,0xf0000000
    786625d09d3a:	and    r11,r10
    786625d09d3d:	movabs rsi,0xffffffff0fffffff
    786625d09d47:	and    rbx,rsi
    786625d09d4a:	or     rbx,r11
    786625d09d4d:	pop    r11
    786625d09d4f:	pop    r10
    786625d09d51:	pop    rsi
    786625d09d52:	pop    rdx
    786625d09d53:	mov    QWORD PTR [r12+0x108],rbx
    786625d09d5b:	add    rsp,0x150
    786625d09d62:	mov    eax,0xc
    786625d09d67:	movabs r11,0x5c9c39de2390
    786625d09d71:	jmp    r11
    786625d09d74:	mov    eax,0x4106d8
    786625d09d79:	mov    QWORD PTR [r12+0x100],rax
    786625d09d81:	push   rdx
    786625d09d82:	push   rsi
    786625d09d83:	push   r10
    786625d09d85:	push   r11
    786625d09d87:	pushf
    786625d09d88:	pop    r11
    786625d09d8a:	mov    QWORD PTR [rsp+0x20],r11
    786625d09d8f:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d09d94:	mov    r10d,edx
    786625d09d97:	and    r10d,0xc0
    786625d09d9e:	shl    r10d,0x18
    786625d09da2:	mov    r11d,edx
    786625d09da5:	and    r11d,0x1
    786625d09da9:	shl    r11d,0x1d
    786625d09dad:	or     r10d,r11d
    786625d09db0:	mov    r11d,edx
    786625d09db3:	and    r11d,0x800
    786625d09dba:	shl    r11d,0x11
    786625d09dbe:	or     r10d,r11d
    786625d09dc1:	btc    r10,0x1d
    786625d09dc6:	mov    r11d,0xf0000000
    786625d09dcc:	and    r11,r10
    786625d09dcf:	movabs rsi,0xffffffff0fffffff
    786625d09dd9:	and    rbx,rsi
    786625d09ddc:	or     rbx,r11
    786625d09ddf:	pop    r11
    786625d09de1:	pop    r10
    786625d09de3:	pop    rsi
    786625d09de4:	pop    rdx
    786625d09de5:	mov    QWORD PTR [r12+0x108],rbx
    786625d09ded:	add    rsp,0x150
    786625d09df4:	mov    eax,0xc
    786625d09df9:	movabs r11,0x5c9c39de2390
    786625d09e03:	jmp    r11
    786625d09e06:	mov    eax,0x410700
    786625d09e0b:	mov    QWORD PTR [r12+0x100],rax
    786625d09e13:	push   rdx
    786625d09e14:	push   rsi
    786625d09e15:	push   r10
    786625d09e17:	push   r11
    786625d09e19:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d09e1e:	mov    r10d,edx
    786625d09e21:	and    r10d,0xc0
    786625d09e28:	shl    r10d,0x18
    786625d09e2c:	mov    r11d,edx
    786625d09e2f:	and    r11d,0x1
    786625d09e33:	shl    r11d,0x1d
    786625d09e37:	or     r10d,r11d
    786625d09e3a:	mov    r11d,edx
    786625d09e3d:	and    r11d,0x800
    786625d09e44:	shl    r11d,0x11
    786625d09e48:	or     r10d,r11d
    786625d09e4b:	btc    r10,0x1d
    786625d09e50:	mov    r11d,0xf0000000
    786625d09e56:	and    r11,r10
    786625d09e59:	movabs rsi,0xffffffff0fffffff
    786625d09e63:	and    rbx,rsi
    786625d09e66:	or     rbx,r11
    786625d09e69:	pop    r11
    786625d09e6b:	pop    r10
    786625d09e6d:	pop    rsi
    786625d09e6e:	pop    rdx
    786625d09e6f:	mov    QWORD PTR [r12+0x108],rbx
    786625d09e77:	add    rsp,0x150
    786625d09e7e:	mov    eax,0xc
    786625d09e83:	movabs r11,0x5c9c39de2390
    786625d09e8d:	jmp    r11
    786625d09e90:	mov    eax,0x410724
    786625d09e95:	mov    QWORD PTR [r12+0x100],rax
    786625d09e9d:	push   rdx
    786625d09e9e:	push   rsi
    786625d09e9f:	push   r10
    786625d09ea1:	push   r11
    786625d09ea3:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d09ea8:	mov    r10d,edx
    786625d09eab:	and    r10d,0xc0
    786625d09eb2:	shl    r10d,0x18
    786625d09eb6:	mov    r11d,edx
    786625d09eb9:	and    r11d,0x1
    786625d09ebd:	shl    r11d,0x1d
    786625d09ec1:	or     r10d,r11d
    786625d09ec4:	mov    r11d,edx
    786625d09ec7:	and    r11d,0x800
    786625d09ece:	shl    r11d,0x11
    786625d09ed2:	or     r10d,r11d
    786625d09ed5:	btc    r10,0x1d
    786625d09eda:	mov    r11d,0xf0000000
    786625d09ee0:	and    r11,r10
    786625d09ee3:	movabs rsi,0xffffffff0fffffff
    786625d09eed:	and    rbx,rsi
    786625d09ef0:	or     rbx,r11
    786625d09ef3:	pop    r11
    786625d09ef5:	pop    r10
    786625d09ef7:	pop    rsi
    786625d09ef8:	pop    rdx
    786625d09ef9:	mov    QWORD PTR [r12+0x108],rbx
    786625d09f01:	add    rsp,0x150
    786625d09f08:	mov    eax,0xc
    786625d09f0d:	movabs r11,0x5c9c39de2390
    786625d09f17:	jmp    r11
    786625d09f1a:	nop    WORD PTR [rax+rax*1+0x0]
    786625d09f20:	sub    rsp,0x150
    786625d09f27:	mov    r11,QWORD PTR [r12+0x398]
    786625d09f2f:	mov    QWORD PTR [rsp],r11
    786625d09f33:	cmp    DWORD PTR [r12+0x310],0x0
    786625d09f3c:	je     0x786625d09fcc
    786625d09f42:	push   rdx
    786625d09f43:	push   rsi
    786625d09f44:	push   r10
    786625d09f46:	push   r11
    786625d09f48:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d09f4d:	mov    r10d,edx
    786625d09f50:	and    r10d,0xc0
    786625d09f57:	shl    r10d,0x18
    786625d09f5b:	mov    r11d,edx
    786625d09f5e:	and    r11d,0x1
    786625d09f62:	shl    r11d,0x1d
    786625d09f66:	or     r10d,r11d
    786625d09f69:	mov    r11d,edx
    786625d09f6c:	and    r11d,0x800
    786625d09f73:	shl    r11d,0x11
    786625d09f77:	or     r10d,r11d
    786625d09f7a:	btc    r10,0x1d
    786625d09f7f:	mov    r11d,0xf0000000
    786625d09f85:	and    r11,r10
    786625d09f88:	movabs rsi,0xffffffff0fffffff
    786625d09f92:	and    rbx,rsi
    786625d09f95:	or     rbx,r11
    786625d09f98:	pop    r11
    786625d09f9a:	pop    r10
    786625d09f9c:	pop    rsi
    786625d09f9d:	pop    rdx
    786625d09f9e:	mov    QWORD PTR [r12+0x108],rbx
    786625d09fa6:	mov    eax,0x410404
    786625d09fab:	mov    QWORD PTR [r12+0x100],rax
    786625d09fb3:	add    rsp,0x150
    786625d09fba:	mov    eax,0x3
    786625d09fbf:	movabs r11,0x5c9c39de2390
    786625d09fc9:	jmp    r11
    786625d09fcc:	jmp    0x786625d02ce8
    786625d09fd1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d09fe0:	sub    rsp,0x150
    786625d09fe7:	mov    r11,QWORD PTR [r12+0x398]
    786625d09fef:	mov    QWORD PTR [rsp],r11
    786625d09ff3:	cmp    DWORD PTR [r12+0x310],0x0
    786625d09ffc:	je     0x786625d0a08c
    786625d0a002:	push   rdx
    786625d0a003:	push   rsi
    786625d0a004:	push   r10
    786625d0a006:	push   r11
    786625d0a008:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0a00d:	mov    r10d,edx
    786625d0a010:	and    r10d,0xc0
    786625d0a017:	shl    r10d,0x18
    786625d0a01b:	mov    r11d,edx
    786625d0a01e:	and    r11d,0x1
    786625d0a022:	shl    r11d,0x1d
    786625d0a026:	or     r10d,r11d
    786625d0a029:	mov    r11d,edx
    786625d0a02c:	and    r11d,0x800
    786625d0a033:	shl    r11d,0x11
    786625d0a037:	or     r10d,r11d
    786625d0a03a:	btc    r10,0x1d
    786625d0a03f:	mov    r11d,0xf0000000
    786625d0a045:	and    r11,r10
    786625d0a048:	movabs rsi,0xffffffff0fffffff
    786625d0a052:	and    rbx,rsi
    786625d0a055:	or     rbx,r11
    786625d0a058:	pop    r11
    786625d0a05a:	pop    r10
    786625d0a05c:	pop    rsi
    786625d0a05d:	pop    rdx
    786625d0a05e:	mov    QWORD PTR [r12+0x108],rbx
    786625d0a066:	mov    eax,0x410450
    786625d0a06b:	mov    QWORD PTR [r12+0x100],rax
    786625d0a073:	add    rsp,0x150
    786625d0a07a:	mov    eax,0x3
    786625d0a07f:	movabs r11,0x5c9c39de2390
    786625d0a089:	jmp    r11
    786625d0a08c:	jmp    0x786625d02e52
    786625d0a091:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d0a0a0:	sub    rsp,0x150
    786625d0a0a7:	mov    r11,QWORD PTR [r12+0x398]
    786625d0a0af:	mov    QWORD PTR [rsp],r11
    786625d0a0b3:	cmp    DWORD PTR [r12+0x310],0x0
    786625d0a0bc:	je     0x786625d0a14c
    786625d0a0c2:	push   rdx
    786625d0a0c3:	push   rsi
    786625d0a0c4:	push   r10
    786625d0a0c6:	push   r11
    786625d0a0c8:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0a0cd:	mov    r10d,edx
    786625d0a0d0:	and    r10d,0xc0
    786625d0a0d7:	shl    r10d,0x18
    786625d0a0db:	mov    r11d,edx
    786625d0a0de:	and    r11d,0x1
    786625d0a0e2:	shl    r11d,0x1d
    786625d0a0e6:	or     r10d,r11d
    786625d0a0e9:	mov    r11d,edx
    786625d0a0ec:	and    r11d,0x800
    786625d0a0f3:	shl    r11d,0x11
    786625d0a0f7:	or     r10d,r11d
    786625d0a0fa:	btc    r10,0x1d
    786625d0a0ff:	mov    r11d,0xf0000000
    786625d0a105:	and    r11,r10
    786625d0a108:	movabs rsi,0xffffffff0fffffff
    786625d0a112:	and    rbx,rsi
    786625d0a115:	or     rbx,r11
    786625d0a118:	pop    r11
    786625d0a11a:	pop    r10
    786625d0a11c:	pop    rsi
    786625d0a11d:	pop    rdx
    786625d0a11e:	mov    QWORD PTR [r12+0x108],rbx
    786625d0a126:	mov    eax,0x410490
    786625d0a12b:	mov    QWORD PTR [r12+0x100],rax
    786625d0a133:	add    rsp,0x150
    786625d0a13a:	mov    eax,0x3
    786625d0a13f:	movabs r11,0x5c9c39de2390
    786625d0a149:	jmp    r11
    786625d0a14c:	jmp    0x786625d033c8
    786625d0a151:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d0a160:	sub    rsp,0x150
    786625d0a167:	mov    r11,QWORD PTR [r12+0x398]
    786625d0a16f:	mov    QWORD PTR [rsp],r11
    786625d0a173:	cmp    DWORD PTR [r12+0x310],0x0
    786625d0a17c:	je     0x786625d0a20c
    786625d0a182:	push   rdx
    786625d0a183:	push   rsi
    786625d0a184:	push   r10
    786625d0a186:	push   r11
    786625d0a188:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0a18d:	mov    r10d,edx
    786625d0a190:	and    r10d,0xc0
    786625d0a197:	shl    r10d,0x18
    786625d0a19b:	mov    r11d,edx
    786625d0a19e:	and    r11d,0x1
    786625d0a1a2:	shl    r11d,0x1d
    786625d0a1a6:	or     r10d,r11d
    786625d0a1a9:	mov    r11d,edx
    786625d0a1ac:	and    r11d,0x800
    786625d0a1b3:	shl    r11d,0x11
    786625d0a1b7:	or     r10d,r11d
    786625d0a1ba:	btc    r10,0x1d
    786625d0a1bf:	mov    r11d,0xf0000000
    786625d0a1c5:	and    r11,r10
    786625d0a1c8:	movabs rsi,0xffffffff0fffffff
    786625d0a1d2:	and    rbx,rsi
    786625d0a1d5:	or     rbx,r11
    786625d0a1d8:	pop    r11
    786625d0a1da:	pop    r10
    786625d0a1dc:	pop    rsi
    786625d0a1dd:	pop    rdx
    786625d0a1de:	mov    QWORD PTR [r12+0x108],rbx
    786625d0a1e6:	mov    eax,0x410500
    786625d0a1eb:	mov    QWORD PTR [r12+0x100],rax
    786625d0a1f3:	add    rsp,0x150
    786625d0a1fa:	mov    eax,0x3
    786625d0a1ff:	movabs r11,0x5c9c39de2390
    786625d0a209:	jmp    r11
    786625d0a20c:	jmp    0x786625d03a08
    786625d0a211:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d0a220:	sub    rsp,0x150
    786625d0a227:	mov    r11,QWORD PTR [r12+0x398]
    786625d0a22f:	mov    QWORD PTR [rsp],r11
    786625d0a233:	cmp    DWORD PTR [r12+0x310],0x0
    786625d0a23c:	je     0x786625d0a2cc
    786625d0a242:	push   rdx
    786625d0a243:	push   rsi
    786625d0a244:	push   r10
    786625d0a246:	push   r11
    786625d0a248:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0a24d:	mov    r10d,edx
    786625d0a250:	and    r10d,0xc0
    786625d0a257:	shl    r10d,0x18
    786625d0a25b:	mov    r11d,edx
    786625d0a25e:	and    r11d,0x1
    786625d0a262:	shl    r11d,0x1d
    786625d0a266:	or     r10d,r11d
    786625d0a269:	mov    r11d,edx
    786625d0a26c:	and    r11d,0x800
    786625d0a273:	shl    r11d,0x11
    786625d0a277:	or     r10d,r11d
    786625d0a27a:	btc    r10,0x1d
    786625d0a27f:	mov    r11d,0xf0000000
    786625d0a285:	and    r11,r10
    786625d0a288:	movabs rsi,0xffffffff0fffffff
    786625d0a292:	and    rbx,rsi
    786625d0a295:	or     rbx,r11
    786625d0a298:	pop    r11
    786625d0a29a:	pop    r10
    786625d0a29c:	pop    rsi
    786625d0a29d:	pop    rdx
    786625d0a29e:	mov    QWORD PTR [r12+0x108],rbx
    786625d0a2a6:	mov    eax,0x410504
    786625d0a2ab:	mov    QWORD PTR [r12+0x100],rax
    786625d0a2b3:	add    rsp,0x150
    786625d0a2ba:	mov    eax,0x3
    786625d0a2bf:	movabs r11,0x5c9c39de2390
    786625d0a2c9:	jmp    r11
    786625d0a2cc:	jmp    0x786625d03a18
    786625d0a2d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d0a2e0:	sub    rsp,0x150
    786625d0a2e7:	mov    r11,QWORD PTR [r12+0x398]
    786625d0a2ef:	mov    QWORD PTR [rsp],r11
    786625d0a2f3:	cmp    DWORD PTR [r12+0x310],0x0
    786625d0a2fc:	je     0x786625d0a38c
    786625d0a302:	push   rdx
    786625d0a303:	push   rsi
    786625d0a304:	push   r10
    786625d0a306:	push   r11
    786625d0a308:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0a30d:	mov    r10d,edx
    786625d0a310:	and    r10d,0xc0
    786625d0a317:	shl    r10d,0x18
    786625d0a31b:	mov    r11d,edx
    786625d0a31e:	and    r11d,0x1
    786625d0a322:	shl    r11d,0x1d
    786625d0a326:	or     r10d,r11d
    786625d0a329:	mov    r11d,edx
    786625d0a32c:	and    r11d,0x800
    786625d0a333:	shl    r11d,0x11
    786625d0a337:	or     r10d,r11d
    786625d0a33a:	btc    r10,0x1d
    786625d0a33f:	mov    r11d,0xf0000000
    786625d0a345:	and    r11,r10
    786625d0a348:	movabs rsi,0xffffffff0fffffff
    786625d0a352:	and    rbx,rsi
    786625d0a355:	or     rbx,r11
    786625d0a358:	pop    r11
    786625d0a35a:	pop    r10
    786625d0a35c:	pop    rsi
    786625d0a35d:	pop    rdx
    786625d0a35e:	mov    QWORD PTR [r12+0x108],rbx
    786625d0a366:	mov    eax,0x4106d0
    786625d0a36b:	mov    QWORD PTR [r12+0x100],rax
    786625d0a373:	add    rsp,0x150
    786625d0a37a:	mov    eax,0x3
    786625d0a37f:	movabs r11,0x5c9c39de2390
    786625d0a389:	jmp    r11
    786625d0a38c:	jmp    0x786625d075dd
    786625d0a391:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d0a3a0:	sub    rsp,0x150
    786625d0a3a7:	mov    r11,QWORD PTR [r12+0x398]
    786625d0a3af:	mov    QWORD PTR [rsp],r11
    786625d0a3b3:	cmp    DWORD PTR [r12+0x310],0x0
    786625d0a3bc:	je     0x786625d0a44c
    786625d0a3c2:	push   rdx
    786625d0a3c3:	push   rsi
    786625d0a3c4:	push   r10
    786625d0a3c6:	push   r11
    786625d0a3c8:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0a3cd:	mov    r10d,edx
    786625d0a3d0:	and    r10d,0xc0
    786625d0a3d7:	shl    r10d,0x18
    786625d0a3db:	mov    r11d,edx
    786625d0a3de:	and    r11d,0x1
    786625d0a3e2:	shl    r11d,0x1d
    786625d0a3e6:	or     r10d,r11d
    786625d0a3e9:	mov    r11d,edx
    786625d0a3ec:	and    r11d,0x800
    786625d0a3f3:	shl    r11d,0x11
    786625d0a3f7:	or     r10d,r11d
    786625d0a3fa:	btc    r10,0x1d
    786625d0a3ff:	mov    r11d,0xf0000000
    786625d0a405:	and    r11,r10
    786625d0a408:	movabs rsi,0xffffffff0fffffff
    786625d0a412:	and    rbx,rsi
    786625d0a415:	or     rbx,r11
    786625d0a418:	pop    r11
    786625d0a41a:	pop    r10
    786625d0a41c:	pop    rsi
    786625d0a41d:	pop    rdx
    786625d0a41e:	mov    QWORD PTR [r12+0x108],rbx
    786625d0a426:	mov    eax,0x4106dc
    786625d0a42b:	mov    QWORD PTR [r12+0x100],rax
    786625d0a433:	add    rsp,0x150
    786625d0a43a:	mov    eax,0x3
    786625d0a43f:	movabs r11,0x5c9c39de2390
    786625d0a449:	jmp    r11
    786625d0a44c:	jmp    0x786625d07613
    786625d0a451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d0a460:	sub    rsp,0x150
    786625d0a467:	mov    r11,QWORD PTR [r12+0x398]
    786625d0a46f:	mov    QWORD PTR [rsp],r11
    786625d0a473:	cmp    DWORD PTR [r12+0x310],0x0
    786625d0a47c:	je     0x786625d0a50c
    786625d0a482:	push   rdx
    786625d0a483:	push   rsi
    786625d0a484:	push   r10
    786625d0a486:	push   r11
    786625d0a488:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0a48d:	mov    r10d,edx
    786625d0a490:	and    r10d,0xc0
    786625d0a497:	shl    r10d,0x18
    786625d0a49b:	mov    r11d,edx
    786625d0a49e:	and    r11d,0x1
    786625d0a4a2:	shl    r11d,0x1d
    786625d0a4a6:	or     r10d,r11d
    786625d0a4a9:	mov    r11d,edx
    786625d0a4ac:	and    r11d,0x800
    786625d0a4b3:	shl    r11d,0x11
    786625d0a4b7:	or     r10d,r11d
    786625d0a4ba:	btc    r10,0x1d
    786625d0a4bf:	mov    r11d,0xf0000000
    786625d0a4c5:	and    r11,r10
    786625d0a4c8:	movabs rsi,0xffffffff0fffffff
    786625d0a4d2:	and    rbx,rsi
    786625d0a4d5:	or     rbx,r11
    786625d0a4d8:	pop    r11
    786625d0a4da:	pop    r10
    786625d0a4dc:	pop    rsi
    786625d0a4dd:	pop    rdx
    786625d0a4de:	mov    QWORD PTR [r12+0x108],rbx
    786625d0a4e6:	mov    eax,0x4106e8
    786625d0a4eb:	mov    QWORD PTR [r12+0x100],rax
    786625d0a4f3:	add    rsp,0x150
    786625d0a4fa:	mov    eax,0x3
    786625d0a4ff:	movabs r11,0x5c9c39de2390
    786625d0a509:	jmp    r11
    786625d0a50c:	jmp    0x786625d0764e
    786625d0a511:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d0a520:	sub    rsp,0x150
    786625d0a527:	mov    r11,QWORD PTR [r12+0x398]
    786625d0a52f:	mov    QWORD PTR [rsp],r11
    786625d0a533:	cmp    DWORD PTR [r12+0x310],0x0
    786625d0a53c:	je     0x786625d0a5cc
    786625d0a542:	push   rdx
    786625d0a543:	push   rsi
    786625d0a544:	push   r10
    786625d0a546:	push   r11
    786625d0a548:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0a54d:	mov    r10d,edx
    786625d0a550:	and    r10d,0xc0
    786625d0a557:	shl    r10d,0x18
    786625d0a55b:	mov    r11d,edx
    786625d0a55e:	and    r11d,0x1
    786625d0a562:	shl    r11d,0x1d
    786625d0a566:	or     r10d,r11d
    786625d0a569:	mov    r11d,edx
    786625d0a56c:	and    r11d,0x800
    786625d0a573:	shl    r11d,0x11
    786625d0a577:	or     r10d,r11d
    786625d0a57a:	btc    r10,0x1d
    786625d0a57f:	mov    r11d,0xf0000000
    786625d0a585:	and    r11,r10
    786625d0a588:	movabs rsi,0xffffffff0fffffff
    786625d0a592:	and    rbx,rsi
    786625d0a595:	or     rbx,r11
    786625d0a598:	pop    r11
    786625d0a59a:	pop    r10
    786625d0a59c:	pop    rsi
    786625d0a59d:	pop    rdx
    786625d0a59e:	mov    QWORD PTR [r12+0x108],rbx
    786625d0a5a6:	mov    eax,0x410704
    786625d0a5ab:	mov    QWORD PTR [r12+0x100],rax
    786625d0a5b3:	add    rsp,0x150
    786625d0a5ba:	mov    eax,0x3
    786625d0a5bf:	movabs r11,0x5c9c39de2390
    786625d0a5c9:	jmp    r11
    786625d0a5cc:	jmp    0x786625d077e6
    786625d0a5d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d0a5e0:	sub    rsp,0x150
    786625d0a5e7:	mov    r11,QWORD PTR [r12+0x398]
    786625d0a5ef:	mov    QWORD PTR [rsp],r11
    786625d0a5f3:	cmp    DWORD PTR [r12+0x310],0x0
    786625d0a5fc:	je     0x786625d0a68c
    786625d0a602:	push   rdx
    786625d0a603:	push   rsi
    786625d0a604:	push   r10
    786625d0a606:	push   r11
    786625d0a608:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0a60d:	mov    r10d,edx
    786625d0a610:	and    r10d,0xc0
    786625d0a617:	shl    r10d,0x18
    786625d0a61b:	mov    r11d,edx
    786625d0a61e:	and    r11d,0x1
    786625d0a622:	shl    r11d,0x1d
    786625d0a626:	or     r10d,r11d
    786625d0a629:	mov    r11d,edx
    786625d0a62c:	and    r11d,0x800
    786625d0a633:	shl    r11d,0x11
    786625d0a637:	or     r10d,r11d
    786625d0a63a:	btc    r10,0x1d
    786625d0a63f:	mov    r11d,0xf0000000
    786625d0a645:	and    r11,r10
    786625d0a648:	movabs rsi,0xffffffff0fffffff
    786625d0a652:	and    rbx,rsi
    786625d0a655:	or     rbx,r11
    786625d0a658:	pop    r11
    786625d0a65a:	pop    r10
    786625d0a65c:	pop    rsi
    786625d0a65d:	pop    rdx
    786625d0a65e:	mov    QWORD PTR [r12+0x108],rbx
    786625d0a666:	mov    eax,0x4103f0
    786625d0a66b:	mov    QWORD PTR [r12+0x100],rax
    786625d0a673:	add    rsp,0x150
    786625d0a67a:	mov    eax,0x3
    786625d0a67f:	movabs r11,0x5c9c39de2390
    786625d0a689:	jmp    r11
    786625d0a68c:	jmp    0x786625d079cf
    786625d0a691:	nop
    786625d0a692:	nop
    786625d0a693:	nop
