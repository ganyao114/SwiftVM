
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/0/2.bin:     file format binary


Disassembly of section .data:

00007c33ec901570 <.data>:
    7c33ec901570:	sub    rsp,0x10
    7c33ec901574:	mov    r13d,DWORD PTR [r12+0xa0]
    7c33ec90157c:	sub    r13d,0x1
    7c33ec901580:	mov    QWORD PTR [r12+0xa0],r13
    7c33ec901588:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec901590:	jrcxz  0x7c33ec901597
    7c33ec901592:	jmp    0x7c33ec901715
    7c33ec901597:	pushf
    7c33ec901598:	pop    r11
    7c33ec90159a:	mov    QWORD PTR [rsp],r11
    7c33ec90159e:	jne    0x7c33ec90167d
    7c33ec9015a4:	jmp    0x7c33ec9015a9
    7c33ec9015a9:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9015b1:	mov    r14,r13
    7c33ec9015b4:	add    r14,0x120
    7c33ec9015bb:	mov    r15,QWORD PTR [r14]
    7c33ec9015be:	mov    QWORD PTR [r12+0x98],r15
    7c33ec9015c6:	mov    r14d,0x80
    7c33ec9015cc:	mov    QWORD PTR [r12+0x40],r14
    7c33ec9015d1:	mov    r14,r13
    7c33ec9015d4:	add    r14,0x100
    7c33ec9015db:	mov    QWORD PTR [r12],r14
    7c33ec9015df:	mov    r14,r13
    7c33ec9015e2:	add    r14,0x17c
    7c33ec9015e9:	mov    QWORD PTR [r12+0x8],r14
    7c33ec9015ee:	mov    r14d,0x1
    7c33ec9015f4:	mov    QWORD PTR [r12+0x10],r14
    7c33ec9015f9:	add    r13,0x17c
    7c33ec901600:	movzx  r14d,BYTE PTR [r12+0x40]
    7c33ec901606:	mov    BYTE PTR [r13+0x0],r14b
    7c33ec90160a:	mov    r13d,0x0
    7c33ec901610:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec901618:	mov    r13d,0x4102a8
    7c33ec90161e:	mov    QWORD PTR [r12+0xf0],r13
    7c33ec901626:	mov    r13d,0x410728
    7c33ec90162c:	mov    QWORD PTR [r12+0x100],r13
    7c33ec901634:	mov    r11,QWORD PTR [rsp]
    7c33ec901638:	mov    QWORD PTR [r12+0x398],r11
    7c33ec901640:	mov    edi,0x410728
    7c33ec901645:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec90164d:	add    rsp,0x10
    7c33ec901651:	nop    DWORD PTR [rax+0x0]
    7c33ec901658:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec901660
    7c33ec90165e:	xchg   ax,ax
    7c33ec901660:	(bad)
    7c33ec901661:	jmp    0x7c3468c402f5
    7c33ec901666:	add    BYTE PTR [rax],al
    7c33ec901668:	jo     0x7c33ec901680
    7c33ec90166a:	nop
    7c33ec90166b:	in     al,dx
    7c33ec90166c:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec901670:	movabs r11,0x5585303950a0
    7c33ec90167a:	jmp    r11
    7c33ec90167d:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec901685:	add    r13,0x100
    7c33ec90168c:	mov    QWORD PTR [r12],r13
    7c33ec901690:	mov    r13d,0x0
    7c33ec901696:	mov    r14,QWORD PTR [r12+0x98]
    7c33ec90169e:	mov    rcx,r14
    7c33ec9016a1:	or     r13,rcx
    7c33ec9016a4:	mov    QWORD PTR [r12+0x8],r13
    7c33ec9016a9:	mov    r13d,0x12c
    7c33ec9016af:	mov    QWORD PTR [r12+0x10],r13
    7c33ec9016b4:	mov    r13d,0x410284
    7c33ec9016ba:	mov    QWORD PTR [r12+0xf0],r13
    7c33ec9016c2:	mov    r13d,0x410728
    7c33ec9016c8:	mov    QWORD PTR [r12+0x100],r13
    7c33ec9016d0:	mov    r11,QWORD PTR [rsp]
    7c33ec9016d4:	mov    QWORD PTR [r12+0x398],r11
    7c33ec9016dc:	mov    edi,0x410728
    7c33ec9016e1:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec9016e9:	add    rsp,0x10
    7c33ec9016ed:	nop    DWORD PTR [rax]
    7c33ec9016f0:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec9016f8
    7c33ec9016f6:	xchg   ax,ax
    7c33ec9016f8:	(bad)
    7c33ec9016f9:	jmp    0x7c3468c4038d
    7c33ec9016fe:	add    BYTE PTR [rax],al
    7c33ec901700:	or     BYTE PTR [rdi],dl
    7c33ec901702:	nop
    7c33ec901703:	in     al,dx
    7c33ec901704:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec901708:	movabs r11,0x5585303950a0
    7c33ec901712:	jmp    r11
    7c33ec901715:	mov    eax,0x410288
    7c33ec90171a:	mov    QWORD PTR [r12+0x100],rax
    7c33ec901722:	push   rdx
    7c33ec901723:	push   rsi
    7c33ec901724:	push   r10
    7c33ec901726:	push   r11
    7c33ec901728:	pushf
    7c33ec901729:	pop    r11
    7c33ec90172b:	mov    QWORD PTR [rsp+0x20],r11
    7c33ec901730:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec901735:	mov    r10d,edx
    7c33ec901738:	and    r10d,0xc0
    7c33ec90173f:	shl    r10d,0x18
    7c33ec901743:	mov    r11d,edx
    7c33ec901746:	and    r11d,0x1
    7c33ec90174a:	shl    r11d,0x1d
    7c33ec90174e:	or     r10d,r11d
    7c33ec901751:	mov    r11d,edx
    7c33ec901754:	and    r11d,0x800
    7c33ec90175b:	shl    r11d,0x11
    7c33ec90175f:	or     r10d,r11d
    7c33ec901762:	btc    r10,0x1d
    7c33ec901767:	mov    r11d,0xf0000000
    7c33ec90176d:	and    r11,r10
    7c33ec901770:	movabs rsi,0xffffffff0fffffff
    7c33ec90177a:	and    rbx,rsi
    7c33ec90177d:	or     rbx,r11
    7c33ec901780:	pop    r11
    7c33ec901782:	pop    r10
    7c33ec901784:	pop    rsi
    7c33ec901785:	pop    rdx
    7c33ec901786:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90178e:	add    rsp,0x10
    7c33ec901792:	mov    eax,0xc
    7c33ec901797:	movabs r11,0x558530395390
    7c33ec9017a1:	jmp    r11
    7c33ec9017a4:	data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec9017b0:	sub    rsp,0x10
    7c33ec9017b4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec9017bc:	mov    QWORD PTR [rsp],r11
    7c33ec9017c0:	jmp    0x7c33ec9015a9
    7c33ec9017c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec9017d0:	sub    rsp,0x10
    7c33ec9017d4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec9017dc:	mov    QWORD PTR [rsp],r11
    7c33ec9017e0:	jmp    0x7c33ec90167d
    7c33ec9017e5:	nop
    7c33ec9017e6:	nop
    7c33ec9017e7:	nop
