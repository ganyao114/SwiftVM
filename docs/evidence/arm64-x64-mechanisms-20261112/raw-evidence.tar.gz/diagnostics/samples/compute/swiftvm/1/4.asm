
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/1/4.bin:     file format binary


Disassembly of section .data:

0000707120f01a50 <.data>:
    707120f01a50:	sub    rsp,0x10
    707120f01a54:	mov    r11,QWORD PTR [r12+0x398]
    707120f01a5c:	mov    QWORD PTR [rsp],r11
    707120f01a60:	mov    r13,QWORD PTR [r12+0xf8]
    707120f01a68:	add    r13,0x168
    707120f01a6f:	mov    r14,QWORD PTR [r13+0x0]
    707120f01a73:	mov    QWORD PTR [r12+0x40],r14
    707120f01a78:	sub    r14,0x38
    707120f01a7c:	mov    rcx,QWORD PTR [r12+0x380]
    707120f01a84:	jrcxz  0x707120f01a8b
    707120f01a86:	jmp    0x707120f01b3d
    707120f01a8b:	pushf
    707120f01a8c:	pop    r11
    707120f01a8e:	mov    QWORD PTR [rsp],r11
    707120f01a92:	jne    0x707120f01aed
    707120f01a98:	jmp    0x707120f01a9d
    707120f01a9d:	mov    r13d,0x4102d4
    707120f01aa3:	mov    QWORD PTR [r12+0x100],r13
    707120f01aab:	mov    r11,QWORD PTR [rsp]
    707120f01aaf:	mov    QWORD PTR [r12+0x398],r11
    707120f01ab7:	mov    edi,0x4102d4
    707120f01abc:	mov    QWORD PTR [r12+0x100],rdi
    707120f01ac4:	add    rsp,0x10
    707120f01ac8:	jmp    QWORD PTR [rip+0x2]        # 0x707120f01ad0
    707120f01ace:	xchg   ax,ax
    707120f01ad0:	xor    BYTE PTR [rdx],bl
    707120f01ad2:	lock and BYTE PTR [rcx+0x70],dh
    707120f01ad6:	add    BYTE PTR [rax],al
    707120f01ad8:	loopne 0x707120f01af4
    707120f01ada:	lock and BYTE PTR [rcx+0x70],dh
    707120f01ade:	add    BYTE PTR [rax],al
    707120f01ae0:	movabs r11,0x5ab6724ae0a0
    707120f01aea:	jmp    r11
    707120f01aed:	mov    r13d,0x4102b8
    707120f01af3:	mov    QWORD PTR [r12+0x100],r13
    707120f01afb:	mov    r11,QWORD PTR [rsp]
    707120f01aff:	mov    QWORD PTR [r12+0x398],r11
    707120f01b07:	mov    edi,0x4102b8
    707120f01b0c:	mov    QWORD PTR [r12+0x100],rdi
    707120f01b14:	add    rsp,0x10
    707120f01b18:	jmp    QWORD PTR [rip+0x2]        # 0x707120f01b20
    707120f01b1e:	xchg   ax,ax
    707120f01b20:	adc    BYTE PTR [rdx],bl
    707120f01b22:	lock and BYTE PTR [rcx+0x70],dh
    707120f01b26:	add    BYTE PTR [rax],al
    707120f01b28:	xor    BYTE PTR [rbx],bl
    707120f01b2a:	lock and BYTE PTR [rcx+0x70],dh
    707120f01b2e:	add    BYTE PTR [rax],al
    707120f01b30:	movabs r11,0x5ab6724ae0a0
    707120f01b3a:	jmp    r11
    707120f01b3d:	mov    eax,0x4102d0
    707120f01b42:	mov    QWORD PTR [r12+0x100],rax
    707120f01b4a:	push   rdx
    707120f01b4b:	push   rsi
    707120f01b4c:	push   r10
    707120f01b4e:	push   r11
    707120f01b50:	pushf
    707120f01b51:	pop    r11
    707120f01b53:	mov    QWORD PTR [rsp+0x20],r11
    707120f01b58:	mov    rdx,QWORD PTR [rsp+0x20]
    707120f01b5d:	mov    r10d,edx
    707120f01b60:	and    r10d,0xc0
    707120f01b67:	shl    r10d,0x18
    707120f01b6b:	mov    r11d,edx
    707120f01b6e:	and    r11d,0x1
    707120f01b72:	shl    r11d,0x1d
    707120f01b76:	or     r10d,r11d
    707120f01b79:	mov    r11d,edx
    707120f01b7c:	and    r11d,0x800
    707120f01b83:	shl    r11d,0x11
    707120f01b87:	or     r10d,r11d
    707120f01b8a:	btc    r10,0x1d
    707120f01b8f:	mov    r11d,0xf0000000
    707120f01b95:	and    r11,r10
    707120f01b98:	movabs rsi,0xffffffff0fffffff
    707120f01ba2:	and    rbx,rsi
    707120f01ba5:	or     rbx,r11
    707120f01ba8:	pop    r11
    707120f01baa:	pop    r10
    707120f01bac:	pop    rsi
    707120f01bad:	pop    rdx
    707120f01bae:	mov    QWORD PTR [r12+0x108],rbx
    707120f01bb6:	add    rsp,0x10
    707120f01bba:	mov    eax,0xc
    707120f01bbf:	movabs r11,0x5ab6724ae390
    707120f01bc9:	jmp    r11
