
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

00007c33ec8fe000 <.data>:
    7c33ec8fe000:	sub    rsp,0x10
    7c33ec8fe004:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec8fe00c:	mov    QWORD PTR [rsp],r11
    7c33ec8fe010:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec8fe018:	sub    r13,0x1e0
    7c33ec8fe01f:	mov    QWORD PTR [r12+0xf8],r13
    7c33ec8fe027:	mov    r14d,0x420000
    7c33ec8fe02d:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe032:	mov    r14d,0x420000
    7c33ec8fe038:	mov    QWORD PTR [r12+0x48],r14
    7c33ec8fe03d:	add    r13,0x1d0
    7c33ec8fe044:	mov    r14,r13
    7c33ec8fe047:	add    r14,0x8
    7c33ec8fe04b:	mov    r15,QWORD PTR [r12+0xa0]
    7c33ec8fe053:	mov    rbp,QWORD PTR [r12+0x98]
    7c33ec8fe05b:	mov    QWORD PTR [r13+0x0],r15
    7c33ec8fe05f:	mov    r13d,0x0
    7c33ec8fe065:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe06d:	mov    QWORD PTR [r14],rbp
    7c33ec8fe070:	mov    r13d,0x0
    7c33ec8fe076:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe07e:	mov    r13d,0x420aa0
    7c33ec8fe084:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec8fe08a:	movdqa xmm0,xmm2
    7c33ec8fe08e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec8fe098:	mov    r13d,0x420000
    7c33ec8fe09e:	mov    QWORD PTR [r12+0x40],r13
    7c33ec8fe0a3:	mov    r13d,0x420a30
    7c33ec8fe0a9:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c33ec8fe0af:	movdqa xmm0,xmm3
    7c33ec8fe0b3:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec8fe0bd:	mov    r13d,0x420000
    7c33ec8fe0c3:	mov    QWORD PTR [r12+0x48],r13
    7c33ec8fe0c8:	mov    r13d,0x420ac0
    7c33ec8fe0ce:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    7c33ec8fe0d4:	movdqa xmm0,xmm4
    7c33ec8fe0d8:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec8fe0e2:	mov    r13d,0x420000
    7c33ec8fe0e8:	mov    QWORD PTR [r12+0x40],r13
    7c33ec8fe0ed:	mov    r13d,0x420a60
    7c33ec8fe0f3:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7c33ec8fe0f9:	movdqa xmm0,xmm5
    7c33ec8fe0fd:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c33ec8fe107:	mov    r13d,0x430000
    7c33ec8fe10d:	add    r13,0xcd0
    7c33ec8fe114:	mov    QWORD PTR [r12+0x98],r13
    7c33ec8fe11c:	mov    r14,QWORD PTR [r12+0x40]
    7c33ec8fe121:	add    r14,0xad0
    7c33ec8fe128:	movdqu xmm6,XMMWORD PTR [r14]
    7c33ec8fe12d:	movdqa xmm0,xmm6
    7c33ec8fe131:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec8fe13b:	mov    r14d,0x420000
    7c33ec8fe141:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe146:	mov    r14,r13
    7c33ec8fe149:	add    r14,0x10
    7c33ec8fe14d:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c33ec8fe153:	mov    r15d,0x0
    7c33ec8fe159:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec8fe161:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec8fe166:	mov    r14d,0x0
    7c33ec8fe16c:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe174:	mov    r14,r13
    7c33ec8fe177:	add    r14,0x20
    7c33ec8fe17b:	mov    r15,r14
    7c33ec8fe17e:	add    r15,0x10
    7c33ec8fe182:	movdqu XMMWORD PTR [r14],xmm4
    7c33ec8fe187:	mov    r14d,0x0
    7c33ec8fe18d:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe195:	movdqu XMMWORD PTR [r15],xmm5
    7c33ec8fe19a:	mov    r14d,0x0
    7c33ec8fe1a0:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe1a8:	mov    r14d,0x420a20
    7c33ec8fe1ae:	movdqu xmm4,XMMWORD PTR [r14]
    7c33ec8fe1b3:	movdqa xmm0,xmm4
    7c33ec8fe1b7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec8fe1c1:	mov    r14d,0x420000
    7c33ec8fe1c7:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe1cc:	mov    r14d,0x420a10
    7c33ec8fe1d2:	movdqu xmm5,XMMWORD PTR [r14]
    7c33ec8fe1d7:	movdqa xmm0,xmm5
    7c33ec8fe1db:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c33ec8fe1e5:	mov    r14d,0x420000
    7c33ec8fe1eb:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe1f0:	mov    r14,r13
    7c33ec8fe1f3:	add    r14,0x100
    7c33ec8fe1fa:	mov    r15,r14
    7c33ec8fe1fd:	add    r15,0x10
    7c33ec8fe201:	movdqu XMMWORD PTR [r14],xmm2
    7c33ec8fe206:	mov    r14d,0x0
    7c33ec8fe20c:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe214:	movdqu XMMWORD PTR [r15],xmm3
    7c33ec8fe219:	mov    r14d,0x0
    7c33ec8fe21f:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe227:	add    r13,0x40
    7c33ec8fe22b:	mov    r14,r13
    7c33ec8fe22e:	add    r14,0x10
    7c33ec8fe232:	movdqu XMMWORD PTR [r13+0x0],xmm6
    7c33ec8fe238:	mov    r13d,0x0
    7c33ec8fe23e:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe246:	movdqu XMMWORD PTR [r14],xmm4
    7c33ec8fe24b:	mov    r13d,0x0
    7c33ec8fe251:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe259:	mov    r13d,0x420a00
    7c33ec8fe25f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec8fe265:	movdqa xmm0,xmm2
    7c33ec8fe269:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec8fe273:	mov    r13d,0x420000
    7c33ec8fe279:	mov    QWORD PTR [r12+0x40],r13
    7c33ec8fe27e:	mov    r13d,0x420a70
    7c33ec8fe284:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c33ec8fe28a:	movdqa xmm0,xmm3
    7c33ec8fe28e:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec8fe298:	mov    r13d,0x420000
    7c33ec8fe29e:	mov    QWORD PTR [r12+0x40],r13
    7c33ec8fe2a3:	mov    r13d,0xf8d3
    7c33ec8fe2a9:	mov    QWORD PTR [r12+0x48],r13
    7c33ec8fe2ae:	mov    r13,QWORD PTR [r12+0x98]
    7c33ec8fe2b6:	mov    r14,r13
    7c33ec8fe2b9:	add    r14,0x60
    7c33ec8fe2bd:	mov    r15,r14
    7c33ec8fe2c0:	add    r15,0x10
    7c33ec8fe2c4:	movdqu XMMWORD PTR [r14],xmm5
    7c33ec8fe2c9:	mov    r14d,0x0
    7c33ec8fe2cf:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe2d7:	movdqu XMMWORD PTR [r15],xmm2
    7c33ec8fe2dc:	mov    r14d,0x0
    7c33ec8fe2e2:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe2ea:	mov    r14d,0x420a80
    7c33ec8fe2f0:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec8fe2f5:	movdqa xmm0,xmm2
    7c33ec8fe2f9:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec8fe303:	mov    r14d,0x420000
    7c33ec8fe309:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe30e:	mov    r14d,0x420a50
    7c33ec8fe314:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec8fe319:	movdqa xmm0,xmm2
    7c33ec8fe31d:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c33ec8fe327:	mov    r14d,0x420000
    7c33ec8fe32d:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe332:	mov    r14d,0xf8d3
    7c33ec8fe338:	mov    r15d,0x421d
    7c33ec8fe33e:	and    r15d,0xffff
    7c33ec8fe345:	mov    rax,r14
    7c33ec8fe348:	movabs rcx,0xffffffff0000ffff
    7c33ec8fe352:	and    rax,rcx
    7c33ec8fe355:	mov    rdx,r15
    7c33ec8fe358:	shl    rdx,0x10
    7c33ec8fe35c:	mov    ecx,0xffff0000
    7c33ec8fe361:	and    rdx,rcx
    7c33ec8fe364:	or     rax,rdx
    7c33ec8fe367:	mov    ebp,eax
    7c33ec8fe369:	mov    QWORD PTR [r12+0x48],rbp
    7c33ec8fe36e:	mov    r14,r13
    7c33ec8fe371:	add    r14,0x80
    7c33ec8fe378:	mov    r15,r14
    7c33ec8fe37b:	add    r15,0x10
    7c33ec8fe37f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec8fe389:	movdqa xmm2,xmm0
    7c33ec8fe38d:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec8fe392:	mov    r14d,0x0
    7c33ec8fe398:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe3a0:	movdqu XMMWORD PTR [r15],xmm2
    7c33ec8fe3a5:	mov    r14d,0x0
    7c33ec8fe3ab:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe3b3:	mov    r14d,0x420af0
    7c33ec8fe3b9:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec8fe3be:	movdqa xmm0,xmm2
    7c33ec8fe3c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec8fe3cc:	mov    r14d,0x420000
    7c33ec8fe3d2:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe3d7:	mov    r14d,0x420b00
    7c33ec8fe3dd:	movdqu xmm3,XMMWORD PTR [r14]
    7c33ec8fe3e2:	movdqa xmm0,xmm3
    7c33ec8fe3e6:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec8fe3f0:	mov    r14d,0x420000
    7c33ec8fe3f6:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe3fb:	mov    r14d,0x3e8
    7c33ec8fe401:	mov    QWORD PTR [r12+0xa0],r14
    7c33ec8fe409:	add    r13,0xa0
    7c33ec8fe410:	mov    r14,r13
    7c33ec8fe413:	add    r14,0x10
    7c33ec8fe417:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec8fe421:	movdqa xmm3,xmm0
    7c33ec8fe425:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7c33ec8fe42b:	mov    r13d,0x0
    7c33ec8fe431:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe439:	movdqu XMMWORD PTR [r14],xmm2
    7c33ec8fe43e:	mov    r13d,0x0
    7c33ec8fe444:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe44c:	mov    r13,QWORD PTR [r12+0x40]
    7c33ec8fe451:	add    r13,0xae0
    7c33ec8fe458:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec8fe45e:	movdqa xmm0,xmm2
    7c33ec8fe462:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec8fe46c:	mov    r13d,0x420000
    7c33ec8fe472:	mov    QWORD PTR [r12+0x40],r13
    7c33ec8fe477:	mov    r13d,0x420a90
    7c33ec8fe47d:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec8fe483:	movdqa xmm0,xmm2
    7c33ec8fe487:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c33ec8fe491:	mov    r13d,0x420000
    7c33ec8fe497:	mov    QWORD PTR [r12+0x40],r13
    7c33ec8fe49c:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec8fe4a4:	add    r13,0x180
    7c33ec8fe4ab:	mov    r14,r13
    7c33ec8fe4ae:	add    r14,0x8
    7c33ec8fe4b2:	mov    r15,QWORD PTR [r12+0x200]
    7c33ec8fe4ba:	mov    rbp,QWORD PTR [r12+0x1f0]
    7c33ec8fe4c2:	mov    QWORD PTR [r13+0x0],r15
    7c33ec8fe4c6:	mov    r13d,0x0
    7c33ec8fe4cc:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe4d4:	mov    QWORD PTR [r14],rbp
    7c33ec8fe4d7:	mov    r13d,0x0
    7c33ec8fe4dd:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe4e5:	mov    r13,QWORD PTR [r12+0x98]
    7c33ec8fe4ed:	mov    r14,r13
    7c33ec8fe4f0:	add    r14,0xc0
    7c33ec8fe4f7:	mov    r15,r14
    7c33ec8fe4fa:	add    r15,0x10
    7c33ec8fe4fe:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec8fe508:	movdqa xmm2,xmm0
    7c33ec8fe50c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec8fe516:	movdqa xmm3,xmm0
    7c33ec8fe51a:	movdqu XMMWORD PTR [r14],xmm2
    7c33ec8fe51f:	mov    r14d,0x0
    7c33ec8fe525:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe52d:	movdqu XMMWORD PTR [r15],xmm3
    7c33ec8fe532:	mov    r14d,0x0
    7c33ec8fe538:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe540:	mov    r14d,0x420ab0
    7c33ec8fe546:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec8fe54b:	movdqa xmm0,xmm2
    7c33ec8fe54f:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec8fe559:	mov    r14d,0x420000
    7c33ec8fe55f:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe564:	mov    r14d,0x420b18
    7c33ec8fe56a:	mov    r15,QWORD PTR [r14]
    7c33ec8fe56d:	mov    r14d,0x0
    7c33ec8fe573:	mov    QWORD PTR [r12+0x110],r15
    7c33ec8fe57b:	mov    QWORD PTR [r12+0x118],r14
    7c33ec8fe583:	mov    r14d,0x420b20
    7c33ec8fe589:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fe58e:	mov    r14,r13
    7c33ec8fe591:	add    r14,0xe0
    7c33ec8fe598:	mov    rbp,r14
    7c33ec8fe59b:	add    rbp,0x10
    7c33ec8fe59f:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec8fe5a9:	movdqa xmm3,xmm0
    7c33ec8fe5ad:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec8fe5b2:	mov    r14d,0x0
    7c33ec8fe5b8:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe5c0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c33ec8fe5c5:	mov    r14d,0x0
    7c33ec8fe5cb:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe5d3:	mov    r14d,0x420b80
    7c33ec8fe5d9:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec8fe5de:	movdqa xmm0,xmm2
    7c33ec8fe5e2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec8fe5ec:	add    r13,0x120
    7c33ec8fe5f3:	mov    QWORD PTR [r13+0x0],r15
    7c33ec8fe5f7:	mov    r13d,0x0
    7c33ec8fe5fd:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe605:	mov    r13d,0x420b60
    7c33ec8fe60b:	mov    r14d,0x420b70
    7c33ec8fe611:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c33ec8fe617:	movdqu xmm4,XMMWORD PTR [r14]
    7c33ec8fe61c:	movdqa xmm0,xmm3
    7c33ec8fe620:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec8fe62a:	movdqa xmm0,xmm4
    7c33ec8fe62e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec8fe638:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec8fe640:	mov    r14,r13
    7c33ec8fe643:	add    r14,0x160
    7c33ec8fe64a:	movdqu XMMWORD PTR [r14],xmm2
    7c33ec8fe64f:	mov    r14d,0x0
    7c33ec8fe655:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe65d:	mov    r14,r13
    7c33ec8fe660:	add    r14,0x190
    7c33ec8fe667:	mov    r15,r14
    7c33ec8fe66a:	add    r15,0x8
    7c33ec8fe66e:	mov    rbp,QWORD PTR [r12+0x1e0]
    7c33ec8fe676:	mov    r8,QWORD PTR [r12+0x1d0]
    7c33ec8fe67e:	mov    QWORD PTR [r14],rbp
    7c33ec8fe681:	mov    r14d,0x0
    7c33ec8fe687:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe68f:	mov    QWORD PTR [r15],r8
    7c33ec8fe692:	mov    r14d,0x0
    7c33ec8fe698:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe6a0:	mov    r14,r13
    7c33ec8fe6a3:	add    r14,0x140
    7c33ec8fe6aa:	mov    r15,r14
    7c33ec8fe6ad:	add    r15,0x10
    7c33ec8fe6b1:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec8fe6b6:	mov    r14d,0x0
    7c33ec8fe6bc:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe6c4:	movdqu XMMWORD PTR [r15],xmm4
    7c33ec8fe6c9:	mov    r14d,0x0
    7c33ec8fe6cf:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe6d7:	mov    r14d,0x420b20
    7c33ec8fe6dd:	mov    r15d,0x420b30
    7c33ec8fe6e3:	movdqu xmm2,XMMWORD PTR [r14]
    7c33ec8fe6e8:	movdqu xmm3,XMMWORD PTR [r15]
    7c33ec8fe6ed:	movdqa xmm0,xmm2
    7c33ec8fe6f1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec8fe6fb:	movdqa xmm0,xmm3
    7c33ec8fe6ff:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec8fe709:	mov    r14,r13
    7c33ec8fe70c:	add    r14,0x1a0
    7c33ec8fe713:	mov    r15,r14
    7c33ec8fe716:	add    r15,0x8
    7c33ec8fe71a:	mov    rbp,QWORD PTR [r12+0x1c0]
    7c33ec8fe722:	mov    r8,QWORD PTR [r12+0x1b0]
    7c33ec8fe72a:	mov    QWORD PTR [r14],rbp
    7c33ec8fe72d:	mov    r14d,0x0
    7c33ec8fe733:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe73b:	mov    QWORD PTR [r15],r8
    7c33ec8fe73e:	mov    r14d,0x0
    7c33ec8fe744:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe74c:	mov    r14,r13
    7c33ec8fe74f:	add    r14,0x1b0
    7c33ec8fe756:	mov    r15,r14
    7c33ec8fe759:	add    r15,0x8
    7c33ec8fe75d:	mov    rbp,QWORD PTR [r12+0x1a0]
    7c33ec8fe765:	mov    r8,QWORD PTR [r12+0x190]
    7c33ec8fe76d:	mov    QWORD PTR [r14],rbp
    7c33ec8fe770:	mov    r14d,0x0
    7c33ec8fe776:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe77e:	mov    QWORD PTR [r15],r8
    7c33ec8fe781:	mov    r14d,0x0
    7c33ec8fe787:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe78f:	add    r13,0x100
    7c33ec8fe796:	mov    r14,r13
    7c33ec8fe799:	add    r14,0x10
    7c33ec8fe79d:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec8fe7a7:	movdqa xmm2,xmm0
    7c33ec8fe7ab:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec8fe7b5:	movdqa xmm3,xmm0
    7c33ec8fe7b9:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c33ec8fe7bf:	mov    r13d,0x0
    7c33ec8fe7c5:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe7cd:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec8fe7d2:	mov    r13d,0x0
    7c33ec8fe7d8:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe7e0:	mov    r13,QWORD PTR [r12+0x40]
    7c33ec8fe7e5:	add    r13,0x20
    7c33ec8fe7e9:	mov    r14,r13
    7c33ec8fe7ec:	add    r14,0x10
    7c33ec8fe7f0:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c33ec8fe7f6:	movdqu xmm3,XMMWORD PTR [r14]
    7c33ec8fe7fb:	movdqa xmm0,xmm2
    7c33ec8fe7ff:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec8fe809:	movdqa xmm0,xmm3
    7c33ec8fe80d:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec8fe817:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec8fe81f:	mov    r14,r13
    7c33ec8fe822:	add    r14,0x1c0
    7c33ec8fe829:	mov    r15,r14
    7c33ec8fe82c:	add    r15,0x8
    7c33ec8fe830:	mov    rbp,QWORD PTR [r12+0xe8]
    7c33ec8fe838:	mov    r8,QWORD PTR [r12+0xf0]
    7c33ec8fe840:	mov    QWORD PTR [r14],rbp
    7c33ec8fe843:	mov    r14d,0x0
    7c33ec8fe849:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe851:	mov    QWORD PTR [r15],r8
    7c33ec8fe854:	mov    r14d,0x0
    7c33ec8fe85a:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fe862:	mov    r14,QWORD PTR [r12+0x98]
    7c33ec8fe86a:	mov    r15,r14
    7c33ec8fe86d:	add    r15,0x128
    7c33ec8fe874:	mov    ebp,DWORD PTR [r12+0x48]
    7c33ec8fe879:	mov    DWORD PTR [r15],ebp
    7c33ec8fe87c:	mov    r15d,0x0
    7c33ec8fe882:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec8fe88a:	mov    r15,r13
    7c33ec8fe88d:	add    r15,0x120
    7c33ec8fe894:	mov    rbp,r15
    7c33ec8fe897:	add    rbp,0x10
    7c33ec8fe89b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec8fe8a5:	movdqa xmm2,xmm0
    7c33ec8fe8a9:	movdqu XMMWORD PTR [r15],xmm2
    7c33ec8fe8ae:	mov    r15d,0x0
    7c33ec8fe8b4:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec8fe8bc:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7c33ec8fe8c1:	mov    r15d,0x0
    7c33ec8fe8c7:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec8fe8cf:	add    r13,0x100
    7c33ec8fe8d6:	mov    QWORD PTR [r12],r13
    7c33ec8fe8da:	mov    r13d,0x0
    7c33ec8fe8e0:	mov    rcx,r14
    7c33ec8fe8e3:	or     r13,rcx
    7c33ec8fe8e6:	mov    QWORD PTR [r12+0x8],r13
    7c33ec8fe8eb:	mov    r13d,0x12c
    7c33ec8fe8f1:	mov    QWORD PTR [r12+0x10],r13
    7c33ec8fe8f6:	mov    r13d,0x410284
    7c33ec8fe8fc:	mov    QWORD PTR [r12+0xf0],r13
    7c33ec8fe904:	mov    r13d,0x410728
    7c33ec8fe90a:	mov    QWORD PTR [r12+0x100],r13
    7c33ec8fe912:	mov    r11,QWORD PTR [rsp]
    7c33ec8fe916:	mov    QWORD PTR [r12+0x398],r11
    7c33ec8fe91e:	mov    edi,0x410728
    7c33ec8fe923:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec8fe92b:	add    rsp,0x10
    7c33ec8fe92f:	nop
    7c33ec8fe930:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec8fe938
    7c33ec8fe936:	xchg   ax,ax
    7c33ec8fe938:	(bad)
    7c33ec8fe939:	jmp    0x7c3468c3d5cd
    7c33ec8fe93e:	add    BYTE PTR [rax],al
    7c33ec8fe940:	rex.W jmp 0x7c3468c3d5d5
    7c33ec8fe946:	add    BYTE PTR [rax],al
    7c33ec8fe948:	movabs r11,0x5585303950a0
    7c33ec8fe952:	jmp    r11
    7c33ec8fe955:	nop
    7c33ec8fe956:	nop
    7c33ec8fe957:	nop
