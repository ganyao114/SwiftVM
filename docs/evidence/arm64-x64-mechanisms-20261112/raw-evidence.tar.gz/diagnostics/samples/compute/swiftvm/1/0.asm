
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

0000707120efe000 <.data>:
    707120efe000:	sub    rsp,0x10
    707120efe004:	mov    r11,QWORD PTR [r12+0x398]
    707120efe00c:	mov    QWORD PTR [rsp],r11
    707120efe010:	mov    r13,QWORD PTR [r12+0xf8]
    707120efe018:	sub    r13,0x1e0
    707120efe01f:	mov    QWORD PTR [r12+0xf8],r13
    707120efe027:	mov    r14d,0x420000
    707120efe02d:	mov    QWORD PTR [r12+0x40],r14
    707120efe032:	mov    r14d,0x420000
    707120efe038:	mov    QWORD PTR [r12+0x48],r14
    707120efe03d:	add    r13,0x1d0
    707120efe044:	mov    r14,r13
    707120efe047:	add    r14,0x8
    707120efe04b:	mov    r15,QWORD PTR [r12+0xa0]
    707120efe053:	mov    rbp,QWORD PTR [r12+0x98]
    707120efe05b:	mov    QWORD PTR [r13+0x0],r15
    707120efe05f:	mov    r13d,0x0
    707120efe065:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe06d:	mov    QWORD PTR [r14],rbp
    707120efe070:	mov    r13d,0x0
    707120efe076:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe07e:	mov    r13d,0x420aa0
    707120efe084:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120efe08a:	movdqa xmm0,xmm2
    707120efe08e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120efe098:	mov    r13d,0x420000
    707120efe09e:	mov    QWORD PTR [r12+0x40],r13
    707120efe0a3:	mov    r13d,0x420a30
    707120efe0a9:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    707120efe0af:	movdqa xmm0,xmm3
    707120efe0b3:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120efe0bd:	mov    r13d,0x420000
    707120efe0c3:	mov    QWORD PTR [r12+0x48],r13
    707120efe0c8:	mov    r13d,0x420ac0
    707120efe0ce:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    707120efe0d4:	movdqa xmm0,xmm4
    707120efe0d8:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120efe0e2:	mov    r13d,0x420000
    707120efe0e8:	mov    QWORD PTR [r12+0x40],r13
    707120efe0ed:	mov    r13d,0x420a60
    707120efe0f3:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    707120efe0f9:	movdqa xmm0,xmm5
    707120efe0fd:	movdqu XMMWORD PTR [r12+0x140],xmm0
    707120efe107:	mov    r13d,0x430000
    707120efe10d:	add    r13,0xcd0
    707120efe114:	mov    QWORD PTR [r12+0x98],r13
    707120efe11c:	mov    r14,QWORD PTR [r12+0x40]
    707120efe121:	add    r14,0xad0
    707120efe128:	movdqu xmm6,XMMWORD PTR [r14]
    707120efe12d:	movdqa xmm0,xmm6
    707120efe131:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120efe13b:	mov    r14d,0x420000
    707120efe141:	mov    QWORD PTR [r12+0x40],r14
    707120efe146:	mov    r14,r13
    707120efe149:	add    r14,0x10
    707120efe14d:	movdqu XMMWORD PTR [r13+0x0],xmm2
    707120efe153:	mov    r15d,0x0
    707120efe159:	mov    DWORD PTR [r12+0x32c],r15d
    707120efe161:	movdqu XMMWORD PTR [r14],xmm3
    707120efe166:	mov    r14d,0x0
    707120efe16c:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe174:	mov    r14,r13
    707120efe177:	add    r14,0x20
    707120efe17b:	mov    r15,r14
    707120efe17e:	add    r15,0x10
    707120efe182:	movdqu XMMWORD PTR [r14],xmm4
    707120efe187:	mov    r14d,0x0
    707120efe18d:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe195:	movdqu XMMWORD PTR [r15],xmm5
    707120efe19a:	mov    r14d,0x0
    707120efe1a0:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe1a8:	mov    r14d,0x420a20
    707120efe1ae:	movdqu xmm4,XMMWORD PTR [r14]
    707120efe1b3:	movdqa xmm0,xmm4
    707120efe1b7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120efe1c1:	mov    r14d,0x420000
    707120efe1c7:	mov    QWORD PTR [r12+0x40],r14
    707120efe1cc:	mov    r14d,0x420a10
    707120efe1d2:	movdqu xmm5,XMMWORD PTR [r14]
    707120efe1d7:	movdqa xmm0,xmm5
    707120efe1db:	movdqu XMMWORD PTR [r12+0x140],xmm0
    707120efe1e5:	mov    r14d,0x420000
    707120efe1eb:	mov    QWORD PTR [r12+0x40],r14
    707120efe1f0:	mov    r14,r13
    707120efe1f3:	add    r14,0x100
    707120efe1fa:	mov    r15,r14
    707120efe1fd:	add    r15,0x10
    707120efe201:	movdqu XMMWORD PTR [r14],xmm2
    707120efe206:	mov    r14d,0x0
    707120efe20c:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe214:	movdqu XMMWORD PTR [r15],xmm3
    707120efe219:	mov    r14d,0x0
    707120efe21f:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe227:	add    r13,0x40
    707120efe22b:	mov    r14,r13
    707120efe22e:	add    r14,0x10
    707120efe232:	movdqu XMMWORD PTR [r13+0x0],xmm6
    707120efe238:	mov    r13d,0x0
    707120efe23e:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe246:	movdqu XMMWORD PTR [r14],xmm4
    707120efe24b:	mov    r13d,0x0
    707120efe251:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe259:	mov    r13d,0x420a00
    707120efe25f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120efe265:	movdqa xmm0,xmm2
    707120efe269:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120efe273:	mov    r13d,0x420000
    707120efe279:	mov    QWORD PTR [r12+0x40],r13
    707120efe27e:	mov    r13d,0x420a70
    707120efe284:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    707120efe28a:	movdqa xmm0,xmm3
    707120efe28e:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120efe298:	mov    r13d,0x420000
    707120efe29e:	mov    QWORD PTR [r12+0x40],r13
    707120efe2a3:	mov    r13d,0xf8d3
    707120efe2a9:	mov    QWORD PTR [r12+0x48],r13
    707120efe2ae:	mov    r13,QWORD PTR [r12+0x98]
    707120efe2b6:	mov    r14,r13
    707120efe2b9:	add    r14,0x60
    707120efe2bd:	mov    r15,r14
    707120efe2c0:	add    r15,0x10
    707120efe2c4:	movdqu XMMWORD PTR [r14],xmm5
    707120efe2c9:	mov    r14d,0x0
    707120efe2cf:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe2d7:	movdqu XMMWORD PTR [r15],xmm2
    707120efe2dc:	mov    r14d,0x0
    707120efe2e2:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe2ea:	mov    r14d,0x420a80
    707120efe2f0:	movdqu xmm2,XMMWORD PTR [r14]
    707120efe2f5:	movdqa xmm0,xmm2
    707120efe2f9:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120efe303:	mov    r14d,0x420000
    707120efe309:	mov    QWORD PTR [r12+0x40],r14
    707120efe30e:	mov    r14d,0x420a50
    707120efe314:	movdqu xmm2,XMMWORD PTR [r14]
    707120efe319:	movdqa xmm0,xmm2
    707120efe31d:	movdqu XMMWORD PTR [r12+0x140],xmm0
    707120efe327:	mov    r14d,0x420000
    707120efe32d:	mov    QWORD PTR [r12+0x40],r14
    707120efe332:	mov    r14d,0xf8d3
    707120efe338:	mov    r15d,0x421d
    707120efe33e:	and    r15d,0xffff
    707120efe345:	mov    rax,r14
    707120efe348:	movabs rcx,0xffffffff0000ffff
    707120efe352:	and    rax,rcx
    707120efe355:	mov    rdx,r15
    707120efe358:	shl    rdx,0x10
    707120efe35c:	mov    ecx,0xffff0000
    707120efe361:	and    rdx,rcx
    707120efe364:	or     rax,rdx
    707120efe367:	mov    ebp,eax
    707120efe369:	mov    QWORD PTR [r12+0x48],rbp
    707120efe36e:	mov    r14,r13
    707120efe371:	add    r14,0x80
    707120efe378:	mov    r15,r14
    707120efe37b:	add    r15,0x10
    707120efe37f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120efe389:	movdqa xmm2,xmm0
    707120efe38d:	movdqu XMMWORD PTR [r14],xmm3
    707120efe392:	mov    r14d,0x0
    707120efe398:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe3a0:	movdqu XMMWORD PTR [r15],xmm2
    707120efe3a5:	mov    r14d,0x0
    707120efe3ab:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe3b3:	mov    r14d,0x420af0
    707120efe3b9:	movdqu xmm2,XMMWORD PTR [r14]
    707120efe3be:	movdqa xmm0,xmm2
    707120efe3c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120efe3cc:	mov    r14d,0x420000
    707120efe3d2:	mov    QWORD PTR [r12+0x40],r14
    707120efe3d7:	mov    r14d,0x420b00
    707120efe3dd:	movdqu xmm3,XMMWORD PTR [r14]
    707120efe3e2:	movdqa xmm0,xmm3
    707120efe3e6:	movdqu XMMWORD PTR [r12+0x150],xmm0
    707120efe3f0:	mov    r14d,0x420000
    707120efe3f6:	mov    QWORD PTR [r12+0x40],r14
    707120efe3fb:	mov    r14d,0x3e8
    707120efe401:	mov    QWORD PTR [r12+0xa0],r14
    707120efe409:	add    r13,0xa0
    707120efe410:	mov    r14,r13
    707120efe413:	add    r14,0x10
    707120efe417:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120efe421:	movdqa xmm3,xmm0
    707120efe425:	movdqu XMMWORD PTR [r13+0x0],xmm3
    707120efe42b:	mov    r13d,0x0
    707120efe431:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe439:	movdqu XMMWORD PTR [r14],xmm2
    707120efe43e:	mov    r13d,0x0
    707120efe444:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe44c:	mov    r13,QWORD PTR [r12+0x40]
    707120efe451:	add    r13,0xae0
    707120efe458:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120efe45e:	movdqa xmm0,xmm2
    707120efe462:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120efe46c:	mov    r13d,0x420000
    707120efe472:	mov    QWORD PTR [r12+0x40],r13
    707120efe477:	mov    r13d,0x420a90
    707120efe47d:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120efe483:	movdqa xmm0,xmm2
    707120efe487:	movdqu XMMWORD PTR [r12+0x140],xmm0
    707120efe491:	mov    r13d,0x420000
    707120efe497:	mov    QWORD PTR [r12+0x40],r13
    707120efe49c:	mov    r13,QWORD PTR [r12+0xf8]
    707120efe4a4:	add    r13,0x180
    707120efe4ab:	mov    r14,r13
    707120efe4ae:	add    r14,0x8
    707120efe4b2:	mov    r15,QWORD PTR [r12+0x200]
    707120efe4ba:	mov    rbp,QWORD PTR [r12+0x1f0]
    707120efe4c2:	mov    QWORD PTR [r13+0x0],r15
    707120efe4c6:	mov    r13d,0x0
    707120efe4cc:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe4d4:	mov    QWORD PTR [r14],rbp
    707120efe4d7:	mov    r13d,0x0
    707120efe4dd:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe4e5:	mov    r13,QWORD PTR [r12+0x98]
    707120efe4ed:	mov    r14,r13
    707120efe4f0:	add    r14,0xc0
    707120efe4f7:	mov    r15,r14
    707120efe4fa:	add    r15,0x10
    707120efe4fe:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    707120efe508:	movdqa xmm2,xmm0
    707120efe50c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    707120efe516:	movdqa xmm3,xmm0
    707120efe51a:	movdqu XMMWORD PTR [r14],xmm2
    707120efe51f:	mov    r14d,0x0
    707120efe525:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe52d:	movdqu XMMWORD PTR [r15],xmm3
    707120efe532:	mov    r14d,0x0
    707120efe538:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe540:	mov    r14d,0x420ab0
    707120efe546:	movdqu xmm2,XMMWORD PTR [r14]
    707120efe54b:	movdqa xmm0,xmm2
    707120efe54f:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120efe559:	mov    r14d,0x420000
    707120efe55f:	mov    QWORD PTR [r12+0x40],r14
    707120efe564:	mov    r14d,0x420b18
    707120efe56a:	mov    r15,QWORD PTR [r14]
    707120efe56d:	mov    r14d,0x0
    707120efe573:	mov    QWORD PTR [r12+0x110],r15
    707120efe57b:	mov    QWORD PTR [r12+0x118],r14
    707120efe583:	mov    r14d,0x420b20
    707120efe589:	mov    QWORD PTR [r12+0x40],r14
    707120efe58e:	mov    r14,r13
    707120efe591:	add    r14,0xe0
    707120efe598:	mov    rbp,r14
    707120efe59b:	add    rbp,0x10
    707120efe59f:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    707120efe5a9:	movdqa xmm3,xmm0
    707120efe5ad:	movdqu XMMWORD PTR [r14],xmm3
    707120efe5b2:	mov    r14d,0x0
    707120efe5b8:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe5c0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    707120efe5c5:	mov    r14d,0x0
    707120efe5cb:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe5d3:	mov    r14d,0x420b80
    707120efe5d9:	movdqu xmm2,XMMWORD PTR [r14]
    707120efe5de:	movdqa xmm0,xmm2
    707120efe5e2:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120efe5ec:	add    r13,0x120
    707120efe5f3:	mov    QWORD PTR [r13+0x0],r15
    707120efe5f7:	mov    r13d,0x0
    707120efe5fd:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe605:	mov    r13d,0x420b60
    707120efe60b:	mov    r14d,0x420b70
    707120efe611:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    707120efe617:	movdqu xmm4,XMMWORD PTR [r14]
    707120efe61c:	movdqa xmm0,xmm3
    707120efe620:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120efe62a:	movdqa xmm0,xmm4
    707120efe62e:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120efe638:	mov    r13,QWORD PTR [r12+0xf8]
    707120efe640:	mov    r14,r13
    707120efe643:	add    r14,0x160
    707120efe64a:	movdqu XMMWORD PTR [r14],xmm2
    707120efe64f:	mov    r14d,0x0
    707120efe655:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe65d:	mov    r14,r13
    707120efe660:	add    r14,0x190
    707120efe667:	mov    r15,r14
    707120efe66a:	add    r15,0x8
    707120efe66e:	mov    rbp,QWORD PTR [r12+0x1e0]
    707120efe676:	mov    r8,QWORD PTR [r12+0x1d0]
    707120efe67e:	mov    QWORD PTR [r14],rbp
    707120efe681:	mov    r14d,0x0
    707120efe687:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe68f:	mov    QWORD PTR [r15],r8
    707120efe692:	mov    r14d,0x0
    707120efe698:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe6a0:	mov    r14,r13
    707120efe6a3:	add    r14,0x140
    707120efe6aa:	mov    r15,r14
    707120efe6ad:	add    r15,0x10
    707120efe6b1:	movdqu XMMWORD PTR [r14],xmm3
    707120efe6b6:	mov    r14d,0x0
    707120efe6bc:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe6c4:	movdqu XMMWORD PTR [r15],xmm4
    707120efe6c9:	mov    r14d,0x0
    707120efe6cf:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe6d7:	mov    r14d,0x420b20
    707120efe6dd:	mov    r15d,0x420b30
    707120efe6e3:	movdqu xmm2,XMMWORD PTR [r14]
    707120efe6e8:	movdqu xmm3,XMMWORD PTR [r15]
    707120efe6ed:	movdqa xmm0,xmm2
    707120efe6f1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120efe6fb:	movdqa xmm0,xmm3
    707120efe6ff:	movdqu XMMWORD PTR [r12+0x120],xmm0
    707120efe709:	mov    r14,r13
    707120efe70c:	add    r14,0x1a0
    707120efe713:	mov    r15,r14
    707120efe716:	add    r15,0x8
    707120efe71a:	mov    rbp,QWORD PTR [r12+0x1c0]
    707120efe722:	mov    r8,QWORD PTR [r12+0x1b0]
    707120efe72a:	mov    QWORD PTR [r14],rbp
    707120efe72d:	mov    r14d,0x0
    707120efe733:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe73b:	mov    QWORD PTR [r15],r8
    707120efe73e:	mov    r14d,0x0
    707120efe744:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe74c:	mov    r14,r13
    707120efe74f:	add    r14,0x1b0
    707120efe756:	mov    r15,r14
    707120efe759:	add    r15,0x8
    707120efe75d:	mov    rbp,QWORD PTR [r12+0x1a0]
    707120efe765:	mov    r8,QWORD PTR [r12+0x190]
    707120efe76d:	mov    QWORD PTR [r14],rbp
    707120efe770:	mov    r14d,0x0
    707120efe776:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe77e:	mov    QWORD PTR [r15],r8
    707120efe781:	mov    r14d,0x0
    707120efe787:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe78f:	add    r13,0x100
    707120efe796:	mov    r14,r13
    707120efe799:	add    r14,0x10
    707120efe79d:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120efe7a7:	movdqa xmm2,xmm0
    707120efe7ab:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    707120efe7b5:	movdqa xmm3,xmm0
    707120efe7b9:	movdqu XMMWORD PTR [r13+0x0],xmm2
    707120efe7bf:	mov    r13d,0x0
    707120efe7c5:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe7cd:	movdqu XMMWORD PTR [r14],xmm3
    707120efe7d2:	mov    r13d,0x0
    707120efe7d8:	mov    DWORD PTR [r12+0x32c],r13d
    707120efe7e0:	mov    r13,QWORD PTR [r12+0x40]
    707120efe7e5:	add    r13,0x20
    707120efe7e9:	mov    r14,r13
    707120efe7ec:	add    r14,0x10
    707120efe7f0:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    707120efe7f6:	movdqu xmm3,XMMWORD PTR [r14]
    707120efe7fb:	movdqa xmm0,xmm2
    707120efe7ff:	movdqu XMMWORD PTR [r12+0x110],xmm0
    707120efe809:	movdqa xmm0,xmm3
    707120efe80d:	movdqu XMMWORD PTR [r12+0x130],xmm0
    707120efe817:	mov    r13,QWORD PTR [r12+0xf8]
    707120efe81f:	mov    r14,r13
    707120efe822:	add    r14,0x1c0
    707120efe829:	mov    r15,r14
    707120efe82c:	add    r15,0x8
    707120efe830:	mov    rbp,QWORD PTR [r12+0xe8]
    707120efe838:	mov    r8,QWORD PTR [r12+0xf0]
    707120efe840:	mov    QWORD PTR [r14],rbp
    707120efe843:	mov    r14d,0x0
    707120efe849:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe851:	mov    QWORD PTR [r15],r8
    707120efe854:	mov    r14d,0x0
    707120efe85a:	mov    DWORD PTR [r12+0x32c],r14d
    707120efe862:	mov    r14,QWORD PTR [r12+0x98]
    707120efe86a:	mov    r15,r14
    707120efe86d:	add    r15,0x128
    707120efe874:	mov    ebp,DWORD PTR [r12+0x48]
    707120efe879:	mov    DWORD PTR [r15],ebp
    707120efe87c:	mov    r15d,0x0
    707120efe882:	mov    DWORD PTR [r12+0x32c],r15d
    707120efe88a:	mov    r15,r13
    707120efe88d:	add    r15,0x120
    707120efe894:	mov    rbp,r15
    707120efe897:	add    rbp,0x10
    707120efe89b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    707120efe8a5:	movdqa xmm2,xmm0
    707120efe8a9:	movdqu XMMWORD PTR [r15],xmm2
    707120efe8ae:	mov    r15d,0x0
    707120efe8b4:	mov    DWORD PTR [r12+0x32c],r15d
    707120efe8bc:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    707120efe8c1:	mov    r15d,0x0
    707120efe8c7:	mov    DWORD PTR [r12+0x32c],r15d
    707120efe8cf:	add    r13,0x100
    707120efe8d6:	mov    QWORD PTR [r12],r13
    707120efe8da:	mov    r13d,0x0
    707120efe8e0:	mov    rcx,r14
    707120efe8e3:	or     r13,rcx
    707120efe8e6:	mov    QWORD PTR [r12+0x8],r13
    707120efe8eb:	mov    r13d,0x12c
    707120efe8f1:	mov    QWORD PTR [r12+0x10],r13
    707120efe8f6:	mov    r13d,0x410284
    707120efe8fc:	mov    QWORD PTR [r12+0xf0],r13
    707120efe904:	mov    r13d,0x410728
    707120efe90a:	mov    QWORD PTR [r12+0x100],r13
    707120efe912:	mov    r11,QWORD PTR [rsp]
    707120efe916:	mov    QWORD PTR [r12+0x398],r11
    707120efe91e:	mov    edi,0x410728
    707120efe923:	mov    QWORD PTR [r12+0x100],rdi
    707120efe92b:	add    rsp,0x10
    707120efe92f:	nop
    707120efe930:	jmp    QWORD PTR [rip+0x2]        # 0x707120efe938
    707120efe936:	xchg   ax,ax
    707120efe938:	(bad)
    707120efe939:	jmp    0x707191610a2d
    707120efe93e:	add    BYTE PTR [rax],al
    707120efe940:	rex.W jmp 0x707191610a35
    707120efe946:	add    BYTE PTR [rax],al
    707120efe948:	movabs r11,0x5ab6724ae0a0
    707120efe952:	jmp    r11
    707120efe955:	nop
    707120efe956:	nop
    707120efe957:	nop
