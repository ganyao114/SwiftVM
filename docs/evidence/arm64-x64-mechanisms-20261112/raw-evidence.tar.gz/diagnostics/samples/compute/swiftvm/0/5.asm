
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/0/5.bin:     file format binary


Disassembly of section .data:

00007c33ec901bd0 <.data>:
    7c33ec901bd0:	sub    rsp,0x20
    7c33ec901bd4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec901bdc:	mov    QWORD PTR [rsp+0x10],r11
    7c33ec901be1:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec901be9:	mov    r14,r13
    7c33ec901bec:	add    r14,0x100
    7c33ec901bf3:	mov    r15d,DWORD PTR [r14]
    7c33ec901bf6:	mov    QWORD PTR [r12+0x40],r15
    7c33ec901bfb:	mov    r14,r13
    7c33ec901bfe:	add    r14,0x104
    7c33ec901c05:	mov    ebp,DWORD PTR [r14]
    7c33ec901c08:	mov    QWORD PTR [r12+0x50],rbp
    7c33ec901c0d:	mov    r14d,0x430c90
    7c33ec901c13:	mov    QWORD PTR [r12+0x48],r14
    7c33ec901c18:	mov    r14,r13
    7c33ec901c1b:	add    r14,0x108
    7c33ec901c22:	mov    r8d,DWORD PTR [r14]
    7c33ec901c25:	mov    QWORD PTR [r12+0x58],r8
    7c33ec901c2a:	add    r13,0x10c
    7c33ec901c31:	mov    r14d,DWORD PTR [r13+0x0]
    7c33ec901c35:	mov    QWORD PTR [r12+0x60],r14
    7c33ec901c3a:	movabs rcx,0xff00ff00ff00ff
    7c33ec901c44:	mov    r13,r15
    7c33ec901c47:	and    r13,rcx
    7c33ec901c4a:	shl    r13,0x8
    7c33ec901c4e:	movabs rcx,0xff00ff00ff00ff00
    7c33ec901c58:	mov    r14,r15
    7c33ec901c5b:	and    r14,rcx
    7c33ec901c5e:	shr    r14,0x8
    7c33ec901c62:	mov    rcx,r13
    7c33ec901c65:	or     r14,rcx
    7c33ec901c68:	movabs rcx,0xffff0000ffff
    7c33ec901c72:	mov    r13,r14
    7c33ec901c75:	and    r13,rcx
    7c33ec901c78:	shl    r13,0x10
    7c33ec901c7c:	movabs rcx,0xffff0000ffff0000
    7c33ec901c86:	and    r14,rcx
    7c33ec901c89:	shr    r14,0x10
    7c33ec901c8d:	mov    rcx,r13
    7c33ec901c90:	or     r14,rcx
    7c33ec901c93:	mov    ecx,0xffffffff
    7c33ec901c98:	and    r14,rcx
    7c33ec901c9b:	mov    QWORD PTR [r12+0x40],r14
    7c33ec901ca0:	movabs rcx,0xff00ff00ff00ff
    7c33ec901caa:	mov    r13,rbp
    7c33ec901cad:	and    r13,rcx
    7c33ec901cb0:	shl    r13,0x8
    7c33ec901cb4:	movabs rcx,0xff00ff00ff00ff00
    7c33ec901cbe:	mov    r15,rbp
    7c33ec901cc1:	and    r15,rcx
    7c33ec901cc4:	shr    r15,0x8
    7c33ec901cc8:	mov    rcx,r13
    7c33ec901ccb:	or     r15,rcx
    7c33ec901cce:	movabs rcx,0xffff0000ffff
    7c33ec901cd8:	mov    r13,r15
    7c33ec901cdb:	and    r13,rcx
    7c33ec901cde:	shl    r13,0x10
    7c33ec901ce2:	movabs rcx,0xffff0000ffff0000
    7c33ec901cec:	and    r15,rcx
    7c33ec901cef:	shr    r15,0x10
    7c33ec901cf3:	mov    rcx,r13
    7c33ec901cf6:	or     r15,rcx
    7c33ec901cf9:	mov    ecx,0xffffffff
    7c33ec901cfe:	and    r15,rcx
    7c33ec901d01:	mov    QWORD PTR [r12+0x50],r15
    7c33ec901d06:	mov    r13d,0x0
    7c33ec901d0c:	mov    QWORD PTR [r12+0xa0],r13
    7c33ec901d14:	mov    r13d,0x430c90
    7c33ec901d1a:	mov    ebp,0x430c94
    7c33ec901d1f:	mov    rax,r14
    7c33ec901d22:	mov    eax,eax
    7c33ec901d24:	mov    r8d,eax
    7c33ec901d27:	mov    rax,r15
    7c33ec901d2a:	mov    eax,eax
    7c33ec901d2c:	mov    r14d,eax
    7c33ec901d2f:	mov    DWORD PTR [r13+0x0],r8d
    7c33ec901d33:	mov    r13d,0x0
    7c33ec901d39:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec901d41:	mov    DWORD PTR [rbp+0x0],r14d
    7c33ec901d45:	mov    r13d,0x0
    7c33ec901d4b:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec901d53:	mov    r13d,DWORD PTR [r12+0x58]
    7c33ec901d58:	movabs rcx,0xff00ff00ff00ff
    7c33ec901d62:	mov    r14,r13
    7c33ec901d65:	and    r14,rcx
    7c33ec901d68:	shl    r14,0x8
    7c33ec901d6c:	movabs rcx,0xff00ff00ff00ff00
    7c33ec901d76:	mov    r15,r13
    7c33ec901d79:	and    r15,rcx
    7c33ec901d7c:	shr    r15,0x8
    7c33ec901d80:	mov    rcx,r14
    7c33ec901d83:	or     r15,rcx
    7c33ec901d86:	movabs rcx,0xffff0000ffff
    7c33ec901d90:	mov    r13,r15
    7c33ec901d93:	and    r13,rcx
    7c33ec901d96:	shl    r13,0x10
    7c33ec901d9a:	movabs rcx,0xffff0000ffff0000
    7c33ec901da4:	and    r15,rcx
    7c33ec901da7:	shr    r15,0x10
    7c33ec901dab:	mov    rcx,r13
    7c33ec901dae:	or     r15,rcx
    7c33ec901db1:	mov    ecx,0xffffffff
    7c33ec901db6:	and    r15,rcx
    7c33ec901db9:	mov    QWORD PTR [r12+0x40],r15
    7c33ec901dbe:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec901dc6:	mov    r14,r13
    7c33ec901dc9:	add    r14,0x110
    7c33ec901dd0:	mov    ebp,DWORD PTR [r14]
    7c33ec901dd3:	mov    QWORD PTR [r12+0x50],rbp
    7c33ec901dd8:	mov    r14d,DWORD PTR [r12+0x60]
    7c33ec901ddd:	movabs rcx,0xff00ff00ff00ff
    7c33ec901de7:	mov    rbp,r14
    7c33ec901dea:	and    rbp,rcx
    7c33ec901ded:	shl    rbp,0x8
    7c33ec901df1:	movabs rcx,0xff00ff00ff00ff00
    7c33ec901dfb:	mov    r8,r14
    7c33ec901dfe:	and    r8,rcx
    7c33ec901e01:	shr    r8,0x8
    7c33ec901e05:	mov    rcx,rbp
    7c33ec901e08:	or     r8,rcx
    7c33ec901e0b:	movabs rcx,0xffff0000ffff
    7c33ec901e15:	mov    r14,r8
    7c33ec901e18:	and    r14,rcx
    7c33ec901e1b:	shl    r14,0x10
    7c33ec901e1f:	movabs rcx,0xffff0000ffff0000
    7c33ec901e29:	and    r8,rcx
    7c33ec901e2c:	shr    r8,0x10
    7c33ec901e30:	mov    rcx,r14
    7c33ec901e33:	or     r8,rcx
    7c33ec901e36:	mov    ecx,0xffffffff
    7c33ec901e3b:	and    r8,rcx
    7c33ec901e3e:	mov    QWORD PTR [r12+0x58],r8
    7c33ec901e43:	add    r13,0x114
    7c33ec901e4a:	mov    r14d,DWORD PTR [r13+0x0]
    7c33ec901e4e:	mov    QWORD PTR [r12+0x60],r14
    7c33ec901e53:	mov    r13d,0x430000
    7c33ec901e59:	add    r13,0xdfc
    7c33ec901e60:	mov    QWORD PTR [r12+0x98],r13
    7c33ec901e68:	mov    r13,QWORD PTR [r12+0x48]
    7c33ec901e6d:	add    r13,0x8
    7c33ec901e71:	mov    r14,r13
    7c33ec901e74:	add    r14,0x4
    7c33ec901e78:	mov    rax,r15
    7c33ec901e7b:	mov    eax,eax
    7c33ec901e7d:	mov    ebp,eax
    7c33ec901e7f:	mov    rax,r8
    7c33ec901e82:	mov    eax,eax
    7c33ec901e84:	mov    r15d,eax
    7c33ec901e87:	mov    DWORD PTR [r13+0x0],ebp
    7c33ec901e8b:	mov    r13d,0x0
    7c33ec901e91:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec901e99:	mov    DWORD PTR [r14],r15d
    7c33ec901e9c:	mov    r13d,0x0
    7c33ec901ea2:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec901eaa:	mov    r13d,DWORD PTR [r12+0x50]
    7c33ec901eaf:	movabs rcx,0xff00ff00ff00ff
    7c33ec901eb9:	mov    r14,r13
    7c33ec901ebc:	and    r14,rcx
    7c33ec901ebf:	shl    r14,0x8
    7c33ec901ec3:	movabs rcx,0xff00ff00ff00ff00
    7c33ec901ecd:	mov    r15,r13
    7c33ec901ed0:	and    r15,rcx
    7c33ec901ed3:	shr    r15,0x8
    7c33ec901ed7:	mov    rcx,r14
    7c33ec901eda:	or     r15,rcx
    7c33ec901edd:	movabs rcx,0xffff0000ffff
    7c33ec901ee7:	mov    r13,r15
    7c33ec901eea:	and    r13,rcx
    7c33ec901eed:	shl    r13,0x10
    7c33ec901ef1:	movabs rcx,0xffff0000ffff0000
    7c33ec901efb:	and    r15,rcx
    7c33ec901efe:	shr    r15,0x10
    7c33ec901f02:	mov    rcx,r13
    7c33ec901f05:	or     r15,rcx
    7c33ec901f08:	mov    ecx,0xffffffff
    7c33ec901f0d:	and    r15,rcx
    7c33ec901f10:	mov    QWORD PTR [r12+0x40],r15
    7c33ec901f15:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec901f1d:	mov    r14,r13
    7c33ec901f20:	add    r14,0x118
    7c33ec901f27:	mov    ebp,DWORD PTR [r14]
    7c33ec901f2a:	mov    QWORD PTR [r12+0x50],rbp
    7c33ec901f2f:	mov    r14d,DWORD PTR [r12+0x60]
    7c33ec901f34:	movabs rcx,0xff00ff00ff00ff
    7c33ec901f3e:	mov    r8,r14
    7c33ec901f41:	and    r8,rcx
    7c33ec901f44:	shl    r8,0x8
    7c33ec901f48:	movabs rcx,0xff00ff00ff00ff00
    7c33ec901f52:	mov    r9,r14
    7c33ec901f55:	and    r9,rcx
    7c33ec901f58:	shr    r9,0x8
    7c33ec901f5c:	mov    rcx,r8
    7c33ec901f5f:	or     r9,rcx
    7c33ec901f62:	movabs rcx,0xffff0000ffff
    7c33ec901f6c:	mov    r14,r9
    7c33ec901f6f:	and    r14,rcx
    7c33ec901f72:	shl    r14,0x10
    7c33ec901f76:	movabs rcx,0xffff0000ffff0000
    7c33ec901f80:	and    r9,rcx
    7c33ec901f83:	shr    r9,0x10
    7c33ec901f87:	mov    rcx,r14
    7c33ec901f8a:	or     r9,rcx
    7c33ec901f8d:	mov    ecx,0xffffffff
    7c33ec901f92:	and    r9,rcx
    7c33ec901f95:	mov    QWORD PTR [r12+0x58],r9
    7c33ec901f9a:	add    r13,0x11c
    7c33ec901fa1:	mov    eax,DWORD PTR [r13+0x0]
    7c33ec901fa5:	mov    QWORD PTR [rsp+0x8],rax
    7c33ec901faa:	mov    rax,QWORD PTR [rsp+0x8]
    7c33ec901faf:	mov    QWORD PTR [r12+0x60],rax
    7c33ec901fb4:	mov    rax,QWORD PTR [r12+0x48]
    7c33ec901fb9:	mov    QWORD PTR [rsp],rax
    7c33ec901fbd:	mov    r8,QWORD PTR [rsp]
    7c33ec901fc1:	add    r8,0x10
    7c33ec901fc5:	mov    r13,r8
    7c33ec901fc8:	add    r13,0x4
    7c33ec901fcc:	mov    rax,r15
    7c33ec901fcf:	mov    eax,eax
    7c33ec901fd1:	mov    r14d,eax
    7c33ec901fd4:	mov    rax,r9
    7c33ec901fd7:	mov    eax,eax
    7c33ec901fd9:	mov    r15d,eax
    7c33ec901fdc:	mov    DWORD PTR [r8],r14d
    7c33ec901fdf:	mov    r14d,0x0
    7c33ec901fe5:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec901fed:	mov    DWORD PTR [r13+0x0],r15d
    7c33ec901ff1:	mov    r13d,0x0
    7c33ec901ff7:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec901fff:	movabs rcx,0xff00ff00ff00ff
    7c33ec902009:	mov    r13,rbp
    7c33ec90200c:	and    r13,rcx
    7c33ec90200f:	shl    r13,0x8
    7c33ec902013:	movabs rcx,0xff00ff00ff00ff00
    7c33ec90201d:	mov    r14,rbp
    7c33ec902020:	and    r14,rcx
    7c33ec902023:	shr    r14,0x8
    7c33ec902027:	mov    rcx,r13
    7c33ec90202a:	or     r14,rcx
    7c33ec90202d:	movabs rcx,0xffff0000ffff
    7c33ec902037:	mov    r13,r14
    7c33ec90203a:	and    r13,rcx
    7c33ec90203d:	shl    r13,0x10
    7c33ec902041:	movabs rcx,0xffff0000ffff0000
    7c33ec90204b:	and    r14,rcx
    7c33ec90204e:	shr    r14,0x10
    7c33ec902052:	mov    rcx,r13
    7c33ec902055:	or     r14,rcx
    7c33ec902058:	mov    ecx,0xffffffff
    7c33ec90205d:	and    r14,rcx
    7c33ec902060:	mov    QWORD PTR [r12+0x40],r14
    7c33ec902065:	movabs rcx,0xff00ff00ff00ff
    7c33ec90206f:	mov    r13,QWORD PTR [rsp+0x8]
    7c33ec902074:	and    r13,rcx
    7c33ec902077:	shl    r13,0x8
    7c33ec90207b:	movabs rcx,0xff00ff00ff00ff00
    7c33ec902085:	mov    r15,QWORD PTR [rsp+0x8]
    7c33ec90208a:	and    r15,rcx
    7c33ec90208d:	shr    r15,0x8
    7c33ec902091:	mov    rcx,r13
    7c33ec902094:	or     r15,rcx
    7c33ec902097:	movabs rcx,0xffff0000ffff
    7c33ec9020a1:	mov    r13,r15
    7c33ec9020a4:	and    r13,rcx
    7c33ec9020a7:	shl    r13,0x10
    7c33ec9020ab:	movabs rcx,0xffff0000ffff0000
    7c33ec9020b5:	and    r15,rcx
    7c33ec9020b8:	shr    r15,0x10
    7c33ec9020bc:	mov    rcx,r13
    7c33ec9020bf:	or     r15,rcx
    7c33ec9020c2:	mov    ecx,0xffffffff
    7c33ec9020c7:	and    r15,rcx
    7c33ec9020ca:	mov    QWORD PTR [r12+0x50],r15
    7c33ec9020cf:	mov    r13,QWORD PTR [rsp]
    7c33ec9020d3:	add    r13,0x18
    7c33ec9020d7:	mov    rbp,r13
    7c33ec9020da:	add    rbp,0x4
    7c33ec9020de:	mov    rax,r14
    7c33ec9020e1:	mov    eax,eax
    7c33ec9020e3:	mov    r8d,eax
    7c33ec9020e6:	mov    rax,r15
    7c33ec9020e9:	mov    eax,eax
    7c33ec9020eb:	mov    r14d,eax
    7c33ec9020ee:	mov    DWORD PTR [r13+0x0],r8d
    7c33ec9020f2:	mov    r13d,0x0
    7c33ec9020f8:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec902100:	mov    DWORD PTR [rbp+0x0],r14d
    7c33ec902104:	mov    r13d,0x0
    7c33ec90210a:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec902112:	mov    r13d,DWORD PTR [r12+0xa0]
    7c33ec90211a:	add    r13d,0x11
    7c33ec90211e:	mov    QWORD PTR [r12],r13
    7c33ec902122:	mov    r13d,0x41035c
    7c33ec902128:	mov    QWORD PTR [r12+0xf0],r13
    7c33ec902130:	mov    r13d,0x4109a4
    7c33ec902136:	mov    QWORD PTR [r12+0x100],r13
    7c33ec90213e:	mov    r11,QWORD PTR [rsp+0x10]
    7c33ec902143:	mov    QWORD PTR [r12+0x398],r11
    7c33ec90214b:	mov    edi,0x4109a4
    7c33ec902150:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec902158:	add    rsp,0x20
    7c33ec90215c:	nop    DWORD PTR [rax+0x0]
    7c33ec902160:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec902168
    7c33ec902166:	xchg   ax,ax
    7c33ec902168:	nop
    7c33ec902169:	and    DWORD PTR [rax+0x7c33ec],edx
    7c33ec90216f:	add    BYTE PTR [rax+0x21],bh
    7c33ec902172:	nop
    7c33ec902173:	in     al,dx
    7c33ec902174:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec902178:	movabs r11,0x5585303950a0
    7c33ec902182:	jmp    r11
    7c33ec902185:	nop
    7c33ec902186:	nop
    7c33ec902187:	nop
