
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/1/5.bin:     file format binary


Disassembly of section .data:

0000707120f01bd0 <.data>:
    707120f01bd0:	sub    rsp,0x20
    707120f01bd4:	mov    r11,QWORD PTR [r12+0x398]
    707120f01bdc:	mov    QWORD PTR [rsp+0x10],r11
    707120f01be1:	mov    r13,QWORD PTR [r12+0xf8]
    707120f01be9:	mov    r14,r13
    707120f01bec:	add    r14,0x100
    707120f01bf3:	mov    r15d,DWORD PTR [r14]
    707120f01bf6:	mov    QWORD PTR [r12+0x40],r15
    707120f01bfb:	mov    r14,r13
    707120f01bfe:	add    r14,0x104
    707120f01c05:	mov    ebp,DWORD PTR [r14]
    707120f01c08:	mov    QWORD PTR [r12+0x50],rbp
    707120f01c0d:	mov    r14d,0x430c90
    707120f01c13:	mov    QWORD PTR [r12+0x48],r14
    707120f01c18:	mov    r14,r13
    707120f01c1b:	add    r14,0x108
    707120f01c22:	mov    r8d,DWORD PTR [r14]
    707120f01c25:	mov    QWORD PTR [r12+0x58],r8
    707120f01c2a:	add    r13,0x10c
    707120f01c31:	mov    r14d,DWORD PTR [r13+0x0]
    707120f01c35:	mov    QWORD PTR [r12+0x60],r14
    707120f01c3a:	movabs rcx,0xff00ff00ff00ff
    707120f01c44:	mov    r13,r15
    707120f01c47:	and    r13,rcx
    707120f01c4a:	shl    r13,0x8
    707120f01c4e:	movabs rcx,0xff00ff00ff00ff00
    707120f01c58:	mov    r14,r15
    707120f01c5b:	and    r14,rcx
    707120f01c5e:	shr    r14,0x8
    707120f01c62:	mov    rcx,r13
    707120f01c65:	or     r14,rcx
    707120f01c68:	movabs rcx,0xffff0000ffff
    707120f01c72:	mov    r13,r14
    707120f01c75:	and    r13,rcx
    707120f01c78:	shl    r13,0x10
    707120f01c7c:	movabs rcx,0xffff0000ffff0000
    707120f01c86:	and    r14,rcx
    707120f01c89:	shr    r14,0x10
    707120f01c8d:	mov    rcx,r13
    707120f01c90:	or     r14,rcx
    707120f01c93:	mov    ecx,0xffffffff
    707120f01c98:	and    r14,rcx
    707120f01c9b:	mov    QWORD PTR [r12+0x40],r14
    707120f01ca0:	movabs rcx,0xff00ff00ff00ff
    707120f01caa:	mov    r13,rbp
    707120f01cad:	and    r13,rcx
    707120f01cb0:	shl    r13,0x8
    707120f01cb4:	movabs rcx,0xff00ff00ff00ff00
    707120f01cbe:	mov    r15,rbp
    707120f01cc1:	and    r15,rcx
    707120f01cc4:	shr    r15,0x8
    707120f01cc8:	mov    rcx,r13
    707120f01ccb:	or     r15,rcx
    707120f01cce:	movabs rcx,0xffff0000ffff
    707120f01cd8:	mov    r13,r15
    707120f01cdb:	and    r13,rcx
    707120f01cde:	shl    r13,0x10
    707120f01ce2:	movabs rcx,0xffff0000ffff0000
    707120f01cec:	and    r15,rcx
    707120f01cef:	shr    r15,0x10
    707120f01cf3:	mov    rcx,r13
    707120f01cf6:	or     r15,rcx
    707120f01cf9:	mov    ecx,0xffffffff
    707120f01cfe:	and    r15,rcx
    707120f01d01:	mov    QWORD PTR [r12+0x50],r15
    707120f01d06:	mov    r13d,0x0
    707120f01d0c:	mov    QWORD PTR [r12+0xa0],r13
    707120f01d14:	mov    r13d,0x430c90
    707120f01d1a:	mov    ebp,0x430c94
    707120f01d1f:	mov    rax,r14
    707120f01d22:	mov    eax,eax
    707120f01d24:	mov    r8d,eax
    707120f01d27:	mov    rax,r15
    707120f01d2a:	mov    eax,eax
    707120f01d2c:	mov    r14d,eax
    707120f01d2f:	mov    DWORD PTR [r13+0x0],r8d
    707120f01d33:	mov    r13d,0x0
    707120f01d39:	mov    DWORD PTR [r12+0x32c],r13d
    707120f01d41:	mov    DWORD PTR [rbp+0x0],r14d
    707120f01d45:	mov    r13d,0x0
    707120f01d4b:	mov    DWORD PTR [r12+0x32c],r13d
    707120f01d53:	mov    r13d,DWORD PTR [r12+0x58]
    707120f01d58:	movabs rcx,0xff00ff00ff00ff
    707120f01d62:	mov    r14,r13
    707120f01d65:	and    r14,rcx
    707120f01d68:	shl    r14,0x8
    707120f01d6c:	movabs rcx,0xff00ff00ff00ff00
    707120f01d76:	mov    r15,r13
    707120f01d79:	and    r15,rcx
    707120f01d7c:	shr    r15,0x8
    707120f01d80:	mov    rcx,r14
    707120f01d83:	or     r15,rcx
    707120f01d86:	movabs rcx,0xffff0000ffff
    707120f01d90:	mov    r13,r15
    707120f01d93:	and    r13,rcx
    707120f01d96:	shl    r13,0x10
    707120f01d9a:	movabs rcx,0xffff0000ffff0000
    707120f01da4:	and    r15,rcx
    707120f01da7:	shr    r15,0x10
    707120f01dab:	mov    rcx,r13
    707120f01dae:	or     r15,rcx
    707120f01db1:	mov    ecx,0xffffffff
    707120f01db6:	and    r15,rcx
    707120f01db9:	mov    QWORD PTR [r12+0x40],r15
    707120f01dbe:	mov    r13,QWORD PTR [r12+0xf8]
    707120f01dc6:	mov    r14,r13
    707120f01dc9:	add    r14,0x110
    707120f01dd0:	mov    ebp,DWORD PTR [r14]
    707120f01dd3:	mov    QWORD PTR [r12+0x50],rbp
    707120f01dd8:	mov    r14d,DWORD PTR [r12+0x60]
    707120f01ddd:	movabs rcx,0xff00ff00ff00ff
    707120f01de7:	mov    rbp,r14
    707120f01dea:	and    rbp,rcx
    707120f01ded:	shl    rbp,0x8
    707120f01df1:	movabs rcx,0xff00ff00ff00ff00
    707120f01dfb:	mov    r8,r14
    707120f01dfe:	and    r8,rcx
    707120f01e01:	shr    r8,0x8
    707120f01e05:	mov    rcx,rbp
    707120f01e08:	or     r8,rcx
    707120f01e0b:	movabs rcx,0xffff0000ffff
    707120f01e15:	mov    r14,r8
    707120f01e18:	and    r14,rcx
    707120f01e1b:	shl    r14,0x10
    707120f01e1f:	movabs rcx,0xffff0000ffff0000
    707120f01e29:	and    r8,rcx
    707120f01e2c:	shr    r8,0x10
    707120f01e30:	mov    rcx,r14
    707120f01e33:	or     r8,rcx
    707120f01e36:	mov    ecx,0xffffffff
    707120f01e3b:	and    r8,rcx
    707120f01e3e:	mov    QWORD PTR [r12+0x58],r8
    707120f01e43:	add    r13,0x114
    707120f01e4a:	mov    r14d,DWORD PTR [r13+0x0]
    707120f01e4e:	mov    QWORD PTR [r12+0x60],r14
    707120f01e53:	mov    r13d,0x430000
    707120f01e59:	add    r13,0xdfc
    707120f01e60:	mov    QWORD PTR [r12+0x98],r13
    707120f01e68:	mov    r13,QWORD PTR [r12+0x48]
    707120f01e6d:	add    r13,0x8
    707120f01e71:	mov    r14,r13
    707120f01e74:	add    r14,0x4
    707120f01e78:	mov    rax,r15
    707120f01e7b:	mov    eax,eax
    707120f01e7d:	mov    ebp,eax
    707120f01e7f:	mov    rax,r8
    707120f01e82:	mov    eax,eax
    707120f01e84:	mov    r15d,eax
    707120f01e87:	mov    DWORD PTR [r13+0x0],ebp
    707120f01e8b:	mov    r13d,0x0
    707120f01e91:	mov    DWORD PTR [r12+0x32c],r13d
    707120f01e99:	mov    DWORD PTR [r14],r15d
    707120f01e9c:	mov    r13d,0x0
    707120f01ea2:	mov    DWORD PTR [r12+0x32c],r13d
    707120f01eaa:	mov    r13d,DWORD PTR [r12+0x50]
    707120f01eaf:	movabs rcx,0xff00ff00ff00ff
    707120f01eb9:	mov    r14,r13
    707120f01ebc:	and    r14,rcx
    707120f01ebf:	shl    r14,0x8
    707120f01ec3:	movabs rcx,0xff00ff00ff00ff00
    707120f01ecd:	mov    r15,r13
    707120f01ed0:	and    r15,rcx
    707120f01ed3:	shr    r15,0x8
    707120f01ed7:	mov    rcx,r14
    707120f01eda:	or     r15,rcx
    707120f01edd:	movabs rcx,0xffff0000ffff
    707120f01ee7:	mov    r13,r15
    707120f01eea:	and    r13,rcx
    707120f01eed:	shl    r13,0x10
    707120f01ef1:	movabs rcx,0xffff0000ffff0000
    707120f01efb:	and    r15,rcx
    707120f01efe:	shr    r15,0x10
    707120f01f02:	mov    rcx,r13
    707120f01f05:	or     r15,rcx
    707120f01f08:	mov    ecx,0xffffffff
    707120f01f0d:	and    r15,rcx
    707120f01f10:	mov    QWORD PTR [r12+0x40],r15
    707120f01f15:	mov    r13,QWORD PTR [r12+0xf8]
    707120f01f1d:	mov    r14,r13
    707120f01f20:	add    r14,0x118
    707120f01f27:	mov    ebp,DWORD PTR [r14]
    707120f01f2a:	mov    QWORD PTR [r12+0x50],rbp
    707120f01f2f:	mov    r14d,DWORD PTR [r12+0x60]
    707120f01f34:	movabs rcx,0xff00ff00ff00ff
    707120f01f3e:	mov    r8,r14
    707120f01f41:	and    r8,rcx
    707120f01f44:	shl    r8,0x8
    707120f01f48:	movabs rcx,0xff00ff00ff00ff00
    707120f01f52:	mov    r9,r14
    707120f01f55:	and    r9,rcx
    707120f01f58:	shr    r9,0x8
    707120f01f5c:	mov    rcx,r8
    707120f01f5f:	or     r9,rcx
    707120f01f62:	movabs rcx,0xffff0000ffff
    707120f01f6c:	mov    r14,r9
    707120f01f6f:	and    r14,rcx
    707120f01f72:	shl    r14,0x10
    707120f01f76:	movabs rcx,0xffff0000ffff0000
    707120f01f80:	and    r9,rcx
    707120f01f83:	shr    r9,0x10
    707120f01f87:	mov    rcx,r14
    707120f01f8a:	or     r9,rcx
    707120f01f8d:	mov    ecx,0xffffffff
    707120f01f92:	and    r9,rcx
    707120f01f95:	mov    QWORD PTR [r12+0x58],r9
    707120f01f9a:	add    r13,0x11c
    707120f01fa1:	mov    eax,DWORD PTR [r13+0x0]
    707120f01fa5:	mov    QWORD PTR [rsp+0x8],rax
    707120f01faa:	mov    rax,QWORD PTR [rsp+0x8]
    707120f01faf:	mov    QWORD PTR [r12+0x60],rax
    707120f01fb4:	mov    rax,QWORD PTR [r12+0x48]
    707120f01fb9:	mov    QWORD PTR [rsp],rax
    707120f01fbd:	mov    r8,QWORD PTR [rsp]
    707120f01fc1:	add    r8,0x10
    707120f01fc5:	mov    r13,r8
    707120f01fc8:	add    r13,0x4
    707120f01fcc:	mov    rax,r15
    707120f01fcf:	mov    eax,eax
    707120f01fd1:	mov    r14d,eax
    707120f01fd4:	mov    rax,r9
    707120f01fd7:	mov    eax,eax
    707120f01fd9:	mov    r15d,eax
    707120f01fdc:	mov    DWORD PTR [r8],r14d
    707120f01fdf:	mov    r14d,0x0
    707120f01fe5:	mov    DWORD PTR [r12+0x32c],r14d
    707120f01fed:	mov    DWORD PTR [r13+0x0],r15d
    707120f01ff1:	mov    r13d,0x0
    707120f01ff7:	mov    DWORD PTR [r12+0x32c],r13d
    707120f01fff:	movabs rcx,0xff00ff00ff00ff
    707120f02009:	mov    r13,rbp
    707120f0200c:	and    r13,rcx
    707120f0200f:	shl    r13,0x8
    707120f02013:	movabs rcx,0xff00ff00ff00ff00
    707120f0201d:	mov    r14,rbp
    707120f02020:	and    r14,rcx
    707120f02023:	shr    r14,0x8
    707120f02027:	mov    rcx,r13
    707120f0202a:	or     r14,rcx
    707120f0202d:	movabs rcx,0xffff0000ffff
    707120f02037:	mov    r13,r14
    707120f0203a:	and    r13,rcx
    707120f0203d:	shl    r13,0x10
    707120f02041:	movabs rcx,0xffff0000ffff0000
    707120f0204b:	and    r14,rcx
    707120f0204e:	shr    r14,0x10
    707120f02052:	mov    rcx,r13
    707120f02055:	or     r14,rcx
    707120f02058:	mov    ecx,0xffffffff
    707120f0205d:	and    r14,rcx
    707120f02060:	mov    QWORD PTR [r12+0x40],r14
    707120f02065:	movabs rcx,0xff00ff00ff00ff
    707120f0206f:	mov    r13,QWORD PTR [rsp+0x8]
    707120f02074:	and    r13,rcx
    707120f02077:	shl    r13,0x8
    707120f0207b:	movabs rcx,0xff00ff00ff00ff00
    707120f02085:	mov    r15,QWORD PTR [rsp+0x8]
    707120f0208a:	and    r15,rcx
    707120f0208d:	shr    r15,0x8
    707120f02091:	mov    rcx,r13
    707120f02094:	or     r15,rcx
    707120f02097:	movabs rcx,0xffff0000ffff
    707120f020a1:	mov    r13,r15
    707120f020a4:	and    r13,rcx
    707120f020a7:	shl    r13,0x10
    707120f020ab:	movabs rcx,0xffff0000ffff0000
    707120f020b5:	and    r15,rcx
    707120f020b8:	shr    r15,0x10
    707120f020bc:	mov    rcx,r13
    707120f020bf:	or     r15,rcx
    707120f020c2:	mov    ecx,0xffffffff
    707120f020c7:	and    r15,rcx
    707120f020ca:	mov    QWORD PTR [r12+0x50],r15
    707120f020cf:	mov    r13,QWORD PTR [rsp]
    707120f020d3:	add    r13,0x18
    707120f020d7:	mov    rbp,r13
    707120f020da:	add    rbp,0x4
    707120f020de:	mov    rax,r14
    707120f020e1:	mov    eax,eax
    707120f020e3:	mov    r8d,eax
    707120f020e6:	mov    rax,r15
    707120f020e9:	mov    eax,eax
    707120f020eb:	mov    r14d,eax
    707120f020ee:	mov    DWORD PTR [r13+0x0],r8d
    707120f020f2:	mov    r13d,0x0
    707120f020f8:	mov    DWORD PTR [r12+0x32c],r13d
    707120f02100:	mov    DWORD PTR [rbp+0x0],r14d
    707120f02104:	mov    r13d,0x0
    707120f0210a:	mov    DWORD PTR [r12+0x32c],r13d
    707120f02112:	mov    r13d,DWORD PTR [r12+0xa0]
    707120f0211a:	add    r13d,0x11
    707120f0211e:	mov    QWORD PTR [r12],r13
    707120f02122:	mov    r13d,0x41035c
    707120f02128:	mov    QWORD PTR [r12+0xf0],r13
    707120f02130:	mov    r13d,0x4109a4
    707120f02136:	mov    QWORD PTR [r12+0x100],r13
    707120f0213e:	mov    r11,QWORD PTR [rsp+0x10]
    707120f02143:	mov    QWORD PTR [r12+0x398],r11
    707120f0214b:	mov    edi,0x4109a4
    707120f02150:	mov    QWORD PTR [r12+0x100],rdi
    707120f02158:	add    rsp,0x20
    707120f0215c:	nop    DWORD PTR [rax+0x0]
    707120f02160:	jmp    QWORD PTR [rip+0x2]        # 0x707120f02168
    707120f02166:	xchg   ax,ax
    707120f02168:	nop
    707120f02169:	and    eax,esi
    707120f0216b:	and    BYTE PTR [rcx+0x70],dh
    707120f0216e:	add    BYTE PTR [rax],al
    707120f02170:	js     0x707120f02193
    707120f02172:	lock and BYTE PTR [rcx+0x70],dh
    707120f02176:	add    BYTE PTR [rax],al
    707120f02178:	movabs r11,0x5ab6724ae0a0
    707120f02182:	jmp    r11
    707120f02185:	nop
    707120f02186:	nop
    707120f02187:	nop
