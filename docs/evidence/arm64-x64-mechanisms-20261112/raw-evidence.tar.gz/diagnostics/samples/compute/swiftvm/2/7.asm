
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/2/7.bin:     file format binary


Disassembly of section .data:

0000786625d02390 <.data>:
    786625d02390:	sub    rsp,0x10
    786625d02394:	mov    r11,QWORD PTR [r12+0x398]
    786625d0239c:	mov    QWORD PTR [rsp],r11
    786625d023a0:	mov    r13,QWORD PTR [r12+0xa0]
    786625d023a8:	mov    r14,r13
    786625d023ab:	shl    r14,0x2
    786625d023af:	mov    r15,QWORD PTR [r12+0x98]
    786625d023b7:	mov    rcx,r14
    786625d023ba:	add    r15,rcx
    786625d023bd:	mov    r14d,DWORD PTR [r12]
    786625d023c1:	mov    DWORD PTR [r15],r14d
    786625d023c4:	mov    r14d,0x0
    786625d023ca:	mov    DWORD PTR [r12+0x32c],r14d
    786625d023d2:	add    r13,0x1
    786625d023d6:	mov    QWORD PTR [r12+0xa0],r13
    786625d023de:	sub    r13,0x400
    786625d023e5:	mov    rcx,QWORD PTR [r12+0x380]
    786625d023ed:	jrcxz  0x786625d023f4
    786625d023ef:	jmp    0x786625d027e5
    786625d023f4:	pushf
    786625d023f5:	pop    r11
    786625d023f7:	mov    QWORD PTR [rsp],r11
    786625d023fb:	jne    0x786625d02775
    786625d02401:	jmp    0x786625d02406
    786625d02406:	mov    r13d,0x1
    786625d0240c:	mov    QWORD PTR [r12+0x40],r13
    786625d02411:	jmp    0x786625d02416
    786625d02416:	mov    r13,QWORD PTR [r12+0x40]
    786625d0241b:	mov    r14,r13
    786625d0241e:	shl    r14,0x2
    786625d02422:	mov    r15,QWORD PTR [r12+0x98]
    786625d0242a:	mov    rcx,r14
    786625d0242d:	add    r15,rcx
    786625d02430:	mov    r14d,DWORD PTR [r15]
    786625d02433:	mov    QWORD PTR [r12+0x48],r14
    786625d02438:	mov    r14d,0x0
    786625d0243e:	mov    rcx,r13
    786625d02441:	or     r14,rcx
    786625d02444:	mov    QWORD PTR [r12+0x50],r14
    786625d02449:	jmp    0x786625d0244e
    786625d0244e:	mov    r13d,DWORD PTR [r12+0x50]
    786625d02453:	sub    r13d,0x1
    786625d02457:	mov    QWORD PTR [r12+0x58],r13
    786625d0245c:	mov    ecx,0xffffffff
    786625d02461:	mov    r14,r13
    786625d02464:	and    r14,rcx
    786625d02467:	shl    r14,0x2
    786625d0246b:	mov    r13,QWORD PTR [r12+0x98]
    786625d02473:	mov    rcx,r14
    786625d02476:	add    r13,rcx
    786625d02479:	mov    r14d,DWORD PTR [r13+0x0]
    786625d0247d:	mov    QWORD PTR [r12+0x60],r14
    786625d02482:	mov    r13d,DWORD PTR [r12+0x48]
    786625d02487:	mov    ecx,r13d
    786625d0248a:	sub    r14d,ecx
    786625d0248d:	mov    rcx,QWORD PTR [r12+0x380]
    786625d02495:	jrcxz  0x786625d0249c
    786625d02497:	jmp    0x786625d02874
    786625d0249c:	sete   al
    786625d0249f:	movzx  eax,al
    786625d024a2:	mov    r13,rax
    786625d024a5:	setb   al
    786625d024a8:	movzx  eax,al
    786625d024ab:	mov    r14,rax
    786625d024ae:	pushf
    786625d024af:	pop    r11
    786625d024b1:	mov    QWORD PTR [rsp],r11
    786625d024b5:	mov    rcx,r13
    786625d024b8:	and    ecx,0xff
    786625d024be:	mov    r15,r14
    786625d024c1:	and    r15d,0xff
    786625d024c8:	or     r15,rcx
    786625d024cb:	and    r15d,0xff
    786625d024d2:	mov    rax,r15
    786625d024d5:	and    eax,0xff
    786625d024da:	test   rax,rax
    786625d024dd:	jne    0x786625d0257f
    786625d024e3:	jmp    0x786625d024e8
    786625d024e8:	mov    r13,QWORD PTR [r12+0x50]
    786625d024ed:	mov    r14,r13
    786625d024f0:	shl    r14,0x2
    786625d024f4:	mov    r15,QWORD PTR [r12+0x98]
    786625d024fc:	mov    rcx,r14
    786625d024ff:	add    r15,rcx
    786625d02502:	mov    r14d,DWORD PTR [r12+0x60]
    786625d02507:	mov    DWORD PTR [r15],r14d
    786625d0250a:	mov    r14d,0x0
    786625d02510:	mov    DWORD PTR [r12+0x32c],r14d
    786625d02518:	sub    r13,0x1
    786625d0251c:	mov    QWORD PTR [r12+0x50],r13
    786625d02521:	mov    rcx,QWORD PTR [r12+0x380]
    786625d02529:	jrcxz  0x786625d02530
    786625d0252b:	jmp    0x786625d02903
    786625d02530:	mov    r13,QWORD PTR [r12+0x58]
    786625d02535:	mov    rax,r13
    786625d02538:	test   rax,rax
    786625d0253b:	setne  al
    786625d0253e:	movzx  eax,al
    786625d02541:	and    eax,0x1
    786625d02544:	mov    r14,rax
    786625d02547:	mov    rax,r14
    786625d0254a:	and    eax,0x1
    786625d0254d:	test   rax,rax
    786625d02550:	jne    0x786625d0244e
    786625d02556:	jmp    0x786625d0255b
    786625d0255b:	mov    rcx,QWORD PTR [r12+0x380]
    786625d02563:	jrcxz  0x786625d0256a
    786625d02565:	jmp    0x786625d0298a
    786625d0256a:	jmp    0x786625d0256f
    786625d0256f:	mov    r13d,0x0
    786625d02575:	mov    QWORD PTR [r12+0x50],r13
    786625d0257a:	jmp    0x786625d0257f
    786625d0257f:	mov    r13,QWORD PTR [r12+0x40]
    786625d02584:	add    r13,0x1
    786625d02588:	mov    QWORD PTR [r12+0x40],r13
    786625d0258d:	mov    r14,QWORD PTR [r12+0x50]
    786625d02592:	mov    ecx,0xffffffff
    786625d02597:	and    r14,rcx
    786625d0259a:	shl    r14,0x2
    786625d0259e:	mov    r15,QWORD PTR [r12+0x98]
    786625d025a6:	mov    rcx,r14
    786625d025a9:	add    r15,rcx
    786625d025ac:	mov    r14d,DWORD PTR [r12+0x48]
    786625d025b1:	mov    DWORD PTR [r15],r14d
    786625d025b4:	mov    r14d,0x0
    786625d025ba:	mov    DWORD PTR [r12+0x32c],r14d
    786625d025c2:	sub    r13,0x400
    786625d025c9:	pushf
    786625d025ca:	pop    r11
    786625d025cc:	mov    QWORD PTR [rsp],r11
    786625d025d0:	je     0x786625d025db
    786625d025d6:	jmp    0x786625d02416
    786625d025db:	mov    r13d,0x430000
    786625d025e1:	mov    QWORD PTR [r12+0x40],r13
    786625d025e6:	mov    r13d,0x0
    786625d025ec:	mov    QWORD PTR [r12+0x58],r13
    786625d025f1:	mov    r13d,0x0
    786625d025f7:	mov    QWORD PTR [r12+0x50],r13
    786625d025fc:	mov    r13d,0x430cb0
    786625d02602:	mov    r14,QWORD PTR [r13+0x0]
    786625d02606:	mov    QWORD PTR [r12+0x48],r14
    786625d0260b:	jmp    0x786625d02610
    786625d02610:	mov    r13,QWORD PTR [r12+0x58]
    786625d02615:	mov    r14,r13
    786625d02618:	shl    r14,0x2
    786625d0261c:	mov    r15,QWORD PTR [r12+0x98]
    786625d02624:	mov    rcx,r14
    786625d02627:	add    r15,rcx
    786625d0262a:	mov    QWORD PTR [r12+0x60],r15
    786625d0262f:	mov    r14,r15
    786625d02632:	add    r14,0x4
    786625d02636:	mov    ebp,DWORD PTR [r15]
    786625d02639:	mov    r15d,DWORD PTR [r14]
    786625d0263c:	mov    QWORD PTR [r12+0x60],r15
    786625d02641:	mov    rax,rbp
    786625d02644:	mov    rcx,r13
    786625d02647:	imul   rax,rcx
    786625d0264b:	mov    r14,rax
    786625d0264e:	mov    rcx,r14
    786625d02651:	mov    r8,rbp
    786625d02654:	add    r8,rcx
    786625d02657:	mov    QWORD PTR [r12+0x68],r8
    786625d0265c:	add    r13,0x2
    786625d02660:	mov    QWORD PTR [r12+0x58],r13
    786625d02665:	mov    r14,r13
    786625d02668:	sub    r14,0x400
    786625d0266f:	mov    r14,QWORD PTR [r12+0x50]
    786625d02674:	pushf
    786625d02675:	pop    r11
    786625d02677:	mov    QWORD PTR [rsp],r11
    786625d0267b:	mov    rax,r13
    786625d0267e:	mov    rcx,r15
    786625d02681:	imul   rax,rcx
    786625d02685:	mov    rbp,rax
    786625d02688:	mov    rcx,rbp
    786625d0268b:	add    r14,rcx
    786625d0268e:	mov    QWORD PTR [r12+0x50],r14
    786625d02693:	mov    r13,QWORD PTR [r12+0x48]
    786625d02698:	mov    rcx,r13
    786625d0269b:	add    r8,rcx
    786625d0269e:	mov    QWORD PTR [r12+0x48],r8
    786625d026a3:	mov    rcx,QWORD PTR [r12+0x380]
    786625d026ab:	jrcxz  0x786625d026b2
    786625d026ad:	jmp    0x786625d02a11
    786625d026b2:	push   QWORD PTR [rsp]
    786625d026b5:	popf
    786625d026b6:	jne    0x786625d02610
    786625d026bc:	jmp    0x786625d026c1
    786625d026c1:	mov    r13d,0x0
    786625d026c7:	mov    QWORD PTR [r12+0x98],r13
    786625d026cf:	mov    r13,QWORD PTR [r12+0x48]
    786625d026d4:	mov    r14,QWORD PTR [r12+0x50]
    786625d026d9:	mov    rcx,r13
    786625d026dc:	add    r14,rcx
    786625d026df:	mov    QWORD PTR [r12+0x48],r14
    786625d026e4:	mov    r13d,0x1
    786625d026ea:	mov    QWORD PTR [r12],r13
    786625d026ee:	mov    r13,QWORD PTR [r12+0x40]
    786625d026f3:	add    r13,0xcb0
    786625d026fa:	mov    QWORD PTR [r13+0x0],r14
    786625d026fe:	mov    r13d,0x0
    786625d02704:	mov    DWORD PTR [r12+0x32c],r13d
    786625d0270c:	mov    r13d,0x1
    786625d02712:	mov    QWORD PTR [r12],r13
    786625d02716:	mov    r13d,0x4103f8
    786625d0271c:	mov    QWORD PTR [r12+0xf0],r13
    786625d02724:	mov    r13d,0x4109a4
    786625d0272a:	mov    QWORD PTR [r12+0x100],r13
    786625d02732:	mov    r11,QWORD PTR [rsp]
    786625d02736:	mov    QWORD PTR [r12+0x398],r11
    786625d0273e:	mov    edi,0x4109a4
    786625d02743:	mov    QWORD PTR [r12+0x100],rdi
    786625d0274b:	add    rsp,0x10
    786625d0274f:	nop
    786625d02750:	jmp    QWORD PTR [rip+0x2]        # 0x786625d02758
    786625d02756:	xchg   ax,ax
    786625d02758:	nop
    786625d02759:	and    eax,edx
    786625d0275b:	and    eax,0x7866
    786625d02760:	push   0x6625d027
    786625d02765:	js     0x786625d02767
    786625d02767:	add    BYTE PTR [rcx-0x45],cl
    786625d0276a:	movabs al,ds:0x4100005c9c39de20
    786625d02773:	jmp    rbx
    786625d02775:	mov    r13d,DWORD PTR [r12+0xa0]
    786625d0277d:	add    r13d,0x11
    786625d02781:	mov    QWORD PTR [r12],r13
    786625d02785:	mov    r13d,0x41035c
    786625d0278b:	mov    QWORD PTR [r12+0xf0],r13
    786625d02793:	mov    r13d,0x4109a4
    786625d02799:	mov    QWORD PTR [r12+0x100],r13
    786625d027a1:	mov    r11,QWORD PTR [rsp]
    786625d027a5:	mov    QWORD PTR [r12+0x398],r11
    786625d027ad:	mov    edi,0x4109a4
    786625d027b2:	mov    QWORD PTR [r12+0x100],rdi
    786625d027ba:	add    rsp,0x10
    786625d027be:	xchg   ax,ax
    786625d027c0:	jmp    QWORD PTR [rip+0x2]        # 0x786625d027c8
    786625d027c6:	xchg   ax,ax
    786625d027c8:	nop
    786625d027c9:	and    eax,edx
    786625d027cb:	and    eax,0x7866
    786625d027d0:	fsub   DWORD PTR [rdi]
    786625d027d2:	shl    BYTE PTR [rip+0x7866],1        # 0x786625d0a03e
    786625d027d8:	movabs r11,0x5c9c39de20a0
    786625d027e2:	jmp    r11
    786625d027e5:	mov    eax,0x410368
    786625d027ea:	mov    QWORD PTR [r12+0x100],rax
    786625d027f2:	push   rdx
    786625d027f3:	push   rsi
    786625d027f4:	push   r10
    786625d027f6:	push   r11
    786625d027f8:	pushf
    786625d027f9:	pop    r11
    786625d027fb:	mov    QWORD PTR [rsp+0x20],r11
    786625d02800:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d02805:	mov    r10d,edx
    786625d02808:	and    r10d,0xc0
    786625d0280f:	shl    r10d,0x18
    786625d02813:	mov    r11d,edx
    786625d02816:	and    r11d,0x1
    786625d0281a:	shl    r11d,0x1d
    786625d0281e:	or     r10d,r11d
    786625d02821:	mov    r11d,edx
    786625d02824:	and    r11d,0x800
    786625d0282b:	shl    r11d,0x11
    786625d0282f:	or     r10d,r11d
    786625d02832:	btc    r10,0x1d
    786625d02837:	mov    r11d,0xf0000000
    786625d0283d:	and    r11,r10
    786625d02840:	movabs rsi,0xffffffff0fffffff
    786625d0284a:	and    rbx,rsi
    786625d0284d:	or     rbx,r11
    786625d02850:	pop    r11
    786625d02852:	pop    r10
    786625d02854:	pop    rsi
    786625d02855:	pop    rdx
    786625d02856:	mov    QWORD PTR [r12+0x108],rbx
    786625d0285e:	add    rsp,0x10
    786625d02862:	mov    eax,0xc
    786625d02867:	movabs r11,0x5c9c39de2390
    786625d02871:	jmp    r11
    786625d02874:	mov    eax,0x41039c
    786625d02879:	mov    QWORD PTR [r12+0x100],rax
    786625d02881:	push   rdx
    786625d02882:	push   rsi
    786625d02883:	push   r10
    786625d02885:	push   r11
    786625d02887:	pushf
    786625d02888:	pop    r11
    786625d0288a:	mov    QWORD PTR [rsp+0x20],r11
    786625d0288f:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d02894:	mov    r10d,edx
    786625d02897:	and    r10d,0xc0
    786625d0289e:	shl    r10d,0x18
    786625d028a2:	mov    r11d,edx
    786625d028a5:	and    r11d,0x1
    786625d028a9:	shl    r11d,0x1d
    786625d028ad:	or     r10d,r11d
    786625d028b0:	mov    r11d,edx
    786625d028b3:	and    r11d,0x800
    786625d028ba:	shl    r11d,0x11
    786625d028be:	or     r10d,r11d
    786625d028c1:	btc    r10,0x1d
    786625d028c6:	mov    r11d,0xf0000000
    786625d028cc:	and    r11,r10
    786625d028cf:	movabs rsi,0xffffffff0fffffff
    786625d028d9:	and    rbx,rsi
    786625d028dc:	or     rbx,r11
    786625d028df:	pop    r11
    786625d028e1:	pop    r10
    786625d028e3:	pop    rsi
    786625d028e4:	pop    rdx
    786625d028e5:	mov    QWORD PTR [r12+0x108],rbx
    786625d028ed:	add    rsp,0x10
    786625d028f1:	mov    eax,0xc
    786625d028f6:	movabs r11,0x5c9c39de2390
    786625d02900:	jmp    r11
    786625d02903:	mov    eax,0x4103a8
    786625d02908:	mov    QWORD PTR [r12+0x100],rax
    786625d02910:	push   rdx
    786625d02911:	push   rsi
    786625d02912:	push   r10
    786625d02914:	push   r11
    786625d02916:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d0291b:	mov    r10d,edx
    786625d0291e:	and    r10d,0xc0
    786625d02925:	shl    r10d,0x18
    786625d02929:	mov    r11d,edx
    786625d0292c:	and    r11d,0x1
    786625d02930:	shl    r11d,0x1d
    786625d02934:	or     r10d,r11d
    786625d02937:	mov    r11d,edx
    786625d0293a:	and    r11d,0x800
    786625d02941:	shl    r11d,0x11
    786625d02945:	or     r10d,r11d
    786625d02948:	btc    r10,0x1d
    786625d0294d:	mov    r11d,0xf0000000
    786625d02953:	and    r11,r10
    786625d02956:	movabs rsi,0xffffffff0fffffff
    786625d02960:	and    rbx,rsi
    786625d02963:	or     rbx,r11
    786625d02966:	pop    r11
    786625d02968:	pop    r10
    786625d0296a:	pop    rsi
    786625d0296b:	pop    rdx
    786625d0296c:	mov    QWORD PTR [r12+0x108],rbx
    786625d02974:	add    rsp,0x10
    786625d02978:	mov    eax,0xc
    786625d0297d:	movabs r11,0x5c9c39de2390
    786625d02987:	jmp    r11
    786625d0298a:	mov    eax,0x4103ac
    786625d0298f:	mov    QWORD PTR [r12+0x100],rax
    786625d02997:	push   rdx
    786625d02998:	push   rsi
    786625d02999:	push   r10
    786625d0299b:	push   r11
    786625d0299d:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d029a2:	mov    r10d,edx
    786625d029a5:	and    r10d,0xc0
    786625d029ac:	shl    r10d,0x18
    786625d029b0:	mov    r11d,edx
    786625d029b3:	and    r11d,0x1
    786625d029b7:	shl    r11d,0x1d
    786625d029bb:	or     r10d,r11d
    786625d029be:	mov    r11d,edx
    786625d029c1:	and    r11d,0x800
    786625d029c8:	shl    r11d,0x11
    786625d029cc:	or     r10d,r11d
    786625d029cf:	btc    r10,0x1d
    786625d029d4:	mov    r11d,0xf0000000
    786625d029da:	and    r11,r10
    786625d029dd:	movabs rsi,0xffffffff0fffffff
    786625d029e7:	and    rbx,rsi
    786625d029ea:	or     rbx,r11
    786625d029ed:	pop    r11
    786625d029ef:	pop    r10
    786625d029f1:	pop    rsi
    786625d029f2:	pop    rdx
    786625d029f3:	mov    QWORD PTR [r12+0x108],rbx
    786625d029fb:	add    rsp,0x10
    786625d029ff:	mov    eax,0xc
    786625d02a04:	movabs r11,0x5c9c39de2390
    786625d02a0e:	jmp    r11
    786625d02a11:	mov    eax,0x4103dc
    786625d02a16:	mov    QWORD PTR [r12+0x100],rax
    786625d02a1e:	push   rdx
    786625d02a1f:	push   rsi
    786625d02a20:	push   r10
    786625d02a22:	push   r11
    786625d02a24:	mov    rdx,QWORD PTR [rsp+0x20]
    786625d02a29:	mov    r10d,edx
    786625d02a2c:	and    r10d,0xc0
    786625d02a33:	shl    r10d,0x18
    786625d02a37:	mov    r11d,edx
    786625d02a3a:	and    r11d,0x1
    786625d02a3e:	shl    r11d,0x1d
    786625d02a42:	or     r10d,r11d
    786625d02a45:	mov    r11d,edx
    786625d02a48:	and    r11d,0x800
    786625d02a4f:	shl    r11d,0x11
    786625d02a53:	or     r10d,r11d
    786625d02a56:	btc    r10,0x1d
    786625d02a5b:	mov    r11d,0xf0000000
    786625d02a61:	and    r11,r10
    786625d02a64:	movabs rsi,0xffffffff0fffffff
    786625d02a6e:	and    rbx,rsi
    786625d02a71:	or     rbx,r11
    786625d02a74:	pop    r11
    786625d02a76:	pop    r10
    786625d02a78:	pop    rsi
    786625d02a79:	pop    rdx
    786625d02a7a:	mov    QWORD PTR [r12+0x108],rbx
    786625d02a82:	add    rsp,0x10
    786625d02a86:	mov    eax,0xc
    786625d02a8b:	movabs r11,0x5c9c39de2390
    786625d02a95:	jmp    r11
    786625d02a98:	nop    DWORD PTR [rax+rax*1+0x0]
    786625d02aa0:	sub    rsp,0x10
    786625d02aa4:	mov    r11,QWORD PTR [r12+0x398]
    786625d02aac:	mov    QWORD PTR [rsp],r11
    786625d02ab0:	jmp    0x786625d02406
    786625d02ab5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02ac0:	sub    rsp,0x10
    786625d02ac4:	mov    r11,QWORD PTR [r12+0x398]
    786625d02acc:	mov    QWORD PTR [rsp],r11
    786625d02ad0:	jmp    0x786625d02416
    786625d02ad5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02ae0:	sub    rsp,0x10
    786625d02ae4:	mov    r11,QWORD PTR [r12+0x398]
    786625d02aec:	mov    QWORD PTR [rsp],r11
    786625d02af0:	jmp    0x786625d0244e
    786625d02af5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02b00:	sub    rsp,0x10
    786625d02b04:	mov    r11,QWORD PTR [r12+0x398]
    786625d02b0c:	mov    QWORD PTR [rsp],r11
    786625d02b10:	jmp    0x786625d024e8
    786625d02b15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02b20:	sub    rsp,0x10
    786625d02b24:	mov    r11,QWORD PTR [r12+0x398]
    786625d02b2c:	mov    QWORD PTR [rsp],r11
    786625d02b30:	jmp    0x786625d0255b
    786625d02b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02b40:	sub    rsp,0x10
    786625d02b44:	mov    r11,QWORD PTR [r12+0x398]
    786625d02b4c:	mov    QWORD PTR [rsp],r11
    786625d02b50:	jmp    0x786625d0256f
    786625d02b55:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02b60:	sub    rsp,0x10
    786625d02b64:	mov    r11,QWORD PTR [r12+0x398]
    786625d02b6c:	mov    QWORD PTR [rsp],r11
    786625d02b70:	jmp    0x786625d0257f
    786625d02b75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02b80:	sub    rsp,0x10
    786625d02b84:	mov    r11,QWORD PTR [r12+0x398]
    786625d02b8c:	mov    QWORD PTR [rsp],r11
    786625d02b90:	jmp    0x786625d025db
    786625d02b95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02ba0:	sub    rsp,0x10
    786625d02ba4:	mov    r11,QWORD PTR [r12+0x398]
    786625d02bac:	mov    QWORD PTR [rsp],r11
    786625d02bb0:	jmp    0x786625d02610
    786625d02bb5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02bc0:	sub    rsp,0x10
    786625d02bc4:	mov    r11,QWORD PTR [r12+0x398]
    786625d02bcc:	mov    QWORD PTR [rsp],r11
    786625d02bd0:	jmp    0x786625d026c1
    786625d02bd5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    786625d02be0:	sub    rsp,0x10
    786625d02be4:	mov    r11,QWORD PTR [r12+0x398]
    786625d02bec:	mov    QWORD PTR [rsp],r11
    786625d02bf0:	jmp    0x786625d02775
    786625d02bf5:	nop
    786625d02bf6:	nop
    786625d02bf7:	nop
