
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/0/4.bin:     file format binary


Disassembly of section .data:

00007c33ec901a50 <.data>:
    7c33ec901a50:	sub    rsp,0x10
    7c33ec901a54:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec901a5c:	mov    QWORD PTR [rsp],r11
    7c33ec901a60:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec901a68:	add    r13,0x168
    7c33ec901a6f:	mov    r14,QWORD PTR [r13+0x0]
    7c33ec901a73:	mov    QWORD PTR [r12+0x40],r14
    7c33ec901a78:	sub    r14,0x38
    7c33ec901a7c:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec901a84:	jrcxz  0x7c33ec901a8b
    7c33ec901a86:	jmp    0x7c33ec901b3d
    7c33ec901a8b:	pushf
    7c33ec901a8c:	pop    r11
    7c33ec901a8e:	mov    QWORD PTR [rsp],r11
    7c33ec901a92:	jne    0x7c33ec901aed
    7c33ec901a98:	jmp    0x7c33ec901a9d
    7c33ec901a9d:	mov    r13d,0x4102d4
    7c33ec901aa3:	mov    QWORD PTR [r12+0x100],r13
    7c33ec901aab:	mov    r11,QWORD PTR [rsp]
    7c33ec901aaf:	mov    QWORD PTR [r12+0x398],r11
    7c33ec901ab7:	mov    edi,0x4102d4
    7c33ec901abc:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec901ac4:	add    rsp,0x10
    7c33ec901ac8:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec901ad0
    7c33ec901ace:	xchg   ax,ax
    7c33ec901ad0:	xor    BYTE PTR [rdx],bl
    7c33ec901ad2:	nop
    7c33ec901ad3:	in     al,dx
    7c33ec901ad4:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec901ad8:	loopne 0x7c33ec901af4
    7c33ec901ada:	nop
    7c33ec901adb:	in     al,dx
    7c33ec901adc:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec901ae0:	movabs r11,0x5585303950a0
    7c33ec901aea:	jmp    r11
    7c33ec901aed:	mov    r13d,0x4102b8
    7c33ec901af3:	mov    QWORD PTR [r12+0x100],r13
    7c33ec901afb:	mov    r11,QWORD PTR [rsp]
    7c33ec901aff:	mov    QWORD PTR [r12+0x398],r11
    7c33ec901b07:	mov    edi,0x4102b8
    7c33ec901b0c:	mov    QWORD PTR [r12+0x100],rdi
    7c33ec901b14:	add    rsp,0x10
    7c33ec901b18:	jmp    QWORD PTR [rip+0x2]        # 0x7c33ec901b20
    7c33ec901b1e:	xchg   ax,ax
    7c33ec901b20:	adc    BYTE PTR [rdx],bl
    7c33ec901b22:	nop
    7c33ec901b23:	in     al,dx
    7c33ec901b24:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec901b28:	xor    BYTE PTR [rbx],bl
    7c33ec901b2a:	nop
    7c33ec901b2b:	in     al,dx
    7c33ec901b2c:	xor    edi,DWORD PTR [rax+rax*1+0x0]
    7c33ec901b30:	movabs r11,0x5585303950a0
    7c33ec901b3a:	jmp    r11
    7c33ec901b3d:	mov    eax,0x4102d0
    7c33ec901b42:	mov    QWORD PTR [r12+0x100],rax
    7c33ec901b4a:	push   rdx
    7c33ec901b4b:	push   rsi
    7c33ec901b4c:	push   r10
    7c33ec901b4e:	push   r11
    7c33ec901b50:	pushf
    7c33ec901b51:	pop    r11
    7c33ec901b53:	mov    QWORD PTR [rsp+0x20],r11
    7c33ec901b58:	mov    rdx,QWORD PTR [rsp+0x20]
    7c33ec901b5d:	mov    r10d,edx
    7c33ec901b60:	and    r10d,0xc0
    7c33ec901b67:	shl    r10d,0x18
    7c33ec901b6b:	mov    r11d,edx
    7c33ec901b6e:	and    r11d,0x1
    7c33ec901b72:	shl    r11d,0x1d
    7c33ec901b76:	or     r10d,r11d
    7c33ec901b79:	mov    r11d,edx
    7c33ec901b7c:	and    r11d,0x800
    7c33ec901b83:	shl    r11d,0x11
    7c33ec901b87:	or     r10d,r11d
    7c33ec901b8a:	btc    r10,0x1d
    7c33ec901b8f:	mov    r11d,0xf0000000
    7c33ec901b95:	and    r11,r10
    7c33ec901b98:	movabs rsi,0xffffffff0fffffff
    7c33ec901ba2:	and    rbx,rsi
    7c33ec901ba5:	or     rbx,r11
    7c33ec901ba8:	pop    r11
    7c33ec901baa:	pop    r10
    7c33ec901bac:	pop    rsi
    7c33ec901bad:	pop    rdx
    7c33ec901bae:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec901bb6:	add    rsp,0x10
    7c33ec901bba:	mov    eax,0xc
    7c33ec901bbf:	movabs r11,0x558530395390
    7c33ec901bc9:	jmp    r11
