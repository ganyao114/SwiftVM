
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute/swiftvm/0/1.bin:     file format binary


Disassembly of section .data:

00007c33ec8fe960 <.data>:
    7c33ec8fe960:	sub    rsp,0x50
    7c33ec8fe964:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec8fe96c:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec8fe971:	mov    r13,QWORD PTR [r12]
    7c33ec8fe975:	mov    r14,r13
    7c33ec8fe978:	add    r14,0x20
    7c33ec8fe97c:	mov    r15,QWORD PTR [r14]
    7c33ec8fe97f:	mov    r14,QWORD PTR [r12+0x10]
    7c33ec8fe984:	mov    rcx,r14
    7c33ec8fe987:	add    r15,rcx
    7c33ec8fe98a:	mov    QWORD PTR [r12+0x40],r15
    7c33ec8fe98f:	add    r13,0x20
    7c33ec8fe993:	mov    QWORD PTR [r13+0x0],r15
    7c33ec8fe997:	mov    r13d,0x0
    7c33ec8fe99d:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fe9a5:	mov    rax,r14
    7c33ec8fe9a8:	test   rax,rax
    7c33ec8fe9ab:	sete   al
    7c33ec8fe9ae:	movzx  eax,al
    7c33ec8fe9b1:	and    eax,0x1
    7c33ec8fe9b4:	mov    r13,rax
    7c33ec8fe9b7:	mov    rax,r13
    7c33ec8fe9ba:	and    eax,0x1
    7c33ec8fe9bd:	test   rax,rax
    7c33ec8fe9c0:	jne    0x7c33ec90113a
    7c33ec8fe9c6:	jmp    0x7c33ec8fe9cb
    7c33ec8fe9cb:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec8fe9d3:	sub    r13,0x150
    7c33ec8fe9da:	mov    QWORD PTR [r12+0xf8],r13
    7c33ec8fe9e2:	mov    r14,QWORD PTR [r12]
    7c33ec8fe9e6:	mov    r15,r14
    7c33ec8fe9e9:	add    r15,0x68
    7c33ec8fe9ed:	mov    rbp,QWORD PTR [r15]
    7c33ec8fe9f0:	mov    QWORD PTR [r12+0x88],rbp
    7c33ec8fe9f8:	add    r14,0x28
    7c33ec8fe9fc:	mov    QWORD PTR [r12+0x40],r14
    7c33ec8fea01:	mov    r14,r13
    7c33ec8fea04:	add    r14,0x0
    7c33ec8fea08:	mov    QWORD PTR [r12+0x48],r14
    7c33ec8fea0d:	mov    r14d,0x420000
    7c33ec8fea13:	add    r14,0xb90
    7c33ec8fea1a:	mov    QWORD PTR [r12+0x50],r14
    7c33ec8fea1f:	add    r13,0x100
    7c33ec8fea26:	mov    r14,r13
    7c33ec8fea29:	add    r14,0x8
    7c33ec8fea2d:	mov    r15,QWORD PTR [r12+0xe8]
    7c33ec8fea35:	mov    rbp,QWORD PTR [r12+0xd8]
    7c33ec8fea3d:	mov    QWORD PTR [r13+0x0],r15
    7c33ec8fea41:	mov    r13d,0x0
    7c33ec8fea47:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fea4f:	mov    QWORD PTR [r14],rbp
    7c33ec8fea52:	mov    r13d,0x0
    7c33ec8fea58:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8fea60:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec8fea68:	mov    r14,r13
    7c33ec8fea6b:	add    r14,0x110
    7c33ec8fea72:	mov    r15,r14
    7c33ec8fea75:	add    r15,0x8
    7c33ec8fea79:	mov    rbp,QWORD PTR [r12+0xd0]
    7c33ec8fea81:	mov    r8,QWORD PTR [r12+0xc8]
    7c33ec8fea89:	mov    QWORD PTR [r14],rbp
    7c33ec8fea8c:	mov    r14d,0x0
    7c33ec8fea92:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8fea9a:	mov    QWORD PTR [r15],r8
    7c33ec8fea9d:	mov    r14d,0x0
    7c33ec8feaa3:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8feaab:	mov    r14,r13
    7c33ec8feaae:	add    r14,0x120
    7c33ec8feab5:	mov    r15,r14
    7c33ec8feab8:	add    r15,0x8
    7c33ec8feabc:	mov    rbp,QWORD PTR [r12+0xc0]
    7c33ec8feac4:	mov    r8,QWORD PTR [r12+0xb8]
    7c33ec8feacc:	mov    QWORD PTR [r14],rbp
    7c33ec8feacf:	mov    r14d,0x0
    7c33ec8fead5:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8feadd:	mov    QWORD PTR [r15],r8
    7c33ec8feae0:	mov    r14d,0x0
    7c33ec8feae6:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8feaee:	mov    r14,r13
    7c33ec8feaf1:	add    r14,0x130
    7c33ec8feaf8:	mov    r15,r14
    7c33ec8feafb:	add    r15,0x8
    7c33ec8feaff:	mov    rbp,QWORD PTR [r12+0xb0]
    7c33ec8feb07:	mov    r8,QWORD PTR [r12+0xa8]
    7c33ec8feb0f:	mov    QWORD PTR [r14],rbp
    7c33ec8feb12:	mov    r14d,0x0
    7c33ec8feb18:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8feb20:	mov    QWORD PTR [r15],r8
    7c33ec8feb23:	mov    r14d,0x0
    7c33ec8feb29:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8feb31:	add    r13,0x140
    7c33ec8feb38:	mov    r14,r13
    7c33ec8feb3b:	add    r14,0x8
    7c33ec8feb3f:	mov    r15,QWORD PTR [r12+0xa0]
    7c33ec8feb47:	mov    rbp,QWORD PTR [r12+0x98]
    7c33ec8feb4f:	mov    QWORD PTR [r13+0x0],r15
    7c33ec8feb53:	mov    r13d,0x0
    7c33ec8feb59:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8feb61:	mov    QWORD PTR [r14],rbp
    7c33ec8feb64:	mov    r13d,0x0
    7c33ec8feb6a:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8feb72:	jmp    0x7c33ec8feb77
    7c33ec8feb77:	mov    r13,QWORD PTR [r12+0x8]
    7c33ec8feb7c:	mov    r14,r13
    7c33ec8feb7f:	add    r14,0x1
    7c33ec8feb83:	movzx  r15d,BYTE PTR [r13+0x0]
    7c33ec8feb88:	mov    QWORD PTR [r12+0x58],r15
    7c33ec8feb8d:	mov    QWORD PTR [r12+0x8],r14
    7c33ec8feb92:	mov    r13,QWORD PTR [r12+0x88]
    7c33ec8feb9a:	mov    r14,r13
    7c33ec8feb9d:	add    r14,0x1
    7c33ec8feba1:	mov    QWORD PTR [r12+0x60],r14
    7c33ec8feba6:	mov    r15,QWORD PTR [r12]
    7c33ec8febaa:	mov    rbp,r15
    7c33ec8febad:	add    rbp,0x68
    7c33ec8febb1:	mov    QWORD PTR [rbp+0x0],r14
    7c33ec8febb5:	mov    r14d,0x0
    7c33ec8febbb:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec8febc3:	mov    rcx,r13
    7c33ec8febc6:	mov    r14,r15
    7c33ec8febc9:	add    r14,rcx
    7c33ec8febcc:	mov    QWORD PTR [r12+0x60],r14
    7c33ec8febd1:	add    r14,0x28
    7c33ec8febd5:	movzx  r13d,BYTE PTR [r12+0x58]
    7c33ec8febdb:	mov    BYTE PTR [r14],r13b
    7c33ec8febde:	mov    r13d,0x0
    7c33ec8febe4:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec8febec:	add    r15,0x68
    7c33ec8febf0:	mov    r13,QWORD PTR [r15]
    7c33ec8febf3:	mov    QWORD PTR [r12+0x88],r13
    7c33ec8febfb:	sub    r13,0x40
    7c33ec8febff:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec8fec07:	jrcxz  0x7c33ec8fec0e
    7c33ec8fec09:	jmp    0x7c33ec90117f
    7c33ec8fec0e:	pushf
    7c33ec8fec0f:	pop    r11
    7c33ec8fec11:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec8fec16:	jne    0x7c33ec901021
    7c33ec8fec1c:	jmp    0x7c33ec8fec21
    7c33ec8fec21:	mov    rax,QWORD PTR [r12+0x40]
    7c33ec8fec26:	mov    QWORD PTR [rsp],rax
    7c33ec8fec2a:	mov    eax,0x0
    7c33ec8fec2f:	mov    QWORD PTR [rsp+0x20],rax
    7c33ec8fec34:	mov    eax,0x0
    7c33ec8fec39:	mov    QWORD PTR [rsp+0x18],rax
    7c33ec8fec3e:	mov    eax,0x0
    7c33ec8fec43:	mov    QWORD PTR [rsp+0x10],rax
    7c33ec8fec48:	mov    eax,0x0
    7c33ec8fec4d:	mov    QWORD PTR [rsp+0x8],rax
    7c33ec8fec52:	mov    rdi,QWORD PTR [rsp]
    7c33ec8fec56:	movzx  r9d,BYTE PTR [rdi]
    7c33ec8fec5a:	mov    r13,r9
    7c33ec8fec5d:	mov    rcx,r13
    7c33ec8fec60:	mov    r9,QWORD PTR [rsp+0x20]
    7c33ec8fec65:	or     r9,rcx
    7c33ec8fec68:	mov    r13,QWORD PTR [rsp]
    7c33ec8fec6c:	add    r13,0x1
    7c33ec8fec70:	movzx  r8d,BYTE PTR [r13+0x0]
    7c33ec8fec75:	mov    r13,r8
    7c33ec8fec78:	mov    rcx,r13
    7c33ec8fec7b:	mov    r8,QWORD PTR [rsp+0x18]
    7c33ec8fec80:	or     r8,rcx
    7c33ec8fec83:	mov    r13,QWORD PTR [rsp]
    7c33ec8fec87:	add    r13,0x2
    7c33ec8fec8b:	movzx  ebp,BYTE PTR [r13+0x0]
    7c33ec8fec90:	mov    r13,rbp
    7c33ec8fec93:	mov    rcx,r13
    7c33ec8fec96:	mov    rbp,QWORD PTR [rsp+0x10]
    7c33ec8fec9b:	or     rbp,rcx
    7c33ec8fec9e:	mov    r13,QWORD PTR [rsp]
    7c33ec8feca2:	add    r13,0x3
    7c33ec8feca6:	movzx  r15d,BYTE PTR [r13+0x0]
    7c33ec8fecab:	mov    r13,r15
    7c33ec8fecae:	mov    rcx,r13
    7c33ec8fecb1:	mov    r15,QWORD PTR [rsp+0x8]
    7c33ec8fecb6:	or     r15,rcx
    7c33ec8fecb9:	mov    r13,QWORD PTR [rsp]
    7c33ec8fecbd:	add    r13,0x4
    7c33ec8fecc1:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fecc6:	mov    r13,r14
    7c33ec8fecc9:	shl    r13,0x8
    7c33ec8feccd:	mov    rcx,r13
    7c33ec8fecd0:	or     r9,rcx
    7c33ec8fecd3:	mov    r13,QWORD PTR [rsp]
    7c33ec8fecd7:	add    r13,0x5
    7c33ec8fecdb:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fece0:	mov    r13,r14
    7c33ec8fece3:	shl    r13,0x8
    7c33ec8fece7:	mov    rcx,r13
    7c33ec8fecea:	or     r8,rcx
    7c33ec8feced:	mov    r13,QWORD PTR [rsp]
    7c33ec8fecf1:	add    r13,0x6
    7c33ec8fecf5:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fecfa:	mov    r13,r14
    7c33ec8fecfd:	shl    r13,0x8
    7c33ec8fed01:	mov    rcx,r13
    7c33ec8fed04:	or     rbp,rcx
    7c33ec8fed07:	mov    r13,QWORD PTR [rsp]
    7c33ec8fed0b:	add    r13,0x7
    7c33ec8fed0f:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fed14:	mov    r13,r14
    7c33ec8fed17:	shl    r13,0x8
    7c33ec8fed1b:	mov    rcx,r13
    7c33ec8fed1e:	or     r15,rcx
    7c33ec8fed21:	mov    r13,QWORD PTR [rsp]
    7c33ec8fed25:	add    r13,0x8
    7c33ec8fed29:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fed2e:	mov    r13,r14
    7c33ec8fed31:	shl    r13,0x10
    7c33ec8fed35:	mov    rcx,r13
    7c33ec8fed38:	or     r9,rcx
    7c33ec8fed3b:	mov    r13,QWORD PTR [rsp]
    7c33ec8fed3f:	add    r13,0x9
    7c33ec8fed43:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fed48:	mov    r13,r14
    7c33ec8fed4b:	shl    r13,0x10
    7c33ec8fed4f:	mov    rcx,r13
    7c33ec8fed52:	or     r8,rcx
    7c33ec8fed55:	mov    r13,QWORD PTR [rsp]
    7c33ec8fed59:	add    r13,0xa
    7c33ec8fed5d:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fed62:	mov    r13,r14
    7c33ec8fed65:	shl    r13,0x10
    7c33ec8fed69:	mov    rcx,r13
    7c33ec8fed6c:	or     rbp,rcx
    7c33ec8fed6f:	mov    r13,QWORD PTR [rsp]
    7c33ec8fed73:	add    r13,0xb
    7c33ec8fed77:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fed7c:	mov    r13,r14
    7c33ec8fed7f:	shl    r13,0x10
    7c33ec8fed83:	mov    rcx,r13
    7c33ec8fed86:	or     r15,rcx
    7c33ec8fed89:	mov    r13,QWORD PTR [rsp]
    7c33ec8fed8d:	add    r13,0xc
    7c33ec8fed91:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fed96:	mov    r13,r14
    7c33ec8fed99:	shl    r13,0x18
    7c33ec8fed9d:	mov    rcx,r13
    7c33ec8feda0:	or     r9,rcx
    7c33ec8feda3:	mov    r13,QWORD PTR [rsp]
    7c33ec8feda7:	add    r13,0xd
    7c33ec8fedab:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fedb0:	mov    r13,r14
    7c33ec8fedb3:	shl    r13,0x18
    7c33ec8fedb7:	mov    rcx,r13
    7c33ec8fedba:	or     r8,rcx
    7c33ec8fedbd:	mov    r13,QWORD PTR [rsp]
    7c33ec8fedc1:	add    r13,0xe
    7c33ec8fedc5:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fedca:	mov    r13,r14
    7c33ec8fedcd:	shl    r13,0x18
    7c33ec8fedd1:	mov    rcx,r13
    7c33ec8fedd4:	or     rbp,rcx
    7c33ec8fedd7:	mov    r13,QWORD PTR [rsp]
    7c33ec8feddb:	add    r13,0xf
    7c33ec8feddf:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fede4:	mov    r13,r14
    7c33ec8fede7:	shl    r13,0x18
    7c33ec8fedeb:	mov    rcx,r13
    7c33ec8fedee:	or     r15,rcx
    7c33ec8fedf1:	mov    r13,QWORD PTR [rsp]
    7c33ec8fedf5:	add    r13,0x10
    7c33ec8fedf9:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fedfe:	mov    r13,r14
    7c33ec8fee01:	shl    r13,0x20
    7c33ec8fee05:	mov    rcx,r13
    7c33ec8fee08:	or     r9,rcx
    7c33ec8fee0b:	mov    r13,QWORD PTR [rsp]
    7c33ec8fee0f:	add    r13,0x11
    7c33ec8fee13:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fee18:	mov    r13,r14
    7c33ec8fee1b:	shl    r13,0x20
    7c33ec8fee1f:	mov    rcx,r13
    7c33ec8fee22:	or     r8,rcx
    7c33ec8fee25:	mov    r13,QWORD PTR [rsp]
    7c33ec8fee29:	add    r13,0x12
    7c33ec8fee2d:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fee32:	mov    r13,r14
    7c33ec8fee35:	shl    r13,0x20
    7c33ec8fee39:	mov    rcx,r13
    7c33ec8fee3c:	or     rbp,rcx
    7c33ec8fee3f:	mov    r13,QWORD PTR [rsp]
    7c33ec8fee43:	add    r13,0x13
    7c33ec8fee47:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fee4c:	mov    r13,r14
    7c33ec8fee4f:	shl    r13,0x20
    7c33ec8fee53:	mov    rcx,r13
    7c33ec8fee56:	or     r15,rcx
    7c33ec8fee59:	mov    r13,QWORD PTR [rsp]
    7c33ec8fee5d:	add    r13,0x14
    7c33ec8fee61:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fee66:	mov    r13,r14
    7c33ec8fee69:	shl    r13,0x28
    7c33ec8fee6d:	mov    rcx,r13
    7c33ec8fee70:	or     r9,rcx
    7c33ec8fee73:	mov    r13,QWORD PTR [rsp]
    7c33ec8fee77:	add    r13,0x15
    7c33ec8fee7b:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fee80:	mov    r13,r14
    7c33ec8fee83:	shl    r13,0x28
    7c33ec8fee87:	mov    rcx,r13
    7c33ec8fee8a:	or     r8,rcx
    7c33ec8fee8d:	mov    r13,QWORD PTR [rsp]
    7c33ec8fee91:	add    r13,0x16
    7c33ec8fee95:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fee9a:	mov    r13,r14
    7c33ec8fee9d:	shl    r13,0x28
    7c33ec8feea1:	mov    rcx,r13
    7c33ec8feea4:	or     rbp,rcx
    7c33ec8feea7:	mov    r13,QWORD PTR [rsp]
    7c33ec8feeab:	add    r13,0x17
    7c33ec8feeaf:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8feeb4:	mov    r13,r14
    7c33ec8feeb7:	shl    r13,0x28
    7c33ec8feebb:	mov    rcx,r13
    7c33ec8feebe:	or     r15,rcx
    7c33ec8feec1:	mov    r13,QWORD PTR [rsp]
    7c33ec8feec5:	add    r13,0x18
    7c33ec8feec9:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8feece:	mov    r13,r14
    7c33ec8feed1:	shl    r13,0x30
    7c33ec8feed5:	mov    rcx,r13
    7c33ec8feed8:	or     r9,rcx
    7c33ec8feedb:	mov    r13,QWORD PTR [rsp]
    7c33ec8feedf:	add    r13,0x19
    7c33ec8feee3:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8feee8:	mov    r13,r14
    7c33ec8feeeb:	shl    r13,0x30
    7c33ec8feeef:	mov    rcx,r13
    7c33ec8feef2:	or     r8,rcx
    7c33ec8feef5:	mov    r13,QWORD PTR [rsp]
    7c33ec8feef9:	add    r13,0x1a
    7c33ec8feefd:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fef02:	mov    r13,r14
    7c33ec8fef05:	shl    r13,0x30
    7c33ec8fef09:	mov    rcx,r13
    7c33ec8fef0c:	or     rbp,rcx
    7c33ec8fef0f:	mov    r13,QWORD PTR [rsp]
    7c33ec8fef13:	add    r13,0x1b
    7c33ec8fef17:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fef1c:	mov    r13,r14
    7c33ec8fef1f:	shl    r13,0x30
    7c33ec8fef23:	mov    rcx,r13
    7c33ec8fef26:	or     r15,rcx
    7c33ec8fef29:	mov    r13,QWORD PTR [rsp]
    7c33ec8fef2d:	add    r13,0x1c
    7c33ec8fef31:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fef36:	mov    r13,r14
    7c33ec8fef39:	shl    r13,0x38
    7c33ec8fef3d:	mov    rcx,r13
    7c33ec8fef40:	mov    rax,r9
    7c33ec8fef43:	or     rax,rcx
    7c33ec8fef46:	mov    QWORD PTR [rsp+0x40],rax
    7c33ec8fef4b:	mov    r13,QWORD PTR [rsp]
    7c33ec8fef4f:	add    r13,0x1d
    7c33ec8fef53:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fef58:	mov    r13,r14
    7c33ec8fef5b:	shl    r13,0x38
    7c33ec8fef5f:	mov    rcx,r13
    7c33ec8fef62:	mov    rax,r8
    7c33ec8fef65:	or     rax,rcx
    7c33ec8fef68:	mov    QWORD PTR [rsp+0x30],rax
    7c33ec8fef6d:	mov    r13,QWORD PTR [rsp]
    7c33ec8fef71:	add    r13,0x1e
    7c33ec8fef75:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fef7a:	mov    r13,r14
    7c33ec8fef7d:	shl    r13,0x38
    7c33ec8fef81:	mov    rcx,r13
    7c33ec8fef84:	mov    rax,rbp
    7c33ec8fef87:	or     rax,rcx
    7c33ec8fef8a:	mov    QWORD PTR [rsp+0x28],rax
    7c33ec8fef8f:	mov    r13,QWORD PTR [rsp]
    7c33ec8fef93:	add    r13,0x1f
    7c33ec8fef97:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fef9c:	mov    r13,r14
    7c33ec8fef9f:	shl    r13,0x38
    7c33ec8fefa3:	mov    rcx,r13
    7c33ec8fefa6:	mov    rax,r15
    7c33ec8fefa9:	or     rax,rcx
    7c33ec8fefac:	mov    QWORD PTR [rsp+0x38],rax
    7c33ec8fefb1:	mov    r13,QWORD PTR [rsp]
    7c33ec8fefb5:	add    r13,0x20
    7c33ec8fefb9:	movzx  r14d,BYTE PTR [r13+0x0]
    7c33ec8fefbe:	mov    r13,r14
    7c33ec8fefc1:	mov    rcx,r13
    7c33ec8fefc4:	mov    r14,QWORD PTR [rsp+0x20]
    7c33ec8fefc9:	or     r14,rcx
    7c33ec8fefcc:	mov    r13,QWORD PTR [rsp]
    7c33ec8fefd0:	add    r13,0x21
    7c33ec8fefd4:	movzx  ebp,BYTE PTR [r13+0x0]
    7c33ec8fefd9:	mov    r13,rbp
    7c33ec8fefdc:	mov    rcx,r13
    7c33ec8fefdf:	mov    rbp,QWORD PTR [rsp+0x18]
    7c33ec8fefe4:	or     rbp,rcx
    7c33ec8fefe7:	mov    r13,QWORD PTR [rsp]
    7c33ec8fefeb:	add    r13,0x22
    7c33ec8fefef:	movzx  r8d,BYTE PTR [r13+0x0]
    7c33ec8feff4:	mov    r13,r8
    7c33ec8feff7:	mov    rcx,r13
    7c33ec8feffa:	mov    r8,QWORD PTR [rsp+0x10]
    7c33ec8fefff:	or     r8,rcx
    7c33ec8ff002:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff006:	add    r13,0x23
    7c33ec8ff00a:	movzx  r15d,BYTE PTR [r13+0x0]
    7c33ec8ff00f:	mov    r13,r15
    7c33ec8ff012:	mov    rcx,r13
    7c33ec8ff015:	mov    r15,QWORD PTR [rsp+0x8]
    7c33ec8ff01a:	or     r15,rcx
    7c33ec8ff01d:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff021:	add    r13,0x24
    7c33ec8ff025:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff02a:	mov    r13,r9
    7c33ec8ff02d:	shl    r13,0x8
    7c33ec8ff031:	mov    rcx,r13
    7c33ec8ff034:	or     r14,rcx
    7c33ec8ff037:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff03b:	add    r13,0x25
    7c33ec8ff03f:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff044:	mov    r13,r9
    7c33ec8ff047:	shl    r13,0x8
    7c33ec8ff04b:	mov    rcx,r13
    7c33ec8ff04e:	or     rbp,rcx
    7c33ec8ff051:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff055:	add    r13,0x26
    7c33ec8ff059:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff05e:	mov    r13,r9
    7c33ec8ff061:	shl    r13,0x8
    7c33ec8ff065:	mov    rcx,r13
    7c33ec8ff068:	or     r8,rcx
    7c33ec8ff06b:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff06f:	add    r13,0x27
    7c33ec8ff073:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff078:	mov    r13,r9
    7c33ec8ff07b:	shl    r13,0x8
    7c33ec8ff07f:	mov    rcx,r13
    7c33ec8ff082:	or     r15,rcx
    7c33ec8ff085:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff089:	add    r13,0x28
    7c33ec8ff08d:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff092:	mov    r13,r9
    7c33ec8ff095:	shl    r13,0x10
    7c33ec8ff099:	mov    rcx,r13
    7c33ec8ff09c:	or     r14,rcx
    7c33ec8ff09f:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff0a3:	add    r13,0x29
    7c33ec8ff0a7:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff0ac:	mov    r13,r9
    7c33ec8ff0af:	shl    r13,0x10
    7c33ec8ff0b3:	mov    rcx,r13
    7c33ec8ff0b6:	or     rbp,rcx
    7c33ec8ff0b9:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff0bd:	add    r13,0x2a
    7c33ec8ff0c1:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff0c6:	mov    r13,r9
    7c33ec8ff0c9:	shl    r13,0x10
    7c33ec8ff0cd:	mov    rcx,r13
    7c33ec8ff0d0:	or     r8,rcx
    7c33ec8ff0d3:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff0d7:	add    r13,0x2b
    7c33ec8ff0db:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff0e0:	mov    r13,r9
    7c33ec8ff0e3:	shl    r13,0x10
    7c33ec8ff0e7:	mov    rcx,r13
    7c33ec8ff0ea:	or     r15,rcx
    7c33ec8ff0ed:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff0f1:	add    r13,0x2c
    7c33ec8ff0f5:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff0fa:	mov    r13,r9
    7c33ec8ff0fd:	shl    r13,0x18
    7c33ec8ff101:	mov    rcx,r13
    7c33ec8ff104:	or     r14,rcx
    7c33ec8ff107:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff10b:	add    r13,0x2d
    7c33ec8ff10f:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff114:	mov    r13,r9
    7c33ec8ff117:	shl    r13,0x18
    7c33ec8ff11b:	mov    rcx,r13
    7c33ec8ff11e:	or     rbp,rcx
    7c33ec8ff121:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff125:	add    r13,0x2e
    7c33ec8ff129:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff12e:	mov    r13,r9
    7c33ec8ff131:	shl    r13,0x18
    7c33ec8ff135:	mov    rcx,r13
    7c33ec8ff138:	or     r8,rcx
    7c33ec8ff13b:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff13f:	add    r13,0x2f
    7c33ec8ff143:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff148:	mov    r13,r9
    7c33ec8ff14b:	shl    r13,0x18
    7c33ec8ff14f:	mov    rcx,r13
    7c33ec8ff152:	or     r15,rcx
    7c33ec8ff155:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff159:	add    r13,0x30
    7c33ec8ff15d:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff162:	mov    r13,r9
    7c33ec8ff165:	shl    r13,0x20
    7c33ec8ff169:	mov    rcx,r13
    7c33ec8ff16c:	or     r14,rcx
    7c33ec8ff16f:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff173:	add    r13,0x31
    7c33ec8ff177:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff17c:	mov    r13,r9
    7c33ec8ff17f:	shl    r13,0x20
    7c33ec8ff183:	mov    rcx,r13
    7c33ec8ff186:	or     rbp,rcx
    7c33ec8ff189:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff18d:	add    r13,0x32
    7c33ec8ff191:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff196:	mov    r13,r9
    7c33ec8ff199:	shl    r13,0x20
    7c33ec8ff19d:	mov    rcx,r13
    7c33ec8ff1a0:	or     r8,rcx
    7c33ec8ff1a3:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff1a7:	add    r13,0x33
    7c33ec8ff1ab:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff1b0:	mov    r13,r9
    7c33ec8ff1b3:	shl    r13,0x20
    7c33ec8ff1b7:	mov    rcx,r13
    7c33ec8ff1ba:	or     r15,rcx
    7c33ec8ff1bd:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff1c1:	add    r13,0x34
    7c33ec8ff1c5:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff1ca:	mov    r13,r9
    7c33ec8ff1cd:	shl    r13,0x28
    7c33ec8ff1d1:	mov    rcx,r13
    7c33ec8ff1d4:	or     r14,rcx
    7c33ec8ff1d7:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff1db:	add    r13,0x35
    7c33ec8ff1df:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff1e4:	mov    r13,r9
    7c33ec8ff1e7:	shl    r13,0x28
    7c33ec8ff1eb:	mov    rcx,r13
    7c33ec8ff1ee:	or     rbp,rcx
    7c33ec8ff1f1:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff1f5:	add    r13,0x36
    7c33ec8ff1f9:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff1fe:	mov    r13,r9
    7c33ec8ff201:	shl    r13,0x28
    7c33ec8ff205:	mov    rcx,r13
    7c33ec8ff208:	or     r8,rcx
    7c33ec8ff20b:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff20f:	add    r13,0x37
    7c33ec8ff213:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff218:	mov    r13,r9
    7c33ec8ff21b:	shl    r13,0x28
    7c33ec8ff21f:	mov    rcx,r13
    7c33ec8ff222:	or     r15,rcx
    7c33ec8ff225:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff229:	add    r13,0x38
    7c33ec8ff22d:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff232:	mov    r13,r9
    7c33ec8ff235:	shl    r13,0x30
    7c33ec8ff239:	mov    rcx,r13
    7c33ec8ff23c:	or     r14,rcx
    7c33ec8ff23f:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff243:	add    r13,0x39
    7c33ec8ff247:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff24c:	mov    r13,r9
    7c33ec8ff24f:	shl    r13,0x30
    7c33ec8ff253:	mov    rcx,r13
    7c33ec8ff256:	or     rbp,rcx
    7c33ec8ff259:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff25d:	add    r13,0x3a
    7c33ec8ff261:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff266:	mov    r13,r9
    7c33ec8ff269:	shl    r13,0x30
    7c33ec8ff26d:	mov    rcx,r13
    7c33ec8ff270:	or     r8,rcx
    7c33ec8ff273:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff277:	add    r13,0x3b
    7c33ec8ff27b:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff280:	mov    r13,r9
    7c33ec8ff283:	shl    r13,0x30
    7c33ec8ff287:	mov    rcx,r13
    7c33ec8ff28a:	or     r15,rcx
    7c33ec8ff28d:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff291:	add    r13,0x3c
    7c33ec8ff295:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff29a:	mov    r13,r9
    7c33ec8ff29d:	shl    r13,0x38
    7c33ec8ff2a1:	mov    rcx,r13
    7c33ec8ff2a4:	or     r14,rcx
    7c33ec8ff2a7:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff2ab:	add    r13,0x3d
    7c33ec8ff2af:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff2b4:	mov    r13,r9
    7c33ec8ff2b7:	shl    r13,0x38
    7c33ec8ff2bb:	mov    rcx,r13
    7c33ec8ff2be:	or     rbp,rcx
    7c33ec8ff2c1:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff2c5:	add    r13,0x3e
    7c33ec8ff2c9:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff2ce:	mov    r13,r9
    7c33ec8ff2d1:	shl    r13,0x38
    7c33ec8ff2d5:	mov    rcx,r13
    7c33ec8ff2d8:	or     r8,rcx
    7c33ec8ff2db:	mov    r13,QWORD PTR [rsp]
    7c33ec8ff2df:	add    r13,0x3f
    7c33ec8ff2e3:	movzx  r9d,BYTE PTR [r13+0x0]
    7c33ec8ff2e8:	mov    r13,r9
    7c33ec8ff2eb:	shl    r13,0x38
    7c33ec8ff2ef:	mov    rcx,r13
    7c33ec8ff2f2:	or     r15,rcx
    7c33ec8ff2f5:	mov    rax,QWORD PTR [rsp+0x40]
    7c33ec8ff2fa:	mov    QWORD PTR [r12+0x110],rax
    7c33ec8ff302:	mov    QWORD PTR [r12+0x118],r14
    7c33ec8ff30a:	mov    rax,QWORD PTR [rsp+0x30]
    7c33ec8ff30f:	mov    QWORD PTR [r12+0x120],rax
    7c33ec8ff317:	mov    QWORD PTR [r12+0x128],rbp
    7c33ec8ff31f:	mov    rax,QWORD PTR [rsp+0x28]
    7c33ec8ff324:	mov    QWORD PTR [r12+0x130],rax
    7c33ec8ff32c:	mov    QWORD PTR [r12+0x138],r8
    7c33ec8ff334:	mov    rax,QWORD PTR [rsp+0x38]
    7c33ec8ff339:	mov    QWORD PTR [r12+0x140],rax
    7c33ec8ff341:	mov    QWORD PTR [r12+0x148],r15
    7c33ec8ff349:	mov    r13d,0x0
    7c33ec8ff34f:	mov    QWORD PTR [r12+0x58],r13
    7c33ec8ff354:	mov    r13d,0x0
    7c33ec8ff35a:	mov    r14,QWORD PTR [rsp+0x30]
    7c33ec8ff35f:	and    r14,0xff
    7c33ec8ff366:	and    r14,0xffff
    7c33ec8ff36d:	mov    rcx,r14
    7c33ec8ff370:	mov    r15,r13
    7c33ec8ff373:	or     r15,rcx
    7c33ec8ff376:	mov    r14,QWORD PTR [rsp+0x30]
    7c33ec8ff37b:	shr    r14,0x8
    7c33ec8ff37f:	and    r14,0xff
    7c33ec8ff386:	and    r14,0xffff
    7c33ec8ff38d:	shl    r14,0x10
    7c33ec8ff391:	mov    rcx,r14
    7c33ec8ff394:	or     r15,rcx
    7c33ec8ff397:	mov    r14,QWORD PTR [rsp+0x30]
    7c33ec8ff39c:	shr    r14,0x10
    7c33ec8ff3a0:	and    r14,0xff
    7c33ec8ff3a7:	and    r14,0xffff
    7c33ec8ff3ae:	shl    r14,0x20
    7c33ec8ff3b2:	mov    rcx,r14
    7c33ec8ff3b5:	or     r15,rcx
    7c33ec8ff3b8:	mov    r14,QWORD PTR [rsp+0x30]
    7c33ec8ff3bd:	shr    r14,0x18
    7c33ec8ff3c1:	and    r14,0xff
    7c33ec8ff3c8:	and    r14,0xffff
    7c33ec8ff3cf:	shl    r14,0x30
    7c33ec8ff3d3:	mov    rcx,r14
    7c33ec8ff3d6:	or     r15,rcx
    7c33ec8ff3d9:	mov    r14,QWORD PTR [rsp+0x30]
    7c33ec8ff3de:	shr    r14,0x20
    7c33ec8ff3e2:	and    r14,0xff
    7c33ec8ff3e9:	and    r14,0xffff
    7c33ec8ff3f0:	mov    rcx,r14
    7c33ec8ff3f3:	or     r13,rcx
    7c33ec8ff3f6:	mov    r14,QWORD PTR [rsp+0x30]
    7c33ec8ff3fb:	shr    r14,0x28
    7c33ec8ff3ff:	and    r14,0xff
    7c33ec8ff406:	and    r14,0xffff
    7c33ec8ff40d:	shl    r14,0x10
    7c33ec8ff411:	mov    rcx,r14
    7c33ec8ff414:	or     r13,rcx
    7c33ec8ff417:	mov    r14,QWORD PTR [rsp+0x30]
    7c33ec8ff41c:	shr    r14,0x30
    7c33ec8ff420:	and    r14,0xff
    7c33ec8ff427:	and    r14,0xffff
    7c33ec8ff42e:	shl    r14,0x20
    7c33ec8ff432:	mov    rcx,r14
    7c33ec8ff435:	or     r13,rcx
    7c33ec8ff438:	mov    r14,QWORD PTR [rsp+0x30]
    7c33ec8ff43d:	shr    r14,0x38
    7c33ec8ff441:	and    r14,0xff
    7c33ec8ff448:	and    r14,0xffff
    7c33ec8ff44f:	shl    r14,0x30
    7c33ec8ff453:	mov    rcx,r14
    7c33ec8ff456:	or     r13,rcx
    7c33ec8ff459:	mov    QWORD PTR [r12+0x150],r15
    7c33ec8ff461:	mov    QWORD PTR [r12+0x158],r13
    7c33ec8ff469:	mov    r13d,0x0
    7c33ec8ff46f:	mov    r14,QWORD PTR [rsp+0x28]
    7c33ec8ff474:	and    r14,0xff
    7c33ec8ff47b:	and    r14,0xffff
    7c33ec8ff482:	mov    rcx,r14
    7c33ec8ff485:	mov    r15,r13
    7c33ec8ff488:	or     r15,rcx
    7c33ec8ff48b:	mov    r14,QWORD PTR [rsp+0x28]
    7c33ec8ff490:	shr    r14,0x8
    7c33ec8ff494:	and    r14,0xff
    7c33ec8ff49b:	and    r14,0xffff
    7c33ec8ff4a2:	shl    r14,0x10
    7c33ec8ff4a6:	mov    rcx,r14
    7c33ec8ff4a9:	or     r15,rcx
    7c33ec8ff4ac:	mov    r14,QWORD PTR [rsp+0x28]
    7c33ec8ff4b1:	shr    r14,0x10
    7c33ec8ff4b5:	and    r14,0xff
    7c33ec8ff4bc:	and    r14,0xffff
    7c33ec8ff4c3:	shl    r14,0x20
    7c33ec8ff4c7:	mov    rcx,r14
    7c33ec8ff4ca:	or     r15,rcx
    7c33ec8ff4cd:	mov    r14,QWORD PTR [rsp+0x28]
    7c33ec8ff4d2:	shr    r14,0x18
    7c33ec8ff4d6:	and    r14,0xff
    7c33ec8ff4dd:	and    r14,0xffff
    7c33ec8ff4e4:	shl    r14,0x30
    7c33ec8ff4e8:	mov    rcx,r14
    7c33ec8ff4eb:	or     r15,rcx
    7c33ec8ff4ee:	mov    r14,QWORD PTR [rsp+0x28]
    7c33ec8ff4f3:	shr    r14,0x20
    7c33ec8ff4f7:	and    r14,0xff
    7c33ec8ff4fe:	and    r14,0xffff
    7c33ec8ff505:	mov    rcx,r14
    7c33ec8ff508:	or     r13,rcx
    7c33ec8ff50b:	mov    r14,QWORD PTR [rsp+0x28]
    7c33ec8ff510:	shr    r14,0x28
    7c33ec8ff514:	and    r14,0xff
    7c33ec8ff51b:	and    r14,0xffff
    7c33ec8ff522:	shl    r14,0x10
    7c33ec8ff526:	mov    rcx,r14
    7c33ec8ff529:	or     r13,rcx
    7c33ec8ff52c:	mov    r14,QWORD PTR [rsp+0x28]
    7c33ec8ff531:	shr    r14,0x30
    7c33ec8ff535:	and    r14,0xff
    7c33ec8ff53c:	and    r14,0xffff
    7c33ec8ff543:	shl    r14,0x20
    7c33ec8ff547:	mov    rcx,r14
    7c33ec8ff54a:	or     r13,rcx
    7c33ec8ff54d:	mov    r14,QWORD PTR [rsp+0x28]
    7c33ec8ff552:	shr    r14,0x38
    7c33ec8ff556:	and    r14,0xff
    7c33ec8ff55d:	and    r14,0xffff
    7c33ec8ff564:	shl    r14,0x30
    7c33ec8ff568:	mov    rcx,r14
    7c33ec8ff56b:	or     r13,rcx
    7c33ec8ff56e:	mov    QWORD PTR [r12+0x160],r15
    7c33ec8ff576:	mov    QWORD PTR [r12+0x168],r13
    7c33ec8ff57e:	mov    r13,QWORD PTR [r12+0x110]
    7c33ec8ff586:	mov    r14d,0x0
    7c33ec8ff58c:	mov    r15,r13
    7c33ec8ff58f:	and    r15,0xff
    7c33ec8ff596:	and    r15,0xffff
    7c33ec8ff59d:	mov    rcx,r15
    7c33ec8ff5a0:	mov    rbp,r14
    7c33ec8ff5a3:	or     rbp,rcx
    7c33ec8ff5a6:	mov    r15,r13
    7c33ec8ff5a9:	shr    r15,0x8
    7c33ec8ff5ad:	and    r15,0xff
    7c33ec8ff5b4:	and    r15,0xffff
    7c33ec8ff5bb:	shl    r15,0x10
    7c33ec8ff5bf:	mov    rcx,r15
    7c33ec8ff5c2:	or     rbp,rcx
    7c33ec8ff5c5:	mov    r15,r13
    7c33ec8ff5c8:	shr    r15,0x10
    7c33ec8ff5cc:	and    r15,0xff
    7c33ec8ff5d3:	and    r15,0xffff
    7c33ec8ff5da:	shl    r15,0x20
    7c33ec8ff5de:	mov    rcx,r15
    7c33ec8ff5e1:	or     rbp,rcx
    7c33ec8ff5e4:	mov    r15,r13
    7c33ec8ff5e7:	shr    r15,0x18
    7c33ec8ff5eb:	and    r15,0xff
    7c33ec8ff5f2:	and    r15,0xffff
    7c33ec8ff5f9:	shl    r15,0x30
    7c33ec8ff5fd:	mov    rcx,r15
    7c33ec8ff600:	or     rbp,rcx
    7c33ec8ff603:	mov    r15,r13
    7c33ec8ff606:	shr    r15,0x20
    7c33ec8ff60a:	and    r15,0xff
    7c33ec8ff611:	and    r15,0xffff
    7c33ec8ff618:	mov    rcx,r15
    7c33ec8ff61b:	or     r14,rcx
    7c33ec8ff61e:	mov    r15,r13
    7c33ec8ff621:	shr    r15,0x28
    7c33ec8ff625:	and    r15,0xff
    7c33ec8ff62c:	and    r15,0xffff
    7c33ec8ff633:	shl    r15,0x10
    7c33ec8ff637:	mov    rcx,r15
    7c33ec8ff63a:	or     r14,rcx
    7c33ec8ff63d:	mov    r15,r13
    7c33ec8ff640:	shr    r15,0x30
    7c33ec8ff644:	and    r15,0xff
    7c33ec8ff64b:	and    r15,0xffff
    7c33ec8ff652:	shl    r15,0x20
    7c33ec8ff656:	mov    rcx,r15
    7c33ec8ff659:	or     r14,rcx
    7c33ec8ff65c:	shr    r13,0x38
    7c33ec8ff660:	and    r13,0xff
    7c33ec8ff667:	and    r13,0xffff
    7c33ec8ff66e:	shl    r13,0x30
    7c33ec8ff672:	mov    rcx,r13
    7c33ec8ff675:	or     r14,rcx
    7c33ec8ff678:	mov    QWORD PTR [r12+0x170],rbp
    7c33ec8ff680:	mov    QWORD PTR [r12+0x178],r14
    7c33ec8ff688:	mov    r13,QWORD PTR [r12+0x118]
    7c33ec8ff690:	mov    r14d,0x0
    7c33ec8ff696:	mov    r15,r13
    7c33ec8ff699:	and    r15,0xff
    7c33ec8ff6a0:	and    r15,0xffff
    7c33ec8ff6a7:	mov    rcx,r15
    7c33ec8ff6aa:	mov    rbp,r14
    7c33ec8ff6ad:	or     rbp,rcx
    7c33ec8ff6b0:	mov    r15,r13
    7c33ec8ff6b3:	shr    r15,0x8
    7c33ec8ff6b7:	and    r15,0xff
    7c33ec8ff6be:	and    r15,0xffff
    7c33ec8ff6c5:	shl    r15,0x10
    7c33ec8ff6c9:	mov    rcx,r15
    7c33ec8ff6cc:	or     rbp,rcx
    7c33ec8ff6cf:	mov    r15,r13
    7c33ec8ff6d2:	shr    r15,0x10
    7c33ec8ff6d6:	and    r15,0xff
    7c33ec8ff6dd:	and    r15,0xffff
    7c33ec8ff6e4:	shl    r15,0x20
    7c33ec8ff6e8:	mov    rcx,r15
    7c33ec8ff6eb:	or     rbp,rcx
    7c33ec8ff6ee:	mov    r15,r13
    7c33ec8ff6f1:	shr    r15,0x18
    7c33ec8ff6f5:	and    r15,0xff
    7c33ec8ff6fc:	and    r15,0xffff
    7c33ec8ff703:	shl    r15,0x30
    7c33ec8ff707:	mov    rcx,r15
    7c33ec8ff70a:	or     rbp,rcx
    7c33ec8ff70d:	mov    r15,r13
    7c33ec8ff710:	shr    r15,0x20
    7c33ec8ff714:	and    r15,0xff
    7c33ec8ff71b:	and    r15,0xffff
    7c33ec8ff722:	mov    rcx,r15
    7c33ec8ff725:	or     r14,rcx
    7c33ec8ff728:	mov    r15,r13
    7c33ec8ff72b:	shr    r15,0x28
    7c33ec8ff72f:	and    r15,0xff
    7c33ec8ff736:	and    r15,0xffff
    7c33ec8ff73d:	shl    r15,0x10
    7c33ec8ff741:	mov    rcx,r15
    7c33ec8ff744:	or     r14,rcx
    7c33ec8ff747:	mov    r15,r13
    7c33ec8ff74a:	shr    r15,0x30
    7c33ec8ff74e:	and    r15,0xff
    7c33ec8ff755:	and    r15,0xffff
    7c33ec8ff75c:	shl    r15,0x20
    7c33ec8ff760:	mov    rcx,r15
    7c33ec8ff763:	or     r14,rcx
    7c33ec8ff766:	shr    r13,0x38
    7c33ec8ff76a:	and    r13,0xff
    7c33ec8ff771:	and    r13,0xffff
    7c33ec8ff778:	shl    r13,0x30
    7c33ec8ff77c:	mov    rcx,r13
    7c33ec8ff77f:	or     r14,rcx
    7c33ec8ff782:	mov    QWORD PTR [r12+0x180],rbp
    7c33ec8ff78a:	mov    QWORD PTR [r12+0x188],r14
    7c33ec8ff792:	mov    r13,QWORD PTR [r12+0x128]
    7c33ec8ff79a:	mov    r14d,0x0
    7c33ec8ff7a0:	mov    r15,r13
    7c33ec8ff7a3:	and    r15,0xff
    7c33ec8ff7aa:	and    r15,0xffff
    7c33ec8ff7b1:	mov    rcx,r15
    7c33ec8ff7b4:	mov    rbp,r14
    7c33ec8ff7b7:	or     rbp,rcx
    7c33ec8ff7ba:	mov    r15,r13
    7c33ec8ff7bd:	shr    r15,0x8
    7c33ec8ff7c1:	and    r15,0xff
    7c33ec8ff7c8:	and    r15,0xffff
    7c33ec8ff7cf:	shl    r15,0x10
    7c33ec8ff7d3:	mov    rcx,r15
    7c33ec8ff7d6:	or     rbp,rcx
    7c33ec8ff7d9:	mov    r15,r13
    7c33ec8ff7dc:	shr    r15,0x10
    7c33ec8ff7e0:	and    r15,0xff
    7c33ec8ff7e7:	and    r15,0xffff
    7c33ec8ff7ee:	shl    r15,0x20
    7c33ec8ff7f2:	mov    rcx,r15
    7c33ec8ff7f5:	or     rbp,rcx
    7c33ec8ff7f8:	mov    r15,r13
    7c33ec8ff7fb:	shr    r15,0x18
    7c33ec8ff7ff:	and    r15,0xff
    7c33ec8ff806:	and    r15,0xffff
    7c33ec8ff80d:	shl    r15,0x30
    7c33ec8ff811:	mov    rcx,r15
    7c33ec8ff814:	or     rbp,rcx
    7c33ec8ff817:	mov    r15,r13
    7c33ec8ff81a:	shr    r15,0x20
    7c33ec8ff81e:	and    r15,0xff
    7c33ec8ff825:	and    r15,0xffff
    7c33ec8ff82c:	mov    rcx,r15
    7c33ec8ff82f:	or     r14,rcx
    7c33ec8ff832:	mov    r15,r13
    7c33ec8ff835:	shr    r15,0x28
    7c33ec8ff839:	and    r15,0xff
    7c33ec8ff840:	and    r15,0xffff
    7c33ec8ff847:	shl    r15,0x10
    7c33ec8ff84b:	mov    rcx,r15
    7c33ec8ff84e:	or     r14,rcx
    7c33ec8ff851:	mov    r15,r13
    7c33ec8ff854:	shr    r15,0x30
    7c33ec8ff858:	and    r15,0xff
    7c33ec8ff85f:	and    r15,0xffff
    7c33ec8ff866:	shl    r15,0x20
    7c33ec8ff86a:	mov    rcx,r15
    7c33ec8ff86d:	or     r14,rcx
    7c33ec8ff870:	shr    r13,0x38
    7c33ec8ff874:	and    r13,0xff
    7c33ec8ff87b:	and    r13,0xffff
    7c33ec8ff882:	shl    r13,0x30
    7c33ec8ff886:	mov    rcx,r13
    7c33ec8ff889:	or     r14,rcx
    7c33ec8ff88c:	mov    QWORD PTR [r12+0x210],rbp
    7c33ec8ff894:	mov    QWORD PTR [r12+0x218],r14
    7c33ec8ff89c:	mov    r13,QWORD PTR [r12+0x138]
    7c33ec8ff8a4:	mov    r14d,0x0
    7c33ec8ff8aa:	mov    r15,r13
    7c33ec8ff8ad:	and    r15,0xff
    7c33ec8ff8b4:	and    r15,0xffff
    7c33ec8ff8bb:	mov    rcx,r15
    7c33ec8ff8be:	mov    rbp,r14
    7c33ec8ff8c1:	or     rbp,rcx
    7c33ec8ff8c4:	mov    r15,r13
    7c33ec8ff8c7:	shr    r15,0x8
    7c33ec8ff8cb:	and    r15,0xff
    7c33ec8ff8d2:	and    r15,0xffff
    7c33ec8ff8d9:	shl    r15,0x10
    7c33ec8ff8dd:	mov    rcx,r15
    7c33ec8ff8e0:	or     rbp,rcx
    7c33ec8ff8e3:	mov    r15,r13
    7c33ec8ff8e6:	shr    r15,0x10
    7c33ec8ff8ea:	and    r15,0xff
    7c33ec8ff8f1:	and    r15,0xffff
    7c33ec8ff8f8:	shl    r15,0x20
    7c33ec8ff8fc:	mov    rcx,r15
    7c33ec8ff8ff:	or     rbp,rcx
    7c33ec8ff902:	mov    r15,r13
    7c33ec8ff905:	shr    r15,0x18
    7c33ec8ff909:	and    r15,0xff
    7c33ec8ff910:	and    r15,0xffff
    7c33ec8ff917:	shl    r15,0x30
    7c33ec8ff91b:	mov    rcx,r15
    7c33ec8ff91e:	or     rbp,rcx
    7c33ec8ff921:	mov    r15,r13
    7c33ec8ff924:	shr    r15,0x20
    7c33ec8ff928:	and    r15,0xff
    7c33ec8ff92f:	and    r15,0xffff
    7c33ec8ff936:	mov    rcx,r15
    7c33ec8ff939:	or     r14,rcx
    7c33ec8ff93c:	mov    r15,r13
    7c33ec8ff93f:	shr    r15,0x28
    7c33ec8ff943:	and    r15,0xff
    7c33ec8ff94a:	and    r15,0xffff
    7c33ec8ff951:	shl    r15,0x10
    7c33ec8ff955:	mov    rcx,r15
    7c33ec8ff958:	or     r14,rcx
    7c33ec8ff95b:	mov    r15,r13
    7c33ec8ff95e:	shr    r15,0x30
    7c33ec8ff962:	and    r15,0xff
    7c33ec8ff969:	and    r15,0xffff
    7c33ec8ff970:	shl    r15,0x20
    7c33ec8ff974:	mov    rcx,r15
    7c33ec8ff977:	or     r14,rcx
    7c33ec8ff97a:	shr    r13,0x38
    7c33ec8ff97e:	and    r13,0xff
    7c33ec8ff985:	and    r13,0xffff
    7c33ec8ff98c:	shl    r13,0x30
    7c33ec8ff990:	mov    rcx,r13
    7c33ec8ff993:	or     r14,rcx
    7c33ec8ff996:	mov    QWORD PTR [r12+0x220],rbp
    7c33ec8ff99e:	mov    QWORD PTR [r12+0x228],r14
    7c33ec8ff9a6:	mov    r13,QWORD PTR [r12+0x140]
    7c33ec8ff9ae:	mov    r14d,0x0
    7c33ec8ff9b4:	mov    r15,r13
    7c33ec8ff9b7:	and    r15,0xff
    7c33ec8ff9be:	and    r15,0xffff
    7c33ec8ff9c5:	mov    rcx,r15
    7c33ec8ff9c8:	mov    rbp,r14
    7c33ec8ff9cb:	or     rbp,rcx
    7c33ec8ff9ce:	mov    r15,r13
    7c33ec8ff9d1:	shr    r15,0x8
    7c33ec8ff9d5:	and    r15,0xff
    7c33ec8ff9dc:	and    r15,0xffff
    7c33ec8ff9e3:	shl    r15,0x10
    7c33ec8ff9e7:	mov    rcx,r15
    7c33ec8ff9ea:	or     rbp,rcx
    7c33ec8ff9ed:	mov    r15,r13
    7c33ec8ff9f0:	shr    r15,0x10
    7c33ec8ff9f4:	and    r15,0xff
    7c33ec8ff9fb:	and    r15,0xffff
    7c33ec8ffa02:	shl    r15,0x20
    7c33ec8ffa06:	mov    rcx,r15
    7c33ec8ffa09:	or     rbp,rcx
    7c33ec8ffa0c:	mov    r15,r13
    7c33ec8ffa0f:	shr    r15,0x18
    7c33ec8ffa13:	and    r15,0xff
    7c33ec8ffa1a:	and    r15,0xffff
    7c33ec8ffa21:	shl    r15,0x30
    7c33ec8ffa25:	mov    rcx,r15
    7c33ec8ffa28:	or     rbp,rcx
    7c33ec8ffa2b:	mov    r15,r13
    7c33ec8ffa2e:	shr    r15,0x20
    7c33ec8ffa32:	and    r15,0xff
    7c33ec8ffa39:	and    r15,0xffff
    7c33ec8ffa40:	mov    rcx,r15
    7c33ec8ffa43:	or     r14,rcx
    7c33ec8ffa46:	mov    r15,r13
    7c33ec8ffa49:	shr    r15,0x28
    7c33ec8ffa4d:	and    r15,0xff
    7c33ec8ffa54:	and    r15,0xffff
    7c33ec8ffa5b:	shl    r15,0x10
    7c33ec8ffa5f:	mov    rcx,r15
    7c33ec8ffa62:	or     r14,rcx
    7c33ec8ffa65:	mov    r15,r13
    7c33ec8ffa68:	shr    r15,0x30
    7c33ec8ffa6c:	and    r15,0xff
    7c33ec8ffa73:	and    r15,0xffff
    7c33ec8ffa7a:	shl    r15,0x20
    7c33ec8ffa7e:	mov    rcx,r15
    7c33ec8ffa81:	or     r14,rcx
    7c33ec8ffa84:	shr    r13,0x38
    7c33ec8ffa88:	and    r13,0xff
    7c33ec8ffa8f:	and    r13,0xffff
    7c33ec8ffa96:	shl    r13,0x30
    7c33ec8ffa9a:	mov    rcx,r13
    7c33ec8ffa9d:	or     r14,rcx
    7c33ec8ffaa0:	mov    QWORD PTR [r12+0x250],rbp
    7c33ec8ffaa8:	mov    QWORD PTR [r12+0x258],r14
    7c33ec8ffab0:	mov    r13,QWORD PTR [r12+0x148]
    7c33ec8ffab8:	mov    r14d,0x0
    7c33ec8ffabe:	mov    r15,r13
    7c33ec8ffac1:	and    r15,0xff
    7c33ec8ffac8:	and    r15,0xffff
    7c33ec8ffacf:	mov    rcx,r15
    7c33ec8ffad2:	mov    rbp,r14
    7c33ec8ffad5:	or     rbp,rcx
    7c33ec8ffad8:	mov    r15,r13
    7c33ec8ffadb:	shr    r15,0x8
    7c33ec8ffadf:	and    r15,0xff
    7c33ec8ffae6:	and    r15,0xffff
    7c33ec8ffaed:	shl    r15,0x10
    7c33ec8ffaf1:	mov    rcx,r15
    7c33ec8ffaf4:	or     rbp,rcx
    7c33ec8ffaf7:	mov    r15,r13
    7c33ec8ffafa:	shr    r15,0x10
    7c33ec8ffafe:	and    r15,0xff
    7c33ec8ffb05:	and    r15,0xffff
    7c33ec8ffb0c:	shl    r15,0x20
    7c33ec8ffb10:	mov    rcx,r15
    7c33ec8ffb13:	or     rbp,rcx
    7c33ec8ffb16:	mov    r15,r13
    7c33ec8ffb19:	shr    r15,0x18
    7c33ec8ffb1d:	and    r15,0xff
    7c33ec8ffb24:	and    r15,0xffff
    7c33ec8ffb2b:	shl    r15,0x30
    7c33ec8ffb2f:	mov    rcx,r15
    7c33ec8ffb32:	or     rbp,rcx
    7c33ec8ffb35:	mov    r15,r13
    7c33ec8ffb38:	shr    r15,0x20
    7c33ec8ffb3c:	and    r15,0xff
    7c33ec8ffb43:	and    r15,0xffff
    7c33ec8ffb4a:	mov    rcx,r15
    7c33ec8ffb4d:	or     r14,rcx
    7c33ec8ffb50:	mov    r15,r13
    7c33ec8ffb53:	shr    r15,0x28
    7c33ec8ffb57:	and    r15,0xff
    7c33ec8ffb5e:	and    r15,0xffff
    7c33ec8ffb65:	shl    r15,0x10
    7c33ec8ffb69:	mov    rcx,r15
    7c33ec8ffb6c:	or     r14,rcx
    7c33ec8ffb6f:	mov    r15,r13
    7c33ec8ffb72:	shr    r15,0x30
    7c33ec8ffb76:	and    r15,0xff
    7c33ec8ffb7d:	and    r15,0xffff
    7c33ec8ffb84:	shl    r15,0x20
    7c33ec8ffb88:	mov    rcx,r15
    7c33ec8ffb8b:	or     r14,rcx
    7c33ec8ffb8e:	shr    r13,0x38
    7c33ec8ffb92:	and    r13,0xff
    7c33ec8ffb99:	and    r13,0xffff
    7c33ec8ffba0:	shl    r13,0x30
    7c33ec8ffba4:	mov    rcx,r13
    7c33ec8ffba7:	or     r14,rcx
    7c33ec8ffbaa:	mov    QWORD PTR [r12+0x110],rbp
    7c33ec8ffbb2:	mov    QWORD PTR [r12+0x118],r14
    7c33ec8ffbba:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec8ffbc4:	movdqa xmm2,xmm0
    7c33ec8ffbc8:	pxor   xmm0,xmm0
    7c33ec8ffbcc:	movdqa xmm3,xmm0
    7c33ec8ffbd0:	movdqa xmm0,xmm2
    7c33ec8ffbd4:	movdqa xmm1,xmm3
    7c33ec8ffbd8:	punpcklwd xmm0,xmm1
    7c33ec8ffbdc:	movdqa xmm4,xmm0
    7c33ec8ffbe0:	movdqa xmm0,xmm4
    7c33ec8ffbe4:	pslld  xmm0,0x10
    7c33ec8ffbe9:	movdqa xmm2,xmm0
    7c33ec8ffbed:	movdqa xmm0,xmm2
    7c33ec8ffbf1:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c33ec8ffbfb:	mov    r13,QWORD PTR [r12+0x160]
    7c33ec8ffc03:	mov    r14d,0x0
    7c33ec8ffc09:	mov    r15,r13
    7c33ec8ffc0c:	and    r15,0xffff
    7c33ec8ffc13:	shl    r15,0x8
    7c33ec8ffc17:	mov    ecx,0xffffffff
    7c33ec8ffc1c:	and    r15,rcx
    7c33ec8ffc1f:	mov    rcx,r15
    7c33ec8ffc22:	mov    rbp,r14
    7c33ec8ffc25:	or     rbp,rcx
    7c33ec8ffc28:	mov    r15,r13
    7c33ec8ffc2b:	shr    r15,0x10
    7c33ec8ffc2f:	and    r15,0xffff
    7c33ec8ffc36:	shl    r15,0x8
    7c33ec8ffc3a:	mov    ecx,0xffffffff
    7c33ec8ffc3f:	and    r15,rcx
    7c33ec8ffc42:	shl    r15,0x20
    7c33ec8ffc46:	mov    rcx,r15
    7c33ec8ffc49:	or     rbp,rcx
    7c33ec8ffc4c:	mov    r15,r13
    7c33ec8ffc4f:	shr    r15,0x20
    7c33ec8ffc53:	and    r15,0xffff
    7c33ec8ffc5a:	shl    r15,0x8
    7c33ec8ffc5e:	mov    ecx,0xffffffff
    7c33ec8ffc63:	and    r15,rcx
    7c33ec8ffc66:	mov    rcx,r15
    7c33ec8ffc69:	or     r14,rcx
    7c33ec8ffc6c:	shr    r13,0x30
    7c33ec8ffc70:	and    r13,0xffff
    7c33ec8ffc77:	shl    r13,0x8
    7c33ec8ffc7b:	mov    ecx,0xffffffff
    7c33ec8ffc80:	and    r13,rcx
    7c33ec8ffc83:	shl    r13,0x20
    7c33ec8ffc87:	mov    rcx,r13
    7c33ec8ffc8a:	or     r14,rcx
    7c33ec8ffc8d:	mov    QWORD PTR [r12+0x240],rbp
    7c33ec8ffc95:	mov    QWORD PTR [r12+0x248],r14
    7c33ec8ffc9d:	mov    r13,QWORD PTR [r12+0x178]
    7c33ec8ffca5:	mov    r14d,0x0
    7c33ec8ffcab:	mov    r15,r13
    7c33ec8ffcae:	and    r15,0xffff
    7c33ec8ffcb5:	mov    ecx,0xffffffff
    7c33ec8ffcba:	and    r15,rcx
    7c33ec8ffcbd:	mov    rcx,r15
    7c33ec8ffcc0:	mov    rbp,r14
    7c33ec8ffcc3:	or     rbp,rcx
    7c33ec8ffcc6:	mov    r15,r13
    7c33ec8ffcc9:	shr    r15,0x10
    7c33ec8ffccd:	and    r15,0xffff
    7c33ec8ffcd4:	mov    ecx,0xffffffff
    7c33ec8ffcd9:	and    r15,rcx
    7c33ec8ffcdc:	shl    r15,0x20
    7c33ec8ffce0:	mov    rcx,r15
    7c33ec8ffce3:	or     rbp,rcx
    7c33ec8ffce6:	mov    r15,r13
    7c33ec8ffce9:	shr    r15,0x20
    7c33ec8ffced:	and    r15,0xffff
    7c33ec8ffcf4:	mov    ecx,0xffffffff
    7c33ec8ffcf9:	and    r15,rcx
    7c33ec8ffcfc:	mov    rcx,r15
    7c33ec8ffcff:	or     r14,rcx
    7c33ec8ffd02:	shr    r13,0x30
    7c33ec8ffd06:	and    r13,0xffff
    7c33ec8ffd0d:	mov    ecx,0xffffffff
    7c33ec8ffd12:	and    r13,rcx
    7c33ec8ffd15:	shl    r13,0x20
    7c33ec8ffd19:	mov    rcx,r13
    7c33ec8ffd1c:	or     r14,rcx
    7c33ec8ffd1f:	mov    QWORD PTR [r12+0x260],rbp
    7c33ec8ffd27:	mov    QWORD PTR [r12+0x268],r14
    7c33ec8ffd2f:	mov    r13,QWORD PTR [r12+0x188]
    7c33ec8ffd37:	mov    r14d,0x0
    7c33ec8ffd3d:	mov    r15,r13
    7c33ec8ffd40:	and    r15,0xffff
    7c33ec8ffd47:	mov    ecx,0xffffffff
    7c33ec8ffd4c:	and    r15,rcx
    7c33ec8ffd4f:	mov    rcx,r15
    7c33ec8ffd52:	mov    rbp,r14
    7c33ec8ffd55:	or     rbp,rcx
    7c33ec8ffd58:	mov    r15,r13
    7c33ec8ffd5b:	shr    r15,0x10
    7c33ec8ffd5f:	and    r15,0xffff
    7c33ec8ffd66:	mov    ecx,0xffffffff
    7c33ec8ffd6b:	and    r15,rcx
    7c33ec8ffd6e:	shl    r15,0x20
    7c33ec8ffd72:	mov    rcx,r15
    7c33ec8ffd75:	or     rbp,rcx
    7c33ec8ffd78:	mov    r15,r13
    7c33ec8ffd7b:	shr    r15,0x20
    7c33ec8ffd7f:	and    r15,0xffff
    7c33ec8ffd86:	mov    ecx,0xffffffff
    7c33ec8ffd8b:	and    r15,rcx
    7c33ec8ffd8e:	mov    rcx,r15
    7c33ec8ffd91:	or     r14,rcx
    7c33ec8ffd94:	shr    r13,0x30
    7c33ec8ffd98:	and    r13,0xffff
    7c33ec8ffd9f:	mov    ecx,0xffffffff
    7c33ec8ffda4:	and    r13,rcx
    7c33ec8ffda7:	shl    r13,0x20
    7c33ec8ffdab:	mov    rcx,r13
    7c33ec8ffdae:	or     r14,rcx
    7c33ec8ffdb1:	mov    QWORD PTR [r12+0x270],rbp
    7c33ec8ffdb9:	mov    QWORD PTR [r12+0x278],r14
    7c33ec8ffdc1:	mov    r13,QWORD PTR [r12+0x170]
    7c33ec8ffdc9:	mov    r14d,0x0
    7c33ec8ffdcf:	mov    r15,r13
    7c33ec8ffdd2:	and    r15,0xffff
    7c33ec8ffdd9:	mov    ecx,0xffffffff
    7c33ec8ffdde:	and    r15,rcx
    7c33ec8ffde1:	mov    rcx,r15
    7c33ec8ffde4:	mov    rbp,r14
    7c33ec8ffde7:	or     rbp,rcx
    7c33ec8ffdea:	mov    r15,r13
    7c33ec8ffded:	shr    r15,0x10
    7c33ec8ffdf1:	and    r15,0xffff
    7c33ec8ffdf8:	mov    ecx,0xffffffff
    7c33ec8ffdfd:	and    r15,rcx
    7c33ec8ffe00:	shl    r15,0x20
    7c33ec8ffe04:	mov    rcx,r15
    7c33ec8ffe07:	or     rbp,rcx
    7c33ec8ffe0a:	mov    r15,r13
    7c33ec8ffe0d:	shr    r15,0x20
    7c33ec8ffe11:	and    r15,0xffff
    7c33ec8ffe18:	mov    ecx,0xffffffff
    7c33ec8ffe1d:	and    r15,rcx
    7c33ec8ffe20:	mov    rcx,r15
    7c33ec8ffe23:	or     r14,rcx
    7c33ec8ffe26:	shr    r13,0x30
    7c33ec8ffe2a:	and    r13,0xffff
    7c33ec8ffe31:	mov    ecx,0xffffffff
    7c33ec8ffe36:	and    r13,rcx
    7c33ec8ffe39:	shl    r13,0x20
    7c33ec8ffe3d:	mov    rcx,r13
    7c33ec8ffe40:	or     r14,rcx
    7c33ec8ffe43:	mov    QWORD PTR [r12+0x170],rbp
    7c33ec8ffe4b:	mov    QWORD PTR [r12+0x178],r14
    7c33ec8ffe53:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec8ffe5d:	movdqa xmm2,xmm0
    7c33ec8ffe61:	pxor   xmm0,xmm0
    7c33ec8ffe65:	movdqa xmm3,xmm0
    7c33ec8ffe69:	movdqa xmm0,xmm2
    7c33ec8ffe6d:	movdqa xmm1,xmm3
    7c33ec8ffe71:	punpckhwd xmm0,xmm1
    7c33ec8ffe75:	movdqa xmm4,xmm0
    7c33ec8ffe79:	movdqa xmm0,xmm4
    7c33ec8ffe7d:	pslld  xmm0,0x10
    7c33ec8ffe82:	movdqa xmm3,xmm0
    7c33ec8ffe86:	movdqa xmm0,xmm3
    7c33ec8ffe8a:	movdqu XMMWORD PTR [r12+0x280],xmm0
    7c33ec8ffe94:	mov    r13,QWORD PTR [r12+0x180]
    7c33ec8ffe9c:	mov    r14d,0x0
    7c33ec8ffea2:	mov    r15,r13
    7c33ec8ffea5:	and    r15,0xffff
    7c33ec8ffeac:	mov    ecx,0xffffffff
    7c33ec8ffeb1:	and    r15,rcx
    7c33ec8ffeb4:	mov    rcx,r15
    7c33ec8ffeb7:	mov    rbp,r14
    7c33ec8ffeba:	or     rbp,rcx
    7c33ec8ffebd:	mov    r15,r13
    7c33ec8ffec0:	shr    r15,0x10
    7c33ec8ffec4:	and    r15,0xffff
    7c33ec8ffecb:	mov    ecx,0xffffffff
    7c33ec8ffed0:	and    r15,rcx
    7c33ec8ffed3:	shl    r15,0x20
    7c33ec8ffed7:	mov    rcx,r15
    7c33ec8ffeda:	or     rbp,rcx
    7c33ec8ffedd:	mov    r15,r13
    7c33ec8ffee0:	shr    r15,0x20
    7c33ec8ffee4:	and    r15,0xffff
    7c33ec8ffeeb:	mov    ecx,0xffffffff
    7c33ec8ffef0:	and    r15,rcx
    7c33ec8ffef3:	mov    rcx,r15
    7c33ec8ffef6:	or     r14,rcx
    7c33ec8ffef9:	shr    r13,0x30
    7c33ec8ffefd:	and    r13,0xffff
    7c33ec8fff04:	mov    ecx,0xffffffff
    7c33ec8fff09:	and    r13,rcx
    7c33ec8fff0c:	shl    r13,0x20
    7c33ec8fff10:	mov    rcx,r13
    7c33ec8fff13:	or     r14,rcx
    7c33ec8fff16:	mov    QWORD PTR [r12+0x180],rbp
    7c33ec8fff1e:	mov    QWORD PTR [r12+0x188],r14
    7c33ec8fff26:	pxor   xmm0,xmm0
    7c33ec8fff2a:	movdqa xmm3,xmm0
    7c33ec8fff2e:	movdqa xmm0,xmm2
    7c33ec8fff32:	movdqa xmm1,xmm3
    7c33ec8fff36:	punpcklwd xmm0,xmm1
    7c33ec8fff3a:	movdqa xmm4,xmm0
    7c33ec8fff3e:	movdqa xmm0,xmm4
    7c33ec8fff42:	pslld  xmm0,0x10
    7c33ec8fff47:	movdqa xmm2,xmm0
    7c33ec8fff4b:	movdqa xmm0,xmm2
    7c33ec8fff4f:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec8fff59:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec8fff63:	movdqa xmm2,xmm0
    7c33ec8fff67:	pxor   xmm0,xmm0
    7c33ec8fff6b:	movdqa xmm3,xmm0
    7c33ec8fff6f:	movdqa xmm0,xmm2
    7c33ec8fff73:	movdqa xmm1,xmm3
    7c33ec8fff77:	punpckhwd xmm0,xmm1
    7c33ec8fff7b:	movdqa xmm4,xmm0
    7c33ec8fff7f:	movdqa xmm0,xmm4
    7c33ec8fff83:	pslld  xmm0,0x10
    7c33ec8fff88:	movdqa xmm2,xmm0
    7c33ec8fff8c:	movdqa xmm0,xmm2
    7c33ec8fff90:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec8fff9a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c33ec8fffa4:	movdqa xmm2,xmm0
    7c33ec8fffa8:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec8fffb2:	movdqa xmm3,xmm0
    7c33ec8fffb6:	movdqa xmm1,xmm2
    7c33ec8fffba:	por    xmm3,xmm1
    7c33ec8fffbe:	movdqa xmm0,xmm3
    7c33ec8fffc2:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c33ec8fffcc:	mov    r13,QWORD PTR [r12+0x228]
    7c33ec8fffd4:	mov    r14d,0x0
    7c33ec8fffda:	mov    r15,r13
    7c33ec8fffdd:	and    r15,0xffff
    7c33ec8fffe4:	shl    r15,0x8
    7c33ec8fffe8:	mov    ecx,0xffffffff
    7c33ec8fffed:	and    r15,rcx
    7c33ec8ffff0:	mov    rcx,r15
    7c33ec8ffff3:	mov    rbp,r14
    7c33ec8ffff6:	or     rbp,rcx
    7c33ec8ffff9:	mov    r15,r13
    7c33ec8ffffc:	shr    r15,0x10
    7c33ec900000:	and    r15,0xffff
    7c33ec900007:	shl    r15,0x8
    7c33ec90000b:	mov    ecx,0xffffffff
    7c33ec900010:	and    r15,rcx
    7c33ec900013:	shl    r15,0x20
    7c33ec900017:	mov    rcx,r15
    7c33ec90001a:	or     rbp,rcx
    7c33ec90001d:	mov    r15,r13
    7c33ec900020:	shr    r15,0x20
    7c33ec900024:	and    r15,0xffff
    7c33ec90002b:	shl    r15,0x8
    7c33ec90002f:	mov    ecx,0xffffffff
    7c33ec900034:	and    r15,rcx
    7c33ec900037:	mov    rcx,r15
    7c33ec90003a:	or     r14,rcx
    7c33ec90003d:	shr    r13,0x30
    7c33ec900041:	and    r13,0xffff
    7c33ec900048:	shl    r13,0x8
    7c33ec90004c:	mov    ecx,0xffffffff
    7c33ec900051:	and    r13,rcx
    7c33ec900054:	shl    r13,0x20
    7c33ec900058:	mov    rcx,r13
    7c33ec90005b:	or     r14,rcx
    7c33ec90005e:	mov    QWORD PTR [r12+0x240],rbp
    7c33ec900066:	mov    QWORD PTR [r12+0x248],r14
    7c33ec90006e:	mov    r13,QWORD PTR [r12+0x220]
    7c33ec900076:	mov    r14d,0x0
    7c33ec90007c:	mov    r15,r13
    7c33ec90007f:	and    r15,0xffff
    7c33ec900086:	shl    r15,0x8
    7c33ec90008a:	mov    ecx,0xffffffff
    7c33ec90008f:	and    r15,rcx
    7c33ec900092:	mov    rcx,r15
    7c33ec900095:	mov    rbp,r14
    7c33ec900098:	or     rbp,rcx
    7c33ec90009b:	mov    r15,r13
    7c33ec90009e:	shr    r15,0x10
    7c33ec9000a2:	and    r15,0xffff
    7c33ec9000a9:	shl    r15,0x8
    7c33ec9000ad:	mov    ecx,0xffffffff
    7c33ec9000b2:	and    r15,rcx
    7c33ec9000b5:	shl    r15,0x20
    7c33ec9000b9:	mov    rcx,r15
    7c33ec9000bc:	or     rbp,rcx
    7c33ec9000bf:	mov    r15,r13
    7c33ec9000c2:	shr    r15,0x20
    7c33ec9000c6:	and    r15,0xffff
    7c33ec9000cd:	shl    r15,0x8
    7c33ec9000d1:	mov    ecx,0xffffffff
    7c33ec9000d6:	and    r15,rcx
    7c33ec9000d9:	mov    rcx,r15
    7c33ec9000dc:	or     r14,rcx
    7c33ec9000df:	shr    r13,0x30
    7c33ec9000e3:	and    r13,0xffff
    7c33ec9000ea:	shl    r13,0x8
    7c33ec9000ee:	mov    ecx,0xffffffff
    7c33ec9000f3:	and    r13,rcx
    7c33ec9000f6:	shl    r13,0x20
    7c33ec9000fa:	mov    rcx,r13
    7c33ec9000fd:	or     r14,rcx
    7c33ec900100:	mov    QWORD PTR [r12+0x220],rbp
    7c33ec900108:	mov    QWORD PTR [r12+0x228],r14
    7c33ec900110:	mov    r13,QWORD PTR [r12+0x168]
    7c33ec900118:	mov    r14d,0x0
    7c33ec90011e:	mov    r15,r13
    7c33ec900121:	and    r15,0xffff
    7c33ec900128:	shl    r15,0x8
    7c33ec90012c:	mov    ecx,0xffffffff
    7c33ec900131:	and    r15,rcx
    7c33ec900134:	mov    rcx,r15
    7c33ec900137:	mov    rbp,r14
    7c33ec90013a:	or     rbp,rcx
    7c33ec90013d:	mov    r15,r13
    7c33ec900140:	shr    r15,0x10
    7c33ec900144:	and    r15,0xffff
    7c33ec90014b:	shl    r15,0x8
    7c33ec90014f:	mov    ecx,0xffffffff
    7c33ec900154:	and    r15,rcx
    7c33ec900157:	shl    r15,0x20
    7c33ec90015b:	mov    rcx,r15
    7c33ec90015e:	or     rbp,rcx
    7c33ec900161:	mov    r15,r13
    7c33ec900164:	shr    r15,0x20
    7c33ec900168:	and    r15,0xffff
    7c33ec90016f:	shl    r15,0x8
    7c33ec900173:	mov    ecx,0xffffffff
    7c33ec900178:	and    r15,rcx
    7c33ec90017b:	mov    rcx,r15
    7c33ec90017e:	or     r14,rcx
    7c33ec900181:	shr    r13,0x30
    7c33ec900185:	and    r13,0xffff
    7c33ec90018c:	shl    r13,0x8
    7c33ec900190:	mov    ecx,0xffffffff
    7c33ec900195:	and    r13,rcx
    7c33ec900198:	shl    r13,0x20
    7c33ec90019c:	mov    rcx,r13
    7c33ec90019f:	or     r14,rcx
    7c33ec9001a2:	mov    QWORD PTR [r12+0x160],rbp
    7c33ec9001aa:	mov    QWORD PTR [r12+0x168],r14
    7c33ec9001b2:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec9001bc:	movdqa xmm2,xmm0
    7c33ec9001c0:	movdqa xmm0,xmm2
    7c33ec9001c4:	pslld  xmm0,0x18
    7c33ec9001c9:	movdqa xmm3,xmm0
    7c33ec9001cd:	movdqa xmm0,xmm3
    7c33ec9001d1:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c33ec9001db:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c33ec9001e5:	movdqa xmm2,xmm0
    7c33ec9001e9:	movdqa xmm0,xmm2
    7c33ec9001ed:	pslld  xmm0,0x18
    7c33ec9001f2:	movdqa xmm3,xmm0
    7c33ec9001f6:	movdqa xmm0,xmm3
    7c33ec9001fa:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec900204:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec90020e:	movdqa xmm2,xmm0
    7c33ec900212:	movdqa xmm0,xmm2
    7c33ec900216:	pslld  xmm0,0x18
    7c33ec90021b:	movdqa xmm3,xmm0
    7c33ec90021f:	movdqa xmm0,xmm3
    7c33ec900223:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c33ec90022d:	mov    r13,QWORD PTR [r12+0x250]
    7c33ec900235:	mov    r14d,0x0
    7c33ec90023b:	mov    r15,r13
    7c33ec90023e:	and    r15,0xffff
    7c33ec900245:	mov    ecx,0xffffffff
    7c33ec90024a:	and    r15,rcx
    7c33ec90024d:	mov    rcx,r15
    7c33ec900250:	mov    rbp,r14
    7c33ec900253:	or     rbp,rcx
    7c33ec900256:	mov    r15,r13
    7c33ec900259:	shr    r15,0x10
    7c33ec90025d:	and    r15,0xffff
    7c33ec900264:	mov    ecx,0xffffffff
    7c33ec900269:	and    r15,rcx
    7c33ec90026c:	shl    r15,0x20
    7c33ec900270:	mov    rcx,r15
    7c33ec900273:	or     rbp,rcx
    7c33ec900276:	mov    r15,r13
    7c33ec900279:	shr    r15,0x20
    7c33ec90027d:	and    r15,0xffff
    7c33ec900284:	mov    ecx,0xffffffff
    7c33ec900289:	and    r15,rcx
    7c33ec90028c:	mov    rcx,r15
    7c33ec90028f:	or     r14,rcx
    7c33ec900292:	shr    r13,0x30
    7c33ec900296:	and    r13,0xffff
    7c33ec90029d:	mov    ecx,0xffffffff
    7c33ec9002a2:	and    r13,rcx
    7c33ec9002a5:	shl    r13,0x20
    7c33ec9002a9:	mov    rcx,r13
    7c33ec9002ac:	or     r14,rcx
    7c33ec9002af:	mov    QWORD PTR [r12+0x140],rbp
    7c33ec9002b7:	mov    QWORD PTR [r12+0x148],r14
    7c33ec9002bf:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c33ec9002c9:	movdqa xmm2,xmm0
    7c33ec9002cd:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7c33ec9002d7:	movdqa xmm3,xmm0
    7c33ec9002db:	movdqa xmm1,xmm2
    7c33ec9002df:	por    xmm3,xmm1
    7c33ec9002e3:	movdqa xmm0,xmm3
    7c33ec9002e7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec9002f1:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec9002fb:	movdqa xmm2,xmm0
    7c33ec9002ff:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec900309:	movdqa xmm3,xmm0
    7c33ec90030d:	movdqa xmm1,xmm2
    7c33ec900311:	por    xmm3,xmm1
    7c33ec900315:	movdqa xmm0,xmm3
    7c33ec900319:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c33ec900323:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7c33ec90032d:	movdqa xmm2,xmm0
    7c33ec900331:	movdqa xmm0,xmm2
    7c33ec900335:	pslld  xmm0,0x18
    7c33ec90033a:	movdqa xmm3,xmm0
    7c33ec90033e:	movdqa xmm0,xmm3
    7c33ec900342:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c33ec90034c:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec900356:	movdqa xmm2,xmm0
    7c33ec90035a:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec900364:	movdqa xmm3,xmm0
    7c33ec900368:	movdqa xmm1,xmm2
    7c33ec90036c:	por    xmm3,xmm1
    7c33ec900370:	movdqa xmm0,xmm3
    7c33ec900374:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec90037e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec900388:	movdqa xmm2,xmm0
    7c33ec90038c:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c33ec900396:	movdqa xmm3,xmm0
    7c33ec90039a:	movdqa xmm1,xmm2
    7c33ec90039e:	por    xmm3,xmm1
    7c33ec9003a2:	movdqa xmm0,xmm3
    7c33ec9003a6:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c33ec9003b0:	mov    r13,QWORD PTR [r12+0x118]
    7c33ec9003b8:	mov    r14d,0x0
    7c33ec9003be:	mov    r15,r13
    7c33ec9003c1:	and    r15,0xffff
    7c33ec9003c8:	mov    ecx,0xffffffff
    7c33ec9003cd:	and    r15,rcx
    7c33ec9003d0:	mov    rcx,r15
    7c33ec9003d3:	mov    rbp,r14
    7c33ec9003d6:	or     rbp,rcx
    7c33ec9003d9:	mov    r15,r13
    7c33ec9003dc:	shr    r15,0x10
    7c33ec9003e0:	and    r15,0xffff
    7c33ec9003e7:	mov    ecx,0xffffffff
    7c33ec9003ec:	and    r15,rcx
    7c33ec9003ef:	shl    r15,0x20
    7c33ec9003f3:	mov    rcx,r15
    7c33ec9003f6:	or     rbp,rcx
    7c33ec9003f9:	mov    r15,r13
    7c33ec9003fc:	shr    r15,0x20
    7c33ec900400:	and    r15,0xffff
    7c33ec900407:	mov    ecx,0xffffffff
    7c33ec90040c:	and    r15,rcx
    7c33ec90040f:	mov    rcx,r15
    7c33ec900412:	or     r14,rcx
    7c33ec900415:	shr    r13,0x30
    7c33ec900419:	and    r13,0xffff
    7c33ec900420:	mov    ecx,0xffffffff
    7c33ec900425:	and    r13,rcx
    7c33ec900428:	shl    r13,0x20
    7c33ec90042c:	mov    rcx,r13
    7c33ec90042f:	or     r14,rcx
    7c33ec900432:	mov    QWORD PTR [r12+0x170],rbp
    7c33ec90043a:	mov    QWORD PTR [r12+0x178],r14
    7c33ec900442:	mov    r13,QWORD PTR [r12+0x110]
    7c33ec90044a:	mov    r14d,0x0
    7c33ec900450:	mov    r15,r13
    7c33ec900453:	and    r15,0xffff
    7c33ec90045a:	mov    ecx,0xffffffff
    7c33ec90045f:	and    r15,rcx
    7c33ec900462:	mov    rcx,r15
    7c33ec900465:	mov    rbp,r14
    7c33ec900468:	or     rbp,rcx
    7c33ec90046b:	mov    r15,r13
    7c33ec90046e:	shr    r15,0x10
    7c33ec900472:	and    r15,0xffff
    7c33ec900479:	mov    ecx,0xffffffff
    7c33ec90047e:	and    r15,rcx
    7c33ec900481:	shl    r15,0x20
    7c33ec900485:	mov    rcx,r15
    7c33ec900488:	or     rbp,rcx
    7c33ec90048b:	mov    r15,r13
    7c33ec90048e:	shr    r15,0x20
    7c33ec900492:	and    r15,0xffff
    7c33ec900499:	mov    ecx,0xffffffff
    7c33ec90049e:	and    r15,rcx
    7c33ec9004a1:	mov    rcx,r15
    7c33ec9004a4:	or     r14,rcx
    7c33ec9004a7:	shr    r13,0x30
    7c33ec9004ab:	and    r13,0xffff
    7c33ec9004b2:	mov    ecx,0xffffffff
    7c33ec9004b7:	and    r13,rcx
    7c33ec9004ba:	shl    r13,0x20
    7c33ec9004be:	mov    rcx,r13
    7c33ec9004c1:	or     r14,rcx
    7c33ec9004c4:	mov    QWORD PTR [r12+0x110],rbp
    7c33ec9004cc:	mov    QWORD PTR [r12+0x118],r14
    7c33ec9004d4:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec9004de:	movdqa xmm2,xmm0
    7c33ec9004e2:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec9004ec:	movdqa xmm3,xmm0
    7c33ec9004f0:	movdqa xmm1,xmm2
    7c33ec9004f4:	por    xmm3,xmm1
    7c33ec9004f8:	movdqa xmm0,xmm3
    7c33ec9004fc:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec900506:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec900510:	movdqa xmm2,xmm0
    7c33ec900514:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c33ec90051e:	movdqa xmm3,xmm0
    7c33ec900522:	movdqa xmm1,xmm2
    7c33ec900526:	por    xmm3,xmm1
    7c33ec90052a:	movdqa xmm0,xmm3
    7c33ec90052e:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec900538:	mov    r13,QWORD PTR [r12+0x258]
    7c33ec900540:	mov    r14d,0x0
    7c33ec900546:	mov    r15,r13
    7c33ec900549:	and    r15,0xffff
    7c33ec900550:	mov    ecx,0xffffffff
    7c33ec900555:	and    r15,rcx
    7c33ec900558:	mov    rcx,r15
    7c33ec90055b:	mov    rbp,r14
    7c33ec90055e:	or     rbp,rcx
    7c33ec900561:	mov    r15,r13
    7c33ec900564:	shr    r15,0x10
    7c33ec900568:	and    r15,0xffff
    7c33ec90056f:	mov    ecx,0xffffffff
    7c33ec900574:	and    r15,rcx
    7c33ec900577:	shl    r15,0x20
    7c33ec90057b:	mov    rcx,r15
    7c33ec90057e:	or     rbp,rcx
    7c33ec900581:	mov    r15,r13
    7c33ec900584:	shr    r15,0x20
    7c33ec900588:	and    r15,0xffff
    7c33ec90058f:	mov    ecx,0xffffffff
    7c33ec900594:	and    r15,rcx
    7c33ec900597:	mov    rcx,r15
    7c33ec90059a:	or     r14,rcx
    7c33ec90059d:	shr    r13,0x30
    7c33ec9005a1:	and    r13,0xffff
    7c33ec9005a8:	mov    ecx,0xffffffff
    7c33ec9005ad:	and    r13,rcx
    7c33ec9005b0:	shl    r13,0x20
    7c33ec9005b4:	mov    rcx,r13
    7c33ec9005b7:	or     r14,rcx
    7c33ec9005ba:	mov    QWORD PTR [r12+0x180],rbp
    7c33ec9005c2:	mov    QWORD PTR [r12+0x188],r14
    7c33ec9005ca:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c33ec9005d4:	movdqa xmm2,xmm0
    7c33ec9005d8:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c33ec9005e2:	movdqa xmm3,xmm0
    7c33ec9005e6:	movdqa xmm1,xmm2
    7c33ec9005ea:	por    xmm3,xmm1
    7c33ec9005ee:	movdqa xmm0,xmm3
    7c33ec9005f2:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c33ec9005fc:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec900606:	movdqa xmm2,xmm0
    7c33ec90060a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c33ec900614:	movdqa xmm4,xmm0
    7c33ec900618:	movdqa xmm1,xmm2
    7c33ec90061c:	por    xmm4,xmm1
    7c33ec900620:	movdqa xmm0,xmm4
    7c33ec900624:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c33ec90062e:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c33ec900638:	movdqa xmm2,xmm0
    7c33ec90063c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c33ec900646:	movdqa xmm4,xmm0
    7c33ec90064a:	movdqa xmm1,xmm2
    7c33ec90064e:	por    xmm4,xmm1
    7c33ec900652:	movdqa xmm0,xmm4
    7c33ec900656:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c33ec900660:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c33ec90066a:	movdqa xmm2,xmm0
    7c33ec90066e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c33ec900678:	movdqa xmm5,xmm0
    7c33ec90067c:	movdqa xmm1,xmm2
    7c33ec900680:	por    xmm5,xmm1
    7c33ec900684:	movdqa xmm0,xmm5
    7c33ec900688:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c33ec900692:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c33ec90069c:	movdqa xmm2,xmm0
    7c33ec9006a0:	movdqa xmm1,xmm2
    7c33ec9006a4:	por    xmm3,xmm1
    7c33ec9006a8:	movdqa xmm0,xmm3
    7c33ec9006ac:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c33ec9006b6:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9006be:	mov    r14,r13
    7c33ec9006c1:	add    r14,0x20
    7c33ec9006c5:	mov    r15,r14
    7c33ec9006c8:	add    r15,0x10
    7c33ec9006cc:	movdqu XMMWORD PTR [r14],xmm4
    7c33ec9006d1:	mov    r14d,0x0
    7c33ec9006d7:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec9006df:	movdqu XMMWORD PTR [r15],xmm5
    7c33ec9006e4:	mov    r14d,0x0
    7c33ec9006ea:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec9006f2:	mov    r14,r13
    7c33ec9006f5:	add    r14,0x10
    7c33ec9006f9:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c33ec900703:	movdqa xmm2,xmm0
    7c33ec900707:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c33ec90070d:	mov    r15d,0x0
    7c33ec900713:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec90071b:	movdqu XMMWORD PTR [r14],xmm3
    7c33ec900720:	mov    r14d,0x0
    7c33ec900726:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec90072e:	mov    r14d,DWORD PTR [r13+0x0]
    7c33ec900732:	mov    QWORD PTR [r12+0x60],r14
    7c33ec900737:	jmp    0x7c33ec90073c
    7c33ec90073c:	mov    r13,QWORD PTR [r12+0x58]
    7c33ec900741:	mov    r14,QWORD PTR [r12+0x48]
    7c33ec900746:	mov    rcx,r13
    7c33ec900749:	add    r14,rcx
    7c33ec90074c:	mov    QWORD PTR [r12+0x68],r14
    7c33ec900751:	add    r13,0x4
    7c33ec900755:	mov    QWORD PTR [r12+0x58],r13
    7c33ec90075a:	mov    r15,r14
    7c33ec90075d:	add    r15,0x4
    7c33ec900761:	mov    ebp,DWORD PTR [r15]
    7c33ec900764:	mov    QWORD PTR [r12+0x70],rbp
    7c33ec900769:	mov    r15,r14
    7c33ec90076c:	add    r15,0x38
    7c33ec900770:	mov    r8d,DWORD PTR [r15]
    7c33ec900773:	mov    QWORD PTR [r12+0x78],r8
    7c33ec900778:	add    r14,0x24
    7c33ec90077c:	mov    r15d,DWORD PTR [r14]
    7c33ec90077f:	mov    QWORD PTR [r12+0x90],r15
    7c33ec900787:	sub    r13,0xc0
    7c33ec90078e:	pushf
    7c33ec90078f:	pop    r11
    7c33ec900791:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec900796:	mov    r13d,ebp
    7c33ec900799:	mov    r13d,r13d
    7c33ec90079c:	ror    r13d,0x7
    7c33ec9007a0:	mov    QWORD PTR [r12+0x80],r13
    7c33ec9007a8:	mov    r14d,r8d
    7c33ec9007ab:	mov    r14d,r14d
    7c33ec9007ae:	ror    r14d,0x11
    7c33ec9007b2:	mov    QWORD PTR [r12+0x88],r14
    7c33ec9007ba:	mov    r9d,DWORD PTR [r12+0x60]
    7c33ec9007bf:	mov    ecx,r9d
    7c33ec9007c2:	add    r15d,ecx
    7c33ec9007c5:	mov    QWORD PTR [r12+0x60],r15
    7c33ec9007ca:	mov    r15d,ebp
    7c33ec9007cd:	mov    r15d,r15d
    7c33ec9007d0:	shr    r15d,0x12
    7c33ec9007d4:	mov    ebp,ebp
    7c33ec9007d6:	shl    ebp,0xe
    7c33ec9007d9:	mov    ecx,ebp
    7c33ec9007db:	or     r15,rcx
    7c33ec9007de:	mov    r15d,r15d
    7c33ec9007e1:	mov    ecx,r15d
    7c33ec9007e4:	xor    r13,rcx
    7c33ec9007e7:	mov    r13d,r13d
    7c33ec9007ea:	mov    QWORD PTR [r12+0x80],r13
    7c33ec9007f2:	mov    r15d,r8d
    7c33ec9007f5:	mov    r15d,r15d
    7c33ec9007f8:	shr    r15d,0x13
    7c33ec9007fc:	mov    r8d,r8d
    7c33ec9007ff:	shl    r8d,0xd
    7c33ec900803:	mov    ecx,r8d
    7c33ec900806:	or     r15,rcx
    7c33ec900809:	mov    r15d,r15d
    7c33ec90080c:	mov    ecx,r15d
    7c33ec90080f:	xor    r14,rcx
    7c33ec900812:	mov    r14d,r14d
    7c33ec900815:	mov    QWORD PTR [r12+0x88],r14
    7c33ec90081d:	mov    r15d,DWORD PTR [r12+0x70]
    7c33ec900822:	mov    r15d,r15d
    7c33ec900825:	shr    r15d,0x3
    7c33ec900829:	mov    ecx,r15d
    7c33ec90082c:	xor    r13,rcx
    7c33ec90082f:	mov    r13d,r13d
    7c33ec900832:	mov    QWORD PTR [r12+0x80],r13
    7c33ec90083a:	mov    r15d,DWORD PTR [r12+0x78]
    7c33ec90083f:	mov    r15d,r15d
    7c33ec900842:	shr    r15d,0xa
    7c33ec900846:	mov    ecx,r15d
    7c33ec900849:	xor    r14,rcx
    7c33ec90084c:	mov    r14d,r14d
    7c33ec90084f:	mov    QWORD PTR [r12+0x78],r14
    7c33ec900854:	mov    r15d,DWORD PTR [r12+0x60]
    7c33ec900859:	mov    ecx,r13d
    7c33ec90085c:	add    r15d,ecx
    7c33ec90085f:	mov    QWORD PTR [r12+0x60],r15
    7c33ec900864:	mov    ecx,r14d
    7c33ec900867:	add    r15d,ecx
    7c33ec90086a:	mov    QWORD PTR [r12+0x60],r15
    7c33ec90086f:	mov    r13,QWORD PTR [r12+0x68]
    7c33ec900874:	add    r13,0x40
    7c33ec900878:	mov    DWORD PTR [r13+0x0],r15d
    7c33ec90087c:	mov    r13d,0x0
    7c33ec900882:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec90088a:	mov    r13d,0x0
    7c33ec900890:	mov    r14d,DWORD PTR [r12+0x70]
    7c33ec900895:	mov    ecx,r14d
    7c33ec900898:	mov    r15d,r13d
    7c33ec90089b:	or     r15,rcx
    7c33ec90089e:	mov    r15d,r15d
    7c33ec9008a1:	mov    QWORD PTR [r12+0x60],r15
    7c33ec9008a6:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec9008ae:	jrcxz  0x7c33ec9008b5
    7c33ec9008b0:	jmp    0x7c33ec90120e
    7c33ec9008b5:	push   QWORD PTR [rsp+0x48]
    7c33ec9008b9:	popf
    7c33ec9008ba:	jne    0x7c33ec90073c
    7c33ec9008c0:	jmp    0x7c33ec9008c5
    7c33ec9008c5:	mov    r13,QWORD PTR [r12]
    7c33ec9008c9:	mov    r14,r13
    7c33ec9008cc:	add    r14,0x4
    7c33ec9008d0:	mov    r15d,DWORD PTR [r13+0x0]
    7c33ec9008d4:	mov    ebp,DWORD PTR [r14]
    7c33ec9008d7:	mov    QWORD PTR [r12+0x78],r15
    7c33ec9008dc:	mov    QWORD PTR [r12+0x80],rbp
    7c33ec9008e4:	mov    r14,r13
    7c33ec9008e7:	add    r14,0x8
    7c33ec9008eb:	mov    r15,r14
    7c33ec9008ee:	add    r15,0x4
    7c33ec9008f2:	mov    ebp,DWORD PTR [r14]
    7c33ec9008f5:	mov    r14d,DWORD PTR [r15]
    7c33ec9008f8:	mov    QWORD PTR [r12+0x70],rbp
    7c33ec9008fd:	mov    QWORD PTR [r12+0x68],r14
    7c33ec900902:	mov    r14,r13
    7c33ec900905:	add    r14,0x18
    7c33ec900909:	mov    r15,r14
    7c33ec90090c:	add    r15,0x4
    7c33ec900910:	mov    ebp,DWORD PTR [r14]
    7c33ec900913:	mov    r14d,DWORD PTR [r15]
    7c33ec900916:	mov    QWORD PTR [r12+0x58],rbp
    7c33ec90091b:	mov    QWORD PTR [r12+0x60],r14
    7c33ec900920:	add    r13,0x10
    7c33ec900924:	mov    r14,r13
    7c33ec900927:	add    r14,0x4
    7c33ec90092b:	mov    r15d,DWORD PTR [r13+0x0]
    7c33ec90092f:	mov    r13d,DWORD PTR [r14]
    7c33ec900932:	mov    QWORD PTR [r12+0x18],r15
    7c33ec900937:	mov    QWORD PTR [r12+0x90],r13
    7c33ec90093f:	mov    r13d,0x0
    7c33ec900945:	mov    QWORD PTR [r12+0x88],r13
    7c33ec90094d:	mov    r13d,0x0
    7c33ec900953:	mov    r14d,DWORD PTR [r12+0x78]
    7c33ec900958:	mov    ecx,r14d
    7c33ec90095b:	mov    r15d,r13d
    7c33ec90095e:	or     r15,rcx
    7c33ec900961:	mov    r15d,r15d
    7c33ec900964:	mov    QWORD PTR [r12+0xa8],r15
    7c33ec90096c:	mov    r13d,0x0
    7c33ec900972:	mov    r14d,DWORD PTR [r12+0x80]
    7c33ec90097a:	mov    ecx,r14d
    7c33ec90097d:	mov    r15d,r13d
    7c33ec900980:	or     r15,rcx
    7c33ec900983:	mov    r15d,r15d
    7c33ec900986:	mov    QWORD PTR [r12+0x38],r15
    7c33ec90098b:	mov    r13d,0x0
    7c33ec900991:	mov    r14d,DWORD PTR [r12+0x70]
    7c33ec900996:	mov    ecx,r14d
    7c33ec900999:	mov    r15d,r13d
    7c33ec90099c:	or     r15,rcx
    7c33ec90099f:	mov    r15d,r15d
    7c33ec9009a2:	mov    QWORD PTR [r12+0x98],r15
    7c33ec9009aa:	mov    r13d,0x0
    7c33ec9009b0:	mov    r14d,DWORD PTR [r12+0x68]
    7c33ec9009b5:	mov    ecx,r14d
    7c33ec9009b8:	mov    r15d,r13d
    7c33ec9009bb:	or     r15,rcx
    7c33ec9009be:	mov    r15d,r15d
    7c33ec9009c1:	mov    QWORD PTR [r12+0x28],r15
    7c33ec9009c6:	mov    r13d,0x0
    7c33ec9009cc:	mov    r14d,DWORD PTR [r12+0x60]
    7c33ec9009d1:	mov    ecx,r14d
    7c33ec9009d4:	mov    r15d,r13d
    7c33ec9009d7:	or     r15,rcx
    7c33ec9009da:	mov    r15d,r15d
    7c33ec9009dd:	mov    QWORD PTR [r12+0xb0],r15
    7c33ec9009e5:	mov    r13d,0x0
    7c33ec9009eb:	mov    r14d,DWORD PTR [r12+0x58]
    7c33ec9009f0:	mov    ecx,r14d
    7c33ec9009f3:	mov    r15d,r13d
    7c33ec9009f6:	or     r15,rcx
    7c33ec9009f9:	mov    r15d,r15d
    7c33ec9009fc:	mov    QWORD PTR [r12+0xc0],r15
    7c33ec900a04:	mov    r13d,0x0
    7c33ec900a0a:	mov    r14d,DWORD PTR [r12+0x90]
    7c33ec900a12:	mov    ecx,r14d
    7c33ec900a15:	mov    r15d,r13d
    7c33ec900a18:	or     r15,rcx
    7c33ec900a1b:	mov    r15d,r15d
    7c33ec900a1e:	mov    QWORD PTR [r12+0xc8],r15
    7c33ec900a26:	mov    r13d,0x0
    7c33ec900a2c:	mov    r14d,DWORD PTR [r12+0x18]
    7c33ec900a31:	mov    ecx,r14d
    7c33ec900a34:	mov    r15d,r13d
    7c33ec900a37:	or     r15,rcx
    7c33ec900a3a:	mov    r15d,r15d
    7c33ec900a3d:	mov    QWORD PTR [r12+0xb8],r15
    7c33ec900a45:	jmp    0x7c33ec900a4a
    7c33ec900a4a:	mov    r13d,0x0
    7c33ec900a50:	mov    r14d,DWORD PTR [r12+0xb8]
    7c33ec900a58:	mov    ecx,r14d
    7c33ec900a5b:	mov    r15d,r13d
    7c33ec900a5e:	or     r15,rcx
    7c33ec900a61:	mov    r15d,r15d
    7c33ec900a64:	mov    QWORD PTR [r12+0x30],r15
    7c33ec900a69:	mov    r13d,0x0
    7c33ec900a6f:	mov    r14d,DWORD PTR [r12+0xc0]
    7c33ec900a77:	mov    ecx,r14d
    7c33ec900a7a:	mov    r15d,r13d
    7c33ec900a7d:	or     r15,rcx
    7c33ec900a80:	mov    r15d,r15d
    7c33ec900a83:	mov    QWORD PTR [r12+0xa0],r15
    7c33ec900a8b:	mov    r13d,0x0
    7c33ec900a91:	mov    r14d,DWORD PTR [r12+0x28]
    7c33ec900a96:	mov    ecx,r14d
    7c33ec900a99:	mov    r15d,r13d
    7c33ec900a9c:	or     r15,rcx
    7c33ec900a9f:	mov    r15d,r15d
    7c33ec900aa2:	mov    QWORD PTR [r12+0xc0],r15
    7c33ec900aaa:	mov    r13d,0x0
    7c33ec900ab0:	mov    r14d,DWORD PTR [r12+0x98]
    7c33ec900ab8:	mov    ecx,r14d
    7c33ec900abb:	mov    r15d,r13d
    7c33ec900abe:	or     r15,rcx
    7c33ec900ac1:	mov    r15d,r15d
    7c33ec900ac4:	mov    QWORD PTR [r12+0x28],r15
    7c33ec900ac9:	mov    r13d,0x0
    7c33ec900acf:	mov    r14d,DWORD PTR [r12+0x38]
    7c33ec900ad4:	mov    ecx,r14d
    7c33ec900ad7:	mov    r15d,r13d
    7c33ec900ada:	or     r15,rcx
    7c33ec900add:	mov    r15d,r15d
    7c33ec900ae0:	mov    QWORD PTR [r12+0x98],r15
    7c33ec900ae8:	mov    r13d,0x0
    7c33ec900aee:	mov    r14d,DWORD PTR [r12+0xa8]
    7c33ec900af6:	mov    ecx,r14d
    7c33ec900af9:	mov    r15d,r13d
    7c33ec900afc:	or     r15,rcx
    7c33ec900aff:	mov    r15d,r15d
    7c33ec900b02:	mov    QWORD PTR [r12+0x38],r15
    7c33ec900b07:	mov    r13d,DWORD PTR [r12+0xb8]
    7c33ec900b0f:	mov    r13d,r13d
    7c33ec900b12:	ror    r13d,0x6
    7c33ec900b16:	mov    QWORD PTR [r12+0xb8],r13
    7c33ec900b1e:	mov    r13d,DWORD PTR [r12+0x30]
    7c33ec900b23:	mov    r14d,DWORD PTR [r12+0xc8]
    7c33ec900b2b:	mov    ecx,r14d
    7c33ec900b2e:	and    r13,rcx
    7c33ec900b31:	mov    r13d,r13d
    7c33ec900b34:	mov    QWORD PTR [r12+0xa8],r13
    7c33ec900b3c:	mov    r15d,r15d
    7c33ec900b3f:	ror    r15d,0x2
    7c33ec900b43:	mov    QWORD PTR [r12+0xd0],r15
    7c33ec900b4b:	mov    r13d,0x0
    7c33ec900b51:	mov    ecx,r14d
    7c33ec900b54:	mov    r15d,r13d
    7c33ec900b57:	or     r15,rcx
    7c33ec900b5a:	mov    r15d,r15d
    7c33ec900b5d:	mov    QWORD PTR [r12+0x20],r15
    7c33ec900b62:	mov    r13,QWORD PTR [r12+0x88]
    7c33ec900b6a:	mov    r14,QWORD PTR [r12+0x50]
    7c33ec900b6f:	mov    rcx,r13
    7c33ec900b72:	add    r14,rcx
    7c33ec900b75:	mov    r13d,DWORD PTR [r14]
    7c33ec900b78:	mov    QWORD PTR [r12+0xc8],r13
    7c33ec900b80:	mov    r13d,DWORD PTR [r12+0xa0]
    7c33ec900b88:	mov    r14d,DWORD PTR [r12+0x30]
    7c33ec900b8d:	mov    ecx,r14d
    7c33ec900b90:	not    rcx
    7c33ec900b93:	and    r13,rcx
    7c33ec900b96:	mov    r13d,r13d
    7c33ec900b99:	mov    QWORD PTR [r12+0xd8],r13
    7c33ec900ba1:	mov    r13d,DWORD PTR [r12+0xb0]
    7c33ec900ba9:	mov    r15d,DWORD PTR [r12+0xa8]
    7c33ec900bb1:	mov    ecx,r13d
    7c33ec900bb4:	add    r15d,ecx
    7c33ec900bb7:	mov    QWORD PTR [r12+0xa8],r15
    7c33ec900bbf:	mov    r13d,DWORD PTR [r12+0xb8]
    7c33ec900bc7:	mov    ebp,r14d
    7c33ec900bca:	mov    ebp,ebp
    7c33ec900bcc:	shr    ebp,0xb
    7c33ec900bcf:	mov    r14d,r14d
    7c33ec900bd2:	shl    r14d,0x15
    7c33ec900bd6:	mov    ecx,r14d
    7c33ec900bd9:	or     rbp,rcx
    7c33ec900bdc:	mov    ebp,ebp
    7c33ec900bde:	mov    ecx,ebp
    7c33ec900be0:	xor    r13,rcx
    7c33ec900be3:	mov    r13d,r13d
    7c33ec900be6:	mov    QWORD PTR [r12+0xb0],r13
    7c33ec900bee:	mov    r13d,DWORD PTR [r12+0xd0]
    7c33ec900bf6:	mov    r14d,DWORD PTR [r12+0x38]
    7c33ec900bfb:	mov    ebp,r14d
    7c33ec900bfe:	mov    ebp,ebp
    7c33ec900c00:	shr    ebp,0xd
    7c33ec900c03:	mov    r14d,r14d
    7c33ec900c06:	shl    r14d,0x13
    7c33ec900c0a:	mov    ecx,r14d
    7c33ec900c0d:	or     rbp,rcx
    7c33ec900c10:	mov    ebp,ebp
    7c33ec900c12:	mov    ecx,ebp
    7c33ec900c14:	xor    r13,rcx
    7c33ec900c17:	mov    r13d,r13d
    7c33ec900c1a:	mov    QWORD PTR [r12+0xd0],r13
    7c33ec900c22:	mov    r13d,DWORD PTR [r12+0xd8]
    7c33ec900c2a:	mov    ecx,r13d
    7c33ec900c2d:	add    r15d,ecx
    7c33ec900c30:	mov    QWORD PTR [r12+0xa8],r15
    7c33ec900c38:	mov    r13,QWORD PTR [r12+0x88]
    7c33ec900c40:	mov    r14,QWORD PTR [r12+0x48]
    7c33ec900c45:	mov    rcx,r13
    7c33ec900c48:	add    r14,rcx
    7c33ec900c4b:	mov    r13d,DWORD PTR [r14]
    7c33ec900c4e:	mov    QWORD PTR [r12+0xb8],r13
    7c33ec900c56:	mov    r13d,DWORD PTR [r12+0x28]
    7c33ec900c5b:	mov    r14d,DWORD PTR [r12+0x98]
    7c33ec900c63:	mov    ecx,r14d
    7c33ec900c66:	mov    ebp,r13d
    7c33ec900c69:	and    rbp,rcx
    7c33ec900c6c:	mov    ebp,ebp
    7c33ec900c6e:	mov    QWORD PTR [r12+0xd8],rbp
    7c33ec900c76:	mov    ebp,DWORD PTR [r12+0xc8]
    7c33ec900c7e:	mov    ecx,ebp
    7c33ec900c80:	add    r15d,ecx
    7c33ec900c83:	mov    QWORD PTR [r12+0xa8],r15
    7c33ec900c8b:	mov    ecx,r14d
    7c33ec900c8e:	xor    r13,rcx
    7c33ec900c91:	mov    r13d,r13d
    7c33ec900c94:	mov    QWORD PTR [r12+0xc8],r13
    7c33ec900c9c:	mov    r14d,DWORD PTR [r12+0xb0]
    7c33ec900ca4:	mov    r15d,DWORD PTR [r12+0x30]
    7c33ec900ca9:	mov    ebp,r15d
    7c33ec900cac:	mov    ebp,ebp
    7c33ec900cae:	shr    ebp,0x19
    7c33ec900cb1:	mov    r15d,r15d
    7c33ec900cb4:	shl    r15d,0x7
    7c33ec900cb8:	mov    ecx,r15d
    7c33ec900cbb:	or     rbp,rcx
    7c33ec900cbe:	mov    ebp,ebp
    7c33ec900cc0:	mov    ecx,ebp
    7c33ec900cc2:	xor    r14,rcx
    7c33ec900cc5:	mov    r14d,r14d
    7c33ec900cc8:	mov    QWORD PTR [r12+0xb0],r14
    7c33ec900cd0:	mov    r14d,DWORD PTR [r12+0x38]
    7c33ec900cd5:	mov    ecx,r14d
    7c33ec900cd8:	and    r13,rcx
    7c33ec900cdb:	mov    r13d,r13d
    7c33ec900cde:	mov    QWORD PTR [r12+0xc8],r13
    7c33ec900ce6:	mov    r15d,DWORD PTR [r12+0xd0]
    7c33ec900cee:	mov    ebp,r14d
    7c33ec900cf1:	mov    ebp,ebp
    7c33ec900cf3:	shr    ebp,0x16
    7c33ec900cf6:	mov    r14d,r14d
    7c33ec900cf9:	shl    r14d,0xa
    7c33ec900cfd:	mov    ecx,r14d
    7c33ec900d00:	or     rbp,rcx
    7c33ec900d03:	mov    ebp,ebp
    7c33ec900d05:	mov    ecx,ebp
    7c33ec900d07:	xor    r15,rcx
    7c33ec900d0a:	mov    r15d,r15d
    7c33ec900d0d:	mov    QWORD PTR [r12+0xd0],r15
    7c33ec900d15:	mov    r14d,DWORD PTR [r12+0xb8]
    7c33ec900d1d:	mov    r15d,DWORD PTR [r12+0xa8]
    7c33ec900d25:	mov    ecx,r14d
    7c33ec900d28:	add    r15d,ecx
    7c33ec900d2b:	mov    QWORD PTR [r12+0xa8],r15
    7c33ec900d33:	mov    r14d,DWORD PTR [r12+0xd8]
    7c33ec900d3b:	mov    ecx,r14d
    7c33ec900d3e:	xor    r13,rcx
    7c33ec900d41:	mov    r13d,r13d
    7c33ec900d44:	mov    QWORD PTR [r12+0xb8],r13
    7c33ec900d4c:	mov    r14d,DWORD PTR [r12+0xb0]
    7c33ec900d54:	mov    ecx,r14d
    7c33ec900d57:	add    r15d,ecx
    7c33ec900d5a:	mov    QWORD PTR [r12+0xa8],r15
    7c33ec900d62:	mov    r14,QWORD PTR [r12+0x88]
    7c33ec900d6a:	add    r14,0x4
    7c33ec900d6e:	mov    QWORD PTR [r12+0x88],r14
    7c33ec900d76:	mov    ebp,DWORD PTR [r12+0xd0]
    7c33ec900d7e:	mov    ecx,ebp
    7c33ec900d80:	add    r13d,ecx
    7c33ec900d83:	mov    QWORD PTR [r12+0xb0],r13
    7c33ec900d8b:	mov    ebp,DWORD PTR [r12+0xc0]
    7c33ec900d93:	mov    ecx,ebp
    7c33ec900d95:	mov    r8d,r15d
    7c33ec900d98:	add    r8d,ecx
    7c33ec900d9b:	mov    QWORD PTR [r12+0xb8],r8
    7c33ec900da3:	sub    r14,0x100
    7c33ec900daa:	pushf
    7c33ec900dab:	pop    r11
    7c33ec900dad:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec900db2:	mov    ecx,r15d
    7c33ec900db5:	add    r13d,ecx
    7c33ec900db8:	mov    QWORD PTR [r12+0xa8],r13
    7c33ec900dc0:	mov    r13d,0x0
    7c33ec900dc6:	mov    r14d,DWORD PTR [r12+0xa0]
    7c33ec900dce:	mov    ecx,r14d
    7c33ec900dd1:	mov    r15d,r13d
    7c33ec900dd4:	or     r15,rcx
    7c33ec900dd7:	mov    r15d,r15d
    7c33ec900dda:	mov    QWORD PTR [r12+0xb0],r15
    7c33ec900de2:	mov    r13d,0x0
    7c33ec900de8:	mov    r14d,DWORD PTR [r12+0x20]
    7c33ec900ded:	mov    ecx,r14d
    7c33ec900df0:	mov    r15d,r13d
    7c33ec900df3:	or     r15,rcx
    7c33ec900df6:	mov    r15d,r15d
    7c33ec900df9:	mov    QWORD PTR [r12+0xc0],r15
    7c33ec900e01:	mov    r13d,0x0
    7c33ec900e07:	mov    r14d,DWORD PTR [r12+0x30]
    7c33ec900e0c:	mov    ecx,r14d
    7c33ec900e0f:	mov    r15d,r13d
    7c33ec900e12:	or     r15,rcx
    7c33ec900e15:	mov    r15d,r15d
    7c33ec900e18:	mov    QWORD PTR [r12+0xc8],r15
    7c33ec900e20:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec900e28:	jrcxz  0x7c33ec900e2f
    7c33ec900e2a:	jmp    0x7c33ec901295
    7c33ec900e2f:	push   QWORD PTR [rsp+0x48]
    7c33ec900e33:	popf
    7c33ec900e34:	jne    0x7c33ec900a4a
    7c33ec900e3a:	jmp    0x7c33ec900e3f
    7c33ec900e3f:	mov    r13d,DWORD PTR [r12+0x70]
    7c33ec900e44:	mov    r14d,DWORD PTR [r12+0x98]
    7c33ec900e4c:	mov    ecx,r13d
    7c33ec900e4f:	add    r14d,ecx
    7c33ec900e52:	mov    QWORD PTR [r12+0x70],r14
    7c33ec900e57:	mov    r13d,DWORD PTR [r12+0x68]
    7c33ec900e5c:	mov    r14d,DWORD PTR [r12+0x28]
    7c33ec900e61:	mov    ecx,r13d
    7c33ec900e64:	add    r14d,ecx
    7c33ec900e67:	mov    QWORD PTR [r12+0x68],r14
    7c33ec900e6c:	mov    r13d,0x0
    7c33ec900e72:	mov    QWORD PTR [r12+0x88],r13
    7c33ec900e7a:	mov    r13d,DWORD PTR [r12+0x78]
    7c33ec900e7f:	mov    r14d,DWORD PTR [r12+0xa8]
    7c33ec900e87:	mov    ecx,r13d
    7c33ec900e8a:	add    r14d,ecx
    7c33ec900e8d:	mov    QWORD PTR [r12+0x78],r14
    7c33ec900e92:	mov    r13d,DWORD PTR [r12+0x80]
    7c33ec900e9a:	mov    r14d,DWORD PTR [r12+0x38]
    7c33ec900e9f:	mov    ecx,r13d
    7c33ec900ea2:	add    r14d,ecx
    7c33ec900ea5:	mov    QWORD PTR [r12+0x80],r14
    7c33ec900ead:	mov    r13,QWORD PTR [r12]
    7c33ec900eb1:	add    r13,0x8
    7c33ec900eb5:	mov    r14,r13
    7c33ec900eb8:	add    r14,0x4
    7c33ec900ebc:	mov    r15d,DWORD PTR [r12+0x70]
    7c33ec900ec1:	mov    ebp,DWORD PTR [r12+0x68]
    7c33ec900ec6:	mov    DWORD PTR [r13+0x0],r15d
    7c33ec900eca:	mov    r13d,0x0
    7c33ec900ed0:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec900ed8:	mov    DWORD PTR [r14],ebp
    7c33ec900edb:	mov    r13d,0x0
    7c33ec900ee1:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec900ee9:	mov    r13d,DWORD PTR [r12+0x18]
    7c33ec900eee:	mov    r14d,DWORD PTR [r12+0xb8]
    7c33ec900ef6:	mov    ecx,r13d
    7c33ec900ef9:	add    r14d,ecx
    7c33ec900efc:	mov    QWORD PTR [r12+0x68],r14
    7c33ec900f01:	mov    r13d,DWORD PTR [r12+0x90]
    7c33ec900f09:	mov    r14d,DWORD PTR [r12+0x30]
    7c33ec900f0e:	mov    ecx,r13d
    7c33ec900f11:	add    r14d,ecx
    7c33ec900f14:	mov    QWORD PTR [r12+0x70],r14
    7c33ec900f19:	mov    r13d,DWORD PTR [r12+0x58]
    7c33ec900f1e:	mov    r14d,DWORD PTR [r12+0x20]
    7c33ec900f23:	mov    ecx,r13d
    7c33ec900f26:	add    r14d,ecx
    7c33ec900f29:	mov    QWORD PTR [r12+0x58],r14
    7c33ec900f2e:	mov    r13d,DWORD PTR [r12+0x60]
    7c33ec900f33:	mov    r14d,DWORD PTR [r12+0xa0]
    7c33ec900f3b:	mov    ecx,r13d
    7c33ec900f3e:	add    r14d,ecx
    7c33ec900f41:	mov    QWORD PTR [r12+0x60],r14
    7c33ec900f46:	mov    r13,QWORD PTR [r12]
    7c33ec900f4a:	mov    r15,r13
    7c33ec900f4d:	add    r15,0x4
    7c33ec900f51:	mov    ebp,DWORD PTR [r12+0x78]
    7c33ec900f56:	mov    r8d,DWORD PTR [r12+0x80]
    7c33ec900f5e:	mov    DWORD PTR [r13+0x0],ebp
    7c33ec900f62:	mov    ebp,0x0
    7c33ec900f67:	mov    DWORD PTR [r12+0x32c],ebp
    7c33ec900f6f:	mov    DWORD PTR [r15],r8d
    7c33ec900f72:	mov    r15d,0x0
    7c33ec900f78:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec900f80:	mov    r15,r13
    7c33ec900f83:	add    r15,0x10
    7c33ec900f87:	mov    rbp,r15
    7c33ec900f8a:	add    rbp,0x4
    7c33ec900f8e:	mov    r8d,DWORD PTR [r12+0x68]
    7c33ec900f93:	mov    r9d,DWORD PTR [r12+0x70]
    7c33ec900f98:	mov    DWORD PTR [r15],r8d
    7c33ec900f9b:	mov    r15d,0x0
    7c33ec900fa1:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec900fa9:	mov    DWORD PTR [rbp+0x0],r9d
    7c33ec900fad:	mov    r15d,0x0
    7c33ec900fb3:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec900fbb:	mov    r15,r13
    7c33ec900fbe:	add    r15,0x18
    7c33ec900fc2:	mov    rbp,r15
    7c33ec900fc5:	add    rbp,0x4
    7c33ec900fc9:	mov    r8d,DWORD PTR [r12+0x58]
    7c33ec900fce:	mov    DWORD PTR [r15],r8d
    7c33ec900fd1:	mov    r15d,0x0
    7c33ec900fd7:	mov    DWORD PTR [r12+0x32c],r15d
    7c33ec900fdf:	mov    DWORD PTR [rbp+0x0],r14d
    7c33ec900fe3:	mov    r14d,0x0
    7c33ec900fe9:	mov    DWORD PTR [r12+0x32c],r14d
    7c33ec900ff1:	add    r13,0x68
    7c33ec900ff5:	mov    r14d,0x0
    7c33ec900ffb:	mov    QWORD PTR [r13+0x0],r14
    7c33ec900fff:	mov    r13d,0x0
    7c33ec901005:	mov    DWORD PTR [r12+0x32c],r13d
    7c33ec90100d:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec901015:	jrcxz  0x7c33ec90101c
    7c33ec901017:	jmp    0x7c33ec90131c
    7c33ec90101c:	jmp    0x7c33ec901021
    7c33ec901021:	mov    r13,QWORD PTR [r12+0x10]
    7c33ec901026:	sub    r13,0x1
    7c33ec90102a:	mov    QWORD PTR [r12+0x10],r13
    7c33ec90102f:	mov    rax,r13
    7c33ec901032:	test   rax,rax
    7c33ec901035:	sete   al
    7c33ec901038:	movzx  eax,al
    7c33ec90103b:	and    eax,0x1
    7c33ec90103e:	mov    r14,rax
    7c33ec901041:	mov    rax,r14
    7c33ec901044:	and    eax,0x1
    7c33ec901047:	test   rax,rax
    7c33ec90104a:	jne    0x7c33ec901055
    7c33ec901050:	jmp    0x7c33ec8feb77
    7c33ec901055:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec90105d:	mov    r14,r13
    7c33ec901060:	add    r14,0x140
    7c33ec901067:	mov    r15,r14
    7c33ec90106a:	add    r15,0x8
    7c33ec90106e:	mov    rbp,QWORD PTR [r14]
    7c33ec901071:	mov    r14,QWORD PTR [r15]
    7c33ec901074:	mov    QWORD PTR [r12+0xa0],rbp
    7c33ec90107c:	mov    QWORD PTR [r12+0x98],r14
    7c33ec901084:	mov    r14,r13
    7c33ec901087:	add    r14,0x130
    7c33ec90108e:	mov    r15,r14
    7c33ec901091:	add    r15,0x8
    7c33ec901095:	mov    rbp,QWORD PTR [r14]
    7c33ec901098:	mov    r14,QWORD PTR [r15]
    7c33ec90109b:	mov    QWORD PTR [r12+0xb0],rbp
    7c33ec9010a3:	mov    QWORD PTR [r12+0xa8],r14
    7c33ec9010ab:	mov    r14,r13
    7c33ec9010ae:	add    r14,0x120
    7c33ec9010b5:	mov    r15,r14
    7c33ec9010b8:	add    r15,0x8
    7c33ec9010bc:	mov    rbp,QWORD PTR [r14]
    7c33ec9010bf:	mov    r14,QWORD PTR [r15]
    7c33ec9010c2:	mov    QWORD PTR [r12+0xc0],rbp
    7c33ec9010ca:	mov    QWORD PTR [r12+0xb8],r14
    7c33ec9010d2:	add    r13,0x110
    7c33ec9010d9:	mov    r14,r13
    7c33ec9010dc:	add    r14,0x8
    7c33ec9010e0:	mov    r15,QWORD PTR [r13+0x0]
    7c33ec9010e4:	mov    r13,QWORD PTR [r14]
    7c33ec9010e7:	mov    QWORD PTR [r12+0xd0],r15
    7c33ec9010ef:	mov    QWORD PTR [r12+0xc8],r13
    7c33ec9010f7:	mov    r13,QWORD PTR [r12+0xf8]
    7c33ec9010ff:	mov    r14,r13
    7c33ec901102:	add    r14,0x100
    7c33ec901109:	mov    r15,r14
    7c33ec90110c:	add    r15,0x8
    7c33ec901110:	mov    rbp,QWORD PTR [r14]
    7c33ec901113:	mov    r14,QWORD PTR [r15]
    7c33ec901116:	mov    QWORD PTR [r12+0xe8],rbp
    7c33ec90111e:	mov    QWORD PTR [r12+0xd8],r14
    7c33ec901126:	add    r13,0x150
    7c33ec90112d:	mov    QWORD PTR [r12+0xf8],r13
    7c33ec901135:	jmp    0x7c33ec90113a
    7c33ec90113a:	mov    rcx,QWORD PTR [r12+0x380]
    7c33ec901142:	jrcxz  0x7c33ec901149
    7c33ec901144:	jmp    0x7c33ec9013a3
    7c33ec901149:	mov    r13,QWORD PTR [r12+0xf0]
    7c33ec901151:	mov    QWORD PTR [r12+0x100],r13
    7c33ec901159:	mov    r11,QWORD PTR [rsp+0x48]
    7c33ec90115e:	mov    QWORD PTR [r12+0x398],r11
    7c33ec901166:	mov    rdi,QWORD PTR [r12+0x100]
    7c33ec90116e:	add    rsp,0x50
    7c33ec901172:	movabs r11,0x5585303950a0
    7c33ec90117c:	jmp    r11
    7c33ec90117f:	mov    eax,0x41078c
    7c33ec901184:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90118c:	push   rdx
    7c33ec90118d:	push   rsi
    7c33ec90118e:	push   r10
    7c33ec901190:	push   r11
    7c33ec901192:	pushf
    7c33ec901193:	pop    r11
    7c33ec901195:	mov    QWORD PTR [rsp+0x68],r11
    7c33ec90119a:	mov    rdx,QWORD PTR [rsp+0x68]
    7c33ec90119f:	mov    r10d,edx
    7c33ec9011a2:	and    r10d,0xc0
    7c33ec9011a9:	shl    r10d,0x18
    7c33ec9011ad:	mov    r11d,edx
    7c33ec9011b0:	and    r11d,0x1
    7c33ec9011b4:	shl    r11d,0x1d
    7c33ec9011b8:	or     r10d,r11d
    7c33ec9011bb:	mov    r11d,edx
    7c33ec9011be:	and    r11d,0x800
    7c33ec9011c5:	shl    r11d,0x11
    7c33ec9011c9:	or     r10d,r11d
    7c33ec9011cc:	btc    r10,0x1d
    7c33ec9011d1:	mov    r11d,0xf0000000
    7c33ec9011d7:	and    r11,r10
    7c33ec9011da:	movabs rsi,0xffffffff0fffffff
    7c33ec9011e4:	and    rbx,rsi
    7c33ec9011e7:	or     rbx,r11
    7c33ec9011ea:	pop    r11
    7c33ec9011ec:	pop    r10
    7c33ec9011ee:	pop    rsi
    7c33ec9011ef:	pop    rdx
    7c33ec9011f0:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec9011f8:	add    rsp,0x50
    7c33ec9011fc:	mov    eax,0xc
    7c33ec901201:	movabs r11,0x558530395390
    7c33ec90120b:	jmp    r11
    7c33ec90120e:	mov    eax,0x410888
    7c33ec901213:	mov    QWORD PTR [r12+0x100],rax
    7c33ec90121b:	push   rdx
    7c33ec90121c:	push   rsi
    7c33ec90121d:	push   r10
    7c33ec90121f:	push   r11
    7c33ec901221:	mov    rdx,QWORD PTR [rsp+0x68]
    7c33ec901226:	mov    r10d,edx
    7c33ec901229:	and    r10d,0xc0
    7c33ec901230:	shl    r10d,0x18
    7c33ec901234:	mov    r11d,edx
    7c33ec901237:	and    r11d,0x1
    7c33ec90123b:	shl    r11d,0x1d
    7c33ec90123f:	or     r10d,r11d
    7c33ec901242:	mov    r11d,edx
    7c33ec901245:	and    r11d,0x800
    7c33ec90124c:	shl    r11d,0x11
    7c33ec901250:	or     r10d,r11d
    7c33ec901253:	btc    r10,0x1d
    7c33ec901258:	mov    r11d,0xf0000000
    7c33ec90125e:	and    r11,r10
    7c33ec901261:	movabs rsi,0xffffffff0fffffff
    7c33ec90126b:	and    rbx,rsi
    7c33ec90126e:	or     rbx,r11
    7c33ec901271:	pop    r11
    7c33ec901273:	pop    r10
    7c33ec901275:	pop    rsi
    7c33ec901276:	pop    rdx
    7c33ec901277:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90127f:	add    rsp,0x50
    7c33ec901283:	mov    eax,0xc
    7c33ec901288:	movabs r11,0x558530395390
    7c33ec901292:	jmp    r11
    7c33ec901295:	mov    eax,0x410948
    7c33ec90129a:	mov    QWORD PTR [r12+0x100],rax
    7c33ec9012a2:	push   rdx
    7c33ec9012a3:	push   rsi
    7c33ec9012a4:	push   r10
    7c33ec9012a6:	push   r11
    7c33ec9012a8:	mov    rdx,QWORD PTR [rsp+0x68]
    7c33ec9012ad:	mov    r10d,edx
    7c33ec9012b0:	and    r10d,0xc0
    7c33ec9012b7:	shl    r10d,0x18
    7c33ec9012bb:	mov    r11d,edx
    7c33ec9012be:	and    r11d,0x1
    7c33ec9012c2:	shl    r11d,0x1d
    7c33ec9012c6:	or     r10d,r11d
    7c33ec9012c9:	mov    r11d,edx
    7c33ec9012cc:	and    r11d,0x800
    7c33ec9012d3:	shl    r11d,0x11
    7c33ec9012d7:	or     r10d,r11d
    7c33ec9012da:	btc    r10,0x1d
    7c33ec9012df:	mov    r11d,0xf0000000
    7c33ec9012e5:	and    r11,r10
    7c33ec9012e8:	movabs rsi,0xffffffff0fffffff
    7c33ec9012f2:	and    rbx,rsi
    7c33ec9012f5:	or     rbx,r11
    7c33ec9012f8:	pop    r11
    7c33ec9012fa:	pop    r10
    7c33ec9012fc:	pop    rsi
    7c33ec9012fd:	pop    rdx
    7c33ec9012fe:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec901306:	add    rsp,0x50
    7c33ec90130a:	mov    eax,0xc
    7c33ec90130f:	movabs r11,0x558530395390
    7c33ec901319:	jmp    r11
    7c33ec90131c:	mov    eax,0x410984
    7c33ec901321:	mov    QWORD PTR [r12+0x100],rax
    7c33ec901329:	push   rdx
    7c33ec90132a:	push   rsi
    7c33ec90132b:	push   r10
    7c33ec90132d:	push   r11
    7c33ec90132f:	mov    rdx,QWORD PTR [rsp+0x68]
    7c33ec901334:	mov    r10d,edx
    7c33ec901337:	and    r10d,0xc0
    7c33ec90133e:	shl    r10d,0x18
    7c33ec901342:	mov    r11d,edx
    7c33ec901345:	and    r11d,0x1
    7c33ec901349:	shl    r11d,0x1d
    7c33ec90134d:	or     r10d,r11d
    7c33ec901350:	mov    r11d,edx
    7c33ec901353:	and    r11d,0x800
    7c33ec90135a:	shl    r11d,0x11
    7c33ec90135e:	or     r10d,r11d
    7c33ec901361:	btc    r10,0x1d
    7c33ec901366:	mov    r11d,0xf0000000
    7c33ec90136c:	and    r11,r10
    7c33ec90136f:	movabs rsi,0xffffffff0fffffff
    7c33ec901379:	and    rbx,rsi
    7c33ec90137c:	or     rbx,r11
    7c33ec90137f:	pop    r11
    7c33ec901381:	pop    r10
    7c33ec901383:	pop    rsi
    7c33ec901384:	pop    rdx
    7c33ec901385:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec90138d:	add    rsp,0x50
    7c33ec901391:	mov    eax,0xc
    7c33ec901396:	movabs r11,0x558530395390
    7c33ec9013a0:	jmp    r11
    7c33ec9013a3:	mov    eax,0x4109a0
    7c33ec9013a8:	mov    QWORD PTR [r12+0x100],rax
    7c33ec9013b0:	push   rdx
    7c33ec9013b1:	push   rsi
    7c33ec9013b2:	push   r10
    7c33ec9013b4:	push   r11
    7c33ec9013b6:	mov    rdx,QWORD PTR [rsp+0x68]
    7c33ec9013bb:	mov    r10d,edx
    7c33ec9013be:	and    r10d,0xc0
    7c33ec9013c5:	shl    r10d,0x18
    7c33ec9013c9:	mov    r11d,edx
    7c33ec9013cc:	and    r11d,0x1
    7c33ec9013d0:	shl    r11d,0x1d
    7c33ec9013d4:	or     r10d,r11d
    7c33ec9013d7:	mov    r11d,edx
    7c33ec9013da:	and    r11d,0x800
    7c33ec9013e1:	shl    r11d,0x11
    7c33ec9013e5:	or     r10d,r11d
    7c33ec9013e8:	btc    r10,0x1d
    7c33ec9013ed:	mov    r11d,0xf0000000
    7c33ec9013f3:	and    r11,r10
    7c33ec9013f6:	movabs rsi,0xffffffff0fffffff
    7c33ec901400:	and    rbx,rsi
    7c33ec901403:	or     rbx,r11
    7c33ec901406:	pop    r11
    7c33ec901408:	pop    r10
    7c33ec90140a:	pop    rsi
    7c33ec90140b:	pop    rdx
    7c33ec90140c:	mov    QWORD PTR [r12+0x108],rbx
    7c33ec901414:	add    rsp,0x50
    7c33ec901418:	mov    eax,0xc
    7c33ec90141d:	movabs r11,0x558530395390
    7c33ec901427:	jmp    r11
    7c33ec90142a:	nop    WORD PTR [rax+rax*1+0x0]
    7c33ec901430:	sub    rsp,0x50
    7c33ec901434:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90143c:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec901441:	jmp    0x7c33ec8fe9cb
    7c33ec901446:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec901450:	sub    rsp,0x50
    7c33ec901454:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90145c:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec901461:	jmp    0x7c33ec8feb77
    7c33ec901466:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec901470:	sub    rsp,0x50
    7c33ec901474:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90147c:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec901481:	jmp    0x7c33ec8fec21
    7c33ec901486:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec901490:	sub    rsp,0x50
    7c33ec901494:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90149c:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec9014a1:	jmp    0x7c33ec90073c
    7c33ec9014a6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec9014b0:	sub    rsp,0x50
    7c33ec9014b4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec9014bc:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec9014c1:	jmp    0x7c33ec9008c5
    7c33ec9014c6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec9014d0:	sub    rsp,0x50
    7c33ec9014d4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec9014dc:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec9014e1:	jmp    0x7c33ec900a4a
    7c33ec9014e6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec9014f0:	sub    rsp,0x50
    7c33ec9014f4:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec9014fc:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec901501:	jmp    0x7c33ec900e3f
    7c33ec901506:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec901510:	sub    rsp,0x50
    7c33ec901514:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90151c:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec901521:	jmp    0x7c33ec901021
    7c33ec901526:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec901530:	sub    rsp,0x50
    7c33ec901534:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90153c:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec901541:	jmp    0x7c33ec901055
    7c33ec901546:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c33ec901550:	sub    rsp,0x50
    7c33ec901554:	mov    r11,QWORD PTR [r12+0x398]
    7c33ec90155c:	mov    QWORD PTR [rsp+0x48],r11
    7c33ec901561:	jmp    0x7c33ec90113a
    7c33ec901566:	nop
    7c33ec901567:	nop
