000076bac53ce69b  nop [rax+rax*1], eax
000076bac53ce6a0  mov rax, [r15+0xF8]
000076bac53ce6a7  lea r14, [rax-0x1E0]
000076bac53ce6ae  mov [r15+0xF8], r14
000076bac53ce6b5  lea rax, [r14+0x1D0]
000076bac53ce6bc  mov r12, [r15+0xA0]
000076bac53ce6c3  mov r11, [r15+0x98]
000076bac53ce6ca  mov [r13+rax*1], r12
000076bac53ce6cf  lea rax, [r14+0x1D8]
000076bac53ce6d6  mov [r13+rax*1], r11
000076bac53ce6db  mov eax, 0x420AA0
000076bac53ce6e0  movups xmm1, [r13+rax*1]
000076bac53ce6e6  mov eax, 0x420A30
000076bac53ce6eb  movups xmm15, [r13+rax*1]
000076bac53ce6f1  mov eax, 0x420AC0
000076bac53ce6f6  movups xmm14, [r13+rax*1]
000076bac53ce6fc  mov eax, 0x420A60
000076bac53ce701  movups xmm13, [r13+rax*1]
000076bac53ce707  mov qword ptr [r15+0x98], 0x430CD0
000076bac53ce712  mov eax, 0x420AD0
000076bac53ce717  movups xmm12, [r13+rax*1]
000076bac53ce71d  mov eax, 0x430CD0
000076bac53ce722  movups [r13+rax*1], xmm1
000076bac53ce728  mov eax, 0x430CE0
000076bac53ce72d  movups [r13+rax*1], xmm15
000076bac53ce733  mov eax, 0x430CF0
000076bac53ce738  movups [r13+rax*1], xmm14
000076bac53ce73e  mov eax, 0x430D00
000076bac53ce743  movups [r13+rax*1], xmm13
000076bac53ce749  mov eax, 0x420A20
000076bac53ce74e  movups xmm14, [r13+rax*1]
000076bac53ce754  mov eax, 0x420A10
000076bac53ce759  movups xmm13, [r13+rax*1]
000076bac53ce75f  mov eax, 0x430DD0
000076bac53ce764  movups [r13+rax*1], xmm1
000076bac53ce76a  mov eax, 0x430DE0
000076bac53ce76f  movups [r13+rax*1], xmm15
000076bac53ce775  mov eax, 0x430D10
000076bac53ce77a  movups [r13+rax*1], xmm12
000076bac53ce780  mov eax, 0x430D20
000076bac53ce785  movups [r13+rax*1], xmm14
000076bac53ce78b  mov eax, 0x420A00
000076bac53ce790  movups xmm1, [r13+rax*1]
000076bac53ce796  mov eax, 0x420A70
000076bac53ce79b  movups xmm15, [r13+rax*1]
000076bac53ce7a1  mov eax, 0x430D30
000076bac53ce7a6  movups [r13+rax*1], xmm13
000076bac53ce7ac  mov eax, 0x430D40
000076bac53ce7b1  movups [r13+rax*1], xmm1
000076bac53ce7b7  mov eax, 0x420A80
000076bac53ce7bc  movups xmm1, [r13+rax*1]
000076bac53ce7c2  mov eax, 0x420A50
000076bac53ce7c7  movups xmm14, [r13+rax*1]
000076bac53ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000076bac53ce7d5  mov eax, 0x430D50
000076bac53ce7da  movups [r13+rax*1], xmm15
000076bac53ce7e0  mov eax, 0x430D60
000076bac53ce7e5  movups [r13+rax*1], xmm1
000076bac53ce7eb  mov eax, 0x420AF0
000076bac53ce7f0  movups xmm1, [r13+rax*1]
000076bac53ce7f6  mov eax, 0x420B00
000076bac53ce7fb  movups xmm15, [r13+rax*1]
000076bac53ce801  movaps [r15+0x150], xmm15
000076bac53ce809  mov qword ptr [r15+0xA0], 0x3E8
000076bac53ce814  mov eax, 0x430D70
000076bac53ce819  movups [r13+rax*1], xmm14
000076bac53ce81f  mov eax, 0x430D80
000076bac53ce824  movups [r13+rax*1], xmm1
000076bac53ce82a  mov eax, 0x420AE0
000076bac53ce82f  movups xmm1, [r13+rax*1]
000076bac53ce835  mov eax, 0x420A90
000076bac53ce83a  movups xmm14, [r13+rax*1]
000076bac53ce840  movaps [r15+0x140], xmm14
000076bac53ce848  lea rax, [r14+0x180]
000076bac53ce84f  movq xmm13, qword ptr [r15+0x200]
000076bac53ce858  movq xmm12, qword ptr [r15+0x1F0]
000076bac53ce861  movq r12, xmm13
000076bac53ce866  movq r11, xmm12
000076bac53ce86b  mov [r13+rax*1], r12
000076bac53ce870  lea rax, [r14+0x188]
000076bac53ce877  mov [r13+rax*1], r11
000076bac53ce87c  mov eax, 0x430D90
000076bac53ce881  movups [r13+rax*1], xmm15
000076bac53ce887  mov eax, 0x430DA0
000076bac53ce88c  movups [r13+rax*1], xmm1
000076bac53ce892  mov eax, 0x420AB0
000076bac53ce897  movups xmm1, [r13+rax*1]
000076bac53ce89d  mov eax, 0x420B18
000076bac53ce8a2  mov r12, [r13+rax*1]
000076bac53ce8a7  movq xmm15, r12
000076bac53ce8ac  mov qword ptr [r15+0x40], 0x420B20
000076bac53ce8b4  mov eax, 0x430DB0
000076bac53ce8b9  movups [r13+rax*1], xmm14
000076bac53ce8bf  mov eax, 0x430DC0
000076bac53ce8c4  movups [r13+rax*1], xmm1
000076bac53ce8ca  mov eax, 0x420B80
000076bac53ce8cf  movups xmm1, [r13+rax*1]
000076bac53ce8d5  movq rax, xmm15
000076bac53ce8da  mov r12d, 0x430DF0
000076bac53ce8e0  mov [r13+r12*1], rax
000076bac53ce8e5  mov eax, 0x420B60
000076bac53ce8ea  movups xmm15, [r13+rax*1]
000076bac53ce8f0  mov eax, 0x420B70
000076bac53ce8f5  movups xmm14, [r13+rax*1]
000076bac53ce8fb  lea rax, [r14+0x160]
000076bac53ce902  movups [r13+rax*1], xmm1
000076bac53ce908  lea rax, [r14+0x190]
000076bac53ce90f  movq xmm1, qword ptr [r15+0x1E0]
000076bac53ce918  movq xmm13, qword ptr [r15+0x1D0]
000076bac53ce921  movq r12, xmm1
000076bac53ce926  movq r11, xmm13
000076bac53ce92b  mov [r13+rax*1], r12
000076bac53ce930  lea rax, [r14+0x198]
000076bac53ce937  mov [r13+rax*1], r11
000076bac53ce93c  lea rax, [r14+0x140]
000076bac53ce943  movups [r13+rax*1], xmm15
000076bac53ce949  lea rax, [r14+0x150]
000076bac53ce950  movups [r13+rax*1], xmm14
000076bac53ce956  mov eax, 0x420B20
000076bac53ce95b  movups xmm1, [r13+rax*1]
000076bac53ce961  mov eax, 0x420B30
000076bac53ce966  movups xmm15, [r13+rax*1]
000076bac53ce96c  movaps [r15+0x120], xmm15
000076bac53ce974  lea rax, [r14+0x1A0]
000076bac53ce97b  movq xmm14, qword ptr [r15+0x1C0]
000076bac53ce984  movq xmm13, qword ptr [r15+0x1B0]
000076bac53ce98d  movq r12, xmm14
000076bac53ce992  movq r11, xmm13
000076bac53ce997  mov [r13+rax*1], r12
000076bac53ce99c  lea rax, [r14+0x1A8]
000076bac53ce9a3  mov [r13+rax*1], r11
000076bac53ce9a8  lea rax, [r14+0x1B0]
000076bac53ce9af  movq xmm14, qword ptr [r15+0x1A0]
000076bac53ce9b8  movq xmm13, qword ptr [r15+0x190]
000076bac53ce9c1  movq r12, xmm14
000076bac53ce9c6  movq r11, xmm13
000076bac53ce9cb  mov [r13+rax*1], r12
000076bac53ce9d0  lea rax, [r14+0x1B8]
000076bac53ce9d7  mov [r13+rax*1], r11
000076bac53ce9dc  lea rax, [r14+0x100]
000076bac53ce9e3  movups [r13+rax*1], xmm1
000076bac53ce9e9  lea rax, [r14+0x110]
000076bac53ce9f0  movups [r13+rax*1], xmm15
000076bac53ce9f6  mov eax, 0x420B40
000076bac53ce9fb  movups xmm1, [r13+rax*1]
000076bac53cea01  mov eax, 0x420B50
000076bac53cea06  movups xmm15, [r13+rax*1]
000076bac53cea0c  movaps [r15+0x110], xmm1
000076bac53cea14  movaps [r15+0x130], xmm15
000076bac53cea1c  lea rax, [r14+0x1C0]
000076bac53cea23  mov r12, [r15+0xE8]
000076bac53cea2a  mov r11, [r15+0xF0]
000076bac53cea31  mov [r13+rax*1], r12
000076bac53cea36  lea rax, [r14+0x1C8]
000076bac53cea3d  mov [r13+rax*1], r11
000076bac53cea42  mov eax, 0x430DF8
000076bac53cea47  mov r12d, 0x421DF8D3
000076bac53cea4d  mov [r13+rax*1], r12d
000076bac53cea52  lea rax, [r14+0x120]
000076bac53cea59  movups [r13+rax*1], xmm1
000076bac53cea5f  lea rax, [r14+0x130]
000076bac53cea66  movups [r13+rax*1], xmm15
000076bac53cea6c  lea rax, [r14+0x100]
000076bac53cea73  mov [r15], rax
000076bac53cea76  mov qword ptr [r15+0x08], 0x430CD0
000076bac53cea7e  mov qword ptr [r15+0x10], 0x12C
000076bac53cea86  mov qword ptr [r15+0xF0], 0x410284
000076bac53cea91  mov r14d, [r15+0x320]
000076bac53cea98  mov eax, 0x410284
000076bac53cea9d  mov rcx, 0x76BAC53D07C0
000076bac53ceaa7  mov [r15+r14*8+0x328], rax
000076bac53ceaaf  mov [r15+r14*8+0x368], rcx
000076bac53ceab7  add r14d, 0x01
000076bac53ceabb  and r14d, 0x07
000076bac53ceabf  mov [r15+0x320], r14d
000076bac53ceac6  cmp dword ptr [r15+0x318], 0x00
000076bac53ceace  jz 0x000076BAC53CED70
000076bac53cead4  nop [rax+rax*1], ax
000076bac53ceadd  nop [rax+rax*1], eax
000076bac53ceae5  mov eax, 0x410728
000076bac53ceaea  mov [r15+0x100], rax
000076bac53ceaf1  jmp 0x000076BAC51FE110
000076bac53ceaf6  int3
000076bac53ceaf7  call 0x000076BAC520BC20
000076bac53ceafc  jmp 0x000076BAC53CE6CF
000076bac53ceb01  call 0x000076BAC520A9A0
000076bac53ceb06  jmp 0x000076BAC53CE6DB
000076bac53ceb0b  call 0x000076BAC51FF430
000076bac53ceb10  jmp 0x000076BAC53CE6E6
000076bac53ceb15  call 0x000076BAC520E760
000076bac53ceb1a  jmp 0x000076BAC53CE6F1
000076bac53ceb1f  call 0x000076BAC520D4E0
000076bac53ceb24  jmp 0x000076BAC53CE6FC
000076bac53ceb29  call 0x000076BAC520C260
000076bac53ceb2e  jmp 0x000076BAC53CE707
000076bac53ceb33  call 0x000076BAC520AFE0
000076bac53ceb38  jmp 0x000076BAC53CE71D
000076bac53ceb3d  call 0x000076BAC51FF540
000076bac53ceb42  jmp 0x000076BAC53CE728
000076bac53ceb47  call 0x000076BAC520E880
000076bac53ceb4c  jmp 0x000076BAC53CE733
000076bac53ceb51  call 0x000076BAC520D600
000076bac53ceb56  jmp 0x000076BAC53CE73E
000076bac53ceb5b  call 0x000076BAC520C380
000076bac53ceb60  jmp 0x000076BAC53CE749
000076bac53ceb65  call 0x000076BAC520D4E0
000076bac53ceb6a  jmp 0x000076BAC53CE754
000076bac53ceb6f  call 0x000076BAC520C260
000076bac53ceb74  jmp 0x000076BAC53CE75F
000076bac53ceb79  call 0x000076BAC51FF540
000076bac53ceb7e  jmp 0x000076BAC53CE76A
000076bac53ceb83  call 0x000076BAC520E880
000076bac53ceb88  jmp 0x000076BAC53CE775
000076bac53ceb8d  call 0x000076BAC520B100
000076bac53ceb92  jmp 0x000076BAC53CE780
000076bac53ceb97  call 0x000076BAC520D600
000076bac53ceb9c  jmp 0x000076BAC53CE78B
000076bac53ceba1  call 0x000076BAC51FF430
000076bac53ceba6  jmp 0x000076BAC53CE796
000076bac53cebab  call 0x000076BAC520E760
000076bac53cebb0  jmp 0x000076BAC53CE7A1
000076bac53cebb5  call 0x000076BAC520C380
000076bac53cebba  jmp 0x000076BAC53CE7AC
000076bac53cebbf  call 0x000076BAC51FF540
000076bac53cebc4  jmp 0x000076BAC53CE7B7
000076bac53cebc9  call 0x000076BAC51FF430
000076bac53cebce  jmp 0x000076BAC53CE7C2
000076bac53cebd3  call 0x000076BAC520D4E0
000076bac53cebd8  jmp 0x000076BAC53CE7CD
000076bac53cebdd  call 0x000076BAC520E880
000076bac53cebe2  jmp 0x000076BAC53CE7E0
000076bac53cebe7  call 0x000076BAC51FF540
000076bac53cebec  jmp 0x000076BAC53CE7EB
000076bac53cebf1  call 0x000076BAC51FF430
000076bac53cebf6  jmp 0x000076BAC53CE7F6
000076bac53cebfb  call 0x000076BAC520E760
000076bac53cec00  jmp 0x000076BAC53CE801
000076bac53cec05  call 0x000076BAC520D600
000076bac53cec0a  jmp 0x000076BAC53CE81F
000076bac53cec0f  call 0x000076BAC51FF540
000076bac53cec14  jmp 0x000076BAC53CE82A
000076bac53cec19  call 0x000076BAC51FF430
000076bac53cec1e  jmp 0x000076BAC53CE835
000076bac53cec23  call 0x000076BAC520D4E0
000076bac53cec28  jmp 0x000076BAC53CE840
000076bac53cec2d  call 0x000076BAC520BC20
000076bac53cec32  jmp 0x000076BAC53CE870
000076bac53cec37  call 0x000076BAC520A9A0
000076bac53cec3c  jmp 0x000076BAC53CE87C
000076bac53cec41  call 0x000076BAC520E880
000076bac53cec46  jmp 0x000076BAC53CE887
000076bac53cec4b  call 0x000076BAC51FF540
000076bac53cec50  jmp 0x000076BAC53CE892
000076bac53cec55  call 0x000076BAC51FF430
000076bac53cec5a  jmp 0x000076BAC53CE89D
000076bac53cec5f  call 0x000076BAC520B720
000076bac53cec64  jmp 0x000076BAC53CE8A7
000076bac53cec69  call 0x000076BAC520D600
000076bac53cec6e  jmp 0x000076BAC53CE8BF
000076bac53cec73  call 0x000076BAC51FF540
000076bac53cec78  jmp 0x000076BAC53CE8CA
000076bac53cec7d  call 0x000076BAC51FF430
000076bac53cec82  jmp 0x000076BAC53CE8D5
000076bac53cec87  call 0x000076BAC52B4CB0
000076bac53cec8c  jmp 0x000076BAC53CE8E5
000076bac53cec91  call 0x000076BAC520E760
000076bac53cec96  jmp 0x000076BAC53CE8F0
000076bac53cec9b  call 0x000076BAC520D4E0
000076bac53ceca0  jmp 0x000076BAC53CE8FB
000076bac53ceca5  call 0x000076BAC51FF540
000076bac53cecaa  jmp 0x000076BAC53CE908
000076bac53cecaf  call 0x000076BAC520BC20
000076bac53cecb4  jmp 0x000076BAC53CE930
000076bac53cecb9  call 0x000076BAC520A9A0
000076bac53cecbe  jmp 0x000076BAC53CE93C
000076bac53cecc3  call 0x000076BAC520E880
000076bac53cecc8  jmp 0x000076BAC53CE949
000076bac53ceccd  call 0x000076BAC520D600
000076bac53cecd2  jmp 0x000076BAC53CE956
000076bac53cecd7  call 0x000076BAC51FF430
000076bac53cecdc  jmp 0x000076BAC53CE961
000076bac53cece1  call 0x000076BAC520E760
000076bac53cece6  jmp 0x000076BAC53CE96C
000076bac53ceceb  call 0x000076BAC520BC20
000076bac53cecf0  jmp 0x000076BAC53CE99C
000076bac53cecf5  call 0x000076BAC520A9A0
000076bac53cecfa  jmp 0x000076BAC53CE9A8
000076bac53cecff  call 0x000076BAC520BC20
000076bac53ced04  jmp 0x000076BAC53CE9D0
000076bac53ced09  call 0x000076BAC520A9A0
000076bac53ced0e  jmp 0x000076BAC53CE9DC
000076bac53ced13  call 0x000076BAC51FF540
000076bac53ced18  jmp 0x000076BAC53CE9E9
000076bac53ced1d  call 0x000076BAC520E880
000076bac53ced22  jmp 0x000076BAC53CE9F6
000076bac53ced27  call 0x000076BAC51FF430
000076bac53ced2c  jmp 0x000076BAC53CEA01
000076bac53ced31  call 0x000076BAC520E760
000076bac53ced36  jmp 0x000076BAC53CEA0C
000076bac53ced3b  call 0x000076BAC520BC20
000076bac53ced40  jmp 0x000076BAC53CEA36
000076bac53ced45  call 0x000076BAC520A9A0
000076bac53ced4a  jmp 0x000076BAC53CEA42
000076bac53ced4f  call 0x000076BAC520BAE0
000076bac53ced54  jmp 0x000076BAC53CEA52
000076bac53ced59  call 0x000076BAC51FF540
000076bac53ced5e  jmp 0x000076BAC53CEA5F
000076bac53ced63  call 0x000076BAC520E880
000076bac53ced68  jmp 0x000076BAC53CEA6C
000076bac53ced6d  int3
000076bac53ced6e  nop
000076bac53ced70  mov rax, [r15]
000076bac53ced73  lea r14, [rax+0x20]
000076bac53ced77  mov r12, [r13+r14*1]
000076bac53ced7c  mov r14, [r15+0x10]
000076bac53ced80  lea r11, [r12+r14*1]
000076bac53ced84  mov [r15+0x40], r11
000076bac53ced88  lea r12, [rax+0x20]
000076bac53ced8c  mov [r13+r12*1], r11
000076bac53ced91  test r14, r14
000076bac53ced94  setz r14b
000076bac53ced98  movzx r14, r14b
000076bac53ced9c  mov [rsp+0x414], r14b
000076bac53ceda4  cmp byte ptr [rsp+0x414], 0x00
000076bac53cedac  jz 0x000076BAC53CEDDE
000076bac53cedae  cmp dword ptr [r15+0x318], 0x00
000076bac53cedb6  mov eax, 0x4109A0
000076bac53cedbb  mov [r15+0x100], rax
000076bac53cedc2  jz 0x000076BAC51FE0A0
000076bac53cedc8  nop [rax+rax*1], eax
000076bac53cedcd  mov eax, 0x4109A0
000076bac53cedd2  mov [r15+0x100], rax
000076bac53cedd9  jmp 0x000076BAC51FE110
000076bac53cedde  cmp dword ptr [r15+0x318], 0x00
000076bac53cede6  jz 0x000076BAC53CEE30
000076bac53cedec  nop [rax+rax*1], ax
000076bac53cedf5  nop [rax+rax*1], eax
000076bac53cedfd  mov eax, 0x410738
000076bac53cee02  mov [r15+0x100], rax
000076bac53cee09  jmp 0x000076BAC51FE110
000076bac53cee0e  int3
000076bac53cee0f  call 0x000076BAC52E27E0
000076bac53cee14  jmp 0x000076BAC53CED7C
000076bac53cee19  call 0x000076BAC52C0860
000076bac53cee1e  jmp 0x000076BAC53CED91
000076bac53cee23  int3
000076bac53cee24  nop [rax+rax*1], ax
000076bac53cee2d  nop [rax], eax
000076bac53cee30  mov rax, [r15+0xF8]
000076bac53cee37  lea r14, [rax-0x150]
000076bac53cee3e  mov [r15+0xF8], r14
000076bac53cee45  mov rax, [r15]
000076bac53cee48  lea r12, [rax+0x68]
000076bac53cee4c  mov r11, [r13+r12*1]
000076bac53cee51  mov [r15+0x88], r11
000076bac53cee58  lea r12, [rax+0x28]
000076bac53cee5c  mov [r15+0x40], r12
000076bac53cee60  mov [r15+0x48], r14
000076bac53cee64  mov qword ptr [r15+0x50], 0x420B90
000076bac53cee6c  lea rax, [r14+0x100]
000076bac53cee73  mov r12, [r15+0xE8]
000076bac53cee7a  mov r11, [r15+0xD8]
000076bac53cee81  mov [r13+rax*1], r12
000076bac53cee86  lea rax, [r14+0x108]
000076bac53cee8d  mov [r13+rax*1], r11
000076bac53cee92  lea rax, [r14+0x110]
000076bac53cee99  mov r12, [r15+0xD0]
000076bac53ceea0  mov r11, [r15+0xC8]
000076bac53ceea7  mov [r13+rax*1], r12
000076bac53ceeac  lea rax, [r14+0x118]
000076bac53ceeb3  mov [r13+rax*1], r11
000076bac53ceeb8  lea rax, [r14+0x120]
000076bac53ceebf  mov r12, [r15+0xC0]
000076bac53ceec6  mov r11, [r15+0xB8]
000076bac53ceecd  mov [r13+rax*1], r12
000076bac53ceed2  lea rax, [r14+0x128]
000076bac53ceed9  mov [r13+rax*1], r11
000076bac53ceede  lea rax, [r14+0x130]
000076bac53ceee5  mov r12, [r15+0xB0]
000076bac53ceeec  mov r11, [r15+0xA8]
000076bac53ceef3  mov [r13+rax*1], r12
000076bac53ceef8  lea rax, [r14+0x138]
000076bac53ceeff  mov [r13+rax*1], r11
000076bac53cef04  lea rax, [r14+0x140]
000076bac53cef0b  mov r12, [r15+0xA0]
000076bac53cef12  mov r11, [r15+0x98]
000076bac53cef19  mov [r13+rax*1], r12
000076bac53cef1e  lea rax, [r14+0x148]
000076bac53cef25  mov [r13+rax*1], r11
000076bac53cef2a  cmp dword ptr [r15+0x318], 0x00
000076bac53cef32  jz 0x000076BAC53CEFD0
000076bac53cef38  nop [rax+rax*1], ax
000076bac53cef41  nop [rax+rax*1], eax
000076bac53cef49  mov eax, 0x410770
000076bac53cef4e  mov [r15+0x100], rax
000076bac53cef55  jmp 0x000076BAC51FE110
000076bac53cef5a  int3
000076bac53cef5b  call 0x000076BAC52C0370
000076bac53cef60  jmp 0x000076BAC53CEE51
000076bac53cef65  call 0x000076BAC520BC20
000076bac53cef6a  jmp 0x000076BAC53CEE86
000076bac53cef6f  call 0x000076BAC520A9A0
000076bac53cef74  jmp 0x000076BAC53CEE92
000076bac53cef79  call 0x000076BAC520BC20
000076bac53cef7e  jmp 0x000076BAC53CEEAC
000076bac53cef83  call 0x000076BAC520A9A0
000076bac53cef88  jmp 0x000076BAC53CEEB8
000076bac53cef8d  call 0x000076BAC520BC20
000076bac53cef92  jmp 0x000076BAC53CEED2
000076bac53cef97  call 0x000076BAC520A9A0
000076bac53cef9c  jmp 0x000076BAC53CEEDE
000076bac53cefa1  call 0x000076BAC520BC20
000076bac53cefa6  jmp 0x000076BAC53CEEF8
000076bac53cefab  call 0x000076BAC520A9A0
000076bac53cefb0  jmp 0x000076BAC53CEF04
000076bac53cefb5  call 0x000076BAC520BC20
000076bac53cefba  jmp 0x000076BAC53CEF1E
000076bac53cefbf  call 0x000076BAC520A9A0
000076bac53cefc4  jmp 0x000076BAC53CEF2A
000076bac53cefc9  int3
000076bac53cefca  nop [rax+rax*1], ax
000076bac53cefd0  mov rax, [r15+0x08]
000076bac53cefd4  movzx r14d, byte ptr [r13+rax*1]
000076bac53cefda  movzx r14d, r14b
000076bac53cefde  mov [rsp+0x10], r14d
000076bac53cefe3  mov r14d, r14d
000076bac53cefe6  mov [r15+0x58], r14
000076bac53cefea  lea r14, [rax+0x01]
000076bac53cefee  mov [r15+0x08], r14
000076bac53ceff2  mov rax, [r15+0x88]
000076bac53ceff9  lea r14, [rax+0x01]
000076bac53ceffd  mov r12, [r15]
000076bac53cf000  lea r11, [r12+0x68]
000076bac53cf005  mov [r13+r11*1], r14
000076bac53cf00a  lea r14, [r12+rax*1]
000076bac53cf00e  mov [r15+0x60], r14
000076bac53cf012  lea rax, [r14+0x28]
000076bac53cf016  mov r11d, [rsp+0x10]
000076bac53cf01b  movzx r14d, r11b
000076bac53cf01f  mov [r13+rax*1], r14b
000076bac53cf024  lea rax, [r12+0x68]
000076bac53cf029  mov r14, [r13+rax*1]
000076bac53cf02e  mov [r15+0x88], r14
000076bac53cf035  xor eax, eax
000076bac53cf037  mov r12d, 0x40
000076bac53cf03d  cmp r14, r12
000076bac53cf040  cmc
000076bac53cf041  lahf
000076bac53cf042  seto al
000076bac53cf045  mov [r15+0x108], eax
000076bac53cf04c  mov eax, [r15+0x108]
000076bac53cf053  sahf
000076bac53cf054  jnz 0x000076BAC53CF086
000076bac53cf056  cmp dword ptr [r15+0x318], 0x00
000076bac53cf05e  jz 0x000076BAC53CF170
000076bac53cf064  nop [rax+rax*1], ax
000076bac53cf06d  nop [rax+rax*1], eax
000076bac53cf075  mov eax, 0x410790
000076bac53cf07a  mov [r15+0x100], rax
000076bac53cf081  jmp 0x000076BAC51FE110
000076bac53cf086  cmp dword ptr [r15+0x318], 0x00
000076bac53cf08e  jz 0x000076BAC53CF0E0
000076bac53cf094  nop [rax+rax*1], ax
000076bac53cf09d  nop [rax+rax*1], eax
000076bac53cf0a5  mov eax, 0x410768
000076bac53cf0aa  mov [r15+0x100], rax
000076bac53cf0b1  jmp 0x000076BAC51FE110
000076bac53cf0b6  int3
000076bac53cf0b7  call 0x000076BAC520D860
000076bac53cf0bc  jmp 0x000076BAC53CEFDA
000076bac53cf0c1  call 0x000076BAC52B36E0
000076bac53cf0c6  jmp 0x000076BAC53CF00A
000076bac53cf0cb  call 0x000076BAC520DD60
000076bac53cf0d0  jmp 0x000076BAC53CF024
000076bac53cf0d5  call 0x000076BAC520DC20
000076bac53cf0da  jmp 0x000076BAC53CF02E
000076bac53cf0df  int3
000076bac53cf0e0  mov rax, [r15+0x10]
000076bac53cf0e4  lea r14, [rax-0x01]
000076bac53cf0e8  mov [r15+0x10], r14
000076bac53cf0ec  test r14, r14
000076bac53cf0ef  setz r14b
000076bac53cf0f3  movzx r14, r14b
000076bac53cf0f7  mov [rsp+0x414], r14b
000076bac53cf0ff  cmp byte ptr [rsp+0x414], 0x00
000076bac53cf107  jz 0x000076BAC53CF139
000076bac53cf109  cmp dword ptr [r15+0x318], 0x00
000076bac53cf111  jz 0x000076BAC53D0670
000076bac53cf117  nop [rax+rax*1], ax
000076bac53cf120  nop [rax+rax*1], eax
000076bac53cf128  mov eax, 0x410988
000076bac53cf12d  mov [r15+0x100], rax
000076bac53cf134  jmp 0x000076BAC51FE110
000076bac53cf139  cmp dword ptr [r15+0x318], 0x00
000076bac53cf141  jz 0x000076BAC53CEFD0
000076bac53cf147  nop [rax+rax*1], ax
000076bac53cf150  nop [rax+rax*1], eax
000076bac53cf158  mov eax, 0x410770
000076bac53cf15d  mov [r15+0x100], rax
000076bac53cf164  jmp 0x000076BAC51FE110
000076bac53cf169  int3
000076bac53cf16a  int3
000076bac53cf16b  nop [rax+rax*1], eax
000076bac53cf170  mov rax, [r15+0x40]
000076bac53cf174  movzx r14d, byte ptr [r13+rax*1]
000076bac53cf17a  movaps xmm1, [r15+0x110]
000076bac53cf182  pinsrb xmm1, r14d, 0x00
000076bac53cf189  lea r14, [rax+0x01]
000076bac53cf18d  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf193  movaps xmm15, [r15+0x120]
000076bac53cf19b  pinsrb xmm15, r12d, 0x00
000076bac53cf1a2  lea r14, [rax+0x02]
000076bac53cf1a6  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf1ac  movaps xmm14, [r15+0x130]
000076bac53cf1b4  pinsrb xmm14, r12d, 0x00
000076bac53cf1bb  lea r14, [rax+0x03]
000076bac53cf1bf  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf1c5  movaps xmm13, [r15+0x140]
000076bac53cf1cd  pinsrb xmm13, r12d, 0x00
000076bac53cf1d4  lea r14, [rax+0x04]
000076bac53cf1d8  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf1de  pinsrb xmm1, r12d, 0x01
000076bac53cf1e5  lea r14, [rax+0x05]
000076bac53cf1e9  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf1ef  pinsrb xmm15, r12d, 0x01
000076bac53cf1f6  lea r14, [rax+0x06]
000076bac53cf1fa  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf200  pinsrb xmm14, r12d, 0x01
000076bac53cf207  lea r14, [rax+0x07]
000076bac53cf20b  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf211  pinsrb xmm13, r12d, 0x01
000076bac53cf218  lea r14, [rax+0x08]
000076bac53cf21c  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf222  pinsrb xmm1, r12d, 0x02
000076bac53cf229  lea r14, [rax+0x09]
000076bac53cf22d  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf233  pinsrb xmm15, r12d, 0x02
000076bac53cf23a  lea r14, [rax+0x0A]
000076bac53cf23e  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf244  pinsrb xmm14, r12d, 0x02
000076bac53cf24b  lea r14, [rax+0x0B]
000076bac53cf24f  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf255  pinsrb xmm13, r12d, 0x02
000076bac53cf25c  lea r14, [rax+0x0C]
000076bac53cf260  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf266  pinsrb xmm1, r12d, 0x03
000076bac53cf26d  lea r14, [rax+0x0D]
000076bac53cf271  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf277  pinsrb xmm15, r12d, 0x03
000076bac53cf27e  lea r14, [rax+0x0E]
000076bac53cf282  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf288  pinsrb xmm14, r12d, 0x03
000076bac53cf28f  lea r14, [rax+0x0F]
000076bac53cf293  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf299  pinsrb xmm13, r12d, 0x03
000076bac53cf2a0  lea r14, [rax+0x10]
000076bac53cf2a4  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf2aa  pinsrb xmm1, r12d, 0x04
000076bac53cf2b1  lea r14, [rax+0x11]
000076bac53cf2b5  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf2bb  pinsrb xmm15, r12d, 0x04
000076bac53cf2c2  lea r14, [rax+0x12]
000076bac53cf2c6  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf2cc  pinsrb xmm14, r12d, 0x04
000076bac53cf2d3  lea r14, [rax+0x13]
000076bac53cf2d7  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf2dd  pinsrb xmm13, r12d, 0x04
000076bac53cf2e4  lea r14, [rax+0x14]
000076bac53cf2e8  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf2ee  pinsrb xmm1, r12d, 0x05
000076bac53cf2f5  lea r14, [rax+0x15]
000076bac53cf2f9  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf2ff  pinsrb xmm15, r12d, 0x05
000076bac53cf306  lea r14, [rax+0x16]
000076bac53cf30a  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf310  pinsrb xmm14, r12d, 0x05
000076bac53cf317  lea r14, [rax+0x17]
000076bac53cf31b  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf321  pinsrb xmm13, r12d, 0x05
000076bac53cf328  lea r14, [rax+0x18]
000076bac53cf32c  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf332  pinsrb xmm1, r12d, 0x06
000076bac53cf339  lea r14, [rax+0x19]
000076bac53cf33d  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf343  pinsrb xmm15, r12d, 0x06
000076bac53cf34a  lea r14, [rax+0x1A]
000076bac53cf34e  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf354  pinsrb xmm14, r12d, 0x06
000076bac53cf35b  lea r14, [rax+0x1B]
000076bac53cf35f  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf365  pinsrb xmm13, r12d, 0x06
000076bac53cf36c  lea r14, [rax+0x1C]
000076bac53cf370  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf376  pinsrb xmm1, r12d, 0x07
000076bac53cf37d  lea r14, [rax+0x1D]
000076bac53cf381  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf387  pinsrb xmm15, r12d, 0x07
000076bac53cf38e  lea r14, [rax+0x1E]
000076bac53cf392  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf398  pinsrb xmm14, r12d, 0x07
000076bac53cf39f  lea r14, [rax+0x1F]
000076bac53cf3a3  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf3a9  pinsrb xmm13, r12d, 0x07
000076bac53cf3b0  lea r14, [rax+0x20]
000076bac53cf3b4  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf3ba  pinsrb xmm1, r12d, 0x08
000076bac53cf3c1  lea r14, [rax+0x21]
000076bac53cf3c5  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf3cb  pinsrb xmm15, r12d, 0x08
000076bac53cf3d2  lea r14, [rax+0x22]
000076bac53cf3d6  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf3dc  pinsrb xmm14, r12d, 0x08
000076bac53cf3e3  lea r14, [rax+0x23]
000076bac53cf3e7  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf3ed  pinsrb xmm13, r12d, 0x08
000076bac53cf3f4  lea r14, [rax+0x24]
000076bac53cf3f8  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf3fe  pinsrb xmm1, r12d, 0x09
000076bac53cf405  lea r14, [rax+0x25]
000076bac53cf409  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf40f  pinsrb xmm15, r12d, 0x09
000076bac53cf416  lea r14, [rax+0x26]
000076bac53cf41a  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf420  pinsrb xmm14, r12d, 0x09
000076bac53cf427  lea r14, [rax+0x27]
000076bac53cf42b  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf431  pinsrb xmm13, r12d, 0x09
000076bac53cf438  lea r14, [rax+0x28]
000076bac53cf43c  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf442  pinsrb xmm1, r12d, 0x0A
000076bac53cf449  lea r14, [rax+0x29]
000076bac53cf44d  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf453  pinsrb xmm15, r12d, 0x0A
000076bac53cf45a  lea r14, [rax+0x2A]
000076bac53cf45e  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf464  pinsrb xmm14, r12d, 0x0A
000076bac53cf46b  lea r14, [rax+0x2B]
000076bac53cf46f  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf475  pinsrb xmm13, r12d, 0x0A
000076bac53cf47c  lea r14, [rax+0x2C]
000076bac53cf480  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf486  pinsrb xmm1, r12d, 0x0B
000076bac53cf48d  lea r14, [rax+0x2D]
000076bac53cf491  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf497  pinsrb xmm15, r12d, 0x0B
000076bac53cf49e  lea r14, [rax+0x2E]
000076bac53cf4a2  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf4a8  pinsrb xmm14, r12d, 0x0B
000076bac53cf4af  lea r14, [rax+0x2F]
000076bac53cf4b3  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf4b9  pinsrb xmm13, r12d, 0x0B
000076bac53cf4c0  lea r14, [rax+0x30]
000076bac53cf4c4  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf4ca  pinsrb xmm1, r12d, 0x0C
000076bac53cf4d1  lea r14, [rax+0x31]
000076bac53cf4d5  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf4db  pinsrb xmm15, r12d, 0x0C
000076bac53cf4e2  lea r14, [rax+0x32]
000076bac53cf4e6  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf4ec  pinsrb xmm14, r12d, 0x0C
000076bac53cf4f3  lea r14, [rax+0x33]
000076bac53cf4f7  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf4fd  pinsrb xmm13, r12d, 0x0C
000076bac53cf504  lea r14, [rax+0x34]
000076bac53cf508  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf50e  pinsrb xmm1, r12d, 0x0D
000076bac53cf515  lea r14, [rax+0x35]
000076bac53cf519  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf51f  pinsrb xmm15, r12d, 0x0D
000076bac53cf526  lea r14, [rax+0x36]
000076bac53cf52a  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf530  pinsrb xmm14, r12d, 0x0D
000076bac53cf537  lea r14, [rax+0x37]
000076bac53cf53b  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf541  pinsrb xmm13, r12d, 0x0D
000076bac53cf548  lea r14, [rax+0x38]
000076bac53cf54c  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf552  pinsrb xmm1, r12d, 0x0E
000076bac53cf559  lea r14, [rax+0x39]
000076bac53cf55d  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf563  pinsrb xmm15, r12d, 0x0E
000076bac53cf56a  lea r14, [rax+0x3A]
000076bac53cf56e  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf574  pinsrb xmm14, r12d, 0x0E
000076bac53cf57b  lea r14, [rax+0x3B]
000076bac53cf57f  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf585  pinsrb xmm13, r12d, 0x0E
000076bac53cf58c  lea r14, [rax+0x3C]
000076bac53cf590  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf596  pinsrb xmm1, r12d, 0x0F
000076bac53cf59d  movaps [r15+0x110], xmm1
000076bac53cf5a5  lea r14, [rax+0x3D]
000076bac53cf5a9  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf5af  pinsrb xmm15, r12d, 0x0F
000076bac53cf5b6  movaps [r15+0x120], xmm15
000076bac53cf5be  lea r14, [rax+0x3E]
000076bac53cf5c2  movzx r12d, byte ptr [r13+r14*1]
000076bac53cf5c8  pinsrb xmm14, r12d, 0x0F
000076bac53cf5cf  movaps [r15+0x130], xmm14
000076bac53cf5d7  lea r14, [rax+0x3F]
000076bac53cf5db  movzx eax, byte ptr [r13+r14*1]
000076bac53cf5e1  pinsrb xmm13, eax, 0x0F
000076bac53cf5e8  movaps [r15+0x140], xmm13
000076bac53cf5f0  movq xmm1, qword ptr [r15+0x120]
000076bac53cf5f9  pmovzxbw xmm1, xmm1
000076bac53cf5fe  psllw xmm1, 0x00
000076bac53cf603  movaps [r15+0x150], xmm1
000076bac53cf60b  movq xmm1, qword ptr [r15+0x130]
000076bac53cf614  pmovzxbw xmm1, xmm1
000076bac53cf619  psllw xmm1, 0x00
000076bac53cf61e  movaps [r15+0x160], xmm1
000076bac53cf626  movq xmm1, qword ptr [r15+0x110]
000076bac53cf62f  pmovzxbw xmm1, xmm1
000076bac53cf634  psllw xmm1, 0x00
000076bac53cf639  movaps [r15+0x170], xmm1
000076bac53cf641  movaps xmm15, [r15+0x110]
000076bac53cf649  pextrq rax, xmm15, 0x01
000076bac53cf650  movq xmm15, rax
000076bac53cf655  pmovzxbw xmm15, xmm15
000076bac53cf65b  psllw xmm15, 0x00
000076bac53cf661  movaps [r15+0x180], xmm15
000076bac53cf669  movaps xmm14, [r15+0x120]
000076bac53cf671  pextrq rax, xmm14, 0x01
000076bac53cf678  movq xmm14, rax
000076bac53cf67d  pmovzxbw xmm14, xmm14
000076bac53cf683  psllw xmm14, 0x00
000076bac53cf689  movaps [r15+0x210], xmm14
000076bac53cf691  movaps xmm13, [r15+0x130]
000076bac53cf699  pextrq rax, xmm13, 0x01
000076bac53cf6a0  movq xmm13, rax
000076bac53cf6a5  pmovzxbw xmm13, xmm13
000076bac53cf6ab  psllw xmm13, 0x00
000076bac53cf6b1  movaps [r15+0x220], xmm13
000076bac53cf6b9  movq xmm12, qword ptr [r15+0x140]
000076bac53cf6c2  pmovzxbw xmm12, xmm12
000076bac53cf6c8  psllw xmm12, 0x00
000076bac53cf6ce  movaps [r15+0x250], xmm12
000076bac53cf6d6  movaps xmm12, [r15+0x140]
000076bac53cf6de  pextrq rax, xmm12, 0x01
000076bac53cf6e5  movq xmm12, rax
000076bac53cf6ea  pmovzxbw xmm12, xmm12
000076bac53cf6f0  psllw xmm12, 0x00
000076bac53cf6f6  movaps [r15+0x110], xmm12
000076bac53cf6fe  movq xmm11, qword ptr [r15+0x150]
000076bac53cf707  pmovzxwd xmm11, xmm11
000076bac53cf70d  pslld xmm11, 0x10
000076bac53cf713  movq xmm10, qword ptr [r15+0x160]
000076bac53cf71c  pmovzxwd xmm10, xmm10
000076bac53cf722  pslld xmm10, 0x08
000076bac53cf728  pextrq rax, xmm1, 0x01
000076bac53cf72f  movq xmm1, rax
000076bac53cf734  pmovzxwd xmm1, xmm1
000076bac53cf739  pslld xmm1, 0x00
000076bac53cf73e  movaps [r15+0x260], xmm1
000076bac53cf746  pextrq rax, xmm15, 0x01
000076bac53cf74d  movq xmm15, rax
000076bac53cf752  pmovzxwd xmm15, xmm15
000076bac53cf758  pslld xmm15, 0x00
000076bac53cf75e  movaps [r15+0x270], xmm15
000076bac53cf766  movq xmm9, qword ptr [r15+0x170]
000076bac53cf76f  pmovzxwd xmm9, xmm9
000076bac53cf775  pslld xmm9, 0x00
000076bac53cf77b  pextrq rax, xmm14, 0x01
000076bac53cf782  movq xmm14, rax
000076bac53cf787  pmovzxwd xmm14, xmm14
000076bac53cf78d  pslld xmm14, 0x10
000076bac53cf793  movaps [r15+0x280], xmm14
000076bac53cf79b  movq xmm8, qword ptr [r15+0x180]
000076bac53cf7a4  pmovzxwd xmm8, xmm8
000076bac53cf7aa  pslld xmm8, 0x00
000076bac53cf7b0  movq xmm7, qword ptr [r15+0x210]
000076bac53cf7b9  pmovzxwd xmm7, xmm7
000076bac53cf7be  pslld xmm7, 0x10
000076bac53cf7c3  movaps xmm6, [r15+0x150]
000076bac53cf7cb  pextrq rax, xmm6, 0x01
000076bac53cf7d2  movq xmm6, rax
000076bac53cf7d7  pmovzxwd xmm6, xmm6
000076bac53cf7dc  pslld xmm6, 0x10
000076bac53cf7e1  por xmm11, xmm10
000076bac53cf7e6  movaps [r15+0x230], xmm11
000076bac53cf7ee  pextrq rax, xmm13, 0x01
000076bac53cf7f5  movq xmm13, rax
000076bac53cf7fa  pmovzxwd xmm13, xmm13
000076bac53cf800  pslld xmm13, 0x08
000076bac53cf806  movaps [r15+0x240], xmm13
000076bac53cf80e  movq xmm10, qword ptr [r15+0x220]
000076bac53cf817  pmovzxwd xmm10, xmm10
000076bac53cf81d  pslld xmm10, 0x08
000076bac53cf823  movaps xmm5, [r15+0x160]
000076bac53cf82b  pextrq rax, xmm5, 0x01
000076bac53cf832  movq xmm5, rax
000076bac53cf837  pmovzxwd xmm5, xmm5
000076bac53cf83c  pslld xmm5, 0x08
000076bac53cf841  pslld xmm9, 0x18
000076bac53cf847  pslld xmm15, 0x18
000076bac53cf84d  pslld xmm8, 0x18
000076bac53cf853  movq xmm4, qword ptr [r15+0x250]
000076bac53cf85c  pmovzxwd xmm4, xmm4
000076bac53cf861  pslld xmm4, 0x00
000076bac53cf866  por xmm14, xmm13
000076bac53cf86b  por xmm7, xmm10
000076bac53cf870  movaps [r15+0x210], xmm7
000076bac53cf878  pslld xmm1, 0x18
000076bac53cf87d  movaps [r15+0x220], xmm1
000076bac53cf885  por xmm6, xmm5
000076bac53cf889  por xmm11, xmm9
000076bac53cf88e  movaps [r15+0x160], xmm11
000076bac53cf896  pextrq rax, xmm12, 0x01
000076bac53cf89d  movq xmm13, rax
000076bac53cf8a2  pmovzxwd xmm13, xmm13
000076bac53cf8a8  pslld xmm13, 0x00
000076bac53cf8ae  movaps [r15+0x170], xmm13
000076bac53cf8b6  movq xmm12, qword ptr [r15+0x110]
000076bac53cf8bf  pmovzxwd xmm12, xmm12
000076bac53cf8c5  pslld xmm12, 0x00
000076bac53cf8cb  por xmm14, xmm15
000076bac53cf8d0  por xmm7, xmm8
000076bac53cf8d5  movaps xmm15, [r15+0x250]
000076bac53cf8dd  pextrq rax, xmm15, 0x01
000076bac53cf8e4  movq xmm15, rax
000076bac53cf8e9  pmovzxwd xmm15, xmm15
000076bac53cf8ef  pslld xmm15, 0x00
000076bac53cf8f5  movaps [r15+0x180], xmm15
000076bac53cf8fd  por xmm6, xmm1
000076bac53cf901  movaps [r15+0x150], xmm6
000076bac53cf909  por xmm11, xmm4
000076bac53cf90e  movaps [r15+0x140], xmm11
000076bac53cf916  por xmm7, xmm12
000076bac53cf91b  movaps [r15+0x110], xmm7
000076bac53cf923  por xmm14, xmm13
000076bac53cf928  movaps [r15+0x120], xmm14
000076bac53cf930  por xmm6, xmm15
000076bac53cf935  movaps [r15+0x130], xmm6
000076bac53cf93d  mov rax, [r15+0xF8]
000076bac53cf944  lea r14, [rax+0x20]
000076bac53cf948  movups [r13+r14*1], xmm7
000076bac53cf94e  lea r14, [rax+0x30]
000076bac53cf952  movups [r13+r14*1], xmm14
000076bac53cf958  movups [r13+rax*1], xmm11
000076bac53cf95e  lea r14, [rax+0x10]
000076bac53cf962  movups [r13+r14*1], xmm6
000076bac53cf968  mov r14d, [r13+rax*1]
000076bac53cf96d  mov rax, [r15+0x48]
000076bac53cf971  mov [r15+0x68], rax
000076bac53cf975  mov qword ptr [r15+0x58], 0x04
000076bac53cf97d  lea r12, [rax+0x04]
000076bac53cf981  mov r11d, [r13+r12*1]
000076bac53cf986  mov [rsp+0x10], r11d
000076bac53cf98b  mov r11d, r11d
000076bac53cf98e  mov [r15+0x70], r11
000076bac53cf992  lea r12, [rax+0x38]
000076bac53cf996  mov r11d, [r13+r12*1]
000076bac53cf99b  lea r12, [rax+0x24]
000076bac53cf99f  mov r10d, [r13+r12*1]
000076bac53cf9a4  mov [rsp+0x20], r10d
000076bac53cf9a9  mov r10d, r10d
000076bac53cf9ac  mov [r15+0x90], r10
000076bac53cf9b3  mov [rsp+0x30], rax
000076bac53cf9b8  xor eax, eax
000076bac53cf9ba  mov r12d, 0x04
000076bac53cf9c0  mov r10d, 0xC0
000076bac53cf9c6  cmp r12, r10
000076bac53cf9c9  cmc
000076bac53cf9ca  lahf
000076bac53cf9cb  seto al
000076bac53cf9ce  mov [r15+0x108], eax
000076bac53cf9d5  mov eax, [rsp+0x10]
000076bac53cf9d9  mov r12d, [rsp+0x10]
000076bac53cf9de  shrd eax, r12d, 0x07
000076bac53cf9e3  mov [rsp+0x10], r11d
000076bac53cf9e8  mov r10d, [rsp+0x10]
000076bac53cf9ed  shrd r11d, r10d, 0x11
000076bac53cf9f2  mov r9d, [rsp+0x20]
000076bac53cf9f7  lea r8d, [r9d+r14d*1]
000076bac53cf9fc  rorx r14d, r12d, 0x12
000076bac53cfa02  xor eax, r14d
000076bac53cfa05  rorx r14d, r10d, 0x13
000076bac53cfa0b  xor r11d, r14d
000076bac53cfa0e  mov [rsp+0x10], r11d
000076bac53cfa13  mov r11d, r11d
000076bac53cfa16  mov [r15+0x88], r11
000076bac53cfa1d  mov [rsp+0x20], r12d
000076bac53cfa22  shr r12d, 0x03
000076bac53cfa26  xor eax, r12d
000076bac53cfa29  mov [rsp+0x40], eax
000076bac53cfa2d  mov eax, eax
000076bac53cfa2f  mov [r15+0x80], rax
000076bac53cfa36  shr r10d, 0x0A
000076bac53cfa3a  mov eax, [rsp+0x10]
000076bac53cfa3e  xor eax, r10d
000076bac53cfa41  mov [rsp+0x10], eax
000076bac53cfa45  mov eax, eax
000076bac53cfa47  mov [r15+0x78], rax
000076bac53cfa4b  mov eax, [rsp+0x40]
000076bac53cfa4f  lea r14d, [r8d+eax*1]
000076bac53cfa54  mov eax, [rsp+0x10]
000076bac53cfa58  lea r12d, [r14d+eax*1]
000076bac53cfa5d  mov rax, [rsp+0x30]
000076bac53cfa62  lea r14, [rax+0x40]
000076bac53cfa66  mov [r13+r14*1], r12d
000076bac53cfa6b  mov eax, [rsp+0x20]
000076bac53cfa6f  mov eax, eax
000076bac53cfa71  mov [r15+0x60], rax
000076bac53cfa75  mov eax, [r15+0x108]
000076bac53cfa7c  sahf
000076bac53cfa7d  jnz 0x000076BAC53CFAAF
000076bac53cfa7f  cmp dword ptr [r15+0x318], 0x00
000076bac53cfa87  jz 0x000076BAC53CFF70
000076bac53cfa8d  nop [rax+rax*1], ax
000076bac53cfa96  nop [rax+rax*1], eax
000076bac53cfa9e  mov eax, 0x41088C
000076bac53cfaa3  mov [r15+0x100], rax
000076bac53cfaaa  jmp 0x000076BAC51FE110
000076bac53cfaaf  cmp dword ptr [r15+0x318], 0x00
000076bac53cfab7  jz 0x000076BAC53CFDC0
000076bac53cfabd  nop [rax+rax*1], ax
000076bac53cfac6  nop [rax+rax*1], eax
000076bac53cface  mov eax, 0x410844
000076bac53cfad3  mov [r15+0x100], rax
000076bac53cfada  jmp 0x000076BAC51FE110
000076bac53cfadf  int3
000076bac53cfae0  call 0x000076BAC520D860
000076bac53cfae5  jmp 0x000076BAC53CF17A
000076bac53cfaea  call 0x000076BAC52E2420
000076bac53cfaef  jmp 0x000076BAC53CF193
000076bac53cfaf4  call 0x000076BAC52E2420
000076bac53cfaf9  jmp 0x000076BAC53CF1AC
000076bac53cfafe  call 0x000076BAC52E2420
000076bac53cfb03  jmp 0x000076BAC53CF1C5
000076bac53cfb08  call 0x000076BAC52E2420
000076bac53cfb0d  jmp 0x000076BAC53CF1DE
000076bac53cfb12  call 0x000076BAC52E2420
000076bac53cfb17  jmp 0x000076BAC53CF1EF
000076bac53cfb1c  call 0x000076BAC52E2420
000076bac53cfb21  jmp 0x000076BAC53CF200
000076bac53cfb26  call 0x000076BAC52E2420
000076bac53cfb2b  jmp 0x000076BAC53CF211
000076bac53cfb30  call 0x000076BAC52E2420
000076bac53cfb35  jmp 0x000076BAC53CF222
000076bac53cfb3a  call 0x000076BAC52E2420
000076bac53cfb3f  jmp 0x000076BAC53CF233
000076bac53cfb44  call 0x000076BAC52E2420
000076bac53cfb49  jmp 0x000076BAC53CF244
000076bac53cfb4e  call 0x000076BAC52E2420
000076bac53cfb53  jmp 0x000076BAC53CF255
000076bac53cfb58  call 0x000076BAC52E2420
000076bac53cfb5d  jmp 0x000076BAC53CF266
000076bac53cfb62  call 0x000076BAC52E2420
000076bac53cfb67  jmp 0x000076BAC53CF277
000076bac53cfb6c  call 0x000076BAC52E2420
000076bac53cfb71  jmp 0x000076BAC53CF288
000076bac53cfb76  call 0x000076BAC52E2420
000076bac53cfb7b  jmp 0x000076BAC53CF299
000076bac53cfb80  call 0x000076BAC52E2420
000076bac53cfb85  jmp 0x000076BAC53CF2AA
000076bac53cfb8a  call 0x000076BAC52E2420
000076bac53cfb8f  jmp 0x000076BAC53CF2BB
000076bac53cfb94  call 0x000076BAC52E2420
000076bac53cfb99  jmp 0x000076BAC53CF2CC
000076bac53cfb9e  call 0x000076BAC52E2420
000076bac53cfba3  jmp 0x000076BAC53CF2DD
000076bac53cfba8  call 0x000076BAC52E2420
000076bac53cfbad  jmp 0x000076BAC53CF2EE
000076bac53cfbb2  call 0x000076BAC52E2420
000076bac53cfbb7  jmp 0x000076BAC53CF2FF
000076bac53cfbbc  call 0x000076BAC52E2420
000076bac53cfbc1  jmp 0x000076BAC53CF310
000076bac53cfbc6  call 0x000076BAC52E2420
000076bac53cfbcb  jmp 0x000076BAC53CF321
000076bac53cfbd0  call 0x000076BAC52E2420
000076bac53cfbd5  jmp 0x000076BAC53CF332
000076bac53cfbda  call 0x000076BAC52E2420
000076bac53cfbdf  jmp 0x000076BAC53CF343
000076bac53cfbe4  call 0x000076BAC52E2420
000076bac53cfbe9  jmp 0x000076BAC53CF354
000076bac53cfbee  call 0x000076BAC52E2420
000076bac53cfbf3  jmp 0x000076BAC53CF365
000076bac53cfbf8  call 0x000076BAC52E2420
000076bac53cfbfd  jmp 0x000076BAC53CF376
000076bac53cfc02  call 0x000076BAC52E2420
000076bac53cfc07  jmp 0x000076BAC53CF387
000076bac53cfc0c  call 0x000076BAC52E2420
000076bac53cfc11  jmp 0x000076BAC53CF398
000076bac53cfc16  call 0x000076BAC52E2420
000076bac53cfc1b  jmp 0x000076BAC53CF3A9
000076bac53cfc20  call 0x000076BAC52E2420
000076bac53cfc25  jmp 0x000076BAC53CF3BA
000076bac53cfc2a  call 0x000076BAC52E2420
000076bac53cfc2f  jmp 0x000076BAC53CF3CB
000076bac53cfc34  call 0x000076BAC52E2420
000076bac53cfc39  jmp 0x000076BAC53CF3DC
000076bac53cfc3e  call 0x000076BAC52E2420
000076bac53cfc43  jmp 0x000076BAC53CF3ED
000076bac53cfc48  call 0x000076BAC52E2420
000076bac53cfc4d  jmp 0x000076BAC53CF3FE
000076bac53cfc52  call 0x000076BAC52E2420
000076bac53cfc57  jmp 0x000076BAC53CF40F
000076bac53cfc5c  call 0x000076BAC52E2420
000076bac53cfc61  jmp 0x000076BAC53CF420
000076bac53cfc66  call 0x000076BAC52E2420
000076bac53cfc6b  jmp 0x000076BAC53CF431
000076bac53cfc70  call 0x000076BAC52E2420
000076bac53cfc75  jmp 0x000076BAC53CF442
000076bac53cfc7a  call 0x000076BAC52E2420
000076bac53cfc7f  jmp 0x000076BAC53CF453
000076bac53cfc84  call 0x000076BAC52E2420
000076bac53cfc89  jmp 0x000076BAC53CF464
000076bac53cfc8e  call 0x000076BAC52E2420
000076bac53cfc93  jmp 0x000076BAC53CF475
000076bac53cfc98  call 0x000076BAC52E2420
000076bac53cfc9d  jmp 0x000076BAC53CF486
000076bac53cfca2  call 0x000076BAC52E2420
000076bac53cfca7  jmp 0x000076BAC53CF497
000076bac53cfcac  call 0x000076BAC52E2420
000076bac53cfcb1  jmp 0x000076BAC53CF4A8
000076bac53cfcb6  call 0x000076BAC52E2420
000076bac53cfcbb  jmp 0x000076BAC53CF4B9
000076bac53cfcc0  call 0x000076BAC52E2420
000076bac53cfcc5  jmp 0x000076BAC53CF4CA
000076bac53cfcca  call 0x000076BAC52E2420
000076bac53cfccf  jmp 0x000076BAC53CF4DB
000076bac53cfcd4  call 0x000076BAC52E2420
000076bac53cfcd9  jmp 0x000076BAC53CF4EC
000076bac53cfcde  call 0x000076BAC52E2420
000076bac53cfce3  jmp 0x000076BAC53CF4FD
000076bac53cfce8  call 0x000076BAC52E2420
000076bac53cfced  jmp 0x000076BAC53CF50E
000076bac53cfcf2  call 0x000076BAC52E2420
000076bac53cfcf7  jmp 0x000076BAC53CF51F
000076bac53cfcfc  call 0x000076BAC52E2420
000076bac53cfd01  jmp 0x000076BAC53CF530
000076bac53cfd06  call 0x000076BAC52E2420
000076bac53cfd0b  jmp 0x000076BAC53CF541
000076bac53cfd10  call 0x000076BAC52E2420
000076bac53cfd15  jmp 0x000076BAC53CF552
000076bac53cfd1a  call 0x000076BAC52E2420
000076bac53cfd1f  jmp 0x000076BAC53CF563
000076bac53cfd24  call 0x000076BAC52E2420
000076bac53cfd29  jmp 0x000076BAC53CF574
000076bac53cfd2e  call 0x000076BAC52E2420
000076bac53cfd33  jmp 0x000076BAC53CF585
000076bac53cfd38  call 0x000076BAC52E2420
000076bac53cfd3d  jmp 0x000076BAC53CF596
000076bac53cfd42  call 0x000076BAC52E2420
000076bac53cfd47  jmp 0x000076BAC53CF5AF
000076bac53cfd4c  call 0x000076BAC52E2420
000076bac53cfd51  jmp 0x000076BAC53CF5C8
000076bac53cfd56  call 0x000076BAC52D5610
000076bac53cfd5b  jmp 0x000076BAC53CF5E1
000076bac53cfd60  call 0x000076BAC52DC580
000076bac53cfd65  jmp 0x000076BAC53CF94E
000076bac53cfd6a  call 0x000076BAC52E46C0
000076bac53cfd6f  jmp 0x000076BAC53CF958
000076bac53cfd74  call 0x000076BAC5209E90
000076bac53cfd79  jmp 0x000076BAC53CF95E
000076bac53cfd7e  call 0x000076BAC52DB310
000076bac53cfd83  jmp 0x000076BAC53CF968
000076bac53cfd88  call 0x000076BAC520DAE0
000076bac53cfd8d  jmp 0x000076BAC53CF96D
000076bac53cfd92  call 0x000076BAC52C0230
000076bac53cfd97  jmp 0x000076BAC53CF986
000076bac53cfd9c  call 0x000076BAC52C0230
000076bac53cfda1  jmp 0x000076BAC53CF99B
000076bac53cfda6  call 0x000076BAC52BEFC0
000076bac53cfdab  jmp 0x000076BAC53CF9A4
000076bac53cfdb0  call 0x000076BAC52E2BA0
000076bac53cfdb5  jmp 0x000076BAC53CFA6B
000076bac53cfdba  int3
000076bac53cfdbb  nop [rax+rax*1], eax
000076bac53cfdc0  mov rax, [r15+0x48]
000076bac53cfdc4  mov r14, [r15+0x58]
000076bac53cfdc8  lea r12, [rax+r14*1]
000076bac53cfdcc  mov [r15+0x68], r12
000076bac53cfdd0  lea rax, [r14+0x04]
000076bac53cfdd4  mov [r15+0x58], rax
000076bac53cfdd8  lea r14, [r12+0x04]
000076bac53cfddd  mov r11d, [r13+r14*1]
000076bac53cfde2  mov [rsp+0x10], r11d
000076bac53cfde7  mov r11d, r11d
000076bac53cfdea  mov [r15+0x70], r11
000076bac53cfdee  lea r14, [r12+0x38]
000076bac53cfdf3  mov r11d, [r13+r14*1]
000076bac53cfdf8  lea r14, [r12+0x24]
000076bac53cfdfd  mov r10d, [r13+r14*1]
000076bac53cfe02  mov [rsp+0x20], r10d
000076bac53cfe07  mov r10d, r10d
000076bac53cfe0a  mov [r15+0x90], r10
000076bac53cfe11  mov [rsp+0x30], rax
000076bac53cfe16  xor eax, eax
000076bac53cfe18  mov r14, [rsp+0x30]
000076bac53cfe1d  mov r10d, 0xC0
000076bac53cfe23  cmp r14, r10
000076bac53cfe26  cmc
000076bac53cfe27  lahf
000076bac53cfe28  seto al
000076bac53cfe2b  mov [r15+0x108], eax
000076bac53cfe32  mov eax, [rsp+0x10]
000076bac53cfe36  mov r14d, [rsp+0x10]
000076bac53cfe3b  shrd eax, r14d, 0x07
000076bac53cfe40  mov [rsp+0x10], r11d
000076bac53cfe45  mov r10d, [rsp+0x10]
000076bac53cfe4a  shrd r11d, r10d, 0x11
000076bac53cfe4f  mov r9d, [r15+0x60]
000076bac53cfe53  mov r8d, [rsp+0x20]
000076bac53cfe58  lea ebp, [r8d+r9d*1]
000076bac53cfe5d  rorx r9d, r14d, 0x12
000076bac53cfe63  xor eax, r9d
000076bac53cfe66  rorx r9d, r10d, 0x13
000076bac53cfe6c  xor r11d, r9d
000076bac53cfe6f  mov [rsp+0x10], r11d
000076bac53cfe74  mov r11d, r11d
000076bac53cfe77  mov [r15+0x88], r11
000076bac53cfe7e  mov [rsp+0x20], r14d
000076bac53cfe83  shr r14d, 0x03
000076bac53cfe87  xor eax, r14d
000076bac53cfe8a  mov [rsp+0x30], eax
000076bac53cfe8e  mov eax, eax
000076bac53cfe90  mov [r15+0x80], rax
000076bac53cfe97  shr r10d, 0x0A
000076bac53cfe9b  mov eax, [rsp+0x10]
000076bac53cfe9f  xor eax, r10d
000076bac53cfea2  mov [rsp+0x10], eax
000076bac53cfea6  mov eax, eax
000076bac53cfea8  mov [r15+0x78], rax
000076bac53cfeac  mov eax, [rsp+0x30]
000076bac53cfeb0  lea r14d, [ebp+eax*1]
000076bac53cfeb6  mov eax, [rsp+0x10]
000076bac53cfeba  lea r11d, [r14d+eax*1]
000076bac53cfebf  lea rax, [r12+0x40]
000076bac53cfec4  mov [r13+rax*1], r11d
000076bac53cfec9  mov eax, [rsp+0x20]
000076bac53cfecd  mov eax, eax
000076bac53cfecf  mov [r15+0x60], rax
000076bac53cfed3  mov eax, [r15+0x108]
000076bac53cfeda  sahf
000076bac53cfedb  jnz 0x000076BAC53CFF0D
000076bac53cfedd  cmp dword ptr [r15+0x318], 0x00
000076bac53cfee5  jz 0x000076BAC53CFF70
000076bac53cfeeb  nop [rax+rax*1], ax
000076bac53cfef4  nop [rax+rax*1], eax
000076bac53cfefc  mov eax, 0x41088C
000076bac53cff01  mov [r15+0x100], rax
000076bac53cff08  jmp 0x000076BAC51FE110
000076bac53cff0d  cmp dword ptr [r15+0x318], 0x00
000076bac53cff15  jz 0x000076BAC53CFDC0
000076bac53cff1b  nop [rax+rax*1], ax
000076bac53cff24  nop [rax+rax*1], eax
000076bac53cff2c  mov eax, 0x410844
000076bac53cff31  mov [r15+0x100], rax
000076bac53cff38  jmp 0x000076BAC51FE110
000076bac53cff3d  int3
000076bac53cff3e  call 0x000076BAC52E1430
000076bac53cff43  jmp 0x000076BAC53CFDE2
000076bac53cff48  call 0x000076BAC52E1430
000076bac53cff4d  jmp 0x000076BAC53CFDF8
000076bac53cff52  call 0x000076BAC52E01C0
000076bac53cff57  jmp 0x000076BAC53CFE02
000076bac53cff5c  call 0x000076BAC520A860
000076bac53cff61  jmp 0x000076BAC53CFEC9
000076bac53cff66  int3
000076bac53cff67  nop [rax+rax*1], ax
000076bac53cff70  mov rax, [r15]
000076bac53cff73  mov r14d, [r13+rax*1]
000076bac53cff78  lea r12, [rax+0x04]
000076bac53cff7c  mov r11d, [r13+r12*1]
000076bac53cff81  mov [rsp+0x10], r14d
000076bac53cff86  mov r14d, r14d
000076bac53cff89  mov [r15+0x78], r14
000076bac53cff8d  mov [rsp+0x20], r11d
000076bac53cff92  mov r11d, r11d
000076bac53cff95  mov [r15+0x80], r11
000076bac53cff9c  lea r14, [rax+0x08]
000076bac53cffa0  mov r12d, [r13+r14*1]
000076bac53cffa5  lea r14, [rax+0x0C]
000076bac53cffa9  mov r11d, [r13+r14*1]
000076bac53cffae  mov [rsp+0x30], r12d
000076bac53cffb3  mov r12d, r12d
000076bac53cffb6  mov [r15+0x70], r12
000076bac53cffba  mov [rsp+0x40], r11d
000076bac53cffbf  mov r11d, r11d
000076bac53cffc2  mov [r15+0x68], r11
000076bac53cffc6  lea r14, [rax+0x18]
000076bac53cffca  mov r12d, [r13+r14*1]
000076bac53cffcf  lea r14, [rax+0x1C]
000076bac53cffd3  mov r11d, [r13+r14*1]
000076bac53cffd8  mov [rsp+0x50], r12d
000076bac53cffdd  mov r12d, r12d
000076bac53cffe0  mov [r15+0x58], r12
000076bac53cffe4  mov [rsp+0x60], r11d
000076bac53cffe9  mov r11d, r11d
000076bac53cffec  mov [r15+0x60], r11
000076bac53cfff0  lea r14, [rax+0x10]
000076bac53cfff4  mov r12d, [r13+r14*1]
000076bac53cfff9  lea r14, [rax+0x14]
000076bac53cfffd  mov eax, [r13+r14*1]
000076bac53d0002  mov [rsp+0x70], r12d
000076bac53d0007  mov r12d, r12d
000076bac53d000a  mov [r15+0x18], r12
000076bac53d000e  mov [rsp+0x80], eax
000076bac53d0015  mov eax, eax
000076bac53d0017  mov [r15+0x90], rax
000076bac53d001e  mov eax, [rsp+0x70]
000076bac53d0022  mov eax, eax
000076bac53d0024  mov [r15+0x30], rax
000076bac53d0028  mov eax, [rsp+0x50]
000076bac53d002c  mov eax, eax
000076bac53d002e  mov [r15+0xA0], rax
000076bac53d0035  mov eax, [rsp+0x30]
000076bac53d0039  mov eax, eax
000076bac53d003b  mov [r15+0x28], rax
000076bac53d003f  mov eax, [rsp+0x20]
000076bac53d0043  mov eax, eax
000076bac53d0045  mov [r15+0x98], rax
000076bac53d004c  mov eax, [rsp+0x10]
000076bac53d0050  mov eax, eax
000076bac53d0052  mov [r15+0x38], rax
000076bac53d0056  mov eax, [rsp+0x70]
000076bac53d005a  mov r14d, [rsp+0x70]
000076bac53d005f  shrd eax, r14d, 0x06
000076bac53d0064  mov [rsp+0x70], r14d
000076bac53d0069  mov r12d, [rsp+0x80]
000076bac53d0071  and r14d, r12d
000076bac53d0074  mov r11d, [rsp+0x10]
000076bac53d0079  mov r10d, [rsp+0x10]
000076bac53d007e  shrd r11d, r10d, 0x02
000076bac53d0083  mov [rsp+0x10], r12d
000076bac53d0088  mov r12d, r12d
000076bac53d008b  mov [r15+0x20], r12
000076bac53d008f  mov r12, [r15+0x50]
000076bac53d0093  mov r9d, [r13+r12*1]
000076bac53d0098  mov r12d, [rsp+0x50]
000076bac53d009d  mov r8d, [rsp+0x70]
000076bac53d00a2  andn ebp, r8d, r12d
000076bac53d00a7  mov edi, [rsp+0x60]
000076bac53d00ab  lea esi, [r14d+edi*1]
000076bac53d00b0  rorx r14d, r8d, 0x0B
000076bac53d00b6  xor eax, r14d
000076bac53d00b9  rorx r14d, r10d, 0x0D
000076bac53d00bf  xor r11d, r14d
000076bac53d00c2  lea edi, [esi+ebp*1]
000076bac53d00c6  mov r14, [r15+0x48]
000076bac53d00ca  mov ebp, [r13+r14*1]
000076bac53d00cf  mov r14d, [rsp+0x30]
000076bac53d00d4  mov esi, [rsp+0x20]
000076bac53d00d8  and r14d, esi
000076bac53d00db  mov [rsp+0x20], r14d
000076bac53d00e0  mov r14d, r14d
000076bac53d00e3  mov [r15+0xD8], r14
000076bac53d00ea  lea r14d, [edi+r9d*1]
000076bac53d00ef  mov r9d, [rsp+0x30]
000076bac53d00f4  xor r9d, esi
000076bac53d00f7  rorx edi, r8d, 0x19
000076bac53d00fd  xor eax, edi
000076bac53d00ff  and r9d, r10d
000076bac53d0102  rorx edi, r10d, 0x16
000076bac53d0108  xor r11d, edi
000076bac53d010b  mov [rsp+0x30], r11d
000076bac53d0110  mov r11d, r11d
000076bac53d0113  mov [r15+0xD0], r11
000076bac53d011a  lea r11d, [r14d+ebp*1]
000076bac53d011f  mov r10d, [rsp+0x20]
000076bac53d0124  xor r9d, r10d
000076bac53d0127  lea r14d, [r11d+eax*1]
000076bac53d012c  mov qword ptr [r15+0x88], 0x04
000076bac53d0137  mov eax, [rsp+0x30]
000076bac53d013b  lea r11d, [r9d+eax*1]
000076bac53d0140  mov eax, [rsp+0x40]
000076bac53d0144  lea r10d, [r14d+eax*1]
000076bac53d0149  mov r10d, r10d
000076bac53d014c  mov [r15+0xB8], r10
000076bac53d0153  xor eax, eax
000076bac53d0155  mov r10d, 0x04
000076bac53d015b  mov r9d, 0x100
000076bac53d0161  cmp r10, r9
000076bac53d0164  cmc
000076bac53d0165  lahf
000076bac53d0166  seto al
000076bac53d0169  mov [r15+0x108], eax
000076bac53d0170  lea eax, [r11d+r14d*1]
000076bac53d0175  mov eax, eax
000076bac53d0177  mov [r15+0xA8], rax
000076bac53d017e  mov r12d, r12d
000076bac53d0181  mov [r15+0xB0], r12
000076bac53d0188  mov eax, [rsp+0x10]
000076bac53d018c  mov eax, eax
000076bac53d018e  mov [r15+0xC0], rax
000076bac53d0195  mov r8d, r8d
000076bac53d0198  mov [r15+0xC8], r8
000076bac53d019f  mov eax, [r15+0x108]
000076bac53d01a6  sahf
000076bac53d01a7  jnz 0x000076BAC53D01D9
000076bac53d01a9  cmp dword ptr [r15+0x318], 0x00
000076bac53d01b1  jz 0x000076BAC53D04A0
000076bac53d01b7  nop [rax+rax*1], ax
000076bac53d01c0  nop [rax+rax*1], eax
000076bac53d01c8  mov eax, 0x41094C
000076bac53d01cd  mov [r15+0x100], rax
000076bac53d01d4  jmp 0x000076BAC51FE110
000076bac53d01d9  cmp dword ptr [r15+0x318], 0x00
000076bac53d01e1  jz 0x000076BAC53D0270
000076bac53d01e7  nop [rax+rax*1], ax
000076bac53d01f0  nop [rax+rax*1], eax
000076bac53d01f8  mov eax, 0x4108C0
000076bac53d01fd  mov [r15+0x100], rax
000076bac53d0204  jmp 0x000076BAC51FE110
000076bac53d0209  int3
000076bac53d020a  call 0x000076BAC520DAE0
000076bac53d020f  jmp 0x000076BAC53CFF78
000076bac53d0214  call 0x000076BAC52C0230
000076bac53d0219  jmp 0x000076BAC53CFF81
000076bac53d021e  call 0x000076BAC52E26A0
000076bac53d0223  jmp 0x000076BAC53CFFA5
000076bac53d0228  call 0x000076BAC52E1430
000076bac53d022d  jmp 0x000076BAC53CFFAE
000076bac53d0232  call 0x000076BAC52E26A0
000076bac53d0237  jmp 0x000076BAC53CFFCF
000076bac53d023c  call 0x000076BAC52E1430
000076bac53d0241  jmp 0x000076BAC53CFFD8
000076bac53d0246  call 0x000076BAC52E26A0
000076bac53d024b  jmp 0x000076BAC53CFFF9
000076bac53d0250  call 0x000076BAC52D5890
000076bac53d0255  jmp 0x000076BAC53D0002
000076bac53d025a  call 0x000076BAC52BDD50
000076bac53d025f  jmp 0x000076BAC53D0098
000076bac53d0264  call 0x000076BAC52DA580
000076bac53d0269  jmp 0x000076BAC53D00CF
000076bac53d026e  int3
000076bac53d026f  nop
000076bac53d0270  mov eax, [r15+0xB8]
000076bac53d0277  mov [rsp+0x10], eax
000076bac53d027b  mov eax, eax
000076bac53d027d  mov [r15+0x30], rax
000076bac53d0281  mov eax, [r15+0xC0]
000076bac53d0288  mov [rsp+0x20], eax
000076bac53d028c  mov eax, eax
000076bac53d028e  mov [r15+0xA0], rax
000076bac53d0295  mov eax, [r15+0x28]
000076bac53d0299  mov r14d, [r15+0x98]
000076bac53d02a0  mov [rsp+0x30], r14d
000076bac53d02a5  mov r14d, r14d
000076bac53d02a8  mov [r15+0x28], r14
000076bac53d02ac  mov r14d, [r15+0x38]
000076bac53d02b0  mov [rsp+0x40], r14d
000076bac53d02b5  mov r14d, r14d
000076bac53d02b8  mov [r15+0x98], r14
000076bac53d02bf  mov r14d, [r15+0xA8]
000076bac53d02c6  mov [rsp+0x50], r14d
000076bac53d02cb  mov r14d, r14d
000076bac53d02ce  mov [r15+0x38], r14
000076bac53d02d2  mov r14d, [rsp+0x10]
000076bac53d02d7  mov r12d, [rsp+0x10]
000076bac53d02dc  shrd r14d, r12d, 0x06
000076bac53d02e1  mov r11d, [r15+0xC8]
000076bac53d02e8  mov [rsp+0x10], r12d
000076bac53d02ed  and r12d, r11d
000076bac53d02f0  mov r10d, [rsp+0x50]
000076bac53d02f5  mov r9d, [rsp+0x50]
000076bac53d02fa  shrd r10d, r9d, 0x02
000076bac53d02ff  mov [rsp+0x50], r11d
000076bac53d0304  mov r11d, r11d
000076bac53d0307  mov [r15+0x20], r11
000076bac53d030b  mov r11, [r15+0x88]
000076bac53d0312  mov r8, [r15+0x50]
000076bac53d0316  lea rbp, [r8+r11*1]
000076bac53d031a  mov r8d, [r13+rbp*1]
000076bac53d031f  mov ebp, [rsp+0x20]
000076bac53d0323  mov edi, [rsp+0x10]
000076bac53d0327  andn esi, edi, ebp
000076bac53d032c  mov edx, [r15+0xB0]
000076bac53d0333  lea ecx, [r12d+edx*1]
000076bac53d0338  rorx r12d, edi, 0x0B
000076bac53d033e  xor r14d, r12d
000076bac53d0341  rorx r12d, r9d, 0x0D
000076bac53d0347  xor r10d, r12d
000076bac53d034a  lea r12d, [ecx+esi*1]
000076bac53d034f  mov rsi, [r15+0x48]
000076bac53d0353  lea rdx, [rsi+r11*1]
000076bac53d0357  mov esi, [r13+rdx*1]
000076bac53d035c  mov edx, [rsp+0x30]
000076bac53d0360  mov ecx, [rsp+0x40]
000076bac53d0364  and edx, ecx
000076bac53d0366  mov [rsp+0x10], edx
000076bac53d036a  mov edx, edx
000076bac53d036c  mov [r15+0xD8], rdx
000076bac53d0373  lea edx, [r12d+r8d*1]
000076bac53d0378  mov r12d, [rsp+0x30]
000076bac53d037d  xor r12d, ecx
000076bac53d0380  rorx r8d, edi, 0x19
000076bac53d0386  xor r14d, r8d
000076bac53d0389  and r12d, r9d
000076bac53d038c  rorx r8d, r9d, 0x16
000076bac53d0392  xor r10d, r8d
000076bac53d0395  mov [rsp+0x20], r10d
000076bac53d039a  mov r10d, r10d
000076bac53d039d  mov [r15+0xD0], r10
000076bac53d03a4  lea r10d, [edx+esi*1]
000076bac53d03a9  mov r9d, [rsp+0x10]
000076bac53d03ae  xor r12d, r9d
000076bac53d03b1  lea r9d, [r10d+r14d*1]
000076bac53d03b6  lea r14, [r11+0x04]
000076bac53d03ba  mov [r15+0x88], r14
000076bac53d03c1  mov r11d, [rsp+0x20]
000076bac53d03c6  lea r10d, [r12d+r11d*1]
000076bac53d03cb  lea r11d, [r9d+eax*1]
000076bac53d03d0  mov r11d, r11d
000076bac53d03d3  mov [r15+0xB8], r11
000076bac53d03da  xor eax, eax
000076bac53d03dc  mov r12d, 0x100
000076bac53d03e2  cmp r14, r12
000076bac53d03e5  cmc
000076bac53d03e6  lahf
000076bac53d03e7  seto al
000076bac53d03ea  mov [r15+0x108], eax
000076bac53d03f1  lea eax, [r10d+r9d*1]
000076bac53d03f6  mov eax, eax
000076bac53d03f8  mov [r15+0xA8], rax
000076bac53d03ff  mov ebp, ebp
000076bac53d0401  mov [r15+0xB0], rbp
000076bac53d0408  mov eax, [rsp+0x50]
000076bac53d040c  mov eax, eax
000076bac53d040e  mov [r15+0xC0], rax
000076bac53d0415  mov edi, edi
000076bac53d0417  mov [r15+0xC8], rdi
000076bac53d041e  mov eax, [r15+0x108]
000076bac53d0425  sahf
000076bac53d0426  jnz 0x000076BAC53D0458
000076bac53d0428  cmp dword ptr [r15+0x318], 0x00
000076bac53d0430  jz 0x000076BAC53D04A0
000076bac53d0436  nop [rax+rax*1], ax
000076bac53d043f  nop [rax+rax*1], eax
000076bac53d0447  mov eax, 0x41094C
000076bac53d044c  mov [r15+0x100], rax
000076bac53d0453  jmp 0x000076BAC51FE110
000076bac53d0458  cmp dword ptr [r15+0x318], 0x00
000076bac53d0460  jz 0x000076BAC53D0270
000076bac53d0466  nop [rax+rax*1], ax
000076bac53d046f  nop [rax+rax*1], eax
000076bac53d0477  mov eax, 0x4108C0
000076bac53d047c  mov [r15+0x100], rax
000076bac53d0483  jmp 0x000076BAC51FE110
000076bac53d0488  int3
000076bac53d0489  call 0x000076BAC5249010
000076bac53d048e  jmp 0x000076BAC53D031F
000076bac53d0493  call 0x000076BAC5225930
000076bac53d0498  jmp 0x000076BAC53D035C
000076bac53d049d  int3
000076bac53d049e  nop
000076bac53d04a0  mov eax, [r15+0x98]
000076bac53d04a7  mov r14d, [r15+0x70]
000076bac53d04ab  lea r12d, [eax+r14d*1]
000076bac53d04b0  mov eax, [r15+0x28]
000076bac53d04b4  mov r14d, [r15+0x68]
000076bac53d04b8  lea r11d, [eax+r14d*1]
000076bac53d04bd  mov qword ptr [r15+0x88], 0x00
000076bac53d04c8  mov eax, [r15+0xA8]
000076bac53d04cf  mov r14d, [r15+0x78]
000076bac53d04d3  lea r10d, [eax+r14d*1]
000076bac53d04d8  mov [rsp+0x10], r10d
000076bac53d04dd  mov r10d, r10d
000076bac53d04e0  mov [r15+0x78], r10
000076bac53d04e4  mov eax, [r15+0x38]
000076bac53d04e8  mov r14d, [r15+0x80]
000076bac53d04ef  lea r10d, [eax+r14d*1]
000076bac53d04f4  mov [rsp+0x20], r10d
000076bac53d04f9  mov r10d, r10d
000076bac53d04fc  mov [r15+0x80], r10
000076bac53d0503  mov rax, [r15]
000076bac53d0506  lea r14, [rax+0x08]
000076bac53d050a  mov [r13+r14*1], r12d
000076bac53d050f  lea r14, [rax+0x0C]
000076bac53d0513  mov [r13+r14*1], r11d
000076bac53d0518  mov r14d, [r15+0xB8]
000076bac53d051f  mov r12d, [r15+0x18]
000076bac53d0523  lea r11d, [r14d+r12d*1]
000076bac53d0528  mov [rsp+0x30], r11d
000076bac53d052d  mov r11d, r11d
000076bac53d0530  mov [r15+0x68], r11
000076bac53d0534  mov r14d, [r15+0x30]
000076bac53d0538  mov r12d, [r15+0x90]
000076bac53d053f  lea r11d, [r14d+r12d*1]
000076bac53d0544  mov [rsp+0x40], r11d
000076bac53d0549  mov r11d, r11d
000076bac53d054c  mov [r15+0x70], r11
000076bac53d0550  mov r14d, [r15+0x20]
000076bac53d0554  mov r12d, [r15+0x58]
000076bac53d0558  lea r11d, [r14d+r12d*1]
000076bac53d055d  mov [rsp+0x50], r11d
000076bac53d0562  mov r11d, r11d
000076bac53d0565  mov [r15+0x58], r11
000076bac53d0569  mov r14d, [r15+0xA0]
000076bac53d0570  mov r12d, [r15+0x60]
000076bac53d0574  lea r11d, [r14d+r12d*1]
000076bac53d0579  mov [rsp+0x60], r11d
000076bac53d057e  mov r11d, r11d
000076bac53d0581  mov [r15+0x60], r11
000076bac53d0585  mov r14d, [rsp+0x10]
000076bac53d058a  mov [r13+rax*1], r14d
000076bac53d058f  lea r14, [rax+0x04]
000076bac53d0593  mov r12d, [rsp+0x20]
000076bac53d0598  mov [r13+r14*1], r12d
000076bac53d059d  lea r14, [rax+0x10]
000076bac53d05a1  mov r12d, [rsp+0x30]
000076bac53d05a6  mov [r13+r14*1], r12d
000076bac53d05ab  lea r14, [rax+0x14]
000076bac53d05af  mov r12d, [rsp+0x40]
000076bac53d05b4  mov [r13+r14*1], r12d
000076bac53d05b9  lea r14, [rax+0x18]
000076bac53d05bd  mov r12d, [rsp+0x50]
000076bac53d05c2  mov [r13+r14*1], r12d
000076bac53d05c7  lea r14, [rax+0x1C]
000076bac53d05cb  mov r12d, [rsp+0x60]
000076bac53d05d0  mov [r13+r14*1], r12d
000076bac53d05d5  lea r14, [rax+0x68]
000076bac53d05d9  xor eax, eax
000076bac53d05db  mov [r13+r14*1], rax
000076bac53d05e0  cmp dword ptr [r15+0x318], 0x00
000076bac53d05e8  jz 0x000076BAC53CF0E0
000076bac53d05ee  nop [rax+rax*1], ax
000076bac53d05f7  nop [rax+rax*1], eax
000076bac53d05ff  mov eax, 0x410768
000076bac53d0604  mov [r15+0x100], rax
000076bac53d060b  jmp 0x000076BAC51FE110
000076bac53d0610  int3
000076bac53d0611  call 0x000076BAC52E2BA0
000076bac53d0616  jmp 0x000076BAC53D050F
000076bac53d061b  call 0x000076BAC52E1920
000076bac53d0620  jmp 0x000076BAC53D0518
000076bac53d0625  call 0x000076BAC520DFE0
000076bac53d062a  jmp 0x000076BAC53D058F
000076bac53d062f  call 0x000076BAC52E2BA0
000076bac53d0634  jmp 0x000076BAC53D059D
000076bac53d0639  call 0x000076BAC52E2BA0
000076bac53d063e  jmp 0x000076BAC53D05AB
000076bac53d0643  call 0x000076BAC52E2BA0
000076bac53d0648  jmp 0x000076BAC53D05B9
000076bac53d064d  call 0x000076BAC52E2BA0
000076bac53d0652  jmp 0x000076BAC53D05C7
000076bac53d0657  call 0x000076BAC52E2BA0
000076bac53d065c  jmp 0x000076BAC53D05D5
000076bac53d0661  call 0x000076BAC52D5EB0
000076bac53d0666  jmp 0x000076BAC53D05E0
000076bac53d066b  int3
000076bac53d066c  nop [rax], eax
000076bac53d0670  mov rax, [r15+0xF8]
000076bac53d0677  lea r14, [rax+0x140]
000076bac53d067e  mov r12, [r13+r14*1]
000076bac53d0683  lea r14, [rax+0x148]
000076bac53d068a  mov r11, [r13+r14*1]
000076bac53d068f  mov [r15+0xA0], r12
000076bac53d0696  mov [r15+0x98], r11
000076bac53d069d  lea r14, [rax+0x130]
000076bac53d06a4  mov r12, [r13+r14*1]
000076bac53d06a9  lea r14, [rax+0x138]
000076bac53d06b0  mov r11, [r13+r14*1]
000076bac53d06b5  mov [r15+0xB0], r12
000076bac53d06bc  mov [r15+0xA8], r11
000076bac53d06c3  lea r14, [rax+0x120]
000076bac53d06ca  mov r12, [r13+r14*1]
000076bac53d06cf  lea r14, [rax+0x128]
000076bac53d06d6  mov r11, [r13+r14*1]
000076bac53d06db  mov [r15+0xC0], r12
000076bac53d06e2  mov [r15+0xB8], r11
000076bac53d06e9  lea r14, [rax+0x110]
000076bac53d06f0  mov r12, [r13+r14*1]
000076bac53d06f5  lea r14, [rax+0x118]
000076bac53d06fc  mov r11, [r13+r14*1]
000076bac53d0701  mov [r15+0xD0], r12
000076bac53d0708  mov [r15+0xC8], r11
000076bac53d070f  lea r14, [rax+0x100]
000076bac53d0716  mov r12, [r13+r14*1]
000076bac53d071b  lea r14, [rax+0x108]
000076bac53d0722  mov r11, [r13+r14*1]
000076bac53d0727  mov [r15+0xE8], r12
000076bac53d072e  mov [r15+0xD8], r11
000076bac53d0735  lea r14, [rax+0x150]
000076bac53d073c  mov [r15+0xF8], r14
000076bac53d0743  mov rax, [r15+0xF0]
000076bac53d074a  mov [r15+0x100], rax
000076bac53d0751  jmp 0x000076BAC53CE5C0
000076bac53d0756  int3
000076bac53d0757  call 0x000076BAC52E27E0
000076bac53d075c  jmp 0x000076BAC53D0683
000076bac53d0761  call 0x000076BAC52E1570
000076bac53d0766  jmp 0x000076BAC53D068F
000076bac53d076b  call 0x000076BAC52E27E0
000076bac53d0770  jmp 0x000076BAC53D06A9
000076bac53d0775  call 0x000076BAC52E1570
000076bac53d077a  jmp 0x000076BAC53D06B5
000076bac53d077f  call 0x000076BAC52E27E0
000076bac53d0784  jmp 0x000076BAC53D06CF
000076bac53d0789  call 0x000076BAC52E1570
000076bac53d078e  jmp 0x000076BAC53D06DB
000076bac53d0793  call 0x000076BAC52E27E0
000076bac53d0798  jmp 0x000076BAC53D06F5
000076bac53d079d  call 0x000076BAC52E1570
000076bac53d07a2  jmp 0x000076BAC53D0701
000076bac53d07a7  call 0x000076BAC52E27E0
000076bac53d07ac  jmp 0x000076BAC53D071B
000076bac53d07b1  call 0x000076BAC52E1570
000076bac53d07b6  jmp 0x000076BAC53D0727
000076bac53d07bb  int3
000076bac53d07bc  nop [rax], eax
000076bac53d07c0  mov eax, [r15+0xA0]
000076bac53d07c7  mov [rsp+0x10], eax
000076bac53d07cb  xor eax, eax
000076bac53d07cd  mov r14d, [rsp+0x10]
000076bac53d07d2  sub r14d, 0x01
000076bac53d07d6  cmc
000076bac53d07d7  lahf
000076bac53d07d8  seto al
000076bac53d07db  mov [r15+0x108], eax
000076bac53d07e2  mov r14d, r14d
000076bac53d07e5  mov [r15+0xA0], r14
000076bac53d07ec  mov eax, [r15+0x108]
000076bac53d07f3  sahf
000076bac53d07f4  jnz 0x000076BAC53D0826
000076bac53d07f6  cmp dword ptr [r15+0x318], 0x00
000076bac53d07fe  jz 0x000076BAC53D0900
000076bac53d0804  nop [rax+rax*1], ax
000076bac53d080d  nop [rax+rax*1], eax
000076bac53d0815  mov eax, 0x41028C
000076bac53d081a  mov [r15+0x100], rax
000076bac53d0821  jmp 0x000076BAC51FE110
000076bac53d0826  cmp dword ptr [r15+0x318], 0x00
000076bac53d082e  jz 0x000076BAC53D0860
000076bac53d0834  nop [rax+rax*1], ax
000076bac53d083d  nop [rax+rax*1], eax
000076bac53d0845  mov eax, 0x410274
000076bac53d084a  mov [r15+0x100], rax
000076bac53d0851  jmp 0x000076BAC51FE110
000076bac53d0856  int3
000076bac53d0857  int3
000076bac53d0858  nop [rax+rax*1], eax
000076bac53d0860  mov rax, [r15+0xF8]
000076bac53d0867  lea r14, [rax+0x100]
000076bac53d086e  mov [r15], r14
000076bac53d0871  mov rax, [r15+0x98]
000076bac53d0878  mov [r15+0x08], rax
000076bac53d087c  mov qword ptr [r15+0x10], 0x12C
000076bac53d0884  mov qword ptr [r15+0xF0], 0x410284
000076bac53d088f  mov r14d, [r15+0x320]
000076bac53d0896  mov eax, 0x410284
000076bac53d089b  mov rcx, 0x76BAC53D07C0
000076bac53d08a5  mov [r15+r14*8+0x328], rax
000076bac53d08ad  mov [r15+r14*8+0x368], rcx
000076bac53d08b5  add r14d, 0x01
000076bac53d08b9  and r14d, 0x07
000076bac53d08bd  mov [r15+0x320], r14d
000076bac53d08c4  cmp dword ptr [r15+0x318], 0x00
000076bac53d08cc  jz 0x000076BAC53CED70
000076bac53d08d2  nop [rax+rax*1], ax
000076bac53d08db  nop [rax+rax*1], eax
000076bac53d08e3  mov eax, 0x410728
000076bac53d08e8  mov [r15+0x100], rax
000076bac53d08ef  jmp 0x000076BAC51FE110
000076bac53d08f4  int3
000076bac53d08f5  int3
000076bac53d08f6  nop [rax+rax*1], ax
000076bac53d08ff  nop
000076bac53d0900  mov rax, [r15+0xF8]
000076bac53d0907  lea r14, [rax+0x120]
000076bac53d090e  mov r12, [r13+r14*1]
000076bac53d0913  mov [r15+0x98], r12
000076bac53d091a  mov qword ptr [r15+0x40], 0x80
000076bac53d0922  lea r14, [rax+0x100]
000076bac53d0929  mov [r15], r14
000076bac53d092c  lea r14, [rax+0x17C]
000076bac53d0933  mov [r15+0x08], r14
000076bac53d0937  mov qword ptr [r15+0x10], 0x01
000076bac53d093f  lea r14, [rax+0x17C]
000076bac53d0946  mov eax, 0x80
000076bac53d094b  mov [r13+r14*1], al
000076bac53d0950  mov qword ptr [r15+0xF0], 0x4102A8
000076bac53d095b  mov r14d, [r15+0x320]
000076bac53d0962  mov eax, 0x4102A8
000076bac53d0967  mov rcx, 0x76BAC53D09E0
000076bac53d0971  mov [r15+r14*8+0x328], rax
000076bac53d0979  mov [r15+r14*8+0x368], rcx
000076bac53d0981  add r14d, 0x01
000076bac53d0985  and r14d, 0x07
000076bac53d0989  mov [r15+0x320], r14d
000076bac53d0990  cmp dword ptr [r15+0x318], 0x00
000076bac53d0998  jz 0x000076BAC53CED70
000076bac53d099e  nop [rax+rax*1], ax
000076bac53d09a7  nop [rax+rax*1], eax
000076bac53d09af  mov eax, 0x410728
000076bac53d09b4  mov [r15+0x100], rax
000076bac53d09bb  jmp 0x000076BAC51FE110
000076bac53d09c0  int3
000076bac53d09c1  call 0x000076BAC52E27E0
000076bac53d09c6  jmp 0x000076BAC53D0913
000076bac53d09cb  call 0x000076BAC52D5AF0
000076bac53d09d0  jmp 0x000076BAC53D0950
000076bac53d09d5  int3
000076bac53d09d6  nop [rax+rax*1], ax
000076bac53d09df  nop
000076bac53d09e0  mov rax, [r15+0xF8]
000076bac53d09e7  lea r14, [rax+0x168]
000076bac53d09ee  mov r12, [r13+r14*1]
000076bac53d09f3  mov [r15+0x40], r12
000076bac53d09f7  lea r14, [rax+0x178]
000076bac53d09fe  xor eax, eax
000076bac53d0a00  mov [r13+r14*1], al
000076bac53d0a05  xor eax, eax
000076bac53d0a07  mov r14d, 0x38
000076bac53d0a0d  cmp r12, r14
000076bac53d0a10  cmc
000076bac53d0a11  lahf
000076bac53d0a12  seto al
000076bac53d0a15  mov [r15+0x108], eax
000076bac53d0a1c  mov eax, [r15+0x108]
000076bac53d0a23  sahf
000076bac53d0a24  jz 0x000076BAC53D0A56
000076bac53d0a26  cmp dword ptr [r15+0x318], 0x00
000076bac53d0a2e  jz 0x000076BAC53D0AA0
000076bac53d0a34  nop [rax+rax*1], ax
000076bac53d0a3d  nop [rax+rax*1], eax
000076bac53d0a45  mov eax, 0x4102B8
000076bac53d0a4a  mov [r15+0x100], rax
000076bac53d0a51  jmp 0x000076BAC51FE110
000076bac53d0a56  cmp dword ptr [r15+0x318], 0x00
000076bac53d0a5e  jz 0x000076BAC53D0BF0
000076bac53d0a64  nop [rax+rax*1], ax
000076bac53d0a6d  nop [rax+rax*1], eax
000076bac53d0a75  mov eax, 0x4102D4
000076bac53d0a7a  mov [r15+0x100], rax
000076bac53d0a81  jmp 0x000076BAC51FE110
000076bac53d0a86  int3
000076bac53d0a87  call 0x000076BAC52E27E0
000076bac53d0a8c  jmp 0x000076BAC53D09F3
000076bac53d0a91  call 0x000076BAC52D5AF0
000076bac53d0a96  jmp 0x000076BAC53D0A05
000076bac53d0a9b  int3
000076bac53d0a9c  nop [rax], eax
000076bac53d0aa0  mov rax, [r15+0xF8]
000076bac53d0aa7  lea r14, [rax+0x100]
000076bac53d0aae  mov [r15], r14
000076bac53d0ab1  lea r14, [rax+0x178]
000076bac53d0ab8  mov [r15+0x08], r14
000076bac53d0abc  mov qword ptr [r15+0x10], 0x01
000076bac53d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000076bac53d0acf  mov r14d, [r15+0x320]
000076bac53d0ad6  mov eax, 0x4102C8
000076bac53d0adb  mov rcx, 0x76BAC53D0B40
000076bac53d0ae5  mov [r15+r14*8+0x328], rax
000076bac53d0aed  mov [r15+r14*8+0x368], rcx
000076bac53d0af5  add r14d, 0x01
000076bac53d0af9  and r14d, 0x07
000076bac53d0afd  mov [r15+0x320], r14d
000076bac53d0b04  cmp dword ptr [r15+0x318], 0x00
000076bac53d0b0c  jz 0x000076BAC53CED70
000076bac53d0b12  nop [rax+rax*1], ax
000076bac53d0b1b  nop [rax+rax*1], eax
000076bac53d0b23  mov eax, 0x410728
000076bac53d0b28  mov [r15+0x100], rax
000076bac53d0b2f  jmp 0x000076BAC51FE110
000076bac53d0b34  int3
000076bac53d0b35  int3
000076bac53d0b36  nop [rax+rax*1], ax
000076bac53d0b3f  nop
000076bac53d0b40  mov rax, [r15+0xF8]
000076bac53d0b47  lea r14, [rax+0x168]
000076bac53d0b4e  mov rax, [r13+r14*1]
000076bac53d0b53  mov [r15+0x40], rax
000076bac53d0b57  mov [rsp+0x10], rax
000076bac53d0b5c  xor eax, eax
000076bac53d0b5e  mov r14, [rsp+0x10]
000076bac53d0b63  mov r12d, 0x38
000076bac53d0b69  cmp r14, r12
000076bac53d0b6c  cmc
000076bac53d0b6d  lahf
000076bac53d0b6e  seto al
000076bac53d0b71  mov [r15+0x108], eax
000076bac53d0b78  mov eax, [r15+0x108]
000076bac53d0b7f  sahf
000076bac53d0b80  jnz 0x000076BAC53D0BB2
000076bac53d0b82  cmp dword ptr [r15+0x318], 0x00
000076bac53d0b8a  jz 0x000076BAC53D0BF0
000076bac53d0b90  nop [rax+rax*1], ax
000076bac53d0b99  nop [rax+rax*1], eax
000076bac53d0ba1  mov eax, 0x4102D4
000076bac53d0ba6  mov [r15+0x100], rax
000076bac53d0bad  jmp 0x000076BAC51FE110
000076bac53d0bb2  cmp dword ptr [r15+0x318], 0x00
000076bac53d0bba  jz 0x000076BAC53D0AA0
000076bac53d0bc0  nop [rax+rax*1], ax
000076bac53d0bc9  nop [rax+rax*1], eax
000076bac53d0bd1  mov eax, 0x4102B8
000076bac53d0bd6  mov [r15+0x100], rax
000076bac53d0bdd  jmp 0x000076BAC51FE110
000076bac53d0be2  int3
000076bac53d0be3  call 0x000076BAC52D59C0
000076bac53d0be8  jmp 0x000076BAC53D0B53
000076bac53d0bed  int3
000076bac53d0bee  nop
000076bac53d0bf0  mov rax, [r15+0x98]
000076bac53d0bf7  rorx r14, rax, 0x3D
000076bac53d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000076bac53d0c01  mov rax, [r15+0xF8]
000076bac53d0c08  lea r12, [rax+0x100]
000076bac53d0c0f  mov [r15], r12
000076bac53d0c12  lea r12, [rax+0x170]
000076bac53d0c19  mov [r15+0x08], r12
000076bac53d0c1d  mov qword ptr [r15+0x10], 0x08
000076bac53d0c25  bswap r14
000076bac53d0c28  mov [r15+0x40], r14
000076bac53d0c2c  lea r12, [rax+0x170]
000076bac53d0c33  mov [r13+r12*1], r14
000076bac53d0c38  mov qword ptr [r15+0xF0], 0x4102F0
000076bac53d0c43  mov r14d, [r15+0x320]
000076bac53d0c4a  mov eax, 0x4102F0
000076bac53d0c4f  mov rcx, 0x76BAC53D0CC0
000076bac53d0c59  mov [r15+r14*8+0x328], rax
000076bac53d0c61  mov [r15+r14*8+0x368], rcx
000076bac53d0c69  add r14d, 0x01
000076bac53d0c6d  and r14d, 0x07
000076bac53d0c71  mov [r15+0x320], r14d
000076bac53d0c78  cmp dword ptr [r15+0x318], 0x00
000076bac53d0c80  jz 0x000076BAC53CED70
000076bac53d0c86  nop [rax+rax*1], ax
000076bac53d0c8f  nop [rax+rax*1], eax
000076bac53d0c97  mov eax, 0x410728
000076bac53d0c9c  mov [r15+0x100], rax
000076bac53d0ca3  jmp 0x000076BAC51FE110
000076bac53d0ca8  int3
000076bac53d0ca9  call 0x000076BAC52C3FE0
000076bac53d0cae  jmp 0x000076BAC53D0C38
000076bac53d0cb3  int3
000076bac53d0cb4  nop [rax+rax*1], ax
000076bac53d0cbd  nop [rax], eax
000076bac53d0cc0  mov rax, [r15+0xF8]
000076bac53d0cc7  lea r14, [rax+0x100]
000076bac53d0cce  mov r12d, [r13+r14*1]
000076bac53d0cd3  lea r14, [rax+0x104]
000076bac53d0cda  mov r11d, [r13+r14*1]
000076bac53d0cdf  mov qword ptr [r15+0x48], 0x430C90
000076bac53d0ce7  lea r14, [rax+0x108]
000076bac53d0cee  mov r10d, [r13+r14*1]
000076bac53d0cf3  lea r14, [rax+0x10C]
000076bac53d0cfa  mov r9d, [r13+r14*1]
000076bac53d0cff  bswap r12d
000076bac53d0d02  bswap r11d
000076bac53d0d05  mov qword ptr [r15+0xA0], 0x00
000076bac53d0d10  mov r14d, 0x430C90
000076bac53d0d16  mov [r13+r14*1], r12d
000076bac53d0d1b  mov r14d, 0x430C94
000076bac53d0d21  mov [r13+r14*1], r11d
000076bac53d0d26  bswap r10d
000076bac53d0d29  lea r14, [rax+0x110]
000076bac53d0d30  mov r12d, [r13+r14*1]
000076bac53d0d35  bswap r9d
000076bac53d0d38  lea r14, [rax+0x114]
000076bac53d0d3f  mov r11d, [r13+r14*1]
000076bac53d0d44  mov qword ptr [r15+0x98], 0x430DFC
000076bac53d0d4f  mov r14d, 0x430C98
000076bac53d0d55  mov [r13+r14*1], r10d
000076bac53d0d5a  mov r14d, 0x430C9C
000076bac53d0d60  mov [r13+r14*1], r9d
000076bac53d0d65  bswap r12d
000076bac53d0d68  lea r14, [rax+0x118]
000076bac53d0d6f  mov r10d, [r13+r14*1]
000076bac53d0d74  bswap r11d
000076bac53d0d77  mov [rsp+0x10], r11d
000076bac53d0d7c  mov r11d, r11d
000076bac53d0d7f  mov [r15+0x58], r11
000076bac53d0d83  lea r14, [rax+0x11C]
000076bac53d0d8a  mov eax, [r13+r14*1]
000076bac53d0d8f  mov [rsp+0x20], eax
000076bac53d0d93  mov eax, eax
000076bac53d0d95  mov [r15+0x60], rax
000076bac53d0d99  mov eax, 0x430CA0
000076bac53d0d9e  mov [r13+rax*1], r12d
000076bac53d0da3  mov eax, 0x430CA4
000076bac53d0da8  mov r14d, [rsp+0x10]
000076bac53d0dad  mov [r13+rax*1], r14d
000076bac53d0db2  bswap r10d
000076bac53d0db5  mov [rsp+0x10], r10d
000076bac53d0dba  mov r10d, r10d
000076bac53d0dbd  mov [r15+0x40], r10
000076bac53d0dc1  mov eax, [rsp+0x20]
000076bac53d0dc5  bswap eax
000076bac53d0dc7  mov [rsp+0x20], eax
000076bac53d0dcb  mov eax, eax
000076bac53d0dcd  mov [r15+0x50], rax
000076bac53d0dd1  mov eax, 0x430CA8
000076bac53d0dd6  mov r14d, [rsp+0x10]
000076bac53d0ddb  mov [r13+rax*1], r14d
000076bac53d0de0  mov eax, 0x430CAC
000076bac53d0de5  mov r14d, [rsp+0x20]
000076bac53d0dea  mov [r13+rax*1], r14d
000076bac53d0def  mov eax, [r15+0xA0]
000076bac53d0df6  lea r14d, [eax+0x11]
000076bac53d0dfb  mov r14d, r14d
000076bac53d0dfe  mov [r15], r14
000076bac53d0e01  mov qword ptr [r15+0xF0], 0x41035C
000076bac53d0e0c  mov r14d, [r15+0x320]
000076bac53d0e13  mov eax, 0x41035C
000076bac53d0e18  mov rcx, 0x76BAC53D0F90
000076bac53d0e22  mov [r15+r14*8+0x328], rax
000076bac53d0e2a  mov [r15+r14*8+0x368], rcx
000076bac53d0e32  add r14d, 0x01
000076bac53d0e36  and r14d, 0x07
000076bac53d0e3a  mov [r15+0x320], r14d
000076bac53d0e41  cmp dword ptr [r15+0x318], 0x00
000076bac53d0e49  jz 0x000076BAC53D0F20
000076bac53d0e4f  nop [rax+rax*1], ax
000076bac53d0e58  nop [rax+rax*1], eax
000076bac53d0e60  mov eax, 0x4109A4
000076bac53d0e65  mov [r15+0x100], rax
000076bac53d0e6c  jmp 0x000076BAC51FE110
000076bac53d0e71  int3
000076bac53d0e72  call 0x000076BAC52E26A0
000076bac53d0e77  jmp 0x000076BAC53D0CD3
000076bac53d0e7c  call 0x000076BAC52E1430
000076bac53d0e81  jmp 0x000076BAC53D0CDF
000076bac53d0e86  call 0x000076BAC52E01C0
000076bac53d0e8b  jmp 0x000076BAC53D0CF3
000076bac53d0e90  call 0x000076BAC52DEF50
000076bac53d0e95  jmp 0x000076BAC53D0CFF
000076bac53d0e9a  call 0x000076BAC52E2BA0
000076bac53d0e9f  jmp 0x000076BAC53D0D1B
000076bac53d0ea4  call 0x000076BAC52E1920
000076bac53d0ea9  jmp 0x000076BAC53D0D26
000076bac53d0eae  call 0x000076BAC52E26A0
000076bac53d0eb3  jmp 0x000076BAC53D0D35
000076bac53d0eb8  call 0x000076BAC52E1430
000076bac53d0ebd  jmp 0x000076BAC53D0D44
000076bac53d0ec2  call 0x000076BAC52E06B0
000076bac53d0ec7  jmp 0x000076BAC53D0D5A
000076bac53d0ecc  call 0x000076BAC52DF440
000076bac53d0ed1  jmp 0x000076BAC53D0D65
000076bac53d0ed6  call 0x000076BAC52E01C0
000076bac53d0edb  jmp 0x000076BAC53D0D74
000076bac53d0ee0  call 0x000076BAC52D5890
000076bac53d0ee5  jmp 0x000076BAC53D0D8F
000076bac53d0eea  call 0x000076BAC520BAE0
000076bac53d0eef  jmp 0x000076BAC53D0DA3
000076bac53d0ef4  call 0x000076BAC520DFE0
000076bac53d0ef9  jmp 0x000076BAC53D0DB2
000076bac53d0efe  call 0x000076BAC520DFE0
000076bac53d0f03  jmp 0x000076BAC53D0DE0
000076bac53d0f08  call 0x000076BAC520DFE0
000076bac53d0f0d  jmp 0x000076BAC53D0DEF
000076bac53d0f12  int3
000076bac53d0f13  nop [rax+rax*1], ax
000076bac53d0f1c  nop [rax], eax
000076bac53d0f20  mov eax, [r15]
000076bac53d0f23  mov [rsp+0x10], eax
000076bac53d0f27  shr eax, 0x10
000076bac53d0f2a  mov r14d, [rsp+0x10]
000076bac53d0f2f  xor r14d, eax
000076bac53d0f32  imul r14d, r14d, 0x7FEB352D
000076bac53d0f39  mov eax, 0x846CA68B
000076bac53d0f3e  mov eax, eax
000076bac53d0f40  mov [r15+0x48], rax
000076bac53d0f44  mov [rsp+0x10], r14d
000076bac53d0f49  shr r14d, 0x0F
000076bac53d0f4d  mov eax, [rsp+0x10]
000076bac53d0f51  xor eax, r14d
000076bac53d0f54  imul eax, eax, 0x846CA68B
000076bac53d0f5a  mov [rsp+0x10], eax
000076bac53d0f5e  mov eax, eax
000076bac53d0f60  mov [r15+0x40], rax
000076bac53d0f64  mov eax, [rsp+0x10]
000076bac53d0f68  shr eax, 0x10
000076bac53d0f6b  mov r14d, [rsp+0x10]
000076bac53d0f70  xor r14d, eax
000076bac53d0f73  mov r14d, r14d
000076bac53d0f76  mov [r15], r14
000076bac53d0f79  mov rax, [r15+0xF0]
000076bac53d0f80  mov [r15+0x100], rax
000076bac53d0f87  jmp 0x000076BAC53CE5C0
000076bac53d0f8c  int3
000076bac53d0f8d  int3
000076bac53d0f8e  nop
000076bac53d0f90  mov rax, [r15+0xA0]
000076bac53d0f97  mov [rsp+0x10], rax
000076bac53d0f9c  shl rax, 0x02
000076bac53d0fa0  mov r14, [r15+0x98]
000076bac53d0fa7  lea r12, [r14+rax*1]
000076bac53d0fab  mov eax, [r15]
000076bac53d0fae  mov [r13+r12*1], eax
000076bac53d0fb3  mov rax, [rsp+0x10]
000076bac53d0fb8  lea r14, [rax+0x01]
000076bac53d0fbc  mov [r15+0xA0], r14
000076bac53d0fc3  xor eax, eax
000076bac53d0fc5  mov r12d, 0x400
000076bac53d0fcb  cmp r14, r12
000076bac53d0fce  cmc
000076bac53d0fcf  lahf
000076bac53d0fd0  seto al
000076bac53d0fd3  mov [r15+0x108], eax
000076bac53d0fda  mov eax, [r15+0x108]
000076bac53d0fe1  sahf
000076bac53d0fe2  jnz 0x000076BAC53D1014
000076bac53d0fe4  cmp dword ptr [r15+0x318], 0x00
000076bac53d0fec  jz 0x000076BAC53D10E0
000076bac53d0ff2  nop [rax+rax*1], ax
000076bac53d0ffb  nop [rax+rax*1], eax
000076bac53d1003  mov eax, 0x41036C
000076bac53d1008  mov [r15+0x100], rax
000076bac53d100f  jmp 0x000076BAC51FE110
000076bac53d1014  cmp dword ptr [r15+0x318], 0x00
000076bac53d101c  jz 0x000076BAC53D1050
000076bac53d1022  nop [rax+rax*1], ax
000076bac53d102b  nop [rax+rax*1], eax
000076bac53d1033  mov eax, 0x410354
000076bac53d1038  mov [r15+0x100], rax
000076bac53d103f  jmp 0x000076BAC51FE110
000076bac53d1044  int3
000076bac53d1045  call 0x000076BAC52B4B70
000076bac53d104a  jmp 0x000076BAC53D0FB3
000076bac53d104f  int3
000076bac53d1050  mov eax, [r15+0xA0]
000076bac53d1057  lea r14d, [eax+0x11]
000076bac53d105c  mov r14d, r14d
000076bac53d105f  mov [r15], r14
000076bac53d1062  mov qword ptr [r15+0xF0], 0x41035C
000076bac53d106d  mov r14d, [r15+0x320]
000076bac53d1074  mov eax, 0x41035C
000076bac53d1079  mov rcx, 0x76BAC53D0F90
000076bac53d1083  mov [r15+r14*8+0x328], rax
000076bac53d108b  mov [r15+r14*8+0x368], rcx
000076bac53d1093  add r14d, 0x01
000076bac53d1097  and r14d, 0x07
000076bac53d109b  mov [r15+0x320], r14d
000076bac53d10a2  cmp dword ptr [r15+0x318], 0x00
000076bac53d10aa  jz 0x000076BAC53D0F20
000076bac53d10b0  nop [rax+rax*1], ax
000076bac53d10b9  nop [rax+rax*1], eax
000076bac53d10c1  mov eax, 0x4109A4
000076bac53d10c6  mov [r15+0x100], rax
000076bac53d10cd  jmp 0x000076BAC51FE110
000076bac53d10d2  int3
000076bac53d10d3  int3
000076bac53d10d4  nop [rax+rax*1], ax
000076bac53d10dd  nop [rax], eax
000076bac53d10e0  mov qword ptr [r15+0x40], 0x01
000076bac53d10e8  cmp dword ptr [r15+0x318], 0x00
000076bac53d10f0  jz 0x000076BAC53D1120
000076bac53d10f6  nop [rax+rax*1], ax
000076bac53d10ff  nop [rax+rax*1], eax
000076bac53d1107  mov eax, 0x410388
000076bac53d110c  mov [r15+0x100], rax
000076bac53d1113  jmp 0x000076BAC51FE110
000076bac53d1118  int3
000076bac53d1119  int3
000076bac53d111a  nop [rax+rax*1], ax
000076bac53d1120  mov rax, [r15+0x40]
000076bac53d1124  mov [rsp+0x10], rax
000076bac53d1129  shl rax, 0x02
000076bac53d112d  mov r14, [r15+0x98]
000076bac53d1134  lea r12, [r14+rax*1]
000076bac53d1138  mov eax, [r13+r12*1]
000076bac53d113d  mov [rsp+0x20], eax
000076bac53d1141  mov eax, eax
000076bac53d1143  mov [r15+0x48], rax
000076bac53d1147  mov rax, [rsp+0x10]
000076bac53d114c  mov [r15+0x50], rax
000076bac53d1150  mov eax, [r15+0x50]
000076bac53d1154  lea r12d, [eax-0x01]
000076bac53d1159  mov r12d, r12d
000076bac53d115c  mov [r15+0x58], r12
000076bac53d1160  mov rax, [r15+0x58]
000076bac53d1164  mov r12d, eax
000076bac53d1167  mov r12d, r12d
000076bac53d116a  shl r12, 0x02
000076bac53d116e  lea rax, [r14+r12*1]
000076bac53d1172  mov r14d, [r13+rax*1]
000076bac53d1177  mov [rsp+0x10], r14d
000076bac53d117c  mov r14d, r14d
000076bac53d117f  mov [r15+0x60], r14
000076bac53d1183  xor eax, eax
000076bac53d1185  mov r14d, [rsp+0x10]
000076bac53d118a  mov r12d, [rsp+0x20]
000076bac53d118f  cmp r14d, r12d
000076bac53d1192  cmc
000076bac53d1193  lahf
000076bac53d1194  seto al
000076bac53d1197  mov [r15+0x108], eax
000076bac53d119e  mov eax, [r15+0x108]
000076bac53d11a5  sahf
000076bac53d11a6  cmc
000076bac53d11a7  jbe 0x000076BAC53D11D9
000076bac53d11a9  cmp dword ptr [r15+0x318], 0x00
000076bac53d11b1  jz 0x000076BAC53D1220
000076bac53d11b7  nop [rax+rax*1], ax
000076bac53d11c0  nop [rax+rax*1], eax
000076bac53d11c8  mov eax, 0x4103A0
000076bac53d11cd  mov [r15+0x100], rax
000076bac53d11d4  jmp 0x000076BAC51FE110
000076bac53d11d9  cmp dword ptr [r15+0x318], 0x00
000076bac53d11e1  jz 0x000076BAC53D14C0
000076bac53d11e7  nop [rax+rax*1], ax
000076bac53d11f0  nop [rax+rax*1], eax
000076bac53d11f8  mov eax, 0x410378
000076bac53d11fd  mov [r15+0x100], rax
000076bac53d1204  jmp 0x000076BAC51FE110
000076bac53d1209  int3
000076bac53d120a  call 0x000076BAC52B4690
000076bac53d120f  jmp 0x000076BAC53D113D
000076bac53d1214  call 0x000076BAC520DAE0
000076bac53d1219  jmp 0x000076BAC53D1177
000076bac53d121e  int3
000076bac53d121f  nop
000076bac53d1220  mov rax, [r15+0x50]
000076bac53d1224  mov [rsp+0x10], rax
000076bac53d1229  shl rax, 0x02
000076bac53d122d  mov r14, [r15+0x98]
000076bac53d1234  lea r12, [r14+rax*1]
000076bac53d1238  mov eax, [r15+0x60]
000076bac53d123c  mov [r13+r12*1], eax
000076bac53d1241  mov rax, [rsp+0x10]
000076bac53d1246  lea r14, [rax-0x01]
000076bac53d124a  mov [r15+0x50], r14
000076bac53d124e  mov rax, [r15+0x58]
000076bac53d1252  test rax, rax
000076bac53d1255  setz al
000076bac53d1258  movzx rax, al
000076bac53d125c  mov [rsp+0x414], al
000076bac53d1263  cmp byte ptr [rsp+0x414], 0x00
000076bac53d126b  jz 0x000076BAC53D129D
000076bac53d126d  cmp dword ptr [r15+0x318], 0x00
000076bac53d1275  jz 0x000076BAC53D12E0
000076bac53d127b  nop [rax+rax*1], ax
000076bac53d1284  nop [rax+rax*1], eax
000076bac53d128c  mov eax, 0x4103AC
000076bac53d1291  mov [r15+0x100], rax
000076bac53d1298  jmp 0x000076BAC51FE110
000076bac53d129d  cmp dword ptr [r15+0x318], 0x00
000076bac53d12a5  jz 0x000076BAC53D13E0
000076bac53d12ab  nop [rax+rax*1], ax
000076bac53d12b4  nop [rax+rax*1], eax
000076bac53d12bc  mov eax, 0x410390
000076bac53d12c1  mov [r15+0x100], rax
000076bac53d12c8  jmp 0x000076BAC51FE110
000076bac53d12cd  int3
000076bac53d12ce  call 0x000076BAC52B4B70
000076bac53d12d3  jmp 0x000076BAC53D1241
000076bac53d12d8  int3
000076bac53d12d9  nop [rax], eax
000076bac53d12e0  cmp dword ptr [r15+0x318], 0x00
000076bac53d12e8  jz 0x000076BAC53D1320
000076bac53d12ee  nop [rax+rax*1], ax
000076bac53d12f7  nop [rax+rax*1], eax
000076bac53d12ff  mov eax, 0x410374
000076bac53d1304  mov [r15+0x100], rax
000076bac53d130b  jmp 0x000076BAC51FE110
000076bac53d1310  int3
000076bac53d1311  int3
000076bac53d1312  nop [rax+rax*1], ax
000076bac53d131b  nop [rax+rax*1], eax
000076bac53d1320  mov qword ptr [r15+0x50], 0x00
000076bac53d1328  mov rax, [r15+0x40]
000076bac53d132c  lea r14, [rax+0x01]
000076bac53d1330  mov [r15+0x40], r14
000076bac53d1334  mov rax, [r15+0x98]
000076bac53d133b  mov r12d, [r15+0x48]
000076bac53d133f  mov [r13+rax*1], r12d
000076bac53d1344  xor eax, eax
000076bac53d1346  mov r12d, 0x400
000076bac53d134c  cmp r14, r12
000076bac53d134f  cmc
000076bac53d1350  lahf
000076bac53d1351  seto al
000076bac53d1354  mov [r15+0x108], eax
000076bac53d135b  mov eax, [r15+0x108]
000076bac53d1362  sahf
000076bac53d1363  jz 0x000076BAC53D1395
000076bac53d1365  cmp dword ptr [r15+0x318], 0x00
000076bac53d136d  jz 0x000076BAC53D1120
000076bac53d1373  nop [rax+rax*1], ax
000076bac53d137c  nop [rax+rax*1], eax
000076bac53d1384  mov eax, 0x410388
000076bac53d1389  mov [r15+0x100], rax
000076bac53d1390  jmp 0x000076BAC51FE110
000076bac53d1395  cmp dword ptr [r15+0x318], 0x00
000076bac53d139d  jz 0x000076BAC53D1580
000076bac53d13a3  nop [rax+rax*1], ax
000076bac53d13ac  nop [rax+rax*1], eax
000076bac53d13b4  mov eax, 0x4103B0
000076bac53d13b9  mov [r15+0x100], rax
000076bac53d13c0  jmp 0x000076BAC51FE110
000076bac53d13c5  int3
000076bac53d13c6  call 0x000076BAC520BAE0
000076bac53d13cb  jmp 0x000076BAC53D1344
000076bac53d13d0  int3
000076bac53d13d1  nop [rax+rax*1], ax
000076bac53d13da  nop [rax+rax*1], ax
000076bac53d13e0  mov eax, [r15+0x50]
000076bac53d13e4  lea r14d, [eax-0x01]
000076bac53d13e9  mov r14d, r14d
000076bac53d13ec  mov [r15+0x58], r14
000076bac53d13f0  mov rax, [r15+0x58]
000076bac53d13f4  mov r14d, eax
000076bac53d13f7  mov r14d, r14d
000076bac53d13fa  shl r14, 0x02
000076bac53d13fe  mov rax, [r15+0x98]
000076bac53d1405  lea r12, [rax+r14*1]
000076bac53d1409  mov eax, [r13+r12*1]
000076bac53d140e  mov [rsp+0x10], eax
000076bac53d1412  mov eax, eax
000076bac53d1414  mov [r15+0x60], rax
000076bac53d1418  mov eax, [r15+0x48]
000076bac53d141c  mov [rsp+0x20], eax
000076bac53d1420  xor eax, eax
000076bac53d1422  mov r14d, [rsp+0x10]
000076bac53d1427  mov r12d, [rsp+0x20]
000076bac53d142c  cmp r14d, r12d
000076bac53d142f  cmc
000076bac53d1430  lahf
000076bac53d1431  seto al
000076bac53d1434  mov [r15+0x108], eax
000076bac53d143b  mov eax, [r15+0x108]
000076bac53d1442  sahf
000076bac53d1443  cmc
000076bac53d1444  jbe 0x000076BAC53D1476
000076bac53d1446  cmp dword ptr [r15+0x318], 0x00
000076bac53d144e  jz 0x000076BAC53D1220
000076bac53d1454  nop [rax+rax*1], ax
000076bac53d145d  nop [rax+rax*1], eax
000076bac53d1465  mov eax, 0x4103A0
000076bac53d146a  mov [r15+0x100], rax
000076bac53d1471  jmp 0x000076BAC51FE110
000076bac53d1476  cmp dword ptr [r15+0x318], 0x00
000076bac53d147e  jz 0x000076BAC53D14C0
000076bac53d1484  nop [rax+rax*1], ax
000076bac53d148d  nop [rax+rax*1], eax
000076bac53d1495  mov eax, 0x410378
000076bac53d149a  mov [r15+0x100], rax
000076bac53d14a1  jmp 0x000076BAC51FE110
000076bac53d14a6  int3
000076bac53d14a7  call 0x000076BAC52B4690
000076bac53d14ac  jmp 0x000076BAC53D140E
000076bac53d14b1  int3
000076bac53d14b2  nop [rax+rax*1], ax
000076bac53d14bb  nop [rax+rax*1], eax
000076bac53d14c0  mov rax, [r15+0x40]
000076bac53d14c4  lea r14, [rax+0x01]
000076bac53d14c8  mov [r15+0x40], r14
000076bac53d14cc  mov rax, [r15+0x50]
000076bac53d14d0  mov r12d, eax
000076bac53d14d3  mov r12d, r12d
000076bac53d14d6  shl r12, 0x02
000076bac53d14da  mov rax, [r15+0x98]
000076bac53d14e1  lea r11, [rax+r12*1]
000076bac53d14e5  mov eax, [r15+0x48]
000076bac53d14e9  mov [r13+r11*1], eax
000076bac53d14ee  xor eax, eax
000076bac53d14f0  mov r12d, 0x400
000076bac53d14f6  cmp r14, r12
000076bac53d14f9  cmc
000076bac53d14fa  lahf
000076bac53d14fb  seto al
000076bac53d14fe  mov [r15+0x108], eax
000076bac53d1505  mov eax, [r15+0x108]
000076bac53d150c  sahf
000076bac53d150d  jz 0x000076BAC53D153F
000076bac53d150f  cmp dword ptr [r15+0x318], 0x00
000076bac53d1517  jz 0x000076BAC53D1120
000076bac53d151d  nop [rax+rax*1], ax
000076bac53d1526  nop [rax+rax*1], eax
000076bac53d152e  mov eax, 0x410388
000076bac53d1533  mov [r15+0x100], rax
000076bac53d153a  jmp 0x000076BAC51FE110
000076bac53d153f  cmp dword ptr [r15+0x318], 0x00
000076bac53d1547  jz 0x000076BAC53D1580
000076bac53d154d  nop [rax+rax*1], ax
000076bac53d1556  nop [rax+rax*1], eax
000076bac53d155e  mov eax, 0x4103B0
000076bac53d1563  mov [r15+0x100], rax
000076bac53d156a  jmp 0x000076BAC51FE110
000076bac53d156f  int3
000076bac53d1570  call 0x000076BAC52A4270
000076bac53d1575  jmp 0x000076BAC53D14EE
000076bac53d157a  int3
000076bac53d157b  nop [rax+rax*1], eax
000076bac53d1580  mov qword ptr [r15+0x40], 0x430000
000076bac53d1588  mov eax, 0x430CB0
000076bac53d158d  mov r14, [r13+rax*1]
000076bac53d1592  mov rax, [r15+0x98]
000076bac53d1599  mov r12d, [r13+rax*1]
000076bac53d159e  lea r11, [rax+0x04]
000076bac53d15a2  mov eax, [r13+r11*1]
000076bac53d15a7  mov r12d, r12d
000076bac53d15aa  mov [r15+0x68], r12
000076bac53d15ae  mov eax, eax
000076bac53d15b0  mov [r15+0x60], rax
000076bac53d15b4  mov rax, [r15+0x68]
000076bac53d15b8  mov [r15+0x68], rax
000076bac53d15bc  mov qword ptr [r15+0x58], 0x02
000076bac53d15c4  mov [rsp+0x10], rax
000076bac53d15c9  xor eax, eax
000076bac53d15cb  mov r12d, 0x02
000076bac53d15d1  mov r11d, 0x400
000076bac53d15d7  cmp r12, r11
000076bac53d15da  cmc
000076bac53d15db  lahf
000076bac53d15dc  seto al
000076bac53d15df  mov [r15+0x108], eax
000076bac53d15e6  mov rax, [r15+0x60]
000076bac53d15ea  mov r12d, 0x02
000076bac53d15f0  imul rax, r12
000076bac53d15f4  mov [r15+0x50], rax
000076bac53d15f8  mov rax, [rsp+0x10]
000076bac53d15fd  lea r12, [rax+r14*1]
000076bac53d1601  mov [r15+0x48], r12
000076bac53d1605  mov eax, [r15+0x108]
000076bac53d160c  sahf
000076bac53d160d  jnz 0x000076BAC53D163F
000076bac53d160f  cmp dword ptr [r15+0x318], 0x00
000076bac53d1617  jz 0x000076BAC53D17B0
000076bac53d161d  nop [rax+rax*1], ax
000076bac53d1626  nop [rax+rax*1], eax
000076bac53d162e  mov eax, 0x4103E0
000076bac53d1633  mov [r15+0x100], rax
000076bac53d163a  jmp 0x000076BAC51FE110
000076bac53d163f  cmp dword ptr [r15+0x318], 0x00
000076bac53d1647  jz 0x000076BAC53D1690
000076bac53d164d  nop [rax+rax*1], ax
000076bac53d1656  nop [rax+rax*1], eax
000076bac53d165e  mov eax, 0x4103C0
000076bac53d1663  mov [r15+0x100], rax
000076bac53d166a  jmp 0x000076BAC51FE110
000076bac53d166f  int3
000076bac53d1670  call 0x000076BAC520DC20
000076bac53d1675  jmp 0x000076BAC53D1592
000076bac53d167a  call 0x000076BAC520B5E0
000076bac53d167f  jmp 0x000076BAC53D159E
000076bac53d1684  call 0x000076BAC52A3D90
000076bac53d1689  jmp 0x000076BAC53D15A7
000076bac53d168e  int3
000076bac53d168f  nop
000076bac53d1690  mov rax, [r15+0x98]
000076bac53d1697  mov r14, [r15+0x58]
000076bac53d169b  mov [rsp+0x10], r14
000076bac53d16a0  shl r14, 0x02
000076bac53d16a4  lea r12, [rax+r14*1]
000076bac53d16a8  mov eax, [r13+r12*1]
000076bac53d16ad  lea r14, [r12+0x04]
000076bac53d16b2  mov r12d, [r13+r14*1]
000076bac53d16b7  mov eax, eax
000076bac53d16b9  mov [r15+0x68], rax
000076bac53d16bd  mov r12d, r12d
000076bac53d16c0  mov [r15+0x60], r12
000076bac53d16c4  mov rax, [r15+0x68]
000076bac53d16c8  mov [rsp+0x20], rax
000076bac53d16cd  mov r14, [rsp+0x10]
000076bac53d16d2  imul rax, r14
000076bac53d16d6  mov r12, [rsp+0x20]
000076bac53d16db  lea r11, [r12+rax*1]
000076bac53d16df  mov [r15+0x68], r11
000076bac53d16e3  lea rax, [r14+0x02]
000076bac53d16e7  mov [r15+0x58], rax
000076bac53d16eb  mov [rsp+0x10], rax
000076bac53d16f0  xor eax, eax
000076bac53d16f2  mov r14, [rsp+0x10]
000076bac53d16f7  mov r12d, 0x400
000076bac53d16fd  cmp r14, r12
000076bac53d1700  cmc
000076bac53d1701  lahf
000076bac53d1702  seto al
000076bac53d1705  mov [r15+0x108], eax
000076bac53d170c  mov rax, [r15+0x50]
000076bac53d1710  mov r12, [r15+0x60]
000076bac53d1714  imul r14, r12
000076bac53d1718  lea r12, [rax+r14*1]
000076bac53d171c  mov [r15+0x50], r12
000076bac53d1720  mov rax, [r15+0x48]
000076bac53d1724  lea r14, [r11+rax*1]
000076bac53d1728  mov [r15+0x48], r14
000076bac53d172c  mov eax, [r15+0x108]
000076bac53d1733  sahf
000076bac53d1734  jnz 0x000076BAC53D1766
000076bac53d1736  cmp dword ptr [r15+0x318], 0x00
000076bac53d173e  jz 0x000076BAC53D17B0
000076bac53d1744  nop [rax+rax*1], ax
000076bac53d174d  nop [rax+rax*1], eax
000076bac53d1755  mov eax, 0x4103E0
000076bac53d175a  mov [r15+0x100], rax
000076bac53d1761  jmp 0x000076BAC51FE110
000076bac53d1766  cmp dword ptr [r15+0x318], 0x00
000076bac53d176e  jz 0x000076BAC53D1690
000076bac53d1774  nop [rax+rax*1], ax
000076bac53d177d  nop [rax+rax*1], eax
000076bac53d1785  mov eax, 0x4103C0
000076bac53d178a  mov [r15+0x100], rax
000076bac53d1791  jmp 0x000076BAC51FE110
000076bac53d1796  int3
000076bac53d1797  call 0x000076BAC52B4690
000076bac53d179c  jmp 0x000076BAC53D16AD
000076bac53d17a1  call 0x000076BAC52E26A0
000076bac53d17a6  jmp 0x000076BAC53D16B7
000076bac53d17ab  int3
000076bac53d17ac  nop [rax], eax
000076bac53d17b0  mov qword ptr [r15+0x98], 0x00
000076bac53d17bb  mov rax, [r15+0x50]
000076bac53d17bf  mov r14, [r15+0x48]
000076bac53d17c3  lea r12, [rax+r14*1]
000076bac53d17c7  mov [r15+0x48], r12
000076bac53d17cb  mov rax, [r15+0x40]
000076bac53d17cf  lea r14, [rax+0xCB0]
000076bac53d17d6  mov [r13+r14*1], r12
000076bac53d17db  mov qword ptr [r15], 0x01
000076bac53d17e2  mov qword ptr [r15+0xF0], 0x4103F8
000076bac53d17ed  mov r14d, [r15+0x320]
000076bac53d17f4  mov eax, 0x4103F8
000076bac53d17f9  mov rcx, 0x76BAC53D1860
000076bac53d1803  mov [r15+r14*8+0x328], rax
000076bac53d180b  mov [r15+r14*8+0x368], rcx
000076bac53d1813  add r14d, 0x01
000076bac53d1817  and r14d, 0x07
000076bac53d181b  mov [r15+0x320], r14d
000076bac53d1822  cmp dword ptr [r15+0x318], 0x00
000076bac53d182a  jz 0x000076BAC53D0F20
000076bac53d1830  nop [rax+rax*1], ax
000076bac53d1839  nop [rax+rax*1], eax
000076bac53d1841  mov eax, 0x4109A4
000076bac53d1846  mov [r15+0x100], rax
000076bac53d184d  jmp 0x000076BAC51FE110
000076bac53d1852  int3
000076bac53d1853  call 0x000076BAC52E2CE0
000076bac53d1858  jmp 0x000076BAC53D17DB
000076bac53d185d  int3
000076bac53d185e  nop
000076bac53d1860  mov eax, [r15+0x98]
000076bac53d1867  lea r14d, [eax+0x01]
000076bac53d186c  mov [rsp+0x10], r14d
000076bac53d1871  mov r14d, r14d
000076bac53d1874  mov [r15+0x98], r14
000076bac53d187b  xor eax, eax
000076bac53d187d  mov r14d, [rsp+0x10]
000076bac53d1882  cmp r14d, 0x10000
000076bac53d1889  cmc
000076bac53d188a  lahf
000076bac53d188b  seto al
000076bac53d188e  mov [r15+0x108], eax
000076bac53d1895  mov eax, [r15+0x108]
000076bac53d189c  sahf
000076bac53d189d  jnz 0x000076BAC53D18CF
000076bac53d189f  cmp dword ptr [r15+0x318], 0x00
000076bac53d18a7  jz 0x000076BAC53D19A0
000076bac53d18ad  nop [rax+rax*1], ax
000076bac53d18b6  nop [rax+rax*1], eax
000076bac53d18be  mov eax, 0x410404
000076bac53d18c3  mov [r15+0x100], rax
000076bac53d18ca  jmp 0x000076BAC51FE110
000076bac53d18cf  cmp dword ptr [r15+0x318], 0x00
000076bac53d18d7  jz 0x000076BAC53D1910
000076bac53d18dd  nop [rax+rax*1], ax
000076bac53d18e6  nop [rax+rax*1], eax
000076bac53d18ee  mov eax, 0x4103F0
000076bac53d18f3  mov [r15+0x100], rax
000076bac53d18fa  jmp 0x000076BAC51FE110
000076bac53d18ff  int3
000076bac53d1900  int3
000076bac53d1901  nop [rax+rax*1], ax
000076bac53d190a  nop [rax+rax*1], ax
000076bac53d1910  mov eax, [r15]
000076bac53d1913  mov r14d, [r15+0x98]
000076bac53d191a  lea r12d, [eax+r14d*1]
000076bac53d191f  mov r12d, r12d
000076bac53d1922  mov [r15], r12
000076bac53d1925  mov qword ptr [r15+0xF0], 0x4103F8
000076bac53d1930  mov r14d, [r15+0x320]
000076bac53d1937  mov eax, 0x4103F8
000076bac53d193c  mov rcx, 0x76BAC53D1860
000076bac53d1946  mov [r15+r14*8+0x328], rax
000076bac53d194e  mov [r15+r14*8+0x368], rcx
000076bac53d1956  add r14d, 0x01
000076bac53d195a  and r14d, 0x07
000076bac53d195e  mov [r15+0x320], r14d
000076bac53d1965  cmp dword ptr [r15+0x318], 0x00
000076bac53d196d  jz 0x000076BAC53D0F20
000076bac53d1973  nop [rax+rax*1], ax
000076bac53d197c  nop [rax+rax*1], eax
000076bac53d1984  mov eax, 0x4109A4
000076bac53d1989  mov [r15+0x100], rax
000076bac53d1990  jmp 0x000076BAC51FE110
000076bac53d1995  int3
000076bac53d1996  int3
000076bac53d1997  nop [rax+rax*1], ax
000076bac53d19a0  vmovaps xmm1, [0x000076BAC4FFE010]
000076bac53d19a8  movq xmm1, xmm1
000076bac53d19ac  movaps [r15+0x110], xmm1
000076bac53d19b4  mov eax, 0x420B10
000076bac53d19b9  mov r14, [r13+rax*1]
000076bac53d19be  movq xmm1, r14
000076bac53d19c3  movaps [r15+0x120], xmm1
000076bac53d19cb  vmovaps xmm1, [0x000076BAC4FFE020]
000076bac53d19d3  movq xmm1, xmm1
000076bac53d19d7  movaps [r15+0x140], xmm1
000076bac53d19df  vmovaps xmm1, [0x000076BAC4FFE030]
000076bac53d19e7  vpbroadcastq xmm1, xmm1
000076bac53d19ec  movaps [r15+0x150], xmm1
000076bac53d19f4  mov qword ptr [r15+0x40], 0x02
000076bac53d19fc  vmovaps xmm15, [0x000076BAC4FFE040]
000076bac53d1a04  movq xmm15, xmm15
000076bac53d1a09  movaps [r15+0x160], xmm15
000076bac53d1a11  vmovaps xmm15, [0x000076BAC4FFE050]
000076bac53d1a19  vpbroadcastq xmm15, xmm15
000076bac53d1a1e  movaps [r15+0x130], xmm15
000076bac53d1a26  mov rax, [r15+0x40]
000076bac53d1a2a  vmovq xmm14, rax
000076bac53d1a2f  vpbroadcastq xmm14, xmm14
000076bac53d1a34  movaps [r15+0x170], xmm14
000076bac53d1a3c  mov eax, 0x420A40
000076bac53d1a41  movups xmm13, [r13+rax*1]
000076bac53d1a47  mov qword ptr [r15+0x40], 0x431E00
000076bac53d1a4f  mov eax, [r15]
000076bac53d1a52  mov r14d, 0x430CB8
000076bac53d1a58  mov [r13+r14*1], eax
000076bac53d1a5d  mov qword ptr [r15+0x50], 0x432000
000076bac53d1a65  vpmovqd xmm12, xmm13
000076bac53d1a6b  pxor xmm11, xmm11
000076bac53d1a70  punpcklqdq xmm12, xmm11
000076bac53d1a75  movaps [r15+0x210], xmm12
000076bac53d1a7d  movq xmm12, qword ptr [r15+0x140]
000076bac53d1a86  movq xmm11, qword ptr [r15+0x120]
000076bac53d1a8f  psubd xmm12, xmm11
000076bac53d1a94  movq xmm12, xmm12
000076bac53d1a99  paddq xmm13, xmm14
000076bac53d1a9e  movaps [r15+0x180], xmm13
000076bac53d1aa6  movq xmm14, qword ptr [r15+0x160]
000076bac53d1aaf  paddd xmm11, xmm14
000076bac53d1ab4  movq xmm11, xmm11
000076bac53d1ab9  movq xmm11, xmm11
000076bac53d1abe  movaps [r15+0x120], xmm11
000076bac53d1ac6  pmovzxdq xmm12, xmm12
000076bac53d1acc  psllq xmm12, 0x00
000076bac53d1ad2  movq xmm14, qword ptr [r15+0x210]
000076bac53d1adb  movq xmm13, qword ptr [r15+0x110]
000076bac53d1ae4  paddd xmm14, xmm13
000076bac53d1ae9  movq xmm14, xmm14
000076bac53d1aee  vcvtuqq2pd xmm12, xmm12
000076bac53d1af4  pmovzxdq xmm14, xmm14
000076bac53d1afa  psllq xmm14, 0x00
000076bac53d1b00  vcvtuqq2pd xmm14, xmm14
000076bac53d1b06  movaps xmm13, xmm12
000076bac53d1b0a  mulpd xmm13, xmm1
000076bac53d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000076bac53d1b15  ptest xmm11, xmm11
000076bac53d1b1b  jnz 0x000076BAC53D1C0F
000076bac53d1b21  movaps [r15+0x220], xmm13
000076bac53d1b29  mov eax, 0x432000
000076bac53d1b2e  movups [r13+rax*1], xmm13
000076bac53d1b34  movaps xmm1, xmm14
000076bac53d1b38  mulpd xmm1, xmm15
000076bac53d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000076bac53d1b42  ptest xmm13, xmm13
000076bac53d1b48  jnz 0x000076BAC53D1D5C
000076bac53d1b4e  movaps [r15+0x210], xmm1
000076bac53d1b56  mov eax, 0x431E00
000076bac53d1b5b  movups [r13+rax*1], xmm1
000076bac53d1b61  mov qword ptr [r15+0x48], 0x10
000076bac53d1b69  xor eax, eax
000076bac53d1b6b  mov r14d, 0x10
000076bac53d1b71  mov r12d, 0x200
000076bac53d1b77  cmp r14, r12
000076bac53d1b7a  cmc
000076bac53d1b7b  lahf
000076bac53d1b7c  seto al
000076bac53d1b7f  mov [r15+0x108], eax
000076bac53d1b86  mov eax, [r15+0x108]
000076bac53d1b8d  sahf
000076bac53d1b8e  jnz 0x000076BAC53D1BC0
000076bac53d1b90  cmp dword ptr [r15+0x318], 0x00
000076bac53d1b98  jz 0x000076BAC53D2300
000076bac53d1b9e  nop [rax+rax*1], ax
000076bac53d1ba7  nop [rax+rax*1], eax
000076bac53d1baf  mov eax, 0x410490
000076bac53d1bb4  mov [r15+0x100], rax
000076bac53d1bbb  jmp 0x000076BAC51FE110
000076bac53d1bc0  cmp dword ptr [r15+0x318], 0x00
000076bac53d1bc8  jz 0x000076BAC53D1EB0
000076bac53d1bce  nop [rax+rax*1], ax
000076bac53d1bd7  nop [rax+rax*1], eax
000076bac53d1bdf  mov eax, 0x410450
000076bac53d1be4  mov [r15+0x100], rax
000076bac53d1beb  jmp 0x000076BAC51FE110
000076bac53d1bf0  int3
000076bac53d1bf1  call 0x000076BAC520DC20
000076bac53d1bf6  jmp 0x000076BAC53D19BE
000076bac53d1bfb  call 0x000076BAC520C260
000076bac53d1c00  jmp 0x000076BAC53D1A47
000076bac53d1c05  call 0x000076BAC52D5D70
000076bac53d1c0a  jmp 0x000076BAC53D1A5D
000076bac53d1c0f  sub rsp, 0x08
000076bac53d1c13  push rax
000076bac53d1c14  push rcx
000076bac53d1c15  push rdx
000076bac53d1c16  push rdi
000076bac53d1c17  push rsi
000076bac53d1c18  push r8
000076bac53d1c1a  push r9
000076bac53d1c1c  push r10
000076bac53d1c1e  push r11
000076bac53d1c20  sub rsp, 0xF0
000076bac53d1c27  vmovaps [rsp], xmm0
000076bac53d1c2c  vmovaps [rsp+0x10], xmm1
000076bac53d1c32  vmovaps [rsp+0x20], xmm2
000076bac53d1c38  vmovaps [rsp+0x30], xmm3
000076bac53d1c3e  vmovaps [rsp+0x40], xmm4
000076bac53d1c44  vmovaps [rsp+0x50], xmm5
000076bac53d1c4a  vmovaps [rsp+0x60], xmm6
000076bac53d1c50  vmovaps [rsp+0x70], xmm7
000076bac53d1c56  vmovaps [rsp+0x80], xmm8
000076bac53d1c5f  vmovaps [rsp+0x90], xmm9
000076bac53d1c68  vmovaps [rsp+0xA0], xmm10
000076bac53d1c71  vmovaps [rsp+0xB0], xmm11
000076bac53d1c7a  vmovaps [rsp+0xC0], xmm12
000076bac53d1c83  vmovaps [rsp+0xD0], xmm14
000076bac53d1c8c  vmovaps [rsp+0xE0], xmm15
000076bac53d1c95  sub rsp, 0x30
000076bac53d1c99  movaps [rsp], xmm13
000076bac53d1c9e  movaps [rsp+0x10], xmm12
000076bac53d1ca4  movaps [rsp+0x20], xmm1
000076bac53d1ca9  lea rdi, [rsp]
000076bac53d1cad  mov esi, 0x00
000076bac53d1cb2  mov rax, 0x5641B0A3C530
000076bac53d1cbc  call rax
000076bac53d1cbe  movaps xmm13, [rsp]
000076bac53d1cc3  add rsp, 0x30
000076bac53d1cc7  vmovaps xmm0, [rsp]
000076bac53d1ccc  vmovaps xmm1, [rsp+0x10]
000076bac53d1cd2  vmovaps xmm2, [rsp+0x20]
000076bac53d1cd8  vmovaps xmm3, [rsp+0x30]
000076bac53d1cde  vmovaps xmm4, [rsp+0x40]
000076bac53d1ce4  vmovaps xmm5, [rsp+0x50]
000076bac53d1cea  vmovaps xmm6, [rsp+0x60]
000076bac53d1cf0  vmovaps xmm7, [rsp+0x70]
000076bac53d1cf6  vmovaps xmm8, [rsp+0x80]
000076bac53d1cff  vmovaps xmm9, [rsp+0x90]
000076bac53d1d08  vmovaps xmm10, [rsp+0xA0]
000076bac53d1d11  vmovaps xmm11, [rsp+0xB0]
000076bac53d1d1a  vmovaps xmm12, [rsp+0xC0]
000076bac53d1d23  vmovaps xmm14, [rsp+0xD0]
000076bac53d1d2c  vmovaps xmm15, [rsp+0xE0]
000076bac53d1d35  add rsp, 0xF0
000076bac53d1d3c  pop r11
000076bac53d1d3e  pop r10
000076bac53d1d40  pop r9
000076bac53d1d42  pop r8
000076bac53d1d44  pop rsi
000076bac53d1d45  pop rdi
000076bac53d1d46  pop rdx
000076bac53d1d47  pop rcx
000076bac53d1d48  pop rax
000076bac53d1d49  add rsp, 0x08
000076bac53d1d4d  jmp 0x000076BAC53D1B21
000076bac53d1d52  call 0x000076BAC520C380
000076bac53d1d57  jmp 0x000076BAC53D1B34
000076bac53d1d5c  sub rsp, 0x08
000076bac53d1d60  push rax
000076bac53d1d61  push rcx
000076bac53d1d62  push rdx
000076bac53d1d63  push rdi
000076bac53d1d64  push rsi
000076bac53d1d65  push r8
000076bac53d1d67  push r9
000076bac53d1d69  push r10
000076bac53d1d6b  push r11
000076bac53d1d6d  sub rsp, 0xF0
000076bac53d1d74  vmovaps [rsp], xmm0
000076bac53d1d79  vmovaps [rsp+0x10], xmm2
000076bac53d1d7f  vmovaps [rsp+0x20], xmm3
000076bac53d1d85  vmovaps [rsp+0x30], xmm4
000076bac53d1d8b  vmovaps [rsp+0x40], xmm5
000076bac53d1d91  vmovaps [rsp+0x50], xmm6
000076bac53d1d97  vmovaps [rsp+0x60], xmm7
000076bac53d1d9d  vmovaps [rsp+0x70], xmm8
000076bac53d1da3  vmovaps [rsp+0x80], xmm9
000076bac53d1dac  vmovaps [rsp+0x90], xmm10
000076bac53d1db5  vmovaps [rsp+0xA0], xmm11
000076bac53d1dbe  vmovaps [rsp+0xB0], xmm12
000076bac53d1dc7  vmovaps [rsp+0xC0], xmm13
000076bac53d1dd0  vmovaps [rsp+0xD0], xmm14
000076bac53d1dd9  vmovaps [rsp+0xE0], xmm15
000076bac53d1de2  sub rsp, 0x30
000076bac53d1de6  movaps [rsp], xmm1
000076bac53d1dea  movaps [rsp+0x10], xmm14
000076bac53d1df0  movaps [rsp+0x20], xmm15
000076bac53d1df6  lea rdi, [rsp]
000076bac53d1dfa  mov esi, 0x00
000076bac53d1dff  mov rax, 0x5641B0A3C530
000076bac53d1e09  call rax
000076bac53d1e0b  movaps xmm1, [rsp]
000076bac53d1e0f  add rsp, 0x30
000076bac53d1e13  vmovaps xmm0, [rsp]
000076bac53d1e18  vmovaps xmm2, [rsp+0x10]
000076bac53d1e1e  vmovaps xmm3, [rsp+0x20]
000076bac53d1e24  vmovaps xmm4, [rsp+0x30]
000076bac53d1e2a  vmovaps xmm5, [rsp+0x40]
000076bac53d1e30  vmovaps xmm6, [rsp+0x50]
000076bac53d1e36  vmovaps xmm7, [rsp+0x60]
000076bac53d1e3c  vmovaps xmm8, [rsp+0x70]
000076bac53d1e42  vmovaps xmm9, [rsp+0x80]
000076bac53d1e4b  vmovaps xmm10, [rsp+0x90]
000076bac53d1e54  vmovaps xmm11, [rsp+0xA0]
000076bac53d1e5d  vmovaps xmm12, [rsp+0xB0]
000076bac53d1e66  vmovaps xmm13, [rsp+0xC0]
000076bac53d1e6f  vmovaps xmm14, [rsp+0xD0]
000076bac53d1e78  vmovaps xmm15, [rsp+0xE0]
000076bac53d1e81  add rsp, 0xF0
000076bac53d1e88  pop r11
000076bac53d1e8a  pop r10
000076bac53d1e8c  pop r9
000076bac53d1e8e  pop r8
000076bac53d1e90  pop rsi
000076bac53d1e91  pop rdi
000076bac53d1e92  pop rdx
000076bac53d1e93  pop rcx
000076bac53d1e94  pop rax
000076bac53d1e95  add rsp, 0x08
000076bac53d1e99  jmp 0x000076BAC53D1B4E
000076bac53d1e9e  call 0x000076BAC51FF540
000076bac53d1ea3  jmp 0x000076BAC53D1B61
000076bac53d1ea8  int3
000076bac53d1ea9  nop [rax], eax
000076bac53d1eb0  movaps xmm1, [r15+0x180]
000076bac53d1eb8  vpmovqd xmm15, xmm1
000076bac53d1ebe  pxor xmm14, xmm14
000076bac53d1ec3  punpcklqdq xmm15, xmm14
000076bac53d1ec8  movaps [r15+0x210], xmm15
000076bac53d1ed0  movq xmm15, qword ptr [r15+0x140]
000076bac53d1ed9  movq xmm14, qword ptr [r15+0x120]
000076bac53d1ee2  psubd xmm15, xmm14
000076bac53d1ee7  movq xmm15, xmm15
000076bac53d1eec  movaps xmm13, [r15+0x170]
000076bac53d1ef4  paddq xmm1, xmm13
000076bac53d1ef9  movaps [r15+0x180], xmm1
000076bac53d1f01  movq xmm1, qword ptr [r15+0x160]
000076bac53d1f0a  paddd xmm14, xmm1
000076bac53d1f0f  movq xmm14, xmm14
000076bac53d1f14  movq xmm14, xmm14
000076bac53d1f19  movaps [r15+0x120], xmm14
000076bac53d1f21  pmovzxdq xmm15, xmm15
000076bac53d1f27  psllq xmm15, 0x00
000076bac53d1f2d  movq xmm1, qword ptr [r15+0x210]
000076bac53d1f36  movq xmm14, qword ptr [r15+0x110]
000076bac53d1f3f  paddd xmm1, xmm14
000076bac53d1f44  movq xmm1, xmm1
000076bac53d1f48  vcvtuqq2pd xmm15, xmm15
000076bac53d1f4e  pmovzxdq xmm1, xmm1
000076bac53d1f53  psllq xmm1, 0x00
000076bac53d1f58  vcvtuqq2pd xmm1, xmm1
000076bac53d1f5e  movaps xmm14, [r15+0x150]
000076bac53d1f66  movaps xmm13, xmm15
000076bac53d1f6a  mulpd xmm13, xmm14
000076bac53d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000076bac53d1f75  ptest xmm12, xmm12
000076bac53d1f7b  jnz 0x000076BAC53D205E
000076bac53d1f81  movaps [r15+0x220], xmm13
000076bac53d1f89  mov rax, [r15+0x48]
000076bac53d1f8d  mov r14, [r15+0x50]
000076bac53d1f91  lea r12, [r14+rax*1]
000076bac53d1f95  movups [r13+r12*1], xmm13
000076bac53d1f9b  movaps xmm15, [r15+0x130]
000076bac53d1fa3  movaps xmm14, xmm1
000076bac53d1fa7  mulpd xmm14, xmm15
000076bac53d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000076bac53d1fb2  ptest xmm13, xmm13
000076bac53d1fb8  jnz 0x000076BAC53D21AC
000076bac53d1fbe  movaps [r15+0x210], xmm14
000076bac53d1fc6  mov r14, [r15+0x40]
000076bac53d1fca  lea r12, [r14+rax*1]
000076bac53d1fce  movups [r13+r12*1], xmm14
000076bac53d1fd4  lea r14, [rax+0x10]
000076bac53d1fd8  mov [r15+0x48], r14
000076bac53d1fdc  xor eax, eax
000076bac53d1fde  mov r12d, 0x200
000076bac53d1fe4  cmp r14, r12
000076bac53d1fe7  cmc
000076bac53d1fe8  lahf
000076bac53d1fe9  seto al
000076bac53d1fec  mov [r15+0x108], eax
000076bac53d1ff3  mov eax, [r15+0x108]
000076bac53d1ffa  sahf
000076bac53d1ffb  jnz 0x000076BAC53D202D
000076bac53d1ffd  cmp dword ptr [r15+0x318], 0x00
000076bac53d2005  jz 0x000076BAC53D2300
000076bac53d200b  nop [rax+rax*1], ax
000076bac53d2014  nop [rax+rax*1], eax
000076bac53d201c  mov eax, 0x410490
000076bac53d2021  mov [r15+0x100], rax
000076bac53d2028  jmp 0x000076BAC51FE110
000076bac53d202d  cmp dword ptr [r15+0x318], 0x00
000076bac53d2035  jz 0x000076BAC53D1EB0
000076bac53d203b  nop [rax+rax*1], ax
000076bac53d2044  nop [rax+rax*1], eax
000076bac53d204c  mov eax, 0x410450
000076bac53d2051  mov [r15+0x100], rax
000076bac53d2058  jmp 0x000076BAC51FE110
000076bac53d205d  int3
000076bac53d205e  sub rsp, 0x08
000076bac53d2062  push rax
000076bac53d2063  push rcx
000076bac53d2064  push rdx
000076bac53d2065  push rdi
000076bac53d2066  push rsi
000076bac53d2067  push r8
000076bac53d2069  push r9
000076bac53d206b  push r10
000076bac53d206d  push r11
000076bac53d206f  sub rsp, 0xF0
000076bac53d2076  vmovaps [rsp], xmm0
000076bac53d207b  vmovaps [rsp+0x10], xmm1
000076bac53d2081  vmovaps [rsp+0x20], xmm2
000076bac53d2087  vmovaps [rsp+0x30], xmm3
000076bac53d208d  vmovaps [rsp+0x40], xmm4
000076bac53d2093  vmovaps [rsp+0x50], xmm5
000076bac53d2099  vmovaps [rsp+0x60], xmm6
000076bac53d209f  vmovaps [rsp+0x70], xmm7
000076bac53d20a5  vmovaps [rsp+0x80], xmm8
000076bac53d20ae  vmovaps [rsp+0x90], xmm9
000076bac53d20b7  vmovaps [rsp+0xA0], xmm10
000076bac53d20c0  vmovaps [rsp+0xB0], xmm11
000076bac53d20c9  vmovaps [rsp+0xC0], xmm12
000076bac53d20d2  vmovaps [rsp+0xD0], xmm14
000076bac53d20db  vmovaps [rsp+0xE0], xmm15
000076bac53d20e4  sub rsp, 0x30
000076bac53d20e8  movaps [rsp], xmm13
000076bac53d20ed  movaps [rsp+0x10], xmm15
000076bac53d20f3  movaps [rsp+0x20], xmm14
000076bac53d20f9  lea rdi, [rsp]
000076bac53d20fd  mov esi, 0x00
000076bac53d2102  mov rax, 0x5641B0A3C530
000076bac53d210c  call rax
000076bac53d210e  movaps xmm13, [rsp]
000076bac53d2113  add rsp, 0x30
000076bac53d2117  vmovaps xmm0, [rsp]
000076bac53d211c  vmovaps xmm1, [rsp+0x10]
000076bac53d2122  vmovaps xmm2, [rsp+0x20]
000076bac53d2128  vmovaps xmm3, [rsp+0x30]
000076bac53d212e  vmovaps xmm4, [rsp+0x40]
000076bac53d2134  vmovaps xmm5, [rsp+0x50]
000076bac53d213a  vmovaps xmm6, [rsp+0x60]
000076bac53d2140  vmovaps xmm7, [rsp+0x70]
000076bac53d2146  vmovaps xmm8, [rsp+0x80]
000076bac53d214f  vmovaps xmm9, [rsp+0x90]
000076bac53d2158  vmovaps xmm10, [rsp+0xA0]
000076bac53d2161  vmovaps xmm11, [rsp+0xB0]
000076bac53d216a  vmovaps xmm12, [rsp+0xC0]
000076bac53d2173  vmovaps xmm14, [rsp+0xD0]
000076bac53d217c  vmovaps xmm15, [rsp+0xE0]
000076bac53d2185  add rsp, 0xF0
000076bac53d218c  pop r11
000076bac53d218e  pop r10
000076bac53d2190  pop r9
000076bac53d2192  pop r8
000076bac53d2194  pop rsi
000076bac53d2195  pop rdi
000076bac53d2196  pop rdx
000076bac53d2197  pop rcx
000076bac53d2198  pop rax
000076bac53d2199  add rsp, 0x08
000076bac53d219d  jmp 0x000076BAC53D1F81
000076bac53d21a2  call 0x000076BAC52C2240
000076bac53d21a7  jmp 0x000076BAC53D1F9B
000076bac53d21ac  sub rsp, 0x08
000076bac53d21b0  push rax
000076bac53d21b1  push rcx
000076bac53d21b2  push rdx
000076bac53d21b3  push rdi
000076bac53d21b4  push rsi
000076bac53d21b5  push r8
000076bac53d21b7  push r9
000076bac53d21b9  push r10
000076bac53d21bb  push r11
000076bac53d21bd  sub rsp, 0xF0
000076bac53d21c4  vmovaps [rsp], xmm0
000076bac53d21c9  vmovaps [rsp+0x10], xmm1
000076bac53d21cf  vmovaps [rsp+0x20], xmm2
000076bac53d21d5  vmovaps [rsp+0x30], xmm3
000076bac53d21db  vmovaps [rsp+0x40], xmm4
000076bac53d21e1  vmovaps [rsp+0x50], xmm5
000076bac53d21e7  vmovaps [rsp+0x60], xmm6
000076bac53d21ed  vmovaps [rsp+0x70], xmm7
000076bac53d21f3  vmovaps [rsp+0x80], xmm8
000076bac53d21fc  vmovaps [rsp+0x90], xmm9
000076bac53d2205  vmovaps [rsp+0xA0], xmm10
000076bac53d220e  vmovaps [rsp+0xB0], xmm11
000076bac53d2217  vmovaps [rsp+0xC0], xmm12
000076bac53d2220  vmovaps [rsp+0xD0], xmm13
000076bac53d2229  vmovaps [rsp+0xE0], xmm15
000076bac53d2232  sub rsp, 0x30
000076bac53d2236  movaps [rsp], xmm14
000076bac53d223b  movaps [rsp+0x10], xmm1
000076bac53d2240  movaps [rsp+0x20], xmm15
000076bac53d2246  lea rdi, [rsp]
000076bac53d224a  mov esi, 0x00
000076bac53d224f  mov rax, 0x5641B0A3C530
000076bac53d2259  call rax
000076bac53d225b  movaps xmm14, [rsp]
000076bac53d2260  add rsp, 0x30
000076bac53d2264  vmovaps xmm0, [rsp]
000076bac53d2269  vmovaps xmm1, [rsp+0x10]
000076bac53d226f  vmovaps xmm2, [rsp+0x20]
000076bac53d2275  vmovaps xmm3, [rsp+0x30]
000076bac53d227b  vmovaps xmm4, [rsp+0x40]
000076bac53d2281  vmovaps xmm5, [rsp+0x50]
000076bac53d2287  vmovaps xmm6, [rsp+0x60]
000076bac53d228d  vmovaps xmm7, [rsp+0x70]
000076bac53d2293  vmovaps xmm8, [rsp+0x80]
000076bac53d229c  vmovaps xmm9, [rsp+0x90]
000076bac53d22a5  vmovaps xmm10, [rsp+0xA0]
000076bac53d22ae  vmovaps xmm11, [rsp+0xB0]
000076bac53d22b7  vmovaps xmm12, [rsp+0xC0]
000076bac53d22c0  vmovaps xmm13, [rsp+0xD0]
000076bac53d22c9  vmovaps xmm15, [rsp+0xE0]
000076bac53d22d2  add rsp, 0xF0
000076bac53d22d9  pop r11
000076bac53d22db  pop r10
000076bac53d22dd  pop r9
000076bac53d22df  pop r8
000076bac53d22e1  pop rsi
000076bac53d22e2  pop rdi
000076bac53d22e3  pop rdx
000076bac53d22e4  pop rcx
000076bac53d22e5  pop rax
000076bac53d22e6  add rsp, 0x08
000076bac53d22ea  jmp 0x000076BAC53D1FBE
000076bac53d22ef  call 0x000076BAC52C34C0
000076bac53d22f4  jmp 0x000076BAC53D1FD4
000076bac53d22f9  int3
000076bac53d22fa  nop [rax+rax*1], ax
000076bac53d2300  mov rax, [r15+0x50]
000076bac53d2304  lea r14, [rax+0x80]
000076bac53d230b  movups xmm1, [r13+r14*1]
000076bac53d2311  lea r14, [rax+0x90]
000076bac53d2318  movups xmm15, [r13+r14*1]
000076bac53d231e  vxorps xmm14, xmm14, xmm14
000076bac53d2323  vpbroadcastq xmm14, xmm14
000076bac53d2328  lea r14, [rax+0x40]
000076bac53d232c  movups xmm13, [r13+r14*1]
000076bac53d2332  lea r14, [rax+0x50]
000076bac53d2336  movups xmm12, [r13+r14*1]
000076bac53d233c  mov qword ptr [r15+0x48], 0x00
000076bac53d2344  movups xmm11, [r13+rax*1]
000076bac53d234a  lea r14, [rax+0x10]
000076bac53d234e  movups xmm10, [r13+r14*1]
000076bac53d2354  mov r14, [r15+0xF8]
000076bac53d235b  lea r12, [r14+0xE0]
000076bac53d2362  movups [r13+r12*1], xmm15
000076bac53d2368  lea r12, [r14+0xF0]
000076bac53d236f  movups [r13+r12*1], xmm1
000076bac53d2375  lea r12, [rax+0xC0]
000076bac53d237c  movups xmm1, [r13+r12*1]
000076bac53d2382  lea r12, [rax+0xD0]
000076bac53d2389  movups xmm15, [r13+r12*1]
000076bac53d238f  lea r12, [rax+0x140]
000076bac53d2396  movups xmm9, [r13+r12*1]
000076bac53d239c  lea r12, [rax+0x150]
000076bac53d23a3  movups xmm8, [r13+r12*1]
000076bac53d23a9  lea r12, [rax+0x180]
000076bac53d23b0  movups xmm7, [r13+r12*1]
000076bac53d23b6  lea r12, [rax+0x190]
000076bac53d23bd  movups xmm6, [r13+r12*1]
000076bac53d23c3  lea r12, [r14+0xC0]
000076bac53d23ca  movups [r13+r12*1], xmm15
000076bac53d23d0  lea r12, [r14+0xD0]
000076bac53d23d7  movups [r13+r12*1], xmm1
000076bac53d23dd  lea r12, [rax+0x100]
000076bac53d23e4  movups xmm1, [r13+r12*1]
000076bac53d23ea  lea r12, [rax+0x110]
000076bac53d23f1  movups xmm15, [r13+r12*1]
000076bac53d23f7  lea r12, [rax+0x1C0]
000076bac53d23fe  movups xmm5, [r13+r12*1]
000076bac53d2404  lea r12, [rax+0x1D0]
000076bac53d240b  movups xmm4, [r13+r12*1]
000076bac53d2411  lea r12, [rax+0x20]
000076bac53d2415  movups xmm3, [r13+r12*1]
000076bac53d241b  lea r12, [rax+0x30]
000076bac53d241f  movups xmm2, [r13+r12*1]
000076bac53d2425  movaps [r15+0x1F0], xmm2
000076bac53d242d  lea r12, [r14+0x20]
000076bac53d2431  movups [r13+r12*1], xmm1
000076bac53d2437  lea r12, [r14+0x30]
000076bac53d243b  movups [r13+r12*1], xmm12
000076bac53d2441  lea r12, [rax+0x60]
000076bac53d2445  movups xmm1, [r13+r12*1]
000076bac53d244b  lea r12, [rax+0x70]
000076bac53d244f  movups xmm12, [r13+r12*1]
000076bac53d2455  lea r12, [r14+0x60]
000076bac53d2459  movups [r13+r12*1], xmm11
000076bac53d245f  lea r12, [r14+0x70]
000076bac53d2463  movups [r13+r12*1], xmm5
000076bac53d2469  lea r12, [rax+0xE0]
000076bac53d2470  movups xmm11, [r13+r12*1]
000076bac53d2476  lea r12, [rax+0xF0]
000076bac53d247d  movups xmm5, [r13+r12*1]
000076bac53d2483  lea r12, [rax+0x120]
000076bac53d248a  vmovaps [rsp+0x10], xmm1
000076bac53d2490  movups xmm1, [r13+r12*1]
000076bac53d2496  lea r12, [rax+0x130]
000076bac53d249d  vmovaps [rsp+0x20], xmm1
000076bac53d24a3  movups xmm1, [r13+r12*1]
000076bac53d24a9  lea r12, [r14+0xA0]
000076bac53d24b0  movups [r13+r12*1], xmm12
000076bac53d24b6  lea r12, [r14+0xB0]
000076bac53d24bd  vmovaps xmm12, [rsp+0x10]
000076bac53d24c3  movups [r13+r12*1], xmm12
000076bac53d24c9  lea r12, [rax+0xA0]
000076bac53d24d0  movups xmm12, [r13+r12*1]
000076bac53d24d6  lea r12, [rax+0xB0]
000076bac53d24dd  vmovaps [rsp+0x10], xmm1
000076bac53d24e3  movups xmm1, [r13+r12*1]
000076bac53d24e9  lea r12, [rax+0x160]
000076bac53d24f0  vmovaps [rsp+0x30], xmm1
000076bac53d24f6  movups xmm1, [r13+r12*1]
000076bac53d24fc  lea r12, [rax+0x170]
000076bac53d2503  vmovaps [rsp+0x40], xmm1
000076bac53d2509  movups xmm1, [r13+r12*1]
000076bac53d250f  movaps [r15+0x2B0], xmm1
000076bac53d2517  lea r12, [rax+0x1A0]
000076bac53d251e  vmovaps [rsp+0x50], xmm1
000076bac53d2524  movups xmm1, [r13+r12*1]
000076bac53d252a  lea r12, [rax+0x1B0]
000076bac53d2531  vmovaps [rsp+0x60], xmm1
000076bac53d2537  movups xmm1, [r13+r12*1]
000076bac53d253d  vmovaps [rsp+0x70], xmm1
000076bac53d2543  vmovaps xmm1, [rsp+0x60]
000076bac53d2549  movaps [r15+0x290], xmm1
000076bac53d2551  vmovaps [rsp+0x60], xmm1
000076bac53d2557  vmovaps xmm1, [rsp+0x70]
000076bac53d255d  movaps [r15+0x1E0], xmm1
000076bac53d2565  lea r12, [r14+0x80]
000076bac53d256c  vmovaps [rsp+0x70], xmm1
000076bac53d2572  vmovaps xmm1, [rsp+0x30]
000076bac53d2578  movups [r13+r12*1], xmm1
000076bac53d257e  lea r12, [r14+0x90]
000076bac53d2585  movups [r13+r12*1], xmm12
000076bac53d258b  lea r12, [rax+0x1E0]
000076bac53d2592  movups xmm1, [r13+r12*1]
000076bac53d2598  lea r12, [rax+0x1F0]
000076bac53d259f  movups xmm12, [r13+r12*1]
000076bac53d25a5  mov qword ptr [r15+0x50], 0x432200
000076bac53d25ad  lea rax, [r14+0x40]
000076bac53d25b1  vmovaps [rsp+0x30], xmm1
000076bac53d25b7  vmovaps xmm1, [rsp+0x40]
000076bac53d25bd  movups [r13+rax*1], xmm1
000076bac53d25c3  lea rax, [r14+0x50]
000076bac53d25c7  movups [r13+rax*1], xmm10
000076bac53d25cd  movups [r13+r14*1], xmm12
000076bac53d25d3  lea rax, [r14+0x10]
000076bac53d25d7  vmovaps xmm1, [rsp+0x30]
000076bac53d25dd  movups [r13+rax*1], xmm1
000076bac53d25e3  mov rax, [r15+0x40]
000076bac53d25e7  vmovaps [rsp+0x30], xmm3
000076bac53d25ed  vmovaps xmm1, [rsp+0x30]
000076bac53d25f3  por xmm3, xmm1
000076bac53d25f7  vmovaps [rsp+0x30], xmm6
000076bac53d25fd  vmovaps xmm12, [rsp+0x30]
000076bac53d2603  por xmm6, xmm12
000076bac53d2608  lea r12, [rax+0x30]
000076bac53d260c  mov r11, [r13+r12*1]
000076bac53d2611  lea r12, [rax+0x38]
000076bac53d2615  mov r10, [r13+r12*1]
000076bac53d261a  movq xmm12, r11
000076bac53d261f  movq xmm10, r10
000076bac53d2624  movq xmm12, xmm12
000076bac53d2629  vmovaps [rsp+0x30], xmm12
000076bac53d262f  movq xmm12, xmm12
000076bac53d2634  movaps [r15+0x130], xmm12
000076bac53d263c  movq xmm10, xmm10
000076bac53d2641  vmovaps [rsp+0x40], xmm10
000076bac53d2647  movq xmm10, xmm10
000076bac53d264c  movaps [r15+0x280], xmm10
000076bac53d2654  vmovaps [rsp+0x80], xmm9
000076bac53d265d  vmovaps xmm12, [rsp+0x80]
000076bac53d2666  por xmm9, xmm12
000076bac53d266b  lea r12, [rax+0x20]
000076bac53d266f  mov r11, [r13+r12*1]
000076bac53d2674  lea r12, [rax+0x28]
000076bac53d2678  mov r10, [r13+r12*1]
000076bac53d267d  movq xmm12, r11
000076bac53d2682  movq xmm10, r10
000076bac53d2687  movq xmm12, xmm12
000076bac53d268c  vmovaps [rsp+0x80], xmm12
000076bac53d2695  movq xmm12, xmm12
000076bac53d269a  movaps [r15+0x150], xmm12
000076bac53d26a2  movq xmm10, xmm10
000076bac53d26a7  vmovaps [rsp+0x90], xmm10
000076bac53d26b0  movq xmm10, xmm10
000076bac53d26b5  movaps [r15+0x140], xmm10
000076bac53d26bd  lea r12, [rax+0x10]
000076bac53d26c1  mov r11, [r13+r12*1]
000076bac53d26c6  lea r12, [rax+0x18]
000076bac53d26ca  mov r10, [r13+r12*1]
000076bac53d26cf  movq xmm12, r11
000076bac53d26d4  movq xmm10, r10
000076bac53d26d9  movq xmm12, xmm12
000076bac53d26de  vmovaps [rsp+0xA0], xmm12
000076bac53d26e7  movq xmm12, xmm12
000076bac53d26ec  movaps [r15+0x170], xmm12
000076bac53d26f4  movq xmm10, xmm10
000076bac53d26f9  vmovaps [rsp+0xB0], xmm10
000076bac53d2702  movq xmm10, xmm10
000076bac53d2707  movaps [r15+0x160], xmm10
000076bac53d270f  mov r12, [r13+rax*1]
000076bac53d2714  vmovq xmm12, r12
000076bac53d2719  vpbroadcastq xmm12, xmm12
000076bac53d271e  lea r12, [rax+0x08]
000076bac53d2722  mov rax, [r13+r12*1]
000076bac53d2727  movq xmm10, rax
000076bac53d272c  movaps [r15+0x230], xmm10
000076bac53d2734  lea rax, [r14+0x50]
000076bac53d2738  movups xmm10, [r13+rax*1]
000076bac53d273e  lea rax, [r14+0x60]
000076bac53d2742  vmovaps [rsp+0xC0], xmm1
000076bac53d274b  movups xmm1, [r13+rax*1]
000076bac53d2751  lea rax, [r14+0x30]
000076bac53d2755  vmovaps [rsp+0xD0], xmm1
000076bac53d275e  movups xmm1, [r13+rax*1]
000076bac53d2764  mov qword ptr [r15+0x60], 0x432200
000076bac53d276c  mov qword ptr [r15+0x58], 0x40
000076bac53d2774  vmovaps [rsp+0xE0], xmm1
000076bac53d277d  vmovaps [rsp+0xF0], xmm15
000076bac53d2786  vmovaps xmm15, [rsp+0xC0]
000076bac53d278f  vmovaps [rsp+0xC0], xmm14
000076bac53d2798  movaps xmm1, xmm12
000076bac53d279c  mulpd xmm1, xmm15
000076bac53d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
000076bac53d27a6  ptest xmm14, xmm14
000076bac53d27ac  jnz 0x000076BAC53D3863
000076bac53d27b2  movq xmm15, qword ptr [r15+0x230]
000076bac53d27bb  vmovaps [rsp+0x100], xmm15
000076bac53d27c4  vpermilpd xmm15, xmm15, 0x00
000076bac53d27ca  vmovaps [rsp+0x110], xmm1
000076bac53d27d3  vmovaps xmm1, [rsp+0xE0]
000076bac53d27dc  vmovaps [rsp+0xE0], xmm13
000076bac53d27e5  movaps xmm14, xmm1
000076bac53d27e9  mulpd xmm14, xmm15
000076bac53d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
000076bac53d27f4  ptest xmm13, xmm13
000076bac53d27fa  jnz 0x000076BAC53D39A5
000076bac53d2800  vxorps xmm1, xmm1, xmm1
000076bac53d2804  vpbroadcastq xmm1, xmm1
000076bac53d2809  vmovaps xmm13, [rsp+0xD0]
000076bac53d2812  vmovaps [rsp+0xD0], xmm1
000076bac53d281b  movaps xmm15, xmm12
000076bac53d281f  mulpd xmm15, xmm13
000076bac53d2824  vcmppd xmm1, xmm15, xmm15, 0x03
000076bac53d282a  ptest xmm1, xmm1
000076bac53d282f  jnz 0x000076BAC53D3AE8
000076bac53d2835  movaps xmm1, xmm12
000076bac53d2839  mulpd xmm1, xmm10
000076bac53d283e  vcmppd xmm13, xmm1, xmm1, 0x03
000076bac53d2843  ptest xmm13, xmm13
000076bac53d2849  jnz 0x000076BAC53D3C2C
000076bac53d284f  movaps xmm13, xmm12
000076bac53d2853  mulpd xmm13, xmm2
000076bac53d2858  vcmppd xmm10, xmm13, xmm13, 0x03
000076bac53d285e  ptest xmm10, xmm10
000076bac53d2864  jnz 0x000076BAC53D3D6E
000076bac53d286a  vmovaps [rsp+0x120], xmm7
000076bac53d2873  vmovaps xmm12, [rsp+0x120]
000076bac53d287c  por xmm7, xmm12
000076bac53d2881  vmovaps xmm12, [rsp+0xE0]
000076bac53d288a  vmovaps xmm10, [rsp+0xE0]
000076bac53d2893  por xmm12, xmm10
000076bac53d2898  vmovaps xmm2, [rsp+0x100]
000076bac53d28a1  vpermilpd xmm2, xmm2, 0x00
000076bac53d28a7  vmovaps [rsp+0xE0], xmm1
000076bac53d28b0  vmovaps [rsp+0x120], xmm15
000076bac53d28b9  movaps xmm1, xmm10
000076bac53d28bd  mulpd xmm1, xmm2
000076bac53d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
000076bac53d28c6  ptest xmm15, xmm15
000076bac53d28cc  jnz 0x000076BAC53D3EB1
000076bac53d28d2  xor eax, eax
000076bac53d28d4  mov r12d, 0x40
000076bac53d28da  mov r11d, 0x200
000076bac53d28e0  cmp r12, r11
000076bac53d28e3  cmc
000076bac53d28e4  lahf
000076bac53d28e5  seto al
000076bac53d28e8  mov [r15+0x108], eax
000076bac53d28ef  vmovaps xmm10, [rsp+0x110]
000076bac53d28f8  vmovaps xmm2, [rsp+0xD0]
000076bac53d2901  vmovaps [rsp+0xD0], xmm1
000076bac53d290a  movaps xmm15, xmm10
000076bac53d290e  addpd xmm15, xmm2
000076bac53d2913  vcmppd xmm1, xmm15, xmm15, 0x03
000076bac53d2919  ptest xmm1, xmm1
000076bac53d291e  jnz 0x000076BAC53D3FF2
000076bac53d2924  vmovaps xmm10, [rsp+0x120]
000076bac53d292d  vmovaps [rsp+0x110], xmm15
000076bac53d2936  vmovaps xmm15, [rsp+0xC0]
000076bac53d293f  vmovaps [rsp+0xC0], xmm14
000076bac53d2948  movaps xmm1, xmm10
000076bac53d294c  addpd xmm1, xmm15
000076bac53d2951  vcmppd xmm14, xmm1, xmm1, 0x03
000076bac53d2956  ptest xmm14, xmm14
000076bac53d295c  jnz 0x000076BAC53D4135
000076bac53d2962  vmovaps xmm10, [rsp+0xE0]
000076bac53d296b  vmovaps [rsp+0xE0], xmm1
000076bac53d2974  movaps xmm14, xmm10
000076bac53d2978  addpd xmm14, xmm15
000076bac53d297d  vcmppd xmm1, xmm14, xmm14, 0x03
000076bac53d2983  ptest xmm1, xmm1
000076bac53d2988  jnz 0x000076BAC53D4277
000076bac53d298e  vmovaps xmm1, [rsp+0x10]
000076bac53d2994  vmovaps xmm15, [rsp+0x10]
000076bac53d299a  por xmm1, xmm15
000076bac53d299f  vmovaps xmm15, [rsp+0x20]
000076bac53d29a5  vmovaps xmm10, [rsp+0x20]
000076bac53d29ab  por xmm15, xmm10
000076bac53d29b0  vmovaps [rsp+0x10], xmm5
000076bac53d29b6  vmovaps xmm10, [rsp+0x10]
000076bac53d29bc  por xmm5, xmm10
000076bac53d29c1  vmovaps [rsp+0x10], xmm11
000076bac53d29c7  vmovaps xmm10, [rsp+0x10]
000076bac53d29cd  por xmm11, xmm10
000076bac53d29d2  vmovaps [rsp+0x10], xmm4
000076bac53d29d8  vmovaps xmm10, [rsp+0x10]
000076bac53d29de  por xmm4, xmm10
000076bac53d29e3  vmovaps [rsp+0x10], xmm8
000076bac53d29e9  vmovaps xmm10, [rsp+0x10]
000076bac53d29ef  por xmm8, xmm10
000076bac53d29f4  vmovaps xmm10, [rsp+0xF0]
000076bac53d29fd  vmovaps [rsp+0x10], xmm1
000076bac53d2a03  vmovaps xmm1, [rsp+0xF0]
000076bac53d2a0c  por xmm10, xmm1
000076bac53d2a11  lea rax, [r14+0xA0]
000076bac53d2a18  movups xmm1, [r13+rax*1]
000076bac53d2a1e  lea rax, [r14+0xB0]
000076bac53d2a25  vmovaps [rsp+0x20], xmm1
000076bac53d2a2b  movups xmm1, [r13+rax*1]
000076bac53d2a31  vmovaps [rsp+0xF0], xmm1
000076bac53d2a3a  vmovaps [rsp+0x120], xmm15
000076bac53d2a43  movaps xmm1, xmm13
000076bac53d2a47  addpd xmm1, xmm2
000076bac53d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
000076bac53d2a50  ptest xmm15, xmm15
000076bac53d2a56  jnz 0x000076BAC53D43CF
000076bac53d2a5c  lea rax, [r14+0xF0]
000076bac53d2a63  movups xmm15, [r13+rax*1]
000076bac53d2a69  vmovaps xmm2, [rsp+0xE0]
000076bac53d2a72  vmovaps [rsp+0xE0], xmm1
000076bac53d2a7b  vmovaps xmm1, [rsp+0xD0]
000076bac53d2a84  vmovaps [rsp+0xD0], xmm15
000076bac53d2a8d  movaps xmm13, xmm2
000076bac53d2a91  addpd xmm13, xmm1
000076bac53d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
000076bac53d2a9c  ptest xmm15, xmm15
000076bac53d2aa2  jnz 0x000076BAC53D451A
000076bac53d2aa8  vmovaps xmm15, [rsp+0xC0]
000076bac53d2ab1  movaps xmm1, xmm14
000076bac53d2ab5  addpd xmm1, xmm15
000076bac53d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
000076bac53d2abf  ptest xmm2, xmm2
000076bac53d2ac4  jnz 0x000076BAC53D465C
000076bac53d2aca  vmovaps xmm15, [rsp+0x100]
000076bac53d2ad3  vpermilpd xmm15, xmm15, 0x00
000076bac53d2ad9  vmovaps xmm2, [rsp+0xF0]
000076bac53d2ae2  vmovaps [rsp+0xC0], xmm1
000076bac53d2aeb  movaps xmm14, xmm2
000076bac53d2aef  mulpd xmm14, xmm15
000076bac53d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
000076bac53d2afa  ptest xmm1, xmm1
000076bac53d2aff  jnz 0x000076BAC53D479E
000076bac53d2b05  vmovaps xmm1, [rsp+0xA0]
000076bac53d2b0e  vpermilpd xmm1, xmm1, 0x00
000076bac53d2b14  vmovaps xmm2, [rsp+0xD0]
000076bac53d2b1d  vmovaps [rsp+0xD0], xmm14
000076bac53d2b26  movaps xmm15, xmm2
000076bac53d2b2a  mulpd xmm15, xmm1
000076bac53d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
000076bac53d2b35  ptest xmm14, xmm14
000076bac53d2b3b  jnz 0x000076BAC53D48E1
000076bac53d2b41  lea rax, [r14+0xE0]
000076bac53d2b48  movups xmm1, [r13+rax*1]
000076bac53d2b4e  vmovaps xmm14, [rsp+0x100]
000076bac53d2b57  vpermilpd xmm14, xmm14, 0x00
000076bac53d2b5d  vmovaps [rsp+0xF0], xmm1
000076bac53d2b66  vmovaps xmm1, [rsp+0x20]
000076bac53d2b6c  vmovaps [rsp+0x20], xmm15
000076bac53d2b72  movaps xmm2, xmm1
000076bac53d2b75  mulpd xmm2, xmm14
000076bac53d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
000076bac53d2b7f  ptest xmm15, xmm15
000076bac53d2b85  jnz 0x000076BAC53D4A2D
000076bac53d2b8b  vmovaps [rsp+0x100], xmm10
000076bac53d2b94  vmovaps xmm1, [rsp+0x100]
000076bac53d2b9d  por xmm10, xmm1
000076bac53d2ba2  movaps [r15+0x300], xmm10
000076bac53d2baa  vmovaps [rsp+0x100], xmm8
000076bac53d2bb3  vmovaps xmm1, [rsp+0x100]
000076bac53d2bbc  por xmm8, xmm1
000076bac53d2bc1  movaps [r15+0x190], xmm8
000076bac53d2bc9  vmovaps xmm1, [rsp+0xA0]
000076bac53d2bd2  vpermilpd xmm1, xmm1, 0x00
000076bac53d2bd8  vmovaps xmm14, [rsp+0xF0]
000076bac53d2be1  vmovaps [rsp+0xF0], xmm13
000076bac53d2bea  movaps xmm15, xmm14
000076bac53d2bee  mulpd xmm15, xmm1
000076bac53d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
000076bac53d2bf9  ptest xmm13, xmm13
000076bac53d2bff  jnz 0x000076BAC53D4B6E
000076bac53d2c05  lea rax, [r14+0x90]
000076bac53d2c0c  movups xmm1, [r13+rax*1]
000076bac53d2c12  vmovaps [rsp+0x100], xmm4
000076bac53d2c1b  vmovaps xmm14, [rsp+0x100]
000076bac53d2c24  por xmm4, xmm14
000076bac53d2c29  movaps [r15+0x1C0], xmm4
000076bac53d2c31  vmovaps [rsp+0x100], xmm11
000076bac53d2c3a  vmovaps xmm14, [rsp+0x100]
000076bac53d2c43  por xmm11, xmm14
000076bac53d2c48  movaps [r15+0x200], xmm11
000076bac53d2c50  vmovaps [rsp+0x100], xmm5
000076bac53d2c59  vmovaps xmm14, [rsp+0x100]
000076bac53d2c62  por xmm5, xmm14
000076bac53d2c67  movaps [r15+0x2D0], xmm5
000076bac53d2c6f  vmovaps xmm14, [rsp+0x120]
000076bac53d2c78  vmovaps xmm13, [rsp+0x120]
000076bac53d2c81  por xmm14, xmm13
000076bac53d2c86  movaps [r15+0x2E0], xmm14
000076bac53d2c8e  vmovaps [rsp+0x100], xmm1
000076bac53d2c97  vmovaps xmm1, [rsp+0x110]
000076bac53d2ca0  vmovaps [rsp+0x110], xmm15
000076bac53d2ca9  vmovaps xmm15, [rsp+0xD0]
000076bac53d2cb2  vmovaps [rsp+0xD0], xmm14
000076bac53d2cbb  movaps xmm13, xmm1
000076bac53d2cbf  addpd xmm13, xmm15
000076bac53d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
000076bac53d2cca  ptest xmm14, xmm14
000076bac53d2cd0  jnz 0x000076BAC53D4CBB
000076bac53d2cd6  vmovaps xmm1, [rsp+0xA0]
000076bac53d2cdf  vpermilpd xmm1, xmm1, 0x00
000076bac53d2ce5  vmovaps xmm14, [rsp+0x100]
000076bac53d2cee  vmovaps [rsp+0x100], xmm13
000076bac53d2cf7  movaps xmm15, xmm14
000076bac53d2cfb  mulpd xmm15, xmm1
000076bac53d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
000076bac53d2d06  ptest xmm13, xmm13
000076bac53d2d0c  jnz 0x000076BAC53D4DFE
000076bac53d2d12  lea rax, [r14+0x80]
000076bac53d2d19  movups xmm1, [r13+rax*1]
000076bac53d2d1f  vmovaps xmm13, [rsp+0xE0]
000076bac53d2d28  vmovaps [rsp+0xE0], xmm1
000076bac53d2d31  movaps xmm14, xmm13
000076bac53d2d35  addpd xmm14, xmm2
000076bac53d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
000076bac53d2d40  ptest xmm1, xmm1
000076bac53d2d45  jnz 0x000076BAC53D4F4B
000076bac53d2d4b  vmovaps xmm13, [rsp+0xF0]
000076bac53d2d54  vmovaps xmm2, [rsp+0x20]
000076bac53d2d5a  vmovaps [rsp+0x20], xmm15
000076bac53d2d60  movaps xmm1, xmm13
000076bac53d2d64  addpd xmm1, xmm2
000076bac53d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
000076bac53d2d6d  ptest xmm15, xmm15
000076bac53d2d73  jnz 0x000076BAC53D508E
000076bac53d2d79  vmovaps xmm15, [rsp+0x10]
000076bac53d2d7f  vmovaps xmm13, [rsp+0x10]
000076bac53d2d85  por xmm15, xmm13
000076bac53d2d8a  movaps [r15+0x2F0], xmm15
000076bac53d2d92  vmovaps xmm13, [rsp+0xA0]
000076bac53d2d9b  vpermilpd xmm13, xmm13, 0x00
000076bac53d2da1  vmovaps [rsp+0x10], xmm1
000076bac53d2da7  vmovaps xmm1, [rsp+0xE0]
000076bac53d2db0  vmovaps [rsp+0xA0], xmm15
000076bac53d2db9  movaps xmm2, xmm1
000076bac53d2dbc  mulpd xmm2, xmm13
000076bac53d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
000076bac53d2dc6  ptest xmm15, xmm15
000076bac53d2dcc  jnz 0x000076BAC53D51CF
000076bac53d2dd2  lea rax, [r14+0xD0]
000076bac53d2dd9  movups xmm1, [r13+rax*1]
000076bac53d2ddf  vmovaps xmm13, [rsp+0xC0]
000076bac53d2de8  vmovaps [rsp+0xC0], xmm1
000076bac53d2df1  vmovaps xmm1, [rsp+0x110]
000076bac53d2dfa  vmovaps [rsp+0xE0], xmm14
000076bac53d2e03  movaps xmm15, xmm13
000076bac53d2e07  addpd xmm15, xmm1
000076bac53d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
000076bac53d2e12  ptest xmm14, xmm14
000076bac53d2e18  jnz 0x000076BAC53D531A
000076bac53d2e1e  vmovaps xmm1, [rsp+0xB0]
000076bac53d2e27  vpermilpd xmm1, xmm1, 0x00
000076bac53d2e2d  movaps xmm14, xmm11
000076bac53d2e31  mulpd xmm14, xmm1
000076bac53d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
000076bac53d2e3c  ptest xmm13, xmm13
000076bac53d2e42  jnz 0x000076BAC53D545D
000076bac53d2e48  movaps [r15+0x260], xmm14
000076bac53d2e50  vxorps xmm1, xmm1, xmm1
000076bac53d2e54  vpbroadcastq xmm1, xmm1
000076bac53d2e59  movaps [r15+0x1B0], xmm1
000076bac53d2e61  vmovaps xmm1, [rsp+0xB0]
000076bac53d2e6a  vpermilpd xmm1, xmm1, 0x00
000076bac53d2e70  vmovaps xmm11, [rsp+0xC0]
000076bac53d2e79  vmovaps [rsp+0xC0], xmm15
000076bac53d2e82  movaps xmm13, xmm11
000076bac53d2e86  mulpd xmm13, xmm1
000076bac53d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
000076bac53d2e91  ptest xmm15, xmm15
000076bac53d2e97  jnz 0x000076BAC53D55A0
000076bac53d2e9d  lea rax, [r14+0xC0]
000076bac53d2ea4  movups xmm1, [r13+rax*1]
000076bac53d2eaa  vmovaps xmm11, [rsp+0x100]
000076bac53d2eb3  vmovaps [rsp+0xF0], xmm1
000076bac53d2ebc  vmovaps xmm1, [rsp+0x20]
000076bac53d2ec2  vmovaps [rsp+0x20], xmm14
000076bac53d2ec8  movaps xmm15, xmm11
000076bac53d2ecc  addpd xmm15, xmm1
000076bac53d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
000076bac53d2ed7  ptest xmm14, xmm14
000076bac53d2edd  jnz 0x000076BAC53D56ED
000076bac53d2ee3  vmovaps [rsp+0x100], xmm9
000076bac53d2eec  vmovaps xmm1, [rsp+0x100]
000076bac53d2ef5  por xmm9, xmm1
000076bac53d2efa  movaps [r15+0x270], xmm9
000076bac53d2f02  vmovaps [rsp+0x100], xmm6
000076bac53d2f0b  vmovaps xmm1, [rsp+0x100]
000076bac53d2f14  por xmm6, xmm1
000076bac53d2f18  movaps [r15+0x1A0], xmm6
000076bac53d2f20  vmovaps xmm14, [rsp+0xB0]
000076bac53d2f29  vpermilpd xmm14, xmm14, 0x00
000076bac53d2f2f  vmovaps xmm6, [rsp+0xF0]
000076bac53d2f38  vmovaps [rsp+0xF0], xmm1
000076bac53d2f41  movaps xmm11, xmm6
000076bac53d2f45  mulpd xmm11, xmm14
000076bac53d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
000076bac53d2f50  ptest xmm1, xmm1
000076bac53d2f55  jnz 0x000076BAC53D5830
000076bac53d2f5b  lea rax, [r14+0x20]
000076bac53d2f5f  movups xmm1, [r13+rax*1]
000076bac53d2f65  movaps [r15+0x110], xmm1
000076bac53d2f6d  vmovaps xmm6, [rsp+0xE0]
000076bac53d2f76  vmovaps [rsp+0xE0], xmm1
000076bac53d2f7f  movaps xmm14, xmm6
000076bac53d2f83  addpd xmm14, xmm2
000076bac53d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
000076bac53d2f8e  ptest xmm1, xmm1
000076bac53d2f93  jnz 0x000076BAC53D597D
000076bac53d2f99  vmovaps xmm1, [rsp+0xB0]
000076bac53d2fa2  vpermilpd xmm1, xmm1, 0x00
000076bac53d2fa8  movaps xmm6, xmm5
000076bac53d2fab  mulpd xmm6, xmm1
000076bac53d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
000076bac53d2fb4  ptest xmm2, xmm2
000076bac53d2fb9  jnz 0x000076BAC53D5ABF
000076bac53d2fbf  vmovaps xmm5, [rsp+0x10]
000076bac53d2fc5  movaps xmm1, xmm5
000076bac53d2fc8  addpd xmm1, xmm13
000076bac53d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
000076bac53d2fd2  ptest xmm2, xmm2
000076bac53d2fd7  jnz 0x000076BAC53D5BFF
000076bac53d2fdd  vmovaps xmm13, [rsp+0x80]
000076bac53d2fe6  vpermilpd xmm13, xmm13, 0x00
000076bac53d2fec  vmovaps xmm2, [rsp+0xE0]
000076bac53d2ff5  vmovaps [rsp+0x10], xmm1
000076bac53d2ffb  movaps xmm5, xmm2
000076bac53d2ffe  mulpd xmm5, xmm13
000076bac53d3003  vcmppd xmm1, xmm5, xmm5, 0x03
000076bac53d3008  ptest xmm1, xmm1
000076bac53d300d  jnz 0x000076BAC53D5D40
000076bac53d3013  vmovaps xmm1, [rsp+0x80]
000076bac53d301c  vpermilpd xmm1, xmm1, 0x00
000076bac53d3022  movaps xmm13, xmm10
000076bac53d3026  mulpd xmm13, xmm1
000076bac53d302b  vcmppd xmm2, xmm13, xmm13, 0x03
000076bac53d3031  ptest xmm2, xmm2
000076bac53d3036  jnz 0x000076BAC53D5E81
000076bac53d303c  vmovaps xmm10, [rsp+0x20]
000076bac53d3042  movaps xmm1, xmm15
000076bac53d3046  addpd xmm1, xmm10
000076bac53d304b  vcmppd xmm2, xmm1, xmm1, 0x03
000076bac53d3050  ptest xmm2, xmm2
000076bac53d3055  jnz 0x000076BAC53D5FC4
000076bac53d305b  vmovaps xmm10, [rsp+0xC0]
000076bac53d3064  movaps xmm15, xmm10
000076bac53d3068  addpd xmm15, xmm11
000076bac53d306d  vcmppd xmm2, xmm15, xmm15, 0x03
000076bac53d3073  ptest xmm2, xmm2
000076bac53d3078  jnz 0x000076BAC53D6106
000076bac53d307e  vmovaps xmm11, [rsp+0x80]
000076bac53d3087  vpermilpd xmm11, xmm11, 0x00
000076bac53d308d  vmovaps xmm2, [rsp+0xD0]
000076bac53d3096  vmovaps [rsp+0x20], xmm1
000076bac53d309c  movaps xmm10, xmm2
000076bac53d30a0  mulpd xmm10, xmm11
000076bac53d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
000076bac53d30ab  ptest xmm1, xmm1
000076bac53d30b0  jnz 0x000076BAC53D624A
000076bac53d30b6  vmovaps xmm1, [rsp+0x80]
000076bac53d30bf  vpermilpd xmm1, xmm1, 0x00
000076bac53d30c5  vmovaps xmm2, [rsp+0xA0]
000076bac53d30ce  vmovaps [rsp+0x80], xmm15
000076bac53d30d7  movaps xmm11, xmm2
000076bac53d30db  mulpd xmm11, xmm1
000076bac53d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
000076bac53d30e6  ptest xmm15, xmm15
000076bac53d30ec  jnz 0x000076BAC53D638D
000076bac53d30f2  movaps xmm1, xmm14
000076bac53d30f6  addpd xmm1, xmm6
000076bac53d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
000076bac53d30ff  ptest xmm15, xmm15
000076bac53d3105  jnz 0x000076BAC53D64CF
000076bac53d310b  vmovaps xmm14, [rsp+0x10]
000076bac53d3111  movaps xmm15, xmm14
000076bac53d3115  addpd xmm15, xmm5
000076bac53d311a  vcmppd xmm6, xmm15, xmm15, 0x03
000076bac53d3120  ptest xmm6, xmm6
000076bac53d3125  jnz 0x000076BAC53D6610
000076bac53d312b  vmovaps xmm14, [rsp+0x90]
000076bac53d3134  vpermilpd xmm14, xmm14, 0x00
000076bac53d313a  movaps xmm6, xmm9
000076bac53d313e  mulpd xmm6, xmm14
000076bac53d3143  vcmppd xmm5, xmm6, xmm6, 0x03
000076bac53d3148  ptest xmm5, xmm5
000076bac53d314d  jnz 0x000076BAC53D6753
000076bac53d3153  vmovaps xmm9, [rsp+0x80]
000076bac53d315c  movaps xmm14, xmm9
000076bac53d3160  addpd xmm14, xmm13
000076bac53d3165  vcmppd xmm5, xmm14, xmm14, 0x03
000076bac53d316b  ptest xmm5, xmm5
000076bac53d3170  jnz 0x000076BAC53D6895
000076bac53d3176  vmovaps xmm9, [rsp+0x20]
000076bac53d317c  movaps xmm13, xmm9
000076bac53d3180  addpd xmm13, xmm10
000076bac53d3185  vcmppd xmm5, xmm13, xmm13, 0x03
000076bac53d318b  ptest xmm5, xmm5
000076bac53d3190  jnz 0x000076BAC53D69D9
000076bac53d3196  vmovaps [rsp+0x10], xmm12
000076bac53d319c  vmovaps xmm10, [rsp+0x10]
000076bac53d31a2  por xmm12, xmm10
000076bac53d31a7  movaps [r15+0x250], xmm12
000076bac53d31af  vmovaps [rsp+0x10], xmm7
000076bac53d31b5  vmovaps xmm12, [rsp+0x10]
000076bac53d31bb  por xmm7, xmm12
000076bac53d31c0  movaps [r15+0x2A0], xmm7
000076bac53d31c8  vmovaps [rsp+0x10], xmm3
000076bac53d31ce  vmovaps xmm12, [rsp+0x10]
000076bac53d31d4  por xmm3, xmm12
000076bac53d31d9  movaps [r15+0x1D0], xmm3
000076bac53d31e1  lea rax, [r14+0x40]
000076bac53d31e5  movups xmm12, [r13+rax*1]
000076bac53d31eb  movaps [r15+0x2C0], xmm12
000076bac53d31f3  vmovaps xmm10, [rsp+0x90]
000076bac53d31fc  vpermilpd xmm10, xmm10, 0x00
000076bac53d3202  movaps xmm9, xmm8
000076bac53d3206  mulpd xmm9, xmm10
000076bac53d320b  vcmppd xmm5, xmm9, xmm9, 0x03
000076bac53d3211  ptest xmm5, xmm5
000076bac53d3216  jnz 0x000076BAC53D6B27
000076bac53d321c  movaps xmm10, xmm1
000076bac53d3220  addpd xmm10, xmm11
000076bac53d3225  vcmppd xmm8, xmm10, xmm10, 0x03
000076bac53d322b  ptest xmm8, xmm8
000076bac53d3231  jnz 0x000076BAC53D6C6B
000076bac53d3237  movaps xmm1, xmm15
000076bac53d323b  addpd xmm1, xmm6
000076bac53d323f  vcmppd xmm11, xmm1, xmm1, 0x03
000076bac53d3244  ptest xmm11, xmm11
000076bac53d324a  jnz 0x000076BAC53D6DAE
000076bac53d3250  vmovaps xmm15, [rsp+0x90]
000076bac53d3259  vpermilpd xmm15, xmm15, 0x00
000076bac53d325f  movaps xmm11, xmm12
000076bac53d3263  mulpd xmm11, xmm15
000076bac53d3268  vcmppd xmm8, xmm11, xmm11, 0x03
000076bac53d326e  ptest xmm8, xmm8
000076bac53d3274  jnz 0x000076BAC53D6EEF
000076bac53d327a  vmovaps xmm15, [rsp+0x90]
000076bac53d3283  vpermilpd xmm15, xmm15, 0x00
000076bac53d3289  vmovaps xmm8, [rsp+0x50]
000076bac53d328f  movaps xmm12, xmm8
000076bac53d3293  mulpd xmm12, xmm15
000076bac53d3298  vcmppd xmm6, xmm12, xmm12, 0x03
000076bac53d329e  ptest xmm6, xmm6
000076bac53d32a3  jnz 0x000076BAC53D7033
000076bac53d32a9  vmovaps xmm15, [rsp+0x30]
000076bac53d32af  vpermilpd xmm15, xmm15, 0x00
000076bac53d32b5  movaps xmm8, xmm7
000076bac53d32b9  mulpd xmm8, xmm15
000076bac53d32be  vcmppd xmm6, xmm8, xmm8, 0x03
000076bac53d32c4  ptest xmm6, xmm6
000076bac53d32c9  jnz 0x000076BAC53D7177
000076bac53d32cf  movaps xmm15, xmm14
000076bac53d32d3  addpd xmm15, xmm9
000076bac53d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
000076bac53d32de  ptest xmm7, xmm7
000076bac53d32e3  jnz 0x000076BAC53D72BA
000076bac53d32e9  vmovaps xmm14, [rsp+0x30]
000076bac53d32ef  vpermilpd xmm14, xmm14, 0x00
000076bac53d32f5  vmovaps xmm7, [rsp+0xF0]
000076bac53d32fe  movaps xmm9, xmm7
000076bac53d3302  mulpd xmm9, xmm14
000076bac53d3307  vcmppd xmm6, xmm9, xmm9, 0x03
000076bac53d330d  ptest xmm6, xmm6
000076bac53d3312  jnz 0x000076BAC53D73FE
000076bac53d3318  movaps xmm14, xmm13
000076bac53d331c  addpd xmm14, xmm11
000076bac53d3321  vcmppd xmm7, xmm14, xmm14, 0x03
000076bac53d3327  ptest xmm7, xmm7
000076bac53d332c  jnz 0x000076BAC53D7541
000076bac53d3332  vmovaps xmm13, [rsp+0x30]
000076bac53d3338  vpermilpd xmm13, xmm13, 0x00
000076bac53d333e  vmovaps xmm7, [rsp+0x60]
000076bac53d3344  movaps xmm11, xmm7
000076bac53d3348  mulpd xmm11, xmm13
000076bac53d334d  vcmppd xmm6, xmm11, xmm11, 0x03
000076bac53d3353  ptest xmm6, xmm6
000076bac53d3358  jnz 0x000076BAC53D7685
000076bac53d335e  movaps xmm13, xmm10
000076bac53d3362  addpd xmm13, xmm12
000076bac53d3367  vcmppd xmm7, xmm13, xmm13, 0x03
000076bac53d336d  ptest xmm7, xmm7
000076bac53d3372  jnz 0x000076BAC53D77C8
000076bac53d3378  vmovaps xmm12, [rsp+0x30]
000076bac53d337e  vpermilpd xmm12, xmm12, 0x00
000076bac53d3384  vmovaps xmm7, [rsp+0x70]
000076bac53d338a  movaps xmm10, xmm7
000076bac53d338e  mulpd xmm10, xmm12
000076bac53d3393  vcmppd xmm6, xmm10, xmm10, 0x03
000076bac53d3399  ptest xmm6, xmm6
000076bac53d339e  jnz 0x000076BAC53D790C
000076bac53d33a4  movaps xmm12, xmm1
000076bac53d33a8  addpd xmm12, xmm8
000076bac53d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
000076bac53d33b3  ptest xmm7, xmm7
000076bac53d33b8  jnz 0x000076BAC53D7A4F
000076bac53d33be  lea rax, [r14+0x70]
000076bac53d33c2  movups xmm1, [r13+rax*1]
000076bac53d33c8  movaps [r15+0x240], xmm1
000076bac53d33d0  movaps xmm8, xmm15
000076bac53d33d4  addpd xmm8, xmm9
000076bac53d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
000076bac53d33df  ptest xmm7, xmm7
000076bac53d33e4  jnz 0x000076BAC53D7B9C
000076bac53d33ea  movaps [r15+0x170], xmm8
000076bac53d33f2  vmovaps xmm15, [rsp+0x40]
000076bac53d33f8  vpermilpd xmm15, xmm15, 0x00
000076bac53d33fe  movaps xmm9, xmm1
000076bac53d3402  mulpd xmm9, xmm15
000076bac53d3407  vcmppd xmm7, xmm9, xmm9, 0x03
000076bac53d340d  ptest xmm7, xmm7
000076bac53d3412  jnz 0x000076BAC53D7CE0
000076bac53d3418  vmovaps xmm1, [rsp+0x40]
000076bac53d341e  vpermilpd xmm1, xmm1, 0x00
000076bac53d3424  movaps xmm15, xmm4
000076bac53d3428  mulpd xmm15, xmm1
000076bac53d342d  vcmppd xmm7, xmm15, xmm15, 0x03
000076bac53d3433  ptest xmm7, xmm7
000076bac53d3438  jnz 0x000076BAC53D7E23
000076bac53d343e  movaps [r15+0x180], xmm15
000076bac53d3446  movaps xmm1, xmm14
000076bac53d344a  addpd xmm1, xmm11
000076bac53d344f  vcmppd xmm7, xmm1, xmm1, 0x03
000076bac53d3454  ptest xmm7, xmm7
000076bac53d3459  jnz 0x000076BAC53D7F65
000076bac53d345f  movaps [r15+0x210], xmm1
000076bac53d3467  movups xmm14, [r13+r14*1]
000076bac53d346d  lea rax, [r14+0x10]
000076bac53d3471  movups xmm11, [r13+rax*1]
000076bac53d3477  movaps [r15+0x230], xmm11
000076bac53d347f  movaps xmm7, xmm13
000076bac53d3483  addpd xmm7, xmm10
000076bac53d3488  vcmppd xmm6, xmm7, xmm7, 0x03
000076bac53d348d  ptest xmm6, xmm6
000076bac53d3492  jnz 0x000076BAC53D80BB
000076bac53d3498  movaps [r15+0x130], xmm7
000076bac53d34a0  vmovaps xmm13, [rsp+0x40]
000076bac53d34a6  vpermilpd xmm13, xmm13, 0x00
000076bac53d34ac  movaps xmm10, xmm11
000076bac53d34b0  mulpd xmm10, xmm13
000076bac53d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
000076bac53d34bb  ptest xmm6, xmm6
000076bac53d34c0  jnz 0x000076BAC53D81FD
000076bac53d34c6  movaps [r15+0x220], xmm10
000076bac53d34ce  vmovaps xmm13, [rsp+0x40]
000076bac53d34d4  vpermilpd xmm13, xmm13, 0x00
000076bac53d34da  movaps xmm11, xmm14
000076bac53d34de  mulpd xmm11, xmm13
000076bac53d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
000076bac53d34e9  ptest xmm6, xmm6
000076bac53d34ee  jnz 0x000076BAC53D8341
000076bac53d34f4  movaps xmm14, xmm12
000076bac53d34f8  addpd xmm14, xmm9
000076bac53d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
000076bac53d3503  ptest xmm13, xmm13
000076bac53d3509  jnz 0x000076BAC53D8485
000076bac53d350f  movaps [r15+0x140], xmm14
000076bac53d3517  movaps xmm13, xmm8
000076bac53d351b  addpd xmm13, xmm15
000076bac53d3520  vcmppd xmm12, xmm13, xmm13, 0x03
000076bac53d3526  ptest xmm12, xmm12
000076bac53d352c  jnz 0x000076BAC53D85C9
000076bac53d3532  movaps [r15+0x150], xmm13
000076bac53d353a  movaps xmm15, xmm1
000076bac53d353e  addpd xmm15, xmm10
000076bac53d3543  vcmppd xmm12, xmm15, xmm15, 0x03
000076bac53d3549  ptest xmm12, xmm12
000076bac53d354f  jnz 0x000076BAC53D870D
000076bac53d3555  movaps [r15+0x160], xmm15
000076bac53d355d  movaps xmm1, xmm7
000076bac53d3560  addpd xmm1, xmm11
000076bac53d3565  vcmppd xmm12, xmm1, xmm1, 0x03
000076bac53d356a  ptest xmm12, xmm12
000076bac53d3570  jnz 0x000076BAC53D8850
000076bac53d3576  movaps [r15+0x120], xmm1
000076bac53d357e  mov eax, 0x432200
000076bac53d3583  movups [r13+rax*1], xmm14
000076bac53d3589  mov eax, 0x432210
000076bac53d358e  movups [r13+rax*1], xmm13
000076bac53d3594  mov eax, 0x432220
000076bac53d3599  movups [r13+rax*1], xmm15
000076bac53d359f  mov eax, 0x432230
000076bac53d35a4  movups [r13+rax*1], xmm1
000076bac53d35aa  mov eax, [r15+0x108]
000076bac53d35b1  sahf
000076bac53d35b2  jnz 0x000076BAC53D35E4
000076bac53d35b4  cmp dword ptr [r15+0x318], 0x00
000076bac53d35bc  jz 0x000076BAC53DEAE0
000076bac53d35c2  nop [rax+rax*1], ax
000076bac53d35cb  nop [rax+rax*1], eax
000076bac53d35d3  mov eax, 0x4106D0
000076bac53d35d8  mov [r15+0x100], rax
000076bac53d35df  jmp 0x000076BAC51FE110
000076bac53d35e4  cmp dword ptr [r15+0x318], 0x00
000076bac53d35ec  jz 0x000076BAC53D89C0
000076bac53d35f2  nop [rax+rax*1], ax
000076bac53d35fb  nop [rax+rax*1], eax
000076bac53d3603  mov eax, 0x410504
000076bac53d3608  mov [r15+0x100], rax
000076bac53d360f  jmp 0x000076BAC51FE110
000076bac53d3614  int3
000076bac53d3615  call 0x000076BAC52D64F0
000076bac53d361a  jmp 0x000076BAC53D2311
000076bac53d361f  call 0x000076BAC52E5820
000076bac53d3624  jmp 0x000076BAC53D231E
000076bac53d3629  call 0x000076BAC52E3320
000076bac53d362e  jmp 0x000076BAC53D2332
000076bac53d3633  call 0x000076BAC52E20A0
000076bac53d3638  jmp 0x000076BAC53D233C
000076bac53d363d  call 0x000076BAC5209D70
000076bac53d3642  jmp 0x000076BAC53D234A
000076bac53d3647  call 0x000076BAC52DFBC0
000076bac53d364c  jmp 0x000076BAC53D2354
000076bac53d3651  call 0x000076BAC52C4740
000076bac53d3656  jmp 0x000076BAC53D2368
000076bac53d365b  call 0x000076BAC52B5400
000076bac53d3660  jmp 0x000076BAC53D2375
000076bac53d3665  call 0x000076BAC52B52F0
000076bac53d366a  jmp 0x000076BAC53D2382
000076bac53d366f  call 0x000076BAC52C4620
000076bac53d3674  jmp 0x000076BAC53D238F
000076bac53d3679  call 0x000076BAC52BD750
000076bac53d367e  jmp 0x000076BAC53D239C
000076bac53d3683  call 0x000076BAC52BC4E0
000076bac53d3688  jmp 0x000076BAC53D23A9
000076bac53d368d  call 0x000076BAC52BB270
000076bac53d3692  jmp 0x000076BAC53D23B6
000076bac53d3697  call 0x000076BAC52BA000
000076bac53d369c  jmp 0x000076BAC53D23C3
000076bac53d36a1  call 0x000076BAC52C4740
000076bac53d36a6  jmp 0x000076BAC53D23D0
000076bac53d36ab  call 0x000076BAC52B5400
000076bac53d36b0  jmp 0x000076BAC53D23DD
000076bac53d36b5  call 0x000076BAC52B52F0
000076bac53d36ba  jmp 0x000076BAC53D23EA
000076bac53d36bf  call 0x000076BAC52C4620
000076bac53d36c4  jmp 0x000076BAC53D23F7
000076bac53d36c9  call 0x000076BAC52B8D90
000076bac53d36ce  jmp 0x000076BAC53D2404
000076bac53d36d3  call 0x000076BAC52B8A20
000076bac53d36d8  jmp 0x000076BAC53D2411
000076bac53d36dd  call 0x000076BAC52B77B0
000076bac53d36e2  jmp 0x000076BAC53D241B
000076bac53d36e7  call 0x000076BAC52B6550
000076bac53d36ec  jmp 0x000076BAC53D2425
000076bac53d36f1  call 0x000076BAC52B5400
000076bac53d36f6  jmp 0x000076BAC53D2437
000076bac53d36fb  call 0x000076BAC52C0FC0
000076bac53d3700  jmp 0x000076BAC53D2441
000076bac53d3705  call 0x000076BAC52B52F0
000076bac53d370a  jmp 0x000076BAC53D244B
000076bac53d370f  call 0x000076BAC52C0EA0
000076bac53d3714  jmp 0x000076BAC53D2455
000076bac53d3719  call 0x000076BAC52BFD50
000076bac53d371e  jmp 0x000076BAC53D245F
000076bac53d3723  call 0x000076BAC52B8EA0
000076bac53d3728  jmp 0x000076BAC53D2469
000076bac53d372d  call 0x000076BAC52BFC30
000076bac53d3732  jmp 0x000076BAC53D2476
000076bac53d3737  call 0x000076BAC52B8D90
000076bac53d373c  jmp 0x000076BAC53D2483
000076bac53d3741  call 0x000076BAC52B52F0
000076bac53d3746  jmp 0x000076BAC53D2496
000076bac53d374b  call 0x000076BAC52B52F0
000076bac53d3750  jmp 0x000076BAC53D24A9
000076bac53d3755  call 0x000076BAC52C0FC0
000076bac53d375a  jmp 0x000076BAC53D24B6
000076bac53d375f  call 0x000076BAC52C0FC0
000076bac53d3764  jmp 0x000076BAC53D24C9
000076bac53d3769  call 0x000076BAC52C0EA0
000076bac53d376e  jmp 0x000076BAC53D24D6
000076bac53d3773  call 0x000076BAC52B52F0
000076bac53d3778  jmp 0x000076BAC53D24E9
000076bac53d377d  call 0x000076BAC52B52F0
000076bac53d3782  jmp 0x000076BAC53D24FC
000076bac53d3787  call 0x000076BAC52B52F0
000076bac53d378c  jmp 0x000076BAC53D250F
000076bac53d3791  call 0x000076BAC52B52F0
000076bac53d3796  jmp 0x000076BAC53D252A
000076bac53d379b  call 0x000076BAC52B52F0
000076bac53d37a0  jmp 0x000076BAC53D253D
000076bac53d37a5  call 0x000076BAC52B5400
000076bac53d37aa  jmp 0x000076BAC53D257E
000076bac53d37af  call 0x000076BAC52C0FC0
000076bac53d37b4  jmp 0x000076BAC53D258B
000076bac53d37b9  call 0x000076BAC52B52F0
000076bac53d37be  jmp 0x000076BAC53D2598
000076bac53d37c3  call 0x000076BAC52C0EA0
000076bac53d37c8  jmp 0x000076BAC53D25A5
000076bac53d37cd  call 0x000076BAC51FF540
000076bac53d37d2  jmp 0x000076BAC53D25C3
000076bac53d37d7  call 0x000076BAC5208C20
000076bac53d37dc  jmp 0x000076BAC53D25CD
000076bac53d37e1  call 0x000076BAC52E21C0
000076bac53d37e6  jmp 0x000076BAC53D25D3
000076bac53d37eb  call 0x000076BAC51FF540
000076bac53d37f0  jmp 0x000076BAC53D25E3
000076bac53d37f5  call 0x000076BAC52C0370
000076bac53d37fa  jmp 0x000076BAC53D2611
000076bac53d37ff  call 0x000076BAC52BF100
000076bac53d3804  jmp 0x000076BAC53D261A
000076bac53d3809  call 0x000076BAC52C0370
000076bac53d380e  jmp 0x000076BAC53D2674
000076bac53d3813  call 0x000076BAC52BF100
000076bac53d3818  jmp 0x000076BAC53D267D
000076bac53d381d  call 0x000076BAC52C0370
000076bac53d3822  jmp 0x000076BAC53D26C6
000076bac53d3827  call 0x000076BAC52BF100
000076bac53d382c  jmp 0x000076BAC53D26CF
000076bac53d3831  call 0x000076BAC520B720
000076bac53d3836  jmp 0x000076BAC53D2714
000076bac53d383b  call 0x000076BAC52B47C0
000076bac53d3840  jmp 0x000076BAC53D2727
000076bac53d3845  call 0x000076BAC5208B00
000076bac53d384a  jmp 0x000076BAC53D273E
000076bac53d384f  call 0x000076BAC51FF430
000076bac53d3854  jmp 0x000076BAC53D2751
000076bac53d3859  call 0x000076BAC51FF430
000076bac53d385e  jmp 0x000076BAC53D2764
000076bac53d3863  sub rsp, 0x08
000076bac53d3867  push rax
000076bac53d3868  push rcx
000076bac53d3869  push rdx
000076bac53d386a  push rdi
000076bac53d386b  push rsi
000076bac53d386c  push r8
000076bac53d386e  push r9
000076bac53d3870  push r10
000076bac53d3872  push r11
000076bac53d3874  sub rsp, 0xF0
000076bac53d387b  vmovaps [rsp], xmm0
000076bac53d3880  vmovaps [rsp+0x10], xmm2
000076bac53d3886  vmovaps [rsp+0x20], xmm3
000076bac53d388c  vmovaps [rsp+0x30], xmm4
000076bac53d3892  vmovaps [rsp+0x40], xmm5
000076bac53d3898  vmovaps [rsp+0x50], xmm6
000076bac53d389e  vmovaps [rsp+0x60], xmm7
000076bac53d38a4  vmovaps [rsp+0x70], xmm8
000076bac53d38aa  vmovaps [rsp+0x80], xmm9
000076bac53d38b3  vmovaps [rsp+0x90], xmm10
000076bac53d38bc  vmovaps [rsp+0xA0], xmm11
000076bac53d38c5  vmovaps [rsp+0xB0], xmm12
000076bac53d38ce  vmovaps [rsp+0xC0], xmm13
000076bac53d38d7  vmovaps [rsp+0xD0], xmm14
000076bac53d38e0  vmovaps [rsp+0xE0], xmm15
000076bac53d38e9  sub rsp, 0x30
000076bac53d38ed  movaps [rsp], xmm1
000076bac53d38f1  movaps [rsp+0x10], xmm12
000076bac53d38f7  movaps [rsp+0x20], xmm15
000076bac53d38fd  lea rdi, [rsp]
000076bac53d3901  mov esi, 0x00
000076bac53d3906  mov rax, 0x5641B0A3C530
000076bac53d3910  call rax
000076bac53d3912  movaps xmm1, [rsp]
000076bac53d3916  add rsp, 0x30
000076bac53d391a  vmovaps xmm0, [rsp]
000076bac53d391f  vmovaps xmm2, [rsp+0x10]
000076bac53d3925  vmovaps xmm3, [rsp+0x20]
000076bac53d392b  vmovaps xmm4, [rsp+0x30]
000076bac53d3931  vmovaps xmm5, [rsp+0x40]
000076bac53d3937  vmovaps xmm6, [rsp+0x50]
000076bac53d393d  vmovaps xmm7, [rsp+0x60]
000076bac53d3943  vmovaps xmm8, [rsp+0x70]
000076bac53d3949  vmovaps xmm9, [rsp+0x80]
000076bac53d3952  vmovaps xmm10, [rsp+0x90]
000076bac53d395b  vmovaps xmm11, [rsp+0xA0]
000076bac53d3964  vmovaps xmm12, [rsp+0xB0]
000076bac53d396d  vmovaps xmm13, [rsp+0xC0]
000076bac53d3976  vmovaps xmm14, [rsp+0xD0]
000076bac53d397f  vmovaps xmm15, [rsp+0xE0]
000076bac53d3988  add rsp, 0xF0
000076bac53d398f  pop r11
000076bac53d3991  pop r10
000076bac53d3993  pop r9
000076bac53d3995  pop r8
000076bac53d3997  pop rsi
000076bac53d3998  pop rdi
000076bac53d3999  pop rdx
000076bac53d399a  pop rcx
000076bac53d399b  pop rax
000076bac53d399c  add rsp, 0x08
000076bac53d39a0  jmp 0x000076BAC53D27B2
000076bac53d39a5  sub rsp, 0x08
000076bac53d39a9  push rax
000076bac53d39aa  push rcx
000076bac53d39ab  push rdx
000076bac53d39ac  push rdi
000076bac53d39ad  push rsi
000076bac53d39ae  push r8
000076bac53d39b0  push r9
000076bac53d39b2  push r10
000076bac53d39b4  push r11
000076bac53d39b6  sub rsp, 0xF0
000076bac53d39bd  vmovaps [rsp], xmm0
000076bac53d39c2  vmovaps [rsp+0x10], xmm1
000076bac53d39c8  vmovaps [rsp+0x20], xmm2
000076bac53d39ce  vmovaps [rsp+0x30], xmm3
000076bac53d39d4  vmovaps [rsp+0x40], xmm4
000076bac53d39da  vmovaps [rsp+0x50], xmm5
000076bac53d39e0  vmovaps [rsp+0x60], xmm6
000076bac53d39e6  vmovaps [rsp+0x70], xmm7
000076bac53d39ec  vmovaps [rsp+0x80], xmm8
000076bac53d39f5  vmovaps [rsp+0x90], xmm9
000076bac53d39fe  vmovaps [rsp+0xA0], xmm10
000076bac53d3a07  vmovaps [rsp+0xB0], xmm11
000076bac53d3a10  vmovaps [rsp+0xC0], xmm12
000076bac53d3a19  vmovaps [rsp+0xD0], xmm13
000076bac53d3a22  vmovaps [rsp+0xE0], xmm15
000076bac53d3a2b  sub rsp, 0x30
000076bac53d3a2f  movaps [rsp], xmm14
000076bac53d3a34  movaps [rsp+0x10], xmm1
000076bac53d3a39  movaps [rsp+0x20], xmm15
000076bac53d3a3f  lea rdi, [rsp]
000076bac53d3a43  mov esi, 0x00
000076bac53d3a48  mov rax, 0x5641B0A3C530
000076bac53d3a52  call rax
000076bac53d3a54  movaps xmm14, [rsp]
000076bac53d3a59  add rsp, 0x30
000076bac53d3a5d  vmovaps xmm0, [rsp]
000076bac53d3a62  vmovaps xmm1, [rsp+0x10]
000076bac53d3a68  vmovaps xmm2, [rsp+0x20]
000076bac53d3a6e  vmovaps xmm3, [rsp+0x30]
000076bac53d3a74  vmovaps xmm4, [rsp+0x40]
000076bac53d3a7a  vmovaps xmm5, [rsp+0x50]
000076bac53d3a80  vmovaps xmm6, [rsp+0x60]
000076bac53d3a86  vmovaps xmm7, [rsp+0x70]
000076bac53d3a8c  vmovaps xmm8, [rsp+0x80]
000076bac53d3a95  vmovaps xmm9, [rsp+0x90]
000076bac53d3a9e  vmovaps xmm10, [rsp+0xA0]
000076bac53d3aa7  vmovaps xmm11, [rsp+0xB0]
000076bac53d3ab0  vmovaps xmm12, [rsp+0xC0]
000076bac53d3ab9  vmovaps xmm13, [rsp+0xD0]
000076bac53d3ac2  vmovaps xmm15, [rsp+0xE0]
000076bac53d3acb  add rsp, 0xF0
000076bac53d3ad2  pop r11
000076bac53d3ad4  pop r10
000076bac53d3ad6  pop r9
000076bac53d3ad8  pop r8
000076bac53d3ada  pop rsi
000076bac53d3adb  pop rdi
000076bac53d3adc  pop rdx
000076bac53d3add  pop rcx
000076bac53d3ade  pop rax
000076bac53d3adf  add rsp, 0x08
000076bac53d3ae3  jmp 0x000076BAC53D2800
000076bac53d3ae8  sub rsp, 0x08
000076bac53d3aec  push rax
000076bac53d3aed  push rcx
000076bac53d3aee  push rdx
000076bac53d3aef  push rdi
000076bac53d3af0  push rsi
000076bac53d3af1  push r8
000076bac53d3af3  push r9
000076bac53d3af5  push r10
000076bac53d3af7  push r11
000076bac53d3af9  sub rsp, 0xF0
000076bac53d3b00  vmovaps [rsp], xmm0
000076bac53d3b05  vmovaps [rsp+0x10], xmm1
000076bac53d3b0b  vmovaps [rsp+0x20], xmm2
000076bac53d3b11  vmovaps [rsp+0x30], xmm3
000076bac53d3b17  vmovaps [rsp+0x40], xmm4
000076bac53d3b1d  vmovaps [rsp+0x50], xmm5
000076bac53d3b23  vmovaps [rsp+0x60], xmm6
000076bac53d3b29  vmovaps [rsp+0x70], xmm7
000076bac53d3b2f  vmovaps [rsp+0x80], xmm8
000076bac53d3b38  vmovaps [rsp+0x90], xmm9
000076bac53d3b41  vmovaps [rsp+0xA0], xmm10
000076bac53d3b4a  vmovaps [rsp+0xB0], xmm11
000076bac53d3b53  vmovaps [rsp+0xC0], xmm12
000076bac53d3b5c  vmovaps [rsp+0xD0], xmm13
000076bac53d3b65  vmovaps [rsp+0xE0], xmm14
000076bac53d3b6e  sub rsp, 0x30
000076bac53d3b72  movaps [rsp], xmm15
000076bac53d3b77  movaps [rsp+0x10], xmm12
000076bac53d3b7d  movaps [rsp+0x20], xmm13
000076bac53d3b83  lea rdi, [rsp]
000076bac53d3b87  mov esi, 0x00
000076bac53d3b8c  mov rax, 0x5641B0A3C530
000076bac53d3b96  call rax
000076bac53d3b98  movaps xmm15, [rsp]
000076bac53d3b9d  add rsp, 0x30
000076bac53d3ba1  vmovaps xmm0, [rsp]
000076bac53d3ba6  vmovaps xmm1, [rsp+0x10]
000076bac53d3bac  vmovaps xmm2, [rsp+0x20]
000076bac53d3bb2  vmovaps xmm3, [rsp+0x30]
000076bac53d3bb8  vmovaps xmm4, [rsp+0x40]
000076bac53d3bbe  vmovaps xmm5, [rsp+0x50]
000076bac53d3bc4  vmovaps xmm6, [rsp+0x60]
000076bac53d3bca  vmovaps xmm7, [rsp+0x70]
000076bac53d3bd0  vmovaps xmm8, [rsp+0x80]
000076bac53d3bd9  vmovaps xmm9, [rsp+0x90]
000076bac53d3be2  vmovaps xmm10, [rsp+0xA0]
000076bac53d3beb  vmovaps xmm11, [rsp+0xB0]
000076bac53d3bf4  vmovaps xmm12, [rsp+0xC0]
000076bac53d3bfd  vmovaps xmm13, [rsp+0xD0]
000076bac53d3c06  vmovaps xmm14, [rsp+0xE0]
000076bac53d3c0f  add rsp, 0xF0
000076bac53d3c16  pop r11
000076bac53d3c18  pop r10
000076bac53d3c1a  pop r9
000076bac53d3c1c  pop r8
000076bac53d3c1e  pop rsi
000076bac53d3c1f  pop rdi
000076bac53d3c20  pop rdx
000076bac53d3c21  pop rcx
000076bac53d3c22  pop rax
000076bac53d3c23  add rsp, 0x08
000076bac53d3c27  jmp 0x000076BAC53D2835
000076bac53d3c2c  sub rsp, 0x08
000076bac53d3c30  push rax
000076bac53d3c31  push rcx
000076bac53d3c32  push rdx
000076bac53d3c33  push rdi
000076bac53d3c34  push rsi
000076bac53d3c35  push r8
000076bac53d3c37  push r9
000076bac53d3c39  push r10
000076bac53d3c3b  push r11
000076bac53d3c3d  sub rsp, 0xF0
000076bac53d3c44  vmovaps [rsp], xmm0
000076bac53d3c49  vmovaps [rsp+0x10], xmm2
000076bac53d3c4f  vmovaps [rsp+0x20], xmm3
000076bac53d3c55  vmovaps [rsp+0x30], xmm4
000076bac53d3c5b  vmovaps [rsp+0x40], xmm5
000076bac53d3c61  vmovaps [rsp+0x50], xmm6
000076bac53d3c67  vmovaps [rsp+0x60], xmm7
000076bac53d3c6d  vmovaps [rsp+0x70], xmm8
000076bac53d3c73  vmovaps [rsp+0x80], xmm9
000076bac53d3c7c  vmovaps [rsp+0x90], xmm10
000076bac53d3c85  vmovaps [rsp+0xA0], xmm11
000076bac53d3c8e  vmovaps [rsp+0xB0], xmm12
000076bac53d3c97  vmovaps [rsp+0xC0], xmm13
000076bac53d3ca0  vmovaps [rsp+0xD0], xmm14
000076bac53d3ca9  vmovaps [rsp+0xE0], xmm15
000076bac53d3cb2  sub rsp, 0x30
000076bac53d3cb6  movaps [rsp], xmm1
000076bac53d3cba  movaps [rsp+0x10], xmm12
000076bac53d3cc0  movaps [rsp+0x20], xmm10
000076bac53d3cc6  lea rdi, [rsp]
000076bac53d3cca  mov esi, 0x00
000076bac53d3ccf  mov rax, 0x5641B0A3C530
000076bac53d3cd9  call rax
000076bac53d3cdb  movaps xmm1, [rsp]
000076bac53d3cdf  add rsp, 0x30
000076bac53d3ce3  vmovaps xmm0, [rsp]
000076bac53d3ce8  vmovaps xmm2, [rsp+0x10]
000076bac53d3cee  vmovaps xmm3, [rsp+0x20]
000076bac53d3cf4  vmovaps xmm4, [rsp+0x30]
000076bac53d3cfa  vmovaps xmm5, [rsp+0x40]
000076bac53d3d00  vmovaps xmm6, [rsp+0x50]
000076bac53d3d06  vmovaps xmm7, [rsp+0x60]
000076bac53d3d0c  vmovaps xmm8, [rsp+0x70]
000076bac53d3d12  vmovaps xmm9, [rsp+0x80]
000076bac53d3d1b  vmovaps xmm10, [rsp+0x90]
000076bac53d3d24  vmovaps xmm11, [rsp+0xA0]
000076bac53d3d2d  vmovaps xmm12, [rsp+0xB0]
000076bac53d3d36  vmovaps xmm13, [rsp+0xC0]
000076bac53d3d3f  vmovaps xmm14, [rsp+0xD0]
000076bac53d3d48  vmovaps xmm15, [rsp+0xE0]
000076bac53d3d51  add rsp, 0xF0
000076bac53d3d58  pop r11
000076bac53d3d5a  pop r10
000076bac53d3d5c  pop r9
000076bac53d3d5e  pop r8
000076bac53d3d60  pop rsi
000076bac53d3d61  pop rdi
000076bac53d3d62  pop rdx
000076bac53d3d63  pop rcx
000076bac53d3d64  pop rax
000076bac53d3d65  add rsp, 0x08
000076bac53d3d69  jmp 0x000076BAC53D284F
000076bac53d3d6e  sub rsp, 0x08
000076bac53d3d72  push rax
000076bac53d3d73  push rcx
000076bac53d3d74  push rdx
000076bac53d3d75  push rdi
000076bac53d3d76  push rsi
000076bac53d3d77  push r8
000076bac53d3d79  push r9
000076bac53d3d7b  push r10
000076bac53d3d7d  push r11
000076bac53d3d7f  sub rsp, 0xF0
000076bac53d3d86  vmovaps [rsp], xmm0
000076bac53d3d8b  vmovaps [rsp+0x10], xmm1
000076bac53d3d91  vmovaps [rsp+0x20], xmm2
000076bac53d3d97  vmovaps [rsp+0x30], xmm3
000076bac53d3d9d  vmovaps [rsp+0x40], xmm4
000076bac53d3da3  vmovaps [rsp+0x50], xmm5
000076bac53d3da9  vmovaps [rsp+0x60], xmm6
000076bac53d3daf  vmovaps [rsp+0x70], xmm7
000076bac53d3db5  vmovaps [rsp+0x80], xmm8
000076bac53d3dbe  vmovaps [rsp+0x90], xmm9
000076bac53d3dc7  vmovaps [rsp+0xA0], xmm10
000076bac53d3dd0  vmovaps [rsp+0xB0], xmm11
000076bac53d3dd9  vmovaps [rsp+0xC0], xmm12
000076bac53d3de2  vmovaps [rsp+0xD0], xmm14
000076bac53d3deb  vmovaps [rsp+0xE0], xmm15
000076bac53d3df4  sub rsp, 0x30
000076bac53d3df8  movaps [rsp], xmm13
000076bac53d3dfd  movaps [rsp+0x10], xmm12
000076bac53d3e03  movaps [rsp+0x20], xmm2
000076bac53d3e08  lea rdi, [rsp]
000076bac53d3e0c  mov esi, 0x00
000076bac53d3e11  mov rax, 0x5641B0A3C530
000076bac53d3e1b  call rax
000076bac53d3e1d  movaps xmm13, [rsp]
000076bac53d3e22  add rsp, 0x30
000076bac53d3e26  vmovaps xmm0, [rsp]
000076bac53d3e2b  vmovaps xmm1, [rsp+0x10]
000076bac53d3e31  vmovaps xmm2, [rsp+0x20]
000076bac53d3e37  vmovaps xmm3, [rsp+0x30]
000076bac53d3e3d  vmovaps xmm4, [rsp+0x40]
000076bac53d3e43  vmovaps xmm5, [rsp+0x50]
000076bac53d3e49  vmovaps xmm6, [rsp+0x60]
000076bac53d3e4f  vmovaps xmm7, [rsp+0x70]
000076bac53d3e55  vmovaps xmm8, [rsp+0x80]
000076bac53d3e5e  vmovaps xmm9, [rsp+0x90]
000076bac53d3e67  vmovaps xmm10, [rsp+0xA0]
000076bac53d3e70  vmovaps xmm11, [rsp+0xB0]
000076bac53d3e79  vmovaps xmm12, [rsp+0xC0]
000076bac53d3e82  vmovaps xmm14, [rsp+0xD0]
000076bac53d3e8b  vmovaps xmm15, [rsp+0xE0]
000076bac53d3e94  add rsp, 0xF0
000076bac53d3e9b  pop r11
000076bac53d3e9d  pop r10
000076bac53d3e9f  pop r9
000076bac53d3ea1  pop r8
000076bac53d3ea3  pop rsi
000076bac53d3ea4  pop rdi
000076bac53d3ea5  pop rdx
000076bac53d3ea6  pop rcx
000076bac53d3ea7  pop rax
000076bac53d3ea8  add rsp, 0x08
000076bac53d3eac  jmp 0x000076BAC53D286A
000076bac53d3eb1  sub rsp, 0x08
000076bac53d3eb5  push rax
000076bac53d3eb6  push rcx
000076bac53d3eb7  push rdx
000076bac53d3eb8  push rdi
000076bac53d3eb9  push rsi
000076bac53d3eba  push r8
000076bac53d3ebc  push r9
000076bac53d3ebe  push r10
000076bac53d3ec0  push r11
000076bac53d3ec2  sub rsp, 0xF0
000076bac53d3ec9  vmovaps [rsp], xmm0
000076bac53d3ece  vmovaps [rsp+0x10], xmm2
000076bac53d3ed4  vmovaps [rsp+0x20], xmm3
000076bac53d3eda  vmovaps [rsp+0x30], xmm4
000076bac53d3ee0  vmovaps [rsp+0x40], xmm5
000076bac53d3ee6  vmovaps [rsp+0x50], xmm6
000076bac53d3eec  vmovaps [rsp+0x60], xmm7
000076bac53d3ef2  vmovaps [rsp+0x70], xmm8
000076bac53d3ef8  vmovaps [rsp+0x80], xmm9
000076bac53d3f01  vmovaps [rsp+0x90], xmm10
000076bac53d3f0a  vmovaps [rsp+0xA0], xmm11
000076bac53d3f13  vmovaps [rsp+0xB0], xmm12
000076bac53d3f1c  vmovaps [rsp+0xC0], xmm13
000076bac53d3f25  vmovaps [rsp+0xD0], xmm14
000076bac53d3f2e  vmovaps [rsp+0xE0], xmm15
000076bac53d3f37  sub rsp, 0x30
000076bac53d3f3b  movaps [rsp], xmm1
000076bac53d3f3f  movaps [rsp+0x10], xmm10
000076bac53d3f45  movaps [rsp+0x20], xmm2
000076bac53d3f4a  lea rdi, [rsp]
000076bac53d3f4e  mov esi, 0x00
000076bac53d3f53  mov rax, 0x5641B0A3C530
000076bac53d3f5d  call rax
000076bac53d3f5f  movaps xmm1, [rsp]
000076bac53d3f63  add rsp, 0x30
000076bac53d3f67  vmovaps xmm0, [rsp]
000076bac53d3f6c  vmovaps xmm2, [rsp+0x10]
000076bac53d3f72  vmovaps xmm3, [rsp+0x20]
000076bac53d3f78  vmovaps xmm4, [rsp+0x30]
000076bac53d3f7e  vmovaps xmm5, [rsp+0x40]
000076bac53d3f84  vmovaps xmm6, [rsp+0x50]
000076bac53d3f8a  vmovaps xmm7, [rsp+0x60]
000076bac53d3f90  vmovaps xmm8, [rsp+0x70]
000076bac53d3f96  vmovaps xmm9, [rsp+0x80]
000076bac53d3f9f  vmovaps xmm10, [rsp+0x90]
000076bac53d3fa8  vmovaps xmm11, [rsp+0xA0]
000076bac53d3fb1  vmovaps xmm12, [rsp+0xB0]
000076bac53d3fba  vmovaps xmm13, [rsp+0xC0]
000076bac53d3fc3  vmovaps xmm14, [rsp+0xD0]
000076bac53d3fcc  vmovaps xmm15, [rsp+0xE0]
000076bac53d3fd5  add rsp, 0xF0
000076bac53d3fdc  pop r11
000076bac53d3fde  pop r10
000076bac53d3fe0  pop r9
000076bac53d3fe2  pop r8
000076bac53d3fe4  pop rsi
000076bac53d3fe5  pop rdi
000076bac53d3fe6  pop rdx
000076bac53d3fe7  pop rcx
000076bac53d3fe8  pop rax
000076bac53d3fe9  add rsp, 0x08
000076bac53d3fed  jmp 0x000076BAC53D28D2
000076bac53d3ff2  sub rsp, 0x08
000076bac53d3ff6  push rax
000076bac53d3ff7  push rcx
000076bac53d3ff8  push rdx
000076bac53d3ff9  push rdi
000076bac53d3ffa  push rsi
000076bac53d3ffb  push r8
000076bac53d3ffd  push r9
000076bac53d3fff  push r10
000076bac53d4001  push r11
000076bac53d4003  sub rsp, 0xF0
000076bac53d400a  vmovaps [rsp], xmm0
000076bac53d400f  vmovaps [rsp+0x10], xmm1
000076bac53d4015  vmovaps [rsp+0x20], xmm2
000076bac53d401b  vmovaps [rsp+0x30], xmm3
000076bac53d4021  vmovaps [rsp+0x40], xmm4
000076bac53d4027  vmovaps [rsp+0x50], xmm5
000076bac53d402d  vmovaps [rsp+0x60], xmm6
000076bac53d4033  vmovaps [rsp+0x70], xmm7
000076bac53d4039  vmovaps [rsp+0x80], xmm8
000076bac53d4042  vmovaps [rsp+0x90], xmm9
000076bac53d404b  vmovaps [rsp+0xA0], xmm10
000076bac53d4054  vmovaps [rsp+0xB0], xmm11
000076bac53d405d  vmovaps [rsp+0xC0], xmm12
000076bac53d4066  vmovaps [rsp+0xD0], xmm13
000076bac53d406f  vmovaps [rsp+0xE0], xmm14
000076bac53d4078  sub rsp, 0x30
000076bac53d407c  movaps [rsp], xmm15
000076bac53d4081  movaps [rsp+0x10], xmm10
000076bac53d4087  movaps [rsp+0x20], xmm2
000076bac53d408c  lea rdi, [rsp]
000076bac53d4090  mov esi, 0x00
000076bac53d4095  mov rax, 0x5641B0A3C530
000076bac53d409f  call rax
000076bac53d40a1  movaps xmm15, [rsp]
000076bac53d40a6  add rsp, 0x30
000076bac53d40aa  vmovaps xmm0, [rsp]
000076bac53d40af  vmovaps xmm1, [rsp+0x10]
000076bac53d40b5  vmovaps xmm2, [rsp+0x20]
000076bac53d40bb  vmovaps xmm3, [rsp+0x30]
000076bac53d40c1  vmovaps xmm4, [rsp+0x40]
000076bac53d40c7  vmovaps xmm5, [rsp+0x50]
000076bac53d40cd  vmovaps xmm6, [rsp+0x60]
000076bac53d40d3  vmovaps xmm7, [rsp+0x70]
000076bac53d40d9  vmovaps xmm8, [rsp+0x80]
000076bac53d40e2  vmovaps xmm9, [rsp+0x90]
000076bac53d40eb  vmovaps xmm10, [rsp+0xA0]
000076bac53d40f4  vmovaps xmm11, [rsp+0xB0]
000076bac53d40fd  vmovaps xmm12, [rsp+0xC0]
000076bac53d4106  vmovaps xmm13, [rsp+0xD0]
000076bac53d410f  vmovaps xmm14, [rsp+0xE0]
000076bac53d4118  add rsp, 0xF0
000076bac53d411f  pop r11
000076bac53d4121  pop r10
000076bac53d4123  pop r9
000076bac53d4125  pop r8
000076bac53d4127  pop rsi
000076bac53d4128  pop rdi
000076bac53d4129  pop rdx
000076bac53d412a  pop rcx
000076bac53d412b  pop rax
000076bac53d412c  add rsp, 0x08
000076bac53d4130  jmp 0x000076BAC53D2924
000076bac53d4135  sub rsp, 0x08
000076bac53d4139  push rax
000076bac53d413a  push rcx
000076bac53d413b  push rdx
000076bac53d413c  push rdi
000076bac53d413d  push rsi
000076bac53d413e  push r8
000076bac53d4140  push r9
000076bac53d4142  push r10
000076bac53d4144  push r11
000076bac53d4146  sub rsp, 0xF0
000076bac53d414d  vmovaps [rsp], xmm0
000076bac53d4152  vmovaps [rsp+0x10], xmm2
000076bac53d4158  vmovaps [rsp+0x20], xmm3
000076bac53d415e  vmovaps [rsp+0x30], xmm4
000076bac53d4164  vmovaps [rsp+0x40], xmm5
000076bac53d416a  vmovaps [rsp+0x50], xmm6
000076bac53d4170  vmovaps [rsp+0x60], xmm7
000076bac53d4176  vmovaps [rsp+0x70], xmm8
000076bac53d417c  vmovaps [rsp+0x80], xmm9
000076bac53d4185  vmovaps [rsp+0x90], xmm10
000076bac53d418e  vmovaps [rsp+0xA0], xmm11
000076bac53d4197  vmovaps [rsp+0xB0], xmm12
000076bac53d41a0  vmovaps [rsp+0xC0], xmm13
000076bac53d41a9  vmovaps [rsp+0xD0], xmm14
000076bac53d41b2  vmovaps [rsp+0xE0], xmm15
000076bac53d41bb  sub rsp, 0x30
000076bac53d41bf  movaps [rsp], xmm1
000076bac53d41c3  movaps [rsp+0x10], xmm10
000076bac53d41c9  movaps [rsp+0x20], xmm15
000076bac53d41cf  lea rdi, [rsp]
000076bac53d41d3  mov esi, 0x00
000076bac53d41d8  mov rax, 0x5641B0A3C530
000076bac53d41e2  call rax
000076bac53d41e4  movaps xmm1, [rsp]
000076bac53d41e8  add rsp, 0x30
000076bac53d41ec  vmovaps xmm0, [rsp]
000076bac53d41f1  vmovaps xmm2, [rsp+0x10]
000076bac53d41f7  vmovaps xmm3, [rsp+0x20]
000076bac53d41fd  vmovaps xmm4, [rsp+0x30]
000076bac53d4203  vmovaps xmm5, [rsp+0x40]
000076bac53d4209  vmovaps xmm6, [rsp+0x50]
000076bac53d420f  vmovaps xmm7, [rsp+0x60]
000076bac53d4215  vmovaps xmm8, [rsp+0x70]
000076bac53d421b  vmovaps xmm9, [rsp+0x80]
000076bac53d4224  vmovaps xmm10, [rsp+0x90]
000076bac53d422d  vmovaps xmm11, [rsp+0xA0]
000076bac53d4236  vmovaps xmm12, [rsp+0xB0]
000076bac53d423f  vmovaps xmm13, [rsp+0xC0]
000076bac53d4248  vmovaps xmm14, [rsp+0xD0]
000076bac53d4251  vmovaps xmm15, [rsp+0xE0]
000076bac53d425a  add rsp, 0xF0
000076bac53d4261  pop r11
000076bac53d4263  pop r10
000076bac53d4265  pop r9
000076bac53d4267  pop r8
000076bac53d4269  pop rsi
000076bac53d426a  pop rdi
000076bac53d426b  pop rdx
000076bac53d426c  pop rcx
000076bac53d426d  pop rax
000076bac53d426e  add rsp, 0x08
000076bac53d4272  jmp 0x000076BAC53D2962
000076bac53d4277  sub rsp, 0x08
000076bac53d427b  push rax
000076bac53d427c  push rcx
000076bac53d427d  push rdx
000076bac53d427e  push rdi
000076bac53d427f  push rsi
000076bac53d4280  push r8
000076bac53d4282  push r9
000076bac53d4284  push r10
000076bac53d4286  push r11
000076bac53d4288  sub rsp, 0xF0
000076bac53d428f  vmovaps [rsp], xmm0
000076bac53d4294  vmovaps [rsp+0x10], xmm1
000076bac53d429a  vmovaps [rsp+0x20], xmm2
000076bac53d42a0  vmovaps [rsp+0x30], xmm3
000076bac53d42a6  vmovaps [rsp+0x40], xmm4
000076bac53d42ac  vmovaps [rsp+0x50], xmm5
000076bac53d42b2  vmovaps [rsp+0x60], xmm6
000076bac53d42b8  vmovaps [rsp+0x70], xmm7
000076bac53d42be  vmovaps [rsp+0x80], xmm8
000076bac53d42c7  vmovaps [rsp+0x90], xmm9
000076bac53d42d0  vmovaps [rsp+0xA0], xmm10
000076bac53d42d9  vmovaps [rsp+0xB0], xmm11
000076bac53d42e2  vmovaps [rsp+0xC0], xmm12
000076bac53d42eb  vmovaps [rsp+0xD0], xmm13
000076bac53d42f4  vmovaps [rsp+0xE0], xmm15
000076bac53d42fd  sub rsp, 0x30
000076bac53d4301  movaps [rsp], xmm14
000076bac53d4306  movaps [rsp+0x10], xmm10
000076bac53d430c  movaps [rsp+0x20], xmm15
000076bac53d4312  lea rdi, [rsp]
000076bac53d4316  mov esi, 0x00
000076bac53d431b  mov rax, 0x5641B0A3C530
000076bac53d4325  call rax
000076bac53d4327  movaps xmm14, [rsp]
000076bac53d432c  add rsp, 0x30
000076bac53d4330  vmovaps xmm0, [rsp]
000076bac53d4335  vmovaps xmm1, [rsp+0x10]
000076bac53d433b  vmovaps xmm2, [rsp+0x20]
000076bac53d4341  vmovaps xmm3, [rsp+0x30]
000076bac53d4347  vmovaps xmm4, [rsp+0x40]
000076bac53d434d  vmovaps xmm5, [rsp+0x50]
000076bac53d4353  vmovaps xmm6, [rsp+0x60]
000076bac53d4359  vmovaps xmm7, [rsp+0x70]
000076bac53d435f  vmovaps xmm8, [rsp+0x80]
000076bac53d4368  vmovaps xmm9, [rsp+0x90]
000076bac53d4371  vmovaps xmm10, [rsp+0xA0]
000076bac53d437a  vmovaps xmm11, [rsp+0xB0]
000076bac53d4383  vmovaps xmm12, [rsp+0xC0]
000076bac53d438c  vmovaps xmm13, [rsp+0xD0]
000076bac53d4395  vmovaps xmm15, [rsp+0xE0]
000076bac53d439e  add rsp, 0xF0
000076bac53d43a5  pop r11
000076bac53d43a7  pop r10
000076bac53d43a9  pop r9
000076bac53d43ab  pop r8
000076bac53d43ad  pop rsi
000076bac53d43ae  pop rdi
000076bac53d43af  pop rdx
000076bac53d43b0  pop rcx
000076bac53d43b1  pop rax
000076bac53d43b2  add rsp, 0x08
000076bac53d43b6  jmp 0x000076BAC53D298E
000076bac53d43bb  call 0x000076BAC51FF430
000076bac53d43c0  jmp 0x000076BAC53D2A1E
000076bac53d43c5  call 0x000076BAC51FF430
000076bac53d43ca  jmp 0x000076BAC53D2A31
000076bac53d43cf  sub rsp, 0x08
000076bac53d43d3  push rax
000076bac53d43d4  push rcx
000076bac53d43d5  push rdx
000076bac53d43d6  push rdi
000076bac53d43d7  push rsi
000076bac53d43d8  push r8
000076bac53d43da  push r9
000076bac53d43dc  push r10
000076bac53d43de  push r11
000076bac53d43e0  sub rsp, 0xF0
000076bac53d43e7  vmovaps [rsp], xmm0
000076bac53d43ec  vmovaps [rsp+0x10], xmm2
000076bac53d43f2  vmovaps [rsp+0x20], xmm3
000076bac53d43f8  vmovaps [rsp+0x30], xmm4
000076bac53d43fe  vmovaps [rsp+0x40], xmm5
000076bac53d4404  vmovaps [rsp+0x50], xmm6
000076bac53d440a  vmovaps [rsp+0x60], xmm7
000076bac53d4410  vmovaps [rsp+0x70], xmm8
000076bac53d4416  vmovaps [rsp+0x80], xmm9
000076bac53d441f  vmovaps [rsp+0x90], xmm10
000076bac53d4428  vmovaps [rsp+0xA0], xmm11
000076bac53d4431  vmovaps [rsp+0xB0], xmm12
000076bac53d443a  vmovaps [rsp+0xC0], xmm13
000076bac53d4443  vmovaps [rsp+0xD0], xmm14
000076bac53d444c  vmovaps [rsp+0xE0], xmm15
000076bac53d4455  sub rsp, 0x30
000076bac53d4459  movaps [rsp], xmm1
000076bac53d445d  movaps [rsp+0x10], xmm13
000076bac53d4463  movaps [rsp+0x20], xmm2
000076bac53d4468  lea rdi, [rsp]
000076bac53d446c  mov esi, 0x00
000076bac53d4471  mov rax, 0x5641B0A3C530
000076bac53d447b  call rax
000076bac53d447d  movaps xmm1, [rsp]
000076bac53d4481  add rsp, 0x30
000076bac53d4485  vmovaps xmm0, [rsp]
000076bac53d448a  vmovaps xmm2, [rsp+0x10]
000076bac53d4490  vmovaps xmm3, [rsp+0x20]
000076bac53d4496  vmovaps xmm4, [rsp+0x30]
000076bac53d449c  vmovaps xmm5, [rsp+0x40]
000076bac53d44a2  vmovaps xmm6, [rsp+0x50]
000076bac53d44a8  vmovaps xmm7, [rsp+0x60]
000076bac53d44ae  vmovaps xmm8, [rsp+0x70]
000076bac53d44b4  vmovaps xmm9, [rsp+0x80]
000076bac53d44bd  vmovaps xmm10, [rsp+0x90]
000076bac53d44c6  vmovaps xmm11, [rsp+0xA0]
000076bac53d44cf  vmovaps xmm12, [rsp+0xB0]
000076bac53d44d8  vmovaps xmm13, [rsp+0xC0]
000076bac53d44e1  vmovaps xmm14, [rsp+0xD0]
000076bac53d44ea  vmovaps xmm15, [rsp+0xE0]
000076bac53d44f3  add rsp, 0xF0
000076bac53d44fa  pop r11
000076bac53d44fc  pop r10
000076bac53d44fe  pop r9
000076bac53d4500  pop r8
000076bac53d4502  pop rsi
000076bac53d4503  pop rdi
000076bac53d4504  pop rdx
000076bac53d4505  pop rcx
000076bac53d4506  pop rax
000076bac53d4507  add rsp, 0x08
000076bac53d450b  jmp 0x000076BAC53D2A5C
000076bac53d4510  call 0x000076BAC520E760
000076bac53d4515  jmp 0x000076BAC53D2A69
000076bac53d451a  sub rsp, 0x08
000076bac53d451e  push rax
000076bac53d451f  push rcx
000076bac53d4520  push rdx
000076bac53d4521  push rdi
000076bac53d4522  push rsi
000076bac53d4523  push r8
000076bac53d4525  push r9
000076bac53d4527  push r10
000076bac53d4529  push r11
000076bac53d452b  sub rsp, 0xF0
000076bac53d4532  vmovaps [rsp], xmm0
000076bac53d4537  vmovaps [rsp+0x10], xmm1
000076bac53d453d  vmovaps [rsp+0x20], xmm2
000076bac53d4543  vmovaps [rsp+0x30], xmm3
000076bac53d4549  vmovaps [rsp+0x40], xmm4
000076bac53d454f  vmovaps [rsp+0x50], xmm5
000076bac53d4555  vmovaps [rsp+0x60], xmm6
000076bac53d455b  vmovaps [rsp+0x70], xmm7
000076bac53d4561  vmovaps [rsp+0x80], xmm8
000076bac53d456a  vmovaps [rsp+0x90], xmm9
000076bac53d4573  vmovaps [rsp+0xA0], xmm10
000076bac53d457c  vmovaps [rsp+0xB0], xmm11
000076bac53d4585  vmovaps [rsp+0xC0], xmm12
000076bac53d458e  vmovaps [rsp+0xD0], xmm14
000076bac53d4597  vmovaps [rsp+0xE0], xmm15
000076bac53d45a0  sub rsp, 0x30
000076bac53d45a4  movaps [rsp], xmm13
000076bac53d45a9  movaps [rsp+0x10], xmm2
000076bac53d45ae  movaps [rsp+0x20], xmm1
000076bac53d45b3  lea rdi, [rsp]
000076bac53d45b7  mov esi, 0x00
000076bac53d45bc  mov rax, 0x5641B0A3C530
000076bac53d45c6  call rax
000076bac53d45c8  movaps xmm13, [rsp]
000076bac53d45cd  add rsp, 0x30
000076bac53d45d1  vmovaps xmm0, [rsp]
000076bac53d45d6  vmovaps xmm1, [rsp+0x10]
000076bac53d45dc  vmovaps xmm2, [rsp+0x20]
000076bac53d45e2  vmovaps xmm3, [rsp+0x30]
000076bac53d45e8  vmovaps xmm4, [rsp+0x40]
000076bac53d45ee  vmovaps xmm5, [rsp+0x50]
000076bac53d45f4  vmovaps xmm6, [rsp+0x60]
000076bac53d45fa  vmovaps xmm7, [rsp+0x70]
000076bac53d4600  vmovaps xmm8, [rsp+0x80]
000076bac53d4609  vmovaps xmm9, [rsp+0x90]
000076bac53d4612  vmovaps xmm10, [rsp+0xA0]
000076bac53d461b  vmovaps xmm11, [rsp+0xB0]
000076bac53d4624  vmovaps xmm12, [rsp+0xC0]
000076bac53d462d  vmovaps xmm14, [rsp+0xD0]
000076bac53d4636  vmovaps xmm15, [rsp+0xE0]
000076bac53d463f  add rsp, 0xF0
000076bac53d4646  pop r11
000076bac53d4648  pop r10
000076bac53d464a  pop r9
000076bac53d464c  pop r8
000076bac53d464e  pop rsi
000076bac53d464f  pop rdi
000076bac53d4650  pop rdx
000076bac53d4651  pop rcx
000076bac53d4652  pop rax
000076bac53d4653  add rsp, 0x08
000076bac53d4657  jmp 0x000076BAC53D2AA8
000076bac53d465c  sub rsp, 0x08
000076bac53d4660  push rax
000076bac53d4661  push rcx
000076bac53d4662  push rdx
000076bac53d4663  push rdi
000076bac53d4664  push rsi
000076bac53d4665  push r8
000076bac53d4667  push r9
000076bac53d4669  push r10
000076bac53d466b  push r11
000076bac53d466d  sub rsp, 0xF0
000076bac53d4674  vmovaps [rsp], xmm0
000076bac53d4679  vmovaps [rsp+0x10], xmm2
000076bac53d467f  vmovaps [rsp+0x20], xmm3
000076bac53d4685  vmovaps [rsp+0x30], xmm4
000076bac53d468b  vmovaps [rsp+0x40], xmm5
000076bac53d4691  vmovaps [rsp+0x50], xmm6
000076bac53d4697  vmovaps [rsp+0x60], xmm7
000076bac53d469d  vmovaps [rsp+0x70], xmm8
000076bac53d46a3  vmovaps [rsp+0x80], xmm9
000076bac53d46ac  vmovaps [rsp+0x90], xmm10
000076bac53d46b5  vmovaps [rsp+0xA0], xmm11
000076bac53d46be  vmovaps [rsp+0xB0], xmm12
000076bac53d46c7  vmovaps [rsp+0xC0], xmm13
000076bac53d46d0  vmovaps [rsp+0xD0], xmm14
000076bac53d46d9  vmovaps [rsp+0xE0], xmm15
000076bac53d46e2  sub rsp, 0x30
000076bac53d46e6  movaps [rsp], xmm1
000076bac53d46ea  movaps [rsp+0x10], xmm14
000076bac53d46f0  movaps [rsp+0x20], xmm15
000076bac53d46f6  lea rdi, [rsp]
000076bac53d46fa  mov esi, 0x00
000076bac53d46ff  mov rax, 0x5641B0A3C530
000076bac53d4709  call rax
000076bac53d470b  movaps xmm1, [rsp]
000076bac53d470f  add rsp, 0x30
000076bac53d4713  vmovaps xmm0, [rsp]
000076bac53d4718  vmovaps xmm2, [rsp+0x10]
000076bac53d471e  vmovaps xmm3, [rsp+0x20]
000076bac53d4724  vmovaps xmm4, [rsp+0x30]
000076bac53d472a  vmovaps xmm5, [rsp+0x40]
000076bac53d4730  vmovaps xmm6, [rsp+0x50]
000076bac53d4736  vmovaps xmm7, [rsp+0x60]
000076bac53d473c  vmovaps xmm8, [rsp+0x70]
000076bac53d4742  vmovaps xmm9, [rsp+0x80]
000076bac53d474b  vmovaps xmm10, [rsp+0x90]
000076bac53d4754  vmovaps xmm11, [rsp+0xA0]
000076bac53d475d  vmovaps xmm12, [rsp+0xB0]
000076bac53d4766  vmovaps xmm13, [rsp+0xC0]
000076bac53d476f  vmovaps xmm14, [rsp+0xD0]
000076bac53d4778  vmovaps xmm15, [rsp+0xE0]
000076bac53d4781  add rsp, 0xF0
000076bac53d4788  pop r11
000076bac53d478a  pop r10
000076bac53d478c  pop r9
000076bac53d478e  pop r8
000076bac53d4790  pop rsi
000076bac53d4791  pop rdi
000076bac53d4792  pop rdx
000076bac53d4793  pop rcx
000076bac53d4794  pop rax
000076bac53d4795  add rsp, 0x08
000076bac53d4799  jmp 0x000076BAC53D2ACA
000076bac53d479e  sub rsp, 0x08
000076bac53d47a2  push rax
000076bac53d47a3  push rcx
000076bac53d47a4  push rdx
000076bac53d47a5  push rdi
000076bac53d47a6  push rsi
000076bac53d47a7  push r8
000076bac53d47a9  push r9
000076bac53d47ab  push r10
000076bac53d47ad  push r11
000076bac53d47af  sub rsp, 0xF0
000076bac53d47b6  vmovaps [rsp], xmm0
000076bac53d47bb  vmovaps [rsp+0x10], xmm1
000076bac53d47c1  vmovaps [rsp+0x20], xmm2
000076bac53d47c7  vmovaps [rsp+0x30], xmm3
000076bac53d47cd  vmovaps [rsp+0x40], xmm4
000076bac53d47d3  vmovaps [rsp+0x50], xmm5
000076bac53d47d9  vmovaps [rsp+0x60], xmm6
000076bac53d47df  vmovaps [rsp+0x70], xmm7
000076bac53d47e5  vmovaps [rsp+0x80], xmm8
000076bac53d47ee  vmovaps [rsp+0x90], xmm9
000076bac53d47f7  vmovaps [rsp+0xA0], xmm10
000076bac53d4800  vmovaps [rsp+0xB0], xmm11
000076bac53d4809  vmovaps [rsp+0xC0], xmm12
000076bac53d4812  vmovaps [rsp+0xD0], xmm13
000076bac53d481b  vmovaps [rsp+0xE0], xmm15
000076bac53d4824  sub rsp, 0x30
000076bac53d4828  movaps [rsp], xmm14
000076bac53d482d  movaps [rsp+0x10], xmm2
000076bac53d4832  movaps [rsp+0x20], xmm15
000076bac53d4838  lea rdi, [rsp]
000076bac53d483c  mov esi, 0x00
000076bac53d4841  mov rax, 0x5641B0A3C530
000076bac53d484b  call rax
000076bac53d484d  movaps xmm14, [rsp]
000076bac53d4852  add rsp, 0x30
000076bac53d4856  vmovaps xmm0, [rsp]
000076bac53d485b  vmovaps xmm1, [rsp+0x10]
000076bac53d4861  vmovaps xmm2, [rsp+0x20]
000076bac53d4867  vmovaps xmm3, [rsp+0x30]
000076bac53d486d  vmovaps xmm4, [rsp+0x40]
000076bac53d4873  vmovaps xmm5, [rsp+0x50]
000076bac53d4879  vmovaps xmm6, [rsp+0x60]
000076bac53d487f  vmovaps xmm7, [rsp+0x70]
000076bac53d4885  vmovaps xmm8, [rsp+0x80]
000076bac53d488e  vmovaps xmm9, [rsp+0x90]
000076bac53d4897  vmovaps xmm10, [rsp+0xA0]
000076bac53d48a0  vmovaps xmm11, [rsp+0xB0]
000076bac53d48a9  vmovaps xmm12, [rsp+0xC0]
000076bac53d48b2  vmovaps xmm13, [rsp+0xD0]
000076bac53d48bb  vmovaps xmm15, [rsp+0xE0]
000076bac53d48c4  add rsp, 0xF0
000076bac53d48cb  pop r11
000076bac53d48cd  pop r10
000076bac53d48cf  pop r9
000076bac53d48d1  pop r8
000076bac53d48d3  pop rsi
000076bac53d48d4  pop rdi
000076bac53d48d5  pop rdx
000076bac53d48d6  pop rcx
000076bac53d48d7  pop rax
000076bac53d48d8  add rsp, 0x08
000076bac53d48dc  jmp 0x000076BAC53D2B05
000076bac53d48e1  sub rsp, 0x08
000076bac53d48e5  push rax
000076bac53d48e6  push rcx
000076bac53d48e7  push rdx
000076bac53d48e8  push rdi
000076bac53d48e9  push rsi
000076bac53d48ea  push r8
000076bac53d48ec  push r9
000076bac53d48ee  push r10
000076bac53d48f0  push r11
000076bac53d48f2  sub rsp, 0xF0
000076bac53d48f9  vmovaps [rsp], xmm0
000076bac53d48fe  vmovaps [rsp+0x10], xmm1
000076bac53d4904  vmovaps [rsp+0x20], xmm2
000076bac53d490a  vmovaps [rsp+0x30], xmm3
000076bac53d4910  vmovaps [rsp+0x40], xmm4
000076bac53d4916  vmovaps [rsp+0x50], xmm5
000076bac53d491c  vmovaps [rsp+0x60], xmm6
000076bac53d4922  vmovaps [rsp+0x70], xmm7
000076bac53d4928  vmovaps [rsp+0x80], xmm8
000076bac53d4931  vmovaps [rsp+0x90], xmm9
000076bac53d493a  vmovaps [rsp+0xA0], xmm10
000076bac53d4943  vmovaps [rsp+0xB0], xmm11
000076bac53d494c  vmovaps [rsp+0xC0], xmm12
000076bac53d4955  vmovaps [rsp+0xD0], xmm13
000076bac53d495e  vmovaps [rsp+0xE0], xmm14
000076bac53d4967  sub rsp, 0x30
000076bac53d496b  movaps [rsp], xmm15
000076bac53d4970  movaps [rsp+0x10], xmm2
000076bac53d4975  movaps [rsp+0x20], xmm1
000076bac53d497a  lea rdi, [rsp]
000076bac53d497e  mov esi, 0x00
000076bac53d4983  mov rax, 0x5641B0A3C530
000076bac53d498d  call rax
000076bac53d498f  movaps xmm15, [rsp]
000076bac53d4994  add rsp, 0x30
000076bac53d4998  vmovaps xmm0, [rsp]
000076bac53d499d  vmovaps xmm1, [rsp+0x10]
000076bac53d49a3  vmovaps xmm2, [rsp+0x20]
000076bac53d49a9  vmovaps xmm3, [rsp+0x30]
000076bac53d49af  vmovaps xmm4, [rsp+0x40]
000076bac53d49b5  vmovaps xmm5, [rsp+0x50]
000076bac53d49bb  vmovaps xmm6, [rsp+0x60]
000076bac53d49c1  vmovaps xmm7, [rsp+0x70]
000076bac53d49c7  vmovaps xmm8, [rsp+0x80]
000076bac53d49d0  vmovaps xmm9, [rsp+0x90]
000076bac53d49d9  vmovaps xmm10, [rsp+0xA0]
000076bac53d49e2  vmovaps xmm11, [rsp+0xB0]
000076bac53d49eb  vmovaps xmm12, [rsp+0xC0]
000076bac53d49f4  vmovaps xmm13, [rsp+0xD0]
000076bac53d49fd  vmovaps xmm14, [rsp+0xE0]
000076bac53d4a06  add rsp, 0xF0
000076bac53d4a0d  pop r11
000076bac53d4a0f  pop r10
000076bac53d4a11  pop r9
000076bac53d4a13  pop r8
000076bac53d4a15  pop rsi
000076bac53d4a16  pop rdi
000076bac53d4a17  pop rdx
000076bac53d4a18  pop rcx
000076bac53d4a19  pop rax
000076bac53d4a1a  add rsp, 0x08
000076bac53d4a1e  jmp 0x000076BAC53D2B41
000076bac53d4a23  call 0x000076BAC51FF430
000076bac53d4a28  jmp 0x000076BAC53D2B4E
000076bac53d4a2d  sub rsp, 0x08
000076bac53d4a31  push rax
000076bac53d4a32  push rcx
000076bac53d4a33  push rdx
000076bac53d4a34  push rdi
000076bac53d4a35  push rsi
000076bac53d4a36  push r8
000076bac53d4a38  push r9
000076bac53d4a3a  push r10
000076bac53d4a3c  push r11
000076bac53d4a3e  sub rsp, 0xF0
000076bac53d4a45  vmovaps [rsp], xmm0
000076bac53d4a4a  vmovaps [rsp+0x10], xmm1
000076bac53d4a50  vmovaps [rsp+0x20], xmm3
000076bac53d4a56  vmovaps [rsp+0x30], xmm4
000076bac53d4a5c  vmovaps [rsp+0x40], xmm5
000076bac53d4a62  vmovaps [rsp+0x50], xmm6
000076bac53d4a68  vmovaps [rsp+0x60], xmm7
000076bac53d4a6e  vmovaps [rsp+0x70], xmm8
000076bac53d4a74  vmovaps [rsp+0x80], xmm9
000076bac53d4a7d  vmovaps [rsp+0x90], xmm10
000076bac53d4a86  vmovaps [rsp+0xA0], xmm11
000076bac53d4a8f  vmovaps [rsp+0xB0], xmm12
000076bac53d4a98  vmovaps [rsp+0xC0], xmm13
000076bac53d4aa1  vmovaps [rsp+0xD0], xmm14
000076bac53d4aaa  vmovaps [rsp+0xE0], xmm15
000076bac53d4ab3  sub rsp, 0x30
000076bac53d4ab7  movaps [rsp], xmm2
000076bac53d4abb  movaps [rsp+0x10], xmm1
000076bac53d4ac0  movaps [rsp+0x20], xmm14
000076bac53d4ac6  lea rdi, [rsp]
000076bac53d4aca  mov esi, 0x00
000076bac53d4acf  mov rax, 0x5641B0A3C530
000076bac53d4ad9  call rax
000076bac53d4adb  movaps xmm2, [rsp]
000076bac53d4adf  add rsp, 0x30
000076bac53d4ae3  vmovaps xmm0, [rsp]
000076bac53d4ae8  vmovaps xmm1, [rsp+0x10]
000076bac53d4aee  vmovaps xmm3, [rsp+0x20]
000076bac53d4af4  vmovaps xmm4, [rsp+0x30]
000076bac53d4afa  vmovaps xmm5, [rsp+0x40]
000076bac53d4b00  vmovaps xmm6, [rsp+0x50]
000076bac53d4b06  vmovaps xmm7, [rsp+0x60]
000076bac53d4b0c  vmovaps xmm8, [rsp+0x70]
000076bac53d4b12  vmovaps xmm9, [rsp+0x80]
000076bac53d4b1b  vmovaps xmm10, [rsp+0x90]
000076bac53d4b24  vmovaps xmm11, [rsp+0xA0]
000076bac53d4b2d  vmovaps xmm12, [rsp+0xB0]
000076bac53d4b36  vmovaps xmm13, [rsp+0xC0]
000076bac53d4b3f  vmovaps xmm14, [rsp+0xD0]
000076bac53d4b48  vmovaps xmm15, [rsp+0xE0]
000076bac53d4b51  add rsp, 0xF0
000076bac53d4b58  pop r11
000076bac53d4b5a  pop r10
000076bac53d4b5c  pop r9
000076bac53d4b5e  pop r8
000076bac53d4b60  pop rsi
000076bac53d4b61  pop rdi
000076bac53d4b62  pop rdx
000076bac53d4b63  pop rcx
000076bac53d4b64  pop rax
000076bac53d4b65  add rsp, 0x08
000076bac53d4b69  jmp 0x000076BAC53D2B8B
000076bac53d4b6e  sub rsp, 0x08
000076bac53d4b72  push rax
000076bac53d4b73  push rcx
000076bac53d4b74  push rdx
000076bac53d4b75  push rdi
000076bac53d4b76  push rsi
000076bac53d4b77  push r8
000076bac53d4b79  push r9
000076bac53d4b7b  push r10
000076bac53d4b7d  push r11
000076bac53d4b7f  sub rsp, 0xF0
000076bac53d4b86  vmovaps [rsp], xmm0
000076bac53d4b8b  vmovaps [rsp+0x10], xmm1
000076bac53d4b91  vmovaps [rsp+0x20], xmm2
000076bac53d4b97  vmovaps [rsp+0x30], xmm3
000076bac53d4b9d  vmovaps [rsp+0x40], xmm4
000076bac53d4ba3  vmovaps [rsp+0x50], xmm5
000076bac53d4ba9  vmovaps [rsp+0x60], xmm6
000076bac53d4baf  vmovaps [rsp+0x70], xmm7
000076bac53d4bb5  vmovaps [rsp+0x80], xmm8
000076bac53d4bbe  vmovaps [rsp+0x90], xmm9
000076bac53d4bc7  vmovaps [rsp+0xA0], xmm10
000076bac53d4bd0  vmovaps [rsp+0xB0], xmm11
000076bac53d4bd9  vmovaps [rsp+0xC0], xmm12
000076bac53d4be2  vmovaps [rsp+0xD0], xmm13
000076bac53d4beb  vmovaps [rsp+0xE0], xmm14
000076bac53d4bf4  sub rsp, 0x30
000076bac53d4bf8  movaps [rsp], xmm15
000076bac53d4bfd  movaps [rsp+0x10], xmm14
000076bac53d4c03  movaps [rsp+0x20], xmm1
000076bac53d4c08  lea rdi, [rsp]
000076bac53d4c0c  mov esi, 0x00
000076bac53d4c11  mov rax, 0x5641B0A3C530
000076bac53d4c1b  call rax
000076bac53d4c1d  movaps xmm15, [rsp]
000076bac53d4c22  add rsp, 0x30
000076bac53d4c26  vmovaps xmm0, [rsp]
000076bac53d4c2b  vmovaps xmm1, [rsp+0x10]
000076bac53d4c31  vmovaps xmm2, [rsp+0x20]
000076bac53d4c37  vmovaps xmm3, [rsp+0x30]
000076bac53d4c3d  vmovaps xmm4, [rsp+0x40]
000076bac53d4c43  vmovaps xmm5, [rsp+0x50]
000076bac53d4c49  vmovaps xmm6, [rsp+0x60]
000076bac53d4c4f  vmovaps xmm7, [rsp+0x70]
000076bac53d4c55  vmovaps xmm8, [rsp+0x80]
000076bac53d4c5e  vmovaps xmm9, [rsp+0x90]
000076bac53d4c67  vmovaps xmm10, [rsp+0xA0]
000076bac53d4c70  vmovaps xmm11, [rsp+0xB0]
000076bac53d4c79  vmovaps xmm12, [rsp+0xC0]
000076bac53d4c82  vmovaps xmm13, [rsp+0xD0]
000076bac53d4c8b  vmovaps xmm14, [rsp+0xE0]
000076bac53d4c94  add rsp, 0xF0
000076bac53d4c9b  pop r11
000076bac53d4c9d  pop r10
000076bac53d4c9f  pop r9
000076bac53d4ca1  pop r8
000076bac53d4ca3  pop rsi
000076bac53d4ca4  pop rdi
000076bac53d4ca5  pop rdx
000076bac53d4ca6  pop rcx
000076bac53d4ca7  pop rax
000076bac53d4ca8  add rsp, 0x08
000076bac53d4cac  jmp 0x000076BAC53D2C05
000076bac53d4cb1  call 0x000076BAC51FF430
000076bac53d4cb6  jmp 0x000076BAC53D2C12
000076bac53d4cbb  sub rsp, 0x08
000076bac53d4cbf  push rax
000076bac53d4cc0  push rcx
000076bac53d4cc1  push rdx
000076bac53d4cc2  push rdi
000076bac53d4cc3  push rsi
000076bac53d4cc4  push r8
000076bac53d4cc6  push r9
000076bac53d4cc8  push r10
000076bac53d4cca  push r11
000076bac53d4ccc  sub rsp, 0xF0
000076bac53d4cd3  vmovaps [rsp], xmm0
000076bac53d4cd8  vmovaps [rsp+0x10], xmm1
000076bac53d4cde  vmovaps [rsp+0x20], xmm2
000076bac53d4ce4  vmovaps [rsp+0x30], xmm3
000076bac53d4cea  vmovaps [rsp+0x40], xmm4
000076bac53d4cf0  vmovaps [rsp+0x50], xmm5
000076bac53d4cf6  vmovaps [rsp+0x60], xmm6
000076bac53d4cfc  vmovaps [rsp+0x70], xmm7
000076bac53d4d02  vmovaps [rsp+0x80], xmm8
000076bac53d4d0b  vmovaps [rsp+0x90], xmm9
000076bac53d4d14  vmovaps [rsp+0xA0], xmm10
000076bac53d4d1d  vmovaps [rsp+0xB0], xmm11
000076bac53d4d26  vmovaps [rsp+0xC0], xmm12
000076bac53d4d2f  vmovaps [rsp+0xD0], xmm14
000076bac53d4d38  vmovaps [rsp+0xE0], xmm15
000076bac53d4d41  sub rsp, 0x30
000076bac53d4d45  movaps [rsp], xmm13
000076bac53d4d4a  movaps [rsp+0x10], xmm1
000076bac53d4d4f  movaps [rsp+0x20], xmm15
000076bac53d4d55  lea rdi, [rsp]
000076bac53d4d59  mov esi, 0x00
000076bac53d4d5e  mov rax, 0x5641B0A3C530
000076bac53d4d68  call rax
000076bac53d4d6a  movaps xmm13, [rsp]
000076bac53d4d6f  add rsp, 0x30
000076bac53d4d73  vmovaps xmm0, [rsp]
000076bac53d4d78  vmovaps xmm1, [rsp+0x10]
000076bac53d4d7e  vmovaps xmm2, [rsp+0x20]
000076bac53d4d84  vmovaps xmm3, [rsp+0x30]
000076bac53d4d8a  vmovaps xmm4, [rsp+0x40]
000076bac53d4d90  vmovaps xmm5, [rsp+0x50]
000076bac53d4d96  vmovaps xmm6, [rsp+0x60]
000076bac53d4d9c  vmovaps xmm7, [rsp+0x70]
000076bac53d4da2  vmovaps xmm8, [rsp+0x80]
000076bac53d4dab  vmovaps xmm9, [rsp+0x90]
000076bac53d4db4  vmovaps xmm10, [rsp+0xA0]
000076bac53d4dbd  vmovaps xmm11, [rsp+0xB0]
000076bac53d4dc6  vmovaps xmm12, [rsp+0xC0]
000076bac53d4dcf  vmovaps xmm14, [rsp+0xD0]
000076bac53d4dd8  vmovaps xmm15, [rsp+0xE0]
000076bac53d4de1  add rsp, 0xF0
000076bac53d4de8  pop r11
000076bac53d4dea  pop r10
000076bac53d4dec  pop r9
000076bac53d4dee  pop r8
000076bac53d4df0  pop rsi
000076bac53d4df1  pop rdi
000076bac53d4df2  pop rdx
000076bac53d4df3  pop rcx
000076bac53d4df4  pop rax
000076bac53d4df5  add rsp, 0x08
000076bac53d4df9  jmp 0x000076BAC53D2CD6
000076bac53d4dfe  sub rsp, 0x08
000076bac53d4e02  push rax
000076bac53d4e03  push rcx
000076bac53d4e04  push rdx
000076bac53d4e05  push rdi
000076bac53d4e06  push rsi
000076bac53d4e07  push r8
000076bac53d4e09  push r9
000076bac53d4e0b  push r10
000076bac53d4e0d  push r11
000076bac53d4e0f  sub rsp, 0xF0
000076bac53d4e16  vmovaps [rsp], xmm0
000076bac53d4e1b  vmovaps [rsp+0x10], xmm1
000076bac53d4e21  vmovaps [rsp+0x20], xmm2
000076bac53d4e27  vmovaps [rsp+0x30], xmm3
000076bac53d4e2d  vmovaps [rsp+0x40], xmm4
000076bac53d4e33  vmovaps [rsp+0x50], xmm5
000076bac53d4e39  vmovaps [rsp+0x60], xmm6
000076bac53d4e3f  vmovaps [rsp+0x70], xmm7
000076bac53d4e45  vmovaps [rsp+0x80], xmm8
000076bac53d4e4e  vmovaps [rsp+0x90], xmm9
000076bac53d4e57  vmovaps [rsp+0xA0], xmm10
000076bac53d4e60  vmovaps [rsp+0xB0], xmm11
000076bac53d4e69  vmovaps [rsp+0xC0], xmm12
000076bac53d4e72  vmovaps [rsp+0xD0], xmm13
000076bac53d4e7b  vmovaps [rsp+0xE0], xmm14
000076bac53d4e84  sub rsp, 0x30
000076bac53d4e88  movaps [rsp], xmm15
000076bac53d4e8d  movaps [rsp+0x10], xmm14
000076bac53d4e93  movaps [rsp+0x20], xmm1
000076bac53d4e98  lea rdi, [rsp]
000076bac53d4e9c  mov esi, 0x00
000076bac53d4ea1  mov rax, 0x5641B0A3C530
000076bac53d4eab  call rax
000076bac53d4ead  movaps xmm15, [rsp]
000076bac53d4eb2  add rsp, 0x30
000076bac53d4eb6  vmovaps xmm0, [rsp]
000076bac53d4ebb  vmovaps xmm1, [rsp+0x10]
000076bac53d4ec1  vmovaps xmm2, [rsp+0x20]
000076bac53d4ec7  vmovaps xmm3, [rsp+0x30]
000076bac53d4ecd  vmovaps xmm4, [rsp+0x40]
000076bac53d4ed3  vmovaps xmm5, [rsp+0x50]
000076bac53d4ed9  vmovaps xmm6, [rsp+0x60]
000076bac53d4edf  vmovaps xmm7, [rsp+0x70]
000076bac53d4ee5  vmovaps xmm8, [rsp+0x80]
000076bac53d4eee  vmovaps xmm9, [rsp+0x90]
000076bac53d4ef7  vmovaps xmm10, [rsp+0xA0]
000076bac53d4f00  vmovaps xmm11, [rsp+0xB0]
000076bac53d4f09  vmovaps xmm12, [rsp+0xC0]
000076bac53d4f12  vmovaps xmm13, [rsp+0xD0]
000076bac53d4f1b  vmovaps xmm14, [rsp+0xE0]
000076bac53d4f24  add rsp, 0xF0
000076bac53d4f2b  pop r11
000076bac53d4f2d  pop r10
000076bac53d4f2f  pop r9
000076bac53d4f31  pop r8
000076bac53d4f33  pop rsi
000076bac53d4f34  pop rdi
000076bac53d4f35  pop rdx
000076bac53d4f36  pop rcx
000076bac53d4f37  pop rax
000076bac53d4f38  add rsp, 0x08
000076bac53d4f3c  jmp 0x000076BAC53D2D12
000076bac53d4f41  call 0x000076BAC51FF430
000076bac53d4f46  jmp 0x000076BAC53D2D1F
000076bac53d4f4b  sub rsp, 0x08
000076bac53d4f4f  push rax
000076bac53d4f50  push rcx
000076bac53d4f51  push rdx
000076bac53d4f52  push rdi
000076bac53d4f53  push rsi
000076bac53d4f54  push r8
000076bac53d4f56  push r9
000076bac53d4f58  push r10
000076bac53d4f5a  push r11
000076bac53d4f5c  sub rsp, 0xF0
000076bac53d4f63  vmovaps [rsp], xmm0
000076bac53d4f68  vmovaps [rsp+0x10], xmm1
000076bac53d4f6e  vmovaps [rsp+0x20], xmm2
000076bac53d4f74  vmovaps [rsp+0x30], xmm3
000076bac53d4f7a  vmovaps [rsp+0x40], xmm4
000076bac53d4f80  vmovaps [rsp+0x50], xmm5
000076bac53d4f86  vmovaps [rsp+0x60], xmm6
000076bac53d4f8c  vmovaps [rsp+0x70], xmm7
000076bac53d4f92  vmovaps [rsp+0x80], xmm8
000076bac53d4f9b  vmovaps [rsp+0x90], xmm9
000076bac53d4fa4  vmovaps [rsp+0xA0], xmm10
000076bac53d4fad  vmovaps [rsp+0xB0], xmm11
000076bac53d4fb6  vmovaps [rsp+0xC0], xmm12
000076bac53d4fbf  vmovaps [rsp+0xD0], xmm13
000076bac53d4fc8  vmovaps [rsp+0xE0], xmm15
000076bac53d4fd1  sub rsp, 0x30
000076bac53d4fd5  movaps [rsp], xmm14
000076bac53d4fda  movaps [rsp+0x10], xmm13
000076bac53d4fe0  movaps [rsp+0x20], xmm2
000076bac53d4fe5  lea rdi, [rsp]
000076bac53d4fe9  mov esi, 0x00
000076bac53d4fee  mov rax, 0x5641B0A3C530
000076bac53d4ff8  call rax
000076bac53d4ffa  movaps xmm14, [rsp]
000076bac53d4fff  add rsp, 0x30
000076bac53d5003  vmovaps xmm0, [rsp]
000076bac53d5008  vmovaps xmm1, [rsp+0x10]
000076bac53d500e  vmovaps xmm2, [rsp+0x20]
000076bac53d5014  vmovaps xmm3, [rsp+0x30]
000076bac53d501a  vmovaps xmm4, [rsp+0x40]
000076bac53d5020  vmovaps xmm5, [rsp+0x50]
000076bac53d5026  vmovaps xmm6, [rsp+0x60]
000076bac53d502c  vmovaps xmm7, [rsp+0x70]
000076bac53d5032  vmovaps xmm8, [rsp+0x80]
000076bac53d503b  vmovaps xmm9, [rsp+0x90]
000076bac53d5044  vmovaps xmm10, [rsp+0xA0]
000076bac53d504d  vmovaps xmm11, [rsp+0xB0]
000076bac53d5056  vmovaps xmm12, [rsp+0xC0]
000076bac53d505f  vmovaps xmm13, [rsp+0xD0]
000076bac53d5068  vmovaps xmm15, [rsp+0xE0]
000076bac53d5071  add rsp, 0xF0
000076bac53d5078  pop r11
000076bac53d507a  pop r10
000076bac53d507c  pop r9
000076bac53d507e  pop r8
000076bac53d5080  pop rsi
000076bac53d5081  pop rdi
000076bac53d5082  pop rdx
000076bac53d5083  pop rcx
000076bac53d5084  pop rax
000076bac53d5085  add rsp, 0x08
000076bac53d5089  jmp 0x000076BAC53D2D4B
000076bac53d508e  sub rsp, 0x08
000076bac53d5092  push rax
000076bac53d5093  push rcx
000076bac53d5094  push rdx
000076bac53d5095  push rdi
000076bac53d5096  push rsi
000076bac53d5097  push r8
000076bac53d5099  push r9
000076bac53d509b  push r10
000076bac53d509d  push r11
000076bac53d509f  sub rsp, 0xF0
000076bac53d50a6  vmovaps [rsp], xmm0
000076bac53d50ab  vmovaps [rsp+0x10], xmm2
000076bac53d50b1  vmovaps [rsp+0x20], xmm3
000076bac53d50b7  vmovaps [rsp+0x30], xmm4
000076bac53d50bd  vmovaps [rsp+0x40], xmm5
000076bac53d50c3  vmovaps [rsp+0x50], xmm6
000076bac53d50c9  vmovaps [rsp+0x60], xmm7
000076bac53d50cf  vmovaps [rsp+0x70], xmm8
000076bac53d50d5  vmovaps [rsp+0x80], xmm9
000076bac53d50de  vmovaps [rsp+0x90], xmm10
000076bac53d50e7  vmovaps [rsp+0xA0], xmm11
000076bac53d50f0  vmovaps [rsp+0xB0], xmm12
000076bac53d50f9  vmovaps [rsp+0xC0], xmm13
000076bac53d5102  vmovaps [rsp+0xD0], xmm14
000076bac53d510b  vmovaps [rsp+0xE0], xmm15
000076bac53d5114  sub rsp, 0x30
000076bac53d5118  movaps [rsp], xmm1
000076bac53d511c  movaps [rsp+0x10], xmm13
000076bac53d5122  movaps [rsp+0x20], xmm2
000076bac53d5127  lea rdi, [rsp]
000076bac53d512b  mov esi, 0x00
000076bac53d5130  mov rax, 0x5641B0A3C530
000076bac53d513a  call rax
000076bac53d513c  movaps xmm1, [rsp]
000076bac53d5140  add rsp, 0x30
000076bac53d5144  vmovaps xmm0, [rsp]
000076bac53d5149  vmovaps xmm2, [rsp+0x10]
000076bac53d514f  vmovaps xmm3, [rsp+0x20]
000076bac53d5155  vmovaps xmm4, [rsp+0x30]
000076bac53d515b  vmovaps xmm5, [rsp+0x40]
000076bac53d5161  vmovaps xmm6, [rsp+0x50]
000076bac53d5167  vmovaps xmm7, [rsp+0x60]
000076bac53d516d  vmovaps xmm8, [rsp+0x70]
000076bac53d5173  vmovaps xmm9, [rsp+0x80]
000076bac53d517c  vmovaps xmm10, [rsp+0x90]
000076bac53d5185  vmovaps xmm11, [rsp+0xA0]
000076bac53d518e  vmovaps xmm12, [rsp+0xB0]
000076bac53d5197  vmovaps xmm13, [rsp+0xC0]
000076bac53d51a0  vmovaps xmm14, [rsp+0xD0]
000076bac53d51a9  vmovaps xmm15, [rsp+0xE0]
000076bac53d51b2  add rsp, 0xF0
000076bac53d51b9  pop r11
000076bac53d51bb  pop r10
000076bac53d51bd  pop r9
000076bac53d51bf  pop r8
000076bac53d51c1  pop rsi
000076bac53d51c2  pop rdi
000076bac53d51c3  pop rdx
000076bac53d51c4  pop rcx
000076bac53d51c5  pop rax
000076bac53d51c6  add rsp, 0x08
000076bac53d51ca  jmp 0x000076BAC53D2D79
000076bac53d51cf  sub rsp, 0x08
000076bac53d51d3  push rax
000076bac53d51d4  push rcx
000076bac53d51d5  push rdx
000076bac53d51d6  push rdi
000076bac53d51d7  push rsi
000076bac53d51d8  push r8
000076bac53d51da  push r9
000076bac53d51dc  push r10
000076bac53d51de  push r11
000076bac53d51e0  sub rsp, 0xF0
000076bac53d51e7  vmovaps [rsp], xmm0
000076bac53d51ec  vmovaps [rsp+0x10], xmm1
000076bac53d51f2  vmovaps [rsp+0x20], xmm3
000076bac53d51f8  vmovaps [rsp+0x30], xmm4
000076bac53d51fe  vmovaps [rsp+0x40], xmm5
000076bac53d5204  vmovaps [rsp+0x50], xmm6
000076bac53d520a  vmovaps [rsp+0x60], xmm7
000076bac53d5210  vmovaps [rsp+0x70], xmm8
000076bac53d5216  vmovaps [rsp+0x80], xmm9
000076bac53d521f  vmovaps [rsp+0x90], xmm10
000076bac53d5228  vmovaps [rsp+0xA0], xmm11
000076bac53d5231  vmovaps [rsp+0xB0], xmm12
000076bac53d523a  vmovaps [rsp+0xC0], xmm13
000076bac53d5243  vmovaps [rsp+0xD0], xmm14
000076bac53d524c  vmovaps [rsp+0xE0], xmm15
000076bac53d5255  sub rsp, 0x30
000076bac53d5259  movaps [rsp], xmm2
000076bac53d525d  movaps [rsp+0x10], xmm1
000076bac53d5262  movaps [rsp+0x20], xmm13
000076bac53d5268  lea rdi, [rsp]
000076bac53d526c  mov esi, 0x00
000076bac53d5271  mov rax, 0x5641B0A3C530
000076bac53d527b  call rax
000076bac53d527d  movaps xmm2, [rsp]
000076bac53d5281  add rsp, 0x30
000076bac53d5285  vmovaps xmm0, [rsp]
000076bac53d528a  vmovaps xmm1, [rsp+0x10]
000076bac53d5290  vmovaps xmm3, [rsp+0x20]
000076bac53d5296  vmovaps xmm4, [rsp+0x30]
000076bac53d529c  vmovaps xmm5, [rsp+0x40]
000076bac53d52a2  vmovaps xmm6, [rsp+0x50]
000076bac53d52a8  vmovaps xmm7, [rsp+0x60]
000076bac53d52ae  vmovaps xmm8, [rsp+0x70]
000076bac53d52b4  vmovaps xmm9, [rsp+0x80]
000076bac53d52bd  vmovaps xmm10, [rsp+0x90]
000076bac53d52c6  vmovaps xmm11, [rsp+0xA0]
000076bac53d52cf  vmovaps xmm12, [rsp+0xB0]
000076bac53d52d8  vmovaps xmm13, [rsp+0xC0]
000076bac53d52e1  vmovaps xmm14, [rsp+0xD0]
000076bac53d52ea  vmovaps xmm15, [rsp+0xE0]
000076bac53d52f3  add rsp, 0xF0
000076bac53d52fa  pop r11
000076bac53d52fc  pop r10
000076bac53d52fe  pop r9
000076bac53d5300  pop r8
000076bac53d5302  pop rsi
000076bac53d5303  pop rdi
000076bac53d5304  pop rdx
000076bac53d5305  pop rcx
000076bac53d5306  pop rax
000076bac53d5307  add rsp, 0x08
000076bac53d530b  jmp 0x000076BAC53D2DD2
000076bac53d5310  call 0x000076BAC51FF430
000076bac53d5315  jmp 0x000076BAC53D2DDF
000076bac53d531a  sub rsp, 0x08
000076bac53d531e  push rax
000076bac53d531f  push rcx
000076bac53d5320  push rdx
000076bac53d5321  push rdi
000076bac53d5322  push rsi
000076bac53d5323  push r8
000076bac53d5325  push r9
000076bac53d5327  push r10
000076bac53d5329  push r11
000076bac53d532b  sub rsp, 0xF0
000076bac53d5332  vmovaps [rsp], xmm0
000076bac53d5337  vmovaps [rsp+0x10], xmm1
000076bac53d533d  vmovaps [rsp+0x20], xmm2
000076bac53d5343  vmovaps [rsp+0x30], xmm3
000076bac53d5349  vmovaps [rsp+0x40], xmm4
000076bac53d534f  vmovaps [rsp+0x50], xmm5
000076bac53d5355  vmovaps [rsp+0x60], xmm6
000076bac53d535b  vmovaps [rsp+0x70], xmm7
000076bac53d5361  vmovaps [rsp+0x80], xmm8
000076bac53d536a  vmovaps [rsp+0x90], xmm9
000076bac53d5373  vmovaps [rsp+0xA0], xmm10
000076bac53d537c  vmovaps [rsp+0xB0], xmm11
000076bac53d5385  vmovaps [rsp+0xC0], xmm12
000076bac53d538e  vmovaps [rsp+0xD0], xmm13
000076bac53d5397  vmovaps [rsp+0xE0], xmm14
000076bac53d53a0  sub rsp, 0x30
000076bac53d53a4  movaps [rsp], xmm15
000076bac53d53a9  movaps [rsp+0x10], xmm13
000076bac53d53af  movaps [rsp+0x20], xmm1
000076bac53d53b4  lea rdi, [rsp]
000076bac53d53b8  mov esi, 0x00
000076bac53d53bd  mov rax, 0x5641B0A3C530
000076bac53d53c7  call rax
000076bac53d53c9  movaps xmm15, [rsp]
000076bac53d53ce  add rsp, 0x30
000076bac53d53d2  vmovaps xmm0, [rsp]
000076bac53d53d7  vmovaps xmm1, [rsp+0x10]
000076bac53d53dd  vmovaps xmm2, [rsp+0x20]
000076bac53d53e3  vmovaps xmm3, [rsp+0x30]
000076bac53d53e9  vmovaps xmm4, [rsp+0x40]
000076bac53d53ef  vmovaps xmm5, [rsp+0x50]
000076bac53d53f5  vmovaps xmm6, [rsp+0x60]
000076bac53d53fb  vmovaps xmm7, [rsp+0x70]
000076bac53d5401  vmovaps xmm8, [rsp+0x80]
000076bac53d540a  vmovaps xmm9, [rsp+0x90]
000076bac53d5413  vmovaps xmm10, [rsp+0xA0]
000076bac53d541c  vmovaps xmm11, [rsp+0xB0]
000076bac53d5425  vmovaps xmm12, [rsp+0xC0]
000076bac53d542e  vmovaps xmm13, [rsp+0xD0]
000076bac53d5437  vmovaps xmm14, [rsp+0xE0]
000076bac53d5440  add rsp, 0xF0
000076bac53d5447  pop r11
000076bac53d5449  pop r10
000076bac53d544b  pop r9
000076bac53d544d  pop r8
000076bac53d544f  pop rsi
000076bac53d5450  pop rdi
000076bac53d5451  pop rdx
000076bac53d5452  pop rcx
000076bac53d5453  pop rax
000076bac53d5454  add rsp, 0x08
000076bac53d5458  jmp 0x000076BAC53D2E1E
000076bac53d545d  sub rsp, 0x08
000076bac53d5461  push rax
000076bac53d5462  push rcx
000076bac53d5463  push rdx
000076bac53d5464  push rdi
000076bac53d5465  push rsi
000076bac53d5466  push r8
000076bac53d5468  push r9
000076bac53d546a  push r10
000076bac53d546c  push r11
000076bac53d546e  sub rsp, 0xF0
000076bac53d5475  vmovaps [rsp], xmm0
000076bac53d547a  vmovaps [rsp+0x10], xmm1
000076bac53d5480  vmovaps [rsp+0x20], xmm2
000076bac53d5486  vmovaps [rsp+0x30], xmm3
000076bac53d548c  vmovaps [rsp+0x40], xmm4
000076bac53d5492  vmovaps [rsp+0x50], xmm5
000076bac53d5498  vmovaps [rsp+0x60], xmm6
000076bac53d549e  vmovaps [rsp+0x70], xmm7
000076bac53d54a4  vmovaps [rsp+0x80], xmm8
000076bac53d54ad  vmovaps [rsp+0x90], xmm9
000076bac53d54b6  vmovaps [rsp+0xA0], xmm10
000076bac53d54bf  vmovaps [rsp+0xB0], xmm11
000076bac53d54c8  vmovaps [rsp+0xC0], xmm12
000076bac53d54d1  vmovaps [rsp+0xD0], xmm13
000076bac53d54da  vmovaps [rsp+0xE0], xmm15
000076bac53d54e3  sub rsp, 0x30
000076bac53d54e7  movaps [rsp], xmm14
000076bac53d54ec  movaps [rsp+0x10], xmm11
000076bac53d54f2  movaps [rsp+0x20], xmm1
000076bac53d54f7  lea rdi, [rsp]
000076bac53d54fb  mov esi, 0x00
000076bac53d5500  mov rax, 0x5641B0A3C530
000076bac53d550a  call rax
000076bac53d550c  movaps xmm14, [rsp]
000076bac53d5511  add rsp, 0x30
000076bac53d5515  vmovaps xmm0, [rsp]
000076bac53d551a  vmovaps xmm1, [rsp+0x10]
000076bac53d5520  vmovaps xmm2, [rsp+0x20]
000076bac53d5526  vmovaps xmm3, [rsp+0x30]
000076bac53d552c  vmovaps xmm4, [rsp+0x40]
000076bac53d5532  vmovaps xmm5, [rsp+0x50]
000076bac53d5538  vmovaps xmm6, [rsp+0x60]
000076bac53d553e  vmovaps xmm7, [rsp+0x70]
000076bac53d5544  vmovaps xmm8, [rsp+0x80]
000076bac53d554d  vmovaps xmm9, [rsp+0x90]
000076bac53d5556  vmovaps xmm10, [rsp+0xA0]
000076bac53d555f  vmovaps xmm11, [rsp+0xB0]
000076bac53d5568  vmovaps xmm12, [rsp+0xC0]
000076bac53d5571  vmovaps xmm13, [rsp+0xD0]
000076bac53d557a  vmovaps xmm15, [rsp+0xE0]
000076bac53d5583  add rsp, 0xF0
000076bac53d558a  pop r11
000076bac53d558c  pop r10
000076bac53d558e  pop r9
000076bac53d5590  pop r8
000076bac53d5592  pop rsi
000076bac53d5593  pop rdi
000076bac53d5594  pop rdx
000076bac53d5595  pop rcx
000076bac53d5596  pop rax
000076bac53d5597  add rsp, 0x08
000076bac53d559b  jmp 0x000076BAC53D2E48
000076bac53d55a0  sub rsp, 0x08
000076bac53d55a4  push rax
000076bac53d55a5  push rcx
000076bac53d55a6  push rdx
000076bac53d55a7  push rdi
000076bac53d55a8  push rsi
000076bac53d55a9  push r8
000076bac53d55ab  push r9
000076bac53d55ad  push r10
000076bac53d55af  push r11
000076bac53d55b1  sub rsp, 0xF0
000076bac53d55b8  vmovaps [rsp], xmm0
000076bac53d55bd  vmovaps [rsp+0x10], xmm1
000076bac53d55c3  vmovaps [rsp+0x20], xmm2
000076bac53d55c9  vmovaps [rsp+0x30], xmm3
000076bac53d55cf  vmovaps [rsp+0x40], xmm4
000076bac53d55d5  vmovaps [rsp+0x50], xmm5
000076bac53d55db  vmovaps [rsp+0x60], xmm6
000076bac53d55e1  vmovaps [rsp+0x70], xmm7
000076bac53d55e7  vmovaps [rsp+0x80], xmm8
000076bac53d55f0  vmovaps [rsp+0x90], xmm9
000076bac53d55f9  vmovaps [rsp+0xA0], xmm10
000076bac53d5602  vmovaps [rsp+0xB0], xmm11
000076bac53d560b  vmovaps [rsp+0xC0], xmm12
000076bac53d5614  vmovaps [rsp+0xD0], xmm14
000076bac53d561d  vmovaps [rsp+0xE0], xmm15
000076bac53d5626  sub rsp, 0x30
000076bac53d562a  movaps [rsp], xmm13
000076bac53d562f  movaps [rsp+0x10], xmm11
000076bac53d5635  movaps [rsp+0x20], xmm1
000076bac53d563a  lea rdi, [rsp]
000076bac53d563e  mov esi, 0x00
000076bac53d5643  mov rax, 0x5641B0A3C530
000076bac53d564d  call rax
000076bac53d564f  movaps xmm13, [rsp]
000076bac53d5654  add rsp, 0x30
000076bac53d5658  vmovaps xmm0, [rsp]
000076bac53d565d  vmovaps xmm1, [rsp+0x10]
000076bac53d5663  vmovaps xmm2, [rsp+0x20]
000076bac53d5669  vmovaps xmm3, [rsp+0x30]
000076bac53d566f  vmovaps xmm4, [rsp+0x40]
000076bac53d5675  vmovaps xmm5, [rsp+0x50]
000076bac53d567b  vmovaps xmm6, [rsp+0x60]
000076bac53d5681  vmovaps xmm7, [rsp+0x70]
000076bac53d5687  vmovaps xmm8, [rsp+0x80]
000076bac53d5690  vmovaps xmm9, [rsp+0x90]
000076bac53d5699  vmovaps xmm10, [rsp+0xA0]
000076bac53d56a2  vmovaps xmm11, [rsp+0xB0]
000076bac53d56ab  vmovaps xmm12, [rsp+0xC0]
000076bac53d56b4  vmovaps xmm14, [rsp+0xD0]
000076bac53d56bd  vmovaps xmm15, [rsp+0xE0]
000076bac53d56c6  add rsp, 0xF0
000076bac53d56cd  pop r11
000076bac53d56cf  pop r10
000076bac53d56d1  pop r9
000076bac53d56d3  pop r8
000076bac53d56d5  pop rsi
000076bac53d56d6  pop rdi
000076bac53d56d7  pop rdx
000076bac53d56d8  pop rcx
000076bac53d56d9  pop rax
000076bac53d56da  add rsp, 0x08
000076bac53d56de  jmp 0x000076BAC53D2E9D
000076bac53d56e3  call 0x000076BAC51FF430
000076bac53d56e8  jmp 0x000076BAC53D2EAA
000076bac53d56ed  sub rsp, 0x08
000076bac53d56f1  push rax
000076bac53d56f2  push rcx
000076bac53d56f3  push rdx
000076bac53d56f4  push rdi
000076bac53d56f5  push rsi
000076bac53d56f6  push r8
000076bac53d56f8  push r9
000076bac53d56fa  push r10
000076bac53d56fc  push r11
000076bac53d56fe  sub rsp, 0xF0
000076bac53d5705  vmovaps [rsp], xmm0
000076bac53d570a  vmovaps [rsp+0x10], xmm1
000076bac53d5710  vmovaps [rsp+0x20], xmm2
000076bac53d5716  vmovaps [rsp+0x30], xmm3
000076bac53d571c  vmovaps [rsp+0x40], xmm4
000076bac53d5722  vmovaps [rsp+0x50], xmm5
000076bac53d5728  vmovaps [rsp+0x60], xmm6
000076bac53d572e  vmovaps [rsp+0x70], xmm7
000076bac53d5734  vmovaps [rsp+0x80], xmm8
000076bac53d573d  vmovaps [rsp+0x90], xmm9
000076bac53d5746  vmovaps [rsp+0xA0], xmm10
000076bac53d574f  vmovaps [rsp+0xB0], xmm11
000076bac53d5758  vmovaps [rsp+0xC0], xmm12
000076bac53d5761  vmovaps [rsp+0xD0], xmm13
000076bac53d576a  vmovaps [rsp+0xE0], xmm14
000076bac53d5773  sub rsp, 0x30
000076bac53d5777  movaps [rsp], xmm15
000076bac53d577c  movaps [rsp+0x10], xmm11
000076bac53d5782  movaps [rsp+0x20], xmm1
000076bac53d5787  lea rdi, [rsp]
000076bac53d578b  mov esi, 0x00
000076bac53d5790  mov rax, 0x5641B0A3C530
000076bac53d579a  call rax
000076bac53d579c  movaps xmm15, [rsp]
000076bac53d57a1  add rsp, 0x30
000076bac53d57a5  vmovaps xmm0, [rsp]
000076bac53d57aa  vmovaps xmm1, [rsp+0x10]
000076bac53d57b0  vmovaps xmm2, [rsp+0x20]
000076bac53d57b6  vmovaps xmm3, [rsp+0x30]
000076bac53d57bc  vmovaps xmm4, [rsp+0x40]
000076bac53d57c2  vmovaps xmm5, [rsp+0x50]
000076bac53d57c8  vmovaps xmm6, [rsp+0x60]
000076bac53d57ce  vmovaps xmm7, [rsp+0x70]
000076bac53d57d4  vmovaps xmm8, [rsp+0x80]
000076bac53d57dd  vmovaps xmm9, [rsp+0x90]
000076bac53d57e6  vmovaps xmm10, [rsp+0xA0]
000076bac53d57ef  vmovaps xmm11, [rsp+0xB0]
000076bac53d57f8  vmovaps xmm12, [rsp+0xC0]
000076bac53d5801  vmovaps xmm13, [rsp+0xD0]
000076bac53d580a  vmovaps xmm14, [rsp+0xE0]
000076bac53d5813  add rsp, 0xF0
000076bac53d581a  pop r11
000076bac53d581c  pop r10
000076bac53d581e  pop r9
000076bac53d5820  pop r8
000076bac53d5822  pop rsi
000076bac53d5823  pop rdi
000076bac53d5824  pop rdx
000076bac53d5825  pop rcx
000076bac53d5826  pop rax
000076bac53d5827  add rsp, 0x08
000076bac53d582b  jmp 0x000076BAC53D2EE3
000076bac53d5830  sub rsp, 0x08
000076bac53d5834  push rax
000076bac53d5835  push rcx
000076bac53d5836  push rdx
000076bac53d5837  push rdi
000076bac53d5838  push rsi
000076bac53d5839  push r8
000076bac53d583b  push r9
000076bac53d583d  push r10
000076bac53d583f  push r11
000076bac53d5841  sub rsp, 0xF0
000076bac53d5848  vmovaps [rsp], xmm0
000076bac53d584d  vmovaps [rsp+0x10], xmm1
000076bac53d5853  vmovaps [rsp+0x20], xmm2
000076bac53d5859  vmovaps [rsp+0x30], xmm3
000076bac53d585f  vmovaps [rsp+0x40], xmm4
000076bac53d5865  vmovaps [rsp+0x50], xmm5
000076bac53d586b  vmovaps [rsp+0x60], xmm6
000076bac53d5871  vmovaps [rsp+0x70], xmm7
000076bac53d5877  vmovaps [rsp+0x80], xmm8
000076bac53d5880  vmovaps [rsp+0x90], xmm9
000076bac53d5889  vmovaps [rsp+0xA0], xmm10
000076bac53d5892  vmovaps [rsp+0xB0], xmm12
000076bac53d589b  vmovaps [rsp+0xC0], xmm13
000076bac53d58a4  vmovaps [rsp+0xD0], xmm14
000076bac53d58ad  vmovaps [rsp+0xE0], xmm15
000076bac53d58b6  sub rsp, 0x30
000076bac53d58ba  movaps [rsp], xmm11
000076bac53d58bf  movaps [rsp+0x10], xmm6
000076bac53d58c4  movaps [rsp+0x20], xmm14
000076bac53d58ca  lea rdi, [rsp]
000076bac53d58ce  mov esi, 0x00
000076bac53d58d3  mov rax, 0x5641B0A3C530
000076bac53d58dd  call rax
000076bac53d58df  movaps xmm11, [rsp]
000076bac53d58e4  add rsp, 0x30
000076bac53d58e8  vmovaps xmm0, [rsp]
000076bac53d58ed  vmovaps xmm1, [rsp+0x10]
000076bac53d58f3  vmovaps xmm2, [rsp+0x20]
000076bac53d58f9  vmovaps xmm3, [rsp+0x30]
000076bac53d58ff  vmovaps xmm4, [rsp+0x40]
000076bac53d5905  vmovaps xmm5, [rsp+0x50]
000076bac53d590b  vmovaps xmm6, [rsp+0x60]
000076bac53d5911  vmovaps xmm7, [rsp+0x70]
000076bac53d5917  vmovaps xmm8, [rsp+0x80]
000076bac53d5920  vmovaps xmm9, [rsp+0x90]
000076bac53d5929  vmovaps xmm10, [rsp+0xA0]
000076bac53d5932  vmovaps xmm12, [rsp+0xB0]
000076bac53d593b  vmovaps xmm13, [rsp+0xC0]
000076bac53d5944  vmovaps xmm14, [rsp+0xD0]
000076bac53d594d  vmovaps xmm15, [rsp+0xE0]
000076bac53d5956  add rsp, 0xF0
000076bac53d595d  pop r11
000076bac53d595f  pop r10
000076bac53d5961  pop r9
000076bac53d5963  pop r8
000076bac53d5965  pop rsi
000076bac53d5966  pop rdi
000076bac53d5967  pop rdx
000076bac53d5968  pop rcx
000076bac53d5969  pop rax
000076bac53d596a  add rsp, 0x08
000076bac53d596e  jmp 0x000076BAC53D2F5B
000076bac53d5973  call 0x000076BAC51FF430
000076bac53d5978  jmp 0x000076BAC53D2F65
000076bac53d597d  sub rsp, 0x08
000076bac53d5981  push rax
000076bac53d5982  push rcx
000076bac53d5983  push rdx
000076bac53d5984  push rdi
000076bac53d5985  push rsi
000076bac53d5986  push r8
000076bac53d5988  push r9
000076bac53d598a  push r10
000076bac53d598c  push r11
000076bac53d598e  sub rsp, 0xF0
000076bac53d5995  vmovaps [rsp], xmm0
000076bac53d599a  vmovaps [rsp+0x10], xmm1
000076bac53d59a0  vmovaps [rsp+0x20], xmm2
000076bac53d59a6  vmovaps [rsp+0x30], xmm3
000076bac53d59ac  vmovaps [rsp+0x40], xmm4
000076bac53d59b2  vmovaps [rsp+0x50], xmm5
000076bac53d59b8  vmovaps [rsp+0x60], xmm6
000076bac53d59be  vmovaps [rsp+0x70], xmm7
000076bac53d59c4  vmovaps [rsp+0x80], xmm8
000076bac53d59cd  vmovaps [rsp+0x90], xmm9
000076bac53d59d6  vmovaps [rsp+0xA0], xmm10
000076bac53d59df  vmovaps [rsp+0xB0], xmm11
000076bac53d59e8  vmovaps [rsp+0xC0], xmm12
000076bac53d59f1  vmovaps [rsp+0xD0], xmm13
000076bac53d59fa  vmovaps [rsp+0xE0], xmm15
000076bac53d5a03  sub rsp, 0x30
000076bac53d5a07  movaps [rsp], xmm14
000076bac53d5a0c  movaps [rsp+0x10], xmm6
000076bac53d5a11  movaps [rsp+0x20], xmm2
000076bac53d5a16  lea rdi, [rsp]
000076bac53d5a1a  mov esi, 0x00
000076bac53d5a1f  mov rax, 0x5641B0A3C530
000076bac53d5a29  call rax
000076bac53d5a2b  movaps xmm14, [rsp]
000076bac53d5a30  add rsp, 0x30
000076bac53d5a34  vmovaps xmm0, [rsp]
000076bac53d5a39  vmovaps xmm1, [rsp+0x10]
000076bac53d5a3f  vmovaps xmm2, [rsp+0x20]
000076bac53d5a45  vmovaps xmm3, [rsp+0x30]
000076bac53d5a4b  vmovaps xmm4, [rsp+0x40]
000076bac53d5a51  vmovaps xmm5, [rsp+0x50]
000076bac53d5a57  vmovaps xmm6, [rsp+0x60]
000076bac53d5a5d  vmovaps xmm7, [rsp+0x70]
000076bac53d5a63  vmovaps xmm8, [rsp+0x80]
000076bac53d5a6c  vmovaps xmm9, [rsp+0x90]
000076bac53d5a75  vmovaps xmm10, [rsp+0xA0]
000076bac53d5a7e  vmovaps xmm11, [rsp+0xB0]
000076bac53d5a87  vmovaps xmm12, [rsp+0xC0]
000076bac53d5a90  vmovaps xmm13, [rsp+0xD0]
000076bac53d5a99  vmovaps xmm15, [rsp+0xE0]
000076bac53d5aa2  add rsp, 0xF0
000076bac53d5aa9  pop r11
000076bac53d5aab  pop r10
000076bac53d5aad  pop r9
000076bac53d5aaf  pop r8
000076bac53d5ab1  pop rsi
000076bac53d5ab2  pop rdi
000076bac53d5ab3  pop rdx
000076bac53d5ab4  pop rcx
000076bac53d5ab5  pop rax
000076bac53d5ab6  add rsp, 0x08
000076bac53d5aba  jmp 0x000076BAC53D2F99
000076bac53d5abf  sub rsp, 0x08
000076bac53d5ac3  push rax
000076bac53d5ac4  push rcx
000076bac53d5ac5  push rdx
000076bac53d5ac6  push rdi
000076bac53d5ac7  push rsi
000076bac53d5ac8  push r8
000076bac53d5aca  push r9
000076bac53d5acc  push r10
000076bac53d5ace  push r11
000076bac53d5ad0  sub rsp, 0xF0
000076bac53d5ad7  vmovaps [rsp], xmm0
000076bac53d5adc  vmovaps [rsp+0x10], xmm1
000076bac53d5ae2  vmovaps [rsp+0x20], xmm2
000076bac53d5ae8  vmovaps [rsp+0x30], xmm3
000076bac53d5aee  vmovaps [rsp+0x40], xmm4
000076bac53d5af4  vmovaps [rsp+0x50], xmm5
000076bac53d5afa  vmovaps [rsp+0x60], xmm7
000076bac53d5b00  vmovaps [rsp+0x70], xmm8
000076bac53d5b06  vmovaps [rsp+0x80], xmm9
000076bac53d5b0f  vmovaps [rsp+0x90], xmm10
000076bac53d5b18  vmovaps [rsp+0xA0], xmm11
000076bac53d5b21  vmovaps [rsp+0xB0], xmm12
000076bac53d5b2a  vmovaps [rsp+0xC0], xmm13
000076bac53d5b33  vmovaps [rsp+0xD0], xmm14
000076bac53d5b3c  vmovaps [rsp+0xE0], xmm15
000076bac53d5b45  sub rsp, 0x30
000076bac53d5b49  movaps [rsp], xmm6
000076bac53d5b4d  movaps [rsp+0x10], xmm5
000076bac53d5b52  movaps [rsp+0x20], xmm1
000076bac53d5b57  lea rdi, [rsp]
000076bac53d5b5b  mov esi, 0x00
000076bac53d5b60  mov rax, 0x5641B0A3C530
000076bac53d5b6a  call rax
000076bac53d5b6c  movaps xmm6, [rsp]
000076bac53d5b70  add rsp, 0x30
000076bac53d5b74  vmovaps xmm0, [rsp]
000076bac53d5b79  vmovaps xmm1, [rsp+0x10]
000076bac53d5b7f  vmovaps xmm2, [rsp+0x20]
000076bac53d5b85  vmovaps xmm3, [rsp+0x30]
000076bac53d5b8b  vmovaps xmm4, [rsp+0x40]
000076bac53d5b91  vmovaps xmm5, [rsp+0x50]
000076bac53d5b97  vmovaps xmm7, [rsp+0x60]
000076bac53d5b9d  vmovaps xmm8, [rsp+0x70]
000076bac53d5ba3  vmovaps xmm9, [rsp+0x80]
000076bac53d5bac  vmovaps xmm10, [rsp+0x90]
000076bac53d5bb5  vmovaps xmm11, [rsp+0xA0]
000076bac53d5bbe  vmovaps xmm12, [rsp+0xB0]
000076bac53d5bc7  vmovaps xmm13, [rsp+0xC0]
000076bac53d5bd0  vmovaps xmm14, [rsp+0xD0]
000076bac53d5bd9  vmovaps xmm15, [rsp+0xE0]
000076bac53d5be2  add rsp, 0xF0
000076bac53d5be9  pop r11
000076bac53d5beb  pop r10
000076bac53d5bed  pop r9
000076bac53d5bef  pop r8
000076bac53d5bf1  pop rsi
000076bac53d5bf2  pop rdi
000076bac53d5bf3  pop rdx
000076bac53d5bf4  pop rcx
000076bac53d5bf5  pop rax
000076bac53d5bf6  add rsp, 0x08
000076bac53d5bfa  jmp 0x000076BAC53D2FBF
000076bac53d5bff  sub rsp, 0x08
000076bac53d5c03  push rax
000076bac53d5c04  push rcx
000076bac53d5c05  push rdx
000076bac53d5c06  push rdi
000076bac53d5c07  push rsi
000076bac53d5c08  push r8
000076bac53d5c0a  push r9
000076bac53d5c0c  push r10
000076bac53d5c0e  push r11
000076bac53d5c10  sub rsp, 0xF0
000076bac53d5c17  vmovaps [rsp], xmm0
000076bac53d5c1c  vmovaps [rsp+0x10], xmm2
000076bac53d5c22  vmovaps [rsp+0x20], xmm3
000076bac53d5c28  vmovaps [rsp+0x30], xmm4
000076bac53d5c2e  vmovaps [rsp+0x40], xmm5
000076bac53d5c34  vmovaps [rsp+0x50], xmm6
000076bac53d5c3a  vmovaps [rsp+0x60], xmm7
000076bac53d5c40  vmovaps [rsp+0x70], xmm8
000076bac53d5c46  vmovaps [rsp+0x80], xmm9
000076bac53d5c4f  vmovaps [rsp+0x90], xmm10
000076bac53d5c58  vmovaps [rsp+0xA0], xmm11
000076bac53d5c61  vmovaps [rsp+0xB0], xmm12
000076bac53d5c6a  vmovaps [rsp+0xC0], xmm13
000076bac53d5c73  vmovaps [rsp+0xD0], xmm14
000076bac53d5c7c  vmovaps [rsp+0xE0], xmm15
000076bac53d5c85  sub rsp, 0x30
000076bac53d5c89  movaps [rsp], xmm1
000076bac53d5c8d  movaps [rsp+0x10], xmm5
000076bac53d5c92  movaps [rsp+0x20], xmm13
000076bac53d5c98  lea rdi, [rsp]
000076bac53d5c9c  mov esi, 0x00
000076bac53d5ca1  mov rax, 0x5641B0A3C530
000076bac53d5cab  call rax
000076bac53d5cad  movaps xmm1, [rsp]
000076bac53d5cb1  add rsp, 0x30
000076bac53d5cb5  vmovaps xmm0, [rsp]
000076bac53d5cba  vmovaps xmm2, [rsp+0x10]
000076bac53d5cc0  vmovaps xmm3, [rsp+0x20]
000076bac53d5cc6  vmovaps xmm4, [rsp+0x30]
000076bac53d5ccc  vmovaps xmm5, [rsp+0x40]
000076bac53d5cd2  vmovaps xmm6, [rsp+0x50]
000076bac53d5cd8  vmovaps xmm7, [rsp+0x60]
000076bac53d5cde  vmovaps xmm8, [rsp+0x70]
000076bac53d5ce4  vmovaps xmm9, [rsp+0x80]
000076bac53d5ced  vmovaps xmm10, [rsp+0x90]
000076bac53d5cf6  vmovaps xmm11, [rsp+0xA0]
000076bac53d5cff  vmovaps xmm12, [rsp+0xB0]
000076bac53d5d08  vmovaps xmm13, [rsp+0xC0]
000076bac53d5d11  vmovaps xmm14, [rsp+0xD0]
000076bac53d5d1a  vmovaps xmm15, [rsp+0xE0]
000076bac53d5d23  add rsp, 0xF0
000076bac53d5d2a  pop r11
000076bac53d5d2c  pop r10
000076bac53d5d2e  pop r9
000076bac53d5d30  pop r8
000076bac53d5d32  pop rsi
000076bac53d5d33  pop rdi
000076bac53d5d34  pop rdx
000076bac53d5d35  pop rcx
000076bac53d5d36  pop rax
000076bac53d5d37  add rsp, 0x08
000076bac53d5d3b  jmp 0x000076BAC53D2FDD
000076bac53d5d40  sub rsp, 0x08
000076bac53d5d44  push rax
000076bac53d5d45  push rcx
000076bac53d5d46  push rdx
000076bac53d5d47  push rdi
000076bac53d5d48  push rsi
000076bac53d5d49  push r8
000076bac53d5d4b  push r9
000076bac53d5d4d  push r10
000076bac53d5d4f  push r11
000076bac53d5d51  sub rsp, 0xF0
000076bac53d5d58  vmovaps [rsp], xmm0
000076bac53d5d5d  vmovaps [rsp+0x10], xmm1
000076bac53d5d63  vmovaps [rsp+0x20], xmm2
000076bac53d5d69  vmovaps [rsp+0x30], xmm3
000076bac53d5d6f  vmovaps [rsp+0x40], xmm4
000076bac53d5d75  vmovaps [rsp+0x50], xmm6
000076bac53d5d7b  vmovaps [rsp+0x60], xmm7
000076bac53d5d81  vmovaps [rsp+0x70], xmm8
000076bac53d5d87  vmovaps [rsp+0x80], xmm9
000076bac53d5d90  vmovaps [rsp+0x90], xmm10
000076bac53d5d99  vmovaps [rsp+0xA0], xmm11
000076bac53d5da2  vmovaps [rsp+0xB0], xmm12
000076bac53d5dab  vmovaps [rsp+0xC0], xmm13
000076bac53d5db4  vmovaps [rsp+0xD0], xmm14
000076bac53d5dbd  vmovaps [rsp+0xE0], xmm15
000076bac53d5dc6  sub rsp, 0x30
000076bac53d5dca  movaps [rsp], xmm5
000076bac53d5dce  movaps [rsp+0x10], xmm2
000076bac53d5dd3  movaps [rsp+0x20], xmm13
000076bac53d5dd9  lea rdi, [rsp]
000076bac53d5ddd  mov esi, 0x00
000076bac53d5de2  mov rax, 0x5641B0A3C530
000076bac53d5dec  call rax
000076bac53d5dee  movaps xmm5, [rsp]
000076bac53d5df2  add rsp, 0x30
000076bac53d5df6  vmovaps xmm0, [rsp]
000076bac53d5dfb  vmovaps xmm1, [rsp+0x10]
000076bac53d5e01  vmovaps xmm2, [rsp+0x20]
000076bac53d5e07  vmovaps xmm3, [rsp+0x30]
000076bac53d5e0d  vmovaps xmm4, [rsp+0x40]
000076bac53d5e13  vmovaps xmm6, [rsp+0x50]
000076bac53d5e19  vmovaps xmm7, [rsp+0x60]
000076bac53d5e1f  vmovaps xmm8, [rsp+0x70]
000076bac53d5e25  vmovaps xmm9, [rsp+0x80]
000076bac53d5e2e  vmovaps xmm10, [rsp+0x90]
000076bac53d5e37  vmovaps xmm11, [rsp+0xA0]
000076bac53d5e40  vmovaps xmm12, [rsp+0xB0]
000076bac53d5e49  vmovaps xmm13, [rsp+0xC0]
000076bac53d5e52  vmovaps xmm14, [rsp+0xD0]
000076bac53d5e5b  vmovaps xmm15, [rsp+0xE0]
000076bac53d5e64  add rsp, 0xF0
000076bac53d5e6b  pop r11
000076bac53d5e6d  pop r10
000076bac53d5e6f  pop r9
000076bac53d5e71  pop r8
000076bac53d5e73  pop rsi
000076bac53d5e74  pop rdi
000076bac53d5e75  pop rdx
000076bac53d5e76  pop rcx
000076bac53d5e77  pop rax
000076bac53d5e78  add rsp, 0x08
000076bac53d5e7c  jmp 0x000076BAC53D3013
000076bac53d5e81  sub rsp, 0x08
000076bac53d5e85  push rax
000076bac53d5e86  push rcx
000076bac53d5e87  push rdx
000076bac53d5e88  push rdi
000076bac53d5e89  push rsi
000076bac53d5e8a  push r8
000076bac53d5e8c  push r9
000076bac53d5e8e  push r10
000076bac53d5e90  push r11
000076bac53d5e92  sub rsp, 0xF0
000076bac53d5e99  vmovaps [rsp], xmm0
000076bac53d5e9e  vmovaps [rsp+0x10], xmm1
000076bac53d5ea4  vmovaps [rsp+0x20], xmm2
000076bac53d5eaa  vmovaps [rsp+0x30], xmm3
000076bac53d5eb0  vmovaps [rsp+0x40], xmm4
000076bac53d5eb6  vmovaps [rsp+0x50], xmm5
000076bac53d5ebc  vmovaps [rsp+0x60], xmm6
000076bac53d5ec2  vmovaps [rsp+0x70], xmm7
000076bac53d5ec8  vmovaps [rsp+0x80], xmm8
000076bac53d5ed1  vmovaps [rsp+0x90], xmm9
000076bac53d5eda  vmovaps [rsp+0xA0], xmm10
000076bac53d5ee3  vmovaps [rsp+0xB0], xmm11
000076bac53d5eec  vmovaps [rsp+0xC0], xmm12
000076bac53d5ef5  vmovaps [rsp+0xD0], xmm14
000076bac53d5efe  vmovaps [rsp+0xE0], xmm15
000076bac53d5f07  sub rsp, 0x30
000076bac53d5f0b  movaps [rsp], xmm13
000076bac53d5f10  movaps [rsp+0x10], xmm10
000076bac53d5f16  movaps [rsp+0x20], xmm1
000076bac53d5f1b  lea rdi, [rsp]
000076bac53d5f1f  mov esi, 0x00
000076bac53d5f24  mov rax, 0x5641B0A3C530
000076bac53d5f2e  call rax
000076bac53d5f30  movaps xmm13, [rsp]
000076bac53d5f35  add rsp, 0x30
000076bac53d5f39  vmovaps xmm0, [rsp]
000076bac53d5f3e  vmovaps xmm1, [rsp+0x10]
000076bac53d5f44  vmovaps xmm2, [rsp+0x20]
000076bac53d5f4a  vmovaps xmm3, [rsp+0x30]
000076bac53d5f50  vmovaps xmm4, [rsp+0x40]
000076bac53d5f56  vmovaps xmm5, [rsp+0x50]
000076bac53d5f5c  vmovaps xmm6, [rsp+0x60]
000076bac53d5f62  vmovaps xmm7, [rsp+0x70]
000076bac53d5f68  vmovaps xmm8, [rsp+0x80]
000076bac53d5f71  vmovaps xmm9, [rsp+0x90]
000076bac53d5f7a  vmovaps xmm10, [rsp+0xA0]
000076bac53d5f83  vmovaps xmm11, [rsp+0xB0]
000076bac53d5f8c  vmovaps xmm12, [rsp+0xC0]
000076bac53d5f95  vmovaps xmm14, [rsp+0xD0]
000076bac53d5f9e  vmovaps xmm15, [rsp+0xE0]
000076bac53d5fa7  add rsp, 0xF0
000076bac53d5fae  pop r11
000076bac53d5fb0  pop r10
000076bac53d5fb2  pop r9
000076bac53d5fb4  pop r8
000076bac53d5fb6  pop rsi
000076bac53d5fb7  pop rdi
000076bac53d5fb8  pop rdx
000076bac53d5fb9  pop rcx
000076bac53d5fba  pop rax
000076bac53d5fbb  add rsp, 0x08
000076bac53d5fbf  jmp 0x000076BAC53D303C
000076bac53d5fc4  sub rsp, 0x08
000076bac53d5fc8  push rax
000076bac53d5fc9  push rcx
000076bac53d5fca  push rdx
000076bac53d5fcb  push rdi
000076bac53d5fcc  push rsi
000076bac53d5fcd  push r8
000076bac53d5fcf  push r9
000076bac53d5fd1  push r10
000076bac53d5fd3  push r11
000076bac53d5fd5  sub rsp, 0xF0
000076bac53d5fdc  vmovaps [rsp], xmm0
000076bac53d5fe1  vmovaps [rsp+0x10], xmm2
000076bac53d5fe7  vmovaps [rsp+0x20], xmm3
000076bac53d5fed  vmovaps [rsp+0x30], xmm4
000076bac53d5ff3  vmovaps [rsp+0x40], xmm5
000076bac53d5ff9  vmovaps [rsp+0x50], xmm6
000076bac53d5fff  vmovaps [rsp+0x60], xmm7
000076bac53d6005  vmovaps [rsp+0x70], xmm8
000076bac53d600b  vmovaps [rsp+0x80], xmm9
000076bac53d6014  vmovaps [rsp+0x90], xmm10
000076bac53d601d  vmovaps [rsp+0xA0], xmm11
000076bac53d6026  vmovaps [rsp+0xB0], xmm12
000076bac53d602f  vmovaps [rsp+0xC0], xmm13
000076bac53d6038  vmovaps [rsp+0xD0], xmm14
000076bac53d6041  vmovaps [rsp+0xE0], xmm15
000076bac53d604a  sub rsp, 0x30
000076bac53d604e  movaps [rsp], xmm1
000076bac53d6052  movaps [rsp+0x10], xmm15
000076bac53d6058  movaps [rsp+0x20], xmm10
000076bac53d605e  lea rdi, [rsp]
000076bac53d6062  mov esi, 0x00
000076bac53d6067  mov rax, 0x5641B0A3C530
000076bac53d6071  call rax
000076bac53d6073  movaps xmm1, [rsp]
000076bac53d6077  add rsp, 0x30
000076bac53d607b  vmovaps xmm0, [rsp]
000076bac53d6080  vmovaps xmm2, [rsp+0x10]
000076bac53d6086  vmovaps xmm3, [rsp+0x20]
000076bac53d608c  vmovaps xmm4, [rsp+0x30]
000076bac53d6092  vmovaps xmm5, [rsp+0x40]
000076bac53d6098  vmovaps xmm6, [rsp+0x50]
000076bac53d609e  vmovaps xmm7, [rsp+0x60]
000076bac53d60a4  vmovaps xmm8, [rsp+0x70]
000076bac53d60aa  vmovaps xmm9, [rsp+0x80]
000076bac53d60b3  vmovaps xmm10, [rsp+0x90]
000076bac53d60bc  vmovaps xmm11, [rsp+0xA0]
000076bac53d60c5  vmovaps xmm12, [rsp+0xB0]
000076bac53d60ce  vmovaps xmm13, [rsp+0xC0]
000076bac53d60d7  vmovaps xmm14, [rsp+0xD0]
000076bac53d60e0  vmovaps xmm15, [rsp+0xE0]
000076bac53d60e9  add rsp, 0xF0
000076bac53d60f0  pop r11
000076bac53d60f2  pop r10
000076bac53d60f4  pop r9
000076bac53d60f6  pop r8
000076bac53d60f8  pop rsi
000076bac53d60f9  pop rdi
000076bac53d60fa  pop rdx
000076bac53d60fb  pop rcx
000076bac53d60fc  pop rax
000076bac53d60fd  add rsp, 0x08
000076bac53d6101  jmp 0x000076BAC53D305B
000076bac53d6106  sub rsp, 0x08
000076bac53d610a  push rax
000076bac53d610b  push rcx
000076bac53d610c  push rdx
000076bac53d610d  push rdi
000076bac53d610e  push rsi
000076bac53d610f  push r8
000076bac53d6111  push r9
000076bac53d6113  push r10
000076bac53d6115  push r11
000076bac53d6117  sub rsp, 0xF0
000076bac53d611e  vmovaps [rsp], xmm0
000076bac53d6123  vmovaps [rsp+0x10], xmm1
000076bac53d6129  vmovaps [rsp+0x20], xmm2
000076bac53d612f  vmovaps [rsp+0x30], xmm3
000076bac53d6135  vmovaps [rsp+0x40], xmm4
000076bac53d613b  vmovaps [rsp+0x50], xmm5
000076bac53d6141  vmovaps [rsp+0x60], xmm6
000076bac53d6147  vmovaps [rsp+0x70], xmm7
000076bac53d614d  vmovaps [rsp+0x80], xmm8
000076bac53d6156  vmovaps [rsp+0x90], xmm9
000076bac53d615f  vmovaps [rsp+0xA0], xmm10
000076bac53d6168  vmovaps [rsp+0xB0], xmm11
000076bac53d6171  vmovaps [rsp+0xC0], xmm12
000076bac53d617a  vmovaps [rsp+0xD0], xmm13
000076bac53d6183  vmovaps [rsp+0xE0], xmm14
000076bac53d618c  sub rsp, 0x30
000076bac53d6190  movaps [rsp], xmm15
000076bac53d6195  movaps [rsp+0x10], xmm10
000076bac53d619b  movaps [rsp+0x20], xmm11
000076bac53d61a1  lea rdi, [rsp]
000076bac53d61a5  mov esi, 0x00
000076bac53d61aa  mov rax, 0x5641B0A3C530
000076bac53d61b4  call rax
000076bac53d61b6  movaps xmm15, [rsp]
000076bac53d61bb  add rsp, 0x30
000076bac53d61bf  vmovaps xmm0, [rsp]
000076bac53d61c4  vmovaps xmm1, [rsp+0x10]
000076bac53d61ca  vmovaps xmm2, [rsp+0x20]
000076bac53d61d0  vmovaps xmm3, [rsp+0x30]
000076bac53d61d6  vmovaps xmm4, [rsp+0x40]
000076bac53d61dc  vmovaps xmm5, [rsp+0x50]
000076bac53d61e2  vmovaps xmm6, [rsp+0x60]
000076bac53d61e8  vmovaps xmm7, [rsp+0x70]
000076bac53d61ee  vmovaps xmm8, [rsp+0x80]
000076bac53d61f7  vmovaps xmm9, [rsp+0x90]
000076bac53d6200  vmovaps xmm10, [rsp+0xA0]
000076bac53d6209  vmovaps xmm11, [rsp+0xB0]
000076bac53d6212  vmovaps xmm12, [rsp+0xC0]
000076bac53d621b  vmovaps xmm13, [rsp+0xD0]
000076bac53d6224  vmovaps xmm14, [rsp+0xE0]
000076bac53d622d  add rsp, 0xF0
000076bac53d6234  pop r11
000076bac53d6236  pop r10
000076bac53d6238  pop r9
000076bac53d623a  pop r8
000076bac53d623c  pop rsi
000076bac53d623d  pop rdi
000076bac53d623e  pop rdx
000076bac53d623f  pop rcx
000076bac53d6240  pop rax
000076bac53d6241  add rsp, 0x08
000076bac53d6245  jmp 0x000076BAC53D307E
000076bac53d624a  sub rsp, 0x08
000076bac53d624e  push rax
000076bac53d624f  push rcx
000076bac53d6250  push rdx
000076bac53d6251  push rdi
000076bac53d6252  push rsi
000076bac53d6253  push r8
000076bac53d6255  push r9
000076bac53d6257  push r10
000076bac53d6259  push r11
000076bac53d625b  sub rsp, 0xF0
000076bac53d6262  vmovaps [rsp], xmm0
000076bac53d6267  vmovaps [rsp+0x10], xmm1
000076bac53d626d  vmovaps [rsp+0x20], xmm2
000076bac53d6273  vmovaps [rsp+0x30], xmm3
000076bac53d6279  vmovaps [rsp+0x40], xmm4
000076bac53d627f  vmovaps [rsp+0x50], xmm5
000076bac53d6285  vmovaps [rsp+0x60], xmm6
000076bac53d628b  vmovaps [rsp+0x70], xmm7
000076bac53d6291  vmovaps [rsp+0x80], xmm8
000076bac53d629a  vmovaps [rsp+0x90], xmm9
000076bac53d62a3  vmovaps [rsp+0xA0], xmm11
000076bac53d62ac  vmovaps [rsp+0xB0], xmm12
000076bac53d62b5  vmovaps [rsp+0xC0], xmm13
000076bac53d62be  vmovaps [rsp+0xD0], xmm14
000076bac53d62c7  vmovaps [rsp+0xE0], xmm15
000076bac53d62d0  sub rsp, 0x30
000076bac53d62d4  movaps [rsp], xmm10
000076bac53d62d9  movaps [rsp+0x10], xmm2
000076bac53d62de  movaps [rsp+0x20], xmm11
000076bac53d62e4  lea rdi, [rsp]
000076bac53d62e8  mov esi, 0x00
000076bac53d62ed  mov rax, 0x5641B0A3C530
000076bac53d62f7  call rax
000076bac53d62f9  movaps xmm10, [rsp]
000076bac53d62fe  add rsp, 0x30
000076bac53d6302  vmovaps xmm0, [rsp]
000076bac53d6307  vmovaps xmm1, [rsp+0x10]
000076bac53d630d  vmovaps xmm2, [rsp+0x20]
000076bac53d6313  vmovaps xmm3, [rsp+0x30]
000076bac53d6319  vmovaps xmm4, [rsp+0x40]
000076bac53d631f  vmovaps xmm5, [rsp+0x50]
000076bac53d6325  vmovaps xmm6, [rsp+0x60]
000076bac53d632b  vmovaps xmm7, [rsp+0x70]
000076bac53d6331  vmovaps xmm8, [rsp+0x80]
000076bac53d633a  vmovaps xmm9, [rsp+0x90]
000076bac53d6343  vmovaps xmm11, [rsp+0xA0]
000076bac53d634c  vmovaps xmm12, [rsp+0xB0]
000076bac53d6355  vmovaps xmm13, [rsp+0xC0]
000076bac53d635e  vmovaps xmm14, [rsp+0xD0]
000076bac53d6367  vmovaps xmm15, [rsp+0xE0]
000076bac53d6370  add rsp, 0xF0
000076bac53d6377  pop r11
000076bac53d6379  pop r10
000076bac53d637b  pop r9
000076bac53d637d  pop r8
000076bac53d637f  pop rsi
000076bac53d6380  pop rdi
000076bac53d6381  pop rdx
000076bac53d6382  pop rcx
000076bac53d6383  pop rax
000076bac53d6384  add rsp, 0x08
000076bac53d6388  jmp 0x000076BAC53D30B6
000076bac53d638d  sub rsp, 0x08
000076bac53d6391  push rax
000076bac53d6392  push rcx
000076bac53d6393  push rdx
000076bac53d6394  push rdi
000076bac53d6395  push rsi
000076bac53d6396  push r8
000076bac53d6398  push r9
000076bac53d639a  push r10
000076bac53d639c  push r11
000076bac53d639e  sub rsp, 0xF0
000076bac53d63a5  vmovaps [rsp], xmm0
000076bac53d63aa  vmovaps [rsp+0x10], xmm1
000076bac53d63b0  vmovaps [rsp+0x20], xmm2
000076bac53d63b6  vmovaps [rsp+0x30], xmm3
000076bac53d63bc  vmovaps [rsp+0x40], xmm4
000076bac53d63c2  vmovaps [rsp+0x50], xmm5
000076bac53d63c8  vmovaps [rsp+0x60], xmm6
000076bac53d63ce  vmovaps [rsp+0x70], xmm7
000076bac53d63d4  vmovaps [rsp+0x80], xmm8
000076bac53d63dd  vmovaps [rsp+0x90], xmm9
000076bac53d63e6  vmovaps [rsp+0xA0], xmm10
000076bac53d63ef  vmovaps [rsp+0xB0], xmm12
000076bac53d63f8  vmovaps [rsp+0xC0], xmm13
000076bac53d6401  vmovaps [rsp+0xD0], xmm14
000076bac53d640a  vmovaps [rsp+0xE0], xmm15
000076bac53d6413  sub rsp, 0x30
000076bac53d6417  movaps [rsp], xmm11
000076bac53d641c  movaps [rsp+0x10], xmm2
000076bac53d6421  movaps [rsp+0x20], xmm1
000076bac53d6426  lea rdi, [rsp]
000076bac53d642a  mov esi, 0x00
000076bac53d642f  mov rax, 0x5641B0A3C530
000076bac53d6439  call rax
000076bac53d643b  movaps xmm11, [rsp]
000076bac53d6440  add rsp, 0x30
000076bac53d6444  vmovaps xmm0, [rsp]
000076bac53d6449  vmovaps xmm1, [rsp+0x10]
000076bac53d644f  vmovaps xmm2, [rsp+0x20]
000076bac53d6455  vmovaps xmm3, [rsp+0x30]
000076bac53d645b  vmovaps xmm4, [rsp+0x40]
000076bac53d6461  vmovaps xmm5, [rsp+0x50]
000076bac53d6467  vmovaps xmm6, [rsp+0x60]
000076bac53d646d  vmovaps xmm7, [rsp+0x70]
000076bac53d6473  vmovaps xmm8, [rsp+0x80]
000076bac53d647c  vmovaps xmm9, [rsp+0x90]
000076bac53d6485  vmovaps xmm10, [rsp+0xA0]
000076bac53d648e  vmovaps xmm12, [rsp+0xB0]
000076bac53d6497  vmovaps xmm13, [rsp+0xC0]
000076bac53d64a0  vmovaps xmm14, [rsp+0xD0]
000076bac53d64a9  vmovaps xmm15, [rsp+0xE0]
000076bac53d64b2  add rsp, 0xF0
000076bac53d64b9  pop r11
000076bac53d64bb  pop r10
000076bac53d64bd  pop r9
000076bac53d64bf  pop r8
000076bac53d64c1  pop rsi
000076bac53d64c2  pop rdi
000076bac53d64c3  pop rdx
000076bac53d64c4  pop rcx
000076bac53d64c5  pop rax
000076bac53d64c6  add rsp, 0x08
000076bac53d64ca  jmp 0x000076BAC53D30F2
000076bac53d64cf  sub rsp, 0x08
000076bac53d64d3  push rax
000076bac53d64d4  push rcx
000076bac53d64d5  push rdx
000076bac53d64d6  push rdi
000076bac53d64d7  push rsi
000076bac53d64d8  push r8
000076bac53d64da  push r9
000076bac53d64dc  push r10
000076bac53d64de  push r11
000076bac53d64e0  sub rsp, 0xF0
000076bac53d64e7  vmovaps [rsp], xmm0
000076bac53d64ec  vmovaps [rsp+0x10], xmm2
000076bac53d64f2  vmovaps [rsp+0x20], xmm3
000076bac53d64f8  vmovaps [rsp+0x30], xmm4
000076bac53d64fe  vmovaps [rsp+0x40], xmm5
000076bac53d6504  vmovaps [rsp+0x50], xmm6
000076bac53d650a  vmovaps [rsp+0x60], xmm7
000076bac53d6510  vmovaps [rsp+0x70], xmm8
000076bac53d6516  vmovaps [rsp+0x80], xmm9
000076bac53d651f  vmovaps [rsp+0x90], xmm10
000076bac53d6528  vmovaps [rsp+0xA0], xmm11
000076bac53d6531  vmovaps [rsp+0xB0], xmm12
000076bac53d653a  vmovaps [rsp+0xC0], xmm13
000076bac53d6543  vmovaps [rsp+0xD0], xmm14
000076bac53d654c  vmovaps [rsp+0xE0], xmm15
000076bac53d6555  sub rsp, 0x30
000076bac53d6559  movaps [rsp], xmm1
000076bac53d655d  movaps [rsp+0x10], xmm14
000076bac53d6563  movaps [rsp+0x20], xmm6
000076bac53d6568  lea rdi, [rsp]
000076bac53d656c  mov esi, 0x00
000076bac53d6571  mov rax, 0x5641B0A3C530
000076bac53d657b  call rax
000076bac53d657d  movaps xmm1, [rsp]
000076bac53d6581  add rsp, 0x30
000076bac53d6585  vmovaps xmm0, [rsp]
000076bac53d658a  vmovaps xmm2, [rsp+0x10]
000076bac53d6590  vmovaps xmm3, [rsp+0x20]
000076bac53d6596  vmovaps xmm4, [rsp+0x30]
000076bac53d659c  vmovaps xmm5, [rsp+0x40]
000076bac53d65a2  vmovaps xmm6, [rsp+0x50]
000076bac53d65a8  vmovaps xmm7, [rsp+0x60]
000076bac53d65ae  vmovaps xmm8, [rsp+0x70]
000076bac53d65b4  vmovaps xmm9, [rsp+0x80]
000076bac53d65bd  vmovaps xmm10, [rsp+0x90]
000076bac53d65c6  vmovaps xmm11, [rsp+0xA0]
000076bac53d65cf  vmovaps xmm12, [rsp+0xB0]
000076bac53d65d8  vmovaps xmm13, [rsp+0xC0]
000076bac53d65e1  vmovaps xmm14, [rsp+0xD0]
000076bac53d65ea  vmovaps xmm15, [rsp+0xE0]
000076bac53d65f3  add rsp, 0xF0
000076bac53d65fa  pop r11
000076bac53d65fc  pop r10
000076bac53d65fe  pop r9
000076bac53d6600  pop r8
000076bac53d6602  pop rsi
000076bac53d6603  pop rdi
000076bac53d6604  pop rdx
000076bac53d6605  pop rcx
000076bac53d6606  pop rax
000076bac53d6607  add rsp, 0x08
000076bac53d660b  jmp 0x000076BAC53D310B
000076bac53d6610  sub rsp, 0x08
000076bac53d6614  push rax
000076bac53d6615  push rcx
000076bac53d6616  push rdx
000076bac53d6617  push rdi
000076bac53d6618  push rsi
000076bac53d6619  push r8
000076bac53d661b  push r9
000076bac53d661d  push r10
000076bac53d661f  push r11
000076bac53d6621  sub rsp, 0xF0
000076bac53d6628  vmovaps [rsp], xmm0
000076bac53d662d  vmovaps [rsp+0x10], xmm1
000076bac53d6633  vmovaps [rsp+0x20], xmm2
000076bac53d6639  vmovaps [rsp+0x30], xmm3
000076bac53d663f  vmovaps [rsp+0x40], xmm4
000076bac53d6645  vmovaps [rsp+0x50], xmm5
000076bac53d664b  vmovaps [rsp+0x60], xmm6
000076bac53d6651  vmovaps [rsp+0x70], xmm7
000076bac53d6657  vmovaps [rsp+0x80], xmm8
000076bac53d6660  vmovaps [rsp+0x90], xmm9
000076bac53d6669  vmovaps [rsp+0xA0], xmm10
000076bac53d6672  vmovaps [rsp+0xB0], xmm11
000076bac53d667b  vmovaps [rsp+0xC0], xmm12
000076bac53d6684  vmovaps [rsp+0xD0], xmm13
000076bac53d668d  vmovaps [rsp+0xE0], xmm14
000076bac53d6696  sub rsp, 0x30
000076bac53d669a  movaps [rsp], xmm15
000076bac53d669f  movaps [rsp+0x10], xmm14
000076bac53d66a5  movaps [rsp+0x20], xmm5
000076bac53d66aa  lea rdi, [rsp]
000076bac53d66ae  mov esi, 0x00
000076bac53d66b3  mov rax, 0x5641B0A3C530
000076bac53d66bd  call rax
000076bac53d66bf  movaps xmm15, [rsp]
000076bac53d66c4  add rsp, 0x30
000076bac53d66c8  vmovaps xmm0, [rsp]
000076bac53d66cd  vmovaps xmm1, [rsp+0x10]
000076bac53d66d3  vmovaps xmm2, [rsp+0x20]
000076bac53d66d9  vmovaps xmm3, [rsp+0x30]
000076bac53d66df  vmovaps xmm4, [rsp+0x40]
000076bac53d66e5  vmovaps xmm5, [rsp+0x50]
000076bac53d66eb  vmovaps xmm6, [rsp+0x60]
000076bac53d66f1  vmovaps xmm7, [rsp+0x70]
000076bac53d66f7  vmovaps xmm8, [rsp+0x80]
000076bac53d6700  vmovaps xmm9, [rsp+0x90]
000076bac53d6709  vmovaps xmm10, [rsp+0xA0]
000076bac53d6712  vmovaps xmm11, [rsp+0xB0]
000076bac53d671b  vmovaps xmm12, [rsp+0xC0]
000076bac53d6724  vmovaps xmm13, [rsp+0xD0]
000076bac53d672d  vmovaps xmm14, [rsp+0xE0]
000076bac53d6736  add rsp, 0xF0
000076bac53d673d  pop r11
000076bac53d673f  pop r10
000076bac53d6741  pop r9
000076bac53d6743  pop r8
000076bac53d6745  pop rsi
000076bac53d6746  pop rdi
000076bac53d6747  pop rdx
000076bac53d6748  pop rcx
000076bac53d6749  pop rax
000076bac53d674a  add rsp, 0x08
000076bac53d674e  jmp 0x000076BAC53D312B
000076bac53d6753  sub rsp, 0x08
000076bac53d6757  push rax
000076bac53d6758  push rcx
000076bac53d6759  push rdx
000076bac53d675a  push rdi
000076bac53d675b  push rsi
000076bac53d675c  push r8
000076bac53d675e  push r9
000076bac53d6760  push r10
000076bac53d6762  push r11
000076bac53d6764  sub rsp, 0xF0
000076bac53d676b  vmovaps [rsp], xmm0
000076bac53d6770  vmovaps [rsp+0x10], xmm1
000076bac53d6776  vmovaps [rsp+0x20], xmm2
000076bac53d677c  vmovaps [rsp+0x30], xmm3
000076bac53d6782  vmovaps [rsp+0x40], xmm4
000076bac53d6788  vmovaps [rsp+0x50], xmm5
000076bac53d678e  vmovaps [rsp+0x60], xmm7
000076bac53d6794  vmovaps [rsp+0x70], xmm8
000076bac53d679a  vmovaps [rsp+0x80], xmm9
000076bac53d67a3  vmovaps [rsp+0x90], xmm10
000076bac53d67ac  vmovaps [rsp+0xA0], xmm11
000076bac53d67b5  vmovaps [rsp+0xB0], xmm12
000076bac53d67be  vmovaps [rsp+0xC0], xmm13
000076bac53d67c7  vmovaps [rsp+0xD0], xmm14
000076bac53d67d0  vmovaps [rsp+0xE0], xmm15
000076bac53d67d9  sub rsp, 0x30
000076bac53d67dd  movaps [rsp], xmm6
000076bac53d67e1  movaps [rsp+0x10], xmm9
000076bac53d67e7  movaps [rsp+0x20], xmm14
000076bac53d67ed  lea rdi, [rsp]
000076bac53d67f1  mov esi, 0x00
000076bac53d67f6  mov rax, 0x5641B0A3C530
000076bac53d6800  call rax
000076bac53d6802  movaps xmm6, [rsp]
000076bac53d6806  add rsp, 0x30
000076bac53d680a  vmovaps xmm0, [rsp]
000076bac53d680f  vmovaps xmm1, [rsp+0x10]
000076bac53d6815  vmovaps xmm2, [rsp+0x20]
000076bac53d681b  vmovaps xmm3, [rsp+0x30]
000076bac53d6821  vmovaps xmm4, [rsp+0x40]
000076bac53d6827  vmovaps xmm5, [rsp+0x50]
000076bac53d682d  vmovaps xmm7, [rsp+0x60]
000076bac53d6833  vmovaps xmm8, [rsp+0x70]
000076bac53d6839  vmovaps xmm9, [rsp+0x80]
000076bac53d6842  vmovaps xmm10, [rsp+0x90]
000076bac53d684b  vmovaps xmm11, [rsp+0xA0]
000076bac53d6854  vmovaps xmm12, [rsp+0xB0]
000076bac53d685d  vmovaps xmm13, [rsp+0xC0]
000076bac53d6866  vmovaps xmm14, [rsp+0xD0]
000076bac53d686f  vmovaps xmm15, [rsp+0xE0]
000076bac53d6878  add rsp, 0xF0
000076bac53d687f  pop r11
000076bac53d6881  pop r10
000076bac53d6883  pop r9
000076bac53d6885  pop r8
000076bac53d6887  pop rsi
000076bac53d6888  pop rdi
000076bac53d6889  pop rdx
000076bac53d688a  pop rcx
000076bac53d688b  pop rax
000076bac53d688c  add rsp, 0x08
000076bac53d6890  jmp 0x000076BAC53D3153
000076bac53d6895  sub rsp, 0x08
000076bac53d6899  push rax
000076bac53d689a  push rcx
000076bac53d689b  push rdx
000076bac53d689c  push rdi
000076bac53d689d  push rsi
000076bac53d689e  push r8
000076bac53d68a0  push r9
000076bac53d68a2  push r10
000076bac53d68a4  push r11
000076bac53d68a6  sub rsp, 0xF0
000076bac53d68ad  vmovaps [rsp], xmm0
000076bac53d68b2  vmovaps [rsp+0x10], xmm1
000076bac53d68b8  vmovaps [rsp+0x20], xmm2
000076bac53d68be  vmovaps [rsp+0x30], xmm3
000076bac53d68c4  vmovaps [rsp+0x40], xmm4
000076bac53d68ca  vmovaps [rsp+0x50], xmm5
000076bac53d68d0  vmovaps [rsp+0x60], xmm6
000076bac53d68d6  vmovaps [rsp+0x70], xmm7
000076bac53d68dc  vmovaps [rsp+0x80], xmm8
000076bac53d68e5  vmovaps [rsp+0x90], xmm9
000076bac53d68ee  vmovaps [rsp+0xA0], xmm10
000076bac53d68f7  vmovaps [rsp+0xB0], xmm11
000076bac53d6900  vmovaps [rsp+0xC0], xmm12
000076bac53d6909  vmovaps [rsp+0xD0], xmm13
000076bac53d6912  vmovaps [rsp+0xE0], xmm15
000076bac53d691b  sub rsp, 0x30
000076bac53d691f  movaps [rsp], xmm14
000076bac53d6924  movaps [rsp+0x10], xmm9
000076bac53d692a  movaps [rsp+0x20], xmm13
000076bac53d6930  lea rdi, [rsp]
000076bac53d6934  mov esi, 0x00
000076bac53d6939  mov rax, 0x5641B0A3C530
000076bac53d6943  call rax
000076bac53d6945  movaps xmm14, [rsp]
000076bac53d694a  add rsp, 0x30
000076bac53d694e  vmovaps xmm0, [rsp]
000076bac53d6953  vmovaps xmm1, [rsp+0x10]
000076bac53d6959  vmovaps xmm2, [rsp+0x20]
000076bac53d695f  vmovaps xmm3, [rsp+0x30]
000076bac53d6965  vmovaps xmm4, [rsp+0x40]
000076bac53d696b  vmovaps xmm5, [rsp+0x50]
000076bac53d6971  vmovaps xmm6, [rsp+0x60]
000076bac53d6977  vmovaps xmm7, [rsp+0x70]
000076bac53d697d  vmovaps xmm8, [rsp+0x80]
000076bac53d6986  vmovaps xmm9, [rsp+0x90]
000076bac53d698f  vmovaps xmm10, [rsp+0xA0]
000076bac53d6998  vmovaps xmm11, [rsp+0xB0]
000076bac53d69a1  vmovaps xmm12, [rsp+0xC0]
000076bac53d69aa  vmovaps xmm13, [rsp+0xD0]
000076bac53d69b3  vmovaps xmm15, [rsp+0xE0]
000076bac53d69bc  add rsp, 0xF0
000076bac53d69c3  pop r11
000076bac53d69c5  pop r10
000076bac53d69c7  pop r9
000076bac53d69c9  pop r8
000076bac53d69cb  pop rsi
000076bac53d69cc  pop rdi
000076bac53d69cd  pop rdx
000076bac53d69ce  pop rcx
000076bac53d69cf  pop rax
000076bac53d69d0  add rsp, 0x08
000076bac53d69d4  jmp 0x000076BAC53D3176
000076bac53d69d9  sub rsp, 0x08
000076bac53d69dd  push rax
000076bac53d69de  push rcx
000076bac53d69df  push rdx
000076bac53d69e0  push rdi
000076bac53d69e1  push rsi
000076bac53d69e2  push r8
000076bac53d69e4  push r9
000076bac53d69e6  push r10
000076bac53d69e8  push r11
000076bac53d69ea  sub rsp, 0xF0
000076bac53d69f1  vmovaps [rsp], xmm0
000076bac53d69f6  vmovaps [rsp+0x10], xmm1
000076bac53d69fc  vmovaps [rsp+0x20], xmm2
000076bac53d6a02  vmovaps [rsp+0x30], xmm3
000076bac53d6a08  vmovaps [rsp+0x40], xmm4
000076bac53d6a0e  vmovaps [rsp+0x50], xmm5
000076bac53d6a14  vmovaps [rsp+0x60], xmm6
000076bac53d6a1a  vmovaps [rsp+0x70], xmm7
000076bac53d6a20  vmovaps [rsp+0x80], xmm8
000076bac53d6a29  vmovaps [rsp+0x90], xmm9
000076bac53d6a32  vmovaps [rsp+0xA0], xmm10
000076bac53d6a3b  vmovaps [rsp+0xB0], xmm11
000076bac53d6a44  vmovaps [rsp+0xC0], xmm12
000076bac53d6a4d  vmovaps [rsp+0xD0], xmm14
000076bac53d6a56  vmovaps [rsp+0xE0], xmm15
000076bac53d6a5f  sub rsp, 0x30
000076bac53d6a63  movaps [rsp], xmm13
000076bac53d6a68  movaps [rsp+0x10], xmm9
000076bac53d6a6e  movaps [rsp+0x20], xmm10
000076bac53d6a74  lea rdi, [rsp]
000076bac53d6a78  mov esi, 0x00
000076bac53d6a7d  mov rax, 0x5641B0A3C530
000076bac53d6a87  call rax
000076bac53d6a89  movaps xmm13, [rsp]
000076bac53d6a8e  add rsp, 0x30
000076bac53d6a92  vmovaps xmm0, [rsp]
000076bac53d6a97  vmovaps xmm1, [rsp+0x10]
000076bac53d6a9d  vmovaps xmm2, [rsp+0x20]
000076bac53d6aa3  vmovaps xmm3, [rsp+0x30]
000076bac53d6aa9  vmovaps xmm4, [rsp+0x40]
000076bac53d6aaf  vmovaps xmm5, [rsp+0x50]
000076bac53d6ab5  vmovaps xmm6, [rsp+0x60]
000076bac53d6abb  vmovaps xmm7, [rsp+0x70]
000076bac53d6ac1  vmovaps xmm8, [rsp+0x80]
000076bac53d6aca  vmovaps xmm9, [rsp+0x90]
000076bac53d6ad3  vmovaps xmm10, [rsp+0xA0]
000076bac53d6adc  vmovaps xmm11, [rsp+0xB0]
000076bac53d6ae5  vmovaps xmm12, [rsp+0xC0]
000076bac53d6aee  vmovaps xmm14, [rsp+0xD0]
000076bac53d6af7  vmovaps xmm15, [rsp+0xE0]
000076bac53d6b00  add rsp, 0xF0
000076bac53d6b07  pop r11
000076bac53d6b09  pop r10
000076bac53d6b0b  pop r9
000076bac53d6b0d  pop r8
000076bac53d6b0f  pop rsi
000076bac53d6b10  pop rdi
000076bac53d6b11  pop rdx
000076bac53d6b12  pop rcx
000076bac53d6b13  pop rax
000076bac53d6b14  add rsp, 0x08
000076bac53d6b18  jmp 0x000076BAC53D3196
000076bac53d6b1d  call 0x000076BAC520AFE0
000076bac53d6b22  jmp 0x000076BAC53D31EB
000076bac53d6b27  sub rsp, 0x08
000076bac53d6b2b  push rax
000076bac53d6b2c  push rcx
000076bac53d6b2d  push rdx
000076bac53d6b2e  push rdi
000076bac53d6b2f  push rsi
000076bac53d6b30  push r8
000076bac53d6b32  push r9
000076bac53d6b34  push r10
000076bac53d6b36  push r11
000076bac53d6b38  sub rsp, 0xF0
000076bac53d6b3f  vmovaps [rsp], xmm0
000076bac53d6b44  vmovaps [rsp+0x10], xmm1
000076bac53d6b4a  vmovaps [rsp+0x20], xmm2
000076bac53d6b50  vmovaps [rsp+0x30], xmm3
000076bac53d6b56  vmovaps [rsp+0x40], xmm4
000076bac53d6b5c  vmovaps [rsp+0x50], xmm5
000076bac53d6b62  vmovaps [rsp+0x60], xmm6
000076bac53d6b68  vmovaps [rsp+0x70], xmm7
000076bac53d6b6e  vmovaps [rsp+0x80], xmm8
000076bac53d6b77  vmovaps [rsp+0x90], xmm10
000076bac53d6b80  vmovaps [rsp+0xA0], xmm11
000076bac53d6b89  vmovaps [rsp+0xB0], xmm12
000076bac53d6b92  vmovaps [rsp+0xC0], xmm13
000076bac53d6b9b  vmovaps [rsp+0xD0], xmm14
000076bac53d6ba4  vmovaps [rsp+0xE0], xmm15
000076bac53d6bad  sub rsp, 0x30
000076bac53d6bb1  movaps [rsp], xmm9
000076bac53d6bb6  movaps [rsp+0x10], xmm8
000076bac53d6bbc  movaps [rsp+0x20], xmm10
000076bac53d6bc2  lea rdi, [rsp]
000076bac53d6bc6  mov esi, 0x00
000076bac53d6bcb  mov rax, 0x5641B0A3C530
000076bac53d6bd5  call rax
000076bac53d6bd7  movaps xmm9, [rsp]
000076bac53d6bdc  add rsp, 0x30
000076bac53d6be0  vmovaps xmm0, [rsp]
000076bac53d6be5  vmovaps xmm1, [rsp+0x10]
000076bac53d6beb  vmovaps xmm2, [rsp+0x20]
000076bac53d6bf1  vmovaps xmm3, [rsp+0x30]
000076bac53d6bf7  vmovaps xmm4, [rsp+0x40]
000076bac53d6bfd  vmovaps xmm5, [rsp+0x50]
000076bac53d6c03  vmovaps xmm6, [rsp+0x60]
000076bac53d6c09  vmovaps xmm7, [rsp+0x70]
000076bac53d6c0f  vmovaps xmm8, [rsp+0x80]
000076bac53d6c18  vmovaps xmm10, [rsp+0x90]
000076bac53d6c21  vmovaps xmm11, [rsp+0xA0]
000076bac53d6c2a  vmovaps xmm12, [rsp+0xB0]
000076bac53d6c33  vmovaps xmm13, [rsp+0xC0]
000076bac53d6c3c  vmovaps xmm14, [rsp+0xD0]
000076bac53d6c45  vmovaps xmm15, [rsp+0xE0]
000076bac53d6c4e  add rsp, 0xF0
000076bac53d6c55  pop r11
000076bac53d6c57  pop r10
000076bac53d6c59  pop r9
000076bac53d6c5b  pop r8
000076bac53d6c5d  pop rsi
000076bac53d6c5e  pop rdi
000076bac53d6c5f  pop rdx
000076bac53d6c60  pop rcx
000076bac53d6c61  pop rax
000076bac53d6c62  add rsp, 0x08
000076bac53d6c66  jmp 0x000076BAC53D321C
000076bac53d6c6b  sub rsp, 0x08
000076bac53d6c6f  push rax
000076bac53d6c70  push rcx
000076bac53d6c71  push rdx
000076bac53d6c72  push rdi
000076bac53d6c73  push rsi
000076bac53d6c74  push r8
000076bac53d6c76  push r9
000076bac53d6c78  push r10
000076bac53d6c7a  push r11
000076bac53d6c7c  sub rsp, 0xF0
000076bac53d6c83  vmovaps [rsp], xmm0
000076bac53d6c88  vmovaps [rsp+0x10], xmm1
000076bac53d6c8e  vmovaps [rsp+0x20], xmm2
000076bac53d6c94  vmovaps [rsp+0x30], xmm3
000076bac53d6c9a  vmovaps [rsp+0x40], xmm4
000076bac53d6ca0  vmovaps [rsp+0x50], xmm5
000076bac53d6ca6  vmovaps [rsp+0x60], xmm6
000076bac53d6cac  vmovaps [rsp+0x70], xmm7
000076bac53d6cb2  vmovaps [rsp+0x80], xmm8
000076bac53d6cbb  vmovaps [rsp+0x90], xmm9
000076bac53d6cc4  vmovaps [rsp+0xA0], xmm11
000076bac53d6ccd  vmovaps [rsp+0xB0], xmm12
000076bac53d6cd6  vmovaps [rsp+0xC0], xmm13
000076bac53d6cdf  vmovaps [rsp+0xD0], xmm14
000076bac53d6ce8  vmovaps [rsp+0xE0], xmm15
000076bac53d6cf1  sub rsp, 0x30
000076bac53d6cf5  movaps [rsp], xmm10
000076bac53d6cfa  movaps [rsp+0x10], xmm1
000076bac53d6cff  movaps [rsp+0x20], xmm11
000076bac53d6d05  lea rdi, [rsp]
000076bac53d6d09  mov esi, 0x00
000076bac53d6d0e  mov rax, 0x5641B0A3C530
000076bac53d6d18  call rax
000076bac53d6d1a  movaps xmm10, [rsp]
000076bac53d6d1f  add rsp, 0x30
000076bac53d6d23  vmovaps xmm0, [rsp]
000076bac53d6d28  vmovaps xmm1, [rsp+0x10]
000076bac53d6d2e  vmovaps xmm2, [rsp+0x20]
000076bac53d6d34  vmovaps xmm3, [rsp+0x30]
000076bac53d6d3a  vmovaps xmm4, [rsp+0x40]
000076bac53d6d40  vmovaps xmm5, [rsp+0x50]
000076bac53d6d46  vmovaps xmm6, [rsp+0x60]
000076bac53d6d4c  vmovaps xmm7, [rsp+0x70]
000076bac53d6d52  vmovaps xmm8, [rsp+0x80]
000076bac53d6d5b  vmovaps xmm9, [rsp+0x90]
000076bac53d6d64  vmovaps xmm11, [rsp+0xA0]
000076bac53d6d6d  vmovaps xmm12, [rsp+0xB0]
000076bac53d6d76  vmovaps xmm13, [rsp+0xC0]
000076bac53d6d7f  vmovaps xmm14, [rsp+0xD0]
000076bac53d6d88  vmovaps xmm15, [rsp+0xE0]
000076bac53d6d91  add rsp, 0xF0
000076bac53d6d98  pop r11
000076bac53d6d9a  pop r10
000076bac53d6d9c  pop r9
000076bac53d6d9e  pop r8
000076bac53d6da0  pop rsi
000076bac53d6da1  pop rdi
000076bac53d6da2  pop rdx
000076bac53d6da3  pop rcx
000076bac53d6da4  pop rax
000076bac53d6da5  add rsp, 0x08
000076bac53d6da9  jmp 0x000076BAC53D3237
000076bac53d6dae  sub rsp, 0x08
000076bac53d6db2  push rax
000076bac53d6db3  push rcx
000076bac53d6db4  push rdx
000076bac53d6db5  push rdi
000076bac53d6db6  push rsi
000076bac53d6db7  push r8
000076bac53d6db9  push r9
000076bac53d6dbb  push r10
000076bac53d6dbd  push r11
000076bac53d6dbf  sub rsp, 0xF0
000076bac53d6dc6  vmovaps [rsp], xmm0
000076bac53d6dcb  vmovaps [rsp+0x10], xmm2
000076bac53d6dd1  vmovaps [rsp+0x20], xmm3
000076bac53d6dd7  vmovaps [rsp+0x30], xmm4
000076bac53d6ddd  vmovaps [rsp+0x40], xmm5
000076bac53d6de3  vmovaps [rsp+0x50], xmm6
000076bac53d6de9  vmovaps [rsp+0x60], xmm7
000076bac53d6def  vmovaps [rsp+0x70], xmm8
000076bac53d6df5  vmovaps [rsp+0x80], xmm9
000076bac53d6dfe  vmovaps [rsp+0x90], xmm10
000076bac53d6e07  vmovaps [rsp+0xA0], xmm11
000076bac53d6e10  vmovaps [rsp+0xB0], xmm12
000076bac53d6e19  vmovaps [rsp+0xC0], xmm13
000076bac53d6e22  vmovaps [rsp+0xD0], xmm14
000076bac53d6e2b  vmovaps [rsp+0xE0], xmm15
000076bac53d6e34  sub rsp, 0x30
000076bac53d6e38  movaps [rsp], xmm1
000076bac53d6e3c  movaps [rsp+0x10], xmm15
000076bac53d6e42  movaps [rsp+0x20], xmm6
000076bac53d6e47  lea rdi, [rsp]
000076bac53d6e4b  mov esi, 0x00
000076bac53d6e50  mov rax, 0x5641B0A3C530
000076bac53d6e5a  call rax
000076bac53d6e5c  movaps xmm1, [rsp]
000076bac53d6e60  add rsp, 0x30
000076bac53d6e64  vmovaps xmm0, [rsp]
000076bac53d6e69  vmovaps xmm2, [rsp+0x10]
000076bac53d6e6f  vmovaps xmm3, [rsp+0x20]
000076bac53d6e75  vmovaps xmm4, [rsp+0x30]
000076bac53d6e7b  vmovaps xmm5, [rsp+0x40]
000076bac53d6e81  vmovaps xmm6, [rsp+0x50]
000076bac53d6e87  vmovaps xmm7, [rsp+0x60]
000076bac53d6e8d  vmovaps xmm8, [rsp+0x70]
000076bac53d6e93  vmovaps xmm9, [rsp+0x80]
000076bac53d6e9c  vmovaps xmm10, [rsp+0x90]
000076bac53d6ea5  vmovaps xmm11, [rsp+0xA0]
000076bac53d6eae  vmovaps xmm12, [rsp+0xB0]
000076bac53d6eb7  vmovaps xmm13, [rsp+0xC0]
000076bac53d6ec0  vmovaps xmm14, [rsp+0xD0]
000076bac53d6ec9  vmovaps xmm15, [rsp+0xE0]
000076bac53d6ed2  add rsp, 0xF0
000076bac53d6ed9  pop r11
000076bac53d6edb  pop r10
000076bac53d6edd  pop r9
000076bac53d6edf  pop r8
000076bac53d6ee1  pop rsi
000076bac53d6ee2  pop rdi
000076bac53d6ee3  pop rdx
000076bac53d6ee4  pop rcx
000076bac53d6ee5  pop rax
000076bac53d6ee6  add rsp, 0x08
000076bac53d6eea  jmp 0x000076BAC53D3250
000076bac53d6eef  sub rsp, 0x08
000076bac53d6ef3  push rax
000076bac53d6ef4  push rcx
000076bac53d6ef5  push rdx
000076bac53d6ef6  push rdi
000076bac53d6ef7  push rsi
000076bac53d6ef8  push r8
000076bac53d6efa  push r9
000076bac53d6efc  push r10
000076bac53d6efe  push r11
000076bac53d6f00  sub rsp, 0xF0
000076bac53d6f07  vmovaps [rsp], xmm0
000076bac53d6f0c  vmovaps [rsp+0x10], xmm1
000076bac53d6f12  vmovaps [rsp+0x20], xmm2
000076bac53d6f18  vmovaps [rsp+0x30], xmm3
000076bac53d6f1e  vmovaps [rsp+0x40], xmm4
000076bac53d6f24  vmovaps [rsp+0x50], xmm5
000076bac53d6f2a  vmovaps [rsp+0x60], xmm6
000076bac53d6f30  vmovaps [rsp+0x70], xmm7
000076bac53d6f36  vmovaps [rsp+0x80], xmm8
000076bac53d6f3f  vmovaps [rsp+0x90], xmm9
000076bac53d6f48  vmovaps [rsp+0xA0], xmm10
000076bac53d6f51  vmovaps [rsp+0xB0], xmm12
000076bac53d6f5a  vmovaps [rsp+0xC0], xmm13
000076bac53d6f63  vmovaps [rsp+0xD0], xmm14
000076bac53d6f6c  vmovaps [rsp+0xE0], xmm15
000076bac53d6f75  sub rsp, 0x30
000076bac53d6f79  movaps [rsp], xmm11
000076bac53d6f7e  movaps [rsp+0x10], xmm12
000076bac53d6f84  movaps [rsp+0x20], xmm15
000076bac53d6f8a  lea rdi, [rsp]
000076bac53d6f8e  mov esi, 0x00
000076bac53d6f93  mov rax, 0x5641B0A3C530
000076bac53d6f9d  call rax
000076bac53d6f9f  movaps xmm11, [rsp]
000076bac53d6fa4  add rsp, 0x30
000076bac53d6fa8  vmovaps xmm0, [rsp]
000076bac53d6fad  vmovaps xmm1, [rsp+0x10]
000076bac53d6fb3  vmovaps xmm2, [rsp+0x20]
000076bac53d6fb9  vmovaps xmm3, [rsp+0x30]
000076bac53d6fbf  vmovaps xmm4, [rsp+0x40]
000076bac53d6fc5  vmovaps xmm5, [rsp+0x50]
000076bac53d6fcb  vmovaps xmm6, [rsp+0x60]
000076bac53d6fd1  vmovaps xmm7, [rsp+0x70]
000076bac53d6fd7  vmovaps xmm8, [rsp+0x80]
000076bac53d6fe0  vmovaps xmm9, [rsp+0x90]
000076bac53d6fe9  vmovaps xmm10, [rsp+0xA0]
000076bac53d6ff2  vmovaps xmm12, [rsp+0xB0]
000076bac53d6ffb  vmovaps xmm13, [rsp+0xC0]
000076bac53d7004  vmovaps xmm14, [rsp+0xD0]
000076bac53d700d  vmovaps xmm15, [rsp+0xE0]
000076bac53d7016  add rsp, 0xF0
000076bac53d701d  pop r11
000076bac53d701f  pop r10
000076bac53d7021  pop r9
000076bac53d7023  pop r8
000076bac53d7025  pop rsi
000076bac53d7026  pop rdi
000076bac53d7027  pop rdx
000076bac53d7028  pop rcx
000076bac53d7029  pop rax
000076bac53d702a  add rsp, 0x08
000076bac53d702e  jmp 0x000076BAC53D327A
000076bac53d7033  sub rsp, 0x08
000076bac53d7037  push rax
000076bac53d7038  push rcx
000076bac53d7039  push rdx
000076bac53d703a  push rdi
000076bac53d703b  push rsi
000076bac53d703c  push r8
000076bac53d703e  push r9
000076bac53d7040  push r10
000076bac53d7042  push r11
000076bac53d7044  sub rsp, 0xF0
000076bac53d704b  vmovaps [rsp], xmm0
000076bac53d7050  vmovaps [rsp+0x10], xmm1
000076bac53d7056  vmovaps [rsp+0x20], xmm2
000076bac53d705c  vmovaps [rsp+0x30], xmm3
000076bac53d7062  vmovaps [rsp+0x40], xmm4
000076bac53d7068  vmovaps [rsp+0x50], xmm5
000076bac53d706e  vmovaps [rsp+0x60], xmm6
000076bac53d7074  vmovaps [rsp+0x70], xmm7
000076bac53d707a  vmovaps [rsp+0x80], xmm8
000076bac53d7083  vmovaps [rsp+0x90], xmm9
000076bac53d708c  vmovaps [rsp+0xA0], xmm10
000076bac53d7095  vmovaps [rsp+0xB0], xmm11
000076bac53d709e  vmovaps [rsp+0xC0], xmm13
000076bac53d70a7  vmovaps [rsp+0xD0], xmm14
000076bac53d70b0  vmovaps [rsp+0xE0], xmm15
000076bac53d70b9  sub rsp, 0x30
000076bac53d70bd  movaps [rsp], xmm12
000076bac53d70c2  movaps [rsp+0x10], xmm8
000076bac53d70c8  movaps [rsp+0x20], xmm15
000076bac53d70ce  lea rdi, [rsp]
000076bac53d70d2  mov esi, 0x00
000076bac53d70d7  mov rax, 0x5641B0A3C530
000076bac53d70e1  call rax
000076bac53d70e3  movaps xmm12, [rsp]
000076bac53d70e8  add rsp, 0x30
000076bac53d70ec  vmovaps xmm0, [rsp]
000076bac53d70f1  vmovaps xmm1, [rsp+0x10]
000076bac53d70f7  vmovaps xmm2, [rsp+0x20]
000076bac53d70fd  vmovaps xmm3, [rsp+0x30]
000076bac53d7103  vmovaps xmm4, [rsp+0x40]
000076bac53d7109  vmovaps xmm5, [rsp+0x50]
000076bac53d710f  vmovaps xmm6, [rsp+0x60]
000076bac53d7115  vmovaps xmm7, [rsp+0x70]
000076bac53d711b  vmovaps xmm8, [rsp+0x80]
000076bac53d7124  vmovaps xmm9, [rsp+0x90]
000076bac53d712d  vmovaps xmm10, [rsp+0xA0]
000076bac53d7136  vmovaps xmm11, [rsp+0xB0]
000076bac53d713f  vmovaps xmm13, [rsp+0xC0]
000076bac53d7148  vmovaps xmm14, [rsp+0xD0]
000076bac53d7151  vmovaps xmm15, [rsp+0xE0]
000076bac53d715a  add rsp, 0xF0
000076bac53d7161  pop r11
000076bac53d7163  pop r10
000076bac53d7165  pop r9
000076bac53d7167  pop r8
000076bac53d7169  pop rsi
000076bac53d716a  pop rdi
000076bac53d716b  pop rdx
000076bac53d716c  pop rcx
000076bac53d716d  pop rax
000076bac53d716e  add rsp, 0x08
000076bac53d7172  jmp 0x000076BAC53D32A9
000076bac53d7177  sub rsp, 0x08
000076bac53d717b  push rax
000076bac53d717c  push rcx
000076bac53d717d  push rdx
000076bac53d717e  push rdi
000076bac53d717f  push rsi
000076bac53d7180  push r8
000076bac53d7182  push r9
000076bac53d7184  push r10
000076bac53d7186  push r11
000076bac53d7188  sub rsp, 0xF0
000076bac53d718f  vmovaps [rsp], xmm0
000076bac53d7194  vmovaps [rsp+0x10], xmm1
000076bac53d719a  vmovaps [rsp+0x20], xmm2
000076bac53d71a0  vmovaps [rsp+0x30], xmm3
000076bac53d71a6  vmovaps [rsp+0x40], xmm4
000076bac53d71ac  vmovaps [rsp+0x50], xmm5
000076bac53d71b2  vmovaps [rsp+0x60], xmm6
000076bac53d71b8  vmovaps [rsp+0x70], xmm7
000076bac53d71be  vmovaps [rsp+0x80], xmm9
000076bac53d71c7  vmovaps [rsp+0x90], xmm10
000076bac53d71d0  vmovaps [rsp+0xA0], xmm11
000076bac53d71d9  vmovaps [rsp+0xB0], xmm12
000076bac53d71e2  vmovaps [rsp+0xC0], xmm13
000076bac53d71eb  vmovaps [rsp+0xD0], xmm14
000076bac53d71f4  vmovaps [rsp+0xE0], xmm15
000076bac53d71fd  sub rsp, 0x30
000076bac53d7201  movaps [rsp], xmm8
000076bac53d7206  movaps [rsp+0x10], xmm7
000076bac53d720b  movaps [rsp+0x20], xmm15
000076bac53d7211  lea rdi, [rsp]
000076bac53d7215  mov esi, 0x00
000076bac53d721a  mov rax, 0x5641B0A3C530
000076bac53d7224  call rax
000076bac53d7226  movaps xmm8, [rsp]
000076bac53d722b  add rsp, 0x30
000076bac53d722f  vmovaps xmm0, [rsp]
000076bac53d7234  vmovaps xmm1, [rsp+0x10]
000076bac53d723a  vmovaps xmm2, [rsp+0x20]
000076bac53d7240  vmovaps xmm3, [rsp+0x30]
000076bac53d7246  vmovaps xmm4, [rsp+0x40]
000076bac53d724c  vmovaps xmm5, [rsp+0x50]
000076bac53d7252  vmovaps xmm6, [rsp+0x60]
000076bac53d7258  vmovaps xmm7, [rsp+0x70]
000076bac53d725e  vmovaps xmm9, [rsp+0x80]
000076bac53d7267  vmovaps xmm10, [rsp+0x90]
000076bac53d7270  vmovaps xmm11, [rsp+0xA0]
000076bac53d7279  vmovaps xmm12, [rsp+0xB0]
000076bac53d7282  vmovaps xmm13, [rsp+0xC0]
000076bac53d728b  vmovaps xmm14, [rsp+0xD0]
000076bac53d7294  vmovaps xmm15, [rsp+0xE0]
000076bac53d729d  add rsp, 0xF0
000076bac53d72a4  pop r11
000076bac53d72a6  pop r10
000076bac53d72a8  pop r9
000076bac53d72aa  pop r8
000076bac53d72ac  pop rsi
000076bac53d72ad  pop rdi
000076bac53d72ae  pop rdx
000076bac53d72af  pop rcx
000076bac53d72b0  pop rax
000076bac53d72b1  add rsp, 0x08
000076bac53d72b5  jmp 0x000076BAC53D32CF
000076bac53d72ba  sub rsp, 0x08
000076bac53d72be  push rax
000076bac53d72bf  push rcx
000076bac53d72c0  push rdx
000076bac53d72c1  push rdi
000076bac53d72c2  push rsi
000076bac53d72c3  push r8
000076bac53d72c5  push r9
000076bac53d72c7  push r10
000076bac53d72c9  push r11
000076bac53d72cb  sub rsp, 0xF0
000076bac53d72d2  vmovaps [rsp], xmm0
000076bac53d72d7  vmovaps [rsp+0x10], xmm1
000076bac53d72dd  vmovaps [rsp+0x20], xmm2
000076bac53d72e3  vmovaps [rsp+0x30], xmm3
000076bac53d72e9  vmovaps [rsp+0x40], xmm4
000076bac53d72ef  vmovaps [rsp+0x50], xmm5
000076bac53d72f5  vmovaps [rsp+0x60], xmm6
000076bac53d72fb  vmovaps [rsp+0x70], xmm7
000076bac53d7301  vmovaps [rsp+0x80], xmm8
000076bac53d730a  vmovaps [rsp+0x90], xmm9
000076bac53d7313  vmovaps [rsp+0xA0], xmm10
000076bac53d731c  vmovaps [rsp+0xB0], xmm11
000076bac53d7325  vmovaps [rsp+0xC0], xmm12
000076bac53d732e  vmovaps [rsp+0xD0], xmm13
000076bac53d7337  vmovaps [rsp+0xE0], xmm14
000076bac53d7340  sub rsp, 0x30
000076bac53d7344  movaps [rsp], xmm15
000076bac53d7349  movaps [rsp+0x10], xmm14
000076bac53d734f  movaps [rsp+0x20], xmm9
000076bac53d7355  lea rdi, [rsp]
000076bac53d7359  mov esi, 0x00
000076bac53d735e  mov rax, 0x5641B0A3C530
000076bac53d7368  call rax
000076bac53d736a  movaps xmm15, [rsp]
000076bac53d736f  add rsp, 0x30
000076bac53d7373  vmovaps xmm0, [rsp]
000076bac53d7378  vmovaps xmm1, [rsp+0x10]
000076bac53d737e  vmovaps xmm2, [rsp+0x20]
000076bac53d7384  vmovaps xmm3, [rsp+0x30]
000076bac53d738a  vmovaps xmm4, [rsp+0x40]
000076bac53d7390  vmovaps xmm5, [rsp+0x50]
000076bac53d7396  vmovaps xmm6, [rsp+0x60]
000076bac53d739c  vmovaps xmm7, [rsp+0x70]
000076bac53d73a2  vmovaps xmm8, [rsp+0x80]
000076bac53d73ab  vmovaps xmm9, [rsp+0x90]
000076bac53d73b4  vmovaps xmm10, [rsp+0xA0]
000076bac53d73bd  vmovaps xmm11, [rsp+0xB0]
000076bac53d73c6  vmovaps xmm12, [rsp+0xC0]
000076bac53d73cf  vmovaps xmm13, [rsp+0xD0]
000076bac53d73d8  vmovaps xmm14, [rsp+0xE0]
000076bac53d73e1  add rsp, 0xF0
000076bac53d73e8  pop r11
000076bac53d73ea  pop r10
000076bac53d73ec  pop r9
000076bac53d73ee  pop r8
000076bac53d73f0  pop rsi
000076bac53d73f1  pop rdi
000076bac53d73f2  pop rdx
000076bac53d73f3  pop rcx
000076bac53d73f4  pop rax
000076bac53d73f5  add rsp, 0x08
000076bac53d73f9  jmp 0x000076BAC53D32E9
000076bac53d73fe  sub rsp, 0x08
000076bac53d7402  push rax
000076bac53d7403  push rcx
000076bac53d7404  push rdx
000076bac53d7405  push rdi
000076bac53d7406  push rsi
000076bac53d7407  push r8
000076bac53d7409  push r9
000076bac53d740b  push r10
000076bac53d740d  push r11
000076bac53d740f  sub rsp, 0xF0
000076bac53d7416  vmovaps [rsp], xmm0
000076bac53d741b  vmovaps [rsp+0x10], xmm1
000076bac53d7421  vmovaps [rsp+0x20], xmm2
000076bac53d7427  vmovaps [rsp+0x30], xmm3
000076bac53d742d  vmovaps [rsp+0x40], xmm4
000076bac53d7433  vmovaps [rsp+0x50], xmm5
000076bac53d7439  vmovaps [rsp+0x60], xmm6
000076bac53d743f  vmovaps [rsp+0x70], xmm7
000076bac53d7445  vmovaps [rsp+0x80], xmm8
000076bac53d744e  vmovaps [rsp+0x90], xmm10
000076bac53d7457  vmovaps [rsp+0xA0], xmm11
000076bac53d7460  vmovaps [rsp+0xB0], xmm12
000076bac53d7469  vmovaps [rsp+0xC0], xmm13
000076bac53d7472  vmovaps [rsp+0xD0], xmm14
000076bac53d747b  vmovaps [rsp+0xE0], xmm15
000076bac53d7484  sub rsp, 0x30
000076bac53d7488  movaps [rsp], xmm9
000076bac53d748d  movaps [rsp+0x10], xmm7
000076bac53d7492  movaps [rsp+0x20], xmm14
000076bac53d7498  lea rdi, [rsp]
000076bac53d749c  mov esi, 0x00
000076bac53d74a1  mov rax, 0x5641B0A3C530
000076bac53d74ab  call rax
000076bac53d74ad  movaps xmm9, [rsp]
000076bac53d74b2  add rsp, 0x30
000076bac53d74b6  vmovaps xmm0, [rsp]
000076bac53d74bb  vmovaps xmm1, [rsp+0x10]
000076bac53d74c1  vmovaps xmm2, [rsp+0x20]
000076bac53d74c7  vmovaps xmm3, [rsp+0x30]
000076bac53d74cd  vmovaps xmm4, [rsp+0x40]
000076bac53d74d3  vmovaps xmm5, [rsp+0x50]
000076bac53d74d9  vmovaps xmm6, [rsp+0x60]
000076bac53d74df  vmovaps xmm7, [rsp+0x70]
000076bac53d74e5  vmovaps xmm8, [rsp+0x80]
000076bac53d74ee  vmovaps xmm10, [rsp+0x90]
000076bac53d74f7  vmovaps xmm11, [rsp+0xA0]
000076bac53d7500  vmovaps xmm12, [rsp+0xB0]
000076bac53d7509  vmovaps xmm13, [rsp+0xC0]
000076bac53d7512  vmovaps xmm14, [rsp+0xD0]
000076bac53d751b  vmovaps xmm15, [rsp+0xE0]
000076bac53d7524  add rsp, 0xF0
000076bac53d752b  pop r11
000076bac53d752d  pop r10
000076bac53d752f  pop r9
000076bac53d7531  pop r8
000076bac53d7533  pop rsi
000076bac53d7534  pop rdi
000076bac53d7535  pop rdx
000076bac53d7536  pop rcx
000076bac53d7537  pop rax
000076bac53d7538  add rsp, 0x08
000076bac53d753c  jmp 0x000076BAC53D3318
000076bac53d7541  sub rsp, 0x08
000076bac53d7545  push rax
000076bac53d7546  push rcx
000076bac53d7547  push rdx
000076bac53d7548  push rdi
000076bac53d7549  push rsi
000076bac53d754a  push r8
000076bac53d754c  push r9
000076bac53d754e  push r10
000076bac53d7550  push r11
000076bac53d7552  sub rsp, 0xF0
000076bac53d7559  vmovaps [rsp], xmm0
000076bac53d755e  vmovaps [rsp+0x10], xmm1
000076bac53d7564  vmovaps [rsp+0x20], xmm2
000076bac53d756a  vmovaps [rsp+0x30], xmm3
000076bac53d7570  vmovaps [rsp+0x40], xmm4
000076bac53d7576  vmovaps [rsp+0x50], xmm5
000076bac53d757c  vmovaps [rsp+0x60], xmm6
000076bac53d7582  vmovaps [rsp+0x70], xmm7
000076bac53d7588  vmovaps [rsp+0x80], xmm8
000076bac53d7591  vmovaps [rsp+0x90], xmm9
000076bac53d759a  vmovaps [rsp+0xA0], xmm10
000076bac53d75a3  vmovaps [rsp+0xB0], xmm11
000076bac53d75ac  vmovaps [rsp+0xC0], xmm12
000076bac53d75b5  vmovaps [rsp+0xD0], xmm13
000076bac53d75be  vmovaps [rsp+0xE0], xmm15
000076bac53d75c7  sub rsp, 0x30
000076bac53d75cb  movaps [rsp], xmm14
000076bac53d75d0  movaps [rsp+0x10], xmm13
000076bac53d75d6  movaps [rsp+0x20], xmm11
000076bac53d75dc  lea rdi, [rsp]
000076bac53d75e0  mov esi, 0x00
000076bac53d75e5  mov rax, 0x5641B0A3C530
000076bac53d75ef  call rax
000076bac53d75f1  movaps xmm14, [rsp]
000076bac53d75f6  add rsp, 0x30
000076bac53d75fa  vmovaps xmm0, [rsp]
000076bac53d75ff  vmovaps xmm1, [rsp+0x10]
000076bac53d7605  vmovaps xmm2, [rsp+0x20]
000076bac53d760b  vmovaps xmm3, [rsp+0x30]
000076bac53d7611  vmovaps xmm4, [rsp+0x40]
000076bac53d7617  vmovaps xmm5, [rsp+0x50]
000076bac53d761d  vmovaps xmm6, [rsp+0x60]
000076bac53d7623  vmovaps xmm7, [rsp+0x70]
000076bac53d7629  vmovaps xmm8, [rsp+0x80]
000076bac53d7632  vmovaps xmm9, [rsp+0x90]
000076bac53d763b  vmovaps xmm10, [rsp+0xA0]
000076bac53d7644  vmovaps xmm11, [rsp+0xB0]
000076bac53d764d  vmovaps xmm12, [rsp+0xC0]
000076bac53d7656  vmovaps xmm13, [rsp+0xD0]
000076bac53d765f  vmovaps xmm15, [rsp+0xE0]
000076bac53d7668  add rsp, 0xF0
000076bac53d766f  pop r11
000076bac53d7671  pop r10
000076bac53d7673  pop r9
000076bac53d7675  pop r8
000076bac53d7677  pop rsi
000076bac53d7678  pop rdi
000076bac53d7679  pop rdx
000076bac53d767a  pop rcx
000076bac53d767b  pop rax
000076bac53d767c  add rsp, 0x08
000076bac53d7680  jmp 0x000076BAC53D3332
000076bac53d7685  sub rsp, 0x08
000076bac53d7689  push rax
000076bac53d768a  push rcx
000076bac53d768b  push rdx
000076bac53d768c  push rdi
000076bac53d768d  push rsi
000076bac53d768e  push r8
000076bac53d7690  push r9
000076bac53d7692  push r10
000076bac53d7694  push r11
000076bac53d7696  sub rsp, 0xF0
000076bac53d769d  vmovaps [rsp], xmm0
000076bac53d76a2  vmovaps [rsp+0x10], xmm1
000076bac53d76a8  vmovaps [rsp+0x20], xmm2
000076bac53d76ae  vmovaps [rsp+0x30], xmm3
000076bac53d76b4  vmovaps [rsp+0x40], xmm4
000076bac53d76ba  vmovaps [rsp+0x50], xmm5
000076bac53d76c0  vmovaps [rsp+0x60], xmm6
000076bac53d76c6  vmovaps [rsp+0x70], xmm7
000076bac53d76cc  vmovaps [rsp+0x80], xmm8
000076bac53d76d5  vmovaps [rsp+0x90], xmm9
000076bac53d76de  vmovaps [rsp+0xA0], xmm10
000076bac53d76e7  vmovaps [rsp+0xB0], xmm12
000076bac53d76f0  vmovaps [rsp+0xC0], xmm13
000076bac53d76f9  vmovaps [rsp+0xD0], xmm14
000076bac53d7702  vmovaps [rsp+0xE0], xmm15
000076bac53d770b  sub rsp, 0x30
000076bac53d770f  movaps [rsp], xmm11
000076bac53d7714  movaps [rsp+0x10], xmm7
000076bac53d7719  movaps [rsp+0x20], xmm13
000076bac53d771f  lea rdi, [rsp]
000076bac53d7723  mov esi, 0x00
000076bac53d7728  mov rax, 0x5641B0A3C530
000076bac53d7732  call rax
000076bac53d7734  movaps xmm11, [rsp]
000076bac53d7739  add rsp, 0x30
000076bac53d773d  vmovaps xmm0, [rsp]
000076bac53d7742  vmovaps xmm1, [rsp+0x10]
000076bac53d7748  vmovaps xmm2, [rsp+0x20]
000076bac53d774e  vmovaps xmm3, [rsp+0x30]
000076bac53d7754  vmovaps xmm4, [rsp+0x40]
000076bac53d775a  vmovaps xmm5, [rsp+0x50]
000076bac53d7760  vmovaps xmm6, [rsp+0x60]
000076bac53d7766  vmovaps xmm7, [rsp+0x70]
000076bac53d776c  vmovaps xmm8, [rsp+0x80]
000076bac53d7775  vmovaps xmm9, [rsp+0x90]
000076bac53d777e  vmovaps xmm10, [rsp+0xA0]
000076bac53d7787  vmovaps xmm12, [rsp+0xB0]
000076bac53d7790  vmovaps xmm13, [rsp+0xC0]
000076bac53d7799  vmovaps xmm14, [rsp+0xD0]
000076bac53d77a2  vmovaps xmm15, [rsp+0xE0]
000076bac53d77ab  add rsp, 0xF0
000076bac53d77b2  pop r11
000076bac53d77b4  pop r10
000076bac53d77b6  pop r9
000076bac53d77b8  pop r8
000076bac53d77ba  pop rsi
000076bac53d77bb  pop rdi
000076bac53d77bc  pop rdx
000076bac53d77bd  pop rcx
000076bac53d77be  pop rax
000076bac53d77bf  add rsp, 0x08
000076bac53d77c3  jmp 0x000076BAC53D335E
000076bac53d77c8  sub rsp, 0x08
000076bac53d77cc  push rax
000076bac53d77cd  push rcx
000076bac53d77ce  push rdx
000076bac53d77cf  push rdi
000076bac53d77d0  push rsi
000076bac53d77d1  push r8
000076bac53d77d3  push r9
000076bac53d77d5  push r10
000076bac53d77d7  push r11
000076bac53d77d9  sub rsp, 0xF0
000076bac53d77e0  vmovaps [rsp], xmm0
000076bac53d77e5  vmovaps [rsp+0x10], xmm1
000076bac53d77eb  vmovaps [rsp+0x20], xmm2
000076bac53d77f1  vmovaps [rsp+0x30], xmm3
000076bac53d77f7  vmovaps [rsp+0x40], xmm4
000076bac53d77fd  vmovaps [rsp+0x50], xmm5
000076bac53d7803  vmovaps [rsp+0x60], xmm6
000076bac53d7809  vmovaps [rsp+0x70], xmm7
000076bac53d780f  vmovaps [rsp+0x80], xmm8
000076bac53d7818  vmovaps [rsp+0x90], xmm9
000076bac53d7821  vmovaps [rsp+0xA0], xmm10
000076bac53d782a  vmovaps [rsp+0xB0], xmm11
000076bac53d7833  vmovaps [rsp+0xC0], xmm12
000076bac53d783c  vmovaps [rsp+0xD0], xmm14
000076bac53d7845  vmovaps [rsp+0xE0], xmm15
000076bac53d784e  sub rsp, 0x30
000076bac53d7852  movaps [rsp], xmm13
000076bac53d7857  movaps [rsp+0x10], xmm10
000076bac53d785d  movaps [rsp+0x20], xmm12
000076bac53d7863  lea rdi, [rsp]
000076bac53d7867  mov esi, 0x00
000076bac53d786c  mov rax, 0x5641B0A3C530
000076bac53d7876  call rax
000076bac53d7878  movaps xmm13, [rsp]
000076bac53d787d  add rsp, 0x30
000076bac53d7881  vmovaps xmm0, [rsp]
000076bac53d7886  vmovaps xmm1, [rsp+0x10]
000076bac53d788c  vmovaps xmm2, [rsp+0x20]
000076bac53d7892  vmovaps xmm3, [rsp+0x30]
000076bac53d7898  vmovaps xmm4, [rsp+0x40]
000076bac53d789e  vmovaps xmm5, [rsp+0x50]
000076bac53d78a4  vmovaps xmm6, [rsp+0x60]
000076bac53d78aa  vmovaps xmm7, [rsp+0x70]
000076bac53d78b0  vmovaps xmm8, [rsp+0x80]
000076bac53d78b9  vmovaps xmm9, [rsp+0x90]
000076bac53d78c2  vmovaps xmm10, [rsp+0xA0]
000076bac53d78cb  vmovaps xmm11, [rsp+0xB0]
000076bac53d78d4  vmovaps xmm12, [rsp+0xC0]
000076bac53d78dd  vmovaps xmm14, [rsp+0xD0]
000076bac53d78e6  vmovaps xmm15, [rsp+0xE0]
000076bac53d78ef  add rsp, 0xF0
000076bac53d78f6  pop r11
000076bac53d78f8  pop r10
000076bac53d78fa  pop r9
000076bac53d78fc  pop r8
000076bac53d78fe  pop rsi
000076bac53d78ff  pop rdi
000076bac53d7900  pop rdx
000076bac53d7901  pop rcx
000076bac53d7902  pop rax
000076bac53d7903  add rsp, 0x08
000076bac53d7907  jmp 0x000076BAC53D3378
000076bac53d790c  sub rsp, 0x08
000076bac53d7910  push rax
000076bac53d7911  push rcx
000076bac53d7912  push rdx
000076bac53d7913  push rdi
000076bac53d7914  push rsi
000076bac53d7915  push r8
000076bac53d7917  push r9
000076bac53d7919  push r10
000076bac53d791b  push r11
000076bac53d791d  sub rsp, 0xF0
000076bac53d7924  vmovaps [rsp], xmm0
000076bac53d7929  vmovaps [rsp+0x10], xmm1
000076bac53d792f  vmovaps [rsp+0x20], xmm2
000076bac53d7935  vmovaps [rsp+0x30], xmm3
000076bac53d793b  vmovaps [rsp+0x40], xmm4
000076bac53d7941  vmovaps [rsp+0x50], xmm5
000076bac53d7947  vmovaps [rsp+0x60], xmm6
000076bac53d794d  vmovaps [rsp+0x70], xmm7
000076bac53d7953  vmovaps [rsp+0x80], xmm8
000076bac53d795c  vmovaps [rsp+0x90], xmm9
000076bac53d7965  vmovaps [rsp+0xA0], xmm11
000076bac53d796e  vmovaps [rsp+0xB0], xmm12
000076bac53d7977  vmovaps [rsp+0xC0], xmm13
000076bac53d7980  vmovaps [rsp+0xD0], xmm14
000076bac53d7989  vmovaps [rsp+0xE0], xmm15
000076bac53d7992  sub rsp, 0x30
000076bac53d7996  movaps [rsp], xmm10
000076bac53d799b  movaps [rsp+0x10], xmm7
000076bac53d79a0  movaps [rsp+0x20], xmm12
000076bac53d79a6  lea rdi, [rsp]
000076bac53d79aa  mov esi, 0x00
000076bac53d79af  mov rax, 0x5641B0A3C530
000076bac53d79b9  call rax
000076bac53d79bb  movaps xmm10, [rsp]
000076bac53d79c0  add rsp, 0x30
000076bac53d79c4  vmovaps xmm0, [rsp]
000076bac53d79c9  vmovaps xmm1, [rsp+0x10]
000076bac53d79cf  vmovaps xmm2, [rsp+0x20]
000076bac53d79d5  vmovaps xmm3, [rsp+0x30]
000076bac53d79db  vmovaps xmm4, [rsp+0x40]
000076bac53d79e1  vmovaps xmm5, [rsp+0x50]
000076bac53d79e7  vmovaps xmm6, [rsp+0x60]
000076bac53d79ed  vmovaps xmm7, [rsp+0x70]
000076bac53d79f3  vmovaps xmm8, [rsp+0x80]
000076bac53d79fc  vmovaps xmm9, [rsp+0x90]
000076bac53d7a05  vmovaps xmm11, [rsp+0xA0]
000076bac53d7a0e  vmovaps xmm12, [rsp+0xB0]
000076bac53d7a17  vmovaps xmm13, [rsp+0xC0]
000076bac53d7a20  vmovaps xmm14, [rsp+0xD0]
000076bac53d7a29  vmovaps xmm15, [rsp+0xE0]
000076bac53d7a32  add rsp, 0xF0
000076bac53d7a39  pop r11
000076bac53d7a3b  pop r10
000076bac53d7a3d  pop r9
000076bac53d7a3f  pop r8
000076bac53d7a41  pop rsi
000076bac53d7a42  pop rdi
000076bac53d7a43  pop rdx
000076bac53d7a44  pop rcx
000076bac53d7a45  pop rax
000076bac53d7a46  add rsp, 0x08
000076bac53d7a4a  jmp 0x000076BAC53D33A4
000076bac53d7a4f  sub rsp, 0x08
000076bac53d7a53  push rax
000076bac53d7a54  push rcx
000076bac53d7a55  push rdx
000076bac53d7a56  push rdi
000076bac53d7a57  push rsi
000076bac53d7a58  push r8
000076bac53d7a5a  push r9
000076bac53d7a5c  push r10
000076bac53d7a5e  push r11
000076bac53d7a60  sub rsp, 0xF0
000076bac53d7a67  vmovaps [rsp], xmm0
000076bac53d7a6c  vmovaps [rsp+0x10], xmm1
000076bac53d7a72  vmovaps [rsp+0x20], xmm2
000076bac53d7a78  vmovaps [rsp+0x30], xmm3
000076bac53d7a7e  vmovaps [rsp+0x40], xmm4
000076bac53d7a84  vmovaps [rsp+0x50], xmm5
000076bac53d7a8a  vmovaps [rsp+0x60], xmm6
000076bac53d7a90  vmovaps [rsp+0x70], xmm7
000076bac53d7a96  vmovaps [rsp+0x80], xmm8
000076bac53d7a9f  vmovaps [rsp+0x90], xmm9
000076bac53d7aa8  vmovaps [rsp+0xA0], xmm10
000076bac53d7ab1  vmovaps [rsp+0xB0], xmm11
000076bac53d7aba  vmovaps [rsp+0xC0], xmm13
000076bac53d7ac3  vmovaps [rsp+0xD0], xmm14
000076bac53d7acc  vmovaps [rsp+0xE0], xmm15
000076bac53d7ad5  sub rsp, 0x30
000076bac53d7ad9  movaps [rsp], xmm12
000076bac53d7ade  movaps [rsp+0x10], xmm1
000076bac53d7ae3  movaps [rsp+0x20], xmm8
000076bac53d7ae9  lea rdi, [rsp]
000076bac53d7aed  mov esi, 0x00
000076bac53d7af2  mov rax, 0x5641B0A3C530
000076bac53d7afc  call rax
000076bac53d7afe  movaps xmm12, [rsp]
000076bac53d7b03  add rsp, 0x30
000076bac53d7b07  vmovaps xmm0, [rsp]
000076bac53d7b0c  vmovaps xmm1, [rsp+0x10]
000076bac53d7b12  vmovaps xmm2, [rsp+0x20]
000076bac53d7b18  vmovaps xmm3, [rsp+0x30]
000076bac53d7b1e  vmovaps xmm4, [rsp+0x40]
000076bac53d7b24  vmovaps xmm5, [rsp+0x50]
000076bac53d7b2a  vmovaps xmm6, [rsp+0x60]
000076bac53d7b30  vmovaps xmm7, [rsp+0x70]
000076bac53d7b36  vmovaps xmm8, [rsp+0x80]
000076bac53d7b3f  vmovaps xmm9, [rsp+0x90]
000076bac53d7b48  vmovaps xmm10, [rsp+0xA0]
000076bac53d7b51  vmovaps xmm11, [rsp+0xB0]
000076bac53d7b5a  vmovaps xmm13, [rsp+0xC0]
000076bac53d7b63  vmovaps xmm14, [rsp+0xD0]
000076bac53d7b6c  vmovaps xmm15, [rsp+0xE0]
000076bac53d7b75  add rsp, 0xF0
000076bac53d7b7c  pop r11
000076bac53d7b7e  pop r10
000076bac53d7b80  pop r9
000076bac53d7b82  pop r8
000076bac53d7b84  pop rsi
000076bac53d7b85  pop rdi
000076bac53d7b86  pop rdx
000076bac53d7b87  pop rcx
000076bac53d7b88  pop rax
000076bac53d7b89  add rsp, 0x08
000076bac53d7b8d  jmp 0x000076BAC53D33BE
000076bac53d7b92  call 0x000076BAC51FF430
000076bac53d7b97  jmp 0x000076BAC53D33C8
000076bac53d7b9c  sub rsp, 0x08
000076bac53d7ba0  push rax
000076bac53d7ba1  push rcx
000076bac53d7ba2  push rdx
000076bac53d7ba3  push rdi
000076bac53d7ba4  push rsi
000076bac53d7ba5  push r8
000076bac53d7ba7  push r9
000076bac53d7ba9  push r10
000076bac53d7bab  push r11
000076bac53d7bad  sub rsp, 0xF0
000076bac53d7bb4  vmovaps [rsp], xmm0
000076bac53d7bb9  vmovaps [rsp+0x10], xmm1
000076bac53d7bbf  vmovaps [rsp+0x20], xmm2
000076bac53d7bc5  vmovaps [rsp+0x30], xmm3
000076bac53d7bcb  vmovaps [rsp+0x40], xmm4
000076bac53d7bd1  vmovaps [rsp+0x50], xmm5
000076bac53d7bd7  vmovaps [rsp+0x60], xmm6
000076bac53d7bdd  vmovaps [rsp+0x70], xmm7
000076bac53d7be3  vmovaps [rsp+0x80], xmm9
000076bac53d7bec  vmovaps [rsp+0x90], xmm10
000076bac53d7bf5  vmovaps [rsp+0xA0], xmm11
000076bac53d7bfe  vmovaps [rsp+0xB0], xmm12
000076bac53d7c07  vmovaps [rsp+0xC0], xmm13
000076bac53d7c10  vmovaps [rsp+0xD0], xmm14
000076bac53d7c19  vmovaps [rsp+0xE0], xmm15
000076bac53d7c22  sub rsp, 0x30
000076bac53d7c26  movaps [rsp], xmm8
000076bac53d7c2b  movaps [rsp+0x10], xmm15
000076bac53d7c31  movaps [rsp+0x20], xmm9
000076bac53d7c37  lea rdi, [rsp]
000076bac53d7c3b  mov esi, 0x00
000076bac53d7c40  mov rax, 0x5641B0A3C530
000076bac53d7c4a  call rax
000076bac53d7c4c  movaps xmm8, [rsp]
000076bac53d7c51  add rsp, 0x30
000076bac53d7c55  vmovaps xmm0, [rsp]
000076bac53d7c5a  vmovaps xmm1, [rsp+0x10]
000076bac53d7c60  vmovaps xmm2, [rsp+0x20]
000076bac53d7c66  vmovaps xmm3, [rsp+0x30]
000076bac53d7c6c  vmovaps xmm4, [rsp+0x40]
000076bac53d7c72  vmovaps xmm5, [rsp+0x50]
000076bac53d7c78  vmovaps xmm6, [rsp+0x60]
000076bac53d7c7e  vmovaps xmm7, [rsp+0x70]
000076bac53d7c84  vmovaps xmm9, [rsp+0x80]
000076bac53d7c8d  vmovaps xmm10, [rsp+0x90]
000076bac53d7c96  vmovaps xmm11, [rsp+0xA0]
000076bac53d7c9f  vmovaps xmm12, [rsp+0xB0]
000076bac53d7ca8  vmovaps xmm13, [rsp+0xC0]
000076bac53d7cb1  vmovaps xmm14, [rsp+0xD0]
000076bac53d7cba  vmovaps xmm15, [rsp+0xE0]
000076bac53d7cc3  add rsp, 0xF0
000076bac53d7cca  pop r11
000076bac53d7ccc  pop r10
000076bac53d7cce  pop r9
000076bac53d7cd0  pop r8
000076bac53d7cd2  pop rsi
000076bac53d7cd3  pop rdi
000076bac53d7cd4  pop rdx
000076bac53d7cd5  pop rcx
000076bac53d7cd6  pop rax
000076bac53d7cd7  add rsp, 0x08
000076bac53d7cdb  jmp 0x000076BAC53D33EA
000076bac53d7ce0  sub rsp, 0x08
000076bac53d7ce4  push rax
000076bac53d7ce5  push rcx
000076bac53d7ce6  push rdx
000076bac53d7ce7  push rdi
000076bac53d7ce8  push rsi
000076bac53d7ce9  push r8
000076bac53d7ceb  push r9
000076bac53d7ced  push r10
000076bac53d7cef  push r11
000076bac53d7cf1  sub rsp, 0xF0
000076bac53d7cf8  vmovaps [rsp], xmm0
000076bac53d7cfd  vmovaps [rsp+0x10], xmm1
000076bac53d7d03  vmovaps [rsp+0x20], xmm2
000076bac53d7d09  vmovaps [rsp+0x30], xmm3
000076bac53d7d0f  vmovaps [rsp+0x40], xmm4
000076bac53d7d15  vmovaps [rsp+0x50], xmm5
000076bac53d7d1b  vmovaps [rsp+0x60], xmm6
000076bac53d7d21  vmovaps [rsp+0x70], xmm7
000076bac53d7d27  vmovaps [rsp+0x80], xmm8
000076bac53d7d30  vmovaps [rsp+0x90], xmm10
000076bac53d7d39  vmovaps [rsp+0xA0], xmm11
000076bac53d7d42  vmovaps [rsp+0xB0], xmm12
000076bac53d7d4b  vmovaps [rsp+0xC0], xmm13
000076bac53d7d54  vmovaps [rsp+0xD0], xmm14
000076bac53d7d5d  vmovaps [rsp+0xE0], xmm15
000076bac53d7d66  sub rsp, 0x30
000076bac53d7d6a  movaps [rsp], xmm9
000076bac53d7d6f  movaps [rsp+0x10], xmm1
000076bac53d7d74  movaps [rsp+0x20], xmm15
000076bac53d7d7a  lea rdi, [rsp]
000076bac53d7d7e  mov esi, 0x00
000076bac53d7d83  mov rax, 0x5641B0A3C530
000076bac53d7d8d  call rax
000076bac53d7d8f  movaps xmm9, [rsp]
000076bac53d7d94  add rsp, 0x30
000076bac53d7d98  vmovaps xmm0, [rsp]
000076bac53d7d9d  vmovaps xmm1, [rsp+0x10]
000076bac53d7da3  vmovaps xmm2, [rsp+0x20]
000076bac53d7da9  vmovaps xmm3, [rsp+0x30]
000076bac53d7daf  vmovaps xmm4, [rsp+0x40]
000076bac53d7db5  vmovaps xmm5, [rsp+0x50]
000076bac53d7dbb  vmovaps xmm6, [rsp+0x60]
000076bac53d7dc1  vmovaps xmm7, [rsp+0x70]
000076bac53d7dc7  vmovaps xmm8, [rsp+0x80]
000076bac53d7dd0  vmovaps xmm10, [rsp+0x90]
000076bac53d7dd9  vmovaps xmm11, [rsp+0xA0]
000076bac53d7de2  vmovaps xmm12, [rsp+0xB0]
000076bac53d7deb  vmovaps xmm13, [rsp+0xC0]
000076bac53d7df4  vmovaps xmm14, [rsp+0xD0]
000076bac53d7dfd  vmovaps xmm15, [rsp+0xE0]
000076bac53d7e06  add rsp, 0xF0
000076bac53d7e0d  pop r11
000076bac53d7e0f  pop r10
000076bac53d7e11  pop r9
000076bac53d7e13  pop r8
000076bac53d7e15  pop rsi
000076bac53d7e16  pop rdi
000076bac53d7e17  pop rdx
000076bac53d7e18  pop rcx
000076bac53d7e19  pop rax
000076bac53d7e1a  add rsp, 0x08
000076bac53d7e1e  jmp 0x000076BAC53D3418
000076bac53d7e23  sub rsp, 0x08
000076bac53d7e27  push rax
000076bac53d7e28  push rcx
000076bac53d7e29  push rdx
000076bac53d7e2a  push rdi
000076bac53d7e2b  push rsi
000076bac53d7e2c  push r8
000076bac53d7e2e  push r9
000076bac53d7e30  push r10
000076bac53d7e32  push r11
000076bac53d7e34  sub rsp, 0xF0
000076bac53d7e3b  vmovaps [rsp], xmm0
000076bac53d7e40  vmovaps [rsp+0x10], xmm1
000076bac53d7e46  vmovaps [rsp+0x20], xmm2
000076bac53d7e4c  vmovaps [rsp+0x30], xmm3
000076bac53d7e52  vmovaps [rsp+0x40], xmm4
000076bac53d7e58  vmovaps [rsp+0x50], xmm5
000076bac53d7e5e  vmovaps [rsp+0x60], xmm6
000076bac53d7e64  vmovaps [rsp+0x70], xmm7
000076bac53d7e6a  vmovaps [rsp+0x80], xmm8
000076bac53d7e73  vmovaps [rsp+0x90], xmm9
000076bac53d7e7c  vmovaps [rsp+0xA0], xmm10
000076bac53d7e85  vmovaps [rsp+0xB0], xmm11
000076bac53d7e8e  vmovaps [rsp+0xC0], xmm12
000076bac53d7e97  vmovaps [rsp+0xD0], xmm13
000076bac53d7ea0  vmovaps [rsp+0xE0], xmm14
000076bac53d7ea9  sub rsp, 0x30
000076bac53d7ead  movaps [rsp], xmm15
000076bac53d7eb2  movaps [rsp+0x10], xmm4
000076bac53d7eb7  movaps [rsp+0x20], xmm1
000076bac53d7ebc  lea rdi, [rsp]
000076bac53d7ec0  mov esi, 0x00
000076bac53d7ec5  mov rax, 0x5641B0A3C530
000076bac53d7ecf  call rax
000076bac53d7ed1  movaps xmm15, [rsp]
000076bac53d7ed6  add rsp, 0x30
000076bac53d7eda  vmovaps xmm0, [rsp]
000076bac53d7edf  vmovaps xmm1, [rsp+0x10]
000076bac53d7ee5  vmovaps xmm2, [rsp+0x20]
000076bac53d7eeb  vmovaps xmm3, [rsp+0x30]
000076bac53d7ef1  vmovaps xmm4, [rsp+0x40]
000076bac53d7ef7  vmovaps xmm5, [rsp+0x50]
000076bac53d7efd  vmovaps xmm6, [rsp+0x60]
000076bac53d7f03  vmovaps xmm7, [rsp+0x70]
000076bac53d7f09  vmovaps xmm8, [rsp+0x80]
000076bac53d7f12  vmovaps xmm9, [rsp+0x90]
000076bac53d7f1b  vmovaps xmm10, [rsp+0xA0]
000076bac53d7f24  vmovaps xmm11, [rsp+0xB0]
000076bac53d7f2d  vmovaps xmm12, [rsp+0xC0]
000076bac53d7f36  vmovaps xmm13, [rsp+0xD0]
000076bac53d7f3f  vmovaps xmm14, [rsp+0xE0]
000076bac53d7f48  add rsp, 0xF0
000076bac53d7f4f  pop r11
000076bac53d7f51  pop r10
000076bac53d7f53  pop r9
000076bac53d7f55  pop r8
000076bac53d7f57  pop rsi
000076bac53d7f58  pop rdi
000076bac53d7f59  pop rdx
000076bac53d7f5a  pop rcx
000076bac53d7f5b  pop rax
000076bac53d7f5c  add rsp, 0x08
000076bac53d7f60  jmp 0x000076BAC53D343E
000076bac53d7f65  sub rsp, 0x08
000076bac53d7f69  push rax
000076bac53d7f6a  push rcx
000076bac53d7f6b  push rdx
000076bac53d7f6c  push rdi
000076bac53d7f6d  push rsi
000076bac53d7f6e  push r8
000076bac53d7f70  push r9
000076bac53d7f72  push r10
000076bac53d7f74  push r11
000076bac53d7f76  sub rsp, 0xF0
000076bac53d7f7d  vmovaps [rsp], xmm0
000076bac53d7f82  vmovaps [rsp+0x10], xmm2
000076bac53d7f88  vmovaps [rsp+0x20], xmm3
000076bac53d7f8e  vmovaps [rsp+0x30], xmm4
000076bac53d7f94  vmovaps [rsp+0x40], xmm5
000076bac53d7f9a  vmovaps [rsp+0x50], xmm6
000076bac53d7fa0  vmovaps [rsp+0x60], xmm7
000076bac53d7fa6  vmovaps [rsp+0x70], xmm8
000076bac53d7fac  vmovaps [rsp+0x80], xmm9
000076bac53d7fb5  vmovaps [rsp+0x90], xmm10
000076bac53d7fbe  vmovaps [rsp+0xA0], xmm11
000076bac53d7fc7  vmovaps [rsp+0xB0], xmm12
000076bac53d7fd0  vmovaps [rsp+0xC0], xmm13
000076bac53d7fd9  vmovaps [rsp+0xD0], xmm14
000076bac53d7fe2  vmovaps [rsp+0xE0], xmm15
000076bac53d7feb  sub rsp, 0x30
000076bac53d7fef  movaps [rsp], xmm1
000076bac53d7ff3  movaps [rsp+0x10], xmm14
000076bac53d7ff9  movaps [rsp+0x20], xmm11
000076bac53d7fff  lea rdi, [rsp]
000076bac53d8003  mov esi, 0x00
000076bac53d8008  mov rax, 0x5641B0A3C530
000076bac53d8012  call rax
000076bac53d8014  movaps xmm1, [rsp]
000076bac53d8018  add rsp, 0x30
000076bac53d801c  vmovaps xmm0, [rsp]
000076bac53d8021  vmovaps xmm2, [rsp+0x10]
000076bac53d8027  vmovaps xmm3, [rsp+0x20]
000076bac53d802d  vmovaps xmm4, [rsp+0x30]
000076bac53d8033  vmovaps xmm5, [rsp+0x40]
000076bac53d8039  vmovaps xmm6, [rsp+0x50]
000076bac53d803f  vmovaps xmm7, [rsp+0x60]
000076bac53d8045  vmovaps xmm8, [rsp+0x70]
000076bac53d804b  vmovaps xmm9, [rsp+0x80]
000076bac53d8054  vmovaps xmm10, [rsp+0x90]
000076bac53d805d  vmovaps xmm11, [rsp+0xA0]
000076bac53d8066  vmovaps xmm12, [rsp+0xB0]
000076bac53d806f  vmovaps xmm13, [rsp+0xC0]
000076bac53d8078  vmovaps xmm14, [rsp+0xD0]
000076bac53d8081  vmovaps xmm15, [rsp+0xE0]
000076bac53d808a  add rsp, 0xF0
000076bac53d8091  pop r11
000076bac53d8093  pop r10
000076bac53d8095  pop r9
000076bac53d8097  pop r8
000076bac53d8099  pop rsi
000076bac53d809a  pop rdi
000076bac53d809b  pop rdx
000076bac53d809c  pop rcx
000076bac53d809d  pop rax
000076bac53d809e  add rsp, 0x08
000076bac53d80a2  jmp 0x000076BAC53D345F
000076bac53d80a7  call 0x000076BAC52E45A0
000076bac53d80ac  jmp 0x000076BAC53D346D
000076bac53d80b1  call 0x000076BAC5209D70
000076bac53d80b6  jmp 0x000076BAC53D3477
000076bac53d80bb  sub rsp, 0x08
000076bac53d80bf  push rax
000076bac53d80c0  push rcx
000076bac53d80c1  push rdx
000076bac53d80c2  push rdi
000076bac53d80c3  push rsi
000076bac53d80c4  push r8
000076bac53d80c6  push r9
000076bac53d80c8  push r10
000076bac53d80ca  push r11
000076bac53d80cc  sub rsp, 0xF0
000076bac53d80d3  vmovaps [rsp], xmm0
000076bac53d80d8  vmovaps [rsp+0x10], xmm1
000076bac53d80de  vmovaps [rsp+0x20], xmm2
000076bac53d80e4  vmovaps [rsp+0x30], xmm3
000076bac53d80ea  vmovaps [rsp+0x40], xmm4
000076bac53d80f0  vmovaps [rsp+0x50], xmm5
000076bac53d80f6  vmovaps [rsp+0x60], xmm6
000076bac53d80fc  vmovaps [rsp+0x70], xmm8
000076bac53d8102  vmovaps [rsp+0x80], xmm9
000076bac53d810b  vmovaps [rsp+0x90], xmm10
000076bac53d8114  vmovaps [rsp+0xA0], xmm11
000076bac53d811d  vmovaps [rsp+0xB0], xmm12
000076bac53d8126  vmovaps [rsp+0xC0], xmm13
000076bac53d812f  vmovaps [rsp+0xD0], xmm14
000076bac53d8138  vmovaps [rsp+0xE0], xmm15
000076bac53d8141  sub rsp, 0x30
000076bac53d8145  movaps [rsp], xmm7
000076bac53d8149  movaps [rsp+0x10], xmm13
000076bac53d814f  movaps [rsp+0x20], xmm10
000076bac53d8155  lea rdi, [rsp]
000076bac53d8159  mov esi, 0x00
000076bac53d815e  mov rax, 0x5641B0A3C530
000076bac53d8168  call rax
000076bac53d816a  movaps xmm7, [rsp]
000076bac53d816e  add rsp, 0x30
000076bac53d8172  vmovaps xmm0, [rsp]
000076bac53d8177  vmovaps xmm1, [rsp+0x10]
000076bac53d817d  vmovaps xmm2, [rsp+0x20]
000076bac53d8183  vmovaps xmm3, [rsp+0x30]
000076bac53d8189  vmovaps xmm4, [rsp+0x40]
000076bac53d818f  vmovaps xmm5, [rsp+0x50]
000076bac53d8195  vmovaps xmm6, [rsp+0x60]
000076bac53d819b  vmovaps xmm8, [rsp+0x70]
000076bac53d81a1  vmovaps xmm9, [rsp+0x80]
000076bac53d81aa  vmovaps xmm10, [rsp+0x90]
000076bac53d81b3  vmovaps xmm11, [rsp+0xA0]
000076bac53d81bc  vmovaps xmm12, [rsp+0xB0]
000076bac53d81c5  vmovaps xmm13, [rsp+0xC0]
000076bac53d81ce  vmovaps xmm14, [rsp+0xD0]
000076bac53d81d7  vmovaps xmm15, [rsp+0xE0]
000076bac53d81e0  add rsp, 0xF0
000076bac53d81e7  pop r11
000076bac53d81e9  pop r10
000076bac53d81eb  pop r9
000076bac53d81ed  pop r8
000076bac53d81ef  pop rsi
000076bac53d81f0  pop rdi
000076bac53d81f1  pop rdx
000076bac53d81f2  pop rcx
000076bac53d81f3  pop rax
000076bac53d81f4  add rsp, 0x08
000076bac53d81f8  jmp 0x000076BAC53D3498
000076bac53d81fd  sub rsp, 0x08
000076bac53d8201  push rax
000076bac53d8202  push rcx
000076bac53d8203  push rdx
000076bac53d8204  push rdi
000076bac53d8205  push rsi
000076bac53d8206  push r8
000076bac53d8208  push r9
000076bac53d820a  push r10
000076bac53d820c  push r11
000076bac53d820e  sub rsp, 0xF0
000076bac53d8215  vmovaps [rsp], xmm0
000076bac53d821a  vmovaps [rsp+0x10], xmm1
000076bac53d8220  vmovaps [rsp+0x20], xmm2
000076bac53d8226  vmovaps [rsp+0x30], xmm3
000076bac53d822c  vmovaps [rsp+0x40], xmm4
000076bac53d8232  vmovaps [rsp+0x50], xmm5
000076bac53d8238  vmovaps [rsp+0x60], xmm6
000076bac53d823e  vmovaps [rsp+0x70], xmm7
000076bac53d8244  vmovaps [rsp+0x80], xmm8
000076bac53d824d  vmovaps [rsp+0x90], xmm9
000076bac53d8256  vmovaps [rsp+0xA0], xmm11
000076bac53d825f  vmovaps [rsp+0xB0], xmm12
000076bac53d8268  vmovaps [rsp+0xC0], xmm13
000076bac53d8271  vmovaps [rsp+0xD0], xmm14
000076bac53d827a  vmovaps [rsp+0xE0], xmm15
000076bac53d8283  sub rsp, 0x30
000076bac53d8287  movaps [rsp], xmm10
000076bac53d828c  movaps [rsp+0x10], xmm11
000076bac53d8292  movaps [rsp+0x20], xmm13
000076bac53d8298  lea rdi, [rsp]
000076bac53d829c  mov esi, 0x00
000076bac53d82a1  mov rax, 0x5641B0A3C530
000076bac53d82ab  call rax
000076bac53d82ad  movaps xmm10, [rsp]
000076bac53d82b2  add rsp, 0x30
000076bac53d82b6  vmovaps xmm0, [rsp]
000076bac53d82bb  vmovaps xmm1, [rsp+0x10]
000076bac53d82c1  vmovaps xmm2, [rsp+0x20]
000076bac53d82c7  vmovaps xmm3, [rsp+0x30]
000076bac53d82cd  vmovaps xmm4, [rsp+0x40]
000076bac53d82d3  vmovaps xmm5, [rsp+0x50]
000076bac53d82d9  vmovaps xmm6, [rsp+0x60]
000076bac53d82df  vmovaps xmm7, [rsp+0x70]
000076bac53d82e5  vmovaps xmm8, [rsp+0x80]
000076bac53d82ee  vmovaps xmm9, [rsp+0x90]
000076bac53d82f7  vmovaps xmm11, [rsp+0xA0]
000076bac53d8300  vmovaps xmm12, [rsp+0xB0]
000076bac53d8309  vmovaps xmm13, [rsp+0xC0]
000076bac53d8312  vmovaps xmm14, [rsp+0xD0]
000076bac53d831b  vmovaps xmm15, [rsp+0xE0]
000076bac53d8324  add rsp, 0xF0
000076bac53d832b  pop r11
000076bac53d832d  pop r10
000076bac53d832f  pop r9
000076bac53d8331  pop r8
000076bac53d8333  pop rsi
000076bac53d8334  pop rdi
000076bac53d8335  pop rdx
000076bac53d8336  pop rcx
000076bac53d8337  pop rax
000076bac53d8338  add rsp, 0x08
000076bac53d833c  jmp 0x000076BAC53D34C6
000076bac53d8341  sub rsp, 0x08
000076bac53d8345  push rax
000076bac53d8346  push rcx
000076bac53d8347  push rdx
000076bac53d8348  push rdi
000076bac53d8349  push rsi
000076bac53d834a  push r8
000076bac53d834c  push r9
000076bac53d834e  push r10
000076bac53d8350  push r11
000076bac53d8352  sub rsp, 0xF0
000076bac53d8359  vmovaps [rsp], xmm0
000076bac53d835e  vmovaps [rsp+0x10], xmm1
000076bac53d8364  vmovaps [rsp+0x20], xmm2
000076bac53d836a  vmovaps [rsp+0x30], xmm3
000076bac53d8370  vmovaps [rsp+0x40], xmm4
000076bac53d8376  vmovaps [rsp+0x50], xmm5
000076bac53d837c  vmovaps [rsp+0x60], xmm6
000076bac53d8382  vmovaps [rsp+0x70], xmm7
000076bac53d8388  vmovaps [rsp+0x80], xmm8
000076bac53d8391  vmovaps [rsp+0x90], xmm9
000076bac53d839a  vmovaps [rsp+0xA0], xmm10
000076bac53d83a3  vmovaps [rsp+0xB0], xmm12
000076bac53d83ac  vmovaps [rsp+0xC0], xmm13
000076bac53d83b5  vmovaps [rsp+0xD0], xmm14
000076bac53d83be  vmovaps [rsp+0xE0], xmm15
000076bac53d83c7  sub rsp, 0x30
000076bac53d83cb  movaps [rsp], xmm11
000076bac53d83d0  movaps [rsp+0x10], xmm14
000076bac53d83d6  movaps [rsp+0x20], xmm13
000076bac53d83dc  lea rdi, [rsp]
000076bac53d83e0  mov esi, 0x00
000076bac53d83e5  mov rax, 0x5641B0A3C530
000076bac53d83ef  call rax
000076bac53d83f1  movaps xmm11, [rsp]
000076bac53d83f6  add rsp, 0x30
000076bac53d83fa  vmovaps xmm0, [rsp]
000076bac53d83ff  vmovaps xmm1, [rsp+0x10]
000076bac53d8405  vmovaps xmm2, [rsp+0x20]
000076bac53d840b  vmovaps xmm3, [rsp+0x30]
000076bac53d8411  vmovaps xmm4, [rsp+0x40]
000076bac53d8417  vmovaps xmm5, [rsp+0x50]
000076bac53d841d  vmovaps xmm6, [rsp+0x60]
000076bac53d8423  vmovaps xmm7, [rsp+0x70]
000076bac53d8429  vmovaps xmm8, [rsp+0x80]
000076bac53d8432  vmovaps xmm9, [rsp+0x90]
000076bac53d843b  vmovaps xmm10, [rsp+0xA0]
000076bac53d8444  vmovaps xmm12, [rsp+0xB0]
000076bac53d844d  vmovaps xmm13, [rsp+0xC0]
000076bac53d8456  vmovaps xmm14, [rsp+0xD0]
000076bac53d845f  vmovaps xmm15, [rsp+0xE0]
000076bac53d8468  add rsp, 0xF0
000076bac53d846f  pop r11
000076bac53d8471  pop r10
000076bac53d8473  pop r9
000076bac53d8475  pop r8
000076bac53d8477  pop rsi
000076bac53d8478  pop rdi
000076bac53d8479  pop rdx
000076bac53d847a  pop rcx
000076bac53d847b  pop rax
000076bac53d847c  add rsp, 0x08
000076bac53d8480  jmp 0x000076BAC53D34F4
000076bac53d8485  sub rsp, 0x08
000076bac53d8489  push rax
000076bac53d848a  push rcx
000076bac53d848b  push rdx
000076bac53d848c  push rdi
000076bac53d848d  push rsi
000076bac53d848e  push r8
000076bac53d8490  push r9
000076bac53d8492  push r10
000076bac53d8494  push r11
000076bac53d8496  sub rsp, 0xF0
000076bac53d849d  vmovaps [rsp], xmm0
000076bac53d84a2  vmovaps [rsp+0x10], xmm1
000076bac53d84a8  vmovaps [rsp+0x20], xmm2
000076bac53d84ae  vmovaps [rsp+0x30], xmm3
000076bac53d84b4  vmovaps [rsp+0x40], xmm4
000076bac53d84ba  vmovaps [rsp+0x50], xmm5
000076bac53d84c0  vmovaps [rsp+0x60], xmm6
000076bac53d84c6  vmovaps [rsp+0x70], xmm7
000076bac53d84cc  vmovaps [rsp+0x80], xmm8
000076bac53d84d5  vmovaps [rsp+0x90], xmm9
000076bac53d84de  vmovaps [rsp+0xA0], xmm10
000076bac53d84e7  vmovaps [rsp+0xB0], xmm11
000076bac53d84f0  vmovaps [rsp+0xC0], xmm12
000076bac53d84f9  vmovaps [rsp+0xD0], xmm13
000076bac53d8502  vmovaps [rsp+0xE0], xmm15
000076bac53d850b  sub rsp, 0x30
000076bac53d850f  movaps [rsp], xmm14
000076bac53d8514  movaps [rsp+0x10], xmm12
000076bac53d851a  movaps [rsp+0x20], xmm9
000076bac53d8520  lea rdi, [rsp]
000076bac53d8524  mov esi, 0x00
000076bac53d8529  mov rax, 0x5641B0A3C530
000076bac53d8533  call rax
000076bac53d8535  movaps xmm14, [rsp]
000076bac53d853a  add rsp, 0x30
000076bac53d853e  vmovaps xmm0, [rsp]
000076bac53d8543  vmovaps xmm1, [rsp+0x10]
000076bac53d8549  vmovaps xmm2, [rsp+0x20]
000076bac53d854f  vmovaps xmm3, [rsp+0x30]
000076bac53d8555  vmovaps xmm4, [rsp+0x40]
000076bac53d855b  vmovaps xmm5, [rsp+0x50]
000076bac53d8561  vmovaps xmm6, [rsp+0x60]
000076bac53d8567  vmovaps xmm7, [rsp+0x70]
000076bac53d856d  vmovaps xmm8, [rsp+0x80]
000076bac53d8576  vmovaps xmm9, [rsp+0x90]
000076bac53d857f  vmovaps xmm10, [rsp+0xA0]
000076bac53d8588  vmovaps xmm11, [rsp+0xB0]
000076bac53d8591  vmovaps xmm12, [rsp+0xC0]
000076bac53d859a  vmovaps xmm13, [rsp+0xD0]
000076bac53d85a3  vmovaps xmm15, [rsp+0xE0]
000076bac53d85ac  add rsp, 0xF0
000076bac53d85b3  pop r11
000076bac53d85b5  pop r10
000076bac53d85b7  pop r9
000076bac53d85b9  pop r8
000076bac53d85bb  pop rsi
000076bac53d85bc  pop rdi
000076bac53d85bd  pop rdx
000076bac53d85be  pop rcx
000076bac53d85bf  pop rax
000076bac53d85c0  add rsp, 0x08
000076bac53d85c4  jmp 0x000076BAC53D350F
000076bac53d85c9  sub rsp, 0x08
000076bac53d85cd  push rax
000076bac53d85ce  push rcx
000076bac53d85cf  push rdx
000076bac53d85d0  push rdi
000076bac53d85d1  push rsi
000076bac53d85d2  push r8
000076bac53d85d4  push r9
000076bac53d85d6  push r10
000076bac53d85d8  push r11
000076bac53d85da  sub rsp, 0xF0
000076bac53d85e1  vmovaps [rsp], xmm0
000076bac53d85e6  vmovaps [rsp+0x10], xmm1
000076bac53d85ec  vmovaps [rsp+0x20], xmm2
000076bac53d85f2  vmovaps [rsp+0x30], xmm3
000076bac53d85f8  vmovaps [rsp+0x40], xmm4
000076bac53d85fe  vmovaps [rsp+0x50], xmm5
000076bac53d8604  vmovaps [rsp+0x60], xmm6
000076bac53d860a  vmovaps [rsp+0x70], xmm7
000076bac53d8610  vmovaps [rsp+0x80], xmm8
000076bac53d8619  vmovaps [rsp+0x90], xmm9
000076bac53d8622  vmovaps [rsp+0xA0], xmm10
000076bac53d862b  vmovaps [rsp+0xB0], xmm11
000076bac53d8634  vmovaps [rsp+0xC0], xmm12
000076bac53d863d  vmovaps [rsp+0xD0], xmm14
000076bac53d8646  vmovaps [rsp+0xE0], xmm15
000076bac53d864f  sub rsp, 0x30
000076bac53d8653  movaps [rsp], xmm13
000076bac53d8658  movaps [rsp+0x10], xmm8
000076bac53d865e  movaps [rsp+0x20], xmm15
000076bac53d8664  lea rdi, [rsp]
000076bac53d8668  mov esi, 0x00
000076bac53d866d  mov rax, 0x5641B0A3C530
000076bac53d8677  call rax
000076bac53d8679  movaps xmm13, [rsp]
000076bac53d867e  add rsp, 0x30
000076bac53d8682  vmovaps xmm0, [rsp]
000076bac53d8687  vmovaps xmm1, [rsp+0x10]
000076bac53d868d  vmovaps xmm2, [rsp+0x20]
000076bac53d8693  vmovaps xmm3, [rsp+0x30]
000076bac53d8699  vmovaps xmm4, [rsp+0x40]
000076bac53d869f  vmovaps xmm5, [rsp+0x50]
000076bac53d86a5  vmovaps xmm6, [rsp+0x60]
000076bac53d86ab  vmovaps xmm7, [rsp+0x70]
000076bac53d86b1  vmovaps xmm8, [rsp+0x80]
000076bac53d86ba  vmovaps xmm9, [rsp+0x90]
000076bac53d86c3  vmovaps xmm10, [rsp+0xA0]
000076bac53d86cc  vmovaps xmm11, [rsp+0xB0]
000076bac53d86d5  vmovaps xmm12, [rsp+0xC0]
000076bac53d86de  vmovaps xmm14, [rsp+0xD0]
000076bac53d86e7  vmovaps xmm15, [rsp+0xE0]
000076bac53d86f0  add rsp, 0xF0
000076bac53d86f7  pop r11
000076bac53d86f9  pop r10
000076bac53d86fb  pop r9
000076bac53d86fd  pop r8
000076bac53d86ff  pop rsi
000076bac53d8700  pop rdi
000076bac53d8701  pop rdx
000076bac53d8702  pop rcx
000076bac53d8703  pop rax
000076bac53d8704  add rsp, 0x08
000076bac53d8708  jmp 0x000076BAC53D3532
000076bac53d870d  sub rsp, 0x08
000076bac53d8711  push rax
000076bac53d8712  push rcx
000076bac53d8713  push rdx
000076bac53d8714  push rdi
000076bac53d8715  push rsi
000076bac53d8716  push r8
000076bac53d8718  push r9
000076bac53d871a  push r10
000076bac53d871c  push r11
000076bac53d871e  sub rsp, 0xF0
000076bac53d8725  vmovaps [rsp], xmm0
000076bac53d872a  vmovaps [rsp+0x10], xmm1
000076bac53d8730  vmovaps [rsp+0x20], xmm2
000076bac53d8736  vmovaps [rsp+0x30], xmm3
000076bac53d873c  vmovaps [rsp+0x40], xmm4
000076bac53d8742  vmovaps [rsp+0x50], xmm5
000076bac53d8748  vmovaps [rsp+0x60], xmm6
000076bac53d874e  vmovaps [rsp+0x70], xmm7
000076bac53d8754  vmovaps [rsp+0x80], xmm8
000076bac53d875d  vmovaps [rsp+0x90], xmm9
000076bac53d8766  vmovaps [rsp+0xA0], xmm10
000076bac53d876f  vmovaps [rsp+0xB0], xmm11
000076bac53d8778  vmovaps [rsp+0xC0], xmm12
000076bac53d8781  vmovaps [rsp+0xD0], xmm13
000076bac53d878a  vmovaps [rsp+0xE0], xmm14
000076bac53d8793  sub rsp, 0x30
000076bac53d8797  movaps [rsp], xmm15
000076bac53d879c  movaps [rsp+0x10], xmm1
000076bac53d87a1  movaps [rsp+0x20], xmm10
000076bac53d87a7  lea rdi, [rsp]
000076bac53d87ab  mov esi, 0x00
000076bac53d87b0  mov rax, 0x5641B0A3C530
000076bac53d87ba  call rax
000076bac53d87bc  movaps xmm15, [rsp]
000076bac53d87c1  add rsp, 0x30
000076bac53d87c5  vmovaps xmm0, [rsp]
000076bac53d87ca  vmovaps xmm1, [rsp+0x10]
000076bac53d87d0  vmovaps xmm2, [rsp+0x20]
000076bac53d87d6  vmovaps xmm3, [rsp+0x30]
000076bac53d87dc  vmovaps xmm4, [rsp+0x40]
000076bac53d87e2  vmovaps xmm5, [rsp+0x50]
000076bac53d87e8  vmovaps xmm6, [rsp+0x60]
000076bac53d87ee  vmovaps xmm7, [rsp+0x70]
000076bac53d87f4  vmovaps xmm8, [rsp+0x80]
000076bac53d87fd  vmovaps xmm9, [rsp+0x90]
000076bac53d8806  vmovaps xmm10, [rsp+0xA0]
000076bac53d880f  vmovaps xmm11, [rsp+0xB0]
000076bac53d8818  vmovaps xmm12, [rsp+0xC0]
000076bac53d8821  vmovaps xmm13, [rsp+0xD0]
000076bac53d882a  vmovaps xmm14, [rsp+0xE0]
000076bac53d8833  add rsp, 0xF0
000076bac53d883a  pop r11
000076bac53d883c  pop r10
000076bac53d883e  pop r9
000076bac53d8840  pop r8
000076bac53d8842  pop rsi
000076bac53d8843  pop rdi
000076bac53d8844  pop rdx
000076bac53d8845  pop rcx
000076bac53d8846  pop rax
000076bac53d8847  add rsp, 0x08
000076bac53d884b  jmp 0x000076BAC53D3555
000076bac53d8850  sub rsp, 0x08
000076bac53d8854  push rax
000076bac53d8855  push rcx
000076bac53d8856  push rdx
000076bac53d8857  push rdi
000076bac53d8858  push rsi
000076bac53d8859  push r8
000076bac53d885b  push r9
000076bac53d885d  push r10
000076bac53d885f  push r11
000076bac53d8861  sub rsp, 0xF0
000076bac53d8868  vmovaps [rsp], xmm0
000076bac53d886d  vmovaps [rsp+0x10], xmm2
000076bac53d8873  vmovaps [rsp+0x20], xmm3
000076bac53d8879  vmovaps [rsp+0x30], xmm4
000076bac53d887f  vmovaps [rsp+0x40], xmm5
000076bac53d8885  vmovaps [rsp+0x50], xmm6
000076bac53d888b  vmovaps [rsp+0x60], xmm7
000076bac53d8891  vmovaps [rsp+0x70], xmm8
000076bac53d8897  vmovaps [rsp+0x80], xmm9
000076bac53d88a0  vmovaps [rsp+0x90], xmm10
000076bac53d88a9  vmovaps [rsp+0xA0], xmm11
000076bac53d88b2  vmovaps [rsp+0xB0], xmm12
000076bac53d88bb  vmovaps [rsp+0xC0], xmm13
000076bac53d88c4  vmovaps [rsp+0xD0], xmm14
000076bac53d88cd  vmovaps [rsp+0xE0], xmm15
000076bac53d88d6  sub rsp, 0x30
000076bac53d88da  movaps [rsp], xmm1
000076bac53d88de  movaps [rsp+0x10], xmm7
000076bac53d88e3  movaps [rsp+0x20], xmm11
000076bac53d88e9  lea rdi, [rsp]
000076bac53d88ed  mov esi, 0x00
000076bac53d88f2  mov rax, 0x5641B0A3C530
000076bac53d88fc  call rax
000076bac53d88fe  movaps xmm1, [rsp]
000076bac53d8902  add rsp, 0x30
000076bac53d8906  vmovaps xmm0, [rsp]
000076bac53d890b  vmovaps xmm2, [rsp+0x10]
000076bac53d8911  vmovaps xmm3, [rsp+0x20]
000076bac53d8917  vmovaps xmm4, [rsp+0x30]
000076bac53d891d  vmovaps xmm5, [rsp+0x40]
000076bac53d8923  vmovaps xmm6, [rsp+0x50]
000076bac53d8929  vmovaps xmm7, [rsp+0x60]
000076bac53d892f  vmovaps xmm8, [rsp+0x70]
000076bac53d8935  vmovaps xmm9, [rsp+0x80]
000076bac53d893e  vmovaps xmm10, [rsp+0x90]
000076bac53d8947  vmovaps xmm11, [rsp+0xA0]
000076bac53d8950  vmovaps xmm12, [rsp+0xB0]
000076bac53d8959  vmovaps xmm13, [rsp+0xC0]
000076bac53d8962  vmovaps xmm14, [rsp+0xD0]
000076bac53d896b  vmovaps xmm15, [rsp+0xE0]
000076bac53d8974  add rsp, 0xF0
000076bac53d897b  pop r11
000076bac53d897d  pop r10
000076bac53d897f  pop r9
000076bac53d8981  pop r8
000076bac53d8983  pop rsi
000076bac53d8984  pop rdi
000076bac53d8985  pop rdx
000076bac53d8986  pop rcx
000076bac53d8987  pop rax
000076bac53d8988  add rsp, 0x08
000076bac53d898c  jmp 0x000076BAC53D3576
000076bac53d8991  call 0x000076BAC520D600
000076bac53d8996  jmp 0x000076BAC53D3589
000076bac53d899b  call 0x000076BAC520C380
000076bac53d89a0  jmp 0x000076BAC53D3594
000076bac53d89a5  call 0x000076BAC520E880
000076bac53d89aa  jmp 0x000076BAC53D359F
000076bac53d89af  call 0x000076BAC51FF540
000076bac53d89b4  jmp 0x000076BAC53D35AA
000076bac53d89b9  int3
000076bac53d89ba  nop [rax+rax*1], ax
000076bac53d89c0  mov rax, [r15+0x40]
000076bac53d89c4  mov r14, [r15+0x58]
000076bac53d89c8  lea r12, [rax+r14*1]
000076bac53d89cc  movaps xmm1, [r15+0x1D0]
000076bac53d89d4  vmovaps [rsp+0x10], xmm1
000076bac53d89da  vmovaps xmm15, [rsp+0x10]
000076bac53d89e0  por xmm1, xmm15
000076bac53d89e5  movaps xmm14, [r15+0x1A0]
000076bac53d89ed  vmovaps [rsp+0x10], xmm14
000076bac53d89f3  vmovaps xmm13, [rsp+0x10]
000076bac53d89f9  por xmm14, xmm13
000076bac53d89fe  lea rax, [r12+0x30]
000076bac53d8a03  mov r11, [r13+rax*1]
000076bac53d8a08  lea rax, [r12+0x38]
000076bac53d8a0d  mov r10, [r13+rax*1]
000076bac53d8a12  movq xmm13, r11
000076bac53d8a17  movq xmm12, r10
000076bac53d8a1c  movq xmm13, xmm13
000076bac53d8a21  vmovaps [rsp+0x10], xmm13
000076bac53d8a27  movq xmm13, xmm13
000076bac53d8a2c  movaps [r15+0x130], xmm13
000076bac53d8a34  movq xmm12, xmm12
000076bac53d8a39  vmovaps [rsp+0x20], xmm12
000076bac53d8a3f  movq xmm12, xmm12
000076bac53d8a44  movaps [r15+0x280], xmm12
000076bac53d8a4c  movaps xmm13, [r15+0x270]
000076bac53d8a54  vmovaps [rsp+0x30], xmm13
000076bac53d8a5a  vmovaps xmm12, [rsp+0x30]
000076bac53d8a60  por xmm13, xmm12
000076bac53d8a65  lea rax, [r12+0x20]
000076bac53d8a6a  mov r11, [r13+rax*1]
000076bac53d8a6f  lea rax, [r12+0x28]
000076bac53d8a74  mov r10, [r13+rax*1]
000076bac53d8a79  movq xmm12, r11
000076bac53d8a7e  movq xmm11, r10
000076bac53d8a83  movq xmm12, xmm12
000076bac53d8a88  vmovaps [rsp+0x30], xmm12
000076bac53d8a8e  movq xmm12, xmm12
000076bac53d8a93  movaps [r15+0x150], xmm12
000076bac53d8a9b  movq xmm11, xmm11
000076bac53d8aa0  vmovaps [rsp+0x40], xmm11
000076bac53d8aa6  movq xmm11, xmm11
000076bac53d8aab  movaps [r15+0x140], xmm11
000076bac53d8ab3  lea rax, [r12+0x10]
000076bac53d8ab8  mov r11, [r13+rax*1]
000076bac53d8abd  lea rax, [r12+0x18]
000076bac53d8ac2  mov r10, [r13+rax*1]
000076bac53d8ac7  movq xmm12, r11
000076bac53d8acc  movq xmm11, r10
000076bac53d8ad1  movq xmm12, xmm12
000076bac53d8ad6  vmovaps [rsp+0x50], xmm12
000076bac53d8adc  movq xmm12, xmm12
000076bac53d8ae1  movaps [r15+0x170], xmm12
000076bac53d8ae9  movq xmm11, xmm11
000076bac53d8aee  vmovaps [rsp+0x60], xmm11
000076bac53d8af4  movq xmm11, xmm11
000076bac53d8af9  movaps [r15+0x160], xmm11
000076bac53d8b01  mov rax, [r13+r12*1]
000076bac53d8b06  vmovq xmm12, rax
000076bac53d8b0b  vpbroadcastq xmm12, xmm12
000076bac53d8b10  lea rax, [r12+0x08]
000076bac53d8b15  mov r12, [r13+rax*1]
000076bac53d8b1a  movq xmm11, r12
000076bac53d8b1f  movaps [r15+0x230], xmm11
000076bac53d8b27  mov rax, [r15+0xF8]
000076bac53d8b2e  lea r12, [rax+0x50]
000076bac53d8b32  movups xmm11, [r13+r12*1]
000076bac53d8b38  lea r12, [rax+0x60]
000076bac53d8b3c  movups xmm10, [r13+r12*1]
000076bac53d8b42  lea r12, [rax+0x30]
000076bac53d8b46  movups xmm9, [r13+r12*1]
000076bac53d8b4c  mov r12, [r15+0x50]
000076bac53d8b50  lea r11, [r12+r14*1]
000076bac53d8b54  mov [r15+0x60], r11
000076bac53d8b58  lea r12, [r14+0x40]
000076bac53d8b5c  mov [r15+0x58], r12
000076bac53d8b60  movaps xmm8, xmm12
000076bac53d8b64  mulpd xmm8, xmm15
000076bac53d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
000076bac53d8b6f  ptest xmm7, xmm7
000076bac53d8b74  jnz 0x000076BAC53D9997
000076bac53d8b7a  movq xmm15, qword ptr [r15+0x230]
000076bac53d8b83  vmovaps [rsp+0x70], xmm15
000076bac53d8b89  vpermilpd xmm15, xmm15, 0x00
000076bac53d8b8f  movaps xmm7, xmm9
000076bac53d8b93  mulpd xmm7, xmm15
000076bac53d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
000076bac53d8b9d  ptest xmm6, xmm6
000076bac53d8ba2  jnz 0x000076BAC53D9ADB
000076bac53d8ba8  vxorps xmm15, xmm15, xmm15
000076bac53d8bad  vpbroadcastq xmm15, xmm15
000076bac53d8bb2  movaps xmm9, xmm12
000076bac53d8bb6  mulpd xmm9, xmm10
000076bac53d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
000076bac53d8bc1  ptest xmm6, xmm6
000076bac53d8bc6  jnz 0x000076BAC53D9C1D
000076bac53d8bcc  movaps xmm10, xmm12
000076bac53d8bd0  mulpd xmm10, xmm11
000076bac53d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
000076bac53d8bdb  ptest xmm6, xmm6
000076bac53d8be0  jnz 0x000076BAC53D9D61
000076bac53d8be6  movaps xmm11, [r15+0x1F0]
000076bac53d8bee  movaps xmm6, xmm12
000076bac53d8bf2  mulpd xmm6, xmm11
000076bac53d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
000076bac53d8bfc  ptest xmm5, xmm5
000076bac53d8c01  jnz 0x000076BAC53D9EA5
000076bac53d8c07  movaps xmm12, [r15+0x2A0]
000076bac53d8c0f  vmovaps [rsp+0x80], xmm12
000076bac53d8c18  vmovaps xmm11, [rsp+0x80]
000076bac53d8c21  por xmm12, xmm11
000076bac53d8c26  movaps xmm11, [r15+0x250]
000076bac53d8c2e  vmovaps [rsp+0x80], xmm11
000076bac53d8c37  vmovaps xmm5, [rsp+0x80]
000076bac53d8c40  por xmm11, xmm5
000076bac53d8c45  vmovaps xmm4, [rsp+0x70]
000076bac53d8c4b  vpermilpd xmm4, xmm4, 0x00
000076bac53d8c51  movaps xmm3, xmm5
000076bac53d8c54  mulpd xmm3, xmm4
000076bac53d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
000076bac53d8c5d  ptest xmm2, xmm2
000076bac53d8c62  jnz 0x000076BAC53D9FE7
000076bac53d8c68  mov [rsp+0x80], rax
000076bac53d8c70  xor eax, eax
000076bac53d8c72  mov r14d, 0x200
000076bac53d8c78  cmp r12, r14
000076bac53d8c7b  cmc
000076bac53d8c7c  lahf
000076bac53d8c7d  seto al
000076bac53d8c80  mov [r15+0x108], eax
000076bac53d8c87  movaps xmm5, xmm8
000076bac53d8c8b  addpd xmm5, xmm15
000076bac53d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
000076bac53d8c95  ptest xmm4, xmm4
000076bac53d8c9a  jnz 0x000076BAC53DA127
000076bac53d8ca0  movaps xmm8, [r15+0x1B0]
000076bac53d8ca8  movaps xmm4, xmm9
000076bac53d8cac  addpd xmm4, xmm8
000076bac53d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
000076bac53d8cb6  ptest xmm2, xmm2
000076bac53d8cbb  jnz 0x000076BAC53DA269
000076bac53d8cc1  movaps xmm9, xmm10
000076bac53d8cc5  addpd xmm9, xmm8
000076bac53d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
000076bac53d8cd0  ptest xmm2, xmm2
000076bac53d8cd5  jnz 0x000076BAC53DA3AB
000076bac53d8cdb  movaps xmm10, [r15+0x2F0]
000076bac53d8ce3  vmovaps [rsp+0x90], xmm10
000076bac53d8cec  vmovaps xmm8, [rsp+0x90]
000076bac53d8cf5  por xmm10, xmm8
000076bac53d8cfa  movaps xmm8, [r15+0x2E0]
000076bac53d8d02  vmovaps [rsp+0x90], xmm8
000076bac53d8d0b  vmovaps xmm2, [rsp+0x90]
000076bac53d8d14  por xmm8, xmm2
000076bac53d8d19  movaps xmm2, [r15+0x2D0]
000076bac53d8d21  vmovaps [rsp+0x90], xmm2
000076bac53d8d2a  vmovaps [rsp+0xA0], xmm1
000076bac53d8d33  vmovaps xmm1, [rsp+0x90]
000076bac53d8d3c  por xmm2, xmm1
000076bac53d8d40  movaps xmm1, [r15+0x200]
000076bac53d8d48  vmovaps [rsp+0x90], xmm1
000076bac53d8d51  vmovaps [rsp+0xB0], xmm15
000076bac53d8d5a  vmovaps xmm15, [rsp+0x90]
000076bac53d8d63  por xmm1, xmm15
000076bac53d8d68  movaps xmm15, [r15+0x1C0]
000076bac53d8d70  vmovaps [rsp+0x90], xmm15
000076bac53d8d79  vmovaps [rsp+0xC0], xmm1
000076bac53d8d82  vmovaps xmm1, [rsp+0x90]
000076bac53d8d8b  por xmm15, xmm1
000076bac53d8d90  movaps xmm1, [r15+0x190]
000076bac53d8d98  vmovaps [rsp+0x90], xmm1
000076bac53d8da1  vmovaps [rsp+0xD0], xmm15
000076bac53d8daa  vmovaps xmm15, [rsp+0x90]
000076bac53d8db3  por xmm1, xmm15
000076bac53d8db8  movaps xmm15, [r15+0x300]
000076bac53d8dc0  vmovaps [rsp+0x90], xmm15
000076bac53d8dc9  vmovaps [rsp+0xE0], xmm1
000076bac53d8dd2  vmovaps xmm1, [rsp+0x90]
000076bac53d8ddb  por xmm15, xmm1
000076bac53d8de0  mov rax, [rsp+0x80]
000076bac53d8de8  lea r14, [rax+0xA0]
000076bac53d8def  movups xmm1, [r13+r14*1]
000076bac53d8df5  lea r14, [rax+0xB0]
000076bac53d8dfc  vmovaps [rsp+0x80], xmm1
000076bac53d8e05  movups xmm1, [r13+r14*1]
000076bac53d8e0b  vmovaps [rsp+0x90], xmm1
000076bac53d8e14  vmovaps [rsp+0xF0], xmm15
000076bac53d8e1d  vmovaps xmm15, [rsp+0xB0]
000076bac53d8e26  vmovaps [rsp+0xB0], xmm14
000076bac53d8e2f  movaps xmm1, xmm6
000076bac53d8e32  addpd xmm1, xmm15
000076bac53d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
000076bac53d8e3c  ptest xmm14, xmm14
000076bac53d8e42  jnz 0x000076BAC53DA503
000076bac53d8e48  lea r14, [rax+0xF0]
000076bac53d8e4f  movups xmm15, [r13+r14*1]
000076bac53d8e55  movaps xmm14, xmm4
000076bac53d8e59  addpd xmm14, xmm3
000076bac53d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
000076bac53d8e64  ptest xmm6, xmm6
000076bac53d8e69  jnz 0x000076BAC53DA64E
000076bac53d8e6f  movaps xmm6, xmm9
000076bac53d8e73  addpd xmm6, xmm7
000076bac53d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
000076bac53d8e7c  ptest xmm4, xmm4
000076bac53d8e81  jnz 0x000076BAC53DA790
000076bac53d8e87  vmovaps xmm9, [rsp+0x70]
000076bac53d8e8d  vpermilpd xmm9, xmm9, 0x00
000076bac53d8e93  vmovaps xmm4, [rsp+0x90]
000076bac53d8e9c  movaps xmm7, xmm4
000076bac53d8e9f  mulpd xmm7, xmm9
000076bac53d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
000076bac53d8ea9  ptest xmm3, xmm3
000076bac53d8eae  jnz 0x000076BAC53DA8D1
000076bac53d8eb4  vmovaps xmm9, [rsp+0x50]
000076bac53d8eba  vpermilpd xmm9, xmm9, 0x00
000076bac53d8ec0  movaps xmm4, xmm15
000076bac53d8ec4  mulpd xmm4, xmm9
000076bac53d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
000076bac53d8ece  ptest xmm3, xmm3
000076bac53d8ed3  jnz 0x000076BAC53DAA12
000076bac53d8ed9  lea r14, [rax+0xE0]
000076bac53d8ee0  movups xmm15, [r13+r14*1]
000076bac53d8ee6  vmovaps xmm9, [rsp+0x70]
000076bac53d8eec  vpermilpd xmm9, xmm9, 0x00
000076bac53d8ef2  vmovaps [rsp+0x70], xmm1
000076bac53d8ef8  vmovaps xmm1, [rsp+0x80]
000076bac53d8f01  vmovaps [rsp+0x80], xmm15
000076bac53d8f0a  movaps xmm3, xmm1
000076bac53d8f0d  mulpd xmm3, xmm9
000076bac53d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
000076bac53d8f17  ptest xmm15, xmm15
000076bac53d8f1d  jnz 0x000076BAC53DAB5E
000076bac53d8f23  vmovaps xmm1, [rsp+0xF0]
000076bac53d8f2c  vmovaps xmm15, [rsp+0xF0]
000076bac53d8f35  por xmm1, xmm15
000076bac53d8f3a  movaps [r15+0x300], xmm1
000076bac53d8f42  vmovaps xmm15, [rsp+0xE0]
000076bac53d8f4b  vmovaps xmm9, [rsp+0xE0]
000076bac53d8f54  por xmm15, xmm9
000076bac53d8f59  movaps [r15+0x190], xmm15
000076bac53d8f61  vmovaps xmm9, [rsp+0x50]
000076bac53d8f67  vpermilpd xmm9, xmm9, 0x00
000076bac53d8f6d  vmovaps [rsp+0x90], xmm1
000076bac53d8f76  vmovaps [rsp+0xE0], xmm15
000076bac53d8f7f  vmovaps xmm15, [rsp+0x80]
000076bac53d8f88  vmovaps [rsp+0x80], xmm14
000076bac53d8f91  movaps xmm1, xmm15
000076bac53d8f95  mulpd xmm1, xmm9
000076bac53d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
000076bac53d8f9f  ptest xmm14, xmm14
000076bac53d8fa5  jnz 0x000076BAC53DAC9F
000076bac53d8fab  lea r14, [rax+0x90]
000076bac53d8fb2  movups xmm15, [r13+r14*1]
000076bac53d8fb8  vmovaps xmm14, [rsp+0xD0]
000076bac53d8fc1  vmovaps xmm9, [rsp+0xD0]
000076bac53d8fca  por xmm14, xmm9
000076bac53d8fcf  movaps [r15+0x1C0], xmm14
000076bac53d8fd7  vmovaps xmm9, [rsp+0xC0]
000076bac53d8fe0  vmovaps [rsp+0xD0], xmm1
000076bac53d8fe9  vmovaps xmm1, [rsp+0xC0]
000076bac53d8ff2  por xmm9, xmm1
000076bac53d8ff7  movaps [r15+0x200], xmm9
000076bac53d8fff  vmovaps [rsp+0xC0], xmm2
000076bac53d9008  vmovaps xmm1, [rsp+0xC0]
000076bac53d9011  por xmm2, xmm1
000076bac53d9015  movaps [r15+0x2D0], xmm2
000076bac53d901d  vmovaps [rsp+0xC0], xmm8
000076bac53d9026  vmovaps xmm1, [rsp+0xC0]
000076bac53d902f  por xmm8, xmm1
000076bac53d9034  movaps [r15+0x2E0], xmm8
000076bac53d903c  vmovaps [rsp+0xC0], xmm15
000076bac53d9045  movaps xmm1, xmm5
000076bac53d9048  addpd xmm1, xmm7
000076bac53d904c  vcmppd xmm15, xmm1, xmm1, 0x03
000076bac53d9051  ptest xmm15, xmm15
000076bac53d9057  jnz 0x000076BAC53DADEB
000076bac53d905d  vmovaps xmm15, [rsp+0x50]
000076bac53d9063  vpermilpd xmm15, xmm15, 0x00
000076bac53d9069  vmovaps xmm5, [rsp+0xC0]
000076bac53d9072  vmovaps [rsp+0xC0], xmm1
000076bac53d907b  movaps xmm7, xmm5
000076bac53d907e  mulpd xmm7, xmm15
000076bac53d9083  vcmppd xmm1, xmm7, xmm7, 0x03
000076bac53d9088  ptest xmm1, xmm1
000076bac53d908d  jnz 0x000076BAC53DAF2B
000076bac53d9093  lea r14, [rax+0x80]
000076bac53d909a  movups xmm1, [r13+r14*1]
000076bac53d90a0  vmovaps xmm5, [rsp+0x70]
000076bac53d90a6  vmovaps [rsp+0x70], xmm1
000076bac53d90ac  movaps xmm15, xmm5
000076bac53d90b0  addpd xmm15, xmm3
000076bac53d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
000076bac53d90bb  ptest xmm1, xmm1
000076bac53d90c0  jnz 0x000076BAC53DB076
000076bac53d90c6  vmovaps xmm5, [rsp+0x80]
000076bac53d90cf  movaps xmm1, xmm5
000076bac53d90d2  addpd xmm1, xmm4
000076bac53d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
000076bac53d90db  ptest xmm3, xmm3
000076bac53d90e0  jnz 0x000076BAC53DB1B8
000076bac53d90e6  vmovaps [rsp+0x80], xmm10
000076bac53d90ef  vmovaps xmm5, [rsp+0x80]
000076bac53d90f8  por xmm10, xmm5
000076bac53d90fd  movaps [r15+0x2F0], xmm10
000076bac53d9105  vmovaps xmm5, [rsp+0x50]
000076bac53d910b  vpermilpd xmm5, xmm5, 0x00
000076bac53d9111  vmovaps xmm3, [rsp+0x70]
000076bac53d9117  vmovaps [rsp+0x50], xmm1
000076bac53d911d  movaps xmm4, xmm3
000076bac53d9120  mulpd xmm4, xmm5
000076bac53d9124  vcmppd xmm1, xmm4, xmm4, 0x03
000076bac53d9129  ptest xmm1, xmm1
000076bac53d912e  jnz 0x000076BAC53DB2F8
000076bac53d9134  lea r14, [rax+0xD0]
000076bac53d913b  movups xmm1, [r13+r14*1]
000076bac53d9141  vmovaps xmm3, [rsp+0xD0]
000076bac53d914a  vmovaps [rsp+0x70], xmm1
000076bac53d9150  movaps xmm5, xmm6
000076bac53d9153  addpd xmm5, xmm3
000076bac53d9157  vcmppd xmm1, xmm5, xmm5, 0x03
000076bac53d915c  ptest xmm1, xmm1
000076bac53d9161  jnz 0x000076BAC53DB442
000076bac53d9167  vmovaps xmm1, [rsp+0x60]
000076bac53d916d  vpermilpd xmm1, xmm1, 0x00
000076bac53d9173  movaps xmm6, xmm9
000076bac53d9177  mulpd xmm6, xmm1
000076bac53d917b  vcmppd xmm3, xmm6, xmm6, 0x03
000076bac53d9180  ptest xmm3, xmm3
000076bac53d9185  jnz 0x000076BAC53DB582
000076bac53d918b  movaps [r15+0x260], xmm6
000076bac53d9193  vxorps xmm1, xmm1, xmm1
000076bac53d9197  vpbroadcastq xmm1, xmm1
000076bac53d919c  movaps [r15+0x1B0], xmm1
000076bac53d91a4  vmovaps xmm1, [rsp+0x60]
000076bac53d91aa  vpermilpd xmm1, xmm1, 0x00
000076bac53d91b0  vmovaps xmm3, [rsp+0x70]
000076bac53d91b6  vmovaps [rsp+0x70], xmm15
000076bac53d91bc  movaps xmm9, xmm3
000076bac53d91c0  mulpd xmm9, xmm1
000076bac53d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
000076bac53d91cb  ptest xmm15, xmm15
000076bac53d91d1  jnz 0x000076BAC53DB6C3
000076bac53d91d7  lea r14, [rax+0xC0]
000076bac53d91de  movups xmm1, [r13+r14*1]
000076bac53d91e4  vmovaps xmm3, [rsp+0xC0]
000076bac53d91ed  vmovaps [rsp+0x80], xmm1
000076bac53d91f6  movaps xmm15, xmm3
000076bac53d91fa  addpd xmm15, xmm7
000076bac53d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
000076bac53d9205  ptest xmm1, xmm1
000076bac53d920a  jnz 0x000076BAC53DB80F
000076bac53d9210  vmovaps [rsp+0xC0], xmm13
000076bac53d9219  vmovaps xmm1, [rsp+0xC0]
000076bac53d9222  por xmm13, xmm1
000076bac53d9227  movaps [r15+0x270], xmm13
000076bac53d922f  vmovaps xmm1, [rsp+0xB0]
000076bac53d9238  vmovaps xmm7, [rsp+0xB0]
000076bac53d9241  por xmm1, xmm7
000076bac53d9245  movaps [r15+0x1A0], xmm1
000076bac53d924d  vmovaps xmm1, [rsp+0x60]
000076bac53d9253  vpermilpd xmm1, xmm1, 0x00
000076bac53d9259  vmovaps [rsp+0xB0], xmm1
000076bac53d9262  vmovaps xmm1, [rsp+0x80]
000076bac53d926b  vmovaps [rsp+0x80], xmm15
000076bac53d9274  vmovaps xmm15, [rsp+0xB0]
000076bac53d927d  vmovaps [rsp+0xB0], xmm14
000076bac53d9286  movaps xmm3, xmm1
000076bac53d9289  mulpd xmm3, xmm15
000076bac53d928e  vcmppd xmm14, xmm3, xmm3, 0x03
000076bac53d9293  ptest xmm14, xmm14
000076bac53d9299  jnz 0x000076BAC53DB951
000076bac53d929f  lea r14, [rax+0x20]
000076bac53d92a3  movups xmm1, [r13+r14*1]
000076bac53d92a9  movaps [r15+0x110], xmm1
000076bac53d92b1  vmovaps xmm14, [rsp+0x70]
000076bac53d92b7  vmovaps [rsp+0x70], xmm1
000076bac53d92bd  movaps xmm15, xmm14
000076bac53d92c1  addpd xmm15, xmm4
000076bac53d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
000076bac53d92cc  ptest xmm1, xmm1
000076bac53d92d1  jnz 0x000076BAC53DBA9C
000076bac53d92d7  vmovaps xmm1, [rsp+0x60]
000076bac53d92dd  vpermilpd xmm1, xmm1, 0x00
000076bac53d92e3  movaps xmm14, xmm2
000076bac53d92e7  mulpd xmm14, xmm1
000076bac53d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
000076bac53d92f2  ptest xmm4, xmm4
000076bac53d92f7  jnz 0x000076BAC53DBBDF
000076bac53d92fd  vmovaps xmm4, [rsp+0x50]
000076bac53d9303  movaps xmm1, xmm4
000076bac53d9306  addpd xmm1, xmm9
000076bac53d930b  vcmppd xmm2, xmm1, xmm1, 0x03
000076bac53d9310  ptest xmm2, xmm2
000076bac53d9315  jnz 0x000076BAC53DBD21
000076bac53d931b  vmovaps xmm9, [rsp+0x30]
000076bac53d9321  vpermilpd xmm9, xmm9, 0x00
000076bac53d9327  vmovaps xmm2, [rsp+0x70]
000076bac53d932d  vmovaps [rsp+0x50], xmm1
000076bac53d9333  movaps xmm4, xmm2
000076bac53d9336  mulpd xmm4, xmm9
000076bac53d933b  vcmppd xmm1, xmm4, xmm4, 0x03
000076bac53d9340  ptest xmm1, xmm1
000076bac53d9345  jnz 0x000076BAC53DBE62
000076bac53d934b  vmovaps xmm1, [rsp+0x30]
000076bac53d9351  vpermilpd xmm1, xmm1, 0x00
000076bac53d9357  vmovaps xmm2, [rsp+0x90]
000076bac53d9360  vmovaps [rsp+0x60], xmm15
000076bac53d9366  movaps xmm9, xmm2
000076bac53d936a  mulpd xmm9, xmm1
000076bac53d936f  vcmppd xmm15, xmm9, xmm9, 0x03
000076bac53d9375  ptest xmm15, xmm15
000076bac53d937b  jnz 0x000076BAC53DBFA3
000076bac53d9381  vmovaps xmm15, [rsp+0x80]
000076bac53d938a  movaps xmm1, xmm15
000076bac53d938e  addpd xmm1, xmm6
000076bac53d9392  vcmppd xmm2, xmm1, xmm1, 0x03
000076bac53d9397  ptest xmm2, xmm2
000076bac53d939c  jnz 0x000076BAC53DC0E5
000076bac53d93a2  movaps xmm15, xmm5
000076bac53d93a6  addpd xmm15, xmm3
000076bac53d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
000076bac53d93b1  ptest xmm6, xmm6
000076bac53d93b6  jnz 0x000076BAC53DC226
000076bac53d93bc  vmovaps xmm6, [rsp+0x30]
000076bac53d93c2  vpermilpd xmm6, xmm6, 0x00
000076bac53d93c8  movaps xmm5, xmm8
000076bac53d93cc  mulpd xmm5, xmm6
000076bac53d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
000076bac53d93d5  ptest xmm3, xmm3
000076bac53d93da  jnz 0x000076BAC53DC368
000076bac53d93e0  vmovaps xmm8, [rsp+0x30]
000076bac53d93e6  vpermilpd xmm8, xmm8, 0x00
000076bac53d93ec  movaps xmm6, xmm10
000076bac53d93f0  mulpd xmm6, xmm8
000076bac53d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
000076bac53d93fa  ptest xmm3, xmm3
000076bac53d93ff  jnz 0x000076BAC53DC4A9
000076bac53d9405  vmovaps xmm8, [rsp+0x60]
000076bac53d940b  movaps xmm10, xmm8
000076bac53d940f  addpd xmm10, xmm14
000076bac53d9414  vcmppd xmm3, xmm10, xmm10, 0x03
000076bac53d941a  ptest xmm3, xmm3
000076bac53d941f  jnz 0x000076BAC53DC5EB
000076bac53d9425  vmovaps xmm8, [rsp+0x50]
000076bac53d942b  movaps xmm14, xmm8
000076bac53d942f  addpd xmm14, xmm4
000076bac53d9434  vcmppd xmm3, xmm14, xmm14, 0x03
000076bac53d943a  ptest xmm3, xmm3
000076bac53d943f  jnz 0x000076BAC53DC72F
000076bac53d9445  vmovaps xmm8, [rsp+0x40]
000076bac53d944b  vpermilpd xmm8, xmm8, 0x00
000076bac53d9451  movaps xmm4, xmm13
000076bac53d9455  mulpd xmm4, xmm8
000076bac53d945a  vcmppd xmm3, xmm4, xmm4, 0x03
000076bac53d945f  ptest xmm3, xmm3
000076bac53d9464  jnz 0x000076BAC53DC872
000076bac53d946a  movaps xmm13, xmm15
000076bac53d946e  addpd xmm13, xmm9
000076bac53d9473  vcmppd xmm8, xmm13, xmm13, 0x03
000076bac53d9479  ptest xmm8, xmm8
000076bac53d947f  jnz 0x000076BAC53DC9B4
000076bac53d9485  movaps xmm15, xmm1
000076bac53d9489  addpd xmm15, xmm5
000076bac53d948e  vcmppd xmm9, xmm15, xmm15, 0x03
000076bac53d9494  ptest xmm9, xmm9
000076bac53d949a  jnz 0x000076BAC53DCAF8
000076bac53d94a0  vmovaps [rsp+0x30], xmm11
000076bac53d94a6  vmovaps xmm1, [rsp+0x30]
000076bac53d94ac  por xmm11, xmm1
000076bac53d94b1  movaps [r15+0x250], xmm11
000076bac53d94b9  vmovaps [rsp+0x30], xmm12
000076bac53d94bf  vmovaps xmm1, [rsp+0x30]
000076bac53d94c5  por xmm12, xmm1
000076bac53d94ca  movaps [r15+0x2A0], xmm12
000076bac53d94d2  vmovaps xmm1, [rsp+0xA0]
000076bac53d94db  vmovaps xmm11, [rsp+0xA0]
000076bac53d94e4  por xmm1, xmm11
000076bac53d94e9  movaps [r15+0x1D0], xmm1
000076bac53d94f1  lea r14, [rax+0x40]
000076bac53d94f5  movups xmm1, [r13+r14*1]
000076bac53d94fb  movaps [r15+0x2C0], xmm1
000076bac53d9503  vmovaps xmm11, [rsp+0x40]
000076bac53d9509  vpermilpd xmm11, xmm11, 0x00
000076bac53d950f  vmovaps xmm8, [rsp+0xE0]
000076bac53d9518  movaps xmm9, xmm8
000076bac53d951c  mulpd xmm9, xmm11
000076bac53d9521  vcmppd xmm5, xmm9, xmm9, 0x03
000076bac53d9527  ptest xmm5, xmm5
000076bac53d952c  jnz 0x000076BAC53DCC44
000076bac53d9532  movaps xmm11, xmm10
000076bac53d9536  addpd xmm11, xmm6
000076bac53d953b  vcmppd xmm8, xmm11, xmm11, 0x03
000076bac53d9541  ptest xmm8, xmm8
000076bac53d9547  jnz 0x000076BAC53DCD88
000076bac53d954d  movaps xmm10, xmm14
000076bac53d9551  addpd xmm10, xmm4
000076bac53d9556  vcmppd xmm8, xmm10, xmm10, 0x03
000076bac53d955c  ptest xmm8, xmm8
000076bac53d9562  jnz 0x000076BAC53DCECB
000076bac53d9568  vmovaps xmm14, [rsp+0x40]
000076bac53d956e  vpermilpd xmm14, xmm14, 0x00
000076bac53d9574  movaps xmm8, xmm1
000076bac53d9578  mulpd xmm8, xmm14
000076bac53d957d  vcmppd xmm6, xmm8, xmm8, 0x03
000076bac53d9583  ptest xmm6, xmm6
000076bac53d9588  jnz 0x000076BAC53DD00E
000076bac53d958e  movaps xmm1, [r15+0x2B0]
000076bac53d9596  vmovaps xmm14, [rsp+0x40]
000076bac53d959c  vpermilpd xmm14, xmm14, 0x00
000076bac53d95a2  movaps xmm6, xmm1
000076bac53d95a5  mulpd xmm6, xmm14
000076bac53d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
000076bac53d95af  ptest xmm5, xmm5
000076bac53d95b4  jnz 0x000076BAC53DD151
000076bac53d95ba  vmovaps xmm1, [rsp+0x10]
000076bac53d95c0  vpermilpd xmm1, xmm1, 0x00
000076bac53d95c6  movaps xmm14, xmm12
000076bac53d95ca  mulpd xmm14, xmm1
000076bac53d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
000076bac53d95d5  ptest xmm5, xmm5
000076bac53d95da  jnz 0x000076BAC53DD292
000076bac53d95e0  movaps xmm1, xmm13
000076bac53d95e4  addpd xmm1, xmm9
000076bac53d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
000076bac53d95ee  ptest xmm12, xmm12
000076bac53d95f4  jnz 0x000076BAC53DD3D5
000076bac53d95fa  vmovaps xmm13, [rsp+0x10]
000076bac53d9600  vpermilpd xmm13, xmm13, 0x00
000076bac53d9606  movaps xmm12, xmm7
000076bac53d960a  mulpd xmm12, xmm13
000076bac53d960f  vcmppd xmm9, xmm12, xmm12, 0x03
000076bac53d9615  ptest xmm9, xmm9
000076bac53d961b  jnz 0x000076BAC53DD517
000076bac53d9621  movaps xmm13, xmm15
000076bac53d9625  addpd xmm13, xmm8
000076bac53d962a  vcmppd xmm9, xmm13, xmm13, 0x03
000076bac53d9630  ptest xmm9, xmm9
000076bac53d9636  jnz 0x000076BAC53DD65A
000076bac53d963c  movaps xmm15, [r15+0x290]
000076bac53d9644  vmovaps xmm9, [rsp+0x10]
000076bac53d964a  vpermilpd xmm9, xmm9, 0x00
000076bac53d9650  movaps xmm8, xmm15
000076bac53d9654  mulpd xmm8, xmm9
000076bac53d9659  vcmppd xmm7, xmm8, xmm8, 0x03
000076bac53d965f  ptest xmm7, xmm7
000076bac53d9664  jnz 0x000076BAC53DD79E
000076bac53d966a  movaps xmm15, xmm11
000076bac53d966e  addpd xmm15, xmm6
000076bac53d9673  vcmppd xmm9, xmm15, xmm15, 0x03
000076bac53d9679  ptest xmm9, xmm9
000076bac53d967f  jnz 0x000076BAC53DD8E2
000076bac53d9685  movaps xmm11, [r15+0x1E0]
000076bac53d968d  vmovaps xmm9, [rsp+0x10]
000076bac53d9693  vpermilpd xmm9, xmm9, 0x00
000076bac53d9699  movaps xmm7, xmm11
000076bac53d969d  mulpd xmm7, xmm9
000076bac53d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
000076bac53d96a7  ptest xmm6, xmm6
000076bac53d96ac  jnz 0x000076BAC53DDA25
000076bac53d96b2  movaps xmm11, xmm10
000076bac53d96b6  addpd xmm11, xmm14
000076bac53d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
000076bac53d96c1  ptest xmm9, xmm9
000076bac53d96c7  jnz 0x000076BAC53DDB67
000076bac53d96cd  lea r14, [rax+0x70]
000076bac53d96d1  movups xmm14, [r13+r14*1]
000076bac53d96d7  movaps [r15+0x240], xmm14
000076bac53d96df  movaps xmm10, xmm1
000076bac53d96e3  addpd xmm10, xmm12
000076bac53d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
000076bac53d96ee  ptest xmm9, xmm9
000076bac53d96f4  jnz 0x000076BAC53DDCB5
000076bac53d96fa  movaps [r15+0x170], xmm10
000076bac53d9702  vmovaps xmm1, [rsp+0x20]
000076bac53d9708  vpermilpd xmm1, xmm1, 0x00
000076bac53d970e  movaps xmm12, xmm14
000076bac53d9712  mulpd xmm12, xmm1
000076bac53d9717  vcmppd xmm9, xmm12, xmm12, 0x03
000076bac53d971d  ptest xmm9, xmm9
000076bac53d9723  jnz 0x000076BAC53DDDF8
000076bac53d9729  vmovaps xmm1, [rsp+0x20]
000076bac53d972f  vpermilpd xmm1, xmm1, 0x00
000076bac53d9735  vmovaps xmm9, [rsp+0xB0]
000076bac53d973e  movaps xmm14, xmm9
000076bac53d9742  mulpd xmm14, xmm1
000076bac53d9747  vcmppd xmm6, xmm14, xmm14, 0x03
000076bac53d974d  ptest xmm6, xmm6
000076bac53d9752  jnz 0x000076BAC53DDF3B
000076bac53d9758  movaps [r15+0x180], xmm14
000076bac53d9760  movaps xmm1, xmm13
000076bac53d9764  addpd xmm1, xmm8
000076bac53d9769  vcmppd xmm9, xmm1, xmm1, 0x03
000076bac53d976e  ptest xmm9, xmm9
000076bac53d9774  jnz 0x000076BAC53DE07E
000076bac53d977a  movaps [r15+0x210], xmm1
000076bac53d9782  movups xmm13, [r13+rax*1]
000076bac53d9788  lea r14, [rax+0x10]
000076bac53d978c  movups xmm9, [r13+r14*1]
000076bac53d9792  movaps [r15+0x230], xmm9
000076bac53d979a  movaps xmm8, xmm15
000076bac53d979e  addpd xmm8, xmm7
000076bac53d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
000076bac53d97a9  ptest xmm6, xmm6
000076bac53d97ae  jnz 0x000076BAC53DE1D4
000076bac53d97b4  movaps [r15+0x130], xmm8
000076bac53d97bc  vmovaps xmm15, [rsp+0x20]
000076bac53d97c2  vpermilpd xmm15, xmm15, 0x00
000076bac53d97c8  movaps xmm7, xmm9
000076bac53d97cc  mulpd xmm7, xmm15
000076bac53d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
000076bac53d97d6  ptest xmm6, xmm6
000076bac53d97db  jnz 0x000076BAC53DE317
000076bac53d97e1  movaps [r15+0x220], xmm7
000076bac53d97e9  vmovaps xmm15, [rsp+0x20]
000076bac53d97ef  vpermilpd xmm15, xmm15, 0x00
000076bac53d97f5  movaps xmm9, xmm13
000076bac53d97f9  mulpd xmm9, xmm15
000076bac53d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
000076bac53d9804  ptest xmm6, xmm6
000076bac53d9809  jnz 0x000076BAC53DE459
000076bac53d980f  movaps xmm15, xmm11
000076bac53d9813  addpd xmm15, xmm12
000076bac53d9818  vcmppd xmm13, xmm15, xmm15, 0x03
000076bac53d981e  ptest xmm13, xmm13
000076bac53d9824  jnz 0x000076BAC53DE59D
000076bac53d982a  movaps [r15+0x140], xmm15
000076bac53d9832  movaps xmm13, xmm10
000076bac53d9836  addpd xmm13, xmm14
000076bac53d983b  vcmppd xmm12, xmm13, xmm13, 0x03
000076bac53d9841  ptest xmm12, xmm12
000076bac53d9847  jnz 0x000076BAC53DE6E1
000076bac53d984d  movaps [r15+0x150], xmm13
000076bac53d9855  movaps xmm14, xmm1
000076bac53d9859  addpd xmm14, xmm7
000076bac53d985e  vcmppd xmm12, xmm14, xmm14, 0x03
000076bac53d9864  ptest xmm12, xmm12
000076bac53d986a  jnz 0x000076BAC53DE825
000076bac53d9870  movaps [r15+0x160], xmm14
000076bac53d9878  movaps xmm1, xmm8
000076bac53d987c  addpd xmm1, xmm9
000076bac53d9881  vcmppd xmm12, xmm1, xmm1, 0x03
000076bac53d9886  ptest xmm12, xmm12
000076bac53d988c  jnz 0x000076BAC53DE967
000076bac53d9892  movaps [r15+0x120], xmm1
000076bac53d989a  movups [r13+r11*1], xmm15
000076bac53d98a0  lea rax, [r11+0x10]
000076bac53d98a4  movups [r13+rax*1], xmm13
000076bac53d98aa  lea rax, [r11+0x20]
000076bac53d98ae  movups [r13+rax*1], xmm14
000076bac53d98b4  lea rax, [r11+0x30]
000076bac53d98b8  movups [r13+rax*1], xmm1
000076bac53d98be  mov eax, [r15+0x108]
000076bac53d98c5  sahf
000076bac53d98c6  jnz 0x000076BAC53D98F8
000076bac53d98c8  cmp dword ptr [r15+0x318], 0x00
000076bac53d98d0  jz 0x000076BAC53DEAE0
000076bac53d98d6  nop [rax+rax*1], ax
000076bac53d98df  nop [rax+rax*1], eax
000076bac53d98e7  mov eax, 0x4106D0
000076bac53d98ec  mov [r15+0x100], rax
000076bac53d98f3  jmp 0x000076BAC51FE110
000076bac53d98f8  cmp dword ptr [r15+0x318], 0x00
000076bac53d9900  jz 0x000076BAC53D89C0
000076bac53d9906  nop [rax+rax*1], ax
000076bac53d990f  nop [rax+rax*1], eax
000076bac53d9917  mov eax, 0x410504
000076bac53d991c  mov [r15+0x100], rax
000076bac53d9923  jmp 0x000076BAC51FE110
000076bac53d9928  int3
000076bac53d9929  call 0x000076BAC520A4B0
000076bac53d992e  jmp 0x000076BAC53D8A08
000076bac53d9933  call 0x000076BAC5209240
000076bac53d9938  jmp 0x000076BAC53D8A12
000076bac53d993d  call 0x000076BAC520A4B0
000076bac53d9942  jmp 0x000076BAC53D8A6F
000076bac53d9947  call 0x000076BAC5209240
000076bac53d994c  jmp 0x000076BAC53D8A79
000076bac53d9951  call 0x000076BAC520A4B0
000076bac53d9956  jmp 0x000076BAC53D8ABD
000076bac53d995b  call 0x000076BAC5209240
000076bac53d9960  jmp 0x000076BAC53D8AC7
000076bac53d9965  call 0x000076BAC52B47C0
000076bac53d996a  jmp 0x000076BAC53D8B06
000076bac53d996f  call 0x000076BAC520B720
000076bac53d9974  jmp 0x000076BAC53D8B1A
000076bac53d9979  call 0x000076BAC52BFC30
000076bac53d997e  jmp 0x000076BAC53D8B38
000076bac53d9983  call 0x000076BAC52BE9C0
000076bac53d9988  jmp 0x000076BAC53D8B42
000076bac53d998d  call 0x000076BAC52BD750
000076bac53d9992  jmp 0x000076BAC53D8B4C
000076bac53d9997  sub rsp, 0x08
000076bac53d999b  push rax
000076bac53d999c  push rcx
000076bac53d999d  push rdx
000076bac53d999e  push rdi
000076bac53d999f  push rsi
000076bac53d99a0  push r8
000076bac53d99a2  push r9
000076bac53d99a4  push r10
000076bac53d99a6  push r11
000076bac53d99a8  sub rsp, 0xF0
000076bac53d99af  vmovaps [rsp], xmm0
000076bac53d99b4  vmovaps [rsp+0x10], xmm1
000076bac53d99ba  vmovaps [rsp+0x20], xmm2
000076bac53d99c0  vmovaps [rsp+0x30], xmm3
000076bac53d99c6  vmovaps [rsp+0x40], xmm4
000076bac53d99cc  vmovaps [rsp+0x50], xmm5
000076bac53d99d2  vmovaps [rsp+0x60], xmm6
000076bac53d99d8  vmovaps [rsp+0x70], xmm7
000076bac53d99de  vmovaps [rsp+0x80], xmm9
000076bac53d99e7  vmovaps [rsp+0x90], xmm10
000076bac53d99f0  vmovaps [rsp+0xA0], xmm11
000076bac53d99f9  vmovaps [rsp+0xB0], xmm12
000076bac53d9a02  vmovaps [rsp+0xC0], xmm13
000076bac53d9a0b  vmovaps [rsp+0xD0], xmm14
000076bac53d9a14  vmovaps [rsp+0xE0], xmm15
000076bac53d9a1d  sub rsp, 0x30
000076bac53d9a21  movaps [rsp], xmm8
000076bac53d9a26  movaps [rsp+0x10], xmm12
000076bac53d9a2c  movaps [rsp+0x20], xmm15
000076bac53d9a32  lea rdi, [rsp]
000076bac53d9a36  mov esi, 0x00
000076bac53d9a3b  mov rax, 0x5641B0A3C530
000076bac53d9a45  call rax
000076bac53d9a47  movaps xmm8, [rsp]
000076bac53d9a4c  add rsp, 0x30
000076bac53d9a50  vmovaps xmm0, [rsp]
000076bac53d9a55  vmovaps xmm1, [rsp+0x10]
000076bac53d9a5b  vmovaps xmm2, [rsp+0x20]
000076bac53d9a61  vmovaps xmm3, [rsp+0x30]
000076bac53d9a67  vmovaps xmm4, [rsp+0x40]
000076bac53d9a6d  vmovaps xmm5, [rsp+0x50]
000076bac53d9a73  vmovaps xmm6, [rsp+0x60]
000076bac53d9a79  vmovaps xmm7, [rsp+0x70]
000076bac53d9a7f  vmovaps xmm9, [rsp+0x80]
000076bac53d9a88  vmovaps xmm10, [rsp+0x90]
000076bac53d9a91  vmovaps xmm11, [rsp+0xA0]
000076bac53d9a9a  vmovaps xmm12, [rsp+0xB0]
000076bac53d9aa3  vmovaps xmm13, [rsp+0xC0]
000076bac53d9aac  vmovaps xmm14, [rsp+0xD0]
000076bac53d9ab5  vmovaps xmm15, [rsp+0xE0]
000076bac53d9abe  add rsp, 0xF0
000076bac53d9ac5  pop r11
000076bac53d9ac7  pop r10
000076bac53d9ac9  pop r9
000076bac53d9acb  pop r8
000076bac53d9acd  pop rsi
000076bac53d9ace  pop rdi
000076bac53d9acf  pop rdx
000076bac53d9ad0  pop rcx
000076bac53d9ad1  pop rax
000076bac53d9ad2  add rsp, 0x08
000076bac53d9ad6  jmp 0x000076BAC53D8B7A
000076bac53d9adb  sub rsp, 0x08
000076bac53d9adf  push rax
000076bac53d9ae0  push rcx
000076bac53d9ae1  push rdx
000076bac53d9ae2  push rdi
000076bac53d9ae3  push rsi
000076bac53d9ae4  push r8
000076bac53d9ae6  push r9
000076bac53d9ae8  push r10
000076bac53d9aea  push r11
000076bac53d9aec  sub rsp, 0xF0
000076bac53d9af3  vmovaps [rsp], xmm0
000076bac53d9af8  vmovaps [rsp+0x10], xmm1
000076bac53d9afe  vmovaps [rsp+0x20], xmm2
000076bac53d9b04  vmovaps [rsp+0x30], xmm3
000076bac53d9b0a  vmovaps [rsp+0x40], xmm4
000076bac53d9b10  vmovaps [rsp+0x50], xmm5
000076bac53d9b16  vmovaps [rsp+0x60], xmm6
000076bac53d9b1c  vmovaps [rsp+0x70], xmm8
000076bac53d9b22  vmovaps [rsp+0x80], xmm9
000076bac53d9b2b  vmovaps [rsp+0x90], xmm10
000076bac53d9b34  vmovaps [rsp+0xA0], xmm11
000076bac53d9b3d  vmovaps [rsp+0xB0], xmm12
000076bac53d9b46  vmovaps [rsp+0xC0], xmm13
000076bac53d9b4f  vmovaps [rsp+0xD0], xmm14
000076bac53d9b58  vmovaps [rsp+0xE0], xmm15
000076bac53d9b61  sub rsp, 0x30
000076bac53d9b65  movaps [rsp], xmm7
000076bac53d9b69  movaps [rsp+0x10], xmm9
000076bac53d9b6f  movaps [rsp+0x20], xmm15
000076bac53d9b75  lea rdi, [rsp]
000076bac53d9b79  mov esi, 0x00
000076bac53d9b7e  mov rax, 0x5641B0A3C530
000076bac53d9b88  call rax
000076bac53d9b8a  movaps xmm7, [rsp]
000076bac53d9b8e  add rsp, 0x30
000076bac53d9b92  vmovaps xmm0, [rsp]
000076bac53d9b97  vmovaps xmm1, [rsp+0x10]
000076bac53d9b9d  vmovaps xmm2, [rsp+0x20]
000076bac53d9ba3  vmovaps xmm3, [rsp+0x30]
000076bac53d9ba9  vmovaps xmm4, [rsp+0x40]
000076bac53d9baf  vmovaps xmm5, [rsp+0x50]
000076bac53d9bb5  vmovaps xmm6, [rsp+0x60]
000076bac53d9bbb  vmovaps xmm8, [rsp+0x70]
000076bac53d9bc1  vmovaps xmm9, [rsp+0x80]
000076bac53d9bca  vmovaps xmm10, [rsp+0x90]
000076bac53d9bd3  vmovaps xmm11, [rsp+0xA0]
000076bac53d9bdc  vmovaps xmm12, [rsp+0xB0]
000076bac53d9be5  vmovaps xmm13, [rsp+0xC0]
000076bac53d9bee  vmovaps xmm14, [rsp+0xD0]
000076bac53d9bf7  vmovaps xmm15, [rsp+0xE0]
000076bac53d9c00  add rsp, 0xF0
000076bac53d9c07  pop r11
000076bac53d9c09  pop r10
000076bac53d9c0b  pop r9
000076bac53d9c0d  pop r8
000076bac53d9c0f  pop rsi
000076bac53d9c10  pop rdi
000076bac53d9c11  pop rdx
000076bac53d9c12  pop rcx
000076bac53d9c13  pop rax
000076bac53d9c14  add rsp, 0x08
000076bac53d9c18  jmp 0x000076BAC53D8BA8
000076bac53d9c1d  sub rsp, 0x08
000076bac53d9c21  push rax
000076bac53d9c22  push rcx
000076bac53d9c23  push rdx
000076bac53d9c24  push rdi
000076bac53d9c25  push rsi
000076bac53d9c26  push r8
000076bac53d9c28  push r9
000076bac53d9c2a  push r10
000076bac53d9c2c  push r11
000076bac53d9c2e  sub rsp, 0xF0
000076bac53d9c35  vmovaps [rsp], xmm0
000076bac53d9c3a  vmovaps [rsp+0x10], xmm1
000076bac53d9c40  vmovaps [rsp+0x20], xmm2
000076bac53d9c46  vmovaps [rsp+0x30], xmm3
000076bac53d9c4c  vmovaps [rsp+0x40], xmm4
000076bac53d9c52  vmovaps [rsp+0x50], xmm5
000076bac53d9c58  vmovaps [rsp+0x60], xmm6
000076bac53d9c5e  vmovaps [rsp+0x70], xmm7
000076bac53d9c64  vmovaps [rsp+0x80], xmm8
000076bac53d9c6d  vmovaps [rsp+0x90], xmm10
000076bac53d9c76  vmovaps [rsp+0xA0], xmm11
000076bac53d9c7f  vmovaps [rsp+0xB0], xmm12
000076bac53d9c88  vmovaps [rsp+0xC0], xmm13
000076bac53d9c91  vmovaps [rsp+0xD0], xmm14
000076bac53d9c9a  vmovaps [rsp+0xE0], xmm15
000076bac53d9ca3  sub rsp, 0x30
000076bac53d9ca7  movaps [rsp], xmm9
000076bac53d9cac  movaps [rsp+0x10], xmm12
000076bac53d9cb2  movaps [rsp+0x20], xmm10
000076bac53d9cb8  lea rdi, [rsp]
000076bac53d9cbc  mov esi, 0x00
000076bac53d9cc1  mov rax, 0x5641B0A3C530
000076bac53d9ccb  call rax
000076bac53d9ccd  movaps xmm9, [rsp]
000076bac53d9cd2  add rsp, 0x30
000076bac53d9cd6  vmovaps xmm0, [rsp]
000076bac53d9cdb  vmovaps xmm1, [rsp+0x10]
000076bac53d9ce1  vmovaps xmm2, [rsp+0x20]
000076bac53d9ce7  vmovaps xmm3, [rsp+0x30]
000076bac53d9ced  vmovaps xmm4, [rsp+0x40]
000076bac53d9cf3  vmovaps xmm5, [rsp+0x50]
000076bac53d9cf9  vmovaps xmm6, [rsp+0x60]
000076bac53d9cff  vmovaps xmm7, [rsp+0x70]
000076bac53d9d05  vmovaps xmm8, [rsp+0x80]
000076bac53d9d0e  vmovaps xmm10, [rsp+0x90]
000076bac53d9d17  vmovaps xmm11, [rsp+0xA0]
000076bac53d9d20  vmovaps xmm12, [rsp+0xB0]
000076bac53d9d29  vmovaps xmm13, [rsp+0xC0]
000076bac53d9d32  vmovaps xmm14, [rsp+0xD0]
000076bac53d9d3b  vmovaps xmm15, [rsp+0xE0]
000076bac53d9d44  add rsp, 0xF0
000076bac53d9d4b  pop r11
000076bac53d9d4d  pop r10
000076bac53d9d4f  pop r9
000076bac53d9d51  pop r8
000076bac53d9d53  pop rsi
000076bac53d9d54  pop rdi
000076bac53d9d55  pop rdx
000076bac53d9d56  pop rcx
000076bac53d9d57  pop rax
000076bac53d9d58  add rsp, 0x08
000076bac53d9d5c  jmp 0x000076BAC53D8BCC
000076bac53d9d61  sub rsp, 0x08
000076bac53d9d65  push rax
000076bac53d9d66  push rcx
000076bac53d9d67  push rdx
000076bac53d9d68  push rdi
000076bac53d9d69  push rsi
000076bac53d9d6a  push r8
000076bac53d9d6c  push r9
000076bac53d9d6e  push r10
000076bac53d9d70  push r11
000076bac53d9d72  sub rsp, 0xF0
000076bac53d9d79  vmovaps [rsp], xmm0
000076bac53d9d7e  vmovaps [rsp+0x10], xmm1
000076bac53d9d84  vmovaps [rsp+0x20], xmm2
000076bac53d9d8a  vmovaps [rsp+0x30], xmm3
000076bac53d9d90  vmovaps [rsp+0x40], xmm4
000076bac53d9d96  vmovaps [rsp+0x50], xmm5
000076bac53d9d9c  vmovaps [rsp+0x60], xmm6
000076bac53d9da2  vmovaps [rsp+0x70], xmm7
000076bac53d9da8  vmovaps [rsp+0x80], xmm8
000076bac53d9db1  vmovaps [rsp+0x90], xmm9
000076bac53d9dba  vmovaps [rsp+0xA0], xmm11
000076bac53d9dc3  vmovaps [rsp+0xB0], xmm12
000076bac53d9dcc  vmovaps [rsp+0xC0], xmm13
000076bac53d9dd5  vmovaps [rsp+0xD0], xmm14
000076bac53d9dde  vmovaps [rsp+0xE0], xmm15
000076bac53d9de7  sub rsp, 0x30
000076bac53d9deb  movaps [rsp], xmm10
000076bac53d9df0  movaps [rsp+0x10], xmm12
000076bac53d9df6  movaps [rsp+0x20], xmm11
000076bac53d9dfc  lea rdi, [rsp]
000076bac53d9e00  mov esi, 0x00
000076bac53d9e05  mov rax, 0x5641B0A3C530
000076bac53d9e0f  call rax
000076bac53d9e11  movaps xmm10, [rsp]
000076bac53d9e16  add rsp, 0x30
000076bac53d9e1a  vmovaps xmm0, [rsp]
000076bac53d9e1f  vmovaps xmm1, [rsp+0x10]
000076bac53d9e25  vmovaps xmm2, [rsp+0x20]
000076bac53d9e2b  vmovaps xmm3, [rsp+0x30]
000076bac53d9e31  vmovaps xmm4, [rsp+0x40]
000076bac53d9e37  vmovaps xmm5, [rsp+0x50]
000076bac53d9e3d  vmovaps xmm6, [rsp+0x60]
000076bac53d9e43  vmovaps xmm7, [rsp+0x70]
000076bac53d9e49  vmovaps xmm8, [rsp+0x80]
000076bac53d9e52  vmovaps xmm9, [rsp+0x90]
000076bac53d9e5b  vmovaps xmm11, [rsp+0xA0]
000076bac53d9e64  vmovaps xmm12, [rsp+0xB0]
000076bac53d9e6d  vmovaps xmm13, [rsp+0xC0]
000076bac53d9e76  vmovaps xmm14, [rsp+0xD0]
000076bac53d9e7f  vmovaps xmm15, [rsp+0xE0]
000076bac53d9e88  add rsp, 0xF0
000076bac53d9e8f  pop r11
000076bac53d9e91  pop r10
000076bac53d9e93  pop r9
000076bac53d9e95  pop r8
000076bac53d9e97  pop rsi
000076bac53d9e98  pop rdi
000076bac53d9e99  pop rdx
000076bac53d9e9a  pop rcx
000076bac53d9e9b  pop rax
000076bac53d9e9c  add rsp, 0x08
000076bac53d9ea0  jmp 0x000076BAC53D8BE6
000076bac53d9ea5  sub rsp, 0x08
000076bac53d9ea9  push rax
000076bac53d9eaa  push rcx
000076bac53d9eab  push rdx
000076bac53d9eac  push rdi
000076bac53d9ead  push rsi
000076bac53d9eae  push r8
000076bac53d9eb0  push r9
000076bac53d9eb2  push r10
000076bac53d9eb4  push r11
000076bac53d9eb6  sub rsp, 0xF0
000076bac53d9ebd  vmovaps [rsp], xmm0
000076bac53d9ec2  vmovaps [rsp+0x10], xmm1
000076bac53d9ec8  vmovaps [rsp+0x20], xmm2
000076bac53d9ece  vmovaps [rsp+0x30], xmm3
000076bac53d9ed4  vmovaps [rsp+0x40], xmm4
000076bac53d9eda  vmovaps [rsp+0x50], xmm5
000076bac53d9ee0  vmovaps [rsp+0x60], xmm7
000076bac53d9ee6  vmovaps [rsp+0x70], xmm8
000076bac53d9eec  vmovaps [rsp+0x80], xmm9
000076bac53d9ef5  vmovaps [rsp+0x90], xmm10
000076bac53d9efe  vmovaps [rsp+0xA0], xmm11
000076bac53d9f07  vmovaps [rsp+0xB0], xmm12
000076bac53d9f10  vmovaps [rsp+0xC0], xmm13
000076bac53d9f19  vmovaps [rsp+0xD0], xmm14
000076bac53d9f22  vmovaps [rsp+0xE0], xmm15
000076bac53d9f2b  sub rsp, 0x30
000076bac53d9f2f  movaps [rsp], xmm6
000076bac53d9f33  movaps [rsp+0x10], xmm12
000076bac53d9f39  movaps [rsp+0x20], xmm11
000076bac53d9f3f  lea rdi, [rsp]
000076bac53d9f43  mov esi, 0x00
000076bac53d9f48  mov rax, 0x5641B0A3C530
000076bac53d9f52  call rax
000076bac53d9f54  movaps xmm6, [rsp]
000076bac53d9f58  add rsp, 0x30
000076bac53d9f5c  vmovaps xmm0, [rsp]
000076bac53d9f61  vmovaps xmm1, [rsp+0x10]
000076bac53d9f67  vmovaps xmm2, [rsp+0x20]
000076bac53d9f6d  vmovaps xmm3, [rsp+0x30]
000076bac53d9f73  vmovaps xmm4, [rsp+0x40]
000076bac53d9f79  vmovaps xmm5, [rsp+0x50]
000076bac53d9f7f  vmovaps xmm7, [rsp+0x60]
000076bac53d9f85  vmovaps xmm8, [rsp+0x70]
000076bac53d9f8b  vmovaps xmm9, [rsp+0x80]
000076bac53d9f94  vmovaps xmm10, [rsp+0x90]
000076bac53d9f9d  vmovaps xmm11, [rsp+0xA0]
000076bac53d9fa6  vmovaps xmm12, [rsp+0xB0]
000076bac53d9faf  vmovaps xmm13, [rsp+0xC0]
000076bac53d9fb8  vmovaps xmm14, [rsp+0xD0]
000076bac53d9fc1  vmovaps xmm15, [rsp+0xE0]
000076bac53d9fca  add rsp, 0xF0
000076bac53d9fd1  pop r11
000076bac53d9fd3  pop r10
000076bac53d9fd5  pop r9
000076bac53d9fd7  pop r8
000076bac53d9fd9  pop rsi
000076bac53d9fda  pop rdi
000076bac53d9fdb  pop rdx
000076bac53d9fdc  pop rcx
000076bac53d9fdd  pop rax
000076bac53d9fde  add rsp, 0x08
000076bac53d9fe2  jmp 0x000076BAC53D8C07
000076bac53d9fe7  sub rsp, 0x08
000076bac53d9feb  push rax
000076bac53d9fec  push rcx
000076bac53d9fed  push rdx
000076bac53d9fee  push rdi
000076bac53d9fef  push rsi
000076bac53d9ff0  push r8
000076bac53d9ff2  push r9
000076bac53d9ff4  push r10
000076bac53d9ff6  push r11
000076bac53d9ff8  sub rsp, 0xF0
000076bac53d9fff  vmovaps [rsp], xmm0
000076bac53da004  vmovaps [rsp+0x10], xmm1
000076bac53da00a  vmovaps [rsp+0x20], xmm2
000076bac53da010  vmovaps [rsp+0x30], xmm4
000076bac53da016  vmovaps [rsp+0x40], xmm5
000076bac53da01c  vmovaps [rsp+0x50], xmm6
000076bac53da022  vmovaps [rsp+0x60], xmm7
000076bac53da028  vmovaps [rsp+0x70], xmm8
000076bac53da02e  vmovaps [rsp+0x80], xmm9
000076bac53da037  vmovaps [rsp+0x90], xmm10
000076bac53da040  vmovaps [rsp+0xA0], xmm11
000076bac53da049  vmovaps [rsp+0xB0], xmm12
000076bac53da052  vmovaps [rsp+0xC0], xmm13
000076bac53da05b  vmovaps [rsp+0xD0], xmm14
000076bac53da064  vmovaps [rsp+0xE0], xmm15
000076bac53da06d  sub rsp, 0x30
000076bac53da071  movaps [rsp], xmm3
000076bac53da075  movaps [rsp+0x10], xmm5
000076bac53da07a  movaps [rsp+0x20], xmm4
000076bac53da07f  lea rdi, [rsp]
000076bac53da083  mov esi, 0x00
000076bac53da088  mov rax, 0x5641B0A3C530
000076bac53da092  call rax
000076bac53da094  movaps xmm3, [rsp]
000076bac53da098  add rsp, 0x30
000076bac53da09c  vmovaps xmm0, [rsp]
000076bac53da0a1  vmovaps xmm1, [rsp+0x10]
000076bac53da0a7  vmovaps xmm2, [rsp+0x20]
000076bac53da0ad  vmovaps xmm4, [rsp+0x30]
000076bac53da0b3  vmovaps xmm5, [rsp+0x40]
000076bac53da0b9  vmovaps xmm6, [rsp+0x50]
000076bac53da0bf  vmovaps xmm7, [rsp+0x60]
000076bac53da0c5  vmovaps xmm8, [rsp+0x70]
000076bac53da0cb  vmovaps xmm9, [rsp+0x80]
000076bac53da0d4  vmovaps xmm10, [rsp+0x90]
000076bac53da0dd  vmovaps xmm11, [rsp+0xA0]
000076bac53da0e6  vmovaps xmm12, [rsp+0xB0]
000076bac53da0ef  vmovaps xmm13, [rsp+0xC0]
000076bac53da0f8  vmovaps xmm14, [rsp+0xD0]
000076bac53da101  vmovaps xmm15, [rsp+0xE0]
000076bac53da10a  add rsp, 0xF0
000076bac53da111  pop r11
000076bac53da113  pop r10
000076bac53da115  pop r9
000076bac53da117  pop r8
000076bac53da119  pop rsi
000076bac53da11a  pop rdi
000076bac53da11b  pop rdx
000076bac53da11c  pop rcx
000076bac53da11d  pop rax
000076bac53da11e  add rsp, 0x08
000076bac53da122  jmp 0x000076BAC53D8C68
000076bac53da127  sub rsp, 0x08
000076bac53da12b  push rax
000076bac53da12c  push rcx
000076bac53da12d  push rdx
000076bac53da12e  push rdi
000076bac53da12f  push rsi
000076bac53da130  push r8
000076bac53da132  push r9
000076bac53da134  push r10
000076bac53da136  push r11
000076bac53da138  sub rsp, 0xF0
000076bac53da13f  vmovaps [rsp], xmm0
000076bac53da144  vmovaps [rsp+0x10], xmm1
000076bac53da14a  vmovaps [rsp+0x20], xmm2
000076bac53da150  vmovaps [rsp+0x30], xmm3
000076bac53da156  vmovaps [rsp+0x40], xmm4
000076bac53da15c  vmovaps [rsp+0x50], xmm6
000076bac53da162  vmovaps [rsp+0x60], xmm7
000076bac53da168  vmovaps [rsp+0x70], xmm8
000076bac53da16e  vmovaps [rsp+0x80], xmm9
000076bac53da177  vmovaps [rsp+0x90], xmm10
000076bac53da180  vmovaps [rsp+0xA0], xmm11
000076bac53da189  vmovaps [rsp+0xB0], xmm12
000076bac53da192  vmovaps [rsp+0xC0], xmm13
000076bac53da19b  vmovaps [rsp+0xD0], xmm14
000076bac53da1a4  vmovaps [rsp+0xE0], xmm15
000076bac53da1ad  sub rsp, 0x30
000076bac53da1b1  movaps [rsp], xmm5
000076bac53da1b5  movaps [rsp+0x10], xmm8
000076bac53da1bb  movaps [rsp+0x20], xmm15
000076bac53da1c1  lea rdi, [rsp]
000076bac53da1c5  mov esi, 0x00
000076bac53da1ca  mov rax, 0x5641B0A3C530
000076bac53da1d4  call rax
000076bac53da1d6  movaps xmm5, [rsp]
000076bac53da1da  add rsp, 0x30
000076bac53da1de  vmovaps xmm0, [rsp]
000076bac53da1e3  vmovaps xmm1, [rsp+0x10]
000076bac53da1e9  vmovaps xmm2, [rsp+0x20]
000076bac53da1ef  vmovaps xmm3, [rsp+0x30]
000076bac53da1f5  vmovaps xmm4, [rsp+0x40]
000076bac53da1fb  vmovaps xmm6, [rsp+0x50]
000076bac53da201  vmovaps xmm7, [rsp+0x60]
000076bac53da207  vmovaps xmm8, [rsp+0x70]
000076bac53da20d  vmovaps xmm9, [rsp+0x80]
000076bac53da216  vmovaps xmm10, [rsp+0x90]
000076bac53da21f  vmovaps xmm11, [rsp+0xA0]
000076bac53da228  vmovaps xmm12, [rsp+0xB0]
000076bac53da231  vmovaps xmm13, [rsp+0xC0]
000076bac53da23a  vmovaps xmm14, [rsp+0xD0]
000076bac53da243  vmovaps xmm15, [rsp+0xE0]
000076bac53da24c  add rsp, 0xF0
000076bac53da253  pop r11
000076bac53da255  pop r10
000076bac53da257  pop r9
000076bac53da259  pop r8
000076bac53da25b  pop rsi
000076bac53da25c  pop rdi
000076bac53da25d  pop rdx
000076bac53da25e  pop rcx
000076bac53da25f  pop rax
000076bac53da260  add rsp, 0x08
000076bac53da264  jmp 0x000076BAC53D8CA0
000076bac53da269  sub rsp, 0x08
000076bac53da26d  push rax
000076bac53da26e  push rcx
000076bac53da26f  push rdx
000076bac53da270  push rdi
000076bac53da271  push rsi
000076bac53da272  push r8
000076bac53da274  push r9
000076bac53da276  push r10
000076bac53da278  push r11
000076bac53da27a  sub rsp, 0xF0
000076bac53da281  vmovaps [rsp], xmm0
000076bac53da286  vmovaps [rsp+0x10], xmm1
000076bac53da28c  vmovaps [rsp+0x20], xmm2
000076bac53da292  vmovaps [rsp+0x30], xmm3
000076bac53da298  vmovaps [rsp+0x40], xmm5
000076bac53da29e  vmovaps [rsp+0x50], xmm6
000076bac53da2a4  vmovaps [rsp+0x60], xmm7
000076bac53da2aa  vmovaps [rsp+0x70], xmm8
000076bac53da2b0  vmovaps [rsp+0x80], xmm9
000076bac53da2b9  vmovaps [rsp+0x90], xmm10
000076bac53da2c2  vmovaps [rsp+0xA0], xmm11
000076bac53da2cb  vmovaps [rsp+0xB0], xmm12
000076bac53da2d4  vmovaps [rsp+0xC0], xmm13
000076bac53da2dd  vmovaps [rsp+0xD0], xmm14
000076bac53da2e6  vmovaps [rsp+0xE0], xmm15
000076bac53da2ef  sub rsp, 0x30
000076bac53da2f3  movaps [rsp], xmm4
000076bac53da2f7  movaps [rsp+0x10], xmm9
000076bac53da2fd  movaps [rsp+0x20], xmm8
000076bac53da303  lea rdi, [rsp]
000076bac53da307  mov esi, 0x00
000076bac53da30c  mov rax, 0x5641B0A3C530
000076bac53da316  call rax
000076bac53da318  movaps xmm4, [rsp]
000076bac53da31c  add rsp, 0x30
000076bac53da320  vmovaps xmm0, [rsp]
000076bac53da325  vmovaps xmm1, [rsp+0x10]
000076bac53da32b  vmovaps xmm2, [rsp+0x20]
000076bac53da331  vmovaps xmm3, [rsp+0x30]
000076bac53da337  vmovaps xmm5, [rsp+0x40]
000076bac53da33d  vmovaps xmm6, [rsp+0x50]
000076bac53da343  vmovaps xmm7, [rsp+0x60]
000076bac53da349  vmovaps xmm8, [rsp+0x70]
000076bac53da34f  vmovaps xmm9, [rsp+0x80]
000076bac53da358  vmovaps xmm10, [rsp+0x90]
000076bac53da361  vmovaps xmm11, [rsp+0xA0]
000076bac53da36a  vmovaps xmm12, [rsp+0xB0]
000076bac53da373  vmovaps xmm13, [rsp+0xC0]
000076bac53da37c  vmovaps xmm14, [rsp+0xD0]
000076bac53da385  vmovaps xmm15, [rsp+0xE0]
000076bac53da38e  add rsp, 0xF0
000076bac53da395  pop r11
000076bac53da397  pop r10
000076bac53da399  pop r9
000076bac53da39b  pop r8
000076bac53da39d  pop rsi
000076bac53da39e  pop rdi
000076bac53da39f  pop rdx
000076bac53da3a0  pop rcx
000076bac53da3a1  pop rax
000076bac53da3a2  add rsp, 0x08
000076bac53da3a6  jmp 0x000076BAC53D8CC1
000076bac53da3ab  sub rsp, 0x08
000076bac53da3af  push rax
000076bac53da3b0  push rcx
000076bac53da3b1  push rdx
000076bac53da3b2  push rdi
000076bac53da3b3  push rsi
000076bac53da3b4  push r8
000076bac53da3b6  push r9
000076bac53da3b8  push r10
000076bac53da3ba  push r11
000076bac53da3bc  sub rsp, 0xF0
000076bac53da3c3  vmovaps [rsp], xmm0
000076bac53da3c8  vmovaps [rsp+0x10], xmm1
000076bac53da3ce  vmovaps [rsp+0x20], xmm2
000076bac53da3d4  vmovaps [rsp+0x30], xmm3
000076bac53da3da  vmovaps [rsp+0x40], xmm4
000076bac53da3e0  vmovaps [rsp+0x50], xmm5
000076bac53da3e6  vmovaps [rsp+0x60], xmm6
000076bac53da3ec  vmovaps [rsp+0x70], xmm7
000076bac53da3f2  vmovaps [rsp+0x80], xmm8
000076bac53da3fb  vmovaps [rsp+0x90], xmm10
000076bac53da404  vmovaps [rsp+0xA0], xmm11
000076bac53da40d  vmovaps [rsp+0xB0], xmm12
000076bac53da416  vmovaps [rsp+0xC0], xmm13
000076bac53da41f  vmovaps [rsp+0xD0], xmm14
000076bac53da428  vmovaps [rsp+0xE0], xmm15
000076bac53da431  sub rsp, 0x30
000076bac53da435  movaps [rsp], xmm9
000076bac53da43a  movaps [rsp+0x10], xmm10
000076bac53da440  movaps [rsp+0x20], xmm8
000076bac53da446  lea rdi, [rsp]
000076bac53da44a  mov esi, 0x00
000076bac53da44f  mov rax, 0x5641B0A3C530
000076bac53da459  call rax
000076bac53da45b  movaps xmm9, [rsp]
000076bac53da460  add rsp, 0x30
000076bac53da464  vmovaps xmm0, [rsp]
000076bac53da469  vmovaps xmm1, [rsp+0x10]
000076bac53da46f  vmovaps xmm2, [rsp+0x20]
000076bac53da475  vmovaps xmm3, [rsp+0x30]
000076bac53da47b  vmovaps xmm4, [rsp+0x40]
000076bac53da481  vmovaps xmm5, [rsp+0x50]
000076bac53da487  vmovaps xmm6, [rsp+0x60]
000076bac53da48d  vmovaps xmm7, [rsp+0x70]
000076bac53da493  vmovaps xmm8, [rsp+0x80]
000076bac53da49c  vmovaps xmm10, [rsp+0x90]
000076bac53da4a5  vmovaps xmm11, [rsp+0xA0]
000076bac53da4ae  vmovaps xmm12, [rsp+0xB0]
000076bac53da4b7  vmovaps xmm13, [rsp+0xC0]
000076bac53da4c0  vmovaps xmm14, [rsp+0xD0]
000076bac53da4c9  vmovaps xmm15, [rsp+0xE0]
000076bac53da4d2  add rsp, 0xF0
000076bac53da4d9  pop r11
000076bac53da4db  pop r10
000076bac53da4dd  pop r9
000076bac53da4df  pop r8
000076bac53da4e1  pop rsi
000076bac53da4e2  pop rdi
000076bac53da4e3  pop rdx
000076bac53da4e4  pop rcx
000076bac53da4e5  pop rax
000076bac53da4e6  add rsp, 0x08
000076bac53da4ea  jmp 0x000076BAC53D8CDB
000076bac53da4ef  call 0x000076BAC52D64F0
000076bac53da4f4  jmp 0x000076BAC53D8DF5
000076bac53da4f9  call 0x000076BAC52D64F0
000076bac53da4fe  jmp 0x000076BAC53D8E0B
000076bac53da503  sub rsp, 0x08
000076bac53da507  push rax
000076bac53da508  push rcx
000076bac53da509  push rdx
000076bac53da50a  push rdi
000076bac53da50b  push rsi
000076bac53da50c  push r8
000076bac53da50e  push r9
000076bac53da510  push r10
000076bac53da512  push r11
000076bac53da514  sub rsp, 0xF0
000076bac53da51b  vmovaps [rsp], xmm0
000076bac53da520  vmovaps [rsp+0x10], xmm2
000076bac53da526  vmovaps [rsp+0x20], xmm3
000076bac53da52c  vmovaps [rsp+0x30], xmm4
000076bac53da532  vmovaps [rsp+0x40], xmm5
000076bac53da538  vmovaps [rsp+0x50], xmm6
000076bac53da53e  vmovaps [rsp+0x60], xmm7
000076bac53da544  vmovaps [rsp+0x70], xmm8
000076bac53da54a  vmovaps [rsp+0x80], xmm9
000076bac53da553  vmovaps [rsp+0x90], xmm10
000076bac53da55c  vmovaps [rsp+0xA0], xmm11
000076bac53da565  vmovaps [rsp+0xB0], xmm12
000076bac53da56e  vmovaps [rsp+0xC0], xmm13
000076bac53da577  vmovaps [rsp+0xD0], xmm14
000076bac53da580  vmovaps [rsp+0xE0], xmm15
000076bac53da589  sub rsp, 0x30
000076bac53da58d  movaps [rsp], xmm1
000076bac53da591  movaps [rsp+0x10], xmm6
000076bac53da596  movaps [rsp+0x20], xmm15
000076bac53da59c  lea rdi, [rsp]
000076bac53da5a0  mov esi, 0x00
000076bac53da5a5  mov rax, 0x5641B0A3C530
000076bac53da5af  call rax
000076bac53da5b1  movaps xmm1, [rsp]
000076bac53da5b5  add rsp, 0x30
000076bac53da5b9  vmovaps xmm0, [rsp]
000076bac53da5be  vmovaps xmm2, [rsp+0x10]
000076bac53da5c4  vmovaps xmm3, [rsp+0x20]
000076bac53da5ca  vmovaps xmm4, [rsp+0x30]
000076bac53da5d0  vmovaps xmm5, [rsp+0x40]
000076bac53da5d6  vmovaps xmm6, [rsp+0x50]
000076bac53da5dc  vmovaps xmm7, [rsp+0x60]
000076bac53da5e2  vmovaps xmm8, [rsp+0x70]
000076bac53da5e8  vmovaps xmm9, [rsp+0x80]
000076bac53da5f1  vmovaps xmm10, [rsp+0x90]
000076bac53da5fa  vmovaps xmm11, [rsp+0xA0]
000076bac53da603  vmovaps xmm12, [rsp+0xB0]
000076bac53da60c  vmovaps xmm13, [rsp+0xC0]
000076bac53da615  vmovaps xmm14, [rsp+0xD0]
000076bac53da61e  vmovaps xmm15, [rsp+0xE0]
000076bac53da627  add rsp, 0xF0
000076bac53da62e  pop r11
000076bac53da630  pop r10
000076bac53da632  pop r9
000076bac53da634  pop r8
000076bac53da636  pop rsi
000076bac53da637  pop rdi
000076bac53da638  pop rdx
000076bac53da639  pop rcx
000076bac53da63a  pop rax
000076bac53da63b  add rsp, 0x08
000076bac53da63f  jmp 0x000076BAC53D8E48
000076bac53da644  call 0x000076BAC52E5820
000076bac53da649  jmp 0x000076BAC53D8E55
000076bac53da64e  sub rsp, 0x08
000076bac53da652  push rax
000076bac53da653  push rcx
000076bac53da654  push rdx
000076bac53da655  push rdi
000076bac53da656  push rsi
000076bac53da657  push r8
000076bac53da659  push r9
000076bac53da65b  push r10
000076bac53da65d  push r11
000076bac53da65f  sub rsp, 0xF0
000076bac53da666  vmovaps [rsp], xmm0
000076bac53da66b  vmovaps [rsp+0x10], xmm1
000076bac53da671  vmovaps [rsp+0x20], xmm2
000076bac53da677  vmovaps [rsp+0x30], xmm3
000076bac53da67d  vmovaps [rsp+0x40], xmm4
000076bac53da683  vmovaps [rsp+0x50], xmm5
000076bac53da689  vmovaps [rsp+0x60], xmm6
000076bac53da68f  vmovaps [rsp+0x70], xmm7
000076bac53da695  vmovaps [rsp+0x80], xmm8
000076bac53da69e  vmovaps [rsp+0x90], xmm9
000076bac53da6a7  vmovaps [rsp+0xA0], xmm10
000076bac53da6b0  vmovaps [rsp+0xB0], xmm11
000076bac53da6b9  vmovaps [rsp+0xC0], xmm12
000076bac53da6c2  vmovaps [rsp+0xD0], xmm13
000076bac53da6cb  vmovaps [rsp+0xE0], xmm15
000076bac53da6d4  sub rsp, 0x30
000076bac53da6d8  movaps [rsp], xmm14
000076bac53da6dd  movaps [rsp+0x10], xmm4
000076bac53da6e2  movaps [rsp+0x20], xmm3
000076bac53da6e7  lea rdi, [rsp]
000076bac53da6eb  mov esi, 0x00
000076bac53da6f0  mov rax, 0x5641B0A3C530
000076bac53da6fa  call rax
000076bac53da6fc  movaps xmm14, [rsp]
000076bac53da701  add rsp, 0x30
000076bac53da705  vmovaps xmm0, [rsp]
000076bac53da70a  vmovaps xmm1, [rsp+0x10]
000076bac53da710  vmovaps xmm2, [rsp+0x20]
000076bac53da716  vmovaps xmm3, [rsp+0x30]
000076bac53da71c  vmovaps xmm4, [rsp+0x40]
000076bac53da722  vmovaps xmm5, [rsp+0x50]
000076bac53da728  vmovaps xmm6, [rsp+0x60]
000076bac53da72e  vmovaps xmm7, [rsp+0x70]
000076bac53da734  vmovaps xmm8, [rsp+0x80]
000076bac53da73d  vmovaps xmm9, [rsp+0x90]
000076bac53da746  vmovaps xmm10, [rsp+0xA0]
000076bac53da74f  vmovaps xmm11, [rsp+0xB0]
000076bac53da758  vmovaps xmm12, [rsp+0xC0]
000076bac53da761  vmovaps xmm13, [rsp+0xD0]
000076bac53da76a  vmovaps xmm15, [rsp+0xE0]
000076bac53da773  add rsp, 0xF0
000076bac53da77a  pop r11
000076bac53da77c  pop r10
000076bac53da77e  pop r9
000076bac53da780  pop r8
000076bac53da782  pop rsi
000076bac53da783  pop rdi
000076bac53da784  pop rdx
000076bac53da785  pop rcx
000076bac53da786  pop rax
000076bac53da787  add rsp, 0x08
000076bac53da78b  jmp 0x000076BAC53D8E6F
000076bac53da790  sub rsp, 0x08
000076bac53da794  push rax
000076bac53da795  push rcx
000076bac53da796  push rdx
000076bac53da797  push rdi
000076bac53da798  push rsi
000076bac53da799  push r8
000076bac53da79b  push r9
000076bac53da79d  push r10
000076bac53da79f  push r11
000076bac53da7a1  sub rsp, 0xF0
000076bac53da7a8  vmovaps [rsp], xmm0
000076bac53da7ad  vmovaps [rsp+0x10], xmm1
000076bac53da7b3  vmovaps [rsp+0x20], xmm2
000076bac53da7b9  vmovaps [rsp+0x30], xmm3
000076bac53da7bf  vmovaps [rsp+0x40], xmm4
000076bac53da7c5  vmovaps [rsp+0x50], xmm5
000076bac53da7cb  vmovaps [rsp+0x60], xmm7
000076bac53da7d1  vmovaps [rsp+0x70], xmm8
000076bac53da7d7  vmovaps [rsp+0x80], xmm9
000076bac53da7e0  vmovaps [rsp+0x90], xmm10
000076bac53da7e9  vmovaps [rsp+0xA0], xmm11
000076bac53da7f2  vmovaps [rsp+0xB0], xmm12
000076bac53da7fb  vmovaps [rsp+0xC0], xmm13
000076bac53da804  vmovaps [rsp+0xD0], xmm14
000076bac53da80d  vmovaps [rsp+0xE0], xmm15
000076bac53da816  sub rsp, 0x30
000076bac53da81a  movaps [rsp], xmm6
000076bac53da81e  movaps [rsp+0x10], xmm9
000076bac53da824  movaps [rsp+0x20], xmm7
000076bac53da829  lea rdi, [rsp]
000076bac53da82d  mov esi, 0x00
000076bac53da832  mov rax, 0x5641B0A3C530
000076bac53da83c  call rax
000076bac53da83e  movaps xmm6, [rsp]
000076bac53da842  add rsp, 0x30
000076bac53da846  vmovaps xmm0, [rsp]
000076bac53da84b  vmovaps xmm1, [rsp+0x10]
000076bac53da851  vmovaps xmm2, [rsp+0x20]
000076bac53da857  vmovaps xmm3, [rsp+0x30]
000076bac53da85d  vmovaps xmm4, [rsp+0x40]
000076bac53da863  vmovaps xmm5, [rsp+0x50]
000076bac53da869  vmovaps xmm7, [rsp+0x60]
000076bac53da86f  vmovaps xmm8, [rsp+0x70]
000076bac53da875  vmovaps xmm9, [rsp+0x80]
000076bac53da87e  vmovaps xmm10, [rsp+0x90]
000076bac53da887  vmovaps xmm11, [rsp+0xA0]
000076bac53da890  vmovaps xmm12, [rsp+0xB0]
000076bac53da899  vmovaps xmm13, [rsp+0xC0]
000076bac53da8a2  vmovaps xmm14, [rsp+0xD0]
000076bac53da8ab  vmovaps xmm15, [rsp+0xE0]
000076bac53da8b4  add rsp, 0xF0
000076bac53da8bb  pop r11
000076bac53da8bd  pop r10
000076bac53da8bf  pop r9
000076bac53da8c1  pop r8
000076bac53da8c3  pop rsi
000076bac53da8c4  pop rdi
000076bac53da8c5  pop rdx
000076bac53da8c6  pop rcx
000076bac53da8c7  pop rax
000076bac53da8c8  add rsp, 0x08
000076bac53da8cc  jmp 0x000076BAC53D8E87
000076bac53da8d1  sub rsp, 0x08
000076bac53da8d5  push rax
000076bac53da8d6  push rcx
000076bac53da8d7  push rdx
000076bac53da8d8  push rdi
000076bac53da8d9  push rsi
000076bac53da8da  push r8
000076bac53da8dc  push r9
000076bac53da8de  push r10
000076bac53da8e0  push r11
000076bac53da8e2  sub rsp, 0xF0
000076bac53da8e9  vmovaps [rsp], xmm0
000076bac53da8ee  vmovaps [rsp+0x10], xmm1
000076bac53da8f4  vmovaps [rsp+0x20], xmm2
000076bac53da8fa  vmovaps [rsp+0x30], xmm3
000076bac53da900  vmovaps [rsp+0x40], xmm4
000076bac53da906  vmovaps [rsp+0x50], xmm5
000076bac53da90c  vmovaps [rsp+0x60], xmm6
000076bac53da912  vmovaps [rsp+0x70], xmm8
000076bac53da918  vmovaps [rsp+0x80], xmm9
000076bac53da921  vmovaps [rsp+0x90], xmm10
000076bac53da92a  vmovaps [rsp+0xA0], xmm11
000076bac53da933  vmovaps [rsp+0xB0], xmm12
000076bac53da93c  vmovaps [rsp+0xC0], xmm13
000076bac53da945  vmovaps [rsp+0xD0], xmm14
000076bac53da94e  vmovaps [rsp+0xE0], xmm15
000076bac53da957  sub rsp, 0x30
000076bac53da95b  movaps [rsp], xmm7
000076bac53da95f  movaps [rsp+0x10], xmm4
000076bac53da964  movaps [rsp+0x20], xmm9
000076bac53da96a  lea rdi, [rsp]
000076bac53da96e  mov esi, 0x00
000076bac53da973  mov rax, 0x5641B0A3C530
000076bac53da97d  call rax
000076bac53da97f  movaps xmm7, [rsp]
000076bac53da983  add rsp, 0x30
000076bac53da987  vmovaps xmm0, [rsp]
000076bac53da98c  vmovaps xmm1, [rsp+0x10]
000076bac53da992  vmovaps xmm2, [rsp+0x20]
000076bac53da998  vmovaps xmm3, [rsp+0x30]
000076bac53da99e  vmovaps xmm4, [rsp+0x40]
000076bac53da9a4  vmovaps xmm5, [rsp+0x50]
000076bac53da9aa  vmovaps xmm6, [rsp+0x60]
000076bac53da9b0  vmovaps xmm8, [rsp+0x70]
000076bac53da9b6  vmovaps xmm9, [rsp+0x80]
000076bac53da9bf  vmovaps xmm10, [rsp+0x90]
000076bac53da9c8  vmovaps xmm11, [rsp+0xA0]
000076bac53da9d1  vmovaps xmm12, [rsp+0xB0]
000076bac53da9da  vmovaps xmm13, [rsp+0xC0]
000076bac53da9e3  vmovaps xmm14, [rsp+0xD0]
000076bac53da9ec  vmovaps xmm15, [rsp+0xE0]
000076bac53da9f5  add rsp, 0xF0
000076bac53da9fc  pop r11
000076bac53da9fe  pop r10
000076bac53daa00  pop r9
000076bac53daa02  pop r8
000076bac53daa04  pop rsi
000076bac53daa05  pop rdi
000076bac53daa06  pop rdx
000076bac53daa07  pop rcx
000076bac53daa08  pop rax
000076bac53daa09  add rsp, 0x08
000076bac53daa0d  jmp 0x000076BAC53D8EB4
000076bac53daa12  sub rsp, 0x08
000076bac53daa16  push rax
000076bac53daa17  push rcx
000076bac53daa18  push rdx
000076bac53daa19  push rdi
000076bac53daa1a  push rsi
000076bac53daa1b  push r8
000076bac53daa1d  push r9
000076bac53daa1f  push r10
000076bac53daa21  push r11
000076bac53daa23  sub rsp, 0xF0
000076bac53daa2a  vmovaps [rsp], xmm0
000076bac53daa2f  vmovaps [rsp+0x10], xmm1
000076bac53daa35  vmovaps [rsp+0x20], xmm2
000076bac53daa3b  vmovaps [rsp+0x30], xmm3
000076bac53daa41  vmovaps [rsp+0x40], xmm5
000076bac53daa47  vmovaps [rsp+0x50], xmm6
000076bac53daa4d  vmovaps [rsp+0x60], xmm7
000076bac53daa53  vmovaps [rsp+0x70], xmm8
000076bac53daa59  vmovaps [rsp+0x80], xmm9
000076bac53daa62  vmovaps [rsp+0x90], xmm10
000076bac53daa6b  vmovaps [rsp+0xA0], xmm11
000076bac53daa74  vmovaps [rsp+0xB0], xmm12
000076bac53daa7d  vmovaps [rsp+0xC0], xmm13
000076bac53daa86  vmovaps [rsp+0xD0], xmm14
000076bac53daa8f  vmovaps [rsp+0xE0], xmm15
000076bac53daa98  sub rsp, 0x30
000076bac53daa9c  movaps [rsp], xmm4
000076bac53daaa0  movaps [rsp+0x10], xmm15
000076bac53daaa6  movaps [rsp+0x20], xmm9
000076bac53daaac  lea rdi, [rsp]
000076bac53daab0  mov esi, 0x00
000076bac53daab5  mov rax, 0x5641B0A3C530
000076bac53daabf  call rax
000076bac53daac1  movaps xmm4, [rsp]
000076bac53daac5  add rsp, 0x30
000076bac53daac9  vmovaps xmm0, [rsp]
000076bac53daace  vmovaps xmm1, [rsp+0x10]
000076bac53daad4  vmovaps xmm2, [rsp+0x20]
000076bac53daada  vmovaps xmm3, [rsp+0x30]
000076bac53daae0  vmovaps xmm5, [rsp+0x40]
000076bac53daae6  vmovaps xmm6, [rsp+0x50]
000076bac53daaec  vmovaps xmm7, [rsp+0x60]
000076bac53daaf2  vmovaps xmm8, [rsp+0x70]
000076bac53daaf8  vmovaps xmm9, [rsp+0x80]
000076bac53dab01  vmovaps xmm10, [rsp+0x90]
000076bac53dab0a  vmovaps xmm11, [rsp+0xA0]
000076bac53dab13  vmovaps xmm12, [rsp+0xB0]
000076bac53dab1c  vmovaps xmm13, [rsp+0xC0]
000076bac53dab25  vmovaps xmm14, [rsp+0xD0]
000076bac53dab2e  vmovaps xmm15, [rsp+0xE0]
000076bac53dab37  add rsp, 0xF0
000076bac53dab3e  pop r11
000076bac53dab40  pop r10
000076bac53dab42  pop r9
000076bac53dab44  pop r8
000076bac53dab46  pop rsi
000076bac53dab47  pop rdi
000076bac53dab48  pop rdx
000076bac53dab49  pop rcx
000076bac53dab4a  pop rax
000076bac53dab4b  add rsp, 0x08
000076bac53dab4f  jmp 0x000076BAC53D8ED9
000076bac53dab54  call 0x000076BAC52E5820
000076bac53dab59  jmp 0x000076BAC53D8EE6
000076bac53dab5e  sub rsp, 0x08
000076bac53dab62  push rax
000076bac53dab63  push rcx
000076bac53dab64  push rdx
000076bac53dab65  push rdi
000076bac53dab66  push rsi
000076bac53dab67  push r8
000076bac53dab69  push r9
000076bac53dab6b  push r10
000076bac53dab6d  push r11
000076bac53dab6f  sub rsp, 0xF0
000076bac53dab76  vmovaps [rsp], xmm0
000076bac53dab7b  vmovaps [rsp+0x10], xmm1
000076bac53dab81  vmovaps [rsp+0x20], xmm2
000076bac53dab87  vmovaps [rsp+0x30], xmm4
000076bac53dab8d  vmovaps [rsp+0x40], xmm5
000076bac53dab93  vmovaps [rsp+0x50], xmm6
000076bac53dab99  vmovaps [rsp+0x60], xmm7
000076bac53dab9f  vmovaps [rsp+0x70], xmm8
000076bac53daba5  vmovaps [rsp+0x80], xmm9
000076bac53dabae  vmovaps [rsp+0x90], xmm10
000076bac53dabb7  vmovaps [rsp+0xA0], xmm11
000076bac53dabc0  vmovaps [rsp+0xB0], xmm12
000076bac53dabc9  vmovaps [rsp+0xC0], xmm13
000076bac53dabd2  vmovaps [rsp+0xD0], xmm14
000076bac53dabdb  vmovaps [rsp+0xE0], xmm15
000076bac53dabe4  sub rsp, 0x30
000076bac53dabe8  movaps [rsp], xmm3
000076bac53dabec  movaps [rsp+0x10], xmm1
000076bac53dabf1  movaps [rsp+0x20], xmm9
000076bac53dabf7  lea rdi, [rsp]
000076bac53dabfb  mov esi, 0x00
000076bac53dac00  mov rax, 0x5641B0A3C530
000076bac53dac0a  call rax
000076bac53dac0c  movaps xmm3, [rsp]
000076bac53dac10  add rsp, 0x30
000076bac53dac14  vmovaps xmm0, [rsp]
000076bac53dac19  vmovaps xmm1, [rsp+0x10]
000076bac53dac1f  vmovaps xmm2, [rsp+0x20]
000076bac53dac25  vmovaps xmm4, [rsp+0x30]
000076bac53dac2b  vmovaps xmm5, [rsp+0x40]
000076bac53dac31  vmovaps xmm6, [rsp+0x50]
000076bac53dac37  vmovaps xmm7, [rsp+0x60]
000076bac53dac3d  vmovaps xmm8, [rsp+0x70]
000076bac53dac43  vmovaps xmm9, [rsp+0x80]
000076bac53dac4c  vmovaps xmm10, [rsp+0x90]
000076bac53dac55  vmovaps xmm11, [rsp+0xA0]
000076bac53dac5e  vmovaps xmm12, [rsp+0xB0]
000076bac53dac67  vmovaps xmm13, [rsp+0xC0]
000076bac53dac70  vmovaps xmm14, [rsp+0xD0]
000076bac53dac79  vmovaps xmm15, [rsp+0xE0]
000076bac53dac82  add rsp, 0xF0
000076bac53dac89  pop r11
000076bac53dac8b  pop r10
000076bac53dac8d  pop r9
000076bac53dac8f  pop r8
000076bac53dac91  pop rsi
000076bac53dac92  pop rdi
000076bac53dac93  pop rdx
000076bac53dac94  pop rcx
000076bac53dac95  pop rax
000076bac53dac96  add rsp, 0x08
000076bac53dac9a  jmp 0x000076BAC53D8F23
000076bac53dac9f  sub rsp, 0x08
000076bac53daca3  push rax
000076bac53daca4  push rcx
000076bac53daca5  push rdx
000076bac53daca6  push rdi
000076bac53daca7  push rsi
000076bac53daca8  push r8
000076bac53dacaa  push r9
000076bac53dacac  push r10
000076bac53dacae  push r11
000076bac53dacb0  sub rsp, 0xF0
000076bac53dacb7  vmovaps [rsp], xmm0
000076bac53dacbc  vmovaps [rsp+0x10], xmm2
000076bac53dacc2  vmovaps [rsp+0x20], xmm3
000076bac53dacc8  vmovaps [rsp+0x30], xmm4
000076bac53dacce  vmovaps [rsp+0x40], xmm5
000076bac53dacd4  vmovaps [rsp+0x50], xmm6
000076bac53dacda  vmovaps [rsp+0x60], xmm7
000076bac53dace0  vmovaps [rsp+0x70], xmm8
000076bac53dace6  vmovaps [rsp+0x80], xmm9
000076bac53dacef  vmovaps [rsp+0x90], xmm10
000076bac53dacf8  vmovaps [rsp+0xA0], xmm11
000076bac53dad01  vmovaps [rsp+0xB0], xmm12
000076bac53dad0a  vmovaps [rsp+0xC0], xmm13
000076bac53dad13  vmovaps [rsp+0xD0], xmm14
000076bac53dad1c  vmovaps [rsp+0xE0], xmm15
000076bac53dad25  sub rsp, 0x30
000076bac53dad29  movaps [rsp], xmm1
000076bac53dad2d  movaps [rsp+0x10], xmm15
000076bac53dad33  movaps [rsp+0x20], xmm9
000076bac53dad39  lea rdi, [rsp]
000076bac53dad3d  mov esi, 0x00
000076bac53dad42  mov rax, 0x5641B0A3C530
000076bac53dad4c  call rax
000076bac53dad4e  movaps xmm1, [rsp]
000076bac53dad52  add rsp, 0x30
000076bac53dad56  vmovaps xmm0, [rsp]
000076bac53dad5b  vmovaps xmm2, [rsp+0x10]
000076bac53dad61  vmovaps xmm3, [rsp+0x20]
000076bac53dad67  vmovaps xmm4, [rsp+0x30]
000076bac53dad6d  vmovaps xmm5, [rsp+0x40]
000076bac53dad73  vmovaps xmm6, [rsp+0x50]
000076bac53dad79  vmovaps xmm7, [rsp+0x60]
000076bac53dad7f  vmovaps xmm8, [rsp+0x70]
000076bac53dad85  vmovaps xmm9, [rsp+0x80]
000076bac53dad8e  vmovaps xmm10, [rsp+0x90]
000076bac53dad97  vmovaps xmm11, [rsp+0xA0]
000076bac53dada0  vmovaps xmm12, [rsp+0xB0]
000076bac53dada9  vmovaps xmm13, [rsp+0xC0]
000076bac53dadb2  vmovaps xmm14, [rsp+0xD0]
000076bac53dadbb  vmovaps xmm15, [rsp+0xE0]
000076bac53dadc4  add rsp, 0xF0
000076bac53dadcb  pop r11
000076bac53dadcd  pop r10
000076bac53dadcf  pop r9
000076bac53dadd1  pop r8
000076bac53dadd3  pop rsi
000076bac53dadd4  pop rdi
000076bac53dadd5  pop rdx
000076bac53dadd6  pop rcx
000076bac53dadd7  pop rax
000076bac53dadd8  add rsp, 0x08
000076bac53daddc  jmp 0x000076BAC53D8FAB
000076bac53dade1  call 0x000076BAC52E5820
000076bac53dade6  jmp 0x000076BAC53D8FB8
000076bac53dadeb  sub rsp, 0x08
000076bac53dadef  push rax
000076bac53dadf0  push rcx
000076bac53dadf1  push rdx
000076bac53dadf2  push rdi
000076bac53dadf3  push rsi
000076bac53dadf4  push r8
000076bac53dadf6  push r9
000076bac53dadf8  push r10
000076bac53dadfa  push r11
000076bac53dadfc  sub rsp, 0xF0
000076bac53dae03  vmovaps [rsp], xmm0
000076bac53dae08  vmovaps [rsp+0x10], xmm2
000076bac53dae0e  vmovaps [rsp+0x20], xmm3
000076bac53dae14  vmovaps [rsp+0x30], xmm4
000076bac53dae1a  vmovaps [rsp+0x40], xmm5
000076bac53dae20  vmovaps [rsp+0x50], xmm6
000076bac53dae26  vmovaps [rsp+0x60], xmm7
000076bac53dae2c  vmovaps [rsp+0x70], xmm8
000076bac53dae32  vmovaps [rsp+0x80], xmm9
000076bac53dae3b  vmovaps [rsp+0x90], xmm10
000076bac53dae44  vmovaps [rsp+0xA0], xmm11
000076bac53dae4d  vmovaps [rsp+0xB0], xmm12
000076bac53dae56  vmovaps [rsp+0xC0], xmm13
000076bac53dae5f  vmovaps [rsp+0xD0], xmm14
000076bac53dae68  vmovaps [rsp+0xE0], xmm15
000076bac53dae71  sub rsp, 0x30
000076bac53dae75  movaps [rsp], xmm1
000076bac53dae79  movaps [rsp+0x10], xmm5
000076bac53dae7e  movaps [rsp+0x20], xmm7
000076bac53dae83  lea rdi, [rsp]
000076bac53dae87  mov esi, 0x00
000076bac53dae8c  mov rax, 0x5641B0A3C530
000076bac53dae96  call rax
000076bac53dae98  movaps xmm1, [rsp]
000076bac53dae9c  add rsp, 0x30
000076bac53daea0  vmovaps xmm0, [rsp]
000076bac53daea5  vmovaps xmm2, [rsp+0x10]
000076bac53daeab  vmovaps xmm3, [rsp+0x20]
000076bac53daeb1  vmovaps xmm4, [rsp+0x30]
000076bac53daeb7  vmovaps xmm5, [rsp+0x40]
000076bac53daebd  vmovaps xmm6, [rsp+0x50]
000076bac53daec3  vmovaps xmm7, [rsp+0x60]
000076bac53daec9  vmovaps xmm8, [rsp+0x70]
000076bac53daecf  vmovaps xmm9, [rsp+0x80]
000076bac53daed8  vmovaps xmm10, [rsp+0x90]
000076bac53daee1  vmovaps xmm11, [rsp+0xA0]
000076bac53daeea  vmovaps xmm12, [rsp+0xB0]
000076bac53daef3  vmovaps xmm13, [rsp+0xC0]
000076bac53daefc  vmovaps xmm14, [rsp+0xD0]
000076bac53daf05  vmovaps xmm15, [rsp+0xE0]
000076bac53daf0e  add rsp, 0xF0
000076bac53daf15  pop r11
000076bac53daf17  pop r10
000076bac53daf19  pop r9
000076bac53daf1b  pop r8
000076bac53daf1d  pop rsi
000076bac53daf1e  pop rdi
000076bac53daf1f  pop rdx
000076bac53daf20  pop rcx
000076bac53daf21  pop rax
000076bac53daf22  add rsp, 0x08
000076bac53daf26  jmp 0x000076BAC53D905D
000076bac53daf2b  sub rsp, 0x08
000076bac53daf2f  push rax
000076bac53daf30  push rcx
000076bac53daf31  push rdx
000076bac53daf32  push rdi
000076bac53daf33  push rsi
000076bac53daf34  push r8
000076bac53daf36  push r9
000076bac53daf38  push r10
000076bac53daf3a  push r11
000076bac53daf3c  sub rsp, 0xF0
000076bac53daf43  vmovaps [rsp], xmm0
000076bac53daf48  vmovaps [rsp+0x10], xmm1
000076bac53daf4e  vmovaps [rsp+0x20], xmm2
000076bac53daf54  vmovaps [rsp+0x30], xmm3
000076bac53daf5a  vmovaps [rsp+0x40], xmm4
000076bac53daf60  vmovaps [rsp+0x50], xmm5
000076bac53daf66  vmovaps [rsp+0x60], xmm6
000076bac53daf6c  vmovaps [rsp+0x70], xmm8
000076bac53daf72  vmovaps [rsp+0x80], xmm9
000076bac53daf7b  vmovaps [rsp+0x90], xmm10
000076bac53daf84  vmovaps [rsp+0xA0], xmm11
000076bac53daf8d  vmovaps [rsp+0xB0], xmm12
000076bac53daf96  vmovaps [rsp+0xC0], xmm13
000076bac53daf9f  vmovaps [rsp+0xD0], xmm14
000076bac53dafa8  vmovaps [rsp+0xE0], xmm15
000076bac53dafb1  sub rsp, 0x30
000076bac53dafb5  movaps [rsp], xmm7
000076bac53dafb9  movaps [rsp+0x10], xmm5
000076bac53dafbe  movaps [rsp+0x20], xmm15
000076bac53dafc4  lea rdi, [rsp]
000076bac53dafc8  mov esi, 0x00
000076bac53dafcd  mov rax, 0x5641B0A3C530
000076bac53dafd7  call rax
000076bac53dafd9  movaps xmm7, [rsp]
000076bac53dafdd  add rsp, 0x30
000076bac53dafe1  vmovaps xmm0, [rsp]
000076bac53dafe6  vmovaps xmm1, [rsp+0x10]
000076bac53dafec  vmovaps xmm2, [rsp+0x20]
000076bac53daff2  vmovaps xmm3, [rsp+0x30]
000076bac53daff8  vmovaps xmm4, [rsp+0x40]
000076bac53daffe  vmovaps xmm5, [rsp+0x50]
000076bac53db004  vmovaps xmm6, [rsp+0x60]
000076bac53db00a  vmovaps xmm8, [rsp+0x70]
000076bac53db010  vmovaps xmm9, [rsp+0x80]
000076bac53db019  vmovaps xmm10, [rsp+0x90]
000076bac53db022  vmovaps xmm11, [rsp+0xA0]
000076bac53db02b  vmovaps xmm12, [rsp+0xB0]
000076bac53db034  vmovaps xmm13, [rsp+0xC0]
000076bac53db03d  vmovaps xmm14, [rsp+0xD0]
000076bac53db046  vmovaps xmm15, [rsp+0xE0]
000076bac53db04f  add rsp, 0xF0
000076bac53db056  pop r11
000076bac53db058  pop r10
000076bac53db05a  pop r9
000076bac53db05c  pop r8
000076bac53db05e  pop rsi
000076bac53db05f  pop rdi
000076bac53db060  pop rdx
000076bac53db061  pop rcx
000076bac53db062  pop rax
000076bac53db063  add rsp, 0x08
000076bac53db067  jmp 0x000076BAC53D9093
000076bac53db06c  call 0x000076BAC52D64F0
000076bac53db071  jmp 0x000076BAC53D90A0
000076bac53db076  sub rsp, 0x08
000076bac53db07a  push rax
000076bac53db07b  push rcx
000076bac53db07c  push rdx
000076bac53db07d  push rdi
000076bac53db07e  push rsi
000076bac53db07f  push r8
000076bac53db081  push r9
000076bac53db083  push r10
000076bac53db085  push r11
000076bac53db087  sub rsp, 0xF0
000076bac53db08e  vmovaps [rsp], xmm0
000076bac53db093  vmovaps [rsp+0x10], xmm1
000076bac53db099  vmovaps [rsp+0x20], xmm2
000076bac53db09f  vmovaps [rsp+0x30], xmm3
000076bac53db0a5  vmovaps [rsp+0x40], xmm4
000076bac53db0ab  vmovaps [rsp+0x50], xmm5
000076bac53db0b1  vmovaps [rsp+0x60], xmm6
000076bac53db0b7  vmovaps [rsp+0x70], xmm7
000076bac53db0bd  vmovaps [rsp+0x80], xmm8
000076bac53db0c6  vmovaps [rsp+0x90], xmm9
000076bac53db0cf  vmovaps [rsp+0xA0], xmm10
000076bac53db0d8  vmovaps [rsp+0xB0], xmm11
000076bac53db0e1  vmovaps [rsp+0xC0], xmm12
000076bac53db0ea  vmovaps [rsp+0xD0], xmm13
000076bac53db0f3  vmovaps [rsp+0xE0], xmm14
000076bac53db0fc  sub rsp, 0x30
000076bac53db100  movaps [rsp], xmm15
000076bac53db105  movaps [rsp+0x10], xmm5
000076bac53db10a  movaps [rsp+0x20], xmm3
000076bac53db10f  lea rdi, [rsp]
000076bac53db113  mov esi, 0x00
000076bac53db118  mov rax, 0x5641B0A3C530
000076bac53db122  call rax
000076bac53db124  movaps xmm15, [rsp]
000076bac53db129  add rsp, 0x30
000076bac53db12d  vmovaps xmm0, [rsp]
000076bac53db132  vmovaps xmm1, [rsp+0x10]
000076bac53db138  vmovaps xmm2, [rsp+0x20]
000076bac53db13e  vmovaps xmm3, [rsp+0x30]
000076bac53db144  vmovaps xmm4, [rsp+0x40]
000076bac53db14a  vmovaps xmm5, [rsp+0x50]
000076bac53db150  vmovaps xmm6, [rsp+0x60]
000076bac53db156  vmovaps xmm7, [rsp+0x70]
000076bac53db15c  vmovaps xmm8, [rsp+0x80]
000076bac53db165  vmovaps xmm9, [rsp+0x90]
000076bac53db16e  vmovaps xmm10, [rsp+0xA0]
000076bac53db177  vmovaps xmm11, [rsp+0xB0]
000076bac53db180  vmovaps xmm12, [rsp+0xC0]
000076bac53db189  vmovaps xmm13, [rsp+0xD0]
000076bac53db192  vmovaps xmm14, [rsp+0xE0]
000076bac53db19b  add rsp, 0xF0
000076bac53db1a2  pop r11
000076bac53db1a4  pop r10
000076bac53db1a6  pop r9
000076bac53db1a8  pop r8
000076bac53db1aa  pop rsi
000076bac53db1ab  pop rdi
000076bac53db1ac  pop rdx
000076bac53db1ad  pop rcx
000076bac53db1ae  pop rax
000076bac53db1af  add rsp, 0x08
000076bac53db1b3  jmp 0x000076BAC53D90C6
000076bac53db1b8  sub rsp, 0x08
000076bac53db1bc  push rax
000076bac53db1bd  push rcx
000076bac53db1be  push rdx
000076bac53db1bf  push rdi
000076bac53db1c0  push rsi
000076bac53db1c1  push r8
000076bac53db1c3  push r9
000076bac53db1c5  push r10
000076bac53db1c7  push r11
000076bac53db1c9  sub rsp, 0xF0
000076bac53db1d0  vmovaps [rsp], xmm0
000076bac53db1d5  vmovaps [rsp+0x10], xmm2
000076bac53db1db  vmovaps [rsp+0x20], xmm3
000076bac53db1e1  vmovaps [rsp+0x30], xmm4
000076bac53db1e7  vmovaps [rsp+0x40], xmm5
000076bac53db1ed  vmovaps [rsp+0x50], xmm6
000076bac53db1f3  vmovaps [rsp+0x60], xmm7
000076bac53db1f9  vmovaps [rsp+0x70], xmm8
000076bac53db1ff  vmovaps [rsp+0x80], xmm9
000076bac53db208  vmovaps [rsp+0x90], xmm10
000076bac53db211  vmovaps [rsp+0xA0], xmm11
000076bac53db21a  vmovaps [rsp+0xB0], xmm12
000076bac53db223  vmovaps [rsp+0xC0], xmm13
000076bac53db22c  vmovaps [rsp+0xD0], xmm14
000076bac53db235  vmovaps [rsp+0xE0], xmm15
000076bac53db23e  sub rsp, 0x30
000076bac53db242  movaps [rsp], xmm1
000076bac53db246  movaps [rsp+0x10], xmm5
000076bac53db24b  movaps [rsp+0x20], xmm4
000076bac53db250  lea rdi, [rsp]
000076bac53db254  mov esi, 0x00
000076bac53db259  mov rax, 0x5641B0A3C530
000076bac53db263  call rax
000076bac53db265  movaps xmm1, [rsp]
000076bac53db269  add rsp, 0x30
000076bac53db26d  vmovaps xmm0, [rsp]
000076bac53db272  vmovaps xmm2, [rsp+0x10]
000076bac53db278  vmovaps xmm3, [rsp+0x20]
000076bac53db27e  vmovaps xmm4, [rsp+0x30]
000076bac53db284  vmovaps xmm5, [rsp+0x40]
000076bac53db28a  vmovaps xmm6, [rsp+0x50]
000076bac53db290  vmovaps xmm7, [rsp+0x60]
000076bac53db296  vmovaps xmm8, [rsp+0x70]
000076bac53db29c  vmovaps xmm9, [rsp+0x80]
000076bac53db2a5  vmovaps xmm10, [rsp+0x90]
000076bac53db2ae  vmovaps xmm11, [rsp+0xA0]
000076bac53db2b7  vmovaps xmm12, [rsp+0xB0]
000076bac53db2c0  vmovaps xmm13, [rsp+0xC0]
000076bac53db2c9  vmovaps xmm14, [rsp+0xD0]
000076bac53db2d2  vmovaps xmm15, [rsp+0xE0]
000076bac53db2db  add rsp, 0xF0
000076bac53db2e2  pop r11
000076bac53db2e4  pop r10
000076bac53db2e6  pop r9
000076bac53db2e8  pop r8
000076bac53db2ea  pop rsi
000076bac53db2eb  pop rdi
000076bac53db2ec  pop rdx
000076bac53db2ed  pop rcx
000076bac53db2ee  pop rax
000076bac53db2ef  add rsp, 0x08
000076bac53db2f3  jmp 0x000076BAC53D90E6
000076bac53db2f8  sub rsp, 0x08
000076bac53db2fc  push rax
000076bac53db2fd  push rcx
000076bac53db2fe  push rdx
000076bac53db2ff  push rdi
000076bac53db300  push rsi
000076bac53db301  push r8
000076bac53db303  push r9
000076bac53db305  push r10
000076bac53db307  push r11
000076bac53db309  sub rsp, 0xF0
000076bac53db310  vmovaps [rsp], xmm0
000076bac53db315  vmovaps [rsp+0x10], xmm1
000076bac53db31b  vmovaps [rsp+0x20], xmm2
000076bac53db321  vmovaps [rsp+0x30], xmm3
000076bac53db327  vmovaps [rsp+0x40], xmm5
000076bac53db32d  vmovaps [rsp+0x50], xmm6
000076bac53db333  vmovaps [rsp+0x60], xmm7
000076bac53db339  vmovaps [rsp+0x70], xmm8
000076bac53db33f  vmovaps [rsp+0x80], xmm9
000076bac53db348  vmovaps [rsp+0x90], xmm10
000076bac53db351  vmovaps [rsp+0xA0], xmm11
000076bac53db35a  vmovaps [rsp+0xB0], xmm12
000076bac53db363  vmovaps [rsp+0xC0], xmm13
000076bac53db36c  vmovaps [rsp+0xD0], xmm14
000076bac53db375  vmovaps [rsp+0xE0], xmm15
000076bac53db37e  sub rsp, 0x30
000076bac53db382  movaps [rsp], xmm4
000076bac53db386  movaps [rsp+0x10], xmm3
000076bac53db38b  movaps [rsp+0x20], xmm5
000076bac53db390  lea rdi, [rsp]
000076bac53db394  mov esi, 0x00
000076bac53db399  mov rax, 0x5641B0A3C530
000076bac53db3a3  call rax
000076bac53db3a5  movaps xmm4, [rsp]
000076bac53db3a9  add rsp, 0x30
000076bac53db3ad  vmovaps xmm0, [rsp]
000076bac53db3b2  vmovaps xmm1, [rsp+0x10]
000076bac53db3b8  vmovaps xmm2, [rsp+0x20]
000076bac53db3be  vmovaps xmm3, [rsp+0x30]
000076bac53db3c4  vmovaps xmm5, [rsp+0x40]
000076bac53db3ca  vmovaps xmm6, [rsp+0x50]
000076bac53db3d0  vmovaps xmm7, [rsp+0x60]
000076bac53db3d6  vmovaps xmm8, [rsp+0x70]
000076bac53db3dc  vmovaps xmm9, [rsp+0x80]
000076bac53db3e5  vmovaps xmm10, [rsp+0x90]
000076bac53db3ee  vmovaps xmm11, [rsp+0xA0]
000076bac53db3f7  vmovaps xmm12, [rsp+0xB0]
000076bac53db400  vmovaps xmm13, [rsp+0xC0]
000076bac53db409  vmovaps xmm14, [rsp+0xD0]
000076bac53db412  vmovaps xmm15, [rsp+0xE0]
000076bac53db41b  add rsp, 0xF0
000076bac53db422  pop r11
000076bac53db424  pop r10
000076bac53db426  pop r9
000076bac53db428  pop r8
000076bac53db42a  pop rsi
000076bac53db42b  pop rdi
000076bac53db42c  pop rdx
000076bac53db42d  pop rcx
000076bac53db42e  pop rax
000076bac53db42f  add rsp, 0x08
000076bac53db433  jmp 0x000076BAC53D9134
000076bac53db438  call 0x000076BAC52D64F0
000076bac53db43d  jmp 0x000076BAC53D9141
000076bac53db442  sub rsp, 0x08
000076bac53db446  push rax
000076bac53db447  push rcx
000076bac53db448  push rdx
000076bac53db449  push rdi
000076bac53db44a  push rsi
000076bac53db44b  push r8
000076bac53db44d  push r9
000076bac53db44f  push r10
000076bac53db451  push r11
000076bac53db453  sub rsp, 0xF0
000076bac53db45a  vmovaps [rsp], xmm0
000076bac53db45f  vmovaps [rsp+0x10], xmm1
000076bac53db465  vmovaps [rsp+0x20], xmm2
000076bac53db46b  vmovaps [rsp+0x30], xmm3
000076bac53db471  vmovaps [rsp+0x40], xmm4
000076bac53db477  vmovaps [rsp+0x50], xmm6
000076bac53db47d  vmovaps [rsp+0x60], xmm7
000076bac53db483  vmovaps [rsp+0x70], xmm8
000076bac53db489  vmovaps [rsp+0x80], xmm9
000076bac53db492  vmovaps [rsp+0x90], xmm10
000076bac53db49b  vmovaps [rsp+0xA0], xmm11
000076bac53db4a4  vmovaps [rsp+0xB0], xmm12
000076bac53db4ad  vmovaps [rsp+0xC0], xmm13
000076bac53db4b6  vmovaps [rsp+0xD0], xmm14
000076bac53db4bf  vmovaps [rsp+0xE0], xmm15
000076bac53db4c8  sub rsp, 0x30
000076bac53db4cc  movaps [rsp], xmm5
000076bac53db4d0  movaps [rsp+0x10], xmm6
000076bac53db4d5  movaps [rsp+0x20], xmm3
000076bac53db4da  lea rdi, [rsp]
000076bac53db4de  mov esi, 0x00
000076bac53db4e3  mov rax, 0x5641B0A3C530
000076bac53db4ed  call rax
000076bac53db4ef  movaps xmm5, [rsp]
000076bac53db4f3  add rsp, 0x30
000076bac53db4f7  vmovaps xmm0, [rsp]
000076bac53db4fc  vmovaps xmm1, [rsp+0x10]
000076bac53db502  vmovaps xmm2, [rsp+0x20]
000076bac53db508  vmovaps xmm3, [rsp+0x30]
000076bac53db50e  vmovaps xmm4, [rsp+0x40]
000076bac53db514  vmovaps xmm6, [rsp+0x50]
000076bac53db51a  vmovaps xmm7, [rsp+0x60]
000076bac53db520  vmovaps xmm8, [rsp+0x70]
000076bac53db526  vmovaps xmm9, [rsp+0x80]
000076bac53db52f  vmovaps xmm10, [rsp+0x90]
000076bac53db538  vmovaps xmm11, [rsp+0xA0]
000076bac53db541  vmovaps xmm12, [rsp+0xB0]
000076bac53db54a  vmovaps xmm13, [rsp+0xC0]
000076bac53db553  vmovaps xmm14, [rsp+0xD0]
000076bac53db55c  vmovaps xmm15, [rsp+0xE0]
000076bac53db565  add rsp, 0xF0
000076bac53db56c  pop r11
000076bac53db56e  pop r10
000076bac53db570  pop r9
000076bac53db572  pop r8
000076bac53db574  pop rsi
000076bac53db575  pop rdi
000076bac53db576  pop rdx
000076bac53db577  pop rcx
000076bac53db578  pop rax
000076bac53db579  add rsp, 0x08
000076bac53db57d  jmp 0x000076BAC53D9167
000076bac53db582  sub rsp, 0x08
000076bac53db586  push rax
000076bac53db587  push rcx
000076bac53db588  push rdx
000076bac53db589  push rdi
000076bac53db58a  push rsi
000076bac53db58b  push r8
000076bac53db58d  push r9
000076bac53db58f  push r10
000076bac53db591  push r11
000076bac53db593  sub rsp, 0xF0
000076bac53db59a  vmovaps [rsp], xmm0
000076bac53db59f  vmovaps [rsp+0x10], xmm1
000076bac53db5a5  vmovaps [rsp+0x20], xmm2
000076bac53db5ab  vmovaps [rsp+0x30], xmm3
000076bac53db5b1  vmovaps [rsp+0x40], xmm4
000076bac53db5b7  vmovaps [rsp+0x50], xmm5
000076bac53db5bd  vmovaps [rsp+0x60], xmm7
000076bac53db5c3  vmovaps [rsp+0x70], xmm8
000076bac53db5c9  vmovaps [rsp+0x80], xmm9
000076bac53db5d2  vmovaps [rsp+0x90], xmm10
000076bac53db5db  vmovaps [rsp+0xA0], xmm11
000076bac53db5e4  vmovaps [rsp+0xB0], xmm12
000076bac53db5ed  vmovaps [rsp+0xC0], xmm13
000076bac53db5f6  vmovaps [rsp+0xD0], xmm14
000076bac53db5ff  vmovaps [rsp+0xE0], xmm15
000076bac53db608  sub rsp, 0x30
000076bac53db60c  movaps [rsp], xmm6
000076bac53db610  movaps [rsp+0x10], xmm9
000076bac53db616  movaps [rsp+0x20], xmm1
000076bac53db61b  lea rdi, [rsp]
000076bac53db61f  mov esi, 0x00
000076bac53db624  mov rax, 0x5641B0A3C530
000076bac53db62e  call rax
000076bac53db630  movaps xmm6, [rsp]
000076bac53db634  add rsp, 0x30
000076bac53db638  vmovaps xmm0, [rsp]
000076bac53db63d  vmovaps xmm1, [rsp+0x10]
000076bac53db643  vmovaps xmm2, [rsp+0x20]
000076bac53db649  vmovaps xmm3, [rsp+0x30]
000076bac53db64f  vmovaps xmm4, [rsp+0x40]
000076bac53db655  vmovaps xmm5, [rsp+0x50]
000076bac53db65b  vmovaps xmm7, [rsp+0x60]
000076bac53db661  vmovaps xmm8, [rsp+0x70]
000076bac53db667  vmovaps xmm9, [rsp+0x80]
000076bac53db670  vmovaps xmm10, [rsp+0x90]
000076bac53db679  vmovaps xmm11, [rsp+0xA0]
000076bac53db682  vmovaps xmm12, [rsp+0xB0]
000076bac53db68b  vmovaps xmm13, [rsp+0xC0]
000076bac53db694  vmovaps xmm14, [rsp+0xD0]
000076bac53db69d  vmovaps xmm15, [rsp+0xE0]
000076bac53db6a6  add rsp, 0xF0
000076bac53db6ad  pop r11
000076bac53db6af  pop r10
000076bac53db6b1  pop r9
000076bac53db6b3  pop r8
000076bac53db6b5  pop rsi
000076bac53db6b6  pop rdi
000076bac53db6b7  pop rdx
000076bac53db6b8  pop rcx
000076bac53db6b9  pop rax
000076bac53db6ba  add rsp, 0x08
000076bac53db6be  jmp 0x000076BAC53D918B
000076bac53db6c3  sub rsp, 0x08
000076bac53db6c7  push rax
000076bac53db6c8  push rcx
000076bac53db6c9  push rdx
000076bac53db6ca  push rdi
000076bac53db6cb  push rsi
000076bac53db6cc  push r8
000076bac53db6ce  push r9
000076bac53db6d0  push r10
000076bac53db6d2  push r11
000076bac53db6d4  sub rsp, 0xF0
000076bac53db6db  vmovaps [rsp], xmm0
000076bac53db6e0  vmovaps [rsp+0x10], xmm1
000076bac53db6e6  vmovaps [rsp+0x20], xmm2
000076bac53db6ec  vmovaps [rsp+0x30], xmm3
000076bac53db6f2  vmovaps [rsp+0x40], xmm4
000076bac53db6f8  vmovaps [rsp+0x50], xmm5
000076bac53db6fe  vmovaps [rsp+0x60], xmm6
000076bac53db704  vmovaps [rsp+0x70], xmm7
000076bac53db70a  vmovaps [rsp+0x80], xmm8
000076bac53db713  vmovaps [rsp+0x90], xmm10
000076bac53db71c  vmovaps [rsp+0xA0], xmm11
000076bac53db725  vmovaps [rsp+0xB0], xmm12
000076bac53db72e  vmovaps [rsp+0xC0], xmm13
000076bac53db737  vmovaps [rsp+0xD0], xmm14
000076bac53db740  vmovaps [rsp+0xE0], xmm15
000076bac53db749  sub rsp, 0x30
000076bac53db74d  movaps [rsp], xmm9
000076bac53db752  movaps [rsp+0x10], xmm3
000076bac53db757  movaps [rsp+0x20], xmm1
000076bac53db75c  lea rdi, [rsp]
000076bac53db760  mov esi, 0x00
000076bac53db765  mov rax, 0x5641B0A3C530
000076bac53db76f  call rax
000076bac53db771  movaps xmm9, [rsp]
000076bac53db776  add rsp, 0x30
000076bac53db77a  vmovaps xmm0, [rsp]
000076bac53db77f  vmovaps xmm1, [rsp+0x10]
000076bac53db785  vmovaps xmm2, [rsp+0x20]
000076bac53db78b  vmovaps xmm3, [rsp+0x30]
000076bac53db791  vmovaps xmm4, [rsp+0x40]
000076bac53db797  vmovaps xmm5, [rsp+0x50]
000076bac53db79d  vmovaps xmm6, [rsp+0x60]
000076bac53db7a3  vmovaps xmm7, [rsp+0x70]
000076bac53db7a9  vmovaps xmm8, [rsp+0x80]
000076bac53db7b2  vmovaps xmm10, [rsp+0x90]
000076bac53db7bb  vmovaps xmm11, [rsp+0xA0]
000076bac53db7c4  vmovaps xmm12, [rsp+0xB0]
000076bac53db7cd  vmovaps xmm13, [rsp+0xC0]
000076bac53db7d6  vmovaps xmm14, [rsp+0xD0]
000076bac53db7df  vmovaps xmm15, [rsp+0xE0]
000076bac53db7e8  add rsp, 0xF0
000076bac53db7ef  pop r11
000076bac53db7f1  pop r10
000076bac53db7f3  pop r9
000076bac53db7f5  pop r8
000076bac53db7f7  pop rsi
000076bac53db7f8  pop rdi
000076bac53db7f9  pop rdx
000076bac53db7fa  pop rcx
000076bac53db7fb  pop rax
000076bac53db7fc  add rsp, 0x08
000076bac53db800  jmp 0x000076BAC53D91D7
000076bac53db805  call 0x000076BAC52D64F0
000076bac53db80a  jmp 0x000076BAC53D91E4
000076bac53db80f  sub rsp, 0x08
000076bac53db813  push rax
000076bac53db814  push rcx
000076bac53db815  push rdx
000076bac53db816  push rdi
000076bac53db817  push rsi
000076bac53db818  push r8
000076bac53db81a  push r9
000076bac53db81c  push r10
000076bac53db81e  push r11
000076bac53db820  sub rsp, 0xF0
000076bac53db827  vmovaps [rsp], xmm0
000076bac53db82c  vmovaps [rsp+0x10], xmm1
000076bac53db832  vmovaps [rsp+0x20], xmm2
000076bac53db838  vmovaps [rsp+0x30], xmm3
000076bac53db83e  vmovaps [rsp+0x40], xmm4
000076bac53db844  vmovaps [rsp+0x50], xmm5
000076bac53db84a  vmovaps [rsp+0x60], xmm6
000076bac53db850  vmovaps [rsp+0x70], xmm7
000076bac53db856  vmovaps [rsp+0x80], xmm8
000076bac53db85f  vmovaps [rsp+0x90], xmm9
000076bac53db868  vmovaps [rsp+0xA0], xmm10
000076bac53db871  vmovaps [rsp+0xB0], xmm11
000076bac53db87a  vmovaps [rsp+0xC0], xmm12
000076bac53db883  vmovaps [rsp+0xD0], xmm13
000076bac53db88c  vmovaps [rsp+0xE0], xmm14
000076bac53db895  sub rsp, 0x30
000076bac53db899  movaps [rsp], xmm15
000076bac53db89e  movaps [rsp+0x10], xmm3
000076bac53db8a3  movaps [rsp+0x20], xmm7
000076bac53db8a8  lea rdi, [rsp]
000076bac53db8ac  mov esi, 0x00
000076bac53db8b1  mov rax, 0x5641B0A3C530
000076bac53db8bb  call rax
000076bac53db8bd  movaps xmm15, [rsp]
000076bac53db8c2  add rsp, 0x30
000076bac53db8c6  vmovaps xmm0, [rsp]
000076bac53db8cb  vmovaps xmm1, [rsp+0x10]
000076bac53db8d1  vmovaps xmm2, [rsp+0x20]
000076bac53db8d7  vmovaps xmm3, [rsp+0x30]
000076bac53db8dd  vmovaps xmm4, [rsp+0x40]
000076bac53db8e3  vmovaps xmm5, [rsp+0x50]
000076bac53db8e9  vmovaps xmm6, [rsp+0x60]
000076bac53db8ef  vmovaps xmm7, [rsp+0x70]
000076bac53db8f5  vmovaps xmm8, [rsp+0x80]
000076bac53db8fe  vmovaps xmm9, [rsp+0x90]
000076bac53db907  vmovaps xmm10, [rsp+0xA0]
000076bac53db910  vmovaps xmm11, [rsp+0xB0]
000076bac53db919  vmovaps xmm12, [rsp+0xC0]
000076bac53db922  vmovaps xmm13, [rsp+0xD0]
000076bac53db92b  vmovaps xmm14, [rsp+0xE0]
000076bac53db934  add rsp, 0xF0
000076bac53db93b  pop r11
000076bac53db93d  pop r10
000076bac53db93f  pop r9
000076bac53db941  pop r8
000076bac53db943  pop rsi
000076bac53db944  pop rdi
000076bac53db945  pop rdx
000076bac53db946  pop rcx
000076bac53db947  pop rax
000076bac53db948  add rsp, 0x08
000076bac53db94c  jmp 0x000076BAC53D9210
000076bac53db951  sub rsp, 0x08
000076bac53db955  push rax
000076bac53db956  push rcx
000076bac53db957  push rdx
000076bac53db958  push rdi
000076bac53db959  push rsi
000076bac53db95a  push r8
000076bac53db95c  push r9
000076bac53db95e  push r10
000076bac53db960  push r11
000076bac53db962  sub rsp, 0xF0
000076bac53db969  vmovaps [rsp], xmm0
000076bac53db96e  vmovaps [rsp+0x10], xmm1
000076bac53db974  vmovaps [rsp+0x20], xmm2
000076bac53db97a  vmovaps [rsp+0x30], xmm4
000076bac53db980  vmovaps [rsp+0x40], xmm5
000076bac53db986  vmovaps [rsp+0x50], xmm6
000076bac53db98c  vmovaps [rsp+0x60], xmm7
000076bac53db992  vmovaps [rsp+0x70], xmm8
000076bac53db998  vmovaps [rsp+0x80], xmm9
000076bac53db9a1  vmovaps [rsp+0x90], xmm10
000076bac53db9aa  vmovaps [rsp+0xA0], xmm11
000076bac53db9b3  vmovaps [rsp+0xB0], xmm12
000076bac53db9bc  vmovaps [rsp+0xC0], xmm13
000076bac53db9c5  vmovaps [rsp+0xD0], xmm14
000076bac53db9ce  vmovaps [rsp+0xE0], xmm15
000076bac53db9d7  sub rsp, 0x30
000076bac53db9db  movaps [rsp], xmm3
000076bac53db9df  movaps [rsp+0x10], xmm1
000076bac53db9e4  movaps [rsp+0x20], xmm15
000076bac53db9ea  lea rdi, [rsp]
000076bac53db9ee  mov esi, 0x00
000076bac53db9f3  mov rax, 0x5641B0A3C530
000076bac53db9fd  call rax
000076bac53db9ff  movaps xmm3, [rsp]
000076bac53dba03  add rsp, 0x30
000076bac53dba07  vmovaps xmm0, [rsp]
000076bac53dba0c  vmovaps xmm1, [rsp+0x10]
000076bac53dba12  vmovaps xmm2, [rsp+0x20]
000076bac53dba18  vmovaps xmm4, [rsp+0x30]
000076bac53dba1e  vmovaps xmm5, [rsp+0x40]
000076bac53dba24  vmovaps xmm6, [rsp+0x50]
000076bac53dba2a  vmovaps xmm7, [rsp+0x60]
000076bac53dba30  vmovaps xmm8, [rsp+0x70]
000076bac53dba36  vmovaps xmm9, [rsp+0x80]
000076bac53dba3f  vmovaps xmm10, [rsp+0x90]
000076bac53dba48  vmovaps xmm11, [rsp+0xA0]
000076bac53dba51  vmovaps xmm12, [rsp+0xB0]
000076bac53dba5a  vmovaps xmm13, [rsp+0xC0]
000076bac53dba63  vmovaps xmm14, [rsp+0xD0]
000076bac53dba6c  vmovaps xmm15, [rsp+0xE0]
000076bac53dba75  add rsp, 0xF0
000076bac53dba7c  pop r11
000076bac53dba7e  pop r10
000076bac53dba80  pop r9
000076bac53dba82  pop r8
000076bac53dba84  pop rsi
000076bac53dba85  pop rdi
000076bac53dba86  pop rdx
000076bac53dba87  pop rcx
000076bac53dba88  pop rax
000076bac53dba89  add rsp, 0x08
000076bac53dba8d  jmp 0x000076BAC53D929F
000076bac53dba92  call 0x000076BAC52D64F0
000076bac53dba97  jmp 0x000076BAC53D92A9
000076bac53dba9c  sub rsp, 0x08
000076bac53dbaa0  push rax
000076bac53dbaa1  push rcx
000076bac53dbaa2  push rdx
000076bac53dbaa3  push rdi
000076bac53dbaa4  push rsi
000076bac53dbaa5  push r8
000076bac53dbaa7  push r9
000076bac53dbaa9  push r10
000076bac53dbaab  push r11
000076bac53dbaad  sub rsp, 0xF0
000076bac53dbab4  vmovaps [rsp], xmm0
000076bac53dbab9  vmovaps [rsp+0x10], xmm1
000076bac53dbabf  vmovaps [rsp+0x20], xmm2
000076bac53dbac5  vmovaps [rsp+0x30], xmm3
000076bac53dbacb  vmovaps [rsp+0x40], xmm4
000076bac53dbad1  vmovaps [rsp+0x50], xmm5
000076bac53dbad7  vmovaps [rsp+0x60], xmm6
000076bac53dbadd  vmovaps [rsp+0x70], xmm7
000076bac53dbae3  vmovaps [rsp+0x80], xmm8
000076bac53dbaec  vmovaps [rsp+0x90], xmm9
000076bac53dbaf5  vmovaps [rsp+0xA0], xmm10
000076bac53dbafe  vmovaps [rsp+0xB0], xmm11
000076bac53dbb07  vmovaps [rsp+0xC0], xmm12
000076bac53dbb10  vmovaps [rsp+0xD0], xmm13
000076bac53dbb19  vmovaps [rsp+0xE0], xmm14
000076bac53dbb22  sub rsp, 0x30
000076bac53dbb26  movaps [rsp], xmm15
000076bac53dbb2b  movaps [rsp+0x10], xmm14
000076bac53dbb31  movaps [rsp+0x20], xmm4
000076bac53dbb36  lea rdi, [rsp]
000076bac53dbb3a  mov esi, 0x00
000076bac53dbb3f  mov rax, 0x5641B0A3C530
000076bac53dbb49  call rax
000076bac53dbb4b  movaps xmm15, [rsp]
000076bac53dbb50  add rsp, 0x30
000076bac53dbb54  vmovaps xmm0, [rsp]
000076bac53dbb59  vmovaps xmm1, [rsp+0x10]
000076bac53dbb5f  vmovaps xmm2, [rsp+0x20]
000076bac53dbb65  vmovaps xmm3, [rsp+0x30]
000076bac53dbb6b  vmovaps xmm4, [rsp+0x40]
000076bac53dbb71  vmovaps xmm5, [rsp+0x50]
000076bac53dbb77  vmovaps xmm6, [rsp+0x60]
000076bac53dbb7d  vmovaps xmm7, [rsp+0x70]
000076bac53dbb83  vmovaps xmm8, [rsp+0x80]
000076bac53dbb8c  vmovaps xmm9, [rsp+0x90]
000076bac53dbb95  vmovaps xmm10, [rsp+0xA0]
000076bac53dbb9e  vmovaps xmm11, [rsp+0xB0]
000076bac53dbba7  vmovaps xmm12, [rsp+0xC0]
000076bac53dbbb0  vmovaps xmm13, [rsp+0xD0]
000076bac53dbbb9  vmovaps xmm14, [rsp+0xE0]
000076bac53dbbc2  add rsp, 0xF0
000076bac53dbbc9  pop r11
000076bac53dbbcb  pop r10
000076bac53dbbcd  pop r9
000076bac53dbbcf  pop r8
000076bac53dbbd1  pop rsi
000076bac53dbbd2  pop rdi
000076bac53dbbd3  pop rdx
000076bac53dbbd4  pop rcx
000076bac53dbbd5  pop rax
000076bac53dbbd6  add rsp, 0x08
000076bac53dbbda  jmp 0x000076BAC53D92D7
000076bac53dbbdf  sub rsp, 0x08
000076bac53dbbe3  push rax
000076bac53dbbe4  push rcx
000076bac53dbbe5  push rdx
000076bac53dbbe6  push rdi
000076bac53dbbe7  push rsi
000076bac53dbbe8  push r8
000076bac53dbbea  push r9
000076bac53dbbec  push r10
000076bac53dbbee  push r11
000076bac53dbbf0  sub rsp, 0xF0
000076bac53dbbf7  vmovaps [rsp], xmm0
000076bac53dbbfc  vmovaps [rsp+0x10], xmm1
000076bac53dbc02  vmovaps [rsp+0x20], xmm2
000076bac53dbc08  vmovaps [rsp+0x30], xmm3
000076bac53dbc0e  vmovaps [rsp+0x40], xmm4
000076bac53dbc14  vmovaps [rsp+0x50], xmm5
000076bac53dbc1a  vmovaps [rsp+0x60], xmm6
000076bac53dbc20  vmovaps [rsp+0x70], xmm7
000076bac53dbc26  vmovaps [rsp+0x80], xmm8
000076bac53dbc2f  vmovaps [rsp+0x90], xmm9
000076bac53dbc38  vmovaps [rsp+0xA0], xmm10
000076bac53dbc41  vmovaps [rsp+0xB0], xmm11
000076bac53dbc4a  vmovaps [rsp+0xC0], xmm12
000076bac53dbc53  vmovaps [rsp+0xD0], xmm13
000076bac53dbc5c  vmovaps [rsp+0xE0], xmm15
000076bac53dbc65  sub rsp, 0x30
000076bac53dbc69  movaps [rsp], xmm14
000076bac53dbc6e  movaps [rsp+0x10], xmm2
000076bac53dbc73  movaps [rsp+0x20], xmm1
000076bac53dbc78  lea rdi, [rsp]
000076bac53dbc7c  mov esi, 0x00
000076bac53dbc81  mov rax, 0x5641B0A3C530
000076bac53dbc8b  call rax
000076bac53dbc8d  movaps xmm14, [rsp]
000076bac53dbc92  add rsp, 0x30
000076bac53dbc96  vmovaps xmm0, [rsp]
000076bac53dbc9b  vmovaps xmm1, [rsp+0x10]
000076bac53dbca1  vmovaps xmm2, [rsp+0x20]
000076bac53dbca7  vmovaps xmm3, [rsp+0x30]
000076bac53dbcad  vmovaps xmm4, [rsp+0x40]
000076bac53dbcb3  vmovaps xmm5, [rsp+0x50]
000076bac53dbcb9  vmovaps xmm6, [rsp+0x60]
000076bac53dbcbf  vmovaps xmm7, [rsp+0x70]
000076bac53dbcc5  vmovaps xmm8, [rsp+0x80]
000076bac53dbcce  vmovaps xmm9, [rsp+0x90]
000076bac53dbcd7  vmovaps xmm10, [rsp+0xA0]
000076bac53dbce0  vmovaps xmm11, [rsp+0xB0]
000076bac53dbce9  vmovaps xmm12, [rsp+0xC0]
000076bac53dbcf2  vmovaps xmm13, [rsp+0xD0]
000076bac53dbcfb  vmovaps xmm15, [rsp+0xE0]
000076bac53dbd04  add rsp, 0xF0
000076bac53dbd0b  pop r11
000076bac53dbd0d  pop r10
000076bac53dbd0f  pop r9
000076bac53dbd11  pop r8
000076bac53dbd13  pop rsi
000076bac53dbd14  pop rdi
000076bac53dbd15  pop rdx
000076bac53dbd16  pop rcx
000076bac53dbd17  pop rax
000076bac53dbd18  add rsp, 0x08
000076bac53dbd1c  jmp 0x000076BAC53D92FD
000076bac53dbd21  sub rsp, 0x08
000076bac53dbd25  push rax
000076bac53dbd26  push rcx
000076bac53dbd27  push rdx
000076bac53dbd28  push rdi
000076bac53dbd29  push rsi
000076bac53dbd2a  push r8
000076bac53dbd2c  push r9
000076bac53dbd2e  push r10
000076bac53dbd30  push r11
000076bac53dbd32  sub rsp, 0xF0
000076bac53dbd39  vmovaps [rsp], xmm0
000076bac53dbd3e  vmovaps [rsp+0x10], xmm2
000076bac53dbd44  vmovaps [rsp+0x20], xmm3
000076bac53dbd4a  vmovaps [rsp+0x30], xmm4
000076bac53dbd50  vmovaps [rsp+0x40], xmm5
000076bac53dbd56  vmovaps [rsp+0x50], xmm6
000076bac53dbd5c  vmovaps [rsp+0x60], xmm7
000076bac53dbd62  vmovaps [rsp+0x70], xmm8
000076bac53dbd68  vmovaps [rsp+0x80], xmm9
000076bac53dbd71  vmovaps [rsp+0x90], xmm10
000076bac53dbd7a  vmovaps [rsp+0xA0], xmm11
000076bac53dbd83  vmovaps [rsp+0xB0], xmm12
000076bac53dbd8c  vmovaps [rsp+0xC0], xmm13
000076bac53dbd95  vmovaps [rsp+0xD0], xmm14
000076bac53dbd9e  vmovaps [rsp+0xE0], xmm15
000076bac53dbda7  sub rsp, 0x30
000076bac53dbdab  movaps [rsp], xmm1
000076bac53dbdaf  movaps [rsp+0x10], xmm4
000076bac53dbdb4  movaps [rsp+0x20], xmm9
000076bac53dbdba  lea rdi, [rsp]
000076bac53dbdbe  mov esi, 0x00
000076bac53dbdc3  mov rax, 0x5641B0A3C530
000076bac53dbdcd  call rax
000076bac53dbdcf  movaps xmm1, [rsp]
000076bac53dbdd3  add rsp, 0x30
000076bac53dbdd7  vmovaps xmm0, [rsp]
000076bac53dbddc  vmovaps xmm2, [rsp+0x10]
000076bac53dbde2  vmovaps xmm3, [rsp+0x20]
000076bac53dbde8  vmovaps xmm4, [rsp+0x30]
000076bac53dbdee  vmovaps xmm5, [rsp+0x40]
000076bac53dbdf4  vmovaps xmm6, [rsp+0x50]
000076bac53dbdfa  vmovaps xmm7, [rsp+0x60]
000076bac53dbe00  vmovaps xmm8, [rsp+0x70]
000076bac53dbe06  vmovaps xmm9, [rsp+0x80]
000076bac53dbe0f  vmovaps xmm10, [rsp+0x90]
000076bac53dbe18  vmovaps xmm11, [rsp+0xA0]
000076bac53dbe21  vmovaps xmm12, [rsp+0xB0]
000076bac53dbe2a  vmovaps xmm13, [rsp+0xC0]
000076bac53dbe33  vmovaps xmm14, [rsp+0xD0]
000076bac53dbe3c  vmovaps xmm15, [rsp+0xE0]
000076bac53dbe45  add rsp, 0xF0
000076bac53dbe4c  pop r11
000076bac53dbe4e  pop r10
000076bac53dbe50  pop r9
000076bac53dbe52  pop r8
000076bac53dbe54  pop rsi
000076bac53dbe55  pop rdi
000076bac53dbe56  pop rdx
000076bac53dbe57  pop rcx
000076bac53dbe58  pop rax
000076bac53dbe59  add rsp, 0x08
000076bac53dbe5d  jmp 0x000076BAC53D931B
000076bac53dbe62  sub rsp, 0x08
000076bac53dbe66  push rax
000076bac53dbe67  push rcx
000076bac53dbe68  push rdx
000076bac53dbe69  push rdi
000076bac53dbe6a  push rsi
000076bac53dbe6b  push r8
000076bac53dbe6d  push r9
000076bac53dbe6f  push r10
000076bac53dbe71  push r11
000076bac53dbe73  sub rsp, 0xF0
000076bac53dbe7a  vmovaps [rsp], xmm0
000076bac53dbe7f  vmovaps [rsp+0x10], xmm1
000076bac53dbe85  vmovaps [rsp+0x20], xmm2
000076bac53dbe8b  vmovaps [rsp+0x30], xmm3
000076bac53dbe91  vmovaps [rsp+0x40], xmm5
000076bac53dbe97  vmovaps [rsp+0x50], xmm6
000076bac53dbe9d  vmovaps [rsp+0x60], xmm7
000076bac53dbea3  vmovaps [rsp+0x70], xmm8
000076bac53dbea9  vmovaps [rsp+0x80], xmm9
000076bac53dbeb2  vmovaps [rsp+0x90], xmm10
000076bac53dbebb  vmovaps [rsp+0xA0], xmm11
000076bac53dbec4  vmovaps [rsp+0xB0], xmm12
000076bac53dbecd  vmovaps [rsp+0xC0], xmm13
000076bac53dbed6  vmovaps [rsp+0xD0], xmm14
000076bac53dbedf  vmovaps [rsp+0xE0], xmm15
000076bac53dbee8  sub rsp, 0x30
000076bac53dbeec  movaps [rsp], xmm4
000076bac53dbef0  movaps [rsp+0x10], xmm2
000076bac53dbef5  movaps [rsp+0x20], xmm9
000076bac53dbefb  lea rdi, [rsp]
000076bac53dbeff  mov esi, 0x00
000076bac53dbf04  mov rax, 0x5641B0A3C530
000076bac53dbf0e  call rax
000076bac53dbf10  movaps xmm4, [rsp]
000076bac53dbf14  add rsp, 0x30
000076bac53dbf18  vmovaps xmm0, [rsp]
000076bac53dbf1d  vmovaps xmm1, [rsp+0x10]
000076bac53dbf23  vmovaps xmm2, [rsp+0x20]
000076bac53dbf29  vmovaps xmm3, [rsp+0x30]
000076bac53dbf2f  vmovaps xmm5, [rsp+0x40]
000076bac53dbf35  vmovaps xmm6, [rsp+0x50]
000076bac53dbf3b  vmovaps xmm7, [rsp+0x60]
000076bac53dbf41  vmovaps xmm8, [rsp+0x70]
000076bac53dbf47  vmovaps xmm9, [rsp+0x80]
000076bac53dbf50  vmovaps xmm10, [rsp+0x90]
000076bac53dbf59  vmovaps xmm11, [rsp+0xA0]
000076bac53dbf62  vmovaps xmm12, [rsp+0xB0]
000076bac53dbf6b  vmovaps xmm13, [rsp+0xC0]
000076bac53dbf74  vmovaps xmm14, [rsp+0xD0]
000076bac53dbf7d  vmovaps xmm15, [rsp+0xE0]
000076bac53dbf86  add rsp, 0xF0
000076bac53dbf8d  pop r11
000076bac53dbf8f  pop r10
000076bac53dbf91  pop r9
000076bac53dbf93  pop r8
000076bac53dbf95  pop rsi
000076bac53dbf96  pop rdi
000076bac53dbf97  pop rdx
000076bac53dbf98  pop rcx
000076bac53dbf99  pop rax
000076bac53dbf9a  add rsp, 0x08
000076bac53dbf9e  jmp 0x000076BAC53D934B
000076bac53dbfa3  sub rsp, 0x08
000076bac53dbfa7  push rax
000076bac53dbfa8  push rcx
000076bac53dbfa9  push rdx
000076bac53dbfaa  push rdi
000076bac53dbfab  push rsi
000076bac53dbfac  push r8
000076bac53dbfae  push r9
000076bac53dbfb0  push r10
000076bac53dbfb2  push r11
000076bac53dbfb4  sub rsp, 0xF0
000076bac53dbfbb  vmovaps [rsp], xmm0
000076bac53dbfc0  vmovaps [rsp+0x10], xmm1
000076bac53dbfc6  vmovaps [rsp+0x20], xmm2
000076bac53dbfcc  vmovaps [rsp+0x30], xmm3
000076bac53dbfd2  vmovaps [rsp+0x40], xmm4
000076bac53dbfd8  vmovaps [rsp+0x50], xmm5
000076bac53dbfde  vmovaps [rsp+0x60], xmm6
000076bac53dbfe4  vmovaps [rsp+0x70], xmm7
000076bac53dbfea  vmovaps [rsp+0x80], xmm8
000076bac53dbff3  vmovaps [rsp+0x90], xmm10
000076bac53dbffc  vmovaps [rsp+0xA0], xmm11
000076bac53dc005  vmovaps [rsp+0xB0], xmm12
000076bac53dc00e  vmovaps [rsp+0xC0], xmm13
000076bac53dc017  vmovaps [rsp+0xD0], xmm14
000076bac53dc020  vmovaps [rsp+0xE0], xmm15
000076bac53dc029  sub rsp, 0x30
000076bac53dc02d  movaps [rsp], xmm9
000076bac53dc032  movaps [rsp+0x10], xmm2
000076bac53dc037  movaps [rsp+0x20], xmm1
000076bac53dc03c  lea rdi, [rsp]
000076bac53dc040  mov esi, 0x00
000076bac53dc045  mov rax, 0x5641B0A3C530
000076bac53dc04f  call rax
000076bac53dc051  movaps xmm9, [rsp]
000076bac53dc056  add rsp, 0x30
000076bac53dc05a  vmovaps xmm0, [rsp]
000076bac53dc05f  vmovaps xmm1, [rsp+0x10]
000076bac53dc065  vmovaps xmm2, [rsp+0x20]
000076bac53dc06b  vmovaps xmm3, [rsp+0x30]
000076bac53dc071  vmovaps xmm4, [rsp+0x40]
000076bac53dc077  vmovaps xmm5, [rsp+0x50]
000076bac53dc07d  vmovaps xmm6, [rsp+0x60]
000076bac53dc083  vmovaps xmm7, [rsp+0x70]
000076bac53dc089  vmovaps xmm8, [rsp+0x80]
000076bac53dc092  vmovaps xmm10, [rsp+0x90]
000076bac53dc09b  vmovaps xmm11, [rsp+0xA0]
000076bac53dc0a4  vmovaps xmm12, [rsp+0xB0]
000076bac53dc0ad  vmovaps xmm13, [rsp+0xC0]
000076bac53dc0b6  vmovaps xmm14, [rsp+0xD0]
000076bac53dc0bf  vmovaps xmm15, [rsp+0xE0]
000076bac53dc0c8  add rsp, 0xF0
000076bac53dc0cf  pop r11
000076bac53dc0d1  pop r10
000076bac53dc0d3  pop r9
000076bac53dc0d5  pop r8
000076bac53dc0d7  pop rsi
000076bac53dc0d8  pop rdi
000076bac53dc0d9  pop rdx
000076bac53dc0da  pop rcx
000076bac53dc0db  pop rax
000076bac53dc0dc  add rsp, 0x08
000076bac53dc0e0  jmp 0x000076BAC53D9381
000076bac53dc0e5  sub rsp, 0x08
000076bac53dc0e9  push rax
000076bac53dc0ea  push rcx
000076bac53dc0eb  push rdx
000076bac53dc0ec  push rdi
000076bac53dc0ed  push rsi
000076bac53dc0ee  push r8
000076bac53dc0f0  push r9
000076bac53dc0f2  push r10
000076bac53dc0f4  push r11
000076bac53dc0f6  sub rsp, 0xF0
000076bac53dc0fd  vmovaps [rsp], xmm0
000076bac53dc102  vmovaps [rsp+0x10], xmm2
000076bac53dc108  vmovaps [rsp+0x20], xmm3
000076bac53dc10e  vmovaps [rsp+0x30], xmm4
000076bac53dc114  vmovaps [rsp+0x40], xmm5
000076bac53dc11a  vmovaps [rsp+0x50], xmm6
000076bac53dc120  vmovaps [rsp+0x60], xmm7
000076bac53dc126  vmovaps [rsp+0x70], xmm8
000076bac53dc12c  vmovaps [rsp+0x80], xmm9
000076bac53dc135  vmovaps [rsp+0x90], xmm10
000076bac53dc13e  vmovaps [rsp+0xA0], xmm11
000076bac53dc147  vmovaps [rsp+0xB0], xmm12
000076bac53dc150  vmovaps [rsp+0xC0], xmm13
000076bac53dc159  vmovaps [rsp+0xD0], xmm14
000076bac53dc162  vmovaps [rsp+0xE0], xmm15
000076bac53dc16b  sub rsp, 0x30
000076bac53dc16f  movaps [rsp], xmm1
000076bac53dc173  movaps [rsp+0x10], xmm15
000076bac53dc179  movaps [rsp+0x20], xmm6
000076bac53dc17e  lea rdi, [rsp]
000076bac53dc182  mov esi, 0x00
000076bac53dc187  mov rax, 0x5641B0A3C530
000076bac53dc191  call rax
000076bac53dc193  movaps xmm1, [rsp]
000076bac53dc197  add rsp, 0x30
000076bac53dc19b  vmovaps xmm0, [rsp]
000076bac53dc1a0  vmovaps xmm2, [rsp+0x10]
000076bac53dc1a6  vmovaps xmm3, [rsp+0x20]
000076bac53dc1ac  vmovaps xmm4, [rsp+0x30]
000076bac53dc1b2  vmovaps xmm5, [rsp+0x40]
000076bac53dc1b8  vmovaps xmm6, [rsp+0x50]
000076bac53dc1be  vmovaps xmm7, [rsp+0x60]
000076bac53dc1c4  vmovaps xmm8, [rsp+0x70]
000076bac53dc1ca  vmovaps xmm9, [rsp+0x80]
000076bac53dc1d3  vmovaps xmm10, [rsp+0x90]
000076bac53dc1dc  vmovaps xmm11, [rsp+0xA0]
000076bac53dc1e5  vmovaps xmm12, [rsp+0xB0]
000076bac53dc1ee  vmovaps xmm13, [rsp+0xC0]
000076bac53dc1f7  vmovaps xmm14, [rsp+0xD0]
000076bac53dc200  vmovaps xmm15, [rsp+0xE0]
000076bac53dc209  add rsp, 0xF0
000076bac53dc210  pop r11
000076bac53dc212  pop r10
000076bac53dc214  pop r9
000076bac53dc216  pop r8
000076bac53dc218  pop rsi
000076bac53dc219  pop rdi
000076bac53dc21a  pop rdx
000076bac53dc21b  pop rcx
000076bac53dc21c  pop rax
000076bac53dc21d  add rsp, 0x08
000076bac53dc221  jmp 0x000076BAC53D93A2
000076bac53dc226  sub rsp, 0x08
000076bac53dc22a  push rax
000076bac53dc22b  push rcx
000076bac53dc22c  push rdx
000076bac53dc22d  push rdi
000076bac53dc22e  push rsi
000076bac53dc22f  push r8
000076bac53dc231  push r9
000076bac53dc233  push r10
000076bac53dc235  push r11
000076bac53dc237  sub rsp, 0xF0
000076bac53dc23e  vmovaps [rsp], xmm0
000076bac53dc243  vmovaps [rsp+0x10], xmm1
000076bac53dc249  vmovaps [rsp+0x20], xmm2
000076bac53dc24f  vmovaps [rsp+0x30], xmm3
000076bac53dc255  vmovaps [rsp+0x40], xmm4
000076bac53dc25b  vmovaps [rsp+0x50], xmm5
000076bac53dc261  vmovaps [rsp+0x60], xmm6
000076bac53dc267  vmovaps [rsp+0x70], xmm7
000076bac53dc26d  vmovaps [rsp+0x80], xmm8
000076bac53dc276  vmovaps [rsp+0x90], xmm9
000076bac53dc27f  vmovaps [rsp+0xA0], xmm10
000076bac53dc288  vmovaps [rsp+0xB0], xmm11
000076bac53dc291  vmovaps [rsp+0xC0], xmm12
000076bac53dc29a  vmovaps [rsp+0xD0], xmm13
000076bac53dc2a3  vmovaps [rsp+0xE0], xmm14
000076bac53dc2ac  sub rsp, 0x30
000076bac53dc2b0  movaps [rsp], xmm15
000076bac53dc2b5  movaps [rsp+0x10], xmm5
000076bac53dc2ba  movaps [rsp+0x20], xmm3
000076bac53dc2bf  lea rdi, [rsp]
000076bac53dc2c3  mov esi, 0x00
000076bac53dc2c8  mov rax, 0x5641B0A3C530
000076bac53dc2d2  call rax
000076bac53dc2d4  movaps xmm15, [rsp]
000076bac53dc2d9  add rsp, 0x30
000076bac53dc2dd  vmovaps xmm0, [rsp]
000076bac53dc2e2  vmovaps xmm1, [rsp+0x10]
000076bac53dc2e8  vmovaps xmm2, [rsp+0x20]
000076bac53dc2ee  vmovaps xmm3, [rsp+0x30]
000076bac53dc2f4  vmovaps xmm4, [rsp+0x40]
000076bac53dc2fa  vmovaps xmm5, [rsp+0x50]
000076bac53dc300  vmovaps xmm6, [rsp+0x60]
000076bac53dc306  vmovaps xmm7, [rsp+0x70]
000076bac53dc30c  vmovaps xmm8, [rsp+0x80]
000076bac53dc315  vmovaps xmm9, [rsp+0x90]
000076bac53dc31e  vmovaps xmm10, [rsp+0xA0]
000076bac53dc327  vmovaps xmm11, [rsp+0xB0]
000076bac53dc330  vmovaps xmm12, [rsp+0xC0]
000076bac53dc339  vmovaps xmm13, [rsp+0xD0]
000076bac53dc342  vmovaps xmm14, [rsp+0xE0]
000076bac53dc34b  add rsp, 0xF0
000076bac53dc352  pop r11
000076bac53dc354  pop r10
000076bac53dc356  pop r9
000076bac53dc358  pop r8
000076bac53dc35a  pop rsi
000076bac53dc35b  pop rdi
000076bac53dc35c  pop rdx
000076bac53dc35d  pop rcx
000076bac53dc35e  pop rax
000076bac53dc35f  add rsp, 0x08
000076bac53dc363  jmp 0x000076BAC53D93BC
000076bac53dc368  sub rsp, 0x08
000076bac53dc36c  push rax
000076bac53dc36d  push rcx
000076bac53dc36e  push rdx
000076bac53dc36f  push rdi
000076bac53dc370  push rsi
000076bac53dc371  push r8
000076bac53dc373  push r9
000076bac53dc375  push r10
000076bac53dc377  push r11
000076bac53dc379  sub rsp, 0xF0
000076bac53dc380  vmovaps [rsp], xmm0
000076bac53dc385  vmovaps [rsp+0x10], xmm1
000076bac53dc38b  vmovaps [rsp+0x20], xmm2
000076bac53dc391  vmovaps [rsp+0x30], xmm3
000076bac53dc397  vmovaps [rsp+0x40], xmm4
000076bac53dc39d  vmovaps [rsp+0x50], xmm6
000076bac53dc3a3  vmovaps [rsp+0x60], xmm7
000076bac53dc3a9  vmovaps [rsp+0x70], xmm8
000076bac53dc3af  vmovaps [rsp+0x80], xmm9
000076bac53dc3b8  vmovaps [rsp+0x90], xmm10
000076bac53dc3c1  vmovaps [rsp+0xA0], xmm11
000076bac53dc3ca  vmovaps [rsp+0xB0], xmm12
000076bac53dc3d3  vmovaps [rsp+0xC0], xmm13
000076bac53dc3dc  vmovaps [rsp+0xD0], xmm14
000076bac53dc3e5  vmovaps [rsp+0xE0], xmm15
000076bac53dc3ee  sub rsp, 0x30
000076bac53dc3f2  movaps [rsp], xmm5
000076bac53dc3f6  movaps [rsp+0x10], xmm8
000076bac53dc3fc  movaps [rsp+0x20], xmm6
000076bac53dc401  lea rdi, [rsp]
000076bac53dc405  mov esi, 0x00
000076bac53dc40a  mov rax, 0x5641B0A3C530
000076bac53dc414  call rax
000076bac53dc416  movaps xmm5, [rsp]
000076bac53dc41a  add rsp, 0x30
000076bac53dc41e  vmovaps xmm0, [rsp]
000076bac53dc423  vmovaps xmm1, [rsp+0x10]
000076bac53dc429  vmovaps xmm2, [rsp+0x20]
000076bac53dc42f  vmovaps xmm3, [rsp+0x30]
000076bac53dc435  vmovaps xmm4, [rsp+0x40]
000076bac53dc43b  vmovaps xmm6, [rsp+0x50]
000076bac53dc441  vmovaps xmm7, [rsp+0x60]
000076bac53dc447  vmovaps xmm8, [rsp+0x70]
000076bac53dc44d  vmovaps xmm9, [rsp+0x80]
000076bac53dc456  vmovaps xmm10, [rsp+0x90]
000076bac53dc45f  vmovaps xmm11, [rsp+0xA0]
000076bac53dc468  vmovaps xmm12, [rsp+0xB0]
000076bac53dc471  vmovaps xmm13, [rsp+0xC0]
000076bac53dc47a  vmovaps xmm14, [rsp+0xD0]
000076bac53dc483  vmovaps xmm15, [rsp+0xE0]
000076bac53dc48c  add rsp, 0xF0
000076bac53dc493  pop r11
000076bac53dc495  pop r10
000076bac53dc497  pop r9
000076bac53dc499  pop r8
000076bac53dc49b  pop rsi
000076bac53dc49c  pop rdi
000076bac53dc49d  pop rdx
000076bac53dc49e  pop rcx
000076bac53dc49f  pop rax
000076bac53dc4a0  add rsp, 0x08
000076bac53dc4a4  jmp 0x000076BAC53D93E0
000076bac53dc4a9  sub rsp, 0x08
000076bac53dc4ad  push rax
000076bac53dc4ae  push rcx
000076bac53dc4af  push rdx
000076bac53dc4b0  push rdi
000076bac53dc4b1  push rsi
000076bac53dc4b2  push r8
000076bac53dc4b4  push r9
000076bac53dc4b6  push r10
000076bac53dc4b8  push r11
000076bac53dc4ba  sub rsp, 0xF0
000076bac53dc4c1  vmovaps [rsp], xmm0
000076bac53dc4c6  vmovaps [rsp+0x10], xmm1
000076bac53dc4cc  vmovaps [rsp+0x20], xmm2
000076bac53dc4d2  vmovaps [rsp+0x30], xmm3
000076bac53dc4d8  vmovaps [rsp+0x40], xmm4
000076bac53dc4de  vmovaps [rsp+0x50], xmm5
000076bac53dc4e4  vmovaps [rsp+0x60], xmm7
000076bac53dc4ea  vmovaps [rsp+0x70], xmm8
000076bac53dc4f0  vmovaps [rsp+0x80], xmm9
000076bac53dc4f9  vmovaps [rsp+0x90], xmm10
000076bac53dc502  vmovaps [rsp+0xA0], xmm11
000076bac53dc50b  vmovaps [rsp+0xB0], xmm12
000076bac53dc514  vmovaps [rsp+0xC0], xmm13
000076bac53dc51d  vmovaps [rsp+0xD0], xmm14
000076bac53dc526  vmovaps [rsp+0xE0], xmm15
000076bac53dc52f  sub rsp, 0x30
000076bac53dc533  movaps [rsp], xmm6
000076bac53dc537  movaps [rsp+0x10], xmm10
000076bac53dc53d  movaps [rsp+0x20], xmm8
000076bac53dc543  lea rdi, [rsp]
000076bac53dc547  mov esi, 0x00
000076bac53dc54c  mov rax, 0x5641B0A3C530
000076bac53dc556  call rax
000076bac53dc558  movaps xmm6, [rsp]
000076bac53dc55c  add rsp, 0x30
000076bac53dc560  vmovaps xmm0, [rsp]
000076bac53dc565  vmovaps xmm1, [rsp+0x10]
000076bac53dc56b  vmovaps xmm2, [rsp+0x20]
000076bac53dc571  vmovaps xmm3, [rsp+0x30]
000076bac53dc577  vmovaps xmm4, [rsp+0x40]
000076bac53dc57d  vmovaps xmm5, [rsp+0x50]
000076bac53dc583  vmovaps xmm7, [rsp+0x60]
000076bac53dc589  vmovaps xmm8, [rsp+0x70]
000076bac53dc58f  vmovaps xmm9, [rsp+0x80]
000076bac53dc598  vmovaps xmm10, [rsp+0x90]
000076bac53dc5a1  vmovaps xmm11, [rsp+0xA0]
000076bac53dc5aa  vmovaps xmm12, [rsp+0xB0]
000076bac53dc5b3  vmovaps xmm13, [rsp+0xC0]
000076bac53dc5bc  vmovaps xmm14, [rsp+0xD0]
000076bac53dc5c5  vmovaps xmm15, [rsp+0xE0]
000076bac53dc5ce  add rsp, 0xF0
000076bac53dc5d5  pop r11
000076bac53dc5d7  pop r10
000076bac53dc5d9  pop r9
000076bac53dc5db  pop r8
000076bac53dc5dd  pop rsi
000076bac53dc5de  pop rdi
000076bac53dc5df  pop rdx
000076bac53dc5e0  pop rcx
000076bac53dc5e1  pop rax
000076bac53dc5e2  add rsp, 0x08
000076bac53dc5e6  jmp 0x000076BAC53D9405
000076bac53dc5eb  sub rsp, 0x08
000076bac53dc5ef  push rax
000076bac53dc5f0  push rcx
000076bac53dc5f1  push rdx
000076bac53dc5f2  push rdi
000076bac53dc5f3  push rsi
000076bac53dc5f4  push r8
000076bac53dc5f6  push r9
000076bac53dc5f8  push r10
000076bac53dc5fa  push r11
000076bac53dc5fc  sub rsp, 0xF0
000076bac53dc603  vmovaps [rsp], xmm0
000076bac53dc608  vmovaps [rsp+0x10], xmm1
000076bac53dc60e  vmovaps [rsp+0x20], xmm2
000076bac53dc614  vmovaps [rsp+0x30], xmm3
000076bac53dc61a  vmovaps [rsp+0x40], xmm4
000076bac53dc620  vmovaps [rsp+0x50], xmm5
000076bac53dc626  vmovaps [rsp+0x60], xmm6
000076bac53dc62c  vmovaps [rsp+0x70], xmm7
000076bac53dc632  vmovaps [rsp+0x80], xmm8
000076bac53dc63b  vmovaps [rsp+0x90], xmm9
000076bac53dc644  vmovaps [rsp+0xA0], xmm11
000076bac53dc64d  vmovaps [rsp+0xB0], xmm12
000076bac53dc656  vmovaps [rsp+0xC0], xmm13
000076bac53dc65f  vmovaps [rsp+0xD0], xmm14
000076bac53dc668  vmovaps [rsp+0xE0], xmm15
000076bac53dc671  sub rsp, 0x30
000076bac53dc675  movaps [rsp], xmm10
000076bac53dc67a  movaps [rsp+0x10], xmm8
000076bac53dc680  movaps [rsp+0x20], xmm14
000076bac53dc686  lea rdi, [rsp]
000076bac53dc68a  mov esi, 0x00
000076bac53dc68f  mov rax, 0x5641B0A3C530
000076bac53dc699  call rax
000076bac53dc69b  movaps xmm10, [rsp]
000076bac53dc6a0  add rsp, 0x30
000076bac53dc6a4  vmovaps xmm0, [rsp]
000076bac53dc6a9  vmovaps xmm1, [rsp+0x10]
000076bac53dc6af  vmovaps xmm2, [rsp+0x20]
000076bac53dc6b5  vmovaps xmm3, [rsp+0x30]
000076bac53dc6bb  vmovaps xmm4, [rsp+0x40]
000076bac53dc6c1  vmovaps xmm5, [rsp+0x50]
000076bac53dc6c7  vmovaps xmm6, [rsp+0x60]
000076bac53dc6cd  vmovaps xmm7, [rsp+0x70]
000076bac53dc6d3  vmovaps xmm8, [rsp+0x80]
000076bac53dc6dc  vmovaps xmm9, [rsp+0x90]
000076bac53dc6e5  vmovaps xmm11, [rsp+0xA0]
000076bac53dc6ee  vmovaps xmm12, [rsp+0xB0]
000076bac53dc6f7  vmovaps xmm13, [rsp+0xC0]
000076bac53dc700  vmovaps xmm14, [rsp+0xD0]
000076bac53dc709  vmovaps xmm15, [rsp+0xE0]
000076bac53dc712  add rsp, 0xF0
000076bac53dc719  pop r11
000076bac53dc71b  pop r10
000076bac53dc71d  pop r9
000076bac53dc71f  pop r8
000076bac53dc721  pop rsi
000076bac53dc722  pop rdi
000076bac53dc723  pop rdx
000076bac53dc724  pop rcx
000076bac53dc725  pop rax
000076bac53dc726  add rsp, 0x08
000076bac53dc72a  jmp 0x000076BAC53D9425
000076bac53dc72f  sub rsp, 0x08
000076bac53dc733  push rax
000076bac53dc734  push rcx
000076bac53dc735  push rdx
000076bac53dc736  push rdi
000076bac53dc737  push rsi
000076bac53dc738  push r8
000076bac53dc73a  push r9
000076bac53dc73c  push r10
000076bac53dc73e  push r11
000076bac53dc740  sub rsp, 0xF0
000076bac53dc747  vmovaps [rsp], xmm0
000076bac53dc74c  vmovaps [rsp+0x10], xmm1
000076bac53dc752  vmovaps [rsp+0x20], xmm2
000076bac53dc758  vmovaps [rsp+0x30], xmm3
000076bac53dc75e  vmovaps [rsp+0x40], xmm4
000076bac53dc764  vmovaps [rsp+0x50], xmm5
000076bac53dc76a  vmovaps [rsp+0x60], xmm6
000076bac53dc770  vmovaps [rsp+0x70], xmm7
000076bac53dc776  vmovaps [rsp+0x80], xmm8
000076bac53dc77f  vmovaps [rsp+0x90], xmm9
000076bac53dc788  vmovaps [rsp+0xA0], xmm10
000076bac53dc791  vmovaps [rsp+0xB0], xmm11
000076bac53dc79a  vmovaps [rsp+0xC0], xmm12
000076bac53dc7a3  vmovaps [rsp+0xD0], xmm13
000076bac53dc7ac  vmovaps [rsp+0xE0], xmm15
000076bac53dc7b5  sub rsp, 0x30
000076bac53dc7b9  movaps [rsp], xmm14
000076bac53dc7be  movaps [rsp+0x10], xmm8
000076bac53dc7c4  movaps [rsp+0x20], xmm4
000076bac53dc7c9  lea rdi, [rsp]
000076bac53dc7cd  mov esi, 0x00
000076bac53dc7d2  mov rax, 0x5641B0A3C530
000076bac53dc7dc  call rax
000076bac53dc7de  movaps xmm14, [rsp]
000076bac53dc7e3  add rsp, 0x30
000076bac53dc7e7  vmovaps xmm0, [rsp]
000076bac53dc7ec  vmovaps xmm1, [rsp+0x10]
000076bac53dc7f2  vmovaps xmm2, [rsp+0x20]
000076bac53dc7f8  vmovaps xmm3, [rsp+0x30]
000076bac53dc7fe  vmovaps xmm4, [rsp+0x40]
000076bac53dc804  vmovaps xmm5, [rsp+0x50]
000076bac53dc80a  vmovaps xmm6, [rsp+0x60]
000076bac53dc810  vmovaps xmm7, [rsp+0x70]
000076bac53dc816  vmovaps xmm8, [rsp+0x80]
000076bac53dc81f  vmovaps xmm9, [rsp+0x90]
000076bac53dc828  vmovaps xmm10, [rsp+0xA0]
000076bac53dc831  vmovaps xmm11, [rsp+0xB0]
000076bac53dc83a  vmovaps xmm12, [rsp+0xC0]
000076bac53dc843  vmovaps xmm13, [rsp+0xD0]
000076bac53dc84c  vmovaps xmm15, [rsp+0xE0]
000076bac53dc855  add rsp, 0xF0
000076bac53dc85c  pop r11
000076bac53dc85e  pop r10
000076bac53dc860  pop r9
000076bac53dc862  pop r8
000076bac53dc864  pop rsi
000076bac53dc865  pop rdi
000076bac53dc866  pop rdx
000076bac53dc867  pop rcx
000076bac53dc868  pop rax
000076bac53dc869  add rsp, 0x08
000076bac53dc86d  jmp 0x000076BAC53D9445
000076bac53dc872  sub rsp, 0x08
000076bac53dc876  push rax
000076bac53dc877  push rcx
000076bac53dc878  push rdx
000076bac53dc879  push rdi
000076bac53dc87a  push rsi
000076bac53dc87b  push r8
000076bac53dc87d  push r9
000076bac53dc87f  push r10
000076bac53dc881  push r11
000076bac53dc883  sub rsp, 0xF0
000076bac53dc88a  vmovaps [rsp], xmm0
000076bac53dc88f  vmovaps [rsp+0x10], xmm1
000076bac53dc895  vmovaps [rsp+0x20], xmm2
000076bac53dc89b  vmovaps [rsp+0x30], xmm3
000076bac53dc8a1  vmovaps [rsp+0x40], xmm5
000076bac53dc8a7  vmovaps [rsp+0x50], xmm6
000076bac53dc8ad  vmovaps [rsp+0x60], xmm7
000076bac53dc8b3  vmovaps [rsp+0x70], xmm8
000076bac53dc8b9  vmovaps [rsp+0x80], xmm9
000076bac53dc8c2  vmovaps [rsp+0x90], xmm10
000076bac53dc8cb  vmovaps [rsp+0xA0], xmm11
000076bac53dc8d4  vmovaps [rsp+0xB0], xmm12
000076bac53dc8dd  vmovaps [rsp+0xC0], xmm13
000076bac53dc8e6  vmovaps [rsp+0xD0], xmm14
000076bac53dc8ef  vmovaps [rsp+0xE0], xmm15
000076bac53dc8f8  sub rsp, 0x30
000076bac53dc8fc  movaps [rsp], xmm4
000076bac53dc900  movaps [rsp+0x10], xmm13
000076bac53dc906  movaps [rsp+0x20], xmm8
000076bac53dc90c  lea rdi, [rsp]
000076bac53dc910  mov esi, 0x00
000076bac53dc915  mov rax, 0x5641B0A3C530
000076bac53dc91f  call rax
000076bac53dc921  movaps xmm4, [rsp]
000076bac53dc925  add rsp, 0x30
000076bac53dc929  vmovaps xmm0, [rsp]
000076bac53dc92e  vmovaps xmm1, [rsp+0x10]
000076bac53dc934  vmovaps xmm2, [rsp+0x20]
000076bac53dc93a  vmovaps xmm3, [rsp+0x30]
000076bac53dc940  vmovaps xmm5, [rsp+0x40]
000076bac53dc946  vmovaps xmm6, [rsp+0x50]
000076bac53dc94c  vmovaps xmm7, [rsp+0x60]
000076bac53dc952  vmovaps xmm8, [rsp+0x70]
000076bac53dc958  vmovaps xmm9, [rsp+0x80]
000076bac53dc961  vmovaps xmm10, [rsp+0x90]
000076bac53dc96a  vmovaps xmm11, [rsp+0xA0]
000076bac53dc973  vmovaps xmm12, [rsp+0xB0]
000076bac53dc97c  vmovaps xmm13, [rsp+0xC0]
000076bac53dc985  vmovaps xmm14, [rsp+0xD0]
000076bac53dc98e  vmovaps xmm15, [rsp+0xE0]
000076bac53dc997  add rsp, 0xF0
000076bac53dc99e  pop r11
000076bac53dc9a0  pop r10
000076bac53dc9a2  pop r9
000076bac53dc9a4  pop r8
000076bac53dc9a6  pop rsi
000076bac53dc9a7  pop rdi
000076bac53dc9a8  pop rdx
000076bac53dc9a9  pop rcx
000076bac53dc9aa  pop rax
000076bac53dc9ab  add rsp, 0x08
000076bac53dc9af  jmp 0x000076BAC53D946A
000076bac53dc9b4  sub rsp, 0x08
000076bac53dc9b8  push rax
000076bac53dc9b9  push rcx
000076bac53dc9ba  push rdx
000076bac53dc9bb  push rdi
000076bac53dc9bc  push rsi
000076bac53dc9bd  push r8
000076bac53dc9bf  push r9
000076bac53dc9c1  push r10
000076bac53dc9c3  push r11
000076bac53dc9c5  sub rsp, 0xF0
000076bac53dc9cc  vmovaps [rsp], xmm0
000076bac53dc9d1  vmovaps [rsp+0x10], xmm1
000076bac53dc9d7  vmovaps [rsp+0x20], xmm2
000076bac53dc9dd  vmovaps [rsp+0x30], xmm3
000076bac53dc9e3  vmovaps [rsp+0x40], xmm4
000076bac53dc9e9  vmovaps [rsp+0x50], xmm5
000076bac53dc9ef  vmovaps [rsp+0x60], xmm6
000076bac53dc9f5  vmovaps [rsp+0x70], xmm7
000076bac53dc9fb  vmovaps [rsp+0x80], xmm8
000076bac53dca04  vmovaps [rsp+0x90], xmm9
000076bac53dca0d  vmovaps [rsp+0xA0], xmm10
000076bac53dca16  vmovaps [rsp+0xB0], xmm11
000076bac53dca1f  vmovaps [rsp+0xC0], xmm12
000076bac53dca28  vmovaps [rsp+0xD0], xmm14
000076bac53dca31  vmovaps [rsp+0xE0], xmm15
000076bac53dca3a  sub rsp, 0x30
000076bac53dca3e  movaps [rsp], xmm13
000076bac53dca43  movaps [rsp+0x10], xmm15
000076bac53dca49  movaps [rsp+0x20], xmm9
000076bac53dca4f  lea rdi, [rsp]
000076bac53dca53  mov esi, 0x00
000076bac53dca58  mov rax, 0x5641B0A3C530
000076bac53dca62  call rax
000076bac53dca64  movaps xmm13, [rsp]
000076bac53dca69  add rsp, 0x30
000076bac53dca6d  vmovaps xmm0, [rsp]
000076bac53dca72  vmovaps xmm1, [rsp+0x10]
000076bac53dca78  vmovaps xmm2, [rsp+0x20]
000076bac53dca7e  vmovaps xmm3, [rsp+0x30]
000076bac53dca84  vmovaps xmm4, [rsp+0x40]
000076bac53dca8a  vmovaps xmm5, [rsp+0x50]
000076bac53dca90  vmovaps xmm6, [rsp+0x60]
000076bac53dca96  vmovaps xmm7, [rsp+0x70]
000076bac53dca9c  vmovaps xmm8, [rsp+0x80]
000076bac53dcaa5  vmovaps xmm9, [rsp+0x90]
000076bac53dcaae  vmovaps xmm10, [rsp+0xA0]
000076bac53dcab7  vmovaps xmm11, [rsp+0xB0]
000076bac53dcac0  vmovaps xmm12, [rsp+0xC0]
000076bac53dcac9  vmovaps xmm14, [rsp+0xD0]
000076bac53dcad2  vmovaps xmm15, [rsp+0xE0]
000076bac53dcadb  add rsp, 0xF0
000076bac53dcae2  pop r11
000076bac53dcae4  pop r10
000076bac53dcae6  pop r9
000076bac53dcae8  pop r8
000076bac53dcaea  pop rsi
000076bac53dcaeb  pop rdi
000076bac53dcaec  pop rdx
000076bac53dcaed  pop rcx
000076bac53dcaee  pop rax
000076bac53dcaef  add rsp, 0x08
000076bac53dcaf3  jmp 0x000076BAC53D9485
000076bac53dcaf8  sub rsp, 0x08
000076bac53dcafc  push rax
000076bac53dcafd  push rcx
000076bac53dcafe  push rdx
000076bac53dcaff  push rdi
000076bac53dcb00  push rsi
000076bac53dcb01  push r8
000076bac53dcb03  push r9
000076bac53dcb05  push r10
000076bac53dcb07  push r11
000076bac53dcb09  sub rsp, 0xF0
000076bac53dcb10  vmovaps [rsp], xmm0
000076bac53dcb15  vmovaps [rsp+0x10], xmm1
000076bac53dcb1b  vmovaps [rsp+0x20], xmm2
000076bac53dcb21  vmovaps [rsp+0x30], xmm3
000076bac53dcb27  vmovaps [rsp+0x40], xmm4
000076bac53dcb2d  vmovaps [rsp+0x50], xmm5
000076bac53dcb33  vmovaps [rsp+0x60], xmm6
000076bac53dcb39  vmovaps [rsp+0x70], xmm7
000076bac53dcb3f  vmovaps [rsp+0x80], xmm8
000076bac53dcb48  vmovaps [rsp+0x90], xmm9
000076bac53dcb51  vmovaps [rsp+0xA0], xmm10
000076bac53dcb5a  vmovaps [rsp+0xB0], xmm11
000076bac53dcb63  vmovaps [rsp+0xC0], xmm12
000076bac53dcb6c  vmovaps [rsp+0xD0], xmm13
000076bac53dcb75  vmovaps [rsp+0xE0], xmm14
000076bac53dcb7e  sub rsp, 0x30
000076bac53dcb82  movaps [rsp], xmm15
000076bac53dcb87  movaps [rsp+0x10], xmm1
000076bac53dcb8c  movaps [rsp+0x20], xmm5
000076bac53dcb91  lea rdi, [rsp]
000076bac53dcb95  mov esi, 0x00
000076bac53dcb9a  mov rax, 0x5641B0A3C530
000076bac53dcba4  call rax
000076bac53dcba6  movaps xmm15, [rsp]
000076bac53dcbab  add rsp, 0x30
000076bac53dcbaf  vmovaps xmm0, [rsp]
000076bac53dcbb4  vmovaps xmm1, [rsp+0x10]
000076bac53dcbba  vmovaps xmm2, [rsp+0x20]
000076bac53dcbc0  vmovaps xmm3, [rsp+0x30]
000076bac53dcbc6  vmovaps xmm4, [rsp+0x40]
000076bac53dcbcc  vmovaps xmm5, [rsp+0x50]
000076bac53dcbd2  vmovaps xmm6, [rsp+0x60]
000076bac53dcbd8  vmovaps xmm7, [rsp+0x70]
000076bac53dcbde  vmovaps xmm8, [rsp+0x80]
000076bac53dcbe7  vmovaps xmm9, [rsp+0x90]
000076bac53dcbf0  vmovaps xmm10, [rsp+0xA0]
000076bac53dcbf9  vmovaps xmm11, [rsp+0xB0]
000076bac53dcc02  vmovaps xmm12, [rsp+0xC0]
000076bac53dcc0b  vmovaps xmm13, [rsp+0xD0]
000076bac53dcc14  vmovaps xmm14, [rsp+0xE0]
000076bac53dcc1d  add rsp, 0xF0
000076bac53dcc24  pop r11
000076bac53dcc26  pop r10
000076bac53dcc28  pop r9
000076bac53dcc2a  pop r8
000076bac53dcc2c  pop rsi
000076bac53dcc2d  pop rdi
000076bac53dcc2e  pop rdx
000076bac53dcc2f  pop rcx
000076bac53dcc30  pop rax
000076bac53dcc31  add rsp, 0x08
000076bac53dcc35  jmp 0x000076BAC53D94A0
000076bac53dcc3a  call 0x000076BAC52D64F0
000076bac53dcc3f  jmp 0x000076BAC53D94FB
000076bac53dcc44  sub rsp, 0x08
000076bac53dcc48  push rax
000076bac53dcc49  push rcx
000076bac53dcc4a  push rdx
000076bac53dcc4b  push rdi
000076bac53dcc4c  push rsi
000076bac53dcc4d  push r8
000076bac53dcc4f  push r9
000076bac53dcc51  push r10
000076bac53dcc53  push r11
000076bac53dcc55  sub rsp, 0xF0
000076bac53dcc5c  vmovaps [rsp], xmm0
000076bac53dcc61  vmovaps [rsp+0x10], xmm1
000076bac53dcc67  vmovaps [rsp+0x20], xmm2
000076bac53dcc6d  vmovaps [rsp+0x30], xmm3
000076bac53dcc73  vmovaps [rsp+0x40], xmm4
000076bac53dcc79  vmovaps [rsp+0x50], xmm5
000076bac53dcc7f  vmovaps [rsp+0x60], xmm6
000076bac53dcc85  vmovaps [rsp+0x70], xmm7
000076bac53dcc8b  vmovaps [rsp+0x80], xmm8
000076bac53dcc94  vmovaps [rsp+0x90], xmm10
000076bac53dcc9d  vmovaps [rsp+0xA0], xmm11
000076bac53dcca6  vmovaps [rsp+0xB0], xmm12
000076bac53dccaf  vmovaps [rsp+0xC0], xmm13
000076bac53dccb8  vmovaps [rsp+0xD0], xmm14
000076bac53dccc1  vmovaps [rsp+0xE0], xmm15
000076bac53dccca  sub rsp, 0x30
000076bac53dccce  movaps [rsp], xmm9
000076bac53dccd3  movaps [rsp+0x10], xmm8
000076bac53dccd9  movaps [rsp+0x20], xmm11
000076bac53dccdf  lea rdi, [rsp]
000076bac53dcce3  mov esi, 0x00
000076bac53dcce8  mov rax, 0x5641B0A3C530
000076bac53dccf2  call rax
000076bac53dccf4  movaps xmm9, [rsp]
000076bac53dccf9  add rsp, 0x30
000076bac53dccfd  vmovaps xmm0, [rsp]
000076bac53dcd02  vmovaps xmm1, [rsp+0x10]
000076bac53dcd08  vmovaps xmm2, [rsp+0x20]
000076bac53dcd0e  vmovaps xmm3, [rsp+0x30]
000076bac53dcd14  vmovaps xmm4, [rsp+0x40]
000076bac53dcd1a  vmovaps xmm5, [rsp+0x50]
000076bac53dcd20  vmovaps xmm6, [rsp+0x60]
000076bac53dcd26  vmovaps xmm7, [rsp+0x70]
000076bac53dcd2c  vmovaps xmm8, [rsp+0x80]
000076bac53dcd35  vmovaps xmm10, [rsp+0x90]
000076bac53dcd3e  vmovaps xmm11, [rsp+0xA0]
000076bac53dcd47  vmovaps xmm12, [rsp+0xB0]
000076bac53dcd50  vmovaps xmm13, [rsp+0xC0]
000076bac53dcd59  vmovaps xmm14, [rsp+0xD0]
000076bac53dcd62  vmovaps xmm15, [rsp+0xE0]
000076bac53dcd6b  add rsp, 0xF0
000076bac53dcd72  pop r11
000076bac53dcd74  pop r10
000076bac53dcd76  pop r9
000076bac53dcd78  pop r8
000076bac53dcd7a  pop rsi
000076bac53dcd7b  pop rdi
000076bac53dcd7c  pop rdx
000076bac53dcd7d  pop rcx
000076bac53dcd7e  pop rax
000076bac53dcd7f  add rsp, 0x08
000076bac53dcd83  jmp 0x000076BAC53D9532
000076bac53dcd88  sub rsp, 0x08
000076bac53dcd8c  push rax
000076bac53dcd8d  push rcx
000076bac53dcd8e  push rdx
000076bac53dcd8f  push rdi
000076bac53dcd90  push rsi
000076bac53dcd91  push r8
000076bac53dcd93  push r9
000076bac53dcd95  push r10
000076bac53dcd97  push r11
000076bac53dcd99  sub rsp, 0xF0
000076bac53dcda0  vmovaps [rsp], xmm0
000076bac53dcda5  vmovaps [rsp+0x10], xmm1
000076bac53dcdab  vmovaps [rsp+0x20], xmm2
000076bac53dcdb1  vmovaps [rsp+0x30], xmm3
000076bac53dcdb7  vmovaps [rsp+0x40], xmm4
000076bac53dcdbd  vmovaps [rsp+0x50], xmm5
000076bac53dcdc3  vmovaps [rsp+0x60], xmm6
000076bac53dcdc9  vmovaps [rsp+0x70], xmm7
000076bac53dcdcf  vmovaps [rsp+0x80], xmm8
000076bac53dcdd8  vmovaps [rsp+0x90], xmm9
000076bac53dcde1  vmovaps [rsp+0xA0], xmm10
000076bac53dcdea  vmovaps [rsp+0xB0], xmm12
000076bac53dcdf3  vmovaps [rsp+0xC0], xmm13
000076bac53dcdfc  vmovaps [rsp+0xD0], xmm14
000076bac53dce05  vmovaps [rsp+0xE0], xmm15
000076bac53dce0e  sub rsp, 0x30
000076bac53dce12  movaps [rsp], xmm11
000076bac53dce17  movaps [rsp+0x10], xmm10
000076bac53dce1d  movaps [rsp+0x20], xmm6
000076bac53dce22  lea rdi, [rsp]
000076bac53dce26  mov esi, 0x00
000076bac53dce2b  mov rax, 0x5641B0A3C530
000076bac53dce35  call rax
000076bac53dce37  movaps xmm11, [rsp]
000076bac53dce3c  add rsp, 0x30
000076bac53dce40  vmovaps xmm0, [rsp]
000076bac53dce45  vmovaps xmm1, [rsp+0x10]
000076bac53dce4b  vmovaps xmm2, [rsp+0x20]
000076bac53dce51  vmovaps xmm3, [rsp+0x30]
000076bac53dce57  vmovaps xmm4, [rsp+0x40]
000076bac53dce5d  vmovaps xmm5, [rsp+0x50]
000076bac53dce63  vmovaps xmm6, [rsp+0x60]
000076bac53dce69  vmovaps xmm7, [rsp+0x70]
000076bac53dce6f  vmovaps xmm8, [rsp+0x80]
000076bac53dce78  vmovaps xmm9, [rsp+0x90]
000076bac53dce81  vmovaps xmm10, [rsp+0xA0]
000076bac53dce8a  vmovaps xmm12, [rsp+0xB0]
000076bac53dce93  vmovaps xmm13, [rsp+0xC0]
000076bac53dce9c  vmovaps xmm14, [rsp+0xD0]
000076bac53dcea5  vmovaps xmm15, [rsp+0xE0]
000076bac53dceae  add rsp, 0xF0
000076bac53dceb5  pop r11
000076bac53dceb7  pop r10
000076bac53dceb9  pop r9
000076bac53dcebb  pop r8
000076bac53dcebd  pop rsi
000076bac53dcebe  pop rdi
000076bac53dcebf  pop rdx
000076bac53dcec0  pop rcx
000076bac53dcec1  pop rax
000076bac53dcec2  add rsp, 0x08
000076bac53dcec6  jmp 0x000076BAC53D954D
000076bac53dcecb  sub rsp, 0x08
000076bac53dcecf  push rax
000076bac53dced0  push rcx
000076bac53dced1  push rdx
000076bac53dced2  push rdi
000076bac53dced3  push rsi
000076bac53dced4  push r8
000076bac53dced6  push r9
000076bac53dced8  push r10
000076bac53dceda  push r11
000076bac53dcedc  sub rsp, 0xF0
000076bac53dcee3  vmovaps [rsp], xmm0
000076bac53dcee8  vmovaps [rsp+0x10], xmm1
000076bac53dceee  vmovaps [rsp+0x20], xmm2
000076bac53dcef4  vmovaps [rsp+0x30], xmm3
000076bac53dcefa  vmovaps [rsp+0x40], xmm4
000076bac53dcf00  vmovaps [rsp+0x50], xmm5
000076bac53dcf06  vmovaps [rsp+0x60], xmm6
000076bac53dcf0c  vmovaps [rsp+0x70], xmm7
000076bac53dcf12  vmovaps [rsp+0x80], xmm8
000076bac53dcf1b  vmovaps [rsp+0x90], xmm9
000076bac53dcf24  vmovaps [rsp+0xA0], xmm11
000076bac53dcf2d  vmovaps [rsp+0xB0], xmm12
000076bac53dcf36  vmovaps [rsp+0xC0], xmm13
000076bac53dcf3f  vmovaps [rsp+0xD0], xmm14
000076bac53dcf48  vmovaps [rsp+0xE0], xmm15
000076bac53dcf51  sub rsp, 0x30
000076bac53dcf55  movaps [rsp], xmm10
000076bac53dcf5a  movaps [rsp+0x10], xmm14
000076bac53dcf60  movaps [rsp+0x20], xmm4
000076bac53dcf65  lea rdi, [rsp]
000076bac53dcf69  mov esi, 0x00
000076bac53dcf6e  mov rax, 0x5641B0A3C530
000076bac53dcf78  call rax
000076bac53dcf7a  movaps xmm10, [rsp]
000076bac53dcf7f  add rsp, 0x30
000076bac53dcf83  vmovaps xmm0, [rsp]
000076bac53dcf88  vmovaps xmm1, [rsp+0x10]
000076bac53dcf8e  vmovaps xmm2, [rsp+0x20]
000076bac53dcf94  vmovaps xmm3, [rsp+0x30]
000076bac53dcf9a  vmovaps xmm4, [rsp+0x40]
000076bac53dcfa0  vmovaps xmm5, [rsp+0x50]
000076bac53dcfa6  vmovaps xmm6, [rsp+0x60]
000076bac53dcfac  vmovaps xmm7, [rsp+0x70]
000076bac53dcfb2  vmovaps xmm8, [rsp+0x80]
000076bac53dcfbb  vmovaps xmm9, [rsp+0x90]
000076bac53dcfc4  vmovaps xmm11, [rsp+0xA0]
000076bac53dcfcd  vmovaps xmm12, [rsp+0xB0]
000076bac53dcfd6  vmovaps xmm13, [rsp+0xC0]
000076bac53dcfdf  vmovaps xmm14, [rsp+0xD0]
000076bac53dcfe8  vmovaps xmm15, [rsp+0xE0]
000076bac53dcff1  add rsp, 0xF0
000076bac53dcff8  pop r11
000076bac53dcffa  pop r10
000076bac53dcffc  pop r9
000076bac53dcffe  pop r8
000076bac53dd000  pop rsi
000076bac53dd001  pop rdi
000076bac53dd002  pop rdx
000076bac53dd003  pop rcx
000076bac53dd004  pop rax
000076bac53dd005  add rsp, 0x08
000076bac53dd009  jmp 0x000076BAC53D9568
000076bac53dd00e  sub rsp, 0x08
000076bac53dd012  push rax
000076bac53dd013  push rcx
000076bac53dd014  push rdx
000076bac53dd015  push rdi
000076bac53dd016  push rsi
000076bac53dd017  push r8
000076bac53dd019  push r9
000076bac53dd01b  push r10
000076bac53dd01d  push r11
000076bac53dd01f  sub rsp, 0xF0
000076bac53dd026  vmovaps [rsp], xmm0
000076bac53dd02b  vmovaps [rsp+0x10], xmm1
000076bac53dd031  vmovaps [rsp+0x20], xmm2
000076bac53dd037  vmovaps [rsp+0x30], xmm3
000076bac53dd03d  vmovaps [rsp+0x40], xmm4
000076bac53dd043  vmovaps [rsp+0x50], xmm5
000076bac53dd049  vmovaps [rsp+0x60], xmm6
000076bac53dd04f  vmovaps [rsp+0x70], xmm7
000076bac53dd055  vmovaps [rsp+0x80], xmm9
000076bac53dd05e  vmovaps [rsp+0x90], xmm10
000076bac53dd067  vmovaps [rsp+0xA0], xmm11
000076bac53dd070  vmovaps [rsp+0xB0], xmm12
000076bac53dd079  vmovaps [rsp+0xC0], xmm13
000076bac53dd082  vmovaps [rsp+0xD0], xmm14
000076bac53dd08b  vmovaps [rsp+0xE0], xmm15
000076bac53dd094  sub rsp, 0x30
000076bac53dd098  movaps [rsp], xmm8
000076bac53dd09d  movaps [rsp+0x10], xmm1
000076bac53dd0a2  movaps [rsp+0x20], xmm14
000076bac53dd0a8  lea rdi, [rsp]
000076bac53dd0ac  mov esi, 0x00
000076bac53dd0b1  mov rax, 0x5641B0A3C530
000076bac53dd0bb  call rax
000076bac53dd0bd  movaps xmm8, [rsp]
000076bac53dd0c2  add rsp, 0x30
000076bac53dd0c6  vmovaps xmm0, [rsp]
000076bac53dd0cb  vmovaps xmm1, [rsp+0x10]
000076bac53dd0d1  vmovaps xmm2, [rsp+0x20]
000076bac53dd0d7  vmovaps xmm3, [rsp+0x30]
000076bac53dd0dd  vmovaps xmm4, [rsp+0x40]
000076bac53dd0e3  vmovaps xmm5, [rsp+0x50]
000076bac53dd0e9  vmovaps xmm6, [rsp+0x60]
000076bac53dd0ef  vmovaps xmm7, [rsp+0x70]
000076bac53dd0f5  vmovaps xmm9, [rsp+0x80]
000076bac53dd0fe  vmovaps xmm10, [rsp+0x90]
000076bac53dd107  vmovaps xmm11, [rsp+0xA0]
000076bac53dd110  vmovaps xmm12, [rsp+0xB0]
000076bac53dd119  vmovaps xmm13, [rsp+0xC0]
000076bac53dd122  vmovaps xmm14, [rsp+0xD0]
000076bac53dd12b  vmovaps xmm15, [rsp+0xE0]
000076bac53dd134  add rsp, 0xF0
000076bac53dd13b  pop r11
000076bac53dd13d  pop r10
000076bac53dd13f  pop r9
000076bac53dd141  pop r8
000076bac53dd143  pop rsi
000076bac53dd144  pop rdi
000076bac53dd145  pop rdx
000076bac53dd146  pop rcx
000076bac53dd147  pop rax
000076bac53dd148  add rsp, 0x08
000076bac53dd14c  jmp 0x000076BAC53D958E
000076bac53dd151  sub rsp, 0x08
000076bac53dd155  push rax
000076bac53dd156  push rcx
000076bac53dd157  push rdx
000076bac53dd158  push rdi
000076bac53dd159  push rsi
000076bac53dd15a  push r8
000076bac53dd15c  push r9
000076bac53dd15e  push r10
000076bac53dd160  push r11
000076bac53dd162  sub rsp, 0xF0
000076bac53dd169  vmovaps [rsp], xmm0
000076bac53dd16e  vmovaps [rsp+0x10], xmm1
000076bac53dd174  vmovaps [rsp+0x20], xmm2
000076bac53dd17a  vmovaps [rsp+0x30], xmm3
000076bac53dd180  vmovaps [rsp+0x40], xmm4
000076bac53dd186  vmovaps [rsp+0x50], xmm5
000076bac53dd18c  vmovaps [rsp+0x60], xmm7
000076bac53dd192  vmovaps [rsp+0x70], xmm8
000076bac53dd198  vmovaps [rsp+0x80], xmm9
000076bac53dd1a1  vmovaps [rsp+0x90], xmm10
000076bac53dd1aa  vmovaps [rsp+0xA0], xmm11
000076bac53dd1b3  vmovaps [rsp+0xB0], xmm12
000076bac53dd1bc  vmovaps [rsp+0xC0], xmm13
000076bac53dd1c5  vmovaps [rsp+0xD0], xmm14
000076bac53dd1ce  vmovaps [rsp+0xE0], xmm15
000076bac53dd1d7  sub rsp, 0x30
000076bac53dd1db  movaps [rsp], xmm6
000076bac53dd1df  movaps [rsp+0x10], xmm1
000076bac53dd1e4  movaps [rsp+0x20], xmm14
000076bac53dd1ea  lea rdi, [rsp]
000076bac53dd1ee  mov esi, 0x00
000076bac53dd1f3  mov rax, 0x5641B0A3C530
000076bac53dd1fd  call rax
000076bac53dd1ff  movaps xmm6, [rsp]
000076bac53dd203  add rsp, 0x30
000076bac53dd207  vmovaps xmm0, [rsp]
000076bac53dd20c  vmovaps xmm1, [rsp+0x10]
000076bac53dd212  vmovaps xmm2, [rsp+0x20]
000076bac53dd218  vmovaps xmm3, [rsp+0x30]
000076bac53dd21e  vmovaps xmm4, [rsp+0x40]
000076bac53dd224  vmovaps xmm5, [rsp+0x50]
000076bac53dd22a  vmovaps xmm7, [rsp+0x60]
000076bac53dd230  vmovaps xmm8, [rsp+0x70]
000076bac53dd236  vmovaps xmm9, [rsp+0x80]
000076bac53dd23f  vmovaps xmm10, [rsp+0x90]
000076bac53dd248  vmovaps xmm11, [rsp+0xA0]
000076bac53dd251  vmovaps xmm12, [rsp+0xB0]
000076bac53dd25a  vmovaps xmm13, [rsp+0xC0]
000076bac53dd263  vmovaps xmm14, [rsp+0xD0]
000076bac53dd26c  vmovaps xmm15, [rsp+0xE0]
000076bac53dd275  add rsp, 0xF0
000076bac53dd27c  pop r11
000076bac53dd27e  pop r10
000076bac53dd280  pop r9
000076bac53dd282  pop r8
000076bac53dd284  pop rsi
000076bac53dd285  pop rdi
000076bac53dd286  pop rdx
000076bac53dd287  pop rcx
000076bac53dd288  pop rax
000076bac53dd289  add rsp, 0x08
000076bac53dd28d  jmp 0x000076BAC53D95BA
000076bac53dd292  sub rsp, 0x08
000076bac53dd296  push rax
000076bac53dd297  push rcx
000076bac53dd298  push rdx
000076bac53dd299  push rdi
000076bac53dd29a  push rsi
000076bac53dd29b  push r8
000076bac53dd29d  push r9
000076bac53dd29f  push r10
000076bac53dd2a1  push r11
000076bac53dd2a3  sub rsp, 0xF0
000076bac53dd2aa  vmovaps [rsp], xmm0
000076bac53dd2af  vmovaps [rsp+0x10], xmm1
000076bac53dd2b5  vmovaps [rsp+0x20], xmm2
000076bac53dd2bb  vmovaps [rsp+0x30], xmm3
000076bac53dd2c1  vmovaps [rsp+0x40], xmm4
000076bac53dd2c7  vmovaps [rsp+0x50], xmm5
000076bac53dd2cd  vmovaps [rsp+0x60], xmm6
000076bac53dd2d3  vmovaps [rsp+0x70], xmm7
000076bac53dd2d9  vmovaps [rsp+0x80], xmm8
000076bac53dd2e2  vmovaps [rsp+0x90], xmm9
000076bac53dd2eb  vmovaps [rsp+0xA0], xmm10
000076bac53dd2f4  vmovaps [rsp+0xB0], xmm11
000076bac53dd2fd  vmovaps [rsp+0xC0], xmm12
000076bac53dd306  vmovaps [rsp+0xD0], xmm13
000076bac53dd30f  vmovaps [rsp+0xE0], xmm15
000076bac53dd318  sub rsp, 0x30
000076bac53dd31c  movaps [rsp], xmm14
000076bac53dd321  movaps [rsp+0x10], xmm12
000076bac53dd327  movaps [rsp+0x20], xmm1
000076bac53dd32c  lea rdi, [rsp]
000076bac53dd330  mov esi, 0x00
000076bac53dd335  mov rax, 0x5641B0A3C530
000076bac53dd33f  call rax
000076bac53dd341  movaps xmm14, [rsp]
000076bac53dd346  add rsp, 0x30
000076bac53dd34a  vmovaps xmm0, [rsp]
000076bac53dd34f  vmovaps xmm1, [rsp+0x10]
000076bac53dd355  vmovaps xmm2, [rsp+0x20]
000076bac53dd35b  vmovaps xmm3, [rsp+0x30]
000076bac53dd361  vmovaps xmm4, [rsp+0x40]
000076bac53dd367  vmovaps xmm5, [rsp+0x50]
000076bac53dd36d  vmovaps xmm6, [rsp+0x60]
000076bac53dd373  vmovaps xmm7, [rsp+0x70]
000076bac53dd379  vmovaps xmm8, [rsp+0x80]
000076bac53dd382  vmovaps xmm9, [rsp+0x90]
000076bac53dd38b  vmovaps xmm10, [rsp+0xA0]
000076bac53dd394  vmovaps xmm11, [rsp+0xB0]
000076bac53dd39d  vmovaps xmm12, [rsp+0xC0]
000076bac53dd3a6  vmovaps xmm13, [rsp+0xD0]
000076bac53dd3af  vmovaps xmm15, [rsp+0xE0]
000076bac53dd3b8  add rsp, 0xF0
000076bac53dd3bf  pop r11
000076bac53dd3c1  pop r10
000076bac53dd3c3  pop r9
000076bac53dd3c5  pop r8
000076bac53dd3c7  pop rsi
000076bac53dd3c8  pop rdi
000076bac53dd3c9  pop rdx
000076bac53dd3ca  pop rcx
000076bac53dd3cb  pop rax
000076bac53dd3cc  add rsp, 0x08
000076bac53dd3d0  jmp 0x000076BAC53D95E0
000076bac53dd3d5  sub rsp, 0x08
000076bac53dd3d9  push rax
000076bac53dd3da  push rcx
000076bac53dd3db  push rdx
000076bac53dd3dc  push rdi
000076bac53dd3dd  push rsi
000076bac53dd3de  push r8
000076bac53dd3e0  push r9
000076bac53dd3e2  push r10
000076bac53dd3e4  push r11
000076bac53dd3e6  sub rsp, 0xF0
000076bac53dd3ed  vmovaps [rsp], xmm0
000076bac53dd3f2  vmovaps [rsp+0x10], xmm2
000076bac53dd3f8  vmovaps [rsp+0x20], xmm3
000076bac53dd3fe  vmovaps [rsp+0x30], xmm4
000076bac53dd404  vmovaps [rsp+0x40], xmm5
000076bac53dd40a  vmovaps [rsp+0x50], xmm6
000076bac53dd410  vmovaps [rsp+0x60], xmm7
000076bac53dd416  vmovaps [rsp+0x70], xmm8
000076bac53dd41c  vmovaps [rsp+0x80], xmm9
000076bac53dd425  vmovaps [rsp+0x90], xmm10
000076bac53dd42e  vmovaps [rsp+0xA0], xmm11
000076bac53dd437  vmovaps [rsp+0xB0], xmm12
000076bac53dd440  vmovaps [rsp+0xC0], xmm13
000076bac53dd449  vmovaps [rsp+0xD0], xmm14
000076bac53dd452  vmovaps [rsp+0xE0], xmm15
000076bac53dd45b  sub rsp, 0x30
000076bac53dd45f  movaps [rsp], xmm1
000076bac53dd463  movaps [rsp+0x10], xmm13
000076bac53dd469  movaps [rsp+0x20], xmm9
000076bac53dd46f  lea rdi, [rsp]
000076bac53dd473  mov esi, 0x00
000076bac53dd478  mov rax, 0x5641B0A3C530
000076bac53dd482  call rax
000076bac53dd484  movaps xmm1, [rsp]
000076bac53dd488  add rsp, 0x30
000076bac53dd48c  vmovaps xmm0, [rsp]
000076bac53dd491  vmovaps xmm2, [rsp+0x10]
000076bac53dd497  vmovaps xmm3, [rsp+0x20]
000076bac53dd49d  vmovaps xmm4, [rsp+0x30]
000076bac53dd4a3  vmovaps xmm5, [rsp+0x40]
000076bac53dd4a9  vmovaps xmm6, [rsp+0x50]
000076bac53dd4af  vmovaps xmm7, [rsp+0x60]
000076bac53dd4b5  vmovaps xmm8, [rsp+0x70]
000076bac53dd4bb  vmovaps xmm9, [rsp+0x80]
000076bac53dd4c4  vmovaps xmm10, [rsp+0x90]
000076bac53dd4cd  vmovaps xmm11, [rsp+0xA0]
000076bac53dd4d6  vmovaps xmm12, [rsp+0xB0]
000076bac53dd4df  vmovaps xmm13, [rsp+0xC0]
000076bac53dd4e8  vmovaps xmm14, [rsp+0xD0]
000076bac53dd4f1  vmovaps xmm15, [rsp+0xE0]
000076bac53dd4fa  add rsp, 0xF0
000076bac53dd501  pop r11
000076bac53dd503  pop r10
000076bac53dd505  pop r9
000076bac53dd507  pop r8
000076bac53dd509  pop rsi
000076bac53dd50a  pop rdi
000076bac53dd50b  pop rdx
000076bac53dd50c  pop rcx
000076bac53dd50d  pop rax
000076bac53dd50e  add rsp, 0x08
000076bac53dd512  jmp 0x000076BAC53D95FA
000076bac53dd517  sub rsp, 0x08
000076bac53dd51b  push rax
000076bac53dd51c  push rcx
000076bac53dd51d  push rdx
000076bac53dd51e  push rdi
000076bac53dd51f  push rsi
000076bac53dd520  push r8
000076bac53dd522  push r9
000076bac53dd524  push r10
000076bac53dd526  push r11
000076bac53dd528  sub rsp, 0xF0
000076bac53dd52f  vmovaps [rsp], xmm0
000076bac53dd534  vmovaps [rsp+0x10], xmm1
000076bac53dd53a  vmovaps [rsp+0x20], xmm2
000076bac53dd540  vmovaps [rsp+0x30], xmm3
000076bac53dd546  vmovaps [rsp+0x40], xmm4
000076bac53dd54c  vmovaps [rsp+0x50], xmm5
000076bac53dd552  vmovaps [rsp+0x60], xmm6
000076bac53dd558  vmovaps [rsp+0x70], xmm7
000076bac53dd55e  vmovaps [rsp+0x80], xmm8
000076bac53dd567  vmovaps [rsp+0x90], xmm9
000076bac53dd570  vmovaps [rsp+0xA0], xmm10
000076bac53dd579  vmovaps [rsp+0xB0], xmm11
000076bac53dd582  vmovaps [rsp+0xC0], xmm13
000076bac53dd58b  vmovaps [rsp+0xD0], xmm14
000076bac53dd594  vmovaps [rsp+0xE0], xmm15
000076bac53dd59d  sub rsp, 0x30
000076bac53dd5a1  movaps [rsp], xmm12
000076bac53dd5a6  movaps [rsp+0x10], xmm7
000076bac53dd5ab  movaps [rsp+0x20], xmm13
000076bac53dd5b1  lea rdi, [rsp]
000076bac53dd5b5  mov esi, 0x00
000076bac53dd5ba  mov rax, 0x5641B0A3C530
000076bac53dd5c4  call rax
000076bac53dd5c6  movaps xmm12, [rsp]
000076bac53dd5cb  add rsp, 0x30
000076bac53dd5cf  vmovaps xmm0, [rsp]
000076bac53dd5d4  vmovaps xmm1, [rsp+0x10]
000076bac53dd5da  vmovaps xmm2, [rsp+0x20]
000076bac53dd5e0  vmovaps xmm3, [rsp+0x30]
000076bac53dd5e6  vmovaps xmm4, [rsp+0x40]
000076bac53dd5ec  vmovaps xmm5, [rsp+0x50]
000076bac53dd5f2  vmovaps xmm6, [rsp+0x60]
000076bac53dd5f8  vmovaps xmm7, [rsp+0x70]
000076bac53dd5fe  vmovaps xmm8, [rsp+0x80]
000076bac53dd607  vmovaps xmm9, [rsp+0x90]
000076bac53dd610  vmovaps xmm10, [rsp+0xA0]
000076bac53dd619  vmovaps xmm11, [rsp+0xB0]
000076bac53dd622  vmovaps xmm13, [rsp+0xC0]
000076bac53dd62b  vmovaps xmm14, [rsp+0xD0]
000076bac53dd634  vmovaps xmm15, [rsp+0xE0]
000076bac53dd63d  add rsp, 0xF0
000076bac53dd644  pop r11
000076bac53dd646  pop r10
000076bac53dd648  pop r9
000076bac53dd64a  pop r8
000076bac53dd64c  pop rsi
000076bac53dd64d  pop rdi
000076bac53dd64e  pop rdx
000076bac53dd64f  pop rcx
000076bac53dd650  pop rax
000076bac53dd651  add rsp, 0x08
000076bac53dd655  jmp 0x000076BAC53D9621
000076bac53dd65a  sub rsp, 0x08
000076bac53dd65e  push rax
000076bac53dd65f  push rcx
000076bac53dd660  push rdx
000076bac53dd661  push rdi
000076bac53dd662  push rsi
000076bac53dd663  push r8
000076bac53dd665  push r9
000076bac53dd667  push r10
000076bac53dd669  push r11
000076bac53dd66b  sub rsp, 0xF0
000076bac53dd672  vmovaps [rsp], xmm0
000076bac53dd677  vmovaps [rsp+0x10], xmm1
000076bac53dd67d  vmovaps [rsp+0x20], xmm2
000076bac53dd683  vmovaps [rsp+0x30], xmm3
000076bac53dd689  vmovaps [rsp+0x40], xmm4
000076bac53dd68f  vmovaps [rsp+0x50], xmm5
000076bac53dd695  vmovaps [rsp+0x60], xmm6
000076bac53dd69b  vmovaps [rsp+0x70], xmm7
000076bac53dd6a1  vmovaps [rsp+0x80], xmm8
000076bac53dd6aa  vmovaps [rsp+0x90], xmm9
000076bac53dd6b3  vmovaps [rsp+0xA0], xmm10
000076bac53dd6bc  vmovaps [rsp+0xB0], xmm11
000076bac53dd6c5  vmovaps [rsp+0xC0], xmm12
000076bac53dd6ce  vmovaps [rsp+0xD0], xmm14
000076bac53dd6d7  vmovaps [rsp+0xE0], xmm15
000076bac53dd6e0  sub rsp, 0x30
000076bac53dd6e4  movaps [rsp], xmm13
000076bac53dd6e9  movaps [rsp+0x10], xmm15
000076bac53dd6ef  movaps [rsp+0x20], xmm8
000076bac53dd6f5  lea rdi, [rsp]
000076bac53dd6f9  mov esi, 0x00
000076bac53dd6fe  mov rax, 0x5641B0A3C530
000076bac53dd708  call rax
000076bac53dd70a  movaps xmm13, [rsp]
000076bac53dd70f  add rsp, 0x30
000076bac53dd713  vmovaps xmm0, [rsp]
000076bac53dd718  vmovaps xmm1, [rsp+0x10]
000076bac53dd71e  vmovaps xmm2, [rsp+0x20]
000076bac53dd724  vmovaps xmm3, [rsp+0x30]
000076bac53dd72a  vmovaps xmm4, [rsp+0x40]
000076bac53dd730  vmovaps xmm5, [rsp+0x50]
000076bac53dd736  vmovaps xmm6, [rsp+0x60]
000076bac53dd73c  vmovaps xmm7, [rsp+0x70]
000076bac53dd742  vmovaps xmm8, [rsp+0x80]
000076bac53dd74b  vmovaps xmm9, [rsp+0x90]
000076bac53dd754  vmovaps xmm10, [rsp+0xA0]
000076bac53dd75d  vmovaps xmm11, [rsp+0xB0]
000076bac53dd766  vmovaps xmm12, [rsp+0xC0]
000076bac53dd76f  vmovaps xmm14, [rsp+0xD0]
000076bac53dd778  vmovaps xmm15, [rsp+0xE0]
000076bac53dd781  add rsp, 0xF0
000076bac53dd788  pop r11
000076bac53dd78a  pop r10
000076bac53dd78c  pop r9
000076bac53dd78e  pop r8
000076bac53dd790  pop rsi
000076bac53dd791  pop rdi
000076bac53dd792  pop rdx
000076bac53dd793  pop rcx
000076bac53dd794  pop rax
000076bac53dd795  add rsp, 0x08
000076bac53dd799  jmp 0x000076BAC53D963C
000076bac53dd79e  sub rsp, 0x08
000076bac53dd7a2  push rax
000076bac53dd7a3  push rcx
000076bac53dd7a4  push rdx
000076bac53dd7a5  push rdi
000076bac53dd7a6  push rsi
000076bac53dd7a7  push r8
000076bac53dd7a9  push r9
000076bac53dd7ab  push r10
000076bac53dd7ad  push r11
000076bac53dd7af  sub rsp, 0xF0
000076bac53dd7b6  vmovaps [rsp], xmm0
000076bac53dd7bb  vmovaps [rsp+0x10], xmm1
000076bac53dd7c1  vmovaps [rsp+0x20], xmm2
000076bac53dd7c7  vmovaps [rsp+0x30], xmm3
000076bac53dd7cd  vmovaps [rsp+0x40], xmm4
000076bac53dd7d3  vmovaps [rsp+0x50], xmm5
000076bac53dd7d9  vmovaps [rsp+0x60], xmm6
000076bac53dd7df  vmovaps [rsp+0x70], xmm7
000076bac53dd7e5  vmovaps [rsp+0x80], xmm9
000076bac53dd7ee  vmovaps [rsp+0x90], xmm10
000076bac53dd7f7  vmovaps [rsp+0xA0], xmm11
000076bac53dd800  vmovaps [rsp+0xB0], xmm12
000076bac53dd809  vmovaps [rsp+0xC0], xmm13
000076bac53dd812  vmovaps [rsp+0xD0], xmm14
000076bac53dd81b  vmovaps [rsp+0xE0], xmm15
000076bac53dd824  sub rsp, 0x30
000076bac53dd828  movaps [rsp], xmm8
000076bac53dd82d  movaps [rsp+0x10], xmm15
000076bac53dd833  movaps [rsp+0x20], xmm9
000076bac53dd839  lea rdi, [rsp]
000076bac53dd83d  mov esi, 0x00
000076bac53dd842  mov rax, 0x5641B0A3C530
000076bac53dd84c  call rax
000076bac53dd84e  movaps xmm8, [rsp]
000076bac53dd853  add rsp, 0x30
000076bac53dd857  vmovaps xmm0, [rsp]
000076bac53dd85c  vmovaps xmm1, [rsp+0x10]
000076bac53dd862  vmovaps xmm2, [rsp+0x20]
000076bac53dd868  vmovaps xmm3, [rsp+0x30]
000076bac53dd86e  vmovaps xmm4, [rsp+0x40]
000076bac53dd874  vmovaps xmm5, [rsp+0x50]
000076bac53dd87a  vmovaps xmm6, [rsp+0x60]
000076bac53dd880  vmovaps xmm7, [rsp+0x70]
000076bac53dd886  vmovaps xmm9, [rsp+0x80]
000076bac53dd88f  vmovaps xmm10, [rsp+0x90]
000076bac53dd898  vmovaps xmm11, [rsp+0xA0]
000076bac53dd8a1  vmovaps xmm12, [rsp+0xB0]
000076bac53dd8aa  vmovaps xmm13, [rsp+0xC0]
000076bac53dd8b3  vmovaps xmm14, [rsp+0xD0]
000076bac53dd8bc  vmovaps xmm15, [rsp+0xE0]
000076bac53dd8c5  add rsp, 0xF0
000076bac53dd8cc  pop r11
000076bac53dd8ce  pop r10
000076bac53dd8d0  pop r9
000076bac53dd8d2  pop r8
000076bac53dd8d4  pop rsi
000076bac53dd8d5  pop rdi
000076bac53dd8d6  pop rdx
000076bac53dd8d7  pop rcx
000076bac53dd8d8  pop rax
000076bac53dd8d9  add rsp, 0x08
000076bac53dd8dd  jmp 0x000076BAC53D966A
000076bac53dd8e2  sub rsp, 0x08
000076bac53dd8e6  push rax
000076bac53dd8e7  push rcx
000076bac53dd8e8  push rdx
000076bac53dd8e9  push rdi
000076bac53dd8ea  push rsi
000076bac53dd8eb  push r8
000076bac53dd8ed  push r9
000076bac53dd8ef  push r10
000076bac53dd8f1  push r11
000076bac53dd8f3  sub rsp, 0xF0
000076bac53dd8fa  vmovaps [rsp], xmm0
000076bac53dd8ff  vmovaps [rsp+0x10], xmm1
000076bac53dd905  vmovaps [rsp+0x20], xmm2
000076bac53dd90b  vmovaps [rsp+0x30], xmm3
000076bac53dd911  vmovaps [rsp+0x40], xmm4
000076bac53dd917  vmovaps [rsp+0x50], xmm5
000076bac53dd91d  vmovaps [rsp+0x60], xmm6
000076bac53dd923  vmovaps [rsp+0x70], xmm7
000076bac53dd929  vmovaps [rsp+0x80], xmm8
000076bac53dd932  vmovaps [rsp+0x90], xmm9
000076bac53dd93b  vmovaps [rsp+0xA0], xmm10
000076bac53dd944  vmovaps [rsp+0xB0], xmm11
000076bac53dd94d  vmovaps [rsp+0xC0], xmm12
000076bac53dd956  vmovaps [rsp+0xD0], xmm13
000076bac53dd95f  vmovaps [rsp+0xE0], xmm14
000076bac53dd968  sub rsp, 0x30
000076bac53dd96c  movaps [rsp], xmm15
000076bac53dd971  movaps [rsp+0x10], xmm11
000076bac53dd977  movaps [rsp+0x20], xmm6
000076bac53dd97c  lea rdi, [rsp]
000076bac53dd980  mov esi, 0x00
000076bac53dd985  mov rax, 0x5641B0A3C530
000076bac53dd98f  call rax
000076bac53dd991  movaps xmm15, [rsp]
000076bac53dd996  add rsp, 0x30
000076bac53dd99a  vmovaps xmm0, [rsp]
000076bac53dd99f  vmovaps xmm1, [rsp+0x10]
000076bac53dd9a5  vmovaps xmm2, [rsp+0x20]
000076bac53dd9ab  vmovaps xmm3, [rsp+0x30]
000076bac53dd9b1  vmovaps xmm4, [rsp+0x40]
000076bac53dd9b7  vmovaps xmm5, [rsp+0x50]
000076bac53dd9bd  vmovaps xmm6, [rsp+0x60]
000076bac53dd9c3  vmovaps xmm7, [rsp+0x70]
000076bac53dd9c9  vmovaps xmm8, [rsp+0x80]
000076bac53dd9d2  vmovaps xmm9, [rsp+0x90]
000076bac53dd9db  vmovaps xmm10, [rsp+0xA0]
000076bac53dd9e4  vmovaps xmm11, [rsp+0xB0]
000076bac53dd9ed  vmovaps xmm12, [rsp+0xC0]
000076bac53dd9f6  vmovaps xmm13, [rsp+0xD0]
000076bac53dd9ff  vmovaps xmm14, [rsp+0xE0]
000076bac53dda08  add rsp, 0xF0
000076bac53dda0f  pop r11
000076bac53dda11  pop r10
000076bac53dda13  pop r9
000076bac53dda15  pop r8
000076bac53dda17  pop rsi
000076bac53dda18  pop rdi
000076bac53dda19  pop rdx
000076bac53dda1a  pop rcx
000076bac53dda1b  pop rax
000076bac53dda1c  add rsp, 0x08
000076bac53dda20  jmp 0x000076BAC53D9685
000076bac53dda25  sub rsp, 0x08
000076bac53dda29  push rax
000076bac53dda2a  push rcx
000076bac53dda2b  push rdx
000076bac53dda2c  push rdi
000076bac53dda2d  push rsi
000076bac53dda2e  push r8
000076bac53dda30  push r9
000076bac53dda32  push r10
000076bac53dda34  push r11
000076bac53dda36  sub rsp, 0xF0
000076bac53dda3d  vmovaps [rsp], xmm0
000076bac53dda42  vmovaps [rsp+0x10], xmm1
000076bac53dda48  vmovaps [rsp+0x20], xmm2
000076bac53dda4e  vmovaps [rsp+0x30], xmm3
000076bac53dda54  vmovaps [rsp+0x40], xmm4
000076bac53dda5a  vmovaps [rsp+0x50], xmm5
000076bac53dda60  vmovaps [rsp+0x60], xmm6
000076bac53dda66  vmovaps [rsp+0x70], xmm8
000076bac53dda6c  vmovaps [rsp+0x80], xmm9
000076bac53dda75  vmovaps [rsp+0x90], xmm10
000076bac53dda7e  vmovaps [rsp+0xA0], xmm11
000076bac53dda87  vmovaps [rsp+0xB0], xmm12
000076bac53dda90  vmovaps [rsp+0xC0], xmm13
000076bac53dda99  vmovaps [rsp+0xD0], xmm14
000076bac53ddaa2  vmovaps [rsp+0xE0], xmm15
000076bac53ddaab  sub rsp, 0x30
000076bac53ddaaf  movaps [rsp], xmm7
000076bac53ddab3  movaps [rsp+0x10], xmm11
000076bac53ddab9  movaps [rsp+0x20], xmm9
000076bac53ddabf  lea rdi, [rsp]
000076bac53ddac3  mov esi, 0x00
000076bac53ddac8  mov rax, 0x5641B0A3C530
000076bac53ddad2  call rax
000076bac53ddad4  movaps xmm7, [rsp]
000076bac53ddad8  add rsp, 0x30
000076bac53ddadc  vmovaps xmm0, [rsp]
000076bac53ddae1  vmovaps xmm1, [rsp+0x10]
000076bac53ddae7  vmovaps xmm2, [rsp+0x20]
000076bac53ddaed  vmovaps xmm3, [rsp+0x30]
000076bac53ddaf3  vmovaps xmm4, [rsp+0x40]
000076bac53ddaf9  vmovaps xmm5, [rsp+0x50]
000076bac53ddaff  vmovaps xmm6, [rsp+0x60]
000076bac53ddb05  vmovaps xmm8, [rsp+0x70]
000076bac53ddb0b  vmovaps xmm9, [rsp+0x80]
000076bac53ddb14  vmovaps xmm10, [rsp+0x90]
000076bac53ddb1d  vmovaps xmm11, [rsp+0xA0]
000076bac53ddb26  vmovaps xmm12, [rsp+0xB0]
000076bac53ddb2f  vmovaps xmm13, [rsp+0xC0]
000076bac53ddb38  vmovaps xmm14, [rsp+0xD0]
000076bac53ddb41  vmovaps xmm15, [rsp+0xE0]
000076bac53ddb4a  add rsp, 0xF0
000076bac53ddb51  pop r11
000076bac53ddb53  pop r10
000076bac53ddb55  pop r9
000076bac53ddb57  pop r8
000076bac53ddb59  pop rsi
000076bac53ddb5a  pop rdi
000076bac53ddb5b  pop rdx
000076bac53ddb5c  pop rcx
000076bac53ddb5d  pop rax
000076bac53ddb5e  add rsp, 0x08
000076bac53ddb62  jmp 0x000076BAC53D96B2
000076bac53ddb67  sub rsp, 0x08
000076bac53ddb6b  push rax
000076bac53ddb6c  push rcx
000076bac53ddb6d  push rdx
000076bac53ddb6e  push rdi
000076bac53ddb6f  push rsi
000076bac53ddb70  push r8
000076bac53ddb72  push r9
000076bac53ddb74  push r10
000076bac53ddb76  push r11
000076bac53ddb78  sub rsp, 0xF0
000076bac53ddb7f  vmovaps [rsp], xmm0
000076bac53ddb84  vmovaps [rsp+0x10], xmm1
000076bac53ddb8a  vmovaps [rsp+0x20], xmm2
000076bac53ddb90  vmovaps [rsp+0x30], xmm3
000076bac53ddb96  vmovaps [rsp+0x40], xmm4
000076bac53ddb9c  vmovaps [rsp+0x50], xmm5
000076bac53ddba2  vmovaps [rsp+0x60], xmm6
000076bac53ddba8  vmovaps [rsp+0x70], xmm7
000076bac53ddbae  vmovaps [rsp+0x80], xmm8
000076bac53ddbb7  vmovaps [rsp+0x90], xmm9
000076bac53ddbc0  vmovaps [rsp+0xA0], xmm10
000076bac53ddbc9  vmovaps [rsp+0xB0], xmm12
000076bac53ddbd2  vmovaps [rsp+0xC0], xmm13
000076bac53ddbdb  vmovaps [rsp+0xD0], xmm14
000076bac53ddbe4  vmovaps [rsp+0xE0], xmm15
000076bac53ddbed  sub rsp, 0x30
000076bac53ddbf1  movaps [rsp], xmm11
000076bac53ddbf6  movaps [rsp+0x10], xmm10
000076bac53ddbfc  movaps [rsp+0x20], xmm14
000076bac53ddc02  lea rdi, [rsp]
000076bac53ddc06  mov esi, 0x00
000076bac53ddc0b  mov rax, 0x5641B0A3C530
000076bac53ddc15  call rax
000076bac53ddc17  movaps xmm11, [rsp]
000076bac53ddc1c  add rsp, 0x30
000076bac53ddc20  vmovaps xmm0, [rsp]
000076bac53ddc25  vmovaps xmm1, [rsp+0x10]
000076bac53ddc2b  vmovaps xmm2, [rsp+0x20]
000076bac53ddc31  vmovaps xmm3, [rsp+0x30]
000076bac53ddc37  vmovaps xmm4, [rsp+0x40]
000076bac53ddc3d  vmovaps xmm5, [rsp+0x50]
000076bac53ddc43  vmovaps xmm6, [rsp+0x60]
000076bac53ddc49  vmovaps xmm7, [rsp+0x70]
000076bac53ddc4f  vmovaps xmm8, [rsp+0x80]
000076bac53ddc58  vmovaps xmm9, [rsp+0x90]
000076bac53ddc61  vmovaps xmm10, [rsp+0xA0]
000076bac53ddc6a  vmovaps xmm12, [rsp+0xB0]
000076bac53ddc73  vmovaps xmm13, [rsp+0xC0]
000076bac53ddc7c  vmovaps xmm14, [rsp+0xD0]
000076bac53ddc85  vmovaps xmm15, [rsp+0xE0]
000076bac53ddc8e  add rsp, 0xF0
000076bac53ddc95  pop r11
000076bac53ddc97  pop r10
000076bac53ddc99  pop r9
000076bac53ddc9b  pop r8
000076bac53ddc9d  pop rsi
000076bac53ddc9e  pop rdi
000076bac53ddc9f  pop rdx
000076bac53ddca0  pop rcx
000076bac53ddca1  pop rax
000076bac53ddca2  add rsp, 0x08
000076bac53ddca6  jmp 0x000076BAC53D96CD
000076bac53ddcab  call 0x000076BAC52E45A0
000076bac53ddcb0  jmp 0x000076BAC53D96D7
000076bac53ddcb5  sub rsp, 0x08
000076bac53ddcb9  push rax
000076bac53ddcba  push rcx
000076bac53ddcbb  push rdx
000076bac53ddcbc  push rdi
000076bac53ddcbd  push rsi
000076bac53ddcbe  push r8
000076bac53ddcc0  push r9
000076bac53ddcc2  push r10
000076bac53ddcc4  push r11
000076bac53ddcc6  sub rsp, 0xF0
000076bac53ddccd  vmovaps [rsp], xmm0
000076bac53ddcd2  vmovaps [rsp+0x10], xmm1
000076bac53ddcd8  vmovaps [rsp+0x20], xmm2
000076bac53ddcde  vmovaps [rsp+0x30], xmm3
000076bac53ddce4  vmovaps [rsp+0x40], xmm4
000076bac53ddcea  vmovaps [rsp+0x50], xmm5
000076bac53ddcf0  vmovaps [rsp+0x60], xmm6
000076bac53ddcf6  vmovaps [rsp+0x70], xmm7
000076bac53ddcfc  vmovaps [rsp+0x80], xmm8
000076bac53ddd05  vmovaps [rsp+0x90], xmm9
000076bac53ddd0e  vmovaps [rsp+0xA0], xmm11
000076bac53ddd17  vmovaps [rsp+0xB0], xmm12
000076bac53ddd20  vmovaps [rsp+0xC0], xmm13
000076bac53ddd29  vmovaps [rsp+0xD0], xmm14
000076bac53ddd32  vmovaps [rsp+0xE0], xmm15
000076bac53ddd3b  sub rsp, 0x30
000076bac53ddd3f  movaps [rsp], xmm10
000076bac53ddd44  movaps [rsp+0x10], xmm1
000076bac53ddd49  movaps [rsp+0x20], xmm12
000076bac53ddd4f  lea rdi, [rsp]
000076bac53ddd53  mov esi, 0x00
000076bac53ddd58  mov rax, 0x5641B0A3C530
000076bac53ddd62  call rax
000076bac53ddd64  movaps xmm10, [rsp]
000076bac53ddd69  add rsp, 0x30
000076bac53ddd6d  vmovaps xmm0, [rsp]
000076bac53ddd72  vmovaps xmm1, [rsp+0x10]
000076bac53ddd78  vmovaps xmm2, [rsp+0x20]
000076bac53ddd7e  vmovaps xmm3, [rsp+0x30]
000076bac53ddd84  vmovaps xmm4, [rsp+0x40]
000076bac53ddd8a  vmovaps xmm5, [rsp+0x50]
000076bac53ddd90  vmovaps xmm6, [rsp+0x60]
000076bac53ddd96  vmovaps xmm7, [rsp+0x70]
000076bac53ddd9c  vmovaps xmm8, [rsp+0x80]
000076bac53ddda5  vmovaps xmm9, [rsp+0x90]
000076bac53dddae  vmovaps xmm11, [rsp+0xA0]
000076bac53dddb7  vmovaps xmm12, [rsp+0xB0]
000076bac53dddc0  vmovaps xmm13, [rsp+0xC0]
000076bac53dddc9  vmovaps xmm14, [rsp+0xD0]
000076bac53dddd2  vmovaps xmm15, [rsp+0xE0]
000076bac53ddddb  add rsp, 0xF0
000076bac53ddde2  pop r11
000076bac53ddde4  pop r10
000076bac53ddde6  pop r9
000076bac53ddde8  pop r8
000076bac53dddea  pop rsi
000076bac53dddeb  pop rdi
000076bac53dddec  pop rdx
000076bac53ddded  pop rcx
000076bac53dddee  pop rax
000076bac53dddef  add rsp, 0x08
000076bac53dddf3  jmp 0x000076BAC53D96FA
000076bac53dddf8  sub rsp, 0x08
000076bac53dddfc  push rax
000076bac53dddfd  push rcx
000076bac53dddfe  push rdx
000076bac53dddff  push rdi
000076bac53dde00  push rsi
000076bac53dde01  push r8
000076bac53dde03  push r9
000076bac53dde05  push r10
000076bac53dde07  push r11
000076bac53dde09  sub rsp, 0xF0
000076bac53dde10  vmovaps [rsp], xmm0
000076bac53dde15  vmovaps [rsp+0x10], xmm1
000076bac53dde1b  vmovaps [rsp+0x20], xmm2
000076bac53dde21  vmovaps [rsp+0x30], xmm3
000076bac53dde27  vmovaps [rsp+0x40], xmm4
000076bac53dde2d  vmovaps [rsp+0x50], xmm5
000076bac53dde33  vmovaps [rsp+0x60], xmm6
000076bac53dde39  vmovaps [rsp+0x70], xmm7
000076bac53dde3f  vmovaps [rsp+0x80], xmm8
000076bac53dde48  vmovaps [rsp+0x90], xmm9
000076bac53dde51  vmovaps [rsp+0xA0], xmm10
000076bac53dde5a  vmovaps [rsp+0xB0], xmm11
000076bac53dde63  vmovaps [rsp+0xC0], xmm13
000076bac53dde6c  vmovaps [rsp+0xD0], xmm14
000076bac53dde75  vmovaps [rsp+0xE0], xmm15
000076bac53dde7e  sub rsp, 0x30
000076bac53dde82  movaps [rsp], xmm12
000076bac53dde87  movaps [rsp+0x10], xmm14
000076bac53dde8d  movaps [rsp+0x20], xmm1
000076bac53dde92  lea rdi, [rsp]
000076bac53dde96  mov esi, 0x00
000076bac53dde9b  mov rax, 0x5641B0A3C530
000076bac53ddea5  call rax
000076bac53ddea7  movaps xmm12, [rsp]
000076bac53ddeac  add rsp, 0x30
000076bac53ddeb0  vmovaps xmm0, [rsp]
000076bac53ddeb5  vmovaps xmm1, [rsp+0x10]
000076bac53ddebb  vmovaps xmm2, [rsp+0x20]
000076bac53ddec1  vmovaps xmm3, [rsp+0x30]
000076bac53ddec7  vmovaps xmm4, [rsp+0x40]
000076bac53ddecd  vmovaps xmm5, [rsp+0x50]
000076bac53dded3  vmovaps xmm6, [rsp+0x60]
000076bac53dded9  vmovaps xmm7, [rsp+0x70]
000076bac53ddedf  vmovaps xmm8, [rsp+0x80]
000076bac53ddee8  vmovaps xmm9, [rsp+0x90]
000076bac53ddef1  vmovaps xmm10, [rsp+0xA0]
000076bac53ddefa  vmovaps xmm11, [rsp+0xB0]
000076bac53ddf03  vmovaps xmm13, [rsp+0xC0]
000076bac53ddf0c  vmovaps xmm14, [rsp+0xD0]
000076bac53ddf15  vmovaps xmm15, [rsp+0xE0]
000076bac53ddf1e  add rsp, 0xF0
000076bac53ddf25  pop r11
000076bac53ddf27  pop r10
000076bac53ddf29  pop r9
000076bac53ddf2b  pop r8
000076bac53ddf2d  pop rsi
000076bac53ddf2e  pop rdi
000076bac53ddf2f  pop rdx
000076bac53ddf30  pop rcx
000076bac53ddf31  pop rax
000076bac53ddf32  add rsp, 0x08
000076bac53ddf36  jmp 0x000076BAC53D9729
000076bac53ddf3b  sub rsp, 0x08
000076bac53ddf3f  push rax
000076bac53ddf40  push rcx
000076bac53ddf41  push rdx
000076bac53ddf42  push rdi
000076bac53ddf43  push rsi
000076bac53ddf44  push r8
000076bac53ddf46  push r9
000076bac53ddf48  push r10
000076bac53ddf4a  push r11
000076bac53ddf4c  sub rsp, 0xF0
000076bac53ddf53  vmovaps [rsp], xmm0
000076bac53ddf58  vmovaps [rsp+0x10], xmm1
000076bac53ddf5e  vmovaps [rsp+0x20], xmm2
000076bac53ddf64  vmovaps [rsp+0x30], xmm3
000076bac53ddf6a  vmovaps [rsp+0x40], xmm4
000076bac53ddf70  vmovaps [rsp+0x50], xmm5
000076bac53ddf76  vmovaps [rsp+0x60], xmm6
000076bac53ddf7c  vmovaps [rsp+0x70], xmm7
000076bac53ddf82  vmovaps [rsp+0x80], xmm8
000076bac53ddf8b  vmovaps [rsp+0x90], xmm9
000076bac53ddf94  vmovaps [rsp+0xA0], xmm10
000076bac53ddf9d  vmovaps [rsp+0xB0], xmm11
000076bac53ddfa6  vmovaps [rsp+0xC0], xmm12
000076bac53ddfaf  vmovaps [rsp+0xD0], xmm13
000076bac53ddfb8  vmovaps [rsp+0xE0], xmm15
000076bac53ddfc1  sub rsp, 0x30
000076bac53ddfc5  movaps [rsp], xmm14
000076bac53ddfca  movaps [rsp+0x10], xmm9
000076bac53ddfd0  movaps [rsp+0x20], xmm1
000076bac53ddfd5  lea rdi, [rsp]
000076bac53ddfd9  mov esi, 0x00
000076bac53ddfde  mov rax, 0x5641B0A3C530
000076bac53ddfe8  call rax
000076bac53ddfea  movaps xmm14, [rsp]
000076bac53ddfef  add rsp, 0x30
000076bac53ddff3  vmovaps xmm0, [rsp]
000076bac53ddff8  vmovaps xmm1, [rsp+0x10]
000076bac53ddffe  vmovaps xmm2, [rsp+0x20]
000076bac53de004  vmovaps xmm3, [rsp+0x30]
000076bac53de00a  vmovaps xmm4, [rsp+0x40]
000076bac53de010  vmovaps xmm5, [rsp+0x50]
000076bac53de016  vmovaps xmm6, [rsp+0x60]
000076bac53de01c  vmovaps xmm7, [rsp+0x70]
000076bac53de022  vmovaps xmm8, [rsp+0x80]
000076bac53de02b  vmovaps xmm9, [rsp+0x90]
000076bac53de034  vmovaps xmm10, [rsp+0xA0]
000076bac53de03d  vmovaps xmm11, [rsp+0xB0]
000076bac53de046  vmovaps xmm12, [rsp+0xC0]
000076bac53de04f  vmovaps xmm13, [rsp+0xD0]
000076bac53de058  vmovaps xmm15, [rsp+0xE0]
000076bac53de061  add rsp, 0xF0
000076bac53de068  pop r11
000076bac53de06a  pop r10
000076bac53de06c  pop r9
000076bac53de06e  pop r8
000076bac53de070  pop rsi
000076bac53de071  pop rdi
000076bac53de072  pop rdx
000076bac53de073  pop rcx
000076bac53de074  pop rax
000076bac53de075  add rsp, 0x08
000076bac53de079  jmp 0x000076BAC53D9758
000076bac53de07e  sub rsp, 0x08
000076bac53de082  push rax
000076bac53de083  push rcx
000076bac53de084  push rdx
000076bac53de085  push rdi
000076bac53de086  push rsi
000076bac53de087  push r8
000076bac53de089  push r9
000076bac53de08b  push r10
000076bac53de08d  push r11
000076bac53de08f  sub rsp, 0xF0
000076bac53de096  vmovaps [rsp], xmm0
000076bac53de09b  vmovaps [rsp+0x10], xmm2
000076bac53de0a1  vmovaps [rsp+0x20], xmm3
000076bac53de0a7  vmovaps [rsp+0x30], xmm4
000076bac53de0ad  vmovaps [rsp+0x40], xmm5
000076bac53de0b3  vmovaps [rsp+0x50], xmm6
000076bac53de0b9  vmovaps [rsp+0x60], xmm7
000076bac53de0bf  vmovaps [rsp+0x70], xmm8
000076bac53de0c5  vmovaps [rsp+0x80], xmm9
000076bac53de0ce  vmovaps [rsp+0x90], xmm10
000076bac53de0d7  vmovaps [rsp+0xA0], xmm11
000076bac53de0e0  vmovaps [rsp+0xB0], xmm12
000076bac53de0e9  vmovaps [rsp+0xC0], xmm13
000076bac53de0f2  vmovaps [rsp+0xD0], xmm14
000076bac53de0fb  vmovaps [rsp+0xE0], xmm15
000076bac53de104  sub rsp, 0x30
000076bac53de108  movaps [rsp], xmm1
000076bac53de10c  movaps [rsp+0x10], xmm13
000076bac53de112  movaps [rsp+0x20], xmm8
000076bac53de118  lea rdi, [rsp]
000076bac53de11c  mov esi, 0x00
000076bac53de121  mov rax, 0x5641B0A3C530
000076bac53de12b  call rax
000076bac53de12d  movaps xmm1, [rsp]
000076bac53de131  add rsp, 0x30
000076bac53de135  vmovaps xmm0, [rsp]
000076bac53de13a  vmovaps xmm2, [rsp+0x10]
000076bac53de140  vmovaps xmm3, [rsp+0x20]
000076bac53de146  vmovaps xmm4, [rsp+0x30]
000076bac53de14c  vmovaps xmm5, [rsp+0x40]
000076bac53de152  vmovaps xmm6, [rsp+0x50]
000076bac53de158  vmovaps xmm7, [rsp+0x60]
000076bac53de15e  vmovaps xmm8, [rsp+0x70]
000076bac53de164  vmovaps xmm9, [rsp+0x80]
000076bac53de16d  vmovaps xmm10, [rsp+0x90]
000076bac53de176  vmovaps xmm11, [rsp+0xA0]
000076bac53de17f  vmovaps xmm12, [rsp+0xB0]
000076bac53de188  vmovaps xmm13, [rsp+0xC0]
000076bac53de191  vmovaps xmm14, [rsp+0xD0]
000076bac53de19a  vmovaps xmm15, [rsp+0xE0]
000076bac53de1a3  add rsp, 0xF0
000076bac53de1aa  pop r11
000076bac53de1ac  pop r10
000076bac53de1ae  pop r9
000076bac53de1b0  pop r8
000076bac53de1b2  pop rsi
000076bac53de1b3  pop rdi
000076bac53de1b4  pop rdx
000076bac53de1b5  pop rcx
000076bac53de1b6  pop rax
000076bac53de1b7  add rsp, 0x08
000076bac53de1bb  jmp 0x000076BAC53D977A
000076bac53de1c0  call 0x000076BAC520C260
000076bac53de1c5  jmp 0x000076BAC53D9788
000076bac53de1ca  call 0x000076BAC52DE950
000076bac53de1cf  jmp 0x000076BAC53D9792
000076bac53de1d4  sub rsp, 0x08
000076bac53de1d8  push rax
000076bac53de1d9  push rcx
000076bac53de1da  push rdx
000076bac53de1db  push rdi
000076bac53de1dc  push rsi
000076bac53de1dd  push r8
000076bac53de1df  push r9
000076bac53de1e1  push r10
000076bac53de1e3  push r11
000076bac53de1e5  sub rsp, 0xF0
000076bac53de1ec  vmovaps [rsp], xmm0
000076bac53de1f1  vmovaps [rsp+0x10], xmm1
000076bac53de1f7  vmovaps [rsp+0x20], xmm2
000076bac53de1fd  vmovaps [rsp+0x30], xmm3
000076bac53de203  vmovaps [rsp+0x40], xmm4
000076bac53de209  vmovaps [rsp+0x50], xmm5
000076bac53de20f  vmovaps [rsp+0x60], xmm6
000076bac53de215  vmovaps [rsp+0x70], xmm7
000076bac53de21b  vmovaps [rsp+0x80], xmm9
000076bac53de224  vmovaps [rsp+0x90], xmm10
000076bac53de22d  vmovaps [rsp+0xA0], xmm11
000076bac53de236  vmovaps [rsp+0xB0], xmm12
000076bac53de23f  vmovaps [rsp+0xC0], xmm13
000076bac53de248  vmovaps [rsp+0xD0], xmm14
000076bac53de251  vmovaps [rsp+0xE0], xmm15
000076bac53de25a  sub rsp, 0x30
000076bac53de25e  movaps [rsp], xmm8
000076bac53de263  movaps [rsp+0x10], xmm15
000076bac53de269  movaps [rsp+0x20], xmm7
000076bac53de26e  lea rdi, [rsp]
000076bac53de272  mov esi, 0x00
000076bac53de277  mov rax, 0x5641B0A3C530
000076bac53de281  call rax
000076bac53de283  movaps xmm8, [rsp]
000076bac53de288  add rsp, 0x30
000076bac53de28c  vmovaps xmm0, [rsp]
000076bac53de291  vmovaps xmm1, [rsp+0x10]
000076bac53de297  vmovaps xmm2, [rsp+0x20]
000076bac53de29d  vmovaps xmm3, [rsp+0x30]
000076bac53de2a3  vmovaps xmm4, [rsp+0x40]
000076bac53de2a9  vmovaps xmm5, [rsp+0x50]
000076bac53de2af  vmovaps xmm6, [rsp+0x60]
000076bac53de2b5  vmovaps xmm7, [rsp+0x70]
000076bac53de2bb  vmovaps xmm9, [rsp+0x80]
000076bac53de2c4  vmovaps xmm10, [rsp+0x90]
000076bac53de2cd  vmovaps xmm11, [rsp+0xA0]
000076bac53de2d6  vmovaps xmm12, [rsp+0xB0]
000076bac53de2df  vmovaps xmm13, [rsp+0xC0]
000076bac53de2e8  vmovaps xmm14, [rsp+0xD0]
000076bac53de2f1  vmovaps xmm15, [rsp+0xE0]
000076bac53de2fa  add rsp, 0xF0
000076bac53de301  pop r11
000076bac53de303  pop r10
000076bac53de305  pop r9
000076bac53de307  pop r8
000076bac53de309  pop rsi
000076bac53de30a  pop rdi
000076bac53de30b  pop rdx
000076bac53de30c  pop rcx
000076bac53de30d  pop rax
000076bac53de30e  add rsp, 0x08
000076bac53de312  jmp 0x000076BAC53D97B4
000076bac53de317  sub rsp, 0x08
000076bac53de31b  push rax
000076bac53de31c  push rcx
000076bac53de31d  push rdx
000076bac53de31e  push rdi
000076bac53de31f  push rsi
000076bac53de320  push r8
000076bac53de322  push r9
000076bac53de324  push r10
000076bac53de326  push r11
000076bac53de328  sub rsp, 0xF0
000076bac53de32f  vmovaps [rsp], xmm0
000076bac53de334  vmovaps [rsp+0x10], xmm1
000076bac53de33a  vmovaps [rsp+0x20], xmm2
000076bac53de340  vmovaps [rsp+0x30], xmm3
000076bac53de346  vmovaps [rsp+0x40], xmm4
000076bac53de34c  vmovaps [rsp+0x50], xmm5
000076bac53de352  vmovaps [rsp+0x60], xmm6
000076bac53de358  vmovaps [rsp+0x70], xmm8
000076bac53de35e  vmovaps [rsp+0x80], xmm9
000076bac53de367  vmovaps [rsp+0x90], xmm10
000076bac53de370  vmovaps [rsp+0xA0], xmm11
000076bac53de379  vmovaps [rsp+0xB0], xmm12
000076bac53de382  vmovaps [rsp+0xC0], xmm13
000076bac53de38b  vmovaps [rsp+0xD0], xmm14
000076bac53de394  vmovaps [rsp+0xE0], xmm15
000076bac53de39d  sub rsp, 0x30
000076bac53de3a1  movaps [rsp], xmm7
000076bac53de3a5  movaps [rsp+0x10], xmm9
000076bac53de3ab  movaps [rsp+0x20], xmm15
000076bac53de3b1  lea rdi, [rsp]
000076bac53de3b5  mov esi, 0x00
000076bac53de3ba  mov rax, 0x5641B0A3C530
000076bac53de3c4  call rax
000076bac53de3c6  movaps xmm7, [rsp]
000076bac53de3ca  add rsp, 0x30
000076bac53de3ce  vmovaps xmm0, [rsp]
000076bac53de3d3  vmovaps xmm1, [rsp+0x10]
000076bac53de3d9  vmovaps xmm2, [rsp+0x20]
000076bac53de3df  vmovaps xmm3, [rsp+0x30]
000076bac53de3e5  vmovaps xmm4, [rsp+0x40]
000076bac53de3eb  vmovaps xmm5, [rsp+0x50]
000076bac53de3f1  vmovaps xmm6, [rsp+0x60]
000076bac53de3f7  vmovaps xmm8, [rsp+0x70]
000076bac53de3fd  vmovaps xmm9, [rsp+0x80]
000076bac53de406  vmovaps xmm10, [rsp+0x90]
000076bac53de40f  vmovaps xmm11, [rsp+0xA0]
000076bac53de418  vmovaps xmm12, [rsp+0xB0]
000076bac53de421  vmovaps xmm13, [rsp+0xC0]
000076bac53de42a  vmovaps xmm14, [rsp+0xD0]
000076bac53de433  vmovaps xmm15, [rsp+0xE0]
000076bac53de43c  add rsp, 0xF0
000076bac53de443  pop r11
000076bac53de445  pop r10
000076bac53de447  pop r9
000076bac53de449  pop r8
000076bac53de44b  pop rsi
000076bac53de44c  pop rdi
000076bac53de44d  pop rdx
000076bac53de44e  pop rcx
000076bac53de44f  pop rax
000076bac53de450  add rsp, 0x08
000076bac53de454  jmp 0x000076BAC53D97E1
000076bac53de459  sub rsp, 0x08
000076bac53de45d  push rax
000076bac53de45e  push rcx
000076bac53de45f  push rdx
000076bac53de460  push rdi
000076bac53de461  push rsi
000076bac53de462  push r8
000076bac53de464  push r9
000076bac53de466  push r10
000076bac53de468  push r11
000076bac53de46a  sub rsp, 0xF0
000076bac53de471  vmovaps [rsp], xmm0
000076bac53de476  vmovaps [rsp+0x10], xmm1
000076bac53de47c  vmovaps [rsp+0x20], xmm2
000076bac53de482  vmovaps [rsp+0x30], xmm3
000076bac53de488  vmovaps [rsp+0x40], xmm4
000076bac53de48e  vmovaps [rsp+0x50], xmm5
000076bac53de494  vmovaps [rsp+0x60], xmm6
000076bac53de49a  vmovaps [rsp+0x70], xmm7
000076bac53de4a0  vmovaps [rsp+0x80], xmm8
000076bac53de4a9  vmovaps [rsp+0x90], xmm10
000076bac53de4b2  vmovaps [rsp+0xA0], xmm11
000076bac53de4bb  vmovaps [rsp+0xB0], xmm12
000076bac53de4c4  vmovaps [rsp+0xC0], xmm13
000076bac53de4cd  vmovaps [rsp+0xD0], xmm14
000076bac53de4d6  vmovaps [rsp+0xE0], xmm15
000076bac53de4df  sub rsp, 0x30
000076bac53de4e3  movaps [rsp], xmm9
000076bac53de4e8  movaps [rsp+0x10], xmm13
000076bac53de4ee  movaps [rsp+0x20], xmm15
000076bac53de4f4  lea rdi, [rsp]
000076bac53de4f8  mov esi, 0x00
000076bac53de4fd  mov rax, 0x5641B0A3C530
000076bac53de507  call rax
000076bac53de509  movaps xmm9, [rsp]
000076bac53de50e  add rsp, 0x30
000076bac53de512  vmovaps xmm0, [rsp]
000076bac53de517  vmovaps xmm1, [rsp+0x10]
000076bac53de51d  vmovaps xmm2, [rsp+0x20]
000076bac53de523  vmovaps xmm3, [rsp+0x30]
000076bac53de529  vmovaps xmm4, [rsp+0x40]
000076bac53de52f  vmovaps xmm5, [rsp+0x50]
000076bac53de535  vmovaps xmm6, [rsp+0x60]
000076bac53de53b  vmovaps xmm7, [rsp+0x70]
000076bac53de541  vmovaps xmm8, [rsp+0x80]
000076bac53de54a  vmovaps xmm10, [rsp+0x90]
000076bac53de553  vmovaps xmm11, [rsp+0xA0]
000076bac53de55c  vmovaps xmm12, [rsp+0xB0]
000076bac53de565  vmovaps xmm13, [rsp+0xC0]
000076bac53de56e  vmovaps xmm14, [rsp+0xD0]
000076bac53de577  vmovaps xmm15, [rsp+0xE0]
000076bac53de580  add rsp, 0xF0
000076bac53de587  pop r11
000076bac53de589  pop r10
000076bac53de58b  pop r9
000076bac53de58d  pop r8
000076bac53de58f  pop rsi
000076bac53de590  pop rdi
000076bac53de591  pop rdx
000076bac53de592  pop rcx
000076bac53de593  pop rax
000076bac53de594  add rsp, 0x08
000076bac53de598  jmp 0x000076BAC53D980F
000076bac53de59d  sub rsp, 0x08
000076bac53de5a1  push rax
000076bac53de5a2  push rcx
000076bac53de5a3  push rdx
000076bac53de5a4  push rdi
000076bac53de5a5  push rsi
000076bac53de5a6  push r8
000076bac53de5a8  push r9
000076bac53de5aa  push r10
000076bac53de5ac  push r11
000076bac53de5ae  sub rsp, 0xF0
000076bac53de5b5  vmovaps [rsp], xmm0
000076bac53de5ba  vmovaps [rsp+0x10], xmm1
000076bac53de5c0  vmovaps [rsp+0x20], xmm2
000076bac53de5c6  vmovaps [rsp+0x30], xmm3
000076bac53de5cc  vmovaps [rsp+0x40], xmm4
000076bac53de5d2  vmovaps [rsp+0x50], xmm5
000076bac53de5d8  vmovaps [rsp+0x60], xmm6
000076bac53de5de  vmovaps [rsp+0x70], xmm7
000076bac53de5e4  vmovaps [rsp+0x80], xmm8
000076bac53de5ed  vmovaps [rsp+0x90], xmm9
000076bac53de5f6  vmovaps [rsp+0xA0], xmm10
000076bac53de5ff  vmovaps [rsp+0xB0], xmm11
000076bac53de608  vmovaps [rsp+0xC0], xmm12
000076bac53de611  vmovaps [rsp+0xD0], xmm13
000076bac53de61a  vmovaps [rsp+0xE0], xmm14
000076bac53de623  sub rsp, 0x30
000076bac53de627  movaps [rsp], xmm15
000076bac53de62c  movaps [rsp+0x10], xmm11
000076bac53de632  movaps [rsp+0x20], xmm12
000076bac53de638  lea rdi, [rsp]
000076bac53de63c  mov esi, 0x00
000076bac53de641  mov rax, 0x5641B0A3C530
000076bac53de64b  call rax
000076bac53de64d  movaps xmm15, [rsp]
000076bac53de652  add rsp, 0x30
000076bac53de656  vmovaps xmm0, [rsp]
000076bac53de65b  vmovaps xmm1, [rsp+0x10]
000076bac53de661  vmovaps xmm2, [rsp+0x20]
000076bac53de667  vmovaps xmm3, [rsp+0x30]
000076bac53de66d  vmovaps xmm4, [rsp+0x40]
000076bac53de673  vmovaps xmm5, [rsp+0x50]
000076bac53de679  vmovaps xmm6, [rsp+0x60]
000076bac53de67f  vmovaps xmm7, [rsp+0x70]
000076bac53de685  vmovaps xmm8, [rsp+0x80]
000076bac53de68e  vmovaps xmm9, [rsp+0x90]
000076bac53de697  vmovaps xmm10, [rsp+0xA0]
000076bac53de6a0  vmovaps xmm11, [rsp+0xB0]
000076bac53de6a9  vmovaps xmm12, [rsp+0xC0]
000076bac53de6b2  vmovaps xmm13, [rsp+0xD0]
000076bac53de6bb  vmovaps xmm14, [rsp+0xE0]
000076bac53de6c4  add rsp, 0xF0
000076bac53de6cb  pop r11
000076bac53de6cd  pop r10
000076bac53de6cf  pop r9
000076bac53de6d1  pop r8
000076bac53de6d3  pop rsi
000076bac53de6d4  pop rdi
000076bac53de6d5  pop rdx
000076bac53de6d6  pop rcx
000076bac53de6d7  pop rax
000076bac53de6d8  add rsp, 0x08
000076bac53de6dc  jmp 0x000076BAC53D982A
000076bac53de6e1  sub rsp, 0x08
000076bac53de6e5  push rax
000076bac53de6e6  push rcx
000076bac53de6e7  push rdx
000076bac53de6e8  push rdi
000076bac53de6e9  push rsi
000076bac53de6ea  push r8
000076bac53de6ec  push r9
000076bac53de6ee  push r10
000076bac53de6f0  push r11
000076bac53de6f2  sub rsp, 0xF0
000076bac53de6f9  vmovaps [rsp], xmm0
000076bac53de6fe  vmovaps [rsp+0x10], xmm1
000076bac53de704  vmovaps [rsp+0x20], xmm2
000076bac53de70a  vmovaps [rsp+0x30], xmm3
000076bac53de710  vmovaps [rsp+0x40], xmm4
000076bac53de716  vmovaps [rsp+0x50], xmm5
000076bac53de71c  vmovaps [rsp+0x60], xmm6
000076bac53de722  vmovaps [rsp+0x70], xmm7
000076bac53de728  vmovaps [rsp+0x80], xmm8
000076bac53de731  vmovaps [rsp+0x90], xmm9
000076bac53de73a  vmovaps [rsp+0xA0], xmm10
000076bac53de743  vmovaps [rsp+0xB0], xmm11
000076bac53de74c  vmovaps [rsp+0xC0], xmm12
000076bac53de755  vmovaps [rsp+0xD0], xmm14
000076bac53de75e  vmovaps [rsp+0xE0], xmm15
000076bac53de767  sub rsp, 0x30
000076bac53de76b  movaps [rsp], xmm13
000076bac53de770  movaps [rsp+0x10], xmm10
000076bac53de776  movaps [rsp+0x20], xmm14
000076bac53de77c  lea rdi, [rsp]
000076bac53de780  mov esi, 0x00
000076bac53de785  mov rax, 0x5641B0A3C530
000076bac53de78f  call rax
000076bac53de791  movaps xmm13, [rsp]
000076bac53de796  add rsp, 0x30
000076bac53de79a  vmovaps xmm0, [rsp]
000076bac53de79f  vmovaps xmm1, [rsp+0x10]
000076bac53de7a5  vmovaps xmm2, [rsp+0x20]
000076bac53de7ab  vmovaps xmm3, [rsp+0x30]
000076bac53de7b1  vmovaps xmm4, [rsp+0x40]
000076bac53de7b7  vmovaps xmm5, [rsp+0x50]
000076bac53de7bd  vmovaps xmm6, [rsp+0x60]
000076bac53de7c3  vmovaps xmm7, [rsp+0x70]
000076bac53de7c9  vmovaps xmm8, [rsp+0x80]
000076bac53de7d2  vmovaps xmm9, [rsp+0x90]
000076bac53de7db  vmovaps xmm10, [rsp+0xA0]
000076bac53de7e4  vmovaps xmm11, [rsp+0xB0]
000076bac53de7ed  vmovaps xmm12, [rsp+0xC0]
000076bac53de7f6  vmovaps xmm14, [rsp+0xD0]
000076bac53de7ff  vmovaps xmm15, [rsp+0xE0]
000076bac53de808  add rsp, 0xF0
000076bac53de80f  pop r11
000076bac53de811  pop r10
000076bac53de813  pop r9
000076bac53de815  pop r8
000076bac53de817  pop rsi
000076bac53de818  pop rdi
000076bac53de819  pop rdx
000076bac53de81a  pop rcx
000076bac53de81b  pop rax
000076bac53de81c  add rsp, 0x08
000076bac53de820  jmp 0x000076BAC53D984D
000076bac53de825  sub rsp, 0x08
000076bac53de829  push rax
000076bac53de82a  push rcx
000076bac53de82b  push rdx
000076bac53de82c  push rdi
000076bac53de82d  push rsi
000076bac53de82e  push r8
000076bac53de830  push r9
000076bac53de832  push r10
000076bac53de834  push r11
000076bac53de836  sub rsp, 0xF0
000076bac53de83d  vmovaps [rsp], xmm0
000076bac53de842  vmovaps [rsp+0x10], xmm1
000076bac53de848  vmovaps [rsp+0x20], xmm2
000076bac53de84e  vmovaps [rsp+0x30], xmm3
000076bac53de854  vmovaps [rsp+0x40], xmm4
000076bac53de85a  vmovaps [rsp+0x50], xmm5
000076bac53de860  vmovaps [rsp+0x60], xmm6
000076bac53de866  vmovaps [rsp+0x70], xmm7
000076bac53de86c  vmovaps [rsp+0x80], xmm8
000076bac53de875  vmovaps [rsp+0x90], xmm9
000076bac53de87e  vmovaps [rsp+0xA0], xmm10
000076bac53de887  vmovaps [rsp+0xB0], xmm11
000076bac53de890  vmovaps [rsp+0xC0], xmm12
000076bac53de899  vmovaps [rsp+0xD0], xmm13
000076bac53de8a2  vmovaps [rsp+0xE0], xmm15
000076bac53de8ab  sub rsp, 0x30
000076bac53de8af  movaps [rsp], xmm14
000076bac53de8b4  movaps [rsp+0x10], xmm1
000076bac53de8b9  movaps [rsp+0x20], xmm7
000076bac53de8be  lea rdi, [rsp]
000076bac53de8c2  mov esi, 0x00
000076bac53de8c7  mov rax, 0x5641B0A3C530
000076bac53de8d1  call rax
000076bac53de8d3  movaps xmm14, [rsp]
000076bac53de8d8  add rsp, 0x30
000076bac53de8dc  vmovaps xmm0, [rsp]
000076bac53de8e1  vmovaps xmm1, [rsp+0x10]
000076bac53de8e7  vmovaps xmm2, [rsp+0x20]
000076bac53de8ed  vmovaps xmm3, [rsp+0x30]
000076bac53de8f3  vmovaps xmm4, [rsp+0x40]
000076bac53de8f9  vmovaps xmm5, [rsp+0x50]
000076bac53de8ff  vmovaps xmm6, [rsp+0x60]
000076bac53de905  vmovaps xmm7, [rsp+0x70]
000076bac53de90b  vmovaps xmm8, [rsp+0x80]
000076bac53de914  vmovaps xmm9, [rsp+0x90]
000076bac53de91d  vmovaps xmm10, [rsp+0xA0]
000076bac53de926  vmovaps xmm11, [rsp+0xB0]
000076bac53de92f  vmovaps xmm12, [rsp+0xC0]
000076bac53de938  vmovaps xmm13, [rsp+0xD0]
000076bac53de941  vmovaps xmm15, [rsp+0xE0]
000076bac53de94a  add rsp, 0xF0
000076bac53de951  pop r11
000076bac53de953  pop r10
000076bac53de955  pop r9
000076bac53de957  pop r8
000076bac53de959  pop rsi
000076bac53de95a  pop rdi
000076bac53de95b  pop rdx
000076bac53de95c  pop rcx
000076bac53de95d  pop rax
000076bac53de95e  add rsp, 0x08
000076bac53de962  jmp 0x000076BAC53D9870
000076bac53de967  sub rsp, 0x08
000076bac53de96b  push rax
000076bac53de96c  push rcx
000076bac53de96d  push rdx
000076bac53de96e  push rdi
000076bac53de96f  push rsi
000076bac53de970  push r8
000076bac53de972  push r9
000076bac53de974  push r10
000076bac53de976  push r11
000076bac53de978  sub rsp, 0xF0
000076bac53de97f  vmovaps [rsp], xmm0
000076bac53de984  vmovaps [rsp+0x10], xmm2
000076bac53de98a  vmovaps [rsp+0x20], xmm3
000076bac53de990  vmovaps [rsp+0x30], xmm4
000076bac53de996  vmovaps [rsp+0x40], xmm5
000076bac53de99c  vmovaps [rsp+0x50], xmm6
000076bac53de9a2  vmovaps [rsp+0x60], xmm7
000076bac53de9a8  vmovaps [rsp+0x70], xmm8
000076bac53de9ae  vmovaps [rsp+0x80], xmm9
000076bac53de9b7  vmovaps [rsp+0x90], xmm10
000076bac53de9c0  vmovaps [rsp+0xA0], xmm11
000076bac53de9c9  vmovaps [rsp+0xB0], xmm12
000076bac53de9d2  vmovaps [rsp+0xC0], xmm13
000076bac53de9db  vmovaps [rsp+0xD0], xmm14
000076bac53de9e4  vmovaps [rsp+0xE0], xmm15
000076bac53de9ed  sub rsp, 0x30
000076bac53de9f1  movaps [rsp], xmm1
000076bac53de9f5  movaps [rsp+0x10], xmm8
000076bac53de9fb  movaps [rsp+0x20], xmm9
000076bac53dea01  lea rdi, [rsp]
000076bac53dea05  mov esi, 0x00
000076bac53dea0a  mov rax, 0x5641B0A3C530
000076bac53dea14  call rax
000076bac53dea16  movaps xmm1, [rsp]
000076bac53dea1a  add rsp, 0x30
000076bac53dea1e  vmovaps xmm0, [rsp]
000076bac53dea23  vmovaps xmm2, [rsp+0x10]
000076bac53dea29  vmovaps xmm3, [rsp+0x20]
000076bac53dea2f  vmovaps xmm4, [rsp+0x30]
000076bac53dea35  vmovaps xmm5, [rsp+0x40]
000076bac53dea3b  vmovaps xmm6, [rsp+0x50]
000076bac53dea41  vmovaps xmm7, [rsp+0x60]
000076bac53dea47  vmovaps xmm8, [rsp+0x70]
000076bac53dea4d  vmovaps xmm9, [rsp+0x80]
000076bac53dea56  vmovaps xmm10, [rsp+0x90]
000076bac53dea5f  vmovaps xmm11, [rsp+0xA0]
000076bac53dea68  vmovaps xmm12, [rsp+0xB0]
000076bac53dea71  vmovaps xmm13, [rsp+0xC0]
000076bac53dea7a  vmovaps xmm14, [rsp+0xD0]
000076bac53dea83  vmovaps xmm15, [rsp+0xE0]
000076bac53dea8c  add rsp, 0xF0
000076bac53dea93  pop r11
000076bac53dea95  pop r10
000076bac53dea97  pop r9
000076bac53dea99  pop r8
000076bac53dea9b  pop rsi
000076bac53dea9c  pop rdi
000076bac53dea9d  pop rdx
000076bac53dea9e  pop rcx
000076bac53dea9f  pop rax
000076bac53deaa0  add rsp, 0x08
000076bac53deaa4  jmp 0x000076BAC53D9892
000076bac53deaa9  call 0x000076BAC52B3E40
000076bac53deaae  jmp 0x000076BAC53D98A0
000076bac53deab3  call 0x000076BAC520C380
000076bac53deab8  jmp 0x000076BAC53D98AA
000076bac53deabd  call 0x000076BAC520D600
000076bac53deac2  jmp 0x000076BAC53D98B4
000076bac53deac7  call 0x000076BAC51FF540
000076bac53deacc  jmp 0x000076BAC53D98BE
000076bac53dead1  int3
000076bac53dead2  nop [rax+rax*1], ax
000076bac53deadb  nop [rax+rax*1], eax
000076bac53deae0  mov eax, [r15+0x48]
000076bac53deae4  lea r14d, [eax+0x01]
000076bac53deae9  mov [rsp+0x10], r14d
000076bac53deaee  mov r14d, r14d
000076bac53deaf1  mov [r15+0x48], r14
000076bac53deaf5  xor eax, eax
000076bac53deaf7  mov r14d, [rsp+0x10]
000076bac53deafc  cmp r14d, 0x1F4
000076bac53deb03  cmc
000076bac53deb04  lahf
000076bac53deb05  seto al
000076bac53deb08  mov [r15+0x108], eax
000076bac53deb0f  mov eax, [r15+0x108]
000076bac53deb16  sahf
000076bac53deb17  jnz 0x000076BAC53DEB49
000076bac53deb19  cmp dword ptr [r15+0x318], 0x00
000076bac53deb21  jz 0x000076BAC53E4C90
000076bac53deb27  nop [rax+rax*1], ax
000076bac53deb30  nop [rax+rax*1], eax
000076bac53deb38  mov eax, 0x4106DC
000076bac53deb3d  mov [r15+0x100], rax
000076bac53deb44  jmp 0x000076BAC51FE110
000076bac53deb49  cmp dword ptr [r15+0x318], 0x00
000076bac53deb51  jz 0x000076BAC53DEB80
000076bac53deb57  nop [rax+rax*1], ax
000076bac53deb60  nop [rax+rax*1], eax
000076bac53deb68  mov eax, 0x410500
000076bac53deb6d  mov [r15+0x100], rax
000076bac53deb74  jmp 0x000076BAC51FE110
000076bac53deb79  int3
000076bac53deb7a  int3
000076bac53deb7b  nop [rax+rax*1], eax
000076bac53deb80  mov rax, [r15+0x40]
000076bac53deb84  movaps xmm1, [r15+0x1D0]
000076bac53deb8c  vmovaps [rsp+0x10], xmm1
000076bac53deb92  vmovaps xmm15, [rsp+0x10]
000076bac53deb98  por xmm1, xmm15
000076bac53deb9d  movaps xmm14, [r15+0x1A0]
000076bac53deba5  vmovaps [rsp+0x10], xmm14
000076bac53debab  vmovaps xmm13, [rsp+0x10]
000076bac53debb1  por xmm14, xmm13
000076bac53debb6  lea r14, [rax+0x30]
000076bac53debba  mov r12, [r13+r14*1]
000076bac53debbf  lea r14, [rax+0x38]
000076bac53debc3  mov r11, [r13+r14*1]
000076bac53debc8  movq xmm13, r12
000076bac53debcd  movq xmm12, r11
000076bac53debd2  movq xmm13, xmm13
000076bac53debd7  vmovaps [rsp+0x10], xmm13
000076bac53debdd  movq xmm13, xmm13
000076bac53debe2  movaps [r15+0x130], xmm13
000076bac53debea  movq xmm12, xmm12
000076bac53debef  vmovaps [rsp+0x20], xmm12
000076bac53debf5  movq xmm12, xmm12
000076bac53debfa  movaps [r15+0x280], xmm12
000076bac53dec02  movaps xmm13, [r15+0x270]
000076bac53dec0a  vmovaps [rsp+0x30], xmm13
000076bac53dec10  vmovaps xmm12, [rsp+0x30]
000076bac53dec16  por xmm13, xmm12
000076bac53dec1b  lea r14, [rax+0x20]
000076bac53dec1f  mov r12, [r13+r14*1]
000076bac53dec24  lea r14, [rax+0x28]
000076bac53dec28  mov r11, [r13+r14*1]
000076bac53dec2d  movq xmm12, r12
000076bac53dec32  movq xmm11, r11
000076bac53dec37  movq xmm12, xmm12
000076bac53dec3c  vmovaps [rsp+0x30], xmm12
000076bac53dec42  movq xmm12, xmm12
000076bac53dec47  movaps [r15+0x150], xmm12
000076bac53dec4f  movq xmm11, xmm11
000076bac53dec54  vmovaps [rsp+0x40], xmm11
000076bac53dec5a  movq xmm11, xmm11
000076bac53dec5f  movaps [r15+0x140], xmm11
000076bac53dec67  lea r14, [rax+0x10]
000076bac53dec6b  mov r12, [r13+r14*1]
000076bac53dec70  lea r14, [rax+0x18]
000076bac53dec74  mov r11, [r13+r14*1]
000076bac53dec79  movq xmm12, r12
000076bac53dec7e  movq xmm11, r11
000076bac53dec83  movq xmm12, xmm12
000076bac53dec88  vmovaps [rsp+0x50], xmm12
000076bac53dec8e  movq xmm12, xmm12
000076bac53dec93  movaps [r15+0x170], xmm12
000076bac53dec9b  movq xmm11, xmm11
000076bac53deca0  vmovaps [rsp+0x60], xmm11
000076bac53deca6  movq xmm11, xmm11
000076bac53decab  movaps [r15+0x160], xmm11
000076bac53decb3  mov r14, [r13+rax*1]
000076bac53decb8  vmovq xmm12, r14
000076bac53decbd  vpbroadcastq xmm12, xmm12
000076bac53decc2  lea r14, [rax+0x08]
000076bac53decc6  mov rax, [r13+r14*1]
000076bac53deccb  movq xmm11, rax
000076bac53decd0  movaps [r15+0x230], xmm11
000076bac53decd8  mov rax, [r15+0xF8]
000076bac53decdf  lea r14, [rax+0x50]
000076bac53dece3  movups xmm11, [r13+r14*1]
000076bac53dece9  lea r14, [rax+0x60]
000076bac53deced  movups xmm10, [r13+r14*1]
000076bac53decf3  lea r14, [rax+0x30]
000076bac53decf7  movups xmm9, [r13+r14*1]
000076bac53decfd  mov r14, [r15+0x50]
000076bac53ded01  mov [r15+0x60], r14
000076bac53ded05  mov qword ptr [r15+0x58], 0x40
000076bac53ded0d  movaps xmm8, xmm12
000076bac53ded11  mulpd xmm8, xmm15
000076bac53ded16  vcmppd xmm7, xmm8, xmm8, 0x03
000076bac53ded1c  ptest xmm7, xmm7
000076bac53ded21  jnz 0x000076BAC53DFB4A
000076bac53ded27  movq xmm15, qword ptr [r15+0x230]
000076bac53ded30  vmovaps [rsp+0x70], xmm15
000076bac53ded36  vpermilpd xmm15, xmm15, 0x00
000076bac53ded3c  movaps xmm7, xmm9
000076bac53ded40  mulpd xmm7, xmm15
000076bac53ded45  vcmppd xmm6, xmm7, xmm7, 0x03
000076bac53ded4a  ptest xmm6, xmm6
000076bac53ded4f  jnz 0x000076BAC53DFC8E
000076bac53ded55  vxorps xmm15, xmm15, xmm15
000076bac53ded5a  vpbroadcastq xmm15, xmm15
000076bac53ded5f  movaps xmm9, xmm12
000076bac53ded63  mulpd xmm9, xmm10
000076bac53ded68  vcmppd xmm6, xmm9, xmm9, 0x03
000076bac53ded6e  ptest xmm6, xmm6
000076bac53ded73  jnz 0x000076BAC53DFDD0
000076bac53ded79  movaps xmm10, xmm12
000076bac53ded7d  mulpd xmm10, xmm11
000076bac53ded82  vcmppd xmm6, xmm10, xmm10, 0x03
000076bac53ded88  ptest xmm6, xmm6
000076bac53ded8d  jnz 0x000076BAC53DFF14
000076bac53ded93  movaps xmm11, [r15+0x1F0]
000076bac53ded9b  movaps xmm6, xmm12
000076bac53ded9f  mulpd xmm6, xmm11
000076bac53deda4  vcmppd xmm5, xmm6, xmm6, 0x03
000076bac53deda9  ptest xmm5, xmm5
000076bac53dedae  jnz 0x000076BAC53E0058
000076bac53dedb4  movaps xmm12, [r15+0x2A0]
000076bac53dedbc  vmovaps [rsp+0x80], xmm12
000076bac53dedc5  vmovaps xmm11, [rsp+0x80]
000076bac53dedce  por xmm12, xmm11
000076bac53dedd3  movaps xmm11, [r15+0x250]
000076bac53deddb  vmovaps [rsp+0x80], xmm11
000076bac53dede4  vmovaps xmm5, [rsp+0x80]
000076bac53deded  por xmm11, xmm5
000076bac53dedf2  vmovaps xmm4, [rsp+0x70]
000076bac53dedf8  vpermilpd xmm4, xmm4, 0x00
000076bac53dedfe  movaps xmm3, xmm5
000076bac53dee01  mulpd xmm3, xmm4
000076bac53dee05  vcmppd xmm2, xmm3, xmm3, 0x03
000076bac53dee0a  ptest xmm2, xmm2
000076bac53dee0f  jnz 0x000076BAC53E019A
000076bac53dee15  mov [rsp+0x80], rax
000076bac53dee1d  xor eax, eax
000076bac53dee1f  mov r12d, 0x40
000076bac53dee25  mov r11d, 0x200
000076bac53dee2b  cmp r12, r11
000076bac53dee2e  cmc
000076bac53dee2f  lahf
000076bac53dee30  seto al
000076bac53dee33  mov [r15+0x108], eax
000076bac53dee3a  movaps xmm5, xmm8
000076bac53dee3e  addpd xmm5, xmm15
000076bac53dee43  vcmppd xmm4, xmm5, xmm5, 0x03
000076bac53dee48  ptest xmm4, xmm4
000076bac53dee4d  jnz 0x000076BAC53E02DA
000076bac53dee53  movaps xmm8, [r15+0x1B0]
000076bac53dee5b  movaps xmm4, xmm9
000076bac53dee5f  addpd xmm4, xmm8
000076bac53dee64  vcmppd xmm2, xmm4, xmm4, 0x03
000076bac53dee69  ptest xmm2, xmm2
000076bac53dee6e  jnz 0x000076BAC53E041C
000076bac53dee74  movaps xmm9, xmm10
000076bac53dee78  addpd xmm9, xmm8
000076bac53dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
000076bac53dee83  ptest xmm2, xmm2
000076bac53dee88  jnz 0x000076BAC53E055E
000076bac53dee8e  movaps xmm10, [r15+0x2F0]
000076bac53dee96  vmovaps [rsp+0x90], xmm10
000076bac53dee9f  vmovaps xmm8, [rsp+0x90]
000076bac53deea8  por xmm10, xmm8
000076bac53deead  movaps xmm8, [r15+0x2E0]
000076bac53deeb5  vmovaps [rsp+0x90], xmm8
000076bac53deebe  vmovaps xmm2, [rsp+0x90]
000076bac53deec7  por xmm8, xmm2
000076bac53deecc  movaps xmm2, [r15+0x2D0]
000076bac53deed4  vmovaps [rsp+0x90], xmm2
000076bac53deedd  vmovaps [rsp+0xA0], xmm1
000076bac53deee6  vmovaps xmm1, [rsp+0x90]
000076bac53deeef  por xmm2, xmm1
000076bac53deef3  movaps xmm1, [r15+0x200]
000076bac53deefb  vmovaps [rsp+0x90], xmm1
000076bac53def04  vmovaps [rsp+0xB0], xmm15
000076bac53def0d  vmovaps xmm15, [rsp+0x90]
000076bac53def16  por xmm1, xmm15
000076bac53def1b  movaps xmm15, [r15+0x1C0]
000076bac53def23  vmovaps [rsp+0x90], xmm15
000076bac53def2c  vmovaps [rsp+0xC0], xmm1
000076bac53def35  vmovaps xmm1, [rsp+0x90]
000076bac53def3e  por xmm15, xmm1
000076bac53def43  movaps xmm1, [r15+0x190]
000076bac53def4b  vmovaps [rsp+0x90], xmm1
000076bac53def54  vmovaps [rsp+0xD0], xmm15
000076bac53def5d  vmovaps xmm15, [rsp+0x90]
000076bac53def66  por xmm1, xmm15
000076bac53def6b  movaps xmm15, [r15+0x300]
000076bac53def73  vmovaps [rsp+0x90], xmm15
000076bac53def7c  vmovaps [rsp+0xE0], xmm1
000076bac53def85  vmovaps xmm1, [rsp+0x90]
000076bac53def8e  por xmm15, xmm1
000076bac53def93  mov rax, [rsp+0x80]
000076bac53def9b  lea r12, [rax+0xA0]
000076bac53defa2  movups xmm1, [r13+r12*1]
000076bac53defa8  lea r12, [rax+0xB0]
000076bac53defaf  vmovaps [rsp+0x80], xmm1
000076bac53defb8  movups xmm1, [r13+r12*1]
000076bac53defbe  vmovaps [rsp+0x90], xmm1
000076bac53defc7  vmovaps [rsp+0xF0], xmm15
000076bac53defd0  vmovaps xmm15, [rsp+0xB0]
000076bac53defd9  vmovaps [rsp+0xB0], xmm14
000076bac53defe2  movaps xmm1, xmm6
000076bac53defe5  addpd xmm1, xmm15
000076bac53defea  vcmppd xmm14, xmm1, xmm1, 0x03
000076bac53defef  ptest xmm14, xmm14
000076bac53deff5  jnz 0x000076BAC53E06B6
000076bac53deffb  lea r12, [rax+0xF0]
000076bac53df002  movups xmm15, [r13+r12*1]
000076bac53df008  movaps xmm14, xmm4
000076bac53df00c  addpd xmm14, xmm3
000076bac53df011  vcmppd xmm6, xmm14, xmm14, 0x03
000076bac53df017  ptest xmm6, xmm6
000076bac53df01c  jnz 0x000076BAC53E0801
000076bac53df022  movaps xmm6, xmm9
000076bac53df026  addpd xmm6, xmm7
000076bac53df02a  vcmppd xmm4, xmm6, xmm6, 0x03
000076bac53df02f  ptest xmm4, xmm4
000076bac53df034  jnz 0x000076BAC53E0943
000076bac53df03a  vmovaps xmm9, [rsp+0x70]
000076bac53df040  vpermilpd xmm9, xmm9, 0x00
000076bac53df046  vmovaps xmm4, [rsp+0x90]
000076bac53df04f  movaps xmm7, xmm4
000076bac53df052  mulpd xmm7, xmm9
000076bac53df057  vcmppd xmm3, xmm7, xmm7, 0x03
000076bac53df05c  ptest xmm3, xmm3
000076bac53df061  jnz 0x000076BAC53E0A84
000076bac53df067  vmovaps xmm9, [rsp+0x50]
000076bac53df06d  vpermilpd xmm9, xmm9, 0x00
000076bac53df073  movaps xmm4, xmm15
000076bac53df077  mulpd xmm4, xmm9
000076bac53df07c  vcmppd xmm3, xmm4, xmm4, 0x03
000076bac53df081  ptest xmm3, xmm3
000076bac53df086  jnz 0x000076BAC53E0BC5
000076bac53df08c  lea r12, [rax+0xE0]
000076bac53df093  movups xmm15, [r13+r12*1]
000076bac53df099  vmovaps xmm9, [rsp+0x70]
000076bac53df09f  vpermilpd xmm9, xmm9, 0x00
000076bac53df0a5  vmovaps [rsp+0x70], xmm1
000076bac53df0ab  vmovaps xmm1, [rsp+0x80]
000076bac53df0b4  vmovaps [rsp+0x80], xmm15
000076bac53df0bd  movaps xmm3, xmm1
000076bac53df0c0  mulpd xmm3, xmm9
000076bac53df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
000076bac53df0ca  ptest xmm15, xmm15
000076bac53df0d0  jnz 0x000076BAC53E0D11
000076bac53df0d6  vmovaps xmm1, [rsp+0xF0]
000076bac53df0df  vmovaps xmm15, [rsp+0xF0]
000076bac53df0e8  por xmm1, xmm15
000076bac53df0ed  movaps [r15+0x300], xmm1
000076bac53df0f5  vmovaps xmm15, [rsp+0xE0]
000076bac53df0fe  vmovaps xmm9, [rsp+0xE0]
000076bac53df107  por xmm15, xmm9
000076bac53df10c  movaps [r15+0x190], xmm15
000076bac53df114  vmovaps xmm9, [rsp+0x50]
000076bac53df11a  vpermilpd xmm9, xmm9, 0x00
000076bac53df120  vmovaps [rsp+0x90], xmm1
000076bac53df129  vmovaps [rsp+0xE0], xmm15
000076bac53df132  vmovaps xmm15, [rsp+0x80]
000076bac53df13b  vmovaps [rsp+0x80], xmm14
000076bac53df144  movaps xmm1, xmm15
000076bac53df148  mulpd xmm1, xmm9
000076bac53df14d  vcmppd xmm14, xmm1, xmm1, 0x03
000076bac53df152  ptest xmm14, xmm14
000076bac53df158  jnz 0x000076BAC53E0E52
000076bac53df15e  lea r12, [rax+0x90]
000076bac53df165  movups xmm15, [r13+r12*1]
000076bac53df16b  vmovaps xmm14, [rsp+0xD0]
000076bac53df174  vmovaps xmm9, [rsp+0xD0]
000076bac53df17d  por xmm14, xmm9
000076bac53df182  movaps [r15+0x1C0], xmm14
000076bac53df18a  vmovaps xmm9, [rsp+0xC0]
000076bac53df193  vmovaps [rsp+0xD0], xmm1
000076bac53df19c  vmovaps xmm1, [rsp+0xC0]
000076bac53df1a5  por xmm9, xmm1
000076bac53df1aa  movaps [r15+0x200], xmm9
000076bac53df1b2  vmovaps [rsp+0xC0], xmm2
000076bac53df1bb  vmovaps xmm1, [rsp+0xC0]
000076bac53df1c4  por xmm2, xmm1
000076bac53df1c8  movaps [r15+0x2D0], xmm2
000076bac53df1d0  vmovaps [rsp+0xC0], xmm8
000076bac53df1d9  vmovaps xmm1, [rsp+0xC0]
000076bac53df1e2  por xmm8, xmm1
000076bac53df1e7  movaps [r15+0x2E0], xmm8
000076bac53df1ef  vmovaps [rsp+0xC0], xmm15
000076bac53df1f8  movaps xmm1, xmm5
000076bac53df1fb  addpd xmm1, xmm7
000076bac53df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
000076bac53df204  ptest xmm15, xmm15
000076bac53df20a  jnz 0x000076BAC53E0F9E
000076bac53df210  vmovaps xmm15, [rsp+0x50]
000076bac53df216  vpermilpd xmm15, xmm15, 0x00
000076bac53df21c  vmovaps xmm5, [rsp+0xC0]
000076bac53df225  vmovaps [rsp+0xC0], xmm1
000076bac53df22e  movaps xmm7, xmm5
000076bac53df231  mulpd xmm7, xmm15
000076bac53df236  vcmppd xmm1, xmm7, xmm7, 0x03
000076bac53df23b  ptest xmm1, xmm1
000076bac53df240  jnz 0x000076BAC53E10DE
000076bac53df246  lea r12, [rax+0x80]
000076bac53df24d  movups xmm1, [r13+r12*1]
000076bac53df253  vmovaps xmm5, [rsp+0x70]
000076bac53df259  vmovaps [rsp+0x70], xmm1
000076bac53df25f  movaps xmm15, xmm5
000076bac53df263  addpd xmm15, xmm3
000076bac53df268  vcmppd xmm1, xmm15, xmm15, 0x03
000076bac53df26e  ptest xmm1, xmm1
000076bac53df273  jnz 0x000076BAC53E1229
000076bac53df279  vmovaps xmm5, [rsp+0x80]
000076bac53df282  movaps xmm1, xmm5
000076bac53df285  addpd xmm1, xmm4
000076bac53df289  vcmppd xmm3, xmm1, xmm1, 0x03
000076bac53df28e  ptest xmm3, xmm3
000076bac53df293  jnz 0x000076BAC53E136B
000076bac53df299  vmovaps [rsp+0x80], xmm10
000076bac53df2a2  vmovaps xmm5, [rsp+0x80]
000076bac53df2ab  por xmm10, xmm5
000076bac53df2b0  movaps [r15+0x2F0], xmm10
000076bac53df2b8  vmovaps xmm5, [rsp+0x50]
000076bac53df2be  vpermilpd xmm5, xmm5, 0x00
000076bac53df2c4  vmovaps xmm3, [rsp+0x70]
000076bac53df2ca  vmovaps [rsp+0x50], xmm1
000076bac53df2d0  movaps xmm4, xmm3
000076bac53df2d3  mulpd xmm4, xmm5
000076bac53df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
000076bac53df2dc  ptest xmm1, xmm1
000076bac53df2e1  jnz 0x000076BAC53E14AB
000076bac53df2e7  lea r12, [rax+0xD0]
000076bac53df2ee  movups xmm1, [r13+r12*1]
000076bac53df2f4  vmovaps xmm3, [rsp+0xD0]
000076bac53df2fd  vmovaps [rsp+0x70], xmm1
000076bac53df303  movaps xmm5, xmm6
000076bac53df306  addpd xmm5, xmm3
000076bac53df30a  vcmppd xmm1, xmm5, xmm5, 0x03
000076bac53df30f  ptest xmm1, xmm1
000076bac53df314  jnz 0x000076BAC53E15F5
000076bac53df31a  vmovaps xmm1, [rsp+0x60]
000076bac53df320  vpermilpd xmm1, xmm1, 0x00
000076bac53df326  movaps xmm6, xmm9
000076bac53df32a  mulpd xmm6, xmm1
000076bac53df32e  vcmppd xmm3, xmm6, xmm6, 0x03
000076bac53df333  ptest xmm3, xmm3
000076bac53df338  jnz 0x000076BAC53E1735
000076bac53df33e  movaps [r15+0x260], xmm6
000076bac53df346  vxorps xmm1, xmm1, xmm1
000076bac53df34a  vpbroadcastq xmm1, xmm1
000076bac53df34f  movaps [r15+0x1B0], xmm1
000076bac53df357  vmovaps xmm1, [rsp+0x60]
000076bac53df35d  vpermilpd xmm1, xmm1, 0x00
000076bac53df363  vmovaps xmm3, [rsp+0x70]
000076bac53df369  vmovaps [rsp+0x70], xmm15
000076bac53df36f  movaps xmm9, xmm3
000076bac53df373  mulpd xmm9, xmm1
000076bac53df378  vcmppd xmm15, xmm9, xmm9, 0x03
000076bac53df37e  ptest xmm15, xmm15
000076bac53df384  jnz 0x000076BAC53E1876
000076bac53df38a  lea r12, [rax+0xC0]
000076bac53df391  movups xmm1, [r13+r12*1]
000076bac53df397  vmovaps xmm3, [rsp+0xC0]
000076bac53df3a0  vmovaps [rsp+0x80], xmm1
000076bac53df3a9  movaps xmm15, xmm3
000076bac53df3ad  addpd xmm15, xmm7
000076bac53df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
000076bac53df3b8  ptest xmm1, xmm1
000076bac53df3bd  jnz 0x000076BAC53E19C2
000076bac53df3c3  vmovaps [rsp+0xC0], xmm13
000076bac53df3cc  vmovaps xmm1, [rsp+0xC0]
000076bac53df3d5  por xmm13, xmm1
000076bac53df3da  movaps [r15+0x270], xmm13
000076bac53df3e2  vmovaps xmm1, [rsp+0xB0]
000076bac53df3eb  vmovaps xmm7, [rsp+0xB0]
000076bac53df3f4  por xmm1, xmm7
000076bac53df3f8  movaps [r15+0x1A0], xmm1
000076bac53df400  vmovaps xmm1, [rsp+0x60]
000076bac53df406  vpermilpd xmm1, xmm1, 0x00
000076bac53df40c  vmovaps [rsp+0xB0], xmm1
000076bac53df415  vmovaps xmm1, [rsp+0x80]
000076bac53df41e  vmovaps [rsp+0x80], xmm15
000076bac53df427  vmovaps xmm15, [rsp+0xB0]
000076bac53df430  vmovaps [rsp+0xB0], xmm14
000076bac53df439  movaps xmm3, xmm1
000076bac53df43c  mulpd xmm3, xmm15
000076bac53df441  vcmppd xmm14, xmm3, xmm3, 0x03
000076bac53df446  ptest xmm14, xmm14
000076bac53df44c  jnz 0x000076BAC53E1B04
000076bac53df452  lea r12, [rax+0x20]
000076bac53df456  movups xmm1, [r13+r12*1]
000076bac53df45c  movaps [r15+0x110], xmm1
000076bac53df464  vmovaps xmm14, [rsp+0x70]
000076bac53df46a  vmovaps [rsp+0x70], xmm1
000076bac53df470  movaps xmm15, xmm14
000076bac53df474  addpd xmm15, xmm4
000076bac53df479  vcmppd xmm1, xmm15, xmm15, 0x03
000076bac53df47f  ptest xmm1, xmm1
000076bac53df484  jnz 0x000076BAC53E1C4F
000076bac53df48a  vmovaps xmm1, [rsp+0x60]
000076bac53df490  vpermilpd xmm1, xmm1, 0x00
000076bac53df496  movaps xmm14, xmm2
000076bac53df49a  mulpd xmm14, xmm1
000076bac53df49f  vcmppd xmm4, xmm14, xmm14, 0x03
000076bac53df4a5  ptest xmm4, xmm4
000076bac53df4aa  jnz 0x000076BAC53E1D92
000076bac53df4b0  vmovaps xmm4, [rsp+0x50]
000076bac53df4b6  movaps xmm1, xmm4
000076bac53df4b9  addpd xmm1, xmm9
000076bac53df4be  vcmppd xmm2, xmm1, xmm1, 0x03
000076bac53df4c3  ptest xmm2, xmm2
000076bac53df4c8  jnz 0x000076BAC53E1ED4
000076bac53df4ce  vmovaps xmm9, [rsp+0x30]
000076bac53df4d4  vpermilpd xmm9, xmm9, 0x00
000076bac53df4da  vmovaps xmm2, [rsp+0x70]
000076bac53df4e0  vmovaps [rsp+0x50], xmm1
000076bac53df4e6  movaps xmm4, xmm2
000076bac53df4e9  mulpd xmm4, xmm9
000076bac53df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
000076bac53df4f3  ptest xmm1, xmm1
000076bac53df4f8  jnz 0x000076BAC53E2015
000076bac53df4fe  vmovaps xmm1, [rsp+0x30]
000076bac53df504  vpermilpd xmm1, xmm1, 0x00
000076bac53df50a  vmovaps xmm2, [rsp+0x90]
000076bac53df513  vmovaps [rsp+0x60], xmm15
000076bac53df519  movaps xmm9, xmm2
000076bac53df51d  mulpd xmm9, xmm1
000076bac53df522  vcmppd xmm15, xmm9, xmm9, 0x03
000076bac53df528  ptest xmm15, xmm15
000076bac53df52e  jnz 0x000076BAC53E2156
000076bac53df534  vmovaps xmm15, [rsp+0x80]
000076bac53df53d  movaps xmm1, xmm15
000076bac53df541  addpd xmm1, xmm6
000076bac53df545  vcmppd xmm2, xmm1, xmm1, 0x03
000076bac53df54a  ptest xmm2, xmm2
000076bac53df54f  jnz 0x000076BAC53E2298
000076bac53df555  movaps xmm15, xmm5
000076bac53df559  addpd xmm15, xmm3
000076bac53df55e  vcmppd xmm6, xmm15, xmm15, 0x03
000076bac53df564  ptest xmm6, xmm6
000076bac53df569  jnz 0x000076BAC53E23D9
000076bac53df56f  vmovaps xmm6, [rsp+0x30]
000076bac53df575  vpermilpd xmm6, xmm6, 0x00
000076bac53df57b  movaps xmm5, xmm8
000076bac53df57f  mulpd xmm5, xmm6
000076bac53df583  vcmppd xmm3, xmm5, xmm5, 0x03
000076bac53df588  ptest xmm3, xmm3
000076bac53df58d  jnz 0x000076BAC53E251B
000076bac53df593  vmovaps xmm8, [rsp+0x30]
000076bac53df599  vpermilpd xmm8, xmm8, 0x00
000076bac53df59f  movaps xmm6, xmm10
000076bac53df5a3  mulpd xmm6, xmm8
000076bac53df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
000076bac53df5ad  ptest xmm3, xmm3
000076bac53df5b2  jnz 0x000076BAC53E265C
000076bac53df5b8  vmovaps xmm8, [rsp+0x60]
000076bac53df5be  movaps xmm10, xmm8
000076bac53df5c2  addpd xmm10, xmm14
000076bac53df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
000076bac53df5cd  ptest xmm3, xmm3
000076bac53df5d2  jnz 0x000076BAC53E279E
000076bac53df5d8  vmovaps xmm8, [rsp+0x50]
000076bac53df5de  movaps xmm14, xmm8
000076bac53df5e2  addpd xmm14, xmm4
000076bac53df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
000076bac53df5ed  ptest xmm3, xmm3
000076bac53df5f2  jnz 0x000076BAC53E28E2
000076bac53df5f8  vmovaps xmm8, [rsp+0x40]
000076bac53df5fe  vpermilpd xmm8, xmm8, 0x00
000076bac53df604  movaps xmm4, xmm13
000076bac53df608  mulpd xmm4, xmm8
000076bac53df60d  vcmppd xmm3, xmm4, xmm4, 0x03
000076bac53df612  ptest xmm3, xmm3
000076bac53df617  jnz 0x000076BAC53E2A25
000076bac53df61d  movaps xmm13, xmm15
000076bac53df621  addpd xmm13, xmm9
000076bac53df626  vcmppd xmm8, xmm13, xmm13, 0x03
000076bac53df62c  ptest xmm8, xmm8
000076bac53df632  jnz 0x000076BAC53E2B67
000076bac53df638  movaps xmm15, xmm1
000076bac53df63c  addpd xmm15, xmm5
000076bac53df641  vcmppd xmm9, xmm15, xmm15, 0x03
000076bac53df647  ptest xmm9, xmm9
000076bac53df64d  jnz 0x000076BAC53E2CAB
000076bac53df653  vmovaps [rsp+0x30], xmm11
000076bac53df659  vmovaps xmm1, [rsp+0x30]
000076bac53df65f  por xmm11, xmm1
000076bac53df664  movaps [r15+0x250], xmm11
000076bac53df66c  vmovaps [rsp+0x30], xmm12
000076bac53df672  vmovaps xmm1, [rsp+0x30]
000076bac53df678  por xmm12, xmm1
000076bac53df67d  movaps [r15+0x2A0], xmm12
000076bac53df685  vmovaps xmm1, [rsp+0xA0]
000076bac53df68e  vmovaps xmm11, [rsp+0xA0]
000076bac53df697  por xmm1, xmm11
000076bac53df69c  movaps [r15+0x1D0], xmm1
000076bac53df6a4  lea r12, [rax+0x40]
000076bac53df6a8  movups xmm1, [r13+r12*1]
000076bac53df6ae  movaps [r15+0x2C0], xmm1
000076bac53df6b6  vmovaps xmm11, [rsp+0x40]
000076bac53df6bc  vpermilpd xmm11, xmm11, 0x00
000076bac53df6c2  vmovaps xmm8, [rsp+0xE0]
000076bac53df6cb  movaps xmm9, xmm8
000076bac53df6cf  mulpd xmm9, xmm11
000076bac53df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
000076bac53df6da  ptest xmm5, xmm5
000076bac53df6df  jnz 0x000076BAC53E2DF7
000076bac53df6e5  movaps xmm11, xmm10
000076bac53df6e9  addpd xmm11, xmm6
000076bac53df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
000076bac53df6f4  ptest xmm8, xmm8
000076bac53df6fa  jnz 0x000076BAC53E2F3B
000076bac53df700  movaps xmm10, xmm14
000076bac53df704  addpd xmm10, xmm4
000076bac53df709  vcmppd xmm8, xmm10, xmm10, 0x03
000076bac53df70f  ptest xmm8, xmm8
000076bac53df715  jnz 0x000076BAC53E307E
000076bac53df71b  vmovaps xmm14, [rsp+0x40]
000076bac53df721  vpermilpd xmm14, xmm14, 0x00
000076bac53df727  movaps xmm8, xmm1
000076bac53df72b  mulpd xmm8, xmm14
000076bac53df730  vcmppd xmm6, xmm8, xmm8, 0x03
000076bac53df736  ptest xmm6, xmm6
000076bac53df73b  jnz 0x000076BAC53E31C1
000076bac53df741  movaps xmm1, [r15+0x2B0]
000076bac53df749  vmovaps xmm14, [rsp+0x40]
000076bac53df74f  vpermilpd xmm14, xmm14, 0x00
000076bac53df755  movaps xmm6, xmm1
000076bac53df758  mulpd xmm6, xmm14
000076bac53df75d  vcmppd xmm5, xmm6, xmm6, 0x03
000076bac53df762  ptest xmm5, xmm5
000076bac53df767  jnz 0x000076BAC53E3304
000076bac53df76d  vmovaps xmm1, [rsp+0x10]
000076bac53df773  vpermilpd xmm1, xmm1, 0x00
000076bac53df779  movaps xmm14, xmm12
000076bac53df77d  mulpd xmm14, xmm1
000076bac53df782  vcmppd xmm5, xmm14, xmm14, 0x03
000076bac53df788  ptest xmm5, xmm5
000076bac53df78d  jnz 0x000076BAC53E3445
000076bac53df793  movaps xmm1, xmm13
000076bac53df797  addpd xmm1, xmm9
000076bac53df79c  vcmppd xmm12, xmm1, xmm1, 0x03
000076bac53df7a1  ptest xmm12, xmm12
000076bac53df7a7  jnz 0x000076BAC53E3588
000076bac53df7ad  vmovaps xmm13, [rsp+0x10]
000076bac53df7b3  vpermilpd xmm13, xmm13, 0x00
000076bac53df7b9  movaps xmm12, xmm7
000076bac53df7bd  mulpd xmm12, xmm13
000076bac53df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
000076bac53df7c8  ptest xmm9, xmm9
000076bac53df7ce  jnz 0x000076BAC53E36CA
000076bac53df7d4  movaps xmm13, xmm15
000076bac53df7d8  addpd xmm13, xmm8
000076bac53df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
000076bac53df7e3  ptest xmm9, xmm9
000076bac53df7e9  jnz 0x000076BAC53E380D
000076bac53df7ef  movaps xmm15, [r15+0x290]
000076bac53df7f7  vmovaps xmm9, [rsp+0x10]
000076bac53df7fd  vpermilpd xmm9, xmm9, 0x00
000076bac53df803  movaps xmm8, xmm15
000076bac53df807  mulpd xmm8, xmm9
000076bac53df80c  vcmppd xmm7, xmm8, xmm8, 0x03
000076bac53df812  ptest xmm7, xmm7
000076bac53df817  jnz 0x000076BAC53E3951
000076bac53df81d  movaps xmm15, xmm11
000076bac53df821  addpd xmm15, xmm6
000076bac53df826  vcmppd xmm9, xmm15, xmm15, 0x03
000076bac53df82c  ptest xmm9, xmm9
000076bac53df832  jnz 0x000076BAC53E3A95
000076bac53df838  movaps xmm11, [r15+0x1E0]
000076bac53df840  vmovaps xmm9, [rsp+0x10]
000076bac53df846  vpermilpd xmm9, xmm9, 0x00
000076bac53df84c  movaps xmm7, xmm11
000076bac53df850  mulpd xmm7, xmm9
000076bac53df855  vcmppd xmm6, xmm7, xmm7, 0x03
000076bac53df85a  ptest xmm6, xmm6
000076bac53df85f  jnz 0x000076BAC53E3BD8
000076bac53df865  movaps xmm11, xmm10
000076bac53df869  addpd xmm11, xmm14
000076bac53df86e  vcmppd xmm9, xmm11, xmm11, 0x03
000076bac53df874  ptest xmm9, xmm9
000076bac53df87a  jnz 0x000076BAC53E3D1A
000076bac53df880  lea r12, [rax+0x70]
000076bac53df884  movups xmm14, [r13+r12*1]
000076bac53df88a  movaps [r15+0x240], xmm14
000076bac53df892  movaps xmm10, xmm1
000076bac53df896  addpd xmm10, xmm12
000076bac53df89b  vcmppd xmm9, xmm10, xmm10, 0x03
000076bac53df8a1  ptest xmm9, xmm9
000076bac53df8a7  jnz 0x000076BAC53E3E68
000076bac53df8ad  movaps [r15+0x170], xmm10
000076bac53df8b5  vmovaps xmm1, [rsp+0x20]
000076bac53df8bb  vpermilpd xmm1, xmm1, 0x00
000076bac53df8c1  movaps xmm12, xmm14
000076bac53df8c5  mulpd xmm12, xmm1
000076bac53df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
000076bac53df8d0  ptest xmm9, xmm9
000076bac53df8d6  jnz 0x000076BAC53E3FAB
000076bac53df8dc  vmovaps xmm1, [rsp+0x20]
000076bac53df8e2  vpermilpd xmm1, xmm1, 0x00
000076bac53df8e8  vmovaps xmm9, [rsp+0xB0]
000076bac53df8f1  movaps xmm14, xmm9
000076bac53df8f5  mulpd xmm14, xmm1
000076bac53df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
000076bac53df900  ptest xmm6, xmm6
000076bac53df905  jnz 0x000076BAC53E40EE
000076bac53df90b  movaps [r15+0x180], xmm14
000076bac53df913  movaps xmm1, xmm13
000076bac53df917  addpd xmm1, xmm8
000076bac53df91c  vcmppd xmm9, xmm1, xmm1, 0x03
000076bac53df921  ptest xmm9, xmm9
000076bac53df927  jnz 0x000076BAC53E4231
000076bac53df92d  movaps [r15+0x210], xmm1
000076bac53df935  movups xmm13, [r13+rax*1]
000076bac53df93b  lea r12, [rax+0x10]
000076bac53df93f  movups xmm9, [r13+r12*1]
000076bac53df945  movaps [r15+0x230], xmm9
000076bac53df94d  movaps xmm8, xmm15
000076bac53df951  addpd xmm8, xmm7
000076bac53df956  vcmppd xmm6, xmm8, xmm8, 0x03
000076bac53df95c  ptest xmm6, xmm6
000076bac53df961  jnz 0x000076BAC53E4387
000076bac53df967  movaps [r15+0x130], xmm8
000076bac53df96f  vmovaps xmm15, [rsp+0x20]
000076bac53df975  vpermilpd xmm15, xmm15, 0x00
000076bac53df97b  movaps xmm7, xmm9
000076bac53df97f  mulpd xmm7, xmm15
000076bac53df984  vcmppd xmm6, xmm7, xmm7, 0x03
000076bac53df989  ptest xmm6, xmm6
000076bac53df98e  jnz 0x000076BAC53E44CA
000076bac53df994  movaps [r15+0x220], xmm7
000076bac53df99c  vmovaps xmm15, [rsp+0x20]
000076bac53df9a2  vpermilpd xmm15, xmm15, 0x00
000076bac53df9a8  movaps xmm9, xmm13
000076bac53df9ac  mulpd xmm9, xmm15
000076bac53df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
000076bac53df9b7  ptest xmm6, xmm6
000076bac53df9bc  jnz 0x000076BAC53E460C
000076bac53df9c2  movaps xmm15, xmm11
000076bac53df9c6  addpd xmm15, xmm12
000076bac53df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
000076bac53df9d1  ptest xmm13, xmm13
000076bac53df9d7  jnz 0x000076BAC53E4750
000076bac53df9dd  movaps [r15+0x140], xmm15
000076bac53df9e5  movaps xmm13, xmm10
000076bac53df9e9  addpd xmm13, xmm14
000076bac53df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
000076bac53df9f4  ptest xmm12, xmm12
000076bac53df9fa  jnz 0x000076BAC53E4894
000076bac53dfa00  movaps [r15+0x150], xmm13
000076bac53dfa08  movaps xmm14, xmm1
000076bac53dfa0c  addpd xmm14, xmm7
000076bac53dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
000076bac53dfa17  ptest xmm12, xmm12
000076bac53dfa1d  jnz 0x000076BAC53E49D8
000076bac53dfa23  movaps [r15+0x160], xmm14
000076bac53dfa2b  movaps xmm1, xmm8
000076bac53dfa2f  addpd xmm1, xmm9
000076bac53dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
000076bac53dfa39  ptest xmm12, xmm12
000076bac53dfa3f  jnz 0x000076BAC53E4B1A
000076bac53dfa45  movaps [r15+0x120], xmm1
000076bac53dfa4d  movups [r13+r14*1], xmm15
000076bac53dfa53  lea rax, [r14+0x10]
000076bac53dfa57  movups [r13+rax*1], xmm13
000076bac53dfa5d  lea rax, [r14+0x20]
000076bac53dfa61  movups [r13+rax*1], xmm14
000076bac53dfa67  lea rax, [r14+0x30]
000076bac53dfa6b  movups [r13+rax*1], xmm1
000076bac53dfa71  mov eax, [r15+0x108]
000076bac53dfa78  sahf
000076bac53dfa79  jnz 0x000076BAC53DFAAB
000076bac53dfa7b  cmp dword ptr [r15+0x318], 0x00
000076bac53dfa83  jz 0x000076BAC53DEAE0
000076bac53dfa89  nop [rax+rax*1], ax
000076bac53dfa92  nop [rax+rax*1], eax
000076bac53dfa9a  mov eax, 0x4106D0
000076bac53dfa9f  mov [r15+0x100], rax
000076bac53dfaa6  jmp 0x000076BAC51FE110
000076bac53dfaab  cmp dword ptr [r15+0x318], 0x00
000076bac53dfab3  jz 0x000076BAC53D89C0
000076bac53dfab9  nop [rax+rax*1], ax
000076bac53dfac2  nop [rax+rax*1], eax
000076bac53dfaca  mov eax, 0x410504
000076bac53dfacf  mov [r15+0x100], rax
000076bac53dfad6  jmp 0x000076BAC51FE110
000076bac53dfadb  int3
000076bac53dfadc  call 0x000076BAC52E27E0
000076bac53dfae1  jmp 0x000076BAC53DEBBF
000076bac53dfae6  call 0x000076BAC52E1570
000076bac53dfaeb  jmp 0x000076BAC53DEBC8
000076bac53dfaf0  call 0x000076BAC52E27E0
000076bac53dfaf5  jmp 0x000076BAC53DEC24
000076bac53dfafa  call 0x000076BAC52E1570
000076bac53dfaff  jmp 0x000076BAC53DEC2D
000076bac53dfb04  call 0x000076BAC52E27E0
000076bac53dfb09  jmp 0x000076BAC53DEC70
000076bac53dfb0e  call 0x000076BAC52E1570
000076bac53dfb13  jmp 0x000076BAC53DEC79
000076bac53dfb18  call 0x000076BAC520DC20
000076bac53dfb1d  jmp 0x000076BAC53DECB8
000076bac53dfb22  call 0x000076BAC52D59C0
000076bac53dfb27  jmp 0x000076BAC53DECCB
000076bac53dfb2c  call 0x000076BAC52E0E30
000076bac53dfb31  jmp 0x000076BAC53DECE9
000076bac53dfb36  call 0x000076BAC52DFBC0
000076bac53dfb3b  jmp 0x000076BAC53DECF3
000076bac53dfb40  call 0x000076BAC52DE950
000076bac53dfb45  jmp 0x000076BAC53DECFD
000076bac53dfb4a  sub rsp, 0x08
000076bac53dfb4e  push rax
000076bac53dfb4f  push rcx
000076bac53dfb50  push rdx
000076bac53dfb51  push rdi
000076bac53dfb52  push rsi
000076bac53dfb53  push r8
000076bac53dfb55  push r9
000076bac53dfb57  push r10
000076bac53dfb59  push r11
000076bac53dfb5b  sub rsp, 0xF0
000076bac53dfb62  vmovaps [rsp], xmm0
000076bac53dfb67  vmovaps [rsp+0x10], xmm1
000076bac53dfb6d  vmovaps [rsp+0x20], xmm2
000076bac53dfb73  vmovaps [rsp+0x30], xmm3
000076bac53dfb79  vmovaps [rsp+0x40], xmm4
000076bac53dfb7f  vmovaps [rsp+0x50], xmm5
000076bac53dfb85  vmovaps [rsp+0x60], xmm6
000076bac53dfb8b  vmovaps [rsp+0x70], xmm7
000076bac53dfb91  vmovaps [rsp+0x80], xmm9
000076bac53dfb9a  vmovaps [rsp+0x90], xmm10
000076bac53dfba3  vmovaps [rsp+0xA0], xmm11
000076bac53dfbac  vmovaps [rsp+0xB0], xmm12
000076bac53dfbb5  vmovaps [rsp+0xC0], xmm13
000076bac53dfbbe  vmovaps [rsp+0xD0], xmm14
000076bac53dfbc7  vmovaps [rsp+0xE0], xmm15
000076bac53dfbd0  sub rsp, 0x30
000076bac53dfbd4  movaps [rsp], xmm8
000076bac53dfbd9  movaps [rsp+0x10], xmm12
000076bac53dfbdf  movaps [rsp+0x20], xmm15
000076bac53dfbe5  lea rdi, [rsp]
000076bac53dfbe9  mov esi, 0x00
000076bac53dfbee  mov rax, 0x5641B0A3C530
000076bac53dfbf8  call rax
000076bac53dfbfa  movaps xmm8, [rsp]
000076bac53dfbff  add rsp, 0x30
000076bac53dfc03  vmovaps xmm0, [rsp]
000076bac53dfc08  vmovaps xmm1, [rsp+0x10]
000076bac53dfc0e  vmovaps xmm2, [rsp+0x20]
000076bac53dfc14  vmovaps xmm3, [rsp+0x30]
000076bac53dfc1a  vmovaps xmm4, [rsp+0x40]
000076bac53dfc20  vmovaps xmm5, [rsp+0x50]
000076bac53dfc26  vmovaps xmm6, [rsp+0x60]
000076bac53dfc2c  vmovaps xmm7, [rsp+0x70]
000076bac53dfc32  vmovaps xmm9, [rsp+0x80]
000076bac53dfc3b  vmovaps xmm10, [rsp+0x90]
000076bac53dfc44  vmovaps xmm11, [rsp+0xA0]
000076bac53dfc4d  vmovaps xmm12, [rsp+0xB0]
000076bac53dfc56  vmovaps xmm13, [rsp+0xC0]
000076bac53dfc5f  vmovaps xmm14, [rsp+0xD0]
000076bac53dfc68  vmovaps xmm15, [rsp+0xE0]
000076bac53dfc71  add rsp, 0xF0
000076bac53dfc78  pop r11
000076bac53dfc7a  pop r10
000076bac53dfc7c  pop r9
000076bac53dfc7e  pop r8
000076bac53dfc80  pop rsi
000076bac53dfc81  pop rdi
000076bac53dfc82  pop rdx
000076bac53dfc83  pop rcx
000076bac53dfc84  pop rax
000076bac53dfc85  add rsp, 0x08
000076bac53dfc89  jmp 0x000076BAC53DED27
000076bac53dfc8e  sub rsp, 0x08
000076bac53dfc92  push rax
000076bac53dfc93  push rcx
000076bac53dfc94  push rdx
000076bac53dfc95  push rdi
000076bac53dfc96  push rsi
000076bac53dfc97  push r8
000076bac53dfc99  push r9
000076bac53dfc9b  push r10
000076bac53dfc9d  push r11
000076bac53dfc9f  sub rsp, 0xF0
000076bac53dfca6  vmovaps [rsp], xmm0
000076bac53dfcab  vmovaps [rsp+0x10], xmm1
000076bac53dfcb1  vmovaps [rsp+0x20], xmm2
000076bac53dfcb7  vmovaps [rsp+0x30], xmm3
000076bac53dfcbd  vmovaps [rsp+0x40], xmm4
000076bac53dfcc3  vmovaps [rsp+0x50], xmm5
000076bac53dfcc9  vmovaps [rsp+0x60], xmm6
000076bac53dfccf  vmovaps [rsp+0x70], xmm8
000076bac53dfcd5  vmovaps [rsp+0x80], xmm9
000076bac53dfcde  vmovaps [rsp+0x90], xmm10
000076bac53dfce7  vmovaps [rsp+0xA0], xmm11
000076bac53dfcf0  vmovaps [rsp+0xB0], xmm12
000076bac53dfcf9  vmovaps [rsp+0xC0], xmm13
000076bac53dfd02  vmovaps [rsp+0xD0], xmm14
000076bac53dfd0b  vmovaps [rsp+0xE0], xmm15
000076bac53dfd14  sub rsp, 0x30
000076bac53dfd18  movaps [rsp], xmm7
000076bac53dfd1c  movaps [rsp+0x10], xmm9
000076bac53dfd22  movaps [rsp+0x20], xmm15
000076bac53dfd28  lea rdi, [rsp]
000076bac53dfd2c  mov esi, 0x00
000076bac53dfd31  mov rax, 0x5641B0A3C530
000076bac53dfd3b  call rax
000076bac53dfd3d  movaps xmm7, [rsp]
000076bac53dfd41  add rsp, 0x30
000076bac53dfd45  vmovaps xmm0, [rsp]
000076bac53dfd4a  vmovaps xmm1, [rsp+0x10]
000076bac53dfd50  vmovaps xmm2, [rsp+0x20]
000076bac53dfd56  vmovaps xmm3, [rsp+0x30]
000076bac53dfd5c  vmovaps xmm4, [rsp+0x40]
000076bac53dfd62  vmovaps xmm5, [rsp+0x50]
000076bac53dfd68  vmovaps xmm6, [rsp+0x60]
000076bac53dfd6e  vmovaps xmm8, [rsp+0x70]
000076bac53dfd74  vmovaps xmm9, [rsp+0x80]
000076bac53dfd7d  vmovaps xmm10, [rsp+0x90]
000076bac53dfd86  vmovaps xmm11, [rsp+0xA0]
000076bac53dfd8f  vmovaps xmm12, [rsp+0xB0]
000076bac53dfd98  vmovaps xmm13, [rsp+0xC0]
000076bac53dfda1  vmovaps xmm14, [rsp+0xD0]
000076bac53dfdaa  vmovaps xmm15, [rsp+0xE0]
000076bac53dfdb3  add rsp, 0xF0
000076bac53dfdba  pop r11
000076bac53dfdbc  pop r10
000076bac53dfdbe  pop r9
000076bac53dfdc0  pop r8
000076bac53dfdc2  pop rsi
000076bac53dfdc3  pop rdi
000076bac53dfdc4  pop rdx
000076bac53dfdc5  pop rcx
000076bac53dfdc6  pop rax
000076bac53dfdc7  add rsp, 0x08
000076bac53dfdcb  jmp 0x000076BAC53DED55
000076bac53dfdd0  sub rsp, 0x08
000076bac53dfdd4  push rax
000076bac53dfdd5  push rcx
000076bac53dfdd6  push rdx
000076bac53dfdd7  push rdi
000076bac53dfdd8  push rsi
000076bac53dfdd9  push r8
000076bac53dfddb  push r9
000076bac53dfddd  push r10
000076bac53dfddf  push r11
000076bac53dfde1  sub rsp, 0xF0
000076bac53dfde8  vmovaps [rsp], xmm0
000076bac53dfded  vmovaps [rsp+0x10], xmm1
000076bac53dfdf3  vmovaps [rsp+0x20], xmm2
000076bac53dfdf9  vmovaps [rsp+0x30], xmm3
000076bac53dfdff  vmovaps [rsp+0x40], xmm4
000076bac53dfe05  vmovaps [rsp+0x50], xmm5
000076bac53dfe0b  vmovaps [rsp+0x60], xmm6
000076bac53dfe11  vmovaps [rsp+0x70], xmm7
000076bac53dfe17  vmovaps [rsp+0x80], xmm8
000076bac53dfe20  vmovaps [rsp+0x90], xmm10
000076bac53dfe29  vmovaps [rsp+0xA0], xmm11
000076bac53dfe32  vmovaps [rsp+0xB0], xmm12
000076bac53dfe3b  vmovaps [rsp+0xC0], xmm13
000076bac53dfe44  vmovaps [rsp+0xD0], xmm14
000076bac53dfe4d  vmovaps [rsp+0xE0], xmm15
000076bac53dfe56  sub rsp, 0x30
000076bac53dfe5a  movaps [rsp], xmm9
000076bac53dfe5f  movaps [rsp+0x10], xmm12
000076bac53dfe65  movaps [rsp+0x20], xmm10
000076bac53dfe6b  lea rdi, [rsp]
000076bac53dfe6f  mov esi, 0x00
000076bac53dfe74  mov rax, 0x5641B0A3C530
000076bac53dfe7e  call rax
000076bac53dfe80  movaps xmm9, [rsp]
000076bac53dfe85  add rsp, 0x30
000076bac53dfe89  vmovaps xmm0, [rsp]
000076bac53dfe8e  vmovaps xmm1, [rsp+0x10]
000076bac53dfe94  vmovaps xmm2, [rsp+0x20]
000076bac53dfe9a  vmovaps xmm3, [rsp+0x30]
000076bac53dfea0  vmovaps xmm4, [rsp+0x40]
000076bac53dfea6  vmovaps xmm5, [rsp+0x50]
000076bac53dfeac  vmovaps xmm6, [rsp+0x60]
000076bac53dfeb2  vmovaps xmm7, [rsp+0x70]
000076bac53dfeb8  vmovaps xmm8, [rsp+0x80]
000076bac53dfec1  vmovaps xmm10, [rsp+0x90]
000076bac53dfeca  vmovaps xmm11, [rsp+0xA0]
000076bac53dfed3  vmovaps xmm12, [rsp+0xB0]
000076bac53dfedc  vmovaps xmm13, [rsp+0xC0]
000076bac53dfee5  vmovaps xmm14, [rsp+0xD0]
000076bac53dfeee  vmovaps xmm15, [rsp+0xE0]
000076bac53dfef7  add rsp, 0xF0
000076bac53dfefe  pop r11
000076bac53dff00  pop r10
000076bac53dff02  pop r9
000076bac53dff04  pop r8
000076bac53dff06  pop rsi
000076bac53dff07  pop rdi
000076bac53dff08  pop rdx
000076bac53dff09  pop rcx
000076bac53dff0a  pop rax
000076bac53dff0b  add rsp, 0x08
000076bac53dff0f  jmp 0x000076BAC53DED79
000076bac53dff14  sub rsp, 0x08
000076bac53dff18  push rax
000076bac53dff19  push rcx
000076bac53dff1a  push rdx
000076bac53dff1b  push rdi
000076bac53dff1c  push rsi
000076bac53dff1d  push r8
000076bac53dff1f  push r9
000076bac53dff21  push r10
000076bac53dff23  push r11
000076bac53dff25  sub rsp, 0xF0
000076bac53dff2c  vmovaps [rsp], xmm0
000076bac53dff31  vmovaps [rsp+0x10], xmm1
000076bac53dff37  vmovaps [rsp+0x20], xmm2
000076bac53dff3d  vmovaps [rsp+0x30], xmm3
000076bac53dff43  vmovaps [rsp+0x40], xmm4
000076bac53dff49  vmovaps [rsp+0x50], xmm5
000076bac53dff4f  vmovaps [rsp+0x60], xmm6
000076bac53dff55  vmovaps [rsp+0x70], xmm7
000076bac53dff5b  vmovaps [rsp+0x80], xmm8
000076bac53dff64  vmovaps [rsp+0x90], xmm9
000076bac53dff6d  vmovaps [rsp+0xA0], xmm11
000076bac53dff76  vmovaps [rsp+0xB0], xmm12
000076bac53dff7f  vmovaps [rsp+0xC0], xmm13
000076bac53dff88  vmovaps [rsp+0xD0], xmm14
000076bac53dff91  vmovaps [rsp+0xE0], xmm15
000076bac53dff9a  sub rsp, 0x30
000076bac53dff9e  movaps [rsp], xmm10
000076bac53dffa3  movaps [rsp+0x10], xmm12
000076bac53dffa9  movaps [rsp+0x20], xmm11
000076bac53dffaf  lea rdi, [rsp]
000076bac53dffb3  mov esi, 0x00
000076bac53dffb8  mov rax, 0x5641B0A3C530
000076bac53dffc2  call rax
000076bac53dffc4  movaps xmm10, [rsp]
000076bac53dffc9  add rsp, 0x30
000076bac53dffcd  vmovaps xmm0, [rsp]
000076bac53dffd2  vmovaps xmm1, [rsp+0x10]
000076bac53dffd8  vmovaps xmm2, [rsp+0x20]
000076bac53dffde  vmovaps xmm3, [rsp+0x30]
000076bac53dffe4  vmovaps xmm4, [rsp+0x40]
000076bac53dffea  vmovaps xmm5, [rsp+0x50]
000076bac53dfff0  vmovaps xmm6, [rsp+0x60]
000076bac53dfff6  vmovaps xmm7, [rsp+0x70]
000076bac53dfffc  vmovaps xmm8, [rsp+0x80]
000076bac53e0005  vmovaps xmm9, [rsp+0x90]
000076bac53e000e  vmovaps xmm11, [rsp+0xA0]
000076bac53e0017  vmovaps xmm12, [rsp+0xB0]
000076bac53e0020  vmovaps xmm13, [rsp+0xC0]
000076bac53e0029  vmovaps xmm14, [rsp+0xD0]
000076bac53e0032  vmovaps xmm15, [rsp+0xE0]
000076bac53e003b  add rsp, 0xF0
000076bac53e0042  pop r11
000076bac53e0044  pop r10
000076bac53e0046  pop r9
000076bac53e0048  pop r8
000076bac53e004a  pop rsi
000076bac53e004b  pop rdi
000076bac53e004c  pop rdx
000076bac53e004d  pop rcx
000076bac53e004e  pop rax
000076bac53e004f  add rsp, 0x08
000076bac53e0053  jmp 0x000076BAC53DED93
000076bac53e0058  sub rsp, 0x08
000076bac53e005c  push rax
000076bac53e005d  push rcx
000076bac53e005e  push rdx
000076bac53e005f  push rdi
000076bac53e0060  push rsi
000076bac53e0061  push r8
000076bac53e0063  push r9
000076bac53e0065  push r10
000076bac53e0067  push r11
000076bac53e0069  sub rsp, 0xF0
000076bac53e0070  vmovaps [rsp], xmm0
000076bac53e0075  vmovaps [rsp+0x10], xmm1
000076bac53e007b  vmovaps [rsp+0x20], xmm2
000076bac53e0081  vmovaps [rsp+0x30], xmm3
000076bac53e0087  vmovaps [rsp+0x40], xmm4
000076bac53e008d  vmovaps [rsp+0x50], xmm5
000076bac53e0093  vmovaps [rsp+0x60], xmm7
000076bac53e0099  vmovaps [rsp+0x70], xmm8
000076bac53e009f  vmovaps [rsp+0x80], xmm9
000076bac53e00a8  vmovaps [rsp+0x90], xmm10
000076bac53e00b1  vmovaps [rsp+0xA0], xmm11
000076bac53e00ba  vmovaps [rsp+0xB0], xmm12
000076bac53e00c3  vmovaps [rsp+0xC0], xmm13
000076bac53e00cc  vmovaps [rsp+0xD0], xmm14
000076bac53e00d5  vmovaps [rsp+0xE0], xmm15
000076bac53e00de  sub rsp, 0x30
000076bac53e00e2  movaps [rsp], xmm6
000076bac53e00e6  movaps [rsp+0x10], xmm12
000076bac53e00ec  movaps [rsp+0x20], xmm11
000076bac53e00f2  lea rdi, [rsp]
000076bac53e00f6  mov esi, 0x00
000076bac53e00fb  mov rax, 0x5641B0A3C530
000076bac53e0105  call rax
000076bac53e0107  movaps xmm6, [rsp]
000076bac53e010b  add rsp, 0x30
000076bac53e010f  vmovaps xmm0, [rsp]
000076bac53e0114  vmovaps xmm1, [rsp+0x10]
000076bac53e011a  vmovaps xmm2, [rsp+0x20]
000076bac53e0120  vmovaps xmm3, [rsp+0x30]
000076bac53e0126  vmovaps xmm4, [rsp+0x40]
000076bac53e012c  vmovaps xmm5, [rsp+0x50]
000076bac53e0132  vmovaps xmm7, [rsp+0x60]
000076bac53e0138  vmovaps xmm8, [rsp+0x70]
000076bac53e013e  vmovaps xmm9, [rsp+0x80]
000076bac53e0147  vmovaps xmm10, [rsp+0x90]
000076bac53e0150  vmovaps xmm11, [rsp+0xA0]
000076bac53e0159  vmovaps xmm12, [rsp+0xB0]
000076bac53e0162  vmovaps xmm13, [rsp+0xC0]
000076bac53e016b  vmovaps xmm14, [rsp+0xD0]
000076bac53e0174  vmovaps xmm15, [rsp+0xE0]
000076bac53e017d  add rsp, 0xF0
000076bac53e0184  pop r11
000076bac53e0186  pop r10
000076bac53e0188  pop r9
000076bac53e018a  pop r8
000076bac53e018c  pop rsi
000076bac53e018d  pop rdi
000076bac53e018e  pop rdx
000076bac53e018f  pop rcx
000076bac53e0190  pop rax
000076bac53e0191  add rsp, 0x08
000076bac53e0195  jmp 0x000076BAC53DEDB4
000076bac53e019a  sub rsp, 0x08
000076bac53e019e  push rax
000076bac53e019f  push rcx
000076bac53e01a0  push rdx
000076bac53e01a1  push rdi
000076bac53e01a2  push rsi
000076bac53e01a3  push r8
000076bac53e01a5  push r9
000076bac53e01a7  push r10
000076bac53e01a9  push r11
000076bac53e01ab  sub rsp, 0xF0
000076bac53e01b2  vmovaps [rsp], xmm0
000076bac53e01b7  vmovaps [rsp+0x10], xmm1
000076bac53e01bd  vmovaps [rsp+0x20], xmm2
000076bac53e01c3  vmovaps [rsp+0x30], xmm4
000076bac53e01c9  vmovaps [rsp+0x40], xmm5
000076bac53e01cf  vmovaps [rsp+0x50], xmm6
000076bac53e01d5  vmovaps [rsp+0x60], xmm7
000076bac53e01db  vmovaps [rsp+0x70], xmm8
000076bac53e01e1  vmovaps [rsp+0x80], xmm9
000076bac53e01ea  vmovaps [rsp+0x90], xmm10
000076bac53e01f3  vmovaps [rsp+0xA0], xmm11
000076bac53e01fc  vmovaps [rsp+0xB0], xmm12
000076bac53e0205  vmovaps [rsp+0xC0], xmm13
000076bac53e020e  vmovaps [rsp+0xD0], xmm14
000076bac53e0217  vmovaps [rsp+0xE0], xmm15
000076bac53e0220  sub rsp, 0x30
000076bac53e0224  movaps [rsp], xmm3
000076bac53e0228  movaps [rsp+0x10], xmm5
000076bac53e022d  movaps [rsp+0x20], xmm4
000076bac53e0232  lea rdi, [rsp]
000076bac53e0236  mov esi, 0x00
000076bac53e023b  mov rax, 0x5641B0A3C530
000076bac53e0245  call rax
000076bac53e0247  movaps xmm3, [rsp]
000076bac53e024b  add rsp, 0x30
000076bac53e024f  vmovaps xmm0, [rsp]
000076bac53e0254  vmovaps xmm1, [rsp+0x10]
000076bac53e025a  vmovaps xmm2, [rsp+0x20]
000076bac53e0260  vmovaps xmm4, [rsp+0x30]
000076bac53e0266  vmovaps xmm5, [rsp+0x40]
000076bac53e026c  vmovaps xmm6, [rsp+0x50]
000076bac53e0272  vmovaps xmm7, [rsp+0x60]
000076bac53e0278  vmovaps xmm8, [rsp+0x70]
000076bac53e027e  vmovaps xmm9, [rsp+0x80]
000076bac53e0287  vmovaps xmm10, [rsp+0x90]
000076bac53e0290  vmovaps xmm11, [rsp+0xA0]
000076bac53e0299  vmovaps xmm12, [rsp+0xB0]
000076bac53e02a2  vmovaps xmm13, [rsp+0xC0]
000076bac53e02ab  vmovaps xmm14, [rsp+0xD0]
000076bac53e02b4  vmovaps xmm15, [rsp+0xE0]
000076bac53e02bd  add rsp, 0xF0
000076bac53e02c4  pop r11
000076bac53e02c6  pop r10
000076bac53e02c8  pop r9
000076bac53e02ca  pop r8
000076bac53e02cc  pop rsi
000076bac53e02cd  pop rdi
000076bac53e02ce  pop rdx
000076bac53e02cf  pop rcx
000076bac53e02d0  pop rax
000076bac53e02d1  add rsp, 0x08
000076bac53e02d5  jmp 0x000076BAC53DEE15
000076bac53e02da  sub rsp, 0x08
000076bac53e02de  push rax
000076bac53e02df  push rcx
000076bac53e02e0  push rdx
000076bac53e02e1  push rdi
000076bac53e02e2  push rsi
000076bac53e02e3  push r8
000076bac53e02e5  push r9
000076bac53e02e7  push r10
000076bac53e02e9  push r11
000076bac53e02eb  sub rsp, 0xF0
000076bac53e02f2  vmovaps [rsp], xmm0
000076bac53e02f7  vmovaps [rsp+0x10], xmm1
000076bac53e02fd  vmovaps [rsp+0x20], xmm2
000076bac53e0303  vmovaps [rsp+0x30], xmm3
000076bac53e0309  vmovaps [rsp+0x40], xmm4
000076bac53e030f  vmovaps [rsp+0x50], xmm6
000076bac53e0315  vmovaps [rsp+0x60], xmm7
000076bac53e031b  vmovaps [rsp+0x70], xmm8
000076bac53e0321  vmovaps [rsp+0x80], xmm9
000076bac53e032a  vmovaps [rsp+0x90], xmm10
000076bac53e0333  vmovaps [rsp+0xA0], xmm11
000076bac53e033c  vmovaps [rsp+0xB0], xmm12
000076bac53e0345  vmovaps [rsp+0xC0], xmm13
000076bac53e034e  vmovaps [rsp+0xD0], xmm14
000076bac53e0357  vmovaps [rsp+0xE0], xmm15
000076bac53e0360  sub rsp, 0x30
000076bac53e0364  movaps [rsp], xmm5
000076bac53e0368  movaps [rsp+0x10], xmm8
000076bac53e036e  movaps [rsp+0x20], xmm15
000076bac53e0374  lea rdi, [rsp]
000076bac53e0378  mov esi, 0x00
000076bac53e037d  mov rax, 0x5641B0A3C530
000076bac53e0387  call rax
000076bac53e0389  movaps xmm5, [rsp]
000076bac53e038d  add rsp, 0x30
000076bac53e0391  vmovaps xmm0, [rsp]
000076bac53e0396  vmovaps xmm1, [rsp+0x10]
000076bac53e039c  vmovaps xmm2, [rsp+0x20]
000076bac53e03a2  vmovaps xmm3, [rsp+0x30]
000076bac53e03a8  vmovaps xmm4, [rsp+0x40]
000076bac53e03ae  vmovaps xmm6, [rsp+0x50]
000076bac53e03b4  vmovaps xmm7, [rsp+0x60]
000076bac53e03ba  vmovaps xmm8, [rsp+0x70]
000076bac53e03c0  vmovaps xmm9, [rsp+0x80]
000076bac53e03c9  vmovaps xmm10, [rsp+0x90]
000076bac53e03d2  vmovaps xmm11, [rsp+0xA0]
000076bac53e03db  vmovaps xmm12, [rsp+0xB0]
000076bac53e03e4  vmovaps xmm13, [rsp+0xC0]
000076bac53e03ed  vmovaps xmm14, [rsp+0xD0]
000076bac53e03f6  vmovaps xmm15, [rsp+0xE0]
000076bac53e03ff  add rsp, 0xF0
000076bac53e0406  pop r11
000076bac53e0408  pop r10
000076bac53e040a  pop r9
000076bac53e040c  pop r8
000076bac53e040e  pop rsi
000076bac53e040f  pop rdi
000076bac53e0410  pop rdx
000076bac53e0411  pop rcx
000076bac53e0412  pop rax
000076bac53e0413  add rsp, 0x08
000076bac53e0417  jmp 0x000076BAC53DEE53
000076bac53e041c  sub rsp, 0x08
000076bac53e0420  push rax
000076bac53e0421  push rcx
000076bac53e0422  push rdx
000076bac53e0423  push rdi
000076bac53e0424  push rsi
000076bac53e0425  push r8
000076bac53e0427  push r9
000076bac53e0429  push r10
000076bac53e042b  push r11
000076bac53e042d  sub rsp, 0xF0
000076bac53e0434  vmovaps [rsp], xmm0
000076bac53e0439  vmovaps [rsp+0x10], xmm1
000076bac53e043f  vmovaps [rsp+0x20], xmm2
000076bac53e0445  vmovaps [rsp+0x30], xmm3
000076bac53e044b  vmovaps [rsp+0x40], xmm5
000076bac53e0451  vmovaps [rsp+0x50], xmm6
000076bac53e0457  vmovaps [rsp+0x60], xmm7
000076bac53e045d  vmovaps [rsp+0x70], xmm8
000076bac53e0463  vmovaps [rsp+0x80], xmm9
000076bac53e046c  vmovaps [rsp+0x90], xmm10
000076bac53e0475  vmovaps [rsp+0xA0], xmm11
000076bac53e047e  vmovaps [rsp+0xB0], xmm12
000076bac53e0487  vmovaps [rsp+0xC0], xmm13
000076bac53e0490  vmovaps [rsp+0xD0], xmm14
000076bac53e0499  vmovaps [rsp+0xE0], xmm15
000076bac53e04a2  sub rsp, 0x30
000076bac53e04a6  movaps [rsp], xmm4
000076bac53e04aa  movaps [rsp+0x10], xmm9
000076bac53e04b0  movaps [rsp+0x20], xmm8
000076bac53e04b6  lea rdi, [rsp]
000076bac53e04ba  mov esi, 0x00
000076bac53e04bf  mov rax, 0x5641B0A3C530
000076bac53e04c9  call rax
000076bac53e04cb  movaps xmm4, [rsp]
000076bac53e04cf  add rsp, 0x30
000076bac53e04d3  vmovaps xmm0, [rsp]
000076bac53e04d8  vmovaps xmm1, [rsp+0x10]
000076bac53e04de  vmovaps xmm2, [rsp+0x20]
000076bac53e04e4  vmovaps xmm3, [rsp+0x30]
000076bac53e04ea  vmovaps xmm5, [rsp+0x40]
000076bac53e04f0  vmovaps xmm6, [rsp+0x50]
000076bac53e04f6  vmovaps xmm7, [rsp+0x60]
000076bac53e04fc  vmovaps xmm8, [rsp+0x70]
000076bac53e0502  vmovaps xmm9, [rsp+0x80]
000076bac53e050b  vmovaps xmm10, [rsp+0x90]
000076bac53e0514  vmovaps xmm11, [rsp+0xA0]
000076bac53e051d  vmovaps xmm12, [rsp+0xB0]
000076bac53e0526  vmovaps xmm13, [rsp+0xC0]
000076bac53e052f  vmovaps xmm14, [rsp+0xD0]
000076bac53e0538  vmovaps xmm15, [rsp+0xE0]
000076bac53e0541  add rsp, 0xF0
000076bac53e0548  pop r11
000076bac53e054a  pop r10
000076bac53e054c  pop r9
000076bac53e054e  pop r8
000076bac53e0550  pop rsi
000076bac53e0551  pop rdi
000076bac53e0552  pop rdx
000076bac53e0553  pop rcx
000076bac53e0554  pop rax
000076bac53e0555  add rsp, 0x08
000076bac53e0559  jmp 0x000076BAC53DEE74
000076bac53e055e  sub rsp, 0x08
000076bac53e0562  push rax
000076bac53e0563  push rcx
000076bac53e0564  push rdx
000076bac53e0565  push rdi
000076bac53e0566  push rsi
000076bac53e0567  push r8
000076bac53e0569  push r9
000076bac53e056b  push r10
000076bac53e056d  push r11
000076bac53e056f  sub rsp, 0xF0
000076bac53e0576  vmovaps [rsp], xmm0
000076bac53e057b  vmovaps [rsp+0x10], xmm1
000076bac53e0581  vmovaps [rsp+0x20], xmm2
000076bac53e0587  vmovaps [rsp+0x30], xmm3
000076bac53e058d  vmovaps [rsp+0x40], xmm4
000076bac53e0593  vmovaps [rsp+0x50], xmm5
000076bac53e0599  vmovaps [rsp+0x60], xmm6
000076bac53e059f  vmovaps [rsp+0x70], xmm7
000076bac53e05a5  vmovaps [rsp+0x80], xmm8
000076bac53e05ae  vmovaps [rsp+0x90], xmm10
000076bac53e05b7  vmovaps [rsp+0xA0], xmm11
000076bac53e05c0  vmovaps [rsp+0xB0], xmm12
000076bac53e05c9  vmovaps [rsp+0xC0], xmm13
000076bac53e05d2  vmovaps [rsp+0xD0], xmm14
000076bac53e05db  vmovaps [rsp+0xE0], xmm15
000076bac53e05e4  sub rsp, 0x30
000076bac53e05e8  movaps [rsp], xmm9
000076bac53e05ed  movaps [rsp+0x10], xmm10
000076bac53e05f3  movaps [rsp+0x20], xmm8
000076bac53e05f9  lea rdi, [rsp]
000076bac53e05fd  mov esi, 0x00
000076bac53e0602  mov rax, 0x5641B0A3C530
000076bac53e060c  call rax
000076bac53e060e  movaps xmm9, [rsp]
000076bac53e0613  add rsp, 0x30
000076bac53e0617  vmovaps xmm0, [rsp]
000076bac53e061c  vmovaps xmm1, [rsp+0x10]
000076bac53e0622  vmovaps xmm2, [rsp+0x20]
000076bac53e0628  vmovaps xmm3, [rsp+0x30]
000076bac53e062e  vmovaps xmm4, [rsp+0x40]
000076bac53e0634  vmovaps xmm5, [rsp+0x50]
000076bac53e063a  vmovaps xmm6, [rsp+0x60]
000076bac53e0640  vmovaps xmm7, [rsp+0x70]
000076bac53e0646  vmovaps xmm8, [rsp+0x80]
000076bac53e064f  vmovaps xmm10, [rsp+0x90]
000076bac53e0658  vmovaps xmm11, [rsp+0xA0]
000076bac53e0661  vmovaps xmm12, [rsp+0xB0]
000076bac53e066a  vmovaps xmm13, [rsp+0xC0]
000076bac53e0673  vmovaps xmm14, [rsp+0xD0]
000076bac53e067c  vmovaps xmm15, [rsp+0xE0]
000076bac53e0685  add rsp, 0xF0
000076bac53e068c  pop r11
000076bac53e068e  pop r10
000076bac53e0690  pop r9
000076bac53e0692  pop r8
000076bac53e0694  pop rsi
000076bac53e0695  pop rdi
000076bac53e0696  pop rdx
000076bac53e0697  pop rcx
000076bac53e0698  pop rax
000076bac53e0699  add rsp, 0x08
000076bac53e069d  jmp 0x000076BAC53DEE8E
000076bac53e06a2  call 0x000076BAC52B52F0
000076bac53e06a7  jmp 0x000076BAC53DEFA8
000076bac53e06ac  call 0x000076BAC52B52F0
000076bac53e06b1  jmp 0x000076BAC53DEFBE
000076bac53e06b6  sub rsp, 0x08
000076bac53e06ba  push rax
000076bac53e06bb  push rcx
000076bac53e06bc  push rdx
000076bac53e06bd  push rdi
000076bac53e06be  push rsi
000076bac53e06bf  push r8
000076bac53e06c1  push r9
000076bac53e06c3  push r10
000076bac53e06c5  push r11
000076bac53e06c7  sub rsp, 0xF0
000076bac53e06ce  vmovaps [rsp], xmm0
000076bac53e06d3  vmovaps [rsp+0x10], xmm2
000076bac53e06d9  vmovaps [rsp+0x20], xmm3
000076bac53e06df  vmovaps [rsp+0x30], xmm4
000076bac53e06e5  vmovaps [rsp+0x40], xmm5
000076bac53e06eb  vmovaps [rsp+0x50], xmm6
000076bac53e06f1  vmovaps [rsp+0x60], xmm7
000076bac53e06f7  vmovaps [rsp+0x70], xmm8
000076bac53e06fd  vmovaps [rsp+0x80], xmm9
000076bac53e0706  vmovaps [rsp+0x90], xmm10
000076bac53e070f  vmovaps [rsp+0xA0], xmm11
000076bac53e0718  vmovaps [rsp+0xB0], xmm12
000076bac53e0721  vmovaps [rsp+0xC0], xmm13
000076bac53e072a  vmovaps [rsp+0xD0], xmm14
000076bac53e0733  vmovaps [rsp+0xE0], xmm15
000076bac53e073c  sub rsp, 0x30
000076bac53e0740  movaps [rsp], xmm1
000076bac53e0744  movaps [rsp+0x10], xmm6
000076bac53e0749  movaps [rsp+0x20], xmm15
000076bac53e074f  lea rdi, [rsp]
000076bac53e0753  mov esi, 0x00
000076bac53e0758  mov rax, 0x5641B0A3C530
000076bac53e0762  call rax
000076bac53e0764  movaps xmm1, [rsp]
000076bac53e0768  add rsp, 0x30
000076bac53e076c  vmovaps xmm0, [rsp]
000076bac53e0771  vmovaps xmm2, [rsp+0x10]
000076bac53e0777  vmovaps xmm3, [rsp+0x20]
000076bac53e077d  vmovaps xmm4, [rsp+0x30]
000076bac53e0783  vmovaps xmm5, [rsp+0x40]
000076bac53e0789  vmovaps xmm6, [rsp+0x50]
000076bac53e078f  vmovaps xmm7, [rsp+0x60]
000076bac53e0795  vmovaps xmm8, [rsp+0x70]
000076bac53e079b  vmovaps xmm9, [rsp+0x80]
000076bac53e07a4  vmovaps xmm10, [rsp+0x90]
000076bac53e07ad  vmovaps xmm11, [rsp+0xA0]
000076bac53e07b6  vmovaps xmm12, [rsp+0xB0]
000076bac53e07bf  vmovaps xmm13, [rsp+0xC0]
000076bac53e07c8  vmovaps xmm14, [rsp+0xD0]
000076bac53e07d1  vmovaps xmm15, [rsp+0xE0]
000076bac53e07da  add rsp, 0xF0
000076bac53e07e1  pop r11
000076bac53e07e3  pop r10
000076bac53e07e5  pop r9
000076bac53e07e7  pop r8
000076bac53e07e9  pop rsi
000076bac53e07ea  pop rdi
000076bac53e07eb  pop rdx
000076bac53e07ec  pop rcx
000076bac53e07ed  pop rax
000076bac53e07ee  add rsp, 0x08
000076bac53e07f2  jmp 0x000076BAC53DEFFB
000076bac53e07f7  call 0x000076BAC52C4620
000076bac53e07fc  jmp 0x000076BAC53DF008
000076bac53e0801  sub rsp, 0x08
000076bac53e0805  push rax
000076bac53e0806  push rcx
000076bac53e0807  push rdx
000076bac53e0808  push rdi
000076bac53e0809  push rsi
000076bac53e080a  push r8
000076bac53e080c  push r9
000076bac53e080e  push r10
000076bac53e0810  push r11
000076bac53e0812  sub rsp, 0xF0
000076bac53e0819  vmovaps [rsp], xmm0
000076bac53e081e  vmovaps [rsp+0x10], xmm1
000076bac53e0824  vmovaps [rsp+0x20], xmm2
000076bac53e082a  vmovaps [rsp+0x30], xmm3
000076bac53e0830  vmovaps [rsp+0x40], xmm4
000076bac53e0836  vmovaps [rsp+0x50], xmm5
000076bac53e083c  vmovaps [rsp+0x60], xmm6
000076bac53e0842  vmovaps [rsp+0x70], xmm7
000076bac53e0848  vmovaps [rsp+0x80], xmm8
000076bac53e0851  vmovaps [rsp+0x90], xmm9
000076bac53e085a  vmovaps [rsp+0xA0], xmm10
000076bac53e0863  vmovaps [rsp+0xB0], xmm11
000076bac53e086c  vmovaps [rsp+0xC0], xmm12
000076bac53e0875  vmovaps [rsp+0xD0], xmm13
000076bac53e087e  vmovaps [rsp+0xE0], xmm15
000076bac53e0887  sub rsp, 0x30
000076bac53e088b  movaps [rsp], xmm14
000076bac53e0890  movaps [rsp+0x10], xmm4
000076bac53e0895  movaps [rsp+0x20], xmm3
000076bac53e089a  lea rdi, [rsp]
000076bac53e089e  mov esi, 0x00
000076bac53e08a3  mov rax, 0x5641B0A3C530
000076bac53e08ad  call rax
000076bac53e08af  movaps xmm14, [rsp]
000076bac53e08b4  add rsp, 0x30
000076bac53e08b8  vmovaps xmm0, [rsp]
000076bac53e08bd  vmovaps xmm1, [rsp+0x10]
000076bac53e08c3  vmovaps xmm2, [rsp+0x20]
000076bac53e08c9  vmovaps xmm3, [rsp+0x30]
000076bac53e08cf  vmovaps xmm4, [rsp+0x40]
000076bac53e08d5  vmovaps xmm5, [rsp+0x50]
000076bac53e08db  vmovaps xmm6, [rsp+0x60]
000076bac53e08e1  vmovaps xmm7, [rsp+0x70]
000076bac53e08e7  vmovaps xmm8, [rsp+0x80]
000076bac53e08f0  vmovaps xmm9, [rsp+0x90]
000076bac53e08f9  vmovaps xmm10, [rsp+0xA0]
000076bac53e0902  vmovaps xmm11, [rsp+0xB0]
000076bac53e090b  vmovaps xmm12, [rsp+0xC0]
000076bac53e0914  vmovaps xmm13, [rsp+0xD0]
000076bac53e091d  vmovaps xmm15, [rsp+0xE0]
000076bac53e0926  add rsp, 0xF0
000076bac53e092d  pop r11
000076bac53e092f  pop r10
000076bac53e0931  pop r9
000076bac53e0933  pop r8
000076bac53e0935  pop rsi
000076bac53e0936  pop rdi
000076bac53e0937  pop rdx
000076bac53e0938  pop rcx
000076bac53e0939  pop rax
000076bac53e093a  add rsp, 0x08
000076bac53e093e  jmp 0x000076BAC53DF022
000076bac53e0943  sub rsp, 0x08
000076bac53e0947  push rax
000076bac53e0948  push rcx
000076bac53e0949  push rdx
000076bac53e094a  push rdi
000076bac53e094b  push rsi
000076bac53e094c  push r8
000076bac53e094e  push r9
000076bac53e0950  push r10
000076bac53e0952  push r11
000076bac53e0954  sub rsp, 0xF0
000076bac53e095b  vmovaps [rsp], xmm0
000076bac53e0960  vmovaps [rsp+0x10], xmm1
000076bac53e0966  vmovaps [rsp+0x20], xmm2
000076bac53e096c  vmovaps [rsp+0x30], xmm3
000076bac53e0972  vmovaps [rsp+0x40], xmm4
000076bac53e0978  vmovaps [rsp+0x50], xmm5
000076bac53e097e  vmovaps [rsp+0x60], xmm7
000076bac53e0984  vmovaps [rsp+0x70], xmm8
000076bac53e098a  vmovaps [rsp+0x80], xmm9
000076bac53e0993  vmovaps [rsp+0x90], xmm10
000076bac53e099c  vmovaps [rsp+0xA0], xmm11
000076bac53e09a5  vmovaps [rsp+0xB0], xmm12
000076bac53e09ae  vmovaps [rsp+0xC0], xmm13
000076bac53e09b7  vmovaps [rsp+0xD0], xmm14
000076bac53e09c0  vmovaps [rsp+0xE0], xmm15
000076bac53e09c9  sub rsp, 0x30
000076bac53e09cd  movaps [rsp], xmm6
000076bac53e09d1  movaps [rsp+0x10], xmm9
000076bac53e09d7  movaps [rsp+0x20], xmm7
000076bac53e09dc  lea rdi, [rsp]
000076bac53e09e0  mov esi, 0x00
000076bac53e09e5  mov rax, 0x5641B0A3C530
000076bac53e09ef  call rax
000076bac53e09f1  movaps xmm6, [rsp]
000076bac53e09f5  add rsp, 0x30
000076bac53e09f9  vmovaps xmm0, [rsp]
000076bac53e09fe  vmovaps xmm1, [rsp+0x10]
000076bac53e0a04  vmovaps xmm2, [rsp+0x20]
000076bac53e0a0a  vmovaps xmm3, [rsp+0x30]
000076bac53e0a10  vmovaps xmm4, [rsp+0x40]
000076bac53e0a16  vmovaps xmm5, [rsp+0x50]
000076bac53e0a1c  vmovaps xmm7, [rsp+0x60]
000076bac53e0a22  vmovaps xmm8, [rsp+0x70]
000076bac53e0a28  vmovaps xmm9, [rsp+0x80]
000076bac53e0a31  vmovaps xmm10, [rsp+0x90]
000076bac53e0a3a  vmovaps xmm11, [rsp+0xA0]
000076bac53e0a43  vmovaps xmm12, [rsp+0xB0]
000076bac53e0a4c  vmovaps xmm13, [rsp+0xC0]
000076bac53e0a55  vmovaps xmm14, [rsp+0xD0]
000076bac53e0a5e  vmovaps xmm15, [rsp+0xE0]
000076bac53e0a67  add rsp, 0xF0
000076bac53e0a6e  pop r11
000076bac53e0a70  pop r10
000076bac53e0a72  pop r9
000076bac53e0a74  pop r8
000076bac53e0a76  pop rsi
000076bac53e0a77  pop rdi
000076bac53e0a78  pop rdx
000076bac53e0a79  pop rcx
000076bac53e0a7a  pop rax
000076bac53e0a7b  add rsp, 0x08
000076bac53e0a7f  jmp 0x000076BAC53DF03A
000076bac53e0a84  sub rsp, 0x08
000076bac53e0a88  push rax
000076bac53e0a89  push rcx
000076bac53e0a8a  push rdx
000076bac53e0a8b  push rdi
000076bac53e0a8c  push rsi
000076bac53e0a8d  push r8
000076bac53e0a8f  push r9
000076bac53e0a91  push r10
000076bac53e0a93  push r11
000076bac53e0a95  sub rsp, 0xF0
000076bac53e0a9c  vmovaps [rsp], xmm0
000076bac53e0aa1  vmovaps [rsp+0x10], xmm1
000076bac53e0aa7  vmovaps [rsp+0x20], xmm2
000076bac53e0aad  vmovaps [rsp+0x30], xmm3
000076bac53e0ab3  vmovaps [rsp+0x40], xmm4
000076bac53e0ab9  vmovaps [rsp+0x50], xmm5
000076bac53e0abf  vmovaps [rsp+0x60], xmm6
000076bac53e0ac5  vmovaps [rsp+0x70], xmm8
000076bac53e0acb  vmovaps [rsp+0x80], xmm9
000076bac53e0ad4  vmovaps [rsp+0x90], xmm10
000076bac53e0add  vmovaps [rsp+0xA0], xmm11
000076bac53e0ae6  vmovaps [rsp+0xB0], xmm12
000076bac53e0aef  vmovaps [rsp+0xC0], xmm13
000076bac53e0af8  vmovaps [rsp+0xD0], xmm14
000076bac53e0b01  vmovaps [rsp+0xE0], xmm15
000076bac53e0b0a  sub rsp, 0x30
000076bac53e0b0e  movaps [rsp], xmm7
000076bac53e0b12  movaps [rsp+0x10], xmm4
000076bac53e0b17  movaps [rsp+0x20], xmm9
000076bac53e0b1d  lea rdi, [rsp]
000076bac53e0b21  mov esi, 0x00
000076bac53e0b26  mov rax, 0x5641B0A3C530
000076bac53e0b30  call rax
000076bac53e0b32  movaps xmm7, [rsp]
000076bac53e0b36  add rsp, 0x30
000076bac53e0b3a  vmovaps xmm0, [rsp]
000076bac53e0b3f  vmovaps xmm1, [rsp+0x10]
000076bac53e0b45  vmovaps xmm2, [rsp+0x20]
000076bac53e0b4b  vmovaps xmm3, [rsp+0x30]
000076bac53e0b51  vmovaps xmm4, [rsp+0x40]
000076bac53e0b57  vmovaps xmm5, [rsp+0x50]
000076bac53e0b5d  vmovaps xmm6, [rsp+0x60]
000076bac53e0b63  vmovaps xmm8, [rsp+0x70]
000076bac53e0b69  vmovaps xmm9, [rsp+0x80]
000076bac53e0b72  vmovaps xmm10, [rsp+0x90]
000076bac53e0b7b  vmovaps xmm11, [rsp+0xA0]
000076bac53e0b84  vmovaps xmm12, [rsp+0xB0]
000076bac53e0b8d  vmovaps xmm13, [rsp+0xC0]
000076bac53e0b96  vmovaps xmm14, [rsp+0xD0]
000076bac53e0b9f  vmovaps xmm15, [rsp+0xE0]
000076bac53e0ba8  add rsp, 0xF0
000076bac53e0baf  pop r11
000076bac53e0bb1  pop r10
000076bac53e0bb3  pop r9
000076bac53e0bb5  pop r8
000076bac53e0bb7  pop rsi
000076bac53e0bb8  pop rdi
000076bac53e0bb9  pop rdx
000076bac53e0bba  pop rcx
000076bac53e0bbb  pop rax
000076bac53e0bbc  add rsp, 0x08
000076bac53e0bc0  jmp 0x000076BAC53DF067
000076bac53e0bc5  sub rsp, 0x08
000076bac53e0bc9  push rax
000076bac53e0bca  push rcx
000076bac53e0bcb  push rdx
000076bac53e0bcc  push rdi
000076bac53e0bcd  push rsi
000076bac53e0bce  push r8
000076bac53e0bd0  push r9
000076bac53e0bd2  push r10
000076bac53e0bd4  push r11
000076bac53e0bd6  sub rsp, 0xF0
000076bac53e0bdd  vmovaps [rsp], xmm0
000076bac53e0be2  vmovaps [rsp+0x10], xmm1
000076bac53e0be8  vmovaps [rsp+0x20], xmm2
000076bac53e0bee  vmovaps [rsp+0x30], xmm3
000076bac53e0bf4  vmovaps [rsp+0x40], xmm5
000076bac53e0bfa  vmovaps [rsp+0x50], xmm6
000076bac53e0c00  vmovaps [rsp+0x60], xmm7
000076bac53e0c06  vmovaps [rsp+0x70], xmm8
000076bac53e0c0c  vmovaps [rsp+0x80], xmm9
000076bac53e0c15  vmovaps [rsp+0x90], xmm10
000076bac53e0c1e  vmovaps [rsp+0xA0], xmm11
000076bac53e0c27  vmovaps [rsp+0xB0], xmm12
000076bac53e0c30  vmovaps [rsp+0xC0], xmm13
000076bac53e0c39  vmovaps [rsp+0xD0], xmm14
000076bac53e0c42  vmovaps [rsp+0xE0], xmm15
000076bac53e0c4b  sub rsp, 0x30
000076bac53e0c4f  movaps [rsp], xmm4
000076bac53e0c53  movaps [rsp+0x10], xmm15
000076bac53e0c59  movaps [rsp+0x20], xmm9
000076bac53e0c5f  lea rdi, [rsp]
000076bac53e0c63  mov esi, 0x00
000076bac53e0c68  mov rax, 0x5641B0A3C530
000076bac53e0c72  call rax
000076bac53e0c74  movaps xmm4, [rsp]
000076bac53e0c78  add rsp, 0x30
000076bac53e0c7c  vmovaps xmm0, [rsp]
000076bac53e0c81  vmovaps xmm1, [rsp+0x10]
000076bac53e0c87  vmovaps xmm2, [rsp+0x20]
000076bac53e0c8d  vmovaps xmm3, [rsp+0x30]
000076bac53e0c93  vmovaps xmm5, [rsp+0x40]
000076bac53e0c99  vmovaps xmm6, [rsp+0x50]
000076bac53e0c9f  vmovaps xmm7, [rsp+0x60]
000076bac53e0ca5  vmovaps xmm8, [rsp+0x70]
000076bac53e0cab  vmovaps xmm9, [rsp+0x80]
000076bac53e0cb4  vmovaps xmm10, [rsp+0x90]
000076bac53e0cbd  vmovaps xmm11, [rsp+0xA0]
000076bac53e0cc6  vmovaps xmm12, [rsp+0xB0]
000076bac53e0ccf  vmovaps xmm13, [rsp+0xC0]
000076bac53e0cd8  vmovaps xmm14, [rsp+0xD0]
000076bac53e0ce1  vmovaps xmm15, [rsp+0xE0]
000076bac53e0cea  add rsp, 0xF0
000076bac53e0cf1  pop r11
000076bac53e0cf3  pop r10
000076bac53e0cf5  pop r9
000076bac53e0cf7  pop r8
000076bac53e0cf9  pop rsi
000076bac53e0cfa  pop rdi
000076bac53e0cfb  pop rdx
000076bac53e0cfc  pop rcx
000076bac53e0cfd  pop rax
000076bac53e0cfe  add rsp, 0x08
000076bac53e0d02  jmp 0x000076BAC53DF08C
000076bac53e0d07  call 0x000076BAC52C4620
000076bac53e0d0c  jmp 0x000076BAC53DF099
000076bac53e0d11  sub rsp, 0x08
000076bac53e0d15  push rax
000076bac53e0d16  push rcx
000076bac53e0d17  push rdx
000076bac53e0d18  push rdi
000076bac53e0d19  push rsi
000076bac53e0d1a  push r8
000076bac53e0d1c  push r9
000076bac53e0d1e  push r10
000076bac53e0d20  push r11
000076bac53e0d22  sub rsp, 0xF0
000076bac53e0d29  vmovaps [rsp], xmm0
000076bac53e0d2e  vmovaps [rsp+0x10], xmm1
000076bac53e0d34  vmovaps [rsp+0x20], xmm2
000076bac53e0d3a  vmovaps [rsp+0x30], xmm4
000076bac53e0d40  vmovaps [rsp+0x40], xmm5
000076bac53e0d46  vmovaps [rsp+0x50], xmm6
000076bac53e0d4c  vmovaps [rsp+0x60], xmm7
000076bac53e0d52  vmovaps [rsp+0x70], xmm8
000076bac53e0d58  vmovaps [rsp+0x80], xmm9
000076bac53e0d61  vmovaps [rsp+0x90], xmm10
000076bac53e0d6a  vmovaps [rsp+0xA0], xmm11
000076bac53e0d73  vmovaps [rsp+0xB0], xmm12
000076bac53e0d7c  vmovaps [rsp+0xC0], xmm13
000076bac53e0d85  vmovaps [rsp+0xD0], xmm14
000076bac53e0d8e  vmovaps [rsp+0xE0], xmm15
000076bac53e0d97  sub rsp, 0x30
000076bac53e0d9b  movaps [rsp], xmm3
000076bac53e0d9f  movaps [rsp+0x10], xmm1
000076bac53e0da4  movaps [rsp+0x20], xmm9
000076bac53e0daa  lea rdi, [rsp]
000076bac53e0dae  mov esi, 0x00
000076bac53e0db3  mov rax, 0x5641B0A3C530
000076bac53e0dbd  call rax
000076bac53e0dbf  movaps xmm3, [rsp]
000076bac53e0dc3  add rsp, 0x30
000076bac53e0dc7  vmovaps xmm0, [rsp]
000076bac53e0dcc  vmovaps xmm1, [rsp+0x10]
000076bac53e0dd2  vmovaps xmm2, [rsp+0x20]
000076bac53e0dd8  vmovaps xmm4, [rsp+0x30]
000076bac53e0dde  vmovaps xmm5, [rsp+0x40]
000076bac53e0de4  vmovaps xmm6, [rsp+0x50]
000076bac53e0dea  vmovaps xmm7, [rsp+0x60]
000076bac53e0df0  vmovaps xmm8, [rsp+0x70]
000076bac53e0df6  vmovaps xmm9, [rsp+0x80]
000076bac53e0dff  vmovaps xmm10, [rsp+0x90]
000076bac53e0e08  vmovaps xmm11, [rsp+0xA0]
000076bac53e0e11  vmovaps xmm12, [rsp+0xB0]
000076bac53e0e1a  vmovaps xmm13, [rsp+0xC0]
000076bac53e0e23  vmovaps xmm14, [rsp+0xD0]
000076bac53e0e2c  vmovaps xmm15, [rsp+0xE0]
000076bac53e0e35  add rsp, 0xF0
000076bac53e0e3c  pop r11
000076bac53e0e3e  pop r10
000076bac53e0e40  pop r9
000076bac53e0e42  pop r8
000076bac53e0e44  pop rsi
000076bac53e0e45  pop rdi
000076bac53e0e46  pop rdx
000076bac53e0e47  pop rcx
000076bac53e0e48  pop rax
000076bac53e0e49  add rsp, 0x08
000076bac53e0e4d  jmp 0x000076BAC53DF0D6
000076bac53e0e52  sub rsp, 0x08
000076bac53e0e56  push rax
000076bac53e0e57  push rcx
000076bac53e0e58  push rdx
000076bac53e0e59  push rdi
000076bac53e0e5a  push rsi
000076bac53e0e5b  push r8
000076bac53e0e5d  push r9
000076bac53e0e5f  push r10
000076bac53e0e61  push r11
000076bac53e0e63  sub rsp, 0xF0
000076bac53e0e6a  vmovaps [rsp], xmm0
000076bac53e0e6f  vmovaps [rsp+0x10], xmm2
000076bac53e0e75  vmovaps [rsp+0x20], xmm3
000076bac53e0e7b  vmovaps [rsp+0x30], xmm4
000076bac53e0e81  vmovaps [rsp+0x40], xmm5
000076bac53e0e87  vmovaps [rsp+0x50], xmm6
000076bac53e0e8d  vmovaps [rsp+0x60], xmm7
000076bac53e0e93  vmovaps [rsp+0x70], xmm8
000076bac53e0e99  vmovaps [rsp+0x80], xmm9
000076bac53e0ea2  vmovaps [rsp+0x90], xmm10
000076bac53e0eab  vmovaps [rsp+0xA0], xmm11
000076bac53e0eb4  vmovaps [rsp+0xB0], xmm12
000076bac53e0ebd  vmovaps [rsp+0xC0], xmm13
000076bac53e0ec6  vmovaps [rsp+0xD0], xmm14
000076bac53e0ecf  vmovaps [rsp+0xE0], xmm15
000076bac53e0ed8  sub rsp, 0x30
000076bac53e0edc  movaps [rsp], xmm1
000076bac53e0ee0  movaps [rsp+0x10], xmm15
000076bac53e0ee6  movaps [rsp+0x20], xmm9
000076bac53e0eec  lea rdi, [rsp]
000076bac53e0ef0  mov esi, 0x00
000076bac53e0ef5  mov rax, 0x5641B0A3C530
000076bac53e0eff  call rax
000076bac53e0f01  movaps xmm1, [rsp]
000076bac53e0f05  add rsp, 0x30
000076bac53e0f09  vmovaps xmm0, [rsp]
000076bac53e0f0e  vmovaps xmm2, [rsp+0x10]
000076bac53e0f14  vmovaps xmm3, [rsp+0x20]
000076bac53e0f1a  vmovaps xmm4, [rsp+0x30]
000076bac53e0f20  vmovaps xmm5, [rsp+0x40]
000076bac53e0f26  vmovaps xmm6, [rsp+0x50]
000076bac53e0f2c  vmovaps xmm7, [rsp+0x60]
000076bac53e0f32  vmovaps xmm8, [rsp+0x70]
000076bac53e0f38  vmovaps xmm9, [rsp+0x80]
000076bac53e0f41  vmovaps xmm10, [rsp+0x90]
000076bac53e0f4a  vmovaps xmm11, [rsp+0xA0]
000076bac53e0f53  vmovaps xmm12, [rsp+0xB0]
000076bac53e0f5c  vmovaps xmm13, [rsp+0xC0]
000076bac53e0f65  vmovaps xmm14, [rsp+0xD0]
000076bac53e0f6e  vmovaps xmm15, [rsp+0xE0]
000076bac53e0f77  add rsp, 0xF0
000076bac53e0f7e  pop r11
000076bac53e0f80  pop r10
000076bac53e0f82  pop r9
000076bac53e0f84  pop r8
000076bac53e0f86  pop rsi
000076bac53e0f87  pop rdi
000076bac53e0f88  pop rdx
000076bac53e0f89  pop rcx
000076bac53e0f8a  pop rax
000076bac53e0f8b  add rsp, 0x08
000076bac53e0f8f  jmp 0x000076BAC53DF15E
000076bac53e0f94  call 0x000076BAC52C4620
000076bac53e0f99  jmp 0x000076BAC53DF16B
000076bac53e0f9e  sub rsp, 0x08
000076bac53e0fa2  push rax
000076bac53e0fa3  push rcx
000076bac53e0fa4  push rdx
000076bac53e0fa5  push rdi
000076bac53e0fa6  push rsi
000076bac53e0fa7  push r8
000076bac53e0fa9  push r9
000076bac53e0fab  push r10
000076bac53e0fad  push r11
000076bac53e0faf  sub rsp, 0xF0
000076bac53e0fb6  vmovaps [rsp], xmm0
000076bac53e0fbb  vmovaps [rsp+0x10], xmm2
000076bac53e0fc1  vmovaps [rsp+0x20], xmm3
000076bac53e0fc7  vmovaps [rsp+0x30], xmm4
000076bac53e0fcd  vmovaps [rsp+0x40], xmm5
000076bac53e0fd3  vmovaps [rsp+0x50], xmm6
000076bac53e0fd9  vmovaps [rsp+0x60], xmm7
000076bac53e0fdf  vmovaps [rsp+0x70], xmm8
000076bac53e0fe5  vmovaps [rsp+0x80], xmm9
000076bac53e0fee  vmovaps [rsp+0x90], xmm10
000076bac53e0ff7  vmovaps [rsp+0xA0], xmm11
000076bac53e1000  vmovaps [rsp+0xB0], xmm12
000076bac53e1009  vmovaps [rsp+0xC0], xmm13
000076bac53e1012  vmovaps [rsp+0xD0], xmm14
000076bac53e101b  vmovaps [rsp+0xE0], xmm15
000076bac53e1024  sub rsp, 0x30
000076bac53e1028  movaps [rsp], xmm1
000076bac53e102c  movaps [rsp+0x10], xmm5
000076bac53e1031  movaps [rsp+0x20], xmm7
000076bac53e1036  lea rdi, [rsp]
000076bac53e103a  mov esi, 0x00
000076bac53e103f  mov rax, 0x5641B0A3C530
000076bac53e1049  call rax
000076bac53e104b  movaps xmm1, [rsp]
000076bac53e104f  add rsp, 0x30
000076bac53e1053  vmovaps xmm0, [rsp]
000076bac53e1058  vmovaps xmm2, [rsp+0x10]
000076bac53e105e  vmovaps xmm3, [rsp+0x20]
000076bac53e1064  vmovaps xmm4, [rsp+0x30]
000076bac53e106a  vmovaps xmm5, [rsp+0x40]
000076bac53e1070  vmovaps xmm6, [rsp+0x50]
000076bac53e1076  vmovaps xmm7, [rsp+0x60]
000076bac53e107c  vmovaps xmm8, [rsp+0x70]
000076bac53e1082  vmovaps xmm9, [rsp+0x80]
000076bac53e108b  vmovaps xmm10, [rsp+0x90]
000076bac53e1094  vmovaps xmm11, [rsp+0xA0]
000076bac53e109d  vmovaps xmm12, [rsp+0xB0]
000076bac53e10a6  vmovaps xmm13, [rsp+0xC0]
000076bac53e10af  vmovaps xmm14, [rsp+0xD0]
000076bac53e10b8  vmovaps xmm15, [rsp+0xE0]
000076bac53e10c1  add rsp, 0xF0
000076bac53e10c8  pop r11
000076bac53e10ca  pop r10
000076bac53e10cc  pop r9
000076bac53e10ce  pop r8
000076bac53e10d0  pop rsi
000076bac53e10d1  pop rdi
000076bac53e10d2  pop rdx
000076bac53e10d3  pop rcx
000076bac53e10d4  pop rax
000076bac53e10d5  add rsp, 0x08
000076bac53e10d9  jmp 0x000076BAC53DF210
000076bac53e10de  sub rsp, 0x08
000076bac53e10e2  push rax
000076bac53e10e3  push rcx
000076bac53e10e4  push rdx
000076bac53e10e5  push rdi
000076bac53e10e6  push rsi
000076bac53e10e7  push r8
000076bac53e10e9  push r9
000076bac53e10eb  push r10
000076bac53e10ed  push r11
000076bac53e10ef  sub rsp, 0xF0
000076bac53e10f6  vmovaps [rsp], xmm0
000076bac53e10fb  vmovaps [rsp+0x10], xmm1
000076bac53e1101  vmovaps [rsp+0x20], xmm2
000076bac53e1107  vmovaps [rsp+0x30], xmm3
000076bac53e110d  vmovaps [rsp+0x40], xmm4
000076bac53e1113  vmovaps [rsp+0x50], xmm5
000076bac53e1119  vmovaps [rsp+0x60], xmm6
000076bac53e111f  vmovaps [rsp+0x70], xmm8
000076bac53e1125  vmovaps [rsp+0x80], xmm9
000076bac53e112e  vmovaps [rsp+0x90], xmm10
000076bac53e1137  vmovaps [rsp+0xA0], xmm11
000076bac53e1140  vmovaps [rsp+0xB0], xmm12
000076bac53e1149  vmovaps [rsp+0xC0], xmm13
000076bac53e1152  vmovaps [rsp+0xD0], xmm14
000076bac53e115b  vmovaps [rsp+0xE0], xmm15
000076bac53e1164  sub rsp, 0x30
000076bac53e1168  movaps [rsp], xmm7
000076bac53e116c  movaps [rsp+0x10], xmm5
000076bac53e1171  movaps [rsp+0x20], xmm15
000076bac53e1177  lea rdi, [rsp]
000076bac53e117b  mov esi, 0x00
000076bac53e1180  mov rax, 0x5641B0A3C530
000076bac53e118a  call rax
000076bac53e118c  movaps xmm7, [rsp]
000076bac53e1190  add rsp, 0x30
000076bac53e1194  vmovaps xmm0, [rsp]
000076bac53e1199  vmovaps xmm1, [rsp+0x10]
000076bac53e119f  vmovaps xmm2, [rsp+0x20]
000076bac53e11a5  vmovaps xmm3, [rsp+0x30]
000076bac53e11ab  vmovaps xmm4, [rsp+0x40]
000076bac53e11b1  vmovaps xmm5, [rsp+0x50]
000076bac53e11b7  vmovaps xmm6, [rsp+0x60]
000076bac53e11bd  vmovaps xmm8, [rsp+0x70]
000076bac53e11c3  vmovaps xmm9, [rsp+0x80]
000076bac53e11cc  vmovaps xmm10, [rsp+0x90]
000076bac53e11d5  vmovaps xmm11, [rsp+0xA0]
000076bac53e11de  vmovaps xmm12, [rsp+0xB0]
000076bac53e11e7  vmovaps xmm13, [rsp+0xC0]
000076bac53e11f0  vmovaps xmm14, [rsp+0xD0]
000076bac53e11f9  vmovaps xmm15, [rsp+0xE0]
000076bac53e1202  add rsp, 0xF0
000076bac53e1209  pop r11
000076bac53e120b  pop r10
000076bac53e120d  pop r9
000076bac53e120f  pop r8
000076bac53e1211  pop rsi
000076bac53e1212  pop rdi
000076bac53e1213  pop rdx
000076bac53e1214  pop rcx
000076bac53e1215  pop rax
000076bac53e1216  add rsp, 0x08
000076bac53e121a  jmp 0x000076BAC53DF246
000076bac53e121f  call 0x000076BAC52B52F0
000076bac53e1224  jmp 0x000076BAC53DF253
000076bac53e1229  sub rsp, 0x08
000076bac53e122d  push rax
000076bac53e122e  push rcx
000076bac53e122f  push rdx
000076bac53e1230  push rdi
000076bac53e1231  push rsi
000076bac53e1232  push r8
000076bac53e1234  push r9
000076bac53e1236  push r10
000076bac53e1238  push r11
000076bac53e123a  sub rsp, 0xF0
000076bac53e1241  vmovaps [rsp], xmm0
000076bac53e1246  vmovaps [rsp+0x10], xmm1
000076bac53e124c  vmovaps [rsp+0x20], xmm2
000076bac53e1252  vmovaps [rsp+0x30], xmm3
000076bac53e1258  vmovaps [rsp+0x40], xmm4
000076bac53e125e  vmovaps [rsp+0x50], xmm5
000076bac53e1264  vmovaps [rsp+0x60], xmm6
000076bac53e126a  vmovaps [rsp+0x70], xmm7
000076bac53e1270  vmovaps [rsp+0x80], xmm8
000076bac53e1279  vmovaps [rsp+0x90], xmm9
000076bac53e1282  vmovaps [rsp+0xA0], xmm10
000076bac53e128b  vmovaps [rsp+0xB0], xmm11
000076bac53e1294  vmovaps [rsp+0xC0], xmm12
000076bac53e129d  vmovaps [rsp+0xD0], xmm13
000076bac53e12a6  vmovaps [rsp+0xE0], xmm14
000076bac53e12af  sub rsp, 0x30
000076bac53e12b3  movaps [rsp], xmm15
000076bac53e12b8  movaps [rsp+0x10], xmm5
000076bac53e12bd  movaps [rsp+0x20], xmm3
000076bac53e12c2  lea rdi, [rsp]
000076bac53e12c6  mov esi, 0x00
000076bac53e12cb  mov rax, 0x5641B0A3C530
000076bac53e12d5  call rax
000076bac53e12d7  movaps xmm15, [rsp]
000076bac53e12dc  add rsp, 0x30
000076bac53e12e0  vmovaps xmm0, [rsp]
000076bac53e12e5  vmovaps xmm1, [rsp+0x10]
000076bac53e12eb  vmovaps xmm2, [rsp+0x20]
000076bac53e12f1  vmovaps xmm3, [rsp+0x30]
000076bac53e12f7  vmovaps xmm4, [rsp+0x40]
000076bac53e12fd  vmovaps xmm5, [rsp+0x50]
000076bac53e1303  vmovaps xmm6, [rsp+0x60]
000076bac53e1309  vmovaps xmm7, [rsp+0x70]
000076bac53e130f  vmovaps xmm8, [rsp+0x80]
000076bac53e1318  vmovaps xmm9, [rsp+0x90]
000076bac53e1321  vmovaps xmm10, [rsp+0xA0]
000076bac53e132a  vmovaps xmm11, [rsp+0xB0]
000076bac53e1333  vmovaps xmm12, [rsp+0xC0]
000076bac53e133c  vmovaps xmm13, [rsp+0xD0]
000076bac53e1345  vmovaps xmm14, [rsp+0xE0]
000076bac53e134e  add rsp, 0xF0
000076bac53e1355  pop r11
000076bac53e1357  pop r10
000076bac53e1359  pop r9
000076bac53e135b  pop r8
000076bac53e135d  pop rsi
000076bac53e135e  pop rdi
000076bac53e135f  pop rdx
000076bac53e1360  pop rcx
000076bac53e1361  pop rax
000076bac53e1362  add rsp, 0x08
000076bac53e1366  jmp 0x000076BAC53DF279
000076bac53e136b  sub rsp, 0x08
000076bac53e136f  push rax
000076bac53e1370  push rcx
000076bac53e1371  push rdx
000076bac53e1372  push rdi
000076bac53e1373  push rsi
000076bac53e1374  push r8
000076bac53e1376  push r9
000076bac53e1378  push r10
000076bac53e137a  push r11
000076bac53e137c  sub rsp, 0xF0
000076bac53e1383  vmovaps [rsp], xmm0
000076bac53e1388  vmovaps [rsp+0x10], xmm2
000076bac53e138e  vmovaps [rsp+0x20], xmm3
000076bac53e1394  vmovaps [rsp+0x30], xmm4
000076bac53e139a  vmovaps [rsp+0x40], xmm5
000076bac53e13a0  vmovaps [rsp+0x50], xmm6
000076bac53e13a6  vmovaps [rsp+0x60], xmm7
000076bac53e13ac  vmovaps [rsp+0x70], xmm8
000076bac53e13b2  vmovaps [rsp+0x80], xmm9
000076bac53e13bb  vmovaps [rsp+0x90], xmm10
000076bac53e13c4  vmovaps [rsp+0xA0], xmm11
000076bac53e13cd  vmovaps [rsp+0xB0], xmm12
000076bac53e13d6  vmovaps [rsp+0xC0], xmm13
000076bac53e13df  vmovaps [rsp+0xD0], xmm14
000076bac53e13e8  vmovaps [rsp+0xE0], xmm15
000076bac53e13f1  sub rsp, 0x30
000076bac53e13f5  movaps [rsp], xmm1
000076bac53e13f9  movaps [rsp+0x10], xmm5
000076bac53e13fe  movaps [rsp+0x20], xmm4
000076bac53e1403  lea rdi, [rsp]
000076bac53e1407  mov esi, 0x00
000076bac53e140c  mov rax, 0x5641B0A3C530
000076bac53e1416  call rax
000076bac53e1418  movaps xmm1, [rsp]
000076bac53e141c  add rsp, 0x30
000076bac53e1420  vmovaps xmm0, [rsp]
000076bac53e1425  vmovaps xmm2, [rsp+0x10]
000076bac53e142b  vmovaps xmm3, [rsp+0x20]
000076bac53e1431  vmovaps xmm4, [rsp+0x30]
000076bac53e1437  vmovaps xmm5, [rsp+0x40]
000076bac53e143d  vmovaps xmm6, [rsp+0x50]
000076bac53e1443  vmovaps xmm7, [rsp+0x60]
000076bac53e1449  vmovaps xmm8, [rsp+0x70]
000076bac53e144f  vmovaps xmm9, [rsp+0x80]
000076bac53e1458  vmovaps xmm10, [rsp+0x90]
000076bac53e1461  vmovaps xmm11, [rsp+0xA0]
000076bac53e146a  vmovaps xmm12, [rsp+0xB0]
000076bac53e1473  vmovaps xmm13, [rsp+0xC0]
000076bac53e147c  vmovaps xmm14, [rsp+0xD0]
000076bac53e1485  vmovaps xmm15, [rsp+0xE0]
000076bac53e148e  add rsp, 0xF0
000076bac53e1495  pop r11
000076bac53e1497  pop r10
000076bac53e1499  pop r9
000076bac53e149b  pop r8
000076bac53e149d  pop rsi
000076bac53e149e  pop rdi
000076bac53e149f  pop rdx
000076bac53e14a0  pop rcx
000076bac53e14a1  pop rax
000076bac53e14a2  add rsp, 0x08
000076bac53e14a6  jmp 0x000076BAC53DF299
000076bac53e14ab  sub rsp, 0x08
000076bac53e14af  push rax
000076bac53e14b0  push rcx
000076bac53e14b1  push rdx
000076bac53e14b2  push rdi
000076bac53e14b3  push rsi
000076bac53e14b4  push r8
000076bac53e14b6  push r9
000076bac53e14b8  push r10
000076bac53e14ba  push r11
000076bac53e14bc  sub rsp, 0xF0
000076bac53e14c3  vmovaps [rsp], xmm0
000076bac53e14c8  vmovaps [rsp+0x10], xmm1
000076bac53e14ce  vmovaps [rsp+0x20], xmm2
000076bac53e14d4  vmovaps [rsp+0x30], xmm3
000076bac53e14da  vmovaps [rsp+0x40], xmm5
000076bac53e14e0  vmovaps [rsp+0x50], xmm6
000076bac53e14e6  vmovaps [rsp+0x60], xmm7
000076bac53e14ec  vmovaps [rsp+0x70], xmm8
000076bac53e14f2  vmovaps [rsp+0x80], xmm9
000076bac53e14fb  vmovaps [rsp+0x90], xmm10
000076bac53e1504  vmovaps [rsp+0xA0], xmm11
000076bac53e150d  vmovaps [rsp+0xB0], xmm12
000076bac53e1516  vmovaps [rsp+0xC0], xmm13
000076bac53e151f  vmovaps [rsp+0xD0], xmm14
000076bac53e1528  vmovaps [rsp+0xE0], xmm15
000076bac53e1531  sub rsp, 0x30
000076bac53e1535  movaps [rsp], xmm4
000076bac53e1539  movaps [rsp+0x10], xmm3
000076bac53e153e  movaps [rsp+0x20], xmm5
000076bac53e1543  lea rdi, [rsp]
000076bac53e1547  mov esi, 0x00
000076bac53e154c  mov rax, 0x5641B0A3C530
000076bac53e1556  call rax
000076bac53e1558  movaps xmm4, [rsp]
000076bac53e155c  add rsp, 0x30
000076bac53e1560  vmovaps xmm0, [rsp]
000076bac53e1565  vmovaps xmm1, [rsp+0x10]
000076bac53e156b  vmovaps xmm2, [rsp+0x20]
000076bac53e1571  vmovaps xmm3, [rsp+0x30]
000076bac53e1577  vmovaps xmm5, [rsp+0x40]
000076bac53e157d  vmovaps xmm6, [rsp+0x50]
000076bac53e1583  vmovaps xmm7, [rsp+0x60]
000076bac53e1589  vmovaps xmm8, [rsp+0x70]
000076bac53e158f  vmovaps xmm9, [rsp+0x80]
000076bac53e1598  vmovaps xmm10, [rsp+0x90]
000076bac53e15a1  vmovaps xmm11, [rsp+0xA0]
000076bac53e15aa  vmovaps xmm12, [rsp+0xB0]
000076bac53e15b3  vmovaps xmm13, [rsp+0xC0]
000076bac53e15bc  vmovaps xmm14, [rsp+0xD0]
000076bac53e15c5  vmovaps xmm15, [rsp+0xE0]
000076bac53e15ce  add rsp, 0xF0
000076bac53e15d5  pop r11
000076bac53e15d7  pop r10
000076bac53e15d9  pop r9
000076bac53e15db  pop r8
000076bac53e15dd  pop rsi
000076bac53e15de  pop rdi
000076bac53e15df  pop rdx
000076bac53e15e0  pop rcx
000076bac53e15e1  pop rax
000076bac53e15e2  add rsp, 0x08
000076bac53e15e6  jmp 0x000076BAC53DF2E7
000076bac53e15eb  call 0x000076BAC52B52F0
000076bac53e15f0  jmp 0x000076BAC53DF2F4
000076bac53e15f5  sub rsp, 0x08
000076bac53e15f9  push rax
000076bac53e15fa  push rcx
000076bac53e15fb  push rdx
000076bac53e15fc  push rdi
000076bac53e15fd  push rsi
000076bac53e15fe  push r8
000076bac53e1600  push r9
000076bac53e1602  push r10
000076bac53e1604  push r11
000076bac53e1606  sub rsp, 0xF0
000076bac53e160d  vmovaps [rsp], xmm0
000076bac53e1612  vmovaps [rsp+0x10], xmm1
000076bac53e1618  vmovaps [rsp+0x20], xmm2
000076bac53e161e  vmovaps [rsp+0x30], xmm3
000076bac53e1624  vmovaps [rsp+0x40], xmm4
000076bac53e162a  vmovaps [rsp+0x50], xmm6
000076bac53e1630  vmovaps [rsp+0x60], xmm7
000076bac53e1636  vmovaps [rsp+0x70], xmm8
000076bac53e163c  vmovaps [rsp+0x80], xmm9
000076bac53e1645  vmovaps [rsp+0x90], xmm10
000076bac53e164e  vmovaps [rsp+0xA0], xmm11
000076bac53e1657  vmovaps [rsp+0xB0], xmm12
000076bac53e1660  vmovaps [rsp+0xC0], xmm13
000076bac53e1669  vmovaps [rsp+0xD0], xmm14
000076bac53e1672  vmovaps [rsp+0xE0], xmm15
000076bac53e167b  sub rsp, 0x30
000076bac53e167f  movaps [rsp], xmm5
000076bac53e1683  movaps [rsp+0x10], xmm6
000076bac53e1688  movaps [rsp+0x20], xmm3
000076bac53e168d  lea rdi, [rsp]
000076bac53e1691  mov esi, 0x00
000076bac53e1696  mov rax, 0x5641B0A3C530
000076bac53e16a0  call rax
000076bac53e16a2  movaps xmm5, [rsp]
000076bac53e16a6  add rsp, 0x30
000076bac53e16aa  vmovaps xmm0, [rsp]
000076bac53e16af  vmovaps xmm1, [rsp+0x10]
000076bac53e16b5  vmovaps xmm2, [rsp+0x20]
000076bac53e16bb  vmovaps xmm3, [rsp+0x30]
000076bac53e16c1  vmovaps xmm4, [rsp+0x40]
000076bac53e16c7  vmovaps xmm6, [rsp+0x50]
000076bac53e16cd  vmovaps xmm7, [rsp+0x60]
000076bac53e16d3  vmovaps xmm8, [rsp+0x70]
000076bac53e16d9  vmovaps xmm9, [rsp+0x80]
000076bac53e16e2  vmovaps xmm10, [rsp+0x90]
000076bac53e16eb  vmovaps xmm11, [rsp+0xA0]
000076bac53e16f4  vmovaps xmm12, [rsp+0xB0]
000076bac53e16fd  vmovaps xmm13, [rsp+0xC0]
000076bac53e1706  vmovaps xmm14, [rsp+0xD0]
000076bac53e170f  vmovaps xmm15, [rsp+0xE0]
000076bac53e1718  add rsp, 0xF0
000076bac53e171f  pop r11
000076bac53e1721  pop r10
000076bac53e1723  pop r9
000076bac53e1725  pop r8
000076bac53e1727  pop rsi
000076bac53e1728  pop rdi
000076bac53e1729  pop rdx
000076bac53e172a  pop rcx
000076bac53e172b  pop rax
000076bac53e172c  add rsp, 0x08
000076bac53e1730  jmp 0x000076BAC53DF31A
000076bac53e1735  sub rsp, 0x08
000076bac53e1739  push rax
000076bac53e173a  push rcx
000076bac53e173b  push rdx
000076bac53e173c  push rdi
000076bac53e173d  push rsi
000076bac53e173e  push r8
000076bac53e1740  push r9
000076bac53e1742  push r10
000076bac53e1744  push r11
000076bac53e1746  sub rsp, 0xF0
000076bac53e174d  vmovaps [rsp], xmm0
000076bac53e1752  vmovaps [rsp+0x10], xmm1
000076bac53e1758  vmovaps [rsp+0x20], xmm2
000076bac53e175e  vmovaps [rsp+0x30], xmm3
000076bac53e1764  vmovaps [rsp+0x40], xmm4
000076bac53e176a  vmovaps [rsp+0x50], xmm5
000076bac53e1770  vmovaps [rsp+0x60], xmm7
000076bac53e1776  vmovaps [rsp+0x70], xmm8
000076bac53e177c  vmovaps [rsp+0x80], xmm9
000076bac53e1785  vmovaps [rsp+0x90], xmm10
000076bac53e178e  vmovaps [rsp+0xA0], xmm11
000076bac53e1797  vmovaps [rsp+0xB0], xmm12
000076bac53e17a0  vmovaps [rsp+0xC0], xmm13
000076bac53e17a9  vmovaps [rsp+0xD0], xmm14
000076bac53e17b2  vmovaps [rsp+0xE0], xmm15
000076bac53e17bb  sub rsp, 0x30
000076bac53e17bf  movaps [rsp], xmm6
000076bac53e17c3  movaps [rsp+0x10], xmm9
000076bac53e17c9  movaps [rsp+0x20], xmm1
000076bac53e17ce  lea rdi, [rsp]
000076bac53e17d2  mov esi, 0x00
000076bac53e17d7  mov rax, 0x5641B0A3C530
000076bac53e17e1  call rax
000076bac53e17e3  movaps xmm6, [rsp]
000076bac53e17e7  add rsp, 0x30
000076bac53e17eb  vmovaps xmm0, [rsp]
000076bac53e17f0  vmovaps xmm1, [rsp+0x10]
000076bac53e17f6  vmovaps xmm2, [rsp+0x20]
000076bac53e17fc  vmovaps xmm3, [rsp+0x30]
000076bac53e1802  vmovaps xmm4, [rsp+0x40]
000076bac53e1808  vmovaps xmm5, [rsp+0x50]
000076bac53e180e  vmovaps xmm7, [rsp+0x60]
000076bac53e1814  vmovaps xmm8, [rsp+0x70]
000076bac53e181a  vmovaps xmm9, [rsp+0x80]
000076bac53e1823  vmovaps xmm10, [rsp+0x90]
000076bac53e182c  vmovaps xmm11, [rsp+0xA0]
000076bac53e1835  vmovaps xmm12, [rsp+0xB0]
000076bac53e183e  vmovaps xmm13, [rsp+0xC0]
000076bac53e1847  vmovaps xmm14, [rsp+0xD0]
000076bac53e1850  vmovaps xmm15, [rsp+0xE0]
000076bac53e1859  add rsp, 0xF0
000076bac53e1860  pop r11
000076bac53e1862  pop r10
000076bac53e1864  pop r9
000076bac53e1866  pop r8
000076bac53e1868  pop rsi
000076bac53e1869  pop rdi
000076bac53e186a  pop rdx
000076bac53e186b  pop rcx
000076bac53e186c  pop rax
000076bac53e186d  add rsp, 0x08
000076bac53e1871  jmp 0x000076BAC53DF33E
000076bac53e1876  sub rsp, 0x08
000076bac53e187a  push rax
000076bac53e187b  push rcx
000076bac53e187c  push rdx
000076bac53e187d  push rdi
000076bac53e187e  push rsi
000076bac53e187f  push r8
000076bac53e1881  push r9
000076bac53e1883  push r10
000076bac53e1885  push r11
000076bac53e1887  sub rsp, 0xF0
000076bac53e188e  vmovaps [rsp], xmm0
000076bac53e1893  vmovaps [rsp+0x10], xmm1
000076bac53e1899  vmovaps [rsp+0x20], xmm2
000076bac53e189f  vmovaps [rsp+0x30], xmm3
000076bac53e18a5  vmovaps [rsp+0x40], xmm4
000076bac53e18ab  vmovaps [rsp+0x50], xmm5
000076bac53e18b1  vmovaps [rsp+0x60], xmm6
000076bac53e18b7  vmovaps [rsp+0x70], xmm7
000076bac53e18bd  vmovaps [rsp+0x80], xmm8
000076bac53e18c6  vmovaps [rsp+0x90], xmm10
000076bac53e18cf  vmovaps [rsp+0xA0], xmm11
000076bac53e18d8  vmovaps [rsp+0xB0], xmm12
000076bac53e18e1  vmovaps [rsp+0xC0], xmm13
000076bac53e18ea  vmovaps [rsp+0xD0], xmm14
000076bac53e18f3  vmovaps [rsp+0xE0], xmm15
000076bac53e18fc  sub rsp, 0x30
000076bac53e1900  movaps [rsp], xmm9
000076bac53e1905  movaps [rsp+0x10], xmm3
000076bac53e190a  movaps [rsp+0x20], xmm1
000076bac53e190f  lea rdi, [rsp]
000076bac53e1913  mov esi, 0x00
000076bac53e1918  mov rax, 0x5641B0A3C530
000076bac53e1922  call rax
000076bac53e1924  movaps xmm9, [rsp]
000076bac53e1929  add rsp, 0x30
000076bac53e192d  vmovaps xmm0, [rsp]
000076bac53e1932  vmovaps xmm1, [rsp+0x10]
000076bac53e1938  vmovaps xmm2, [rsp+0x20]
000076bac53e193e  vmovaps xmm3, [rsp+0x30]
000076bac53e1944  vmovaps xmm4, [rsp+0x40]
000076bac53e194a  vmovaps xmm5, [rsp+0x50]
000076bac53e1950  vmovaps xmm6, [rsp+0x60]
000076bac53e1956  vmovaps xmm7, [rsp+0x70]
000076bac53e195c  vmovaps xmm8, [rsp+0x80]
000076bac53e1965  vmovaps xmm10, [rsp+0x90]
000076bac53e196e  vmovaps xmm11, [rsp+0xA0]
000076bac53e1977  vmovaps xmm12, [rsp+0xB0]
000076bac53e1980  vmovaps xmm13, [rsp+0xC0]
000076bac53e1989  vmovaps xmm14, [rsp+0xD0]
000076bac53e1992  vmovaps xmm15, [rsp+0xE0]
000076bac53e199b  add rsp, 0xF0
000076bac53e19a2  pop r11
000076bac53e19a4  pop r10
000076bac53e19a6  pop r9
000076bac53e19a8  pop r8
000076bac53e19aa  pop rsi
000076bac53e19ab  pop rdi
000076bac53e19ac  pop rdx
000076bac53e19ad  pop rcx
000076bac53e19ae  pop rax
000076bac53e19af  add rsp, 0x08
000076bac53e19b3  jmp 0x000076BAC53DF38A
000076bac53e19b8  call 0x000076BAC52B52F0
000076bac53e19bd  jmp 0x000076BAC53DF397
000076bac53e19c2  sub rsp, 0x08
000076bac53e19c6  push rax
000076bac53e19c7  push rcx
000076bac53e19c8  push rdx
000076bac53e19c9  push rdi
000076bac53e19ca  push rsi
000076bac53e19cb  push r8
000076bac53e19cd  push r9
000076bac53e19cf  push r10
000076bac53e19d1  push r11
000076bac53e19d3  sub rsp, 0xF0
000076bac53e19da  vmovaps [rsp], xmm0
000076bac53e19df  vmovaps [rsp+0x10], xmm1
000076bac53e19e5  vmovaps [rsp+0x20], xmm2
000076bac53e19eb  vmovaps [rsp+0x30], xmm3
000076bac53e19f1  vmovaps [rsp+0x40], xmm4
000076bac53e19f7  vmovaps [rsp+0x50], xmm5
000076bac53e19fd  vmovaps [rsp+0x60], xmm6
000076bac53e1a03  vmovaps [rsp+0x70], xmm7
000076bac53e1a09  vmovaps [rsp+0x80], xmm8
000076bac53e1a12  vmovaps [rsp+0x90], xmm9
000076bac53e1a1b  vmovaps [rsp+0xA0], xmm10
000076bac53e1a24  vmovaps [rsp+0xB0], xmm11
000076bac53e1a2d  vmovaps [rsp+0xC0], xmm12
000076bac53e1a36  vmovaps [rsp+0xD0], xmm13
000076bac53e1a3f  vmovaps [rsp+0xE0], xmm14
000076bac53e1a48  sub rsp, 0x30
000076bac53e1a4c  movaps [rsp], xmm15
000076bac53e1a51  movaps [rsp+0x10], xmm3
000076bac53e1a56  movaps [rsp+0x20], xmm7
000076bac53e1a5b  lea rdi, [rsp]
000076bac53e1a5f  mov esi, 0x00
000076bac53e1a64  mov rax, 0x5641B0A3C530
000076bac53e1a6e  call rax
000076bac53e1a70  movaps xmm15, [rsp]
000076bac53e1a75  add rsp, 0x30
000076bac53e1a79  vmovaps xmm0, [rsp]
000076bac53e1a7e  vmovaps xmm1, [rsp+0x10]
000076bac53e1a84  vmovaps xmm2, [rsp+0x20]
000076bac53e1a8a  vmovaps xmm3, [rsp+0x30]
000076bac53e1a90  vmovaps xmm4, [rsp+0x40]
000076bac53e1a96  vmovaps xmm5, [rsp+0x50]
000076bac53e1a9c  vmovaps xmm6, [rsp+0x60]
000076bac53e1aa2  vmovaps xmm7, [rsp+0x70]
000076bac53e1aa8  vmovaps xmm8, [rsp+0x80]
000076bac53e1ab1  vmovaps xmm9, [rsp+0x90]
000076bac53e1aba  vmovaps xmm10, [rsp+0xA0]
000076bac53e1ac3  vmovaps xmm11, [rsp+0xB0]
000076bac53e1acc  vmovaps xmm12, [rsp+0xC0]
000076bac53e1ad5  vmovaps xmm13, [rsp+0xD0]
000076bac53e1ade  vmovaps xmm14, [rsp+0xE0]
000076bac53e1ae7  add rsp, 0xF0
000076bac53e1aee  pop r11
000076bac53e1af0  pop r10
000076bac53e1af2  pop r9
000076bac53e1af4  pop r8
000076bac53e1af6  pop rsi
000076bac53e1af7  pop rdi
000076bac53e1af8  pop rdx
000076bac53e1af9  pop rcx
000076bac53e1afa  pop rax
000076bac53e1afb  add rsp, 0x08
000076bac53e1aff  jmp 0x000076BAC53DF3C3
000076bac53e1b04  sub rsp, 0x08
000076bac53e1b08  push rax
000076bac53e1b09  push rcx
000076bac53e1b0a  push rdx
000076bac53e1b0b  push rdi
000076bac53e1b0c  push rsi
000076bac53e1b0d  push r8
000076bac53e1b0f  push r9
000076bac53e1b11  push r10
000076bac53e1b13  push r11
000076bac53e1b15  sub rsp, 0xF0
000076bac53e1b1c  vmovaps [rsp], xmm0
000076bac53e1b21  vmovaps [rsp+0x10], xmm1
000076bac53e1b27  vmovaps [rsp+0x20], xmm2
000076bac53e1b2d  vmovaps [rsp+0x30], xmm4
000076bac53e1b33  vmovaps [rsp+0x40], xmm5
000076bac53e1b39  vmovaps [rsp+0x50], xmm6
000076bac53e1b3f  vmovaps [rsp+0x60], xmm7
000076bac53e1b45  vmovaps [rsp+0x70], xmm8
000076bac53e1b4b  vmovaps [rsp+0x80], xmm9
000076bac53e1b54  vmovaps [rsp+0x90], xmm10
000076bac53e1b5d  vmovaps [rsp+0xA0], xmm11
000076bac53e1b66  vmovaps [rsp+0xB0], xmm12
000076bac53e1b6f  vmovaps [rsp+0xC0], xmm13
000076bac53e1b78  vmovaps [rsp+0xD0], xmm14
000076bac53e1b81  vmovaps [rsp+0xE0], xmm15
000076bac53e1b8a  sub rsp, 0x30
000076bac53e1b8e  movaps [rsp], xmm3
000076bac53e1b92  movaps [rsp+0x10], xmm1
000076bac53e1b97  movaps [rsp+0x20], xmm15
000076bac53e1b9d  lea rdi, [rsp]
000076bac53e1ba1  mov esi, 0x00
000076bac53e1ba6  mov rax, 0x5641B0A3C530
000076bac53e1bb0  call rax
000076bac53e1bb2  movaps xmm3, [rsp]
000076bac53e1bb6  add rsp, 0x30
000076bac53e1bba  vmovaps xmm0, [rsp]
000076bac53e1bbf  vmovaps xmm1, [rsp+0x10]
000076bac53e1bc5  vmovaps xmm2, [rsp+0x20]
000076bac53e1bcb  vmovaps xmm4, [rsp+0x30]
000076bac53e1bd1  vmovaps xmm5, [rsp+0x40]
000076bac53e1bd7  vmovaps xmm6, [rsp+0x50]
000076bac53e1bdd  vmovaps xmm7, [rsp+0x60]
000076bac53e1be3  vmovaps xmm8, [rsp+0x70]
000076bac53e1be9  vmovaps xmm9, [rsp+0x80]
000076bac53e1bf2  vmovaps xmm10, [rsp+0x90]
000076bac53e1bfb  vmovaps xmm11, [rsp+0xA0]
000076bac53e1c04  vmovaps xmm12, [rsp+0xB0]
000076bac53e1c0d  vmovaps xmm13, [rsp+0xC0]
000076bac53e1c16  vmovaps xmm14, [rsp+0xD0]
000076bac53e1c1f  vmovaps xmm15, [rsp+0xE0]
000076bac53e1c28  add rsp, 0xF0
000076bac53e1c2f  pop r11
000076bac53e1c31  pop r10
000076bac53e1c33  pop r9
000076bac53e1c35  pop r8
000076bac53e1c37  pop rsi
000076bac53e1c38  pop rdi
000076bac53e1c39  pop rdx
000076bac53e1c3a  pop rcx
000076bac53e1c3b  pop rax
000076bac53e1c3c  add rsp, 0x08
000076bac53e1c40  jmp 0x000076BAC53DF452
000076bac53e1c45  call 0x000076BAC52B52F0
000076bac53e1c4a  jmp 0x000076BAC53DF45C
000076bac53e1c4f  sub rsp, 0x08
000076bac53e1c53  push rax
000076bac53e1c54  push rcx
000076bac53e1c55  push rdx
000076bac53e1c56  push rdi
000076bac53e1c57  push rsi
000076bac53e1c58  push r8
000076bac53e1c5a  push r9
000076bac53e1c5c  push r10
000076bac53e1c5e  push r11
000076bac53e1c60  sub rsp, 0xF0
000076bac53e1c67  vmovaps [rsp], xmm0
000076bac53e1c6c  vmovaps [rsp+0x10], xmm1
000076bac53e1c72  vmovaps [rsp+0x20], xmm2
000076bac53e1c78  vmovaps [rsp+0x30], xmm3
000076bac53e1c7e  vmovaps [rsp+0x40], xmm4
000076bac53e1c84  vmovaps [rsp+0x50], xmm5
000076bac53e1c8a  vmovaps [rsp+0x60], xmm6
000076bac53e1c90  vmovaps [rsp+0x70], xmm7
000076bac53e1c96  vmovaps [rsp+0x80], xmm8
000076bac53e1c9f  vmovaps [rsp+0x90], xmm9
000076bac53e1ca8  vmovaps [rsp+0xA0], xmm10
000076bac53e1cb1  vmovaps [rsp+0xB0], xmm11
000076bac53e1cba  vmovaps [rsp+0xC0], xmm12
000076bac53e1cc3  vmovaps [rsp+0xD0], xmm13
000076bac53e1ccc  vmovaps [rsp+0xE0], xmm14
000076bac53e1cd5  sub rsp, 0x30
000076bac53e1cd9  movaps [rsp], xmm15
000076bac53e1cde  movaps [rsp+0x10], xmm14
000076bac53e1ce4  movaps [rsp+0x20], xmm4
000076bac53e1ce9  lea rdi, [rsp]
000076bac53e1ced  mov esi, 0x00
000076bac53e1cf2  mov rax, 0x5641B0A3C530
000076bac53e1cfc  call rax
000076bac53e1cfe  movaps xmm15, [rsp]
000076bac53e1d03  add rsp, 0x30
000076bac53e1d07  vmovaps xmm0, [rsp]
000076bac53e1d0c  vmovaps xmm1, [rsp+0x10]
000076bac53e1d12  vmovaps xmm2, [rsp+0x20]
000076bac53e1d18  vmovaps xmm3, [rsp+0x30]
000076bac53e1d1e  vmovaps xmm4, [rsp+0x40]
000076bac53e1d24  vmovaps xmm5, [rsp+0x50]
000076bac53e1d2a  vmovaps xmm6, [rsp+0x60]
000076bac53e1d30  vmovaps xmm7, [rsp+0x70]
000076bac53e1d36  vmovaps xmm8, [rsp+0x80]
000076bac53e1d3f  vmovaps xmm9, [rsp+0x90]
000076bac53e1d48  vmovaps xmm10, [rsp+0xA0]
000076bac53e1d51  vmovaps xmm11, [rsp+0xB0]
000076bac53e1d5a  vmovaps xmm12, [rsp+0xC0]
000076bac53e1d63  vmovaps xmm13, [rsp+0xD0]
000076bac53e1d6c  vmovaps xmm14, [rsp+0xE0]
000076bac53e1d75  add rsp, 0xF0
000076bac53e1d7c  pop r11
000076bac53e1d7e  pop r10
000076bac53e1d80  pop r9
000076bac53e1d82  pop r8
000076bac53e1d84  pop rsi
000076bac53e1d85  pop rdi
000076bac53e1d86  pop rdx
000076bac53e1d87  pop rcx
000076bac53e1d88  pop rax
000076bac53e1d89  add rsp, 0x08
000076bac53e1d8d  jmp 0x000076BAC53DF48A
000076bac53e1d92  sub rsp, 0x08
000076bac53e1d96  push rax
000076bac53e1d97  push rcx
000076bac53e1d98  push rdx
000076bac53e1d99  push rdi
000076bac53e1d9a  push rsi
000076bac53e1d9b  push r8
000076bac53e1d9d  push r9
000076bac53e1d9f  push r10
000076bac53e1da1  push r11
000076bac53e1da3  sub rsp, 0xF0
000076bac53e1daa  vmovaps [rsp], xmm0
000076bac53e1daf  vmovaps [rsp+0x10], xmm1
000076bac53e1db5  vmovaps [rsp+0x20], xmm2
000076bac53e1dbb  vmovaps [rsp+0x30], xmm3
000076bac53e1dc1  vmovaps [rsp+0x40], xmm4
000076bac53e1dc7  vmovaps [rsp+0x50], xmm5
000076bac53e1dcd  vmovaps [rsp+0x60], xmm6
000076bac53e1dd3  vmovaps [rsp+0x70], xmm7
000076bac53e1dd9  vmovaps [rsp+0x80], xmm8
000076bac53e1de2  vmovaps [rsp+0x90], xmm9
000076bac53e1deb  vmovaps [rsp+0xA0], xmm10
000076bac53e1df4  vmovaps [rsp+0xB0], xmm11
000076bac53e1dfd  vmovaps [rsp+0xC0], xmm12
000076bac53e1e06  vmovaps [rsp+0xD0], xmm13
000076bac53e1e0f  vmovaps [rsp+0xE0], xmm15
000076bac53e1e18  sub rsp, 0x30
000076bac53e1e1c  movaps [rsp], xmm14
000076bac53e1e21  movaps [rsp+0x10], xmm2
000076bac53e1e26  movaps [rsp+0x20], xmm1
000076bac53e1e2b  lea rdi, [rsp]
000076bac53e1e2f  mov esi, 0x00
000076bac53e1e34  mov rax, 0x5641B0A3C530
000076bac53e1e3e  call rax
000076bac53e1e40  movaps xmm14, [rsp]
000076bac53e1e45  add rsp, 0x30
000076bac53e1e49  vmovaps xmm0, [rsp]
000076bac53e1e4e  vmovaps xmm1, [rsp+0x10]
000076bac53e1e54  vmovaps xmm2, [rsp+0x20]
000076bac53e1e5a  vmovaps xmm3, [rsp+0x30]
000076bac53e1e60  vmovaps xmm4, [rsp+0x40]
000076bac53e1e66  vmovaps xmm5, [rsp+0x50]
000076bac53e1e6c  vmovaps xmm6, [rsp+0x60]
000076bac53e1e72  vmovaps xmm7, [rsp+0x70]
000076bac53e1e78  vmovaps xmm8, [rsp+0x80]
000076bac53e1e81  vmovaps xmm9, [rsp+0x90]
000076bac53e1e8a  vmovaps xmm10, [rsp+0xA0]
000076bac53e1e93  vmovaps xmm11, [rsp+0xB0]
000076bac53e1e9c  vmovaps xmm12, [rsp+0xC0]
000076bac53e1ea5  vmovaps xmm13, [rsp+0xD0]
000076bac53e1eae  vmovaps xmm15, [rsp+0xE0]
000076bac53e1eb7  add rsp, 0xF0
000076bac53e1ebe  pop r11
000076bac53e1ec0  pop r10
000076bac53e1ec2  pop r9
000076bac53e1ec4  pop r8
000076bac53e1ec6  pop rsi
000076bac53e1ec7  pop rdi
000076bac53e1ec8  pop rdx
000076bac53e1ec9  pop rcx
000076bac53e1eca  pop rax
000076bac53e1ecb  add rsp, 0x08
000076bac53e1ecf  jmp 0x000076BAC53DF4B0
000076bac53e1ed4  sub rsp, 0x08
000076bac53e1ed8  push rax
000076bac53e1ed9  push rcx
000076bac53e1eda  push rdx
000076bac53e1edb  push rdi
000076bac53e1edc  push rsi
000076bac53e1edd  push r8
000076bac53e1edf  push r9
000076bac53e1ee1  push r10
000076bac53e1ee3  push r11
000076bac53e1ee5  sub rsp, 0xF0
000076bac53e1eec  vmovaps [rsp], xmm0
000076bac53e1ef1  vmovaps [rsp+0x10], xmm2
000076bac53e1ef7  vmovaps [rsp+0x20], xmm3
000076bac53e1efd  vmovaps [rsp+0x30], xmm4
000076bac53e1f03  vmovaps [rsp+0x40], xmm5
000076bac53e1f09  vmovaps [rsp+0x50], xmm6
000076bac53e1f0f  vmovaps [rsp+0x60], xmm7
000076bac53e1f15  vmovaps [rsp+0x70], xmm8
000076bac53e1f1b  vmovaps [rsp+0x80], xmm9
000076bac53e1f24  vmovaps [rsp+0x90], xmm10
000076bac53e1f2d  vmovaps [rsp+0xA0], xmm11
000076bac53e1f36  vmovaps [rsp+0xB0], xmm12
000076bac53e1f3f  vmovaps [rsp+0xC0], xmm13
000076bac53e1f48  vmovaps [rsp+0xD0], xmm14
000076bac53e1f51  vmovaps [rsp+0xE0], xmm15
000076bac53e1f5a  sub rsp, 0x30
000076bac53e1f5e  movaps [rsp], xmm1
000076bac53e1f62  movaps [rsp+0x10], xmm4
000076bac53e1f67  movaps [rsp+0x20], xmm9
000076bac53e1f6d  lea rdi, [rsp]
000076bac53e1f71  mov esi, 0x00
000076bac53e1f76  mov rax, 0x5641B0A3C530
000076bac53e1f80  call rax
000076bac53e1f82  movaps xmm1, [rsp]
000076bac53e1f86  add rsp, 0x30
000076bac53e1f8a  vmovaps xmm0, [rsp]
000076bac53e1f8f  vmovaps xmm2, [rsp+0x10]
000076bac53e1f95  vmovaps xmm3, [rsp+0x20]
000076bac53e1f9b  vmovaps xmm4, [rsp+0x30]
000076bac53e1fa1  vmovaps xmm5, [rsp+0x40]
000076bac53e1fa7  vmovaps xmm6, [rsp+0x50]
000076bac53e1fad  vmovaps xmm7, [rsp+0x60]
000076bac53e1fb3  vmovaps xmm8, [rsp+0x70]
000076bac53e1fb9  vmovaps xmm9, [rsp+0x80]
000076bac53e1fc2  vmovaps xmm10, [rsp+0x90]
000076bac53e1fcb  vmovaps xmm11, [rsp+0xA0]
000076bac53e1fd4  vmovaps xmm12, [rsp+0xB0]
000076bac53e1fdd  vmovaps xmm13, [rsp+0xC0]
000076bac53e1fe6  vmovaps xmm14, [rsp+0xD0]
000076bac53e1fef  vmovaps xmm15, [rsp+0xE0]
000076bac53e1ff8  add rsp, 0xF0
000076bac53e1fff  pop r11
000076bac53e2001  pop r10
000076bac53e2003  pop r9
000076bac53e2005  pop r8
000076bac53e2007  pop rsi
000076bac53e2008  pop rdi
000076bac53e2009  pop rdx
000076bac53e200a  pop rcx
000076bac53e200b  pop rax
000076bac53e200c  add rsp, 0x08
000076bac53e2010  jmp 0x000076BAC53DF4CE
000076bac53e2015  sub rsp, 0x08
000076bac53e2019  push rax
000076bac53e201a  push rcx
000076bac53e201b  push rdx
000076bac53e201c  push rdi
000076bac53e201d  push rsi
000076bac53e201e  push r8
000076bac53e2020  push r9
000076bac53e2022  push r10
000076bac53e2024  push r11
000076bac53e2026  sub rsp, 0xF0
000076bac53e202d  vmovaps [rsp], xmm0
000076bac53e2032  vmovaps [rsp+0x10], xmm1
000076bac53e2038  vmovaps [rsp+0x20], xmm2
000076bac53e203e  vmovaps [rsp+0x30], xmm3
000076bac53e2044  vmovaps [rsp+0x40], xmm5
000076bac53e204a  vmovaps [rsp+0x50], xmm6
000076bac53e2050  vmovaps [rsp+0x60], xmm7
000076bac53e2056  vmovaps [rsp+0x70], xmm8
000076bac53e205c  vmovaps [rsp+0x80], xmm9
000076bac53e2065  vmovaps [rsp+0x90], xmm10
000076bac53e206e  vmovaps [rsp+0xA0], xmm11
000076bac53e2077  vmovaps [rsp+0xB0], xmm12
000076bac53e2080  vmovaps [rsp+0xC0], xmm13
000076bac53e2089  vmovaps [rsp+0xD0], xmm14
000076bac53e2092  vmovaps [rsp+0xE0], xmm15
000076bac53e209b  sub rsp, 0x30
000076bac53e209f  movaps [rsp], xmm4
000076bac53e20a3  movaps [rsp+0x10], xmm2
000076bac53e20a8  movaps [rsp+0x20], xmm9
000076bac53e20ae  lea rdi, [rsp]
000076bac53e20b2  mov esi, 0x00
000076bac53e20b7  mov rax, 0x5641B0A3C530
000076bac53e20c1  call rax
000076bac53e20c3  movaps xmm4, [rsp]
000076bac53e20c7  add rsp, 0x30
000076bac53e20cb  vmovaps xmm0, [rsp]
000076bac53e20d0  vmovaps xmm1, [rsp+0x10]
000076bac53e20d6  vmovaps xmm2, [rsp+0x20]
000076bac53e20dc  vmovaps xmm3, [rsp+0x30]
000076bac53e20e2  vmovaps xmm5, [rsp+0x40]
000076bac53e20e8  vmovaps xmm6, [rsp+0x50]
000076bac53e20ee  vmovaps xmm7, [rsp+0x60]
000076bac53e20f4  vmovaps xmm8, [rsp+0x70]
000076bac53e20fa  vmovaps xmm9, [rsp+0x80]
000076bac53e2103  vmovaps xmm10, [rsp+0x90]
000076bac53e210c  vmovaps xmm11, [rsp+0xA0]
000076bac53e2115  vmovaps xmm12, [rsp+0xB0]
000076bac53e211e  vmovaps xmm13, [rsp+0xC0]
000076bac53e2127  vmovaps xmm14, [rsp+0xD0]
000076bac53e2130  vmovaps xmm15, [rsp+0xE0]
000076bac53e2139  add rsp, 0xF0
000076bac53e2140  pop r11
000076bac53e2142  pop r10
000076bac53e2144  pop r9
000076bac53e2146  pop r8
000076bac53e2148  pop rsi
000076bac53e2149  pop rdi
000076bac53e214a  pop rdx
000076bac53e214b  pop rcx
000076bac53e214c  pop rax
000076bac53e214d  add rsp, 0x08
000076bac53e2151  jmp 0x000076BAC53DF4FE
000076bac53e2156  sub rsp, 0x08
000076bac53e215a  push rax
000076bac53e215b  push rcx
000076bac53e215c  push rdx
000076bac53e215d  push rdi
000076bac53e215e  push rsi
000076bac53e215f  push r8
000076bac53e2161  push r9
000076bac53e2163  push r10
000076bac53e2165  push r11
000076bac53e2167  sub rsp, 0xF0
000076bac53e216e  vmovaps [rsp], xmm0
000076bac53e2173  vmovaps [rsp+0x10], xmm1
000076bac53e2179  vmovaps [rsp+0x20], xmm2
000076bac53e217f  vmovaps [rsp+0x30], xmm3
000076bac53e2185  vmovaps [rsp+0x40], xmm4
000076bac53e218b  vmovaps [rsp+0x50], xmm5
000076bac53e2191  vmovaps [rsp+0x60], xmm6
000076bac53e2197  vmovaps [rsp+0x70], xmm7
000076bac53e219d  vmovaps [rsp+0x80], xmm8
000076bac53e21a6  vmovaps [rsp+0x90], xmm10
000076bac53e21af  vmovaps [rsp+0xA0], xmm11
000076bac53e21b8  vmovaps [rsp+0xB0], xmm12
000076bac53e21c1  vmovaps [rsp+0xC0], xmm13
000076bac53e21ca  vmovaps [rsp+0xD0], xmm14
000076bac53e21d3  vmovaps [rsp+0xE0], xmm15
000076bac53e21dc  sub rsp, 0x30
000076bac53e21e0  movaps [rsp], xmm9
000076bac53e21e5  movaps [rsp+0x10], xmm2
000076bac53e21ea  movaps [rsp+0x20], xmm1
000076bac53e21ef  lea rdi, [rsp]
000076bac53e21f3  mov esi, 0x00
000076bac53e21f8  mov rax, 0x5641B0A3C530
000076bac53e2202  call rax
000076bac53e2204  movaps xmm9, [rsp]
000076bac53e2209  add rsp, 0x30
000076bac53e220d  vmovaps xmm0, [rsp]
000076bac53e2212  vmovaps xmm1, [rsp+0x10]
000076bac53e2218  vmovaps xmm2, [rsp+0x20]
000076bac53e221e  vmovaps xmm3, [rsp+0x30]
000076bac53e2224  vmovaps xmm4, [rsp+0x40]
000076bac53e222a  vmovaps xmm5, [rsp+0x50]
000076bac53e2230  vmovaps xmm6, [rsp+0x60]
000076bac53e2236  vmovaps xmm7, [rsp+0x70]
000076bac53e223c  vmovaps xmm8, [rsp+0x80]
000076bac53e2245  vmovaps xmm10, [rsp+0x90]
000076bac53e224e  vmovaps xmm11, [rsp+0xA0]
000076bac53e2257  vmovaps xmm12, [rsp+0xB0]
000076bac53e2260  vmovaps xmm13, [rsp+0xC0]
000076bac53e2269  vmovaps xmm14, [rsp+0xD0]
000076bac53e2272  vmovaps xmm15, [rsp+0xE0]
000076bac53e227b  add rsp, 0xF0
000076bac53e2282  pop r11
000076bac53e2284  pop r10
000076bac53e2286  pop r9
000076bac53e2288  pop r8
000076bac53e228a  pop rsi
000076bac53e228b  pop rdi
000076bac53e228c  pop rdx
000076bac53e228d  pop rcx
000076bac53e228e  pop rax
000076bac53e228f  add rsp, 0x08
000076bac53e2293  jmp 0x000076BAC53DF534
000076bac53e2298  sub rsp, 0x08
000076bac53e229c  push rax
000076bac53e229d  push rcx
000076bac53e229e  push rdx
000076bac53e229f  push rdi
000076bac53e22a0  push rsi
000076bac53e22a1  push r8
000076bac53e22a3  push r9
000076bac53e22a5  push r10
000076bac53e22a7  push r11
000076bac53e22a9  sub rsp, 0xF0
000076bac53e22b0  vmovaps [rsp], xmm0
000076bac53e22b5  vmovaps [rsp+0x10], xmm2
000076bac53e22bb  vmovaps [rsp+0x20], xmm3
000076bac53e22c1  vmovaps [rsp+0x30], xmm4
000076bac53e22c7  vmovaps [rsp+0x40], xmm5
000076bac53e22cd  vmovaps [rsp+0x50], xmm6
000076bac53e22d3  vmovaps [rsp+0x60], xmm7
000076bac53e22d9  vmovaps [rsp+0x70], xmm8
000076bac53e22df  vmovaps [rsp+0x80], xmm9
000076bac53e22e8  vmovaps [rsp+0x90], xmm10
000076bac53e22f1  vmovaps [rsp+0xA0], xmm11
000076bac53e22fa  vmovaps [rsp+0xB0], xmm12
000076bac53e2303  vmovaps [rsp+0xC0], xmm13
000076bac53e230c  vmovaps [rsp+0xD0], xmm14
000076bac53e2315  vmovaps [rsp+0xE0], xmm15
000076bac53e231e  sub rsp, 0x30
000076bac53e2322  movaps [rsp], xmm1
000076bac53e2326  movaps [rsp+0x10], xmm15
000076bac53e232c  movaps [rsp+0x20], xmm6
000076bac53e2331  lea rdi, [rsp]
000076bac53e2335  mov esi, 0x00
000076bac53e233a  mov rax, 0x5641B0A3C530
000076bac53e2344  call rax
000076bac53e2346  movaps xmm1, [rsp]
000076bac53e234a  add rsp, 0x30
000076bac53e234e  vmovaps xmm0, [rsp]
000076bac53e2353  vmovaps xmm2, [rsp+0x10]
000076bac53e2359  vmovaps xmm3, [rsp+0x20]
000076bac53e235f  vmovaps xmm4, [rsp+0x30]
000076bac53e2365  vmovaps xmm5, [rsp+0x40]
000076bac53e236b  vmovaps xmm6, [rsp+0x50]
000076bac53e2371  vmovaps xmm7, [rsp+0x60]
000076bac53e2377  vmovaps xmm8, [rsp+0x70]
000076bac53e237d  vmovaps xmm9, [rsp+0x80]
000076bac53e2386  vmovaps xmm10, [rsp+0x90]
000076bac53e238f  vmovaps xmm11, [rsp+0xA0]
000076bac53e2398  vmovaps xmm12, [rsp+0xB0]
000076bac53e23a1  vmovaps xmm13, [rsp+0xC0]
000076bac53e23aa  vmovaps xmm14, [rsp+0xD0]
000076bac53e23b3  vmovaps xmm15, [rsp+0xE0]
000076bac53e23bc  add rsp, 0xF0
000076bac53e23c3  pop r11
000076bac53e23c5  pop r10
000076bac53e23c7  pop r9
000076bac53e23c9  pop r8
000076bac53e23cb  pop rsi
000076bac53e23cc  pop rdi
000076bac53e23cd  pop rdx
000076bac53e23ce  pop rcx
000076bac53e23cf  pop rax
000076bac53e23d0  add rsp, 0x08
000076bac53e23d4  jmp 0x000076BAC53DF555
000076bac53e23d9  sub rsp, 0x08
000076bac53e23dd  push rax
000076bac53e23de  push rcx
000076bac53e23df  push rdx
000076bac53e23e0  push rdi
000076bac53e23e1  push rsi
000076bac53e23e2  push r8
000076bac53e23e4  push r9
000076bac53e23e6  push r10
000076bac53e23e8  push r11
000076bac53e23ea  sub rsp, 0xF0
000076bac53e23f1  vmovaps [rsp], xmm0
000076bac53e23f6  vmovaps [rsp+0x10], xmm1
000076bac53e23fc  vmovaps [rsp+0x20], xmm2
000076bac53e2402  vmovaps [rsp+0x30], xmm3
000076bac53e2408  vmovaps [rsp+0x40], xmm4
000076bac53e240e  vmovaps [rsp+0x50], xmm5
000076bac53e2414  vmovaps [rsp+0x60], xmm6
000076bac53e241a  vmovaps [rsp+0x70], xmm7
000076bac53e2420  vmovaps [rsp+0x80], xmm8
000076bac53e2429  vmovaps [rsp+0x90], xmm9
000076bac53e2432  vmovaps [rsp+0xA0], xmm10
000076bac53e243b  vmovaps [rsp+0xB0], xmm11
000076bac53e2444  vmovaps [rsp+0xC0], xmm12
000076bac53e244d  vmovaps [rsp+0xD0], xmm13
000076bac53e2456  vmovaps [rsp+0xE0], xmm14
000076bac53e245f  sub rsp, 0x30
000076bac53e2463  movaps [rsp], xmm15
000076bac53e2468  movaps [rsp+0x10], xmm5
000076bac53e246d  movaps [rsp+0x20], xmm3
000076bac53e2472  lea rdi, [rsp]
000076bac53e2476  mov esi, 0x00
000076bac53e247b  mov rax, 0x5641B0A3C530
000076bac53e2485  call rax
000076bac53e2487  movaps xmm15, [rsp]
000076bac53e248c  add rsp, 0x30
000076bac53e2490  vmovaps xmm0, [rsp]
000076bac53e2495  vmovaps xmm1, [rsp+0x10]
000076bac53e249b  vmovaps xmm2, [rsp+0x20]
000076bac53e24a1  vmovaps xmm3, [rsp+0x30]
000076bac53e24a7  vmovaps xmm4, [rsp+0x40]
000076bac53e24ad  vmovaps xmm5, [rsp+0x50]
000076bac53e24b3  vmovaps xmm6, [rsp+0x60]
000076bac53e24b9  vmovaps xmm7, [rsp+0x70]
000076bac53e24bf  vmovaps xmm8, [rsp+0x80]
000076bac53e24c8  vmovaps xmm9, [rsp+0x90]
000076bac53e24d1  vmovaps xmm10, [rsp+0xA0]
000076bac53e24da  vmovaps xmm11, [rsp+0xB0]
000076bac53e24e3  vmovaps xmm12, [rsp+0xC0]
000076bac53e24ec  vmovaps xmm13, [rsp+0xD0]
000076bac53e24f5  vmovaps xmm14, [rsp+0xE0]
000076bac53e24fe  add rsp, 0xF0
000076bac53e2505  pop r11
000076bac53e2507  pop r10
000076bac53e2509  pop r9
000076bac53e250b  pop r8
000076bac53e250d  pop rsi
000076bac53e250e  pop rdi
000076bac53e250f  pop rdx
000076bac53e2510  pop rcx
000076bac53e2511  pop rax
000076bac53e2512  add rsp, 0x08
000076bac53e2516  jmp 0x000076BAC53DF56F
000076bac53e251b  sub rsp, 0x08
000076bac53e251f  push rax
000076bac53e2520  push rcx
000076bac53e2521  push rdx
000076bac53e2522  push rdi
000076bac53e2523  push rsi
000076bac53e2524  push r8
000076bac53e2526  push r9
000076bac53e2528  push r10
000076bac53e252a  push r11
000076bac53e252c  sub rsp, 0xF0
000076bac53e2533  vmovaps [rsp], xmm0
000076bac53e2538  vmovaps [rsp+0x10], xmm1
000076bac53e253e  vmovaps [rsp+0x20], xmm2
000076bac53e2544  vmovaps [rsp+0x30], xmm3
000076bac53e254a  vmovaps [rsp+0x40], xmm4
000076bac53e2550  vmovaps [rsp+0x50], xmm6
000076bac53e2556  vmovaps [rsp+0x60], xmm7
000076bac53e255c  vmovaps [rsp+0x70], xmm8
000076bac53e2562  vmovaps [rsp+0x80], xmm9
000076bac53e256b  vmovaps [rsp+0x90], xmm10
000076bac53e2574  vmovaps [rsp+0xA0], xmm11
000076bac53e257d  vmovaps [rsp+0xB0], xmm12
000076bac53e2586  vmovaps [rsp+0xC0], xmm13
000076bac53e258f  vmovaps [rsp+0xD0], xmm14
000076bac53e2598  vmovaps [rsp+0xE0], xmm15
000076bac53e25a1  sub rsp, 0x30
000076bac53e25a5  movaps [rsp], xmm5
000076bac53e25a9  movaps [rsp+0x10], xmm8
000076bac53e25af  movaps [rsp+0x20], xmm6
000076bac53e25b4  lea rdi, [rsp]
000076bac53e25b8  mov esi, 0x00
000076bac53e25bd  mov rax, 0x5641B0A3C530
000076bac53e25c7  call rax
000076bac53e25c9  movaps xmm5, [rsp]
000076bac53e25cd  add rsp, 0x30
000076bac53e25d1  vmovaps xmm0, [rsp]
000076bac53e25d6  vmovaps xmm1, [rsp+0x10]
000076bac53e25dc  vmovaps xmm2, [rsp+0x20]
000076bac53e25e2  vmovaps xmm3, [rsp+0x30]
000076bac53e25e8  vmovaps xmm4, [rsp+0x40]
000076bac53e25ee  vmovaps xmm6, [rsp+0x50]
000076bac53e25f4  vmovaps xmm7, [rsp+0x60]
000076bac53e25fa  vmovaps xmm8, [rsp+0x70]
000076bac53e2600  vmovaps xmm9, [rsp+0x80]
000076bac53e2609  vmovaps xmm10, [rsp+0x90]
000076bac53e2612  vmovaps xmm11, [rsp+0xA0]
000076bac53e261b  vmovaps xmm12, [rsp+0xB0]
000076bac53e2624  vmovaps xmm13, [rsp+0xC0]
000076bac53e262d  vmovaps xmm14, [rsp+0xD0]
000076bac53e2636  vmovaps xmm15, [rsp+0xE0]
000076bac53e263f  add rsp, 0xF0
000076bac53e2646  pop r11
000076bac53e2648  pop r10
000076bac53e264a  pop r9
000076bac53e264c  pop r8
000076bac53e264e  pop rsi
000076bac53e264f  pop rdi
000076bac53e2650  pop rdx
000076bac53e2651  pop rcx
000076bac53e2652  pop rax
000076bac53e2653  add rsp, 0x08
000076bac53e2657  jmp 0x000076BAC53DF593
000076bac53e265c  sub rsp, 0x08
000076bac53e2660  push rax
000076bac53e2661  push rcx
000076bac53e2662  push rdx
000076bac53e2663  push rdi
000076bac53e2664  push rsi
000076bac53e2665  push r8
000076bac53e2667  push r9
000076bac53e2669  push r10
000076bac53e266b  push r11
000076bac53e266d  sub rsp, 0xF0
000076bac53e2674  vmovaps [rsp], xmm0
000076bac53e2679  vmovaps [rsp+0x10], xmm1
000076bac53e267f  vmovaps [rsp+0x20], xmm2
000076bac53e2685  vmovaps [rsp+0x30], xmm3
000076bac53e268b  vmovaps [rsp+0x40], xmm4
000076bac53e2691  vmovaps [rsp+0x50], xmm5
000076bac53e2697  vmovaps [rsp+0x60], xmm7
000076bac53e269d  vmovaps [rsp+0x70], xmm8
000076bac53e26a3  vmovaps [rsp+0x80], xmm9
000076bac53e26ac  vmovaps [rsp+0x90], xmm10
000076bac53e26b5  vmovaps [rsp+0xA0], xmm11
000076bac53e26be  vmovaps [rsp+0xB0], xmm12
000076bac53e26c7  vmovaps [rsp+0xC0], xmm13
000076bac53e26d0  vmovaps [rsp+0xD0], xmm14
000076bac53e26d9  vmovaps [rsp+0xE0], xmm15
000076bac53e26e2  sub rsp, 0x30
000076bac53e26e6  movaps [rsp], xmm6
000076bac53e26ea  movaps [rsp+0x10], xmm10
000076bac53e26f0  movaps [rsp+0x20], xmm8
000076bac53e26f6  lea rdi, [rsp]
000076bac53e26fa  mov esi, 0x00
000076bac53e26ff  mov rax, 0x5641B0A3C530
000076bac53e2709  call rax
000076bac53e270b  movaps xmm6, [rsp]
000076bac53e270f  add rsp, 0x30
000076bac53e2713  vmovaps xmm0, [rsp]
000076bac53e2718  vmovaps xmm1, [rsp+0x10]
000076bac53e271e  vmovaps xmm2, [rsp+0x20]
000076bac53e2724  vmovaps xmm3, [rsp+0x30]
000076bac53e272a  vmovaps xmm4, [rsp+0x40]
000076bac53e2730  vmovaps xmm5, [rsp+0x50]
000076bac53e2736  vmovaps xmm7, [rsp+0x60]
000076bac53e273c  vmovaps xmm8, [rsp+0x70]
000076bac53e2742  vmovaps xmm9, [rsp+0x80]
000076bac53e274b  vmovaps xmm10, [rsp+0x90]
000076bac53e2754  vmovaps xmm11, [rsp+0xA0]
000076bac53e275d  vmovaps xmm12, [rsp+0xB0]
000076bac53e2766  vmovaps xmm13, [rsp+0xC0]
000076bac53e276f  vmovaps xmm14, [rsp+0xD0]
000076bac53e2778  vmovaps xmm15, [rsp+0xE0]
000076bac53e2781  add rsp, 0xF0
000076bac53e2788  pop r11
000076bac53e278a  pop r10
000076bac53e278c  pop r9
000076bac53e278e  pop r8
000076bac53e2790  pop rsi
000076bac53e2791  pop rdi
000076bac53e2792  pop rdx
000076bac53e2793  pop rcx
000076bac53e2794  pop rax
000076bac53e2795  add rsp, 0x08
000076bac53e2799  jmp 0x000076BAC53DF5B8
000076bac53e279e  sub rsp, 0x08
000076bac53e27a2  push rax
000076bac53e27a3  push rcx
000076bac53e27a4  push rdx
000076bac53e27a5  push rdi
000076bac53e27a6  push rsi
000076bac53e27a7  push r8
000076bac53e27a9  push r9
000076bac53e27ab  push r10
000076bac53e27ad  push r11
000076bac53e27af  sub rsp, 0xF0
000076bac53e27b6  vmovaps [rsp], xmm0
000076bac53e27bb  vmovaps [rsp+0x10], xmm1
000076bac53e27c1  vmovaps [rsp+0x20], xmm2
000076bac53e27c7  vmovaps [rsp+0x30], xmm3
000076bac53e27cd  vmovaps [rsp+0x40], xmm4
000076bac53e27d3  vmovaps [rsp+0x50], xmm5
000076bac53e27d9  vmovaps [rsp+0x60], xmm6
000076bac53e27df  vmovaps [rsp+0x70], xmm7
000076bac53e27e5  vmovaps [rsp+0x80], xmm8
000076bac53e27ee  vmovaps [rsp+0x90], xmm9
000076bac53e27f7  vmovaps [rsp+0xA0], xmm11
000076bac53e2800  vmovaps [rsp+0xB0], xmm12
000076bac53e2809  vmovaps [rsp+0xC0], xmm13
000076bac53e2812  vmovaps [rsp+0xD0], xmm14
000076bac53e281b  vmovaps [rsp+0xE0], xmm15
000076bac53e2824  sub rsp, 0x30
000076bac53e2828  movaps [rsp], xmm10
000076bac53e282d  movaps [rsp+0x10], xmm8
000076bac53e2833  movaps [rsp+0x20], xmm14
000076bac53e2839  lea rdi, [rsp]
000076bac53e283d  mov esi, 0x00
000076bac53e2842  mov rax, 0x5641B0A3C530
000076bac53e284c  call rax
000076bac53e284e  movaps xmm10, [rsp]
000076bac53e2853  add rsp, 0x30
000076bac53e2857  vmovaps xmm0, [rsp]
000076bac53e285c  vmovaps xmm1, [rsp+0x10]
000076bac53e2862  vmovaps xmm2, [rsp+0x20]
000076bac53e2868  vmovaps xmm3, [rsp+0x30]
000076bac53e286e  vmovaps xmm4, [rsp+0x40]
000076bac53e2874  vmovaps xmm5, [rsp+0x50]
000076bac53e287a  vmovaps xmm6, [rsp+0x60]
000076bac53e2880  vmovaps xmm7, [rsp+0x70]
000076bac53e2886  vmovaps xmm8, [rsp+0x80]
000076bac53e288f  vmovaps xmm9, [rsp+0x90]
000076bac53e2898  vmovaps xmm11, [rsp+0xA0]
000076bac53e28a1  vmovaps xmm12, [rsp+0xB0]
000076bac53e28aa  vmovaps xmm13, [rsp+0xC0]
000076bac53e28b3  vmovaps xmm14, [rsp+0xD0]
000076bac53e28bc  vmovaps xmm15, [rsp+0xE0]
000076bac53e28c5  add rsp, 0xF0
000076bac53e28cc  pop r11
000076bac53e28ce  pop r10
000076bac53e28d0  pop r9
000076bac53e28d2  pop r8
000076bac53e28d4  pop rsi
000076bac53e28d5  pop rdi
000076bac53e28d6  pop rdx
000076bac53e28d7  pop rcx
000076bac53e28d8  pop rax
000076bac53e28d9  add rsp, 0x08
000076bac53e28dd  jmp 0x000076BAC53DF5D8
000076bac53e28e2  sub rsp, 0x08
000076bac53e28e6  push rax
000076bac53e28e7  push rcx
000076bac53e28e8  push rdx
000076bac53e28e9  push rdi
000076bac53e28ea  push rsi
000076bac53e28eb  push r8
000076bac53e28ed  push r9
000076bac53e28ef  push r10
000076bac53e28f1  push r11
000076bac53e28f3  sub rsp, 0xF0
000076bac53e28fa  vmovaps [rsp], xmm0
000076bac53e28ff  vmovaps [rsp+0x10], xmm1
000076bac53e2905  vmovaps [rsp+0x20], xmm2
000076bac53e290b  vmovaps [rsp+0x30], xmm3
000076bac53e2911  vmovaps [rsp+0x40], xmm4
000076bac53e2917  vmovaps [rsp+0x50], xmm5
000076bac53e291d  vmovaps [rsp+0x60], xmm6
000076bac53e2923  vmovaps [rsp+0x70], xmm7
000076bac53e2929  vmovaps [rsp+0x80], xmm8
000076bac53e2932  vmovaps [rsp+0x90], xmm9
000076bac53e293b  vmovaps [rsp+0xA0], xmm10
000076bac53e2944  vmovaps [rsp+0xB0], xmm11
000076bac53e294d  vmovaps [rsp+0xC0], xmm12
000076bac53e2956  vmovaps [rsp+0xD0], xmm13
000076bac53e295f  vmovaps [rsp+0xE0], xmm15
000076bac53e2968  sub rsp, 0x30
000076bac53e296c  movaps [rsp], xmm14
000076bac53e2971  movaps [rsp+0x10], xmm8
000076bac53e2977  movaps [rsp+0x20], xmm4
000076bac53e297c  lea rdi, [rsp]
000076bac53e2980  mov esi, 0x00
000076bac53e2985  mov rax, 0x5641B0A3C530
000076bac53e298f  call rax
000076bac53e2991  movaps xmm14, [rsp]
000076bac53e2996  add rsp, 0x30
000076bac53e299a  vmovaps xmm0, [rsp]
000076bac53e299f  vmovaps xmm1, [rsp+0x10]
000076bac53e29a5  vmovaps xmm2, [rsp+0x20]
000076bac53e29ab  vmovaps xmm3, [rsp+0x30]
000076bac53e29b1  vmovaps xmm4, [rsp+0x40]
000076bac53e29b7  vmovaps xmm5, [rsp+0x50]
000076bac53e29bd  vmovaps xmm6, [rsp+0x60]
000076bac53e29c3  vmovaps xmm7, [rsp+0x70]
000076bac53e29c9  vmovaps xmm8, [rsp+0x80]
000076bac53e29d2  vmovaps xmm9, [rsp+0x90]
000076bac53e29db  vmovaps xmm10, [rsp+0xA0]
000076bac53e29e4  vmovaps xmm11, [rsp+0xB0]
000076bac53e29ed  vmovaps xmm12, [rsp+0xC0]
000076bac53e29f6  vmovaps xmm13, [rsp+0xD0]
000076bac53e29ff  vmovaps xmm15, [rsp+0xE0]
000076bac53e2a08  add rsp, 0xF0
000076bac53e2a0f  pop r11
000076bac53e2a11  pop r10
000076bac53e2a13  pop r9
000076bac53e2a15  pop r8
000076bac53e2a17  pop rsi
000076bac53e2a18  pop rdi
000076bac53e2a19  pop rdx
000076bac53e2a1a  pop rcx
000076bac53e2a1b  pop rax
000076bac53e2a1c  add rsp, 0x08
000076bac53e2a20  jmp 0x000076BAC53DF5F8
000076bac53e2a25  sub rsp, 0x08
000076bac53e2a29  push rax
000076bac53e2a2a  push rcx
000076bac53e2a2b  push rdx
000076bac53e2a2c  push rdi
000076bac53e2a2d  push rsi
000076bac53e2a2e  push r8
000076bac53e2a30  push r9
000076bac53e2a32  push r10
000076bac53e2a34  push r11
000076bac53e2a36  sub rsp, 0xF0
000076bac53e2a3d  vmovaps [rsp], xmm0
000076bac53e2a42  vmovaps [rsp+0x10], xmm1
000076bac53e2a48  vmovaps [rsp+0x20], xmm2
000076bac53e2a4e  vmovaps [rsp+0x30], xmm3
000076bac53e2a54  vmovaps [rsp+0x40], xmm5
000076bac53e2a5a  vmovaps [rsp+0x50], xmm6
000076bac53e2a60  vmovaps [rsp+0x60], xmm7
000076bac53e2a66  vmovaps [rsp+0x70], xmm8
000076bac53e2a6c  vmovaps [rsp+0x80], xmm9
000076bac53e2a75  vmovaps [rsp+0x90], xmm10
000076bac53e2a7e  vmovaps [rsp+0xA0], xmm11
000076bac53e2a87  vmovaps [rsp+0xB0], xmm12
000076bac53e2a90  vmovaps [rsp+0xC0], xmm13
000076bac53e2a99  vmovaps [rsp+0xD0], xmm14
000076bac53e2aa2  vmovaps [rsp+0xE0], xmm15
000076bac53e2aab  sub rsp, 0x30
000076bac53e2aaf  movaps [rsp], xmm4
000076bac53e2ab3  movaps [rsp+0x10], xmm13
000076bac53e2ab9  movaps [rsp+0x20], xmm8
000076bac53e2abf  lea rdi, [rsp]
000076bac53e2ac3  mov esi, 0x00
000076bac53e2ac8  mov rax, 0x5641B0A3C530
000076bac53e2ad2  call rax
000076bac53e2ad4  movaps xmm4, [rsp]
000076bac53e2ad8  add rsp, 0x30
000076bac53e2adc  vmovaps xmm0, [rsp]
000076bac53e2ae1  vmovaps xmm1, [rsp+0x10]
000076bac53e2ae7  vmovaps xmm2, [rsp+0x20]
000076bac53e2aed  vmovaps xmm3, [rsp+0x30]
000076bac53e2af3  vmovaps xmm5, [rsp+0x40]
000076bac53e2af9  vmovaps xmm6, [rsp+0x50]
000076bac53e2aff  vmovaps xmm7, [rsp+0x60]
000076bac53e2b05  vmovaps xmm8, [rsp+0x70]
000076bac53e2b0b  vmovaps xmm9, [rsp+0x80]
000076bac53e2b14  vmovaps xmm10, [rsp+0x90]
000076bac53e2b1d  vmovaps xmm11, [rsp+0xA0]
000076bac53e2b26  vmovaps xmm12, [rsp+0xB0]
000076bac53e2b2f  vmovaps xmm13, [rsp+0xC0]
000076bac53e2b38  vmovaps xmm14, [rsp+0xD0]
000076bac53e2b41  vmovaps xmm15, [rsp+0xE0]
000076bac53e2b4a  add rsp, 0xF0
000076bac53e2b51  pop r11
000076bac53e2b53  pop r10
000076bac53e2b55  pop r9
000076bac53e2b57  pop r8
000076bac53e2b59  pop rsi
000076bac53e2b5a  pop rdi
000076bac53e2b5b  pop rdx
000076bac53e2b5c  pop rcx
000076bac53e2b5d  pop rax
000076bac53e2b5e  add rsp, 0x08
000076bac53e2b62  jmp 0x000076BAC53DF61D
000076bac53e2b67  sub rsp, 0x08
000076bac53e2b6b  push rax
000076bac53e2b6c  push rcx
000076bac53e2b6d  push rdx
000076bac53e2b6e  push rdi
000076bac53e2b6f  push rsi
000076bac53e2b70  push r8
000076bac53e2b72  push r9
000076bac53e2b74  push r10
000076bac53e2b76  push r11
000076bac53e2b78  sub rsp, 0xF0
000076bac53e2b7f  vmovaps [rsp], xmm0
000076bac53e2b84  vmovaps [rsp+0x10], xmm1
000076bac53e2b8a  vmovaps [rsp+0x20], xmm2
000076bac53e2b90  vmovaps [rsp+0x30], xmm3
000076bac53e2b96  vmovaps [rsp+0x40], xmm4
000076bac53e2b9c  vmovaps [rsp+0x50], xmm5
000076bac53e2ba2  vmovaps [rsp+0x60], xmm6
000076bac53e2ba8  vmovaps [rsp+0x70], xmm7
000076bac53e2bae  vmovaps [rsp+0x80], xmm8
000076bac53e2bb7  vmovaps [rsp+0x90], xmm9
000076bac53e2bc0  vmovaps [rsp+0xA0], xmm10
000076bac53e2bc9  vmovaps [rsp+0xB0], xmm11
000076bac53e2bd2  vmovaps [rsp+0xC0], xmm12
000076bac53e2bdb  vmovaps [rsp+0xD0], xmm14
000076bac53e2be4  vmovaps [rsp+0xE0], xmm15
000076bac53e2bed  sub rsp, 0x30
000076bac53e2bf1  movaps [rsp], xmm13
000076bac53e2bf6  movaps [rsp+0x10], xmm15
000076bac53e2bfc  movaps [rsp+0x20], xmm9
000076bac53e2c02  lea rdi, [rsp]
000076bac53e2c06  mov esi, 0x00
000076bac53e2c0b  mov rax, 0x5641B0A3C530
000076bac53e2c15  call rax
000076bac53e2c17  movaps xmm13, [rsp]
000076bac53e2c1c  add rsp, 0x30
000076bac53e2c20  vmovaps xmm0, [rsp]
000076bac53e2c25  vmovaps xmm1, [rsp+0x10]
000076bac53e2c2b  vmovaps xmm2, [rsp+0x20]
000076bac53e2c31  vmovaps xmm3, [rsp+0x30]
000076bac53e2c37  vmovaps xmm4, [rsp+0x40]
000076bac53e2c3d  vmovaps xmm5, [rsp+0x50]
000076bac53e2c43  vmovaps xmm6, [rsp+0x60]
000076bac53e2c49  vmovaps xmm7, [rsp+0x70]
000076bac53e2c4f  vmovaps xmm8, [rsp+0x80]
000076bac53e2c58  vmovaps xmm9, [rsp+0x90]
000076bac53e2c61  vmovaps xmm10, [rsp+0xA0]
000076bac53e2c6a  vmovaps xmm11, [rsp+0xB0]
000076bac53e2c73  vmovaps xmm12, [rsp+0xC0]
000076bac53e2c7c  vmovaps xmm14, [rsp+0xD0]
000076bac53e2c85  vmovaps xmm15, [rsp+0xE0]
000076bac53e2c8e  add rsp, 0xF0
000076bac53e2c95  pop r11
000076bac53e2c97  pop r10
000076bac53e2c99  pop r9
000076bac53e2c9b  pop r8
000076bac53e2c9d  pop rsi
000076bac53e2c9e  pop rdi
000076bac53e2c9f  pop rdx
000076bac53e2ca0  pop rcx
000076bac53e2ca1  pop rax
000076bac53e2ca2  add rsp, 0x08
000076bac53e2ca6  jmp 0x000076BAC53DF638
000076bac53e2cab  sub rsp, 0x08
000076bac53e2caf  push rax
000076bac53e2cb0  push rcx
000076bac53e2cb1  push rdx
000076bac53e2cb2  push rdi
000076bac53e2cb3  push rsi
000076bac53e2cb4  push r8
000076bac53e2cb6  push r9
000076bac53e2cb8  push r10
000076bac53e2cba  push r11
000076bac53e2cbc  sub rsp, 0xF0
000076bac53e2cc3  vmovaps [rsp], xmm0
000076bac53e2cc8  vmovaps [rsp+0x10], xmm1
000076bac53e2cce  vmovaps [rsp+0x20], xmm2
000076bac53e2cd4  vmovaps [rsp+0x30], xmm3
000076bac53e2cda  vmovaps [rsp+0x40], xmm4
000076bac53e2ce0  vmovaps [rsp+0x50], xmm5
000076bac53e2ce6  vmovaps [rsp+0x60], xmm6
000076bac53e2cec  vmovaps [rsp+0x70], xmm7
000076bac53e2cf2  vmovaps [rsp+0x80], xmm8
000076bac53e2cfb  vmovaps [rsp+0x90], xmm9
000076bac53e2d04  vmovaps [rsp+0xA0], xmm10
000076bac53e2d0d  vmovaps [rsp+0xB0], xmm11
000076bac53e2d16  vmovaps [rsp+0xC0], xmm12
000076bac53e2d1f  vmovaps [rsp+0xD0], xmm13
000076bac53e2d28  vmovaps [rsp+0xE0], xmm14
000076bac53e2d31  sub rsp, 0x30
000076bac53e2d35  movaps [rsp], xmm15
000076bac53e2d3a  movaps [rsp+0x10], xmm1
000076bac53e2d3f  movaps [rsp+0x20], xmm5
000076bac53e2d44  lea rdi, [rsp]
000076bac53e2d48  mov esi, 0x00
000076bac53e2d4d  mov rax, 0x5641B0A3C530
000076bac53e2d57  call rax
000076bac53e2d59  movaps xmm15, [rsp]
000076bac53e2d5e  add rsp, 0x30
000076bac53e2d62  vmovaps xmm0, [rsp]
000076bac53e2d67  vmovaps xmm1, [rsp+0x10]
000076bac53e2d6d  vmovaps xmm2, [rsp+0x20]
000076bac53e2d73  vmovaps xmm3, [rsp+0x30]
000076bac53e2d79  vmovaps xmm4, [rsp+0x40]
000076bac53e2d7f  vmovaps xmm5, [rsp+0x50]
000076bac53e2d85  vmovaps xmm6, [rsp+0x60]
000076bac53e2d8b  vmovaps xmm7, [rsp+0x70]
000076bac53e2d91  vmovaps xmm8, [rsp+0x80]
000076bac53e2d9a  vmovaps xmm9, [rsp+0x90]
000076bac53e2da3  vmovaps xmm10, [rsp+0xA0]
000076bac53e2dac  vmovaps xmm11, [rsp+0xB0]
000076bac53e2db5  vmovaps xmm12, [rsp+0xC0]
000076bac53e2dbe  vmovaps xmm13, [rsp+0xD0]
000076bac53e2dc7  vmovaps xmm14, [rsp+0xE0]
000076bac53e2dd0  add rsp, 0xF0
000076bac53e2dd7  pop r11
000076bac53e2dd9  pop r10
000076bac53e2ddb  pop r9
000076bac53e2ddd  pop r8
000076bac53e2ddf  pop rsi
000076bac53e2de0  pop rdi
000076bac53e2de1  pop rdx
000076bac53e2de2  pop rcx
000076bac53e2de3  pop rax
000076bac53e2de4  add rsp, 0x08
000076bac53e2de8  jmp 0x000076BAC53DF653
000076bac53e2ded  call 0x000076BAC52B52F0
000076bac53e2df2  jmp 0x000076BAC53DF6AE
000076bac53e2df7  sub rsp, 0x08
000076bac53e2dfb  push rax
000076bac53e2dfc  push rcx
000076bac53e2dfd  push rdx
000076bac53e2dfe  push rdi
000076bac53e2dff  push rsi
000076bac53e2e00  push r8
000076bac53e2e02  push r9
000076bac53e2e04  push r10
000076bac53e2e06  push r11
000076bac53e2e08  sub rsp, 0xF0
000076bac53e2e0f  vmovaps [rsp], xmm0
000076bac53e2e14  vmovaps [rsp+0x10], xmm1
000076bac53e2e1a  vmovaps [rsp+0x20], xmm2
000076bac53e2e20  vmovaps [rsp+0x30], xmm3
000076bac53e2e26  vmovaps [rsp+0x40], xmm4
000076bac53e2e2c  vmovaps [rsp+0x50], xmm5
000076bac53e2e32  vmovaps [rsp+0x60], xmm6
000076bac53e2e38  vmovaps [rsp+0x70], xmm7
000076bac53e2e3e  vmovaps [rsp+0x80], xmm8
000076bac53e2e47  vmovaps [rsp+0x90], xmm10
000076bac53e2e50  vmovaps [rsp+0xA0], xmm11
000076bac53e2e59  vmovaps [rsp+0xB0], xmm12
000076bac53e2e62  vmovaps [rsp+0xC0], xmm13
000076bac53e2e6b  vmovaps [rsp+0xD0], xmm14
000076bac53e2e74  vmovaps [rsp+0xE0], xmm15
000076bac53e2e7d  sub rsp, 0x30
000076bac53e2e81  movaps [rsp], xmm9
000076bac53e2e86  movaps [rsp+0x10], xmm8
000076bac53e2e8c  movaps [rsp+0x20], xmm11
000076bac53e2e92  lea rdi, [rsp]
000076bac53e2e96  mov esi, 0x00
000076bac53e2e9b  mov rax, 0x5641B0A3C530
000076bac53e2ea5  call rax
000076bac53e2ea7  movaps xmm9, [rsp]
000076bac53e2eac  add rsp, 0x30
000076bac53e2eb0  vmovaps xmm0, [rsp]
000076bac53e2eb5  vmovaps xmm1, [rsp+0x10]
000076bac53e2ebb  vmovaps xmm2, [rsp+0x20]
000076bac53e2ec1  vmovaps xmm3, [rsp+0x30]
000076bac53e2ec7  vmovaps xmm4, [rsp+0x40]
000076bac53e2ecd  vmovaps xmm5, [rsp+0x50]
000076bac53e2ed3  vmovaps xmm6, [rsp+0x60]
000076bac53e2ed9  vmovaps xmm7, [rsp+0x70]
000076bac53e2edf  vmovaps xmm8, [rsp+0x80]
000076bac53e2ee8  vmovaps xmm10, [rsp+0x90]
000076bac53e2ef1  vmovaps xmm11, [rsp+0xA0]
000076bac53e2efa  vmovaps xmm12, [rsp+0xB0]
000076bac53e2f03  vmovaps xmm13, [rsp+0xC0]
000076bac53e2f0c  vmovaps xmm14, [rsp+0xD0]
000076bac53e2f15  vmovaps xmm15, [rsp+0xE0]
000076bac53e2f1e  add rsp, 0xF0
000076bac53e2f25  pop r11
000076bac53e2f27  pop r10
000076bac53e2f29  pop r9
000076bac53e2f2b  pop r8
000076bac53e2f2d  pop rsi
000076bac53e2f2e  pop rdi
000076bac53e2f2f  pop rdx
000076bac53e2f30  pop rcx
000076bac53e2f31  pop rax
000076bac53e2f32  add rsp, 0x08
000076bac53e2f36  jmp 0x000076BAC53DF6E5
000076bac53e2f3b  sub rsp, 0x08
000076bac53e2f3f  push rax
000076bac53e2f40  push rcx
000076bac53e2f41  push rdx
000076bac53e2f42  push rdi
000076bac53e2f43  push rsi
000076bac53e2f44  push r8
000076bac53e2f46  push r9
000076bac53e2f48  push r10
000076bac53e2f4a  push r11
000076bac53e2f4c  sub rsp, 0xF0
000076bac53e2f53  vmovaps [rsp], xmm0
000076bac53e2f58  vmovaps [rsp+0x10], xmm1
000076bac53e2f5e  vmovaps [rsp+0x20], xmm2
000076bac53e2f64  vmovaps [rsp+0x30], xmm3
000076bac53e2f6a  vmovaps [rsp+0x40], xmm4
000076bac53e2f70  vmovaps [rsp+0x50], xmm5
000076bac53e2f76  vmovaps [rsp+0x60], xmm6
000076bac53e2f7c  vmovaps [rsp+0x70], xmm7
000076bac53e2f82  vmovaps [rsp+0x80], xmm8
000076bac53e2f8b  vmovaps [rsp+0x90], xmm9
000076bac53e2f94  vmovaps [rsp+0xA0], xmm10
000076bac53e2f9d  vmovaps [rsp+0xB0], xmm12
000076bac53e2fa6  vmovaps [rsp+0xC0], xmm13
000076bac53e2faf  vmovaps [rsp+0xD0], xmm14
000076bac53e2fb8  vmovaps [rsp+0xE0], xmm15
000076bac53e2fc1  sub rsp, 0x30
000076bac53e2fc5  movaps [rsp], xmm11
000076bac53e2fca  movaps [rsp+0x10], xmm10
000076bac53e2fd0  movaps [rsp+0x20], xmm6
000076bac53e2fd5  lea rdi, [rsp]
000076bac53e2fd9  mov esi, 0x00
000076bac53e2fde  mov rax, 0x5641B0A3C530
000076bac53e2fe8  call rax
000076bac53e2fea  movaps xmm11, [rsp]
000076bac53e2fef  add rsp, 0x30
000076bac53e2ff3  vmovaps xmm0, [rsp]
000076bac53e2ff8  vmovaps xmm1, [rsp+0x10]
000076bac53e2ffe  vmovaps xmm2, [rsp+0x20]
000076bac53e3004  vmovaps xmm3, [rsp+0x30]
000076bac53e300a  vmovaps xmm4, [rsp+0x40]
000076bac53e3010  vmovaps xmm5, [rsp+0x50]
000076bac53e3016  vmovaps xmm6, [rsp+0x60]
000076bac53e301c  vmovaps xmm7, [rsp+0x70]
000076bac53e3022  vmovaps xmm8, [rsp+0x80]
000076bac53e302b  vmovaps xmm9, [rsp+0x90]
000076bac53e3034  vmovaps xmm10, [rsp+0xA0]
000076bac53e303d  vmovaps xmm12, [rsp+0xB0]
000076bac53e3046  vmovaps xmm13, [rsp+0xC0]
000076bac53e304f  vmovaps xmm14, [rsp+0xD0]
000076bac53e3058  vmovaps xmm15, [rsp+0xE0]
000076bac53e3061  add rsp, 0xF0
000076bac53e3068  pop r11
000076bac53e306a  pop r10
000076bac53e306c  pop r9
000076bac53e306e  pop r8
000076bac53e3070  pop rsi
000076bac53e3071  pop rdi
000076bac53e3072  pop rdx
000076bac53e3073  pop rcx
000076bac53e3074  pop rax
000076bac53e3075  add rsp, 0x08
000076bac53e3079  jmp 0x000076BAC53DF700
000076bac53e307e  sub rsp, 0x08
000076bac53e3082  push rax
000076bac53e3083  push rcx
000076bac53e3084  push rdx
000076bac53e3085  push rdi
000076bac53e3086  push rsi
000076bac53e3087  push r8
000076bac53e3089  push r9
000076bac53e308b  push r10
000076bac53e308d  push r11
000076bac53e308f  sub rsp, 0xF0
000076bac53e3096  vmovaps [rsp], xmm0
000076bac53e309b  vmovaps [rsp+0x10], xmm1
000076bac53e30a1  vmovaps [rsp+0x20], xmm2
000076bac53e30a7  vmovaps [rsp+0x30], xmm3
000076bac53e30ad  vmovaps [rsp+0x40], xmm4
000076bac53e30b3  vmovaps [rsp+0x50], xmm5
000076bac53e30b9  vmovaps [rsp+0x60], xmm6
000076bac53e30bf  vmovaps [rsp+0x70], xmm7
000076bac53e30c5  vmovaps [rsp+0x80], xmm8
000076bac53e30ce  vmovaps [rsp+0x90], xmm9
000076bac53e30d7  vmovaps [rsp+0xA0], xmm11
000076bac53e30e0  vmovaps [rsp+0xB0], xmm12
000076bac53e30e9  vmovaps [rsp+0xC0], xmm13
000076bac53e30f2  vmovaps [rsp+0xD0], xmm14
000076bac53e30fb  vmovaps [rsp+0xE0], xmm15
000076bac53e3104  sub rsp, 0x30
000076bac53e3108  movaps [rsp], xmm10
000076bac53e310d  movaps [rsp+0x10], xmm14
000076bac53e3113  movaps [rsp+0x20], xmm4
000076bac53e3118  lea rdi, [rsp]
000076bac53e311c  mov esi, 0x00
000076bac53e3121  mov rax, 0x5641B0A3C530
000076bac53e312b  call rax
000076bac53e312d  movaps xmm10, [rsp]
000076bac53e3132  add rsp, 0x30
000076bac53e3136  vmovaps xmm0, [rsp]
000076bac53e313b  vmovaps xmm1, [rsp+0x10]
000076bac53e3141  vmovaps xmm2, [rsp+0x20]
000076bac53e3147  vmovaps xmm3, [rsp+0x30]
000076bac53e314d  vmovaps xmm4, [rsp+0x40]
000076bac53e3153  vmovaps xmm5, [rsp+0x50]
000076bac53e3159  vmovaps xmm6, [rsp+0x60]
000076bac53e315f  vmovaps xmm7, [rsp+0x70]
000076bac53e3165  vmovaps xmm8, [rsp+0x80]
000076bac53e316e  vmovaps xmm9, [rsp+0x90]
000076bac53e3177  vmovaps xmm11, [rsp+0xA0]
000076bac53e3180  vmovaps xmm12, [rsp+0xB0]
000076bac53e3189  vmovaps xmm13, [rsp+0xC0]
000076bac53e3192  vmovaps xmm14, [rsp+0xD0]
000076bac53e319b  vmovaps xmm15, [rsp+0xE0]
000076bac53e31a4  add rsp, 0xF0
000076bac53e31ab  pop r11
000076bac53e31ad  pop r10
000076bac53e31af  pop r9
000076bac53e31b1  pop r8
000076bac53e31b3  pop rsi
000076bac53e31b4  pop rdi
000076bac53e31b5  pop rdx
000076bac53e31b6  pop rcx
000076bac53e31b7  pop rax
000076bac53e31b8  add rsp, 0x08
000076bac53e31bc  jmp 0x000076BAC53DF71B
000076bac53e31c1  sub rsp, 0x08
000076bac53e31c5  push rax
000076bac53e31c6  push rcx
000076bac53e31c7  push rdx
000076bac53e31c8  push rdi
000076bac53e31c9  push rsi
000076bac53e31ca  push r8
000076bac53e31cc  push r9
000076bac53e31ce  push r10
000076bac53e31d0  push r11
000076bac53e31d2  sub rsp, 0xF0
000076bac53e31d9  vmovaps [rsp], xmm0
000076bac53e31de  vmovaps [rsp+0x10], xmm1
000076bac53e31e4  vmovaps [rsp+0x20], xmm2
000076bac53e31ea  vmovaps [rsp+0x30], xmm3
000076bac53e31f0  vmovaps [rsp+0x40], xmm4
000076bac53e31f6  vmovaps [rsp+0x50], xmm5
000076bac53e31fc  vmovaps [rsp+0x60], xmm6
000076bac53e3202  vmovaps [rsp+0x70], xmm7
000076bac53e3208  vmovaps [rsp+0x80], xmm9
000076bac53e3211  vmovaps [rsp+0x90], xmm10
000076bac53e321a  vmovaps [rsp+0xA0], xmm11
000076bac53e3223  vmovaps [rsp+0xB0], xmm12
000076bac53e322c  vmovaps [rsp+0xC0], xmm13
000076bac53e3235  vmovaps [rsp+0xD0], xmm14
000076bac53e323e  vmovaps [rsp+0xE0], xmm15
000076bac53e3247  sub rsp, 0x30
000076bac53e324b  movaps [rsp], xmm8
000076bac53e3250  movaps [rsp+0x10], xmm1
000076bac53e3255  movaps [rsp+0x20], xmm14
000076bac53e325b  lea rdi, [rsp]
000076bac53e325f  mov esi, 0x00
000076bac53e3264  mov rax, 0x5641B0A3C530
000076bac53e326e  call rax
000076bac53e3270  movaps xmm8, [rsp]
000076bac53e3275  add rsp, 0x30
000076bac53e3279  vmovaps xmm0, [rsp]
000076bac53e327e  vmovaps xmm1, [rsp+0x10]
000076bac53e3284  vmovaps xmm2, [rsp+0x20]
000076bac53e328a  vmovaps xmm3, [rsp+0x30]
000076bac53e3290  vmovaps xmm4, [rsp+0x40]
000076bac53e3296  vmovaps xmm5, [rsp+0x50]
000076bac53e329c  vmovaps xmm6, [rsp+0x60]
000076bac53e32a2  vmovaps xmm7, [rsp+0x70]
000076bac53e32a8  vmovaps xmm9, [rsp+0x80]
000076bac53e32b1  vmovaps xmm10, [rsp+0x90]
000076bac53e32ba  vmovaps xmm11, [rsp+0xA0]
000076bac53e32c3  vmovaps xmm12, [rsp+0xB0]
000076bac53e32cc  vmovaps xmm13, [rsp+0xC0]
000076bac53e32d5  vmovaps xmm14, [rsp+0xD0]
000076bac53e32de  vmovaps xmm15, [rsp+0xE0]
000076bac53e32e7  add rsp, 0xF0
000076bac53e32ee  pop r11
000076bac53e32f0  pop r10
000076bac53e32f2  pop r9
000076bac53e32f4  pop r8
000076bac53e32f6  pop rsi
000076bac53e32f7  pop rdi
000076bac53e32f8  pop rdx
000076bac53e32f9  pop rcx
000076bac53e32fa  pop rax
000076bac53e32fb  add rsp, 0x08
000076bac53e32ff  jmp 0x000076BAC53DF741
000076bac53e3304  sub rsp, 0x08
000076bac53e3308  push rax
000076bac53e3309  push rcx
000076bac53e330a  push rdx
000076bac53e330b  push rdi
000076bac53e330c  push rsi
000076bac53e330d  push r8
000076bac53e330f  push r9
000076bac53e3311  push r10
000076bac53e3313  push r11
000076bac53e3315  sub rsp, 0xF0
000076bac53e331c  vmovaps [rsp], xmm0
000076bac53e3321  vmovaps [rsp+0x10], xmm1
000076bac53e3327  vmovaps [rsp+0x20], xmm2
000076bac53e332d  vmovaps [rsp+0x30], xmm3
000076bac53e3333  vmovaps [rsp+0x40], xmm4
000076bac53e3339  vmovaps [rsp+0x50], xmm5
000076bac53e333f  vmovaps [rsp+0x60], xmm7
000076bac53e3345  vmovaps [rsp+0x70], xmm8
000076bac53e334b  vmovaps [rsp+0x80], xmm9
000076bac53e3354  vmovaps [rsp+0x90], xmm10
000076bac53e335d  vmovaps [rsp+0xA0], xmm11
000076bac53e3366  vmovaps [rsp+0xB0], xmm12
000076bac53e336f  vmovaps [rsp+0xC0], xmm13
000076bac53e3378  vmovaps [rsp+0xD0], xmm14
000076bac53e3381  vmovaps [rsp+0xE0], xmm15
000076bac53e338a  sub rsp, 0x30
000076bac53e338e  movaps [rsp], xmm6
000076bac53e3392  movaps [rsp+0x10], xmm1
000076bac53e3397  movaps [rsp+0x20], xmm14
000076bac53e339d  lea rdi, [rsp]
000076bac53e33a1  mov esi, 0x00
000076bac53e33a6  mov rax, 0x5641B0A3C530
000076bac53e33b0  call rax
000076bac53e33b2  movaps xmm6, [rsp]
000076bac53e33b6  add rsp, 0x30
000076bac53e33ba  vmovaps xmm0, [rsp]
000076bac53e33bf  vmovaps xmm1, [rsp+0x10]
000076bac53e33c5  vmovaps xmm2, [rsp+0x20]
000076bac53e33cb  vmovaps xmm3, [rsp+0x30]
000076bac53e33d1  vmovaps xmm4, [rsp+0x40]
000076bac53e33d7  vmovaps xmm5, [rsp+0x50]
000076bac53e33dd  vmovaps xmm7, [rsp+0x60]
000076bac53e33e3  vmovaps xmm8, [rsp+0x70]
000076bac53e33e9  vmovaps xmm9, [rsp+0x80]
000076bac53e33f2  vmovaps xmm10, [rsp+0x90]
000076bac53e33fb  vmovaps xmm11, [rsp+0xA0]
000076bac53e3404  vmovaps xmm12, [rsp+0xB0]
000076bac53e340d  vmovaps xmm13, [rsp+0xC0]
000076bac53e3416  vmovaps xmm14, [rsp+0xD0]
000076bac53e341f  vmovaps xmm15, [rsp+0xE0]
000076bac53e3428  add rsp, 0xF0
000076bac53e342f  pop r11
000076bac53e3431  pop r10
000076bac53e3433  pop r9
000076bac53e3435  pop r8
000076bac53e3437  pop rsi
000076bac53e3438  pop rdi
000076bac53e3439  pop rdx
000076bac53e343a  pop rcx
000076bac53e343b  pop rax
000076bac53e343c  add rsp, 0x08
000076bac53e3440  jmp 0x000076BAC53DF76D
000076bac53e3445  sub rsp, 0x08
000076bac53e3449  push rax
000076bac53e344a  push rcx
000076bac53e344b  push rdx
000076bac53e344c  push rdi
000076bac53e344d  push rsi
000076bac53e344e  push r8
000076bac53e3450  push r9
000076bac53e3452  push r10
000076bac53e3454  push r11
000076bac53e3456  sub rsp, 0xF0
000076bac53e345d  vmovaps [rsp], xmm0
000076bac53e3462  vmovaps [rsp+0x10], xmm1
000076bac53e3468  vmovaps [rsp+0x20], xmm2
000076bac53e346e  vmovaps [rsp+0x30], xmm3
000076bac53e3474  vmovaps [rsp+0x40], xmm4
000076bac53e347a  vmovaps [rsp+0x50], xmm5
000076bac53e3480  vmovaps [rsp+0x60], xmm6
000076bac53e3486  vmovaps [rsp+0x70], xmm7
000076bac53e348c  vmovaps [rsp+0x80], xmm8
000076bac53e3495  vmovaps [rsp+0x90], xmm9
000076bac53e349e  vmovaps [rsp+0xA0], xmm10
000076bac53e34a7  vmovaps [rsp+0xB0], xmm11
000076bac53e34b0  vmovaps [rsp+0xC0], xmm12
000076bac53e34b9  vmovaps [rsp+0xD0], xmm13
000076bac53e34c2  vmovaps [rsp+0xE0], xmm15
000076bac53e34cb  sub rsp, 0x30
000076bac53e34cf  movaps [rsp], xmm14
000076bac53e34d4  movaps [rsp+0x10], xmm12
000076bac53e34da  movaps [rsp+0x20], xmm1
000076bac53e34df  lea rdi, [rsp]
000076bac53e34e3  mov esi, 0x00
000076bac53e34e8  mov rax, 0x5641B0A3C530
000076bac53e34f2  call rax
000076bac53e34f4  movaps xmm14, [rsp]
000076bac53e34f9  add rsp, 0x30
000076bac53e34fd  vmovaps xmm0, [rsp]
000076bac53e3502  vmovaps xmm1, [rsp+0x10]
000076bac53e3508  vmovaps xmm2, [rsp+0x20]
000076bac53e350e  vmovaps xmm3, [rsp+0x30]
000076bac53e3514  vmovaps xmm4, [rsp+0x40]
000076bac53e351a  vmovaps xmm5, [rsp+0x50]
000076bac53e3520  vmovaps xmm6, [rsp+0x60]
000076bac53e3526  vmovaps xmm7, [rsp+0x70]
000076bac53e352c  vmovaps xmm8, [rsp+0x80]
000076bac53e3535  vmovaps xmm9, [rsp+0x90]
000076bac53e353e  vmovaps xmm10, [rsp+0xA0]
000076bac53e3547  vmovaps xmm11, [rsp+0xB0]
000076bac53e3550  vmovaps xmm12, [rsp+0xC0]
000076bac53e3559  vmovaps xmm13, [rsp+0xD0]
000076bac53e3562  vmovaps xmm15, [rsp+0xE0]
000076bac53e356b  add rsp, 0xF0
000076bac53e3572  pop r11
000076bac53e3574  pop r10
000076bac53e3576  pop r9
000076bac53e3578  pop r8
000076bac53e357a  pop rsi
000076bac53e357b  pop rdi
000076bac53e357c  pop rdx
000076bac53e357d  pop rcx
000076bac53e357e  pop rax
000076bac53e357f  add rsp, 0x08
000076bac53e3583  jmp 0x000076BAC53DF793
000076bac53e3588  sub rsp, 0x08
000076bac53e358c  push rax
000076bac53e358d  push rcx
000076bac53e358e  push rdx
000076bac53e358f  push rdi
000076bac53e3590  push rsi
000076bac53e3591  push r8
000076bac53e3593  push r9
000076bac53e3595  push r10
000076bac53e3597  push r11
000076bac53e3599  sub rsp, 0xF0
000076bac53e35a0  vmovaps [rsp], xmm0
000076bac53e35a5  vmovaps [rsp+0x10], xmm2
000076bac53e35ab  vmovaps [rsp+0x20], xmm3
000076bac53e35b1  vmovaps [rsp+0x30], xmm4
000076bac53e35b7  vmovaps [rsp+0x40], xmm5
000076bac53e35bd  vmovaps [rsp+0x50], xmm6
000076bac53e35c3  vmovaps [rsp+0x60], xmm7
000076bac53e35c9  vmovaps [rsp+0x70], xmm8
000076bac53e35cf  vmovaps [rsp+0x80], xmm9
000076bac53e35d8  vmovaps [rsp+0x90], xmm10
000076bac53e35e1  vmovaps [rsp+0xA0], xmm11
000076bac53e35ea  vmovaps [rsp+0xB0], xmm12
000076bac53e35f3  vmovaps [rsp+0xC0], xmm13
000076bac53e35fc  vmovaps [rsp+0xD0], xmm14
000076bac53e3605  vmovaps [rsp+0xE0], xmm15
000076bac53e360e  sub rsp, 0x30
000076bac53e3612  movaps [rsp], xmm1
000076bac53e3616  movaps [rsp+0x10], xmm13
000076bac53e361c  movaps [rsp+0x20], xmm9
000076bac53e3622  lea rdi, [rsp]
000076bac53e3626  mov esi, 0x00
000076bac53e362b  mov rax, 0x5641B0A3C530
000076bac53e3635  call rax
000076bac53e3637  movaps xmm1, [rsp]
000076bac53e363b  add rsp, 0x30
000076bac53e363f  vmovaps xmm0, [rsp]
000076bac53e3644  vmovaps xmm2, [rsp+0x10]
000076bac53e364a  vmovaps xmm3, [rsp+0x20]
000076bac53e3650  vmovaps xmm4, [rsp+0x30]
000076bac53e3656  vmovaps xmm5, [rsp+0x40]
000076bac53e365c  vmovaps xmm6, [rsp+0x50]
000076bac53e3662  vmovaps xmm7, [rsp+0x60]
000076bac53e3668  vmovaps xmm8, [rsp+0x70]
000076bac53e366e  vmovaps xmm9, [rsp+0x80]
000076bac53e3677  vmovaps xmm10, [rsp+0x90]
000076bac53e3680  vmovaps xmm11, [rsp+0xA0]
000076bac53e3689  vmovaps xmm12, [rsp+0xB0]
000076bac53e3692  vmovaps xmm13, [rsp+0xC0]
000076bac53e369b  vmovaps xmm14, [rsp+0xD0]
000076bac53e36a4  vmovaps xmm15, [rsp+0xE0]
000076bac53e36ad  add rsp, 0xF0
000076bac53e36b4  pop r11
000076bac53e36b6  pop r10
000076bac53e36b8  pop r9
000076bac53e36ba  pop r8
000076bac53e36bc  pop rsi
000076bac53e36bd  pop rdi
000076bac53e36be  pop rdx
000076bac53e36bf  pop rcx
000076bac53e36c0  pop rax
000076bac53e36c1  add rsp, 0x08
000076bac53e36c5  jmp 0x000076BAC53DF7AD
000076bac53e36ca  sub rsp, 0x08
000076bac53e36ce  push rax
000076bac53e36cf  push rcx
000076bac53e36d0  push rdx
000076bac53e36d1  push rdi
000076bac53e36d2  push rsi
000076bac53e36d3  push r8
000076bac53e36d5  push r9
000076bac53e36d7  push r10
000076bac53e36d9  push r11
000076bac53e36db  sub rsp, 0xF0
000076bac53e36e2  vmovaps [rsp], xmm0
000076bac53e36e7  vmovaps [rsp+0x10], xmm1
000076bac53e36ed  vmovaps [rsp+0x20], xmm2
000076bac53e36f3  vmovaps [rsp+0x30], xmm3
000076bac53e36f9  vmovaps [rsp+0x40], xmm4
000076bac53e36ff  vmovaps [rsp+0x50], xmm5
000076bac53e3705  vmovaps [rsp+0x60], xmm6
000076bac53e370b  vmovaps [rsp+0x70], xmm7
000076bac53e3711  vmovaps [rsp+0x80], xmm8
000076bac53e371a  vmovaps [rsp+0x90], xmm9
000076bac53e3723  vmovaps [rsp+0xA0], xmm10
000076bac53e372c  vmovaps [rsp+0xB0], xmm11
000076bac53e3735  vmovaps [rsp+0xC0], xmm13
000076bac53e373e  vmovaps [rsp+0xD0], xmm14
000076bac53e3747  vmovaps [rsp+0xE0], xmm15
000076bac53e3750  sub rsp, 0x30
000076bac53e3754  movaps [rsp], xmm12
000076bac53e3759  movaps [rsp+0x10], xmm7
000076bac53e375e  movaps [rsp+0x20], xmm13
000076bac53e3764  lea rdi, [rsp]
000076bac53e3768  mov esi, 0x00
000076bac53e376d  mov rax, 0x5641B0A3C530
000076bac53e3777  call rax
000076bac53e3779  movaps xmm12, [rsp]
000076bac53e377e  add rsp, 0x30
000076bac53e3782  vmovaps xmm0, [rsp]
000076bac53e3787  vmovaps xmm1, [rsp+0x10]
000076bac53e378d  vmovaps xmm2, [rsp+0x20]
000076bac53e3793  vmovaps xmm3, [rsp+0x30]
000076bac53e3799  vmovaps xmm4, [rsp+0x40]
000076bac53e379f  vmovaps xmm5, [rsp+0x50]
000076bac53e37a5  vmovaps xmm6, [rsp+0x60]
000076bac53e37ab  vmovaps xmm7, [rsp+0x70]
000076bac53e37b1  vmovaps xmm8, [rsp+0x80]
000076bac53e37ba  vmovaps xmm9, [rsp+0x90]
000076bac53e37c3  vmovaps xmm10, [rsp+0xA0]
000076bac53e37cc  vmovaps xmm11, [rsp+0xB0]
000076bac53e37d5  vmovaps xmm13, [rsp+0xC0]
000076bac53e37de  vmovaps xmm14, [rsp+0xD0]
000076bac53e37e7  vmovaps xmm15, [rsp+0xE0]
000076bac53e37f0  add rsp, 0xF0
000076bac53e37f7  pop r11
000076bac53e37f9  pop r10
000076bac53e37fb  pop r9
000076bac53e37fd  pop r8
000076bac53e37ff  pop rsi
000076bac53e3800  pop rdi
000076bac53e3801  pop rdx
000076bac53e3802  pop rcx
000076bac53e3803  pop rax
000076bac53e3804  add rsp, 0x08
000076bac53e3808  jmp 0x000076BAC53DF7D4
000076bac53e380d  sub rsp, 0x08
000076bac53e3811  push rax
000076bac53e3812  push rcx
000076bac53e3813  push rdx
000076bac53e3814  push rdi
000076bac53e3815  push rsi
000076bac53e3816  push r8
000076bac53e3818  push r9
000076bac53e381a  push r10
000076bac53e381c  push r11
000076bac53e381e  sub rsp, 0xF0
000076bac53e3825  vmovaps [rsp], xmm0
000076bac53e382a  vmovaps [rsp+0x10], xmm1
000076bac53e3830  vmovaps [rsp+0x20], xmm2
000076bac53e3836  vmovaps [rsp+0x30], xmm3
000076bac53e383c  vmovaps [rsp+0x40], xmm4
000076bac53e3842  vmovaps [rsp+0x50], xmm5
000076bac53e3848  vmovaps [rsp+0x60], xmm6
000076bac53e384e  vmovaps [rsp+0x70], xmm7
000076bac53e3854  vmovaps [rsp+0x80], xmm8
000076bac53e385d  vmovaps [rsp+0x90], xmm9
000076bac53e3866  vmovaps [rsp+0xA0], xmm10
000076bac53e386f  vmovaps [rsp+0xB0], xmm11
000076bac53e3878  vmovaps [rsp+0xC0], xmm12
000076bac53e3881  vmovaps [rsp+0xD0], xmm14
000076bac53e388a  vmovaps [rsp+0xE0], xmm15
000076bac53e3893  sub rsp, 0x30
000076bac53e3897  movaps [rsp], xmm13
000076bac53e389c  movaps [rsp+0x10], xmm15
000076bac53e38a2  movaps [rsp+0x20], xmm8
000076bac53e38a8  lea rdi, [rsp]
000076bac53e38ac  mov esi, 0x00
000076bac53e38b1  mov rax, 0x5641B0A3C530
000076bac53e38bb  call rax
000076bac53e38bd  movaps xmm13, [rsp]
000076bac53e38c2  add rsp, 0x30
000076bac53e38c6  vmovaps xmm0, [rsp]
000076bac53e38cb  vmovaps xmm1, [rsp+0x10]
000076bac53e38d1  vmovaps xmm2, [rsp+0x20]
000076bac53e38d7  vmovaps xmm3, [rsp+0x30]
000076bac53e38dd  vmovaps xmm4, [rsp+0x40]
000076bac53e38e3  vmovaps xmm5, [rsp+0x50]
000076bac53e38e9  vmovaps xmm6, [rsp+0x60]
000076bac53e38ef  vmovaps xmm7, [rsp+0x70]
000076bac53e38f5  vmovaps xmm8, [rsp+0x80]
000076bac53e38fe  vmovaps xmm9, [rsp+0x90]
000076bac53e3907  vmovaps xmm10, [rsp+0xA0]
000076bac53e3910  vmovaps xmm11, [rsp+0xB0]
000076bac53e3919  vmovaps xmm12, [rsp+0xC0]
000076bac53e3922  vmovaps xmm14, [rsp+0xD0]
000076bac53e392b  vmovaps xmm15, [rsp+0xE0]
000076bac53e3934  add rsp, 0xF0
000076bac53e393b  pop r11
000076bac53e393d  pop r10
000076bac53e393f  pop r9
000076bac53e3941  pop r8
000076bac53e3943  pop rsi
000076bac53e3944  pop rdi
000076bac53e3945  pop rdx
000076bac53e3946  pop rcx
000076bac53e3947  pop rax
000076bac53e3948  add rsp, 0x08
000076bac53e394c  jmp 0x000076BAC53DF7EF
000076bac53e3951  sub rsp, 0x08
000076bac53e3955  push rax
000076bac53e3956  push rcx
000076bac53e3957  push rdx
000076bac53e3958  push rdi
000076bac53e3959  push rsi
000076bac53e395a  push r8
000076bac53e395c  push r9
000076bac53e395e  push r10
000076bac53e3960  push r11
000076bac53e3962  sub rsp, 0xF0
000076bac53e3969  vmovaps [rsp], xmm0
000076bac53e396e  vmovaps [rsp+0x10], xmm1
000076bac53e3974  vmovaps [rsp+0x20], xmm2
000076bac53e397a  vmovaps [rsp+0x30], xmm3
000076bac53e3980  vmovaps [rsp+0x40], xmm4
000076bac53e3986  vmovaps [rsp+0x50], xmm5
000076bac53e398c  vmovaps [rsp+0x60], xmm6
000076bac53e3992  vmovaps [rsp+0x70], xmm7
000076bac53e3998  vmovaps [rsp+0x80], xmm9
000076bac53e39a1  vmovaps [rsp+0x90], xmm10
000076bac53e39aa  vmovaps [rsp+0xA0], xmm11
000076bac53e39b3  vmovaps [rsp+0xB0], xmm12
000076bac53e39bc  vmovaps [rsp+0xC0], xmm13
000076bac53e39c5  vmovaps [rsp+0xD0], xmm14
000076bac53e39ce  vmovaps [rsp+0xE0], xmm15
000076bac53e39d7  sub rsp, 0x30
000076bac53e39db  movaps [rsp], xmm8
000076bac53e39e0  movaps [rsp+0x10], xmm15
000076bac53e39e6  movaps [rsp+0x20], xmm9
000076bac53e39ec  lea rdi, [rsp]
000076bac53e39f0  mov esi, 0x00
000076bac53e39f5  mov rax, 0x5641B0A3C530
000076bac53e39ff  call rax
000076bac53e3a01  movaps xmm8, [rsp]
000076bac53e3a06  add rsp, 0x30
000076bac53e3a0a  vmovaps xmm0, [rsp]
000076bac53e3a0f  vmovaps xmm1, [rsp+0x10]
000076bac53e3a15  vmovaps xmm2, [rsp+0x20]
000076bac53e3a1b  vmovaps xmm3, [rsp+0x30]
000076bac53e3a21  vmovaps xmm4, [rsp+0x40]
000076bac53e3a27  vmovaps xmm5, [rsp+0x50]
000076bac53e3a2d  vmovaps xmm6, [rsp+0x60]
000076bac53e3a33  vmovaps xmm7, [rsp+0x70]
000076bac53e3a39  vmovaps xmm9, [rsp+0x80]
000076bac53e3a42  vmovaps xmm10, [rsp+0x90]
000076bac53e3a4b  vmovaps xmm11, [rsp+0xA0]
000076bac53e3a54  vmovaps xmm12, [rsp+0xB0]
000076bac53e3a5d  vmovaps xmm13, [rsp+0xC0]
000076bac53e3a66  vmovaps xmm14, [rsp+0xD0]
000076bac53e3a6f  vmovaps xmm15, [rsp+0xE0]
000076bac53e3a78  add rsp, 0xF0
000076bac53e3a7f  pop r11
000076bac53e3a81  pop r10
000076bac53e3a83  pop r9
000076bac53e3a85  pop r8
000076bac53e3a87  pop rsi
000076bac53e3a88  pop rdi
000076bac53e3a89  pop rdx
000076bac53e3a8a  pop rcx
000076bac53e3a8b  pop rax
000076bac53e3a8c  add rsp, 0x08
000076bac53e3a90  jmp 0x000076BAC53DF81D
000076bac53e3a95  sub rsp, 0x08
000076bac53e3a99  push rax
000076bac53e3a9a  push rcx
000076bac53e3a9b  push rdx
000076bac53e3a9c  push rdi
000076bac53e3a9d  push rsi
000076bac53e3a9e  push r8
000076bac53e3aa0  push r9
000076bac53e3aa2  push r10
000076bac53e3aa4  push r11
000076bac53e3aa6  sub rsp, 0xF0
000076bac53e3aad  vmovaps [rsp], xmm0
000076bac53e3ab2  vmovaps [rsp+0x10], xmm1
000076bac53e3ab8  vmovaps [rsp+0x20], xmm2
000076bac53e3abe  vmovaps [rsp+0x30], xmm3
000076bac53e3ac4  vmovaps [rsp+0x40], xmm4
000076bac53e3aca  vmovaps [rsp+0x50], xmm5
000076bac53e3ad0  vmovaps [rsp+0x60], xmm6
000076bac53e3ad6  vmovaps [rsp+0x70], xmm7
000076bac53e3adc  vmovaps [rsp+0x80], xmm8
000076bac53e3ae5  vmovaps [rsp+0x90], xmm9
000076bac53e3aee  vmovaps [rsp+0xA0], xmm10
000076bac53e3af7  vmovaps [rsp+0xB0], xmm11
000076bac53e3b00  vmovaps [rsp+0xC0], xmm12
000076bac53e3b09  vmovaps [rsp+0xD0], xmm13
000076bac53e3b12  vmovaps [rsp+0xE0], xmm14
000076bac53e3b1b  sub rsp, 0x30
000076bac53e3b1f  movaps [rsp], xmm15
000076bac53e3b24  movaps [rsp+0x10], xmm11
000076bac53e3b2a  movaps [rsp+0x20], xmm6
000076bac53e3b2f  lea rdi, [rsp]
000076bac53e3b33  mov esi, 0x00
000076bac53e3b38  mov rax, 0x5641B0A3C530
000076bac53e3b42  call rax
000076bac53e3b44  movaps xmm15, [rsp]
000076bac53e3b49  add rsp, 0x30
000076bac53e3b4d  vmovaps xmm0, [rsp]
000076bac53e3b52  vmovaps xmm1, [rsp+0x10]
000076bac53e3b58  vmovaps xmm2, [rsp+0x20]
000076bac53e3b5e  vmovaps xmm3, [rsp+0x30]
000076bac53e3b64  vmovaps xmm4, [rsp+0x40]
000076bac53e3b6a  vmovaps xmm5, [rsp+0x50]
000076bac53e3b70  vmovaps xmm6, [rsp+0x60]
000076bac53e3b76  vmovaps xmm7, [rsp+0x70]
000076bac53e3b7c  vmovaps xmm8, [rsp+0x80]
000076bac53e3b85  vmovaps xmm9, [rsp+0x90]
000076bac53e3b8e  vmovaps xmm10, [rsp+0xA0]
000076bac53e3b97  vmovaps xmm11, [rsp+0xB0]
000076bac53e3ba0  vmovaps xmm12, [rsp+0xC0]
000076bac53e3ba9  vmovaps xmm13, [rsp+0xD0]
000076bac53e3bb2  vmovaps xmm14, [rsp+0xE0]
000076bac53e3bbb  add rsp, 0xF0
000076bac53e3bc2  pop r11
000076bac53e3bc4  pop r10
000076bac53e3bc6  pop r9
000076bac53e3bc8  pop r8
000076bac53e3bca  pop rsi
000076bac53e3bcb  pop rdi
000076bac53e3bcc  pop rdx
000076bac53e3bcd  pop rcx
000076bac53e3bce  pop rax
000076bac53e3bcf  add rsp, 0x08
000076bac53e3bd3  jmp 0x000076BAC53DF838
000076bac53e3bd8  sub rsp, 0x08
000076bac53e3bdc  push rax
000076bac53e3bdd  push rcx
000076bac53e3bde  push rdx
000076bac53e3bdf  push rdi
000076bac53e3be0  push rsi
000076bac53e3be1  push r8
000076bac53e3be3  push r9
000076bac53e3be5  push r10
000076bac53e3be7  push r11
000076bac53e3be9  sub rsp, 0xF0
000076bac53e3bf0  vmovaps [rsp], xmm0
000076bac53e3bf5  vmovaps [rsp+0x10], xmm1
000076bac53e3bfb  vmovaps [rsp+0x20], xmm2
000076bac53e3c01  vmovaps [rsp+0x30], xmm3
000076bac53e3c07  vmovaps [rsp+0x40], xmm4
000076bac53e3c0d  vmovaps [rsp+0x50], xmm5
000076bac53e3c13  vmovaps [rsp+0x60], xmm6
000076bac53e3c19  vmovaps [rsp+0x70], xmm8
000076bac53e3c1f  vmovaps [rsp+0x80], xmm9
000076bac53e3c28  vmovaps [rsp+0x90], xmm10
000076bac53e3c31  vmovaps [rsp+0xA0], xmm11
000076bac53e3c3a  vmovaps [rsp+0xB0], xmm12
000076bac53e3c43  vmovaps [rsp+0xC0], xmm13
000076bac53e3c4c  vmovaps [rsp+0xD0], xmm14
000076bac53e3c55  vmovaps [rsp+0xE0], xmm15
000076bac53e3c5e  sub rsp, 0x30
000076bac53e3c62  movaps [rsp], xmm7
000076bac53e3c66  movaps [rsp+0x10], xmm11
000076bac53e3c6c  movaps [rsp+0x20], xmm9
000076bac53e3c72  lea rdi, [rsp]
000076bac53e3c76  mov esi, 0x00
000076bac53e3c7b  mov rax, 0x5641B0A3C530
000076bac53e3c85  call rax
000076bac53e3c87  movaps xmm7, [rsp]
000076bac53e3c8b  add rsp, 0x30
000076bac53e3c8f  vmovaps xmm0, [rsp]
000076bac53e3c94  vmovaps xmm1, [rsp+0x10]
000076bac53e3c9a  vmovaps xmm2, [rsp+0x20]
000076bac53e3ca0  vmovaps xmm3, [rsp+0x30]
000076bac53e3ca6  vmovaps xmm4, [rsp+0x40]
000076bac53e3cac  vmovaps xmm5, [rsp+0x50]
000076bac53e3cb2  vmovaps xmm6, [rsp+0x60]
000076bac53e3cb8  vmovaps xmm8, [rsp+0x70]
000076bac53e3cbe  vmovaps xmm9, [rsp+0x80]
000076bac53e3cc7  vmovaps xmm10, [rsp+0x90]
000076bac53e3cd0  vmovaps xmm11, [rsp+0xA0]
000076bac53e3cd9  vmovaps xmm12, [rsp+0xB0]
000076bac53e3ce2  vmovaps xmm13, [rsp+0xC0]
000076bac53e3ceb  vmovaps xmm14, [rsp+0xD0]
000076bac53e3cf4  vmovaps xmm15, [rsp+0xE0]
000076bac53e3cfd  add rsp, 0xF0
000076bac53e3d04  pop r11
000076bac53e3d06  pop r10
000076bac53e3d08  pop r9
000076bac53e3d0a  pop r8
000076bac53e3d0c  pop rsi
000076bac53e3d0d  pop rdi
000076bac53e3d0e  pop rdx
000076bac53e3d0f  pop rcx
000076bac53e3d10  pop rax
000076bac53e3d11  add rsp, 0x08
000076bac53e3d15  jmp 0x000076BAC53DF865
000076bac53e3d1a  sub rsp, 0x08
000076bac53e3d1e  push rax
000076bac53e3d1f  push rcx
000076bac53e3d20  push rdx
000076bac53e3d21  push rdi
000076bac53e3d22  push rsi
000076bac53e3d23  push r8
000076bac53e3d25  push r9
000076bac53e3d27  push r10
000076bac53e3d29  push r11
000076bac53e3d2b  sub rsp, 0xF0
000076bac53e3d32  vmovaps [rsp], xmm0
000076bac53e3d37  vmovaps [rsp+0x10], xmm1
000076bac53e3d3d  vmovaps [rsp+0x20], xmm2
000076bac53e3d43  vmovaps [rsp+0x30], xmm3
000076bac53e3d49  vmovaps [rsp+0x40], xmm4
000076bac53e3d4f  vmovaps [rsp+0x50], xmm5
000076bac53e3d55  vmovaps [rsp+0x60], xmm6
000076bac53e3d5b  vmovaps [rsp+0x70], xmm7
000076bac53e3d61  vmovaps [rsp+0x80], xmm8
000076bac53e3d6a  vmovaps [rsp+0x90], xmm9
000076bac53e3d73  vmovaps [rsp+0xA0], xmm10
000076bac53e3d7c  vmovaps [rsp+0xB0], xmm12
000076bac53e3d85  vmovaps [rsp+0xC0], xmm13
000076bac53e3d8e  vmovaps [rsp+0xD0], xmm14
000076bac53e3d97  vmovaps [rsp+0xE0], xmm15
000076bac53e3da0  sub rsp, 0x30
000076bac53e3da4  movaps [rsp], xmm11
000076bac53e3da9  movaps [rsp+0x10], xmm10
000076bac53e3daf  movaps [rsp+0x20], xmm14
000076bac53e3db5  lea rdi, [rsp]
000076bac53e3db9  mov esi, 0x00
000076bac53e3dbe  mov rax, 0x5641B0A3C530
000076bac53e3dc8  call rax
000076bac53e3dca  movaps xmm11, [rsp]
000076bac53e3dcf  add rsp, 0x30
000076bac53e3dd3  vmovaps xmm0, [rsp]
000076bac53e3dd8  vmovaps xmm1, [rsp+0x10]
000076bac53e3dde  vmovaps xmm2, [rsp+0x20]
000076bac53e3de4  vmovaps xmm3, [rsp+0x30]
000076bac53e3dea  vmovaps xmm4, [rsp+0x40]
000076bac53e3df0  vmovaps xmm5, [rsp+0x50]
000076bac53e3df6  vmovaps xmm6, [rsp+0x60]
000076bac53e3dfc  vmovaps xmm7, [rsp+0x70]
000076bac53e3e02  vmovaps xmm8, [rsp+0x80]
000076bac53e3e0b  vmovaps xmm9, [rsp+0x90]
000076bac53e3e14  vmovaps xmm10, [rsp+0xA0]
000076bac53e3e1d  vmovaps xmm12, [rsp+0xB0]
000076bac53e3e26  vmovaps xmm13, [rsp+0xC0]
000076bac53e3e2f  vmovaps xmm14, [rsp+0xD0]
000076bac53e3e38  vmovaps xmm15, [rsp+0xE0]
000076bac53e3e41  add rsp, 0xF0
000076bac53e3e48  pop r11
000076bac53e3e4a  pop r10
000076bac53e3e4c  pop r9
000076bac53e3e4e  pop r8
000076bac53e3e50  pop rsi
000076bac53e3e51  pop rdi
000076bac53e3e52  pop rdx
000076bac53e3e53  pop rcx
000076bac53e3e54  pop rax
000076bac53e3e55  add rsp, 0x08
000076bac53e3e59  jmp 0x000076BAC53DF880
000076bac53e3e5e  call 0x000076BAC52C33A0
000076bac53e3e63  jmp 0x000076BAC53DF88A
000076bac53e3e68  sub rsp, 0x08
000076bac53e3e6c  push rax
000076bac53e3e6d  push rcx
000076bac53e3e6e  push rdx
000076bac53e3e6f  push rdi
000076bac53e3e70  push rsi
000076bac53e3e71  push r8
000076bac53e3e73  push r9
000076bac53e3e75  push r10
000076bac53e3e77  push r11
000076bac53e3e79  sub rsp, 0xF0
000076bac53e3e80  vmovaps [rsp], xmm0
000076bac53e3e85  vmovaps [rsp+0x10], xmm1
000076bac53e3e8b  vmovaps [rsp+0x20], xmm2
000076bac53e3e91  vmovaps [rsp+0x30], xmm3
000076bac53e3e97  vmovaps [rsp+0x40], xmm4
000076bac53e3e9d  vmovaps [rsp+0x50], xmm5
000076bac53e3ea3  vmovaps [rsp+0x60], xmm6
000076bac53e3ea9  vmovaps [rsp+0x70], xmm7
000076bac53e3eaf  vmovaps [rsp+0x80], xmm8
000076bac53e3eb8  vmovaps [rsp+0x90], xmm9
000076bac53e3ec1  vmovaps [rsp+0xA0], xmm11
000076bac53e3eca  vmovaps [rsp+0xB0], xmm12
000076bac53e3ed3  vmovaps [rsp+0xC0], xmm13
000076bac53e3edc  vmovaps [rsp+0xD0], xmm14
000076bac53e3ee5  vmovaps [rsp+0xE0], xmm15
000076bac53e3eee  sub rsp, 0x30
000076bac53e3ef2  movaps [rsp], xmm10
000076bac53e3ef7  movaps [rsp+0x10], xmm1
000076bac53e3efc  movaps [rsp+0x20], xmm12
000076bac53e3f02  lea rdi, [rsp]
000076bac53e3f06  mov esi, 0x00
000076bac53e3f0b  mov rax, 0x5641B0A3C530
000076bac53e3f15  call rax
000076bac53e3f17  movaps xmm10, [rsp]
000076bac53e3f1c  add rsp, 0x30
000076bac53e3f20  vmovaps xmm0, [rsp]
000076bac53e3f25  vmovaps xmm1, [rsp+0x10]
000076bac53e3f2b  vmovaps xmm2, [rsp+0x20]
000076bac53e3f31  vmovaps xmm3, [rsp+0x30]
000076bac53e3f37  vmovaps xmm4, [rsp+0x40]
000076bac53e3f3d  vmovaps xmm5, [rsp+0x50]
000076bac53e3f43  vmovaps xmm6, [rsp+0x60]
000076bac53e3f49  vmovaps xmm7, [rsp+0x70]
000076bac53e3f4f  vmovaps xmm8, [rsp+0x80]
000076bac53e3f58  vmovaps xmm9, [rsp+0x90]
000076bac53e3f61  vmovaps xmm11, [rsp+0xA0]
000076bac53e3f6a  vmovaps xmm12, [rsp+0xB0]
000076bac53e3f73  vmovaps xmm13, [rsp+0xC0]
000076bac53e3f7c  vmovaps xmm14, [rsp+0xD0]
000076bac53e3f85  vmovaps xmm15, [rsp+0xE0]
000076bac53e3f8e  add rsp, 0xF0
000076bac53e3f95  pop r11
000076bac53e3f97  pop r10
000076bac53e3f99  pop r9
000076bac53e3f9b  pop r8
000076bac53e3f9d  pop rsi
000076bac53e3f9e  pop rdi
000076bac53e3f9f  pop rdx
000076bac53e3fa0  pop rcx
000076bac53e3fa1  pop rax
000076bac53e3fa2  add rsp, 0x08
000076bac53e3fa6  jmp 0x000076BAC53DF8AD
000076bac53e3fab  sub rsp, 0x08
000076bac53e3faf  push rax
000076bac53e3fb0  push rcx
000076bac53e3fb1  push rdx
000076bac53e3fb2  push rdi
000076bac53e3fb3  push rsi
000076bac53e3fb4  push r8
000076bac53e3fb6  push r9
000076bac53e3fb8  push r10
000076bac53e3fba  push r11
000076bac53e3fbc  sub rsp, 0xF0
000076bac53e3fc3  vmovaps [rsp], xmm0
000076bac53e3fc8  vmovaps [rsp+0x10], xmm1
000076bac53e3fce  vmovaps [rsp+0x20], xmm2
000076bac53e3fd4  vmovaps [rsp+0x30], xmm3
000076bac53e3fda  vmovaps [rsp+0x40], xmm4
000076bac53e3fe0  vmovaps [rsp+0x50], xmm5
000076bac53e3fe6  vmovaps [rsp+0x60], xmm6
000076bac53e3fec  vmovaps [rsp+0x70], xmm7
000076bac53e3ff2  vmovaps [rsp+0x80], xmm8
000076bac53e3ffb  vmovaps [rsp+0x90], xmm9
000076bac53e4004  vmovaps [rsp+0xA0], xmm10
000076bac53e400d  vmovaps [rsp+0xB0], xmm11
000076bac53e4016  vmovaps [rsp+0xC0], xmm13
000076bac53e401f  vmovaps [rsp+0xD0], xmm14
000076bac53e4028  vmovaps [rsp+0xE0], xmm15
000076bac53e4031  sub rsp, 0x30
000076bac53e4035  movaps [rsp], xmm12
000076bac53e403a  movaps [rsp+0x10], xmm14
000076bac53e4040  movaps [rsp+0x20], xmm1
000076bac53e4045  lea rdi, [rsp]
000076bac53e4049  mov esi, 0x00
000076bac53e404e  mov rax, 0x5641B0A3C530
000076bac53e4058  call rax
000076bac53e405a  movaps xmm12, [rsp]
000076bac53e405f  add rsp, 0x30
000076bac53e4063  vmovaps xmm0, [rsp]
000076bac53e4068  vmovaps xmm1, [rsp+0x10]
000076bac53e406e  vmovaps xmm2, [rsp+0x20]
000076bac53e4074  vmovaps xmm3, [rsp+0x30]
000076bac53e407a  vmovaps xmm4, [rsp+0x40]
000076bac53e4080  vmovaps xmm5, [rsp+0x50]
000076bac53e4086  vmovaps xmm6, [rsp+0x60]
000076bac53e408c  vmovaps xmm7, [rsp+0x70]
000076bac53e4092  vmovaps xmm8, [rsp+0x80]
000076bac53e409b  vmovaps xmm9, [rsp+0x90]
000076bac53e40a4  vmovaps xmm10, [rsp+0xA0]
000076bac53e40ad  vmovaps xmm11, [rsp+0xB0]
000076bac53e40b6  vmovaps xmm13, [rsp+0xC0]
000076bac53e40bf  vmovaps xmm14, [rsp+0xD0]
000076bac53e40c8  vmovaps xmm15, [rsp+0xE0]
000076bac53e40d1  add rsp, 0xF0
000076bac53e40d8  pop r11
000076bac53e40da  pop r10
000076bac53e40dc  pop r9
000076bac53e40de  pop r8
000076bac53e40e0  pop rsi
000076bac53e40e1  pop rdi
000076bac53e40e2  pop rdx
000076bac53e40e3  pop rcx
000076bac53e40e4  pop rax
000076bac53e40e5  add rsp, 0x08
000076bac53e40e9  jmp 0x000076BAC53DF8DC
000076bac53e40ee  sub rsp, 0x08
000076bac53e40f2  push rax
000076bac53e40f3  push rcx
000076bac53e40f4  push rdx
000076bac53e40f5  push rdi
000076bac53e40f6  push rsi
000076bac53e40f7  push r8
000076bac53e40f9  push r9
000076bac53e40fb  push r10
000076bac53e40fd  push r11
000076bac53e40ff  sub rsp, 0xF0
000076bac53e4106  vmovaps [rsp], xmm0
000076bac53e410b  vmovaps [rsp+0x10], xmm1
000076bac53e4111  vmovaps [rsp+0x20], xmm2
000076bac53e4117  vmovaps [rsp+0x30], xmm3
000076bac53e411d  vmovaps [rsp+0x40], xmm4
000076bac53e4123  vmovaps [rsp+0x50], xmm5
000076bac53e4129  vmovaps [rsp+0x60], xmm6
000076bac53e412f  vmovaps [rsp+0x70], xmm7
000076bac53e4135  vmovaps [rsp+0x80], xmm8
000076bac53e413e  vmovaps [rsp+0x90], xmm9
000076bac53e4147  vmovaps [rsp+0xA0], xmm10
000076bac53e4150  vmovaps [rsp+0xB0], xmm11
000076bac53e4159  vmovaps [rsp+0xC0], xmm12
000076bac53e4162  vmovaps [rsp+0xD0], xmm13
000076bac53e416b  vmovaps [rsp+0xE0], xmm15
000076bac53e4174  sub rsp, 0x30
000076bac53e4178  movaps [rsp], xmm14
000076bac53e417d  movaps [rsp+0x10], xmm9
000076bac53e4183  movaps [rsp+0x20], xmm1
000076bac53e4188  lea rdi, [rsp]
000076bac53e418c  mov esi, 0x00
000076bac53e4191  mov rax, 0x5641B0A3C530
000076bac53e419b  call rax
000076bac53e419d  movaps xmm14, [rsp]
000076bac53e41a2  add rsp, 0x30
000076bac53e41a6  vmovaps xmm0, [rsp]
000076bac53e41ab  vmovaps xmm1, [rsp+0x10]
000076bac53e41b1  vmovaps xmm2, [rsp+0x20]
000076bac53e41b7  vmovaps xmm3, [rsp+0x30]
000076bac53e41bd  vmovaps xmm4, [rsp+0x40]
000076bac53e41c3  vmovaps xmm5, [rsp+0x50]
000076bac53e41c9  vmovaps xmm6, [rsp+0x60]
000076bac53e41cf  vmovaps xmm7, [rsp+0x70]
000076bac53e41d5  vmovaps xmm8, [rsp+0x80]
000076bac53e41de  vmovaps xmm9, [rsp+0x90]
000076bac53e41e7  vmovaps xmm10, [rsp+0xA0]
000076bac53e41f0  vmovaps xmm11, [rsp+0xB0]
000076bac53e41f9  vmovaps xmm12, [rsp+0xC0]
000076bac53e4202  vmovaps xmm13, [rsp+0xD0]
000076bac53e420b  vmovaps xmm15, [rsp+0xE0]
000076bac53e4214  add rsp, 0xF0
000076bac53e421b  pop r11
000076bac53e421d  pop r10
000076bac53e421f  pop r9
000076bac53e4221  pop r8
000076bac53e4223  pop rsi
000076bac53e4224  pop rdi
000076bac53e4225  pop rdx
000076bac53e4226  pop rcx
000076bac53e4227  pop rax
000076bac53e4228  add rsp, 0x08
000076bac53e422c  jmp 0x000076BAC53DF90B
000076bac53e4231  sub rsp, 0x08
000076bac53e4235  push rax
000076bac53e4236  push rcx
000076bac53e4237  push rdx
000076bac53e4238  push rdi
000076bac53e4239  push rsi
000076bac53e423a  push r8
000076bac53e423c  push r9
000076bac53e423e  push r10
000076bac53e4240  push r11
000076bac53e4242  sub rsp, 0xF0
000076bac53e4249  vmovaps [rsp], xmm0
000076bac53e424e  vmovaps [rsp+0x10], xmm2
000076bac53e4254  vmovaps [rsp+0x20], xmm3
000076bac53e425a  vmovaps [rsp+0x30], xmm4
000076bac53e4260  vmovaps [rsp+0x40], xmm5
000076bac53e4266  vmovaps [rsp+0x50], xmm6
000076bac53e426c  vmovaps [rsp+0x60], xmm7
000076bac53e4272  vmovaps [rsp+0x70], xmm8
000076bac53e4278  vmovaps [rsp+0x80], xmm9
000076bac53e4281  vmovaps [rsp+0x90], xmm10
000076bac53e428a  vmovaps [rsp+0xA0], xmm11
000076bac53e4293  vmovaps [rsp+0xB0], xmm12
000076bac53e429c  vmovaps [rsp+0xC0], xmm13
000076bac53e42a5  vmovaps [rsp+0xD0], xmm14
000076bac53e42ae  vmovaps [rsp+0xE0], xmm15
000076bac53e42b7  sub rsp, 0x30
000076bac53e42bb  movaps [rsp], xmm1
000076bac53e42bf  movaps [rsp+0x10], xmm13
000076bac53e42c5  movaps [rsp+0x20], xmm8
000076bac53e42cb  lea rdi, [rsp]
000076bac53e42cf  mov esi, 0x00
000076bac53e42d4  mov rax, 0x5641B0A3C530
000076bac53e42de  call rax
000076bac53e42e0  movaps xmm1, [rsp]
000076bac53e42e4  add rsp, 0x30
000076bac53e42e8  vmovaps xmm0, [rsp]
000076bac53e42ed  vmovaps xmm2, [rsp+0x10]
000076bac53e42f3  vmovaps xmm3, [rsp+0x20]
000076bac53e42f9  vmovaps xmm4, [rsp+0x30]
000076bac53e42ff  vmovaps xmm5, [rsp+0x40]
000076bac53e4305  vmovaps xmm6, [rsp+0x50]
000076bac53e430b  vmovaps xmm7, [rsp+0x60]
000076bac53e4311  vmovaps xmm8, [rsp+0x70]
000076bac53e4317  vmovaps xmm9, [rsp+0x80]
000076bac53e4320  vmovaps xmm10, [rsp+0x90]
000076bac53e4329  vmovaps xmm11, [rsp+0xA0]
000076bac53e4332  vmovaps xmm12, [rsp+0xB0]
000076bac53e433b  vmovaps xmm13, [rsp+0xC0]
000076bac53e4344  vmovaps xmm14, [rsp+0xD0]
000076bac53e434d  vmovaps xmm15, [rsp+0xE0]
000076bac53e4356  add rsp, 0xF0
000076bac53e435d  pop r11
000076bac53e435f  pop r10
000076bac53e4361  pop r9
000076bac53e4363  pop r8
000076bac53e4365  pop rsi
000076bac53e4366  pop rdi
000076bac53e4367  pop rdx
000076bac53e4368  pop rcx
000076bac53e4369  pop rax
000076bac53e436a  add rsp, 0x08
000076bac53e436e  jmp 0x000076BAC53DF92D
000076bac53e4373  call 0x000076BAC520C260
000076bac53e4378  jmp 0x000076BAC53DF93B
000076bac53e437d  call 0x000076BAC52BD750
000076bac53e4382  jmp 0x000076BAC53DF945
000076bac53e4387  sub rsp, 0x08
000076bac53e438b  push rax
000076bac53e438c  push rcx
000076bac53e438d  push rdx
000076bac53e438e  push rdi
000076bac53e438f  push rsi
000076bac53e4390  push r8
000076bac53e4392  push r9
000076bac53e4394  push r10
000076bac53e4396  push r11
000076bac53e4398  sub rsp, 0xF0
000076bac53e439f  vmovaps [rsp], xmm0
000076bac53e43a4  vmovaps [rsp+0x10], xmm1
000076bac53e43aa  vmovaps [rsp+0x20], xmm2
000076bac53e43b0  vmovaps [rsp+0x30], xmm3
000076bac53e43b6  vmovaps [rsp+0x40], xmm4
000076bac53e43bc  vmovaps [rsp+0x50], xmm5
000076bac53e43c2  vmovaps [rsp+0x60], xmm6
000076bac53e43c8  vmovaps [rsp+0x70], xmm7
000076bac53e43ce  vmovaps [rsp+0x80], xmm9
000076bac53e43d7  vmovaps [rsp+0x90], xmm10
000076bac53e43e0  vmovaps [rsp+0xA0], xmm11
000076bac53e43e9  vmovaps [rsp+0xB0], xmm12
000076bac53e43f2  vmovaps [rsp+0xC0], xmm13
000076bac53e43fb  vmovaps [rsp+0xD0], xmm14
000076bac53e4404  vmovaps [rsp+0xE0], xmm15
000076bac53e440d  sub rsp, 0x30
000076bac53e4411  movaps [rsp], xmm8
000076bac53e4416  movaps [rsp+0x10], xmm15
000076bac53e441c  movaps [rsp+0x20], xmm7
000076bac53e4421  lea rdi, [rsp]
000076bac53e4425  mov esi, 0x00
000076bac53e442a  mov rax, 0x5641B0A3C530
000076bac53e4434  call rax
000076bac53e4436  movaps xmm8, [rsp]
000076bac53e443b  add rsp, 0x30
000076bac53e443f  vmovaps xmm0, [rsp]
000076bac53e4444  vmovaps xmm1, [rsp+0x10]
000076bac53e444a  vmovaps xmm2, [rsp+0x20]
000076bac53e4450  vmovaps xmm3, [rsp+0x30]
000076bac53e4456  vmovaps xmm4, [rsp+0x40]
000076bac53e445c  vmovaps xmm5, [rsp+0x50]
000076bac53e4462  vmovaps xmm6, [rsp+0x60]
000076bac53e4468  vmovaps xmm7, [rsp+0x70]
000076bac53e446e  vmovaps xmm9, [rsp+0x80]
000076bac53e4477  vmovaps xmm10, [rsp+0x90]
000076bac53e4480  vmovaps xmm11, [rsp+0xA0]
000076bac53e4489  vmovaps xmm12, [rsp+0xB0]
000076bac53e4492  vmovaps xmm13, [rsp+0xC0]
000076bac53e449b  vmovaps xmm14, [rsp+0xD0]
000076bac53e44a4  vmovaps xmm15, [rsp+0xE0]
000076bac53e44ad  add rsp, 0xF0
000076bac53e44b4  pop r11
000076bac53e44b6  pop r10
000076bac53e44b8  pop r9
000076bac53e44ba  pop r8
000076bac53e44bc  pop rsi
000076bac53e44bd  pop rdi
000076bac53e44be  pop rdx
000076bac53e44bf  pop rcx
000076bac53e44c0  pop rax
000076bac53e44c1  add rsp, 0x08
000076bac53e44c5  jmp 0x000076BAC53DF967
000076bac53e44ca  sub rsp, 0x08
000076bac53e44ce  push rax
000076bac53e44cf  push rcx
000076bac53e44d0  push rdx
000076bac53e44d1  push rdi
000076bac53e44d2  push rsi
000076bac53e44d3  push r8
000076bac53e44d5  push r9
000076bac53e44d7  push r10
000076bac53e44d9  push r11
000076bac53e44db  sub rsp, 0xF0
000076bac53e44e2  vmovaps [rsp], xmm0
000076bac53e44e7  vmovaps [rsp+0x10], xmm1
000076bac53e44ed  vmovaps [rsp+0x20], xmm2
000076bac53e44f3  vmovaps [rsp+0x30], xmm3
000076bac53e44f9  vmovaps [rsp+0x40], xmm4
000076bac53e44ff  vmovaps [rsp+0x50], xmm5
000076bac53e4505  vmovaps [rsp+0x60], xmm6
000076bac53e450b  vmovaps [rsp+0x70], xmm8
000076bac53e4511  vmovaps [rsp+0x80], xmm9
000076bac53e451a  vmovaps [rsp+0x90], xmm10
000076bac53e4523  vmovaps [rsp+0xA0], xmm11
000076bac53e452c  vmovaps [rsp+0xB0], xmm12
000076bac53e4535  vmovaps [rsp+0xC0], xmm13
000076bac53e453e  vmovaps [rsp+0xD0], xmm14
000076bac53e4547  vmovaps [rsp+0xE0], xmm15
000076bac53e4550  sub rsp, 0x30
000076bac53e4554  movaps [rsp], xmm7
000076bac53e4558  movaps [rsp+0x10], xmm9
000076bac53e455e  movaps [rsp+0x20], xmm15
000076bac53e4564  lea rdi, [rsp]
000076bac53e4568  mov esi, 0x00
000076bac53e456d  mov rax, 0x5641B0A3C530
000076bac53e4577  call rax
000076bac53e4579  movaps xmm7, [rsp]
000076bac53e457d  add rsp, 0x30
000076bac53e4581  vmovaps xmm0, [rsp]
000076bac53e4586  vmovaps xmm1, [rsp+0x10]
000076bac53e458c  vmovaps xmm2, [rsp+0x20]
000076bac53e4592  vmovaps xmm3, [rsp+0x30]
000076bac53e4598  vmovaps xmm4, [rsp+0x40]
000076bac53e459e  vmovaps xmm5, [rsp+0x50]
000076bac53e45a4  vmovaps xmm6, [rsp+0x60]
000076bac53e45aa  vmovaps xmm8, [rsp+0x70]
000076bac53e45b0  vmovaps xmm9, [rsp+0x80]
000076bac53e45b9  vmovaps xmm10, [rsp+0x90]
000076bac53e45c2  vmovaps xmm11, [rsp+0xA0]
000076bac53e45cb  vmovaps xmm12, [rsp+0xB0]
000076bac53e45d4  vmovaps xmm13, [rsp+0xC0]
000076bac53e45dd  vmovaps xmm14, [rsp+0xD0]
000076bac53e45e6  vmovaps xmm15, [rsp+0xE0]
000076bac53e45ef  add rsp, 0xF0
000076bac53e45f6  pop r11
000076bac53e45f8  pop r10
000076bac53e45fa  pop r9
000076bac53e45fc  pop r8
000076bac53e45fe  pop rsi
000076bac53e45ff  pop rdi
000076bac53e4600  pop rdx
000076bac53e4601  pop rcx
000076bac53e4602  pop rax
000076bac53e4603  add rsp, 0x08
000076bac53e4607  jmp 0x000076BAC53DF994
000076bac53e460c  sub rsp, 0x08
000076bac53e4610  push rax
000076bac53e4611  push rcx
000076bac53e4612  push rdx
000076bac53e4613  push rdi
000076bac53e4614  push rsi
000076bac53e4615  push r8
000076bac53e4617  push r9
000076bac53e4619  push r10
000076bac53e461b  push r11
000076bac53e461d  sub rsp, 0xF0
000076bac53e4624  vmovaps [rsp], xmm0
000076bac53e4629  vmovaps [rsp+0x10], xmm1
000076bac53e462f  vmovaps [rsp+0x20], xmm2
000076bac53e4635  vmovaps [rsp+0x30], xmm3
000076bac53e463b  vmovaps [rsp+0x40], xmm4
000076bac53e4641  vmovaps [rsp+0x50], xmm5
000076bac53e4647  vmovaps [rsp+0x60], xmm6
000076bac53e464d  vmovaps [rsp+0x70], xmm7
000076bac53e4653  vmovaps [rsp+0x80], xmm8
000076bac53e465c  vmovaps [rsp+0x90], xmm10
000076bac53e4665  vmovaps [rsp+0xA0], xmm11
000076bac53e466e  vmovaps [rsp+0xB0], xmm12
000076bac53e4677  vmovaps [rsp+0xC0], xmm13
000076bac53e4680  vmovaps [rsp+0xD0], xmm14
000076bac53e4689  vmovaps [rsp+0xE0], xmm15
000076bac53e4692  sub rsp, 0x30
000076bac53e4696  movaps [rsp], xmm9
000076bac53e469b  movaps [rsp+0x10], xmm13
000076bac53e46a1  movaps [rsp+0x20], xmm15
000076bac53e46a7  lea rdi, [rsp]
000076bac53e46ab  mov esi, 0x00
000076bac53e46b0  mov rax, 0x5641B0A3C530
000076bac53e46ba  call rax
000076bac53e46bc  movaps xmm9, [rsp]
000076bac53e46c1  add rsp, 0x30
000076bac53e46c5  vmovaps xmm0, [rsp]
000076bac53e46ca  vmovaps xmm1, [rsp+0x10]
000076bac53e46d0  vmovaps xmm2, [rsp+0x20]
000076bac53e46d6  vmovaps xmm3, [rsp+0x30]
000076bac53e46dc  vmovaps xmm4, [rsp+0x40]
000076bac53e46e2  vmovaps xmm5, [rsp+0x50]
000076bac53e46e8  vmovaps xmm6, [rsp+0x60]
000076bac53e46ee  vmovaps xmm7, [rsp+0x70]
000076bac53e46f4  vmovaps xmm8, [rsp+0x80]
000076bac53e46fd  vmovaps xmm10, [rsp+0x90]
000076bac53e4706  vmovaps xmm11, [rsp+0xA0]
000076bac53e470f  vmovaps xmm12, [rsp+0xB0]
000076bac53e4718  vmovaps xmm13, [rsp+0xC0]
000076bac53e4721  vmovaps xmm14, [rsp+0xD0]
000076bac53e472a  vmovaps xmm15, [rsp+0xE0]
000076bac53e4733  add rsp, 0xF0
000076bac53e473a  pop r11
000076bac53e473c  pop r10
000076bac53e473e  pop r9
000076bac53e4740  pop r8
000076bac53e4742  pop rsi
000076bac53e4743  pop rdi
000076bac53e4744  pop rdx
000076bac53e4745  pop rcx
000076bac53e4746  pop rax
000076bac53e4747  add rsp, 0x08
000076bac53e474b  jmp 0x000076BAC53DF9C2
000076bac53e4750  sub rsp, 0x08
000076bac53e4754  push rax
000076bac53e4755  push rcx
000076bac53e4756  push rdx
000076bac53e4757  push rdi
000076bac53e4758  push rsi
000076bac53e4759  push r8
000076bac53e475b  push r9
000076bac53e475d  push r10
000076bac53e475f  push r11
000076bac53e4761  sub rsp, 0xF0
000076bac53e4768  vmovaps [rsp], xmm0
000076bac53e476d  vmovaps [rsp+0x10], xmm1
000076bac53e4773  vmovaps [rsp+0x20], xmm2
000076bac53e4779  vmovaps [rsp+0x30], xmm3
000076bac53e477f  vmovaps [rsp+0x40], xmm4
000076bac53e4785  vmovaps [rsp+0x50], xmm5
000076bac53e478b  vmovaps [rsp+0x60], xmm6
000076bac53e4791  vmovaps [rsp+0x70], xmm7
000076bac53e4797  vmovaps [rsp+0x80], xmm8
000076bac53e47a0  vmovaps [rsp+0x90], xmm9
000076bac53e47a9  vmovaps [rsp+0xA0], xmm10
000076bac53e47b2  vmovaps [rsp+0xB0], xmm11
000076bac53e47bb  vmovaps [rsp+0xC0], xmm12
000076bac53e47c4  vmovaps [rsp+0xD0], xmm13
000076bac53e47cd  vmovaps [rsp+0xE0], xmm14
000076bac53e47d6  sub rsp, 0x30
000076bac53e47da  movaps [rsp], xmm15
000076bac53e47df  movaps [rsp+0x10], xmm11
000076bac53e47e5  movaps [rsp+0x20], xmm12
000076bac53e47eb  lea rdi, [rsp]
000076bac53e47ef  mov esi, 0x00
000076bac53e47f4  mov rax, 0x5641B0A3C530
000076bac53e47fe  call rax
000076bac53e4800  movaps xmm15, [rsp]
000076bac53e4805  add rsp, 0x30
000076bac53e4809  vmovaps xmm0, [rsp]
000076bac53e480e  vmovaps xmm1, [rsp+0x10]
000076bac53e4814  vmovaps xmm2, [rsp+0x20]
000076bac53e481a  vmovaps xmm3, [rsp+0x30]
000076bac53e4820  vmovaps xmm4, [rsp+0x40]
000076bac53e4826  vmovaps xmm5, [rsp+0x50]
000076bac53e482c  vmovaps xmm6, [rsp+0x60]
000076bac53e4832  vmovaps xmm7, [rsp+0x70]
000076bac53e4838  vmovaps xmm8, [rsp+0x80]
000076bac53e4841  vmovaps xmm9, [rsp+0x90]
000076bac53e484a  vmovaps xmm10, [rsp+0xA0]
000076bac53e4853  vmovaps xmm11, [rsp+0xB0]
000076bac53e485c  vmovaps xmm12, [rsp+0xC0]
000076bac53e4865  vmovaps xmm13, [rsp+0xD0]
000076bac53e486e  vmovaps xmm14, [rsp+0xE0]
000076bac53e4877  add rsp, 0xF0
000076bac53e487e  pop r11
000076bac53e4880  pop r10
000076bac53e4882  pop r9
000076bac53e4884  pop r8
000076bac53e4886  pop rsi
000076bac53e4887  pop rdi
000076bac53e4888  pop rdx
000076bac53e4889  pop rcx
000076bac53e488a  pop rax
000076bac53e488b  add rsp, 0x08
000076bac53e488f  jmp 0x000076BAC53DF9DD
000076bac53e4894  sub rsp, 0x08
000076bac53e4898  push rax
000076bac53e4899  push rcx
000076bac53e489a  push rdx
000076bac53e489b  push rdi
000076bac53e489c  push rsi
000076bac53e489d  push r8
000076bac53e489f  push r9
000076bac53e48a1  push r10
000076bac53e48a3  push r11
000076bac53e48a5  sub rsp, 0xF0
000076bac53e48ac  vmovaps [rsp], xmm0
000076bac53e48b1  vmovaps [rsp+0x10], xmm1
000076bac53e48b7  vmovaps [rsp+0x20], xmm2
000076bac53e48bd  vmovaps [rsp+0x30], xmm3
000076bac53e48c3  vmovaps [rsp+0x40], xmm4
000076bac53e48c9  vmovaps [rsp+0x50], xmm5
000076bac53e48cf  vmovaps [rsp+0x60], xmm6
000076bac53e48d5  vmovaps [rsp+0x70], xmm7
000076bac53e48db  vmovaps [rsp+0x80], xmm8
000076bac53e48e4  vmovaps [rsp+0x90], xmm9
000076bac53e48ed  vmovaps [rsp+0xA0], xmm10
000076bac53e48f6  vmovaps [rsp+0xB0], xmm11
000076bac53e48ff  vmovaps [rsp+0xC0], xmm12
000076bac53e4908  vmovaps [rsp+0xD0], xmm14
000076bac53e4911  vmovaps [rsp+0xE0], xmm15
000076bac53e491a  sub rsp, 0x30
000076bac53e491e  movaps [rsp], xmm13
000076bac53e4923  movaps [rsp+0x10], xmm10
000076bac53e4929  movaps [rsp+0x20], xmm14
000076bac53e492f  lea rdi, [rsp]
000076bac53e4933  mov esi, 0x00
000076bac53e4938  mov rax, 0x5641B0A3C530
000076bac53e4942  call rax
000076bac53e4944  movaps xmm13, [rsp]
000076bac53e4949  add rsp, 0x30
000076bac53e494d  vmovaps xmm0, [rsp]
000076bac53e4952  vmovaps xmm1, [rsp+0x10]
000076bac53e4958  vmovaps xmm2, [rsp+0x20]
000076bac53e495e  vmovaps xmm3, [rsp+0x30]
000076bac53e4964  vmovaps xmm4, [rsp+0x40]
000076bac53e496a  vmovaps xmm5, [rsp+0x50]
000076bac53e4970  vmovaps xmm6, [rsp+0x60]
000076bac53e4976  vmovaps xmm7, [rsp+0x70]
000076bac53e497c  vmovaps xmm8, [rsp+0x80]
000076bac53e4985  vmovaps xmm9, [rsp+0x90]
000076bac53e498e  vmovaps xmm10, [rsp+0xA0]
000076bac53e4997  vmovaps xmm11, [rsp+0xB0]
000076bac53e49a0  vmovaps xmm12, [rsp+0xC0]
000076bac53e49a9  vmovaps xmm14, [rsp+0xD0]
000076bac53e49b2  vmovaps xmm15, [rsp+0xE0]
000076bac53e49bb  add rsp, 0xF0
000076bac53e49c2  pop r11
000076bac53e49c4  pop r10
000076bac53e49c6  pop r9
000076bac53e49c8  pop r8
000076bac53e49ca  pop rsi
000076bac53e49cb  pop rdi
000076bac53e49cc  pop rdx
000076bac53e49cd  pop rcx
000076bac53e49ce  pop rax
000076bac53e49cf  add rsp, 0x08
000076bac53e49d3  jmp 0x000076BAC53DFA00
000076bac53e49d8  sub rsp, 0x08
000076bac53e49dc  push rax
000076bac53e49dd  push rcx
000076bac53e49de  push rdx
000076bac53e49df  push rdi
000076bac53e49e0  push rsi
000076bac53e49e1  push r8
000076bac53e49e3  push r9
000076bac53e49e5  push r10
000076bac53e49e7  push r11
000076bac53e49e9  sub rsp, 0xF0
000076bac53e49f0  vmovaps [rsp], xmm0
000076bac53e49f5  vmovaps [rsp+0x10], xmm1
000076bac53e49fb  vmovaps [rsp+0x20], xmm2
000076bac53e4a01  vmovaps [rsp+0x30], xmm3
000076bac53e4a07  vmovaps [rsp+0x40], xmm4
000076bac53e4a0d  vmovaps [rsp+0x50], xmm5
000076bac53e4a13  vmovaps [rsp+0x60], xmm6
000076bac53e4a19  vmovaps [rsp+0x70], xmm7
000076bac53e4a1f  vmovaps [rsp+0x80], xmm8
000076bac53e4a28  vmovaps [rsp+0x90], xmm9
000076bac53e4a31  vmovaps [rsp+0xA0], xmm10
000076bac53e4a3a  vmovaps [rsp+0xB0], xmm11
000076bac53e4a43  vmovaps [rsp+0xC0], xmm12
000076bac53e4a4c  vmovaps [rsp+0xD0], xmm13
000076bac53e4a55  vmovaps [rsp+0xE0], xmm15
000076bac53e4a5e  sub rsp, 0x30
000076bac53e4a62  movaps [rsp], xmm14
000076bac53e4a67  movaps [rsp+0x10], xmm1
000076bac53e4a6c  movaps [rsp+0x20], xmm7
000076bac53e4a71  lea rdi, [rsp]
000076bac53e4a75  mov esi, 0x00
000076bac53e4a7a  mov rax, 0x5641B0A3C530
000076bac53e4a84  call rax
000076bac53e4a86  movaps xmm14, [rsp]
000076bac53e4a8b  add rsp, 0x30
000076bac53e4a8f  vmovaps xmm0, [rsp]
000076bac53e4a94  vmovaps xmm1, [rsp+0x10]
000076bac53e4a9a  vmovaps xmm2, [rsp+0x20]
000076bac53e4aa0  vmovaps xmm3, [rsp+0x30]
000076bac53e4aa6  vmovaps xmm4, [rsp+0x40]
000076bac53e4aac  vmovaps xmm5, [rsp+0x50]
000076bac53e4ab2  vmovaps xmm6, [rsp+0x60]
000076bac53e4ab8  vmovaps xmm7, [rsp+0x70]
000076bac53e4abe  vmovaps xmm8, [rsp+0x80]
000076bac53e4ac7  vmovaps xmm9, [rsp+0x90]
000076bac53e4ad0  vmovaps xmm10, [rsp+0xA0]
000076bac53e4ad9  vmovaps xmm11, [rsp+0xB0]
000076bac53e4ae2  vmovaps xmm12, [rsp+0xC0]
000076bac53e4aeb  vmovaps xmm13, [rsp+0xD0]
000076bac53e4af4  vmovaps xmm15, [rsp+0xE0]
000076bac53e4afd  add rsp, 0xF0
000076bac53e4b04  pop r11
000076bac53e4b06  pop r10
000076bac53e4b08  pop r9
000076bac53e4b0a  pop r8
000076bac53e4b0c  pop rsi
000076bac53e4b0d  pop rdi
000076bac53e4b0e  pop rdx
000076bac53e4b0f  pop rcx
000076bac53e4b10  pop rax
000076bac53e4b11  add rsp, 0x08
000076bac53e4b15  jmp 0x000076BAC53DFA23
000076bac53e4b1a  sub rsp, 0x08
000076bac53e4b1e  push rax
000076bac53e4b1f  push rcx
000076bac53e4b20  push rdx
000076bac53e4b21  push rdi
000076bac53e4b22  push rsi
000076bac53e4b23  push r8
000076bac53e4b25  push r9
000076bac53e4b27  push r10
000076bac53e4b29  push r11
000076bac53e4b2b  sub rsp, 0xF0
000076bac53e4b32  vmovaps [rsp], xmm0
000076bac53e4b37  vmovaps [rsp+0x10], xmm2
000076bac53e4b3d  vmovaps [rsp+0x20], xmm3
000076bac53e4b43  vmovaps [rsp+0x30], xmm4
000076bac53e4b49  vmovaps [rsp+0x40], xmm5
000076bac53e4b4f  vmovaps [rsp+0x50], xmm6
000076bac53e4b55  vmovaps [rsp+0x60], xmm7
000076bac53e4b5b  vmovaps [rsp+0x70], xmm8
000076bac53e4b61  vmovaps [rsp+0x80], xmm9
000076bac53e4b6a  vmovaps [rsp+0x90], xmm10
000076bac53e4b73  vmovaps [rsp+0xA0], xmm11
000076bac53e4b7c  vmovaps [rsp+0xB0], xmm12
000076bac53e4b85  vmovaps [rsp+0xC0], xmm13
000076bac53e4b8e  vmovaps [rsp+0xD0], xmm14
000076bac53e4b97  vmovaps [rsp+0xE0], xmm15
000076bac53e4ba0  sub rsp, 0x30
000076bac53e4ba4  movaps [rsp], xmm1
000076bac53e4ba8  movaps [rsp+0x10], xmm8
000076bac53e4bae  movaps [rsp+0x20], xmm9
000076bac53e4bb4  lea rdi, [rsp]
000076bac53e4bb8  mov esi, 0x00
000076bac53e4bbd  mov rax, 0x5641B0A3C530
000076bac53e4bc7  call rax
000076bac53e4bc9  movaps xmm1, [rsp]
000076bac53e4bcd  add rsp, 0x30
000076bac53e4bd1  vmovaps xmm0, [rsp]
000076bac53e4bd6  vmovaps xmm2, [rsp+0x10]
000076bac53e4bdc  vmovaps xmm3, [rsp+0x20]
000076bac53e4be2  vmovaps xmm4, [rsp+0x30]
000076bac53e4be8  vmovaps xmm5, [rsp+0x40]
000076bac53e4bee  vmovaps xmm6, [rsp+0x50]
000076bac53e4bf4  vmovaps xmm7, [rsp+0x60]
000076bac53e4bfa  vmovaps xmm8, [rsp+0x70]
000076bac53e4c00  vmovaps xmm9, [rsp+0x80]
000076bac53e4c09  vmovaps xmm10, [rsp+0x90]
000076bac53e4c12  vmovaps xmm11, [rsp+0xA0]
000076bac53e4c1b  vmovaps xmm12, [rsp+0xB0]
000076bac53e4c24  vmovaps xmm13, [rsp+0xC0]
000076bac53e4c2d  vmovaps xmm14, [rsp+0xD0]
000076bac53e4c36  vmovaps xmm15, [rsp+0xE0]
000076bac53e4c3f  add rsp, 0xF0
000076bac53e4c46  pop r11
000076bac53e4c48  pop r10
000076bac53e4c4a  pop r9
000076bac53e4c4c  pop r8
000076bac53e4c4e  pop rsi
000076bac53e4c4f  pop rdi
000076bac53e4c50  pop rdx
000076bac53e4c51  pop rcx
000076bac53e4c52  pop rax
000076bac53e4c53  add rsp, 0x08
000076bac53e4c57  jmp 0x000076BAC53DFA45
000076bac53e4c5c  call 0x000076BAC52E5940
000076bac53e4c61  jmp 0x000076BAC53DFA53
000076bac53e4c66  call 0x000076BAC520C380
000076bac53e4c6b  jmp 0x000076BAC53DFA5D
000076bac53e4c70  call 0x000076BAC520D600
000076bac53e4c75  jmp 0x000076BAC53DFA67
000076bac53e4c7a  call 0x000076BAC51FF540
000076bac53e4c7f  jmp 0x000076BAC53DFA71
000076bac53e4c84  int3
000076bac53e4c85  nop [rax+rax*1], ax
000076bac53e4c8e  nop
000076bac53e4c90  mov qword ptr [r15+0x40], 0x430000
000076bac53e4c98  mov eax, 0x430CC0
000076bac53e4c9d  mov r14, [r13+rax*1]
000076bac53e4ca2  movq xmm1, r14
000076bac53e4ca7  mov rax, [r15+0x50]
000076bac53e4cab  movups xmm15, [r13+rax*1]
000076bac53e4cb1  movaps [r15+0x120], xmm15
000076bac53e4cb9  mov qword ptr [r15+0x48], 0x10
000076bac53e4cc1  xor eax, eax
000076bac53e4cc3  mov r14d, 0x10
000076bac53e4cc9  mov r12d, 0x200
000076bac53e4ccf  cmp r14, r12
000076bac53e4cd2  cmc
000076bac53e4cd3  lahf
000076bac53e4cd4  seto al
000076bac53e4cd7  mov [r15+0x108], eax
000076bac53e4cde  pextrq rax, xmm15, 0x01
000076bac53e4ce5  movq xmm14, rax
000076bac53e4cea  movaps [r15+0x130], xmm14
000076bac53e4cf2  movq rax, xmm1
000076bac53e4cf7  movq r14, xmm15
000076bac53e4cfc  vmovq xmm1, rax
000076bac53e4d01  vmovq xmm15, r14
000076bac53e4d06  movaps xmm13, xmm1
000076bac53e4d0a  addsd xmm13, xmm15
000076bac53e4d0f  ucomisd xmm13, xmm13
000076bac53e4d14  jp 0x000076BAC53E4DD3
000076bac53e4d1a  movq xmm13, xmm13
000076bac53e4d1f  movq rax, xmm13
000076bac53e4d24  movq r14, xmm14
000076bac53e4d29  vmovq xmm1, rax
000076bac53e4d2e  vmovq xmm15, r14
000076bac53e4d33  movaps xmm14, xmm1
000076bac53e4d37  addsd xmm14, xmm15
000076bac53e4d3c  ucomisd xmm14, xmm14
000076bac53e4d41  jp 0x000076BAC53E4E1B
000076bac53e4d47  movq xmm14, xmm14
000076bac53e4d4c  movaps [r15+0x110], xmm14
000076bac53e4d54  mov eax, [r15+0x108]
000076bac53e4d5b  sahf
000076bac53e4d5c  jnz 0x000076BAC53E4D8E
000076bac53e4d5e  cmp dword ptr [r15+0x318], 0x00
000076bac53e4d66  jz 0x000076BAC53E5030
000076bac53e4d6c  nop [rax+rax*1], ax
000076bac53e4d75  nop [rax+rax*1], eax
000076bac53e4d7d  mov eax, 0x410704
000076bac53e4d82  mov [r15+0x100], rax
000076bac53e4d89  jmp 0x000076BAC51FE110
000076bac53e4d8e  cmp dword ptr [r15+0x318], 0x00
000076bac53e4d96  jz 0x000076BAC53E4E70
000076bac53e4d9c  nop [rax+rax*1], ax
000076bac53e4da5  nop [rax+rax*1], eax
000076bac53e4dad  mov eax, 0x4106E8
000076bac53e4db2  mov [r15+0x100], rax
000076bac53e4db9  jmp 0x000076BAC51FE110
000076bac53e4dbe  int3
000076bac53e4dbf  call 0x000076BAC520DC20
000076bac53e4dc4  jmp 0x000076BAC53E4CA2
000076bac53e4dc9  call 0x000076BAC520E760
000076bac53e4dce  jmp 0x000076BAC53E4CB1
000076bac53e4dd3  ucomisd xmm1, xmm15
000076bac53e4dd8  jp 0x000076BAC53E4DE7
000076bac53e4dda  movaps xmm13, [0x000076BAC4FFE060]
000076bac53e4de2  jmp 0x000076BAC53E4D1A
000076bac53e4de7  vxorps xmm0, xmm1, xmm15
000076bac53e4dec  pextrw eax, xmm0, 0x03
000076bac53e4df1  and eax, 0x7FF8
000076bac53e4df6  cmp eax, 0x08
000076bac53e4df9  jnz 0x000076BAC53E4D1A
000076bac53e4dff  movq rax, xmm15
000076bac53e4e04  shl rax, 0x0D
000076bac53e4e08  jbe 0x000076BAC53E4D1A
000076bac53e4e0e  vorps xmm13, xmm15, [0x000076BAC4FFE070]
000076bac53e4e16  jmp 0x000076BAC53E4D1A
000076bac53e4e1b  ucomisd xmm1, xmm15
000076bac53e4e20  jp 0x000076BAC53E4E2F
000076bac53e4e22  movaps xmm14, [0x000076BAC4FFE060]
000076bac53e4e2a  jmp 0x000076BAC53E4D47
000076bac53e4e2f  vxorps xmm0, xmm1, xmm15
000076bac53e4e34  pextrw eax, xmm0, 0x03
000076bac53e4e39  and eax, 0x7FF8
000076bac53e4e3e  cmp eax, 0x08
000076bac53e4e41  jnz 0x000076BAC53E4D47
000076bac53e4e47  movq rax, xmm15
000076bac53e4e4c  shl rax, 0x0D
000076bac53e4e50  jbe 0x000076BAC53E4D47
000076bac53e4e56  vorps xmm14, xmm15, [0x000076BAC4FFE070]
000076bac53e4e5e  jmp 0x000076BAC53E4D47
000076bac53e4e63  int3
000076bac53e4e64  nop [rax+rax*1], ax
000076bac53e4e6d  nop [rax], eax
000076bac53e4e70  mov rax, [r15+0x48]
000076bac53e4e74  mov r14, [r15+0x50]
000076bac53e4e78  lea r12, [r14+rax*1]
000076bac53e4e7c  movups xmm1, [r13+r12*1]
000076bac53e4e82  movaps [r15+0x120], xmm1
000076bac53e4e8a  lea r14, [rax+0x10]
000076bac53e4e8e  mov [r15+0x48], r14
000076bac53e4e92  xor eax, eax
000076bac53e4e94  mov r12d, 0x200
000076bac53e4e9a  cmp r14, r12
000076bac53e4e9d  cmc
000076bac53e4e9e  lahf
000076bac53e4e9f  seto al
000076bac53e4ea2  mov [r15+0x108], eax
000076bac53e4ea9  pextrq rax, xmm1, 0x01
000076bac53e4eb0  movq xmm15, rax
000076bac53e4eb5  movaps [r15+0x130], xmm15
000076bac53e4ebd  movaps xmm14, [r15+0x110]
000076bac53e4ec5  movq rax, xmm14
000076bac53e4eca  movq r14, xmm1
000076bac53e4ecf  vmovq xmm1, rax
000076bac53e4ed4  vmovq xmm14, r14
000076bac53e4ed9  movaps xmm13, xmm1
000076bac53e4edd  addsd xmm13, xmm14
000076bac53e4ee2  ucomisd xmm13, xmm13
000076bac53e4ee7  jp 0x000076BAC53E4F9C
000076bac53e4eed  movq xmm13, xmm13
000076bac53e4ef2  movq rax, xmm13
000076bac53e4ef7  movq r14, xmm15
000076bac53e4efc  vmovq xmm1, rax
000076bac53e4f01  vmovq xmm15, r14
000076bac53e4f06  movaps xmm14, xmm1
000076bac53e4f0a  addsd xmm14, xmm15
000076bac53e4f0f  ucomisd xmm14, xmm14
000076bac53e4f14  jp 0x000076BAC53E4FE4
000076bac53e4f1a  movq xmm14, xmm14
000076bac53e4f1f  movaps [r15+0x110], xmm14
000076bac53e4f27  mov eax, [r15+0x108]
000076bac53e4f2e  sahf
000076bac53e4f2f  jnz 0x000076BAC53E4F61
000076bac53e4f31  cmp dword ptr [r15+0x318], 0x00
000076bac53e4f39  jz 0x000076BAC53E5030
000076bac53e4f3f  nop [rax+rax*1], ax
000076bac53e4f48  nop [rax+rax*1], eax
000076bac53e4f50  mov eax, 0x410704
000076bac53e4f55  mov [r15+0x100], rax
000076bac53e4f5c  jmp 0x000076BAC51FE110
000076bac53e4f61  cmp dword ptr [r15+0x318], 0x00
000076bac53e4f69  jz 0x000076BAC53E4E70
000076bac53e4f6f  nop [rax+rax*1], ax
000076bac53e4f78  nop [rax+rax*1], eax
000076bac53e4f80  mov eax, 0x4106E8
000076bac53e4f85  mov [r15+0x100], rax
000076bac53e4f8c  jmp 0x000076BAC51FE110
000076bac53e4f91  int3
000076bac53e4f92  call 0x000076BAC52B52F0
000076bac53e4f97  jmp 0x000076BAC53E4E82
000076bac53e4f9c  ucomisd xmm1, xmm14
000076bac53e4fa1  jp 0x000076BAC53E4FB0
000076bac53e4fa3  movaps xmm13, [0x000076BAC4FFE060]
000076bac53e4fab  jmp 0x000076BAC53E4EED
000076bac53e4fb0  vxorps xmm0, xmm1, xmm14
000076bac53e4fb5  pextrw eax, xmm0, 0x03
000076bac53e4fba  and eax, 0x7FF8
000076bac53e4fbf  cmp eax, 0x08
000076bac53e4fc2  jnz 0x000076BAC53E4EED
000076bac53e4fc8  movq rax, xmm14
000076bac53e4fcd  shl rax, 0x0D
000076bac53e4fd1  jbe 0x000076BAC53E4EED
000076bac53e4fd7  vorps xmm13, xmm14, [0x000076BAC4FFE070]
000076bac53e4fdf  jmp 0x000076BAC53E4EED
000076bac53e4fe4  ucomisd xmm1, xmm15
000076bac53e4fe9  jp 0x000076BAC53E4FF8
000076bac53e4feb  movaps xmm14, [0x000076BAC4FFE060]
000076bac53e4ff3  jmp 0x000076BAC53E4F1A
000076bac53e4ff8  vxorps xmm0, xmm1, xmm15
000076bac53e4ffd  pextrw eax, xmm0, 0x03
000076bac53e5002  and eax, 0x7FF8
000076bac53e5007  cmp eax, 0x08
000076bac53e500a  jnz 0x000076BAC53E4F1A
000076bac53e5010  movq rax, xmm15
000076bac53e5015  shl rax, 0x0D
000076bac53e5019  jbe 0x000076BAC53E4F1A
000076bac53e501f  vorps xmm14, xmm15, [0x000076BAC4FFE070]
000076bac53e5027  jmp 0x000076BAC53E4F1A
000076bac53e502c  int3
000076bac53e502d  nop [rax], eax
000076bac53e5030  mov rax, [r15+0xF8]
000076bac53e5037  lea r14, [rax+0x1D0]
000076bac53e503e  mov r12, [r13+r14*1]
000076bac53e5043  lea r14, [rax+0x1D8]
000076bac53e504a  mov r11, [r13+r14*1]
000076bac53e504f  mov [r15+0xA0], r12
000076bac53e5056  mov [r15+0x98], r11
000076bac53e505d  mov r14, [r15+0x40]
000076bac53e5061  lea r12, [r14+0xCC0]
000076bac53e5068  movaps xmm1, [r15+0x110]
000076bac53e5070  movq r14, xmm1
000076bac53e5075  mov [r13+r12*1], r14
000076bac53e507a  lea r14, [rax+0x1C0]
000076bac53e5081  mov r12, [r13+r14*1]
000076bac53e5086  lea r14, [rax+0x1C8]
000076bac53e508d  mov r11, [r13+r14*1]
000076bac53e5092  mov [r15+0xE8], r12
000076bac53e5099  mov [r15+0xF0], r11
000076bac53e50a0  lea r14, [rax+0x1B0]
000076bac53e50a7  mov r12, [r13+r14*1]
000076bac53e50ac  lea r14, [rax+0x1B8]
000076bac53e50b3  mov r10, [r13+r14*1]
000076bac53e50b8  movq xmm1, r12
000076bac53e50bd  movq xmm15, r10
000076bac53e50c2  movq xmm1, xmm1
000076bac53e50c6  movq xmm1, xmm1
000076bac53e50ca  movaps [r15+0x1A0], xmm1
000076bac53e50d2  movq xmm15, xmm15
000076bac53e50d7  movq xmm15, xmm15
000076bac53e50dc  movaps [r15+0x190], xmm15
000076bac53e50e4  lea r14, [rax+0x1A0]
000076bac53e50eb  mov r12, [r13+r14*1]
000076bac53e50f0  lea r14, [rax+0x1A8]
000076bac53e50f7  mov r10, [r13+r14*1]
000076bac53e50fc  movq xmm1, r12
000076bac53e5101  movq xmm15, r10
000076bac53e5106  movq xmm1, xmm1
000076bac53e510a  movq xmm1, xmm1
000076bac53e510e  movaps [r15+0x1C0], xmm1
000076bac53e5116  movq xmm15, xmm15
000076bac53e511b  movq xmm15, xmm15
000076bac53e5120  movaps [r15+0x1B0], xmm15
000076bac53e5128  lea r14, [rax+0x190]
000076bac53e512f  mov r12, [r13+r14*1]
000076bac53e5134  lea r14, [rax+0x198]
000076bac53e513b  mov r10, [r13+r14*1]
000076bac53e5140  movq xmm1, r12
000076bac53e5145  movq xmm15, r10
000076bac53e514a  movq xmm1, xmm1
000076bac53e514e  movq xmm1, xmm1
000076bac53e5152  movaps [r15+0x1E0], xmm1
000076bac53e515a  movq xmm15, xmm15
000076bac53e515f  movq xmm15, xmm15
000076bac53e5164  movaps [r15+0x1D0], xmm15
000076bac53e516c  lea r14, [rax+0x180]
000076bac53e5173  mov r12, [r13+r14*1]
000076bac53e5178  lea r14, [rax+0x188]
000076bac53e517f  mov r10, [r13+r14*1]
000076bac53e5184  movq xmm1, r12
000076bac53e5189  movq xmm15, r10
000076bac53e518e  movq xmm1, xmm1
000076bac53e5192  movq xmm1, xmm1
000076bac53e5196  movaps [r15+0x200], xmm1
000076bac53e519e  movq xmm15, xmm15
000076bac53e51a3  movq xmm15, xmm15
000076bac53e51a8  movaps [r15+0x1F0], xmm15
000076bac53e51b0  lea r14, [rax+0x1E0]
000076bac53e51b7  mov [r15+0xF8], r14
000076bac53e51be  mov [r15+0x100], r11
000076bac53e51c5  jmp 0x000076BAC53CE5C0
000076bac53e51ca  int3
000076bac53e51cb  call 0x000076BAC52E27E0
000076bac53e51d0  jmp 0x000076BAC53E5043
000076bac53e51d5  call 0x000076BAC52E1570
000076bac53e51da  jmp 0x000076BAC53E504F
000076bac53e51df  call 0x000076BAC52C3FE0
000076bac53e51e4  jmp 0x000076BAC53E507A
000076bac53e51e9  call 0x000076BAC52E27E0
000076bac53e51ee  jmp 0x000076BAC53E5086
000076bac53e51f3  call 0x000076BAC52E1570
000076bac53e51f8  jmp 0x000076BAC53E5092
000076bac53e51fd  call 0x000076BAC52E27E0
000076bac53e5202  jmp 0x000076BAC53E50AC
000076bac53e5207  call 0x000076BAC52E0300
000076bac53e520c  jmp 0x000076BAC53E50B8
000076bac53e5211  call 0x000076BAC52E27E0
000076bac53e5216  jmp 0x000076BAC53E50F0
000076bac53e521b  call 0x000076BAC52E0300
000076bac53e5220  jmp 0x000076BAC53E50FC
000076bac53e5225  call 0x000076BAC52E27E0
000076bac53e522a  jmp 0x000076BAC53E5134
000076bac53e522f  call 0x000076BAC52E0300
000076bac53e5234  jmp 0x000076BAC53E5140
000076bac53e5239  call 0x000076BAC52E27E0
000076bac53e523e  jmp 0x000076BAC53E5178
000076bac53e5243  call 0x000076BAC52E0300
000076bac53e5248  jmp 0x000076BAC53E5184
000076bac53e524d  int3
000076bac53e524e  nop
000076bac53e5250  mov qword ptr [r15+0x100], 0x04
000076bac53e525b  mov esi, 0x00
000076bac53e5260  mov edx, 0x09
000076bac53e5265  mov rdi, 0x7FFFC1964500
000076bac53e526f  mov rax, 0x5641B08CF970
000076bac53e5279  call rax
000076bac53e527b  cmp dword ptr [r15+0x318], 0x00
000076bac53e5283  jnz 0x000076BAC51FE110
000076bac53e5289  jmp 0x000076BAC51FE0A0
000076bac53e528e  int3
000076bac53e528f  int3
