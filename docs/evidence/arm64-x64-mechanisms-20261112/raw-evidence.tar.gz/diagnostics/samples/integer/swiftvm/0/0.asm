
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/integer/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

0000790ce5500000 <.data>:
    790ce5500000:	sub    rsp,0x10
    790ce5500004:	mov    r13d,0x1b00
    790ce550000a:	mov    r14d,0xb7
    790ce5500010:	and    r14d,0xffff
    790ce5500017:	mov    rax,r13
    790ce550001a:	movabs rcx,0xffffffff0000ffff
    790ce5500024:	and    rax,rcx
    790ce5500027:	mov    rdx,r14
    790ce550002a:	shl    rdx,0x10
    790ce550002e:	mov    ecx,0xffff0000
    790ce5500033:	and    rdx,rcx
    790ce5500036:	or     rax,rdx
    790ce5500039:	mov    r15,rax
    790ce550003c:	mov    QWORD PTR [r12+0x8],r15
    790ce5500041:	mov    r13d,0x420060
    790ce5500047:	mov    QWORD PTR [r12+0x20],r13
    790ce550004c:	mov    r13d,0x0
    790ce5500052:	mov    QWORD PTR [r12],r13
    790ce5500056:	jmp    0x790ce550005b
    790ce550005b:	mov    r13,QWORD PTR [r12]
    790ce550005f:	add    r13,0x3
    790ce5500063:	mov    r14,r13
    790ce5500066:	shr    r14,0x7
    790ce550006a:	mov    rcx,r14
    790ce550006d:	xor    r13,rcx
    790ce5500070:	mov    QWORD PTR [r12],r13
    790ce5500074:	mov    r13,QWORD PTR [r12+0x8]
    790ce5500079:	sub    r13,0x1
    790ce550007d:	mov    QWORD PTR [r12+0x8],r13
    790ce5500082:	mov    rcx,QWORD PTR [r12+0x380]
    790ce550008a:	jrcxz  0x790ce5500091
    790ce550008c:	jmp    0x790ce5500102
    790ce5500091:	jne    0x790ce550005b
    790ce5500097:	pushf
    790ce5500098:	pop    r11
    790ce550009a:	mov    QWORD PTR [rsp],r11
    790ce550009e:	jmp    0x790ce55000a3
    790ce55000a3:	mov    r13,QWORD PTR [r12+0x20]
    790ce55000a8:	mov    r14,QWORD PTR [r12]
    790ce55000ac:	mov    QWORD PTR [r13+0x0],r14
    790ce55000b0:	mov    r13d,0x0
    790ce55000b6:	mov    DWORD PTR [r12+0x32c],r13d
    790ce55000be:	mov    rcx,QWORD PTR [r12+0x380]
    790ce55000c6:	jrcxz  0x790ce55000cd
    790ce55000c8:	jmp    0x790ce5500191
    790ce55000cd:	mov    r13,QWORD PTR [r12+0xf0]
    790ce55000d5:	mov    QWORD PTR [r12+0x100],r13
    790ce55000dd:	mov    r11,QWORD PTR [rsp]
    790ce55000e1:	mov    QWORD PTR [r12+0x398],r11
    790ce55000e9:	mov    rdi,QWORD PTR [r12+0x100]
    790ce55000f1:	add    rsp,0x10
    790ce55000f5:	movabs r11,0x5e1e7fdda0a0
    790ce55000ff:	jmp    r11
    790ce5500102:	mov    eax,0x410048
    790ce5500107:	mov    QWORD PTR [r12+0x100],rax
    790ce550010f:	push   rdx
    790ce5500110:	push   rsi
    790ce5500111:	push   r10
    790ce5500113:	push   r11
    790ce5500115:	pushf
    790ce5500116:	pop    r11
    790ce5500118:	mov    QWORD PTR [rsp+0x20],r11
    790ce550011d:	mov    rdx,QWORD PTR [rsp+0x20]
    790ce5500122:	mov    r10d,edx
    790ce5500125:	and    r10d,0xc0
    790ce550012c:	shl    r10d,0x18
    790ce5500130:	mov    r11d,edx
    790ce5500133:	and    r11d,0x1
    790ce5500137:	shl    r11d,0x1d
    790ce550013b:	or     r10d,r11d
    790ce550013e:	mov    r11d,edx
    790ce5500141:	and    r11d,0x800
    790ce5500148:	shl    r11d,0x11
    790ce550014c:	or     r10d,r11d
    790ce550014f:	btc    r10,0x1d
    790ce5500154:	mov    r11d,0xf0000000
    790ce550015a:	and    r11,r10
    790ce550015d:	movabs rsi,0xffffffff0fffffff
    790ce5500167:	and    rbx,rsi
    790ce550016a:	or     rbx,r11
    790ce550016d:	pop    r11
    790ce550016f:	pop    r10
    790ce5500171:	pop    rsi
    790ce5500172:	pop    rdx
    790ce5500173:	mov    QWORD PTR [r12+0x108],rbx
    790ce550017b:	add    rsp,0x10
    790ce550017f:	mov    eax,0xc
    790ce5500184:	movabs r11,0x5e1e7fdda390
    790ce550018e:	jmp    r11
    790ce5500191:	mov    eax,0x410050
    790ce5500196:	mov    QWORD PTR [r12+0x100],rax
    790ce550019e:	push   rdx
    790ce550019f:	push   rsi
    790ce55001a0:	push   r10
    790ce55001a2:	push   r11
    790ce55001a4:	mov    rdx,QWORD PTR [rsp+0x20]
    790ce55001a9:	mov    r10d,edx
    790ce55001ac:	and    r10d,0xc0
    790ce55001b3:	shl    r10d,0x18
    790ce55001b7:	mov    r11d,edx
    790ce55001ba:	and    r11d,0x1
    790ce55001be:	shl    r11d,0x1d
    790ce55001c2:	or     r10d,r11d
    790ce55001c5:	mov    r11d,edx
    790ce55001c8:	and    r11d,0x800
    790ce55001cf:	shl    r11d,0x11
    790ce55001d3:	or     r10d,r11d
    790ce55001d6:	btc    r10,0x1d
    790ce55001db:	mov    r11d,0xf0000000
    790ce55001e1:	and    r11,r10
    790ce55001e4:	movabs rsi,0xffffffff0fffffff
    790ce55001ee:	and    rbx,rsi
    790ce55001f1:	or     rbx,r11
    790ce55001f4:	pop    r11
    790ce55001f6:	pop    r10
    790ce55001f8:	pop    rsi
    790ce55001f9:	pop    rdx
    790ce55001fa:	mov    QWORD PTR [r12+0x108],rbx
    790ce5500202:	add    rsp,0x10
    790ce5500206:	mov    eax,0xc
    790ce550020b:	movabs r11,0x5e1e7fdda390
    790ce5500215:	jmp    r11
    790ce5500218:	nop    DWORD PTR [rax+rax*1+0x0]
    790ce5500220:	sub    rsp,0x10
    790ce5500224:	jmp    0x790ce550005b
    790ce5500229:	nop    DWORD PTR [rax+0x0]
    790ce5500230:	sub    rsp,0x10
    790ce5500234:	mov    r11,QWORD PTR [r12+0x398]
    790ce550023c:	mov    QWORD PTR [rsp],r11
    790ce5500240:	jmp    0x790ce55000a3
    790ce5500245:	nop
    790ce5500246:	nop
    790ce5500247:	nop
