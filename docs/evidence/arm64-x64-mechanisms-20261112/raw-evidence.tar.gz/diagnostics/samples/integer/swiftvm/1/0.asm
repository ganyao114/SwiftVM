
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/integer/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

00007be0a1300000 <.data>:
    7be0a1300000:	sub    rsp,0x10
    7be0a1300004:	mov    r13d,0x1b00
    7be0a130000a:	mov    r14d,0xb7
    7be0a1300010:	and    r14d,0xffff
    7be0a1300017:	mov    rax,r13
    7be0a130001a:	movabs rcx,0xffffffff0000ffff
    7be0a1300024:	and    rax,rcx
    7be0a1300027:	mov    rdx,r14
    7be0a130002a:	shl    rdx,0x10
    7be0a130002e:	mov    ecx,0xffff0000
    7be0a1300033:	and    rdx,rcx
    7be0a1300036:	or     rax,rdx
    7be0a1300039:	mov    r15,rax
    7be0a130003c:	mov    QWORD PTR [r12+0x8],r15
    7be0a1300041:	mov    r13d,0x420060
    7be0a1300047:	mov    QWORD PTR [r12+0x20],r13
    7be0a130004c:	mov    r13d,0x0
    7be0a1300052:	mov    QWORD PTR [r12],r13
    7be0a1300056:	jmp    0x7be0a130005b
    7be0a130005b:	mov    r13,QWORD PTR [r12]
    7be0a130005f:	add    r13,0x3
    7be0a1300063:	mov    r14,r13
    7be0a1300066:	shr    r14,0x7
    7be0a130006a:	mov    rcx,r14
    7be0a130006d:	xor    r13,rcx
    7be0a1300070:	mov    QWORD PTR [r12],r13
    7be0a1300074:	mov    r13,QWORD PTR [r12+0x8]
    7be0a1300079:	sub    r13,0x1
    7be0a130007d:	mov    QWORD PTR [r12+0x8],r13
    7be0a1300082:	mov    rcx,QWORD PTR [r12+0x380]
    7be0a130008a:	jrcxz  0x7be0a1300091
    7be0a130008c:	jmp    0x7be0a1300102
    7be0a1300091:	jne    0x7be0a130005b
    7be0a1300097:	pushf
    7be0a1300098:	pop    r11
    7be0a130009a:	mov    QWORD PTR [rsp],r11
    7be0a130009e:	jmp    0x7be0a13000a3
    7be0a13000a3:	mov    r13,QWORD PTR [r12+0x20]
    7be0a13000a8:	mov    r14,QWORD PTR [r12]
    7be0a13000ac:	mov    QWORD PTR [r13+0x0],r14
    7be0a13000b0:	mov    r13d,0x0
    7be0a13000b6:	mov    DWORD PTR [r12+0x32c],r13d
    7be0a13000be:	mov    rcx,QWORD PTR [r12+0x380]
    7be0a13000c6:	jrcxz  0x7be0a13000cd
    7be0a13000c8:	jmp    0x7be0a1300191
    7be0a13000cd:	mov    r13,QWORD PTR [r12+0xf0]
    7be0a13000d5:	mov    QWORD PTR [r12+0x100],r13
    7be0a13000dd:	mov    r11,QWORD PTR [rsp]
    7be0a13000e1:	mov    QWORD PTR [r12+0x398],r11
    7be0a13000e9:	mov    rdi,QWORD PTR [r12+0x100]
    7be0a13000f1:	add    rsp,0x10
    7be0a13000f5:	movabs r11,0x5b67773140a0
    7be0a13000ff:	jmp    r11
    7be0a1300102:	mov    eax,0x410048
    7be0a1300107:	mov    QWORD PTR [r12+0x100],rax
    7be0a130010f:	push   rdx
    7be0a1300110:	push   rsi
    7be0a1300111:	push   r10
    7be0a1300113:	push   r11
    7be0a1300115:	pushf
    7be0a1300116:	pop    r11
    7be0a1300118:	mov    QWORD PTR [rsp+0x20],r11
    7be0a130011d:	mov    rdx,QWORD PTR [rsp+0x20]
    7be0a1300122:	mov    r10d,edx
    7be0a1300125:	and    r10d,0xc0
    7be0a130012c:	shl    r10d,0x18
    7be0a1300130:	mov    r11d,edx
    7be0a1300133:	and    r11d,0x1
    7be0a1300137:	shl    r11d,0x1d
    7be0a130013b:	or     r10d,r11d
    7be0a130013e:	mov    r11d,edx
    7be0a1300141:	and    r11d,0x800
    7be0a1300148:	shl    r11d,0x11
    7be0a130014c:	or     r10d,r11d
    7be0a130014f:	btc    r10,0x1d
    7be0a1300154:	mov    r11d,0xf0000000
    7be0a130015a:	and    r11,r10
    7be0a130015d:	movabs rsi,0xffffffff0fffffff
    7be0a1300167:	and    rbx,rsi
    7be0a130016a:	or     rbx,r11
    7be0a130016d:	pop    r11
    7be0a130016f:	pop    r10
    7be0a1300171:	pop    rsi
    7be0a1300172:	pop    rdx
    7be0a1300173:	mov    QWORD PTR [r12+0x108],rbx
    7be0a130017b:	add    rsp,0x10
    7be0a130017f:	mov    eax,0xc
    7be0a1300184:	movabs r11,0x5b6777314390
    7be0a130018e:	jmp    r11
    7be0a1300191:	mov    eax,0x410050
    7be0a1300196:	mov    QWORD PTR [r12+0x100],rax
    7be0a130019e:	push   rdx
    7be0a130019f:	push   rsi
    7be0a13001a0:	push   r10
    7be0a13001a2:	push   r11
    7be0a13001a4:	mov    rdx,QWORD PTR [rsp+0x20]
    7be0a13001a9:	mov    r10d,edx
    7be0a13001ac:	and    r10d,0xc0
    7be0a13001b3:	shl    r10d,0x18
    7be0a13001b7:	mov    r11d,edx
    7be0a13001ba:	and    r11d,0x1
    7be0a13001be:	shl    r11d,0x1d
    7be0a13001c2:	or     r10d,r11d
    7be0a13001c5:	mov    r11d,edx
    7be0a13001c8:	and    r11d,0x800
    7be0a13001cf:	shl    r11d,0x11
    7be0a13001d3:	or     r10d,r11d
    7be0a13001d6:	btc    r10,0x1d
    7be0a13001db:	mov    r11d,0xf0000000
    7be0a13001e1:	and    r11,r10
    7be0a13001e4:	movabs rsi,0xffffffff0fffffff
    7be0a13001ee:	and    rbx,rsi
    7be0a13001f1:	or     rbx,r11
    7be0a13001f4:	pop    r11
    7be0a13001f6:	pop    r10
    7be0a13001f8:	pop    rsi
    7be0a13001f9:	pop    rdx
    7be0a13001fa:	mov    QWORD PTR [r12+0x108],rbx
    7be0a1300202:	add    rsp,0x10
    7be0a1300206:	mov    eax,0xc
    7be0a130020b:	movabs r11,0x5b6777314390
    7be0a1300215:	jmp    r11
    7be0a1300218:	nop    DWORD PTR [rax+rax*1+0x0]
    7be0a1300220:	sub    rsp,0x10
    7be0a1300224:	jmp    0x7be0a130005b
    7be0a1300229:	nop    DWORD PTR [rax+0x0]
    7be0a1300230:	sub    rsp,0x10
    7be0a1300234:	mov    r11,QWORD PTR [r12+0x398]
    7be0a130023c:	mov    QWORD PTR [rsp],r11
    7be0a1300240:	jmp    0x7be0a13000a3
    7be0a1300245:	nop
    7be0a1300246:	nop
    7be0a1300247:	nop
