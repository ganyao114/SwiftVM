
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/integer/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

0000718441d00000 <.data>:
    718441d00000:	sub    rsp,0x10
    718441d00004:	mov    r13d,0x1b00
    718441d0000a:	mov    r14d,0xb7
    718441d00010:	and    r14d,0xffff
    718441d00017:	mov    rax,r13
    718441d0001a:	movabs rcx,0xffffffff0000ffff
    718441d00024:	and    rax,rcx
    718441d00027:	mov    rdx,r14
    718441d0002a:	shl    rdx,0x10
    718441d0002e:	mov    ecx,0xffff0000
    718441d00033:	and    rdx,rcx
    718441d00036:	or     rax,rdx
    718441d00039:	mov    r15,rax
    718441d0003c:	mov    QWORD PTR [r12+0x8],r15
    718441d00041:	mov    r13d,0x420060
    718441d00047:	mov    QWORD PTR [r12+0x20],r13
    718441d0004c:	mov    r13d,0x0
    718441d00052:	mov    QWORD PTR [r12],r13
    718441d00056:	jmp    0x718441d0005b
    718441d0005b:	mov    r13,QWORD PTR [r12]
    718441d0005f:	add    r13,0x3
    718441d00063:	mov    r14,r13
    718441d00066:	shr    r14,0x7
    718441d0006a:	mov    rcx,r14
    718441d0006d:	xor    r13,rcx
    718441d00070:	mov    QWORD PTR [r12],r13
    718441d00074:	mov    r13,QWORD PTR [r12+0x8]
    718441d00079:	sub    r13,0x1
    718441d0007d:	mov    QWORD PTR [r12+0x8],r13
    718441d00082:	mov    rcx,QWORD PTR [r12+0x380]
    718441d0008a:	jrcxz  0x718441d00091
    718441d0008c:	jmp    0x718441d00102
    718441d00091:	jne    0x718441d0005b
    718441d00097:	pushf
    718441d00098:	pop    r11
    718441d0009a:	mov    QWORD PTR [rsp],r11
    718441d0009e:	jmp    0x718441d000a3
    718441d000a3:	mov    r13,QWORD PTR [r12+0x20]
    718441d000a8:	mov    r14,QWORD PTR [r12]
    718441d000ac:	mov    QWORD PTR [r13+0x0],r14
    718441d000b0:	mov    r13d,0x0
    718441d000b6:	mov    DWORD PTR [r12+0x32c],r13d
    718441d000be:	mov    rcx,QWORD PTR [r12+0x380]
    718441d000c6:	jrcxz  0x718441d000cd
    718441d000c8:	jmp    0x718441d00191
    718441d000cd:	mov    r13,QWORD PTR [r12+0xf0]
    718441d000d5:	mov    QWORD PTR [r12+0x100],r13
    718441d000dd:	mov    r11,QWORD PTR [rsp]
    718441d000e1:	mov    QWORD PTR [r12+0x398],r11
    718441d000e9:	mov    rdi,QWORD PTR [r12+0x100]
    718441d000f1:	add    rsp,0x10
    718441d000f5:	movabs r11,0x5b5c38d760a0
    718441d000ff:	jmp    r11
    718441d00102:	mov    eax,0x410048
    718441d00107:	mov    QWORD PTR [r12+0x100],rax
    718441d0010f:	push   rdx
    718441d00110:	push   rsi
    718441d00111:	push   r10
    718441d00113:	push   r11
    718441d00115:	pushf
    718441d00116:	pop    r11
    718441d00118:	mov    QWORD PTR [rsp+0x20],r11
    718441d0011d:	mov    rdx,QWORD PTR [rsp+0x20]
    718441d00122:	mov    r10d,edx
    718441d00125:	and    r10d,0xc0
    718441d0012c:	shl    r10d,0x18
    718441d00130:	mov    r11d,edx
    718441d00133:	and    r11d,0x1
    718441d00137:	shl    r11d,0x1d
    718441d0013b:	or     r10d,r11d
    718441d0013e:	mov    r11d,edx
    718441d00141:	and    r11d,0x800
    718441d00148:	shl    r11d,0x11
    718441d0014c:	or     r10d,r11d
    718441d0014f:	btc    r10,0x1d
    718441d00154:	mov    r11d,0xf0000000
    718441d0015a:	and    r11,r10
    718441d0015d:	movabs rsi,0xffffffff0fffffff
    718441d00167:	and    rbx,rsi
    718441d0016a:	or     rbx,r11
    718441d0016d:	pop    r11
    718441d0016f:	pop    r10
    718441d00171:	pop    rsi
    718441d00172:	pop    rdx
    718441d00173:	mov    QWORD PTR [r12+0x108],rbx
    718441d0017b:	add    rsp,0x10
    718441d0017f:	mov    eax,0xc
    718441d00184:	movabs r11,0x5b5c38d76390
    718441d0018e:	jmp    r11
    718441d00191:	mov    eax,0x410050
    718441d00196:	mov    QWORD PTR [r12+0x100],rax
    718441d0019e:	push   rdx
    718441d0019f:	push   rsi
    718441d001a0:	push   r10
    718441d001a2:	push   r11
    718441d001a4:	mov    rdx,QWORD PTR [rsp+0x20]
    718441d001a9:	mov    r10d,edx
    718441d001ac:	and    r10d,0xc0
    718441d001b3:	shl    r10d,0x18
    718441d001b7:	mov    r11d,edx
    718441d001ba:	and    r11d,0x1
    718441d001be:	shl    r11d,0x1d
    718441d001c2:	or     r10d,r11d
    718441d001c5:	mov    r11d,edx
    718441d001c8:	and    r11d,0x800
    718441d001cf:	shl    r11d,0x11
    718441d001d3:	or     r10d,r11d
    718441d001d6:	btc    r10,0x1d
    718441d001db:	mov    r11d,0xf0000000
    718441d001e1:	and    r11,r10
    718441d001e4:	movabs rsi,0xffffffff0fffffff
    718441d001ee:	and    rbx,rsi
    718441d001f1:	or     rbx,r11
    718441d001f4:	pop    r11
    718441d001f6:	pop    r10
    718441d001f8:	pop    rsi
    718441d001f9:	pop    rdx
    718441d001fa:	mov    QWORD PTR [r12+0x108],rbx
    718441d00202:	add    rsp,0x10
    718441d00206:	mov    eax,0xc
    718441d0020b:	movabs r11,0x5b5c38d76390
    718441d00215:	jmp    r11
    718441d00218:	nop    DWORD PTR [rax+rax*1+0x0]
    718441d00220:	sub    rsp,0x10
    718441d00224:	jmp    0x718441d0005b
    718441d00229:	nop    DWORD PTR [rax+0x0]
    718441d00230:	sub    rsp,0x10
    718441d00234:	mov    r11,QWORD PTR [r12+0x398]
    718441d0023c:	mov    QWORD PTR [rsp],r11
    718441d00240:	jmp    0x718441d000a3
    718441d00245:	nop
    718441d00246:	nop
    718441d00247:	nop
