00007a1af29ce69b  nop [rax+rax*1], eax
00007a1af29ce6a0  mov qword ptr [r15+0x20], 0x420060
00007a1af29ce6a8  mov qword ptr [r15], 0x03
00007a1af29ce6af  xor eax, eax
00007a1af29ce6b1  mov r14d, 0xB71B00
00007a1af29ce6b7  mov r12d, 0x01
00007a1af29ce6bd  sub r14, r12
00007a1af29ce6c0  cmc
00007a1af29ce6c1  lahf
00007a1af29ce6c2  seto al
00007a1af29ce6c5  mov [r15+0x108], eax
00007a1af29ce6cc  mov [r15+0x08], r14
00007a1af29ce6d0  mov eax, [r15+0x108]
00007a1af29ce6d7  sahf
00007a1af29ce6d8  jnz 0x00007A1AF29CE70A
00007a1af29ce6da  cmp dword ptr [r15+0x318], 0x00
00007a1af29ce6e2  jz 0x00007A1AF29CE7F0
00007a1af29ce6e8  nop [rax+rax*1], ax
00007a1af29ce6f1  nop [rax+rax*1], eax
00007a1af29ce6f9  mov eax, 0x41004C
00007a1af29ce6fe  mov [r15+0x100], rax
00007a1af29ce705  jmp 0x00007A1AF27FE110
00007a1af29ce70a  cmp dword ptr [r15+0x318], 0x00
00007a1af29ce712  jz 0x00007A1AF29CE740
00007a1af29ce718  nop [rax+rax*1], ax
00007a1af29ce721  nop [rax+rax*1], eax
00007a1af29ce729  mov eax, 0x41003C
00007a1af29ce72e  mov [r15+0x100], rax
00007a1af29ce735  jmp 0x00007A1AF27FE110
00007a1af29ce73a  int3
00007a1af29ce73b  int3
00007a1af29ce73c  nop [rax], eax
00007a1af29ce740  mov rax, [r15]
00007a1af29ce743  lea r14, [rax+0x03]
00007a1af29ce747  mov [rsp+0x10], r14
00007a1af29ce74c  shr r14, 0x07
00007a1af29ce750  mov rax, [rsp+0x10]
00007a1af29ce755  xor rax, r14
00007a1af29ce758  mov [r15], rax
00007a1af29ce75b  mov rax, [r15+0x08]
00007a1af29ce75f  mov [rsp+0x10], rax
00007a1af29ce764  xor eax, eax
00007a1af29ce766  mov r14, [rsp+0x10]
00007a1af29ce76b  mov r12d, 0x01
00007a1af29ce771  sub r14, r12
00007a1af29ce774  cmc
00007a1af29ce775  lahf
00007a1af29ce776  seto al
00007a1af29ce779  mov [r15+0x108], eax
00007a1af29ce780  mov [r15+0x08], r14
00007a1af29ce784  mov eax, [r15+0x108]
00007a1af29ce78b  sahf
00007a1af29ce78c  jnz 0x00007A1AF29CE7BE
00007a1af29ce78e  cmp dword ptr [r15+0x318], 0x00
00007a1af29ce796  jz 0x00007A1AF29CE7F0
00007a1af29ce79c  nop [rax+rax*1], ax
00007a1af29ce7a5  nop [rax+rax*1], eax
00007a1af29ce7ad  mov eax, 0x41004C
00007a1af29ce7b2  mov [r15+0x100], rax
00007a1af29ce7b9  jmp 0x00007A1AF27FE110
00007a1af29ce7be  cmp dword ptr [r15+0x318], 0x00
00007a1af29ce7c6  jz 0x00007A1AF29CE740
00007a1af29ce7cc  nop [rax+rax*1], ax
00007a1af29ce7d5  nop [rax+rax*1], eax
00007a1af29ce7dd  mov eax, 0x41003C
00007a1af29ce7e2  mov [r15+0x100], rax
00007a1af29ce7e9  jmp 0x00007A1AF27FE110
00007a1af29ce7ee  int3
00007a1af29ce7ef  int3
00007a1af29ce7f0  mov rax, [r15+0x20]
00007a1af29ce7f4  mov r14, [r15]
00007a1af29ce7f7  mov [r13+rax*1], r14
00007a1af29ce7fc  mov rax, [r15+0xF0]
00007a1af29ce803  mov [r15+0x100], rax
00007a1af29ce80a  jmp 0x00007A1AF29CE5C0
00007a1af29ce80f  int3
00007a1af29ce810  call 0x00007A1AF280E120
00007a1af29ce815  jmp 0x00007A1AF29CE7FC
00007a1af29ce81a  int3
00007a1af29ce81b  nop [rax+rax*1], eax
00007a1af29ce820  mov qword ptr [r15+0x100], 0x04
00007a1af29ce82b  mov esi, 0x00
00007a1af29ce830  mov edx, 0x09
00007a1af29ce835  mov rdi, 0x7FFFCBC52130
00007a1af29ce83f  mov rax, 0x60594419A970
00007a1af29ce849  call rax
00007a1af29ce84b  cmp dword ptr [r15+0x318], 0x00
00007a1af29ce853  jnz 0x00007A1AF27FE110
00007a1af29ce859  jmp 0x00007A1AF27FE0A0
00007a1af29ce85e  int3
00007a1af29ce85f  int3
