
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-matrix/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000070b3efb00000 <.data>:
    70b3efb00000:	sub    rsp,0x150
    70b3efb00007:	mov    r11,QWORD PTR [r12+0x398]
    70b3efb0000f:	mov    QWORD PTR [rsp],r11
    70b3efb00013:	cmp    DWORD PTR [r12+0x310],0x0
    70b3efb0001c:	je     0x70b3efb000ac
    70b3efb00022:	push   rdx
    70b3efb00023:	push   rsi
    70b3efb00024:	push   r10
    70b3efb00026:	push   r11
    70b3efb00028:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb0002d:	mov    r10d,edx
    70b3efb00030:	and    r10d,0xc0
    70b3efb00037:	shl    r10d,0x18
    70b3efb0003b:	mov    r11d,edx
    70b3efb0003e:	and    r11d,0x1
    70b3efb00042:	shl    r11d,0x1d
    70b3efb00046:	or     r10d,r11d
    70b3efb00049:	mov    r11d,edx
    70b3efb0004c:	and    r11d,0x800
    70b3efb00053:	shl    r11d,0x11
    70b3efb00057:	or     r10d,r11d
    70b3efb0005a:	btc    r10,0x1d
    70b3efb0005f:	mov    r11d,0xf0000000
    70b3efb00065:	and    r11,r10
    70b3efb00068:	movabs rsi,0xffffffff0fffffff
    70b3efb00072:	and    rbx,rsi
    70b3efb00075:	or     rbx,r11
    70b3efb00078:	pop    r11
    70b3efb0007a:	pop    r10
    70b3efb0007c:	pop    rsi
    70b3efb0007d:	pop    rdx
    70b3efb0007e:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb00086:	mov    eax,0x410168
    70b3efb0008b:	mov    QWORD PTR [r12+0x100],rax
    70b3efb00093:	add    rsp,0x150
    70b3efb0009a:	mov    eax,0x3
    70b3efb0009f:	movabs r11,0x566a970a8390
    70b3efb000a9:	jmp    r11
    70b3efb000ac:	mov    r13d,0x420000
    70b3efb000b2:	mov    QWORD PTR [r12+0x40],r13
    70b3efb000b7:	movabs r13,0x100000001
    70b3efb000c1:	mov    r14d,0x0
    70b3efb000c7:	mov    QWORD PTR [r12+0x110],r13
    70b3efb000cf:	mov    QWORD PTR [r12+0x118],r14
    70b3efb000d7:	movabs r13,0x3fa0000000000000
    70b3efb000e1:	mov    QWORD PTR [r12+0x50],r13
    70b3efb000e6:	movabs r13,0x4100000041
    70b3efb000f0:	mov    r14d,0x0
    70b3efb000f6:	mov    QWORD PTR [r12+0x120],r13
    70b3efb000fe:	mov    QWORD PTR [r12+0x128],r14
    70b3efb00106:	mov    r13d,0x4204c0
    70b3efb0010c:	mov    r14,QWORD PTR [r13+0x0]
    70b3efb00110:	mov    r13d,0x0
    70b3efb00116:	mov    QWORD PTR [r12+0x130],r14
    70b3efb0011e:	mov    QWORD PTR [r12+0x138],r13
    70b3efb00126:	movabs r13,0x3fc0000000000000
    70b3efb00130:	movabs r14,0x3fc0000000000000
    70b3efb0013a:	mov    QWORD PTR [r12+0x140],r13
    70b3efb00142:	mov    QWORD PTR [r12+0x148],r14
    70b3efb0014a:	mov    r13d,0x2
    70b3efb00150:	mov    QWORD PTR [r12+0x40],r13
    70b3efb00155:	movabs r13,0x200000002
    70b3efb0015f:	mov    r14d,0x0
    70b3efb00165:	mov    QWORD PTR [r12+0x150],r13
    70b3efb0016d:	mov    QWORD PTR [r12+0x158],r14
    70b3efb00175:	mov    r13d,0x420000
    70b3efb0017b:	mov    QWORD PTR [r12+0x58],r13
    70b3efb00180:	mov    r13,QWORD PTR [r12+0x50]
    70b3efb00185:	and    r13,0xffffffffffffffff
    70b3efb00189:	mov    QWORD PTR [r12+0x160],r13
    70b3efb00191:	mov    QWORD PTR [r12+0x168],r13
    70b3efb00199:	mov    r13d,0x2
    70b3efb0019f:	mov    QWORD PTR [r12+0x170],r13
    70b3efb001a7:	mov    QWORD PTR [r12+0x178],r13
    70b3efb001af:	mov    r13d,0x4204d0
    70b3efb001b5:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb001bb:	movdqa xmm0,xmm2
    70b3efb001bf:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb001c9:	mov    r13d,0x0
    70b3efb001cf:	mov    QWORD PTR [r12+0x48],r13
    70b3efb001d4:	mov    r13d,0x430000
    70b3efb001da:	add    r13,0x518
    70b3efb001e1:	mov    QWORD PTR [r12+0x40],r13
    70b3efb001e6:	mov    r13d,0x430000
    70b3efb001ec:	add    r13,0x720
    70b3efb001f3:	mov    QWORD PTR [r12+0x50],r13
    70b3efb001f8:	jmp    0x70b3efb001fd
    70b3efb001fd:	mov    r13,QWORD PTR [r12+0x180]
    70b3efb00205:	mov    r14,QWORD PTR [r12+0x188]
    70b3efb0020d:	mov    r15d,0x0
    70b3efb00213:	and    r13,0xffffffffffffffff
    70b3efb00217:	mov    ecx,0xffffffff
    70b3efb0021c:	and    r13,rcx
    70b3efb0021f:	mov    rcx,r13
    70b3efb00222:	mov    rbp,r15
    70b3efb00225:	or     rbp,rcx
    70b3efb00228:	and    r14,0xffffffffffffffff
    70b3efb0022c:	mov    ecx,0xffffffff
    70b3efb00231:	and    r14,rcx
    70b3efb00234:	shl    r14,0x20
    70b3efb00238:	mov    rcx,r14
    70b3efb0023b:	or     rbp,rcx
    70b3efb0023e:	mov    QWORD PTR [r12+0x210],rbp
    70b3efb00246:	mov    QWORD PTR [r12+0x218],r15
    70b3efb0024e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    70b3efb00258:	movdqa xmm2,xmm0
    70b3efb0025c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    70b3efb00266:	movdqa xmm3,xmm0
    70b3efb0026a:	movdqa xmm1,xmm3
    70b3efb0026e:	psubd  xmm2,xmm1
    70b3efb00272:	movdqa xmm14,xmm2
    70b3efb00277:	movdqa xmm1,xmm14
    70b3efb0027c:	movq   rax,xmm1
    70b3efb00281:	mov    r13,rax
    70b3efb00284:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb0028e:	movdqa xmm2,xmm0
    70b3efb00292:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb0029c:	movdqa xmm4,xmm0
    70b3efb002a0:	movdqa xmm1,xmm4
    70b3efb002a4:	paddq  xmm2,xmm1
    70b3efb002a8:	movdqa xmm0,xmm2
    70b3efb002ac:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb002b6:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    70b3efb002c0:	movdqa xmm2,xmm0
    70b3efb002c4:	movdqa xmm1,xmm2
    70b3efb002c8:	paddd  xmm3,xmm1
    70b3efb002cc:	movdqa xmm14,xmm3
    70b3efb002d1:	movdqa xmm1,xmm14
    70b3efb002d6:	movq   rax,xmm1
    70b3efb002db:	mov    r14,rax
    70b3efb002de:	mov    r15d,0x0
    70b3efb002e4:	mov    QWORD PTR [r12+0x130],r14
    70b3efb002ec:	mov    QWORD PTR [r12+0x138],r15
    70b3efb002f4:	mov    r14d,0x0
    70b3efb002fa:	mov    r15,r13
    70b3efb002fd:	mov    ecx,0xffffffff
    70b3efb00302:	and    r15,rcx
    70b3efb00305:	and    r15,0xffffffffffffffff
    70b3efb00309:	mov    rcx,r15
    70b3efb0030c:	mov    rbp,r14
    70b3efb0030f:	or     rbp,rcx
    70b3efb00312:	shr    r13,0x20
    70b3efb00316:	mov    ecx,0xffffffff
    70b3efb0031b:	and    r13,rcx
    70b3efb0031e:	and    r13,0xffffffffffffffff
    70b3efb00322:	mov    rcx,r13
    70b3efb00325:	or     r14,rcx
    70b3efb00328:	mov    QWORD PTR [r12+0x220],rbp
    70b3efb00330:	mov    QWORD PTR [r12+0x228],r14
    70b3efb00338:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb00342:	movdqa xmm2,xmm0
    70b3efb00346:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb00350:	movdqa xmm3,xmm0
    70b3efb00354:	movdqa xmm1,xmm3
    70b3efb00358:	paddd  xmm2,xmm1
    70b3efb0035c:	movdqa xmm14,xmm2
    70b3efb00361:	movdqa xmm1,xmm14
    70b3efb00366:	movq   rax,xmm1
    70b3efb0036b:	mov    r13,rax
    70b3efb0036e:	mov    r14d,0x0
    70b3efb00374:	mov    QWORD PTR [r12+0x210],r13
    70b3efb0037c:	mov    QWORD PTR [r12+0x218],r14
    70b3efb00384:	lea    r13,[r12]
    70b3efb00388:	movabs r14,0xb6e61da31
    70b3efb00392:	mov    r15d,0x4101c4
    70b3efb00398:	mov    rdx,QWORD PTR [rsp]
    70b3efb0039c:	mov    r10d,edx
    70b3efb0039f:	and    r10d,0xc0
    70b3efb003a6:	shl    r10d,0x18
    70b3efb003aa:	mov    r11d,edx
    70b3efb003ad:	and    r11d,0x1
    70b3efb003b1:	shl    r11d,0x1d
    70b3efb003b5:	or     r10d,r11d
    70b3efb003b8:	mov    r11d,edx
    70b3efb003bb:	and    r11d,0x800
    70b3efb003c2:	shl    r11d,0x11
    70b3efb003c6:	or     r10d,r11d
    70b3efb003c9:	btc    r10,0x1d
    70b3efb003ce:	mov    r11d,0xf0000000
    70b3efb003d4:	and    r11,r10
    70b3efb003d7:	movabs rsi,0xffffffff0fffffff
    70b3efb003e1:	and    rbx,rsi
    70b3efb003e4:	or     rbx,r11
    70b3efb003e7:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb003f3:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb003fb:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb00401:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb00407:	movabs r11,0x566a96f0edc0
    70b3efb00411:	mov    rdi,r13
    70b3efb00414:	mov    rsi,r14
    70b3efb00417:	mov    rdx,r15
    70b3efb0041a:	call   r11
    70b3efb0041d:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb00423:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb0042b:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb00437:	mov    rbp,rax
    70b3efb0043a:	mov    r13,QWORD PTR [r12+0x210]
    70b3efb00442:	mov    r14d,0x0
    70b3efb00448:	mov    r15,r13
    70b3efb0044b:	mov    ecx,0xffffffff
    70b3efb00450:	and    r15,rcx
    70b3efb00453:	and    r15,0xffffffffffffffff
    70b3efb00457:	mov    rcx,r15
    70b3efb0045a:	mov    rbp,r14
    70b3efb0045d:	or     rbp,rcx
    70b3efb00460:	shr    r13,0x20
    70b3efb00464:	mov    ecx,0xffffffff
    70b3efb00469:	and    r13,rcx
    70b3efb0046c:	and    r13,0xffffffffffffffff
    70b3efb00470:	mov    rcx,r13
    70b3efb00473:	or     r14,rcx
    70b3efb00476:	mov    QWORD PTR [r12+0x210],rbp
    70b3efb0047e:	mov    QWORD PTR [r12+0x218],r14
    70b3efb00486:	lea    r13,[r12]
    70b3efb0048a:	movabs r14,0xb6e61da10
    70b3efb00494:	mov    r15d,0x4101cc
    70b3efb0049a:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb004a6:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb004ae:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb004b4:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb004ba:	movabs r11,0x566a96f0edc0
    70b3efb004c4:	mov    rdi,r13
    70b3efb004c7:	mov    rsi,r14
    70b3efb004ca:	mov    rdx,r15
    70b3efb004cd:	call   r11
    70b3efb004d0:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb004d6:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb004de:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb004ea:	mov    rbp,rax
    70b3efb004ed:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb004f7:	movdqa xmm2,xmm0
    70b3efb004fb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    70b3efb00505:	movdqa xmm3,xmm0
    70b3efb00509:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb00511:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb0051c:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb00524:	movdqa xmm0,xmm2
    70b3efb00528:	movdqa xmm1,xmm3
    70b3efb0052c:	movq   rax,xmm0
    70b3efb00531:	add    rax,rax
    70b3efb00534:	je     0x70b3efb0054a
    70b3efb00536:	shr    rax,0x35
    70b3efb0053a:	sub    eax,0x201
    70b3efb0053f:	cmp    eax,0x3fc
    70b3efb00544:	ja     0x70b3efb04e57
    70b3efb0054a:	movdqa xmm14,xmm0
    70b3efb0054f:	psrldq xmm14,0x8
    70b3efb00555:	movq   rax,xmm14
    70b3efb0055a:	add    rax,rax
    70b3efb0055d:	je     0x70b3efb00573
    70b3efb0055f:	shr    rax,0x35
    70b3efb00563:	sub    eax,0x201
    70b3efb00568:	cmp    eax,0x3fc
    70b3efb0056d:	ja     0x70b3efb04e57
    70b3efb00573:	movq   rax,xmm1
    70b3efb00578:	add    rax,rax
    70b3efb0057b:	je     0x70b3efb00591
    70b3efb0057d:	shr    rax,0x35
    70b3efb00581:	sub    eax,0x201
    70b3efb00586:	cmp    eax,0x3fc
    70b3efb0058b:	ja     0x70b3efb04e57
    70b3efb00591:	movdqa xmm14,xmm1
    70b3efb00596:	psrldq xmm14,0x8
    70b3efb0059c:	movq   rax,xmm14
    70b3efb005a1:	add    rax,rax
    70b3efb005a4:	je     0x70b3efb005ba
    70b3efb005a6:	shr    rax,0x35
    70b3efb005aa:	sub    eax,0x201
    70b3efb005af:	cmp    eax,0x3fc
    70b3efb005b4:	ja     0x70b3efb04e57
    70b3efb005ba:	mulpd  xmm0,xmm1
    70b3efb005be:	movdqa xmm4,xmm0
    70b3efb005c2:	movdqa xmm0,xmm4
    70b3efb005c6:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb005d0:	mov    r13,QWORD PTR [r12+0x48]
    70b3efb005d5:	mov    r14,QWORD PTR [r12+0x50]
    70b3efb005da:	mov    rcx,r13
    70b3efb005dd:	add    r14,rcx
    70b3efb005e0:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb005e8:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb005f0:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb005f8:	shr    r11d,1
    70b3efb005fb:	and    r11d,0x10
    70b3efb005ff:	or     DWORD PTR [r12+0x314],r11d
    70b3efb00607:	movdqu XMMWORD PTR [r14],xmm4
    70b3efb0060c:	mov    r14d,0x0
    70b3efb00612:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb0061a:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb00624:	movdqa xmm2,xmm0
    70b3efb00628:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    70b3efb00632:	movdqa xmm3,xmm0
    70b3efb00636:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb0063e:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb00649:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb00651:	movdqa xmm0,xmm2
    70b3efb00655:	movdqa xmm1,xmm3
    70b3efb00659:	movq   rax,xmm0
    70b3efb0065e:	add    rax,rax
    70b3efb00661:	je     0x70b3efb00677
    70b3efb00663:	shr    rax,0x35
    70b3efb00667:	sub    eax,0x201
    70b3efb0066c:	cmp    eax,0x3fc
    70b3efb00671:	ja     0x70b3efb04e7b
    70b3efb00677:	movdqa xmm14,xmm0
    70b3efb0067c:	psrldq xmm14,0x8
    70b3efb00682:	movq   rax,xmm14
    70b3efb00687:	add    rax,rax
    70b3efb0068a:	je     0x70b3efb006a0
    70b3efb0068c:	shr    rax,0x35
    70b3efb00690:	sub    eax,0x201
    70b3efb00695:	cmp    eax,0x3fc
    70b3efb0069a:	ja     0x70b3efb04e7b
    70b3efb006a0:	movq   rax,xmm1
    70b3efb006a5:	add    rax,rax
    70b3efb006a8:	je     0x70b3efb006be
    70b3efb006aa:	shr    rax,0x35
    70b3efb006ae:	sub    eax,0x201
    70b3efb006b3:	cmp    eax,0x3fc
    70b3efb006b8:	ja     0x70b3efb04e7b
    70b3efb006be:	movdqa xmm14,xmm1
    70b3efb006c3:	psrldq xmm14,0x8
    70b3efb006c9:	movq   rax,xmm14
    70b3efb006ce:	add    rax,rax
    70b3efb006d1:	je     0x70b3efb006e7
    70b3efb006d3:	shr    rax,0x35
    70b3efb006d7:	sub    eax,0x201
    70b3efb006dc:	cmp    eax,0x3fc
    70b3efb006e1:	ja     0x70b3efb04e7b
    70b3efb006e7:	mulpd  xmm0,xmm1
    70b3efb006eb:	movdqa xmm4,xmm0
    70b3efb006ef:	movdqa xmm0,xmm4
    70b3efb006f3:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb006fd:	mov    r14,QWORD PTR [r12+0x40]
    70b3efb00702:	mov    rcx,r13
    70b3efb00705:	add    r14,rcx
    70b3efb00708:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb00710:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb00718:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb00720:	shr    r11d,1
    70b3efb00723:	and    r11d,0x10
    70b3efb00727:	or     DWORD PTR [r12+0x314],r11d
    70b3efb0072f:	movdqu XMMWORD PTR [r14],xmm4
    70b3efb00734:	mov    r14d,0x0
    70b3efb0073a:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb00742:	add    r13,0x10
    70b3efb00746:	mov    QWORD PTR [r12+0x48],r13
    70b3efb0074b:	sub    r13,0x200
    70b3efb00752:	mov    rcx,QWORD PTR [r12+0x380]
    70b3efb0075a:	jrcxz  0x70b3efb00761
    70b3efb0075c:	jmp    0x70b3efb06fd6
    70b3efb00761:	pushf
    70b3efb00762:	pop    r11
    70b3efb00764:	mov    QWORD PTR [rsp],r11
    70b3efb00768:	jne    0x70b3efb001fd
    70b3efb0076e:	jmp    0x70b3efb00773
    70b3efb00773:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb0077b:	sub    r13,0x150
    70b3efb00782:	mov    QWORD PTR [r12+0xf8],r13
    70b3efb0078a:	mov    r14,QWORD PTR [r12+0x50]
    70b3efb0078f:	mov    r15,r14
    70b3efb00792:	add    r15,0x80
    70b3efb00799:	mov    rbp,r15
    70b3efb0079c:	add    rbp,0x10
    70b3efb007a0:	movdqu xmm2,XMMWORD PTR [r15]
    70b3efb007a5:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    70b3efb007aa:	movdqa xmm0,xmm2
    70b3efb007ae:	movdqu XMMWORD PTR [r12+0x130],xmm0
    70b3efb007b8:	movdqa xmm0,xmm3
    70b3efb007bc:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb007c6:	mov    r15d,0x0
    70b3efb007cc:	mov    QWORD PTR [r12+0x48],r15
    70b3efb007d1:	add    r14,0x40
    70b3efb007d5:	mov    r15,r14
    70b3efb007d8:	add    r15,0x10
    70b3efb007dc:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb007e1:	movdqu xmm3,XMMWORD PTR [r15]
    70b3efb007e6:	movdqa xmm0,xmm2
    70b3efb007ea:	movdqu XMMWORD PTR [r12+0x250],xmm0
    70b3efb007f4:	movdqa xmm0,xmm3
    70b3efb007f8:	movdqu XMMWORD PTR [r12+0x120],xmm0
    70b3efb00802:	add    r13,0x120
    70b3efb00809:	mov    r14,r13
    70b3efb0080c:	add    r14,0x8
    70b3efb00810:	mov    r15,QWORD PTR [r12+0x1c0]
    70b3efb00818:	mov    rbp,QWORD PTR [r12+0x1b0]
    70b3efb00820:	mov    QWORD PTR [r13+0x0],r15
    70b3efb00824:	mov    r13d,0x0
    70b3efb0082a:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00832:	mov    QWORD PTR [r14],rbp
    70b3efb00835:	mov    r13d,0x0
    70b3efb0083b:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00843:	mov    r13d,0x0
    70b3efb00849:	mov    r14d,0x0
    70b3efb0084f:	mov    QWORD PTR [r12+0x1b0],r13
    70b3efb00857:	mov    QWORD PTR [r12+0x1b8],r14
    70b3efb0085f:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb00867:	mov    r14,r13
    70b3efb0086a:	add    r14,0x100
    70b3efb00871:	mov    r15,r14
    70b3efb00874:	add    r15,0x8
    70b3efb00878:	mov    rbp,QWORD PTR [r12+0x200]
    70b3efb00880:	mov    r8,QWORD PTR [r12+0x1f0]
    70b3efb00888:	mov    QWORD PTR [r14],rbp
    70b3efb0088b:	mov    r14d,0x0
    70b3efb00891:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb00899:	mov    QWORD PTR [r15],r8
    70b3efb0089c:	mov    r14d,0x0
    70b3efb008a2:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb008aa:	mov    r14,r13
    70b3efb008ad:	add    r14,0xe0
    70b3efb008b4:	mov    r15,r14
    70b3efb008b7:	add    r15,0x10
    70b3efb008bb:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb008c5:	movdqa xmm2,xmm0
    70b3efb008c9:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    70b3efb008d3:	movdqa xmm3,xmm0
    70b3efb008d7:	movdqu XMMWORD PTR [r14],xmm2
    70b3efb008dc:	mov    r14d,0x0
    70b3efb008e2:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb008ea:	movdqu XMMWORD PTR [r15],xmm3
    70b3efb008ef:	mov    r14d,0x0
    70b3efb008f5:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb008fd:	mov    r14,QWORD PTR [r12+0x50]
    70b3efb00902:	mov    r15,r14
    70b3efb00905:	add    r15,0xc0
    70b3efb0090c:	mov    rbp,r15
    70b3efb0090f:	add    rbp,0x10
    70b3efb00913:	movdqu xmm2,XMMWORD PTR [r15]
    70b3efb00918:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    70b3efb0091d:	movdqa xmm0,xmm2
    70b3efb00921:	movdqu XMMWORD PTR [r12+0x130],xmm0
    70b3efb0092b:	movdqa xmm0,xmm3
    70b3efb0092f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb00939:	add    r13,0x110
    70b3efb00940:	mov    r15,r13
    70b3efb00943:	add    r15,0x8
    70b3efb00947:	mov    rbp,QWORD PTR [r12+0x1e0]
    70b3efb0094f:	mov    r8,QWORD PTR [r12+0x1d0]
    70b3efb00957:	mov    QWORD PTR [r13+0x0],rbp
    70b3efb0095b:	mov    r13d,0x0
    70b3efb00961:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00969:	mov    QWORD PTR [r15],r8
    70b3efb0096c:	mov    r13d,0x0
    70b3efb00972:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb0097a:	mov    r13,r14
    70b3efb0097d:	add    r13,0x10
    70b3efb00981:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb00986:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    70b3efb0098c:	movdqa xmm0,xmm2
    70b3efb00990:	movdqu XMMWORD PTR [r12+0x170],xmm0
    70b3efb0099a:	movdqa xmm0,xmm3
    70b3efb0099e:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb009a8:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb009b0:	mov    r14,r13
    70b3efb009b3:	add    r14,0x130
    70b3efb009ba:	mov    r15,r14
    70b3efb009bd:	add    r15,0x8
    70b3efb009c1:	mov    rbp,QWORD PTR [r12+0x1a0]
    70b3efb009c9:	mov    r8,QWORD PTR [r12+0x190]
    70b3efb009d1:	mov    QWORD PTR [r14],rbp
    70b3efb009d4:	mov    r14d,0x0
    70b3efb009da:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb009e2:	mov    QWORD PTR [r15],r8
    70b3efb009e5:	mov    r14d,0x0
    70b3efb009eb:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb009f3:	mov    r14,QWORD PTR [r12+0x50]
    70b3efb009f8:	mov    r15,r14
    70b3efb009fb:	add    r15,0x140
    70b3efb00a02:	mov    rbp,r15
    70b3efb00a05:	add    rbp,0x10
    70b3efb00a09:	movdqu xmm2,XMMWORD PTR [r15]
    70b3efb00a0e:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    70b3efb00a13:	movdqa xmm0,xmm2
    70b3efb00a17:	movdqu XMMWORD PTR [r12+0x270],xmm0
    70b3efb00a21:	movdqa xmm0,xmm3
    70b3efb00a25:	movdqu XMMWORD PTR [r12+0x190],xmm0
    70b3efb00a2f:	add    r13,0xc0
    70b3efb00a36:	mov    r15,r13
    70b3efb00a39:	add    r15,0x10
    70b3efb00a3d:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb00a47:	movdqa xmm2,xmm0
    70b3efb00a4b:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    70b3efb00a55:	movdqa xmm3,xmm0
    70b3efb00a59:	movdqu XMMWORD PTR [r13+0x0],xmm2
    70b3efb00a5f:	mov    r13d,0x0
    70b3efb00a65:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00a6d:	movdqu XMMWORD PTR [r15],xmm3
    70b3efb00a72:	mov    r13d,0x0
    70b3efb00a78:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00a80:	add    r14,0x100
    70b3efb00a87:	mov    r13,r14
    70b3efb00a8a:	add    r13,0x10
    70b3efb00a8e:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb00a93:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    70b3efb00a99:	movdqa xmm0,xmm2
    70b3efb00a9d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb00aa7:	movdqa xmm0,xmm3
    70b3efb00aab:	movdqu XMMWORD PTR [r12+0x300],xmm0
    70b3efb00ab5:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb00abd:	mov    r14,r13
    70b3efb00ac0:	add    r14,0x140
    70b3efb00ac7:	mov    r15,QWORD PTR [r12+0xe8]
    70b3efb00acf:	mov    QWORD PTR [r14],r15
    70b3efb00ad2:	mov    r14d,0x0
    70b3efb00ad8:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb00ae0:	mov    r14,QWORD PTR [r12+0x50]
    70b3efb00ae5:	mov    r15,r14
    70b3efb00ae8:	add    r15,0x180
    70b3efb00aef:	mov    rbp,r15
    70b3efb00af2:	add    rbp,0x10
    70b3efb00af6:	movdqu xmm2,XMMWORD PTR [r15]
    70b3efb00afb:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    70b3efb00b00:	movdqa xmm0,xmm2
    70b3efb00b04:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    70b3efb00b0e:	movdqa xmm0,xmm3
    70b3efb00b12:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    70b3efb00b1c:	mov    r15,r14
    70b3efb00b1f:	add    r15,0x1c0
    70b3efb00b26:	mov    rbp,r15
    70b3efb00b29:	add    rbp,0x10
    70b3efb00b2d:	movdqu xmm2,XMMWORD PTR [r15]
    70b3efb00b32:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    70b3efb00b37:	movdqa xmm0,xmm2
    70b3efb00b3b:	movdqu XMMWORD PTR [r12+0x240],xmm0
    70b3efb00b45:	movdqa xmm0,xmm3
    70b3efb00b49:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    70b3efb00b53:	add    r13,0x20
    70b3efb00b57:	mov    r15,r13
    70b3efb00b5a:	add    r15,0x10
    70b3efb00b5e:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb00b68:	movdqa xmm2,xmm0
    70b3efb00b6c:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    70b3efb00b76:	movdqa xmm3,xmm0
    70b3efb00b7a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    70b3efb00b80:	mov    r13d,0x0
    70b3efb00b86:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00b8e:	movdqu XMMWORD PTR [r15],xmm3
    70b3efb00b93:	mov    r13d,0x0
    70b3efb00b99:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00ba1:	mov    r13,r14
    70b3efb00ba4:	add    r13,0x60
    70b3efb00ba8:	mov    r15,r13
    70b3efb00bab:	add    r15,0x10
    70b3efb00baf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb00bb5:	movdqu xmm3,XMMWORD PTR [r15]
    70b3efb00bba:	movdqa xmm0,xmm2
    70b3efb00bbe:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb00bc8:	movdqa xmm0,xmm3
    70b3efb00bcc:	movdqu XMMWORD PTR [r12+0x120],xmm0
    70b3efb00bd6:	add    r14,0x20
    70b3efb00bda:	mov    r13,r14
    70b3efb00bdd:	add    r13,0x10
    70b3efb00be1:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb00be6:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    70b3efb00bec:	movdqa xmm0,xmm2
    70b3efb00bf0:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    70b3efb00bfa:	movdqa xmm0,xmm3
    70b3efb00bfe:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
    70b3efb00c08:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb00c10:	mov    r14,r13
    70b3efb00c13:	add    r14,0x60
    70b3efb00c17:	mov    r15,r14
    70b3efb00c1a:	add    r15,0x10
    70b3efb00c1e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb00c28:	movdqa xmm2,xmm0
    70b3efb00c2c:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    70b3efb00c36:	movdqa xmm3,xmm0
    70b3efb00c3a:	movdqu XMMWORD PTR [r14],xmm2
    70b3efb00c3f:	mov    r14d,0x0
    70b3efb00c45:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb00c4d:	movdqu XMMWORD PTR [r15],xmm3
    70b3efb00c52:	mov    r14d,0x0
    70b3efb00c58:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb00c60:	mov    r14,QWORD PTR [r12+0x50]
    70b3efb00c65:	mov    r15,r14
    70b3efb00c68:	add    r15,0xe0
    70b3efb00c6f:	mov    rbp,r15
    70b3efb00c72:	add    rbp,0x10
    70b3efb00c76:	movdqu xmm2,XMMWORD PTR [r15]
    70b3efb00c7b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    70b3efb00c80:	movdqa xmm0,xmm2
    70b3efb00c84:	movdqu XMMWORD PTR [r12+0x200],xmm0
    70b3efb00c8e:	movdqa xmm0,xmm3
    70b3efb00c92:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    70b3efb00c9c:	add    r13,0xa0
    70b3efb00ca3:	mov    r15,r13
    70b3efb00ca6:	add    r15,0x10
    70b3efb00caa:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    70b3efb00cb4:	movdqa xmm2,xmm0
    70b3efb00cb8:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb00cc2:	movdqa xmm3,xmm0
    70b3efb00cc6:	movdqu XMMWORD PTR [r13+0x0],xmm2
    70b3efb00ccc:	mov    r13d,0x0
    70b3efb00cd2:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00cda:	movdqu XMMWORD PTR [r15],xmm3
    70b3efb00cdf:	mov    r13d,0x0
    70b3efb00ce5:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00ced:	mov    r13,r14
    70b3efb00cf0:	add    r13,0xa0
    70b3efb00cf7:	mov    r15,r13
    70b3efb00cfa:	add    r15,0x10
    70b3efb00cfe:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb00d04:	movdqu xmm3,XMMWORD PTR [r15]
    70b3efb00d09:	movdqa xmm0,xmm2
    70b3efb00d0d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb00d17:	movdqa xmm0,xmm3
    70b3efb00d1b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    70b3efb00d25:	mov    r13,r14
    70b3efb00d28:	add    r13,0x120
    70b3efb00d2f:	mov    r15,r13
    70b3efb00d32:	add    r15,0x10
    70b3efb00d36:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    70b3efb00d3c:	movdqu xmm5,XMMWORD PTR [r15]
    70b3efb00d41:	movdqa xmm0,xmm4
    70b3efb00d45:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    70b3efb00d4f:	movdqa xmm0,xmm5
    70b3efb00d53:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    70b3efb00d5d:	add    r14,0x160
    70b3efb00d64:	mov    r13,r14
    70b3efb00d67:	add    r13,0x10
    70b3efb00d6b:	movdqu xmm4,XMMWORD PTR [r14]
    70b3efb00d70:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    70b3efb00d76:	movdqa xmm0,xmm4
    70b3efb00d7a:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    70b3efb00d84:	movdqa xmm0,xmm5
    70b3efb00d88:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
    70b3efb00d92:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb00d9a:	mov    r14,r13
    70b3efb00d9d:	add    r14,0x80
    70b3efb00da4:	mov    r15,r14
    70b3efb00da7:	add    r15,0x10
    70b3efb00dab:	movdqu XMMWORD PTR [r14],xmm3
    70b3efb00db0:	mov    r14d,0x0
    70b3efb00db6:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb00dbe:	movdqu XMMWORD PTR [r15],xmm2
    70b3efb00dc3:	mov    r14d,0x0
    70b3efb00dc9:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb00dd1:	mov    r14,QWORD PTR [r12+0x50]
    70b3efb00dd6:	mov    r15,r14
    70b3efb00dd9:	add    r15,0x1a0
    70b3efb00de0:	mov    rbp,r15
    70b3efb00de3:	add    rbp,0x10
    70b3efb00de7:	movdqu xmm2,XMMWORD PTR [r15]
    70b3efb00dec:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    70b3efb00df1:	movdqa xmm0,xmm2
    70b3efb00df5:	movdqu XMMWORD PTR [r12+0x290],xmm0
    70b3efb00dff:	movdqa xmm0,xmm3
    70b3efb00e03:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
    70b3efb00e0d:	add    r14,0x1e0
    70b3efb00e14:	mov    r15,r14
    70b3efb00e17:	add    r15,0x10
    70b3efb00e1b:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb00e20:	movdqu xmm3,XMMWORD PTR [r15]
    70b3efb00e25:	movdqa xmm0,xmm2
    70b3efb00e29:	movdqu XMMWORD PTR [r12+0x230],xmm0
    70b3efb00e33:	movdqa xmm0,xmm3
    70b3efb00e37:	movdqu XMMWORD PTR [r12+0x280],xmm0
    70b3efb00e41:	mov    r14d,0x430000
    70b3efb00e47:	add    r14,0x920
    70b3efb00e4e:	mov    QWORD PTR [r12+0x50],r14
    70b3efb00e53:	mov    r14,r13
    70b3efb00e56:	add    r14,0x40
    70b3efb00e5a:	mov    r15,r14
    70b3efb00e5d:	add    r15,0x10
    70b3efb00e61:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb00e6b:	movdqa xmm5,xmm0
    70b3efb00e6f:	movdqu XMMWORD PTR [r14],xmm4
    70b3efb00e74:	mov    r14d,0x0
    70b3efb00e7a:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb00e82:	movdqu XMMWORD PTR [r15],xmm5
    70b3efb00e87:	mov    r14d,0x0
    70b3efb00e8d:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb00e95:	mov    r14,r13
    70b3efb00e98:	add    r14,0x10
    70b3efb00e9c:	movdqu XMMWORD PTR [r13+0x0],xmm3
    70b3efb00ea2:	mov    r13d,0x0
    70b3efb00ea8:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00eb0:	movdqu XMMWORD PTR [r14],xmm2
    70b3efb00eb5:	mov    r13d,0x0
    70b3efb00ebb:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb00ec3:	jmp    0x70b3efb00ec8
    70b3efb00ec8:	mov    r13d,0x0
    70b3efb00ece:	mov    QWORD PTR [r12+0x58],r13
    70b3efb00ed3:	jmp    0x70b3efb00ed8
    70b3efb00ed8:	mov    r13,QWORD PTR [r12+0x58]
    70b3efb00edd:	mov    r14,QWORD PTR [r12+0x40]
    70b3efb00ee2:	mov    rcx,r13
    70b3efb00ee5:	add    r14,rcx
    70b3efb00ee8:	mov    QWORD PTR [r12+0x60],r14
    70b3efb00eed:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    70b3efb00ef7:	movdqa xmm2,xmm0
    70b3efb00efb:	movdqa xmm1,xmm2
    70b3efb00eff:	por    xmm2,xmm1
    70b3efb00f03:	movdqa xmm0,xmm2
    70b3efb00f07:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    70b3efb00f11:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    70b3efb00f1b:	movdqa xmm2,xmm0
    70b3efb00f1f:	movdqa xmm1,xmm2
    70b3efb00f23:	por    xmm2,xmm1
    70b3efb00f27:	movdqa xmm0,xmm2
    70b3efb00f2b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    70b3efb00f35:	add    r14,0x30
    70b3efb00f39:	mov    r13,r14
    70b3efb00f3c:	add    r13,0x8
    70b3efb00f40:	mov    r15,QWORD PTR [r14]
    70b3efb00f43:	mov    r14,QWORD PTR [r13+0x0]
    70b3efb00f47:	mov    r13d,0x0
    70b3efb00f4d:	mov    QWORD PTR [r12+0x130],r15
    70b3efb00f55:	mov    QWORD PTR [r12+0x138],r13
    70b3efb00f5d:	mov    r13d,0x0
    70b3efb00f63:	mov    QWORD PTR [r12+0x280],r14
    70b3efb00f6b:	mov    QWORD PTR [r12+0x288],r13
    70b3efb00f73:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    70b3efb00f7d:	movdqa xmm2,xmm0
    70b3efb00f81:	movdqa xmm1,xmm2
    70b3efb00f85:	por    xmm2,xmm1
    70b3efb00f89:	movdqa xmm0,xmm2
    70b3efb00f8d:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    70b3efb00f97:	mov    r13,QWORD PTR [r12+0x60]
    70b3efb00f9c:	mov    r14,r13
    70b3efb00f9f:	add    r14,0x20
    70b3efb00fa3:	mov    r15,r14
    70b3efb00fa6:	add    r15,0x8
    70b3efb00faa:	mov    rbp,QWORD PTR [r14]
    70b3efb00fad:	mov    r14,QWORD PTR [r15]
    70b3efb00fb0:	mov    r15d,0x0
    70b3efb00fb6:	mov    QWORD PTR [r12+0x150],rbp
    70b3efb00fbe:	mov    QWORD PTR [r12+0x158],r15
    70b3efb00fc6:	mov    r15d,0x0
    70b3efb00fcc:	mov    QWORD PTR [r12+0x140],r14
    70b3efb00fd4:	mov    QWORD PTR [r12+0x148],r15
    70b3efb00fdc:	add    r13,0x10
    70b3efb00fe0:	mov    r14,r13
    70b3efb00fe3:	add    r14,0x8
    70b3efb00fe7:	mov    r15,QWORD PTR [r13+0x0]
    70b3efb00feb:	mov    r13,QWORD PTR [r14]
    70b3efb00fee:	mov    r14d,0x0
    70b3efb00ff4:	mov    QWORD PTR [r12+0x170],r15
    70b3efb00ffc:	mov    QWORD PTR [r12+0x178],r14
    70b3efb01004:	mov    r14d,0x0
    70b3efb0100a:	mov    QWORD PTR [r12+0x160],r13
    70b3efb01012:	mov    QWORD PTR [r12+0x168],r14
    70b3efb0101a:	mov    r13,QWORD PTR [r12+0x60]
    70b3efb0101f:	mov    r14d,0x8
    70b3efb01025:	mov    r15,QWORD PTR [r13+0x0]
    70b3efb01029:	mov    QWORD PTR [r12+0x180],r15
    70b3efb01031:	mov    QWORD PTR [r12+0x188],r15
    70b3efb01039:	mov    rcx,r14
    70b3efb0103c:	add    r13,rcx
    70b3efb0103f:	mov    QWORD PTR [r12+0x60],r13
    70b3efb01044:	mov    r14,QWORD PTR [r13+0x0]
    70b3efb01048:	mov    r13d,0x0
    70b3efb0104e:	mov    QWORD PTR [r12+0x230],r14
    70b3efb01056:	mov    QWORD PTR [r12+0x238],r13
    70b3efb0105e:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb01066:	mov    r14,r13
    70b3efb01069:	add    r14,0x50
    70b3efb0106d:	mov    r15,r14
    70b3efb01070:	add    r15,0x10
    70b3efb01074:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb01079:	movdqu xmm3,XMMWORD PTR [r15]
    70b3efb0107e:	movdqa xmm0,xmm2
    70b3efb01082:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb0108c:	movdqa xmm0,xmm3
    70b3efb01090:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb0109a:	add    r13,0x30
    70b3efb0109e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb010a4:	movdqa xmm0,xmm2
    70b3efb010a8:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb010b2:	mov    r13,QWORD PTR [r12+0x58]
    70b3efb010b7:	mov    r14,QWORD PTR [r12+0x50]
    70b3efb010bc:	mov    rcx,r13
    70b3efb010bf:	add    r14,rcx
    70b3efb010c2:	mov    QWORD PTR [r12+0x60],r14
    70b3efb010c7:	add    r13,0x40
    70b3efb010cb:	mov    QWORD PTR [r12+0x58],r13
    70b3efb010d0:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb010da:	movdqa xmm3,xmm0
    70b3efb010de:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    70b3efb010e8:	movdqa xmm4,xmm0
    70b3efb010ec:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb010f4:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb010ff:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb01107:	movdqa xmm0,xmm3
    70b3efb0110b:	movdqa xmm1,xmm4
    70b3efb0110f:	movq   rax,xmm0
    70b3efb01114:	add    rax,rax
    70b3efb01117:	je     0x70b3efb0112d
    70b3efb01119:	shr    rax,0x35
    70b3efb0111d:	sub    eax,0x201
    70b3efb01122:	cmp    eax,0x3fc
    70b3efb01127:	ja     0x70b3efb04e9f
    70b3efb0112d:	movdqa xmm14,xmm0
    70b3efb01132:	psrldq xmm14,0x8
    70b3efb01138:	movq   rax,xmm14
    70b3efb0113d:	add    rax,rax
    70b3efb01140:	je     0x70b3efb01156
    70b3efb01142:	shr    rax,0x35
    70b3efb01146:	sub    eax,0x201
    70b3efb0114b:	cmp    eax,0x3fc
    70b3efb01150:	ja     0x70b3efb04e9f
    70b3efb01156:	movq   rax,xmm1
    70b3efb0115b:	add    rax,rax
    70b3efb0115e:	je     0x70b3efb01174
    70b3efb01160:	shr    rax,0x35
    70b3efb01164:	sub    eax,0x201
    70b3efb01169:	cmp    eax,0x3fc
    70b3efb0116e:	ja     0x70b3efb04e9f
    70b3efb01174:	movdqa xmm14,xmm1
    70b3efb01179:	psrldq xmm14,0x8
    70b3efb0117f:	movq   rax,xmm14
    70b3efb01184:	add    rax,rax
    70b3efb01187:	je     0x70b3efb0119d
    70b3efb01189:	shr    rax,0x35
    70b3efb0118d:	sub    eax,0x201
    70b3efb01192:	cmp    eax,0x3fc
    70b3efb01197:	ja     0x70b3efb04e9f
    70b3efb0119d:	mulpd  xmm0,xmm1
    70b3efb011a1:	movdqa xmm5,xmm0
    70b3efb011a5:	movdqa xmm0,xmm5
    70b3efb011a9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    70b3efb011b3:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    70b3efb011bd:	movdqa xmm4,xmm0
    70b3efb011c1:	movdqa xmm0,xmm2
    70b3efb011c5:	movdqa xmm1,xmm4
    70b3efb011c9:	pshufd xmm1,xmm1,0x44
    70b3efb011ce:	movq   rax,xmm0
    70b3efb011d3:	add    rax,rax
    70b3efb011d6:	je     0x70b3efb011ec
    70b3efb011d8:	shr    rax,0x35
    70b3efb011dc:	sub    eax,0x201
    70b3efb011e1:	cmp    eax,0x3fc
    70b3efb011e6:	ja     0x70b3efb04ec3
    70b3efb011ec:	movdqa xmm14,xmm0
    70b3efb011f1:	psrldq xmm14,0x8
    70b3efb011f7:	movq   rax,xmm14
    70b3efb011fc:	add    rax,rax
    70b3efb011ff:	je     0x70b3efb01215
    70b3efb01201:	shr    rax,0x35
    70b3efb01205:	sub    eax,0x201
    70b3efb0120a:	cmp    eax,0x3fc
    70b3efb0120f:	ja     0x70b3efb04ec3
    70b3efb01215:	movq   rax,xmm1
    70b3efb0121a:	add    rax,rax
    70b3efb0121d:	je     0x70b3efb01233
    70b3efb0121f:	shr    rax,0x35
    70b3efb01223:	sub    eax,0x201
    70b3efb01228:	cmp    eax,0x3fc
    70b3efb0122d:	ja     0x70b3efb04ec3
    70b3efb01233:	movdqa xmm14,xmm1
    70b3efb01238:	psrldq xmm14,0x8
    70b3efb0123e:	movq   rax,xmm14
    70b3efb01243:	add    rax,rax
    70b3efb01246:	je     0x70b3efb0125c
    70b3efb01248:	shr    rax,0x35
    70b3efb0124c:	sub    eax,0x201
    70b3efb01251:	cmp    eax,0x3fc
    70b3efb01256:	ja     0x70b3efb04ec3
    70b3efb0125c:	mulpd  xmm0,xmm1
    70b3efb01260:	movdqa xmm5,xmm0
    70b3efb01264:	movdqa xmm0,xmm5
    70b3efb01268:	movdqu XMMWORD PTR [r12+0x260],xmm0
    70b3efb01272:	mov    r13d,0x0
    70b3efb01278:	mov    r14d,0x0
    70b3efb0127e:	mov    QWORD PTR [r12+0x110],r13
    70b3efb01286:	mov    QWORD PTR [r12+0x118],r14
    70b3efb0128e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb01298:	movdqa xmm2,xmm0
    70b3efb0129c:	movdqa xmm0,xmm3
    70b3efb012a0:	movdqa xmm1,xmm2
    70b3efb012a4:	movq   rax,xmm0
    70b3efb012a9:	add    rax,rax
    70b3efb012ac:	je     0x70b3efb012c2
    70b3efb012ae:	shr    rax,0x35
    70b3efb012b2:	sub    eax,0x201
    70b3efb012b7:	cmp    eax,0x3fc
    70b3efb012bc:	ja     0x70b3efb04ee7
    70b3efb012c2:	movdqa xmm14,xmm0
    70b3efb012c7:	psrldq xmm14,0x8
    70b3efb012cd:	movq   rax,xmm14
    70b3efb012d2:	add    rax,rax
    70b3efb012d5:	je     0x70b3efb012eb
    70b3efb012d7:	shr    rax,0x35
    70b3efb012db:	sub    eax,0x201
    70b3efb012e0:	cmp    eax,0x3fc
    70b3efb012e5:	ja     0x70b3efb04ee7
    70b3efb012eb:	movq   rax,xmm1
    70b3efb012f0:	add    rax,rax
    70b3efb012f3:	je     0x70b3efb01309
    70b3efb012f5:	shr    rax,0x35
    70b3efb012f9:	sub    eax,0x201
    70b3efb012fe:	cmp    eax,0x3fc
    70b3efb01303:	ja     0x70b3efb04ee7
    70b3efb01309:	movdqa xmm14,xmm1
    70b3efb0130e:	psrldq xmm14,0x8
    70b3efb01314:	movq   rax,xmm14
    70b3efb01319:	add    rax,rax
    70b3efb0131c:	je     0x70b3efb01332
    70b3efb0131e:	shr    rax,0x35
    70b3efb01322:	sub    eax,0x201
    70b3efb01327:	cmp    eax,0x3fc
    70b3efb0132c:	ja     0x70b3efb04ee7
    70b3efb01332:	mulpd  xmm0,xmm1
    70b3efb01336:	movdqa xmm4,xmm0
    70b3efb0133a:	movdqa xmm0,xmm4
    70b3efb0133e:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb01348:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb01352:	movdqa xmm2,xmm0
    70b3efb01356:	movdqa xmm0,xmm3
    70b3efb0135a:	movdqa xmm1,xmm2
    70b3efb0135e:	movq   rax,xmm0
    70b3efb01363:	add    rax,rax
    70b3efb01366:	je     0x70b3efb0137c
    70b3efb01368:	shr    rax,0x35
    70b3efb0136c:	sub    eax,0x201
    70b3efb01371:	cmp    eax,0x3fc
    70b3efb01376:	ja     0x70b3efb04f0b
    70b3efb0137c:	movdqa xmm14,xmm0
    70b3efb01381:	psrldq xmm14,0x8
    70b3efb01387:	movq   rax,xmm14
    70b3efb0138c:	add    rax,rax
    70b3efb0138f:	je     0x70b3efb013a5
    70b3efb01391:	shr    rax,0x35
    70b3efb01395:	sub    eax,0x201
    70b3efb0139a:	cmp    eax,0x3fc
    70b3efb0139f:	ja     0x70b3efb04f0b
    70b3efb013a5:	movq   rax,xmm1
    70b3efb013aa:	add    rax,rax
    70b3efb013ad:	je     0x70b3efb013c3
    70b3efb013af:	shr    rax,0x35
    70b3efb013b3:	sub    eax,0x201
    70b3efb013b8:	cmp    eax,0x3fc
    70b3efb013bd:	ja     0x70b3efb04f0b
    70b3efb013c3:	movdqa xmm14,xmm1
    70b3efb013c8:	psrldq xmm14,0x8
    70b3efb013ce:	movq   rax,xmm14
    70b3efb013d3:	add    rax,rax
    70b3efb013d6:	je     0x70b3efb013ec
    70b3efb013d8:	shr    rax,0x35
    70b3efb013dc:	sub    eax,0x201
    70b3efb013e1:	cmp    eax,0x3fc
    70b3efb013e6:	ja     0x70b3efb04f0b
    70b3efb013ec:	mulpd  xmm0,xmm1
    70b3efb013f0:	movdqa xmm4,xmm0
    70b3efb013f4:	movdqa xmm0,xmm4
    70b3efb013f8:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb01402:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb0140c:	movdqa xmm2,xmm0
    70b3efb01410:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    70b3efb0141a:	movdqa xmm3,xmm0
    70b3efb0141e:	movdqa xmm0,xmm2
    70b3efb01422:	movdqa xmm1,xmm3
    70b3efb01426:	movq   rax,xmm0
    70b3efb0142b:	add    rax,rax
    70b3efb0142e:	je     0x70b3efb01444
    70b3efb01430:	shr    rax,0x35
    70b3efb01434:	sub    eax,0x201
    70b3efb01439:	cmp    eax,0x3fc
    70b3efb0143e:	ja     0x70b3efb04f2f
    70b3efb01444:	movdqa xmm14,xmm0
    70b3efb01449:	psrldq xmm14,0x8
    70b3efb0144f:	movq   rax,xmm14
    70b3efb01454:	add    rax,rax
    70b3efb01457:	je     0x70b3efb0146d
    70b3efb01459:	shr    rax,0x35
    70b3efb0145d:	sub    eax,0x201
    70b3efb01462:	cmp    eax,0x3fc
    70b3efb01467:	ja     0x70b3efb04f2f
    70b3efb0146d:	movq   rax,xmm1
    70b3efb01472:	add    rax,rax
    70b3efb01475:	je     0x70b3efb0148b
    70b3efb01477:	shr    rax,0x35
    70b3efb0147b:	sub    eax,0x201
    70b3efb01480:	cmp    eax,0x3fc
    70b3efb01485:	ja     0x70b3efb04f2f
    70b3efb0148b:	movdqa xmm14,xmm1
    70b3efb01490:	psrldq xmm14,0x8
    70b3efb01496:	movq   rax,xmm14
    70b3efb0149b:	add    rax,rax
    70b3efb0149e:	je     0x70b3efb014b4
    70b3efb014a0:	shr    rax,0x35
    70b3efb014a4:	sub    eax,0x201
    70b3efb014a9:	cmp    eax,0x3fc
    70b3efb014ae:	ja     0x70b3efb04f2f
    70b3efb014b4:	mulpd  xmm0,xmm1
    70b3efb014b8:	movdqa xmm4,xmm0
    70b3efb014bc:	movdqa xmm0,xmm4
    70b3efb014c0:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb014ca:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    70b3efb014d4:	movdqa xmm2,xmm0
    70b3efb014d8:	movdqa xmm1,xmm2
    70b3efb014dc:	por    xmm2,xmm1
    70b3efb014e0:	movdqa xmm0,xmm2
    70b3efb014e4:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    70b3efb014ee:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    70b3efb014f8:	movdqa xmm2,xmm0
    70b3efb014fc:	movdqa xmm3,xmm2
    70b3efb01500:	movdqa xmm1,xmm2
    70b3efb01504:	por    xmm3,xmm1
    70b3efb01508:	movdqa xmm0,xmm3
    70b3efb0150c:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    70b3efb01516:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    70b3efb01520:	movdqa xmm3,xmm0
    70b3efb01524:	movdqa xmm0,xmm2
    70b3efb01528:	movdqa xmm1,xmm3
    70b3efb0152c:	pshufd xmm1,xmm1,0x44
    70b3efb01531:	movq   rax,xmm0
    70b3efb01536:	add    rax,rax
    70b3efb01539:	je     0x70b3efb0154f
    70b3efb0153b:	shr    rax,0x35
    70b3efb0153f:	sub    eax,0x201
    70b3efb01544:	cmp    eax,0x3fc
    70b3efb01549:	ja     0x70b3efb04f53
    70b3efb0154f:	movdqa xmm14,xmm0
    70b3efb01554:	psrldq xmm14,0x8
    70b3efb0155a:	movq   rax,xmm14
    70b3efb0155f:	add    rax,rax
    70b3efb01562:	je     0x70b3efb01578
    70b3efb01564:	shr    rax,0x35
    70b3efb01568:	sub    eax,0x201
    70b3efb0156d:	cmp    eax,0x3fc
    70b3efb01572:	ja     0x70b3efb04f53
    70b3efb01578:	movq   rax,xmm1
    70b3efb0157d:	add    rax,rax
    70b3efb01580:	je     0x70b3efb01596
    70b3efb01582:	shr    rax,0x35
    70b3efb01586:	sub    eax,0x201
    70b3efb0158b:	cmp    eax,0x3fc
    70b3efb01590:	ja     0x70b3efb04f53
    70b3efb01596:	movdqa xmm14,xmm1
    70b3efb0159b:	psrldq xmm14,0x8
    70b3efb015a1:	movq   rax,xmm14
    70b3efb015a6:	add    rax,rax
    70b3efb015a9:	je     0x70b3efb015bf
    70b3efb015ab:	shr    rax,0x35
    70b3efb015af:	sub    eax,0x201
    70b3efb015b4:	cmp    eax,0x3fc
    70b3efb015b9:	ja     0x70b3efb04f53
    70b3efb015bf:	mulpd  xmm0,xmm1
    70b3efb015c3:	movdqa xmm4,xmm0
    70b3efb015c7:	movdqa xmm0,xmm4
    70b3efb015cb:	movdqu XMMWORD PTR [r12+0x250],xmm0
    70b3efb015d5:	mov    r13,QWORD PTR [r12+0x58]
    70b3efb015da:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb015e2:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb015ea:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb015f2:	shr    r11d,1
    70b3efb015f5:	and    r11d,0x10
    70b3efb015f9:	or     DWORD PTR [r12+0x314],r11d
    70b3efb01601:	sub    r13,0x200
    70b3efb01608:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    70b3efb01612:	movdqa xmm2,xmm0
    70b3efb01616:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb01620:	movdqa xmm3,xmm0
    70b3efb01624:	pushf
    70b3efb01625:	pop    r11
    70b3efb01627:	mov    QWORD PTR [rsp],r11
    70b3efb0162b:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb01633:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb0163e:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb01646:	movdqa xmm0,xmm2
    70b3efb0164a:	movdqa xmm1,xmm3
    70b3efb0164e:	movq   rax,xmm0
    70b3efb01653:	add    rax,rax
    70b3efb01656:	je     0x70b3efb0166c
    70b3efb01658:	shr    rax,0x35
    70b3efb0165c:	sub    eax,0x201
    70b3efb01661:	cmp    eax,0x3fc
    70b3efb01666:	ja     0x70b3efb04f77
    70b3efb0166c:	movdqa xmm14,xmm0
    70b3efb01671:	psrldq xmm14,0x8
    70b3efb01677:	movq   rax,xmm14
    70b3efb0167c:	add    rax,rax
    70b3efb0167f:	je     0x70b3efb01695
    70b3efb01681:	shr    rax,0x35
    70b3efb01685:	sub    eax,0x201
    70b3efb0168a:	cmp    eax,0x3fc
    70b3efb0168f:	ja     0x70b3efb04f77
    70b3efb01695:	movq   rax,xmm1
    70b3efb0169a:	add    rax,rax
    70b3efb0169d:	je     0x70b3efb016b3
    70b3efb0169f:	shr    rax,0x35
    70b3efb016a3:	sub    eax,0x201
    70b3efb016a8:	cmp    eax,0x3fc
    70b3efb016ad:	ja     0x70b3efb04f77
    70b3efb016b3:	movdqa xmm14,xmm1
    70b3efb016b8:	psrldq xmm14,0x8
    70b3efb016be:	movq   rax,xmm14
    70b3efb016c3:	add    rax,rax
    70b3efb016c6:	je     0x70b3efb016dc
    70b3efb016c8:	shr    rax,0x35
    70b3efb016cc:	sub    eax,0x201
    70b3efb016d1:	cmp    eax,0x3fc
    70b3efb016d6:	ja     0x70b3efb04f77
    70b3efb016dc:	addpd  xmm0,xmm1
    70b3efb016e0:	movdqa xmm4,xmm0
    70b3efb016e4:	movdqa xmm0,xmm4
    70b3efb016e8:	movdqu XMMWORD PTR [r12+0x240],xmm0
    70b3efb016f2:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb016fc:	movdqa xmm2,xmm0
    70b3efb01700:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    70b3efb0170a:	movdqa xmm3,xmm0
    70b3efb0170e:	movdqa xmm0,xmm2
    70b3efb01712:	movdqa xmm1,xmm3
    70b3efb01716:	movq   rax,xmm0
    70b3efb0171b:	add    rax,rax
    70b3efb0171e:	je     0x70b3efb01734
    70b3efb01720:	shr    rax,0x35
    70b3efb01724:	sub    eax,0x201
    70b3efb01729:	cmp    eax,0x3fc
    70b3efb0172e:	ja     0x70b3efb04f9b
    70b3efb01734:	movdqa xmm14,xmm0
    70b3efb01739:	psrldq xmm14,0x8
    70b3efb0173f:	movq   rax,xmm14
    70b3efb01744:	add    rax,rax
    70b3efb01747:	je     0x70b3efb0175d
    70b3efb01749:	shr    rax,0x35
    70b3efb0174d:	sub    eax,0x201
    70b3efb01752:	cmp    eax,0x3fc
    70b3efb01757:	ja     0x70b3efb04f9b
    70b3efb0175d:	movq   rax,xmm1
    70b3efb01762:	add    rax,rax
    70b3efb01765:	je     0x70b3efb0177b
    70b3efb01767:	shr    rax,0x35
    70b3efb0176b:	sub    eax,0x201
    70b3efb01770:	cmp    eax,0x3fc
    70b3efb01775:	ja     0x70b3efb04f9b
    70b3efb0177b:	movdqa xmm14,xmm1
    70b3efb01780:	psrldq xmm14,0x8
    70b3efb01786:	movq   rax,xmm14
    70b3efb0178b:	add    rax,rax
    70b3efb0178e:	je     0x70b3efb017a4
    70b3efb01790:	shr    rax,0x35
    70b3efb01794:	sub    eax,0x201
    70b3efb01799:	cmp    eax,0x3fc
    70b3efb0179e:	ja     0x70b3efb04f9b
    70b3efb017a4:	addpd  xmm0,xmm1
    70b3efb017a8:	movdqa xmm4,xmm0
    70b3efb017ac:	movdqa xmm0,xmm4
    70b3efb017b0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb017ba:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb017c4:	movdqa xmm2,xmm0
    70b3efb017c8:	movdqa xmm0,xmm2
    70b3efb017cc:	movdqa xmm1,xmm3
    70b3efb017d0:	movq   rax,xmm0
    70b3efb017d5:	add    rax,rax
    70b3efb017d8:	je     0x70b3efb017ee
    70b3efb017da:	shr    rax,0x35
    70b3efb017de:	sub    eax,0x201
    70b3efb017e3:	cmp    eax,0x3fc
    70b3efb017e8:	ja     0x70b3efb04fbf
    70b3efb017ee:	movdqa xmm14,xmm0
    70b3efb017f3:	psrldq xmm14,0x8
    70b3efb017f9:	movq   rax,xmm14
    70b3efb017fe:	add    rax,rax
    70b3efb01801:	je     0x70b3efb01817
    70b3efb01803:	shr    rax,0x35
    70b3efb01807:	sub    eax,0x201
    70b3efb0180c:	cmp    eax,0x3fc
    70b3efb01811:	ja     0x70b3efb04fbf
    70b3efb01817:	movq   rax,xmm1
    70b3efb0181c:	add    rax,rax
    70b3efb0181f:	je     0x70b3efb01835
    70b3efb01821:	shr    rax,0x35
    70b3efb01825:	sub    eax,0x201
    70b3efb0182a:	cmp    eax,0x3fc
    70b3efb0182f:	ja     0x70b3efb04fbf
    70b3efb01835:	movdqa xmm14,xmm1
    70b3efb0183a:	psrldq xmm14,0x8
    70b3efb01840:	movq   rax,xmm14
    70b3efb01845:	add    rax,rax
    70b3efb01848:	je     0x70b3efb0185e
    70b3efb0184a:	shr    rax,0x35
    70b3efb0184e:	sub    eax,0x201
    70b3efb01853:	cmp    eax,0x3fc
    70b3efb01858:	ja     0x70b3efb04fbf
    70b3efb0185e:	addpd  xmm0,xmm1
    70b3efb01862:	movdqa xmm4,xmm0
    70b3efb01866:	movdqa xmm0,xmm4
    70b3efb0186a:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb01874:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    70b3efb0187e:	movdqa xmm2,xmm0
    70b3efb01882:	movdqa xmm1,xmm2
    70b3efb01886:	por    xmm2,xmm1
    70b3efb0188a:	movdqa xmm0,xmm2
    70b3efb0188e:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    70b3efb01898:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    70b3efb018a2:	movdqa xmm2,xmm0
    70b3efb018a6:	movdqa xmm1,xmm2
    70b3efb018aa:	por    xmm2,xmm1
    70b3efb018ae:	movdqa xmm0,xmm2
    70b3efb018b2:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    70b3efb018bc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    70b3efb018c6:	movdqa xmm2,xmm0
    70b3efb018ca:	movdqa xmm1,xmm2
    70b3efb018ce:	por    xmm2,xmm1
    70b3efb018d2:	movdqa xmm0,xmm2
    70b3efb018d6:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    70b3efb018e0:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    70b3efb018ea:	movdqa xmm2,xmm0
    70b3efb018ee:	movdqa xmm1,xmm2
    70b3efb018f2:	por    xmm2,xmm1
    70b3efb018f6:	movdqa xmm0,xmm2
    70b3efb018fa:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    70b3efb01904:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    70b3efb0190e:	movdqa xmm2,xmm0
    70b3efb01912:	movdqa xmm1,xmm2
    70b3efb01916:	por    xmm2,xmm1
    70b3efb0191a:	movdqa xmm0,xmm2
    70b3efb0191e:	movdqu XMMWORD PTR [r12+0x200],xmm0
    70b3efb01928:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    70b3efb01932:	movdqa xmm2,xmm0
    70b3efb01936:	movdqa xmm1,xmm2
    70b3efb0193a:	por    xmm2,xmm1
    70b3efb0193e:	movdqa xmm0,xmm2
    70b3efb01942:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    70b3efb0194c:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    70b3efb01956:	movdqa xmm2,xmm0
    70b3efb0195a:	movdqa xmm1,xmm2
    70b3efb0195e:	por    xmm2,xmm1
    70b3efb01962:	movdqa xmm0,xmm2
    70b3efb01966:	movdqu XMMWORD PTR [r12+0x190],xmm0
    70b3efb01970:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb01978:	mov    r14,r13
    70b3efb0197b:	add    r14,0xa0
    70b3efb01982:	mov    r15,r14
    70b3efb01985:	add    r15,0x10
    70b3efb01989:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb01991:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb01999:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb019a1:	shr    r11d,1
    70b3efb019a4:	and    r11d,0x10
    70b3efb019a8:	or     DWORD PTR [r12+0x314],r11d
    70b3efb019b0:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb019b5:	movdqu xmm3,XMMWORD PTR [r15]
    70b3efb019ba:	movdqa xmm0,xmm2
    70b3efb019be:	movdqu XMMWORD PTR [r12+0x300],xmm0
    70b3efb019c8:	movdqa xmm0,xmm3
    70b3efb019cc:	movdqu XMMWORD PTR [r12+0x270],xmm0
    70b3efb019d6:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb019e0:	movdqa xmm2,xmm0
    70b3efb019e4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb019ee:	movdqa xmm4,xmm0
    70b3efb019f2:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb019fa:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb01a05:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb01a0d:	movdqa xmm0,xmm2
    70b3efb01a11:	movdqa xmm1,xmm4
    70b3efb01a15:	movq   rax,xmm0
    70b3efb01a1a:	add    rax,rax
    70b3efb01a1d:	je     0x70b3efb01a33
    70b3efb01a1f:	shr    rax,0x35
    70b3efb01a23:	sub    eax,0x201
    70b3efb01a28:	cmp    eax,0x3fc
    70b3efb01a2d:	ja     0x70b3efb04fe3
    70b3efb01a33:	movdqa xmm14,xmm0
    70b3efb01a38:	psrldq xmm14,0x8
    70b3efb01a3e:	movq   rax,xmm14
    70b3efb01a43:	add    rax,rax
    70b3efb01a46:	je     0x70b3efb01a5c
    70b3efb01a48:	shr    rax,0x35
    70b3efb01a4c:	sub    eax,0x201
    70b3efb01a51:	cmp    eax,0x3fc
    70b3efb01a56:	ja     0x70b3efb04fe3
    70b3efb01a5c:	movq   rax,xmm1
    70b3efb01a61:	add    rax,rax
    70b3efb01a64:	je     0x70b3efb01a7a
    70b3efb01a66:	shr    rax,0x35
    70b3efb01a6a:	sub    eax,0x201
    70b3efb01a6f:	cmp    eax,0x3fc
    70b3efb01a74:	ja     0x70b3efb04fe3
    70b3efb01a7a:	movdqa xmm14,xmm1
    70b3efb01a7f:	psrldq xmm14,0x8
    70b3efb01a85:	movq   rax,xmm14
    70b3efb01a8a:	add    rax,rax
    70b3efb01a8d:	je     0x70b3efb01aa3
    70b3efb01a8f:	shr    rax,0x35
    70b3efb01a93:	sub    eax,0x201
    70b3efb01a98:	cmp    eax,0x3fc
    70b3efb01a9d:	ja     0x70b3efb04fe3
    70b3efb01aa3:	addpd  xmm0,xmm1
    70b3efb01aa7:	movdqa xmm5,xmm0
    70b3efb01aab:	movdqa xmm0,xmm5
    70b3efb01aaf:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb01ab9:	add    r13,0xf0
    70b3efb01ac0:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb01ac8:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb01ad0:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb01ad8:	shr    r11d,1
    70b3efb01adb:	and    r11d,0x10
    70b3efb01adf:	or     DWORD PTR [r12+0x314],r11d
    70b3efb01ae7:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb01aed:	movdqa xmm0,xmm2
    70b3efb01af1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb01afb:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb01b05:	movdqa xmm4,xmm0
    70b3efb01b09:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    70b3efb01b13:	movdqa xmm5,xmm0
    70b3efb01b17:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb01b1f:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb01b2a:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb01b32:	movdqa xmm0,xmm4
    70b3efb01b36:	movdqa xmm1,xmm5
    70b3efb01b3a:	movq   rax,xmm0
    70b3efb01b3f:	add    rax,rax
    70b3efb01b42:	je     0x70b3efb01b58
    70b3efb01b44:	shr    rax,0x35
    70b3efb01b48:	sub    eax,0x201
    70b3efb01b4d:	cmp    eax,0x3fc
    70b3efb01b52:	ja     0x70b3efb05007
    70b3efb01b58:	movdqa xmm14,xmm0
    70b3efb01b5d:	psrldq xmm14,0x8
    70b3efb01b63:	movq   rax,xmm14
    70b3efb01b68:	add    rax,rax
    70b3efb01b6b:	je     0x70b3efb01b81
    70b3efb01b6d:	shr    rax,0x35
    70b3efb01b71:	sub    eax,0x201
    70b3efb01b76:	cmp    eax,0x3fc
    70b3efb01b7b:	ja     0x70b3efb05007
    70b3efb01b81:	movq   rax,xmm1
    70b3efb01b86:	add    rax,rax
    70b3efb01b89:	je     0x70b3efb01b9f
    70b3efb01b8b:	shr    rax,0x35
    70b3efb01b8f:	sub    eax,0x201
    70b3efb01b94:	cmp    eax,0x3fc
    70b3efb01b99:	ja     0x70b3efb05007
    70b3efb01b9f:	movdqa xmm14,xmm1
    70b3efb01ba4:	psrldq xmm14,0x8
    70b3efb01baa:	movq   rax,xmm14
    70b3efb01baf:	add    rax,rax
    70b3efb01bb2:	je     0x70b3efb01bc8
    70b3efb01bb4:	shr    rax,0x35
    70b3efb01bb8:	sub    eax,0x201
    70b3efb01bbd:	cmp    eax,0x3fc
    70b3efb01bc2:	ja     0x70b3efb05007
    70b3efb01bc8:	addpd  xmm0,xmm1
    70b3efb01bcc:	movdqa xmm6,xmm0
    70b3efb01bd0:	movdqa xmm0,xmm6
    70b3efb01bd4:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb01bde:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb01be8:	movdqa xmm4,xmm0
    70b3efb01bec:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    70b3efb01bf6:	movdqa xmm5,xmm0
    70b3efb01bfa:	movdqa xmm0,xmm4
    70b3efb01bfe:	movdqa xmm1,xmm5
    70b3efb01c02:	movq   rax,xmm0
    70b3efb01c07:	add    rax,rax
    70b3efb01c0a:	je     0x70b3efb01c20
    70b3efb01c0c:	shr    rax,0x35
    70b3efb01c10:	sub    eax,0x201
    70b3efb01c15:	cmp    eax,0x3fc
    70b3efb01c1a:	ja     0x70b3efb0502b
    70b3efb01c20:	movdqa xmm14,xmm0
    70b3efb01c25:	psrldq xmm14,0x8
    70b3efb01c2b:	movq   rax,xmm14
    70b3efb01c30:	add    rax,rax
    70b3efb01c33:	je     0x70b3efb01c49
    70b3efb01c35:	shr    rax,0x35
    70b3efb01c39:	sub    eax,0x201
    70b3efb01c3e:	cmp    eax,0x3fc
    70b3efb01c43:	ja     0x70b3efb0502b
    70b3efb01c49:	movq   rax,xmm1
    70b3efb01c4e:	add    rax,rax
    70b3efb01c51:	je     0x70b3efb01c67
    70b3efb01c53:	shr    rax,0x35
    70b3efb01c57:	sub    eax,0x201
    70b3efb01c5c:	cmp    eax,0x3fc
    70b3efb01c61:	ja     0x70b3efb0502b
    70b3efb01c67:	movdqa xmm14,xmm1
    70b3efb01c6c:	psrldq xmm14,0x8
    70b3efb01c72:	movq   rax,xmm14
    70b3efb01c77:	add    rax,rax
    70b3efb01c7a:	je     0x70b3efb01c90
    70b3efb01c7c:	shr    rax,0x35
    70b3efb01c80:	sub    eax,0x201
    70b3efb01c85:	cmp    eax,0x3fc
    70b3efb01c8a:	ja     0x70b3efb0502b
    70b3efb01c90:	addpd  xmm0,xmm1
    70b3efb01c94:	movdqa xmm6,xmm0
    70b3efb01c98:	movdqa xmm0,xmm6
    70b3efb01c9c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb01ca6:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    70b3efb01cb0:	movdqa xmm4,xmm0
    70b3efb01cb4:	movdqa xmm0,xmm3
    70b3efb01cb8:	movdqa xmm1,xmm4
    70b3efb01cbc:	pshufd xmm1,xmm1,0x44
    70b3efb01cc1:	movq   rax,xmm0
    70b3efb01cc6:	add    rax,rax
    70b3efb01cc9:	je     0x70b3efb01cdf
    70b3efb01ccb:	shr    rax,0x35
    70b3efb01ccf:	sub    eax,0x201
    70b3efb01cd4:	cmp    eax,0x3fc
    70b3efb01cd9:	ja     0x70b3efb0504f
    70b3efb01cdf:	movdqa xmm14,xmm0
    70b3efb01ce4:	psrldq xmm14,0x8
    70b3efb01cea:	movq   rax,xmm14
    70b3efb01cef:	add    rax,rax
    70b3efb01cf2:	je     0x70b3efb01d08
    70b3efb01cf4:	shr    rax,0x35
    70b3efb01cf8:	sub    eax,0x201
    70b3efb01cfd:	cmp    eax,0x3fc
    70b3efb01d02:	ja     0x70b3efb0504f
    70b3efb01d08:	movq   rax,xmm1
    70b3efb01d0d:	add    rax,rax
    70b3efb01d10:	je     0x70b3efb01d26
    70b3efb01d12:	shr    rax,0x35
    70b3efb01d16:	sub    eax,0x201
    70b3efb01d1b:	cmp    eax,0x3fc
    70b3efb01d20:	ja     0x70b3efb0504f
    70b3efb01d26:	movdqa xmm14,xmm1
    70b3efb01d2b:	psrldq xmm14,0x8
    70b3efb01d31:	movq   rax,xmm14
    70b3efb01d36:	add    rax,rax
    70b3efb01d39:	je     0x70b3efb01d4f
    70b3efb01d3b:	shr    rax,0x35
    70b3efb01d3f:	sub    eax,0x201
    70b3efb01d44:	cmp    eax,0x3fc
    70b3efb01d49:	ja     0x70b3efb0504f
    70b3efb01d4f:	mulpd  xmm0,xmm1
    70b3efb01d53:	movdqa xmm5,xmm0
    70b3efb01d57:	movdqa xmm0,xmm5
    70b3efb01d5b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    70b3efb01d65:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb01d6f:	movdqa xmm3,xmm0
    70b3efb01d73:	movdqa xmm0,xmm2
    70b3efb01d77:	movdqa xmm1,xmm3
    70b3efb01d7b:	pshufd xmm1,xmm1,0x44
    70b3efb01d80:	movq   rax,xmm0
    70b3efb01d85:	add    rax,rax
    70b3efb01d88:	je     0x70b3efb01d9e
    70b3efb01d8a:	shr    rax,0x35
    70b3efb01d8e:	sub    eax,0x201
    70b3efb01d93:	cmp    eax,0x3fc
    70b3efb01d98:	ja     0x70b3efb05073
    70b3efb01d9e:	movdqa xmm14,xmm0
    70b3efb01da3:	psrldq xmm14,0x8
    70b3efb01da9:	movq   rax,xmm14
    70b3efb01dae:	add    rax,rax
    70b3efb01db1:	je     0x70b3efb01dc7
    70b3efb01db3:	shr    rax,0x35
    70b3efb01db7:	sub    eax,0x201
    70b3efb01dbc:	cmp    eax,0x3fc
    70b3efb01dc1:	ja     0x70b3efb05073
    70b3efb01dc7:	movq   rax,xmm1
    70b3efb01dcc:	add    rax,rax
    70b3efb01dcf:	je     0x70b3efb01de5
    70b3efb01dd1:	shr    rax,0x35
    70b3efb01dd5:	sub    eax,0x201
    70b3efb01dda:	cmp    eax,0x3fc
    70b3efb01ddf:	ja     0x70b3efb05073
    70b3efb01de5:	movdqa xmm14,xmm1
    70b3efb01dea:	psrldq xmm14,0x8
    70b3efb01df0:	movq   rax,xmm14
    70b3efb01df5:	add    rax,rax
    70b3efb01df8:	je     0x70b3efb01e0e
    70b3efb01dfa:	shr    rax,0x35
    70b3efb01dfe:	sub    eax,0x201
    70b3efb01e03:	cmp    eax,0x3fc
    70b3efb01e08:	ja     0x70b3efb05073
    70b3efb01e0e:	mulpd  xmm0,xmm1
    70b3efb01e12:	movdqa xmm5,xmm0
    70b3efb01e16:	movdqa xmm0,xmm5
    70b3efb01e1a:	movdqu XMMWORD PTR [r12+0x250],xmm0
    70b3efb01e24:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb01e2c:	mov    r14,r13
    70b3efb01e2f:	add    r14,0xe0
    70b3efb01e36:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb01e3e:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb01e46:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb01e4e:	shr    r11d,1
    70b3efb01e51:	and    r11d,0x10
    70b3efb01e55:	or     DWORD PTR [r12+0x314],r11d
    70b3efb01e5d:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb01e62:	movdqa xmm0,xmm2
    70b3efb01e66:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb01e70:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    70b3efb01e7a:	movdqa xmm2,xmm0
    70b3efb01e7e:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb01e86:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb01e91:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb01e99:	movdqa xmm0,xmm2
    70b3efb01e9d:	movdqa xmm1,xmm4
    70b3efb01ea1:	pshufd xmm1,xmm1,0x44
    70b3efb01ea6:	movq   rax,xmm0
    70b3efb01eab:	add    rax,rax
    70b3efb01eae:	je     0x70b3efb01ec4
    70b3efb01eb0:	shr    rax,0x35
    70b3efb01eb4:	sub    eax,0x201
    70b3efb01eb9:	cmp    eax,0x3fc
    70b3efb01ebe:	ja     0x70b3efb05097
    70b3efb01ec4:	movdqa xmm14,xmm0
    70b3efb01ec9:	psrldq xmm14,0x8
    70b3efb01ecf:	movq   rax,xmm14
    70b3efb01ed4:	add    rax,rax
    70b3efb01ed7:	je     0x70b3efb01eed
    70b3efb01ed9:	shr    rax,0x35
    70b3efb01edd:	sub    eax,0x201
    70b3efb01ee2:	cmp    eax,0x3fc
    70b3efb01ee7:	ja     0x70b3efb05097
    70b3efb01eed:	movq   rax,xmm1
    70b3efb01ef2:	add    rax,rax
    70b3efb01ef5:	je     0x70b3efb01f0b
    70b3efb01ef7:	shr    rax,0x35
    70b3efb01efb:	sub    eax,0x201
    70b3efb01f00:	cmp    eax,0x3fc
    70b3efb01f05:	ja     0x70b3efb05097
    70b3efb01f0b:	movdqa xmm14,xmm1
    70b3efb01f10:	psrldq xmm14,0x8
    70b3efb01f16:	movq   rax,xmm14
    70b3efb01f1b:	add    rax,rax
    70b3efb01f1e:	je     0x70b3efb01f34
    70b3efb01f20:	shr    rax,0x35
    70b3efb01f24:	sub    eax,0x201
    70b3efb01f29:	cmp    eax,0x3fc
    70b3efb01f2e:	ja     0x70b3efb05097
    70b3efb01f34:	mulpd  xmm0,xmm1
    70b3efb01f38:	movdqa xmm5,xmm0
    70b3efb01f3c:	movdqa xmm0,xmm5
    70b3efb01f40:	movdqu XMMWORD PTR [r12+0x230],xmm0
    70b3efb01f4a:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    70b3efb01f54:	movdqa xmm2,xmm0
    70b3efb01f58:	movdqa xmm1,xmm2
    70b3efb01f5c:	por    xmm2,xmm1
    70b3efb01f60:	movdqa xmm0,xmm2
    70b3efb01f64:	movdqu XMMWORD PTR [r12+0x300],xmm0
    70b3efb01f6e:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    70b3efb01f78:	movdqa xmm2,xmm0
    70b3efb01f7c:	movdqa xmm1,xmm2
    70b3efb01f80:	por    xmm2,xmm1
    70b3efb01f84:	movdqa xmm0,xmm2
    70b3efb01f88:	movdqu XMMWORD PTR [r12+0x190],xmm0
    70b3efb01f92:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb01f9c:	movdqa xmm2,xmm0
    70b3efb01fa0:	movdqa xmm0,xmm2
    70b3efb01fa4:	movdqa xmm1,xmm3
    70b3efb01fa8:	pshufd xmm1,xmm1,0x44
    70b3efb01fad:	movq   rax,xmm0
    70b3efb01fb2:	add    rax,rax
    70b3efb01fb5:	je     0x70b3efb01fcb
    70b3efb01fb7:	shr    rax,0x35
    70b3efb01fbb:	sub    eax,0x201
    70b3efb01fc0:	cmp    eax,0x3fc
    70b3efb01fc5:	ja     0x70b3efb050bb
    70b3efb01fcb:	movdqa xmm14,xmm0
    70b3efb01fd0:	psrldq xmm14,0x8
    70b3efb01fd6:	movq   rax,xmm14
    70b3efb01fdb:	add    rax,rax
    70b3efb01fde:	je     0x70b3efb01ff4
    70b3efb01fe0:	shr    rax,0x35
    70b3efb01fe4:	sub    eax,0x201
    70b3efb01fe9:	cmp    eax,0x3fc
    70b3efb01fee:	ja     0x70b3efb050bb
    70b3efb01ff4:	movq   rax,xmm1
    70b3efb01ff9:	add    rax,rax
    70b3efb01ffc:	je     0x70b3efb02012
    70b3efb01ffe:	shr    rax,0x35
    70b3efb02002:	sub    eax,0x201
    70b3efb02007:	cmp    eax,0x3fc
    70b3efb0200c:	ja     0x70b3efb050bb
    70b3efb02012:	movdqa xmm14,xmm1
    70b3efb02017:	psrldq xmm14,0x8
    70b3efb0201d:	movq   rax,xmm14
    70b3efb02022:	add    rax,rax
    70b3efb02025:	je     0x70b3efb0203b
    70b3efb02027:	shr    rax,0x35
    70b3efb0202b:	sub    eax,0x201
    70b3efb02030:	cmp    eax,0x3fc
    70b3efb02035:	ja     0x70b3efb050bb
    70b3efb0203b:	mulpd  xmm0,xmm1
    70b3efb0203f:	movdqa xmm4,xmm0
    70b3efb02043:	movdqa xmm0,xmm4
    70b3efb02047:	movdqu XMMWORD PTR [r12+0x260],xmm0
    70b3efb02051:	add    r13,0x90
    70b3efb02058:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb02060:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb02068:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb02070:	shr    r11d,1
    70b3efb02073:	and    r11d,0x10
    70b3efb02077:	or     DWORD PTR [r12+0x314],r11d
    70b3efb0207f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb02085:	movdqa xmm0,xmm2
    70b3efb02089:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb02093:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    70b3efb0209d:	movdqa xmm3,xmm0
    70b3efb020a1:	movdqa xmm1,xmm3
    70b3efb020a5:	por    xmm3,xmm1
    70b3efb020a9:	movdqa xmm0,xmm3
    70b3efb020ad:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    70b3efb020b7:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    70b3efb020c1:	movdqa xmm3,xmm0
    70b3efb020c5:	movdqa xmm1,xmm3
    70b3efb020c9:	por    xmm3,xmm1
    70b3efb020cd:	movdqa xmm0,xmm3
    70b3efb020d1:	movdqu XMMWORD PTR [r12+0x200],xmm0
    70b3efb020db:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    70b3efb020e5:	movdqa xmm3,xmm0
    70b3efb020e9:	movdqa xmm1,xmm3
    70b3efb020ed:	por    xmm3,xmm1
    70b3efb020f1:	movdqa xmm0,xmm3
    70b3efb020f5:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    70b3efb020ff:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    70b3efb02109:	movdqa xmm3,xmm0
    70b3efb0210d:	movdqa xmm1,xmm3
    70b3efb02111:	por    xmm3,xmm1
    70b3efb02115:	movdqa xmm0,xmm3
    70b3efb02119:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    70b3efb02123:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    70b3efb0212d:	movdqa xmm3,xmm0
    70b3efb02131:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    70b3efb0213b:	movdqa xmm4,xmm0
    70b3efb0213f:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb02147:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb02152:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb0215a:	movdqa xmm0,xmm3
    70b3efb0215e:	movdqa xmm1,xmm4
    70b3efb02162:	movq   rax,xmm0
    70b3efb02167:	add    rax,rax
    70b3efb0216a:	je     0x70b3efb02180
    70b3efb0216c:	shr    rax,0x35
    70b3efb02170:	sub    eax,0x201
    70b3efb02175:	cmp    eax,0x3fc
    70b3efb0217a:	ja     0x70b3efb050df
    70b3efb02180:	movdqa xmm14,xmm0
    70b3efb02185:	psrldq xmm14,0x8
    70b3efb0218b:	movq   rax,xmm14
    70b3efb02190:	add    rax,rax
    70b3efb02193:	je     0x70b3efb021a9
    70b3efb02195:	shr    rax,0x35
    70b3efb02199:	sub    eax,0x201
    70b3efb0219e:	cmp    eax,0x3fc
    70b3efb021a3:	ja     0x70b3efb050df
    70b3efb021a9:	movq   rax,xmm1
    70b3efb021ae:	add    rax,rax
    70b3efb021b1:	je     0x70b3efb021c7
    70b3efb021b3:	shr    rax,0x35
    70b3efb021b7:	sub    eax,0x201
    70b3efb021bc:	cmp    eax,0x3fc
    70b3efb021c1:	ja     0x70b3efb050df
    70b3efb021c7:	movdqa xmm14,xmm1
    70b3efb021cc:	psrldq xmm14,0x8
    70b3efb021d2:	movq   rax,xmm14
    70b3efb021d7:	add    rax,rax
    70b3efb021da:	je     0x70b3efb021f0
    70b3efb021dc:	shr    rax,0x35
    70b3efb021e0:	sub    eax,0x201
    70b3efb021e5:	cmp    eax,0x3fc
    70b3efb021ea:	ja     0x70b3efb050df
    70b3efb021f0:	addpd  xmm0,xmm1
    70b3efb021f4:	movdqa xmm5,xmm0
    70b3efb021f8:	movdqa xmm0,xmm5
    70b3efb021fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    70b3efb02206:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb02210:	movdqa xmm3,xmm0
    70b3efb02214:	movdqa xmm0,xmm2
    70b3efb02218:	movdqa xmm1,xmm3
    70b3efb0221c:	pshufd xmm1,xmm1,0x44
    70b3efb02221:	movq   rax,xmm0
    70b3efb02226:	add    rax,rax
    70b3efb02229:	je     0x70b3efb0223f
    70b3efb0222b:	shr    rax,0x35
    70b3efb0222f:	sub    eax,0x201
    70b3efb02234:	cmp    eax,0x3fc
    70b3efb02239:	ja     0x70b3efb05103
    70b3efb0223f:	movdqa xmm14,xmm0
    70b3efb02244:	psrldq xmm14,0x8
    70b3efb0224a:	movq   rax,xmm14
    70b3efb0224f:	add    rax,rax
    70b3efb02252:	je     0x70b3efb02268
    70b3efb02254:	shr    rax,0x35
    70b3efb02258:	sub    eax,0x201
    70b3efb0225d:	cmp    eax,0x3fc
    70b3efb02262:	ja     0x70b3efb05103
    70b3efb02268:	movq   rax,xmm1
    70b3efb0226d:	add    rax,rax
    70b3efb02270:	je     0x70b3efb02286
    70b3efb02272:	shr    rax,0x35
    70b3efb02276:	sub    eax,0x201
    70b3efb0227b:	cmp    eax,0x3fc
    70b3efb02280:	ja     0x70b3efb05103
    70b3efb02286:	movdqa xmm14,xmm1
    70b3efb0228b:	psrldq xmm14,0x8
    70b3efb02291:	movq   rax,xmm14
    70b3efb02296:	add    rax,rax
    70b3efb02299:	je     0x70b3efb022af
    70b3efb0229b:	shr    rax,0x35
    70b3efb0229f:	sub    eax,0x201
    70b3efb022a4:	cmp    eax,0x3fc
    70b3efb022a9:	ja     0x70b3efb05103
    70b3efb022af:	mulpd  xmm0,xmm1
    70b3efb022b3:	movdqa xmm4,xmm0
    70b3efb022b7:	movdqa xmm0,xmm4
    70b3efb022bb:	movdqu XMMWORD PTR [r12+0x270],xmm0
    70b3efb022c5:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb022cd:	add    r13,0x80
    70b3efb022d4:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb022dc:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb022e4:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb022ec:	shr    r11d,1
    70b3efb022ef:	and    r11d,0x10
    70b3efb022f3:	or     DWORD PTR [r12+0x314],r11d
    70b3efb022fb:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb02301:	movdqa xmm0,xmm2
    70b3efb02305:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb0230f:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb02319:	movdqa xmm3,xmm0
    70b3efb0231d:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    70b3efb02327:	movdqa xmm4,xmm0
    70b3efb0232b:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb02333:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb0233e:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb02346:	movdqa xmm0,xmm3
    70b3efb0234a:	movdqa xmm1,xmm4
    70b3efb0234e:	movq   rax,xmm0
    70b3efb02353:	add    rax,rax
    70b3efb02356:	je     0x70b3efb0236c
    70b3efb02358:	shr    rax,0x35
    70b3efb0235c:	sub    eax,0x201
    70b3efb02361:	cmp    eax,0x3fc
    70b3efb02366:	ja     0x70b3efb05127
    70b3efb0236c:	movdqa xmm14,xmm0
    70b3efb02371:	psrldq xmm14,0x8
    70b3efb02377:	movq   rax,xmm14
    70b3efb0237c:	add    rax,rax
    70b3efb0237f:	je     0x70b3efb02395
    70b3efb02381:	shr    rax,0x35
    70b3efb02385:	sub    eax,0x201
    70b3efb0238a:	cmp    eax,0x3fc
    70b3efb0238f:	ja     0x70b3efb05127
    70b3efb02395:	movq   rax,xmm1
    70b3efb0239a:	add    rax,rax
    70b3efb0239d:	je     0x70b3efb023b3
    70b3efb0239f:	shr    rax,0x35
    70b3efb023a3:	sub    eax,0x201
    70b3efb023a8:	cmp    eax,0x3fc
    70b3efb023ad:	ja     0x70b3efb05127
    70b3efb023b3:	movdqa xmm14,xmm1
    70b3efb023b8:	psrldq xmm14,0x8
    70b3efb023be:	movq   rax,xmm14
    70b3efb023c3:	add    rax,rax
    70b3efb023c6:	je     0x70b3efb023dc
    70b3efb023c8:	shr    rax,0x35
    70b3efb023cc:	sub    eax,0x201
    70b3efb023d1:	cmp    eax,0x3fc
    70b3efb023d6:	ja     0x70b3efb05127
    70b3efb023dc:	addpd  xmm0,xmm1
    70b3efb023e0:	movdqa xmm5,xmm0
    70b3efb023e4:	movdqa xmm0,xmm5
    70b3efb023e8:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb023f2:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb023fc:	movdqa xmm3,xmm0
    70b3efb02400:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    70b3efb0240a:	movdqa xmm4,xmm0
    70b3efb0240e:	movdqa xmm0,xmm3
    70b3efb02412:	movdqa xmm1,xmm4
    70b3efb02416:	movq   rax,xmm0
    70b3efb0241b:	add    rax,rax
    70b3efb0241e:	je     0x70b3efb02434
    70b3efb02420:	shr    rax,0x35
    70b3efb02424:	sub    eax,0x201
    70b3efb02429:	cmp    eax,0x3fc
    70b3efb0242e:	ja     0x70b3efb0514b
    70b3efb02434:	movdqa xmm14,xmm0
    70b3efb02439:	psrldq xmm14,0x8
    70b3efb0243f:	movq   rax,xmm14
    70b3efb02444:	add    rax,rax
    70b3efb02447:	je     0x70b3efb0245d
    70b3efb02449:	shr    rax,0x35
    70b3efb0244d:	sub    eax,0x201
    70b3efb02452:	cmp    eax,0x3fc
    70b3efb02457:	ja     0x70b3efb0514b
    70b3efb0245d:	movq   rax,xmm1
    70b3efb02462:	add    rax,rax
    70b3efb02465:	je     0x70b3efb0247b
    70b3efb02467:	shr    rax,0x35
    70b3efb0246b:	sub    eax,0x201
    70b3efb02470:	cmp    eax,0x3fc
    70b3efb02475:	ja     0x70b3efb0514b
    70b3efb0247b:	movdqa xmm14,xmm1
    70b3efb02480:	psrldq xmm14,0x8
    70b3efb02486:	movq   rax,xmm14
    70b3efb0248b:	add    rax,rax
    70b3efb0248e:	je     0x70b3efb024a4
    70b3efb02490:	shr    rax,0x35
    70b3efb02494:	sub    eax,0x201
    70b3efb02499:	cmp    eax,0x3fc
    70b3efb0249e:	ja     0x70b3efb0514b
    70b3efb024a4:	addpd  xmm0,xmm1
    70b3efb024a8:	movdqa xmm5,xmm0
    70b3efb024ac:	movdqa xmm0,xmm5
    70b3efb024b0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb024ba:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    70b3efb024c4:	movdqa xmm3,xmm0
    70b3efb024c8:	movdqa xmm1,xmm3
    70b3efb024cc:	por    xmm3,xmm1
    70b3efb024d0:	movdqa xmm0,xmm3
    70b3efb024d4:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    70b3efb024de:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb024e8:	movdqa xmm3,xmm0
    70b3efb024ec:	movdqa xmm0,xmm2
    70b3efb024f0:	movdqa xmm1,xmm3
    70b3efb024f4:	pshufd xmm1,xmm1,0x44
    70b3efb024f9:	movq   rax,xmm0
    70b3efb024fe:	add    rax,rax
    70b3efb02501:	je     0x70b3efb02517
    70b3efb02503:	shr    rax,0x35
    70b3efb02507:	sub    eax,0x201
    70b3efb0250c:	cmp    eax,0x3fc
    70b3efb02511:	ja     0x70b3efb0516f
    70b3efb02517:	movdqa xmm14,xmm0
    70b3efb0251c:	psrldq xmm14,0x8
    70b3efb02522:	movq   rax,xmm14
    70b3efb02527:	add    rax,rax
    70b3efb0252a:	je     0x70b3efb02540
    70b3efb0252c:	shr    rax,0x35
    70b3efb02530:	sub    eax,0x201
    70b3efb02535:	cmp    eax,0x3fc
    70b3efb0253a:	ja     0x70b3efb0516f
    70b3efb02540:	movq   rax,xmm1
    70b3efb02545:	add    rax,rax
    70b3efb02548:	je     0x70b3efb0255e
    70b3efb0254a:	shr    rax,0x35
    70b3efb0254e:	sub    eax,0x201
    70b3efb02553:	cmp    eax,0x3fc
    70b3efb02558:	ja     0x70b3efb0516f
    70b3efb0255e:	movdqa xmm14,xmm1
    70b3efb02563:	psrldq xmm14,0x8
    70b3efb02569:	movq   rax,xmm14
    70b3efb0256e:	add    rax,rax
    70b3efb02571:	je     0x70b3efb02587
    70b3efb02573:	shr    rax,0x35
    70b3efb02577:	sub    eax,0x201
    70b3efb0257c:	cmp    eax,0x3fc
    70b3efb02581:	ja     0x70b3efb0516f
    70b3efb02587:	mulpd  xmm0,xmm1
    70b3efb0258b:	movdqa xmm4,xmm0
    70b3efb0258f:	movdqa xmm0,xmm4
    70b3efb02593:	movdqu XMMWORD PTR [r12+0x170],xmm0
    70b3efb0259d:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb025a5:	add    r13,0xd0
    70b3efb025ac:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb025b4:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb025bc:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb025c4:	shr    r11d,1
    70b3efb025c7:	and    r11d,0x10
    70b3efb025cb:	or     DWORD PTR [r12+0x314],r11d
    70b3efb025d3:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb025d9:	movdqa xmm0,xmm2
    70b3efb025dd:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb025e7:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb025f1:	movdqa xmm3,xmm0
    70b3efb025f5:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    70b3efb025ff:	movdqa xmm4,xmm0
    70b3efb02603:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb0260b:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb02616:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb0261e:	movdqa xmm0,xmm3
    70b3efb02622:	movdqa xmm1,xmm4
    70b3efb02626:	movq   rax,xmm0
    70b3efb0262b:	add    rax,rax
    70b3efb0262e:	je     0x70b3efb02644
    70b3efb02630:	shr    rax,0x35
    70b3efb02634:	sub    eax,0x201
    70b3efb02639:	cmp    eax,0x3fc
    70b3efb0263e:	ja     0x70b3efb05193
    70b3efb02644:	movdqa xmm14,xmm0
    70b3efb02649:	psrldq xmm14,0x8
    70b3efb0264f:	movq   rax,xmm14
    70b3efb02654:	add    rax,rax
    70b3efb02657:	je     0x70b3efb0266d
    70b3efb02659:	shr    rax,0x35
    70b3efb0265d:	sub    eax,0x201
    70b3efb02662:	cmp    eax,0x3fc
    70b3efb02667:	ja     0x70b3efb05193
    70b3efb0266d:	movq   rax,xmm1
    70b3efb02672:	add    rax,rax
    70b3efb02675:	je     0x70b3efb0268b
    70b3efb02677:	shr    rax,0x35
    70b3efb0267b:	sub    eax,0x201
    70b3efb02680:	cmp    eax,0x3fc
    70b3efb02685:	ja     0x70b3efb05193
    70b3efb0268b:	movdqa xmm14,xmm1
    70b3efb02690:	psrldq xmm14,0x8
    70b3efb02696:	movq   rax,xmm14
    70b3efb0269b:	add    rax,rax
    70b3efb0269e:	je     0x70b3efb026b4
    70b3efb026a0:	shr    rax,0x35
    70b3efb026a4:	sub    eax,0x201
    70b3efb026a9:	cmp    eax,0x3fc
    70b3efb026ae:	ja     0x70b3efb05193
    70b3efb026b4:	addpd  xmm0,xmm1
    70b3efb026b8:	movdqa xmm5,xmm0
    70b3efb026bc:	movdqa xmm0,xmm5
    70b3efb026c0:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb026ca:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    70b3efb026d4:	movdqa xmm3,xmm0
    70b3efb026d8:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    70b3efb026e2:	movdqa xmm4,xmm0
    70b3efb026e6:	movdqa xmm0,xmm3
    70b3efb026ea:	movdqa xmm1,xmm4
    70b3efb026ee:	pshufd xmm1,xmm1,0x44
    70b3efb026f3:	movq   rax,xmm0
    70b3efb026f8:	add    rax,rax
    70b3efb026fb:	je     0x70b3efb02711
    70b3efb026fd:	shr    rax,0x35
    70b3efb02701:	sub    eax,0x201
    70b3efb02706:	cmp    eax,0x3fc
    70b3efb0270b:	ja     0x70b3efb051b7
    70b3efb02711:	movdqa xmm14,xmm0
    70b3efb02716:	psrldq xmm14,0x8
    70b3efb0271c:	movq   rax,xmm14
    70b3efb02721:	add    rax,rax
    70b3efb02724:	je     0x70b3efb0273a
    70b3efb02726:	shr    rax,0x35
    70b3efb0272a:	sub    eax,0x201
    70b3efb0272f:	cmp    eax,0x3fc
    70b3efb02734:	ja     0x70b3efb051b7
    70b3efb0273a:	movq   rax,xmm1
    70b3efb0273f:	add    rax,rax
    70b3efb02742:	je     0x70b3efb02758
    70b3efb02744:	shr    rax,0x35
    70b3efb02748:	sub    eax,0x201
    70b3efb0274d:	cmp    eax,0x3fc
    70b3efb02752:	ja     0x70b3efb051b7
    70b3efb02758:	movdqa xmm14,xmm1
    70b3efb0275d:	psrldq xmm14,0x8
    70b3efb02763:	movq   rax,xmm14
    70b3efb02768:	add    rax,rax
    70b3efb0276b:	je     0x70b3efb02781
    70b3efb0276d:	shr    rax,0x35
    70b3efb02771:	sub    eax,0x201
    70b3efb02776:	cmp    eax,0x3fc
    70b3efb0277b:	ja     0x70b3efb051b7
    70b3efb02781:	mulpd  xmm0,xmm1
    70b3efb02785:	movdqa xmm5,xmm0
    70b3efb02789:	movdqa xmm0,xmm5
    70b3efb0278d:	movdqu XMMWORD PTR [r12+0x260],xmm0
    70b3efb02797:	mov    r13d,0x0
    70b3efb0279d:	mov    r14d,0x0
    70b3efb027a3:	mov    QWORD PTR [r12+0x1b0],r13
    70b3efb027ab:	mov    QWORD PTR [r12+0x1b8],r14
    70b3efb027b3:	movdqa xmm0,xmm2
    70b3efb027b7:	movdqa xmm1,xmm4
    70b3efb027bb:	pshufd xmm1,xmm1,0x44
    70b3efb027c0:	movq   rax,xmm0
    70b3efb027c5:	add    rax,rax
    70b3efb027c8:	je     0x70b3efb027de
    70b3efb027ca:	shr    rax,0x35
    70b3efb027ce:	sub    eax,0x201
    70b3efb027d3:	cmp    eax,0x3fc
    70b3efb027d8:	ja     0x70b3efb051db
    70b3efb027de:	movdqa xmm14,xmm0
    70b3efb027e3:	psrldq xmm14,0x8
    70b3efb027e9:	movq   rax,xmm14
    70b3efb027ee:	add    rax,rax
    70b3efb027f1:	je     0x70b3efb02807
    70b3efb027f3:	shr    rax,0x35
    70b3efb027f7:	sub    eax,0x201
    70b3efb027fc:	cmp    eax,0x3fc
    70b3efb02801:	ja     0x70b3efb051db
    70b3efb02807:	movq   rax,xmm1
    70b3efb0280c:	add    rax,rax
    70b3efb0280f:	je     0x70b3efb02825
    70b3efb02811:	shr    rax,0x35
    70b3efb02815:	sub    eax,0x201
    70b3efb0281a:	cmp    eax,0x3fc
    70b3efb0281f:	ja     0x70b3efb051db
    70b3efb02825:	movdqa xmm14,xmm1
    70b3efb0282a:	psrldq xmm14,0x8
    70b3efb02830:	movq   rax,xmm14
    70b3efb02835:	add    rax,rax
    70b3efb02838:	je     0x70b3efb0284e
    70b3efb0283a:	shr    rax,0x35
    70b3efb0283e:	sub    eax,0x201
    70b3efb02843:	cmp    eax,0x3fc
    70b3efb02848:	ja     0x70b3efb051db
    70b3efb0284e:	mulpd  xmm0,xmm1
    70b3efb02852:	movdqa xmm3,xmm0
    70b3efb02856:	movdqa xmm0,xmm3
    70b3efb0285a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    70b3efb02864:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb0286c:	mov    r14,r13
    70b3efb0286f:	add    r14,0xc0
    70b3efb02876:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb0287e:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb02886:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb0288e:	shr    r11d,1
    70b3efb02891:	and    r11d,0x10
    70b3efb02895:	or     DWORD PTR [r12+0x314],r11d
    70b3efb0289d:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb028a2:	movdqa xmm0,xmm2
    70b3efb028a6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb028b0:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    70b3efb028ba:	movdqa xmm3,xmm0
    70b3efb028be:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    70b3efb028c8:	movdqa xmm4,xmm0
    70b3efb028cc:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb028d4:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb028df:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb028e7:	movdqa xmm0,xmm3
    70b3efb028eb:	movdqa xmm1,xmm4
    70b3efb028ef:	movq   rax,xmm0
    70b3efb028f4:	add    rax,rax
    70b3efb028f7:	je     0x70b3efb0290d
    70b3efb028f9:	shr    rax,0x35
    70b3efb028fd:	sub    eax,0x201
    70b3efb02902:	cmp    eax,0x3fc
    70b3efb02907:	ja     0x70b3efb051ff
    70b3efb0290d:	movdqa xmm14,xmm0
    70b3efb02912:	psrldq xmm14,0x8
    70b3efb02918:	movq   rax,xmm14
    70b3efb0291d:	add    rax,rax
    70b3efb02920:	je     0x70b3efb02936
    70b3efb02922:	shr    rax,0x35
    70b3efb02926:	sub    eax,0x201
    70b3efb0292b:	cmp    eax,0x3fc
    70b3efb02930:	ja     0x70b3efb051ff
    70b3efb02936:	movq   rax,xmm1
    70b3efb0293b:	add    rax,rax
    70b3efb0293e:	je     0x70b3efb02954
    70b3efb02940:	shr    rax,0x35
    70b3efb02944:	sub    eax,0x201
    70b3efb02949:	cmp    eax,0x3fc
    70b3efb0294e:	ja     0x70b3efb051ff
    70b3efb02954:	movdqa xmm14,xmm1
    70b3efb02959:	psrldq xmm14,0x8
    70b3efb0295f:	movq   rax,xmm14
    70b3efb02964:	add    rax,rax
    70b3efb02967:	je     0x70b3efb0297d
    70b3efb02969:	shr    rax,0x35
    70b3efb0296d:	sub    eax,0x201
    70b3efb02972:	cmp    eax,0x3fc
    70b3efb02977:	ja     0x70b3efb051ff
    70b3efb0297d:	addpd  xmm0,xmm1
    70b3efb02981:	movdqa xmm5,xmm0
    70b3efb02985:	movdqa xmm0,xmm5
    70b3efb02989:	movdqu XMMWORD PTR [r12+0x240],xmm0
    70b3efb02993:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    70b3efb0299d:	movdqa xmm3,xmm0
    70b3efb029a1:	movdqa xmm1,xmm3
    70b3efb029a5:	por    xmm3,xmm1
    70b3efb029a9:	movdqa xmm0,xmm3
    70b3efb029ad:	movdqu XMMWORD PTR [r12+0x270],xmm0
    70b3efb029b7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    70b3efb029c1:	movdqa xmm3,xmm0
    70b3efb029c5:	movdqa xmm1,xmm3
    70b3efb029c9:	por    xmm3,xmm1
    70b3efb029cd:	movdqa xmm0,xmm3
    70b3efb029d1:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    70b3efb029db:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    70b3efb029e5:	movdqa xmm3,xmm0
    70b3efb029e9:	movdqa xmm0,xmm2
    70b3efb029ed:	movdqa xmm1,xmm3
    70b3efb029f1:	pshufd xmm1,xmm1,0x44
    70b3efb029f6:	movq   rax,xmm0
    70b3efb029fb:	add    rax,rax
    70b3efb029fe:	je     0x70b3efb02a14
    70b3efb02a00:	shr    rax,0x35
    70b3efb02a04:	sub    eax,0x201
    70b3efb02a09:	cmp    eax,0x3fc
    70b3efb02a0e:	ja     0x70b3efb05223
    70b3efb02a14:	movdqa xmm14,xmm0
    70b3efb02a19:	psrldq xmm14,0x8
    70b3efb02a1f:	movq   rax,xmm14
    70b3efb02a24:	add    rax,rax
    70b3efb02a27:	je     0x70b3efb02a3d
    70b3efb02a29:	shr    rax,0x35
    70b3efb02a2d:	sub    eax,0x201
    70b3efb02a32:	cmp    eax,0x3fc
    70b3efb02a37:	ja     0x70b3efb05223
    70b3efb02a3d:	movq   rax,xmm1
    70b3efb02a42:	add    rax,rax
    70b3efb02a45:	je     0x70b3efb02a5b
    70b3efb02a47:	shr    rax,0x35
    70b3efb02a4b:	sub    eax,0x201
    70b3efb02a50:	cmp    eax,0x3fc
    70b3efb02a55:	ja     0x70b3efb05223
    70b3efb02a5b:	movdqa xmm14,xmm1
    70b3efb02a60:	psrldq xmm14,0x8
    70b3efb02a66:	movq   rax,xmm14
    70b3efb02a6b:	add    rax,rax
    70b3efb02a6e:	je     0x70b3efb02a84
    70b3efb02a70:	shr    rax,0x35
    70b3efb02a74:	sub    eax,0x201
    70b3efb02a79:	cmp    eax,0x3fc
    70b3efb02a7e:	ja     0x70b3efb05223
    70b3efb02a84:	mulpd  xmm0,xmm1
    70b3efb02a88:	movdqa xmm4,xmm0
    70b3efb02a8c:	movdqa xmm0,xmm4
    70b3efb02a90:	movdqu XMMWORD PTR [r12+0x250],xmm0
    70b3efb02a9a:	add    r13,0x20
    70b3efb02a9e:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb02aa6:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb02aae:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb02ab6:	shr    r11d,1
    70b3efb02ab9:	and    r11d,0x10
    70b3efb02abd:	or     DWORD PTR [r12+0x314],r11d
    70b3efb02ac5:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb02acb:	movdqa xmm0,xmm2
    70b3efb02acf:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb02ad9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb02ae3:	movdqa xmm2,xmm0
    70b3efb02ae7:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb02af1:	movdqa xmm4,xmm0
    70b3efb02af5:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb02afd:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb02b08:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb02b10:	movdqa xmm0,xmm2
    70b3efb02b14:	movdqa xmm1,xmm4
    70b3efb02b18:	movq   rax,xmm0
    70b3efb02b1d:	add    rax,rax
    70b3efb02b20:	je     0x70b3efb02b36
    70b3efb02b22:	shr    rax,0x35
    70b3efb02b26:	sub    eax,0x201
    70b3efb02b2b:	cmp    eax,0x3fc
    70b3efb02b30:	ja     0x70b3efb05247
    70b3efb02b36:	movdqa xmm14,xmm0
    70b3efb02b3b:	psrldq xmm14,0x8
    70b3efb02b41:	movq   rax,xmm14
    70b3efb02b46:	add    rax,rax
    70b3efb02b49:	je     0x70b3efb02b5f
    70b3efb02b4b:	shr    rax,0x35
    70b3efb02b4f:	sub    eax,0x201
    70b3efb02b54:	cmp    eax,0x3fc
    70b3efb02b59:	ja     0x70b3efb05247
    70b3efb02b5f:	movq   rax,xmm1
    70b3efb02b64:	add    rax,rax
    70b3efb02b67:	je     0x70b3efb02b7d
    70b3efb02b69:	shr    rax,0x35
    70b3efb02b6d:	sub    eax,0x201
    70b3efb02b72:	cmp    eax,0x3fc
    70b3efb02b77:	ja     0x70b3efb05247
    70b3efb02b7d:	movdqa xmm14,xmm1
    70b3efb02b82:	psrldq xmm14,0x8
    70b3efb02b88:	movq   rax,xmm14
    70b3efb02b8d:	add    rax,rax
    70b3efb02b90:	je     0x70b3efb02ba6
    70b3efb02b92:	shr    rax,0x35
    70b3efb02b96:	sub    eax,0x201
    70b3efb02b9b:	cmp    eax,0x3fc
    70b3efb02ba0:	ja     0x70b3efb05247
    70b3efb02ba6:	addpd  xmm0,xmm1
    70b3efb02baa:	movdqa xmm5,xmm0
    70b3efb02bae:	movdqa xmm0,xmm5
    70b3efb02bb2:	movdqu XMMWORD PTR [r12+0x170],xmm0
    70b3efb02bbc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    70b3efb02bc6:	movdqa xmm2,xmm0
    70b3efb02bca:	movdqa xmm0,xmm2
    70b3efb02bce:	movdqa xmm1,xmm3
    70b3efb02bd2:	pshufd xmm1,xmm1,0x44
    70b3efb02bd7:	movq   rax,xmm0
    70b3efb02bdc:	add    rax,rax
    70b3efb02bdf:	je     0x70b3efb02bf5
    70b3efb02be1:	shr    rax,0x35
    70b3efb02be5:	sub    eax,0x201
    70b3efb02bea:	cmp    eax,0x3fc
    70b3efb02bef:	ja     0x70b3efb0526b
    70b3efb02bf5:	movdqa xmm14,xmm0
    70b3efb02bfa:	psrldq xmm14,0x8
    70b3efb02c00:	movq   rax,xmm14
    70b3efb02c05:	add    rax,rax
    70b3efb02c08:	je     0x70b3efb02c1e
    70b3efb02c0a:	shr    rax,0x35
    70b3efb02c0e:	sub    eax,0x201
    70b3efb02c13:	cmp    eax,0x3fc
    70b3efb02c18:	ja     0x70b3efb0526b
    70b3efb02c1e:	movq   rax,xmm1
    70b3efb02c23:	add    rax,rax
    70b3efb02c26:	je     0x70b3efb02c3c
    70b3efb02c28:	shr    rax,0x35
    70b3efb02c2c:	sub    eax,0x201
    70b3efb02c31:	cmp    eax,0x3fc
    70b3efb02c36:	ja     0x70b3efb0526b
    70b3efb02c3c:	movdqa xmm14,xmm1
    70b3efb02c41:	psrldq xmm14,0x8
    70b3efb02c47:	movq   rax,xmm14
    70b3efb02c4c:	add    rax,rax
    70b3efb02c4f:	je     0x70b3efb02c65
    70b3efb02c51:	shr    rax,0x35
    70b3efb02c55:	sub    eax,0x201
    70b3efb02c5a:	cmp    eax,0x3fc
    70b3efb02c5f:	ja     0x70b3efb0526b
    70b3efb02c65:	mulpd  xmm0,xmm1
    70b3efb02c69:	movdqa xmm4,xmm0
    70b3efb02c6d:	movdqa xmm0,xmm4
    70b3efb02c71:	movdqu XMMWORD PTR [r12+0x160],xmm0
    70b3efb02c7b:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb02c85:	movdqa xmm2,xmm0
    70b3efb02c89:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    70b3efb02c93:	movdqa xmm3,xmm0
    70b3efb02c97:	movdqa xmm0,xmm2
    70b3efb02c9b:	movdqa xmm1,xmm3
    70b3efb02c9f:	movq   rax,xmm0
    70b3efb02ca4:	add    rax,rax
    70b3efb02ca7:	je     0x70b3efb02cbd
    70b3efb02ca9:	shr    rax,0x35
    70b3efb02cad:	sub    eax,0x201
    70b3efb02cb2:	cmp    eax,0x3fc
    70b3efb02cb7:	ja     0x70b3efb0528f
    70b3efb02cbd:	movdqa xmm14,xmm0
    70b3efb02cc2:	psrldq xmm14,0x8
    70b3efb02cc8:	movq   rax,xmm14
    70b3efb02ccd:	add    rax,rax
    70b3efb02cd0:	je     0x70b3efb02ce6
    70b3efb02cd2:	shr    rax,0x35
    70b3efb02cd6:	sub    eax,0x201
    70b3efb02cdb:	cmp    eax,0x3fc
    70b3efb02ce0:	ja     0x70b3efb0528f
    70b3efb02ce6:	movq   rax,xmm1
    70b3efb02ceb:	add    rax,rax
    70b3efb02cee:	je     0x70b3efb02d04
    70b3efb02cf0:	shr    rax,0x35
    70b3efb02cf4:	sub    eax,0x201
    70b3efb02cf9:	cmp    eax,0x3fc
    70b3efb02cfe:	ja     0x70b3efb0528f
    70b3efb02d04:	movdqa xmm14,xmm1
    70b3efb02d09:	psrldq xmm14,0x8
    70b3efb02d0f:	movq   rax,xmm14
    70b3efb02d14:	add    rax,rax
    70b3efb02d17:	je     0x70b3efb02d2d
    70b3efb02d19:	shr    rax,0x35
    70b3efb02d1d:	sub    eax,0x201
    70b3efb02d22:	cmp    eax,0x3fc
    70b3efb02d27:	ja     0x70b3efb0528f
    70b3efb02d2d:	addpd  xmm0,xmm1
    70b3efb02d31:	movdqa xmm4,xmm0
    70b3efb02d35:	movdqa xmm0,xmm4
    70b3efb02d39:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb02d43:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb02d4d:	movdqa xmm2,xmm0
    70b3efb02d51:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    70b3efb02d5b:	movdqa xmm3,xmm0
    70b3efb02d5f:	movdqa xmm0,xmm2
    70b3efb02d63:	movdqa xmm1,xmm3
    70b3efb02d67:	pshufd xmm1,xmm1,0x44
    70b3efb02d6c:	movq   rax,xmm0
    70b3efb02d71:	add    rax,rax
    70b3efb02d74:	je     0x70b3efb02d8a
    70b3efb02d76:	shr    rax,0x35
    70b3efb02d7a:	sub    eax,0x201
    70b3efb02d7f:	cmp    eax,0x3fc
    70b3efb02d84:	ja     0x70b3efb052b3
    70b3efb02d8a:	movdqa xmm14,xmm0
    70b3efb02d8f:	psrldq xmm14,0x8
    70b3efb02d95:	movq   rax,xmm14
    70b3efb02d9a:	add    rax,rax
    70b3efb02d9d:	je     0x70b3efb02db3
    70b3efb02d9f:	shr    rax,0x35
    70b3efb02da3:	sub    eax,0x201
    70b3efb02da8:	cmp    eax,0x3fc
    70b3efb02dad:	ja     0x70b3efb052b3
    70b3efb02db3:	movq   rax,xmm1
    70b3efb02db8:	add    rax,rax
    70b3efb02dbb:	je     0x70b3efb02dd1
    70b3efb02dbd:	shr    rax,0x35
    70b3efb02dc1:	sub    eax,0x201
    70b3efb02dc6:	cmp    eax,0x3fc
    70b3efb02dcb:	ja     0x70b3efb052b3
    70b3efb02dd1:	movdqa xmm14,xmm1
    70b3efb02dd6:	psrldq xmm14,0x8
    70b3efb02ddc:	movq   rax,xmm14
    70b3efb02de1:	add    rax,rax
    70b3efb02de4:	je     0x70b3efb02dfa
    70b3efb02de6:	shr    rax,0x35
    70b3efb02dea:	sub    eax,0x201
    70b3efb02def:	cmp    eax,0x3fc
    70b3efb02df4:	ja     0x70b3efb052b3
    70b3efb02dfa:	mulpd  xmm0,xmm1
    70b3efb02dfe:	movdqa xmm4,xmm0
    70b3efb02e02:	movdqa xmm0,xmm4
    70b3efb02e06:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb02e10:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    70b3efb02e1a:	movdqa xmm2,xmm0
    70b3efb02e1e:	movdqa xmm0,xmm2
    70b3efb02e22:	movdqa xmm1,xmm3
    70b3efb02e26:	pshufd xmm1,xmm1,0x44
    70b3efb02e2b:	movq   rax,xmm0
    70b3efb02e30:	add    rax,rax
    70b3efb02e33:	je     0x70b3efb02e49
    70b3efb02e35:	shr    rax,0x35
    70b3efb02e39:	sub    eax,0x201
    70b3efb02e3e:	cmp    eax,0x3fc
    70b3efb02e43:	ja     0x70b3efb052d7
    70b3efb02e49:	movdqa xmm14,xmm0
    70b3efb02e4e:	psrldq xmm14,0x8
    70b3efb02e54:	movq   rax,xmm14
    70b3efb02e59:	add    rax,rax
    70b3efb02e5c:	je     0x70b3efb02e72
    70b3efb02e5e:	shr    rax,0x35
    70b3efb02e62:	sub    eax,0x201
    70b3efb02e67:	cmp    eax,0x3fc
    70b3efb02e6c:	ja     0x70b3efb052d7
    70b3efb02e72:	movq   rax,xmm1
    70b3efb02e77:	add    rax,rax
    70b3efb02e7a:	je     0x70b3efb02e90
    70b3efb02e7c:	shr    rax,0x35
    70b3efb02e80:	sub    eax,0x201
    70b3efb02e85:	cmp    eax,0x3fc
    70b3efb02e8a:	ja     0x70b3efb052d7
    70b3efb02e90:	movdqa xmm14,xmm1
    70b3efb02e95:	psrldq xmm14,0x8
    70b3efb02e9b:	movq   rax,xmm14
    70b3efb02ea0:	add    rax,rax
    70b3efb02ea3:	je     0x70b3efb02eb9
    70b3efb02ea5:	shr    rax,0x35
    70b3efb02ea9:	sub    eax,0x201
    70b3efb02eae:	cmp    eax,0x3fc
    70b3efb02eb3:	ja     0x70b3efb052d7
    70b3efb02eb9:	mulpd  xmm0,xmm1
    70b3efb02ebd:	movdqa xmm4,xmm0
    70b3efb02ec1:	movdqa xmm0,xmm4
    70b3efb02ec5:	movdqu XMMWORD PTR [r12+0x230],xmm0
    70b3efb02ecf:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    70b3efb02ed9:	movdqa xmm2,xmm0
    70b3efb02edd:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    70b3efb02ee7:	movdqa xmm4,xmm0
    70b3efb02eeb:	movdqa xmm0,xmm2
    70b3efb02eef:	movdqa xmm1,xmm4
    70b3efb02ef3:	movq   rax,xmm0
    70b3efb02ef8:	add    rax,rax
    70b3efb02efb:	je     0x70b3efb02f11
    70b3efb02efd:	shr    rax,0x35
    70b3efb02f01:	sub    eax,0x201
    70b3efb02f06:	cmp    eax,0x3fc
    70b3efb02f0b:	ja     0x70b3efb052fb
    70b3efb02f11:	movdqa xmm14,xmm0
    70b3efb02f16:	psrldq xmm14,0x8
    70b3efb02f1c:	movq   rax,xmm14
    70b3efb02f21:	add    rax,rax
    70b3efb02f24:	je     0x70b3efb02f3a
    70b3efb02f26:	shr    rax,0x35
    70b3efb02f2a:	sub    eax,0x201
    70b3efb02f2f:	cmp    eax,0x3fc
    70b3efb02f34:	ja     0x70b3efb052fb
    70b3efb02f3a:	movq   rax,xmm1
    70b3efb02f3f:	add    rax,rax
    70b3efb02f42:	je     0x70b3efb02f58
    70b3efb02f44:	shr    rax,0x35
    70b3efb02f48:	sub    eax,0x201
    70b3efb02f4d:	cmp    eax,0x3fc
    70b3efb02f52:	ja     0x70b3efb052fb
    70b3efb02f58:	movdqa xmm14,xmm1
    70b3efb02f5d:	psrldq xmm14,0x8
    70b3efb02f63:	movq   rax,xmm14
    70b3efb02f68:	add    rax,rax
    70b3efb02f6b:	je     0x70b3efb02f81
    70b3efb02f6d:	shr    rax,0x35
    70b3efb02f71:	sub    eax,0x201
    70b3efb02f76:	cmp    eax,0x3fc
    70b3efb02f7b:	ja     0x70b3efb052fb
    70b3efb02f81:	addpd  xmm0,xmm1
    70b3efb02f85:	movdqa xmm5,xmm0
    70b3efb02f89:	movdqa xmm0,xmm5
    70b3efb02f8d:	movdqu XMMWORD PTR [r12+0x240],xmm0
    70b3efb02f97:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb02fa1:	movdqa xmm2,xmm0
    70b3efb02fa5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    70b3efb02faf:	movdqa xmm4,xmm0
    70b3efb02fb3:	movdqa xmm0,xmm2
    70b3efb02fb7:	movdqa xmm1,xmm4
    70b3efb02fbb:	movq   rax,xmm0
    70b3efb02fc0:	add    rax,rax
    70b3efb02fc3:	je     0x70b3efb02fd9
    70b3efb02fc5:	shr    rax,0x35
    70b3efb02fc9:	sub    eax,0x201
    70b3efb02fce:	cmp    eax,0x3fc
    70b3efb02fd3:	ja     0x70b3efb0531f
    70b3efb02fd9:	movdqa xmm14,xmm0
    70b3efb02fde:	psrldq xmm14,0x8
    70b3efb02fe4:	movq   rax,xmm14
    70b3efb02fe9:	add    rax,rax
    70b3efb02fec:	je     0x70b3efb03002
    70b3efb02fee:	shr    rax,0x35
    70b3efb02ff2:	sub    eax,0x201
    70b3efb02ff7:	cmp    eax,0x3fc
    70b3efb02ffc:	ja     0x70b3efb0531f
    70b3efb03002:	movq   rax,xmm1
    70b3efb03007:	add    rax,rax
    70b3efb0300a:	je     0x70b3efb03020
    70b3efb0300c:	shr    rax,0x35
    70b3efb03010:	sub    eax,0x201
    70b3efb03015:	cmp    eax,0x3fc
    70b3efb0301a:	ja     0x70b3efb0531f
    70b3efb03020:	movdqa xmm14,xmm1
    70b3efb03025:	psrldq xmm14,0x8
    70b3efb0302b:	movq   rax,xmm14
    70b3efb03030:	add    rax,rax
    70b3efb03033:	je     0x70b3efb03049
    70b3efb03035:	shr    rax,0x35
    70b3efb03039:	sub    eax,0x201
    70b3efb0303e:	cmp    eax,0x3fc
    70b3efb03043:	ja     0x70b3efb0531f
    70b3efb03049:	addpd  xmm0,xmm1
    70b3efb0304d:	movdqa xmm5,xmm0
    70b3efb03051:	movdqa xmm0,xmm5
    70b3efb03055:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb0305f:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    70b3efb03069:	movdqa xmm2,xmm0
    70b3efb0306d:	movdqa xmm0,xmm2
    70b3efb03071:	movdqa xmm1,xmm3
    70b3efb03075:	pshufd xmm1,xmm1,0x44
    70b3efb0307a:	movq   rax,xmm0
    70b3efb0307f:	add    rax,rax
    70b3efb03082:	je     0x70b3efb03098
    70b3efb03084:	shr    rax,0x35
    70b3efb03088:	sub    eax,0x201
    70b3efb0308d:	cmp    eax,0x3fc
    70b3efb03092:	ja     0x70b3efb05343
    70b3efb03098:	movdqa xmm14,xmm0
    70b3efb0309d:	psrldq xmm14,0x8
    70b3efb030a3:	movq   rax,xmm14
    70b3efb030a8:	add    rax,rax
    70b3efb030ab:	je     0x70b3efb030c1
    70b3efb030ad:	shr    rax,0x35
    70b3efb030b1:	sub    eax,0x201
    70b3efb030b6:	cmp    eax,0x3fc
    70b3efb030bb:	ja     0x70b3efb05343
    70b3efb030c1:	movq   rax,xmm1
    70b3efb030c6:	add    rax,rax
    70b3efb030c9:	je     0x70b3efb030df
    70b3efb030cb:	shr    rax,0x35
    70b3efb030cf:	sub    eax,0x201
    70b3efb030d4:	cmp    eax,0x3fc
    70b3efb030d9:	ja     0x70b3efb05343
    70b3efb030df:	movdqa xmm14,xmm1
    70b3efb030e4:	psrldq xmm14,0x8
    70b3efb030ea:	movq   rax,xmm14
    70b3efb030ef:	add    rax,rax
    70b3efb030f2:	je     0x70b3efb03108
    70b3efb030f4:	shr    rax,0x35
    70b3efb030f8:	sub    eax,0x201
    70b3efb030fd:	cmp    eax,0x3fc
    70b3efb03102:	ja     0x70b3efb05343
    70b3efb03108:	mulpd  xmm0,xmm1
    70b3efb0310c:	movdqa xmm4,xmm0
    70b3efb03110:	movdqa xmm0,xmm4
    70b3efb03114:	movdqu XMMWORD PTR [r12+0x250],xmm0
    70b3efb0311e:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    70b3efb03128:	movdqa xmm2,xmm0
    70b3efb0312c:	movdqa xmm0,xmm2
    70b3efb03130:	movdqa xmm1,xmm3
    70b3efb03134:	pshufd xmm1,xmm1,0x44
    70b3efb03139:	movq   rax,xmm0
    70b3efb0313e:	add    rax,rax
    70b3efb03141:	je     0x70b3efb03157
    70b3efb03143:	shr    rax,0x35
    70b3efb03147:	sub    eax,0x201
    70b3efb0314c:	cmp    eax,0x3fc
    70b3efb03151:	ja     0x70b3efb05367
    70b3efb03157:	movdqa xmm14,xmm0
    70b3efb0315c:	psrldq xmm14,0x8
    70b3efb03162:	movq   rax,xmm14
    70b3efb03167:	add    rax,rax
    70b3efb0316a:	je     0x70b3efb03180
    70b3efb0316c:	shr    rax,0x35
    70b3efb03170:	sub    eax,0x201
    70b3efb03175:	cmp    eax,0x3fc
    70b3efb0317a:	ja     0x70b3efb05367
    70b3efb03180:	movq   rax,xmm1
    70b3efb03185:	add    rax,rax
    70b3efb03188:	je     0x70b3efb0319e
    70b3efb0318a:	shr    rax,0x35
    70b3efb0318e:	sub    eax,0x201
    70b3efb03193:	cmp    eax,0x3fc
    70b3efb03198:	ja     0x70b3efb05367
    70b3efb0319e:	movdqa xmm14,xmm1
    70b3efb031a3:	psrldq xmm14,0x8
    70b3efb031a9:	movq   rax,xmm14
    70b3efb031ae:	add    rax,rax
    70b3efb031b1:	je     0x70b3efb031c7
    70b3efb031b3:	shr    rax,0x35
    70b3efb031b7:	sub    eax,0x201
    70b3efb031bc:	cmp    eax,0x3fc
    70b3efb031c1:	ja     0x70b3efb05367
    70b3efb031c7:	mulpd  xmm0,xmm1
    70b3efb031cb:	movdqa xmm4,xmm0
    70b3efb031cf:	movdqa xmm0,xmm4
    70b3efb031d3:	movdqu XMMWORD PTR [r12+0x150],xmm0
    70b3efb031dd:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb031e7:	movdqa xmm2,xmm0
    70b3efb031eb:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    70b3efb031f5:	movdqa xmm3,xmm0
    70b3efb031f9:	movdqa xmm0,xmm2
    70b3efb031fd:	movdqa xmm1,xmm3
    70b3efb03201:	movq   rax,xmm0
    70b3efb03206:	add    rax,rax
    70b3efb03209:	je     0x70b3efb0321f
    70b3efb0320b:	shr    rax,0x35
    70b3efb0320f:	sub    eax,0x201
    70b3efb03214:	cmp    eax,0x3fc
    70b3efb03219:	ja     0x70b3efb0538b
    70b3efb0321f:	movdqa xmm14,xmm0
    70b3efb03224:	psrldq xmm14,0x8
    70b3efb0322a:	movq   rax,xmm14
    70b3efb0322f:	add    rax,rax
    70b3efb03232:	je     0x70b3efb03248
    70b3efb03234:	shr    rax,0x35
    70b3efb03238:	sub    eax,0x201
    70b3efb0323d:	cmp    eax,0x3fc
    70b3efb03242:	ja     0x70b3efb0538b
    70b3efb03248:	movq   rax,xmm1
    70b3efb0324d:	add    rax,rax
    70b3efb03250:	je     0x70b3efb03266
    70b3efb03252:	shr    rax,0x35
    70b3efb03256:	sub    eax,0x201
    70b3efb0325b:	cmp    eax,0x3fc
    70b3efb03260:	ja     0x70b3efb0538b
    70b3efb03266:	movdqa xmm14,xmm1
    70b3efb0326b:	psrldq xmm14,0x8
    70b3efb03271:	movq   rax,xmm14
    70b3efb03276:	add    rax,rax
    70b3efb03279:	je     0x70b3efb0328f
    70b3efb0327b:	shr    rax,0x35
    70b3efb0327f:	sub    eax,0x201
    70b3efb03284:	cmp    eax,0x3fc
    70b3efb03289:	ja     0x70b3efb0538b
    70b3efb0328f:	addpd  xmm0,xmm1
    70b3efb03293:	movdqa xmm4,xmm0
    70b3efb03297:	movdqa xmm0,xmm4
    70b3efb0329b:	movdqu XMMWORD PTR [r12+0x160],xmm0
    70b3efb032a5:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb032af:	movdqa xmm2,xmm0
    70b3efb032b3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb032bd:	movdqa xmm3,xmm0
    70b3efb032c1:	movdqa xmm0,xmm2
    70b3efb032c5:	movdqa xmm1,xmm3
    70b3efb032c9:	movq   rax,xmm0
    70b3efb032ce:	add    rax,rax
    70b3efb032d1:	je     0x70b3efb032e7
    70b3efb032d3:	shr    rax,0x35
    70b3efb032d7:	sub    eax,0x201
    70b3efb032dc:	cmp    eax,0x3fc
    70b3efb032e1:	ja     0x70b3efb053af
    70b3efb032e7:	movdqa xmm14,xmm0
    70b3efb032ec:	psrldq xmm14,0x8
    70b3efb032f2:	movq   rax,xmm14
    70b3efb032f7:	add    rax,rax
    70b3efb032fa:	je     0x70b3efb03310
    70b3efb032fc:	shr    rax,0x35
    70b3efb03300:	sub    eax,0x201
    70b3efb03305:	cmp    eax,0x3fc
    70b3efb0330a:	ja     0x70b3efb053af
    70b3efb03310:	movq   rax,xmm1
    70b3efb03315:	add    rax,rax
    70b3efb03318:	je     0x70b3efb0332e
    70b3efb0331a:	shr    rax,0x35
    70b3efb0331e:	sub    eax,0x201
    70b3efb03323:	cmp    eax,0x3fc
    70b3efb03328:	ja     0x70b3efb053af
    70b3efb0332e:	movdqa xmm14,xmm1
    70b3efb03333:	psrldq xmm14,0x8
    70b3efb03339:	movq   rax,xmm14
    70b3efb0333e:	add    rax,rax
    70b3efb03341:	je     0x70b3efb03357
    70b3efb03343:	shr    rax,0x35
    70b3efb03347:	sub    eax,0x201
    70b3efb0334c:	cmp    eax,0x3fc
    70b3efb03351:	ja     0x70b3efb053af
    70b3efb03357:	addpd  xmm0,xmm1
    70b3efb0335b:	movdqa xmm4,xmm0
    70b3efb0335f:	movdqa xmm0,xmm4
    70b3efb03363:	movdqu XMMWORD PTR [r12+0x170],xmm0
    70b3efb0336d:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    70b3efb03377:	movdqa xmm2,xmm0
    70b3efb0337b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    70b3efb03385:	movdqa xmm3,xmm0
    70b3efb03389:	movdqa xmm0,xmm2
    70b3efb0338d:	movdqa xmm1,xmm3
    70b3efb03391:	pshufd xmm1,xmm1,0x44
    70b3efb03396:	movq   rax,xmm0
    70b3efb0339b:	add    rax,rax
    70b3efb0339e:	je     0x70b3efb033b4
    70b3efb033a0:	shr    rax,0x35
    70b3efb033a4:	sub    eax,0x201
    70b3efb033a9:	cmp    eax,0x3fc
    70b3efb033ae:	ja     0x70b3efb053d3
    70b3efb033b4:	movdqa xmm14,xmm0
    70b3efb033b9:	psrldq xmm14,0x8
    70b3efb033bf:	movq   rax,xmm14
    70b3efb033c4:	add    rax,rax
    70b3efb033c7:	je     0x70b3efb033dd
    70b3efb033c9:	shr    rax,0x35
    70b3efb033cd:	sub    eax,0x201
    70b3efb033d2:	cmp    eax,0x3fc
    70b3efb033d7:	ja     0x70b3efb053d3
    70b3efb033dd:	movq   rax,xmm1
    70b3efb033e2:	add    rax,rax
    70b3efb033e5:	je     0x70b3efb033fb
    70b3efb033e7:	shr    rax,0x35
    70b3efb033eb:	sub    eax,0x201
    70b3efb033f0:	cmp    eax,0x3fc
    70b3efb033f5:	ja     0x70b3efb053d3
    70b3efb033fb:	movdqa xmm14,xmm1
    70b3efb03400:	psrldq xmm14,0x8
    70b3efb03406:	movq   rax,xmm14
    70b3efb0340b:	add    rax,rax
    70b3efb0340e:	je     0x70b3efb03424
    70b3efb03410:	shr    rax,0x35
    70b3efb03414:	sub    eax,0x201
    70b3efb03419:	cmp    eax,0x3fc
    70b3efb0341e:	ja     0x70b3efb053d3
    70b3efb03424:	mulpd  xmm0,xmm1
    70b3efb03428:	movdqa xmm4,xmm0
    70b3efb0342c:	movdqa xmm0,xmm4
    70b3efb03430:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb0343a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb03444:	movdqa xmm2,xmm0
    70b3efb03448:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    70b3efb03452:	movdqa xmm3,xmm0
    70b3efb03456:	movdqa xmm0,xmm2
    70b3efb0345a:	movdqa xmm1,xmm3
    70b3efb0345e:	movq   rax,xmm0
    70b3efb03463:	add    rax,rax
    70b3efb03466:	je     0x70b3efb0347c
    70b3efb03468:	shr    rax,0x35
    70b3efb0346c:	sub    eax,0x201
    70b3efb03471:	cmp    eax,0x3fc
    70b3efb03476:	ja     0x70b3efb053f7
    70b3efb0347c:	movdqa xmm14,xmm0
    70b3efb03481:	psrldq xmm14,0x8
    70b3efb03487:	movq   rax,xmm14
    70b3efb0348c:	add    rax,rax
    70b3efb0348f:	je     0x70b3efb034a5
    70b3efb03491:	shr    rax,0x35
    70b3efb03495:	sub    eax,0x201
    70b3efb0349a:	cmp    eax,0x3fc
    70b3efb0349f:	ja     0x70b3efb053f7
    70b3efb034a5:	movq   rax,xmm1
    70b3efb034aa:	add    rax,rax
    70b3efb034ad:	je     0x70b3efb034c3
    70b3efb034af:	shr    rax,0x35
    70b3efb034b3:	sub    eax,0x201
    70b3efb034b8:	cmp    eax,0x3fc
    70b3efb034bd:	ja     0x70b3efb053f7
    70b3efb034c3:	movdqa xmm14,xmm1
    70b3efb034c8:	psrldq xmm14,0x8
    70b3efb034ce:	movq   rax,xmm14
    70b3efb034d3:	add    rax,rax
    70b3efb034d6:	je     0x70b3efb034ec
    70b3efb034d8:	shr    rax,0x35
    70b3efb034dc:	sub    eax,0x201
    70b3efb034e1:	cmp    eax,0x3fc
    70b3efb034e6:	ja     0x70b3efb053f7
    70b3efb034ec:	addpd  xmm0,xmm1
    70b3efb034f0:	movdqa xmm4,xmm0
    70b3efb034f4:	movdqa xmm0,xmm4
    70b3efb034f8:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb03502:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    70b3efb0350c:	movdqa xmm2,xmm0
    70b3efb03510:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    70b3efb0351a:	movdqa xmm3,xmm0
    70b3efb0351e:	movdqa xmm0,xmm2
    70b3efb03522:	movdqa xmm1,xmm3
    70b3efb03526:	movq   rax,xmm0
    70b3efb0352b:	add    rax,rax
    70b3efb0352e:	je     0x70b3efb03544
    70b3efb03530:	shr    rax,0x35
    70b3efb03534:	sub    eax,0x201
    70b3efb03539:	cmp    eax,0x3fc
    70b3efb0353e:	ja     0x70b3efb0541b
    70b3efb03544:	movdqa xmm14,xmm0
    70b3efb03549:	psrldq xmm14,0x8
    70b3efb0354f:	movq   rax,xmm14
    70b3efb03554:	add    rax,rax
    70b3efb03557:	je     0x70b3efb0356d
    70b3efb03559:	shr    rax,0x35
    70b3efb0355d:	sub    eax,0x201
    70b3efb03562:	cmp    eax,0x3fc
    70b3efb03567:	ja     0x70b3efb0541b
    70b3efb0356d:	movq   rax,xmm1
    70b3efb03572:	add    rax,rax
    70b3efb03575:	je     0x70b3efb0358b
    70b3efb03577:	shr    rax,0x35
    70b3efb0357b:	sub    eax,0x201
    70b3efb03580:	cmp    eax,0x3fc
    70b3efb03585:	ja     0x70b3efb0541b
    70b3efb0358b:	movdqa xmm14,xmm1
    70b3efb03590:	psrldq xmm14,0x8
    70b3efb03596:	movq   rax,xmm14
    70b3efb0359b:	add    rax,rax
    70b3efb0359e:	je     0x70b3efb035b4
    70b3efb035a0:	shr    rax,0x35
    70b3efb035a4:	sub    eax,0x201
    70b3efb035a9:	cmp    eax,0x3fc
    70b3efb035ae:	ja     0x70b3efb0541b
    70b3efb035b4:	addpd  xmm0,xmm1
    70b3efb035b8:	movdqa xmm4,xmm0
    70b3efb035bc:	movdqa xmm0,xmm4
    70b3efb035c0:	movdqu XMMWORD PTR [r12+0x230],xmm0
    70b3efb035ca:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    70b3efb035d4:	movdqa xmm2,xmm0
    70b3efb035d8:	movdqa xmm1,xmm2
    70b3efb035dc:	por    xmm2,xmm1
    70b3efb035e0:	movdqa xmm0,xmm2
    70b3efb035e4:	movdqu XMMWORD PTR [r12+0x250],xmm0
    70b3efb035ee:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    70b3efb035f8:	movdqa xmm2,xmm0
    70b3efb035fc:	movdqa xmm1,xmm2
    70b3efb03600:	por    xmm2,xmm1
    70b3efb03604:	movdqa xmm0,xmm2
    70b3efb03608:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    70b3efb03612:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    70b3efb0361c:	movdqa xmm2,xmm0
    70b3efb03620:	movdqa xmm1,xmm2
    70b3efb03624:	por    xmm2,xmm1
    70b3efb03628:	movdqa xmm0,xmm2
    70b3efb0362c:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    70b3efb03636:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb0363e:	add    r13,0x40
    70b3efb03642:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb0364a:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb03652:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb0365a:	shr    r11d,1
    70b3efb0365d:	and    r11d,0x10
    70b3efb03661:	or     DWORD PTR [r12+0x314],r11d
    70b3efb03669:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb0366f:	movdqa xmm0,xmm2
    70b3efb03673:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    70b3efb0367d:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    70b3efb03687:	movdqa xmm2,xmm0
    70b3efb0368b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    70b3efb03695:	movdqa xmm3,xmm0
    70b3efb03699:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb036a1:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb036ac:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb036b4:	movdqa xmm0,xmm2
    70b3efb036b8:	movdqa xmm1,xmm3
    70b3efb036bc:	pshufd xmm1,xmm1,0x44
    70b3efb036c1:	movq   rax,xmm0
    70b3efb036c6:	add    rax,rax
    70b3efb036c9:	je     0x70b3efb036df
    70b3efb036cb:	shr    rax,0x35
    70b3efb036cf:	sub    eax,0x201
    70b3efb036d4:	cmp    eax,0x3fc
    70b3efb036d9:	ja     0x70b3efb0543f
    70b3efb036df:	movdqa xmm14,xmm0
    70b3efb036e4:	psrldq xmm14,0x8
    70b3efb036ea:	movq   rax,xmm14
    70b3efb036ef:	add    rax,rax
    70b3efb036f2:	je     0x70b3efb03708
    70b3efb036f4:	shr    rax,0x35
    70b3efb036f8:	sub    eax,0x201
    70b3efb036fd:	cmp    eax,0x3fc
    70b3efb03702:	ja     0x70b3efb0543f
    70b3efb03708:	movq   rax,xmm1
    70b3efb0370d:	add    rax,rax
    70b3efb03710:	je     0x70b3efb03726
    70b3efb03712:	shr    rax,0x35
    70b3efb03716:	sub    eax,0x201
    70b3efb0371b:	cmp    eax,0x3fc
    70b3efb03720:	ja     0x70b3efb0543f
    70b3efb03726:	movdqa xmm14,xmm1
    70b3efb0372b:	psrldq xmm14,0x8
    70b3efb03731:	movq   rax,xmm14
    70b3efb03736:	add    rax,rax
    70b3efb03739:	je     0x70b3efb0374f
    70b3efb0373b:	shr    rax,0x35
    70b3efb0373f:	sub    eax,0x201
    70b3efb03744:	cmp    eax,0x3fc
    70b3efb03749:	ja     0x70b3efb0543f
    70b3efb0374f:	mulpd  xmm0,xmm1
    70b3efb03753:	movdqa xmm4,xmm0
    70b3efb03757:	movdqa xmm0,xmm4
    70b3efb0375b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb03765:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    70b3efb0376f:	movdqa xmm2,xmm0
    70b3efb03773:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    70b3efb0377d:	movdqa xmm4,xmm0
    70b3efb03781:	movdqa xmm0,xmm2
    70b3efb03785:	movdqa xmm1,xmm4
    70b3efb03789:	movq   rax,xmm0
    70b3efb0378e:	add    rax,rax
    70b3efb03791:	je     0x70b3efb037a7
    70b3efb03793:	shr    rax,0x35
    70b3efb03797:	sub    eax,0x201
    70b3efb0379c:	cmp    eax,0x3fc
    70b3efb037a1:	ja     0x70b3efb05463
    70b3efb037a7:	movdqa xmm14,xmm0
    70b3efb037ac:	psrldq xmm14,0x8
    70b3efb037b2:	movq   rax,xmm14
    70b3efb037b7:	add    rax,rax
    70b3efb037ba:	je     0x70b3efb037d0
    70b3efb037bc:	shr    rax,0x35
    70b3efb037c0:	sub    eax,0x201
    70b3efb037c5:	cmp    eax,0x3fc
    70b3efb037ca:	ja     0x70b3efb05463
    70b3efb037d0:	movq   rax,xmm1
    70b3efb037d5:	add    rax,rax
    70b3efb037d8:	je     0x70b3efb037ee
    70b3efb037da:	shr    rax,0x35
    70b3efb037de:	sub    eax,0x201
    70b3efb037e3:	cmp    eax,0x3fc
    70b3efb037e8:	ja     0x70b3efb05463
    70b3efb037ee:	movdqa xmm14,xmm1
    70b3efb037f3:	psrldq xmm14,0x8
    70b3efb037f9:	movq   rax,xmm14
    70b3efb037fe:	add    rax,rax
    70b3efb03801:	je     0x70b3efb03817
    70b3efb03803:	shr    rax,0x35
    70b3efb03807:	sub    eax,0x201
    70b3efb0380c:	cmp    eax,0x3fc
    70b3efb03811:	ja     0x70b3efb05463
    70b3efb03817:	addpd  xmm0,xmm1
    70b3efb0381b:	movdqa xmm5,xmm0
    70b3efb0381f:	movdqa xmm0,xmm5
    70b3efb03823:	movdqu XMMWORD PTR [r12+0x150],xmm0
    70b3efb0382d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb03837:	movdqa xmm2,xmm0
    70b3efb0383b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb03845:	movdqa xmm4,xmm0
    70b3efb03849:	movdqa xmm0,xmm2
    70b3efb0384d:	movdqa xmm1,xmm4
    70b3efb03851:	movq   rax,xmm0
    70b3efb03856:	add    rax,rax
    70b3efb03859:	je     0x70b3efb0386f
    70b3efb0385b:	shr    rax,0x35
    70b3efb0385f:	sub    eax,0x201
    70b3efb03864:	cmp    eax,0x3fc
    70b3efb03869:	ja     0x70b3efb05487
    70b3efb0386f:	movdqa xmm14,xmm0
    70b3efb03874:	psrldq xmm14,0x8
    70b3efb0387a:	movq   rax,xmm14
    70b3efb0387f:	add    rax,rax
    70b3efb03882:	je     0x70b3efb03898
    70b3efb03884:	shr    rax,0x35
    70b3efb03888:	sub    eax,0x201
    70b3efb0388d:	cmp    eax,0x3fc
    70b3efb03892:	ja     0x70b3efb05487
    70b3efb03898:	movq   rax,xmm1
    70b3efb0389d:	add    rax,rax
    70b3efb038a0:	je     0x70b3efb038b6
    70b3efb038a2:	shr    rax,0x35
    70b3efb038a6:	sub    eax,0x201
    70b3efb038ab:	cmp    eax,0x3fc
    70b3efb038b0:	ja     0x70b3efb05487
    70b3efb038b6:	movdqa xmm14,xmm1
    70b3efb038bb:	psrldq xmm14,0x8
    70b3efb038c1:	movq   rax,xmm14
    70b3efb038c6:	add    rax,rax
    70b3efb038c9:	je     0x70b3efb038df
    70b3efb038cb:	shr    rax,0x35
    70b3efb038cf:	sub    eax,0x201
    70b3efb038d4:	cmp    eax,0x3fc
    70b3efb038d9:	ja     0x70b3efb05487
    70b3efb038df:	addpd  xmm0,xmm1
    70b3efb038e3:	movdqa xmm5,xmm0
    70b3efb038e7:	movdqa xmm0,xmm5
    70b3efb038eb:	movdqu XMMWORD PTR [r12+0x160],xmm0
    70b3efb038f5:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    70b3efb038ff:	movdqa xmm2,xmm0
    70b3efb03903:	movdqa xmm0,xmm2
    70b3efb03907:	movdqa xmm1,xmm3
    70b3efb0390b:	pshufd xmm1,xmm1,0x44
    70b3efb03910:	movq   rax,xmm0
    70b3efb03915:	add    rax,rax
    70b3efb03918:	je     0x70b3efb0392e
    70b3efb0391a:	shr    rax,0x35
    70b3efb0391e:	sub    eax,0x201
    70b3efb03923:	cmp    eax,0x3fc
    70b3efb03928:	ja     0x70b3efb054ab
    70b3efb0392e:	movdqa xmm14,xmm0
    70b3efb03933:	psrldq xmm14,0x8
    70b3efb03939:	movq   rax,xmm14
    70b3efb0393e:	add    rax,rax
    70b3efb03941:	je     0x70b3efb03957
    70b3efb03943:	shr    rax,0x35
    70b3efb03947:	sub    eax,0x201
    70b3efb0394c:	cmp    eax,0x3fc
    70b3efb03951:	ja     0x70b3efb054ab
    70b3efb03957:	movq   rax,xmm1
    70b3efb0395c:	add    rax,rax
    70b3efb0395f:	je     0x70b3efb03975
    70b3efb03961:	shr    rax,0x35
    70b3efb03965:	sub    eax,0x201
    70b3efb0396a:	cmp    eax,0x3fc
    70b3efb0396f:	ja     0x70b3efb054ab
    70b3efb03975:	movdqa xmm14,xmm1
    70b3efb0397a:	psrldq xmm14,0x8
    70b3efb03980:	movq   rax,xmm14
    70b3efb03985:	add    rax,rax
    70b3efb03988:	je     0x70b3efb0399e
    70b3efb0398a:	shr    rax,0x35
    70b3efb0398e:	sub    eax,0x201
    70b3efb03993:	cmp    eax,0x3fc
    70b3efb03998:	ja     0x70b3efb054ab
    70b3efb0399e:	mulpd  xmm0,xmm1
    70b3efb039a2:	movdqa xmm4,xmm0
    70b3efb039a6:	movdqa xmm0,xmm4
    70b3efb039aa:	movdqu XMMWORD PTR [r12+0x240],xmm0
    70b3efb039b4:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    70b3efb039be:	movdqa xmm2,xmm0
    70b3efb039c2:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    70b3efb039cc:	movdqa xmm3,xmm0
    70b3efb039d0:	movdqa xmm0,xmm2
    70b3efb039d4:	movdqa xmm1,xmm3
    70b3efb039d8:	pshufd xmm1,xmm1,0x44
    70b3efb039dd:	movq   rax,xmm0
    70b3efb039e2:	add    rax,rax
    70b3efb039e5:	je     0x70b3efb039fb
    70b3efb039e7:	shr    rax,0x35
    70b3efb039eb:	sub    eax,0x201
    70b3efb039f0:	cmp    eax,0x3fc
    70b3efb039f5:	ja     0x70b3efb054cf
    70b3efb039fb:	movdqa xmm14,xmm0
    70b3efb03a00:	psrldq xmm14,0x8
    70b3efb03a06:	movq   rax,xmm14
    70b3efb03a0b:	add    rax,rax
    70b3efb03a0e:	je     0x70b3efb03a24
    70b3efb03a10:	shr    rax,0x35
    70b3efb03a14:	sub    eax,0x201
    70b3efb03a19:	cmp    eax,0x3fc
    70b3efb03a1e:	ja     0x70b3efb054cf
    70b3efb03a24:	movq   rax,xmm1
    70b3efb03a29:	add    rax,rax
    70b3efb03a2c:	je     0x70b3efb03a42
    70b3efb03a2e:	shr    rax,0x35
    70b3efb03a32:	sub    eax,0x201
    70b3efb03a37:	cmp    eax,0x3fc
    70b3efb03a3c:	ja     0x70b3efb054cf
    70b3efb03a42:	movdqa xmm14,xmm1
    70b3efb03a47:	psrldq xmm14,0x8
    70b3efb03a4d:	movq   rax,xmm14
    70b3efb03a52:	add    rax,rax
    70b3efb03a55:	je     0x70b3efb03a6b
    70b3efb03a57:	shr    rax,0x35
    70b3efb03a5b:	sub    eax,0x201
    70b3efb03a60:	cmp    eax,0x3fc
    70b3efb03a65:	ja     0x70b3efb054cf
    70b3efb03a6b:	mulpd  xmm0,xmm1
    70b3efb03a6f:	movdqa xmm4,xmm0
    70b3efb03a73:	movdqa xmm0,xmm4
    70b3efb03a77:	movdqu XMMWORD PTR [r12+0x140],xmm0
    70b3efb03a81:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    70b3efb03a8b:	movdqa xmm2,xmm0
    70b3efb03a8f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    70b3efb03a99:	movdqa xmm3,xmm0
    70b3efb03a9d:	movdqa xmm0,xmm2
    70b3efb03aa1:	movdqa xmm1,xmm3
    70b3efb03aa5:	pshufd xmm1,xmm1,0x44
    70b3efb03aaa:	movq   rax,xmm0
    70b3efb03aaf:	add    rax,rax
    70b3efb03ab2:	je     0x70b3efb03ac8
    70b3efb03ab4:	shr    rax,0x35
    70b3efb03ab8:	sub    eax,0x201
    70b3efb03abd:	cmp    eax,0x3fc
    70b3efb03ac2:	ja     0x70b3efb054f3
    70b3efb03ac8:	movdqa xmm14,xmm0
    70b3efb03acd:	psrldq xmm14,0x8
    70b3efb03ad3:	movq   rax,xmm14
    70b3efb03ad8:	add    rax,rax
    70b3efb03adb:	je     0x70b3efb03af1
    70b3efb03add:	shr    rax,0x35
    70b3efb03ae1:	sub    eax,0x201
    70b3efb03ae6:	cmp    eax,0x3fc
    70b3efb03aeb:	ja     0x70b3efb054f3
    70b3efb03af1:	movq   rax,xmm1
    70b3efb03af6:	add    rax,rax
    70b3efb03af9:	je     0x70b3efb03b0f
    70b3efb03afb:	shr    rax,0x35
    70b3efb03aff:	sub    eax,0x201
    70b3efb03b04:	cmp    eax,0x3fc
    70b3efb03b09:	ja     0x70b3efb054f3
    70b3efb03b0f:	movdqa xmm14,xmm1
    70b3efb03b14:	psrldq xmm14,0x8
    70b3efb03b1a:	movq   rax,xmm14
    70b3efb03b1f:	add    rax,rax
    70b3efb03b22:	je     0x70b3efb03b38
    70b3efb03b24:	shr    rax,0x35
    70b3efb03b28:	sub    eax,0x201
    70b3efb03b2d:	cmp    eax,0x3fc
    70b3efb03b32:	ja     0x70b3efb054f3
    70b3efb03b38:	mulpd  xmm0,xmm1
    70b3efb03b3c:	movdqa xmm4,xmm0
    70b3efb03b40:	movdqa xmm0,xmm4
    70b3efb03b44:	movdqu XMMWORD PTR [r12+0x170],xmm0
    70b3efb03b4e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb03b58:	movdqa xmm2,xmm0
    70b3efb03b5c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb03b66:	movdqa xmm4,xmm0
    70b3efb03b6a:	movdqa xmm0,xmm2
    70b3efb03b6e:	movdqa xmm1,xmm4
    70b3efb03b72:	movq   rax,xmm0
    70b3efb03b77:	add    rax,rax
    70b3efb03b7a:	je     0x70b3efb03b90
    70b3efb03b7c:	shr    rax,0x35
    70b3efb03b80:	sub    eax,0x201
    70b3efb03b85:	cmp    eax,0x3fc
    70b3efb03b8a:	ja     0x70b3efb05517
    70b3efb03b90:	movdqa xmm14,xmm0
    70b3efb03b95:	psrldq xmm14,0x8
    70b3efb03b9b:	movq   rax,xmm14
    70b3efb03ba0:	add    rax,rax
    70b3efb03ba3:	je     0x70b3efb03bb9
    70b3efb03ba5:	shr    rax,0x35
    70b3efb03ba9:	sub    eax,0x201
    70b3efb03bae:	cmp    eax,0x3fc
    70b3efb03bb3:	ja     0x70b3efb05517
    70b3efb03bb9:	movq   rax,xmm1
    70b3efb03bbe:	add    rax,rax
    70b3efb03bc1:	je     0x70b3efb03bd7
    70b3efb03bc3:	shr    rax,0x35
    70b3efb03bc7:	sub    eax,0x201
    70b3efb03bcc:	cmp    eax,0x3fc
    70b3efb03bd1:	ja     0x70b3efb05517
    70b3efb03bd7:	movdqa xmm14,xmm1
    70b3efb03bdc:	psrldq xmm14,0x8
    70b3efb03be2:	movq   rax,xmm14
    70b3efb03be7:	add    rax,rax
    70b3efb03bea:	je     0x70b3efb03c00
    70b3efb03bec:	shr    rax,0x35
    70b3efb03bf0:	sub    eax,0x201
    70b3efb03bf5:	cmp    eax,0x3fc
    70b3efb03bfa:	ja     0x70b3efb05517
    70b3efb03c00:	addpd  xmm0,xmm1
    70b3efb03c04:	movdqa xmm5,xmm0
    70b3efb03c08:	movdqa xmm0,xmm5
    70b3efb03c0c:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb03c16:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    70b3efb03c20:	movdqa xmm2,xmm0
    70b3efb03c24:	movdqa xmm0,xmm2
    70b3efb03c28:	movdqa xmm1,xmm3
    70b3efb03c2c:	pshufd xmm1,xmm1,0x44
    70b3efb03c31:	movq   rax,xmm0
    70b3efb03c36:	add    rax,rax
    70b3efb03c39:	je     0x70b3efb03c4f
    70b3efb03c3b:	shr    rax,0x35
    70b3efb03c3f:	sub    eax,0x201
    70b3efb03c44:	cmp    eax,0x3fc
    70b3efb03c49:	ja     0x70b3efb0553b
    70b3efb03c4f:	movdqa xmm14,xmm0
    70b3efb03c54:	psrldq xmm14,0x8
    70b3efb03c5a:	movq   rax,xmm14
    70b3efb03c5f:	add    rax,rax
    70b3efb03c62:	je     0x70b3efb03c78
    70b3efb03c64:	shr    rax,0x35
    70b3efb03c68:	sub    eax,0x201
    70b3efb03c6d:	cmp    eax,0x3fc
    70b3efb03c72:	ja     0x70b3efb0553b
    70b3efb03c78:	movq   rax,xmm1
    70b3efb03c7d:	add    rax,rax
    70b3efb03c80:	je     0x70b3efb03c96
    70b3efb03c82:	shr    rax,0x35
    70b3efb03c86:	sub    eax,0x201
    70b3efb03c8b:	cmp    eax,0x3fc
    70b3efb03c90:	ja     0x70b3efb0553b
    70b3efb03c96:	movdqa xmm14,xmm1
    70b3efb03c9b:	psrldq xmm14,0x8
    70b3efb03ca1:	movq   rax,xmm14
    70b3efb03ca6:	add    rax,rax
    70b3efb03ca9:	je     0x70b3efb03cbf
    70b3efb03cab:	shr    rax,0x35
    70b3efb03caf:	sub    eax,0x201
    70b3efb03cb4:	cmp    eax,0x3fc
    70b3efb03cb9:	ja     0x70b3efb0553b
    70b3efb03cbf:	mulpd  xmm0,xmm1
    70b3efb03cc3:	movdqa xmm4,xmm0
    70b3efb03cc7:	movdqa xmm0,xmm4
    70b3efb03ccb:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb03cd5:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    70b3efb03cdf:	movdqa xmm2,xmm0
    70b3efb03ce3:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    70b3efb03ced:	movdqa xmm4,xmm0
    70b3efb03cf1:	movdqa xmm0,xmm2
    70b3efb03cf5:	movdqa xmm1,xmm4
    70b3efb03cf9:	movq   rax,xmm0
    70b3efb03cfe:	add    rax,rax
    70b3efb03d01:	je     0x70b3efb03d17
    70b3efb03d03:	shr    rax,0x35
    70b3efb03d07:	sub    eax,0x201
    70b3efb03d0c:	cmp    eax,0x3fc
    70b3efb03d11:	ja     0x70b3efb0555f
    70b3efb03d17:	movdqa xmm14,xmm0
    70b3efb03d1c:	psrldq xmm14,0x8
    70b3efb03d22:	movq   rax,xmm14
    70b3efb03d27:	add    rax,rax
    70b3efb03d2a:	je     0x70b3efb03d40
    70b3efb03d2c:	shr    rax,0x35
    70b3efb03d30:	sub    eax,0x201
    70b3efb03d35:	cmp    eax,0x3fc
    70b3efb03d3a:	ja     0x70b3efb0555f
    70b3efb03d40:	movq   rax,xmm1
    70b3efb03d45:	add    rax,rax
    70b3efb03d48:	je     0x70b3efb03d5e
    70b3efb03d4a:	shr    rax,0x35
    70b3efb03d4e:	sub    eax,0x201
    70b3efb03d53:	cmp    eax,0x3fc
    70b3efb03d58:	ja     0x70b3efb0555f
    70b3efb03d5e:	movdqa xmm14,xmm1
    70b3efb03d63:	psrldq xmm14,0x8
    70b3efb03d69:	movq   rax,xmm14
    70b3efb03d6e:	add    rax,rax
    70b3efb03d71:	je     0x70b3efb03d87
    70b3efb03d73:	shr    rax,0x35
    70b3efb03d77:	sub    eax,0x201
    70b3efb03d7c:	cmp    eax,0x3fc
    70b3efb03d81:	ja     0x70b3efb0555f
    70b3efb03d87:	addpd  xmm0,xmm1
    70b3efb03d8b:	movdqa xmm5,xmm0
    70b3efb03d8f:	movdqa xmm0,xmm5
    70b3efb03d93:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb03d9d:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    70b3efb03da7:	movdqa xmm2,xmm0
    70b3efb03dab:	movdqa xmm0,xmm2
    70b3efb03daf:	movdqa xmm1,xmm3
    70b3efb03db3:	pshufd xmm1,xmm1,0x44
    70b3efb03db8:	movq   rax,xmm0
    70b3efb03dbd:	add    rax,rax
    70b3efb03dc0:	je     0x70b3efb03dd6
    70b3efb03dc2:	shr    rax,0x35
    70b3efb03dc6:	sub    eax,0x201
    70b3efb03dcb:	cmp    eax,0x3fc
    70b3efb03dd0:	ja     0x70b3efb05583
    70b3efb03dd6:	movdqa xmm14,xmm0
    70b3efb03ddb:	psrldq xmm14,0x8
    70b3efb03de1:	movq   rax,xmm14
    70b3efb03de6:	add    rax,rax
    70b3efb03de9:	je     0x70b3efb03dff
    70b3efb03deb:	shr    rax,0x35
    70b3efb03def:	sub    eax,0x201
    70b3efb03df4:	cmp    eax,0x3fc
    70b3efb03df9:	ja     0x70b3efb05583
    70b3efb03dff:	movq   rax,xmm1
    70b3efb03e04:	add    rax,rax
    70b3efb03e07:	je     0x70b3efb03e1d
    70b3efb03e09:	shr    rax,0x35
    70b3efb03e0d:	sub    eax,0x201
    70b3efb03e12:	cmp    eax,0x3fc
    70b3efb03e17:	ja     0x70b3efb05583
    70b3efb03e1d:	movdqa xmm14,xmm1
    70b3efb03e22:	psrldq xmm14,0x8
    70b3efb03e28:	movq   rax,xmm14
    70b3efb03e2d:	add    rax,rax
    70b3efb03e30:	je     0x70b3efb03e46
    70b3efb03e32:	shr    rax,0x35
    70b3efb03e36:	sub    eax,0x201
    70b3efb03e3b:	cmp    eax,0x3fc
    70b3efb03e40:	ja     0x70b3efb05583
    70b3efb03e46:	mulpd  xmm0,xmm1
    70b3efb03e4a:	movdqa xmm4,xmm0
    70b3efb03e4e:	movdqa xmm0,xmm4
    70b3efb03e52:	movdqu XMMWORD PTR [r12+0x230],xmm0
    70b3efb03e5c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    70b3efb03e66:	movdqa xmm2,xmm0
    70b3efb03e6a:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    70b3efb03e74:	movdqa xmm3,xmm0
    70b3efb03e78:	movdqa xmm0,xmm2
    70b3efb03e7c:	movdqa xmm1,xmm3
    70b3efb03e80:	movq   rax,xmm0
    70b3efb03e85:	add    rax,rax
    70b3efb03e88:	je     0x70b3efb03e9e
    70b3efb03e8a:	shr    rax,0x35
    70b3efb03e8e:	sub    eax,0x201
    70b3efb03e93:	cmp    eax,0x3fc
    70b3efb03e98:	ja     0x70b3efb055a7
    70b3efb03e9e:	movdqa xmm14,xmm0
    70b3efb03ea3:	psrldq xmm14,0x8
    70b3efb03ea9:	movq   rax,xmm14
    70b3efb03eae:	add    rax,rax
    70b3efb03eb1:	je     0x70b3efb03ec7
    70b3efb03eb3:	shr    rax,0x35
    70b3efb03eb7:	sub    eax,0x201
    70b3efb03ebc:	cmp    eax,0x3fc
    70b3efb03ec1:	ja     0x70b3efb055a7
    70b3efb03ec7:	movq   rax,xmm1
    70b3efb03ecc:	add    rax,rax
    70b3efb03ecf:	je     0x70b3efb03ee5
    70b3efb03ed1:	shr    rax,0x35
    70b3efb03ed5:	sub    eax,0x201
    70b3efb03eda:	cmp    eax,0x3fc
    70b3efb03edf:	ja     0x70b3efb055a7
    70b3efb03ee5:	movdqa xmm14,xmm1
    70b3efb03eea:	psrldq xmm14,0x8
    70b3efb03ef0:	movq   rax,xmm14
    70b3efb03ef5:	add    rax,rax
    70b3efb03ef8:	je     0x70b3efb03f0e
    70b3efb03efa:	shr    rax,0x35
    70b3efb03efe:	sub    eax,0x201
    70b3efb03f03:	cmp    eax,0x3fc
    70b3efb03f08:	ja     0x70b3efb055a7
    70b3efb03f0e:	addpd  xmm0,xmm1
    70b3efb03f12:	movdqa xmm4,xmm0
    70b3efb03f16:	movdqa xmm0,xmm4
    70b3efb03f1a:	movdqu XMMWORD PTR [r12+0x140],xmm0
    70b3efb03f24:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    70b3efb03f2e:	movdqa xmm2,xmm0
    70b3efb03f32:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    70b3efb03f3c:	movdqa xmm3,xmm0
    70b3efb03f40:	movdqa xmm0,xmm2
    70b3efb03f44:	movdqa xmm1,xmm3
    70b3efb03f48:	pshufd xmm1,xmm1,0x44
    70b3efb03f4d:	movq   rax,xmm0
    70b3efb03f52:	add    rax,rax
    70b3efb03f55:	je     0x70b3efb03f6b
    70b3efb03f57:	shr    rax,0x35
    70b3efb03f5b:	sub    eax,0x201
    70b3efb03f60:	cmp    eax,0x3fc
    70b3efb03f65:	ja     0x70b3efb055cb
    70b3efb03f6b:	movdqa xmm14,xmm0
    70b3efb03f70:	psrldq xmm14,0x8
    70b3efb03f76:	movq   rax,xmm14
    70b3efb03f7b:	add    rax,rax
    70b3efb03f7e:	je     0x70b3efb03f94
    70b3efb03f80:	shr    rax,0x35
    70b3efb03f84:	sub    eax,0x201
    70b3efb03f89:	cmp    eax,0x3fc
    70b3efb03f8e:	ja     0x70b3efb055cb
    70b3efb03f94:	movq   rax,xmm1
    70b3efb03f99:	add    rax,rax
    70b3efb03f9c:	je     0x70b3efb03fb2
    70b3efb03f9e:	shr    rax,0x35
    70b3efb03fa2:	sub    eax,0x201
    70b3efb03fa7:	cmp    eax,0x3fc
    70b3efb03fac:	ja     0x70b3efb055cb
    70b3efb03fb2:	movdqa xmm14,xmm1
    70b3efb03fb7:	psrldq xmm14,0x8
    70b3efb03fbd:	movq   rax,xmm14
    70b3efb03fc2:	add    rax,rax
    70b3efb03fc5:	je     0x70b3efb03fdb
    70b3efb03fc7:	shr    rax,0x35
    70b3efb03fcb:	sub    eax,0x201
    70b3efb03fd0:	cmp    eax,0x3fc
    70b3efb03fd5:	ja     0x70b3efb055cb
    70b3efb03fdb:	mulpd  xmm0,xmm1
    70b3efb03fdf:	movdqa xmm4,xmm0
    70b3efb03fe3:	movdqa xmm0,xmm4
    70b3efb03fe7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    70b3efb03ff1:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    70b3efb03ffb:	movdqa xmm2,xmm0
    70b3efb03fff:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb04009:	movdqa xmm3,xmm0
    70b3efb0400d:	movdqa xmm0,xmm2
    70b3efb04011:	movdqa xmm1,xmm3
    70b3efb04015:	movq   rax,xmm0
    70b3efb0401a:	add    rax,rax
    70b3efb0401d:	je     0x70b3efb04033
    70b3efb0401f:	shr    rax,0x35
    70b3efb04023:	sub    eax,0x201
    70b3efb04028:	cmp    eax,0x3fc
    70b3efb0402d:	ja     0x70b3efb055ef
    70b3efb04033:	movdqa xmm14,xmm0
    70b3efb04038:	psrldq xmm14,0x8
    70b3efb0403e:	movq   rax,xmm14
    70b3efb04043:	add    rax,rax
    70b3efb04046:	je     0x70b3efb0405c
    70b3efb04048:	shr    rax,0x35
    70b3efb0404c:	sub    eax,0x201
    70b3efb04051:	cmp    eax,0x3fc
    70b3efb04056:	ja     0x70b3efb055ef
    70b3efb0405c:	movq   rax,xmm1
    70b3efb04061:	add    rax,rax
    70b3efb04064:	je     0x70b3efb0407a
    70b3efb04066:	shr    rax,0x35
    70b3efb0406a:	sub    eax,0x201
    70b3efb0406f:	cmp    eax,0x3fc
    70b3efb04074:	ja     0x70b3efb055ef
    70b3efb0407a:	movdqa xmm14,xmm1
    70b3efb0407f:	psrldq xmm14,0x8
    70b3efb04085:	movq   rax,xmm14
    70b3efb0408a:	add    rax,rax
    70b3efb0408d:	je     0x70b3efb040a3
    70b3efb0408f:	shr    rax,0x35
    70b3efb04093:	sub    eax,0x201
    70b3efb04098:	cmp    eax,0x3fc
    70b3efb0409d:	ja     0x70b3efb055ef
    70b3efb040a3:	addpd  xmm0,xmm1
    70b3efb040a7:	movdqa xmm4,xmm0
    70b3efb040ab:	movdqa xmm0,xmm4
    70b3efb040af:	movdqu XMMWORD PTR [r12+0x150],xmm0
    70b3efb040b9:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb040c1:	mov    r14,r13
    70b3efb040c4:	add    r14,0x70
    70b3efb040c8:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb040d0:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb040d8:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb040e0:	shr    r11d,1
    70b3efb040e3:	and    r11d,0x10
    70b3efb040e7:	or     DWORD PTR [r12+0x314],r11d
    70b3efb040ef:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb040f4:	movdqa xmm0,xmm2
    70b3efb040f8:	movdqu XMMWORD PTR [r12+0x240],xmm0
    70b3efb04102:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb0410c:	movdqa xmm3,xmm0
    70b3efb04110:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb0411a:	movdqa xmm4,xmm0
    70b3efb0411e:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb04126:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb04131:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb04139:	movdqa xmm0,xmm3
    70b3efb0413d:	movdqa xmm1,xmm4
    70b3efb04141:	movq   rax,xmm0
    70b3efb04146:	add    rax,rax
    70b3efb04149:	je     0x70b3efb0415f
    70b3efb0414b:	shr    rax,0x35
    70b3efb0414f:	sub    eax,0x201
    70b3efb04154:	cmp    eax,0x3fc
    70b3efb04159:	ja     0x70b3efb05613
    70b3efb0415f:	movdqa xmm14,xmm0
    70b3efb04164:	psrldq xmm14,0x8
    70b3efb0416a:	movq   rax,xmm14
    70b3efb0416f:	add    rax,rax
    70b3efb04172:	je     0x70b3efb04188
    70b3efb04174:	shr    rax,0x35
    70b3efb04178:	sub    eax,0x201
    70b3efb0417d:	cmp    eax,0x3fc
    70b3efb04182:	ja     0x70b3efb05613
    70b3efb04188:	movq   rax,xmm1
    70b3efb0418d:	add    rax,rax
    70b3efb04190:	je     0x70b3efb041a6
    70b3efb04192:	shr    rax,0x35
    70b3efb04196:	sub    eax,0x201
    70b3efb0419b:	cmp    eax,0x3fc
    70b3efb041a0:	ja     0x70b3efb05613
    70b3efb041a6:	movdqa xmm14,xmm1
    70b3efb041ab:	psrldq xmm14,0x8
    70b3efb041b1:	movq   rax,xmm14
    70b3efb041b6:	add    rax,rax
    70b3efb041b9:	je     0x70b3efb041cf
    70b3efb041bb:	shr    rax,0x35
    70b3efb041bf:	sub    eax,0x201
    70b3efb041c4:	cmp    eax,0x3fc
    70b3efb041c9:	ja     0x70b3efb05613
    70b3efb041cf:	addpd  xmm0,xmm1
    70b3efb041d3:	movdqa xmm5,xmm0
    70b3efb041d7:	movdqa xmm0,xmm5
    70b3efb041db:	movdqu XMMWORD PTR [r12+0x170],xmm0
    70b3efb041e5:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    70b3efb041ef:	movdqa xmm3,xmm0
    70b3efb041f3:	movdqa xmm0,xmm2
    70b3efb041f7:	movdqa xmm1,xmm3
    70b3efb041fb:	pshufd xmm1,xmm1,0x44
    70b3efb04200:	movq   rax,xmm0
    70b3efb04205:	add    rax,rax
    70b3efb04208:	je     0x70b3efb0421e
    70b3efb0420a:	shr    rax,0x35
    70b3efb0420e:	sub    eax,0x201
    70b3efb04213:	cmp    eax,0x3fc
    70b3efb04218:	ja     0x70b3efb05637
    70b3efb0421e:	movdqa xmm14,xmm0
    70b3efb04223:	psrldq xmm14,0x8
    70b3efb04229:	movq   rax,xmm14
    70b3efb0422e:	add    rax,rax
    70b3efb04231:	je     0x70b3efb04247
    70b3efb04233:	shr    rax,0x35
    70b3efb04237:	sub    eax,0x201
    70b3efb0423c:	cmp    eax,0x3fc
    70b3efb04241:	ja     0x70b3efb05637
    70b3efb04247:	movq   rax,xmm1
    70b3efb0424c:	add    rax,rax
    70b3efb0424f:	je     0x70b3efb04265
    70b3efb04251:	shr    rax,0x35
    70b3efb04255:	sub    eax,0x201
    70b3efb0425a:	cmp    eax,0x3fc
    70b3efb0425f:	ja     0x70b3efb05637
    70b3efb04265:	movdqa xmm14,xmm1
    70b3efb0426a:	psrldq xmm14,0x8
    70b3efb04270:	movq   rax,xmm14
    70b3efb04275:	add    rax,rax
    70b3efb04278:	je     0x70b3efb0428e
    70b3efb0427a:	shr    rax,0x35
    70b3efb0427e:	sub    eax,0x201
    70b3efb04283:	cmp    eax,0x3fc
    70b3efb04288:	ja     0x70b3efb05637
    70b3efb0428e:	mulpd  xmm0,xmm1
    70b3efb04292:	movdqa xmm4,xmm0
    70b3efb04296:	movdqa xmm0,xmm4
    70b3efb0429a:	movdqu XMMWORD PTR [r12+0x160],xmm0
    70b3efb042a4:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    70b3efb042ae:	movdqa xmm2,xmm0
    70b3efb042b2:	movdqa xmm0,xmm2
    70b3efb042b6:	movdqa xmm1,xmm3
    70b3efb042ba:	pshufd xmm1,xmm1,0x44
    70b3efb042bf:	movq   rax,xmm0
    70b3efb042c4:	add    rax,rax
    70b3efb042c7:	je     0x70b3efb042dd
    70b3efb042c9:	shr    rax,0x35
    70b3efb042cd:	sub    eax,0x201
    70b3efb042d2:	cmp    eax,0x3fc
    70b3efb042d7:	ja     0x70b3efb0565b
    70b3efb042dd:	movdqa xmm14,xmm0
    70b3efb042e2:	psrldq xmm14,0x8
    70b3efb042e8:	movq   rax,xmm14
    70b3efb042ed:	add    rax,rax
    70b3efb042f0:	je     0x70b3efb04306
    70b3efb042f2:	shr    rax,0x35
    70b3efb042f6:	sub    eax,0x201
    70b3efb042fb:	cmp    eax,0x3fc
    70b3efb04300:	ja     0x70b3efb0565b
    70b3efb04306:	movq   rax,xmm1
    70b3efb0430b:	add    rax,rax
    70b3efb0430e:	je     0x70b3efb04324
    70b3efb04310:	shr    rax,0x35
    70b3efb04314:	sub    eax,0x201
    70b3efb04319:	cmp    eax,0x3fc
    70b3efb0431e:	ja     0x70b3efb0565b
    70b3efb04324:	movdqa xmm14,xmm1
    70b3efb04329:	psrldq xmm14,0x8
    70b3efb0432f:	movq   rax,xmm14
    70b3efb04334:	add    rax,rax
    70b3efb04337:	je     0x70b3efb0434d
    70b3efb04339:	shr    rax,0x35
    70b3efb0433d:	sub    eax,0x201
    70b3efb04342:	cmp    eax,0x3fc
    70b3efb04347:	ja     0x70b3efb0565b
    70b3efb0434d:	mulpd  xmm0,xmm1
    70b3efb04351:	movdqa xmm4,xmm0
    70b3efb04355:	movdqa xmm0,xmm4
    70b3efb04359:	movdqu XMMWORD PTR [r12+0x180],xmm0
    70b3efb04363:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb0436d:	movdqa xmm2,xmm0
    70b3efb04371:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    70b3efb0437b:	movdqa xmm4,xmm0
    70b3efb0437f:	movdqa xmm0,xmm2
    70b3efb04383:	movdqa xmm1,xmm4
    70b3efb04387:	movq   rax,xmm0
    70b3efb0438c:	add    rax,rax
    70b3efb0438f:	je     0x70b3efb043a5
    70b3efb04391:	shr    rax,0x35
    70b3efb04395:	sub    eax,0x201
    70b3efb0439a:	cmp    eax,0x3fc
    70b3efb0439f:	ja     0x70b3efb0567f
    70b3efb043a5:	movdqa xmm14,xmm0
    70b3efb043aa:	psrldq xmm14,0x8
    70b3efb043b0:	movq   rax,xmm14
    70b3efb043b5:	add    rax,rax
    70b3efb043b8:	je     0x70b3efb043ce
    70b3efb043ba:	shr    rax,0x35
    70b3efb043be:	sub    eax,0x201
    70b3efb043c3:	cmp    eax,0x3fc
    70b3efb043c8:	ja     0x70b3efb0567f
    70b3efb043ce:	movq   rax,xmm1
    70b3efb043d3:	add    rax,rax
    70b3efb043d6:	je     0x70b3efb043ec
    70b3efb043d8:	shr    rax,0x35
    70b3efb043dc:	sub    eax,0x201
    70b3efb043e1:	cmp    eax,0x3fc
    70b3efb043e6:	ja     0x70b3efb0567f
    70b3efb043ec:	movdqa xmm14,xmm1
    70b3efb043f1:	psrldq xmm14,0x8
    70b3efb043f7:	movq   rax,xmm14
    70b3efb043fc:	add    rax,rax
    70b3efb043ff:	je     0x70b3efb04415
    70b3efb04401:	shr    rax,0x35
    70b3efb04405:	sub    eax,0x201
    70b3efb0440a:	cmp    eax,0x3fc
    70b3efb0440f:	ja     0x70b3efb0567f
    70b3efb04415:	addpd  xmm0,xmm1
    70b3efb04419:	movdqa xmm5,xmm0
    70b3efb0441d:	movdqa xmm0,xmm5
    70b3efb04421:	movdqu XMMWORD PTR [r12+0x210],xmm0
    70b3efb0442b:	mov    r14,r13
    70b3efb0442e:	add    r14,0x10
    70b3efb04432:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb0443a:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb04442:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb0444a:	shr    r11d,1
    70b3efb0444d:	and    r11d,0x10
    70b3efb04451:	or     DWORD PTR [r12+0x314],r11d
    70b3efb04459:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    70b3efb0445f:	movdqu xmm4,XMMWORD PTR [r14]
    70b3efb04464:	movdqa xmm0,xmm4
    70b3efb04468:	movdqu XMMWORD PTR [r12+0x230],xmm0
    70b3efb04472:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    70b3efb0447c:	movdqa xmm5,xmm0
    70b3efb04480:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    70b3efb0448a:	movdqa xmm6,xmm0
    70b3efb0448e:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb04496:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb044a1:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb044a9:	movdqa xmm0,xmm5
    70b3efb044ad:	movdqa xmm1,xmm6
    70b3efb044b1:	movq   rax,xmm0
    70b3efb044b6:	add    rax,rax
    70b3efb044b9:	je     0x70b3efb044cf
    70b3efb044bb:	shr    rax,0x35
    70b3efb044bf:	sub    eax,0x201
    70b3efb044c4:	cmp    eax,0x3fc
    70b3efb044c9:	ja     0x70b3efb056a3
    70b3efb044cf:	movdqa xmm14,xmm0
    70b3efb044d4:	psrldq xmm14,0x8
    70b3efb044da:	movq   rax,xmm14
    70b3efb044df:	add    rax,rax
    70b3efb044e2:	je     0x70b3efb044f8
    70b3efb044e4:	shr    rax,0x35
    70b3efb044e8:	sub    eax,0x201
    70b3efb044ed:	cmp    eax,0x3fc
    70b3efb044f2:	ja     0x70b3efb056a3
    70b3efb044f8:	movq   rax,xmm1
    70b3efb044fd:	add    rax,rax
    70b3efb04500:	je     0x70b3efb04516
    70b3efb04502:	shr    rax,0x35
    70b3efb04506:	sub    eax,0x201
    70b3efb0450b:	cmp    eax,0x3fc
    70b3efb04510:	ja     0x70b3efb056a3
    70b3efb04516:	movdqa xmm14,xmm1
    70b3efb0451b:	psrldq xmm14,0x8
    70b3efb04521:	movq   rax,xmm14
    70b3efb04526:	add    rax,rax
    70b3efb04529:	je     0x70b3efb0453f
    70b3efb0452b:	shr    rax,0x35
    70b3efb0452f:	sub    eax,0x201
    70b3efb04534:	cmp    eax,0x3fc
    70b3efb04539:	ja     0x70b3efb056a3
    70b3efb0453f:	addpd  xmm0,xmm1
    70b3efb04543:	movdqa xmm7,xmm0
    70b3efb04547:	movdqa xmm0,xmm7
    70b3efb0454b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    70b3efb04555:	movdqa xmm0,xmm4
    70b3efb04559:	movdqa xmm1,xmm3
    70b3efb0455d:	pshufd xmm1,xmm1,0x44
    70b3efb04562:	movq   rax,xmm0
    70b3efb04567:	add    rax,rax
    70b3efb0456a:	je     0x70b3efb04580
    70b3efb0456c:	shr    rax,0x35
    70b3efb04570:	sub    eax,0x201
    70b3efb04575:	cmp    eax,0x3fc
    70b3efb0457a:	ja     0x70b3efb056c7
    70b3efb04580:	movdqa xmm14,xmm0
    70b3efb04585:	psrldq xmm14,0x8
    70b3efb0458b:	movq   rax,xmm14
    70b3efb04590:	add    rax,rax
    70b3efb04593:	je     0x70b3efb045a9
    70b3efb04595:	shr    rax,0x35
    70b3efb04599:	sub    eax,0x201
    70b3efb0459e:	cmp    eax,0x3fc
    70b3efb045a3:	ja     0x70b3efb056c7
    70b3efb045a9:	movq   rax,xmm1
    70b3efb045ae:	add    rax,rax
    70b3efb045b1:	je     0x70b3efb045c7
    70b3efb045b3:	shr    rax,0x35
    70b3efb045b7:	sub    eax,0x201
    70b3efb045bc:	cmp    eax,0x3fc
    70b3efb045c1:	ja     0x70b3efb056c7
    70b3efb045c7:	movdqa xmm14,xmm1
    70b3efb045cc:	psrldq xmm14,0x8
    70b3efb045d2:	movq   rax,xmm14
    70b3efb045d7:	add    rax,rax
    70b3efb045da:	je     0x70b3efb045f0
    70b3efb045dc:	shr    rax,0x35
    70b3efb045e0:	sub    eax,0x201
    70b3efb045e5:	cmp    eax,0x3fc
    70b3efb045ea:	ja     0x70b3efb056c7
    70b3efb045f0:	mulpd  xmm0,xmm1
    70b3efb045f4:	movdqa xmm5,xmm0
    70b3efb045f8:	movdqa xmm0,xmm5
    70b3efb045fc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    70b3efb04606:	movdqa xmm0,xmm2
    70b3efb0460a:	movdqa xmm1,xmm3
    70b3efb0460e:	pshufd xmm1,xmm1,0x44
    70b3efb04613:	movq   rax,xmm0
    70b3efb04618:	add    rax,rax
    70b3efb0461b:	je     0x70b3efb04631
    70b3efb0461d:	shr    rax,0x35
    70b3efb04621:	sub    eax,0x201
    70b3efb04626:	cmp    eax,0x3fc
    70b3efb0462b:	ja     0x70b3efb056eb
    70b3efb04631:	movdqa xmm14,xmm0
    70b3efb04636:	psrldq xmm14,0x8
    70b3efb0463c:	movq   rax,xmm14
    70b3efb04641:	add    rax,rax
    70b3efb04644:	je     0x70b3efb0465a
    70b3efb04646:	shr    rax,0x35
    70b3efb0464a:	sub    eax,0x201
    70b3efb0464f:	cmp    eax,0x3fc
    70b3efb04654:	ja     0x70b3efb056eb
    70b3efb0465a:	movq   rax,xmm1
    70b3efb0465f:	add    rax,rax
    70b3efb04662:	je     0x70b3efb04678
    70b3efb04664:	shr    rax,0x35
    70b3efb04668:	sub    eax,0x201
    70b3efb0466d:	cmp    eax,0x3fc
    70b3efb04672:	ja     0x70b3efb056eb
    70b3efb04678:	movdqa xmm14,xmm1
    70b3efb0467d:	psrldq xmm14,0x8
    70b3efb04683:	movq   rax,xmm14
    70b3efb04688:	add    rax,rax
    70b3efb0468b:	je     0x70b3efb046a1
    70b3efb0468d:	shr    rax,0x35
    70b3efb04691:	sub    eax,0x201
    70b3efb04696:	cmp    eax,0x3fc
    70b3efb0469b:	ja     0x70b3efb056eb
    70b3efb046a1:	mulpd  xmm0,xmm1
    70b3efb046a5:	movdqa xmm4,xmm0
    70b3efb046a9:	movdqa xmm0,xmm4
    70b3efb046ad:	movdqu XMMWORD PTR [r12+0x120],xmm0
    70b3efb046b7:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    70b3efb046c1:	movdqa xmm2,xmm0
    70b3efb046c5:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    70b3efb046cf:	movdqa xmm3,xmm0
    70b3efb046d3:	movdqa xmm0,xmm2
    70b3efb046d7:	movdqa xmm1,xmm3
    70b3efb046db:	movq   rax,xmm0
    70b3efb046e0:	add    rax,rax
    70b3efb046e3:	je     0x70b3efb046f9
    70b3efb046e5:	shr    rax,0x35
    70b3efb046e9:	sub    eax,0x201
    70b3efb046ee:	cmp    eax,0x3fc
    70b3efb046f3:	ja     0x70b3efb0570f
    70b3efb046f9:	movdqa xmm14,xmm0
    70b3efb046fe:	psrldq xmm14,0x8
    70b3efb04704:	movq   rax,xmm14
    70b3efb04709:	add    rax,rax
    70b3efb0470c:	je     0x70b3efb04722
    70b3efb0470e:	shr    rax,0x35
    70b3efb04712:	sub    eax,0x201
    70b3efb04717:	cmp    eax,0x3fc
    70b3efb0471c:	ja     0x70b3efb0570f
    70b3efb04722:	movq   rax,xmm1
    70b3efb04727:	add    rax,rax
    70b3efb0472a:	je     0x70b3efb04740
    70b3efb0472c:	shr    rax,0x35
    70b3efb04730:	sub    eax,0x201
    70b3efb04735:	cmp    eax,0x3fc
    70b3efb0473a:	ja     0x70b3efb0570f
    70b3efb04740:	movdqa xmm14,xmm1
    70b3efb04745:	psrldq xmm14,0x8
    70b3efb0474b:	movq   rax,xmm14
    70b3efb04750:	add    rax,rax
    70b3efb04753:	je     0x70b3efb04769
    70b3efb04755:	shr    rax,0x35
    70b3efb04759:	sub    eax,0x201
    70b3efb0475e:	cmp    eax,0x3fc
    70b3efb04763:	ja     0x70b3efb0570f
    70b3efb04769:	addpd  xmm0,xmm1
    70b3efb0476d:	movdqa xmm4,xmm0
    70b3efb04771:	movdqa xmm0,xmm4
    70b3efb04775:	movdqu XMMWORD PTR [r12+0x140],xmm0
    70b3efb0477f:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    70b3efb04789:	movdqa xmm2,xmm0
    70b3efb0478d:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    70b3efb04797:	movdqa xmm3,xmm0
    70b3efb0479b:	movdqa xmm0,xmm2
    70b3efb0479f:	movdqa xmm1,xmm3
    70b3efb047a3:	movq   rax,xmm0
    70b3efb047a8:	add    rax,rax
    70b3efb047ab:	je     0x70b3efb047c1
    70b3efb047ad:	shr    rax,0x35
    70b3efb047b1:	sub    eax,0x201
    70b3efb047b6:	cmp    eax,0x3fc
    70b3efb047bb:	ja     0x70b3efb05733
    70b3efb047c1:	movdqa xmm14,xmm0
    70b3efb047c6:	psrldq xmm14,0x8
    70b3efb047cc:	movq   rax,xmm14
    70b3efb047d1:	add    rax,rax
    70b3efb047d4:	je     0x70b3efb047ea
    70b3efb047d6:	shr    rax,0x35
    70b3efb047da:	sub    eax,0x201
    70b3efb047df:	cmp    eax,0x3fc
    70b3efb047e4:	ja     0x70b3efb05733
    70b3efb047ea:	movq   rax,xmm1
    70b3efb047ef:	add    rax,rax
    70b3efb047f2:	je     0x70b3efb04808
    70b3efb047f4:	shr    rax,0x35
    70b3efb047f8:	sub    eax,0x201
    70b3efb047fd:	cmp    eax,0x3fc
    70b3efb04802:	ja     0x70b3efb05733
    70b3efb04808:	movdqa xmm14,xmm1
    70b3efb0480d:	psrldq xmm14,0x8
    70b3efb04813:	movq   rax,xmm14
    70b3efb04818:	add    rax,rax
    70b3efb0481b:	je     0x70b3efb04831
    70b3efb0481d:	shr    rax,0x35
    70b3efb04821:	sub    eax,0x201
    70b3efb04826:	cmp    eax,0x3fc
    70b3efb0482b:	ja     0x70b3efb05733
    70b3efb04831:	addpd  xmm0,xmm1
    70b3efb04835:	movdqa xmm4,xmm0
    70b3efb04839:	movdqa xmm0,xmm4
    70b3efb0483d:	movdqu XMMWORD PTR [r12+0x150],xmm0
    70b3efb04847:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    70b3efb04851:	movdqa xmm2,xmm0
    70b3efb04855:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    70b3efb0485f:	movdqa xmm3,xmm0
    70b3efb04863:	movdqa xmm0,xmm2
    70b3efb04867:	movdqa xmm1,xmm3
    70b3efb0486b:	movq   rax,xmm0
    70b3efb04870:	add    rax,rax
    70b3efb04873:	je     0x70b3efb04889
    70b3efb04875:	shr    rax,0x35
    70b3efb04879:	sub    eax,0x201
    70b3efb0487e:	cmp    eax,0x3fc
    70b3efb04883:	ja     0x70b3efb05757
    70b3efb04889:	movdqa xmm14,xmm0
    70b3efb0488e:	psrldq xmm14,0x8
    70b3efb04894:	movq   rax,xmm14
    70b3efb04899:	add    rax,rax
    70b3efb0489c:	je     0x70b3efb048b2
    70b3efb0489e:	shr    rax,0x35
    70b3efb048a2:	sub    eax,0x201
    70b3efb048a7:	cmp    eax,0x3fc
    70b3efb048ac:	ja     0x70b3efb05757
    70b3efb048b2:	movq   rax,xmm1
    70b3efb048b7:	add    rax,rax
    70b3efb048ba:	je     0x70b3efb048d0
    70b3efb048bc:	shr    rax,0x35
    70b3efb048c0:	sub    eax,0x201
    70b3efb048c5:	cmp    eax,0x3fc
    70b3efb048ca:	ja     0x70b3efb05757
    70b3efb048d0:	movdqa xmm14,xmm1
    70b3efb048d5:	psrldq xmm14,0x8
    70b3efb048db:	movq   rax,xmm14
    70b3efb048e0:	add    rax,rax
    70b3efb048e3:	je     0x70b3efb048f9
    70b3efb048e5:	shr    rax,0x35
    70b3efb048e9:	sub    eax,0x201
    70b3efb048ee:	cmp    eax,0x3fc
    70b3efb048f3:	ja     0x70b3efb05757
    70b3efb048f9:	addpd  xmm0,xmm1
    70b3efb048fd:	movdqa xmm4,xmm0
    70b3efb04901:	movdqa xmm0,xmm4
    70b3efb04905:	movdqu XMMWORD PTR [r12+0x160],xmm0
    70b3efb0490f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    70b3efb04919:	movdqa xmm2,xmm0
    70b3efb0491d:	movdqa xmm0,xmm7
    70b3efb04921:	movdqa xmm1,xmm2
    70b3efb04925:	movq   rax,xmm0
    70b3efb0492a:	add    rax,rax
    70b3efb0492d:	je     0x70b3efb04943
    70b3efb0492f:	shr    rax,0x35
    70b3efb04933:	sub    eax,0x201
    70b3efb04938:	cmp    eax,0x3fc
    70b3efb0493d:	ja     0x70b3efb0577b
    70b3efb04943:	movdqa xmm14,xmm0
    70b3efb04948:	psrldq xmm14,0x8
    70b3efb0494e:	movq   rax,xmm14
    70b3efb04953:	add    rax,rax
    70b3efb04956:	je     0x70b3efb0496c
    70b3efb04958:	shr    rax,0x35
    70b3efb0495c:	sub    eax,0x201
    70b3efb04961:	cmp    eax,0x3fc
    70b3efb04966:	ja     0x70b3efb0577b
    70b3efb0496c:	movq   rax,xmm1
    70b3efb04971:	add    rax,rax
    70b3efb04974:	je     0x70b3efb0498a
    70b3efb04976:	shr    rax,0x35
    70b3efb0497a:	sub    eax,0x201
    70b3efb0497f:	cmp    eax,0x3fc
    70b3efb04984:	ja     0x70b3efb0577b
    70b3efb0498a:	movdqa xmm14,xmm1
    70b3efb0498f:	psrldq xmm14,0x8
    70b3efb04995:	movq   rax,xmm14
    70b3efb0499a:	add    rax,rax
    70b3efb0499d:	je     0x70b3efb049b3
    70b3efb0499f:	shr    rax,0x35
    70b3efb049a3:	sub    eax,0x201
    70b3efb049a8:	cmp    eax,0x3fc
    70b3efb049ad:	ja     0x70b3efb0577b
    70b3efb049b3:	addpd  xmm0,xmm1
    70b3efb049b7:	movdqa xmm3,xmm0
    70b3efb049bb:	movdqa xmm0,xmm3
    70b3efb049bf:	movdqu XMMWORD PTR [r12+0x120],xmm0
    70b3efb049c9:	mov    r13,QWORD PTR [r12+0x60]
    70b3efb049ce:	mov    r14,r13
    70b3efb049d1:	add    r14,0x10
    70b3efb049d5:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    70b3efb049df:	movdqa xmm2,xmm0
    70b3efb049e3:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    70b3efb049ed:	movdqa xmm4,xmm0
    70b3efb049f1:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb049f9:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb04a01:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb04a09:	shr    r11d,1
    70b3efb04a0c:	and    r11d,0x10
    70b3efb04a10:	or     DWORD PTR [r12+0x314],r11d
    70b3efb04a18:	movdqu XMMWORD PTR [r13+0x0],xmm2
    70b3efb04a1e:	mov    r15d,0x0
    70b3efb04a24:	mov    DWORD PTR [r12+0x32c],r15d
    70b3efb04a2c:	movdqu XMMWORD PTR [r14],xmm4
    70b3efb04a31:	mov    r14d,0x0
    70b3efb04a37:	mov    DWORD PTR [r12+0x32c],r14d
    70b3efb04a3f:	add    r13,0x20
    70b3efb04a43:	mov    r14,r13
    70b3efb04a46:	add    r14,0x10
    70b3efb04a4a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    70b3efb04a54:	movdqa xmm2,xmm0
    70b3efb04a58:	movdqu XMMWORD PTR [r13+0x0],xmm2
    70b3efb04a5e:	mov    r13d,0x0
    70b3efb04a64:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb04a6c:	movdqu XMMWORD PTR [r14],xmm3
    70b3efb04a71:	mov    r13d,0x0
    70b3efb04a77:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb04a7f:	mov    rcx,QWORD PTR [r12+0x380]
    70b3efb04a87:	jrcxz  0x70b3efb04a8e
    70b3efb04a89:	jmp    0x70b3efb07068
    70b3efb04a8e:	push   QWORD PTR [rsp]
    70b3efb04a91:	popf
    70b3efb04a92:	je     0x70b3efb04a9d
    70b3efb04a98:	jmp    0x70b3efb00ed8
    70b3efb04a9d:	mov    r13d,DWORD PTR [r12+0x48]
    70b3efb04aa2:	add    r13d,0x1
    70b3efb04aa6:	mov    QWORD PTR [r12+0x48],r13
    70b3efb04aab:	sub    r13d,0x1f4
    70b3efb04ab2:	mov    rcx,QWORD PTR [r12+0x380]
    70b3efb04aba:	jrcxz  0x70b3efb04ac1
    70b3efb04abc:	jmp    0x70b3efb070f2
    70b3efb04ac1:	pushf
    70b3efb04ac2:	pop    r11
    70b3efb04ac4:	mov    QWORD PTR [rsp],r11
    70b3efb04ac8:	jne    0x70b3efb00ec8
    70b3efb04ace:	jmp    0x70b3efb04ad3
    70b3efb04ad3:	mov    r13d,0x0
    70b3efb04ad9:	mov    QWORD PTR [r12+0x48],r13
    70b3efb04ade:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb04ae6:	mov    r14,r13
    70b3efb04ae9:	add    r14,0x140
    70b3efb04af0:	mov    r15,QWORD PTR [r14]
    70b3efb04af3:	mov    QWORD PTR [r12+0xe8],r15
    70b3efb04afb:	mov    r14,r13
    70b3efb04afe:	add    r14,0x130
    70b3efb04b05:	mov    r15,r14
    70b3efb04b08:	add    r15,0x8
    70b3efb04b0c:	mov    rbp,QWORD PTR [r14]
    70b3efb04b0f:	mov    r14,QWORD PTR [r15]
    70b3efb04b12:	mov    r15d,0x0
    70b3efb04b18:	mov    QWORD PTR [r12+0x1a0],rbp
    70b3efb04b20:	mov    QWORD PTR [r12+0x1a8],r15
    70b3efb04b28:	mov    r15d,0x0
    70b3efb04b2e:	mov    QWORD PTR [r12+0x190],r14
    70b3efb04b36:	mov    QWORD PTR [r12+0x198],r15
    70b3efb04b3e:	add    r13,0x120
    70b3efb04b45:	mov    r14,r13
    70b3efb04b48:	add    r14,0x8
    70b3efb04b4c:	mov    r15,QWORD PTR [r13+0x0]
    70b3efb04b50:	mov    r13,QWORD PTR [r14]
    70b3efb04b53:	mov    r14d,0x0
    70b3efb04b59:	mov    QWORD PTR [r12+0x1c0],r15
    70b3efb04b61:	mov    QWORD PTR [r12+0x1c8],r14
    70b3efb04b69:	mov    r14d,0x0
    70b3efb04b6f:	mov    QWORD PTR [r12+0x1b0],r13
    70b3efb04b77:	mov    QWORD PTR [r12+0x1b8],r14
    70b3efb04b7f:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb04b87:	mov    r14,r13
    70b3efb04b8a:	add    r14,0x110
    70b3efb04b91:	mov    r15,r14
    70b3efb04b94:	add    r15,0x8
    70b3efb04b98:	mov    rbp,QWORD PTR [r14]
    70b3efb04b9b:	mov    r14,QWORD PTR [r15]
    70b3efb04b9e:	mov    r15d,0x0
    70b3efb04ba4:	mov    QWORD PTR [r12+0x1e0],rbp
    70b3efb04bac:	mov    QWORD PTR [r12+0x1e8],r15
    70b3efb04bb4:	mov    r15d,0x0
    70b3efb04bba:	mov    QWORD PTR [r12+0x1d0],r14
    70b3efb04bc2:	mov    QWORD PTR [r12+0x1d8],r15
    70b3efb04bca:	add    r13,0x100
    70b3efb04bd1:	mov    r14,r13
    70b3efb04bd4:	add    r14,0x8
    70b3efb04bd8:	mov    r15,QWORD PTR [r13+0x0]
    70b3efb04bdc:	mov    r13,QWORD PTR [r14]
    70b3efb04bdf:	mov    r14d,0x0
    70b3efb04be5:	mov    QWORD PTR [r12+0x200],r15
    70b3efb04bed:	mov    QWORD PTR [r12+0x208],r14
    70b3efb04bf5:	mov    r14d,0x0
    70b3efb04bfb:	mov    QWORD PTR [r12+0x1f0],r13
    70b3efb04c03:	mov    QWORD PTR [r12+0x1f8],r14
    70b3efb04c0b:	mov    r13d,0x430000
    70b3efb04c11:	mov    QWORD PTR [r12+0x40],r13
    70b3efb04c16:	mov    r13d,0x430510
    70b3efb04c1c:	mov    r14,QWORD PTR [r13+0x0]
    70b3efb04c20:	mov    r13d,0x0
    70b3efb04c26:	mov    QWORD PTR [r12+0x110],r14
    70b3efb04c2e:	mov    QWORD PTR [r12+0x118],r13
    70b3efb04c36:	mov    r13,QWORD PTR [r12+0xf8]
    70b3efb04c3e:	add    r13,0x150
    70b3efb04c45:	mov    QWORD PTR [r12+0xf8],r13
    70b3efb04c4d:	jmp    0x70b3efb04c52
    70b3efb04c52:	mov    r13,QWORD PTR [r12+0x48]
    70b3efb04c57:	mov    r14,QWORD PTR [r12+0x50]
    70b3efb04c5c:	mov    rcx,r13
    70b3efb04c5f:	add    r14,rcx
    70b3efb04c62:	movdqu xmm2,XMMWORD PTR [r14]
    70b3efb04c67:	movdqa xmm0,xmm2
    70b3efb04c6b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    70b3efb04c75:	add    r13,0x10
    70b3efb04c79:	mov    QWORD PTR [r12+0x48],r13
    70b3efb04c7e:	sub    r13,0x200
    70b3efb04c85:	mov    r13,QWORD PTR [r12+0x128]
    70b3efb04c8d:	mov    r14d,0x0
    70b3efb04c93:	mov    QWORD PTR [r12+0x130],r13
    70b3efb04c9b:	mov    QWORD PTR [r12+0x138],r14
    70b3efb04ca3:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    70b3efb04cad:	movdqa xmm2,xmm0
    70b3efb04cb1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    70b3efb04cbb:	movdqa xmm3,xmm0
    70b3efb04cbf:	pushf
    70b3efb04cc0:	pop    r11
    70b3efb04cc2:	mov    QWORD PTR [rsp],r11
    70b3efb04cc6:	stmxcsr DWORD PTR [rsp+0x110]
    70b3efb04cce:	mov    DWORD PTR [rsp+0x114],0x1f80
    70b3efb04cd9:	ldmxcsr DWORD PTR [rsp+0x114]
    70b3efb04ce1:	movdqa xmm0,xmm2
    70b3efb04ce5:	movdqa xmm1,xmm3
    70b3efb04ce9:	movq   rax,xmm0
    70b3efb04cee:	add    rax,rax
    70b3efb04cf1:	je     0x70b3efb04d07
    70b3efb04cf3:	shr    rax,0x35
    70b3efb04cf7:	sub    eax,0x201
    70b3efb04cfc:	cmp    eax,0x3fc
    70b3efb04d01:	ja     0x70b3efb0579f
    70b3efb04d07:	movq   rax,xmm1
    70b3efb04d0c:	add    rax,rax
    70b3efb04d0f:	je     0x70b3efb04d25
    70b3efb04d11:	shr    rax,0x35
    70b3efb04d15:	sub    eax,0x201
    70b3efb04d1a:	cmp    eax,0x3fc
    70b3efb04d1f:	ja     0x70b3efb0579f
    70b3efb04d25:	movq   xmm0,xmm0
    70b3efb04d29:	movq   xmm1,xmm1
    70b3efb04d2d:	addsd  xmm0,xmm1
    70b3efb04d31:	movdqa xmm4,xmm0
    70b3efb04d35:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    70b3efb04d3f:	movdqa xmm2,xmm0
    70b3efb04d43:	movdqa xmm0,xmm4
    70b3efb04d47:	movdqa xmm1,xmm2
    70b3efb04d4b:	movq   rax,xmm0
    70b3efb04d50:	add    rax,rax
    70b3efb04d53:	je     0x70b3efb04d69
    70b3efb04d55:	shr    rax,0x35
    70b3efb04d59:	sub    eax,0x201
    70b3efb04d5e:	cmp    eax,0x3fc
    70b3efb04d63:	ja     0x70b3efb057c3
    70b3efb04d69:	movq   rax,xmm1
    70b3efb04d6e:	add    rax,rax
    70b3efb04d71:	je     0x70b3efb04d87
    70b3efb04d73:	shr    rax,0x35
    70b3efb04d77:	sub    eax,0x201
    70b3efb04d7c:	cmp    eax,0x3fc
    70b3efb04d81:	ja     0x70b3efb057c3
    70b3efb04d87:	movq   xmm0,xmm0
    70b3efb04d8b:	movq   xmm1,xmm1
    70b3efb04d8f:	addsd  xmm0,xmm1
    70b3efb04d93:	movdqa xmm3,xmm0
    70b3efb04d97:	movdqa xmm0,xmm3
    70b3efb04d9b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    70b3efb04da5:	stmxcsr DWORD PTR [rsp+0x114]
    70b3efb04dad:	ldmxcsr DWORD PTR [rsp+0x110]
    70b3efb04db5:	mov    r11d,DWORD PTR [rsp+0x114]
    70b3efb04dbd:	shr    r11d,1
    70b3efb04dc0:	and    r11d,0x10
    70b3efb04dc4:	or     DWORD PTR [r12+0x314],r11d
    70b3efb04dcc:	mov    rcx,QWORD PTR [r12+0x380]
    70b3efb04dd4:	jrcxz  0x70b3efb04ddb
    70b3efb04dd6:	jmp    0x70b3efb07184
    70b3efb04ddb:	push   QWORD PTR [rsp]
    70b3efb04dde:	popf
    70b3efb04ddf:	jne    0x70b3efb04c52
    70b3efb04de5:	jmp    0x70b3efb04dea
    70b3efb04dea:	mov    r13,QWORD PTR [r12+0x40]
    70b3efb04def:	add    r13,0x510
    70b3efb04df6:	mov    r14,QWORD PTR [r12+0x110]
    70b3efb04dfe:	mov    QWORD PTR [r13+0x0],r14
    70b3efb04e02:	mov    r13d,0x0
    70b3efb04e08:	mov    DWORD PTR [r12+0x32c],r13d
    70b3efb04e10:	mov    rcx,QWORD PTR [r12+0x380]
    70b3efb04e18:	jrcxz  0x70b3efb04e1f
    70b3efb04e1a:	jmp    0x70b3efb0720e
    70b3efb04e1f:	mov    r13,QWORD PTR [r12+0xf0]
    70b3efb04e27:	mov    QWORD PTR [r12+0x100],r13
    70b3efb04e2f:	mov    r11,QWORD PTR [rsp]
    70b3efb04e33:	mov    QWORD PTR [r12+0x398],r11
    70b3efb04e3b:	mov    rdi,QWORD PTR [r12+0x100]
    70b3efb04e43:	add    rsp,0x150
    70b3efb04e4a:	movabs r11,0x566a970a80a0
    70b3efb04e54:	jmp    r11
    70b3efb04e57:	movdqa xmm0,xmm2
    70b3efb04e5b:	movdqa xmm1,xmm3
    70b3efb04e5f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04e68:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04e71:	call   0x70b3efb057f0
    70b3efb04e76:	jmp    0x70b3efb005be
    70b3efb04e7b:	movdqa xmm0,xmm2
    70b3efb04e7f:	movdqa xmm1,xmm3
    70b3efb04e83:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04e8c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04e95:	call   0x70b3efb057f0
    70b3efb04e9a:	jmp    0x70b3efb006eb
    70b3efb04e9f:	movdqa xmm0,xmm3
    70b3efb04ea3:	movdqa xmm1,xmm4
    70b3efb04ea7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04eb0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04eb9:	call   0x70b3efb058d0
    70b3efb04ebe:	jmp    0x70b3efb011a1
    70b3efb04ec3:	movdqa xmm0,xmm2
    70b3efb04ec7:	movdqa xmm1,xmm4
    70b3efb04ecb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04ed4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04edd:	call   0x70b3efb05a60
    70b3efb04ee2:	jmp    0x70b3efb01260
    70b3efb04ee7:	movdqa xmm0,xmm3
    70b3efb04eeb:	movdqa xmm1,xmm2
    70b3efb04eef:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04ef8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04f01:	call   0x70b3efb05bf0
    70b3efb04f06:	jmp    0x70b3efb01336
    70b3efb04f0b:	movdqa xmm0,xmm3
    70b3efb04f0f:	movdqa xmm1,xmm2
    70b3efb04f13:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04f1c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04f25:	call   0x70b3efb05bf0
    70b3efb04f2a:	jmp    0x70b3efb013f0
    70b3efb04f2f:	movdqa xmm0,xmm2
    70b3efb04f33:	movdqa xmm1,xmm3
    70b3efb04f37:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04f40:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04f49:	call   0x70b3efb05bf0
    70b3efb04f4e:	jmp    0x70b3efb014b8
    70b3efb04f53:	movdqa xmm0,xmm2
    70b3efb04f57:	movdqa xmm1,xmm3
    70b3efb04f5b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04f64:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04f6d:	call   0x70b3efb05d70
    70b3efb04f72:	jmp    0x70b3efb015c3
    70b3efb04f77:	movdqa xmm0,xmm2
    70b3efb04f7b:	movdqa xmm1,xmm3
    70b3efb04f7f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04f88:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04f91:	call   0x70b3efb05ef0
    70b3efb04f96:	jmp    0x70b3efb016e0
    70b3efb04f9b:	movdqa xmm0,xmm2
    70b3efb04f9f:	movdqa xmm1,xmm3
    70b3efb04fa3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04fac:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04fb5:	call   0x70b3efb05ef0
    70b3efb04fba:	jmp    0x70b3efb017a8
    70b3efb04fbf:	movdqa xmm0,xmm2
    70b3efb04fc3:	movdqa xmm1,xmm3
    70b3efb04fc7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04fd0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04fd9:	call   0x70b3efb05ef0
    70b3efb04fde:	jmp    0x70b3efb01862
    70b3efb04fe3:	movdqa xmm0,xmm2
    70b3efb04fe7:	movdqa xmm1,xmm4
    70b3efb04feb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb04ff4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb04ffd:	call   0x70b3efb06070
    70b3efb05002:	jmp    0x70b3efb01aa7
    70b3efb05007:	movdqa xmm0,xmm4
    70b3efb0500b:	movdqa xmm1,xmm5
    70b3efb0500f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05018:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05021:	call   0x70b3efb06200
    70b3efb05026:	jmp    0x70b3efb01bcc
    70b3efb0502b:	movdqa xmm0,xmm4
    70b3efb0502f:	movdqa xmm1,xmm5
    70b3efb05033:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb0503c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05045:	call   0x70b3efb06200
    70b3efb0504a:	jmp    0x70b3efb01c94
    70b3efb0504f:	movdqa xmm0,xmm3
    70b3efb05053:	movdqa xmm1,xmm4
    70b3efb05057:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05060:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05069:	call   0x70b3efb05a60
    70b3efb0506e:	jmp    0x70b3efb01d53
    70b3efb05073:	movdqa xmm0,xmm2
    70b3efb05077:	movdqa xmm1,xmm3
    70b3efb0507b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05084:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb0508d:	call   0x70b3efb05a60
    70b3efb05092:	jmp    0x70b3efb01e12
    70b3efb05097:	movdqa xmm0,xmm2
    70b3efb0509b:	movdqa xmm1,xmm4
    70b3efb0509f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb050a8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb050b1:	call   0x70b3efb05a60
    70b3efb050b6:	jmp    0x70b3efb01f38
    70b3efb050bb:	movdqa xmm0,xmm2
    70b3efb050bf:	movdqa xmm1,xmm3
    70b3efb050c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb050cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb050d5:	call   0x70b3efb05d70
    70b3efb050da:	jmp    0x70b3efb0203f
    70b3efb050df:	movdqa xmm0,xmm3
    70b3efb050e3:	movdqa xmm1,xmm4
    70b3efb050e7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb050f0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb050f9:	call   0x70b3efb06070
    70b3efb050fe:	jmp    0x70b3efb021f4
    70b3efb05103:	movdqa xmm0,xmm2
    70b3efb05107:	movdqa xmm1,xmm3
    70b3efb0510b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05114:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb0511d:	call   0x70b3efb05d70
    70b3efb05122:	jmp    0x70b3efb022b3
    70b3efb05127:	movdqa xmm0,xmm3
    70b3efb0512b:	movdqa xmm1,xmm4
    70b3efb0512f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05138:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05141:	call   0x70b3efb06070
    70b3efb05146:	jmp    0x70b3efb023e0
    70b3efb0514b:	movdqa xmm0,xmm3
    70b3efb0514f:	movdqa xmm1,xmm4
    70b3efb05153:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb0515c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05165:	call   0x70b3efb06070
    70b3efb0516a:	jmp    0x70b3efb024a8
    70b3efb0516f:	movdqa xmm0,xmm2
    70b3efb05173:	movdqa xmm1,xmm3
    70b3efb05177:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05180:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05189:	call   0x70b3efb05d70
    70b3efb0518e:	jmp    0x70b3efb0258b
    70b3efb05193:	movdqa xmm0,xmm3
    70b3efb05197:	movdqa xmm1,xmm4
    70b3efb0519b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb051a4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb051ad:	call   0x70b3efb06070
    70b3efb051b2:	jmp    0x70b3efb026b8
    70b3efb051b7:	movdqa xmm0,xmm3
    70b3efb051bb:	movdqa xmm1,xmm4
    70b3efb051bf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb051c8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb051d1:	call   0x70b3efb05a60
    70b3efb051d6:	jmp    0x70b3efb02785
    70b3efb051db:	movdqa xmm0,xmm2
    70b3efb051df:	movdqa xmm1,xmm4
    70b3efb051e3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb051ec:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb051f5:	call   0x70b3efb06390
    70b3efb051fa:	jmp    0x70b3efb02852
    70b3efb051ff:	movdqa xmm0,xmm3
    70b3efb05203:	movdqa xmm1,xmm4
    70b3efb05207:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05210:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05219:	call   0x70b3efb06070
    70b3efb0521e:	jmp    0x70b3efb02981
    70b3efb05223:	movdqa xmm0,xmm2
    70b3efb05227:	movdqa xmm1,xmm3
    70b3efb0522b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05234:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb0523d:	call   0x70b3efb05d70
    70b3efb05242:	jmp    0x70b3efb02a88
    70b3efb05247:	movdqa xmm0,xmm2
    70b3efb0524b:	movdqa xmm1,xmm4
    70b3efb0524f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05258:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05261:	call   0x70b3efb06070
    70b3efb05266:	jmp    0x70b3efb02baa
    70b3efb0526b:	movdqa xmm0,xmm2
    70b3efb0526f:	movdqa xmm1,xmm3
    70b3efb05273:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb0527c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05285:	call   0x70b3efb05d70
    70b3efb0528a:	jmp    0x70b3efb02c69
    70b3efb0528f:	movdqa xmm0,xmm2
    70b3efb05293:	movdqa xmm1,xmm3
    70b3efb05297:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb052a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb052a9:	call   0x70b3efb05ef0
    70b3efb052ae:	jmp    0x70b3efb02d31
    70b3efb052b3:	movdqa xmm0,xmm2
    70b3efb052b7:	movdqa xmm1,xmm3
    70b3efb052bb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb052c4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb052cd:	call   0x70b3efb05d70
    70b3efb052d2:	jmp    0x70b3efb02dfe
    70b3efb052d7:	movdqa xmm0,xmm2
    70b3efb052db:	movdqa xmm1,xmm3
    70b3efb052df:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb052e8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb052f1:	call   0x70b3efb05d70
    70b3efb052f6:	jmp    0x70b3efb02ebd
    70b3efb052fb:	movdqa xmm0,xmm2
    70b3efb052ff:	movdqa xmm1,xmm4
    70b3efb05303:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb0530c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05315:	call   0x70b3efb06070
    70b3efb0531a:	jmp    0x70b3efb02f85
    70b3efb0531f:	movdqa xmm0,xmm2
    70b3efb05323:	movdqa xmm1,xmm4
    70b3efb05327:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05330:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05339:	call   0x70b3efb06070
    70b3efb0533e:	jmp    0x70b3efb0304d
    70b3efb05343:	movdqa xmm0,xmm2
    70b3efb05347:	movdqa xmm1,xmm3
    70b3efb0534b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05354:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb0535d:	call   0x70b3efb05d70
    70b3efb05362:	jmp    0x70b3efb0310c
    70b3efb05367:	movdqa xmm0,xmm2
    70b3efb0536b:	movdqa xmm1,xmm3
    70b3efb0536f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05378:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05381:	call   0x70b3efb05d70
    70b3efb05386:	jmp    0x70b3efb031cb
    70b3efb0538b:	movdqa xmm0,xmm2
    70b3efb0538f:	movdqa xmm1,xmm3
    70b3efb05393:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb0539c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb053a5:	call   0x70b3efb05ef0
    70b3efb053aa:	jmp    0x70b3efb03293
    70b3efb053af:	movdqa xmm0,xmm2
    70b3efb053b3:	movdqa xmm1,xmm3
    70b3efb053b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb053c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb053c9:	call   0x70b3efb05ef0
    70b3efb053ce:	jmp    0x70b3efb0335b
    70b3efb053d3:	movdqa xmm0,xmm2
    70b3efb053d7:	movdqa xmm1,xmm3
    70b3efb053db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb053e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb053ed:	call   0x70b3efb05d70
    70b3efb053f2:	jmp    0x70b3efb03428
    70b3efb053f7:	movdqa xmm0,xmm2
    70b3efb053fb:	movdqa xmm1,xmm3
    70b3efb053ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05408:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05411:	call   0x70b3efb05ef0
    70b3efb05416:	jmp    0x70b3efb034f0
    70b3efb0541b:	movdqa xmm0,xmm2
    70b3efb0541f:	movdqa xmm1,xmm3
    70b3efb05423:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb0542c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05435:	call   0x70b3efb05ef0
    70b3efb0543a:	jmp    0x70b3efb035b8
    70b3efb0543f:	movdqa xmm0,xmm2
    70b3efb05443:	movdqa xmm1,xmm3
    70b3efb05447:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05450:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05459:	call   0x70b3efb05d70
    70b3efb0545e:	jmp    0x70b3efb03753
    70b3efb05463:	movdqa xmm0,xmm2
    70b3efb05467:	movdqa xmm1,xmm4
    70b3efb0546b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05474:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb0547d:	call   0x70b3efb06070
    70b3efb05482:	jmp    0x70b3efb0381b
    70b3efb05487:	movdqa xmm0,xmm2
    70b3efb0548b:	movdqa xmm1,xmm4
    70b3efb0548f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05498:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb054a1:	call   0x70b3efb06070
    70b3efb054a6:	jmp    0x70b3efb038e3
    70b3efb054ab:	movdqa xmm0,xmm2
    70b3efb054af:	movdqa xmm1,xmm3
    70b3efb054b3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb054bc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb054c5:	call   0x70b3efb05d70
    70b3efb054ca:	jmp    0x70b3efb039a2
    70b3efb054cf:	movdqa xmm0,xmm2
    70b3efb054d3:	movdqa xmm1,xmm3
    70b3efb054d7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb054e0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb054e9:	call   0x70b3efb05d70
    70b3efb054ee:	jmp    0x70b3efb03a6f
    70b3efb054f3:	movdqa xmm0,xmm2
    70b3efb054f7:	movdqa xmm1,xmm3
    70b3efb054fb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05504:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb0550d:	call   0x70b3efb05d70
    70b3efb05512:	jmp    0x70b3efb03b3c
    70b3efb05517:	movdqa xmm0,xmm2
    70b3efb0551b:	movdqa xmm1,xmm4
    70b3efb0551f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05528:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05531:	call   0x70b3efb06070
    70b3efb05536:	jmp    0x70b3efb03c04
    70b3efb0553b:	movdqa xmm0,xmm2
    70b3efb0553f:	movdqa xmm1,xmm3
    70b3efb05543:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb0554c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05555:	call   0x70b3efb05d70
    70b3efb0555a:	jmp    0x70b3efb03cc3
    70b3efb0555f:	movdqa xmm0,xmm2
    70b3efb05563:	movdqa xmm1,xmm4
    70b3efb05567:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05570:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05579:	call   0x70b3efb06070
    70b3efb0557e:	jmp    0x70b3efb03d8b
    70b3efb05583:	movdqa xmm0,xmm2
    70b3efb05587:	movdqa xmm1,xmm3
    70b3efb0558b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05594:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb0559d:	call   0x70b3efb05d70
    70b3efb055a2:	jmp    0x70b3efb03e4a
    70b3efb055a7:	movdqa xmm0,xmm2
    70b3efb055ab:	movdqa xmm1,xmm3
    70b3efb055af:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb055b8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb055c1:	call   0x70b3efb05ef0
    70b3efb055c6:	jmp    0x70b3efb03f12
    70b3efb055cb:	movdqa xmm0,xmm2
    70b3efb055cf:	movdqa xmm1,xmm3
    70b3efb055d3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb055dc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb055e5:	call   0x70b3efb05d70
    70b3efb055ea:	jmp    0x70b3efb03fdf
    70b3efb055ef:	movdqa xmm0,xmm2
    70b3efb055f3:	movdqa xmm1,xmm3
    70b3efb055f7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05600:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05609:	call   0x70b3efb05ef0
    70b3efb0560e:	jmp    0x70b3efb040a7
    70b3efb05613:	movdqa xmm0,xmm3
    70b3efb05617:	movdqa xmm1,xmm4
    70b3efb0561b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05624:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb0562d:	call   0x70b3efb06070
    70b3efb05632:	jmp    0x70b3efb041d3
    70b3efb05637:	movdqa xmm0,xmm2
    70b3efb0563b:	movdqa xmm1,xmm3
    70b3efb0563f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05648:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05651:	call   0x70b3efb05d70
    70b3efb05656:	jmp    0x70b3efb04292
    70b3efb0565b:	movdqa xmm0,xmm2
    70b3efb0565f:	movdqa xmm1,xmm3
    70b3efb05663:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb0566c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05675:	call   0x70b3efb05d70
    70b3efb0567a:	jmp    0x70b3efb04351
    70b3efb0567f:	movdqa xmm0,xmm2
    70b3efb05683:	movdqa xmm1,xmm4
    70b3efb05687:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05690:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05699:	call   0x70b3efb06070
    70b3efb0569e:	jmp    0x70b3efb04419
    70b3efb056a3:	movdqa xmm0,xmm5
    70b3efb056a7:	movdqa xmm1,xmm6
    70b3efb056ab:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb056b4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb056bd:	call   0x70b3efb06510
    70b3efb056c2:	jmp    0x70b3efb04543
    70b3efb056c7:	movdqa xmm0,xmm4
    70b3efb056cb:	movdqa xmm1,xmm3
    70b3efb056cf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb056d8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb056e1:	call   0x70b3efb066b0
    70b3efb056e6:	jmp    0x70b3efb045f4
    70b3efb056eb:	movdqa xmm0,xmm2
    70b3efb056ef:	movdqa xmm1,xmm3
    70b3efb056f3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb056fc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05705:	call   0x70b3efb06840
    70b3efb0570a:	jmp    0x70b3efb046a5
    70b3efb0570f:	movdqa xmm0,xmm2
    70b3efb05713:	movdqa xmm1,xmm3
    70b3efb05717:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05720:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05729:	call   0x70b3efb069d0
    70b3efb0572e:	jmp    0x70b3efb0476d
    70b3efb05733:	movdqa xmm0,xmm2
    70b3efb05737:	movdqa xmm1,xmm3
    70b3efb0573b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05744:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb0574d:	call   0x70b3efb069d0
    70b3efb05752:	jmp    0x70b3efb04835
    70b3efb05757:	movdqa xmm0,xmm2
    70b3efb0575b:	movdqa xmm1,xmm3
    70b3efb0575f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb05768:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05771:	call   0x70b3efb069d0
    70b3efb05776:	jmp    0x70b3efb048fd
    70b3efb0577b:	movdqa xmm0,xmm7
    70b3efb0577f:	movdqa xmm1,xmm2
    70b3efb05783:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb0578c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb05795:	call   0x70b3efb06b60
    70b3efb0579a:	jmp    0x70b3efb049b7
    70b3efb0579f:	movdqa xmm0,xmm2
    70b3efb057a3:	movdqa xmm1,xmm3
    70b3efb057a7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb057b0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb057b9:	call   0x70b3efb06ce0
    70b3efb057be:	jmp    0x70b3efb04d31
    70b3efb057c3:	movdqa xmm0,xmm4
    70b3efb057c7:	movdqa xmm1,xmm2
    70b3efb057cb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    70b3efb057d4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    70b3efb057dd:	call   0x70b3efb06e60
    70b3efb057e2:	jmp    0x70b3efb04d93
    70b3efb057e7:	nop    WORD PTR [rax+rax*1+0x0]
    70b3efb057f0:	sub    rsp,0x8
    70b3efb057f4:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb057fc:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb05804:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb0580c:	shr    r11d,1
    70b3efb0580f:	and    r11d,0x10
    70b3efb05813:	or     DWORD PTR [r12+0x314],r11d
    70b3efb0581b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb05827:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb0582d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb05833:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb0583b:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb05841:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb05847:	lea    rdi,[rsp+0x110]
    70b3efb0584f:	lea    rsi,[rsp+0xf0]
    70b3efb05857:	lea    rdx,[rsp+0x100]
    70b3efb0585f:	mov    ecx,0x16
    70b3efb05864:	mov    r8d,0x0
    70b3efb0586a:	lea    r9,[r12+0x314]
    70b3efb05872:	movabs r11,0x566a96f131b0
    70b3efb0587c:	call   r11
    70b3efb0587f:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb05885:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb0588b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb05891:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb05899:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb058a5:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb058ae:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb058b6:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb058c1:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb058c9:	add    rsp,0x8
    70b3efb058cd:	ret
    70b3efb058ce:	xchg   ax,ax
    70b3efb058d0:	sub    rsp,0x8
    70b3efb058d4:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb058dc:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb058e4:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb058ec:	shr    r11d,1
    70b3efb058ef:	and    r11d,0x10
    70b3efb058f3:	or     DWORD PTR [r12+0x314],r11d
    70b3efb058fb:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb05907:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb0590d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb05913:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    70b3efb05919:	push   rdx
    70b3efb0591a:	push   rsi
    70b3efb0591b:	push   r10
    70b3efb0591d:	push   r11
    70b3efb0591f:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb05924:	mov    r10d,edx
    70b3efb05927:	and    r10d,0xc0
    70b3efb0592e:	shl    r10d,0x18
    70b3efb05932:	mov    r11d,edx
    70b3efb05935:	and    r11d,0x1
    70b3efb05939:	shl    r11d,0x1d
    70b3efb0593d:	or     r10d,r11d
    70b3efb05940:	mov    r11d,edx
    70b3efb05943:	and    r11d,0x800
    70b3efb0594a:	shl    r11d,0x11
    70b3efb0594e:	or     r10d,r11d
    70b3efb05951:	btc    r10,0x1d
    70b3efb05956:	mov    r11d,0xf0000000
    70b3efb0595c:	and    r11,r10
    70b3efb0595f:	movabs rsi,0xffffffff0fffffff
    70b3efb05969:	and    rbx,rsi
    70b3efb0596c:	or     rbx,r11
    70b3efb0596f:	pop    r11
    70b3efb05971:	pop    r10
    70b3efb05973:	pop    rsi
    70b3efb05974:	pop    rdx
    70b3efb05975:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb0597d:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb05983:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb05989:	lea    rdi,[rsp+0x110]
    70b3efb05991:	lea    rsi,[rsp+0xf0]
    70b3efb05999:	lea    rdx,[rsp+0x100]
    70b3efb059a1:	mov    ecx,0x16
    70b3efb059a6:	mov    r8d,0x0
    70b3efb059ac:	lea    r9,[r12+0x314]
    70b3efb059b4:	movabs r11,0x566a96f131b0
    70b3efb059be:	call   r11
    70b3efb059c1:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb059c7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb059cd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb059d3:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    70b3efb059d9:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb059e1:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb059ed:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb059f6:	pushf
    70b3efb059f7:	pop    rdx
    70b3efb059f8:	and    rdx,0xfffffffffffff73e
    70b3efb059ff:	mov    rax,rbx
    70b3efb05a02:	shr    rax,0x18
    70b3efb05a06:	and    eax,0xc0
    70b3efb05a0b:	or     rdx,rax
    70b3efb05a0e:	mov    rax,rbx
    70b3efb05a11:	shr    rax,0x1d
    70b3efb05a15:	and    eax,0x1
    70b3efb05a18:	xor    eax,0x1
    70b3efb05a1b:	or     rdx,rax
    70b3efb05a1e:	mov    rax,rbx
    70b3efb05a21:	shr    rax,0x11
    70b3efb05a25:	and    eax,0x800
    70b3efb05a2a:	or     rdx,rax
    70b3efb05a2d:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb05a32:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb05a3a:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb05a45:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb05a4d:	add    rsp,0x8
    70b3efb05a51:	ret
    70b3efb05a52:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb05a60:	sub    rsp,0x8
    70b3efb05a64:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb05a6c:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb05a74:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb05a7c:	shr    r11d,1
    70b3efb05a7f:	and    r11d,0x10
    70b3efb05a83:	or     DWORD PTR [r12+0x314],r11d
    70b3efb05a8b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb05a97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb05a9d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb05aa3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    70b3efb05aa9:	push   rdx
    70b3efb05aaa:	push   rsi
    70b3efb05aab:	push   r10
    70b3efb05aad:	push   r11
    70b3efb05aaf:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb05ab4:	mov    r10d,edx
    70b3efb05ab7:	and    r10d,0xc0
    70b3efb05abe:	shl    r10d,0x18
    70b3efb05ac2:	mov    r11d,edx
    70b3efb05ac5:	and    r11d,0x1
    70b3efb05ac9:	shl    r11d,0x1d
    70b3efb05acd:	or     r10d,r11d
    70b3efb05ad0:	mov    r11d,edx
    70b3efb05ad3:	and    r11d,0x800
    70b3efb05ada:	shl    r11d,0x11
    70b3efb05ade:	or     r10d,r11d
    70b3efb05ae1:	btc    r10,0x1d
    70b3efb05ae6:	mov    r11d,0xf0000000
    70b3efb05aec:	and    r11,r10
    70b3efb05aef:	movabs rsi,0xffffffff0fffffff
    70b3efb05af9:	and    rbx,rsi
    70b3efb05afc:	or     rbx,r11
    70b3efb05aff:	pop    r11
    70b3efb05b01:	pop    r10
    70b3efb05b03:	pop    rsi
    70b3efb05b04:	pop    rdx
    70b3efb05b05:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb05b0d:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb05b13:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb05b19:	lea    rdi,[rsp+0x110]
    70b3efb05b21:	lea    rsi,[rsp+0xf0]
    70b3efb05b29:	lea    rdx,[rsp+0x100]
    70b3efb05b31:	mov    ecx,0x56
    70b3efb05b36:	mov    r8d,0x0
    70b3efb05b3c:	lea    r9,[r12+0x314]
    70b3efb05b44:	movabs r11,0x566a96f131b0
    70b3efb05b4e:	call   r11
    70b3efb05b51:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb05b57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb05b5d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb05b63:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    70b3efb05b69:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb05b71:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb05b7d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb05b86:	pushf
    70b3efb05b87:	pop    rdx
    70b3efb05b88:	and    rdx,0xfffffffffffff73e
    70b3efb05b8f:	mov    rax,rbx
    70b3efb05b92:	shr    rax,0x18
    70b3efb05b96:	and    eax,0xc0
    70b3efb05b9b:	or     rdx,rax
    70b3efb05b9e:	mov    rax,rbx
    70b3efb05ba1:	shr    rax,0x1d
    70b3efb05ba5:	and    eax,0x1
    70b3efb05ba8:	xor    eax,0x1
    70b3efb05bab:	or     rdx,rax
    70b3efb05bae:	mov    rax,rbx
    70b3efb05bb1:	shr    rax,0x11
    70b3efb05bb5:	and    eax,0x800
    70b3efb05bba:	or     rdx,rax
    70b3efb05bbd:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb05bc2:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb05bca:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb05bd5:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb05bdd:	add    rsp,0x8
    70b3efb05be1:	ret
    70b3efb05be2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb05bf0:	sub    rsp,0x8
    70b3efb05bf4:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb05bfc:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb05c04:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb05c0c:	shr    r11d,1
    70b3efb05c0f:	and    r11d,0x10
    70b3efb05c13:	or     DWORD PTR [r12+0x314],r11d
    70b3efb05c1b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb05c27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb05c2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb05c33:	push   rdx
    70b3efb05c34:	push   rsi
    70b3efb05c35:	push   r10
    70b3efb05c37:	push   r11
    70b3efb05c39:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb05c3e:	mov    r10d,edx
    70b3efb05c41:	and    r10d,0xc0
    70b3efb05c48:	shl    r10d,0x18
    70b3efb05c4c:	mov    r11d,edx
    70b3efb05c4f:	and    r11d,0x1
    70b3efb05c53:	shl    r11d,0x1d
    70b3efb05c57:	or     r10d,r11d
    70b3efb05c5a:	mov    r11d,edx
    70b3efb05c5d:	and    r11d,0x800
    70b3efb05c64:	shl    r11d,0x11
    70b3efb05c68:	or     r10d,r11d
    70b3efb05c6b:	btc    r10,0x1d
    70b3efb05c70:	mov    r11d,0xf0000000
    70b3efb05c76:	and    r11,r10
    70b3efb05c79:	movabs rsi,0xffffffff0fffffff
    70b3efb05c83:	and    rbx,rsi
    70b3efb05c86:	or     rbx,r11
    70b3efb05c89:	pop    r11
    70b3efb05c8b:	pop    r10
    70b3efb05c8d:	pop    rsi
    70b3efb05c8e:	pop    rdx
    70b3efb05c8f:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb05c97:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb05c9d:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb05ca3:	lea    rdi,[rsp+0x110]
    70b3efb05cab:	lea    rsi,[rsp+0xf0]
    70b3efb05cb3:	lea    rdx,[rsp+0x100]
    70b3efb05cbb:	mov    ecx,0x16
    70b3efb05cc0:	mov    r8d,0x0
    70b3efb05cc6:	lea    r9,[r12+0x314]
    70b3efb05cce:	movabs r11,0x566a96f131b0
    70b3efb05cd8:	call   r11
    70b3efb05cdb:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb05ce1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb05ce7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb05ced:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb05cf5:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb05d01:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb05d0a:	pushf
    70b3efb05d0b:	pop    rdx
    70b3efb05d0c:	and    rdx,0xfffffffffffff73e
    70b3efb05d13:	mov    rax,rbx
    70b3efb05d16:	shr    rax,0x18
    70b3efb05d1a:	and    eax,0xc0
    70b3efb05d1f:	or     rdx,rax
    70b3efb05d22:	mov    rax,rbx
    70b3efb05d25:	shr    rax,0x1d
    70b3efb05d29:	and    eax,0x1
    70b3efb05d2c:	xor    eax,0x1
    70b3efb05d2f:	or     rdx,rax
    70b3efb05d32:	mov    rax,rbx
    70b3efb05d35:	shr    rax,0x11
    70b3efb05d39:	and    eax,0x800
    70b3efb05d3e:	or     rdx,rax
    70b3efb05d41:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb05d46:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb05d4e:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb05d59:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb05d61:	add    rsp,0x8
    70b3efb05d65:	ret
    70b3efb05d66:	data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb05d70:	sub    rsp,0x8
    70b3efb05d74:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb05d7c:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb05d84:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb05d8c:	shr    r11d,1
    70b3efb05d8f:	and    r11d,0x10
    70b3efb05d93:	or     DWORD PTR [r12+0x314],r11d
    70b3efb05d9b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb05da7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb05dad:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb05db3:	push   rdx
    70b3efb05db4:	push   rsi
    70b3efb05db5:	push   r10
    70b3efb05db7:	push   r11
    70b3efb05db9:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb05dbe:	mov    r10d,edx
    70b3efb05dc1:	and    r10d,0xc0
    70b3efb05dc8:	shl    r10d,0x18
    70b3efb05dcc:	mov    r11d,edx
    70b3efb05dcf:	and    r11d,0x1
    70b3efb05dd3:	shl    r11d,0x1d
    70b3efb05dd7:	or     r10d,r11d
    70b3efb05dda:	mov    r11d,edx
    70b3efb05ddd:	and    r11d,0x800
    70b3efb05de4:	shl    r11d,0x11
    70b3efb05de8:	or     r10d,r11d
    70b3efb05deb:	btc    r10,0x1d
    70b3efb05df0:	mov    r11d,0xf0000000
    70b3efb05df6:	and    r11,r10
    70b3efb05df9:	movabs rsi,0xffffffff0fffffff
    70b3efb05e03:	and    rbx,rsi
    70b3efb05e06:	or     rbx,r11
    70b3efb05e09:	pop    r11
    70b3efb05e0b:	pop    r10
    70b3efb05e0d:	pop    rsi
    70b3efb05e0e:	pop    rdx
    70b3efb05e0f:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb05e17:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb05e1d:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb05e23:	lea    rdi,[rsp+0x110]
    70b3efb05e2b:	lea    rsi,[rsp+0xf0]
    70b3efb05e33:	lea    rdx,[rsp+0x100]
    70b3efb05e3b:	mov    ecx,0x56
    70b3efb05e40:	mov    r8d,0x0
    70b3efb05e46:	lea    r9,[r12+0x314]
    70b3efb05e4e:	movabs r11,0x566a96f131b0
    70b3efb05e58:	call   r11
    70b3efb05e5b:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb05e61:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb05e67:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb05e6d:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb05e75:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb05e81:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb05e8a:	pushf
    70b3efb05e8b:	pop    rdx
    70b3efb05e8c:	and    rdx,0xfffffffffffff73e
    70b3efb05e93:	mov    rax,rbx
    70b3efb05e96:	shr    rax,0x18
    70b3efb05e9a:	and    eax,0xc0
    70b3efb05e9f:	or     rdx,rax
    70b3efb05ea2:	mov    rax,rbx
    70b3efb05ea5:	shr    rax,0x1d
    70b3efb05ea9:	and    eax,0x1
    70b3efb05eac:	xor    eax,0x1
    70b3efb05eaf:	or     rdx,rax
    70b3efb05eb2:	mov    rax,rbx
    70b3efb05eb5:	shr    rax,0x11
    70b3efb05eb9:	and    eax,0x800
    70b3efb05ebe:	or     rdx,rax
    70b3efb05ec1:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb05ec6:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb05ece:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb05ed9:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb05ee1:	add    rsp,0x8
    70b3efb05ee5:	ret
    70b3efb05ee6:	data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb05ef0:	sub    rsp,0x8
    70b3efb05ef4:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb05efc:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb05f04:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb05f0c:	shr    r11d,1
    70b3efb05f0f:	and    r11d,0x10
    70b3efb05f13:	or     DWORD PTR [r12+0x314],r11d
    70b3efb05f1b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb05f27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb05f2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb05f33:	push   rdx
    70b3efb05f34:	push   rsi
    70b3efb05f35:	push   r10
    70b3efb05f37:	push   r11
    70b3efb05f39:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb05f3e:	mov    r10d,edx
    70b3efb05f41:	and    r10d,0xc0
    70b3efb05f48:	shl    r10d,0x18
    70b3efb05f4c:	mov    r11d,edx
    70b3efb05f4f:	and    r11d,0x1
    70b3efb05f53:	shl    r11d,0x1d
    70b3efb05f57:	or     r10d,r11d
    70b3efb05f5a:	mov    r11d,edx
    70b3efb05f5d:	and    r11d,0x800
    70b3efb05f64:	shl    r11d,0x11
    70b3efb05f68:	or     r10d,r11d
    70b3efb05f6b:	btc    r10,0x1d
    70b3efb05f70:	mov    r11d,0xf0000000
    70b3efb05f76:	and    r11,r10
    70b3efb05f79:	movabs rsi,0xffffffff0fffffff
    70b3efb05f83:	and    rbx,rsi
    70b3efb05f86:	or     rbx,r11
    70b3efb05f89:	pop    r11
    70b3efb05f8b:	pop    r10
    70b3efb05f8d:	pop    rsi
    70b3efb05f8e:	pop    rdx
    70b3efb05f8f:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb05f97:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb05f9d:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb05fa3:	lea    rdi,[rsp+0x110]
    70b3efb05fab:	lea    rsi,[rsp+0xf0]
    70b3efb05fb3:	lea    rdx,[rsp+0x100]
    70b3efb05fbb:	mov    ecx,0x14
    70b3efb05fc0:	mov    r8d,0x0
    70b3efb05fc6:	lea    r9,[r12+0x314]
    70b3efb05fce:	movabs r11,0x566a96f131b0
    70b3efb05fd8:	call   r11
    70b3efb05fdb:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb05fe1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb05fe7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb05fed:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb05ff5:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb06001:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb0600a:	pushf
    70b3efb0600b:	pop    rdx
    70b3efb0600c:	and    rdx,0xfffffffffffff73e
    70b3efb06013:	mov    rax,rbx
    70b3efb06016:	shr    rax,0x18
    70b3efb0601a:	and    eax,0xc0
    70b3efb0601f:	or     rdx,rax
    70b3efb06022:	mov    rax,rbx
    70b3efb06025:	shr    rax,0x1d
    70b3efb06029:	and    eax,0x1
    70b3efb0602c:	xor    eax,0x1
    70b3efb0602f:	or     rdx,rax
    70b3efb06032:	mov    rax,rbx
    70b3efb06035:	shr    rax,0x11
    70b3efb06039:	and    eax,0x800
    70b3efb0603e:	or     rdx,rax
    70b3efb06041:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb06046:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb0604e:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb06059:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb06061:	add    rsp,0x8
    70b3efb06065:	ret
    70b3efb06066:	data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb06070:	sub    rsp,0x8
    70b3efb06074:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb0607c:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb06084:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb0608c:	shr    r11d,1
    70b3efb0608f:	and    r11d,0x10
    70b3efb06093:	or     DWORD PTR [r12+0x314],r11d
    70b3efb0609b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb060a7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb060ad:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb060b3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    70b3efb060b9:	push   rdx
    70b3efb060ba:	push   rsi
    70b3efb060bb:	push   r10
    70b3efb060bd:	push   r11
    70b3efb060bf:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb060c4:	mov    r10d,edx
    70b3efb060c7:	and    r10d,0xc0
    70b3efb060ce:	shl    r10d,0x18
    70b3efb060d2:	mov    r11d,edx
    70b3efb060d5:	and    r11d,0x1
    70b3efb060d9:	shl    r11d,0x1d
    70b3efb060dd:	or     r10d,r11d
    70b3efb060e0:	mov    r11d,edx
    70b3efb060e3:	and    r11d,0x800
    70b3efb060ea:	shl    r11d,0x11
    70b3efb060ee:	or     r10d,r11d
    70b3efb060f1:	btc    r10,0x1d
    70b3efb060f6:	mov    r11d,0xf0000000
    70b3efb060fc:	and    r11,r10
    70b3efb060ff:	movabs rsi,0xffffffff0fffffff
    70b3efb06109:	and    rbx,rsi
    70b3efb0610c:	or     rbx,r11
    70b3efb0610f:	pop    r11
    70b3efb06111:	pop    r10
    70b3efb06113:	pop    rsi
    70b3efb06114:	pop    rdx
    70b3efb06115:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb0611d:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb06123:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb06129:	lea    rdi,[rsp+0x110]
    70b3efb06131:	lea    rsi,[rsp+0xf0]
    70b3efb06139:	lea    rdx,[rsp+0x100]
    70b3efb06141:	mov    ecx,0x14
    70b3efb06146:	mov    r8d,0x0
    70b3efb0614c:	lea    r9,[r12+0x314]
    70b3efb06154:	movabs r11,0x566a96f131b0
    70b3efb0615e:	call   r11
    70b3efb06161:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb06167:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb0616d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb06173:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    70b3efb06179:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb06181:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb0618d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb06196:	pushf
    70b3efb06197:	pop    rdx
    70b3efb06198:	and    rdx,0xfffffffffffff73e
    70b3efb0619f:	mov    rax,rbx
    70b3efb061a2:	shr    rax,0x18
    70b3efb061a6:	and    eax,0xc0
    70b3efb061ab:	or     rdx,rax
    70b3efb061ae:	mov    rax,rbx
    70b3efb061b1:	shr    rax,0x1d
    70b3efb061b5:	and    eax,0x1
    70b3efb061b8:	xor    eax,0x1
    70b3efb061bb:	or     rdx,rax
    70b3efb061be:	mov    rax,rbx
    70b3efb061c1:	shr    rax,0x11
    70b3efb061c5:	and    eax,0x800
    70b3efb061ca:	or     rdx,rax
    70b3efb061cd:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb061d2:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb061da:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb061e5:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb061ed:	add    rsp,0x8
    70b3efb061f1:	ret
    70b3efb061f2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb06200:	sub    rsp,0x8
    70b3efb06204:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb0620c:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb06214:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb0621c:	shr    r11d,1
    70b3efb0621f:	and    r11d,0x10
    70b3efb06223:	or     DWORD PTR [r12+0x314],r11d
    70b3efb0622b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb06237:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb0623d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb06243:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    70b3efb06249:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    70b3efb0624f:	push   rdx
    70b3efb06250:	push   rsi
    70b3efb06251:	push   r10
    70b3efb06253:	push   r11
    70b3efb06255:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb0625a:	mov    r10d,edx
    70b3efb0625d:	and    r10d,0xc0
    70b3efb06264:	shl    r10d,0x18
    70b3efb06268:	mov    r11d,edx
    70b3efb0626b:	and    r11d,0x1
    70b3efb0626f:	shl    r11d,0x1d
    70b3efb06273:	or     r10d,r11d
    70b3efb06276:	mov    r11d,edx
    70b3efb06279:	and    r11d,0x800
    70b3efb06280:	shl    r11d,0x11
    70b3efb06284:	or     r10d,r11d
    70b3efb06287:	btc    r10,0x1d
    70b3efb0628c:	mov    r11d,0xf0000000
    70b3efb06292:	and    r11,r10
    70b3efb06295:	movabs rsi,0xffffffff0fffffff
    70b3efb0629f:	and    rbx,rsi
    70b3efb062a2:	or     rbx,r11
    70b3efb062a5:	pop    r11
    70b3efb062a7:	pop    r10
    70b3efb062a9:	pop    rsi
    70b3efb062aa:	pop    rdx
    70b3efb062ab:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb062b3:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb062b9:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb062bf:	lea    rdi,[rsp+0x110]
    70b3efb062c7:	lea    rsi,[rsp+0xf0]
    70b3efb062cf:	lea    rdx,[rsp+0x100]
    70b3efb062d7:	mov    ecx,0x14
    70b3efb062dc:	mov    r8d,0x0
    70b3efb062e2:	lea    r9,[r12+0x314]
    70b3efb062ea:	movabs r11,0x566a96f131b0
    70b3efb062f4:	call   r11
    70b3efb062f7:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb062fd:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb06303:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb06309:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    70b3efb0630f:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    70b3efb06315:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb0631d:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb06329:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb06332:	pushf
    70b3efb06333:	pop    rdx
    70b3efb06334:	and    rdx,0xfffffffffffff73e
    70b3efb0633b:	mov    rax,rbx
    70b3efb0633e:	shr    rax,0x18
    70b3efb06342:	and    eax,0xc0
    70b3efb06347:	or     rdx,rax
    70b3efb0634a:	mov    rax,rbx
    70b3efb0634d:	shr    rax,0x1d
    70b3efb06351:	and    eax,0x1
    70b3efb06354:	xor    eax,0x1
    70b3efb06357:	or     rdx,rax
    70b3efb0635a:	mov    rax,rbx
    70b3efb0635d:	shr    rax,0x11
    70b3efb06361:	and    eax,0x800
    70b3efb06366:	or     rdx,rax
    70b3efb06369:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb0636e:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb06376:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb06381:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb06389:	add    rsp,0x8
    70b3efb0638d:	ret
    70b3efb0638e:	xchg   ax,ax
    70b3efb06390:	sub    rsp,0x8
    70b3efb06394:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb0639c:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb063a4:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb063ac:	shr    r11d,1
    70b3efb063af:	and    r11d,0x10
    70b3efb063b3:	or     DWORD PTR [r12+0x314],r11d
    70b3efb063bb:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb063c7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb063cd:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    70b3efb063d3:	push   rdx
    70b3efb063d4:	push   rsi
    70b3efb063d5:	push   r10
    70b3efb063d7:	push   r11
    70b3efb063d9:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb063de:	mov    r10d,edx
    70b3efb063e1:	and    r10d,0xc0
    70b3efb063e8:	shl    r10d,0x18
    70b3efb063ec:	mov    r11d,edx
    70b3efb063ef:	and    r11d,0x1
    70b3efb063f3:	shl    r11d,0x1d
    70b3efb063f7:	or     r10d,r11d
    70b3efb063fa:	mov    r11d,edx
    70b3efb063fd:	and    r11d,0x800
    70b3efb06404:	shl    r11d,0x11
    70b3efb06408:	or     r10d,r11d
    70b3efb0640b:	btc    r10,0x1d
    70b3efb06410:	mov    r11d,0xf0000000
    70b3efb06416:	and    r11,r10
    70b3efb06419:	movabs rsi,0xffffffff0fffffff
    70b3efb06423:	and    rbx,rsi
    70b3efb06426:	or     rbx,r11
    70b3efb06429:	pop    r11
    70b3efb0642b:	pop    r10
    70b3efb0642d:	pop    rsi
    70b3efb0642e:	pop    rdx
    70b3efb0642f:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb06437:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb0643d:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb06443:	lea    rdi,[rsp+0x110]
    70b3efb0644b:	lea    rsi,[rsp+0xf0]
    70b3efb06453:	lea    rdx,[rsp+0x100]
    70b3efb0645b:	mov    ecx,0x56
    70b3efb06460:	mov    r8d,0x0
    70b3efb06466:	lea    r9,[r12+0x314]
    70b3efb0646e:	movabs r11,0x566a96f131b0
    70b3efb06478:	call   r11
    70b3efb0647b:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb06481:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb06487:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    70b3efb0648d:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb06495:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb064a1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb064aa:	pushf
    70b3efb064ab:	pop    rdx
    70b3efb064ac:	and    rdx,0xfffffffffffff73e
    70b3efb064b3:	mov    rax,rbx
    70b3efb064b6:	shr    rax,0x18
    70b3efb064ba:	and    eax,0xc0
    70b3efb064bf:	or     rdx,rax
    70b3efb064c2:	mov    rax,rbx
    70b3efb064c5:	shr    rax,0x1d
    70b3efb064c9:	and    eax,0x1
    70b3efb064cc:	xor    eax,0x1
    70b3efb064cf:	or     rdx,rax
    70b3efb064d2:	mov    rax,rbx
    70b3efb064d5:	shr    rax,0x11
    70b3efb064d9:	and    eax,0x800
    70b3efb064de:	or     rdx,rax
    70b3efb064e1:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb064e6:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb064ee:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb064f9:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb06501:	add    rsp,0x8
    70b3efb06505:	ret
    70b3efb06506:	data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb06510:	sub    rsp,0x8
    70b3efb06514:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb0651c:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb06524:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb0652c:	shr    r11d,1
    70b3efb0652f:	and    r11d,0x10
    70b3efb06533:	or     DWORD PTR [r12+0x314],r11d
    70b3efb0653b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb06547:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb0654d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb06553:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    70b3efb06559:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    70b3efb0655f:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    70b3efb06565:	push   rdx
    70b3efb06566:	push   rsi
    70b3efb06567:	push   r10
    70b3efb06569:	push   r11
    70b3efb0656b:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb06570:	mov    r10d,edx
    70b3efb06573:	and    r10d,0xc0
    70b3efb0657a:	shl    r10d,0x18
    70b3efb0657e:	mov    r11d,edx
    70b3efb06581:	and    r11d,0x1
    70b3efb06585:	shl    r11d,0x1d
    70b3efb06589:	or     r10d,r11d
    70b3efb0658c:	mov    r11d,edx
    70b3efb0658f:	and    r11d,0x800
    70b3efb06596:	shl    r11d,0x11
    70b3efb0659a:	or     r10d,r11d
    70b3efb0659d:	btc    r10,0x1d
    70b3efb065a2:	mov    r11d,0xf0000000
    70b3efb065a8:	and    r11,r10
    70b3efb065ab:	movabs rsi,0xffffffff0fffffff
    70b3efb065b5:	and    rbx,rsi
    70b3efb065b8:	or     rbx,r11
    70b3efb065bb:	pop    r11
    70b3efb065bd:	pop    r10
    70b3efb065bf:	pop    rsi
    70b3efb065c0:	pop    rdx
    70b3efb065c1:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb065c9:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb065cf:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb065d5:	lea    rdi,[rsp+0x110]
    70b3efb065dd:	lea    rsi,[rsp+0xf0]
    70b3efb065e5:	lea    rdx,[rsp+0x100]
    70b3efb065ed:	mov    ecx,0x14
    70b3efb065f2:	mov    r8d,0x0
    70b3efb065f8:	lea    r9,[r12+0x314]
    70b3efb06600:	movabs r11,0x566a96f131b0
    70b3efb0660a:	call   r11
    70b3efb0660d:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb06613:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb06619:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb0661f:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    70b3efb06625:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    70b3efb0662b:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    70b3efb06631:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb06639:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb06645:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb0664e:	pushf
    70b3efb0664f:	pop    rdx
    70b3efb06650:	and    rdx,0xfffffffffffff73e
    70b3efb06657:	mov    rax,rbx
    70b3efb0665a:	shr    rax,0x18
    70b3efb0665e:	and    eax,0xc0
    70b3efb06663:	or     rdx,rax
    70b3efb06666:	mov    rax,rbx
    70b3efb06669:	shr    rax,0x1d
    70b3efb0666d:	and    eax,0x1
    70b3efb06670:	xor    eax,0x1
    70b3efb06673:	or     rdx,rax
    70b3efb06676:	mov    rax,rbx
    70b3efb06679:	shr    rax,0x11
    70b3efb0667d:	and    eax,0x800
    70b3efb06682:	or     rdx,rax
    70b3efb06685:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb0668a:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb06692:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb0669d:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb066a5:	add    rsp,0x8
    70b3efb066a9:	ret
    70b3efb066aa:	nop    WORD PTR [rax+rax*1+0x0]
    70b3efb066b0:	sub    rsp,0x8
    70b3efb066b4:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb066bc:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb066c4:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb066cc:	shr    r11d,1
    70b3efb066cf:	and    r11d,0x10
    70b3efb066d3:	or     DWORD PTR [r12+0x314],r11d
    70b3efb066db:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb066e7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb066ed:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb066f3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    70b3efb066f9:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    70b3efb066ff:	push   rdx
    70b3efb06700:	push   rsi
    70b3efb06701:	push   r10
    70b3efb06703:	push   r11
    70b3efb06705:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb0670a:	mov    r10d,edx
    70b3efb0670d:	and    r10d,0xc0
    70b3efb06714:	shl    r10d,0x18
    70b3efb06718:	mov    r11d,edx
    70b3efb0671b:	and    r11d,0x1
    70b3efb0671f:	shl    r11d,0x1d
    70b3efb06723:	or     r10d,r11d
    70b3efb06726:	mov    r11d,edx
    70b3efb06729:	and    r11d,0x800
    70b3efb06730:	shl    r11d,0x11
    70b3efb06734:	or     r10d,r11d
    70b3efb06737:	btc    r10,0x1d
    70b3efb0673c:	mov    r11d,0xf0000000
    70b3efb06742:	and    r11,r10
    70b3efb06745:	movabs rsi,0xffffffff0fffffff
    70b3efb0674f:	and    rbx,rsi
    70b3efb06752:	or     rbx,r11
    70b3efb06755:	pop    r11
    70b3efb06757:	pop    r10
    70b3efb06759:	pop    rsi
    70b3efb0675a:	pop    rdx
    70b3efb0675b:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb06763:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb06769:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb0676f:	lea    rdi,[rsp+0x110]
    70b3efb06777:	lea    rsi,[rsp+0xf0]
    70b3efb0677f:	lea    rdx,[rsp+0x100]
    70b3efb06787:	mov    ecx,0x56
    70b3efb0678c:	mov    r8d,0x0
    70b3efb06792:	lea    r9,[r12+0x314]
    70b3efb0679a:	movabs r11,0x566a96f131b0
    70b3efb067a4:	call   r11
    70b3efb067a7:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb067ad:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb067b3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb067b9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    70b3efb067bf:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    70b3efb067c5:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb067cd:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb067d9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb067e2:	pushf
    70b3efb067e3:	pop    rdx
    70b3efb067e4:	and    rdx,0xfffffffffffff73e
    70b3efb067eb:	mov    rax,rbx
    70b3efb067ee:	shr    rax,0x18
    70b3efb067f2:	and    eax,0xc0
    70b3efb067f7:	or     rdx,rax
    70b3efb067fa:	mov    rax,rbx
    70b3efb067fd:	shr    rax,0x1d
    70b3efb06801:	and    eax,0x1
    70b3efb06804:	xor    eax,0x1
    70b3efb06807:	or     rdx,rax
    70b3efb0680a:	mov    rax,rbx
    70b3efb0680d:	shr    rax,0x11
    70b3efb06811:	and    eax,0x800
    70b3efb06816:	or     rdx,rax
    70b3efb06819:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb0681e:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb06826:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb06831:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb06839:	add    rsp,0x8
    70b3efb0683d:	ret
    70b3efb0683e:	xchg   ax,ax
    70b3efb06840:	sub    rsp,0x8
    70b3efb06844:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb0684c:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb06854:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb0685c:	shr    r11d,1
    70b3efb0685f:	and    r11d,0x10
    70b3efb06863:	or     DWORD PTR [r12+0x314],r11d
    70b3efb0686b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb06877:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb0687d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb06883:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    70b3efb06889:	push   rdx
    70b3efb0688a:	push   rsi
    70b3efb0688b:	push   r10
    70b3efb0688d:	push   r11
    70b3efb0688f:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb06894:	mov    r10d,edx
    70b3efb06897:	and    r10d,0xc0
    70b3efb0689e:	shl    r10d,0x18
    70b3efb068a2:	mov    r11d,edx
    70b3efb068a5:	and    r11d,0x1
    70b3efb068a9:	shl    r11d,0x1d
    70b3efb068ad:	or     r10d,r11d
    70b3efb068b0:	mov    r11d,edx
    70b3efb068b3:	and    r11d,0x800
    70b3efb068ba:	shl    r11d,0x11
    70b3efb068be:	or     r10d,r11d
    70b3efb068c1:	btc    r10,0x1d
    70b3efb068c6:	mov    r11d,0xf0000000
    70b3efb068cc:	and    r11,r10
    70b3efb068cf:	movabs rsi,0xffffffff0fffffff
    70b3efb068d9:	and    rbx,rsi
    70b3efb068dc:	or     rbx,r11
    70b3efb068df:	pop    r11
    70b3efb068e1:	pop    r10
    70b3efb068e3:	pop    rsi
    70b3efb068e4:	pop    rdx
    70b3efb068e5:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb068ed:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb068f3:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb068f9:	lea    rdi,[rsp+0x110]
    70b3efb06901:	lea    rsi,[rsp+0xf0]
    70b3efb06909:	lea    rdx,[rsp+0x100]
    70b3efb06911:	mov    ecx,0x56
    70b3efb06916:	mov    r8d,0x0
    70b3efb0691c:	lea    r9,[r12+0x314]
    70b3efb06924:	movabs r11,0x566a96f131b0
    70b3efb0692e:	call   r11
    70b3efb06931:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb06937:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb0693d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb06943:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    70b3efb06949:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb06951:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb0695d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb06966:	pushf
    70b3efb06967:	pop    rdx
    70b3efb06968:	and    rdx,0xfffffffffffff73e
    70b3efb0696f:	mov    rax,rbx
    70b3efb06972:	shr    rax,0x18
    70b3efb06976:	and    eax,0xc0
    70b3efb0697b:	or     rdx,rax
    70b3efb0697e:	mov    rax,rbx
    70b3efb06981:	shr    rax,0x1d
    70b3efb06985:	and    eax,0x1
    70b3efb06988:	xor    eax,0x1
    70b3efb0698b:	or     rdx,rax
    70b3efb0698e:	mov    rax,rbx
    70b3efb06991:	shr    rax,0x11
    70b3efb06995:	and    eax,0x800
    70b3efb0699a:	or     rdx,rax
    70b3efb0699d:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb069a2:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb069aa:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb069b5:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb069bd:	add    rsp,0x8
    70b3efb069c1:	ret
    70b3efb069c2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb069d0:	sub    rsp,0x8
    70b3efb069d4:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb069dc:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb069e4:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb069ec:	shr    r11d,1
    70b3efb069ef:	and    r11d,0x10
    70b3efb069f3:	or     DWORD PTR [r12+0x314],r11d
    70b3efb069fb:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb06a07:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb06a0d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb06a13:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    70b3efb06a19:	push   rdx
    70b3efb06a1a:	push   rsi
    70b3efb06a1b:	push   r10
    70b3efb06a1d:	push   r11
    70b3efb06a1f:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb06a24:	mov    r10d,edx
    70b3efb06a27:	and    r10d,0xc0
    70b3efb06a2e:	shl    r10d,0x18
    70b3efb06a32:	mov    r11d,edx
    70b3efb06a35:	and    r11d,0x1
    70b3efb06a39:	shl    r11d,0x1d
    70b3efb06a3d:	or     r10d,r11d
    70b3efb06a40:	mov    r11d,edx
    70b3efb06a43:	and    r11d,0x800
    70b3efb06a4a:	shl    r11d,0x11
    70b3efb06a4e:	or     r10d,r11d
    70b3efb06a51:	btc    r10,0x1d
    70b3efb06a56:	mov    r11d,0xf0000000
    70b3efb06a5c:	and    r11,r10
    70b3efb06a5f:	movabs rsi,0xffffffff0fffffff
    70b3efb06a69:	and    rbx,rsi
    70b3efb06a6c:	or     rbx,r11
    70b3efb06a6f:	pop    r11
    70b3efb06a71:	pop    r10
    70b3efb06a73:	pop    rsi
    70b3efb06a74:	pop    rdx
    70b3efb06a75:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb06a7d:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb06a83:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb06a89:	lea    rdi,[rsp+0x110]
    70b3efb06a91:	lea    rsi,[rsp+0xf0]
    70b3efb06a99:	lea    rdx,[rsp+0x100]
    70b3efb06aa1:	mov    ecx,0x14
    70b3efb06aa6:	mov    r8d,0x0
    70b3efb06aac:	lea    r9,[r12+0x314]
    70b3efb06ab4:	movabs r11,0x566a96f131b0
    70b3efb06abe:	call   r11
    70b3efb06ac1:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb06ac7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb06acd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb06ad3:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    70b3efb06ad9:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb06ae1:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb06aed:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb06af6:	pushf
    70b3efb06af7:	pop    rdx
    70b3efb06af8:	and    rdx,0xfffffffffffff73e
    70b3efb06aff:	mov    rax,rbx
    70b3efb06b02:	shr    rax,0x18
    70b3efb06b06:	and    eax,0xc0
    70b3efb06b0b:	or     rdx,rax
    70b3efb06b0e:	mov    rax,rbx
    70b3efb06b11:	shr    rax,0x1d
    70b3efb06b15:	and    eax,0x1
    70b3efb06b18:	xor    eax,0x1
    70b3efb06b1b:	or     rdx,rax
    70b3efb06b1e:	mov    rax,rbx
    70b3efb06b21:	shr    rax,0x11
    70b3efb06b25:	and    eax,0x800
    70b3efb06b2a:	or     rdx,rax
    70b3efb06b2d:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb06b32:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb06b3a:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb06b45:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb06b4d:	add    rsp,0x8
    70b3efb06b51:	ret
    70b3efb06b52:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb06b60:	sub    rsp,0x8
    70b3efb06b64:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb06b6c:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb06b74:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb06b7c:	shr    r11d,1
    70b3efb06b7f:	and    r11d,0x10
    70b3efb06b83:	or     DWORD PTR [r12+0x314],r11d
    70b3efb06b8b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb06b97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb06b9d:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    70b3efb06ba3:	push   rdx
    70b3efb06ba4:	push   rsi
    70b3efb06ba5:	push   r10
    70b3efb06ba7:	push   r11
    70b3efb06ba9:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb06bae:	mov    r10d,edx
    70b3efb06bb1:	and    r10d,0xc0
    70b3efb06bb8:	shl    r10d,0x18
    70b3efb06bbc:	mov    r11d,edx
    70b3efb06bbf:	and    r11d,0x1
    70b3efb06bc3:	shl    r11d,0x1d
    70b3efb06bc7:	or     r10d,r11d
    70b3efb06bca:	mov    r11d,edx
    70b3efb06bcd:	and    r11d,0x800
    70b3efb06bd4:	shl    r11d,0x11
    70b3efb06bd8:	or     r10d,r11d
    70b3efb06bdb:	btc    r10,0x1d
    70b3efb06be0:	mov    r11d,0xf0000000
    70b3efb06be6:	and    r11,r10
    70b3efb06be9:	movabs rsi,0xffffffff0fffffff
    70b3efb06bf3:	and    rbx,rsi
    70b3efb06bf6:	or     rbx,r11
    70b3efb06bf9:	pop    r11
    70b3efb06bfb:	pop    r10
    70b3efb06bfd:	pop    rsi
    70b3efb06bfe:	pop    rdx
    70b3efb06bff:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb06c07:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb06c0d:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb06c13:	lea    rdi,[rsp+0x110]
    70b3efb06c1b:	lea    rsi,[rsp+0xf0]
    70b3efb06c23:	lea    rdx,[rsp+0x100]
    70b3efb06c2b:	mov    ecx,0x14
    70b3efb06c30:	mov    r8d,0x0
    70b3efb06c36:	lea    r9,[r12+0x314]
    70b3efb06c3e:	movabs r11,0x566a96f131b0
    70b3efb06c48:	call   r11
    70b3efb06c4b:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb06c51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb06c57:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    70b3efb06c5d:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb06c65:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb06c71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb06c7a:	pushf
    70b3efb06c7b:	pop    rdx
    70b3efb06c7c:	and    rdx,0xfffffffffffff73e
    70b3efb06c83:	mov    rax,rbx
    70b3efb06c86:	shr    rax,0x18
    70b3efb06c8a:	and    eax,0xc0
    70b3efb06c8f:	or     rdx,rax
    70b3efb06c92:	mov    rax,rbx
    70b3efb06c95:	shr    rax,0x1d
    70b3efb06c99:	and    eax,0x1
    70b3efb06c9c:	xor    eax,0x1
    70b3efb06c9f:	or     rdx,rax
    70b3efb06ca2:	mov    rax,rbx
    70b3efb06ca5:	shr    rax,0x11
    70b3efb06ca9:	and    eax,0x800
    70b3efb06cae:	or     rdx,rax
    70b3efb06cb1:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb06cb6:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb06cbe:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb06cc9:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb06cd1:	add    rsp,0x8
    70b3efb06cd5:	ret
    70b3efb06cd6:	data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb06ce0:	sub    rsp,0x8
    70b3efb06ce4:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb06cec:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb06cf4:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb06cfc:	shr    r11d,1
    70b3efb06cff:	and    r11d,0x10
    70b3efb06d03:	or     DWORD PTR [r12+0x314],r11d
    70b3efb06d0b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb06d17:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb06d1d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70b3efb06d23:	push   rdx
    70b3efb06d24:	push   rsi
    70b3efb06d25:	push   r10
    70b3efb06d27:	push   r11
    70b3efb06d29:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb06d2e:	mov    r10d,edx
    70b3efb06d31:	and    r10d,0xc0
    70b3efb06d38:	shl    r10d,0x18
    70b3efb06d3c:	mov    r11d,edx
    70b3efb06d3f:	and    r11d,0x1
    70b3efb06d43:	shl    r11d,0x1d
    70b3efb06d47:	or     r10d,r11d
    70b3efb06d4a:	mov    r11d,edx
    70b3efb06d4d:	and    r11d,0x800
    70b3efb06d54:	shl    r11d,0x11
    70b3efb06d58:	or     r10d,r11d
    70b3efb06d5b:	btc    r10,0x1d
    70b3efb06d60:	mov    r11d,0xf0000000
    70b3efb06d66:	and    r11,r10
    70b3efb06d69:	movabs rsi,0xffffffff0fffffff
    70b3efb06d73:	and    rbx,rsi
    70b3efb06d76:	or     rbx,r11
    70b3efb06d79:	pop    r11
    70b3efb06d7b:	pop    r10
    70b3efb06d7d:	pop    rsi
    70b3efb06d7e:	pop    rdx
    70b3efb06d7f:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb06d87:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb06d8d:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb06d93:	lea    rdi,[rsp+0x110]
    70b3efb06d9b:	lea    rsi,[rsp+0xf0]
    70b3efb06da3:	lea    rdx,[rsp+0x100]
    70b3efb06dab:	mov    ecx,0xc
    70b3efb06db0:	mov    r8d,0x0
    70b3efb06db6:	lea    r9,[r12+0x314]
    70b3efb06dbe:	movabs r11,0x566a96f131b0
    70b3efb06dc8:	call   r11
    70b3efb06dcb:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb06dd1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb06dd7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    70b3efb06ddd:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb06de5:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb06df1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb06dfa:	pushf
    70b3efb06dfb:	pop    rdx
    70b3efb06dfc:	and    rdx,0xfffffffffffff73e
    70b3efb06e03:	mov    rax,rbx
    70b3efb06e06:	shr    rax,0x18
    70b3efb06e0a:	and    eax,0xc0
    70b3efb06e0f:	or     rdx,rax
    70b3efb06e12:	mov    rax,rbx
    70b3efb06e15:	shr    rax,0x1d
    70b3efb06e19:	and    eax,0x1
    70b3efb06e1c:	xor    eax,0x1
    70b3efb06e1f:	or     rdx,rax
    70b3efb06e22:	mov    rax,rbx
    70b3efb06e25:	shr    rax,0x11
    70b3efb06e29:	and    eax,0x800
    70b3efb06e2e:	or     rdx,rax
    70b3efb06e31:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb06e36:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb06e3e:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb06e49:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb06e51:	add    rsp,0x8
    70b3efb06e55:	ret
    70b3efb06e56:	data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb06e60:	sub    rsp,0x8
    70b3efb06e64:	stmxcsr DWORD PTR [rsp+0x124]
    70b3efb06e6c:	ldmxcsr DWORD PTR [rsp+0x120]
    70b3efb06e74:	mov    r11d,DWORD PTR [rsp+0x124]
    70b3efb06e7c:	shr    r11d,1
    70b3efb06e7f:	and    r11d,0x10
    70b3efb06e83:	or     DWORD PTR [r12+0x314],r11d
    70b3efb06e8b:	mov    QWORD PTR [r12+0x378],0x3
    70b3efb06e97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70b3efb06e9d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    70b3efb06ea3:	push   rdx
    70b3efb06ea4:	push   rsi
    70b3efb06ea5:	push   r10
    70b3efb06ea7:	push   r11
    70b3efb06ea9:	mov    rdx,QWORD PTR [rsp+0x30]
    70b3efb06eae:	mov    r10d,edx
    70b3efb06eb1:	and    r10d,0xc0
    70b3efb06eb8:	shl    r10d,0x18
    70b3efb06ebc:	mov    r11d,edx
    70b3efb06ebf:	and    r11d,0x1
    70b3efb06ec3:	shl    r11d,0x1d
    70b3efb06ec7:	or     r10d,r11d
    70b3efb06eca:	mov    r11d,edx
    70b3efb06ecd:	and    r11d,0x800
    70b3efb06ed4:	shl    r11d,0x11
    70b3efb06ed8:	or     r10d,r11d
    70b3efb06edb:	btc    r10,0x1d
    70b3efb06ee0:	mov    r11d,0xf0000000
    70b3efb06ee6:	and    r11,r10
    70b3efb06ee9:	movabs rsi,0xffffffff0fffffff
    70b3efb06ef3:	and    rbx,rsi
    70b3efb06ef6:	or     rbx,r11
    70b3efb06ef9:	pop    r11
    70b3efb06efb:	pop    r10
    70b3efb06efd:	pop    rsi
    70b3efb06efe:	pop    rdx
    70b3efb06eff:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb06f07:	stmxcsr DWORD PTR [r12-0x28]
    70b3efb06f0d:	ldmxcsr DWORD PTR [r12-0x38]
    70b3efb06f13:	lea    rdi,[rsp+0x110]
    70b3efb06f1b:	lea    rsi,[rsp+0xf0]
    70b3efb06f23:	lea    rdx,[rsp+0x100]
    70b3efb06f2b:	mov    ecx,0xc
    70b3efb06f30:	mov    r8d,0x0
    70b3efb06f36:	lea    r9,[r12+0x314]
    70b3efb06f3e:	movabs r11,0x566a96f131b0
    70b3efb06f48:	call   r11
    70b3efb06f4b:	ldmxcsr DWORD PTR [r12-0x28]
    70b3efb06f51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    70b3efb06f57:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    70b3efb06f5d:	mov    rbx,QWORD PTR [r12+0x108]
    70b3efb06f65:	mov    QWORD PTR [r12+0x378],0x2
    70b3efb06f71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    70b3efb06f7a:	pushf
    70b3efb06f7b:	pop    rdx
    70b3efb06f7c:	and    rdx,0xfffffffffffff73e
    70b3efb06f83:	mov    rax,rbx
    70b3efb06f86:	shr    rax,0x18
    70b3efb06f8a:	and    eax,0xc0
    70b3efb06f8f:	or     rdx,rax
    70b3efb06f92:	mov    rax,rbx
    70b3efb06f95:	shr    rax,0x1d
    70b3efb06f99:	and    eax,0x1
    70b3efb06f9c:	xor    eax,0x1
    70b3efb06f9f:	or     rdx,rax
    70b3efb06fa2:	mov    rax,rbx
    70b3efb06fa5:	shr    rax,0x11
    70b3efb06fa9:	and    eax,0x800
    70b3efb06fae:	or     rdx,rax
    70b3efb06fb1:	mov    QWORD PTR [rsp+0x10],rdx
    70b3efb06fb6:	stmxcsr DWORD PTR [rsp+0x120]
    70b3efb06fbe:	mov    DWORD PTR [rsp+0x124],0x1f80
    70b3efb06fc9:	ldmxcsr DWORD PTR [rsp+0x124]
    70b3efb06fd1:	add    rsp,0x8
    70b3efb06fd5:	ret
    70b3efb06fd6:	mov    eax,0x4101e8
    70b3efb06fdb:	mov    QWORD PTR [r12+0x100],rax
    70b3efb06fe3:	push   rdx
    70b3efb06fe4:	push   rsi
    70b3efb06fe5:	push   r10
    70b3efb06fe7:	push   r11
    70b3efb06fe9:	pushf
    70b3efb06fea:	pop    r11
    70b3efb06fec:	mov    QWORD PTR [rsp+0x20],r11
    70b3efb06ff1:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb06ff6:	mov    r10d,edx
    70b3efb06ff9:	and    r10d,0xc0
    70b3efb07000:	shl    r10d,0x18
    70b3efb07004:	mov    r11d,edx
    70b3efb07007:	and    r11d,0x1
    70b3efb0700b:	shl    r11d,0x1d
    70b3efb0700f:	or     r10d,r11d
    70b3efb07012:	mov    r11d,edx
    70b3efb07015:	and    r11d,0x800
    70b3efb0701c:	shl    r11d,0x11
    70b3efb07020:	or     r10d,r11d
    70b3efb07023:	btc    r10,0x1d
    70b3efb07028:	mov    r11d,0xf0000000
    70b3efb0702e:	and    r11,r10
    70b3efb07031:	movabs rsi,0xffffffff0fffffff
    70b3efb0703b:	and    rbx,rsi
    70b3efb0703e:	or     rbx,r11
    70b3efb07041:	pop    r11
    70b3efb07043:	pop    r10
    70b3efb07045:	pop    rsi
    70b3efb07046:	pop    rdx
    70b3efb07047:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb0704f:	add    rsp,0x150
    70b3efb07056:	mov    eax,0xc
    70b3efb0705b:	movabs r11,0x566a970a8390
    70b3efb07065:	jmp    r11
    70b3efb07068:	mov    eax,0x410440
    70b3efb0706d:	mov    QWORD PTR [r12+0x100],rax
    70b3efb07075:	push   rdx
    70b3efb07076:	push   rsi
    70b3efb07077:	push   r10
    70b3efb07079:	push   r11
    70b3efb0707b:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb07080:	mov    r10d,edx
    70b3efb07083:	and    r10d,0xc0
    70b3efb0708a:	shl    r10d,0x18
    70b3efb0708e:	mov    r11d,edx
    70b3efb07091:	and    r11d,0x1
    70b3efb07095:	shl    r11d,0x1d
    70b3efb07099:	or     r10d,r11d
    70b3efb0709c:	mov    r11d,edx
    70b3efb0709f:	and    r11d,0x800
    70b3efb070a6:	shl    r11d,0x11
    70b3efb070aa:	or     r10d,r11d
    70b3efb070ad:	btc    r10,0x1d
    70b3efb070b2:	mov    r11d,0xf0000000
    70b3efb070b8:	and    r11,r10
    70b3efb070bb:	movabs rsi,0xffffffff0fffffff
    70b3efb070c5:	and    rbx,rsi
    70b3efb070c8:	or     rbx,r11
    70b3efb070cb:	pop    r11
    70b3efb070cd:	pop    r10
    70b3efb070cf:	pop    rsi
    70b3efb070d0:	pop    rdx
    70b3efb070d1:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb070d9:	add    rsp,0x150
    70b3efb070e0:	mov    eax,0xc
    70b3efb070e5:	movabs r11,0x566a970a8390
    70b3efb070ef:	jmp    r11
    70b3efb070f2:	mov    eax,0x41044c
    70b3efb070f7:	mov    QWORD PTR [r12+0x100],rax
    70b3efb070ff:	push   rdx
    70b3efb07100:	push   rsi
    70b3efb07101:	push   r10
    70b3efb07103:	push   r11
    70b3efb07105:	pushf
    70b3efb07106:	pop    r11
    70b3efb07108:	mov    QWORD PTR [rsp+0x20],r11
    70b3efb0710d:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb07112:	mov    r10d,edx
    70b3efb07115:	and    r10d,0xc0
    70b3efb0711c:	shl    r10d,0x18
    70b3efb07120:	mov    r11d,edx
    70b3efb07123:	and    r11d,0x1
    70b3efb07127:	shl    r11d,0x1d
    70b3efb0712b:	or     r10d,r11d
    70b3efb0712e:	mov    r11d,edx
    70b3efb07131:	and    r11d,0x800
    70b3efb07138:	shl    r11d,0x11
    70b3efb0713c:	or     r10d,r11d
    70b3efb0713f:	btc    r10,0x1d
    70b3efb07144:	mov    r11d,0xf0000000
    70b3efb0714a:	and    r11,r10
    70b3efb0714d:	movabs rsi,0xffffffff0fffffff
    70b3efb07157:	and    rbx,rsi
    70b3efb0715a:	or     rbx,r11
    70b3efb0715d:	pop    r11
    70b3efb0715f:	pop    r10
    70b3efb07161:	pop    rsi
    70b3efb07162:	pop    rdx
    70b3efb07163:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb0716b:	add    rsp,0x150
    70b3efb07172:	mov    eax,0xc
    70b3efb07177:	movabs r11,0x566a970a8390
    70b3efb07181:	jmp    r11
    70b3efb07184:	mov    eax,0x41048c
    70b3efb07189:	mov    QWORD PTR [r12+0x100],rax
    70b3efb07191:	push   rdx
    70b3efb07192:	push   rsi
    70b3efb07193:	push   r10
    70b3efb07195:	push   r11
    70b3efb07197:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb0719c:	mov    r10d,edx
    70b3efb0719f:	and    r10d,0xc0
    70b3efb071a6:	shl    r10d,0x18
    70b3efb071aa:	mov    r11d,edx
    70b3efb071ad:	and    r11d,0x1
    70b3efb071b1:	shl    r11d,0x1d
    70b3efb071b5:	or     r10d,r11d
    70b3efb071b8:	mov    r11d,edx
    70b3efb071bb:	and    r11d,0x800
    70b3efb071c2:	shl    r11d,0x11
    70b3efb071c6:	or     r10d,r11d
    70b3efb071c9:	btc    r10,0x1d
    70b3efb071ce:	mov    r11d,0xf0000000
    70b3efb071d4:	and    r11,r10
    70b3efb071d7:	movabs rsi,0xffffffff0fffffff
    70b3efb071e1:	and    rbx,rsi
    70b3efb071e4:	or     rbx,r11
    70b3efb071e7:	pop    r11
    70b3efb071e9:	pop    r10
    70b3efb071eb:	pop    rsi
    70b3efb071ec:	pop    rdx
    70b3efb071ed:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb071f5:	add    rsp,0x150
    70b3efb071fc:	mov    eax,0xc
    70b3efb07201:	movabs r11,0x566a970a8390
    70b3efb0720b:	jmp    r11
    70b3efb0720e:	mov    eax,0x410494
    70b3efb07213:	mov    QWORD PTR [r12+0x100],rax
    70b3efb0721b:	push   rdx
    70b3efb0721c:	push   rsi
    70b3efb0721d:	push   r10
    70b3efb0721f:	push   r11
    70b3efb07221:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb07226:	mov    r10d,edx
    70b3efb07229:	and    r10d,0xc0
    70b3efb07230:	shl    r10d,0x18
    70b3efb07234:	mov    r11d,edx
    70b3efb07237:	and    r11d,0x1
    70b3efb0723b:	shl    r11d,0x1d
    70b3efb0723f:	or     r10d,r11d
    70b3efb07242:	mov    r11d,edx
    70b3efb07245:	and    r11d,0x800
    70b3efb0724c:	shl    r11d,0x11
    70b3efb07250:	or     r10d,r11d
    70b3efb07253:	btc    r10,0x1d
    70b3efb07258:	mov    r11d,0xf0000000
    70b3efb0725e:	and    r11,r10
    70b3efb07261:	movabs rsi,0xffffffff0fffffff
    70b3efb0726b:	and    rbx,rsi
    70b3efb0726e:	or     rbx,r11
    70b3efb07271:	pop    r11
    70b3efb07273:	pop    r10
    70b3efb07275:	pop    rsi
    70b3efb07276:	pop    rdx
    70b3efb07277:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb0727f:	add    rsp,0x150
    70b3efb07286:	mov    eax,0xc
    70b3efb0728b:	movabs r11,0x566a970a8390
    70b3efb07295:	jmp    r11
    70b3efb07298:	nop    DWORD PTR [rax+rax*1+0x0]
    70b3efb072a0:	sub    rsp,0x150
    70b3efb072a7:	mov    r11,QWORD PTR [r12+0x398]
    70b3efb072af:	mov    QWORD PTR [rsp],r11
    70b3efb072b3:	cmp    DWORD PTR [r12+0x310],0x0
    70b3efb072bc:	je     0x70b3efb0734c
    70b3efb072c2:	push   rdx
    70b3efb072c3:	push   rsi
    70b3efb072c4:	push   r10
    70b3efb072c6:	push   r11
    70b3efb072c8:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb072cd:	mov    r10d,edx
    70b3efb072d0:	and    r10d,0xc0
    70b3efb072d7:	shl    r10d,0x18
    70b3efb072db:	mov    r11d,edx
    70b3efb072de:	and    r11d,0x1
    70b3efb072e2:	shl    r11d,0x1d
    70b3efb072e6:	or     r10d,r11d
    70b3efb072e9:	mov    r11d,edx
    70b3efb072ec:	and    r11d,0x800
    70b3efb072f3:	shl    r11d,0x11
    70b3efb072f7:	or     r10d,r11d
    70b3efb072fa:	btc    r10,0x1d
    70b3efb072ff:	mov    r11d,0xf0000000
    70b3efb07305:	and    r11,r10
    70b3efb07308:	movabs rsi,0xffffffff0fffffff
    70b3efb07312:	and    rbx,rsi
    70b3efb07315:	or     rbx,r11
    70b3efb07318:	pop    r11
    70b3efb0731a:	pop    r10
    70b3efb0731c:	pop    rsi
    70b3efb0731d:	pop    rdx
    70b3efb0731e:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb07326:	mov    eax,0x4101ac
    70b3efb0732b:	mov    QWORD PTR [r12+0x100],rax
    70b3efb07333:	add    rsp,0x150
    70b3efb0733a:	mov    eax,0x3
    70b3efb0733f:	movabs r11,0x566a970a8390
    70b3efb07349:	jmp    r11
    70b3efb0734c:	jmp    0x70b3efb001fd
    70b3efb07351:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb07360:	sub    rsp,0x150
    70b3efb07367:	mov    r11,QWORD PTR [r12+0x398]
    70b3efb0736f:	mov    QWORD PTR [rsp],r11
    70b3efb07373:	cmp    DWORD PTR [r12+0x310],0x0
    70b3efb0737c:	je     0x70b3efb0740c
    70b3efb07382:	push   rdx
    70b3efb07383:	push   rsi
    70b3efb07384:	push   r10
    70b3efb07386:	push   r11
    70b3efb07388:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb0738d:	mov    r10d,edx
    70b3efb07390:	and    r10d,0xc0
    70b3efb07397:	shl    r10d,0x18
    70b3efb0739b:	mov    r11d,edx
    70b3efb0739e:	and    r11d,0x1
    70b3efb073a2:	shl    r11d,0x1d
    70b3efb073a6:	or     r10d,r11d
    70b3efb073a9:	mov    r11d,edx
    70b3efb073ac:	and    r11d,0x800
    70b3efb073b3:	shl    r11d,0x11
    70b3efb073b7:	or     r10d,r11d
    70b3efb073ba:	btc    r10,0x1d
    70b3efb073bf:	mov    r11d,0xf0000000
    70b3efb073c5:	and    r11,r10
    70b3efb073c8:	movabs rsi,0xffffffff0fffffff
    70b3efb073d2:	and    rbx,rsi
    70b3efb073d5:	or     rbx,r11
    70b3efb073d8:	pop    r11
    70b3efb073da:	pop    r10
    70b3efb073dc:	pop    rsi
    70b3efb073dd:	pop    rdx
    70b3efb073de:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb073e6:	mov    eax,0x4101ec
    70b3efb073eb:	mov    QWORD PTR [r12+0x100],rax
    70b3efb073f3:	add    rsp,0x150
    70b3efb073fa:	mov    eax,0x3
    70b3efb073ff:	movabs r11,0x566a970a8390
    70b3efb07409:	jmp    r11
    70b3efb0740c:	jmp    0x70b3efb00773
    70b3efb07411:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb07420:	sub    rsp,0x150
    70b3efb07427:	mov    r11,QWORD PTR [r12+0x398]
    70b3efb0742f:	mov    QWORD PTR [rsp],r11
    70b3efb07433:	cmp    DWORD PTR [r12+0x310],0x0
    70b3efb0743c:	je     0x70b3efb074cc
    70b3efb07442:	push   rdx
    70b3efb07443:	push   rsi
    70b3efb07444:	push   r10
    70b3efb07446:	push   r11
    70b3efb07448:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb0744d:	mov    r10d,edx
    70b3efb07450:	and    r10d,0xc0
    70b3efb07457:	shl    r10d,0x18
    70b3efb0745b:	mov    r11d,edx
    70b3efb0745e:	and    r11d,0x1
    70b3efb07462:	shl    r11d,0x1d
    70b3efb07466:	or     r10d,r11d
    70b3efb07469:	mov    r11d,edx
    70b3efb0746c:	and    r11d,0x800
    70b3efb07473:	shl    r11d,0x11
    70b3efb07477:	or     r10d,r11d
    70b3efb0747a:	btc    r10,0x1d
    70b3efb0747f:	mov    r11d,0xf0000000
    70b3efb07485:	and    r11,r10
    70b3efb07488:	movabs rsi,0xffffffff0fffffff
    70b3efb07492:	and    rbx,rsi
    70b3efb07495:	or     rbx,r11
    70b3efb07498:	pop    r11
    70b3efb0749a:	pop    r10
    70b3efb0749c:	pop    rsi
    70b3efb0749d:	pop    rdx
    70b3efb0749e:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb074a6:	mov    eax,0x410274
    70b3efb074ab:	mov    QWORD PTR [r12+0x100],rax
    70b3efb074b3:	add    rsp,0x150
    70b3efb074ba:	mov    eax,0x3
    70b3efb074bf:	movabs r11,0x566a970a8390
    70b3efb074c9:	jmp    r11
    70b3efb074cc:	jmp    0x70b3efb00ec8
    70b3efb074d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb074e0:	sub    rsp,0x150
    70b3efb074e7:	mov    r11,QWORD PTR [r12+0x398]
    70b3efb074ef:	mov    QWORD PTR [rsp],r11
    70b3efb074f3:	cmp    DWORD PTR [r12+0x310],0x0
    70b3efb074fc:	je     0x70b3efb0758c
    70b3efb07502:	push   rdx
    70b3efb07503:	push   rsi
    70b3efb07504:	push   r10
    70b3efb07506:	push   r11
    70b3efb07508:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb0750d:	mov    r10d,edx
    70b3efb07510:	and    r10d,0xc0
    70b3efb07517:	shl    r10d,0x18
    70b3efb0751b:	mov    r11d,edx
    70b3efb0751e:	and    r11d,0x1
    70b3efb07522:	shl    r11d,0x1d
    70b3efb07526:	or     r10d,r11d
    70b3efb07529:	mov    r11d,edx
    70b3efb0752c:	and    r11d,0x800
    70b3efb07533:	shl    r11d,0x11
    70b3efb07537:	or     r10d,r11d
    70b3efb0753a:	btc    r10,0x1d
    70b3efb0753f:	mov    r11d,0xf0000000
    70b3efb07545:	and    r11,r10
    70b3efb07548:	movabs rsi,0xffffffff0fffffff
    70b3efb07552:	and    rbx,rsi
    70b3efb07555:	or     rbx,r11
    70b3efb07558:	pop    r11
    70b3efb0755a:	pop    r10
    70b3efb0755c:	pop    rsi
    70b3efb0755d:	pop    rdx
    70b3efb0755e:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb07566:	mov    eax,0x410278
    70b3efb0756b:	mov    QWORD PTR [r12+0x100],rax
    70b3efb07573:	add    rsp,0x150
    70b3efb0757a:	mov    eax,0x3
    70b3efb0757f:	movabs r11,0x566a970a8390
    70b3efb07589:	jmp    r11
    70b3efb0758c:	jmp    0x70b3efb00ed8
    70b3efb07591:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb075a0:	sub    rsp,0x150
    70b3efb075a7:	mov    r11,QWORD PTR [r12+0x398]
    70b3efb075af:	mov    QWORD PTR [rsp],r11
    70b3efb075b3:	cmp    DWORD PTR [r12+0x310],0x0
    70b3efb075bc:	je     0x70b3efb0764c
    70b3efb075c2:	push   rdx
    70b3efb075c3:	push   rsi
    70b3efb075c4:	push   r10
    70b3efb075c6:	push   r11
    70b3efb075c8:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb075cd:	mov    r10d,edx
    70b3efb075d0:	and    r10d,0xc0
    70b3efb075d7:	shl    r10d,0x18
    70b3efb075db:	mov    r11d,edx
    70b3efb075de:	and    r11d,0x1
    70b3efb075e2:	shl    r11d,0x1d
    70b3efb075e6:	or     r10d,r11d
    70b3efb075e9:	mov    r11d,edx
    70b3efb075ec:	and    r11d,0x800
    70b3efb075f3:	shl    r11d,0x11
    70b3efb075f7:	or     r10d,r11d
    70b3efb075fa:	btc    r10,0x1d
    70b3efb075ff:	mov    r11d,0xf0000000
    70b3efb07605:	and    r11,r10
    70b3efb07608:	movabs rsi,0xffffffff0fffffff
    70b3efb07612:	and    rbx,rsi
    70b3efb07615:	or     rbx,r11
    70b3efb07618:	pop    r11
    70b3efb0761a:	pop    r10
    70b3efb0761c:	pop    rsi
    70b3efb0761d:	pop    rdx
    70b3efb0761e:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb07626:	mov    eax,0x410444
    70b3efb0762b:	mov    QWORD PTR [r12+0x100],rax
    70b3efb07633:	add    rsp,0x150
    70b3efb0763a:	mov    eax,0x3
    70b3efb0763f:	movabs r11,0x566a970a8390
    70b3efb07649:	jmp    r11
    70b3efb0764c:	jmp    0x70b3efb04a9d
    70b3efb07651:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb07660:	sub    rsp,0x150
    70b3efb07667:	mov    r11,QWORD PTR [r12+0x398]
    70b3efb0766f:	mov    QWORD PTR [rsp],r11
    70b3efb07673:	cmp    DWORD PTR [r12+0x310],0x0
    70b3efb0767c:	je     0x70b3efb0770c
    70b3efb07682:	push   rdx
    70b3efb07683:	push   rsi
    70b3efb07684:	push   r10
    70b3efb07686:	push   r11
    70b3efb07688:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb0768d:	mov    r10d,edx
    70b3efb07690:	and    r10d,0xc0
    70b3efb07697:	shl    r10d,0x18
    70b3efb0769b:	mov    r11d,edx
    70b3efb0769e:	and    r11d,0x1
    70b3efb076a2:	shl    r11d,0x1d
    70b3efb076a6:	or     r10d,r11d
    70b3efb076a9:	mov    r11d,edx
    70b3efb076ac:	and    r11d,0x800
    70b3efb076b3:	shl    r11d,0x11
    70b3efb076b7:	or     r10d,r11d
    70b3efb076ba:	btc    r10,0x1d
    70b3efb076bf:	mov    r11d,0xf0000000
    70b3efb076c5:	and    r11,r10
    70b3efb076c8:	movabs rsi,0xffffffff0fffffff
    70b3efb076d2:	and    rbx,rsi
    70b3efb076d5:	or     rbx,r11
    70b3efb076d8:	pop    r11
    70b3efb076da:	pop    r10
    70b3efb076dc:	pop    rsi
    70b3efb076dd:	pop    rdx
    70b3efb076de:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb076e6:	mov    eax,0x410450
    70b3efb076eb:	mov    QWORD PTR [r12+0x100],rax
    70b3efb076f3:	add    rsp,0x150
    70b3efb076fa:	mov    eax,0x3
    70b3efb076ff:	movabs r11,0x566a970a8390
    70b3efb07709:	jmp    r11
    70b3efb0770c:	jmp    0x70b3efb04ad3
    70b3efb07711:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb07720:	sub    rsp,0x150
    70b3efb07727:	mov    r11,QWORD PTR [r12+0x398]
    70b3efb0772f:	mov    QWORD PTR [rsp],r11
    70b3efb07733:	cmp    DWORD PTR [r12+0x310],0x0
    70b3efb0773c:	je     0x70b3efb077cc
    70b3efb07742:	push   rdx
    70b3efb07743:	push   rsi
    70b3efb07744:	push   r10
    70b3efb07746:	push   r11
    70b3efb07748:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb0774d:	mov    r10d,edx
    70b3efb07750:	and    r10d,0xc0
    70b3efb07757:	shl    r10d,0x18
    70b3efb0775b:	mov    r11d,edx
    70b3efb0775e:	and    r11d,0x1
    70b3efb07762:	shl    r11d,0x1d
    70b3efb07766:	or     r10d,r11d
    70b3efb07769:	mov    r11d,edx
    70b3efb0776c:	and    r11d,0x800
    70b3efb07773:	shl    r11d,0x11
    70b3efb07777:	or     r10d,r11d
    70b3efb0777a:	btc    r10,0x1d
    70b3efb0777f:	mov    r11d,0xf0000000
    70b3efb07785:	and    r11,r10
    70b3efb07788:	movabs rsi,0xffffffff0fffffff
    70b3efb07792:	and    rbx,rsi
    70b3efb07795:	or     rbx,r11
    70b3efb07798:	pop    r11
    70b3efb0779a:	pop    r10
    70b3efb0779c:	pop    rsi
    70b3efb0779d:	pop    rdx
    70b3efb0779e:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb077a6:	mov    eax,0x410474
    70b3efb077ab:	mov    QWORD PTR [r12+0x100],rax
    70b3efb077b3:	add    rsp,0x150
    70b3efb077ba:	mov    eax,0x3
    70b3efb077bf:	movabs r11,0x566a970a8390
    70b3efb077c9:	jmp    r11
    70b3efb077cc:	jmp    0x70b3efb04c52
    70b3efb077d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70b3efb077e0:	sub    rsp,0x150
    70b3efb077e7:	mov    r11,QWORD PTR [r12+0x398]
    70b3efb077ef:	mov    QWORD PTR [rsp],r11
    70b3efb077f3:	cmp    DWORD PTR [r12+0x310],0x0
    70b3efb077fc:	je     0x70b3efb0788c
    70b3efb07802:	push   rdx
    70b3efb07803:	push   rsi
    70b3efb07804:	push   r10
    70b3efb07806:	push   r11
    70b3efb07808:	mov    rdx,QWORD PTR [rsp+0x20]
    70b3efb0780d:	mov    r10d,edx
    70b3efb07810:	and    r10d,0xc0
    70b3efb07817:	shl    r10d,0x18
    70b3efb0781b:	mov    r11d,edx
    70b3efb0781e:	and    r11d,0x1
    70b3efb07822:	shl    r11d,0x1d
    70b3efb07826:	or     r10d,r11d
    70b3efb07829:	mov    r11d,edx
    70b3efb0782c:	and    r11d,0x800
    70b3efb07833:	shl    r11d,0x11
    70b3efb07837:	or     r10d,r11d
    70b3efb0783a:	btc    r10,0x1d
    70b3efb0783f:	mov    r11d,0xf0000000
    70b3efb07845:	and    r11,r10
    70b3efb07848:	movabs rsi,0xffffffff0fffffff
    70b3efb07852:	and    rbx,rsi
    70b3efb07855:	or     rbx,r11
    70b3efb07858:	pop    r11
    70b3efb0785a:	pop    r10
    70b3efb0785c:	pop    rsi
    70b3efb0785d:	pop    rdx
    70b3efb0785e:	mov    QWORD PTR [r12+0x108],rbx
    70b3efb07866:	mov    eax,0x410490
    70b3efb0786b:	mov    QWORD PTR [r12+0x100],rax
    70b3efb07873:	add    rsp,0x150
    70b3efb0787a:	mov    eax,0x3
    70b3efb0787f:	movabs r11,0x566a970a8390
    70b3efb07889:	jmp    r11
    70b3efb0788c:	jmp    0x70b3efb04dea
    70b3efb07891:	nop
    70b3efb07892:	nop
    70b3efb07893:	nop
