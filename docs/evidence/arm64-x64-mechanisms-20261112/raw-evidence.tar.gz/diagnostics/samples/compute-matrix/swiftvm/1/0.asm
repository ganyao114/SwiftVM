
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-matrix/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

00007c1738900000 <.data>:
    7c1738900000:	sub    rsp,0x150
    7c1738900007:	mov    r11,QWORD PTR [r12+0x398]
    7c173890000f:	mov    QWORD PTR [rsp],r11
    7c1738900013:	cmp    DWORD PTR [r12+0x310],0x0
    7c173890001c:	je     0x7c17389000ac
    7c1738900022:	push   rdx
    7c1738900023:	push   rsi
    7c1738900024:	push   r10
    7c1738900026:	push   r11
    7c1738900028:	mov    rdx,QWORD PTR [rsp+0x20]
    7c173890002d:	mov    r10d,edx
    7c1738900030:	and    r10d,0xc0
    7c1738900037:	shl    r10d,0x18
    7c173890003b:	mov    r11d,edx
    7c173890003e:	and    r11d,0x1
    7c1738900042:	shl    r11d,0x1d
    7c1738900046:	or     r10d,r11d
    7c1738900049:	mov    r11d,edx
    7c173890004c:	and    r11d,0x800
    7c1738900053:	shl    r11d,0x11
    7c1738900057:	or     r10d,r11d
    7c173890005a:	btc    r10,0x1d
    7c173890005f:	mov    r11d,0xf0000000
    7c1738900065:	and    r11,r10
    7c1738900068:	movabs rsi,0xffffffff0fffffff
    7c1738900072:	and    rbx,rsi
    7c1738900075:	or     rbx,r11
    7c1738900078:	pop    r11
    7c173890007a:	pop    r10
    7c173890007c:	pop    rsi
    7c173890007d:	pop    rdx
    7c173890007e:	mov    QWORD PTR [r12+0x108],rbx
    7c1738900086:	mov    eax,0x410168
    7c173890008b:	mov    QWORD PTR [r12+0x100],rax
    7c1738900093:	add    rsp,0x150
    7c173890009a:	mov    eax,0x3
    7c173890009f:	movabs r11,0x59b8d047a390
    7c17389000a9:	jmp    r11
    7c17389000ac:	mov    r13d,0x420000
    7c17389000b2:	mov    QWORD PTR [r12+0x40],r13
    7c17389000b7:	movabs r13,0x100000001
    7c17389000c1:	mov    r14d,0x0
    7c17389000c7:	mov    QWORD PTR [r12+0x110],r13
    7c17389000cf:	mov    QWORD PTR [r12+0x118],r14
    7c17389000d7:	movabs r13,0x3fa0000000000000
    7c17389000e1:	mov    QWORD PTR [r12+0x50],r13
    7c17389000e6:	movabs r13,0x4100000041
    7c17389000f0:	mov    r14d,0x0
    7c17389000f6:	mov    QWORD PTR [r12+0x120],r13
    7c17389000fe:	mov    QWORD PTR [r12+0x128],r14
    7c1738900106:	mov    r13d,0x4204c0
    7c173890010c:	mov    r14,QWORD PTR [r13+0x0]
    7c1738900110:	mov    r13d,0x0
    7c1738900116:	mov    QWORD PTR [r12+0x130],r14
    7c173890011e:	mov    QWORD PTR [r12+0x138],r13
    7c1738900126:	movabs r13,0x3fc0000000000000
    7c1738900130:	movabs r14,0x3fc0000000000000
    7c173890013a:	mov    QWORD PTR [r12+0x140],r13
    7c1738900142:	mov    QWORD PTR [r12+0x148],r14
    7c173890014a:	mov    r13d,0x2
    7c1738900150:	mov    QWORD PTR [r12+0x40],r13
    7c1738900155:	movabs r13,0x200000002
    7c173890015f:	mov    r14d,0x0
    7c1738900165:	mov    QWORD PTR [r12+0x150],r13
    7c173890016d:	mov    QWORD PTR [r12+0x158],r14
    7c1738900175:	mov    r13d,0x420000
    7c173890017b:	mov    QWORD PTR [r12+0x58],r13
    7c1738900180:	mov    r13,QWORD PTR [r12+0x50]
    7c1738900185:	and    r13,0xffffffffffffffff
    7c1738900189:	mov    QWORD PTR [r12+0x160],r13
    7c1738900191:	mov    QWORD PTR [r12+0x168],r13
    7c1738900199:	mov    r13d,0x2
    7c173890019f:	mov    QWORD PTR [r12+0x170],r13
    7c17389001a7:	mov    QWORD PTR [r12+0x178],r13
    7c17389001af:	mov    r13d,0x4204d0
    7c17389001b5:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c17389001bb:	movdqa xmm0,xmm2
    7c17389001bf:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c17389001c9:	mov    r13d,0x0
    7c17389001cf:	mov    QWORD PTR [r12+0x48],r13
    7c17389001d4:	mov    r13d,0x430000
    7c17389001da:	add    r13,0x518
    7c17389001e1:	mov    QWORD PTR [r12+0x40],r13
    7c17389001e6:	mov    r13d,0x430000
    7c17389001ec:	add    r13,0x720
    7c17389001f3:	mov    QWORD PTR [r12+0x50],r13
    7c17389001f8:	jmp    0x7c17389001fd
    7c17389001fd:	mov    r13,QWORD PTR [r12+0x180]
    7c1738900205:	mov    r14,QWORD PTR [r12+0x188]
    7c173890020d:	mov    r15d,0x0
    7c1738900213:	and    r13,0xffffffffffffffff
    7c1738900217:	mov    ecx,0xffffffff
    7c173890021c:	and    r13,rcx
    7c173890021f:	mov    rcx,r13
    7c1738900222:	mov    rbp,r15
    7c1738900225:	or     rbp,rcx
    7c1738900228:	and    r14,0xffffffffffffffff
    7c173890022c:	mov    ecx,0xffffffff
    7c1738900231:	and    r14,rcx
    7c1738900234:	shl    r14,0x20
    7c1738900238:	mov    rcx,r14
    7c173890023b:	or     rbp,rcx
    7c173890023e:	mov    QWORD PTR [r12+0x210],rbp
    7c1738900246:	mov    QWORD PTR [r12+0x218],r15
    7c173890024e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c1738900258:	movdqa xmm2,xmm0
    7c173890025c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c1738900266:	movdqa xmm3,xmm0
    7c173890026a:	movdqa xmm1,xmm3
    7c173890026e:	psubd  xmm2,xmm1
    7c1738900272:	movdqa xmm14,xmm2
    7c1738900277:	movdqa xmm1,xmm14
    7c173890027c:	movq   rax,xmm1
    7c1738900281:	mov    r13,rax
    7c1738900284:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c173890028e:	movdqa xmm2,xmm0
    7c1738900292:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c173890029c:	movdqa xmm4,xmm0
    7c17389002a0:	movdqa xmm1,xmm4
    7c17389002a4:	paddq  xmm2,xmm1
    7c17389002a8:	movdqa xmm0,xmm2
    7c17389002ac:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c17389002b6:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c17389002c0:	movdqa xmm2,xmm0
    7c17389002c4:	movdqa xmm1,xmm2
    7c17389002c8:	paddd  xmm3,xmm1
    7c17389002cc:	movdqa xmm14,xmm3
    7c17389002d1:	movdqa xmm1,xmm14
    7c17389002d6:	movq   rax,xmm1
    7c17389002db:	mov    r14,rax
    7c17389002de:	mov    r15d,0x0
    7c17389002e4:	mov    QWORD PTR [r12+0x130],r14
    7c17389002ec:	mov    QWORD PTR [r12+0x138],r15
    7c17389002f4:	mov    r14d,0x0
    7c17389002fa:	mov    r15,r13
    7c17389002fd:	mov    ecx,0xffffffff
    7c1738900302:	and    r15,rcx
    7c1738900305:	and    r15,0xffffffffffffffff
    7c1738900309:	mov    rcx,r15
    7c173890030c:	mov    rbp,r14
    7c173890030f:	or     rbp,rcx
    7c1738900312:	shr    r13,0x20
    7c1738900316:	mov    ecx,0xffffffff
    7c173890031b:	and    r13,rcx
    7c173890031e:	and    r13,0xffffffffffffffff
    7c1738900322:	mov    rcx,r13
    7c1738900325:	or     r14,rcx
    7c1738900328:	mov    QWORD PTR [r12+0x220],rbp
    7c1738900330:	mov    QWORD PTR [r12+0x228],r14
    7c1738900338:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c1738900342:	movdqa xmm2,xmm0
    7c1738900346:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c1738900350:	movdqa xmm3,xmm0
    7c1738900354:	movdqa xmm1,xmm3
    7c1738900358:	paddd  xmm2,xmm1
    7c173890035c:	movdqa xmm14,xmm2
    7c1738900361:	movdqa xmm1,xmm14
    7c1738900366:	movq   rax,xmm1
    7c173890036b:	mov    r13,rax
    7c173890036e:	mov    r14d,0x0
    7c1738900374:	mov    QWORD PTR [r12+0x210],r13
    7c173890037c:	mov    QWORD PTR [r12+0x218],r14
    7c1738900384:	lea    r13,[r12]
    7c1738900388:	movabs r14,0xb6e61da31
    7c1738900392:	mov    r15d,0x4101c4
    7c1738900398:	mov    rdx,QWORD PTR [rsp]
    7c173890039c:	mov    r10d,edx
    7c173890039f:	and    r10d,0xc0
    7c17389003a6:	shl    r10d,0x18
    7c17389003aa:	mov    r11d,edx
    7c17389003ad:	and    r11d,0x1
    7c17389003b1:	shl    r11d,0x1d
    7c17389003b5:	or     r10d,r11d
    7c17389003b8:	mov    r11d,edx
    7c17389003bb:	and    r11d,0x800
    7c17389003c2:	shl    r11d,0x11
    7c17389003c6:	or     r10d,r11d
    7c17389003c9:	btc    r10,0x1d
    7c17389003ce:	mov    r11d,0xf0000000
    7c17389003d4:	and    r11,r10
    7c17389003d7:	movabs rsi,0xffffffff0fffffff
    7c17389003e1:	and    rbx,rsi
    7c17389003e4:	or     rbx,r11
    7c17389003e7:	mov    QWORD PTR [r12+0x378],0x3
    7c17389003f3:	mov    QWORD PTR [r12+0x108],rbx
    7c17389003fb:	stmxcsr DWORD PTR [r12-0x28]
    7c1738900401:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738900407:	movabs r11,0x59b8d02e0dc0
    7c1738900411:	mov    rdi,r13
    7c1738900414:	mov    rsi,r14
    7c1738900417:	mov    rdx,r15
    7c173890041a:	call   r11
    7c173890041d:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738900423:	mov    rbx,QWORD PTR [r12+0x108]
    7c173890042b:	mov    QWORD PTR [r12+0x378],0x2
    7c1738900437:	mov    rbp,rax
    7c173890043a:	mov    r13,QWORD PTR [r12+0x210]
    7c1738900442:	mov    r14d,0x0
    7c1738900448:	mov    r15,r13
    7c173890044b:	mov    ecx,0xffffffff
    7c1738900450:	and    r15,rcx
    7c1738900453:	and    r15,0xffffffffffffffff
    7c1738900457:	mov    rcx,r15
    7c173890045a:	mov    rbp,r14
    7c173890045d:	or     rbp,rcx
    7c1738900460:	shr    r13,0x20
    7c1738900464:	mov    ecx,0xffffffff
    7c1738900469:	and    r13,rcx
    7c173890046c:	and    r13,0xffffffffffffffff
    7c1738900470:	mov    rcx,r13
    7c1738900473:	or     r14,rcx
    7c1738900476:	mov    QWORD PTR [r12+0x210],rbp
    7c173890047e:	mov    QWORD PTR [r12+0x218],r14
    7c1738900486:	lea    r13,[r12]
    7c173890048a:	movabs r14,0xb6e61da10
    7c1738900494:	mov    r15d,0x4101cc
    7c173890049a:	mov    QWORD PTR [r12+0x378],0x3
    7c17389004a6:	mov    QWORD PTR [r12+0x108],rbx
    7c17389004ae:	stmxcsr DWORD PTR [r12-0x28]
    7c17389004b4:	ldmxcsr DWORD PTR [r12-0x38]
    7c17389004ba:	movabs r11,0x59b8d02e0dc0
    7c17389004c4:	mov    rdi,r13
    7c17389004c7:	mov    rsi,r14
    7c17389004ca:	mov    rdx,r15
    7c17389004cd:	call   r11
    7c17389004d0:	ldmxcsr DWORD PTR [r12-0x28]
    7c17389004d6:	mov    rbx,QWORD PTR [r12+0x108]
    7c17389004de:	mov    QWORD PTR [r12+0x378],0x2
    7c17389004ea:	mov    rbp,rax
    7c17389004ed:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c17389004f7:	movdqa xmm2,xmm0
    7c17389004fb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c1738900505:	movdqa xmm3,xmm0
    7c1738900509:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738900511:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c173890051c:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738900524:	movdqa xmm0,xmm2
    7c1738900528:	movdqa xmm1,xmm3
    7c173890052c:	movq   rax,xmm0
    7c1738900531:	add    rax,rax
    7c1738900534:	je     0x7c173890054a
    7c1738900536:	shr    rax,0x35
    7c173890053a:	sub    eax,0x201
    7c173890053f:	cmp    eax,0x3fc
    7c1738900544:	ja     0x7c1738904e57
    7c173890054a:	movdqa xmm14,xmm0
    7c173890054f:	psrldq xmm14,0x8
    7c1738900555:	movq   rax,xmm14
    7c173890055a:	add    rax,rax
    7c173890055d:	je     0x7c1738900573
    7c173890055f:	shr    rax,0x35
    7c1738900563:	sub    eax,0x201
    7c1738900568:	cmp    eax,0x3fc
    7c173890056d:	ja     0x7c1738904e57
    7c1738900573:	movq   rax,xmm1
    7c1738900578:	add    rax,rax
    7c173890057b:	je     0x7c1738900591
    7c173890057d:	shr    rax,0x35
    7c1738900581:	sub    eax,0x201
    7c1738900586:	cmp    eax,0x3fc
    7c173890058b:	ja     0x7c1738904e57
    7c1738900591:	movdqa xmm14,xmm1
    7c1738900596:	psrldq xmm14,0x8
    7c173890059c:	movq   rax,xmm14
    7c17389005a1:	add    rax,rax
    7c17389005a4:	je     0x7c17389005ba
    7c17389005a6:	shr    rax,0x35
    7c17389005aa:	sub    eax,0x201
    7c17389005af:	cmp    eax,0x3fc
    7c17389005b4:	ja     0x7c1738904e57
    7c17389005ba:	mulpd  xmm0,xmm1
    7c17389005be:	movdqa xmm4,xmm0
    7c17389005c2:	movdqa xmm0,xmm4
    7c17389005c6:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c17389005d0:	mov    r13,QWORD PTR [r12+0x48]
    7c17389005d5:	mov    r14,QWORD PTR [r12+0x50]
    7c17389005da:	mov    rcx,r13
    7c17389005dd:	add    r14,rcx
    7c17389005e0:	stmxcsr DWORD PTR [rsp+0x114]
    7c17389005e8:	ldmxcsr DWORD PTR [rsp+0x110]
    7c17389005f0:	mov    r11d,DWORD PTR [rsp+0x114]
    7c17389005f8:	shr    r11d,1
    7c17389005fb:	and    r11d,0x10
    7c17389005ff:	or     DWORD PTR [r12+0x314],r11d
    7c1738900607:	movdqu XMMWORD PTR [r14],xmm4
    7c173890060c:	mov    r14d,0x0
    7c1738900612:	mov    DWORD PTR [r12+0x32c],r14d
    7c173890061a:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c1738900624:	movdqa xmm2,xmm0
    7c1738900628:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c1738900632:	movdqa xmm3,xmm0
    7c1738900636:	stmxcsr DWORD PTR [rsp+0x110]
    7c173890063e:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c1738900649:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738900651:	movdqa xmm0,xmm2
    7c1738900655:	movdqa xmm1,xmm3
    7c1738900659:	movq   rax,xmm0
    7c173890065e:	add    rax,rax
    7c1738900661:	je     0x7c1738900677
    7c1738900663:	shr    rax,0x35
    7c1738900667:	sub    eax,0x201
    7c173890066c:	cmp    eax,0x3fc
    7c1738900671:	ja     0x7c1738904e7b
    7c1738900677:	movdqa xmm14,xmm0
    7c173890067c:	psrldq xmm14,0x8
    7c1738900682:	movq   rax,xmm14
    7c1738900687:	add    rax,rax
    7c173890068a:	je     0x7c17389006a0
    7c173890068c:	shr    rax,0x35
    7c1738900690:	sub    eax,0x201
    7c1738900695:	cmp    eax,0x3fc
    7c173890069a:	ja     0x7c1738904e7b
    7c17389006a0:	movq   rax,xmm1
    7c17389006a5:	add    rax,rax
    7c17389006a8:	je     0x7c17389006be
    7c17389006aa:	shr    rax,0x35
    7c17389006ae:	sub    eax,0x201
    7c17389006b3:	cmp    eax,0x3fc
    7c17389006b8:	ja     0x7c1738904e7b
    7c17389006be:	movdqa xmm14,xmm1
    7c17389006c3:	psrldq xmm14,0x8
    7c17389006c9:	movq   rax,xmm14
    7c17389006ce:	add    rax,rax
    7c17389006d1:	je     0x7c17389006e7
    7c17389006d3:	shr    rax,0x35
    7c17389006d7:	sub    eax,0x201
    7c17389006dc:	cmp    eax,0x3fc
    7c17389006e1:	ja     0x7c1738904e7b
    7c17389006e7:	mulpd  xmm0,xmm1
    7c17389006eb:	movdqa xmm4,xmm0
    7c17389006ef:	movdqa xmm0,xmm4
    7c17389006f3:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c17389006fd:	mov    r14,QWORD PTR [r12+0x40]
    7c1738900702:	mov    rcx,r13
    7c1738900705:	add    r14,rcx
    7c1738900708:	stmxcsr DWORD PTR [rsp+0x114]
    7c1738900710:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738900718:	mov    r11d,DWORD PTR [rsp+0x114]
    7c1738900720:	shr    r11d,1
    7c1738900723:	and    r11d,0x10
    7c1738900727:	or     DWORD PTR [r12+0x314],r11d
    7c173890072f:	movdqu XMMWORD PTR [r14],xmm4
    7c1738900734:	mov    r14d,0x0
    7c173890073a:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738900742:	add    r13,0x10
    7c1738900746:	mov    QWORD PTR [r12+0x48],r13
    7c173890074b:	sub    r13,0x200
    7c1738900752:	mov    rcx,QWORD PTR [r12+0x380]
    7c173890075a:	jrcxz  0x7c1738900761
    7c173890075c:	jmp    0x7c1738906fd6
    7c1738900761:	pushf
    7c1738900762:	pop    r11
    7c1738900764:	mov    QWORD PTR [rsp],r11
    7c1738900768:	jne    0x7c17389001fd
    7c173890076e:	jmp    0x7c1738900773
    7c1738900773:	mov    r13,QWORD PTR [r12+0xf8]
    7c173890077b:	sub    r13,0x150
    7c1738900782:	mov    QWORD PTR [r12+0xf8],r13
    7c173890078a:	mov    r14,QWORD PTR [r12+0x50]
    7c173890078f:	mov    r15,r14
    7c1738900792:	add    r15,0x80
    7c1738900799:	mov    rbp,r15
    7c173890079c:	add    rbp,0x10
    7c17389007a0:	movdqu xmm2,XMMWORD PTR [r15]
    7c17389007a5:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c17389007aa:	movdqa xmm0,xmm2
    7c17389007ae:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c17389007b8:	movdqa xmm0,xmm3
    7c17389007bc:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c17389007c6:	mov    r15d,0x0
    7c17389007cc:	mov    QWORD PTR [r12+0x48],r15
    7c17389007d1:	add    r14,0x40
    7c17389007d5:	mov    r15,r14
    7c17389007d8:	add    r15,0x10
    7c17389007dc:	movdqu xmm2,XMMWORD PTR [r14]
    7c17389007e1:	movdqu xmm3,XMMWORD PTR [r15]
    7c17389007e6:	movdqa xmm0,xmm2
    7c17389007ea:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c17389007f4:	movdqa xmm0,xmm3
    7c17389007f8:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c1738900802:	add    r13,0x120
    7c1738900809:	mov    r14,r13
    7c173890080c:	add    r14,0x8
    7c1738900810:	mov    r15,QWORD PTR [r12+0x1c0]
    7c1738900818:	mov    rbp,QWORD PTR [r12+0x1b0]
    7c1738900820:	mov    QWORD PTR [r13+0x0],r15
    7c1738900824:	mov    r13d,0x0
    7c173890082a:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900832:	mov    QWORD PTR [r14],rbp
    7c1738900835:	mov    r13d,0x0
    7c173890083b:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900843:	mov    r13d,0x0
    7c1738900849:	mov    r14d,0x0
    7c173890084f:	mov    QWORD PTR [r12+0x1b0],r13
    7c1738900857:	mov    QWORD PTR [r12+0x1b8],r14
    7c173890085f:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738900867:	mov    r14,r13
    7c173890086a:	add    r14,0x100
    7c1738900871:	mov    r15,r14
    7c1738900874:	add    r15,0x8
    7c1738900878:	mov    rbp,QWORD PTR [r12+0x200]
    7c1738900880:	mov    r8,QWORD PTR [r12+0x1f0]
    7c1738900888:	mov    QWORD PTR [r14],rbp
    7c173890088b:	mov    r14d,0x0
    7c1738900891:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738900899:	mov    QWORD PTR [r15],r8
    7c173890089c:	mov    r14d,0x0
    7c17389008a2:	mov    DWORD PTR [r12+0x32c],r14d
    7c17389008aa:	mov    r14,r13
    7c17389008ad:	add    r14,0xe0
    7c17389008b4:	mov    r15,r14
    7c17389008b7:	add    r15,0x10
    7c17389008bb:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c17389008c5:	movdqa xmm2,xmm0
    7c17389008c9:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c17389008d3:	movdqa xmm3,xmm0
    7c17389008d7:	movdqu XMMWORD PTR [r14],xmm2
    7c17389008dc:	mov    r14d,0x0
    7c17389008e2:	mov    DWORD PTR [r12+0x32c],r14d
    7c17389008ea:	movdqu XMMWORD PTR [r15],xmm3
    7c17389008ef:	mov    r14d,0x0
    7c17389008f5:	mov    DWORD PTR [r12+0x32c],r14d
    7c17389008fd:	mov    r14,QWORD PTR [r12+0x50]
    7c1738900902:	mov    r15,r14
    7c1738900905:	add    r15,0xc0
    7c173890090c:	mov    rbp,r15
    7c173890090f:	add    rbp,0x10
    7c1738900913:	movdqu xmm2,XMMWORD PTR [r15]
    7c1738900918:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c173890091d:	movdqa xmm0,xmm2
    7c1738900921:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c173890092b:	movdqa xmm0,xmm3
    7c173890092f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c1738900939:	add    r13,0x110
    7c1738900940:	mov    r15,r13
    7c1738900943:	add    r15,0x8
    7c1738900947:	mov    rbp,QWORD PTR [r12+0x1e0]
    7c173890094f:	mov    r8,QWORD PTR [r12+0x1d0]
    7c1738900957:	mov    QWORD PTR [r13+0x0],rbp
    7c173890095b:	mov    r13d,0x0
    7c1738900961:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900969:	mov    QWORD PTR [r15],r8
    7c173890096c:	mov    r13d,0x0
    7c1738900972:	mov    DWORD PTR [r12+0x32c],r13d
    7c173890097a:	mov    r13,r14
    7c173890097d:	add    r13,0x10
    7c1738900981:	movdqu xmm2,XMMWORD PTR [r14]
    7c1738900986:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c173890098c:	movdqa xmm0,xmm2
    7c1738900990:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c173890099a:	movdqa xmm0,xmm3
    7c173890099e:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c17389009a8:	mov    r13,QWORD PTR [r12+0xf8]
    7c17389009b0:	mov    r14,r13
    7c17389009b3:	add    r14,0x130
    7c17389009ba:	mov    r15,r14
    7c17389009bd:	add    r15,0x8
    7c17389009c1:	mov    rbp,QWORD PTR [r12+0x1a0]
    7c17389009c9:	mov    r8,QWORD PTR [r12+0x190]
    7c17389009d1:	mov    QWORD PTR [r14],rbp
    7c17389009d4:	mov    r14d,0x0
    7c17389009da:	mov    DWORD PTR [r12+0x32c],r14d
    7c17389009e2:	mov    QWORD PTR [r15],r8
    7c17389009e5:	mov    r14d,0x0
    7c17389009eb:	mov    DWORD PTR [r12+0x32c],r14d
    7c17389009f3:	mov    r14,QWORD PTR [r12+0x50]
    7c17389009f8:	mov    r15,r14
    7c17389009fb:	add    r15,0x140
    7c1738900a02:	mov    rbp,r15
    7c1738900a05:	add    rbp,0x10
    7c1738900a09:	movdqu xmm2,XMMWORD PTR [r15]
    7c1738900a0e:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c1738900a13:	movdqa xmm0,xmm2
    7c1738900a17:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c1738900a21:	movdqa xmm0,xmm3
    7c1738900a25:	movdqu XMMWORD PTR [r12+0x190],xmm0
    7c1738900a2f:	add    r13,0xc0
    7c1738900a36:	mov    r15,r13
    7c1738900a39:	add    r15,0x10
    7c1738900a3d:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c1738900a47:	movdqa xmm2,xmm0
    7c1738900a4b:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c1738900a55:	movdqa xmm3,xmm0
    7c1738900a59:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c1738900a5f:	mov    r13d,0x0
    7c1738900a65:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900a6d:	movdqu XMMWORD PTR [r15],xmm3
    7c1738900a72:	mov    r13d,0x0
    7c1738900a78:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900a80:	add    r14,0x100
    7c1738900a87:	mov    r13,r14
    7c1738900a8a:	add    r13,0x10
    7c1738900a8e:	movdqu xmm2,XMMWORD PTR [r14]
    7c1738900a93:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c1738900a99:	movdqa xmm0,xmm2
    7c1738900a9d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c1738900aa7:	movdqa xmm0,xmm3
    7c1738900aab:	movdqu XMMWORD PTR [r12+0x300],xmm0
    7c1738900ab5:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738900abd:	mov    r14,r13
    7c1738900ac0:	add    r14,0x140
    7c1738900ac7:	mov    r15,QWORD PTR [r12+0xe8]
    7c1738900acf:	mov    QWORD PTR [r14],r15
    7c1738900ad2:	mov    r14d,0x0
    7c1738900ad8:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738900ae0:	mov    r14,QWORD PTR [r12+0x50]
    7c1738900ae5:	mov    r15,r14
    7c1738900ae8:	add    r15,0x180
    7c1738900aef:	mov    rbp,r15
    7c1738900af2:	add    rbp,0x10
    7c1738900af6:	movdqu xmm2,XMMWORD PTR [r15]
    7c1738900afb:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c1738900b00:	movdqa xmm0,xmm2
    7c1738900b04:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    7c1738900b0e:	movdqa xmm0,xmm3
    7c1738900b12:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    7c1738900b1c:	mov    r15,r14
    7c1738900b1f:	add    r15,0x1c0
    7c1738900b26:	mov    rbp,r15
    7c1738900b29:	add    rbp,0x10
    7c1738900b2d:	movdqu xmm2,XMMWORD PTR [r15]
    7c1738900b32:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c1738900b37:	movdqa xmm0,xmm2
    7c1738900b3b:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c1738900b45:	movdqa xmm0,xmm3
    7c1738900b49:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    7c1738900b53:	add    r13,0x20
    7c1738900b57:	mov    r15,r13
    7c1738900b5a:	add    r15,0x10
    7c1738900b5e:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c1738900b68:	movdqa xmm2,xmm0
    7c1738900b6c:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c1738900b76:	movdqa xmm3,xmm0
    7c1738900b7a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c1738900b80:	mov    r13d,0x0
    7c1738900b86:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900b8e:	movdqu XMMWORD PTR [r15],xmm3
    7c1738900b93:	mov    r13d,0x0
    7c1738900b99:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900ba1:	mov    r13,r14
    7c1738900ba4:	add    r13,0x60
    7c1738900ba8:	mov    r15,r13
    7c1738900bab:	add    r15,0x10
    7c1738900baf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c1738900bb5:	movdqu xmm3,XMMWORD PTR [r15]
    7c1738900bba:	movdqa xmm0,xmm2
    7c1738900bbe:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c1738900bc8:	movdqa xmm0,xmm3
    7c1738900bcc:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c1738900bd6:	add    r14,0x20
    7c1738900bda:	mov    r13,r14
    7c1738900bdd:	add    r13,0x10
    7c1738900be1:	movdqu xmm2,XMMWORD PTR [r14]
    7c1738900be6:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    7c1738900bec:	movdqa xmm0,xmm2
    7c1738900bf0:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    7c1738900bfa:	movdqa xmm0,xmm3
    7c1738900bfe:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
    7c1738900c08:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738900c10:	mov    r14,r13
    7c1738900c13:	add    r14,0x60
    7c1738900c17:	mov    r15,r14
    7c1738900c1a:	add    r15,0x10
    7c1738900c1e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c1738900c28:	movdqa xmm2,xmm0
    7c1738900c2c:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c1738900c36:	movdqa xmm3,xmm0
    7c1738900c3a:	movdqu XMMWORD PTR [r14],xmm2
    7c1738900c3f:	mov    r14d,0x0
    7c1738900c45:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738900c4d:	movdqu XMMWORD PTR [r15],xmm3
    7c1738900c52:	mov    r14d,0x0
    7c1738900c58:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738900c60:	mov    r14,QWORD PTR [r12+0x50]
    7c1738900c65:	mov    r15,r14
    7c1738900c68:	add    r15,0xe0
    7c1738900c6f:	mov    rbp,r15
    7c1738900c72:	add    rbp,0x10
    7c1738900c76:	movdqu xmm2,XMMWORD PTR [r15]
    7c1738900c7b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c1738900c80:	movdqa xmm0,xmm2
    7c1738900c84:	movdqu XMMWORD PTR [r12+0x200],xmm0
    7c1738900c8e:	movdqa xmm0,xmm3
    7c1738900c92:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    7c1738900c9c:	add    r13,0xa0
    7c1738900ca3:	mov    r15,r13
    7c1738900ca6:	add    r15,0x10
    7c1738900caa:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c1738900cb4:	movdqa xmm2,xmm0
    7c1738900cb8:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c1738900cc2:	movdqa xmm3,xmm0
    7c1738900cc6:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c1738900ccc:	mov    r13d,0x0
    7c1738900cd2:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900cda:	movdqu XMMWORD PTR [r15],xmm3
    7c1738900cdf:	mov    r13d,0x0
    7c1738900ce5:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900ced:	mov    r13,r14
    7c1738900cf0:	add    r13,0xa0
    7c1738900cf7:	mov    r15,r13
    7c1738900cfa:	add    r15,0x10
    7c1738900cfe:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c1738900d04:	movdqu xmm3,XMMWORD PTR [r15]
    7c1738900d09:	movdqa xmm0,xmm2
    7c1738900d0d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c1738900d17:	movdqa xmm0,xmm3
    7c1738900d1b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c1738900d25:	mov    r13,r14
    7c1738900d28:	add    r13,0x120
    7c1738900d2f:	mov    r15,r13
    7c1738900d32:	add    r15,0x10
    7c1738900d36:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    7c1738900d3c:	movdqu xmm5,XMMWORD PTR [r15]
    7c1738900d41:	movdqa xmm0,xmm4
    7c1738900d45:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7c1738900d4f:	movdqa xmm0,xmm5
    7c1738900d53:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7c1738900d5d:	add    r14,0x160
    7c1738900d64:	mov    r13,r14
    7c1738900d67:	add    r13,0x10
    7c1738900d6b:	movdqu xmm4,XMMWORD PTR [r14]
    7c1738900d70:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7c1738900d76:	movdqa xmm0,xmm4
    7c1738900d7a:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    7c1738900d84:	movdqa xmm0,xmm5
    7c1738900d88:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
    7c1738900d92:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738900d9a:	mov    r14,r13
    7c1738900d9d:	add    r14,0x80
    7c1738900da4:	mov    r15,r14
    7c1738900da7:	add    r15,0x10
    7c1738900dab:	movdqu XMMWORD PTR [r14],xmm3
    7c1738900db0:	mov    r14d,0x0
    7c1738900db6:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738900dbe:	movdqu XMMWORD PTR [r15],xmm2
    7c1738900dc3:	mov    r14d,0x0
    7c1738900dc9:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738900dd1:	mov    r14,QWORD PTR [r12+0x50]
    7c1738900dd6:	mov    r15,r14
    7c1738900dd9:	add    r15,0x1a0
    7c1738900de0:	mov    rbp,r15
    7c1738900de3:	add    rbp,0x10
    7c1738900de7:	movdqu xmm2,XMMWORD PTR [r15]
    7c1738900dec:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c1738900df1:	movdqa xmm0,xmm2
    7c1738900df5:	movdqu XMMWORD PTR [r12+0x290],xmm0
    7c1738900dff:	movdqa xmm0,xmm3
    7c1738900e03:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
    7c1738900e0d:	add    r14,0x1e0
    7c1738900e14:	mov    r15,r14
    7c1738900e17:	add    r15,0x10
    7c1738900e1b:	movdqu xmm2,XMMWORD PTR [r14]
    7c1738900e20:	movdqu xmm3,XMMWORD PTR [r15]
    7c1738900e25:	movdqa xmm0,xmm2
    7c1738900e29:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c1738900e33:	movdqa xmm0,xmm3
    7c1738900e37:	movdqu XMMWORD PTR [r12+0x280],xmm0
    7c1738900e41:	mov    r14d,0x430000
    7c1738900e47:	add    r14,0x920
    7c1738900e4e:	mov    QWORD PTR [r12+0x50],r14
    7c1738900e53:	mov    r14,r13
    7c1738900e56:	add    r14,0x40
    7c1738900e5a:	mov    r15,r14
    7c1738900e5d:	add    r15,0x10
    7c1738900e61:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c1738900e6b:	movdqa xmm5,xmm0
    7c1738900e6f:	movdqu XMMWORD PTR [r14],xmm4
    7c1738900e74:	mov    r14d,0x0
    7c1738900e7a:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738900e82:	movdqu XMMWORD PTR [r15],xmm5
    7c1738900e87:	mov    r14d,0x0
    7c1738900e8d:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738900e95:	mov    r14,r13
    7c1738900e98:	add    r14,0x10
    7c1738900e9c:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7c1738900ea2:	mov    r13d,0x0
    7c1738900ea8:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900eb0:	movdqu XMMWORD PTR [r14],xmm2
    7c1738900eb5:	mov    r13d,0x0
    7c1738900ebb:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738900ec3:	jmp    0x7c1738900ec8
    7c1738900ec8:	mov    r13d,0x0
    7c1738900ece:	mov    QWORD PTR [r12+0x58],r13
    7c1738900ed3:	jmp    0x7c1738900ed8
    7c1738900ed8:	mov    r13,QWORD PTR [r12+0x58]
    7c1738900edd:	mov    r14,QWORD PTR [r12+0x40]
    7c1738900ee2:	mov    rcx,r13
    7c1738900ee5:	add    r14,rcx
    7c1738900ee8:	mov    QWORD PTR [r12+0x60],r14
    7c1738900eed:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    7c1738900ef7:	movdqa xmm2,xmm0
    7c1738900efb:	movdqa xmm1,xmm2
    7c1738900eff:	por    xmm2,xmm1
    7c1738900f03:	movdqa xmm0,xmm2
    7c1738900f07:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    7c1738900f11:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7c1738900f1b:	movdqa xmm2,xmm0
    7c1738900f1f:	movdqa xmm1,xmm2
    7c1738900f23:	por    xmm2,xmm1
    7c1738900f27:	movdqa xmm0,xmm2
    7c1738900f2b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c1738900f35:	add    r14,0x30
    7c1738900f39:	mov    r13,r14
    7c1738900f3c:	add    r13,0x8
    7c1738900f40:	mov    r15,QWORD PTR [r14]
    7c1738900f43:	mov    r14,QWORD PTR [r13+0x0]
    7c1738900f47:	mov    r13d,0x0
    7c1738900f4d:	mov    QWORD PTR [r12+0x130],r15
    7c1738900f55:	mov    QWORD PTR [r12+0x138],r13
    7c1738900f5d:	mov    r13d,0x0
    7c1738900f63:	mov    QWORD PTR [r12+0x280],r14
    7c1738900f6b:	mov    QWORD PTR [r12+0x288],r13
    7c1738900f73:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c1738900f7d:	movdqa xmm2,xmm0
    7c1738900f81:	movdqa xmm1,xmm2
    7c1738900f85:	por    xmm2,xmm1
    7c1738900f89:	movdqa xmm0,xmm2
    7c1738900f8d:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    7c1738900f97:	mov    r13,QWORD PTR [r12+0x60]
    7c1738900f9c:	mov    r14,r13
    7c1738900f9f:	add    r14,0x20
    7c1738900fa3:	mov    r15,r14
    7c1738900fa6:	add    r15,0x8
    7c1738900faa:	mov    rbp,QWORD PTR [r14]
    7c1738900fad:	mov    r14,QWORD PTR [r15]
    7c1738900fb0:	mov    r15d,0x0
    7c1738900fb6:	mov    QWORD PTR [r12+0x150],rbp
    7c1738900fbe:	mov    QWORD PTR [r12+0x158],r15
    7c1738900fc6:	mov    r15d,0x0
    7c1738900fcc:	mov    QWORD PTR [r12+0x140],r14
    7c1738900fd4:	mov    QWORD PTR [r12+0x148],r15
    7c1738900fdc:	add    r13,0x10
    7c1738900fe0:	mov    r14,r13
    7c1738900fe3:	add    r14,0x8
    7c1738900fe7:	mov    r15,QWORD PTR [r13+0x0]
    7c1738900feb:	mov    r13,QWORD PTR [r14]
    7c1738900fee:	mov    r14d,0x0
    7c1738900ff4:	mov    QWORD PTR [r12+0x170],r15
    7c1738900ffc:	mov    QWORD PTR [r12+0x178],r14
    7c1738901004:	mov    r14d,0x0
    7c173890100a:	mov    QWORD PTR [r12+0x160],r13
    7c1738901012:	mov    QWORD PTR [r12+0x168],r14
    7c173890101a:	mov    r13,QWORD PTR [r12+0x60]
    7c173890101f:	mov    r14d,0x8
    7c1738901025:	mov    r15,QWORD PTR [r13+0x0]
    7c1738901029:	mov    QWORD PTR [r12+0x180],r15
    7c1738901031:	mov    QWORD PTR [r12+0x188],r15
    7c1738901039:	mov    rcx,r14
    7c173890103c:	add    r13,rcx
    7c173890103f:	mov    QWORD PTR [r12+0x60],r13
    7c1738901044:	mov    r14,QWORD PTR [r13+0x0]
    7c1738901048:	mov    r13d,0x0
    7c173890104e:	mov    QWORD PTR [r12+0x230],r14
    7c1738901056:	mov    QWORD PTR [r12+0x238],r13
    7c173890105e:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738901066:	mov    r14,r13
    7c1738901069:	add    r14,0x50
    7c173890106d:	mov    r15,r14
    7c1738901070:	add    r15,0x10
    7c1738901074:	movdqu xmm2,XMMWORD PTR [r14]
    7c1738901079:	movdqu xmm3,XMMWORD PTR [r15]
    7c173890107e:	movdqa xmm0,xmm2
    7c1738901082:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c173890108c:	movdqa xmm0,xmm3
    7c1738901090:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c173890109a:	add    r13,0x30
    7c173890109e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c17389010a4:	movdqa xmm0,xmm2
    7c17389010a8:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c17389010b2:	mov    r13,QWORD PTR [r12+0x58]
    7c17389010b7:	mov    r14,QWORD PTR [r12+0x50]
    7c17389010bc:	mov    rcx,r13
    7c17389010bf:	add    r14,rcx
    7c17389010c2:	mov    QWORD PTR [r12+0x60],r14
    7c17389010c7:	add    r13,0x40
    7c17389010cb:	mov    QWORD PTR [r12+0x58],r13
    7c17389010d0:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c17389010da:	movdqa xmm3,xmm0
    7c17389010de:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    7c17389010e8:	movdqa xmm4,xmm0
    7c17389010ec:	stmxcsr DWORD PTR [rsp+0x110]
    7c17389010f4:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c17389010ff:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738901107:	movdqa xmm0,xmm3
    7c173890110b:	movdqa xmm1,xmm4
    7c173890110f:	movq   rax,xmm0
    7c1738901114:	add    rax,rax
    7c1738901117:	je     0x7c173890112d
    7c1738901119:	shr    rax,0x35
    7c173890111d:	sub    eax,0x201
    7c1738901122:	cmp    eax,0x3fc
    7c1738901127:	ja     0x7c1738904e9f
    7c173890112d:	movdqa xmm14,xmm0
    7c1738901132:	psrldq xmm14,0x8
    7c1738901138:	movq   rax,xmm14
    7c173890113d:	add    rax,rax
    7c1738901140:	je     0x7c1738901156
    7c1738901142:	shr    rax,0x35
    7c1738901146:	sub    eax,0x201
    7c173890114b:	cmp    eax,0x3fc
    7c1738901150:	ja     0x7c1738904e9f
    7c1738901156:	movq   rax,xmm1
    7c173890115b:	add    rax,rax
    7c173890115e:	je     0x7c1738901174
    7c1738901160:	shr    rax,0x35
    7c1738901164:	sub    eax,0x201
    7c1738901169:	cmp    eax,0x3fc
    7c173890116e:	ja     0x7c1738904e9f
    7c1738901174:	movdqa xmm14,xmm1
    7c1738901179:	psrldq xmm14,0x8
    7c173890117f:	movq   rax,xmm14
    7c1738901184:	add    rax,rax
    7c1738901187:	je     0x7c173890119d
    7c1738901189:	shr    rax,0x35
    7c173890118d:	sub    eax,0x201
    7c1738901192:	cmp    eax,0x3fc
    7c1738901197:	ja     0x7c1738904e9f
    7c173890119d:	mulpd  xmm0,xmm1
    7c17389011a1:	movdqa xmm5,xmm0
    7c17389011a5:	movdqa xmm0,xmm5
    7c17389011a9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c17389011b3:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c17389011bd:	movdqa xmm4,xmm0
    7c17389011c1:	movdqa xmm0,xmm2
    7c17389011c5:	movdqa xmm1,xmm4
    7c17389011c9:	pshufd xmm1,xmm1,0x44
    7c17389011ce:	movq   rax,xmm0
    7c17389011d3:	add    rax,rax
    7c17389011d6:	je     0x7c17389011ec
    7c17389011d8:	shr    rax,0x35
    7c17389011dc:	sub    eax,0x201
    7c17389011e1:	cmp    eax,0x3fc
    7c17389011e6:	ja     0x7c1738904ec3
    7c17389011ec:	movdqa xmm14,xmm0
    7c17389011f1:	psrldq xmm14,0x8
    7c17389011f7:	movq   rax,xmm14
    7c17389011fc:	add    rax,rax
    7c17389011ff:	je     0x7c1738901215
    7c1738901201:	shr    rax,0x35
    7c1738901205:	sub    eax,0x201
    7c173890120a:	cmp    eax,0x3fc
    7c173890120f:	ja     0x7c1738904ec3
    7c1738901215:	movq   rax,xmm1
    7c173890121a:	add    rax,rax
    7c173890121d:	je     0x7c1738901233
    7c173890121f:	shr    rax,0x35
    7c1738901223:	sub    eax,0x201
    7c1738901228:	cmp    eax,0x3fc
    7c173890122d:	ja     0x7c1738904ec3
    7c1738901233:	movdqa xmm14,xmm1
    7c1738901238:	psrldq xmm14,0x8
    7c173890123e:	movq   rax,xmm14
    7c1738901243:	add    rax,rax
    7c1738901246:	je     0x7c173890125c
    7c1738901248:	shr    rax,0x35
    7c173890124c:	sub    eax,0x201
    7c1738901251:	cmp    eax,0x3fc
    7c1738901256:	ja     0x7c1738904ec3
    7c173890125c:	mulpd  xmm0,xmm1
    7c1738901260:	movdqa xmm5,xmm0
    7c1738901264:	movdqa xmm0,xmm5
    7c1738901268:	movdqu XMMWORD PTR [r12+0x260],xmm0
    7c1738901272:	mov    r13d,0x0
    7c1738901278:	mov    r14d,0x0
    7c173890127e:	mov    QWORD PTR [r12+0x110],r13
    7c1738901286:	mov    QWORD PTR [r12+0x118],r14
    7c173890128e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c1738901298:	movdqa xmm2,xmm0
    7c173890129c:	movdqa xmm0,xmm3
    7c17389012a0:	movdqa xmm1,xmm2
    7c17389012a4:	movq   rax,xmm0
    7c17389012a9:	add    rax,rax
    7c17389012ac:	je     0x7c17389012c2
    7c17389012ae:	shr    rax,0x35
    7c17389012b2:	sub    eax,0x201
    7c17389012b7:	cmp    eax,0x3fc
    7c17389012bc:	ja     0x7c1738904ee7
    7c17389012c2:	movdqa xmm14,xmm0
    7c17389012c7:	psrldq xmm14,0x8
    7c17389012cd:	movq   rax,xmm14
    7c17389012d2:	add    rax,rax
    7c17389012d5:	je     0x7c17389012eb
    7c17389012d7:	shr    rax,0x35
    7c17389012db:	sub    eax,0x201
    7c17389012e0:	cmp    eax,0x3fc
    7c17389012e5:	ja     0x7c1738904ee7
    7c17389012eb:	movq   rax,xmm1
    7c17389012f0:	add    rax,rax
    7c17389012f3:	je     0x7c1738901309
    7c17389012f5:	shr    rax,0x35
    7c17389012f9:	sub    eax,0x201
    7c17389012fe:	cmp    eax,0x3fc
    7c1738901303:	ja     0x7c1738904ee7
    7c1738901309:	movdqa xmm14,xmm1
    7c173890130e:	psrldq xmm14,0x8
    7c1738901314:	movq   rax,xmm14
    7c1738901319:	add    rax,rax
    7c173890131c:	je     0x7c1738901332
    7c173890131e:	shr    rax,0x35
    7c1738901322:	sub    eax,0x201
    7c1738901327:	cmp    eax,0x3fc
    7c173890132c:	ja     0x7c1738904ee7
    7c1738901332:	mulpd  xmm0,xmm1
    7c1738901336:	movdqa xmm4,xmm0
    7c173890133a:	movdqa xmm0,xmm4
    7c173890133e:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c1738901348:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c1738901352:	movdqa xmm2,xmm0
    7c1738901356:	movdqa xmm0,xmm3
    7c173890135a:	movdqa xmm1,xmm2
    7c173890135e:	movq   rax,xmm0
    7c1738901363:	add    rax,rax
    7c1738901366:	je     0x7c173890137c
    7c1738901368:	shr    rax,0x35
    7c173890136c:	sub    eax,0x201
    7c1738901371:	cmp    eax,0x3fc
    7c1738901376:	ja     0x7c1738904f0b
    7c173890137c:	movdqa xmm14,xmm0
    7c1738901381:	psrldq xmm14,0x8
    7c1738901387:	movq   rax,xmm14
    7c173890138c:	add    rax,rax
    7c173890138f:	je     0x7c17389013a5
    7c1738901391:	shr    rax,0x35
    7c1738901395:	sub    eax,0x201
    7c173890139a:	cmp    eax,0x3fc
    7c173890139f:	ja     0x7c1738904f0b
    7c17389013a5:	movq   rax,xmm1
    7c17389013aa:	add    rax,rax
    7c17389013ad:	je     0x7c17389013c3
    7c17389013af:	shr    rax,0x35
    7c17389013b3:	sub    eax,0x201
    7c17389013b8:	cmp    eax,0x3fc
    7c17389013bd:	ja     0x7c1738904f0b
    7c17389013c3:	movdqa xmm14,xmm1
    7c17389013c8:	psrldq xmm14,0x8
    7c17389013ce:	movq   rax,xmm14
    7c17389013d3:	add    rax,rax
    7c17389013d6:	je     0x7c17389013ec
    7c17389013d8:	shr    rax,0x35
    7c17389013dc:	sub    eax,0x201
    7c17389013e1:	cmp    eax,0x3fc
    7c17389013e6:	ja     0x7c1738904f0b
    7c17389013ec:	mulpd  xmm0,xmm1
    7c17389013f0:	movdqa xmm4,xmm0
    7c17389013f4:	movdqa xmm0,xmm4
    7c17389013f8:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c1738901402:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c173890140c:	movdqa xmm2,xmm0
    7c1738901410:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    7c173890141a:	movdqa xmm3,xmm0
    7c173890141e:	movdqa xmm0,xmm2
    7c1738901422:	movdqa xmm1,xmm3
    7c1738901426:	movq   rax,xmm0
    7c173890142b:	add    rax,rax
    7c173890142e:	je     0x7c1738901444
    7c1738901430:	shr    rax,0x35
    7c1738901434:	sub    eax,0x201
    7c1738901439:	cmp    eax,0x3fc
    7c173890143e:	ja     0x7c1738904f2f
    7c1738901444:	movdqa xmm14,xmm0
    7c1738901449:	psrldq xmm14,0x8
    7c173890144f:	movq   rax,xmm14
    7c1738901454:	add    rax,rax
    7c1738901457:	je     0x7c173890146d
    7c1738901459:	shr    rax,0x35
    7c173890145d:	sub    eax,0x201
    7c1738901462:	cmp    eax,0x3fc
    7c1738901467:	ja     0x7c1738904f2f
    7c173890146d:	movq   rax,xmm1
    7c1738901472:	add    rax,rax
    7c1738901475:	je     0x7c173890148b
    7c1738901477:	shr    rax,0x35
    7c173890147b:	sub    eax,0x201
    7c1738901480:	cmp    eax,0x3fc
    7c1738901485:	ja     0x7c1738904f2f
    7c173890148b:	movdqa xmm14,xmm1
    7c1738901490:	psrldq xmm14,0x8
    7c1738901496:	movq   rax,xmm14
    7c173890149b:	add    rax,rax
    7c173890149e:	je     0x7c17389014b4
    7c17389014a0:	shr    rax,0x35
    7c17389014a4:	sub    eax,0x201
    7c17389014a9:	cmp    eax,0x3fc
    7c17389014ae:	ja     0x7c1738904f2f
    7c17389014b4:	mulpd  xmm0,xmm1
    7c17389014b8:	movdqa xmm4,xmm0
    7c17389014bc:	movdqa xmm0,xmm4
    7c17389014c0:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c17389014ca:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    7c17389014d4:	movdqa xmm2,xmm0
    7c17389014d8:	movdqa xmm1,xmm2
    7c17389014dc:	por    xmm2,xmm1
    7c17389014e0:	movdqa xmm0,xmm2
    7c17389014e4:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    7c17389014ee:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c17389014f8:	movdqa xmm2,xmm0
    7c17389014fc:	movdqa xmm3,xmm2
    7c1738901500:	movdqa xmm1,xmm2
    7c1738901504:	por    xmm3,xmm1
    7c1738901508:	movdqa xmm0,xmm3
    7c173890150c:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    7c1738901516:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c1738901520:	movdqa xmm3,xmm0
    7c1738901524:	movdqa xmm0,xmm2
    7c1738901528:	movdqa xmm1,xmm3
    7c173890152c:	pshufd xmm1,xmm1,0x44
    7c1738901531:	movq   rax,xmm0
    7c1738901536:	add    rax,rax
    7c1738901539:	je     0x7c173890154f
    7c173890153b:	shr    rax,0x35
    7c173890153f:	sub    eax,0x201
    7c1738901544:	cmp    eax,0x3fc
    7c1738901549:	ja     0x7c1738904f53
    7c173890154f:	movdqa xmm14,xmm0
    7c1738901554:	psrldq xmm14,0x8
    7c173890155a:	movq   rax,xmm14
    7c173890155f:	add    rax,rax
    7c1738901562:	je     0x7c1738901578
    7c1738901564:	shr    rax,0x35
    7c1738901568:	sub    eax,0x201
    7c173890156d:	cmp    eax,0x3fc
    7c1738901572:	ja     0x7c1738904f53
    7c1738901578:	movq   rax,xmm1
    7c173890157d:	add    rax,rax
    7c1738901580:	je     0x7c1738901596
    7c1738901582:	shr    rax,0x35
    7c1738901586:	sub    eax,0x201
    7c173890158b:	cmp    eax,0x3fc
    7c1738901590:	ja     0x7c1738904f53
    7c1738901596:	movdqa xmm14,xmm1
    7c173890159b:	psrldq xmm14,0x8
    7c17389015a1:	movq   rax,xmm14
    7c17389015a6:	add    rax,rax
    7c17389015a9:	je     0x7c17389015bf
    7c17389015ab:	shr    rax,0x35
    7c17389015af:	sub    eax,0x201
    7c17389015b4:	cmp    eax,0x3fc
    7c17389015b9:	ja     0x7c1738904f53
    7c17389015bf:	mulpd  xmm0,xmm1
    7c17389015c3:	movdqa xmm4,xmm0
    7c17389015c7:	movdqa xmm0,xmm4
    7c17389015cb:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c17389015d5:	mov    r13,QWORD PTR [r12+0x58]
    7c17389015da:	stmxcsr DWORD PTR [rsp+0x114]
    7c17389015e2:	ldmxcsr DWORD PTR [rsp+0x110]
    7c17389015ea:	mov    r11d,DWORD PTR [rsp+0x114]
    7c17389015f2:	shr    r11d,1
    7c17389015f5:	and    r11d,0x10
    7c17389015f9:	or     DWORD PTR [r12+0x314],r11d
    7c1738901601:	sub    r13,0x200
    7c1738901608:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c1738901612:	movdqa xmm2,xmm0
    7c1738901616:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c1738901620:	movdqa xmm3,xmm0
    7c1738901624:	pushf
    7c1738901625:	pop    r11
    7c1738901627:	mov    QWORD PTR [rsp],r11
    7c173890162b:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738901633:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c173890163e:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738901646:	movdqa xmm0,xmm2
    7c173890164a:	movdqa xmm1,xmm3
    7c173890164e:	movq   rax,xmm0
    7c1738901653:	add    rax,rax
    7c1738901656:	je     0x7c173890166c
    7c1738901658:	shr    rax,0x35
    7c173890165c:	sub    eax,0x201
    7c1738901661:	cmp    eax,0x3fc
    7c1738901666:	ja     0x7c1738904f77
    7c173890166c:	movdqa xmm14,xmm0
    7c1738901671:	psrldq xmm14,0x8
    7c1738901677:	movq   rax,xmm14
    7c173890167c:	add    rax,rax
    7c173890167f:	je     0x7c1738901695
    7c1738901681:	shr    rax,0x35
    7c1738901685:	sub    eax,0x201
    7c173890168a:	cmp    eax,0x3fc
    7c173890168f:	ja     0x7c1738904f77
    7c1738901695:	movq   rax,xmm1
    7c173890169a:	add    rax,rax
    7c173890169d:	je     0x7c17389016b3
    7c173890169f:	shr    rax,0x35
    7c17389016a3:	sub    eax,0x201
    7c17389016a8:	cmp    eax,0x3fc
    7c17389016ad:	ja     0x7c1738904f77
    7c17389016b3:	movdqa xmm14,xmm1
    7c17389016b8:	psrldq xmm14,0x8
    7c17389016be:	movq   rax,xmm14
    7c17389016c3:	add    rax,rax
    7c17389016c6:	je     0x7c17389016dc
    7c17389016c8:	shr    rax,0x35
    7c17389016cc:	sub    eax,0x201
    7c17389016d1:	cmp    eax,0x3fc
    7c17389016d6:	ja     0x7c1738904f77
    7c17389016dc:	addpd  xmm0,xmm1
    7c17389016e0:	movdqa xmm4,xmm0
    7c17389016e4:	movdqa xmm0,xmm4
    7c17389016e8:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c17389016f2:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c17389016fc:	movdqa xmm2,xmm0
    7c1738901700:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    7c173890170a:	movdqa xmm3,xmm0
    7c173890170e:	movdqa xmm0,xmm2
    7c1738901712:	movdqa xmm1,xmm3
    7c1738901716:	movq   rax,xmm0
    7c173890171b:	add    rax,rax
    7c173890171e:	je     0x7c1738901734
    7c1738901720:	shr    rax,0x35
    7c1738901724:	sub    eax,0x201
    7c1738901729:	cmp    eax,0x3fc
    7c173890172e:	ja     0x7c1738904f9b
    7c1738901734:	movdqa xmm14,xmm0
    7c1738901739:	psrldq xmm14,0x8
    7c173890173f:	movq   rax,xmm14
    7c1738901744:	add    rax,rax
    7c1738901747:	je     0x7c173890175d
    7c1738901749:	shr    rax,0x35
    7c173890174d:	sub    eax,0x201
    7c1738901752:	cmp    eax,0x3fc
    7c1738901757:	ja     0x7c1738904f9b
    7c173890175d:	movq   rax,xmm1
    7c1738901762:	add    rax,rax
    7c1738901765:	je     0x7c173890177b
    7c1738901767:	shr    rax,0x35
    7c173890176b:	sub    eax,0x201
    7c1738901770:	cmp    eax,0x3fc
    7c1738901775:	ja     0x7c1738904f9b
    7c173890177b:	movdqa xmm14,xmm1
    7c1738901780:	psrldq xmm14,0x8
    7c1738901786:	movq   rax,xmm14
    7c173890178b:	add    rax,rax
    7c173890178e:	je     0x7c17389017a4
    7c1738901790:	shr    rax,0x35
    7c1738901794:	sub    eax,0x201
    7c1738901799:	cmp    eax,0x3fc
    7c173890179e:	ja     0x7c1738904f9b
    7c17389017a4:	addpd  xmm0,xmm1
    7c17389017a8:	movdqa xmm4,xmm0
    7c17389017ac:	movdqa xmm0,xmm4
    7c17389017b0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c17389017ba:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c17389017c4:	movdqa xmm2,xmm0
    7c17389017c8:	movdqa xmm0,xmm2
    7c17389017cc:	movdqa xmm1,xmm3
    7c17389017d0:	movq   rax,xmm0
    7c17389017d5:	add    rax,rax
    7c17389017d8:	je     0x7c17389017ee
    7c17389017da:	shr    rax,0x35
    7c17389017de:	sub    eax,0x201
    7c17389017e3:	cmp    eax,0x3fc
    7c17389017e8:	ja     0x7c1738904fbf
    7c17389017ee:	movdqa xmm14,xmm0
    7c17389017f3:	psrldq xmm14,0x8
    7c17389017f9:	movq   rax,xmm14
    7c17389017fe:	add    rax,rax
    7c1738901801:	je     0x7c1738901817
    7c1738901803:	shr    rax,0x35
    7c1738901807:	sub    eax,0x201
    7c173890180c:	cmp    eax,0x3fc
    7c1738901811:	ja     0x7c1738904fbf
    7c1738901817:	movq   rax,xmm1
    7c173890181c:	add    rax,rax
    7c173890181f:	je     0x7c1738901835
    7c1738901821:	shr    rax,0x35
    7c1738901825:	sub    eax,0x201
    7c173890182a:	cmp    eax,0x3fc
    7c173890182f:	ja     0x7c1738904fbf
    7c1738901835:	movdqa xmm14,xmm1
    7c173890183a:	psrldq xmm14,0x8
    7c1738901840:	movq   rax,xmm14
    7c1738901845:	add    rax,rax
    7c1738901848:	je     0x7c173890185e
    7c173890184a:	shr    rax,0x35
    7c173890184e:	sub    eax,0x201
    7c1738901853:	cmp    eax,0x3fc
    7c1738901858:	ja     0x7c1738904fbf
    7c173890185e:	addpd  xmm0,xmm1
    7c1738901862:	movdqa xmm4,xmm0
    7c1738901866:	movdqa xmm0,xmm4
    7c173890186a:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c1738901874:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7c173890187e:	movdqa xmm2,xmm0
    7c1738901882:	movdqa xmm1,xmm2
    7c1738901886:	por    xmm2,xmm1
    7c173890188a:	movdqa xmm0,xmm2
    7c173890188e:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    7c1738901898:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7c17389018a2:	movdqa xmm2,xmm0
    7c17389018a6:	movdqa xmm1,xmm2
    7c17389018aa:	por    xmm2,xmm1
    7c17389018ae:	movdqa xmm0,xmm2
    7c17389018b2:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7c17389018bc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    7c17389018c6:	movdqa xmm2,xmm0
    7c17389018ca:	movdqa xmm1,xmm2
    7c17389018ce:	por    xmm2,xmm1
    7c17389018d2:	movdqa xmm0,xmm2
    7c17389018d6:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7c17389018e0:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    7c17389018ea:	movdqa xmm2,xmm0
    7c17389018ee:	movdqa xmm1,xmm2
    7c17389018f2:	por    xmm2,xmm1
    7c17389018f6:	movdqa xmm0,xmm2
    7c17389018fa:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    7c1738901904:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7c173890190e:	movdqa xmm2,xmm0
    7c1738901912:	movdqa xmm1,xmm2
    7c1738901916:	por    xmm2,xmm1
    7c173890191a:	movdqa xmm0,xmm2
    7c173890191e:	movdqu XMMWORD PTR [r12+0x200],xmm0
    7c1738901928:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7c1738901932:	movdqa xmm2,xmm0
    7c1738901936:	movdqa xmm1,xmm2
    7c173890193a:	por    xmm2,xmm1
    7c173890193e:	movdqa xmm0,xmm2
    7c1738901942:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    7c173890194c:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7c1738901956:	movdqa xmm2,xmm0
    7c173890195a:	movdqa xmm1,xmm2
    7c173890195e:	por    xmm2,xmm1
    7c1738901962:	movdqa xmm0,xmm2
    7c1738901966:	movdqu XMMWORD PTR [r12+0x190],xmm0
    7c1738901970:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738901978:	mov    r14,r13
    7c173890197b:	add    r14,0xa0
    7c1738901982:	mov    r15,r14
    7c1738901985:	add    r15,0x10
    7c1738901989:	stmxcsr DWORD PTR [rsp+0x114]
    7c1738901991:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738901999:	mov    r11d,DWORD PTR [rsp+0x114]
    7c17389019a1:	shr    r11d,1
    7c17389019a4:	and    r11d,0x10
    7c17389019a8:	or     DWORD PTR [r12+0x314],r11d
    7c17389019b0:	movdqu xmm2,XMMWORD PTR [r14]
    7c17389019b5:	movdqu xmm3,XMMWORD PTR [r15]
    7c17389019ba:	movdqa xmm0,xmm2
    7c17389019be:	movdqu XMMWORD PTR [r12+0x300],xmm0
    7c17389019c8:	movdqa xmm0,xmm3
    7c17389019cc:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c17389019d6:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c17389019e0:	movdqa xmm2,xmm0
    7c17389019e4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c17389019ee:	movdqa xmm4,xmm0
    7c17389019f2:	stmxcsr DWORD PTR [rsp+0x110]
    7c17389019fa:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c1738901a05:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738901a0d:	movdqa xmm0,xmm2
    7c1738901a11:	movdqa xmm1,xmm4
    7c1738901a15:	movq   rax,xmm0
    7c1738901a1a:	add    rax,rax
    7c1738901a1d:	je     0x7c1738901a33
    7c1738901a1f:	shr    rax,0x35
    7c1738901a23:	sub    eax,0x201
    7c1738901a28:	cmp    eax,0x3fc
    7c1738901a2d:	ja     0x7c1738904fe3
    7c1738901a33:	movdqa xmm14,xmm0
    7c1738901a38:	psrldq xmm14,0x8
    7c1738901a3e:	movq   rax,xmm14
    7c1738901a43:	add    rax,rax
    7c1738901a46:	je     0x7c1738901a5c
    7c1738901a48:	shr    rax,0x35
    7c1738901a4c:	sub    eax,0x201
    7c1738901a51:	cmp    eax,0x3fc
    7c1738901a56:	ja     0x7c1738904fe3
    7c1738901a5c:	movq   rax,xmm1
    7c1738901a61:	add    rax,rax
    7c1738901a64:	je     0x7c1738901a7a
    7c1738901a66:	shr    rax,0x35
    7c1738901a6a:	sub    eax,0x201
    7c1738901a6f:	cmp    eax,0x3fc
    7c1738901a74:	ja     0x7c1738904fe3
    7c1738901a7a:	movdqa xmm14,xmm1
    7c1738901a7f:	psrldq xmm14,0x8
    7c1738901a85:	movq   rax,xmm14
    7c1738901a8a:	add    rax,rax
    7c1738901a8d:	je     0x7c1738901aa3
    7c1738901a8f:	shr    rax,0x35
    7c1738901a93:	sub    eax,0x201
    7c1738901a98:	cmp    eax,0x3fc
    7c1738901a9d:	ja     0x7c1738904fe3
    7c1738901aa3:	addpd  xmm0,xmm1
    7c1738901aa7:	movdqa xmm5,xmm0
    7c1738901aab:	movdqa xmm0,xmm5
    7c1738901aaf:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c1738901ab9:	add    r13,0xf0
    7c1738901ac0:	stmxcsr DWORD PTR [rsp+0x114]
    7c1738901ac8:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738901ad0:	mov    r11d,DWORD PTR [rsp+0x114]
    7c1738901ad8:	shr    r11d,1
    7c1738901adb:	and    r11d,0x10
    7c1738901adf:	or     DWORD PTR [r12+0x314],r11d
    7c1738901ae7:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c1738901aed:	movdqa xmm0,xmm2
    7c1738901af1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c1738901afb:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c1738901b05:	movdqa xmm4,xmm0
    7c1738901b09:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c1738901b13:	movdqa xmm5,xmm0
    7c1738901b17:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738901b1f:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c1738901b2a:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738901b32:	movdqa xmm0,xmm4
    7c1738901b36:	movdqa xmm1,xmm5
    7c1738901b3a:	movq   rax,xmm0
    7c1738901b3f:	add    rax,rax
    7c1738901b42:	je     0x7c1738901b58
    7c1738901b44:	shr    rax,0x35
    7c1738901b48:	sub    eax,0x201
    7c1738901b4d:	cmp    eax,0x3fc
    7c1738901b52:	ja     0x7c1738905007
    7c1738901b58:	movdqa xmm14,xmm0
    7c1738901b5d:	psrldq xmm14,0x8
    7c1738901b63:	movq   rax,xmm14
    7c1738901b68:	add    rax,rax
    7c1738901b6b:	je     0x7c1738901b81
    7c1738901b6d:	shr    rax,0x35
    7c1738901b71:	sub    eax,0x201
    7c1738901b76:	cmp    eax,0x3fc
    7c1738901b7b:	ja     0x7c1738905007
    7c1738901b81:	movq   rax,xmm1
    7c1738901b86:	add    rax,rax
    7c1738901b89:	je     0x7c1738901b9f
    7c1738901b8b:	shr    rax,0x35
    7c1738901b8f:	sub    eax,0x201
    7c1738901b94:	cmp    eax,0x3fc
    7c1738901b99:	ja     0x7c1738905007
    7c1738901b9f:	movdqa xmm14,xmm1
    7c1738901ba4:	psrldq xmm14,0x8
    7c1738901baa:	movq   rax,xmm14
    7c1738901baf:	add    rax,rax
    7c1738901bb2:	je     0x7c1738901bc8
    7c1738901bb4:	shr    rax,0x35
    7c1738901bb8:	sub    eax,0x201
    7c1738901bbd:	cmp    eax,0x3fc
    7c1738901bc2:	ja     0x7c1738905007
    7c1738901bc8:	addpd  xmm0,xmm1
    7c1738901bcc:	movdqa xmm6,xmm0
    7c1738901bd0:	movdqa xmm0,xmm6
    7c1738901bd4:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c1738901bde:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c1738901be8:	movdqa xmm4,xmm0
    7c1738901bec:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7c1738901bf6:	movdqa xmm5,xmm0
    7c1738901bfa:	movdqa xmm0,xmm4
    7c1738901bfe:	movdqa xmm1,xmm5
    7c1738901c02:	movq   rax,xmm0
    7c1738901c07:	add    rax,rax
    7c1738901c0a:	je     0x7c1738901c20
    7c1738901c0c:	shr    rax,0x35
    7c1738901c10:	sub    eax,0x201
    7c1738901c15:	cmp    eax,0x3fc
    7c1738901c1a:	ja     0x7c173890502b
    7c1738901c20:	movdqa xmm14,xmm0
    7c1738901c25:	psrldq xmm14,0x8
    7c1738901c2b:	movq   rax,xmm14
    7c1738901c30:	add    rax,rax
    7c1738901c33:	je     0x7c1738901c49
    7c1738901c35:	shr    rax,0x35
    7c1738901c39:	sub    eax,0x201
    7c1738901c3e:	cmp    eax,0x3fc
    7c1738901c43:	ja     0x7c173890502b
    7c1738901c49:	movq   rax,xmm1
    7c1738901c4e:	add    rax,rax
    7c1738901c51:	je     0x7c1738901c67
    7c1738901c53:	shr    rax,0x35
    7c1738901c57:	sub    eax,0x201
    7c1738901c5c:	cmp    eax,0x3fc
    7c1738901c61:	ja     0x7c173890502b
    7c1738901c67:	movdqa xmm14,xmm1
    7c1738901c6c:	psrldq xmm14,0x8
    7c1738901c72:	movq   rax,xmm14
    7c1738901c77:	add    rax,rax
    7c1738901c7a:	je     0x7c1738901c90
    7c1738901c7c:	shr    rax,0x35
    7c1738901c80:	sub    eax,0x201
    7c1738901c85:	cmp    eax,0x3fc
    7c1738901c8a:	ja     0x7c173890502b
    7c1738901c90:	addpd  xmm0,xmm1
    7c1738901c94:	movdqa xmm6,xmm0
    7c1738901c98:	movdqa xmm0,xmm6
    7c1738901c9c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c1738901ca6:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c1738901cb0:	movdqa xmm4,xmm0
    7c1738901cb4:	movdqa xmm0,xmm3
    7c1738901cb8:	movdqa xmm1,xmm4
    7c1738901cbc:	pshufd xmm1,xmm1,0x44
    7c1738901cc1:	movq   rax,xmm0
    7c1738901cc6:	add    rax,rax
    7c1738901cc9:	je     0x7c1738901cdf
    7c1738901ccb:	shr    rax,0x35
    7c1738901ccf:	sub    eax,0x201
    7c1738901cd4:	cmp    eax,0x3fc
    7c1738901cd9:	ja     0x7c173890504f
    7c1738901cdf:	movdqa xmm14,xmm0
    7c1738901ce4:	psrldq xmm14,0x8
    7c1738901cea:	movq   rax,xmm14
    7c1738901cef:	add    rax,rax
    7c1738901cf2:	je     0x7c1738901d08
    7c1738901cf4:	shr    rax,0x35
    7c1738901cf8:	sub    eax,0x201
    7c1738901cfd:	cmp    eax,0x3fc
    7c1738901d02:	ja     0x7c173890504f
    7c1738901d08:	movq   rax,xmm1
    7c1738901d0d:	add    rax,rax
    7c1738901d10:	je     0x7c1738901d26
    7c1738901d12:	shr    rax,0x35
    7c1738901d16:	sub    eax,0x201
    7c1738901d1b:	cmp    eax,0x3fc
    7c1738901d20:	ja     0x7c173890504f
    7c1738901d26:	movdqa xmm14,xmm1
    7c1738901d2b:	psrldq xmm14,0x8
    7c1738901d31:	movq   rax,xmm14
    7c1738901d36:	add    rax,rax
    7c1738901d39:	je     0x7c1738901d4f
    7c1738901d3b:	shr    rax,0x35
    7c1738901d3f:	sub    eax,0x201
    7c1738901d44:	cmp    eax,0x3fc
    7c1738901d49:	ja     0x7c173890504f
    7c1738901d4f:	mulpd  xmm0,xmm1
    7c1738901d53:	movdqa xmm5,xmm0
    7c1738901d57:	movdqa xmm0,xmm5
    7c1738901d5b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c1738901d65:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c1738901d6f:	movdqa xmm3,xmm0
    7c1738901d73:	movdqa xmm0,xmm2
    7c1738901d77:	movdqa xmm1,xmm3
    7c1738901d7b:	pshufd xmm1,xmm1,0x44
    7c1738901d80:	movq   rax,xmm0
    7c1738901d85:	add    rax,rax
    7c1738901d88:	je     0x7c1738901d9e
    7c1738901d8a:	shr    rax,0x35
    7c1738901d8e:	sub    eax,0x201
    7c1738901d93:	cmp    eax,0x3fc
    7c1738901d98:	ja     0x7c1738905073
    7c1738901d9e:	movdqa xmm14,xmm0
    7c1738901da3:	psrldq xmm14,0x8
    7c1738901da9:	movq   rax,xmm14
    7c1738901dae:	add    rax,rax
    7c1738901db1:	je     0x7c1738901dc7
    7c1738901db3:	shr    rax,0x35
    7c1738901db7:	sub    eax,0x201
    7c1738901dbc:	cmp    eax,0x3fc
    7c1738901dc1:	ja     0x7c1738905073
    7c1738901dc7:	movq   rax,xmm1
    7c1738901dcc:	add    rax,rax
    7c1738901dcf:	je     0x7c1738901de5
    7c1738901dd1:	shr    rax,0x35
    7c1738901dd5:	sub    eax,0x201
    7c1738901dda:	cmp    eax,0x3fc
    7c1738901ddf:	ja     0x7c1738905073
    7c1738901de5:	movdqa xmm14,xmm1
    7c1738901dea:	psrldq xmm14,0x8
    7c1738901df0:	movq   rax,xmm14
    7c1738901df5:	add    rax,rax
    7c1738901df8:	je     0x7c1738901e0e
    7c1738901dfa:	shr    rax,0x35
    7c1738901dfe:	sub    eax,0x201
    7c1738901e03:	cmp    eax,0x3fc
    7c1738901e08:	ja     0x7c1738905073
    7c1738901e0e:	mulpd  xmm0,xmm1
    7c1738901e12:	movdqa xmm5,xmm0
    7c1738901e16:	movdqa xmm0,xmm5
    7c1738901e1a:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c1738901e24:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738901e2c:	mov    r14,r13
    7c1738901e2f:	add    r14,0xe0
    7c1738901e36:	stmxcsr DWORD PTR [rsp+0x114]
    7c1738901e3e:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738901e46:	mov    r11d,DWORD PTR [rsp+0x114]
    7c1738901e4e:	shr    r11d,1
    7c1738901e51:	and    r11d,0x10
    7c1738901e55:	or     DWORD PTR [r12+0x314],r11d
    7c1738901e5d:	movdqu xmm2,XMMWORD PTR [r14]
    7c1738901e62:	movdqa xmm0,xmm2
    7c1738901e66:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c1738901e70:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7c1738901e7a:	movdqa xmm2,xmm0
    7c1738901e7e:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738901e86:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c1738901e91:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738901e99:	movdqa xmm0,xmm2
    7c1738901e9d:	movdqa xmm1,xmm4
    7c1738901ea1:	pshufd xmm1,xmm1,0x44
    7c1738901ea6:	movq   rax,xmm0
    7c1738901eab:	add    rax,rax
    7c1738901eae:	je     0x7c1738901ec4
    7c1738901eb0:	shr    rax,0x35
    7c1738901eb4:	sub    eax,0x201
    7c1738901eb9:	cmp    eax,0x3fc
    7c1738901ebe:	ja     0x7c1738905097
    7c1738901ec4:	movdqa xmm14,xmm0
    7c1738901ec9:	psrldq xmm14,0x8
    7c1738901ecf:	movq   rax,xmm14
    7c1738901ed4:	add    rax,rax
    7c1738901ed7:	je     0x7c1738901eed
    7c1738901ed9:	shr    rax,0x35
    7c1738901edd:	sub    eax,0x201
    7c1738901ee2:	cmp    eax,0x3fc
    7c1738901ee7:	ja     0x7c1738905097
    7c1738901eed:	movq   rax,xmm1
    7c1738901ef2:	add    rax,rax
    7c1738901ef5:	je     0x7c1738901f0b
    7c1738901ef7:	shr    rax,0x35
    7c1738901efb:	sub    eax,0x201
    7c1738901f00:	cmp    eax,0x3fc
    7c1738901f05:	ja     0x7c1738905097
    7c1738901f0b:	movdqa xmm14,xmm1
    7c1738901f10:	psrldq xmm14,0x8
    7c1738901f16:	movq   rax,xmm14
    7c1738901f1b:	add    rax,rax
    7c1738901f1e:	je     0x7c1738901f34
    7c1738901f20:	shr    rax,0x35
    7c1738901f24:	sub    eax,0x201
    7c1738901f29:	cmp    eax,0x3fc
    7c1738901f2e:	ja     0x7c1738905097
    7c1738901f34:	mulpd  xmm0,xmm1
    7c1738901f38:	movdqa xmm5,xmm0
    7c1738901f3c:	movdqa xmm0,xmm5
    7c1738901f40:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c1738901f4a:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7c1738901f54:	movdqa xmm2,xmm0
    7c1738901f58:	movdqa xmm1,xmm2
    7c1738901f5c:	por    xmm2,xmm1
    7c1738901f60:	movdqa xmm0,xmm2
    7c1738901f64:	movdqu XMMWORD PTR [r12+0x300],xmm0
    7c1738901f6e:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7c1738901f78:	movdqa xmm2,xmm0
    7c1738901f7c:	movdqa xmm1,xmm2
    7c1738901f80:	por    xmm2,xmm1
    7c1738901f84:	movdqa xmm0,xmm2
    7c1738901f88:	movdqu XMMWORD PTR [r12+0x190],xmm0
    7c1738901f92:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c1738901f9c:	movdqa xmm2,xmm0
    7c1738901fa0:	movdqa xmm0,xmm2
    7c1738901fa4:	movdqa xmm1,xmm3
    7c1738901fa8:	pshufd xmm1,xmm1,0x44
    7c1738901fad:	movq   rax,xmm0
    7c1738901fb2:	add    rax,rax
    7c1738901fb5:	je     0x7c1738901fcb
    7c1738901fb7:	shr    rax,0x35
    7c1738901fbb:	sub    eax,0x201
    7c1738901fc0:	cmp    eax,0x3fc
    7c1738901fc5:	ja     0x7c17389050bb
    7c1738901fcb:	movdqa xmm14,xmm0
    7c1738901fd0:	psrldq xmm14,0x8
    7c1738901fd6:	movq   rax,xmm14
    7c1738901fdb:	add    rax,rax
    7c1738901fde:	je     0x7c1738901ff4
    7c1738901fe0:	shr    rax,0x35
    7c1738901fe4:	sub    eax,0x201
    7c1738901fe9:	cmp    eax,0x3fc
    7c1738901fee:	ja     0x7c17389050bb
    7c1738901ff4:	movq   rax,xmm1
    7c1738901ff9:	add    rax,rax
    7c1738901ffc:	je     0x7c1738902012
    7c1738901ffe:	shr    rax,0x35
    7c1738902002:	sub    eax,0x201
    7c1738902007:	cmp    eax,0x3fc
    7c173890200c:	ja     0x7c17389050bb
    7c1738902012:	movdqa xmm14,xmm1
    7c1738902017:	psrldq xmm14,0x8
    7c173890201d:	movq   rax,xmm14
    7c1738902022:	add    rax,rax
    7c1738902025:	je     0x7c173890203b
    7c1738902027:	shr    rax,0x35
    7c173890202b:	sub    eax,0x201
    7c1738902030:	cmp    eax,0x3fc
    7c1738902035:	ja     0x7c17389050bb
    7c173890203b:	mulpd  xmm0,xmm1
    7c173890203f:	movdqa xmm4,xmm0
    7c1738902043:	movdqa xmm0,xmm4
    7c1738902047:	movdqu XMMWORD PTR [r12+0x260],xmm0
    7c1738902051:	add    r13,0x90
    7c1738902058:	stmxcsr DWORD PTR [rsp+0x114]
    7c1738902060:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738902068:	mov    r11d,DWORD PTR [rsp+0x114]
    7c1738902070:	shr    r11d,1
    7c1738902073:	and    r11d,0x10
    7c1738902077:	or     DWORD PTR [r12+0x314],r11d
    7c173890207f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c1738902085:	movdqa xmm0,xmm2
    7c1738902089:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c1738902093:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    7c173890209d:	movdqa xmm3,xmm0
    7c17389020a1:	movdqa xmm1,xmm3
    7c17389020a5:	por    xmm3,xmm1
    7c17389020a9:	movdqa xmm0,xmm3
    7c17389020ad:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    7c17389020b7:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    7c17389020c1:	movdqa xmm3,xmm0
    7c17389020c5:	movdqa xmm1,xmm3
    7c17389020c9:	por    xmm3,xmm1
    7c17389020cd:	movdqa xmm0,xmm3
    7c17389020d1:	movdqu XMMWORD PTR [r12+0x200],xmm0
    7c17389020db:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7c17389020e5:	movdqa xmm3,xmm0
    7c17389020e9:	movdqa xmm1,xmm3
    7c17389020ed:	por    xmm3,xmm1
    7c17389020f1:	movdqa xmm0,xmm3
    7c17389020f5:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    7c17389020ff:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7c1738902109:	movdqa xmm3,xmm0
    7c173890210d:	movdqa xmm1,xmm3
    7c1738902111:	por    xmm3,xmm1
    7c1738902115:	movdqa xmm0,xmm3
    7c1738902119:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7c1738902123:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c173890212d:	movdqa xmm3,xmm0
    7c1738902131:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c173890213b:	movdqa xmm4,xmm0
    7c173890213f:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738902147:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c1738902152:	ldmxcsr DWORD PTR [rsp+0x114]
    7c173890215a:	movdqa xmm0,xmm3
    7c173890215e:	movdqa xmm1,xmm4
    7c1738902162:	movq   rax,xmm0
    7c1738902167:	add    rax,rax
    7c173890216a:	je     0x7c1738902180
    7c173890216c:	shr    rax,0x35
    7c1738902170:	sub    eax,0x201
    7c1738902175:	cmp    eax,0x3fc
    7c173890217a:	ja     0x7c17389050df
    7c1738902180:	movdqa xmm14,xmm0
    7c1738902185:	psrldq xmm14,0x8
    7c173890218b:	movq   rax,xmm14
    7c1738902190:	add    rax,rax
    7c1738902193:	je     0x7c17389021a9
    7c1738902195:	shr    rax,0x35
    7c1738902199:	sub    eax,0x201
    7c173890219e:	cmp    eax,0x3fc
    7c17389021a3:	ja     0x7c17389050df
    7c17389021a9:	movq   rax,xmm1
    7c17389021ae:	add    rax,rax
    7c17389021b1:	je     0x7c17389021c7
    7c17389021b3:	shr    rax,0x35
    7c17389021b7:	sub    eax,0x201
    7c17389021bc:	cmp    eax,0x3fc
    7c17389021c1:	ja     0x7c17389050df
    7c17389021c7:	movdqa xmm14,xmm1
    7c17389021cc:	psrldq xmm14,0x8
    7c17389021d2:	movq   rax,xmm14
    7c17389021d7:	add    rax,rax
    7c17389021da:	je     0x7c17389021f0
    7c17389021dc:	shr    rax,0x35
    7c17389021e0:	sub    eax,0x201
    7c17389021e5:	cmp    eax,0x3fc
    7c17389021ea:	ja     0x7c17389050df
    7c17389021f0:	addpd  xmm0,xmm1
    7c17389021f4:	movdqa xmm5,xmm0
    7c17389021f8:	movdqa xmm0,xmm5
    7c17389021fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c1738902206:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c1738902210:	movdqa xmm3,xmm0
    7c1738902214:	movdqa xmm0,xmm2
    7c1738902218:	movdqa xmm1,xmm3
    7c173890221c:	pshufd xmm1,xmm1,0x44
    7c1738902221:	movq   rax,xmm0
    7c1738902226:	add    rax,rax
    7c1738902229:	je     0x7c173890223f
    7c173890222b:	shr    rax,0x35
    7c173890222f:	sub    eax,0x201
    7c1738902234:	cmp    eax,0x3fc
    7c1738902239:	ja     0x7c1738905103
    7c173890223f:	movdqa xmm14,xmm0
    7c1738902244:	psrldq xmm14,0x8
    7c173890224a:	movq   rax,xmm14
    7c173890224f:	add    rax,rax
    7c1738902252:	je     0x7c1738902268
    7c1738902254:	shr    rax,0x35
    7c1738902258:	sub    eax,0x201
    7c173890225d:	cmp    eax,0x3fc
    7c1738902262:	ja     0x7c1738905103
    7c1738902268:	movq   rax,xmm1
    7c173890226d:	add    rax,rax
    7c1738902270:	je     0x7c1738902286
    7c1738902272:	shr    rax,0x35
    7c1738902276:	sub    eax,0x201
    7c173890227b:	cmp    eax,0x3fc
    7c1738902280:	ja     0x7c1738905103
    7c1738902286:	movdqa xmm14,xmm1
    7c173890228b:	psrldq xmm14,0x8
    7c1738902291:	movq   rax,xmm14
    7c1738902296:	add    rax,rax
    7c1738902299:	je     0x7c17389022af
    7c173890229b:	shr    rax,0x35
    7c173890229f:	sub    eax,0x201
    7c17389022a4:	cmp    eax,0x3fc
    7c17389022a9:	ja     0x7c1738905103
    7c17389022af:	mulpd  xmm0,xmm1
    7c17389022b3:	movdqa xmm4,xmm0
    7c17389022b7:	movdqa xmm0,xmm4
    7c17389022bb:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c17389022c5:	mov    r13,QWORD PTR [r12+0xf8]
    7c17389022cd:	add    r13,0x80
    7c17389022d4:	stmxcsr DWORD PTR [rsp+0x114]
    7c17389022dc:	ldmxcsr DWORD PTR [rsp+0x110]
    7c17389022e4:	mov    r11d,DWORD PTR [rsp+0x114]
    7c17389022ec:	shr    r11d,1
    7c17389022ef:	and    r11d,0x10
    7c17389022f3:	or     DWORD PTR [r12+0x314],r11d
    7c17389022fb:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c1738902301:	movdqa xmm0,xmm2
    7c1738902305:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c173890230f:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c1738902319:	movdqa xmm3,xmm0
    7c173890231d:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c1738902327:	movdqa xmm4,xmm0
    7c173890232b:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738902333:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c173890233e:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738902346:	movdqa xmm0,xmm3
    7c173890234a:	movdqa xmm1,xmm4
    7c173890234e:	movq   rax,xmm0
    7c1738902353:	add    rax,rax
    7c1738902356:	je     0x7c173890236c
    7c1738902358:	shr    rax,0x35
    7c173890235c:	sub    eax,0x201
    7c1738902361:	cmp    eax,0x3fc
    7c1738902366:	ja     0x7c1738905127
    7c173890236c:	movdqa xmm14,xmm0
    7c1738902371:	psrldq xmm14,0x8
    7c1738902377:	movq   rax,xmm14
    7c173890237c:	add    rax,rax
    7c173890237f:	je     0x7c1738902395
    7c1738902381:	shr    rax,0x35
    7c1738902385:	sub    eax,0x201
    7c173890238a:	cmp    eax,0x3fc
    7c173890238f:	ja     0x7c1738905127
    7c1738902395:	movq   rax,xmm1
    7c173890239a:	add    rax,rax
    7c173890239d:	je     0x7c17389023b3
    7c173890239f:	shr    rax,0x35
    7c17389023a3:	sub    eax,0x201
    7c17389023a8:	cmp    eax,0x3fc
    7c17389023ad:	ja     0x7c1738905127
    7c17389023b3:	movdqa xmm14,xmm1
    7c17389023b8:	psrldq xmm14,0x8
    7c17389023be:	movq   rax,xmm14
    7c17389023c3:	add    rax,rax
    7c17389023c6:	je     0x7c17389023dc
    7c17389023c8:	shr    rax,0x35
    7c17389023cc:	sub    eax,0x201
    7c17389023d1:	cmp    eax,0x3fc
    7c17389023d6:	ja     0x7c1738905127
    7c17389023dc:	addpd  xmm0,xmm1
    7c17389023e0:	movdqa xmm5,xmm0
    7c17389023e4:	movdqa xmm0,xmm5
    7c17389023e8:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c17389023f2:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c17389023fc:	movdqa xmm3,xmm0
    7c1738902400:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c173890240a:	movdqa xmm4,xmm0
    7c173890240e:	movdqa xmm0,xmm3
    7c1738902412:	movdqa xmm1,xmm4
    7c1738902416:	movq   rax,xmm0
    7c173890241b:	add    rax,rax
    7c173890241e:	je     0x7c1738902434
    7c1738902420:	shr    rax,0x35
    7c1738902424:	sub    eax,0x201
    7c1738902429:	cmp    eax,0x3fc
    7c173890242e:	ja     0x7c173890514b
    7c1738902434:	movdqa xmm14,xmm0
    7c1738902439:	psrldq xmm14,0x8
    7c173890243f:	movq   rax,xmm14
    7c1738902444:	add    rax,rax
    7c1738902447:	je     0x7c173890245d
    7c1738902449:	shr    rax,0x35
    7c173890244d:	sub    eax,0x201
    7c1738902452:	cmp    eax,0x3fc
    7c1738902457:	ja     0x7c173890514b
    7c173890245d:	movq   rax,xmm1
    7c1738902462:	add    rax,rax
    7c1738902465:	je     0x7c173890247b
    7c1738902467:	shr    rax,0x35
    7c173890246b:	sub    eax,0x201
    7c1738902470:	cmp    eax,0x3fc
    7c1738902475:	ja     0x7c173890514b
    7c173890247b:	movdqa xmm14,xmm1
    7c1738902480:	psrldq xmm14,0x8
    7c1738902486:	movq   rax,xmm14
    7c173890248b:	add    rax,rax
    7c173890248e:	je     0x7c17389024a4
    7c1738902490:	shr    rax,0x35
    7c1738902494:	sub    eax,0x201
    7c1738902499:	cmp    eax,0x3fc
    7c173890249e:	ja     0x7c173890514b
    7c17389024a4:	addpd  xmm0,xmm1
    7c17389024a8:	movdqa xmm5,xmm0
    7c17389024ac:	movdqa xmm0,xmm5
    7c17389024b0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c17389024ba:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    7c17389024c4:	movdqa xmm3,xmm0
    7c17389024c8:	movdqa xmm1,xmm3
    7c17389024cc:	por    xmm3,xmm1
    7c17389024d0:	movdqa xmm0,xmm3
    7c17389024d4:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7c17389024de:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c17389024e8:	movdqa xmm3,xmm0
    7c17389024ec:	movdqa xmm0,xmm2
    7c17389024f0:	movdqa xmm1,xmm3
    7c17389024f4:	pshufd xmm1,xmm1,0x44
    7c17389024f9:	movq   rax,xmm0
    7c17389024fe:	add    rax,rax
    7c1738902501:	je     0x7c1738902517
    7c1738902503:	shr    rax,0x35
    7c1738902507:	sub    eax,0x201
    7c173890250c:	cmp    eax,0x3fc
    7c1738902511:	ja     0x7c173890516f
    7c1738902517:	movdqa xmm14,xmm0
    7c173890251c:	psrldq xmm14,0x8
    7c1738902522:	movq   rax,xmm14
    7c1738902527:	add    rax,rax
    7c173890252a:	je     0x7c1738902540
    7c173890252c:	shr    rax,0x35
    7c1738902530:	sub    eax,0x201
    7c1738902535:	cmp    eax,0x3fc
    7c173890253a:	ja     0x7c173890516f
    7c1738902540:	movq   rax,xmm1
    7c1738902545:	add    rax,rax
    7c1738902548:	je     0x7c173890255e
    7c173890254a:	shr    rax,0x35
    7c173890254e:	sub    eax,0x201
    7c1738902553:	cmp    eax,0x3fc
    7c1738902558:	ja     0x7c173890516f
    7c173890255e:	movdqa xmm14,xmm1
    7c1738902563:	psrldq xmm14,0x8
    7c1738902569:	movq   rax,xmm14
    7c173890256e:	add    rax,rax
    7c1738902571:	je     0x7c1738902587
    7c1738902573:	shr    rax,0x35
    7c1738902577:	sub    eax,0x201
    7c173890257c:	cmp    eax,0x3fc
    7c1738902581:	ja     0x7c173890516f
    7c1738902587:	mulpd  xmm0,xmm1
    7c173890258b:	movdqa xmm4,xmm0
    7c173890258f:	movdqa xmm0,xmm4
    7c1738902593:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c173890259d:	mov    r13,QWORD PTR [r12+0xf8]
    7c17389025a5:	add    r13,0xd0
    7c17389025ac:	stmxcsr DWORD PTR [rsp+0x114]
    7c17389025b4:	ldmxcsr DWORD PTR [rsp+0x110]
    7c17389025bc:	mov    r11d,DWORD PTR [rsp+0x114]
    7c17389025c4:	shr    r11d,1
    7c17389025c7:	and    r11d,0x10
    7c17389025cb:	or     DWORD PTR [r12+0x314],r11d
    7c17389025d3:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c17389025d9:	movdqa xmm0,xmm2
    7c17389025dd:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c17389025e7:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c17389025f1:	movdqa xmm3,xmm0
    7c17389025f5:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7c17389025ff:	movdqa xmm4,xmm0
    7c1738902603:	stmxcsr DWORD PTR [rsp+0x110]
    7c173890260b:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c1738902616:	ldmxcsr DWORD PTR [rsp+0x114]
    7c173890261e:	movdqa xmm0,xmm3
    7c1738902622:	movdqa xmm1,xmm4
    7c1738902626:	movq   rax,xmm0
    7c173890262b:	add    rax,rax
    7c173890262e:	je     0x7c1738902644
    7c1738902630:	shr    rax,0x35
    7c1738902634:	sub    eax,0x201
    7c1738902639:	cmp    eax,0x3fc
    7c173890263e:	ja     0x7c1738905193
    7c1738902644:	movdqa xmm14,xmm0
    7c1738902649:	psrldq xmm14,0x8
    7c173890264f:	movq   rax,xmm14
    7c1738902654:	add    rax,rax
    7c1738902657:	je     0x7c173890266d
    7c1738902659:	shr    rax,0x35
    7c173890265d:	sub    eax,0x201
    7c1738902662:	cmp    eax,0x3fc
    7c1738902667:	ja     0x7c1738905193
    7c173890266d:	movq   rax,xmm1
    7c1738902672:	add    rax,rax
    7c1738902675:	je     0x7c173890268b
    7c1738902677:	shr    rax,0x35
    7c173890267b:	sub    eax,0x201
    7c1738902680:	cmp    eax,0x3fc
    7c1738902685:	ja     0x7c1738905193
    7c173890268b:	movdqa xmm14,xmm1
    7c1738902690:	psrldq xmm14,0x8
    7c1738902696:	movq   rax,xmm14
    7c173890269b:	add    rax,rax
    7c173890269e:	je     0x7c17389026b4
    7c17389026a0:	shr    rax,0x35
    7c17389026a4:	sub    eax,0x201
    7c17389026a9:	cmp    eax,0x3fc
    7c17389026ae:	ja     0x7c1738905193
    7c17389026b4:	addpd  xmm0,xmm1
    7c17389026b8:	movdqa xmm5,xmm0
    7c17389026bc:	movdqa xmm0,xmm5
    7c17389026c0:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c17389026ca:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    7c17389026d4:	movdqa xmm3,xmm0
    7c17389026d8:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c17389026e2:	movdqa xmm4,xmm0
    7c17389026e6:	movdqa xmm0,xmm3
    7c17389026ea:	movdqa xmm1,xmm4
    7c17389026ee:	pshufd xmm1,xmm1,0x44
    7c17389026f3:	movq   rax,xmm0
    7c17389026f8:	add    rax,rax
    7c17389026fb:	je     0x7c1738902711
    7c17389026fd:	shr    rax,0x35
    7c1738902701:	sub    eax,0x201
    7c1738902706:	cmp    eax,0x3fc
    7c173890270b:	ja     0x7c17389051b7
    7c1738902711:	movdqa xmm14,xmm0
    7c1738902716:	psrldq xmm14,0x8
    7c173890271c:	movq   rax,xmm14
    7c1738902721:	add    rax,rax
    7c1738902724:	je     0x7c173890273a
    7c1738902726:	shr    rax,0x35
    7c173890272a:	sub    eax,0x201
    7c173890272f:	cmp    eax,0x3fc
    7c1738902734:	ja     0x7c17389051b7
    7c173890273a:	movq   rax,xmm1
    7c173890273f:	add    rax,rax
    7c1738902742:	je     0x7c1738902758
    7c1738902744:	shr    rax,0x35
    7c1738902748:	sub    eax,0x201
    7c173890274d:	cmp    eax,0x3fc
    7c1738902752:	ja     0x7c17389051b7
    7c1738902758:	movdqa xmm14,xmm1
    7c173890275d:	psrldq xmm14,0x8
    7c1738902763:	movq   rax,xmm14
    7c1738902768:	add    rax,rax
    7c173890276b:	je     0x7c1738902781
    7c173890276d:	shr    rax,0x35
    7c1738902771:	sub    eax,0x201
    7c1738902776:	cmp    eax,0x3fc
    7c173890277b:	ja     0x7c17389051b7
    7c1738902781:	mulpd  xmm0,xmm1
    7c1738902785:	movdqa xmm5,xmm0
    7c1738902789:	movdqa xmm0,xmm5
    7c173890278d:	movdqu XMMWORD PTR [r12+0x260],xmm0
    7c1738902797:	mov    r13d,0x0
    7c173890279d:	mov    r14d,0x0
    7c17389027a3:	mov    QWORD PTR [r12+0x1b0],r13
    7c17389027ab:	mov    QWORD PTR [r12+0x1b8],r14
    7c17389027b3:	movdqa xmm0,xmm2
    7c17389027b7:	movdqa xmm1,xmm4
    7c17389027bb:	pshufd xmm1,xmm1,0x44
    7c17389027c0:	movq   rax,xmm0
    7c17389027c5:	add    rax,rax
    7c17389027c8:	je     0x7c17389027de
    7c17389027ca:	shr    rax,0x35
    7c17389027ce:	sub    eax,0x201
    7c17389027d3:	cmp    eax,0x3fc
    7c17389027d8:	ja     0x7c17389051db
    7c17389027de:	movdqa xmm14,xmm0
    7c17389027e3:	psrldq xmm14,0x8
    7c17389027e9:	movq   rax,xmm14
    7c17389027ee:	add    rax,rax
    7c17389027f1:	je     0x7c1738902807
    7c17389027f3:	shr    rax,0x35
    7c17389027f7:	sub    eax,0x201
    7c17389027fc:	cmp    eax,0x3fc
    7c1738902801:	ja     0x7c17389051db
    7c1738902807:	movq   rax,xmm1
    7c173890280c:	add    rax,rax
    7c173890280f:	je     0x7c1738902825
    7c1738902811:	shr    rax,0x35
    7c1738902815:	sub    eax,0x201
    7c173890281a:	cmp    eax,0x3fc
    7c173890281f:	ja     0x7c17389051db
    7c1738902825:	movdqa xmm14,xmm1
    7c173890282a:	psrldq xmm14,0x8
    7c1738902830:	movq   rax,xmm14
    7c1738902835:	add    rax,rax
    7c1738902838:	je     0x7c173890284e
    7c173890283a:	shr    rax,0x35
    7c173890283e:	sub    eax,0x201
    7c1738902843:	cmp    eax,0x3fc
    7c1738902848:	ja     0x7c17389051db
    7c173890284e:	mulpd  xmm0,xmm1
    7c1738902852:	movdqa xmm3,xmm0
    7c1738902856:	movdqa xmm0,xmm3
    7c173890285a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c1738902864:	mov    r13,QWORD PTR [r12+0xf8]
    7c173890286c:	mov    r14,r13
    7c173890286f:	add    r14,0xc0
    7c1738902876:	stmxcsr DWORD PTR [rsp+0x114]
    7c173890287e:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738902886:	mov    r11d,DWORD PTR [rsp+0x114]
    7c173890288e:	shr    r11d,1
    7c1738902891:	and    r11d,0x10
    7c1738902895:	or     DWORD PTR [r12+0x314],r11d
    7c173890289d:	movdqu xmm2,XMMWORD PTR [r14]
    7c17389028a2:	movdqa xmm0,xmm2
    7c17389028a6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c17389028b0:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c17389028ba:	movdqa xmm3,xmm0
    7c17389028be:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c17389028c8:	movdqa xmm4,xmm0
    7c17389028cc:	stmxcsr DWORD PTR [rsp+0x110]
    7c17389028d4:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c17389028df:	ldmxcsr DWORD PTR [rsp+0x114]
    7c17389028e7:	movdqa xmm0,xmm3
    7c17389028eb:	movdqa xmm1,xmm4
    7c17389028ef:	movq   rax,xmm0
    7c17389028f4:	add    rax,rax
    7c17389028f7:	je     0x7c173890290d
    7c17389028f9:	shr    rax,0x35
    7c17389028fd:	sub    eax,0x201
    7c1738902902:	cmp    eax,0x3fc
    7c1738902907:	ja     0x7c17389051ff
    7c173890290d:	movdqa xmm14,xmm0
    7c1738902912:	psrldq xmm14,0x8
    7c1738902918:	movq   rax,xmm14
    7c173890291d:	add    rax,rax
    7c1738902920:	je     0x7c1738902936
    7c1738902922:	shr    rax,0x35
    7c1738902926:	sub    eax,0x201
    7c173890292b:	cmp    eax,0x3fc
    7c1738902930:	ja     0x7c17389051ff
    7c1738902936:	movq   rax,xmm1
    7c173890293b:	add    rax,rax
    7c173890293e:	je     0x7c1738902954
    7c1738902940:	shr    rax,0x35
    7c1738902944:	sub    eax,0x201
    7c1738902949:	cmp    eax,0x3fc
    7c173890294e:	ja     0x7c17389051ff
    7c1738902954:	movdqa xmm14,xmm1
    7c1738902959:	psrldq xmm14,0x8
    7c173890295f:	movq   rax,xmm14
    7c1738902964:	add    rax,rax
    7c1738902967:	je     0x7c173890297d
    7c1738902969:	shr    rax,0x35
    7c173890296d:	sub    eax,0x201
    7c1738902972:	cmp    eax,0x3fc
    7c1738902977:	ja     0x7c17389051ff
    7c173890297d:	addpd  xmm0,xmm1
    7c1738902981:	movdqa xmm5,xmm0
    7c1738902985:	movdqa xmm0,xmm5
    7c1738902989:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c1738902993:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7c173890299d:	movdqa xmm3,xmm0
    7c17389029a1:	movdqa xmm1,xmm3
    7c17389029a5:	por    xmm3,xmm1
    7c17389029a9:	movdqa xmm0,xmm3
    7c17389029ad:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c17389029b7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c17389029c1:	movdqa xmm3,xmm0
    7c17389029c5:	movdqa xmm1,xmm3
    7c17389029c9:	por    xmm3,xmm1
    7c17389029cd:	movdqa xmm0,xmm3
    7c17389029d1:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    7c17389029db:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c17389029e5:	movdqa xmm3,xmm0
    7c17389029e9:	movdqa xmm0,xmm2
    7c17389029ed:	movdqa xmm1,xmm3
    7c17389029f1:	pshufd xmm1,xmm1,0x44
    7c17389029f6:	movq   rax,xmm0
    7c17389029fb:	add    rax,rax
    7c17389029fe:	je     0x7c1738902a14
    7c1738902a00:	shr    rax,0x35
    7c1738902a04:	sub    eax,0x201
    7c1738902a09:	cmp    eax,0x3fc
    7c1738902a0e:	ja     0x7c1738905223
    7c1738902a14:	movdqa xmm14,xmm0
    7c1738902a19:	psrldq xmm14,0x8
    7c1738902a1f:	movq   rax,xmm14
    7c1738902a24:	add    rax,rax
    7c1738902a27:	je     0x7c1738902a3d
    7c1738902a29:	shr    rax,0x35
    7c1738902a2d:	sub    eax,0x201
    7c1738902a32:	cmp    eax,0x3fc
    7c1738902a37:	ja     0x7c1738905223
    7c1738902a3d:	movq   rax,xmm1
    7c1738902a42:	add    rax,rax
    7c1738902a45:	je     0x7c1738902a5b
    7c1738902a47:	shr    rax,0x35
    7c1738902a4b:	sub    eax,0x201
    7c1738902a50:	cmp    eax,0x3fc
    7c1738902a55:	ja     0x7c1738905223
    7c1738902a5b:	movdqa xmm14,xmm1
    7c1738902a60:	psrldq xmm14,0x8
    7c1738902a66:	movq   rax,xmm14
    7c1738902a6b:	add    rax,rax
    7c1738902a6e:	je     0x7c1738902a84
    7c1738902a70:	shr    rax,0x35
    7c1738902a74:	sub    eax,0x201
    7c1738902a79:	cmp    eax,0x3fc
    7c1738902a7e:	ja     0x7c1738905223
    7c1738902a84:	mulpd  xmm0,xmm1
    7c1738902a88:	movdqa xmm4,xmm0
    7c1738902a8c:	movdqa xmm0,xmm4
    7c1738902a90:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c1738902a9a:	add    r13,0x20
    7c1738902a9e:	stmxcsr DWORD PTR [rsp+0x114]
    7c1738902aa6:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738902aae:	mov    r11d,DWORD PTR [rsp+0x114]
    7c1738902ab6:	shr    r11d,1
    7c1738902ab9:	and    r11d,0x10
    7c1738902abd:	or     DWORD PTR [r12+0x314],r11d
    7c1738902ac5:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c1738902acb:	movdqa xmm0,xmm2
    7c1738902acf:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c1738902ad9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c1738902ae3:	movdqa xmm2,xmm0
    7c1738902ae7:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c1738902af1:	movdqa xmm4,xmm0
    7c1738902af5:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738902afd:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c1738902b08:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738902b10:	movdqa xmm0,xmm2
    7c1738902b14:	movdqa xmm1,xmm4
    7c1738902b18:	movq   rax,xmm0
    7c1738902b1d:	add    rax,rax
    7c1738902b20:	je     0x7c1738902b36
    7c1738902b22:	shr    rax,0x35
    7c1738902b26:	sub    eax,0x201
    7c1738902b2b:	cmp    eax,0x3fc
    7c1738902b30:	ja     0x7c1738905247
    7c1738902b36:	movdqa xmm14,xmm0
    7c1738902b3b:	psrldq xmm14,0x8
    7c1738902b41:	movq   rax,xmm14
    7c1738902b46:	add    rax,rax
    7c1738902b49:	je     0x7c1738902b5f
    7c1738902b4b:	shr    rax,0x35
    7c1738902b4f:	sub    eax,0x201
    7c1738902b54:	cmp    eax,0x3fc
    7c1738902b59:	ja     0x7c1738905247
    7c1738902b5f:	movq   rax,xmm1
    7c1738902b64:	add    rax,rax
    7c1738902b67:	je     0x7c1738902b7d
    7c1738902b69:	shr    rax,0x35
    7c1738902b6d:	sub    eax,0x201
    7c1738902b72:	cmp    eax,0x3fc
    7c1738902b77:	ja     0x7c1738905247
    7c1738902b7d:	movdqa xmm14,xmm1
    7c1738902b82:	psrldq xmm14,0x8
    7c1738902b88:	movq   rax,xmm14
    7c1738902b8d:	add    rax,rax
    7c1738902b90:	je     0x7c1738902ba6
    7c1738902b92:	shr    rax,0x35
    7c1738902b96:	sub    eax,0x201
    7c1738902b9b:	cmp    eax,0x3fc
    7c1738902ba0:	ja     0x7c1738905247
    7c1738902ba6:	addpd  xmm0,xmm1
    7c1738902baa:	movdqa xmm5,xmm0
    7c1738902bae:	movdqa xmm0,xmm5
    7c1738902bb2:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c1738902bbc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    7c1738902bc6:	movdqa xmm2,xmm0
    7c1738902bca:	movdqa xmm0,xmm2
    7c1738902bce:	movdqa xmm1,xmm3
    7c1738902bd2:	pshufd xmm1,xmm1,0x44
    7c1738902bd7:	movq   rax,xmm0
    7c1738902bdc:	add    rax,rax
    7c1738902bdf:	je     0x7c1738902bf5
    7c1738902be1:	shr    rax,0x35
    7c1738902be5:	sub    eax,0x201
    7c1738902bea:	cmp    eax,0x3fc
    7c1738902bef:	ja     0x7c173890526b
    7c1738902bf5:	movdqa xmm14,xmm0
    7c1738902bfa:	psrldq xmm14,0x8
    7c1738902c00:	movq   rax,xmm14
    7c1738902c05:	add    rax,rax
    7c1738902c08:	je     0x7c1738902c1e
    7c1738902c0a:	shr    rax,0x35
    7c1738902c0e:	sub    eax,0x201
    7c1738902c13:	cmp    eax,0x3fc
    7c1738902c18:	ja     0x7c173890526b
    7c1738902c1e:	movq   rax,xmm1
    7c1738902c23:	add    rax,rax
    7c1738902c26:	je     0x7c1738902c3c
    7c1738902c28:	shr    rax,0x35
    7c1738902c2c:	sub    eax,0x201
    7c1738902c31:	cmp    eax,0x3fc
    7c1738902c36:	ja     0x7c173890526b
    7c1738902c3c:	movdqa xmm14,xmm1
    7c1738902c41:	psrldq xmm14,0x8
    7c1738902c47:	movq   rax,xmm14
    7c1738902c4c:	add    rax,rax
    7c1738902c4f:	je     0x7c1738902c65
    7c1738902c51:	shr    rax,0x35
    7c1738902c55:	sub    eax,0x201
    7c1738902c5a:	cmp    eax,0x3fc
    7c1738902c5f:	ja     0x7c173890526b
    7c1738902c65:	mulpd  xmm0,xmm1
    7c1738902c69:	movdqa xmm4,xmm0
    7c1738902c6d:	movdqa xmm0,xmm4
    7c1738902c71:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c1738902c7b:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c1738902c85:	movdqa xmm2,xmm0
    7c1738902c89:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c1738902c93:	movdqa xmm3,xmm0
    7c1738902c97:	movdqa xmm0,xmm2
    7c1738902c9b:	movdqa xmm1,xmm3
    7c1738902c9f:	movq   rax,xmm0
    7c1738902ca4:	add    rax,rax
    7c1738902ca7:	je     0x7c1738902cbd
    7c1738902ca9:	shr    rax,0x35
    7c1738902cad:	sub    eax,0x201
    7c1738902cb2:	cmp    eax,0x3fc
    7c1738902cb7:	ja     0x7c173890528f
    7c1738902cbd:	movdqa xmm14,xmm0
    7c1738902cc2:	psrldq xmm14,0x8
    7c1738902cc8:	movq   rax,xmm14
    7c1738902ccd:	add    rax,rax
    7c1738902cd0:	je     0x7c1738902ce6
    7c1738902cd2:	shr    rax,0x35
    7c1738902cd6:	sub    eax,0x201
    7c1738902cdb:	cmp    eax,0x3fc
    7c1738902ce0:	ja     0x7c173890528f
    7c1738902ce6:	movq   rax,xmm1
    7c1738902ceb:	add    rax,rax
    7c1738902cee:	je     0x7c1738902d04
    7c1738902cf0:	shr    rax,0x35
    7c1738902cf4:	sub    eax,0x201
    7c1738902cf9:	cmp    eax,0x3fc
    7c1738902cfe:	ja     0x7c173890528f
    7c1738902d04:	movdqa xmm14,xmm1
    7c1738902d09:	psrldq xmm14,0x8
    7c1738902d0f:	movq   rax,xmm14
    7c1738902d14:	add    rax,rax
    7c1738902d17:	je     0x7c1738902d2d
    7c1738902d19:	shr    rax,0x35
    7c1738902d1d:	sub    eax,0x201
    7c1738902d22:	cmp    eax,0x3fc
    7c1738902d27:	ja     0x7c173890528f
    7c1738902d2d:	addpd  xmm0,xmm1
    7c1738902d31:	movdqa xmm4,xmm0
    7c1738902d35:	movdqa xmm0,xmm4
    7c1738902d39:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c1738902d43:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c1738902d4d:	movdqa xmm2,xmm0
    7c1738902d51:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c1738902d5b:	movdqa xmm3,xmm0
    7c1738902d5f:	movdqa xmm0,xmm2
    7c1738902d63:	movdqa xmm1,xmm3
    7c1738902d67:	pshufd xmm1,xmm1,0x44
    7c1738902d6c:	movq   rax,xmm0
    7c1738902d71:	add    rax,rax
    7c1738902d74:	je     0x7c1738902d8a
    7c1738902d76:	shr    rax,0x35
    7c1738902d7a:	sub    eax,0x201
    7c1738902d7f:	cmp    eax,0x3fc
    7c1738902d84:	ja     0x7c17389052b3
    7c1738902d8a:	movdqa xmm14,xmm0
    7c1738902d8f:	psrldq xmm14,0x8
    7c1738902d95:	movq   rax,xmm14
    7c1738902d9a:	add    rax,rax
    7c1738902d9d:	je     0x7c1738902db3
    7c1738902d9f:	shr    rax,0x35
    7c1738902da3:	sub    eax,0x201
    7c1738902da8:	cmp    eax,0x3fc
    7c1738902dad:	ja     0x7c17389052b3
    7c1738902db3:	movq   rax,xmm1
    7c1738902db8:	add    rax,rax
    7c1738902dbb:	je     0x7c1738902dd1
    7c1738902dbd:	shr    rax,0x35
    7c1738902dc1:	sub    eax,0x201
    7c1738902dc6:	cmp    eax,0x3fc
    7c1738902dcb:	ja     0x7c17389052b3
    7c1738902dd1:	movdqa xmm14,xmm1
    7c1738902dd6:	psrldq xmm14,0x8
    7c1738902ddc:	movq   rax,xmm14
    7c1738902de1:	add    rax,rax
    7c1738902de4:	je     0x7c1738902dfa
    7c1738902de6:	shr    rax,0x35
    7c1738902dea:	sub    eax,0x201
    7c1738902def:	cmp    eax,0x3fc
    7c1738902df4:	ja     0x7c17389052b3
    7c1738902dfa:	mulpd  xmm0,xmm1
    7c1738902dfe:	movdqa xmm4,xmm0
    7c1738902e02:	movdqa xmm0,xmm4
    7c1738902e06:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c1738902e10:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7c1738902e1a:	movdqa xmm2,xmm0
    7c1738902e1e:	movdqa xmm0,xmm2
    7c1738902e22:	movdqa xmm1,xmm3
    7c1738902e26:	pshufd xmm1,xmm1,0x44
    7c1738902e2b:	movq   rax,xmm0
    7c1738902e30:	add    rax,rax
    7c1738902e33:	je     0x7c1738902e49
    7c1738902e35:	shr    rax,0x35
    7c1738902e39:	sub    eax,0x201
    7c1738902e3e:	cmp    eax,0x3fc
    7c1738902e43:	ja     0x7c17389052d7
    7c1738902e49:	movdqa xmm14,xmm0
    7c1738902e4e:	psrldq xmm14,0x8
    7c1738902e54:	movq   rax,xmm14
    7c1738902e59:	add    rax,rax
    7c1738902e5c:	je     0x7c1738902e72
    7c1738902e5e:	shr    rax,0x35
    7c1738902e62:	sub    eax,0x201
    7c1738902e67:	cmp    eax,0x3fc
    7c1738902e6c:	ja     0x7c17389052d7
    7c1738902e72:	movq   rax,xmm1
    7c1738902e77:	add    rax,rax
    7c1738902e7a:	je     0x7c1738902e90
    7c1738902e7c:	shr    rax,0x35
    7c1738902e80:	sub    eax,0x201
    7c1738902e85:	cmp    eax,0x3fc
    7c1738902e8a:	ja     0x7c17389052d7
    7c1738902e90:	movdqa xmm14,xmm1
    7c1738902e95:	psrldq xmm14,0x8
    7c1738902e9b:	movq   rax,xmm14
    7c1738902ea0:	add    rax,rax
    7c1738902ea3:	je     0x7c1738902eb9
    7c1738902ea5:	shr    rax,0x35
    7c1738902ea9:	sub    eax,0x201
    7c1738902eae:	cmp    eax,0x3fc
    7c1738902eb3:	ja     0x7c17389052d7
    7c1738902eb9:	mulpd  xmm0,xmm1
    7c1738902ebd:	movdqa xmm4,xmm0
    7c1738902ec1:	movdqa xmm0,xmm4
    7c1738902ec5:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c1738902ecf:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c1738902ed9:	movdqa xmm2,xmm0
    7c1738902edd:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7c1738902ee7:	movdqa xmm4,xmm0
    7c1738902eeb:	movdqa xmm0,xmm2
    7c1738902eef:	movdqa xmm1,xmm4
    7c1738902ef3:	movq   rax,xmm0
    7c1738902ef8:	add    rax,rax
    7c1738902efb:	je     0x7c1738902f11
    7c1738902efd:	shr    rax,0x35
    7c1738902f01:	sub    eax,0x201
    7c1738902f06:	cmp    eax,0x3fc
    7c1738902f0b:	ja     0x7c17389052fb
    7c1738902f11:	movdqa xmm14,xmm0
    7c1738902f16:	psrldq xmm14,0x8
    7c1738902f1c:	movq   rax,xmm14
    7c1738902f21:	add    rax,rax
    7c1738902f24:	je     0x7c1738902f3a
    7c1738902f26:	shr    rax,0x35
    7c1738902f2a:	sub    eax,0x201
    7c1738902f2f:	cmp    eax,0x3fc
    7c1738902f34:	ja     0x7c17389052fb
    7c1738902f3a:	movq   rax,xmm1
    7c1738902f3f:	add    rax,rax
    7c1738902f42:	je     0x7c1738902f58
    7c1738902f44:	shr    rax,0x35
    7c1738902f48:	sub    eax,0x201
    7c1738902f4d:	cmp    eax,0x3fc
    7c1738902f52:	ja     0x7c17389052fb
    7c1738902f58:	movdqa xmm14,xmm1
    7c1738902f5d:	psrldq xmm14,0x8
    7c1738902f63:	movq   rax,xmm14
    7c1738902f68:	add    rax,rax
    7c1738902f6b:	je     0x7c1738902f81
    7c1738902f6d:	shr    rax,0x35
    7c1738902f71:	sub    eax,0x201
    7c1738902f76:	cmp    eax,0x3fc
    7c1738902f7b:	ja     0x7c17389052fb
    7c1738902f81:	addpd  xmm0,xmm1
    7c1738902f85:	movdqa xmm5,xmm0
    7c1738902f89:	movdqa xmm0,xmm5
    7c1738902f8d:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c1738902f97:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c1738902fa1:	movdqa xmm2,xmm0
    7c1738902fa5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c1738902faf:	movdqa xmm4,xmm0
    7c1738902fb3:	movdqa xmm0,xmm2
    7c1738902fb7:	movdqa xmm1,xmm4
    7c1738902fbb:	movq   rax,xmm0
    7c1738902fc0:	add    rax,rax
    7c1738902fc3:	je     0x7c1738902fd9
    7c1738902fc5:	shr    rax,0x35
    7c1738902fc9:	sub    eax,0x201
    7c1738902fce:	cmp    eax,0x3fc
    7c1738902fd3:	ja     0x7c173890531f
    7c1738902fd9:	movdqa xmm14,xmm0
    7c1738902fde:	psrldq xmm14,0x8
    7c1738902fe4:	movq   rax,xmm14
    7c1738902fe9:	add    rax,rax
    7c1738902fec:	je     0x7c1738903002
    7c1738902fee:	shr    rax,0x35
    7c1738902ff2:	sub    eax,0x201
    7c1738902ff7:	cmp    eax,0x3fc
    7c1738902ffc:	ja     0x7c173890531f
    7c1738903002:	movq   rax,xmm1
    7c1738903007:	add    rax,rax
    7c173890300a:	je     0x7c1738903020
    7c173890300c:	shr    rax,0x35
    7c1738903010:	sub    eax,0x201
    7c1738903015:	cmp    eax,0x3fc
    7c173890301a:	ja     0x7c173890531f
    7c1738903020:	movdqa xmm14,xmm1
    7c1738903025:	psrldq xmm14,0x8
    7c173890302b:	movq   rax,xmm14
    7c1738903030:	add    rax,rax
    7c1738903033:	je     0x7c1738903049
    7c1738903035:	shr    rax,0x35
    7c1738903039:	sub    eax,0x201
    7c173890303e:	cmp    eax,0x3fc
    7c1738903043:	ja     0x7c173890531f
    7c1738903049:	addpd  xmm0,xmm1
    7c173890304d:	movdqa xmm5,xmm0
    7c1738903051:	movdqa xmm0,xmm5
    7c1738903055:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c173890305f:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7c1738903069:	movdqa xmm2,xmm0
    7c173890306d:	movdqa xmm0,xmm2
    7c1738903071:	movdqa xmm1,xmm3
    7c1738903075:	pshufd xmm1,xmm1,0x44
    7c173890307a:	movq   rax,xmm0
    7c173890307f:	add    rax,rax
    7c1738903082:	je     0x7c1738903098
    7c1738903084:	shr    rax,0x35
    7c1738903088:	sub    eax,0x201
    7c173890308d:	cmp    eax,0x3fc
    7c1738903092:	ja     0x7c1738905343
    7c1738903098:	movdqa xmm14,xmm0
    7c173890309d:	psrldq xmm14,0x8
    7c17389030a3:	movq   rax,xmm14
    7c17389030a8:	add    rax,rax
    7c17389030ab:	je     0x7c17389030c1
    7c17389030ad:	shr    rax,0x35
    7c17389030b1:	sub    eax,0x201
    7c17389030b6:	cmp    eax,0x3fc
    7c17389030bb:	ja     0x7c1738905343
    7c17389030c1:	movq   rax,xmm1
    7c17389030c6:	add    rax,rax
    7c17389030c9:	je     0x7c17389030df
    7c17389030cb:	shr    rax,0x35
    7c17389030cf:	sub    eax,0x201
    7c17389030d4:	cmp    eax,0x3fc
    7c17389030d9:	ja     0x7c1738905343
    7c17389030df:	movdqa xmm14,xmm1
    7c17389030e4:	psrldq xmm14,0x8
    7c17389030ea:	movq   rax,xmm14
    7c17389030ef:	add    rax,rax
    7c17389030f2:	je     0x7c1738903108
    7c17389030f4:	shr    rax,0x35
    7c17389030f8:	sub    eax,0x201
    7c17389030fd:	cmp    eax,0x3fc
    7c1738903102:	ja     0x7c1738905343
    7c1738903108:	mulpd  xmm0,xmm1
    7c173890310c:	movdqa xmm4,xmm0
    7c1738903110:	movdqa xmm0,xmm4
    7c1738903114:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c173890311e:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7c1738903128:	movdqa xmm2,xmm0
    7c173890312c:	movdqa xmm0,xmm2
    7c1738903130:	movdqa xmm1,xmm3
    7c1738903134:	pshufd xmm1,xmm1,0x44
    7c1738903139:	movq   rax,xmm0
    7c173890313e:	add    rax,rax
    7c1738903141:	je     0x7c1738903157
    7c1738903143:	shr    rax,0x35
    7c1738903147:	sub    eax,0x201
    7c173890314c:	cmp    eax,0x3fc
    7c1738903151:	ja     0x7c1738905367
    7c1738903157:	movdqa xmm14,xmm0
    7c173890315c:	psrldq xmm14,0x8
    7c1738903162:	movq   rax,xmm14
    7c1738903167:	add    rax,rax
    7c173890316a:	je     0x7c1738903180
    7c173890316c:	shr    rax,0x35
    7c1738903170:	sub    eax,0x201
    7c1738903175:	cmp    eax,0x3fc
    7c173890317a:	ja     0x7c1738905367
    7c1738903180:	movq   rax,xmm1
    7c1738903185:	add    rax,rax
    7c1738903188:	je     0x7c173890319e
    7c173890318a:	shr    rax,0x35
    7c173890318e:	sub    eax,0x201
    7c1738903193:	cmp    eax,0x3fc
    7c1738903198:	ja     0x7c1738905367
    7c173890319e:	movdqa xmm14,xmm1
    7c17389031a3:	psrldq xmm14,0x8
    7c17389031a9:	movq   rax,xmm14
    7c17389031ae:	add    rax,rax
    7c17389031b1:	je     0x7c17389031c7
    7c17389031b3:	shr    rax,0x35
    7c17389031b7:	sub    eax,0x201
    7c17389031bc:	cmp    eax,0x3fc
    7c17389031c1:	ja     0x7c1738905367
    7c17389031c7:	mulpd  xmm0,xmm1
    7c17389031cb:	movdqa xmm4,xmm0
    7c17389031cf:	movdqa xmm0,xmm4
    7c17389031d3:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c17389031dd:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c17389031e7:	movdqa xmm2,xmm0
    7c17389031eb:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c17389031f5:	movdqa xmm3,xmm0
    7c17389031f9:	movdqa xmm0,xmm2
    7c17389031fd:	movdqa xmm1,xmm3
    7c1738903201:	movq   rax,xmm0
    7c1738903206:	add    rax,rax
    7c1738903209:	je     0x7c173890321f
    7c173890320b:	shr    rax,0x35
    7c173890320f:	sub    eax,0x201
    7c1738903214:	cmp    eax,0x3fc
    7c1738903219:	ja     0x7c173890538b
    7c173890321f:	movdqa xmm14,xmm0
    7c1738903224:	psrldq xmm14,0x8
    7c173890322a:	movq   rax,xmm14
    7c173890322f:	add    rax,rax
    7c1738903232:	je     0x7c1738903248
    7c1738903234:	shr    rax,0x35
    7c1738903238:	sub    eax,0x201
    7c173890323d:	cmp    eax,0x3fc
    7c1738903242:	ja     0x7c173890538b
    7c1738903248:	movq   rax,xmm1
    7c173890324d:	add    rax,rax
    7c1738903250:	je     0x7c1738903266
    7c1738903252:	shr    rax,0x35
    7c1738903256:	sub    eax,0x201
    7c173890325b:	cmp    eax,0x3fc
    7c1738903260:	ja     0x7c173890538b
    7c1738903266:	movdqa xmm14,xmm1
    7c173890326b:	psrldq xmm14,0x8
    7c1738903271:	movq   rax,xmm14
    7c1738903276:	add    rax,rax
    7c1738903279:	je     0x7c173890328f
    7c173890327b:	shr    rax,0x35
    7c173890327f:	sub    eax,0x201
    7c1738903284:	cmp    eax,0x3fc
    7c1738903289:	ja     0x7c173890538b
    7c173890328f:	addpd  xmm0,xmm1
    7c1738903293:	movdqa xmm4,xmm0
    7c1738903297:	movdqa xmm0,xmm4
    7c173890329b:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c17389032a5:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c17389032af:	movdqa xmm2,xmm0
    7c17389032b3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c17389032bd:	movdqa xmm3,xmm0
    7c17389032c1:	movdqa xmm0,xmm2
    7c17389032c5:	movdqa xmm1,xmm3
    7c17389032c9:	movq   rax,xmm0
    7c17389032ce:	add    rax,rax
    7c17389032d1:	je     0x7c17389032e7
    7c17389032d3:	shr    rax,0x35
    7c17389032d7:	sub    eax,0x201
    7c17389032dc:	cmp    eax,0x3fc
    7c17389032e1:	ja     0x7c17389053af
    7c17389032e7:	movdqa xmm14,xmm0
    7c17389032ec:	psrldq xmm14,0x8
    7c17389032f2:	movq   rax,xmm14
    7c17389032f7:	add    rax,rax
    7c17389032fa:	je     0x7c1738903310
    7c17389032fc:	shr    rax,0x35
    7c1738903300:	sub    eax,0x201
    7c1738903305:	cmp    eax,0x3fc
    7c173890330a:	ja     0x7c17389053af
    7c1738903310:	movq   rax,xmm1
    7c1738903315:	add    rax,rax
    7c1738903318:	je     0x7c173890332e
    7c173890331a:	shr    rax,0x35
    7c173890331e:	sub    eax,0x201
    7c1738903323:	cmp    eax,0x3fc
    7c1738903328:	ja     0x7c17389053af
    7c173890332e:	movdqa xmm14,xmm1
    7c1738903333:	psrldq xmm14,0x8
    7c1738903339:	movq   rax,xmm14
    7c173890333e:	add    rax,rax
    7c1738903341:	je     0x7c1738903357
    7c1738903343:	shr    rax,0x35
    7c1738903347:	sub    eax,0x201
    7c173890334c:	cmp    eax,0x3fc
    7c1738903351:	ja     0x7c17389053af
    7c1738903357:	addpd  xmm0,xmm1
    7c173890335b:	movdqa xmm4,xmm0
    7c173890335f:	movdqa xmm0,xmm4
    7c1738903363:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c173890336d:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c1738903377:	movdqa xmm2,xmm0
    7c173890337b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c1738903385:	movdqa xmm3,xmm0
    7c1738903389:	movdqa xmm0,xmm2
    7c173890338d:	movdqa xmm1,xmm3
    7c1738903391:	pshufd xmm1,xmm1,0x44
    7c1738903396:	movq   rax,xmm0
    7c173890339b:	add    rax,rax
    7c173890339e:	je     0x7c17389033b4
    7c17389033a0:	shr    rax,0x35
    7c17389033a4:	sub    eax,0x201
    7c17389033a9:	cmp    eax,0x3fc
    7c17389033ae:	ja     0x7c17389053d3
    7c17389033b4:	movdqa xmm14,xmm0
    7c17389033b9:	psrldq xmm14,0x8
    7c17389033bf:	movq   rax,xmm14
    7c17389033c4:	add    rax,rax
    7c17389033c7:	je     0x7c17389033dd
    7c17389033c9:	shr    rax,0x35
    7c17389033cd:	sub    eax,0x201
    7c17389033d2:	cmp    eax,0x3fc
    7c17389033d7:	ja     0x7c17389053d3
    7c17389033dd:	movq   rax,xmm1
    7c17389033e2:	add    rax,rax
    7c17389033e5:	je     0x7c17389033fb
    7c17389033e7:	shr    rax,0x35
    7c17389033eb:	sub    eax,0x201
    7c17389033f0:	cmp    eax,0x3fc
    7c17389033f5:	ja     0x7c17389053d3
    7c17389033fb:	movdqa xmm14,xmm1
    7c1738903400:	psrldq xmm14,0x8
    7c1738903406:	movq   rax,xmm14
    7c173890340b:	add    rax,rax
    7c173890340e:	je     0x7c1738903424
    7c1738903410:	shr    rax,0x35
    7c1738903414:	sub    eax,0x201
    7c1738903419:	cmp    eax,0x3fc
    7c173890341e:	ja     0x7c17389053d3
    7c1738903424:	mulpd  xmm0,xmm1
    7c1738903428:	movdqa xmm4,xmm0
    7c173890342c:	movdqa xmm0,xmm4
    7c1738903430:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c173890343a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c1738903444:	movdqa xmm2,xmm0
    7c1738903448:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c1738903452:	movdqa xmm3,xmm0
    7c1738903456:	movdqa xmm0,xmm2
    7c173890345a:	movdqa xmm1,xmm3
    7c173890345e:	movq   rax,xmm0
    7c1738903463:	add    rax,rax
    7c1738903466:	je     0x7c173890347c
    7c1738903468:	shr    rax,0x35
    7c173890346c:	sub    eax,0x201
    7c1738903471:	cmp    eax,0x3fc
    7c1738903476:	ja     0x7c17389053f7
    7c173890347c:	movdqa xmm14,xmm0
    7c1738903481:	psrldq xmm14,0x8
    7c1738903487:	movq   rax,xmm14
    7c173890348c:	add    rax,rax
    7c173890348f:	je     0x7c17389034a5
    7c1738903491:	shr    rax,0x35
    7c1738903495:	sub    eax,0x201
    7c173890349a:	cmp    eax,0x3fc
    7c173890349f:	ja     0x7c17389053f7
    7c17389034a5:	movq   rax,xmm1
    7c17389034aa:	add    rax,rax
    7c17389034ad:	je     0x7c17389034c3
    7c17389034af:	shr    rax,0x35
    7c17389034b3:	sub    eax,0x201
    7c17389034b8:	cmp    eax,0x3fc
    7c17389034bd:	ja     0x7c17389053f7
    7c17389034c3:	movdqa xmm14,xmm1
    7c17389034c8:	psrldq xmm14,0x8
    7c17389034ce:	movq   rax,xmm14
    7c17389034d3:	add    rax,rax
    7c17389034d6:	je     0x7c17389034ec
    7c17389034d8:	shr    rax,0x35
    7c17389034dc:	sub    eax,0x201
    7c17389034e1:	cmp    eax,0x3fc
    7c17389034e6:	ja     0x7c17389053f7
    7c17389034ec:	addpd  xmm0,xmm1
    7c17389034f0:	movdqa xmm4,xmm0
    7c17389034f4:	movdqa xmm0,xmm4
    7c17389034f8:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c1738903502:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c173890350c:	movdqa xmm2,xmm0
    7c1738903510:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7c173890351a:	movdqa xmm3,xmm0
    7c173890351e:	movdqa xmm0,xmm2
    7c1738903522:	movdqa xmm1,xmm3
    7c1738903526:	movq   rax,xmm0
    7c173890352b:	add    rax,rax
    7c173890352e:	je     0x7c1738903544
    7c1738903530:	shr    rax,0x35
    7c1738903534:	sub    eax,0x201
    7c1738903539:	cmp    eax,0x3fc
    7c173890353e:	ja     0x7c173890541b
    7c1738903544:	movdqa xmm14,xmm0
    7c1738903549:	psrldq xmm14,0x8
    7c173890354f:	movq   rax,xmm14
    7c1738903554:	add    rax,rax
    7c1738903557:	je     0x7c173890356d
    7c1738903559:	shr    rax,0x35
    7c173890355d:	sub    eax,0x201
    7c1738903562:	cmp    eax,0x3fc
    7c1738903567:	ja     0x7c173890541b
    7c173890356d:	movq   rax,xmm1
    7c1738903572:	add    rax,rax
    7c1738903575:	je     0x7c173890358b
    7c1738903577:	shr    rax,0x35
    7c173890357b:	sub    eax,0x201
    7c1738903580:	cmp    eax,0x3fc
    7c1738903585:	ja     0x7c173890541b
    7c173890358b:	movdqa xmm14,xmm1
    7c1738903590:	psrldq xmm14,0x8
    7c1738903596:	movq   rax,xmm14
    7c173890359b:	add    rax,rax
    7c173890359e:	je     0x7c17389035b4
    7c17389035a0:	shr    rax,0x35
    7c17389035a4:	sub    eax,0x201
    7c17389035a9:	cmp    eax,0x3fc
    7c17389035ae:	ja     0x7c173890541b
    7c17389035b4:	addpd  xmm0,xmm1
    7c17389035b8:	movdqa xmm4,xmm0
    7c17389035bc:	movdqa xmm0,xmm4
    7c17389035c0:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c17389035ca:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    7c17389035d4:	movdqa xmm2,xmm0
    7c17389035d8:	movdqa xmm1,xmm2
    7c17389035dc:	por    xmm2,xmm1
    7c17389035e0:	movdqa xmm0,xmm2
    7c17389035e4:	movdqu XMMWORD PTR [r12+0x250],xmm0
    7c17389035ee:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    7c17389035f8:	movdqa xmm2,xmm0
    7c17389035fc:	movdqa xmm1,xmm2
    7c1738903600:	por    xmm2,xmm1
    7c1738903604:	movdqa xmm0,xmm2
    7c1738903608:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    7c1738903612:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    7c173890361c:	movdqa xmm2,xmm0
    7c1738903620:	movdqa xmm1,xmm2
    7c1738903624:	por    xmm2,xmm1
    7c1738903628:	movdqa xmm0,xmm2
    7c173890362c:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    7c1738903636:	mov    r13,QWORD PTR [r12+0xf8]
    7c173890363e:	add    r13,0x40
    7c1738903642:	stmxcsr DWORD PTR [rsp+0x114]
    7c173890364a:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738903652:	mov    r11d,DWORD PTR [rsp+0x114]
    7c173890365a:	shr    r11d,1
    7c173890365d:	and    r11d,0x10
    7c1738903661:	or     DWORD PTR [r12+0x314],r11d
    7c1738903669:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c173890366f:	movdqa xmm0,xmm2
    7c1738903673:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    7c173890367d:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7c1738903687:	movdqa xmm2,xmm0
    7c173890368b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c1738903695:	movdqa xmm3,xmm0
    7c1738903699:	stmxcsr DWORD PTR [rsp+0x110]
    7c17389036a1:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c17389036ac:	ldmxcsr DWORD PTR [rsp+0x114]
    7c17389036b4:	movdqa xmm0,xmm2
    7c17389036b8:	movdqa xmm1,xmm3
    7c17389036bc:	pshufd xmm1,xmm1,0x44
    7c17389036c1:	movq   rax,xmm0
    7c17389036c6:	add    rax,rax
    7c17389036c9:	je     0x7c17389036df
    7c17389036cb:	shr    rax,0x35
    7c17389036cf:	sub    eax,0x201
    7c17389036d4:	cmp    eax,0x3fc
    7c17389036d9:	ja     0x7c173890543f
    7c17389036df:	movdqa xmm14,xmm0
    7c17389036e4:	psrldq xmm14,0x8
    7c17389036ea:	movq   rax,xmm14
    7c17389036ef:	add    rax,rax
    7c17389036f2:	je     0x7c1738903708
    7c17389036f4:	shr    rax,0x35
    7c17389036f8:	sub    eax,0x201
    7c17389036fd:	cmp    eax,0x3fc
    7c1738903702:	ja     0x7c173890543f
    7c1738903708:	movq   rax,xmm1
    7c173890370d:	add    rax,rax
    7c1738903710:	je     0x7c1738903726
    7c1738903712:	shr    rax,0x35
    7c1738903716:	sub    eax,0x201
    7c173890371b:	cmp    eax,0x3fc
    7c1738903720:	ja     0x7c173890543f
    7c1738903726:	movdqa xmm14,xmm1
    7c173890372b:	psrldq xmm14,0x8
    7c1738903731:	movq   rax,xmm14
    7c1738903736:	add    rax,rax
    7c1738903739:	je     0x7c173890374f
    7c173890373b:	shr    rax,0x35
    7c173890373f:	sub    eax,0x201
    7c1738903744:	cmp    eax,0x3fc
    7c1738903749:	ja     0x7c173890543f
    7c173890374f:	mulpd  xmm0,xmm1
    7c1738903753:	movdqa xmm4,xmm0
    7c1738903757:	movdqa xmm0,xmm4
    7c173890375b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c1738903765:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c173890376f:	movdqa xmm2,xmm0
    7c1738903773:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c173890377d:	movdqa xmm4,xmm0
    7c1738903781:	movdqa xmm0,xmm2
    7c1738903785:	movdqa xmm1,xmm4
    7c1738903789:	movq   rax,xmm0
    7c173890378e:	add    rax,rax
    7c1738903791:	je     0x7c17389037a7
    7c1738903793:	shr    rax,0x35
    7c1738903797:	sub    eax,0x201
    7c173890379c:	cmp    eax,0x3fc
    7c17389037a1:	ja     0x7c1738905463
    7c17389037a7:	movdqa xmm14,xmm0
    7c17389037ac:	psrldq xmm14,0x8
    7c17389037b2:	movq   rax,xmm14
    7c17389037b7:	add    rax,rax
    7c17389037ba:	je     0x7c17389037d0
    7c17389037bc:	shr    rax,0x35
    7c17389037c0:	sub    eax,0x201
    7c17389037c5:	cmp    eax,0x3fc
    7c17389037ca:	ja     0x7c1738905463
    7c17389037d0:	movq   rax,xmm1
    7c17389037d5:	add    rax,rax
    7c17389037d8:	je     0x7c17389037ee
    7c17389037da:	shr    rax,0x35
    7c17389037de:	sub    eax,0x201
    7c17389037e3:	cmp    eax,0x3fc
    7c17389037e8:	ja     0x7c1738905463
    7c17389037ee:	movdqa xmm14,xmm1
    7c17389037f3:	psrldq xmm14,0x8
    7c17389037f9:	movq   rax,xmm14
    7c17389037fe:	add    rax,rax
    7c1738903801:	je     0x7c1738903817
    7c1738903803:	shr    rax,0x35
    7c1738903807:	sub    eax,0x201
    7c173890380c:	cmp    eax,0x3fc
    7c1738903811:	ja     0x7c1738905463
    7c1738903817:	addpd  xmm0,xmm1
    7c173890381b:	movdqa xmm5,xmm0
    7c173890381f:	movdqa xmm0,xmm5
    7c1738903823:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c173890382d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c1738903837:	movdqa xmm2,xmm0
    7c173890383b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c1738903845:	movdqa xmm4,xmm0
    7c1738903849:	movdqa xmm0,xmm2
    7c173890384d:	movdqa xmm1,xmm4
    7c1738903851:	movq   rax,xmm0
    7c1738903856:	add    rax,rax
    7c1738903859:	je     0x7c173890386f
    7c173890385b:	shr    rax,0x35
    7c173890385f:	sub    eax,0x201
    7c1738903864:	cmp    eax,0x3fc
    7c1738903869:	ja     0x7c1738905487
    7c173890386f:	movdqa xmm14,xmm0
    7c1738903874:	psrldq xmm14,0x8
    7c173890387a:	movq   rax,xmm14
    7c173890387f:	add    rax,rax
    7c1738903882:	je     0x7c1738903898
    7c1738903884:	shr    rax,0x35
    7c1738903888:	sub    eax,0x201
    7c173890388d:	cmp    eax,0x3fc
    7c1738903892:	ja     0x7c1738905487
    7c1738903898:	movq   rax,xmm1
    7c173890389d:	add    rax,rax
    7c17389038a0:	je     0x7c17389038b6
    7c17389038a2:	shr    rax,0x35
    7c17389038a6:	sub    eax,0x201
    7c17389038ab:	cmp    eax,0x3fc
    7c17389038b0:	ja     0x7c1738905487
    7c17389038b6:	movdqa xmm14,xmm1
    7c17389038bb:	psrldq xmm14,0x8
    7c17389038c1:	movq   rax,xmm14
    7c17389038c6:	add    rax,rax
    7c17389038c9:	je     0x7c17389038df
    7c17389038cb:	shr    rax,0x35
    7c17389038cf:	sub    eax,0x201
    7c17389038d4:	cmp    eax,0x3fc
    7c17389038d9:	ja     0x7c1738905487
    7c17389038df:	addpd  xmm0,xmm1
    7c17389038e3:	movdqa xmm5,xmm0
    7c17389038e7:	movdqa xmm0,xmm5
    7c17389038eb:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c17389038f5:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    7c17389038ff:	movdqa xmm2,xmm0
    7c1738903903:	movdqa xmm0,xmm2
    7c1738903907:	movdqa xmm1,xmm3
    7c173890390b:	pshufd xmm1,xmm1,0x44
    7c1738903910:	movq   rax,xmm0
    7c1738903915:	add    rax,rax
    7c1738903918:	je     0x7c173890392e
    7c173890391a:	shr    rax,0x35
    7c173890391e:	sub    eax,0x201
    7c1738903923:	cmp    eax,0x3fc
    7c1738903928:	ja     0x7c17389054ab
    7c173890392e:	movdqa xmm14,xmm0
    7c1738903933:	psrldq xmm14,0x8
    7c1738903939:	movq   rax,xmm14
    7c173890393e:	add    rax,rax
    7c1738903941:	je     0x7c1738903957
    7c1738903943:	shr    rax,0x35
    7c1738903947:	sub    eax,0x201
    7c173890394c:	cmp    eax,0x3fc
    7c1738903951:	ja     0x7c17389054ab
    7c1738903957:	movq   rax,xmm1
    7c173890395c:	add    rax,rax
    7c173890395f:	je     0x7c1738903975
    7c1738903961:	shr    rax,0x35
    7c1738903965:	sub    eax,0x201
    7c173890396a:	cmp    eax,0x3fc
    7c173890396f:	ja     0x7c17389054ab
    7c1738903975:	movdqa xmm14,xmm1
    7c173890397a:	psrldq xmm14,0x8
    7c1738903980:	movq   rax,xmm14
    7c1738903985:	add    rax,rax
    7c1738903988:	je     0x7c173890399e
    7c173890398a:	shr    rax,0x35
    7c173890398e:	sub    eax,0x201
    7c1738903993:	cmp    eax,0x3fc
    7c1738903998:	ja     0x7c17389054ab
    7c173890399e:	mulpd  xmm0,xmm1
    7c17389039a2:	movdqa xmm4,xmm0
    7c17389039a6:	movdqa xmm0,xmm4
    7c17389039aa:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c17389039b4:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    7c17389039be:	movdqa xmm2,xmm0
    7c17389039c2:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c17389039cc:	movdqa xmm3,xmm0
    7c17389039d0:	movdqa xmm0,xmm2
    7c17389039d4:	movdqa xmm1,xmm3
    7c17389039d8:	pshufd xmm1,xmm1,0x44
    7c17389039dd:	movq   rax,xmm0
    7c17389039e2:	add    rax,rax
    7c17389039e5:	je     0x7c17389039fb
    7c17389039e7:	shr    rax,0x35
    7c17389039eb:	sub    eax,0x201
    7c17389039f0:	cmp    eax,0x3fc
    7c17389039f5:	ja     0x7c17389054cf
    7c17389039fb:	movdqa xmm14,xmm0
    7c1738903a00:	psrldq xmm14,0x8
    7c1738903a06:	movq   rax,xmm14
    7c1738903a0b:	add    rax,rax
    7c1738903a0e:	je     0x7c1738903a24
    7c1738903a10:	shr    rax,0x35
    7c1738903a14:	sub    eax,0x201
    7c1738903a19:	cmp    eax,0x3fc
    7c1738903a1e:	ja     0x7c17389054cf
    7c1738903a24:	movq   rax,xmm1
    7c1738903a29:	add    rax,rax
    7c1738903a2c:	je     0x7c1738903a42
    7c1738903a2e:	shr    rax,0x35
    7c1738903a32:	sub    eax,0x201
    7c1738903a37:	cmp    eax,0x3fc
    7c1738903a3c:	ja     0x7c17389054cf
    7c1738903a42:	movdqa xmm14,xmm1
    7c1738903a47:	psrldq xmm14,0x8
    7c1738903a4d:	movq   rax,xmm14
    7c1738903a52:	add    rax,rax
    7c1738903a55:	je     0x7c1738903a6b
    7c1738903a57:	shr    rax,0x35
    7c1738903a5b:	sub    eax,0x201
    7c1738903a60:	cmp    eax,0x3fc
    7c1738903a65:	ja     0x7c17389054cf
    7c1738903a6b:	mulpd  xmm0,xmm1
    7c1738903a6f:	movdqa xmm4,xmm0
    7c1738903a73:	movdqa xmm0,xmm4
    7c1738903a77:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c1738903a81:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    7c1738903a8b:	movdqa xmm2,xmm0
    7c1738903a8f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c1738903a99:	movdqa xmm3,xmm0
    7c1738903a9d:	movdqa xmm0,xmm2
    7c1738903aa1:	movdqa xmm1,xmm3
    7c1738903aa5:	pshufd xmm1,xmm1,0x44
    7c1738903aaa:	movq   rax,xmm0
    7c1738903aaf:	add    rax,rax
    7c1738903ab2:	je     0x7c1738903ac8
    7c1738903ab4:	shr    rax,0x35
    7c1738903ab8:	sub    eax,0x201
    7c1738903abd:	cmp    eax,0x3fc
    7c1738903ac2:	ja     0x7c17389054f3
    7c1738903ac8:	movdqa xmm14,xmm0
    7c1738903acd:	psrldq xmm14,0x8
    7c1738903ad3:	movq   rax,xmm14
    7c1738903ad8:	add    rax,rax
    7c1738903adb:	je     0x7c1738903af1
    7c1738903add:	shr    rax,0x35
    7c1738903ae1:	sub    eax,0x201
    7c1738903ae6:	cmp    eax,0x3fc
    7c1738903aeb:	ja     0x7c17389054f3
    7c1738903af1:	movq   rax,xmm1
    7c1738903af6:	add    rax,rax
    7c1738903af9:	je     0x7c1738903b0f
    7c1738903afb:	shr    rax,0x35
    7c1738903aff:	sub    eax,0x201
    7c1738903b04:	cmp    eax,0x3fc
    7c1738903b09:	ja     0x7c17389054f3
    7c1738903b0f:	movdqa xmm14,xmm1
    7c1738903b14:	psrldq xmm14,0x8
    7c1738903b1a:	movq   rax,xmm14
    7c1738903b1f:	add    rax,rax
    7c1738903b22:	je     0x7c1738903b38
    7c1738903b24:	shr    rax,0x35
    7c1738903b28:	sub    eax,0x201
    7c1738903b2d:	cmp    eax,0x3fc
    7c1738903b32:	ja     0x7c17389054f3
    7c1738903b38:	mulpd  xmm0,xmm1
    7c1738903b3c:	movdqa xmm4,xmm0
    7c1738903b40:	movdqa xmm0,xmm4
    7c1738903b44:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c1738903b4e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c1738903b58:	movdqa xmm2,xmm0
    7c1738903b5c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c1738903b66:	movdqa xmm4,xmm0
    7c1738903b6a:	movdqa xmm0,xmm2
    7c1738903b6e:	movdqa xmm1,xmm4
    7c1738903b72:	movq   rax,xmm0
    7c1738903b77:	add    rax,rax
    7c1738903b7a:	je     0x7c1738903b90
    7c1738903b7c:	shr    rax,0x35
    7c1738903b80:	sub    eax,0x201
    7c1738903b85:	cmp    eax,0x3fc
    7c1738903b8a:	ja     0x7c1738905517
    7c1738903b90:	movdqa xmm14,xmm0
    7c1738903b95:	psrldq xmm14,0x8
    7c1738903b9b:	movq   rax,xmm14
    7c1738903ba0:	add    rax,rax
    7c1738903ba3:	je     0x7c1738903bb9
    7c1738903ba5:	shr    rax,0x35
    7c1738903ba9:	sub    eax,0x201
    7c1738903bae:	cmp    eax,0x3fc
    7c1738903bb3:	ja     0x7c1738905517
    7c1738903bb9:	movq   rax,xmm1
    7c1738903bbe:	add    rax,rax
    7c1738903bc1:	je     0x7c1738903bd7
    7c1738903bc3:	shr    rax,0x35
    7c1738903bc7:	sub    eax,0x201
    7c1738903bcc:	cmp    eax,0x3fc
    7c1738903bd1:	ja     0x7c1738905517
    7c1738903bd7:	movdqa xmm14,xmm1
    7c1738903bdc:	psrldq xmm14,0x8
    7c1738903be2:	movq   rax,xmm14
    7c1738903be7:	add    rax,rax
    7c1738903bea:	je     0x7c1738903c00
    7c1738903bec:	shr    rax,0x35
    7c1738903bf0:	sub    eax,0x201
    7c1738903bf5:	cmp    eax,0x3fc
    7c1738903bfa:	ja     0x7c1738905517
    7c1738903c00:	addpd  xmm0,xmm1
    7c1738903c04:	movdqa xmm5,xmm0
    7c1738903c08:	movdqa xmm0,xmm5
    7c1738903c0c:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c1738903c16:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c1738903c20:	movdqa xmm2,xmm0
    7c1738903c24:	movdqa xmm0,xmm2
    7c1738903c28:	movdqa xmm1,xmm3
    7c1738903c2c:	pshufd xmm1,xmm1,0x44
    7c1738903c31:	movq   rax,xmm0
    7c1738903c36:	add    rax,rax
    7c1738903c39:	je     0x7c1738903c4f
    7c1738903c3b:	shr    rax,0x35
    7c1738903c3f:	sub    eax,0x201
    7c1738903c44:	cmp    eax,0x3fc
    7c1738903c49:	ja     0x7c173890553b
    7c1738903c4f:	movdqa xmm14,xmm0
    7c1738903c54:	psrldq xmm14,0x8
    7c1738903c5a:	movq   rax,xmm14
    7c1738903c5f:	add    rax,rax
    7c1738903c62:	je     0x7c1738903c78
    7c1738903c64:	shr    rax,0x35
    7c1738903c68:	sub    eax,0x201
    7c1738903c6d:	cmp    eax,0x3fc
    7c1738903c72:	ja     0x7c173890553b
    7c1738903c78:	movq   rax,xmm1
    7c1738903c7d:	add    rax,rax
    7c1738903c80:	je     0x7c1738903c96
    7c1738903c82:	shr    rax,0x35
    7c1738903c86:	sub    eax,0x201
    7c1738903c8b:	cmp    eax,0x3fc
    7c1738903c90:	ja     0x7c173890553b
    7c1738903c96:	movdqa xmm14,xmm1
    7c1738903c9b:	psrldq xmm14,0x8
    7c1738903ca1:	movq   rax,xmm14
    7c1738903ca6:	add    rax,rax
    7c1738903ca9:	je     0x7c1738903cbf
    7c1738903cab:	shr    rax,0x35
    7c1738903caf:	sub    eax,0x201
    7c1738903cb4:	cmp    eax,0x3fc
    7c1738903cb9:	ja     0x7c173890553b
    7c1738903cbf:	mulpd  xmm0,xmm1
    7c1738903cc3:	movdqa xmm4,xmm0
    7c1738903cc7:	movdqa xmm0,xmm4
    7c1738903ccb:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c1738903cd5:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c1738903cdf:	movdqa xmm2,xmm0
    7c1738903ce3:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c1738903ced:	movdqa xmm4,xmm0
    7c1738903cf1:	movdqa xmm0,xmm2
    7c1738903cf5:	movdqa xmm1,xmm4
    7c1738903cf9:	movq   rax,xmm0
    7c1738903cfe:	add    rax,rax
    7c1738903d01:	je     0x7c1738903d17
    7c1738903d03:	shr    rax,0x35
    7c1738903d07:	sub    eax,0x201
    7c1738903d0c:	cmp    eax,0x3fc
    7c1738903d11:	ja     0x7c173890555f
    7c1738903d17:	movdqa xmm14,xmm0
    7c1738903d1c:	psrldq xmm14,0x8
    7c1738903d22:	movq   rax,xmm14
    7c1738903d27:	add    rax,rax
    7c1738903d2a:	je     0x7c1738903d40
    7c1738903d2c:	shr    rax,0x35
    7c1738903d30:	sub    eax,0x201
    7c1738903d35:	cmp    eax,0x3fc
    7c1738903d3a:	ja     0x7c173890555f
    7c1738903d40:	movq   rax,xmm1
    7c1738903d45:	add    rax,rax
    7c1738903d48:	je     0x7c1738903d5e
    7c1738903d4a:	shr    rax,0x35
    7c1738903d4e:	sub    eax,0x201
    7c1738903d53:	cmp    eax,0x3fc
    7c1738903d58:	ja     0x7c173890555f
    7c1738903d5e:	movdqa xmm14,xmm1
    7c1738903d63:	psrldq xmm14,0x8
    7c1738903d69:	movq   rax,xmm14
    7c1738903d6e:	add    rax,rax
    7c1738903d71:	je     0x7c1738903d87
    7c1738903d73:	shr    rax,0x35
    7c1738903d77:	sub    eax,0x201
    7c1738903d7c:	cmp    eax,0x3fc
    7c1738903d81:	ja     0x7c173890555f
    7c1738903d87:	addpd  xmm0,xmm1
    7c1738903d8b:	movdqa xmm5,xmm0
    7c1738903d8f:	movdqa xmm0,xmm5
    7c1738903d93:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c1738903d9d:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    7c1738903da7:	movdqa xmm2,xmm0
    7c1738903dab:	movdqa xmm0,xmm2
    7c1738903daf:	movdqa xmm1,xmm3
    7c1738903db3:	pshufd xmm1,xmm1,0x44
    7c1738903db8:	movq   rax,xmm0
    7c1738903dbd:	add    rax,rax
    7c1738903dc0:	je     0x7c1738903dd6
    7c1738903dc2:	shr    rax,0x35
    7c1738903dc6:	sub    eax,0x201
    7c1738903dcb:	cmp    eax,0x3fc
    7c1738903dd0:	ja     0x7c1738905583
    7c1738903dd6:	movdqa xmm14,xmm0
    7c1738903ddb:	psrldq xmm14,0x8
    7c1738903de1:	movq   rax,xmm14
    7c1738903de6:	add    rax,rax
    7c1738903de9:	je     0x7c1738903dff
    7c1738903deb:	shr    rax,0x35
    7c1738903def:	sub    eax,0x201
    7c1738903df4:	cmp    eax,0x3fc
    7c1738903df9:	ja     0x7c1738905583
    7c1738903dff:	movq   rax,xmm1
    7c1738903e04:	add    rax,rax
    7c1738903e07:	je     0x7c1738903e1d
    7c1738903e09:	shr    rax,0x35
    7c1738903e0d:	sub    eax,0x201
    7c1738903e12:	cmp    eax,0x3fc
    7c1738903e17:	ja     0x7c1738905583
    7c1738903e1d:	movdqa xmm14,xmm1
    7c1738903e22:	psrldq xmm14,0x8
    7c1738903e28:	movq   rax,xmm14
    7c1738903e2d:	add    rax,rax
    7c1738903e30:	je     0x7c1738903e46
    7c1738903e32:	shr    rax,0x35
    7c1738903e36:	sub    eax,0x201
    7c1738903e3b:	cmp    eax,0x3fc
    7c1738903e40:	ja     0x7c1738905583
    7c1738903e46:	mulpd  xmm0,xmm1
    7c1738903e4a:	movdqa xmm4,xmm0
    7c1738903e4e:	movdqa xmm0,xmm4
    7c1738903e52:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c1738903e5c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c1738903e66:	movdqa xmm2,xmm0
    7c1738903e6a:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c1738903e74:	movdqa xmm3,xmm0
    7c1738903e78:	movdqa xmm0,xmm2
    7c1738903e7c:	movdqa xmm1,xmm3
    7c1738903e80:	movq   rax,xmm0
    7c1738903e85:	add    rax,rax
    7c1738903e88:	je     0x7c1738903e9e
    7c1738903e8a:	shr    rax,0x35
    7c1738903e8e:	sub    eax,0x201
    7c1738903e93:	cmp    eax,0x3fc
    7c1738903e98:	ja     0x7c17389055a7
    7c1738903e9e:	movdqa xmm14,xmm0
    7c1738903ea3:	psrldq xmm14,0x8
    7c1738903ea9:	movq   rax,xmm14
    7c1738903eae:	add    rax,rax
    7c1738903eb1:	je     0x7c1738903ec7
    7c1738903eb3:	shr    rax,0x35
    7c1738903eb7:	sub    eax,0x201
    7c1738903ebc:	cmp    eax,0x3fc
    7c1738903ec1:	ja     0x7c17389055a7
    7c1738903ec7:	movq   rax,xmm1
    7c1738903ecc:	add    rax,rax
    7c1738903ecf:	je     0x7c1738903ee5
    7c1738903ed1:	shr    rax,0x35
    7c1738903ed5:	sub    eax,0x201
    7c1738903eda:	cmp    eax,0x3fc
    7c1738903edf:	ja     0x7c17389055a7
    7c1738903ee5:	movdqa xmm14,xmm1
    7c1738903eea:	psrldq xmm14,0x8
    7c1738903ef0:	movq   rax,xmm14
    7c1738903ef5:	add    rax,rax
    7c1738903ef8:	je     0x7c1738903f0e
    7c1738903efa:	shr    rax,0x35
    7c1738903efe:	sub    eax,0x201
    7c1738903f03:	cmp    eax,0x3fc
    7c1738903f08:	ja     0x7c17389055a7
    7c1738903f0e:	addpd  xmm0,xmm1
    7c1738903f12:	movdqa xmm4,xmm0
    7c1738903f16:	movdqa xmm0,xmm4
    7c1738903f1a:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c1738903f24:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    7c1738903f2e:	movdqa xmm2,xmm0
    7c1738903f32:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c1738903f3c:	movdqa xmm3,xmm0
    7c1738903f40:	movdqa xmm0,xmm2
    7c1738903f44:	movdqa xmm1,xmm3
    7c1738903f48:	pshufd xmm1,xmm1,0x44
    7c1738903f4d:	movq   rax,xmm0
    7c1738903f52:	add    rax,rax
    7c1738903f55:	je     0x7c1738903f6b
    7c1738903f57:	shr    rax,0x35
    7c1738903f5b:	sub    eax,0x201
    7c1738903f60:	cmp    eax,0x3fc
    7c1738903f65:	ja     0x7c17389055cb
    7c1738903f6b:	movdqa xmm14,xmm0
    7c1738903f70:	psrldq xmm14,0x8
    7c1738903f76:	movq   rax,xmm14
    7c1738903f7b:	add    rax,rax
    7c1738903f7e:	je     0x7c1738903f94
    7c1738903f80:	shr    rax,0x35
    7c1738903f84:	sub    eax,0x201
    7c1738903f89:	cmp    eax,0x3fc
    7c1738903f8e:	ja     0x7c17389055cb
    7c1738903f94:	movq   rax,xmm1
    7c1738903f99:	add    rax,rax
    7c1738903f9c:	je     0x7c1738903fb2
    7c1738903f9e:	shr    rax,0x35
    7c1738903fa2:	sub    eax,0x201
    7c1738903fa7:	cmp    eax,0x3fc
    7c1738903fac:	ja     0x7c17389055cb
    7c1738903fb2:	movdqa xmm14,xmm1
    7c1738903fb7:	psrldq xmm14,0x8
    7c1738903fbd:	movq   rax,xmm14
    7c1738903fc2:	add    rax,rax
    7c1738903fc5:	je     0x7c1738903fdb
    7c1738903fc7:	shr    rax,0x35
    7c1738903fcb:	sub    eax,0x201
    7c1738903fd0:	cmp    eax,0x3fc
    7c1738903fd5:	ja     0x7c17389055cb
    7c1738903fdb:	mulpd  xmm0,xmm1
    7c1738903fdf:	movdqa xmm4,xmm0
    7c1738903fe3:	movdqa xmm0,xmm4
    7c1738903fe7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c1738903ff1:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c1738903ffb:	movdqa xmm2,xmm0
    7c1738903fff:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c1738904009:	movdqa xmm3,xmm0
    7c173890400d:	movdqa xmm0,xmm2
    7c1738904011:	movdqa xmm1,xmm3
    7c1738904015:	movq   rax,xmm0
    7c173890401a:	add    rax,rax
    7c173890401d:	je     0x7c1738904033
    7c173890401f:	shr    rax,0x35
    7c1738904023:	sub    eax,0x201
    7c1738904028:	cmp    eax,0x3fc
    7c173890402d:	ja     0x7c17389055ef
    7c1738904033:	movdqa xmm14,xmm0
    7c1738904038:	psrldq xmm14,0x8
    7c173890403e:	movq   rax,xmm14
    7c1738904043:	add    rax,rax
    7c1738904046:	je     0x7c173890405c
    7c1738904048:	shr    rax,0x35
    7c173890404c:	sub    eax,0x201
    7c1738904051:	cmp    eax,0x3fc
    7c1738904056:	ja     0x7c17389055ef
    7c173890405c:	movq   rax,xmm1
    7c1738904061:	add    rax,rax
    7c1738904064:	je     0x7c173890407a
    7c1738904066:	shr    rax,0x35
    7c173890406a:	sub    eax,0x201
    7c173890406f:	cmp    eax,0x3fc
    7c1738904074:	ja     0x7c17389055ef
    7c173890407a:	movdqa xmm14,xmm1
    7c173890407f:	psrldq xmm14,0x8
    7c1738904085:	movq   rax,xmm14
    7c173890408a:	add    rax,rax
    7c173890408d:	je     0x7c17389040a3
    7c173890408f:	shr    rax,0x35
    7c1738904093:	sub    eax,0x201
    7c1738904098:	cmp    eax,0x3fc
    7c173890409d:	ja     0x7c17389055ef
    7c17389040a3:	addpd  xmm0,xmm1
    7c17389040a7:	movdqa xmm4,xmm0
    7c17389040ab:	movdqa xmm0,xmm4
    7c17389040af:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c17389040b9:	mov    r13,QWORD PTR [r12+0xf8]
    7c17389040c1:	mov    r14,r13
    7c17389040c4:	add    r14,0x70
    7c17389040c8:	stmxcsr DWORD PTR [rsp+0x114]
    7c17389040d0:	ldmxcsr DWORD PTR [rsp+0x110]
    7c17389040d8:	mov    r11d,DWORD PTR [rsp+0x114]
    7c17389040e0:	shr    r11d,1
    7c17389040e3:	and    r11d,0x10
    7c17389040e7:	or     DWORD PTR [r12+0x314],r11d
    7c17389040ef:	movdqu xmm2,XMMWORD PTR [r14]
    7c17389040f4:	movdqa xmm0,xmm2
    7c17389040f8:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c1738904102:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c173890410c:	movdqa xmm3,xmm0
    7c1738904110:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c173890411a:	movdqa xmm4,xmm0
    7c173890411e:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738904126:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c1738904131:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738904139:	movdqa xmm0,xmm3
    7c173890413d:	movdqa xmm1,xmm4
    7c1738904141:	movq   rax,xmm0
    7c1738904146:	add    rax,rax
    7c1738904149:	je     0x7c173890415f
    7c173890414b:	shr    rax,0x35
    7c173890414f:	sub    eax,0x201
    7c1738904154:	cmp    eax,0x3fc
    7c1738904159:	ja     0x7c1738905613
    7c173890415f:	movdqa xmm14,xmm0
    7c1738904164:	psrldq xmm14,0x8
    7c173890416a:	movq   rax,xmm14
    7c173890416f:	add    rax,rax
    7c1738904172:	je     0x7c1738904188
    7c1738904174:	shr    rax,0x35
    7c1738904178:	sub    eax,0x201
    7c173890417d:	cmp    eax,0x3fc
    7c1738904182:	ja     0x7c1738905613
    7c1738904188:	movq   rax,xmm1
    7c173890418d:	add    rax,rax
    7c1738904190:	je     0x7c17389041a6
    7c1738904192:	shr    rax,0x35
    7c1738904196:	sub    eax,0x201
    7c173890419b:	cmp    eax,0x3fc
    7c17389041a0:	ja     0x7c1738905613
    7c17389041a6:	movdqa xmm14,xmm1
    7c17389041ab:	psrldq xmm14,0x8
    7c17389041b1:	movq   rax,xmm14
    7c17389041b6:	add    rax,rax
    7c17389041b9:	je     0x7c17389041cf
    7c17389041bb:	shr    rax,0x35
    7c17389041bf:	sub    eax,0x201
    7c17389041c4:	cmp    eax,0x3fc
    7c17389041c9:	ja     0x7c1738905613
    7c17389041cf:	addpd  xmm0,xmm1
    7c17389041d3:	movdqa xmm5,xmm0
    7c17389041d7:	movdqa xmm0,xmm5
    7c17389041db:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7c17389041e5:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7c17389041ef:	movdqa xmm3,xmm0
    7c17389041f3:	movdqa xmm0,xmm2
    7c17389041f7:	movdqa xmm1,xmm3
    7c17389041fb:	pshufd xmm1,xmm1,0x44
    7c1738904200:	movq   rax,xmm0
    7c1738904205:	add    rax,rax
    7c1738904208:	je     0x7c173890421e
    7c173890420a:	shr    rax,0x35
    7c173890420e:	sub    eax,0x201
    7c1738904213:	cmp    eax,0x3fc
    7c1738904218:	ja     0x7c1738905637
    7c173890421e:	movdqa xmm14,xmm0
    7c1738904223:	psrldq xmm14,0x8
    7c1738904229:	movq   rax,xmm14
    7c173890422e:	add    rax,rax
    7c1738904231:	je     0x7c1738904247
    7c1738904233:	shr    rax,0x35
    7c1738904237:	sub    eax,0x201
    7c173890423c:	cmp    eax,0x3fc
    7c1738904241:	ja     0x7c1738905637
    7c1738904247:	movq   rax,xmm1
    7c173890424c:	add    rax,rax
    7c173890424f:	je     0x7c1738904265
    7c1738904251:	shr    rax,0x35
    7c1738904255:	sub    eax,0x201
    7c173890425a:	cmp    eax,0x3fc
    7c173890425f:	ja     0x7c1738905637
    7c1738904265:	movdqa xmm14,xmm1
    7c173890426a:	psrldq xmm14,0x8
    7c1738904270:	movq   rax,xmm14
    7c1738904275:	add    rax,rax
    7c1738904278:	je     0x7c173890428e
    7c173890427a:	shr    rax,0x35
    7c173890427e:	sub    eax,0x201
    7c1738904283:	cmp    eax,0x3fc
    7c1738904288:	ja     0x7c1738905637
    7c173890428e:	mulpd  xmm0,xmm1
    7c1738904292:	movdqa xmm4,xmm0
    7c1738904296:	movdqa xmm0,xmm4
    7c173890429a:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c17389042a4:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7c17389042ae:	movdqa xmm2,xmm0
    7c17389042b2:	movdqa xmm0,xmm2
    7c17389042b6:	movdqa xmm1,xmm3
    7c17389042ba:	pshufd xmm1,xmm1,0x44
    7c17389042bf:	movq   rax,xmm0
    7c17389042c4:	add    rax,rax
    7c17389042c7:	je     0x7c17389042dd
    7c17389042c9:	shr    rax,0x35
    7c17389042cd:	sub    eax,0x201
    7c17389042d2:	cmp    eax,0x3fc
    7c17389042d7:	ja     0x7c173890565b
    7c17389042dd:	movdqa xmm14,xmm0
    7c17389042e2:	psrldq xmm14,0x8
    7c17389042e8:	movq   rax,xmm14
    7c17389042ed:	add    rax,rax
    7c17389042f0:	je     0x7c1738904306
    7c17389042f2:	shr    rax,0x35
    7c17389042f6:	sub    eax,0x201
    7c17389042fb:	cmp    eax,0x3fc
    7c1738904300:	ja     0x7c173890565b
    7c1738904306:	movq   rax,xmm1
    7c173890430b:	add    rax,rax
    7c173890430e:	je     0x7c1738904324
    7c1738904310:	shr    rax,0x35
    7c1738904314:	sub    eax,0x201
    7c1738904319:	cmp    eax,0x3fc
    7c173890431e:	ja     0x7c173890565b
    7c1738904324:	movdqa xmm14,xmm1
    7c1738904329:	psrldq xmm14,0x8
    7c173890432f:	movq   rax,xmm14
    7c1738904334:	add    rax,rax
    7c1738904337:	je     0x7c173890434d
    7c1738904339:	shr    rax,0x35
    7c173890433d:	sub    eax,0x201
    7c1738904342:	cmp    eax,0x3fc
    7c1738904347:	ja     0x7c173890565b
    7c173890434d:	mulpd  xmm0,xmm1
    7c1738904351:	movdqa xmm4,xmm0
    7c1738904355:	movdqa xmm0,xmm4
    7c1738904359:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c1738904363:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c173890436d:	movdqa xmm2,xmm0
    7c1738904371:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    7c173890437b:	movdqa xmm4,xmm0
    7c173890437f:	movdqa xmm0,xmm2
    7c1738904383:	movdqa xmm1,xmm4
    7c1738904387:	movq   rax,xmm0
    7c173890438c:	add    rax,rax
    7c173890438f:	je     0x7c17389043a5
    7c1738904391:	shr    rax,0x35
    7c1738904395:	sub    eax,0x201
    7c173890439a:	cmp    eax,0x3fc
    7c173890439f:	ja     0x7c173890567f
    7c17389043a5:	movdqa xmm14,xmm0
    7c17389043aa:	psrldq xmm14,0x8
    7c17389043b0:	movq   rax,xmm14
    7c17389043b5:	add    rax,rax
    7c17389043b8:	je     0x7c17389043ce
    7c17389043ba:	shr    rax,0x35
    7c17389043be:	sub    eax,0x201
    7c17389043c3:	cmp    eax,0x3fc
    7c17389043c8:	ja     0x7c173890567f
    7c17389043ce:	movq   rax,xmm1
    7c17389043d3:	add    rax,rax
    7c17389043d6:	je     0x7c17389043ec
    7c17389043d8:	shr    rax,0x35
    7c17389043dc:	sub    eax,0x201
    7c17389043e1:	cmp    eax,0x3fc
    7c17389043e6:	ja     0x7c173890567f
    7c17389043ec:	movdqa xmm14,xmm1
    7c17389043f1:	psrldq xmm14,0x8
    7c17389043f7:	movq   rax,xmm14
    7c17389043fc:	add    rax,rax
    7c17389043ff:	je     0x7c1738904415
    7c1738904401:	shr    rax,0x35
    7c1738904405:	sub    eax,0x201
    7c173890440a:	cmp    eax,0x3fc
    7c173890440f:	ja     0x7c173890567f
    7c1738904415:	addpd  xmm0,xmm1
    7c1738904419:	movdqa xmm5,xmm0
    7c173890441d:	movdqa xmm0,xmm5
    7c1738904421:	movdqu XMMWORD PTR [r12+0x210],xmm0
    7c173890442b:	mov    r14,r13
    7c173890442e:	add    r14,0x10
    7c1738904432:	stmxcsr DWORD PTR [rsp+0x114]
    7c173890443a:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738904442:	mov    r11d,DWORD PTR [rsp+0x114]
    7c173890444a:	shr    r11d,1
    7c173890444d:	and    r11d,0x10
    7c1738904451:	or     DWORD PTR [r12+0x314],r11d
    7c1738904459:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c173890445f:	movdqu xmm4,XMMWORD PTR [r14]
    7c1738904464:	movdqa xmm0,xmm4
    7c1738904468:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7c1738904472:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c173890447c:	movdqa xmm5,xmm0
    7c1738904480:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c173890448a:	movdqa xmm6,xmm0
    7c173890448e:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738904496:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c17389044a1:	ldmxcsr DWORD PTR [rsp+0x114]
    7c17389044a9:	movdqa xmm0,xmm5
    7c17389044ad:	movdqa xmm1,xmm6
    7c17389044b1:	movq   rax,xmm0
    7c17389044b6:	add    rax,rax
    7c17389044b9:	je     0x7c17389044cf
    7c17389044bb:	shr    rax,0x35
    7c17389044bf:	sub    eax,0x201
    7c17389044c4:	cmp    eax,0x3fc
    7c17389044c9:	ja     0x7c17389056a3
    7c17389044cf:	movdqa xmm14,xmm0
    7c17389044d4:	psrldq xmm14,0x8
    7c17389044da:	movq   rax,xmm14
    7c17389044df:	add    rax,rax
    7c17389044e2:	je     0x7c17389044f8
    7c17389044e4:	shr    rax,0x35
    7c17389044e8:	sub    eax,0x201
    7c17389044ed:	cmp    eax,0x3fc
    7c17389044f2:	ja     0x7c17389056a3
    7c17389044f8:	movq   rax,xmm1
    7c17389044fd:	add    rax,rax
    7c1738904500:	je     0x7c1738904516
    7c1738904502:	shr    rax,0x35
    7c1738904506:	sub    eax,0x201
    7c173890450b:	cmp    eax,0x3fc
    7c1738904510:	ja     0x7c17389056a3
    7c1738904516:	movdqa xmm14,xmm1
    7c173890451b:	psrldq xmm14,0x8
    7c1738904521:	movq   rax,xmm14
    7c1738904526:	add    rax,rax
    7c1738904529:	je     0x7c173890453f
    7c173890452b:	shr    rax,0x35
    7c173890452f:	sub    eax,0x201
    7c1738904534:	cmp    eax,0x3fc
    7c1738904539:	ja     0x7c17389056a3
    7c173890453f:	addpd  xmm0,xmm1
    7c1738904543:	movdqa xmm7,xmm0
    7c1738904547:	movdqa xmm0,xmm7
    7c173890454b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    7c1738904555:	movdqa xmm0,xmm4
    7c1738904559:	movdqa xmm1,xmm3
    7c173890455d:	pshufd xmm1,xmm1,0x44
    7c1738904562:	movq   rax,xmm0
    7c1738904567:	add    rax,rax
    7c173890456a:	je     0x7c1738904580
    7c173890456c:	shr    rax,0x35
    7c1738904570:	sub    eax,0x201
    7c1738904575:	cmp    eax,0x3fc
    7c173890457a:	ja     0x7c17389056c7
    7c1738904580:	movdqa xmm14,xmm0
    7c1738904585:	psrldq xmm14,0x8
    7c173890458b:	movq   rax,xmm14
    7c1738904590:	add    rax,rax
    7c1738904593:	je     0x7c17389045a9
    7c1738904595:	shr    rax,0x35
    7c1738904599:	sub    eax,0x201
    7c173890459e:	cmp    eax,0x3fc
    7c17389045a3:	ja     0x7c17389056c7
    7c17389045a9:	movq   rax,xmm1
    7c17389045ae:	add    rax,rax
    7c17389045b1:	je     0x7c17389045c7
    7c17389045b3:	shr    rax,0x35
    7c17389045b7:	sub    eax,0x201
    7c17389045bc:	cmp    eax,0x3fc
    7c17389045c1:	ja     0x7c17389056c7
    7c17389045c7:	movdqa xmm14,xmm1
    7c17389045cc:	psrldq xmm14,0x8
    7c17389045d2:	movq   rax,xmm14
    7c17389045d7:	add    rax,rax
    7c17389045da:	je     0x7c17389045f0
    7c17389045dc:	shr    rax,0x35
    7c17389045e0:	sub    eax,0x201
    7c17389045e5:	cmp    eax,0x3fc
    7c17389045ea:	ja     0x7c17389056c7
    7c17389045f0:	mulpd  xmm0,xmm1
    7c17389045f4:	movdqa xmm5,xmm0
    7c17389045f8:	movdqa xmm0,xmm5
    7c17389045fc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7c1738904606:	movdqa xmm0,xmm2
    7c173890460a:	movdqa xmm1,xmm3
    7c173890460e:	pshufd xmm1,xmm1,0x44
    7c1738904613:	movq   rax,xmm0
    7c1738904618:	add    rax,rax
    7c173890461b:	je     0x7c1738904631
    7c173890461d:	shr    rax,0x35
    7c1738904621:	sub    eax,0x201
    7c1738904626:	cmp    eax,0x3fc
    7c173890462b:	ja     0x7c17389056eb
    7c1738904631:	movdqa xmm14,xmm0
    7c1738904636:	psrldq xmm14,0x8
    7c173890463c:	movq   rax,xmm14
    7c1738904641:	add    rax,rax
    7c1738904644:	je     0x7c173890465a
    7c1738904646:	shr    rax,0x35
    7c173890464a:	sub    eax,0x201
    7c173890464f:	cmp    eax,0x3fc
    7c1738904654:	ja     0x7c17389056eb
    7c173890465a:	movq   rax,xmm1
    7c173890465f:	add    rax,rax
    7c1738904662:	je     0x7c1738904678
    7c1738904664:	shr    rax,0x35
    7c1738904668:	sub    eax,0x201
    7c173890466d:	cmp    eax,0x3fc
    7c1738904672:	ja     0x7c17389056eb
    7c1738904678:	movdqa xmm14,xmm1
    7c173890467d:	psrldq xmm14,0x8
    7c1738904683:	movq   rax,xmm14
    7c1738904688:	add    rax,rax
    7c173890468b:	je     0x7c17389046a1
    7c173890468d:	shr    rax,0x35
    7c1738904691:	sub    eax,0x201
    7c1738904696:	cmp    eax,0x3fc
    7c173890469b:	ja     0x7c17389056eb
    7c17389046a1:	mulpd  xmm0,xmm1
    7c17389046a5:	movdqa xmm4,xmm0
    7c17389046a9:	movdqa xmm0,xmm4
    7c17389046ad:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c17389046b7:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c17389046c1:	movdqa xmm2,xmm0
    7c17389046c5:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c17389046cf:	movdqa xmm3,xmm0
    7c17389046d3:	movdqa xmm0,xmm2
    7c17389046d7:	movdqa xmm1,xmm3
    7c17389046db:	movq   rax,xmm0
    7c17389046e0:	add    rax,rax
    7c17389046e3:	je     0x7c17389046f9
    7c17389046e5:	shr    rax,0x35
    7c17389046e9:	sub    eax,0x201
    7c17389046ee:	cmp    eax,0x3fc
    7c17389046f3:	ja     0x7c173890570f
    7c17389046f9:	movdqa xmm14,xmm0
    7c17389046fe:	psrldq xmm14,0x8
    7c1738904704:	movq   rax,xmm14
    7c1738904709:	add    rax,rax
    7c173890470c:	je     0x7c1738904722
    7c173890470e:	shr    rax,0x35
    7c1738904712:	sub    eax,0x201
    7c1738904717:	cmp    eax,0x3fc
    7c173890471c:	ja     0x7c173890570f
    7c1738904722:	movq   rax,xmm1
    7c1738904727:	add    rax,rax
    7c173890472a:	je     0x7c1738904740
    7c173890472c:	shr    rax,0x35
    7c1738904730:	sub    eax,0x201
    7c1738904735:	cmp    eax,0x3fc
    7c173890473a:	ja     0x7c173890570f
    7c1738904740:	movdqa xmm14,xmm1
    7c1738904745:	psrldq xmm14,0x8
    7c173890474b:	movq   rax,xmm14
    7c1738904750:	add    rax,rax
    7c1738904753:	je     0x7c1738904769
    7c1738904755:	shr    rax,0x35
    7c1738904759:	sub    eax,0x201
    7c173890475e:	cmp    eax,0x3fc
    7c1738904763:	ja     0x7c173890570f
    7c1738904769:	addpd  xmm0,xmm1
    7c173890476d:	movdqa xmm4,xmm0
    7c1738904771:	movdqa xmm0,xmm4
    7c1738904775:	movdqu XMMWORD PTR [r12+0x140],xmm0
    7c173890477f:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    7c1738904789:	movdqa xmm2,xmm0
    7c173890478d:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c1738904797:	movdqa xmm3,xmm0
    7c173890479b:	movdqa xmm0,xmm2
    7c173890479f:	movdqa xmm1,xmm3
    7c17389047a3:	movq   rax,xmm0
    7c17389047a8:	add    rax,rax
    7c17389047ab:	je     0x7c17389047c1
    7c17389047ad:	shr    rax,0x35
    7c17389047b1:	sub    eax,0x201
    7c17389047b6:	cmp    eax,0x3fc
    7c17389047bb:	ja     0x7c1738905733
    7c17389047c1:	movdqa xmm14,xmm0
    7c17389047c6:	psrldq xmm14,0x8
    7c17389047cc:	movq   rax,xmm14
    7c17389047d1:	add    rax,rax
    7c17389047d4:	je     0x7c17389047ea
    7c17389047d6:	shr    rax,0x35
    7c17389047da:	sub    eax,0x201
    7c17389047df:	cmp    eax,0x3fc
    7c17389047e4:	ja     0x7c1738905733
    7c17389047ea:	movq   rax,xmm1
    7c17389047ef:	add    rax,rax
    7c17389047f2:	je     0x7c1738904808
    7c17389047f4:	shr    rax,0x35
    7c17389047f8:	sub    eax,0x201
    7c17389047fd:	cmp    eax,0x3fc
    7c1738904802:	ja     0x7c1738905733
    7c1738904808:	movdqa xmm14,xmm1
    7c173890480d:	psrldq xmm14,0x8
    7c1738904813:	movq   rax,xmm14
    7c1738904818:	add    rax,rax
    7c173890481b:	je     0x7c1738904831
    7c173890481d:	shr    rax,0x35
    7c1738904821:	sub    eax,0x201
    7c1738904826:	cmp    eax,0x3fc
    7c173890482b:	ja     0x7c1738905733
    7c1738904831:	addpd  xmm0,xmm1
    7c1738904835:	movdqa xmm4,xmm0
    7c1738904839:	movdqa xmm0,xmm4
    7c173890483d:	movdqu XMMWORD PTR [r12+0x150],xmm0
    7c1738904847:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7c1738904851:	movdqa xmm2,xmm0
    7c1738904855:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    7c173890485f:	movdqa xmm3,xmm0
    7c1738904863:	movdqa xmm0,xmm2
    7c1738904867:	movdqa xmm1,xmm3
    7c173890486b:	movq   rax,xmm0
    7c1738904870:	add    rax,rax
    7c1738904873:	je     0x7c1738904889
    7c1738904875:	shr    rax,0x35
    7c1738904879:	sub    eax,0x201
    7c173890487e:	cmp    eax,0x3fc
    7c1738904883:	ja     0x7c1738905757
    7c1738904889:	movdqa xmm14,xmm0
    7c173890488e:	psrldq xmm14,0x8
    7c1738904894:	movq   rax,xmm14
    7c1738904899:	add    rax,rax
    7c173890489c:	je     0x7c17389048b2
    7c173890489e:	shr    rax,0x35
    7c17389048a2:	sub    eax,0x201
    7c17389048a7:	cmp    eax,0x3fc
    7c17389048ac:	ja     0x7c1738905757
    7c17389048b2:	movq   rax,xmm1
    7c17389048b7:	add    rax,rax
    7c17389048ba:	je     0x7c17389048d0
    7c17389048bc:	shr    rax,0x35
    7c17389048c0:	sub    eax,0x201
    7c17389048c5:	cmp    eax,0x3fc
    7c17389048ca:	ja     0x7c1738905757
    7c17389048d0:	movdqa xmm14,xmm1
    7c17389048d5:	psrldq xmm14,0x8
    7c17389048db:	movq   rax,xmm14
    7c17389048e0:	add    rax,rax
    7c17389048e3:	je     0x7c17389048f9
    7c17389048e5:	shr    rax,0x35
    7c17389048e9:	sub    eax,0x201
    7c17389048ee:	cmp    eax,0x3fc
    7c17389048f3:	ja     0x7c1738905757
    7c17389048f9:	addpd  xmm0,xmm1
    7c17389048fd:	movdqa xmm4,xmm0
    7c1738904901:	movdqa xmm0,xmm4
    7c1738904905:	movdqu XMMWORD PTR [r12+0x160],xmm0
    7c173890490f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c1738904919:	movdqa xmm2,xmm0
    7c173890491d:	movdqa xmm0,xmm7
    7c1738904921:	movdqa xmm1,xmm2
    7c1738904925:	movq   rax,xmm0
    7c173890492a:	add    rax,rax
    7c173890492d:	je     0x7c1738904943
    7c173890492f:	shr    rax,0x35
    7c1738904933:	sub    eax,0x201
    7c1738904938:	cmp    eax,0x3fc
    7c173890493d:	ja     0x7c173890577b
    7c1738904943:	movdqa xmm14,xmm0
    7c1738904948:	psrldq xmm14,0x8
    7c173890494e:	movq   rax,xmm14
    7c1738904953:	add    rax,rax
    7c1738904956:	je     0x7c173890496c
    7c1738904958:	shr    rax,0x35
    7c173890495c:	sub    eax,0x201
    7c1738904961:	cmp    eax,0x3fc
    7c1738904966:	ja     0x7c173890577b
    7c173890496c:	movq   rax,xmm1
    7c1738904971:	add    rax,rax
    7c1738904974:	je     0x7c173890498a
    7c1738904976:	shr    rax,0x35
    7c173890497a:	sub    eax,0x201
    7c173890497f:	cmp    eax,0x3fc
    7c1738904984:	ja     0x7c173890577b
    7c173890498a:	movdqa xmm14,xmm1
    7c173890498f:	psrldq xmm14,0x8
    7c1738904995:	movq   rax,xmm14
    7c173890499a:	add    rax,rax
    7c173890499d:	je     0x7c17389049b3
    7c173890499f:	shr    rax,0x35
    7c17389049a3:	sub    eax,0x201
    7c17389049a8:	cmp    eax,0x3fc
    7c17389049ad:	ja     0x7c173890577b
    7c17389049b3:	addpd  xmm0,xmm1
    7c17389049b7:	movdqa xmm3,xmm0
    7c17389049bb:	movdqa xmm0,xmm3
    7c17389049bf:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c17389049c9:	mov    r13,QWORD PTR [r12+0x60]
    7c17389049ce:	mov    r14,r13
    7c17389049d1:	add    r14,0x10
    7c17389049d5:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7c17389049df:	movdqa xmm2,xmm0
    7c17389049e3:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7c17389049ed:	movdqa xmm4,xmm0
    7c17389049f1:	stmxcsr DWORD PTR [rsp+0x114]
    7c17389049f9:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738904a01:	mov    r11d,DWORD PTR [rsp+0x114]
    7c1738904a09:	shr    r11d,1
    7c1738904a0c:	and    r11d,0x10
    7c1738904a10:	or     DWORD PTR [r12+0x314],r11d
    7c1738904a18:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c1738904a1e:	mov    r15d,0x0
    7c1738904a24:	mov    DWORD PTR [r12+0x32c],r15d
    7c1738904a2c:	movdqu XMMWORD PTR [r14],xmm4
    7c1738904a31:	mov    r14d,0x0
    7c1738904a37:	mov    DWORD PTR [r12+0x32c],r14d
    7c1738904a3f:	add    r13,0x20
    7c1738904a43:	mov    r14,r13
    7c1738904a46:	add    r14,0x10
    7c1738904a4a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7c1738904a54:	movdqa xmm2,xmm0
    7c1738904a58:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c1738904a5e:	mov    r13d,0x0
    7c1738904a64:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738904a6c:	movdqu XMMWORD PTR [r14],xmm3
    7c1738904a71:	mov    r13d,0x0
    7c1738904a77:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738904a7f:	mov    rcx,QWORD PTR [r12+0x380]
    7c1738904a87:	jrcxz  0x7c1738904a8e
    7c1738904a89:	jmp    0x7c1738907068
    7c1738904a8e:	push   QWORD PTR [rsp]
    7c1738904a91:	popf
    7c1738904a92:	je     0x7c1738904a9d
    7c1738904a98:	jmp    0x7c1738900ed8
    7c1738904a9d:	mov    r13d,DWORD PTR [r12+0x48]
    7c1738904aa2:	add    r13d,0x1
    7c1738904aa6:	mov    QWORD PTR [r12+0x48],r13
    7c1738904aab:	sub    r13d,0x1f4
    7c1738904ab2:	mov    rcx,QWORD PTR [r12+0x380]
    7c1738904aba:	jrcxz  0x7c1738904ac1
    7c1738904abc:	jmp    0x7c17389070f2
    7c1738904ac1:	pushf
    7c1738904ac2:	pop    r11
    7c1738904ac4:	mov    QWORD PTR [rsp],r11
    7c1738904ac8:	jne    0x7c1738900ec8
    7c1738904ace:	jmp    0x7c1738904ad3
    7c1738904ad3:	mov    r13d,0x0
    7c1738904ad9:	mov    QWORD PTR [r12+0x48],r13
    7c1738904ade:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738904ae6:	mov    r14,r13
    7c1738904ae9:	add    r14,0x140
    7c1738904af0:	mov    r15,QWORD PTR [r14]
    7c1738904af3:	mov    QWORD PTR [r12+0xe8],r15
    7c1738904afb:	mov    r14,r13
    7c1738904afe:	add    r14,0x130
    7c1738904b05:	mov    r15,r14
    7c1738904b08:	add    r15,0x8
    7c1738904b0c:	mov    rbp,QWORD PTR [r14]
    7c1738904b0f:	mov    r14,QWORD PTR [r15]
    7c1738904b12:	mov    r15d,0x0
    7c1738904b18:	mov    QWORD PTR [r12+0x1a0],rbp
    7c1738904b20:	mov    QWORD PTR [r12+0x1a8],r15
    7c1738904b28:	mov    r15d,0x0
    7c1738904b2e:	mov    QWORD PTR [r12+0x190],r14
    7c1738904b36:	mov    QWORD PTR [r12+0x198],r15
    7c1738904b3e:	add    r13,0x120
    7c1738904b45:	mov    r14,r13
    7c1738904b48:	add    r14,0x8
    7c1738904b4c:	mov    r15,QWORD PTR [r13+0x0]
    7c1738904b50:	mov    r13,QWORD PTR [r14]
    7c1738904b53:	mov    r14d,0x0
    7c1738904b59:	mov    QWORD PTR [r12+0x1c0],r15
    7c1738904b61:	mov    QWORD PTR [r12+0x1c8],r14
    7c1738904b69:	mov    r14d,0x0
    7c1738904b6f:	mov    QWORD PTR [r12+0x1b0],r13
    7c1738904b77:	mov    QWORD PTR [r12+0x1b8],r14
    7c1738904b7f:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738904b87:	mov    r14,r13
    7c1738904b8a:	add    r14,0x110
    7c1738904b91:	mov    r15,r14
    7c1738904b94:	add    r15,0x8
    7c1738904b98:	mov    rbp,QWORD PTR [r14]
    7c1738904b9b:	mov    r14,QWORD PTR [r15]
    7c1738904b9e:	mov    r15d,0x0
    7c1738904ba4:	mov    QWORD PTR [r12+0x1e0],rbp
    7c1738904bac:	mov    QWORD PTR [r12+0x1e8],r15
    7c1738904bb4:	mov    r15d,0x0
    7c1738904bba:	mov    QWORD PTR [r12+0x1d0],r14
    7c1738904bc2:	mov    QWORD PTR [r12+0x1d8],r15
    7c1738904bca:	add    r13,0x100
    7c1738904bd1:	mov    r14,r13
    7c1738904bd4:	add    r14,0x8
    7c1738904bd8:	mov    r15,QWORD PTR [r13+0x0]
    7c1738904bdc:	mov    r13,QWORD PTR [r14]
    7c1738904bdf:	mov    r14d,0x0
    7c1738904be5:	mov    QWORD PTR [r12+0x200],r15
    7c1738904bed:	mov    QWORD PTR [r12+0x208],r14
    7c1738904bf5:	mov    r14d,0x0
    7c1738904bfb:	mov    QWORD PTR [r12+0x1f0],r13
    7c1738904c03:	mov    QWORD PTR [r12+0x1f8],r14
    7c1738904c0b:	mov    r13d,0x430000
    7c1738904c11:	mov    QWORD PTR [r12+0x40],r13
    7c1738904c16:	mov    r13d,0x430510
    7c1738904c1c:	mov    r14,QWORD PTR [r13+0x0]
    7c1738904c20:	mov    r13d,0x0
    7c1738904c26:	mov    QWORD PTR [r12+0x110],r14
    7c1738904c2e:	mov    QWORD PTR [r12+0x118],r13
    7c1738904c36:	mov    r13,QWORD PTR [r12+0xf8]
    7c1738904c3e:	add    r13,0x150
    7c1738904c45:	mov    QWORD PTR [r12+0xf8],r13
    7c1738904c4d:	jmp    0x7c1738904c52
    7c1738904c52:	mov    r13,QWORD PTR [r12+0x48]
    7c1738904c57:	mov    r14,QWORD PTR [r12+0x50]
    7c1738904c5c:	mov    rcx,r13
    7c1738904c5f:	add    r14,rcx
    7c1738904c62:	movdqu xmm2,XMMWORD PTR [r14]
    7c1738904c67:	movdqa xmm0,xmm2
    7c1738904c6b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c1738904c75:	add    r13,0x10
    7c1738904c79:	mov    QWORD PTR [r12+0x48],r13
    7c1738904c7e:	sub    r13,0x200
    7c1738904c85:	mov    r13,QWORD PTR [r12+0x128]
    7c1738904c8d:	mov    r14d,0x0
    7c1738904c93:	mov    QWORD PTR [r12+0x130],r13
    7c1738904c9b:	mov    QWORD PTR [r12+0x138],r14
    7c1738904ca3:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7c1738904cad:	movdqa xmm2,xmm0
    7c1738904cb1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c1738904cbb:	movdqa xmm3,xmm0
    7c1738904cbf:	pushf
    7c1738904cc0:	pop    r11
    7c1738904cc2:	mov    QWORD PTR [rsp],r11
    7c1738904cc6:	stmxcsr DWORD PTR [rsp+0x110]
    7c1738904cce:	mov    DWORD PTR [rsp+0x114],0x1f80
    7c1738904cd9:	ldmxcsr DWORD PTR [rsp+0x114]
    7c1738904ce1:	movdqa xmm0,xmm2
    7c1738904ce5:	movdqa xmm1,xmm3
    7c1738904ce9:	movq   rax,xmm0
    7c1738904cee:	add    rax,rax
    7c1738904cf1:	je     0x7c1738904d07
    7c1738904cf3:	shr    rax,0x35
    7c1738904cf7:	sub    eax,0x201
    7c1738904cfc:	cmp    eax,0x3fc
    7c1738904d01:	ja     0x7c173890579f
    7c1738904d07:	movq   rax,xmm1
    7c1738904d0c:	add    rax,rax
    7c1738904d0f:	je     0x7c1738904d25
    7c1738904d11:	shr    rax,0x35
    7c1738904d15:	sub    eax,0x201
    7c1738904d1a:	cmp    eax,0x3fc
    7c1738904d1f:	ja     0x7c173890579f
    7c1738904d25:	movq   xmm0,xmm0
    7c1738904d29:	movq   xmm1,xmm1
    7c1738904d2d:	addsd  xmm0,xmm1
    7c1738904d31:	movdqa xmm4,xmm0
    7c1738904d35:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7c1738904d3f:	movdqa xmm2,xmm0
    7c1738904d43:	movdqa xmm0,xmm4
    7c1738904d47:	movdqa xmm1,xmm2
    7c1738904d4b:	movq   rax,xmm0
    7c1738904d50:	add    rax,rax
    7c1738904d53:	je     0x7c1738904d69
    7c1738904d55:	shr    rax,0x35
    7c1738904d59:	sub    eax,0x201
    7c1738904d5e:	cmp    eax,0x3fc
    7c1738904d63:	ja     0x7c17389057c3
    7c1738904d69:	movq   rax,xmm1
    7c1738904d6e:	add    rax,rax
    7c1738904d71:	je     0x7c1738904d87
    7c1738904d73:	shr    rax,0x35
    7c1738904d77:	sub    eax,0x201
    7c1738904d7c:	cmp    eax,0x3fc
    7c1738904d81:	ja     0x7c17389057c3
    7c1738904d87:	movq   xmm0,xmm0
    7c1738904d8b:	movq   xmm1,xmm1
    7c1738904d8f:	addsd  xmm0,xmm1
    7c1738904d93:	movdqa xmm3,xmm0
    7c1738904d97:	movdqa xmm0,xmm3
    7c1738904d9b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7c1738904da5:	stmxcsr DWORD PTR [rsp+0x114]
    7c1738904dad:	ldmxcsr DWORD PTR [rsp+0x110]
    7c1738904db5:	mov    r11d,DWORD PTR [rsp+0x114]
    7c1738904dbd:	shr    r11d,1
    7c1738904dc0:	and    r11d,0x10
    7c1738904dc4:	or     DWORD PTR [r12+0x314],r11d
    7c1738904dcc:	mov    rcx,QWORD PTR [r12+0x380]
    7c1738904dd4:	jrcxz  0x7c1738904ddb
    7c1738904dd6:	jmp    0x7c1738907184
    7c1738904ddb:	push   QWORD PTR [rsp]
    7c1738904dde:	popf
    7c1738904ddf:	jne    0x7c1738904c52
    7c1738904de5:	jmp    0x7c1738904dea
    7c1738904dea:	mov    r13,QWORD PTR [r12+0x40]
    7c1738904def:	add    r13,0x510
    7c1738904df6:	mov    r14,QWORD PTR [r12+0x110]
    7c1738904dfe:	mov    QWORD PTR [r13+0x0],r14
    7c1738904e02:	mov    r13d,0x0
    7c1738904e08:	mov    DWORD PTR [r12+0x32c],r13d
    7c1738904e10:	mov    rcx,QWORD PTR [r12+0x380]
    7c1738904e18:	jrcxz  0x7c1738904e1f
    7c1738904e1a:	jmp    0x7c173890720e
    7c1738904e1f:	mov    r13,QWORD PTR [r12+0xf0]
    7c1738904e27:	mov    QWORD PTR [r12+0x100],r13
    7c1738904e2f:	mov    r11,QWORD PTR [rsp]
    7c1738904e33:	mov    QWORD PTR [r12+0x398],r11
    7c1738904e3b:	mov    rdi,QWORD PTR [r12+0x100]
    7c1738904e43:	add    rsp,0x150
    7c1738904e4a:	movabs r11,0x59b8d047a0a0
    7c1738904e54:	jmp    r11
    7c1738904e57:	movdqa xmm0,xmm2
    7c1738904e5b:	movdqa xmm1,xmm3
    7c1738904e5f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904e68:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904e71:	call   0x7c17389057f0
    7c1738904e76:	jmp    0x7c17389005be
    7c1738904e7b:	movdqa xmm0,xmm2
    7c1738904e7f:	movdqa xmm1,xmm3
    7c1738904e83:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904e8c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904e95:	call   0x7c17389057f0
    7c1738904e9a:	jmp    0x7c17389006eb
    7c1738904e9f:	movdqa xmm0,xmm3
    7c1738904ea3:	movdqa xmm1,xmm4
    7c1738904ea7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904eb0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904eb9:	call   0x7c17389058d0
    7c1738904ebe:	jmp    0x7c17389011a1
    7c1738904ec3:	movdqa xmm0,xmm2
    7c1738904ec7:	movdqa xmm1,xmm4
    7c1738904ecb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904ed4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904edd:	call   0x7c1738905a60
    7c1738904ee2:	jmp    0x7c1738901260
    7c1738904ee7:	movdqa xmm0,xmm3
    7c1738904eeb:	movdqa xmm1,xmm2
    7c1738904eef:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904ef8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904f01:	call   0x7c1738905bf0
    7c1738904f06:	jmp    0x7c1738901336
    7c1738904f0b:	movdqa xmm0,xmm3
    7c1738904f0f:	movdqa xmm1,xmm2
    7c1738904f13:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904f1c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904f25:	call   0x7c1738905bf0
    7c1738904f2a:	jmp    0x7c17389013f0
    7c1738904f2f:	movdqa xmm0,xmm2
    7c1738904f33:	movdqa xmm1,xmm3
    7c1738904f37:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904f40:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904f49:	call   0x7c1738905bf0
    7c1738904f4e:	jmp    0x7c17389014b8
    7c1738904f53:	movdqa xmm0,xmm2
    7c1738904f57:	movdqa xmm1,xmm3
    7c1738904f5b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904f64:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904f6d:	call   0x7c1738905d70
    7c1738904f72:	jmp    0x7c17389015c3
    7c1738904f77:	movdqa xmm0,xmm2
    7c1738904f7b:	movdqa xmm1,xmm3
    7c1738904f7f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904f88:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904f91:	call   0x7c1738905ef0
    7c1738904f96:	jmp    0x7c17389016e0
    7c1738904f9b:	movdqa xmm0,xmm2
    7c1738904f9f:	movdqa xmm1,xmm3
    7c1738904fa3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904fac:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904fb5:	call   0x7c1738905ef0
    7c1738904fba:	jmp    0x7c17389017a8
    7c1738904fbf:	movdqa xmm0,xmm2
    7c1738904fc3:	movdqa xmm1,xmm3
    7c1738904fc7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904fd0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904fd9:	call   0x7c1738905ef0
    7c1738904fde:	jmp    0x7c1738901862
    7c1738904fe3:	movdqa xmm0,xmm2
    7c1738904fe7:	movdqa xmm1,xmm4
    7c1738904feb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738904ff4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738904ffd:	call   0x7c1738906070
    7c1738905002:	jmp    0x7c1738901aa7
    7c1738905007:	movdqa xmm0,xmm4
    7c173890500b:	movdqa xmm1,xmm5
    7c173890500f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905018:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905021:	call   0x7c1738906200
    7c1738905026:	jmp    0x7c1738901bcc
    7c173890502b:	movdqa xmm0,xmm4
    7c173890502f:	movdqa xmm1,xmm5
    7c1738905033:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c173890503c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905045:	call   0x7c1738906200
    7c173890504a:	jmp    0x7c1738901c94
    7c173890504f:	movdqa xmm0,xmm3
    7c1738905053:	movdqa xmm1,xmm4
    7c1738905057:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905060:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905069:	call   0x7c1738905a60
    7c173890506e:	jmp    0x7c1738901d53
    7c1738905073:	movdqa xmm0,xmm2
    7c1738905077:	movdqa xmm1,xmm3
    7c173890507b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905084:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c173890508d:	call   0x7c1738905a60
    7c1738905092:	jmp    0x7c1738901e12
    7c1738905097:	movdqa xmm0,xmm2
    7c173890509b:	movdqa xmm1,xmm4
    7c173890509f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389050a8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389050b1:	call   0x7c1738905a60
    7c17389050b6:	jmp    0x7c1738901f38
    7c17389050bb:	movdqa xmm0,xmm2
    7c17389050bf:	movdqa xmm1,xmm3
    7c17389050c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389050cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389050d5:	call   0x7c1738905d70
    7c17389050da:	jmp    0x7c173890203f
    7c17389050df:	movdqa xmm0,xmm3
    7c17389050e3:	movdqa xmm1,xmm4
    7c17389050e7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389050f0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389050f9:	call   0x7c1738906070
    7c17389050fe:	jmp    0x7c17389021f4
    7c1738905103:	movdqa xmm0,xmm2
    7c1738905107:	movdqa xmm1,xmm3
    7c173890510b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905114:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c173890511d:	call   0x7c1738905d70
    7c1738905122:	jmp    0x7c17389022b3
    7c1738905127:	movdqa xmm0,xmm3
    7c173890512b:	movdqa xmm1,xmm4
    7c173890512f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905138:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905141:	call   0x7c1738906070
    7c1738905146:	jmp    0x7c17389023e0
    7c173890514b:	movdqa xmm0,xmm3
    7c173890514f:	movdqa xmm1,xmm4
    7c1738905153:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c173890515c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905165:	call   0x7c1738906070
    7c173890516a:	jmp    0x7c17389024a8
    7c173890516f:	movdqa xmm0,xmm2
    7c1738905173:	movdqa xmm1,xmm3
    7c1738905177:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905180:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905189:	call   0x7c1738905d70
    7c173890518e:	jmp    0x7c173890258b
    7c1738905193:	movdqa xmm0,xmm3
    7c1738905197:	movdqa xmm1,xmm4
    7c173890519b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389051a4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389051ad:	call   0x7c1738906070
    7c17389051b2:	jmp    0x7c17389026b8
    7c17389051b7:	movdqa xmm0,xmm3
    7c17389051bb:	movdqa xmm1,xmm4
    7c17389051bf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389051c8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389051d1:	call   0x7c1738905a60
    7c17389051d6:	jmp    0x7c1738902785
    7c17389051db:	movdqa xmm0,xmm2
    7c17389051df:	movdqa xmm1,xmm4
    7c17389051e3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389051ec:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389051f5:	call   0x7c1738906390
    7c17389051fa:	jmp    0x7c1738902852
    7c17389051ff:	movdqa xmm0,xmm3
    7c1738905203:	movdqa xmm1,xmm4
    7c1738905207:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905210:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905219:	call   0x7c1738906070
    7c173890521e:	jmp    0x7c1738902981
    7c1738905223:	movdqa xmm0,xmm2
    7c1738905227:	movdqa xmm1,xmm3
    7c173890522b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905234:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c173890523d:	call   0x7c1738905d70
    7c1738905242:	jmp    0x7c1738902a88
    7c1738905247:	movdqa xmm0,xmm2
    7c173890524b:	movdqa xmm1,xmm4
    7c173890524f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905258:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905261:	call   0x7c1738906070
    7c1738905266:	jmp    0x7c1738902baa
    7c173890526b:	movdqa xmm0,xmm2
    7c173890526f:	movdqa xmm1,xmm3
    7c1738905273:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c173890527c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905285:	call   0x7c1738905d70
    7c173890528a:	jmp    0x7c1738902c69
    7c173890528f:	movdqa xmm0,xmm2
    7c1738905293:	movdqa xmm1,xmm3
    7c1738905297:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389052a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389052a9:	call   0x7c1738905ef0
    7c17389052ae:	jmp    0x7c1738902d31
    7c17389052b3:	movdqa xmm0,xmm2
    7c17389052b7:	movdqa xmm1,xmm3
    7c17389052bb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389052c4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389052cd:	call   0x7c1738905d70
    7c17389052d2:	jmp    0x7c1738902dfe
    7c17389052d7:	movdqa xmm0,xmm2
    7c17389052db:	movdqa xmm1,xmm3
    7c17389052df:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389052e8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389052f1:	call   0x7c1738905d70
    7c17389052f6:	jmp    0x7c1738902ebd
    7c17389052fb:	movdqa xmm0,xmm2
    7c17389052ff:	movdqa xmm1,xmm4
    7c1738905303:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c173890530c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905315:	call   0x7c1738906070
    7c173890531a:	jmp    0x7c1738902f85
    7c173890531f:	movdqa xmm0,xmm2
    7c1738905323:	movdqa xmm1,xmm4
    7c1738905327:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905330:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905339:	call   0x7c1738906070
    7c173890533e:	jmp    0x7c173890304d
    7c1738905343:	movdqa xmm0,xmm2
    7c1738905347:	movdqa xmm1,xmm3
    7c173890534b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905354:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c173890535d:	call   0x7c1738905d70
    7c1738905362:	jmp    0x7c173890310c
    7c1738905367:	movdqa xmm0,xmm2
    7c173890536b:	movdqa xmm1,xmm3
    7c173890536f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905378:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905381:	call   0x7c1738905d70
    7c1738905386:	jmp    0x7c17389031cb
    7c173890538b:	movdqa xmm0,xmm2
    7c173890538f:	movdqa xmm1,xmm3
    7c1738905393:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c173890539c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389053a5:	call   0x7c1738905ef0
    7c17389053aa:	jmp    0x7c1738903293
    7c17389053af:	movdqa xmm0,xmm2
    7c17389053b3:	movdqa xmm1,xmm3
    7c17389053b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389053c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389053c9:	call   0x7c1738905ef0
    7c17389053ce:	jmp    0x7c173890335b
    7c17389053d3:	movdqa xmm0,xmm2
    7c17389053d7:	movdqa xmm1,xmm3
    7c17389053db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389053e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389053ed:	call   0x7c1738905d70
    7c17389053f2:	jmp    0x7c1738903428
    7c17389053f7:	movdqa xmm0,xmm2
    7c17389053fb:	movdqa xmm1,xmm3
    7c17389053ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905408:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905411:	call   0x7c1738905ef0
    7c1738905416:	jmp    0x7c17389034f0
    7c173890541b:	movdqa xmm0,xmm2
    7c173890541f:	movdqa xmm1,xmm3
    7c1738905423:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c173890542c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905435:	call   0x7c1738905ef0
    7c173890543a:	jmp    0x7c17389035b8
    7c173890543f:	movdqa xmm0,xmm2
    7c1738905443:	movdqa xmm1,xmm3
    7c1738905447:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905450:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905459:	call   0x7c1738905d70
    7c173890545e:	jmp    0x7c1738903753
    7c1738905463:	movdqa xmm0,xmm2
    7c1738905467:	movdqa xmm1,xmm4
    7c173890546b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905474:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c173890547d:	call   0x7c1738906070
    7c1738905482:	jmp    0x7c173890381b
    7c1738905487:	movdqa xmm0,xmm2
    7c173890548b:	movdqa xmm1,xmm4
    7c173890548f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905498:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389054a1:	call   0x7c1738906070
    7c17389054a6:	jmp    0x7c17389038e3
    7c17389054ab:	movdqa xmm0,xmm2
    7c17389054af:	movdqa xmm1,xmm3
    7c17389054b3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389054bc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389054c5:	call   0x7c1738905d70
    7c17389054ca:	jmp    0x7c17389039a2
    7c17389054cf:	movdqa xmm0,xmm2
    7c17389054d3:	movdqa xmm1,xmm3
    7c17389054d7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389054e0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389054e9:	call   0x7c1738905d70
    7c17389054ee:	jmp    0x7c1738903a6f
    7c17389054f3:	movdqa xmm0,xmm2
    7c17389054f7:	movdqa xmm1,xmm3
    7c17389054fb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905504:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c173890550d:	call   0x7c1738905d70
    7c1738905512:	jmp    0x7c1738903b3c
    7c1738905517:	movdqa xmm0,xmm2
    7c173890551b:	movdqa xmm1,xmm4
    7c173890551f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905528:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905531:	call   0x7c1738906070
    7c1738905536:	jmp    0x7c1738903c04
    7c173890553b:	movdqa xmm0,xmm2
    7c173890553f:	movdqa xmm1,xmm3
    7c1738905543:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c173890554c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905555:	call   0x7c1738905d70
    7c173890555a:	jmp    0x7c1738903cc3
    7c173890555f:	movdqa xmm0,xmm2
    7c1738905563:	movdqa xmm1,xmm4
    7c1738905567:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905570:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905579:	call   0x7c1738906070
    7c173890557e:	jmp    0x7c1738903d8b
    7c1738905583:	movdqa xmm0,xmm2
    7c1738905587:	movdqa xmm1,xmm3
    7c173890558b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905594:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c173890559d:	call   0x7c1738905d70
    7c17389055a2:	jmp    0x7c1738903e4a
    7c17389055a7:	movdqa xmm0,xmm2
    7c17389055ab:	movdqa xmm1,xmm3
    7c17389055af:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389055b8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389055c1:	call   0x7c1738905ef0
    7c17389055c6:	jmp    0x7c1738903f12
    7c17389055cb:	movdqa xmm0,xmm2
    7c17389055cf:	movdqa xmm1,xmm3
    7c17389055d3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389055dc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389055e5:	call   0x7c1738905d70
    7c17389055ea:	jmp    0x7c1738903fdf
    7c17389055ef:	movdqa xmm0,xmm2
    7c17389055f3:	movdqa xmm1,xmm3
    7c17389055f7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905600:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905609:	call   0x7c1738905ef0
    7c173890560e:	jmp    0x7c17389040a7
    7c1738905613:	movdqa xmm0,xmm3
    7c1738905617:	movdqa xmm1,xmm4
    7c173890561b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905624:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c173890562d:	call   0x7c1738906070
    7c1738905632:	jmp    0x7c17389041d3
    7c1738905637:	movdqa xmm0,xmm2
    7c173890563b:	movdqa xmm1,xmm3
    7c173890563f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905648:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905651:	call   0x7c1738905d70
    7c1738905656:	jmp    0x7c1738904292
    7c173890565b:	movdqa xmm0,xmm2
    7c173890565f:	movdqa xmm1,xmm3
    7c1738905663:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c173890566c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905675:	call   0x7c1738905d70
    7c173890567a:	jmp    0x7c1738904351
    7c173890567f:	movdqa xmm0,xmm2
    7c1738905683:	movdqa xmm1,xmm4
    7c1738905687:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905690:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905699:	call   0x7c1738906070
    7c173890569e:	jmp    0x7c1738904419
    7c17389056a3:	movdqa xmm0,xmm5
    7c17389056a7:	movdqa xmm1,xmm6
    7c17389056ab:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389056b4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389056bd:	call   0x7c1738906510
    7c17389056c2:	jmp    0x7c1738904543
    7c17389056c7:	movdqa xmm0,xmm4
    7c17389056cb:	movdqa xmm1,xmm3
    7c17389056cf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389056d8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389056e1:	call   0x7c17389066b0
    7c17389056e6:	jmp    0x7c17389045f4
    7c17389056eb:	movdqa xmm0,xmm2
    7c17389056ef:	movdqa xmm1,xmm3
    7c17389056f3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389056fc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905705:	call   0x7c1738906840
    7c173890570a:	jmp    0x7c17389046a5
    7c173890570f:	movdqa xmm0,xmm2
    7c1738905713:	movdqa xmm1,xmm3
    7c1738905717:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905720:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905729:	call   0x7c17389069d0
    7c173890572e:	jmp    0x7c173890476d
    7c1738905733:	movdqa xmm0,xmm2
    7c1738905737:	movdqa xmm1,xmm3
    7c173890573b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905744:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c173890574d:	call   0x7c17389069d0
    7c1738905752:	jmp    0x7c1738904835
    7c1738905757:	movdqa xmm0,xmm2
    7c173890575b:	movdqa xmm1,xmm3
    7c173890575f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c1738905768:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905771:	call   0x7c17389069d0
    7c1738905776:	jmp    0x7c17389048fd
    7c173890577b:	movdqa xmm0,xmm7
    7c173890577f:	movdqa xmm1,xmm2
    7c1738905783:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c173890578c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c1738905795:	call   0x7c1738906b60
    7c173890579a:	jmp    0x7c17389049b7
    7c173890579f:	movdqa xmm0,xmm2
    7c17389057a3:	movdqa xmm1,xmm3
    7c17389057a7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389057b0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389057b9:	call   0x7c1738906ce0
    7c17389057be:	jmp    0x7c1738904d31
    7c17389057c3:	movdqa xmm0,xmm4
    7c17389057c7:	movdqa xmm1,xmm2
    7c17389057cb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c17389057d4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c17389057dd:	call   0x7c1738906e60
    7c17389057e2:	jmp    0x7c1738904d93
    7c17389057e7:	nop    WORD PTR [rax+rax*1+0x0]
    7c17389057f0:	sub    rsp,0x8
    7c17389057f4:	stmxcsr DWORD PTR [rsp+0x124]
    7c17389057fc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738905804:	mov    r11d,DWORD PTR [rsp+0x124]
    7c173890580c:	shr    r11d,1
    7c173890580f:	and    r11d,0x10
    7c1738905813:	or     DWORD PTR [r12+0x314],r11d
    7c173890581b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738905827:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c173890582d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738905833:	mov    QWORD PTR [r12+0x108],rbx
    7c173890583b:	stmxcsr DWORD PTR [r12-0x28]
    7c1738905841:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738905847:	lea    rdi,[rsp+0x110]
    7c173890584f:	lea    rsi,[rsp+0xf0]
    7c1738905857:	lea    rdx,[rsp+0x100]
    7c173890585f:	mov    ecx,0x16
    7c1738905864:	mov    r8d,0x0
    7c173890586a:	lea    r9,[r12+0x314]
    7c1738905872:	movabs r11,0x59b8d02e51b0
    7c173890587c:	call   r11
    7c173890587f:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738905885:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c173890588b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738905891:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738905899:	mov    QWORD PTR [r12+0x378],0x2
    7c17389058a5:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c17389058ae:	stmxcsr DWORD PTR [rsp+0x120]
    7c17389058b6:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c17389058c1:	ldmxcsr DWORD PTR [rsp+0x124]
    7c17389058c9:	add    rsp,0x8
    7c17389058cd:	ret
    7c17389058ce:	xchg   ax,ax
    7c17389058d0:	sub    rsp,0x8
    7c17389058d4:	stmxcsr DWORD PTR [rsp+0x124]
    7c17389058dc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c17389058e4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c17389058ec:	shr    r11d,1
    7c17389058ef:	and    r11d,0x10
    7c17389058f3:	or     DWORD PTR [r12+0x314],r11d
    7c17389058fb:	mov    QWORD PTR [r12+0x378],0x3
    7c1738905907:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c173890590d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738905913:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c1738905919:	push   rdx
    7c173890591a:	push   rsi
    7c173890591b:	push   r10
    7c173890591d:	push   r11
    7c173890591f:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738905924:	mov    r10d,edx
    7c1738905927:	and    r10d,0xc0
    7c173890592e:	shl    r10d,0x18
    7c1738905932:	mov    r11d,edx
    7c1738905935:	and    r11d,0x1
    7c1738905939:	shl    r11d,0x1d
    7c173890593d:	or     r10d,r11d
    7c1738905940:	mov    r11d,edx
    7c1738905943:	and    r11d,0x800
    7c173890594a:	shl    r11d,0x11
    7c173890594e:	or     r10d,r11d
    7c1738905951:	btc    r10,0x1d
    7c1738905956:	mov    r11d,0xf0000000
    7c173890595c:	and    r11,r10
    7c173890595f:	movabs rsi,0xffffffff0fffffff
    7c1738905969:	and    rbx,rsi
    7c173890596c:	or     rbx,r11
    7c173890596f:	pop    r11
    7c1738905971:	pop    r10
    7c1738905973:	pop    rsi
    7c1738905974:	pop    rdx
    7c1738905975:	mov    QWORD PTR [r12+0x108],rbx
    7c173890597d:	stmxcsr DWORD PTR [r12-0x28]
    7c1738905983:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738905989:	lea    rdi,[rsp+0x110]
    7c1738905991:	lea    rsi,[rsp+0xf0]
    7c1738905999:	lea    rdx,[rsp+0x100]
    7c17389059a1:	mov    ecx,0x16
    7c17389059a6:	mov    r8d,0x0
    7c17389059ac:	lea    r9,[r12+0x314]
    7c17389059b4:	movabs r11,0x59b8d02e51b0
    7c17389059be:	call   r11
    7c17389059c1:	ldmxcsr DWORD PTR [r12-0x28]
    7c17389059c7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c17389059cd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c17389059d3:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c17389059d9:	mov    rbx,QWORD PTR [r12+0x108]
    7c17389059e1:	mov    QWORD PTR [r12+0x378],0x2
    7c17389059ed:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c17389059f6:	pushf
    7c17389059f7:	pop    rdx
    7c17389059f8:	and    rdx,0xfffffffffffff73e
    7c17389059ff:	mov    rax,rbx
    7c1738905a02:	shr    rax,0x18
    7c1738905a06:	and    eax,0xc0
    7c1738905a0b:	or     rdx,rax
    7c1738905a0e:	mov    rax,rbx
    7c1738905a11:	shr    rax,0x1d
    7c1738905a15:	and    eax,0x1
    7c1738905a18:	xor    eax,0x1
    7c1738905a1b:	or     rdx,rax
    7c1738905a1e:	mov    rax,rbx
    7c1738905a21:	shr    rax,0x11
    7c1738905a25:	and    eax,0x800
    7c1738905a2a:	or     rdx,rax
    7c1738905a2d:	mov    QWORD PTR [rsp+0x10],rdx
    7c1738905a32:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738905a3a:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738905a45:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738905a4d:	add    rsp,0x8
    7c1738905a51:	ret
    7c1738905a52:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738905a60:	sub    rsp,0x8
    7c1738905a64:	stmxcsr DWORD PTR [rsp+0x124]
    7c1738905a6c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738905a74:	mov    r11d,DWORD PTR [rsp+0x124]
    7c1738905a7c:	shr    r11d,1
    7c1738905a7f:	and    r11d,0x10
    7c1738905a83:	or     DWORD PTR [r12+0x314],r11d
    7c1738905a8b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738905a97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c1738905a9d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738905aa3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c1738905aa9:	push   rdx
    7c1738905aaa:	push   rsi
    7c1738905aab:	push   r10
    7c1738905aad:	push   r11
    7c1738905aaf:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738905ab4:	mov    r10d,edx
    7c1738905ab7:	and    r10d,0xc0
    7c1738905abe:	shl    r10d,0x18
    7c1738905ac2:	mov    r11d,edx
    7c1738905ac5:	and    r11d,0x1
    7c1738905ac9:	shl    r11d,0x1d
    7c1738905acd:	or     r10d,r11d
    7c1738905ad0:	mov    r11d,edx
    7c1738905ad3:	and    r11d,0x800
    7c1738905ada:	shl    r11d,0x11
    7c1738905ade:	or     r10d,r11d
    7c1738905ae1:	btc    r10,0x1d
    7c1738905ae6:	mov    r11d,0xf0000000
    7c1738905aec:	and    r11,r10
    7c1738905aef:	movabs rsi,0xffffffff0fffffff
    7c1738905af9:	and    rbx,rsi
    7c1738905afc:	or     rbx,r11
    7c1738905aff:	pop    r11
    7c1738905b01:	pop    r10
    7c1738905b03:	pop    rsi
    7c1738905b04:	pop    rdx
    7c1738905b05:	mov    QWORD PTR [r12+0x108],rbx
    7c1738905b0d:	stmxcsr DWORD PTR [r12-0x28]
    7c1738905b13:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738905b19:	lea    rdi,[rsp+0x110]
    7c1738905b21:	lea    rsi,[rsp+0xf0]
    7c1738905b29:	lea    rdx,[rsp+0x100]
    7c1738905b31:	mov    ecx,0x56
    7c1738905b36:	mov    r8d,0x0
    7c1738905b3c:	lea    r9,[r12+0x314]
    7c1738905b44:	movabs r11,0x59b8d02e51b0
    7c1738905b4e:	call   r11
    7c1738905b51:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738905b57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738905b5d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738905b63:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c1738905b69:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738905b71:	mov    QWORD PTR [r12+0x378],0x2
    7c1738905b7d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738905b86:	pushf
    7c1738905b87:	pop    rdx
    7c1738905b88:	and    rdx,0xfffffffffffff73e
    7c1738905b8f:	mov    rax,rbx
    7c1738905b92:	shr    rax,0x18
    7c1738905b96:	and    eax,0xc0
    7c1738905b9b:	or     rdx,rax
    7c1738905b9e:	mov    rax,rbx
    7c1738905ba1:	shr    rax,0x1d
    7c1738905ba5:	and    eax,0x1
    7c1738905ba8:	xor    eax,0x1
    7c1738905bab:	or     rdx,rax
    7c1738905bae:	mov    rax,rbx
    7c1738905bb1:	shr    rax,0x11
    7c1738905bb5:	and    eax,0x800
    7c1738905bba:	or     rdx,rax
    7c1738905bbd:	mov    QWORD PTR [rsp+0x10],rdx
    7c1738905bc2:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738905bca:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738905bd5:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738905bdd:	add    rsp,0x8
    7c1738905be1:	ret
    7c1738905be2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738905bf0:	sub    rsp,0x8
    7c1738905bf4:	stmxcsr DWORD PTR [rsp+0x124]
    7c1738905bfc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738905c04:	mov    r11d,DWORD PTR [rsp+0x124]
    7c1738905c0c:	shr    r11d,1
    7c1738905c0f:	and    r11d,0x10
    7c1738905c13:	or     DWORD PTR [r12+0x314],r11d
    7c1738905c1b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738905c27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c1738905c2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738905c33:	push   rdx
    7c1738905c34:	push   rsi
    7c1738905c35:	push   r10
    7c1738905c37:	push   r11
    7c1738905c39:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738905c3e:	mov    r10d,edx
    7c1738905c41:	and    r10d,0xc0
    7c1738905c48:	shl    r10d,0x18
    7c1738905c4c:	mov    r11d,edx
    7c1738905c4f:	and    r11d,0x1
    7c1738905c53:	shl    r11d,0x1d
    7c1738905c57:	or     r10d,r11d
    7c1738905c5a:	mov    r11d,edx
    7c1738905c5d:	and    r11d,0x800
    7c1738905c64:	shl    r11d,0x11
    7c1738905c68:	or     r10d,r11d
    7c1738905c6b:	btc    r10,0x1d
    7c1738905c70:	mov    r11d,0xf0000000
    7c1738905c76:	and    r11,r10
    7c1738905c79:	movabs rsi,0xffffffff0fffffff
    7c1738905c83:	and    rbx,rsi
    7c1738905c86:	or     rbx,r11
    7c1738905c89:	pop    r11
    7c1738905c8b:	pop    r10
    7c1738905c8d:	pop    rsi
    7c1738905c8e:	pop    rdx
    7c1738905c8f:	mov    QWORD PTR [r12+0x108],rbx
    7c1738905c97:	stmxcsr DWORD PTR [r12-0x28]
    7c1738905c9d:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738905ca3:	lea    rdi,[rsp+0x110]
    7c1738905cab:	lea    rsi,[rsp+0xf0]
    7c1738905cb3:	lea    rdx,[rsp+0x100]
    7c1738905cbb:	mov    ecx,0x16
    7c1738905cc0:	mov    r8d,0x0
    7c1738905cc6:	lea    r9,[r12+0x314]
    7c1738905cce:	movabs r11,0x59b8d02e51b0
    7c1738905cd8:	call   r11
    7c1738905cdb:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738905ce1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738905ce7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738905ced:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738905cf5:	mov    QWORD PTR [r12+0x378],0x2
    7c1738905d01:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738905d0a:	pushf
    7c1738905d0b:	pop    rdx
    7c1738905d0c:	and    rdx,0xfffffffffffff73e
    7c1738905d13:	mov    rax,rbx
    7c1738905d16:	shr    rax,0x18
    7c1738905d1a:	and    eax,0xc0
    7c1738905d1f:	or     rdx,rax
    7c1738905d22:	mov    rax,rbx
    7c1738905d25:	shr    rax,0x1d
    7c1738905d29:	and    eax,0x1
    7c1738905d2c:	xor    eax,0x1
    7c1738905d2f:	or     rdx,rax
    7c1738905d32:	mov    rax,rbx
    7c1738905d35:	shr    rax,0x11
    7c1738905d39:	and    eax,0x800
    7c1738905d3e:	or     rdx,rax
    7c1738905d41:	mov    QWORD PTR [rsp+0x10],rdx
    7c1738905d46:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738905d4e:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738905d59:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738905d61:	add    rsp,0x8
    7c1738905d65:	ret
    7c1738905d66:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738905d70:	sub    rsp,0x8
    7c1738905d74:	stmxcsr DWORD PTR [rsp+0x124]
    7c1738905d7c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738905d84:	mov    r11d,DWORD PTR [rsp+0x124]
    7c1738905d8c:	shr    r11d,1
    7c1738905d8f:	and    r11d,0x10
    7c1738905d93:	or     DWORD PTR [r12+0x314],r11d
    7c1738905d9b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738905da7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c1738905dad:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738905db3:	push   rdx
    7c1738905db4:	push   rsi
    7c1738905db5:	push   r10
    7c1738905db7:	push   r11
    7c1738905db9:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738905dbe:	mov    r10d,edx
    7c1738905dc1:	and    r10d,0xc0
    7c1738905dc8:	shl    r10d,0x18
    7c1738905dcc:	mov    r11d,edx
    7c1738905dcf:	and    r11d,0x1
    7c1738905dd3:	shl    r11d,0x1d
    7c1738905dd7:	or     r10d,r11d
    7c1738905dda:	mov    r11d,edx
    7c1738905ddd:	and    r11d,0x800
    7c1738905de4:	shl    r11d,0x11
    7c1738905de8:	or     r10d,r11d
    7c1738905deb:	btc    r10,0x1d
    7c1738905df0:	mov    r11d,0xf0000000
    7c1738905df6:	and    r11,r10
    7c1738905df9:	movabs rsi,0xffffffff0fffffff
    7c1738905e03:	and    rbx,rsi
    7c1738905e06:	or     rbx,r11
    7c1738905e09:	pop    r11
    7c1738905e0b:	pop    r10
    7c1738905e0d:	pop    rsi
    7c1738905e0e:	pop    rdx
    7c1738905e0f:	mov    QWORD PTR [r12+0x108],rbx
    7c1738905e17:	stmxcsr DWORD PTR [r12-0x28]
    7c1738905e1d:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738905e23:	lea    rdi,[rsp+0x110]
    7c1738905e2b:	lea    rsi,[rsp+0xf0]
    7c1738905e33:	lea    rdx,[rsp+0x100]
    7c1738905e3b:	mov    ecx,0x56
    7c1738905e40:	mov    r8d,0x0
    7c1738905e46:	lea    r9,[r12+0x314]
    7c1738905e4e:	movabs r11,0x59b8d02e51b0
    7c1738905e58:	call   r11
    7c1738905e5b:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738905e61:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738905e67:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738905e6d:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738905e75:	mov    QWORD PTR [r12+0x378],0x2
    7c1738905e81:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738905e8a:	pushf
    7c1738905e8b:	pop    rdx
    7c1738905e8c:	and    rdx,0xfffffffffffff73e
    7c1738905e93:	mov    rax,rbx
    7c1738905e96:	shr    rax,0x18
    7c1738905e9a:	and    eax,0xc0
    7c1738905e9f:	or     rdx,rax
    7c1738905ea2:	mov    rax,rbx
    7c1738905ea5:	shr    rax,0x1d
    7c1738905ea9:	and    eax,0x1
    7c1738905eac:	xor    eax,0x1
    7c1738905eaf:	or     rdx,rax
    7c1738905eb2:	mov    rax,rbx
    7c1738905eb5:	shr    rax,0x11
    7c1738905eb9:	and    eax,0x800
    7c1738905ebe:	or     rdx,rax
    7c1738905ec1:	mov    QWORD PTR [rsp+0x10],rdx
    7c1738905ec6:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738905ece:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738905ed9:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738905ee1:	add    rsp,0x8
    7c1738905ee5:	ret
    7c1738905ee6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738905ef0:	sub    rsp,0x8
    7c1738905ef4:	stmxcsr DWORD PTR [rsp+0x124]
    7c1738905efc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738905f04:	mov    r11d,DWORD PTR [rsp+0x124]
    7c1738905f0c:	shr    r11d,1
    7c1738905f0f:	and    r11d,0x10
    7c1738905f13:	or     DWORD PTR [r12+0x314],r11d
    7c1738905f1b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738905f27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c1738905f2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738905f33:	push   rdx
    7c1738905f34:	push   rsi
    7c1738905f35:	push   r10
    7c1738905f37:	push   r11
    7c1738905f39:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738905f3e:	mov    r10d,edx
    7c1738905f41:	and    r10d,0xc0
    7c1738905f48:	shl    r10d,0x18
    7c1738905f4c:	mov    r11d,edx
    7c1738905f4f:	and    r11d,0x1
    7c1738905f53:	shl    r11d,0x1d
    7c1738905f57:	or     r10d,r11d
    7c1738905f5a:	mov    r11d,edx
    7c1738905f5d:	and    r11d,0x800
    7c1738905f64:	shl    r11d,0x11
    7c1738905f68:	or     r10d,r11d
    7c1738905f6b:	btc    r10,0x1d
    7c1738905f70:	mov    r11d,0xf0000000
    7c1738905f76:	and    r11,r10
    7c1738905f79:	movabs rsi,0xffffffff0fffffff
    7c1738905f83:	and    rbx,rsi
    7c1738905f86:	or     rbx,r11
    7c1738905f89:	pop    r11
    7c1738905f8b:	pop    r10
    7c1738905f8d:	pop    rsi
    7c1738905f8e:	pop    rdx
    7c1738905f8f:	mov    QWORD PTR [r12+0x108],rbx
    7c1738905f97:	stmxcsr DWORD PTR [r12-0x28]
    7c1738905f9d:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738905fa3:	lea    rdi,[rsp+0x110]
    7c1738905fab:	lea    rsi,[rsp+0xf0]
    7c1738905fb3:	lea    rdx,[rsp+0x100]
    7c1738905fbb:	mov    ecx,0x14
    7c1738905fc0:	mov    r8d,0x0
    7c1738905fc6:	lea    r9,[r12+0x314]
    7c1738905fce:	movabs r11,0x59b8d02e51b0
    7c1738905fd8:	call   r11
    7c1738905fdb:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738905fe1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738905fe7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738905fed:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738905ff5:	mov    QWORD PTR [r12+0x378],0x2
    7c1738906001:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c173890600a:	pushf
    7c173890600b:	pop    rdx
    7c173890600c:	and    rdx,0xfffffffffffff73e
    7c1738906013:	mov    rax,rbx
    7c1738906016:	shr    rax,0x18
    7c173890601a:	and    eax,0xc0
    7c173890601f:	or     rdx,rax
    7c1738906022:	mov    rax,rbx
    7c1738906025:	shr    rax,0x1d
    7c1738906029:	and    eax,0x1
    7c173890602c:	xor    eax,0x1
    7c173890602f:	or     rdx,rax
    7c1738906032:	mov    rax,rbx
    7c1738906035:	shr    rax,0x11
    7c1738906039:	and    eax,0x800
    7c173890603e:	or     rdx,rax
    7c1738906041:	mov    QWORD PTR [rsp+0x10],rdx
    7c1738906046:	stmxcsr DWORD PTR [rsp+0x120]
    7c173890604e:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738906059:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738906061:	add    rsp,0x8
    7c1738906065:	ret
    7c1738906066:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738906070:	sub    rsp,0x8
    7c1738906074:	stmxcsr DWORD PTR [rsp+0x124]
    7c173890607c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738906084:	mov    r11d,DWORD PTR [rsp+0x124]
    7c173890608c:	shr    r11d,1
    7c173890608f:	and    r11d,0x10
    7c1738906093:	or     DWORD PTR [r12+0x314],r11d
    7c173890609b:	mov    QWORD PTR [r12+0x378],0x3
    7c17389060a7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c17389060ad:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c17389060b3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c17389060b9:	push   rdx
    7c17389060ba:	push   rsi
    7c17389060bb:	push   r10
    7c17389060bd:	push   r11
    7c17389060bf:	mov    rdx,QWORD PTR [rsp+0x30]
    7c17389060c4:	mov    r10d,edx
    7c17389060c7:	and    r10d,0xc0
    7c17389060ce:	shl    r10d,0x18
    7c17389060d2:	mov    r11d,edx
    7c17389060d5:	and    r11d,0x1
    7c17389060d9:	shl    r11d,0x1d
    7c17389060dd:	or     r10d,r11d
    7c17389060e0:	mov    r11d,edx
    7c17389060e3:	and    r11d,0x800
    7c17389060ea:	shl    r11d,0x11
    7c17389060ee:	or     r10d,r11d
    7c17389060f1:	btc    r10,0x1d
    7c17389060f6:	mov    r11d,0xf0000000
    7c17389060fc:	and    r11,r10
    7c17389060ff:	movabs rsi,0xffffffff0fffffff
    7c1738906109:	and    rbx,rsi
    7c173890610c:	or     rbx,r11
    7c173890610f:	pop    r11
    7c1738906111:	pop    r10
    7c1738906113:	pop    rsi
    7c1738906114:	pop    rdx
    7c1738906115:	mov    QWORD PTR [r12+0x108],rbx
    7c173890611d:	stmxcsr DWORD PTR [r12-0x28]
    7c1738906123:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738906129:	lea    rdi,[rsp+0x110]
    7c1738906131:	lea    rsi,[rsp+0xf0]
    7c1738906139:	lea    rdx,[rsp+0x100]
    7c1738906141:	mov    ecx,0x14
    7c1738906146:	mov    r8d,0x0
    7c173890614c:	lea    r9,[r12+0x314]
    7c1738906154:	movabs r11,0x59b8d02e51b0
    7c173890615e:	call   r11
    7c1738906161:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738906167:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c173890616d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738906173:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c1738906179:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738906181:	mov    QWORD PTR [r12+0x378],0x2
    7c173890618d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738906196:	pushf
    7c1738906197:	pop    rdx
    7c1738906198:	and    rdx,0xfffffffffffff73e
    7c173890619f:	mov    rax,rbx
    7c17389061a2:	shr    rax,0x18
    7c17389061a6:	and    eax,0xc0
    7c17389061ab:	or     rdx,rax
    7c17389061ae:	mov    rax,rbx
    7c17389061b1:	shr    rax,0x1d
    7c17389061b5:	and    eax,0x1
    7c17389061b8:	xor    eax,0x1
    7c17389061bb:	or     rdx,rax
    7c17389061be:	mov    rax,rbx
    7c17389061c1:	shr    rax,0x11
    7c17389061c5:	and    eax,0x800
    7c17389061ca:	or     rdx,rax
    7c17389061cd:	mov    QWORD PTR [rsp+0x10],rdx
    7c17389061d2:	stmxcsr DWORD PTR [rsp+0x120]
    7c17389061da:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c17389061e5:	ldmxcsr DWORD PTR [rsp+0x124]
    7c17389061ed:	add    rsp,0x8
    7c17389061f1:	ret
    7c17389061f2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738906200:	sub    rsp,0x8
    7c1738906204:	stmxcsr DWORD PTR [rsp+0x124]
    7c173890620c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738906214:	mov    r11d,DWORD PTR [rsp+0x124]
    7c173890621c:	shr    r11d,1
    7c173890621f:	and    r11d,0x10
    7c1738906223:	or     DWORD PTR [r12+0x314],r11d
    7c173890622b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738906237:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c173890623d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738906243:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c1738906249:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c173890624f:	push   rdx
    7c1738906250:	push   rsi
    7c1738906251:	push   r10
    7c1738906253:	push   r11
    7c1738906255:	mov    rdx,QWORD PTR [rsp+0x30]
    7c173890625a:	mov    r10d,edx
    7c173890625d:	and    r10d,0xc0
    7c1738906264:	shl    r10d,0x18
    7c1738906268:	mov    r11d,edx
    7c173890626b:	and    r11d,0x1
    7c173890626f:	shl    r11d,0x1d
    7c1738906273:	or     r10d,r11d
    7c1738906276:	mov    r11d,edx
    7c1738906279:	and    r11d,0x800
    7c1738906280:	shl    r11d,0x11
    7c1738906284:	or     r10d,r11d
    7c1738906287:	btc    r10,0x1d
    7c173890628c:	mov    r11d,0xf0000000
    7c1738906292:	and    r11,r10
    7c1738906295:	movabs rsi,0xffffffff0fffffff
    7c173890629f:	and    rbx,rsi
    7c17389062a2:	or     rbx,r11
    7c17389062a5:	pop    r11
    7c17389062a7:	pop    r10
    7c17389062a9:	pop    rsi
    7c17389062aa:	pop    rdx
    7c17389062ab:	mov    QWORD PTR [r12+0x108],rbx
    7c17389062b3:	stmxcsr DWORD PTR [r12-0x28]
    7c17389062b9:	ldmxcsr DWORD PTR [r12-0x38]
    7c17389062bf:	lea    rdi,[rsp+0x110]
    7c17389062c7:	lea    rsi,[rsp+0xf0]
    7c17389062cf:	lea    rdx,[rsp+0x100]
    7c17389062d7:	mov    ecx,0x14
    7c17389062dc:	mov    r8d,0x0
    7c17389062e2:	lea    r9,[r12+0x314]
    7c17389062ea:	movabs r11,0x59b8d02e51b0
    7c17389062f4:	call   r11
    7c17389062f7:	ldmxcsr DWORD PTR [r12-0x28]
    7c17389062fd:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738906303:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738906309:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c173890630f:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c1738906315:	mov    rbx,QWORD PTR [r12+0x108]
    7c173890631d:	mov    QWORD PTR [r12+0x378],0x2
    7c1738906329:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738906332:	pushf
    7c1738906333:	pop    rdx
    7c1738906334:	and    rdx,0xfffffffffffff73e
    7c173890633b:	mov    rax,rbx
    7c173890633e:	shr    rax,0x18
    7c1738906342:	and    eax,0xc0
    7c1738906347:	or     rdx,rax
    7c173890634a:	mov    rax,rbx
    7c173890634d:	shr    rax,0x1d
    7c1738906351:	and    eax,0x1
    7c1738906354:	xor    eax,0x1
    7c1738906357:	or     rdx,rax
    7c173890635a:	mov    rax,rbx
    7c173890635d:	shr    rax,0x11
    7c1738906361:	and    eax,0x800
    7c1738906366:	or     rdx,rax
    7c1738906369:	mov    QWORD PTR [rsp+0x10],rdx
    7c173890636e:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738906376:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738906381:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738906389:	add    rsp,0x8
    7c173890638d:	ret
    7c173890638e:	xchg   ax,ax
    7c1738906390:	sub    rsp,0x8
    7c1738906394:	stmxcsr DWORD PTR [rsp+0x124]
    7c173890639c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c17389063a4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c17389063ac:	shr    r11d,1
    7c17389063af:	and    r11d,0x10
    7c17389063b3:	or     DWORD PTR [r12+0x314],r11d
    7c17389063bb:	mov    QWORD PTR [r12+0x378],0x3
    7c17389063c7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c17389063cd:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c17389063d3:	push   rdx
    7c17389063d4:	push   rsi
    7c17389063d5:	push   r10
    7c17389063d7:	push   r11
    7c17389063d9:	mov    rdx,QWORD PTR [rsp+0x30]
    7c17389063de:	mov    r10d,edx
    7c17389063e1:	and    r10d,0xc0
    7c17389063e8:	shl    r10d,0x18
    7c17389063ec:	mov    r11d,edx
    7c17389063ef:	and    r11d,0x1
    7c17389063f3:	shl    r11d,0x1d
    7c17389063f7:	or     r10d,r11d
    7c17389063fa:	mov    r11d,edx
    7c17389063fd:	and    r11d,0x800
    7c1738906404:	shl    r11d,0x11
    7c1738906408:	or     r10d,r11d
    7c173890640b:	btc    r10,0x1d
    7c1738906410:	mov    r11d,0xf0000000
    7c1738906416:	and    r11,r10
    7c1738906419:	movabs rsi,0xffffffff0fffffff
    7c1738906423:	and    rbx,rsi
    7c1738906426:	or     rbx,r11
    7c1738906429:	pop    r11
    7c173890642b:	pop    r10
    7c173890642d:	pop    rsi
    7c173890642e:	pop    rdx
    7c173890642f:	mov    QWORD PTR [r12+0x108],rbx
    7c1738906437:	stmxcsr DWORD PTR [r12-0x28]
    7c173890643d:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738906443:	lea    rdi,[rsp+0x110]
    7c173890644b:	lea    rsi,[rsp+0xf0]
    7c1738906453:	lea    rdx,[rsp+0x100]
    7c173890645b:	mov    ecx,0x56
    7c1738906460:	mov    r8d,0x0
    7c1738906466:	lea    r9,[r12+0x314]
    7c173890646e:	movabs r11,0x59b8d02e51b0
    7c1738906478:	call   r11
    7c173890647b:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738906481:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738906487:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c173890648d:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738906495:	mov    QWORD PTR [r12+0x378],0x2
    7c17389064a1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c17389064aa:	pushf
    7c17389064ab:	pop    rdx
    7c17389064ac:	and    rdx,0xfffffffffffff73e
    7c17389064b3:	mov    rax,rbx
    7c17389064b6:	shr    rax,0x18
    7c17389064ba:	and    eax,0xc0
    7c17389064bf:	or     rdx,rax
    7c17389064c2:	mov    rax,rbx
    7c17389064c5:	shr    rax,0x1d
    7c17389064c9:	and    eax,0x1
    7c17389064cc:	xor    eax,0x1
    7c17389064cf:	or     rdx,rax
    7c17389064d2:	mov    rax,rbx
    7c17389064d5:	shr    rax,0x11
    7c17389064d9:	and    eax,0x800
    7c17389064de:	or     rdx,rax
    7c17389064e1:	mov    QWORD PTR [rsp+0x10],rdx
    7c17389064e6:	stmxcsr DWORD PTR [rsp+0x120]
    7c17389064ee:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c17389064f9:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738906501:	add    rsp,0x8
    7c1738906505:	ret
    7c1738906506:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738906510:	sub    rsp,0x8
    7c1738906514:	stmxcsr DWORD PTR [rsp+0x124]
    7c173890651c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738906524:	mov    r11d,DWORD PTR [rsp+0x124]
    7c173890652c:	shr    r11d,1
    7c173890652f:	and    r11d,0x10
    7c1738906533:	or     DWORD PTR [r12+0x314],r11d
    7c173890653b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738906547:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c173890654d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738906553:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c1738906559:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c173890655f:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c1738906565:	push   rdx
    7c1738906566:	push   rsi
    7c1738906567:	push   r10
    7c1738906569:	push   r11
    7c173890656b:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738906570:	mov    r10d,edx
    7c1738906573:	and    r10d,0xc0
    7c173890657a:	shl    r10d,0x18
    7c173890657e:	mov    r11d,edx
    7c1738906581:	and    r11d,0x1
    7c1738906585:	shl    r11d,0x1d
    7c1738906589:	or     r10d,r11d
    7c173890658c:	mov    r11d,edx
    7c173890658f:	and    r11d,0x800
    7c1738906596:	shl    r11d,0x11
    7c173890659a:	or     r10d,r11d
    7c173890659d:	btc    r10,0x1d
    7c17389065a2:	mov    r11d,0xf0000000
    7c17389065a8:	and    r11,r10
    7c17389065ab:	movabs rsi,0xffffffff0fffffff
    7c17389065b5:	and    rbx,rsi
    7c17389065b8:	or     rbx,r11
    7c17389065bb:	pop    r11
    7c17389065bd:	pop    r10
    7c17389065bf:	pop    rsi
    7c17389065c0:	pop    rdx
    7c17389065c1:	mov    QWORD PTR [r12+0x108],rbx
    7c17389065c9:	stmxcsr DWORD PTR [r12-0x28]
    7c17389065cf:	ldmxcsr DWORD PTR [r12-0x38]
    7c17389065d5:	lea    rdi,[rsp+0x110]
    7c17389065dd:	lea    rsi,[rsp+0xf0]
    7c17389065e5:	lea    rdx,[rsp+0x100]
    7c17389065ed:	mov    ecx,0x14
    7c17389065f2:	mov    r8d,0x0
    7c17389065f8:	lea    r9,[r12+0x314]
    7c1738906600:	movabs r11,0x59b8d02e51b0
    7c173890660a:	call   r11
    7c173890660d:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738906613:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738906619:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c173890661f:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c1738906625:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c173890662b:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c1738906631:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738906639:	mov    QWORD PTR [r12+0x378],0x2
    7c1738906645:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c173890664e:	pushf
    7c173890664f:	pop    rdx
    7c1738906650:	and    rdx,0xfffffffffffff73e
    7c1738906657:	mov    rax,rbx
    7c173890665a:	shr    rax,0x18
    7c173890665e:	and    eax,0xc0
    7c1738906663:	or     rdx,rax
    7c1738906666:	mov    rax,rbx
    7c1738906669:	shr    rax,0x1d
    7c173890666d:	and    eax,0x1
    7c1738906670:	xor    eax,0x1
    7c1738906673:	or     rdx,rax
    7c1738906676:	mov    rax,rbx
    7c1738906679:	shr    rax,0x11
    7c173890667d:	and    eax,0x800
    7c1738906682:	or     rdx,rax
    7c1738906685:	mov    QWORD PTR [rsp+0x10],rdx
    7c173890668a:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738906692:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c173890669d:	ldmxcsr DWORD PTR [rsp+0x124]
    7c17389066a5:	add    rsp,0x8
    7c17389066a9:	ret
    7c17389066aa:	nop    WORD PTR [rax+rax*1+0x0]
    7c17389066b0:	sub    rsp,0x8
    7c17389066b4:	stmxcsr DWORD PTR [rsp+0x124]
    7c17389066bc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c17389066c4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c17389066cc:	shr    r11d,1
    7c17389066cf:	and    r11d,0x10
    7c17389066d3:	or     DWORD PTR [r12+0x314],r11d
    7c17389066db:	mov    QWORD PTR [r12+0x378],0x3
    7c17389066e7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c17389066ed:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c17389066f3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c17389066f9:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c17389066ff:	push   rdx
    7c1738906700:	push   rsi
    7c1738906701:	push   r10
    7c1738906703:	push   r11
    7c1738906705:	mov    rdx,QWORD PTR [rsp+0x30]
    7c173890670a:	mov    r10d,edx
    7c173890670d:	and    r10d,0xc0
    7c1738906714:	shl    r10d,0x18
    7c1738906718:	mov    r11d,edx
    7c173890671b:	and    r11d,0x1
    7c173890671f:	shl    r11d,0x1d
    7c1738906723:	or     r10d,r11d
    7c1738906726:	mov    r11d,edx
    7c1738906729:	and    r11d,0x800
    7c1738906730:	shl    r11d,0x11
    7c1738906734:	or     r10d,r11d
    7c1738906737:	btc    r10,0x1d
    7c173890673c:	mov    r11d,0xf0000000
    7c1738906742:	and    r11,r10
    7c1738906745:	movabs rsi,0xffffffff0fffffff
    7c173890674f:	and    rbx,rsi
    7c1738906752:	or     rbx,r11
    7c1738906755:	pop    r11
    7c1738906757:	pop    r10
    7c1738906759:	pop    rsi
    7c173890675a:	pop    rdx
    7c173890675b:	mov    QWORD PTR [r12+0x108],rbx
    7c1738906763:	stmxcsr DWORD PTR [r12-0x28]
    7c1738906769:	ldmxcsr DWORD PTR [r12-0x38]
    7c173890676f:	lea    rdi,[rsp+0x110]
    7c1738906777:	lea    rsi,[rsp+0xf0]
    7c173890677f:	lea    rdx,[rsp+0x100]
    7c1738906787:	mov    ecx,0x56
    7c173890678c:	mov    r8d,0x0
    7c1738906792:	lea    r9,[r12+0x314]
    7c173890679a:	movabs r11,0x59b8d02e51b0
    7c17389067a4:	call   r11
    7c17389067a7:	ldmxcsr DWORD PTR [r12-0x28]
    7c17389067ad:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c17389067b3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c17389067b9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c17389067bf:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c17389067c5:	mov    rbx,QWORD PTR [r12+0x108]
    7c17389067cd:	mov    QWORD PTR [r12+0x378],0x2
    7c17389067d9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c17389067e2:	pushf
    7c17389067e3:	pop    rdx
    7c17389067e4:	and    rdx,0xfffffffffffff73e
    7c17389067eb:	mov    rax,rbx
    7c17389067ee:	shr    rax,0x18
    7c17389067f2:	and    eax,0xc0
    7c17389067f7:	or     rdx,rax
    7c17389067fa:	mov    rax,rbx
    7c17389067fd:	shr    rax,0x1d
    7c1738906801:	and    eax,0x1
    7c1738906804:	xor    eax,0x1
    7c1738906807:	or     rdx,rax
    7c173890680a:	mov    rax,rbx
    7c173890680d:	shr    rax,0x11
    7c1738906811:	and    eax,0x800
    7c1738906816:	or     rdx,rax
    7c1738906819:	mov    QWORD PTR [rsp+0x10],rdx
    7c173890681e:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738906826:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738906831:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738906839:	add    rsp,0x8
    7c173890683d:	ret
    7c173890683e:	xchg   ax,ax
    7c1738906840:	sub    rsp,0x8
    7c1738906844:	stmxcsr DWORD PTR [rsp+0x124]
    7c173890684c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738906854:	mov    r11d,DWORD PTR [rsp+0x124]
    7c173890685c:	shr    r11d,1
    7c173890685f:	and    r11d,0x10
    7c1738906863:	or     DWORD PTR [r12+0x314],r11d
    7c173890686b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738906877:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c173890687d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738906883:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c1738906889:	push   rdx
    7c173890688a:	push   rsi
    7c173890688b:	push   r10
    7c173890688d:	push   r11
    7c173890688f:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738906894:	mov    r10d,edx
    7c1738906897:	and    r10d,0xc0
    7c173890689e:	shl    r10d,0x18
    7c17389068a2:	mov    r11d,edx
    7c17389068a5:	and    r11d,0x1
    7c17389068a9:	shl    r11d,0x1d
    7c17389068ad:	or     r10d,r11d
    7c17389068b0:	mov    r11d,edx
    7c17389068b3:	and    r11d,0x800
    7c17389068ba:	shl    r11d,0x11
    7c17389068be:	or     r10d,r11d
    7c17389068c1:	btc    r10,0x1d
    7c17389068c6:	mov    r11d,0xf0000000
    7c17389068cc:	and    r11,r10
    7c17389068cf:	movabs rsi,0xffffffff0fffffff
    7c17389068d9:	and    rbx,rsi
    7c17389068dc:	or     rbx,r11
    7c17389068df:	pop    r11
    7c17389068e1:	pop    r10
    7c17389068e3:	pop    rsi
    7c17389068e4:	pop    rdx
    7c17389068e5:	mov    QWORD PTR [r12+0x108],rbx
    7c17389068ed:	stmxcsr DWORD PTR [r12-0x28]
    7c17389068f3:	ldmxcsr DWORD PTR [r12-0x38]
    7c17389068f9:	lea    rdi,[rsp+0x110]
    7c1738906901:	lea    rsi,[rsp+0xf0]
    7c1738906909:	lea    rdx,[rsp+0x100]
    7c1738906911:	mov    ecx,0x56
    7c1738906916:	mov    r8d,0x0
    7c173890691c:	lea    r9,[r12+0x314]
    7c1738906924:	movabs r11,0x59b8d02e51b0
    7c173890692e:	call   r11
    7c1738906931:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738906937:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c173890693d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738906943:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c1738906949:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738906951:	mov    QWORD PTR [r12+0x378],0x2
    7c173890695d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738906966:	pushf
    7c1738906967:	pop    rdx
    7c1738906968:	and    rdx,0xfffffffffffff73e
    7c173890696f:	mov    rax,rbx
    7c1738906972:	shr    rax,0x18
    7c1738906976:	and    eax,0xc0
    7c173890697b:	or     rdx,rax
    7c173890697e:	mov    rax,rbx
    7c1738906981:	shr    rax,0x1d
    7c1738906985:	and    eax,0x1
    7c1738906988:	xor    eax,0x1
    7c173890698b:	or     rdx,rax
    7c173890698e:	mov    rax,rbx
    7c1738906991:	shr    rax,0x11
    7c1738906995:	and    eax,0x800
    7c173890699a:	or     rdx,rax
    7c173890699d:	mov    QWORD PTR [rsp+0x10],rdx
    7c17389069a2:	stmxcsr DWORD PTR [rsp+0x120]
    7c17389069aa:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c17389069b5:	ldmxcsr DWORD PTR [rsp+0x124]
    7c17389069bd:	add    rsp,0x8
    7c17389069c1:	ret
    7c17389069c2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c17389069d0:	sub    rsp,0x8
    7c17389069d4:	stmxcsr DWORD PTR [rsp+0x124]
    7c17389069dc:	ldmxcsr DWORD PTR [rsp+0x120]
    7c17389069e4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c17389069ec:	shr    r11d,1
    7c17389069ef:	and    r11d,0x10
    7c17389069f3:	or     DWORD PTR [r12+0x314],r11d
    7c17389069fb:	mov    QWORD PTR [r12+0x378],0x3
    7c1738906a07:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c1738906a0d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738906a13:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c1738906a19:	push   rdx
    7c1738906a1a:	push   rsi
    7c1738906a1b:	push   r10
    7c1738906a1d:	push   r11
    7c1738906a1f:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738906a24:	mov    r10d,edx
    7c1738906a27:	and    r10d,0xc0
    7c1738906a2e:	shl    r10d,0x18
    7c1738906a32:	mov    r11d,edx
    7c1738906a35:	and    r11d,0x1
    7c1738906a39:	shl    r11d,0x1d
    7c1738906a3d:	or     r10d,r11d
    7c1738906a40:	mov    r11d,edx
    7c1738906a43:	and    r11d,0x800
    7c1738906a4a:	shl    r11d,0x11
    7c1738906a4e:	or     r10d,r11d
    7c1738906a51:	btc    r10,0x1d
    7c1738906a56:	mov    r11d,0xf0000000
    7c1738906a5c:	and    r11,r10
    7c1738906a5f:	movabs rsi,0xffffffff0fffffff
    7c1738906a69:	and    rbx,rsi
    7c1738906a6c:	or     rbx,r11
    7c1738906a6f:	pop    r11
    7c1738906a71:	pop    r10
    7c1738906a73:	pop    rsi
    7c1738906a74:	pop    rdx
    7c1738906a75:	mov    QWORD PTR [r12+0x108],rbx
    7c1738906a7d:	stmxcsr DWORD PTR [r12-0x28]
    7c1738906a83:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738906a89:	lea    rdi,[rsp+0x110]
    7c1738906a91:	lea    rsi,[rsp+0xf0]
    7c1738906a99:	lea    rdx,[rsp+0x100]
    7c1738906aa1:	mov    ecx,0x14
    7c1738906aa6:	mov    r8d,0x0
    7c1738906aac:	lea    r9,[r12+0x314]
    7c1738906ab4:	movabs r11,0x59b8d02e51b0
    7c1738906abe:	call   r11
    7c1738906ac1:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738906ac7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738906acd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738906ad3:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c1738906ad9:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738906ae1:	mov    QWORD PTR [r12+0x378],0x2
    7c1738906aed:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738906af6:	pushf
    7c1738906af7:	pop    rdx
    7c1738906af8:	and    rdx,0xfffffffffffff73e
    7c1738906aff:	mov    rax,rbx
    7c1738906b02:	shr    rax,0x18
    7c1738906b06:	and    eax,0xc0
    7c1738906b0b:	or     rdx,rax
    7c1738906b0e:	mov    rax,rbx
    7c1738906b11:	shr    rax,0x1d
    7c1738906b15:	and    eax,0x1
    7c1738906b18:	xor    eax,0x1
    7c1738906b1b:	or     rdx,rax
    7c1738906b1e:	mov    rax,rbx
    7c1738906b21:	shr    rax,0x11
    7c1738906b25:	and    eax,0x800
    7c1738906b2a:	or     rdx,rax
    7c1738906b2d:	mov    QWORD PTR [rsp+0x10],rdx
    7c1738906b32:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738906b3a:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738906b45:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738906b4d:	add    rsp,0x8
    7c1738906b51:	ret
    7c1738906b52:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738906b60:	sub    rsp,0x8
    7c1738906b64:	stmxcsr DWORD PTR [rsp+0x124]
    7c1738906b6c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738906b74:	mov    r11d,DWORD PTR [rsp+0x124]
    7c1738906b7c:	shr    r11d,1
    7c1738906b7f:	and    r11d,0x10
    7c1738906b83:	or     DWORD PTR [r12+0x314],r11d
    7c1738906b8b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738906b97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c1738906b9d:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c1738906ba3:	push   rdx
    7c1738906ba4:	push   rsi
    7c1738906ba5:	push   r10
    7c1738906ba7:	push   r11
    7c1738906ba9:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738906bae:	mov    r10d,edx
    7c1738906bb1:	and    r10d,0xc0
    7c1738906bb8:	shl    r10d,0x18
    7c1738906bbc:	mov    r11d,edx
    7c1738906bbf:	and    r11d,0x1
    7c1738906bc3:	shl    r11d,0x1d
    7c1738906bc7:	or     r10d,r11d
    7c1738906bca:	mov    r11d,edx
    7c1738906bcd:	and    r11d,0x800
    7c1738906bd4:	shl    r11d,0x11
    7c1738906bd8:	or     r10d,r11d
    7c1738906bdb:	btc    r10,0x1d
    7c1738906be0:	mov    r11d,0xf0000000
    7c1738906be6:	and    r11,r10
    7c1738906be9:	movabs rsi,0xffffffff0fffffff
    7c1738906bf3:	and    rbx,rsi
    7c1738906bf6:	or     rbx,r11
    7c1738906bf9:	pop    r11
    7c1738906bfb:	pop    r10
    7c1738906bfd:	pop    rsi
    7c1738906bfe:	pop    rdx
    7c1738906bff:	mov    QWORD PTR [r12+0x108],rbx
    7c1738906c07:	stmxcsr DWORD PTR [r12-0x28]
    7c1738906c0d:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738906c13:	lea    rdi,[rsp+0x110]
    7c1738906c1b:	lea    rsi,[rsp+0xf0]
    7c1738906c23:	lea    rdx,[rsp+0x100]
    7c1738906c2b:	mov    ecx,0x14
    7c1738906c30:	mov    r8d,0x0
    7c1738906c36:	lea    r9,[r12+0x314]
    7c1738906c3e:	movabs r11,0x59b8d02e51b0
    7c1738906c48:	call   r11
    7c1738906c4b:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738906c51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738906c57:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c1738906c5d:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738906c65:	mov    QWORD PTR [r12+0x378],0x2
    7c1738906c71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738906c7a:	pushf
    7c1738906c7b:	pop    rdx
    7c1738906c7c:	and    rdx,0xfffffffffffff73e
    7c1738906c83:	mov    rax,rbx
    7c1738906c86:	shr    rax,0x18
    7c1738906c8a:	and    eax,0xc0
    7c1738906c8f:	or     rdx,rax
    7c1738906c92:	mov    rax,rbx
    7c1738906c95:	shr    rax,0x1d
    7c1738906c99:	and    eax,0x1
    7c1738906c9c:	xor    eax,0x1
    7c1738906c9f:	or     rdx,rax
    7c1738906ca2:	mov    rax,rbx
    7c1738906ca5:	shr    rax,0x11
    7c1738906ca9:	and    eax,0x800
    7c1738906cae:	or     rdx,rax
    7c1738906cb1:	mov    QWORD PTR [rsp+0x10],rdx
    7c1738906cb6:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738906cbe:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738906cc9:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738906cd1:	add    rsp,0x8
    7c1738906cd5:	ret
    7c1738906cd6:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738906ce0:	sub    rsp,0x8
    7c1738906ce4:	stmxcsr DWORD PTR [rsp+0x124]
    7c1738906cec:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738906cf4:	mov    r11d,DWORD PTR [rsp+0x124]
    7c1738906cfc:	shr    r11d,1
    7c1738906cff:	and    r11d,0x10
    7c1738906d03:	or     DWORD PTR [r12+0x314],r11d
    7c1738906d0b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738906d17:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c1738906d1d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c1738906d23:	push   rdx
    7c1738906d24:	push   rsi
    7c1738906d25:	push   r10
    7c1738906d27:	push   r11
    7c1738906d29:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738906d2e:	mov    r10d,edx
    7c1738906d31:	and    r10d,0xc0
    7c1738906d38:	shl    r10d,0x18
    7c1738906d3c:	mov    r11d,edx
    7c1738906d3f:	and    r11d,0x1
    7c1738906d43:	shl    r11d,0x1d
    7c1738906d47:	or     r10d,r11d
    7c1738906d4a:	mov    r11d,edx
    7c1738906d4d:	and    r11d,0x800
    7c1738906d54:	shl    r11d,0x11
    7c1738906d58:	or     r10d,r11d
    7c1738906d5b:	btc    r10,0x1d
    7c1738906d60:	mov    r11d,0xf0000000
    7c1738906d66:	and    r11,r10
    7c1738906d69:	movabs rsi,0xffffffff0fffffff
    7c1738906d73:	and    rbx,rsi
    7c1738906d76:	or     rbx,r11
    7c1738906d79:	pop    r11
    7c1738906d7b:	pop    r10
    7c1738906d7d:	pop    rsi
    7c1738906d7e:	pop    rdx
    7c1738906d7f:	mov    QWORD PTR [r12+0x108],rbx
    7c1738906d87:	stmxcsr DWORD PTR [r12-0x28]
    7c1738906d8d:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738906d93:	lea    rdi,[rsp+0x110]
    7c1738906d9b:	lea    rsi,[rsp+0xf0]
    7c1738906da3:	lea    rdx,[rsp+0x100]
    7c1738906dab:	mov    ecx,0xc
    7c1738906db0:	mov    r8d,0x0
    7c1738906db6:	lea    r9,[r12+0x314]
    7c1738906dbe:	movabs r11,0x59b8d02e51b0
    7c1738906dc8:	call   r11
    7c1738906dcb:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738906dd1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738906dd7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c1738906ddd:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738906de5:	mov    QWORD PTR [r12+0x378],0x2
    7c1738906df1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738906dfa:	pushf
    7c1738906dfb:	pop    rdx
    7c1738906dfc:	and    rdx,0xfffffffffffff73e
    7c1738906e03:	mov    rax,rbx
    7c1738906e06:	shr    rax,0x18
    7c1738906e0a:	and    eax,0xc0
    7c1738906e0f:	or     rdx,rax
    7c1738906e12:	mov    rax,rbx
    7c1738906e15:	shr    rax,0x1d
    7c1738906e19:	and    eax,0x1
    7c1738906e1c:	xor    eax,0x1
    7c1738906e1f:	or     rdx,rax
    7c1738906e22:	mov    rax,rbx
    7c1738906e25:	shr    rax,0x11
    7c1738906e29:	and    eax,0x800
    7c1738906e2e:	or     rdx,rax
    7c1738906e31:	mov    QWORD PTR [rsp+0x10],rdx
    7c1738906e36:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738906e3e:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738906e49:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738906e51:	add    rsp,0x8
    7c1738906e55:	ret
    7c1738906e56:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738906e60:	sub    rsp,0x8
    7c1738906e64:	stmxcsr DWORD PTR [rsp+0x124]
    7c1738906e6c:	ldmxcsr DWORD PTR [rsp+0x120]
    7c1738906e74:	mov    r11d,DWORD PTR [rsp+0x124]
    7c1738906e7c:	shr    r11d,1
    7c1738906e7f:	and    r11d,0x10
    7c1738906e83:	or     DWORD PTR [r12+0x314],r11d
    7c1738906e8b:	mov    QWORD PTR [r12+0x378],0x3
    7c1738906e97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c1738906e9d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c1738906ea3:	push   rdx
    7c1738906ea4:	push   rsi
    7c1738906ea5:	push   r10
    7c1738906ea7:	push   r11
    7c1738906ea9:	mov    rdx,QWORD PTR [rsp+0x30]
    7c1738906eae:	mov    r10d,edx
    7c1738906eb1:	and    r10d,0xc0
    7c1738906eb8:	shl    r10d,0x18
    7c1738906ebc:	mov    r11d,edx
    7c1738906ebf:	and    r11d,0x1
    7c1738906ec3:	shl    r11d,0x1d
    7c1738906ec7:	or     r10d,r11d
    7c1738906eca:	mov    r11d,edx
    7c1738906ecd:	and    r11d,0x800
    7c1738906ed4:	shl    r11d,0x11
    7c1738906ed8:	or     r10d,r11d
    7c1738906edb:	btc    r10,0x1d
    7c1738906ee0:	mov    r11d,0xf0000000
    7c1738906ee6:	and    r11,r10
    7c1738906ee9:	movabs rsi,0xffffffff0fffffff
    7c1738906ef3:	and    rbx,rsi
    7c1738906ef6:	or     rbx,r11
    7c1738906ef9:	pop    r11
    7c1738906efb:	pop    r10
    7c1738906efd:	pop    rsi
    7c1738906efe:	pop    rdx
    7c1738906eff:	mov    QWORD PTR [r12+0x108],rbx
    7c1738906f07:	stmxcsr DWORD PTR [r12-0x28]
    7c1738906f0d:	ldmxcsr DWORD PTR [r12-0x38]
    7c1738906f13:	lea    rdi,[rsp+0x110]
    7c1738906f1b:	lea    rsi,[rsp+0xf0]
    7c1738906f23:	lea    rdx,[rsp+0x100]
    7c1738906f2b:	mov    ecx,0xc
    7c1738906f30:	mov    r8d,0x0
    7c1738906f36:	lea    r9,[r12+0x314]
    7c1738906f3e:	movabs r11,0x59b8d02e51b0
    7c1738906f48:	call   r11
    7c1738906f4b:	ldmxcsr DWORD PTR [r12-0x28]
    7c1738906f51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c1738906f57:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c1738906f5d:	mov    rbx,QWORD PTR [r12+0x108]
    7c1738906f65:	mov    QWORD PTR [r12+0x378],0x2
    7c1738906f71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c1738906f7a:	pushf
    7c1738906f7b:	pop    rdx
    7c1738906f7c:	and    rdx,0xfffffffffffff73e
    7c1738906f83:	mov    rax,rbx
    7c1738906f86:	shr    rax,0x18
    7c1738906f8a:	and    eax,0xc0
    7c1738906f8f:	or     rdx,rax
    7c1738906f92:	mov    rax,rbx
    7c1738906f95:	shr    rax,0x1d
    7c1738906f99:	and    eax,0x1
    7c1738906f9c:	xor    eax,0x1
    7c1738906f9f:	or     rdx,rax
    7c1738906fa2:	mov    rax,rbx
    7c1738906fa5:	shr    rax,0x11
    7c1738906fa9:	and    eax,0x800
    7c1738906fae:	or     rdx,rax
    7c1738906fb1:	mov    QWORD PTR [rsp+0x10],rdx
    7c1738906fb6:	stmxcsr DWORD PTR [rsp+0x120]
    7c1738906fbe:	mov    DWORD PTR [rsp+0x124],0x1f80
    7c1738906fc9:	ldmxcsr DWORD PTR [rsp+0x124]
    7c1738906fd1:	add    rsp,0x8
    7c1738906fd5:	ret
    7c1738906fd6:	mov    eax,0x4101e8
    7c1738906fdb:	mov    QWORD PTR [r12+0x100],rax
    7c1738906fe3:	push   rdx
    7c1738906fe4:	push   rsi
    7c1738906fe5:	push   r10
    7c1738906fe7:	push   r11
    7c1738906fe9:	pushf
    7c1738906fea:	pop    r11
    7c1738906fec:	mov    QWORD PTR [rsp+0x20],r11
    7c1738906ff1:	mov    rdx,QWORD PTR [rsp+0x20]
    7c1738906ff6:	mov    r10d,edx
    7c1738906ff9:	and    r10d,0xc0
    7c1738907000:	shl    r10d,0x18
    7c1738907004:	mov    r11d,edx
    7c1738907007:	and    r11d,0x1
    7c173890700b:	shl    r11d,0x1d
    7c173890700f:	or     r10d,r11d
    7c1738907012:	mov    r11d,edx
    7c1738907015:	and    r11d,0x800
    7c173890701c:	shl    r11d,0x11
    7c1738907020:	or     r10d,r11d
    7c1738907023:	btc    r10,0x1d
    7c1738907028:	mov    r11d,0xf0000000
    7c173890702e:	and    r11,r10
    7c1738907031:	movabs rsi,0xffffffff0fffffff
    7c173890703b:	and    rbx,rsi
    7c173890703e:	or     rbx,r11
    7c1738907041:	pop    r11
    7c1738907043:	pop    r10
    7c1738907045:	pop    rsi
    7c1738907046:	pop    rdx
    7c1738907047:	mov    QWORD PTR [r12+0x108],rbx
    7c173890704f:	add    rsp,0x150
    7c1738907056:	mov    eax,0xc
    7c173890705b:	movabs r11,0x59b8d047a390
    7c1738907065:	jmp    r11
    7c1738907068:	mov    eax,0x410440
    7c173890706d:	mov    QWORD PTR [r12+0x100],rax
    7c1738907075:	push   rdx
    7c1738907076:	push   rsi
    7c1738907077:	push   r10
    7c1738907079:	push   r11
    7c173890707b:	mov    rdx,QWORD PTR [rsp+0x20]
    7c1738907080:	mov    r10d,edx
    7c1738907083:	and    r10d,0xc0
    7c173890708a:	shl    r10d,0x18
    7c173890708e:	mov    r11d,edx
    7c1738907091:	and    r11d,0x1
    7c1738907095:	shl    r11d,0x1d
    7c1738907099:	or     r10d,r11d
    7c173890709c:	mov    r11d,edx
    7c173890709f:	and    r11d,0x800
    7c17389070a6:	shl    r11d,0x11
    7c17389070aa:	or     r10d,r11d
    7c17389070ad:	btc    r10,0x1d
    7c17389070b2:	mov    r11d,0xf0000000
    7c17389070b8:	and    r11,r10
    7c17389070bb:	movabs rsi,0xffffffff0fffffff
    7c17389070c5:	and    rbx,rsi
    7c17389070c8:	or     rbx,r11
    7c17389070cb:	pop    r11
    7c17389070cd:	pop    r10
    7c17389070cf:	pop    rsi
    7c17389070d0:	pop    rdx
    7c17389070d1:	mov    QWORD PTR [r12+0x108],rbx
    7c17389070d9:	add    rsp,0x150
    7c17389070e0:	mov    eax,0xc
    7c17389070e5:	movabs r11,0x59b8d047a390
    7c17389070ef:	jmp    r11
    7c17389070f2:	mov    eax,0x41044c
    7c17389070f7:	mov    QWORD PTR [r12+0x100],rax
    7c17389070ff:	push   rdx
    7c1738907100:	push   rsi
    7c1738907101:	push   r10
    7c1738907103:	push   r11
    7c1738907105:	pushf
    7c1738907106:	pop    r11
    7c1738907108:	mov    QWORD PTR [rsp+0x20],r11
    7c173890710d:	mov    rdx,QWORD PTR [rsp+0x20]
    7c1738907112:	mov    r10d,edx
    7c1738907115:	and    r10d,0xc0
    7c173890711c:	shl    r10d,0x18
    7c1738907120:	mov    r11d,edx
    7c1738907123:	and    r11d,0x1
    7c1738907127:	shl    r11d,0x1d
    7c173890712b:	or     r10d,r11d
    7c173890712e:	mov    r11d,edx
    7c1738907131:	and    r11d,0x800
    7c1738907138:	shl    r11d,0x11
    7c173890713c:	or     r10d,r11d
    7c173890713f:	btc    r10,0x1d
    7c1738907144:	mov    r11d,0xf0000000
    7c173890714a:	and    r11,r10
    7c173890714d:	movabs rsi,0xffffffff0fffffff
    7c1738907157:	and    rbx,rsi
    7c173890715a:	or     rbx,r11
    7c173890715d:	pop    r11
    7c173890715f:	pop    r10
    7c1738907161:	pop    rsi
    7c1738907162:	pop    rdx
    7c1738907163:	mov    QWORD PTR [r12+0x108],rbx
    7c173890716b:	add    rsp,0x150
    7c1738907172:	mov    eax,0xc
    7c1738907177:	movabs r11,0x59b8d047a390
    7c1738907181:	jmp    r11
    7c1738907184:	mov    eax,0x41048c
    7c1738907189:	mov    QWORD PTR [r12+0x100],rax
    7c1738907191:	push   rdx
    7c1738907192:	push   rsi
    7c1738907193:	push   r10
    7c1738907195:	push   r11
    7c1738907197:	mov    rdx,QWORD PTR [rsp+0x20]
    7c173890719c:	mov    r10d,edx
    7c173890719f:	and    r10d,0xc0
    7c17389071a6:	shl    r10d,0x18
    7c17389071aa:	mov    r11d,edx
    7c17389071ad:	and    r11d,0x1
    7c17389071b1:	shl    r11d,0x1d
    7c17389071b5:	or     r10d,r11d
    7c17389071b8:	mov    r11d,edx
    7c17389071bb:	and    r11d,0x800
    7c17389071c2:	shl    r11d,0x11
    7c17389071c6:	or     r10d,r11d
    7c17389071c9:	btc    r10,0x1d
    7c17389071ce:	mov    r11d,0xf0000000
    7c17389071d4:	and    r11,r10
    7c17389071d7:	movabs rsi,0xffffffff0fffffff
    7c17389071e1:	and    rbx,rsi
    7c17389071e4:	or     rbx,r11
    7c17389071e7:	pop    r11
    7c17389071e9:	pop    r10
    7c17389071eb:	pop    rsi
    7c17389071ec:	pop    rdx
    7c17389071ed:	mov    QWORD PTR [r12+0x108],rbx
    7c17389071f5:	add    rsp,0x150
    7c17389071fc:	mov    eax,0xc
    7c1738907201:	movabs r11,0x59b8d047a390
    7c173890720b:	jmp    r11
    7c173890720e:	mov    eax,0x410494
    7c1738907213:	mov    QWORD PTR [r12+0x100],rax
    7c173890721b:	push   rdx
    7c173890721c:	push   rsi
    7c173890721d:	push   r10
    7c173890721f:	push   r11
    7c1738907221:	mov    rdx,QWORD PTR [rsp+0x20]
    7c1738907226:	mov    r10d,edx
    7c1738907229:	and    r10d,0xc0
    7c1738907230:	shl    r10d,0x18
    7c1738907234:	mov    r11d,edx
    7c1738907237:	and    r11d,0x1
    7c173890723b:	shl    r11d,0x1d
    7c173890723f:	or     r10d,r11d
    7c1738907242:	mov    r11d,edx
    7c1738907245:	and    r11d,0x800
    7c173890724c:	shl    r11d,0x11
    7c1738907250:	or     r10d,r11d
    7c1738907253:	btc    r10,0x1d
    7c1738907258:	mov    r11d,0xf0000000
    7c173890725e:	and    r11,r10
    7c1738907261:	movabs rsi,0xffffffff0fffffff
    7c173890726b:	and    rbx,rsi
    7c173890726e:	or     rbx,r11
    7c1738907271:	pop    r11
    7c1738907273:	pop    r10
    7c1738907275:	pop    rsi
    7c1738907276:	pop    rdx
    7c1738907277:	mov    QWORD PTR [r12+0x108],rbx
    7c173890727f:	add    rsp,0x150
    7c1738907286:	mov    eax,0xc
    7c173890728b:	movabs r11,0x59b8d047a390
    7c1738907295:	jmp    r11
    7c1738907298:	nop    DWORD PTR [rax+rax*1+0x0]
    7c17389072a0:	sub    rsp,0x150
    7c17389072a7:	mov    r11,QWORD PTR [r12+0x398]
    7c17389072af:	mov    QWORD PTR [rsp],r11
    7c17389072b3:	cmp    DWORD PTR [r12+0x310],0x0
    7c17389072bc:	je     0x7c173890734c
    7c17389072c2:	push   rdx
    7c17389072c3:	push   rsi
    7c17389072c4:	push   r10
    7c17389072c6:	push   r11
    7c17389072c8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c17389072cd:	mov    r10d,edx
    7c17389072d0:	and    r10d,0xc0
    7c17389072d7:	shl    r10d,0x18
    7c17389072db:	mov    r11d,edx
    7c17389072de:	and    r11d,0x1
    7c17389072e2:	shl    r11d,0x1d
    7c17389072e6:	or     r10d,r11d
    7c17389072e9:	mov    r11d,edx
    7c17389072ec:	and    r11d,0x800
    7c17389072f3:	shl    r11d,0x11
    7c17389072f7:	or     r10d,r11d
    7c17389072fa:	btc    r10,0x1d
    7c17389072ff:	mov    r11d,0xf0000000
    7c1738907305:	and    r11,r10
    7c1738907308:	movabs rsi,0xffffffff0fffffff
    7c1738907312:	and    rbx,rsi
    7c1738907315:	or     rbx,r11
    7c1738907318:	pop    r11
    7c173890731a:	pop    r10
    7c173890731c:	pop    rsi
    7c173890731d:	pop    rdx
    7c173890731e:	mov    QWORD PTR [r12+0x108],rbx
    7c1738907326:	mov    eax,0x4101ac
    7c173890732b:	mov    QWORD PTR [r12+0x100],rax
    7c1738907333:	add    rsp,0x150
    7c173890733a:	mov    eax,0x3
    7c173890733f:	movabs r11,0x59b8d047a390
    7c1738907349:	jmp    r11
    7c173890734c:	jmp    0x7c17389001fd
    7c1738907351:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738907360:	sub    rsp,0x150
    7c1738907367:	mov    r11,QWORD PTR [r12+0x398]
    7c173890736f:	mov    QWORD PTR [rsp],r11
    7c1738907373:	cmp    DWORD PTR [r12+0x310],0x0
    7c173890737c:	je     0x7c173890740c
    7c1738907382:	push   rdx
    7c1738907383:	push   rsi
    7c1738907384:	push   r10
    7c1738907386:	push   r11
    7c1738907388:	mov    rdx,QWORD PTR [rsp+0x20]
    7c173890738d:	mov    r10d,edx
    7c1738907390:	and    r10d,0xc0
    7c1738907397:	shl    r10d,0x18
    7c173890739b:	mov    r11d,edx
    7c173890739e:	and    r11d,0x1
    7c17389073a2:	shl    r11d,0x1d
    7c17389073a6:	or     r10d,r11d
    7c17389073a9:	mov    r11d,edx
    7c17389073ac:	and    r11d,0x800
    7c17389073b3:	shl    r11d,0x11
    7c17389073b7:	or     r10d,r11d
    7c17389073ba:	btc    r10,0x1d
    7c17389073bf:	mov    r11d,0xf0000000
    7c17389073c5:	and    r11,r10
    7c17389073c8:	movabs rsi,0xffffffff0fffffff
    7c17389073d2:	and    rbx,rsi
    7c17389073d5:	or     rbx,r11
    7c17389073d8:	pop    r11
    7c17389073da:	pop    r10
    7c17389073dc:	pop    rsi
    7c17389073dd:	pop    rdx
    7c17389073de:	mov    QWORD PTR [r12+0x108],rbx
    7c17389073e6:	mov    eax,0x4101ec
    7c17389073eb:	mov    QWORD PTR [r12+0x100],rax
    7c17389073f3:	add    rsp,0x150
    7c17389073fa:	mov    eax,0x3
    7c17389073ff:	movabs r11,0x59b8d047a390
    7c1738907409:	jmp    r11
    7c173890740c:	jmp    0x7c1738900773
    7c1738907411:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738907420:	sub    rsp,0x150
    7c1738907427:	mov    r11,QWORD PTR [r12+0x398]
    7c173890742f:	mov    QWORD PTR [rsp],r11
    7c1738907433:	cmp    DWORD PTR [r12+0x310],0x0
    7c173890743c:	je     0x7c17389074cc
    7c1738907442:	push   rdx
    7c1738907443:	push   rsi
    7c1738907444:	push   r10
    7c1738907446:	push   r11
    7c1738907448:	mov    rdx,QWORD PTR [rsp+0x20]
    7c173890744d:	mov    r10d,edx
    7c1738907450:	and    r10d,0xc0
    7c1738907457:	shl    r10d,0x18
    7c173890745b:	mov    r11d,edx
    7c173890745e:	and    r11d,0x1
    7c1738907462:	shl    r11d,0x1d
    7c1738907466:	or     r10d,r11d
    7c1738907469:	mov    r11d,edx
    7c173890746c:	and    r11d,0x800
    7c1738907473:	shl    r11d,0x11
    7c1738907477:	or     r10d,r11d
    7c173890747a:	btc    r10,0x1d
    7c173890747f:	mov    r11d,0xf0000000
    7c1738907485:	and    r11,r10
    7c1738907488:	movabs rsi,0xffffffff0fffffff
    7c1738907492:	and    rbx,rsi
    7c1738907495:	or     rbx,r11
    7c1738907498:	pop    r11
    7c173890749a:	pop    r10
    7c173890749c:	pop    rsi
    7c173890749d:	pop    rdx
    7c173890749e:	mov    QWORD PTR [r12+0x108],rbx
    7c17389074a6:	mov    eax,0x410274
    7c17389074ab:	mov    QWORD PTR [r12+0x100],rax
    7c17389074b3:	add    rsp,0x150
    7c17389074ba:	mov    eax,0x3
    7c17389074bf:	movabs r11,0x59b8d047a390
    7c17389074c9:	jmp    r11
    7c17389074cc:	jmp    0x7c1738900ec8
    7c17389074d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c17389074e0:	sub    rsp,0x150
    7c17389074e7:	mov    r11,QWORD PTR [r12+0x398]
    7c17389074ef:	mov    QWORD PTR [rsp],r11
    7c17389074f3:	cmp    DWORD PTR [r12+0x310],0x0
    7c17389074fc:	je     0x7c173890758c
    7c1738907502:	push   rdx
    7c1738907503:	push   rsi
    7c1738907504:	push   r10
    7c1738907506:	push   r11
    7c1738907508:	mov    rdx,QWORD PTR [rsp+0x20]
    7c173890750d:	mov    r10d,edx
    7c1738907510:	and    r10d,0xc0
    7c1738907517:	shl    r10d,0x18
    7c173890751b:	mov    r11d,edx
    7c173890751e:	and    r11d,0x1
    7c1738907522:	shl    r11d,0x1d
    7c1738907526:	or     r10d,r11d
    7c1738907529:	mov    r11d,edx
    7c173890752c:	and    r11d,0x800
    7c1738907533:	shl    r11d,0x11
    7c1738907537:	or     r10d,r11d
    7c173890753a:	btc    r10,0x1d
    7c173890753f:	mov    r11d,0xf0000000
    7c1738907545:	and    r11,r10
    7c1738907548:	movabs rsi,0xffffffff0fffffff
    7c1738907552:	and    rbx,rsi
    7c1738907555:	or     rbx,r11
    7c1738907558:	pop    r11
    7c173890755a:	pop    r10
    7c173890755c:	pop    rsi
    7c173890755d:	pop    rdx
    7c173890755e:	mov    QWORD PTR [r12+0x108],rbx
    7c1738907566:	mov    eax,0x410278
    7c173890756b:	mov    QWORD PTR [r12+0x100],rax
    7c1738907573:	add    rsp,0x150
    7c173890757a:	mov    eax,0x3
    7c173890757f:	movabs r11,0x59b8d047a390
    7c1738907589:	jmp    r11
    7c173890758c:	jmp    0x7c1738900ed8
    7c1738907591:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c17389075a0:	sub    rsp,0x150
    7c17389075a7:	mov    r11,QWORD PTR [r12+0x398]
    7c17389075af:	mov    QWORD PTR [rsp],r11
    7c17389075b3:	cmp    DWORD PTR [r12+0x310],0x0
    7c17389075bc:	je     0x7c173890764c
    7c17389075c2:	push   rdx
    7c17389075c3:	push   rsi
    7c17389075c4:	push   r10
    7c17389075c6:	push   r11
    7c17389075c8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c17389075cd:	mov    r10d,edx
    7c17389075d0:	and    r10d,0xc0
    7c17389075d7:	shl    r10d,0x18
    7c17389075db:	mov    r11d,edx
    7c17389075de:	and    r11d,0x1
    7c17389075e2:	shl    r11d,0x1d
    7c17389075e6:	or     r10d,r11d
    7c17389075e9:	mov    r11d,edx
    7c17389075ec:	and    r11d,0x800
    7c17389075f3:	shl    r11d,0x11
    7c17389075f7:	or     r10d,r11d
    7c17389075fa:	btc    r10,0x1d
    7c17389075ff:	mov    r11d,0xf0000000
    7c1738907605:	and    r11,r10
    7c1738907608:	movabs rsi,0xffffffff0fffffff
    7c1738907612:	and    rbx,rsi
    7c1738907615:	or     rbx,r11
    7c1738907618:	pop    r11
    7c173890761a:	pop    r10
    7c173890761c:	pop    rsi
    7c173890761d:	pop    rdx
    7c173890761e:	mov    QWORD PTR [r12+0x108],rbx
    7c1738907626:	mov    eax,0x410444
    7c173890762b:	mov    QWORD PTR [r12+0x100],rax
    7c1738907633:	add    rsp,0x150
    7c173890763a:	mov    eax,0x3
    7c173890763f:	movabs r11,0x59b8d047a390
    7c1738907649:	jmp    r11
    7c173890764c:	jmp    0x7c1738904a9d
    7c1738907651:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738907660:	sub    rsp,0x150
    7c1738907667:	mov    r11,QWORD PTR [r12+0x398]
    7c173890766f:	mov    QWORD PTR [rsp],r11
    7c1738907673:	cmp    DWORD PTR [r12+0x310],0x0
    7c173890767c:	je     0x7c173890770c
    7c1738907682:	push   rdx
    7c1738907683:	push   rsi
    7c1738907684:	push   r10
    7c1738907686:	push   r11
    7c1738907688:	mov    rdx,QWORD PTR [rsp+0x20]
    7c173890768d:	mov    r10d,edx
    7c1738907690:	and    r10d,0xc0
    7c1738907697:	shl    r10d,0x18
    7c173890769b:	mov    r11d,edx
    7c173890769e:	and    r11d,0x1
    7c17389076a2:	shl    r11d,0x1d
    7c17389076a6:	or     r10d,r11d
    7c17389076a9:	mov    r11d,edx
    7c17389076ac:	and    r11d,0x800
    7c17389076b3:	shl    r11d,0x11
    7c17389076b7:	or     r10d,r11d
    7c17389076ba:	btc    r10,0x1d
    7c17389076bf:	mov    r11d,0xf0000000
    7c17389076c5:	and    r11,r10
    7c17389076c8:	movabs rsi,0xffffffff0fffffff
    7c17389076d2:	and    rbx,rsi
    7c17389076d5:	or     rbx,r11
    7c17389076d8:	pop    r11
    7c17389076da:	pop    r10
    7c17389076dc:	pop    rsi
    7c17389076dd:	pop    rdx
    7c17389076de:	mov    QWORD PTR [r12+0x108],rbx
    7c17389076e6:	mov    eax,0x410450
    7c17389076eb:	mov    QWORD PTR [r12+0x100],rax
    7c17389076f3:	add    rsp,0x150
    7c17389076fa:	mov    eax,0x3
    7c17389076ff:	movabs r11,0x59b8d047a390
    7c1738907709:	jmp    r11
    7c173890770c:	jmp    0x7c1738904ad3
    7c1738907711:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c1738907720:	sub    rsp,0x150
    7c1738907727:	mov    r11,QWORD PTR [r12+0x398]
    7c173890772f:	mov    QWORD PTR [rsp],r11
    7c1738907733:	cmp    DWORD PTR [r12+0x310],0x0
    7c173890773c:	je     0x7c17389077cc
    7c1738907742:	push   rdx
    7c1738907743:	push   rsi
    7c1738907744:	push   r10
    7c1738907746:	push   r11
    7c1738907748:	mov    rdx,QWORD PTR [rsp+0x20]
    7c173890774d:	mov    r10d,edx
    7c1738907750:	and    r10d,0xc0
    7c1738907757:	shl    r10d,0x18
    7c173890775b:	mov    r11d,edx
    7c173890775e:	and    r11d,0x1
    7c1738907762:	shl    r11d,0x1d
    7c1738907766:	or     r10d,r11d
    7c1738907769:	mov    r11d,edx
    7c173890776c:	and    r11d,0x800
    7c1738907773:	shl    r11d,0x11
    7c1738907777:	or     r10d,r11d
    7c173890777a:	btc    r10,0x1d
    7c173890777f:	mov    r11d,0xf0000000
    7c1738907785:	and    r11,r10
    7c1738907788:	movabs rsi,0xffffffff0fffffff
    7c1738907792:	and    rbx,rsi
    7c1738907795:	or     rbx,r11
    7c1738907798:	pop    r11
    7c173890779a:	pop    r10
    7c173890779c:	pop    rsi
    7c173890779d:	pop    rdx
    7c173890779e:	mov    QWORD PTR [r12+0x108],rbx
    7c17389077a6:	mov    eax,0x410474
    7c17389077ab:	mov    QWORD PTR [r12+0x100],rax
    7c17389077b3:	add    rsp,0x150
    7c17389077ba:	mov    eax,0x3
    7c17389077bf:	movabs r11,0x59b8d047a390
    7c17389077c9:	jmp    r11
    7c17389077cc:	jmp    0x7c1738904c52
    7c17389077d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c17389077e0:	sub    rsp,0x150
    7c17389077e7:	mov    r11,QWORD PTR [r12+0x398]
    7c17389077ef:	mov    QWORD PTR [rsp],r11
    7c17389077f3:	cmp    DWORD PTR [r12+0x310],0x0
    7c17389077fc:	je     0x7c173890788c
    7c1738907802:	push   rdx
    7c1738907803:	push   rsi
    7c1738907804:	push   r10
    7c1738907806:	push   r11
    7c1738907808:	mov    rdx,QWORD PTR [rsp+0x20]
    7c173890780d:	mov    r10d,edx
    7c1738907810:	and    r10d,0xc0
    7c1738907817:	shl    r10d,0x18
    7c173890781b:	mov    r11d,edx
    7c173890781e:	and    r11d,0x1
    7c1738907822:	shl    r11d,0x1d
    7c1738907826:	or     r10d,r11d
    7c1738907829:	mov    r11d,edx
    7c173890782c:	and    r11d,0x800
    7c1738907833:	shl    r11d,0x11
    7c1738907837:	or     r10d,r11d
    7c173890783a:	btc    r10,0x1d
    7c173890783f:	mov    r11d,0xf0000000
    7c1738907845:	and    r11,r10
    7c1738907848:	movabs rsi,0xffffffff0fffffff
    7c1738907852:	and    rbx,rsi
    7c1738907855:	or     rbx,r11
    7c1738907858:	pop    r11
    7c173890785a:	pop    r10
    7c173890785c:	pop    rsi
    7c173890785d:	pop    rdx
    7c173890785e:	mov    QWORD PTR [r12+0x108],rbx
    7c1738907866:	mov    eax,0x410490
    7c173890786b:	mov    QWORD PTR [r12+0x100],rax
    7c1738907873:	add    rsp,0x150
    7c173890787a:	mov    eax,0x3
    7c173890787f:	movabs r11,0x59b8d047a390
    7c1738907889:	jmp    r11
    7c173890788c:	jmp    0x7c1738904dea
    7c1738907891:	nop
    7c1738907892:	nop
    7c1738907893:	nop
