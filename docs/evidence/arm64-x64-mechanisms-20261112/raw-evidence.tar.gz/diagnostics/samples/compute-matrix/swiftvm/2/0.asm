
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/compute-matrix/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

000071e6bf300000 <.data>:
    71e6bf300000:	sub    rsp,0x150
    71e6bf300007:	mov    r11,QWORD PTR [r12+0x398]
    71e6bf30000f:	mov    QWORD PTR [rsp],r11
    71e6bf300013:	cmp    DWORD PTR [r12+0x310],0x0
    71e6bf30001c:	je     0x71e6bf3000ac
    71e6bf300022:	push   rdx
    71e6bf300023:	push   rsi
    71e6bf300024:	push   r10
    71e6bf300026:	push   r11
    71e6bf300028:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf30002d:	mov    r10d,edx
    71e6bf300030:	and    r10d,0xc0
    71e6bf300037:	shl    r10d,0x18
    71e6bf30003b:	mov    r11d,edx
    71e6bf30003e:	and    r11d,0x1
    71e6bf300042:	shl    r11d,0x1d
    71e6bf300046:	or     r10d,r11d
    71e6bf300049:	mov    r11d,edx
    71e6bf30004c:	and    r11d,0x800
    71e6bf300053:	shl    r11d,0x11
    71e6bf300057:	or     r10d,r11d
    71e6bf30005a:	btc    r10,0x1d
    71e6bf30005f:	mov    r11d,0xf0000000
    71e6bf300065:	and    r11,r10
    71e6bf300068:	movabs rsi,0xffffffff0fffffff
    71e6bf300072:	and    rbx,rsi
    71e6bf300075:	or     rbx,r11
    71e6bf300078:	pop    r11
    71e6bf30007a:	pop    r10
    71e6bf30007c:	pop    rsi
    71e6bf30007d:	pop    rdx
    71e6bf30007e:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf300086:	mov    eax,0x410168
    71e6bf30008b:	mov    QWORD PTR [r12+0x100],rax
    71e6bf300093:	add    rsp,0x150
    71e6bf30009a:	mov    eax,0x3
    71e6bf30009f:	movabs r11,0x5f73f3e93390
    71e6bf3000a9:	jmp    r11
    71e6bf3000ac:	mov    r13d,0x420000
    71e6bf3000b2:	mov    QWORD PTR [r12+0x40],r13
    71e6bf3000b7:	movabs r13,0x100000001
    71e6bf3000c1:	mov    r14d,0x0
    71e6bf3000c7:	mov    QWORD PTR [r12+0x110],r13
    71e6bf3000cf:	mov    QWORD PTR [r12+0x118],r14
    71e6bf3000d7:	movabs r13,0x3fa0000000000000
    71e6bf3000e1:	mov    QWORD PTR [r12+0x50],r13
    71e6bf3000e6:	movabs r13,0x4100000041
    71e6bf3000f0:	mov    r14d,0x0
    71e6bf3000f6:	mov    QWORD PTR [r12+0x120],r13
    71e6bf3000fe:	mov    QWORD PTR [r12+0x128],r14
    71e6bf300106:	mov    r13d,0x4204c0
    71e6bf30010c:	mov    r14,QWORD PTR [r13+0x0]
    71e6bf300110:	mov    r13d,0x0
    71e6bf300116:	mov    QWORD PTR [r12+0x130],r14
    71e6bf30011e:	mov    QWORD PTR [r12+0x138],r13
    71e6bf300126:	movabs r13,0x3fc0000000000000
    71e6bf300130:	movabs r14,0x3fc0000000000000
    71e6bf30013a:	mov    QWORD PTR [r12+0x140],r13
    71e6bf300142:	mov    QWORD PTR [r12+0x148],r14
    71e6bf30014a:	mov    r13d,0x2
    71e6bf300150:	mov    QWORD PTR [r12+0x40],r13
    71e6bf300155:	movabs r13,0x200000002
    71e6bf30015f:	mov    r14d,0x0
    71e6bf300165:	mov    QWORD PTR [r12+0x150],r13
    71e6bf30016d:	mov    QWORD PTR [r12+0x158],r14
    71e6bf300175:	mov    r13d,0x420000
    71e6bf30017b:	mov    QWORD PTR [r12+0x58],r13
    71e6bf300180:	mov    r13,QWORD PTR [r12+0x50]
    71e6bf300185:	and    r13,0xffffffffffffffff
    71e6bf300189:	mov    QWORD PTR [r12+0x160],r13
    71e6bf300191:	mov    QWORD PTR [r12+0x168],r13
    71e6bf300199:	mov    r13d,0x2
    71e6bf30019f:	mov    QWORD PTR [r12+0x170],r13
    71e6bf3001a7:	mov    QWORD PTR [r12+0x178],r13
    71e6bf3001af:	mov    r13d,0x4204d0
    71e6bf3001b5:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf3001bb:	movdqa xmm0,xmm2
    71e6bf3001bf:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf3001c9:	mov    r13d,0x0
    71e6bf3001cf:	mov    QWORD PTR [r12+0x48],r13
    71e6bf3001d4:	mov    r13d,0x430000
    71e6bf3001da:	add    r13,0x518
    71e6bf3001e1:	mov    QWORD PTR [r12+0x40],r13
    71e6bf3001e6:	mov    r13d,0x430000
    71e6bf3001ec:	add    r13,0x720
    71e6bf3001f3:	mov    QWORD PTR [r12+0x50],r13
    71e6bf3001f8:	jmp    0x71e6bf3001fd
    71e6bf3001fd:	mov    r13,QWORD PTR [r12+0x180]
    71e6bf300205:	mov    r14,QWORD PTR [r12+0x188]
    71e6bf30020d:	mov    r15d,0x0
    71e6bf300213:	and    r13,0xffffffffffffffff
    71e6bf300217:	mov    ecx,0xffffffff
    71e6bf30021c:	and    r13,rcx
    71e6bf30021f:	mov    rcx,r13
    71e6bf300222:	mov    rbp,r15
    71e6bf300225:	or     rbp,rcx
    71e6bf300228:	and    r14,0xffffffffffffffff
    71e6bf30022c:	mov    ecx,0xffffffff
    71e6bf300231:	and    r14,rcx
    71e6bf300234:	shl    r14,0x20
    71e6bf300238:	mov    rcx,r14
    71e6bf30023b:	or     rbp,rcx
    71e6bf30023e:	mov    QWORD PTR [r12+0x210],rbp
    71e6bf300246:	mov    QWORD PTR [r12+0x218],r15
    71e6bf30024e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    71e6bf300258:	movdqa xmm2,xmm0
    71e6bf30025c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    71e6bf300266:	movdqa xmm3,xmm0
    71e6bf30026a:	movdqa xmm1,xmm3
    71e6bf30026e:	psubd  xmm2,xmm1
    71e6bf300272:	movdqa xmm14,xmm2
    71e6bf300277:	movdqa xmm1,xmm14
    71e6bf30027c:	movq   rax,xmm1
    71e6bf300281:	mov    r13,rax
    71e6bf300284:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf30028e:	movdqa xmm2,xmm0
    71e6bf300292:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf30029c:	movdqa xmm4,xmm0
    71e6bf3002a0:	movdqa xmm1,xmm4
    71e6bf3002a4:	paddq  xmm2,xmm1
    71e6bf3002a8:	movdqa xmm0,xmm2
    71e6bf3002ac:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf3002b6:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    71e6bf3002c0:	movdqa xmm2,xmm0
    71e6bf3002c4:	movdqa xmm1,xmm2
    71e6bf3002c8:	paddd  xmm3,xmm1
    71e6bf3002cc:	movdqa xmm14,xmm3
    71e6bf3002d1:	movdqa xmm1,xmm14
    71e6bf3002d6:	movq   rax,xmm1
    71e6bf3002db:	mov    r14,rax
    71e6bf3002de:	mov    r15d,0x0
    71e6bf3002e4:	mov    QWORD PTR [r12+0x130],r14
    71e6bf3002ec:	mov    QWORD PTR [r12+0x138],r15
    71e6bf3002f4:	mov    r14d,0x0
    71e6bf3002fa:	mov    r15,r13
    71e6bf3002fd:	mov    ecx,0xffffffff
    71e6bf300302:	and    r15,rcx
    71e6bf300305:	and    r15,0xffffffffffffffff
    71e6bf300309:	mov    rcx,r15
    71e6bf30030c:	mov    rbp,r14
    71e6bf30030f:	or     rbp,rcx
    71e6bf300312:	shr    r13,0x20
    71e6bf300316:	mov    ecx,0xffffffff
    71e6bf30031b:	and    r13,rcx
    71e6bf30031e:	and    r13,0xffffffffffffffff
    71e6bf300322:	mov    rcx,r13
    71e6bf300325:	or     r14,rcx
    71e6bf300328:	mov    QWORD PTR [r12+0x220],rbp
    71e6bf300330:	mov    QWORD PTR [r12+0x228],r14
    71e6bf300338:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf300342:	movdqa xmm2,xmm0
    71e6bf300346:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf300350:	movdqa xmm3,xmm0
    71e6bf300354:	movdqa xmm1,xmm3
    71e6bf300358:	paddd  xmm2,xmm1
    71e6bf30035c:	movdqa xmm14,xmm2
    71e6bf300361:	movdqa xmm1,xmm14
    71e6bf300366:	movq   rax,xmm1
    71e6bf30036b:	mov    r13,rax
    71e6bf30036e:	mov    r14d,0x0
    71e6bf300374:	mov    QWORD PTR [r12+0x210],r13
    71e6bf30037c:	mov    QWORD PTR [r12+0x218],r14
    71e6bf300384:	lea    r13,[r12]
    71e6bf300388:	movabs r14,0xb6e61da31
    71e6bf300392:	mov    r15d,0x4101c4
    71e6bf300398:	mov    rdx,QWORD PTR [rsp]
    71e6bf30039c:	mov    r10d,edx
    71e6bf30039f:	and    r10d,0xc0
    71e6bf3003a6:	shl    r10d,0x18
    71e6bf3003aa:	mov    r11d,edx
    71e6bf3003ad:	and    r11d,0x1
    71e6bf3003b1:	shl    r11d,0x1d
    71e6bf3003b5:	or     r10d,r11d
    71e6bf3003b8:	mov    r11d,edx
    71e6bf3003bb:	and    r11d,0x800
    71e6bf3003c2:	shl    r11d,0x11
    71e6bf3003c6:	or     r10d,r11d
    71e6bf3003c9:	btc    r10,0x1d
    71e6bf3003ce:	mov    r11d,0xf0000000
    71e6bf3003d4:	and    r11,r10
    71e6bf3003d7:	movabs rsi,0xffffffff0fffffff
    71e6bf3003e1:	and    rbx,rsi
    71e6bf3003e4:	or     rbx,r11
    71e6bf3003e7:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf3003f3:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3003fb:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf300401:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf300407:	movabs r11,0x5f73f3cf9dc0
    71e6bf300411:	mov    rdi,r13
    71e6bf300414:	mov    rsi,r14
    71e6bf300417:	mov    rdx,r15
    71e6bf30041a:	call   r11
    71e6bf30041d:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf300423:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf30042b:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf300437:	mov    rbp,rax
    71e6bf30043a:	mov    r13,QWORD PTR [r12+0x210]
    71e6bf300442:	mov    r14d,0x0
    71e6bf300448:	mov    r15,r13
    71e6bf30044b:	mov    ecx,0xffffffff
    71e6bf300450:	and    r15,rcx
    71e6bf300453:	and    r15,0xffffffffffffffff
    71e6bf300457:	mov    rcx,r15
    71e6bf30045a:	mov    rbp,r14
    71e6bf30045d:	or     rbp,rcx
    71e6bf300460:	shr    r13,0x20
    71e6bf300464:	mov    ecx,0xffffffff
    71e6bf300469:	and    r13,rcx
    71e6bf30046c:	and    r13,0xffffffffffffffff
    71e6bf300470:	mov    rcx,r13
    71e6bf300473:	or     r14,rcx
    71e6bf300476:	mov    QWORD PTR [r12+0x210],rbp
    71e6bf30047e:	mov    QWORD PTR [r12+0x218],r14
    71e6bf300486:	lea    r13,[r12]
    71e6bf30048a:	movabs r14,0xb6e61da10
    71e6bf300494:	mov    r15d,0x4101cc
    71e6bf30049a:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf3004a6:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3004ae:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf3004b4:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf3004ba:	movabs r11,0x5f73f3cf9dc0
    71e6bf3004c4:	mov    rdi,r13
    71e6bf3004c7:	mov    rsi,r14
    71e6bf3004ca:	mov    rdx,r15
    71e6bf3004cd:	call   r11
    71e6bf3004d0:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf3004d6:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf3004de:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf3004ea:	mov    rbp,rax
    71e6bf3004ed:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf3004f7:	movdqa xmm2,xmm0
    71e6bf3004fb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    71e6bf300505:	movdqa xmm3,xmm0
    71e6bf300509:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf300511:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf30051c:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf300524:	movdqa xmm0,xmm2
    71e6bf300528:	movdqa xmm1,xmm3
    71e6bf30052c:	movq   rax,xmm0
    71e6bf300531:	add    rax,rax
    71e6bf300534:	je     0x71e6bf30054a
    71e6bf300536:	shr    rax,0x35
    71e6bf30053a:	sub    eax,0x201
    71e6bf30053f:	cmp    eax,0x3fc
    71e6bf300544:	ja     0x71e6bf304e57
    71e6bf30054a:	movdqa xmm14,xmm0
    71e6bf30054f:	psrldq xmm14,0x8
    71e6bf300555:	movq   rax,xmm14
    71e6bf30055a:	add    rax,rax
    71e6bf30055d:	je     0x71e6bf300573
    71e6bf30055f:	shr    rax,0x35
    71e6bf300563:	sub    eax,0x201
    71e6bf300568:	cmp    eax,0x3fc
    71e6bf30056d:	ja     0x71e6bf304e57
    71e6bf300573:	movq   rax,xmm1
    71e6bf300578:	add    rax,rax
    71e6bf30057b:	je     0x71e6bf300591
    71e6bf30057d:	shr    rax,0x35
    71e6bf300581:	sub    eax,0x201
    71e6bf300586:	cmp    eax,0x3fc
    71e6bf30058b:	ja     0x71e6bf304e57
    71e6bf300591:	movdqa xmm14,xmm1
    71e6bf300596:	psrldq xmm14,0x8
    71e6bf30059c:	movq   rax,xmm14
    71e6bf3005a1:	add    rax,rax
    71e6bf3005a4:	je     0x71e6bf3005ba
    71e6bf3005a6:	shr    rax,0x35
    71e6bf3005aa:	sub    eax,0x201
    71e6bf3005af:	cmp    eax,0x3fc
    71e6bf3005b4:	ja     0x71e6bf304e57
    71e6bf3005ba:	mulpd  xmm0,xmm1
    71e6bf3005be:	movdqa xmm4,xmm0
    71e6bf3005c2:	movdqa xmm0,xmm4
    71e6bf3005c6:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf3005d0:	mov    r13,QWORD PTR [r12+0x48]
    71e6bf3005d5:	mov    r14,QWORD PTR [r12+0x50]
    71e6bf3005da:	mov    rcx,r13
    71e6bf3005dd:	add    r14,rcx
    71e6bf3005e0:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf3005e8:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf3005f0:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf3005f8:	shr    r11d,1
    71e6bf3005fb:	and    r11d,0x10
    71e6bf3005ff:	or     DWORD PTR [r12+0x314],r11d
    71e6bf300607:	movdqu XMMWORD PTR [r14],xmm4
    71e6bf30060c:	mov    r14d,0x0
    71e6bf300612:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf30061a:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf300624:	movdqa xmm2,xmm0
    71e6bf300628:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    71e6bf300632:	movdqa xmm3,xmm0
    71e6bf300636:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf30063e:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf300649:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf300651:	movdqa xmm0,xmm2
    71e6bf300655:	movdqa xmm1,xmm3
    71e6bf300659:	movq   rax,xmm0
    71e6bf30065e:	add    rax,rax
    71e6bf300661:	je     0x71e6bf300677
    71e6bf300663:	shr    rax,0x35
    71e6bf300667:	sub    eax,0x201
    71e6bf30066c:	cmp    eax,0x3fc
    71e6bf300671:	ja     0x71e6bf304e7b
    71e6bf300677:	movdqa xmm14,xmm0
    71e6bf30067c:	psrldq xmm14,0x8
    71e6bf300682:	movq   rax,xmm14
    71e6bf300687:	add    rax,rax
    71e6bf30068a:	je     0x71e6bf3006a0
    71e6bf30068c:	shr    rax,0x35
    71e6bf300690:	sub    eax,0x201
    71e6bf300695:	cmp    eax,0x3fc
    71e6bf30069a:	ja     0x71e6bf304e7b
    71e6bf3006a0:	movq   rax,xmm1
    71e6bf3006a5:	add    rax,rax
    71e6bf3006a8:	je     0x71e6bf3006be
    71e6bf3006aa:	shr    rax,0x35
    71e6bf3006ae:	sub    eax,0x201
    71e6bf3006b3:	cmp    eax,0x3fc
    71e6bf3006b8:	ja     0x71e6bf304e7b
    71e6bf3006be:	movdqa xmm14,xmm1
    71e6bf3006c3:	psrldq xmm14,0x8
    71e6bf3006c9:	movq   rax,xmm14
    71e6bf3006ce:	add    rax,rax
    71e6bf3006d1:	je     0x71e6bf3006e7
    71e6bf3006d3:	shr    rax,0x35
    71e6bf3006d7:	sub    eax,0x201
    71e6bf3006dc:	cmp    eax,0x3fc
    71e6bf3006e1:	ja     0x71e6bf304e7b
    71e6bf3006e7:	mulpd  xmm0,xmm1
    71e6bf3006eb:	movdqa xmm4,xmm0
    71e6bf3006ef:	movdqa xmm0,xmm4
    71e6bf3006f3:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf3006fd:	mov    r14,QWORD PTR [r12+0x40]
    71e6bf300702:	mov    rcx,r13
    71e6bf300705:	add    r14,rcx
    71e6bf300708:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf300710:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf300718:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf300720:	shr    r11d,1
    71e6bf300723:	and    r11d,0x10
    71e6bf300727:	or     DWORD PTR [r12+0x314],r11d
    71e6bf30072f:	movdqu XMMWORD PTR [r14],xmm4
    71e6bf300734:	mov    r14d,0x0
    71e6bf30073a:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf300742:	add    r13,0x10
    71e6bf300746:	mov    QWORD PTR [r12+0x48],r13
    71e6bf30074b:	sub    r13,0x200
    71e6bf300752:	mov    rcx,QWORD PTR [r12+0x380]
    71e6bf30075a:	jrcxz  0x71e6bf300761
    71e6bf30075c:	jmp    0x71e6bf306fd6
    71e6bf300761:	pushf
    71e6bf300762:	pop    r11
    71e6bf300764:	mov    QWORD PTR [rsp],r11
    71e6bf300768:	jne    0x71e6bf3001fd
    71e6bf30076e:	jmp    0x71e6bf300773
    71e6bf300773:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf30077b:	sub    r13,0x150
    71e6bf300782:	mov    QWORD PTR [r12+0xf8],r13
    71e6bf30078a:	mov    r14,QWORD PTR [r12+0x50]
    71e6bf30078f:	mov    r15,r14
    71e6bf300792:	add    r15,0x80
    71e6bf300799:	mov    rbp,r15
    71e6bf30079c:	add    rbp,0x10
    71e6bf3007a0:	movdqu xmm2,XMMWORD PTR [r15]
    71e6bf3007a5:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    71e6bf3007aa:	movdqa xmm0,xmm2
    71e6bf3007ae:	movdqu XMMWORD PTR [r12+0x130],xmm0
    71e6bf3007b8:	movdqa xmm0,xmm3
    71e6bf3007bc:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf3007c6:	mov    r15d,0x0
    71e6bf3007cc:	mov    QWORD PTR [r12+0x48],r15
    71e6bf3007d1:	add    r14,0x40
    71e6bf3007d5:	mov    r15,r14
    71e6bf3007d8:	add    r15,0x10
    71e6bf3007dc:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf3007e1:	movdqu xmm3,XMMWORD PTR [r15]
    71e6bf3007e6:	movdqa xmm0,xmm2
    71e6bf3007ea:	movdqu XMMWORD PTR [r12+0x250],xmm0
    71e6bf3007f4:	movdqa xmm0,xmm3
    71e6bf3007f8:	movdqu XMMWORD PTR [r12+0x120],xmm0
    71e6bf300802:	add    r13,0x120
    71e6bf300809:	mov    r14,r13
    71e6bf30080c:	add    r14,0x8
    71e6bf300810:	mov    r15,QWORD PTR [r12+0x1c0]
    71e6bf300818:	mov    rbp,QWORD PTR [r12+0x1b0]
    71e6bf300820:	mov    QWORD PTR [r13+0x0],r15
    71e6bf300824:	mov    r13d,0x0
    71e6bf30082a:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300832:	mov    QWORD PTR [r14],rbp
    71e6bf300835:	mov    r13d,0x0
    71e6bf30083b:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300843:	mov    r13d,0x0
    71e6bf300849:	mov    r14d,0x0
    71e6bf30084f:	mov    QWORD PTR [r12+0x1b0],r13
    71e6bf300857:	mov    QWORD PTR [r12+0x1b8],r14
    71e6bf30085f:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf300867:	mov    r14,r13
    71e6bf30086a:	add    r14,0x100
    71e6bf300871:	mov    r15,r14
    71e6bf300874:	add    r15,0x8
    71e6bf300878:	mov    rbp,QWORD PTR [r12+0x200]
    71e6bf300880:	mov    r8,QWORD PTR [r12+0x1f0]
    71e6bf300888:	mov    QWORD PTR [r14],rbp
    71e6bf30088b:	mov    r14d,0x0
    71e6bf300891:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf300899:	mov    QWORD PTR [r15],r8
    71e6bf30089c:	mov    r14d,0x0
    71e6bf3008a2:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf3008aa:	mov    r14,r13
    71e6bf3008ad:	add    r14,0xe0
    71e6bf3008b4:	mov    r15,r14
    71e6bf3008b7:	add    r15,0x10
    71e6bf3008bb:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf3008c5:	movdqa xmm2,xmm0
    71e6bf3008c9:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    71e6bf3008d3:	movdqa xmm3,xmm0
    71e6bf3008d7:	movdqu XMMWORD PTR [r14],xmm2
    71e6bf3008dc:	mov    r14d,0x0
    71e6bf3008e2:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf3008ea:	movdqu XMMWORD PTR [r15],xmm3
    71e6bf3008ef:	mov    r14d,0x0
    71e6bf3008f5:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf3008fd:	mov    r14,QWORD PTR [r12+0x50]
    71e6bf300902:	mov    r15,r14
    71e6bf300905:	add    r15,0xc0
    71e6bf30090c:	mov    rbp,r15
    71e6bf30090f:	add    rbp,0x10
    71e6bf300913:	movdqu xmm2,XMMWORD PTR [r15]
    71e6bf300918:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    71e6bf30091d:	movdqa xmm0,xmm2
    71e6bf300921:	movdqu XMMWORD PTR [r12+0x130],xmm0
    71e6bf30092b:	movdqa xmm0,xmm3
    71e6bf30092f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf300939:	add    r13,0x110
    71e6bf300940:	mov    r15,r13
    71e6bf300943:	add    r15,0x8
    71e6bf300947:	mov    rbp,QWORD PTR [r12+0x1e0]
    71e6bf30094f:	mov    r8,QWORD PTR [r12+0x1d0]
    71e6bf300957:	mov    QWORD PTR [r13+0x0],rbp
    71e6bf30095b:	mov    r13d,0x0
    71e6bf300961:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300969:	mov    QWORD PTR [r15],r8
    71e6bf30096c:	mov    r13d,0x0
    71e6bf300972:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf30097a:	mov    r13,r14
    71e6bf30097d:	add    r13,0x10
    71e6bf300981:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf300986:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    71e6bf30098c:	movdqa xmm0,xmm2
    71e6bf300990:	movdqu XMMWORD PTR [r12+0x170],xmm0
    71e6bf30099a:	movdqa xmm0,xmm3
    71e6bf30099e:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf3009a8:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf3009b0:	mov    r14,r13
    71e6bf3009b3:	add    r14,0x130
    71e6bf3009ba:	mov    r15,r14
    71e6bf3009bd:	add    r15,0x8
    71e6bf3009c1:	mov    rbp,QWORD PTR [r12+0x1a0]
    71e6bf3009c9:	mov    r8,QWORD PTR [r12+0x190]
    71e6bf3009d1:	mov    QWORD PTR [r14],rbp
    71e6bf3009d4:	mov    r14d,0x0
    71e6bf3009da:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf3009e2:	mov    QWORD PTR [r15],r8
    71e6bf3009e5:	mov    r14d,0x0
    71e6bf3009eb:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf3009f3:	mov    r14,QWORD PTR [r12+0x50]
    71e6bf3009f8:	mov    r15,r14
    71e6bf3009fb:	add    r15,0x140
    71e6bf300a02:	mov    rbp,r15
    71e6bf300a05:	add    rbp,0x10
    71e6bf300a09:	movdqu xmm2,XMMWORD PTR [r15]
    71e6bf300a0e:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    71e6bf300a13:	movdqa xmm0,xmm2
    71e6bf300a17:	movdqu XMMWORD PTR [r12+0x270],xmm0
    71e6bf300a21:	movdqa xmm0,xmm3
    71e6bf300a25:	movdqu XMMWORD PTR [r12+0x190],xmm0
    71e6bf300a2f:	add    r13,0xc0
    71e6bf300a36:	mov    r15,r13
    71e6bf300a39:	add    r15,0x10
    71e6bf300a3d:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf300a47:	movdqa xmm2,xmm0
    71e6bf300a4b:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    71e6bf300a55:	movdqa xmm3,xmm0
    71e6bf300a59:	movdqu XMMWORD PTR [r13+0x0],xmm2
    71e6bf300a5f:	mov    r13d,0x0
    71e6bf300a65:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300a6d:	movdqu XMMWORD PTR [r15],xmm3
    71e6bf300a72:	mov    r13d,0x0
    71e6bf300a78:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300a80:	add    r14,0x100
    71e6bf300a87:	mov    r13,r14
    71e6bf300a8a:	add    r13,0x10
    71e6bf300a8e:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf300a93:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    71e6bf300a99:	movdqa xmm0,xmm2
    71e6bf300a9d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf300aa7:	movdqa xmm0,xmm3
    71e6bf300aab:	movdqu XMMWORD PTR [r12+0x300],xmm0
    71e6bf300ab5:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf300abd:	mov    r14,r13
    71e6bf300ac0:	add    r14,0x140
    71e6bf300ac7:	mov    r15,QWORD PTR [r12+0xe8]
    71e6bf300acf:	mov    QWORD PTR [r14],r15
    71e6bf300ad2:	mov    r14d,0x0
    71e6bf300ad8:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf300ae0:	mov    r14,QWORD PTR [r12+0x50]
    71e6bf300ae5:	mov    r15,r14
    71e6bf300ae8:	add    r15,0x180
    71e6bf300aef:	mov    rbp,r15
    71e6bf300af2:	add    rbp,0x10
    71e6bf300af6:	movdqu xmm2,XMMWORD PTR [r15]
    71e6bf300afb:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    71e6bf300b00:	movdqa xmm0,xmm2
    71e6bf300b04:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    71e6bf300b0e:	movdqa xmm0,xmm3
    71e6bf300b12:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    71e6bf300b1c:	mov    r15,r14
    71e6bf300b1f:	add    r15,0x1c0
    71e6bf300b26:	mov    rbp,r15
    71e6bf300b29:	add    rbp,0x10
    71e6bf300b2d:	movdqu xmm2,XMMWORD PTR [r15]
    71e6bf300b32:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    71e6bf300b37:	movdqa xmm0,xmm2
    71e6bf300b3b:	movdqu XMMWORD PTR [r12+0x240],xmm0
    71e6bf300b45:	movdqa xmm0,xmm3
    71e6bf300b49:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    71e6bf300b53:	add    r13,0x20
    71e6bf300b57:	mov    r15,r13
    71e6bf300b5a:	add    r15,0x10
    71e6bf300b5e:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf300b68:	movdqa xmm2,xmm0
    71e6bf300b6c:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    71e6bf300b76:	movdqa xmm3,xmm0
    71e6bf300b7a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    71e6bf300b80:	mov    r13d,0x0
    71e6bf300b86:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300b8e:	movdqu XMMWORD PTR [r15],xmm3
    71e6bf300b93:	mov    r13d,0x0
    71e6bf300b99:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300ba1:	mov    r13,r14
    71e6bf300ba4:	add    r13,0x60
    71e6bf300ba8:	mov    r15,r13
    71e6bf300bab:	add    r15,0x10
    71e6bf300baf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf300bb5:	movdqu xmm3,XMMWORD PTR [r15]
    71e6bf300bba:	movdqa xmm0,xmm2
    71e6bf300bbe:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf300bc8:	movdqa xmm0,xmm3
    71e6bf300bcc:	movdqu XMMWORD PTR [r12+0x120],xmm0
    71e6bf300bd6:	add    r14,0x20
    71e6bf300bda:	mov    r13,r14
    71e6bf300bdd:	add    r13,0x10
    71e6bf300be1:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf300be6:	movdqu xmm3,XMMWORD PTR [r13+0x0]
    71e6bf300bec:	movdqa xmm0,xmm2
    71e6bf300bf0:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    71e6bf300bfa:	movdqa xmm0,xmm3
    71e6bf300bfe:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
    71e6bf300c08:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf300c10:	mov    r14,r13
    71e6bf300c13:	add    r14,0x60
    71e6bf300c17:	mov    r15,r14
    71e6bf300c1a:	add    r15,0x10
    71e6bf300c1e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf300c28:	movdqa xmm2,xmm0
    71e6bf300c2c:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    71e6bf300c36:	movdqa xmm3,xmm0
    71e6bf300c3a:	movdqu XMMWORD PTR [r14],xmm2
    71e6bf300c3f:	mov    r14d,0x0
    71e6bf300c45:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf300c4d:	movdqu XMMWORD PTR [r15],xmm3
    71e6bf300c52:	mov    r14d,0x0
    71e6bf300c58:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf300c60:	mov    r14,QWORD PTR [r12+0x50]
    71e6bf300c65:	mov    r15,r14
    71e6bf300c68:	add    r15,0xe0
    71e6bf300c6f:	mov    rbp,r15
    71e6bf300c72:	add    rbp,0x10
    71e6bf300c76:	movdqu xmm2,XMMWORD PTR [r15]
    71e6bf300c7b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    71e6bf300c80:	movdqa xmm0,xmm2
    71e6bf300c84:	movdqu XMMWORD PTR [r12+0x200],xmm0
    71e6bf300c8e:	movdqa xmm0,xmm3
    71e6bf300c92:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    71e6bf300c9c:	add    r13,0xa0
    71e6bf300ca3:	mov    r15,r13
    71e6bf300ca6:	add    r15,0x10
    71e6bf300caa:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    71e6bf300cb4:	movdqa xmm2,xmm0
    71e6bf300cb8:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf300cc2:	movdqa xmm3,xmm0
    71e6bf300cc6:	movdqu XMMWORD PTR [r13+0x0],xmm2
    71e6bf300ccc:	mov    r13d,0x0
    71e6bf300cd2:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300cda:	movdqu XMMWORD PTR [r15],xmm3
    71e6bf300cdf:	mov    r13d,0x0
    71e6bf300ce5:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300ced:	mov    r13,r14
    71e6bf300cf0:	add    r13,0xa0
    71e6bf300cf7:	mov    r15,r13
    71e6bf300cfa:	add    r15,0x10
    71e6bf300cfe:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf300d04:	movdqu xmm3,XMMWORD PTR [r15]
    71e6bf300d09:	movdqa xmm0,xmm2
    71e6bf300d0d:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf300d17:	movdqa xmm0,xmm3
    71e6bf300d1b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    71e6bf300d25:	mov    r13,r14
    71e6bf300d28:	add    r13,0x120
    71e6bf300d2f:	mov    r15,r13
    71e6bf300d32:	add    r15,0x10
    71e6bf300d36:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    71e6bf300d3c:	movdqu xmm5,XMMWORD PTR [r15]
    71e6bf300d41:	movdqa xmm0,xmm4
    71e6bf300d45:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    71e6bf300d4f:	movdqa xmm0,xmm5
    71e6bf300d53:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    71e6bf300d5d:	add    r14,0x160
    71e6bf300d64:	mov    r13,r14
    71e6bf300d67:	add    r13,0x10
    71e6bf300d6b:	movdqu xmm4,XMMWORD PTR [r14]
    71e6bf300d70:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    71e6bf300d76:	movdqa xmm0,xmm4
    71e6bf300d7a:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    71e6bf300d84:	movdqa xmm0,xmm5
    71e6bf300d88:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
    71e6bf300d92:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf300d9a:	mov    r14,r13
    71e6bf300d9d:	add    r14,0x80
    71e6bf300da4:	mov    r15,r14
    71e6bf300da7:	add    r15,0x10
    71e6bf300dab:	movdqu XMMWORD PTR [r14],xmm3
    71e6bf300db0:	mov    r14d,0x0
    71e6bf300db6:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf300dbe:	movdqu XMMWORD PTR [r15],xmm2
    71e6bf300dc3:	mov    r14d,0x0
    71e6bf300dc9:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf300dd1:	mov    r14,QWORD PTR [r12+0x50]
    71e6bf300dd6:	mov    r15,r14
    71e6bf300dd9:	add    r15,0x1a0
    71e6bf300de0:	mov    rbp,r15
    71e6bf300de3:	add    rbp,0x10
    71e6bf300de7:	movdqu xmm2,XMMWORD PTR [r15]
    71e6bf300dec:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    71e6bf300df1:	movdqa xmm0,xmm2
    71e6bf300df5:	movdqu XMMWORD PTR [r12+0x290],xmm0
    71e6bf300dff:	movdqa xmm0,xmm3
    71e6bf300e03:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
    71e6bf300e0d:	add    r14,0x1e0
    71e6bf300e14:	mov    r15,r14
    71e6bf300e17:	add    r15,0x10
    71e6bf300e1b:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf300e20:	movdqu xmm3,XMMWORD PTR [r15]
    71e6bf300e25:	movdqa xmm0,xmm2
    71e6bf300e29:	movdqu XMMWORD PTR [r12+0x230],xmm0
    71e6bf300e33:	movdqa xmm0,xmm3
    71e6bf300e37:	movdqu XMMWORD PTR [r12+0x280],xmm0
    71e6bf300e41:	mov    r14d,0x430000
    71e6bf300e47:	add    r14,0x920
    71e6bf300e4e:	mov    QWORD PTR [r12+0x50],r14
    71e6bf300e53:	mov    r14,r13
    71e6bf300e56:	add    r14,0x40
    71e6bf300e5a:	mov    r15,r14
    71e6bf300e5d:	add    r15,0x10
    71e6bf300e61:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf300e6b:	movdqa xmm5,xmm0
    71e6bf300e6f:	movdqu XMMWORD PTR [r14],xmm4
    71e6bf300e74:	mov    r14d,0x0
    71e6bf300e7a:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf300e82:	movdqu XMMWORD PTR [r15],xmm5
    71e6bf300e87:	mov    r14d,0x0
    71e6bf300e8d:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf300e95:	mov    r14,r13
    71e6bf300e98:	add    r14,0x10
    71e6bf300e9c:	movdqu XMMWORD PTR [r13+0x0],xmm3
    71e6bf300ea2:	mov    r13d,0x0
    71e6bf300ea8:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300eb0:	movdqu XMMWORD PTR [r14],xmm2
    71e6bf300eb5:	mov    r13d,0x0
    71e6bf300ebb:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf300ec3:	jmp    0x71e6bf300ec8
    71e6bf300ec8:	mov    r13d,0x0
    71e6bf300ece:	mov    QWORD PTR [r12+0x58],r13
    71e6bf300ed3:	jmp    0x71e6bf300ed8
    71e6bf300ed8:	mov    r13,QWORD PTR [r12+0x58]
    71e6bf300edd:	mov    r14,QWORD PTR [r12+0x40]
    71e6bf300ee2:	mov    rcx,r13
    71e6bf300ee5:	add    r14,rcx
    71e6bf300ee8:	mov    QWORD PTR [r12+0x60],r14
    71e6bf300eed:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    71e6bf300ef7:	movdqa xmm2,xmm0
    71e6bf300efb:	movdqa xmm1,xmm2
    71e6bf300eff:	por    xmm2,xmm1
    71e6bf300f03:	movdqa xmm0,xmm2
    71e6bf300f07:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    71e6bf300f11:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    71e6bf300f1b:	movdqa xmm2,xmm0
    71e6bf300f1f:	movdqa xmm1,xmm2
    71e6bf300f23:	por    xmm2,xmm1
    71e6bf300f27:	movdqa xmm0,xmm2
    71e6bf300f2b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    71e6bf300f35:	add    r14,0x30
    71e6bf300f39:	mov    r13,r14
    71e6bf300f3c:	add    r13,0x8
    71e6bf300f40:	mov    r15,QWORD PTR [r14]
    71e6bf300f43:	mov    r14,QWORD PTR [r13+0x0]
    71e6bf300f47:	mov    r13d,0x0
    71e6bf300f4d:	mov    QWORD PTR [r12+0x130],r15
    71e6bf300f55:	mov    QWORD PTR [r12+0x138],r13
    71e6bf300f5d:	mov    r13d,0x0
    71e6bf300f63:	mov    QWORD PTR [r12+0x280],r14
    71e6bf300f6b:	mov    QWORD PTR [r12+0x288],r13
    71e6bf300f73:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    71e6bf300f7d:	movdqa xmm2,xmm0
    71e6bf300f81:	movdqa xmm1,xmm2
    71e6bf300f85:	por    xmm2,xmm1
    71e6bf300f89:	movdqa xmm0,xmm2
    71e6bf300f8d:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    71e6bf300f97:	mov    r13,QWORD PTR [r12+0x60]
    71e6bf300f9c:	mov    r14,r13
    71e6bf300f9f:	add    r14,0x20
    71e6bf300fa3:	mov    r15,r14
    71e6bf300fa6:	add    r15,0x8
    71e6bf300faa:	mov    rbp,QWORD PTR [r14]
    71e6bf300fad:	mov    r14,QWORD PTR [r15]
    71e6bf300fb0:	mov    r15d,0x0
    71e6bf300fb6:	mov    QWORD PTR [r12+0x150],rbp
    71e6bf300fbe:	mov    QWORD PTR [r12+0x158],r15
    71e6bf300fc6:	mov    r15d,0x0
    71e6bf300fcc:	mov    QWORD PTR [r12+0x140],r14
    71e6bf300fd4:	mov    QWORD PTR [r12+0x148],r15
    71e6bf300fdc:	add    r13,0x10
    71e6bf300fe0:	mov    r14,r13
    71e6bf300fe3:	add    r14,0x8
    71e6bf300fe7:	mov    r15,QWORD PTR [r13+0x0]
    71e6bf300feb:	mov    r13,QWORD PTR [r14]
    71e6bf300fee:	mov    r14d,0x0
    71e6bf300ff4:	mov    QWORD PTR [r12+0x170],r15
    71e6bf300ffc:	mov    QWORD PTR [r12+0x178],r14
    71e6bf301004:	mov    r14d,0x0
    71e6bf30100a:	mov    QWORD PTR [r12+0x160],r13
    71e6bf301012:	mov    QWORD PTR [r12+0x168],r14
    71e6bf30101a:	mov    r13,QWORD PTR [r12+0x60]
    71e6bf30101f:	mov    r14d,0x8
    71e6bf301025:	mov    r15,QWORD PTR [r13+0x0]
    71e6bf301029:	mov    QWORD PTR [r12+0x180],r15
    71e6bf301031:	mov    QWORD PTR [r12+0x188],r15
    71e6bf301039:	mov    rcx,r14
    71e6bf30103c:	add    r13,rcx
    71e6bf30103f:	mov    QWORD PTR [r12+0x60],r13
    71e6bf301044:	mov    r14,QWORD PTR [r13+0x0]
    71e6bf301048:	mov    r13d,0x0
    71e6bf30104e:	mov    QWORD PTR [r12+0x230],r14
    71e6bf301056:	mov    QWORD PTR [r12+0x238],r13
    71e6bf30105e:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf301066:	mov    r14,r13
    71e6bf301069:	add    r14,0x50
    71e6bf30106d:	mov    r15,r14
    71e6bf301070:	add    r15,0x10
    71e6bf301074:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf301079:	movdqu xmm3,XMMWORD PTR [r15]
    71e6bf30107e:	movdqa xmm0,xmm2
    71e6bf301082:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf30108c:	movdqa xmm0,xmm3
    71e6bf301090:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf30109a:	add    r13,0x30
    71e6bf30109e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf3010a4:	movdqa xmm0,xmm2
    71e6bf3010a8:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf3010b2:	mov    r13,QWORD PTR [r12+0x58]
    71e6bf3010b7:	mov    r14,QWORD PTR [r12+0x50]
    71e6bf3010bc:	mov    rcx,r13
    71e6bf3010bf:	add    r14,rcx
    71e6bf3010c2:	mov    QWORD PTR [r12+0x60],r14
    71e6bf3010c7:	add    r13,0x40
    71e6bf3010cb:	mov    QWORD PTR [r12+0x58],r13
    71e6bf3010d0:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf3010da:	movdqa xmm3,xmm0
    71e6bf3010de:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    71e6bf3010e8:	movdqa xmm4,xmm0
    71e6bf3010ec:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf3010f4:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf3010ff:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf301107:	movdqa xmm0,xmm3
    71e6bf30110b:	movdqa xmm1,xmm4
    71e6bf30110f:	movq   rax,xmm0
    71e6bf301114:	add    rax,rax
    71e6bf301117:	je     0x71e6bf30112d
    71e6bf301119:	shr    rax,0x35
    71e6bf30111d:	sub    eax,0x201
    71e6bf301122:	cmp    eax,0x3fc
    71e6bf301127:	ja     0x71e6bf304e9f
    71e6bf30112d:	movdqa xmm14,xmm0
    71e6bf301132:	psrldq xmm14,0x8
    71e6bf301138:	movq   rax,xmm14
    71e6bf30113d:	add    rax,rax
    71e6bf301140:	je     0x71e6bf301156
    71e6bf301142:	shr    rax,0x35
    71e6bf301146:	sub    eax,0x201
    71e6bf30114b:	cmp    eax,0x3fc
    71e6bf301150:	ja     0x71e6bf304e9f
    71e6bf301156:	movq   rax,xmm1
    71e6bf30115b:	add    rax,rax
    71e6bf30115e:	je     0x71e6bf301174
    71e6bf301160:	shr    rax,0x35
    71e6bf301164:	sub    eax,0x201
    71e6bf301169:	cmp    eax,0x3fc
    71e6bf30116e:	ja     0x71e6bf304e9f
    71e6bf301174:	movdqa xmm14,xmm1
    71e6bf301179:	psrldq xmm14,0x8
    71e6bf30117f:	movq   rax,xmm14
    71e6bf301184:	add    rax,rax
    71e6bf301187:	je     0x71e6bf30119d
    71e6bf301189:	shr    rax,0x35
    71e6bf30118d:	sub    eax,0x201
    71e6bf301192:	cmp    eax,0x3fc
    71e6bf301197:	ja     0x71e6bf304e9f
    71e6bf30119d:	mulpd  xmm0,xmm1
    71e6bf3011a1:	movdqa xmm5,xmm0
    71e6bf3011a5:	movdqa xmm0,xmm5
    71e6bf3011a9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    71e6bf3011b3:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    71e6bf3011bd:	movdqa xmm4,xmm0
    71e6bf3011c1:	movdqa xmm0,xmm2
    71e6bf3011c5:	movdqa xmm1,xmm4
    71e6bf3011c9:	pshufd xmm1,xmm1,0x44
    71e6bf3011ce:	movq   rax,xmm0
    71e6bf3011d3:	add    rax,rax
    71e6bf3011d6:	je     0x71e6bf3011ec
    71e6bf3011d8:	shr    rax,0x35
    71e6bf3011dc:	sub    eax,0x201
    71e6bf3011e1:	cmp    eax,0x3fc
    71e6bf3011e6:	ja     0x71e6bf304ec3
    71e6bf3011ec:	movdqa xmm14,xmm0
    71e6bf3011f1:	psrldq xmm14,0x8
    71e6bf3011f7:	movq   rax,xmm14
    71e6bf3011fc:	add    rax,rax
    71e6bf3011ff:	je     0x71e6bf301215
    71e6bf301201:	shr    rax,0x35
    71e6bf301205:	sub    eax,0x201
    71e6bf30120a:	cmp    eax,0x3fc
    71e6bf30120f:	ja     0x71e6bf304ec3
    71e6bf301215:	movq   rax,xmm1
    71e6bf30121a:	add    rax,rax
    71e6bf30121d:	je     0x71e6bf301233
    71e6bf30121f:	shr    rax,0x35
    71e6bf301223:	sub    eax,0x201
    71e6bf301228:	cmp    eax,0x3fc
    71e6bf30122d:	ja     0x71e6bf304ec3
    71e6bf301233:	movdqa xmm14,xmm1
    71e6bf301238:	psrldq xmm14,0x8
    71e6bf30123e:	movq   rax,xmm14
    71e6bf301243:	add    rax,rax
    71e6bf301246:	je     0x71e6bf30125c
    71e6bf301248:	shr    rax,0x35
    71e6bf30124c:	sub    eax,0x201
    71e6bf301251:	cmp    eax,0x3fc
    71e6bf301256:	ja     0x71e6bf304ec3
    71e6bf30125c:	mulpd  xmm0,xmm1
    71e6bf301260:	movdqa xmm5,xmm0
    71e6bf301264:	movdqa xmm0,xmm5
    71e6bf301268:	movdqu XMMWORD PTR [r12+0x260],xmm0
    71e6bf301272:	mov    r13d,0x0
    71e6bf301278:	mov    r14d,0x0
    71e6bf30127e:	mov    QWORD PTR [r12+0x110],r13
    71e6bf301286:	mov    QWORD PTR [r12+0x118],r14
    71e6bf30128e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf301298:	movdqa xmm2,xmm0
    71e6bf30129c:	movdqa xmm0,xmm3
    71e6bf3012a0:	movdqa xmm1,xmm2
    71e6bf3012a4:	movq   rax,xmm0
    71e6bf3012a9:	add    rax,rax
    71e6bf3012ac:	je     0x71e6bf3012c2
    71e6bf3012ae:	shr    rax,0x35
    71e6bf3012b2:	sub    eax,0x201
    71e6bf3012b7:	cmp    eax,0x3fc
    71e6bf3012bc:	ja     0x71e6bf304ee7
    71e6bf3012c2:	movdqa xmm14,xmm0
    71e6bf3012c7:	psrldq xmm14,0x8
    71e6bf3012cd:	movq   rax,xmm14
    71e6bf3012d2:	add    rax,rax
    71e6bf3012d5:	je     0x71e6bf3012eb
    71e6bf3012d7:	shr    rax,0x35
    71e6bf3012db:	sub    eax,0x201
    71e6bf3012e0:	cmp    eax,0x3fc
    71e6bf3012e5:	ja     0x71e6bf304ee7
    71e6bf3012eb:	movq   rax,xmm1
    71e6bf3012f0:	add    rax,rax
    71e6bf3012f3:	je     0x71e6bf301309
    71e6bf3012f5:	shr    rax,0x35
    71e6bf3012f9:	sub    eax,0x201
    71e6bf3012fe:	cmp    eax,0x3fc
    71e6bf301303:	ja     0x71e6bf304ee7
    71e6bf301309:	movdqa xmm14,xmm1
    71e6bf30130e:	psrldq xmm14,0x8
    71e6bf301314:	movq   rax,xmm14
    71e6bf301319:	add    rax,rax
    71e6bf30131c:	je     0x71e6bf301332
    71e6bf30131e:	shr    rax,0x35
    71e6bf301322:	sub    eax,0x201
    71e6bf301327:	cmp    eax,0x3fc
    71e6bf30132c:	ja     0x71e6bf304ee7
    71e6bf301332:	mulpd  xmm0,xmm1
    71e6bf301336:	movdqa xmm4,xmm0
    71e6bf30133a:	movdqa xmm0,xmm4
    71e6bf30133e:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf301348:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf301352:	movdqa xmm2,xmm0
    71e6bf301356:	movdqa xmm0,xmm3
    71e6bf30135a:	movdqa xmm1,xmm2
    71e6bf30135e:	movq   rax,xmm0
    71e6bf301363:	add    rax,rax
    71e6bf301366:	je     0x71e6bf30137c
    71e6bf301368:	shr    rax,0x35
    71e6bf30136c:	sub    eax,0x201
    71e6bf301371:	cmp    eax,0x3fc
    71e6bf301376:	ja     0x71e6bf304f0b
    71e6bf30137c:	movdqa xmm14,xmm0
    71e6bf301381:	psrldq xmm14,0x8
    71e6bf301387:	movq   rax,xmm14
    71e6bf30138c:	add    rax,rax
    71e6bf30138f:	je     0x71e6bf3013a5
    71e6bf301391:	shr    rax,0x35
    71e6bf301395:	sub    eax,0x201
    71e6bf30139a:	cmp    eax,0x3fc
    71e6bf30139f:	ja     0x71e6bf304f0b
    71e6bf3013a5:	movq   rax,xmm1
    71e6bf3013aa:	add    rax,rax
    71e6bf3013ad:	je     0x71e6bf3013c3
    71e6bf3013af:	shr    rax,0x35
    71e6bf3013b3:	sub    eax,0x201
    71e6bf3013b8:	cmp    eax,0x3fc
    71e6bf3013bd:	ja     0x71e6bf304f0b
    71e6bf3013c3:	movdqa xmm14,xmm1
    71e6bf3013c8:	psrldq xmm14,0x8
    71e6bf3013ce:	movq   rax,xmm14
    71e6bf3013d3:	add    rax,rax
    71e6bf3013d6:	je     0x71e6bf3013ec
    71e6bf3013d8:	shr    rax,0x35
    71e6bf3013dc:	sub    eax,0x201
    71e6bf3013e1:	cmp    eax,0x3fc
    71e6bf3013e6:	ja     0x71e6bf304f0b
    71e6bf3013ec:	mulpd  xmm0,xmm1
    71e6bf3013f0:	movdqa xmm4,xmm0
    71e6bf3013f4:	movdqa xmm0,xmm4
    71e6bf3013f8:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf301402:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf30140c:	movdqa xmm2,xmm0
    71e6bf301410:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    71e6bf30141a:	movdqa xmm3,xmm0
    71e6bf30141e:	movdqa xmm0,xmm2
    71e6bf301422:	movdqa xmm1,xmm3
    71e6bf301426:	movq   rax,xmm0
    71e6bf30142b:	add    rax,rax
    71e6bf30142e:	je     0x71e6bf301444
    71e6bf301430:	shr    rax,0x35
    71e6bf301434:	sub    eax,0x201
    71e6bf301439:	cmp    eax,0x3fc
    71e6bf30143e:	ja     0x71e6bf304f2f
    71e6bf301444:	movdqa xmm14,xmm0
    71e6bf301449:	psrldq xmm14,0x8
    71e6bf30144f:	movq   rax,xmm14
    71e6bf301454:	add    rax,rax
    71e6bf301457:	je     0x71e6bf30146d
    71e6bf301459:	shr    rax,0x35
    71e6bf30145d:	sub    eax,0x201
    71e6bf301462:	cmp    eax,0x3fc
    71e6bf301467:	ja     0x71e6bf304f2f
    71e6bf30146d:	movq   rax,xmm1
    71e6bf301472:	add    rax,rax
    71e6bf301475:	je     0x71e6bf30148b
    71e6bf301477:	shr    rax,0x35
    71e6bf30147b:	sub    eax,0x201
    71e6bf301480:	cmp    eax,0x3fc
    71e6bf301485:	ja     0x71e6bf304f2f
    71e6bf30148b:	movdqa xmm14,xmm1
    71e6bf301490:	psrldq xmm14,0x8
    71e6bf301496:	movq   rax,xmm14
    71e6bf30149b:	add    rax,rax
    71e6bf30149e:	je     0x71e6bf3014b4
    71e6bf3014a0:	shr    rax,0x35
    71e6bf3014a4:	sub    eax,0x201
    71e6bf3014a9:	cmp    eax,0x3fc
    71e6bf3014ae:	ja     0x71e6bf304f2f
    71e6bf3014b4:	mulpd  xmm0,xmm1
    71e6bf3014b8:	movdqa xmm4,xmm0
    71e6bf3014bc:	movdqa xmm0,xmm4
    71e6bf3014c0:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf3014ca:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    71e6bf3014d4:	movdqa xmm2,xmm0
    71e6bf3014d8:	movdqa xmm1,xmm2
    71e6bf3014dc:	por    xmm2,xmm1
    71e6bf3014e0:	movdqa xmm0,xmm2
    71e6bf3014e4:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    71e6bf3014ee:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    71e6bf3014f8:	movdqa xmm2,xmm0
    71e6bf3014fc:	movdqa xmm3,xmm2
    71e6bf301500:	movdqa xmm1,xmm2
    71e6bf301504:	por    xmm3,xmm1
    71e6bf301508:	movdqa xmm0,xmm3
    71e6bf30150c:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    71e6bf301516:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    71e6bf301520:	movdqa xmm3,xmm0
    71e6bf301524:	movdqa xmm0,xmm2
    71e6bf301528:	movdqa xmm1,xmm3
    71e6bf30152c:	pshufd xmm1,xmm1,0x44
    71e6bf301531:	movq   rax,xmm0
    71e6bf301536:	add    rax,rax
    71e6bf301539:	je     0x71e6bf30154f
    71e6bf30153b:	shr    rax,0x35
    71e6bf30153f:	sub    eax,0x201
    71e6bf301544:	cmp    eax,0x3fc
    71e6bf301549:	ja     0x71e6bf304f53
    71e6bf30154f:	movdqa xmm14,xmm0
    71e6bf301554:	psrldq xmm14,0x8
    71e6bf30155a:	movq   rax,xmm14
    71e6bf30155f:	add    rax,rax
    71e6bf301562:	je     0x71e6bf301578
    71e6bf301564:	shr    rax,0x35
    71e6bf301568:	sub    eax,0x201
    71e6bf30156d:	cmp    eax,0x3fc
    71e6bf301572:	ja     0x71e6bf304f53
    71e6bf301578:	movq   rax,xmm1
    71e6bf30157d:	add    rax,rax
    71e6bf301580:	je     0x71e6bf301596
    71e6bf301582:	shr    rax,0x35
    71e6bf301586:	sub    eax,0x201
    71e6bf30158b:	cmp    eax,0x3fc
    71e6bf301590:	ja     0x71e6bf304f53
    71e6bf301596:	movdqa xmm14,xmm1
    71e6bf30159b:	psrldq xmm14,0x8
    71e6bf3015a1:	movq   rax,xmm14
    71e6bf3015a6:	add    rax,rax
    71e6bf3015a9:	je     0x71e6bf3015bf
    71e6bf3015ab:	shr    rax,0x35
    71e6bf3015af:	sub    eax,0x201
    71e6bf3015b4:	cmp    eax,0x3fc
    71e6bf3015b9:	ja     0x71e6bf304f53
    71e6bf3015bf:	mulpd  xmm0,xmm1
    71e6bf3015c3:	movdqa xmm4,xmm0
    71e6bf3015c7:	movdqa xmm0,xmm4
    71e6bf3015cb:	movdqu XMMWORD PTR [r12+0x250],xmm0
    71e6bf3015d5:	mov    r13,QWORD PTR [r12+0x58]
    71e6bf3015da:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf3015e2:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf3015ea:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf3015f2:	shr    r11d,1
    71e6bf3015f5:	and    r11d,0x10
    71e6bf3015f9:	or     DWORD PTR [r12+0x314],r11d
    71e6bf301601:	sub    r13,0x200
    71e6bf301608:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    71e6bf301612:	movdqa xmm2,xmm0
    71e6bf301616:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf301620:	movdqa xmm3,xmm0
    71e6bf301624:	pushf
    71e6bf301625:	pop    r11
    71e6bf301627:	mov    QWORD PTR [rsp],r11
    71e6bf30162b:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf301633:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf30163e:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf301646:	movdqa xmm0,xmm2
    71e6bf30164a:	movdqa xmm1,xmm3
    71e6bf30164e:	movq   rax,xmm0
    71e6bf301653:	add    rax,rax
    71e6bf301656:	je     0x71e6bf30166c
    71e6bf301658:	shr    rax,0x35
    71e6bf30165c:	sub    eax,0x201
    71e6bf301661:	cmp    eax,0x3fc
    71e6bf301666:	ja     0x71e6bf304f77
    71e6bf30166c:	movdqa xmm14,xmm0
    71e6bf301671:	psrldq xmm14,0x8
    71e6bf301677:	movq   rax,xmm14
    71e6bf30167c:	add    rax,rax
    71e6bf30167f:	je     0x71e6bf301695
    71e6bf301681:	shr    rax,0x35
    71e6bf301685:	sub    eax,0x201
    71e6bf30168a:	cmp    eax,0x3fc
    71e6bf30168f:	ja     0x71e6bf304f77
    71e6bf301695:	movq   rax,xmm1
    71e6bf30169a:	add    rax,rax
    71e6bf30169d:	je     0x71e6bf3016b3
    71e6bf30169f:	shr    rax,0x35
    71e6bf3016a3:	sub    eax,0x201
    71e6bf3016a8:	cmp    eax,0x3fc
    71e6bf3016ad:	ja     0x71e6bf304f77
    71e6bf3016b3:	movdqa xmm14,xmm1
    71e6bf3016b8:	psrldq xmm14,0x8
    71e6bf3016be:	movq   rax,xmm14
    71e6bf3016c3:	add    rax,rax
    71e6bf3016c6:	je     0x71e6bf3016dc
    71e6bf3016c8:	shr    rax,0x35
    71e6bf3016cc:	sub    eax,0x201
    71e6bf3016d1:	cmp    eax,0x3fc
    71e6bf3016d6:	ja     0x71e6bf304f77
    71e6bf3016dc:	addpd  xmm0,xmm1
    71e6bf3016e0:	movdqa xmm4,xmm0
    71e6bf3016e4:	movdqa xmm0,xmm4
    71e6bf3016e8:	movdqu XMMWORD PTR [r12+0x240],xmm0
    71e6bf3016f2:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf3016fc:	movdqa xmm2,xmm0
    71e6bf301700:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    71e6bf30170a:	movdqa xmm3,xmm0
    71e6bf30170e:	movdqa xmm0,xmm2
    71e6bf301712:	movdqa xmm1,xmm3
    71e6bf301716:	movq   rax,xmm0
    71e6bf30171b:	add    rax,rax
    71e6bf30171e:	je     0x71e6bf301734
    71e6bf301720:	shr    rax,0x35
    71e6bf301724:	sub    eax,0x201
    71e6bf301729:	cmp    eax,0x3fc
    71e6bf30172e:	ja     0x71e6bf304f9b
    71e6bf301734:	movdqa xmm14,xmm0
    71e6bf301739:	psrldq xmm14,0x8
    71e6bf30173f:	movq   rax,xmm14
    71e6bf301744:	add    rax,rax
    71e6bf301747:	je     0x71e6bf30175d
    71e6bf301749:	shr    rax,0x35
    71e6bf30174d:	sub    eax,0x201
    71e6bf301752:	cmp    eax,0x3fc
    71e6bf301757:	ja     0x71e6bf304f9b
    71e6bf30175d:	movq   rax,xmm1
    71e6bf301762:	add    rax,rax
    71e6bf301765:	je     0x71e6bf30177b
    71e6bf301767:	shr    rax,0x35
    71e6bf30176b:	sub    eax,0x201
    71e6bf301770:	cmp    eax,0x3fc
    71e6bf301775:	ja     0x71e6bf304f9b
    71e6bf30177b:	movdqa xmm14,xmm1
    71e6bf301780:	psrldq xmm14,0x8
    71e6bf301786:	movq   rax,xmm14
    71e6bf30178b:	add    rax,rax
    71e6bf30178e:	je     0x71e6bf3017a4
    71e6bf301790:	shr    rax,0x35
    71e6bf301794:	sub    eax,0x201
    71e6bf301799:	cmp    eax,0x3fc
    71e6bf30179e:	ja     0x71e6bf304f9b
    71e6bf3017a4:	addpd  xmm0,xmm1
    71e6bf3017a8:	movdqa xmm4,xmm0
    71e6bf3017ac:	movdqa xmm0,xmm4
    71e6bf3017b0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf3017ba:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf3017c4:	movdqa xmm2,xmm0
    71e6bf3017c8:	movdqa xmm0,xmm2
    71e6bf3017cc:	movdqa xmm1,xmm3
    71e6bf3017d0:	movq   rax,xmm0
    71e6bf3017d5:	add    rax,rax
    71e6bf3017d8:	je     0x71e6bf3017ee
    71e6bf3017da:	shr    rax,0x35
    71e6bf3017de:	sub    eax,0x201
    71e6bf3017e3:	cmp    eax,0x3fc
    71e6bf3017e8:	ja     0x71e6bf304fbf
    71e6bf3017ee:	movdqa xmm14,xmm0
    71e6bf3017f3:	psrldq xmm14,0x8
    71e6bf3017f9:	movq   rax,xmm14
    71e6bf3017fe:	add    rax,rax
    71e6bf301801:	je     0x71e6bf301817
    71e6bf301803:	shr    rax,0x35
    71e6bf301807:	sub    eax,0x201
    71e6bf30180c:	cmp    eax,0x3fc
    71e6bf301811:	ja     0x71e6bf304fbf
    71e6bf301817:	movq   rax,xmm1
    71e6bf30181c:	add    rax,rax
    71e6bf30181f:	je     0x71e6bf301835
    71e6bf301821:	shr    rax,0x35
    71e6bf301825:	sub    eax,0x201
    71e6bf30182a:	cmp    eax,0x3fc
    71e6bf30182f:	ja     0x71e6bf304fbf
    71e6bf301835:	movdqa xmm14,xmm1
    71e6bf30183a:	psrldq xmm14,0x8
    71e6bf301840:	movq   rax,xmm14
    71e6bf301845:	add    rax,rax
    71e6bf301848:	je     0x71e6bf30185e
    71e6bf30184a:	shr    rax,0x35
    71e6bf30184e:	sub    eax,0x201
    71e6bf301853:	cmp    eax,0x3fc
    71e6bf301858:	ja     0x71e6bf304fbf
    71e6bf30185e:	addpd  xmm0,xmm1
    71e6bf301862:	movdqa xmm4,xmm0
    71e6bf301866:	movdqa xmm0,xmm4
    71e6bf30186a:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf301874:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    71e6bf30187e:	movdqa xmm2,xmm0
    71e6bf301882:	movdqa xmm1,xmm2
    71e6bf301886:	por    xmm2,xmm1
    71e6bf30188a:	movdqa xmm0,xmm2
    71e6bf30188e:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    71e6bf301898:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    71e6bf3018a2:	movdqa xmm2,xmm0
    71e6bf3018a6:	movdqa xmm1,xmm2
    71e6bf3018aa:	por    xmm2,xmm1
    71e6bf3018ae:	movdqa xmm0,xmm2
    71e6bf3018b2:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    71e6bf3018bc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    71e6bf3018c6:	movdqa xmm2,xmm0
    71e6bf3018ca:	movdqa xmm1,xmm2
    71e6bf3018ce:	por    xmm2,xmm1
    71e6bf3018d2:	movdqa xmm0,xmm2
    71e6bf3018d6:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    71e6bf3018e0:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    71e6bf3018ea:	movdqa xmm2,xmm0
    71e6bf3018ee:	movdqa xmm1,xmm2
    71e6bf3018f2:	por    xmm2,xmm1
    71e6bf3018f6:	movdqa xmm0,xmm2
    71e6bf3018fa:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    71e6bf301904:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    71e6bf30190e:	movdqa xmm2,xmm0
    71e6bf301912:	movdqa xmm1,xmm2
    71e6bf301916:	por    xmm2,xmm1
    71e6bf30191a:	movdqa xmm0,xmm2
    71e6bf30191e:	movdqu XMMWORD PTR [r12+0x200],xmm0
    71e6bf301928:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    71e6bf301932:	movdqa xmm2,xmm0
    71e6bf301936:	movdqa xmm1,xmm2
    71e6bf30193a:	por    xmm2,xmm1
    71e6bf30193e:	movdqa xmm0,xmm2
    71e6bf301942:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    71e6bf30194c:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    71e6bf301956:	movdqa xmm2,xmm0
    71e6bf30195a:	movdqa xmm1,xmm2
    71e6bf30195e:	por    xmm2,xmm1
    71e6bf301962:	movdqa xmm0,xmm2
    71e6bf301966:	movdqu XMMWORD PTR [r12+0x190],xmm0
    71e6bf301970:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf301978:	mov    r14,r13
    71e6bf30197b:	add    r14,0xa0
    71e6bf301982:	mov    r15,r14
    71e6bf301985:	add    r15,0x10
    71e6bf301989:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf301991:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf301999:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf3019a1:	shr    r11d,1
    71e6bf3019a4:	and    r11d,0x10
    71e6bf3019a8:	or     DWORD PTR [r12+0x314],r11d
    71e6bf3019b0:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf3019b5:	movdqu xmm3,XMMWORD PTR [r15]
    71e6bf3019ba:	movdqa xmm0,xmm2
    71e6bf3019be:	movdqu XMMWORD PTR [r12+0x300],xmm0
    71e6bf3019c8:	movdqa xmm0,xmm3
    71e6bf3019cc:	movdqu XMMWORD PTR [r12+0x270],xmm0
    71e6bf3019d6:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf3019e0:	movdqa xmm2,xmm0
    71e6bf3019e4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf3019ee:	movdqa xmm4,xmm0
    71e6bf3019f2:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf3019fa:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf301a05:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf301a0d:	movdqa xmm0,xmm2
    71e6bf301a11:	movdqa xmm1,xmm4
    71e6bf301a15:	movq   rax,xmm0
    71e6bf301a1a:	add    rax,rax
    71e6bf301a1d:	je     0x71e6bf301a33
    71e6bf301a1f:	shr    rax,0x35
    71e6bf301a23:	sub    eax,0x201
    71e6bf301a28:	cmp    eax,0x3fc
    71e6bf301a2d:	ja     0x71e6bf304fe3
    71e6bf301a33:	movdqa xmm14,xmm0
    71e6bf301a38:	psrldq xmm14,0x8
    71e6bf301a3e:	movq   rax,xmm14
    71e6bf301a43:	add    rax,rax
    71e6bf301a46:	je     0x71e6bf301a5c
    71e6bf301a48:	shr    rax,0x35
    71e6bf301a4c:	sub    eax,0x201
    71e6bf301a51:	cmp    eax,0x3fc
    71e6bf301a56:	ja     0x71e6bf304fe3
    71e6bf301a5c:	movq   rax,xmm1
    71e6bf301a61:	add    rax,rax
    71e6bf301a64:	je     0x71e6bf301a7a
    71e6bf301a66:	shr    rax,0x35
    71e6bf301a6a:	sub    eax,0x201
    71e6bf301a6f:	cmp    eax,0x3fc
    71e6bf301a74:	ja     0x71e6bf304fe3
    71e6bf301a7a:	movdqa xmm14,xmm1
    71e6bf301a7f:	psrldq xmm14,0x8
    71e6bf301a85:	movq   rax,xmm14
    71e6bf301a8a:	add    rax,rax
    71e6bf301a8d:	je     0x71e6bf301aa3
    71e6bf301a8f:	shr    rax,0x35
    71e6bf301a93:	sub    eax,0x201
    71e6bf301a98:	cmp    eax,0x3fc
    71e6bf301a9d:	ja     0x71e6bf304fe3
    71e6bf301aa3:	addpd  xmm0,xmm1
    71e6bf301aa7:	movdqa xmm5,xmm0
    71e6bf301aab:	movdqa xmm0,xmm5
    71e6bf301aaf:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf301ab9:	add    r13,0xf0
    71e6bf301ac0:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf301ac8:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf301ad0:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf301ad8:	shr    r11d,1
    71e6bf301adb:	and    r11d,0x10
    71e6bf301adf:	or     DWORD PTR [r12+0x314],r11d
    71e6bf301ae7:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf301aed:	movdqa xmm0,xmm2
    71e6bf301af1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf301afb:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf301b05:	movdqa xmm4,xmm0
    71e6bf301b09:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    71e6bf301b13:	movdqa xmm5,xmm0
    71e6bf301b17:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf301b1f:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf301b2a:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf301b32:	movdqa xmm0,xmm4
    71e6bf301b36:	movdqa xmm1,xmm5
    71e6bf301b3a:	movq   rax,xmm0
    71e6bf301b3f:	add    rax,rax
    71e6bf301b42:	je     0x71e6bf301b58
    71e6bf301b44:	shr    rax,0x35
    71e6bf301b48:	sub    eax,0x201
    71e6bf301b4d:	cmp    eax,0x3fc
    71e6bf301b52:	ja     0x71e6bf305007
    71e6bf301b58:	movdqa xmm14,xmm0
    71e6bf301b5d:	psrldq xmm14,0x8
    71e6bf301b63:	movq   rax,xmm14
    71e6bf301b68:	add    rax,rax
    71e6bf301b6b:	je     0x71e6bf301b81
    71e6bf301b6d:	shr    rax,0x35
    71e6bf301b71:	sub    eax,0x201
    71e6bf301b76:	cmp    eax,0x3fc
    71e6bf301b7b:	ja     0x71e6bf305007
    71e6bf301b81:	movq   rax,xmm1
    71e6bf301b86:	add    rax,rax
    71e6bf301b89:	je     0x71e6bf301b9f
    71e6bf301b8b:	shr    rax,0x35
    71e6bf301b8f:	sub    eax,0x201
    71e6bf301b94:	cmp    eax,0x3fc
    71e6bf301b99:	ja     0x71e6bf305007
    71e6bf301b9f:	movdqa xmm14,xmm1
    71e6bf301ba4:	psrldq xmm14,0x8
    71e6bf301baa:	movq   rax,xmm14
    71e6bf301baf:	add    rax,rax
    71e6bf301bb2:	je     0x71e6bf301bc8
    71e6bf301bb4:	shr    rax,0x35
    71e6bf301bb8:	sub    eax,0x201
    71e6bf301bbd:	cmp    eax,0x3fc
    71e6bf301bc2:	ja     0x71e6bf305007
    71e6bf301bc8:	addpd  xmm0,xmm1
    71e6bf301bcc:	movdqa xmm6,xmm0
    71e6bf301bd0:	movdqa xmm0,xmm6
    71e6bf301bd4:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf301bde:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf301be8:	movdqa xmm4,xmm0
    71e6bf301bec:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    71e6bf301bf6:	movdqa xmm5,xmm0
    71e6bf301bfa:	movdqa xmm0,xmm4
    71e6bf301bfe:	movdqa xmm1,xmm5
    71e6bf301c02:	movq   rax,xmm0
    71e6bf301c07:	add    rax,rax
    71e6bf301c0a:	je     0x71e6bf301c20
    71e6bf301c0c:	shr    rax,0x35
    71e6bf301c10:	sub    eax,0x201
    71e6bf301c15:	cmp    eax,0x3fc
    71e6bf301c1a:	ja     0x71e6bf30502b
    71e6bf301c20:	movdqa xmm14,xmm0
    71e6bf301c25:	psrldq xmm14,0x8
    71e6bf301c2b:	movq   rax,xmm14
    71e6bf301c30:	add    rax,rax
    71e6bf301c33:	je     0x71e6bf301c49
    71e6bf301c35:	shr    rax,0x35
    71e6bf301c39:	sub    eax,0x201
    71e6bf301c3e:	cmp    eax,0x3fc
    71e6bf301c43:	ja     0x71e6bf30502b
    71e6bf301c49:	movq   rax,xmm1
    71e6bf301c4e:	add    rax,rax
    71e6bf301c51:	je     0x71e6bf301c67
    71e6bf301c53:	shr    rax,0x35
    71e6bf301c57:	sub    eax,0x201
    71e6bf301c5c:	cmp    eax,0x3fc
    71e6bf301c61:	ja     0x71e6bf30502b
    71e6bf301c67:	movdqa xmm14,xmm1
    71e6bf301c6c:	psrldq xmm14,0x8
    71e6bf301c72:	movq   rax,xmm14
    71e6bf301c77:	add    rax,rax
    71e6bf301c7a:	je     0x71e6bf301c90
    71e6bf301c7c:	shr    rax,0x35
    71e6bf301c80:	sub    eax,0x201
    71e6bf301c85:	cmp    eax,0x3fc
    71e6bf301c8a:	ja     0x71e6bf30502b
    71e6bf301c90:	addpd  xmm0,xmm1
    71e6bf301c94:	movdqa xmm6,xmm0
    71e6bf301c98:	movdqa xmm0,xmm6
    71e6bf301c9c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf301ca6:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    71e6bf301cb0:	movdqa xmm4,xmm0
    71e6bf301cb4:	movdqa xmm0,xmm3
    71e6bf301cb8:	movdqa xmm1,xmm4
    71e6bf301cbc:	pshufd xmm1,xmm1,0x44
    71e6bf301cc1:	movq   rax,xmm0
    71e6bf301cc6:	add    rax,rax
    71e6bf301cc9:	je     0x71e6bf301cdf
    71e6bf301ccb:	shr    rax,0x35
    71e6bf301ccf:	sub    eax,0x201
    71e6bf301cd4:	cmp    eax,0x3fc
    71e6bf301cd9:	ja     0x71e6bf30504f
    71e6bf301cdf:	movdqa xmm14,xmm0
    71e6bf301ce4:	psrldq xmm14,0x8
    71e6bf301cea:	movq   rax,xmm14
    71e6bf301cef:	add    rax,rax
    71e6bf301cf2:	je     0x71e6bf301d08
    71e6bf301cf4:	shr    rax,0x35
    71e6bf301cf8:	sub    eax,0x201
    71e6bf301cfd:	cmp    eax,0x3fc
    71e6bf301d02:	ja     0x71e6bf30504f
    71e6bf301d08:	movq   rax,xmm1
    71e6bf301d0d:	add    rax,rax
    71e6bf301d10:	je     0x71e6bf301d26
    71e6bf301d12:	shr    rax,0x35
    71e6bf301d16:	sub    eax,0x201
    71e6bf301d1b:	cmp    eax,0x3fc
    71e6bf301d20:	ja     0x71e6bf30504f
    71e6bf301d26:	movdqa xmm14,xmm1
    71e6bf301d2b:	psrldq xmm14,0x8
    71e6bf301d31:	movq   rax,xmm14
    71e6bf301d36:	add    rax,rax
    71e6bf301d39:	je     0x71e6bf301d4f
    71e6bf301d3b:	shr    rax,0x35
    71e6bf301d3f:	sub    eax,0x201
    71e6bf301d44:	cmp    eax,0x3fc
    71e6bf301d49:	ja     0x71e6bf30504f
    71e6bf301d4f:	mulpd  xmm0,xmm1
    71e6bf301d53:	movdqa xmm5,xmm0
    71e6bf301d57:	movdqa xmm0,xmm5
    71e6bf301d5b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    71e6bf301d65:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf301d6f:	movdqa xmm3,xmm0
    71e6bf301d73:	movdqa xmm0,xmm2
    71e6bf301d77:	movdqa xmm1,xmm3
    71e6bf301d7b:	pshufd xmm1,xmm1,0x44
    71e6bf301d80:	movq   rax,xmm0
    71e6bf301d85:	add    rax,rax
    71e6bf301d88:	je     0x71e6bf301d9e
    71e6bf301d8a:	shr    rax,0x35
    71e6bf301d8e:	sub    eax,0x201
    71e6bf301d93:	cmp    eax,0x3fc
    71e6bf301d98:	ja     0x71e6bf305073
    71e6bf301d9e:	movdqa xmm14,xmm0
    71e6bf301da3:	psrldq xmm14,0x8
    71e6bf301da9:	movq   rax,xmm14
    71e6bf301dae:	add    rax,rax
    71e6bf301db1:	je     0x71e6bf301dc7
    71e6bf301db3:	shr    rax,0x35
    71e6bf301db7:	sub    eax,0x201
    71e6bf301dbc:	cmp    eax,0x3fc
    71e6bf301dc1:	ja     0x71e6bf305073
    71e6bf301dc7:	movq   rax,xmm1
    71e6bf301dcc:	add    rax,rax
    71e6bf301dcf:	je     0x71e6bf301de5
    71e6bf301dd1:	shr    rax,0x35
    71e6bf301dd5:	sub    eax,0x201
    71e6bf301dda:	cmp    eax,0x3fc
    71e6bf301ddf:	ja     0x71e6bf305073
    71e6bf301de5:	movdqa xmm14,xmm1
    71e6bf301dea:	psrldq xmm14,0x8
    71e6bf301df0:	movq   rax,xmm14
    71e6bf301df5:	add    rax,rax
    71e6bf301df8:	je     0x71e6bf301e0e
    71e6bf301dfa:	shr    rax,0x35
    71e6bf301dfe:	sub    eax,0x201
    71e6bf301e03:	cmp    eax,0x3fc
    71e6bf301e08:	ja     0x71e6bf305073
    71e6bf301e0e:	mulpd  xmm0,xmm1
    71e6bf301e12:	movdqa xmm5,xmm0
    71e6bf301e16:	movdqa xmm0,xmm5
    71e6bf301e1a:	movdqu XMMWORD PTR [r12+0x250],xmm0
    71e6bf301e24:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf301e2c:	mov    r14,r13
    71e6bf301e2f:	add    r14,0xe0
    71e6bf301e36:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf301e3e:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf301e46:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf301e4e:	shr    r11d,1
    71e6bf301e51:	and    r11d,0x10
    71e6bf301e55:	or     DWORD PTR [r12+0x314],r11d
    71e6bf301e5d:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf301e62:	movdqa xmm0,xmm2
    71e6bf301e66:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf301e70:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    71e6bf301e7a:	movdqa xmm2,xmm0
    71e6bf301e7e:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf301e86:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf301e91:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf301e99:	movdqa xmm0,xmm2
    71e6bf301e9d:	movdqa xmm1,xmm4
    71e6bf301ea1:	pshufd xmm1,xmm1,0x44
    71e6bf301ea6:	movq   rax,xmm0
    71e6bf301eab:	add    rax,rax
    71e6bf301eae:	je     0x71e6bf301ec4
    71e6bf301eb0:	shr    rax,0x35
    71e6bf301eb4:	sub    eax,0x201
    71e6bf301eb9:	cmp    eax,0x3fc
    71e6bf301ebe:	ja     0x71e6bf305097
    71e6bf301ec4:	movdqa xmm14,xmm0
    71e6bf301ec9:	psrldq xmm14,0x8
    71e6bf301ecf:	movq   rax,xmm14
    71e6bf301ed4:	add    rax,rax
    71e6bf301ed7:	je     0x71e6bf301eed
    71e6bf301ed9:	shr    rax,0x35
    71e6bf301edd:	sub    eax,0x201
    71e6bf301ee2:	cmp    eax,0x3fc
    71e6bf301ee7:	ja     0x71e6bf305097
    71e6bf301eed:	movq   rax,xmm1
    71e6bf301ef2:	add    rax,rax
    71e6bf301ef5:	je     0x71e6bf301f0b
    71e6bf301ef7:	shr    rax,0x35
    71e6bf301efb:	sub    eax,0x201
    71e6bf301f00:	cmp    eax,0x3fc
    71e6bf301f05:	ja     0x71e6bf305097
    71e6bf301f0b:	movdqa xmm14,xmm1
    71e6bf301f10:	psrldq xmm14,0x8
    71e6bf301f16:	movq   rax,xmm14
    71e6bf301f1b:	add    rax,rax
    71e6bf301f1e:	je     0x71e6bf301f34
    71e6bf301f20:	shr    rax,0x35
    71e6bf301f24:	sub    eax,0x201
    71e6bf301f29:	cmp    eax,0x3fc
    71e6bf301f2e:	ja     0x71e6bf305097
    71e6bf301f34:	mulpd  xmm0,xmm1
    71e6bf301f38:	movdqa xmm5,xmm0
    71e6bf301f3c:	movdqa xmm0,xmm5
    71e6bf301f40:	movdqu XMMWORD PTR [r12+0x230],xmm0
    71e6bf301f4a:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    71e6bf301f54:	movdqa xmm2,xmm0
    71e6bf301f58:	movdqa xmm1,xmm2
    71e6bf301f5c:	por    xmm2,xmm1
    71e6bf301f60:	movdqa xmm0,xmm2
    71e6bf301f64:	movdqu XMMWORD PTR [r12+0x300],xmm0
    71e6bf301f6e:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    71e6bf301f78:	movdqa xmm2,xmm0
    71e6bf301f7c:	movdqa xmm1,xmm2
    71e6bf301f80:	por    xmm2,xmm1
    71e6bf301f84:	movdqa xmm0,xmm2
    71e6bf301f88:	movdqu XMMWORD PTR [r12+0x190],xmm0
    71e6bf301f92:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf301f9c:	movdqa xmm2,xmm0
    71e6bf301fa0:	movdqa xmm0,xmm2
    71e6bf301fa4:	movdqa xmm1,xmm3
    71e6bf301fa8:	pshufd xmm1,xmm1,0x44
    71e6bf301fad:	movq   rax,xmm0
    71e6bf301fb2:	add    rax,rax
    71e6bf301fb5:	je     0x71e6bf301fcb
    71e6bf301fb7:	shr    rax,0x35
    71e6bf301fbb:	sub    eax,0x201
    71e6bf301fc0:	cmp    eax,0x3fc
    71e6bf301fc5:	ja     0x71e6bf3050bb
    71e6bf301fcb:	movdqa xmm14,xmm0
    71e6bf301fd0:	psrldq xmm14,0x8
    71e6bf301fd6:	movq   rax,xmm14
    71e6bf301fdb:	add    rax,rax
    71e6bf301fde:	je     0x71e6bf301ff4
    71e6bf301fe0:	shr    rax,0x35
    71e6bf301fe4:	sub    eax,0x201
    71e6bf301fe9:	cmp    eax,0x3fc
    71e6bf301fee:	ja     0x71e6bf3050bb
    71e6bf301ff4:	movq   rax,xmm1
    71e6bf301ff9:	add    rax,rax
    71e6bf301ffc:	je     0x71e6bf302012
    71e6bf301ffe:	shr    rax,0x35
    71e6bf302002:	sub    eax,0x201
    71e6bf302007:	cmp    eax,0x3fc
    71e6bf30200c:	ja     0x71e6bf3050bb
    71e6bf302012:	movdqa xmm14,xmm1
    71e6bf302017:	psrldq xmm14,0x8
    71e6bf30201d:	movq   rax,xmm14
    71e6bf302022:	add    rax,rax
    71e6bf302025:	je     0x71e6bf30203b
    71e6bf302027:	shr    rax,0x35
    71e6bf30202b:	sub    eax,0x201
    71e6bf302030:	cmp    eax,0x3fc
    71e6bf302035:	ja     0x71e6bf3050bb
    71e6bf30203b:	mulpd  xmm0,xmm1
    71e6bf30203f:	movdqa xmm4,xmm0
    71e6bf302043:	movdqa xmm0,xmm4
    71e6bf302047:	movdqu XMMWORD PTR [r12+0x260],xmm0
    71e6bf302051:	add    r13,0x90
    71e6bf302058:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf302060:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf302068:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf302070:	shr    r11d,1
    71e6bf302073:	and    r11d,0x10
    71e6bf302077:	or     DWORD PTR [r12+0x314],r11d
    71e6bf30207f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf302085:	movdqa xmm0,xmm2
    71e6bf302089:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf302093:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    71e6bf30209d:	movdqa xmm3,xmm0
    71e6bf3020a1:	movdqa xmm1,xmm3
    71e6bf3020a5:	por    xmm3,xmm1
    71e6bf3020a9:	movdqa xmm0,xmm3
    71e6bf3020ad:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    71e6bf3020b7:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    71e6bf3020c1:	movdqa xmm3,xmm0
    71e6bf3020c5:	movdqa xmm1,xmm3
    71e6bf3020c9:	por    xmm3,xmm1
    71e6bf3020cd:	movdqa xmm0,xmm3
    71e6bf3020d1:	movdqu XMMWORD PTR [r12+0x200],xmm0
    71e6bf3020db:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    71e6bf3020e5:	movdqa xmm3,xmm0
    71e6bf3020e9:	movdqa xmm1,xmm3
    71e6bf3020ed:	por    xmm3,xmm1
    71e6bf3020f1:	movdqa xmm0,xmm3
    71e6bf3020f5:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    71e6bf3020ff:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    71e6bf302109:	movdqa xmm3,xmm0
    71e6bf30210d:	movdqa xmm1,xmm3
    71e6bf302111:	por    xmm3,xmm1
    71e6bf302115:	movdqa xmm0,xmm3
    71e6bf302119:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    71e6bf302123:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    71e6bf30212d:	movdqa xmm3,xmm0
    71e6bf302131:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    71e6bf30213b:	movdqa xmm4,xmm0
    71e6bf30213f:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf302147:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf302152:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf30215a:	movdqa xmm0,xmm3
    71e6bf30215e:	movdqa xmm1,xmm4
    71e6bf302162:	movq   rax,xmm0
    71e6bf302167:	add    rax,rax
    71e6bf30216a:	je     0x71e6bf302180
    71e6bf30216c:	shr    rax,0x35
    71e6bf302170:	sub    eax,0x201
    71e6bf302175:	cmp    eax,0x3fc
    71e6bf30217a:	ja     0x71e6bf3050df
    71e6bf302180:	movdqa xmm14,xmm0
    71e6bf302185:	psrldq xmm14,0x8
    71e6bf30218b:	movq   rax,xmm14
    71e6bf302190:	add    rax,rax
    71e6bf302193:	je     0x71e6bf3021a9
    71e6bf302195:	shr    rax,0x35
    71e6bf302199:	sub    eax,0x201
    71e6bf30219e:	cmp    eax,0x3fc
    71e6bf3021a3:	ja     0x71e6bf3050df
    71e6bf3021a9:	movq   rax,xmm1
    71e6bf3021ae:	add    rax,rax
    71e6bf3021b1:	je     0x71e6bf3021c7
    71e6bf3021b3:	shr    rax,0x35
    71e6bf3021b7:	sub    eax,0x201
    71e6bf3021bc:	cmp    eax,0x3fc
    71e6bf3021c1:	ja     0x71e6bf3050df
    71e6bf3021c7:	movdqa xmm14,xmm1
    71e6bf3021cc:	psrldq xmm14,0x8
    71e6bf3021d2:	movq   rax,xmm14
    71e6bf3021d7:	add    rax,rax
    71e6bf3021da:	je     0x71e6bf3021f0
    71e6bf3021dc:	shr    rax,0x35
    71e6bf3021e0:	sub    eax,0x201
    71e6bf3021e5:	cmp    eax,0x3fc
    71e6bf3021ea:	ja     0x71e6bf3050df
    71e6bf3021f0:	addpd  xmm0,xmm1
    71e6bf3021f4:	movdqa xmm5,xmm0
    71e6bf3021f8:	movdqa xmm0,xmm5
    71e6bf3021fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    71e6bf302206:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf302210:	movdqa xmm3,xmm0
    71e6bf302214:	movdqa xmm0,xmm2
    71e6bf302218:	movdqa xmm1,xmm3
    71e6bf30221c:	pshufd xmm1,xmm1,0x44
    71e6bf302221:	movq   rax,xmm0
    71e6bf302226:	add    rax,rax
    71e6bf302229:	je     0x71e6bf30223f
    71e6bf30222b:	shr    rax,0x35
    71e6bf30222f:	sub    eax,0x201
    71e6bf302234:	cmp    eax,0x3fc
    71e6bf302239:	ja     0x71e6bf305103
    71e6bf30223f:	movdqa xmm14,xmm0
    71e6bf302244:	psrldq xmm14,0x8
    71e6bf30224a:	movq   rax,xmm14
    71e6bf30224f:	add    rax,rax
    71e6bf302252:	je     0x71e6bf302268
    71e6bf302254:	shr    rax,0x35
    71e6bf302258:	sub    eax,0x201
    71e6bf30225d:	cmp    eax,0x3fc
    71e6bf302262:	ja     0x71e6bf305103
    71e6bf302268:	movq   rax,xmm1
    71e6bf30226d:	add    rax,rax
    71e6bf302270:	je     0x71e6bf302286
    71e6bf302272:	shr    rax,0x35
    71e6bf302276:	sub    eax,0x201
    71e6bf30227b:	cmp    eax,0x3fc
    71e6bf302280:	ja     0x71e6bf305103
    71e6bf302286:	movdqa xmm14,xmm1
    71e6bf30228b:	psrldq xmm14,0x8
    71e6bf302291:	movq   rax,xmm14
    71e6bf302296:	add    rax,rax
    71e6bf302299:	je     0x71e6bf3022af
    71e6bf30229b:	shr    rax,0x35
    71e6bf30229f:	sub    eax,0x201
    71e6bf3022a4:	cmp    eax,0x3fc
    71e6bf3022a9:	ja     0x71e6bf305103
    71e6bf3022af:	mulpd  xmm0,xmm1
    71e6bf3022b3:	movdqa xmm4,xmm0
    71e6bf3022b7:	movdqa xmm0,xmm4
    71e6bf3022bb:	movdqu XMMWORD PTR [r12+0x270],xmm0
    71e6bf3022c5:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf3022cd:	add    r13,0x80
    71e6bf3022d4:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf3022dc:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf3022e4:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf3022ec:	shr    r11d,1
    71e6bf3022ef:	and    r11d,0x10
    71e6bf3022f3:	or     DWORD PTR [r12+0x314],r11d
    71e6bf3022fb:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf302301:	movdqa xmm0,xmm2
    71e6bf302305:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf30230f:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf302319:	movdqa xmm3,xmm0
    71e6bf30231d:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    71e6bf302327:	movdqa xmm4,xmm0
    71e6bf30232b:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf302333:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf30233e:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf302346:	movdqa xmm0,xmm3
    71e6bf30234a:	movdqa xmm1,xmm4
    71e6bf30234e:	movq   rax,xmm0
    71e6bf302353:	add    rax,rax
    71e6bf302356:	je     0x71e6bf30236c
    71e6bf302358:	shr    rax,0x35
    71e6bf30235c:	sub    eax,0x201
    71e6bf302361:	cmp    eax,0x3fc
    71e6bf302366:	ja     0x71e6bf305127
    71e6bf30236c:	movdqa xmm14,xmm0
    71e6bf302371:	psrldq xmm14,0x8
    71e6bf302377:	movq   rax,xmm14
    71e6bf30237c:	add    rax,rax
    71e6bf30237f:	je     0x71e6bf302395
    71e6bf302381:	shr    rax,0x35
    71e6bf302385:	sub    eax,0x201
    71e6bf30238a:	cmp    eax,0x3fc
    71e6bf30238f:	ja     0x71e6bf305127
    71e6bf302395:	movq   rax,xmm1
    71e6bf30239a:	add    rax,rax
    71e6bf30239d:	je     0x71e6bf3023b3
    71e6bf30239f:	shr    rax,0x35
    71e6bf3023a3:	sub    eax,0x201
    71e6bf3023a8:	cmp    eax,0x3fc
    71e6bf3023ad:	ja     0x71e6bf305127
    71e6bf3023b3:	movdqa xmm14,xmm1
    71e6bf3023b8:	psrldq xmm14,0x8
    71e6bf3023be:	movq   rax,xmm14
    71e6bf3023c3:	add    rax,rax
    71e6bf3023c6:	je     0x71e6bf3023dc
    71e6bf3023c8:	shr    rax,0x35
    71e6bf3023cc:	sub    eax,0x201
    71e6bf3023d1:	cmp    eax,0x3fc
    71e6bf3023d6:	ja     0x71e6bf305127
    71e6bf3023dc:	addpd  xmm0,xmm1
    71e6bf3023e0:	movdqa xmm5,xmm0
    71e6bf3023e4:	movdqa xmm0,xmm5
    71e6bf3023e8:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf3023f2:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf3023fc:	movdqa xmm3,xmm0
    71e6bf302400:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    71e6bf30240a:	movdqa xmm4,xmm0
    71e6bf30240e:	movdqa xmm0,xmm3
    71e6bf302412:	movdqa xmm1,xmm4
    71e6bf302416:	movq   rax,xmm0
    71e6bf30241b:	add    rax,rax
    71e6bf30241e:	je     0x71e6bf302434
    71e6bf302420:	shr    rax,0x35
    71e6bf302424:	sub    eax,0x201
    71e6bf302429:	cmp    eax,0x3fc
    71e6bf30242e:	ja     0x71e6bf30514b
    71e6bf302434:	movdqa xmm14,xmm0
    71e6bf302439:	psrldq xmm14,0x8
    71e6bf30243f:	movq   rax,xmm14
    71e6bf302444:	add    rax,rax
    71e6bf302447:	je     0x71e6bf30245d
    71e6bf302449:	shr    rax,0x35
    71e6bf30244d:	sub    eax,0x201
    71e6bf302452:	cmp    eax,0x3fc
    71e6bf302457:	ja     0x71e6bf30514b
    71e6bf30245d:	movq   rax,xmm1
    71e6bf302462:	add    rax,rax
    71e6bf302465:	je     0x71e6bf30247b
    71e6bf302467:	shr    rax,0x35
    71e6bf30246b:	sub    eax,0x201
    71e6bf302470:	cmp    eax,0x3fc
    71e6bf302475:	ja     0x71e6bf30514b
    71e6bf30247b:	movdqa xmm14,xmm1
    71e6bf302480:	psrldq xmm14,0x8
    71e6bf302486:	movq   rax,xmm14
    71e6bf30248b:	add    rax,rax
    71e6bf30248e:	je     0x71e6bf3024a4
    71e6bf302490:	shr    rax,0x35
    71e6bf302494:	sub    eax,0x201
    71e6bf302499:	cmp    eax,0x3fc
    71e6bf30249e:	ja     0x71e6bf30514b
    71e6bf3024a4:	addpd  xmm0,xmm1
    71e6bf3024a8:	movdqa xmm5,xmm0
    71e6bf3024ac:	movdqa xmm0,xmm5
    71e6bf3024b0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf3024ba:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    71e6bf3024c4:	movdqa xmm3,xmm0
    71e6bf3024c8:	movdqa xmm1,xmm3
    71e6bf3024cc:	por    xmm3,xmm1
    71e6bf3024d0:	movdqa xmm0,xmm3
    71e6bf3024d4:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    71e6bf3024de:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf3024e8:	movdqa xmm3,xmm0
    71e6bf3024ec:	movdqa xmm0,xmm2
    71e6bf3024f0:	movdqa xmm1,xmm3
    71e6bf3024f4:	pshufd xmm1,xmm1,0x44
    71e6bf3024f9:	movq   rax,xmm0
    71e6bf3024fe:	add    rax,rax
    71e6bf302501:	je     0x71e6bf302517
    71e6bf302503:	shr    rax,0x35
    71e6bf302507:	sub    eax,0x201
    71e6bf30250c:	cmp    eax,0x3fc
    71e6bf302511:	ja     0x71e6bf30516f
    71e6bf302517:	movdqa xmm14,xmm0
    71e6bf30251c:	psrldq xmm14,0x8
    71e6bf302522:	movq   rax,xmm14
    71e6bf302527:	add    rax,rax
    71e6bf30252a:	je     0x71e6bf302540
    71e6bf30252c:	shr    rax,0x35
    71e6bf302530:	sub    eax,0x201
    71e6bf302535:	cmp    eax,0x3fc
    71e6bf30253a:	ja     0x71e6bf30516f
    71e6bf302540:	movq   rax,xmm1
    71e6bf302545:	add    rax,rax
    71e6bf302548:	je     0x71e6bf30255e
    71e6bf30254a:	shr    rax,0x35
    71e6bf30254e:	sub    eax,0x201
    71e6bf302553:	cmp    eax,0x3fc
    71e6bf302558:	ja     0x71e6bf30516f
    71e6bf30255e:	movdqa xmm14,xmm1
    71e6bf302563:	psrldq xmm14,0x8
    71e6bf302569:	movq   rax,xmm14
    71e6bf30256e:	add    rax,rax
    71e6bf302571:	je     0x71e6bf302587
    71e6bf302573:	shr    rax,0x35
    71e6bf302577:	sub    eax,0x201
    71e6bf30257c:	cmp    eax,0x3fc
    71e6bf302581:	ja     0x71e6bf30516f
    71e6bf302587:	mulpd  xmm0,xmm1
    71e6bf30258b:	movdqa xmm4,xmm0
    71e6bf30258f:	movdqa xmm0,xmm4
    71e6bf302593:	movdqu XMMWORD PTR [r12+0x170],xmm0
    71e6bf30259d:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf3025a5:	add    r13,0xd0
    71e6bf3025ac:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf3025b4:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf3025bc:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf3025c4:	shr    r11d,1
    71e6bf3025c7:	and    r11d,0x10
    71e6bf3025cb:	or     DWORD PTR [r12+0x314],r11d
    71e6bf3025d3:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf3025d9:	movdqa xmm0,xmm2
    71e6bf3025dd:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf3025e7:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf3025f1:	movdqa xmm3,xmm0
    71e6bf3025f5:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    71e6bf3025ff:	movdqa xmm4,xmm0
    71e6bf302603:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf30260b:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf302616:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf30261e:	movdqa xmm0,xmm3
    71e6bf302622:	movdqa xmm1,xmm4
    71e6bf302626:	movq   rax,xmm0
    71e6bf30262b:	add    rax,rax
    71e6bf30262e:	je     0x71e6bf302644
    71e6bf302630:	shr    rax,0x35
    71e6bf302634:	sub    eax,0x201
    71e6bf302639:	cmp    eax,0x3fc
    71e6bf30263e:	ja     0x71e6bf305193
    71e6bf302644:	movdqa xmm14,xmm0
    71e6bf302649:	psrldq xmm14,0x8
    71e6bf30264f:	movq   rax,xmm14
    71e6bf302654:	add    rax,rax
    71e6bf302657:	je     0x71e6bf30266d
    71e6bf302659:	shr    rax,0x35
    71e6bf30265d:	sub    eax,0x201
    71e6bf302662:	cmp    eax,0x3fc
    71e6bf302667:	ja     0x71e6bf305193
    71e6bf30266d:	movq   rax,xmm1
    71e6bf302672:	add    rax,rax
    71e6bf302675:	je     0x71e6bf30268b
    71e6bf302677:	shr    rax,0x35
    71e6bf30267b:	sub    eax,0x201
    71e6bf302680:	cmp    eax,0x3fc
    71e6bf302685:	ja     0x71e6bf305193
    71e6bf30268b:	movdqa xmm14,xmm1
    71e6bf302690:	psrldq xmm14,0x8
    71e6bf302696:	movq   rax,xmm14
    71e6bf30269b:	add    rax,rax
    71e6bf30269e:	je     0x71e6bf3026b4
    71e6bf3026a0:	shr    rax,0x35
    71e6bf3026a4:	sub    eax,0x201
    71e6bf3026a9:	cmp    eax,0x3fc
    71e6bf3026ae:	ja     0x71e6bf305193
    71e6bf3026b4:	addpd  xmm0,xmm1
    71e6bf3026b8:	movdqa xmm5,xmm0
    71e6bf3026bc:	movdqa xmm0,xmm5
    71e6bf3026c0:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf3026ca:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    71e6bf3026d4:	movdqa xmm3,xmm0
    71e6bf3026d8:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    71e6bf3026e2:	movdqa xmm4,xmm0
    71e6bf3026e6:	movdqa xmm0,xmm3
    71e6bf3026ea:	movdqa xmm1,xmm4
    71e6bf3026ee:	pshufd xmm1,xmm1,0x44
    71e6bf3026f3:	movq   rax,xmm0
    71e6bf3026f8:	add    rax,rax
    71e6bf3026fb:	je     0x71e6bf302711
    71e6bf3026fd:	shr    rax,0x35
    71e6bf302701:	sub    eax,0x201
    71e6bf302706:	cmp    eax,0x3fc
    71e6bf30270b:	ja     0x71e6bf3051b7
    71e6bf302711:	movdqa xmm14,xmm0
    71e6bf302716:	psrldq xmm14,0x8
    71e6bf30271c:	movq   rax,xmm14
    71e6bf302721:	add    rax,rax
    71e6bf302724:	je     0x71e6bf30273a
    71e6bf302726:	shr    rax,0x35
    71e6bf30272a:	sub    eax,0x201
    71e6bf30272f:	cmp    eax,0x3fc
    71e6bf302734:	ja     0x71e6bf3051b7
    71e6bf30273a:	movq   rax,xmm1
    71e6bf30273f:	add    rax,rax
    71e6bf302742:	je     0x71e6bf302758
    71e6bf302744:	shr    rax,0x35
    71e6bf302748:	sub    eax,0x201
    71e6bf30274d:	cmp    eax,0x3fc
    71e6bf302752:	ja     0x71e6bf3051b7
    71e6bf302758:	movdqa xmm14,xmm1
    71e6bf30275d:	psrldq xmm14,0x8
    71e6bf302763:	movq   rax,xmm14
    71e6bf302768:	add    rax,rax
    71e6bf30276b:	je     0x71e6bf302781
    71e6bf30276d:	shr    rax,0x35
    71e6bf302771:	sub    eax,0x201
    71e6bf302776:	cmp    eax,0x3fc
    71e6bf30277b:	ja     0x71e6bf3051b7
    71e6bf302781:	mulpd  xmm0,xmm1
    71e6bf302785:	movdqa xmm5,xmm0
    71e6bf302789:	movdqa xmm0,xmm5
    71e6bf30278d:	movdqu XMMWORD PTR [r12+0x260],xmm0
    71e6bf302797:	mov    r13d,0x0
    71e6bf30279d:	mov    r14d,0x0
    71e6bf3027a3:	mov    QWORD PTR [r12+0x1b0],r13
    71e6bf3027ab:	mov    QWORD PTR [r12+0x1b8],r14
    71e6bf3027b3:	movdqa xmm0,xmm2
    71e6bf3027b7:	movdqa xmm1,xmm4
    71e6bf3027bb:	pshufd xmm1,xmm1,0x44
    71e6bf3027c0:	movq   rax,xmm0
    71e6bf3027c5:	add    rax,rax
    71e6bf3027c8:	je     0x71e6bf3027de
    71e6bf3027ca:	shr    rax,0x35
    71e6bf3027ce:	sub    eax,0x201
    71e6bf3027d3:	cmp    eax,0x3fc
    71e6bf3027d8:	ja     0x71e6bf3051db
    71e6bf3027de:	movdqa xmm14,xmm0
    71e6bf3027e3:	psrldq xmm14,0x8
    71e6bf3027e9:	movq   rax,xmm14
    71e6bf3027ee:	add    rax,rax
    71e6bf3027f1:	je     0x71e6bf302807
    71e6bf3027f3:	shr    rax,0x35
    71e6bf3027f7:	sub    eax,0x201
    71e6bf3027fc:	cmp    eax,0x3fc
    71e6bf302801:	ja     0x71e6bf3051db
    71e6bf302807:	movq   rax,xmm1
    71e6bf30280c:	add    rax,rax
    71e6bf30280f:	je     0x71e6bf302825
    71e6bf302811:	shr    rax,0x35
    71e6bf302815:	sub    eax,0x201
    71e6bf30281a:	cmp    eax,0x3fc
    71e6bf30281f:	ja     0x71e6bf3051db
    71e6bf302825:	movdqa xmm14,xmm1
    71e6bf30282a:	psrldq xmm14,0x8
    71e6bf302830:	movq   rax,xmm14
    71e6bf302835:	add    rax,rax
    71e6bf302838:	je     0x71e6bf30284e
    71e6bf30283a:	shr    rax,0x35
    71e6bf30283e:	sub    eax,0x201
    71e6bf302843:	cmp    eax,0x3fc
    71e6bf302848:	ja     0x71e6bf3051db
    71e6bf30284e:	mulpd  xmm0,xmm1
    71e6bf302852:	movdqa xmm3,xmm0
    71e6bf302856:	movdqa xmm0,xmm3
    71e6bf30285a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    71e6bf302864:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf30286c:	mov    r14,r13
    71e6bf30286f:	add    r14,0xc0
    71e6bf302876:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf30287e:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf302886:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf30288e:	shr    r11d,1
    71e6bf302891:	and    r11d,0x10
    71e6bf302895:	or     DWORD PTR [r12+0x314],r11d
    71e6bf30289d:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf3028a2:	movdqa xmm0,xmm2
    71e6bf3028a6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf3028b0:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    71e6bf3028ba:	movdqa xmm3,xmm0
    71e6bf3028be:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    71e6bf3028c8:	movdqa xmm4,xmm0
    71e6bf3028cc:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf3028d4:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf3028df:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf3028e7:	movdqa xmm0,xmm3
    71e6bf3028eb:	movdqa xmm1,xmm4
    71e6bf3028ef:	movq   rax,xmm0
    71e6bf3028f4:	add    rax,rax
    71e6bf3028f7:	je     0x71e6bf30290d
    71e6bf3028f9:	shr    rax,0x35
    71e6bf3028fd:	sub    eax,0x201
    71e6bf302902:	cmp    eax,0x3fc
    71e6bf302907:	ja     0x71e6bf3051ff
    71e6bf30290d:	movdqa xmm14,xmm0
    71e6bf302912:	psrldq xmm14,0x8
    71e6bf302918:	movq   rax,xmm14
    71e6bf30291d:	add    rax,rax
    71e6bf302920:	je     0x71e6bf302936
    71e6bf302922:	shr    rax,0x35
    71e6bf302926:	sub    eax,0x201
    71e6bf30292b:	cmp    eax,0x3fc
    71e6bf302930:	ja     0x71e6bf3051ff
    71e6bf302936:	movq   rax,xmm1
    71e6bf30293b:	add    rax,rax
    71e6bf30293e:	je     0x71e6bf302954
    71e6bf302940:	shr    rax,0x35
    71e6bf302944:	sub    eax,0x201
    71e6bf302949:	cmp    eax,0x3fc
    71e6bf30294e:	ja     0x71e6bf3051ff
    71e6bf302954:	movdqa xmm14,xmm1
    71e6bf302959:	psrldq xmm14,0x8
    71e6bf30295f:	movq   rax,xmm14
    71e6bf302964:	add    rax,rax
    71e6bf302967:	je     0x71e6bf30297d
    71e6bf302969:	shr    rax,0x35
    71e6bf30296d:	sub    eax,0x201
    71e6bf302972:	cmp    eax,0x3fc
    71e6bf302977:	ja     0x71e6bf3051ff
    71e6bf30297d:	addpd  xmm0,xmm1
    71e6bf302981:	movdqa xmm5,xmm0
    71e6bf302985:	movdqa xmm0,xmm5
    71e6bf302989:	movdqu XMMWORD PTR [r12+0x240],xmm0
    71e6bf302993:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    71e6bf30299d:	movdqa xmm3,xmm0
    71e6bf3029a1:	movdqa xmm1,xmm3
    71e6bf3029a5:	por    xmm3,xmm1
    71e6bf3029a9:	movdqa xmm0,xmm3
    71e6bf3029ad:	movdqu XMMWORD PTR [r12+0x270],xmm0
    71e6bf3029b7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    71e6bf3029c1:	movdqa xmm3,xmm0
    71e6bf3029c5:	movdqa xmm1,xmm3
    71e6bf3029c9:	por    xmm3,xmm1
    71e6bf3029cd:	movdqa xmm0,xmm3
    71e6bf3029d1:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    71e6bf3029db:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    71e6bf3029e5:	movdqa xmm3,xmm0
    71e6bf3029e9:	movdqa xmm0,xmm2
    71e6bf3029ed:	movdqa xmm1,xmm3
    71e6bf3029f1:	pshufd xmm1,xmm1,0x44
    71e6bf3029f6:	movq   rax,xmm0
    71e6bf3029fb:	add    rax,rax
    71e6bf3029fe:	je     0x71e6bf302a14
    71e6bf302a00:	shr    rax,0x35
    71e6bf302a04:	sub    eax,0x201
    71e6bf302a09:	cmp    eax,0x3fc
    71e6bf302a0e:	ja     0x71e6bf305223
    71e6bf302a14:	movdqa xmm14,xmm0
    71e6bf302a19:	psrldq xmm14,0x8
    71e6bf302a1f:	movq   rax,xmm14
    71e6bf302a24:	add    rax,rax
    71e6bf302a27:	je     0x71e6bf302a3d
    71e6bf302a29:	shr    rax,0x35
    71e6bf302a2d:	sub    eax,0x201
    71e6bf302a32:	cmp    eax,0x3fc
    71e6bf302a37:	ja     0x71e6bf305223
    71e6bf302a3d:	movq   rax,xmm1
    71e6bf302a42:	add    rax,rax
    71e6bf302a45:	je     0x71e6bf302a5b
    71e6bf302a47:	shr    rax,0x35
    71e6bf302a4b:	sub    eax,0x201
    71e6bf302a50:	cmp    eax,0x3fc
    71e6bf302a55:	ja     0x71e6bf305223
    71e6bf302a5b:	movdqa xmm14,xmm1
    71e6bf302a60:	psrldq xmm14,0x8
    71e6bf302a66:	movq   rax,xmm14
    71e6bf302a6b:	add    rax,rax
    71e6bf302a6e:	je     0x71e6bf302a84
    71e6bf302a70:	shr    rax,0x35
    71e6bf302a74:	sub    eax,0x201
    71e6bf302a79:	cmp    eax,0x3fc
    71e6bf302a7e:	ja     0x71e6bf305223
    71e6bf302a84:	mulpd  xmm0,xmm1
    71e6bf302a88:	movdqa xmm4,xmm0
    71e6bf302a8c:	movdqa xmm0,xmm4
    71e6bf302a90:	movdqu XMMWORD PTR [r12+0x250],xmm0
    71e6bf302a9a:	add    r13,0x20
    71e6bf302a9e:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf302aa6:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf302aae:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf302ab6:	shr    r11d,1
    71e6bf302ab9:	and    r11d,0x10
    71e6bf302abd:	or     DWORD PTR [r12+0x314],r11d
    71e6bf302ac5:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf302acb:	movdqa xmm0,xmm2
    71e6bf302acf:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf302ad9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf302ae3:	movdqa xmm2,xmm0
    71e6bf302ae7:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf302af1:	movdqa xmm4,xmm0
    71e6bf302af5:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf302afd:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf302b08:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf302b10:	movdqa xmm0,xmm2
    71e6bf302b14:	movdqa xmm1,xmm4
    71e6bf302b18:	movq   rax,xmm0
    71e6bf302b1d:	add    rax,rax
    71e6bf302b20:	je     0x71e6bf302b36
    71e6bf302b22:	shr    rax,0x35
    71e6bf302b26:	sub    eax,0x201
    71e6bf302b2b:	cmp    eax,0x3fc
    71e6bf302b30:	ja     0x71e6bf305247
    71e6bf302b36:	movdqa xmm14,xmm0
    71e6bf302b3b:	psrldq xmm14,0x8
    71e6bf302b41:	movq   rax,xmm14
    71e6bf302b46:	add    rax,rax
    71e6bf302b49:	je     0x71e6bf302b5f
    71e6bf302b4b:	shr    rax,0x35
    71e6bf302b4f:	sub    eax,0x201
    71e6bf302b54:	cmp    eax,0x3fc
    71e6bf302b59:	ja     0x71e6bf305247
    71e6bf302b5f:	movq   rax,xmm1
    71e6bf302b64:	add    rax,rax
    71e6bf302b67:	je     0x71e6bf302b7d
    71e6bf302b69:	shr    rax,0x35
    71e6bf302b6d:	sub    eax,0x201
    71e6bf302b72:	cmp    eax,0x3fc
    71e6bf302b77:	ja     0x71e6bf305247
    71e6bf302b7d:	movdqa xmm14,xmm1
    71e6bf302b82:	psrldq xmm14,0x8
    71e6bf302b88:	movq   rax,xmm14
    71e6bf302b8d:	add    rax,rax
    71e6bf302b90:	je     0x71e6bf302ba6
    71e6bf302b92:	shr    rax,0x35
    71e6bf302b96:	sub    eax,0x201
    71e6bf302b9b:	cmp    eax,0x3fc
    71e6bf302ba0:	ja     0x71e6bf305247
    71e6bf302ba6:	addpd  xmm0,xmm1
    71e6bf302baa:	movdqa xmm5,xmm0
    71e6bf302bae:	movdqa xmm0,xmm5
    71e6bf302bb2:	movdqu XMMWORD PTR [r12+0x170],xmm0
    71e6bf302bbc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    71e6bf302bc6:	movdqa xmm2,xmm0
    71e6bf302bca:	movdqa xmm0,xmm2
    71e6bf302bce:	movdqa xmm1,xmm3
    71e6bf302bd2:	pshufd xmm1,xmm1,0x44
    71e6bf302bd7:	movq   rax,xmm0
    71e6bf302bdc:	add    rax,rax
    71e6bf302bdf:	je     0x71e6bf302bf5
    71e6bf302be1:	shr    rax,0x35
    71e6bf302be5:	sub    eax,0x201
    71e6bf302bea:	cmp    eax,0x3fc
    71e6bf302bef:	ja     0x71e6bf30526b
    71e6bf302bf5:	movdqa xmm14,xmm0
    71e6bf302bfa:	psrldq xmm14,0x8
    71e6bf302c00:	movq   rax,xmm14
    71e6bf302c05:	add    rax,rax
    71e6bf302c08:	je     0x71e6bf302c1e
    71e6bf302c0a:	shr    rax,0x35
    71e6bf302c0e:	sub    eax,0x201
    71e6bf302c13:	cmp    eax,0x3fc
    71e6bf302c18:	ja     0x71e6bf30526b
    71e6bf302c1e:	movq   rax,xmm1
    71e6bf302c23:	add    rax,rax
    71e6bf302c26:	je     0x71e6bf302c3c
    71e6bf302c28:	shr    rax,0x35
    71e6bf302c2c:	sub    eax,0x201
    71e6bf302c31:	cmp    eax,0x3fc
    71e6bf302c36:	ja     0x71e6bf30526b
    71e6bf302c3c:	movdqa xmm14,xmm1
    71e6bf302c41:	psrldq xmm14,0x8
    71e6bf302c47:	movq   rax,xmm14
    71e6bf302c4c:	add    rax,rax
    71e6bf302c4f:	je     0x71e6bf302c65
    71e6bf302c51:	shr    rax,0x35
    71e6bf302c55:	sub    eax,0x201
    71e6bf302c5a:	cmp    eax,0x3fc
    71e6bf302c5f:	ja     0x71e6bf30526b
    71e6bf302c65:	mulpd  xmm0,xmm1
    71e6bf302c69:	movdqa xmm4,xmm0
    71e6bf302c6d:	movdqa xmm0,xmm4
    71e6bf302c71:	movdqu XMMWORD PTR [r12+0x160],xmm0
    71e6bf302c7b:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf302c85:	movdqa xmm2,xmm0
    71e6bf302c89:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    71e6bf302c93:	movdqa xmm3,xmm0
    71e6bf302c97:	movdqa xmm0,xmm2
    71e6bf302c9b:	movdqa xmm1,xmm3
    71e6bf302c9f:	movq   rax,xmm0
    71e6bf302ca4:	add    rax,rax
    71e6bf302ca7:	je     0x71e6bf302cbd
    71e6bf302ca9:	shr    rax,0x35
    71e6bf302cad:	sub    eax,0x201
    71e6bf302cb2:	cmp    eax,0x3fc
    71e6bf302cb7:	ja     0x71e6bf30528f
    71e6bf302cbd:	movdqa xmm14,xmm0
    71e6bf302cc2:	psrldq xmm14,0x8
    71e6bf302cc8:	movq   rax,xmm14
    71e6bf302ccd:	add    rax,rax
    71e6bf302cd0:	je     0x71e6bf302ce6
    71e6bf302cd2:	shr    rax,0x35
    71e6bf302cd6:	sub    eax,0x201
    71e6bf302cdb:	cmp    eax,0x3fc
    71e6bf302ce0:	ja     0x71e6bf30528f
    71e6bf302ce6:	movq   rax,xmm1
    71e6bf302ceb:	add    rax,rax
    71e6bf302cee:	je     0x71e6bf302d04
    71e6bf302cf0:	shr    rax,0x35
    71e6bf302cf4:	sub    eax,0x201
    71e6bf302cf9:	cmp    eax,0x3fc
    71e6bf302cfe:	ja     0x71e6bf30528f
    71e6bf302d04:	movdqa xmm14,xmm1
    71e6bf302d09:	psrldq xmm14,0x8
    71e6bf302d0f:	movq   rax,xmm14
    71e6bf302d14:	add    rax,rax
    71e6bf302d17:	je     0x71e6bf302d2d
    71e6bf302d19:	shr    rax,0x35
    71e6bf302d1d:	sub    eax,0x201
    71e6bf302d22:	cmp    eax,0x3fc
    71e6bf302d27:	ja     0x71e6bf30528f
    71e6bf302d2d:	addpd  xmm0,xmm1
    71e6bf302d31:	movdqa xmm4,xmm0
    71e6bf302d35:	movdqa xmm0,xmm4
    71e6bf302d39:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf302d43:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf302d4d:	movdqa xmm2,xmm0
    71e6bf302d51:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    71e6bf302d5b:	movdqa xmm3,xmm0
    71e6bf302d5f:	movdqa xmm0,xmm2
    71e6bf302d63:	movdqa xmm1,xmm3
    71e6bf302d67:	pshufd xmm1,xmm1,0x44
    71e6bf302d6c:	movq   rax,xmm0
    71e6bf302d71:	add    rax,rax
    71e6bf302d74:	je     0x71e6bf302d8a
    71e6bf302d76:	shr    rax,0x35
    71e6bf302d7a:	sub    eax,0x201
    71e6bf302d7f:	cmp    eax,0x3fc
    71e6bf302d84:	ja     0x71e6bf3052b3
    71e6bf302d8a:	movdqa xmm14,xmm0
    71e6bf302d8f:	psrldq xmm14,0x8
    71e6bf302d95:	movq   rax,xmm14
    71e6bf302d9a:	add    rax,rax
    71e6bf302d9d:	je     0x71e6bf302db3
    71e6bf302d9f:	shr    rax,0x35
    71e6bf302da3:	sub    eax,0x201
    71e6bf302da8:	cmp    eax,0x3fc
    71e6bf302dad:	ja     0x71e6bf3052b3
    71e6bf302db3:	movq   rax,xmm1
    71e6bf302db8:	add    rax,rax
    71e6bf302dbb:	je     0x71e6bf302dd1
    71e6bf302dbd:	shr    rax,0x35
    71e6bf302dc1:	sub    eax,0x201
    71e6bf302dc6:	cmp    eax,0x3fc
    71e6bf302dcb:	ja     0x71e6bf3052b3
    71e6bf302dd1:	movdqa xmm14,xmm1
    71e6bf302dd6:	psrldq xmm14,0x8
    71e6bf302ddc:	movq   rax,xmm14
    71e6bf302de1:	add    rax,rax
    71e6bf302de4:	je     0x71e6bf302dfa
    71e6bf302de6:	shr    rax,0x35
    71e6bf302dea:	sub    eax,0x201
    71e6bf302def:	cmp    eax,0x3fc
    71e6bf302df4:	ja     0x71e6bf3052b3
    71e6bf302dfa:	mulpd  xmm0,xmm1
    71e6bf302dfe:	movdqa xmm4,xmm0
    71e6bf302e02:	movdqa xmm0,xmm4
    71e6bf302e06:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf302e10:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    71e6bf302e1a:	movdqa xmm2,xmm0
    71e6bf302e1e:	movdqa xmm0,xmm2
    71e6bf302e22:	movdqa xmm1,xmm3
    71e6bf302e26:	pshufd xmm1,xmm1,0x44
    71e6bf302e2b:	movq   rax,xmm0
    71e6bf302e30:	add    rax,rax
    71e6bf302e33:	je     0x71e6bf302e49
    71e6bf302e35:	shr    rax,0x35
    71e6bf302e39:	sub    eax,0x201
    71e6bf302e3e:	cmp    eax,0x3fc
    71e6bf302e43:	ja     0x71e6bf3052d7
    71e6bf302e49:	movdqa xmm14,xmm0
    71e6bf302e4e:	psrldq xmm14,0x8
    71e6bf302e54:	movq   rax,xmm14
    71e6bf302e59:	add    rax,rax
    71e6bf302e5c:	je     0x71e6bf302e72
    71e6bf302e5e:	shr    rax,0x35
    71e6bf302e62:	sub    eax,0x201
    71e6bf302e67:	cmp    eax,0x3fc
    71e6bf302e6c:	ja     0x71e6bf3052d7
    71e6bf302e72:	movq   rax,xmm1
    71e6bf302e77:	add    rax,rax
    71e6bf302e7a:	je     0x71e6bf302e90
    71e6bf302e7c:	shr    rax,0x35
    71e6bf302e80:	sub    eax,0x201
    71e6bf302e85:	cmp    eax,0x3fc
    71e6bf302e8a:	ja     0x71e6bf3052d7
    71e6bf302e90:	movdqa xmm14,xmm1
    71e6bf302e95:	psrldq xmm14,0x8
    71e6bf302e9b:	movq   rax,xmm14
    71e6bf302ea0:	add    rax,rax
    71e6bf302ea3:	je     0x71e6bf302eb9
    71e6bf302ea5:	shr    rax,0x35
    71e6bf302ea9:	sub    eax,0x201
    71e6bf302eae:	cmp    eax,0x3fc
    71e6bf302eb3:	ja     0x71e6bf3052d7
    71e6bf302eb9:	mulpd  xmm0,xmm1
    71e6bf302ebd:	movdqa xmm4,xmm0
    71e6bf302ec1:	movdqa xmm0,xmm4
    71e6bf302ec5:	movdqu XMMWORD PTR [r12+0x230],xmm0
    71e6bf302ecf:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    71e6bf302ed9:	movdqa xmm2,xmm0
    71e6bf302edd:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    71e6bf302ee7:	movdqa xmm4,xmm0
    71e6bf302eeb:	movdqa xmm0,xmm2
    71e6bf302eef:	movdqa xmm1,xmm4
    71e6bf302ef3:	movq   rax,xmm0
    71e6bf302ef8:	add    rax,rax
    71e6bf302efb:	je     0x71e6bf302f11
    71e6bf302efd:	shr    rax,0x35
    71e6bf302f01:	sub    eax,0x201
    71e6bf302f06:	cmp    eax,0x3fc
    71e6bf302f0b:	ja     0x71e6bf3052fb
    71e6bf302f11:	movdqa xmm14,xmm0
    71e6bf302f16:	psrldq xmm14,0x8
    71e6bf302f1c:	movq   rax,xmm14
    71e6bf302f21:	add    rax,rax
    71e6bf302f24:	je     0x71e6bf302f3a
    71e6bf302f26:	shr    rax,0x35
    71e6bf302f2a:	sub    eax,0x201
    71e6bf302f2f:	cmp    eax,0x3fc
    71e6bf302f34:	ja     0x71e6bf3052fb
    71e6bf302f3a:	movq   rax,xmm1
    71e6bf302f3f:	add    rax,rax
    71e6bf302f42:	je     0x71e6bf302f58
    71e6bf302f44:	shr    rax,0x35
    71e6bf302f48:	sub    eax,0x201
    71e6bf302f4d:	cmp    eax,0x3fc
    71e6bf302f52:	ja     0x71e6bf3052fb
    71e6bf302f58:	movdqa xmm14,xmm1
    71e6bf302f5d:	psrldq xmm14,0x8
    71e6bf302f63:	movq   rax,xmm14
    71e6bf302f68:	add    rax,rax
    71e6bf302f6b:	je     0x71e6bf302f81
    71e6bf302f6d:	shr    rax,0x35
    71e6bf302f71:	sub    eax,0x201
    71e6bf302f76:	cmp    eax,0x3fc
    71e6bf302f7b:	ja     0x71e6bf3052fb
    71e6bf302f81:	addpd  xmm0,xmm1
    71e6bf302f85:	movdqa xmm5,xmm0
    71e6bf302f89:	movdqa xmm0,xmm5
    71e6bf302f8d:	movdqu XMMWORD PTR [r12+0x240],xmm0
    71e6bf302f97:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf302fa1:	movdqa xmm2,xmm0
    71e6bf302fa5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    71e6bf302faf:	movdqa xmm4,xmm0
    71e6bf302fb3:	movdqa xmm0,xmm2
    71e6bf302fb7:	movdqa xmm1,xmm4
    71e6bf302fbb:	movq   rax,xmm0
    71e6bf302fc0:	add    rax,rax
    71e6bf302fc3:	je     0x71e6bf302fd9
    71e6bf302fc5:	shr    rax,0x35
    71e6bf302fc9:	sub    eax,0x201
    71e6bf302fce:	cmp    eax,0x3fc
    71e6bf302fd3:	ja     0x71e6bf30531f
    71e6bf302fd9:	movdqa xmm14,xmm0
    71e6bf302fde:	psrldq xmm14,0x8
    71e6bf302fe4:	movq   rax,xmm14
    71e6bf302fe9:	add    rax,rax
    71e6bf302fec:	je     0x71e6bf303002
    71e6bf302fee:	shr    rax,0x35
    71e6bf302ff2:	sub    eax,0x201
    71e6bf302ff7:	cmp    eax,0x3fc
    71e6bf302ffc:	ja     0x71e6bf30531f
    71e6bf303002:	movq   rax,xmm1
    71e6bf303007:	add    rax,rax
    71e6bf30300a:	je     0x71e6bf303020
    71e6bf30300c:	shr    rax,0x35
    71e6bf303010:	sub    eax,0x201
    71e6bf303015:	cmp    eax,0x3fc
    71e6bf30301a:	ja     0x71e6bf30531f
    71e6bf303020:	movdqa xmm14,xmm1
    71e6bf303025:	psrldq xmm14,0x8
    71e6bf30302b:	movq   rax,xmm14
    71e6bf303030:	add    rax,rax
    71e6bf303033:	je     0x71e6bf303049
    71e6bf303035:	shr    rax,0x35
    71e6bf303039:	sub    eax,0x201
    71e6bf30303e:	cmp    eax,0x3fc
    71e6bf303043:	ja     0x71e6bf30531f
    71e6bf303049:	addpd  xmm0,xmm1
    71e6bf30304d:	movdqa xmm5,xmm0
    71e6bf303051:	movdqa xmm0,xmm5
    71e6bf303055:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf30305f:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    71e6bf303069:	movdqa xmm2,xmm0
    71e6bf30306d:	movdqa xmm0,xmm2
    71e6bf303071:	movdqa xmm1,xmm3
    71e6bf303075:	pshufd xmm1,xmm1,0x44
    71e6bf30307a:	movq   rax,xmm0
    71e6bf30307f:	add    rax,rax
    71e6bf303082:	je     0x71e6bf303098
    71e6bf303084:	shr    rax,0x35
    71e6bf303088:	sub    eax,0x201
    71e6bf30308d:	cmp    eax,0x3fc
    71e6bf303092:	ja     0x71e6bf305343
    71e6bf303098:	movdqa xmm14,xmm0
    71e6bf30309d:	psrldq xmm14,0x8
    71e6bf3030a3:	movq   rax,xmm14
    71e6bf3030a8:	add    rax,rax
    71e6bf3030ab:	je     0x71e6bf3030c1
    71e6bf3030ad:	shr    rax,0x35
    71e6bf3030b1:	sub    eax,0x201
    71e6bf3030b6:	cmp    eax,0x3fc
    71e6bf3030bb:	ja     0x71e6bf305343
    71e6bf3030c1:	movq   rax,xmm1
    71e6bf3030c6:	add    rax,rax
    71e6bf3030c9:	je     0x71e6bf3030df
    71e6bf3030cb:	shr    rax,0x35
    71e6bf3030cf:	sub    eax,0x201
    71e6bf3030d4:	cmp    eax,0x3fc
    71e6bf3030d9:	ja     0x71e6bf305343
    71e6bf3030df:	movdqa xmm14,xmm1
    71e6bf3030e4:	psrldq xmm14,0x8
    71e6bf3030ea:	movq   rax,xmm14
    71e6bf3030ef:	add    rax,rax
    71e6bf3030f2:	je     0x71e6bf303108
    71e6bf3030f4:	shr    rax,0x35
    71e6bf3030f8:	sub    eax,0x201
    71e6bf3030fd:	cmp    eax,0x3fc
    71e6bf303102:	ja     0x71e6bf305343
    71e6bf303108:	mulpd  xmm0,xmm1
    71e6bf30310c:	movdqa xmm4,xmm0
    71e6bf303110:	movdqa xmm0,xmm4
    71e6bf303114:	movdqu XMMWORD PTR [r12+0x250],xmm0
    71e6bf30311e:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    71e6bf303128:	movdqa xmm2,xmm0
    71e6bf30312c:	movdqa xmm0,xmm2
    71e6bf303130:	movdqa xmm1,xmm3
    71e6bf303134:	pshufd xmm1,xmm1,0x44
    71e6bf303139:	movq   rax,xmm0
    71e6bf30313e:	add    rax,rax
    71e6bf303141:	je     0x71e6bf303157
    71e6bf303143:	shr    rax,0x35
    71e6bf303147:	sub    eax,0x201
    71e6bf30314c:	cmp    eax,0x3fc
    71e6bf303151:	ja     0x71e6bf305367
    71e6bf303157:	movdqa xmm14,xmm0
    71e6bf30315c:	psrldq xmm14,0x8
    71e6bf303162:	movq   rax,xmm14
    71e6bf303167:	add    rax,rax
    71e6bf30316a:	je     0x71e6bf303180
    71e6bf30316c:	shr    rax,0x35
    71e6bf303170:	sub    eax,0x201
    71e6bf303175:	cmp    eax,0x3fc
    71e6bf30317a:	ja     0x71e6bf305367
    71e6bf303180:	movq   rax,xmm1
    71e6bf303185:	add    rax,rax
    71e6bf303188:	je     0x71e6bf30319e
    71e6bf30318a:	shr    rax,0x35
    71e6bf30318e:	sub    eax,0x201
    71e6bf303193:	cmp    eax,0x3fc
    71e6bf303198:	ja     0x71e6bf305367
    71e6bf30319e:	movdqa xmm14,xmm1
    71e6bf3031a3:	psrldq xmm14,0x8
    71e6bf3031a9:	movq   rax,xmm14
    71e6bf3031ae:	add    rax,rax
    71e6bf3031b1:	je     0x71e6bf3031c7
    71e6bf3031b3:	shr    rax,0x35
    71e6bf3031b7:	sub    eax,0x201
    71e6bf3031bc:	cmp    eax,0x3fc
    71e6bf3031c1:	ja     0x71e6bf305367
    71e6bf3031c7:	mulpd  xmm0,xmm1
    71e6bf3031cb:	movdqa xmm4,xmm0
    71e6bf3031cf:	movdqa xmm0,xmm4
    71e6bf3031d3:	movdqu XMMWORD PTR [r12+0x150],xmm0
    71e6bf3031dd:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf3031e7:	movdqa xmm2,xmm0
    71e6bf3031eb:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    71e6bf3031f5:	movdqa xmm3,xmm0
    71e6bf3031f9:	movdqa xmm0,xmm2
    71e6bf3031fd:	movdqa xmm1,xmm3
    71e6bf303201:	movq   rax,xmm0
    71e6bf303206:	add    rax,rax
    71e6bf303209:	je     0x71e6bf30321f
    71e6bf30320b:	shr    rax,0x35
    71e6bf30320f:	sub    eax,0x201
    71e6bf303214:	cmp    eax,0x3fc
    71e6bf303219:	ja     0x71e6bf30538b
    71e6bf30321f:	movdqa xmm14,xmm0
    71e6bf303224:	psrldq xmm14,0x8
    71e6bf30322a:	movq   rax,xmm14
    71e6bf30322f:	add    rax,rax
    71e6bf303232:	je     0x71e6bf303248
    71e6bf303234:	shr    rax,0x35
    71e6bf303238:	sub    eax,0x201
    71e6bf30323d:	cmp    eax,0x3fc
    71e6bf303242:	ja     0x71e6bf30538b
    71e6bf303248:	movq   rax,xmm1
    71e6bf30324d:	add    rax,rax
    71e6bf303250:	je     0x71e6bf303266
    71e6bf303252:	shr    rax,0x35
    71e6bf303256:	sub    eax,0x201
    71e6bf30325b:	cmp    eax,0x3fc
    71e6bf303260:	ja     0x71e6bf30538b
    71e6bf303266:	movdqa xmm14,xmm1
    71e6bf30326b:	psrldq xmm14,0x8
    71e6bf303271:	movq   rax,xmm14
    71e6bf303276:	add    rax,rax
    71e6bf303279:	je     0x71e6bf30328f
    71e6bf30327b:	shr    rax,0x35
    71e6bf30327f:	sub    eax,0x201
    71e6bf303284:	cmp    eax,0x3fc
    71e6bf303289:	ja     0x71e6bf30538b
    71e6bf30328f:	addpd  xmm0,xmm1
    71e6bf303293:	movdqa xmm4,xmm0
    71e6bf303297:	movdqa xmm0,xmm4
    71e6bf30329b:	movdqu XMMWORD PTR [r12+0x160],xmm0
    71e6bf3032a5:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf3032af:	movdqa xmm2,xmm0
    71e6bf3032b3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf3032bd:	movdqa xmm3,xmm0
    71e6bf3032c1:	movdqa xmm0,xmm2
    71e6bf3032c5:	movdqa xmm1,xmm3
    71e6bf3032c9:	movq   rax,xmm0
    71e6bf3032ce:	add    rax,rax
    71e6bf3032d1:	je     0x71e6bf3032e7
    71e6bf3032d3:	shr    rax,0x35
    71e6bf3032d7:	sub    eax,0x201
    71e6bf3032dc:	cmp    eax,0x3fc
    71e6bf3032e1:	ja     0x71e6bf3053af
    71e6bf3032e7:	movdqa xmm14,xmm0
    71e6bf3032ec:	psrldq xmm14,0x8
    71e6bf3032f2:	movq   rax,xmm14
    71e6bf3032f7:	add    rax,rax
    71e6bf3032fa:	je     0x71e6bf303310
    71e6bf3032fc:	shr    rax,0x35
    71e6bf303300:	sub    eax,0x201
    71e6bf303305:	cmp    eax,0x3fc
    71e6bf30330a:	ja     0x71e6bf3053af
    71e6bf303310:	movq   rax,xmm1
    71e6bf303315:	add    rax,rax
    71e6bf303318:	je     0x71e6bf30332e
    71e6bf30331a:	shr    rax,0x35
    71e6bf30331e:	sub    eax,0x201
    71e6bf303323:	cmp    eax,0x3fc
    71e6bf303328:	ja     0x71e6bf3053af
    71e6bf30332e:	movdqa xmm14,xmm1
    71e6bf303333:	psrldq xmm14,0x8
    71e6bf303339:	movq   rax,xmm14
    71e6bf30333e:	add    rax,rax
    71e6bf303341:	je     0x71e6bf303357
    71e6bf303343:	shr    rax,0x35
    71e6bf303347:	sub    eax,0x201
    71e6bf30334c:	cmp    eax,0x3fc
    71e6bf303351:	ja     0x71e6bf3053af
    71e6bf303357:	addpd  xmm0,xmm1
    71e6bf30335b:	movdqa xmm4,xmm0
    71e6bf30335f:	movdqa xmm0,xmm4
    71e6bf303363:	movdqu XMMWORD PTR [r12+0x170],xmm0
    71e6bf30336d:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    71e6bf303377:	movdqa xmm2,xmm0
    71e6bf30337b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    71e6bf303385:	movdqa xmm3,xmm0
    71e6bf303389:	movdqa xmm0,xmm2
    71e6bf30338d:	movdqa xmm1,xmm3
    71e6bf303391:	pshufd xmm1,xmm1,0x44
    71e6bf303396:	movq   rax,xmm0
    71e6bf30339b:	add    rax,rax
    71e6bf30339e:	je     0x71e6bf3033b4
    71e6bf3033a0:	shr    rax,0x35
    71e6bf3033a4:	sub    eax,0x201
    71e6bf3033a9:	cmp    eax,0x3fc
    71e6bf3033ae:	ja     0x71e6bf3053d3
    71e6bf3033b4:	movdqa xmm14,xmm0
    71e6bf3033b9:	psrldq xmm14,0x8
    71e6bf3033bf:	movq   rax,xmm14
    71e6bf3033c4:	add    rax,rax
    71e6bf3033c7:	je     0x71e6bf3033dd
    71e6bf3033c9:	shr    rax,0x35
    71e6bf3033cd:	sub    eax,0x201
    71e6bf3033d2:	cmp    eax,0x3fc
    71e6bf3033d7:	ja     0x71e6bf3053d3
    71e6bf3033dd:	movq   rax,xmm1
    71e6bf3033e2:	add    rax,rax
    71e6bf3033e5:	je     0x71e6bf3033fb
    71e6bf3033e7:	shr    rax,0x35
    71e6bf3033eb:	sub    eax,0x201
    71e6bf3033f0:	cmp    eax,0x3fc
    71e6bf3033f5:	ja     0x71e6bf3053d3
    71e6bf3033fb:	movdqa xmm14,xmm1
    71e6bf303400:	psrldq xmm14,0x8
    71e6bf303406:	movq   rax,xmm14
    71e6bf30340b:	add    rax,rax
    71e6bf30340e:	je     0x71e6bf303424
    71e6bf303410:	shr    rax,0x35
    71e6bf303414:	sub    eax,0x201
    71e6bf303419:	cmp    eax,0x3fc
    71e6bf30341e:	ja     0x71e6bf3053d3
    71e6bf303424:	mulpd  xmm0,xmm1
    71e6bf303428:	movdqa xmm4,xmm0
    71e6bf30342c:	movdqa xmm0,xmm4
    71e6bf303430:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf30343a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf303444:	movdqa xmm2,xmm0
    71e6bf303448:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    71e6bf303452:	movdqa xmm3,xmm0
    71e6bf303456:	movdqa xmm0,xmm2
    71e6bf30345a:	movdqa xmm1,xmm3
    71e6bf30345e:	movq   rax,xmm0
    71e6bf303463:	add    rax,rax
    71e6bf303466:	je     0x71e6bf30347c
    71e6bf303468:	shr    rax,0x35
    71e6bf30346c:	sub    eax,0x201
    71e6bf303471:	cmp    eax,0x3fc
    71e6bf303476:	ja     0x71e6bf3053f7
    71e6bf30347c:	movdqa xmm14,xmm0
    71e6bf303481:	psrldq xmm14,0x8
    71e6bf303487:	movq   rax,xmm14
    71e6bf30348c:	add    rax,rax
    71e6bf30348f:	je     0x71e6bf3034a5
    71e6bf303491:	shr    rax,0x35
    71e6bf303495:	sub    eax,0x201
    71e6bf30349a:	cmp    eax,0x3fc
    71e6bf30349f:	ja     0x71e6bf3053f7
    71e6bf3034a5:	movq   rax,xmm1
    71e6bf3034aa:	add    rax,rax
    71e6bf3034ad:	je     0x71e6bf3034c3
    71e6bf3034af:	shr    rax,0x35
    71e6bf3034b3:	sub    eax,0x201
    71e6bf3034b8:	cmp    eax,0x3fc
    71e6bf3034bd:	ja     0x71e6bf3053f7
    71e6bf3034c3:	movdqa xmm14,xmm1
    71e6bf3034c8:	psrldq xmm14,0x8
    71e6bf3034ce:	movq   rax,xmm14
    71e6bf3034d3:	add    rax,rax
    71e6bf3034d6:	je     0x71e6bf3034ec
    71e6bf3034d8:	shr    rax,0x35
    71e6bf3034dc:	sub    eax,0x201
    71e6bf3034e1:	cmp    eax,0x3fc
    71e6bf3034e6:	ja     0x71e6bf3053f7
    71e6bf3034ec:	addpd  xmm0,xmm1
    71e6bf3034f0:	movdqa xmm4,xmm0
    71e6bf3034f4:	movdqa xmm0,xmm4
    71e6bf3034f8:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf303502:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    71e6bf30350c:	movdqa xmm2,xmm0
    71e6bf303510:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    71e6bf30351a:	movdqa xmm3,xmm0
    71e6bf30351e:	movdqa xmm0,xmm2
    71e6bf303522:	movdqa xmm1,xmm3
    71e6bf303526:	movq   rax,xmm0
    71e6bf30352b:	add    rax,rax
    71e6bf30352e:	je     0x71e6bf303544
    71e6bf303530:	shr    rax,0x35
    71e6bf303534:	sub    eax,0x201
    71e6bf303539:	cmp    eax,0x3fc
    71e6bf30353e:	ja     0x71e6bf30541b
    71e6bf303544:	movdqa xmm14,xmm0
    71e6bf303549:	psrldq xmm14,0x8
    71e6bf30354f:	movq   rax,xmm14
    71e6bf303554:	add    rax,rax
    71e6bf303557:	je     0x71e6bf30356d
    71e6bf303559:	shr    rax,0x35
    71e6bf30355d:	sub    eax,0x201
    71e6bf303562:	cmp    eax,0x3fc
    71e6bf303567:	ja     0x71e6bf30541b
    71e6bf30356d:	movq   rax,xmm1
    71e6bf303572:	add    rax,rax
    71e6bf303575:	je     0x71e6bf30358b
    71e6bf303577:	shr    rax,0x35
    71e6bf30357b:	sub    eax,0x201
    71e6bf303580:	cmp    eax,0x3fc
    71e6bf303585:	ja     0x71e6bf30541b
    71e6bf30358b:	movdqa xmm14,xmm1
    71e6bf303590:	psrldq xmm14,0x8
    71e6bf303596:	movq   rax,xmm14
    71e6bf30359b:	add    rax,rax
    71e6bf30359e:	je     0x71e6bf3035b4
    71e6bf3035a0:	shr    rax,0x35
    71e6bf3035a4:	sub    eax,0x201
    71e6bf3035a9:	cmp    eax,0x3fc
    71e6bf3035ae:	ja     0x71e6bf30541b
    71e6bf3035b4:	addpd  xmm0,xmm1
    71e6bf3035b8:	movdqa xmm4,xmm0
    71e6bf3035bc:	movdqa xmm0,xmm4
    71e6bf3035c0:	movdqu XMMWORD PTR [r12+0x230],xmm0
    71e6bf3035ca:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    71e6bf3035d4:	movdqa xmm2,xmm0
    71e6bf3035d8:	movdqa xmm1,xmm2
    71e6bf3035dc:	por    xmm2,xmm1
    71e6bf3035e0:	movdqa xmm0,xmm2
    71e6bf3035e4:	movdqu XMMWORD PTR [r12+0x250],xmm0
    71e6bf3035ee:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    71e6bf3035f8:	movdqa xmm2,xmm0
    71e6bf3035fc:	movdqa xmm1,xmm2
    71e6bf303600:	por    xmm2,xmm1
    71e6bf303604:	movdqa xmm0,xmm2
    71e6bf303608:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    71e6bf303612:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    71e6bf30361c:	movdqa xmm2,xmm0
    71e6bf303620:	movdqa xmm1,xmm2
    71e6bf303624:	por    xmm2,xmm1
    71e6bf303628:	movdqa xmm0,xmm2
    71e6bf30362c:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    71e6bf303636:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf30363e:	add    r13,0x40
    71e6bf303642:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf30364a:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf303652:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf30365a:	shr    r11d,1
    71e6bf30365d:	and    r11d,0x10
    71e6bf303661:	or     DWORD PTR [r12+0x314],r11d
    71e6bf303669:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf30366f:	movdqa xmm0,xmm2
    71e6bf303673:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    71e6bf30367d:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    71e6bf303687:	movdqa xmm2,xmm0
    71e6bf30368b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    71e6bf303695:	movdqa xmm3,xmm0
    71e6bf303699:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf3036a1:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf3036ac:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf3036b4:	movdqa xmm0,xmm2
    71e6bf3036b8:	movdqa xmm1,xmm3
    71e6bf3036bc:	pshufd xmm1,xmm1,0x44
    71e6bf3036c1:	movq   rax,xmm0
    71e6bf3036c6:	add    rax,rax
    71e6bf3036c9:	je     0x71e6bf3036df
    71e6bf3036cb:	shr    rax,0x35
    71e6bf3036cf:	sub    eax,0x201
    71e6bf3036d4:	cmp    eax,0x3fc
    71e6bf3036d9:	ja     0x71e6bf30543f
    71e6bf3036df:	movdqa xmm14,xmm0
    71e6bf3036e4:	psrldq xmm14,0x8
    71e6bf3036ea:	movq   rax,xmm14
    71e6bf3036ef:	add    rax,rax
    71e6bf3036f2:	je     0x71e6bf303708
    71e6bf3036f4:	shr    rax,0x35
    71e6bf3036f8:	sub    eax,0x201
    71e6bf3036fd:	cmp    eax,0x3fc
    71e6bf303702:	ja     0x71e6bf30543f
    71e6bf303708:	movq   rax,xmm1
    71e6bf30370d:	add    rax,rax
    71e6bf303710:	je     0x71e6bf303726
    71e6bf303712:	shr    rax,0x35
    71e6bf303716:	sub    eax,0x201
    71e6bf30371b:	cmp    eax,0x3fc
    71e6bf303720:	ja     0x71e6bf30543f
    71e6bf303726:	movdqa xmm14,xmm1
    71e6bf30372b:	psrldq xmm14,0x8
    71e6bf303731:	movq   rax,xmm14
    71e6bf303736:	add    rax,rax
    71e6bf303739:	je     0x71e6bf30374f
    71e6bf30373b:	shr    rax,0x35
    71e6bf30373f:	sub    eax,0x201
    71e6bf303744:	cmp    eax,0x3fc
    71e6bf303749:	ja     0x71e6bf30543f
    71e6bf30374f:	mulpd  xmm0,xmm1
    71e6bf303753:	movdqa xmm4,xmm0
    71e6bf303757:	movdqa xmm0,xmm4
    71e6bf30375b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf303765:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    71e6bf30376f:	movdqa xmm2,xmm0
    71e6bf303773:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    71e6bf30377d:	movdqa xmm4,xmm0
    71e6bf303781:	movdqa xmm0,xmm2
    71e6bf303785:	movdqa xmm1,xmm4
    71e6bf303789:	movq   rax,xmm0
    71e6bf30378e:	add    rax,rax
    71e6bf303791:	je     0x71e6bf3037a7
    71e6bf303793:	shr    rax,0x35
    71e6bf303797:	sub    eax,0x201
    71e6bf30379c:	cmp    eax,0x3fc
    71e6bf3037a1:	ja     0x71e6bf305463
    71e6bf3037a7:	movdqa xmm14,xmm0
    71e6bf3037ac:	psrldq xmm14,0x8
    71e6bf3037b2:	movq   rax,xmm14
    71e6bf3037b7:	add    rax,rax
    71e6bf3037ba:	je     0x71e6bf3037d0
    71e6bf3037bc:	shr    rax,0x35
    71e6bf3037c0:	sub    eax,0x201
    71e6bf3037c5:	cmp    eax,0x3fc
    71e6bf3037ca:	ja     0x71e6bf305463
    71e6bf3037d0:	movq   rax,xmm1
    71e6bf3037d5:	add    rax,rax
    71e6bf3037d8:	je     0x71e6bf3037ee
    71e6bf3037da:	shr    rax,0x35
    71e6bf3037de:	sub    eax,0x201
    71e6bf3037e3:	cmp    eax,0x3fc
    71e6bf3037e8:	ja     0x71e6bf305463
    71e6bf3037ee:	movdqa xmm14,xmm1
    71e6bf3037f3:	psrldq xmm14,0x8
    71e6bf3037f9:	movq   rax,xmm14
    71e6bf3037fe:	add    rax,rax
    71e6bf303801:	je     0x71e6bf303817
    71e6bf303803:	shr    rax,0x35
    71e6bf303807:	sub    eax,0x201
    71e6bf30380c:	cmp    eax,0x3fc
    71e6bf303811:	ja     0x71e6bf305463
    71e6bf303817:	addpd  xmm0,xmm1
    71e6bf30381b:	movdqa xmm5,xmm0
    71e6bf30381f:	movdqa xmm0,xmm5
    71e6bf303823:	movdqu XMMWORD PTR [r12+0x150],xmm0
    71e6bf30382d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf303837:	movdqa xmm2,xmm0
    71e6bf30383b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf303845:	movdqa xmm4,xmm0
    71e6bf303849:	movdqa xmm0,xmm2
    71e6bf30384d:	movdqa xmm1,xmm4
    71e6bf303851:	movq   rax,xmm0
    71e6bf303856:	add    rax,rax
    71e6bf303859:	je     0x71e6bf30386f
    71e6bf30385b:	shr    rax,0x35
    71e6bf30385f:	sub    eax,0x201
    71e6bf303864:	cmp    eax,0x3fc
    71e6bf303869:	ja     0x71e6bf305487
    71e6bf30386f:	movdqa xmm14,xmm0
    71e6bf303874:	psrldq xmm14,0x8
    71e6bf30387a:	movq   rax,xmm14
    71e6bf30387f:	add    rax,rax
    71e6bf303882:	je     0x71e6bf303898
    71e6bf303884:	shr    rax,0x35
    71e6bf303888:	sub    eax,0x201
    71e6bf30388d:	cmp    eax,0x3fc
    71e6bf303892:	ja     0x71e6bf305487
    71e6bf303898:	movq   rax,xmm1
    71e6bf30389d:	add    rax,rax
    71e6bf3038a0:	je     0x71e6bf3038b6
    71e6bf3038a2:	shr    rax,0x35
    71e6bf3038a6:	sub    eax,0x201
    71e6bf3038ab:	cmp    eax,0x3fc
    71e6bf3038b0:	ja     0x71e6bf305487
    71e6bf3038b6:	movdqa xmm14,xmm1
    71e6bf3038bb:	psrldq xmm14,0x8
    71e6bf3038c1:	movq   rax,xmm14
    71e6bf3038c6:	add    rax,rax
    71e6bf3038c9:	je     0x71e6bf3038df
    71e6bf3038cb:	shr    rax,0x35
    71e6bf3038cf:	sub    eax,0x201
    71e6bf3038d4:	cmp    eax,0x3fc
    71e6bf3038d9:	ja     0x71e6bf305487
    71e6bf3038df:	addpd  xmm0,xmm1
    71e6bf3038e3:	movdqa xmm5,xmm0
    71e6bf3038e7:	movdqa xmm0,xmm5
    71e6bf3038eb:	movdqu XMMWORD PTR [r12+0x160],xmm0
    71e6bf3038f5:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    71e6bf3038ff:	movdqa xmm2,xmm0
    71e6bf303903:	movdqa xmm0,xmm2
    71e6bf303907:	movdqa xmm1,xmm3
    71e6bf30390b:	pshufd xmm1,xmm1,0x44
    71e6bf303910:	movq   rax,xmm0
    71e6bf303915:	add    rax,rax
    71e6bf303918:	je     0x71e6bf30392e
    71e6bf30391a:	shr    rax,0x35
    71e6bf30391e:	sub    eax,0x201
    71e6bf303923:	cmp    eax,0x3fc
    71e6bf303928:	ja     0x71e6bf3054ab
    71e6bf30392e:	movdqa xmm14,xmm0
    71e6bf303933:	psrldq xmm14,0x8
    71e6bf303939:	movq   rax,xmm14
    71e6bf30393e:	add    rax,rax
    71e6bf303941:	je     0x71e6bf303957
    71e6bf303943:	shr    rax,0x35
    71e6bf303947:	sub    eax,0x201
    71e6bf30394c:	cmp    eax,0x3fc
    71e6bf303951:	ja     0x71e6bf3054ab
    71e6bf303957:	movq   rax,xmm1
    71e6bf30395c:	add    rax,rax
    71e6bf30395f:	je     0x71e6bf303975
    71e6bf303961:	shr    rax,0x35
    71e6bf303965:	sub    eax,0x201
    71e6bf30396a:	cmp    eax,0x3fc
    71e6bf30396f:	ja     0x71e6bf3054ab
    71e6bf303975:	movdqa xmm14,xmm1
    71e6bf30397a:	psrldq xmm14,0x8
    71e6bf303980:	movq   rax,xmm14
    71e6bf303985:	add    rax,rax
    71e6bf303988:	je     0x71e6bf30399e
    71e6bf30398a:	shr    rax,0x35
    71e6bf30398e:	sub    eax,0x201
    71e6bf303993:	cmp    eax,0x3fc
    71e6bf303998:	ja     0x71e6bf3054ab
    71e6bf30399e:	mulpd  xmm0,xmm1
    71e6bf3039a2:	movdqa xmm4,xmm0
    71e6bf3039a6:	movdqa xmm0,xmm4
    71e6bf3039aa:	movdqu XMMWORD PTR [r12+0x240],xmm0
    71e6bf3039b4:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    71e6bf3039be:	movdqa xmm2,xmm0
    71e6bf3039c2:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    71e6bf3039cc:	movdqa xmm3,xmm0
    71e6bf3039d0:	movdqa xmm0,xmm2
    71e6bf3039d4:	movdqa xmm1,xmm3
    71e6bf3039d8:	pshufd xmm1,xmm1,0x44
    71e6bf3039dd:	movq   rax,xmm0
    71e6bf3039e2:	add    rax,rax
    71e6bf3039e5:	je     0x71e6bf3039fb
    71e6bf3039e7:	shr    rax,0x35
    71e6bf3039eb:	sub    eax,0x201
    71e6bf3039f0:	cmp    eax,0x3fc
    71e6bf3039f5:	ja     0x71e6bf3054cf
    71e6bf3039fb:	movdqa xmm14,xmm0
    71e6bf303a00:	psrldq xmm14,0x8
    71e6bf303a06:	movq   rax,xmm14
    71e6bf303a0b:	add    rax,rax
    71e6bf303a0e:	je     0x71e6bf303a24
    71e6bf303a10:	shr    rax,0x35
    71e6bf303a14:	sub    eax,0x201
    71e6bf303a19:	cmp    eax,0x3fc
    71e6bf303a1e:	ja     0x71e6bf3054cf
    71e6bf303a24:	movq   rax,xmm1
    71e6bf303a29:	add    rax,rax
    71e6bf303a2c:	je     0x71e6bf303a42
    71e6bf303a2e:	shr    rax,0x35
    71e6bf303a32:	sub    eax,0x201
    71e6bf303a37:	cmp    eax,0x3fc
    71e6bf303a3c:	ja     0x71e6bf3054cf
    71e6bf303a42:	movdqa xmm14,xmm1
    71e6bf303a47:	psrldq xmm14,0x8
    71e6bf303a4d:	movq   rax,xmm14
    71e6bf303a52:	add    rax,rax
    71e6bf303a55:	je     0x71e6bf303a6b
    71e6bf303a57:	shr    rax,0x35
    71e6bf303a5b:	sub    eax,0x201
    71e6bf303a60:	cmp    eax,0x3fc
    71e6bf303a65:	ja     0x71e6bf3054cf
    71e6bf303a6b:	mulpd  xmm0,xmm1
    71e6bf303a6f:	movdqa xmm4,xmm0
    71e6bf303a73:	movdqa xmm0,xmm4
    71e6bf303a77:	movdqu XMMWORD PTR [r12+0x140],xmm0
    71e6bf303a81:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    71e6bf303a8b:	movdqa xmm2,xmm0
    71e6bf303a8f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    71e6bf303a99:	movdqa xmm3,xmm0
    71e6bf303a9d:	movdqa xmm0,xmm2
    71e6bf303aa1:	movdqa xmm1,xmm3
    71e6bf303aa5:	pshufd xmm1,xmm1,0x44
    71e6bf303aaa:	movq   rax,xmm0
    71e6bf303aaf:	add    rax,rax
    71e6bf303ab2:	je     0x71e6bf303ac8
    71e6bf303ab4:	shr    rax,0x35
    71e6bf303ab8:	sub    eax,0x201
    71e6bf303abd:	cmp    eax,0x3fc
    71e6bf303ac2:	ja     0x71e6bf3054f3
    71e6bf303ac8:	movdqa xmm14,xmm0
    71e6bf303acd:	psrldq xmm14,0x8
    71e6bf303ad3:	movq   rax,xmm14
    71e6bf303ad8:	add    rax,rax
    71e6bf303adb:	je     0x71e6bf303af1
    71e6bf303add:	shr    rax,0x35
    71e6bf303ae1:	sub    eax,0x201
    71e6bf303ae6:	cmp    eax,0x3fc
    71e6bf303aeb:	ja     0x71e6bf3054f3
    71e6bf303af1:	movq   rax,xmm1
    71e6bf303af6:	add    rax,rax
    71e6bf303af9:	je     0x71e6bf303b0f
    71e6bf303afb:	shr    rax,0x35
    71e6bf303aff:	sub    eax,0x201
    71e6bf303b04:	cmp    eax,0x3fc
    71e6bf303b09:	ja     0x71e6bf3054f3
    71e6bf303b0f:	movdqa xmm14,xmm1
    71e6bf303b14:	psrldq xmm14,0x8
    71e6bf303b1a:	movq   rax,xmm14
    71e6bf303b1f:	add    rax,rax
    71e6bf303b22:	je     0x71e6bf303b38
    71e6bf303b24:	shr    rax,0x35
    71e6bf303b28:	sub    eax,0x201
    71e6bf303b2d:	cmp    eax,0x3fc
    71e6bf303b32:	ja     0x71e6bf3054f3
    71e6bf303b38:	mulpd  xmm0,xmm1
    71e6bf303b3c:	movdqa xmm4,xmm0
    71e6bf303b40:	movdqa xmm0,xmm4
    71e6bf303b44:	movdqu XMMWORD PTR [r12+0x170],xmm0
    71e6bf303b4e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf303b58:	movdqa xmm2,xmm0
    71e6bf303b5c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf303b66:	movdqa xmm4,xmm0
    71e6bf303b6a:	movdqa xmm0,xmm2
    71e6bf303b6e:	movdqa xmm1,xmm4
    71e6bf303b72:	movq   rax,xmm0
    71e6bf303b77:	add    rax,rax
    71e6bf303b7a:	je     0x71e6bf303b90
    71e6bf303b7c:	shr    rax,0x35
    71e6bf303b80:	sub    eax,0x201
    71e6bf303b85:	cmp    eax,0x3fc
    71e6bf303b8a:	ja     0x71e6bf305517
    71e6bf303b90:	movdqa xmm14,xmm0
    71e6bf303b95:	psrldq xmm14,0x8
    71e6bf303b9b:	movq   rax,xmm14
    71e6bf303ba0:	add    rax,rax
    71e6bf303ba3:	je     0x71e6bf303bb9
    71e6bf303ba5:	shr    rax,0x35
    71e6bf303ba9:	sub    eax,0x201
    71e6bf303bae:	cmp    eax,0x3fc
    71e6bf303bb3:	ja     0x71e6bf305517
    71e6bf303bb9:	movq   rax,xmm1
    71e6bf303bbe:	add    rax,rax
    71e6bf303bc1:	je     0x71e6bf303bd7
    71e6bf303bc3:	shr    rax,0x35
    71e6bf303bc7:	sub    eax,0x201
    71e6bf303bcc:	cmp    eax,0x3fc
    71e6bf303bd1:	ja     0x71e6bf305517
    71e6bf303bd7:	movdqa xmm14,xmm1
    71e6bf303bdc:	psrldq xmm14,0x8
    71e6bf303be2:	movq   rax,xmm14
    71e6bf303be7:	add    rax,rax
    71e6bf303bea:	je     0x71e6bf303c00
    71e6bf303bec:	shr    rax,0x35
    71e6bf303bf0:	sub    eax,0x201
    71e6bf303bf5:	cmp    eax,0x3fc
    71e6bf303bfa:	ja     0x71e6bf305517
    71e6bf303c00:	addpd  xmm0,xmm1
    71e6bf303c04:	movdqa xmm5,xmm0
    71e6bf303c08:	movdqa xmm0,xmm5
    71e6bf303c0c:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf303c16:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    71e6bf303c20:	movdqa xmm2,xmm0
    71e6bf303c24:	movdqa xmm0,xmm2
    71e6bf303c28:	movdqa xmm1,xmm3
    71e6bf303c2c:	pshufd xmm1,xmm1,0x44
    71e6bf303c31:	movq   rax,xmm0
    71e6bf303c36:	add    rax,rax
    71e6bf303c39:	je     0x71e6bf303c4f
    71e6bf303c3b:	shr    rax,0x35
    71e6bf303c3f:	sub    eax,0x201
    71e6bf303c44:	cmp    eax,0x3fc
    71e6bf303c49:	ja     0x71e6bf30553b
    71e6bf303c4f:	movdqa xmm14,xmm0
    71e6bf303c54:	psrldq xmm14,0x8
    71e6bf303c5a:	movq   rax,xmm14
    71e6bf303c5f:	add    rax,rax
    71e6bf303c62:	je     0x71e6bf303c78
    71e6bf303c64:	shr    rax,0x35
    71e6bf303c68:	sub    eax,0x201
    71e6bf303c6d:	cmp    eax,0x3fc
    71e6bf303c72:	ja     0x71e6bf30553b
    71e6bf303c78:	movq   rax,xmm1
    71e6bf303c7d:	add    rax,rax
    71e6bf303c80:	je     0x71e6bf303c96
    71e6bf303c82:	shr    rax,0x35
    71e6bf303c86:	sub    eax,0x201
    71e6bf303c8b:	cmp    eax,0x3fc
    71e6bf303c90:	ja     0x71e6bf30553b
    71e6bf303c96:	movdqa xmm14,xmm1
    71e6bf303c9b:	psrldq xmm14,0x8
    71e6bf303ca1:	movq   rax,xmm14
    71e6bf303ca6:	add    rax,rax
    71e6bf303ca9:	je     0x71e6bf303cbf
    71e6bf303cab:	shr    rax,0x35
    71e6bf303caf:	sub    eax,0x201
    71e6bf303cb4:	cmp    eax,0x3fc
    71e6bf303cb9:	ja     0x71e6bf30553b
    71e6bf303cbf:	mulpd  xmm0,xmm1
    71e6bf303cc3:	movdqa xmm4,xmm0
    71e6bf303cc7:	movdqa xmm0,xmm4
    71e6bf303ccb:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf303cd5:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    71e6bf303cdf:	movdqa xmm2,xmm0
    71e6bf303ce3:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    71e6bf303ced:	movdqa xmm4,xmm0
    71e6bf303cf1:	movdqa xmm0,xmm2
    71e6bf303cf5:	movdqa xmm1,xmm4
    71e6bf303cf9:	movq   rax,xmm0
    71e6bf303cfe:	add    rax,rax
    71e6bf303d01:	je     0x71e6bf303d17
    71e6bf303d03:	shr    rax,0x35
    71e6bf303d07:	sub    eax,0x201
    71e6bf303d0c:	cmp    eax,0x3fc
    71e6bf303d11:	ja     0x71e6bf30555f
    71e6bf303d17:	movdqa xmm14,xmm0
    71e6bf303d1c:	psrldq xmm14,0x8
    71e6bf303d22:	movq   rax,xmm14
    71e6bf303d27:	add    rax,rax
    71e6bf303d2a:	je     0x71e6bf303d40
    71e6bf303d2c:	shr    rax,0x35
    71e6bf303d30:	sub    eax,0x201
    71e6bf303d35:	cmp    eax,0x3fc
    71e6bf303d3a:	ja     0x71e6bf30555f
    71e6bf303d40:	movq   rax,xmm1
    71e6bf303d45:	add    rax,rax
    71e6bf303d48:	je     0x71e6bf303d5e
    71e6bf303d4a:	shr    rax,0x35
    71e6bf303d4e:	sub    eax,0x201
    71e6bf303d53:	cmp    eax,0x3fc
    71e6bf303d58:	ja     0x71e6bf30555f
    71e6bf303d5e:	movdqa xmm14,xmm1
    71e6bf303d63:	psrldq xmm14,0x8
    71e6bf303d69:	movq   rax,xmm14
    71e6bf303d6e:	add    rax,rax
    71e6bf303d71:	je     0x71e6bf303d87
    71e6bf303d73:	shr    rax,0x35
    71e6bf303d77:	sub    eax,0x201
    71e6bf303d7c:	cmp    eax,0x3fc
    71e6bf303d81:	ja     0x71e6bf30555f
    71e6bf303d87:	addpd  xmm0,xmm1
    71e6bf303d8b:	movdqa xmm5,xmm0
    71e6bf303d8f:	movdqa xmm0,xmm5
    71e6bf303d93:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf303d9d:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    71e6bf303da7:	movdqa xmm2,xmm0
    71e6bf303dab:	movdqa xmm0,xmm2
    71e6bf303daf:	movdqa xmm1,xmm3
    71e6bf303db3:	pshufd xmm1,xmm1,0x44
    71e6bf303db8:	movq   rax,xmm0
    71e6bf303dbd:	add    rax,rax
    71e6bf303dc0:	je     0x71e6bf303dd6
    71e6bf303dc2:	shr    rax,0x35
    71e6bf303dc6:	sub    eax,0x201
    71e6bf303dcb:	cmp    eax,0x3fc
    71e6bf303dd0:	ja     0x71e6bf305583
    71e6bf303dd6:	movdqa xmm14,xmm0
    71e6bf303ddb:	psrldq xmm14,0x8
    71e6bf303de1:	movq   rax,xmm14
    71e6bf303de6:	add    rax,rax
    71e6bf303de9:	je     0x71e6bf303dff
    71e6bf303deb:	shr    rax,0x35
    71e6bf303def:	sub    eax,0x201
    71e6bf303df4:	cmp    eax,0x3fc
    71e6bf303df9:	ja     0x71e6bf305583
    71e6bf303dff:	movq   rax,xmm1
    71e6bf303e04:	add    rax,rax
    71e6bf303e07:	je     0x71e6bf303e1d
    71e6bf303e09:	shr    rax,0x35
    71e6bf303e0d:	sub    eax,0x201
    71e6bf303e12:	cmp    eax,0x3fc
    71e6bf303e17:	ja     0x71e6bf305583
    71e6bf303e1d:	movdqa xmm14,xmm1
    71e6bf303e22:	psrldq xmm14,0x8
    71e6bf303e28:	movq   rax,xmm14
    71e6bf303e2d:	add    rax,rax
    71e6bf303e30:	je     0x71e6bf303e46
    71e6bf303e32:	shr    rax,0x35
    71e6bf303e36:	sub    eax,0x201
    71e6bf303e3b:	cmp    eax,0x3fc
    71e6bf303e40:	ja     0x71e6bf305583
    71e6bf303e46:	mulpd  xmm0,xmm1
    71e6bf303e4a:	movdqa xmm4,xmm0
    71e6bf303e4e:	movdqa xmm0,xmm4
    71e6bf303e52:	movdqu XMMWORD PTR [r12+0x230],xmm0
    71e6bf303e5c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    71e6bf303e66:	movdqa xmm2,xmm0
    71e6bf303e6a:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    71e6bf303e74:	movdqa xmm3,xmm0
    71e6bf303e78:	movdqa xmm0,xmm2
    71e6bf303e7c:	movdqa xmm1,xmm3
    71e6bf303e80:	movq   rax,xmm0
    71e6bf303e85:	add    rax,rax
    71e6bf303e88:	je     0x71e6bf303e9e
    71e6bf303e8a:	shr    rax,0x35
    71e6bf303e8e:	sub    eax,0x201
    71e6bf303e93:	cmp    eax,0x3fc
    71e6bf303e98:	ja     0x71e6bf3055a7
    71e6bf303e9e:	movdqa xmm14,xmm0
    71e6bf303ea3:	psrldq xmm14,0x8
    71e6bf303ea9:	movq   rax,xmm14
    71e6bf303eae:	add    rax,rax
    71e6bf303eb1:	je     0x71e6bf303ec7
    71e6bf303eb3:	shr    rax,0x35
    71e6bf303eb7:	sub    eax,0x201
    71e6bf303ebc:	cmp    eax,0x3fc
    71e6bf303ec1:	ja     0x71e6bf3055a7
    71e6bf303ec7:	movq   rax,xmm1
    71e6bf303ecc:	add    rax,rax
    71e6bf303ecf:	je     0x71e6bf303ee5
    71e6bf303ed1:	shr    rax,0x35
    71e6bf303ed5:	sub    eax,0x201
    71e6bf303eda:	cmp    eax,0x3fc
    71e6bf303edf:	ja     0x71e6bf3055a7
    71e6bf303ee5:	movdqa xmm14,xmm1
    71e6bf303eea:	psrldq xmm14,0x8
    71e6bf303ef0:	movq   rax,xmm14
    71e6bf303ef5:	add    rax,rax
    71e6bf303ef8:	je     0x71e6bf303f0e
    71e6bf303efa:	shr    rax,0x35
    71e6bf303efe:	sub    eax,0x201
    71e6bf303f03:	cmp    eax,0x3fc
    71e6bf303f08:	ja     0x71e6bf3055a7
    71e6bf303f0e:	addpd  xmm0,xmm1
    71e6bf303f12:	movdqa xmm4,xmm0
    71e6bf303f16:	movdqa xmm0,xmm4
    71e6bf303f1a:	movdqu XMMWORD PTR [r12+0x140],xmm0
    71e6bf303f24:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    71e6bf303f2e:	movdqa xmm2,xmm0
    71e6bf303f32:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    71e6bf303f3c:	movdqa xmm3,xmm0
    71e6bf303f40:	movdqa xmm0,xmm2
    71e6bf303f44:	movdqa xmm1,xmm3
    71e6bf303f48:	pshufd xmm1,xmm1,0x44
    71e6bf303f4d:	movq   rax,xmm0
    71e6bf303f52:	add    rax,rax
    71e6bf303f55:	je     0x71e6bf303f6b
    71e6bf303f57:	shr    rax,0x35
    71e6bf303f5b:	sub    eax,0x201
    71e6bf303f60:	cmp    eax,0x3fc
    71e6bf303f65:	ja     0x71e6bf3055cb
    71e6bf303f6b:	movdqa xmm14,xmm0
    71e6bf303f70:	psrldq xmm14,0x8
    71e6bf303f76:	movq   rax,xmm14
    71e6bf303f7b:	add    rax,rax
    71e6bf303f7e:	je     0x71e6bf303f94
    71e6bf303f80:	shr    rax,0x35
    71e6bf303f84:	sub    eax,0x201
    71e6bf303f89:	cmp    eax,0x3fc
    71e6bf303f8e:	ja     0x71e6bf3055cb
    71e6bf303f94:	movq   rax,xmm1
    71e6bf303f99:	add    rax,rax
    71e6bf303f9c:	je     0x71e6bf303fb2
    71e6bf303f9e:	shr    rax,0x35
    71e6bf303fa2:	sub    eax,0x201
    71e6bf303fa7:	cmp    eax,0x3fc
    71e6bf303fac:	ja     0x71e6bf3055cb
    71e6bf303fb2:	movdqa xmm14,xmm1
    71e6bf303fb7:	psrldq xmm14,0x8
    71e6bf303fbd:	movq   rax,xmm14
    71e6bf303fc2:	add    rax,rax
    71e6bf303fc5:	je     0x71e6bf303fdb
    71e6bf303fc7:	shr    rax,0x35
    71e6bf303fcb:	sub    eax,0x201
    71e6bf303fd0:	cmp    eax,0x3fc
    71e6bf303fd5:	ja     0x71e6bf3055cb
    71e6bf303fdb:	mulpd  xmm0,xmm1
    71e6bf303fdf:	movdqa xmm4,xmm0
    71e6bf303fe3:	movdqa xmm0,xmm4
    71e6bf303fe7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    71e6bf303ff1:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    71e6bf303ffb:	movdqa xmm2,xmm0
    71e6bf303fff:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf304009:	movdqa xmm3,xmm0
    71e6bf30400d:	movdqa xmm0,xmm2
    71e6bf304011:	movdqa xmm1,xmm3
    71e6bf304015:	movq   rax,xmm0
    71e6bf30401a:	add    rax,rax
    71e6bf30401d:	je     0x71e6bf304033
    71e6bf30401f:	shr    rax,0x35
    71e6bf304023:	sub    eax,0x201
    71e6bf304028:	cmp    eax,0x3fc
    71e6bf30402d:	ja     0x71e6bf3055ef
    71e6bf304033:	movdqa xmm14,xmm0
    71e6bf304038:	psrldq xmm14,0x8
    71e6bf30403e:	movq   rax,xmm14
    71e6bf304043:	add    rax,rax
    71e6bf304046:	je     0x71e6bf30405c
    71e6bf304048:	shr    rax,0x35
    71e6bf30404c:	sub    eax,0x201
    71e6bf304051:	cmp    eax,0x3fc
    71e6bf304056:	ja     0x71e6bf3055ef
    71e6bf30405c:	movq   rax,xmm1
    71e6bf304061:	add    rax,rax
    71e6bf304064:	je     0x71e6bf30407a
    71e6bf304066:	shr    rax,0x35
    71e6bf30406a:	sub    eax,0x201
    71e6bf30406f:	cmp    eax,0x3fc
    71e6bf304074:	ja     0x71e6bf3055ef
    71e6bf30407a:	movdqa xmm14,xmm1
    71e6bf30407f:	psrldq xmm14,0x8
    71e6bf304085:	movq   rax,xmm14
    71e6bf30408a:	add    rax,rax
    71e6bf30408d:	je     0x71e6bf3040a3
    71e6bf30408f:	shr    rax,0x35
    71e6bf304093:	sub    eax,0x201
    71e6bf304098:	cmp    eax,0x3fc
    71e6bf30409d:	ja     0x71e6bf3055ef
    71e6bf3040a3:	addpd  xmm0,xmm1
    71e6bf3040a7:	movdqa xmm4,xmm0
    71e6bf3040ab:	movdqa xmm0,xmm4
    71e6bf3040af:	movdqu XMMWORD PTR [r12+0x150],xmm0
    71e6bf3040b9:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf3040c1:	mov    r14,r13
    71e6bf3040c4:	add    r14,0x70
    71e6bf3040c8:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf3040d0:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf3040d8:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf3040e0:	shr    r11d,1
    71e6bf3040e3:	and    r11d,0x10
    71e6bf3040e7:	or     DWORD PTR [r12+0x314],r11d
    71e6bf3040ef:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf3040f4:	movdqa xmm0,xmm2
    71e6bf3040f8:	movdqu XMMWORD PTR [r12+0x240],xmm0
    71e6bf304102:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf30410c:	movdqa xmm3,xmm0
    71e6bf304110:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf30411a:	movdqa xmm4,xmm0
    71e6bf30411e:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf304126:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf304131:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf304139:	movdqa xmm0,xmm3
    71e6bf30413d:	movdqa xmm1,xmm4
    71e6bf304141:	movq   rax,xmm0
    71e6bf304146:	add    rax,rax
    71e6bf304149:	je     0x71e6bf30415f
    71e6bf30414b:	shr    rax,0x35
    71e6bf30414f:	sub    eax,0x201
    71e6bf304154:	cmp    eax,0x3fc
    71e6bf304159:	ja     0x71e6bf305613
    71e6bf30415f:	movdqa xmm14,xmm0
    71e6bf304164:	psrldq xmm14,0x8
    71e6bf30416a:	movq   rax,xmm14
    71e6bf30416f:	add    rax,rax
    71e6bf304172:	je     0x71e6bf304188
    71e6bf304174:	shr    rax,0x35
    71e6bf304178:	sub    eax,0x201
    71e6bf30417d:	cmp    eax,0x3fc
    71e6bf304182:	ja     0x71e6bf305613
    71e6bf304188:	movq   rax,xmm1
    71e6bf30418d:	add    rax,rax
    71e6bf304190:	je     0x71e6bf3041a6
    71e6bf304192:	shr    rax,0x35
    71e6bf304196:	sub    eax,0x201
    71e6bf30419b:	cmp    eax,0x3fc
    71e6bf3041a0:	ja     0x71e6bf305613
    71e6bf3041a6:	movdqa xmm14,xmm1
    71e6bf3041ab:	psrldq xmm14,0x8
    71e6bf3041b1:	movq   rax,xmm14
    71e6bf3041b6:	add    rax,rax
    71e6bf3041b9:	je     0x71e6bf3041cf
    71e6bf3041bb:	shr    rax,0x35
    71e6bf3041bf:	sub    eax,0x201
    71e6bf3041c4:	cmp    eax,0x3fc
    71e6bf3041c9:	ja     0x71e6bf305613
    71e6bf3041cf:	addpd  xmm0,xmm1
    71e6bf3041d3:	movdqa xmm5,xmm0
    71e6bf3041d7:	movdqa xmm0,xmm5
    71e6bf3041db:	movdqu XMMWORD PTR [r12+0x170],xmm0
    71e6bf3041e5:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    71e6bf3041ef:	movdqa xmm3,xmm0
    71e6bf3041f3:	movdqa xmm0,xmm2
    71e6bf3041f7:	movdqa xmm1,xmm3
    71e6bf3041fb:	pshufd xmm1,xmm1,0x44
    71e6bf304200:	movq   rax,xmm0
    71e6bf304205:	add    rax,rax
    71e6bf304208:	je     0x71e6bf30421e
    71e6bf30420a:	shr    rax,0x35
    71e6bf30420e:	sub    eax,0x201
    71e6bf304213:	cmp    eax,0x3fc
    71e6bf304218:	ja     0x71e6bf305637
    71e6bf30421e:	movdqa xmm14,xmm0
    71e6bf304223:	psrldq xmm14,0x8
    71e6bf304229:	movq   rax,xmm14
    71e6bf30422e:	add    rax,rax
    71e6bf304231:	je     0x71e6bf304247
    71e6bf304233:	shr    rax,0x35
    71e6bf304237:	sub    eax,0x201
    71e6bf30423c:	cmp    eax,0x3fc
    71e6bf304241:	ja     0x71e6bf305637
    71e6bf304247:	movq   rax,xmm1
    71e6bf30424c:	add    rax,rax
    71e6bf30424f:	je     0x71e6bf304265
    71e6bf304251:	shr    rax,0x35
    71e6bf304255:	sub    eax,0x201
    71e6bf30425a:	cmp    eax,0x3fc
    71e6bf30425f:	ja     0x71e6bf305637
    71e6bf304265:	movdqa xmm14,xmm1
    71e6bf30426a:	psrldq xmm14,0x8
    71e6bf304270:	movq   rax,xmm14
    71e6bf304275:	add    rax,rax
    71e6bf304278:	je     0x71e6bf30428e
    71e6bf30427a:	shr    rax,0x35
    71e6bf30427e:	sub    eax,0x201
    71e6bf304283:	cmp    eax,0x3fc
    71e6bf304288:	ja     0x71e6bf305637
    71e6bf30428e:	mulpd  xmm0,xmm1
    71e6bf304292:	movdqa xmm4,xmm0
    71e6bf304296:	movdqa xmm0,xmm4
    71e6bf30429a:	movdqu XMMWORD PTR [r12+0x160],xmm0
    71e6bf3042a4:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    71e6bf3042ae:	movdqa xmm2,xmm0
    71e6bf3042b2:	movdqa xmm0,xmm2
    71e6bf3042b6:	movdqa xmm1,xmm3
    71e6bf3042ba:	pshufd xmm1,xmm1,0x44
    71e6bf3042bf:	movq   rax,xmm0
    71e6bf3042c4:	add    rax,rax
    71e6bf3042c7:	je     0x71e6bf3042dd
    71e6bf3042c9:	shr    rax,0x35
    71e6bf3042cd:	sub    eax,0x201
    71e6bf3042d2:	cmp    eax,0x3fc
    71e6bf3042d7:	ja     0x71e6bf30565b
    71e6bf3042dd:	movdqa xmm14,xmm0
    71e6bf3042e2:	psrldq xmm14,0x8
    71e6bf3042e8:	movq   rax,xmm14
    71e6bf3042ed:	add    rax,rax
    71e6bf3042f0:	je     0x71e6bf304306
    71e6bf3042f2:	shr    rax,0x35
    71e6bf3042f6:	sub    eax,0x201
    71e6bf3042fb:	cmp    eax,0x3fc
    71e6bf304300:	ja     0x71e6bf30565b
    71e6bf304306:	movq   rax,xmm1
    71e6bf30430b:	add    rax,rax
    71e6bf30430e:	je     0x71e6bf304324
    71e6bf304310:	shr    rax,0x35
    71e6bf304314:	sub    eax,0x201
    71e6bf304319:	cmp    eax,0x3fc
    71e6bf30431e:	ja     0x71e6bf30565b
    71e6bf304324:	movdqa xmm14,xmm1
    71e6bf304329:	psrldq xmm14,0x8
    71e6bf30432f:	movq   rax,xmm14
    71e6bf304334:	add    rax,rax
    71e6bf304337:	je     0x71e6bf30434d
    71e6bf304339:	shr    rax,0x35
    71e6bf30433d:	sub    eax,0x201
    71e6bf304342:	cmp    eax,0x3fc
    71e6bf304347:	ja     0x71e6bf30565b
    71e6bf30434d:	mulpd  xmm0,xmm1
    71e6bf304351:	movdqa xmm4,xmm0
    71e6bf304355:	movdqa xmm0,xmm4
    71e6bf304359:	movdqu XMMWORD PTR [r12+0x180],xmm0
    71e6bf304363:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf30436d:	movdqa xmm2,xmm0
    71e6bf304371:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    71e6bf30437b:	movdqa xmm4,xmm0
    71e6bf30437f:	movdqa xmm0,xmm2
    71e6bf304383:	movdqa xmm1,xmm4
    71e6bf304387:	movq   rax,xmm0
    71e6bf30438c:	add    rax,rax
    71e6bf30438f:	je     0x71e6bf3043a5
    71e6bf304391:	shr    rax,0x35
    71e6bf304395:	sub    eax,0x201
    71e6bf30439a:	cmp    eax,0x3fc
    71e6bf30439f:	ja     0x71e6bf30567f
    71e6bf3043a5:	movdqa xmm14,xmm0
    71e6bf3043aa:	psrldq xmm14,0x8
    71e6bf3043b0:	movq   rax,xmm14
    71e6bf3043b5:	add    rax,rax
    71e6bf3043b8:	je     0x71e6bf3043ce
    71e6bf3043ba:	shr    rax,0x35
    71e6bf3043be:	sub    eax,0x201
    71e6bf3043c3:	cmp    eax,0x3fc
    71e6bf3043c8:	ja     0x71e6bf30567f
    71e6bf3043ce:	movq   rax,xmm1
    71e6bf3043d3:	add    rax,rax
    71e6bf3043d6:	je     0x71e6bf3043ec
    71e6bf3043d8:	shr    rax,0x35
    71e6bf3043dc:	sub    eax,0x201
    71e6bf3043e1:	cmp    eax,0x3fc
    71e6bf3043e6:	ja     0x71e6bf30567f
    71e6bf3043ec:	movdqa xmm14,xmm1
    71e6bf3043f1:	psrldq xmm14,0x8
    71e6bf3043f7:	movq   rax,xmm14
    71e6bf3043fc:	add    rax,rax
    71e6bf3043ff:	je     0x71e6bf304415
    71e6bf304401:	shr    rax,0x35
    71e6bf304405:	sub    eax,0x201
    71e6bf30440a:	cmp    eax,0x3fc
    71e6bf30440f:	ja     0x71e6bf30567f
    71e6bf304415:	addpd  xmm0,xmm1
    71e6bf304419:	movdqa xmm5,xmm0
    71e6bf30441d:	movdqa xmm0,xmm5
    71e6bf304421:	movdqu XMMWORD PTR [r12+0x210],xmm0
    71e6bf30442b:	mov    r14,r13
    71e6bf30442e:	add    r14,0x10
    71e6bf304432:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf30443a:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf304442:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf30444a:	shr    r11d,1
    71e6bf30444d:	and    r11d,0x10
    71e6bf304451:	or     DWORD PTR [r12+0x314],r11d
    71e6bf304459:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    71e6bf30445f:	movdqu xmm4,XMMWORD PTR [r14]
    71e6bf304464:	movdqa xmm0,xmm4
    71e6bf304468:	movdqu XMMWORD PTR [r12+0x230],xmm0
    71e6bf304472:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    71e6bf30447c:	movdqa xmm5,xmm0
    71e6bf304480:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    71e6bf30448a:	movdqa xmm6,xmm0
    71e6bf30448e:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf304496:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf3044a1:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf3044a9:	movdqa xmm0,xmm5
    71e6bf3044ad:	movdqa xmm1,xmm6
    71e6bf3044b1:	movq   rax,xmm0
    71e6bf3044b6:	add    rax,rax
    71e6bf3044b9:	je     0x71e6bf3044cf
    71e6bf3044bb:	shr    rax,0x35
    71e6bf3044bf:	sub    eax,0x201
    71e6bf3044c4:	cmp    eax,0x3fc
    71e6bf3044c9:	ja     0x71e6bf3056a3
    71e6bf3044cf:	movdqa xmm14,xmm0
    71e6bf3044d4:	psrldq xmm14,0x8
    71e6bf3044da:	movq   rax,xmm14
    71e6bf3044df:	add    rax,rax
    71e6bf3044e2:	je     0x71e6bf3044f8
    71e6bf3044e4:	shr    rax,0x35
    71e6bf3044e8:	sub    eax,0x201
    71e6bf3044ed:	cmp    eax,0x3fc
    71e6bf3044f2:	ja     0x71e6bf3056a3
    71e6bf3044f8:	movq   rax,xmm1
    71e6bf3044fd:	add    rax,rax
    71e6bf304500:	je     0x71e6bf304516
    71e6bf304502:	shr    rax,0x35
    71e6bf304506:	sub    eax,0x201
    71e6bf30450b:	cmp    eax,0x3fc
    71e6bf304510:	ja     0x71e6bf3056a3
    71e6bf304516:	movdqa xmm14,xmm1
    71e6bf30451b:	psrldq xmm14,0x8
    71e6bf304521:	movq   rax,xmm14
    71e6bf304526:	add    rax,rax
    71e6bf304529:	je     0x71e6bf30453f
    71e6bf30452b:	shr    rax,0x35
    71e6bf30452f:	sub    eax,0x201
    71e6bf304534:	cmp    eax,0x3fc
    71e6bf304539:	ja     0x71e6bf3056a3
    71e6bf30453f:	addpd  xmm0,xmm1
    71e6bf304543:	movdqa xmm7,xmm0
    71e6bf304547:	movdqa xmm0,xmm7
    71e6bf30454b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    71e6bf304555:	movdqa xmm0,xmm4
    71e6bf304559:	movdqa xmm1,xmm3
    71e6bf30455d:	pshufd xmm1,xmm1,0x44
    71e6bf304562:	movq   rax,xmm0
    71e6bf304567:	add    rax,rax
    71e6bf30456a:	je     0x71e6bf304580
    71e6bf30456c:	shr    rax,0x35
    71e6bf304570:	sub    eax,0x201
    71e6bf304575:	cmp    eax,0x3fc
    71e6bf30457a:	ja     0x71e6bf3056c7
    71e6bf304580:	movdqa xmm14,xmm0
    71e6bf304585:	psrldq xmm14,0x8
    71e6bf30458b:	movq   rax,xmm14
    71e6bf304590:	add    rax,rax
    71e6bf304593:	je     0x71e6bf3045a9
    71e6bf304595:	shr    rax,0x35
    71e6bf304599:	sub    eax,0x201
    71e6bf30459e:	cmp    eax,0x3fc
    71e6bf3045a3:	ja     0x71e6bf3056c7
    71e6bf3045a9:	movq   rax,xmm1
    71e6bf3045ae:	add    rax,rax
    71e6bf3045b1:	je     0x71e6bf3045c7
    71e6bf3045b3:	shr    rax,0x35
    71e6bf3045b7:	sub    eax,0x201
    71e6bf3045bc:	cmp    eax,0x3fc
    71e6bf3045c1:	ja     0x71e6bf3056c7
    71e6bf3045c7:	movdqa xmm14,xmm1
    71e6bf3045cc:	psrldq xmm14,0x8
    71e6bf3045d2:	movq   rax,xmm14
    71e6bf3045d7:	add    rax,rax
    71e6bf3045da:	je     0x71e6bf3045f0
    71e6bf3045dc:	shr    rax,0x35
    71e6bf3045e0:	sub    eax,0x201
    71e6bf3045e5:	cmp    eax,0x3fc
    71e6bf3045ea:	ja     0x71e6bf3056c7
    71e6bf3045f0:	mulpd  xmm0,xmm1
    71e6bf3045f4:	movdqa xmm5,xmm0
    71e6bf3045f8:	movdqa xmm0,xmm5
    71e6bf3045fc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    71e6bf304606:	movdqa xmm0,xmm2
    71e6bf30460a:	movdqa xmm1,xmm3
    71e6bf30460e:	pshufd xmm1,xmm1,0x44
    71e6bf304613:	movq   rax,xmm0
    71e6bf304618:	add    rax,rax
    71e6bf30461b:	je     0x71e6bf304631
    71e6bf30461d:	shr    rax,0x35
    71e6bf304621:	sub    eax,0x201
    71e6bf304626:	cmp    eax,0x3fc
    71e6bf30462b:	ja     0x71e6bf3056eb
    71e6bf304631:	movdqa xmm14,xmm0
    71e6bf304636:	psrldq xmm14,0x8
    71e6bf30463c:	movq   rax,xmm14
    71e6bf304641:	add    rax,rax
    71e6bf304644:	je     0x71e6bf30465a
    71e6bf304646:	shr    rax,0x35
    71e6bf30464a:	sub    eax,0x201
    71e6bf30464f:	cmp    eax,0x3fc
    71e6bf304654:	ja     0x71e6bf3056eb
    71e6bf30465a:	movq   rax,xmm1
    71e6bf30465f:	add    rax,rax
    71e6bf304662:	je     0x71e6bf304678
    71e6bf304664:	shr    rax,0x35
    71e6bf304668:	sub    eax,0x201
    71e6bf30466d:	cmp    eax,0x3fc
    71e6bf304672:	ja     0x71e6bf3056eb
    71e6bf304678:	movdqa xmm14,xmm1
    71e6bf30467d:	psrldq xmm14,0x8
    71e6bf304683:	movq   rax,xmm14
    71e6bf304688:	add    rax,rax
    71e6bf30468b:	je     0x71e6bf3046a1
    71e6bf30468d:	shr    rax,0x35
    71e6bf304691:	sub    eax,0x201
    71e6bf304696:	cmp    eax,0x3fc
    71e6bf30469b:	ja     0x71e6bf3056eb
    71e6bf3046a1:	mulpd  xmm0,xmm1
    71e6bf3046a5:	movdqa xmm4,xmm0
    71e6bf3046a9:	movdqa xmm0,xmm4
    71e6bf3046ad:	movdqu XMMWORD PTR [r12+0x120],xmm0
    71e6bf3046b7:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    71e6bf3046c1:	movdqa xmm2,xmm0
    71e6bf3046c5:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    71e6bf3046cf:	movdqa xmm3,xmm0
    71e6bf3046d3:	movdqa xmm0,xmm2
    71e6bf3046d7:	movdqa xmm1,xmm3
    71e6bf3046db:	movq   rax,xmm0
    71e6bf3046e0:	add    rax,rax
    71e6bf3046e3:	je     0x71e6bf3046f9
    71e6bf3046e5:	shr    rax,0x35
    71e6bf3046e9:	sub    eax,0x201
    71e6bf3046ee:	cmp    eax,0x3fc
    71e6bf3046f3:	ja     0x71e6bf30570f
    71e6bf3046f9:	movdqa xmm14,xmm0
    71e6bf3046fe:	psrldq xmm14,0x8
    71e6bf304704:	movq   rax,xmm14
    71e6bf304709:	add    rax,rax
    71e6bf30470c:	je     0x71e6bf304722
    71e6bf30470e:	shr    rax,0x35
    71e6bf304712:	sub    eax,0x201
    71e6bf304717:	cmp    eax,0x3fc
    71e6bf30471c:	ja     0x71e6bf30570f
    71e6bf304722:	movq   rax,xmm1
    71e6bf304727:	add    rax,rax
    71e6bf30472a:	je     0x71e6bf304740
    71e6bf30472c:	shr    rax,0x35
    71e6bf304730:	sub    eax,0x201
    71e6bf304735:	cmp    eax,0x3fc
    71e6bf30473a:	ja     0x71e6bf30570f
    71e6bf304740:	movdqa xmm14,xmm1
    71e6bf304745:	psrldq xmm14,0x8
    71e6bf30474b:	movq   rax,xmm14
    71e6bf304750:	add    rax,rax
    71e6bf304753:	je     0x71e6bf304769
    71e6bf304755:	shr    rax,0x35
    71e6bf304759:	sub    eax,0x201
    71e6bf30475e:	cmp    eax,0x3fc
    71e6bf304763:	ja     0x71e6bf30570f
    71e6bf304769:	addpd  xmm0,xmm1
    71e6bf30476d:	movdqa xmm4,xmm0
    71e6bf304771:	movdqa xmm0,xmm4
    71e6bf304775:	movdqu XMMWORD PTR [r12+0x140],xmm0
    71e6bf30477f:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    71e6bf304789:	movdqa xmm2,xmm0
    71e6bf30478d:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    71e6bf304797:	movdqa xmm3,xmm0
    71e6bf30479b:	movdqa xmm0,xmm2
    71e6bf30479f:	movdqa xmm1,xmm3
    71e6bf3047a3:	movq   rax,xmm0
    71e6bf3047a8:	add    rax,rax
    71e6bf3047ab:	je     0x71e6bf3047c1
    71e6bf3047ad:	shr    rax,0x35
    71e6bf3047b1:	sub    eax,0x201
    71e6bf3047b6:	cmp    eax,0x3fc
    71e6bf3047bb:	ja     0x71e6bf305733
    71e6bf3047c1:	movdqa xmm14,xmm0
    71e6bf3047c6:	psrldq xmm14,0x8
    71e6bf3047cc:	movq   rax,xmm14
    71e6bf3047d1:	add    rax,rax
    71e6bf3047d4:	je     0x71e6bf3047ea
    71e6bf3047d6:	shr    rax,0x35
    71e6bf3047da:	sub    eax,0x201
    71e6bf3047df:	cmp    eax,0x3fc
    71e6bf3047e4:	ja     0x71e6bf305733
    71e6bf3047ea:	movq   rax,xmm1
    71e6bf3047ef:	add    rax,rax
    71e6bf3047f2:	je     0x71e6bf304808
    71e6bf3047f4:	shr    rax,0x35
    71e6bf3047f8:	sub    eax,0x201
    71e6bf3047fd:	cmp    eax,0x3fc
    71e6bf304802:	ja     0x71e6bf305733
    71e6bf304808:	movdqa xmm14,xmm1
    71e6bf30480d:	psrldq xmm14,0x8
    71e6bf304813:	movq   rax,xmm14
    71e6bf304818:	add    rax,rax
    71e6bf30481b:	je     0x71e6bf304831
    71e6bf30481d:	shr    rax,0x35
    71e6bf304821:	sub    eax,0x201
    71e6bf304826:	cmp    eax,0x3fc
    71e6bf30482b:	ja     0x71e6bf305733
    71e6bf304831:	addpd  xmm0,xmm1
    71e6bf304835:	movdqa xmm4,xmm0
    71e6bf304839:	movdqa xmm0,xmm4
    71e6bf30483d:	movdqu XMMWORD PTR [r12+0x150],xmm0
    71e6bf304847:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    71e6bf304851:	movdqa xmm2,xmm0
    71e6bf304855:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    71e6bf30485f:	movdqa xmm3,xmm0
    71e6bf304863:	movdqa xmm0,xmm2
    71e6bf304867:	movdqa xmm1,xmm3
    71e6bf30486b:	movq   rax,xmm0
    71e6bf304870:	add    rax,rax
    71e6bf304873:	je     0x71e6bf304889
    71e6bf304875:	shr    rax,0x35
    71e6bf304879:	sub    eax,0x201
    71e6bf30487e:	cmp    eax,0x3fc
    71e6bf304883:	ja     0x71e6bf305757
    71e6bf304889:	movdqa xmm14,xmm0
    71e6bf30488e:	psrldq xmm14,0x8
    71e6bf304894:	movq   rax,xmm14
    71e6bf304899:	add    rax,rax
    71e6bf30489c:	je     0x71e6bf3048b2
    71e6bf30489e:	shr    rax,0x35
    71e6bf3048a2:	sub    eax,0x201
    71e6bf3048a7:	cmp    eax,0x3fc
    71e6bf3048ac:	ja     0x71e6bf305757
    71e6bf3048b2:	movq   rax,xmm1
    71e6bf3048b7:	add    rax,rax
    71e6bf3048ba:	je     0x71e6bf3048d0
    71e6bf3048bc:	shr    rax,0x35
    71e6bf3048c0:	sub    eax,0x201
    71e6bf3048c5:	cmp    eax,0x3fc
    71e6bf3048ca:	ja     0x71e6bf305757
    71e6bf3048d0:	movdqa xmm14,xmm1
    71e6bf3048d5:	psrldq xmm14,0x8
    71e6bf3048db:	movq   rax,xmm14
    71e6bf3048e0:	add    rax,rax
    71e6bf3048e3:	je     0x71e6bf3048f9
    71e6bf3048e5:	shr    rax,0x35
    71e6bf3048e9:	sub    eax,0x201
    71e6bf3048ee:	cmp    eax,0x3fc
    71e6bf3048f3:	ja     0x71e6bf305757
    71e6bf3048f9:	addpd  xmm0,xmm1
    71e6bf3048fd:	movdqa xmm4,xmm0
    71e6bf304901:	movdqa xmm0,xmm4
    71e6bf304905:	movdqu XMMWORD PTR [r12+0x160],xmm0
    71e6bf30490f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    71e6bf304919:	movdqa xmm2,xmm0
    71e6bf30491d:	movdqa xmm0,xmm7
    71e6bf304921:	movdqa xmm1,xmm2
    71e6bf304925:	movq   rax,xmm0
    71e6bf30492a:	add    rax,rax
    71e6bf30492d:	je     0x71e6bf304943
    71e6bf30492f:	shr    rax,0x35
    71e6bf304933:	sub    eax,0x201
    71e6bf304938:	cmp    eax,0x3fc
    71e6bf30493d:	ja     0x71e6bf30577b
    71e6bf304943:	movdqa xmm14,xmm0
    71e6bf304948:	psrldq xmm14,0x8
    71e6bf30494e:	movq   rax,xmm14
    71e6bf304953:	add    rax,rax
    71e6bf304956:	je     0x71e6bf30496c
    71e6bf304958:	shr    rax,0x35
    71e6bf30495c:	sub    eax,0x201
    71e6bf304961:	cmp    eax,0x3fc
    71e6bf304966:	ja     0x71e6bf30577b
    71e6bf30496c:	movq   rax,xmm1
    71e6bf304971:	add    rax,rax
    71e6bf304974:	je     0x71e6bf30498a
    71e6bf304976:	shr    rax,0x35
    71e6bf30497a:	sub    eax,0x201
    71e6bf30497f:	cmp    eax,0x3fc
    71e6bf304984:	ja     0x71e6bf30577b
    71e6bf30498a:	movdqa xmm14,xmm1
    71e6bf30498f:	psrldq xmm14,0x8
    71e6bf304995:	movq   rax,xmm14
    71e6bf30499a:	add    rax,rax
    71e6bf30499d:	je     0x71e6bf3049b3
    71e6bf30499f:	shr    rax,0x35
    71e6bf3049a3:	sub    eax,0x201
    71e6bf3049a8:	cmp    eax,0x3fc
    71e6bf3049ad:	ja     0x71e6bf30577b
    71e6bf3049b3:	addpd  xmm0,xmm1
    71e6bf3049b7:	movdqa xmm3,xmm0
    71e6bf3049bb:	movdqa xmm0,xmm3
    71e6bf3049bf:	movdqu XMMWORD PTR [r12+0x120],xmm0
    71e6bf3049c9:	mov    r13,QWORD PTR [r12+0x60]
    71e6bf3049ce:	mov    r14,r13
    71e6bf3049d1:	add    r14,0x10
    71e6bf3049d5:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    71e6bf3049df:	movdqa xmm2,xmm0
    71e6bf3049e3:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    71e6bf3049ed:	movdqa xmm4,xmm0
    71e6bf3049f1:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf3049f9:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf304a01:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf304a09:	shr    r11d,1
    71e6bf304a0c:	and    r11d,0x10
    71e6bf304a10:	or     DWORD PTR [r12+0x314],r11d
    71e6bf304a18:	movdqu XMMWORD PTR [r13+0x0],xmm2
    71e6bf304a1e:	mov    r15d,0x0
    71e6bf304a24:	mov    DWORD PTR [r12+0x32c],r15d
    71e6bf304a2c:	movdqu XMMWORD PTR [r14],xmm4
    71e6bf304a31:	mov    r14d,0x0
    71e6bf304a37:	mov    DWORD PTR [r12+0x32c],r14d
    71e6bf304a3f:	add    r13,0x20
    71e6bf304a43:	mov    r14,r13
    71e6bf304a46:	add    r14,0x10
    71e6bf304a4a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    71e6bf304a54:	movdqa xmm2,xmm0
    71e6bf304a58:	movdqu XMMWORD PTR [r13+0x0],xmm2
    71e6bf304a5e:	mov    r13d,0x0
    71e6bf304a64:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf304a6c:	movdqu XMMWORD PTR [r14],xmm3
    71e6bf304a71:	mov    r13d,0x0
    71e6bf304a77:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf304a7f:	mov    rcx,QWORD PTR [r12+0x380]
    71e6bf304a87:	jrcxz  0x71e6bf304a8e
    71e6bf304a89:	jmp    0x71e6bf307068
    71e6bf304a8e:	push   QWORD PTR [rsp]
    71e6bf304a91:	popf
    71e6bf304a92:	je     0x71e6bf304a9d
    71e6bf304a98:	jmp    0x71e6bf300ed8
    71e6bf304a9d:	mov    r13d,DWORD PTR [r12+0x48]
    71e6bf304aa2:	add    r13d,0x1
    71e6bf304aa6:	mov    QWORD PTR [r12+0x48],r13
    71e6bf304aab:	sub    r13d,0x1f4
    71e6bf304ab2:	mov    rcx,QWORD PTR [r12+0x380]
    71e6bf304aba:	jrcxz  0x71e6bf304ac1
    71e6bf304abc:	jmp    0x71e6bf3070f2
    71e6bf304ac1:	pushf
    71e6bf304ac2:	pop    r11
    71e6bf304ac4:	mov    QWORD PTR [rsp],r11
    71e6bf304ac8:	jne    0x71e6bf300ec8
    71e6bf304ace:	jmp    0x71e6bf304ad3
    71e6bf304ad3:	mov    r13d,0x0
    71e6bf304ad9:	mov    QWORD PTR [r12+0x48],r13
    71e6bf304ade:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf304ae6:	mov    r14,r13
    71e6bf304ae9:	add    r14,0x140
    71e6bf304af0:	mov    r15,QWORD PTR [r14]
    71e6bf304af3:	mov    QWORD PTR [r12+0xe8],r15
    71e6bf304afb:	mov    r14,r13
    71e6bf304afe:	add    r14,0x130
    71e6bf304b05:	mov    r15,r14
    71e6bf304b08:	add    r15,0x8
    71e6bf304b0c:	mov    rbp,QWORD PTR [r14]
    71e6bf304b0f:	mov    r14,QWORD PTR [r15]
    71e6bf304b12:	mov    r15d,0x0
    71e6bf304b18:	mov    QWORD PTR [r12+0x1a0],rbp
    71e6bf304b20:	mov    QWORD PTR [r12+0x1a8],r15
    71e6bf304b28:	mov    r15d,0x0
    71e6bf304b2e:	mov    QWORD PTR [r12+0x190],r14
    71e6bf304b36:	mov    QWORD PTR [r12+0x198],r15
    71e6bf304b3e:	add    r13,0x120
    71e6bf304b45:	mov    r14,r13
    71e6bf304b48:	add    r14,0x8
    71e6bf304b4c:	mov    r15,QWORD PTR [r13+0x0]
    71e6bf304b50:	mov    r13,QWORD PTR [r14]
    71e6bf304b53:	mov    r14d,0x0
    71e6bf304b59:	mov    QWORD PTR [r12+0x1c0],r15
    71e6bf304b61:	mov    QWORD PTR [r12+0x1c8],r14
    71e6bf304b69:	mov    r14d,0x0
    71e6bf304b6f:	mov    QWORD PTR [r12+0x1b0],r13
    71e6bf304b77:	mov    QWORD PTR [r12+0x1b8],r14
    71e6bf304b7f:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf304b87:	mov    r14,r13
    71e6bf304b8a:	add    r14,0x110
    71e6bf304b91:	mov    r15,r14
    71e6bf304b94:	add    r15,0x8
    71e6bf304b98:	mov    rbp,QWORD PTR [r14]
    71e6bf304b9b:	mov    r14,QWORD PTR [r15]
    71e6bf304b9e:	mov    r15d,0x0
    71e6bf304ba4:	mov    QWORD PTR [r12+0x1e0],rbp
    71e6bf304bac:	mov    QWORD PTR [r12+0x1e8],r15
    71e6bf304bb4:	mov    r15d,0x0
    71e6bf304bba:	mov    QWORD PTR [r12+0x1d0],r14
    71e6bf304bc2:	mov    QWORD PTR [r12+0x1d8],r15
    71e6bf304bca:	add    r13,0x100
    71e6bf304bd1:	mov    r14,r13
    71e6bf304bd4:	add    r14,0x8
    71e6bf304bd8:	mov    r15,QWORD PTR [r13+0x0]
    71e6bf304bdc:	mov    r13,QWORD PTR [r14]
    71e6bf304bdf:	mov    r14d,0x0
    71e6bf304be5:	mov    QWORD PTR [r12+0x200],r15
    71e6bf304bed:	mov    QWORD PTR [r12+0x208],r14
    71e6bf304bf5:	mov    r14d,0x0
    71e6bf304bfb:	mov    QWORD PTR [r12+0x1f0],r13
    71e6bf304c03:	mov    QWORD PTR [r12+0x1f8],r14
    71e6bf304c0b:	mov    r13d,0x430000
    71e6bf304c11:	mov    QWORD PTR [r12+0x40],r13
    71e6bf304c16:	mov    r13d,0x430510
    71e6bf304c1c:	mov    r14,QWORD PTR [r13+0x0]
    71e6bf304c20:	mov    r13d,0x0
    71e6bf304c26:	mov    QWORD PTR [r12+0x110],r14
    71e6bf304c2e:	mov    QWORD PTR [r12+0x118],r13
    71e6bf304c36:	mov    r13,QWORD PTR [r12+0xf8]
    71e6bf304c3e:	add    r13,0x150
    71e6bf304c45:	mov    QWORD PTR [r12+0xf8],r13
    71e6bf304c4d:	jmp    0x71e6bf304c52
    71e6bf304c52:	mov    r13,QWORD PTR [r12+0x48]
    71e6bf304c57:	mov    r14,QWORD PTR [r12+0x50]
    71e6bf304c5c:	mov    rcx,r13
    71e6bf304c5f:	add    r14,rcx
    71e6bf304c62:	movdqu xmm2,XMMWORD PTR [r14]
    71e6bf304c67:	movdqa xmm0,xmm2
    71e6bf304c6b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    71e6bf304c75:	add    r13,0x10
    71e6bf304c79:	mov    QWORD PTR [r12+0x48],r13
    71e6bf304c7e:	sub    r13,0x200
    71e6bf304c85:	mov    r13,QWORD PTR [r12+0x128]
    71e6bf304c8d:	mov    r14d,0x0
    71e6bf304c93:	mov    QWORD PTR [r12+0x130],r13
    71e6bf304c9b:	mov    QWORD PTR [r12+0x138],r14
    71e6bf304ca3:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    71e6bf304cad:	movdqa xmm2,xmm0
    71e6bf304cb1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    71e6bf304cbb:	movdqa xmm3,xmm0
    71e6bf304cbf:	pushf
    71e6bf304cc0:	pop    r11
    71e6bf304cc2:	mov    QWORD PTR [rsp],r11
    71e6bf304cc6:	stmxcsr DWORD PTR [rsp+0x110]
    71e6bf304cce:	mov    DWORD PTR [rsp+0x114],0x1f80
    71e6bf304cd9:	ldmxcsr DWORD PTR [rsp+0x114]
    71e6bf304ce1:	movdqa xmm0,xmm2
    71e6bf304ce5:	movdqa xmm1,xmm3
    71e6bf304ce9:	movq   rax,xmm0
    71e6bf304cee:	add    rax,rax
    71e6bf304cf1:	je     0x71e6bf304d07
    71e6bf304cf3:	shr    rax,0x35
    71e6bf304cf7:	sub    eax,0x201
    71e6bf304cfc:	cmp    eax,0x3fc
    71e6bf304d01:	ja     0x71e6bf30579f
    71e6bf304d07:	movq   rax,xmm1
    71e6bf304d0c:	add    rax,rax
    71e6bf304d0f:	je     0x71e6bf304d25
    71e6bf304d11:	shr    rax,0x35
    71e6bf304d15:	sub    eax,0x201
    71e6bf304d1a:	cmp    eax,0x3fc
    71e6bf304d1f:	ja     0x71e6bf30579f
    71e6bf304d25:	movq   xmm0,xmm0
    71e6bf304d29:	movq   xmm1,xmm1
    71e6bf304d2d:	addsd  xmm0,xmm1
    71e6bf304d31:	movdqa xmm4,xmm0
    71e6bf304d35:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    71e6bf304d3f:	movdqa xmm2,xmm0
    71e6bf304d43:	movdqa xmm0,xmm4
    71e6bf304d47:	movdqa xmm1,xmm2
    71e6bf304d4b:	movq   rax,xmm0
    71e6bf304d50:	add    rax,rax
    71e6bf304d53:	je     0x71e6bf304d69
    71e6bf304d55:	shr    rax,0x35
    71e6bf304d59:	sub    eax,0x201
    71e6bf304d5e:	cmp    eax,0x3fc
    71e6bf304d63:	ja     0x71e6bf3057c3
    71e6bf304d69:	movq   rax,xmm1
    71e6bf304d6e:	add    rax,rax
    71e6bf304d71:	je     0x71e6bf304d87
    71e6bf304d73:	shr    rax,0x35
    71e6bf304d77:	sub    eax,0x201
    71e6bf304d7c:	cmp    eax,0x3fc
    71e6bf304d81:	ja     0x71e6bf3057c3
    71e6bf304d87:	movq   xmm0,xmm0
    71e6bf304d8b:	movq   xmm1,xmm1
    71e6bf304d8f:	addsd  xmm0,xmm1
    71e6bf304d93:	movdqa xmm3,xmm0
    71e6bf304d97:	movdqa xmm0,xmm3
    71e6bf304d9b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    71e6bf304da5:	stmxcsr DWORD PTR [rsp+0x114]
    71e6bf304dad:	ldmxcsr DWORD PTR [rsp+0x110]
    71e6bf304db5:	mov    r11d,DWORD PTR [rsp+0x114]
    71e6bf304dbd:	shr    r11d,1
    71e6bf304dc0:	and    r11d,0x10
    71e6bf304dc4:	or     DWORD PTR [r12+0x314],r11d
    71e6bf304dcc:	mov    rcx,QWORD PTR [r12+0x380]
    71e6bf304dd4:	jrcxz  0x71e6bf304ddb
    71e6bf304dd6:	jmp    0x71e6bf307184
    71e6bf304ddb:	push   QWORD PTR [rsp]
    71e6bf304dde:	popf
    71e6bf304ddf:	jne    0x71e6bf304c52
    71e6bf304de5:	jmp    0x71e6bf304dea
    71e6bf304dea:	mov    r13,QWORD PTR [r12+0x40]
    71e6bf304def:	add    r13,0x510
    71e6bf304df6:	mov    r14,QWORD PTR [r12+0x110]
    71e6bf304dfe:	mov    QWORD PTR [r13+0x0],r14
    71e6bf304e02:	mov    r13d,0x0
    71e6bf304e08:	mov    DWORD PTR [r12+0x32c],r13d
    71e6bf304e10:	mov    rcx,QWORD PTR [r12+0x380]
    71e6bf304e18:	jrcxz  0x71e6bf304e1f
    71e6bf304e1a:	jmp    0x71e6bf30720e
    71e6bf304e1f:	mov    r13,QWORD PTR [r12+0xf0]
    71e6bf304e27:	mov    QWORD PTR [r12+0x100],r13
    71e6bf304e2f:	mov    r11,QWORD PTR [rsp]
    71e6bf304e33:	mov    QWORD PTR [r12+0x398],r11
    71e6bf304e3b:	mov    rdi,QWORD PTR [r12+0x100]
    71e6bf304e43:	add    rsp,0x150
    71e6bf304e4a:	movabs r11,0x5f73f3e930a0
    71e6bf304e54:	jmp    r11
    71e6bf304e57:	movdqa xmm0,xmm2
    71e6bf304e5b:	movdqa xmm1,xmm3
    71e6bf304e5f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304e68:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304e71:	call   0x71e6bf3057f0
    71e6bf304e76:	jmp    0x71e6bf3005be
    71e6bf304e7b:	movdqa xmm0,xmm2
    71e6bf304e7f:	movdqa xmm1,xmm3
    71e6bf304e83:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304e8c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304e95:	call   0x71e6bf3057f0
    71e6bf304e9a:	jmp    0x71e6bf3006eb
    71e6bf304e9f:	movdqa xmm0,xmm3
    71e6bf304ea3:	movdqa xmm1,xmm4
    71e6bf304ea7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304eb0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304eb9:	call   0x71e6bf3058d0
    71e6bf304ebe:	jmp    0x71e6bf3011a1
    71e6bf304ec3:	movdqa xmm0,xmm2
    71e6bf304ec7:	movdqa xmm1,xmm4
    71e6bf304ecb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304ed4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304edd:	call   0x71e6bf305a60
    71e6bf304ee2:	jmp    0x71e6bf301260
    71e6bf304ee7:	movdqa xmm0,xmm3
    71e6bf304eeb:	movdqa xmm1,xmm2
    71e6bf304eef:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304ef8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304f01:	call   0x71e6bf305bf0
    71e6bf304f06:	jmp    0x71e6bf301336
    71e6bf304f0b:	movdqa xmm0,xmm3
    71e6bf304f0f:	movdqa xmm1,xmm2
    71e6bf304f13:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304f1c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304f25:	call   0x71e6bf305bf0
    71e6bf304f2a:	jmp    0x71e6bf3013f0
    71e6bf304f2f:	movdqa xmm0,xmm2
    71e6bf304f33:	movdqa xmm1,xmm3
    71e6bf304f37:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304f40:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304f49:	call   0x71e6bf305bf0
    71e6bf304f4e:	jmp    0x71e6bf3014b8
    71e6bf304f53:	movdqa xmm0,xmm2
    71e6bf304f57:	movdqa xmm1,xmm3
    71e6bf304f5b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304f64:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304f6d:	call   0x71e6bf305d70
    71e6bf304f72:	jmp    0x71e6bf3015c3
    71e6bf304f77:	movdqa xmm0,xmm2
    71e6bf304f7b:	movdqa xmm1,xmm3
    71e6bf304f7f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304f88:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304f91:	call   0x71e6bf305ef0
    71e6bf304f96:	jmp    0x71e6bf3016e0
    71e6bf304f9b:	movdqa xmm0,xmm2
    71e6bf304f9f:	movdqa xmm1,xmm3
    71e6bf304fa3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304fac:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304fb5:	call   0x71e6bf305ef0
    71e6bf304fba:	jmp    0x71e6bf3017a8
    71e6bf304fbf:	movdqa xmm0,xmm2
    71e6bf304fc3:	movdqa xmm1,xmm3
    71e6bf304fc7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304fd0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304fd9:	call   0x71e6bf305ef0
    71e6bf304fde:	jmp    0x71e6bf301862
    71e6bf304fe3:	movdqa xmm0,xmm2
    71e6bf304fe7:	movdqa xmm1,xmm4
    71e6bf304feb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf304ff4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf304ffd:	call   0x71e6bf306070
    71e6bf305002:	jmp    0x71e6bf301aa7
    71e6bf305007:	movdqa xmm0,xmm4
    71e6bf30500b:	movdqa xmm1,xmm5
    71e6bf30500f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305018:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305021:	call   0x71e6bf306200
    71e6bf305026:	jmp    0x71e6bf301bcc
    71e6bf30502b:	movdqa xmm0,xmm4
    71e6bf30502f:	movdqa xmm1,xmm5
    71e6bf305033:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf30503c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305045:	call   0x71e6bf306200
    71e6bf30504a:	jmp    0x71e6bf301c94
    71e6bf30504f:	movdqa xmm0,xmm3
    71e6bf305053:	movdqa xmm1,xmm4
    71e6bf305057:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305060:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305069:	call   0x71e6bf305a60
    71e6bf30506e:	jmp    0x71e6bf301d53
    71e6bf305073:	movdqa xmm0,xmm2
    71e6bf305077:	movdqa xmm1,xmm3
    71e6bf30507b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305084:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf30508d:	call   0x71e6bf305a60
    71e6bf305092:	jmp    0x71e6bf301e12
    71e6bf305097:	movdqa xmm0,xmm2
    71e6bf30509b:	movdqa xmm1,xmm4
    71e6bf30509f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3050a8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3050b1:	call   0x71e6bf305a60
    71e6bf3050b6:	jmp    0x71e6bf301f38
    71e6bf3050bb:	movdqa xmm0,xmm2
    71e6bf3050bf:	movdqa xmm1,xmm3
    71e6bf3050c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3050cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3050d5:	call   0x71e6bf305d70
    71e6bf3050da:	jmp    0x71e6bf30203f
    71e6bf3050df:	movdqa xmm0,xmm3
    71e6bf3050e3:	movdqa xmm1,xmm4
    71e6bf3050e7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3050f0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3050f9:	call   0x71e6bf306070
    71e6bf3050fe:	jmp    0x71e6bf3021f4
    71e6bf305103:	movdqa xmm0,xmm2
    71e6bf305107:	movdqa xmm1,xmm3
    71e6bf30510b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305114:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf30511d:	call   0x71e6bf305d70
    71e6bf305122:	jmp    0x71e6bf3022b3
    71e6bf305127:	movdqa xmm0,xmm3
    71e6bf30512b:	movdqa xmm1,xmm4
    71e6bf30512f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305138:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305141:	call   0x71e6bf306070
    71e6bf305146:	jmp    0x71e6bf3023e0
    71e6bf30514b:	movdqa xmm0,xmm3
    71e6bf30514f:	movdqa xmm1,xmm4
    71e6bf305153:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf30515c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305165:	call   0x71e6bf306070
    71e6bf30516a:	jmp    0x71e6bf3024a8
    71e6bf30516f:	movdqa xmm0,xmm2
    71e6bf305173:	movdqa xmm1,xmm3
    71e6bf305177:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305180:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305189:	call   0x71e6bf305d70
    71e6bf30518e:	jmp    0x71e6bf30258b
    71e6bf305193:	movdqa xmm0,xmm3
    71e6bf305197:	movdqa xmm1,xmm4
    71e6bf30519b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3051a4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3051ad:	call   0x71e6bf306070
    71e6bf3051b2:	jmp    0x71e6bf3026b8
    71e6bf3051b7:	movdqa xmm0,xmm3
    71e6bf3051bb:	movdqa xmm1,xmm4
    71e6bf3051bf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3051c8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3051d1:	call   0x71e6bf305a60
    71e6bf3051d6:	jmp    0x71e6bf302785
    71e6bf3051db:	movdqa xmm0,xmm2
    71e6bf3051df:	movdqa xmm1,xmm4
    71e6bf3051e3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3051ec:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3051f5:	call   0x71e6bf306390
    71e6bf3051fa:	jmp    0x71e6bf302852
    71e6bf3051ff:	movdqa xmm0,xmm3
    71e6bf305203:	movdqa xmm1,xmm4
    71e6bf305207:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305210:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305219:	call   0x71e6bf306070
    71e6bf30521e:	jmp    0x71e6bf302981
    71e6bf305223:	movdqa xmm0,xmm2
    71e6bf305227:	movdqa xmm1,xmm3
    71e6bf30522b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305234:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf30523d:	call   0x71e6bf305d70
    71e6bf305242:	jmp    0x71e6bf302a88
    71e6bf305247:	movdqa xmm0,xmm2
    71e6bf30524b:	movdqa xmm1,xmm4
    71e6bf30524f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305258:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305261:	call   0x71e6bf306070
    71e6bf305266:	jmp    0x71e6bf302baa
    71e6bf30526b:	movdqa xmm0,xmm2
    71e6bf30526f:	movdqa xmm1,xmm3
    71e6bf305273:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf30527c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305285:	call   0x71e6bf305d70
    71e6bf30528a:	jmp    0x71e6bf302c69
    71e6bf30528f:	movdqa xmm0,xmm2
    71e6bf305293:	movdqa xmm1,xmm3
    71e6bf305297:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3052a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3052a9:	call   0x71e6bf305ef0
    71e6bf3052ae:	jmp    0x71e6bf302d31
    71e6bf3052b3:	movdqa xmm0,xmm2
    71e6bf3052b7:	movdqa xmm1,xmm3
    71e6bf3052bb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3052c4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3052cd:	call   0x71e6bf305d70
    71e6bf3052d2:	jmp    0x71e6bf302dfe
    71e6bf3052d7:	movdqa xmm0,xmm2
    71e6bf3052db:	movdqa xmm1,xmm3
    71e6bf3052df:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3052e8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3052f1:	call   0x71e6bf305d70
    71e6bf3052f6:	jmp    0x71e6bf302ebd
    71e6bf3052fb:	movdqa xmm0,xmm2
    71e6bf3052ff:	movdqa xmm1,xmm4
    71e6bf305303:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf30530c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305315:	call   0x71e6bf306070
    71e6bf30531a:	jmp    0x71e6bf302f85
    71e6bf30531f:	movdqa xmm0,xmm2
    71e6bf305323:	movdqa xmm1,xmm4
    71e6bf305327:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305330:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305339:	call   0x71e6bf306070
    71e6bf30533e:	jmp    0x71e6bf30304d
    71e6bf305343:	movdqa xmm0,xmm2
    71e6bf305347:	movdqa xmm1,xmm3
    71e6bf30534b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305354:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf30535d:	call   0x71e6bf305d70
    71e6bf305362:	jmp    0x71e6bf30310c
    71e6bf305367:	movdqa xmm0,xmm2
    71e6bf30536b:	movdqa xmm1,xmm3
    71e6bf30536f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305378:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305381:	call   0x71e6bf305d70
    71e6bf305386:	jmp    0x71e6bf3031cb
    71e6bf30538b:	movdqa xmm0,xmm2
    71e6bf30538f:	movdqa xmm1,xmm3
    71e6bf305393:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf30539c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3053a5:	call   0x71e6bf305ef0
    71e6bf3053aa:	jmp    0x71e6bf303293
    71e6bf3053af:	movdqa xmm0,xmm2
    71e6bf3053b3:	movdqa xmm1,xmm3
    71e6bf3053b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3053c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3053c9:	call   0x71e6bf305ef0
    71e6bf3053ce:	jmp    0x71e6bf30335b
    71e6bf3053d3:	movdqa xmm0,xmm2
    71e6bf3053d7:	movdqa xmm1,xmm3
    71e6bf3053db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3053e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3053ed:	call   0x71e6bf305d70
    71e6bf3053f2:	jmp    0x71e6bf303428
    71e6bf3053f7:	movdqa xmm0,xmm2
    71e6bf3053fb:	movdqa xmm1,xmm3
    71e6bf3053ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305408:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305411:	call   0x71e6bf305ef0
    71e6bf305416:	jmp    0x71e6bf3034f0
    71e6bf30541b:	movdqa xmm0,xmm2
    71e6bf30541f:	movdqa xmm1,xmm3
    71e6bf305423:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf30542c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305435:	call   0x71e6bf305ef0
    71e6bf30543a:	jmp    0x71e6bf3035b8
    71e6bf30543f:	movdqa xmm0,xmm2
    71e6bf305443:	movdqa xmm1,xmm3
    71e6bf305447:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305450:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305459:	call   0x71e6bf305d70
    71e6bf30545e:	jmp    0x71e6bf303753
    71e6bf305463:	movdqa xmm0,xmm2
    71e6bf305467:	movdqa xmm1,xmm4
    71e6bf30546b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305474:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf30547d:	call   0x71e6bf306070
    71e6bf305482:	jmp    0x71e6bf30381b
    71e6bf305487:	movdqa xmm0,xmm2
    71e6bf30548b:	movdqa xmm1,xmm4
    71e6bf30548f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305498:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3054a1:	call   0x71e6bf306070
    71e6bf3054a6:	jmp    0x71e6bf3038e3
    71e6bf3054ab:	movdqa xmm0,xmm2
    71e6bf3054af:	movdqa xmm1,xmm3
    71e6bf3054b3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3054bc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3054c5:	call   0x71e6bf305d70
    71e6bf3054ca:	jmp    0x71e6bf3039a2
    71e6bf3054cf:	movdqa xmm0,xmm2
    71e6bf3054d3:	movdqa xmm1,xmm3
    71e6bf3054d7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3054e0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3054e9:	call   0x71e6bf305d70
    71e6bf3054ee:	jmp    0x71e6bf303a6f
    71e6bf3054f3:	movdqa xmm0,xmm2
    71e6bf3054f7:	movdqa xmm1,xmm3
    71e6bf3054fb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305504:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf30550d:	call   0x71e6bf305d70
    71e6bf305512:	jmp    0x71e6bf303b3c
    71e6bf305517:	movdqa xmm0,xmm2
    71e6bf30551b:	movdqa xmm1,xmm4
    71e6bf30551f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305528:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305531:	call   0x71e6bf306070
    71e6bf305536:	jmp    0x71e6bf303c04
    71e6bf30553b:	movdqa xmm0,xmm2
    71e6bf30553f:	movdqa xmm1,xmm3
    71e6bf305543:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf30554c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305555:	call   0x71e6bf305d70
    71e6bf30555a:	jmp    0x71e6bf303cc3
    71e6bf30555f:	movdqa xmm0,xmm2
    71e6bf305563:	movdqa xmm1,xmm4
    71e6bf305567:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305570:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305579:	call   0x71e6bf306070
    71e6bf30557e:	jmp    0x71e6bf303d8b
    71e6bf305583:	movdqa xmm0,xmm2
    71e6bf305587:	movdqa xmm1,xmm3
    71e6bf30558b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305594:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf30559d:	call   0x71e6bf305d70
    71e6bf3055a2:	jmp    0x71e6bf303e4a
    71e6bf3055a7:	movdqa xmm0,xmm2
    71e6bf3055ab:	movdqa xmm1,xmm3
    71e6bf3055af:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3055b8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3055c1:	call   0x71e6bf305ef0
    71e6bf3055c6:	jmp    0x71e6bf303f12
    71e6bf3055cb:	movdqa xmm0,xmm2
    71e6bf3055cf:	movdqa xmm1,xmm3
    71e6bf3055d3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3055dc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3055e5:	call   0x71e6bf305d70
    71e6bf3055ea:	jmp    0x71e6bf303fdf
    71e6bf3055ef:	movdqa xmm0,xmm2
    71e6bf3055f3:	movdqa xmm1,xmm3
    71e6bf3055f7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305600:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305609:	call   0x71e6bf305ef0
    71e6bf30560e:	jmp    0x71e6bf3040a7
    71e6bf305613:	movdqa xmm0,xmm3
    71e6bf305617:	movdqa xmm1,xmm4
    71e6bf30561b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305624:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf30562d:	call   0x71e6bf306070
    71e6bf305632:	jmp    0x71e6bf3041d3
    71e6bf305637:	movdqa xmm0,xmm2
    71e6bf30563b:	movdqa xmm1,xmm3
    71e6bf30563f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305648:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305651:	call   0x71e6bf305d70
    71e6bf305656:	jmp    0x71e6bf304292
    71e6bf30565b:	movdqa xmm0,xmm2
    71e6bf30565f:	movdqa xmm1,xmm3
    71e6bf305663:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf30566c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305675:	call   0x71e6bf305d70
    71e6bf30567a:	jmp    0x71e6bf304351
    71e6bf30567f:	movdqa xmm0,xmm2
    71e6bf305683:	movdqa xmm1,xmm4
    71e6bf305687:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305690:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305699:	call   0x71e6bf306070
    71e6bf30569e:	jmp    0x71e6bf304419
    71e6bf3056a3:	movdqa xmm0,xmm5
    71e6bf3056a7:	movdqa xmm1,xmm6
    71e6bf3056ab:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3056b4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3056bd:	call   0x71e6bf306510
    71e6bf3056c2:	jmp    0x71e6bf304543
    71e6bf3056c7:	movdqa xmm0,xmm4
    71e6bf3056cb:	movdqa xmm1,xmm3
    71e6bf3056cf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3056d8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3056e1:	call   0x71e6bf3066b0
    71e6bf3056e6:	jmp    0x71e6bf3045f4
    71e6bf3056eb:	movdqa xmm0,xmm2
    71e6bf3056ef:	movdqa xmm1,xmm3
    71e6bf3056f3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3056fc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305705:	call   0x71e6bf306840
    71e6bf30570a:	jmp    0x71e6bf3046a5
    71e6bf30570f:	movdqa xmm0,xmm2
    71e6bf305713:	movdqa xmm1,xmm3
    71e6bf305717:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305720:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305729:	call   0x71e6bf3069d0
    71e6bf30572e:	jmp    0x71e6bf30476d
    71e6bf305733:	movdqa xmm0,xmm2
    71e6bf305737:	movdqa xmm1,xmm3
    71e6bf30573b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305744:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf30574d:	call   0x71e6bf3069d0
    71e6bf305752:	jmp    0x71e6bf304835
    71e6bf305757:	movdqa xmm0,xmm2
    71e6bf30575b:	movdqa xmm1,xmm3
    71e6bf30575f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf305768:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305771:	call   0x71e6bf3069d0
    71e6bf305776:	jmp    0x71e6bf3048fd
    71e6bf30577b:	movdqa xmm0,xmm7
    71e6bf30577f:	movdqa xmm1,xmm2
    71e6bf305783:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf30578c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf305795:	call   0x71e6bf306b60
    71e6bf30579a:	jmp    0x71e6bf3049b7
    71e6bf30579f:	movdqa xmm0,xmm2
    71e6bf3057a3:	movdqa xmm1,xmm3
    71e6bf3057a7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3057b0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3057b9:	call   0x71e6bf306ce0
    71e6bf3057be:	jmp    0x71e6bf304d31
    71e6bf3057c3:	movdqa xmm0,xmm4
    71e6bf3057c7:	movdqa xmm1,xmm2
    71e6bf3057cb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71e6bf3057d4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71e6bf3057dd:	call   0x71e6bf306e60
    71e6bf3057e2:	jmp    0x71e6bf304d93
    71e6bf3057e7:	nop    WORD PTR [rax+rax*1+0x0]
    71e6bf3057f0:	sub    rsp,0x8
    71e6bf3057f4:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf3057fc:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf305804:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf30580c:	shr    r11d,1
    71e6bf30580f:	and    r11d,0x10
    71e6bf305813:	or     DWORD PTR [r12+0x314],r11d
    71e6bf30581b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf305827:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf30582d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf305833:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf30583b:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf305841:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf305847:	lea    rdi,[rsp+0x110]
    71e6bf30584f:	lea    rsi,[rsp+0xf0]
    71e6bf305857:	lea    rdx,[rsp+0x100]
    71e6bf30585f:	mov    ecx,0x16
    71e6bf305864:	mov    r8d,0x0
    71e6bf30586a:	lea    r9,[r12+0x314]
    71e6bf305872:	movabs r11,0x5f73f3cfe1b0
    71e6bf30587c:	call   r11
    71e6bf30587f:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf305885:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf30588b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf305891:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf305899:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf3058a5:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf3058ae:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf3058b6:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf3058c1:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf3058c9:	add    rsp,0x8
    71e6bf3058cd:	ret
    71e6bf3058ce:	xchg   ax,ax
    71e6bf3058d0:	sub    rsp,0x8
    71e6bf3058d4:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf3058dc:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf3058e4:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf3058ec:	shr    r11d,1
    71e6bf3058ef:	and    r11d,0x10
    71e6bf3058f3:	or     DWORD PTR [r12+0x314],r11d
    71e6bf3058fb:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf305907:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf30590d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf305913:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    71e6bf305919:	push   rdx
    71e6bf30591a:	push   rsi
    71e6bf30591b:	push   r10
    71e6bf30591d:	push   r11
    71e6bf30591f:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf305924:	mov    r10d,edx
    71e6bf305927:	and    r10d,0xc0
    71e6bf30592e:	shl    r10d,0x18
    71e6bf305932:	mov    r11d,edx
    71e6bf305935:	and    r11d,0x1
    71e6bf305939:	shl    r11d,0x1d
    71e6bf30593d:	or     r10d,r11d
    71e6bf305940:	mov    r11d,edx
    71e6bf305943:	and    r11d,0x800
    71e6bf30594a:	shl    r11d,0x11
    71e6bf30594e:	or     r10d,r11d
    71e6bf305951:	btc    r10,0x1d
    71e6bf305956:	mov    r11d,0xf0000000
    71e6bf30595c:	and    r11,r10
    71e6bf30595f:	movabs rsi,0xffffffff0fffffff
    71e6bf305969:	and    rbx,rsi
    71e6bf30596c:	or     rbx,r11
    71e6bf30596f:	pop    r11
    71e6bf305971:	pop    r10
    71e6bf305973:	pop    rsi
    71e6bf305974:	pop    rdx
    71e6bf305975:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf30597d:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf305983:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf305989:	lea    rdi,[rsp+0x110]
    71e6bf305991:	lea    rsi,[rsp+0xf0]
    71e6bf305999:	lea    rdx,[rsp+0x100]
    71e6bf3059a1:	mov    ecx,0x16
    71e6bf3059a6:	mov    r8d,0x0
    71e6bf3059ac:	lea    r9,[r12+0x314]
    71e6bf3059b4:	movabs r11,0x5f73f3cfe1b0
    71e6bf3059be:	call   r11
    71e6bf3059c1:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf3059c7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf3059cd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf3059d3:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    71e6bf3059d9:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf3059e1:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf3059ed:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf3059f6:	pushf
    71e6bf3059f7:	pop    rdx
    71e6bf3059f8:	and    rdx,0xfffffffffffff73e
    71e6bf3059ff:	mov    rax,rbx
    71e6bf305a02:	shr    rax,0x18
    71e6bf305a06:	and    eax,0xc0
    71e6bf305a0b:	or     rdx,rax
    71e6bf305a0e:	mov    rax,rbx
    71e6bf305a11:	shr    rax,0x1d
    71e6bf305a15:	and    eax,0x1
    71e6bf305a18:	xor    eax,0x1
    71e6bf305a1b:	or     rdx,rax
    71e6bf305a1e:	mov    rax,rbx
    71e6bf305a21:	shr    rax,0x11
    71e6bf305a25:	and    eax,0x800
    71e6bf305a2a:	or     rdx,rax
    71e6bf305a2d:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf305a32:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf305a3a:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf305a45:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf305a4d:	add    rsp,0x8
    71e6bf305a51:	ret
    71e6bf305a52:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf305a60:	sub    rsp,0x8
    71e6bf305a64:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf305a6c:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf305a74:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf305a7c:	shr    r11d,1
    71e6bf305a7f:	and    r11d,0x10
    71e6bf305a83:	or     DWORD PTR [r12+0x314],r11d
    71e6bf305a8b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf305a97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf305a9d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf305aa3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    71e6bf305aa9:	push   rdx
    71e6bf305aaa:	push   rsi
    71e6bf305aab:	push   r10
    71e6bf305aad:	push   r11
    71e6bf305aaf:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf305ab4:	mov    r10d,edx
    71e6bf305ab7:	and    r10d,0xc0
    71e6bf305abe:	shl    r10d,0x18
    71e6bf305ac2:	mov    r11d,edx
    71e6bf305ac5:	and    r11d,0x1
    71e6bf305ac9:	shl    r11d,0x1d
    71e6bf305acd:	or     r10d,r11d
    71e6bf305ad0:	mov    r11d,edx
    71e6bf305ad3:	and    r11d,0x800
    71e6bf305ada:	shl    r11d,0x11
    71e6bf305ade:	or     r10d,r11d
    71e6bf305ae1:	btc    r10,0x1d
    71e6bf305ae6:	mov    r11d,0xf0000000
    71e6bf305aec:	and    r11,r10
    71e6bf305aef:	movabs rsi,0xffffffff0fffffff
    71e6bf305af9:	and    rbx,rsi
    71e6bf305afc:	or     rbx,r11
    71e6bf305aff:	pop    r11
    71e6bf305b01:	pop    r10
    71e6bf305b03:	pop    rsi
    71e6bf305b04:	pop    rdx
    71e6bf305b05:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf305b0d:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf305b13:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf305b19:	lea    rdi,[rsp+0x110]
    71e6bf305b21:	lea    rsi,[rsp+0xf0]
    71e6bf305b29:	lea    rdx,[rsp+0x100]
    71e6bf305b31:	mov    ecx,0x56
    71e6bf305b36:	mov    r8d,0x0
    71e6bf305b3c:	lea    r9,[r12+0x314]
    71e6bf305b44:	movabs r11,0x5f73f3cfe1b0
    71e6bf305b4e:	call   r11
    71e6bf305b51:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf305b57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf305b5d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf305b63:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    71e6bf305b69:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf305b71:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf305b7d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf305b86:	pushf
    71e6bf305b87:	pop    rdx
    71e6bf305b88:	and    rdx,0xfffffffffffff73e
    71e6bf305b8f:	mov    rax,rbx
    71e6bf305b92:	shr    rax,0x18
    71e6bf305b96:	and    eax,0xc0
    71e6bf305b9b:	or     rdx,rax
    71e6bf305b9e:	mov    rax,rbx
    71e6bf305ba1:	shr    rax,0x1d
    71e6bf305ba5:	and    eax,0x1
    71e6bf305ba8:	xor    eax,0x1
    71e6bf305bab:	or     rdx,rax
    71e6bf305bae:	mov    rax,rbx
    71e6bf305bb1:	shr    rax,0x11
    71e6bf305bb5:	and    eax,0x800
    71e6bf305bba:	or     rdx,rax
    71e6bf305bbd:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf305bc2:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf305bca:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf305bd5:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf305bdd:	add    rsp,0x8
    71e6bf305be1:	ret
    71e6bf305be2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf305bf0:	sub    rsp,0x8
    71e6bf305bf4:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf305bfc:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf305c04:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf305c0c:	shr    r11d,1
    71e6bf305c0f:	and    r11d,0x10
    71e6bf305c13:	or     DWORD PTR [r12+0x314],r11d
    71e6bf305c1b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf305c27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf305c2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf305c33:	push   rdx
    71e6bf305c34:	push   rsi
    71e6bf305c35:	push   r10
    71e6bf305c37:	push   r11
    71e6bf305c39:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf305c3e:	mov    r10d,edx
    71e6bf305c41:	and    r10d,0xc0
    71e6bf305c48:	shl    r10d,0x18
    71e6bf305c4c:	mov    r11d,edx
    71e6bf305c4f:	and    r11d,0x1
    71e6bf305c53:	shl    r11d,0x1d
    71e6bf305c57:	or     r10d,r11d
    71e6bf305c5a:	mov    r11d,edx
    71e6bf305c5d:	and    r11d,0x800
    71e6bf305c64:	shl    r11d,0x11
    71e6bf305c68:	or     r10d,r11d
    71e6bf305c6b:	btc    r10,0x1d
    71e6bf305c70:	mov    r11d,0xf0000000
    71e6bf305c76:	and    r11,r10
    71e6bf305c79:	movabs rsi,0xffffffff0fffffff
    71e6bf305c83:	and    rbx,rsi
    71e6bf305c86:	or     rbx,r11
    71e6bf305c89:	pop    r11
    71e6bf305c8b:	pop    r10
    71e6bf305c8d:	pop    rsi
    71e6bf305c8e:	pop    rdx
    71e6bf305c8f:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf305c97:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf305c9d:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf305ca3:	lea    rdi,[rsp+0x110]
    71e6bf305cab:	lea    rsi,[rsp+0xf0]
    71e6bf305cb3:	lea    rdx,[rsp+0x100]
    71e6bf305cbb:	mov    ecx,0x16
    71e6bf305cc0:	mov    r8d,0x0
    71e6bf305cc6:	lea    r9,[r12+0x314]
    71e6bf305cce:	movabs r11,0x5f73f3cfe1b0
    71e6bf305cd8:	call   r11
    71e6bf305cdb:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf305ce1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf305ce7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf305ced:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf305cf5:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf305d01:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf305d0a:	pushf
    71e6bf305d0b:	pop    rdx
    71e6bf305d0c:	and    rdx,0xfffffffffffff73e
    71e6bf305d13:	mov    rax,rbx
    71e6bf305d16:	shr    rax,0x18
    71e6bf305d1a:	and    eax,0xc0
    71e6bf305d1f:	or     rdx,rax
    71e6bf305d22:	mov    rax,rbx
    71e6bf305d25:	shr    rax,0x1d
    71e6bf305d29:	and    eax,0x1
    71e6bf305d2c:	xor    eax,0x1
    71e6bf305d2f:	or     rdx,rax
    71e6bf305d32:	mov    rax,rbx
    71e6bf305d35:	shr    rax,0x11
    71e6bf305d39:	and    eax,0x800
    71e6bf305d3e:	or     rdx,rax
    71e6bf305d41:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf305d46:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf305d4e:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf305d59:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf305d61:	add    rsp,0x8
    71e6bf305d65:	ret
    71e6bf305d66:	data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf305d70:	sub    rsp,0x8
    71e6bf305d74:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf305d7c:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf305d84:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf305d8c:	shr    r11d,1
    71e6bf305d8f:	and    r11d,0x10
    71e6bf305d93:	or     DWORD PTR [r12+0x314],r11d
    71e6bf305d9b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf305da7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf305dad:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf305db3:	push   rdx
    71e6bf305db4:	push   rsi
    71e6bf305db5:	push   r10
    71e6bf305db7:	push   r11
    71e6bf305db9:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf305dbe:	mov    r10d,edx
    71e6bf305dc1:	and    r10d,0xc0
    71e6bf305dc8:	shl    r10d,0x18
    71e6bf305dcc:	mov    r11d,edx
    71e6bf305dcf:	and    r11d,0x1
    71e6bf305dd3:	shl    r11d,0x1d
    71e6bf305dd7:	or     r10d,r11d
    71e6bf305dda:	mov    r11d,edx
    71e6bf305ddd:	and    r11d,0x800
    71e6bf305de4:	shl    r11d,0x11
    71e6bf305de8:	or     r10d,r11d
    71e6bf305deb:	btc    r10,0x1d
    71e6bf305df0:	mov    r11d,0xf0000000
    71e6bf305df6:	and    r11,r10
    71e6bf305df9:	movabs rsi,0xffffffff0fffffff
    71e6bf305e03:	and    rbx,rsi
    71e6bf305e06:	or     rbx,r11
    71e6bf305e09:	pop    r11
    71e6bf305e0b:	pop    r10
    71e6bf305e0d:	pop    rsi
    71e6bf305e0e:	pop    rdx
    71e6bf305e0f:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf305e17:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf305e1d:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf305e23:	lea    rdi,[rsp+0x110]
    71e6bf305e2b:	lea    rsi,[rsp+0xf0]
    71e6bf305e33:	lea    rdx,[rsp+0x100]
    71e6bf305e3b:	mov    ecx,0x56
    71e6bf305e40:	mov    r8d,0x0
    71e6bf305e46:	lea    r9,[r12+0x314]
    71e6bf305e4e:	movabs r11,0x5f73f3cfe1b0
    71e6bf305e58:	call   r11
    71e6bf305e5b:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf305e61:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf305e67:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf305e6d:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf305e75:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf305e81:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf305e8a:	pushf
    71e6bf305e8b:	pop    rdx
    71e6bf305e8c:	and    rdx,0xfffffffffffff73e
    71e6bf305e93:	mov    rax,rbx
    71e6bf305e96:	shr    rax,0x18
    71e6bf305e9a:	and    eax,0xc0
    71e6bf305e9f:	or     rdx,rax
    71e6bf305ea2:	mov    rax,rbx
    71e6bf305ea5:	shr    rax,0x1d
    71e6bf305ea9:	and    eax,0x1
    71e6bf305eac:	xor    eax,0x1
    71e6bf305eaf:	or     rdx,rax
    71e6bf305eb2:	mov    rax,rbx
    71e6bf305eb5:	shr    rax,0x11
    71e6bf305eb9:	and    eax,0x800
    71e6bf305ebe:	or     rdx,rax
    71e6bf305ec1:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf305ec6:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf305ece:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf305ed9:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf305ee1:	add    rsp,0x8
    71e6bf305ee5:	ret
    71e6bf305ee6:	data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf305ef0:	sub    rsp,0x8
    71e6bf305ef4:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf305efc:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf305f04:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf305f0c:	shr    r11d,1
    71e6bf305f0f:	and    r11d,0x10
    71e6bf305f13:	or     DWORD PTR [r12+0x314],r11d
    71e6bf305f1b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf305f27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf305f2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf305f33:	push   rdx
    71e6bf305f34:	push   rsi
    71e6bf305f35:	push   r10
    71e6bf305f37:	push   r11
    71e6bf305f39:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf305f3e:	mov    r10d,edx
    71e6bf305f41:	and    r10d,0xc0
    71e6bf305f48:	shl    r10d,0x18
    71e6bf305f4c:	mov    r11d,edx
    71e6bf305f4f:	and    r11d,0x1
    71e6bf305f53:	shl    r11d,0x1d
    71e6bf305f57:	or     r10d,r11d
    71e6bf305f5a:	mov    r11d,edx
    71e6bf305f5d:	and    r11d,0x800
    71e6bf305f64:	shl    r11d,0x11
    71e6bf305f68:	or     r10d,r11d
    71e6bf305f6b:	btc    r10,0x1d
    71e6bf305f70:	mov    r11d,0xf0000000
    71e6bf305f76:	and    r11,r10
    71e6bf305f79:	movabs rsi,0xffffffff0fffffff
    71e6bf305f83:	and    rbx,rsi
    71e6bf305f86:	or     rbx,r11
    71e6bf305f89:	pop    r11
    71e6bf305f8b:	pop    r10
    71e6bf305f8d:	pop    rsi
    71e6bf305f8e:	pop    rdx
    71e6bf305f8f:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf305f97:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf305f9d:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf305fa3:	lea    rdi,[rsp+0x110]
    71e6bf305fab:	lea    rsi,[rsp+0xf0]
    71e6bf305fb3:	lea    rdx,[rsp+0x100]
    71e6bf305fbb:	mov    ecx,0x14
    71e6bf305fc0:	mov    r8d,0x0
    71e6bf305fc6:	lea    r9,[r12+0x314]
    71e6bf305fce:	movabs r11,0x5f73f3cfe1b0
    71e6bf305fd8:	call   r11
    71e6bf305fdb:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf305fe1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf305fe7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf305fed:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf305ff5:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf306001:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf30600a:	pushf
    71e6bf30600b:	pop    rdx
    71e6bf30600c:	and    rdx,0xfffffffffffff73e
    71e6bf306013:	mov    rax,rbx
    71e6bf306016:	shr    rax,0x18
    71e6bf30601a:	and    eax,0xc0
    71e6bf30601f:	or     rdx,rax
    71e6bf306022:	mov    rax,rbx
    71e6bf306025:	shr    rax,0x1d
    71e6bf306029:	and    eax,0x1
    71e6bf30602c:	xor    eax,0x1
    71e6bf30602f:	or     rdx,rax
    71e6bf306032:	mov    rax,rbx
    71e6bf306035:	shr    rax,0x11
    71e6bf306039:	and    eax,0x800
    71e6bf30603e:	or     rdx,rax
    71e6bf306041:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf306046:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf30604e:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf306059:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf306061:	add    rsp,0x8
    71e6bf306065:	ret
    71e6bf306066:	data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf306070:	sub    rsp,0x8
    71e6bf306074:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf30607c:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf306084:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf30608c:	shr    r11d,1
    71e6bf30608f:	and    r11d,0x10
    71e6bf306093:	or     DWORD PTR [r12+0x314],r11d
    71e6bf30609b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf3060a7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf3060ad:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf3060b3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    71e6bf3060b9:	push   rdx
    71e6bf3060ba:	push   rsi
    71e6bf3060bb:	push   r10
    71e6bf3060bd:	push   r11
    71e6bf3060bf:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf3060c4:	mov    r10d,edx
    71e6bf3060c7:	and    r10d,0xc0
    71e6bf3060ce:	shl    r10d,0x18
    71e6bf3060d2:	mov    r11d,edx
    71e6bf3060d5:	and    r11d,0x1
    71e6bf3060d9:	shl    r11d,0x1d
    71e6bf3060dd:	or     r10d,r11d
    71e6bf3060e0:	mov    r11d,edx
    71e6bf3060e3:	and    r11d,0x800
    71e6bf3060ea:	shl    r11d,0x11
    71e6bf3060ee:	or     r10d,r11d
    71e6bf3060f1:	btc    r10,0x1d
    71e6bf3060f6:	mov    r11d,0xf0000000
    71e6bf3060fc:	and    r11,r10
    71e6bf3060ff:	movabs rsi,0xffffffff0fffffff
    71e6bf306109:	and    rbx,rsi
    71e6bf30610c:	or     rbx,r11
    71e6bf30610f:	pop    r11
    71e6bf306111:	pop    r10
    71e6bf306113:	pop    rsi
    71e6bf306114:	pop    rdx
    71e6bf306115:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf30611d:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf306123:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf306129:	lea    rdi,[rsp+0x110]
    71e6bf306131:	lea    rsi,[rsp+0xf0]
    71e6bf306139:	lea    rdx,[rsp+0x100]
    71e6bf306141:	mov    ecx,0x14
    71e6bf306146:	mov    r8d,0x0
    71e6bf30614c:	lea    r9,[r12+0x314]
    71e6bf306154:	movabs r11,0x5f73f3cfe1b0
    71e6bf30615e:	call   r11
    71e6bf306161:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf306167:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf30616d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf306173:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    71e6bf306179:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf306181:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf30618d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf306196:	pushf
    71e6bf306197:	pop    rdx
    71e6bf306198:	and    rdx,0xfffffffffffff73e
    71e6bf30619f:	mov    rax,rbx
    71e6bf3061a2:	shr    rax,0x18
    71e6bf3061a6:	and    eax,0xc0
    71e6bf3061ab:	or     rdx,rax
    71e6bf3061ae:	mov    rax,rbx
    71e6bf3061b1:	shr    rax,0x1d
    71e6bf3061b5:	and    eax,0x1
    71e6bf3061b8:	xor    eax,0x1
    71e6bf3061bb:	or     rdx,rax
    71e6bf3061be:	mov    rax,rbx
    71e6bf3061c1:	shr    rax,0x11
    71e6bf3061c5:	and    eax,0x800
    71e6bf3061ca:	or     rdx,rax
    71e6bf3061cd:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf3061d2:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf3061da:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf3061e5:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf3061ed:	add    rsp,0x8
    71e6bf3061f1:	ret
    71e6bf3061f2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf306200:	sub    rsp,0x8
    71e6bf306204:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf30620c:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf306214:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf30621c:	shr    r11d,1
    71e6bf30621f:	and    r11d,0x10
    71e6bf306223:	or     DWORD PTR [r12+0x314],r11d
    71e6bf30622b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf306237:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf30623d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf306243:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    71e6bf306249:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    71e6bf30624f:	push   rdx
    71e6bf306250:	push   rsi
    71e6bf306251:	push   r10
    71e6bf306253:	push   r11
    71e6bf306255:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf30625a:	mov    r10d,edx
    71e6bf30625d:	and    r10d,0xc0
    71e6bf306264:	shl    r10d,0x18
    71e6bf306268:	mov    r11d,edx
    71e6bf30626b:	and    r11d,0x1
    71e6bf30626f:	shl    r11d,0x1d
    71e6bf306273:	or     r10d,r11d
    71e6bf306276:	mov    r11d,edx
    71e6bf306279:	and    r11d,0x800
    71e6bf306280:	shl    r11d,0x11
    71e6bf306284:	or     r10d,r11d
    71e6bf306287:	btc    r10,0x1d
    71e6bf30628c:	mov    r11d,0xf0000000
    71e6bf306292:	and    r11,r10
    71e6bf306295:	movabs rsi,0xffffffff0fffffff
    71e6bf30629f:	and    rbx,rsi
    71e6bf3062a2:	or     rbx,r11
    71e6bf3062a5:	pop    r11
    71e6bf3062a7:	pop    r10
    71e6bf3062a9:	pop    rsi
    71e6bf3062aa:	pop    rdx
    71e6bf3062ab:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3062b3:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf3062b9:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf3062bf:	lea    rdi,[rsp+0x110]
    71e6bf3062c7:	lea    rsi,[rsp+0xf0]
    71e6bf3062cf:	lea    rdx,[rsp+0x100]
    71e6bf3062d7:	mov    ecx,0x14
    71e6bf3062dc:	mov    r8d,0x0
    71e6bf3062e2:	lea    r9,[r12+0x314]
    71e6bf3062ea:	movabs r11,0x5f73f3cfe1b0
    71e6bf3062f4:	call   r11
    71e6bf3062f7:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf3062fd:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf306303:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf306309:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    71e6bf30630f:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    71e6bf306315:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf30631d:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf306329:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf306332:	pushf
    71e6bf306333:	pop    rdx
    71e6bf306334:	and    rdx,0xfffffffffffff73e
    71e6bf30633b:	mov    rax,rbx
    71e6bf30633e:	shr    rax,0x18
    71e6bf306342:	and    eax,0xc0
    71e6bf306347:	or     rdx,rax
    71e6bf30634a:	mov    rax,rbx
    71e6bf30634d:	shr    rax,0x1d
    71e6bf306351:	and    eax,0x1
    71e6bf306354:	xor    eax,0x1
    71e6bf306357:	or     rdx,rax
    71e6bf30635a:	mov    rax,rbx
    71e6bf30635d:	shr    rax,0x11
    71e6bf306361:	and    eax,0x800
    71e6bf306366:	or     rdx,rax
    71e6bf306369:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf30636e:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf306376:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf306381:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf306389:	add    rsp,0x8
    71e6bf30638d:	ret
    71e6bf30638e:	xchg   ax,ax
    71e6bf306390:	sub    rsp,0x8
    71e6bf306394:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf30639c:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf3063a4:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf3063ac:	shr    r11d,1
    71e6bf3063af:	and    r11d,0x10
    71e6bf3063b3:	or     DWORD PTR [r12+0x314],r11d
    71e6bf3063bb:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf3063c7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf3063cd:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    71e6bf3063d3:	push   rdx
    71e6bf3063d4:	push   rsi
    71e6bf3063d5:	push   r10
    71e6bf3063d7:	push   r11
    71e6bf3063d9:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf3063de:	mov    r10d,edx
    71e6bf3063e1:	and    r10d,0xc0
    71e6bf3063e8:	shl    r10d,0x18
    71e6bf3063ec:	mov    r11d,edx
    71e6bf3063ef:	and    r11d,0x1
    71e6bf3063f3:	shl    r11d,0x1d
    71e6bf3063f7:	or     r10d,r11d
    71e6bf3063fa:	mov    r11d,edx
    71e6bf3063fd:	and    r11d,0x800
    71e6bf306404:	shl    r11d,0x11
    71e6bf306408:	or     r10d,r11d
    71e6bf30640b:	btc    r10,0x1d
    71e6bf306410:	mov    r11d,0xf0000000
    71e6bf306416:	and    r11,r10
    71e6bf306419:	movabs rsi,0xffffffff0fffffff
    71e6bf306423:	and    rbx,rsi
    71e6bf306426:	or     rbx,r11
    71e6bf306429:	pop    r11
    71e6bf30642b:	pop    r10
    71e6bf30642d:	pop    rsi
    71e6bf30642e:	pop    rdx
    71e6bf30642f:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf306437:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf30643d:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf306443:	lea    rdi,[rsp+0x110]
    71e6bf30644b:	lea    rsi,[rsp+0xf0]
    71e6bf306453:	lea    rdx,[rsp+0x100]
    71e6bf30645b:	mov    ecx,0x56
    71e6bf306460:	mov    r8d,0x0
    71e6bf306466:	lea    r9,[r12+0x314]
    71e6bf30646e:	movabs r11,0x5f73f3cfe1b0
    71e6bf306478:	call   r11
    71e6bf30647b:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf306481:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf306487:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    71e6bf30648d:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf306495:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf3064a1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf3064aa:	pushf
    71e6bf3064ab:	pop    rdx
    71e6bf3064ac:	and    rdx,0xfffffffffffff73e
    71e6bf3064b3:	mov    rax,rbx
    71e6bf3064b6:	shr    rax,0x18
    71e6bf3064ba:	and    eax,0xc0
    71e6bf3064bf:	or     rdx,rax
    71e6bf3064c2:	mov    rax,rbx
    71e6bf3064c5:	shr    rax,0x1d
    71e6bf3064c9:	and    eax,0x1
    71e6bf3064cc:	xor    eax,0x1
    71e6bf3064cf:	or     rdx,rax
    71e6bf3064d2:	mov    rax,rbx
    71e6bf3064d5:	shr    rax,0x11
    71e6bf3064d9:	and    eax,0x800
    71e6bf3064de:	or     rdx,rax
    71e6bf3064e1:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf3064e6:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf3064ee:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf3064f9:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf306501:	add    rsp,0x8
    71e6bf306505:	ret
    71e6bf306506:	data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf306510:	sub    rsp,0x8
    71e6bf306514:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf30651c:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf306524:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf30652c:	shr    r11d,1
    71e6bf30652f:	and    r11d,0x10
    71e6bf306533:	or     DWORD PTR [r12+0x314],r11d
    71e6bf30653b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf306547:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf30654d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf306553:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    71e6bf306559:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    71e6bf30655f:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    71e6bf306565:	push   rdx
    71e6bf306566:	push   rsi
    71e6bf306567:	push   r10
    71e6bf306569:	push   r11
    71e6bf30656b:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf306570:	mov    r10d,edx
    71e6bf306573:	and    r10d,0xc0
    71e6bf30657a:	shl    r10d,0x18
    71e6bf30657e:	mov    r11d,edx
    71e6bf306581:	and    r11d,0x1
    71e6bf306585:	shl    r11d,0x1d
    71e6bf306589:	or     r10d,r11d
    71e6bf30658c:	mov    r11d,edx
    71e6bf30658f:	and    r11d,0x800
    71e6bf306596:	shl    r11d,0x11
    71e6bf30659a:	or     r10d,r11d
    71e6bf30659d:	btc    r10,0x1d
    71e6bf3065a2:	mov    r11d,0xf0000000
    71e6bf3065a8:	and    r11,r10
    71e6bf3065ab:	movabs rsi,0xffffffff0fffffff
    71e6bf3065b5:	and    rbx,rsi
    71e6bf3065b8:	or     rbx,r11
    71e6bf3065bb:	pop    r11
    71e6bf3065bd:	pop    r10
    71e6bf3065bf:	pop    rsi
    71e6bf3065c0:	pop    rdx
    71e6bf3065c1:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3065c9:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf3065cf:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf3065d5:	lea    rdi,[rsp+0x110]
    71e6bf3065dd:	lea    rsi,[rsp+0xf0]
    71e6bf3065e5:	lea    rdx,[rsp+0x100]
    71e6bf3065ed:	mov    ecx,0x14
    71e6bf3065f2:	mov    r8d,0x0
    71e6bf3065f8:	lea    r9,[r12+0x314]
    71e6bf306600:	movabs r11,0x5f73f3cfe1b0
    71e6bf30660a:	call   r11
    71e6bf30660d:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf306613:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf306619:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf30661f:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    71e6bf306625:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    71e6bf30662b:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    71e6bf306631:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf306639:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf306645:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf30664e:	pushf
    71e6bf30664f:	pop    rdx
    71e6bf306650:	and    rdx,0xfffffffffffff73e
    71e6bf306657:	mov    rax,rbx
    71e6bf30665a:	shr    rax,0x18
    71e6bf30665e:	and    eax,0xc0
    71e6bf306663:	or     rdx,rax
    71e6bf306666:	mov    rax,rbx
    71e6bf306669:	shr    rax,0x1d
    71e6bf30666d:	and    eax,0x1
    71e6bf306670:	xor    eax,0x1
    71e6bf306673:	or     rdx,rax
    71e6bf306676:	mov    rax,rbx
    71e6bf306679:	shr    rax,0x11
    71e6bf30667d:	and    eax,0x800
    71e6bf306682:	or     rdx,rax
    71e6bf306685:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf30668a:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf306692:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf30669d:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf3066a5:	add    rsp,0x8
    71e6bf3066a9:	ret
    71e6bf3066aa:	nop    WORD PTR [rax+rax*1+0x0]
    71e6bf3066b0:	sub    rsp,0x8
    71e6bf3066b4:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf3066bc:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf3066c4:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf3066cc:	shr    r11d,1
    71e6bf3066cf:	and    r11d,0x10
    71e6bf3066d3:	or     DWORD PTR [r12+0x314],r11d
    71e6bf3066db:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf3066e7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf3066ed:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf3066f3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    71e6bf3066f9:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    71e6bf3066ff:	push   rdx
    71e6bf306700:	push   rsi
    71e6bf306701:	push   r10
    71e6bf306703:	push   r11
    71e6bf306705:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf30670a:	mov    r10d,edx
    71e6bf30670d:	and    r10d,0xc0
    71e6bf306714:	shl    r10d,0x18
    71e6bf306718:	mov    r11d,edx
    71e6bf30671b:	and    r11d,0x1
    71e6bf30671f:	shl    r11d,0x1d
    71e6bf306723:	or     r10d,r11d
    71e6bf306726:	mov    r11d,edx
    71e6bf306729:	and    r11d,0x800
    71e6bf306730:	shl    r11d,0x11
    71e6bf306734:	or     r10d,r11d
    71e6bf306737:	btc    r10,0x1d
    71e6bf30673c:	mov    r11d,0xf0000000
    71e6bf306742:	and    r11,r10
    71e6bf306745:	movabs rsi,0xffffffff0fffffff
    71e6bf30674f:	and    rbx,rsi
    71e6bf306752:	or     rbx,r11
    71e6bf306755:	pop    r11
    71e6bf306757:	pop    r10
    71e6bf306759:	pop    rsi
    71e6bf30675a:	pop    rdx
    71e6bf30675b:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf306763:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf306769:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf30676f:	lea    rdi,[rsp+0x110]
    71e6bf306777:	lea    rsi,[rsp+0xf0]
    71e6bf30677f:	lea    rdx,[rsp+0x100]
    71e6bf306787:	mov    ecx,0x56
    71e6bf30678c:	mov    r8d,0x0
    71e6bf306792:	lea    r9,[r12+0x314]
    71e6bf30679a:	movabs r11,0x5f73f3cfe1b0
    71e6bf3067a4:	call   r11
    71e6bf3067a7:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf3067ad:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf3067b3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf3067b9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    71e6bf3067bf:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    71e6bf3067c5:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf3067cd:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf3067d9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf3067e2:	pushf
    71e6bf3067e3:	pop    rdx
    71e6bf3067e4:	and    rdx,0xfffffffffffff73e
    71e6bf3067eb:	mov    rax,rbx
    71e6bf3067ee:	shr    rax,0x18
    71e6bf3067f2:	and    eax,0xc0
    71e6bf3067f7:	or     rdx,rax
    71e6bf3067fa:	mov    rax,rbx
    71e6bf3067fd:	shr    rax,0x1d
    71e6bf306801:	and    eax,0x1
    71e6bf306804:	xor    eax,0x1
    71e6bf306807:	or     rdx,rax
    71e6bf30680a:	mov    rax,rbx
    71e6bf30680d:	shr    rax,0x11
    71e6bf306811:	and    eax,0x800
    71e6bf306816:	or     rdx,rax
    71e6bf306819:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf30681e:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf306826:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf306831:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf306839:	add    rsp,0x8
    71e6bf30683d:	ret
    71e6bf30683e:	xchg   ax,ax
    71e6bf306840:	sub    rsp,0x8
    71e6bf306844:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf30684c:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf306854:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf30685c:	shr    r11d,1
    71e6bf30685f:	and    r11d,0x10
    71e6bf306863:	or     DWORD PTR [r12+0x314],r11d
    71e6bf30686b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf306877:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf30687d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf306883:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    71e6bf306889:	push   rdx
    71e6bf30688a:	push   rsi
    71e6bf30688b:	push   r10
    71e6bf30688d:	push   r11
    71e6bf30688f:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf306894:	mov    r10d,edx
    71e6bf306897:	and    r10d,0xc0
    71e6bf30689e:	shl    r10d,0x18
    71e6bf3068a2:	mov    r11d,edx
    71e6bf3068a5:	and    r11d,0x1
    71e6bf3068a9:	shl    r11d,0x1d
    71e6bf3068ad:	or     r10d,r11d
    71e6bf3068b0:	mov    r11d,edx
    71e6bf3068b3:	and    r11d,0x800
    71e6bf3068ba:	shl    r11d,0x11
    71e6bf3068be:	or     r10d,r11d
    71e6bf3068c1:	btc    r10,0x1d
    71e6bf3068c6:	mov    r11d,0xf0000000
    71e6bf3068cc:	and    r11,r10
    71e6bf3068cf:	movabs rsi,0xffffffff0fffffff
    71e6bf3068d9:	and    rbx,rsi
    71e6bf3068dc:	or     rbx,r11
    71e6bf3068df:	pop    r11
    71e6bf3068e1:	pop    r10
    71e6bf3068e3:	pop    rsi
    71e6bf3068e4:	pop    rdx
    71e6bf3068e5:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3068ed:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf3068f3:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf3068f9:	lea    rdi,[rsp+0x110]
    71e6bf306901:	lea    rsi,[rsp+0xf0]
    71e6bf306909:	lea    rdx,[rsp+0x100]
    71e6bf306911:	mov    ecx,0x56
    71e6bf306916:	mov    r8d,0x0
    71e6bf30691c:	lea    r9,[r12+0x314]
    71e6bf306924:	movabs r11,0x5f73f3cfe1b0
    71e6bf30692e:	call   r11
    71e6bf306931:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf306937:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf30693d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf306943:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    71e6bf306949:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf306951:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf30695d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf306966:	pushf
    71e6bf306967:	pop    rdx
    71e6bf306968:	and    rdx,0xfffffffffffff73e
    71e6bf30696f:	mov    rax,rbx
    71e6bf306972:	shr    rax,0x18
    71e6bf306976:	and    eax,0xc0
    71e6bf30697b:	or     rdx,rax
    71e6bf30697e:	mov    rax,rbx
    71e6bf306981:	shr    rax,0x1d
    71e6bf306985:	and    eax,0x1
    71e6bf306988:	xor    eax,0x1
    71e6bf30698b:	or     rdx,rax
    71e6bf30698e:	mov    rax,rbx
    71e6bf306991:	shr    rax,0x11
    71e6bf306995:	and    eax,0x800
    71e6bf30699a:	or     rdx,rax
    71e6bf30699d:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf3069a2:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf3069aa:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf3069b5:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf3069bd:	add    rsp,0x8
    71e6bf3069c1:	ret
    71e6bf3069c2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf3069d0:	sub    rsp,0x8
    71e6bf3069d4:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf3069dc:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf3069e4:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf3069ec:	shr    r11d,1
    71e6bf3069ef:	and    r11d,0x10
    71e6bf3069f3:	or     DWORD PTR [r12+0x314],r11d
    71e6bf3069fb:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf306a07:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf306a0d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf306a13:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    71e6bf306a19:	push   rdx
    71e6bf306a1a:	push   rsi
    71e6bf306a1b:	push   r10
    71e6bf306a1d:	push   r11
    71e6bf306a1f:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf306a24:	mov    r10d,edx
    71e6bf306a27:	and    r10d,0xc0
    71e6bf306a2e:	shl    r10d,0x18
    71e6bf306a32:	mov    r11d,edx
    71e6bf306a35:	and    r11d,0x1
    71e6bf306a39:	shl    r11d,0x1d
    71e6bf306a3d:	or     r10d,r11d
    71e6bf306a40:	mov    r11d,edx
    71e6bf306a43:	and    r11d,0x800
    71e6bf306a4a:	shl    r11d,0x11
    71e6bf306a4e:	or     r10d,r11d
    71e6bf306a51:	btc    r10,0x1d
    71e6bf306a56:	mov    r11d,0xf0000000
    71e6bf306a5c:	and    r11,r10
    71e6bf306a5f:	movabs rsi,0xffffffff0fffffff
    71e6bf306a69:	and    rbx,rsi
    71e6bf306a6c:	or     rbx,r11
    71e6bf306a6f:	pop    r11
    71e6bf306a71:	pop    r10
    71e6bf306a73:	pop    rsi
    71e6bf306a74:	pop    rdx
    71e6bf306a75:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf306a7d:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf306a83:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf306a89:	lea    rdi,[rsp+0x110]
    71e6bf306a91:	lea    rsi,[rsp+0xf0]
    71e6bf306a99:	lea    rdx,[rsp+0x100]
    71e6bf306aa1:	mov    ecx,0x14
    71e6bf306aa6:	mov    r8d,0x0
    71e6bf306aac:	lea    r9,[r12+0x314]
    71e6bf306ab4:	movabs r11,0x5f73f3cfe1b0
    71e6bf306abe:	call   r11
    71e6bf306ac1:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf306ac7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf306acd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf306ad3:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    71e6bf306ad9:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf306ae1:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf306aed:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf306af6:	pushf
    71e6bf306af7:	pop    rdx
    71e6bf306af8:	and    rdx,0xfffffffffffff73e
    71e6bf306aff:	mov    rax,rbx
    71e6bf306b02:	shr    rax,0x18
    71e6bf306b06:	and    eax,0xc0
    71e6bf306b0b:	or     rdx,rax
    71e6bf306b0e:	mov    rax,rbx
    71e6bf306b11:	shr    rax,0x1d
    71e6bf306b15:	and    eax,0x1
    71e6bf306b18:	xor    eax,0x1
    71e6bf306b1b:	or     rdx,rax
    71e6bf306b1e:	mov    rax,rbx
    71e6bf306b21:	shr    rax,0x11
    71e6bf306b25:	and    eax,0x800
    71e6bf306b2a:	or     rdx,rax
    71e6bf306b2d:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf306b32:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf306b3a:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf306b45:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf306b4d:	add    rsp,0x8
    71e6bf306b51:	ret
    71e6bf306b52:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf306b60:	sub    rsp,0x8
    71e6bf306b64:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf306b6c:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf306b74:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf306b7c:	shr    r11d,1
    71e6bf306b7f:	and    r11d,0x10
    71e6bf306b83:	or     DWORD PTR [r12+0x314],r11d
    71e6bf306b8b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf306b97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf306b9d:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    71e6bf306ba3:	push   rdx
    71e6bf306ba4:	push   rsi
    71e6bf306ba5:	push   r10
    71e6bf306ba7:	push   r11
    71e6bf306ba9:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf306bae:	mov    r10d,edx
    71e6bf306bb1:	and    r10d,0xc0
    71e6bf306bb8:	shl    r10d,0x18
    71e6bf306bbc:	mov    r11d,edx
    71e6bf306bbf:	and    r11d,0x1
    71e6bf306bc3:	shl    r11d,0x1d
    71e6bf306bc7:	or     r10d,r11d
    71e6bf306bca:	mov    r11d,edx
    71e6bf306bcd:	and    r11d,0x800
    71e6bf306bd4:	shl    r11d,0x11
    71e6bf306bd8:	or     r10d,r11d
    71e6bf306bdb:	btc    r10,0x1d
    71e6bf306be0:	mov    r11d,0xf0000000
    71e6bf306be6:	and    r11,r10
    71e6bf306be9:	movabs rsi,0xffffffff0fffffff
    71e6bf306bf3:	and    rbx,rsi
    71e6bf306bf6:	or     rbx,r11
    71e6bf306bf9:	pop    r11
    71e6bf306bfb:	pop    r10
    71e6bf306bfd:	pop    rsi
    71e6bf306bfe:	pop    rdx
    71e6bf306bff:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf306c07:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf306c0d:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf306c13:	lea    rdi,[rsp+0x110]
    71e6bf306c1b:	lea    rsi,[rsp+0xf0]
    71e6bf306c23:	lea    rdx,[rsp+0x100]
    71e6bf306c2b:	mov    ecx,0x14
    71e6bf306c30:	mov    r8d,0x0
    71e6bf306c36:	lea    r9,[r12+0x314]
    71e6bf306c3e:	movabs r11,0x5f73f3cfe1b0
    71e6bf306c48:	call   r11
    71e6bf306c4b:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf306c51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf306c57:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    71e6bf306c5d:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf306c65:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf306c71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf306c7a:	pushf
    71e6bf306c7b:	pop    rdx
    71e6bf306c7c:	and    rdx,0xfffffffffffff73e
    71e6bf306c83:	mov    rax,rbx
    71e6bf306c86:	shr    rax,0x18
    71e6bf306c8a:	and    eax,0xc0
    71e6bf306c8f:	or     rdx,rax
    71e6bf306c92:	mov    rax,rbx
    71e6bf306c95:	shr    rax,0x1d
    71e6bf306c99:	and    eax,0x1
    71e6bf306c9c:	xor    eax,0x1
    71e6bf306c9f:	or     rdx,rax
    71e6bf306ca2:	mov    rax,rbx
    71e6bf306ca5:	shr    rax,0x11
    71e6bf306ca9:	and    eax,0x800
    71e6bf306cae:	or     rdx,rax
    71e6bf306cb1:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf306cb6:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf306cbe:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf306cc9:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf306cd1:	add    rsp,0x8
    71e6bf306cd5:	ret
    71e6bf306cd6:	data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf306ce0:	sub    rsp,0x8
    71e6bf306ce4:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf306cec:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf306cf4:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf306cfc:	shr    r11d,1
    71e6bf306cff:	and    r11d,0x10
    71e6bf306d03:	or     DWORD PTR [r12+0x314],r11d
    71e6bf306d0b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf306d17:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf306d1d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71e6bf306d23:	push   rdx
    71e6bf306d24:	push   rsi
    71e6bf306d25:	push   r10
    71e6bf306d27:	push   r11
    71e6bf306d29:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf306d2e:	mov    r10d,edx
    71e6bf306d31:	and    r10d,0xc0
    71e6bf306d38:	shl    r10d,0x18
    71e6bf306d3c:	mov    r11d,edx
    71e6bf306d3f:	and    r11d,0x1
    71e6bf306d43:	shl    r11d,0x1d
    71e6bf306d47:	or     r10d,r11d
    71e6bf306d4a:	mov    r11d,edx
    71e6bf306d4d:	and    r11d,0x800
    71e6bf306d54:	shl    r11d,0x11
    71e6bf306d58:	or     r10d,r11d
    71e6bf306d5b:	btc    r10,0x1d
    71e6bf306d60:	mov    r11d,0xf0000000
    71e6bf306d66:	and    r11,r10
    71e6bf306d69:	movabs rsi,0xffffffff0fffffff
    71e6bf306d73:	and    rbx,rsi
    71e6bf306d76:	or     rbx,r11
    71e6bf306d79:	pop    r11
    71e6bf306d7b:	pop    r10
    71e6bf306d7d:	pop    rsi
    71e6bf306d7e:	pop    rdx
    71e6bf306d7f:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf306d87:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf306d8d:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf306d93:	lea    rdi,[rsp+0x110]
    71e6bf306d9b:	lea    rsi,[rsp+0xf0]
    71e6bf306da3:	lea    rdx,[rsp+0x100]
    71e6bf306dab:	mov    ecx,0xc
    71e6bf306db0:	mov    r8d,0x0
    71e6bf306db6:	lea    r9,[r12+0x314]
    71e6bf306dbe:	movabs r11,0x5f73f3cfe1b0
    71e6bf306dc8:	call   r11
    71e6bf306dcb:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf306dd1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf306dd7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71e6bf306ddd:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf306de5:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf306df1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf306dfa:	pushf
    71e6bf306dfb:	pop    rdx
    71e6bf306dfc:	and    rdx,0xfffffffffffff73e
    71e6bf306e03:	mov    rax,rbx
    71e6bf306e06:	shr    rax,0x18
    71e6bf306e0a:	and    eax,0xc0
    71e6bf306e0f:	or     rdx,rax
    71e6bf306e12:	mov    rax,rbx
    71e6bf306e15:	shr    rax,0x1d
    71e6bf306e19:	and    eax,0x1
    71e6bf306e1c:	xor    eax,0x1
    71e6bf306e1f:	or     rdx,rax
    71e6bf306e22:	mov    rax,rbx
    71e6bf306e25:	shr    rax,0x11
    71e6bf306e29:	and    eax,0x800
    71e6bf306e2e:	or     rdx,rax
    71e6bf306e31:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf306e36:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf306e3e:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf306e49:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf306e51:	add    rsp,0x8
    71e6bf306e55:	ret
    71e6bf306e56:	data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf306e60:	sub    rsp,0x8
    71e6bf306e64:	stmxcsr DWORD PTR [rsp+0x124]
    71e6bf306e6c:	ldmxcsr DWORD PTR [rsp+0x120]
    71e6bf306e74:	mov    r11d,DWORD PTR [rsp+0x124]
    71e6bf306e7c:	shr    r11d,1
    71e6bf306e7f:	and    r11d,0x10
    71e6bf306e83:	or     DWORD PTR [r12+0x314],r11d
    71e6bf306e8b:	mov    QWORD PTR [r12+0x378],0x3
    71e6bf306e97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71e6bf306e9d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    71e6bf306ea3:	push   rdx
    71e6bf306ea4:	push   rsi
    71e6bf306ea5:	push   r10
    71e6bf306ea7:	push   r11
    71e6bf306ea9:	mov    rdx,QWORD PTR [rsp+0x30]
    71e6bf306eae:	mov    r10d,edx
    71e6bf306eb1:	and    r10d,0xc0
    71e6bf306eb8:	shl    r10d,0x18
    71e6bf306ebc:	mov    r11d,edx
    71e6bf306ebf:	and    r11d,0x1
    71e6bf306ec3:	shl    r11d,0x1d
    71e6bf306ec7:	or     r10d,r11d
    71e6bf306eca:	mov    r11d,edx
    71e6bf306ecd:	and    r11d,0x800
    71e6bf306ed4:	shl    r11d,0x11
    71e6bf306ed8:	or     r10d,r11d
    71e6bf306edb:	btc    r10,0x1d
    71e6bf306ee0:	mov    r11d,0xf0000000
    71e6bf306ee6:	and    r11,r10
    71e6bf306ee9:	movabs rsi,0xffffffff0fffffff
    71e6bf306ef3:	and    rbx,rsi
    71e6bf306ef6:	or     rbx,r11
    71e6bf306ef9:	pop    r11
    71e6bf306efb:	pop    r10
    71e6bf306efd:	pop    rsi
    71e6bf306efe:	pop    rdx
    71e6bf306eff:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf306f07:	stmxcsr DWORD PTR [r12-0x28]
    71e6bf306f0d:	ldmxcsr DWORD PTR [r12-0x38]
    71e6bf306f13:	lea    rdi,[rsp+0x110]
    71e6bf306f1b:	lea    rsi,[rsp+0xf0]
    71e6bf306f23:	lea    rdx,[rsp+0x100]
    71e6bf306f2b:	mov    ecx,0xc
    71e6bf306f30:	mov    r8d,0x0
    71e6bf306f36:	lea    r9,[r12+0x314]
    71e6bf306f3e:	movabs r11,0x5f73f3cfe1b0
    71e6bf306f48:	call   r11
    71e6bf306f4b:	ldmxcsr DWORD PTR [r12-0x28]
    71e6bf306f51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71e6bf306f57:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    71e6bf306f5d:	mov    rbx,QWORD PTR [r12+0x108]
    71e6bf306f65:	mov    QWORD PTR [r12+0x378],0x2
    71e6bf306f71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71e6bf306f7a:	pushf
    71e6bf306f7b:	pop    rdx
    71e6bf306f7c:	and    rdx,0xfffffffffffff73e
    71e6bf306f83:	mov    rax,rbx
    71e6bf306f86:	shr    rax,0x18
    71e6bf306f8a:	and    eax,0xc0
    71e6bf306f8f:	or     rdx,rax
    71e6bf306f92:	mov    rax,rbx
    71e6bf306f95:	shr    rax,0x1d
    71e6bf306f99:	and    eax,0x1
    71e6bf306f9c:	xor    eax,0x1
    71e6bf306f9f:	or     rdx,rax
    71e6bf306fa2:	mov    rax,rbx
    71e6bf306fa5:	shr    rax,0x11
    71e6bf306fa9:	and    eax,0x800
    71e6bf306fae:	or     rdx,rax
    71e6bf306fb1:	mov    QWORD PTR [rsp+0x10],rdx
    71e6bf306fb6:	stmxcsr DWORD PTR [rsp+0x120]
    71e6bf306fbe:	mov    DWORD PTR [rsp+0x124],0x1f80
    71e6bf306fc9:	ldmxcsr DWORD PTR [rsp+0x124]
    71e6bf306fd1:	add    rsp,0x8
    71e6bf306fd5:	ret
    71e6bf306fd6:	mov    eax,0x4101e8
    71e6bf306fdb:	mov    QWORD PTR [r12+0x100],rax
    71e6bf306fe3:	push   rdx
    71e6bf306fe4:	push   rsi
    71e6bf306fe5:	push   r10
    71e6bf306fe7:	push   r11
    71e6bf306fe9:	pushf
    71e6bf306fea:	pop    r11
    71e6bf306fec:	mov    QWORD PTR [rsp+0x20],r11
    71e6bf306ff1:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf306ff6:	mov    r10d,edx
    71e6bf306ff9:	and    r10d,0xc0
    71e6bf307000:	shl    r10d,0x18
    71e6bf307004:	mov    r11d,edx
    71e6bf307007:	and    r11d,0x1
    71e6bf30700b:	shl    r11d,0x1d
    71e6bf30700f:	or     r10d,r11d
    71e6bf307012:	mov    r11d,edx
    71e6bf307015:	and    r11d,0x800
    71e6bf30701c:	shl    r11d,0x11
    71e6bf307020:	or     r10d,r11d
    71e6bf307023:	btc    r10,0x1d
    71e6bf307028:	mov    r11d,0xf0000000
    71e6bf30702e:	and    r11,r10
    71e6bf307031:	movabs rsi,0xffffffff0fffffff
    71e6bf30703b:	and    rbx,rsi
    71e6bf30703e:	or     rbx,r11
    71e6bf307041:	pop    r11
    71e6bf307043:	pop    r10
    71e6bf307045:	pop    rsi
    71e6bf307046:	pop    rdx
    71e6bf307047:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf30704f:	add    rsp,0x150
    71e6bf307056:	mov    eax,0xc
    71e6bf30705b:	movabs r11,0x5f73f3e93390
    71e6bf307065:	jmp    r11
    71e6bf307068:	mov    eax,0x410440
    71e6bf30706d:	mov    QWORD PTR [r12+0x100],rax
    71e6bf307075:	push   rdx
    71e6bf307076:	push   rsi
    71e6bf307077:	push   r10
    71e6bf307079:	push   r11
    71e6bf30707b:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf307080:	mov    r10d,edx
    71e6bf307083:	and    r10d,0xc0
    71e6bf30708a:	shl    r10d,0x18
    71e6bf30708e:	mov    r11d,edx
    71e6bf307091:	and    r11d,0x1
    71e6bf307095:	shl    r11d,0x1d
    71e6bf307099:	or     r10d,r11d
    71e6bf30709c:	mov    r11d,edx
    71e6bf30709f:	and    r11d,0x800
    71e6bf3070a6:	shl    r11d,0x11
    71e6bf3070aa:	or     r10d,r11d
    71e6bf3070ad:	btc    r10,0x1d
    71e6bf3070b2:	mov    r11d,0xf0000000
    71e6bf3070b8:	and    r11,r10
    71e6bf3070bb:	movabs rsi,0xffffffff0fffffff
    71e6bf3070c5:	and    rbx,rsi
    71e6bf3070c8:	or     rbx,r11
    71e6bf3070cb:	pop    r11
    71e6bf3070cd:	pop    r10
    71e6bf3070cf:	pop    rsi
    71e6bf3070d0:	pop    rdx
    71e6bf3070d1:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3070d9:	add    rsp,0x150
    71e6bf3070e0:	mov    eax,0xc
    71e6bf3070e5:	movabs r11,0x5f73f3e93390
    71e6bf3070ef:	jmp    r11
    71e6bf3070f2:	mov    eax,0x41044c
    71e6bf3070f7:	mov    QWORD PTR [r12+0x100],rax
    71e6bf3070ff:	push   rdx
    71e6bf307100:	push   rsi
    71e6bf307101:	push   r10
    71e6bf307103:	push   r11
    71e6bf307105:	pushf
    71e6bf307106:	pop    r11
    71e6bf307108:	mov    QWORD PTR [rsp+0x20],r11
    71e6bf30710d:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf307112:	mov    r10d,edx
    71e6bf307115:	and    r10d,0xc0
    71e6bf30711c:	shl    r10d,0x18
    71e6bf307120:	mov    r11d,edx
    71e6bf307123:	and    r11d,0x1
    71e6bf307127:	shl    r11d,0x1d
    71e6bf30712b:	or     r10d,r11d
    71e6bf30712e:	mov    r11d,edx
    71e6bf307131:	and    r11d,0x800
    71e6bf307138:	shl    r11d,0x11
    71e6bf30713c:	or     r10d,r11d
    71e6bf30713f:	btc    r10,0x1d
    71e6bf307144:	mov    r11d,0xf0000000
    71e6bf30714a:	and    r11,r10
    71e6bf30714d:	movabs rsi,0xffffffff0fffffff
    71e6bf307157:	and    rbx,rsi
    71e6bf30715a:	or     rbx,r11
    71e6bf30715d:	pop    r11
    71e6bf30715f:	pop    r10
    71e6bf307161:	pop    rsi
    71e6bf307162:	pop    rdx
    71e6bf307163:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf30716b:	add    rsp,0x150
    71e6bf307172:	mov    eax,0xc
    71e6bf307177:	movabs r11,0x5f73f3e93390
    71e6bf307181:	jmp    r11
    71e6bf307184:	mov    eax,0x41048c
    71e6bf307189:	mov    QWORD PTR [r12+0x100],rax
    71e6bf307191:	push   rdx
    71e6bf307192:	push   rsi
    71e6bf307193:	push   r10
    71e6bf307195:	push   r11
    71e6bf307197:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf30719c:	mov    r10d,edx
    71e6bf30719f:	and    r10d,0xc0
    71e6bf3071a6:	shl    r10d,0x18
    71e6bf3071aa:	mov    r11d,edx
    71e6bf3071ad:	and    r11d,0x1
    71e6bf3071b1:	shl    r11d,0x1d
    71e6bf3071b5:	or     r10d,r11d
    71e6bf3071b8:	mov    r11d,edx
    71e6bf3071bb:	and    r11d,0x800
    71e6bf3071c2:	shl    r11d,0x11
    71e6bf3071c6:	or     r10d,r11d
    71e6bf3071c9:	btc    r10,0x1d
    71e6bf3071ce:	mov    r11d,0xf0000000
    71e6bf3071d4:	and    r11,r10
    71e6bf3071d7:	movabs rsi,0xffffffff0fffffff
    71e6bf3071e1:	and    rbx,rsi
    71e6bf3071e4:	or     rbx,r11
    71e6bf3071e7:	pop    r11
    71e6bf3071e9:	pop    r10
    71e6bf3071eb:	pop    rsi
    71e6bf3071ec:	pop    rdx
    71e6bf3071ed:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3071f5:	add    rsp,0x150
    71e6bf3071fc:	mov    eax,0xc
    71e6bf307201:	movabs r11,0x5f73f3e93390
    71e6bf30720b:	jmp    r11
    71e6bf30720e:	mov    eax,0x410494
    71e6bf307213:	mov    QWORD PTR [r12+0x100],rax
    71e6bf30721b:	push   rdx
    71e6bf30721c:	push   rsi
    71e6bf30721d:	push   r10
    71e6bf30721f:	push   r11
    71e6bf307221:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf307226:	mov    r10d,edx
    71e6bf307229:	and    r10d,0xc0
    71e6bf307230:	shl    r10d,0x18
    71e6bf307234:	mov    r11d,edx
    71e6bf307237:	and    r11d,0x1
    71e6bf30723b:	shl    r11d,0x1d
    71e6bf30723f:	or     r10d,r11d
    71e6bf307242:	mov    r11d,edx
    71e6bf307245:	and    r11d,0x800
    71e6bf30724c:	shl    r11d,0x11
    71e6bf307250:	or     r10d,r11d
    71e6bf307253:	btc    r10,0x1d
    71e6bf307258:	mov    r11d,0xf0000000
    71e6bf30725e:	and    r11,r10
    71e6bf307261:	movabs rsi,0xffffffff0fffffff
    71e6bf30726b:	and    rbx,rsi
    71e6bf30726e:	or     rbx,r11
    71e6bf307271:	pop    r11
    71e6bf307273:	pop    r10
    71e6bf307275:	pop    rsi
    71e6bf307276:	pop    rdx
    71e6bf307277:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf30727f:	add    rsp,0x150
    71e6bf307286:	mov    eax,0xc
    71e6bf30728b:	movabs r11,0x5f73f3e93390
    71e6bf307295:	jmp    r11
    71e6bf307298:	nop    DWORD PTR [rax+rax*1+0x0]
    71e6bf3072a0:	sub    rsp,0x150
    71e6bf3072a7:	mov    r11,QWORD PTR [r12+0x398]
    71e6bf3072af:	mov    QWORD PTR [rsp],r11
    71e6bf3072b3:	cmp    DWORD PTR [r12+0x310],0x0
    71e6bf3072bc:	je     0x71e6bf30734c
    71e6bf3072c2:	push   rdx
    71e6bf3072c3:	push   rsi
    71e6bf3072c4:	push   r10
    71e6bf3072c6:	push   r11
    71e6bf3072c8:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf3072cd:	mov    r10d,edx
    71e6bf3072d0:	and    r10d,0xc0
    71e6bf3072d7:	shl    r10d,0x18
    71e6bf3072db:	mov    r11d,edx
    71e6bf3072de:	and    r11d,0x1
    71e6bf3072e2:	shl    r11d,0x1d
    71e6bf3072e6:	or     r10d,r11d
    71e6bf3072e9:	mov    r11d,edx
    71e6bf3072ec:	and    r11d,0x800
    71e6bf3072f3:	shl    r11d,0x11
    71e6bf3072f7:	or     r10d,r11d
    71e6bf3072fa:	btc    r10,0x1d
    71e6bf3072ff:	mov    r11d,0xf0000000
    71e6bf307305:	and    r11,r10
    71e6bf307308:	movabs rsi,0xffffffff0fffffff
    71e6bf307312:	and    rbx,rsi
    71e6bf307315:	or     rbx,r11
    71e6bf307318:	pop    r11
    71e6bf30731a:	pop    r10
    71e6bf30731c:	pop    rsi
    71e6bf30731d:	pop    rdx
    71e6bf30731e:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf307326:	mov    eax,0x4101ac
    71e6bf30732b:	mov    QWORD PTR [r12+0x100],rax
    71e6bf307333:	add    rsp,0x150
    71e6bf30733a:	mov    eax,0x3
    71e6bf30733f:	movabs r11,0x5f73f3e93390
    71e6bf307349:	jmp    r11
    71e6bf30734c:	jmp    0x71e6bf3001fd
    71e6bf307351:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf307360:	sub    rsp,0x150
    71e6bf307367:	mov    r11,QWORD PTR [r12+0x398]
    71e6bf30736f:	mov    QWORD PTR [rsp],r11
    71e6bf307373:	cmp    DWORD PTR [r12+0x310],0x0
    71e6bf30737c:	je     0x71e6bf30740c
    71e6bf307382:	push   rdx
    71e6bf307383:	push   rsi
    71e6bf307384:	push   r10
    71e6bf307386:	push   r11
    71e6bf307388:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf30738d:	mov    r10d,edx
    71e6bf307390:	and    r10d,0xc0
    71e6bf307397:	shl    r10d,0x18
    71e6bf30739b:	mov    r11d,edx
    71e6bf30739e:	and    r11d,0x1
    71e6bf3073a2:	shl    r11d,0x1d
    71e6bf3073a6:	or     r10d,r11d
    71e6bf3073a9:	mov    r11d,edx
    71e6bf3073ac:	and    r11d,0x800
    71e6bf3073b3:	shl    r11d,0x11
    71e6bf3073b7:	or     r10d,r11d
    71e6bf3073ba:	btc    r10,0x1d
    71e6bf3073bf:	mov    r11d,0xf0000000
    71e6bf3073c5:	and    r11,r10
    71e6bf3073c8:	movabs rsi,0xffffffff0fffffff
    71e6bf3073d2:	and    rbx,rsi
    71e6bf3073d5:	or     rbx,r11
    71e6bf3073d8:	pop    r11
    71e6bf3073da:	pop    r10
    71e6bf3073dc:	pop    rsi
    71e6bf3073dd:	pop    rdx
    71e6bf3073de:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3073e6:	mov    eax,0x4101ec
    71e6bf3073eb:	mov    QWORD PTR [r12+0x100],rax
    71e6bf3073f3:	add    rsp,0x150
    71e6bf3073fa:	mov    eax,0x3
    71e6bf3073ff:	movabs r11,0x5f73f3e93390
    71e6bf307409:	jmp    r11
    71e6bf30740c:	jmp    0x71e6bf300773
    71e6bf307411:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf307420:	sub    rsp,0x150
    71e6bf307427:	mov    r11,QWORD PTR [r12+0x398]
    71e6bf30742f:	mov    QWORD PTR [rsp],r11
    71e6bf307433:	cmp    DWORD PTR [r12+0x310],0x0
    71e6bf30743c:	je     0x71e6bf3074cc
    71e6bf307442:	push   rdx
    71e6bf307443:	push   rsi
    71e6bf307444:	push   r10
    71e6bf307446:	push   r11
    71e6bf307448:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf30744d:	mov    r10d,edx
    71e6bf307450:	and    r10d,0xc0
    71e6bf307457:	shl    r10d,0x18
    71e6bf30745b:	mov    r11d,edx
    71e6bf30745e:	and    r11d,0x1
    71e6bf307462:	shl    r11d,0x1d
    71e6bf307466:	or     r10d,r11d
    71e6bf307469:	mov    r11d,edx
    71e6bf30746c:	and    r11d,0x800
    71e6bf307473:	shl    r11d,0x11
    71e6bf307477:	or     r10d,r11d
    71e6bf30747a:	btc    r10,0x1d
    71e6bf30747f:	mov    r11d,0xf0000000
    71e6bf307485:	and    r11,r10
    71e6bf307488:	movabs rsi,0xffffffff0fffffff
    71e6bf307492:	and    rbx,rsi
    71e6bf307495:	or     rbx,r11
    71e6bf307498:	pop    r11
    71e6bf30749a:	pop    r10
    71e6bf30749c:	pop    rsi
    71e6bf30749d:	pop    rdx
    71e6bf30749e:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3074a6:	mov    eax,0x410274
    71e6bf3074ab:	mov    QWORD PTR [r12+0x100],rax
    71e6bf3074b3:	add    rsp,0x150
    71e6bf3074ba:	mov    eax,0x3
    71e6bf3074bf:	movabs r11,0x5f73f3e93390
    71e6bf3074c9:	jmp    r11
    71e6bf3074cc:	jmp    0x71e6bf300ec8
    71e6bf3074d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf3074e0:	sub    rsp,0x150
    71e6bf3074e7:	mov    r11,QWORD PTR [r12+0x398]
    71e6bf3074ef:	mov    QWORD PTR [rsp],r11
    71e6bf3074f3:	cmp    DWORD PTR [r12+0x310],0x0
    71e6bf3074fc:	je     0x71e6bf30758c
    71e6bf307502:	push   rdx
    71e6bf307503:	push   rsi
    71e6bf307504:	push   r10
    71e6bf307506:	push   r11
    71e6bf307508:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf30750d:	mov    r10d,edx
    71e6bf307510:	and    r10d,0xc0
    71e6bf307517:	shl    r10d,0x18
    71e6bf30751b:	mov    r11d,edx
    71e6bf30751e:	and    r11d,0x1
    71e6bf307522:	shl    r11d,0x1d
    71e6bf307526:	or     r10d,r11d
    71e6bf307529:	mov    r11d,edx
    71e6bf30752c:	and    r11d,0x800
    71e6bf307533:	shl    r11d,0x11
    71e6bf307537:	or     r10d,r11d
    71e6bf30753a:	btc    r10,0x1d
    71e6bf30753f:	mov    r11d,0xf0000000
    71e6bf307545:	and    r11,r10
    71e6bf307548:	movabs rsi,0xffffffff0fffffff
    71e6bf307552:	and    rbx,rsi
    71e6bf307555:	or     rbx,r11
    71e6bf307558:	pop    r11
    71e6bf30755a:	pop    r10
    71e6bf30755c:	pop    rsi
    71e6bf30755d:	pop    rdx
    71e6bf30755e:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf307566:	mov    eax,0x410278
    71e6bf30756b:	mov    QWORD PTR [r12+0x100],rax
    71e6bf307573:	add    rsp,0x150
    71e6bf30757a:	mov    eax,0x3
    71e6bf30757f:	movabs r11,0x5f73f3e93390
    71e6bf307589:	jmp    r11
    71e6bf30758c:	jmp    0x71e6bf300ed8
    71e6bf307591:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf3075a0:	sub    rsp,0x150
    71e6bf3075a7:	mov    r11,QWORD PTR [r12+0x398]
    71e6bf3075af:	mov    QWORD PTR [rsp],r11
    71e6bf3075b3:	cmp    DWORD PTR [r12+0x310],0x0
    71e6bf3075bc:	je     0x71e6bf30764c
    71e6bf3075c2:	push   rdx
    71e6bf3075c3:	push   rsi
    71e6bf3075c4:	push   r10
    71e6bf3075c6:	push   r11
    71e6bf3075c8:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf3075cd:	mov    r10d,edx
    71e6bf3075d0:	and    r10d,0xc0
    71e6bf3075d7:	shl    r10d,0x18
    71e6bf3075db:	mov    r11d,edx
    71e6bf3075de:	and    r11d,0x1
    71e6bf3075e2:	shl    r11d,0x1d
    71e6bf3075e6:	or     r10d,r11d
    71e6bf3075e9:	mov    r11d,edx
    71e6bf3075ec:	and    r11d,0x800
    71e6bf3075f3:	shl    r11d,0x11
    71e6bf3075f7:	or     r10d,r11d
    71e6bf3075fa:	btc    r10,0x1d
    71e6bf3075ff:	mov    r11d,0xf0000000
    71e6bf307605:	and    r11,r10
    71e6bf307608:	movabs rsi,0xffffffff0fffffff
    71e6bf307612:	and    rbx,rsi
    71e6bf307615:	or     rbx,r11
    71e6bf307618:	pop    r11
    71e6bf30761a:	pop    r10
    71e6bf30761c:	pop    rsi
    71e6bf30761d:	pop    rdx
    71e6bf30761e:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf307626:	mov    eax,0x410444
    71e6bf30762b:	mov    QWORD PTR [r12+0x100],rax
    71e6bf307633:	add    rsp,0x150
    71e6bf30763a:	mov    eax,0x3
    71e6bf30763f:	movabs r11,0x5f73f3e93390
    71e6bf307649:	jmp    r11
    71e6bf30764c:	jmp    0x71e6bf304a9d
    71e6bf307651:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf307660:	sub    rsp,0x150
    71e6bf307667:	mov    r11,QWORD PTR [r12+0x398]
    71e6bf30766f:	mov    QWORD PTR [rsp],r11
    71e6bf307673:	cmp    DWORD PTR [r12+0x310],0x0
    71e6bf30767c:	je     0x71e6bf30770c
    71e6bf307682:	push   rdx
    71e6bf307683:	push   rsi
    71e6bf307684:	push   r10
    71e6bf307686:	push   r11
    71e6bf307688:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf30768d:	mov    r10d,edx
    71e6bf307690:	and    r10d,0xc0
    71e6bf307697:	shl    r10d,0x18
    71e6bf30769b:	mov    r11d,edx
    71e6bf30769e:	and    r11d,0x1
    71e6bf3076a2:	shl    r11d,0x1d
    71e6bf3076a6:	or     r10d,r11d
    71e6bf3076a9:	mov    r11d,edx
    71e6bf3076ac:	and    r11d,0x800
    71e6bf3076b3:	shl    r11d,0x11
    71e6bf3076b7:	or     r10d,r11d
    71e6bf3076ba:	btc    r10,0x1d
    71e6bf3076bf:	mov    r11d,0xf0000000
    71e6bf3076c5:	and    r11,r10
    71e6bf3076c8:	movabs rsi,0xffffffff0fffffff
    71e6bf3076d2:	and    rbx,rsi
    71e6bf3076d5:	or     rbx,r11
    71e6bf3076d8:	pop    r11
    71e6bf3076da:	pop    r10
    71e6bf3076dc:	pop    rsi
    71e6bf3076dd:	pop    rdx
    71e6bf3076de:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3076e6:	mov    eax,0x410450
    71e6bf3076eb:	mov    QWORD PTR [r12+0x100],rax
    71e6bf3076f3:	add    rsp,0x150
    71e6bf3076fa:	mov    eax,0x3
    71e6bf3076ff:	movabs r11,0x5f73f3e93390
    71e6bf307709:	jmp    r11
    71e6bf30770c:	jmp    0x71e6bf304ad3
    71e6bf307711:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf307720:	sub    rsp,0x150
    71e6bf307727:	mov    r11,QWORD PTR [r12+0x398]
    71e6bf30772f:	mov    QWORD PTR [rsp],r11
    71e6bf307733:	cmp    DWORD PTR [r12+0x310],0x0
    71e6bf30773c:	je     0x71e6bf3077cc
    71e6bf307742:	push   rdx
    71e6bf307743:	push   rsi
    71e6bf307744:	push   r10
    71e6bf307746:	push   r11
    71e6bf307748:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf30774d:	mov    r10d,edx
    71e6bf307750:	and    r10d,0xc0
    71e6bf307757:	shl    r10d,0x18
    71e6bf30775b:	mov    r11d,edx
    71e6bf30775e:	and    r11d,0x1
    71e6bf307762:	shl    r11d,0x1d
    71e6bf307766:	or     r10d,r11d
    71e6bf307769:	mov    r11d,edx
    71e6bf30776c:	and    r11d,0x800
    71e6bf307773:	shl    r11d,0x11
    71e6bf307777:	or     r10d,r11d
    71e6bf30777a:	btc    r10,0x1d
    71e6bf30777f:	mov    r11d,0xf0000000
    71e6bf307785:	and    r11,r10
    71e6bf307788:	movabs rsi,0xffffffff0fffffff
    71e6bf307792:	and    rbx,rsi
    71e6bf307795:	or     rbx,r11
    71e6bf307798:	pop    r11
    71e6bf30779a:	pop    r10
    71e6bf30779c:	pop    rsi
    71e6bf30779d:	pop    rdx
    71e6bf30779e:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf3077a6:	mov    eax,0x410474
    71e6bf3077ab:	mov    QWORD PTR [r12+0x100],rax
    71e6bf3077b3:	add    rsp,0x150
    71e6bf3077ba:	mov    eax,0x3
    71e6bf3077bf:	movabs r11,0x5f73f3e93390
    71e6bf3077c9:	jmp    r11
    71e6bf3077cc:	jmp    0x71e6bf304c52
    71e6bf3077d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71e6bf3077e0:	sub    rsp,0x150
    71e6bf3077e7:	mov    r11,QWORD PTR [r12+0x398]
    71e6bf3077ef:	mov    QWORD PTR [rsp],r11
    71e6bf3077f3:	cmp    DWORD PTR [r12+0x310],0x0
    71e6bf3077fc:	je     0x71e6bf30788c
    71e6bf307802:	push   rdx
    71e6bf307803:	push   rsi
    71e6bf307804:	push   r10
    71e6bf307806:	push   r11
    71e6bf307808:	mov    rdx,QWORD PTR [rsp+0x20]
    71e6bf30780d:	mov    r10d,edx
    71e6bf307810:	and    r10d,0xc0
    71e6bf307817:	shl    r10d,0x18
    71e6bf30781b:	mov    r11d,edx
    71e6bf30781e:	and    r11d,0x1
    71e6bf307822:	shl    r11d,0x1d
    71e6bf307826:	or     r10d,r11d
    71e6bf307829:	mov    r11d,edx
    71e6bf30782c:	and    r11d,0x800
    71e6bf307833:	shl    r11d,0x11
    71e6bf307837:	or     r10d,r11d
    71e6bf30783a:	btc    r10,0x1d
    71e6bf30783f:	mov    r11d,0xf0000000
    71e6bf307845:	and    r11,r10
    71e6bf307848:	movabs rsi,0xffffffff0fffffff
    71e6bf307852:	and    rbx,rsi
    71e6bf307855:	or     rbx,r11
    71e6bf307858:	pop    r11
    71e6bf30785a:	pop    r10
    71e6bf30785c:	pop    rsi
    71e6bf30785d:	pop    rdx
    71e6bf30785e:	mov    QWORD PTR [r12+0x108],rbx
    71e6bf307866:	mov    eax,0x410490
    71e6bf30786b:	mov    QWORD PTR [r12+0x100],rax
    71e6bf307873:	add    rsp,0x150
    71e6bf30787a:	mov    eax,0x3
    71e6bf30787f:	movabs r11,0x5f73f3e93390
    71e6bf307889:	jmp    r11
    71e6bf30788c:	jmp    0x71e6bf304dea
    71e6bf307891:	nop
    71e6bf307892:	nop
    71e6bf307893:	nop
